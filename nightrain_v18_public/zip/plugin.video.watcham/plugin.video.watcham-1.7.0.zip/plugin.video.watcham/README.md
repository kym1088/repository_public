# watchaM-v18
 왓챠 애드온 for Kodi18


###
# 1.6.1 이후 부터는 저장소를 통해서만 업데이트 됩니다.
* [Korea OTT Package for Kodi 18 (public)-18.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v18_public.zip)
* [Korea OTT Package for Kodi 19 (public)-19.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v19_public.zip)
###


# 공통
- 해상도는 1080p, 720p만 적용됩니다.

- 1080p 적용안될시 조치방법
1. inputstream.adaptive 애드온에서 스트림설정 비디오수동 선택
2. 영화 재생화면에서  비디오설정->화질 변경후 다시 재생하세요

# 변경사항

## Version 1.7.0 (2020.11.01)
- 코드정리

## Version 1.6.1 (2020.09.08)
- 특정스킨 오류 수정

## Version 1.6.0 (2020.08.31)
- 로그인 처리변경 (세션정보 파일처리)

## Version 1.5.2 (2020.06.14)
- vod 최근시청내역 바로보기 옵션 추가

## Version 1.5.1 (2020.04.26)
- 새로 올라온 작품 조회오류 수정

## Version 1.5.0 (2020.04.13)
- 애드온 버전 통일
- 내부폴더명 변경 (이전버전 애드온은 삭제후 설치하세요)
- info 정보 추가

## Version 1.1.0 (2020.04.08)
- 성능개선을 위한 일부구조 변경

## Version 1.0.1 (2020.04.04)
- 일부 영화 자막 안나오는 오류 수정
- 평균별점순 분류 추가

## Version 1.0.0 (2020.03.31)
- Initial addon version

<파악중인 버그>
- 진행바를 마우스 클릭으로 재생시 자막싱크 오류있음 (키보드, 리모컨 등은 정상)

