# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
import os
import xbmcplugin , xbmcgui , xbmcaddon , xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import urlparse
if 46 - 46: ooOoO0o * I11i - OoooooooOO
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
__addon__ = xbmcaddon . Addon ( )
__language__ = __addon__ . getLocalizedString
__profile__ = xbmc . translatePath ( __addon__ . getAddonInfo ( 'profile' ) )
__version__ = __addon__ . getAddonInfo ( 'version' )
__addonid__ = __addon__ . getAddonInfo ( 'id' )
__addonname__ = __addon__ . getAddonInfo ( 'name' )
if 94 - 94: i1IIi % Oo0Ooo
o0oO0 = [
 { 'title' : '왓플 최고 인기작' , 'mode' : 'CATEGORY_LIST' , 'stype' : '-' , 'api_path' : 'staffmades/409' , 'sort' : '-' }
 , { 'title' : '최고 인기 시리즈' , 'mode' : 'CATEGORY_LIST' , 'stype' : '-' , 'api_path' : 'staffmades/410' , 'sort' : '-' }
 , { 'title' : '새로 올라온 작품' , 'mode' : 'CATEGORY_LIST' , 'stype' : '-' , 'api_path' : 'arrivals/latest' , 'sort' : '-' }
 , { 'title' : '이어보기' , 'mode' : 'CATEGORY_LIST' , 'stype' : '-' , 'api_path' : 'users/me/watchings' , 'sort' : '-' }
 , { 'title' : '장르별 분류 (평균별점순)' , 'mode' : 'SUB_GROUP' , 'stype' : 'genres' , 'api_path' : '-' , 'sort' : '2' }
 , { 'title' : '특징별 분류 (평균별점순)' , 'mode' : 'SUB_GROUP' , 'stype' : 'tags' , 'api_path' : '-' , 'sort' : '2' }
 , { 'title' : '장르별 분류 (추천순)' , 'mode' : 'SUB_GROUP' , 'stype' : 'genres' , 'api_path' : '-' , 'sort' : '1' }
 , { 'title' : '특징별 분류 (추천순)' , 'mode' : 'SUB_GROUP' , 'stype' : 'tags' , 'api_path' : '-' , 'sort' : '1' }
 , { 'title' : '-----------------' , 'mode' : 'XXX' , 'stype' : 'XXX' , 'api_path' : '-' , 'sort' : '-' }
 , { 'title' : '검색 (search)' , 'mode' : 'SEARCH' , 'stype' : '-' , 'api_path' : '-' , 'sort' : '-' }
 , { 'title' : 'Watched (시청목록)' , 'mode' : 'WATCH' , 'stype' : '-' , 'api_path' : '-' , 'sort' : '-' }
 ]
if 100 - 100: i1IIi
I1Ii11I1Ii1i = [
 { 'title' : '영화 시청내역' , 'mode' : 'WATCH' , 'stype' : 'movie' }
 , { 'title' : '시리즈 시청내역' , 'mode' : 'WATCH' , 'stype' : 'seasons' }
 ]
if 67 - 67: iIii1I11I1II1 . I1ii11iIi11i . oO0o / i1IIi % II111iiii - OoOoOO00
OOo = 40
Ii1IIii11 = 20
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * IiII * i1IIi / iIii1I11I1II1
OOo000 = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
O0I11i1i11i1I = xbmc . translatePath ( os . path . join ( __profile__ , 'temp_subtitles.vtt' ) )
Iiii = xbmc . translatePath ( os . path . join ( __profile__ , 'watcha_cookies.json' ) )
if 87 - 87: oO0o / ooOoO0o + I1Ii111 - ooOoO0o . ooOoO0o / II111iiii
from watchaCore import *
if 11 - 11: I1IiiI % o0oOOo0O0Ooo - Oo0Ooo
if 58 - 58: i11iIiiIii % I1Ii111
class O0OoOoo00o ( object ) :
 def __init__ ( self , in_addonurl , in_handle , in_params ) :
  self . _addon_url = in_addonurl
  self . _addon_handle = in_handle
  self . main_params = in_params
  self . WatchaObj = xI1Ii11I1Ii1i ( )
  if 31 - 31: II111iiii + OoO0O00 . I1Ii111
  if 68 - 68: I1IiiI - i11iIiiIii - OoO0O00 / OOooOOo - OoO0O00 + i1IIi
  if 48 - 48: OoooooooOO % o0oOOo0O0Ooo . I1IiiI - Ii1I % i1IIi % OoooooooOO
 def addon_noti ( self , sting ) :
  try :
   i1iIIi1 = xbmcgui . Dialog ( )
   i1iIIi1 . notification ( __addonname__ , sting )
  except :
   None
   if 50 - 50: i11iIiiIii - Ii1I
   if 78 - 78: OoO0O00
   if 18 - 18: O0 - iII111i / iII111i + ooOoO0o % ooOoO0o - IiII
 def addon_log ( self , string ) :
  try :
   O0O00Ooo = string . encode ( 'utf-8' , 'ignore' )
  except :
   O0O00Ooo = 'addonException: addon_log'
   if 64 - 64: oO0o - O0 / II111iiii / o0oOOo0O0Ooo / iIii1I11I1II1
   if 24 - 24: O0 % o0oOOo0O0Ooo + i1IIi + I1Ii111 + I1ii11iIi11i
  OOoO000O0OO = xbmc . LOGINFO
  xbmc . log ( "[%s-%s]: %s" % ( __addonid__ , __version__ , O0O00Ooo ) , level = OOoO000O0OO )
  if 23 - 23: i11iIiiIii + I1IiiI
  if 68 - 68: OoOoOO00 . oO0o . i11iIiiIii
  if 40 - 40: oO0o . OoOoOO00 . Oo0Ooo . i1IIi
  if 33 - 33: Ii1I + II111iiii % i11iIiiIii . ooOoO0o - I1IiiI
 def get_keyboard_input ( self , title ) :
  O00oooo0O = None
  IiI1i11iii1 = xbmc . Keyboard ( )
  IiI1i11iii1 . setHeading ( title )
  xbmc . sleep ( 1000 )
  IiI1i11iii1 . doModal ( )
  if ( IiI1i11iii1 . isConfirmed ( ) ) :
   O00oooo0O = IiI1i11iii1 . getText ( )
  return O00oooo0O
  if 96 - 96: O0 % oO0o % iIii1I11I1II1
  if 78 - 78: iIii1I11I1II1 - Ii1I * OoO0O00 + o0oOOo0O0Ooo + iII111i + iII111i
  if 11 - 11: iII111i - OoO0O00 % ooOoO0o % iII111i / OoOoOO00 - OoO0O00
  if 74 - 74: iII111i * O0
 def get_settings_login_info ( self ) :
  oOOo0oo = __addon__ . getSetting ( 'id' )
  o0oo0o0O00OO = __addon__ . getSetting ( 'pw' )
  o0oO = int ( __addon__ . getSetting ( 'selected_profile' ) )
  return ( oOOo0oo , o0oo0o0O00OO , o0oO )
  if 48 - 48: I11i + I11i / II111iiii / iIii1I11I1II1
  if 20 - 20: o0oOOo0O0Ooo
  if 77 - 77: OoOoOO00 / I11i
  if 98 - 98: iIii1I11I1II1 / i1IIi / i11iIiiIii / o0oOOo0O0Ooo
 def get_selQuality ( self ) :
  try :
   if 28 - 28: OOooOOo - IiII . IiII + OoOoOO00 - OoooooooOO + O0
   if 95 - 95: OoO0O00 % oO0o . O0
   I1i1I = [ '3840x2160/1' , '1920x1080/1' , '1280x720/1' ]
   if 80 - 80: OoOoOO00 - OoO0O00
   OOO00 = int ( __addon__ . getSetting ( 'selected_quality' ) )
   return I1i1I [ OOO00 ]
  except :
   None
   if 21 - 21: OoooooooOO - OoooooooOO
  return 1080
  if 8 - 8: OoOoOO00
  if 60 - 60: I11i / I11i
  if 46 - 46: Ii1I * OOooOOo - OoO0O00 * oO0o - I1Ii111
 def get_settings_direct_replay ( self ) :
  oo0 = int ( __addon__ . getSetting ( 'direct_replay' ) )
  if oo0 == 0 :
   return False
  else :
   return True
   if 57 - 57: OOooOOo . OOooOOo
   if 95 - 95: O0 + OoO0O00 . II111iiii / O0
   if 97 - 97: ooOoO0o - OOooOOo * i11iIiiIii / OoOoOO00 % I1Ii111 - OoooooooOO
   if 59 - 59: O0 + I1IiiI + IiII % I1IiiI
   if 70 - 70: iII111i * I1ii11iIi11i
 def set_winCredential ( self , credential ) :
  i1II1 = xbmcgui . Window ( 10000 )
  i1II1 . setProperty ( 'WATCHA_M_TOKEN' , credential . get ( 'watcha_token' ) )
  i1II1 . setProperty ( 'WATCHA_M_GUIT' , credential . get ( 'watcha_guit' ) )
  i1II1 . setProperty ( 'WATCHA_M_GUITV' , credential . get ( 'watcha_guitv' ) )
  i1II1 . setProperty ( 'WATCHA_M_USERCD' , credential . get ( 'watcha_usercd' ) )
  i1II1 . setProperty ( 'WATCHA_M_LOGINTIME' , self . WatchaObj . Get_Now_Datetime ( ) . strftime ( '%Y-%m-%d' ) )
  if 66 - 66: OoooooooOO + Ii1I + Ii1I - i1IIi
  if 55 - 55: OOooOOo + ooOoO0o . i1IIi - I1ii11iIi11i . O0 - ooOoO0o
 def get_winCredential ( self ) :
  i1II1 = xbmcgui . Window ( 10000 )
  o0O = {
 'watcha_token' : i1II1 . getProperty ( 'WATCHA_M_TOKEN' )
 , 'watcha_guit' : i1II1 . getProperty ( 'WATCHA_M_GUIT' )
 , 'watcha_guitv' : i1II1 . getProperty ( 'WATCHA_M_GUITV' )
 , 'watcha_usercd' : i1II1 . getProperty ( 'WATCHA_M_USERCD' )
 }
  return o0O
  if 72 - 72: iII111i / i1IIi * Oo0Ooo - I1Ii111
 def set_winEpisodeOrderby ( self , orderby ) :
  i1II1 = xbmcgui . Window ( 10000 )
  i1II1 . setProperty ( 'WATCHA_M_ORDERBY' , orderby )
  if 51 - 51: II111iiii * OoO0O00 % o0oOOo0O0Ooo * II111iiii % I1ii11iIi11i / ooOoO0o
 def get_winEpisodeOrderby ( self ) :
  i1II1 = xbmcgui . Window ( 10000 )
  return i1II1 . getProperty ( 'WATCHA_M_ORDERBY' )
  if 49 - 49: o0oOOo0O0Ooo
  if 35 - 35: OoOoOO00 - OoooooooOO / I1ii11iIi11i % i1IIi
  if 78 - 78: I11i
 def dp_setEpOrderby ( self , args ) :
  OO00Oo = args . get ( 'orderby' )
  if 51 - 51: IiII * o0oOOo0O0Ooo + I11i + OoO0O00
  self . set_winEpisodeOrderby ( OO00Oo )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 66 - 66: OoOoOO00
  if 97 - 97: oO0o % IiII * IiII
  if 39 - 39: Ii1I % IiII
  if 4 - 4: oO0o
 def add_dir ( self , label , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = '' ) :
  OOoO0O00o0 = '%s?%s' % ( self . _addon_url , urllib . urlencode ( params ) )
  if 30 - 30: o0oOOo0O0Ooo . Ii1I - OoooooooOO
  if sublabel : Ii1iIiii1 = '%s < %s >' % ( label , sublabel )
  else : Ii1iIiii1 = label
  if not img : img = 'DefaultFolder.png'
  if 91 - 91: OoO0O00 . I1ii11iIi11i + OoO0O00 - iII111i / OoooooooOO
  iII1 = xbmcgui . ListItem ( Ii1iIiii1 )
  iII1 . setArt ( { 'thumbnailImage' : img , 'icon' : img , 'poster' : img } )
  if 30 - 30: II111iiii - OOooOOo - i11iIiiIii % OoOoOO00 - II111iiii * Ii1I
  if infoLabels : iII1 . setInfo ( type = "Video" , infoLabels = infoLabels )
  if not isFolder : iII1 . setProperty ( 'IsPlayable' , 'true' )
  if 61 - 61: oO0o - I11i % OOooOOo
  xbmcplugin . addDirectoryItem ( self . _addon_handle , OOoO0O00o0 , iII1 , isFolder )
  if 84 - 84: oO0o * OoO0O00 / I11i - O0
  if 30 - 30: iIii1I11I1II1 / ooOoO0o - I1Ii111 - II111iiii % iII111i
  if 49 - 49: I1IiiI % ooOoO0o . ooOoO0o . I11i * ooOoO0o
  if 97 - 97: Ii1I + o0oOOo0O0Ooo . OOooOOo + I1ii11iIi11i % iII111i
  if 95 - 95: i1IIi
 def dp_Main_List ( self ) :
  if 3 - 3: I1Ii111 - O0 / I1Ii111 % OoO0O00 / I1Ii111 . I1IiiI
  for iiI111I1iIiI in o0oO0 :
   Ii1iIiii1 = iiI111I1iIiI . get ( 'title' )
   if 41 - 41: Oo0Ooo . ooOoO0o + O0 * o0oOOo0O0Ooo % Oo0Ooo * Oo0Ooo
   iIIIIi1iiIi1 = { 'mode' : iiI111I1iIiI . get ( 'mode' )
 , 'stype' : iiI111I1iIiI . get ( 'stype' )
 , 'api_path' : iiI111I1iIiI . get ( 'api_path' )
 , 'page' : '1'
 , 'sort' : iiI111I1iIiI . get ( 'sort' )
 , 'tag_id' : '-'
 }
   if 21 - 21: I1IiiI * iIii1I11I1II1
   if iiI111I1iIiI . get ( 'mode' ) == 'XXX' :
    iIIIIi1iiIi1 [ 'mode' ] = 'XXX'
    oooooOoo0ooo = False
   else :
    oooooOoo0ooo = True
    if 6 - 6: I11i - Ii1I + iIii1I11I1II1 - I1Ii111 - i11iIiiIii
   self . add_dir ( Ii1iIiii1 , sublabel = '' , img = '' , infoLabels = None , isFolder = oooooOoo0ooo , params = iIIIIi1iiIi1 )
  if len ( o0oO0 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle )
  if 79 - 79: OoOoOO00 - O0 * OoO0O00 + OoOoOO00 % O0 * O0
  if 61 - 61: II111iiii
  if 64 - 64: ooOoO0o / OoOoOO00 - O0 - I11i
  if 86 - 86: I11i % OoOoOO00 / I1IiiI / OoOoOO00
 def login_main ( self ) :
  ( iIIi1i1 , i1IIIiiII1 , OOOOoOoo0O0O0 ) = self . get_settings_login_info ( )
  if 85 - 85: oO0o % i11iIiiIii - iII111i * OoooooooOO / I1IiiI % I1IiiI
  if 1 - 1: OoO0O00 - oO0o . I11i . OoO0O00 / Oo0Ooo + I11i
  if not ( iIIi1i1 and i1IIIiiII1 ) :
   i1iIIi1 = xbmcgui . Dialog ( )
   Ooo = i1iIIi1 . yesno ( __language__ ( 30901 ) . encode ( 'utf8' ) , __language__ ( 30902 ) . encode ( 'utf8' ) )
   if Ooo == True :
    __addon__ . openSettings ( )
    sys . exit ( )
   else :
    sys . exit ( )
    if 62 - 62: OOooOOo / OoO0O00 + Ii1I / OoO0O00 . II111iiii
    if 68 - 68: i11iIiiIii % I1ii11iIi11i + i11iIiiIii
  if self . get_winEpisodeOrderby ( ) == '' :
   self . set_winEpisodeOrderby ( 'asc' )
   if 31 - 31: II111iiii . I1IiiI
   if 1 - 1: Oo0Ooo / o0oOOo0O0Ooo % iII111i * IiII . i11iIiiIii
  if self . cookiefile_check ( ) : return
  if 2 - 2: I1ii11iIi11i * I11i - iIii1I11I1II1 + I1IiiI . oO0o % iII111i
  if 92 - 92: iII111i
  IIiIiiIi = int ( self . WatchaObj . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' ) )
  O000oo = xbmcgui . Window ( 10000 ) . getProperty ( 'WATCHA_M_LOGINTIME' )
  if 20 - 20: OOooOOo % Ii1I / Ii1I + Ii1I
  if O000oo == None or O000oo == '' :
   O000oo = int ( '19000101' )
  else :
   O000oo = int ( re . sub ( '-' , '' , O000oo ) )
   if 45 - 45: oO0o - IiII - OoooooooOO - OoO0O00 . II111iiii / O0
   if 51 - 51: O0 + iII111i
   if 8 - 8: oO0o * OoOoOO00 - Ii1I - OoO0O00 * OOooOOo % I1IiiI
  if xbmcgui . Window ( 10000 ) . getProperty ( 'WATCHA_M_LOGINWAIT' ) == 'TRUE' :
   ii = 0
   while True :
    ii += 1
    if 90 - 90: o0oOOo0O0Ooo % i1IIi / OoO0O00
    time . sleep ( 0.05 )
    if 44 - 44: Oo0Ooo . OoO0O00 / I1ii11iIi11i + Ii1I
    if O000oo >= IIiIiiIi : return
    if ii > 600 : return
  else :
   xbmcgui . Window ( 10000 ) . setProperty ( 'WATCHA_M_LOGINWAIT' , 'TRUE' )
   if 65 - 65: O0
  if O000oo >= IIiIiiIi :
   xbmcgui . Window ( 10000 ) . setProperty ( 'WATCHA_M_LOGINWAIT' , 'FALSE' )
   return
   if 68 - 68: OOooOOo % I1Ii111
   if 88 - 88: iIii1I11I1II1 - ooOoO0o + OOooOOo
  if not self . WatchaObj . GetCredential ( iIIi1i1 , i1IIIiiII1 , OOOOoOoo0O0O0 ) :
   self . addon_noti ( __language__ ( 30903 ) . encode ( 'utf8' ) )
   xbmcgui . Window ( 10000 ) . setProperty ( 'WATCHA_M_LOGINWAIT' , 'FALSE' )
   sys . exit ( )
   if 40 - 40: I1IiiI * Ii1I + OOooOOo % iII111i
   if 74 - 74: oO0o - Oo0Ooo + OoooooooOO + I1Ii111 / OoOoOO00
  self . set_winCredential ( self . WatchaObj . LoadCredential ( ) )
  self . cookiefile_save ( )
  xbmcgui . Window ( 10000 ) . setProperty ( 'WATCHA_M_LOGINWAIT' , 'FALSE' )
  if 23 - 23: O0
  if 85 - 85: Ii1I
  if 84 - 84: I1IiiI . iIii1I11I1II1 % OoooooooOO + Ii1I % OoooooooOO % OoO0O00
  if 42 - 42: OoO0O00 / I11i / o0oOOo0O0Ooo + iII111i / OoOoOO00
  if 84 - 84: ooOoO0o * II111iiii + Oo0Ooo
  if 53 - 53: iII111i % II111iiii . IiII - iIii1I11I1II1 - IiII * II111iiii
 def dp_SubGroup_List ( self , args ) :
  if 77 - 77: iIii1I11I1II1 * OoO0O00
  self . WatchaObj . SaveCredential ( self . get_winCredential ( ) )
  if 95 - 95: I1IiiI + i11iIiiIii
  I1Ii = args . get ( 'stype' )
  O0oo00o0O = int ( args . get ( 'page' ) )
  i1I1I = args . get ( 'sort' )
  if 12 - 12: i11iIiiIii / OoO0O00
  o0OIiII = self . WatchaObj . GetSubGroupList ( I1Ii )
  if 25 - 25: O0 - O0 * o0oOOo0O0Ooo
  OOOO0oo0 = OOo if I1Ii == 'genres' else Ii1IIii11
  if 35 - 35: Ii1I - I1IiiI % o0oOOo0O0Ooo . OoooooooOO % Ii1I
  I1i1Iiiii = len ( o0OIiII )
  OOo0oO00ooO00 = int ( I1i1Iiiii // ( OOOO0oo0 + 1 ) ) + 1
  oOO0O00oO0Ooo = ( O0oo00o0O - 1 ) * OOOO0oo0
  if 67 - 67: OoO0O00 - OOooOOo
  for iI1i11iII111 in range ( OOOO0oo0 ) :
   Iii1IIII11I = oOO0O00oO0Ooo + iI1i11iII111
   if Iii1IIII11I >= I1i1Iiiii : break
   if 77 - 77: Oo0Ooo - i1IIi - I11i . OoOoOO00
   Ii1iIiii1 = o0OIiII [ Iii1IIII11I ] . get ( 'group_name' )
   IiI1i = o0OIiII [ Iii1IIII11I ] . get ( 'api_path' )
   o0Oo00 = o0OIiII [ Iii1IIII11I ] . get ( 'tag_id' )
   if 32 - 32: o0oOOo0O0Ooo . IiII * I11i
   iIIIIi1iiIi1 = { 'mode' : 'CATEGORY_LIST'
 , 'api_path' : IiI1i
 , 'tag_id' : o0Oo00
 , 'stype' : I1Ii
 , 'page' : '1'
 , 'sort' : i1I1I
 }
   if 93 - 93: o0oOOo0O0Ooo % i1IIi . Ii1I . i11iIiiIii
   self . add_dir ( Ii1iIiii1 , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = iIIIIi1iiIi1 )
   if 56 - 56: I1ii11iIi11i % O0 - I1IiiI
  if OOo0oO00ooO00 > O0oo00o0O :
   iIIIIi1iiIi1 = { }
   iIIIIi1iiIi1 [ 'mode' ] = 'SUB_GROUP'
   iIIIIi1iiIi1 [ 'stype' ] = I1Ii
   iIIIIi1iiIi1 [ 'api_path' ] = args . get ( 'api_path' )
   iIIIIi1iiIi1 [ 'page' ] = str ( O0oo00o0O + 1 )
   iIIIIi1iiIi1 [ 'sort' ] = i1I1I
   Ii1iIiii1 = '[B]%s >>[/B]' % '다음 페이지'
   O00o0OO0 = str ( O0oo00o0O + 1 )
   self . add_dir ( Ii1iIiii1 , sublabel = O00o0OO0 , img = '' , infoLabels = None , isFolder = True , params = iIIIIi1iiIi1 )
   if 35 - 35: oO0o % ooOoO0o / I1Ii111 + iIii1I11I1II1 . OoooooooOO . I1IiiI
   if 71 - 71: IiII * II111iiii * oO0o
  if len ( o0OIiII ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 56 - 56: I1IiiI
  if 54 - 54: I1Ii111 / OOooOOo . oO0o % iII111i
  if 57 - 57: i11iIiiIii . I1ii11iIi11i - Ii1I - oO0o + OoOoOO00
  if 63 - 63: OoOoOO00 * iII111i
 def play_VIDEO ( self , args ) :
  if 69 - 69: O0 . OoO0O00
  self . WatchaObj . SaveCredential ( self . get_winCredential ( ) )
  if 49 - 49: I1IiiI - I11i
  OoOOoOooooOOo = args . get ( 'movie_code' )
  oOo0O = args . get ( 'season_code' )
  Ii1iIiii1 = args . get ( 'title' )
  oo0O0 = args . get ( 'thumbnail' )
  iI = self . get_selQuality ( )
  if 89 - 89: o0oOOo0O0Ooo + OoO0O00 * I11i * Ii1I
  self . addon_log ( OoOOoOooooOOo + ' - ' + oOo0O )
  iiIiI1i1 , oO0O00oOOoooO , IiIi11iI = self . WatchaObj . GetStreamingURL ( OoOOoOooooOOo , iI )
  if 83 - 83: II111iiii % Oo0Ooo % ooOoO0o % I1ii11iIi11i
  if 80 - 80: i11iIiiIii % ooOoO0o + Ii1I % I11i - I1ii11iIi11i
  if iiIiI1i1 == '' :
   self . addon_noti ( __language__ ( 30908 ) . encode ( 'utf8' ) )
   return
   if 18 - 18: iII111i - OOooOOo . I1Ii111 . iIii1I11I1II1
   if 2 - 2: OOooOOo . OoO0O00
   if 78 - 78: I11i * iIii1I11I1II1 . I1IiiI / o0oOOo0O0Ooo - OoooooooOO / I1Ii111
   if 35 - 35: I11i % OOooOOo - oO0o
  ii1iii1i = iiIiI1i1
  self . addon_log ( ii1iii1i )
  if 35 - 35: II111iiii % OOooOOo . ooOoO0o + ooOoO0o % II111iiii % II111iiii
  if 72 - 72: II111iiii + i1IIi + o0oOOo0O0Ooo
  OOO = xbmcgui . ListItem ( path = ii1iii1i )
  if 25 - 25: oO0o - OoO0O00 . iIii1I11I1II1 % i11iIiiIii % I1ii11iIi11i
  if IiIi11iI :
   o0Oo0oO0oOO00 = IiIi11iI
   oo00OO0000oO = 'https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true'
   I1II1 = 'mpd'
   oooO = 'com.widevine.alpha'
   if 26 - 26: Ii1I % I1ii11iIi11i
   o00Oo0oooooo = inputstreamhelper . Helper ( I1II1 , drm = oooO )
   if 76 - 76: I11i / OOooOOo . O0 % I1IiiI . o0oOOo0O0Ooo + IiII
   if o00Oo0oooooo . check_inputstream ( ) :
    if 71 - 71: I1Ii111 . II111iiii
    oo0oOOOoo00 = { 'Host' : 'lic.drmtoday.com'
 , 'origin' : 'https://play.watcha.net'
 , 'referer' : 'https://play.watcha.net/watch/' + OoOOoOooooOOo
 , 'dt-custom-data' : o0Oo0oO0oOO00
 , 'Sec-Fetch-Dest' : 'empty'
 , 'sec-fetch-mode' : 'cors'
 , 'sec-fetch-site' : 'cross-site'
 , 'user-agent' : OOo000
 , 'Content-Type' : 'application/octet-stream'
 }
    iiIiIIIiiI = oo00OO0000oO + '|' + urllib . urlencode ( oo0oOOOoo00 ) + '|R{SSM}|'
    if 12 - 12: O0 - o0oOOo0O0Ooo
    self . addon_log ( iiIiIIIiiI )
    if 81 - 81: OoOoOO00 - OoOoOO00 . iII111i
    OOO . setProperty ( 'inputstreamaddon' , o00Oo0oooooo . inputstream_addon )
    OOO . setProperty ( 'inputstream.adaptive.manifest_type' , I1II1 )
    OOO . setProperty ( 'inputstream.adaptive.license_type' , oooO )
    OOO . setProperty ( 'inputstream.adaptive.license_key' , iiIiIIIiiI )
    if 73 - 73: I11i % i11iIiiIii - I1IiiI
    OOO . setProperty ( 'inputstream.adaptive.stream_headers' , 'user-agent=%s' % ( OOo000 ) )
    if 7 - 7: O0 * i11iIiiIii * Ii1I + ooOoO0o % OoO0O00 - ooOoO0o
    if 39 - 39: Oo0Ooo * OOooOOo % OOooOOo - OoooooooOO + o0oOOo0O0Ooo - I11i
    if 23 - 23: i11iIiiIii
    if 30 - 30: o0oOOo0O0Ooo - i1IIi % II111iiii + I11i * iIii1I11I1II1
  if oO0O00oOOoooO :
   try :
    o0ooooO0o0O = open ( O0I11i1i11i1I , 'w' )
    iiIi11iI1iii = requests . get ( oO0O00oOOoooO )
    oo000 = iiIi11iI1iii . content . decode ( 'utf-8' )
    if 63 - 63: ooOoO0o + OOooOOo * Ii1I
    for iI1 in oo000 . splitlines ( ) :
     I111I = re . sub ( r'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*' , r'00:\1.\2 --> 00:\3.\4' , iI1 )
     o0ooooO0o0O . write ( I111I + '\n' )
    o0ooooO0o0O . close ( )
    OOO . setSubtitles ( [ O0I11i1i11i1I , oO0O00oOOoooO ] )
   except :
    OOO . setSubtitles ( [ oO0O00oOOoooO ] )
    if 97 - 97: i1IIi . oO0o / iII111i * O0
    if 73 - 73: OOooOOo / oO0o
  xbmcplugin . setResolvedUrl ( self . _addon_handle , True , OOO )
  if 88 - 88: I11i % I1ii11iIi11i
  if 48 - 48: ooOoO0o / I1Ii111 . iIii1I11I1II1 * OoOoOO00 * oO0o / i1IIi
  if 92 - 92: Oo0Ooo % Oo0Ooo - o0oOOo0O0Ooo / OoOoOO00
  try :
   I1Ii = 'movie' if oOo0O == '-' else 'seasons'
   iIIIIi1iiIi1 = { 'code' : OoOOoOooooOOo if I1Ii == 'movie' else oOo0O
 , 'img' : oo0O0
 , 'title' : Ii1iIiii1
 , 'videoid' : OoOOoOooooOOo
   }
   self . Save_Watched_List ( I1Ii , iIIIIi1iiIi1 )
  except :
   None
   if 10 - 10: iII111i + Oo0Ooo * I1ii11iIi11i + iIii1I11I1II1 / I1Ii111 / I1ii11iIi11i
   if 42 - 42: I1IiiI
   if 38 - 38: OOooOOo + II111iiii % ooOoO0o % OoOoOO00 - Ii1I / OoooooooOO
   if 73 - 73: o0oOOo0O0Ooo * O0 - i11iIiiIii
   if 85 - 85: Ii1I % iII111i + I11i / o0oOOo0O0Ooo . oO0o + OOooOOo
 def dp_Category_List ( self , args ) :
  if 62 - 62: i11iIiiIii + i11iIiiIii - o0oOOo0O0Ooo
  self . WatchaObj . SaveCredential ( self . get_winCredential ( ) )
  if 28 - 28: iII111i . iII111i % iIii1I11I1II1 * iIii1I11I1II1 . o0oOOo0O0Ooo / iII111i
  I1Ii = args . get ( 'stype' )
  o0Oo00 = args . get ( 'tag_id' )
  IiI1i = args . get ( 'api_path' )
  O0oo00o0O = int ( args . get ( 'page' ) )
  i1I1I = args . get ( 'sort' )
  if 27 - 27: OoO0O00 + ooOoO0o - i1IIi
  O00oOOooo , iI1iIii11Ii = self . WatchaObj . GetCategoryList ( I1Ii , o0Oo00 , IiI1i , O0oo00o0O , i1I1I )
  if 8 - 8: I1ii11iIi11i * I1Ii111 . ooOoO0o / Ii1I - Oo0Ooo % O0
  if 17 - 17: Oo0Ooo * IiII
  for I11 in O00oOOooo :
   OoOOoOooooOOo = I11 . get ( 'code' )
   Ii1iIiii1 = I11 . get ( 'title' )
   OO = I11 . get ( 'content_type' )
   o0O0oo0OO0O = I11 . get ( 'story' )
   oo0O0 = I11 . get ( 'thumbnail' )
   OO0 = I11 . get ( 'year' )
   o0Oooo = I11 . get ( 'film_rating_code' )
   iiI = I11 . get ( 'film_rating_short' )
   if 56 - 56: Oo0Ooo . I1ii11iIi11i . I1IiiI
   if OO == 'movies' :
    oooooOoo0ooo = False
    ii111I = 'MOVIE'
    iiIiIiiiII = ''
    oOo0O = '-'
   else :
    oooooOoo0ooo = True
    ii111I = 'EPISODE'
    iiIiIiiiII = 'Series'
    oOo0O = OoOOoOooooOOo
    if 20 - 20: I1IiiI
   o0oO000oo = I11 . get ( 'info' )
   o0oO000oo [ 'plot' ] = '%s (%s)\n년도 : %s\n\n%s' % ( Ii1iIiii1 , iiI , OO0 , o0O0oo0OO0O )
   if 95 - 95: ooOoO0o / ooOoO0o
   if o0Oooo >= 19 :
    Ii1iIiii1 += '  (%s년 - %s)' % ( OO0 , str ( iiI ) )
   else :
    Ii1iIiii1 += '  (%s년)' % ( OO0 )
    if 30 - 30: I1ii11iIi11i + Oo0Ooo / Oo0Ooo % I1ii11iIi11i . I1ii11iIi11i
    if 55 - 55: ooOoO0o - I11i + II111iiii + iII111i % Ii1I
   iIIIIi1iiIi1 = { 'mode' : ii111I
 , 'movie_code' : OoOOoOooooOOo
 , 'page' : '1'
 , 'season_code' : oOo0O
   , 'title' : Ii1iIiii1
 , 'thumbnail' : oo0O0
 }
   if 41 - 41: i1IIi - I11i - Ii1I
   self . add_dir ( Ii1iIiii1 , sublabel = iiIiIiiiII , img = oo0O0 , infoLabels = o0oO000oo , isFolder = oooooOoo0ooo , params = iIIIIi1iiIi1 )
   if 8 - 8: OoO0O00 + I1Ii111 - o0oOOo0O0Ooo % Oo0Ooo % o0oOOo0O0Ooo * oO0o
   if 9 - 9: Oo0Ooo - i11iIiiIii - OOooOOo * Ii1I + ooOoO0o
  if iI1iIii11Ii :
   if self . WatchaObj . GetCategoryList_morepage ( I1Ii , o0Oo00 , IiI1i , O0oo00o0O + 1 , i1I1I ) :
    iIIIIi1iiIi1 = { }
    iIIIIi1iiIi1 [ 'mode' ] = 'CATEGORY_LIST'
    iIIIIi1iiIi1 [ 'stype' ] = I1Ii
    iIIIIi1iiIi1 [ 'tag_id' ] = o0Oo00
    iIIIIi1iiIi1 [ 'api_path' ] = IiI1i
    iIIIIi1iiIi1 [ 'page' ] = str ( O0oo00o0O + 1 )
    iIIIIi1iiIi1 [ 'sort' ] = i1I1I
    Ii1iIiii1 = '[B]%s >>[/B]' % '다음 페이지'
    O00o0OO0 = str ( O0oo00o0O + 1 )
    self . add_dir ( Ii1iIiii1 , sublabel = O00o0OO0 , img = '' , infoLabels = None , isFolder = True , params = iIIIIi1iiIi1 )
    if 44 - 44: II111iiii
  if len ( O00oOOooo ) > 0 :
   if IiI1i == 'arrivals/latest' :
    xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
   else :
    xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
    if 52 - 52: I1ii11iIi11i - Oo0Ooo + I1ii11iIi11i % o0oOOo0O0Ooo
    if 35 - 35: iIii1I11I1II1
    if 42 - 42: I1Ii111 . I1IiiI . i1IIi + OoOoOO00 + OOooOOo + I1IiiI
    if 31 - 31: iII111i . OOooOOo - ooOoO0o . OoooooooOO / OoooooooOO
    if 56 - 56: OoO0O00 / oO0o / i11iIiiIii + OoooooooOO - Oo0Ooo - I11i
 def dp_Episode_List ( self , args ) :
  if 21 - 21: O0 % IiII . I1IiiI / II111iiii + IiII
  self . WatchaObj . SaveCredential ( self . get_winCredential ( ) )
  if 53 - 53: oO0o - I1IiiI - oO0o * iII111i
  oooooo0OO = args . get ( 'movie_code' )
  O0oo00o0O = int ( args . get ( 'page' ) )
  oOo0O = args . get ( 'season_code' )
  if 14 - 14: oO0o / oO0o % ooOoO0o
  if 56 - 56: I1IiiI . O0 + Oo0Ooo
  O00oOOooo , iI1iIii11Ii = self . WatchaObj . GetEpisodoList ( oooooo0OO , O0oo00o0O , orderby = self . get_winEpisodeOrderby ( ) )
  if 1 - 1: iII111i
  if 97 - 97: OOooOOo + iII111i + O0 + i11iIiiIii
  for I11 in O00oOOooo :
   OoOOoOooooOOo = I11 . get ( 'code' )
   Ii1iIiii1 = I11 . get ( 'title' )
   oo0O0 = I11 . get ( 'thumbnail' )
   oOoO0 = I11 . get ( 'display_num' )
   Oo0 = I11 . get ( 'season_title' )
   if 83 - 83: i11iIiiIii % o0oOOo0O0Ooo % ooOoO0o
   o0oO000oo = I11 . get ( 'info' )
   o0oO000oo [ 'plot' ] = '%s\n%s\n\n%s' % ( Oo0 , oOoO0 , Ii1iIiii1 )
   if 11 - 11: II111iiii % OoO0O00 * iII111i + ooOoO0o + Ii1I
   Ii1iIiii1 = '(%s) %s' % ( oOoO0 , Ii1iIiii1 )
   if 24 - 24: Oo0Ooo - oO0o % iIii1I11I1II1 . i1IIi / O0
   iIIIIi1iiIi1 = { 'mode' : 'MOVIE'
 , 'movie_code' : OoOOoOooooOOo
 , 'season_code' : oOo0O
   # o0oOOo0O0Ooo / I11i / II111iiii
   , 'title' : '%s < %s >' % ( Ii1iIiii1 , Oo0 )
 , 'thumbnail' : oo0O0
 }
   if 27 - 27: OOooOOo * ooOoO0o . I1Ii111 % IiII * IiII . i1IIi
   self . add_dir ( Ii1iIiii1 , sublabel = Oo0 , img = oo0O0 , infoLabels = o0oO000oo , isFolder = False , params = iIIIIi1iiIi1 )
   if 72 - 72: OOooOOo % I1ii11iIi11i + OoO0O00 / oO0o + IiII
  if O0oo00o0O == 1 :
   o0oO000oo = { 'plot' : '정렬순서를 변경합니다.' }
   iIIIIi1iiIi1 = { }
   iIIIIi1iiIi1 [ 'mode' ] = 'ORDER_BY'
   if self . get_winEpisodeOrderby ( ) == 'desc' :
    Ii1iIiii1 = '정렬순서변경 : 최신화부터 -> 1회부터'
    iIIIIi1iiIi1 [ 'orderby' ] = 'asc'
   else :
    Ii1iIiii1 = '정렬순서변경 : 1회부터 -> 최신화부터'
    iIIIIi1iiIi1 [ 'orderby' ] = 'desc'
   self . add_dir ( Ii1iIiii1 , sublabel = '' , img = '' , infoLabels = o0oO000oo , isFolder = False , params = iIIIIi1iiIi1 )
   if 10 - 10: I1Ii111 / ooOoO0o + i11iIiiIii / Ii1I
  if iI1iIii11Ii :
   if 74 - 74: OOooOOo + O0 + i1IIi - i1IIi + II111iiii
   iIIIIi1iiIi1 [ 'mode' ] = 'EPISODE'
   iIIIIi1iiIi1 [ 'movie_code' ] = oooooo0OO
   iIIIIi1iiIi1 [ 'page' ] = str ( O0oo00o0O + 1 )
   Ii1iIiii1 = '[B]%s >>[/B]' % '다음 페이지'
   O00o0OO0 = str ( O0oo00o0O + 1 )
   self . add_dir ( Ii1iIiii1 , sublabel = O00o0OO0 , img = '' , infoLabels = None , isFolder = True , params = iIIIIi1iiIi1 )
   if 83 - 83: I1ii11iIi11i - I1IiiI + OOooOOo
   if 5 - 5: Ii1I
  if len ( O00oOOooo ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 46 - 46: IiII
  if 45 - 45: ooOoO0o
  if 21 - 21: oO0o . I1Ii111 . OOooOOo / Oo0Ooo / I1Ii111
  if 17 - 17: OOooOOo / OOooOOo / I11i
  if 1 - 1: i1IIi . i11iIiiIii % OOooOOo
  if 82 - 82: iIii1I11I1II1 + Oo0Ooo . iIii1I11I1II1 % IiII / Ii1I . Ii1I
  if 14 - 14: o0oOOo0O0Ooo . OOooOOo . I11i + OoooooooOO - OOooOOo + IiII
 def dp_Search_List ( self , args ) :
  if 9 - 9: Ii1I
  self . WatchaObj . SaveCredential ( self . get_winCredential ( ) )
  if 59 - 59: I1IiiI * II111iiii . O0
  O0oo00o0O = int ( args . get ( 'page' ) )
  if 56 - 56: Ii1I - iII111i % I1IiiI - o0oOOo0O0Ooo
  if 'search_key' in args :
   Oo00O = args . get ( 'search_key' )
  else :
   Oo00O = self . get_keyboard_input ( __language__ ( 30906 ) . encode ( 'utf-8' ) )
   if not Oo00O : return
   if 12 - 12: o0oOOo0O0Ooo - ooOoO0o * I1Ii111
   if 14 - 14: Oo0Ooo - Ii1I % Ii1I * O0 . i11iIiiIii / O0
  O00oOOooo , iI1iIii11Ii = self . WatchaObj . GetSearchList ( Oo00O , O0oo00o0O )
  if len ( O00oOOooo ) == 0 : return
  if 79 - 79: o0oOOo0O0Ooo - I11i + o0oOOo0O0Ooo . oO0o
  if 28 - 28: i1IIi - iII111i
  for I11 in O00oOOooo :
   OoOOoOooooOOo = I11 . get ( 'code' )
   Ii1iIiii1 = I11 . get ( 'title' )
   OO = I11 . get ( 'content_type' )
   o0O0oo0OO0O = I11 . get ( 'story' )
   oo0O0 = I11 . get ( 'thumbnail' )
   OO0 = I11 . get ( 'year' )
   o0Oooo = I11 . get ( 'film_rating_code' )
   iiI = I11 . get ( 'film_rating_short' )
   if 54 - 54: iII111i - O0 % OOooOOo
   if OO == 'movies' :
    oooooOoo0ooo = False
    ii111I = 'MOVIE'
    iiIiIiiiII = ''
    oOo0O = '-'
   else :
    oooooOoo0ooo = True
    ii111I = 'EPISODE'
    iiIiIiiiII = 'Series'
    oOo0O = OoOOoOooooOOo
    if 73 - 73: O0 . OoOoOO00 + I1IiiI - I11i % I11i . I11i
   o0oO000oo = I11 . get ( 'info' )
   o0oO000oo [ 'plot' ] = '%s (%s)\n년도 : %s\n\n%s' % ( Ii1iIiii1 , iiI , OO0 , o0O0oo0OO0O )
   if 17 - 17: Ii1I - OoooooooOO % Ii1I . IiII / i11iIiiIii % iII111i
   if o0Oooo >= 19 :
    Ii1iIiii1 += '  (%s년 - %s)' % ( OO0 , str ( iiI ) )
   else :
    Ii1iIiii1 += '  (%s년)' % ( OO0 )
    if 28 - 28: I11i
   iIIIIi1iiIi1 = { 'mode' : ii111I
 , 'movie_code' : OoOOoOooooOOo
 , 'page' : '1'
 , 'season_code' : oOo0O
   , 'title' : Ii1iIiii1
 , 'thumbnail' : oo0O0
 }
   if 58 - 58: OoOoOO00
   self . add_dir ( Ii1iIiii1 , sublabel = iiIiIiiiII , img = oo0O0 , infoLabels = o0oO000oo , isFolder = oooooOoo0ooo , params = iIIIIi1iiIi1 )
   if 37 - 37: Oo0Ooo - iIii1I11I1II1 / I1ii11iIi11i
   if 73 - 73: i11iIiiIii - IiII
  if iI1iIii11Ii :
   iIIIIi1iiIi1 = { }
   iIIIIi1iiIi1 [ 'mode' ] = 'SEARCH'
   iIIIIi1iiIi1 [ 'search_key' ] = Oo00O
   iIIIIi1iiIi1 [ 'page' ] = str ( O0oo00o0O + 1 )
   Ii1iIiii1 = '[B]%s >>[/B]' % '다음 페이지'
   O00o0OO0 = str ( O0oo00o0O + 1 )
   self . add_dir ( Ii1iIiii1 , sublabel = O00o0OO0 , img = '' , infoLabels = None , isFolder = True , params = iIIIIi1iiIi1 )
   if 25 - 25: OoooooooOO + IiII * I1ii11iIi11i
  if len ( O00oOOooo ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle )
  if 92 - 92: I1IiiI + I11i + O0 / o0oOOo0O0Ooo + I1Ii111
  if 18 - 18: ooOoO0o * OoOoOO00 . iII111i / I1ii11iIi11i / i11iIiiIii
  if 21 - 21: oO0o / I1ii11iIi11i + Ii1I + OoooooooOO
  if 91 - 91: i11iIiiIii / i1IIi + iII111i + ooOoO0o * i11iIiiIii
  if 66 - 66: iIii1I11I1II1 % i1IIi - O0 + I11i * I1Ii111 . IiII
  if 52 - 52: ooOoO0o + O0 . iII111i . I1ii11iIi11i . OoO0O00
 def Delete_Watched_List ( self , stype ) :
  try :
   oo000ii = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % stype ) )
   if 78 - 78: OoooooooOO . OoO0O00 + ooOoO0o - i1IIi
   ii1 = open ( oo000ii , 'w' )
   ii1 . write ( '' )
   ii1 . close ( )
  except :
   None
   if 83 - 83: iII111i . O0 / Oo0Ooo / OOooOOo - II111iiii
   if 100 - 100: OoO0O00
   if 46 - 46: OoOoOO00 / iIii1I11I1II1 % iII111i . iIii1I11I1II1 * iII111i
   if 38 - 38: I1ii11iIi11i - iII111i / O0 . I1Ii111
 def dp_WatchList_Delete ( self , args ) :
  I1Ii = args . get ( 'stype' )
  if 45 - 45: I1Ii111
  i1iIIi1 = xbmcgui . Dialog ( )
  Ooo = i1iIIi1 . yesno ( __language__ ( 30904 ) . encode ( 'utf8' ) , __language__ ( 30905 ) . encode ( 'utf8' ) )
  if Ooo == False : sys . exit ( )
  if 83 - 83: OoOoOO00 . OoooooooOO
  self . Delete_Watched_List ( I1Ii )
  if 58 - 58: i11iIiiIii + OoooooooOO % OoooooooOO / IiII / i11iIiiIii
  xbmc . executebuiltin ( "Container.Refresh" )
  if 62 - 62: OoO0O00 / I1ii11iIi11i
  if 7 - 7: OoooooooOO . IiII
  if 53 - 53: Ii1I % Ii1I * o0oOOo0O0Ooo + OoOoOO00
  if 92 - 92: OoooooooOO + i1IIi / Ii1I * O0
 def Load_Watched_List ( self , stype ) :
  try :
   oo000ii = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % stype ) )
   if 100 - 100: ooOoO0o % iIii1I11I1II1 * II111iiii - iII111i
   ii1 = open ( oo000ii , 'r' )
   oo00O00oO000o = ii1 . readlines ( )
   ii1 . close ( )
  except :
   oo00O00oO000o = [ ]
   if 71 - 71: I1ii11iIi11i - ooOoO0o / OoOoOO00 * OoOoOO00 / i1IIi . i1IIi
  return oo00O00oO000o
  if 53 - 53: I1Ii111
  if 21 - 21: I11i
  if 92 - 92: i11iIiiIii / I1Ii111 - iII111i % ooOoO0o * I1Ii111 + Oo0Ooo
  if 11 - 11: OoooooooOO . I1Ii111
 def Save_Watched_List ( self , stype , in_params ) :
  try :
   oo000ii = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % stype ) )
   Oo0000oOo = self . Load_Watched_List ( stype )
   if 31 - 31: I11i . I1Ii111 * ooOoO0o + i11iIiiIii * oO0o
   if 93 - 93: I1ii11iIi11i / iIii1I11I1II1 * i1IIi % OoooooooOO * O0 * I11i
   ii1 = open ( oo000ii , 'w' )
   Ooooooo = urllib . urlencode ( in_params )
   Ooooooo = Ooooooo + '\n'
   ii1 . write ( Ooooooo )
   if 39 - 39: IiII * Oo0Ooo + iIii1I11I1II1 - IiII + OOooOOo
   o0 = 0
   for iiiI1I1iIIIi1 in Oo0000oOo :
    Iii = dict ( urlparse . parse_qsl ( iiiI1I1iIIIi1 ) )
    if 19 - 19: I11i % II111iiii / i11iIiiIii / iII111i - OoooooooOO
    iIIii = in_params . get ( 'code' ) . strip ( )
    i1 = Iii . get ( 'code' ) . strip ( )
    if stype == 'seasons' and self . get_settings_direct_replay ( ) == True :
     iIIii = in_params . get ( 'videoid' ) . strip ( )
     i1 = Iii . get ( 'videoid' ) . strip ( ) if i1 != None else '-'
     if 31 - 31: OOooOOo + o0oOOo0O0Ooo . OoooooooOO
    if iIIii != i1 :
     ii1 . write ( iiiI1I1iIIIi1 )
     o0 += 1
     if o0 >= 50 : break
   ii1 . close ( )
  except :
   None
   if 89 - 89: II111iiii + i1IIi + II111iiii
   if 7 - 7: O0 % o0oOOo0O0Ooo + I1ii11iIi11i * iII111i - iII111i
   if 42 - 42: OoOoOO00 * OoOoOO00 * I1Ii111 . I11i
   if 51 - 51: OOooOOo % iIii1I11I1II1 - OoooooooOO % ooOoO0o * iIii1I11I1II1 % OoO0O00
   if 99 - 99: oO0o * II111iiii * I1Ii111
 def dp_Watch_List ( self , args ) :
  I1Ii = args . get ( 'stype' )
  oo0 = self . get_settings_direct_replay ( )
  if 92 - 92: Oo0Ooo
  if I1Ii == '-' :
   for iI11I in I1Ii11I1Ii1i :
    Ii1iIiii1 = iI11I . get ( 'title' )
    if 53 - 53: iIii1I11I1II1 + Ii1I - I1Ii111
    iIIIIi1iiIi1 = { 'mode' : iI11I . get ( 'mode' )
 , 'stype' : iI11I . get ( 'stype' )
 }
    if 93 - 93: II111iiii . I1IiiI - Oo0Ooo + OoOoOO00
    self . add_dir ( Ii1iIiii1 , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = iIIIIi1iiIi1 )
   if len ( I1Ii11I1Ii1i ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle )
   if 61 - 61: II111iiii
  else :
   Ii1ii111i1 = self . Load_Watched_List ( I1Ii )
   if 31 - 31: OOooOOo + O0
   for oO0oOOoo00000 in Ii1ii111i1 :
    oOo00 = dict ( urlparse . parse_qsl ( oO0oOOoo00000 ) )
    if 3 - 3: iII111i % i1IIi
    OoOOoOooooOOo = oOo00 . get ( 'code' ) . strip ( )
    Ii1iIiii1 = oOo00 . get ( 'title' ) . strip ( )
    oo0O0 = oOo00 . get ( 'img' ) . strip ( )
    Ii1IIiiIIi = oOo00 . get ( 'videoid' ) . strip ( )
    if 88 - 88: OoooooooOO + I11i * II111iiii % Oo0Ooo
    o0oO000oo = { }
    o0oO000oo [ 'plot' ] = Ii1iIiii1
    if 17 - 17: IiII * OOooOOo - OoO0O00 / i11iIiiIii
    if I1Ii == 'movie' :
     iIIIIi1iiIi1 = { 'mode' : 'MOVIE'
 , 'page' : '1'
 , 'movie_code' : OoOOoOooooOOo
 , 'season_code' : '-'
 , 'title' : Ii1iIiii1
 , 'thumbnail' : oo0O0
 }
     oooooOoo0ooo = False
    else :
     if oo0 == False or Ii1IIiiIIi == None :
      iIIIIi1iiIi1 = { 'mode' : 'EPISODE'
 , 'page' : '1'
 , 'movie_code' : OoOOoOooooOOo
 , 'season_code' : OoOOoOooooOOo
 , 'title' : Ii1iIiii1
 , 'thumbnail' : oo0O0
 }
      oooooOoo0ooo = True
     else :
      iIIIIi1iiIi1 = { 'mode' : 'MOVIE'
 , 'movie_code' : Ii1IIiiIIi
 , 'season_code' : OoOOoOooooOOo
 , 'title' : Ii1iIiii1
 , 'thumbnail' : oo0O0
 }
      oooooOoo0ooo = False
      if 79 - 79: I1Ii111 . oO0o - II111iiii . I1IiiI % ooOoO0o
    self . add_dir ( Ii1iIiii1 , sublabel = '' , img = oo0O0 , infoLabels = o0oO000oo , isFolder = oooooOoo0ooo , params = iIIIIi1iiIi1 )
    if 65 - 65: I1IiiI + OoOoOO00 / OOooOOo
   o0oO000oo = { 'plot' : '시청목록을 삭제합니다.' }
   Ii1iIiii1 = '*** 시청목록 삭제 ***'
   iIIIIi1iiIi1 = { 'mode' : 'MYVIEW_REMOVE'
 , 'stype' : I1Ii
 }
   self . add_dir ( Ii1iIiii1 , sublabel = '' , img = '' , infoLabels = o0oO000oo , isFolder = False , params = iIIIIi1iiIi1 )
   if 83 - 83: o0oOOo0O0Ooo . iII111i - Oo0Ooo
   xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
   if 65 - 65: iIii1I11I1II1 / ooOoO0o . IiII - II111iiii
   if 72 - 72: iIii1I11I1II1 / IiII % iII111i % OOooOOo - I11i % OOooOOo
   if 100 - 100: Oo0Ooo + i11iIiiIii
   if 71 - 71: I11i / o0oOOo0O0Ooo / I1Ii111 % OOooOOo
   if 51 - 51: IiII * O0 / II111iiii . Ii1I % OOooOOo / I1IiiI
 def logout ( self ) :
  i1iIIi1 = xbmcgui . Dialog ( )
  Ooo = i1iIIi1 . yesno ( __language__ ( 30910 ) . encode ( 'utf8' ) , __language__ ( 30905 ) . encode ( 'utf8' ) )
  if Ooo == False : sys . exit ( )
  if 9 - 9: I1IiiI % I1IiiI % II111iiii
  self . wininfo_clear ( )
  if 30 - 30: IiII + I1Ii111 - IiII . IiII - II111iiii + O0
  if 86 - 86: i1IIi
  if os . path . isfile ( Iiii ) : os . remove ( Iiii )
  if 41 - 41: OoOoOO00 * I11i / OoOoOO00 % oO0o
  self . addon_noti ( __language__ ( 30909 ) . encode ( 'utf-8' ) )
  if 18 - 18: II111iiii . OoooooooOO % OoOoOO00 % Ii1I
  if 9 - 9: OoO0O00 - Oo0Ooo * OoooooooOO . Oo0Ooo
  if 2 - 2: OoooooooOO % OOooOOo
  if 63 - 63: I1IiiI % iIii1I11I1II1
 def wininfo_clear ( self ) :
  if 39 - 39: iII111i / II111iiii / I1ii11iIi11i % I1IiiI
  i1II1 = xbmcgui . Window ( 10000 )
  i1II1 . setProperty ( 'WATCHA_M_TOKEN' , '' )
  i1II1 . setProperty ( 'WATCHA_M_GUIT' , '' )
  i1II1 . setProperty ( 'WATCHA_M_GUITV' , '' )
  i1II1 . setProperty ( 'WATCHA_M_USERCD' , '' )
  i1II1 . setProperty ( 'WATCHA_M_LOGINTIME' , '' )
  if 89 - 89: I1Ii111 + OoooooooOO + I1Ii111 * i1IIi + iIii1I11I1II1 % I11i
  if 59 - 59: OOooOOo + i11iIiiIii
  if 88 - 88: i11iIiiIii - ooOoO0o
  if 67 - 67: OOooOOo . Oo0Ooo + OoOoOO00 - OoooooooOO
 def cookiefile_save ( self ) :
  OOOoO = self . WatchaObj . Get_Now_Datetime ( )
  I1i = OOOoO + datetime . timedelta ( days = int ( __addon__ . getSetting ( 'cache_ttl' ) ) )
  if 12 - 12: OoooooooOO
  i1II1 = xbmcgui . Window ( 10000 )
  ii1iiIi1 = { 'watcha_token' : i1II1 . getProperty ( 'WATCHA_M_TOKEN' )
 , 'watcha_guit' : i1II1 . getProperty ( 'WATCHA_M_GUIT' )
 , 'watcha_guitv' : i1II1 . getProperty ( 'WATCHA_M_GUITV' )
 , 'watcha_usercd' : i1II1 . getProperty ( 'WATCHA_M_USERCD' )
 , 'watcha_id' : base64 . standard_b64encode ( __addon__ . getSetting ( 'id' ) . encode ( ) ) . decode ( 'utf-8' )
 , 'watcha_pw' : base64 . standard_b64encode ( __addon__ . getSetting ( 'pw' ) . encode ( ) ) . decode ( 'utf-8' )
 , 'watcha_profile' : __addon__ . getSetting ( 'selected_profile' )
 , 'watcha_limitdate' : I1i . strftime ( '%Y-%m-%d' )
 }
  if 34 - 34: OOooOOo
  try :
   if 91 - 91: iIii1I11I1II1 % o0oOOo0O0Ooo . iIii1I11I1II1 % i1IIi / II111iiii * OoOoOO00
   ii1 = open ( Iiii , 'w' )
   json . dump ( ii1iiIi1 , ii1 )
   ii1 . close ( )
  except Exception as iioo0o0OoOOO :
   print ( iioo0o0OoOOO )
   if 88 - 88: iII111i
   if 19 - 19: II111iiii * IiII + Ii1I
   if 65 - 65: OOooOOo . I1Ii111 . OoO0O00 . iII111i - OOooOOo
   if 19 - 19: i11iIiiIii + iII111i % ooOoO0o
 def cookiefile_check ( self ) :
  if 14 - 14: OoO0O00 . II111iiii . I11i / Ii1I % I1ii11iIi11i - ooOoO0o
  if 67 - 67: I11i - OOooOOo . i1IIi
  ii1iiIi1 = { }
  try :
   if 35 - 35: iII111i + ooOoO0o - oO0o . iII111i . IiII
   ii1 = open ( Iiii , 'r' )
   ii1iiIi1 = json . load ( ii1 )
   ii1 . close ( )
  except Exception as iioo0o0OoOOO :
   self . wininfo_clear ( )
   return False
   if 87 - 87: OoOoOO00
   if 25 - 25: i1IIi . OoO0O00 - OoOoOO00 / OoO0O00 % OoO0O00 * iIii1I11I1II1
   if 50 - 50: OoO0O00 . i11iIiiIii - oO0o . oO0o
  iIIi1i1 = __addon__ . getSetting ( 'id' )
  i1IIIiiII1 = __addon__ . getSetting ( 'pw' )
  I11I = __addon__ . getSetting ( 'selected_profile' )
  ii1iiIi1 [ 'watcha_id' ] = base64 . standard_b64decode ( ii1iiIi1 [ 'watcha_id' ] ) . decode ( 'utf-8' )
  ii1iiIi1 [ 'watcha_pw' ] = base64 . standard_b64decode ( ii1iiIi1 [ 'watcha_pw' ] ) . decode ( 'utf-8' )
  if iIIi1i1 != ii1iiIi1 [ 'watcha_id' ] or i1IIIiiII1 != ii1iiIi1 [ 'watcha_pw' ] or I11I != ii1iiIi1 [ 'watcha_profile' ] :
   self . wininfo_clear ( )
   return False
   if 6 - 6: I1ii11iIi11i + oO0o
   if 48 - 48: iIii1I11I1II1 % i1IIi % iII111i + ooOoO0o
  IIiIiiIi = int ( self . WatchaObj . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' ) )
  Iiii11iIi1 = ii1iiIi1 [ 'watcha_limitdate' ]
  O000oo = int ( re . sub ( '-' , '' , Iiii11iIi1 ) )
  if 40 - 40: I11i % OoO0O00 . I1Ii111
  if 84 - 84: OoOoOO00 % ooOoO0o - OoOoOO00 . o0oOOo0O0Ooo
  if O000oo < IIiIiiIi :
   self . wininfo_clear ( )
   return False
   if 5 - 5: OoOoOO00 * I1Ii111 - I1ii11iIi11i / iIii1I11I1II1 % oO0o + IiII
   if 51 - 51: I1Ii111 * II111iiii % ooOoO0o
  i1II1 = xbmcgui . Window ( 10000 )
  i1II1 . setProperty ( 'WATCHA_M_TOKEN' , ii1iiIi1 [ 'watcha_token' ] )
  i1II1 . setProperty ( 'WATCHA_M_GUIT' , ii1iiIi1 [ 'watcha_guit' ] )
  i1II1 . setProperty ( 'WATCHA_M_GUITV' , ii1iiIi1 [ 'watcha_guitv' ] )
  i1II1 . setProperty ( 'WATCHA_M_USERCD' , ii1iiIi1 [ 'watcha_usercd' ] )
  i1II1 . setProperty ( 'WATCHA_M_LOGINTIME' , Iiii11iIi1 )
  if 98 - 98: OoO0O00 . I11i % II111iiii
  return True
  if 71 - 71: I1Ii111 % i1IIi - II111iiii - OOooOOo + OOooOOo * ooOoO0o
  if 51 - 51: iIii1I11I1II1 / OoOoOO00 + OOooOOo - I11i + iII111i
  if 29 - 29: o0oOOo0O0Ooo % iIii1I11I1II1 . OoooooooOO % OoooooooOO % II111iiii / iII111i
  if 70 - 70: i11iIiiIii % iII111i
 def watcha_main ( self ) :
  I11Ii11iI1 = self . main_params . get ( 'mode' , None )
  if 39 - 39: I1IiiI * i11iIiiIii - oO0o / IiII % I1Ii111 % I11i
  if 65 - 65: oO0o - ooOoO0o % OoooooooOO / OoooooooOO % OoooooooOO
  if I11Ii11iI1 == 'LOGOUT' :
   self . logout ( )
   return
   if 52 - 52: I1ii11iIi11i + I1ii11iIi11i . II111iiii
  self . login_main ( )
  if 34 - 34: OoooooooOO . O0 / oO0o * OoOoOO00 - I1ii11iIi11i
  if I11Ii11iI1 is None :
   self . dp_Main_List ( )
   if 36 - 36: i1IIi / O0 / OoO0O00 - O0 - i1IIi
  elif I11Ii11iI1 == 'SUB_GROUP' :
   self . dp_SubGroup_List ( self . main_params )
   if 22 - 22: i1IIi + Ii1I
  elif I11Ii11iI1 == 'CATEGORY_LIST' :
   self . dp_Category_List ( self . main_params )
   if 54 - 54: ooOoO0o % OOooOOo . I1Ii111 + oO0o - OOooOOo * I1IiiI
  elif I11Ii11iI1 == 'EPISODE' :
   self . dp_Episode_List ( self . main_params )
   if 92 - 92: o0oOOo0O0Ooo + I1Ii111 / Oo0Ooo % OoO0O00 % IiII . OoooooooOO
  elif I11Ii11iI1 == 'ORDER_BY' :
   self . dp_setEpOrderby ( self . main_params )
   if 52 - 52: ooOoO0o / i11iIiiIii - OOooOOo . IiII % iIii1I11I1II1 + o0oOOo0O0Ooo
  elif I11Ii11iI1 == 'SEARCH' :
   self . dp_Search_List ( self . main_params )
   if 71 - 71: oO0o % I11i * OoOoOO00 . O0 / Ii1I . I1ii11iIi11i
  elif I11Ii11iI1 == 'MOVIE' :
   if 58 - 58: Oo0Ooo / oO0o
   self . play_VIDEO ( self . main_params )
   if 44 - 44: OOooOOo
  elif I11Ii11iI1 == 'WATCH' :
   self . dp_Watch_List ( self . main_params )
   if 54 - 54: Ii1I - I11i - I1Ii111 . iIii1I11I1II1
  elif I11Ii11iI1 == 'MYVIEW_REMOVE' :
   self . dp_WatchList_Delete ( self . main_params )
   if 79 - 79: Ii1I . OoO0O00
   if 40 - 40: o0oOOo0O0Ooo + Oo0Ooo . o0oOOo0O0Ooo % ooOoO0o
   if 15 - 15: Ii1I * Oo0Ooo % I1ii11iIi11i * iIii1I11I1II1 - i11iIiiIii
   if 60 - 60: I1IiiI * I1Ii111 % OoO0O00 + oO0o
  else :
   None
   if 52 - 52: i1IIi
   if 84 - 84: Ii1I / IiII
   if 86 - 86: OoOoOO00 * II111iiii - O0 . OoOoOO00 % iIii1I11I1II1 / OOooOOo
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
