# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import urllib
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
import re
import json
import sys
import time
import base64
import requests
import datetime
if 73 - 73: II111iiii
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
IiiIII111iI = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . OoO0O00 - I1ii11iIi11i
if 53 - 53: I11i / Oo0Ooo / II111iiii % Ii1I / OoOoOO00 . Oo0ooO0oo0oO
if 100 - 100: i1IIi
class xI1Ii11I1Ii1i ( object ) :
 def __init__ ( self ) :
  self . WATCHA_TOKEN = ''
  self . WATCHA_GUIT = ''
  self . WATCHA_GUITV = ''
  self . WATCHA_USERCD = ''
  self . API_DOMAIN = 'https://play.watcha.net'
  self . EPISODE_LIMIT = 20
  self . SEARCH_LIMIT = 30
  if 67 - 67: iIii1I11I1II1 . I1ii11iIi11i . oO0o / i1IIi % II111iiii - OoOoOO00
  self . DEFAULT_HEADER = { 'user-agent' : IiiIII111iI
 , 'x-watchaplay-client' : 'WatchaPlay-WebApp'
 , 'x-watchaplay-client-language' : 'ko'
 , 'x-watchaplay-client-region' : 'KR'
 , 'x-watchaplay-client-version' : '1.0.0'
 }
  if 91 - 91: OoO0O00 . i11iIiiIii / oO0o % I11i / OoO0O00 - i11iIiiIii
  if 8 - 8: o0oOOo0O0Ooo * I1ii11iIi11i * iIii1I11I1II1 . O00oOoOoO0o0O / O00oOoOoO0o0O % O00oOoOoO0o0O
 def callRequestCookies ( self , jobtype , url , payload = None , params = None , headers = None , cookies = None , redirects = False ) :
  i11 = self . DEFAULT_HEADER
  if headers : i11 . update ( headers )
  if 41 - 41: O0oo0OO0 . Oo0ooO0oo0oO * O00oOoOoO0o0O % i11iIiiIii
  if jobtype == 'Get' :
   o000o0o00o0Oo = requests . get ( url , params = params , headers = i11 , cookies = cookies , allow_redirects = redirects )
  elif jobtype == 'Put' :
   o000o0o00o0Oo = requests . put ( url , data = payload , params = params , headers = i11 , cookies = cookies , allow_redirects = redirects )
  else :
   o000o0o00o0Oo = requests . post ( url , data = payload , params = params , headers = i11 , cookies = cookies , allow_redirects = redirects )
   if 80 - 80: OoooooooOO . I1IiiI
  return o000o0o00o0Oo
  if 87 - 87: oO0o / Oo0ooO0oo0oO + O0oo0OO0 - Oo0ooO0oo0oO . Oo0ooO0oo0oO / II111iiii
  if 11 - 11: I1IiiI % o0oOOo0O0Ooo - Oo0Ooo
 def SaveCredential ( self , login_params ) :
  self . WATCHA_TOKEN = login_params . get ( 'watcha_token' )
  self . WATCHA_GUIT = login_params . get ( 'watcha_guit' )
  self . WATCHA_GUITV = login_params . get ( 'watcha_guitv' )
  self . WATCHA_USERCD = login_params . get ( 'watcha_usercd' )
  if 58 - 58: i11iIiiIii % O0oo0OO0
 def SaveCredential_usercd ( self , usercd ) :
  self . WATCHA_USERCD = usercd
  if 54 - 54: OOooOOo % O0 + I1IiiI - iii1I1I / I11i
 def SaveCredential_guitv ( self , guitv , token ) :
  self . WATCHA_GUITV = guitv
  self . WATCHA_TOKEN = token
  if 31 - 31: OoO0O00 + II111iiii
 def ClearCredential ( self ) :
  self . WATCHA_TOKEN = ''
  self . WATCHA_GUIT = ''
  self . WATCHA_GUITV = ''
  self . WATCHA_USERCD = ''
  if 13 - 13: OOooOOo * oO0o * I1IiiI
  if 55 - 55: II111iiii
 def LoadCredential ( self ) :
  IIIiI11ii = {
 'watcha_token' : self . WATCHA_TOKEN
 , 'watcha_guit' : self . WATCHA_GUIT
 , 'watcha_guitv' : self . WATCHA_GUITV
 , 'watcha_usercd' : self . WATCHA_USERCD
 }
  return IIIiI11ii
  if 52 - 52: iii1I1I + OOooOOo % OoooooooOO / i11iIiiIii
 def makeDefaultCookies ( self ) :
  iiIIi1IiIi11 = {
 '_s_guit' : self . WATCHA_GUIT
 , '_guinness-premium_session' : self . WATCHA_TOKEN
 }
  if self . WATCHA_GUITV :
   iiIIi1IiIi11 [ '_s_guitv' ] = self . WATCHA_GUITV
  return iiIIi1IiIi11
  if 11 - 11: Oo0ooO0oo0oO / O0 - i1IIi
  if 85 - 85: OOooOOo % I1ii11iIi11i * Oo0ooO0oo0oO
 def makeurl ( self , domain , path , query1 = None , query2 = None ) :
  OO0O00OooO = domain + path
  if query1 :
   OO0O00OooO += '?%s' % urllib . urlencode ( query1 )
  if query2 :
   OO0O00OooO += '&%s' % urllib . urlencode ( query2 )
  return OO0O00OooO
  if 77 - 77: II111iiii - II111iiii . I1IiiI / o0oOOo0O0Ooo
  if 14 - 14: I11i % O0
 def GetCredential ( self , user_id , user_pw , user_pf ) :
  IiI1I1 = False
  OoO000 = IIiiIiI1 = '-'
  if 41 - 41: OoOoOO00
  if 13 - 13: Oo0Ooo . i11iIiiIii - iIii1I11I1II1 - OoOoOO00
  try :
   ii1I = self . API_DOMAIN + '/api/session'
   if 76 - 76: O0 / o0oOOo0O0Ooo . I1IiiI * Ii1I - OOooOOo
   Oooo = { 'email' : user_id
 , 'password' : user_pw
 }
   if 67 - 67: OOooOOo / OoooooooOO % I11i - iIii1I11I1II1
   Ooo = { 'accept' : 'application/vnd.frograms+json;version=4' }
   O0o0Oo = self . callRequestCookies ( 'Post' , ii1I , payload = Oooo , params = None , headers = Ooo , cookies = None )
   if 78 - 78: iIii1I11I1II1 - Ii1I * OoO0O00 + o0oOOo0O0Ooo + iii1I1I + iii1I1I
   if 11 - 11: iii1I1I - OoO0O00 % Oo0ooO0oo0oO % iii1I1I / OoOoOO00 - OoO0O00
   if 74 - 74: iii1I1I * O0
   for oOOo0oo in O0o0Oo . cookies :
    if oOOo0oo . name == '_guinness-premium_session' :
     IIiiIiI1 = oOOo0oo . value
    elif oOOo0oo . name == '_s_guit' :
     OoO000 = oOOo0oo . value
     if 80 - 80: I11i * i11iIiiIii / O0oo0OO0
   if IIiiIiI1 : IiI1I1 = True
   if 9 - 9: Ii1I + oO0o % Ii1I + i1IIi . OOooOOo
  except Exception as III1i1i :
   print ( III1i1i )
   OoO000 = IIiiIiI1 = ''
   if 26 - 26: OoooooooOO
   if 12 - 12: OoooooooOO % OoOoOO00 / Oo0ooO0oo0oO % o0oOOo0O0Ooo
  IIIiI11ii = {
 'watcha_guit' : OoO000
 , 'watcha_token' : IIiiIiI1
 , 'watcha_guitv' : ''
 , 'watcha_usercd' : ''
 }
  self . SaveCredential ( IIIiI11ii )
  if 29 - 29: OoooooooOO
  if 23 - 23: o0oOOo0O0Ooo . II111iiii
  if 98 - 98: iIii1I11I1II1 % OoOoOO00 * I1ii11iIi11i * OoOoOO00
  if 45 - 45: O0oo0OO0 . OoOoOO00
  try :
   oO = self . GetProfilesList ( )
   if 6 - 6: I1ii11iIi11i
   I1I = oO [ user_pf ]
   self . SaveCredential_usercd ( I1I )
   if 80 - 80: OoOoOO00 - OoO0O00
  except Exception as III1i1i :
   print ( III1i1i )
   self . ClearCredential ( )
   return False
   if 87 - 87: oO0o / I11i - i1IIi * OOooOOo / OoooooooOO . O0
   if 1 - 1: II111iiii - I11i / I11i
   if 46 - 46: Ii1I * OOooOOo - OoO0O00 * oO0o - O0oo0OO0
  if user_pf != 0 :
   oo0 , o00 = self . GetProfilesConvert ( I1I )
   self . SaveCredential_guitv ( oo0 , o00 )
   if 95 - 95: O0 + OoO0O00 . II111iiii / O0
  return IiI1I1
  if 97 - 97: Oo0ooO0oo0oO - OOooOOo * i11iIiiIii / OoOoOO00 % O0oo0OO0 - OoooooooOO
  if 59 - 59: O0 + I1IiiI + O00oOoOoO0o0O % I1IiiI
 def GetSubGroupList ( self , stype ) :
  o0OOoo0OO0OOO = [ ]
  if 19 - 19: oO0o % i1IIi % o0oOOo0O0Ooo
  try :
   oo0OooOOo0 = '/api/categories.json'
   if 92 - 92: iii1I1I . I11i + o0oOOo0O0Ooo
   OO0O00OooO = self . makeurl ( self . API_DOMAIN , oo0OooOOo0 )
   if 28 - 28: i1IIi * Oo0Ooo - o0oOOo0O0Ooo * O00oOoOoO0o0O * Ii1I / OoO0O00
   oOOo0oo = self . makeDefaultCookies ( )
   O0o0Oo = self . callRequestCookies ( 'Get' , OO0O00OooO , payload = None , params = None , headers = None , cookies = oOOo0oo )
   OooO0OoOOOO = json . loads ( O0o0Oo . text )
   if 46 - 46: OOooOOo / I1ii11iIi11i
   if 24 - 24: I11i . iii1I1I % OOooOOo + Oo0ooO0oo0oO % OoOoOO00
   if not ( 'genres' in OooO0OoOOOO ) : return o0OOoo0OO0OOO
   if stype == 'genres' :
    I11III1II = OooO0OoOOOO [ 'genres' ]
   else :
    I11III1II = OooO0OoOOOO [ 'tags' ]
    if 16 - 16: I1IiiI * oO0o % O00oOoOoO0o0O
    if 86 - 86: I1IiiI + Ii1I % i11iIiiIii * oO0o . Oo0ooO0oo0oO * I11i
   for i1I11i1iI in I11III1II :
    I1ii1Ii1 = i1I11i1iI [ 'name' ]
    iii11 = i1I11i1iI [ 'api_path' ]
    oOOOOo0 = i1I11i1iI [ 'entity' ] [ 'id' ]
    if 20 - 20: i1IIi + I1ii11iIi11i - Oo0ooO0oo0oO
    IiI11iII1 = { 'group_name' : I1ii1Ii1
 , 'api_path' : iii11
 , 'tag_id' : str ( oOOOOo0 )
 }
    o0OOoo0OO0OOO . append ( IiI11iII1 )
    if 29 - 29: Oo0Ooo - oO0o - I11i % iii1I1I - oO0o
    if 91 - 91: OoO0O00 / I11i - II111iiii . I11i
  except Exception as III1i1i :
   print ( III1i1i )
   if 18 - 18: o0oOOo0O0Ooo
  return o0OOoo0OO0OOO
  if 98 - 98: iii1I1I * iii1I1I / iii1I1I + I11i
  if 34 - 34: Oo0ooO0oo0oO
  if 15 - 15: I11i * Oo0ooO0oo0oO * Oo0Ooo % i11iIiiIii % OoOoOO00 - OOooOOo
 def GetCategoryList ( self , stype , tag_id , api_path , page_int , in_sort ) :
  o0OOoo0OO0OOO = [ ]
  O0ooo0O0oo0 = False
  oo0oOo = { }
  if 89 - 89: OoOoOO00
  try :
   if 'categories' in api_path :
    oo0OooOOo0 = '/api/categories/contents.json'
    if 68 - 68: OoO0O00 * OoooooooOO % O0 + OoO0O00 + Oo0ooO0oo0oO
    if stype == 'genres' :
     oo0oOo [ 'genre' ] = tag_id
    else :
     oo0oOo [ 'tag' ] = tag_id
     if 4 - 4: Oo0ooO0oo0oO + O0 * OOooOOo
    oo0oOo [ 'order' ] = in_sort
    if page_int > 1 :
     oo0oOo [ 'page' ] = str ( page_int - 1 )
     if 55 - 55: Oo0Ooo + iIii1I11I1II1 / OoOoOO00 * oO0o - i11iIiiIii - Ii1I
   else :
    oo0OooOOo0 = '/api/' + api_path + '.json'
    if 25 - 25: I1ii11iIi11i
    if page_int > 1 :
     oo0oOo [ 'page' ] = str ( page_int )
     if 7 - 7: i1IIi / I1IiiI * O0oo0OO0 . O00oOoOoO0o0O . iIii1I11I1II1
   OO0O00OooO = self . makeurl ( self . API_DOMAIN , oo0OooOOo0 )
   if 13 - 13: OOooOOo / i11iIiiIii
   oOOo0oo = self . makeDefaultCookies ( )
   O0o0Oo = self . callRequestCookies ( 'Get' , OO0O00OooO , payload = None , params = oo0oOo , headers = None , cookies = oOOo0oo )
   OooO0OoOOOO = json . loads ( O0o0Oo . text )
   if 2 - 2: I1IiiI / O0 / o0oOOo0O0Ooo % OoOoOO00 % Ii1I
   if 52 - 52: o0oOOo0O0Ooo
   if not ( 'contents' in OooO0OoOOOO ) : return o0OOoo0OO0OOO , O0ooo0O0oo0
   I11III1II = OooO0OoOOOO [ 'contents' ]
   O0ooo0O0oo0 = OooO0OoOOOO [ 'meta' ] [ 'has_next' ]
   if 95 - 95: Ii1I
   for i1I11i1iI in I11III1II :
    O0oOO0O = i1I11i1iI [ 'code' ]
    oOiIi1IIIi1 = i1I11i1iI [ 'content_type' ]
    O0oOoOOOoOO = i1I11i1iI [ 'title' ]
    ii1ii11IIIiiI = i1I11i1iI [ 'story' ]
    if i1I11i1iI [ 'thumbnail' ] != None :
     O00OOOoOoo0O = i1I11i1iI [ 'thumbnail' ] [ 'medium' ]
    else :
     O00OOOoOoo0O = i1I11i1iI [ 'stillcut' ] [ 'medium' ]
    O000OOo00oo = i1I11i1iI [ 'year' ]
    oo0OOo = i1I11i1iI [ 'film_rating_code' ]
    ooOOO00Ooo = i1I11i1iI [ 'film_rating_short' ]
    if 16 - 16: II111iiii % OoOoOO00 - II111iiii + Ii1I
    if 12 - 12: OOooOOo / OOooOOo + i11iIiiIii
    Ii = { }
    Ii [ 'mpaa' ] = i1I11i1iI [ 'film_rating_long' ]
    Ii [ 'year' ] = i1I11i1iI [ 'year' ]
    Ii [ 'title' ] = i1I11i1iI [ 'title' ]
    if 22 - 22: II111iiii
    if oOiIi1IIIi1 == 'movies' :
     Ii [ 'mediatype' ] = 'movie'
     Ii [ 'duration' ] = i1I11i1iI [ 'duration' ]
    else :
     Ii [ 'mediatype' ] = 'episode'
     if 33 - 33: I11i
     if 18 - 18: o0oOOo0O0Ooo % iii1I1I * O0
    IiI11iII1 = { 'code' : O0oOO0O
 , 'content_type' : oOiIi1IIIi1
 , 'title' : O0oOoOOOoOO
 , 'story' : ii1ii11IIIiiI
 , 'thumbnail' : O00OOOoOoo0O
 , 'year' : O000OOo00oo
 , 'film_rating_code' : oo0OOo
 , 'film_rating_short' : ooOOO00Ooo
 , 'info' : Ii
 }
    o0OOoo0OO0OOO . append ( IiI11iII1 )
    if 87 - 87: i11iIiiIii
    if 93 - 93: I1ii11iIi11i - OoO0O00 % i11iIiiIii . iii1I1I / iii1I1I - O0oo0OO0
  except Exception as III1i1i :
   print ( III1i1i )
   if 9 - 9: I1ii11iIi11i / Oo0Ooo - I1IiiI / OoooooooOO / iIii1I11I1II1 - o0oOOo0O0Ooo
  return o0OOoo0OO0OOO , O0ooo0O0oo0
  if 91 - 91: iii1I1I % i1IIi % iIii1I11I1II1
  if 20 - 20: OOooOOo % Ii1I / Ii1I + Ii1I
 def GetCategoryList_morepage ( self , stype , tag_id , api_path , page_int , in_sort ) :
  O0ooo0O0oo0 = False
  if 45 - 45: oO0o - O00oOoOoO0o0O - OoooooooOO - OoO0O00 . II111iiii / O0
  if not ( 'categories' in api_path ) : return True
  if 51 - 51: O0 + iii1I1I
  try :
   oo0OooOOo0 = '/api/categories/contents.json'
   if 8 - 8: oO0o * OoOoOO00 - Ii1I - OoO0O00 * OOooOOo % I1IiiI
   oo0oOo = { }
   if stype == 'genres' :
    oo0oOo [ 'genre' ] = tag_id
   else :
    oo0oOo [ 'tag' ] = tag_id
    if 48 - 48: O0
   oo0oOo [ 'order' ] = in_sort
   if page_int > 1 :
    oo0oOo [ 'page' ] = str ( page_int - 1 )
    if 11 - 11: I11i + OoooooooOO - OoO0O00 / o0oOOo0O0Ooo + Oo0Ooo . II111iiii
   OO0O00OooO = self . makeurl ( self . API_DOMAIN , oo0OooOOo0 )
   oOOo0oo = self . makeDefaultCookies ( )
   O0o0Oo = self . callRequestCookies ( 'Get' , OO0O00OooO , payload = None , params = oo0oOo , headers = None , cookies = oOOo0oo )
   OooO0OoOOOO = json . loads ( O0o0Oo . text )
   if 41 - 41: Ii1I - O0 - O0
   if 68 - 68: OOooOOo % O0oo0OO0
   O0ooo0O0oo0 = OooO0OoOOOO [ 'meta' ] [ 'has_next' ]
   if 88 - 88: iIii1I11I1II1 - Oo0ooO0oo0oO + OOooOOo
  except Exception as III1i1i :
   print ( III1i1i )
   if 40 - 40: I1IiiI * Ii1I + OOooOOo % iii1I1I
  return O0ooo0O0oo0
  if 74 - 74: oO0o - Oo0Ooo + OoooooooOO + O0oo0OO0 / OoOoOO00
  if 23 - 23: O0
  if 85 - 85: Ii1I
 def GetEpisodoList ( self , program_code , page_int , orderby = 'asc' ) :
  o0OOoo0OO0OOO = [ ]
  O0ooo0O0oo0 = False
  OO = ''
  if 77 - 77: Oo0Ooo
  if 17 - 17: iii1I1I % OoO0O00 . OOooOOo + OoO0O00 / II111iiii
  try :
   oo0OooOOo0 = '/api/contents/' + program_code + '/tv_episodes.json'
   oo0oOo = { 'all' : 'true' }
   if 75 - 75: I1IiiI - OoOoOO00 % iii1I1I
   OO0O00OooO = self . makeurl ( self . API_DOMAIN , oo0OooOOo0 )
   oOOo0oo = self . makeDefaultCookies ( )
   O0o0Oo = self . callRequestCookies ( 'Get' , OO0O00OooO , payload = None , params = oo0oOo , headers = None , cookies = oOOo0oo )
   OooO0OoOOOO = json . loads ( O0o0Oo . text )
   if 37 - 37: OoOoOO00 * Oo0Ooo / Oo0ooO0oo0oO - iii1I1I % II111iiii . oO0o
   if 88 - 88: iii1I1I . II111iiii * II111iiii % O0oo0OO0
   if not ( 'tv_episode_codes' in OooO0OoOOOO ) : return o0OOoo0OO0OOO , O0ooo0O0oo0
   I11III1II = OooO0OoOOOO [ 'tv_episode_codes' ]
   if 15 - 15: i1IIi * I1IiiI + i11iIiiIii
   I1Ii = len ( I11III1II )
   O0oo00o0O = int ( I1Ii // ( self . EPISODE_LIMIT + 1 ) ) + 1
   if 1 - 1: II111iiii
   if orderby == 'desc' :
    OOooooO0Oo = ( I1Ii - 1 ) - ( ( page_int - 1 ) * self . EPISODE_LIMIT )
   else :
    OOooooO0Oo = ( page_int - 1 ) * self . EPISODE_LIMIT
    if 91 - 91: o0oOOo0O0Ooo . iIii1I11I1II1 / oO0o + i1IIi
   for I1i in range ( self . EPISODE_LIMIT ) :
    if orderby == 'desc' :
     OOOOO0oo0O0O0 = OOooooO0Oo - I1i
     if OOOOO0oo0O0O0 < 0 : break
    else :
     OOOOO0oo0O0O0 = OOooooO0Oo + I1i
     if OOOOO0oo0O0O0 >= I1Ii : break
     if 74 - 74: o0oOOo0O0Ooo . iii1I1I
    if OO != '' : OO += ','
    OO += I11III1II [ OOOOO0oo0O0O0 ]
    if 18 - 18: OOooOOo + iii1I1I - Ii1I . II111iiii + i11iIiiIii
   if O0oo00o0O > page_int : O0ooo0O0oo0 = True
   if 20 - 20: O0oo0OO0
  except Exception as III1i1i :
   print ( III1i1i )
   if 52 - 52: II111iiii - OoooooooOO % Ii1I + I1IiiI * Oo0Ooo . O00oOoOoO0o0O
   if 75 - 75: Oo0ooO0oo0oO + OoOoOO00 + o0oOOo0O0Ooo * I11i % oO0o . iii1I1I
   if 55 - 55: OOooOOo . I1IiiI
  try :
   if 61 - 61: Oo0Ooo % O00oOoOoO0o0O . Oo0Ooo
   oo0oOo = { 'codes' : OO }
   if 100 - 100: O0oo0OO0 * O0
   if 64 - 64: OOooOOo % iIii1I11I1II1 * oO0o
   OO0O00OooO = self . makeurl ( self . API_DOMAIN , oo0OooOOo0 )
   oOOo0oo = self . makeDefaultCookies ( )
   O0o0Oo = self . callRequestCookies ( 'Get' , OO0O00OooO , payload = None , params = oo0oOo , headers = None , cookies = oOOo0oo )
   OooO0OoOOOO = json . loads ( O0o0Oo . text )
   if 79 - 79: O0
   if 78 - 78: I1ii11iIi11i + OOooOOo - O0oo0OO0
   if not ( 'tv_episodes' in OooO0OoOOOO ) : return o0OOoo0OO0OOO
   if 38 - 38: o0oOOo0O0Ooo - oO0o + iIii1I11I1II1 / OoOoOO00 % Oo0Ooo
   I11III1II = OooO0OoOOOO [ 'tv_episodes' ]
   if 57 - 57: OoO0O00 / Oo0ooO0oo0oO
   for i1I11i1iI in I11III1II :
    O0oOO0O = i1I11i1iI [ 'code' ]
    if 29 - 29: iIii1I11I1II1 + OoOoOO00 * OoO0O00 * OOooOOo . I1IiiI * I1IiiI
    if 7 - 7: O00oOoOoO0o0O * O0oo0OO0 % Ii1I - o0oOOo0O0Ooo
    if i1I11i1iI [ 'title' ] :
     O0oOoOOOoOO = i1I11i1iI [ 'title' ]
    else :
     O0oOoOOOoOO = ''
    O00OOOoOoo0O = i1I11i1iI [ 'stillcut' ] [ 'medium' ]
    i1i = i1I11i1iI [ 'display_number' ]
    oOOoo00O00o = i1I11i1iI [ 'tv_season_title' ]
    if 98 - 98: OOooOOo + O00oOoOoO0o0O + oO0o % OoooooooOO
    if 97 - 97: O0 * OoooooooOO . OoooooooOO
    Ii = { }
    Ii [ 'mediatype' ] = 'episode'
    Ii [ 'tvshowtitle' ] = O0oOoOOOoOO if O0oOoOOOoOO else oOOoo00O00o
    Ii [ 'title' ] = '%s %s' % ( oOOoo00O00o , i1i ) if O0oOoOOOoOO else i1i
    Ii [ 'duration' ] = i1I11i1iI [ 'duration' ]
    try :
     if 33 - 33: O0oo0OO0 + iii1I1I * oO0o / iIii1I11I1II1 - I1IiiI
     Ii [ 'episode' ] = i1I11i1iI [ 'episode_number' ]
    except :
     None
     if 54 - 54: O0oo0OO0 / OOooOOo . oO0o % iii1I1I
    IiI11iII1 = { 'code' : O0oOO0O

    # i11iIiiIii % oO0o . OOooOOo - Ii1I
    , 'title' : O0oOoOOOoOO
 , 'thumbnail' : O00OOOoOoo0O
 , 'display_num' : i1i
 , 'season_title' : oOOoo00O00o

    , 'info' : Ii
 }
    if 42 - 42: oO0o + Oo0ooO0oo0oO / iii1I1I + OOooOOo
    o0OOoo0OO0OOO . append ( IiI11iII1 )
    if 30 - 30: O0
  except Exception as III1i1i :
   print ( III1i1i )
   if 44 - 44: oO0o / I11i / I11i
   if 87 - 87: Oo0Ooo . I1IiiI - II111iiii + O0 / Oo0Ooo / oO0o
  return o0OOoo0OO0OOO , O0ooo0O0oo0
  if 25 - 25: I1IiiI . I1IiiI - OoOoOO00 % OoOoOO00 - i11iIiiIii / O0oo0OO0
  if 51 - 51: Oo0Ooo / OoOoOO00 . OOooOOo * o0oOOo0O0Ooo + OoO0O00 * O00oOoOoO0o0O
  if 73 - 73: OoO0O00 + OoooooooOO - O0 - Ii1I - II111iiii
 def GetSearchList ( self , search_key , page_int ) :
  O0O = [ ]
  O0ooo0O0oo0 = False
  if 80 - 80: Ii1I * o0oOOo0O0Ooo / o0oOOo0O0Ooo
  try :
   oo0OooOOo0 = '/api/search.json'
   if 5 - 5: I1IiiI
   oo0oOo = { 'query' : search_key
 , 'page' : str ( page_int )
 , 'per' : str ( self . SEARCH_LIMIT )
 , 'exclude' : 'limited'
 }
   if 48 - 48: o0oOOo0O0Ooo - oO0o / OoooooooOO
   OO0O00OooO = self . makeurl ( self . API_DOMAIN , oo0OooOOo0 )
   oOOo0oo = self . makeDefaultCookies ( )
   O0o0Oo = self . callRequestCookies ( 'Get' , OO0O00OooO , payload = None , params = oo0oOo , headers = None , cookies = oOOo0oo )
   OooO0OoOOOO = json . loads ( O0o0Oo . text )
   if 100 - 100: I1IiiI / o0oOOo0O0Ooo % II111iiii % Oo0Ooo % OOooOOo
   if 98 - 98: I11i % i11iIiiIii % Oo0ooO0oo0oO + Ii1I
   if not ( 'results' in OooO0OoOOOO ) : return O0O , O0ooo0O0oo0
   I11III1II = OooO0OoOOOO [ 'results' ]
   O0ooo0O0oo0 = OooO0OoOOOO [ 'meta' ] [ 'has_next' ]
   if 78 - 78: I1ii11iIi11i % oO0o / iii1I1I - iIii1I11I1II1
   for i1I11i1iI in I11III1II :
    O0oOO0O = i1I11i1iI [ 'code' ]
    oOiIi1IIIi1 = i1I11i1iI [ 'content_type' ]
    O0oOoOOOoOO = i1I11i1iI [ 'title' ]
    ii1ii11IIIiiI = i1I11i1iI [ 'story' ]
    if i1I11i1iI [ 'thumbnail' ] != None :
     O00OOOoOoo0O = i1I11i1iI [ 'thumbnail' ] [ 'medium' ]
    else :
     O00OOOoOoo0O = i1I11i1iI [ 'stillcut' ] [ 'medium' ]
    O000OOo00oo = i1I11i1iI [ 'year' ]
    oo0OOo = i1I11i1iI [ 'film_rating_code' ]
    ooOOO00Ooo = i1I11i1iI [ 'film_rating_short' ]
    if 69 - 69: O0oo0OO0
    if 11 - 11: I1IiiI
    Ii = { }
    Ii [ 'mpaa' ] = i1I11i1iI [ 'film_rating_long' ]
    Ii [ 'year' ] = i1I11i1iI [ 'year' ]
    Ii [ 'title' ] = i1I11i1iI [ 'title' ]
    if 16 - 16: Ii1I + O00oOoOoO0o0O * O0 % i1IIi . I1IiiI
    if oOiIi1IIIi1 == 'movies' :
     Ii [ 'mediatype' ] = 'movie'
     Ii [ 'duration' ] = i1I11i1iI [ 'duration' ]
    else :
     Ii [ 'mediatype' ] = 'episode'
     if 67 - 67: OoooooooOO / I1IiiI * Ii1I + I11i
     if 65 - 65: OoooooooOO - I1ii11iIi11i / Oo0ooO0oo0oO / II111iiii / i1IIi
    IiI11iII1 = { 'code' : O0oOO0O
 , 'content_type' : oOiIi1IIIi1
 , 'title' : O0oOoOOOoOO
 , 'story' : ii1ii11IIIiiI
 , 'thumbnail' : O00OOOoOoo0O
 , 'year' : O000OOo00oo
 , 'film_rating_code' : oo0OOo
 , 'film_rating_short' : ooOOO00Ooo
 , 'info' : Ii
 }
    O0O . append ( IiI11iII1 )
    if 71 - 71: O0oo0OO0 + Ii1I
    if 28 - 28: OOooOOo
  except Exception as III1i1i :
   print ( III1i1i )
   if 38 - 38: Oo0ooO0oo0oO % II111iiii % I11i / OoO0O00 + OoOoOO00 / i1IIi
  return O0O , O0ooo0O0oo0
  if 54 - 54: iIii1I11I1II1 % I1ii11iIi11i - OOooOOo / oO0o - OoO0O00 . I11i
  if 11 - 11: I1ii11iIi11i . OoO0O00 * O00oOoOoO0o0O * OoooooooOO + Oo0ooO0oo0oO
 def GetProfilesList ( self ) :
  oO = [ ]
  if 33 - 33: O0 * o0oOOo0O0Ooo - O0oo0OO0 % O0oo0OO0
  try :
   oo0OooOOo0 = '/manage_profiles'
   OO0O00OooO = self . makeurl ( self . API_DOMAIN , oo0OooOOo0 )
   if 18 - 18: O0oo0OO0 / Oo0Ooo * O0oo0OO0 + O0oo0OO0 * i11iIiiIii * I1ii11iIi11i
   oOOo0oo = self . makeDefaultCookies ( )
   O0o0Oo = self . callRequestCookies ( 'Get' , OO0O00OooO , payload = None , params = None , headers = None , cookies = oOOo0oo , redirects = True )
   I1II1 = O0o0Oo . text
   if 86 - 86: iIii1I11I1II1 / OoOoOO00 . II111iiii
   if 19 - 19: I1ii11iIi11i % OoooooooOO % O00oOoOoO0o0O * o0oOOo0O0Ooo % O0
   ooo = re . findall ( '/api/users/me.{5000}' , I1II1 ) [ 0 ]
   ooo = ooo . replace ( '&quot;' , '' )
   oO = re . findall ( 'Normal,code:[A-Za-z0-9]{13},name:|Virtual,code:[A-Za-z0-9]{13},name:' , ooo )
   if 27 - 27: Oo0ooO0oo0oO % I1IiiI
   for I1i in range ( len ( oO ) ) :
    o0oooOO00 = oO [ I1i ]
    o0oooOO00 = o0oooOO00 . split ( ':' ) [ 1 ]
    oO [ I1i ] = o0oooOO00 . split ( ',' ) [ 0 ]
    if 32 - 32: O0oo0OO0
    if 30 - 30: iIii1I11I1II1 / I11i . OoO0O00 - o0oOOo0O0Ooo
  except Exception as III1i1i :
   print ( III1i1i )
   if 48 - 48: i1IIi - Ii1I / O0 * OoO0O00
  return oO
  if 71 - 71: I1ii11iIi11i
  if 7 - 7: I1ii11iIi11i - I1IiiI . iIii1I11I1II1 - i1IIi
 def GetProfilesConvert ( self , usercd ) :
  o0OOOoO0 = ''
  o0OoOo00o0o = ''
  if 41 - 41: Oo0ooO0oo0oO % OoO0O00 - Oo0Ooo * O0oo0OO0 * Oo0Ooo
  try :
   oo0OooOOo0 = '/api/users/' + usercd + '/convert'
   OO0O00OooO = self . makeurl ( self . API_DOMAIN , oo0OooOOo0 )
   if 69 - 69: OOooOOo - OoooooooOO + o0oOOo0O0Ooo - I11i
   oOOo0oo = self . makeDefaultCookies ( )
   O0o0Oo = self . callRequestCookies ( 'Put' , OO0O00OooO , payload = None , params = None , headers = None , cookies = oOOo0oo )
   if 23 - 23: i11iIiiIii
   for oOOo0oo in O0o0Oo . cookies :
    if oOOo0oo . name == '_s_guitv' :
     II1iIi11 = oOOo0oo . value
    elif oOOo0oo . name == '_guinness-premium_session' :
     IIiiIiI1 = oOOo0oo . value
     if 12 - 12: Ii1I + i11iIiiIii * iIii1I11I1II1 / I1ii11iIi11i . I11i
   if II1iIi11 :
    o0OOOoO0 = II1iIi11
   if IIiiIiI1 :
    o0OoOo00o0o = IIiiIiI1
    if 5 - 5: i1IIi + O00oOoOoO0o0O / o0oOOo0O0Ooo . iii1I1I / I11i
  except Exception as III1i1i :
   o0OOOoO0 = ''
   o0OoOo00o0o = ''
   if 32 - 32: I1IiiI % iIii1I11I1II1 / i1IIi - I1IiiI
  return o0OOOoO0 , o0OoOo00o0o
  if 7 - 7: O0oo0OO0 * OoO0O00 - Oo0ooO0oo0oO + OOooOOo * I1IiiI % OoO0O00
  if 15 - 15: OoOoOO00 % I1IiiI * I11i
 def Get_Now_Datetime ( self ) :
  if 81 - 81: Oo0ooO0oo0oO - iIii1I11I1II1 - i1IIi / O0oo0OO0 - O0 * I11i
  return datetime . datetime . utcnow ( ) + datetime . timedelta ( hours = 9 )
  if 20 - 20: oO0o % O00oOoOoO0o0O
  if 19 - 19: I1ii11iIi11i % O00oOoOoO0o0O + Oo0ooO0oo0oO / O0oo0OO0 . Oo0ooO0oo0oO
 def GetStreamingURL ( self , movie_code , quality_str ) :
  IiIi1I1 = IiIIi1 = IIIIiii1IIii = ''
  if 38 - 38: OOooOOo + II111iiii % Oo0ooO0oo0oO % OoOoOO00 - Ii1I / OoooooooOO
  try :
   oo0OooOOo0 = '/api/watch/' + movie_code + '.json'
   if 73 - 73: o0oOOo0O0Ooo * O0 - i11iIiiIii
   OO0O00OooO = self . makeurl ( self . API_DOMAIN , oo0OooOOo0 )
   if 85 - 85: Ii1I % iii1I1I + I11i / o0oOOo0O0Ooo . oO0o + OOooOOo
   Ooo = { 'x-watchaplay-client-codec-flag' : '3'
 , 'x-watchaplay-media-devices-info' : '1'
 , 'x-watchaplay-screen' : quality_str

   }
   oOOo0oo = self . makeDefaultCookies ( )
   O0o0Oo = self . callRequestCookies ( 'Get' , OO0O00OooO , payload = None , params = None , headers = Ooo , cookies = oOOo0oo )
   OooO0OoOOOO = json . loads ( O0o0Oo . text )
   if 62 - 62: i11iIiiIii + i11iIiiIii - o0oOOo0O0Ooo
   IiIi1I1 = OooO0OoOOOO [ 'streams' ] [ 0 ] [ 'source' ]
   if IiIi1I1 == None : return ( IiIi1I1 , IiIIi1 , IIIIiii1IIii )
   if 28 - 28: iii1I1I . iii1I1I % iIii1I11I1II1 * iIii1I11I1II1 . o0oOOo0O0Ooo / iii1I1I
   if 'subtitles' in OooO0OoOOOO [ 'streams' ] [ 0 ] :
    for iII1i1 in OooO0OoOOOO [ 'streams' ] [ 0 ] [ 'subtitles' ] :
     if iII1i1 [ 'lang' ] == 'ko' :
      IiIIi1 = iII1i1 [ 'url' ]
      break
      if 85 - 85: Ii1I * Oo0Ooo . O0 - i11iIiiIii
      if 18 - 18: Ii1I + O00oOoOoO0o0O - O0
   o00O = OooO0OoOOOO [ 'ping_payload' ]
   i1Ii1i1I11Iii = self . WATCHA_USERCD
   I1i1i1 = { 'merchant' : 'giitd_frograms'
 , 'sessionId' : o00O
 , 'userId' : i1Ii1i1I11Iii
 }
   OoO0O00O0oo0O = json . dumps ( I1i1i1 , separators = ( "," , ":" ) ) . encode ( 'UTF-8' )
   if 36 - 36: OOooOOo + O0 - Ii1I - O0 % I11i . oO0o
   IIIIiii1IIii = base64 . b64encode ( OoO0O00O0oo0O )
   if 74 - 74: i11iIiiIii . I1IiiI
   if 36 - 36: OoooooooOO . OoO0O00
  except Exception as III1i1i :
   return ( IiIi1I1 , IiIIi1 , IIIIiii1IIii )
   if 56 - 56: Oo0Ooo . I1ii11iIi11i . I1IiiI
   if 39 - 39: O0 + O0oo0OO0
  return ( IiIi1I1 , IiIIi1 , IIIIiii1IIii )
  if 91 - 91: OoooooooOO - iIii1I11I1II1 + OoOoOO00 / OoO0O00 . OoOoOO00 + O0
  if 26 - 26: I1ii11iIi11i - OoooooooOO
  if 11 - 11: I1IiiI * oO0o
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
