# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import os
import xbmcplugin , xbmcgui , xbmcaddon , xbmc
import sys
import datetime
import time
import urllib
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
xIiiIII111iI = [
 { 'title' : '*** 간단설명 (개별 OTT 애드온 필수) ***' , 'mode' : 'XXX' }
 , { 'title' : '     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)' , 'mode' : 'XXX' }
 , { 'title' : '     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)' , 'mode' : 'XXX' }
 , { 'title' : '-----------------' , 'mode' : 'XXX' }
 , { 'title' : '-> M3U 파일 초기화/삭제' , 'mode' : 'DEL_M3U' }
 , { 'title' : '     - M3U 추가 (웨이브)' , 'mode' : 'ADD_M3U' , 'sType' : 'wavve' , 'sName' : '웨이브' }
 , { 'title' : '     - M3U 추가 (티빙)' , 'mode' : 'ADD_M3U' , 'sType' : 'tving' , 'sName' : '티빙' }
 , { 'title' : '     - M3U 추가 (스포티비)' , 'mode' : 'ADD_M3U' , 'sType' : 'spotv' , 'sName' : '스포티비나우' }
 , { 'title' : '-> M3U (삭제후 일괄생성)' , 'mode' : 'ADD_M3U' , 'sType' : 'all' , 'sName' : '전체' }
 , { 'title' : '-----------------' , 'mode' : 'XXX' }
 , { 'title' : '-> EPG 생성 (삭제후 일괄생성)' , 'mode' : 'ADD_EPG' , 'sType' : 'all' , 'sName' : '전체' }
 ]
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . OoO0O00 - I1ii11iIi11i
if 53 - 53: I11i / Oo0Ooo / II111iiii % Ii1I / OoOoOO00 . Oo0ooO0oo0oO
__addon__ = xbmcaddon . Addon ( )
__language__ = __addon__ . getLocalizedString
__profile__ = xbmc . translatePath ( __addon__ . getAddonInfo ( 'profile' ) )
__version__ = __addon__ . getAddonInfo ( 'version' )
__addonid__ = __addon__ . getAddonInfo ( 'id' )
__addonname__ = __addon__ . getAddonInfo ( 'name' )
if 100 - 100: i1IIi
if 27 - 27: O00oOoOoO0o0O * OoooooooOO + I11i * Oo0ooO0oo0oO - i11iIiiIii - iii1I1I
IiiiIiI1iIiI1 = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
if 85 - 85: OoO0O00
if 28 - 28: Ii1I
from boritvCore import *
if 64 - 64: I1ii11iIi11i % OoO0O00
if 1 - 1: O00oOoOoO0o0O
class OOooo0000ooo ( object ) :
 def __init__ ( self , in_addonurl , in_handle , in_params ) :
  self . _addon_url = in_addonurl
  self . _addon_handle = in_handle
  self . main_params = in_params
  self . M3U_FILE_PATH = ''
  self . M3U_FILE_NAME = ''
  self . M3U_ONWAVVE = False
  self . M3U_ONTVING = False
  self . M3U_ONSPOTV = False
  self . M3U_ONWAVVERADIO = False
  self . M3U_ONWAVVEHOME = False
  self . M3U_ONSPOTVPAY = False
  self . M3U_DISPLAYNM = False
  self . BoritvObj = xxOOO0o0o ( )
  if 79 - 79: oO0o + O0oo0OO0 . Oo0ooO0oo0oO * O00oOoOoO0o0O % I11i . I1IiiI
  if 94 - 94: iii1I1I * Ii1I / O00oOoOoO0o0O . i1IIi * iii1I1I
  if 47 - 47: i1IIi % i11iIiiIii
 def addon_noti ( self , sting ) :
  try :
   i1iII1I1i1i1 = xbmcgui . Dialog ( )
   i1iII1I1i1i1 . notification ( __addonname__ , sting )
  except :
   None
   if 27 - 27: OoO0O00
   if 73 - 73: o0oOOo0O0Ooo - Oo0Ooo
   if 58 - 58: i11iIiiIii % O0oo0OO0
 def addon_log ( self , string ) :
  try :
   O0OoOoo00o = string . encode ( 'utf-8' , 'ignore' )
  except :
   O0OoOoo00o = 'addonException: addon_log'
   if 31 - 31: II111iiii + OoO0O00 . O0oo0OO0
   if 68 - 68: I1IiiI - i11iIiiIii - OoO0O00 / OOooOOo - OoO0O00 + i1IIi
  IiiIII111ii = xbmc . LOGINFO
  xbmc . log ( "[%s-%s]: %s" % ( __addonid__ , __version__ , O0OoOoo00o ) , level = IiiIII111ii )
  if 3 - 3: iii1I1I + O0
  if 42 - 42: OOooOOo / i1IIi + i11iIiiIii - Ii1I
  if 78 - 78: OoO0O00
  if 18 - 18: O0 - iii1I1I / iii1I1I + Oo0ooO0oo0oO % Oo0ooO0oo0oO - O00oOoOoO0o0O
 def get_keyboard_input ( self , title ) :
  O0O00Ooo = None
  OOoooooO = xbmc . Keyboard ( )
  OOoooooO . setHeading ( title )
  xbmc . sleep ( 1000 )
  OOoooooO . doModal ( )
  if ( OOoooooO . isConfirmed ( ) ) :
   O0O00Ooo = OOoooooO . getText ( )
  return O0O00Ooo
  if 14 - 14: I11i % O0
  if 41 - 41: i1IIi + O0oo0OO0 + OOooOOo - O00oOoOoO0o0O
  if 77 - 77: Oo0Ooo . O00oOoOoO0o0O % Oo0ooO0oo0oO
  if 42 - 42: oO0o - i1IIi / i11iIiiIii + OOooOOo + OoO0O00
 def add_dir ( self , label , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = '' ) :
  iIi = '%s?%s' % ( self . _addon_url , urllib . urlencode ( params ) )
  if 40 - 40: oO0o . OoOoOO00 . Oo0Ooo . i1IIi
  if sublabel : I11iii = '%s < %s >' % ( label , sublabel )
  else : I11iii = label
  if not img : img = 'DefaultFolder.png'
  if 54 - 54: OOooOOo + OOooOOo % O0oo0OO0 % i11iIiiIii / iIii1I11I1II1 . OOooOOo
  o0oO0o00oo = xbmcgui . ListItem ( I11iii )
  o0oO0o00oo . setArt ( { 'thumbnailImage' : img , 'icon' : img , 'poster' : img } )
  if 32 - 32: Oo0Ooo * O0 % oO0o % Ii1I . O00oOoOoO0o0O
  if infoLabels : o0oO0o00oo . setInfo ( type = "video" , infoLabels = infoLabels )
  if not isFolder : o0oO0o00oo . setProperty ( 'IsPlayable' , 'true' )
  if 61 - 61: Oo0ooO0oo0oO
  xbmcplugin . addDirectoryItem ( self . _addon_handle , iIi , o0oO0o00oo , isFolder )
  if 79 - 79: Oo0Ooo + I1IiiI - iii1I1I
  if 83 - 83: Oo0ooO0oo0oO
  if 64 - 64: OoO0O00 % Oo0ooO0oo0oO % iii1I1I / OoOoOO00 - OoO0O00
  if 74 - 74: iii1I1I * O0
 def make_M3u_Filename ( self ) :
  return self . M3U_FILE_PATH + self . M3U_FILE_NAME + '.m3u'
  if 89 - 89: oO0o + Oo0Ooo
  if 3 - 3: i1IIi / I1IiiI % I11i * i11iIiiIii / O0 * I11i
  if 49 - 49: oO0o % Ii1I + i1IIi . I1IiiI % I1ii11iIi11i
  if 48 - 48: I11i + I11i / II111iiii / iIii1I11I1II1
 def make_Epg_Filename ( self ) :
  return self . M3U_FILE_PATH + self . M3U_FILE_NAME + '.xml'
  if 20 - 20: o0oOOo0O0Ooo
  if 77 - 77: OoOoOO00 / I11i
  if 98 - 98: iIii1I11I1II1 / i1IIi / i11iIiiIii / o0oOOo0O0Ooo
  if 28 - 28: OOooOOo - O00oOoOoO0o0O . O00oOoOoO0o0O + OoOoOO00 - OoooooooOO + O0
 def dp_Main_List ( self ) :
  if 95 - 95: OoO0O00 % oO0o . O0
  for I1i1I in xIiiIII111iI :
   I11iii = I1i1I . get ( 'title' )
   if 80 - 80: OoOoOO00 - OoO0O00
   OOO00 = { 'mode' : I1i1I . get ( 'mode' )
 , 'sType' : I1i1I . get ( 'sType' )
 , 'sName' : I1i1I . get ( 'sName' )
 }
   if 21 - 21: OoooooooOO - OoooooooOO
   if I1i1I . get ( 'mode' ) == 'XXX' :
    iIii11I = False
   else :
    iIii11I = True
    if 69 - 69: oO0o % O0oo0OO0 - o0oOOo0O0Ooo + O0oo0OO0 - O0 % OoooooooOO
   Iii111II = True
   if I1i1I . get ( 'mode' ) == 'ADD_M3U' :
    if I1i1I . get ( 'sType' ) == 'wavve' and self . M3U_ONWAVVE == False : Iii111II = False
    if I1i1I . get ( 'sType' ) == 'tving' and self . M3U_ONTVING == False : Iii111II = False
    if I1i1I . get ( 'sType' ) == 'spotv' and self . M3U_ONSPOTV == False : Iii111II = False
    if 9 - 9: OoO0O00
   if Iii111II == True :
    self . add_dir ( I11iii , sublabel = '' , img = '' , infoLabels = None , isFolder = iIii11I , params = OOO00 )
    if 33 - 33: Oo0ooO0oo0oO . iii1I1I
  if len ( IiiIII111iI ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 58 - 58: OOooOOo * i11iIiiIii / OoOoOO00 % O0oo0OO0 - I1ii11iIi11i / oO0o
  if 50 - 50: I1IiiI
  if 34 - 34: I1IiiI * II111iiii % iii1I1I * OoOoOO00 - I1IiiI
  if 33 - 33: o0oOOo0O0Ooo + OOooOOo * OoO0O00 - Oo0Ooo / oO0o % Ii1I
 def dp_Delete_M3u ( self , args ) :
  i1iII1I1i1i1 = xbmcgui . Dialog ( )
  II1i1IiiIIi11 = i1iII1I1i1i1 . yesno ( __language__ ( 30903 ) . encode ( 'utf8' ) , __language__ ( 30904 ) . encode ( 'utf8' ) )
  if II1i1IiiIIi11 == False : sys . exit ( )
  if 47 - 47: iii1I1I
  if 50 - 50: II111iiii - Oo0ooO0oo0oO * I1ii11iIi11i / O0oo0OO0 + o0oOOo0O0Ooo
  O0O0O = self . make_M3u_Filename ( )
  if os . path . isfile ( O0O0O ) : os . remove ( O0O0O )
  if 83 - 83: I1ii11iIi11i / Oo0ooO0oo0oO
  self . addon_noti ( __language__ ( 30905 ) . encode ( 'utf-8' ) )
  if 49 - 49: o0oOOo0O0Ooo
  if 35 - 35: OoOoOO00 - OoooooooOO / I1ii11iIi11i % i1IIi
  if 78 - 78: I11i
  if 71 - 71: OOooOOo + Oo0ooO0oo0oO % i11iIiiIii + I1ii11iIi11i - O00oOoOoO0o0O
 def dp_MakeAdd_M3u ( self , args ) :
  if 88 - 88: OoOoOO00 - OoO0O00 % OOooOOo
  iI1I111Ii111i = args . get ( 'sType' )
  I11IiI1I11i1i = args . get ( 'sName' )
  if 38 - 38: o0oOOo0O0Ooo
  i1iII1I1i1i1 = xbmcgui . Dialog ( )
  II1i1IiiIIi11 = i1iII1I1i1i1 . yesno ( ( I11IiI1I11i1i + __language__ ( 30906 ) ) . encode ( 'utf8' ) , __language__ ( 30907 ) . encode ( 'utf8' ) )
  if II1i1IiiIIi11 == False : sys . exit ( )
  if 57 - 57: O0 / oO0o * O0oo0OO0 / OoOoOO00 . II111iiii
  i11iIIIIIi1 = [ ]
  if 20 - 20: i1IIi + I1ii11iIi11i - Oo0ooO0oo0oO
  if 30 - 30: II111iiii - OOooOOo - i11iIiiIii % OoOoOO00 - II111iiii * Ii1I
  if iI1I111Ii111i == 'all' :
   O0O0O = self . make_M3u_Filename ( )
   if os . path . isfile ( O0O0O ) : os . remove ( O0O0O )
   if 61 - 61: oO0o - I11i % OOooOOo
   if 84 - 84: oO0o * OoO0O00 / I11i - O0
  if ( iI1I111Ii111i == 'wavve' or iI1I111Ii111i == 'all' ) and self . M3U_ONWAVVE :
   IiI1 = self . BoritvObj . Get_ChannelList_Wavve ( exceptGroup = self . make_EexceptGroup_Wavve ( ) )
   if len ( IiI1 ) != 0 : i11iIIIIIi1 . extend ( IiI1 )
   if 54 - 54: II111iiii % OoOoOO00 % I11i % iIii1I11I1II1 + iIii1I11I1II1 * Oo0ooO0oo0oO
   if 87 - 87: Oo0ooO0oo0oO * Oo0Ooo % i11iIiiIii % OoOoOO00 - OOooOOo
  if ( iI1I111Ii111i == 'tving' or iI1I111Ii111i == 'all' ) and self . M3U_ONTVING :
   IiI1 = self . BoritvObj . Get_ChannelList_Tving ( )
   if len ( IiI1 ) != 0 : i11iIIIIIi1 . extend ( IiI1 )
   if 68 - 68: O0oo0OO0 % i1IIi . O00oOoOoO0o0O . I1ii11iIi11i
   if 92 - 92: iii1I1I . O0oo0OO0
  if ( iI1I111Ii111i == 'spotv' or iI1I111Ii111i == 'all' ) and self . M3U_ONSPOTV :
   IiI1 = self . BoritvObj . Get_ChannelList_Spotv ( payyn = self . M3U_ONSPOTVPAY )
   if len ( IiI1 ) != 0 : i11iIIIIIi1 . extend ( IiI1 )
   if 31 - 31: O0oo0OO0 . OoOoOO00 / O0
  if len ( i11iIIIIIi1 ) == 0 :
   self . addon_noti ( __language__ ( 30909 ) . encode ( 'utf8' ) )
   return
   if 89 - 89: OoOoOO00
  try :
   O0O0O = self . make_M3u_Filename ( )
   if 68 - 68: OoO0O00 * OoooooooOO % O0 + OoO0O00 + Oo0ooO0oo0oO
   if os . path . isfile ( O0O0O ) :
    i11i1I1 = open ( O0O0O , 'a' )
   else :
    i11i1I1 = open ( O0O0O , 'w' )
    i11i1I1 . write ( '#EXTM3U\n' )
    if 36 - 36: iIii1I11I1II1 / OoOoOO00 * OOooOOo
   for O0ii1ii1ii in i11iIIIIIi1 :
    if 91 - 91: O00oOoOoO0o0O
    iiIii = O0ii1ii1ii [ 'channelid' ]
    ooo0O = O0ii1ii1ii [ 'channelnm' ]
    oOoO0o00OO0 = O0ii1ii1ii [ 'channelimg' ]
    i1I1ii = O0ii1ii1ii [ 'ott' ]
    oOOo0 = '%s.%s' % ( iiIii , i1I1ii )
    if 54 - 54: O0 - O00oOoOoO0o0O % OOooOOo
    if self . M3U_DISPLAYNM :
     ooo0O = '%s (%s)' % ( ooo0O , i1I1ii )
     if 77 - 77: OoOoOO00 / I1IiiI / OoO0O00 + OoO0O00 . OOooOOo
     if 38 - 38: O0oo0OO0
    Ii1 = '#EXTINF:0 tvg-ID="%s" tvg-name="%s" tvg-logo="%s",%s\n' % ( oOOo0 , ooo0O , oOoO0o00OO0 , ooo0O )
    if 82 - 82: I1ii11iIi11i - iIii1I11I1II1 / OOooOOo + Ii1I
    if i1I1ii == 'wavve' :
     OOOOoOoo0O0O0 = 'plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n' % ( iiIii )
    elif i1I1ii == 'tving' :
     OOOOoOoo0O0O0 = 'plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n' % ( iiIii )
    elif i1I1ii == 'spotv' :
     if 85 - 85: oO0o % i11iIiiIii - iii1I1I * OoooooooOO / I1IiiI % I1IiiI
     if 1 - 1: OoO0O00 - oO0o . I11i . OoO0O00 / Oo0Ooo + I11i
     if 78 - 78: O0 . oO0o . II111iiii % OOooOOo
     OOOOoOoo0O0O0 = 'plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n' % ( iiIii )
     if 49 - 49: Ii1I / OoO0O00 . II111iiii
    i11i1I1 . write ( Ii1 )
    i11i1I1 . write ( OOOOoOoo0O0O0 )
    if 68 - 68: i11iIiiIii % I1ii11iIi11i + i11iIiiIii
   i11i1I1 . close ( )
  except :
   self . addon_noti ( __language__ ( 30910 ) . encode ( 'utf8' ) )
   return
   if 31 - 31: II111iiii . I1IiiI
  self . addon_noti ( ( I11IiI1I11i1i + ' ' + __language__ ( 30908 ) ) . encode ( 'utf8' ) )
  if 1 - 1: Oo0Ooo / o0oOOo0O0Ooo % iii1I1I * O00oOoOoO0o0O . i11iIiiIii
  if 2 - 2: I1ii11iIi11i * I11i - iIii1I11I1II1 + I1IiiI . oO0o % iii1I1I
  if 92 - 92: iii1I1I
  if 25 - 25: Oo0Ooo - I1IiiI / OoooooooOO / o0oOOo0O0Ooo
 def dp_Make_Epg ( self , args ) :
  if 12 - 12: I1IiiI * iii1I1I % i1IIi % iIii1I11I1II1
  iI1I111Ii111i = args . get ( 'sType' )
  I11IiI1I11i1i = args . get ( 'sName' )
  if 20 - 20: OOooOOo % Ii1I / Ii1I + Ii1I
  i1iII1I1i1i1 = xbmcgui . Dialog ( )
  II1i1IiiIIi11 = i1iII1I1i1i1 . yesno ( ( I11IiI1I11i1i + __language__ ( 30911 ) ) . encode ( 'utf8' ) , __language__ ( 30907 ) . encode ( 'utf8' ) )
  if II1i1IiiIIi11 == False : sys . exit ( )
  if 45 - 45: oO0o - O00oOoOoO0o0O - OoooooooOO - OoO0O00 . II111iiii / O0
  oo0o00O = [ ]
  o00O0OoO = [ ]
  if 16 - 16: iIii1I11I1II1
  if 90 - 90: o0oOOo0O0Ooo % i1IIi / OoO0O00
  if 44 - 44: Oo0Ooo . OoO0O00 / I1ii11iIi11i + Ii1I
  if ( iI1I111Ii111i == 'wavve' or iI1I111Ii111i == 'all' ) and self . M3U_ONWAVVE :
   o0o , O0OOoO00OO0o = self . BoritvObj . Get_EpgInfo_Wavve ( exceptGroup = self . make_EexceptGroup_Wavve ( ) )
   if len ( O0OOoO00OO0o ) != 0 :
    oo0o00O . extend ( o0o )
    o00O0OoO . extend ( O0OOoO00OO0o )
    if 38 - 38: OOooOOo % I11i % o0oOOo0O0Ooo % OoO0O00 - Oo0Ooo
    if 37 - 37: O0oo0OO0 / OoOoOO00
  if ( iI1I111Ii111i == 'tving' or iI1I111Ii111i == 'all' ) and self . M3U_ONTVING :
   o0o , O0OOoO00OO0o = self . BoritvObj . Get_EpgInfo_Tving ( )
   if len ( O0OOoO00OO0o ) != 0 :
    oo0o00O . extend ( o0o )
    o00O0OoO . extend ( O0OOoO00OO0o )
    if 23 - 23: O0
    if 85 - 85: Ii1I
  if ( iI1I111Ii111i == 'spotv' or iI1I111Ii111i == 'all' ) and self . M3U_ONSPOTV :
   o0o , O0OOoO00OO0o = self . BoritvObj . Get_EpgInfo_Spotv ( payyn = self . M3U_ONSPOTVPAY )
   if len ( O0OOoO00OO0o ) != 0 :
    oo0o00O . extend ( o0o )
    o00O0OoO . extend ( O0OOoO00OO0o )
    if 84 - 84: I1IiiI . iIii1I11I1II1 % OoooooooOO + Ii1I % OoooooooOO % OoO0O00
  if len ( o00O0OoO ) == 0 :
   self . addon_noti ( __language__ ( 30909 ) . encode ( 'utf8' ) )
   return
   if 42 - 42: OoO0O00 / I11i / o0oOOo0O0Ooo + iii1I1I / OoOoOO00
  try :
   O0O0O = self . make_Epg_Filename ( )
   i11i1I1 = open ( O0O0O , 'w' )
   if 84 - 84: Oo0ooO0oo0oO * II111iiii + Oo0Ooo
   O0ooO0Oo00o = '<?xml version="1.0" encoding="UTF-8"?>\n'
   ooO0oOOooOo0 = '<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   i1I1ii11i1Iii = '<tv generator-info-name="boritv_epg">\n\n'
   I1IiiiiI = '\n</tv>\n'
   if 80 - 80: O0oo0OO0 . i11iIiiIii - o0oOOo0O0Ooo
   i11i1I1 . write ( O0ooO0Oo00o )
   i11i1I1 . write ( ooO0oOOooOo0 )
   i11i1I1 . write ( i1I1ii11i1Iii )
   if 25 - 25: OoO0O00
   if 62 - 62: OOooOOo + O0
   for oO0OOOO0 in oo0o00O :
    iI1I11iiI1i = '  <channel id="%s.%s">\n' % ( oO0OOOO0 . get ( 'channelid' ) , oO0OOOO0 . get ( 'ott' ) )
    oO0o0Ooooo = '    <display-name>%s</display-name>\n' % ( oO0OOOO0 . get ( 'channelnm' ) )
    OOo0oO00ooO00 = '    <icon src="%s" />\n' % ( oO0OOOO0 . get ( 'channelimg' ) )
    oOO0O00oO0Ooo = '  </channel>\n\n'
    i11i1I1 . write ( iI1I11iiI1i )
    i11i1I1 . write ( oO0o0Ooooo )
    i11i1I1 . write ( OOo0oO00ooO00 )
    i11i1I1 . write ( oOO0O00oO0Ooo )
    if 67 - 67: OoO0O00 - OOooOOo
    if 36 - 36: O00oOoOoO0o0O
   for oO0OOOO0 in o00O0OoO :
    iI1I11iiI1i = '  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n' % ( oO0OOOO0 . get ( 'startTime' ) , oO0OOOO0 . get ( 'endTime' ) , oO0OOOO0 . get ( 'channelid' ) , oO0OOOO0 . get ( 'ott' ) )
    oO0o0Ooooo = '    <title lang="kr">%s</title>\n' % ( oO0OOOO0 . get ( 'title' ) )
    OOo0oO00ooO00 = '  </programme>\n\n'
    i11i1I1 . write ( iI1I11iiI1i )
    i11i1I1 . write ( oO0o0Ooooo )
    i11i1I1 . write ( OOo0oO00ooO00 )
    if 36 - 36: Oo0ooO0oo0oO / O0 * Oo0Ooo - OOooOOo % iIii1I11I1II1 * oO0o
   i11i1I1 . write ( I1IiiiiI )
   if 79 - 79: O0
   i11i1I1 . close ( )
  except :
   self . addon_noti ( __language__ ( 30910 ) . encode ( 'utf8' ) )
   return
   if 78 - 78: I1ii11iIi11i + OOooOOo - O0oo0OO0
  self . addon_noti ( ( I11IiI1I11i1i + ' ' + __language__ ( 30912 ) ) . encode ( 'utf8' ) )
  if 38 - 38: o0oOOo0O0Ooo - oO0o + iIii1I11I1II1 / OoOoOO00 % Oo0Ooo
  if 57 - 57: OoO0O00 / Oo0ooO0oo0oO
  if 29 - 29: iIii1I11I1II1 + OoOoOO00 * OoO0O00 * OOooOOo . I1IiiI * I1IiiI
  if 7 - 7: O00oOoOoO0o0O * O0oo0OO0 % Ii1I - o0oOOo0O0Ooo
 def make_EexceptGroup_Wavve ( self ) :
  i1i = [ ]
  if 56 - 56: I1ii11iIi11i % O0 - I1IiiI
  if self . M3U_ONWAVVERADIO == False :
   O00o0OO0 = { 'broadcastid' : '46584'
 , 'genre' : '10'
   }
   i1i . append ( O00o0OO0 )
   if 35 - 35: oO0o % Oo0ooO0oo0oO / O0oo0OO0 + iIii1I11I1II1 . OoooooooOO . I1IiiI
  if self . M3U_ONWAVVEHOME == False :
   O00o0OO0 = { 'broadcastid' : '46584'
 , 'genre' : '03'
   }
   i1i . append ( O00o0OO0 )
   if 71 - 71: O00oOoOoO0o0O * II111iiii * oO0o
  return i1i
  if 56 - 56: I1IiiI
  if 54 - 54: O0oo0OO0 / OOooOOo . oO0o % iii1I1I
  if 57 - 57: i11iIiiIii . I1ii11iIi11i - Ii1I - oO0o + OoOoOO00
  if 63 - 63: OoOoOO00 * iii1I1I
 def check_config ( self ) :
  oo = True
  if 44 - 44: oO0o / I11i / I11i
  self . M3U_FILE_PATH = ( __addon__ . getSetting ( 'm3uFilepath' ) ) . strip ( )
  self . M3U_FILE_NAME = ( __addon__ . getSetting ( 'm3uFilename' ) ) . strip ( )
  self . M3U_ONWAVVE = True if __addon__ . getSetting ( 'onWavve' ) == 'true' else False
  self . M3U_ONTVING = True if __addon__ . getSetting ( 'onTvng' ) == 'true' else False
  self . M3U_ONSPOTV = True if __addon__ . getSetting ( 'onSpotv' ) == 'true' else False
  self . M3U_ONWAVVERADIO = True if __addon__ . getSetting ( 'onWavveRadio' ) == 'true' else False
  self . M3U_ONWAVVEHOME = True if __addon__ . getSetting ( 'onWavveHome' ) == 'true' else False
  self . M3U_ONSPOTVPAY = True if __addon__ . getSetting ( 'onSpotvPay' ) == 'true' else False
  self . M3U_DISPLAYNM = True if __addon__ . getSetting ( 'displayOTTnm' ) == 'true' else False
  if 87 - 87: Oo0Ooo . I1IiiI - II111iiii + O0 / Oo0Ooo / oO0o
  if self . M3U_FILE_PATH == '' or self . M3U_FILE_NAME == '' : oo = False
  if self . M3U_ONWAVVE == False and self . M3U_ONTVING == '' and self . M3U_ONSPOTV == '' : oo = False
  if 25 - 25: I1IiiI . I1IiiI - OoOoOO00 % OoOoOO00 - i11iIiiIii / O0oo0OO0
  if oo == False :
   i1iII1I1i1i1 = xbmcgui . Dialog ( )
   II1i1IiiIIi11 = i1iII1I1i1i1 . yesno ( __language__ ( 30901 ) . encode ( 'utf8' ) , __language__ ( 30902 ) . encode ( 'utf8' ) )
   if II1i1IiiIIi11 == True :
    __addon__ . openSettings ( )
    sys . exit ( )
   else :
    sys . exit ( )
    if 51 - 51: Oo0Ooo / OoOoOO00 . OOooOOo * o0oOOo0O0Ooo + OoO0O00 * O00oOoOoO0o0O
    if 73 - 73: OoO0O00 + OoooooooOO - O0 - Ii1I - II111iiii
    if 99 - 99: Oo0ooO0oo0oO . Ii1I + O0oo0OO0 + OoooooooOO % o0oOOo0O0Ooo
    if 51 - 51: iIii1I11I1II1
 def boritv_main ( self ) :
  if 34 - 34: oO0o + I1IiiI - oO0o
  IiI1I1i1I1 = self . main_params . get ( 'mode' , None )
  if 98 - 98: I11i % i11iIiiIii % Oo0ooO0oo0oO + Ii1I
  self . check_config ( )
  if 78 - 78: I1ii11iIi11i % oO0o / iii1I1I - iIii1I11I1II1
  if IiI1I1i1I1 is None :
   self . dp_Main_List ( )
   if 69 - 69: O0oo0OO0
  elif IiI1I1i1I1 == 'DEL_M3U' :
   self . dp_Delete_M3u ( self . main_params )
   if 11 - 11: I1IiiI
  elif IiI1I1i1I1 == 'ADD_M3U' :
   self . dp_MakeAdd_M3u ( self . main_params )
   if 16 - 16: Ii1I + O00oOoOoO0o0O * O0 % i1IIi . I1IiiI
  elif IiI1I1i1I1 == 'ADD_EPG' :
   self . dp_Make_Epg ( self . main_params )
   if 67 - 67: OoooooooOO / I1IiiI * Ii1I + I11i
  else :
   None
   if 65 - 65: OoooooooOO - I1ii11iIi11i / Oo0ooO0oo0oO / II111iiii / i1IIi
   if 71 - 71: O0oo0OO0 + Ii1I
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
