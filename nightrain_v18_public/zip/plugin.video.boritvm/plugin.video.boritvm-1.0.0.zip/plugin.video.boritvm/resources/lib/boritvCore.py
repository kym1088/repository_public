# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import urllib
import re
import json
import sys
import requests
import datetime
import time
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
IiiIII111iI = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
IiII = [ { 'starttm' : '000000' , 'endtm' : '030000' }
 , { 'starttm' : '030000' , 'endtm' : '060000' }
 , { 'starttm' : '060000' , 'endtm' : '090000' }
 , { 'starttm' : '090000' , 'endtm' : '120000' }
 , { 'starttm' : '120000' , 'endtm' : '150000' }
 , { 'starttm' : '150000' , 'endtm' : '180000' }
 , { 'starttm' : '180000' , 'endtm' : '210000' }
 , { 'starttm' : '210000' , 'endtm' : '240000' }
 ]
if 28 - 28: Ii11111i * iiI1i1
if 46 - 46: Ooo0OO0oOO * Ii * I1ii11iIi11i
if 68 - 68: iiI1i1 . i1IIi
class xxOOO0o0o ( object ) :
 def __init__ ( self ) :
  self . API_WAVVE = 'https://apis.wavve.com'
  self . API_TVING = 'https://api.tving.com'
  self . API_TVINGIMG = 'https://image.tving.com'
  self . API_SPOTV = 'https://www.spotvnow.co.kr'
  self . HTTPTAG = 'https://'
  self . LIMIT_WAVVE = 200
  self . LIMIT_TVING = 60
  self . LIMIT_TVINGEPG = 20
  self . DEFAULT_HEADER = { 'user-agent' : IiiIII111iI }
  self . SLEEP_TIME = 0.2
  if 40 - 40: I1IiiI / O0 % Ii + O0 * i1IIi
  if 27 - 27: iiI1i1 * OoooooooOO + I11i * Ii - i11iIiiIii - Ii11111i
 def callRequestCookies ( self , jobtype , url , payload = None , params = None , headers = None , cookies = None , redirects = False ) :
  IiiiIiI1iIiI1 = self . DEFAULT_HEADER
  if headers : IiiiIiI1iIiI1 . update ( headers )
  if 85 - 85: OoO0O00
  if jobtype == 'Get' :
   iIi1IIii11I = requests . get ( url , params = params , headers = IiiiIiI1iIiI1 , cookies = cookies , allow_redirects = redirects )
  else :
   iIi1IIii11I = requests . post ( url , data = payload , params = params , headers = IiiiIiI1iIiI1 , cookies = cookies , allow_redirects = redirects )
   if 84 - 84: iIii1I11I1II1 . iiI1i1 / iiI1i1 % iiI1i1
  return iIi1IIii11I
  if 22 - 22: Ii1I . iiI1i1
 def Get_DefaultParams_Wavve ( self ) :
  I11 = { 'apikey' : 'E5F3E0D30947AA5440556471321BB6D9'
 , 'credential' : 'none'
 , 'device' : 'pc'
 , 'drm' : 'wm'
 , 'partner' : 'pooq'
 , 'pooqzone' : 'none'
 , 'region' : 'kor'
 , 'targetage' : 'all'
 }
  return I11
  if 98 - 98: i11iIiiIii * I1IiiI % Ii11111i * Ii11111i * II111iiii
 def Get_DefaultParams_Tving ( self ) :
  I11 = { 'apiKey' : '1e7952d0917d6aab1f0293a063697610'
 , 'networkCode' : 'CSND0900'
 , 'osCode' : 'CSOD0900'
  , 'teleCode' : 'CSCD0900'
 , 'screenCode' : 'CSSD0100'
 }
  return I11
  if 79 - 79: iiI1i1
  if 86 - 86: OoOoOO00 % I1IiiI
 def Get_Now_Datetime ( self ) :
  if 80 - 80: OoooooooOO . I1IiiI
  return datetime . datetime . utcnow ( ) + datetime . timedelta ( hours = 9 )
  if 87 - 87: oO0o / Ii + Ooo0OO0oOO - Ii . Ii / II111iiii
  if 11 - 11: I1IiiI % o0oOOo0O0Ooo - Oo0Ooo
  if 58 - 58: i11iIiiIii % Ooo0OO0oOO
 def xmlText ( self , in_text ) :
  if 54 - 54: OOooOOo % O0 + I1IiiI - Ii11111i / I11i
  iIiiI1 = in_text . replace ( '<' , '(' ) . replace ( '>' , ')' ) . replace ( '&lt;' , '(' ) . replace ( '&gt;' , ')' ) . replace ( '&' , '&amp;' )
  if 68 - 68: I1IiiI - i11iIiiIii - OoO0O00 / OOooOOo - OoO0O00 + i1IIi
  if 48 - 48: OoooooooOO % o0oOOo0O0Ooo . I1IiiI - Ii1I % i1IIi % OoooooooOO
  return iIiiI1
  if 3 - 3: Ii11111i + O0
  if 42 - 42: OOooOOo / i1IIi + i11iIiiIii - Ii1I
 def Get_ChannelList_Wavve ( self , exceptGroup = [ ] ) :
  oo0Ooo0 = [ ]
  I1I11I1I1I = [ ]
  if 90 - 90: II111iiii + oO0o / o0oOOo0O0Ooo % II111iiii - O0
  if 29 - 29: o0oOOo0O0Ooo / iIii1I11I1II1
  IiIIIiI1I1 = self . Get_ChannelImg_Wavve ( )
  if 86 - 86: i11iIiiIii + Ii1I + Ii * I11i + o0oOOo0O0Ooo
  if 61 - 61: OoO0O00 / i11iIiiIii
  if exceptGroup != [ ] :
   I1I11I1I1I = self . Get_ChannelList_WavveExcept ( exceptGroup )
   if 34 - 34: OoooooooOO + iIii1I11I1II1 + i11iIiiIii - I1ii11iIi11i + i11iIiiIii
  try :
   ooOoo0O = self . API_WAVVE + '/cf/live/recommend-channels'
   I11 = { 'WeekDay' : 'all'
 , 'broadcastid' : '30783'
 , 'contenttype' : 'channel'
 , 'isrecommend' : 'y'
 , 'limit' : str ( self . LIMIT_WAVVE )
   , 'offset' : '0'
 , 'uicode' : 'LN58'
 , 'uiparent' : 'GN54-LN58'
 , 'uirank' : '4'
 , 'uitype' : 'LN58'
 }
   if 76 - 76: O0 / o0oOOo0O0Ooo . I1IiiI * Ii1I - OOooOOo
   I11 . update ( self . Get_DefaultParams_Wavve ( ) )
   if 76 - 76: i11iIiiIii / iIii1I11I1II1 . I1ii11iIi11i % OOooOOo / OoooooooOO % oO0o
   o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ooOoo0O , payload = None , params = I11 , headers = None , cookies = None )
   o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
   if 85 - 85: Ii . Ii11111i - OoO0O00 % Ii % II111iiii
   if not ( 'celllist' in o0Oo00OOOOO [ 'cell_toplist' ] ) : return oo0Ooo0
   OO0o00o = o0Oo00OOOOO [ 'cell_toplist' ] [ 'celllist' ]
   if 89 - 89: oO0o + Oo0Ooo
   for Ii1IOo0o0 in OO0o00o :
    if 49 - 49: oO0o % Ii1I + i1IIi . I1IiiI % I1ii11iIi11i
    I1i1iii = Ii1IOo0o0 [ 'contentid' ]
    i1iiI11I = Ii1IOo0o0 [ 'title_list' ] [ 0 ] [ 'text' ]
    if 29 - 29: OoooooooOO
    if I1i1iii in IiIIIiI1I1 :
     iI = IiIIIiI1I1 [ I1i1iii ]
    else :
     iI = ''
     if 28 - 28: OOooOOo - iiI1i1 . iiI1i1 + OoOoOO00 - OoooooooOO + O0
    oOoOooOo0o0 = { 'channelid' : I1i1iii
 , 'channelnm' : i1iiI11I
 , 'channelimg' : self . HTTPTAG + iI if iI != '' else ''
 , 'ott' : 'wavve'
 }
    if 61 - 61: o0oOOo0O0Ooo / OoO0O00 + Ii * oO0o / oO0o
    if I1i1iii not in I1I11I1I1I :
     oo0Ooo0 . append ( oOoOooOo0o0 )
     if 75 - 75: i1IIi / OoooooooOO - O0 / OoOoOO00 . II111iiii - i1IIi
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ]
   if 43 - 43: Ooo0OO0oOO - O0 % I1IiiI . I11i
  return oo0Ooo0
  if 57 - 57: OOooOOo . OOooOOo
  if 95 - 95: O0 + OoO0O00 . II111iiii / O0
 def Get_ChannelList_WavveExcept ( self , exceptGroup = [ ] ) :
  oo0Ooo0 = [ ]
  if exceptGroup == [ ] : return [ ]
  if 97 - 97: Ii - OOooOOo * i11iIiiIii / OoOoOO00 % Ooo0OO0oOO - OoooooooOO
  try :
   ooOoo0O = self . API_WAVVE + '/cf/live/recommend-channels'
   if 59 - 59: O0 + I1IiiI + iiI1i1 % I1IiiI
   for Ii1IOo0o0 in exceptGroup :
    I11 = { 'WeekDay' : 'all'
 , 'adult' : 'n'
 , 'broadcastid' : Ii1IOo0o0 [ 'broadcastid' ]
    , 'contenttype' : 'channel'
 , 'genre' : Ii1IOo0o0 [ 'genre' ]
    , 'isrecommend' : 'y'
 , 'limit' : str ( self . LIMIT_WAVVE )
    , 'offset' : '0'
 , 'uicode' : 'LN58'
 , 'uiparent' : 'GN54-LN58'
 , 'uirank' : '4'
 , 'uitype' : 'LN58'
 }
    if 70 - 70: Ii11111i * I1ii11iIi11i
    I11 . update ( self . Get_DefaultParams_Wavve ( ) )
    if 46 - 46: Ii / OoO0O00
    o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ooOoo0O , payload = None , params = I11 , headers = None , cookies = None )
    o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
    if 52 - 52: o0oOOo0O0Ooo - OoooooooOO + Ii1I + Ii1I - o0oOOo0O0Ooo / Ooo0OO0oOO
    if not ( 'celllist' in o0Oo00OOOOO [ 'cell_toplist' ] ) : return oo0Ooo0
    OO0o00o = o0Oo00OOOOO [ 'cell_toplist' ] [ 'celllist' ]
    if 44 - 44: Ii . i1IIi - I1ii11iIi11i . O0 - Ii
    for Ii1IOo0o0 in OO0o00o :
     oo0Ooo0 . append ( Ii1IOo0o0 [ 'contentid' ] )
     if 92 - 92: Ii11111i . I11i + o0oOOo0O0Ooo
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ]
   if 28 - 28: i1IIi * Oo0Ooo - o0oOOo0O0Ooo * iiI1i1 * Ii1I / OoO0O00
  return oo0Ooo0
  if 94 - 94: II111iiii % I1ii11iIi11i / OoOoOO00 * iIii1I11I1II1
  if 54 - 54: o0oOOo0O0Ooo - I1IiiI + OoooooooOO
  if 70 - 70: Ii1I / I11i . Ii11111i % Oo0Ooo
 def Get_ChannelImg_Wavve ( self ) :
  OOoOO00OOO0OO = { }
  if 16 - 16: I1IiiI * oO0o % iiI1i1
  try :
   Oo000o = self . Get_Now_Datetime ( )
   I11IiI1I11i1i = Oo000o + datetime . timedelta ( hours = 3 )
   if 38 - 38: o0oOOo0O0Ooo
   ooOoo0O = self . API_WAVVE + '/live/epgs'
   I11 = { 'limit' : str ( self . LIMIT_WAVVE )
   , 'offset' : '0'
 , 'genre' : 'all'
 , 'startdatetime' : Oo000o . strftime ( '%Y-%m-%d %H:00' )
 , 'enddatetime' : I11IiI1I11i1i . strftime ( '%Y-%m-%d %H:00' )
 }
   I11 . update ( self . Get_DefaultParams_Wavve ( ) )
   if 57 - 57: O0 / oO0o * Ooo0OO0oOO / OoOoOO00 . II111iiii
   o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ooOoo0O , payload = None , params = I11 , headers = None , cookies = None )
   o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
   if 26 - 26: Ii11111i
   OO0o00o = o0Oo00OOOOO [ 'list' ]
   if 91 - 91: OoO0O00 . I1ii11iIi11i + OoO0O00 - Ii11111i / OoooooooOO
   for Ii1IOo0o0 in OO0o00o :
    OOoOO00OOO0OO [ Ii1IOo0o0 [ 'channelid' ] ] = Ii1IOo0o0 [ 'channelimage' ]
    if 39 - 39: I1ii11iIi11i / Ii - II111iiii
  except Exception as O000OO0 :
   print ( O000OO0 )
   if 98 - 98: I1ii11iIi11i / I11i % oO0o . OoOoOO00
  return OOoOO00OOO0OO
  if 91 - 91: oO0o % Oo0Ooo
  if 64 - 64: I11i % Ii11111i - Ooo0OO0oOO - oO0o
 def Get_ChannelList_Spotv ( self , payyn = True ) :
  oo0Ooo0 = [ ]
  if 31 - 31: I11i - II111iiii . I11i
  try :
   ooOoo0O = self . API_SPOTV + '/api/v2/channel'
   if 18 - 18: o0oOOo0O0Ooo
   o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ooOoo0O , payload = None , params = None , headers = None , cookies = None )
   o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
   if 98 - 98: Ii11111i * Ii11111i / Ii11111i + I11i
   for Ii1IOo0o0 in o0Oo00OOOOO :
    oOoOooOo0o0 = { 'channelid' : Ii1IOo0o0 [ 'videoId' ] . replace ( 'ref:' , '' )
 , 'channelnm' : Ii1IOo0o0 [ 'name' ]
 , 'channelimg' : Ii1IOo0o0 [ 'logo' ]
 , 'ott' : 'spotv'

    # Ii . Ii . iiI1i1
    }
    if payyn == True or Ii1IOo0o0 [ 'free' ] == True :
     oo0Ooo0 . append ( oOoOooOo0o0 )
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ]
   if 73 - 73: Ii11111i * Ii1I + o0oOOo0O0Ooo . OOooOOo + I1ii11iIi11i % Ii11111i
  return oo0Ooo0
  if 95 - 95: i1IIi
  if 3 - 3: Ooo0OO0oOO - O0 / Ooo0OO0oOO % OoO0O00 / Ooo0OO0oOO . I1IiiI
 def Get_ChannelList_Tving ( self ) :
  oo0Ooo0 = [ ]
  iiI111I1iIiI = [ ]
  if 41 - 41: Oo0Ooo . Ii + O0 * o0oOOo0O0Ooo % Oo0Ooo * Oo0Ooo
  try :
   ooOoo0O = self . API_TVING + '/v2/media/lives'
   I11 = { 'pageNo' : '1'
 , 'pageSize' : str ( self . LIMIT_TVING )
   , 'order' : 'rating'
   , 'adult' : 'all'
 , 'free' : 'all'
 , 'guest' : 'all'
 , 'scope' : 'all'
 , 'channelType' : 'CPCS0100,CPCS0400'

   # Ii11111i . OoOoOO00
   }
   if 67 - 67: i11iIiiIii - i1IIi % I1ii11iIi11i . O0
   I11 . update ( self . Get_DefaultParams_Tving ( ) )
   if 77 - 77: iiI1i1 / I1IiiI
   o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ooOoo0O , payload = None , params = I11 , headers = None , cookies = None )
   o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
   if 15 - 15: iiI1i1 . iIii1I11I1II1 . OoooooooOO / i11iIiiIii - Ii1I . i1IIi
   if not ( 'result' in o0Oo00OOOOO [ 'body' ] ) : return oo0Ooo0
   OO0o00o = o0Oo00OOOOO [ 'body' ] [ 'result' ]
   if 33 - 33: I11i . o0oOOo0O0Ooo
   if 75 - 75: o0oOOo0O0Ooo % o0oOOo0O0Ooo . Ooo0OO0oOO
   for Ii1IOo0o0 in OO0o00o :
    if Ii1IOo0o0 [ 'live_code' ] == 'C44441' : continue
    iiI111I1iIiI . append ( Ii1IOo0o0 [ 'live_code' ] )
    if 5 - 5: o0oOOo0O0Ooo * Ii + OoOoOO00 . OOooOOo + OoOoOO00
    if 91 - 91: O0
    if 61 - 61: II111iiii
   IiIIIiI1I1 = self . Get_ChannelImg_Tving ( iiI111I1iIiI )
   if 64 - 64: Ii / OoOoOO00 - O0 - I11i
   if 86 - 86: I11i % OoOoOO00 / I1IiiI / OoOoOO00
   if 42 - 42: OoO0O00
   for Ii1IOo0o0 in OO0o00o :
    if 67 - 67: Ooo0OO0oOO . Ii11111i . O0
    I1i1iii = Ii1IOo0o0 [ 'live_code' ]
    if I1i1iii == 'C44441' : continue
    i1iiI11I = Ii1IOo0o0 [ 'schedule' ] [ 'channel' ] [ 'name' ] [ 'ko' ]
    if 10 - 10: I1ii11iIi11i % I1ii11iIi11i - iIii1I11I1II1 / OOooOOo + Ii1I
    if I1i1iii in IiIIIiI1I1 :
     iI = IiIIIiI1I1 [ I1i1iii ]
    else :
     iI = ''
     if 87 - 87: oO0o * I1ii11iIi11i + OOooOOo / iIii1I11I1II1 / Ii11111i
    oOoOooOo0o0 = { 'channelid' : I1i1iii
 , 'channelnm' : i1iiI11I
 , 'channelimg' : iI
 , 'ott' : 'tving'
 }
    if 37 - 37: Ii11111i - Ii * oO0o % i11iIiiIii - Ooo0OO0oOO
    oo0Ooo0 . append ( oOoOooOo0o0 )
    if 83 - 83: I11i / I1IiiI
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ]
   if 34 - 34: iiI1i1
  return oo0Ooo0
  if 57 - 57: oO0o . I11i . i1IIi
  if 42 - 42: I11i + I1ii11iIi11i % O0
  if 6 - 6: oO0o
 def make_EpgDatetime_Tving ( self , days = 2 ) :
  oOOo0oOo0 = [ ]
  if 49 - 49: Oo0Ooo . i11iIiiIii - i1IIi / II111iiii . I1IiiI
  II1I = self . make_DateList ( days = 2 , dateType = '2' )
  if 84 - 84: iiI1i1 . i11iIiiIii . iiI1i1 * I1ii11iIi11i - I11i
  ii = int ( self . Get_Now_Datetime ( ) . strftime ( '%Y%m%d%H0000' ) )
  if 81 - 81: Ooo0OO0oOO % Ii11111i . I1ii11iIi11i / o0oOOo0O0Ooo
  for Ii1IOo0o0 in II1I :
   for iiiIiI in range ( 8 ) :
    oOoOooOo0o0 = { 'ndate' : Ii1IOo0o0
 , 'starttm' : IiII [ iiiIiI ] [ 'starttm' ]
 , 'endtm' : IiII [ iiiIiI ] [ 'endtm' ]
 }
    if 91 - 91: Ii11111i % i1IIi % iIii1I11I1II1
    IIi1I11I1II = int ( Ii1IOo0o0 + IiII [ iiiIiI ] [ 'starttm' ] )
    OooOoooOo = int ( Ii1IOo0o0 + IiII [ iiiIiI ] [ 'endtm' ] )
    if 46 - 46: Ii11111i
    if ii <= IIi1I11I1II or ( IIi1I11I1II < ii and ii < OooOoooOo ) :
     if 8 - 8: oO0o * OoOoOO00 - Ii1I - OoO0O00 * OOooOOo % I1IiiI
     oOOo0oOo0 . append ( oOoOooOo0o0 )
     if 48 - 48: O0
  return oOOo0oOo0
  if 11 - 11: I11i + OoooooooOO - OoO0O00 / o0oOOo0O0Ooo + Oo0Ooo . II111iiii
  if 41 - 41: Ii1I - O0 - O0
  if 68 - 68: OOooOOo % Ooo0OO0oOO
 def make_DateList ( self , days = 2 , dateType = '1' ) :
  II1I = [ ]
  ooO00OO0 = self . Get_Now_Datetime ( )
  if 31 - 31: Ii11111i % Ii11111i % I11i
  for OOOOoo0Oo in range ( days ) :
   ii111iI1iIi1 = ooO00OO0 + datetime . timedelta ( days = OOOOoo0Oo )
   if 78 - 78: OoO0O00 . OOooOOo + OoO0O00 / I11i / OoO0O00
   if dateType == '1' :
    II1I . append ( ii111iI1iIi1 . strftime ( '%Y-%m-%d' ) )
   else :
    II1I . append ( ii111iI1iIi1 . strftime ( '%Y%m%d' ) )
    if 54 - 54: OoOoOO00 % Ii11111i
  return II1I
  if 37 - 37: OoOoOO00 * Oo0Ooo / Ii - Ii11111i % II111iiii . oO0o
  if 88 - 88: Ii11111i . II111iiii * II111iiii % Ooo0OO0oOO
 def make_Tving_ChannleGroup ( self , channelid_list ) :
  iiIIiiIi1Ii11 = [ ]
  OOOOoo0Oo = 0
  Oo0 = ''
  if 70 - 70: I11i
  for iiOOooooO0Oo in channelid_list :
   if OOOOoo0Oo == 0 : Oo0 = iiOOooooO0Oo
   else : Oo0 += ',%s' % ( iiOOooooO0Oo )
   if 91 - 91: o0oOOo0O0Ooo . iIii1I11I1II1 / oO0o + i1IIi
   OOOOoo0Oo += 1
   if OOOOoo0Oo >= self . LIMIT_TVINGEPG :
    iiIIiiIi1Ii11 . append ( Oo0 )
    OOOOoo0Oo = 0
    Oo0 = ''
    if 42 - 42: Ii . o0oOOo0O0Ooo . Ii - I1ii11iIi11i
  if Oo0 != '' :
   iiIIiiIi1Ii11 . append ( Oo0 )
   if 40 - 40: Ii - i11iIiiIii / Ii1I
  return iiIIiiIi1Ii11
  if 35 - 35: Ii1I - I1IiiI % o0oOOo0O0Ooo . OoooooooOO % Ii1I
  if 47 - 47: Ii11111i - Ii1I . II111iiii + OoooooooOO . i11iIiiIii
 def Get_ChannelImg_Tving ( self , chid_list ) :
  OOoOO00OOO0OO = { }
  if 94 - 94: o0oOOo0O0Ooo * Ii1I / Oo0Ooo / Ii1I
  try :
   oO0 = self . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' )
   Oo000o = IiII [ 6 ] [ 'starttm' ]
   I11IiI1I11i1i = IiII [ 6 ] [ 'endtm' ]
   if 75 - 75: Ii + OoOoOO00 + o0oOOo0O0Ooo * I11i % oO0o . Ii11111i
   if 55 - 55: OOooOOo . I1IiiI
   iiIIiiIi1Ii11 = self . make_Tving_ChannleGroup ( chid_list )
   if 61 - 61: Oo0Ooo % iiI1i1 . Oo0Ooo
   for Ii1IOo0o0 in iiIIiiIi1Ii11 :
    ooOoo0O = self . API_TVING + '/v2/media/schedules'
    I11 = { 'pageNo' : '1'
 , 'pageSize' : str ( self . LIMIT_TVINGEPG )
    , 'order' : 'chno'
 , 'scope' : 'all'
 , 'adult' : 'n'
 , 'free' : 'all'
 , 'broadDate' : oO0
    , 'broadcastDate' : oO0
 , 'startBroadTime' : Oo000o
    , 'endBroadTime' : I11IiI1I11i1i
    , 'channelCode' : Ii1IOo0o0

 }
    I11 . update ( self . Get_DefaultParams_Tving ( ) )
    if 100 - 100: Ooo0OO0oOO * O0
    o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ooOoo0O , payload = None , params = I11 , headers = None , cookies = None )
    o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
    if 64 - 64: OOooOOo % iIii1I11I1II1 * oO0o
    if not ( 'result' in o0Oo00OOOOO [ 'body' ] ) : return { }
    OO0o00o = o0Oo00OOOOO [ 'body' ] [ 'result' ]
    if 79 - 79: O0
    for Ii1IOo0o0 in OO0o00o :
     if 78 - 78: I1ii11iIi11i + OOooOOo - Ooo0OO0oOO
     OOoOO00OOO0OO [ Ii1IOo0o0 [ 'channel_code' ] ] = self . API_TVINGIMG + Ii1IOo0o0 [ 'image' ] [ 2 ] [ 'url' ]
     if 38 - 38: o0oOOo0O0Ooo - oO0o + iIii1I11I1II1 / OoOoOO00 % Oo0Ooo
  except Exception as O000OO0 :
   print ( O000OO0 )
   return { }
   if 57 - 57: OoO0O00 / Ii
  return OOoOO00OOO0OO
  if 29 - 29: iIii1I11I1II1 + OoOoOO00 * OoO0O00 * OOooOOo . I1IiiI * I1IiiI
  if 7 - 7: iiI1i1 * Ooo0OO0oOO % Ii1I - o0oOOo0O0Ooo
 def Get_EpgInfo_Spotv ( self , days = 2 , payyn = True ) :
  i1i = { }
  oo0Ooo0 = [ ]
  oOOoo00O00o = [ ]
  if 98 - 98: OOooOOo + iiI1i1 + oO0o % OoooooooOO
  II1I = self . make_DateList ( days = days , dateType = '1' )
  if 97 - 97: O0 * OoooooooOO . OoooooooOO
  if 33 - 33: Ooo0OO0oOO + Ii11111i * oO0o / iIii1I11I1II1 - I1IiiI
  try :
   ooOoo0O = self . API_SPOTV + '/api/v2/channel'
   if 54 - 54: Ooo0OO0oOO / OOooOOo . oO0o % Ii11111i
   o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ooOoo0O , payload = None , params = None , headers = None , cookies = None )
   o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
   if 57 - 57: i11iIiiIii . I1ii11iIi11i - Ii1I - oO0o + OoOoOO00
   for Ii1IOo0o0 in o0Oo00OOOOO :
    I1i1iii = Ii1IOo0o0 [ 'videoId' ] . replace ( 'ref:' , '' )
    oOoOooOo0o0 = { 'channelid' : I1i1iii
 , 'channelnm' : self . xmlText ( Ii1IOo0o0 [ 'name' ] )
 , 'channelimg' : Ii1IOo0o0 [ 'logo' ]
 , 'ott' : 'spotv'
 }
    if 63 - 63: OoOoOO00 * Ii11111i
    if payyn == True or Ii1IOo0o0 [ 'free' ] == True :
     i1i [ Ii1IOo0o0 [ 'id' ] ] = I1i1iii
     oo0Ooo0 . append ( oOoOooOo0o0 )
     if 69 - 69: O0 . OoO0O00
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ] , [ ]
   if 49 - 49: I1IiiI - I11i
   if 74 - 74: iIii1I11I1II1 * I1ii11iIi11i + OoOoOO00 / i1IIi / II111iiii . Oo0Ooo
  try :
   for oooOo0OOOoo0 in II1I :
    ooOoo0O = self . API_SPOTV + '/api/v2/program/' + oooOo0OOOoo0
    if 51 - 51: Oo0Ooo / OoOoOO00 . OOooOOo * o0oOOo0O0Ooo + OoO0O00 * iiI1i1
    o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ooOoo0O , payload = None , params = None , headers = None , cookies = None )
    o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
    if 73 - 73: OoO0O00 + OoooooooOO - O0 - Ii1I - II111iiii
    for Ii1IOo0o0 in o0Oo00OOOOO :
     if i1i . get ( Ii1IOo0o0 [ 'channelId' ] ) == None : continue
     if 99 - 99: Ii . Ii1I + Ooo0OO0oOO + OoooooooOO % o0oOOo0O0Ooo
     oOoOooOo0o0 = { 'channelid' : i1i . get ( Ii1IOo0o0 [ 'channelId' ] )
 , 'title' : self . xmlText ( Ii1IOo0o0 [ 'title' ] )
 , 'startTime' : Ii1IOo0o0 [ 'startTime' ] . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' ) + '00'
 , 'endTime' : Ii1IOo0o0 [ 'endTime' ] . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' ) + '00'
 , 'ott' : 'spotv'
 }
     oOOoo00O00o . append ( oOoOooOo0o0 )
     if 51 - 51: iIii1I11I1II1
    time . sleep ( self . SLEEP_TIME )
    if 34 - 34: oO0o + I1IiiI - oO0o
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ] , [ ]
   if 17 - 17: II111iiii % Ii11111i + I11i - Ii11111i / OOooOOo + Ii
  return oo0Ooo0 , oOOoo00O00o
  if 59 - 59: OOooOOo % OoOoOO00 . Ii1I * I1ii11iIi11i % I11i
  if 59 - 59: oO0o - Ii11111i
 def Get_EpgInfo_Wavve ( self , days = 2 , exceptGroup = [ ] ) :
  oo0Ooo0 = [ ]
  oOOoo00O00o = [ ]
  I1I11I1I1I = [ ]
  if 15 - 15: Ooo0OO0oOO . i11iIiiIii . OoooooooOO / OoO0O00 % Ii1I
  if 93 - 93: O0 % i1IIi . OOooOOo / I1IiiI - Ooo0OO0oOO / I1IiiI
  if 36 - 36: oO0o % oO0o % i1IIi / i1IIi - Ii
  ooO00OO0 = self . Get_Now_Datetime ( )
  i1iI = ooO00OO0 + datetime . timedelta ( hours = - 2 )
  Oo0O0 = ooO00OO0 + datetime . timedelta ( days = ( days - 1 ) )
  if int ( i1iI . strftime ( '%H' ) ) <= 3 :
   Ooo0OOoOoO0 = i1iI . strftime ( '%Y-%m-%d 00:00' )
  else :
   Ooo0OOoOoO0 = i1iI . strftime ( '%Y-%m-%d %H:00' )
  oOo0OOoO0 = Oo0O0 . strftime ( '%Y-%m-%d 24:00' )
  if 11 - 11: I1ii11iIi11i . OoO0O00 * iiI1i1 * OoooooooOO + Ii
  if 33 - 33: O0 * o0oOOo0O0Ooo - Ooo0OO0oOO % Ooo0OO0oOO
  if 18 - 18: Ooo0OO0oOO / Oo0Ooo * Ooo0OO0oOO + Ooo0OO0oOO * i11iIiiIii * I1ii11iIi11i
  if exceptGroup != [ ] :
   I1I11I1I1I = self . Get_ChannelList_WavveExcept ( exceptGroup )
   if 11 - 11: Ii / OoOoOO00 - iiI1i1 * OoooooooOO + OoooooooOO . OoOoOO00
   if 26 - 26: Ii1I % I1ii11iIi11i
  try :
   ooOoo0O = self . API_WAVVE + '/live/epgs'
   I11 = { 'limit' : str ( self . LIMIT_WAVVE )
 , 'offset' : '0'
 , 'genre' : 'all'
 , 'startdatetime' : Ooo0OOoOoO0
 , 'enddatetime' : oOo0OOoO0
 }
   I11 . update ( self . Get_DefaultParams_Wavve ( ) )
   if 76 - 76: iiI1i1 * Ii11111i
   o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ooOoo0O , payload = None , params = I11 , headers = None , cookies = None )
   o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
   if 52 - 52: OOooOOo
   iiii1 = o0Oo00OOOOO [ 'list' ]
   if 96 - 96: i11iIiiIii % OOooOOo
   for Ii1IOo0o0 in iiii1 :
    oOoOooOo0o0 = { 'channelid' : Ii1IOo0o0 [ 'channelid' ]
 , 'channelnm' : Ii1IOo0o0 [ 'channelname' ]
 , 'channelimg' : self . HTTPTAG + Ii1IOo0o0 [ 'channelimage' ]
 , 'ott' : 'wavve'
 }
    if 70 - 70: iIii1I11I1II1
    if Ii1IOo0o0 [ 'channelid' ] not in I1I11I1I1I :
     oo0Ooo0 . append ( oOoOooOo0o0 )
     if 31 - 31: iiI1i1 - I1IiiI % iIii1I11I1II1
    for oooo0OOOO in Ii1IOo0o0 [ 'list' ] :
     oOoOooOo0o0 = { 'channelid' : Ii1IOo0o0 [ 'channelid' ]
 , 'title' : self . xmlText ( oooo0OOOO [ 'title' ] )
 , 'startTime' : oooo0OOOO [ 'starttime' ] . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' ) + '00'
     , 'endTime' : oooo0OOOO [ 'endtime' ] . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' ) + '00'
 , 'ott' : 'wavve'
 }
     if 54 - 54: i1IIi / iiI1i1 % OoO0O00 . I11i
     if 8 - 8: o0oOOo0O0Ooo . I1ii11iIi11i - I1IiiI . o0oOOo0O0Ooo
     if Ii1IOo0o0 [ 'channelid' ] not in I1I11I1I1I and oooo0OOOO [ 'starttime' ] != oooo0OOOO [ 'endtime' ] :
      oOOoo00O00o . append ( oOoOooOo0o0 )
      if 12 - 12: O0 - o0oOOo0O0Ooo
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ] , [ ]
   if 81 - 81: OoOoOO00 - OoOoOO00 . Ii11111i
   if 73 - 73: I11i % i11iIiiIii - I1IiiI
  Ii1iI111II1I1 = len ( oOOoo00O00o )
  for OOOOoo0Oo in ( range ( 1 , Ii1iI111II1I1 ) ) :
   if int ( oOOoo00O00o [ OOOOoo0Oo - 1 ] [ 'endTime' ] ) + 1 == int ( oOOoo00O00o [ OOOOoo0Oo ] [ 'startTime' ] ) and oOOoo00O00o [ OOOOoo0Oo - 1 ] [ 'channelid' ] == oOOoo00O00o [ OOOOoo0Oo ] [ 'channelid' ] :
    oOOoo00O00o [ OOOOoo0Oo - 1 ] [ 'endTime' ] = oOOoo00O00o [ OOOOoo0Oo ] [ 'startTime' ]
    if 91 - 91: OOooOOo % OOooOOo - I1IiiI
  return oo0Ooo0 , oOOoo00O00o
  if 18 - 18: I11i - i11iIiiIii / II111iiii . OOooOOo
  if 55 - 55: i1IIi % II111iiii + I11i * iIii1I11I1II1
 def Get_EpgInfo_Tving ( self , days = 2 ) :
  oo0Ooo0 = [ ]
  oOOoo00O00o = [ ]
  o0ooooO0o0O = [ ]
  if 24 - 24: O0 * o0oOOo0O0Ooo
  if 29 - 29: I1IiiI % OOooOOo - I1IiiI / OOooOOo . i1IIi
  i11III1111iIi = self . make_EpgDatetime_Tving ( days = days )
  if 38 - 38: Ii11111i + I11i / Ooo0OO0oOO % Ii - I1ii11iIi11i
  if 14 - 14: oO0o / Ooo0OO0oOO
  oo0Ooo0 = self . Get_ChannelList_Tving ( )
  ooo0O0o00O = [ ]
  for Ii1IOo0o0 in oo0Ooo0 :
   ooo0O0o00O . append ( Ii1IOo0o0 [ 'channelid' ] )
   if 48 - 48: Ii / Ooo0OO0oOO . iIii1I11I1II1 * OoOoOO00 * oO0o / i1IIi
   if 92 - 92: Oo0Ooo % Oo0Ooo - o0oOOo0O0Ooo / OoOoOO00
  I11IIIi = self . make_Tving_ChannleGroup ( ooo0O0o00O )
  if 15 - 15: I1ii11iIi11i * OoO0O00
  if 16 - 16: Ii11111i + OoOoOO00
  try :
   ooOoo0O = self . API_TVING + '/v2/media/schedules'
   if 66 - 66: Ii11111i / oO0o * OoooooooOO + OoooooooOO % I11i
   for IIii1111 in i11III1111iIi :
    for I1iI in I11IIIi :
     if 38 - 38: oO0o % OoOoOO00 + I1ii11iIi11i . i11iIiiIii
     I11 = { 'pageNo' : '1'
 , 'pageSize' : str ( self . LIMIT_TVINGEPG )
     , 'order' : 'chno'
 , 'scope' : 'all'
 , 'adult' : 'n'
 , 'free' : 'all'
 , 'broadDate' : IIii1111 [ 'ndate' ]
     , 'broadcastDate' : IIii1111 [ 'ndate' ]
 , 'startBroadTime' : IIii1111 [ 'starttm' ]
     , 'endBroadTime' : IIii1111 [ 'endtm' ]
     , 'channelCode' : I1iI

 }
     I11 . update ( self . Get_DefaultParams_Tving ( ) )
     if 53 - 53: i11iIiiIii * Ii11111i
     o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ooOoo0O , payload = None , params = I11 , headers = None , cookies = None )
     o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
     if 68 - 68: iIii1I11I1II1 * iIii1I11I1II1 . o0oOOo0O0Ooo / II111iiii % Oo0Ooo
     OO0o00o = o0Oo00OOOOO [ 'body' ] [ 'result' ]
     if 38 - 38: Ii - OOooOOo / Ii11111i
     for Ii1IOo0o0 in OO0o00o :
      if 66 - 66: O0 % I1ii11iIi11i + i11iIiiIii . OoOoOO00 / Ii1I + I1ii11iIi11i
      if not ( 'schedules' in Ii1IOo0o0 ) : continue
      if 86 - 86: o0oOOo0O0Ooo
      for i1Iii11Ii1i1 in Ii1IOo0o0 [ 'schedules' ] :
       oOoOooOo0o0 = { 'channelid' : i1Iii11Ii1i1 [ 'schedule_code' ]
 , 'title' : self . xmlText ( i1Iii11Ii1i1 [ 'program' ] [ 'name' ] [ 'ko' ] )
 , 'startTime' : str ( i1Iii11Ii1i1 [ 'broadcast_start_time' ] )
 , 'endTime' : str ( i1Iii11Ii1i1 [ 'broadcast_end_time' ] )
 , 'ott' : 'tving'
 }
       OOooo0O0o0 = i1Iii11Ii1i1 [ 'schedule_code' ] + str ( i1Iii11Ii1i1 [ 'broadcast_start_time' ] )
       if OOooo0O0o0 in o0ooooO0o0O : continue
       if 14 - 14: o0oOOo0O0Ooo % O0 * Ii11111i + Ii1I + Oo0Ooo * Ii1I
       o0ooooO0o0O . append ( OOooo0O0o0 )
       oOOoo00O00o . append ( oOoOooOo0o0 )
       if 3 - 3: OoOoOO00 * Oo0Ooo
     time . sleep ( self . SLEEP_TIME )
     if 95 - 95: OOooOOo % oO0o . Ii1I
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ] , [ ]
   if 72 - 72: OoooooooOO
  return oo0Ooo0 , oOOoo00O00o
  if 72 - 72: I1IiiI % i11iIiiIii . Oo0Ooo / II111iiii
  if 14 - 14: I1ii11iIi11i + OoO0O00
  if 3 - 3: I1ii11iIi11i . Oo0Ooo / II111iiii
  if 39 - 39: Ooo0OO0oOO
  if 91 - 91: OoooooooOO - iIii1I11I1II1 + OoOoOO00 / OoO0O00 . OoOoOO00 + O0
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
