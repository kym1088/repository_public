# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
import os
import sys
import xbmcaddon
import urllib
import urlparse
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
__cwd__ = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) )
__lib__ = os . path . join ( __cwd__ , 'resources' , 'lib' )
sys . path . append ( __lib__ )
if 46 - 46: ooOoO0o * I11i - OoooooooOO
from boritvRun import *
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
def ooO0oo0oO0 ( ) :
 oo00 = urlparse . parse_qs ( sys . argv [ 2 ] [ 1 : ] )
 for o00 in oo00 . keys ( ) :
  oo00 [ o00 ] = oo00 [ o00 ] [ 0 ]
 return oo00
 if 62 - 62: i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
 if 61 - 61: oO0o / OoOoOO00 / iII111i * OoO0O00 . II111iiii
 if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + IiII . I1Ii111
Oooo0000 = OOooo0000ooo ( sys . argv [ 0 ] , int ( sys . argv [ 1 ] ) , ooO0oo0oO0 ( ) )
Oooo0000 . boritv_main ( )
if 22 - 22: Ii1I . IiII
if 41 - 41: I1Ii111 . ooOoO0o * IiII % i11iIiiIii
if 74 - 74: iII111i * IiII
if 82 - 82: iIii1I11I1II1 % IiII
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
