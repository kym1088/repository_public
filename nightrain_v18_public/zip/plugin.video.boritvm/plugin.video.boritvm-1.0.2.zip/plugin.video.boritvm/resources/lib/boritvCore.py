# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import urllib
import re
import json
import sys
import requests
import datetime
import time
import os
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
from channelgenre import *
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
i1I1ii1II1iII = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
oooO0oo0oOOOO = [ { 'starttm' : '000000' , 'endtm' : '030000' }
 , { 'starttm' : '030000' , 'endtm' : '060000' }
 , { 'starttm' : '060000' , 'endtm' : '090000' }
 , { 'starttm' : '090000' , 'endtm' : '120000' }
 , { 'starttm' : '120000' , 'endtm' : '150000' }
 , { 'starttm' : '150000' , 'endtm' : '180000' }
 , { 'starttm' : '180000' , 'endtm' : '210000' }
 , { 'starttm' : '210000' , 'endtm' : '240000' }
 ]
if 53 - 53: I11i / Oo0Ooo / II111iiii % Ii1I / OoOoOO00 . ooOoO0o
if 100 - 100: i1IIi
if 27 - 27: IiII * OoooooooOO + I11i * ooOoO0o - i11iIiiIii - iII111i
class xIiiiIiI1iIiI1 ( object ) :
 def __init__ ( self ) :
  self . API_WAVVE = 'https://apis.wavve.com'
  self . API_TVING = 'https://api.tving.com'
  self . API_TVINGIMG = 'https://image.tving.com'
  self . API_SPOTV = 'https://www.spotvnow.co.kr'
  self . HTTPTAG = 'https://'
  self . LIMIT_WAVVE = 200
  self . LIMIT_TVING = 60
  self . LIMIT_TVINGEPG = 20
  self . DEFAULT_HEADER = { 'user-agent' : i1I1ii1II1iII }
  self . SLEEP_TIME = 0.2
  self . INIT_GENRESORT = MASTER_GENRE
  self . INIT_CHANNEL = MASTER_CHANNEL
  if 85 - 85: OoO0O00
  if 28 - 28: Ii1I
 def callRequestCookies ( self , jobtype , url , payload = None , params = None , headers = None , cookies = None , redirects = False ) :
  oOOoo00O0O = self . DEFAULT_HEADER
  if headers : oOOoo00O0O . update ( headers )
  if 15 - 15: I1IiiI
  if jobtype == 'Get' :
   O0ooo00OOo00 = requests . get ( url , params = params , headers = oOOoo00O0O , cookies = cookies , allow_redirects = redirects )
  else :
   O0ooo00OOo00 = requests . post ( url , data = payload , params = params , headers = oOOoo00O0O , cookies = cookies , allow_redirects = redirects )
   if 98 - 98: i11iIiiIii * I1IiiI % iII111i * iII111i * II111iiii
  return O0ooo00OOo00
  if 79 - 79: IiII
 def Get_DefaultParams_Wavve ( self ) :
  oOo0oooo00o = { 'apikey' : 'E5F3E0D30947AA5440556471321BB6D9'
 , 'credential' : 'none'
 , 'device' : 'pc'
 , 'drm' : 'wm'
 , 'partner' : 'pooq'
 , 'pooqzone' : 'none'
 , 'region' : 'kor'
 , 'targetage' : 'all'
 }
  return oOo0oooo00o
  if 65 - 65: o0oOOo0O0Ooo * iIii1I11I1II1 * ooOoO0o
 def Get_DefaultParams_Tving ( self ) :
  oOo0oooo00o = { 'apiKey' : '1e7952d0917d6aab1f0293a063697610'
 , 'networkCode' : 'CSND0900'
 , 'osCode' : 'CSOD0900'
  , 'teleCode' : 'CSCD0900'
 , 'screenCode' : 'CSSD0100'
 }
  return oOo0oooo00o
  if 18 - 18: iIii1I11I1II1 / I11i + oO0o / Oo0Ooo - II111iiii - I11i
  if 1 - 1: I11i - OOooOOo % O0 + I1IiiI - iII111i / I11i
 def Get_Now_Datetime ( self ) :
  if 31 - 31: OoO0O00 + II111iiii
  return datetime . datetime . utcnow ( ) + datetime . timedelta ( hours = 9 )
  if 13 - 13: OOooOOo * oO0o * I1IiiI
  if 55 - 55: II111iiii
  if 43 - 43: OoOoOO00 - i1IIi + I1Ii111 + Ii1I
 def xmlText ( self , in_text ) :
  if 17 - 17: o0oOOo0O0Ooo
  o00ooooO0oO = in_text . replace ( '<' , '(' ) . replace ( '>' , ')' ) . replace ( '&lt;' , '(' ) . replace ( '&gt;' , ')' ) . replace ( '&' , '&amp;' )
  if 63 - 63: OoOoOO00 % i1IIi
  if 66 - 66: Ii1I
  return o00ooooO0oO
  if 78 - 78: OoO0O00
  if 18 - 18: O0 - iII111i / iII111i + ooOoO0o % ooOoO0o - IiII
 def Get_ChannelList_Wavve ( self , exceptGroup = [ ] ) :
  O0O00Ooo = [ ]
  OOoooooO = [ ]
  if 14 - 14: I11i % O0
  if 41 - 41: i1IIi + I1Ii111 + OOooOOo - IiII
  oO = self . Get_ChannelImg_Wavve ( )
  if 76 - 76: OoO0O00 * o0oOOo0O0Ooo % i1IIi - OoO0O00 / I1IiiI . OOooOOo
  if 41 - 41: OoOoOO00
  if exceptGroup != [ ] :
   OOoooooO = self . Get_ChannelList_WavveExcept ( exceptGroup )
   if 13 - 13: Oo0Ooo . i11iIiiIii - iIii1I11I1II1 - OoOoOO00
  try :
   ii1I = self . API_WAVVE + '/cf/live/recommend-channels'
   oOo0oooo00o = { 'WeekDay' : 'all'
 , 'broadcastid' : '30783'
 , 'contenttype' : 'channel'
 , 'isrecommend' : 'y'
 , 'limit' : str ( self . LIMIT_WAVVE )
   , 'offset' : '0'
 , 'uicode' : 'LN58'
 , 'uiparent' : 'GN54-LN58'
 , 'uirank' : '4'
 , 'uitype' : 'LN58'
 }
   if 76 - 76: O0 / o0oOOo0O0Ooo . I1IiiI * Ii1I - OOooOOo
   oOo0oooo00o . update ( self . Get_DefaultParams_Wavve ( ) )
   if 76 - 76: i11iIiiIii / iIii1I11I1II1 . I1ii11iIi11i % OOooOOo / OoooooooOO % oO0o
   o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ii1I , payload = None , params = oOo0oooo00o , headers = None , cookies = None )
   o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
   if 85 - 85: ooOoO0o . iII111i - OoO0O00 % ooOoO0o % II111iiii
   if not ( 'celllist' in o0Oo00OOOOO [ 'cell_toplist' ] ) : return O0O00Ooo
   OO0o00o = o0Oo00OOOOO [ 'cell_toplist' ] [ 'celllist' ]
   if 89 - 89: oO0o + Oo0Ooo
   for Ii1IOo0o0 in OO0o00o :
    if 49 - 49: oO0o % Ii1I + i1IIi . I1IiiI % I1ii11iIi11i
    I1i1iii = Ii1IOo0o0 [ 'contentid' ]
    i1iiI11I = Ii1IOo0o0 [ 'title_list' ] [ 0 ] [ 'text' ]
    if 29 - 29: OoooooooOO
    if I1i1iii in oO :
     iI = oO [ I1i1iii ]
    else :
     iI = ''
     if 28 - 28: OOooOOo - IiII . IiII + OoOoOO00 - OoooooooOO + O0
    oOoOooOo0o0 = { 'channelid' : I1i1iii
 , 'channelnm' : i1iiI11I
 , 'channelimg' : self . HTTPTAG + iI if iI != '' else ''
 , 'ott' : 'wavve'
 , 'genrenm' : self . make_getGenre ( I1i1iii , 'wavve' )
 }
    if 61 - 61: o0oOOo0O0Ooo / OoO0O00 + ooOoO0o * oO0o / oO0o
    if I1i1iii not in OOoooooO :
     O0O00Ooo . append ( oOoOooOo0o0 )
     if 75 - 75: i1IIi / OoooooooOO - O0 / OoOoOO00 . II111iiii - i1IIi
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ]
   if 43 - 43: I1Ii111 - O0 % I1IiiI . I11i
  return O0O00Ooo
  if 57 - 57: OOooOOo . OOooOOo
  if 95 - 95: O0 + OoO0O00 . II111iiii / O0
 def Get_ChannelList_WavveExcept ( self , exceptGroup = [ ] ) :
  O0O00Ooo = [ ]
  if exceptGroup == [ ] : return [ ]
  if 97 - 97: ooOoO0o - OOooOOo * i11iIiiIii / OoOoOO00 % I1Ii111 - OoooooooOO
  try :
   ii1I = self . API_WAVVE + '/cf/live/recommend-channels'
   if 59 - 59: O0 + I1IiiI + IiII % I1IiiI
   for Ii1IOo0o0 in exceptGroup :
    oOo0oooo00o = { 'WeekDay' : 'all'
 , 'adult' : 'n'
 , 'broadcastid' : Ii1IOo0o0 [ 'broadcastid' ]
    , 'contenttype' : 'channel'
 , 'genre' : Ii1IOo0o0 [ 'genre' ]
    , 'isrecommend' : 'y'
 , 'limit' : str ( self . LIMIT_WAVVE )
    , 'offset' : '0'
 , 'uicode' : 'LN58'
 , 'uiparent' : 'GN54-LN58'
 , 'uirank' : '4'
 , 'uitype' : 'LN58'
 }
    if 70 - 70: iII111i * I1ii11iIi11i
    oOo0oooo00o . update ( self . Get_DefaultParams_Wavve ( ) )
    if 46 - 46: ooOoO0o / OoO0O00
    o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ii1I , payload = None , params = oOo0oooo00o , headers = None , cookies = None )
    o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
    if 52 - 52: o0oOOo0O0Ooo - OoooooooOO + Ii1I + Ii1I - o0oOOo0O0Ooo / I1Ii111
    if not ( 'celllist' in o0Oo00OOOOO [ 'cell_toplist' ] ) : return O0O00Ooo
    OO0o00o = o0Oo00OOOOO [ 'cell_toplist' ] [ 'celllist' ]
    if 44 - 44: ooOoO0o . i1IIi - I1ii11iIi11i . O0 - ooOoO0o
    for Ii1IOo0o0 in OO0o00o :
     O0O00Ooo . append ( Ii1IOo0o0 [ 'contentid' ] )
     if 92 - 92: iII111i . I11i + o0oOOo0O0Ooo
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ]
   if 28 - 28: i1IIi * Oo0Ooo - o0oOOo0O0Ooo * IiII * Ii1I / OoO0O00
  return O0O00Ooo
  if 94 - 94: II111iiii % I1ii11iIi11i / OoOoOO00 * iIii1I11I1II1
  if 54 - 54: o0oOOo0O0Ooo - I1IiiI + OoooooooOO
  if 70 - 70: Ii1I / I11i . iII111i % Oo0Ooo
 def Get_ChannelImg_Wavve ( self ) :
  OOoOO00OOO0OO = { }
  if 16 - 16: I1IiiI * oO0o % IiII
  try :
   Oo000o = self . Get_Now_Datetime ( )
   I11IiI1I11i1i = Oo000o + datetime . timedelta ( hours = 3 )
   if 38 - 38: o0oOOo0O0Ooo
   ii1I = self . API_WAVVE + '/live/epgs'
   oOo0oooo00o = { 'limit' : str ( self . LIMIT_WAVVE )
   , 'offset' : '0'
 , 'genre' : 'all'
 , 'startdatetime' : Oo000o . strftime ( '%Y-%m-%d %H:00' )
 , 'enddatetime' : I11IiI1I11i1i . strftime ( '%Y-%m-%d %H:00' )
 }
   oOo0oooo00o . update ( self . Get_DefaultParams_Wavve ( ) )
   if 57 - 57: O0 / oO0o * I1Ii111 / OoOoOO00 . II111iiii
   o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ii1I , payload = None , params = oOo0oooo00o , headers = None , cookies = None )
   o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
   if 26 - 26: iII111i
   OO0o00o = o0Oo00OOOOO [ 'list' ]
   if 91 - 91: OoO0O00 . I1ii11iIi11i + OoO0O00 - iII111i / OoooooooOO
   for Ii1IOo0o0 in OO0o00o :
    OOoOO00OOO0OO [ Ii1IOo0o0 [ 'channelid' ] ] = Ii1IOo0o0 [ 'channelimage' ]
    if 39 - 39: I1ii11iIi11i / ooOoO0o - II111iiii
  except Exception as O000OO0 :
   print ( O000OO0 )
   if 98 - 98: I1ii11iIi11i / I11i % oO0o . OoOoOO00
  return OOoOO00OOO0OO
  if 91 - 91: oO0o % Oo0Ooo
 def Get_ChanneGenrename_Wavve ( self , channelid ) :
  if 64 - 64: I11i % iII111i - I1Ii111 - oO0o
  try :
   ii1I = self . API_WAVVE + '/live/channels/' + channelid
   if 31 - 31: I11i - II111iiii . I11i
   oOo0oooo00o = self . Get_DefaultParams_Wavve ( )
   if 18 - 18: o0oOOo0O0Ooo
   o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ii1I , payload = None , params = oOo0oooo00o , headers = None , cookies = None )
   o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
   if 98 - 98: iII111i * iII111i / iII111i + I11i
   ii111111I1iII = o0Oo00OOOOO [ 'genretext' ]
   if 68 - 68: iII111i - iIii1I11I1II1 * i11iIiiIii / I1ii11iIi11i * I1Ii111
  except Exception as O000OO0 :
   print ( O000OO0 )
   return ''
   if 23 - 23: iII111i
  return ii111111I1iII
  if 91 - 91: iIii1I11I1II1 + I1Ii111
  if 31 - 31: IiII . OoOoOO00 . OOooOOo
 def Get_ChannelList_Spotv ( self , payyn = True ) :
  O0O00Ooo = [ ]
  if 75 - 75: I11i + OoO0O00 . OoOoOO00 . ooOoO0o + Oo0Ooo . OoO0O00
  try :
   ii1I = self . API_SPOTV + '/api/v2/channel'
   if 96 - 96: OOooOOo . ooOoO0o - Oo0Ooo + iIii1I11I1II1 / OoOoOO00 * OOooOOo
   o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ii1I , payload = None , params = None , headers = None , cookies = None )
   o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
   if 65 - 65: Ii1I . iIii1I11I1II1 / O0 - Ii1I
   for Ii1IOo0o0 in o0Oo00OOOOO :
    I1i1iii = Ii1IOo0o0 [ 'videoId' ] . replace ( 'ref:' , '' )
    oOoOooOo0o0 = { 'channelid' : I1i1iii
 , 'channelnm' : Ii1IOo0o0 [ 'name' ]
 , 'channelimg' : Ii1IOo0o0 [ 'logo' ]
 , 'ott' : 'spotv'
 , 'genrenm' : self . make_getGenre ( I1i1iii , 'spotv' )

    # IiII / I1IiiI
    }
    if payyn == True or Ii1IOo0o0 [ 'free' ] == True :
     O0O00Ooo . append ( oOoOooOo0o0 )
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ]
   if 15 - 15: IiII . iIii1I11I1II1 . OoooooooOO / i11iIiiIii - Ii1I . i1IIi
  return O0O00Ooo
  if 33 - 33: I11i . o0oOOo0O0Ooo
  if 75 - 75: o0oOOo0O0Ooo % o0oOOo0O0Ooo . I1Ii111
 def Get_ChannelList_Tving ( self ) :
  O0O00Ooo = [ ]
  III1iII1I1ii = [ ]
  if 61 - 61: II111iiii
  try :
   ii1I = self . API_TVING + '/v2/media/lives'
   oOo0oooo00o = { 'pageNo' : '1'
 , 'pageSize' : str ( self . LIMIT_TVING )
   , 'order' : 'rating'
   , 'adult' : 'all'
 , 'free' : 'all'
 , 'guest' : 'all'
 , 'scope' : 'all'
 , 'channelType' : 'CPCS0100,CPCS0400'

   # I1IiiI - o0oOOo0O0Ooo * oO0o + O0
   }
   if 71 - 71: Ii1I - i1IIi % i1IIi + OoOoOO00 + O0 + OoO0O00
   oOo0oooo00o . update ( self . Get_DefaultParams_Tving ( ) )
   if 67 - 67: I1Ii111 . iII111i . O0
   o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ii1I , payload = None , params = oOo0oooo00o , headers = None , cookies = None )
   o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
   if 10 - 10: I1ii11iIi11i % I1ii11iIi11i - iIii1I11I1II1 / OOooOOo + Ii1I
   if not ( 'result' in o0Oo00OOOOO [ 'body' ] ) : return O0O00Ooo
   OO0o00o = o0Oo00OOOOO [ 'body' ] [ 'result' ]
   if 87 - 87: oO0o * I1ii11iIi11i + OOooOOo / iIii1I11I1II1 / iII111i
   if 37 - 37: iII111i - ooOoO0o * oO0o % i11iIiiIii - I1Ii111
   for Ii1IOo0o0 in OO0o00o :
    if Ii1IOo0o0 [ 'live_code' ] == 'C44441' : continue
    III1iII1I1ii . append ( Ii1IOo0o0 [ 'live_code' ] )
    if 83 - 83: I11i / I1IiiI
    if 34 - 34: IiII
    if 57 - 57: oO0o . I11i . i1IIi
   oO = self . Get_ChannelImg_Tving ( III1iII1I1ii )
   if 42 - 42: I11i + I1ii11iIi11i % O0
   if 6 - 6: oO0o
   if 68 - 68: OoOoOO00 - OoO0O00
   for Ii1IOo0o0 in OO0o00o :
    if 28 - 28: OoO0O00 . OOooOOo / OOooOOo + Oo0Ooo . I1ii11iIi11i
    I1i1iii = Ii1IOo0o0 [ 'live_code' ]
    if I1i1iii == 'C44441' : continue
    i1iiI11I = Ii1IOo0o0 [ 'schedule' ] [ 'channel' ] [ 'name' ] [ 'ko' ]
    if 1 - 1: iIii1I11I1II1 / II111iiii
    if I1i1iii in oO :
     iI = oO [ I1i1iii ]
    else :
     iI = ''
     if 33 - 33: I11i
    oOoOooOo0o0 = { 'channelid' : I1i1iii
 , 'channelnm' : i1iiI11I
 , 'channelimg' : iI
 , 'ott' : 'tving'
 , 'genrenm' : self . make_getGenre ( I1i1iii , 'tving' )
 }
    if 18 - 18: o0oOOo0O0Ooo % iII111i * O0
    O0O00Ooo . append ( oOoOooOo0o0 )
    if 87 - 87: i11iIiiIii
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ]
   if 93 - 93: I1ii11iIi11i - OoO0O00 % i11iIiiIii . iII111i / iII111i - I1Ii111
  return O0O00Ooo
  if 9 - 9: I1ii11iIi11i / Oo0Ooo - I1IiiI / OoooooooOO / iIii1I11I1II1 - o0oOOo0O0Ooo
  if 91 - 91: iII111i % i1IIi % iIii1I11I1II1
  if 20 - 20: OOooOOo % Ii1I / Ii1I + Ii1I
 def make_EpgDatetime_Tving ( self , days = 2 ) :
  III1IiiI = [ ]
  if 31 - 31: o0oOOo0O0Ooo . I1IiiI
  ii11IIII11I = self . make_DateList ( days = 2 , dateType = '2' )
  if 81 - 81: OoOoOO00 / O0 . IiII . I1IiiI
  OoOO = int ( self . Get_Now_Datetime ( ) . strftime ( '%Y%m%d%H0000' ) )
  if 53 - 53: Oo0Ooo
  for Ii1IOo0o0 in ii11IIII11I :
   for iI1Iii in range ( 8 ) :
    oOoOooOo0o0 = { 'ndate' : Ii1IOo0o0
 , 'starttm' : oooO0oo0oOOOO [ iI1Iii ] [ 'starttm' ]
 , 'endtm' : oooO0oo0oOOOO [ iI1Iii ] [ 'endtm' ]
 }
    if 68 - 68: OOooOOo % I1Ii111
    ooO00OO0 = int ( Ii1IOo0o0 + oooO0oo0oOOOO [ iI1Iii ] [ 'starttm' ] )
    i11111IIIII = int ( Ii1IOo0o0 + oooO0oo0oOOOO [ iI1Iii ] [ 'endtm' ] )
    if 19 - 19: OoOoOO00 * i1IIi
    if OoOO <= ooO00OO0 or ( ooO00OO0 < OoOO and OoOO < i11111IIIII ) :
     if 14 - 14: iII111i
     III1IiiI . append ( oOoOooOo0o0 )
     if 11 - 11: IiII * I1IiiI . iIii1I11I1II1 % OoooooooOO + iII111i
  return III1IiiI
  if 78 - 78: OoO0O00 . OOooOOo + OoO0O00 / I11i / OoO0O00
  if 54 - 54: OoOoOO00 % iII111i
  if 37 - 37: OoOoOO00 * Oo0Ooo / ooOoO0o - iII111i % II111iiii . oO0o
 def make_DateList ( self , days = 2 , dateType = '1' ) :
  ii11IIII11I = [ ]
  O00 = self . Get_Now_Datetime ( )
  if 29 - 29: I1Ii111 / OoO0O00 . i1IIi * I1IiiI + i11iIiiIii
  if dateType == '1' :
   O00 = O00 - datetime . timedelta ( days = 1 )
   if 6 - 6: ooOoO0o / i11iIiiIii + iII111i * oO0o
   if 80 - 80: II111iiii
  for O0O in range ( days ) :
   i1I1I = O00 + datetime . timedelta ( days = O0O )
   if 12 - 12: i11iIiiIii / OoO0O00
   if dateType == '1' :
    ii11IIII11I . append ( i1I1I . strftime ( '%Y-%m-%d' ) )
   else :
    ii11IIII11I . append ( i1I1I . strftime ( '%Y%m%d' ) )
    if 80 - 80: I1Ii111 . i11iIiiIii - o0oOOo0O0Ooo
  return ii11IIII11I
  if 25 - 25: OoO0O00
  if 62 - 62: OOooOOo + O0
 def make_Tving_ChannleGroup ( self , channelid_list ) :
  oO0OOOO0 = [ ]
  O0O = 0
  iI1I11iiI1i = ''
  if 78 - 78: oO0o % O0 % Ii1I
  for ii in channelid_list :
   if O0O == 0 : iI1I11iiI1i = ii
   else : iI1I11iiI1i += ',%s' % ( ii )
   if 5 - 5: ooOoO0o - II111iiii - OoooooooOO % Ii1I + I1IiiI * iIii1I11I1II1
   O0O += 1
   if O0O >= self . LIMIT_TVINGEPG :
    oO0OOOO0 . append ( iI1I11iiI1i )
    O0O = 0
    iI1I11iiI1i = ''
    if 37 - 37: IiII % ooOoO0o + OoOoOO00 + o0oOOo0O0Ooo * I11i % O0
  if iI1I11iiI1i != '' :
   oO0OOOO0 . append ( iI1I11iiI1i )
   if 61 - 61: I1IiiI - OOooOOo . oO0o / OOooOOo + Oo0Ooo
  return oO0OOOO0
  if 5 - 5: ooOoO0o + ooOoO0o / O0 * Oo0Ooo - OOooOOo % ooOoO0o
  if 15 - 15: i11iIiiIii % Ii1I . Oo0Ooo + I1ii11iIi11i
 def Get_ChannelImg_Tving ( self , chid_list ) :
  OOoOO00OOO0OO = { }
  if 61 - 61: Oo0Ooo * I1ii11iIi11i % Oo0Ooo - i1IIi - iIii1I11I1II1
  try :
   oOooO0 = self . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' )
   Oo000o = oooO0oo0oOOOO [ 6 ] [ 'starttm' ]
   I11IiI1I11i1i = oooO0oo0oOOOO [ 6 ] [ 'endtm' ]
   if 29 - 29: iIii1I11I1II1 + OoOoOO00 * OoO0O00 * OOooOOo . I1IiiI * I1IiiI
   if 7 - 7: IiII * I1Ii111 % Ii1I - o0oOOo0O0Ooo
   oO0OOOO0 = self . make_Tving_ChannleGroup ( chid_list )
   if 13 - 13: Ii1I . i11iIiiIii
   for Ii1IOo0o0 in oO0OOOO0 :
    ii1I = self . API_TVING + '/v2/media/schedules'
    oOo0oooo00o = { 'pageNo' : '1'
 , 'pageSize' : str ( self . LIMIT_TVINGEPG )
    , 'order' : 'chno'
 , 'scope' : 'all'
 , 'adult' : 'n'
 , 'free' : 'all'
 , 'broadDate' : oOooO0
    , 'broadcastDate' : oOooO0
 , 'startBroadTime' : Oo000o
    , 'endBroadTime' : I11IiI1I11i1i
    , 'channelCode' : Ii1IOo0o0

 }
    oOo0oooo00o . update ( self . Get_DefaultParams_Tving ( ) )
    if 56 - 56: I1ii11iIi11i % O0 - I1IiiI
    o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ii1I , payload = None , params = oOo0oooo00o , headers = None , cookies = None )
    o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
    if 100 - 100: Ii1I - O0 % oO0o * OOooOOo + I1IiiI
    if not ( 'result' in o0Oo00OOOOO [ 'body' ] ) : return { }
    OO0o00o = o0Oo00OOOOO [ 'body' ] [ 'result' ]
    if 88 - 88: OoooooooOO - OoO0O00 * O0 * OoooooooOO . OoooooooOO
    for Ii1IOo0o0 in OO0o00o :
     if 33 - 33: I1Ii111 + iII111i * oO0o / iIii1I11I1II1 - I1IiiI
     OOoOO00OOO0OO [ Ii1IOo0o0 [ 'channel_code' ] ] = self . API_TVINGIMG + Ii1IOo0o0 [ 'image' ] [ 2 ] [ 'url' ]
     if 54 - 54: I1Ii111 / OOooOOo . oO0o % iII111i
  except Exception as O000OO0 :
   print ( O000OO0 )
   return { }
   if 57 - 57: i11iIiiIii . I1ii11iIi11i - Ii1I - oO0o + OoOoOO00
  return OOoOO00OOO0OO
  if 63 - 63: OoOoOO00 * iII111i
  if 69 - 69: O0 . OoO0O00
 def Get_EpgInfo_Spotv ( self , days = 3 , payyn = True ) :
  ii1111iII = { }
  O0O00Ooo = [ ]
  iiiiI = [ ]
  if 62 - 62: OoooooooOO * I1IiiI
  ii11IIII11I = self . make_DateList ( days = days , dateType = '1' )
  if 58 - 58: OoOoOO00 % o0oOOo0O0Ooo
  if 50 - 50: I1Ii111 . o0oOOo0O0Ooo
  if 97 - 97: O0 + OoOoOO00
  try :
   ii1I = self . API_SPOTV + '/api/v2/channel'
   if 89 - 89: o0oOOo0O0Ooo + OoO0O00 * I11i * Ii1I
   o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ii1I , payload = None , params = None , headers = None , cookies = None )
   o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
   if 37 - 37: OoooooooOO - O0 - o0oOOo0O0Ooo
   for Ii1IOo0o0 in o0Oo00OOOOO :
    I1i1iii = Ii1IOo0o0 [ 'videoId' ] . replace ( 'ref:' , '' )
    oOoOooOo0o0 = { 'channelid' : I1i1iii
 , 'channelnm' : self . xmlText ( Ii1IOo0o0 [ 'name' ] )
 , 'channelimg' : Ii1IOo0o0 [ 'logo' ]
 , 'ott' : 'spotv'
 }
    if 77 - 77: OOooOOo * iIii1I11I1II1
    if payyn == True or Ii1IOo0o0 [ 'free' ] == True :
     ii1111iII [ Ii1IOo0o0 [ 'id' ] ] = I1i1iii
     O0O00Ooo . append ( oOoOooOo0o0 )
     if 98 - 98: I1IiiI % Ii1I * OoooooooOO
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ] , [ ]
   if 51 - 51: iIii1I11I1II1 . OoOoOO00 / oO0o + o0oOOo0O0Ooo
   if 33 - 33: ooOoO0o . II111iiii % iII111i + o0oOOo0O0Ooo
  try :
   for oO00O000oO0 in ii11IIII11I :
    ii1I = self . API_SPOTV + '/api/v2/program/' + oO00O000oO0
    if 79 - 79: I11i - OoooooooOO - oO0o - iIii1I11I1II1 * OOooOOo
    o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ii1I , payload = None , params = None , headers = None , cookies = None )
    o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
    if 4 - 4: i11iIiiIii . OoooooooOO / OoO0O00 % I1Ii111 % I11i * O0
    for Ii1IOo0o0 in o0Oo00OOOOO :
     if ii1111iII . get ( Ii1IOo0o0 [ 'channelId' ] ) == None : continue
     if 14 - 14: OOooOOo / o0oOOo0O0Ooo
     oOoOooOo0o0 = { 'channelid' : ii1111iII . get ( Ii1IOo0o0 [ 'channelId' ] )
 , 'title' : self . xmlText ( Ii1IOo0o0 [ 'title' ] )
 , 'startTime' : Ii1IOo0o0 [ 'startTime' ] . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' ) + '00'
 , 'endTime' : Ii1IOo0o0 [ 'endTime' ] . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' ) + '00'
 , 'ott' : 'spotv'
 }
     iiiiI . append ( oOoOooOo0o0 )
     if 32 - 32: I1IiiI * Oo0Ooo
    time . sleep ( self . SLEEP_TIME )
    if 78 - 78: OOooOOo - OoooooooOO - I1ii11iIi11i / ooOoO0o / II111iiii
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ] , [ ]
   if 29 - 29: I1IiiI % I1IiiI
  return O0O00Ooo , iiiiI
  if 94 - 94: iIii1I11I1II1 / Oo0Ooo % iII111i * iII111i * II111iiii
  if 29 - 29: OoO0O00 + OoOoOO00 / o0oOOo0O0Ooo / OOooOOo * iIii1I11I1II1
 def Get_EpgInfo_Wavve ( self , days = 2 , exceptGroup = [ ] ) :
  O0O00Ooo = [ ]
  iiiiI = [ ]
  OOoooooO = [ ]
  if 62 - 62: OOooOOo / oO0o - OoO0O00 . I11i
  if 11 - 11: I1ii11iIi11i . OoO0O00 * IiII * OoooooooOO + ooOoO0o
  if 33 - 33: O0 * o0oOOo0O0Ooo - I1Ii111 % I1Ii111
  O00 = self . Get_Now_Datetime ( )
  I11I = O00 + datetime . timedelta ( hours = - 2 )
  I11iIi1i1II11 = O00 + datetime . timedelta ( days = ( days - 1 ) )
  if int ( I11I . strftime ( '%H' ) ) <= 3 :
   iiI = I11I . strftime ( '%Y-%m-%d 00:00' )
  else :
   iiI = I11I . strftime ( '%Y-%m-%d %H:00' )
  i1I1i111Ii = I11iIi1i1II11 . strftime ( '%Y-%m-%d 24:00' )
  if 67 - 67: I1IiiI . i1IIi
  if 27 - 27: ooOoO0o % I1IiiI
  if 73 - 73: OOooOOo
  if exceptGroup != [ ] :
   OOoooooO = self . Get_ChannelList_WavveExcept ( exceptGroup )
   if 70 - 70: iIii1I11I1II1
   if 31 - 31: IiII - I1IiiI % iIii1I11I1II1
  try :
   ii1I = self . API_WAVVE + '/live/epgs'
   oOo0oooo00o = { 'limit' : str ( self . LIMIT_WAVVE )
 , 'offset' : '0'
 , 'genre' : 'all'
 , 'startdatetime' : iiI
 , 'enddatetime' : i1I1i111Ii
 }
   oOo0oooo00o . update ( self . Get_DefaultParams_Wavve ( ) )
   if 92 - 92: i1IIi - iIii1I11I1II1
   o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ii1I , payload = None , params = oOo0oooo00o , headers = None , cookies = None )
   o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
   if 16 - 16: OoO0O00 - OoOoOO00 - OOooOOo - i1IIi / Ii1I
   o0oOoOO = o0Oo00OOOOO [ 'list' ]
   if 58 - 58: I1IiiI
   for Ii1IOo0o0 in o0oOoOO :
    oOoOooOo0o0 = { 'channelid' : Ii1IOo0o0 [ 'channelid' ]
 , 'channelnm' : self . xmlText ( Ii1IOo0o0 [ 'channelname' ] )
 , 'channelimg' : self . HTTPTAG + Ii1IOo0o0 [ 'channelimage' ]
 , 'ott' : 'wavve'
 }
    if 53 - 53: i1IIi
    if Ii1IOo0o0 [ 'channelid' ] not in OOoooooO :
     O0O00Ooo . append ( oOoOooOo0o0 )
     if 59 - 59: o0oOOo0O0Ooo
    for oOoO00O0 in Ii1IOo0o0 [ 'list' ] :
     oOoOooOo0o0 = { 'channelid' : Ii1IOo0o0 [ 'channelid' ]
 , 'title' : self . xmlText ( oOoO00O0 [ 'title' ] )
 , 'startTime' : oOoO00O0 [ 'starttime' ] . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' ) + '00'
     , 'endTime' : oOoO00O0 [ 'endtime' ] . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' ) + '00'
 , 'ott' : 'wavve'
 }
     if 75 - 75: I1IiiI . ooOoO0o . O0 * I1Ii111
     if 4 - 4: Ii1I % oO0o * OoO0O00
     if Ii1IOo0o0 [ 'channelid' ] not in OOoooooO and oOoO00O0 [ 'starttime' ] != oOoO00O0 [ 'endtime' ] :
      iiiiI . append ( oOoOooOo0o0 )
      if 100 - 100: I1Ii111 * OOooOOo + OOooOOo
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ] , [ ]
   if 54 - 54: OoooooooOO + o0oOOo0O0Ooo - i1IIi % i11iIiiIii
   if 3 - 3: o0oOOo0O0Ooo % o0oOOo0O0Ooo
  oo00o0 = len ( iiiiI )
  for O0O in ( range ( 1 , oo00o0 ) ) :
   if int ( iiiiI [ O0O - 1 ] [ 'endTime' ] ) + 1 == int ( iiiiI [ O0O ] [ 'startTime' ] ) and iiiiI [ O0O - 1 ] [ 'channelid' ] == iiiiI [ O0O ] [ 'channelid' ] :
    iiiiI [ O0O - 1 ] [ 'endTime' ] = iiiiI [ O0O ] [ 'startTime' ]
    if 42 - 42: i11iIiiIii * iIii1I11I1II1 / I1ii11iIi11i . i11iIiiIii % I11i
  return O0O00Ooo , iiiiI
  if 41 - 41: IiII / O0
  if 51 - 51: I11i % I1IiiI
 def Get_EpgInfo_Tving ( self , days = 2 ) :
  O0O00Ooo = [ ]
  iiiiI = [ ]
  OooOo = [ ]
  if 31 - 31: I1Ii111
  if 88 - 88: OoO0O00 - ooOoO0o + OOooOOo * I1IiiI % iIii1I11I1II1 + Oo0Ooo
  oo000O0OoooO = self . make_EpgDatetime_Tving ( days = days )
  if 93 - 93: I11i . II111iiii / oO0o % OoooooooOO * I11i % I1ii11iIi11i
  if 48 - 48: ooOoO0o / I1Ii111 . iIii1I11I1II1 * OoOoOO00 * oO0o / i1IIi
  if 92 - 92: Oo0Ooo % Oo0Ooo - o0oOOo0O0Ooo / OoOoOO00
  if 10 - 10: iII111i + Oo0Ooo * I1ii11iIi11i + iIii1I11I1II1 / I1Ii111 / I1ii11iIi11i
  O0O00Ooo = self . Get_ChannelList_Tving ( )
  iI1II = [ ]
  if 69 - 69: ooOoO0o % oO0o
  if 50 - 50: OoooooooOO % I11i
  for O0O in range ( len ( O0O00Ooo ) ) :
   O0O00Ooo [ O0O ] [ 'channelnm' ] = self . xmlText ( O0O00Ooo [ O0O ] [ 'channelnm' ] )
   iI1II . append ( O0O00Ooo [ O0O ] [ 'channelid' ] )
   if 49 - 49: oO0o - i11iIiiIii . I1Ii111 * Ii1I % iII111i + i1IIi
   if 71 - 71: o0oOOo0O0Ooo
   if 38 - 38: oO0o % OoOoOO00 + I1ii11iIi11i . i11iIiiIii
   if 53 - 53: i11iIiiIii * iII111i
  OooooO0oOOOO = self . make_Tving_ChannleGroup ( iI1II )
  if 100 - 100: iII111i % OOooOOo
  try :
   ii1I = self . API_TVING + '/v2/media/schedules'
   if 86 - 86: Oo0Ooo . O0 - OoooooooOO . OoO0O00 + Ii1I
   for OOo in oo000O0OoooO :
    if 22 - 22: OoOoOO00 * O0 . IiII * i11iIiiIii - I1IiiI * ooOoO0o
    for OOooo0O0o0 in OooooO0oOOOO :
     if 14 - 14: o0oOOo0O0Ooo % O0 * iII111i + Ii1I + Oo0Ooo * Ii1I
     oOo0oooo00o = { 'pageNo' : '1'
 , 'pageSize' : str ( self . LIMIT_TVINGEPG )
     , 'order' : 'chno'
 , 'scope' : 'all'
 , 'adult' : 'n'
 , 'free' : 'all'
 , 'broadDate' : OOo [ 'ndate' ]
     , 'broadcastDate' : OOo [ 'ndate' ]
 , 'startBroadTime' : OOo [ 'starttm' ]
     , 'endBroadTime' : OOo [ 'endtm' ]
     , 'channelCode' : OOooo0O0o0

 }
     oOo0oooo00o . update ( self . Get_DefaultParams_Tving ( ) )
     if 3 - 3: OoOoOO00 * Oo0Ooo
     o0ooo00O0o0 = self . callRequestCookies ( 'Get' , ii1I , payload = None , params = oOo0oooo00o , headers = None , cookies = None )
     o0Oo00OOOOO = json . loads ( o0ooo00O0o0 . text )
     if 95 - 95: OOooOOo % oO0o . Ii1I
     if 72 - 72: OoooooooOO
     OO0o00o = o0Oo00OOOOO [ 'body' ] [ 'result' ]
     for Ii1IOo0o0 in OO0o00o :
      if 72 - 72: I1IiiI % i11iIiiIii . Oo0Ooo / II111iiii
      if 'schedules' not in Ii1IOo0o0 : continue
      if Ii1IOo0o0 [ 'schedules' ] == None : continue
      if 14 - 14: I1ii11iIi11i + OoO0O00
      for iIi in Ii1IOo0o0 [ 'schedules' ] :
       oOoOooOo0o0 = { 'channelid' : iIi [ 'schedule_code' ]
 , 'title' : self . xmlText ( iIi [ 'program' ] [ 'name' ] [ 'ko' ] )
 , 'startTime' : str ( iIi [ 'broadcast_start_time' ] )
 , 'endTime' : str ( iIi [ 'broadcast_end_time' ] )
 , 'ott' : 'tving'
 }
       ii111I = iIi [ 'schedule_code' ] + str ( iIi [ 'broadcast_start_time' ] )
       if ii111I in OooOo : continue
       if 17 - 17: I1IiiI . O0 + OoO0O00
       OooOo . append ( ii111I )
       iiiiI . append ( oOoOooOo0o0 )
       if 43 - 43: II111iiii . oO0o / I1ii11iIi11i
     time . sleep ( self . SLEEP_TIME )
     if 20 - 20: I1IiiI
  except Exception as O000OO0 :
   print ( O000OO0 )
   return [ ] , [ ]
   if 95 - 95: iII111i - I1IiiI
  return O0O00Ooo , iiiiI
  if 34 - 34: ooOoO0o * I1IiiI . i1IIi * ooOoO0o / ooOoO0o
  if 30 - 30: I1ii11iIi11i + Oo0Ooo / Oo0Ooo % I1ii11iIi11i . I1ii11iIi11i
 def make_getGenre ( self , channelid , ott ) :
  try :
   ii111111I1iII = self . INIT_CHANNEL . get ( channelid + '.' + ott ) . get ( 'genre' )
  except :
   ii111111I1iII = '-'
  return ii111111I1iII
  if 55 - 55: ooOoO0o - I11i + II111iiii + iII111i % Ii1I
  if 41 - 41: i1IIi - I11i - Ii1I
 def make_base_allchannel_py ( self ) :
  III11I1 = [ ]
  IIi1IIIi = [ ]
  O00Ooo = set ( )
  if 52 - 52: I1ii11iIi11i - Oo0Ooo + I1ii11iIi11i % o0oOOo0O0Ooo
  oOoOooOo0o0 = self . Get_ChannelList_Wavve ( )
  III11I1 . extend ( oOoOooOo0o0 )
  if 35 - 35: iIii1I11I1II1
  oOoOooOo0o0 = self . Get_ChannelList_Tving ( )
  III11I1 . extend ( oOoOooOo0o0 )
  if 42 - 42: I1Ii111 . I1IiiI . i1IIi + OoOoOO00 + OOooOOo + I1IiiI
  oOoOooOo0o0 = self . Get_ChannelList_Spotv ( )
  III11I1 . extend ( oOoOooOo0o0 )
  if 31 - 31: iII111i . OOooOOo - ooOoO0o . OoooooooOO / OoooooooOO
  if 56 - 56: OoO0O00 / oO0o / i11iIiiIii + OoooooooOO - Oo0Ooo - I11i
  print ( '1' )
  for O0O in range ( len ( III11I1 ) ) :
   if III11I1 [ O0O ] [ 'genrenm' ] == '-' :
    if III11I1 [ O0O ] [ 'ott' ] == 'wavve' :
     ii111111I1iII = self . Get_ChanneGenrename_Wavve ( III11I1 [ O0O ] [ 'channelid' ] )
     if ii111111I1iII not in O00Ooo : O00Ooo . add ( ii111111I1iII )
     time . sleep ( self . SLEEP_TIME )
    elif III11I1 [ O0O ] [ 'ott' ] == 'spotv' :
     ii111111I1iII = '스포츠'
    else :
     ii111111I1iII = '-'
    III11I1 [ O0O ] [ 'genrenm' ] = ii111111I1iII
   else :
    if III11I1 [ O0O ] [ 'genrenm' ] not in O00Ooo : O00Ooo . add ( III11I1 [ O0O ] [ 'genrenm' ] )
    if 21 - 21: O0 % IiII . I1IiiI / II111iiii + IiII
  O00Ooo . add ( '-' )
  if 53 - 53: oO0o - I1IiiI - oO0o * iII111i
  if 71 - 71: O0 - iIii1I11I1II1
  print ( '2' )
  for i1II in O00Ooo :
   for iI1I in III11I1 :
    if iI1I [ 'genrenm' ] == i1II :
     IIi1IIIi . append ( iI1I )
     if 100 - 100: iIii1I11I1II1 + OoOoOO00 / Oo0Ooo . i11iIiiIii
  for iI1I in III11I1 :
   if iI1I [ 'genrenm' ] not in O00Ooo :
    SORT_LIST . append ( iI1I )
    if 14 - 14: o0oOOo0O0Ooo * OOooOOo + iII111i + O0 + i11iIiiIii
    if 77 - 77: o0oOOo0O0Ooo / OoooooooOO
  print ( '3' )
  IIii11I1i1I = 'c:\\job\\channelgenre.json'
  if os . path . isfile ( IIii11I1i1I ) : os . remove ( IIii11I1i1I )
  if 99 - 99: iII111i
  oOO0O00o0OO0O = open ( IIii11I1i1I , 'w' )
  oOO0O00o0OO0O . write ( 'MASTER_CHANNEL = {\n' )
  if 17 - 17: i1IIi
  iiIi1i = len ( IIi1IIIi )
  O0O = 0
  for Ii1IOo0o0 in IIi1IIIi :
   O0O += 1
   I1i1iii = Ii1IOo0o0 [ 'channelid' ]
   i1iiI11I = Ii1IOo0o0 [ 'channelnm' ]
   I1i11111i1i11 = Ii1IOo0o0 [ 'ott' ]
   OOoOOO0 = '%s.%s' % ( I1i1iii , I1i11111i1i11 )
   ii111111I1iII = Ii1IOo0o0 [ 'genrenm' ]
   if 10 - 10: I1Ii111 / ooOoO0o + i11iIiiIii / Ii1I
   OOOoOoO = '\t"%s" : { "channelnm" : "%s", "genre" : "%s" }' % ( OOoOOO0 , i1iiI11I , ii111111I1iII )
   if O0O < iiIi1i :
    oOO0O00o0OO0O . write ( OOOoOoO + ',\n' )
   else :
    oOO0O00o0OO0O . write ( OOOoOoO + '\n' )
    if 22 - 22: I1IiiI % I1ii11iIi11i
  oOO0O00o0OO0O . write ( '}\n' )
  oOO0O00o0OO0O . close ( )
  if 57 - 57: OOooOOo + O0 . Ii1I
  return O00Ooo
  if 46 - 46: IiII
  if 45 - 45: ooOoO0o
  if 21 - 21: oO0o . I1Ii111 . OOooOOo / Oo0Ooo / I1Ii111
  if 17 - 17: OOooOOo / OOooOOo / I11i
  if 1 - 1: i1IIi . i11iIiiIii % OOooOOo
  if 82 - 82: iIii1I11I1II1 + Oo0Ooo . iIii1I11I1II1 % IiII / Ii1I . Ii1I
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
