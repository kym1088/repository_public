# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import json
import time
import datetime
import random
import os
import sys
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
try :
 import xbmc , xbmcaddon
 IiII1IiiIiI1 = 'ADDON'
except :
 IiII1IiiIiI1 = 'SINGLE'
 if 40 - 40: oo * OoO0O00
if IiII1IiiIiI1 == 'ADDON' :
 __addon__ = xbmcaddon . Addon ( )
 __version__ = __addon__ . getAddonInfo ( 'version' )
 __addonid__ = __addon__ . getAddonInfo ( 'id' )
 __profile__ = xbmc . translatePath ( __addon__ . getAddonInfo ( 'profile' ) )
 if 2 - 2: ooOO00oOo % oOo0O0Ooo * Ooo00oOo00o . oOoO0oo0OOOo + iiiiIi11i
 def Ii1I ( string ) :
  log_message = str ( string ) . encode ( 'utf-8' , 'ignore' )
  level = xbmc . LOGNOTICE
  xbmc . log ( "[%s-%s]: %s" % ( __addonid__ , __version__ , log_message ) , level = level )
  if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 def O0oOO0o0 ( ) :
  return True if __addon__ . getSetting ( 'autoEpg' ) == 'true' else False
  if 9 - 9: o0o - OOO0o0o
 def Ii1iI ( ) :
  return xbmc . translatePath ( os . path . join ( __profile__ , 'boritv_update.json' ) )
  if 100 - 100: i1IIi . o0o / o00O0oo * OoooooooOO + IiII * iiiiIi11i
else :
 def Ii1I ( string ) :
  print ( string )
  if 99 - 99: ooOoO0o . iII111i / iIii1I11I1II1 * iIii1I11I1II1
 def O0oOO0o0 ( ) :
  return True
  if 11 - 11: iiiiIi11i / i1IIi % II111iiii - oOo0O0Ooo
 def Ii1iI ( ) :
  return 'c:\\job\\boritv_update.json'
  if 91 - 91: ooOO00oOo . i11iIiiIii / iiiiIi11i % IiII / ooOO00oOo - i11iIiiIii
  if 8 - 8: Ooo00oOo00o * oOoO0oo0OOOo * iIii1I11I1II1 . o00O0oo / o00O0oo % o00O0oo
  if 22 - 22: I1Ii111 . o00O0oo
  if 41 - 41: o0o . OOO0o0o * o00O0oo % i11iIiiIii
class xxo000o0o00o0Oo ( ) :
 if 80 - 80: OoooooooOO . oo
 def __init__ ( self ) :
  if 87 - 87: iiiiIi11i / OOO0o0o + o0o - OOO0o0o . OOO0o0o / II111iiii
  self . START_INTERVAL = 10
  self . INTERVAL = 10
  self . EPG_FILETAGNM = 'date_makeepg'
  self . EPG_MAKEDATE = '-'
  self . EPG_WILL_TM = - 1
  if 11 - 11: oo % Ooo00oOo00o - OoO0O00
  if 58 - 58: i11iIiiIii % o0o
 def Get_Now_Datetime ( self ) :
  if 54 - 54: iII111i % O0 + oo - ooOoO0o / IiII
  return datetime . datetime . utcnow ( ) + datetime . timedelta ( hours = 9 )
  if 31 - 31: ooOO00oOo + II111iiii
  if 13 - 13: iII111i * iiiiIi11i * oo
 def MakeEpg_DateCheck ( self ) :
  if 55 - 55: II111iiii
  if 43 - 43: oOo0O0Ooo - i1IIi + o0o + I1Ii111
  if 17 - 17: Ooo00oOo00o
  if 64 - 64: I1Ii111 % i1IIi % OoooooooOO
  if 3 - 3: ooOoO0o + O0
  I1Ii = '-'
  if 66 - 66: I1Ii111
  if 78 - 78: ooOO00oOo
  if self . EPG_MAKEDATE == '-' :
   try :
    Iii1I111 = open ( Ii1iI ( ) , 'r' )
    OO0O0O00OooO = json . load ( Iii1I111 )
    Iii1I111 . close ( )
    I1Ii = OO0O0O00OooO [ self . EPG_FILETAGNM ]
   except Exception as OoooooOoo :
    return 5
  else :
   I1Ii = self . EPG_MAKEDATE
   if 70 - 70: ooOO00oOo . ooOO00oOo - ooOO00oOo / oOoO0oo0OOOo * iII111i
   if 86 - 86: i11iIiiIii + I1Ii111 + OOO0o0o * IiII + Ooo00oOo00o
  oOoO = self . Get_Now_Datetime ( )
  oOo = ( oOoO - datetime . timedelta ( days = 1 ) ) . strftime ( '%Y-%m-%d' )
  oOoOoO = oOoO . strftime ( '%Y-%m-%d' )
  ii1I = oOoO . strftime ( '%H' )
  if 76 - 76: O0 / Ooo00oOo00o . oo * I1Ii111 - iII111i
  if 76 - 76: i11iIiiIii / iIii1I11I1II1 . oOoO0oo0OOOo % iII111i / OoooooooOO % iiiiIi11i
  if 75 - 75: ooOoO0o
  if I1Ii == oOoOoO : return - 1
  if 97 - 97: i11iIiiIii
  if 32 - 32: OoO0O00 * O0 % iiiiIi11i % I1Ii111 . o00O0oo
  if I1Ii == oOo and ii1I == '00' : return 30
  if 61 - 61: OOO0o0o
  if 79 - 79: OoO0O00 + oo - ooOoO0o
  return 5
  if 83 - 83: OOO0o0o
  if 64 - 64: ooOO00oOo % OOO0o0o % ooOoO0o / oOo0O0Ooo - ooOO00oOo
  if 74 - 74: ooOoO0o * O0
 def MakeEpg_RandomTm ( self , mintm ) :
  oOOo0oo = ( mintm * 60 ) + random . randint ( 0 , 300 )
  if 80 - 80: IiII * i11iIiiIii / o0o
  if 9 - 9: I1Ii111 + iiiiIi11i % I1Ii111 + i1IIi . iII111i
  oOoO = self . Get_Now_Datetime ( )
  III1i1i = ( oOoO + datetime . timedelta ( seconds = oOOo0oo ) ) . strftime ( '%Y%m%d%H%M%S' )
  return int ( III1i1i )
  if 26 - 26: OoooooooOO
  if 12 - 12: OoooooooOO % oOo0O0Ooo / OOO0o0o % Ooo00oOo00o
 def MakeEpg_SaveJson ( self ) :
  OO0O0O00OooO = { self . EPG_FILETAGNM : self . Get_Now_Datetime ( ) . strftime ( '%Y-%m-%d' ) }
  try :
   Iii1I111 = open ( Ii1iI ( ) , 'w' )
   json . dump ( OO0O0O00OooO , Iii1I111 )
   Iii1I111 . close ( )
  except Exception as OoooooOoo :
   return
   if 29 - 29: OoooooooOO
   if 23 - 23: Ooo00oOo00o . II111iiii
   if 98 - 98: iIii1I11I1II1 % oOo0O0Ooo * oOoO0oo0OOOo * oOo0O0Ooo
 def service_run ( self ) :
  if 45 - 45: o0o . oOo0O0Ooo
  if O0oOO0o0 ( ) == False : return
  if 83 - 83: iiiiIi11i . iIii1I11I1II1 . oOoO0oo0OOOo
  if 31 - 31: I1Ii111 . I1Ii111 - Ooo00oOo00o / ooOO00oOo + OOO0o0o * oo
  if 63 - 63: o0o % i1IIi / OoooooooOO - OoooooooOO
  if 8 - 8: oOo0O0Ooo
  if 60 - 60: IiII / IiII
  if 46 - 46: I1Ii111 * iII111i - ooOO00oOo * iiiiIi11i - o0o
  if 83 - 83: OoooooooOO
  Iii111II = self . MakeEpg_DateCheck ( )
  if 9 - 9: ooOO00oOo
  if 33 - 33: OOO0o0o . ooOoO0o
  if Iii111II < 0 :
   if 58 - 58: iII111i * i11iIiiIii / oOo0O0Ooo % o0o - oOoO0oo0OOOo / iiiiIi11i
   return
   if 50 - 50: oo
  if self . EPG_WILL_TM < 0 :
   self . EPG_WILL_TM = self . MakeEpg_RandomTm ( Iii111II )
   Ii1I ( 'EPG_WILL_TM --> ' + str ( self . EPG_WILL_TM ) )
  else :
   oOoOoO = self . Get_Now_Datetime ( )
   if self . EPG_WILL_TM < int ( oOoOoO . strftime ( '%Y%m%d%H%M%S' ) ) :
    if 34 - 34: oo * II111iiii % ooOoO0o * oOo0O0Ooo - oo
    if 33 - 33: Ooo00oOo00o + iII111i * ooOO00oOo - OoO0O00 / iiiiIi11i % I1Ii111
    Ii1I ( 'make epg' )
    xbmc . executebuiltin ( 'RunPlugin("plugin://plugin.video.boritvm/?mode=ADD_EPG&sName=%ec%a0%84%ec%b2%b4&sType=all&&sNoti=N")' )
    self . MakeEpg_SaveJson ( )
    if 21 - 21: ooOO00oOo * iIii1I11I1II1 % iiiiIi11i * i1IIi
    if 16 - 16: O0 - o0o * iIii1I11I1II1 + ooOoO0o
    self . EPG_MAKEDATE = oOoOoO . strftime ( '%Y-%m-%d' )
    self . EPG_WILL_TM = - 1
   else :
    if 50 - 50: II111iiii - OOO0o0o * oOoO0oo0OOOo / o0o + Ooo00oOo00o
    pass
    if 88 - 88: I1Ii111 / o0o + ooOoO0o - II111iiii / OOO0o0o - oOo0O0Ooo
  pass
  if 15 - 15: oOoO0oo0OOOo + oOo0O0Ooo - OoooooooOO / iII111i
  if 58 - 58: i11iIiiIii % IiII
  if 71 - 71: iII111i + OOO0o0o % i11iIiiIii + oOoO0oo0OOOo - o00O0oo
  if 88 - 88: oOo0O0Ooo - ooOO00oOo % iII111i
  if 16 - 16: oo * iiiiIi11i % o00O0oo
  if 86 - 86: oo + I1Ii111 % i11iIiiIii * iiiiIi11i . OOO0o0o * IiII
  if 44 - 44: iiiiIi11i
if __name__ == "__main__" :
 if 88 - 88: o0o % I1Ii111 . II111iiii
 Ii1I ( '__main__' )
 iI1ii1Ii = o000o0o00o0Oo ( )
 time . sleep ( iI1ii1Ii . START_INTERVAL )
 if 92 - 92: oOo0O0Ooo
 while True :
  time . sleep ( iI1ii1Ii . INTERVAL )
  iI1ii1Ii . service_run ( )
  pass
  if 26 - 26: ooOoO0o . o0o
  if 68 - 68: ooOO00oOo
  if 35 - 35: ooOO00oOo - ooOoO0o / OoO0O00 / oOo0O0Ooo
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
