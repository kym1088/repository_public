# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import os
import xbmcplugin , xbmcgui , xbmcaddon , xbmc
import sys
import datetime
import time
import urllib
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 73 - 73: II111iiii
xIiII1IiiIiI1 = [
 { 'title' : '*** 간단설명 (개별 OTT 애드온 필수) ***' , 'mode' : 'XXX' }
 , { 'title' : '     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)' , 'mode' : 'XXX' }
 , { 'title' : '     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)' , 'mode' : 'XXX' }
 , { 'title' : '-----------------' , 'mode' : 'XXX' }
 , { 'title' : '-> M3U 파일 초기화/삭제' , 'mode' : 'DEL_M3U' }
 , { 'title' : '     - M3U 추가 (웨이브)' , 'mode' : 'ADD_M3U' , 'sType' : 'wavve' , 'sName' : '웨이브' }
 , { 'title' : '     - M3U 추가 (티빙)' , 'mode' : 'ADD_M3U' , 'sType' : 'tving' , 'sName' : '티빙' }
 , { 'title' : '     - M3U 추가 (스포티비)' , 'mode' : 'ADD_M3U' , 'sType' : 'spotv' , 'sName' : '스포티비나우' }
 , { 'title' : '-> M3U (삭제후 일괄생성)' , 'mode' : 'ADD_M3U' , 'sType' : 'all' , 'sName' : '전체' }
 , { 'title' : '-----------------' , 'mode' : 'XXX' }
 , { 'title' : '-> EPG 생성 (삭제후 일괄생성)' , 'mode' : 'ADD_EPG' , 'sType' : 'all' , 'sName' : '전체' }
 ]
if 40 - 40: oo * OoO0O00
if 2 - 2: ooOO00oOo % oOo0O0Ooo * Ooo00oOo00o . oOoO0oo0OOOo + iiiiIi11i
__addon__ = xbmcaddon . Addon ( )
__language__ = __addon__ . getLocalizedString
__profile__ = xbmc . translatePath ( __addon__ . getAddonInfo ( 'profile' ) )
__version__ = __addon__ . getAddonInfo ( 'version' )
__addonid__ = __addon__ . getAddonInfo ( 'id' )
__addonname__ = __addon__ . getAddonInfo ( 'name' )
if 24 - 24: II11iiII / OoOO0ooOOoo0O + o0000oOoOoO0o * i1I1ii1II1iII % oooO0oo0oOOOO
if 53 - 53: o0oo0o / Oo + o0oo0o / oooO0oo0oOOOO * OoooooooOO + i1I1ii1II1iII
OOo0oO0oooOoO = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
ooO00oOoo = xbmc . translatePath ( os . path . join ( __profile__ , 'boritv_update.json' ) )
if 78 - 78: OoOO0ooOOoo0O / ooOO00oOo - O0 . oooO0oo0oOOOO
from boritvCore import *
if 91 - 91: oOoO0oo0OOOo * iIii1I11I1II1 . oooO0oo0oOOOO / o0000oOoOoO0o
if 87 - 87: i1IIi / o0000oOoOoO0o . ooOO00oOo * OoooooooOO - oooO0oo0oOOOO * Oo
class O0I11i1i11i1I ( object ) :
 def __init__ ( self , in_addonurl , in_handle , in_params ) :
  self . _addon_url = in_addonurl
  self . _addon_handle = in_handle
  self . main_params = in_params
  self . M3U_FILE_PATH = ''
  self . M3U_FILE_NAME = ''
  self . M3U_ONWAVVE = False
  self . M3U_ONTVING = False
  self . M3U_ONSPOTV = False
  self . M3U_ONWAVVERADIO = False
  self . M3U_ONWAVVEHOME = False
  self . M3U_ONSPOTVPAY = False
  self . M3U_DISPLAYNM = False
  self . BoritvObj = xIiiiIiI1iIiI1 ( )
  if 31 - 31: i11iIiiIii / oo / Oo * iiiiIi11i / OoO0O00
  if 99 - 99: iIii1I11I1II1 * OoooooooOO * II111iiii * iIii1I11I1II1
  if 44 - 44: iiiiIi11i / OoO0O00 - II111iiii - i11iIiiIii % o0oo0o
 def addon_noti ( self , sting ) :
  try :
   O0OoOoo00o = xbmcgui . Dialog ( )
   O0OoOoo00o . notification ( __addonname__ , sting )
  except :
   None
   if 31 - 31: II111iiii + ooOO00oOo . o0oo0o
   if 68 - 68: oo - i11iIiiIii - ooOO00oOo / II11iiII - ooOO00oOo + i1IIi
   if 48 - 48: OoooooooOO % Ooo00oOo00o . oo - o0000oOoOoO0o % i1IIi % OoooooooOO
 def addon_log ( self , string ) :
  try :
   i1iIIi1 = string . encode ( 'utf-8' , 'ignore' )
  except :
   i1iIIi1 = 'addonException: addon_log'
   if 50 - 50: i11iIiiIii - o0000oOoOoO0o
   if 78 - 78: ooOO00oOo
  Iii1I111 = xbmc . LOGINFO
  xbmc . log ( "[%s-%s]: %s" % ( __addonid__ , __version__ , i1iIIi1 ) , level = Iii1I111 )
  if 60 - 60: iiiiIi11i * Ooo00oOo00o % Ooo00oOo00o % OoOO0ooOOoo0O * II111iiii + i1IIi
  if 64 - 64: iiiiIi11i - O0 / II111iiii / Ooo00oOo00o / iIii1I11I1II1
  if 24 - 24: O0 % Ooo00oOo00o + i1IIi + o0oo0o + oOoO0oo0OOOo
  if 70 - 70: OoO0O00 % OoO0O00 . oooO0oo0oOOOO % ooOO00oOo * Ooo00oOo00o % iiiiIi11i
 def get_keyboard_input ( self , title ) :
  iiI1IiI = None
  II = xbmc . Keyboard ( )
  II . setHeading ( title )
  xbmc . sleep ( 1000 )
  II . doModal ( )
  if ( II . isConfirmed ( ) ) :
   iiI1IiI = II . getText ( )
  return iiI1IiI
  if 57 - 57: iiiiIi11i
  if 14 - 14: OoO0O00 . oo / o0000oOoOoO0o
  if 38 - 38: II111iiii % i11iIiiIii . Oo - II11iiII + o0000oOoOoO0o
  if 66 - 66: OoooooooOO * OoooooooOO . II11iiII . i1IIi - II11iiII
 def add_dir ( self , label , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = '' ) :
  o0o00ooo0 = '%s?%s' % ( self . _addon_url , urllib . urlencode ( params ) )
  if 96 - 96: O0 % iiiiIi11i % iIii1I11I1II1
  if sublabel : Oo00OOOOO = '%s < %s >' % ( label , sublabel )
  else : Oo00OOOOO = label
  if not img : img = 'DefaultFolder.png'
  if 85 - 85: Oo . i1I1ii1II1iII - ooOO00oOo % Oo % II111iiii
  OO0o00o = xbmcgui . ListItem ( Oo00OOOOO )
  OO0o00o . setArt ( { 'thumbnailImage' : img , 'icon' : img , 'poster' : img } )
  if 89 - 89: iiiiIi11i + OoO0O00
  if infoLabels : OO0o00o . setInfo ( type = "video" , infoLabels = infoLabels )
  if not isFolder : OO0o00o . setProperty ( 'IsPlayable' , 'true' )
  if 3 - 3: i1IIi / oo % OoOO0ooOOoo0O * i11iIiiIii / O0 * OoOO0ooOOoo0O
  xbmcplugin . addDirectoryItem ( self . _addon_handle , o0o00ooo0 , OO0o00o , isFolder )
  if 49 - 49: iiiiIi11i % o0000oOoOoO0o + i1IIi . oo % oOoO0oo0OOOo
  if 48 - 48: OoOO0ooOOoo0O + OoOO0ooOOoo0O / II111iiii / iIii1I11I1II1
  if 20 - 20: Ooo00oOo00o
  if 77 - 77: oOo0O0Ooo / OoOO0ooOOoo0O
 def make_M3u_Filename ( self ) :
  return self . M3U_FILE_PATH + self . M3U_FILE_NAME + '.m3u'
  if 98 - 98: iIii1I11I1II1 / i1IIi / i11iIiiIii / Ooo00oOo00o
  if 28 - 28: II11iiII - oooO0oo0oOOOO . oooO0oo0oOOOO + oOo0O0Ooo - OoooooooOO + O0
  if 95 - 95: ooOO00oOo % iiiiIi11i . O0
  if 15 - 15: Oo / o0000oOoOoO0o . o0000oOoOoO0o - i1IIi
 def make_Epg_Filename ( self ) :
  return self . M3U_FILE_PATH + self . M3U_FILE_NAME + '.xml'
  if 53 - 53: oooO0oo0oOOOO + oo * iiiiIi11i
  if 61 - 61: i1IIi * II11iiII / OoooooooOO . i11iIiiIii . oOo0O0Ooo
  if 60 - 60: OoOO0ooOOoo0O / OoOO0ooOOoo0O
  if 46 - 46: o0000oOoOoO0o * II11iiII - ooOO00oOo * iiiiIi11i - o0oo0o
 def dp_Main_List ( self ) :
  if 83 - 83: OoooooooOO
  for Iii111II in xIiII1IiiIiI1 :
   Oo00OOOOO = Iii111II . get ( 'title' )
   if 9 - 9: ooOO00oOo
   i11 = { 'mode' : Iii111II . get ( 'mode' )
 , 'sType' : Iii111II . get ( 'sType' )
 , 'sName' : Iii111II . get ( 'sName' )
 }
   if 58 - 58: II11iiII * i11iIiiIii / oOo0O0Ooo % o0oo0o - oOoO0oo0OOOo / iiiiIi11i
   if Iii111II . get ( 'mode' ) == 'XXX' :
    ii11i1 = False
   else :
    ii11i1 = True
    if 29 - 29: oOoO0oo0OOOo % oo + Oo / Ooo00oOo00o + II11iiII * Ooo00oOo00o
   i1I1iI = True
   if Iii111II . get ( 'mode' ) == 'ADD_M3U' :
    if Iii111II . get ( 'sType' ) == 'wavve' and self . M3U_ONWAVVE == False : i1I1iI = False
    if Iii111II . get ( 'sType' ) == 'tving' and self . M3U_ONTVING == False : i1I1iI = False
    if Iii111II . get ( 'sType' ) == 'spotv' and self . M3U_ONSPOTV == False : i1I1iI = False
    if 93 - 93: iIii1I11I1II1 % iiiiIi11i * i1IIi
   if i1I1iI == True :
    self . add_dir ( Oo00OOOOO , sublabel = '' , img = '' , infoLabels = None , isFolder = ii11i1 , params = i11 )
    if 16 - 16: O0 - o0oo0o * iIii1I11I1II1 + i1I1ii1II1iII
  if len ( xIiII1IiiIiI1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 50 - 50: II111iiii - Oo * oOoO0oo0OOOo / o0oo0o + Ooo00oOo00o
  if 88 - 88: o0000oOoOoO0o / o0oo0o + i1I1ii1II1iII - II111iiii / Oo - oOo0O0Ooo
  if 15 - 15: oOoO0oo0OOOo + oOo0O0Ooo - OoooooooOO / II11iiII
  if 58 - 58: i11iIiiIii % OoOO0ooOOoo0O
 def dp_Delete_M3u ( self , args ) :
  O0OoOoo00o = xbmcgui . Dialog ( )
  OO00Oo = O0OoOoo00o . yesno ( __language__ ( 30903 ) . encode ( 'utf8' ) , __language__ ( 30904 ) . encode ( 'utf8' ) )
  if OO00Oo == False : sys . exit ( )
  if 51 - 51: oooO0oo0oOOOO * Ooo00oOo00o + OoOO0ooOOoo0O + ooOO00oOo
  if 66 - 66: oOo0O0Ooo
  oO000Oo000 = self . make_M3u_Filename ( )
  if os . path . isfile ( oO000Oo000 ) : os . remove ( oO000Oo000 )
  if 4 - 4: iiiiIi11i
  self . addon_noti ( __language__ ( 30905 ) . encode ( 'utf-8' ) )
  if 93 - 93: ooOO00oOo % iiiiIi11i . ooOO00oOo * o0oo0o % o0000oOoOoO0o . II111iiii
  if 38 - 38: Ooo00oOo00o
  if 57 - 57: O0 / iiiiIi11i * o0oo0o / oOo0O0Ooo . II111iiii
  if 26 - 26: i1I1ii1II1iII
 def dp_MakeAdd_M3u ( self , args ) :
  if 91 - 91: ooOO00oOo . oOoO0oo0OOOo + ooOO00oOo - i1I1ii1II1iII / OoooooooOO
  iII1 = args . get ( 'sType' )
  IiI11iII1 = args . get ( 'sName' )
  if 29 - 29: OoO0O00 - iiiiIi11i - OoOO0ooOOoo0O % i1I1ii1II1iII - iiiiIi11i
  O0OoOoo00o = xbmcgui . Dialog ( )
  OO00Oo = O0OoOoo00o . yesno ( ( IiI11iII1 + __language__ ( 30906 ) ) . encode ( 'utf8' ) , __language__ ( 30907 ) . encode ( 'utf8' ) )
  if OO00Oo == False : sys . exit ( )
  if 91 - 91: ooOO00oOo / OoOO0ooOOoo0O - II111iiii . OoOO0ooOOoo0O
  i1I11i1I = [ ]
  Oo0o00 = [ ]
  O0O0oOO00O00o = [ ]
  if 24 - 24: oooO0oo0oOOOO
  if 57 - 57: O0 / o0oo0o % ooOO00oOo / o0oo0o . oOo0O0Ooo / O0
  if iII1 == 'all' :
   oO000Oo000 = self . make_M3u_Filename ( )
   if os . path . isfile ( oO000Oo000 ) : os . remove ( oO000Oo000 )
   if 89 - 89: oOo0O0Ooo
   if 68 - 68: ooOO00oOo * OoooooooOO % O0 + ooOO00oOo + Oo
  if ( iII1 == 'wavve' or iII1 == 'all' ) and self . M3U_ONWAVVE :
   i11i1I1 = self . BoritvObj . Get_ChannelList_Wavve ( exceptGroup = self . make_EexceptGroup_Wavve ( ) )
   if len ( i11i1I1 ) != 0 : i1I11i1I . extend ( i11i1I1 )
   O0O0oOO00O00o = self . get_radio_list ( )
   self . addon_log ( 'wavve cnt ----> ' + str ( len ( i11i1I1 ) ) )
   if 36 - 36: iIii1I11I1II1 / oOo0O0Ooo * II11iiII
   if 65 - 65: o0000oOoOoO0o . iIii1I11I1II1 / O0 - o0000oOoOoO0o
  if ( iII1 == 'tving' or iII1 == 'all' ) and self . M3U_ONTVING :
   i11i1I1 = self . BoritvObj . Get_ChannelList_Tving ( )
   if len ( i11i1I1 ) != 0 : i1I11i1I . extend ( i11i1I1 )
   self . addon_log ( 'tving cnt ----> ' + str ( len ( i11i1I1 ) ) )
   if 21 - 21: oo * iIii1I11I1II1
   if 91 - 91: oooO0oo0oOOOO
  if ( iII1 == 'spotv' or iII1 == 'all' ) and self . M3U_ONSPOTV :
   i11i1I1 = self . BoritvObj . Get_ChannelList_Spotv ( payyn = self . M3U_ONSPOTVPAY )
   if len ( i11i1I1 ) != 0 : i1I11i1I . extend ( i11i1I1 )
   self . addon_log ( 'spotv cnt ----> ' + str ( len ( i11i1I1 ) ) )
   if 15 - 15: II111iiii
  if len ( i1I11i1I ) == 0 :
   self . addon_noti ( __language__ ( 30909 ) . encode ( 'utf8' ) )
   return
   if 18 - 18: i11iIiiIii . i1IIi % OoooooooOO / O0
   if 75 - 75: oOo0O0Ooo % Ooo00oOo00o % Ooo00oOo00o . o0oo0o
  for III1iII1I1ii in self . BoritvObj . INIT_GENRESORT :
   for oOOo0 in i1I11i1I :
    if oOOo0 [ 'genrenm' ] == III1iII1I1ii :
     Oo0o00 . append ( oOOo0 )
     if 54 - 54: O0 - oooO0oo0oOOOO % II11iiII
  for oOOo0 in i1I11i1I :
   if oOOo0 [ 'genrenm' ] not in self . BoritvObj . INIT_GENRESORT :
    Oo0o00 . append ( oOOo0 )
    if 77 - 77: oOo0O0Ooo / oo / ooOO00oOo + ooOO00oOo . II11iiII
  try :
   oO000Oo000 = self . make_M3u_Filename ( )
   if 38 - 38: o0oo0o
   if os . path . isfile ( oO000Oo000 ) :
    Ii1 = open ( oO000Oo000 , 'a' )
   else :
    Ii1 = open ( oO000Oo000 , 'w' )
    Ii1 . write ( '#EXTM3U\n' )
    if 82 - 82: oOoO0oo0OOOo - iIii1I11I1II1 / II11iiII + o0000oOoOoO0o
   for OOOOoOoo0O0O0 in Oo0o00 :
    if 85 - 85: iiiiIi11i % i11iIiiIii - i1I1ii1II1iII * OoooooooOO / oo % oo
    IIiIi1iI = OOOOoOoo0O0O0 [ 'channelid' ]
    i1IiiiI1iI = OOOOoOoo0O0O0 [ 'channelnm' ]
    i1iIi = OOOOoOoo0O0O0 [ 'channelimg' ]
    ooOOoooooo = OOOOoOoo0O0O0 [ 'ott' ]
    II1I = '%s.%s' % ( IIiIi1iI , ooOOoooooo )
    O0i1II1Iiii1I11 = OOOOoOoo0O0O0 [ 'genrenm' ]
    if 9 - 9: oOoO0oo0OOOo / OoO0O00 - oo / OoooooooOO / iIii1I11I1II1 - Ooo00oOo00o
    if self . M3U_DISPLAYNM :
     i1IiiiI1iI = '%s (%s)' % ( i1IiiiI1iI , ooOOoooooo )
     if 91 - 91: i1I1ii1II1iII % i1IIi % iIii1I11I1II1
     if 20 - 20: II11iiII % o0000oOoOoO0o / o0000oOoOoO0o + o0000oOoOoO0o
    if IIiIi1iI in O0O0oOO00O00o :
     III1IiiI = '#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n' % ( II1I , i1IiiiI1iI , O0i1II1Iiii1I11 , i1iIi , i1IiiiI1iI )
    else :
     III1IiiI = '#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n' % ( II1I , i1IiiiI1iI , O0i1II1Iiii1I11 , i1iIi , i1IiiiI1iI )
     if 31 - 31: Ooo00oOo00o . oo
    if ooOOoooooo == 'wavve' :
     ii11IIII11I = 'plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n' % ( IIiIi1iI )
    elif ooOOoooooo == 'tving' :
     ii11IIII11I = 'plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n' % ( IIiIi1iI )
    elif ooOOoooooo == 'spotv' :
     if 81 - 81: oOo0O0Ooo / O0 . oooO0oo0oOOOO . oo
     if 72 - 72: i1IIi / ooOO00oOo + OoooooooOO - OoO0O00
     if 29 - 29: oOoO0oo0OOOo + iiiiIi11i % O0
     ii11IIII11I = 'plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n' % ( IIiIi1iI )
     if 10 - 10: OoOO0ooOOoo0O / o0oo0o - oo * iIii1I11I1II1 - oo
    Ii1 . write ( III1IiiI )
    Ii1 . write ( ii11IIII11I )
    if 97 - 97: oOoO0oo0OOOo + oo * o0000oOoOoO0o + II11iiII % i1I1ii1II1iII
   Ii1 . close ( )
  except :
   self . addon_noti ( __language__ ( 30910 ) . encode ( 'utf8' ) )
   return
   if 74 - 74: iiiiIi11i - OoO0O00 + OoooooooOO + o0oo0o / oOo0O0Ooo
  self . addon_noti ( ( IiI11iII1 + ' ' + __language__ ( 30908 ) ) . encode ( 'utf8' ) )
  if 23 - 23: O0
  if 85 - 85: o0000oOoOoO0o
  if 84 - 84: oo . iIii1I11I1II1 % OoooooooOO + o0000oOoOoO0o % OoooooooOO % ooOO00oOo
  if 42 - 42: ooOO00oOo / OoOO0ooOOoo0O / Ooo00oOo00o + i1I1ii1II1iII / oOo0O0Ooo
 def dp_Make_Epg ( self , args ) :
  if 84 - 84: Oo * II111iiii + OoO0O00
  iII1 = args . get ( 'sType' )
  IiI11iII1 = args . get ( 'sName' )
  O0ooO0Oo00o = args . get ( 'sNoti' )
  if 77 - 77: iIii1I11I1II1 * ooOO00oOo
  if O0ooO0Oo00o != 'N' :
   O0OoOoo00o = xbmcgui . Dialog ( )
   OO00Oo = O0OoOoo00o . yesno ( ( IiI11iII1 + __language__ ( 30911 ) ) . encode ( 'utf8' ) , __language__ ( 30907 ) . encode ( 'utf8' ) )
   if OO00Oo == False : sys . exit ( )
   if 95 - 95: oo + i11iIiiIii
  I1Ii = [ ]
  O0oo00o0O = [ ]
  if 1 - 1: II111iiii
  if 84 - 84: Ooo00oOo00o % II111iiii . i11iIiiIii / ooOO00oOo
  if 80 - 80: o0oo0o . i11iIiiIii - Ooo00oOo00o
  if ( iII1 == 'wavve' or iII1 == 'all' ) and self . M3U_ONWAVVE :
   iIiIIi1 , I1IIII1i = self . BoritvObj . Get_EpgInfo_Wavve ( exceptGroup = self . make_EexceptGroup_Wavve ( ) )
   if len ( I1IIII1i ) != 0 :
    I1Ii . extend ( iIiIIi1 )
    O0oo00o0O . extend ( I1IIII1i )
    if 2 - 2: OoOO0ooOOoo0O + o0000oOoOoO0o - oo % Ooo00oOo00o . i1I1ii1II1iII
    if 18 - 18: II11iiII + i1I1ii1II1iII - o0000oOoOoO0o . II111iiii + i11iIiiIii
  if ( iII1 == 'tving' or iII1 == 'all' ) and self . M3U_ONTVING :
   iIiIIi1 , I1IIII1i = self . BoritvObj . Get_EpgInfo_Tving ( )
   if len ( I1IIII1i ) != 0 :
    I1Ii . extend ( iIiIIi1 )
    O0oo00o0O . extend ( I1IIII1i )
    if 20 - 20: o0oo0o
    if 52 - 52: II111iiii - OoooooooOO % o0000oOoOoO0o + oo * OoO0O00 . oooO0oo0oOOOO
  if ( iII1 == 'spotv' or iII1 == 'all' ) and self . M3U_ONSPOTV :
   iIiIIi1 , I1IIII1i = self . BoritvObj . Get_EpgInfo_Spotv ( payyn = self . M3U_ONSPOTVPAY )
   if len ( I1IIII1i ) != 0 :
    I1Ii . extend ( iIiIIi1 )
    O0oo00o0O . extend ( I1IIII1i )
    if 75 - 75: Oo + oOo0O0Ooo + Ooo00oOo00o * OoOO0ooOOoo0O % iiiiIi11i . i1I1ii1II1iII
  if len ( O0oo00o0O ) == 0 :
   if O0ooO0Oo00o != 'N' : self . addon_noti ( __language__ ( 30909 ) . encode ( 'utf8' ) )
   return
   if 55 - 55: II11iiII . oo
  try :
   oO000Oo000 = self . make_Epg_Filename ( )
   Ii1 = open ( oO000Oo000 , 'w' )
   if 61 - 61: OoO0O00 % oooO0oo0oOOOO . OoO0O00
   o0oOO000oO0oo = '<?xml version="1.0" encoding="UTF-8"?>\n'
   oOO00O = '<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   OOOoo0OO = '<tv generator-info-name="boritv_epg">\n\n'
   oO0o0 = '\n</tv>\n'
   if 50 - 50: oooO0oo0oOOOO
   Ii1 . write ( o0oOO000oO0oo )
   Ii1 . write ( oOO00O )
   Ii1 . write ( OOOoo0OO )
   if 46 - 46: O0 + i1I1ii1II1iII % oo / Ooo00oOo00o . oooO0oo0oOOOO * OoOO0ooOOoo0O
   if 93 - 93: Ooo00oOo00o % i1IIi . o0000oOoOoO0o . i11iIiiIii
   for oOOoo00O00o in I1Ii :
    O0O00Oo = '  <channel id="%s.%s">\n' % ( oOOoo00O00o . get ( 'channelid' ) , oOOoo00O00o . get ( 'ott' ) )
    oooooo0O000o = '    <display-name>%s</display-name>\n' % ( oOOoo00O00o . get ( 'channelnm' ) )
    OoO = '    <icon src="%s" />\n' % ( oOOoo00O00o . get ( 'channelimg' ) )
    ooO0O0O0ooOOO = '  </channel>\n\n'
    Ii1 . write ( O0O00Oo )
    Ii1 . write ( oooooo0O000o )
    Ii1 . write ( OoO )
    Ii1 . write ( ooO0O0O0ooOOO )
    if 77 - 77: oOo0O0Ooo - II111iiii - Oo
    if 49 - 49: II111iiii % O0 . oOo0O0Ooo + iiiiIi11i / oo
   for oOOoo00O00o in O0oo00o0O :
    O0O00Oo = '  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n' % ( oOOoo00O00o . get ( 'startTime' ) , oOOoo00O00o . get ( 'endTime' ) , oOOoo00O00o . get ( 'channelid' ) , oOOoo00O00o . get ( 'ott' ) )
    oooooo0O000o = '    <title lang="kr">%s</title>\n' % ( oOOoo00O00o . get ( 'title' ) )
    OoO = '  </programme>\n\n'
    Ii1 . write ( O0O00Oo )
    Ii1 . write ( oooooo0O000o )
    Ii1 . write ( OoO )
    if 72 - 72: Oo * OoO0O00 . oo - II111iiii + i1IIi
   Ii1 . write ( oO0o0 )
   if 10 - 10: iiiiIi11i + i1IIi
   Ii1 . close ( )
  except :
   if O0ooO0Oo00o != 'N' : self . addon_noti ( __language__ ( 30910 ) . encode ( 'utf8' ) )
   return
   if 87 - 87: oo
  self . MakeEpg_SaveJson ( )
  if O0ooO0Oo00o != 'N' : self . addon_noti ( ( IiI11iII1 + ' ' + __language__ ( 30912 ) ) . encode ( 'utf8' ) )
  if 58 - 58: oOo0O0Ooo % Ooo00oOo00o
  if 50 - 50: o0oo0o . Ooo00oOo00o
  if 97 - 97: O0 + oOo0O0Ooo
  if 89 - 89: Ooo00oOo00o + ooOO00oOo * OoOO0ooOOoo0O * o0000oOoOoO0o
 def make_EexceptGroup_Wavve ( self ) :
  iiIiI1i1 = [ ]
  if 69 - 69: Oo
  if self . M3U_ONWAVVERADIO == False :
   I11iII = { 'broadcastid' : '46584'
 , 'genre' : '10'
   }
   iiIiI1i1 . append ( I11iII )
   if 5 - 5: oo
  if self . M3U_ONWAVVEHOME == False :
   I11iII = { 'broadcastid' : '46584'
 , 'genre' : '03'
   }
   iiIiI1i1 . append ( I11iII )
   if 48 - 48: Ooo00oOo00o - iiiiIi11i / OoooooooOO
  return iiIiI1i1
  if 100 - 100: oo / Ooo00oOo00o % II111iiii % OoO0O00 % II11iiII
  if 98 - 98: OoOO0ooOOoo0O % i11iIiiIii % Oo + o0000oOoOoO0o
  if 78 - 78: oOoO0oo0OOOo % iiiiIi11i / i1I1ii1II1iII - iIii1I11I1II1
  if 69 - 69: o0oo0o
 def get_radio_list ( self ) :
  if self . M3U_ONWAVVERADIO == False : return [ ]
  if 11 - 11: oo
  I11iII = [ { 'broadcastid' : '46584'
 , 'genre' : '10'
  } ]
  return self . BoritvObj . Get_ChannelList_WavveExcept ( I11iII )
  if 16 - 16: o0000oOoOoO0o + oooO0oo0oOOOO * O0 % i1IIi . oo
  if 67 - 67: OoooooooOO / oo * o0000oOoOoO0o + OoOO0ooOOoo0O
  if 65 - 65: OoooooooOO - oOoO0oo0OOOo / Oo / II111iiii / i1IIi
  if 71 - 71: o0oo0o + o0000oOoOoO0o
 def check_config ( self ) :
  iI1111ii1I = True
  if 45 - 45: i1IIi + Ooo00oOo00o
  self . M3U_FILE_PATH = ( __addon__ . getSetting ( 'm3uFilepath' ) ) . strip ( )
  self . M3U_FILE_NAME = ( __addon__ . getSetting ( 'm3uFilename' ) ) . strip ( )
  self . M3U_ONWAVVE = True if __addon__ . getSetting ( 'onWavve' ) == 'true' else False
  self . M3U_ONTVING = True if __addon__ . getSetting ( 'onTvng' ) == 'true' else False
  self . M3U_ONSPOTV = True if __addon__ . getSetting ( 'onSpotv' ) == 'true' else False
  self . M3U_ONWAVVERADIO = True if __addon__ . getSetting ( 'onWavveRadio' ) == 'true' else False
  self . M3U_ONWAVVEHOME = True if __addon__ . getSetting ( 'onWavveHome' ) == 'true' else False
  self . M3U_ONSPOTVPAY = True if __addon__ . getSetting ( 'onSpotvPay' ) == 'true' else False
  self . M3U_DISPLAYNM = True if __addon__ . getSetting ( 'displayOTTnm' ) == 'true' else False
  if 94 - 94: iiiiIi11i . i1IIi - Ooo00oOo00o % O0 - ooOO00oOo
  if self . M3U_FILE_PATH == '' or self . M3U_FILE_NAME == '' : iI1111ii1I = False
  if self . M3U_ONWAVVE == False and self . M3U_ONTVING == '' and self . M3U_ONSPOTV == '' : iI1111ii1I = False
  if 72 - 72: o0000oOoOoO0o
  if iI1111ii1I == False :
   O0OoOoo00o = xbmcgui . Dialog ( )
   OO00Oo = O0OoOoo00o . yesno ( __language__ ( 30901 ) . encode ( 'utf8' ) , __language__ ( 30902 ) . encode ( 'utf8' ) )
   if OO00Oo == True :
    __addon__ . openSettings ( )
    sys . exit ( )
   else :
    sys . exit ( )
    if 1 - 1: ooOO00oOo * oooO0oo0oOOOO * OoooooooOO + Oo
    if 33 - 33: O0 * Ooo00oOo00o - o0oo0o % o0oo0o
    if 18 - 18: o0oo0o / OoO0O00 * o0oo0o + o0oo0o * i11iIiiIii * oOoO0oo0OOOo
    if 11 - 11: Oo / oOo0O0Ooo - oooO0oo0oOOOO * OoooooooOO + OoooooooOO . oOo0O0Ooo
 def MakeEpg_SaveJson ( self ) :
  i1I1i111Ii = { 'date_makeepg' : self . BoritvObj . Get_Now_Datetime ( ) . strftime ( '%Y-%m-%d' ) }
  try :
   Ii1 = open ( ooO00oOoo , 'w' )
   json . dump ( i1I1i111Ii , Ii1 )
   Ii1 . close ( )
  except Exception as ooo :
   return
   if 27 - 27: Oo % oo
   if 73 - 73: II11iiII
   if 70 - 70: iIii1I11I1II1
   if 31 - 31: oooO0oo0oOOOO - oo % iIii1I11I1II1
 def boritv_main ( self ) :
  if 92 - 92: i1IIi - iIii1I11I1II1
  IIIIIIii1 = self . main_params . get ( 'mode' , None )
  if 88 - 88: ooOO00oOo
  self . check_config ( )
  if 71 - 71: oOoO0oo0OOOo
  if IIIIIIii1 is None :
   self . dp_Main_List ( )
   if 7 - 7: oOoO0oo0OOOo - oo . iIii1I11I1II1 - i1IIi
  elif IIIIIIii1 == 'DEL_M3U' :
   self . dp_Delete_M3u ( self . main_params )
   if 59 - 59: Ooo00oOo00o
  elif IIIIIIii1 == 'ADD_M3U' :
   self . dp_MakeAdd_M3u ( self . main_params )
   if 81 - 81: oOo0O0Ooo - oOo0O0Ooo . i1I1ii1II1iII
  elif IIIIIIii1 == 'ADD_EPG' :
   self . dp_Make_Epg ( self . main_params )
   if 73 - 73: OoOO0ooOOoo0O % i11iIiiIii - oo
  else :
   None
   if 7 - 7: O0 * i11iIiiIii * o0000oOoOoO0o + Oo % ooOO00oOo - Oo
   if 39 - 39: OoO0O00 * II11iiII % II11iiII - OoooooooOO + Ooo00oOo00o - OoOO0ooOOoo0O
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
