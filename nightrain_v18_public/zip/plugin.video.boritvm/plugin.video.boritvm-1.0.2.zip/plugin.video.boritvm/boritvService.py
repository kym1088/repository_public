# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import os
import sys
import xbmcaddon
import urllib
import time
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
__cwd__ = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) )
__lib__ = os . path . join ( __cwd__ , 'resources' , 'lib' )
sys . path . append ( __lib__ )
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
from boritvServiceRun import *
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
i1I1ii1II1iII = xbmc . Monitor ( )
oooO0oo0oOOOO = xxo000o0o00o0Oo ( )
xbmc . sleep ( oooO0oo0oOOOO . START_INTERVAL )
if 53 - 53: I11i / Oo0Ooo / II111iiii % Ii1I / OoOoOO00 . ooOoO0o
while not i1I1ii1II1iII . abortRequested ( ) :
 if 100 - 100: i1IIi
 if i1I1ii1II1iII . waitForAbort ( oooO0oo0oOOOO . INTERVAL ) :
  if 27 - 27: IiII * OoooooooOO + I11i * ooOoO0o - i11iIiiIii - iII111i
  if 30 - 30: iIii1I11I1II1 * iIii1I11I1II1 . II111iiii - oO0o
  break
  if 72 - 72: II111iiii - OoOoOO00
 oooO0oo0oOOOO . service_run ( )
 if 91 - 91: OoO0O00 . i11iIiiIii / oO0o % I11i / OoO0O00 - i11iIiiIii
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
