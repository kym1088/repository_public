# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import os
import xbmcplugin , xbmcgui , xbmcaddon , xbmc , xbmcvfs
import sys
import datetime
import time
import urllib
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 73 - 73: II111iiii
IiII1IiiIiI1 = [
 { 'title' : '*** 간단설명 (개별 OTT 애드온 필수) ***' , 'mode' : 'XXX' }
 , { 'title' : '     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)' , 'mode' : 'XXX' }
 , { 'title' : '     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)' , 'mode' : 'XXX' }
 , { 'title' : '-----------------' , 'mode' : 'XXX' }
 , { 'title' : '-> M3U 파일 초기화/삭제' , 'mode' : 'DEL_M3U' }
 , { 'title' : '     - M3U 추가 (웨이브)' , 'mode' : 'ADD_M3U' , 'sType' : 'wavve' , 'sName' : '웨이브' }
 , { 'title' : '     - M3U 추가 (티빙)' , 'mode' : 'ADD_M3U' , 'sType' : 'tving' , 'sName' : '티빙' }
 , { 'title' : '     - M3U 추가 (스포티비)' , 'mode' : 'ADD_M3U' , 'sType' : 'spotv' , 'sName' : '스포티비나우' }
 , { 'title' : '-> M3U (삭제후 일괄생성)' , 'mode' : 'ADD_M3U' , 'sType' : 'all' , 'sName' : '전체' }
 , { 'title' : '-----------------' , 'mode' : 'XXX' }
 , { 'title' : '-> EPG 생성 (삭제후 일괄생성)' , 'mode' : 'ADD_EPG' , 'sType' : 'all' , 'sName' : '전체' }
 ]
if 40 - 40: oo * OoO0O00
if 2 - 2: ooOO00oOo % oOo0O0Ooo * Ooo00oOo00o . oOoO0oo0OOOo + iiiiIi11i
__addon__ = xbmcaddon . Addon ( )
__language__ = __addon__ . getLocalizedString
__profile__ = xbmc . translatePath ( __addon__ . getAddonInfo ( 'profile' ) )
__version__ = __addon__ . getAddonInfo ( 'version' )
__addonid__ = __addon__ . getAddonInfo ( 'id' )
__addonname__ = __addon__ . getAddonInfo ( 'name' )
if 24 - 24: II11iiII / OoOO0ooOOoo0O + o0000oOoOoO0o * i1I1ii1II1iII % oooO0oo0oOOOO
if 53 - 53: o0oo0o / Oo + o0oo0o / oooO0oo0oOOOO * OoooooooOO + i1I1ii1II1iII
OOo0oO0oooOoO = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
ooO00oOoo = xbmc . translatePath ( os . path . join ( __profile__ , 'boritv_update.json' ) )
if 78 - 78: OoOO0ooOOoo0O / ooOO00oOo - O0 . oooO0oo0oOOOO
from boritvCore import *
if 91 - 91: oOoO0oo0OOOo * iIii1I11I1II1 . oooO0oo0oOOOO / o0000oOoOoO0o
if 87 - 87: i1IIi / o0000oOoOoO0o . ooOO00oOo * OoooooooOO - oooO0oo0oOOOO * Oo
class xxO0I11i1i11i1I ( object ) :
 def __init__ ( self , in_addonurl , in_handle , in_params ) :
  self . _addon_url = in_addonurl
  self . _addon_handle = in_handle
  self . main_params = in_params
  self . M3U_FILE_PATH = ''
  self . M3U_FILE_NAME = ''
  self . M3U_ONWAVVE = False
  self . M3U_ONTVING = False
  self . M3U_ONSPOTV = False
  self . M3U_ONWAVVERADIO = False
  self . M3U_ONWAVVEHOME = False
  self . M3U_ONSPOTVPAY = False
  self . M3U_DISPLAYNM = False
  self . BoritvObj = xIiiiIiI1iIiI1 ( )
  if 31 - 31: i11iIiiIii / oo / Oo * iiiiIi11i / OoO0O00
  if 99 - 99: iIii1I11I1II1 * OoooooooOO * II111iiii * iIii1I11I1II1
  if 44 - 44: iiiiIi11i / OoO0O00 - II111iiii - i11iIiiIii % o0oo0o
 def addon_noti ( self , sting ) :
  try :
   O0OoOoo00o = xbmcgui . Dialog ( )
   O0OoOoo00o . notification ( __addonname__ , sting )
  except :
   None
   if 31 - 31: II111iiii + ooOO00oOo . o0oo0o
   if 68 - 68: oo - i11iIiiIii - ooOO00oOo / II11iiII - ooOO00oOo + i1IIi
   if 48 - 48: OoooooooOO % Ooo00oOo00o . oo - o0000oOoOoO0o % i1IIi % OoooooooOO
 def addon_log ( self , string ) :
  try :
   i1iIIi1 = string . encode ( 'utf-8' , 'ignore' )
  except :
   i1iIIi1 = 'addonException: addon_log'
   if 50 - 50: i11iIiiIii - o0000oOoOoO0o
   if 78 - 78: ooOO00oOo
  Iii1I111 = xbmc . LOGINFO
  xbmc . log ( "[%s-%s]: %s" % ( __addonid__ , __version__ , i1iIIi1 ) , level = Iii1I111 )
  if 60 - 60: iiiiIi11i * Ooo00oOo00o % Ooo00oOo00o % OoOO0ooOOoo0O * II111iiii + i1IIi
  if 64 - 64: iiiiIi11i - O0 / II111iiii / Ooo00oOo00o / iIii1I11I1II1
  if 24 - 24: O0 % Ooo00oOo00o + i1IIi + o0oo0o + oOoO0oo0OOOo
  if 70 - 70: OoO0O00 % OoO0O00 . oooO0oo0oOOOO % ooOO00oOo * Ooo00oOo00o % iiiiIi11i
 def get_keyboard_input ( self , title ) :
  iiI1IiI = None
  II = xbmc . Keyboard ( )
  II . setHeading ( title )
  xbmc . sleep ( 1000 )
  II . doModal ( )
  if ( II . isConfirmed ( ) ) :
   iiI1IiI = II . getText ( )
  return iiI1IiI
  if 57 - 57: iiiiIi11i
  if 14 - 14: OoO0O00 . oo / o0000oOoOoO0o
  if 38 - 38: II111iiii % i11iIiiIii . Oo - II11iiII + o0000oOoOoO0o
  if 66 - 66: OoooooooOO * OoooooooOO . II11iiII . i1IIi - II11iiII
 def add_dir ( self , label , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = '' ) :
  o0o00ooo0 = '%s?%s' % ( self . _addon_url , urllib . urlencode ( params ) )
  if 96 - 96: O0 % iiiiIi11i % iIii1I11I1II1
  if sublabel : Oo00OOOOO = '%s < %s >' % ( label , sublabel )
  else : Oo00OOOOO = label
  if not img : img = 'DefaultFolder.png'
  if 85 - 85: Oo . i1I1ii1II1iII - ooOO00oOo % Oo % II111iiii
  OO0o00o = xbmcgui . ListItem ( Oo00OOOOO )
  OO0o00o . setArt ( { 'thumbnailImage' : img , 'icon' : img , 'poster' : img } )
  if 89 - 89: iiiiIi11i + OoO0O00
  if infoLabels : OO0o00o . setInfo ( type = "video" , infoLabels = infoLabels )
  if not isFolder : OO0o00o . setProperty ( 'IsPlayable' , 'true' )
  if 3 - 3: i1IIi / oo % OoOO0ooOOoo0O * i11iIiiIii / O0 * OoOO0ooOOoo0O
  xbmcplugin . addDirectoryItem ( self . _addon_handle , o0o00ooo0 , OO0o00o , isFolder )
  if 49 - 49: iiiiIi11i % o0000oOoOoO0o + i1IIi . oo % oOoO0oo0OOOo
  if 48 - 48: OoOO0ooOOoo0O + OoOO0ooOOoo0O / II111iiii / iIii1I11I1II1
  if 20 - 20: Ooo00oOo00o
  if 77 - 77: oOo0O0Ooo / OoOO0ooOOoo0O
 def make_M3u_Filename ( self , tempyn = False ) :
  if tempyn :
   return xbmc . translatePath ( os . path . join ( __profile__ , 'boritv_temp.m3u' ) )
  else :
   return self . M3U_FILE_PATH + self . M3U_FILE_NAME + '.m3u'
   if 98 - 98: iIii1I11I1II1 / i1IIi / i11iIiiIii / Ooo00oOo00o
   if 28 - 28: II11iiII - oooO0oo0oOOOO . oooO0oo0oOOOO + oOo0O0Ooo - OoooooooOO + O0
   if 95 - 95: ooOO00oOo % iiiiIi11i . O0
   if 15 - 15: Oo / o0000oOoOoO0o . o0000oOoOoO0o - i1IIi
 def make_Epg_Filename ( self , tempyn = False ) :
  if tempyn :
   return xbmc . translatePath ( os . path . join ( __profile__ , 'boritv_temp.xml' ) )
  else :
   return self . M3U_FILE_PATH + self . M3U_FILE_NAME + '.xml'
   if 53 - 53: oooO0oo0oOOOO + oo * iiiiIi11i
   if 61 - 61: i1IIi * II11iiII / OoooooooOO . i11iIiiIii . oOo0O0Ooo
   if 60 - 60: OoOO0ooOOoo0O / OoOO0ooOOoo0O
   if 46 - 46: o0000oOoOoO0o * II11iiII - ooOO00oOo * iiiiIi11i - o0oo0o
 def dp_Main_List ( self ) :
  if 83 - 83: OoooooooOO
  for Iii111II in IiII1IiiIiI1 :
   Oo00OOOOO = Iii111II . get ( 'title' )
   if 9 - 9: ooOO00oOo
   i11 = { 'mode' : Iii111II . get ( 'mode' )
 , 'sType' : Iii111II . get ( 'sType' )
 , 'sName' : Iii111II . get ( 'sName' )
 }
   if 58 - 58: II11iiII * i11iIiiIii / oOo0O0Ooo % o0oo0o - oOoO0oo0OOOo / iiiiIi11i
   if Iii111II . get ( 'mode' ) == 'XXX' :
    ii11i1 = False
   else :
    ii11i1 = True
    if 29 - 29: oOoO0oo0OOOo % oo + Oo / Ooo00oOo00o + II11iiII * Ooo00oOo00o
   i1I1iI = True
   if Iii111II . get ( 'mode' ) == 'ADD_M3U' :
    if Iii111II . get ( 'sType' ) == 'wavve' and self . M3U_ONWAVVE == False : i1I1iI = False
    if Iii111II . get ( 'sType' ) == 'tving' and self . M3U_ONTVING == False : i1I1iI = False
    if Iii111II . get ( 'sType' ) == 'spotv' and self . M3U_ONSPOTV == False : i1I1iI = False
    if 93 - 93: iIii1I11I1II1 % iiiiIi11i * i1IIi
   if i1I1iI == True :
    self . add_dir ( Oo00OOOOO , sublabel = '' , img = '' , infoLabels = None , isFolder = ii11i1 , params = i11 )
    if 16 - 16: O0 - o0oo0o * iIii1I11I1II1 + i1I1ii1II1iII
  if len ( IiII1IiiIiI1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 50 - 50: II111iiii - Oo * oOoO0oo0OOOo / o0oo0o + Ooo00oOo00o
  if 88 - 88: o0000oOoOoO0o / o0oo0o + i1I1ii1II1iII - II111iiii / Oo - oOo0O0Ooo
  if 15 - 15: oOoO0oo0OOOo + oOo0O0Ooo - OoooooooOO / II11iiII
  if 58 - 58: i11iIiiIii % OoOO0ooOOoo0O
 def dp_Delete_M3u ( self , args ) :
  O0OoOoo00o = xbmcgui . Dialog ( )
  OO00Oo = O0OoOoo00o . yesno ( __language__ ( 30903 ) . encode ( 'utf8' ) , __language__ ( 30904 ) . encode ( 'utf8' ) )
  if OO00Oo == False : sys . exit ( )
  if 51 - 51: oooO0oo0oOOOO * Ooo00oOo00o + OoOO0ooOOoo0O + ooOO00oOo
  if 66 - 66: oOo0O0Ooo
  if 97 - 97: iiiiIi11i % oooO0oo0oOOOO * oooO0oo0oOOOO
  if 39 - 39: o0000oOoOoO0o % oooO0oo0oOOOO
  if 4 - 4: iiiiIi11i
  if 93 - 93: ooOO00oOo % iiiiIi11i . ooOO00oOo * o0oo0o % o0000oOoOoO0o . II111iiii
  iI1ii1Ii = self . make_M3u_Filename ( tempyn = False )
  if xbmcvfs . exists ( iI1ii1Ii ) :
   if xbmcvfs . delete ( iI1ii1Ii ) == False :
    self . addon_noti ( __language__ ( 30910 ) . encode ( 'utf-8' ) )
    return
    if 92 - 92: oOo0O0Ooo
  self . addon_noti ( __language__ ( 30905 ) . encode ( 'utf-8' ) )
  if 26 - 26: i1I1ii1II1iII . o0oo0o
  if 68 - 68: ooOO00oOo
  if 35 - 35: ooOO00oOo - i1I1ii1II1iII / OoO0O00 / oOo0O0Ooo
  if 24 - 24: Oo - Oo / II111iiii - oOoO0oo0OOOo
 def dp_MakeAdd_M3u ( self , args ) :
  if 69 - 69: iiiiIi11i . o0oo0o + o0000oOoOoO0o / OoO0O00 - iiiiIi11i
  OO0O0OoOO0 = args . get ( 'sType' )
  iiiI1I11i1 = args . get ( 'sName' )
  if 49 - 49: oo % Oo . Oo . OoOO0ooOOoo0O * Oo
  O0OoOoo00o = xbmcgui . Dialog ( )
  OO00Oo = O0OoOoo00o . yesno ( ( iiiI1I11i1 + __language__ ( 30906 ) ) . encode ( 'utf8' ) , __language__ ( 30907 ) . encode ( 'utf8' ) )
  if OO00Oo == False : sys . exit ( )
  if 97 - 97: o0000oOoOoO0o + Ooo00oOo00o . II11iiII + oOoO0oo0OOOo % i1I1ii1II1iII
  oo0O = [ ]
  o0 = [ ]
  oo0oOo = [ ]
  if 89 - 89: oOo0O0Ooo
  if 68 - 68: ooOO00oOo * OoooooooOO % O0 + ooOO00oOo + Oo
  if 4 - 4: Oo + O0 * II11iiII
  if 55 - 55: OoO0O00 + iIii1I11I1II1 / oOo0O0Ooo * iiiiIi11i - i11iIiiIii - o0000oOoOoO0o
  if 25 - 25: oOoO0oo0OOOo
  if 7 - 7: i1IIi / oo * o0oo0o . oooO0oo0oOOOO . iIii1I11I1II1
  if 13 - 13: II11iiII / i11iIiiIii
  if OO0O0OoOO0 == 'all' :
   if 2 - 2: oo / O0 / Ooo00oOo00o % oOo0O0Ooo % o0000oOoOoO0o
   iI1ii1Ii = self . make_M3u_Filename ( tempyn = True )
   if os . path . isfile ( iI1ii1Ii ) : os . remove ( iI1ii1Ii )
   if 52 - 52: Ooo00oOo00o
   iI1ii1Ii = self . make_M3u_Filename ( tempyn = False )
   if xbmcvfs . exists ( iI1ii1Ii ) :
    if xbmcvfs . delete ( iI1ii1Ii ) == False :
     self . addon_noti ( __language__ ( 30910 ) . encode ( 'utf-8' ) )
     return
     if 95 - 95: o0000oOoOoO0o
     if 87 - 87: Oo + oOo0O0Ooo . II11iiII + oOo0O0Ooo
     if 91 - 91: O0
  if ( OO0O0OoOO0 == 'wavve' or OO0O0OoOO0 == 'all' ) and self . M3U_ONWAVVE :
   oOOo0 = self . BoritvObj . Get_ChannelList_Wavve ( exceptGroup = self . make_EexceptGroup_Wavve ( ) )
   if len ( oOOo0 ) != 0 : oo0O . extend ( oOOo0 )
   oo0oOo = self . get_radio_list ( )
   self . addon_log ( 'wavve cnt ----> ' + str ( len ( oOOo0 ) ) )
   if 54 - 54: O0 - oooO0oo0oOOOO % II11iiII
   if 77 - 77: oOo0O0Ooo / oo / ooOO00oOo + ooOO00oOo . II11iiII
  if ( OO0O0OoOO0 == 'tving' or OO0O0OoOO0 == 'all' ) and self . M3U_ONTVING :
   oOOo0 = self . BoritvObj . Get_ChannelList_Tving ( )
   if len ( oOOo0 ) != 0 : oo0O . extend ( oOOo0 )
   self . addon_log ( 'tving cnt ----> ' + str ( len ( oOOo0 ) ) )
   if 38 - 38: o0oo0o
   if 7 - 7: O0 . i1I1ii1II1iII % oOoO0oo0OOOo - oo - iIii1I11I1II1
  if ( OO0O0OoOO0 == 'spotv' or OO0O0OoOO0 == 'all' ) and self . M3U_ONSPOTV :
   oOOo0 = self . BoritvObj . Get_ChannelList_Spotv ( payyn = self . M3U_ONSPOTVPAY )
   if len ( oOOo0 ) != 0 : oo0O . extend ( oOOo0 )
   self . addon_log ( 'spotv cnt ----> ' + str ( len ( oOOo0 ) ) )
   if 36 - 36: oooO0oo0oOOOO % Oo % OoO0O00 - oOoO0oo0OOOo
  if len ( oo0O ) == 0 :
   self . addon_noti ( __language__ ( 30909 ) . encode ( 'utf8' ) )
   return
   if 22 - 22: iIii1I11I1II1 / OoO0O00 * oOoO0oo0OOOo % i1I1ii1II1iII
   if 85 - 85: iiiiIi11i % i11iIiiIii - i1I1ii1II1iII * OoooooooOO / oo % oo
  for IIiIi1iI in self . BoritvObj . INIT_GENRESORT :
   for i1IiiiI1iI in oo0O :
    if i1IiiiI1iI [ 'genrenm' ] == IIiIi1iI :
     o0 . append ( i1IiiiI1iI )
     if 49 - 49: o0000oOoOoO0o / ooOO00oOo . II111iiii
  for i1IiiiI1iI in oo0O :
   if i1IiiiI1iI [ 'genrenm' ] not in self . BoritvObj . INIT_GENRESORT :
    o0 . append ( i1IiiiI1iI )
    if 68 - 68: i11iIiiIii % oOoO0oo0OOOo + i11iIiiIii
  try :
   if 31 - 31: II111iiii . oo
   iI1ii1Ii = self . make_M3u_Filename ( tempyn = True )
   if 1 - 1: OoO0O00 / Ooo00oOo00o % i1I1ii1II1iII * oooO0oo0oOOOO . i11iIiiIii
   if os . path . isfile ( iI1ii1Ii ) :
    III1Iiii1I11 = open ( iI1ii1Ii , 'a' )
   else :
    III1Iiii1I11 = open ( iI1ii1Ii , 'w' )
    III1Iiii1I11 . write ( '#EXTM3U\n' )
    if 9 - 9: oOoO0oo0OOOo / OoO0O00 - oo / OoooooooOO / iIii1I11I1II1 - Ooo00oOo00o
   for o00oooO0Oo in o0 :
    if 78 - 78: o0000oOoOoO0o % o0oo0o + oOoO0oo0OOOo
    OOooOoooOoOo = o00oooO0Oo [ 'channelid' ]
    o0OOOO00O0Oo = o00oooO0Oo [ 'channelnm' ]
    ii = o00oooO0Oo [ 'channelimg' ]
    oOooOOOoOo = o00oooO0Oo [ 'ott' ]
    i1Iii1i1I = '%s.%s' % ( OOooOoooOoOo , oOooOOOoOo )
    OOoO00 = o00oooO0Oo [ 'genrenm' ]
    if 40 - 40: oo * o0000oOoOoO0o + II11iiII % i1I1ii1II1iII
    if self . M3U_DISPLAYNM :
     o0OOOO00O0Oo = '%s (%s)' % ( o0OOOO00O0Oo , oOooOOOoOo )
     if 74 - 74: iiiiIi11i - OoO0O00 + OoooooooOO + o0oo0o / oOo0O0Ooo
     if 23 - 23: O0
    if OOooOoooOoOo in oo0oOo :
     o00oO0oOo00 = '#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n' % ( i1Iii1i1I , o0OOOO00O0Oo , OOoO00 , ii , o0OOOO00O0Oo )
    else :
     o00oO0oOo00 = '#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n' % ( i1Iii1i1I , o0OOOO00O0Oo , OOoO00 , ii , o0OOOO00O0Oo )
     if 81 - 81: ooOO00oOo
    if oOooOOOoOo == 'wavve' :
     IIi1 = 'plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n' % ( OOooOoooOoOo )
    elif oOooOOOoOo == 'tving' :
     IIi1 = 'plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n' % ( OOooOoooOoOo )
    elif oOooOOOoOo == 'spotv' :
     if 45 - 45: i1I1ii1II1iII / i1I1ii1II1iII + o0oo0o + Oo
     if 47 - 47: Ooo00oOo00o + Oo
     if 82 - 82: II111iiii . oooO0oo0oOOOO - iIii1I11I1II1 - oooO0oo0oOOOO * II111iiii
     IIi1 = 'plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n' % ( OOooOoooOoOo )
     if 77 - 77: iIii1I11I1II1 * ooOO00oOo
    III1Iiii1I11 . write ( o00oO0oOo00 )
    III1Iiii1I11 . write ( IIi1 )
    if 95 - 95: oo + i11iIiiIii
   III1Iiii1I11 . close ( )
  except :
   self . addon_noti ( __language__ ( 30910 ) . encode ( 'utf8' ) )
   return
   if 6 - 6: Oo / i11iIiiIii + i1I1ii1II1iII * iiiiIi11i
   if 80 - 80: II111iiii
  O0O = self . make_M3u_Filename ( tempyn = True )
  i1I1I = self . make_M3u_Filename ( tempyn = False )
  if xbmcvfs . copy ( O0O , i1I1I ) :
   self . addon_noti ( ( iiiI1I11i1 + ' ' + __language__ ( 30908 ) ) . encode ( 'utf8' ) )
  else :
   self . addon_noti ( __language__ ( 30910 ) . encode ( 'utf-8' ) )
   if 12 - 12: i11iIiiIii / ooOO00oOo
   if 80 - 80: o0oo0o . i11iIiiIii - Ooo00oOo00o
   if 25 - 25: ooOO00oOo
   if 62 - 62: II11iiII + O0
   if 98 - 98: Ooo00oOo00o
   if 51 - 51: OoO0O00 - iiiiIi11i + II111iiii * o0000oOoOoO0o . OoOO0ooOOoo0O + iiiiIi11i
 def dp_Make_Epg ( self , args ) :
  if 78 - 78: i11iIiiIii / i1I1ii1II1iII - o0000oOoOoO0o / II11iiII + iiiiIi11i
  OO0O0OoOO0 = args . get ( 'sType' )
  iiiI1I11i1 = args . get ( 'sName' )
  oOoooo0O0Oo = args . get ( 'sNoti' )
  if 76 - 76: o0000oOoOoO0o + oooO0oo0oOOOO
  if oOoooo0O0Oo != 'N' :
   O0OoOoo00o = xbmcgui . Dialog ( )
   OO00Oo = O0OoOoo00o . yesno ( ( iiiI1I11i1 + __language__ ( 30911 ) ) . encode ( 'utf8' ) , __language__ ( 30907 ) . encode ( 'utf8' ) )
   if OO00Oo == False : sys . exit ( )
   if 34 - 34: OoO0O00
  OO0OO0O00oO0 = [ ]
  oO = [ ]
  if 31 - 31: II11iiII + i11iIiiIii + OoO0O00 * Oo
  if 28 - 28: O0 * OoO0O00 - II11iiII % iIii1I11I1II1 * o0000oOoOoO0o - i11iIiiIii
  if 7 - 7: OoO0O00 + iiiiIi11i - o0oo0o % o0000oOoOoO0o + oOoO0oo0OOOo
  if ( OO0O0OoOO0 == 'wavve' or OO0O0OoOO0 == 'all' ) and self . M3U_ONWAVVE :
   ooo0OOOoo , I1Ii1 = self . BoritvObj . Get_EpgInfo_Wavve ( exceptGroup = self . make_EexceptGroup_Wavve ( ) )
   if len ( I1Ii1 ) != 0 :
    OO0OO0O00oO0 . extend ( ooo0OOOoo )
    oO . extend ( I1Ii1 )
    if 46 - 46: O0 + i1I1ii1II1iII % oo / Ooo00oOo00o . oooO0oo0oOOOO * OoOO0ooOOoo0O
    if 93 - 93: Ooo00oOo00o % i1IIi . o0000oOoOoO0o . i11iIiiIii
  if ( OO0O0OoOO0 == 'tving' or OO0O0OoOO0 == 'all' ) and self . M3U_ONTVING :
   ooo0OOOoo , I1Ii1 = self . BoritvObj . Get_EpgInfo_Tving ( )
   if len ( I1Ii1 ) != 0 :
    OO0OO0O00oO0 . extend ( ooo0OOOoo )
    oO . extend ( I1Ii1 )
    if 56 - 56: oOoO0oo0OOOo % O0 - oo
    if 100 - 100: o0000oOoOoO0o - O0 % iiiiIi11i * II11iiII + oo
  if ( OO0O0OoOO0 == 'spotv' or OO0O0OoOO0 == 'all' ) and self . M3U_ONSPOTV :
   ooo0OOOoo , I1Ii1 = self . BoritvObj . Get_EpgInfo_Spotv ( payyn = self . M3U_ONSPOTVPAY )
   if len ( I1Ii1 ) != 0 :
    OO0OO0O00oO0 . extend ( ooo0OOOoo )
    oO . extend ( I1Ii1 )
    if 88 - 88: OoooooooOO - ooOO00oOo * O0 * OoooooooOO . OoooooooOO
  if len ( oO ) == 0 :
   if oOoooo0O0Oo != 'N' : self . addon_noti ( __language__ ( 30909 ) . encode ( 'utf8' ) )
   return
   if 33 - 33: o0oo0o + i1I1ii1II1iII * iiiiIi11i / iIii1I11I1II1 - oo
  try :
   if 54 - 54: o0oo0o / II11iiII . iiiiIi11i % i1I1ii1II1iII
   iI1ii1Ii = self . make_Epg_Filename ( tempyn = True )
   III1Iiii1I11 = open ( iI1ii1Ii , 'w' )
   if 57 - 57: i11iIiiIii . oOoO0oo0OOOo - o0000oOoOoO0o - iiiiIi11i + oOo0O0Ooo
   oO00oooOOoOo0 = '<?xml version="1.0" encoding="UTF-8"?>\n'
   OoOOoOooooOOo = '<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
   oOo0O = '<tv generator-info-name="boritv_epg">\n\n'
   oo0O0 = '\n</tv>\n'
   if 22 - 22: oOo0O0Ooo . II11iiII * oOo0O0Ooo
   III1Iiii1I11 . write ( oO00oooOOoOo0 )
   III1Iiii1I11 . write ( OoOOoOooooOOo )
   III1Iiii1I11 . write ( oOo0O )
   if 54 - 54: oooO0oo0oOOOO + o0000oOoOoO0o % ooOO00oOo + OoooooooOO - O0 - Ooo00oOo00o
   if 77 - 77: II11iiII * iIii1I11I1II1
   for oO00oOOoooO in OO0OO0O00oO0 :
    IiIi11iI = '  <channel id="%s.%s">\n' % ( oO00oOOoooO . get ( 'channelid' ) , oO00oOOoooO . get ( 'ott' ) )
    Oo0O00O000 = '    <display-name>%s</display-name>\n' % ( oO00oOOoooO . get ( 'channelnm' ) )
    i11I1IiII1i1i = '    <icon src="%s" />\n' % ( oO00oOOoooO . get ( 'channelimg' ) )
    ooI1111i = '  </channel>\n\n'
    III1Iiii1I11 . write ( IiIi11iI )
    III1Iiii1I11 . write ( Oo0O00O000 )
    III1Iiii1I11 . write ( i11I1IiII1i1i )
    III1Iiii1I11 . write ( ooI1111i )
    if 14 - 14: II11iiII / Ooo00oOo00o
    if 32 - 32: oo * OoO0O00
   for oO00oOOoooO in oO :
    IiIi11iI = '  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n' % ( oO00oOOoooO . get ( 'startTime' ) , oO00oOOoooO . get ( 'endTime' ) , oO00oOOoooO . get ( 'channelid' ) , oO00oOOoooO . get ( 'ott' ) )
    Oo0O00O000 = '    <title lang="kr">%s</title>\n' % ( oO00oOOoooO . get ( 'title' ) )
    i11I1IiII1i1i = '  </programme>\n\n'
    III1Iiii1I11 . write ( IiIi11iI )
    III1Iiii1I11 . write ( Oo0O00O000 )
    III1Iiii1I11 . write ( i11I1IiII1i1i )
    if 78 - 78: II11iiII - OoooooooOO - oOoO0oo0OOOo / Oo / II111iiii
   III1Iiii1I11 . write ( oo0O0 )
   if 29 - 29: oo % oo
   III1Iiii1I11 . close ( )
  except :
   if oOoooo0O0Oo != 'N' : self . addon_noti ( __language__ ( 30910 ) . encode ( 'utf8' ) )
   return
   if 94 - 94: iIii1I11I1II1 / OoO0O00 % i1I1ii1II1iII * i1I1ii1II1iII * II111iiii
  self . MakeEpg_SaveJson ( )
  if 29 - 29: ooOO00oOo + oOo0O0Ooo / Ooo00oOo00o / II11iiII * iIii1I11I1II1
  if 62 - 62: II11iiII / iiiiIi11i - ooOO00oOo . OoOO0ooOOoo0O
  O0O = self . make_Epg_Filename ( tempyn = True )
  i1I1I = self . make_Epg_Filename ( tempyn = False )
  if xbmcvfs . copy ( O0O , i1I1I ) :
   if oOoooo0O0Oo != 'N' : self . addon_noti ( ( iiiI1I11i1 + ' ' + __language__ ( 30912 ) ) . encode ( 'utf8' ) )
  else :
   self . addon_noti ( __language__ ( 30910 ) . encode ( 'utf-8' ) )
   if 11 - 11: oOoO0oo0OOOo . ooOO00oOo * oooO0oo0oOOOO * OoooooooOO + Oo
   if 33 - 33: O0 * Ooo00oOo00o - o0oo0o % o0oo0o
   if 18 - 18: o0oo0o / OoO0O00 * o0oo0o + o0oo0o * i11iIiiIii * oOoO0oo0OOOo
   if 11 - 11: Oo / oOo0O0Ooo - oooO0oo0oOOOO * OoooooooOO + OoooooooOO . oOo0O0Ooo
   if 26 - 26: o0000oOoOoO0o % oOoO0oo0OOOo
   if 76 - 76: oooO0oo0oOOOO * i1I1ii1II1iII
 def make_EexceptGroup_Wavve ( self ) :
  ooooooo00o = [ ]
  if 73 - 73: II11iiII
  if self . M3U_ONWAVVERADIO == False :
   ooO = { 'broadcastid' : '46584'
 , 'genre' : '10'
   }
   ooooooo00o . append ( ooO )
   if 51 - 51: oo % o0oo0o . iiiiIi11i / iIii1I11I1II1 / OoOO0ooOOoo0O . iiiiIi11i
  if self . M3U_ONWAVVEHOME == False :
   ooO = { 'broadcastid' : '46584'
 , 'genre' : '03'
   }
   ooooooo00o . append ( ooO )
   if 42 - 42: Ooo00oOo00o + i1IIi - o0000oOoOoO0o / oooO0oo0oOOOO
  return ooooooo00o
  if 9 - 9: O0 % O0 - Ooo00oOo00o
  if 51 - 51: oo . iIii1I11I1II1 - oOoO0oo0OOOo / O0
  if 52 - 52: Ooo00oOo00o + O0 + i1I1ii1II1iII + OoO0O00 % i1I1ii1II1iII
  if 75 - 75: oo . Oo . O0 * o0oo0o
 def get_radio_list ( self ) :
  if self . M3U_ONWAVVERADIO == False : return [ ]
  if 4 - 4: o0000oOoOoO0o % iiiiIi11i * ooOO00oOo
  ooO = [ { 'broadcastid' : '46584'
 , 'genre' : '10'
  } ]
  return self . BoritvObj . Get_ChannelList_WavveExcept ( ooO )
  if 100 - 100: o0oo0o * II11iiII + II11iiII
  if 54 - 54: OoooooooOO + Ooo00oOo00o - i1IIi % i11iIiiIii
  if 3 - 3: Ooo00oOo00o % Ooo00oOo00o
  if 83 - 83: II111iiii + o0oo0o
 def check_config ( self ) :
  oO00ooooO0o = True
  if 75 - 75: i1IIi / O0 * Ooo00oOo00o
  self . M3U_FILE_PATH = ( __addon__ . getSetting ( 'm3uFilepath' ) ) . strip ( )
  self . M3U_FILE_NAME = ( __addon__ . getSetting ( 'm3uFilename' ) ) . strip ( )
  self . M3U_ONWAVVE = True if __addon__ . getSetting ( 'onWavve' ) == 'true' else False
  self . M3U_ONTVING = True if __addon__ . getSetting ( 'onTvng' ) == 'true' else False
  self . M3U_ONSPOTV = True if __addon__ . getSetting ( 'onSpotv' ) == 'true' else False
  self . M3U_ONWAVVERADIO = True if __addon__ . getSetting ( 'onWavveRadio' ) == 'true' else False
  self . M3U_ONWAVVEHOME = True if __addon__ . getSetting ( 'onWavveHome' ) == 'true' else False
  self . M3U_ONSPOTVPAY = True if __addon__ . getSetting ( 'onSpotvPay' ) == 'true' else False
  self . M3U_DISPLAYNM = True if __addon__ . getSetting ( 'displayOTTnm' ) == 'true' else False
  if 29 - 29: oo % II11iiII - oo / II11iiII . i1IIi
  if self . M3U_FILE_PATH == '' or self . M3U_FILE_NAME == '' : oO00ooooO0o = False
  if self . M3U_ONWAVVE == False and self . M3U_ONTVING == '' and self . M3U_ONSPOTV == '' : oO00ooooO0o = False
  if 31 - 31: o0oo0o
  if oO00ooooO0o == False :
   O0OoOoo00o = xbmcgui . Dialog ( )
   OO00Oo = O0OoOoo00o . yesno ( __language__ ( 30901 ) . encode ( 'utf8' ) , __language__ ( 30902 ) . encode ( 'utf8' ) )
   if OO00Oo == True :
    __addon__ . openSettings ( )
    sys . exit ( )
   else :
    sys . exit ( )
    if 88 - 88: ooOO00oOo - Oo + II11iiII * oo % iIii1I11I1II1 + OoO0O00
    if 76 - 76: oo * i1I1ii1II1iII % o0oo0o
    if 57 - 57: iIii1I11I1II1 - i1IIi / o0oo0o - O0 * OoooooooOO % II111iiii
    if 68 - 68: OoooooooOO * OoOO0ooOOoo0O % oOo0O0Ooo - oooO0oo0oOOOO
 def MakeEpg_SaveJson ( self ) :
  I1 = { 'date_makeepg' : self . BoritvObj . Get_Now_Datetime ( ) . strftime ( '%Y-%m-%d' ) }
  try :
   III1Iiii1I11 = open ( ooO00oOoo , 'w' )
   json . dump ( I1 , III1Iiii1I11 )
   III1Iiii1I11 . close ( )
  except Exception as oOoOo0O0OOOoO :
   return
   if 50 - 50: Oo
   if 47 - 47: OoO0O00 * oOoO0oo0OOOo + iIii1I11I1II1 / o0oo0o / ooOO00oOo - OoooooooOO
   if 33 - 33: oOo0O0Ooo * II11iiII - II111iiii
   if 83 - 83: oOo0O0Ooo - o0000oOoOoO0o / OoOO0ooOOoo0O / o0oo0o + iiiiIi11i - O0
 def boritv_main ( self ) :
  if 4 - 4: II11iiII * ooOO00oOo % i1IIi * i11iIiiIii % OoO0O00 - iiiiIi11i
  OOoOoOo = self . main_params . get ( 'mode' , None )
  if 98 - 98: i1I1ii1II1iII
  self . check_config ( )
  if 68 - 68: iIii1I11I1II1 * iIii1I11I1II1 . Ooo00oOo00o / II111iiii % OoO0O00
  if OOoOoOo is None :
   self . dp_Main_List ( )
   if 38 - 38: Oo - II11iiII / i1I1ii1II1iII
  elif OOoOoOo == 'DEL_M3U' :
   self . dp_Delete_M3u ( self . main_params )
   if 66 - 66: O0 % oOoO0oo0OOOo + i11iIiiIii . oOo0O0Ooo / o0000oOoOoO0o + oOoO0oo0OOOo
  elif OOoOoOo == 'ADD_M3U' :
   self . dp_MakeAdd_M3u ( self . main_params )
   if 86 - 86: Ooo00oOo00o
  elif OOoOoOo == 'ADD_EPG' :
   self . dp_Make_Epg ( self . main_params )
   if 5 - 5: oooO0oo0oOOOO * oOo0O0Ooo
  else :
   None
   if 5 - 5: o0oo0o
   if 90 - 90: o0oo0o . Oo / o0000oOoOoO0o - OoOO0ooOOoo0O
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
