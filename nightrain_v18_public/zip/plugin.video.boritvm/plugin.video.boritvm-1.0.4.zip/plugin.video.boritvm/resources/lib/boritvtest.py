# -*- coding: utf-8 -*-
import sys
import json
import re


from boritvCore import *


##### main start #####
BoritvObj = Boritv()


#print( len(BoritvObj.Get_ChannelList_Wavve( [] ) ) )
#print( BoritvObj.Get_ChannelImg_Wavve() ) # 하위 실행
#print( BoritvObj.Get_ChannelList_WavveRadio() )


'''
ch_list = [ 'C00551', 'C15741', 'C01141', 'C04601', 'C01143', 'C01582', 'C00593', 'C00579', 'C01723', 'C22041'
          , 'C00611', 'C17141', 'C00575', 'C01142', 'C01581', 'C07381', 'C00585', 'C07382', 'C01583', 'C00708'
          , 'C06941', 'C15347', 'C43341', 'C00544', 'C05661', 'C00588', 'C43241', 'C17142', 'C43242', 'C00805'
          , 'C01101', 'C43342', 'C00590', 'C17341', 'C15846', 'C15152']
print( BoritvObj.make_Tving_ChannleGroup( ch_list ) )
'''

'''
ch_list = [ 'C00551', 'C15741', 'C01141', 'C04601', 'C01143', 'C01582', 'C00593', 'C00579', 'C01723', 'C22041'
          , 'C00611', 'C17141', 'C00575', 'C01142', 'C01581', 'C07381', 'C00585', 'C07382', 'C01583', 'C00708'
          , 'C06941', 'C15347', 'C43341', 'C00544', 'C05661', 'C00588', 'C43241', 'C17142', 'C43242', 'C00805'
          , 'C01101', 'C43342', 'C00590', 'C17341', 'C15846', 'C15152']
print( BoritvObj.Get_ChannelImg_Tving( ch_list ) ) # 하위 시행
'''

#print( len(BoritvObj.Get_ChannelList_Tving()) )

'''
# 방송  
          [ 'C00551', 'C15741', 'C01141', 'C04601', 'C01143', 'C01582', 'C00593', 'C00579', 'C01723', 'C22041'
          , 'C00611', 'C17141', 'C00575', 'C01142', 'C01581', 'C07381', 'C00585', 'C07382', 'C01583', 'C00708'
          , 'C06941', 'C15347', 'C43341', 'C00544', 'C05661', 'C00588', 'C43241', 'C17142', 'C43242',
          , 'C01101', 'C43342', 'C00590', 'C17341', 'C15846', 'C15152'    ]
'''

#print( BoritvObj.Get_Tving_Timeslice() )  # 하위

#print( BoritvObj.Get_ChannelList_Spotv( payyn = True ) )

#print( BoritvObj.Get_EpgInfo_Spotv( ) )
#print( BoritvObj.Get_EpgInfo_Wavve(radioyn=True) )


#print( BoritvObj.make_EpgDatetime_Tving()  )
#print( BoritvObj.Get_EpgInfo_Tving() )

#epgcount = 3
#for i in ( range(1,epgcount) ):
#	print(i)

#print( BoritvObj.Get_ChanneGenrename_Wavve('K01') )
print( BoritvObj.make_base_allchannel_py() )

##### main end #####
