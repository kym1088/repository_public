# -*- coding: utf-8 -*-
__author__ = "NightRain"

import urllib
import re
import json
import sys
import requests
import datetime
import time
import os

from channelgenre import *


reload(sys)
sys.setdefaultencoding('utf-8')


USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
TIME_GROUP = [ { 'starttm' : '000000', 'endtm' : '030000' }
			 , { 'starttm' : '030000', 'endtm' : '060000' }
			 , { 'starttm' : '060000', 'endtm' : '090000' }
			 , { 'starttm' : '090000', 'endtm' : '120000' }
			 , { 'starttm' : '120000', 'endtm' : '150000' }
			 , { 'starttm' : '150000', 'endtm' : '180000' }
			 , { 'starttm' : '180000', 'endtm' : '210000' }
			 , { 'starttm' : '210000', 'endtm' : '240000' }
]


##### Boritv class Start #####
class Boritv( object):
	def __init__( self ):
		self.API_WAVVE      = 'https://apis.wavve.com'
		self.API_TVING      = 'https://api.tving.com'
		self.API_TVINGIMG   = 'https://image.tving.com'
		self.API_SPOTV      = 'https://www.spotvnow.co.kr'
		self.HTTPTAG        = 'https://'
		self.LIMIT_WAVVE    = 200
		self.LIMIT_TVING    = 60
		self.LIMIT_TVINGEPG = 20 #사이트 최대값
		self.DEFAULT_HEADER = { 'user-agent' : USER_AGENT }
		self.SLEEP_TIME     = 0.2
		self.INIT_GENRESORT = MASTER_GENRE
		self.INIT_CHANNEL   = MASTER_CHANNEL


	def callRequestCookies( self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):
		setHeader = self.DEFAULT_HEADER
		if headers: setHeader.update( headers )

		if jobtype == 'Get': # Get/Post
			res = requests.get( url, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )
		else:
			res = requests.post( url, data=payload, params=params, headers=setHeader, cookies=cookies, allow_redirects=redirects )

		return res

	def Get_DefaultParams_Wavve ( self ):
		params = { 'apikey'     : 'E5F3E0D30947AA5440556471321BB6D9'
				 , 'credential' : 'none'
				 , 'device'     : 'pc'
				 , 'drm'        : 'wm'
				 , 'partner'    : 'pooq'
				 , 'pooqzone'   : 'none'
				 , 'region'     : 'kor'
				 , 'targetage'  : 'all'
				 }
		return params

	def Get_DefaultParams_Tving ( self ):
		params = { 'apiKey'      : '1e7952d0917d6aab1f0293a063697610'
				 , 'networkCode' : 'CSND0900'
				 , 'osCode'      : 'CSOD0900' #'CSOD0400'
				 , 'teleCode'    : 'CSCD0900'
				 , 'screenCode'  : 'CSSD0100'
		}
		return params


	def Get_Now_Datetime( self ):
		#return datetime.datetime.now( datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul') )
		return datetime.datetime.utcnow() + datetime.timedelta(hours=9)


	# String 특수기호 문자 변경
	def xmlText( self, in_text ):
		#out_text = in_text.replace('<','&lt;').replace('>','&gt;').replace('&','&amp;').replace('\'','&apos;').replace('\"','&quot;')
		out_text = in_text.replace('<','(').replace('>',')').replace('&lt;','(').replace('&gt;',')').replace('&','&amp;')
		#out_text = re.sub('\n|\!|\~|(@0@)|(@\^0@)', '', out_text)
		#out_text = out_text.lstrip('#')
		return out_text


	def Get_ChannelList_Wavve( self, exceptGroup=[] ):
		channel_list   = []
		except_channel = []

		# 채널 이미지 조회
		imglist = self.Get_ChannelImg_Wavve()

		# 채널 제외시 필요
		if exceptGroup != []:
			except_channel = self.Get_ChannelList_WavveExcept( exceptGroup )

		try:
			url = self.API_WAVVE + '/cf/live/recommend-channels'
			params = { 'WeekDay'       : 'all'
					 , 'broadcastid'   : '30783'
					 , 'contenttype'   : 'channel'
					 , 'isrecommend'   : 'y'
					 , 'limit'         : str(self.LIMIT_WAVVE) #200
					 , 'offset'        : '0'
					 , 'uicode'        : 'LN58'
					 , 'uiparent'      : 'GN54-LN58'
					 , 'uirank'        : '4'
					 , 'uitype'        : 'LN58'
					 }
			# 기본 params 추가
			params.update( self.Get_DefaultParams_Wavve() )

			response = self.callRequestCookies( 'Get', url, payload=None, params=params, headers=None, cookies=None )
			res_json = json.loads( response.text )

			if not ( 'celllist' in res_json['cell_toplist'] ) : return channel_list
			section_list = res_json['cell_toplist']['celllist']

			for i_section in section_list:

				channelid = i_section['contentid']
				channelnm = i_section['title_list'][0]['text']

				if channelid in imglist:
					channelimg = imglist[ channelid ]
				else:
					channelimg = ''

				temp_list = { 'channelid'  : channelid
							, 'channelnm'  : channelnm
							, 'channelimg' : self.HTTPTAG + channelimg if channelimg != '' else ''
							, 'ott'        : 'wavve'
							, 'genrenm'    : self.make_getGenre( channelid, 'wavve' )
				}

				if channelid not in except_channel : # 제외 채널
					channel_list.append( temp_list )

		except Exception as exception:
			print(exception)
			return []

		return channel_list


	def Get_ChannelList_WavveExcept( self, exceptGroup=[] ):
		channel_list = []
		if exceptGroup == []: return []

		try:
			url = self.API_WAVVE + '/cf/live/recommend-channels'

			for i_section in exceptGroup:
				params = { 'WeekDay'       : 'all'
						, 'adult'         : 'n'
						, 'broadcastid'   : i_section['broadcastid'] # '46584'
						, 'contenttype'   : 'channel'
						, 'genre'         : i_section['genre'] #'10'
						, 'isrecommend'   : 'y'
						, 'limit'         : str(self.LIMIT_WAVVE) #200
						, 'offset'        : '0'
						, 'uicode'        : 'LN58'
						, 'uiparent'      : 'GN54-LN58'
						, 'uirank'        : '4'
						, 'uitype'        : 'LN58'
						}
				# 기본 params 추가
				params.update( self.Get_DefaultParams_Wavve() )

				response = self.callRequestCookies( 'Get', url, payload=None, params=params, headers=None, cookies=None )
				res_json = json.loads( response.text )

				if not ( 'celllist' in res_json['cell_toplist'] ) : return channel_list
				section_list = res_json['cell_toplist']['celllist']

				for i_section in section_list:
					channel_list.append( i_section['contentid'] )

		except Exception as exception:
			print(exception)
			return []

		return channel_list



	def Get_ChannelImg_Wavve( self ):
		img_list = {}

		try:
			starttm = self.Get_Now_Datetime()
			endtm   = starttm + datetime.timedelta(hours=3)

			url = self.API_WAVVE + '/live/epgs'
			params = { 'limit'         : str(self.LIMIT_WAVVE) #200
					 , 'offset'        : '0'
					 , 'genre'         : 'all'
					 , 'startdatetime' : starttm.strftime('%Y-%m-%d %H:00')
					 , 'enddatetime'   : endtm.strftime('%Y-%m-%d %H:00')
			}
			params.update( self.Get_DefaultParams_Wavve() )

			response = self.callRequestCookies( 'Get', url, payload=None, params=params, headers=None, cookies=None )
			res_json = json.loads( response.text )

			section_list = res_json['list']

			for i_section in section_list:
				img_list[i_section['channelid']] = i_section['channelimage']

		except Exception as exception:
			print(exception)

		return img_list

	def Get_ChanneGenrename_Wavve( self, channelid ):

		try:
			url = self.API_WAVVE + '/live/channels/' + channelid
			# 기본 params 추가
			params = self.Get_DefaultParams_Wavve()

			response = self.callRequestCookies( 'Get', url, payload=None, params=params, headers=None, cookies=None )
			res_json = json.loads( response.text )

			genrenm = res_json['genretext']

		except Exception as exception:
			print(exception)
			return ''

		return genrenm


	def Get_ChannelList_Spotv( self, payyn=True ):
		channel_list = []

		try:
			url = self.API_SPOTV + '/api/v2/channel'

			response = self.callRequestCookies( 'Get', url, payload=None, params=None, headers=None, cookies=None )
			res_json = json.loads( response.text )

			for i_section in res_json:
				channelid = i_section['videoId'].replace('ref:','')
				temp_list = { 'channelid'  : channelid
							, 'channelnm'  : i_section['name']
							, 'channelimg' : i_section['logo']
							, 'ott'        : 'spotv'
							, 'genrenm'    : self.make_getGenre( channelid, 'spotv' )
							#, 'free'       : i_section['free']
							#, 'mediaid'    : i_section['id']
				}
				if payyn == True or i_section['free'] == True :
					channel_list.append( temp_list )
		except Exception as exception:
			print(exception)
			return []

		return channel_list


	def Get_ChannelList_Tving( self ):
		channel_list   = []
		channelid_list = []

		try:
			url = self.API_TVING + '/v2/media/lives'
			params = { 'pageNo'      : '1'
					 , 'pageSize'    : str(self.LIMIT_TVING) # 60
					 , 'order'       : 'rating' #'rating'
					 , 'adult'       : 'all'
					 , 'free'        : 'all'
					 , 'guest'       : 'all'
					 , 'scope'       : 'all'
					 , 'channelType' : 'CPCS0100,CPCS0400'
					 #, 'callback'    : 'jQuery12394_1576218354638'
					 #, '_'           : '1604107324360'
			}
			# 기본 params 추가
			params.update( self.Get_DefaultParams_Tving() )

			response = self.callRequestCookies( 'Get', url, payload=None, params=params, headers=None, cookies=None )
			res_json = json.loads( response.text )

			if not ( 'result' in res_json['body'] ) : return channel_list
			section_list = res_json['body']['result']

			#img 확인
			for i_section in section_list:
				if i_section['live_code'] == 'C44441' : continue #추가유료채널
				channelid_list.append( i_section['live_code'] )


			# 채널 이미지 조회
			imglist = self.Get_ChannelImg_Tving( channelid_list )


			# 채널조회
			for i_section in section_list:

				channelid = i_section['live_code']
				if channelid == 'C44441' : continue #추가유료채널
				channelnm = i_section['schedule']['channel']['name']['ko']

				if channelid in imglist:
					channelimg = imglist[ channelid ]
				else:
					channelimg = ''

				temp_list = { 'channelid'  : channelid
							, 'channelnm'  : channelnm
							, 'channelimg' : channelimg
							, 'ott'        : 'tving'
							, 'genrenm'    :  self.make_getGenre( channelid, 'tving' )
				}

				channel_list.append( temp_list )

		except Exception as exception:
			print(exception)
			return []

		return channel_list



	def make_EpgDatetime_Tving( self, days=2 ):
		datetime_list = []

		days_list = self.make_DateList( days=2, dateType='2' )

		nowtm = int( self.Get_Now_Datetime().strftime('%Y%m%d%H0000') )

		for i_section in days_list:
			for timenum in range( 8 ):
				temp_list = { 'ndate'   : i_section
							, 'starttm' : TIME_GROUP[timenum]['starttm']
							, 'endtm'   : TIME_GROUP[timenum]['endtm']
				}

				temp_stm = int( i_section+TIME_GROUP[timenum]['starttm'] )
				temp_etm = int( i_section+TIME_GROUP[timenum]['endtm'] )

				if nowtm <= temp_stm or ( temp_stm < nowtm and nowtm < temp_etm ):
				#if ( temp_stm < nowtm and nowtm < temp_etm ):
					datetime_list.append( temp_list )

		return datetime_list


	# 공통사용
	def make_DateList( self, days=2, dateType='1' ):
		days_list = []
		nowdate   = self.Get_Now_Datetime()

		if dateType == '1': ## 스포티비는 전날부터
			nowdate = nowdate - datetime.timedelta( days=1 )


		for i in range(days):
			temp_day = nowdate + datetime.timedelta( days=i )

			if dateType == '1':
				days_list.append( temp_day.strftime('%Y-%m-%d') )
			else:
				days_list.append( temp_day.strftime('%Y%m%d') )

		return days_list


	def make_Tving_ChannleGroup( self, channelid_list ):
		chstr_group = []
		i = 0
		ch_str = ''

		for i_chid in channelid_list:
			if i == 0 : ch_str = i_chid
			else: ch_str += ',%s' %(i_chid)

			i += 1
			if i >= self.LIMIT_TVINGEPG:
				chstr_group.append( ch_str )
				i = 0
				ch_str = ''
		
		if ch_str != '':
			chstr_group.append( ch_str )
		
		return chstr_group


	def Get_ChannelImg_Tving( self, chid_list ):
		img_list = {}

		try:
			broadDate = self.Get_Now_Datetime().strftime('%Y%m%d')
			starttm   = TIME_GROUP[6]['starttm']  #6  'starttm':'180000', 'endtm':'210000' 
			endtm     = TIME_GROUP[6]['endtm']


			chstr_group = self.make_Tving_ChannleGroup( chid_list )

			for i_section in chstr_group:
				url = self.API_TVING + '/v2/media/schedules'
				params = { 'pageNo'        : '1'
						, 'pageSize'      : str(self.LIMIT_TVINGEPG) #최대20까지 가능 #self.LIMIT_TVING # 60
						, 'order'         : 'chno'
						, 'scope'         : 'all'
						, 'adult'         : 'n'
						, 'free'          : 'all'
						, 'broadDate'     : broadDate #20201031
						, 'broadcastDate' : broadDate
						, 'startBroadTime': starttm #180000
						, 'endBroadTime'  : endtm #210000
						, 'channelCode'   : i_section

				}
				params.update( self.Get_DefaultParams_Tving() )

				response = self.callRequestCookies( 'Get', url, payload=None, params=params, headers=None, cookies=None )
				res_json = json.loads( response.text )

				if not ( 'result' in res_json['body'] ) : return {}
				section_list = res_json['body']['result']

				for i_section in section_list:
					#img_list[i_section['channel_code']] = self.API_TVINGIMG + i_section['image'][0]['url']
					img_list[i_section['channel_code']] = self.API_TVINGIMG + i_section['image'][2]['url']

		except Exception as exception:
			print(exception)
			return {}

		return img_list


	def Get_EpgInfo_Spotv( self, days=3, payyn=True ):
		find_list    = {}
		channel_list = []
		epg_list     = []

		days_list = self.make_DateList( days=days, dateType='1' )
		#print ( days_list )


		try:
			url = self.API_SPOTV + '/api/v2/channel'

			response = self.callRequestCookies( 'Get', url, payload=None, params=None, headers=None, cookies=None )
			res_json = json.loads( response.text )

			for i_section in res_json:
				channelid  = i_section['videoId'].replace('ref:','')
				temp_list = { 'channelid'  : channelid
							, 'channelnm'  : self.xmlText( i_section['name'] )
							, 'channelimg' : i_section['logo']
							, 'ott'        : 'spotv'
				}

				if payyn == True or i_section['free'] == True :
					find_list[ i_section['id'] ] = channelid
					channel_list.append( temp_list )

		except Exception as exception:
			print(exception)
			return [], []


		try:
			for now_day in days_list:
				url = self.API_SPOTV + '/api/v2/program/' + now_day

				response = self.callRequestCookies( 'Get', url, payload=None, params=None, headers=None, cookies=None )
				res_json = json.loads( response.text )

				for i_section in res_json:
					if find_list.get( i_section['channelId'] ) == None:	continue

					temp_list = { 'channelid'  : find_list.get( i_section['channelId'] )
								, 'title'      : self.xmlText( i_section['title'] )
								, 'startTime'  : i_section['startTime'].replace('-','').replace(' ','').replace(':','')+'00'
								, 'endTime'    : i_section['endTime'].replace('-','').replace(' ','').replace(':','')+'00'
								, 'ott'        : 'spotv'
					}
					epg_list.append( temp_list )

				time.sleep(self.SLEEP_TIME) #####

		except Exception as exception:
			print(exception)
			return [], []

		return channel_list, epg_list


	def Get_EpgInfo_Wavve( self, days=2, exceptGroup=[] ):
		channel_list   = []
		epg_list       = []
		except_channel = []


		# 조회시간
		nowdate       = self.Get_Now_Datetime()
		fromdate      = nowdate + datetime.timedelta( hours=-2  )
		todate        = nowdate + datetime.timedelta( days=(days-1) )
		if int(fromdate.strftime('%H')) <= 3 :
			startdatetime = fromdate.strftime('%Y-%m-%d 00:00')
		else:
			startdatetime = fromdate.strftime('%Y-%m-%d %H:00')
		enddatetime   = todate.strftime('%Y-%m-%d 24:00')


		# 채널 제외시 필요
		if exceptGroup != []:
			except_channel = self.Get_ChannelList_WavveExcept( exceptGroup )


		try:
			url = self.API_WAVVE + '/live/epgs'
			params = { 'limit'         : str(self.LIMIT_WAVVE)
					 , 'offset'        : '0'
					 , 'genre'         : 'all'
					 , 'startdatetime' : startdatetime
					 , 'enddatetime'   : enddatetime
			}
			params.update( self.Get_DefaultParams_Wavve() )

			response = self.callRequestCookies( 'Get', url, payload=None, params=params, headers=None, cookies=None )
			res_json = json.loads( response.text )

			epgjson = res_json['list']
	
			for i_section in epgjson:
				temp_list = { 'channelid'  : i_section['channelid']
							, 'channelnm'  : self.xmlText( i_section['channelname'] )
							, 'channelimg' : self.HTTPTAG + i_section['channelimage']
							, 'ott'        : 'wavve'
				}

				if i_section['channelid'] not in except_channel : # 라디오채널 제외
					channel_list.append( temp_list )

				for channel in i_section['list']:
					temp_list = { 'channelid'  : i_section['channelid']
								, 'title'      : self.xmlText( channel['title'] )
								, 'startTime'  : channel['starttime'].replace('-','').replace(' ','').replace(':','')+'00'  #20201101040000
								, 'endTime'    : channel['endtime'].replace('-','').replace(' ','').replace(':','')+'00'
								, 'ott'        : 'wavve'
					}

 					# 라디오채널 제외, 시작/종료 동일건 제외
					if i_section['channelid'] not in except_channel and channel['starttime'] != channel['endtime'] :
						epg_list.append( temp_list )

		except Exception as exception:
			print(exception)
			return [], []

		# 종료시간 1분 공백처리
		epgcnt = len(epg_list)
		for i in ( range(1, epgcnt) ):
			if int(epg_list[i-1]['endTime']) + 1 == int(epg_list[i]['startTime']) and epg_list[i-1]['channelid'] == epg_list[i]['channelid'] :
				epg_list[i-1]['endTime'] = epg_list[i]['startTime']

		return channel_list, epg_list


	def Get_EpgInfo_Tving( self, days=2 ):
		channel_list = []
		epg_list     = []
		exists_list  = []

		# 시간대
		TIME_LIST     = self.make_EpgDatetime_Tving( days=days )
		#print(TIME_LIST)
		#TIME_LIST = [{'ndate': '20201108', 'starttm': '030000', 'endtm': '060000'}]### test

		# 채널조회
		channel_list  = self.Get_ChannelList_Tving()
		chstr_list = []
		#for i_section in channel_list:
		#	chstr_list.append( i_section['channelid'] )
		for i in range(len(channel_list)):
			channel_list[i]['channelnm'] = self.xmlText( channel_list[i]['channelnm'] )
			chstr_list.append( channel_list[i]['channelid'] )
		#chstr_list = [  'C01345' ] #


		#chstr_list  = ['C01582']#,'C00708'] #test
		CHANNEL_GROUP = self.make_Tving_ChannleGroup( chstr_list )

		try:
			url = self.API_TVING + '/v2/media/schedules'

			for i_time in TIME_LIST:
				#print(i_time)
				for i_channel in CHANNEL_GROUP:

					params = { 'pageNo'        : '1'
							, 'pageSize'      : str(self.LIMIT_TVINGEPG) #최대20까지 가능 #self.LIMIT_TVING # 60
							, 'order'         : 'chno'
							, 'scope'         : 'all'
							, 'adult'         : 'n'
							, 'free'          : 'all'
							, 'broadDate'     : i_time['ndate'] #20201031
							, 'broadcastDate' : i_time['ndate']
							, 'startBroadTime': i_time['starttm'] #180000
							, 'endBroadTime'  : i_time['endtm']   #210000
							, 'channelCode'   : i_channel

					}
					params.update( self.Get_DefaultParams_Tving() )

					response = self.callRequestCookies( 'Get', url, payload=None, params=params, headers=None, cookies=None )
					res_json = json.loads( response.text )
					#print(res_json)

					section_list = res_json['body']['result']
					for i_section in section_list: # 채널수 반복

						if 'schedules' not in i_section : continue
						if i_section['schedules'] == None : continue

						for i_program in i_section['schedules']:
							temp_list = { 'channelid'  : i_program['schedule_code']
										, 'title'      : self.xmlText( i_program['program']['name']['ko'] )
										, 'startTime'  : str(i_program['broadcast_start_time'])
										, 'endTime'    : str(i_program['broadcast_end_time'])
										, 'ott'        : 'tving'
							}
							exists_str = i_program['schedule_code']+str(i_program['broadcast_start_time'])
							if exists_str in exists_list: continue
							
							exists_list.append( exists_str )
							epg_list.append( temp_list )

					time.sleep(self.SLEEP_TIME) #####

		except Exception as exception:
			print(exception)
			return [], []

		return channel_list, epg_list


	def make_getGenre( self, channelid, ott ):
		try:
			genrenm = self.INIT_CHANNEL.get(channelid + '.' + ott).get('genre')
		except:
			genrenm = '-'
		return genrenm


	def make_base_allchannel_py( self ):
		tot_list  = []
		sort_list = []
		genne_set = set()

		temp_list = self.Get_ChannelList_Wavve()
		tot_list.extend(temp_list)

		temp_list = self.Get_ChannelList_Tving()
		tot_list.extend(temp_list)

		temp_list = self.Get_ChannelList_Spotv()
		tot_list.extend(temp_list)

		# 장르 가져오기
		print('1')
		for i in range(len(tot_list)):
			if tot_list[i]['genrenm'] == '-':
				if tot_list[i]['ott'] == 'wavve':
					genrenm = self.Get_ChanneGenrename_Wavve( tot_list[i]['channelid'] )
					if genrenm not in genne_set: genne_set.add(genrenm)
					time.sleep(self.SLEEP_TIME) #####
				elif tot_list[i]['ott'] == 'spotv':
					genrenm = '스포츠'
				else:
					genrenm = '-'
				tot_list[i]['genrenm'] = genrenm
			else:
				if tot_list[i]['genrenm'] not in genne_set: genne_set.add(tot_list[i]['genrenm'])

		genne_set.add('-')

		# 장르별로 다시 가져오기(정렬)
		print('2')
		for i_genne in genne_set:
			for i_list in tot_list:
				if i_list['genrenm'] == i_genne:
					sort_list.append( i_list )
		#  누락체크
		for i_list in tot_list:
			if i_list['genrenm'] not in genne_set: 
				SORT_LIST.append( i_list )

		# 파일생성
		print('3')
		filename = 'c:\\job\\channelgenre.json'
		if os.path.isfile(filename): os.remove(filename)

		fp = open(filename, 'w')
		fp.write('MASTER_CHANNEL = {\n')

		totcnt = len(sort_list)
		i = 0
		for i_section in sort_list:
			i += 1
			channelid  = i_section['channelid']
			channelnm  = i_section['channelnm']
			ott        = i_section['ott']
			tvgid      = '%s.%s' %( channelid, ott )
			genrenm    = i_section['genrenm']

			line_str = '\t"%s" : { "channelnm" : "%s", "genre" : "%s" }' %( tvgid, channelnm, genrenm )
			if i < totcnt:
				fp.write( line_str + ',\n')
			else:
				fp.write( line_str + '\n')

		fp.write('}\n')
		fp.close()

		return genne_set



##### Boritv class End #####


