# -*- coding: utf-8 -*-
__author__ = "NightRain"

import os
import xbmcplugin, xbmcgui, xbmcaddon, xbmc, xbmcvfs
import sys
import datetime
import time
import urllib

reload(sys)
sys.setdefaultencoding('utf-8')

MAIN_GROUP = [
	  { 'title' : '*** 간단설명 (개별 OTT 애드온 필수) ***'              , 'mode' : 'XXX' }
	, { 'title' : '     1. 국내 OTT 실시간 채널 M3U 파일 생성 (아래 메뉴 클릭)', 'mode' : 'XXX' }
	, { 'title' : '     2. PVR IPTV Simple Client 에서 재생 (KODI 기본저장소)', 'mode' : 'XXX' }
	, { 'title' : '-----------------' , 'mode' : 'XXX' }
	, { 'title' : '-> M3U 파일 초기화/삭제'       , 'mode' : 'DEL_M3U' }
	, { 'title' : '     - M3U 추가 (웨이브)'     , 'mode' : 'ADD_M3U' , 'sType' : 'wavve', 'sName' : '웨이브'      }
	, { 'title' : '     - M3U 추가 (티빙)'       , 'mode' : 'ADD_M3U' , 'sType' : 'tving', 'sName' : '티빙'        }
	, { 'title' : '     - M3U 추가 (스포티비)'   , 'mode' : 'ADD_M3U' , 'sType' : 'spotv', 'sName' : '스포티비나우'}
	, { 'title' : '-> M3U (삭제후 일괄생성)'      , 'mode' : 'ADD_M3U' , 'sType' : 'all',    'sName' : '전체'       }
	, { 'title' : '-----------------' , 'mode' : 'XXX' }
	, { 'title' : '-> EPG 생성 (삭제후 일괄생성)' , 'mode' : 'ADD_EPG' , 'sType' : 'all',   'sName' : '전체'       }
]


__addon__     = xbmcaddon.Addon()
__language__  = __addon__.getLocalizedString
__profile__   = xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__   = __addon__.getAddonInfo('version')
__addonid__   = __addon__.getAddonInfo('id')
__addonname__ = __addon__.getAddonInfo('name')


USER_AGENT2 = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
EPGDATE_FILE_NAME = xbmc.translatePath(os.path.join(__profile__, 'boritv_update.json'))

from boritvCore import *


class BoritvRun( object ):
	def __init__( self, in_addonurl, in_handle, in_params ):
		self._addon_url       = in_addonurl
		self._addon_handle    = in_handle
		self.main_params      = in_params
		self.M3U_FILE_PATH    = '' #'d:\\job\\'
		self.M3U_FILE_NAME    = '' #'boritv.m3u'
		self.M3U_ONWAVVE      = False
		self.M3U_ONTVING      = False
		self.M3U_ONSPOTV      = False
		self.M3U_ONWAVVERADIO = False
		self.M3U_ONWAVVEHOME  = False
		self.M3U_ONSPOTVPAY   = False
		self.M3U_DISPLAYNM    = False
		self.M3U_AUTORESTART  = False
		self.BoritvObj        = Boritv()  ### main class 생성


	### addon_noti start ###
	def addon_noti( self, sting ):
		try:
			dialog = xbmcgui.Dialog()
			dialog.notification(__addonname__, sting)
		except:
			None
	### addon_noti end ###

	### addon_log start ###
	def addon_log( self, string ):
		try:
			log_message = string.encode('utf-8', 'ignore')
		except:
			log_message = 'addonException: addon_log'
		#if isDebug: level = xbmc.LOGDEBUG
		#else: level = xbmc.LOGNOTICE
		level = xbmc.LOGINFO
		xbmc.log( "[%s-%s]: %s" %(__addonid__, __version__, log_message), level=level )
	### addon_log end ###


	### get_keyboard_input start ###
	def get_keyboard_input( self, title ):
		input_text = None
		kb = xbmc.Keyboard()
		kb.setHeading( title )
		xbmc.sleep(1000)
		kb.doModal()
		if (kb.isConfirmed()):
			input_text = kb.getText()
		return input_text
	### get_keyboard_input end ###


	### add folder start ###
	def add_dir( self, label, sublabel='', img='', infoLabels=None, isFolder=True, params='' ):
		url = '%s?%s' %(self._addon_url, urllib.urlencode(params))

		if sublabel: title = '%s < %s >' % (label, sublabel)
		else: 		 title = label
		if not img: img = 'DefaultFolder.png'

		listitem = xbmcgui.ListItem(title)
		listitem.setArt({'thumbnailImage':img, 'icon':img, 'poster': img})

		if infoLabels: listitem.setInfo(type="video", infoLabels=infoLabels)
		if not isFolder: listitem.setProperty('IsPlayable', 'true')	

		xbmcplugin.addDirectoryItem(self._addon_handle, url, listitem, isFolder)
	### add folder end ###


	### make_M3u_Filename end ###
	def make_M3u_Filename( self, tempyn=False ) :
		if tempyn:
			return xbmc.translatePath(os.path.join(__profile__, 'boritv_temp.m3u'))
		else:
			return self.M3U_FILE_PATH + self.M3U_FILE_NAME + '.m3u'
	### make_M3u_Filename end ###


	### make_Epg_Filename end ###
	def make_Epg_Filename( self, tempyn=False ) :
		if tempyn:
			return xbmc.translatePath(os.path.join(__profile__, 'boritv_temp.xml'))
		else:
			return self.M3U_FILE_PATH + self.M3U_FILE_NAME + '.xml'
	### make_Epg_Filename end ###


	### dp_Main_List start ###
	def dp_Main_List( self ):
		# main list
		for main_group in MAIN_GROUP:
			title = main_group.get('title')

			params = { 'mode'    : main_group.get('mode')
					 , 'sType'   : main_group.get('sType')
					 , 'sName'   : main_group.get('sName')
			}

			if main_group.get('mode') == 'XXX':
				isFolder = False
			else:
				isFolder = True

			addYn = True
			if main_group.get('mode') == 'ADD_M3U':
				if main_group.get('sType') == 'wavve' and self.M3U_ONWAVVE == False : addYn = False
				if main_group.get('sType') == 'tving' and self.M3U_ONTVING == False : addYn = False
				if main_group.get('sType') == 'spotv' and self.M3U_ONSPOTV == False : addYn = False

			if addYn == True:
				self.add_dir(title, sublabel='', img='', infoLabels=None, isFolder=isFolder, params=params)

		if len(MAIN_GROUP) > 0: xbmcplugin.endOfDirectory( self._addon_handle, cacheToDisc=True )
	### dp_Main_List end ###


	### dp_Delete_M3u start ###
	def dp_Delete_M3u( self, args ):
		dialog = xbmcgui.Dialog()
		ret = dialog.yesno(  __language__(30903).encode('utf8'), __language__(30904).encode('utf8') )
		if ret == False: sys.exit()

 		#파일삭제
		#filename = self.make_M3u_Filename()
		#if os.path.isfile(filename): os.remove(filename)

 		#파일삭제
		filename = self.make_M3u_Filename(tempyn=False)
		if xbmcvfs.exists(filename):
			if xbmcvfs.delete(filename) == False:
				self.addon_noti(__language__(30910).encode('utf-8'))
				return

		self.addon_noti(__language__(30905).encode('utf-8'))
	### dp_Delete_M3u start ###


	### dp_MakeAdd_M3u start ###
	def dp_MakeAdd_M3u( self, args ):

		sType = args.get('sType')	
		sName = args.get('sName')	

		dialog = xbmcgui.Dialog()
		ret = dialog.yesno( (sName + __language__(30906)).encode('utf8'), __language__(30907).encode('utf8') )
		if ret == False: sys.exit()

		GN_LIST    = []
		SORT_LIST  = []
		RADIO_LIST = []

		# 삭제후 일괄생성
		#if sType == 'all' :
		#	filename = self.make_M3u_Filename()
		#	if os.path.isfile(filename): os.remove(filename)

		# 삭제후 일괄생성
		if sType == 'all' :
			#temp파일 삭제
			filename = self.make_M3u_Filename(tempyn=True)
			if os.path.isfile(filename): os.remove(filename)
			#실제파일 삭제
			filename = self.make_M3u_Filename(tempyn=False)
			if xbmcvfs.exists(filename):
				if xbmcvfs.delete(filename) == False:
					self.addon_noti(__language__(30910).encode('utf-8'))
					return


		# wavve
		if ( sType == 'wavve' or sType == 'all' ) and self.M3U_ONWAVVE :
			temp_list = self.BoritvObj.Get_ChannelList_Wavve( exceptGroup=self.make_EexceptGroup_Wavve() )
			if len(temp_list) != 0: GN_LIST.extend(temp_list)
			RADIO_LIST = self.get_radio_list() ### radio
			self.addon_log( 'wavve cnt ----> ' + str(len(temp_list)) )

		# tving
		if ( sType == 'tving' or sType == 'all' ) and self.M3U_ONTVING :
			temp_list = self.BoritvObj.Get_ChannelList_Tving()
			if len(temp_list) != 0: GN_LIST.extend(temp_list)
			self.addon_log( 'tving cnt ----> ' + str(len(temp_list)) )

		# spotv
		if ( sType == 'spotv' or sType == 'all' ) and self.M3U_ONSPOTV :
			temp_list = self.BoritvObj.Get_ChannelList_Spotv( payyn=self.M3U_ONSPOTVPAY )
			if len(temp_list) != 0: GN_LIST.extend(temp_list)
			self.addon_log( 'spotv cnt ----> ' + str(len(temp_list)) )

		if len(GN_LIST) == 0:
			self.addon_noti( __language__(30909).encode('utf8') )
			return

		# 소트
		for i_genre in self.BoritvObj.INIT_GENRESORT:
			for i_list in GN_LIST:
				if i_list['genrenm'] == i_genre:
					SORT_LIST.append( i_list )
		#  누락체크
		for i_list in GN_LIST:
			if i_list['genrenm'] not in self.BoritvObj.INIT_GENRESORT: 
				SORT_LIST.append( i_list )

		try:
			#filename = self.make_M3u_Filename()
			filename = self.make_M3u_Filename(tempyn=True)

			if os.path.isfile(filename) :
				fp = open(filename, 'a')
			else:
				fp = open(filename, 'w')
				fp.write('#EXTM3U\n')

			for gn_list in SORT_LIST:

				channelid  = gn_list['channelid']
				channelnm  = gn_list['channelnm']
				channelimg = gn_list['channelimg']
				ott        = gn_list['ott']
				tvgid      = '%s.%s' %( channelid, ott )
				channelgenre = gn_list['genrenm']

				if self.M3U_DISPLAYNM :
					channelnm = '%s (%s)' %( channelnm, ott )

				#m3uinfo = '#EXTINF:-1 tvg-chno="" tvg-ID="%s" tvg-name="%s" tvg-logo="%s" tvh-chnum="",%s\n' %(tvgid, channelnm, channelimg, channelnm)
				if channelid in RADIO_LIST:
					m3uinfo = '#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s" radio="true",%s\n' %(tvgid, channelnm, channelgenre, channelimg, channelnm)
				else:
					m3uinfo = '#EXTINF:0 tvg-ID="%s" tvg-name="%s" group-title="%s" tvg-logo="%s",%s\n' %(tvgid, channelnm, channelgenre, channelimg, channelnm)

				if ott == 'wavve' :
					m3uurl  = 'plugin://plugin.video.wavvem/?mode=LIVE&contentid=%s&pvrmode=pvr\n' %(channelid)
				elif ott == 'tving' :
					m3uurl  = 'plugin://plugin.video.tvingm/?mode=LIVE&mediacode=%s&stype=onair&pvrmode=pvr\n' %(channelid)
				elif ott == 'spotv' :
					#mediaid = gn_list['mediaid']
					#free    = gn_list['free']
					#m3uurl  = 'plugin://plugin.video.spotvm/?mode=LIVE&mediaid=%s&mediacode=%s&free=%s&mediatype=live\n' %(mediaid, channelid, free)
					m3uurl  = 'plugin://plugin.video.spotvm/?mode=LIVE&mediacode=%s&mediatype=live\n' %(channelid)

				fp.write(m3uinfo)
				fp.write(m3uurl)

			fp.close()
		except:
			self.addon_noti( __language__(30910).encode('utf8') )
			return

		# 파일복사
		asis_filename = self.make_M3u_Filename(tempyn=True)
		tobe_filename = self.make_M3u_Filename(tempyn=False)
		if xbmcvfs.copy(asis_filename, tobe_filename):
			self.addon_noti( (sName + ' ' + __language__(30908)).encode('utf8') )
		else:
			self.addon_noti(__language__(30910).encode('utf-8'))

		#self.addon_noti( (sName + ' ' + __language__(30908)).encode('utf8') )
	### dp_MakeAdd_M3u end ###


	### dp_Make_Epg start ###
	def dp_Make_Epg( self, args ):

		sType = args.get('sType')	
		sName = args.get('sName')	
		sNoti = args.get('sNoti') ## 자동생성을 위해

		if sNoti != 'N':
			dialog = xbmcgui.Dialog()
			ret = dialog.yesno( (sName + __language__(30911)).encode('utf8'), __language__(30907).encode('utf8') )
			if ret == False: sys.exit()

		CH_LIST = []
		EPG_LIST = []


		# wavve
		if ( sType == 'wavve' or sType == 'all' ) and self.M3U_ONWAVVE :
			temp_ch, temp_epg = self.BoritvObj.Get_EpgInfo_Wavve( exceptGroup=self.make_EexceptGroup_Wavve() )
			if len(temp_epg) != 0:
				CH_LIST.extend(temp_ch)
				EPG_LIST.extend(temp_epg)

		# tving
		if ( sType == 'tving' or sType == 'all' ) and self.M3U_ONTVING :
			temp_ch, temp_epg = self.BoritvObj.Get_EpgInfo_Tving()
			if len(temp_epg) != 0:
				CH_LIST.extend(temp_ch)
				EPG_LIST.extend(temp_epg)

		# spotv
		if ( sType == 'spotv' or sType == 'all' ) and self.M3U_ONSPOTV :
			temp_ch, temp_epg = self.BoritvObj.Get_EpgInfo_Spotv( payyn=self.M3U_ONSPOTVPAY )
			if len(temp_epg) != 0:
				CH_LIST.extend(temp_ch)
				EPG_LIST.extend(temp_epg)

		if len(EPG_LIST) == 0:
			if sNoti != 'N': self.addon_noti( __language__(30909).encode('utf8') )
			return

		try:
			#filename = self.make_Epg_Filename()
			filename = self.make_Epg_Filename(tempyn=True)
			fp = open(filename, 'w')

			xmltext_1 = '<?xml version="1.0" encoding="UTF-8"?>\n'
			xmltext_2 = '<!DOCTYPE tv SYSTEM "xmltv.dtd">\n\n'
			xmltext_3 = '<tv generator-info-name="boritv_epg">\n\n'
			xmltext_4 = '\n</tv>\n'

			fp.write(xmltext_1)
			fp.write(xmltext_2)
			fp.write(xmltext_3)

			# 채널정보
			for i_section in CH_LIST:
				temptext_1 = '  <channel id="%s.%s">\n'              %( i_section.get('channelid'), i_section.get('ott') )
				temptext_2 = '    <display-name>%s</display-name>\n' %( i_section.get('channelnm') )
				temptext_3 = '    <icon src="%s" />\n'               %( i_section.get('channelimg') )
				temptext_4 = '  </channel>\n\n'
				fp.write(temptext_1)
				fp.write(temptext_2)
				fp.write(temptext_3)
				fp.write(temptext_4)

			# EPG 정보
			for i_section in EPG_LIST:
				temptext_1 = '  <programme start="%s +0900" stop="%s +0900" channel="%s.%s">\n' %( i_section.get('startTime'), i_section.get('endTime'), i_section.get('channelid'), i_section.get('ott') )
				temptext_2 = '    <title lang="kr">%s</title>\n'                                %( i_section.get('title') )
				temptext_3 = '  </programme>\n\n'
				fp.write(temptext_1)
				fp.write(temptext_2)
				fp.write(temptext_3)

			fp.write(xmltext_4)

			fp.close()
		except:
			if sNoti != 'N': self.addon_noti( __language__(30910).encode('utf8') )
			return

		self.MakeEpg_SaveJson()

		# 파일복사
		asis_filename = self.make_Epg_Filename(tempyn=True)
		tobe_filename = self.make_Epg_Filename(tempyn=False)
		if xbmcvfs.copy(asis_filename, tobe_filename):
			if sNoti != 'N': self.addon_noti( (sName + ' ' + __language__(30912)).encode('utf8') )
		else:
			self.addon_noti(__language__(30910).encode('utf-8'))

		# pvr 재시작 (epg 강제적용)
		try:
			if self.M3U_AUTORESTART:
				#addon = xbmcaddon.Addon('pvr.iptvsimple')
				#addon.setSetting('anything', 'anything')
				xbmc.executebuiltin('InstallAddon(pvr.demo)', True)
				xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":true}}')
				xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false}}')				
		except:
			None	

		#if sNoti != 'N': self.addon_noti( (sName + ' ' + __language__(30912)).encode('utf8') )
	### dp_Make_Epg end ###


	### make_EexceptGroup_Wavve start ###
	def make_EexceptGroup_Wavve( self ):
		except_group = []

		if self.M3U_ONWAVVERADIO == False:
			temp_group = { 'broadcastid' : '46584'
						 , 'genre'       : '10' # 라디오
						 }
			except_group.append(temp_group)

		if self.M3U_ONWAVVEHOME == False:
			temp_group = { 'broadcastid' : '46584'
						 , 'genre'       : '03' # 홈쇼핑
						 }
			except_group.append(temp_group)

		return except_group
	### make_EexceptGroup_Wavve end ###


	### get_radio_list end ###
	def get_radio_list( self ):
		if self.M3U_ONWAVVERADIO == False: return []

		temp_group = [{ 'broadcastid' : '46584'
					 , 'genre'       : '10' # 라디오
					 }]
		return self.BoritvObj.Get_ChannelList_WavveExcept( temp_group )
	### get_radio_list end ###


	### check_config start ###
	def check_config( self ):
		checkyn = True

		self.M3U_FILE_PATH    = (__addon__.getSetting( 'm3uFilepath' )).strip()
		self.M3U_FILE_NAME    = (__addon__.getSetting( 'm3uFilename' )).strip()
		self.M3U_ONWAVVE      = True if __addon__.getSetting( 'onWavve'      ) == 'true' else False
		self.M3U_ONTVING      = True if __addon__.getSetting( 'onTvng'       ) == 'true' else False
		self.M3U_ONSPOTV      = True if __addon__.getSetting( 'onSpotv'      ) == 'true' else False
		self.M3U_ONWAVVERADIO = True if __addon__.getSetting( 'onWavveRadio' ) == 'true' else False
		self.M3U_ONWAVVEHOME  = True if __addon__.getSetting( 'onWavveHome'  ) == 'true' else False
		self.M3U_ONSPOTVPAY   = True if __addon__.getSetting( 'onSpotvPay'   ) == 'true' else False
		self.M3U_DISPLAYNM    = True if __addon__.getSetting( 'displayOTTnm' ) == 'true' else False
		self.M3U_AUTORESTART  = True if __addon__.getSetting( 'autoRestart'  ) == 'true' else False

		if self.M3U_FILE_PATH == '' or self.M3U_FILE_NAME == '' : checkyn = False
		if self.M3U_ONWAVVE == False and self.M3U_ONTVING == '' and self.M3U_ONSPOTV == '' : checkyn = False

		if checkyn == False:
			dialog = xbmcgui.Dialog()
			ret = dialog.yesno(__language__(30901).encode('utf8'), __language__(30902).encode('utf8'))
			if ret == True:
				__addon__.openSettings()
				sys.exit()
			else:
				sys.exit()
	### check_config end ###


	### MakeEpg_SaveJson end ###
	def MakeEpg_SaveJson( self ):
		json_data = { 'date_makeepg' : self.BoritvObj.Get_Now_Datetime().strftime('%Y-%m-%d')	}
		try:		
			fp = open(EPGDATE_FILE_NAME, 'w')
			json.dump(json_data, fp)
			fp.close()
		except Exception as exception:
			return
	### MakeEpg_SaveJson end ###


	### main process start ####
	def boritv_main( self ):

		mode = self.main_params.get('mode', None)

		self.check_config() #환경설정 체크

		if mode is None:
			self.dp_Main_List()

		elif mode == 'DEL_M3U':
			self.dp_Delete_M3u( self.main_params )

		elif mode == 'ADD_M3U':
			self.dp_MakeAdd_M3u( self.main_params )

		elif mode == 'ADD_EPG':
			self.dp_Make_Epg( self.main_params )

		else:
			None
	### main process end ####

