# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import os
import xbmcplugin , xbmcgui , xbmcaddon , xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import urlparse
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
__addon__ = xbmcaddon . Addon ( )
__language__ = __addon__ . getLocalizedString
__profile__ = xbmc . translatePath ( __addon__ . getAddonInfo ( 'profile' ) )
__version__ = __addon__ . getAddonInfo ( 'version' )
__addonid__ = __addon__ . getAddonInfo ( 'id' )
__addonname__ = __addon__ . getAddonInfo ( 'name' )
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
i1I1ii1II1iII = [
 { 'title' : 'LIVE 채널' , 'mode' : 'LIVE_GROUP' , 'stype' : 'live' , 'orderby' : '-' , 'ordernm' : '-' }
 , { 'title' : 'VOD 방송 (인기순)' , 'mode' : 'VOD_GROUP' , 'stype' : 'vod' , 'orderby' : 'viewDay' , 'ordernm' : '인기' }
 , { 'title' : 'VOD 방송 (최신순)' , 'mode' : 'VOD_GROUP' , 'stype' : 'vod' , 'orderby' : 'new' , 'ordernm' : '최신' }
 , { 'title' : '월정액 영화관 (인기)' , 'mode' : 'MOVIE_GROUP' , 'stype' : 'movie' , 'orderby' : 'viewWeek' , 'ordernm' : '-' }
 , { 'title' : '월정액 영화관 (최신)' , 'mode' : 'MOVIE_GROUP' , 'stype' : 'movie' , 'orderby' : 'new' , 'ordernm' : '-' }
 , { 'title' : '-----------------' , 'mode' : 'XXX' , 'stype' : 'XXX' , 'orderby' : '-' , 'ordernm' : '-' }
 , { 'title' : '검색 (search)' , 'mode' : 'SEARCH_GROUP' , 'stype' : '-' , 'orderby' : '-' , 'ordernm' : '-' }
 , { 'title' : 'Watched (시청목록)' , 'mode' : 'WATCH' , 'stype' : '-' , 'orderby' : '-' , 'ordernm' : '-' }
 ]
if 86 - 86: ooOoO0o
i1ii1iIII = [
 { 'title' : '실시간 TV' , 'mode' : 'CHANNEL' , 'stype' : 'onair' }
 , { 'title' : 'TVING TV' , 'mode' : 'CHANNEL' , 'stype' : 'tvingtv' }
 ]
if 59 - 59: i1IIi * i1IIi % OOooOOo + II111iiii
II = [
 { 'title' : 'VOD 시청내역' , 'mode' : 'WATCH' , 'stype' : 'vod' }
 , { 'title' : '영화 시청내역' , 'mode' : 'WATCH' , 'stype' : 'movie' }
 ]
if 100 - 100: i1IIi . I1Ii111 / IiII * OoooooooOO + I11i * oO0o
O0IiiiIiI1iIiI1 = [
 { 'title' : 'VOD 검색' , 'mode' : 'SEARCH' , 'stype' : 'vod' }
 , { 'title' : '영화 검색' , 'mode' : 'SEARCH' , 'stype' : 'movie' }
 ]
if 85 - 85: OoO0O00
iIi1IIii11I = [
 { 'title' : '전체' , 'mode' : 'PROGRAM' , 'stype' : 'all' }
 , { 'title' : '드라마' , 'mode' : 'PROGRAM' , 'stype' : 'PCA' }
 , { 'title' : '예능' , 'mode' : 'PROGRAM' , 'stype' : 'PCD' }
 , { 'title' : '해외시리즈' , 'mode' : 'PROGRAM' , 'stype' : 'PCPOS' }
 , { 'title' : '디지털오리지널' , 'mode' : 'PROGRAM' , 'stype' : 'PCWD' }
 , { 'title' : '교양' , 'mode' : 'PROGRAM' , 'stype' : 'PCK' }
 , { 'title' : '키즈/애니' , 'mode' : 'PROGRAM' , 'stype' : 'PCC,PCAN' }
 , { 'title' : '스포츠/취미' , 'mode' : 'PROGRAM' , 'stype' : 'PCF' }
 , { 'title' : '뮤직' , 'mode' : 'PROGRAM' , 'stype' : 'PCG' }
 , { 'title' : 'e 스포츠' , 'mode' : 'PROGRAM' , 'stype' : 'PCE' }
 ]
if 84 - 84: iIii1I11I1II1 . IiII / IiII % IiII
i11 = { 'C00551' : 'tvN'
 , 'C00544' : '중화TV'
 , 'C00575' : 'Olive'
 , 'C00579' : 'Mnet'
 , 'C00590' : 'OGN'
 , 'C01141' : 'XtvN'
 , 'C01142' : 'ONSTYLE'
 , 'C01143' : 'OtvN'
 , 'C04601' : 'CGV'
 , 'C06941' : 'tooniverse'
 , 'C07381' : 'OCN'
 , 'C07382' : 'SUPER ACTION'
 , 'C15251' : 'OGN x LOL'
 , 'C15252' : 'OGN x 오버워치'
 , 'C15042' : '티빙라이브'
, 'C01581' : 'TV CHOSUN'
 , 'C01583' : '채널A'
 , 'C00708' : 'MBN'
 , 'C00593' : 'YTN'
 , 'C01101' : 'YTN Life'
 , 'C15347' : 'YTN science'
 , 'C01723' : '연합뉴스TV'
 , 'C15152' : 'DIA TV'
 , 'C01582' : 'JTBC'
 , 'C00588' : 'JTBC Golf'
 , 'C15741' : 'JTBC2'
 , 'C00805' : 'JTBC3 FOX Sports'
 , 'C05661' : '디즈니채널'
 , 'C18641' : 'IHQ'
 , 'C22041' : 'JTBC4'
 , 'C23343' : 't.cast'
 , 'C23441' : 'E channel'
 , 'C17341' : '히스토리'
 , 'C00585' : 'TV CHOSUN2'
 , 'C17141' : '채널A 플러스'
 , 'C00611' : 'LIFETIME'
 , 'C08041' : 'tvN go'
 , 'C05901' : '채널W'
 , 'C23442' : "D'LIVE"
 , 'C27441' : 'KBS N'
 }
if 41 - 41: I1Ii111 . ooOoO0o * IiII % i11iIiiIii
o000o0o00o0Oo = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
oo = xbmc . translatePath ( os . path . join ( __profile__ , 'tving_cookies.json' ) )
if 33 - 33: II111iiii * Oo0Ooo - o0oOOo0O0Ooo * iIii1I11I1II1 * OoooooooOO * ooOoO0o
from tvingCore import *
if 27 - 27: OoO0O00
if 73 - 73: o0oOOo0O0Ooo - Oo0Ooo
class oo0O000OoO ( object ) :
 def __init__ ( self , in_addonurl , in_handle , in_params ) :
  self . _addon_url = in_addonurl
  self . _addon_handle = in_handle
  self . main_params = in_params
  self . TvingObj = xi1I1ii1II1iII ( )
  if 34 - 34: I11i * I1IiiI
  if 31 - 31: II111iiii + OoO0O00 . I1Ii111
  if 68 - 68: I1IiiI - i11iIiiIii - OoO0O00 / OOooOOo - OoO0O00 + i1IIi
 def addon_noti ( self , sting ) :
  try :
   IiiIII111ii = xbmcgui . Dialog ( )
   IiiIII111ii . notification ( __addonname__ , sting )
  except :
   None
   if 3 - 3: iII111i + O0
   if 42 - 42: OOooOOo / i1IIi + i11iIiiIii - Ii1I
   if 78 - 78: OoO0O00
 def addon_log ( self , string ) :
  try :
   Iii1I111 = string . encode ( 'utf-8' , 'ignore' )
  except :
   Iii1I111 = 'addonException: addon_log'
   if 60 - 60: oO0o * o0oOOo0O0Ooo % o0oOOo0O0Ooo % I11i * II111iiii + i1IIi
   if 64 - 64: oO0o - O0 / II111iiii / o0oOOo0O0Ooo / iIii1I11I1II1
  IiIIIiI1I1 = xbmc . LOGINFO
  xbmc . log ( "[%s-%s]: %s" % ( __addonid__ , __version__ , Iii1I111 ) , level = IiIIIiI1I1 )
  if 86 - 86: i11iIiiIii + Ii1I + ooOoO0o * I11i + o0oOOo0O0Ooo
  if 61 - 61: OoO0O00 / i11iIiiIii
  if 34 - 34: OoooooooOO + iIii1I11I1II1 + i11iIiiIii - I1ii11iIi11i + i11iIiiIii
  if 65 - 65: OoOoOO00
 def get_keyboard_input ( self , title ) :
  ii1I = None
  OooO0 = xbmc . Keyboard ( )
  OooO0 . setHeading ( title )
  xbmc . sleep ( 1000 )
  OooO0 . doModal ( )
  if ( OooO0 . isConfirmed ( ) ) :
   ii1I = OooO0 . getText ( )
  return ii1I
  if 35 - 35: OOooOOo % I1Ii111 % i11iIiiIii / OoooooooOO
  if 13 - 13: i1IIi - Ii1I % oO0o / iIii1I11I1II1 % iII111i
  if 97 - 97: i11iIiiIii
  if 32 - 32: Oo0Ooo * O0 % oO0o % Ii1I . IiII
 def get_settings_login_info ( self ) :
  o0OOOOO00o0O0 = __addon__ . getSetting ( 'id' )
  o0o0OOO0o0 = __addon__ . getSetting ( 'pw' )
  ooOOOo0oo0O0 = __addon__ . getSetting ( 'login_type' )
  return ( o0OOOOO00o0O0 , o0o0OOO0o0 , ooOOOo0oo0O0 )
  if 71 - 71: I1Ii111 . O0
  if 73 - 73: OOooOOo % OoOoOO00 - Ii1I
  if 10 - 10: I1IiiI % I1ii11iIi11i
  if 48 - 48: I11i + I11i / II111iiii / iIii1I11I1II1
 def get_settings_premiumyn ( self ) :
  i1iiI11I = __addon__ . getSetting ( 'premium_movieyn' )
  if i1iiI11I == 'false' :
   return False
  else :
   return True
   if 29 - 29: OoooooooOO
   if 23 - 23: o0oOOo0O0Ooo . II111iiii
   if 98 - 98: iIii1I11I1II1 % OoOoOO00 * I1ii11iIi11i * OoOoOO00
 def get_settings_direct_replay ( self ) :
  i1 = int ( __addon__ . getSetting ( 'direct_replay' ) )
  if i1 == 0 :
   return False
  else :
   return True
   if 48 - 48: O0 + O0 - I1ii11iIi11i . ooOoO0o / iIii1I11I1II1
   if 77 - 77: i1IIi % OoOoOO00 - IiII + ooOoO0o
   if 31 - 31: I11i - i1IIi * OOooOOo / OoooooooOO
 def get_settings_thumbnail_landyn ( self ) :
  iI = int ( __addon__ . getSetting ( 'thumbnail_way' ) )
  if iI == 0 :
   return True
  else :
   return False
   if 60 - 60: I11i / I11i
   if 46 - 46: Ii1I * OOooOOo - OoO0O00 * oO0o - I1Ii111
   if 83 - 83: OoooooooOO
   if 31 - 31: II111iiii - OOooOOo . I1Ii111 % OoOoOO00 - O0
 def set_winCredential ( self , credential ) :
  iii11 = xbmcgui . Window ( 10000 )
  iii11 . setProperty ( 'TVING_M_TOKEN' , credential . get ( 'tving_token' ) )
  iii11 . setProperty ( 'TVING_M_USERINFO' , credential . get ( 'poc_userinfo' ) )
  iii11 . setProperty ( 'TVING_M_UUID' , credential . get ( 'tving_uuid' ) )
  iii11 . setProperty ( 'TVING_M_LOGINTIME' , self . TvingObj . Get_Now_Datetime ( ) . strftime ( '%Y-%m-%d' ) )
  if 58 - 58: OOooOOo * i11iIiiIii / OoOoOO00 % I1Ii111 - I1ii11iIi11i / oO0o
  if 50 - 50: I1IiiI
 def get_winCredential ( self ) :
  iii11 = xbmcgui . Window ( 10000 )
  Ii1i11IIii1I = {
 'tving_token' : iii11 . getProperty ( 'TVING_M_TOKEN' )
 , 'poc_userinfo' : iii11 . getProperty ( 'TVING_M_USERINFO' )
 , 'tving_uuid' : iii11 . getProperty ( 'TVING_M_UUID' )
 }
  return Ii1i11IIii1I
  if 52 - 52: o0oOOo0O0Ooo - OoooooooOO + Ii1I + Ii1I - o0oOOo0O0Ooo / I1Ii111
 def set_winEpisodeOrderby ( self , orderby ) :
  iii11 = xbmcgui . Window ( 10000 )
  iii11 . setProperty ( 'TVING_M_ORDERBY' , orderby )
  if 44 - 44: ooOoO0o . i1IIi - I1ii11iIi11i . O0 - ooOoO0o
 def get_winEpisodeOrderby ( self ) :
  iii11 = xbmcgui . Window ( 10000 )
  return iii11 . getProperty ( 'TVING_M_ORDERBY' )
  if 92 - 92: iII111i . I11i + o0oOOo0O0Ooo
  if 28 - 28: i1IIi * Oo0Ooo - o0oOOo0O0Ooo * IiII * Ii1I / OoO0O00
  if 94 - 94: II111iiii % I1ii11iIi11i / OoOoOO00 * iIii1I11I1II1
  if 54 - 54: o0oOOo0O0Ooo - I1IiiI + OoooooooOO
 def add_dir ( self , label , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = '' ) :
  O0o0 = '%s?%s' % ( self . _addon_url , urllib . urlencode ( params ) )
  if 71 - 71: OOooOOo + ooOoO0o % i11iIiiIii + I1ii11iIi11i - IiII
  if sublabel : oO0OOoO0 = '%s < %s >' % ( label , sublabel )
  else : oO0OOoO0 = label
  if not img : img = 'DefaultFolder.png'
  if 34 - 34: IiII - IiII * I1IiiI + Ii1I % IiII
  i111IiI1I = xbmcgui . ListItem ( oO0OOoO0 )
  i111IiI1I . setArt ( { 'thumbnailImage' : img , 'icon' : img , 'poster' : img } )
  if 70 - 70: Ii1I . Oo0Ooo / o0oOOo0O0Ooo . Ii1I - O0 / IiII
  if infoLabels : i111IiI1I . setInfo ( type = "Video" , infoLabels = infoLabels )
  if not isFolder : i111IiI1I . setProperty ( 'IsPlayable' , 'true' )
  if 62 - 62: iIii1I11I1II1 * OoOoOO00
  xbmcplugin . addDirectoryItem ( self . _addon_handle , O0o0 , i111IiI1I , isFolder )
  if 26 - 26: iII111i . I1Ii111
  if 68 - 68: OoO0O00
  if 35 - 35: OoO0O00 - iII111i / Oo0Ooo / OoOoOO00
 def get_selQuality ( self , etype ) :
  try :
   I1i1IiI1 = 'selected_quality'
   if 75 - 75: oO0o
   I1III = [ 1080 , 720 , 480 , 360 ]
   if 63 - 63: OOooOOo % oO0o * oO0o * OoO0O00 / I1ii11iIi11i
   o0ooO = int ( __addon__ . getSetting ( I1i1IiI1 ) )
   return I1III [ o0ooO ]
  except :
   None
   if 98 - 98: iII111i * iII111i / iII111i + I11i
  return 720
  if 34 - 34: ooOoO0o
  if 15 - 15: I11i * ooOoO0o * Oo0Ooo % i11iIiiIii % OoOoOO00 - OOooOOo
  if 68 - 68: I1Ii111 % i1IIi . IiII . I1ii11iIi11i
 def dp_Main_List ( self ) :
  if 92 - 92: iII111i . I1Ii111
  for i1i in i1I1ii1II1iII :
   oO0OOoO0 = i1i . get ( 'title' )
   if 50 - 50: IiII
   i11I1iIiII = { 'mode' : i1i . get ( 'mode' )
 , 'stype' : i1i . get ( 'stype' )
 , 'orderby' : i1i . get ( 'orderby' )
 , 'ordernm' : i1i . get ( 'ordernm' )
 , 'page' : '1'
 }
   if 96 - 96: Oo0Ooo
   if i1i . get ( 'mode' ) == 'XXX' :
    i11I1iIiII [ 'mode' ] = 'XXX'
    Ii1I1IIii1II = False
   else :
    Ii1I1IIii1II = True
    if 65 - 65: Ii1I . iIii1I11I1II1 / O0 - Ii1I
   self . add_dir ( oO0OOoO0 , sublabel = '' , img = '' , infoLabels = None , isFolder = Ii1I1IIii1II , params = i11I1iIiII )
  if len ( i1I1ii1II1iII ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle )
  if 21 - 21: I1IiiI * iIii1I11I1II1
  if 91 - 91: IiII
  if 15 - 15: II111iiii
  if 18 - 18: i11iIiiIii . i1IIi % OoooooooOO / O0
 def login_main ( self ) :
  ( OO0OoO0o00 , ooOO0O0ooOooO , oOOOo00O00oOo ) = self . get_settings_login_info ( )
  if 34 - 34: O0 + OOooOOo + Oo0Ooo
  if 16 - 16: iII111i . O0 . iII111i % I1ii11iIi11i - I1IiiI - iIii1I11I1II1
  if not ( OO0OoO0o00 and ooOO0O0ooOooO ) :
   IiiIII111ii = xbmcgui . Dialog ( )
   I111IIIiIii = IiiIII111ii . yesno ( __language__ ( 30901 ) . encode ( 'utf8' ) , __language__ ( 30902 ) . encode ( 'utf8' ) )
   if I111IIIiIii == True :
    __addon__ . openSettings ( )
    sys . exit ( )
   else :
    sys . exit ( )
    if 85 - 85: I1ii11iIi11i % iII111i % ooOoO0o
    if 82 - 82: i11iIiiIii - iII111i * OoooooooOO / I11i
  if self . get_winEpisodeOrderby ( ) == '' :
   self . set_winEpisodeOrderby ( 'desc' )
   if 31 - 31: IiII . OoO0O00 - iIii1I11I1II1
   if 64 - 64: I11i
  if self . cookiefile_check ( ) : return
  if 22 - 22: Oo0Ooo + Ii1I % I1ii11iIi11i
  if 9 - 9: OoooooooOO
  OOOOo = int ( self . TvingObj . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' ) )
  oo0O0oO = xbmcgui . Window ( 10000 ) . getProperty ( 'TVING_M_LOGINTIME' )
  if 60 - 60: I1IiiI
  if oo0O0oO == None or oo0O0oO == '' :
   oo0O0oO = int ( '19000101' )
  else :
   oo0O0oO = int ( re . sub ( '-' , '' , oo0O0oO ) )
   if 22 - 22: II111iiii
   if 33 - 33: I11i
   if 18 - 18: o0oOOo0O0Ooo % iII111i * O0
  if xbmcgui . Window ( 10000 ) . getProperty ( 'TVING_M_LOGINWAIT' ) == 'TRUE' :
   o0 = 0
   while True :
    o0 += 1
    time . sleep ( 0.05 )
    if 87 - 87: I11i - iIii1I11I1II1 + I1IiiI . iII111i
    if oo0O0oO >= OOOOo : return
    if o0 > 600 : return
  else :
   xbmcgui . Window ( 10000 ) . setProperty ( 'TVING_M_LOGINWAIT' , 'TRUE' )
   if 62 - 62: O0 * i1IIi * o0oOOo0O0Ooo - I1IiiI + I1IiiI
  if oo0O0oO >= OOOOo :
   xbmcgui . Window ( 10000 ) . setProperty ( 'TVING_M_LOGINWAIT' , 'FALSE' )
   return
   if 34 - 34: iIii1I11I1II1 - o0oOOo0O0Ooo
   if 91 - 91: iII111i % i1IIi % iIii1I11I1II1
  if not self . TvingObj . GetCredential ( OO0OoO0o00 , ooOO0O0ooOooO , oOOOo00O00oOo ) :
   self . addon_noti ( __language__ ( 30903 ) . encode ( 'utf8' ) )
   xbmcgui . Window ( 10000 ) . setProperty ( 'TVING_M_LOGINWAIT' , 'FALSE' )
   sys . exit ( )
   if 20 - 20: OOooOOo % Ii1I / Ii1I + Ii1I
   if 45 - 45: oO0o - IiII - OoooooooOO - OoO0O00 . II111iiii / O0
  self . set_winCredential ( self . TvingObj . LoadCredential ( ) )
  self . cookiefile_save ( )
  xbmcgui . Window ( 10000 ) . setProperty ( 'TVING_M_LOGINWAIT' , 'FALSE' )
  if 51 - 51: O0 + iII111i
  if 8 - 8: oO0o * OoOoOO00 - Ii1I - OoO0O00 * OOooOOo % I1IiiI
  if 48 - 48: O0
  if 11 - 11: I11i + OoooooooOO - OoO0O00 / o0oOOo0O0Ooo + Oo0Ooo . II111iiii
  if 41 - 41: Ii1I - O0 - O0
  if 68 - 68: OOooOOo % I1Ii111
 def dp_Title_Group ( self , args ) :
  ooO00OO0 = args . get ( 'stype' )
  if ooO00OO0 == 'live' :
   i11111IIIII = i1ii1iIII
  else :
   i11111IIIII = iIi1IIii11I
   if 19 - 19: OoOoOO00 * i1IIi
  for ii111iI1iIi1 in i11111IIIII :
   oO0OOoO0 = ii111iI1iIi1 . get ( 'title' )
   if 78 - 78: OoO0O00 . OOooOOo + OoO0O00 / I11i / OoO0O00
   if args . get ( 'ordernm' ) != '-' :
    oO0OOoO0 += '  (' + args . get ( 'ordernm' ) + ')'
    if 54 - 54: OoOoOO00 % iII111i
   i11I1iIiII = { 'mode' : ii111iI1iIi1 . get ( 'mode' )
 , 'stype' : ii111iI1iIi1 . get ( 'stype' )
 , 'orderby' : args . get ( 'orderby' )
 , 'page' : '1'
 }
   if 37 - 37: OoOoOO00 * Oo0Ooo / ooOoO0o - iII111i % II111iiii . oO0o
   self . add_dir ( oO0OOoO0 , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = i11I1iIiII )
  if len ( i11111IIIII ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle )
  if 88 - 88: iII111i . II111iiii * II111iiii % I1Ii111
  if 15 - 15: i1IIi * I1IiiI + i11iIiiIii
  if 6 - 6: ooOoO0o / i11iIiiIii + iII111i * oO0o
  if 80 - 80: II111iiii
 def dp_LiveChannel_List ( self , args ) :
  if 83 - 83: I11i . i11iIiiIii + II111iiii . o0oOOo0O0Ooo * I11i
  self . TvingObj . SaveCredential ( self . get_winCredential ( ) )
  if 53 - 53: II111iiii
  ooO00OO0 = args . get ( 'stype' )
  i1Ii1Ii = int ( args . get ( 'page' ) )
  oOO , ii1iII1II = self . TvingObj . GetLiveChannelList ( ooO00OO0 , i1Ii1Ii )
  if 48 - 48: II111iiii * Ii1I . I11i + oO0o
  for OoO0o in oOO :
   oO0OOoO0 = OoO0o . get ( 'title' )
   oO0o0Ooooo = OoO0o . get ( 'channel' )
   OOo0oO00ooO00 = OoO0o . get ( 'thumbnail' )
   oOO0O00oO0Ooo = OoO0o . get ( 'synopsis' )
   oO0Oo0O0o = OoO0o . get ( 'channelepg' )
   if 99 - 99: oO0o . iII111i + ooOoO0o % oO0o . i11iIiiIii % O0
   oOO00O = OoO0o . get ( 'info' )
   oOO00O [ 'plot' ] = '%s\n%s\n%s\n\n%s' % ( oO0o0Ooooo , oO0OOoO0 , oO0Oo0O0o , oOO0O00oO0Ooo )
   if 77 - 77: Oo0Ooo - i1IIi - I11i . OoOoOO00
   i11I1iIiII = { 'mode' : 'LIVE'
 , 'mediacode' : OoO0o . get ( 'mediacode' )
 , 'stype' : ooO00OO0
   }
   if 39 - 39: II111iiii / ooOoO0o + I1Ii111 / OoOoOO00
   self . add_dir ( oO0o0Ooooo , sublabel = oO0OOoO0 , img = OOo0oO00ooO00 , infoLabels = oOO00O , isFolder = False , params = i11I1iIiII )
   if 13 - 13: IiII + O0 + iII111i % I1IiiI / o0oOOo0O0Ooo . IiII
  if ii1iII1II :
   if 86 - 86: oO0o * o0oOOo0O0Ooo % i1IIi . Ii1I . i11iIiiIii
   i11I1iIiII [ 'mode' ] = 'CHANNEL'
   i11I1iIiII [ 'stype' ] = ooO00OO0
   i11I1iIiII [ 'page' ] = str ( i1Ii1Ii + 1 )
   oO0OOoO0 = '[B]%s >>[/B]' % '다음 페이지'
   oOOoo00O00o = str ( i1Ii1Ii + 1 )
   self . add_dir ( oO0OOoO0 , sublabel = oOOoo00O00o , img = '' , infoLabels = None , isFolder = True , params = i11I1iIiII )
   if 98 - 98: OOooOOo + IiII + oO0o % OoooooooOO
  if len ( oOO ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 97 - 97: O0 * OoooooooOO . OoooooooOO
  if 33 - 33: I1Ii111 + iII111i * oO0o / iIii1I11I1II1 - I1IiiI
  if 54 - 54: I1Ii111 / OOooOOo . oO0o % iII111i
  if 57 - 57: i11iIiiIii . I1ii11iIi11i - Ii1I - oO0o + OoOoOO00
 def dp_Program_List ( self , args ) :
  if 63 - 63: OoOoOO00 * iII111i
  self . TvingObj . SaveCredential ( self . get_winCredential ( ) )
  if 69 - 69: O0 . OoO0O00
  ooO00OO0 = args . get ( 'stype' )
  ii1111iII = args . get ( 'orderby' )
  i1Ii1Ii = int ( args . get ( 'page' ) )
  if 32 - 32: i1IIi / II111iiii . Oo0Ooo
  oooOo0OOOoo0 , ii1iII1II = self . TvingObj . GetProgramList ( ooO00OO0 , ii1111iII , i1Ii1Ii , landyn = self . get_settings_thumbnail_landyn ( ) )
  if 51 - 51: Oo0Ooo / OoOoOO00 . OOooOOo * o0oOOo0O0Ooo + OoO0O00 * IiII
  for OOOoOo in oooOo0OOOoo0 :
   oO0OOoO0 = OOOoOo . get ( 'title' )
   OOo0oO00ooO00 = OOOoOo . get ( 'thumbnail' )
   oOO0O00oO0Ooo = OOOoOo . get ( 'synopsis' )
   O00o0 = i11 . get ( OOOoOo . get ( 'channel' ) )
   if 40 - 40: I1Ii111 + OoooooooOO % o0oOOo0O0Ooo - iIii1I11I1II1 . I1IiiI
   oOO00O = OOOoOo . get ( 'info' )
   oOO00O [ 'studio' ] = O00o0
   oOO00O [ 'plot' ] = '%s <%s>\n\n%s' % ( oO0OOoO0 , O00o0 , oOO0O00oO0Ooo )
   if 48 - 48: o0oOOo0O0Ooo - oO0o / OoooooooOO
   i11I1iIiII = { 'mode' : 'EPISODE'
 , 'programcode' : OOOoOo . get ( 'program' )
 , 'page' : '1'
 }
   if 100 - 100: I1IiiI / o0oOOo0O0Ooo % II111iiii % Oo0Ooo % OOooOOo
   self . add_dir ( oO0OOoO0 , sublabel = O00o0 , img = OOo0oO00ooO00 , infoLabels = oOO00O , isFolder = True , params = i11I1iIiII )
   if 98 - 98: I11i % i11iIiiIii % ooOoO0o + Ii1I
  if ii1iII1II :
   if 78 - 78: I1ii11iIi11i % oO0o / iII111i - iIii1I11I1II1
   i11I1iIiII [ 'mode' ] = 'PROGRAM'
   i11I1iIiII [ 'stype' ] = ooO00OO0
   i11I1iIiII [ 'orderby' ] = ii1111iII
   i11I1iIiII [ 'page' ] = str ( i1Ii1Ii + 1 )
   oO0OOoO0 = '[B]%s >>[/B]' % '다음 페이지'
   oOOoo00O00o = str ( i1Ii1Ii + 1 )
   self . add_dir ( oO0OOoO0 , sublabel = oOOoo00O00o , img = '' , infoLabels = None , isFolder = True , params = i11I1iIiII )
   if 69 - 69: I1Ii111
  if len ( oooOo0OOOoo0 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 11 - 11: I1IiiI
  if 16 - 16: Ii1I + IiII * O0 % i1IIi . I1IiiI
  if 67 - 67: OoooooooOO / I1IiiI * Ii1I + I11i
  if 65 - 65: OoooooooOO - I1ii11iIi11i / ooOoO0o / II111iiii / i1IIi
 def dp_Episode_List ( self , args ) :
  if 71 - 71: I1Ii111 + Ii1I
  self . TvingObj . SaveCredential ( self . get_winCredential ( ) )
  if 28 - 28: OOooOOo
  I11ii1IIiIi = args . get ( 'programcode' )
  i1Ii1Ii = int ( args . get ( 'page' ) )
  if 54 - 54: iIii1I11I1II1 % I1ii11iIi11i - OOooOOo / oO0o - OoO0O00 . I11i
  IIo0Oo0oO0oOO00 , ii1iII1II , oo00OO0000oO = self . TvingObj . GetEpisodoList ( I11ii1IIiIi , i1Ii1Ii , orderby = self . get_winEpisodeOrderby ( ) )
  if 11 - 11: ooOoO0o / OoOoOO00 - IiII * OoooooooOO + OoooooooOO . OoOoOO00
  for i1I1i111Ii in IIo0Oo0oO0oOO00 :
   oO0OOoO0 = i1I1i111Ii . get ( 'title' )
   oOOoo00O00o = i1I1i111Ii . get ( 'subtitle' )
   OOo0oO00ooO00 = i1I1i111Ii . get ( 'thumbnail' )
   oOO0O00oO0Ooo = i1I1i111Ii . get ( 'synopsis' )
   if 67 - 67: I1IiiI . i1IIi
   oOO00O = i1I1i111Ii . get ( 'info' )
   oOO00O [ 'plot' ] = '%s\n\n%s' % ( oO0OOoO0 , oOO0O00oO0Ooo )
   if 27 - 27: ooOoO0o % I1IiiI
   i11I1iIiII = { 'mode' : 'VOD'
 , 'mediacode' : i1I1i111Ii . get ( 'episode' )
 , 'stype' : 'vod'
 , 'programcode' : I11ii1IIiIi
 , 'title' : oO0OOoO0
 , 'thumbnail' : OOo0oO00ooO00
 }
   if 73 - 73: OOooOOo
   self . add_dir ( oO0OOoO0 , sublabel = oOOoo00O00o , img = OOo0oO00ooO00 , infoLabels = oOO00O , isFolder = False , params = i11I1iIiII )
   if 70 - 70: iIii1I11I1II1
  if i1Ii1Ii == 1 :
   oOO00O = { 'plot' : '정렬순서를 변경합니다.' }
   i11I1iIiII = { }
   i11I1iIiII [ 'mode' ] = 'ORDER_BY'
   if self . get_winEpisodeOrderby ( ) == 'desc' :
    oO0OOoO0 = '정렬순서변경 : 최신화부터 -> 1회부터'
    i11I1iIiII [ 'orderby' ] = 'asc'
   else :
    oO0OOoO0 = '정렬순서변경 : 1회부터 -> 최신화부터'
    i11I1iIiII [ 'orderby' ] = 'desc'
   self . add_dir ( oO0OOoO0 , sublabel = '' , img = '' , infoLabels = oOO00O , isFolder = False , params = i11I1iIiII )
   if 31 - 31: IiII - I1IiiI % iIii1I11I1II1
   if 92 - 92: i1IIi - iIii1I11I1II1
  if ii1iII1II :
   if 16 - 16: OoO0O00 - OoOoOO00 - OOooOOo - i1IIi / Ii1I
   i11I1iIiII [ 'mode' ] = 'EPISODE'
   i11I1iIiII [ 'programcode' ] = I11ii1IIiIi
   i11I1iIiII [ 'page' ] = str ( i1Ii1Ii + 1 )
   oO0OOoO0 = '[B]%s >>[/B]' % '다음 페이지'
   oOOoo00O00o = str ( i1Ii1Ii + 1 )
   self . add_dir ( oO0OOoO0 , sublabel = oOOoo00O00o , img = '' , infoLabels = None , isFolder = True , params = i11I1iIiII )
   if 88 - 88: OoO0O00
   if 71 - 71: I1ii11iIi11i
  if len ( IIo0Oo0oO0oOO00 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 7 - 7: I1ii11iIi11i - I1IiiI . iIii1I11I1II1 - i1IIi
  if 59 - 59: o0oOOo0O0Ooo
  if 81 - 81: OoOoOO00 - OoOoOO00 . iII111i
  if 73 - 73: I11i % i11iIiiIii - I1IiiI
 def dp_setEpOrderby ( self , args ) :
  ii1111iII = args . get ( 'orderby' )
  if 7 - 7: O0 * i11iIiiIii * Ii1I + ooOoO0o % OoO0O00 - ooOoO0o
  self . set_winEpisodeOrderby ( ii1111iII )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 39 - 39: Oo0Ooo * OOooOOo % OOooOOo - OoooooooOO + o0oOOo0O0Ooo - I11i
  if 23 - 23: i11iIiiIii
  if 30 - 30: o0oOOo0O0Ooo - i1IIi % II111iiii + I11i * iIii1I11I1II1
  if 81 - 81: IiII % i1IIi . iIii1I11I1II1
 def dp_Movie_List ( self , args ) :
  if 4 - 4: i11iIiiIii % OoO0O00 % i1IIi / IiII
  self . TvingObj . SaveCredential ( self . get_winCredential ( ) )
  if 6 - 6: iII111i / I1IiiI % OOooOOo - I1IiiI
  ii1111iII = args . get ( 'orderby' )
  i1Ii1Ii = int ( args . get ( 'page' ) )
  if 31 - 31: OOooOOo
  i1OOO0000oO , ii1iII1II = self . TvingObj . GetMovieList ( ii1111iII , i1Ii1Ii , premiumyn = self . get_settings_premiumyn ( ) , landyn = self . get_settings_thumbnail_landyn ( ) )
  if 15 - 15: OoOoOO00 % I1IiiI * I11i
  for O0OoooO0 in i1OOO0000oO :
   oO0OOoO0 = O0OoooO0 . get ( 'title' )
   OOo0oO00ooO00 = O0OoooO0 . get ( 'thumbnail' )
   oOO0O00oO0Ooo = O0OoooO0 . get ( 'synopsis' )
   if 85 - 85: I11i
   oOO00O = O0OoooO0 . get ( 'info' )
   oOO00O [ 'plot' ] = '%s\n\n%s' % ( oO0OOoO0 , oOO0O00oO0Ooo )
   if 20 - 20: oO0o % IiII
   i11I1iIiII = { 'mode' : 'MOVIE'
 , 'mediacode' : O0OoooO0 . get ( 'moviecode' )
 , 'stype' : 'movie'
 , 'title' : oO0OOoO0
 , 'thumbnail' : OOo0oO00ooO00
 }
   if 19 - 19: I1ii11iIi11i % IiII + ooOoO0o / I1Ii111 . ooOoO0o
   self . add_dir ( oO0OOoO0 , sublabel = '' , img = OOo0oO00ooO00 , infoLabels = oOO00O , isFolder = False , params = i11I1iIiII )
   if 12 - 12: i1IIi + i1IIi - I1ii11iIi11i * Oo0Ooo % Oo0Ooo - II111iiii
  if ii1iII1II :
   if 52 - 52: ooOoO0o . iII111i + I1Ii111
   i11I1iIiII [ 'mode' ] = 'MOVIE_GROUP'
   i11I1iIiII [ 'orderby' ] = ii1111iII
   i11I1iIiII [ 'page' ] = str ( i1Ii1Ii + 1 )
   oO0OOoO0 = '[B]%s >>[/B]' % '다음 페이지'
   oOOoo00O00o = str ( i1Ii1Ii + 1 )
   self . add_dir ( oO0OOoO0 , sublabel = oOOoo00O00o , img = '' , infoLabels = None , isFolder = True , params = i11I1iIiII )
   if 38 - 38: i1IIi - II111iiii . I1Ii111
  if len ( i1OOO0000oO ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 58 - 58: I1IiiI . iII111i + OoOoOO00
  if 66 - 66: iII111i / oO0o * OoooooooOO + OoooooooOO % I11i
  if 49 - 49: oO0o - i11iIiiIii . I1Ii111 * Ii1I % iII111i + i1IIi
  if 71 - 71: o0oOOo0O0Ooo
 def dp_Search_Group ( self , args ) :
  for ii111iI1iIi1 in O0IiiiIiI1iIiI1 :
   oO0OOoO0 = ii111iI1iIi1 . get ( 'title' )
   if 38 - 38: oO0o % OoOoOO00 + I1ii11iIi11i . i11iIiiIii
   i11I1iIiII = { 'mode' : ii111iI1iIi1 . get ( 'mode' )
 , 'stype' : ii111iI1iIi1 . get ( 'stype' )
 , 'page' : '1'
 }
   if 53 - 53: i11iIiiIii * iII111i
   self . add_dir ( oO0OOoO0 , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = i11I1iIiII )
  if len ( O0IiiiIiI1iIiI1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle )
  if 68 - 68: iIii1I11I1II1 * iIii1I11I1II1 . o0oOOo0O0Ooo / II111iiii % Oo0Ooo
  if 38 - 38: ooOoO0o - OOooOOo / iII111i
  if 66 - 66: O0 % I1ii11iIi11i + i11iIiiIii . OoOoOO00 / Ii1I + I1ii11iIi11i
  if 86 - 86: o0oOOo0O0Ooo
 def dp_Search_List ( self , args ) :
  if 5 - 5: IiII * OoOoOO00
  self . TvingObj . SaveCredential ( self . get_winCredential ( ) )
  if 5 - 5: I1Ii111
  O0I11Iiii1I = __addon__ . getSetting ( 'id' )
  i1Ii1Ii = int ( args . get ( 'page' ) )
  ooO00OO0 = args . get ( 'stype' )
  if 90 - 90: iIii1I11I1II1 % ooOoO0o
  if 'search_key' in args :
   OoO0O00O0oo0O = args . get ( 'search_key' )
  else :
   OoO0O00O0oo0O = self . get_keyboard_input ( __language__ ( 30906 ) . encode ( 'utf-8' ) )
   if not OoO0O00O0oo0O : return
   if 36 - 36: OOooOOo + O0 - Ii1I - O0 % I11i . oO0o
  ooo , ii1iII1II = self . TvingObj . GetSearchList ( OoO0O00O0oo0O , O0I11Iiii1I , i1Ii1Ii , ooO00OO0 , premiumyn = self . get_settings_premiumyn ( ) , landyn = self . get_settings_thumbnail_landyn ( ) )
  if len ( ooo ) == 0 : return
  if 36 - 36: OoooooooOO . OoO0O00
  for oO in ooo :
   oO0OOoO0 = oO . get ( 'title' )
   OOo0oO00ooO00 = oO . get ( 'thumbnail' )
   oOO0O00oO0Ooo = oO . get ( 'synopsis' )
   IIiIi = oO . get ( 'program' )
   if 91 - 91: I1ii11iIi11i * Oo0Ooo / I1IiiI . O0 + OoO0O00 + OoOoOO00
   oOO00O = oO . get ( 'info' )
   oOO00O [ 'plot' ] = '%s\n\n%s' % ( oO0OOoO0 , oOO0O00oO0Ooo )
   if 8 - 8: oO0o / I1ii11iIi11i
   if ooO00OO0 == 'vod' :
    i11I1iIiII = { 'mode' : 'EPISODE'
 , 'programcode' : oO . get ( 'program' )
 , 'page' : '1'
 }
    Ii1I1IIii1II = True
   else :
    i11I1iIiII = { 'mode' : 'MOVIE'
 , 'mediacode' : oO . get ( 'movie' )
 , 'stype' : 'movie'
 , 'title' : oO0OOoO0
 , 'thumbnail' : OOo0oO00ooO00
 }
    Ii1I1IIii1II = False
    if 20 - 20: I1IiiI
   self . add_dir ( oO0OOoO0 , sublabel = '' , img = OOo0oO00ooO00 , infoLabels = oOO00O , isFolder = Ii1I1IIii1II , params = i11I1iIiII )
   if 95 - 95: iII111i - I1IiiI
  if ii1iII1II :
   if 34 - 34: ooOoO0o * I1IiiI . i1IIi * ooOoO0o / ooOoO0o
   i11I1iIiII [ 'mode' ] = 'SEARCH'
   i11I1iIiII [ 'search_key' ] = OoO0O00O0oo0O
   i11I1iIiII [ 'page' ] = str ( i1Ii1Ii + 1 )
   oO0OOoO0 = '[B]%s >>[/B]' % '다음 페이지'
   oOOoo00O00o = str ( i1Ii1Ii + 1 )
   self . add_dir ( oO0OOoO0 , sublabel = oOOoo00O00o , img = '' , infoLabels = None , isFolder = True , params = i11I1iIiII )
   if 30 - 30: I1ii11iIi11i + Oo0Ooo / Oo0Ooo % I1ii11iIi11i . I1ii11iIi11i
  if len ( ooo ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle )
  if 55 - 55: ooOoO0o - I11i + II111iiii + iII111i % Ii1I
  if 41 - 41: i1IIi - I11i - Ii1I
  if 8 - 8: OoO0O00 + I1Ii111 - o0oOOo0O0Ooo % Oo0Ooo % o0oOOo0O0Ooo * oO0o
  if 9 - 9: Oo0Ooo - i11iIiiIii - OOooOOo * Ii1I + ooOoO0o
 def Delete_Watched_List ( self , stype ) :
  try :
   iIIII = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % stype ) )
   if 45 - 45: I1ii11iIi11i % I1IiiI - i11iIiiIii
   ii1iiIiIII1ii = open ( iIIII , 'w' )
   ii1iiIiIII1ii . write ( '' )
   ii1iiIiIII1ii . close ( )
  except :
   None
   if 82 - 82: iII111i
   if 65 - 65: ooOoO0o . OoooooooOO / I1ii11iIi11i . i1IIi * OoO0O00
   if 19 - 19: i11iIiiIii + OoooooooOO - Oo0Ooo - I11i
   if 21 - 21: O0 % IiII . I1IiiI / II111iiii + IiII
 def dp_WatchList_Delete ( self , args ) :
  ooO00OO0 = args . get ( 'stype' )
  if 53 - 53: oO0o - I1IiiI - oO0o * iII111i
  IiiIII111ii = xbmcgui . Dialog ( )
  I111IIIiIii = IiiIII111ii . yesno ( __language__ ( 30904 ) . encode ( 'utf8' ) , __language__ ( 30905 ) . encode ( 'utf8' ) )
  if I111IIIiIii == False : sys . exit ( )
  if 71 - 71: O0 - iIii1I11I1II1
  self . Delete_Watched_List ( ooO00OO0 )
  if 12 - 12: OOooOOo / o0oOOo0O0Ooo
  xbmc . executebuiltin ( "Container.Refresh" )
  if 42 - 42: Oo0Ooo
  if 19 - 19: oO0o % I1ii11iIi11i * iIii1I11I1II1 + I1IiiI
  if 46 - 46: Oo0Ooo
  if 1 - 1: iII111i
 def Load_Watched_List ( self , stype ) :
  try :
   iIIII = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % stype ) )
   if 97 - 97: OOooOOo + iII111i + O0 + i11iIiiIii
   ii1iiIiIII1ii = open ( iIIII , 'r' )
   oOoO0 = ii1iiIiIII1ii . readlines ( )
   ii1iiIiIII1ii . close ( )
  except :
   oOoO0 = [ ]
   if 77 - 77: iIii1I11I1II1 . iII111i % iII111i + i11iIiiIii
  return oOoO0
  if 72 - 72: iIii1I11I1II1 * Ii1I % ooOoO0o / OoO0O00
  if 35 - 35: ooOoO0o + i1IIi % I1ii11iIi11i % I11i + oO0o
  if 17 - 17: i1IIi
  if 21 - 21: Oo0Ooo
 def Save_Watched_List ( self , stype , in_params ) :
  try :
   iIIII = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % stype ) )
   I1ii1 = self . Load_Watched_List ( stype )
   if 99 - 99: ooOoO0o . I1Ii111 % IiII * IiII . i1IIi
   if 72 - 72: OOooOOo % I1ii11iIi11i + OoO0O00 / oO0o + IiII
   ii1iiIiIII1ii = open ( iIIII , 'w' )
   I1I1i = urllib . urlencode ( in_params )
   I1I1i = I1I1i + '\n'
   ii1iiIiIII1ii . write ( I1I1i )
   if 1 - 1: I11i % OOooOOo + O0 + i1IIi - OoO0O00
   iIIIII1ii1I = 0
   for Ii1i1iI in I1ii1 :
    IIiI1 = dict ( urlparse . parse_qsl ( Ii1i1iI ) )
    if 17 - 17: OOooOOo / OOooOOo / I11i
    ii1 = in_params . get ( 'code' ) . strip ( )
    I1IiiI1ii1i = IIiI1 . get ( 'code' ) . strip ( )
    if stype == 'vod' and self . get_settings_direct_replay ( ) == True :
     ii1 = in_params . get ( 'videoid' ) . strip ( )
     I1IiiI1ii1i = IIiI1 . get ( 'videoid' ) . strip ( ) if I1IiiI1ii1i != None else '-'
     if 78 - 78: ooOoO0o . o0oOOo0O0Ooo . OOooOOo . I11i + oO0o
     if 16 - 16: IiII % iIii1I11I1II1 . Ii1I
    if ii1 != I1IiiI1ii1i :
     ii1iiIiIII1ii . write ( Ii1i1iI )
     iIIIII1ii1I += 1
     if iIIIII1ii1I >= 50 : break
   ii1iiIiIII1ii . close ( )
  except :
   None
   if 59 - 59: I1IiiI * II111iiii . O0
   if 56 - 56: Ii1I - iII111i % I1IiiI - o0oOOo0O0Ooo
   if 51 - 51: O0 / ooOoO0o * iIii1I11I1II1 + I1ii11iIi11i + o0oOOo0O0Ooo
   if 98 - 98: iIii1I11I1II1 * I1ii11iIi11i * OOooOOo + ooOoO0o % i11iIiiIii % O0
 def dp_Watch_List ( self , args ) :
  ooO00OO0 = args . get ( 'stype' )
  i1 = self . get_settings_direct_replay ( )
  if 27 - 27: O0
  if ooO00OO0 == '-' :
   for ii111iI1iIi1 in II :
    oO0OOoO0 = ii111iI1iIi1 . get ( 'title' )
    if 79 - 79: o0oOOo0O0Ooo - I11i + o0oOOo0O0Ooo . oO0o
    i11I1iIiII = { 'mode' : ii111iI1iIi1 . get ( 'mode' )
 , 'stype' : ii111iI1iIi1 . get ( 'stype' )
 }
    if 28 - 28: i1IIi - iII111i
    self . add_dir ( oO0OOoO0 , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = i11I1iIiII )
   if len ( II ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle )
   if 54 - 54: iII111i - O0 % OOooOOo
  else :
   Oo = self . Load_Watched_List ( ooO00OO0 )
   if 44 - 44: I1IiiI - I11i % iIii1I11I1II1
   for O0O in Oo :
    Oo0o = dict ( urlparse . parse_qsl ( O0O ) )
    if 89 - 89: iII111i . O0 / I1ii11iIi11i % OoOoOO00 . Oo0Ooo
    IiiI1i = Oo0o . get ( 'code' ) . strip ( )
    oO0OOoO0 = Oo0o . get ( 'title' ) . strip ( )
    OOo0oO00ooO00 = Oo0o . get ( 'img' ) . strip ( )
    ooOOo00O00Oo = Oo0o . get ( 'videoid' ) . strip ( )
    if 42 - 42: O0 / o0oOOo0O0Ooo + OoooooooOO * ooOoO0o % ooOoO0o
    oOO00O = { }
    oOO00O [ 'plot' ] = oO0OOoO0
    if 7 - 7: iII111i / I1ii11iIi11i / i11iIiiIii
    if ooO00OO0 == 'vod' :
     if i1 == False or ooOOo00O00Oo == None :
      i11I1iIiII = { 'mode' : 'EPISODE'
 , 'programcode' : IiiI1i
 , 'page' : '1'
 }
      Ii1I1IIii1II = True
     else :
      i11I1iIiII = { 'mode' : 'VOD'
 , 'mediacode' : ooOOo00O00Oo
 , 'stype' : 'vod'
 , 'programcode' : IiiI1i
 , 'title' : oO0OOoO0
 , 'thumbnail' : OOo0oO00ooO00
 }
      Ii1I1IIii1II = False
    else :
     i11I1iIiII = { 'mode' : 'MOVIE'
 , 'mediacode' : IiiI1i
 , 'stype' : 'movie'
 , 'title' : oO0OOoO0
 , 'thumbnail' : OOo0oO00ooO00
 }
     Ii1I1IIii1II = False
     if 21 - 21: oO0o / I1ii11iIi11i + Ii1I + OoooooooOO
    self . add_dir ( oO0OOoO0 , sublabel = '' , img = OOo0oO00ooO00 , infoLabels = oOO00O , isFolder = Ii1I1IIii1II , params = i11I1iIiII )
    if 91 - 91: i11iIiiIii / i1IIi + iII111i + ooOoO0o * i11iIiiIii
   oOO00O = { 'plot' : '시청목록을 삭제합니다.' }
   oO0OOoO0 = '*** 시청목록 삭제 ***'
   i11I1iIiII = { 'mode' : 'MYVIEW_REMOVE'
 , 'stype' : ooO00OO0
 }
   self . add_dir ( oO0OOoO0 , sublabel = '' , img = '' , infoLabels = oOO00O , isFolder = False , params = i11I1iIiII )
   if 66 - 66: iIii1I11I1II1 % i1IIi - O0 + I11i * I1Ii111 . IiII
   xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
   if 52 - 52: ooOoO0o + O0 . iII111i . I1ii11iIi11i . OoO0O00
   if 97 - 97: I1IiiI / iII111i
   if 71 - 71: II111iiii / i1IIi . I1ii11iIi11i % OoooooooOO . OoOoOO00
   if 41 - 41: i1IIi * II111iiii / OoooooooOO . OOooOOo
   if 83 - 83: iII111i . O0 / Oo0Ooo / OOooOOo - II111iiii
 def play_VIDEO ( self , args ) :
  if 100 - 100: OoO0O00
  self . TvingObj . SaveCredential ( self . get_winCredential ( ) )
  if 46 - 46: OoOoOO00 / iIii1I11I1II1 % iII111i . iIii1I11I1II1 * iII111i
  IIi1ii1Ii = args . get ( 'mediacode' )
  ooO00OO0 = args . get ( 'stype' )
  OoOoO = args . get ( 'pvrmode' )
  o0ii1i = self . get_selQuality ( ooO00OO0 )
  if 62 - 62: OoO0O00 / I1ii11iIi11i
  ii1O000OOO0OOo , i1i1I111iIi1 = self . TvingObj . GetBroadURL ( IIi1ii1Ii , o0ii1i , ooO00OO0 , OoOoO )
  if 92 - 92: ooOoO0o
  self . addon_log ( 'qt, stype, url : %s - %s - %s' % ( str ( o0ii1i ) , ooO00OO0 , ii1O000OOO0OOo ) )
  if 22 - 22: Oo0Ooo % iII111i * I1ii11iIi11i / OOooOOo % i11iIiiIii * I11i
  if ii1O000OOO0OOo == '' :
   self . addon_noti ( __language__ ( 30908 ) . encode ( 'utf8' ) )
   return
   if 95 - 95: OoooooooOO - IiII * I1IiiI + OoOoOO00
   if 10 - 10: o0oOOo0O0Ooo / i11iIiiIii
   if 92 - 92: I11i . I1Ii111
  oOO00O0Ooooo00 = ii1O000OOO0OOo . find ( 'Policy=' )
  if oOO00O0Ooooo00 != - 1 :
   O000 = ii1O000OOO0OOo . split ( '?' ) [ 0 ]
   if 79 - 79: OoooooooOO - I1IiiI
   o00O00oO00 = dict ( urlparse . parse_qsl ( urlparse . urlsplit ( ii1O000OOO0OOo ) . query ) )
   o00O00oO00 = urllib . urlencode ( o00O00oO00 )
   o00O00oO00 = o00O00oO00 . replace ( '&' , ';' )
   o00O00oO00 = o00O00oO00 . replace ( 'Policy' , 'CloudFront-Policy' )
   o00O00oO00 = o00O00oO00 . replace ( 'Signature' , 'CloudFront-Signature' )
   o00O00oO00 = o00O00oO00 . replace ( 'Key-Pair-Id' , 'CloudFront-Key-Pair-Id' )
   if 23 - 23: iIii1I11I1II1 * i1IIi % OoooooooOO * IiII
   I1Iiiiiii = '%s|Cookie=%s' % ( O000 , o00O00oO00 )
  else :
   I1Iiiiiii = ii1O000OOO0OOo
   if 39 - 39: IiII * Oo0Ooo + iIii1I11I1II1 - IiII + OOooOOo
   if 69 - 69: O0
  self . addon_log ( I1Iiiiiii )
  if 85 - 85: ooOoO0o / O0
  if 18 - 18: o0oOOo0O0Ooo % O0 * I1ii11iIi11i
  if 62 - 62: I1Ii111 . IiII . OoooooooOO
  if 11 - 11: OOooOOo / I11i
  oooO0 = xbmcgui . ListItem ( path = I1Iiiiiii )
  if 16 - 16: II111iiii + oO0o - OoooooooOO
  if 3 - 3: O0 / iII111i
  if i1i1I111iIi1 != '' :
   iIiIi1I = i1i1I111iIi1
   iiii11i = 'https://cj.drmkeyserver.com/widevine_license'
   if 35 - 35: I1ii11iIi11i * iII111i - OoO0O00 % o0oOOo0O0Ooo
   oOo00O000Oo0 = 'mpd'
   I1iI1I1I1i11i = 'com.widevine.alpha'
   if 39 - 39: II111iiii / IiII + Ii1I
   OOoO000 = inputstreamhelper . Helper ( oOo00O000Oo0 , drm = 'widevine' )
   if 57 - 57: II111iiii
   if OOoO000 . check_inputstream ( ) :
    if 54 - 54: Oo0Ooo + oO0o + i11iIiiIii
    i1i1ii111 = { 'origin' : 'https://www.tving.com'
 , 'pragma' : 'no-cache'
 , 'referer' : 'https://www.tving.com/live/player/%s' % IIi1ii1Ii
 , 'sec-fetch-mode' : 'cors'
 , 'sec-fetch-site' : 'same-site'
    , 'user-agent' : o000o0o00o0Oo
 , 'AcquireLicenseAssertion' : iIiIi1I
 , 'Host' : 'cj.drmkeyserver.com'
 }
    IiI1i = iiii11i + '|' + urllib . urlencode ( i1i1ii111 ) + '|R{SSM}|'
    if 87 - 87: ooOoO0o
    oooO0 . setProperty ( 'inputstreamaddon' , OOoO000 . inputstream_addon )
    oooO0 . setProperty ( 'inputstream.adaptive.manifest_type' , oOo00O000Oo0 )
    oooO0 . setProperty ( 'inputstream.adaptive.license_type' , I1iI1I1I1i11i )
    if 45 - 45: OoO0O00 / OoooooooOO - iII111i / Ii1I % IiII
    oooO0 . setProperty ( 'inputstream.adaptive.license_key' , IiI1i )
    oooO0 . setProperty ( 'inputstream.adaptive.stream_headers' , 'user-agent=%s' % ( o000o0o00o0Oo ) )
    if 83 - 83: I1IiiI . iIii1I11I1II1 - IiII * i11iIiiIii
    if 20 - 20: i1IIi * I1Ii111 + II111iiii % o0oOOo0O0Ooo % oO0o
    if 13 - 13: Oo0Ooo
    if 60 - 60: I1ii11iIi11i * I1IiiI
    if 17 - 17: OOooOOo % Oo0Ooo / I1ii11iIi11i . IiII * OOooOOo - II111iiii
  xbmcplugin . setResolvedUrl ( self . _addon_handle , True , oooO0 )
  if 41 - 41: Ii1I
  try :
   if args . get ( 'mode' ) in [ 'VOD' , 'MOVIE' ] and args . get ( 'title' ) :
    i11I1iIiII = { 'code' : args . get ( 'programcode' ) if args . get ( 'mode' ) == 'VOD' else args . get ( 'mediacode' )
 , 'img' : args . get ( 'thumbnail' )
 , 'title' : args . get ( 'title' )
 , 'videoid' : args . get ( 'mediacode' )
    }
    self . Save_Watched_List ( args . get ( 'stype' ) , i11I1iIiII )
  except :
   None
   if 77 - 77: I1Ii111
   if 65 - 65: II111iiii . I1IiiI % oO0o * OoO0O00
   if 38 - 38: OoOoOO00 / iII111i % Oo0Ooo
   if 11 - 11: iII111i - oO0o + II111iiii - iIii1I11I1II1
   if 7 - 7: IiII - I11i / II111iiii * Ii1I . iII111i * iII111i
 def logout ( self ) :
  IiiIII111ii = xbmcgui . Dialog ( )
  I111IIIiIii = IiiIII111ii . yesno ( __language__ ( 30910 ) . encode ( 'utf8' ) , __language__ ( 30905 ) . encode ( 'utf8' ) )
  if I111IIIiIii == False : sys . exit ( )
  if 61 - 61: I11i % ooOoO0o - OoO0O00 / Oo0Ooo
  self . wininfo_clear ( )
  if 4 - 4: OoooooooOO - i1IIi % Ii1I - OOooOOo * o0oOOo0O0Ooo
  if 85 - 85: OoooooooOO * iIii1I11I1II1 . iII111i / OoooooooOO % I1IiiI % O0
  if os . path . isfile ( oo ) : os . remove ( oo )
  if 36 - 36: Ii1I / II111iiii / IiII / IiII + I1ii11iIi11i
  self . addon_noti ( __language__ ( 30909 ) . encode ( 'utf-8' ) )
  if 95 - 95: IiII
  if 51 - 51: II111iiii + IiII . i1IIi . I1ii11iIi11i + OoOoOO00 * I1IiiI
  if 72 - 72: oO0o + oO0o / II111iiii . OoooooooOO % Ii1I
  if 49 - 49: oO0o . OoO0O00 - Oo0Ooo * OoooooooOO . Oo0Ooo
 def wininfo_clear ( self ) :
  if 2 - 2: OoooooooOO % OOooOOo
  iii11 = xbmcgui . Window ( 10000 )
  iii11 . setProperty ( 'TVING_M_TOKEN' , '' )
  iii11 . setProperty ( 'TVING_M_USERINFO' , '' )
  iii11 . setProperty ( 'TVING_M_UUID' , '' )
  iii11 . setProperty ( 'TVING_M_LOGINTIME' , '' )
  if 63 - 63: I1IiiI % iIii1I11I1II1
  if 39 - 39: iII111i / II111iiii / I1ii11iIi11i % I1IiiI
  if 89 - 89: I1Ii111 + OoooooooOO + I1Ii111 * i1IIi + iIii1I11I1II1 % I11i
  if 59 - 59: OOooOOo + i11iIiiIii
 def cookiefile_save ( self ) :
  oo0OOo0O = self . TvingObj . Get_Now_Datetime ( )
  Ii1IiII = oo0OOo0O + datetime . timedelta ( days = int ( __addon__ . getSetting ( 'cache_ttl' ) ) )
  if 27 - 27: iII111i . I11i . iIii1I11I1II1 . iIii1I11I1II1
  iii11 = xbmcgui . Window ( 10000 )
  iIi1i = { 'tving_token' : iii11 . getProperty ( 'TVING_M_TOKEN' )
 , 'tving_userinfo' : iii11 . getProperty ( 'TVING_M_USERINFO' )
 , 'tving_uuid' : iii11 . getProperty ( 'TVING_M_UUID' )
 , 'tving_id' : base64 . standard_b64encode ( __addon__ . getSetting ( 'id' ) . encode ( ) ) . decode ( 'utf-8' )
 , 'tving_pw' : base64 . standard_b64encode ( __addon__ . getSetting ( 'pw' ) . encode ( ) ) . decode ( 'utf-8' )
 , 'tving_logintype' : __addon__ . getSetting ( 'login_type' )
 , 'tving_limitdate' : Ii1IiII . strftime ( '%Y-%m-%d' )
 }
  if 4 - 4: I1Ii111 / i11iIiiIii / OOooOOo
  try :
   if 91 - 91: iIii1I11I1II1 % o0oOOo0O0Ooo . iIii1I11I1II1 % i1IIi / II111iiii * OoOoOO00
   ii1iiIiIII1ii = open ( oo , 'w' )
   json . dump ( iIi1i , ii1iiIiIII1ii )
   ii1iiIiIII1ii . close ( )
  except Exception as ii :
   print ( ii )
   if 81 - 81: O0 % Ii1I
   if 5 - 5: OoooooooOO - OoO0O00 + IiII - iII111i . OoO0O00 / ooOoO0o
   if 28 - 28: Ii1I * Ii1I - iIii1I11I1II1
   if 70 - 70: I1Ii111
 def cookiefile_check ( self ) :
  if 16 - 16: iII111i - OoooooooOO % Oo0Ooo
  if 36 - 36: OOooOOo
  iIi1i = { }
  try :
   if 84 - 84: I1Ii111 . OoO0O00 . II111iiii . I11i / Ii1I % I1ii11iIi11i
   ii1iiIiIII1ii = open ( oo , 'r' )
   iIi1i = json . load ( ii1iiIiIII1ii )
   ii1iiIiIII1ii . close ( )
  except Exception as ii :
   self . wininfo_clear ( )
   return False
   if 57 - 57: I1IiiI % I11i - OOooOOo . I1IiiI / Oo0Ooo % iII111i
   if 56 - 56: oO0o . iII111i . IiII * OoOoOO00 . ooOoO0o / O0
   if 23 - 23: i1IIi + iII111i + IiII + OoO0O00
  OO0OoO0o00 = __addon__ . getSetting ( 'id' )
  ooOO0O0ooOooO = __addon__ . getSetting ( 'pw' )
  iiIIiiIIi = __addon__ . getSetting ( 'login_type' )
  iIi1i [ 'tving_id' ] = base64 . standard_b64decode ( iIi1i [ 'tving_id' ] ) . decode ( 'utf-8' )
  iIi1i [ 'tving_pw' ] = base64 . standard_b64decode ( iIi1i [ 'tving_pw' ] ) . decode ( 'utf-8' )
  if OO0OoO0o00 != iIi1i [ 'tving_id' ] or ooOO0O0ooOooO != iIi1i [ 'tving_pw' ] or iiIIiiIIi != iIi1i [ 'tving_logintype' ] :
   self . wininfo_clear ( )
   return False
   if 51 - 51: ooOoO0o % Oo0Ooo
   if 6 - 6: I1ii11iIi11i + oO0o
  OOOOo = int ( self . TvingObj . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' ) )
  Ii1iI11iI1 = iIi1i [ 'tving_limitdate' ]
  oo0O0oO = int ( re . sub ( '-' , '' , Ii1iI11iI1 ) )
  if 5 - 5: iIii1I11I1II1
  if 72 - 72: oO0o . I1Ii111 / OoOoOO00 + I11i % iIii1I11I1II1
  if oo0O0oO < OOOOo :
   self . wininfo_clear ( )
   return False
   if 42 - 42: I1ii11iIi11i * OoOoOO00 % ooOoO0o - OoOoOO00 . i11iIiiIii - I1Ii111
   if 84 - 84: I1Ii111 - I1ii11iIi11i / I11i
  iii11 = xbmcgui . Window ( 10000 )
  iii11 . setProperty ( 'TVING_M_TOKEN' , iIi1i [ 'tving_token' ] )
  iii11 . setProperty ( 'TVING_M_USERINFO' , iIi1i [ 'tving_userinfo' ] )
  iii11 . setProperty ( 'TVING_M_UUID' , iIi1i [ 'tving_uuid' ] )
  iii11 . setProperty ( 'TVING_M_LOGINTIME' , Ii1iI11iI1 )
  if 13 - 13: IiII - Oo0Ooo - ooOoO0o
  return True
  if 92 - 92: ooOoO0o / OoOoOO00 * OoO0O00 . I11i % II111iiii
  if 71 - 71: I1Ii111 % i1IIi - II111iiii - OOooOOo + OOooOOo * ooOoO0o
  if 51 - 51: iIii1I11I1II1 / OoOoOO00 + OOooOOo - I11i + iII111i
  if 29 - 29: o0oOOo0O0Ooo % iIii1I11I1II1 . OoooooooOO % OoooooooOO % II111iiii / iII111i
  if 70 - 70: i11iIiiIii % iII111i
 def tving_main ( self ) :
  I11Ii11iI1 = self . main_params . get ( 'mode' , None )
  if 39 - 39: I1IiiI * i11iIiiIii - oO0o / IiII % I1Ii111 % I11i
  if 65 - 65: oO0o - ooOoO0o % OoooooooOO / OoooooooOO % OoooooooOO
  if I11Ii11iI1 == 'LOGOUT' :
   self . logout ( )
   return
   if 52 - 52: I1ii11iIi11i + I1ii11iIi11i . II111iiii
  self . login_main ( )
  if 34 - 34: OoooooooOO . O0 / oO0o * OoOoOO00 - I1ii11iIi11i
  if I11Ii11iI1 is None :
   self . dp_Main_List ( )
   if 36 - 36: i1IIi / O0 / OoO0O00 - O0 - i1IIi
  elif I11Ii11iI1 in [ 'LIVE_GROUP' , 'VOD_GROUP' ] :
   self . dp_Title_Group ( self . main_params )
   if 22 - 22: i1IIi + Ii1I
  elif I11Ii11iI1 == 'CHANNEL' :
   self . dp_LiveChannel_List ( self . main_params )
   if 54 - 54: ooOoO0o % OOooOOo . I1Ii111 + oO0o - OOooOOo * I1IiiI
  elif I11Ii11iI1 in [ 'LIVE' , 'VOD' , 'MOVIE' ] :
   if 92 - 92: o0oOOo0O0Ooo + I1Ii111 / Oo0Ooo % OoO0O00 % IiII . OoooooooOO
   self . play_VIDEO ( self . main_params )
   if 52 - 52: ooOoO0o / i11iIiiIii - OOooOOo . IiII % iIii1I11I1II1 + o0oOOo0O0Ooo
  elif I11Ii11iI1 == 'PROGRAM' :
   self . dp_Program_List ( self . main_params )
   if 71 - 71: oO0o % I11i * OoOoOO00 . O0 / Ii1I . I1ii11iIi11i
  elif I11Ii11iI1 == 'EPISODE' :
   self . dp_Episode_List ( self . main_params )
   if 58 - 58: Oo0Ooo / oO0o
  elif I11Ii11iI1 == 'MOVIE_GROUP' :
   self . dp_Movie_List ( self . main_params )
   if 44 - 44: OOooOOo
  elif I11Ii11iI1 == 'SEARCH_GROUP' :
   self . dp_Search_Group ( self . main_params )
   if 54 - 54: Ii1I - I11i - I1Ii111 . iIii1I11I1II1
  elif I11Ii11iI1 == 'SEARCH' :
   self . dp_Search_List ( self . main_params )
   if 79 - 79: Ii1I . OoO0O00
  elif I11Ii11iI1 == 'WATCH' :
   self . dp_Watch_List ( self . main_params )
   if 40 - 40: o0oOOo0O0Ooo + Oo0Ooo . o0oOOo0O0Ooo % ooOoO0o
  elif I11Ii11iI1 == 'MYVIEW_REMOVE' :
   self . dp_WatchList_Delete ( self . main_params )
   if 15 - 15: Ii1I * Oo0Ooo % I1ii11iIi11i * iIii1I11I1II1 - i11iIiiIii
  elif I11Ii11iI1 == 'ORDER_BY' :
   self . dp_setEpOrderby ( self . main_params )
   if 60 - 60: I1IiiI * I1Ii111 % OoO0O00 + oO0o
   if 52 - 52: i1IIi
   if 84 - 84: Ii1I / IiII
   if 86 - 86: OoOoOO00 * II111iiii - O0 . OoOoOO00 % iIii1I11I1II1 / OOooOOo
  else :
   None
   if 11 - 11: I1IiiI * oO0o + I1ii11iIi11i / I1ii11iIi11i
   if 37 - 37: i11iIiiIii + i1IIi
   if 23 - 23: iII111i + I11i . OoOoOO00 * I1IiiI + I1ii11iIi11i
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
