# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import urllib
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
import re
import json
import sys
import time
import requests
import datetime
if 73 - 73: II111iiii
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
I1IiI = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
o0OOO = { 'stream50' : 1080 , 'stream40' : 720 , 'stream30' : 480 , 'stream25' : 360 }
if 13 - 13: ooOo + Oo
if 67 - 67: O00ooOO . I1iII1iiII
if 28 - 28: Ii11111i * iiI1i1
class xi1I1ii1II1iII ( object ) :
 def __init__ ( self ) :
  self . TVING_TOKEN = ''
  self . POC_USERINFO = ''
  self . TVING_UUID = '-'
  self . APIKEY = '1e7952d0917d6aab1f0293a063697610'
  self . NETWORKCODE = 'CSND0900'
  self . OSCODE = 'CSOD0900'
  self . TELECODE = 'CSCD0900'
  self . SCREENCODE = 'CSSD0100'
  self . LIVE_LIMIT = 23
  self . VOD_LIMIT = 20
  self . EPISODE_LIMIT = 30
  self . SEARCH_LIMIT = 80
  self . MOVIE_LIMIT = 18
  self . API_DOMAIN = 'https://api.tving.com'
  self . IMG_DOMAIN = 'https://image.tving.com'
  self . SEARCH_DOMAIN = 'https://search.tving.com'
  self . LOGIN_DOMAIN = 'https://user.tving.com'
  self . URL_DOMAIN = 'https://www.tving.com'
  self . MOVIE_LITE = '338723'
  self . MOVIE_PREMIUM = '1513561'
  self . DEFAULT_HEADER = { 'user-agent' : I1IiI }
  if 86 - 86: oO0o
  if 12 - 12: OOO0o0o / Oo + I1IiiI / O0 % OOO0o0o + OOO0o0o
 def callRequestCookies ( self , jobtype , url , payload = None , params = None , headers = None , cookies = None , redirects = False ) :
  i111I = self . DEFAULT_HEADER
  if headers : i111I . update ( headers )
  if 16 - 16: ooOo % Oo * Ii11111i . Oo / iIii1I11I1II1 * iIii1I11I1II1
  if jobtype == 'Get' :
   II1iI = requests . get ( url , params = params , headers = i111I , cookies = cookies , allow_redirects = redirects )
  else :
   II1iI = requests . post ( url , data = payload , params = params , headers = i111I , cookies = cookies , allow_redirects = redirects )
   if 27 - 27: Ii11111i * OoO0O00 . II111iiii
  return II1iI
  if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + iiI1i1 . oO0o
 def makeDefaultCookies ( self , vToken = None , vUserinfo = None ) :
  Oooo0000 = { }
  Oooo0000 [ '_tving_token' ] = self . TVING_TOKEN if vToken == None else vToken
  Oooo0000 [ 'POC_USERINFO' ] = self . POC_USERINFO if vToken == None else vUserinfo
  return Oooo0000
  if 22 - 22: I1iII1iiII . iiI1i1
  if 41 - 41: oO0o . OOO0o0o * iiI1i1 % i11iIiiIii
 def getDeviceStr ( self ) :
  o000o0o00o0Oo = [ ]
  o000o0o00o0Oo . append ( 'Windows' )
  o000o0o00o0Oo . append ( 'Chrome' )
  o000o0o00o0Oo . append ( 'ko-KR' )
  o000o0o00o0Oo . append ( 'undefined' )
  o000o0o00o0Oo . append ( '24' )
  o000o0o00o0Oo . append ( u'한국 표준시' )
  o000o0o00o0Oo . append ( 'undefined' )
  o000o0o00o0Oo . append ( 'undefined' )
  o000o0o00o0Oo . append ( 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC' )
  if 80 - 80: OoooooooOO . I1IiiI
  OOO0O = ''
  for oo0ooO0oOOOOo in o000o0o00o0Oo :
   OOO0O += oo0ooO0oOOOOo + '|'
  return OOO0O
  if 71 - 71: oO0o
  if 54 - 54: Oo % O0 + I1IiiI - Ii11111i / O00ooOO
 def SaveCredential ( self , login_params ) :
  self . TVING_TOKEN = login_params . get ( 'tving_token' )
  self . POC_USERINFO = login_params . get ( 'poc_userinfo' )
  self . TVING_UUID = login_params . get ( 'tving_uuid' )
  if 31 - 31: OoO0O00 + II111iiii
 def LoadCredential ( self ) :
  i11IiIiiIIIII = {
 'tving_token' : self . TVING_TOKEN
 , 'poc_userinfo' : self . POC_USERINFO
 , 'tving_uuid' : self . TVING_UUID
 }
  return i11IiIiiIIIII
  if 22 - 22: I1iII1iiII * O0 / o0oOOo0O0Ooo
 def GetDefaultParams ( self ) :
  o00ooooO0oO = { 'apiKey' : self . APIKEY
 , 'networkCode' : self . NETWORKCODE
 , 'osCode' : self . OSCODE
 , 'teleCode' : self . TELECODE
 , 'screenCode' : self . SCREENCODE
 }
  return o00ooooO0oO
  if 63 - 63: OoOoOO00 % i1IIi
 def GetNoCache ( self , timetype = 1 ) :
  if timetype == 1 :
   return int ( time . time ( ) )
  else :
   return int ( time . time ( ) * 1000 )
   if 66 - 66: I1iII1iiII
 def makeurl ( self , domain , path , query1 = None , query2 = None ) :
  oo0Ooo0 = domain + path
  if query1 :
   oo0Ooo0 += '?%s' % urllib . urlencode ( query1 )
  if query2 :
   oo0Ooo0 += '&%s' % urllib . urlencode ( query2 )
  return oo0Ooo0
  if 46 - 46: OOO0o0o % OOO0o0o - ooOo * o0oOOo0O0Ooo % Ii11111i
  if 55 - 55: OoOoOO00 % i1IIi / I1iII1iiII - ooOo - O0 / II111iiii
 def GetCredential ( self , user_id , user_pw , login_type ) :
  iii11iII = False
  i1I111I = i11I1IIiiIi = ''
  IiIiIi = '-'
  if 40 - 40: ooOo . OoOoOO00 . Oo0Ooo . i1IIi
  try :
   I11iii = self . LOGIN_DOMAIN + '/pc/user/doLogin.tving'
   if 54 - 54: Oo + Oo % oO0o % i11iIiiIii / iIii1I11I1II1 . Oo
   o0oO0o00oo = { 'userId' : user_id
 , 'password' : user_pw
 , 'loginType' : '10' if login_type == '0' else '20'
 , 'autoLogin' : 'false'
 , 'cjOneCookie' : ''
 , 'kaptcha' : ''

   , 'returnUrl' : ''
 , 'csite' : ''
 }
   if 32 - 32: Oo0Ooo * O0 % ooOo % I1iII1iiII . iiI1i1
   o0OOOOO00o0O0 = self . callRequestCookies ( 'Post' , I11iii , payload = o0oO0o00oo , params = None , headers = None , cookies = None )
   if 71 - 71: OOO0o0o % Ii11111i / o0oOOo0O0Ooo
   for ii11i1iIII in o0OOOOO00o0O0 . cookies :
    if ii11i1iIII . name == '_tving_token' :
     i1I111I = ii11i1iIII . value
    elif ii11i1iIII . name == 'POC_USERINFO' :
     i11I1IIiiIi = ii11i1iIII . value
     if 3 - 3: i1IIi / I1IiiI % O00ooOO * i11iIiiIii / O0 * O00ooOO
   if i1I111I : iii11iII = True
   if 49 - 49: ooOo % I1iII1iiII + i1IIi . I1IiiI % I1ii11iIi11i
   IiIiIi = self . GetDeviceList ( i1I111I , i11I1IIiiIi )
   if 48 - 48: O00ooOO + O00ooOO / II111iiii / iIii1I11I1II1
   if 20 - 20: o0oOOo0O0Ooo
  except Exception as oO00 :
   i1I111I = i11I1IIiiIi = ''
   IiIiIi = '-'
   print ( oO00 )
   if 53 - 53: OoooooooOO . i1IIi
  i11IiIiiIIIII = {
 'tving_token' : i1I111I
 , 'poc_userinfo' : i11I1IIiiIi
 , 'tving_uuid' : IiIiIi
 }
  self . SaveCredential ( i11IiIiiIIIII )
  if 18 - 18: o0oOOo0O0Ooo
  return iii11iII
  if 28 - 28: Oo - iiI1i1 . iiI1i1 + OoOoOO00 - OoooooooOO + O0
 def Get_Now_Datetime ( self ) :
  if 95 - 95: OoO0O00 % ooOo . O0
  return datetime . datetime . utcnow ( ) + datetime . timedelta ( hours = 9 )
  if 15 - 15: OOO0o0o / I1iII1iiII . I1iII1iiII - i1IIi
 def GetBroadURL ( self , mediacode , sel_quality , stype , pvrmode = '-' ) :
  o00oOO0 = ''
  oOoo = ''
  iIii11I = self . TVING_UUID
  if 69 - 69: ooOo % oO0o - o0oOOo0O0Ooo + oO0o - O0 % OoooooooOO
  if 31 - 31: II111iiii - Oo . oO0o % OoOoOO00 - O0
  if 4 - 4: II111iiii / OOO0o0o . Ii11111i
  if 58 - 58: Oo * i11iIiiIii / OoOoOO00 % oO0o - I1ii11iIi11i / ooOo
  try :
   if stype != 'tvingtv' and ( pvrmode == '-' or stype != 'onair' ) :
    if 50 - 50: I1IiiI
    if 34 - 34: I1IiiI * II111iiii % Ii11111i * OoOoOO00 - I1IiiI
    II1III = '/v2/media/stream/info'
    if 19 - 19: ooOo % i1IIi % o0oOOo0O0Ooo
    oo0OooOOo0 = self . GetDefaultParams ( )
    o0O = { 'info' : 'N'
    , 'mediaCode' : mediacode
 , 'noCache' : str ( self . GetNoCache ( 1 ) )
 , 'callingFrom' : 'HTML5'
 , 'adReq' : 'none'
 , 'ooc' : ''
 , 'deviceId' : iIii11I
 , 'wm' : 'Y'
 }
    oo0OooOOo0 . update ( o0O )
    if 72 - 72: Ii11111i / i1IIi * Oo0Ooo - oO0o
    oo0Ooo0 = self . makeurl ( self . API_DOMAIN , II1III )
    if 51 - 51: II111iiii * OoO0O00 % o0oOOo0O0Ooo * II111iiii % I1ii11iIi11i / OOO0o0o
    Oooo0000 = self . makeDefaultCookies ( )
    if 49 - 49: o0oOOo0O0Ooo
    o0OOOOO00o0O0 = self . callRequestCookies ( 'Get' , oo0Ooo0 , payload = None , params = oo0OooOOo0 , headers = None , cookies = Oooo0000 )
    IIii1Ii1 = json . loads ( o0OOOOO00o0O0 . text )
    if 5 - 5: Ii11111i % Oo + OOO0o0o % i11iIiiIii + o0oOOo0O0Ooo
    if not ( 'stream' in IIii1Ii1 [ 'body' ] ) : return o00oOO0 , oOoo
    OOOO0OOoO0O0 = IIii1Ii1 [ 'body' ] [ 'stream' ]
    if 65 - 65: iiI1i1 * I1IiiI + I1iII1iiII % i11iIiiIii * ooOo . oO0o
    if 100 - 100: O0 + iiI1i1 - Oo + i11iIiiIii * I1iII1iiII
    if 30 - 30: o0oOOo0O0Ooo . I1iII1iiII - OoooooooOO
    if 8 - 8: i1IIi - iIii1I11I1II1 * II111iiii + i11iIiiIii / oO0o % Oo
    if 16 - 16: I1ii11iIi11i + OoO0O00 - II111iiii
    oOoOO0 = OOOO0OOoO0O0 [ 'quality' ]
    if 30 - 30: II111iiii - Oo - i11iIiiIii % OoOoOO00 - II111iiii * I1iII1iiII
    oO00O0O0O = [ ]
    for i1ii1iiI in oOoOO0 :
     if i1ii1iiI [ 'active' ] == 'Y' :
      oO00O0O0O . append ( { o0OOO . get ( i1ii1iiI [ 'code' ] ) : i1ii1iiI [ 'code' ] } )
      if 98 - 98: Ii11111i * Ii11111i / Ii11111i + O00ooOO
    ii111111I1iII = self . CheckQuality ( sel_quality , oO00O0O0O )
    if 68 - 68: Ii11111i - iIii1I11I1II1 * i11iIiiIii / I1ii11iIi11i * oO0o
   else :
    for i1iIi1iIi1i , I1I1iIiII1 in o0OOO . items ( ) :
     if I1I1iIiII1 == sel_quality :
      ii111111I1iII = i1iIi1iIi1i
      if 4 - 4: OOO0o0o + O0 * Oo
      if 55 - 55: Oo0Ooo + iIii1I11I1II1 / OoOoOO00 * ooOo - i11iIiiIii - I1iII1iiII
  except Exception as oO00 :
   print ( oO00 )
   for i1iIi1iIi1i , I1I1iIiII1 in o0OOO . items ( ) :
    if I1I1iIiII1 == sel_quality :
     ii111111I1iII = i1iIi1iIi1i
   return o00oOO0 , oOoo
   if 25 - 25: I1ii11iIi11i
   if 7 - 7: i1IIi / I1IiiI * oO0o . iiI1i1 . iIii1I11I1II1
   if 13 - 13: Oo / i11iIiiIii
   if 2 - 2: I1IiiI / O0 / o0oOOo0O0Ooo % OoOoOO00 % I1iII1iiII
  try :
   if 52 - 52: o0oOOo0O0Ooo
   II1III = '/streaming/info'
   oo0OooOOo0 = self . GetDefaultParams ( )
   if stype == 'onair' : oo0OooOOo0 [ 'osCode' ] = 'CSOD0400'
   if 95 - 95: I1iII1iiII
   if 87 - 87: OOO0o0o + OoOoOO00 . Oo + OoOoOO00
   if 91 - 91: O0
   oOOo0 = {
 'isTrusted' : 'false'
 , 'NONE' : '0'
 , 'CAPTURING_PHASE' : '1'
 , 'AT_TARGET' : '2'
 , 'BUBBLING_PHASE' : '3'
 , 'type' : 'oocCreate'
 , 'eventPhase' : '0'
 , 'bubbles' : 'false'
 , 'cancelable' : 'false'
 , 'defaultPrevented' : 'false'
 , 'composed' : 'false'
 , 'timeStamp' : '2158.7350000045262'
 , 'returnValue' : 'true'
 , 'cancelBubble' : 'false'
 }
   if 54 - 54: O0 - iiI1i1 % Oo
   OOoO = self . makeOocUrl ( oOOo0 )
   iII = urllib . quote ( OOoO )
   if 38 - 38: oO0o
   if 7 - 7: O0 . Ii11111i % I1ii11iIi11i - I1IiiI - iIii1I11I1II1
   if 36 - 36: iiI1i1 % OOO0o0o % Oo0Ooo - I1ii11iIi11i
   o0O = { 'info' : 'N'
   , 'mediaCode' : mediacode
 , 'callingFrom' : 'HTML5'
 , 'streamCode' : ii111111I1iII
   , 'adReq' : 'none'
 , 'ooc' : OOoO
 , 'deviceId' : iIii11I
 }
   Ii1I = oo0OooOOo0
   Ii1I . update ( o0O )
   if 77 - 77: Ii11111i % Ii11111i * ooOo - i11iIiiIii
   if 93 - 93: OoooooooOO / I1IiiI % i11iIiiIii + I1ii11iIi11i * OoO0O00
   oo0Ooo0 = self . URL_DOMAIN + II1III
   if 15 - 15: O00ooOO . OoO0O00 / Oo0Ooo + O00ooOO
   if 78 - 78: O0 . ooOo . II111iiii % Oo
   i1iIi = { 'origin' : 'https://www.tving.com'
 , 'Referer' : 'https://www.tving.com/vod/player/' + mediacode
 }
   if 68 - 68: i11iIiiIii % I1ii11iIi11i + i11iIiiIii
   Oooo0000 = self . makeDefaultCookies ( )
   Oooo0000 [ 'onClickEvent2' ] = iII
   if 31 - 31: II111iiii . I1IiiI
   o0OOOOO00o0O0 = self . callRequestCookies ( 'Post' , oo0Ooo0 , payload = Ii1I , params = None , headers = i1iIi , cookies = Oooo0000 )
   IIii1Ii1 = json . loads ( o0OOOOO00o0O0 . text )
   if 1 - 1: Oo0Ooo / o0oOOo0O0Ooo % Ii11111i * iiI1i1 . i11iIiiIii
   if 2 - 2: I1ii11iIi11i * O00ooOO - iIii1I11I1II1 + I1IiiI . ooOo % Ii11111i
   if 'drm_license_assertion' in IIii1Ii1 [ 'stream' ] :
    if 92 - 92: Ii11111i
    oOoo = IIii1Ii1 [ 'stream' ] [ 'drm_license_assertion' ]
    o00oOO0 = IIii1Ii1 [ 'stream' ] [ 'broadcast' ] [ 'widevine' ] [ 'broad_url' ]
   else :
    if not ( 'broad_url' in IIii1Ii1 [ 'stream' ] [ 'broadcast' ] ) : return o00oOO0 , oOoo
    o00oOO0 = IIii1Ii1 [ 'stream' ] [ 'broadcast' ] [ 'broad_url' ]
    if 25 - 25: Oo0Ooo - I1IiiI / OoooooooOO / o0oOOo0O0Ooo
  except Exception as oO00 :
   print ( oO00 )
   if 12 - 12: I1IiiI * Ii11111i % i1IIi % iIii1I11I1II1
  return o00oOO0 , oOoo
  if 20 - 20: Oo % I1iII1iiII / I1iII1iiII + I1iII1iiII
  if 45 - 45: ooOo - iiI1i1 - OoooooooOO - OoO0O00 . II111iiii / O0
 def CheckQuality ( self , sel_qt , qt_list ) :
  for oo0o00O in qt_list :
   if sel_qt >= list ( oo0o00O ) [ 0 ] : return oo0o00O . get ( list ( oo0o00O ) [ 0 ] )
   o00O0OoO = oo0o00O . get ( list ( oo0o00O ) [ 0 ] )
  return o00O0OoO
  if 16 - 16: iIii1I11I1II1
  if 90 - 90: o0oOOo0O0Ooo % i1IIi / OoO0O00
 def makeOocUrl ( self , ooc_params ) :
  oo0Ooo0 = ''
  for i1iIi1iIi1i , I1I1iIiII1 in ooc_params . items ( ) :
   oo0Ooo0 += "%s=%s^" % ( i1iIi1iIi1i , I1I1iIiII1 )
  return oo0Ooo0
  if 44 - 44: Oo0Ooo . OoO0O00 / I1ii11iIi11i + I1iII1iiII
  if 65 - 65: O0
 def GetLiveChannelList ( self , stype , page_int ) :
  oO00OOoO00 = [ ]
  IiI111111IIII = False
  if 37 - 37: oO0o / OoOoOO00
  try :
   II1III = '/v2/media/lives'
   if 23 - 23: O0
   if stype == 'onair' :
    o00oO0oOo00 = 'CPCS0100,CPCS0400'
   else :
    o00oO0oOo00 = 'CPCS0300'
    if 81 - 81: OoO0O00
   oo0OooOOo0 = self . GetDefaultParams ( )
   o0O = { 'pageNo' : str ( page_int )
 , 'pageSize' : str ( self . LIVE_LIMIT )
 , 'order' : 'rating'
 , 'adult' : 'all'
 , 'free' : 'all'
 , 'guest' : 'all'
 , 'scope' : 'all'
 , 'channelType' : o00oO0oOo00

   , '_' : str ( self . GetNoCache ( 2 ) )
 }
   oo0OooOOo0 . update ( o0O )
   if 42 - 42: OoO0O00 / O00ooOO / o0oOOo0O0Ooo + Ii11111i / OoOoOO00
   oo0Ooo0 = self . makeurl ( self . API_DOMAIN , II1III )
   if 84 - 84: OOO0o0o * II111iiii + Oo0Ooo
   if 53 - 53: Ii11111i % II111iiii . iiI1i1 - iIii1I11I1II1 - iiI1i1 * II111iiii
   Oooo0000 = self . makeDefaultCookies ( )
   o0OOOOO00o0O0 = self . callRequestCookies ( 'Get' , oo0Ooo0 , payload = None , params = oo0OooOOo0 , headers = None , cookies = Oooo0000 )
   IIii1Ii1 = json . loads ( o0OOOOO00o0O0 . text )
   if 77 - 77: iIii1I11I1II1 * OoO0O00
   if 95 - 95: I1IiiI + i11iIiiIii
   if not ( 'result' in IIii1Ii1 [ 'body' ] ) : return oO00OOoO00 , IiI111111IIII
   I1Ii = IIii1Ii1 [ 'body' ] [ 'result' ]
   if 94 - 94: I1iII1iiII - II111iiii . Oo % O00ooOO . i11iIiiIii + O0
   if 26 - 26: O00ooOO - iIii1I11I1II1 - I1IiiI / OoO0O00 . OoOoOO00 % iIii1I11I1II1
   for i1ii1iiI in I1Ii :
    OO = { }
    OO [ 'mediatype' ] = 'video'
    if 25 - 25: OoO0O00
    oOo0oO = OOOO0oo0 = I11iiI1i1 = I1i1Iiiii = ''
    OOo0oO00ooO00 = oOO0O00oO0Ooo = ''
    if 67 - 67: OoO0O00 - Oo
    iI1i11iII111 = i1ii1iiI [ 'live_code' ]
    oOo0oO = i1ii1iiI [ 'schedule' ] [ 'channel' ] [ 'name' ] [ 'ko' ]
    if 15 - 15: i11iIiiIii % I1iII1iiII . Oo0Ooo + I1ii11iIi11i
    if i1ii1iiI [ 'schedule' ] [ 'episode' ] != None :
     OOOO0oo0 = i1ii1iiI [ 'schedule' ] [ 'program' ] [ 'name' ] [ 'ko' ]
     OOOO0oo0 = OOOO0oo0 + ', ' + str ( i1ii1iiI [ 'schedule' ] [ 'episode' ] [ 'frequency' ] ) + '회'
     if i1ii1iiI [ 'schedule' ] [ 'episode' ] [ 'image' ] != [ ] :
      I11iiI1i1 = i1ii1iiI [ 'schedule' ] [ 'episode' ] [ 'image' ] [ 0 ] [ 'url' ]
     I1i1Iiiii = i1ii1iiI [ 'schedule' ] [ 'episode' ] [ 'synopsis' ] [ 'ko' ]
    else :
     OOOO0oo0 = i1ii1iiI [ 'schedule' ] [ 'program' ] [ 'name' ] [ 'ko' ]
     if i1ii1iiI [ 'schedule' ] [ 'program' ] [ 'image' ] != [ ] :
      I11iiI1i1 = i1ii1iiI [ 'schedule' ] [ 'program' ] [ 'image' ] [ 0 ] [ 'url' ]
     I1i1Iiiii = i1ii1iiI [ 'schedule' ] [ 'program' ] [ 'synopsis' ] [ 'ko' ]
     if 61 - 61: Oo0Ooo * I1ii11iIi11i % Oo0Ooo - i1IIi - iIii1I11I1II1
     if 74 - 74: I1ii11iIi11i + II111iiii / OoO0O00
    OO [ 'title' ] = i1ii1iiI [ 'schedule' ] [ 'program' ] [ 'name' ] [ 'ko' ]
    OO [ 'studio' ] = oOo0oO
    try :
     oOo0O0Oo00oO = [ ]
     for I111I1Iiii1i in i1ii1iiI . get ( 'schedule' ) . get ( 'program' ) . get ( 'actor' ) : oOo0O0Oo00oO . append ( I111I1Iiii1i )
     if oOo0O0Oo00oO [ 0 ] != '' and oOo0O0Oo00oO [ 0 ] != u'없음' : OO [ 'cast' ] = oOo0O0Oo00oO
    except :
     None
    try :
     oOOoo00O00o = [ ]
     if i1ii1iiI . get ( 'schedule' ) . get ( 'program' ) . get ( 'category1_name' ) . get ( 'ko' ) != '' :
      oOOoo00O00o . append ( i1ii1iiI [ 'schedule' ] [ 'program' ] [ 'category1_name' ] [ 'ko' ] )
     if i1ii1iiI . get ( 'schedule' ) . get ( 'program' ) . get ( 'category2_name' ) . get ( 'ko' ) != '' :
      oOOoo00O00o . append ( i1ii1iiI [ 'schedule' ] [ 'program' ] [ 'category2_name' ] [ 'ko' ] )
     if oOOoo00O00o [ 0 ] != '' : OO [ 'genre' ] = oOOoo00O00o
    except :
     None
     if 98 - 98: Oo + iiI1i1 + ooOo % OoooooooOO
     if 97 - 97: O0 * OoooooooOO . OoooooooOO
     if 33 - 33: oO0o + Ii11111i * ooOo / iIii1I11I1II1 - I1IiiI
     if 54 - 54: oO0o / Oo . ooOo % Ii11111i
    if I11iiI1i1 == '' :
     I11iiI1i1 = i1ii1iiI [ 'schedule' ] [ 'channel' ] [ 'image' ] [ 0 ] [ 'url' ]
    if I11iiI1i1 != '' : I11iiI1i1 = self . IMG_DOMAIN + I11iiI1i1
    if 57 - 57: i11iIiiIii . I1ii11iIi11i - I1iII1iiII - ooOo + OoOoOO00
    OOo0oO00ooO00 = str ( i1ii1iiI [ 'schedule' ] [ 'broadcast_start_time' ] ) [ 8 : 12 ]
    oOO0O00oO0Ooo = str ( i1ii1iiI [ 'schedule' ] [ 'broadcast_end_time' ] ) [ 8 : 12 ]
    if 63 - 63: OoOoOO00 * Ii11111i
    oo = { 'channel' : oOo0oO
 , 'title' : OOOO0oo0
 , 'mediacode' : iI1i11iII111
 , 'thumbnail' : I11iiI1i1
 , 'synopsis' : I1i1Iiiii
 , 'channelepg' : ' [%s:%s ~ %s:%s]' % ( OOo0oO00ooO00 [ 0 : 2 ] , OOo0oO00ooO00 [ 2 : ] , oOO0O00oO0Ooo [ 0 : 2 ] , oOO0O00oO0Ooo [ 2 : ] )
 , 'info' : OO
 }
    if 44 - 44: ooOo / O00ooOO / O00ooOO
    oO00OOoO00 . append ( oo )
    if 87 - 87: Oo0Ooo . I1IiiI - II111iiii + O0 / Oo0Ooo / ooOo
   if IIii1Ii1 [ 'body' ] [ 'has_more' ] == 'Y' : IiI111111IIII = True
   if 25 - 25: I1IiiI . I1IiiI - OoOoOO00 % OoOoOO00 - i11iIiiIii / oO0o
  except Exception as oO00 :
   print ( oO00 )
   if 51 - 51: Oo0Ooo / OoOoOO00 . Oo * o0oOOo0O0Ooo + OoO0O00 * iiI1i1
  return oO00OOoO00 , IiI111111IIII
  if 73 - 73: OoO0O00 + OoooooooOO - O0 - I1iII1iiII - II111iiii
  if 99 - 99: OOO0o0o . I1iII1iiII + oO0o + OoooooooOO % o0oOOo0O0Ooo
 def GetProgramList ( self , stype , orderby , page_int , landyn = False ) :
  oO00OOoO00 = [ ]
  IiI111111IIII = False
  if 51 - 51: iIii1I11I1II1
  try :
   II1III = '/v2/media/episodes'
   if 34 - 34: ooOo + I1IiiI - ooOo
   oo0OooOOo0 = self . GetDefaultParams ( )
   o0O = { 'pageNo' : str ( page_int )
 , 'pageSize' : str ( self . VOD_LIMIT )
 , 'order' : orderby
 , 'adult' : 'all'
 , 'free' : 'all'
 , 'guest' : 'all'
 , 'scope' : 'all'
 , 'lastFrequency' : 'y'
 , 'personal' : 'N'

   , '_' : str ( self . GetNoCache ( 2 ) )
 }
   if stype != 'all' : o0O [ 'multiCategoryCode' ] = stype
   if 17 - 17: II111iiii % Ii11111i + O00ooOO - Ii11111i / Oo + OOO0o0o
   oo0OooOOo0 . update ( o0O )
   if 59 - 59: Oo % OoOoOO00 . I1iII1iiII * I1ii11iIi11i % O00ooOO
   oo0Ooo0 = self . makeurl ( self . API_DOMAIN , II1III )
   if 59 - 59: ooOo - Ii11111i
   if 15 - 15: oO0o . i11iIiiIii . OoooooooOO / OoO0O00 % I1iII1iiII
   Oooo0000 = self . makeDefaultCookies ( )
   o0OOOOO00o0O0 = self . callRequestCookies ( 'Get' , oo0Ooo0 , payload = None , params = oo0OooOOo0 , headers = None , cookies = Oooo0000 )
   IIii1Ii1 = json . loads ( o0OOOOO00o0O0 . text )
   if 93 - 93: O0 % i1IIi . Oo / I1IiiI - oO0o / I1IiiI
   if 36 - 36: ooOo % ooOo % i1IIi / i1IIi - OOO0o0o
   if not ( 'result' in IIii1Ii1 [ 'body' ] ) : return oO00OOoO00 , IiI111111IIII
   I1Ii = IIii1Ii1 [ 'body' ] [ 'result' ]
   if 30 - 30: O00ooOO / I1IiiI
   if 35 - 35: II111iiii % Oo . OOO0o0o + OOO0o0o % II111iiii % II111iiii
   for i1ii1iiI in I1Ii :
    ooOoO00 = i1ii1iiI [ 'program' ] [ 'code' ]
    OOOO0oo0 = i1ii1iiI [ 'program' ] [ 'name' ] [ 'ko' ]
    if 14 - 14: i1IIi - o0oOOo0O0Ooo % O0 - OoO0O00
    I11iiI1i1 = self . IMG_DOMAIN + i1ii1iiI [ 'program' ] [ 'image' ] [ 0 ] [ 'url' ]
    ooO0O00Oo0o = 'CAIP0200' if landyn else 'CAIP0900'
    if 65 - 65: I1ii11iIi11i . O00ooOO - oO0o * iiI1i1 / oO0o / OOO0o0o
    for i111iIi1i1II1 in i1ii1iiI [ 'program' ] [ 'image' ] :
     if i111iIi1i1II1 [ 'code' ] == ooO0O00Oo0o :
      I11iiI1i1 = self . IMG_DOMAIN + i111iIi1i1II1 [ 'url' ]
      break
      if 86 - 86: iIii1I11I1II1 / OoOoOO00 . II111iiii
    I1i1Iiiii = i1ii1iiI [ 'program' ] [ 'synopsis' ] [ 'ko' ]
    II1i111Ii1i = i1ii1iiI [ 'program' ] [ 'channel_code' ]
    if 15 - 15: II111iiii / i1IIi
    OO = { }
    OO [ 'title' ] = OOOO0oo0
    OO [ 'mediatype' ] = 'episode'
    try :
     oOo0O0Oo00oO = [ ]
     for I111I1Iiii1i in i1ii1iiI . get ( 'program' ) . get ( 'actor' ) : oOo0O0Oo00oO . append ( I111I1Iiii1i )
     if oOo0O0Oo00oO [ 0 ] != '' and oOo0O0Oo00oO [ 0 ] != '-' : OO [ 'cast' ] = oOo0O0Oo00oO
    except :
     None
    try :
     O0oO0 = [ ]
     for iII11 in i1ii1iiI . get ( 'program' ) . get ( 'director' ) : O0oO0 . append ( iII11 )
     if O0oO0 [ 0 ] != '' and O0oO0 [ 0 ] != '-' : OO [ 'director' ] = O0oO0
    except :
     None
     if 32 - 32: oO0o
    oOOoo00O00o = [ ]
    if i1ii1iiI . get ( 'program' ) . get ( 'category1_name' ) . get ( 'ko' ) != '' :
     oOOoo00O00o . append ( i1ii1iiI [ 'program' ] [ 'category1_name' ] [ 'ko' ] )
    if i1ii1iiI . get ( 'program' ) . get ( 'category2_name' ) . get ( 'ko' ) != '' :
     oOOoo00O00o . append ( i1ii1iiI [ 'program' ] [ 'category2_name' ] [ 'ko' ] )
    if oOOoo00O00o [ 0 ] != '' : OO [ 'genre' ] = oOOoo00O00o
    if 30 - 30: iIii1I11I1II1 / O00ooOO . OoO0O00 - o0oOOo0O0Ooo
    try :
     if i1ii1iiI . get ( 'program' ) . get ( 'product_year' ) : OO [ 'year' ] = i1ii1iiI [ 'program' ] [ 'product_year' ]
     if 'broad_dt' in i1ii1iiI . get ( 'program' ) :
      Iii11iI1i = i1ii1iiI . get ( 'program' ) . get ( 'broad_dt' )
      OO [ 'aired' ] = '%s-%s-%s' % ( Iii11iI1i [ : 4 ] , Iii11iI1i [ 4 : 6 ] , Iii11iI1i [ 6 : ] )
    except :
     None
     if 57 - 57: o0oOOo0O0Ooo
     if 51 - 51: I1IiiI . iIii1I11I1II1 - I1ii11iIi11i / O0
    oo = { 'program' : ooOoO00
 , 'title' : OOOO0oo0
    , 'thumbnail' : I11iiI1i1
 , 'synopsis' : I1i1Iiiii
    , 'channel' : II1i111Ii1i
 , 'info' : OO
 }
    if 52 - 52: o0oOOo0O0Ooo + O0 + Ii11111i + Oo0Ooo % Ii11111i
    oO00OOoO00 . append ( oo )
    if 75 - 75: I1IiiI . OOO0o0o . O0 * oO0o
    if 4 - 4: I1iII1iiII % ooOo * OoO0O00
   if IIii1Ii1 [ 'body' ] [ 'has_more' ] == 'Y' : IiI111111IIII = True
   if 100 - 100: oO0o * Oo + Oo
  except Exception as oO00 :
   print ( oO00 )
   if 54 - 54: OoooooooOO + o0oOOo0O0Ooo - i1IIi % i11iIiiIii
  return oO00OOoO00 , IiI111111IIII
  if 3 - 3: o0oOOo0O0Ooo % o0oOOo0O0Ooo
  if 83 - 83: II111iiii + oO0o
 def GetEpisodoList ( self , program_code , page_int , orderby = 'desc' ) :
  oO00OOoO00 = [ ]
  IiI111111IIII = False
  if 73 - 73: Ii11111i
  try :
   II1III = '/v2/media/frequency/program/' + program_code
   if 42 - 42: i11iIiiIii * iIii1I11I1II1 / I1ii11iIi11i . i11iIiiIii % O00ooOO
   oo0OooOOo0 = self . GetDefaultParams ( )
   o0O = { 'pageNo' : '1'
   , 'pageSize' : '10'
   , 'order' : 'new'
 , 'free' : 'all'
 , 'adult' : 'all'
 , 'scope' : 'all'

   , '_' : str ( self . GetNoCache ( 2 ) )
 }
   if 41 - 41: iiI1i1 / O0
   oo0OooOOo0 . update ( o0O )
   if 51 - 51: O00ooOO % I1IiiI
   oo0Ooo0 = self . makeurl ( self . API_DOMAIN , II1III )
   if 60 - 60: I1IiiI / Oo . I1IiiI / oO0o . iiI1i1
   if 92 - 92: OoOoOO00 + oO0o * I1iII1iiII % I1IiiI
   Oooo0000 = self . makeDefaultCookies ( )
   o0OOOOO00o0O0 = self . callRequestCookies ( 'Get' , oo0Ooo0 , payload = None , params = oo0OooOOo0 , headers = None , cookies = Oooo0000 )
   IIii1Ii1 = json . loads ( o0OOOOO00o0O0 . text )
   if 42 - 42: Oo0Ooo
   if 76 - 76: I1IiiI * Ii11111i % oO0o
   if not ( 'result' in IIii1Ii1 [ 'body' ] ) : return oO00OOoO00 , IiI111111IIII
   I1Ii = IIii1Ii1 [ 'body' ] [ 'result' ]
   if 57 - 57: iIii1I11I1II1 - i1IIi / oO0o - O0 * OoooooooOO % II111iiii
   Oo00OO0o0o00 = int ( IIii1Ii1 [ 'body' ] [ 'total_count' ] )
   IiIi1I1 = int ( Oo00OO0o0o00 // ( self . EPISODE_LIMIT + 1 ) ) + 1
   if orderby == 'desc' :
    IiIIi1 = ( Oo00OO0o0o00 - 1 ) - ( ( page_int - 1 ) * self . EPISODE_LIMIT )
   else :
    IiIIi1 = ( page_int - 1 ) * self . EPISODE_LIMIT
    if 47 - 47: Oo0Ooo * I1ii11iIi11i + iIii1I11I1II1 / oO0o / OoO0O00 - OoooooooOO
   for iII1i11IIi1i in range ( self . EPISODE_LIMIT ) :
    if orderby == 'desc' :
     oOOoo0000O0o0 = IiIIi1 - iII1i11IIi1i
     if oOOoo0000O0o0 < 0 : break
    else :
     oOOoo0000O0o0 = IiIIi1 + iII1i11IIi1i
     if oOOoo0000O0o0 >= Oo00OO0o0o00 : break
     if 1 - 1: ooOo + ooOo % OoOoOO00 + i11iIiiIii
    oo0o0000 = I1Ii [ oOOoo0000O0o0 ] [ 'episode' ] [ 'code' ]
    OOOO0oo0 = I1Ii [ oOOoo0000O0o0 ] [ 'vod_name' ] [ 'ko' ]
    iiI = ''
    try :
     Iii11iI1i = str ( I1Ii [ oOOoo0000O0o0 ] [ 'episode' ] [ 'broadcast_date' ] )
     iiI = '%s-%s-%s' % ( Iii11iI1i [ : 4 ] , Iii11iI1i [ 4 : 6 ] , Iii11iI1i [ 6 : ] )
    except :
     None
    if I1Ii [ oOOoo0000O0o0 ] [ 'episode' ] [ 'image' ] != [ ] :
     I11iiI1i1 = self . IMG_DOMAIN + I1Ii [ oOOoo0000O0o0 ] [ 'episode' ] [ 'image' ] [ 0 ] [ 'url' ]
    else :
     I11iiI1i1 = self . IMG_DOMAIN + I1Ii [ oOOoo0000O0o0 ] [ 'program' ] [ 'image' ] [ 0 ] [ 'url' ]
    I1i1Iiiii = I1Ii [ oOOoo0000O0o0 ] [ 'episode' ] [ 'synopsis' ] [ 'ko' ]
    if 82 - 82: Oo0Ooo + OoO0O00
    OO = { }
    OO [ 'mediatype' ] = 'episode'
    try :
     OO [ 'title' ] = I1Ii [ oOOoo0000O0o0 ] [ 'program' ] [ 'name' ] [ 'ko' ]
     OO [ 'aired' ] = iiI
     OO [ 'studio' ] = I1Ii [ oOOoo0000O0o0 ] [ 'channel' ] [ 'name' ] [ 'ko' ]
     if 'frequency' in I1Ii [ oOOoo0000O0o0 ] [ 'episode' ] : OO [ 'episode' ] = I1Ii [ oOOoo0000O0o0 ] [ 'episode' ] [ 'frequency' ]
    except :
     None
     if 57 - 57: Oo / Oo * I1iII1iiII * Oo0Ooo . O0 - i11iIiiIii
    oo = { 'episode' : oo0o0000
 , 'title' : OOOO0oo0
 , 'subtitle' : iiI
 , 'thumbnail' : I11iiI1i1
 , 'synopsis' : I1i1Iiiii
 , 'info' : OO
 }
    if 18 - 18: I1iII1iiII + iiI1i1 - O0
    oO00OOoO00 . append ( oo )
    if 53 - 53: i1IIi
   if IiIi1I1 > page_int : IiI111111IIII = True
   if 87 - 87: i11iIiiIii + oO0o . I1ii11iIi11i * oO0o . OOO0o0o / I1ii11iIi11i
  except Exception as oO00 :
   print ( oO00 )
   if 76 - 76: O0 + i1IIi . Oo0Ooo * I1IiiI * I1iII1iiII
  return oO00OOoO00 , IiI111111IIII , IiIi1I1
  if 14 - 14: o0oOOo0O0Ooo % O0 * Ii11111i + I1iII1iiII + Oo0Ooo * I1iII1iiII
  if 3 - 3: OoOoOO00 * Oo0Ooo
 def GetMovieList ( self , orderby , page_int , premiumyn = False , landyn = False ) :
  oO00OOoO00 = [ ]
  IiI111111IIII = False
  if 95 - 95: Oo % ooOo . I1iII1iiII
  if premiumyn == True :
   o0Oooo = self . MOVIE_LITE + ',' + self . MOVIE_PREMIUM
  else :
   o0Oooo = self . MOVIE_LITE
   if 36 - 36: OoooooooOO . OoO0O00
  try :
   II1III = '/v2/media/movies'
   if 56 - 56: Oo0Ooo . I1ii11iIi11i . I1IiiI
   oo0OooOOo0 = self . GetDefaultParams ( )
   o0O = { 'pageNo' : str ( page_int )
 , 'pageSize' : str ( self . MOVIE_LIMIT )
 , 'order' : orderby
   , 'free' : 'all'
 , 'adult' : 'all'
 , 'guest' : 'all'
 , 'scope' : 'all'
 , 'productPackageCode' : o0Oooo
   # Oo0Ooo / oO0o . oO0o
   , '_' : str ( self . GetNoCache ( 2 ) )
 }
   if 98 - 98: Oo0Ooo / I1IiiI . O0 + OoO0O00
   oo0OooOOo0 . update ( o0O )
   oo0Ooo0 = self . makeurl ( self . API_DOMAIN , II1III )
   if 43 - 43: II111iiii . ooOo / I1ii11iIi11i
   Oooo0000 = self . makeDefaultCookies ( )
   o0OOOOO00o0O0 = self . callRequestCookies ( 'Get' , oo0Ooo0 , payload = None , params = oo0OooOOo0 , headers = None , cookies = Oooo0000 )
   IIii1Ii1 = json . loads ( o0OOOOO00o0O0 . text )
   if 20 - 20: I1IiiI
   if 95 - 95: Ii11111i - I1IiiI
   if not ( 'result' in IIii1Ii1 [ 'body' ] ) : return oO00OOoO00 , IiI111111IIII
   I1Ii = IIii1Ii1 [ 'body' ] [ 'result' ]
   if 34 - 34: OOO0o0o * I1IiiI . i1IIi * OOO0o0o / OOO0o0o
   if 30 - 30: I1ii11iIi11i + Oo0Ooo / Oo0Ooo % I1ii11iIi11i . I1ii11iIi11i
   for i1ii1iiI in I1Ii :
    O0O0Oo00 = i1ii1iiI [ 'movie' ] [ 'code' ]
    OOOO0oo0 = i1ii1iiI [ 'movie' ] [ 'name' ] [ 'ko' ] . strip ( )
    OOOO0oo0 += u' (%s년)' % ( i1ii1iiI . get ( 'movie' ) . get ( 'product_year' ) )
    I11iiI1i1 = self . IMG_DOMAIN + i1ii1iiI [ 'movie' ] [ 'image' ] [ 0 ] [ 'url' ]
    ooO0O00Oo0o = 'CAIM0400' if landyn else 'CAIM2100'
    if 80 - 80: ooOo + Oo / O00ooOO
    for i111iIi1i1II1 in i1ii1iiI [ 'movie' ] [ 'image' ] :
     if i111iIi1i1II1 [ 'code' ] == ooO0O00Oo0o :
      I11iiI1i1 = self . IMG_DOMAIN + i111iIi1i1II1 [ 'url' ]
      break
      if 79 - 79: OOO0o0o
    I1i1Iiiii = i1ii1iiI [ 'movie' ] [ 'story' ] [ 'ko' ]
    if 48 - 48: oO0o - o0oOOo0O0Ooo % I1iII1iiII
    OO = { }
    OO [ 'mediatype' ] = 'movie'
    OO [ 'title' ] = i1ii1iiI [ 'movie' ] [ 'name' ] [ 'ko' ] . strip ( )
    OO [ 'year' ] = i1ii1iiI . get ( 'movie' ) . get ( 'product_year' )
    try :
     oOo0O0Oo00oO = [ ]
     for I111I1Iiii1i in i1ii1iiI . get ( 'movie' ) . get ( 'actor' ) : oOo0O0Oo00oO . append ( I111I1Iiii1i )
     if oOo0O0Oo00oO [ 0 ] != '' : OO [ 'cast' ] = oOo0O0Oo00oO
    except :
     None
    try :
     O0oO0 = [ ]
     for iII11 in i1ii1iiI . get ( 'movie' ) . get ( 'director' ) : O0oO0 . append ( iII11 )
     if O0oO0 [ 0 ] != '' : OO [ 'director' ] = O0oO0
    except :
     None
    try :
     oOOoo00O00o = [ ]
     if i1ii1iiI . get ( 'movie' ) . get ( 'category1_name' ) . get ( 'ko' ) != '' :
      oOOoo00O00o . append ( i1ii1iiI [ 'movie' ] [ 'category1_name' ] [ 'ko' ] )
     if i1ii1iiI . get ( 'movie' ) . get ( 'category2_name' ) . get ( 'ko' ) != '' :
      oOOoo00O00o . append ( i1ii1iiI [ 'movie' ] [ 'category2_name' ] [ 'ko' ] )
     if oOOoo00O00o [ 0 ] != '' : OO [ 'genre' ] = oOOoo00O00o
    except :
     None
    try :
     if 'release_date' in i1ii1iiI . get ( 'movie' ) :
      Iii11iI1i = str ( i1ii1iiI . get ( 'movie' ) . get ( 'release_date' ) )
      OO [ 'aired' ] = '%s-%s-%s' % ( Iii11iI1i [ : 4 ] , Iii11iI1i [ 4 : 6 ] , Iii11iI1i [ 6 : ] )
    except :
     None
    try :
     if 'duration' in i1ii1iiI . get ( 'movie' ) : OO [ 'duration' ] = i1ii1iiI . get ( 'movie' ) . get ( 'duration' )
    except :
     None
     if 36 - 36: ooOo - I1iII1iiII . Oo0Ooo - i11iIiiIii - Oo * Oo0Ooo
     if 76 - 76: i11iIiiIii + o0oOOo0O0Ooo / I1ii11iIi11i - OoO0O00 - I1iII1iiII + I1ii11iIi11i
    oo = { 'moviecode' : O0O0Oo00
 , 'title' : OOOO0oo0
 , 'thumbnail' : I11iiI1i1
 , 'synopsis' : I1i1Iiiii
 , 'info' : OO
 }
    if 51 - 51: iIii1I11I1II1 . OOO0o0o + iIii1I11I1II1
    if premiumyn == True :
     oOoOO = False
     for Ii1i1 in i1ii1iiI [ 'billing_package_id' ] :
      if Ii1i1 == self . MOVIE_LITE :
       oOoOO = True
       break
     if oOoOO == False :
      oo [ 'title' ] = oo [ 'title' ] + ' [Premium]'
      if 65 - 65: OOO0o0o . OoooooooOO / I1ii11iIi11i . i1IIi * OoO0O00
    oO00OOoO00 . append ( oo )
    if 19 - 19: i11iIiiIii + OoooooooOO - Oo0Ooo - O00ooOO
    if 21 - 21: O0 % iiI1i1 . I1IiiI / II111iiii + iiI1i1
   if IIii1Ii1 [ 'body' ] [ 'has_more' ] == 'Y' : IiI111111IIII = True
   if 53 - 53: ooOo - I1IiiI - ooOo * Ii11111i
  except Exception as oO00 :
   print ( oO00 )
   if 71 - 71: O0 - iIii1I11I1II1
  return oO00OOoO00 , IiI111111IIII
  if 12 - 12: Oo / o0oOOo0O0Ooo
  if 42 - 42: Oo0Ooo
 def GetMovieListGenre ( self , genre , page_int , premiumyn = False ) :
  oO00OOoO00 = [ ]
  IiI111111IIII = False
  if 19 - 19: ooOo % I1ii11iIi11i * iIii1I11I1II1 + I1IiiI
  if premiumyn == True :
   o0Oooo = self . MOVIE_LITE + ',' + self . MOVIE_PREMIUM
  else :
   o0Oooo = self . MOVIE_LITE
   if 46 - 46: Oo0Ooo
  try :
   II1III = '/v2/media/movie/curation/' + genre
   if 1 - 1: Ii11111i
   oo0OooOOo0 = self . GetDefaultParams ( )
   o0O = { 'pageNo' : str ( page_int )
 , 'pageSize' : str ( self . MOVIE_LIMIT )
 , 'productPackageCode' : o0Oooo
   # OoOoOO00 - OoO0O00 % OoOoOO00 * i11iIiiIii . II111iiii % II111iiii
   , '_' : str ( self . GetNoCache ( 2 ) )
 }
   if 54 - 54: O00ooOO + I1iII1iiII
   oo0OooOOo0 . update ( o0O )
   oo0Ooo0 = self . makeurl ( self . API_DOMAIN , II1III )
   if 55 - 55: iIii1I11I1II1
   Oooo0000 = self . makeDefaultCookies ( )
   o0OOOOO00o0O0 = self . callRequestCookies ( 'Get' , oo0Ooo0 , payload = None , params = oo0OooOOo0 , headers = None , cookies = Oooo0000 )
   IIii1Ii1 = json . loads ( o0OOOOO00o0O0 . text )
   if 78 - 78: Ii11111i + O00ooOO . OOO0o0o - Ii11111i . I1iII1iiII
   if 30 - 30: I1IiiI + OoO0O00 % I1iII1iiII * Ii11111i / Oo0Ooo - O00ooOO
   if not ( 'movies' in IIii1Ii1 [ 'body' ] ) : return oO00OOoO00 , IiI111111IIII
   I1Ii = IIii1Ii1 [ 'body' ] [ 'movies' ]
   if 64 - 64: iIii1I11I1II1
   if 21 - 21: Oo0Ooo . II111iiii
   for i1ii1iiI in I1Ii :
    O0O0Oo00 = i1ii1iiI [ 'code' ]
    OOOO0oo0 = i1ii1iiI [ 'name' ] [ 'ko' ]
    I11iiI1i1 = self . IMG_DOMAIN + i1ii1iiI [ 'image' ] [ 0 ] [ 'url' ]
    for i111iIi1i1II1 in i1ii1iiI [ 'image' ] :
     if i111iIi1i1II1 [ 'code' ] == 'CAIM2100' :
      I11iiI1i1 = self . IMG_DOMAIN + i111iIi1i1II1 [ 'url' ]
    I1i1Iiiii = i1ii1iiI [ 'story' ] [ 'ko' ]
    if 54 - 54: II111iiii % II111iiii
    oo = { 'moviecode' : O0O0Oo00
 , 'title' : OOOO0oo0 . strip ( )
 , 'thumbnail' : I11iiI1i1
 , 'synopsis' : I1i1Iiiii
 }
    if 86 - 86: O0 % I1iII1iiII * OOO0o0o * iIii1I11I1II1 * i1IIi * O00ooOO
    if premiumyn == True :
     oOoOO = False
     for Ii1i1 in i1ii1iiI [ 'billing_package_id' ] :
      if Ii1i1 == self . MOVIE_LITE :
       oOoOO = True
       break
     if oOoOO == False :
      oo [ 'title' ] = oo [ 'title' ] + ' [Premium]'
      if 83 - 83: OoOoOO00 % II111iiii - OoOoOO00 + iiI1i1 - O0
    oO00OOoO00 . append ( oo )
    if 52 - 52: Oo0Ooo * OOO0o0o
    if 33 - 33: I1iII1iiII
    if 74 - 74: Oo + O0 + i1IIi - i1IIi + II111iiii
    if 83 - 83: I1ii11iIi11i - I1IiiI + Oo
  except Exception as oO00 :
   print ( oO00 )
   if 5 - 5: I1iII1iiII
  return oO00OOoO00 , IiI111111IIII
  if 46 - 46: iiI1i1
  if 45 - 45: OOO0o0o
 def GetMovieGenre ( self ) :
  oO00OOoO00 = [ ]
  IiI111111IIII = False
  if 21 - 21: ooOo . oO0o . Oo / Oo0Ooo / oO0o
  try :
   II1III = '/v2/media/movie/curations'
   if 17 - 17: Oo / Oo / O00ooOO
   oo0OooOOo0 = self . GetDefaultParams ( )
   o0O = { 'pageNo' : '1'
   , 'pageSize' : '10'
   , 'movieViewType' : 'sma'
 , 'curationSection' : 'view0002'
   , 'order' : 'curation_code'

   , '_' : str ( self . GetNoCache ( 2 ) )
 }
   if 1 - 1: i1IIi . i11iIiiIii % Oo
   oo0OooOOo0 . update ( o0O )
   oo0Ooo0 = self . makeurl ( self . API_DOMAIN , II1III )
   if 82 - 82: iIii1I11I1II1 + Oo0Ooo . iIii1I11I1II1 % iiI1i1 / I1iII1iiII . I1iII1iiII
   Oooo0000 = self . makeDefaultCookies ( )
   o0OOOOO00o0O0 = self . callRequestCookies ( 'Get' , oo0Ooo0 , payload = None , params = oo0OooOOo0 , headers = None , cookies = Oooo0000 )
   IIii1Ii1 = json . loads ( o0OOOOO00o0O0 . text )
   if 14 - 14: o0oOOo0O0Ooo . Oo . O00ooOO + OoooooooOO - Oo + iiI1i1
   if 9 - 9: I1iII1iiII
   if not ( 'result' in IIii1Ii1 [ 'body' ] ) : return oO00OOoO00 , IiI111111IIII
   I1Ii = IIii1Ii1 [ 'body' ] [ 'result' ]
   if 59 - 59: I1IiiI * II111iiii . O0
   if 56 - 56: I1iII1iiII - Ii11111i % I1IiiI - o0oOOo0O0Ooo
   for i1ii1iiI in I1Ii :
    Oo00O = i1ii1iiI [ 'curation_code' ]
    iI111i1II = i1ii1iiI [ 'curation_name' ]
    if 69 - 69: I1iII1iiII * O0 . i11iIiiIii / I1iII1iiII . o0oOOo0O0Ooo
    oo = { 'curation_code' : Oo00O
 , 'curation_name' : iI111i1II
 }
    oO00OOoO00 . append ( oo )
    if 63 - 63: O00ooOO + o0oOOo0O0Ooo . II111iiii - I1IiiI
    if 52 - 52: o0oOOo0O0Ooo % Oo0Ooo
    if 64 - 64: O0 % O00ooOO % O0 * OoO0O00 . ooOo + I1IiiI
  except Exception as oO00 :
   print ( oO00 )
   if 75 - 75: O00ooOO . OoooooooOO % o0oOOo0O0Ooo * O00ooOO % OoooooooOO
  return oO00OOoO00 , IiI111111IIII
  if 13 - 13: iiI1i1 / i11iIiiIii % II111iiii % O00ooOO . I1ii11iIi11i
  if 8 - 8: OoOoOO00 + Oo0Ooo - II111iiii
 def GetSearchList ( self , search_key , userid , page_int , stype , premiumyn = False , landyn = False ) :
  IiIi1iIIi1 = [ ]
  IiI111111IIII = False
  if 86 - 86: O00ooOO * I1IiiI + O00ooOO + II111iiii
  try :
   II1III = '/search/getSearch.jsp'
   if 8 - 8: oO0o - Ii11111i / OOO0o0o
   if 96 - 96: OoOoOO00
   o0O = { 'kwd' : search_key
 , 'notFoundText' : search_key
 , 'userid' : userid
 , 'siteName' : 'TVING_WEB'
 , 'category' : 'TOTAL'
   , 'pageNum' : str ( page_int )
 , 'pageSize' : str ( self . SEARCH_LIMIT )
 , 'indexType' : 'both'
 , 'methodType' : 'allwordthruindex'
 , 'payFree' : 'ALL'
 , 'runTime' : 'ALL'
 , 'grade' : 'ALL'
 , 'genre' : 'ALL'
 , 'screen' : self . SCREENCODE
 , 'os' : self . OSCODE
 , 'network' : self . NETWORKCODE
 , 'sort1' : 'NO'
 , 'sort2' : 'NO'
 , 'sort3' : 'NO'
 , 'type1' : 'desc'
 , 'type2' : 'desc'
 , 'type3' : 'desc'
 , 'fixedType' : 'Y'
 , 'spcMethod' : 'someword'
 , 'spcSize' : '0'
 , 'schReqCnt' : '0'
   , 'vodBCReqCnt' : '0'
   , 'programReqCnt' : str ( self . SEARCH_LIMIT )
 , 'vodMVReqCnt' : str ( self . SEARCH_LIMIT )
 , 'smrclipReqCnt' : '0'
   , 'pickClipReqCnt' : '0'
   , 'aloneReqCnt' : '0'
   , 'cSocialClipCnt' : '0'
 , 'boardReqCnt' : '0'
 , 'talkReqCnt' : '0'
 , 'nowTime' : ''
 , 'mode' : 'normal'
 , 'adult_yn' : ''
 , 'reKwd' : ''
 , 'xwd' : ''

   , '_' : str ( self . GetNoCache ( 2 ) )
 }
   if 29 - 29: I1ii11iIi11i / i1IIi . I1IiiI - OoOoOO00 - OoOoOO00 - I1iII1iiII
   if 20 - 20: i1IIi % OoO0O00 . I1IiiI / iiI1i1 * i11iIiiIii * Oo
   oo0Ooo0 = self . makeurl ( self . SEARCH_DOMAIN , II1III )
   if 85 - 85: o0oOOo0O0Ooo . OoOoOO00 / OOO0o0o . O0 % oO0o
   Oooo0000 = self . makeDefaultCookies ( )
   o0OOOOO00o0O0 = self . callRequestCookies ( 'Get' , oo0Ooo0 , payload = None , params = o0O , headers = None , cookies = Oooo0000 )
   IIii1Ii1 = json . loads ( o0OOOOO00o0O0 . text )
   if 90 - 90: Oo0Ooo % O0 * iIii1I11I1II1 . Ii11111i
   if 8 - 8: OOO0o0o + II111iiii / Ii11111i / O00ooOO
   if stype == 'vod' :
    if not ( 'programRsb' in IIii1Ii1 ) : return IiIi1iIIi1 , IiI111111IIII
    if 74 - 74: O0 / i1IIi
    OoO = IIii1Ii1 [ 'programRsb' ] [ 'dataList' ]
    Iiiiii111i1ii = int ( IIii1Ii1 [ 'programRsb' ] [ 'count' ] )
    if 25 - 25: Oo - OOO0o0o / i11iIiiIii
    if 41 - 41: i1IIi % Ii11111i + iIii1I11I1II1
    for i1ii1iiI in OoO :
     ooOoO00 = i1ii1iiI [ 'mast_cd' ]
     OOOO0oo0 = i1ii1iiI [ 'mast_nm' ]
     I11iiI1i1 = self . IMG_DOMAIN + i1ii1iiI [ 'web_url' ]
     if landyn == False :
      I11iiI1i1 = self . IMG_DOMAIN + i1ii1iiI [ 'web_url4' ]
      if 2 - 2: iIii1I11I1II1 * Oo0Ooo % ooOo - II111iiii - Ii11111i
      if 3 - 3: oO0o
      if 45 - 45: oO0o
     OO = { }
     OO [ 'title' ] = i1ii1iiI [ 'mast_nm' ]
     OO [ 'mediatype' ] = 'episode'
     if 83 - 83: OoOoOO00 . OoooooooOO
     try :
      if i1ii1iiI . get ( 'actor' ) != '' and i1ii1iiI . get ( 'actor' ) != '-' : OO [ 'cast' ] = i1ii1iiI . get ( 'actor' ) . split ( ',' )
      if i1ii1iiI . get ( 'director' ) != '' and i1ii1iiI . get ( 'director' ) != '-' : OO [ 'director' ] = i1ii1iiI . get ( 'director' ) . split ( ',' )
      if i1ii1iiI . get ( 'cate_nm' ) != '' : OO [ 'genre' ] = i1ii1iiI . get ( 'cate_nm' ) . split ( '/' )
      if 'targetage' in i1ii1iiI : OO [ 'mpaa' ] = i1ii1iiI . get ( 'targetage' )
     except :
      None
     try :
      if 'broad_dt' in i1ii1iiI :
       Iii11iI1i = i1ii1iiI . get ( 'broad_dt' )
       OO [ 'aired' ] = '%s-%s-%s' % ( Iii11iI1i [ : 4 ] , Iii11iI1i [ 4 : 6 ] , Iii11iI1i [ 6 : ] )
     except :
      None
      if 58 - 58: i11iIiiIii + OoooooooOO % OoooooooOO / iiI1i1 / i11iIiiIii
     oo = { 'program' : ooOoO00
 , 'title' : OOOO0oo0
 , 'thumbnail' : I11iiI1i1
 , 'synopsis' : ''
     , 'info' : OO
 }
     if 62 - 62: OoO0O00 / I1ii11iIi11i
     IiIi1iIIi1 . append ( oo )
   else :
    if not ( 'vodMVRsb' in IIii1Ii1 ) : return IiIi1iIIi1 , IiI111111IIII
    ii1 = IIii1Ii1 [ 'vodMVRsb' ] [ 'dataList' ]
    Iiiiii111i1ii = int ( IIii1Ii1 [ 'vodMVRsb' ] [ 'count' ] )
    if 53 - 53: I1iII1iiII % I1iII1iiII * o0oOOo0O0Ooo + OoOoOO00
    if 92 - 92: OoooooooOO + i1IIi / I1iII1iiII * O0
    for i1ii1iiI in ii1 :
     ooOoO00 = i1ii1iiI [ 'mast_cd' ]
     OOOO0oo0 = i1ii1iiI [ 'mast_nm' ] . strip ( )
     I11iiI1i1 = self . IMG_DOMAIN + i1ii1iiI [ 'web_url' ]
     if 100 - 100: OOO0o0o % iIii1I11I1II1 * II111iiii - Ii11111i
     if 92 - 92: OOO0o0o
     if landyn == False :
      I11iiI1i1 = self . IMG_DOMAIN + i1ii1iiI [ 'web_url5' ]
      if 22 - 22: Oo0Ooo % Ii11111i * I1ii11iIi11i / Oo % i11iIiiIii * O00ooOO
      if 95 - 95: OoooooooOO - iiI1i1 * I1IiiI + OoOoOO00
      if 10 - 10: o0oOOo0O0Ooo / i11iIiiIii
     OO = { }
     OO [ 'title' ] = OOOO0oo0
     OO [ 'mediatype' ] = 'movie'
     if 92 - 92: O00ooOO . oO0o
     try :
      if i1ii1iiI . get ( 'actor' ) != '' : OO [ 'cast' ] = i1ii1iiI . get ( 'actor' ) . split ( ',' )
      if 85 - 85: I1ii11iIi11i . oO0o
      if i1ii1iiI . get ( 'cate_nm' ) != '' : OO [ 'genre' ] = i1ii1iiI . get ( 'cate_nm' ) . split ( '/' )
      if i1ii1iiI . get ( 'runtime_sec' ) != '' : OO [ 'duration' ] = i1ii1iiI . get ( 'runtime_sec' )
      if 'grade_nm' in i1ii1iiI : OO [ 'mpaa' ] = i1ii1iiI . get ( 'grade_nm' )
     except :
      None
     try :
      Iii11iI1i = i1ii1iiI . get ( 'broad_dt' )
      if data_str != '' :
       OO [ 'aired' ] = '%s-%s-%s' % ( Iii11iI1i [ : 4 ] , Iii11iI1i [ 4 : 6 ] , Iii11iI1i [ 6 : ] )
       OO [ 'year' ] = Iii11iI1i [ : 4 ]
     except :
      None
      if 78 - 78: OOO0o0o * oO0o + iIii1I11I1II1 + iIii1I11I1II1 / oO0o . I1iII1iiII
      if 97 - 97: OOO0o0o / oO0o % i1IIi % I1ii11iIi11i
      if 18 - 18: iIii1I11I1II1 % O00ooOO
     if True :
      oo = { 'movie' : ooOoO00
 , 'title' : OOOO0oo0
 , 'thumbnail' : I11iiI1i1
 , 'synopsis' : ''
      , 'info' : OO
 }
      if 95 - 95: OOO0o0o + i11iIiiIii * oO0o - i1IIi * oO0o - iIii1I11I1II1
      IiIi1iIIi1 . append ( oo )
      if 75 - 75: OoooooooOO * iiI1i1
      if 9 - 9: iiI1i1 - II111iiii + O0 / iIii1I11I1II1 / i11iIiiIii
      if 39 - 39: iiI1i1 * Oo0Ooo + iIii1I11I1II1 - iiI1i1 + Oo
      if 69 - 69: O0
  except Exception as oO00 :
   if 85 - 85: OOO0o0o / O0
   print ( oO00 )
   if 18 - 18: o0oOOo0O0Ooo % O0 * I1ii11iIi11i
  return IiIi1iIIi1 , IiI111111IIII
  if 62 - 62: oO0o . iiI1i1 . OoooooooOO
  if 11 - 11: Oo / O00ooOO
 def GetDeviceList ( self , tving_token , poc_userinfo ) :
  oO00OOoO00 = [ ]
  iIii11I = '-'
  if 73 - 73: i1IIi / i11iIiiIii
  try :
   II1III = '/v1/user/device/list'
   OOO = self . makeurl ( self . API_DOMAIN , II1III )
   if 30 - 30: OoooooooOO - OoooooooOO . O0 / Ii11111i
   o0O = { 'apiKey' : '4263d7d76161f4a19a9efe9ca7903ec4'
 , 'model' : 'PC'
 }
   Oooo0000 = self . makeDefaultCookies ( vToken = tving_token , vUserinfo = poc_userinfo )
   if 31 - 31: Oo + o0oOOo0O0Ooo . OoooooooOO
   o0OOOOO00o0O0 = self . callRequestCookies ( 'Get' , OOO , payload = None , params = o0O , headers = None , cookies = Oooo0000 )
   IIii1Ii1 = json . loads ( o0OOOOO00o0O0 . text )
   if 89 - 89: II111iiii + i1IIi + II111iiii
   if 7 - 7: O0 % o0oOOo0O0Ooo + I1ii11iIi11i * Ii11111i - Ii11111i
   oO00OOoO00 = IIii1Ii1 [ 'body' ]
   if 42 - 42: OoOoOO00 * OoOoOO00 * oO0o . O00ooOO
   for i1ii1iiI in oO00OOoO00 :
    if i1ii1iiI [ 'model' ] == 'PC' :
     iIii11I = i1ii1iiI [ 'uuid' ]
     if 51 - 51: Oo % iIii1I11I1II1 - OoooooooOO % OOO0o0o * iIii1I11I1II1 % OoO0O00
     if 99 - 99: ooOo * II111iiii * oO0o
  except Exception as oO00 :
   print ( oO00 )
   if 92 - 92: Oo0Ooo
  return iIii11I
  if 40 - 40: OoOoOO00 / iiI1i1
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
