# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
import os
import sys
import xbmcaddon
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
__cwd__ = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) )
__lib__ = os . path . join ( __cwd__ , 'resources' , 'lib' )
sys . path . append ( __lib__ )
if 94 - 94: i1IIi % Oo0Ooo
from tvingRun import *
if 68 - 68: Ii1I / O0
if 46 - 46: O0 * II111iiii / IiII * Oo0Ooo * iII111i . I11i
def Oo0oO0ooo ( ) :
 o0oOoO00o = urlparse . parse_qs ( sys . argv [ 2 ] [ 1 : ] )
 for i1 in o0oOoO00o . keys ( ) :
  o0oOoO00o [ i1 ] = o0oOoO00o [ i1 ] [ 0 ]
 return o0oOoO00o
 if 64 - 64: I1ii11iIi11i % OoO0O00
 if 1 - 1: IiII
 if 91 - 91: I1ii11iIi11i * iIii1I11I1II1 . IiII / Ii1I
Ooo0 = O0O00Ooo ( sys . argv [ 0 ] , int ( sys . argv [ 1 ] ) , Oo0oO0ooo ( ) )
Ooo0 . tving_main ( )
if 89 - 89: OoooooooOO - IiII * ooOoO0o
if 82 - 82: I11i . I1Ii111 / IiII % II111iiii % iIii1I11I1II1 % IiII
if 86 - 86: OoOoOO00 % I1IiiI
if 80 - 80: OoooooooOO . I1IiiI
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
