# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
import os
import sys
import xbmcaddon
if 46 - 46: ooOoO0o * I11i - OoooooooOO
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
__cwd__ = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) )
__lib__ = os . path . join ( __cwd__ , 'resources' , 'lib' )
sys . path . append ( __lib__ )
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
from wavveRun import *
if 94 - 94: i1IIi % Oo0Ooo
if 68 - 68: Ii1I / O0
def Iiii111Ii11I1 ( ) :
 ooO0oooOoO0 = urlparse . parse_qs ( sys . argv [ 2 ] [ 1 : ] )
 for II11i in ooO0oooOoO0 . keys ( ) :
  ooO0oooOoO0 [ II11i ] = ooO0oooOoO0 [ II11i ] [ 0 ]
 return ooO0oooOoO0
 if 43 - 43: Ii1I . oO0o
 if 27 - 27: OoO0O00 - O0 . I1Ii111 * iII111i - I1ii11iIi11i
i1111 = iIiiI1 ( sys . argv [ 0 ] , int ( sys . argv [ 1 ] ) , Iiii111Ii11I1 ( ) )
i1111 . wavve_main ( )
if 22 - 22: Ii1I . IiII
if 41 - 41: I1Ii111 . ooOoO0o * IiII % i11iIiiIii
if 74 - 74: iII111i * IiII
if 82 - 82: iIii1I11I1II1 % IiII
if 86 - 86: OoOoOO00 % I1IiiI
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
