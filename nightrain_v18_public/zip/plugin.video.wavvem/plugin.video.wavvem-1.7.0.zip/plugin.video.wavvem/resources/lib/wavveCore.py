# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import urllib
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
import re
import json
import sys
import requests
import datetime
import urlparse
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
IiiIII111iI = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . OoO0O00 - I1ii11iIi11i
if 53 - 53: I11i / Oo0Ooo / II111iiii % Ii1I / OoOoOO00 . Oo0ooO0oo0oO
if 100 - 100: i1IIi
class xI1Ii11I1Ii1i ( object ) :
 def __init__ ( self ) :
  self . API_DOMAIN = 'https://apis.wavve.com'
  self . APIKEY = 'E5F3E0D30947AA5440556471321BB6D9'
  self . CREDENTIAL = 'none'
  self . DEVICE = 'pc'
  self . DRM = 'wm'
  self . PARTNER = 'pooq'
  self . POOQZONE = 'none'
  self . REGION = 'kor'
  self . TARGETAGE = 'all'
  self . HTTPTAG = 'https://'
  self . LIST_LIMIT = 30
  self . EP_LIMIT = 30
  self . MV_LIMIT = 24
  self . guid = 'none'
  self . guidtimestamp = 'none'
  self . DEFAULT_HEADER = { 'user-agent' : IiiIII111iI }
  if 67 - 67: iIii1I11I1II1 . I1ii11iIi11i . oO0o / i1IIi % II111iiii - OoOoOO00
  if 91 - 91: OoO0O00 . i11iIiiIii / oO0o % I11i / OoO0O00 - i11iIiiIii
 def callRequestCookies ( self , jobtype , url , payload = None , params = None , headers = None , cookies = None , redirects = False ) :
  II1Iiii1111i = self . DEFAULT_HEADER
  if headers : II1Iiii1111i . update ( headers )
  if 25 - 25: Ii1I
  if jobtype == 'Get' :
   oo00000o0 = requests . get ( url , params = params , headers = II1Iiii1111i , cookies = cookies , allow_redirects = redirects )
  else :
   oo00000o0 = requests . post ( url , data = payload , params = params , headers = II1Iiii1111i , cookies = cookies , allow_redirects = redirects )
   if 34 - 34: O00oOoOoO0o0O % II111iiii % iIii1I11I1II1 % O00oOoOoO0o0O * iii1I1I / OoOoOO00
  return oo00000o0
  if 31 - 31: i11iIiiIii / I1IiiI / Oo0ooO0oo0oO * oO0o / Oo0Ooo
 def SaveCredential ( self , credential ) :
  self . CREDENTIAL = credential
  if 99 - 99: iIii1I11I1II1 * OoooooooOO * II111iiii * iIii1I11I1II1
 def LoadCredential ( self ) :
  return self . CREDENTIAL
  if 44 - 44: oO0o / Oo0Ooo - II111iiii - i11iIiiIii % O0oo0OO0
 def GetDefaultParams ( self , login = True ) :
  O0OoOoo00o = { 'apikey' : self . APIKEY
 , 'credential' : self . CREDENTIAL if login else 'none'
 , 'device' : self . DEVICE
 , 'drm' : self . DRM
 , 'partner' : self . PARTNER
 , 'pooqzone' : self . POOQZONE
 , 'region' : self . REGION
 , 'targetage' : self . TARGETAGE
 }
  return O0OoOoo00o
  if 31 - 31: II111iiii + OoO0O00 . O0oo0OO0
  if 68 - 68: I1IiiI - i11iIiiIii - OoO0O00 / OOooOOo - OoO0O00 + i1IIi
 def GetGUID ( self , guid_str = 'POOQ' , guidType = 1 ) :
  if 48 - 48: OoooooooOO % o0oOOo0O0Ooo . I1IiiI - Ii1I % i1IIi % OoooooooOO
  def i1iIIi1 ( media ) :
   ii11iIi1I = self . Get_Now_Datetime ( ) . strftime ( '%Y%m%d%H%M%S' )
   iI111I11I1I1 = OOooO0OOoo ( 5 )
   iIii1 = iI111I11I1I1 + media + ii11iIi1I
   return iIii1
   if 71 - 71: OoO0O00
  def OOooO0OOoo ( num ) :
   from random import randint
   oO0O = ""
   for OOoO000O0OO in range ( 0 , num ) :
    iiI1IiI = str ( randint ( 1 , 5 ) )
    oO0O += iiI1IiI
   return oO0O
   if 13 - 13: Oo0Ooo . i11iIiiIii - iIii1I11I1II1 - OoOoOO00
  iIii1 = i1iIIi1 ( guid_str )
  if 6 - 6: I1IiiI / Oo0Ooo % Ii1I
  oo = self . GetHash ( iIii1 )
  if guidType == 2 :
   oo = '%s-%s-%s-%s-%s' % ( oo [ : 8 ] , oo [ 8 : 12 ] , oo [ 12 : 16 ] , oo [ 16 : 20 ] , oo [ 20 : ] )
   if 54 - 54: OOooOOo + OOooOOo % O0oo0OO0 % i11iIiiIii / iIii1I11I1II1 . OOooOOo
  return oo
  if 57 - 57: Ii1I % OoooooooOO
 def GetHash ( self , hash_str ) :
  import hashlib
  O00 = hashlib . md5 ( )
  if 11 - 11: I1IiiI
  O00 . update ( hash_str . encode ( 'utf-8' ) )
  return str ( O00 . hexdigest ( ) )
  if 68 - 68: I11i + OOooOOo . iIii1I11I1II1 - O00oOoOoO0o0O % iIii1I11I1II1 - Oo0ooO0oo0oO
 def CheckQuality ( self , sel_qt , qt_list ) :
  oOOO00o = 0
  for O0O00o0OOO0 in qt_list :
   if sel_qt >= O0O00o0OOO0 : return O0O00o0OOO0
   oOOO00o = O0O00o0OOO0
  return oOOO00o
  if 27 - 27: O0 % i1IIi * oO0o + i11iIiiIii + OoooooooOO * i1IIi
 def Get_Now_Datetime ( self ) :
  if 80 - 80: I11i * i11iIiiIii / O0oo0OO0
  return datetime . datetime . utcnow ( ) + datetime . timedelta ( hours = 9 )
  if 9 - 9: Ii1I + oO0o % Ii1I + i1IIi . OOooOOo
  if 31 - 31: o0oOOo0O0Ooo + I11i + I11i / II111iiii
  if 26 - 26: OoooooooOO
 def Get_ChangeText ( self , in_text ) :
  IiiI11Iiiii = in_text . replace ( '&lt;' , '<' ) . replace ( '&gt;' , '>' )
  IiiI11Iiiii = IiiI11Iiiii . replace ( '$O$' , '' )
  IiiI11Iiiii = re . sub ( '\n|\!|\~|(@0@)|(@\^0@)' , '' , IiiI11Iiiii )
  IiiI11Iiiii = IiiI11Iiiii . lstrip ( '#' )
  return IiiI11Iiiii
  if 18 - 18: o0oOOo0O0Ooo
  if 28 - 28: OOooOOo - O00oOoOoO0o0O . O00oOoOoO0o0O + OoOoOO00 - OoooooooOO + O0
 def GetCredential ( self , user_id , user_pw , user_pf ) :
  oOoOooOo0o0 = False
  try :
   OOOO = self . API_DOMAIN + '/login'
   if 87 - 87: oO0o / I11i - i1IIi * OOooOOo / OoooooooOO . O0
   O0OoOoo00o = self . GetDefaultParams ( )
   iii11I111 = { 'id' : user_id
 , 'password' : user_pw
 , 'profile' : '0'
 , 'pushid' : ''
 , 'type' : 'general'
 }
   if 63 - 63: OoO0O00 * oO0o - iii1I1I * O0
   iIii111IIi = self . callRequestCookies ( 'Post' , OOOO , payload = iii11I111 , params = O0OoOoo00o , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 58 - 58: OOooOOo * i11iIiiIii / OoOoOO00 % O0oo0OO0 - I1ii11iIi11i / oO0o
   ii11i1 = iii11 [ 'credential' ]
   if 29 - 29: I1ii11iIi11i % I1IiiI + Oo0ooO0oo0oO / o0oOOo0O0Ooo + OOooOOo * o0oOOo0O0Ooo
   if 42 - 42: Ii1I + oO0o
   if user_pf != 0 :
    iii11I111 = { 'id' : ii11i1
 , 'password' : ''
 , 'profile' : str ( user_pf )
 , 'pushid' : ''
 , 'type' : 'credential'
 }
    if 76 - 76: O0oo0OO0 - OoO0O00
    O0OoOoo00o [ 'credential' ] = ii11i1
    iIii111IIi = self . callRequestCookies ( 'Post' , OOOO , payload = iii11I111 , params = O0OoOoo00o , headers = None , cookies = None )
    iii11 = json . loads ( iIii111IIi . text )
    if 70 - 70: Oo0ooO0oo0oO
    ii11i1 = iii11 [ 'credential' ]
    if 61 - 61: I1ii11iIi11i . I1ii11iIi11i
   if ii11i1 : oOoOooOo0o0 = True
   if 10 - 10: OoOoOO00 * iii1I1I . I11i + II111iiii - Oo0ooO0oo0oO * i1IIi
   if 56 - 56: o0oOOo0O0Ooo * O00oOoOoO0o0O * II111iiii
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   ii11i1 = 'none'
   if 46 - 46: OOooOOo / I1ii11iIi11i
  self . SaveCredential ( ii11i1 )
  return oOoOooOo0o0
  if 24 - 24: I11i . iii1I1I % OOooOOo + Oo0ooO0oo0oO % OoOoOO00
  if 4 - 4: O00oOoOoO0o0O - OoO0O00 * OoOoOO00 - I11i
  if 41 - 41: OoOoOO00 . I1IiiI * oO0o % O00oOoOoO0o0O
 def GetIssue ( self ) :
  Oo000o = False
  try :
   OOOO = self . API_DOMAIN + '/guid/issue'
   O0OoOoo00o = self . GetDefaultParams ( )
   if 7 - 7: Oo0ooO0oo0oO * OoO0O00 % oO0o . O00oOoOoO0o0O
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 45 - 45: i11iIiiIii * II111iiii % iIii1I11I1II1 + I1ii11iIi11i - Ii1I
   iIi1iIiii111 = iii11 [ 'guid' ]
   iIIIi1 = iii11 [ 'guidtimestamp' ]
   if iIi1iIiii111 : Oo000o = True
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   iIi1iIiii111 = 'none'
   iIIIi1 = 'none'
   if 20 - 20: i1IIi + I1ii11iIi11i - Oo0ooO0oo0oO
  self . guid = iIi1iIiii111
  self . guidtimestamp = iIIIi1
  if 30 - 30: II111iiii - OOooOOo - i11iIiiIii % OoOoOO00 - II111iiii * Ii1I
  return Oo000o
  if 61 - 61: oO0o - I11i % OOooOOo
  if 84 - 84: oO0o * OoO0O00 / I11i - O0
  if 30 - 30: iIii1I11I1II1 / Oo0ooO0oo0oO - O0oo0OO0 - II111iiii % iii1I1I
 def Baseapi_Parse ( self , baseapi ) :
  try :
   IIi1i11111 = urlparse . urlsplit ( baseapi )
   if 81 - 81: i11iIiiIii % OoOoOO00 - OOooOOo
   if IIi1i11111 . netloc == '' :
    OOOO = self . HTTPTAG + IIi1i11111 . netloc + IIi1i11111 . path
   else :
    OOOO = IIi1i11111 . scheme + '://' + IIi1i11111 . netloc + IIi1i11111 . path
    if 68 - 68: O0oo0OO0 % i1IIi . O00oOoOoO0o0O . I1ii11iIi11i
   O0OoOoo00o = dict ( urlparse . parse_qsl ( IIi1i11111 . query ) )
   if 92 - 92: iii1I1I . O0oo0OO0
  except :
   print ( exception )
   return '' , { }
   if 31 - 31: O0oo0OO0 . OoOoOO00 / O0
  return OOOO , O0OoOoo00o
  if 89 - 89: OoOoOO00
  if 68 - 68: OoO0O00 * OoooooooOO % O0 + OoO0O00 + Oo0ooO0oo0oO
  if 4 - 4: Oo0ooO0oo0oO + O0 * OOooOOo
  if 55 - 55: Oo0Ooo + iIii1I11I1II1 / OoOoOO00 * oO0o - i11iIiiIii - Ii1I
 def GetSupermultiUrl ( self , sCode , sIndex = '0' ) :
  try :
   OOOO = self . API_DOMAIN + '/cf/supermultisections/' + sCode
   O0OoOoo00o = self . GetDefaultParams ( login = False )
   if 25 - 25: I1ii11iIi11i
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 7 - 7: i1IIi / I1IiiI * O0oo0OO0 . O00oOoOoO0o0O . iIii1I11I1II1
   iIii = iii11 [ 'multisectionlist' ] [ int ( sIndex ) ] [ 'eventlist' ] [ 1 ] [ 'url' ]
   if 79 - 79: OoooooooOO / O0
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return ''
   if 75 - 75: OoOoOO00 % o0oOOo0O0Ooo % o0oOOo0O0Ooo . O0oo0OO0
  return iIii
  if 5 - 5: o0oOOo0O0Ooo * Oo0ooO0oo0oO + OoOoOO00 . OOooOOo + OoOoOO00
  if 91 - 91: O0
 def Get_LiveCatagory_List ( self , sCode , sIndex = '0' ) :
  oOOo0 = [ ]
  if 54 - 54: O0 - O00oOoOoO0o0O % OOooOOo
  if 77 - 77: OoOoOO00 / I1IiiI / OoO0O00 + OoO0O00 . OOooOOo
  ii1ii11IIIiiI = self . GetSupermultiUrl ( sCode , sIndex )
  ( OOOO , O0OoOoo00o ) = self . Baseapi_Parse ( ii1ii11IIIiiI )
  if OOOO == '' : return oOOo0 , ''
  if 67 - 67: I11i * oO0o * I1ii11iIi11i + OOooOOo / i1IIi
  if 11 - 11: Ii1I + iii1I1I - Oo0ooO0oo0oO * oO0o % i11iIiiIii - O0oo0OO0
  try :
   if 83 - 83: I11i / I1IiiI
   O0OoOoo00o . update ( self . GetDefaultParams ( login = False ) )
   if 34 - 34: O00oOoOoO0o0O
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 57 - 57: oO0o . I11i . i1IIi
   if 42 - 42: I11i + I1ii11iIi11i % O0
   if not ( 'filter_item_list' in iii11 [ 'filter' ] [ 'filterlist' ] [ 0 ] ) : return [ ] , ''
   i1iIIIi1i = iii11 [ 'filter' ] [ 'filterlist' ] [ 0 ] [ 'filter_item_list' ]
   if 43 - 43: OoOoOO00 % OOooOOo
   for iiiiiiii1 in i1iIIIi1i :
    iI11i1ii11 = { 'title' : iiiiiiii1 [ 'title' ]
 , 'genre' : iiiiiiii1 [ 'api_parameters' ] [ iiiiiiii1 [ 'api_parameters' ] . index ( '=' ) + 1 : ]
 }
    if 58 - 58: OoO0O00 % i11iIiiIii . iii1I1I / oO0o
    oOOo0 . append ( iI11i1ii11 )
    if 84 - 84: iii1I1I . I1ii11iIi11i / Oo0Ooo - I1IiiI / OoooooooOO / o0oOOo0O0Ooo
    if 12 - 12: I1IiiI * iii1I1I % i1IIi % iIii1I11I1II1
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return [ ] , ''
   if 20 - 20: OOooOOo % Ii1I / Ii1I + Ii1I
  return oOOo0 , ii1ii11IIIiiI
  if 45 - 45: oO0o - O00oOoOoO0o0O - OoooooooOO - OoO0O00 . II111iiii / O0
  if 51 - 51: O0 + iii1I1I
  if 8 - 8: oO0o * OoOoOO00 - Ii1I - OoO0O00 * OOooOOo % I1IiiI
 def Get_MainCatagory_List ( self , sCode , sIndex = '0' ) :
  oOOo0 = [ ]
  if 48 - 48: O0
  if 11 - 11: I11i + OoooooooOO - OoO0O00 / o0oOOo0O0Ooo + Oo0Ooo . II111iiii
  ii1ii11IIIiiI = self . GetSupermultiUrl ( sCode , sIndex )
  ( OOOO , O0OoOoo00o ) = self . Baseapi_Parse ( ii1ii11IIIiiI )
  if OOOO == '' : return oOOo0
  if 41 - 41: Ii1I - O0 - O0
  if 68 - 68: OOooOOo % O0oo0OO0
  try :
   if 88 - 88: iIii1I11I1II1 - Oo0ooO0oo0oO + OOooOOo
   O0OoOoo00o . update ( self . GetDefaultParams ( login = False ) )
   if 40 - 40: I1IiiI * Ii1I + OOooOOo % iii1I1I
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 74 - 74: oO0o - Oo0Ooo + OoooooooOO + O0oo0OO0 / OoOoOO00
   if 23 - 23: O0
   if not ( 'celllist' in iii11 [ 'band' ] ) : return [ ]
   i1iIIIi1i = iii11 [ 'band' ] [ 'celllist' ]
   if 85 - 85: Ii1I
   for iiiiiiii1 in i1iIIIi1i :
    OO = iiiiiiii1 [ 'event_list' ] [ 1 ] [ 'url' ]
    ( oo000o , iiIi1IIi1I ) = self . Baseapi_Parse ( OO )
    if 84 - 84: Oo0ooO0oo0oO * II111iiii + Oo0Ooo
    iI11i1ii11 = { 'title' : iiiiiiii1 [ 'title_list' ] [ 0 ] [ 'text' ]
 , 'suburl' : oo000o
 , 'subapi' : iiIi1IIi1I . get ( 'api' )
 , 'subtype' : 'catagory' if iiIi1IIi1I else 'supersection'
 }
    if 53 - 53: iii1I1I % II111iiii . O00oOoOoO0o0O - iIii1I11I1II1 - O00oOoOoO0o0O * II111iiii
    oOOo0 . append ( iI11i1ii11 )
    if 77 - 77: iIii1I11I1II1 * OoO0O00
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return [ ]
   if 95 - 95: I1IiiI + i11iIiiIii
  return oOOo0
  if 6 - 6: Oo0ooO0oo0oO / i11iIiiIii + iii1I1I * oO0o
  if 80 - 80: II111iiii
 def Get_SuperMultiSection_List ( self , subapi_text ) :
  oOOo0 = [ ]
  if 83 - 83: I11i . i11iIiiIii + II111iiii . o0oOOo0O0Ooo * I11i
  if 53 - 53: II111iiii
  try :
   IIi1i11111 = urlparse . urlsplit ( subapi_text )
   OOOO = self . API_DOMAIN + '/cf' + IIi1i11111 . path
   OOOO = OOOO . replace ( 'supermultisection/' , 'supermultisections/' )
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return [ ]
   if 31 - 31: OoO0O00
   if 80 - 80: O0oo0OO0 . i11iIiiIii - o0oOOo0O0Ooo
   if 25 - 25: OoO0O00
  try :
   if 62 - 62: OOooOOo + O0
   O0OoOoo00o = self . GetDefaultParams ( login = False )
   if 98 - 98: o0oOOo0O0Ooo
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = None , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 51 - 51: Oo0Ooo - oO0o + II111iiii * Ii1I . I11i + oO0o
   if not ( 'multisectionlist' in iii11 ) : return [ ]
   i1iIIIi1i = iii11 [ 'multisectionlist' ]
   if 78 - 78: i11iIiiIii / iii1I1I - Ii1I / OOooOOo + oO0o
   for iiiiiiii1 in i1iIIIi1i :
    if 82 - 82: Ii1I
    ii = iiiiiiii1 [ 'title' ]
    if len ( ii ) == 0 : continue
    if ii == 'minor' : continue
    if re . search ( u'베너' , ii ) : continue
    if 5 - 5: Oo0ooO0oo0oO - II111iiii - OoooooooOO % Ii1I + I1IiiI * iIii1I11I1II1
    iiIi1IIi1I = iiiiiiii1 [ 'eventlist' ] [ 2 ] [ 'url' ]
    I1I1II1I11 = iiiiiiii1 [ 'cell_type' ]
    if I1I1II1I11 == 'band_2' :
     if iiIi1IIi1I . find ( 'channellist=' ) >= 0 :
      I1I1II1I11 = 'band_live'
      if 8 - 8: o0oOOo0O0Ooo % O0 / I1IiiI - oO0o
    iI11i1ii11 = { 'title' : self . Get_ChangeText ( ii )
 , 'subapi' : iiIi1IIi1I
 , 'cell_type' : I1I1II1I11
 }
    if 43 - 43: i11iIiiIii + Oo0Ooo * II111iiii * O0oo0OO0 * O0
    oOOo0 . append ( iI11i1ii11 )
    if 64 - 64: OOooOOo % iIii1I11I1II1 * oO0o
   print ( oOOo0 )
   if 79 - 79: O0
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return [ ]
   if 78 - 78: I1ii11iIi11i + OOooOOo - O0oo0OO0
  return oOOo0
  if 38 - 38: o0oOOo0O0Ooo - oO0o + iIii1I11I1II1 / OoOoOO00 % Oo0Ooo
  if 57 - 57: OoO0O00 / Oo0ooO0oo0oO
 def Get_BandLiveSection_List ( self , baseapi , page_int = 1 ) :
  Ii1I1Ii = [ ]
  OOoO0 = OO0Oooo0oOO0O = 1
  o00O0 = False
  if 83 - 83: Oo0ooO0oo0oO
  if 65 - 65: I1IiiI % Ii1I * oO0o
  try :
   ( OOOO , O0OoOoo00o ) = self . Baseapi_Parse ( baseapi )
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return [ ] , False
   if 19 - 19: O0oo0OO0 + iIii1I11I1II1 . OoooooooOO . I11i / O0oo0OO0 + O00oOoOoO0o0O
   if 85 - 85: I1ii11iIi11i - iIii1I11I1II1
  try :
   O0OoOoo00o [ 'limit' ] = self . LIST_LIMIT
   O0OoOoo00o [ 'offset' ] = str ( ( page_int - 1 ) * self . LIST_LIMIT )
   if 31 - 31: OoooooooOO - OoooooooOO * I11i - oO0o
   if 85 - 85: i11iIiiIii % oO0o . OOooOOo - Ii1I
   O0OoOoo00o . update ( self . GetDefaultParams ( login = False ) )
   if 42 - 42: oO0o + Oo0ooO0oo0oO / iii1I1I + OOooOOo
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 30 - 30: O0
   if not ( 'celllist' in iii11 [ 'cell_toplist' ] ) : return [ ] , False
   i1iIIIi1i = iii11 [ 'cell_toplist' ] [ 'celllist' ]
   if 44 - 44: oO0o / I11i / I11i
   for iiiiiiii1 in i1iIIIi1i :
    OOO = iiiiiiii1 [ 'event_list' ] [ 1 ] [ 'url' ]
    iiiiI = urlparse . urlsplit ( OOO ) . query
    iiiiI = dict ( urlparse . parse_qsl ( iiiiI ) )
    oooOo0OOOoo0 = 'channelid'
    OOoO = iiiiI [ oooOo0OOOoo0 ]
    if 89 - 89: o0oOOo0O0Ooo + OoO0O00 * I11i * Ii1I
    iI11i1ii11 = { 'studio' : iiiiiiii1 [ 'title_list' ] [ 0 ] [ 'text' ]
    , 'tvshowtitle' : self . Get_ChangeText ( iiiiiiii1 [ 'title_list' ] [ 1 ] [ 'text' ] )
 , 'channelid' : OOoO
 , 'age' : iiiiiiii1 . get ( 'age' )
 , 'thumbnail' : 'https://%s' % iiiiiiii1 . get ( 'thumbnail' )

    }
    if 37 - 37: OoooooooOO - O0 - o0oOOo0O0Ooo
    Ii1I1Ii . append ( iI11i1ii11 )
    if 77 - 77: OOooOOo * iIii1I11I1II1
   OOoO0 = int ( iii11 [ 'cell_toplist' ] [ 'pagecount' ] )
   if iii11 [ 'cell_toplist' ] [ 'count' ] : OO0Oooo0oOO0O = int ( iii11 [ 'cell_toplist' ] [ 'count' ] )
   else : OO0Oooo0oOO0O = self . LIST_LIMIT * page_int
   if 98 - 98: I1IiiI % Ii1I * OoooooooOO
   o00O0 = OOoO0 > OO0Oooo0oOO0O
   if 51 - 51: iIii1I11I1II1 . OoOoOO00 / oO0o + o0oOOo0O0Ooo
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return [ ] , False
   if 33 - 33: Oo0ooO0oo0oO . II111iiii % iii1I1I + o0oOOo0O0Ooo
  return Ii1I1Ii , o00O0
  if 71 - 71: Oo0Ooo % OOooOOo
  if 98 - 98: I11i % i11iIiiIii % Oo0ooO0oo0oO + Ii1I
 def Get_Band2Section_List ( self , baseapi , page_int = 1 ) :
  OOoOO0o0o0 = [ ]
  OOoO0 = OO0Oooo0oOO0O = 1
  o00O0 = False
  if 11 - 11: I1IiiI
  if 16 - 16: Ii1I + O00oOoOoO0o0O * O0 % i1IIi . I1IiiI
  try :
   ( OOOO , O0OoOoo00o ) = self . Baseapi_Parse ( baseapi )
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return [ ] , False
   if 67 - 67: OoooooooOO / I1IiiI * Ii1I + I11i
   if 65 - 65: OoooooooOO - I1ii11iIi11i / Oo0ooO0oo0oO / II111iiii / i1IIi
  try :
   O0OoOoo00o [ 'came' ] = 'BandView'
   O0OoOoo00o [ 'limit' ] = self . LIST_LIMIT
   O0OoOoo00o [ 'offset' ] = str ( ( page_int - 1 ) * self . LIST_LIMIT )
   if 71 - 71: O0oo0OO0 + Ii1I
   if 28 - 28: OOooOOo
   O0OoOoo00o . update ( self . GetDefaultParams ( login = False ) )
   if 38 - 38: Oo0ooO0oo0oO % II111iiii % I11i / OoO0O00 + OoOoOO00 / i1IIi
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 54 - 54: iIii1I11I1II1 % I1ii11iIi11i - OOooOOo / oO0o - OoO0O00 . I11i
   if not ( 'celllist' in iii11 [ 'cell_toplist' ] ) : return [ ] , False
   i1iIIIi1i = iii11 [ 'cell_toplist' ] [ 'celllist' ]
   if 11 - 11: I1ii11iIi11i . OoO0O00 * O00oOoOoO0o0O * OoooooooOO + Oo0ooO0oo0oO
   for iiiiiiii1 in i1iIIIi1i :
    OOO = iiiiiiii1 [ 'event_list' ] [ 1 ] [ 'url' ]
    iiiiI = urlparse . urlsplit ( OOO ) . query
    iiiiI = dict ( urlparse . parse_qsl ( iiiiI ) )
    oooOo0OOOoo0 = 'contentid'
    OOoO = iiiiI [ oooOo0OOOoo0 ]
    if 33 - 33: O0 * o0oOOo0O0Ooo - O0oo0OO0 % O0oo0OO0
    iI11i1ii11 = { 'programtitle' : iiiiiiii1 [ 'title_list' ] [ 0 ] [ 'text' ]
 , 'episodetitle' : self . Get_ChangeText ( iiiiiiii1 [ 'title_list' ] [ 1 ] [ 'text' ] )
 , 'age' : iiiiiiii1 . get ( 'age' )
 , 'thumbnail' : self . HTTPTAG + iiiiiiii1 . get ( 'thumbnail' )

    # OoooooooOO * O0oo0OO0
    , 'vidtype' : oooOo0OOOoo0
 , 'videoid' : OOoO
 }
    if 100 - 100: O0oo0OO0 + O0oo0OO0 * O00oOoOoO0o0O
    OOoOO0o0o0 . append ( iI11i1ii11 )
    if 1 - 1: Oo0ooO0oo0oO . Oo0ooO0oo0oO / OoOoOO00 - O0oo0OO0
   OOoO0 = int ( iii11 [ 'cell_toplist' ] [ 'pagecount' ] )
   if iii11 [ 'cell_toplist' ] [ 'count' ] : OO0Oooo0oOO0O = int ( iii11 [ 'cell_toplist' ] [ 'count' ] )
   else : OO0Oooo0oOO0O = self . LIST_LIMIT * page_int
   if 86 - 86: iIii1I11I1II1 / OoOoOO00 . II111iiii
   o00O0 = OOoO0 > OO0Oooo0oOO0O
   if 19 - 19: I1ii11iIi11i % OoooooooOO % O00oOoOoO0o0O * o0oOOo0O0Ooo % O0
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return [ ] , False
   if 67 - 67: I1IiiI . i1IIi
  return OOoOO0o0o0 , o00O0
  if 27 - 27: Oo0ooO0oo0oO % I1IiiI
  if 73 - 73: OOooOOo
 def Get_Program_List ( self , baseapi , page_int = 1 , orderby = '-' ) :
  ooO = [ ]
  OOoO0 = OO0Oooo0oOO0O = 1
  o00O0 = False
  if 51 - 51: I1IiiI % O0oo0OO0 . oO0o / iIii1I11I1II1 / I11i . oO0o
  ( OOOO , O0OoOoo00o ) = self . Baseapi_Parse ( baseapi )
  if OOOO == '' : return ooO , o00O0
  if 42 - 42: o0oOOo0O0Ooo + i1IIi - Ii1I / O00oOoOoO0o0O
  try :
   O0OoOoo00o [ 'limit' ] = self . LIST_LIMIT
   O0OoOoo00o [ 'offset' ] = str ( ( page_int - 1 ) * self . LIST_LIMIT )
   O0OoOoo00o [ 'page' ] = str ( page_int )
   if O0OoOoo00o . get ( 'orderby' ) != '' and O0OoOoo00o . get ( 'orderby' ) != 'regdatefirst' and orderby != '-' :
    O0OoOoo00o [ 'orderby' ] = orderby
    if 9 - 9: O0 % O0 - o0oOOo0O0Ooo
   O0OoOoo00o . update ( self . GetDefaultParams ( login = False ) )
   if 51 - 51: I1IiiI . iIii1I11I1II1 - I1ii11iIi11i / O0
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 52 - 52: o0oOOo0O0Ooo + O0 + iii1I1I + Oo0Ooo % iii1I1I
   if 75 - 75: I1IiiI . Oo0ooO0oo0oO . O0 * O0oo0OO0
   if not ( 'celllist' in iii11 [ 'cell_toplist' ] ) : return ooO , o00O0
   i1iIIIi1i = iii11 [ 'cell_toplist' ] [ 'celllist' ]
   if 4 - 4: Ii1I % oO0o * OoO0O00
   for iiiiiiii1 in i1iIIIi1i :
    OOO = iiiiiiii1 [ 'event_list' ] [ 1 ] [ 'url' ]
    iiiiI = urlparse . urlsplit ( OOO ) . query
    oooOo0OOOoo0 = iiiiI [ 0 : iiiiI . find ( '=' ) ]
    OOoO = iiiiI [ iiiiI . find ( '=' ) + 1 : ]
    if 100 - 100: O0oo0OO0 * OOooOOo + OOooOOo
    iI11i1ii11 = { 'title' : iiiiiiii1 [ 'title_list' ] [ 0 ] [ 'text' ]
 , 'age' : iiiiiiii1 [ 'age' ]
 , 'thumbnail' : 'https://%s' % iiiiiiii1 . get ( 'thumbnail' )
 , 'videoid' : OOoO
    , 'vidtype' : oooOo0OOOoo0
    }
    if 54 - 54: OoooooooOO + o0oOOo0O0Ooo - i1IIi % i11iIiiIii
    ooO . append ( iI11i1ii11 )
    if 3 - 3: o0oOOo0O0Ooo % o0oOOo0O0Ooo
   OOoO0 = int ( iii11 [ 'cell_toplist' ] [ 'pagecount' ] )
   if iii11 [ 'cell_toplist' ] [ 'count' ] : OO0Oooo0oOO0O = int ( iii11 [ 'cell_toplist' ] [ 'count' ] )
   else : OO0Oooo0oOO0O = self . LIST_LIMIT * page_int
   if 83 - 83: II111iiii + O0oo0OO0
   o00O0 = OOoO0 > OO0Oooo0oOO0O
   if 73 - 73: iii1I1I
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return [ ] , False
   if 42 - 42: i11iIiiIii * iIii1I11I1II1 / I1ii11iIi11i . i11iIiiIii % I11i
  return ooO , o00O0
  if 41 - 41: O00oOoOoO0o0O / O0
  if 51 - 51: I11i % I1IiiI
 def Get_Movie_List ( self , baseapi , page_int = 1 ) :
  OooOo = [ ]
  OOoO0 = OO0Oooo0oOO0O = 1
  o00O0 = False
  if 31 - 31: O0oo0OO0
  ( OOOO , O0OoOoo00o ) = self . Baseapi_Parse ( baseapi )
  if OOOO == '' : return OooOo , o00O0
  if 88 - 88: OoO0O00 - Oo0ooO0oo0oO + OOooOOo * I1IiiI % iIii1I11I1II1 + Oo0Ooo
  try :
   O0OoOoo00o [ 'limit' ] = self . MV_LIMIT
   O0OoOoo00o [ 'offset' ] = str ( ( page_int - 1 ) * self . MV_LIMIT )
   if 76 - 76: I1IiiI * iii1I1I % O0oo0OO0
   if 57 - 57: iIii1I11I1II1 - i1IIi / O0oo0OO0 - O0 * OoooooooOO % II111iiii
   O0OoOoo00o . update ( self . GetDefaultParams ( login = False ) )
   if 68 - 68: OoooooooOO * I11i % OoOoOO00 - O00oOoOoO0o0O
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 34 - 34: O0oo0OO0 . iIii1I11I1II1 * OoOoOO00 * oO0o / O0oo0OO0 / I1ii11iIi11i
   if not ( 'celllist' in iii11 [ 'cell_toplist' ] ) : return OooOo , o00O0
   i1iIIIi1i = iii11 [ 'cell_toplist' ] [ 'celllist' ]
   if 78 - 78: Oo0Ooo - o0oOOo0O0Ooo / OoOoOO00
   for iiiiiiii1 in i1iIIIi1i :
    OOO = iiiiiiii1 [ 'event_list' ] [ 1 ] [ 'url' ]
    iiiiI = urlparse . urlsplit ( OOO ) . query
    oooOo0OOOoo0 = iiiiI [ 0 : iiiiI . find ( '=' ) ]
    OOoO = iiiiI [ iiiiI . find ( '=' ) + 1 : ]
    if 10 - 10: iii1I1I + Oo0Ooo * I1ii11iIi11i + iIii1I11I1II1 / O0oo0OO0 / I1ii11iIi11i
    iI11i1ii11 = { 'title' : iiiiiiii1 [ 'title_list' ] [ 0 ] [ 'text' ]
 , 'age' : iiiiiiii1 [ 'age' ]
 , 'thumbnail' : 'https://%s' % iiiiiiii1 . get ( 'thumbnail' )
 , 'videoid' : OOoO
 , 'vidtype' : oooOo0OOOoo0
    }
    if 42 - 42: I1IiiI
    OooOo . append ( iI11i1ii11 )
    if 38 - 38: OOooOOo + II111iiii % Oo0ooO0oo0oO % OoOoOO00 - Ii1I / OoooooooOO
   OOoO0 = int ( iii11 [ 'cell_toplist' ] [ 'pagecount' ] )
   if iii11 [ 'cell_toplist' ] [ 'count' ] : OO0Oooo0oOO0O = int ( iii11 [ 'cell_toplist' ] [ 'count' ] )
   else : OO0Oooo0oOO0O = self . MV_LIMIT * page_int
   if 73 - 73: o0oOOo0O0Ooo * O0 - i11iIiiIii
   o00O0 = OOoO0 > OO0Oooo0oOO0O
   if 85 - 85: Ii1I % iii1I1I + I11i / o0oOOo0O0Ooo . oO0o + OOooOOo
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return [ ] , False
   if 62 - 62: i11iIiiIii + i11iIiiIii - o0oOOo0O0Ooo
  return OooOo , o00O0
  if 28 - 28: iii1I1I . iii1I1I % iIii1I11I1II1 * iIii1I11I1II1 . o0oOOo0O0Ooo / iii1I1I
  if 27 - 27: OoO0O00 + Oo0ooO0oo0oO - i1IIi
 def ChangeToProgramid ( self , contentid ) :
  O00oOOooo = ''
  if 50 - 50: I1ii11iIi11i % O0 * o0oOOo0O0Ooo
  try :
   OOOO = self . API_DOMAIN + '/cf/vod/contents/' + contentid
   O0OoOoo00o = self . GetDefaultParams ( login = False )
   if 5 - 5: O00oOoOoO0o0O * OoOoOO00
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   i1Ii1i1I11Iii = json . loads ( iIii111IIi . text )
   if 25 - 25: O00oOoOoO0o0O + Ii1I / Oo0ooO0oo0oO . o0oOOo0O0Ooo % O0 * OoO0O00
   if not ( 'programid' in i1Ii1i1I11Iii ) : return O00oOOooo
   O00oOOooo = i1Ii1i1I11Iii [ 'programid' ]
   if 84 - 84: Oo0ooO0oo0oO % Ii1I + i11iIiiIii
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   if 28 - 28: Oo0Ooo + OoO0O00 * OOooOOo % oO0o . I11i % O0
  return O00oOOooo
  if 16 - 16: I11i - iIii1I11I1II1 / I1IiiI . II111iiii + iIii1I11I1II1
  if 19 - 19: OoO0O00 - Oo0Ooo . O0
 def Get_Episode_List ( self , videoid , vidtype , page_int = 1 , orderby = 'desc' ) :
  ooOo00 = [ ]
  OOoO0 = OO0Oooo0oOO0O = 1
  o00O0 = False
  if 98 - 98: Oo0Ooo / I1IiiI . O0 + OoO0O00
  if vidtype == 'contentid' :
   O00oOOooo = self . ChangeToProgramid ( videoid )
  else :
   O00oOOooo = videoid
   if 43 - 43: II111iiii . oO0o / I1ii11iIi11i
  if orderby == 'desc' :
   orderby = 'new'
  else :
   orderby = 'old'
   if 20 - 20: I1IiiI
  try :
   OOOO = self . API_DOMAIN + '/vod/programs-contents/' + O00oOOooo
   if 95 - 95: iii1I1I - I1IiiI
   O0OoOoo00o = { }
   O0OoOoo00o [ 'limit' ] = self . EP_LIMIT
   O0OoOoo00o [ 'offset' ] = str ( ( page_int - 1 ) * self . EP_LIMIT )
   if 34 - 34: Oo0ooO0oo0oO * I1IiiI . i1IIi * Oo0ooO0oo0oO / Oo0ooO0oo0oO
   O0OoOoo00o [ 'orderby' ] = orderby
   if 30 - 30: I1ii11iIi11i + Oo0Ooo / Oo0Ooo % I1ii11iIi11i . I1ii11iIi11i
   if 55 - 55: Oo0ooO0oo0oO - I11i + II111iiii + iii1I1I % Ii1I
   O0OoOoo00o . update ( self . GetDefaultParams ( login = False ) )
   if 41 - 41: i1IIi - I11i - Ii1I
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 8 - 8: OoO0O00 + O0oo0OO0 - o0oOOo0O0Ooo % Oo0Ooo % o0oOOo0O0Ooo * oO0o
   i1iIIIi1i = iii11 [ 'list' ]
   if 9 - 9: Oo0Ooo - i11iIiiIii - OOooOOo * Ii1I + Oo0ooO0oo0oO
   for iiiiiiii1 in i1iIIIi1i :
    if 44 - 44: II111iiii
    OOOO0OOO = re . sub ( u'(\<[a-zA-Z]{1,2}\>)|(\<\/[a-zA-Z]{1,2}\>)' , '' , iiiiiiii1 . get ( 'synopsis' ) )
    if 3 - 3: OoO0O00
    iI11i1ii11 = { 'programtitle' : iiiiiiii1 . get ( 'programtitle' )
 , 'episodetitle' : iiiiiiii1 . get ( 'episodetitle' )
 , 'episodenumber' : iiiiiiii1 . get ( 'episodenumber' )
 , 'releasedate' : iiiiiiii1 . get ( 'releasedate' )
 , 'releaseweekday' : iiiiiiii1 . get ( 'releaseweekday' )
 , 'programid' : iiiiiiii1 . get ( 'programid' )
 , 'contentid' : iiiiiiii1 . get ( 'contentid' )
 , 'age' : iiiiiiii1 . get ( 'targetage' )
 , 'playtime' : iiiiiiii1 . get ( 'playtime' )
 , 'synopsis' : OOOO0OOO
 , 'episodeactors' : iiiiiiii1 . get ( 'episodeactors' ) . split ( ',' )
 , 'thumbnail' : self . HTTPTAG + iiiiiiii1 . get ( 'image' )
 }
    if 97 - 97: O0oo0OO0
    ooOo00 . append ( iI11i1ii11 )
    if 15 - 15: i1IIi + OoOoOO00
   OOoO0 = int ( iii11 [ 'pagecount' ] )
   if iii11 [ 'count' ] : OO0Oooo0oOO0O = int ( iii11 [ 'count' ] )
   else : OO0Oooo0oOO0O = self . EP_LIMIT * page_int
   if 48 - 48: I1IiiI % iii1I1I / iIii1I11I1II1
   o00O0 = OOoO0 > OO0Oooo0oOO0O
   if 85 - 85: OoooooooOO % i1IIi * OoooooooOO / I1ii11iIi11i
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return [ ] , False
   if 96 - 96: OoooooooOO + oO0o
  return ooOo00 , o00O0
  if 44 - 44: oO0o
  if 20 - 20: I11i + Ii1I / O0 % iIii1I11I1II1
 def GetEPGList ( self , genre ) :
  oOo0O = { }
  if 64 - 64: I1ii11iIi11i - iii1I1I + iii1I1I - I11i
  try :
   Iii = self . Get_Now_Datetime ( )
   if genre == 'all' :
    iIIiIiI1I1 = Iii + datetime . timedelta ( hours = 3 )
   else :
    iIIiIiI1I1 = Iii + datetime . timedelta ( hours = 3 )
    if 56 - 56: I1IiiI . O0 + Oo0Ooo
   OOOO = self . API_DOMAIN + '/live/epgs'
   O0OoOoo00o = { 'limit' : '100'
 , 'offset' : '0'
 , 'genre' : genre
 , 'startdatetime' : Iii . strftime ( '%Y-%m-%d %H:00' )
 , 'enddatetime' : iIIiIiI1I1 . strftime ( '%Y-%m-%d %H:00' )
 }
   O0OoOoo00o . update ( self . GetDefaultParams ( login = False ) )
   if 1 - 1: iii1I1I
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 97 - 97: OOooOOo + iii1I1I + O0 + i11iIiiIii
   oOoO0 = iii11 [ 'list' ]
   if 77 - 77: iIii1I11I1II1 . iii1I1I % iii1I1I + i11iIiiIii
   for iiiiiiii1 in oOoO0 :
    Oo00o0OO0O00o = ''
    if 82 - 82: I11i + OoooooooOO - i1IIi . i1IIi
    for iIi1i in iiiiiiii1 [ 'list' ] :
     if Oo00o0OO0O00o : Oo00o0OO0O00o += '\n'
     Oo00o0OO0O00o += self . Get_ChangeText ( iIi1i [ 'title' ] ) + '\n'
     Oo00o0OO0O00o += ' [%s ~ %s]' % ( iIi1i [ 'starttime' ] [ - 5 : ] , iIi1i [ 'endtime' ] [ - 5 : ] ) + '\n'
     if 27 - 27: OOooOOo * Oo0ooO0oo0oO . O0oo0OO0 % O00oOoOoO0o0O * O00oOoOoO0o0O . i1IIi
    oOo0O [ iiiiiiii1 [ 'channelid' ] ] = Oo00o0OO0O00o
    if 72 - 72: OOooOOo % I1ii11iIi11i + OoO0O00 / oO0o + O00oOoOoO0o0O
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   if 10 - 10: O0oo0OO0 / Oo0ooO0oo0oO + i11iIiiIii / Ii1I
  return oOo0O
  if 74 - 74: OOooOOo + O0 + i1IIi - i1IIi + II111iiii
  if 83 - 83: I1ii11iIi11i - I1IiiI + OOooOOo
  if 5 - 5: Ii1I
 def Get_LiveChannel_List ( self , genre , baseapi ) :
  Ii1I1Ii = [ ]
  if 46 - 46: O00oOoOoO0o0O
  ( OOOO , O0OoOoo00o ) = self . Baseapi_Parse ( baseapi )
  if OOOO == '' : return Ii1I1Ii
  if 45 - 45: Oo0ooO0oo0oO
  if 21 - 21: oO0o . O0oo0OO0 . OOooOOo / Oo0Ooo / O0oo0OO0
  i1iI1 = self . GetEPGList ( genre )
  if 1 - 1: i1IIi . i11iIiiIii % OOooOOo
  try :
   if 82 - 82: iIii1I11I1II1 + Oo0Ooo . iIii1I11I1II1 % O00oOoOoO0o0O / Ii1I . Ii1I
   O0OoOoo00o . update ( self . GetDefaultParams ( login = False ) )
   O0OoOoo00o [ 'genre' ] = genre
   if 14 - 14: o0oOOo0O0Ooo . OOooOOo . I11i + OoooooooOO - OOooOOo + O00oOoOoO0o0O
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 9 - 9: Ii1I
   if not ( 'celllist' in iii11 [ 'cell_toplist' ] ) : return [ ]
   i1iIIIi1i = iii11 [ 'cell_toplist' ] [ 'celllist' ]
   if 59 - 59: I1IiiI * II111iiii . O0
   for iiiiiiii1 in i1iIIIi1i :
    if 56 - 56: Ii1I - iii1I1I % I1IiiI - o0oOOo0O0Ooo
    if 51 - 51: O0 / Oo0ooO0oo0oO * iIii1I11I1II1 + I1ii11iIi11i + o0oOOo0O0Ooo
    Oo0OO0000oooo = iiiiiiii1 [ 'contentid' ]
    if Oo0OO0000oooo in i1iI1 :
     IIII1iII = i1iI1 [ Oo0OO0000oooo ]
    else :
     IIII1iII = ''
     if 28 - 28: i1IIi - iii1I1I
    iI11i1ii11 = { 'studio' : iiiiiiii1 [ 'title_list' ] [ 0 ] [ 'text' ]
    , 'tvshowtitle' : self . Get_ChangeText ( iiiiiiii1 [ 'title_list' ] [ 1 ] [ 'text' ] )
 , 'channelid' : Oo0OO0000oooo
 , 'age' : iiiiiiii1 [ 'age' ]
 , 'thumbnail' : 'https://%s' % iiiiiiii1 . get ( 'thumbnail' )
 , 'epg' : IIII1iII
 }
    if 54 - 54: iii1I1I - O0 % OOooOOo
    Ii1I1Ii . append ( iI11i1ii11 )
    if 73 - 73: O0 . OoOoOO00 + I1IiiI - I11i % I11i . I11i
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return [ ]
   if 17 - 17: Ii1I - OoooooooOO % Ii1I . O00oOoOoO0o0O / i11iIiiIii % iii1I1I
  return Ii1I1Ii
  if 28 - 28: I11i
  if 58 - 58: OoOoOO00
 def Get_Search_List ( self , search_key , sType , page_int , exclusion21 = False ) :
  iIiiI1iI = [ ]
  OOoO0 = OO0Oooo0oOO0O = 1
  o00O0 = False
  if 5 - 5: OoOoOO00 / OoooooooOO + O00oOoOoO0o0O * O0oo0OO0 - OoO0O00 % I1IiiI
  try :
   OOOO = self . API_DOMAIN + '/cf/search/list.js'
   if 42 - 42: O0 / o0oOOo0O0Ooo + OoooooooOO * Oo0ooO0oo0oO % Oo0ooO0oo0oO
   O0OoOoo00o = { 'type' : 'program' if sType == 'vod' else 'movie'
 , 'keyword' : search_key
 , 'offset' : str ( ( page_int - 1 ) * self . LIST_LIMIT )
 , 'limit' : self . LIST_LIMIT
   , 'orderby' : 'score'
 }
   O0OoOoo00o . update ( self . GetDefaultParams ( login = False ) )
   if 7 - 7: iii1I1I / I1ii11iIi11i / i11iIiiIii
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   i1Ii1i1I11Iii = json . loads ( iIii111IIi . text )
   if 21 - 21: oO0o / I1ii11iIi11i + Ii1I + OoooooooOO
   if 91 - 91: i11iIiiIii / i1IIi + iii1I1I + Oo0ooO0oo0oO * i11iIiiIii
   if not ( 'celllist' in i1Ii1i1I11Iii [ 'cell_toplist' ] ) : return iIiiI1iI , o00O0
   i1iIIIi1i = i1Ii1i1I11Iii [ 'cell_toplist' ] [ 'celllist' ]
   if 66 - 66: iIii1I11I1II1 % i1IIi - O0 + I11i * O0oo0OO0 . O00oOoOoO0o0O
   if 52 - 52: Oo0ooO0oo0oO + O0 . iii1I1I . I1ii11iIi11i . OoO0O00
   for iiiiiiii1 in i1iIIIi1i :
    OOO = iiiiiiii1 [ 'event_list' ] [ 1 ] [ 'url' ]
    iiiiI = urlparse . urlsplit ( OOO ) . query
    oooOo0OOOoo0 = iiiiI [ 0 : iiiiI . find ( '=' ) ]
    OOoO = iiiiI [ iiiiI . find ( '=' ) + 1 : ]
    if 97 - 97: I1IiiI / iii1I1I
    if 71 - 71: II111iiii / i1IIi . I1ii11iIi11i % OoooooooOO . OoOoOO00
    if 41 - 41: i1IIi * II111iiii / OoooooooOO . OOooOOo
    if 83 - 83: iii1I1I . O0 / Oo0Ooo / OOooOOo - II111iiii
    if 100 - 100: OoO0O00
    iI11i1ii11 = { 'title' : iiiiiiii1 [ 'title_list' ] [ 0 ] [ 'text' ]

    , 'age' : iiiiiiii1 [ 'age' ]
 , 'thumbnail' : 'https://%s' % iiiiiiii1 . get ( 'thumbnail' )
 , 'videoid' : OOoO
 , 'vidtype' : oooOo0OOOoo0
 }
    if 46 - 46: OoOoOO00 / iIii1I11I1II1 % iii1I1I . iIii1I11I1II1 * iii1I1I
    if exclusion21 == False or iiiiiiii1 . get ( 'age' ) != '21' :
     iIiiI1iI . append ( iI11i1ii11 )
     if 38 - 38: I1ii11iIi11i - iii1I1I / O0 . O0oo0OO0
     if 45 - 45: O0oo0OO0
   OOoO0 = int ( i1Ii1i1I11Iii [ 'cell_toplist' ] [ 'pagecount' ] )
   if i1Ii1i1I11Iii [ 'cell_toplist' ] [ 'count' ] : OO0Oooo0oOO0O = int ( i1Ii1i1I11Iii [ 'cell_toplist' ] [ 'count' ] )
   else : OO0Oooo0oOO0O = self . LIST_LIMIT
   if 83 - 83: OoOoOO00 . OoooooooOO
   o00O0 = OOoO0 > OO0Oooo0oOO0O
   if 58 - 58: i11iIiiIii + OoooooooOO % OoooooooOO / O00oOoOoO0o0O / i11iIiiIii
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   if 62 - 62: OoO0O00 / I1ii11iIi11i
  return iIiiI1iI , o00O0
  if 7 - 7: OoooooooOO . O00oOoOoO0o0O
  if 53 - 53: Ii1I % Ii1I * o0oOOo0O0Ooo + OoOoOO00
 def GetStreamingURL ( self , mode , contentid , quality_int , pvrmode = '-' ) :
  Oooo00 = I111iIi1 = oo00O00oO000o = OOo00OoO = ''
  iIi1 = [ ]
  if 21 - 21: I11i
  if 92 - 92: i11iIiiIii / O0oo0OO0 - iii1I1I % Oo0ooO0oo0oO * O0oo0OO0 + Oo0Ooo
  ii1 = 'hls'
  if mode == 'LIVE' :
   OOOO = self . API_DOMAIN + '/live/channels/' + contentid
   Oo0000oOo = 'live'
  elif mode == 'VOD' :
   OOOO = self . API_DOMAIN + '/cf/vod/contents/' + contentid
   Oo0000oOo = 'vod'
  elif mode == 'MOVIE' :
   OOOO = self . API_DOMAIN + '/cf/movie/contents/' + contentid
   Oo0000oOo = 'movie'
   if 31 - 31: I11i . O0oo0OO0 * Oo0ooO0oo0oO + i11iIiiIii * oO0o
   if 93 - 93: I1ii11iIi11i / iIii1I11I1II1 * i1IIi % OoooooooOO * O0 * I11i
   if 64 - 64: II111iiii + O0 / iIii1I11I1II1 / Oo0Ooo . Oo0ooO0oo0oO % O00oOoOoO0o0O
  try :
   if mode != 'LIVE' or pvrmode == '-' :
    if 50 - 50: iIii1I11I1II1 - O00oOoOoO0o0O + OOooOOo
    O0OoOoo00o = self . GetDefaultParams ( login = False )
    if 69 - 69: O0
    iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
    iii11 = json . loads ( iIii111IIi . text )
    if 85 - 85: Oo0ooO0oo0oO / O0
    iI1iIIIi1i = iii11 [ 'qualities' ] [ 'list' ]
    if iI1iIIIi1i == None : return ( Oooo00 , I111iIi1 , oo00O00oO000o , OOo00OoO )
    if 89 - 89: iIii1I11I1II1
    for i11iiiiI1i in iI1iIIIi1i :
     iIi1 . append ( int ( i11iiiiI1i . get ( 'id' ) . rstrip ( 'p' ) ) )
     if 37 - 37: OOooOOo / OoooooooOO - i11iIiiIii
     if 18 - 18: iii1I1I . I1IiiI
    if 'type' in iii11 :
     if iii11 [ 'type' ] == 'onair' :
      Oo0000oOo = 'onairvod'
      if 40 - 40: O0 - OoooooooOO - O00oOoOoO0o0O
      if 37 - 37: OoOoOO00 / II111iiii / O0
    if 'drms' in iii11 :
     if iii11 [ 'drms' ] :
      ii1 = 'dash'
      if 76 - 76: I1IiiI . Oo0ooO0oo0oO - I1ii11iIi11i - iii1I1I * OoO0O00
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   return ( Oooo00 , I111iIi1 , oo00O00oO000o , OOo00OoO )
   if 54 - 54: O00oOoOoO0o0O + O0 + I11i * O0oo0OO0 - OOooOOo % oO0o
   if 13 - 13: Oo0ooO0oo0oO / iii1I1I * OoO0O00 . OoO0O00 * Oo0ooO0oo0oO
   if 63 - 63: O0oo0OO0 / O0 * Oo0Ooo + II111iiii / O00oOoOoO0o0O + Ii1I
  try :
   OOoO000 = self . CheckQuality ( quality_int , iIi1 )
   if 57 - 57: II111iiii
   if 54 - 54: Oo0Ooo + oO0o + i11iIiiIii
   if 28 - 28: oO0o
   if mode == 'LIVE' and pvrmode != '-' :
    ooo000o0ooO0 = 'auto'
   else :
    ooo000o0ooO0 = str ( OOoO000 ) + 'p'
    if 10 - 10: Oo0ooO0oo0oO . iii1I1I + OoO0O00 / OoooooooOO - iii1I1I / I11i
   OOOO = self . API_DOMAIN + '/streaming'
   O0OoOoo00o = { 'contentid' : contentid
 , 'contenttype' : Oo0000oOo
 , 'action' : ii1
 , 'quality' : ooo000o0ooO0
   , 'deviceModelId' : 'Windows 10'
 , 'guid' : self . GetGUID ( guidType = 2 )
 , 'lastplayid' : ''
   , 'authtype' : 'cookie'
 , 'isabr' : 'y'
 , 'ishevc' : 'n'
 }
   O0OoOoo00o . update ( self . GetDefaultParams ( login = True ) )
   if 76 - 76: o0oOOo0O0Ooo % I1IiiI . iIii1I11I1II1 - O00oOoOoO0o0O * OoooooooOO . iii1I1I
   iIii111IIi = self . callRequestCookies ( 'Get' , OOOO , payload = None , params = O0OoOoo00o , headers = None , cookies = None )
   iii11 = json . loads ( iIii111IIi . text )
   if 84 - 84: O0oo0OO0 + I11i
   Oooo00 = iii11 [ 'playurl' ]
   if Oooo00 == None : return ( Oooo00 , I111iIi1 , oo00O00oO000o , OOo00OoO )
   I111iIi1 = iii11 [ 'awscookie' ]
   oo00O00oO000o = iii11 [ 'drm' ]
   if 'previewmsg' in iii11 [ 'preview' ] : OOo00OoO = iii11 [ 'preview' ] [ 'previewmsg' ]
   if 28 - 28: oO0o - i11iIiiIii . I1ii11iIi11i + O00oOoOoO0o0O / I1ii11iIi11i
  except Exception as oO0ooO0OoOOOO :
   print ( oO0ooO0OoOOOO )
   if 35 - 35: O00oOoOoO0o0O
   if 75 - 75: Oo0Ooo / I1ii11iIi11i . O00oOoOoO0o0O * OOooOOo - II111iiii
   if 41 - 41: Ii1I
   if 77 - 77: O0oo0OO0
   if 65 - 65: II111iiii . I1IiiI % oO0o * OoO0O00
  return ( Oooo00 , I111iIi1 , oo00O00oO000o , OOo00OoO )
  if 38 - 38: OoOoOO00 / iii1I1I % Oo0Ooo
  if 11 - 11: iii1I1I - oO0o + II111iiii - iIii1I11I1II1
  if 7 - 7: O00oOoOoO0o0O - I11i / II111iiii * Ii1I . iii1I1I * iii1I1I
  if 61 - 61: I11i % Oo0ooO0oo0oO - OoO0O00 / Oo0Ooo
  if 4 - 4: OoooooooOO - i1IIi % Ii1I - OOooOOo * o0oOOo0O0Ooo
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
