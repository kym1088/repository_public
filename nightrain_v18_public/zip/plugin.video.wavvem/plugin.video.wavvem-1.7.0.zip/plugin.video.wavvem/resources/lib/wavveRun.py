# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import os
import xbmcplugin , xbmcgui , xbmcaddon , xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import urlparse
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 73 - 73: II111iiii
IiII1IiiIiI1 = [
 { 'title' : 'LIVE 채널' , 'mode' : 'LIVE_CATAGORY' , 'sCode' : 'GN54' , 'sIndex' : '0' , 'sType' : 'live' }
 , { 'title' : '인기 드라마' , 'mode' : 'PROGRAM_LIST' , 'subapi' : 'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4' , 'page' : '1' }
 , { 'title' : '인기 예능' , 'mode' : 'PROGRAM_LIST' , 'subapi' : 'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3' , 'page' : '1' }

, { 'title' : '분류별 - VOD 방송  - 최신순' , 'mode' : 'MAIN_CATAGORY' , 'sCode' : 'GN52' , 'sIndex' : '1' , 'sType' : 'vod' , 'orderby' : 'new' , 'ordernm' : '최신순' }
 , { 'title' : '분류별 - 해외시리즈 - 인기순' , 'mode' : 'MAIN_CATAGORY' , 'sCode' : 'GN52' , 'sIndex' : '2' , 'sType' : 'vod' , 'orderby' : 'viewtime' , 'ordernm' : '인기순' }
 , { 'title' : '분류별 - 해외시리즈 - 최신순' , 'mode' : 'MAIN_CATAGORY' , 'sCode' : 'GN52' , 'sIndex' : '2' , 'sType' : 'vod' , 'orderby' : 'new' , 'ordernm' : '최신순' }
 , { 'title' : '분류별 - 영화(Movie) - 인기순' , 'mode' : 'MAIN_CATAGORY' , 'sCode' : 'GN52' , 'sIndex' : '3' , 'sType' : 'movie' , 'orderby' : 'paid' , 'ordernm' : '인기순' }
 , { 'title' : '분류별 - 영화(Movie) - 업데이트순' , 'mode' : 'MAIN_CATAGORY' , 'sCode' : 'GN52' , 'sIndex' : '3' , 'sType' : 'movie' , 'orderby' : 'displaystart' , 'ordernm' : '업데이트순' }

, { 'title' : '-----------------' , 'mode' : 'XXX' }
 , { 'title' : '검색 (search)' , 'mode' : 'SEARCH_GROUP' }
 , { 'title' : 'Watched (시청목록)' , 'mode' : 'WATCH_GROUP' }
 ]
if 40 - 40: oo * OoO0O00
IIiIiII11i = [
 { 'title' : 'VOD 검색' , 'mode' : 'SEARCH_LIST' , 'sType' : 'vod' }
 , { 'title' : '영화 검색' , 'mode' : 'SEARCH_LIST' , 'sType' : 'movie' }
 ]
if 51 - 51: oOo0O0Ooo * I1ii11iIi11i
I1IiI = [
 { 'title' : 'VOD 시청내역' , 'mode' : 'WATCH_LIST' , 'sType' : 'vod' }
 , { 'title' : '영화 시청내역' , 'mode' : 'WATCH_LIST' , 'sType' : 'movie' }
 ]
if 73 - 73: OOooOOo / ii11ii1ii
__addon__ = xbmcaddon . Addon ( )
__language__ = __addon__ . getLocalizedString
__profile__ = xbmc . translatePath ( __addon__ . getAddonInfo ( 'profile' ) )
__version__ = __addon__ . getAddonInfo ( 'version' )
__addonid__ = __addon__ . getAddonInfo ( 'id' )
__addonname__ = __addon__ . getAddonInfo ( 'name' )
if 94 - 94: OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * o00O0oo
if 97 - 97: oO0o0ooO0 - IIII / O0oO - o0oO0
oo00 = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
o00 = xbmc . translatePath ( os . path . join ( __profile__ , 'wavve_cookies.json' ) )
if 62 - 62: i11iIiiIii - II111iiii % O0oO - iIii1I11I1II1 . ii11ii1ii . II111iiii
if 61 - 61: OoOO / I1ii11iIi11i / oO0o0ooO0 * oOo0O0Ooo . II111iiii
from wavveCore import *
if 1 - 1: II111iiii - ii11ii1ii % i11iIiiIii + IIII . O0oO
if 55 - 55: iIii1I11I1II1 - oo . o00O0oo * IIII * i1IIi / iIii1I11I1II1
class OOo000 ( object ) :
 def __init__ ( self , in_addonurl , in_handle , in_params ) :
  self . _addon_url = in_addonurl
  self . _addon_handle = in_handle
  self . main_params = in_params
  self . WavveObj = xI1Ii11I1Ii1i ( )
  if 82 - 82: o0000oOoOoO0o . O0oO / IIII % II111iiii % iIii1I11I1II1 % IIII
  if 86 - 86: I1ii11iIi11i % oo
  if 80 - 80: OoooooooOO . oo
 def addon_noti ( self , sting ) :
  try :
   OOO0O = xbmcgui . Dialog ( )
   OOO0O . notification ( __addonname__ , sting )
  except :
   None
   if 94 - 94: o0oO0
   if 18 - 18: iIii1I11I1II1 / o0000oOoOoO0o + OoOO / OoO0O00 - II111iiii - o0000oOoOoO0o
   if 1 - 1: o0000oOoOoO0o - OoOO0ooOOoo0O % O0 + oo - oO0o0ooO0 / o0000oOoOoO0o
 def addon_log ( self , string ) :
  try :
   iIiiI1 = string . encode ( 'utf-8' , 'ignore' )
  except :
   iIiiI1 = 'addonException: addon_log'
   if 68 - 68: oo - i11iIiiIii - oOo0O0Ooo / OoOO0ooOOoo0O - oOo0O0Ooo + i1IIi
   if 48 - 48: OoooooooOO % OOooOOo . oo - o00O0oo % i1IIi % OoooooooOO
  i1iIIi1 = xbmc . LOGINFO
  xbmc . log ( "[%s-%s]: %s" % ( __addonid__ , __version__ , iIiiI1 ) , level = i1iIIi1 )
  if 50 - 50: i11iIiiIii - o00O0oo
  if 78 - 78: oOo0O0Ooo
  if 18 - 18: O0 - oO0o0ooO0 / oO0o0ooO0 + o0oO0 % o0oO0 - IIII
  if 62 - 62: oO0o0ooO0 - IIII - I1ii11iIi11i % i1IIi / OoOO
 def get_keyboard_input ( self , title ) :
  OoooooOoo = None
  OO = xbmc . Keyboard ( )
  OO . setHeading ( title )
  xbmc . sleep ( 1000 )
  OO . doModal ( )
  if ( OO . isConfirmed ( ) ) :
   OoooooOoo = OO . getText ( )
  return OoooooOoo
  if 55 - 55: oOo0O0Ooo / ii11ii1ii * OoOO0ooOOoo0O
  if 86 - 86: i11iIiiIii + o00O0oo + o0oO0 * o0000oOoOoO0o + OOooOOo
  if 61 - 61: oOo0O0Ooo / i11iIiiIii
  if 34 - 34: OoooooooOO + iIii1I11I1II1 + i11iIiiIii - ii11ii1ii + i11iIiiIii
 def get_settings_login_info ( self ) :
  ooOoo0O = __addon__ . getSetting ( 'id' )
  OooO0 = __addon__ . getSetting ( 'pw' )
  II11iiii1Ii = __addon__ . getSetting ( 'selected_profile' )
  return ( ooOoo0O , OooO0 , II11iiii1Ii )
  if 70 - 70: OoOO / iIii1I11I1II1 % o0oO0 % i11iIiiIii . oo
  if 68 - 68: o0000oOoOoO0o + OoOO0ooOOoo0O . iIii1I11I1II1 - IIII % iIii1I11I1II1 - o0oO0
  if 79 - 79: OoO0O00 + oo - oO0o0ooO0
 def get_selQuality ( self ) :
  try :
   oO00O00o0OOO0 = [ 1080 , 720 , 480 , 360 ]
   if 27 - 27: O0 % i1IIi * OoOO + i11iIiiIii + OoooooooOO * i1IIi
   o0oo0o0O00OO = int ( __addon__ . getSetting ( 'selected_quality' ) )
   return oO00O00o0OOO0 [ o0oo0o0O00OO ]
  except :
   None
   if 80 - 80: i1IIi
  return 1080
  if 70 - 70: I1ii11iIi11i - OOooOOo
  if 43 - 43: o0000oOoOoO0o / II111iiii / OoooooooOO . OOooOOo . o00O0oo
  if 19 - 19: o0000oOoOoO0o + o0oO0
 def get_settings_exclusion21 ( self ) :
  ooo = __addon__ . getSetting ( 'exclusion21' )
  if ooo == 'false' :
   return False
  else :
   return True
   if 18 - 18: OOooOOo
   if 28 - 28: OoOO0ooOOoo0O - IIII . IIII + I1ii11iIi11i - OoooooooOO + O0
   if 95 - 95: oOo0O0Ooo % OoOO . O0
 def get_settings_direct_replay ( self ) :
  I1i1I = int ( __addon__ . getSetting ( 'direct_replay' ) )
  if I1i1I == 0 :
   return False
  else :
   return True
   if 80 - 80: I1ii11iIi11i - oOo0O0Ooo
   if 87 - 87: OoOO / o0000oOoOoO0o - i1IIi * OoOO0ooOOoo0O / OoooooooOO . O0
   if 1 - 1: II111iiii - o0000oOoOoO0o / o0000oOoOoO0o
 def get_settings_addinfo ( self ) :
  I1II1III11iii = __addon__ . getSetting ( 'add_infoyn' )
  if I1II1III11iii == 'false' :
   return False
  else :
   return True
   if 75 - 75: iIii1I11I1II1 / OoOO0ooOOoo0O % OOooOOo * I1ii11iIi11i
   if 9 - 9: oOo0O0Ooo
   if 33 - 33: o0oO0 . oO0o0ooO0
   if 58 - 58: OoOO0ooOOoo0O * i11iIiiIii / I1ii11iIi11i % O0oO - ii11ii1ii / OoOO
 def set_winCredential ( self , credential ) :
  ii11i1 = xbmcgui . Window ( 10000 )
  ii11i1 . setProperty ( 'WAVVE_M_CREDENTIAL' , credential )
  ii11i1 . setProperty ( 'WAVVE_M_LOGINTIME' , self . WavveObj . Get_Now_Datetime ( ) . strftime ( '%Y-%m-%d' ) )
  if 29 - 29: ii11ii1ii % oo + o0oO0 / OOooOOo + OoOO0ooOOoo0O * OOooOOo
 def get_winCredential ( self ) :
  ii11i1 = xbmcgui . Window ( 10000 )
  return ii11i1 . getProperty ( 'WAVVE_M_CREDENTIAL' )
  if 42 - 42: o00O0oo + OoOO
 def set_winEpisodeOrderby ( self , orderby ) :
  ii11i1 = xbmcgui . Window ( 10000 )
  ii11i1 . setProperty ( 'WAVVE_M_ORDERBY' , orderby )
  if 76 - 76: O0oO - oOo0O0Ooo
 def get_winEpisodeOrderby ( self ) :
  ii11i1 = xbmcgui . Window ( 10000 )
  return ii11i1 . getProperty ( 'WAVVE_M_ORDERBY' )
  if 70 - 70: o0oO0
  if 61 - 61: ii11ii1ii . ii11ii1ii
  if 10 - 10: I1ii11iIi11i * oO0o0ooO0 . o0000oOoOoO0o + II111iiii - o0oO0 * i1IIi
  if 56 - 56: OOooOOo * IIII * II111iiii
 def add_dir ( self , label , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = '' ) :
  oO0ooO0OoOOOO = '%s?%s' % ( self . _addon_url , urllib . urlencode ( params ) )
  if 46 - 46: OoOO0ooOOoo0O / ii11ii1ii
  if sublabel : I1 = '%s < %s >' % ( label , sublabel )
  else : I1 = label
  if not img : img = 'DefaultFolder.png'
  if 71 - 71: OoOO0ooOOoo0O + o0oO0 % i11iIiiIii + ii11ii1ii - IIII
  oO0OOoO0 = xbmcgui . ListItem ( I1 )
  oO0OOoO0 . setArt ( { 'thumbnailImage' : img , 'icon' : img , 'poster' : img } )
  if 34 - 34: IIII - IIII * oo + o00O0oo % IIII
  if infoLabels : oO0OOoO0 . setInfo ( type = "video" , infoLabels = infoLabels )
  if not isFolder : oO0OOoO0 . setProperty ( 'IsPlayable' , 'true' )
  if 4 - 4: OoOO
  xbmcplugin . addDirectoryItem ( self . _addon_handle , oO0ooO0OoOOOO , oO0OOoO0 , isFolder )
  if 93 - 93: oOo0O0Ooo % OoOO . oOo0O0Ooo * O0oO % o00O0oo . II111iiii
  if 38 - 38: OOooOOo
  if 57 - 57: O0 / OoOO * O0oO / I1ii11iIi11i . II111iiii
  if 26 - 26: oO0o0ooO0
 def dp_Main_List ( self ) :
  if 91 - 91: oOo0O0Ooo . ii11ii1ii + oOo0O0Ooo - oO0o0ooO0 / OoooooooOO
  for iII1 in IiII1IiiIiI1 :
   I1 = iII1 . get ( 'title' )
   if 30 - 30: II111iiii - OoOO0ooOOoo0O - i11iIiiIii % I1ii11iIi11i - II111iiii * o00O0oo
   oO00O0O0O = { 'mode' : iII1 . get ( 'mode' )
 , 'sCode' : iII1 . get ( 'sCode' )
 , 'sIndex' : iII1 . get ( 'sIndex' )
 , 'sType' : iII1 . get ( 'sType' )

 , 'subapi' : iII1 . get ( 'subapi' )
 , 'page' : iII1 . get ( 'page' )
 , 'orderby' : iII1 . get ( 'orderby' )
 , 'ordernm' : iII1 . get ( 'ordernm' )
 }
   if 31 - 31: o0000oOoOoO0o - II111iiii . o0000oOoOoO0o
   if iII1 . get ( 'mode' ) == 'XXX' :
    i1I11i1I = False
   else :
    i1I11i1I = True
    if 81 - 81: iIii1I11I1II1 + iIii1I11I1II1 * IIII * o0oO0 % o0oO0
   self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = None , isFolder = i1I11i1I , params = oO00O0O0O )
   if 81 - 81: i11iIiiIii % I1ii11iIi11i - OoOO0ooOOoo0O
  if len ( IiII1IiiIiI1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 68 - 68: O0oO % i1IIi . IIII . ii11ii1ii
  if 92 - 92: oO0o0ooO0 . O0oO
  if 31 - 31: O0oO . I1ii11iIi11i / O0
  if 89 - 89: I1ii11iIi11i
 def dp_Search_Group ( self , args ) :
  for OO0oOoOO0oOO0 in IIiIiII11i :
   I1 = OO0oOoOO0oOO0 . get ( 'title' )
   if 86 - 86: OoOO0ooOOoo0O
   oO00O0O0O = { 'mode' : OO0oOoOO0oOO0 . get ( 'mode' )
 , 'sType' : OO0oOoOO0oOO0 . get ( 'sType' )
 , 'page' : '1'
 }
   if 55 - 55: OoO0O00 + iIii1I11I1II1 / I1ii11iIi11i * OoOO - i11iIiiIii - o00O0oo
   self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 25 - 25: ii11ii1ii
  if len ( IIiIiII11i ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 7 - 7: i1IIi / oo * O0oO . IIII . iIii1I11I1II1
  if 13 - 13: OoOO0ooOOoo0O / i11iIiiIii
  if 2 - 2: oo / O0 / OOooOOo % I1ii11iIi11i % o00O0oo
  if 52 - 52: OOooOOo
 def dp_Watch_Group ( self , args ) :
  for o0OO0oOO0O0 in I1IiI :
   I1 = o0OO0oOO0O0 . get ( 'title' )
   if 8 - 8: OoOO
   oO00O0O0O = { 'mode' : o0OO0oOO0O0 . get ( 'mode' )
 , 'sType' : o0OO0oOO0O0 . get ( 'sType' )
 }
   if 7 - 7: OOooOOo - oo
   self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 100 - 100: OoOO + o0000oOoOoO0o . OoOO0ooOOoo0O * o00O0oo
  if len ( I1IiI ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 73 - 73: i1IIi + oo
  if 46 - 46: oOo0O0Ooo . OoO0O00 - OoooooooOO
  if 93 - 93: oO0o0ooO0
  if 10 - 10: o0000oOoOoO0o
 def login_main ( self ) :
  ( OOooOO000 , OOoOoo , oO0000OOo00 ) = self . get_settings_login_info ( )
  if 27 - 27: oo % oo
  if 1 - 1: oOo0O0Ooo - OoOO . o0000oOoOoO0o . oOo0O0Ooo / OoO0O00 + o0000oOoOoO0o
  if not ( OOooOO000 and OOoOoo ) :
   OOO0O = xbmcgui . Dialog ( )
   Ooo = OOO0O . yesno ( __language__ ( 30901 ) . encode ( 'utf8' ) , __language__ ( 30902 ) . encode ( 'utf8' ) )
   if Ooo == True :
    __addon__ . openSettings ( )
    sys . exit ( )
   else :
    sys . exit ( )
    if 62 - 62: OoOO0ooOOoo0O / oOo0O0Ooo + o00O0oo / oOo0O0Ooo . II111iiii
    if 68 - 68: i11iIiiIii % ii11ii1ii + i11iIiiIii
  if self . get_winEpisodeOrderby ( ) == '' :
   self . set_winEpisodeOrderby ( 'desc' )
   if 31 - 31: II111iiii . oo
   if 1 - 1: OoO0O00 / OOooOOo % oO0o0ooO0 * IIII . i11iIiiIii
  if self . cookiefile_check ( ) : return
  if 2 - 2: ii11ii1ii * o0000oOoOoO0o - iIii1I11I1II1 + oo . OoOO % oO0o0ooO0
  ooOOOoOooOoO = int ( self . WavveObj . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' ) )
  o00oooO0Oo = xbmcgui . Window ( 10000 ) . getProperty ( 'WAVVE_M_LOGINTIME' )
  if 78 - 78: o00O0oo % O0oO + ii11ii1ii
  if o00oooO0Oo == None or o00oooO0Oo == '' :
   o00oooO0Oo = int ( '19000101' )
  else :
   o00oooO0Oo = int ( re . sub ( '-' , '' , o00oooO0Oo ) )
   if 64 - 64: OoOO * O0 . oo + II111iiii
   if 6 - 6: I1ii11iIi11i / oO0o0ooO0 . IIII . IIII
   if 62 - 62: ii11ii1ii + IIII % oO0o0ooO0 + OoOO0ooOOoo0O
  if xbmcgui . Window ( 10000 ) . getProperty ( 'WAVVE_M_LOGINWAIT' ) == 'TRUE' :
   iii = 0
   while True :
    iii += 1
    if 90 - 90: OOooOOo % i1IIi / oOo0O0Ooo
    time . sleep ( 0.05 )
    if 44 - 44: OoO0O00 . oOo0O0Ooo / ii11ii1ii + o00O0oo
    if o00oooO0Oo >= ooOOOoOooOoO : return
    if iii > 600 : return
  else :
   xbmcgui . Window ( 10000 ) . setProperty ( 'WAVVE_M_LOGINWAIT' , 'TRUE' )
   if 65 - 65: O0
  if o00oooO0Oo >= ooOOOoOooOoO :
   xbmcgui . Window ( 10000 ) . setProperty ( 'WAVVE_M_LOGINWAIT' , 'FALSE' )
   return
   if 68 - 68: OoOO0ooOOoo0O % O0oO
  if not self . WavveObj . GetCredential ( OOooOO000 , OOoOoo , oO0000OOo00 ) :
   self . addon_noti ( __language__ ( 30903 ) . encode ( 'utf8' ) )
   xbmcgui . Window ( 10000 ) . setProperty ( 'WAVVE_M_LOGINWAIT' , 'FALSE' )
   sys . exit ( )
   if 88 - 88: iIii1I11I1II1 - o0oO0 + OoOO0ooOOoo0O
   if 40 - 40: oo * o00O0oo + OoOO0ooOOoo0O % oO0o0ooO0
  self . set_winCredential ( self . WavveObj . LoadCredential ( ) )
  self . cookiefile_save ( )
  xbmcgui . Window ( 10000 ) . setProperty ( 'WAVVE_M_LOGINWAIT' , 'FALSE' )
  if 74 - 74: OoOO - OoO0O00 + OoooooooOO + O0oO / I1ii11iIi11i
  if 23 - 23: O0
  if 85 - 85: o00O0oo
  if 84 - 84: oo . iIii1I11I1II1 % OoooooooOO + o00O0oo % OoooooooOO % oOo0O0Ooo
  if 42 - 42: oOo0O0Ooo / o0000oOoOoO0o / OOooOOo + oO0o0ooO0 / I1ii11iIi11i
  if 84 - 84: o0oO0 * II111iiii + OoO0O00
 def dp_setEpOrderby ( self , args ) :
  O0ooO0Oo00o = args . get ( 'orderby' )
  if 77 - 77: iIii1I11I1II1 * oOo0O0Ooo
  self . set_winEpisodeOrderby ( O0ooO0Oo00o )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 95 - 95: oo + i11iIiiIii
  if 6 - 6: o0oO0 / i11iIiiIii + oO0o0ooO0 * OoOO
  if 80 - 80: II111iiii
  if 83 - 83: o0000oOoOoO0o . i11iIiiIii + II111iiii . OOooOOo * o0000oOoOoO0o
  if 53 - 53: II111iiii
 def play_VIDEO ( self , args ) :
  if 31 - 31: oOo0O0Ooo
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 80 - 80: O0oO . i11iIiiIii - OOooOOo
  iIiIIi1 = args . get ( 'mode' )
  I1IIII1i = args . get ( 'contentid' )
  I1I11i = args . get ( 'pvrmode' )
  Ii1I1I1i1Ii = self . get_selQuality ( )
  if 5 - 5: O0oO . OOooOOo
  self . addon_log ( I1IIII1i + ' - ' + iIiIIi1 )
  O0oO0 , oO0 , O0OO0O , OOOoOoO = self . WavveObj . GetStreamingURL ( iIiIIi1 , I1IIII1i , Ii1I1I1i1Ii , I1I11i )
  if 43 - 43: i11iIiiIii + OoO0O00 * II111iiii * O0oO * O0
  o00oO0oo0OO = '%s|Cookie=%s' % ( O0oO0 , oO0 )
  self . addon_log ( o00oO0oo0OO )
  if 57 - 57: O0oO % o00O0oo + OOooOOo - OoO0O00
  if O0oO0 == '' :
   self . addon_noti ( __language__ ( 30907 ) . encode ( 'utf8' ) )
   return
   if 65 - 65: o0000oOoOoO0o . I1ii11iIi11i
  IiI1i = xbmcgui . ListItem ( path = o00oO0oo0OO )
  if 92 - 92: IIII . IIII + oOo0O0Ooo
  if O0OO0O :
   self . addon_log ( '!!streaming_drm!!' )
   IiIiI1111I1I = O0OO0O [ 'customdata' ]
   i1i = O0OO0O [ 'drmhost' ]
   if 56 - 56: ii11ii1ii % O0 - oo
   O00o0OO0 = inputstreamhelper . Helper ( 'mpd' , drm = 'widevine' )
   if 35 - 35: OoOO % o0oO0 / O0oO + iIii1I11I1II1 . OoooooooOO . oo
   if O00o0OO0 . check_inputstream ( ) :
    if 71 - 71: IIII * II111iiii * OoOO
    if iIiIIi1 == 'MOVIE' :
     oOOo0 = 'https://www.wavve.com/player/movie?movieid=%s' % I1IIII1i
    else :
     oOOo0 = 'https://www.wavve.com/player/vod?programid=%s&page=1' % I1IIII1i
     if 16 - 16: OoOO % ii11ii1ii * i11iIiiIii % i11iIiiIii
    O0OOOOo0O = { 'content-type' : 'application/octet-stream'
 , 'origin' : 'https://www.wavve.com'
 , 'pallycon-customdata' : IiIiI1111I1I
 , 'referer' : oOOo0
 , 'sec-fetch-dest' : 'empty'
    , 'sec-fetch-mode' : 'cors'
 , 'sec-fetch-site' : 'same-site'
 , 'user-agent' : oo00
 }
    OooOO = i1i + '|' + urllib . urlencode ( O0OOOOo0O ) + '|R{SSM}|'
    if 21 - 21: o0000oOoOoO0o / IIII % iIii1I11I1II1 * OoO0O00
    IiI1i . setProperty ( 'inputstreamaddon' , O00o0OO0 . inputstream_addon )
    IiI1i . setProperty ( 'inputstream.adaptive.manifest_type' , 'mpd' )
    IiI1i . setProperty ( 'inputstream.adaptive.license_type' , 'com.widevine.alpha' )
    IiI1i . setProperty ( 'inputstream.adaptive.license_key' , OooOO )
    IiI1i . setProperty ( 'inputstream.adaptive.stream_headers' , 'user-agent=%s&Cookie=%s' % ( oo00 , oO0 ) )
    if 57 - 57: II111iiii + i1IIi
  xbmcplugin . setResolvedUrl ( self . _addon_handle , True , IiI1i )
  if 10 - 10: OoOO + i1IIi
  oOo0O = False
  if OOOoOoO :
   self . addon_noti ( OOOoOoO . encode ( 'utf-8' ) )
   oOo0O = True
  else :
   if '/preview.' in urlparse . urlsplit ( O0oO0 ) . path :
    self . addon_noti ( __language__ ( 30908 ) . encode ( 'utf8' ) )
    oOo0O = True
    if 52 - 52: i11iIiiIii / OOooOOo * o0oO0
    if 22 - 22: I1ii11iIi11i . OoOO0ooOOoo0O * I1ii11iIi11i
  try :
   O000OOO = args . get ( 'programid' ) if args . get ( 'mode' ) == 'VOD' else args . get ( 'contentid' )
   if args . get ( 'mode' ) in [ 'VOD' , 'MOVIE' ] and args . get ( 'title' ) and args . get ( 'age' ) != '21' and oOo0O == False and O000OOO != '-' :
    oO00O0O0O = { 'code' : O000OOO
 , 'img' : args . get ( 'thumbnail' )
 , 'title' : args . get ( 'title' )
 , 'subtitle' : args . get ( 'subtitle' )
 , 'videoid' : args . get ( 'contentid' )
    }
    self . Save_Watched_List ( args . get ( 'mode' ) . lower ( ) , oO00O0O0O )
  except :
   None
   if 20 - 20: OOooOOo . II111iiii % OoOO0ooOOoo0O * iIii1I11I1II1
   if 98 - 98: oo % o00O0oo * OoooooooOO
   if 51 - 51: iIii1I11I1II1 . I1ii11iIi11i / OoOO + OOooOOo
   if 33 - 33: o0oO0 . II111iiii % oO0o0ooO0 + OOooOOo
   if 71 - 71: OoO0O00 % OoOO0ooOOoo0O
   if 98 - 98: o0000oOoOoO0o % i11iIiiIii % o0oO0 + o00O0oo
 def Load_Watched_List ( self , genre ) :
  try :
   OOoOO0o0o0 = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % genre ) )
   if 11 - 11: oo
   I1111i = open ( OOoOO0o0o0 , 'r' )
   iIIii = I1111i . readlines ( )
   I1111i . close ( )
  except :
   iIIii = [ ]
   if 92 - 92: o00O0oo + OoOO % OoOO0ooOOoo0O
  return iIIii
  if 62 - 62: ii11ii1ii / i1IIi
  if 98 - 98: i1IIi / o0000oOoOoO0o
  if 32 - 32: o00O0oo * iIii1I11I1II1 / OoOO0ooOOoo0O
  if 38 - 38: o0oO0 % II111iiii % o0000oOoOoO0o / oOo0O0Ooo + I1ii11iIi11i / i1IIi
 def Save_Watched_List ( self , genre , in_params ) :
  try :
   OOoOO0o0o0 = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % genre ) )
   OoOOo0OOoO = self . Load_Watched_List ( genre )
   if 72 - 72: o00O0oo
   I1111i = open ( OOoOO0o0o0 , 'w' )
   II11Ii1iI1iII = urllib . urlencode ( in_params )
   II11Ii1iI1iII = II11Ii1iI1iII + '\n'
   I1111i . write ( II11Ii1iI1iII )
   if 73 - 73: OoooooooOO * OoooooooOO * o0oO0 * I1ii11iIi11i + o0oO0 * O0oO
   oo0o0OO0 = 0
   for oooO in OoOOo0OOoO :
    i1I1i111Ii = dict ( urlparse . parse_qsl ( oooO ) )
    if 67 - 67: oo . i1IIi
    i1i1iI1iiiI = in_params . get ( 'code' ) . strip ( )
    Ooo0oOooo0 = i1I1i111Ii . get ( 'code' ) . strip ( )
    if genre == 'vod' and self . get_settings_direct_replay ( ) == True :
     i1i1iI1iiiI = in_params . get ( 'videoid' ) . strip ( )
     Ooo0oOooo0 = i1I1i111Ii . get ( 'videoid' ) . strip ( ) if Ooo0oOooo0 != None else '-'
     if 61 - 61: I1ii11iIi11i - OoOO0ooOOoo0O - i1IIi
    if i1i1iI1iiiI != Ooo0oOooo0 :
     I1111i . write ( oooO )
     oo0o0OO0 += 1
     if oo0o0OO0 >= 50 : break
     if 25 - 25: O0 * o0000oOoOoO0o + ii11ii1ii . OOooOOo . OOooOOo
   I1111i . close ( )
  except :
   None
   if 58 - 58: oo
   if 53 - 53: i1IIi
   if 59 - 59: OOooOOo
   if 81 - 81: I1ii11iIi11i - I1ii11iIi11i . oO0o0ooO0
 def Delete_Watched_List ( self , genre ) :
  try :
   OOoOO0o0o0 = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % genre ) )
   I1111i = open ( OOoOO0o0o0 , 'w' )
   I1111i . write ( '' )
   I1111i . close ( )
  except :
   None
   if 73 - 73: o0000oOoOoO0o % i11iIiiIii - oo
   if 7 - 7: O0 * i11iIiiIii * o00O0oo + o0oO0 % oOo0O0Ooo - o0oO0
   if 39 - 39: OoO0O00 * OoOO0ooOOoo0O % OoOO0ooOOoo0O - OoooooooOO + OOooOOo - o0000oOoOoO0o
   if 23 - 23: i11iIiiIii
 def dp_WatchList_Delete ( self , args ) :
  II1iIi11 = args . get ( 'sType' )
  if 12 - 12: o00O0oo + i11iIiiIii * iIii1I11I1II1 / ii11ii1ii . o0000oOoOoO0o
  OOO0O = xbmcgui . Dialog ( )
  Ooo = OOO0O . yesno ( __language__ ( 30904 ) . encode ( 'utf8' ) , __language__ ( 30905 ) . encode ( 'utf8' ) )
  if Ooo == False : sys . exit ( )
  if 5 - 5: i1IIi + IIII / OOooOOo . oO0o0ooO0 / o0000oOoOoO0o
  self . Delete_Watched_List ( II1iIi11 )
  if 32 - 32: oo % iIii1I11I1II1 / i1IIi - oo
  xbmc . executebuiltin ( "Container.Refresh" )
  if 7 - 7: O0oO * oOo0O0Ooo - o0oO0 + OoOO0ooOOoo0O * oo % oOo0O0Ooo
  if 15 - 15: I1ii11iIi11i % oo * o0000oOoOoO0o
  if 81 - 81: o0oO0 - iIii1I11I1II1 - i1IIi / O0oO - O0 * o0000oOoOoO0o
  if 20 - 20: OoOO % IIII
 def logout ( self ) :
  OOO0O = xbmcgui . Dialog ( )
  Ooo = OOO0O . yesno ( __language__ ( 30910 ) . encode ( 'utf8' ) , __language__ ( 30905 ) . encode ( 'utf8' ) )
  if Ooo == False : sys . exit ( )
  if 19 - 19: ii11ii1ii % IIII + o0oO0 / O0oO . o0oO0
  self . wininfo_clear ( )
  if 12 - 12: i1IIi + i1IIi - ii11ii1ii * OoO0O00 % OoO0O00 - II111iiii
  if 52 - 52: o0oO0 . oO0o0ooO0 + O0oO
  if os . path . isfile ( o00 ) : os . remove ( o00 )
  if 38 - 38: i1IIi - II111iiii . O0oO
  self . addon_noti ( __language__ ( 30909 ) . encode ( 'utf-8' ) )
  if 58 - 58: oo . oO0o0ooO0 + I1ii11iIi11i
  if 66 - 66: oO0o0ooO0 / OoOO * OoooooooOO + OoooooooOO % o0000oOoOoO0o
  if 49 - 49: OoOO - i11iIiiIii . O0oO * o00O0oo % oO0o0ooO0 + i1IIi
  if 71 - 71: OOooOOo
 def wininfo_clear ( self ) :
  if 38 - 38: OoOO % I1ii11iIi11i + ii11ii1ii . i11iIiiIii
  ii11i1 = xbmcgui . Window ( 10000 )
  ii11i1 . setProperty ( 'WAVVE_M_CREDENTIAL' , '' )
  ii11i1 . setProperty ( 'WAVVE_M_LOGINTIME' , '' )
  if 53 - 53: i11iIiiIii * oO0o0ooO0
  if 68 - 68: iIii1I11I1II1 * iIii1I11I1II1 . OOooOOo / II111iiii % OoO0O00
  if 38 - 38: o0oO0 - OoOO0ooOOoo0O / oO0o0ooO0
  if 66 - 66: O0 % ii11ii1ii + i11iIiiIii . I1ii11iIi11i / o00O0oo + ii11ii1ii
 def cookiefile_save ( self ) :
  ooo00Ooo = self . WavveObj . Get_Now_Datetime ( )
  Oo0o0O00 = ooo00Ooo + datetime . timedelta ( days = int ( __addon__ . getSetting ( 'cache_ttl' ) ) )
  if 40 - 40: OoooooooOO
  ii11i1 = xbmcgui . Window ( 10000 )
  I1i1i1 = { 'wavve_token' : ii11i1 . getProperty ( 'WAVVE_M_CREDENTIAL' )
 , 'wavve_id' : base64 . standard_b64encode ( __addon__ . getSetting ( 'id' ) . encode ( ) ) . decode ( 'utf-8' )
 , 'wavve_pw' : base64 . standard_b64encode ( __addon__ . getSetting ( 'pw' ) . encode ( ) ) . decode ( 'utf-8' )
 , 'wavve_profile' : __addon__ . getSetting ( 'selected_profile' )
 , 'wavve_limitdate' : Oo0o0O00 . strftime ( '%Y-%m-%d' )
 }
  if 73 - 73: O0 * oO0o0ooO0 + o00O0oo + o0oO0
  try :
   if 40 - 40: II111iiii . I1ii11iIi11i * O0oO + OoOO0ooOOoo0O + OoOO0ooOOoo0O
   I1111i = open ( o00 , 'w' )
   json . dump ( I1i1i1 , I1111i )
   I1111i . close ( )
  except Exception as I1ii1I1iiii :
   print ( I1ii1I1iiii )
   if 36 - 36: OoooooooOO . oOo0O0Ooo
   if 56 - 56: OoO0O00 . ii11ii1ii . oo
   if 39 - 39: O0 + O0oO
   if 91 - 91: OoooooooOO - iIii1I11I1II1 + I1ii11iIi11i / oOo0O0Ooo . I1ii11iIi11i + O0
 def cookiefile_check ( self ) :
  if 26 - 26: ii11ii1ii - OoooooooOO
  if 11 - 11: oo * OoOO
  I1i1i1 = { }
  try :
   I1111i = open ( o00 , 'r' )
   I1i1i1 = json . load ( I1111i )
   I1111i . close ( )
  except Exception as I1ii1I1iiii :
   self . wininfo_clear ( )
   return False
   if 81 - 81: oO0o0ooO0 + IIII
   if 98 - 98: oo
   if 95 - 95: o0oO0 / o0oO0
  OOooOO000 = __addon__ . getSetting ( 'id' )
  OOoOoo = __addon__ . getSetting ( 'pw' )
  IIiI1Ii = __addon__ . getSetting ( 'selected_profile' )
  I1i1i1 [ 'wavve_id' ] = base64 . standard_b64decode ( I1i1i1 [ 'wavve_id' ] ) . decode ( 'utf-8' )
  I1i1i1 [ 'wavve_pw' ] = base64 . standard_b64decode ( I1i1i1 [ 'wavve_pw' ] ) . decode ( 'utf-8' )
  if OOooOO000 != I1i1i1 [ 'wavve_id' ] or OOoOoo != I1i1i1 [ 'wavve_pw' ] or IIiI1Ii != I1i1i1 [ 'wavve_profile' ] :
   self . wininfo_clear ( )
   return False
   if 57 - 57: OoOO0ooOOoo0O - o0oO0 - o0000oOoOoO0o + oOo0O0Ooo
   if 30 - 30: o00O0oo % I1ii11iIi11i + i1IIi - o0000oOoOoO0o - o00O0oo
  ooOOOoOooOoO = int ( self . WavveObj . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' ) )
  III11I1 = I1i1i1 [ 'wavve_limitdate' ]
  o00oooO0Oo = int ( re . sub ( '-' , '' , III11I1 ) )
  if 36 - 36: OoOO - o00O0oo . OoO0O00 - i11iIiiIii - OoOO0ooOOoo0O * OoO0O00
  if 76 - 76: i11iIiiIii + OOooOOo / ii11ii1ii - oOo0O0Ooo - o00O0oo + ii11ii1ii
  if o00oooO0Oo < ooOOOoOooOoO :
   self . wininfo_clear ( )
   return False
   if 51 - 51: iIii1I11I1II1 . o0oO0 + iIii1I11I1II1
   if 95 - 95: oo
  ii11i1 = xbmcgui . Window ( 10000 )
  ii11i1 . setProperty ( 'WAVVE_M_CREDENTIAL' , I1i1i1 [ 'wavve_token' ] )
  ii11i1 . setProperty ( 'WAVVE_M_LOGINTIME' , III11I1 )
  if 46 - 46: I1ii11iIi11i + oOo0O0Ooo
  return True
  if 70 - 70: oO0o0ooO0 / iIii1I11I1II1
  if 85 - 85: OoooooooOO % i1IIi * OoooooooOO / ii11ii1ii
  if 96 - 96: OoooooooOO + OoOO
  if 44 - 44: OoOO
 def dp_LiveCatagory_List ( self , args ) :
  if 20 - 20: o0000oOoOoO0o + o00O0oo / O0 % iIii1I11I1II1
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 88 - 88: I1ii11iIi11i / II111iiii
  OOOOO0O00 = args . get ( 'sCode' )
  Iii = args . get ( 'sIndex' )
  iIIiIiI1I1 , ooO = self . WavveObj . Get_LiveCatagory_List ( OOOOO0O00 , Iii )
  if 6 - 6: iIii1I11I1II1 . o0oO0 % OOooOOo
  for I1Iii1 in iIIiIiI1I1 :
   I1 = I1Iii1 . get ( 'title' )
   oO00O0O0O = { 'mode' : 'LIVE_LIST'
 , 'genre' : I1Iii1 . get ( 'genre' )
 , 'baseapi' : ooO
 }
   if 30 - 30: OoooooooOO - I1ii11iIi11i
   self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 75 - 75: iIii1I11I1II1 - o00O0oo . OoO0O00 % i11iIiiIii % o0000oOoOoO0o
  if len ( iIIiIiI1I1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 55 - 55: oO0o0ooO0 . II111iiii % oOo0O0Ooo * oO0o0ooO0 + o0oO0 + o00O0oo
  if 24 - 24: OoO0O00 - OoOO % iIii1I11I1II1 . i1IIi / O0
  if 36 - 36: oo - o0000oOoOoO0o
  if 29 - 29: o0oO0 * OoOO0ooOOoo0O
  if 10 - 10: O0oO % IIII * IIII . o0000oOoOoO0o / o00O0oo % OoOO0ooOOoo0O
 def dp_MainCatagory_List ( self , args ) :
  if 49 - 49: oOo0O0Ooo / OoOO + O0 * OOooOOo
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 28 - 28: o0oO0 + i11iIiiIii / o0000oOoOoO0o % I1ii11iIi11i % OoO0O00 - O0
  OOOOO0O00 = args . get ( 'sCode' )
  Iii = args . get ( 'sIndex' )
  II1iIi11 = args . get ( 'sType' )
  iIIiIiI1I1 = self . WavveObj . Get_MainCatagory_List ( OOOOO0O00 , Iii )
  if 54 - 54: i1IIi + II111iiii
  for I1Iii1 in iIIiIiI1I1 :
   if 83 - 83: ii11ii1ii - oo + OoOO0ooOOoo0O
   if II1iIi11 == 'vod' :
    if I1Iii1 . get ( 'subtype' ) == 'catagory' :
     iIiIIi1 = 'PROGRAM_LIST'
    else :
     iIiIIi1 = 'SUPERSECTION_LIST'
   elif II1iIi11 == 'movie' :
    iIiIIi1 = 'MOVIE_LIST'
   else :
    iIiIIi1 = ''
    if 5 - 5: o00O0oo
    if 46 - 46: IIII
   I1 = '%s (%s)' % ( I1Iii1 . get ( 'title' ) , args . get ( 'ordernm' ) )
   if 45 - 45: o0oO0
   if 21 - 21: OoOO . O0oO . OoOO0ooOOoo0O / OoO0O00 / O0oO
   oO00O0O0O = { 'mode' : iIiIIi1
 , 'suburl' : I1Iii1 . get ( 'suburl' )
 , 'subapi' : I1Iii1 . get ( 'subapi' )
 , 'page' : '1'
 , 'orderby' : args . get ( 'orderby' )
 }
   if 17 - 17: OoOO0ooOOoo0O / OoOO0ooOOoo0O / o0000oOoOoO0o
   if self . get_settings_exclusion21 ( ) :
    if I1Iii1 . get ( 'title' ) == '성인' or I1Iii1 . get ( 'title' ) == '성인+' : continue
    if 1 - 1: i1IIi . i11iIiiIii % OoOO0ooOOoo0O
   self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 82 - 82: iIii1I11I1II1 + OoO0O00 . iIii1I11I1II1 % IIII / o00O0oo . o00O0oo
  if len ( iIIiIiI1I1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 14 - 14: OOooOOo . OoOO0ooOOoo0O . o0000oOoOoO0o + OoooooooOO - OoOO0ooOOoo0O + IIII
  if 9 - 9: o00O0oo
  if 59 - 59: oo * II111iiii . O0
  if 56 - 56: o00O0oo - oO0o0ooO0 % oo - OOooOOo
 def dp_Program_List ( self , args ) :
  if 51 - 51: O0 / o0oO0 * iIii1I11I1II1 + ii11ii1ii + OOooOOo
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 98 - 98: iIii1I11I1II1 * ii11ii1ii * OoOO0ooOOoo0O + o0oO0 % i11iIiiIii % O0
  i1 = args . get ( 'subapi' )
  OO0oOOoo = int ( args . get ( 'page' ) )
  O0ooO0Oo00o = args . get ( 'orderby' )
  if 52 - 52: OOooOOo % OoO0O00
  if 64 - 64: O0 % o0000oOoOoO0o % O0 * oOo0O0Ooo . OoOO + oo
  if 75 - 75: o0000oOoOoO0o . OoooooooOO % OOooOOo * o0000oOoOoO0o % OoooooooOO
  iIIiIiI1I1 , I11i1 = self . WavveObj . Get_Program_List ( i1 , OO0oOOoo , O0ooO0Oo00o )
  if 28 - 28: o0000oOoOoO0o
  for I1Iii1 in iIIiIiI1I1 :
   if 58 - 58: I1ii11iIi11i
   I1 = I1Iii1 . get ( 'title' )
   iIiiI1iI = I1Iii1 . get ( 'thumbnail' )
   IIIi = I1Iii1 . get ( 'age' )
   if IIIi == '18' or IIIi == '19' or IIIi == '21' : I1 += ' (%s)' % ( IIIi )
   if 94 - 94: O0oO - oOo0O0Ooo % oOo0O0Ooo / II111iiii % OoO0O00 . OOooOOo
   o00oOo0oOoo = { 'plot' : I1
 , 'mpaa' : IIIi
 , 'mediatype' : 'episode'
 }
   if 57 - 57: I1ii11iIi11i - ii11ii1ii
   oO00O0O0O = { 'mode' : 'EPISODE_LIST'
 , 'videoid' : I1Iii1 . get ( 'videoid' )
 , 'vidtype' : I1Iii1 . get ( 'vidtype' )
 , 'page' : '1'
 }
   if 50 - 50: O0oO / i1IIi % oOo0O0Ooo . oo / oO0o0ooO0
   self . add_dir ( I1 , sublabel = '' , img = iIiiI1iI , infoLabels = o00oOo0oOoo , isFolder = True , params = oO00O0O0O )
   if 88 - 88: OoOO0ooOOoo0O . o0000oOoOoO0o * OOooOOo . I1ii11iIi11i / o0oO0 . o0000oOoOoO0o
  if I11i1 :
   oO00O0O0O = { }
   oO00O0O0O [ 'mode' ] = 'PROGRAM_LIST'
   oO00O0O0O [ 'subapi' ] = i1
   oO00O0O0O [ 'page' ] = str ( OO0oOOoo + 1 )
   I1 = '[B]%s >>[/B]' % '다음 페이지'
   II1I1iii1iII = str ( OO0oOOoo + 1 )
   self . add_dir ( I1 , sublabel = II1I1iii1iII , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 97 - 97: oo / oO0o0ooO0
  if len ( iIIiIiI1I1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 71 - 71: II111iiii / i1IIi . ii11ii1ii % OoooooooOO . I1ii11iIi11i
  if 41 - 41: i1IIi * II111iiii / OoooooooOO . OoOO0ooOOoo0O
  if 83 - 83: oO0o0ooO0 . O0 / OoO0O00 / OoOO0ooOOoo0O - II111iiii
  if 100 - 100: oOo0O0Ooo
 def dp_SuperSection_List ( self , args ) :
  if 46 - 46: I1ii11iIi11i / iIii1I11I1II1 % oO0o0ooO0 . iIii1I11I1II1 * oO0o0ooO0
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 38 - 38: ii11ii1ii - oO0o0ooO0 / O0 . O0oO
  i1iiIiI1Ii1i = args . get ( 'suburl' )
  if 22 - 22: IIII / i11iIiiIii
  if 62 - 62: oOo0O0Ooo / ii11ii1ii
  iIIiIiI1I1 = self . WavveObj . Get_SuperMultiSection_List ( i1iiIiI1Ii1i )
  if 7 - 7: OoooooooOO . IIII
  for I1Iii1 in iIIiIiI1I1 :
   if 53 - 53: o00O0oo % o00O0oo * OOooOOo + I1ii11iIi11i
   I1 = I1Iii1 . get ( 'title' )
   i1 = I1Iii1 . get ( 'subapi' )
   Oooo00 = I1Iii1 . get ( 'cell_type' )
   if 6 - 6: o00O0oo - o0oO0 * OoOO0ooOOoo0O . oO0o0ooO0 / O0 * o0oO0
   if Oooo00 == 'band_2' :
    iIiIIi1 = 'BAND2SECTION_LIST'
   elif Oooo00 == 'band_live' :
    iIiIIi1 = 'BANDLIVESECTION_LIST'
   else :
    iIiIIi1 = 'PROGRAM_LIST'
    if 22 - 22: OoO0O00 % oO0o0ooO0 * ii11ii1ii / OoOO0ooOOoo0O % i11iIiiIii * o0000oOoOoO0o
   o00oOo0oOoo = { 'plot' : I1
   , 'mediatype' : 'episode'
 }
   if 95 - 95: OoooooooOO - IIII * oo + I1ii11iIi11i
   oO00O0O0O = { 'mode' : iIiIIi1
 , 'suburl' : i1iiIiI1Ii1i
   , 'subapi' : I1Iii1 . get ( 'subapi' )
 , 'page' : '1'
 }
   if 10 - 10: OOooOOo / i11iIiiIii
   self . add_dir ( I1 , sublabel = '' , img = None , infoLabels = o00oOo0oOoo , isFolder = True , params = oO00O0O0O )
   if 92 - 92: o0000oOoOoO0o . O0oO
  if len ( iIIiIiI1I1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 85 - 85: ii11ii1ii . O0oO
  if 78 - 78: o0oO0 * O0oO + iIii1I11I1II1 + iIii1I11I1II1 / O0oO . o00O0oo
  if 97 - 97: o0oO0 / O0oO % i1IIi % ii11ii1ii
  if 18 - 18: iIii1I11I1II1 % o0000oOoOoO0o
 def dp_BandLiveSection_List ( self , args ) :
  if 95 - 95: o0oO0 + i11iIiiIii * O0oO - i1IIi * O0oO - iIii1I11I1II1
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 75 - 75: OoooooooOO * IIII
  i1 = args . get ( 'subapi' )
  OO0oOOoo = int ( args . get ( 'page' ) )
  if 9 - 9: IIII - II111iiii + O0 / iIii1I11I1II1 / i11iIiiIii
  iIIiIiI1I1 , I11i1 = self . WavveObj . Get_BandLiveSection_List ( i1 , OO0oOOoo )
  if 39 - 39: IIII * OoO0O00 + iIii1I11I1II1 - IIII + OoOO0ooOOoo0O
  for I1Iii1 in iIIiIiI1I1 :
   if 69 - 69: O0
   o0ooO = I1Iii1 . get ( 'channelid' )
   OoOOOo0o0ooo = I1Iii1 . get ( 'studio' )
   I1iiiiI1iI = I1Iii1 . get ( 'tvshowtitle' )
   iIiiI1iI = I1Iii1 . get ( 'thumbnail' )
   IIIi = I1Iii1 . get ( 'age' )
   if 43 - 43: OoOO - OoooooooOO
   o00oOo0oOoo = { 'mediatype' : 'video'
 , 'mpaa' : IIIi
 , 'title' : '%s < %s >' % ( OoOOOo0o0ooo , I1iiiiI1iI )
 , 'tvshowtitle' : I1iiiiI1iI
 , 'studio' : OoOOOo0o0ooo
 , 'plot' : OoOOOo0o0ooo
 }
   if 3 - 3: O0 / oO0o0ooO0
   oO00O0O0O = { 'mode' : 'LIVE'
 , 'contentid' : o0ooO

   }
   if 31 - 31: OoOO0ooOOoo0O + OOooOOo . OoooooooOO
   self . add_dir ( OoOOOo0o0ooo , sublabel = I1iiiiI1iI , img = I1Iii1 . get ( 'thumbnail' ) , infoLabels = o00oOo0oOoo , isFolder = False , params = oO00O0O0O )
   if 89 - 89: II111iiii + i1IIi + II111iiii
  if I11i1 :
   oO00O0O0O = { }
   oO00O0O0O [ 'mode' ] = 'BANDLIVESECTION_LIST'
   oO00O0O0O [ 'subapi' ] = i1
   oO00O0O0O [ 'page' ] = str ( OO0oOOoo + 1 )
   I1 = '[B]%s >>[/B]' % '다음 페이지'
   II1I1iii1iII = str ( OO0oOOoo + 1 )
   self . add_dir ( I1 , sublabel = II1I1iii1iII , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 7 - 7: O0 % OOooOOo + ii11ii1ii * oO0o0ooO0 - oO0o0ooO0
  if len ( iIIiIiI1I1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 42 - 42: I1ii11iIi11i * I1ii11iIi11i * O0oO . o0000oOoOoO0o
  if 51 - 51: OoOO0ooOOoo0O % iIii1I11I1II1 - OoooooooOO % o0oO0 * iIii1I11I1II1 % oOo0O0Ooo
  if 99 - 99: OoOO * II111iiii * O0oO
  if 92 - 92: OoO0O00
 def dp_Band2Section_List ( self , args ) :
  if 40 - 40: I1ii11iIi11i / IIII
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 79 - 79: oOo0O0Ooo - iIii1I11I1II1 + o00O0oo - O0oO
  i1 = args . get ( 'subapi' )
  OO0oOOoo = int ( args . get ( 'page' ) )
  if 93 - 93: II111iiii . oo - OoO0O00 + I1ii11iIi11i
  iIIiIiI1I1 , I11i1 = self . WavveObj . Get_Band2Section_List ( i1 , OO0oOOoo )
  if 61 - 61: II111iiii
  for I1Iii1 in iIIiIiI1I1 :
   if 15 - 15: i11iIiiIii % oo * o0000oOoOoO0o / O0oO
   I1 = I1Iii1 . get ( 'programtitle' )
   II1I1iii1iII = I1Iii1 . get ( 'episodetitle' )
   if 90 - 90: oO0o0ooO0
   o00oOo0oOoo = { 'plot' : I1 + '\n\n' + II1I1iii1iII
 , 'mpaa' : I1Iii1 . get ( 'age' )
 , 'mediatype' : 'episode'
 }
   if 31 - 31: OoOO0ooOOoo0O + O0
   oO00O0O0O = { 'mode' : 'VOD'
 , 'programid' : '-'
 , 'contentid' : I1Iii1 . get ( 'videoid' )
 , 'thumbnail' : I1Iii1 . get ( 'thumbnail' )
 , 'title' : I1
 , 'subtitle' : II1I1iii1iII
 }
   if 87 - 87: o0oO0
   self . add_dir ( I1 , sublabel = II1I1iii1iII , img = I1Iii1 . get ( 'thumbnail' ) , infoLabels = o00oOo0oOoo , isFolder = False , params = oO00O0O0O )
   if 45 - 45: oOo0O0Ooo / OoooooooOO - oO0o0ooO0 / o00O0oo % IIII
  if I11i1 :
   oO00O0O0O = { }
   oO00O0O0O [ 'mode' ] = 'BAND2SECTION_LIST'
   oO00O0O0O [ 'subapi' ] = i1
   oO00O0O0O [ 'page' ] = str ( OO0oOOoo + 1 )
   I1 = '[B]%s >>[/B]' % '다음 페이지'
   II1I1iii1iII = str ( OO0oOOoo + 1 )
   self . add_dir ( I1 , sublabel = II1I1iii1iII , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 83 - 83: oo . iIii1I11I1II1 - IIII * i11iIiiIii
  if len ( iIIiIiI1I1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 20 - 20: i1IIi * O0oO + II111iiii % OOooOOo % OoOO
  if 13 - 13: OoO0O00
  if 60 - 60: ii11ii1ii * oo
  if 17 - 17: OoOO0ooOOoo0O % OoO0O00 / ii11ii1ii . IIII * OoOO0ooOOoo0O - II111iiii
 def dp_Movie_List ( self , args ) :
  if 41 - 41: o00O0oo
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 77 - 77: O0oO
  i1 = args . get ( 'subapi' )
  OO0oOOoo = int ( args . get ( 'page' ) )
  if 65 - 65: II111iiii . oo % OoOO * oOo0O0Ooo
  if 38 - 38: I1ii11iIi11i / oO0o0ooO0 % OoO0O00
  if 11 - 11: oO0o0ooO0 - OoOO + II111iiii - iIii1I11I1II1
  iIIiIiI1I1 , I11i1 = self . WavveObj . Get_Movie_List ( i1 , OO0oOOoo )
  if 7 - 7: IIII - o0000oOoOoO0o / II111iiii * o00O0oo . oO0o0ooO0 * oO0o0ooO0
  for I1Iii1 in iIIiIiI1I1 :
   if 61 - 61: o0000oOoOoO0o % o0oO0 - oOo0O0Ooo / OoO0O00
   I1 = I1Iii1 . get ( 'title' )
   iIiiI1iI = I1Iii1 . get ( 'thumbnail' )
   IIIi = I1Iii1 . get ( 'age' )
   if IIIi == '18' or IIIi == '19' or IIIi == '21' : I1 += ' (%s)' % ( IIIi )
   if 4 - 4: OoooooooOO - i1IIi % o00O0oo - OoOO0ooOOoo0O * OOooOOo
   o00oOo0oOoo = { 'plot' : I1
 , 'mpaa' : IIIi
 , 'mediatype' : 'movie'
 }
   if 85 - 85: OoooooooOO * iIii1I11I1II1 . oO0o0ooO0 / OoooooooOO % oo % O0
   oO00O0O0O = { 'mode' : 'MOVIE'
 , 'contentid' : I1Iii1 . get ( 'videoid' )

   , 'title' : I1
 , 'thumbnail' : iIiiI1iI
 , 'age' : IIIi
 }
   if 36 - 36: o00O0oo / II111iiii / IIII / IIII + ii11ii1ii
   self . add_dir ( I1 , sublabel = '' , img = iIiiI1iI , infoLabels = o00oOo0oOoo , isFolder = False , params = oO00O0O0O )
   if 95 - 95: IIII
  if I11i1 :
   oO00O0O0O = { }
   oO00O0O0O [ 'mode' ] = 'MOVIE_LIST'
   oO00O0O0O [ 'subapi' ] = i1
   oO00O0O0O [ 'page' ] = str ( OO0oOOoo + 1 )
   I1 = '[B]%s >>[/B]' % '다음 페이지'
   II1I1iii1iII = str ( OO0oOOoo + 1 )
   self . add_dir ( I1 , sublabel = II1I1iii1iII , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 51 - 51: II111iiii + IIII . i1IIi . ii11ii1ii + I1ii11iIi11i * oo
  if len ( iIIiIiI1I1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 72 - 72: OoOO + OoOO / II111iiii . OoooooooOO % o00O0oo
  if 49 - 49: OoOO . oOo0O0Ooo - OoO0O00 * OoooooooOO . OoO0O00
  if 2 - 2: OoooooooOO % OoOO0ooOOoo0O
  if 63 - 63: oo % iIii1I11I1II1
 def dp_Episode_List ( self , args ) :
  if 39 - 39: oO0o0ooO0 / II111iiii / ii11ii1ii % oo
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 89 - 89: O0oO + OoooooooOO + O0oO * i1IIi + iIii1I11I1II1 % o0000oOoOoO0o
  oOo0oO = args . get ( 'videoid' )
  IIi1IIIIi = args . get ( 'vidtype' )
  OO0oOOoo = int ( args . get ( 'page' ) )
  if 70 - 70: OoOO0ooOOoo0O / II111iiii - iIii1I11I1II1 - oO0o0ooO0
  iIIiIiI1I1 , I11i1 = self . WavveObj . Get_Episode_List ( oOo0oO , IIi1IIIIi , OO0oOOoo , orderby = self . get_winEpisodeOrderby ( ) )
  if 11 - 11: iIii1I11I1II1 . OoooooooOO . II111iiii / i1IIi - o0000oOoOoO0o
  for I1Iii1 in iIIiIiI1I1 :
   if 30 - 30: I1ii11iIi11i
   II1I1iii1iII = '%s회, %s(%s)' % ( I1Iii1 . get ( 'episodenumber' ) , I1Iii1 . get ( 'releasedate' ) , I1Iii1 . get ( 'releaseweekday' ) )
   Ii111 = '[%s]\n\n%s' % ( I1Iii1 . get ( 'episodetitle' ) , I1Iii1 . get ( 'synopsis' ) )
   if 67 - 67: O0
   o00oOo0oOoo = { 'mediatype' : 'episode'
 , 'title' : I1Iii1 . get ( 'programtitle' )
 , 'year' : int ( I1Iii1 . get ( 'releasedate' ) [ : 4 ] )
 , 'aired' : I1Iii1 . get ( 'releasedate' )
 , 'mpaa' : I1Iii1 . get ( 'age' )
 , 'episode' : I1Iii1 . get ( 'episodenumber' )
 , 'duration' : I1Iii1 . get ( 'playtime' )
 , 'plot' : Ii111
 , 'cast' : I1Iii1 . get ( 'episodeactors' )
 }
   if 52 - 52: II111iiii . o0oO0 / I1ii11iIi11i / OoooooooOO . i11iIiiIii
   oO00O0O0O = { 'mode' : 'VOD'
 , 'programid' : I1Iii1 . get ( 'programid' )
 , 'contentid' : I1Iii1 . get ( 'contentid' )
 , 'thumbnail' : I1Iii1 . get ( 'thumbnail' )
 , 'title' : I1Iii1 . get ( 'programtitle' )
 , 'subtitle' : II1I1iii1iII
 }
   if 30 - 30: o0000oOoOoO0o / o00O0oo . IIII . OoooooooOO - OoO0O00
   self . add_dir ( I1Iii1 . get ( 'programtitle' ) , sublabel = II1I1iii1iII , img = I1Iii1 . get ( 'thumbnail' ) , infoLabels = o00oOo0oOoo , isFolder = False , params = oO00O0O0O )
   if 44 - 44: O0 * OoooooooOO % o0oO0 + II111iiii
  if OO0oOOoo == 1 :
   o00oOo0oOoo = { 'plot' : '정렬순서를 변경합니다.' }
   oO00O0O0O = { }
   oO00O0O0O [ 'mode' ] = 'ORDER_BY'
   if self . get_winEpisodeOrderby ( ) == 'desc' :
    I1 = '정렬순서변경 : 최신화부터 -> 1회부터'
    oO00O0O0O [ 'orderby' ] = 'asc'
   else :
    I1 = '정렬순서변경 : 1회부터 -> 최신화부터'
    oO00O0O0O [ 'orderby' ] = 'desc'
   self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = o00oOo0oOoo , isFolder = False , params = oO00O0O0O )
   if 39 - 39: OoOO % iIii1I11I1II1 % O0 % OoooooooOO * ii11ii1ii + oO0o0ooO0
   if 68 - 68: OoO0O00 + i11iIiiIii
  if I11i1 :
   oO00O0O0O = { }
   oO00O0O0O [ 'mode' ] = 'EPISODE_LIST'
   oO00O0O0O [ 'videoid' ] = I1Iii1 . get ( 'programid' )
   oO00O0O0O [ 'vidtype' ] = 'programid'
   oO00O0O0O [ 'page' ] = str ( OO0oOOoo + 1 )
   I1 = '[B]%s >>[/B]' % '다음 페이지'
   II1I1iii1iII = str ( OO0oOOoo + 1 )
   self . add_dir ( I1 , sublabel = II1I1iii1iII , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 69 - 69: iIii1I11I1II1 * iIii1I11I1II1 * i11iIiiIii + oo / OoOO0ooOOoo0O % o00O0oo
  if len ( iIIiIiI1I1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 58 - 58: OoOO0ooOOoo0O * OOooOOo + O0 % OoOO0ooOOoo0O
  if 25 - 25: OoO0O00 % ii11ii1ii * o0oO0
  if 6 - 6: oO0o0ooO0 . IIII * I1ii11iIi11i . i1IIi
  if 98 - 98: i1IIi
 def dp_LiveChannel_List ( self , args ) :
  if 65 - 65: I1ii11iIi11i / oOo0O0Ooo % IIII
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 45 - 45: I1ii11iIi11i
  oOooOO = args . get ( 'genre' )
  ooO = args . get ( 'baseapi' )
  iIIiIiI1I1 = self . WavveObj . Get_LiveChannel_List ( oOooOO , ooO )
  if 31 - 31: OoOO0ooOOoo0O / OoO0O00 * i1IIi . I1ii11iIi11i
  if 57 - 57: OoOO0ooOOoo0O + iIii1I11I1II1 % i1IIi % oo
  for I1Iii1 in iIIiIiI1I1 :
   if 83 - 83: OOooOOo / i11iIiiIii % iIii1I11I1II1 . o0000oOoOoO0o % OoOO . OoooooooOO
   o0ooO = I1Iii1 . get ( 'channelid' )
   OoOOOo0o0ooo = I1Iii1 . get ( 'studio' )
   I1iiiiI1iI = I1Iii1 . get ( 'tvshowtitle' )
   iIiiI1iI = I1Iii1 . get ( 'thumbnail' )
   IIIi = I1Iii1 . get ( 'age' )
   o00oO00 = I1Iii1 . get ( 'epg' )
   if 59 - 59: OoOO0ooOOoo0O + iIii1I11I1II1 * OOooOOo + O0oO . oO0o0ooO0
   o00oOo0oOoo = { 'mediatype' : 'video'
 , 'mpaa' : IIIi
 , 'title' : '%s < %s >' % ( OoOOOo0o0ooo , I1iiiiI1iI )
 , 'tvshowtitle' : I1iiiiI1iI
 , 'studio' : OoOOOo0o0ooo
 , 'plot' : '%s\n\n%s' % ( OoOOOo0o0ooo , o00oO00 )
 }
   if 49 - 49: OoooooooOO * o0000oOoOoO0o - OoO0O00 . OoOO
   oO00O0O0O = { 'mode' : 'LIVE'
 , 'contentid' : o0ooO

   }
   if 89 - 89: o0oO0 + o00O0oo * o0oO0 / o0oO0
   self . add_dir ( label = OoOOOo0o0ooo , sublabel = I1iiiiI1iI , img = iIiiI1iI , infoLabels = o00oOo0oOoo , isFolder = False , params = oO00O0O0O )
   if 46 - 46: oOo0O0Ooo
  if len ( iIIiIiI1I1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 71 - 71: o0000oOoOoO0o / o0000oOoOoO0o * OoOO * OoOO / II111iiii
  if 35 - 35: OoOO0ooOOoo0O * OOooOOo * oo % OoO0O00 . I1ii11iIi11i
  if 58 - 58: o0000oOoOoO0o + II111iiii * oO0o0ooO0 * i11iIiiIii - iIii1I11I1II1
  if 68 - 68: OoooooooOO % II111iiii
  if 26 - 26: II111iiii % i11iIiiIii % iIii1I11I1II1 % o0000oOoOoO0o * o0000oOoOoO0o * ii11ii1ii
 def dp_Search_List ( self , args ) :
  if 24 - 24: II111iiii % O0oO - o0oO0 + oo * ii11ii1ii
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 2 - 2: o00O0oo - IIII
  II1iIi11 = args . get ( 'sType' )
  OO0oOOoo = int ( args . get ( 'page' ) )
  if 83 - 83: OoOO % OOooOOo % o00O0oo - II111iiii * OoOO0ooOOoo0O / OoooooooOO
  if 'search_key' in args :
   IIIiIi = args . get ( 'search_key' )
  else :
   IIIiIi = self . get_keyboard_input ( __language__ ( 30906 ) . encode ( 'utf-8' ) )
   if not IIIiIi : return
   if 34 - 34: OoooooooOO . O0 / OoOO * I1ii11iIi11i - ii11ii1ii
  iIIiIiI1I1 , I11i1 = self . WavveObj . Get_Search_List ( IIIiIi , II1iIi11 , OO0oOOoo , exclusion21 = self . get_settings_exclusion21 ( ) )
  if 36 - 36: i1IIi / O0 / oOo0O0Ooo - O0 - i1IIi
  for I1Iii1 in iIIiIiI1I1 :
   if 22 - 22: i1IIi + o00O0oo
   I1 = I1Iii1 . get ( 'title' )
   iIiiI1iI = I1Iii1 . get ( 'thumbnail' )
   IIIi = I1Iii1 . get ( 'age' )
   if IIIi == '18' or IIIi == '19' or IIIi == '21' : I1 += ' (%s)' % ( IIIi )
   if 54 - 54: o0oO0 % OoOO0ooOOoo0O . O0oO + OoOO - OoOO0ooOOoo0O * oo
   o00oOo0oOoo = { 'mediatype' : 'episode' if II1iIi11 == 'vod' else 'movie'
 , 'mpaa' : IIIi
 , 'title' : I1
 , 'plot' : I1
 }
   if 92 - 92: OOooOOo + O0oO / OoO0O00 % oOo0O0Ooo % IIII . OoooooooOO
   if II1iIi11 == 'vod' :
    oO00O0O0O = { 'mode' : 'EPISODE_LIST'
 , 'videoid' : I1Iii1 . get ( 'videoid' )
 , 'vidtype' : I1Iii1 . get ( 'vidtype' )
 , 'page' : '1'
 }
    i1I11i1I = True
    if 52 - 52: o0oO0 / i11iIiiIii - OoOO0ooOOoo0O . IIII % iIii1I11I1II1 + OOooOOo
   else :
    oO00O0O0O = { 'mode' : 'MOVIE'
 , 'contentid' : I1Iii1 . get ( 'videoid' )

    , 'title' : I1
 , 'thumbnail' : iIiiI1iI
 , 'age' : IIIi
 }
    i1I11i1I = False
    if 71 - 71: OoOO % o0000oOoOoO0o * I1ii11iIi11i . O0 / o00O0oo . ii11ii1ii
   self . add_dir ( I1 , sublabel = '' , img = iIiiI1iI , infoLabels = o00oOo0oOoo , isFolder = i1I11i1I , params = oO00O0O0O )
   if 58 - 58: OoO0O00 / OoOO
  if I11i1 :
   if 44 - 44: OoOO0ooOOoo0O
   oO00O0O0O [ 'mode' ] = 'SEARCH_LIST'
   oO00O0O0O [ 'sType' ] = II1iIi11
   oO00O0O0O [ 'page' ] = str ( OO0oOOoo + 1 )
   oO00O0O0O [ 'search_key' ] = IIIiIi
   I1 = '[B]%s >>[/B]' % '다음 페이지'
   II1I1iii1iII = str ( OO0oOOoo + 1 )
   self . add_dir ( I1 , sublabel = II1I1iii1iII , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 54 - 54: o00O0oo - o0000oOoOoO0o - O0oO . iIii1I11I1II1
  if len ( iIIiIiI1I1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle )
  if 79 - 79: o00O0oo . oOo0O0Ooo
  if 40 - 40: OOooOOo + OoO0O00 . OOooOOo % o0oO0
  if 15 - 15: o00O0oo * OoO0O00 % ii11ii1ii * iIii1I11I1II1 - i11iIiiIii
  if 60 - 60: oo * O0oO % oOo0O0Ooo + OoOO
 def dp_Watch_List ( self , args ) :
  II1iIi11 = args . get ( 'sType' )
  I1i1I = self . get_settings_direct_replay ( )
  if 52 - 52: i1IIi
  iIIiIiI1I1 = self . Load_Watched_List ( II1iIi11 )
  if 84 - 84: o00O0oo / IIII
  for I1Iii1 in iIIiIiI1I1 :
   OOOooo0OooOoO = dict ( urlparse . parse_qsl ( I1Iii1 ) )
   if 91 - 91: OoOO + oo
   OoOooo = OOOooo0OooOoO . get ( 'code' ) . strip ( )
   I1 = OOOooo0OooOoO . get ( 'title' ) . strip ( )
   II1I1iii1iII = OOOooo0OooOoO . get ( 'subtitle' ) . strip ( )
   if II1I1iii1iII == 'None' : II1I1iii1iII = ''
   iIiiI1iI = OOOooo0OooOoO . get ( 'img' ) . strip ( )
   oOo0oO = OOOooo0OooOoO . get ( 'videoid' ) . strip ( )
   if 74 - 74: iIii1I11I1II1 * IIII % I1ii11iIi11i
   if 36 - 36: OoooooooOO - OoOO
   o00oOo0oOoo = { 'plot' : '%s\n%s' % ( I1 , II1I1iii1iII ) }
   if 85 - 85: OOooOOo . IIII / O0 . OOooOOo . ii11ii1ii . oOo0O0Ooo
   if II1iIi11 == 'vod' :
    if I1i1I == False or oOo0oO == None :
     oO00O0O0O = { 'mode' : 'EPISODE_LIST'
 , 'videoid' : OoOooo
 , 'vidtype' : 'programid'
 , 'page' : '1'
 }
     i1I11i1I = True
    else :
     oO00O0O0O = { 'mode' : 'VOD'
 , 'programid' : OoOooo
 , 'contentid' : oOo0oO
 , 'title' : I1
 , 'subtitle' : II1I1iii1iII
 , 'thumbnail' : iIiiI1iI
 }
     i1I11i1I = False
     if 60 - 60: OOooOOo - I1ii11iIi11i * OoO0O00 % o00O0oo / II111iiii % I1ii11iIi11i
   else :
    oO00O0O0O = { 'mode' : 'MOVIE'
 , 'contentid' : OoOooo

    , 'title' : I1
 , 'subtitle' : II1I1iii1iII
 , 'thumbnail' : iIiiI1iI
 }
    i1I11i1I = False
    if 52 - 52: OoOO0ooOOoo0O - oO0o0ooO0 * OoOO
   self . add_dir ( I1 , sublabel = II1I1iii1iII , img = iIiiI1iI , infoLabels = o00oOo0oOoo , isFolder = i1I11i1I , params = oO00O0O0O )
   if 17 - 17: OoooooooOO + OoOO0ooOOoo0O * o0000oOoOoO0o * I1ii11iIi11i
   if 36 - 36: O0 + OoO0O00
  o00oOo0oOoo = { 'plot' : '시청목록을 삭제합니다.' }
  I1 = '*** 시청목록 삭제 ***'
  oO00O0O0O = { 'mode' : 'MYVIEW_REMOVE'
 , 'sType' : II1iIi11
 }
  self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = o00oOo0oOoo , isFolder = False , params = oO00O0O0O )
  if 5 - 5: OoO0O00 * I1ii11iIi11i
  if 46 - 46: o0oO0
  xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 33 - 33: oO0o0ooO0 - II111iiii * OoooooooOO - OoO0O00 - OoOO0ooOOoo0O
  if 84 - 84: O0oO + OoO0O00 - I1ii11iIi11i * I1ii11iIi11i
  if 61 - 61: OoooooooOO . OoOO . OoooooooOO / OoO0O00
  if 72 - 72: i1IIi
  if 82 - 82: I1ii11iIi11i + OoooooooOO / i11iIiiIii * ii11ii1ii . OoooooooOO
  if 63 - 63: ii11ii1ii
 def wavve_main ( self ) :
  if 6 - 6: o0oO0 / ii11ii1ii
  iIiIIi1 = self . main_params . get ( 'mode' , None )
  if 57 - 57: o0000oOoOoO0o
  if 67 - 67: oOo0O0Ooo . o0oO0
  if iIiIIi1 == 'LOGOUT' :
   self . logout ( )
   return
   if 87 - 87: OoOO % o00O0oo
  self . login_main ( )
  if 83 - 83: II111iiii - o0000oOoOoO0o
  if 35 - 35: i1IIi - iIii1I11I1II1 + i1IIi
  if iIiIIi1 is None :
   self . dp_Main_List ( )
   if 86 - 86: iIii1I11I1II1 + I1ii11iIi11i . i11iIiiIii - o00O0oo
  elif iIiIIi1 in [ 'LIVE' , 'VOD' , 'MOVIE' ] :
   self . play_VIDEO ( self . main_params )
   if 51 - 51: I1ii11iIi11i
  elif iIiIIi1 == 'LIVE_CATAGORY' :
   self . dp_LiveCatagory_List ( self . main_params )
   if 14 - 14: IIII % OoOO % OoO0O00 - i11iIiiIii
  elif iIiIIi1 == 'MAIN_CATAGORY' :
   self . dp_MainCatagory_List ( self . main_params )
   if 53 - 53: o00O0oo % OoO0O00
  elif iIiIIi1 == 'SUPERSECTION_LIST' :
   self . dp_SuperSection_List ( self . main_params )
   if 59 - 59: OoOO0ooOOoo0O % iIii1I11I1II1 . i1IIi + II111iiii * IIII
  elif iIiIIi1 == 'BANDLIVESECTION_LIST' :
   self . dp_BandLiveSection_List ( self . main_params )
   if 41 - 41: o00O0oo % ii11ii1ii
  elif iIiIIi1 == 'BAND2SECTION_LIST' :
   self . dp_Band2Section_List ( self . main_params )
   if 12 - 12: OoOO0ooOOoo0O
  elif iIiIIi1 == 'PROGRAM_LIST' :
   self . dp_Program_List ( self . main_params )
   if 69 - 69: OoooooooOO + OoOO0ooOOoo0O
  elif iIiIIi1 == 'EPISODE_LIST' :
   self . dp_Episode_List ( self . main_params )
   if 26 - 26: OoO0O00 + OoOO0ooOOoo0O / oOo0O0Ooo % I1ii11iIi11i % ii11ii1ii + II111iiii
  elif iIiIIi1 == 'MOVIE_LIST' :
   self . dp_Movie_List ( self . main_params )
   if 31 - 31: o0000oOoOoO0o % OoOO0ooOOoo0O * o0000oOoOoO0o
  elif iIiIIi1 == 'LIVE_LIST' :
   self . dp_LiveChannel_List ( self . main_params )
   if 45 - 45: i1IIi . oo + OoOO0ooOOoo0O - OoooooooOO % o0oO0
  elif iIiIIi1 == 'ORDER_BY' :
   self . dp_setEpOrderby ( self . main_params )
   if 1 - 1: iIii1I11I1II1
  elif iIiIIi1 == 'SEARCH_GROUP' :
   self . dp_Search_Group ( self . main_params )
   if 93 - 93: i1IIi . i11iIiiIii . OoO0O00
  elif iIiIIi1 == 'SEARCH_LIST' :
   self . dp_Search_List ( self . main_params )
   if 99 - 99: o0000oOoOoO0o - O0oO - OoOO % oOo0O0Ooo
  elif iIiIIi1 == 'WATCH_GROUP' :
   self . dp_Watch_Group ( self . main_params )
   if 21 - 21: II111iiii % ii11ii1ii . i1IIi - OoooooooOO
  elif iIiIIi1 == 'WATCH_LIST' :
   self . dp_Watch_List ( self . main_params )
   if 4 - 4: OoooooooOO . o0oO0
  elif iIiIIi1 == 'MYVIEW_REMOVE' :
   self . dp_WatchList_Delete ( self . main_params )
   if 78 - 78: ii11ii1ii + o0000oOoOoO0o - O0
  else :
   None
   if 10 - 10: O0oO % oo
   if 97 - 97: OoooooooOO - O0oO
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
