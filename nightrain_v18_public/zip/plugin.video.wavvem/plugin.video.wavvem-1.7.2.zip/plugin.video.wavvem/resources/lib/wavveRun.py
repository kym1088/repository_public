# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import os
import xbmcplugin , xbmcgui , xbmcaddon , xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import urlparse
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 73 - 73: II111iiii
xIiII1IiiIiI1 = [
 { 'title' : '홈' , 'mode' : 'SUPERSECTION_LIST' , 'suburl' : 'https://www.wavve.com/supermultisection/GN51' }
, { 'title' : 'LIVE 채널' , 'mode' : 'LIVE_CATAGORY' , 'sCode' : 'GN54' , 'sIndex' : '0' , 'sType' : 'live' }
 , { 'title' : '인기 드라마' , 'mode' : 'PROGRAM_LIST' , 'subapi' : 'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=01&WeekDay=all&uitype=VN4&uiparent=FN0&uirank=0&broadcastid=847243&uicode=VN4' , 'page' : '1' }
 , { 'title' : '인기 예능' , 'mode' : 'PROGRAM_LIST' , 'subapi' : 'apis.wavve.com/cf/vod/popularcontents?orderby=viewtime&contenttype=vod&genre=02&WeekDay=all&uitype=VN3&uiparent=FN0&uirank=0&broadcastid=783664&uicode=VN3' , 'page' : '1' }

, { 'title' : '분류별 - VOD 방송  - 최신순' , 'mode' : 'MAIN_CATAGORY' , 'sCode' : 'GN52' , 'sIndex' : '1' , 'sType' : 'vod' , 'orderby' : 'new' , 'ordernm' : '최신순' }
 , { 'title' : '분류별 - 해외시리즈 - 인기순' , 'mode' : 'MAIN_CATAGORY' , 'sCode' : 'GN52' , 'sIndex' : '2' , 'sType' : 'vod' , 'orderby' : 'viewtime' , 'ordernm' : '인기순' }
 , { 'title' : '분류별 - 해외시리즈 - 최신순' , 'mode' : 'MAIN_CATAGORY' , 'sCode' : 'GN52' , 'sIndex' : '2' , 'sType' : 'vod' , 'orderby' : 'new' , 'ordernm' : '최신순' }
 , { 'title' : '분류별 - 영화(Movie) - 인기순' , 'mode' : 'MAIN_CATAGORY' , 'sCode' : 'GN52' , 'sIndex' : '3' , 'sType' : 'movie' , 'orderby' : 'paid' , 'ordernm' : '인기순' }
 , { 'title' : '분류별 - 영화(Movie) - 업데이트순' , 'mode' : 'MAIN_CATAGORY' , 'sCode' : 'GN52' , 'sIndex' : '3' , 'sType' : 'movie' , 'orderby' : 'displaystart' , 'ordernm' : '업데이트순' }

# Ooo / oO - O0o00OoOoOO00
, { 'title' : '검색 (search)' , 'mode' : 'SEARCH_GROUP' }
 , { 'title' : 'Watched (시청목록)' , 'mode' : 'WATCH_GROUP' }
 ]
if 27 - 27: OOOo0 / Oo - Ooo00oOo00o . I1IiI
o0OOO = [
 { 'title' : 'VOD 검색' , 'mode' : 'SEARCH_LIST' , 'sType' : 'vod' }
 , { 'title' : '영화 검색' , 'mode' : 'SEARCH_LIST' , 'sType' : 'movie' }
 ]
if 13 - 13: ooOo + Ooo0O
xIiiIII111iI = [
 { 'title' : 'VOD 시청내역' , 'mode' : 'WATCH_LIST' , 'sType' : 'vod' }
 , { 'title' : '영화 시청내역' , 'mode' : 'WATCH_LIST' , 'sType' : 'movie' }
 ]
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - Ooo
__addon__ = xbmcaddon . Addon ( )
__language__ = __addon__ . getLocalizedString
__profile__ = xbmc . translatePath ( __addon__ . getAddonInfo ( 'profile' ) )
__version__ = __addon__ . getAddonInfo ( 'version' )
__addonid__ = __addon__ . getAddonInfo ( 'id' )
__addonname__ = __addon__ . getAddonInfo ( 'name' )
if 76 - 76: OOOo0
if 100 - 100: i1IIi . Oo0ooO0oo0oO / O0oo0OO0 * OoooooooOO + Ooo0O * I1IiI
O0IiiiIiI1iIiI1 = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
ooo0Oo0 = xbmc . translatePath ( os . path . join ( __profile__ , 'wavve_cookies.json' ) )
if 56 - 56: O0 . Oo0ooO0oo0oO * Oo
if 84 - 84: iIii1I11I1II1 . O0oo0OO0 / O0oo0OO0 % O0oo0OO0
from wavveCore import *
if 22 - 22: iii1I1I . O0oo0OO0
if 41 - 41: Oo0ooO0oo0oO . I1i1iI1i * O0oo0OO0 % i11iIiiIii
class o000o0o00o0Oo ( object ) :
 def __init__ ( self , in_addonurl , in_handle , in_params ) :
  self . _addon_url = in_addonurl
  self . _addon_handle = in_handle
  self . main_params = in_params
  self . WavveObj = xxI1Ii11I1Ii1i ( )
  if 80 - 80: OoooooooOO . Ooo
  if 87 - 87: I1IiI / I1i1iI1i + Oo0ooO0oo0oO - I1i1iI1i . I1i1iI1i / II111iiii
  if 11 - 11: Ooo % Oo - oO
 def addon_noti ( self , sting ) :
  try :
   oo0O000OoO = xbmcgui . Dialog ( )
   oo0O000OoO . notification ( __addonname__ , sting )
  except :
   None
   if 34 - 34: Ooo0O * Ooo
   if 31 - 31: II111iiii + O0o00OoOoOO00 . Oo0ooO0oo0oO
   if 68 - 68: Ooo - i11iIiiIii - O0o00OoOoOO00 / ooOo - O0o00OoOoOO00 + i1IIi
 def addon_log ( self , string ) :
  try :
   IiiIII111ii = string . encode ( 'utf-8' , 'ignore' )
  except :
   IiiIII111ii = 'addonException: addon_log'
   if 3 - 3: O00oOoOoO0o0O + O0
   if 42 - 42: ooOo / i1IIi + i11iIiiIii - iii1I1I
  oo0Ooo0 = xbmc . LOGINFO
  xbmc . log ( "[%s-%s]: %s" % ( __addonid__ , __version__ , IiiIII111ii ) , level = oo0Ooo0 )
  if 46 - 46: I1i1iI1i % I1i1iI1i - I1IiI * Oo % O00oOoOoO0o0O
  if 55 - 55: OOOo0 % i1IIi / iii1I1I - I1IiI - O0 / II111iiii
  if 28 - 28: iIii1I11I1II1 - i1IIi
  if 70 - 70: O0o00OoOoOO00 . O0o00OoOoOO00 - O0o00OoOoOO00 / Ooo00oOo00o * ooOo
 def get_keyboard_input ( self , title ) :
  OoO000 = None
  IIiiIiI1 = xbmc . Keyboard ( )
  IIiiIiI1 . setHeading ( title )
  xbmc . sleep ( 1000 )
  IIiiIiI1 . doModal ( )
  if ( IIiiIiI1 . isConfirmed ( ) ) :
   OoO000 = IIiiIiI1 . getText ( )
  return OoO000
  if 41 - 41: OOOo0
  if 13 - 13: oO . i11iIiiIii - iIii1I11I1II1 - OOOo0
  if 6 - 6: Ooo / oO % iii1I1I
  if 84 - 84: i11iIiiIii . Oo
 def get_settings_login_info ( self ) :
  o0O00oooo = __addon__ . getSetting ( 'id' )
  O00o = __addon__ . getSetting ( 'pw' )
  O00 = __addon__ . getSetting ( 'selected_profile' )
  return ( o0O00oooo , O00o , O00 )
  if 11 - 11: Ooo
  if 68 - 68: Ooo0O + ooOo . iIii1I11I1II1 - O0oo0OO0 % iIii1I11I1II1 - I1i1iI1i
  if 79 - 79: oO + Ooo - O00oOoOoO0o0O
 def get_selQuality ( self ) :
  try :
   oO00O00o0OOO0 = [ 1080 , 720 , 480 , 360 ]
   if 27 - 27: O0 % i1IIi * I1IiI + i11iIiiIii + OoooooooOO * i1IIi
   o0oo0o0O00OO = int ( __addon__ . getSetting ( 'selected_quality' ) )
   return oO00O00o0OOO0 [ o0oo0o0O00OO ]
  except :
   None
   if 80 - 80: i1IIi
  return 1080
  if 70 - 70: OOOo0 - Oo
  if 43 - 43: Ooo0O / II111iiii / OoooooooOO . Oo . iii1I1I
  if 19 - 19: Ooo0O + I1i1iI1i
 def get_settings_exclusion21 ( self ) :
  ooo = __addon__ . getSetting ( 'exclusion21' )
  if ooo == 'false' :
   return False
  else :
   return True
   if 18 - 18: Oo
   if 28 - 28: ooOo - O0oo0OO0 . O0oo0OO0 + OOOo0 - OoooooooOO + O0
   if 95 - 95: O0o00OoOoOO00 % I1IiI . O0
 def get_settings_direct_replay ( self ) :
  I1i1I = int ( __addon__ . getSetting ( 'direct_replay' ) )
  if I1i1I == 0 :
   return False
  else :
   return True
   if 80 - 80: OOOo0 - O0o00OoOoOO00
   if 87 - 87: I1IiI / Ooo0O - i1IIi * ooOo / OoooooooOO . O0
   if 1 - 1: II111iiii - Ooo0O / Ooo0O
 def get_settings_addinfo ( self ) :
  I1II1III11iii = __addon__ . getSetting ( 'add_infoyn' )
  if I1II1III11iii == 'false' :
   return False
  else :
   return True
   if 75 - 75: iIii1I11I1II1 / ooOo % Oo * OOOo0
   if 9 - 9: O0o00OoOoOO00
   if 33 - 33: I1i1iI1i . O00oOoOoO0o0O
   if 58 - 58: ooOo * i11iIiiIii / OOOo0 % Oo0ooO0oo0oO - Ooo00oOo00o / I1IiI
 def set_winCredential ( self , credential ) :
  ii11i1 = xbmcgui . Window ( 10000 )
  ii11i1 . setProperty ( 'WAVVE_M_CREDENTIAL' , credential )
  ii11i1 . setProperty ( 'WAVVE_M_LOGINTIME' , self . WavveObj . Get_Now_Datetime ( ) . strftime ( '%Y-%m-%d' ) )
  if 29 - 29: Ooo00oOo00o % Ooo + I1i1iI1i / Oo + ooOo * Oo
 def get_winCredential ( self ) :
  ii11i1 = xbmcgui . Window ( 10000 )
  return ii11i1 . getProperty ( 'WAVVE_M_CREDENTIAL' )
  if 42 - 42: iii1I1I + I1IiI
 def set_winEpisodeOrderby ( self , orderby ) :
  ii11i1 = xbmcgui . Window ( 10000 )
  ii11i1 . setProperty ( 'WAVVE_M_ORDERBY' , orderby )
  if 76 - 76: Oo0ooO0oo0oO - O0o00OoOoOO00
 def get_winEpisodeOrderby ( self ) :
  ii11i1 = xbmcgui . Window ( 10000 )
  return ii11i1 . getProperty ( 'WAVVE_M_ORDERBY' )
  if 70 - 70: I1i1iI1i
  if 61 - 61: Ooo00oOo00o . Ooo00oOo00o
  if 10 - 10: OOOo0 * O00oOoOoO0o0O . Ooo0O + II111iiii - I1i1iI1i * i1IIi
  if 56 - 56: Oo * O0oo0OO0 * II111iiii
 def add_dir ( self , label , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = '' ) :
  oO0ooO0OoOOOO = '%s?%s' % ( self . _addon_url , urllib . urlencode ( params ) )
  if 46 - 46: ooOo / Ooo00oOo00o
  if sublabel : I1 = '%s < %s >' % ( label , sublabel )
  else : I1 = label
  if not img : img = 'DefaultFolder.png'
  if 71 - 71: ooOo + I1i1iI1i % i11iIiiIii + Ooo00oOo00o - O0oo0OO0
  oO0OOoO0 = xbmcgui . ListItem ( I1 )
  oO0OOoO0 . setArt ( { 'thumbnailImage' : img , 'icon' : img , 'poster' : img } )
  if 34 - 34: O0oo0OO0 - O0oo0OO0 * Ooo + iii1I1I % O0oo0OO0
  if infoLabels : oO0OOoO0 . setInfo ( type = "video" , infoLabels = infoLabels )
  if not isFolder : oO0OOoO0 . setProperty ( 'IsPlayable' , 'true' )
  if 4 - 4: I1IiI
  xbmcplugin . addDirectoryItem ( self . _addon_handle , oO0ooO0OoOOOO , oO0OOoO0 , isFolder )
  if 93 - 93: O0o00OoOoOO00 % I1IiI . O0o00OoOoOO00 * Oo0ooO0oo0oO % iii1I1I . II111iiii
  if 38 - 38: Oo
  if 57 - 57: O0 / I1IiI * Oo0ooO0oo0oO / OOOo0 . II111iiii
  if 26 - 26: O00oOoOoO0o0O
 def dp_Main_List ( self ) :
  if 91 - 91: O0o00OoOoOO00 . Ooo00oOo00o + O0o00OoOoOO00 - O00oOoOoO0o0O / OoooooooOO
  for iII1 in xIiII1IiiIiI1 :
   I1 = iII1 . get ( 'title' )
   if 30 - 30: II111iiii - ooOo - i11iIiiIii % OOOo0 - II111iiii * iii1I1I
   oO00O0O0O = { 'mode' : iII1 . get ( 'mode' )
 , 'sCode' : iII1 . get ( 'sCode' )
 , 'sIndex' : iII1 . get ( 'sIndex' )
 , 'sType' : iII1 . get ( 'sType' )

 , 'suburl' : iII1 . get ( 'suburl' )
   , 'subapi' : iII1 . get ( 'subapi' )
 , 'page' : iII1 . get ( 'page' )
 , 'orderby' : iII1 . get ( 'orderby' )
 , 'ordernm' : iII1 . get ( 'ordernm' )
 }
   if 31 - 31: Ooo0O - II111iiii . Ooo0O
   if iII1 . get ( 'mode' ) == 'XXX' :
    i1I11i1I = False
   else :
    i1I11i1I = True
    if 81 - 81: iIii1I11I1II1 + iIii1I11I1II1 * O0oo0OO0 * I1i1iI1i % I1i1iI1i
   self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = None , isFolder = i1I11i1I , params = oO00O0O0O )
   if 81 - 81: i11iIiiIii % OOOo0 - ooOo
  if len ( xIiII1IiiIiI1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 68 - 68: Oo0ooO0oo0oO % i1IIi . O0oo0OO0 . Ooo00oOo00o
  if 92 - 92: O00oOoOoO0o0O . Oo0ooO0oo0oO
  if 31 - 31: Oo0ooO0oo0oO . OOOo0 / O0
  if 89 - 89: OOOo0
 def dp_Search_Group ( self , args ) :
  for OO0oOoOO0oOO0 in o0OOO :
   I1 = OO0oOoOO0oOO0 . get ( 'title' )
   if 86 - 86: ooOo
   oO00O0O0O = { 'mode' : OO0oOoOO0oOO0 . get ( 'mode' )
 , 'sType' : OO0oOoOO0oOO0 . get ( 'sType' )
 , 'page' : '1'
 }
   if 55 - 55: oO + iIii1I11I1II1 / OOOo0 * I1IiI - i11iIiiIii - iii1I1I
   self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 25 - 25: Ooo00oOo00o
  if len ( o0OOO ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 7 - 7: i1IIi / Ooo * Oo0ooO0oo0oO . O0oo0OO0 . iIii1I11I1II1
  if 13 - 13: ooOo / i11iIiiIii
  if 2 - 2: Ooo / O0 / Oo % OOOo0 % iii1I1I
  if 52 - 52: Oo
 def dp_Watch_Group ( self , args ) :
  for o0OO0oOO0O0 in xIiiIII111iI :
   I1 = o0OO0oOO0O0 . get ( 'title' )
   if 8 - 8: I1IiI
   oO00O0O0O = { 'mode' : o0OO0oOO0O0 . get ( 'mode' )
 , 'sType' : o0OO0oOO0O0 . get ( 'sType' )
 }
   if 7 - 7: Oo - Ooo
   self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 100 - 100: I1IiI + Ooo0O . ooOo * iii1I1I
  if len ( xIiiIII111iI ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 73 - 73: i1IIi + Ooo
  if 46 - 46: O0o00OoOoOO00 . oO - OoooooooOO
  if 93 - 93: O00oOoOoO0o0O
  if 10 - 10: Ooo0O
 def login_main ( self ) :
  ( OOooOO000 , OOoOoo , oO0000OOo00 ) = self . get_settings_login_info ( )
  if 27 - 27: Ooo % Ooo
  if 1 - 1: O0o00OoOoOO00 - I1IiI . Ooo0O . O0o00OoOoOO00 / oO + Ooo0O
  if not ( OOooOO000 and OOoOoo ) :
   oo0O000OoO = xbmcgui . Dialog ( )
   OooOOOOo = oo0O000OoO . yesno ( __language__ ( 30901 ) . encode ( 'utf8' ) , __language__ ( 30902 ) . encode ( 'utf8' ) )
   if OooOOOOo == True :
    __addon__ . openSettings ( )
    sys . exit ( )
   else :
    sys . exit ( )
    if 76 - 76: O0o00OoOoOO00
    if 29 - 29: ooOo + oO . i11iIiiIii - i1IIi / iIii1I11I1II1
  if self . get_winEpisodeOrderby ( ) == '' :
   self . set_winEpisodeOrderby ( 'desc' )
   if 26 - 26: Ooo0O . OoooooooOO
   if 39 - 39: O00oOoOoO0o0O - O0 % i11iIiiIii * Oo0ooO0oo0oO . O0oo0OO0
  if self . cookiefile_check ( ) : return
  if 58 - 58: O0o00OoOoOO00 % i11iIiiIii . O00oOoOoO0o0O / I1IiI
  O0o = int ( self . WavveObj . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' ) )
  OoOooO = xbmcgui . Window ( 10000 ) . getProperty ( 'WAVVE_M_LOGINTIME' )
  if 12 - 12: Ooo * O00oOoOoO0o0O % i1IIi % iIii1I11I1II1
  if OoOooO == None or OoOooO == '' :
   OoOooO = int ( '19000101' )
  else :
   OoOooO = int ( re . sub ( '-' , '' , OoOooO ) )
   if 20 - 20: ooOo % iii1I1I / iii1I1I + iii1I1I
   if 45 - 45: I1IiI - O0oo0OO0 - OoooooooOO - O0o00OoOoOO00 . II111iiii / O0
   if 51 - 51: O0 + O00oOoOoO0o0O
  if xbmcgui . Window ( 10000 ) . getProperty ( 'WAVVE_M_LOGINWAIT' ) == 'TRUE' :
   IIIII11I1IiI = 0
   while True :
    IIIII11I1IiI += 1
    if 16 - 16: iIii1I11I1II1
    time . sleep ( 0.05 )
    if 90 - 90: Oo % i1IIi / O0o00OoOoOO00
    if OoOooO >= O0o : return
    if IIIII11I1IiI > 600 : return
  else :
   xbmcgui . Window ( 10000 ) . setProperty ( 'WAVVE_M_LOGINWAIT' , 'TRUE' )
   if 44 - 44: oO . O0o00OoOoOO00 / Ooo00oOo00o + iii1I1I
  if OoOooO >= O0o :
   xbmcgui . Window ( 10000 ) . setProperty ( 'WAVVE_M_LOGINWAIT' , 'FALSE' )
   return
   if 65 - 65: O0
  if not self . WavveObj . GetCredential ( OOooOO000 , OOoOoo , oO0000OOo00 ) :
   self . addon_noti ( __language__ ( 30903 ) . encode ( 'utf8' ) )
   xbmcgui . Window ( 10000 ) . setProperty ( 'WAVVE_M_LOGINWAIT' , 'FALSE' )
   sys . exit ( )
   if 68 - 68: ooOo % Oo0ooO0oo0oO
   if 88 - 88: iIii1I11I1II1 - I1i1iI1i + ooOo
  self . set_winCredential ( self . WavveObj . LoadCredential ( ) )
  self . cookiefile_save ( )
  xbmcgui . Window ( 10000 ) . setProperty ( 'WAVVE_M_LOGINWAIT' , 'FALSE' )
  if 40 - 40: Ooo * iii1I1I + ooOo % O00oOoOoO0o0O
  if 74 - 74: I1IiI - oO + OoooooooOO + Oo0ooO0oo0oO / OOOo0
  if 23 - 23: O0
  if 85 - 85: iii1I1I
  if 84 - 84: Ooo . iIii1I11I1II1 % OoooooooOO + iii1I1I % OoooooooOO % O0o00OoOoOO00
  if 42 - 42: O0o00OoOoOO00 / Ooo0O / Oo + O00oOoOoO0o0O / OOOo0
 def dp_setEpOrderby ( self , args ) :
  o0OoOO000ooO0 = args . get ( 'orderby' )
  if 56 - 56: O00oOoOoO0o0O
  self . set_winEpisodeOrderby ( o0OoOO000ooO0 )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 86 - 86: II111iiii % Oo0ooO0oo0oO
  if 15 - 15: i1IIi * Ooo + i11iIiiIii
  if 6 - 6: I1i1iI1i / i11iIiiIii + O00oOoOoO0o0O * I1IiI
  if 80 - 80: II111iiii
  if 83 - 83: Ooo0O . i11iIiiIii + II111iiii . Oo * Ooo0O
 def play_VIDEO ( self , args ) :
  if 53 - 53: II111iiii
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 31 - 31: O0o00OoOoOO00
  o0O = args . get ( 'mode' )
  IiII = args . get ( 'contentid' )
  ii1iII1II = args . get ( 'pvrmode' )
  Iii1I1I11iiI1 = self . get_selQuality ( )
  if 18 - 18: ooOo + O00oOoOoO0o0O - iii1I1I . II111iiii + i11iIiiIii
  self . addon_log ( IiII + ' - ' + o0O )
  iI1Ii1iI11iiI , OO0OO0O00oO0 , oOI1Ii1I1 , IiII111iI1ii1 = self . WavveObj . GetStreamingURL ( o0O , IiII , Iii1I1I11iiI1 , ii1iII1II )
  if 37 - 37: I1IiI - Oo0ooO0oo0oO % oO
  OOOoo0OO = '%s|Cookie=%s' % ( iI1Ii1iI11iiI , OO0OO0O00oO0 )
  self . addon_log ( OOOoo0OO )
  if 57 - 57: O0o00OoOoOO00 / I1i1iI1i
  if iI1Ii1iI11iiI == '' :
   self . addon_noti ( __language__ ( 30907 ) . encode ( 'utf8' ) )
   return
   if 29 - 29: iIii1I11I1II1 + OOOo0 * O0o00OoOoOO00 * ooOo . Ooo * Ooo
  I111I1Iiii1i = xbmcgui . ListItem ( path = OOOoo0OO )
  if 56 - 56: Ooo00oOo00o % O0 - Ooo
  if oOI1Ii1I1 :
   self . addon_log ( '!!streaming_drm!!' )
   O00o0OO0 = oOI1Ii1I1 [ 'customdata' ]
   IIi1I1iiiii = oOI1Ii1I1 [ 'drmhost' ]
   if 71 - 71: O0oo0OO0 * II111iiii * I1IiI
   oOOo0 = inputstreamhelper . Helper ( 'mpd' , drm = 'widevine' )
   if 16 - 16: I1IiI % Ooo00oOo00o * i11iIiiIii % i11iIiiIii
   if oOOo0 . check_inputstream ( ) :
    if 65 - 65: iii1I1I - I1IiI + I1IiI + II111iiii
    if o0O == 'MOVIE' :
     o0oooOOoOo0 = 'https://www.wavve.com/player/movie?movieid=%s' % IiII
    else :
     o0oooOOoOo0 = 'https://www.wavve.com/player/vod?programid=%s&page=1' % IiII
     if 74 - 74: iIii1I11I1II1 * Ooo00oOo00o + OOOo0 / i1IIi / II111iiii . oO
    oooOo0OOOoo0 = { 'content-type' : 'application/octet-stream'
 , 'origin' : 'https://www.wavve.com'
 , 'pallycon-customdata' : O00o0OO0
 , 'referer' : o0oooOOoOo0
 , 'sec-fetch-dest' : 'empty'
    , 'sec-fetch-mode' : 'cors'
 , 'sec-fetch-site' : 'same-site'
 , 'user-agent' : O0IiiiIiI1iIiI1
 }
    OOoO = IIi1I1iiiii + '|' + urllib . urlencode ( oooOo0OOOoo0 ) + '|R{SSM}|'
    if 89 - 89: Oo + O0o00OoOoOO00 * Ooo0O * iii1I1I
    I111I1Iiii1i . setProperty ( 'inputstreamaddon' , oOOo0 . inputstream_addon )
    I111I1Iiii1i . setProperty ( 'inputstream.adaptive.manifest_type' , 'mpd' )
    I111I1Iiii1i . setProperty ( 'inputstream.adaptive.license_type' , 'com.widevine.alpha' )
    I111I1Iiii1i . setProperty ( 'inputstream.adaptive.license_key' , OOoO )
    I111I1Iiii1i . setProperty ( 'inputstream.adaptive.stream_headers' , 'user-agent=%s&Cookie=%s' % ( O0IiiiIiI1iIiI1 , OO0OO0O00oO0 ) )
    if 37 - 37: OoooooooOO - O0 - Oo
  xbmcplugin . setResolvedUrl ( self . _addon_handle , True , I111I1Iiii1i )
  if 77 - 77: ooOo * iIii1I11I1II1
  oO00oOOoooO = False
  if IiII111iI1ii1 :
   self . addon_noti ( IiII111iI1ii1 . encode ( 'utf-8' ) )
   oO00oOOoooO = True
  else :
   if '/preview.' in urlparse . urlsplit ( iI1Ii1iI11iiI ) . path :
    self . addon_noti ( __language__ ( 30908 ) . encode ( 'utf8' ) )
    oO00oOOoooO = True
    if 46 - 46: Ooo - OoooooooOO - Ooo0O * II111iiii
    if 34 - 34: Ooo0O - O00oOoOoO0o0O / ooOo + Ooo00oOo00o * iii1I1I
  try :
   OO = args . get ( 'programid' ) if args . get ( 'mode' ) == 'VOD' else args . get ( 'contentid' )
   if args . get ( 'mode' ) in [ 'VOD' , 'MOVIE' ] and args . get ( 'title' ) and args . get ( 'age' ) != '21' and oO00oOOoooO == False and OO != '-' :
    oO00O0O0O = { 'code' : OO
 , 'img' : args . get ( 'thumbnail' )
 , 'title' : args . get ( 'title' )
 , 'subtitle' : args . get ( 'subtitle' )
 , 'videoid' : args . get ( 'contentid' )
    }
    self . Save_Watched_List ( args . get ( 'mode' ) . lower ( ) , oO00O0O0O )
  except :
   None
   if 97 - 97: Ooo00oOo00o % Ooo00oOo00o % I1IiI / O00oOoOoO0o0O - iIii1I11I1II1
   if 69 - 69: Oo0ooO0oo0oO
   if 11 - 11: Ooo
   if 16 - 16: iii1I1I + O0oo0OO0 * O0 % i1IIi . Ooo
   if 67 - 67: OoooooooOO / Ooo * iii1I1I + Ooo0O
   if 65 - 65: OoooooooOO - Ooo00oOo00o / I1i1iI1i / II111iiii / i1IIi
 def Load_Watched_List ( self , genre ) :
  try :
   o00oo0 = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % genre ) )
   if 38 - 38: I1i1iI1i % II111iiii % Ooo0O / O0o00OoOoOO00 + OOOo0 / i1IIi
   OoOOo0OOoO = open ( o00oo0 , 'r' )
   ooO0O00Oo0o = OoOOo0OOoO . readlines ( )
   OoOOo0OOoO . close ( )
  except :
   ooO0O00Oo0o = [ ]
   if 65 - 65: Ooo00oOo00o . Ooo0O - Oo0ooO0oo0oO * O0oo0OO0 / Oo0ooO0oo0oO / I1i1iI1i
  return ooO0O00Oo0o
  if 40 - 40: I1i1iI1i * O0oo0OO0 * i11iIiiIii
  if 57 - 57: I1i1iI1i
  if 29 - 29: OOOo0 - O0oo0OO0 * OoooooooOO + OoooooooOO . II111iiii + OoooooooOO
  if 74 - 74: iii1I1I - O0oo0OO0 / O00oOoOoO0o0O * O0 - ooOo
 def Save_Watched_List ( self , genre , in_params ) :
  try :
   o00oo0 = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % genre ) )
   iiii1 = self . Load_Watched_List ( genre )
   if 96 - 96: i11iIiiIii % ooOo
   OoOOo0OOoO = open ( o00oo0 , 'w' )
   ooO = urllib . urlencode ( in_params )
   ooO = ooO + '\n'
   OoOOo0OOoO . write ( ooO )
   if 51 - 51: Ooo % Oo0ooO0oo0oO . I1IiI / iIii1I11I1II1 / Ooo0O . I1IiI
   IIIii11 = 0
   for iiIiIIIiiI in iiii1 :
    iiI1IIIi = dict ( urlparse . parse_qsl ( iiIiIIIiiI ) )
    if 47 - 47: oO % Ooo0O % i11iIiiIii - O0 + I1i1iI1i
    ooO000OO0O00O = in_params . get ( 'code' ) . strip ( )
    OOOoOO0o = iiI1IIIi . get ( 'code' ) . strip ( )
    if genre == 'vod' and self . get_settings_direct_replay ( ) == True :
     ooO000OO0O00O = in_params . get ( 'videoid' ) . strip ( )
     OOOoOO0o = iiI1IIIi . get ( 'videoid' ) . strip ( ) if OOOoOO0o != None else '-'
     if 1 - 1: II111iiii
    if ooO000OO0O00O != OOOoOO0o :
     OoOOo0OOoO . write ( iiIiIIIiiI )
     IIIii11 += 1
     if IIIii11 >= 50 : break
     if 68 - 68: O00oOoOoO0o0O - Ooo / Oo0ooO0oo0oO / Ooo0O
   OoOOo0OOoO . close ( )
  except :
   None
   if 12 - 12: iii1I1I + i11iIiiIii * iIii1I11I1II1 / Ooo00oOo00o . Ooo0O
   if 5 - 5: i1IIi + O0oo0OO0 / Oo . O00oOoOoO0o0O / Ooo0O
   if 32 - 32: Ooo % iIii1I11I1II1 / i1IIi - Ooo
   if 7 - 7: Oo0ooO0oo0oO * O0o00OoOoOO00 - I1i1iI1i + ooOo * Ooo % O0o00OoOoOO00
 def Delete_Watched_List ( self , genre ) :
  try :
   o00oo0 = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % genre ) )
   OoOOo0OOoO = open ( o00oo0 , 'w' )
   OoOOo0OOoO . write ( '' )
   OoOOo0OOoO . close ( )
  except :
   None
   if 15 - 15: OOOo0 % Ooo * Ooo0O
   if 81 - 81: I1i1iI1i - iIii1I11I1II1 - i1IIi / Oo0ooO0oo0oO - O0 * Ooo0O
   if 20 - 20: I1IiI % O0oo0OO0
   if 19 - 19: Ooo00oOo00o % O0oo0OO0 + I1i1iI1i / Oo0ooO0oo0oO . I1i1iI1i
 def dp_WatchList_Delete ( self , args ) :
  IiIi1I1 = args . get ( 'sType' )
  if 39 - 39: II111iiii + OOOo0 - I1i1iI1i . OOOo0
  oo0O000OoO = xbmcgui . Dialog ( )
  OooOOOOo = oo0O000OoO . yesno ( __language__ ( 30904 ) . encode ( 'utf8' ) , __language__ ( 30905 ) . encode ( 'utf8' ) )
  if OooOOOOo == False : sys . exit ( )
  if 84 - 84: O0o00OoOoOO00 + i1IIi - II111iiii . Ooo00oOo00o * OoooooooOO + Ooo
  self . Delete_Watched_List ( IiIi1I1 )
  if 38 - 38: ooOo + II111iiii % I1i1iI1i % OOOo0 - iii1I1I / OoooooooOO
  xbmc . executebuiltin ( "Container.Refresh" )
  if 73 - 73: Oo * O0 - i11iIiiIii
  if 85 - 85: iii1I1I % O00oOoOoO0o0O + Ooo0O / Oo . I1IiI + ooOo
  if 62 - 62: i11iIiiIii + i11iIiiIii - Oo
  if 28 - 28: O00oOoOoO0o0O . O00oOoOoO0o0O % iIii1I11I1II1 * iIii1I11I1II1 . Oo / O00oOoOoO0o0O
 def logout ( self ) :
  oo0O000OoO = xbmcgui . Dialog ( )
  OooOOOOo = oo0O000OoO . yesno ( __language__ ( 30910 ) . encode ( 'utf8' ) , __language__ ( 30905 ) . encode ( 'utf8' ) )
  if OooOOOOo == False : sys . exit ( )
  if 27 - 27: O0o00OoOoOO00 + I1i1iI1i - i1IIi
  self . wininfo_clear ( )
  if 69 - 69: O0oo0OO0 - O0 % Ooo00oOo00o + i11iIiiIii . OOOo0 / O0o00OoOoOO00
  if 79 - 79: O0 * i11iIiiIii - O0oo0OO0 / O0oo0OO0
  if os . path . isfile ( ooo0Oo0 ) : os . remove ( ooo0Oo0 )
  if 48 - 48: O0
  self . addon_noti ( __language__ ( 30909 ) . encode ( 'utf-8' ) )
  if 93 - 93: i11iIiiIii - Ooo * Ooo00oOo00o * Ooo0O % O0 + OoooooooOO
  if 25 - 25: O0oo0OO0 + iii1I1I / I1i1iI1i . Oo % O0 * O0o00OoOoOO00
  if 84 - 84: I1i1iI1i % iii1I1I + i11iIiiIii
  if 28 - 28: oO + O0o00OoOoOO00 * ooOo % I1IiI . Ooo0O % O0
 def wininfo_clear ( self ) :
  if 16 - 16: Ooo0O - iIii1I11I1II1 / Ooo . II111iiii + iIii1I11I1II1
  ii11i1 = xbmcgui . Window ( 10000 )
  ii11i1 . setProperty ( 'WAVVE_M_CREDENTIAL' , '' )
  ii11i1 . setProperty ( 'WAVVE_M_LOGINTIME' , '' )
  if 19 - 19: O0o00OoOoOO00 - oO . O0
  if 60 - 60: II111iiii + oO
  if 9 - 9: I1i1iI1i * OoooooooOO - iIii1I11I1II1 + OOOo0 / O0o00OoOoOO00 . O0o00OoOoOO00
  if 49 - 49: II111iiii
 def cookiefile_save ( self ) :
  Iiii1iI1i = self . WavveObj . Get_Now_Datetime ( )
  I1ii1ii11i1I = Iiii1iI1i + datetime . timedelta ( days = int ( __addon__ . getSetting ( 'cache_ttl' ) ) )
  if 58 - 58: O00oOoOoO0o0O + oO
  ii11i1 = xbmcgui . Window ( 10000 )
  II1I1I1Ii = { 'wavve_token' : ii11i1 . getProperty ( 'WAVVE_M_CREDENTIAL' )
 , 'wavve_id' : base64 . standard_b64encode ( __addon__ . getSetting ( 'id' ) . encode ( ) ) . decode ( 'utf-8' )
 , 'wavve_pw' : base64 . standard_b64encode ( __addon__ . getSetting ( 'pw' ) . encode ( ) ) . decode ( 'utf-8' )
 , 'wavve_profile' : __addon__ . getSetting ( 'selected_profile' )
 , 'wavve_limitdate' : I1ii1ii11i1I . strftime ( '%Y-%m-%d' )
 }
  if 70 - 70: O0o00OoOoOO00 % I1IiI + ooOo / iii1I1I % O0
  try :
   if 100 - 100: Oo + ooOo * Oo
   OoOOo0OOoO = open ( ooo0Oo0 , 'w' )
   json . dump ( II1I1I1Ii , OoOOo0OOoO )
   OoOOo0OOoO . close ( )
  except Exception as oOOo0OOOo00O :
   print ( oOOo0OOOo00O )
   if 76 - 76: i11iIiiIii + Oo / Ooo00oOo00o - O0o00OoOoOO00 - iii1I1I + Ooo00oOo00o
   if 51 - 51: iIii1I11I1II1 . I1i1iI1i + iIii1I11I1II1
   if 95 - 95: Ooo
   if 46 - 46: OOOo0 + O0o00OoOoOO00
 def cookiefile_check ( self ) :
  if 70 - 70: O00oOoOoO0o0O / iIii1I11I1II1
  if 85 - 85: OoooooooOO % i1IIi * OoooooooOO / Ooo00oOo00o
  II1I1I1Ii = { }
  try :
   OoOOo0OOoO = open ( ooo0Oo0 , 'r' )
   II1I1I1Ii = json . load ( OoOOo0OOoO )
   OoOOo0OOoO . close ( )
  except Exception as oOOo0OOOo00O :
   self . wininfo_clear ( )
   return False
   if 96 - 96: OoooooooOO + I1IiI
   if 44 - 44: I1IiI
   if 20 - 20: Ooo0O + iii1I1I / O0 % iIii1I11I1II1
  OOooOO000 = __addon__ . getSetting ( 'id' )
  OOoOoo = __addon__ . getSetting ( 'pw' )
  oOo0O = __addon__ . getSetting ( 'selected_profile' )
  II1I1I1Ii [ 'wavve_id' ] = base64 . standard_b64decode ( II1I1I1Ii [ 'wavve_id' ] ) . decode ( 'utf-8' )
  II1I1I1Ii [ 'wavve_pw' ] = base64 . standard_b64decode ( II1I1I1Ii [ 'wavve_pw' ] ) . decode ( 'utf-8' )
  if OOooOO000 != II1I1I1Ii [ 'wavve_id' ] or OOoOoo != II1I1I1Ii [ 'wavve_pw' ] or oOo0O != II1I1I1Ii [ 'wavve_profile' ] :
   self . wininfo_clear ( )
   return False
   if 64 - 64: Ooo00oOo00o - O00oOoOoO0o0O + O00oOoOoO0o0O - Ooo0O
   if 30 - 30: iIii1I11I1II1 . Ooo . ooOo / Oo
  O0o = int ( self . WavveObj . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' ) )
  iiI1I1 = II1I1I1Ii [ 'wavve_limitdate' ]
  OoOooO = int ( re . sub ( '-' , '' , iiI1I1 ) )
  if 56 - 56: Ooo . O0 + oO
  if 1 - 1: O00oOoOoO0o0O
  if OoOooO < O0o :
   self . wininfo_clear ( )
   return False
   if 97 - 97: ooOo + O00oOoOoO0o0O + O0 + i11iIiiIii
   if 77 - 77: Oo / OoooooooOO
  ii11i1 = xbmcgui . Window ( 10000 )
  ii11i1 . setProperty ( 'WAVVE_M_CREDENTIAL' , II1I1I1Ii [ 'wavve_token' ] )
  ii11i1 . setProperty ( 'WAVVE_M_LOGINTIME' , iiI1I1 )
  if 46 - 46: Oo % iIii1I11I1II1 . O00oOoOoO0o0O % O00oOoOoO0o0O + i11iIiiIii
  return True
  if 72 - 72: iIii1I11I1II1 * iii1I1I % I1i1iI1i / O0o00OoOoOO00
  if 35 - 35: I1i1iI1i + i1IIi % Ooo00oOo00o % Ooo0O + I1IiI
  if 17 - 17: i1IIi
  if 21 - 21: oO
 def dp_LiveCatagory_List ( self , args ) :
  if 29 - 29: Ooo0O / II111iiii / I1i1iI1i * ooOo
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 10 - 10: Oo0ooO0oo0oO % O0oo0OO0 * O0oo0OO0 . Ooo0O / iii1I1I % ooOo
  IIII1 = args . get ( 'sCode' )
  I1I1i = args . get ( 'sIndex' )
  I1IIIiIiIi , IIIII1 = self . WavveObj . Get_LiveCatagory_List ( IIII1 , I1I1i )
  if 5 - 5: iii1I1I
  for iIi1i1iIi1iI in I1IIIiIiIi :
   I1 = iIi1i1iIi1iI . get ( 'title' )
   oO00O0O0O = { 'mode' : 'LIVE_LIST'
 , 'genre' : iIi1i1iIi1iI . get ( 'genre' )
 , 'baseapi' : IIIII1
 }
   if 26 - 26: OoooooooOO * Ooo + ooOo
   self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 24 - 24: i11iIiiIii % iIii1I11I1II1 + ooOo / i11iIiiIii
  if len ( I1IIIiIiIi ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 70 - 70: O0o00OoOoOO00 * O0 . Ooo0O + Ooo . O0oo0OO0
  if 14 - 14: iIii1I11I1II1 % iIii1I11I1II1 * i11iIiiIii - O0o00OoOoOO00 - Ooo0O
  if 63 - 63: O0o00OoOoOO00
  if 69 - 69: iIii1I11I1II1 . Ooo00oOo00o % I1i1iI1i + iIii1I11I1II1 / O0 / Ooo00oOo00o
  if 61 - 61: ooOo % ooOo * Oo / Oo
 def dp_MainCatagory_List ( self , args ) :
  if 75 - 75: O0oo0OO0 . I1i1iI1i
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 50 - 50: OOOo0
  IIII1 = args . get ( 'sCode' )
  I1I1i = args . get ( 'sIndex' )
  IiIi1I1 = args . get ( 'sType' )
  I1IIIiIiIi = self . WavveObj . Get_MainCatagory_List ( IIII1 , I1I1i )
  if 60 - 60: I1i1iI1i * iIii1I11I1II1 * Ooo00oOo00o * oO
  for iIi1i1iIi1iI in I1IIIiIiIi :
   if 69 - 69: iii1I1I * O0 . i11iIiiIii / iii1I1I . Oo
   if IiIi1I1 == 'vod' :
    if iIi1i1iIi1iI . get ( 'subtype' ) == 'catagory' :
     o0O = 'PROGRAM_LIST'
    else :
     o0O = 'SUPERSECTION_LIST'
   elif IiIi1I1 == 'movie' :
    o0O = 'MOVIE_LIST'
   else :
    o0O = ''
    if 63 - 63: Ooo0O + Oo . II111iiii - Ooo
    if 52 - 52: Oo % oO
   I1 = '%s (%s)' % ( iIi1i1iIi1iI . get ( 'title' ) , args . get ( 'ordernm' ) )
   if 64 - 64: O0 % Ooo0O % O0 * O0o00OoOoOO00 . I1IiI + Ooo
   if 75 - 75: Ooo0O . OoooooooOO % Oo * Ooo0O % OoooooooOO
   oO00O0O0O = { 'mode' : o0O
 , 'suburl' : iIi1i1iIi1iI . get ( 'suburl' )
 , 'subapi' : iIi1i1iIi1iI . get ( 'subapi' )
 , 'page' : '1'
 , 'orderby' : args . get ( 'orderby' )
 }
   if 13 - 13: O0oo0OO0 / i11iIiiIii % II111iiii % Ooo0O . Ooo00oOo00o
   if self . get_settings_exclusion21 ( ) :
    if iIi1i1iIi1iI . get ( 'title' ) == '성인' or iIi1i1iIi1iI . get ( 'title' ) == '성인+' : continue
    if 8 - 8: OOOo0 + oO - II111iiii
   self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 11 - 11: i1IIi % i11iIiiIii - i1IIi * OOOo0
  if len ( I1IIIiIiIi ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 39 - 39: Oo0ooO0oo0oO
  if 86 - 86: Ooo0O * Ooo + Ooo0O + II111iiii
  if 8 - 8: Oo0ooO0oo0oO - O00oOoOoO0o0O / I1i1iI1i
  if 96 - 96: OOOo0
 def dp_Program_List ( self , args ) :
  if 29 - 29: Ooo00oOo00o / i1IIi . Ooo - OOOo0 - OOOo0 - iii1I1I
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 20 - 20: i1IIi % O0o00OoOoOO00 . Ooo / O0oo0OO0 * i11iIiiIii * ooOo
  OOo = args . get ( 'subapi' )
  i1i11I1I1iii1 = int ( args . get ( 'page' ) )
  o0OoOO000ooO0 = args . get ( 'orderby' )
  if 8 - 8: I1i1iI1i + II111iiii / O00oOoOoO0o0O / Ooo0O
  if 74 - 74: O0 / i1IIi
  if 78 - 78: OoooooooOO . O0o00OoOoOO00 + I1i1iI1i - i1IIi
  I1IIIiIiIi , ii1 = self . WavveObj . Get_Program_List ( OOo , i1i11I1I1iii1 , o0OoOO000ooO0 )
  if 83 - 83: O00oOoOoO0o0O . O0 / oO / ooOo - II111iiii
  for iIi1i1iIi1iI in I1IIIiIiIi :
   if 100 - 100: O0o00OoOoOO00
   I1 = iIi1i1iIi1iI . get ( 'title' )
   II1i = iIi1i1iIi1iI . get ( 'thumbnail' )
   Ii1IIIIi1ii1I = iIi1i1iIi1iI . get ( 'age' )
   if Ii1IIIIi1ii1I == '18' or Ii1IIIIi1ii1I == '19' or Ii1IIIIi1ii1I == '21' : I1 += ' (%s)' % ( Ii1IIIIi1ii1I )
   if 13 - 13: Ooo % OOOo0 . Ooo00oOo00o / oO % ooOo . OoooooooOO
   i1iIi = { 'plot' : I1
 , 'mpaa' : Ii1IIIIi1ii1I
 , 'mediatype' : 'episode'
 }
   if 30 - 30: O0 - iIii1I11I1II1 / OoooooooOO
   oO00O0O0O = { 'mode' : 'EPISODE_LIST'
 , 'videoid' : iIi1i1iIi1iI . get ( 'videoid' )
 , 'vidtype' : iIi1i1iIi1iI . get ( 'vidtype' )
 , 'page' : '1'
 }
   if 89 - 89: O00oOoOoO0o0O - I1i1iI1i % oO % Oo
   self . add_dir ( I1 , sublabel = '' , img = II1i , infoLabels = i1iIi , isFolder = True , params = oO00O0O0O )
   if 49 - 49: oO - Ooo / O0oo0OO0 / O0 % Oo * iii1I1I
  if ii1 :
   oO00O0O0O = { }
   oO00O0O0O [ 'mode' ] = 'PROGRAM_LIST'
   oO00O0O0O [ 'subapi' ] = OOo
   oO00O0O0O [ 'page' ] = str ( i1i11I1I1iii1 + 1 )
   I1 = '[B]%s >>[/B]' % '다음 페이지'
   OOoO0 = str ( i1i11I1I1iii1 + 1 )
   self . add_dir ( I1 , sublabel = OOoO0 , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 22 - 22: oO % O00oOoOoO0o0O * Ooo00oOo00o / ooOo % i11iIiiIii * Ooo0O
  if len ( I1IIIiIiIi ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 95 - 95: OoooooooOO - O0oo0OO0 * Ooo + OOOo0
  if 10 - 10: Oo / i11iIiiIii
  if 92 - 92: Ooo0O . Oo0ooO0oo0oO
  if 85 - 85: Ooo00oOo00o . Oo0ooO0oo0oO
 def dp_SuperSection_List ( self , args ) :
  if 78 - 78: I1i1iI1i * Oo0ooO0oo0oO + iIii1I11I1II1 + iIii1I11I1II1 / Oo0ooO0oo0oO . iii1I1I
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 97 - 97: I1i1iI1i / Oo0ooO0oo0oO % i1IIi % Ooo00oOo00o
  ii111I11iI = args . get ( 'suburl' )
  if 93 - 93: Ooo00oOo00o / iIii1I11I1II1 * i1IIi % OoooooooOO * O0 * Ooo0O
  if 64 - 64: II111iiii + O0 / iIii1I11I1II1 / oO . I1i1iI1i % O0oo0OO0
  I1IIIiIiIi = self . WavveObj . Get_SuperMultiSection_List ( ii111I11iI )
  if 50 - 50: iIii1I11I1II1 - O0oo0OO0 + ooOo
  for iIi1i1iIi1iI in I1IIIiIiIi :
   if 69 - 69: O0
   I1 = iIi1i1iIi1iI . get ( 'title' )
   OOo = iIi1i1iIi1iI . get ( 'subapi' )
   o0ooO = iIi1i1iIi1iI . get ( 'cell_type' )
   if 74 - 74: O0 * I1IiI - i11iIiiIii + Oo0ooO0oo0oO
   if OOo . find ( 'mtype=svod' ) >= 0 or OOo . find ( 'mtype=ppv' ) >= 0 :
    o0O = 'MOVIE_LIST'
   elif o0ooO == 'band_71' :
    o0O = 'SUPERSECTION_LIST'
    ( Iii , I1iiiiI1iI ) = self . WavveObj . Baseapi_Parse ( OOo )
    ii111I11iI = I1iiiiI1iI . get ( 'api' )
    OOo = ''
   elif o0ooO == 'band_2' :
    o0O = 'BAND2SECTION_LIST'
   elif o0ooO == 'band_live' :
    o0O = 'BANDLIVESECTION_LIST'
   elif re . search ( u'themes/2\d{4}' , OOo ) :
    o0O = 'MOVIE_LIST'
   else :
    o0O = 'PROGRAM_LIST'
    if 43 - 43: I1IiI - OoooooooOO
   i1iIi = { 'plot' : I1
   , 'mediatype' : 'episode'
 }
   if 3 - 3: O0 / O00oOoOoO0o0O
   oO00O0O0O = { 'mode' : o0O
 , 'suburl' : ii111I11iI
   , 'subapi' : OOo
 , 'page' : '1'
 }
   if 31 - 31: ooOo + Oo . OoooooooOO
   self . add_dir ( I1 , sublabel = '' , img = None , infoLabels = i1iIi , isFolder = True , params = oO00O0O0O )
   if 89 - 89: II111iiii + i1IIi + II111iiii
  if len ( I1IIIiIiIi ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 7 - 7: O0 % Oo + Ooo00oOo00o * O00oOoOoO0o0O - O00oOoOoO0o0O
  if 42 - 42: OOOo0 * OOOo0 * Oo0ooO0oo0oO . Ooo0O
  if 51 - 51: ooOo % iIii1I11I1II1 - OoooooooOO % I1i1iI1i * iIii1I11I1II1 % O0o00OoOoOO00
  if 99 - 99: I1IiI * II111iiii * Oo0ooO0oo0oO
 def dp_BandLiveSection_List ( self , args ) :
  if 92 - 92: oO
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 40 - 40: OOOo0 / O0oo0OO0
  OOo = args . get ( 'subapi' )
  i1i11I1I1iii1 = int ( args . get ( 'page' ) )
  if 79 - 79: O0o00OoOoOO00 - iIii1I11I1II1 + iii1I1I - Oo0ooO0oo0oO
  I1IIIiIiIi , ii1 = self . WavveObj . Get_BandLiveSection_List ( OOo , i1i11I1I1iii1 )
  if 93 - 93: II111iiii . Ooo - oO + OOOo0
  for iIi1i1iIi1iI in I1IIIiIiIi :
   if 61 - 61: II111iiii
   Ii1ii111i1 = iIi1i1iIi1iI . get ( 'channelid' )
   i1i1i1I = iIi1i1iIi1iI . get ( 'studio' )
   oOoo000 = iIi1i1iIi1iI . get ( 'tvshowtitle' )
   II1i = iIi1i1iIi1iI . get ( 'thumbnail' )
   Ii1IIIIi1ii1I = iIi1i1iIi1iI . get ( 'age' )
   if 87 - 87: OoooooooOO - Oo / O0oo0OO0 . i11iIiiIii * OoooooooOO
   i1iIi = { 'mediatype' : 'video'
 , 'mpaa' : Ii1IIIIi1ii1I
 , 'title' : '%s < %s >' % ( i1i1i1I , oOoo000 )
 , 'tvshowtitle' : oOoo000
 , 'studio' : i1i1i1I
 , 'plot' : i1i1i1I
 }
   if 84 - 84: OOOo0 / Ooo0O * O00oOoOoO0o0O / I1IiI - i11iIiiIii . oO
   oO00O0O0O = { 'mode' : 'LIVE'
 , 'contentid' : Ii1ii111i1

   }
   if 60 - 60: Ooo00oOo00o * Ooo
   self . add_dir ( i1i1i1I , sublabel = oOoo000 , img = iIi1i1iIi1iI . get ( 'thumbnail' ) , infoLabels = i1iIi , isFolder = False , params = oO00O0O0O )
   if 17 - 17: ooOo % oO / Ooo00oOo00o . O0oo0OO0 * ooOo - II111iiii
  if ii1 :
   oO00O0O0O = { }
   oO00O0O0O [ 'mode' ] = 'BANDLIVESECTION_LIST'
   oO00O0O0O [ 'subapi' ] = OOo
   oO00O0O0O [ 'page' ] = str ( i1i11I1I1iii1 + 1 )
   I1 = '[B]%s >>[/B]' % '다음 페이지'
   OOoO0 = str ( i1i11I1I1iii1 + 1 )
   self . add_dir ( I1 , sublabel = OOoO0 , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 41 - 41: iii1I1I
  if len ( I1IIIiIiIi ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 77 - 77: Oo0ooO0oo0oO
  if 65 - 65: II111iiii . Ooo % I1IiI * O0o00OoOoOO00
  if 38 - 38: OOOo0 / O00oOoOoO0o0O % oO
  if 11 - 11: O00oOoOoO0o0O - I1IiI + II111iiii - iIii1I11I1II1
 def dp_Band2Section_List ( self , args ) :
  if 7 - 7: O0oo0OO0 - Ooo0O / II111iiii * iii1I1I . O00oOoOoO0o0O * O00oOoOoO0o0O
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 61 - 61: Ooo0O % I1i1iI1i - O0o00OoOoOO00 / oO
  OOo = args . get ( 'subapi' )
  i1i11I1I1iii1 = int ( args . get ( 'page' ) )
  if 4 - 4: OoooooooOO - i1IIi % iii1I1I - ooOo * Oo
  I1IIIiIiIi , ii1 = self . WavveObj . Get_Band2Section_List ( OOo , i1i11I1I1iii1 )
  if 85 - 85: OoooooooOO * iIii1I11I1II1 . O00oOoOoO0o0O / OoooooooOO % Ooo % O0
  for iIi1i1iIi1iI in I1IIIiIiIi :
   if 36 - 36: iii1I1I / II111iiii / O0oo0OO0 / O0oo0OO0 + Ooo00oOo00o
   I1 = iIi1i1iIi1iI . get ( 'programtitle' )
   OOoO0 = iIi1i1iIi1iI . get ( 'episodetitle' )
   if 95 - 95: O0oo0OO0
   i1iIi = { 'plot' : I1 + '\n\n' + OOoO0
 , 'mpaa' : iIi1i1iIi1iI . get ( 'age' )
 , 'mediatype' : 'episode'
 }
   if 51 - 51: II111iiii + O0oo0OO0 . i1IIi . Ooo00oOo00o + OOOo0 * Ooo
   oO00O0O0O = { 'mode' : 'VOD'
 , 'programid' : '-'
 , 'contentid' : iIi1i1iIi1iI . get ( 'videoid' )
 , 'thumbnail' : iIi1i1iIi1iI . get ( 'thumbnail' )
 , 'title' : I1
 , 'subtitle' : OOoO0
 }
   if 72 - 72: I1IiI + I1IiI / II111iiii . OoooooooOO % iii1I1I
   self . add_dir ( I1 , sublabel = OOoO0 , img = iIi1i1iIi1iI . get ( 'thumbnail' ) , infoLabels = i1iIi , isFolder = False , params = oO00O0O0O )
   if 49 - 49: I1IiI . O0o00OoOoOO00 - oO * OoooooooOO . oO
  if ii1 :
   oO00O0O0O = { }
   oO00O0O0O [ 'mode' ] = 'BAND2SECTION_LIST'
   oO00O0O0O [ 'subapi' ] = OOo
   oO00O0O0O [ 'page' ] = str ( i1i11I1I1iii1 + 1 )
   I1 = '[B]%s >>[/B]' % '다음 페이지'
   OOoO0 = str ( i1i11I1I1iii1 + 1 )
   self . add_dir ( I1 , sublabel = OOoO0 , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 2 - 2: OoooooooOO % ooOo
  if len ( I1IIIiIiIi ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 63 - 63: Ooo % iIii1I11I1II1
  if 39 - 39: O00oOoOoO0o0O / II111iiii / Ooo00oOo00o % Ooo
  if 89 - 89: Oo0ooO0oo0oO + OoooooooOO + Oo0ooO0oo0oO * i1IIi + iIii1I11I1II1 % Ooo0O
  if 59 - 59: ooOo + i11iIiiIii
 def dp_Movie_List ( self , args ) :
  if 88 - 88: i11iIiiIii - I1i1iI1i
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 67 - 67: ooOo . oO + OOOo0 - OoooooooOO
  OOo = args . get ( 'subapi' )
  i1i11I1I1iii1 = int ( args . get ( 'page' ) )
  if 70 - 70: ooOo / II111iiii - iIii1I11I1II1 - O00oOoOoO0o0O
  if 11 - 11: iIii1I11I1II1 . OoooooooOO . II111iiii / i1IIi - Ooo0O
  if 30 - 30: OOOo0
  I1IIIiIiIi , ii1 = self . WavveObj . Get_Movie_List ( OOo , i1i11I1I1iii1 )
  if 21 - 21: i11iIiiIii / Oo0ooO0oo0oO % ooOo * O0 . Ooo0O - iIii1I11I1II1
  for iIi1i1iIi1iI in I1IIIiIiIi :
   if 26 - 26: II111iiii * OOOo0
   I1 = iIi1i1iIi1iI . get ( 'title' )
   II1i = iIi1i1iIi1iI . get ( 'thumbnail' )
   Ii1IIIIi1ii1I = iIi1i1iIi1iI . get ( 'age' )
   if Ii1IIIIi1ii1I == '18' or Ii1IIIIi1ii1I == '19' or Ii1IIIIi1ii1I == '21' : I1 += ' (%s)' % ( Ii1IIIIi1ii1I )
   if 10 - 10: II111iiii . O00oOoOoO0o0O
   i1iIi = { 'plot' : I1
 , 'mpaa' : Ii1IIIIi1ii1I
 , 'mediatype' : 'movie'
 }
   if 32 - 32: iii1I1I . O0oo0OO0 . OoooooooOO - O0o00OoOoOO00 + I1IiI
   oO00O0O0O = { 'mode' : 'MOVIE'
 , 'contentid' : iIi1i1iIi1iI . get ( 'videoid' )

   , 'title' : I1
 , 'thumbnail' : II1i
 , 'age' : Ii1IIIIi1ii1I
 }
   if 88 - 88: O00oOoOoO0o0O
   self . add_dir ( I1 , sublabel = '' , img = II1i , infoLabels = i1iIi , isFolder = False , params = oO00O0O0O )
   if 19 - 19: II111iiii * O0oo0OO0 + iii1I1I
  if ii1 :
   oO00O0O0O = { }
   oO00O0O0O [ 'mode' ] = 'MOVIE_LIST'
   oO00O0O0O [ 'subapi' ] = OOo
   oO00O0O0O [ 'page' ] = str ( i1i11I1I1iii1 + 1 )
   I1 = '[B]%s >>[/B]' % '다음 페이지'
   OOoO0 = str ( i1i11I1I1iii1 + 1 )
   self . add_dir ( I1 , sublabel = OOoO0 , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 65 - 65: ooOo . Oo0ooO0oo0oO . O0o00OoOoOO00 . O00oOoOoO0o0O - ooOo
  if len ( I1IIIiIiIi ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 19 - 19: i11iIiiIii + O00oOoOoO0o0O % I1i1iI1i
  if 14 - 14: O0o00OoOoOO00 . II111iiii . Ooo0O / iii1I1I % Ooo00oOo00o - I1i1iI1i
  if 67 - 67: Ooo0O - ooOo . i1IIi
  if 35 - 35: O00oOoOoO0o0O + I1i1iI1i - I1IiI . O00oOoOoO0o0O . O0oo0OO0
 def dp_Episode_List ( self , args ) :
  if 87 - 87: OOOo0
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 25 - 25: i1IIi . O0o00OoOoOO00 - OOOo0 / O0o00OoOoOO00 % O0o00OoOoOO00 * iIii1I11I1II1
  III = args . get ( 'videoid' )
  iIiIi11Ii = args . get ( 'vidtype' )
  i1i11I1I1iii1 = int ( args . get ( 'page' ) )
  if 23 - 23: I1IiI - ooOo + Ooo0O
  I1IIIiIiIi , ii1 = self . WavveObj . Get_Episode_List ( III , iIiIi11Ii , i1i11I1I1iii1 , orderby = self . get_winEpisodeOrderby ( ) )
  if 12 - 12: Ooo / I1i1iI1i % Oo / i11iIiiIii % OoooooooOO
  for iIi1i1iIi1iI in I1IIIiIiIi :
   if 15 - 15: iIii1I11I1II1 % OoooooooOO - oO * iii1I1I + Ooo0O
   OOoO0 = '%s회, %s(%s)' % ( iIi1i1iIi1iI . get ( 'episodenumber' ) , iIi1i1iIi1iI . get ( 'releasedate' ) , iIi1i1iIi1iI . get ( 'releaseweekday' ) )
   i1I1II1iIIi11 = '[%s]\n\n%s' % ( iIi1i1iIi1iI . get ( 'episodetitle' ) , iIi1i1iIi1iI . get ( 'synopsis' ) )
   if 49 - 49: OoooooooOO * Ooo0O - oO . I1IiI
   i1iIi = { 'mediatype' : 'episode'
 , 'title' : iIi1i1iIi1iI . get ( 'programtitle' )
 , 'year' : int ( iIi1i1iIi1iI . get ( 'releasedate' ) [ : 4 ] )
 , 'aired' : iIi1i1iIi1iI . get ( 'releasedate' )
 , 'mpaa' : iIi1i1iIi1iI . get ( 'age' )
 , 'episode' : iIi1i1iIi1iI . get ( 'episodenumber' )
 , 'duration' : iIi1i1iIi1iI . get ( 'playtime' )
 , 'plot' : i1I1II1iIIi11
 , 'cast' : iIi1i1iIi1iI . get ( 'episodeactors' )
 }
   if 89 - 89: I1i1iI1i + iii1I1I * I1i1iI1i / I1i1iI1i
   oO00O0O0O = { 'mode' : 'VOD'
 , 'programid' : iIi1i1iIi1iI . get ( 'programid' )
 , 'contentid' : iIi1i1iIi1iI . get ( 'contentid' )
 , 'thumbnail' : iIi1i1iIi1iI . get ( 'thumbnail' )
 , 'title' : iIi1i1iIi1iI . get ( 'programtitle' )
 , 'subtitle' : OOoO0
 }
   if 46 - 46: O0o00OoOoOO00
   self . add_dir ( iIi1i1iIi1iI . get ( 'programtitle' ) , sublabel = OOoO0 , img = iIi1i1iIi1iI . get ( 'thumbnail' ) , infoLabels = i1iIi , isFolder = False , params = oO00O0O0O )
   if 71 - 71: Ooo0O / Ooo0O * I1IiI * I1IiI / II111iiii
  if i1i11I1I1iii1 == 1 :
   i1iIi = { 'plot' : '정렬순서를 변경합니다.' }
   oO00O0O0O = { }
   oO00O0O0O [ 'mode' ] = 'ORDER_BY'
   if self . get_winEpisodeOrderby ( ) == 'desc' :
    I1 = '정렬순서변경 : 최신화부터 -> 1회부터'
    oO00O0O0O [ 'orderby' ] = 'asc'
   else :
    I1 = '정렬순서변경 : 1회부터 -> 최신화부터'
    oO00O0O0O [ 'orderby' ] = 'desc'
   self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = i1iIi , isFolder = False , params = oO00O0O0O )
   if 35 - 35: ooOo * Oo * Ooo % oO . OOOo0
   if 58 - 58: Ooo0O + II111iiii * O00oOoOoO0o0O * i11iIiiIii - iIii1I11I1II1
  if ii1 :
   oO00O0O0O = { }
   oO00O0O0O [ 'mode' ] = 'EPISODE_LIST'
   oO00O0O0O [ 'videoid' ] = iIi1i1iIi1iI . get ( 'programid' )
   oO00O0O0O [ 'vidtype' ] = 'programid'
   oO00O0O0O [ 'page' ] = str ( i1i11I1I1iii1 + 1 )
   I1 = '[B]%s >>[/B]' % '다음 페이지'
   OOoO0 = str ( i1i11I1I1iii1 + 1 )
   self . add_dir ( I1 , sublabel = OOoO0 , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 68 - 68: OoooooooOO % II111iiii
  if len ( I1IIIiIiIi ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 26 - 26: II111iiii % i11iIiiIii % iIii1I11I1II1 % Ooo0O * Ooo0O * Ooo00oOo00o
  if 24 - 24: II111iiii % Oo0ooO0oo0oO - I1i1iI1i + Ooo * Ooo00oOo00o
  if 2 - 2: iii1I1I - O0oo0OO0
  if 83 - 83: I1IiI % Oo % iii1I1I - II111iiii * ooOo / OoooooooOO
 def dp_LiveChannel_List ( self , args ) :
  if 18 - 18: O0o00OoOoOO00 + iIii1I11I1II1 - II111iiii - Ooo
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 71 - 71: OoooooooOO
  iIIIII1iiiiII = args . get ( 'genre' )
  IIIII1 = args . get ( 'baseapi' )
  I1IIIiIiIi = self . WavveObj . Get_LiveChannel_List ( iIIIII1iiiiII , IIIII1 )
  if 54 - 54: i1IIi
  if 22 - 22: i1IIi + iii1I1I
  for iIi1i1iIi1iI in I1IIIiIiIi :
   if 54 - 54: I1i1iI1i % ooOo . Oo0ooO0oo0oO + I1IiI - ooOo * Ooo
   Ii1ii111i1 = iIi1i1iIi1iI . get ( 'channelid' )
   i1i1i1I = iIi1i1iIi1iI . get ( 'studio' )
   oOoo000 = iIi1i1iIi1iI . get ( 'tvshowtitle' )
   II1i = iIi1i1iIi1iI . get ( 'thumbnail' )
   Ii1IIIIi1ii1I = iIi1i1iIi1iI . get ( 'age' )
   OOo00O = iIi1i1iIi1iI . get ( 'epg' )
   if 81 - 81: O0oo0OO0 . Oo / Oo0ooO0oo0oO
   i1iIi = { 'mediatype' : 'video'
 , 'mpaa' : Ii1IIIIi1ii1I
 , 'title' : '%s < %s >' % ( i1i1i1I , oOoo000 )
 , 'tvshowtitle' : oOoo000
 , 'studio' : i1i1i1I
 , 'plot' : '%s\n\n%s' % ( i1i1i1I , OOo00O )
 }
   if 17 - 17: i11iIiiIii - ooOo . O0oo0OO0 % iIii1I11I1II1 + Ooo0O - I1i1iI1i
   oO00O0O0O = { 'mode' : 'LIVE'
 , 'contentid' : Ii1ii111i1

   }
   if 78 - 78: Ooo0O * OOOo0 . O0 / O0
   self . add_dir ( i1i1i1I , sublabel = oOoo000 , img = II1i , infoLabels = i1iIi , isFolder = False , params = oO00O0O0O )
   if 80 - 80: i1IIi - oO / O0o00OoOoOO00 - i11iIiiIii
  if len ( I1IIIiIiIi ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 68 - 68: I1IiI - Ooo00oOo00o % O0 % Oo0ooO0oo0oO
  if 11 - 11: O0 / O0o00OoOoOO00 % ooOo + Oo + iIii1I11I1II1
  if 40 - 40: I1i1iI1i - ooOo . iii1I1I * oO % Oo0ooO0oo0oO
  if 56 - 56: i11iIiiIii . Oo - Ooo * Ooo0O
  if 91 - 91: I1IiI + OoooooooOO - i1IIi
 def dp_Search_List ( self , args ) :
  if 84 - 84: iii1I1I / O0oo0OO0
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 86 - 86: OOOo0 * II111iiii - O0 . OOOo0 % iIii1I11I1II1 / ooOo
  IiIi1I1 = args . get ( 'sType' )
  i1i11I1I1iii1 = int ( args . get ( 'page' ) )
  if 11 - 11: Ooo * I1IiI + Ooo00oOo00o / Ooo00oOo00o
  if 'search_key' in args :
   iiii1I1 = args . get ( 'search_key' )
  else :
   iiii1I1 = self . get_keyboard_input ( __language__ ( 30906 ) . encode ( 'utf-8' ) )
   if not iiii1I1 : return
   if 14 - 14: OOOo0 * Ooo + OoooooooOO - O00oOoOoO0o0O - O0oo0OO0
  I1IIIiIiIi , ii1 = self . WavveObj . Get_Search_List ( iiii1I1 , IiIi1I1 , i1i11I1I1iii1 , exclusion21 = self . get_settings_exclusion21 ( ) )
  if 15 - 15: O0oo0OO0 / O0 . Oo . i11iIiiIii
  for iIi1i1iIi1iI in I1IIIiIiIi :
   if 59 - 59: Oo0ooO0oo0oO - Oo - I1i1iI1i
   I1 = iIi1i1iIi1iI . get ( 'title' )
   II1i = iIi1i1iIi1iI . get ( 'thumbnail' )
   Ii1IIIIi1ii1I = iIi1i1iIi1iI . get ( 'age' )
   if Ii1IIIIi1ii1I == '18' or Ii1IIIIi1ii1I == '19' or Ii1IIIIi1ii1I == '21' : I1 += ' (%s)' % ( Ii1IIIIi1ii1I )
   if 48 - 48: i1IIi + Ooo0O % OOOo0 / oO - Oo
   i1iIi = { 'mediatype' : 'episode' if IiIi1I1 == 'vod' else 'movie'
 , 'mpaa' : Ii1IIIIi1ii1I
 , 'title' : I1
 , 'plot' : I1
 }
   if 67 - 67: I1IiI % Oo . OoooooooOO + ooOo * Ooo0O * OOOo0
   if IiIi1I1 == 'vod' :
    oO00O0O0O = { 'mode' : 'EPISODE_LIST'
 , 'videoid' : iIi1i1iIi1iI . get ( 'videoid' )
 , 'vidtype' : iIi1i1iIi1iI . get ( 'vidtype' )
 , 'page' : '1'
 }
    i1I11i1I = True
    if 36 - 36: O0 + oO
   else :
    oO00O0O0O = { 'mode' : 'MOVIE'
 , 'contentid' : iIi1i1iIi1iI . get ( 'videoid' )

    , 'title' : I1
 , 'thumbnail' : II1i
 , 'age' : Ii1IIIIi1ii1I
 }
    i1I11i1I = False
    if 5 - 5: oO * OOOo0
   self . add_dir ( I1 , sublabel = '' , img = II1i , infoLabels = i1iIi , isFolder = i1I11i1I , params = oO00O0O0O )
   if 46 - 46: I1i1iI1i
  if ii1 :
   if 33 - 33: O00oOoOoO0o0O - II111iiii * OoooooooOO - oO - ooOo
   oO00O0O0O [ 'mode' ] = 'SEARCH_LIST'
   oO00O0O0O [ 'sType' ] = IiIi1I1
   oO00O0O0O [ 'page' ] = str ( i1i11I1I1iii1 + 1 )
   oO00O0O0O [ 'search_key' ] = iiii1I1
   I1 = '[B]%s >>[/B]' % '다음 페이지'
   OOoO0 = str ( i1i11I1I1iii1 + 1 )
   self . add_dir ( I1 , sublabel = OOoO0 , img = '' , infoLabels = None , isFolder = True , params = oO00O0O0O )
   if 84 - 84: Oo0ooO0oo0oO + oO - OOOo0 * OOOo0
  if len ( I1IIIiIiIi ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle )
  if 61 - 61: OoooooooOO . I1IiI . OoooooooOO / oO
  if 72 - 72: i1IIi
  if 82 - 82: OOOo0 + OoooooooOO / i11iIiiIii * Ooo00oOo00o . OoooooooOO
  if 63 - 63: Ooo00oOo00o
 def dp_Watch_List ( self , args ) :
  IiIi1I1 = args . get ( 'sType' )
  I1i1I = self . get_settings_direct_replay ( )
  if 6 - 6: I1i1iI1i / Ooo00oOo00o
  I1IIIiIiIi = self . Load_Watched_List ( IiIi1I1 )
  if 57 - 57: Ooo0O
  for iIi1i1iIi1iI in I1IIIiIiIi :
   oO0 = dict ( urlparse . parse_qsl ( iIi1i1iIi1iI ) )
   if 87 - 87: I1IiI % iii1I1I
   oo0OOOoOo = oO0 . get ( 'code' ) . strip ( )
   I1 = oO0 . get ( 'title' ) . strip ( )
   OOoO0 = oO0 . get ( 'subtitle' ) . strip ( )
   if OOoO0 == 'None' : OOoO0 = ''
   II1i = oO0 . get ( 'img' ) . strip ( )
   III = oO0 . get ( 'videoid' ) . strip ( )
   if 21 - 21: O0o00OoOoOO00 - O0 . I1IiI + iii1I1I . iIii1I11I1II1 - OOOo0
   if 14 - 14: O0oo0OO0 % I1IiI % oO - i11iIiiIii
   i1iIi = { 'plot' : '%s\n%s' % ( I1 , OOoO0 ) }
   if 53 - 53: iii1I1I % oO
   if IiIi1I1 == 'vod' :
    if I1i1I == False or III == None :
     oO00O0O0O = { 'mode' : 'EPISODE_LIST'
 , 'videoid' : oo0OOOoOo
 , 'vidtype' : 'programid'
 , 'page' : '1'
 }
     i1I11i1I = True
    else :
     oO00O0O0O = { 'mode' : 'VOD'
 , 'programid' : oo0OOOoOo
 , 'contentid' : III
 , 'title' : I1
 , 'subtitle' : OOoO0
 , 'thumbnail' : II1i
 }
     i1I11i1I = False
     if 59 - 59: ooOo % iIii1I11I1II1 . i1IIi + II111iiii * O0oo0OO0
   else :
    oO00O0O0O = { 'mode' : 'MOVIE'
 , 'contentid' : oo0OOOoOo

    , 'title' : I1
 , 'subtitle' : OOoO0
 , 'thumbnail' : II1i
 }
    i1I11i1I = False
    if 41 - 41: iii1I1I % Ooo00oOo00o
   self . add_dir ( I1 , sublabel = OOoO0 , img = II1i , infoLabels = i1iIi , isFolder = i1I11i1I , params = oO00O0O0O )
   if 12 - 12: ooOo
   if 69 - 69: OoooooooOO + ooOo
  i1iIi = { 'plot' : '시청목록을 삭제합니다.' }
  I1 = '*** 시청목록 삭제 ***'
  oO00O0O0O = { 'mode' : 'MYVIEW_REMOVE'
 , 'sType' : IiIi1I1
 }
  self . add_dir ( I1 , sublabel = '' , img = '' , infoLabels = i1iIi , isFolder = False , params = oO00O0O0O )
  if 26 - 26: oO + ooOo / O0o00OoOoOO00 % OOOo0 % Ooo00oOo00o + II111iiii
  if 31 - 31: Ooo0O % ooOo * Ooo0O
  xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 45 - 45: i1IIi . Ooo + ooOo - OoooooooOO % I1i1iI1i
  if 1 - 1: iIii1I11I1II1
  if 93 - 93: i1IIi . i11iIiiIii . oO
  if 99 - 99: Ooo0O - Oo0ooO0oo0oO - I1IiI % O0o00OoOoOO00
  if 21 - 21: II111iiii % Ooo00oOo00o . i1IIi - OoooooooOO
  if 4 - 4: OoooooooOO . I1i1iI1i
 def wavve_main ( self ) :
  if 78 - 78: Ooo00oOo00o + Ooo0O - O0
  o0O = self . main_params . get ( 'mode' , None )
  if 10 - 10: Oo0ooO0oo0oO % Ooo
  if 97 - 97: OoooooooOO - Oo0ooO0oo0oO
  if o0O == 'LOGOUT' :
   self . logout ( )
   return
   if 58 - 58: iIii1I11I1II1 + O0
  self . login_main ( )
  if 30 - 30: I1i1iI1i % O00oOoOoO0o0O * ooOo - Ooo00oOo00o * iii1I1I % I1i1iI1i
  if 46 - 46: i11iIiiIii - O0 . I1IiI
  if o0O is None :
   self . dp_Main_List ( )
   if 100 - 100: Ooo / Oo * O00oOoOoO0o0O . O0 / ooOo
  elif o0O in [ 'LIVE' , 'VOD' , 'MOVIE' ] :
   self . play_VIDEO ( self . main_params )
   if 83 - 83: Oo0ooO0oo0oO
  elif o0O == 'LIVE_CATAGORY' :
   self . dp_LiveCatagory_List ( self . main_params )
   if 48 - 48: II111iiii * ooOo * Oo0ooO0oo0oO
  elif o0O == 'MAIN_CATAGORY' :
   self . dp_MainCatagory_List ( self . main_params )
   if 50 - 50: O0oo0OO0 % i1IIi
  elif o0O == 'SUPERSECTION_LIST' :
   self . dp_SuperSection_List ( self . main_params )
   if 21 - 21: OoooooooOO - iIii1I11I1II1
  elif o0O == 'BANDLIVESECTION_LIST' :
   self . dp_BandLiveSection_List ( self . main_params )
   if 93 - 93: I1IiI - Oo % OOOo0 . OOOo0 - I1i1iI1i
  elif o0O == 'BAND2SECTION_LIST' :
   self . dp_Band2Section_List ( self . main_params )
   if 90 - 90: I1i1iI1i + II111iiii * Ooo00oOo00o / iii1I1I . Oo + Oo
  elif o0O == 'PROGRAM_LIST' :
   self . dp_Program_List ( self . main_params )
   if 40 - 40: I1i1iI1i / OOOo0 % i11iIiiIii % Ooo00oOo00o / Ooo
  elif o0O == 'EPISODE_LIST' :
   self . dp_Episode_List ( self . main_params )
   if 62 - 62: i1IIi - OOOo0
  elif o0O == 'MOVIE_LIST' :
   self . dp_Movie_List ( self . main_params )
   if 62 - 62: i1IIi + oO % O0oo0OO0
  elif o0O == 'LIVE_LIST' :
   self . dp_LiveChannel_List ( self . main_params )
   if 28 - 28: Ooo00oOo00o . i1IIi
  elif o0O == 'ORDER_BY' :
   self . dp_setEpOrderby ( self . main_params )
   if 10 - 10: O0o00OoOoOO00 / oO
  elif o0O == 'SEARCH_GROUP' :
   self . dp_Search_Group ( self . main_params )
   if 15 - 15: O00oOoOoO0o0O . OOOo0 / O00oOoOoO0o0O * Ooo0O - Ooo % Ooo00oOo00o
  elif o0O == 'SEARCH_LIST' :
   self . dp_Search_List ( self . main_params )
   if 57 - 57: O0 % OOOo0 % I1IiI
  elif o0O == 'WATCH_GROUP' :
   self . dp_Watch_Group ( self . main_params )
   if 45 - 45: Ooo00oOo00o + II111iiii * i11iIiiIii
  elif o0O == 'WATCH_LIST' :
   self . dp_Watch_List ( self . main_params )
   if 13 - 13: OoooooooOO * I1IiI - iii1I1I / ooOo + Ooo0O + O0oo0OO0
  elif o0O == 'MYVIEW_REMOVE' :
   self . dp_WatchList_Delete ( self . main_params )
   if 39 - 39: iIii1I11I1II1 - OoooooooOO
  else :
   None
   if 81 - 81: Ooo00oOo00o - O0 * OoooooooOO
   if 23 - 23: II111iiii / I1IiI
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
