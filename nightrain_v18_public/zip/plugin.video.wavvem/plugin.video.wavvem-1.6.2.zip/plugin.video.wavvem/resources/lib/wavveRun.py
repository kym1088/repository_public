# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
import os
import xbmcplugin , xbmcgui , xbmcaddon , xbmc
import sys
import urlparse
import inputstreamhelper
import datetime
import time
import base64
if 46 - 46: ooOoO0o * I11i - OoooooooOO
if 30 - 30: o0oOOo0O0Ooo - O0 % o0oOOo0O0Ooo - OoooooooOO * O0 * OoooooooOO
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
o0oO0 = [
 { 'title' : '홈' , 'uicode' : 'GN1' , 'came' : 'home' }
 , { 'title' : 'LIVE 채널' , 'uicode' : 'GN3' , 'came' : 'live' }
 , { 'title' : 'VOD 방송' , 'uicode' : 'GN2' , 'came' : 'broadcast' }

, { 'title' : '영화(Movie)' , 'uicode' : 'GN17' , 'came' : 'movie' }
 , { 'title' : '해외시리즈' , 'uicode' : 'GN12' , 'came' : 'global' }

# i1IIi . I1Ii111 / IiII * OoooooooOO + I11i * oO0o
# i11iIiiIii - II111iiii % I1Ii111 - iIii1I11I1II1 . I1ii11iIi11i . II111iiii
, { 'title' : '분류별 - 방송(VOD) - 인기순' , 'uicode' : 'GENRE' , 'came' : 'vodgenre' , 'orderby' : 'viewtime' , 'ordernm' : '인기순' }
 , { 'title' : '분류별 - 방송(VOD) - 최신순' , 'uicode' : 'GENRE' , 'came' : 'vodgenre' , 'orderby' : 'new' , 'ordernm' : '최신순' }
 , { 'title' : '분류별 - 영화(Movie) - 인기순' , 'uicode' : 'GENRE' , 'came' : 'moviegenre_svod' , 'orderby' : 'paid' , 'ordernm' : '인기순' }
 , { 'title' : '분류별 - 영화(Movie) - 업데이트순' , 'uicode' : 'GENRE' , 'came' : 'moviegenre_svod' , 'orderby' : 'displaystart' , 'ordernm' : '업데이트순' }

, { 'title' : '검색' , 'uicode' : 'SEARCH' , 'came' : '-' }
 , { 'title' : 'Watched(시청목록)' , 'uicode' : 'WATCH' , 'came' : '-' }
 ]
if 61 - 61: oO0o / OoOoOO00 / iII111i * OoO0O00 . II111iiii
__addon__ = xbmcaddon . Addon ( )
__language__ = __addon__ . getLocalizedString
__profile__ = xbmc . translatePath ( __addon__ . getAddonInfo ( 'profile' ) )
__version__ = __addon__ . getAddonInfo ( 'version' )
__addonid__ = __addon__ . getAddonInfo ( 'id' )
__addonname__ = __addon__ . getAddonInfo ( 'name' )
if 1 - 1: II111iiii - I1ii11iIi11i % i11iIiiIii + IiII . I1Ii111
if 55 - 55: iIii1I11I1II1 - I1IiiI . Ii1I * IiII * i1IIi / iIii1I11I1II1
OOo000 = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36'
O0I11i1i11i1I = xbmc . translatePath ( os . path . join ( __profile__ , 'wavve_cookies.json' ) )
if 31 - 31: i11iIiiIii / I1IiiI / ooOoO0o * oO0o / Oo0Ooo
if 99 - 99: iIii1I11I1II1 * OoooooooOO * II111iiii * iIii1I11I1II1
from wavveCore import *
if 44 - 44: oO0o / Oo0Ooo - II111iiii - i11iIiiIii % I1Ii111
if 54 - 54: OOooOOo % O0 + I1IiiI - iII111i / I11i
class iIiiI1 ( object ) :
 def __init__ ( self , in_addonurl , in_handle , in_params ) :
  if 68 - 68: I1IiiI - i11iIiiIii - OoO0O00 / OOooOOo - OoO0O00 + i1IIi
  if 48 - 48: OoooooooOO % o0oOOo0O0Ooo . I1IiiI - Ii1I % i1IIi % OoooooooOO
  if 3 - 3: iII111i + O0
  if 42 - 42: OOooOOo / i1IIi + i11iIiiIii - Ii1I
  self . _addon_url = in_addonurl
  self . _addon_handle = in_handle
  self . main_params = in_params
  self . WavveObj = iII111ii ( )
  if 78 - 78: OoO0O00
  if 18 - 18: O0 - iII111i / iII111i + ooOoO0o % ooOoO0o - IiII
  if 62 - 62: iII111i - IiII - OoOoOO00 % i1IIi / oO0o
 def addon_noti ( self , sting ) :
  try :
   OoooooOoo = xbmcgui . Dialog ( )
   if 70 - 70: OoO0O00 . OoO0O00 - OoO0O00 / I1ii11iIi11i * OOooOOo
   OoooooOoo . notification ( __addonname__ , sting )
  except :
   None
   if 86 - 86: i11iIiiIii + Ii1I + ooOoO0o * I11i + o0oOOo0O0Ooo
   if 61 - 61: OoO0O00 / i11iIiiIii
   if 34 - 34: OoooooooOO + iIii1I11I1II1 + i11iIiiIii - I1ii11iIi11i + i11iIiiIii
 def addon_log ( self , string , isDebug = False ) :
  try :
   ooOoo0O = string . encode ( 'utf-8' , 'ignore' )
  except :
   ooOoo0O = 'addonException: addon_log'
  if isDebug : OooO0 = xbmc . LOGDEBUG
  else : OooO0 = xbmc . LOGNOTICE
  xbmc . log ( "[%s-%s]: %s" % ( __addonid__ , __version__ , ooOoo0O ) , level = OooO0 )
  if 35 - 35: OOooOOo % I1Ii111 % i11iIiiIii / OoooooooOO
  if 13 - 13: i1IIi - Ii1I % oO0o / iIii1I11I1II1 % iII111i
  if 97 - 97: i11iIiiIii
  if 32 - 32: Oo0Ooo * O0 % oO0o % Ii1I . IiII
 def get_keyboard_input ( self , title ) :
  o0OOOOO00o0O0 = None
  o0o0OOO0o0 = xbmc . Keyboard ( )
  o0o0OOO0o0 . setHeading ( title )
  xbmc . sleep ( 1000 )
  o0o0OOO0o0 . doModal ( )
  if ( o0o0OOO0o0 . isConfirmed ( ) ) :
   o0OOOOO00o0O0 = o0o0OOO0o0 . getText ( )
  return o0OOOOO00o0O0
  if 84 - 84: IiII
  if 25 - 25: Oo0Ooo - IiII . OoooooooOO
  if 22 - 22: IiII + II111iiii % I1Ii111 . I11i . OoOoOO00
  if 76 - 76: OoOoOO00 - O0 % OOooOOo / I1ii11iIi11i / OoOoOO00
 def get_settings_login_info ( self ) :
  oo0oooooO0 = __addon__ . getSetting ( 'id' )
  i11Iiii = __addon__ . getSetting ( 'pw' )
  iI = __addon__ . getSetting ( 'selected_profile' )
  return ( oo0oooooO0 , i11Iiii , iI )
  if 28 - 28: OOooOOo - IiII . IiII + OoOoOO00 - OoooooooOO + O0
  if 95 - 95: OoO0O00 % oO0o . O0
  if 15 - 15: ooOoO0o / Ii1I . Ii1I - i1IIi
 def get_selQuality ( self ) :
  try :
   o00oOO0 = [ 1080 , 720 , 480 , 360 ]
   if 95 - 95: OOooOOo / OoooooooOO
   iIo00O = int ( __addon__ . getSetting ( 'selected_quality' ) )
   return o00oOO0 [ iIo00O ]
  except :
   None
   if 69 - 69: oO0o % I1Ii111 - o0oOOo0O0Ooo + I1Ii111 - O0 % OoooooooOO
  return 1080
  if 31 - 31: II111iiii - OOooOOo . I1Ii111 % OoOoOO00 - O0
  if 4 - 4: II111iiii / ooOoO0o . iII111i
  if 58 - 58: OOooOOo * i11iIiiIii / OoOoOO00 % I1Ii111 - I1ii11iIi11i / oO0o
 def get_settings_exclusion21 ( self ) :
  ii11i1 = __addon__ . getSetting ( 'exclusion21' )
  if ii11i1 == 'false' :
   return False
  else :
   return True
   if 29 - 29: I1ii11iIi11i % I1IiiI + ooOoO0o / o0oOOo0O0Ooo + OOooOOo * o0oOOo0O0Ooo
   if 42 - 42: Ii1I + oO0o
   if 76 - 76: I1Ii111 - OoO0O00
 def get_settings_direct_replay ( self ) :
  oOooOOo00Oo0O = int ( __addon__ . getSetting ( 'direct_replay' ) )
  if oOooOOo00Oo0O == 0 :
   return False
  else :
   return True
   if 72 - 72: iII111i / i1IIi * Oo0Ooo - I1Ii111
   if 51 - 51: II111iiii * OoO0O00 % o0oOOo0O0Ooo * II111iiii % I1ii11iIi11i / ooOoO0o
   if 49 - 49: o0oOOo0O0Ooo
 def get_settings_addinfo ( self ) :
  IIii1Ii1 = __addon__ . getSetting ( 'add_infoyn' )
  if IIii1Ii1 == 'false' :
   return False
  else :
   return True
   if 5 - 5: iII111i % OOooOOo + ooOoO0o % i11iIiiIii + o0oOOo0O0Ooo
   if 60 - 60: OoO0O00 * OoOoOO00 - OoO0O00 % OoooooooOO - ooOoO0o + I1IiiI
   if 70 - 70: IiII * Oo0Ooo * I11i / Ii1I
   if 88 - 88: O0
 def get_settings_thumbnail_landyn ( self ) :
  O0OoO0O00o0oO = int ( __addon__ . getSetting ( 'thumbnail_way' ) )
  if O0OoO0O00o0oO == 0 :
   return True
  else :
   return False
   if 15 - 15: Ii1I - O0 / oO0o * i1IIi
   if 92 - 92: OoOoOO00
   if 26 - 26: iII111i . I1Ii111
   if 68 - 68: OoO0O00
 def set_winCredential ( self , credential ) :
  IIi1iIIiI = xbmcgui . Window ( 10000 )
  IIi1iIIiI . setProperty ( 'WAVVE_M_CREDENTIAL' , credential )
  IIi1iIIiI . setProperty ( 'WAVVE_M_LOGINTIME' , self . WavveObj . Get_Now_Datetime ( ) . strftime ( '%Y-%m-%d' ) )
  if 58 - 58: ooOoO0o / II111iiii - OOooOOo - i11iIiiIii % OoOoOO00 - I1Ii111
 def get_winCredential ( self ) :
  IIi1iIIiI = xbmcgui . Window ( 10000 )
  return IIi1iIIiI . getProperty ( 'WAVVE_M_CREDENTIAL' )
  if 29 - 29: Oo0Ooo - oO0o - I11i % iII111i - oO0o
 def set_winEpisodeOrderby ( self , orderby ) :
  IIi1iIIiI = xbmcgui . Window ( 10000 )
  IIi1iIIiI . setProperty ( 'WAVVE_M_ORDERBY' , orderby )
  if 91 - 91: OoO0O00 / I11i - II111iiii . I11i
 def get_winEpisodeOrderby ( self ) :
  IIi1iIIiI = xbmcgui . Window ( 10000 )
  return IIi1iIIiI . getProperty ( 'WAVVE_M_ORDERBY' )
  if 18 - 18: o0oOOo0O0Ooo
  if 98 - 98: iII111i * iII111i / iII111i + I11i
  if 34 - 34: ooOoO0o
  if 15 - 15: I11i * ooOoO0o * Oo0Ooo % i11iIiiIii % OoOoOO00 - OOooOOo
 def add_dir ( self , label , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = '' ) :
  if 68 - 68: I1Ii111 % i1IIi . IiII . I1ii11iIi11i
  o0 = '%s?%s' % ( self . _addon_url , urllib . urlencode ( params ) )
  if 91 - 91: iIii1I11I1II1 + I1Ii111
  if sublabel : i1i = '%s < %s >' % ( label , sublabel )
  else : i1i = label
  if not img : img = 'DefaultFolder.png'
  if 46 - 46: I1Ii111 % I11i + OoO0O00 . OoOoOO00 . OoO0O00
  if 96 - 96: Oo0Ooo
  Ii1I1IIii1II = xbmcgui . ListItem ( i1i )
  Ii1I1IIii1II . setArt ( { 'thumbnailImage' : img , 'icon' : img , 'poster' : img } )
  if 65 - 65: Ii1I . iIii1I11I1II1 / O0 - Ii1I
  if infoLabels : Ii1I1IIii1II . setInfo ( type = "video" , infoLabels = infoLabels )
  if not isFolder : Ii1I1IIii1II . setProperty ( 'IsPlayable' , 'true' )
  if 21 - 21: I1IiiI * iIii1I11I1II1
  xbmcplugin . addDirectoryItem ( self . _addon_handle , o0 , Ii1I1IIii1II , isFolder )
  if 91 - 91: IiII
  if 15 - 15: II111iiii
  if 18 - 18: i11iIiiIii . i1IIi % OoooooooOO / O0
  if 75 - 75: OoOoOO00 % o0oOOo0O0Ooo % o0oOOo0O0Ooo . I1Ii111
 def dp_Main_List ( self ) :
  if 5 - 5: o0oOOo0O0Ooo * ooOoO0o + OoOoOO00 . OOooOOo + OoOoOO00
  for oO in o0oO0 :
   i1i = oO . get ( 'title' )
   if 7 - 7: o0oOOo0O0Ooo - I1IiiI
   if oO . get ( 'uicode' ) == 'GENRE' :
    OOo00O0 = { 'mode' : 'GENRE'
 , 'uicode' : oO . get ( 'came' )
    , 'genre' : '-'
 , 'subgenre' : '-'
    , 'orderby' : oO . get ( 'orderby' )
 , 'ordernm' : oO . get ( 'ordernm' )
 }
   elif oO . get ( 'uicode' ) == 'WATCH' :
    OOo00O0 = { 'mode' : 'WATCH'
 , 'genre' : '-'
 }
   elif oO . get ( 'uicode' ) == 'SEARCH' :
    OOo00O0 = { 'mode' : 'SEARCH'
 , 'genre' : '-'
 }
   else :
    OOo00O0 = { 'mode' : 'GNB_LIST'
 , 'uicode' : oO . get ( 'uicode' )
 , 'came' : oO . get ( 'came' )
 }
    if 73 - 73: i1IIi + I1IiiI
   iII = True
   if 38 - 38: I1Ii111
   if oO . get ( 'uicode' ) == 'XXX' :
    OOo00O0 [ 'mode' ] = 'XXX'
    iII = False
    if 7 - 7: O0 . iII111i % I1ii11iIi11i - I1IiiI - iIii1I11I1II1
   self . add_dir ( i1i , sublabel = '' , img = '' , infoLabels = None , isFolder = iII , params = OOo00O0 )
  if len ( o0oO0 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle )
  if 36 - 36: IiII % ooOoO0o % Oo0Ooo - I1ii11iIi11i
  if 22 - 22: iIii1I11I1II1 / Oo0Ooo * I1ii11iIi11i % iII111i
  if 85 - 85: oO0o % i11iIiiIii - iII111i * OoooooooOO / I1IiiI % I1IiiI
  if 1 - 1: OoO0O00 - oO0o . I11i . OoO0O00 / Oo0Ooo + I11i
 def login_main ( self ) :
  if 78 - 78: O0 . oO0o . II111iiii % OOooOOo
  ( i1iIi , ooOOoooooo , II1I ) = self . get_settings_login_info ( )
  if 84 - 84: IiII . i11iIiiIii . IiII * I1ii11iIi11i - I11i
  if 42 - 42: i11iIiiIii
  if not ( i1iIi and ooOOoooooo ) :
   OoooooOoo = xbmcgui . Dialog ( )
   I11i1iIII = OoooooOoo . yesno ( __name__ , __language__ ( 30101 ) . encode ( 'utf8' ) , __language__ ( 30102 ) . encode ( 'utf8' ) )
   if I11i1iIII == True :
    __addon__ . openSettings ( )
    sys . exit ( )
    if 32 - 32: OoooooooOO / iIii1I11I1II1 - o0oOOo0O0Ooo
    if 91 - 91: iII111i % i1IIi % iIii1I11I1II1
  if self . get_winEpisodeOrderby ( ) == '' :
   self . set_winEpisodeOrderby ( 'desc' )
   if 20 - 20: OOooOOo % Ii1I / Ii1I + Ii1I
   if 45 - 45: oO0o - IiII - OoooooooOO - OoO0O00 . II111iiii / O0
  if self . cookiefile_check ( ) : return
  if 51 - 51: O0 + iII111i
  if 8 - 8: oO0o * OoOoOO00 - Ii1I - OoO0O00 * OOooOOo % I1IiiI
  ii = int ( self . WavveObj . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' ) )
  oOooOOOoOo = xbmcgui . Window ( 10000 ) . getProperty ( 'WAVVE_M_LOGINTIME' )
  if oOooOOOoOo == None or oOooOOOoOo == '' : oOooOOOoOo = int ( '19000101' )
  if 41 - 41: Ii1I - O0 - O0
  if 68 - 68: OOooOOo % I1Ii111
  if 88 - 88: iIii1I11I1II1 - ooOoO0o + OOooOOo
  if xbmcgui . Window ( 10000 ) . getProperty ( 'WAVVE_M_LOGINWAIT' ) == 'TRUE' :
   IiI111111IIII = 0
   while True :
    IiI111111IIII += 1
    if 37 - 37: I1Ii111 / OoOoOO00
    time . sleep ( 0.05 )
    if 23 - 23: O0
    if oOooOOOoOo >= ii : return
    if IiI111111IIII > 600 : return
  else :
   xbmcgui . Window ( 10000 ) . setProperty ( 'WAVVE_M_LOGINWAIT' , 'TRUE' )
   if 85 - 85: Ii1I
  if oOooOOOoOo >= ii :
   xbmcgui . Window ( 10000 ) . setProperty ( 'WAVVE_M_LOGINWAIT' , 'FALSE' )
   return
   if 84 - 84: I1IiiI . iIii1I11I1II1 % OoooooooOO + Ii1I % OoooooooOO % OoO0O00
  if not self . WavveObj . GetCredential ( i1iIi , ooOOoooooo , II1I ) :
   self . addon_noti ( __language__ ( 30103 ) . encode ( 'utf8' ) )
   xbmcgui . Window ( 10000 ) . setProperty ( 'WAVVE_M_LOGINWAIT' , 'FALSE' )
   sys . exit ( )
   if 42 - 42: OoO0O00 / I11i / o0oOOo0O0Ooo + iII111i / OoOoOO00
   if 84 - 84: ooOoO0o * II111iiii + Oo0Ooo
  self . set_winCredential ( self . WavveObj . LoadCredential ( ) )
  self . cookiefile_save ( )
  xbmcgui . Window ( 10000 ) . setProperty ( 'WAVVE_M_LOGINWAIT' , 'FALSE' )
  if 53 - 53: iII111i % II111iiii . IiII - iIii1I11I1II1 - IiII * II111iiii
  if 77 - 77: iIii1I11I1II1 * OoO0O00
  if 95 - 95: I1IiiI + i11iIiiIii
  if 6 - 6: ooOoO0o / i11iIiiIii + iII111i * oO0o
  if 80 - 80: II111iiii
  if 83 - 83: I11i . i11iIiiIii + II111iiii . o0oOOo0O0Ooo * I11i
 def dp_setEpOrderby ( self , args ) :
  oooO0 = args . get ( 'orderby' )
  if 46 - 46: I1Ii111
  self . set_winEpisodeOrderby ( oooO0 )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 60 - 60: o0oOOo0O0Ooo
  if 25 - 25: OoO0O00
  if 62 - 62: OOooOOo + O0
  if 98 - 98: o0oOOo0O0Ooo
 def dp_Gnb_List ( self , args ) :
  if 51 - 51: Oo0Ooo - oO0o + II111iiii * Ii1I . I11i + oO0o
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 78 - 78: i11iIiiIii / iII111i - Ii1I / OOooOOo + oO0o
  oOoooo0O0Oo = self . WavveObj . GetGnList ( args . get ( 'uicode' ) )
  if 76 - 76: Ii1I + IiII
  if 34 - 34: Oo0Ooo
  if 89 - 89: Oo0Ooo * OoOoOO00 * I1Ii111 + iII111i - I11i
  if 8 - 8: o0oOOo0O0Ooo % O0 / I1IiiI - oO0o
  for Ii1I1i in oOoooo0O0Oo :
   i1i = Ii1I1i . get ( 'title' )
   OOo00O0 = { 'mode' : 'GN_LIST' if Ii1I1i . get ( 'uicode' ) != 'CY1' else 'GN_MYVIEW'
   , 'uicode' : Ii1I1i . get ( 'uicode' )
 , 'came' : args . get ( 'came' )
 , 'page' : '1'
 }
   if 99 - 99: oO0o . iII111i + ooOoO0o % oO0o . i11iIiiIii % O0
   self . add_dir ( i1i , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = OOo00O0 )
  if len ( oOoooo0O0Oo ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 78 - 78: I1ii11iIi11i + OOooOOo - I1Ii111
  if 38 - 38: o0oOOo0O0Ooo - oO0o + iIii1I11I1II1 / OoOoOO00 % Oo0Ooo
  if 57 - 57: OoO0O00 / ooOoO0o
  if 29 - 29: iIii1I11I1II1 + OoOoOO00 * OoO0O00 * OOooOOo . I1IiiI * I1IiiI
 def dp_Myview_Group ( self , args ) :
  i1i = 'VOD 시청내역'
  OOo00O0 = { 'mode' : 'MYVIEW_LIST'
 , 'uicode' : 'vod'
 , 'page' : '1'
 }
  self . add_dir ( i1i , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = OOo00O0 )
  if 7 - 7: IiII * I1Ii111 % Ii1I - o0oOOo0O0Ooo
  i1i = '영화 시청내역'
  OOo00O0 [ 'uicode' ] = 'movie'
  self . add_dir ( i1i , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = OOo00O0 )
  if 13 - 13: Ii1I . i11iIiiIii
  xbmcplugin . endOfDirectory ( self . _addon_handle )
  if 56 - 56: I1ii11iIi11i % O0 - I1IiiI
  if 100 - 100: Ii1I - O0 % oO0o * OOooOOo + I1IiiI
  if 88 - 88: OoooooooOO - OoO0O00 * O0 * OoooooooOO . OoooooooOO
  if 33 - 33: I1Ii111 + iII111i * oO0o / iIii1I11I1II1 - I1IiiI
 def dp_Myview_List ( self , args ) :
  if 54 - 54: I1Ii111 / OOooOOo . oO0o % iII111i
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  Oo = self . get_settings_addinfo ( )
  if 65 - 65: Ii1I - oO0o + oO0o + II111iiii
  o0oooOOoOo0 = args . get ( 'uicode' )
  OoOOoOooooOOo = int ( args . get ( 'page' ) )
  oOo0O , oo0O0 = self . WavveObj . GetMyviewList ( o0oooOOoOo0 , OoOOoOooooOOo , addinfoyn = Oo )
  if 22 - 22: OoOoOO00 . OOooOOo * OoOoOO00
  for O000OOO in oOo0O :
   i1i = O000OOO . get ( 'title' )
   II = O000OOO . get ( 'subtitle' )
   o0o0O0O00oOOo = O000OOO . get ( 'thumbnail' )
   if 14 - 14: OoOoOO00 + oO0o
   oo00oO0O0 = O000OOO . get ( 'info' )
   if o0oooOOoOo0 == 'movie' and Oo == True :
    i1i = '%s (%s)' % ( i1i , str ( oo00oO0O0 . get ( 'year' ) ) )
   else :
    oo00oO0O0 [ 'plot' ] = i1i
    if 30 - 30: OOooOOo + I1ii11iIi11i * I11i % i11iIiiIii % OoOoOO00
   if o0oooOOoOo0 == 'vod' :
    OOo00O0 = { 'mode' : 'DEEP_LIST'
 , 'contentid' : O000OOO . get ( 'programid' )
 , 'contentidType' : 'programid'
 , 'uicode' : 'vod'
 , 'page' : '1'
 , 'title' : i1i
    , 'subtitle' : II
    , 'thumbnail' : o0o0O0O00oOOo
    , 'viewage' : O000OOO . get ( 'viewage' )
 }
    iII = True
    if 97 - 97: I1ii11iIi11i % I1ii11iIi11i % oO0o / iII111i - iIii1I11I1II1
   else :
    OOo00O0 = { 'mode' : 'MOVIE'
 , 'contentid' : O000OOO . get ( 'contentid' )
 , 'contentidType' : 'contentid'
 , 'uicode' : 'movie'
 , 'page' : '1'
 , 'title' : i1i
    , 'subtitle' : II
    , 'thumbnail' : o0o0O0O00oOOo
    , 'viewage' : O000OOO . get ( 'viewage' )
 }
    iII = False
    if 69 - 69: I1Ii111
   if O000OOO . get ( 'viewage' ) == '21' : II += ' (%s)' % ( O000OOO . get ( 'viewage' ) )
   if 11 - 11: I1IiiI
   self . add_dir ( i1i , sublabel = II , img = o0o0O0O00oOOo , infoLabels = oo00oO0O0 , isFolder = iII , params = OOo00O0 )
   if 16 - 16: Ii1I + IiII * O0 % i1IIi . I1IiiI
  if oo0O0 :
   if 67 - 67: OoooooooOO / I1IiiI * Ii1I + I11i
   OOo00O0 [ 'mode' ] = 'MYVIEW_LIST'
   OOo00O0 [ 'uicode' ] = o0oooOOoOo0
   OOo00O0 [ 'page' ] = str ( OoOOoOooooOOo + 1 )
   i1i = '[B]%s >>[/B]' % '다음 페이지'
   II = str ( OoOOoOooooOOo + 1 )
   self . add_dir ( i1i , sublabel = II , img = '' , infoLabels = None , isFolder = True , params = OOo00O0 )
   if 65 - 65: OoooooooOO - I1ii11iIi11i / ooOoO0o / II111iiii / i1IIi
  if len ( oOo0O ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 71 - 71: I1Ii111 + Ii1I
  if 28 - 28: OOooOOo
  if 38 - 38: ooOoO0o % II111iiii % I11i / OoO0O00 + OoOoOO00 / i1IIi
  if 54 - 54: iIii1I11I1II1 % I1ii11iIi11i - OOooOOo / oO0o - OoO0O00 . I11i
  if 11 - 11: I1ii11iIi11i . OoO0O00 * IiII * OoooooooOO + ooOoO0o
 def dp_Genre_Group ( self , args ) :
  if 33 - 33: O0 * o0oOOo0O0Ooo - I1Ii111 % I1Ii111
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 18 - 18: I1Ii111 / Oo0Ooo * I1Ii111 + I1Ii111 * i11iIiiIii * I1ii11iIi11i
  I1II1 = args . get ( 'mode' )
  oooO = args . get ( 'uicode' )
  i1I1i111Ii = args . get ( 'genre' )
  ooo = args . get ( 'subgenre' )
  oooO0 = args . get ( 'orderby' )
  i1i1iI1iiiI = args . get ( 'ordernm' )
  if 51 - 51: I1IiiI % I1Ii111 . oO0o / iIii1I11I1II1 / I11i . oO0o
  if i1I1i111Ii == '-' :
   IIIii11 = self . WavveObj . GetGenreGroup ( oooO , i1I1i111Ii , oooO0 , i1i1iI1iiiI , exclusion21 = self . get_settings_exclusion21 ( ) )
  else :
   iiIiIIIiiI = { 'adult' : args . get ( 'adult' )
 , 'broadcastid' : args . get ( 'broadcastid' )
 , 'contenttype' : args . get ( 'contenttype' )
 , 'genre' : args . get ( 'genre' )
 , 'uiparent' : args . get ( 'uiparent' )
 , 'uirank' : args . get ( 'uirank' )
 , 'uitype' : args . get ( 'uitype' )
 , 'orderby' : oooO0
 , 'ordernm' : i1i1iI1iiiI
 }
   if 12 - 12: O0 - o0oOOo0O0Ooo
   IIIii11 = self . WavveObj . GetGenreGroup_sub ( iiIiIIIiiI )
   if 81 - 81: OoOoOO00 - OoOoOO00 . iII111i
   if 73 - 73: I11i % i11iIiiIii - I1IiiI
  for Ii1iI111II1I1 in IIIii11 :
   i1i = Ii1iI111II1I1 . get ( 'title' ) + '  (' + i1i1iI1iiiI + ')'
   if 91 - 91: OOooOOo % OOooOOo - I1IiiI
   OOo00O0 = { 'mode' : I1II1
 , 'uicode' : oooO
   , 'genre' : Ii1iI111II1I1 . get ( 'genre' )
 , 'subgenre' : Ii1iI111II1I1 . get ( 'subgenre' )
 , 'adult' : Ii1iI111II1I1 . get ( 'adult' )
 , 'page' : '1'
 , 'broadcastid' : Ii1iI111II1I1 . get ( 'broadcastid' )
 , 'contenttype' : Ii1iI111II1I1 . get ( 'contenttype' )
 , 'uiparent' : Ii1iI111II1I1 . get ( 'uiparent' )
 , 'uirank' : Ii1iI111II1I1 . get ( 'uirank' )
 , 'uitype' : Ii1iI111II1I1 . get ( 'uitype' )
 , 'orderby' : oooO0
 , 'ordernm' : i1i1iI1iiiI
 }
   if 18 - 18: I11i - i11iIiiIii / II111iiii . OOooOOo
   if oooO == 'moviegenre' or oooO == 'moviegenre_svod' or oooO == 'moviegenre_ppv' or Ii1iI111II1I1 . get ( 'subgenre' ) != '-' :
    OOo00O0 [ 'mode' ] = 'GENRE_LIST'
    if 55 - 55: i1IIi % II111iiii + I11i * iIii1I11I1II1
   else :
    if 81 - 81: IiII % i1IIi . iIii1I11I1II1
    None
    if 4 - 4: i11iIiiIii % OoO0O00 % i1IIi / IiII
   self . add_dir ( i1i , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = OOo00O0 )
   if 6 - 6: iII111i / I1IiiI % OOooOOo - I1IiiI
  if len ( IIIii11 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 31 - 31: OOooOOo
  if 23 - 23: I1Ii111 . IiII
  if 92 - 92: OoOoOO00 + I1Ii111 * Ii1I % I1IiiI
  if 42 - 42: Oo0Ooo
 def dp_Genre_List ( self , args ) :
  if 76 - 76: I1IiiI * iII111i % I1Ii111
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  Oo = self . get_settings_addinfo ( )
  if 57 - 57: iIii1I11I1II1 - i1IIi / I1Ii111 - O0 * OoooooooOO % II111iiii
  oooO = args . get ( 'uicode' )
  OoOOoOooooOOo = int ( args . get ( 'page' ) )
  if 68 - 68: OoooooooOO * I11i % OoOoOO00 - IiII
  OOo00O0 = { 'adult' : args . get ( 'adult' )
 , 'broadcastid' : args . get ( 'broadcastid' )
 , 'contenttype' : args . get ( 'contenttype' )
 , 'genre' : args . get ( 'genre' )
 , 'subgenre' : args . get ( 'subgenre' )
 , 'uiparent' : args . get ( 'uiparent' )
 , 'uirank' : args . get ( 'uirank' )
 , 'uitype' : args . get ( 'uitype' )
 , 'orderby' : args . get ( 'orderby' )
 }
  if args . get ( 'genre' ) == args . get ( 'subgenre' ) :
   OOo00O0 [ 'subgenre' ] = 'all'
   if 34 - 34: I1Ii111 . iIii1I11I1II1 * OoOoOO00 * oO0o / I1Ii111 / I1ii11iIi11i
  IIIii11 , oo0O0 = self . WavveObj . GetGenreList ( oooO , OOo00O0 , OoOOoOooooOOo , addinfoyn = Oo )
  if 78 - 78: Oo0Ooo - o0oOOo0O0Ooo / OoOoOO00
  if 10 - 10: iII111i + Oo0Ooo * I1ii11iIi11i + iIii1I11I1II1 / I1Ii111 / I1ii11iIi11i
  if 42 - 42: I1IiiI
  for Ii1iI111II1I1 in IIIii11 :
   i1i = Ii1iI111II1I1 . get ( 'title' )
   o0o0O0O00oOOo = Ii1iI111II1I1 . get ( 'thumbnail' )
   if 38 - 38: OOooOOo + II111iiii % ooOoO0o % OoOoOO00 - Ii1I / OoooooooOO
   oo00oO0O0 = Ii1iI111II1I1 . get ( 'info' )
   if oooO == 'moviegenre_svod' and Oo == True :
    i1i = '%s (%s)' % ( i1i , str ( oo00oO0O0 . get ( 'year' ) ) )
   else :
    oo00oO0O0 [ 'plot' ] = i1i
    if 73 - 73: o0oOOo0O0Ooo * O0 - i11iIiiIii
   if oooO == 'vodgenre' :
    O0O0o0oOOO = { 'mode' : 'DEEP_LIST'
 , 'contentid' : Ii1iI111II1I1 . get ( 'uicode' )
 , 'contentidType' : 'contentid'
 , 'uicode' : 'vod'
 , 'page' : '1'
 , 'title' : i1i
    , 'subtitle' : ''
    , 'thumbnail' : o0o0O0O00oOOo
    , 'viewage' : Ii1iI111II1I1 . get ( 'viewage' )
 }
    iII = True
    if 67 - 67: OoOoOO00 + I1ii11iIi11i . o0oOOo0O0Ooo . II111iiii
   else :
    O0O0o0oOOO = { 'mode' : 'MOVIE'
 , 'contentid' : Ii1iI111II1I1 . get ( 'uicode' )
 , 'contentidType' : 'contentid'
 , 'uicode' : 'movie'
 , 'page' : '1'
 , 'title' : i1i
    , 'subtitle' : ''
    , 'thumbnail' : o0o0O0O00oOOo
    , 'viewage' : Ii1iI111II1I1 . get ( 'viewage' )
 }
    if 98 - 98: iII111i
    iII = False
    if 68 - 68: iIii1I11I1II1 * iIii1I11I1II1 . o0oOOo0O0Ooo / II111iiii % Oo0Ooo
   if O0O0o0oOOO . get ( 'viewage' ) == '21' : i1i += ' (%s)' % ( O0O0o0oOOO . get ( 'viewage' ) )
   if 38 - 38: ooOoO0o - OOooOOo / iII111i
   self . add_dir ( i1i , sublabel = '' , img = o0o0O0O00oOOo , infoLabels = oo00oO0O0 , isFolder = iII , params = O0O0o0oOOO )
   if 66 - 66: O0 % I1ii11iIi11i + i11iIiiIii . OoOoOO00 / Ii1I + I1ii11iIi11i
  if oo0O0 :
   if 86 - 86: o0oOOo0O0Ooo
   OOo00O0 [ 'mode' ] = 'GENRE_LIST'
   OOo00O0 [ 'uicode' ] = oooO
   OOo00O0 [ 'page' ] = str ( OoOOoOooooOOo + 1 )
   i1i = '[B]%s >>[/B]' % '다음 페이지'
   II = str ( OoOOoOooooOOo + 1 )
   self . add_dir ( i1i , sublabel = II , img = '' , infoLabels = None , isFolder = True , params = OOo00O0 )
   if 5 - 5: IiII * OoOoOO00
  if len ( IIIii11 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 5 - 5: I1Ii111
  if 90 - 90: I1Ii111 . ooOoO0o / Ii1I - I11i
  if 40 - 40: OoooooooOO
  if 25 - 25: IiII + Ii1I / ooOoO0o . o0oOOo0O0Ooo % O0 * OoO0O00
 def dp_Deeplink_List ( self , args ) :
  if 84 - 84: ooOoO0o % Ii1I + i11iIiiIii
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  Oo = self . get_settings_addinfo ( )
  if 28 - 28: Oo0Ooo + OoO0O00 * OOooOOo % oO0o . I11i % O0
  oooO = args . get ( 'uicode' )
  I1iiiiIii = args . get ( 'came' )
  OoOOoOooooOOo = int ( args . get ( 'page' ) )
  if 19 - 19: OoO0O00 - Oo0Ooo . O0
  if 60 - 60: II111iiii + Oo0Ooo
  if 9 - 9: ooOoO0o * OoooooooOO - iIii1I11I1II1 + OoOoOO00 / OoO0O00 . OoO0O00
  iiIIi , oo0O0 = self . WavveObj . GetDeeplinkList ( oooO , I1iiiiIii , OoOOoOooooOOo , addinfoyn = Oo )
  if 11 - 11: I1IiiI * oO0o
  for o000oo in iiIIi :
   i1i = o000oo . get ( 'title' )
   II = o000oo . get ( 'subtitle' )
   o0o0O0O00oOOo = o000oo . get ( 'thumbnail' )
   o00o0 = o000oo . get ( 'uicode' )
   II1III1I1I1Ii = o000oo . get ( 'channelepg' )
   if 70 - 70: OoO0O00 % oO0o + OOooOOo / Ii1I % O0
   OOo00O0 = { 'uicode' : o00o0
   , 'came' : I1iiiiIii
 , 'contentid' : o000oo . get ( 'contentid' )
 , 'contentidType' : o000oo . get ( 'contentidType' )
 , 'page' : '1'
 , 'title' : i1i
   , 'subtitle' : II
   , 'thumbnail' : o0o0O0O00oOOo
   , 'viewage' : o000oo . get ( 'viewage' )
 }
   if 100 - 100: o0oOOo0O0Ooo + OOooOOo * o0oOOo0O0Ooo
   if o00o0 == 'channel' :
    OOo00O0 [ 'mode' ] = 'LIVE'
   elif o00o0 == 'movie' :
    OOo00O0 [ 'mode' ] = 'MOVIE'
   else :
    OOo00O0 [ 'mode' ] = 'DEEP_LIST'
    if 80 - 80: o0oOOo0O0Ooo * O0 - Ii1I
    if 66 - 66: i11iIiiIii - OOooOOo * Oo0Ooo
   oo00oO0O0 = o000oo . get ( 'info' )
   if II1III1I1I1Ii :
    oo00oO0O0 [ 'plot' ] = '%s\n\n%s' % ( i1i , II1III1I1I1Ii )
   elif o00o0 == 'movie' and Oo == True :
    i1i = '%s (%s)' % ( i1i , str ( oo00oO0O0 . get ( 'year' ) ) )
   else :
    oo00oO0O0 [ 'plot' ] = '%s\n\n%s' % ( i1i , II )
    if 76 - 76: i11iIiiIii + o0oOOo0O0Ooo / I1ii11iIi11i - OoO0O00 - Ii1I + I1ii11iIi11i
   if o000oo . get ( 'viewage' ) == '21' : II += ' (%s)' % ( o000oo . get ( 'viewage' ) )
   if 51 - 51: iIii1I11I1II1 . ooOoO0o + iIii1I11I1II1
   if o00o0 in [ 'channel' , 'movie' ] :
    iII = False
   elif OOo00O0 [ 'contentidType' ] == 'direct' :
    iII = False
    OOo00O0 [ 'mode' ] = 'VOD'
   else :
    iII = True
    if 95 - 95: I1IiiI
    if 46 - 46: OoOoOO00 + OoO0O00
   self . add_dir ( i1i , sublabel = II , img = o0o0O0O00oOOo , infoLabels = oo00oO0O0 , isFolder = iII , params = OOo00O0 )
   if 70 - 70: iII111i / iIii1I11I1II1
  if oo0O0 :
   if 85 - 85: OoooooooOO % i1IIi * OoooooooOO / I1ii11iIi11i
   OOo00O0 [ 'mode' ] = 'GN_LIST'
   OOo00O0 [ 'uicode' ] = oooO
   OOo00O0 [ 'page' ] = str ( OoOOoOooooOOo + 1 )
   i1i = '[B]%s >>[/B]' % '다음 페이지'
   II = str ( OoOOoOooooOOo + 1 )
   self . add_dir ( i1i , sublabel = II , img = '' , infoLabels = None , isFolder = True , params = OOo00O0 )
   if 96 - 96: OoooooooOO + oO0o
  if len ( iiIIi ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 44 - 44: oO0o
  if 20 - 20: I11i + Ii1I / O0 % iIii1I11I1II1
  if 88 - 88: OoOoOO00 / II111iiii
  if 87 - 87: I1ii11iIi11i - I1ii11iIi11i - iII111i + oO0o
 def dp_Episodelink_List ( self , args ) :
  if 82 - 82: oO0o / iIii1I11I1II1 . I1IiiI . OOooOOo / o0oOOo0O0Ooo
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 42 - 42: Oo0Ooo
  II1IIiiIiI = args . get ( 'contentid' )
  i1II1I1Iii1 = args . get ( 'contentidType' )
  o0oooOOoOo0 = args . get ( 'uicode' )
  if 30 - 30: OoooooooOO - OoOoOO00
  OoOOoOooooOOo = int ( args . get ( 'page' ) )
  if 75 - 75: iIii1I11I1II1 - Ii1I . Oo0Ooo % i11iIiiIii % I11i
  O00 , oo0O0 = self . WavveObj . GetEpisodeList ( II1IIiiIiI , o0oooOOoOo0 , i1II1I1Iii1 , OoOOoOooooOOo , orderby = self . get_winEpisodeOrderby ( ) )
  if 30 - 30: I1IiiI + OoO0O00 % Ii1I * iII111i / Oo0Ooo - I11i
  for oooiIi1i in O00 :
   i1i = oooiIi1i . get ( 'title' )
   II = oooiIi1i . get ( 'subtitle' )
   o0o0O0O00oOOo = oooiIi1i . get ( 'thumbnail' )
   OOo00O0 = { 'mode' : 'VOD'
 , 'uicode' : oooiIi1i . get ( 'uicode' )
   , 'contentid' : oooiIi1i . get ( 'contentid' )
 , 'programid' : oooiIi1i . get ( 'programid' )
 , 'title' : i1i
   , 'subtitle' : II
   , 'thumbnail' : o0o0O0O00oOOo
   , 'viewage' : oooiIi1i . get ( 'viewage' )
 }
   if 27 - 27: OOooOOo * ooOoO0o . I1Ii111 % IiII * IiII . i1IIi
   if oooiIi1i . get ( 'viewage' ) == '21' : II += ' (%s)' % ( oooiIi1i . get ( 'viewage' ) )
   if 72 - 72: OOooOOo % I1ii11iIi11i + OoO0O00 / oO0o + IiII
   I1I1i = oooiIi1i . get ( 'info' )
   I1I1i [ 'plot' ] = oooiIi1i . get ( 'synopsis' )
   if 1 - 1: I11i % OOooOOo + O0 + i1IIi - OoO0O00
   if 22 - 22: I1IiiI % I1ii11iIi11i
   if 57 - 57: OOooOOo + O0 . Ii1I
   if 46 - 46: IiII
   self . add_dir ( i1i , sublabel = II , img = o0o0O0O00oOOo , infoLabels = I1I1i , isFolder = False , params = OOo00O0 )
   if 45 - 45: ooOoO0o
  if OoOOoOooooOOo == 1 :
   oo00oO0O0 = { 'plot' : '정렬순서를 변경합니다.' }
   OOo00O0 = { }
   OOo00O0 [ 'mode' ] = 'ORDER_BY'
   if self . get_winEpisodeOrderby ( ) == 'desc' :
    i1i = '정렬순서변경 : 최신화부터 -> 1회부터'
    OOo00O0 [ 'orderby' ] = 'asc'
   else :
    i1i = '정렬순서변경 : 1회부터 -> 최신화부터'
    OOo00O0 [ 'orderby' ] = 'desc'
   self . add_dir ( i1i , sublabel = '' , img = '' , infoLabels = oo00oO0O0 , isFolder = False , params = OOo00O0 )
   if 21 - 21: oO0o . I1Ii111 . OOooOOo / Oo0Ooo / I1Ii111
  if oo0O0 :
   if 17 - 17: OOooOOo / OOooOOo / I11i
   OOo00O0 [ 'mode' ] = 'DEEP_LIST'
   OOo00O0 [ 'uicode' ] = o0oooOOoOo0
   OOo00O0 [ 'contentid' ] = II1IIiiIiI
   OOo00O0 [ 'contentidType' ] = i1II1I1Iii1
   OOo00O0 [ 'page' ] = str ( OoOOoOooooOOo + 1 )
   i1i = '[B]%s >>[/B]' % '다음 페이지'
   II = str ( OoOOoOooooOOo + 1 )
   self . add_dir ( i1i , sublabel = II , img = '' , infoLabels = None , isFolder = True , params = OOo00O0 )
   if 1 - 1: i1IIi . i11iIiiIii % OOooOOo
   if 82 - 82: iIii1I11I1II1 + Oo0Ooo . iIii1I11I1II1 % IiII / Ii1I . Ii1I
  if len ( O00 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 14 - 14: o0oOOo0O0Ooo . OOooOOo . I11i + OoooooooOO - OOooOOo + IiII
  if 9 - 9: Ii1I
  if 59 - 59: I1IiiI * II111iiii . O0
 def play_VIDEO ( self , args ) :
  if 56 - 56: Ii1I - iII111i % I1IiiI - o0oOOo0O0Ooo
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  if 51 - 51: O0 / ooOoO0o * iIii1I11I1II1 + I1ii11iIi11i + o0oOOo0O0Ooo
  II1IIiiIiI = args . get ( 'contentid' )
  o0oooOOoOo0 = args . get ( 'uicode' )
  Oo0OO0000oooo = self . get_selQuality ( )
  if 7 - 7: oO0o - OoO0O00 - O0 % oO0o - II111iiii
  self . addon_log ( II1IIiiIiI + ' - ' + o0oooOOoOo0 , False )
  I1II , Oo000ooOOO , Ii11i1I11i , I11i1 = self . WavveObj . GetStreamingURL ( II1IIiiIiI , o0oooOOoOo0 , Oo0OO0000oooo )
  if 28 - 28: I11i
  if 58 - 58: OoOoOO00
  iIiiI1iI = '%s|Cookie=%s' % ( I1II , Oo000ooOOO )
  self . addon_log ( iIiiI1iI , False )
  if 5 - 5: OoOoOO00 / OoooooooOO + IiII * I1Ii111 - OoO0O00 % I1IiiI
  if I1II == '' :
   self . addon_noti ( __language__ ( 30303 ) . encode ( 'utf8' ) )
   return
   if 42 - 42: O0 / o0oOOo0O0Ooo + OoooooooOO * ooOoO0o % ooOoO0o
  i1iIiIIIII = xbmcgui . ListItem ( path = iIiiI1iI )
  if 78 - 78: Ii1I * i1IIi
  if Ii11i1I11i :
   if 1 - 1: I1IiiI / IiII * ooOoO0o
   if 1 - 1: I11i * o0oOOo0O0Ooo . OoOoOO00 / O0
   O00O0ooo0 = Ii11i1I11i [ 'customdata' ]
   I1iii11 = Ii11i1I11i [ 'drmhost' ]
   if 74 - 74: O0 / i1IIi
   OoO = 'mpd'
   Iiiiii111i1ii = 'com.widevine.alpha'
   if 25 - 25: OOooOOo - ooOoO0o / i11iIiiIii
   iiI1ii11i1 = inputstreamhelper . Helper ( OoO , drm = Iiiiii111i1ii )
   if 38 - 38: I1ii11iIi11i - iII111i / O0 . I1Ii111
   if iiI1ii11i1 . check_inputstream ( ) :
    if 45 - 45: I1Ii111
    if o0oooOOoOo0 == 'movie' :
     oOIIi1iiii1iI = 'https://www.wavve.com/player/movie?movieid=%s' % II1IIiiIiI
    else :
     oOIIi1iiii1iI = 'https://www.wavve.com/player/vod?programid=%s&page=1' % II1IIiiIiI
     if 25 - 25: I1ii11iIi11i + O0
    i1II = { 'content-type' : 'application/octet-stream'
 , 'origin' : 'https://www.wavve.com'
 , 'pallycon-customdata' : O00O0ooo0
 , 'referer' : oOIIi1iiii1iI
 , 'sec-fetch-dest' : 'empty'
    , 'sec-fetch-mode' : 'cors'
 , 'sec-fetch-site' : 'same-site'

    , 'user-agent' : OOo000
 }
    O0OOO0OOooo00 = I1iii11 + '|' + urllib . urlencode ( i1II ) + '|R{SSM}|'
    if 6 - 6: Ii1I - ooOoO0o * OOooOOo . iII111i / O0 * ooOoO0o
    i1iIiIIIII . setProperty ( 'inputstreamaddon' , iiI1ii11i1 . inputstream_addon )
    i1iIiIIIII . setProperty ( 'inputstream.adaptive.manifest_type' , OoO )
    i1iIiIIIII . setProperty ( 'inputstream.adaptive.license_type' , Iiiiii111i1ii )
    if 22 - 22: Oo0Ooo % iII111i * I1ii11iIi11i / OOooOOo % i11iIiiIii * I11i
    i1iIiIIIII . setProperty ( 'inputstream.adaptive.license_key' , O0OOO0OOooo00 )
    i1iIiIIIII . setProperty ( 'inputstream.adaptive.stream_headers' , 'Cookie=%s' % Oo000ooOOO )
    if 95 - 95: OoooooooOO - IiII * I1IiiI + OoOoOO00
  xbmcplugin . setResolvedUrl ( self . _addon_handle , True , i1iIiIIIII )
  if 10 - 10: o0oOOo0O0Ooo / i11iIiiIii
  if I11i1 :
   self . addon_noti ( I11i1 . encode ( 'utf-8' ) )
  else :
   if '/preview.' in urlparse . urlsplit ( I1II ) . path : self . addon_noti ( __language__ ( 30401 ) . encode ( 'utf8' ) )
   if 92 - 92: I11i . I1Ii111
  try :
   if args . get ( 'mode' ) in [ 'VOD' , 'MOVIE' ] and args . get ( 'title' ) and args . get ( 'viewage' ) != '21' :
    OOo00O0 = { 'code' : args . get ( 'programid' ) if args . get ( 'mode' ) == 'VOD' else args . get ( 'contentid' )
 , 'img' : args . get ( 'thumbnail' )
 , 'title' : args . get ( 'title' )
 , 'subtitle' : args . get ( 'subtitle' )
 , 'videoid' : args . get ( 'contentid' )
    }
    self . Save_Watched_List ( args . get ( 'mode' ) . lower ( ) , OOo00O0 )
  except :
   None
   if 85 - 85: I1ii11iIi11i . I1Ii111
   if 78 - 78: ooOoO0o * I1Ii111 + iIii1I11I1II1 + iIii1I11I1II1 / I1Ii111 . Ii1I
   if 97 - 97: ooOoO0o / I1Ii111 % i1IIi % I1ii11iIi11i
   if 18 - 18: iIii1I11I1II1 % I11i
 def dp_Watch_List ( self , args ) :
  i1I1i111Ii = args . get ( 'genre' )
  oOooOOo00Oo0O = self . get_settings_direct_replay ( )
  if 95 - 95: ooOoO0o + i11iIiiIii * I1Ii111 - i1IIi * I1Ii111 - iIii1I11I1II1
  if i1I1i111Ii == '-' :
   i1i = 'VOD 시청내역'
   OOo00O0 = { 'mode' : 'WATCH'
 , 'genre' : 'vod'
 }
   self . add_dir ( i1i , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = OOo00O0 )
   if 75 - 75: OoooooooOO * IiII
   i1i = '영화 시청내역'
   OOo00O0 [ 'genre' ] = 'movie'
   self . add_dir ( i1i , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = OOo00O0 )
   if 9 - 9: IiII - II111iiii + O0 / iIii1I11I1II1 / i11iIiiIii
   xbmcplugin . endOfDirectory ( self . _addon_handle )
   if 39 - 39: IiII * Oo0Ooo + iIii1I11I1II1 - IiII + OOooOOo
  else :
   o0iiiI1I1iIIIi1 = self . Load_Watched_List ( i1I1i111Ii )
   if 17 - 17: iIii1I11I1II1 . OoooooooOO / I11i % II111iiii % i1IIi / i11iIiiIii
   for OOO in o0iiiI1I1iIIIi1 :
    Iiiiii1iI = dict ( urlparse . parse_qsl ( OOO ) )
    if 49 - 49: o0oOOo0O0Ooo . IiII / OoO0O00 + II111iiii
    i1i = Iiiiii1iI . get ( 'title' ) . strip ( )
    II = Iiiiii1iI . get ( 'subtitle' ) . strip ( )
    if II == 'None' : II = ''
    o0o0O0O00oOOo = Iiiiii1iI . get ( 'img' )
    ii11i = Iiiiii1iI . get ( 'videoid' )
    if 35 - 35: I1ii11iIi11i * iII111i - OoO0O00 % o0oOOo0O0Ooo
    if 87 - 87: OoOoOO00 * I1Ii111 . I11i
    oo00oO0O0 = { }
    if i1I1i111Ii == 'movie' and self . get_settings_addinfo ( ) == True :
     O0Oo0o000oO = self . WavveObj . GetMovieInfoList ( [ Iiiiii1iI . get ( 'code' ) ] )
     oo00oO0O0 = O0Oo0o000oO . get ( Iiiiii1iI . get ( 'code' ) )
    else :
     oo00oO0O0 [ 'plot' ] = '%s\n%s' % ( i1i , II )
     if 99 - 99: oO0o * II111iiii * I1Ii111
    if i1I1i111Ii == 'vod' :
     if oOooOOo00Oo0O == False or ii11i == None :
      OOo00O0 = { 'mode' : 'DEEP_LIST'
 , 'contentid' : Iiiiii1iI . get ( 'code' )
 , 'contentidType' : 'programid'
 , 'uicode' : 'vod'
 , 'page' : '1'
 }
      iII = True
     else :
      OOo00O0 = { 'mode' : 'VOD'
 , 'contentid' : ii11i
 , 'contentidType' : 'contentid'
 , 'programid' : Iiiiii1iI . get ( 'code' )
 , 'uicode' : 'vod'
 , 'title' : i1i
 , 'subtitle' : II
 , 'thumbnail' : o0o0O0O00oOOo
 }
      iII = False
    else :
     OOo00O0 = { 'mode' : 'MOVIE'
 , 'contentid' : Iiiiii1iI . get ( 'code' )
 , 'contentidType' : 'contentid'
 , 'uicode' : 'movie'
 , 'title' : i1i
 , 'thumbnail' : o0o0O0O00oOOo
 }
     iII = False
     if 92 - 92: Oo0Ooo
    self . add_dir ( i1i , sublabel = II , img = o0o0O0O00oOOo , infoLabels = oo00oO0O0 , isFolder = iII , params = OOo00O0 )
    if 40 - 40: OoOoOO00 / IiII
   oo00oO0O0 = { 'plot' : '시청목록을 삭제합니다.' }
   i1i = '*** 시청목록 삭제 ***'
   OOo00O0 = { 'mode' : 'MYVIEW_REMOVE'
 , 'genre' : i1I1i111Ii
 }
   if 79 - 79: OoO0O00 - iIii1I11I1II1 + Ii1I - I1Ii111
   self . add_dir ( i1i , sublabel = '' , img = '' , infoLabels = oo00oO0O0 , isFolder = False , params = OOo00O0 )
   if 93 - 93: II111iiii . I1IiiI - Oo0Ooo + OoOoOO00
   xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
   if 61 - 61: II111iiii
   if 15 - 15: i11iIiiIii % I1IiiI * I11i / I1Ii111
   if 90 - 90: iII111i
   if 31 - 31: OOooOOo + O0
   if 87 - 87: ooOoO0o
 def dp_Search_Group ( self , args ) :
  i1i = 'VOD 검색'
  OOo00O0 = { 'mode' : 'SEARCH_LIST'
 , 'genre' : 'vod'
 , 'page' : '1'
 }
  self . add_dir ( i1i , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = OOo00O0 )
  if 45 - 45: OoO0O00 / OoooooooOO - iII111i / Ii1I % IiII
  i1i = '영화 검색'
  OOo00O0 [ 'genre' ] = 'movie'
  self . add_dir ( i1i , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = OOo00O0 )
  if 83 - 83: I1IiiI . iIii1I11I1II1 - IiII * i11iIiiIii
  xbmcplugin . endOfDirectory ( self . _addon_handle )
  if 20 - 20: i1IIi * I1Ii111 + II111iiii % o0oOOo0O0Ooo % oO0o
  if 13 - 13: Oo0Ooo
  if 60 - 60: I1ii11iIi11i * I1IiiI
  if 17 - 17: OOooOOo % Oo0Ooo / I1ii11iIi11i . IiII * OOooOOo - II111iiii
 def dp_Search_List ( self , args ) :
  if 41 - 41: Ii1I
  self . WavveObj . SaveCredential ( self . get_winCredential ( ) )
  Oo = self . get_settings_addinfo ( )
  if 77 - 77: I1Ii111
  o0oooOOoOo0 = args . get ( 'genre' )
  OoOOoOooooOOo = int ( args . get ( 'page' ) )
  if 65 - 65: II111iiii . I1IiiI % oO0o * OoO0O00
  if 'search_key' in args :
   iI11I = args . get ( 'search_key' )
  else :
   iI11I = self . get_keyboard_input ( __language__ ( 30003 ) . encode ( 'utf-8' ) )
   if not iI11I : return
   if 11 - 11: iII111i - oO0o + II111iiii - iIii1I11I1II1
  I1i11ii11 , oo0O0 = self . WavveObj . GetSearchList ( iI11I , o0oooOOoOo0 , OoOOoOooooOOo , exclusion21 = self . get_settings_exclusion21 ( ) , addinfoyn = Oo )
  if 81 - 81: OOooOOo - I11i % ooOoO0o - OoO0O00 / Oo0Ooo
  for Ii1iI111 in I1i11ii11 :
   i1i = Ii1iI111 . get ( 'title' )
   o0o0O0O00oOOo = Ii1iI111 . get ( 'thumbnail' )
   if 51 - 51: IiII * O0 / II111iiii . Ii1I % OOooOOo / I1IiiI
   oo00oO0O0 = Ii1iI111 . get ( 'info' )
   if o0oooOOoOo0 == 'movie' and Oo == True :
    i1i = '%s (%s)' % ( i1i , str ( oo00oO0O0 . get ( 'year' ) ) )
   else :
    oo00oO0O0 [ 'plot' ] = i1i
    if 9 - 9: I1IiiI % I1IiiI % II111iiii
   if o0oooOOoOo0 == 'vod' :
    OOo00O0 = { 'mode' : 'DEEP_LIST'
 , 'contentid' : Ii1iI111 . get ( 'programid' )
 , 'contentidType' : 'programid'
 , 'uicode' : 'vod'
 , 'page' : '1'
 , 'title' : i1i
    , 'subtitle' : ''
    , 'thumbnail' : o0o0O0O00oOOo
    , 'viewage' : Ii1iI111 . get ( 'viewage' )
 }
    iII = True
    if 30 - 30: IiII + I1Ii111 - IiII . IiII - II111iiii + O0
   else :
    OOo00O0 = { 'mode' : 'MOVIE'
 , 'contentid' : Ii1iI111 . get ( 'contentid' )
 , 'contentidType' : 'contentid'
 , 'uicode' : 'movie'
 , 'page' : '1'
 , 'title' : i1i
    , 'subtitle' : ''
    , 'thumbnail' : o0o0O0O00oOOo
    , 'viewage' : Ii1iI111 . get ( 'viewage' )
 }
    if 86 - 86: i1IIi
    iII = False
    if 41 - 41: OoOoOO00 * I11i / OoOoOO00 % oO0o
   if OOo00O0 . get ( 'viewage' ) == '21' : i1i += ' (%s)' % ( OOo00O0 . get ( 'viewage' ) )
   if 18 - 18: II111iiii . OoooooooOO % OoOoOO00 % Ii1I
   self . add_dir ( i1i , sublabel = '' , img = o0o0O0O00oOOo , infoLabels = oo00oO0O0 , isFolder = iII , params = OOo00O0 )
   if 9 - 9: OoO0O00 - Oo0Ooo * OoooooooOO . Oo0Ooo
  if oo0O0 :
   if 2 - 2: OoooooooOO % OOooOOo
   OOo00O0 [ 'mode' ] = 'SEARCH_LIST'
   OOo00O0 [ 'genre' ] = o0oooOOoOo0
   OOo00O0 [ 'page' ] = str ( OoOOoOooooOOo + 1 )
   OOo00O0 [ 'search_key' ] = iI11I
   i1i = '[B]%s >>[/B]' % '다음 페이지'
   II = str ( OoOOoOooooOOo + 1 )
   self . add_dir ( i1i , sublabel = II , img = '' , infoLabels = None , isFolder = True , params = OOo00O0 )
   if 63 - 63: I1IiiI % iIii1I11I1II1
  if len ( I1i11ii11 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle )
  if 39 - 39: iII111i / II111iiii / I1ii11iIi11i % I1IiiI
  if 89 - 89: I1Ii111 + OoooooooOO + I1Ii111 * i1IIi + iIii1I11I1II1 % I11i
  if 59 - 59: OOooOOo + i11iIiiIii
  if 88 - 88: i11iIiiIii - ooOoO0o
  if 67 - 67: OOooOOo . Oo0Ooo + OoOoOO00 - OoooooooOO
 def Load_Watched_List ( self , genre ) :
  try :
   OOOoO = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % genre ) )
   with open ( OOOoO , 'r' ) as I1i :
    iiiI = I1i . readlines ( )
  except :
   iiiI = [ ]
   if 21 - 21: i11iIiiIii / i1IIi + I1IiiI * OOooOOo . I1Ii111
  return iiiI
  if 84 - 84: O0 . I11i - II111iiii . ooOoO0o / II111iiii
  if 47 - 47: OoooooooOO
  if 4 - 4: I1IiiI % I11i
  if 10 - 10: IiII . OoooooooOO - OoO0O00 + IiII - O0
 def Save_Watched_List ( self , genre , in_params ) :
  try :
   OOOoO = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % genre ) )
   o0oO00 = self . Load_Watched_List ( genre )
   if 65 - 65: OOooOOo . I1Ii111 . OoO0O00 . iII111i - OOooOOo
   with open ( OOOoO , 'w' ) as I1i :
    ii111i = urllib . urlencode ( in_params )
    ii111i = ii111i . encode ( 'utf-8' ) + '\n'
    I1i . write ( ii111i )
    if 93 - 93: OoO0O00
    i111I = 0
    for OOO0oOoO0O in o0oO00 :
     OoOo000oOo0oo = dict ( urlparse . parse_qsl ( OOO0oOoO0O ) )
     if 65 - 65: OoOoOO00 / OoO0O00 % IiII
     iIiIIii = in_params . get ( 'code' )
     OOo00 = OoOo000oOo0oo . get ( 'code' )
     if genre == 'vod' and self . get_settings_direct_replay ( ) == True :
      iIiIIii = in_params . get ( 'videoid' )
      OOo00 = OoOo000oOo0oo . get ( 'videoid' ) if OOo00 != None else '-'
      if 37 - 37: i1IIi
     if iIiIIii != OOo00 :
      I1i . write ( OOO0oOoO0O )
      i111I += 1
      if i111I >= 50 : break
  except :
   None
   if 46 - 46: OoOoOO00 - I11i - Ii1I . i1IIi
   if 35 - 35: II111iiii * I11i - OoooooooOO . I11i . I11i
   if 11 - 11: I1Ii111 / OoOoOO00 + I11i % iIii1I11I1II1
   if 42 - 42: I1ii11iIi11i * OoOoOO00 % ooOoO0o - OoOoOO00 . i11iIiiIii - I1Ii111
 def Delete_Watched_List ( self , genre ) :
  try :
   OOOoO = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % genre ) )
   with open ( OOOoO , 'w' ) as I1i :
    I1i . write ( '' )
  except :
   None
   if 84 - 84: I1Ii111 - I1ii11iIi11i / I11i
   if 13 - 13: IiII - Oo0Ooo - ooOoO0o
   if 92 - 92: ooOoO0o / OoOoOO00 * OoO0O00 . I11i % II111iiii
   if 71 - 71: I1Ii111 % i1IIi - II111iiii - OOooOOo + OOooOOo * ooOoO0o
 def dp_WatchList_Delete ( self , args ) :
  i1I1i111Ii = args . get ( 'genre' )
  if 51 - 51: iIii1I11I1II1 / OoOoOO00 + OOooOOo - I11i + iII111i
  OoooooOoo = xbmcgui . Dialog ( )
  I11i1iIII = OoooooOoo . yesno ( __name__ , __language__ ( 30201 ) . encode ( 'utf8' ) , __language__ ( 30202 ) . encode ( 'utf8' ) )
  if I11i1iIII == False : sys . exit ( )
  if 29 - 29: o0oOOo0O0Ooo % iIii1I11I1II1 . OoooooooOO % OoooooooOO % II111iiii / iII111i
  self . Delete_Watched_List ( i1I1i111Ii )
  if 70 - 70: i11iIiiIii % iII111i
  xbmc . executebuiltin ( "Container.Refresh" )
  if 11 - 11: IiII % I1ii11iIi11i % Ii1I / II111iiii % I1Ii111 - Oo0Ooo
  if 96 - 96: I1ii11iIi11i / II111iiii . Ii1I - iII111i * I11i * oO0o
  if 76 - 76: Ii1I - II111iiii * OOooOOo / OoooooooOO
  if 18 - 18: OoO0O00 + iIii1I11I1II1 - II111iiii - I1IiiI
 def logout ( self ) :
  OoooooOoo = xbmcgui . Dialog ( )
  I11i1iIII = OoooooOoo . yesno ( __language__ ( 30910 ) . encode ( 'utf8' ) , __language__ ( 30202 ) . encode ( 'utf8' ) )
  if I11i1iIII == False : sys . exit ( )
  if 71 - 71: OoooooooOO
  self . wininfo_clear ( )
  if 33 - 33: I1Ii111
  if 62 - 62: I1ii11iIi11i + Ii1I + i1IIi / OoooooooOO
  if os . path . isfile ( O0I11i1i11i1I ) : os . remove ( O0I11i1i11i1I )
  if 7 - 7: o0oOOo0O0Ooo + i1IIi . I1IiiI / Oo0Ooo
  self . addon_noti ( __language__ ( 30909 ) . encode ( 'utf-8' ) )
  if 22 - 22: ooOoO0o - ooOoO0o % OOooOOo . I1Ii111 + oO0o
  if 63 - 63: I1IiiI % I1Ii111 * o0oOOo0O0Ooo + I1Ii111 / Oo0Ooo % iII111i
  if 45 - 45: IiII
  if 20 - 20: OoooooooOO * o0oOOo0O0Ooo * O0 . OOooOOo
 def wininfo_clear ( self ) :
  if 78 - 78: iIii1I11I1II1 + I11i - Ii1I * I1Ii111 - OoooooooOO % OoOoOO00
  IIi1iIIiI = xbmcgui . Window ( 10000 )
  IIi1iIIiI . setProperty ( 'WAVVE_M_CREDENTIAL' , '' )
  IIi1iIIiI . setProperty ( 'WAVVE_M_LOGINTIME' , '' )
  if 34 - 34: O0
  if 80 - 80: i1IIi - Oo0Ooo / OoO0O00 - i11iIiiIii
  if 68 - 68: oO0o - I1ii11iIi11i % O0 % I1Ii111
  if 11 - 11: O0 / OoO0O00 % OOooOOo + o0oOOo0O0Ooo + iIii1I11I1II1
 def cookiefile_save ( self ) :
  I1i1111I = self . WavveObj . Get_Now_Datetime ( )
  OooOO0o0 = I1i1111I + datetime . timedelta ( days = int ( __addon__ . getSetting ( 'cache_ttl' ) ) )
  if 91 - 91: oO0o + OoooooooOO - i1IIi
  IIi1iIIiI = xbmcgui . Window ( 10000 )
  o000 = { 'wavve_token' : IIi1iIIiI . getProperty ( 'WAVVE_M_CREDENTIAL' )
 , 'wavve_id' : base64 . standard_b64encode ( __addon__ . getSetting ( 'id' ) . encode ( ) ) . decode ( 'utf-8' )
 , 'wavve_pw' : base64 . standard_b64encode ( __addon__ . getSetting ( 'pw' ) . encode ( ) ) . decode ( 'utf-8' )
 , 'wavve_profile' : __addon__ . getSetting ( 'selected_profile' )
 , 'wavve_limitdate' : OooOO0o0 . strftime ( '%Y-%m-%d' )
 }
  if 94 - 94: o0oOOo0O0Ooo + O0 / I11i . I1IiiI + OOooOOo . iIii1I11I1II1
  try :
   with open ( O0I11i1i11i1I , 'w' ) as I1i :
    json . dump ( o000 , I1i )
  except Exception as OOOoOoOooo :
   print ( OOOoOoOooo )
   if 74 - 74: iIii1I11I1II1 * IiII % OoOoOO00
   if 36 - 36: OoooooooOO - oO0o
   if 85 - 85: o0oOOo0O0Ooo . IiII / O0 . o0oOOo0O0Ooo . I1ii11iIi11i . OoO0O00
   if 60 - 60: o0oOOo0O0Ooo - OoOoOO00 * Oo0Ooo % Ii1I / II111iiii % OoOoOO00
 def cookiefile_check ( self ) :
  if 52 - 52: OOooOOo - iII111i * oO0o
  if 17 - 17: OoooooooOO + OOooOOo * I11i * OoOoOO00
  o000 = { }
  try :
   with open ( O0I11i1i11i1I , 'r' ) as I1i :
    o000 = json . load ( I1i )
  except Exception as OOOoOoOooo :
   self . wininfo_clear ( )
   return False
   if 36 - 36: O0 + Oo0Ooo
   if 5 - 5: Oo0Ooo * OoOoOO00
   if 46 - 46: ooOoO0o
  i1iIi = __addon__ . getSetting ( 'id' )
  ooOOoooooo = __addon__ . getSetting ( 'pw' )
  I11iIiII = __addon__ . getSetting ( 'selected_profile' )
  o000 [ 'wavve_id' ] = base64 . standard_b64decode ( o000 [ 'wavve_id' ] ) . decode ( 'utf-8' )
  o000 [ 'wavve_pw' ] = base64 . standard_b64decode ( o000 [ 'wavve_pw' ] ) . decode ( 'utf-8' )
  if i1iIi != o000 [ 'wavve_id' ] or ooOOoooooo != o000 [ 'wavve_pw' ] or I11iIiII != o000 [ 'wavve_profile' ] :
   self . wininfo_clear ( )
   return False
   if 66 - 66: Oo0Ooo - o0oOOo0O0Ooo * IiII + OoOoOO00 + o0oOOo0O0Ooo - iIii1I11I1II1
   if 17 - 17: oO0o
  ii = int ( self . WavveObj . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' ) )
  i1ii11 = o000 [ 'wavve_limitdate' ]
  oOooOOOoOo = int ( re . sub ( '-' , '' , i1ii11 ) )
  if 49 - 49: OoooooooOO / i11iIiiIii * i11iIiiIii
  if 58 - 58: oO0o
  if oOooOOOoOo < ii :
   self . wininfo_clear ( )
   return False
   if 4 - 4: II111iiii . ooOoO0o / I1ii11iIi11i - i11iIiiIii
   if 72 - 72: O0 / ooOoO0o + OoooooooOO * iII111i
  IIi1iIIiI = xbmcgui . Window ( 10000 )
  IIi1iIIiI . setProperty ( 'WAVVE_M_CREDENTIAL' , o000 [ 'wavve_token' ] )
  IIi1iIIiI . setProperty ( 'WAVVE_M_LOGINTIME' , i1ii11 )
  if 61 - 61: OoooooooOO % II111iiii - I1IiiI % I1ii11iIi11i + i1IIi
  return True
  if 39 - 39: i1IIi
  if 86 - 86: iIii1I11I1II1 + OoOoOO00 . i11iIiiIii - Ii1I
  if 51 - 51: OoOoOO00
  if 14 - 14: IiII % oO0o % Oo0Ooo - i11iIiiIii
 def wavve_main ( self ) :
  if 53 - 53: Ii1I % Oo0Ooo
  I1II1 = self . main_params . get ( 'mode' , None )
  if 59 - 59: OOooOOo % iIii1I11I1II1 . i1IIi + II111iiii * IiII
  self . login_main ( )
  if I1II1 is None :
   if 41 - 41: Ii1I % I1ii11iIi11i
   self . dp_Main_List ( )
   if 12 - 12: OOooOOo
   if 69 - 69: OoooooooOO + OOooOOo
   if 26 - 26: Oo0Ooo + OOooOOo / OoO0O00 % OoOoOO00 % I1ii11iIi11i + II111iiii
   if 31 - 31: I11i % OOooOOo * I11i
   if 45 - 45: i1IIi . I1IiiI + OOooOOo - OoooooooOO % ooOoO0o
   if 1 - 1: iIii1I11I1II1
   if 93 - 93: i1IIi . i11iIiiIii . Oo0Ooo
   if 99 - 99: I11i - I1Ii111 - oO0o % OoO0O00
   if 21 - 21: II111iiii % I1ii11iIi11i . i1IIi - OoooooooOO
  elif I1II1 == 'GNB_LIST' :
   self . dp_Gnb_List ( self . main_params )
   if 4 - 4: OoooooooOO . ooOoO0o
  elif I1II1 == 'GN_LIST' :
   self . dp_Deeplink_List ( self . main_params )
   if 78 - 78: I1ii11iIi11i + I11i - O0
  elif I1II1 == 'DEEP_LIST' :
   o0oooOOoOo0 = self . main_params . get ( 'uicode' , None )
   if 10 - 10: I1Ii111 % I1IiiI
   if o0oooOOoOo0 in [ 'quick' , 'vod' , 'program' , 'x' ] :
    self . dp_Episodelink_List ( self . main_params )
    if 97 - 97: OoooooooOO - I1Ii111
   else : None
   if 58 - 58: iIii1I11I1II1 + O0
  elif I1II1 in [ 'LIVE' , 'VOD' , 'MOVIE' ] :
   self . play_VIDEO ( self . main_params )
   if 30 - 30: ooOoO0o % iII111i * OOooOOo - I1ii11iIi11i * Ii1I % ooOoO0o
   time . sleep ( 0.1 )
   if 46 - 46: i11iIiiIii - O0 . oO0o
  elif I1II1 == 'GN_MYVIEW' :
   self . dp_Myview_Group ( self . main_params )
   if 100 - 100: I1IiiI / o0oOOo0O0Ooo * iII111i . O0 / OOooOOo
  elif I1II1 == 'MYVIEW_LIST' :
   self . dp_Myview_List ( self . main_params )
   if 83 - 83: I1Ii111
  elif I1II1 == 'GENRE' :
   self . dp_Genre_Group ( self . main_params )
   if 48 - 48: II111iiii * OOooOOo * I1Ii111
  elif I1II1 == 'GENRE_LIST' :
   self . dp_Genre_List ( self . main_params )
   if 50 - 50: IiII % i1IIi
  elif I1II1 == 'WATCH' :
   self . dp_Watch_List ( self . main_params )
   if 21 - 21: OoooooooOO - iIii1I11I1II1
  elif I1II1 == 'MYVIEW_REMOVE' :
   self . dp_WatchList_Delete ( self . main_params )
   if 93 - 93: oO0o - o0oOOo0O0Ooo % OoOoOO00 . OoOoOO00 - ooOoO0o
  elif I1II1 == 'SEARCH' :
   self . dp_Search_Group ( self . main_params )
   if 90 - 90: ooOoO0o + II111iiii * I1ii11iIi11i / Ii1I . o0oOOo0O0Ooo + o0oOOo0O0Ooo
  elif I1II1 == 'SEARCH_LIST' :
   self . dp_Search_List ( self . main_params )
   if 40 - 40: ooOoO0o / OoOoOO00 % i11iIiiIii % I1ii11iIi11i / I1IiiI
  elif I1II1 == 'ORDER_BY' :
   self . dp_setEpOrderby ( self . main_params )
   if 62 - 62: i1IIi - OoOoOO00
  elif I1II1 == 'LOGOUT' :
   self . logout ( )
   if 62 - 62: i1IIi + Oo0Ooo % IiII
   if 28 - 28: I1ii11iIi11i . i1IIi
   if 10 - 10: OoO0O00 / Oo0Ooo
   if 15 - 15: iII111i . OoOoOO00 / iII111i * I11i - I1IiiI % I1ii11iIi11i
   if 57 - 57: O0 % OoOoOO00 % oO0o
   if 45 - 45: I1ii11iIi11i + II111iiii * i11iIiiIii
  else :
   None
   if 13 - 13: OoooooooOO * oO0o - Ii1I / OOooOOo + I11i + IiII
   if 39 - 39: iIii1I11I1II1 - OoooooooOO
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
