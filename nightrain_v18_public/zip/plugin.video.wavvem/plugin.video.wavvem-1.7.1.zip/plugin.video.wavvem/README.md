# wavveM-v18
웨이브 애드온 for Kodi18


###
# 1.6.1 이후 부터는 저장소를 통해서만 업데이트 됩니다.
* [Korea OTT Package for Kodi 18 (public)-18.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v18_public.zip)
* [Korea OTT Package for Kodi 19 (public)-19.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v19_public.zip)
###


# 공통
- 

# 변경사항

## Version 1.7.1 (2020.11.07)
- 홈메뉴 추가

## Version 1.7.0 (2020.11.01)
- 사이트 변경 적용

## Version 1.6.2 (2020.09.09)
- timezone

## Version 1.6.1 (2020.09.08)
- 특정스킨 오류 수정

## Version 1.6.0 (2020.08.31)
- 로그인 처리변경 (세션정보 파일처리)

## Version 1.5.1 (2020.06.14)
- vod 최근시청내역 바로보기 옵션 추가

## Version 1.5.0 (2020.04.13)
- 애드온 버전 통일
- 내부폴더명 변경 (이전버전 애드온은 삭제후 설치하세요)
- info 정보 추가
- 영화 info 추가정보 조회 옵션 추가 (속도문제로 비권장)

## Version 1.2.0 (2020.04.08)
- 성능개선을 위한 일부구조 변경

## Version 1.1.1 (2020.03.18)
- 일부 카테고리 조회 및 재생 오류 수정

## Version 1.1.0 (2020.03.15)
- VOD 및 영화 최신순, 인기순 카테고리 추가

## Version 1.0.6 (2020.02.04)
- 특정 실행환경 오류 수정

## Version 1.0.5 (2020.02.02)
- 특정 실행환경 오류 수정

## Version 1.0.4 (2020.01.30)
- 영화 장르별 조회 wavvie 영화로 제한
- 영화 카테고리 연령제한 옵션 미적용 오류 수정(영화)
- 메인메뉴 명칭 일부조정

## Version 1.0.3 (2020.01.27)
- 즐겨찾기, 커스텀메뉴 사용자를 위한 로그인 방식 개선

## Version 1.0.2 (2020.01.10)
- 실시간 채널 방송시간 정보 추가
- 에피소드 및 영상 페이지당 조회건수 조정

## Version 1.0.1 (2019.12.31)
- 일부 오류 수정
- 에피소드 회차순서 변경기능 추가(최신순->1회부터)

## Version 1.0.0 (2019.12.19)
- 실시간채널, VOD 지원(방송, 해외드라마)
- 영화 재생 지원(일부영화의 경우 재생이 안될수 있음)


