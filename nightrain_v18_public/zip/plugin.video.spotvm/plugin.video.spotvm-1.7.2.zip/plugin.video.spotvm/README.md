# spotvM-v19
 스포티비 나우 애드온 for Kodi18

###
# 현재는 저장소를 통해서만 업데이트 됩니다.
* [Korea OTT Package for Kodi 18 (public)-18.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v18_public.zip)
* [Korea OTT Package for Kodi 19 (public)-19.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v19_public.zip)
###


# 공통
- kodi18용

## Version 1.7.2 (2020.11.02)
- 권한체크 오류수정

## Version 1.7.0 (2020.11.01)
- check channnel

## Version 1.6.0 (2020.10.21)
- kodi 18 최초 생성
