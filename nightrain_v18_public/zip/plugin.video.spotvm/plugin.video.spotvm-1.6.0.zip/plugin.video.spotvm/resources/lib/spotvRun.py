# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import os
import xbmcplugin , xbmcgui , xbmcaddon , xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import urlparse
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
if 73 - 73: II111iiii
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
__addon__ = xbmcaddon . Addon ( )
__language__ = __addon__ . getLocalizedString
__profile__ = xbmc . translatePath ( __addon__ . getAddonInfo ( 'profile' ) )
__version__ = __addon__ . getAddonInfo ( 'version' )
__addonid__ = __addon__ . getAddonInfo ( 'id' )
__addonname__ = __addon__ . getAddonInfo ( 'name' )
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
if 46 - 46: ooOoO0o * I11i - OoooooooOO
II1iII1i = [
 { 'title' : 'TV 채널' , 'mode' : 'LIVE_GROUP' }
 , { 'title' : 'Live중계 (독점,현지)' , 'mode' : 'ELIVE_GROUP' }
 , { 'title' : '-----------------' , 'mode' : 'XXX' }
 , { 'title' : '인기영상5' , 'mode' : 'POP_GROUP' }
 , { 'title' : 'VOD 영상' , 'mode' : 'VOD_GROUP' }
 , { 'title' : '-----------------' , 'mode' : 'XXX' }
 , { 'title' : 'Watched (시청목록)' , 'mode' : 'WATCH' }
 ]
if 97 - 97: OoooooooOO
if 60 - 60: iIii1I11I1II1 / i1IIi * oO0o - I1ii11iIi11i + o0oOOo0O0Ooo
if 94 - 94: i1IIi % Oo0Ooo
o0oO0 = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
oo00 = xbmc . translatePath ( os . path . join ( __profile__ , 'spotv_cookies.json' ) )
if 88 - 88: iII111i . oO0o % ooOoO0o
from spotvCore import *
if 66 - 66: iII111i
if 30 - 30: iIii1I11I1II1 * iIii1I11I1II1 . II111iiii - oO0o
class ooO00oOoo ( object ) :
 def __init__ ( self , in_addonurl , in_handle , in_params ) :
  self . _addon_url = in_addonurl
  self . _addon_handle = in_handle
  self . main_params = in_params
  self . SpotvObj = ooO00oOooo ( )
  if 78 - 78: I11i / OoO0O00 - O0 . IiII
  if 91 - 91: I1ii11iIi11i * iIii1I11I1II1 . IiII / Ii1I
  if 87 - 87: i1IIi / Ii1I . OoO0O00 * OoooooooOO - IiII * ooOoO0o
 def addon_noti ( self , sting ) :
  try :
   O0I11i1i11i1I = xbmcgui . Dialog ( )
   O0I11i1i11i1I . notification ( __addonname__ , sting )
  except :
   None
   if 31 - 31: i11iIiiIii / I1IiiI / ooOoO0o * oO0o / Oo0Ooo
   if 99 - 99: iIii1I11I1II1 * OoooooooOO * II111iiii * iIii1I11I1II1
   if 44 - 44: oO0o / Oo0Ooo - II111iiii - i11iIiiIii % I1Ii111
 def addon_log ( self , string ) :
  try :
   O0OoOoo00o = string . encode ( 'utf-8' , 'ignore' )
  except :
   O0OoOoo00o = 'addonException: addon_log'
   if 31 - 31: II111iiii + OoO0O00 . I1Ii111
   if 68 - 68: I1IiiI - i11iIiiIii - OoO0O00 / OOooOOo - OoO0O00 + i1IIi
  IiiIII111ii = xbmc . LOGINFO
  xbmc . log ( "[%s-%s]: %s" % ( __addonid__ , __version__ , O0OoOoo00o ) , level = IiiIII111ii )
  if 3 - 3: iII111i + O0
  if 42 - 42: OOooOOo / i1IIi + i11iIiiIii - Ii1I
  if 78 - 78: OoO0O00
  if 18 - 18: O0 - iII111i / iII111i + ooOoO0o % ooOoO0o - IiII
 def get_keyboard_input ( self , title ) :
  O0O00Ooo = None
  OOoooooO = xbmc . Keyboard ( )
  OOoooooO . setHeading ( title )
  xbmc . sleep ( 1000 )
  OOoooooO . doModal ( )
  if ( OOoooooO . isConfirmed ( ) ) :
   O0O00Ooo = OOoooooO . getText ( )
  return O0O00Ooo
  if 14 - 14: I11i % O0
  if 41 - 41: i1IIi + I1Ii111 + OOooOOo - IiII
  if 77 - 77: Oo0Ooo . IiII % ooOoO0o
  if 42 - 42: oO0o - i1IIi / i11iIiiIii + OOooOOo + OoO0O00
 def get_settings_login_info ( self ) :
  iIi = __addon__ . getSetting ( 'id' )
  II = __addon__ . getSetting ( 'pw' )
  return ( iIi , II )
  if 14 - 14: Oo0Ooo . I1IiiI / Ii1I
  if 38 - 38: II111iiii % i11iIiiIii . ooOoO0o - OOooOOo + Ii1I
  if 66 - 66: OoooooooOO * OoooooooOO . OOooOOo . i1IIi - OOooOOo
  if 77 - 77: I11i - iIii1I11I1II1
 def set_winCredential ( self , credential ) :
  Ooo = xbmcgui . Window ( 10000 )
  Ooo . setProperty ( 'SPOTV_M_SESSIONID' , credential . get ( 'spotv_sessionid' ) )
  Ooo . setProperty ( 'SPOTV_M_SESSION' , credential . get ( 'spotv_session' ) )
  Ooo . setProperty ( 'SPOTV_M_ACCOUNTID' , credential . get ( 'spotv_accountId' ) )
  Ooo . setProperty ( 'SPOTV_M_POLICYKEY' , credential . get ( 'spotv_policyKey' ) )
  Ooo . setProperty ( 'SPOTV_M_SUBEND' , credential . get ( 'spotv_subend' ) )
  Ooo . setProperty ( 'SPOTV_M_LOGINTIME' , self . SpotvObj . Get_Now_Datetime ( ) . strftime ( '%Y-%m-%d' ) )
  if 68 - 68: I11i + OOooOOo . iIii1I11I1II1 - IiII % iIii1I11I1II1 - ooOoO0o
  if 79 - 79: Oo0Ooo + I1IiiI - iII111i
 def get_winCredential ( self ) :
  Ooo = xbmcgui . Window ( 10000 )
  oO00O00o0OOO0 = {
 'spotv_sessionid' : Ooo . getProperty ( 'SPOTV_M_SESSIONID' )
 , 'spotv_session' : Ooo . getProperty ( 'SPOTV_M_SESSION' )
 , 'spotv_accountId' : Ooo . getProperty ( 'SPOTV_M_ACCOUNTID' )
 , 'spotv_policyKey' : Ooo . getProperty ( 'SPOTV_M_POLICYKEY' )
 , 'spotv_subend' : Ooo . getProperty ( 'SPOTV_M_SUBEND' )
 }
  return oO00O00o0OOO0
  if 27 - 27: O0 % i1IIi * oO0o + i11iIiiIii + OoooooooOO * i1IIi
  if 80 - 80: I11i * i11iIiiIii / I1Ii111
  if 9 - 9: Ii1I + oO0o % Ii1I + i1IIi . OOooOOo
  if 31 - 31: o0oOOo0O0Ooo + I11i + I11i / II111iiii
 def add_dir ( self , label , sublabel = '' , img = '' , infoLabels = None , isFolder = True , params = '' ) :
  iiI1 = '%s?%s' % ( self . _addon_url , urllib . urlencode ( params ) )
  if 19 - 19: I11i + ooOoO0o
  if sublabel : ooo = '%s < %s >' % ( label , sublabel )
  else : ooo = label
  if not img : img = 'DefaultFolder.png'
  if 18 - 18: o0oOOo0O0Ooo
  I1i1I1II = xbmcgui . ListItem ( ooo )
  I1i1I1II . setArt ( { 'thumbnailImage' : img , 'icon' : img , 'poster' : img } )
  if 45 - 45: I1Ii111 . OoOoOO00
  if infoLabels : I1i1I1II . setInfo ( type = "Video" , infoLabels = infoLabels )
  if not isFolder : I1i1I1II . setProperty ( 'IsPlayable' , 'true' )
  if 83 - 83: oO0o . iIii1I11I1II1 . I1ii11iIi11i
  xbmcplugin . addDirectoryItem ( self . _addon_handle , iiI1 , I1i1I1II , isFolder )
  if 31 - 31: Ii1I . Ii1I - o0oOOo0O0Ooo / OoO0O00 + ooOoO0o * I1IiiI
  if 63 - 63: I1Ii111 % i1IIi / OoooooooOO - OoooooooOO
  if 8 - 8: OoOoOO00
  if 60 - 60: I11i / I11i
 def get_selQuality ( self , etype ) :
  try :
   I1II1III11iii = 'selected_quality'
   if 75 - 75: iIii1I11I1II1 / OOooOOo % o0oOOo0O0Ooo * OoOoOO00
   iiii11I = [ 1080 , 720 , 540 ]
   if 96 - 96: II111iiii % Ii1I . OOooOOo + OoooooooOO * oO0o - OoOoOO00
   i11i1 = int ( __addon__ . getSetting ( I1II1III11iii ) )
   return iiii11I [ i11i1 ]
  except :
   None
   if 29 - 29: I1ii11iIi11i % I1IiiI + ooOoO0o / o0oOOo0O0Ooo + OOooOOo * o0oOOo0O0Ooo
  return 1080
  if 42 - 42: Ii1I + oO0o
  if 76 - 76: I1Ii111 - OoO0O00
  if 70 - 70: ooOoO0o
  if 61 - 61: I1ii11iIi11i . I1ii11iIi11i
 def dp_Main_List ( self ) :
  if 10 - 10: OoOoOO00 * iII111i . I11i + II111iiii - ooOoO0o * i1IIi
  for oO00o0O0O0ooO in II1iII1i :
   ooo = oO00o0O0O0ooO . get ( 'title' )
   if 100 - 100: o0oOOo0O0Ooo . I1ii11iIi11i + o0oOOo0O0Ooo
   i1Ii = { 'mode' : oO00o0O0O0ooO . get ( 'mode' )

   # I11i . iII111i % OOooOOo + ooOoO0o % OoOoOO00
   }
   if 4 - 4: IiII - OoO0O00 * OoOoOO00 - I11i
   if oO00o0O0O0ooO . get ( 'mode' ) == 'XXX' :
    if 41 - 41: OoOoOO00 . I1IiiI * oO0o % IiII
    Oo000o = False
   else :
    Oo000o = True
    if 7 - 7: ooOoO0o * OoO0O00 % oO0o . IiII
   self . add_dir ( ooo , sublabel = '' , img = '' , infoLabels = None , isFolder = Oo000o , params = i1Ii )
   if 45 - 45: i11iIiiIii * II111iiii % iIii1I11I1II1 + I1ii11iIi11i - Ii1I
   if 17 - 17: IiII
   if 62 - 62: iIii1I11I1II1 * OoOoOO00
   if 26 - 26: iII111i . I1Ii111
  if len ( II1iII1i ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle )
  if 68 - 68: OoO0O00
  if 35 - 35: OoO0O00 - iII111i / Oo0Ooo / OoOoOO00
  if 24 - 24: ooOoO0o - ooOoO0o / II111iiii - I1ii11iIi11i
  if 69 - 69: oO0o . I1Ii111 + Ii1I / Oo0Ooo - oO0o
 def dp_MainLeague_List ( self , args ) :
  if 63 - 63: OOooOOo % oO0o * oO0o * OoO0O00 / I1ii11iIi11i
  if 74 - 74: II111iiii
  self . SpotvObj . SaveCredential ( self . get_winCredential ( ) )
  if 75 - 75: o0oOOo0O0Ooo . ooOoO0o
  Oo0O00Oo0o0 = self . SpotvObj . GetTitleGroupList ( )
  if 87 - 87: ooOoO0o * Oo0Ooo % i11iIiiIii % OoOoOO00 - OOooOOo
  for O0ooo0O0oo0 in Oo0O00Oo0o0 :
   ooo = O0ooo0O0oo0 . get ( 'title' )
   oo0oOo = O0ooo0O0oo0 . get ( 'logo' )
   o000O0o = O0ooo0O0oo0 . get ( 'reagueId' )
   iI1iII1 = O0ooo0O0oo0 . get ( 'subGame' )
   if 86 - 86: OOooOOo
   OOoo0O = O0ooo0O0oo0 . get ( 'info' )
   OOoo0O [ 'plot' ] = '%s\n\n%s' % ( ooo , iI1iII1 )
   if 67 - 67: i11iIiiIii - i1IIi % I1ii11iIi11i . O0
   i1Ii = { 'mode' : 'LEAGUE_GROUP'
 , 'reagueId' : o000O0o
 }
   if 77 - 77: IiII / I1IiiI
   self . add_dir ( ooo , sublabel = None , img = oo0oOo , infoLabels = OOoo0O , isFolder = True , params = i1Ii )
   if 15 - 15: IiII . iIii1I11I1II1 . OoooooooOO / i11iIiiIii - Ii1I . i1IIi
   if 33 - 33: I11i . o0oOOo0O0Ooo
  if len ( Oo0O00Oo0o0 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 75 - 75: o0oOOo0O0Ooo % o0oOOo0O0Ooo . I1Ii111
  if 5 - 5: o0oOOo0O0Ooo * ooOoO0o + OoOoOO00 . OOooOOo + OoOoOO00
  if 91 - 91: O0
  if 61 - 61: II111iiii
  if 64 - 64: ooOoO0o / OoOoOO00 - O0 - I11i
 def dp_PopVod_GroupList ( self , args ) :
  if 86 - 86: I11i % OoOoOO00 / I1IiiI / OoOoOO00
  self . SpotvObj . SaveCredential ( self . get_winCredential ( ) )
  if 42 - 42: OoO0O00
  Oo0O00Oo0o0 = self . SpotvObj . GetPopularGroupList ( )
  if 67 - 67: I1Ii111 . iII111i . O0
  for O0ooo0O0oo0 in Oo0O00Oo0o0 :
   if 10 - 10: I1ii11iIi11i % I1ii11iIi11i - iIii1I11I1II1 / OOooOOo + Ii1I
   OOOOoOoo0O0O0 = O0ooo0O0oo0 . get ( 'vodTitle' )
   OOOo00oo0oO = O0ooo0O0oo0 . get ( 'vodId' )
   IIiIi1iI = O0ooo0O0oo0 . get ( 'vodType' )
   oo0oOo = O0ooo0O0oo0 . get ( 'thumbnail' )
   i1IiiiI1iI = O0ooo0O0oo0 . get ( 'vtypeId' )
   if 49 - 49: Ii1I / OoO0O00 . II111iiii
   OOoo0O = O0ooo0O0oo0 . get ( 'info' )
   if 68 - 68: i11iIiiIii % I1ii11iIi11i + i11iIiiIii
   OOoo0O [ 'plot' ] = OOOOoOoo0O0O0
   if 31 - 31: II111iiii . I1IiiI
   if 1 - 1: Oo0Ooo / o0oOOo0O0Ooo % iII111i * IiII . i11iIiiIii
   i1Ii = { 'mode' : 'POP_VOD'

   # I1Ii111
   # I1ii11iIi11i - OoO0O00 % i11iIiiIii . iII111i / iII111i - I1Ii111
   # iII111i
   , 'mediacode' : OOOo00oo0oO
 , 'mediatype' : 'vod'
 , 'vtypeId' : i1IiiiI1iI
   }
   if 25 - 25: Oo0Ooo - I1IiiI / OoooooooOO / o0oOOo0O0Ooo
   self . add_dir ( OOOOoOoo0O0O0 , sublabel = IIiIi1iI , img = oo0oOo , infoLabels = OOoo0O , isFolder = False , params = i1Ii )
   if 12 - 12: I1IiiI * iII111i % i1IIi % iIii1I11I1II1
  if len ( Oo0O00Oo0o0 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 20 - 20: OOooOOo % Ii1I / Ii1I + Ii1I
  if 45 - 45: oO0o - IiII - OoooooooOO - OoO0O00 . II111iiii / O0
  if 51 - 51: O0 + iII111i
  if 8 - 8: oO0o * OoOoOO00 - Ii1I - OoO0O00 * OOooOOo % I1IiiI
  if 48 - 48: O0
  if 11 - 11: I11i + OoooooooOO - OoO0O00 / o0oOOo0O0Ooo + Oo0Ooo . II111iiii
 def dp_Season_List ( self , args ) :
  if 41 - 41: Ii1I - O0 - O0
  self . SpotvObj . SaveCredential ( self . get_winCredential ( ) )
  if 68 - 68: OOooOOo % I1Ii111
  o000O0o = args . get ( 'reagueId' )
  Oo0O00Oo0o0 = self . SpotvObj . GetSeasonList ( o000O0o )
  if 88 - 88: iIii1I11I1II1 - ooOoO0o + OOooOOo
  for O0ooo0O0oo0 in Oo0O00Oo0o0 :
   IiI111111IIII = O0ooo0O0oo0 . get ( 'reagueName' )
   i1Iiii111iI1iIi1 = O0ooo0O0oo0 . get ( 'gameTypeId' )
   OOO = O0ooo0O0oo0 . get ( 'seasonName' )
   oo0OOo0 = O0ooo0O0oo0 . get ( 'seasonId' )
   if 47 - 47: I1Ii111 + OoOoOO00 * Oo0Ooo / ooOoO0o - iII111i % iIii1I11I1II1
   OOoo0O = O0ooo0O0oo0 . get ( 'info' )
   OOoo0O [ 'plot' ] = '%s - %s' % ( IiI111111IIII , OOO )
   if 26 - 26: I1ii11iIi11i * iII111i . II111iiii * Ii1I
   i1Ii = { 'mode' : 'SEASON_GROUP'
 , 'reagueId' : o000O0o
 , 'seasonId' : oo0OOo0
 , 'gameTypeId' : i1Iiii111iI1iIi1
 , 'page' : '1'
 }
   if 28 - 28: OoO0O00 . i1IIi * I1IiiI + O0 . i1IIi - ooOoO0o
   self . add_dir ( IiI111111IIII , sublabel = OOO , img = '' , infoLabels = OOoo0O , isFolder = True , params = i1Ii )
   if 38 - 38: I1Ii111
  if len ( Oo0O00Oo0o0 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 84 - 84: iIii1I11I1II1 % iII111i / iIii1I11I1II1 % I11i
  if 45 - 45: O0
  if 26 - 26: I11i - iIii1I11I1II1 - I1IiiI / OoO0O00 . OoOoOO00 % iIii1I11I1II1
  if 91 - 91: o0oOOo0O0Ooo . iIii1I11I1II1 / oO0o + i1IIi
  if 42 - 42: ooOoO0o . o0oOOo0O0Ooo . ooOoO0o - I1ii11iIi11i
 def dp_Game_List ( self , args ) :
  if 40 - 40: ooOoO0o - i11iIiiIii / Ii1I
  self . SpotvObj . SaveCredential ( self . get_winCredential ( ) )
  if 35 - 35: Ii1I - I1IiiI % o0oOOo0O0Ooo . OoooooooOO % Ii1I
  i1Iiii111iI1iIi1 = args . get ( 'gameTypeId' )
  o000O0o = args . get ( 'reagueId' )
  oo0OOo0 = args . get ( 'seasonId' )
  I1i1Iiiii = int ( args . get ( 'page' ) )
  if 94 - 94: o0oOOo0O0Ooo * Ii1I / Oo0Ooo / Ii1I
  Oo0O00Oo0o0 , oO0 = self . SpotvObj . GetGameList ( i1Iiii111iI1iIi1 , o000O0o , oo0OOo0 , I1i1Iiiii )
  if 75 - 75: ooOoO0o + OoOoOO00 + o0oOOo0O0Ooo * I11i % oO0o . iII111i
  for O0ooo0O0oo0 in Oo0O00Oo0o0 :
   if 55 - 55: OOooOOo . I1IiiI
   oOo0O0o00o = O0ooo0O0oo0 . get ( 'gameTitle' )
   o00oO0oo0OO = O0ooo0O0oo0 . get ( 'beginDate' )
   oo0oOo = O0ooo0O0oo0 . get ( 'thumbnail' )
   O0O0OOOOoo = O0ooo0O0oo0 . get ( 'gameId' )
   oOooO0 = O0ooo0O0oo0 . get ( 'totVodCnt' )
   if 29 - 29: iIii1I11I1II1 + OoOoOO00 * OoO0O00 * OOooOOo . I1IiiI * I1IiiI
   if 7 - 7: IiII * I1Ii111 % Ii1I - o0oOOo0O0Ooo
   i1i = O0ooo0O0oo0 . get ( 'leaguenm' )
   oOOoo00O00o = O0ooo0O0oo0 . get ( 'seasonnm' )
   O0O00Oo = O0ooo0O0oo0 . get ( 'roundnm' )
   if 97 - 97: O0 * OoooooooOO . OoooooooOO
   if 33 - 33: I1Ii111 + iII111i * oO0o / iIii1I11I1II1 - I1IiiI
   O0oO = '%s < %s >' % ( oOo0O0o00o , o00oO0oo0OO )
   if 73 - 73: I1ii11iIi11i * i11iIiiIii % oO0o . I1ii11iIi11i
   if 66 - 66: oO0o + oO0o + ooOoO0o / iII111i + OOooOOo
   OOoo0O = O0ooo0O0oo0 . get ( 'info' )
   if 30 - 30: O0
   if 44 - 44: oO0o / I11i / I11i
   if 87 - 87: Oo0Ooo . I1IiiI - II111iiii + O0 / Oo0Ooo / oO0o
   i1Ii = { 'mode' : 'GAME_VOD_GROUP' if oOooO0 != 0 else 'XXX'
 , 'saveTitle' : O0oO
   , 'saveImg' : oo0oOo
   , 'saveInfo' : OOoo0O [ 'plot' ]
 , 'gameid' : O0O0OOOOoo
 }
   if 25 - 25: I1IiiI . I1IiiI - OoOoOO00 % OoOoOO00 - i11iIiiIii / I1Ii111
   self . add_dir ( oOo0O0o00o , sublabel = o00oO0oo0OO , img = oo0oOo , infoLabels = OOoo0O , isFolder = True , params = i1Ii )
   if 51 - 51: Oo0Ooo / OoOoOO00 . OOooOOo * o0oOOo0O0Ooo + OoO0O00 * IiII
  if oO0 :
   if 73 - 73: OoO0O00 + OoooooooOO - O0 - Ii1I - II111iiii
   i1Ii [ 'mode' ] = 'SEASON_GROUP'
   i1Ii [ 'reagueId' ] = o000O0o
   i1Ii [ 'seasonId' ] = oo0OOo0
   i1Ii [ 'gameTypeId' ] = i1Iiii111iI1iIi1
   i1Ii [ 'page' ] = str ( I1i1Iiiii + 1 )
   ooo = '[B]%s >>[/B]' % '다음 페이지'
   O0O = str ( I1i1Iiiii + 1 )
   self . add_dir ( ooo , sublabel = O0O , img = '' , infoLabels = None , isFolder = True , params = i1Ii )
   if 80 - 80: Ii1I * o0oOOo0O0Ooo / o0oOOo0O0Ooo
  if len ( Oo0O00Oo0o0 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 5 - 5: I1IiiI
  if 48 - 48: o0oOOo0O0Ooo - oO0o / OoooooooOO
  if 100 - 100: I1IiiI / o0oOOo0O0Ooo % II111iiii % Oo0Ooo % OOooOOo
  if 98 - 98: I11i % i11iIiiIii % ooOoO0o + Ii1I
  if 78 - 78: I1ii11iIi11i % oO0o / iII111i - iIii1I11I1II1
 def dp_GameVod_List ( self , args ) :
  if 69 - 69: I1Ii111
  self . SpotvObj . SaveCredential ( self . get_winCredential ( ) )
  if 11 - 11: I1IiiI
  I1111i = args . get ( 'gameid' )
  O0oO = args . get ( 'saveTitle' )
  iIIii = args . get ( 'saveImg' )
  o00O0O = args . get ( 'saveInfo' )
  if 20 - 20: i1IIi - ooOoO0o
  Oo0O00Oo0o0 = self . SpotvObj . GetGameVodList ( I1111i )
  if 30 - 30: I11i / I1IiiI
  for O0ooo0O0oo0 in Oo0O00Oo0o0 :
   if 35 - 35: II111iiii % OOooOOo . ooOoO0o + ooOoO0o % II111iiii % II111iiii
   OOOOoOoo0O0O0 = O0ooo0O0oo0 . get ( 'vodTitle' )
   OOOo00oo0oO = O0ooo0O0oo0 . get ( 'vodId' )
   IIiIi1iI = O0ooo0O0oo0 . get ( 'vodType' )
   oo0oOo = O0ooo0O0oo0 . get ( 'thumbnail' )
   i1IiiiI1iI = O0ooo0O0oo0 . get ( 'vtypeId' )
   if 72 - 72: II111iiii + i1IIi + o0oOOo0O0Ooo
   OOoo0O = O0ooo0O0oo0 . get ( 'info' )
   OOoo0O [ 'plot' ] = '%s \n\n %s' % ( OOOOoOoo0O0O0 , o00O0O )
   if 94 - 94: oO0o . i1IIi - o0oOOo0O0Ooo % O0 - OoO0O00
   if 72 - 72: Ii1I
   i1Ii = { 'mode' : 'GAME_VOD'
 , 'saveTitle' : O0oO
   , 'saveImg' : iIIii
   , 'saveId' : I1111i
   , 'saveInfo' : o00O0O
   , 'mediacode' : OOOo00oo0oO
 , 'mediatype' : 'vod'
 , 'vtypeId' : i1IiiiI1iI
   }
   if 1 - 1: OoO0O00 * IiII * OoooooooOO + ooOoO0o
   self . add_dir ( OOOOoOoo0O0O0 , sublabel = IIiIi1iI , img = oo0oOo , infoLabels = OOoo0O , isFolder = False , params = i1Ii )
   if 33 - 33: O0 * o0oOOo0O0Ooo - I1Ii111 % I1Ii111
  if len ( Oo0O00Oo0o0 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 18 - 18: I1Ii111 / Oo0Ooo * I1Ii111 + I1Ii111 * i11iIiiIii * I1ii11iIi11i
  if 11 - 11: ooOoO0o / OoOoOO00 - IiII * OoooooooOO + OoooooooOO . OoOoOO00
  if 26 - 26: Ii1I % I1ii11iIi11i
  if 76 - 76: IiII * iII111i
  if 52 - 52: OOooOOo
  if 19 - 19: I1IiiI
 def login_main ( self ) :
  ( i11i , o0oooOO00 ) = self . get_settings_login_info ( )
  if 32 - 32: I1Ii111
  if 30 - 30: iIii1I11I1II1 / I11i . OoO0O00 - o0oOOo0O0Ooo
  if not ( i11i and o0oooOO00 ) :
   O0I11i1i11i1I = xbmcgui . Dialog ( )
   Iii11iI1i = O0I11i1i11i1I . yesno ( __language__ ( 30901 ) . encode ( 'utf8' ) , __language__ ( 30902 ) . encode ( 'utf8' ) )
   if Iii11iI1i == True :
    __addon__ . openSettings ( )
    sys . exit ( )
   else :
    sys . exit ( )
    if 57 - 57: o0oOOo0O0Ooo
    if 51 - 51: I1IiiI . iIii1I11I1II1 - I1ii11iIi11i / O0
    if 52 - 52: o0oOOo0O0Ooo + O0 + iII111i + Oo0Ooo % iII111i
  if self . cookiefile_check ( ) : return
  if 75 - 75: I1IiiI . ooOoO0o . O0 * I1Ii111
  if 4 - 4: Ii1I % oO0o * OoO0O00
  o0O0OOOOoOO0 = int ( self . SpotvObj . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' ) )
  ii = xbmcgui . Window ( 10000 ) . getProperty ( 'SPOTV_M_LOGINTIME' )
  if ii == None or ii == '' :
   ii = int ( '19000101' )
  else :
   ii = int ( re . sub ( '-' , '' , ii ) )
   if 68 - 68: iII111i - I1IiiI / I1Ii111 / I11i
   if 12 - 12: Ii1I + i11iIiiIii * iIii1I11I1II1 / I1ii11iIi11i . I11i
   if 5 - 5: i1IIi + IiII / o0oOOo0O0Ooo . iII111i / I11i
  if xbmcgui . Window ( 10000 ) . getProperty ( 'SPOTV_M_LOGINWAIT' ) == 'TRUE' :
   IiiiIiii11 = 0
   while True :
    IiiiIiii11 += 1
    time . sleep ( 0.05 )
    if 92 - 92: OoOoOO00 + I1Ii111 * Ii1I % I1IiiI
    if ii >= o0O0OOOOoOO0 : return
    if IiiiIiii11 > 600 : return
  else :
   xbmcgui . Window ( 10000 ) . setProperty ( 'SPOTV_M_LOGINWAIT' , 'TRUE' )
   if 42 - 42: Oo0Ooo
  if ii >= o0O0OOOOoOO0 :
   xbmcgui . Window ( 10000 ) . setProperty ( 'SPOTV_M_LOGINWAIT' , 'FALSE' )
   return
   if 76 - 76: I1IiiI * iII111i % I1Ii111
   if 57 - 57: iIii1I11I1II1 - i1IIi / I1Ii111 - O0 * OoooooooOO % II111iiii
  if not self . SpotvObj . GetCredential ( i11i , o0oooOO00 ) :
   self . addon_noti ( __language__ ( 30903 ) . encode ( 'utf8' ) )
   xbmcgui . Window ( 10000 ) . setProperty ( 'SPOTV_M_LOGINWAIT' , 'FALSE' )
   sys . exit ( )
   if 68 - 68: OoooooooOO * I11i % OoOoOO00 - IiII
   if 34 - 34: I1Ii111 . iIii1I11I1II1 * OoOoOO00 * oO0o / I1Ii111 / I1ii11iIi11i
  self . set_winCredential ( self . SpotvObj . LoadCredential ( ) )
  self . cookiefile_save ( )
  xbmcgui . Window ( 10000 ) . setProperty ( 'SPOTV_M_LOGINWAIT' , 'FALSE' )
  if 78 - 78: Oo0Ooo - o0oOOo0O0Ooo / OoOoOO00
  if 10 - 10: iII111i + Oo0Ooo * I1ii11iIi11i + iIii1I11I1II1 / I1Ii111 / I1ii11iIi11i
  if 42 - 42: I1IiiI
  if 38 - 38: OOooOOo + II111iiii % ooOoO0o % OoOoOO00 - Ii1I / OoooooooOO
  if 73 - 73: o0oOOo0O0Ooo * O0 - i11iIiiIii
  if 85 - 85: Ii1I % iII111i + I11i / o0oOOo0O0Ooo . oO0o + OOooOOo
 def dp_LiveChannel_List ( self , args ) :
  if 62 - 62: i11iIiiIii + i11iIiiIii - o0oOOo0O0Ooo
  self . SpotvObj . SaveCredential ( self . get_winCredential ( ) )
  if 28 - 28: iII111i . iII111i % iIii1I11I1II1 * iIii1I11I1II1 . o0oOOo0O0Ooo / iII111i
  iII1i1 = self . SpotvObj . GetLiveChannelList ( )
  if 85 - 85: Ii1I * Oo0Ooo . O0 - i11iIiiIii
  for i1I1iIi in iII1i1 :
   ooo = i1I1iIi . get ( 'name' )
   IIii11Ii1i1I = i1I1iIi . get ( 'programName' )
   oo0oOo = i1I1iIi . get ( 'logo' )
   Oooo0O = i1I1iIi . get ( 'channelepg' )
   oo00O0oO0O0 = i1I1iIi . get ( 'free' )
   if 96 - 96: i11iIiiIii % ooOoO0o / OoOoOO00
   OOoo0O = i1I1iIi . get ( 'info' )
   if 36 - 36: OOooOOo + O0 - Ii1I - O0 % I11i . oO0o
   OOoo0O [ 'plot' ] = '%s' % ( Oooo0O )
   if 74 - 74: i11iIiiIii . I1IiiI
   i1Ii = { 'mode' : 'LIVE'
 , 'mediaid' : i1I1iIi . get ( 'id' )
 , 'mediacode' : i1I1iIi . get ( 'videoId' )
   , 'free' : oo00O0oO0O0
 , 'mediatype' : 'live'
   }
   if 36 - 36: OoooooooOO . OoO0O00
   if oo00O0oO0O0 : ooo += ' [free]'
   self . add_dir ( ooo , sublabel = IIii11Ii1i1I , img = oo0oOo , infoLabels = OOoo0O , isFolder = False , params = i1Ii )
   if 56 - 56: Oo0Ooo . I1ii11iIi11i . I1IiiI
  if len ( iII1i1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
  if 39 - 39: O0 + I1Ii111
  if 91 - 91: OoooooooOO - iIii1I11I1II1 + OoOoOO00 / OoO0O00 . OoOoOO00 + O0
  if 26 - 26: I1ii11iIi11i - OoooooooOO
  if 11 - 11: I1IiiI * oO0o
 def dp_EventLiveChannel_List ( self , args ) :
  if 81 - 81: iII111i + IiII
  self . SpotvObj . SaveCredential ( self . get_winCredential ( ) )
  if 98 - 98: I1IiiI
  iII1i1 , o00o0 = self . SpotvObj . GetEventLiveList ( )
  if 50 - 50: Oo0Ooo / Oo0Ooo % I1ii11iIi11i . I1ii11iIi11i
  if 55 - 55: ooOoO0o - I11i + II111iiii + iII111i % Ii1I
  if o00o0 != 401 and len ( iII1i1 ) == 0 :
   self . addon_noti ( __language__ ( 30907 ) . encode ( 'utf8' ) )
   if 41 - 41: i1IIi - I11i - Ii1I
   if 8 - 8: OoO0O00 + I1Ii111 - o0oOOo0O0Ooo % Oo0Ooo % o0oOOo0O0Ooo * oO0o
  for i1I1iIi in iII1i1 :
   ooo = i1I1iIi . get ( 'title' )
   IIii11Ii1i1I = i1I1iIi . get ( 'startTime' )
   oo0oOo = i1I1iIi . get ( 'logo' )
   oo00O0oO0O0 = i1I1iIi . get ( 'free' )
   if 9 - 9: Oo0Ooo - i11iIiiIii - OOooOOo * Ii1I + ooOoO0o
   OOoo0O = i1I1iIi . get ( 'info' )
   OOoo0O [ 'plot' ] = '%s\n\n%s' % ( ooo , IIii11Ii1i1I )
   if 44 - 44: II111iiii
   i1Ii = { 'mode' : 'ELIVE'
 , 'mediaid' : i1I1iIi . get ( 'liveId' )
 , 'mediacode' : ''
   , 'free' : oo00O0oO0O0
 , 'mediatype' : 'live'
   }
   if 52 - 52: I1ii11iIi11i - Oo0Ooo + I1ii11iIi11i % o0oOOo0O0Ooo
   if oo00O0oO0O0 : ooo += ' [free]'
   self . add_dir ( ooo , sublabel = IIii11Ii1i1I , img = oo0oOo , infoLabels = OOoo0O , isFolder = False , params = i1Ii )
   if 35 - 35: iIii1I11I1II1
   if 42 - 42: I1Ii111 . I1IiiI . i1IIi + OoOoOO00 + OOooOOo + I1IiiI
  if len ( iII1i1 ) > 0 : xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = True )
  if 31 - 31: iII111i . OOooOOo - ooOoO0o . OoooooooOO / OoooooooOO
  return o00o0
  if 56 - 56: OoO0O00 / oO0o / i11iIiiIii + OoooooooOO - Oo0Ooo - I11i
  if 21 - 21: O0 % IiII . I1IiiI / II111iiii + IiII
  if 53 - 53: oO0o - I1IiiI - oO0o * iII111i
  if 71 - 71: O0 - iIii1I11I1II1
 def play_VIDEO ( self , args ) :
  if 12 - 12: OOooOOo / o0oOOo0O0Ooo
  self . SpotvObj . SaveCredential ( self . get_winCredential ( ) )
  if 42 - 42: Oo0Ooo
  if 19 - 19: oO0o % I1ii11iIi11i * iIii1I11I1II1 + I1IiiI
  if args . get ( 'free' ) == 'False' :
   if self . SpotvObj . CheckSubEnd ( ) == False :
    self . addon_noti ( __language__ ( 30908 ) . encode ( 'utf8' ) )
    return
    if 46 - 46: Oo0Ooo
    if 1 - 1: iII111i
  O0O0Ooo = args . get ( 'mode' )
  oOoO0 = args . get ( 'mediacode' )
  Oo0 = args . get ( 'mediatype' )
  i1IiiiI1iI = args . get ( 'vtypeId' )
  if 83 - 83: i11iIiiIii % o0oOOo0O0Ooo % ooOoO0o
  if 11 - 11: II111iiii % OoO0O00 * iII111i + ooOoO0o + Ii1I
  if args . get ( 'mode' ) == 'ELIVE' :
   oOoO0 = self . SpotvObj . GetEventLive_videoId ( args . get ( 'mediaid' ) )
   if 24 - 24: Oo0Ooo - oO0o % iIii1I11I1II1 . i1IIi / O0
   if 36 - 36: I1IiiI - I11i
   if 29 - 29: ooOoO0o * OOooOOo
   if 10 - 10: I1Ii111 % IiII * IiII . I11i / Ii1I % OOooOOo
  if oOoO0 == '' or oOoO0 == None :
   self . addon_noti ( __language__ ( 30907 ) . encode ( 'utf8' ) )
   return
   if 49 - 49: OoO0O00 / oO0o + O0 * o0oOOo0O0Ooo
  I1ii11 = self . SpotvObj . GetBroadURL ( oOoO0 , Oo0 , i1IiiiI1iI )
  if 74 - 74: Oo0Ooo - o0oOOo0O0Ooo . i1IIi
  if I1ii11 == '' :
   self . addon_noti ( __language__ ( 30908 ) . encode ( 'utf8' ) )
   return
   if 43 - 43: iII111i / I1IiiI
  OO0oo0O = I1ii11
  self . addon_log ( OO0oo0O )
  if 13 - 13: i11iIiiIii + i1IIi * iIii1I11I1II1 % OoooooooOO - II111iiii * OOooOOo
  iiIi1iI1iIii = xbmcgui . ListItem ( path = OO0oo0O )
  if 68 - 68: OOooOOo
  if 82 - 82: iIii1I11I1II1 + Oo0Ooo . iIii1I11I1II1 % IiII / Ii1I . Ii1I
  if 14 - 14: o0oOOo0O0Ooo . OOooOOo . I11i + OoooooooOO - OOooOOo + IiII
  if 9 - 9: Ii1I
  if 59 - 59: I1IiiI * II111iiii . O0
  if 56 - 56: Ii1I - iII111i % I1IiiI - o0oOOo0O0Ooo
  if 51 - 51: O0 / ooOoO0o * iIii1I11I1II1 + I1ii11iIi11i + o0oOOo0O0Ooo
  if 98 - 98: iIii1I11I1II1 * I1ii11iIi11i * OOooOOo + ooOoO0o % i11iIiiIii % O0
  if 27 - 27: O0
  if 79 - 79: o0oOOo0O0Ooo - I11i + o0oOOo0O0Ooo . oO0o
  if 28 - 28: i1IIi - iII111i
  if 54 - 54: iII111i - O0 % OOooOOo
  if 73 - 73: O0 . OoOoOO00 + I1IiiI - I11i % I11i . I11i
  if 17 - 17: Ii1I - OoooooooOO % Ii1I . IiII / i11iIiiIii % iII111i
  if 28 - 28: I11i
  if 58 - 58: OoOoOO00
  if 37 - 37: Oo0Ooo - iIii1I11I1II1 / I1ii11iIi11i
  if 73 - 73: i11iIiiIii - IiII
  if 25 - 25: OoooooooOO + IiII * I1ii11iIi11i
  if 92 - 92: I1IiiI + I11i + O0 / o0oOOo0O0Ooo + I1Ii111
  if 18 - 18: ooOoO0o * OoOoOO00 . iII111i / I1ii11iIi11i / i11iIiiIii
  if 21 - 21: oO0o / I1ii11iIi11i + Ii1I + OoooooooOO
  if 91 - 91: i11iIiiIii / i1IIi + iII111i + ooOoO0o * i11iIiiIii
  if 66 - 66: iIii1I11I1II1 % i1IIi - O0 + I11i * I1Ii111 . IiII
  if 52 - 52: ooOoO0o + O0 . iII111i . I1ii11iIi11i . OoO0O00
  if 97 - 97: I1IiiI / iII111i
  if 71 - 71: II111iiii / i1IIi . I1ii11iIi11i % OoooooooOO . OoOoOO00
  if 41 - 41: i1IIi * II111iiii / OoooooooOO . OOooOOo
  xbmcplugin . setResolvedUrl ( self . _addon_handle , True , iiIi1iI1iIii )
  if 83 - 83: iII111i . O0 / Oo0Ooo / OOooOOo - II111iiii
  try :
   if Oo0 == 'vod' and O0O0Ooo != 'POP_VOD' :
    i1Ii = { 'code' : args . get ( 'saveId' )
 , 'img' : args . get ( 'saveImg' )
 , 'title' : args . get ( 'saveTitle' )
 , 'info' : args . get ( 'saveInfo' )
 }
    self . Save_Watched_List ( Oo0 , i1Ii )
  except :
   None
   if 100 - 100: OoO0O00
   if 46 - 46: OoOoOO00 / iIii1I11I1II1 % iII111i . iIii1I11I1II1 * iII111i
   if 38 - 38: I1ii11iIi11i - iII111i / O0 . I1Ii111
   if 45 - 45: I1Ii111
   if 83 - 83: OoOoOO00 . OoooooooOO
 def logout ( self ) :
  O0I11i1i11i1I = xbmcgui . Dialog ( )
  Iii11iI1i = O0I11i1i11i1I . yesno ( __language__ ( 30910 ) . encode ( 'utf8' ) , __language__ ( 30905 ) . encode ( 'utf8' ) )
  if Iii11iI1i == False : sys . exit ( )
  if 58 - 58: i11iIiiIii + OoooooooOO % OoooooooOO / IiII / i11iIiiIii
  self . wininfo_clear ( )
  if 62 - 62: OoO0O00 / I1ii11iIi11i
  if 7 - 7: OoooooooOO . IiII
  if os . path . isfile ( oo00 ) : os . remove ( oo00 )
  if 53 - 53: Ii1I % Ii1I * o0oOOo0O0Ooo + OoOoOO00
  self . addon_noti ( __language__ ( 30909 ) . encode ( 'utf-8' ) )
  if 92 - 92: OoooooooOO + i1IIi / Ii1I * O0
  if 100 - 100: ooOoO0o % iIii1I11I1II1 * II111iiii - iII111i
  if 92 - 92: ooOoO0o
  if 22 - 22: Oo0Ooo % iII111i * I1ii11iIi11i / OOooOOo % i11iIiiIii * I11i
 def wininfo_clear ( self ) :
  if 95 - 95: OoooooooOO - IiII * I1IiiI + OoOoOO00
  Ooo = xbmcgui . Window ( 10000 )
  Ooo . setProperty ( 'SPOTV_M_SESSIONID' , '' )
  Ooo . setProperty ( 'SPOTV_M_SESSION' , '' )
  Ooo . setProperty ( 'SPOTV_M_ACCOUNTID' , '' )
  Ooo . setProperty ( 'SPOTV_M_POLICYKEY' , '' )
  Ooo . setProperty ( 'SPOTV_M_SUBEND' , '' )
  Ooo . setProperty ( 'SPOTV_M_LOGINTIME' , '' )
  if 10 - 10: o0oOOo0O0Ooo / i11iIiiIii
  if 92 - 92: I11i . I1Ii111
  if 85 - 85: I1ii11iIi11i . I1Ii111
  if 78 - 78: ooOoO0o * I1Ii111 + iIii1I11I1II1 + iIii1I11I1II1 / I1Ii111 . Ii1I
 def cookiefile_save ( self ) :
  O000 = self . SpotvObj . Get_Now_Datetime ( )
  ooo0o000O = O000 + datetime . timedelta ( days = int ( __addon__ . getSetting ( 'cache_ttl' ) ) )
  if 100 - 100: oO0o . ooOoO0o * I1ii11iIi11i / iIii1I11I1II1 * i1IIi % ooOoO0o
  Ooo = xbmcgui . Window ( 10000 )
  I1I = { 'spotv_sessionid' : Ooo . getProperty ( 'SPOTV_M_SESSIONID' )
 , 'spotv_session' : Ooo . getProperty ( 'SPOTV_M_SESSION' )
 , 'spotv_accountId' : Ooo . getProperty ( 'SPOTV_M_ACCOUNTID' )
 , 'spotv_policyKey' : base64 . standard_b64encode ( Ooo . getProperty ( 'SPOTV_M_POLICYKEY' ) . encode ( ) ) . decode ( 'utf-8' )
 , 'spotv_subend' : base64 . standard_b64encode ( ( self . SpotvObj . SPOTV_PMCODE + Ooo . getProperty ( 'SPOTV_M_SUBEND' ) ) . encode ( ) ) . decode ( 'utf-8' )
 , 'spotv_id' : base64 . standard_b64encode ( __addon__ . getSetting ( 'id' ) . encode ( ) ) . decode ( 'utf-8' )
 , 'spotv_pw' : base64 . standard_b64encode ( __addon__ . getSetting ( 'pw' ) . encode ( ) ) . decode ( 'utf-8' )
 , 'spotv_limitdate' : ooo0o000O . strftime ( '%Y-%m-%d' )
 }
  if 89 - 89: i1IIi / II111iiii . iIii1I11I1II1
  try :
   with open ( oo00 , 'w' ) as i11IIIiI1I :
    json . dump ( I1I , i11IIIiI1I )
  except Exception as o0 :
   print ( o0 )
   if 30 - 30: O0 * OoooooooOO
   if 38 - 38: IiII - I1ii11iIi11i . OoOoOO00 - I1Ii111 . OoooooooOO
   if 89 - 89: iIii1I11I1II1
   if 21 - 21: I11i % I11i
 def cookiefile_check ( self ) :
  if 27 - 27: i11iIiiIii / I1ii11iIi11i
  if 84 - 84: Oo0Ooo
  I1I = { }
  try :
   with open ( oo00 , 'r' ) as i11IIIiI1I :
    I1I = json . load ( i11IIIiI1I )
  except Exception as o0 :
   self . wininfo_clear ( )
   return False
   if 43 - 43: oO0o - OoooooooOO
   if 3 - 3: O0 / iII111i
   if 31 - 31: OOooOOo + o0oOOo0O0Ooo . OoooooooOO
  i11i = __addon__ . getSetting ( 'id' )
  o0oooOO00 = __addon__ . getSetting ( 'pw' )
  I1I [ 'spotv_id' ] = base64 . standard_b64decode ( I1I [ 'spotv_id' ] ) . decode ( 'utf-8' )
  I1I [ 'spotv_pw' ] = base64 . standard_b64decode ( I1I [ 'spotv_pw' ] ) . decode ( 'utf-8' )
  I1I [ 'spotv_policyKey' ] = base64 . standard_b64decode ( I1I [ 'spotv_policyKey' ] ) . decode ( 'utf-8' )
  I1I [ 'spotv_subend' ] = base64 . standard_b64decode ( I1I [ 'spotv_subend' ] ) . decode ( 'utf-8' ) [ self . SpotvObj . SPOTV_PMSIZE : ]
  if i11i != I1I [ 'spotv_id' ] or o0oooOO00 != I1I [ 'spotv_pw' ] :
   self . wininfo_clear ( )
   return False
   if 89 - 89: II111iiii + i1IIi + II111iiii
   if 7 - 7: O0 % o0oOOo0O0Ooo + I1ii11iIi11i * iII111i - iII111i
  o0O0OOOOoOO0 = int ( self . SpotvObj . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' ) )
  II1Ii11I111I = I1I [ 'spotv_limitdate' ]
  ii = int ( re . sub ( '-' , '' , II1Ii11I111I ) )
  if 13 - 13: ooOoO0o / iII111i * OoO0O00 . OoO0O00 * ooOoO0o
  if 63 - 63: I1Ii111 / O0 * Oo0Ooo + II111iiii / IiII + Ii1I
  if ii < o0O0OOOOoOO0 :
   self . wininfo_clear ( )
   return False
   if 63 - 63: OoO0O00 + I1ii11iIi11i . I1Ii111 % I1Ii111
   if 57 - 57: II111iiii
  Ooo = xbmcgui . Window ( 10000 )
  Ooo . setProperty ( 'SPOTV_M_SESSIONID' , I1I [ 'spotv_sessionid' ] )
  Ooo . setProperty ( 'SPOTV_M_SESSION' , I1I [ 'spotv_session' ] )
  Ooo . setProperty ( 'SPOTV_M_ACCOUNTID' , I1I [ 'spotv_accountId' ] )
  Ooo . setProperty ( 'SPOTV_M_POLICYKEY' , I1I [ 'spotv_policyKey' ] )
  Ooo . setProperty ( 'SPOTV_M_SUBEND' , I1I [ 'spotv_subend' ] )
  Ooo . setProperty ( 'SPOTV_M_LOGINTIME' , II1Ii11I111I )
  if 54 - 54: Oo0Ooo + oO0o + i11iIiiIii
  return True
  if 28 - 28: oO0o
  if 70 - 70: IiII
  if 34 - 34: I1Ii111 % IiII
  if 3 - 3: II111iiii / OOooOOo + IiII . ooOoO0o . OoO0O00
 def dp_WatchList_Delete ( self , args ) :
  Oo0 = args . get ( 'mediatype' )
  if 83 - 83: oO0o + OoooooooOO
  O0I11i1i11i1I = xbmcgui . Dialog ( )
  Iii11iI1i = O0I11i1i11i1I . yesno ( __language__ ( 30904 ) . encode ( 'utf8' ) , __language__ ( 30905 ) . encode ( 'utf8' ) )
  if Iii11iI1i == False : sys . exit ( )
  if 22 - 22: Ii1I % iII111i * OoooooooOO - o0oOOo0O0Ooo / iIii1I11I1II1
  self . Delete_Watched_List ( Oo0 )
  if 86 - 86: OoooooooOO . iII111i % OoOoOO00 / I11i * iII111i / o0oOOo0O0Ooo
  xbmc . executebuiltin ( "Container.Refresh" )
  if 64 - 64: i11iIiiIii
  if 38 - 38: IiII / I1IiiI - IiII . I11i
  if 69 - 69: OoooooooOO + I1ii11iIi11i
  if 97 - 97: OOooOOo - OoO0O00 / Ii1I . i11iIiiIii % oO0o * oO0o
 def Delete_Watched_List ( self , mediatype ) :
  try :
   ii1IIIIiI11 = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % mediatype ) )
   with open ( ii1IIIIiI11 , 'w' ) as i11IIIiI1I :
    i11IIIiI1I . write ( '' )
  except :
   None
   if 40 - 40: o0oOOo0O0Ooo
   if 67 - 67: oO0o + II111iiii - O0 . oO0o * II111iiii * I11i
   if 90 - 90: Ii1I . IiII
   if 81 - 81: OOooOOo - I11i % ooOoO0o - OoO0O00 / Oo0Ooo
 def Load_Watched_List ( self , mediatype ) :
  try :
   ii1IIIIiI11 = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % mediatype ) )
   with open ( ii1IIIIiI11 , 'r' ) as i11IIIiI1I :
    Ii1iI111 = i11IIIiI1I . readlines ( )
  except :
   Ii1iI111 = [ ]
   if 51 - 51: IiII * O0 / II111iiii . Ii1I % OOooOOo / I1IiiI
  return Ii1iI111
  if 9 - 9: I1IiiI % I1IiiI % II111iiii
  if 30 - 30: IiII + I1Ii111 - IiII . IiII - II111iiii + O0
  if 86 - 86: i1IIi
  if 41 - 41: OoOoOO00 * I11i / OoOoOO00 % oO0o
 def Save_Watched_List ( self , stype , in_params ) :
  try :
   ii1IIIIiI11 = xbmc . translatePath ( os . path . join ( __profile__ , 'watchedlist_%s.txt' % stype ) )
   Ii = self . Load_Watched_List ( stype )
   if 77 - 77: OoOoOO00 % Ii1I
   with open ( ii1IIIIiI11 , 'w' ) as i11IIIiI1I :
    II1IiiIii = urllib . urlencode ( in_params )
    II1IiiIii = II1IiiIii . encode ( 'utf-8' ) + '\n'
    i11IIIiI1I . write ( II1IiiIii )
    if 84 - 84: oO0o % i1IIi
    oOO = 0
    for Ii1II in Ii :
     O0Oo00 = dict ( urlparse . parse_qsl ( Ii1II ) )
     if 41 - 41: iIii1I11I1II1 % I11i
     oOo0oO = in_params . get ( 'code' )
     IIi1IIIIi = O0Oo00 . get ( 'code' )
     if 70 - 70: OOooOOo / II111iiii - iIii1I11I1II1 - iII111i
     if oOo0oO != IIi1IIIIi :
      i11IIIiI1I . write ( Ii1II )
      oOO += 1
      if oOO >= 50 : break
      if 11 - 11: iIii1I11I1II1 . OoooooooOO . II111iiii / i1IIi - I11i
  except :
   None
   if 30 - 30: OoOoOO00
   if 21 - 21: i11iIiiIii / I1Ii111 % OOooOOo * O0 . I11i - iIii1I11I1II1
   if 26 - 26: II111iiii * OoOoOO00
   if 10 - 10: II111iiii . iII111i
 def dp_Watch_List ( self , args ) :
  if 32 - 32: Ii1I . IiII . OoooooooOO - OoO0O00 + oO0o
  Oo0 = 'vod'
  if 88 - 88: iII111i
  if Oo0 == 'vod' :
   if 19 - 19: II111iiii * IiII + Ii1I
   O0o = self . Load_Watched_List ( Oo0 )
   if 95 - 95: OoO0O00
   for OoOOo000o0 in O0o :
    iiI1II11II1i = dict ( urlparse . parse_qsl ( OoOOo000o0 ) )
    if 67 - 67: OOooOOo + Oo0Ooo
    ooo = iiI1II11II1i . get ( 'title' )
    oo0oOo = iiI1II11II1i . get ( 'img' )
    oOoO0 = iiI1II11II1i . get ( 'code' )
    OoOo000oOo0oo = iiI1II11II1i . get ( 'info' )
    if 65 - 65: OoOoOO00 / OoO0O00 % IiII
    OOoo0O = { }
    if 45 - 45: OoOoOO00
    OOoo0O [ 'plot' ] = OoOo000oOo0oo
    if 66 - 66: OoO0O00
    i1Ii = { 'mode' : 'GAME_VOD_GROUP'
 , 'gameid' : oOoO0
 , 'saveTitle' : ooo
 , 'saveImg' : oo0oOo
 , 'saveInfo' : OoOo000oOo0oo
 , 'mediatype' : Oo0
 }
    if 56 - 56: O0
    self . add_dir ( ooo , sublabel = '' , img = oo0oOo , infoLabels = OOoo0O , isFolder = True , params = i1Ii )
    if 61 - 61: o0oOOo0O0Ooo / OOooOOo / Oo0Ooo * O0
    if 23 - 23: oO0o - OOooOOo + I11i
   OOoo0O = { 'plot' : '시청목록을 삭제합니다.' }
   ooo = '*** 시청목록 삭제 ***'
   i1Ii = { 'mode' : 'MYVIEW_REMOVE'
 , 'mediatype' : Oo0
 }
   self . add_dir ( ooo , sublabel = '' , img = '' , infoLabels = OOoo0O , isFolder = False , params = i1Ii )
   if 12 - 12: I1IiiI / ooOoO0o % o0oOOo0O0Ooo / i11iIiiIii % OoooooooOO
   xbmcplugin . endOfDirectory ( self . _addon_handle , cacheToDisc = False )
   if 15 - 15: iIii1I11I1II1 % OoooooooOO - Oo0Ooo * Ii1I + I11i
   if 11 - 11: iII111i * Ii1I - OoOoOO00
   if 66 - 66: OoOoOO00 . i11iIiiIii - iII111i * o0oOOo0O0Ooo + OoooooooOO * I1ii11iIi11i
   if 74 - 74: Oo0Ooo
   if 61 - 61: Oo0Ooo - I1Ii111 * II111iiii % ooOoO0o * iIii1I11I1II1 + OoO0O00
 def spotv_main ( self ) :
  if 71 - 71: I11i / I11i * oO0o * oO0o / II111iiii
  II1I1iiIII1I1 = self . main_params . get ( 'mode' , None )
  if 85 - 85: iII111i * o0oOOo0O0Ooo
  if 3 - 3: OOooOOo
  if II1I1iiIII1I1 == 'LOGOUT' :
   self . logout ( )
   return
   if 20 - 20: II111iiii . iII111i / II111iiii % i11iIiiIii % iII111i
   if 11 - 11: IiII % I1ii11iIi11i % Ii1I / II111iiii % I1Ii111 - Oo0Ooo
   if 96 - 96: I1ii11iIi11i / II111iiii . Ii1I - iII111i * I11i * oO0o
   if 76 - 76: Ii1I - II111iiii * OOooOOo / OoooooooOO
   if 18 - 18: OoO0O00 + iIii1I11I1II1 - II111iiii - I1IiiI
   if 71 - 71: OoooooooOO
  self . login_main ( )
  if 33 - 33: I1Ii111
  if II1I1iiIII1I1 is None :
   self . dp_Main_List ( )
   if 62 - 62: I1ii11iIi11i + Ii1I + i1IIi / OoooooooOO
  elif II1I1iiIII1I1 == 'LIVE_GROUP' :
   self . dp_LiveChannel_List ( self . main_params )
   if 7 - 7: o0oOOo0O0Ooo + i1IIi . I1IiiI / Oo0Ooo
  elif II1I1iiIII1I1 == 'ELIVE_GROUP' :
   o00o0 = self . dp_EventLiveChannel_List ( self . main_params )
   if 22 - 22: ooOoO0o - ooOoO0o % OOooOOo . I1Ii111 + oO0o
   if 63 - 63: I1IiiI % I1Ii111 * o0oOOo0O0Ooo + I1Ii111 / Oo0Ooo % iII111i
   if o00o0 == 401 :
    if os . path . isfile ( oo00 ) : os . remove ( oo00 )
    self . login_main ( )
    self . dp_EventLiveChannel_List ( self . main_params )
    if 45 - 45: IiII
  elif II1I1iiIII1I1 in [ 'LIVE' , 'GAME_VOD' , 'POP_VOD' , 'ELIVE' ] :
   if 20 - 20: OoooooooOO * o0oOOo0O0Ooo * O0 . OOooOOo
   self . play_VIDEO ( self . main_params )
   if 78 - 78: iIii1I11I1II1 + I11i - Ii1I * I1Ii111 - OoooooooOO % OoOoOO00
  elif II1I1iiIII1I1 == 'VOD_GROUP' :
   self . dp_MainLeague_List ( self . main_params )
   if 34 - 34: O0
  elif II1I1iiIII1I1 == 'POP_GROUP' :
   self . dp_PopVod_GroupList ( self . main_params )
   if 80 - 80: i1IIi - Oo0Ooo / OoO0O00 - i11iIiiIii
  elif II1I1iiIII1I1 == 'LEAGUE_GROUP' :
   self . dp_Season_List ( self . main_params )
   if 68 - 68: oO0o - I1ii11iIi11i % O0 % I1Ii111
  elif II1I1iiIII1I1 == 'SEASON_GROUP' :
   self . dp_Game_List ( self . main_params )
   if 11 - 11: O0 / OoO0O00 % OOooOOo + o0oOOo0O0Ooo + iIii1I11I1II1
  elif II1I1iiIII1I1 == 'GAME_VOD_GROUP' :
   self . dp_GameVod_List ( self . main_params )
   if 40 - 40: ooOoO0o - OOooOOo . Ii1I * Oo0Ooo % I1Ii111
  elif II1I1iiIII1I1 == 'WATCH' :
   self . dp_Watch_List ( self . main_params )
   if 56 - 56: i11iIiiIii . o0oOOo0O0Ooo - I1IiiI * I11i
  elif II1I1iiIII1I1 == 'MYVIEW_REMOVE' :
   self . dp_WatchList_Delete ( self . main_params )
   if 91 - 91: oO0o + OoooooooOO - i1IIi
   if 84 - 84: Ii1I / IiII
   if 86 - 86: OoOoOO00 * II111iiii - O0 . OoOoOO00 % iIii1I11I1II1 / OOooOOo
   if 11 - 11: I1IiiI * oO0o + I1ii11iIi11i / I1ii11iIi11i
  else :
   None
   if 37 - 37: i11iIiiIii + i1IIi
   if 23 - 23: iII111i + I11i . OoOoOO00 * I1IiiI + I1ii11iIi11i
   if 18 - 18: IiII * o0oOOo0O0Ooo . IiII / O0
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
