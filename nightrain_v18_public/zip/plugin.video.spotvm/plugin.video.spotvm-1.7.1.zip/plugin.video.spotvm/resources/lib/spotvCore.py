# -*- coding: utf-8 -*-
__author__ = "NightRain"
if 64 - 64: i11iIiiIii
import urllib
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
import re
import json
import sys
import time
import requests
import datetime
import base64
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
reload ( sys )
sys . setdefaultencoding ( 'utf-8' )
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * Ii1I
i1I1ii1II1iII = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
oooO0oo0oOOOO = { 'stream50' : 1080 , 'stream40' : 720 , 'stream30' : 540 }
if 53 - 53: I11i / Oo0Ooo / II111iiii % Ii1I / OoOoOO00 . ooOoO0o
if 100 - 100: i1IIi
if 27 - 27: IiII * OoooooooOO + I11i * ooOoO0o - i11iIiiIii - iII111i
if 30 - 30: iIii1I11I1II1 * iIii1I11I1II1 . II111iiii - oO0o
class xooO00oOoo ( object ) :
 def __init__ ( self ) :
  self . SPOTV_SESSIONID = ''
  self . SPOTV_SESSION = ''
  self . SPOTV_ACCOUNTID = ''
  self . SPOTV_POLICYKEY = ''
  self . SPOTV_SUBEND = ''
  self . SPOTV_PMCODE = '987'
  self . SPOTV_PMSIZE = 3
  self . GAMELIST_LIMIT = 10
  self . API_DOMAIN = 'https://www.spotvnow.co.kr'
  self . BC_DOMAIN = 'https://players.brightcove.net'
  self . PLAYER_DOMAIN = 'https://edge.api.brightcove.com'
  self . DEFAULT_HEADER = { 'user-agent' : i1I1ii1II1iII }
  if 78 - 78: I11i / OoO0O00 - O0 . IiII
  if 91 - 91: I1ii11iIi11i * iIii1I11I1II1 . IiII / Ii1I
 def callRequestCookies ( self , jobtype , url , payload = None , params = None , headers = None , cookies = None , redirects = False ) :
  Ooo0 = self . DEFAULT_HEADER
  if headers : Ooo0 . update ( headers )
  if 89 - 89: OoooooooOO - IiII * ooOoO0o
  if jobtype == 'Get' :
   O0I11i1i11i1I = requests . get ( url , params = params , headers = Ooo0 , cookies = cookies , allow_redirects = redirects )
  else :
   O0I11i1i11i1I = requests . post ( url , data = payload , params = params , headers = Ooo0 , cookies = cookies , allow_redirects = redirects )
   if 31 - 31: i11iIiiIii / I1IiiI / ooOoO0o * oO0o / Oo0Ooo
  return O0I11i1i11i1I
  if 99 - 99: iIii1I11I1II1 * OoooooooOO * II111iiii * iIii1I11I1II1
  if 44 - 44: oO0o / Oo0Ooo - II111iiii - i11iIiiIii % I1Ii111
 def makeDefaultCookies ( self ) :
  O0OoOoo00o = { 'SESSION' : self . SPOTV_SESSION }
  return O0OoOoo00o
  if 31 - 31: II111iiii + OoO0O00 . I1Ii111
  if 68 - 68: I1IiiI - i11iIiiIii - OoO0O00 / OOooOOo - OoO0O00 + i1IIi
 def GetCredential ( self , user_id , user_pw ) :
  IiiIII111ii = False
  i1iIIi1 = ii11iIi1I = iI111I11I1I1 = OOooO0OOoo = iIii1 = ''
  if 71 - 71: OoO0O00
  try :
   oO0O = base64 . standard_b64encode ( user_id . encode ( "UTF-8" ) ) . decode ( 'utf-8' )
   OOoO000O0OO = base64 . standard_b64encode ( user_pw . encode ( "UTF-8" ) ) . decode ( 'utf-8' )
   if 23 - 23: i11iIiiIii + I1IiiI
   oOo = self . API_DOMAIN + '/api/v2/login'
   if 63 - 63: Oo0Ooo
   ooOoOoo0O = { 'username' : oO0O
 , 'password' : OOoO000O0OO
 }
   ooOoOoo0O = json . dumps ( ooOoOoo0O )
   if 76 - 76: O0 / o0oOOo0O0Ooo . I1IiiI * Ii1I - OOooOOo
   Oooo = self . callRequestCookies ( 'Post' , oOo , payload = ooOoOoo0O , params = None , headers = None , cookies = None )
   print ( Oooo . status_code )
   if 67 - 67: OOooOOo / OoooooooOO % I11i - iIii1I11I1II1
   if 82 - 82: i11iIiiIii . OOooOOo / Oo0Ooo * O0 % oO0o % iIii1I11I1II1
   if 78 - 78: iIii1I11I1II1 - Ii1I * OoO0O00 + o0oOOo0O0Ooo + iII111i + iII111i
   for I11I11i1I in Oooo . cookies :
    if I11I11i1I . name == 'SESSION' :
     ii11iIi1I = I11I11i1I . value
     break
   if ii11iIi1I == '' : return IiiIII111ii
   if 49 - 49: II111iiii % iII111i * O0
   if 89 - 89: oO0o + Oo0Ooo
   Ii1IOo0o0 = json . loads ( Oooo . text )
   if not ( 'userId' in Ii1IOo0o0 ) : return IiiIII111ii
   i1iIIi1 = str ( Ii1IOo0o0 [ 'userId' ] )
   iIii1 = str ( Ii1IOo0o0 [ 'subEndTime' ] )
   if 49 - 49: oO0o % Ii1I + i1IIi . I1IiiI % I1ii11iIi11i
   if 48 - 48: I11i + I11i / II111iiii / iIii1I11I1II1
   iI111I11I1I1 , OOooO0OOoo = self . GetPolicyKey ( )
   if OOooO0OOoo == '' : return IiiIII111ii
   if 20 - 20: o0oOOo0O0Ooo
   IiiIII111ii = True
   if 77 - 77: OoOoOO00 / I11i
  except Exception as Ooooo :
   i1iIIi1 = ii11iIi1I = ''
   print ( Ooooo )
   if 2 - 2: ooOoO0o / OOooOOo - IiII . OoOoOO00
  OOoo0O0 = {
 'spotv_sessionid' : i1iIIi1
 , 'spotv_session' : ii11iIi1I
 , 'spotv_accountId' : iI111I11I1I1
 , 'spotv_policyKey' : OOooO0OOoo
 , 'spotv_subend' : iIii1
 }
  if 41 - 41: oO0o
  if 6 - 6: I1ii11iIi11i
  self . SaveCredential ( OOoo0O0 )
  if 31 - 31: Ii1I . Ii1I - o0oOOo0O0Ooo / OoO0O00 + ooOoO0o * I1IiiI
  return IiiIII111ii
  if 63 - 63: I1Ii111 % i1IIi / OoooooooOO - OoooooooOO
  if 8 - 8: OoOoOO00
 def SaveCredential ( self , login_params ) :
  self . SPOTV_SESSIONID = login_params . get ( 'spotv_sessionid' )
  self . SPOTV_SESSION = login_params . get ( 'spotv_session' )
  self . SPOTV_ACCOUNTID = login_params . get ( 'spotv_accountId' )
  self . SPOTV_POLICYKEY = login_params . get ( 'spotv_policyKey' )
  self . SPOTV_SUBEND = login_params . get ( 'spotv_subend' )
  if 60 - 60: I11i / I11i
 def LoadCredential ( self ) :
  OOoo0O0 = {
 'spotv_sessionid' : self . SPOTV_SESSIONID
 , 'spotv_session' : self . SPOTV_SESSION
 , 'spotv_accountId' : self . SPOTV_ACCOUNTID
 , 'spotv_policyKey' : self . SPOTV_POLICYKEY
 , 'spotv_subend' : self . SPOTV_SUBEND
 }
  return OOoo0O0
  if 46 - 46: Ii1I * OOooOOo - OoO0O00 * oO0o - I1Ii111
  if 83 - 83: OoooooooOO
 def Get_Now_Datetime ( self ) :
  if 31 - 31: II111iiii - OOooOOo . I1Ii111 % OoOoOO00 - O0
  return datetime . datetime . utcnow ( ) + datetime . timedelta ( hours = 9 )
  if 4 - 4: II111iiii / ooOoO0o . iII111i
  if 58 - 58: OOooOOo * i11iIiiIii / OoOoOO00 % I1Ii111 - I1ii11iIi11i / oO0o
 def GetLiveChannelList ( self ) :
  ii11i1 = [ ]
  IIIii1II1II = { }
  if 42 - 42: Ii1I + oO0o
  try :
   o0O0o0Oo = self . API_DOMAIN + '/api/v2/channel'
   if 16 - 16: O0 - I1Ii111 * iIii1I11I1II1 + iII111i
   if 50 - 50: II111iiii - ooOoO0o * I1ii11iIi11i / I1Ii111 + o0oOOo0O0Ooo
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = None )
   Ii1IOo0o0 = json . loads ( Oooo . text )
   if 88 - 88: Ii1I / I1Ii111 + iII111i - II111iiii / ooOoO0o - OoOoOO00
   if 15 - 15: I1ii11iIi11i + OoOoOO00 - OoooooooOO / OOooOOo
   IIIii1II1II = self . GetEPGList ( )
   if 58 - 58: i11iIiiIii % I11i
   for OO00Oo in range ( 2 ) :
    for O0OOO0OOoO0O in Ii1IOo0o0 :
     O00Oo000ooO0 = { }
     O00Oo000ooO0 [ 'mediatype' ] = 'video'
     if 100 - 100: O0 + IiII - OOooOOo + i11iIiiIii * Ii1I
     O00Oo000ooO0 [ 'title' ] = O0OOO0OOoO0O [ 'programName' ]
     O00Oo000ooO0 [ 'studio' ] = O0OOO0OOoO0O [ 'name' ]
     if 30 - 30: o0oOOo0O0Ooo . Ii1I - OoooooooOO
     Ii1iIiii1 = { 'id' : O0OOO0OOoO0O [ 'id' ]
 , 'name' : O0OOO0OOoO0O [ 'name' ]
 , 'logo' : O0OOO0OOoO0O [ 'logo' ]
 , 'videoId' : O0OOO0OOoO0O [ 'videoId' ] . replace ( 'ref:' , '' )
 , 'free' : O0OOO0OOoO0O [ 'free' ]
 , 'programName' : O0OOO0OOoO0O [ 'programName' ]
 , 'channelepg' : IIIii1II1II . get ( O0OOO0OOoO0O [ 'id' ] )
 , 'info' : O00Oo000ooO0
 }
     if 91 - 91: OoO0O00 . I1ii11iIi11i + OoO0O00 - iII111i / OoooooooOO
     if OO00Oo == 0 :
      if O0OOO0OOoO0O [ 'free' ] == False : ii11i1 . append ( Ii1iIiii1 )
     else :
      if O0OOO0OOoO0O [ 'free' ] == True : ii11i1 . append ( Ii1iIiii1 )
      if 39 - 39: I1ii11iIi11i / ooOoO0o - II111iiii
  except Exception as Ooooo :
   print ( Ooooo )
   if 98 - 98: I1ii11iIi11i / I11i % oO0o . OoOoOO00
  return ii11i1
  if 91 - 91: oO0o % Oo0Ooo
  if 64 - 64: I11i % iII111i - I1Ii111 - oO0o
 def CheckLiveChannel ( self , channelid ) :
  try :
   o0O0o0Oo = self . API_DOMAIN + '/api/v2/channel'
   if 31 - 31: I11i - II111iiii . I11i
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = None )
   Ii1IOo0o0 = json . loads ( Oooo . text )
   if 18 - 18: o0oOOo0O0Ooo
   for O0OOO0OOoO0O in Ii1IOo0o0 :
    if O0OOO0OOoO0O [ 'videoId' ] . replace ( 'ref:' , '' ) == channelid :
     return O0OOO0OOoO0O [ 'free' ]
     if 98 - 98: iII111i * iII111i / iII111i + I11i
  except Exception as Ooooo :
   print ( Ooooo )
  return False
  if 34 - 34: ooOoO0o
  if 15 - 15: I11i * ooOoO0o * Oo0Ooo % i11iIiiIii % OoOoOO00 - OOooOOo
 def GetEPGList ( self ) :
  O0ooo0O0oo0 = { }
  if 91 - 91: iIii1I11I1II1 + I1Ii111
  i1i = self . Get_Now_Datetime ( )
  I1I1iIiII1 = i1i . strftime ( '%Y%m%d%H%M' )
  i11i1I1 = '%s-%s-%s' % ( I1I1iIiII1 [ 0 : 4 ] , I1I1iIiII1 [ 4 : 6 ] , I1I1iIiII1 [ 6 : 8 ] )
  if 36 - 36: iIii1I11I1II1 / OoOoOO00 * OOooOOo
  O0ii1ii1ii = ( i1i + datetime . timedelta ( hours = 4 ) ) . strftime ( '%Y%m%d%H%M' )
  if 91 - 91: IiII
  if 15 - 15: II111iiii
  try :
   o0O0o0Oo = self . API_DOMAIN + '/api/v2/program/' + i11i1I1
   if 18 - 18: i11iIiiIii . i1IIi % OoooooooOO / O0
   if 75 - 75: OoOoOO00 % o0oOOo0O0Ooo % o0oOOo0O0Ooo . I1Ii111
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = None )
   Ii1IOo0o0 = json . loads ( Oooo . text )
   if 5 - 5: o0oOOo0O0Ooo * ooOoO0o + OoOoOO00 . OOooOOo + OoOoOO00
   oO = - 1
   iIi1IIIi1 = ''
   if 86 - 86: I11i % OoOoOO00 / I1IiiI / OoOoOO00
   for O0OOO0OOoO0O in Ii1IOo0o0 :
    iIIi1i1 = O0OOO0OOoO0O [ 'channelId' ]
    i1IIIiiII1 = O0OOO0OOoO0O [ 'startTime' ] . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' )
    OOOOoOoo0O0O0 = O0OOO0OOoO0O [ 'endTime' ] . replace ( '-' , '' ) . replace ( ' ' , '' ) . replace ( ':' , '' )
    if 85 - 85: oO0o % i11iIiiIii - iII111i * OoooooooOO / I1IiiI % I1IiiI
    if int ( I1I1iIiII1 ) > int ( OOOOoOoo0O0O0 ) : continue
    if int ( O0ii1ii1ii ) < int ( i1IIIiiII1 ) : continue
    if 1 - 1: OoO0O00 - oO0o . I11i . OoO0O00 / Oo0Ooo + I11i
    if oO != iIIi1i1 :
     if iIi1IIIi1 != '' : O0ooo0O0oo0 [ oO ] = iIi1IIIi1
     if 78 - 78: O0 . oO0o . II111iiii % OOooOOo
     oO = iIIi1i1
     iIi1IIIi1 = ''
     if 49 - 49: Ii1I / OoO0O00 . II111iiii
    if iIi1IIIi1 : iIi1IIIi1 += '\n'
    iIi1IIIi1 += O0OOO0OOoO0O [ 'title' ] + '\n'
    iIi1IIIi1 += ' [%s ~ %s]' % ( O0OOO0OOoO0O [ 'startTime' ] [ - 5 : ] , O0OOO0OOoO0O [ 'endTime' ] [ - 5 : ] ) + '\n'
    if 68 - 68: i11iIiiIii % I1ii11iIi11i + i11iIiiIii
   if iIi1IIIi1 : O0ooo0O0oo0 [ oO ] = iIi1IIIi1
   if 31 - 31: II111iiii . I1IiiI
   if 1 - 1: Oo0Ooo / o0oOOo0O0Ooo % iII111i * IiII . i11iIiiIii
  except Exception as Ooooo :
   print ( Ooooo )
   if 2 - 2: I1ii11iIi11i * I11i - iIii1I11I1II1 + I1IiiI . oO0o % iII111i
  return O0ooo0O0oo0
  if 92 - 92: iII111i
  if 25 - 25: Oo0Ooo - I1IiiI / OoooooooOO / o0oOOo0O0Ooo
 def GetEventLiveList ( self ) :
  ii11i1 = [ ]
  II111iiiI1Ii = 0
  if 78 - 78: Ii1I % I1Ii111 + I1ii11iIi11i
  if 64 - 64: oO0o * O0 . I1IiiI + II111iiii
  try :
   IIi1i = self . Get_Now_Datetime ( )
   OOOO00O0O = IIi1i . strftime ( '%Y-%m-%d' )
  except Exception as Ooooo :
   print ( Ooooo )
   return ii11i1 , II111iiiI1Ii
   if 33 - 33: O0 . IiII . I1IiiI
   if 72 - 72: i1IIi / OoO0O00 + OoooooooOO - Oo0Ooo
  try :
   o0O0o0Oo = self . API_DOMAIN + '/api/v2/player/lives/' + OOOO00O0O
   if 29 - 29: I1ii11iIi11i + oO0o % O0
   O0OoOoo00o = self . makeDefaultCookies ( )
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = O0OoOoo00o )
   if 10 - 10: I11i / I1Ii111 - I1IiiI * iIii1I11I1II1 - I1IiiI
   II111iiiI1Ii = Oooo . status_code
   if 97 - 97: I1ii11iIi11i + I1IiiI * Ii1I + OOooOOo % iII111i
   Ii1IOo0o0 = json . loads ( Oooo . text )
   if 74 - 74: oO0o - Oo0Ooo + OoooooooOO + I1Ii111 / OoOoOO00
   if 23 - 23: O0
   if 85 - 85: Ii1I
   for OO in Ii1IOo0o0 :
    for O0OOO0OOoO0O in OO [ 'liveNowList' ] :
     if 77 - 77: Oo0Ooo
     O00Oo000ooO0 = { }
     O00Oo000ooO0 [ 'mediatype' ] = 'video'
     if 17 - 17: iII111i % OoO0O00 . OOooOOo + OoO0O00 / II111iiii
     if O0OOO0OOoO0O [ 'gameDesc' ] [ 'title' ] == None or O0OOO0OOoO0O [ 'gameDesc' ] [ 'title' ] == '' :
      oo0O0O00 = '%s ( %s : %s )' % ( O0OOO0OOoO0O [ 'leagueName' ] , O0OOO0OOoO0O [ 'homeNameShort' ] , O0OOO0OOoO0O [ 'awayNameShort' ] )
     else :
      oo0O0O00 = O0OOO0OOoO0O [ 'gameDesc' ] [ 'title' ]
      if 47 - 47: o0oOOo0O0Ooo + ooOoO0o
     Ii1iIiii1 = { 'liveId' : O0OOO0OOoO0O [ 'liveId' ]
 , 'title' : oo0O0O00
 , 'logo' : O0OOO0OOoO0O [ 'gameDesc' ] [ 'leagueLogo' ]
 , 'free' : O0OOO0OOoO0O [ 'isFree' ]
 , 'startTime' : O0OOO0OOoO0O [ 'startTime' ]
 , 'info' : O00Oo000ooO0
 }
     if 82 - 82: II111iiii . IiII - iIii1I11I1II1 - IiII * II111iiii
     ii11i1 . append ( Ii1iIiii1 )
     if 77 - 77: iIii1I11I1II1 * OoO0O00
  except Exception as Ooooo :
   print ( Ooooo )
   if 95 - 95: I1IiiI + i11iIiiIii
  return ii11i1 , II111iiiI1Ii
  if 6 - 6: ooOoO0o / i11iIiiIii + iII111i * oO0o
  if 80 - 80: II111iiii
 def GetEventLive_videoId ( self , liveId ) :
  O0O = ''
  if 1 - 1: II111iiii
  try :
   o0O0o0Oo = self . API_DOMAIN + '/api/v2/live/' + liveId
   if 84 - 84: o0oOOo0O0Ooo % II111iiii . i11iIiiIii / OoO0O00
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = None )
   Ii1IOo0o0 = json . loads ( Oooo . text )
   if 80 - 80: I1Ii111 . i11iIiiIii - o0oOOo0O0Ooo
   iIiIIi1 = Ii1IOo0o0 [ 'videoId' ]
   O0O = iIiIIi1 . replace ( 'ref:' , '' )
   if 7 - 7: ooOoO0o - Oo0Ooo - oO0o + ooOoO0o
  except Exception as Ooooo :
   print ( Ooooo )
   if 26 - 26: Ii1I
  return O0O
  if 35 - 35: Ii1I - I1IiiI % o0oOOo0O0Ooo . OoooooooOO % Ii1I
  if 47 - 47: iII111i - Ii1I . II111iiii + OoooooooOO . i11iIiiIii
 def CheckMainEnd ( self ) :
  OOo0oO00ooO00 = base64 . standard_b64encode ( ( self . SPOTV_PMCODE + self . SPOTV_SESSIONID ) . encode ( ) ) . decode ( 'utf-8' )
  if 90 - 90: OoOoOO00 * I1Ii111 + o0oOOo0O0Ooo
  if OOo0oO00ooO00 == 'OTg3MTgzMzM0Ng==' or OOo0oO00ooO00 == 'OTg3MTgzMzExNw==' : return True
  return False
  if 81 - 81: oO0o . o0oOOo0O0Ooo % O0 / I1IiiI - oO0o
  if 43 - 43: i11iIiiIii + Oo0Ooo * II111iiii * I1Ii111 * O0
 def CheckSubEnd ( self ) :
  o00oO0oo0OO = False
  try :
   if self . CheckMainEnd ( ) : return True
   if self . SPOTV_SUBEND == '0' : return o00oO0oo0OO
   if 57 - 57: I1Ii111 % Ii1I + o0oOOo0O0Ooo - Oo0Ooo
   if 65 - 65: I11i . OoOoOO00
   IiI1i = int ( self . Get_Now_Datetime ( ) . strftime ( '%Y%m%d' ) )
   o0O = int ( self . SPOTV_SUBEND ) / 1000
   o00 = int ( datetime . datetime . fromtimestamp ( o0O ) ) . strftime ( '%Y%m%d' ) )
   if IiI1i <= o00 : o00oO0oo0OO = True
   if 32 - 32: o0oOOo0O0Ooo . IiII * I11i
   if 93 - 93: o0oOOo0O0Ooo % i1IIi . Ii1I . i11iIiiIii
  except Exception as Ooooo :
   print ( Ooooo )
   return o00oO0oo0OO
  return o00oO0oo0OO
  if 56 - 56: I1ii11iIi11i % O0 - I1IiiI
  if 100 - 100: Ii1I - O0 % oO0o * OOooOOo + I1IiiI
 def GetMainJspath ( self ) :
  Oo0O0oooo = ''
  if 33 - 33: I1Ii111 + iII111i * oO0o / iIii1I11I1II1 - I1IiiI
  try :
   o0O0o0Oo = self . API_DOMAIN
   if 54 - 54: I1Ii111 / OOooOOo . oO0o % iII111i
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = None )
   Oo = Oooo . text
   if 65 - 65: Ii1I - oO0o + oO0o + II111iiii
   if 96 - 96: OOooOOo % O0 / O0
   iIi1 = re . findall ( 'https://cdn.spotvnow.co.kr/dist/js/.{20}\.js' , Oo ) [ 0 ]
   Oo0O0oooo = iIi1
   if 74 - 74: iIii1I11I1II1 * I1ii11iIi11i + OoOoOO00 / i1IIi / II111iiii . Oo0Ooo
  except Exception as Ooooo :
   print ( Ooooo )
   if 62 - 62: OoooooooOO * I1IiiI
  return Oo0O0oooo
  if 58 - 58: OoOoOO00 % o0oOOo0O0Ooo
  if 50 - 50: I1Ii111 . o0oOOo0O0Ooo
 def GetBcPlayerUrl ( self ) :
  ooO0OO = ''
  if 54 - 54: IiII + Ii1I % OoO0O00 + OoooooooOO - O0 - o0oOOo0O0Ooo
  try :
   o0O0o0Oo = self . GetMainJspath ( )
   if o0O0o0Oo == '' : return ooO0OO
   if 77 - 77: OOooOOo * iIii1I11I1II1
   if 98 - 98: I1IiiI % Ii1I * OoooooooOO
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = None )
   Oo = Oooo . text
   if 51 - 51: iIii1I11I1II1 . OoOoOO00 / oO0o + o0oOOo0O0Ooo
   I11 = re . findall ( 'bc:\s*\"\d{13}\",\s*player:\s*\".{9}\"' , Oo ) [ 0 ]
   I11 = I11 . replace ( 'bc' , '"bc"' )
   I11 = I11 . replace ( 'player' , '"player"' )
   I11 = '{' + I11 + '}'
   I11 = json . loads ( I11 )
   if 30 - 30: o0oOOo0O0Ooo % II111iiii % iII111i
   II111iI111I1I = I11 [ 'bc' ]
   I1i1i1iii = I11 [ 'player' ]
   ooO0OO = "%s/%s/%s_default/index.min.js" % ( self . BC_DOMAIN , II111iI111I1I , I1i1i1iii )
   if 16 - 16: Ii1I + IiII * O0 % i1IIi . I1IiiI
  except Exception as Ooooo :
   print ( Ooooo )
   if 67 - 67: OoooooooOO / I1IiiI * Ii1I + I11i
  return ooO0OO
  if 65 - 65: OoooooooOO - I1ii11iIi11i / ooOoO0o / II111iiii / i1IIi
  if 71 - 71: I1Ii111 + Ii1I
 def GetPolicyKey ( self ) :
  iI1111ii1I = iiI11iI = ''
  if 59 - 59: o0oOOo0O0Ooo % oO0o
  try :
   o0O0o0Oo = self . GetBcPlayerUrl ( )
   if o0O0o0Oo == '' : return iI1111ii1I , ii1iI1I11I
   if 20 - 20: oO0o / O0 * o0oOOo0O0Ooo - I1Ii111 % OoooooooOO * IiII
   if 18 - 18: Oo0Ooo * I1Ii111 + I1Ii111 * i11iIiiIii * iIii1I11I1II1 - ooOoO0o
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = None )
   Oo = Oooo . text
   if 29 - 29: OoOoOO00 - IiII * OoooooooOO + OoooooooOO . II111iiii + OoooooooOO
   iIi1 = re . findall ( 'accountId:\s*\"\d{13}\",\s*policyKey:\s*\".[^(){}]{100,300}\"' , Oo ) [ 0 ]
   iIi1 = iIi1 . replace ( 'accountId' , '"accountId"' )
   iIi1 = iIi1 . replace ( 'policyKey' , '"policyKey"' )
   iIi1 = '{' + iIi1 + '}'
   O0o000Oo = json . loads ( iIi1 )
   iI1111ii1I = O0o000Oo [ 'accountId' ]
   ii1iI1I11I = O0o000Oo [ 'policyKey' ]
   if 67 - 67: I1IiiI . i1IIi
  except Exception as Ooooo :
   print ( Ooooo )
   if 27 - 27: ooOoO0o % I1IiiI
  return iI1111ii1I , ii1iI1I11I
  if 73 - 73: OOooOOo
  if 70 - 70: iIii1I11I1II1
 def GetBroadURL ( self , videoId , mediatype , vtypeId ) :
  if 31 - 31: IiII - I1IiiI % iIii1I11I1II1
  if 92 - 92: i1IIi - iIii1I11I1II1
  IIIIIIii1 = ''
  if 88 - 88: OoO0O00
  try :
   if 71 - 71: I1ii11iIi11i
   if mediatype == 'live' :
    videoId = 'ref%3A' + videoId
   else :
    videoId = self . GetReplay_UrlId ( videoId , vtypeId )
    if videoId == '' : return IIIIIIii1
    if 7 - 7: I1ii11iIi11i - I1IiiI . iIii1I11I1II1 - i1IIi
   o0O0o0Oo = self . PLAYER_DOMAIN + '/playback/v1/accounts/' + self . SPOTV_ACCOUNTID + '/videos/' + videoId
   if 59 - 59: o0oOOo0O0Ooo
   oOoO00O0 = { 'accept' : 'application/json;pk=' + self . SPOTV_POLICYKEY

   }
   if 75 - 75: I1IiiI . ooOoO0o . O0 * I1Ii111
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = oOoO00O0 , cookies = None )
   i11II1I11I1 = json . loads ( Oooo . text )
   if 67 - 67: I1IiiI - o0oOOo0O0Ooo / I11i - i1IIi
   if 1 - 1: II111iiii
   if 68 - 68: iII111i - I1IiiI / I1Ii111 / I11i
   IIIIIIii1 = i11II1I11I1 [ 'sources' ] [ 0 ] [ 'src' ]
   if 12 - 12: Ii1I + i11iIiiIii * iIii1I11I1II1 / I1ii11iIi11i . I11i
   if 5 - 5: i1IIi + IiII / o0oOOo0O0Ooo . iII111i / I11i
   if mediatype == 'live' :
    IIIIIIii1 = IIIIIIii1 . replace ( 'playlist.m3u8' , 'playlist_dvr.m3u8' )
    if 32 - 32: I1IiiI % iIii1I11I1II1 / i1IIi - I1IiiI
   IIIIIIii1 = IIIIIIii1 . replace ( 'http://' , 'https://' )
   if 7 - 7: I1Ii111 * OoO0O00 - ooOoO0o + OOooOOo * I1IiiI % OoO0O00
  except Exception as Ooooo :
   print ( Ooooo )
   if 15 - 15: OoOoOO00 % I1IiiI * I11i
  return IIIIIIii1
  if 81 - 81: ooOoO0o - iIii1I11I1II1 - i1IIi / I1Ii111 - O0 * I11i
  if 20 - 20: oO0o % IiII
 def GetTitleGroupList ( self ) :
  ii11i1 = [ ]
  III1i1i11i = False
  if 100 - 100: oO0o / I1Ii111 / I1ii11iIi11i
  try :
   o0O0o0Oo = self . API_DOMAIN + '/api/v2/home/web'
   if 78 - 78: Oo0Ooo - o0oOOo0O0Ooo / OoOoOO00
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = None )
   Ii1IOo0o0 = json . loads ( Oooo . text )
   if 10 - 10: iII111i + Oo0Ooo * I1ii11iIi11i + iIii1I11I1II1 / I1Ii111 / I1ii11iIi11i
   for O0OOO0OOoO0O in Ii1IOo0o0 :
    O00Oo000ooO0 = { }
    O00Oo000ooO0 [ 'mediatype' ] = 'episode'
    if 42 - 42: I1IiiI
    if str ( O0OOO0OOoO0O [ 'type' ] ) == '3' :
     if 38 - 38: OOooOOo + II111iiii % ooOoO0o % OoOoOO00 - Ii1I / OoooooooOO
     oOOoo0000O0o0 = ''
     for II1III in O0OOO0OOoO0O [ 'data' ] [ 'list' ] :
      II = '[%s] %s vs %s\n<%s>\n\n' % ( II1III [ 'gameDesc' ] [ 'roundName' ] , II1III [ 'gameDesc' ] [ 'homeNameShort' ] , II1III [ 'gameDesc' ] [ 'awayNameShort' ] , II1III [ 'gameDesc' ] [ 'beginDate' ] )
      oOOoo0000O0o0 += II
      if 28 - 28: iII111i . iII111i % iIii1I11I1II1 * iIii1I11I1II1 . o0oOOo0O0Ooo / iII111i
     Ii1iIiii1 = {
 'title' : O0OOO0OOoO0O [ 'title' ]
 , 'logo' : O0OOO0OOoO0O [ 'logo' ]
 , 'reagueId' : str ( O0OOO0OOoO0O [ 'destId' ] )
 , 'subGame' : oOOoo0000O0o0
 , 'info' : O00Oo000ooO0
 }
     if 27 - 27: OoO0O00 + ooOoO0o - i1IIi
     ii11i1 . append ( Ii1iIiii1 )
     if 69 - 69: IiII - O0 % I1ii11iIi11i + i11iIiiIii . OoOoOO00 / OoO0O00
     if str ( O0OOO0OOoO0O [ 'destId' ] ) == '13' : III1i1i11i = True
     if 79 - 79: O0 * i11iIiiIii - IiII / IiII
     if 48 - 48: O0
     if 93 - 93: i11iIiiIii - I1IiiI * I1ii11iIi11i * I11i % O0 + OoooooooOO
   if III1i1i11i == False :
    O00Oo000ooO0 = { 'mediatype' : 'episode' }
    Ii1iIiii1 = {
 'title' : 'UFC'
 , 'logo' : 'https://cdn.spotvnow.co.kr/src/upload/image/20200928/a643c7cf1c285fb0b4469c07d4c09c28.png'
 , 'reagueId' : '13'
 , 'subGame' : ''
 , 'info' : O00Oo000ooO0
 }
    ii11i1 . append ( Ii1iIiii1 )
    if 25 - 25: IiII + Ii1I / ooOoO0o . o0oOOo0O0Ooo % O0 * OoO0O00
  except Exception as Ooooo :
   print ( Ooooo )
   if 84 - 84: ooOoO0o % Ii1I + i11iIiiIii
  return ii11i1
  if 28 - 28: Oo0Ooo + OoO0O00 * OOooOOo % oO0o . I11i % O0
  if 16 - 16: I11i - iIii1I11I1II1 / I1IiiI . II111iiii + iIii1I11I1II1
 def GetPopularGroupList ( self ) :
  ii11i1 = [ ]
  if 19 - 19: OoO0O00 - Oo0Ooo . O0
  try :
   o0O0o0Oo = self . API_DOMAIN + '/api/v2/home/web'
   if 60 - 60: II111iiii + Oo0Ooo
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = None )
   Ii1IOo0o0 = json . loads ( Oooo . text )
   if 9 - 9: ooOoO0o * OoooooooOO - iIii1I11I1II1 + OoOoOO00 / OoO0O00 . OoO0O00
   for O0OOO0OOoO0O in Ii1IOo0o0 :
    O00Oo000ooO0 = { }
    O00Oo000ooO0 [ 'mediatype' ] = 'episode'
    if 49 - 49: II111iiii
    if str ( O0OOO0OOoO0O [ 'type' ] ) == '1' and str ( O0OOO0OOoO0O [ 'destId' ] ) == '4' :
     if 25 - 25: OoooooooOO - I1IiiI . I1IiiI * oO0o
     for II1III in O0OOO0OOoO0O [ 'data' ] [ 'list' ] :
      if 81 - 81: iII111i + IiII
      O00Oo000ooO0 = { }
      O00Oo000ooO0 [ 'mediatype' ] = 'video'
      if 98 - 98: I1IiiI
      o00o0 = II1III [ 'title' ]
      II1I = II1III [ 'id' ]
      II1I1I1Ii = II1III [ 'vtype' ]
      OOOOoO00o0O = II1III [ 'imgUrl' ]
      I1I1I1IIi1III = II1III [ 'vtypeId' ]
      if 5 - 5: Oo0Ooo % ooOoO0o % i11iIiiIii + o0oOOo0O0Ooo / I1ii11iIi11i - I1ii11iIi11i
      O00Oo000ooO0 [ 'duration' ] = int ( II1III [ 'duration' ] / 1000 )
      if 45 - 45: I1ii11iIi11i % I1IiiI - i11iIiiIii
      if 11 - 11: iIii1I11I1II1 * iIii1I11I1II1 * I1IiiI
      Ii1iIiii1 = {
 'vodTitle' : o00o0
 , 'vodId' : II1I
 , 'vodType' : II1I1I1Ii
 , 'thumbnail' : OOOOoO00o0O
 , 'info' : O00Oo000ooO0
 , 'vtypeId' : str ( I1I1I1IIi1III )
      }
      if 46 - 46: OoOoOO00 + OoO0O00
      ii11i1 . append ( Ii1iIiii1 )
      if 70 - 70: iII111i / iIii1I11I1II1
  except Exception as Ooooo :
   print ( Ooooo )
   if 85 - 85: OoooooooOO % i1IIi * OoooooooOO / I1ii11iIi11i
  return ii11i1
  if 96 - 96: OoooooooOO + oO0o
  if 44 - 44: oO0o
 def GetSeasonList ( self , leagueId ) :
  if 20 - 20: I11i + Ii1I / O0 % iIii1I11I1II1
  if 88 - 88: OoOoOO00 / II111iiii
  if 87 - 87: I1ii11iIi11i - I1ii11iIi11i - iII111i + oO0o
  if 82 - 82: oO0o / iIii1I11I1II1 . I1IiiI . OOooOOo / o0oOOo0O0Ooo
  if 42 - 42: Oo0Ooo
  ii11i1 = [ ]
  II1IIiiIiI = i1II1I1Iii1 = ''
  if 30 - 30: OoooooooOO - OoOoOO00
  if 75 - 75: iIii1I11I1II1 - Ii1I . Oo0Ooo % i11iIiiIii % I11i
  try :
   o0O0o0Oo = self . API_DOMAIN + '/api/v2/game/league/' + leagueId
   if 55 - 55: iII111i . II111iiii % OoO0O00 * iII111i + ooOoO0o + Ii1I
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = None )
   Ii1IOo0o0 = json . loads ( Oooo . text )
   if 24 - 24: Oo0Ooo - oO0o % iIii1I11I1II1 . i1IIi / O0
   II1IIiiIiI = Ii1IOo0o0 [ 'name' ]
   i1II1I1Iii1 = str ( Ii1IOo0o0 [ 'gameTypeId' ] )
   if 36 - 36: I1IiiI - I11i
  except Exception as Ooooo :
   print ( Ooooo )
   return ii11i1
   if 29 - 29: ooOoO0o * OOooOOo
   if 10 - 10: I1Ii111 % IiII * IiII . I11i / Ii1I % OOooOOo
  if i1II1I1Iii1 == '2' :
   if 49 - 49: OoO0O00 / oO0o + O0 * o0oOOo0O0Ooo
   try :
    o0O0o0Oo = self . API_DOMAIN + '/api/v2/year/' + leagueId
    if 28 - 28: ooOoO0o + i11iIiiIii / I11i % OoOoOO00 % Oo0Ooo - O0
    Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = None )
    Ii1IOo0o0 = json . loads ( Oooo . text )
    if 54 - 54: i1IIi + II111iiii
    for O0OOO0OOoO0O in Ii1IOo0o0 :
     O00Oo000ooO0 = { }
     O00Oo000ooO0 [ 'mediatype' ] = 'episode'
     if 83 - 83: I1ii11iIi11i - I1IiiI + OOooOOo
     Ii1iIiii1 = {
 'reagueName' : II1IIiiIiI
 , 'gameTypeId' : i1II1I1Iii1
 , 'seasonName' : str ( O0OOO0OOoO0O )
 , 'seasonId' : str ( O0OOO0OOoO0O )
 , 'info' : O00Oo000ooO0
 }
     if 5 - 5: Ii1I
     ii11i1 . append ( Ii1iIiii1 )
     if 46 - 46: IiII
   except Exception as Ooooo :
    print ( Ooooo )
    return [ ]
    if 45 - 45: ooOoO0o
  else :
   if 21 - 21: oO0o . I1Ii111 . OOooOOo / Oo0Ooo / I1Ii111
   try :
    o0O0o0Oo = self . API_DOMAIN + '/api/v2/season/' + leagueId
    if 17 - 17: OOooOOo / OOooOOo / I11i
    Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = None )
    Ii1IOo0o0 = json . loads ( Oooo . text )
    if 1 - 1: i1IIi . i11iIiiIii % OOooOOo
    for O0OOO0OOoO0O in Ii1IOo0o0 :
     O00Oo000ooO0 = { }
     O00Oo000ooO0 [ 'mediatype' ] = 'episode'
     if 82 - 82: iIii1I11I1II1 + Oo0Ooo . iIii1I11I1II1 % IiII / Ii1I . Ii1I
     Ii1iIiii1 = {
 'reagueName' : II1IIiiIiI
 , 'gameTypeId' : i1II1I1Iii1
 , 'seasonName' : O0OOO0OOoO0O [ 'name' ]
 , 'seasonId' : str ( O0OOO0OOoO0O [ 'id' ] )
 , 'info' : O00Oo000ooO0
 }
     if 14 - 14: o0oOOo0O0Ooo . OOooOOo . I11i + OoooooooOO - OOooOOo + IiII
     ii11i1 . append ( Ii1iIiii1 )
     if 9 - 9: Ii1I
   except Exception as Ooooo :
    print ( Ooooo )
    return [ ]
    if 59 - 59: I1IiiI * II111iiii . O0
    if 56 - 56: Ii1I - iII111i % I1IiiI - o0oOOo0O0Ooo
    if 51 - 51: O0 / ooOoO0o * iIii1I11I1II1 + I1ii11iIi11i + o0oOOo0O0Ooo
  return ii11i1
  if 98 - 98: iIii1I11I1II1 * I1ii11iIi11i * OOooOOo + ooOoO0o % i11iIiiIii % O0
  if 27 - 27: O0
 def GetGameList ( self , gameTypeId , leagueId , seasonId , page_int ) :
  ii11i1 = [ ]
  OOO0oOOoo = False
  if 52 - 52: o0oOOo0O0Ooo % Oo0Ooo
  try :
   o0O0o0Oo = self . API_DOMAIN + '/api/v2/vod/league/detail'
   if 64 - 64: O0 % I11i % O0 * OoO0O00 . oO0o + I1IiiI
   if 75 - 75: I11i . OoooooooOO % o0oOOo0O0Ooo * I11i % OoooooooOO
   I11i1 = { 'gameType' : gameTypeId
 , 'leagueId' : leagueId
 , 'seasonId' : seasonId if gameTypeId != '2' else ''
 , 'teamId' : ''
 , 'roundId' : ''
 , 'year' : '' if gameTypeId != '2' else seasonId
 , 'pageNo' : str ( page_int )
 }
   if 28 - 28: I11i
   if 58 - 58: OoOoOO00
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = I11i1 , headers = None , cookies = None )
   Ii1IOo0o0 = json . loads ( Oooo . text )
   if 37 - 37: Oo0Ooo - iIii1I11I1II1 / I1ii11iIi11i
   if 73 - 73: i11iIiiIii - IiII
   if 25 - 25: OoooooooOO + IiII * I1ii11iIi11i
   OO = Ii1IOo0o0 [ 'list' ]
   if 92 - 92: I1IiiI + I11i + O0 / o0oOOo0O0Ooo + I1Ii111
   for I1iIi1iIiiIiI in OO :
    for O0OOO0OOoO0O in I1iIi1iIiiIiI [ 'list' ] :
     if 47 - 47: Ii1I + I1Ii111 / i1IIi % i11iIiiIii
     O00Oo000ooO0 = { }
     O00Oo000ooO0 [ 'mediatype' ] = 'video'
     if 42 - 42: iII111i + IiII
     if O0OOO0OOoO0O [ 'gameDesc' ] [ 'title' ] == None or O0OOO0OOoO0O [ 'gameDesc' ] [ 'title' ] == '' :
      oo0O0O00 = '%s vs %s' % ( O0OOO0OOoO0O [ 'gameDesc' ] [ 'homeNameShort' ] , O0OOO0OOoO0O [ 'gameDesc' ] [ 'awayNameShort' ] )
     else :
      oo0O0O00 = O0OOO0OOoO0O [ 'gameDesc' ] [ 'title' ]
      if 96 - 96: OOooOOo
     OOo = O0OOO0OOoO0O [ 'gameDesc' ] [ 'beginDate' ]
     i1i11I1I1iii1 = O0OOO0OOoO0O [ 'gameDesc' ] [ 'id' ]
     if 8 - 8: ooOoO0o + II111iiii / iII111i / I11i
     if 74 - 74: O0 / i1IIi
     if 78 - 78: OoooooooOO . OoO0O00 + ooOoO0o - i1IIi
     ii1 = O0OOO0OOoO0O [ 'gameDesc' ] [ 'leagueNameFull' ]
     O0iII1 = O0OOO0OOoO0O [ 'gameDesc' ] [ 'seasonName' ]
     IIII1i = O0OOO0OOoO0O [ 'gameDesc' ] [ 'roundName' ]
     Ii1IIIIi1ii1I = O0OOO0OOoO0O [ 'gameDesc' ] [ 'homeName' ]
     IiiIiI1Ii1i = O0OOO0OOoO0O [ 'gameDesc' ] [ 'awayName' ]
     i1iIi = O0OOO0OOoO0O [ 'gameDesc' ] [ 'homeScore' ]
     iiiii1II = O0OOO0OOoO0O [ 'gameDesc' ] [ 'awayScore' ]
     O0OOO0OOooo00 = '%s\n - %s (%s)\n - %s\n\nhome : %s (Score %s)\n\naway : %s (Score %s)' % ( ii1 , O0iII1 , IIII1i , OOo , Ii1IIIIi1ii1I , i1iIi , IiiIiI1Ii1i , iiiii1II )
     O00Oo000ooO0 [ 'plot' ] = O0OOO0OOooo00
     if 6 - 6: Ii1I - ooOoO0o * OOooOOo . iII111i / O0 * ooOoO0o
     if 22 - 22: Oo0Ooo % iII111i * I1ii11iIi11i / OOooOOo % i11iIiiIii * I11i
     Oo00OoOo = O0OOO0OOoO0O [ 'replayVod' ] [ 'count' ]
     ii1ii111 = O0OOO0OOoO0O [ 'highlightVod' ] [ 'count' ]
     i11111I1I = O0OOO0OOoO0O [ 'vods' ] [ 'count' ]
     if 11 - 11: OoooooooOO . I1Ii111
     OOOOoO00o0O = ''
     if 80 - 80: OoooooooOO - OOooOOo * Ii1I * I1ii11iIi11i / I1IiiI / OOooOOo
     I1I11iI11iI1i = Oo00OoOo + ii1ii111 + i11111I1I
     if 75 - 75: OoooooooOO * IiII
     if I1I11iI11iI1i == 0 :
      if 9 - 9: IiII - II111iiii + O0 / iIii1I11I1II1 / i11iIiiIii
      if gameTypeId == '2' :
       oo0O0O00 = '----- %s -----' % ( O0iII1 )
       OOo = ''
       if 39 - 39: IiII * Oo0Ooo + iIii1I11I1II1 - IiII + OOooOOo
      else :
       oo0O0O00 += ' - 관련영상 없음'
       O00Oo000ooO0 [ 'plot' ] += '\n\n ** 관련영상 없음 **'
       if 69 - 69: O0
     else :
      if Oo00OoOo != 0 :
       OOOOoO00o0O = O0OOO0OOoO0O [ 'replayVod' ] [ 'list' ] [ 0 ] [ 'imgUrl' ]
      elif ii1ii111 != 0 :
       OOOOoO00o0O = O0OOO0OOoO0O [ 'highlightVod' ] [ 'list' ] [ 0 ] [ 'imgUrl' ]
      else :
       OOOOoO00o0O = O0OOO0OOoO0O [ 'vods' ] [ 'list' ] [ 0 ] [ 'imgUrl' ]
       if 85 - 85: ooOoO0o / O0
     Ii1iIiii1 = {
 'gameTitle' : oo0O0O00
 , 'gameId' : i1i11I1I1iii1
 , 'beginDate' : OOo [ : 11 ]
 , 'thumbnail' : OOOOoO00o0O
 , 'info' : O00Oo000ooO0
 , 'leaguenm' : ii1
     , 'seasonnm' : O0iII1
 , 'roundnm' : IIII1i
 , 'totVodCnt' : I1I11iI11iI1i
     }
     if 18 - 18: o0oOOo0O0Ooo % O0 * I1ii11iIi11i
     ii11i1 . append ( Ii1iIiii1 )
     if 62 - 62: I1Ii111 . IiII . OoooooooOO
   if gameTypeId == '2' :
    if Ii1IOo0o0 [ 'count' ] > page_int * self . GAMELIST_LIMIT : OOO0oOOoo = True
   else :
    if Ii1IOo0o0 [ 'list' ] [ 0 ] [ 'count' ] > page_int * self . GAMELIST_LIMIT : OOO0oOOoo = True
    if 11 - 11: OOooOOo / I11i
  except Exception as Ooooo :
   print ( Ooooo )
   if 73 - 73: i1IIi / i11iIiiIii
  return ii11i1 , OOO0oOOoo
  if 58 - 58: Oo0Ooo . II111iiii + oO0o - i11iIiiIii / II111iiii / O0
  if 85 - 85: OoOoOO00 + OOooOOo
  if 10 - 10: IiII / OoO0O00 + OoOoOO00 / i1IIi
  if 27 - 27: Ii1I
 def GetGameVodList ( self , gameId ) :
  ii11i1 = [ ]
  oO0OO0 = ''
  if 82 - 82: IiII - IiII + OoOoOO00
  try :
   o0O0o0Oo = self . API_DOMAIN + '/api/v2/vod/game'
   if 8 - 8: o0oOOo0O0Ooo % iII111i * oO0o % Ii1I . ooOoO0o / ooOoO0o
   I11i1 = { 'gameId' : gameId
 , 'pageItem' : '1000'
 }
   if 81 - 81: OoO0O00
   if 99 - 99: oO0o * II111iiii * I1Ii111
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = I11i1 , headers = None , cookies = None )
   Ii1IOo0o0 = json . loads ( Oooo . text )
   if 92 - 92: Oo0Ooo
   if 40 - 40: OoOoOO00 / IiII
   I1iIi1iIiiIiI = Ii1IOo0o0 [ 'list' ]
   if 79 - 79: OoO0O00 - iIii1I11I1II1 + Ii1I - I1Ii111
   for O0OOO0OOoO0O in I1iIi1iIiiIiI :
    O00Oo000ooO0 = { }
    O00Oo000ooO0 [ 'mediatype' ] = 'video'
    if 93 - 93: II111iiii . I1IiiI - Oo0Ooo + OoOoOO00
    o00o0 = O0OOO0OOoO0O [ 'title' ]
    II1I = O0OOO0OOoO0O [ 'id' ]
    II1I1I1Ii = O0OOO0OOoO0O [ 'vtype' ]
    OOOOoO00o0O = O0OOO0OOoO0O [ 'imgUrl' ]
    I1I1I1IIi1III = O0OOO0OOoO0O [ 'vtypeId' ]
    if 61 - 61: II111iiii
    O00Oo000ooO0 [ 'duration' ] = int ( O0OOO0OOoO0O [ 'duration' ] / 1000 )
    if 15 - 15: i11iIiiIii % I1IiiI * I11i / I1Ii111
    if 90 - 90: iII111i
    Ii1iIiii1 = {
 'vodTitle' : o00o0
 , 'vodId' : II1I
 , 'vodType' : II1I1I1Ii
 , 'thumbnail' : OOOOoO00o0O
 , 'info' : O00Oo000ooO0
 , 'vtypeId' : str ( I1I1I1IIi1III )
    }
    if 31 - 31: OOooOOo + O0
    ii11i1 . append ( Ii1iIiii1 )
    if 87 - 87: ooOoO0o
  except Exception as Ooooo :
   print ( Ooooo )
   if 45 - 45: OoO0O00 / OoooooooOO - iII111i / Ii1I % IiII
  return ii11i1
  if 83 - 83: I1IiiI . iIii1I11I1II1 - IiII * i11iIiiIii
  if 20 - 20: i1IIi * I1Ii111 + II111iiii % o0oOOo0O0Ooo % oO0o
 def GetReplay_UrlId ( self , replayId , vtypeId ) :
  iIi1II = O0O = ''
  I1iIiI11I1 = ''
  if 27 - 27: Ii1I . i11iIiiIii % I1Ii111
  try :
   o0O0o0Oo = self . API_DOMAIN + '/api/v2/vod/' + replayId
   if 65 - 65: II111iiii . I1IiiI % oO0o * OoO0O00
   Oooo = self . callRequestCookies ( 'Get' , o0O0o0Oo , payload = None , params = None , headers = None , cookies = None )
   Ii1IOo0o0 = json . loads ( Oooo . text )
   if 38 - 38: OoOoOO00 / iII111i % Oo0Ooo
   iIi1II = Ii1IOo0o0 [ 'clipId' ]
   O0O = Ii1IOo0o0 [ 'videoId' ]
   if 11 - 11: iII111i - oO0o + II111iiii - iIii1I11I1II1
   I1iIiI11I1 = iIi1II
   if self . CheckSubEnd ( ) or vtypeId != '1' : I1iIiI11I1 = O0O
   if 7 - 7: IiII - I11i / II111iiii * Ii1I . iII111i * iII111i
  except Exception as Ooooo :
   print ( Ooooo )
   if 61 - 61: I11i % ooOoO0o - OoO0O00 / Oo0Ooo
  return I1iIiI11I1
  if 4 - 4: OoooooooOO - i1IIi % Ii1I - OOooOOo * o0oOOo0O0Ooo
  if 85 - 85: OoooooooOO * iIii1I11I1II1 . iII111i / OoooooooOO % I1IiiI % O0
  if 36 - 36: Ii1I / II111iiii / IiII / IiII + I1ii11iIi11i
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
