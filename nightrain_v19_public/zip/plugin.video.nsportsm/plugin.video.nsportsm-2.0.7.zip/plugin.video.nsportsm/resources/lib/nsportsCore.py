__author__="NightRain"
omliSeDnUcgBvaFwMpjrQLKJTzOYVX=object
omliSeDnUcgBvaFwMpjrQLKJTzOYVs=None
omliSeDnUcgBvaFwMpjrQLKJTzOYVR=False
omliSeDnUcgBvaFwMpjrQLKJTzOYVu=True
omliSeDnUcgBvaFwMpjrQLKJTzOYVG=len
omliSeDnUcgBvaFwMpjrQLKJTzOYVh=print
omliSeDnUcgBvaFwMpjrQLKJTzOYVt=Exception
omliSeDnUcgBvaFwMpjrQLKJTzOYVf=int
omliSeDnUcgBvaFwMpjrQLKJTzOYVk=str
omliSeDnUcgBvaFwMpjrQLKJTzOYVH=type
omliSeDnUcgBvaFwMpjrQLKJTzOYVC=dict
import urllib
import re
import json
import requests
import datetime
from bs4 import BeautifulSoup
class omliSeDnUcgBvaFwMpjrQLKJTzOYbd(omliSeDnUcgBvaFwMpjrQLKJTzOYVX):
 def __init__(omliSeDnUcgBvaFwMpjrQLKJTzOYbI):
  omliSeDnUcgBvaFwMpjrQLKJTzOYbI.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  omliSeDnUcgBvaFwMpjrQLKJTzOYbI.DEFAULT_HEADER ={'user-agent':omliSeDnUcgBvaFwMpjrQLKJTzOYbI.USER_AGENT}
  omliSeDnUcgBvaFwMpjrQLKJTzOYbI.genres=[{'groupnm':'야구','category':['kbaseball','wbaseball']},{'groupnm':'축구','category':['kfootball','wfootball']},{'groupnm':'배구','category':['kvolleyball']},{'groupnm':'골프','category':['golf']},{'groupnm':'농구','category':['kbasketball']},{'groupnm':'기타','category':['others']},]
 def callRequestCookies(omliSeDnUcgBvaFwMpjrQLKJTzOYbI,jobtype,omliSeDnUcgBvaFwMpjrQLKJTzOYbX,payload=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,params=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,headers=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,cookies=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,redirects=omliSeDnUcgBvaFwMpjrQLKJTzOYVR):
  omliSeDnUcgBvaFwMpjrQLKJTzOYbV=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.DEFAULT_HEADER
  if headers:omliSeDnUcgBvaFwMpjrQLKJTzOYbV.update(headers)
  if jobtype=='Get':
   omliSeDnUcgBvaFwMpjrQLKJTzOYbx=requests.get(omliSeDnUcgBvaFwMpjrQLKJTzOYbX,params=params,headers=omliSeDnUcgBvaFwMpjrQLKJTzOYbV,cookies=cookies,allow_redirects=redirects)
  else:
   omliSeDnUcgBvaFwMpjrQLKJTzOYbx=requests.post(omliSeDnUcgBvaFwMpjrQLKJTzOYbX,data=payload,params=params,headers=omliSeDnUcgBvaFwMpjrQLKJTzOYbV,cookies=cookies,allow_redirects=redirects)
  return omliSeDnUcgBvaFwMpjrQLKJTzOYbx
 def Get_Now_Datetime(omliSeDnUcgBvaFwMpjrQLKJTzOYbI):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def make_viewdate(omliSeDnUcgBvaFwMpjrQLKJTzOYbI,dtype='1'):
  omliSeDnUcgBvaFwMpjrQLKJTzOYbP =omliSeDnUcgBvaFwMpjrQLKJTzOYbI.Get_Now_Datetime()
  omliSeDnUcgBvaFwMpjrQLKJTzOYby =omliSeDnUcgBvaFwMpjrQLKJTzOYbP+datetime.timedelta(days=-1)
  omliSeDnUcgBvaFwMpjrQLKJTzOYbA =omliSeDnUcgBvaFwMpjrQLKJTzOYbP+datetime.timedelta(days=1)
  if dtype=='1':
   omliSeDnUcgBvaFwMpjrQLKJTzOYbW=[omliSeDnUcgBvaFwMpjrQLKJTzOYbP.strftime('%Y%m%d'),]
  elif dtype=='2':
   omliSeDnUcgBvaFwMpjrQLKJTzOYbW=[omliSeDnUcgBvaFwMpjrQLKJTzOYbP.strftime('%Y%m%d'),omliSeDnUcgBvaFwMpjrQLKJTzOYbA.strftime('%Y%m%d'),]
  elif dtype=='3':
   omliSeDnUcgBvaFwMpjrQLKJTzOYbW=[omliSeDnUcgBvaFwMpjrQLKJTzOYbP.strftime('%Y%m%d'),omliSeDnUcgBvaFwMpjrQLKJTzOYby.strftime('%Y%m%d'),omliSeDnUcgBvaFwMpjrQLKJTzOYbA.strftime('%Y%m%d'),]
  return omliSeDnUcgBvaFwMpjrQLKJTzOYbW
 def Get_Category_List(omliSeDnUcgBvaFwMpjrQLKJTzOYbI):
  omliSeDnUcgBvaFwMpjrQLKJTzOYbE=[]
  omliSeDnUcgBvaFwMpjrQLKJTzOYbN=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.make_viewdate(dtype='1')
  try:
   omliSeDnUcgBvaFwMpjrQLKJTzOYbX='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   omliSeDnUcgBvaFwMpjrQLKJTzOYbs=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.callRequestCookies('Get',omliSeDnUcgBvaFwMpjrQLKJTzOYbX,payload=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,params=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,headers=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,cookies=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,redirects=omliSeDnUcgBvaFwMpjrQLKJTzOYVu)
   if omliSeDnUcgBvaFwMpjrQLKJTzOYbs.status_code!=200:return[]
   omliSeDnUcgBvaFwMpjrQLKJTzOYbR=json.loads(omliSeDnUcgBvaFwMpjrQLKJTzOYbs.text)
   omliSeDnUcgBvaFwMpjrQLKJTzOYbu=omliSeDnUcgBvaFwMpjrQLKJTzOYbR.get('gameList')
   omliSeDnUcgBvaFwMpjrQLKJTzOYbG=[]
   for omliSeDnUcgBvaFwMpjrQLKJTzOYbh in omliSeDnUcgBvaFwMpjrQLKJTzOYbI.genres:
    omliSeDnUcgBvaFwMpjrQLKJTzOYbt =omliSeDnUcgBvaFwMpjrQLKJTzOYbh.get('groupnm')
    omliSeDnUcgBvaFwMpjrQLKJTzOYbf=[]
    omliSeDnUcgBvaFwMpjrQLKJTzOYbk ='N'
    if omliSeDnUcgBvaFwMpjrQLKJTzOYVG(omliSeDnUcgBvaFwMpjrQLKJTzOYbG)!=0:
     omliSeDnUcgBvaFwMpjrQLKJTzOYbu =omliSeDnUcgBvaFwMpjrQLKJTzOYbG
     omliSeDnUcgBvaFwMpjrQLKJTzOYbG=[]
    for omliSeDnUcgBvaFwMpjrQLKJTzOYbH in omliSeDnUcgBvaFwMpjrQLKJTzOYbu:
     omliSeDnUcgBvaFwMpjrQLKJTzOYbC=omliSeDnUcgBvaFwMpjrQLKJTzOYbH.get('upperCategoryId')
     omliSeDnUcgBvaFwMpjrQLKJTzOYdb =omliSeDnUcgBvaFwMpjrQLKJTzOYbH.get('statusCode')
     omliSeDnUcgBvaFwMpjrQLKJTzOYdI =omliSeDnUcgBvaFwMpjrQLKJTzOYbH.get('isOnAirTv')
     omliSeDnUcgBvaFwMpjrQLKJTzOYdV =omliSeDnUcgBvaFwMpjrQLKJTzOYbH.get('gameId')
     if omliSeDnUcgBvaFwMpjrQLKJTzOYbC in('esports'):continue
     if omliSeDnUcgBvaFwMpjrQLKJTzOYdb in('RESULT'):continue
     if omliSeDnUcgBvaFwMpjrQLKJTzOYdV[:8]not in omliSeDnUcgBvaFwMpjrQLKJTzOYbN and omliSeDnUcgBvaFwMpjrQLKJTzOYdI!='Y':continue
     if omliSeDnUcgBvaFwMpjrQLKJTzOYbC in omliSeDnUcgBvaFwMpjrQLKJTzOYbh.get('category'):
      if omliSeDnUcgBvaFwMpjrQLKJTzOYbC not in omliSeDnUcgBvaFwMpjrQLKJTzOYbf:omliSeDnUcgBvaFwMpjrQLKJTzOYbf.append(omliSeDnUcgBvaFwMpjrQLKJTzOYbC)
      if omliSeDnUcgBvaFwMpjrQLKJTzOYdI=='Y':omliSeDnUcgBvaFwMpjrQLKJTzOYbk='Y'
     else:
      omliSeDnUcgBvaFwMpjrQLKJTzOYbG.append(omliSeDnUcgBvaFwMpjrQLKJTzOYbH)
    if omliSeDnUcgBvaFwMpjrQLKJTzOYVG(omliSeDnUcgBvaFwMpjrQLKJTzOYbf)>0:
     omliSeDnUcgBvaFwMpjrQLKJTzOYdx={'groupnm':omliSeDnUcgBvaFwMpjrQLKJTzOYbt,'onairyn':omliSeDnUcgBvaFwMpjrQLKJTzOYbk,'category':omliSeDnUcgBvaFwMpjrQLKJTzOYbf,}
     omliSeDnUcgBvaFwMpjrQLKJTzOYbE.append(omliSeDnUcgBvaFwMpjrQLKJTzOYdx)
    if omliSeDnUcgBvaFwMpjrQLKJTzOYVG(omliSeDnUcgBvaFwMpjrQLKJTzOYbG)==0:break
   omliSeDnUcgBvaFwMpjrQLKJTzOYbt ='-'
   omliSeDnUcgBvaFwMpjrQLKJTzOYbf=[]
   omliSeDnUcgBvaFwMpjrQLKJTzOYbk ='N'
   for omliSeDnUcgBvaFwMpjrQLKJTzOYbH in omliSeDnUcgBvaFwMpjrQLKJTzOYbG:
    omliSeDnUcgBvaFwMpjrQLKJTzOYbC=omliSeDnUcgBvaFwMpjrQLKJTzOYbH.get('upperCategoryId')
    omliSeDnUcgBvaFwMpjrQLKJTzOYdI =omliSeDnUcgBvaFwMpjrQLKJTzOYbH.get('isOnAirTv')
    if omliSeDnUcgBvaFwMpjrQLKJTzOYbC not in omliSeDnUcgBvaFwMpjrQLKJTzOYbf:omliSeDnUcgBvaFwMpjrQLKJTzOYbf.append(omliSeDnUcgBvaFwMpjrQLKJTzOYbC)
    if omliSeDnUcgBvaFwMpjrQLKJTzOYdI=='Y':omliSeDnUcgBvaFwMpjrQLKJTzOYbk='Y'
   if omliSeDnUcgBvaFwMpjrQLKJTzOYVG(omliSeDnUcgBvaFwMpjrQLKJTzOYbf)>0:
    omliSeDnUcgBvaFwMpjrQLKJTzOYdx={'groupnm':'-','onairyn':omliSeDnUcgBvaFwMpjrQLKJTzOYbk,'category':omliSeDnUcgBvaFwMpjrQLKJTzOYbf,}
    omliSeDnUcgBvaFwMpjrQLKJTzOYbE.append(omliSeDnUcgBvaFwMpjrQLKJTzOYdx)
    omliSeDnUcgBvaFwMpjrQLKJTzOYVh(omliSeDnUcgBvaFwMpjrQLKJTzOYbt,omliSeDnUcgBvaFwMpjrQLKJTzOYbk,omliSeDnUcgBvaFwMpjrQLKJTzOYbf)
  except omliSeDnUcgBvaFwMpjrQLKJTzOYVt as exception:
   omliSeDnUcgBvaFwMpjrQLKJTzOYVh(exception)
   return[]
  return omliSeDnUcgBvaFwMpjrQLKJTzOYbE
 def Get_Game_List(omliSeDnUcgBvaFwMpjrQLKJTzOYbI,category):
  omliSeDnUcgBvaFwMpjrQLKJTzOYdq=category.split(',')
  omliSeDnUcgBvaFwMpjrQLKJTzOYbE =[]
  omliSeDnUcgBvaFwMpjrQLKJTzOYdP =[]
  omliSeDnUcgBvaFwMpjrQLKJTzOYdy =[]
  omliSeDnUcgBvaFwMpjrQLKJTzOYbN=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.make_viewdate()
  try:
   omliSeDnUcgBvaFwMpjrQLKJTzOYbX='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   omliSeDnUcgBvaFwMpjrQLKJTzOYbs=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.callRequestCookies('Get',omliSeDnUcgBvaFwMpjrQLKJTzOYbX,payload=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,params=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,headers=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,cookies=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,redirects=omliSeDnUcgBvaFwMpjrQLKJTzOYVu)
   if omliSeDnUcgBvaFwMpjrQLKJTzOYbs.status_code!=200:return[]
   omliSeDnUcgBvaFwMpjrQLKJTzOYbR=json.loads(omliSeDnUcgBvaFwMpjrQLKJTzOYbs.text)
   omliSeDnUcgBvaFwMpjrQLKJTzOYbu=omliSeDnUcgBvaFwMpjrQLKJTzOYbR.get('gameList')
   for omliSeDnUcgBvaFwMpjrQLKJTzOYbH in omliSeDnUcgBvaFwMpjrQLKJTzOYbu:
    omliSeDnUcgBvaFwMpjrQLKJTzOYdV =omliSeDnUcgBvaFwMpjrQLKJTzOYbH.get('gameId')
    omliSeDnUcgBvaFwMpjrQLKJTzOYbC=omliSeDnUcgBvaFwMpjrQLKJTzOYbH.get('upperCategoryId')
    omliSeDnUcgBvaFwMpjrQLKJTzOYdA =omliSeDnUcgBvaFwMpjrQLKJTzOYbH.get('categoryId')
    omliSeDnUcgBvaFwMpjrQLKJTzOYdb =omliSeDnUcgBvaFwMpjrQLKJTzOYbH.get('statusCode')
    omliSeDnUcgBvaFwMpjrQLKJTzOYdW =omliSeDnUcgBvaFwMpjrQLKJTzOYbH.get('statusInfo')
    omliSeDnUcgBvaFwMpjrQLKJTzOYdI =omliSeDnUcgBvaFwMpjrQLKJTzOYbH.get('isOnAirTv')
    if omliSeDnUcgBvaFwMpjrQLKJTzOYbC in('esports'):continue
    if omliSeDnUcgBvaFwMpjrQLKJTzOYdb in('RESULT'):continue
    if omliSeDnUcgBvaFwMpjrQLKJTzOYbC not in omliSeDnUcgBvaFwMpjrQLKJTzOYdq:continue
    if omliSeDnUcgBvaFwMpjrQLKJTzOYdV[:8]not in omliSeDnUcgBvaFwMpjrQLKJTzOYbN and omliSeDnUcgBvaFwMpjrQLKJTzOYdI!='Y':continue
    omliSeDnUcgBvaFwMpjrQLKJTzOYdE=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.Get_Game_liveInfo(omliSeDnUcgBvaFwMpjrQLKJTzOYdV)
    if omliSeDnUcgBvaFwMpjrQLKJTzOYdE.get('chId')==omliSeDnUcgBvaFwMpjrQLKJTzOYVs:continue
    omliSeDnUcgBvaFwMpjrQLKJTzOYdx={'gameId':omliSeDnUcgBvaFwMpjrQLKJTzOYdV,'upperCategoryId':omliSeDnUcgBvaFwMpjrQLKJTzOYbC,'categoryId':omliSeDnUcgBvaFwMpjrQLKJTzOYdA,'statusCode':omliSeDnUcgBvaFwMpjrQLKJTzOYdb,'statusInfo':omliSeDnUcgBvaFwMpjrQLKJTzOYdW,'isOnAirTv':omliSeDnUcgBvaFwMpjrQLKJTzOYdI,'chId':omliSeDnUcgBvaFwMpjrQLKJTzOYdE.get('chId'),'title':omliSeDnUcgBvaFwMpjrQLKJTzOYdE.get('title'),'starttime':omliSeDnUcgBvaFwMpjrQLKJTzOYdE.get('starttime'),'endTime':omliSeDnUcgBvaFwMpjrQLKJTzOYdE.get('endTime'),'maxBitrate':omliSeDnUcgBvaFwMpjrQLKJTzOYdE.get('maxBitrate'),}
    if omliSeDnUcgBvaFwMpjrQLKJTzOYdI=='Y':
     omliSeDnUcgBvaFwMpjrQLKJTzOYdP.append(omliSeDnUcgBvaFwMpjrQLKJTzOYdx)
    else:
     omliSeDnUcgBvaFwMpjrQLKJTzOYdy.append(omliSeDnUcgBvaFwMpjrQLKJTzOYdx)
   omliSeDnUcgBvaFwMpjrQLKJTzOYbE=omliSeDnUcgBvaFwMpjrQLKJTzOYdP+omliSeDnUcgBvaFwMpjrQLKJTzOYdy
  except omliSeDnUcgBvaFwMpjrQLKJTzOYVt as exception:
   omliSeDnUcgBvaFwMpjrQLKJTzOYVh(exception)
   return[]
  return omliSeDnUcgBvaFwMpjrQLKJTzOYbE
 def Get_Game_liveInfo(omliSeDnUcgBvaFwMpjrQLKJTzOYbI,omliSeDnUcgBvaFwMpjrQLKJTzOYdV):
  omliSeDnUcgBvaFwMpjrQLKJTzOYdN={}
  try:
   omliSeDnUcgBvaFwMpjrQLKJTzOYbX='https://apis.naver.com/pcLive/livePlatform/liveInfo2'
   omliSeDnUcgBvaFwMpjrQLKJTzOYdX={'env':'pc','inclAudCh':'0','svcId':'12002','svcLiveId':omliSeDnUcgBvaFwMpjrQLKJTzOYdV,}
   omliSeDnUcgBvaFwMpjrQLKJTzOYbs=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.callRequestCookies('Get',omliSeDnUcgBvaFwMpjrQLKJTzOYbX,payload=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,params=omliSeDnUcgBvaFwMpjrQLKJTzOYdX,headers=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,cookies=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,redirects=omliSeDnUcgBvaFwMpjrQLKJTzOYVu)
   if omliSeDnUcgBvaFwMpjrQLKJTzOYbs.status_code!=200:return[]
   omliSeDnUcgBvaFwMpjrQLKJTzOYVh(omliSeDnUcgBvaFwMpjrQLKJTzOYbs.text)
   omliSeDnUcgBvaFwMpjrQLKJTzOYbR=json.loads(omliSeDnUcgBvaFwMpjrQLKJTzOYbs.text)
   omliSeDnUcgBvaFwMpjrQLKJTzOYds =omliSeDnUcgBvaFwMpjrQLKJTzOYbR.get('chList')[0].get('chId')
   omliSeDnUcgBvaFwMpjrQLKJTzOYdR=omliSeDnUcgBvaFwMpjrQLKJTzOYbR.get('chConf').get(omliSeDnUcgBvaFwMpjrQLKJTzOYds)[0].get('id')
   omliSeDnUcgBvaFwMpjrQLKJTzOYdu =omliSeDnUcgBvaFwMpjrQLKJTzOYbR.get('program')
   omliSeDnUcgBvaFwMpjrQLKJTzOYdG =omliSeDnUcgBvaFwMpjrQLKJTzOYdu.get('title')
   omliSeDnUcgBvaFwMpjrQLKJTzOYdh =omliSeDnUcgBvaFwMpjrQLKJTzOYdu.get('startTime')
   omliSeDnUcgBvaFwMpjrQLKJTzOYdt =omliSeDnUcgBvaFwMpjrQLKJTzOYdu.get('endTime')
   if omliSeDnUcgBvaFwMpjrQLKJTzOYdh!=omliSeDnUcgBvaFwMpjrQLKJTzOYVs:
    omliSeDnUcgBvaFwMpjrQLKJTzOYdh =datetime.datetime.fromtimestamp(omliSeDnUcgBvaFwMpjrQLKJTzOYVf(omliSeDnUcgBvaFwMpjrQLKJTzOYdh),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:omliSeDnUcgBvaFwMpjrQLKJTzOYdh=''
   if omliSeDnUcgBvaFwMpjrQLKJTzOYdt!=omliSeDnUcgBvaFwMpjrQLKJTzOYVs:
    omliSeDnUcgBvaFwMpjrQLKJTzOYdt =datetime.datetime.fromtimestamp(omliSeDnUcgBvaFwMpjrQLKJTzOYVf(omliSeDnUcgBvaFwMpjrQLKJTzOYdt),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:omliSeDnUcgBvaFwMpjrQLKJTzOYdt=''
   omliSeDnUcgBvaFwMpjrQLKJTzOYdN={'chId':omliSeDnUcgBvaFwMpjrQLKJTzOYds,'title':omliSeDnUcgBvaFwMpjrQLKJTzOYdG,'starttime':omliSeDnUcgBvaFwMpjrQLKJTzOYdh,'endTime':omliSeDnUcgBvaFwMpjrQLKJTzOYdt,'maxBitrate':omliSeDnUcgBvaFwMpjrQLKJTzOYdR,}
  except omliSeDnUcgBvaFwMpjrQLKJTzOYVt as exception:
   omliSeDnUcgBvaFwMpjrQLKJTzOYVh(exception)
   return{}
  return omliSeDnUcgBvaFwMpjrQLKJTzOYdN
 def GetStreamingURL(omliSeDnUcgBvaFwMpjrQLKJTzOYbI,channelId,setBitrate,omliSeDnUcgBvaFwMpjrQLKJTzOYdR):
  omliSeDnUcgBvaFwMpjrQLKJTzOYdf=''
  if omliSeDnUcgBvaFwMpjrQLKJTzOYVf(setBitrate)>omliSeDnUcgBvaFwMpjrQLKJTzOYVf(omliSeDnUcgBvaFwMpjrQLKJTzOYdR):
   omliSeDnUcgBvaFwMpjrQLKJTzOYdk=omliSeDnUcgBvaFwMpjrQLKJTzOYdR
  else:
   omliSeDnUcgBvaFwMpjrQLKJTzOYdk=setBitrate
  try:
   omliSeDnUcgBvaFwMpjrQLKJTzOYbX='https://apis.naver.com/pcLive/livePlatform/sUrl'
   omliSeDnUcgBvaFwMpjrQLKJTzOYdX={'ch':channelId,'q':omliSeDnUcgBvaFwMpjrQLKJTzOYdk,'p':'hls','cc':'KR','env':'pc',}
   omliSeDnUcgBvaFwMpjrQLKJTzOYbs=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.callRequestCookies('Get',omliSeDnUcgBvaFwMpjrQLKJTzOYbX,payload=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,params=omliSeDnUcgBvaFwMpjrQLKJTzOYdX,headers=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,cookies=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,redirects=omliSeDnUcgBvaFwMpjrQLKJTzOYVu)
   if omliSeDnUcgBvaFwMpjrQLKJTzOYbs.status_code!=200:return ''
   omliSeDnUcgBvaFwMpjrQLKJTzOYbR=json.loads(omliSeDnUcgBvaFwMpjrQLKJTzOYbs.text)
   omliSeDnUcgBvaFwMpjrQLKJTzOYdf=omliSeDnUcgBvaFwMpjrQLKJTzOYbR.get('secUrl')
  except omliSeDnUcgBvaFwMpjrQLKJTzOYVt as exception:
   omliSeDnUcgBvaFwMpjrQLKJTzOYVh(exception)
   return ''
  return omliSeDnUcgBvaFwMpjrQLKJTzOYdf
 def GetStreamingRtmp_bak(omliSeDnUcgBvaFwMpjrQLKJTzOYbI,omliSeDnUcgBvaFwMpjrQLKJTzOYdV,setBitrate):
  omliSeDnUcgBvaFwMpjrQLKJTzOYdf=''
  try:
   omliSeDnUcgBvaFwMpjrQLKJTzOYbX='https://api-gw.sports.naver.com/schedule/%s/lives'%(omliSeDnUcgBvaFwMpjrQLKJTzOYdV)
   omliSeDnUcgBvaFwMpjrQLKJTzOYbs=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.callRequestCookies('Get',omliSeDnUcgBvaFwMpjrQLKJTzOYbX,payload=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,params=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,headers=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,cookies=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,redirects=omliSeDnUcgBvaFwMpjrQLKJTzOYVu)
   if omliSeDnUcgBvaFwMpjrQLKJTzOYbs.status_code!=200:return ''
   omliSeDnUcgBvaFwMpjrQLKJTzOYbR=json.loads(omliSeDnUcgBvaFwMpjrQLKJTzOYbs.text)
   omliSeDnUcgBvaFwMpjrQLKJTzOYdH=omliSeDnUcgBvaFwMpjrQLKJTzOYbR.get('result').get('lives')[0]
   if setBitrate=='5000':
    omliSeDnUcgBvaFwMpjrQLKJTzOYdf=omliSeDnUcgBvaFwMpjrQLKJTzOYdH.get('rtmpPlayUrl1080')
   else:
    omliSeDnUcgBvaFwMpjrQLKJTzOYdf=omliSeDnUcgBvaFwMpjrQLKJTzOYdH.get('rtmpPlayUrl720')
  except omliSeDnUcgBvaFwMpjrQLKJTzOYVt as exception:
   omliSeDnUcgBvaFwMpjrQLKJTzOYVh(exception)
   return ''
  return omliSeDnUcgBvaFwMpjrQLKJTzOYdf
 def GetStreamingRtmp(omliSeDnUcgBvaFwMpjrQLKJTzOYbI,omliSeDnUcgBvaFwMpjrQLKJTzOYdV,setBitrate):
  omliSeDnUcgBvaFwMpjrQLKJTzOYdf=''
  try:
   omliSeDnUcgBvaFwMpjrQLKJTzOYbX='https://api-gw.sports.naver.com/schedule/%s/lives/first'%(omliSeDnUcgBvaFwMpjrQLKJTzOYdV)
   omliSeDnUcgBvaFwMpjrQLKJTzOYdC={'fields':'basic,sportslive'}
   omliSeDnUcgBvaFwMpjrQLKJTzOYbs=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.callRequestCookies('Get',omliSeDnUcgBvaFwMpjrQLKJTzOYbX,payload=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,params=omliSeDnUcgBvaFwMpjrQLKJTzOYdC,headers=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,cookies=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,redirects=omliSeDnUcgBvaFwMpjrQLKJTzOYVu)
   if omliSeDnUcgBvaFwMpjrQLKJTzOYbs.status_code!=200:return ''
   omliSeDnUcgBvaFwMpjrQLKJTzOYbR=json.loads(omliSeDnUcgBvaFwMpjrQLKJTzOYbs.text)
   omliSeDnUcgBvaFwMpjrQLKJTzOYIb=omliSeDnUcgBvaFwMpjrQLKJTzOYbR.get('result').get('liveId')
   if omliSeDnUcgBvaFwMpjrQLKJTzOYIb=='':return ''
  except omliSeDnUcgBvaFwMpjrQLKJTzOYVt as exception:
   omliSeDnUcgBvaFwMpjrQLKJTzOYVh(exception)
   return ''
  try:
   omliSeDnUcgBvaFwMpjrQLKJTzOYbX='https://proxy-gateway.sports.naver.com/livecloud/lives/%s/playback'%(omliSeDnUcgBvaFwMpjrQLKJTzOYIb)
   omliSeDnUcgBvaFwMpjrQLKJTzOYdC={'countryCode':'KR','devt':'HTML5_PC','timeMachine':'true','p2p':'true','includeThumbnail':'true',}
   omliSeDnUcgBvaFwMpjrQLKJTzOYbs=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.callRequestCookies('Get',omliSeDnUcgBvaFwMpjrQLKJTzOYbX,payload=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,params=omliSeDnUcgBvaFwMpjrQLKJTzOYdC,headers=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,cookies=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,redirects=omliSeDnUcgBvaFwMpjrQLKJTzOYVu)
   if omliSeDnUcgBvaFwMpjrQLKJTzOYbs.status_code!=200:return ''
   omliSeDnUcgBvaFwMpjrQLKJTzOYbR=json.loads(omliSeDnUcgBvaFwMpjrQLKJTzOYbs.text)
   omliSeDnUcgBvaFwMpjrQLKJTzOYdH=omliSeDnUcgBvaFwMpjrQLKJTzOYbR.get('media')
   if omliSeDnUcgBvaFwMpjrQLKJTzOYdH=='':return ''
   omliSeDnUcgBvaFwMpjrQLKJTzOYdf=omliSeDnUcgBvaFwMpjrQLKJTzOYdH[0].get('path')
  except omliSeDnUcgBvaFwMpjrQLKJTzOYVt as exception:
   omliSeDnUcgBvaFwMpjrQLKJTzOYVh(exception)
   return ''
  return omliSeDnUcgBvaFwMpjrQLKJTzOYdf
 def Get_BSList_Json(omliSeDnUcgBvaFwMpjrQLKJTzOYbI):
  omliSeDnUcgBvaFwMpjrQLKJTzOYbE=[]
  omliSeDnUcgBvaFwMpjrQLKJTzOYbN =omliSeDnUcgBvaFwMpjrQLKJTzOYbI.make_viewdate(dtype='2')
  try:
   omliSeDnUcgBvaFwMpjrQLKJTzOYbX='https://sports.news.naver.com/scoreboard/index.nhn'
   for omliSeDnUcgBvaFwMpjrQLKJTzOYId in omliSeDnUcgBvaFwMpjrQLKJTzOYbN:
    omliSeDnUcgBvaFwMpjrQLKJTzOYIV=[]
    omliSeDnUcgBvaFwMpjrQLKJTzOYdX={'date':omliSeDnUcgBvaFwMpjrQLKJTzOYId}
    omliSeDnUcgBvaFwMpjrQLKJTzOYbs=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.callRequestCookies('Get',omliSeDnUcgBvaFwMpjrQLKJTzOYbX,payload=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,params=omliSeDnUcgBvaFwMpjrQLKJTzOYdX,headers=omliSeDnUcgBvaFwMpjrQLKJTzOYVs,cookies=omliSeDnUcgBvaFwMpjrQLKJTzOYVs)
    if omliSeDnUcgBvaFwMpjrQLKJTzOYbs.status_code!=200:return[]
    omliSeDnUcgBvaFwMpjrQLKJTzOYIx=BeautifulSoup(omliSeDnUcgBvaFwMpjrQLKJTzOYbs.text,'html.parser')
    omliSeDnUcgBvaFwMpjrQLKJTzOYIx=omliSeDnUcgBvaFwMpjrQLKJTzOYIx.select_one('#content > div > table > tbody')
    omliSeDnUcgBvaFwMpjrQLKJTzOYIq='%s-%s-%s'%(omliSeDnUcgBvaFwMpjrQLKJTzOYId[:4],omliSeDnUcgBvaFwMpjrQLKJTzOYId[4:6],omliSeDnUcgBvaFwMpjrQLKJTzOYId[-2:])
    omliSeDnUcgBvaFwMpjrQLKJTzOYIP=omliSeDnUcgBvaFwMpjrQLKJTzOYIx.find('tr')
    omliSeDnUcgBvaFwMpjrQLKJTzOYIV+=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.Get_NowTag_List(omliSeDnUcgBvaFwMpjrQLKJTzOYIP,omliSeDnUcgBvaFwMpjrQLKJTzOYIq)
    for omliSeDnUcgBvaFwMpjrQLKJTzOYIP in omliSeDnUcgBvaFwMpjrQLKJTzOYIP.next_siblings:
     if omliSeDnUcgBvaFwMpjrQLKJTzOYVk(omliSeDnUcgBvaFwMpjrQLKJTzOYVH(omliSeDnUcgBvaFwMpjrQLKJTzOYIP))!="<class 'bs4.element.Tag'>":continue
     omliSeDnUcgBvaFwMpjrQLKJTzOYIV+=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.Get_NowTag_List(omliSeDnUcgBvaFwMpjrQLKJTzOYIP,omliSeDnUcgBvaFwMpjrQLKJTzOYIq)
    omliSeDnUcgBvaFwMpjrQLKJTzOYIy=''
    omliSeDnUcgBvaFwMpjrQLKJTzOYIA=''
    omliSeDnUcgBvaFwMpjrQLKJTzOYIW =''
    omliSeDnUcgBvaFwMpjrQLKJTzOYIE=''
    omliSeDnUcgBvaFwMpjrQLKJTzOYIN=''
    omliSeDnUcgBvaFwMpjrQLKJTzOYIX=''
    for omliSeDnUcgBvaFwMpjrQLKJTzOYIs in omliSeDnUcgBvaFwMpjrQLKJTzOYIV:
     if omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('class')=='game' :omliSeDnUcgBvaFwMpjrQLKJTzOYIy =omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('cont')
     if omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('class')=='time' :omliSeDnUcgBvaFwMpjrQLKJTzOYIA =omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('cont')
     if omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('class')=='ing' :omliSeDnUcgBvaFwMpjrQLKJTzOYIW =omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('cont')
     if omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('class')=='title':omliSeDnUcgBvaFwMpjrQLKJTzOYIE =omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('cont')
     if omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('class')=='gameId':omliSeDnUcgBvaFwMpjrQLKJTzOYIN=omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('cont')
     if omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('class')=='relay':
      omliSeDnUcgBvaFwMpjrQLKJTzOYIR='-'
      for omliSeDnUcgBvaFwMpjrQLKJTzOYIu in omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('cont'):
       if omliSeDnUcgBvaFwMpjrQLKJTzOYIu.get('live')in['Y','N']:
        omliSeDnUcgBvaFwMpjrQLKJTzOYIR=omliSeDnUcgBvaFwMpjrQLKJTzOYIu.get('live')
     if omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('class')=='place':
      if omliSeDnUcgBvaFwMpjrQLKJTzOYIR not in['Y','N']:continue
      omliSeDnUcgBvaFwMpjrQLKJTzOYIX=omliSeDnUcgBvaFwMpjrQLKJTzOYIs.get('cont')
      omliSeDnUcgBvaFwMpjrQLKJTzOYIG={'category':omliSeDnUcgBvaFwMpjrQLKJTzOYIy,'time':omliSeDnUcgBvaFwMpjrQLKJTzOYIA,'title':' '.join(omliSeDnUcgBvaFwMpjrQLKJTzOYIE.split()),'gameId':omliSeDnUcgBvaFwMpjrQLKJTzOYIN,'live':omliSeDnUcgBvaFwMpjrQLKJTzOYIR,'ing':omliSeDnUcgBvaFwMpjrQLKJTzOYIW,'place':omliSeDnUcgBvaFwMpjrQLKJTzOYIX,}
      omliSeDnUcgBvaFwMpjrQLKJTzOYbE.append(omliSeDnUcgBvaFwMpjrQLKJTzOYIG)
  except omliSeDnUcgBvaFwMpjrQLKJTzOYVt as exception:
   omliSeDnUcgBvaFwMpjrQLKJTzOYVh(exception)
   return[]
  return omliSeDnUcgBvaFwMpjrQLKJTzOYbE
 def Get_NowTag_List(omliSeDnUcgBvaFwMpjrQLKJTzOYbI,omliSeDnUcgBvaFwMpjrQLKJTzOYIP,omliSeDnUcgBvaFwMpjrQLKJTzOYIq):
  omliSeDnUcgBvaFwMpjrQLKJTzOYIV=[]
  omliSeDnUcgBvaFwMpjrQLKJTzOYIh=omliSeDnUcgBvaFwMpjrQLKJTzOYIP.find_all('td')
  for omliSeDnUcgBvaFwMpjrQLKJTzOYIt in omliSeDnUcgBvaFwMpjrQLKJTzOYIh:
   omliSeDnUcgBvaFwMpjrQLKJTzOYIf=omliSeDnUcgBvaFwMpjrQLKJTzOYIt.get('class')[0]
   if omliSeDnUcgBvaFwMpjrQLKJTzOYIf=='game':
    omliSeDnUcgBvaFwMpjrQLKJTzOYIk={'class':'game','cont':omliSeDnUcgBvaFwMpjrQLKJTzOYIt.text,}
    omliSeDnUcgBvaFwMpjrQLKJTzOYIV.append(omliSeDnUcgBvaFwMpjrQLKJTzOYIk)
   elif omliSeDnUcgBvaFwMpjrQLKJTzOYIf=='time':
    omliSeDnUcgBvaFwMpjrQLKJTzOYIk={'class':'time','cont':omliSeDnUcgBvaFwMpjrQLKJTzOYIq+' '+omliSeDnUcgBvaFwMpjrQLKJTzOYIt.text,}
    omliSeDnUcgBvaFwMpjrQLKJTzOYIV.append(omliSeDnUcgBvaFwMpjrQLKJTzOYIk)
   elif omliSeDnUcgBvaFwMpjrQLKJTzOYIf=='gameinfo':
    pass
   elif omliSeDnUcgBvaFwMpjrQLKJTzOYIf=='state':
    omliSeDnUcgBvaFwMpjrQLKJTzOYIH=omliSeDnUcgBvaFwMpjrQLKJTzOYIt.find_all('img')
    omliSeDnUcgBvaFwMpjrQLKJTzOYIC='-'
    for omliSeDnUcgBvaFwMpjrQLKJTzOYVb in omliSeDnUcgBvaFwMpjrQLKJTzOYIH:
     if omliSeDnUcgBvaFwMpjrQLKJTzOYVb.get('alt')=='진행중':
      omliSeDnUcgBvaFwMpjrQLKJTzOYIC='Y'
    omliSeDnUcgBvaFwMpjrQLKJTzOYIk={'class':'ing','cont':omliSeDnUcgBvaFwMpjrQLKJTzOYIC,}
    omliSeDnUcgBvaFwMpjrQLKJTzOYIV.append(omliSeDnUcgBvaFwMpjrQLKJTzOYIk)
    omliSeDnUcgBvaFwMpjrQLKJTzOYIk={'class':'title','cont':omliSeDnUcgBvaFwMpjrQLKJTzOYIt.text,}
    omliSeDnUcgBvaFwMpjrQLKJTzOYIV.append(omliSeDnUcgBvaFwMpjrQLKJTzOYIk)
   elif omliSeDnUcgBvaFwMpjrQLKJTzOYIf=='relay':
    omliSeDnUcgBvaFwMpjrQLKJTzOYVd=''
    omliSeDnUcgBvaFwMpjrQLKJTzOYVI=omliSeDnUcgBvaFwMpjrQLKJTzOYIt.find('a')
    if omliSeDnUcgBvaFwMpjrQLKJTzOYVI:
     omliSeDnUcgBvaFwMpjrQLKJTzOYVx=omliSeDnUcgBvaFwMpjrQLKJTzOYVI.get('href')
     if "'" in omliSeDnUcgBvaFwMpjrQLKJTzOYVx:omliSeDnUcgBvaFwMpjrQLKJTzOYVx=omliSeDnUcgBvaFwMpjrQLKJTzOYVx.split("'")[1]
     if omliSeDnUcgBvaFwMpjrQLKJTzOYVx.startswith('/game/'):
      omliSeDnUcgBvaFwMpjrQLKJTzOYVd=omliSeDnUcgBvaFwMpjrQLKJTzOYVx.split('/')[2]
     elif omliSeDnUcgBvaFwMpjrQLKJTzOYVx.startswith('/')and '?' in omliSeDnUcgBvaFwMpjrQLKJTzOYVx:
      omliSeDnUcgBvaFwMpjrQLKJTzOYVq=urllib.parse.urlsplit(omliSeDnUcgBvaFwMpjrQLKJTzOYVx)
      omliSeDnUcgBvaFwMpjrQLKJTzOYVq=omliSeDnUcgBvaFwMpjrQLKJTzOYVC(urllib.parse.parse_qsl(omliSeDnUcgBvaFwMpjrQLKJTzOYVq.query))
      omliSeDnUcgBvaFwMpjrQLKJTzOYVd=omliSeDnUcgBvaFwMpjrQLKJTzOYVq.get('gameId') 
    omliSeDnUcgBvaFwMpjrQLKJTzOYIk={'class':'gameId','cont':omliSeDnUcgBvaFwMpjrQLKJTzOYVd,}
    omliSeDnUcgBvaFwMpjrQLKJTzOYIV.append(omliSeDnUcgBvaFwMpjrQLKJTzOYIk)
    omliSeDnUcgBvaFwMpjrQLKJTzOYIH=omliSeDnUcgBvaFwMpjrQLKJTzOYIt.find_all('img')
    omliSeDnUcgBvaFwMpjrQLKJTzOYVP=[]
    for omliSeDnUcgBvaFwMpjrQLKJTzOYVb in omliSeDnUcgBvaFwMpjrQLKJTzOYIH:
     omliSeDnUcgBvaFwMpjrQLKJTzOYVy =omliSeDnUcgBvaFwMpjrQLKJTzOYVb.get('alt')
     omliSeDnUcgBvaFwMpjrQLKJTzOYVA=omliSeDnUcgBvaFwMpjrQLKJTzOYVb.get('onclick')
     omliSeDnUcgBvaFwMpjrQLKJTzOYVW ='-'
     if omliSeDnUcgBvaFwMpjrQLKJTzOYVA:
      if "'scb.tv'" in omliSeDnUcgBvaFwMpjrQLKJTzOYVA:omliSeDnUcgBvaFwMpjrQLKJTzOYVW='Y'
      elif "'scb.tv_off'" in omliSeDnUcgBvaFwMpjrQLKJTzOYVA:omliSeDnUcgBvaFwMpjrQLKJTzOYVW='N'
     omliSeDnUcgBvaFwMpjrQLKJTzOYVP.append({'alt':omliSeDnUcgBvaFwMpjrQLKJTzOYVy,'live':omliSeDnUcgBvaFwMpjrQLKJTzOYVW})
    omliSeDnUcgBvaFwMpjrQLKJTzOYIk={'class':'relay','cont':omliSeDnUcgBvaFwMpjrQLKJTzOYVP,}
    omliSeDnUcgBvaFwMpjrQLKJTzOYIV.append(omliSeDnUcgBvaFwMpjrQLKJTzOYIk)
   elif omliSeDnUcgBvaFwMpjrQLKJTzOYIf=='place':
    omliSeDnUcgBvaFwMpjrQLKJTzOYIk={'class':'place','cont':omliSeDnUcgBvaFwMpjrQLKJTzOYIt.text,}
    omliSeDnUcgBvaFwMpjrQLKJTzOYIV.append(omliSeDnUcgBvaFwMpjrQLKJTzOYIk)
   else:
    omliSeDnUcgBvaFwMpjrQLKJTzOYVh(omliSeDnUcgBvaFwMpjrQLKJTzOYIf)
  return omliSeDnUcgBvaFwMpjrQLKJTzOYIV
 def Get_Category_BSjson(omliSeDnUcgBvaFwMpjrQLKJTzOYbI):
  omliSeDnUcgBvaFwMpjrQLKJTzOYbE=[]
  omliSeDnUcgBvaFwMpjrQLKJTzOYbu=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.Get_BSList_Json()
  omliSeDnUcgBvaFwMpjrQLKJTzOYVE=[]
  for omliSeDnUcgBvaFwMpjrQLKJTzOYVN in omliSeDnUcgBvaFwMpjrQLKJTzOYbu:
   if omliSeDnUcgBvaFwMpjrQLKJTzOYVN.get('category')not in omliSeDnUcgBvaFwMpjrQLKJTzOYVE:
    omliSeDnUcgBvaFwMpjrQLKJTzOYVE.append(omliSeDnUcgBvaFwMpjrQLKJTzOYVN.get('category'))
  for omliSeDnUcgBvaFwMpjrQLKJTzOYbf in omliSeDnUcgBvaFwMpjrQLKJTzOYVE:
   omliSeDnUcgBvaFwMpjrQLKJTzOYbk='N'
   for omliSeDnUcgBvaFwMpjrQLKJTzOYVN in omliSeDnUcgBvaFwMpjrQLKJTzOYbu:
    if omliSeDnUcgBvaFwMpjrQLKJTzOYbf==omliSeDnUcgBvaFwMpjrQLKJTzOYVN.get('category')and omliSeDnUcgBvaFwMpjrQLKJTzOYVN.get('live')=='Y':
     omliSeDnUcgBvaFwMpjrQLKJTzOYbk='Y'
   omliSeDnUcgBvaFwMpjrQLKJTzOYbG={'category':omliSeDnUcgBvaFwMpjrQLKJTzOYbf,'live':omliSeDnUcgBvaFwMpjrQLKJTzOYbk,}
   omliSeDnUcgBvaFwMpjrQLKJTzOYbE.append(omliSeDnUcgBvaFwMpjrQLKJTzOYbG)
  return omliSeDnUcgBvaFwMpjrQLKJTzOYbE
 def Get_Gamelist_BSjson(omliSeDnUcgBvaFwMpjrQLKJTzOYbI,category):
  omliSeDnUcgBvaFwMpjrQLKJTzOYbE =[]
  omliSeDnUcgBvaFwMpjrQLKJTzOYbu=omliSeDnUcgBvaFwMpjrQLKJTzOYbI.Get_BSList_Json()
  for omliSeDnUcgBvaFwMpjrQLKJTzOYVN in omliSeDnUcgBvaFwMpjrQLKJTzOYbu:
   if omliSeDnUcgBvaFwMpjrQLKJTzOYVN.get('category')==category:
    omliSeDnUcgBvaFwMpjrQLKJTzOYbE.append(omliSeDnUcgBvaFwMpjrQLKJTzOYVN)
  return omliSeDnUcgBvaFwMpjrQLKJTzOYbE
# Created by pyminifier (https://github.com/liftoff/pyminifier)
