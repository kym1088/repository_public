__author__="NightRain"
vNlofExzwBOULAMYanJyTIRtQeKXrW=object
vNlofExzwBOULAMYanJyTIRtQeKXrk=None
vNlofExzwBOULAMYanJyTIRtQeKXrj=True
vNlofExzwBOULAMYanJyTIRtQeKXrF=False
vNlofExzwBOULAMYanJyTIRtQeKXrS=type
vNlofExzwBOULAMYanJyTIRtQeKXrG=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
vNlofExzwBOULAMYanJyTIRtQeKXpr=[{'title':'경기별 보기','mode':'BS_CATEGORY'},{'title':'-----------------','mode':'XXX'},{'title':'** 경기중이 아닐때에는 시청이 제한될수 있음 **','mode':'XXX'},]
vNlofExzwBOULAMYanJyTIRtQeKXpb=[{'chId':'ad1','title':'Spotv1'},{'chId':'ad2','title':'KBS N Sports'},{'chId':'ad3','title':'SBS Sports'},{'chId':'ad4','title':'MBC Sports'},{'chId':'ad5','title':'Spotv2'},]
from nsportsCore import*
class vNlofExzwBOULAMYanJyTIRtQeKXpd(vNlofExzwBOULAMYanJyTIRtQeKXrW):
 def __init__(vNlofExzwBOULAMYanJyTIRtQeKXpP,vNlofExzwBOULAMYanJyTIRtQeKXpD,vNlofExzwBOULAMYanJyTIRtQeKXpg,vNlofExzwBOULAMYanJyTIRtQeKXpW):
  vNlofExzwBOULAMYanJyTIRtQeKXpP._addon_url =vNlofExzwBOULAMYanJyTIRtQeKXpD
  vNlofExzwBOULAMYanJyTIRtQeKXpP._addon_handle=vNlofExzwBOULAMYanJyTIRtQeKXpg
  vNlofExzwBOULAMYanJyTIRtQeKXpP.main_params =vNlofExzwBOULAMYanJyTIRtQeKXpW
  vNlofExzwBOULAMYanJyTIRtQeKXpP.NsportsObj =omliSeDnUcgBvaFwMpjrQLKJTzOYbd() 
 def addon_noti(vNlofExzwBOULAMYanJyTIRtQeKXpP,sting):
  try:
   vNlofExzwBOULAMYanJyTIRtQeKXpj=xbmcgui.Dialog()
   vNlofExzwBOULAMYanJyTIRtQeKXpj.notification(__addonname__,sting)
  except:
   vNlofExzwBOULAMYanJyTIRtQeKXrk
 def addon_log(vNlofExzwBOULAMYanJyTIRtQeKXpP,string):
  try:
   vNlofExzwBOULAMYanJyTIRtQeKXpF=string.encode('utf-8','ignore')
  except:
   vNlofExzwBOULAMYanJyTIRtQeKXpF='addonException: addon_log'
  vNlofExzwBOULAMYanJyTIRtQeKXpS=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,vNlofExzwBOULAMYanJyTIRtQeKXpF),level=vNlofExzwBOULAMYanJyTIRtQeKXpS)
 def get_Bitrate_sel(vNlofExzwBOULAMYanJyTIRtQeKXpP):
  vNlofExzwBOULAMYanJyTIRtQeKXpG={'0':'5000','1':'2000','2':'800',}
  return vNlofExzwBOULAMYanJyTIRtQeKXpG.get(__addon__.getSetting('selected_quality'))
 def add_dir(vNlofExzwBOULAMYanJyTIRtQeKXpP,label,sublabel='',img='',infoLabels=vNlofExzwBOULAMYanJyTIRtQeKXrk,isFolder=vNlofExzwBOULAMYanJyTIRtQeKXrj,params='',isLink=vNlofExzwBOULAMYanJyTIRtQeKXrF,ContextMenu=vNlofExzwBOULAMYanJyTIRtQeKXrk):
  vNlofExzwBOULAMYanJyTIRtQeKXpH='%s?%s'%(vNlofExzwBOULAMYanJyTIRtQeKXpP._addon_url,urllib.parse.urlencode(params))
  if sublabel:vNlofExzwBOULAMYanJyTIRtQeKXpV='%s < %s >'%(label,sublabel)
  else: vNlofExzwBOULAMYanJyTIRtQeKXpV=label
  if not img:img='DefaultFolder.png'
  vNlofExzwBOULAMYanJyTIRtQeKXpc=xbmcgui.ListItem(vNlofExzwBOULAMYanJyTIRtQeKXpV)
  if vNlofExzwBOULAMYanJyTIRtQeKXrS(img)==vNlofExzwBOULAMYanJyTIRtQeKXrG:
   vNlofExzwBOULAMYanJyTIRtQeKXpc.setArt(img)
  else:
   vNlofExzwBOULAMYanJyTIRtQeKXpc.setArt({'thumb':img,'poster':img})
  if infoLabels:vNlofExzwBOULAMYanJyTIRtQeKXpc.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   vNlofExzwBOULAMYanJyTIRtQeKXpc.setProperty('IsPlayable','true')
  if ContextMenu:vNlofExzwBOULAMYanJyTIRtQeKXpc.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(vNlofExzwBOULAMYanJyTIRtQeKXpP._addon_handle,vNlofExzwBOULAMYanJyTIRtQeKXpH,vNlofExzwBOULAMYanJyTIRtQeKXpc,isFolder)
 def dp_Main_List(vNlofExzwBOULAMYanJyTIRtQeKXpP,args):
  for vNlofExzwBOULAMYanJyTIRtQeKXpq in vNlofExzwBOULAMYanJyTIRtQeKXpr:
   vNlofExzwBOULAMYanJyTIRtQeKXpV=vNlofExzwBOULAMYanJyTIRtQeKXpq.get('title')
   vNlofExzwBOULAMYanJyTIRtQeKXpi=''
   vNlofExzwBOULAMYanJyTIRtQeKXph={'mode':vNlofExzwBOULAMYanJyTIRtQeKXpq.get('mode'),}
   if vNlofExzwBOULAMYanJyTIRtQeKXpq.get('mode')in['XXX']:
    vNlofExzwBOULAMYanJyTIRtQeKXpu=vNlofExzwBOULAMYanJyTIRtQeKXrF
    vNlofExzwBOULAMYanJyTIRtQeKXps =vNlofExzwBOULAMYanJyTIRtQeKXrj
   else:
    vNlofExzwBOULAMYanJyTIRtQeKXpu=vNlofExzwBOULAMYanJyTIRtQeKXrj
    vNlofExzwBOULAMYanJyTIRtQeKXps =vNlofExzwBOULAMYanJyTIRtQeKXrF
   if 'icon' in vNlofExzwBOULAMYanJyTIRtQeKXpq:vNlofExzwBOULAMYanJyTIRtQeKXpi=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',vNlofExzwBOULAMYanJyTIRtQeKXpq.get('icon')) 
   vNlofExzwBOULAMYanJyTIRtQeKXpP.add_dir(vNlofExzwBOULAMYanJyTIRtQeKXpV,sublabel='',img=vNlofExzwBOULAMYanJyTIRtQeKXpi,infoLabels=vNlofExzwBOULAMYanJyTIRtQeKXrk,isFolder=vNlofExzwBOULAMYanJyTIRtQeKXpu,params=vNlofExzwBOULAMYanJyTIRtQeKXph,isLink=vNlofExzwBOULAMYanJyTIRtQeKXps)
  xbmcplugin.endOfDirectory(vNlofExzwBOULAMYanJyTIRtQeKXpP._addon_handle)
 def dp_Channel_List(vNlofExzwBOULAMYanJyTIRtQeKXpP,args):
  vNlofExzwBOULAMYanJyTIRtQeKXpm=vNlofExzwBOULAMYanJyTIRtQeKXpP.get_Bitrate_sel()
  for vNlofExzwBOULAMYanJyTIRtQeKXdp in vNlofExzwBOULAMYanJyTIRtQeKXpb:
   vNlofExzwBOULAMYanJyTIRtQeKXpV=vNlofExzwBOULAMYanJyTIRtQeKXdp.get('title')
   vNlofExzwBOULAMYanJyTIRtQeKXdr=vNlofExzwBOULAMYanJyTIRtQeKXdp.get('chId')
   vNlofExzwBOULAMYanJyTIRtQeKXdb={'mediatype':'episode','title':vNlofExzwBOULAMYanJyTIRtQeKXpV}
   vNlofExzwBOULAMYanJyTIRtQeKXph={'mode':'CLIVE','chId':vNlofExzwBOULAMYanJyTIRtQeKXdr,'maxBitrate':vNlofExzwBOULAMYanJyTIRtQeKXpm,}
   vNlofExzwBOULAMYanJyTIRtQeKXpP.add_dir(vNlofExzwBOULAMYanJyTIRtQeKXpV,sublabel='',img='',infoLabels=vNlofExzwBOULAMYanJyTIRtQeKXdb,isFolder=vNlofExzwBOULAMYanJyTIRtQeKXrF,params=vNlofExzwBOULAMYanJyTIRtQeKXph,isLink=vNlofExzwBOULAMYanJyTIRtQeKXrF)
  xbmcplugin.endOfDirectory(vNlofExzwBOULAMYanJyTIRtQeKXpP._addon_handle)
 def dp_Category_List(vNlofExzwBOULAMYanJyTIRtQeKXpP,args):
  vNlofExzwBOULAMYanJyTIRtQeKXdP=vNlofExzwBOULAMYanJyTIRtQeKXpP.NsportsObj.Get_Category_List()
  for vNlofExzwBOULAMYanJyTIRtQeKXdD in vNlofExzwBOULAMYanJyTIRtQeKXdP:
   vNlofExzwBOULAMYanJyTIRtQeKXdg =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('groupnm')
   vNlofExzwBOULAMYanJyTIRtQeKXdW =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('onairyn')
   vNlofExzwBOULAMYanJyTIRtQeKXdk=','.join(vNlofExzwBOULAMYanJyTIRtQeKXdD.get('category'))
   if vNlofExzwBOULAMYanJyTIRtQeKXdW=='Y':vNlofExzwBOULAMYanJyTIRtQeKXpC='중계중'
   else:vNlofExzwBOULAMYanJyTIRtQeKXpC=''
   vNlofExzwBOULAMYanJyTIRtQeKXph={'mode':'GAME_LIST','category':vNlofExzwBOULAMYanJyTIRtQeKXdk,}
   vNlofExzwBOULAMYanJyTIRtQeKXpP.add_dir(vNlofExzwBOULAMYanJyTIRtQeKXdg,sublabel=vNlofExzwBOULAMYanJyTIRtQeKXpC,img='',infoLabels=vNlofExzwBOULAMYanJyTIRtQeKXrk,isFolder=vNlofExzwBOULAMYanJyTIRtQeKXrj,params=vNlofExzwBOULAMYanJyTIRtQeKXph)
  xbmcplugin.endOfDirectory(vNlofExzwBOULAMYanJyTIRtQeKXpP._addon_handle,cacheToDisc=vNlofExzwBOULAMYanJyTIRtQeKXrF)
 def dp_Game_List(vNlofExzwBOULAMYanJyTIRtQeKXpP,args):
  vNlofExzwBOULAMYanJyTIRtQeKXdF=args.get('category')
  vNlofExzwBOULAMYanJyTIRtQeKXdP=vNlofExzwBOULAMYanJyTIRtQeKXpP.NsportsObj.Get_Game_List(vNlofExzwBOULAMYanJyTIRtQeKXdF)
  for vNlofExzwBOULAMYanJyTIRtQeKXdD in vNlofExzwBOULAMYanJyTIRtQeKXdP:
   vNlofExzwBOULAMYanJyTIRtQeKXdS =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('gameId')
   vNlofExzwBOULAMYanJyTIRtQeKXdG =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('upperCategoryId')
   vNlofExzwBOULAMYanJyTIRtQeKXdH =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('categoryId')
   vNlofExzwBOULAMYanJyTIRtQeKXdV =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('statusCode')
   vNlofExzwBOULAMYanJyTIRtQeKXdc =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('statusInfo')
   vNlofExzwBOULAMYanJyTIRtQeKXdq =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('isOnAirTv')
   vNlofExzwBOULAMYanJyTIRtQeKXdr =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('chId')
   vNlofExzwBOULAMYanJyTIRtQeKXpV =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('title')
   vNlofExzwBOULAMYanJyTIRtQeKXdi =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('starttime')
   vNlofExzwBOULAMYanJyTIRtQeKXdh =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('endTime')
   vNlofExzwBOULAMYanJyTIRtQeKXdu =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('maxBitrate')
   if vNlofExzwBOULAMYanJyTIRtQeKXpV=='':vNlofExzwBOULAMYanJyTIRtQeKXpV=vNlofExzwBOULAMYanJyTIRtQeKXdS
   if vNlofExzwBOULAMYanJyTIRtQeKXdq=='Y':
    vNlofExzwBOULAMYanJyTIRtQeKXds='방송중'
   else:
    if vNlofExzwBOULAMYanJyTIRtQeKXdc=='경기취소':
     vNlofExzwBOULAMYanJyTIRtQeKXds=vNlofExzwBOULAMYanJyTIRtQeKXdc
    else:
     vNlofExzwBOULAMYanJyTIRtQeKXds=''
   if vNlofExzwBOULAMYanJyTIRtQeKXdi=='':
    vNlofExzwBOULAMYanJyTIRtQeKXpC=vNlofExzwBOULAMYanJyTIRtQeKXds
   else:
    if vNlofExzwBOULAMYanJyTIRtQeKXds=='':
     vNlofExzwBOULAMYanJyTIRtQeKXpC=vNlofExzwBOULAMYanJyTIRtQeKXdi
    else:
     vNlofExzwBOULAMYanJyTIRtQeKXpC=vNlofExzwBOULAMYanJyTIRtQeKXdi+' - '+vNlofExzwBOULAMYanJyTIRtQeKXds
   vNlofExzwBOULAMYanJyTIRtQeKXdb={'mediatype':'episode','title':vNlofExzwBOULAMYanJyTIRtQeKXpV,'plot':'%s\n\n시작 : %s\n종료 : %s'%(vNlofExzwBOULAMYanJyTIRtQeKXpV,vNlofExzwBOULAMYanJyTIRtQeKXdi,vNlofExzwBOULAMYanJyTIRtQeKXdh)}
   vNlofExzwBOULAMYanJyTIRtQeKXph={'mode':'LIVE','chId':vNlofExzwBOULAMYanJyTIRtQeKXdr,'maxBitrate':vNlofExzwBOULAMYanJyTIRtQeKXdu,'gameId':vNlofExzwBOULAMYanJyTIRtQeKXdS,}
   vNlofExzwBOULAMYanJyTIRtQeKXpP.add_dir(vNlofExzwBOULAMYanJyTIRtQeKXpV,sublabel=vNlofExzwBOULAMYanJyTIRtQeKXpC,img='',infoLabels=vNlofExzwBOULAMYanJyTIRtQeKXdb,isFolder=vNlofExzwBOULAMYanJyTIRtQeKXrF,params=vNlofExzwBOULAMYanJyTIRtQeKXph)
  xbmcplugin.endOfDirectory(vNlofExzwBOULAMYanJyTIRtQeKXpP._addon_handle,cacheToDisc=vNlofExzwBOULAMYanJyTIRtQeKXrF)
 def dp_BsCategory_List(vNlofExzwBOULAMYanJyTIRtQeKXpP,args):
  vNlofExzwBOULAMYanJyTIRtQeKXdP=vNlofExzwBOULAMYanJyTIRtQeKXpP.NsportsObj.Get_Category_BSjson()
  for vNlofExzwBOULAMYanJyTIRtQeKXdD in vNlofExzwBOULAMYanJyTIRtQeKXdP:
   vNlofExzwBOULAMYanJyTIRtQeKXdk =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('category')
   vNlofExzwBOULAMYanJyTIRtQeKXdC =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('live')
   if vNlofExzwBOULAMYanJyTIRtQeKXdC=='Y':vNlofExzwBOULAMYanJyTIRtQeKXpC='중계중'
   else:vNlofExzwBOULAMYanJyTIRtQeKXpC=''
   vNlofExzwBOULAMYanJyTIRtQeKXph={'mode':'BS_GAME','category':vNlofExzwBOULAMYanJyTIRtQeKXdk,}
   vNlofExzwBOULAMYanJyTIRtQeKXpP.add_dir(vNlofExzwBOULAMYanJyTIRtQeKXdk,sublabel=vNlofExzwBOULAMYanJyTIRtQeKXpC,img='',infoLabels=vNlofExzwBOULAMYanJyTIRtQeKXrk,isFolder=vNlofExzwBOULAMYanJyTIRtQeKXrj,params=vNlofExzwBOULAMYanJyTIRtQeKXph)
  xbmcplugin.endOfDirectory(vNlofExzwBOULAMYanJyTIRtQeKXpP._addon_handle,cacheToDisc=vNlofExzwBOULAMYanJyTIRtQeKXrF)
 def dp_BsGame_List(vNlofExzwBOULAMYanJyTIRtQeKXpP,args):
  vNlofExzwBOULAMYanJyTIRtQeKXdk=args.get('category')
  vNlofExzwBOULAMYanJyTIRtQeKXdP=vNlofExzwBOULAMYanJyTIRtQeKXpP.NsportsObj.Get_Gamelist_BSjson(vNlofExzwBOULAMYanJyTIRtQeKXdk)
  for vNlofExzwBOULAMYanJyTIRtQeKXdD in vNlofExzwBOULAMYanJyTIRtQeKXdP:
   vNlofExzwBOULAMYanJyTIRtQeKXdS =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('gameId')
   vNlofExzwBOULAMYanJyTIRtQeKXdm =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('time')
   vNlofExzwBOULAMYanJyTIRtQeKXpV =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('title')
   vNlofExzwBOULAMYanJyTIRtQeKXdC =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('live')
   vNlofExzwBOULAMYanJyTIRtQeKXrp =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('ing')
   vNlofExzwBOULAMYanJyTIRtQeKXrd =vNlofExzwBOULAMYanJyTIRtQeKXdD.get('place')
   if vNlofExzwBOULAMYanJyTIRtQeKXdC=='Y':
    vNlofExzwBOULAMYanJyTIRtQeKXds='방송중'
   else:
    vNlofExzwBOULAMYanJyTIRtQeKXds=''
   if vNlofExzwBOULAMYanJyTIRtQeKXds=='':
    vNlofExzwBOULAMYanJyTIRtQeKXpC=vNlofExzwBOULAMYanJyTIRtQeKXdm
   else:
    vNlofExzwBOULAMYanJyTIRtQeKXpC=vNlofExzwBOULAMYanJyTIRtQeKXdm+' - '+vNlofExzwBOULAMYanJyTIRtQeKXds
   vNlofExzwBOULAMYanJyTIRtQeKXdb={'mediatype':'episode','title':vNlofExzwBOULAMYanJyTIRtQeKXpV,'plot':'%s\n\n시간 : %s\n\n%s'%(vNlofExzwBOULAMYanJyTIRtQeKXpV,vNlofExzwBOULAMYanJyTIRtQeKXpC,vNlofExzwBOULAMYanJyTIRtQeKXrd)}
   vNlofExzwBOULAMYanJyTIRtQeKXph={'mode':'LIVE','gameId':vNlofExzwBOULAMYanJyTIRtQeKXdS,}
   vNlofExzwBOULAMYanJyTIRtQeKXpP.add_dir(vNlofExzwBOULAMYanJyTIRtQeKXpV,sublabel=vNlofExzwBOULAMYanJyTIRtQeKXpC,img='',infoLabels=vNlofExzwBOULAMYanJyTIRtQeKXdb,isFolder=vNlofExzwBOULAMYanJyTIRtQeKXrF,params=vNlofExzwBOULAMYanJyTIRtQeKXph)
  xbmcplugin.endOfDirectory(vNlofExzwBOULAMYanJyTIRtQeKXpP._addon_handle,cacheToDisc=vNlofExzwBOULAMYanJyTIRtQeKXrF)
 def play_VIDEO(vNlofExzwBOULAMYanJyTIRtQeKXpP,args):
  vNlofExzwBOULAMYanJyTIRtQeKXdS =args.get('gameId')
  vNlofExzwBOULAMYanJyTIRtQeKXrb =vNlofExzwBOULAMYanJyTIRtQeKXpP.get_Bitrate_sel()
  if vNlofExzwBOULAMYanJyTIRtQeKXdS=='' or vNlofExzwBOULAMYanJyTIRtQeKXdS==vNlofExzwBOULAMYanJyTIRtQeKXrk:return
  vNlofExzwBOULAMYanJyTIRtQeKXrP=vNlofExzwBOULAMYanJyTIRtQeKXpP.NsportsObj.GetStreamingRtmp(vNlofExzwBOULAMYanJyTIRtQeKXdS,vNlofExzwBOULAMYanJyTIRtQeKXrb)
  if vNlofExzwBOULAMYanJyTIRtQeKXrP=='':
   vNlofExzwBOULAMYanJyTIRtQeKXpP.addon_noti(__language__(30901).encode('utf8'))
   return
  vNlofExzwBOULAMYanJyTIRtQeKXpP.addon_log('gameId : '+vNlofExzwBOULAMYanJyTIRtQeKXdS)
  vNlofExzwBOULAMYanJyTIRtQeKXpP.addon_log('GetStreamingRtmp : '+vNlofExzwBOULAMYanJyTIRtQeKXrP)
  vNlofExzwBOULAMYanJyTIRtQeKXrD=xbmcgui.ListItem(path=vNlofExzwBOULAMYanJyTIRtQeKXrP)
  xbmcplugin.setResolvedUrl(vNlofExzwBOULAMYanJyTIRtQeKXpP._addon_handle,vNlofExzwBOULAMYanJyTIRtQeKXrj,vNlofExzwBOULAMYanJyTIRtQeKXrD)
 def play_CHANNEL(vNlofExzwBOULAMYanJyTIRtQeKXpP,args):
  vNlofExzwBOULAMYanJyTIRtQeKXdr =args.get('chId')
  vNlofExzwBOULAMYanJyTIRtQeKXdu =args.get('maxBitrate')
  vNlofExzwBOULAMYanJyTIRtQeKXrb =vNlofExzwBOULAMYanJyTIRtQeKXpP.get_Bitrate_sel()
  vNlofExzwBOULAMYanJyTIRtQeKXrP=vNlofExzwBOULAMYanJyTIRtQeKXpP.NsportsObj.GetStreamingURL(vNlofExzwBOULAMYanJyTIRtQeKXdr,vNlofExzwBOULAMYanJyTIRtQeKXrb,vNlofExzwBOULAMYanJyTIRtQeKXdu)
  if vNlofExzwBOULAMYanJyTIRtQeKXrP=='':
   vNlofExzwBOULAMYanJyTIRtQeKXpP.addon_noti(__language__(30901).encode('utf8'))
   return
  vNlofExzwBOULAMYanJyTIRtQeKXpP.addon_log('chId : '+vNlofExzwBOULAMYanJyTIRtQeKXdr)
  vNlofExzwBOULAMYanJyTIRtQeKXpP.addon_log('play_CHANNEL : '+vNlofExzwBOULAMYanJyTIRtQeKXrP)
  vNlofExzwBOULAMYanJyTIRtQeKXrD=xbmcgui.ListItem(path=vNlofExzwBOULAMYanJyTIRtQeKXrP)
  xbmcplugin.setResolvedUrl(vNlofExzwBOULAMYanJyTIRtQeKXpP._addon_handle,vNlofExzwBOULAMYanJyTIRtQeKXrj,vNlofExzwBOULAMYanJyTIRtQeKXrD)
 def nsports_main(vNlofExzwBOULAMYanJyTIRtQeKXpP):
  vNlofExzwBOULAMYanJyTIRtQeKXrg=vNlofExzwBOULAMYanJyTIRtQeKXpP.main_params.get('mode',vNlofExzwBOULAMYanJyTIRtQeKXrk)
  if vNlofExzwBOULAMYanJyTIRtQeKXrg is vNlofExzwBOULAMYanJyTIRtQeKXrk:
   vNlofExzwBOULAMYanJyTIRtQeKXpP.dp_Main_List(vNlofExzwBOULAMYanJyTIRtQeKXpP.main_params)
  elif vNlofExzwBOULAMYanJyTIRtQeKXrg=='CATEGORY_LIST':
   vNlofExzwBOULAMYanJyTIRtQeKXpP.dp_Category_List(vNlofExzwBOULAMYanJyTIRtQeKXpP.main_params)
  elif vNlofExzwBOULAMYanJyTIRtQeKXrg=='BS_CATEGORY':
   vNlofExzwBOULAMYanJyTIRtQeKXpP.dp_BsCategory_List(vNlofExzwBOULAMYanJyTIRtQeKXpP.main_params)
  elif vNlofExzwBOULAMYanJyTIRtQeKXrg=='GAME_LIST':
   vNlofExzwBOULAMYanJyTIRtQeKXpP.dp_Game_List(vNlofExzwBOULAMYanJyTIRtQeKXpP.main_params)
  elif vNlofExzwBOULAMYanJyTIRtQeKXrg=='BS_GAME':
   vNlofExzwBOULAMYanJyTIRtQeKXpP.dp_BsGame_List(vNlofExzwBOULAMYanJyTIRtQeKXpP.main_params)
  elif vNlofExzwBOULAMYanJyTIRtQeKXrg=='LIVE':
   vNlofExzwBOULAMYanJyTIRtQeKXpP.play_VIDEO(vNlofExzwBOULAMYanJyTIRtQeKXpP.main_params)
  elif vNlofExzwBOULAMYanJyTIRtQeKXrg=='CLIVE':
   vNlofExzwBOULAMYanJyTIRtQeKXpP.play_CHANNEL(vNlofExzwBOULAMYanJyTIRtQeKXpP.main_params)
  elif vNlofExzwBOULAMYanJyTIRtQeKXrg=='CHANNEL_LIST':
   vNlofExzwBOULAMYanJyTIRtQeKXpP.dp_Channel_List(vNlofExzwBOULAMYanJyTIRtQeKXpP.main_params)
  else:
   vNlofExzwBOULAMYanJyTIRtQeKXrk
# Created by pyminifier (https://github.com/liftoff/pyminifier)
