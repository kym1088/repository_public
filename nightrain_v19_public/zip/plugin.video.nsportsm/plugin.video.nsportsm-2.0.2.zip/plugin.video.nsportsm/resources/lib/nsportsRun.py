__author__="NightRain"
rGqQLCPEnvhBFdYTekJXfcVAMSDUso=object
rGqQLCPEnvhBFdYTekJXfcVAMSDUsb=None
rGqQLCPEnvhBFdYTekJXfcVAMSDUsy=True
rGqQLCPEnvhBFdYTekJXfcVAMSDUsz=False
rGqQLCPEnvhBFdYTekJXfcVAMSDUsu=type
rGqQLCPEnvhBFdYTekJXfcVAMSDUsR=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
rGqQLCPEnvhBFdYTekJXfcVAMSDUNs=[{'title':'경기별 보기 (타입1)','mode':'CATEGORY_LIST'},{'title':'경기별 보기 (타입2)','mode':'BS_CATEGORY'},{'title':'채널별 보기','mode':'CHANNEL_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'** 경기중이 아닐때에는 시청이 제한될수 있음 **','mode':'XXX'},]
rGqQLCPEnvhBFdYTekJXfcVAMSDUNx=[{'chId':'ad1','title':'Spotv1'},{'chId':'ad2','title':'KBS N Sports'},{'chId':'ad3','title':'SBS Sports'},{'chId':'ad4','title':'MBC Sports'},{'chId':'ad5','title':'Spotv2'},]
from nsportsCore import*
class rGqQLCPEnvhBFdYTekJXfcVAMSDUNO(rGqQLCPEnvhBFdYTekJXfcVAMSDUso):
 def __init__(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp,rGqQLCPEnvhBFdYTekJXfcVAMSDUNi,rGqQLCPEnvhBFdYTekJXfcVAMSDUNa,rGqQLCPEnvhBFdYTekJXfcVAMSDUNo):
  rGqQLCPEnvhBFdYTekJXfcVAMSDUNp._addon_url =rGqQLCPEnvhBFdYTekJXfcVAMSDUNi
  rGqQLCPEnvhBFdYTekJXfcVAMSDUNp._addon_handle=rGqQLCPEnvhBFdYTekJXfcVAMSDUNa
  rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.main_params =rGqQLCPEnvhBFdYTekJXfcVAMSDUNo
  rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.NsportsObj =LwIdPYlxtRreUNnCmWgsaTkGEVKXqB() 
 def addon_noti(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp,sting):
  try:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNy=xbmcgui.Dialog()
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNy.notification(__addonname__,sting)
  except:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUsb
 def addon_log(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp,string):
  try:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNz=string.encode('utf-8','ignore')
  except:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNz='addonException: addon_log'
  rGqQLCPEnvhBFdYTekJXfcVAMSDUNu=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,rGqQLCPEnvhBFdYTekJXfcVAMSDUNz),level=rGqQLCPEnvhBFdYTekJXfcVAMSDUNu)
 def get_Bitrate_sel(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp):
  rGqQLCPEnvhBFdYTekJXfcVAMSDUNR={'0':'5000','1':'2000','2':'800',}
  return rGqQLCPEnvhBFdYTekJXfcVAMSDUNR.get(__addon__.getSetting('selected_quality'))
 def add_dir(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp,label,sublabel='',img='',infoLabels=rGqQLCPEnvhBFdYTekJXfcVAMSDUsb,isFolder=rGqQLCPEnvhBFdYTekJXfcVAMSDUsy,params='',isLink=rGqQLCPEnvhBFdYTekJXfcVAMSDUsz,ContextMenu=rGqQLCPEnvhBFdYTekJXfcVAMSDUsb):
  rGqQLCPEnvhBFdYTekJXfcVAMSDUNH='%s?%s'%(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp._addon_url,urllib.parse.urlencode(params))
  if sublabel:rGqQLCPEnvhBFdYTekJXfcVAMSDUNg='%s < %s >'%(label,sublabel)
  else: rGqQLCPEnvhBFdYTekJXfcVAMSDUNg=label
  if not img:img='DefaultFolder.png'
  rGqQLCPEnvhBFdYTekJXfcVAMSDUNl=xbmcgui.ListItem(rGqQLCPEnvhBFdYTekJXfcVAMSDUNg)
  if rGqQLCPEnvhBFdYTekJXfcVAMSDUsu(img)==rGqQLCPEnvhBFdYTekJXfcVAMSDUsR:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNl.setArt(img)
  else:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNl.setArt({'thumb':img,'poster':img})
  if infoLabels:rGqQLCPEnvhBFdYTekJXfcVAMSDUNl.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNl.setProperty('IsPlayable','true')
  if ContextMenu:rGqQLCPEnvhBFdYTekJXfcVAMSDUNl.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp._addon_handle,rGqQLCPEnvhBFdYTekJXfcVAMSDUNH,rGqQLCPEnvhBFdYTekJXfcVAMSDUNl,isFolder)
 def dp_Main_List(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp,args):
  for rGqQLCPEnvhBFdYTekJXfcVAMSDUNw in rGqQLCPEnvhBFdYTekJXfcVAMSDUNs:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNg=rGqQLCPEnvhBFdYTekJXfcVAMSDUNw.get('title')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNt=''
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNW={'mode':rGqQLCPEnvhBFdYTekJXfcVAMSDUNw.get('mode'),}
   if rGqQLCPEnvhBFdYTekJXfcVAMSDUNw.get('mode')in['XXX']:
    rGqQLCPEnvhBFdYTekJXfcVAMSDUNK=rGqQLCPEnvhBFdYTekJXfcVAMSDUsz
    rGqQLCPEnvhBFdYTekJXfcVAMSDUNm =rGqQLCPEnvhBFdYTekJXfcVAMSDUsy
   else:
    rGqQLCPEnvhBFdYTekJXfcVAMSDUNK=rGqQLCPEnvhBFdYTekJXfcVAMSDUsy
    rGqQLCPEnvhBFdYTekJXfcVAMSDUNm =rGqQLCPEnvhBFdYTekJXfcVAMSDUsz
   if 'icon' in rGqQLCPEnvhBFdYTekJXfcVAMSDUNw:rGqQLCPEnvhBFdYTekJXfcVAMSDUNt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',rGqQLCPEnvhBFdYTekJXfcVAMSDUNw.get('icon')) 
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.add_dir(rGqQLCPEnvhBFdYTekJXfcVAMSDUNg,sublabel='',img=rGqQLCPEnvhBFdYTekJXfcVAMSDUNt,infoLabels=rGqQLCPEnvhBFdYTekJXfcVAMSDUsb,isFolder=rGqQLCPEnvhBFdYTekJXfcVAMSDUNK,params=rGqQLCPEnvhBFdYTekJXfcVAMSDUNW,isLink=rGqQLCPEnvhBFdYTekJXfcVAMSDUNm)
  xbmcplugin.endOfDirectory(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp._addon_handle)
 def dp_Channel_List(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp,args):
  rGqQLCPEnvhBFdYTekJXfcVAMSDUNj=rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.get_Bitrate_sel()
  for rGqQLCPEnvhBFdYTekJXfcVAMSDUON in rGqQLCPEnvhBFdYTekJXfcVAMSDUNx:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNg=rGqQLCPEnvhBFdYTekJXfcVAMSDUON.get('title')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOs=rGqQLCPEnvhBFdYTekJXfcVAMSDUON.get('chId')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOx={'mediatype':'episode','title':rGqQLCPEnvhBFdYTekJXfcVAMSDUNg}
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNW={'mode':'CLIVE','chId':rGqQLCPEnvhBFdYTekJXfcVAMSDUOs,'maxBitrate':rGqQLCPEnvhBFdYTekJXfcVAMSDUNj,}
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.add_dir(rGqQLCPEnvhBFdYTekJXfcVAMSDUNg,sublabel='',img='',infoLabels=rGqQLCPEnvhBFdYTekJXfcVAMSDUOx,isFolder=rGqQLCPEnvhBFdYTekJXfcVAMSDUsz,params=rGqQLCPEnvhBFdYTekJXfcVAMSDUNW,isLink=rGqQLCPEnvhBFdYTekJXfcVAMSDUsz)
  xbmcplugin.endOfDirectory(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp._addon_handle)
 def dp_Category_List(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp,args):
  rGqQLCPEnvhBFdYTekJXfcVAMSDUOp=rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.NsportsObj.Get_Category_List()
  for rGqQLCPEnvhBFdYTekJXfcVAMSDUOi in rGqQLCPEnvhBFdYTekJXfcVAMSDUOp:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOa =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('groupnm')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOo =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('onairyn')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOb=','.join(rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('category'))
   if rGqQLCPEnvhBFdYTekJXfcVAMSDUOo=='Y':rGqQLCPEnvhBFdYTekJXfcVAMSDUNI='중계중'
   else:rGqQLCPEnvhBFdYTekJXfcVAMSDUNI=''
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNW={'mode':'GAME_LIST','category':rGqQLCPEnvhBFdYTekJXfcVAMSDUOb,}
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.add_dir(rGqQLCPEnvhBFdYTekJXfcVAMSDUOa,sublabel=rGqQLCPEnvhBFdYTekJXfcVAMSDUNI,img='',infoLabels=rGqQLCPEnvhBFdYTekJXfcVAMSDUsb,isFolder=rGqQLCPEnvhBFdYTekJXfcVAMSDUsy,params=rGqQLCPEnvhBFdYTekJXfcVAMSDUNW)
  xbmcplugin.endOfDirectory(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp._addon_handle,cacheToDisc=rGqQLCPEnvhBFdYTekJXfcVAMSDUsz)
 def dp_Game_List(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp,args):
  rGqQLCPEnvhBFdYTekJXfcVAMSDUOz=args.get('category')
  rGqQLCPEnvhBFdYTekJXfcVAMSDUOp=rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.NsportsObj.Get_Game_List(rGqQLCPEnvhBFdYTekJXfcVAMSDUOz)
  for rGqQLCPEnvhBFdYTekJXfcVAMSDUOi in rGqQLCPEnvhBFdYTekJXfcVAMSDUOp:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOu =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('gameId')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOR =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('upperCategoryId')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOH =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('categoryId')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOg =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('statusCode')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOl =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('statusInfo')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOw =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('isOnAirTv')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOs =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('chId')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNg =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('title')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOt =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('starttime')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOW =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('endTime')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOK =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('maxBitrate')
   if rGqQLCPEnvhBFdYTekJXfcVAMSDUNg=='':rGqQLCPEnvhBFdYTekJXfcVAMSDUNg=rGqQLCPEnvhBFdYTekJXfcVAMSDUOu
   if rGqQLCPEnvhBFdYTekJXfcVAMSDUOw=='Y':
    rGqQLCPEnvhBFdYTekJXfcVAMSDUOm='방송중'
   else:
    if rGqQLCPEnvhBFdYTekJXfcVAMSDUOl=='경기취소':
     rGqQLCPEnvhBFdYTekJXfcVAMSDUOm=rGqQLCPEnvhBFdYTekJXfcVAMSDUOl
    else:
     rGqQLCPEnvhBFdYTekJXfcVAMSDUOm=''
   if rGqQLCPEnvhBFdYTekJXfcVAMSDUOt=='':
    rGqQLCPEnvhBFdYTekJXfcVAMSDUNI=rGqQLCPEnvhBFdYTekJXfcVAMSDUOm
   else:
    if rGqQLCPEnvhBFdYTekJXfcVAMSDUOm=='':
     rGqQLCPEnvhBFdYTekJXfcVAMSDUNI=rGqQLCPEnvhBFdYTekJXfcVAMSDUOt
    else:
     rGqQLCPEnvhBFdYTekJXfcVAMSDUNI=rGqQLCPEnvhBFdYTekJXfcVAMSDUOt+' - '+rGqQLCPEnvhBFdYTekJXfcVAMSDUOm
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOx={'mediatype':'episode','title':rGqQLCPEnvhBFdYTekJXfcVAMSDUNg,'plot':'%s\n\n시작 : %s\n종료 : %s'%(rGqQLCPEnvhBFdYTekJXfcVAMSDUNg,rGqQLCPEnvhBFdYTekJXfcVAMSDUOt,rGqQLCPEnvhBFdYTekJXfcVAMSDUOW)}
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNW={'mode':'LIVE','chId':rGqQLCPEnvhBFdYTekJXfcVAMSDUOs,'maxBitrate':rGqQLCPEnvhBFdYTekJXfcVAMSDUOK,'gameId':rGqQLCPEnvhBFdYTekJXfcVAMSDUOu,}
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.add_dir(rGqQLCPEnvhBFdYTekJXfcVAMSDUNg,sublabel=rGqQLCPEnvhBFdYTekJXfcVAMSDUNI,img='',infoLabels=rGqQLCPEnvhBFdYTekJXfcVAMSDUOx,isFolder=rGqQLCPEnvhBFdYTekJXfcVAMSDUsz,params=rGqQLCPEnvhBFdYTekJXfcVAMSDUNW)
  xbmcplugin.endOfDirectory(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp._addon_handle,cacheToDisc=rGqQLCPEnvhBFdYTekJXfcVAMSDUsz)
 def dp_BsCategory_List(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp,args):
  rGqQLCPEnvhBFdYTekJXfcVAMSDUOp=rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.NsportsObj.Get_Category_BSjson()
  for rGqQLCPEnvhBFdYTekJXfcVAMSDUOi in rGqQLCPEnvhBFdYTekJXfcVAMSDUOp:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOb =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('category')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOI =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('live')
   if rGqQLCPEnvhBFdYTekJXfcVAMSDUOI=='Y':rGqQLCPEnvhBFdYTekJXfcVAMSDUNI='중계중'
   else:rGqQLCPEnvhBFdYTekJXfcVAMSDUNI=''
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNW={'mode':'BS_GAME','category':rGqQLCPEnvhBFdYTekJXfcVAMSDUOb,}
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.add_dir(rGqQLCPEnvhBFdYTekJXfcVAMSDUOb,sublabel=rGqQLCPEnvhBFdYTekJXfcVAMSDUNI,img='',infoLabels=rGqQLCPEnvhBFdYTekJXfcVAMSDUsb,isFolder=rGqQLCPEnvhBFdYTekJXfcVAMSDUsy,params=rGqQLCPEnvhBFdYTekJXfcVAMSDUNW)
  xbmcplugin.endOfDirectory(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp._addon_handle,cacheToDisc=rGqQLCPEnvhBFdYTekJXfcVAMSDUsz)
 def dp_BsGame_List(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp,args):
  rGqQLCPEnvhBFdYTekJXfcVAMSDUOb=args.get('category')
  rGqQLCPEnvhBFdYTekJXfcVAMSDUOp=rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.NsportsObj.Get_Gamelist_BSjson(rGqQLCPEnvhBFdYTekJXfcVAMSDUOb)
  for rGqQLCPEnvhBFdYTekJXfcVAMSDUOi in rGqQLCPEnvhBFdYTekJXfcVAMSDUOp:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOu =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('gameId')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOj =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('time')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNg =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('title')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOI =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('live')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUsN =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('ing')
   rGqQLCPEnvhBFdYTekJXfcVAMSDUsO =rGqQLCPEnvhBFdYTekJXfcVAMSDUOi.get('place')
   if rGqQLCPEnvhBFdYTekJXfcVAMSDUOI=='Y':
    rGqQLCPEnvhBFdYTekJXfcVAMSDUOm='방송중'
   else:
    rGqQLCPEnvhBFdYTekJXfcVAMSDUOm=''
   if rGqQLCPEnvhBFdYTekJXfcVAMSDUOm=='':
    rGqQLCPEnvhBFdYTekJXfcVAMSDUNI=rGqQLCPEnvhBFdYTekJXfcVAMSDUOj
   else:
    rGqQLCPEnvhBFdYTekJXfcVAMSDUNI=rGqQLCPEnvhBFdYTekJXfcVAMSDUOj+' - '+rGqQLCPEnvhBFdYTekJXfcVAMSDUOm
   rGqQLCPEnvhBFdYTekJXfcVAMSDUOx={'mediatype':'episode','title':rGqQLCPEnvhBFdYTekJXfcVAMSDUNg,'plot':'%s\n\n시간 : %s\n\n%s'%(rGqQLCPEnvhBFdYTekJXfcVAMSDUNg,rGqQLCPEnvhBFdYTekJXfcVAMSDUNI,rGqQLCPEnvhBFdYTekJXfcVAMSDUsO)}
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNW={'mode':'LIVE','gameId':rGqQLCPEnvhBFdYTekJXfcVAMSDUOu,}
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.add_dir(rGqQLCPEnvhBFdYTekJXfcVAMSDUNg,sublabel=rGqQLCPEnvhBFdYTekJXfcVAMSDUNI,img='',infoLabels=rGqQLCPEnvhBFdYTekJXfcVAMSDUOx,isFolder=rGqQLCPEnvhBFdYTekJXfcVAMSDUsz,params=rGqQLCPEnvhBFdYTekJXfcVAMSDUNW)
  xbmcplugin.endOfDirectory(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp._addon_handle,cacheToDisc=rGqQLCPEnvhBFdYTekJXfcVAMSDUsz)
 def play_VIDEO(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp,args):
  rGqQLCPEnvhBFdYTekJXfcVAMSDUOu =args.get('gameId')
  rGqQLCPEnvhBFdYTekJXfcVAMSDUsx =rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.get_Bitrate_sel()
  if rGqQLCPEnvhBFdYTekJXfcVAMSDUOu=='' or rGqQLCPEnvhBFdYTekJXfcVAMSDUOu==rGqQLCPEnvhBFdYTekJXfcVAMSDUsb:return
  rGqQLCPEnvhBFdYTekJXfcVAMSDUsp=rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.NsportsObj.GetStreamingRtmp(rGqQLCPEnvhBFdYTekJXfcVAMSDUOu,rGqQLCPEnvhBFdYTekJXfcVAMSDUsx)
  if rGqQLCPEnvhBFdYTekJXfcVAMSDUsp=='':
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.addon_noti(__language__(30901).encode('utf8'))
   return
  rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.addon_log(rGqQLCPEnvhBFdYTekJXfcVAMSDUsp)
  rGqQLCPEnvhBFdYTekJXfcVAMSDUsi=xbmcgui.ListItem(path=rGqQLCPEnvhBFdYTekJXfcVAMSDUsp)
  xbmcplugin.setResolvedUrl(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp._addon_handle,rGqQLCPEnvhBFdYTekJXfcVAMSDUsy,rGqQLCPEnvhBFdYTekJXfcVAMSDUsi)
 def play_CHANNEL(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp,args):
  rGqQLCPEnvhBFdYTekJXfcVAMSDUOs =args.get('chId')
  rGqQLCPEnvhBFdYTekJXfcVAMSDUOK =args.get('maxBitrate')
  rGqQLCPEnvhBFdYTekJXfcVAMSDUsx =rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.get_Bitrate_sel()
  rGqQLCPEnvhBFdYTekJXfcVAMSDUsp=rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.NsportsObj.GetStreamingURL(rGqQLCPEnvhBFdYTekJXfcVAMSDUOs,rGqQLCPEnvhBFdYTekJXfcVAMSDUsx,rGqQLCPEnvhBFdYTekJXfcVAMSDUOK)
  if rGqQLCPEnvhBFdYTekJXfcVAMSDUsp=='':
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.addon_noti(__language__(30901).encode('utf8'))
   return
  rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.addon_log(rGqQLCPEnvhBFdYTekJXfcVAMSDUsp)
  rGqQLCPEnvhBFdYTekJXfcVAMSDUsi=xbmcgui.ListItem(path=rGqQLCPEnvhBFdYTekJXfcVAMSDUsp)
  xbmcplugin.setResolvedUrl(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp._addon_handle,rGqQLCPEnvhBFdYTekJXfcVAMSDUsy,rGqQLCPEnvhBFdYTekJXfcVAMSDUsi)
 def nsports_main(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp):
  rGqQLCPEnvhBFdYTekJXfcVAMSDUsa=rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.main_params.get('mode',rGqQLCPEnvhBFdYTekJXfcVAMSDUsb)
  if rGqQLCPEnvhBFdYTekJXfcVAMSDUsa is rGqQLCPEnvhBFdYTekJXfcVAMSDUsb:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.dp_Main_List(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.main_params)
  elif rGqQLCPEnvhBFdYTekJXfcVAMSDUsa=='CATEGORY_LIST':
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.dp_Category_List(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.main_params)
  elif rGqQLCPEnvhBFdYTekJXfcVAMSDUsa=='BS_CATEGORY':
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.dp_BsCategory_List(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.main_params)
  elif rGqQLCPEnvhBFdYTekJXfcVAMSDUsa=='GAME_LIST':
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.dp_Game_List(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.main_params)
  elif rGqQLCPEnvhBFdYTekJXfcVAMSDUsa=='BS_GAME':
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.dp_BsGame_List(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.main_params)
  elif rGqQLCPEnvhBFdYTekJXfcVAMSDUsa=='LIVE':
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.play_VIDEO(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.main_params)
  elif rGqQLCPEnvhBFdYTekJXfcVAMSDUsa=='CLIVE':
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.play_CHANNEL(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.main_params)
  elif rGqQLCPEnvhBFdYTekJXfcVAMSDUsa=='CHANNEL_LIST':
   rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.dp_Channel_List(rGqQLCPEnvhBFdYTekJXfcVAMSDUNp.main_params)
  else:
   rGqQLCPEnvhBFdYTekJXfcVAMSDUsb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
