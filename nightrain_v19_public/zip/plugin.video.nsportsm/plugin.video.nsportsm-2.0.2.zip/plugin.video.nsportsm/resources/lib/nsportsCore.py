__author__="NightRain"
LwIdPYlxtRreUNnCmWgsaTkGEVKXhJ=object
LwIdPYlxtRreUNnCmWgsaTkGEVKXhb=None
LwIdPYlxtRreUNnCmWgsaTkGEVKXhy=False
LwIdPYlxtRreUNnCmWgsaTkGEVKXhv=True
LwIdPYlxtRreUNnCmWgsaTkGEVKXhQ=len
LwIdPYlxtRreUNnCmWgsaTkGEVKXhp=print
LwIdPYlxtRreUNnCmWgsaTkGEVKXhu=Exception
LwIdPYlxtRreUNnCmWgsaTkGEVKXhf=int
LwIdPYlxtRreUNnCmWgsaTkGEVKXhc=str
LwIdPYlxtRreUNnCmWgsaTkGEVKXhH=type
LwIdPYlxtRreUNnCmWgsaTkGEVKXho=dict
import urllib
import re
import json
import requests
import datetime
from bs4 import BeautifulSoup
class LwIdPYlxtRreUNnCmWgsaTkGEVKXqB(LwIdPYlxtRreUNnCmWgsaTkGEVKXhJ):
 def __init__(LwIdPYlxtRreUNnCmWgsaTkGEVKXqi):
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36'
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.DEFAULT_HEADER ={'user-agent':LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.USER_AGENT}
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.genres=[{'groupnm':'야구','category':['kbaseball','wbaseball']},{'groupnm':'축구','category':['kfootball','wfootball']},{'groupnm':'배구','category':['kvolleyball']},{'groupnm':'골프','category':['golf']},{'groupnm':'기타','category':['others']},]
 def callRequestCookies(LwIdPYlxtRreUNnCmWgsaTkGEVKXqi,jobtype,LwIdPYlxtRreUNnCmWgsaTkGEVKXqy,payload=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,params=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,headers=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,cookies=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,redirects=LwIdPYlxtRreUNnCmWgsaTkGEVKXhy):
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqh=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.DEFAULT_HEADER
  if headers:LwIdPYlxtRreUNnCmWgsaTkGEVKXqh.update(headers)
  if jobtype=='Get':
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqj=requests.get(LwIdPYlxtRreUNnCmWgsaTkGEVKXqy,params=params,headers=LwIdPYlxtRreUNnCmWgsaTkGEVKXqh,cookies=cookies,allow_redirects=redirects)
  else:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqj=requests.post(LwIdPYlxtRreUNnCmWgsaTkGEVKXqy,data=payload,params=params,headers=LwIdPYlxtRreUNnCmWgsaTkGEVKXqh,cookies=cookies,allow_redirects=redirects)
  return LwIdPYlxtRreUNnCmWgsaTkGEVKXqj
 def Get_Now_Datetime(LwIdPYlxtRreUNnCmWgsaTkGEVKXqi):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def make_viewdate(LwIdPYlxtRreUNnCmWgsaTkGEVKXqi,dtype='1'):
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqM =LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.Get_Now_Datetime()
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqD =LwIdPYlxtRreUNnCmWgsaTkGEVKXqM+datetime.timedelta(days=-1)
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqS =LwIdPYlxtRreUNnCmWgsaTkGEVKXqM+datetime.timedelta(days=1)
  if dtype=='1':
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqA=[LwIdPYlxtRreUNnCmWgsaTkGEVKXqM.strftime('%Y%m%d'),]
  elif dtype=='2':
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqA=[LwIdPYlxtRreUNnCmWgsaTkGEVKXqM.strftime('%Y%m%d'),LwIdPYlxtRreUNnCmWgsaTkGEVKXqS.strftime('%Y%m%d'),]
  elif dtype=='3':
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqA=[LwIdPYlxtRreUNnCmWgsaTkGEVKXqM.strftime('%Y%m%d'),LwIdPYlxtRreUNnCmWgsaTkGEVKXqD.strftime('%Y%m%d'),LwIdPYlxtRreUNnCmWgsaTkGEVKXqS.strftime('%Y%m%d'),]
  return LwIdPYlxtRreUNnCmWgsaTkGEVKXqA
 def Get_Category_List(LwIdPYlxtRreUNnCmWgsaTkGEVKXqi):
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ=[]
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqb=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.make_viewdate(dtype='1')
  try:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqy='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqv=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.callRequestCookies('Get',LwIdPYlxtRreUNnCmWgsaTkGEVKXqy,payload=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,params=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,headers=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,cookies=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,redirects=LwIdPYlxtRreUNnCmWgsaTkGEVKXhv)
   if LwIdPYlxtRreUNnCmWgsaTkGEVKXqv.status_code!=200:return[]
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqQ=json.loads(LwIdPYlxtRreUNnCmWgsaTkGEVKXqv.text)
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqp=LwIdPYlxtRreUNnCmWgsaTkGEVKXqQ.get('gameList')
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqu=[]
   for LwIdPYlxtRreUNnCmWgsaTkGEVKXqf in LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.genres:
    LwIdPYlxtRreUNnCmWgsaTkGEVKXqc =LwIdPYlxtRreUNnCmWgsaTkGEVKXqf.get('groupnm')
    LwIdPYlxtRreUNnCmWgsaTkGEVKXqH=[]
    LwIdPYlxtRreUNnCmWgsaTkGEVKXqo ='N'
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXhQ(LwIdPYlxtRreUNnCmWgsaTkGEVKXqu)!=0:
     LwIdPYlxtRreUNnCmWgsaTkGEVKXqp =LwIdPYlxtRreUNnCmWgsaTkGEVKXqu
     LwIdPYlxtRreUNnCmWgsaTkGEVKXqu=[]
    for LwIdPYlxtRreUNnCmWgsaTkGEVKXqz in LwIdPYlxtRreUNnCmWgsaTkGEVKXqp:
     LwIdPYlxtRreUNnCmWgsaTkGEVKXqO=LwIdPYlxtRreUNnCmWgsaTkGEVKXqz.get('upperCategoryId')
     LwIdPYlxtRreUNnCmWgsaTkGEVKXBq =LwIdPYlxtRreUNnCmWgsaTkGEVKXqz.get('statusCode')
     LwIdPYlxtRreUNnCmWgsaTkGEVKXBi =LwIdPYlxtRreUNnCmWgsaTkGEVKXqz.get('isOnAirTv')
     LwIdPYlxtRreUNnCmWgsaTkGEVKXBh =LwIdPYlxtRreUNnCmWgsaTkGEVKXqz.get('gameId')
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXqO in('esports'):continue
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXBq in('RESULT'):continue
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXBh[:8]not in LwIdPYlxtRreUNnCmWgsaTkGEVKXqb and LwIdPYlxtRreUNnCmWgsaTkGEVKXBi!='Y':continue
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXqO in LwIdPYlxtRreUNnCmWgsaTkGEVKXqf.get('category'):
      if LwIdPYlxtRreUNnCmWgsaTkGEVKXqO not in LwIdPYlxtRreUNnCmWgsaTkGEVKXqH:LwIdPYlxtRreUNnCmWgsaTkGEVKXqH.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXqO)
      if LwIdPYlxtRreUNnCmWgsaTkGEVKXBi=='Y':LwIdPYlxtRreUNnCmWgsaTkGEVKXqo='Y'
     else:
      LwIdPYlxtRreUNnCmWgsaTkGEVKXqu.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXqz)
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXhQ(LwIdPYlxtRreUNnCmWgsaTkGEVKXqH)>0:
     LwIdPYlxtRreUNnCmWgsaTkGEVKXBj={'groupnm':LwIdPYlxtRreUNnCmWgsaTkGEVKXqc,'onairyn':LwIdPYlxtRreUNnCmWgsaTkGEVKXqo,'category':LwIdPYlxtRreUNnCmWgsaTkGEVKXqH,}
     LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXBj)
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXhQ(LwIdPYlxtRreUNnCmWgsaTkGEVKXqu)==0:break
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqc ='-'
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqH=[]
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqo ='N'
   for LwIdPYlxtRreUNnCmWgsaTkGEVKXqz in LwIdPYlxtRreUNnCmWgsaTkGEVKXqu:
    LwIdPYlxtRreUNnCmWgsaTkGEVKXqO=LwIdPYlxtRreUNnCmWgsaTkGEVKXqz.get('upperCategoryId')
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBi =LwIdPYlxtRreUNnCmWgsaTkGEVKXqz.get('isOnAirTv')
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXqO not in LwIdPYlxtRreUNnCmWgsaTkGEVKXqH:LwIdPYlxtRreUNnCmWgsaTkGEVKXqH.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXqO)
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXBi=='Y':LwIdPYlxtRreUNnCmWgsaTkGEVKXqo='Y'
   if LwIdPYlxtRreUNnCmWgsaTkGEVKXhQ(LwIdPYlxtRreUNnCmWgsaTkGEVKXqH)>0:
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBj={'groupnm':'-','onairyn':LwIdPYlxtRreUNnCmWgsaTkGEVKXqo,'category':LwIdPYlxtRreUNnCmWgsaTkGEVKXqH,}
    LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXBj)
    LwIdPYlxtRreUNnCmWgsaTkGEVKXhp(LwIdPYlxtRreUNnCmWgsaTkGEVKXqc,LwIdPYlxtRreUNnCmWgsaTkGEVKXqo,LwIdPYlxtRreUNnCmWgsaTkGEVKXqH)
  except LwIdPYlxtRreUNnCmWgsaTkGEVKXhu as exception:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXhp(exception)
   return[]
  return LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ
 def Get_Game_List(LwIdPYlxtRreUNnCmWgsaTkGEVKXqi,category):
  LwIdPYlxtRreUNnCmWgsaTkGEVKXBF=category.split(',')
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ =[]
  LwIdPYlxtRreUNnCmWgsaTkGEVKXBM =[]
  LwIdPYlxtRreUNnCmWgsaTkGEVKXBD =[]
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqb=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.make_viewdate()
  try:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqy='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqv=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.callRequestCookies('Get',LwIdPYlxtRreUNnCmWgsaTkGEVKXqy,payload=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,params=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,headers=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,cookies=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,redirects=LwIdPYlxtRreUNnCmWgsaTkGEVKXhv)
   if LwIdPYlxtRreUNnCmWgsaTkGEVKXqv.status_code!=200:return[]
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqQ=json.loads(LwIdPYlxtRreUNnCmWgsaTkGEVKXqv.text)
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqp=LwIdPYlxtRreUNnCmWgsaTkGEVKXqQ.get('gameList')
   for LwIdPYlxtRreUNnCmWgsaTkGEVKXqz in LwIdPYlxtRreUNnCmWgsaTkGEVKXqp:
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBh =LwIdPYlxtRreUNnCmWgsaTkGEVKXqz.get('gameId')
    LwIdPYlxtRreUNnCmWgsaTkGEVKXqO=LwIdPYlxtRreUNnCmWgsaTkGEVKXqz.get('upperCategoryId')
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBS =LwIdPYlxtRreUNnCmWgsaTkGEVKXqz.get('categoryId')
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBq =LwIdPYlxtRreUNnCmWgsaTkGEVKXqz.get('statusCode')
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBA =LwIdPYlxtRreUNnCmWgsaTkGEVKXqz.get('statusInfo')
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBi =LwIdPYlxtRreUNnCmWgsaTkGEVKXqz.get('isOnAirTv')
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXqO in('esports'):continue
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXBq in('RESULT'):continue
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXqO not in LwIdPYlxtRreUNnCmWgsaTkGEVKXBF:continue
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXBh[:8]not in LwIdPYlxtRreUNnCmWgsaTkGEVKXqb and LwIdPYlxtRreUNnCmWgsaTkGEVKXBi!='Y':continue
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBJ=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.Get_Game_liveInfo(LwIdPYlxtRreUNnCmWgsaTkGEVKXBh)
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXBJ.get('chId')==LwIdPYlxtRreUNnCmWgsaTkGEVKXhb:continue
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBj={'gameId':LwIdPYlxtRreUNnCmWgsaTkGEVKXBh,'upperCategoryId':LwIdPYlxtRreUNnCmWgsaTkGEVKXqO,'categoryId':LwIdPYlxtRreUNnCmWgsaTkGEVKXBS,'statusCode':LwIdPYlxtRreUNnCmWgsaTkGEVKXBq,'statusInfo':LwIdPYlxtRreUNnCmWgsaTkGEVKXBA,'isOnAirTv':LwIdPYlxtRreUNnCmWgsaTkGEVKXBi,'chId':LwIdPYlxtRreUNnCmWgsaTkGEVKXBJ.get('chId'),'title':LwIdPYlxtRreUNnCmWgsaTkGEVKXBJ.get('title'),'starttime':LwIdPYlxtRreUNnCmWgsaTkGEVKXBJ.get('starttime'),'endTime':LwIdPYlxtRreUNnCmWgsaTkGEVKXBJ.get('endTime'),'maxBitrate':LwIdPYlxtRreUNnCmWgsaTkGEVKXBJ.get('maxBitrate'),}
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXBi=='Y':
     LwIdPYlxtRreUNnCmWgsaTkGEVKXBM.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXBj)
    else:
     LwIdPYlxtRreUNnCmWgsaTkGEVKXBD.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXBj)
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ=LwIdPYlxtRreUNnCmWgsaTkGEVKXBM+LwIdPYlxtRreUNnCmWgsaTkGEVKXBD
  except LwIdPYlxtRreUNnCmWgsaTkGEVKXhu as exception:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXhp(exception)
   return[]
  return LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ
 def Get_Game_liveInfo(LwIdPYlxtRreUNnCmWgsaTkGEVKXqi,LwIdPYlxtRreUNnCmWgsaTkGEVKXBh):
  LwIdPYlxtRreUNnCmWgsaTkGEVKXBb={}
  try:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqy='https://apis.naver.com/pcLive/livePlatform/liveInfo2'
   LwIdPYlxtRreUNnCmWgsaTkGEVKXBy={'env':'pc','inclAudCh':'0','svcId':'12002','svcLiveId':LwIdPYlxtRreUNnCmWgsaTkGEVKXBh,}
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqv=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.callRequestCookies('Get',LwIdPYlxtRreUNnCmWgsaTkGEVKXqy,payload=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,params=LwIdPYlxtRreUNnCmWgsaTkGEVKXBy,headers=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,cookies=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,redirects=LwIdPYlxtRreUNnCmWgsaTkGEVKXhv)
   if LwIdPYlxtRreUNnCmWgsaTkGEVKXqv.status_code!=200:return[]
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqQ=json.loads(LwIdPYlxtRreUNnCmWgsaTkGEVKXqv.text)
   LwIdPYlxtRreUNnCmWgsaTkGEVKXBv =LwIdPYlxtRreUNnCmWgsaTkGEVKXqQ.get('chList')[0].get('chId')
   LwIdPYlxtRreUNnCmWgsaTkGEVKXBQ=LwIdPYlxtRreUNnCmWgsaTkGEVKXqQ.get('chConf').get(LwIdPYlxtRreUNnCmWgsaTkGEVKXBv)[0].get('id')
   LwIdPYlxtRreUNnCmWgsaTkGEVKXBp =LwIdPYlxtRreUNnCmWgsaTkGEVKXqQ.get('program')
   LwIdPYlxtRreUNnCmWgsaTkGEVKXBu =LwIdPYlxtRreUNnCmWgsaTkGEVKXBp.get('title')
   LwIdPYlxtRreUNnCmWgsaTkGEVKXBf =LwIdPYlxtRreUNnCmWgsaTkGEVKXBp.get('startTime')
   LwIdPYlxtRreUNnCmWgsaTkGEVKXBc =LwIdPYlxtRreUNnCmWgsaTkGEVKXBp.get('endTime')
   if LwIdPYlxtRreUNnCmWgsaTkGEVKXBf!=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb:
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBf =datetime.datetime.fromtimestamp(LwIdPYlxtRreUNnCmWgsaTkGEVKXhf(LwIdPYlxtRreUNnCmWgsaTkGEVKXBf),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:LwIdPYlxtRreUNnCmWgsaTkGEVKXBf=''
   if LwIdPYlxtRreUNnCmWgsaTkGEVKXBc!=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb:
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBc =datetime.datetime.fromtimestamp(LwIdPYlxtRreUNnCmWgsaTkGEVKXhf(LwIdPYlxtRreUNnCmWgsaTkGEVKXBc),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:LwIdPYlxtRreUNnCmWgsaTkGEVKXBc=''
   LwIdPYlxtRreUNnCmWgsaTkGEVKXBb={'chId':LwIdPYlxtRreUNnCmWgsaTkGEVKXBv,'title':LwIdPYlxtRreUNnCmWgsaTkGEVKXBu,'starttime':LwIdPYlxtRreUNnCmWgsaTkGEVKXBf,'endTime':LwIdPYlxtRreUNnCmWgsaTkGEVKXBc,'maxBitrate':LwIdPYlxtRreUNnCmWgsaTkGEVKXBQ,}
  except LwIdPYlxtRreUNnCmWgsaTkGEVKXhu as exception:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXhp(exception)
   return{}
  return LwIdPYlxtRreUNnCmWgsaTkGEVKXBb
 def GetStreamingURL(LwIdPYlxtRreUNnCmWgsaTkGEVKXqi,channelId,setBitrate,LwIdPYlxtRreUNnCmWgsaTkGEVKXBQ):
  LwIdPYlxtRreUNnCmWgsaTkGEVKXBH=''
  if LwIdPYlxtRreUNnCmWgsaTkGEVKXhf(setBitrate)>LwIdPYlxtRreUNnCmWgsaTkGEVKXhf(LwIdPYlxtRreUNnCmWgsaTkGEVKXBQ):
   LwIdPYlxtRreUNnCmWgsaTkGEVKXBo=LwIdPYlxtRreUNnCmWgsaTkGEVKXBQ
  else:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXBo=setBitrate
  try:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqy='https://apis.naver.com/pcLive/livePlatform/sUrl'
   LwIdPYlxtRreUNnCmWgsaTkGEVKXBy={'ch':channelId,'q':LwIdPYlxtRreUNnCmWgsaTkGEVKXBo,'p':'hls','cc':'KR','env':'pc',}
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqv=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.callRequestCookies('Get',LwIdPYlxtRreUNnCmWgsaTkGEVKXqy,payload=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,params=LwIdPYlxtRreUNnCmWgsaTkGEVKXBy,headers=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,cookies=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,redirects=LwIdPYlxtRreUNnCmWgsaTkGEVKXhv)
   if LwIdPYlxtRreUNnCmWgsaTkGEVKXqv.status_code!=200:return ''
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqQ=json.loads(LwIdPYlxtRreUNnCmWgsaTkGEVKXqv.text)
   LwIdPYlxtRreUNnCmWgsaTkGEVKXBH=LwIdPYlxtRreUNnCmWgsaTkGEVKXqQ.get('secUrl')
  except LwIdPYlxtRreUNnCmWgsaTkGEVKXhu as exception:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXhp(exception)
   return ''
  return LwIdPYlxtRreUNnCmWgsaTkGEVKXBH
 def GetStreamingRtmp(LwIdPYlxtRreUNnCmWgsaTkGEVKXqi,LwIdPYlxtRreUNnCmWgsaTkGEVKXBh,setBitrate):
  LwIdPYlxtRreUNnCmWgsaTkGEVKXBH=''
  try:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqy='https://api-gw.sports.naver.com/schedule/%s/lives'%(LwIdPYlxtRreUNnCmWgsaTkGEVKXBh)
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqv=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.callRequestCookies('Get',LwIdPYlxtRreUNnCmWgsaTkGEVKXqy,payload=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,params=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,headers=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,cookies=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,redirects=LwIdPYlxtRreUNnCmWgsaTkGEVKXhv)
   if LwIdPYlxtRreUNnCmWgsaTkGEVKXqv.status_code!=200:return ''
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqQ=json.loads(LwIdPYlxtRreUNnCmWgsaTkGEVKXqv.text)
   LwIdPYlxtRreUNnCmWgsaTkGEVKXBz=LwIdPYlxtRreUNnCmWgsaTkGEVKXqQ.get('result').get('lives')[0]
   if setBitrate=='5000':
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBH=LwIdPYlxtRreUNnCmWgsaTkGEVKXBz.get('rtmpPlayUrl1080')
   else:
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBH=LwIdPYlxtRreUNnCmWgsaTkGEVKXBz.get('rtmpPlayUrl720')
  except LwIdPYlxtRreUNnCmWgsaTkGEVKXhu as exception:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXhp(exception)
   return ''
  return LwIdPYlxtRreUNnCmWgsaTkGEVKXBH
 def Get_BSList_Json(LwIdPYlxtRreUNnCmWgsaTkGEVKXqi):
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ=[]
  LwIdPYlxtRreUNnCmWgsaTkGEVKXBO=[]
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqb =LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.make_viewdate(dtype='1')
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqb =['20210521']
  try:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqy='https://sports.news.naver.com/scoreboard/index.nhn'
   for LwIdPYlxtRreUNnCmWgsaTkGEVKXiq in LwIdPYlxtRreUNnCmWgsaTkGEVKXqb:
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBy={'date':LwIdPYlxtRreUNnCmWgsaTkGEVKXiq}
    LwIdPYlxtRreUNnCmWgsaTkGEVKXqv=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.callRequestCookies('Get',LwIdPYlxtRreUNnCmWgsaTkGEVKXqy,payload=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,params=LwIdPYlxtRreUNnCmWgsaTkGEVKXBy,headers=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb,cookies=LwIdPYlxtRreUNnCmWgsaTkGEVKXhb)
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXqv.status_code!=200:return[]
    LwIdPYlxtRreUNnCmWgsaTkGEVKXiB=BeautifulSoup(LwIdPYlxtRreUNnCmWgsaTkGEVKXqv.text,'html.parser')
    LwIdPYlxtRreUNnCmWgsaTkGEVKXiB=LwIdPYlxtRreUNnCmWgsaTkGEVKXiB.select_one('#content > div > table > tbody')
    LwIdPYlxtRreUNnCmWgsaTkGEVKXih='%s-%s-%s'%(LwIdPYlxtRreUNnCmWgsaTkGEVKXiq[:4],LwIdPYlxtRreUNnCmWgsaTkGEVKXiq[4:6],LwIdPYlxtRreUNnCmWgsaTkGEVKXiq[-2:])
    LwIdPYlxtRreUNnCmWgsaTkGEVKXij=LwIdPYlxtRreUNnCmWgsaTkGEVKXiB.find('tr')
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBO+=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.Get_NowTag_List(LwIdPYlxtRreUNnCmWgsaTkGEVKXij,LwIdPYlxtRreUNnCmWgsaTkGEVKXih)
    for LwIdPYlxtRreUNnCmWgsaTkGEVKXij in LwIdPYlxtRreUNnCmWgsaTkGEVKXij.next_siblings:
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXhc(LwIdPYlxtRreUNnCmWgsaTkGEVKXhH(LwIdPYlxtRreUNnCmWgsaTkGEVKXij))!="<class 'bs4.element.Tag'>":continue
     LwIdPYlxtRreUNnCmWgsaTkGEVKXBO+=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.Get_NowTag_List(LwIdPYlxtRreUNnCmWgsaTkGEVKXij,LwIdPYlxtRreUNnCmWgsaTkGEVKXih)
    LwIdPYlxtRreUNnCmWgsaTkGEVKXiF=''
    LwIdPYlxtRreUNnCmWgsaTkGEVKXiM=''
    LwIdPYlxtRreUNnCmWgsaTkGEVKXiD =''
    LwIdPYlxtRreUNnCmWgsaTkGEVKXiS=''
    LwIdPYlxtRreUNnCmWgsaTkGEVKXiA=''
    LwIdPYlxtRreUNnCmWgsaTkGEVKXiJ=''
    for LwIdPYlxtRreUNnCmWgsaTkGEVKXib in LwIdPYlxtRreUNnCmWgsaTkGEVKXBO:
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('class')=='game' :LwIdPYlxtRreUNnCmWgsaTkGEVKXiF =LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('cont')
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('class')=='time' :LwIdPYlxtRreUNnCmWgsaTkGEVKXiM =LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('cont')
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('class')=='ing' :LwIdPYlxtRreUNnCmWgsaTkGEVKXiD =LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('cont')
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('class')=='title':LwIdPYlxtRreUNnCmWgsaTkGEVKXiS =LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('cont')
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('class')=='gameId':LwIdPYlxtRreUNnCmWgsaTkGEVKXiA=LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('cont')
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('class')=='relay':
      LwIdPYlxtRreUNnCmWgsaTkGEVKXiy='-'
      for LwIdPYlxtRreUNnCmWgsaTkGEVKXiv in LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('cont'):
       if LwIdPYlxtRreUNnCmWgsaTkGEVKXiv.get('live')in['Y','N']:
        LwIdPYlxtRreUNnCmWgsaTkGEVKXiy=LwIdPYlxtRreUNnCmWgsaTkGEVKXiv.get('live')
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('class')=='place':
      if LwIdPYlxtRreUNnCmWgsaTkGEVKXiy not in['Y','N']:continue
      LwIdPYlxtRreUNnCmWgsaTkGEVKXiJ=LwIdPYlxtRreUNnCmWgsaTkGEVKXib.get('cont')
      LwIdPYlxtRreUNnCmWgsaTkGEVKXiQ={'category':LwIdPYlxtRreUNnCmWgsaTkGEVKXiF,'time':LwIdPYlxtRreUNnCmWgsaTkGEVKXiM,'title':' '.join(LwIdPYlxtRreUNnCmWgsaTkGEVKXiS.split()),'gameId':LwIdPYlxtRreUNnCmWgsaTkGEVKXiA,'live':LwIdPYlxtRreUNnCmWgsaTkGEVKXiy,'ing':LwIdPYlxtRreUNnCmWgsaTkGEVKXiD,'place':LwIdPYlxtRreUNnCmWgsaTkGEVKXiJ,}
      LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXiQ)
  except LwIdPYlxtRreUNnCmWgsaTkGEVKXhu as exception:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXhp(exception)
   return[]
  return LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ
 def Get_NowTag_List(LwIdPYlxtRreUNnCmWgsaTkGEVKXqi,LwIdPYlxtRreUNnCmWgsaTkGEVKXij,LwIdPYlxtRreUNnCmWgsaTkGEVKXih):
  LwIdPYlxtRreUNnCmWgsaTkGEVKXBO=[]
  LwIdPYlxtRreUNnCmWgsaTkGEVKXip=LwIdPYlxtRreUNnCmWgsaTkGEVKXij.find_all('td')
  for LwIdPYlxtRreUNnCmWgsaTkGEVKXiu in LwIdPYlxtRreUNnCmWgsaTkGEVKXip:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXif=LwIdPYlxtRreUNnCmWgsaTkGEVKXiu.get('class')[0]
   if LwIdPYlxtRreUNnCmWgsaTkGEVKXif=='game':
    LwIdPYlxtRreUNnCmWgsaTkGEVKXic={'class':'game','cont':LwIdPYlxtRreUNnCmWgsaTkGEVKXiu.text,}
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBO.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXic)
   elif LwIdPYlxtRreUNnCmWgsaTkGEVKXif=='time':
    LwIdPYlxtRreUNnCmWgsaTkGEVKXic={'class':'time','cont':LwIdPYlxtRreUNnCmWgsaTkGEVKXih+' '+LwIdPYlxtRreUNnCmWgsaTkGEVKXiu.text,}
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBO.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXic)
   elif LwIdPYlxtRreUNnCmWgsaTkGEVKXif=='gameinfo':
    pass
   elif LwIdPYlxtRreUNnCmWgsaTkGEVKXif=='state':
    LwIdPYlxtRreUNnCmWgsaTkGEVKXiH=LwIdPYlxtRreUNnCmWgsaTkGEVKXiu.find_all('img')
    LwIdPYlxtRreUNnCmWgsaTkGEVKXio='-'
    for LwIdPYlxtRreUNnCmWgsaTkGEVKXiz in LwIdPYlxtRreUNnCmWgsaTkGEVKXiH:
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXiz.get('alt')=='진행중':
      LwIdPYlxtRreUNnCmWgsaTkGEVKXio='Y'
    LwIdPYlxtRreUNnCmWgsaTkGEVKXic={'class':'ing','cont':LwIdPYlxtRreUNnCmWgsaTkGEVKXio,}
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBO.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXic)
    LwIdPYlxtRreUNnCmWgsaTkGEVKXic={'class':'title','cont':LwIdPYlxtRreUNnCmWgsaTkGEVKXiu.text,}
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBO.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXic)
   elif LwIdPYlxtRreUNnCmWgsaTkGEVKXif=='relay':
    LwIdPYlxtRreUNnCmWgsaTkGEVKXiO=''
    LwIdPYlxtRreUNnCmWgsaTkGEVKXhq=LwIdPYlxtRreUNnCmWgsaTkGEVKXiu.find('a')
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXhq:
     LwIdPYlxtRreUNnCmWgsaTkGEVKXhB=LwIdPYlxtRreUNnCmWgsaTkGEVKXhq.get('href')
     if "'" in LwIdPYlxtRreUNnCmWgsaTkGEVKXhB:LwIdPYlxtRreUNnCmWgsaTkGEVKXhB=LwIdPYlxtRreUNnCmWgsaTkGEVKXhB.split("'")[1]
     LwIdPYlxtRreUNnCmWgsaTkGEVKXhi=urllib.parse.urlsplit(LwIdPYlxtRreUNnCmWgsaTkGEVKXhB)
     LwIdPYlxtRreUNnCmWgsaTkGEVKXhi=LwIdPYlxtRreUNnCmWgsaTkGEVKXho(urllib.parse.parse_qsl(LwIdPYlxtRreUNnCmWgsaTkGEVKXhi.query))
     LwIdPYlxtRreUNnCmWgsaTkGEVKXiO=LwIdPYlxtRreUNnCmWgsaTkGEVKXhi.get('gameId')
    LwIdPYlxtRreUNnCmWgsaTkGEVKXic={'class':'gameId','cont':LwIdPYlxtRreUNnCmWgsaTkGEVKXiO,}
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBO.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXic)
    LwIdPYlxtRreUNnCmWgsaTkGEVKXiH=LwIdPYlxtRreUNnCmWgsaTkGEVKXiu.find_all('img')
    LwIdPYlxtRreUNnCmWgsaTkGEVKXhj=[]
    for LwIdPYlxtRreUNnCmWgsaTkGEVKXiz in LwIdPYlxtRreUNnCmWgsaTkGEVKXiH:
     LwIdPYlxtRreUNnCmWgsaTkGEVKXhF =LwIdPYlxtRreUNnCmWgsaTkGEVKXiz.get('alt')
     LwIdPYlxtRreUNnCmWgsaTkGEVKXhM=LwIdPYlxtRreUNnCmWgsaTkGEVKXiz.get('onclick')
     LwIdPYlxtRreUNnCmWgsaTkGEVKXhD ='-'
     if LwIdPYlxtRreUNnCmWgsaTkGEVKXhM:
      if "'scb.tv'" in LwIdPYlxtRreUNnCmWgsaTkGEVKXhM:LwIdPYlxtRreUNnCmWgsaTkGEVKXhD='Y'
      elif "'scb.tv_off'" in LwIdPYlxtRreUNnCmWgsaTkGEVKXhM:LwIdPYlxtRreUNnCmWgsaTkGEVKXhD='N'
     LwIdPYlxtRreUNnCmWgsaTkGEVKXhj.append({'alt':LwIdPYlxtRreUNnCmWgsaTkGEVKXhF,'live':LwIdPYlxtRreUNnCmWgsaTkGEVKXhD})
    LwIdPYlxtRreUNnCmWgsaTkGEVKXic={'class':'relay','cont':LwIdPYlxtRreUNnCmWgsaTkGEVKXhj,}
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBO.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXic)
   elif LwIdPYlxtRreUNnCmWgsaTkGEVKXif=='place':
    LwIdPYlxtRreUNnCmWgsaTkGEVKXic={'class':'place','cont':LwIdPYlxtRreUNnCmWgsaTkGEVKXiu.text,}
    LwIdPYlxtRreUNnCmWgsaTkGEVKXBO.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXic)
   else:
    LwIdPYlxtRreUNnCmWgsaTkGEVKXhp(LwIdPYlxtRreUNnCmWgsaTkGEVKXif)
  return LwIdPYlxtRreUNnCmWgsaTkGEVKXBO
 def Get_Category_BSjson(LwIdPYlxtRreUNnCmWgsaTkGEVKXqi):
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ=[]
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqp=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.Get_BSList_Json()
  LwIdPYlxtRreUNnCmWgsaTkGEVKXhS=[]
  for LwIdPYlxtRreUNnCmWgsaTkGEVKXhA in LwIdPYlxtRreUNnCmWgsaTkGEVKXqp:
   if LwIdPYlxtRreUNnCmWgsaTkGEVKXhA.get('category')not in LwIdPYlxtRreUNnCmWgsaTkGEVKXhS:
    LwIdPYlxtRreUNnCmWgsaTkGEVKXhS.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXhA.get('category'))
  for LwIdPYlxtRreUNnCmWgsaTkGEVKXqH in LwIdPYlxtRreUNnCmWgsaTkGEVKXhS:
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqo='N'
   for LwIdPYlxtRreUNnCmWgsaTkGEVKXhA in LwIdPYlxtRreUNnCmWgsaTkGEVKXqp:
    if LwIdPYlxtRreUNnCmWgsaTkGEVKXqH==LwIdPYlxtRreUNnCmWgsaTkGEVKXhA.get('category')and LwIdPYlxtRreUNnCmWgsaTkGEVKXhA.get('ing')=='Y':
     LwIdPYlxtRreUNnCmWgsaTkGEVKXqo='Y'
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqu={'category':LwIdPYlxtRreUNnCmWgsaTkGEVKXqH,'live':LwIdPYlxtRreUNnCmWgsaTkGEVKXqo,}
   LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXqu)
  return LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ
 def Get_Gamelist_BSjson(LwIdPYlxtRreUNnCmWgsaTkGEVKXqi,category):
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ =[]
  LwIdPYlxtRreUNnCmWgsaTkGEVKXqp=LwIdPYlxtRreUNnCmWgsaTkGEVKXqi.Get_BSList_Json()
  for LwIdPYlxtRreUNnCmWgsaTkGEVKXhA in LwIdPYlxtRreUNnCmWgsaTkGEVKXqp:
   if LwIdPYlxtRreUNnCmWgsaTkGEVKXhA.get('category')==category:
    LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ.append(LwIdPYlxtRreUNnCmWgsaTkGEVKXhA)
  return LwIdPYlxtRreUNnCmWgsaTkGEVKXqJ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
