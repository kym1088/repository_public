__author__="NightRain"
JjcMfhUliYguPLdeRFTEsayKIWQVHp=object
JjcMfhUliYguPLdeRFTEsayKIWQVHo=None
JjcMfhUliYguPLdeRFTEsayKIWQVmz=False
JjcMfhUliYguPLdeRFTEsayKIWQVmH=True
JjcMfhUliYguPLdeRFTEsayKIWQVmD=len
JjcMfhUliYguPLdeRFTEsayKIWQVmv=print
JjcMfhUliYguPLdeRFTEsayKIWQVmb=Exception
JjcMfhUliYguPLdeRFTEsayKIWQVmx=int
import urllib
import re
import json
import requests
import datetime
class JjcMfhUliYguPLdeRFTEsayKIWQVzH(JjcMfhUliYguPLdeRFTEsayKIWQVHp):
 def __init__(JjcMfhUliYguPLdeRFTEsayKIWQVzm):
  JjcMfhUliYguPLdeRFTEsayKIWQVzm.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36'
  JjcMfhUliYguPLdeRFTEsayKIWQVzm.DEFAULT_HEADER ={'user-agent':JjcMfhUliYguPLdeRFTEsayKIWQVzm.USER_AGENT}
  JjcMfhUliYguPLdeRFTEsayKIWQVzm.genres=[{'groupnm':'야구','category':['kbaseball']},{'groupnm':'축구','category':['kfootball','wfootball']},{'groupnm':'배구','category':['kvolleyball']},{'groupnm':'골프','category':['golf']},{'groupnm':'기타','category':['others']},]
 def callRequestCookies(JjcMfhUliYguPLdeRFTEsayKIWQVzm,jobtype,JjcMfhUliYguPLdeRFTEsayKIWQVzN,payload=JjcMfhUliYguPLdeRFTEsayKIWQVHo,params=JjcMfhUliYguPLdeRFTEsayKIWQVHo,headers=JjcMfhUliYguPLdeRFTEsayKIWQVHo,cookies=JjcMfhUliYguPLdeRFTEsayKIWQVHo,redirects=JjcMfhUliYguPLdeRFTEsayKIWQVmz):
  JjcMfhUliYguPLdeRFTEsayKIWQVzD=JjcMfhUliYguPLdeRFTEsayKIWQVzm.DEFAULT_HEADER
  if headers:JjcMfhUliYguPLdeRFTEsayKIWQVzD.update(headers)
  if jobtype=='Get':
   JjcMfhUliYguPLdeRFTEsayKIWQVzv=requests.get(JjcMfhUliYguPLdeRFTEsayKIWQVzN,params=params,headers=JjcMfhUliYguPLdeRFTEsayKIWQVzD,cookies=cookies,allow_redirects=redirects)
  else:
   JjcMfhUliYguPLdeRFTEsayKIWQVzv=requests.post(JjcMfhUliYguPLdeRFTEsayKIWQVzN,data=payload,params=params,headers=JjcMfhUliYguPLdeRFTEsayKIWQVzD,cookies=cookies,allow_redirects=redirects)
  return JjcMfhUliYguPLdeRFTEsayKIWQVzv
 def Get_Now_Datetime(JjcMfhUliYguPLdeRFTEsayKIWQVzm):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def make_viewdate(JjcMfhUliYguPLdeRFTEsayKIWQVzm):
  JjcMfhUliYguPLdeRFTEsayKIWQVzx =JjcMfhUliYguPLdeRFTEsayKIWQVzm.Get_Now_Datetime()
  JjcMfhUliYguPLdeRFTEsayKIWQVzX =JjcMfhUliYguPLdeRFTEsayKIWQVzx+datetime.timedelta(days=-1)
  JjcMfhUliYguPLdeRFTEsayKIWQVzC =JjcMfhUliYguPLdeRFTEsayKIWQVzx+datetime.timedelta(days=1)
  JjcMfhUliYguPLdeRFTEsayKIWQVzn=[JjcMfhUliYguPLdeRFTEsayKIWQVzx.strftime('%Y%m%d'),JjcMfhUliYguPLdeRFTEsayKIWQVzX.strftime('%Y%m%d'),JjcMfhUliYguPLdeRFTEsayKIWQVzC.strftime('%Y%m%d'),]
  return JjcMfhUliYguPLdeRFTEsayKIWQVzn
 def Get_Category_List(JjcMfhUliYguPLdeRFTEsayKIWQVzm):
  JjcMfhUliYguPLdeRFTEsayKIWQVzk=[]
  JjcMfhUliYguPLdeRFTEsayKIWQVzO=JjcMfhUliYguPLdeRFTEsayKIWQVzm.make_viewdate()
  try:
   JjcMfhUliYguPLdeRFTEsayKIWQVzN='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   JjcMfhUliYguPLdeRFTEsayKIWQVzr=JjcMfhUliYguPLdeRFTEsayKIWQVzm.callRequestCookies('Get',JjcMfhUliYguPLdeRFTEsayKIWQVzN,payload=JjcMfhUliYguPLdeRFTEsayKIWQVHo,params=JjcMfhUliYguPLdeRFTEsayKIWQVHo,headers=JjcMfhUliYguPLdeRFTEsayKIWQVHo,cookies=JjcMfhUliYguPLdeRFTEsayKIWQVHo,redirects=JjcMfhUliYguPLdeRFTEsayKIWQVmH)
   if JjcMfhUliYguPLdeRFTEsayKIWQVzr.status_code!=200:return[]
   JjcMfhUliYguPLdeRFTEsayKIWQVzS=json.loads(JjcMfhUliYguPLdeRFTEsayKIWQVzr.text)
   JjcMfhUliYguPLdeRFTEsayKIWQVzG=JjcMfhUliYguPLdeRFTEsayKIWQVzS.get('gameList')
   JjcMfhUliYguPLdeRFTEsayKIWQVzw=[]
   for JjcMfhUliYguPLdeRFTEsayKIWQVzt in JjcMfhUliYguPLdeRFTEsayKIWQVzm.genres:
    JjcMfhUliYguPLdeRFTEsayKIWQVzB =JjcMfhUliYguPLdeRFTEsayKIWQVzt.get('groupnm')
    JjcMfhUliYguPLdeRFTEsayKIWQVzA=[]
    JjcMfhUliYguPLdeRFTEsayKIWQVzq ='N'
    if JjcMfhUliYguPLdeRFTEsayKIWQVmD(JjcMfhUliYguPLdeRFTEsayKIWQVzw)!=0:
     JjcMfhUliYguPLdeRFTEsayKIWQVzG =JjcMfhUliYguPLdeRFTEsayKIWQVzw
     JjcMfhUliYguPLdeRFTEsayKIWQVzw=[]
    for JjcMfhUliYguPLdeRFTEsayKIWQVzp in JjcMfhUliYguPLdeRFTEsayKIWQVzG:
     JjcMfhUliYguPLdeRFTEsayKIWQVzo=JjcMfhUliYguPLdeRFTEsayKIWQVzp.get('upperCategoryId')
     JjcMfhUliYguPLdeRFTEsayKIWQVHz =JjcMfhUliYguPLdeRFTEsayKIWQVzp.get('statusCode')
     JjcMfhUliYguPLdeRFTEsayKIWQVHm =JjcMfhUliYguPLdeRFTEsayKIWQVzp.get('isOnAirTv')
     JjcMfhUliYguPLdeRFTEsayKIWQVHD =JjcMfhUliYguPLdeRFTEsayKIWQVzp.get('gameId')
     if JjcMfhUliYguPLdeRFTEsayKIWQVzo in('esports'):continue
     if JjcMfhUliYguPLdeRFTEsayKIWQVHz in('RESULT'):continue
     if JjcMfhUliYguPLdeRFTEsayKIWQVHD[:8]not in JjcMfhUliYguPLdeRFTEsayKIWQVzO:continue
     if JjcMfhUliYguPLdeRFTEsayKIWQVzo in JjcMfhUliYguPLdeRFTEsayKIWQVzt.get('category'):
      if JjcMfhUliYguPLdeRFTEsayKIWQVzo not in JjcMfhUliYguPLdeRFTEsayKIWQVzA:JjcMfhUliYguPLdeRFTEsayKIWQVzA.append(JjcMfhUliYguPLdeRFTEsayKIWQVzo)
      if JjcMfhUliYguPLdeRFTEsayKIWQVHm=='Y':JjcMfhUliYguPLdeRFTEsayKIWQVzq='Y'
     else:
      JjcMfhUliYguPLdeRFTEsayKIWQVzw.append(JjcMfhUliYguPLdeRFTEsayKIWQVzp)
    if JjcMfhUliYguPLdeRFTEsayKIWQVmD(JjcMfhUliYguPLdeRFTEsayKIWQVzA)>0:
     JjcMfhUliYguPLdeRFTEsayKIWQVHv={'groupnm':JjcMfhUliYguPLdeRFTEsayKIWQVzB,'onairyn':JjcMfhUliYguPLdeRFTEsayKIWQVzq,'category':JjcMfhUliYguPLdeRFTEsayKIWQVzA,}
     JjcMfhUliYguPLdeRFTEsayKIWQVzk.append(JjcMfhUliYguPLdeRFTEsayKIWQVHv)
   JjcMfhUliYguPLdeRFTEsayKIWQVzB ='-'
   JjcMfhUliYguPLdeRFTEsayKIWQVzA=[]
   JjcMfhUliYguPLdeRFTEsayKIWQVzq ='N'
   for JjcMfhUliYguPLdeRFTEsayKIWQVzp in JjcMfhUliYguPLdeRFTEsayKIWQVzw:
    JjcMfhUliYguPLdeRFTEsayKIWQVzo=JjcMfhUliYguPLdeRFTEsayKIWQVzp.get('upperCategoryId')
    JjcMfhUliYguPLdeRFTEsayKIWQVHm =JjcMfhUliYguPLdeRFTEsayKIWQVzp.get('isOnAirTv')
    if JjcMfhUliYguPLdeRFTEsayKIWQVzo not in JjcMfhUliYguPLdeRFTEsayKIWQVzA:JjcMfhUliYguPLdeRFTEsayKIWQVzA.append(JjcMfhUliYguPLdeRFTEsayKIWQVzo)
    if JjcMfhUliYguPLdeRFTEsayKIWQVHm=='Y':JjcMfhUliYguPLdeRFTEsayKIWQVzq='Y'
   if JjcMfhUliYguPLdeRFTEsayKIWQVmD(JjcMfhUliYguPLdeRFTEsayKIWQVzA)>0:
    JjcMfhUliYguPLdeRFTEsayKIWQVHv={'groupnm':'-','onairyn':JjcMfhUliYguPLdeRFTEsayKIWQVzq,'category':JjcMfhUliYguPLdeRFTEsayKIWQVzA,}
    JjcMfhUliYguPLdeRFTEsayKIWQVzk.append(JjcMfhUliYguPLdeRFTEsayKIWQVHv)
    JjcMfhUliYguPLdeRFTEsayKIWQVmv(JjcMfhUliYguPLdeRFTEsayKIWQVzB,JjcMfhUliYguPLdeRFTEsayKIWQVzq,JjcMfhUliYguPLdeRFTEsayKIWQVzA)
  except JjcMfhUliYguPLdeRFTEsayKIWQVmb as exception:
   JjcMfhUliYguPLdeRFTEsayKIWQVmv(exception)
   return[]
  return JjcMfhUliYguPLdeRFTEsayKIWQVzk
 def Get_Game_List(JjcMfhUliYguPLdeRFTEsayKIWQVzm,category):
  JjcMfhUliYguPLdeRFTEsayKIWQVHb=category.split(',')
  JjcMfhUliYguPLdeRFTEsayKIWQVzk =[]
  JjcMfhUliYguPLdeRFTEsayKIWQVHx =[]
  JjcMfhUliYguPLdeRFTEsayKIWQVHX =[]
  JjcMfhUliYguPLdeRFTEsayKIWQVzO=JjcMfhUliYguPLdeRFTEsayKIWQVzm.make_viewdate()
  try:
   JjcMfhUliYguPLdeRFTEsayKIWQVzN='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   JjcMfhUliYguPLdeRFTEsayKIWQVzr=JjcMfhUliYguPLdeRFTEsayKIWQVzm.callRequestCookies('Get',JjcMfhUliYguPLdeRFTEsayKIWQVzN,payload=JjcMfhUliYguPLdeRFTEsayKIWQVHo,params=JjcMfhUliYguPLdeRFTEsayKIWQVHo,headers=JjcMfhUliYguPLdeRFTEsayKIWQVHo,cookies=JjcMfhUliYguPLdeRFTEsayKIWQVHo,redirects=JjcMfhUliYguPLdeRFTEsayKIWQVmH)
   if JjcMfhUliYguPLdeRFTEsayKIWQVzr.status_code!=200:return[]
   JjcMfhUliYguPLdeRFTEsayKIWQVzS=json.loads(JjcMfhUliYguPLdeRFTEsayKIWQVzr.text)
   JjcMfhUliYguPLdeRFTEsayKIWQVzG=JjcMfhUliYguPLdeRFTEsayKIWQVzS.get('gameList')
   for JjcMfhUliYguPLdeRFTEsayKIWQVzp in JjcMfhUliYguPLdeRFTEsayKIWQVzG:
    JjcMfhUliYguPLdeRFTEsayKIWQVHD =JjcMfhUliYguPLdeRFTEsayKIWQVzp.get('gameId')
    JjcMfhUliYguPLdeRFTEsayKIWQVzo=JjcMfhUliYguPLdeRFTEsayKIWQVzp.get('upperCategoryId')
    JjcMfhUliYguPLdeRFTEsayKIWQVHC =JjcMfhUliYguPLdeRFTEsayKIWQVzp.get('categoryId')
    JjcMfhUliYguPLdeRFTEsayKIWQVHz =JjcMfhUliYguPLdeRFTEsayKIWQVzp.get('statusCode')
    JjcMfhUliYguPLdeRFTEsayKIWQVHn =JjcMfhUliYguPLdeRFTEsayKIWQVzp.get('statusInfo')
    JjcMfhUliYguPLdeRFTEsayKIWQVHm =JjcMfhUliYguPLdeRFTEsayKIWQVzp.get('isOnAirTv')
    if JjcMfhUliYguPLdeRFTEsayKIWQVzo in('esports'):continue
    if JjcMfhUliYguPLdeRFTEsayKIWQVHz in('RESULT'):continue
    if JjcMfhUliYguPLdeRFTEsayKIWQVzo not in JjcMfhUliYguPLdeRFTEsayKIWQVHb:continue
    if JjcMfhUliYguPLdeRFTEsayKIWQVHD[:8]not in JjcMfhUliYguPLdeRFTEsayKIWQVzO:continue
    JjcMfhUliYguPLdeRFTEsayKIWQVHk=JjcMfhUliYguPLdeRFTEsayKIWQVzm.Get_Game_liveInfo(JjcMfhUliYguPLdeRFTEsayKIWQVHD)
    if JjcMfhUliYguPLdeRFTEsayKIWQVHk.get('chId')==JjcMfhUliYguPLdeRFTEsayKIWQVHo:continue
    JjcMfhUliYguPLdeRFTEsayKIWQVHv={'gameId':JjcMfhUliYguPLdeRFTEsayKIWQVHD,'upperCategoryId':JjcMfhUliYguPLdeRFTEsayKIWQVzo,'categoryId':JjcMfhUliYguPLdeRFTEsayKIWQVHC,'statusCode':JjcMfhUliYguPLdeRFTEsayKIWQVHz,'statusInfo':JjcMfhUliYguPLdeRFTEsayKIWQVHn,'isOnAirTv':JjcMfhUliYguPLdeRFTEsayKIWQVHm,'chId':JjcMfhUliYguPLdeRFTEsayKIWQVHk.get('chId'),'title':JjcMfhUliYguPLdeRFTEsayKIWQVHk.get('title'),'starttime':JjcMfhUliYguPLdeRFTEsayKIWQVHk.get('starttime'),'endTime':JjcMfhUliYguPLdeRFTEsayKIWQVHk.get('endTime'),'maxBitrate':JjcMfhUliYguPLdeRFTEsayKIWQVHk.get('maxBitrate'),}
    if JjcMfhUliYguPLdeRFTEsayKIWQVHm=='Y':
     JjcMfhUliYguPLdeRFTEsayKIWQVHx.append(JjcMfhUliYguPLdeRFTEsayKIWQVHv)
    else:
     JjcMfhUliYguPLdeRFTEsayKIWQVHX.append(JjcMfhUliYguPLdeRFTEsayKIWQVHv)
   JjcMfhUliYguPLdeRFTEsayKIWQVzk=JjcMfhUliYguPLdeRFTEsayKIWQVHx+JjcMfhUliYguPLdeRFTEsayKIWQVHX
  except JjcMfhUliYguPLdeRFTEsayKIWQVmb as exception:
   JjcMfhUliYguPLdeRFTEsayKIWQVmv(exception)
   return[]
  return JjcMfhUliYguPLdeRFTEsayKIWQVzk
 def Get_Game_liveInfo(JjcMfhUliYguPLdeRFTEsayKIWQVzm,JjcMfhUliYguPLdeRFTEsayKIWQVHD):
  JjcMfhUliYguPLdeRFTEsayKIWQVHO={}
  try:
   JjcMfhUliYguPLdeRFTEsayKIWQVzN='https://apis.naver.com/pcLive/livePlatform/liveInfo2'
   JjcMfhUliYguPLdeRFTEsayKIWQVHN={'env':'pc','inclAudCh':'0','svcId':'12002','svcLiveId':JjcMfhUliYguPLdeRFTEsayKIWQVHD,}
   JjcMfhUliYguPLdeRFTEsayKIWQVzr=JjcMfhUliYguPLdeRFTEsayKIWQVzm.callRequestCookies('Get',JjcMfhUliYguPLdeRFTEsayKIWQVzN,payload=JjcMfhUliYguPLdeRFTEsayKIWQVHo,params=JjcMfhUliYguPLdeRFTEsayKIWQVHN,headers=JjcMfhUliYguPLdeRFTEsayKIWQVHo,cookies=JjcMfhUliYguPLdeRFTEsayKIWQVHo,redirects=JjcMfhUliYguPLdeRFTEsayKIWQVmH)
   if JjcMfhUliYguPLdeRFTEsayKIWQVzr.status_code!=200:return[]
   JjcMfhUliYguPLdeRFTEsayKIWQVzS=json.loads(JjcMfhUliYguPLdeRFTEsayKIWQVzr.text)
   JjcMfhUliYguPLdeRFTEsayKIWQVHr =JjcMfhUliYguPLdeRFTEsayKIWQVzS.get('chList')[0].get('chId')
   JjcMfhUliYguPLdeRFTEsayKIWQVHS=JjcMfhUliYguPLdeRFTEsayKIWQVzS.get('chConf').get(JjcMfhUliYguPLdeRFTEsayKIWQVHr)[0].get('id')
   JjcMfhUliYguPLdeRFTEsayKIWQVHG =JjcMfhUliYguPLdeRFTEsayKIWQVzS.get('program')
   JjcMfhUliYguPLdeRFTEsayKIWQVHw =JjcMfhUliYguPLdeRFTEsayKIWQVHG.get('title')
   JjcMfhUliYguPLdeRFTEsayKIWQVHt =JjcMfhUliYguPLdeRFTEsayKIWQVHG.get('startTime')
   JjcMfhUliYguPLdeRFTEsayKIWQVHB =JjcMfhUliYguPLdeRFTEsayKIWQVHG.get('endTime')
   if JjcMfhUliYguPLdeRFTEsayKIWQVHt!=JjcMfhUliYguPLdeRFTEsayKIWQVHo:
    JjcMfhUliYguPLdeRFTEsayKIWQVHt =datetime.datetime.fromtimestamp(JjcMfhUliYguPLdeRFTEsayKIWQVmx(JjcMfhUliYguPLdeRFTEsayKIWQVHt),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:JjcMfhUliYguPLdeRFTEsayKIWQVHt=''
   if JjcMfhUliYguPLdeRFTEsayKIWQVHB!=JjcMfhUliYguPLdeRFTEsayKIWQVHo:
    JjcMfhUliYguPLdeRFTEsayKIWQVHB =datetime.datetime.fromtimestamp(JjcMfhUliYguPLdeRFTEsayKIWQVmx(JjcMfhUliYguPLdeRFTEsayKIWQVHB),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:JjcMfhUliYguPLdeRFTEsayKIWQVHB=''
   JjcMfhUliYguPLdeRFTEsayKIWQVHO={'chId':JjcMfhUliYguPLdeRFTEsayKIWQVHr,'title':JjcMfhUliYguPLdeRFTEsayKIWQVHw,'starttime':JjcMfhUliYguPLdeRFTEsayKIWQVHt,'endTime':JjcMfhUliYguPLdeRFTEsayKIWQVHB,'maxBitrate':JjcMfhUliYguPLdeRFTEsayKIWQVHS,}
  except JjcMfhUliYguPLdeRFTEsayKIWQVmb as exception:
   JjcMfhUliYguPLdeRFTEsayKIWQVmv(exception)
   return{}
  return JjcMfhUliYguPLdeRFTEsayKIWQVHO
 def GetStreamingURL(JjcMfhUliYguPLdeRFTEsayKIWQVzm,channelId,setBitrate,JjcMfhUliYguPLdeRFTEsayKIWQVHS):
  JjcMfhUliYguPLdeRFTEsayKIWQVHA=''
  if JjcMfhUliYguPLdeRFTEsayKIWQVmx(setBitrate)>JjcMfhUliYguPLdeRFTEsayKIWQVmx(JjcMfhUliYguPLdeRFTEsayKIWQVHS):
   JjcMfhUliYguPLdeRFTEsayKIWQVHq=JjcMfhUliYguPLdeRFTEsayKIWQVHS
  else:
   JjcMfhUliYguPLdeRFTEsayKIWQVHq=setBitrate
  try:
   JjcMfhUliYguPLdeRFTEsayKIWQVzN='https://apis.naver.com/pcLive/livePlatform/sUrl'
   JjcMfhUliYguPLdeRFTEsayKIWQVHN={'ch':channelId,'q':JjcMfhUliYguPLdeRFTEsayKIWQVHq,'p':'hls','cc':'KR','env':'pc',}
   JjcMfhUliYguPLdeRFTEsayKIWQVzr=JjcMfhUliYguPLdeRFTEsayKIWQVzm.callRequestCookies('Get',JjcMfhUliYguPLdeRFTEsayKIWQVzN,payload=JjcMfhUliYguPLdeRFTEsayKIWQVHo,params=JjcMfhUliYguPLdeRFTEsayKIWQVHN,headers=JjcMfhUliYguPLdeRFTEsayKIWQVHo,cookies=JjcMfhUliYguPLdeRFTEsayKIWQVHo,redirects=JjcMfhUliYguPLdeRFTEsayKIWQVmH)
   if JjcMfhUliYguPLdeRFTEsayKIWQVzr.status_code!=200:return ''
   JjcMfhUliYguPLdeRFTEsayKIWQVzS=json.loads(JjcMfhUliYguPLdeRFTEsayKIWQVzr.text)
   JjcMfhUliYguPLdeRFTEsayKIWQVHA=JjcMfhUliYguPLdeRFTEsayKIWQVzS.get('secUrl')
  except JjcMfhUliYguPLdeRFTEsayKIWQVmb as exception:
   JjcMfhUliYguPLdeRFTEsayKIWQVmv(exception)
   return ''
  return JjcMfhUliYguPLdeRFTEsayKIWQVHA
# Created by pyminifier (https://github.com/liftoff/pyminifier)
