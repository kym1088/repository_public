__author__="NightRain"
nVAbJcRvYNBoUIjTdQGXDrCfgkymwz=object
nVAbJcRvYNBoUIjTdQGXDrCfgkymwi=None
nVAbJcRvYNBoUIjTdQGXDrCfgkymwO=True
nVAbJcRvYNBoUIjTdQGXDrCfgkymwa=False
nVAbJcRvYNBoUIjTdQGXDrCfgkymws=type
nVAbJcRvYNBoUIjTdQGXDrCfgkymwx=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
nVAbJcRvYNBoUIjTdQGXDrCfgkymtw=[{'title':'경기(게임)별 보기','mode':'CATEGORY_LIST'},{'title':'채널별 보기','mode':'CHANNEL_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'** 경기중이 아닐때에는 시청이 제한될수 있음 **','mode':'XXX'},]
nVAbJcRvYNBoUIjTdQGXDrCfgkymtz=[{'chId':'ad1','title':'Spotv1'},{'chId':'ad2','title':'KBS N Sports'},{'chId':'ad3','title':'SBS Sports'},{'chId':'ad4','title':'MBC Sports'},{'chId':'ad5','title':'Spotv2'},]
from nsportsCore import*
class nVAbJcRvYNBoUIjTdQGXDrCfgkymth(nVAbJcRvYNBoUIjTdQGXDrCfgkymwz):
 def __init__(nVAbJcRvYNBoUIjTdQGXDrCfgkymti,nVAbJcRvYNBoUIjTdQGXDrCfgkymtO,nVAbJcRvYNBoUIjTdQGXDrCfgkymta,nVAbJcRvYNBoUIjTdQGXDrCfgkymts):
  nVAbJcRvYNBoUIjTdQGXDrCfgkymti._addon_url =nVAbJcRvYNBoUIjTdQGXDrCfgkymtO
  nVAbJcRvYNBoUIjTdQGXDrCfgkymti._addon_handle=nVAbJcRvYNBoUIjTdQGXDrCfgkymta
  nVAbJcRvYNBoUIjTdQGXDrCfgkymti.main_params =nVAbJcRvYNBoUIjTdQGXDrCfgkymts
  nVAbJcRvYNBoUIjTdQGXDrCfgkymti.NsportsObj =JjcMfhUliYguPLdeRFTEsayKIWQVzH() 
 def addon_noti(nVAbJcRvYNBoUIjTdQGXDrCfgkymti,sting):
  try:
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtW=xbmcgui.Dialog()
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtW.notification(__addonname__,sting)
  except:
   nVAbJcRvYNBoUIjTdQGXDrCfgkymwi
 def addon_log(nVAbJcRvYNBoUIjTdQGXDrCfgkymti,string):
  try:
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtE=string.encode('utf-8','ignore')
  except:
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtE='addonException: addon_log'
  nVAbJcRvYNBoUIjTdQGXDrCfgkymtF=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,nVAbJcRvYNBoUIjTdQGXDrCfgkymtE),level=nVAbJcRvYNBoUIjTdQGXDrCfgkymtF)
 def get_Bitrate_sel(nVAbJcRvYNBoUIjTdQGXDrCfgkymti):
  nVAbJcRvYNBoUIjTdQGXDrCfgkymtK={'0':'5000','1':'2000','2':'800',}
  return nVAbJcRvYNBoUIjTdQGXDrCfgkymtK.get(__addon__.getSetting('selected_quality'))
 def add_dir(nVAbJcRvYNBoUIjTdQGXDrCfgkymti,label,sublabel='',img='',infoLabels=nVAbJcRvYNBoUIjTdQGXDrCfgkymwi,isFolder=nVAbJcRvYNBoUIjTdQGXDrCfgkymwO,params='',isLink=nVAbJcRvYNBoUIjTdQGXDrCfgkymwa,ContextMenu=nVAbJcRvYNBoUIjTdQGXDrCfgkymwi):
  nVAbJcRvYNBoUIjTdQGXDrCfgkymte='%s?%s'%(nVAbJcRvYNBoUIjTdQGXDrCfgkymti._addon_url,urllib.parse.urlencode(params))
  if sublabel:nVAbJcRvYNBoUIjTdQGXDrCfgkymtL='%s < %s >'%(label,sublabel)
  else: nVAbJcRvYNBoUIjTdQGXDrCfgkymtL=label
  if not img:img='DefaultFolder.png'
  nVAbJcRvYNBoUIjTdQGXDrCfgkymtH=xbmcgui.ListItem(nVAbJcRvYNBoUIjTdQGXDrCfgkymtL)
  if nVAbJcRvYNBoUIjTdQGXDrCfgkymws(img)==nVAbJcRvYNBoUIjTdQGXDrCfgkymwx:
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtH.setArt(img)
  else:
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtH.setArt({'thumb':img,'poster':img})
  if infoLabels:nVAbJcRvYNBoUIjTdQGXDrCfgkymtH.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtH.setProperty('IsPlayable','true')
  if ContextMenu:nVAbJcRvYNBoUIjTdQGXDrCfgkymtH.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(nVAbJcRvYNBoUIjTdQGXDrCfgkymti._addon_handle,nVAbJcRvYNBoUIjTdQGXDrCfgkymte,nVAbJcRvYNBoUIjTdQGXDrCfgkymtH,isFolder)
 def dp_Main_List(nVAbJcRvYNBoUIjTdQGXDrCfgkymti,args):
  for nVAbJcRvYNBoUIjTdQGXDrCfgkymtq in nVAbJcRvYNBoUIjTdQGXDrCfgkymtw:
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtL=nVAbJcRvYNBoUIjTdQGXDrCfgkymtq.get('title')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtS=''
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtM={'mode':nVAbJcRvYNBoUIjTdQGXDrCfgkymtq.get('mode'),}
   if nVAbJcRvYNBoUIjTdQGXDrCfgkymtq.get('mode')in['XXX']:
    nVAbJcRvYNBoUIjTdQGXDrCfgkymtp=nVAbJcRvYNBoUIjTdQGXDrCfgkymwa
    nVAbJcRvYNBoUIjTdQGXDrCfgkymtl =nVAbJcRvYNBoUIjTdQGXDrCfgkymwO
   else:
    nVAbJcRvYNBoUIjTdQGXDrCfgkymtp=nVAbJcRvYNBoUIjTdQGXDrCfgkymwO
    nVAbJcRvYNBoUIjTdQGXDrCfgkymtl =nVAbJcRvYNBoUIjTdQGXDrCfgkymwa
   if 'icon' in nVAbJcRvYNBoUIjTdQGXDrCfgkymtq:nVAbJcRvYNBoUIjTdQGXDrCfgkymtS=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',nVAbJcRvYNBoUIjTdQGXDrCfgkymtq.get('icon')) 
   nVAbJcRvYNBoUIjTdQGXDrCfgkymti.add_dir(nVAbJcRvYNBoUIjTdQGXDrCfgkymtL,sublabel='',img=nVAbJcRvYNBoUIjTdQGXDrCfgkymtS,infoLabels=nVAbJcRvYNBoUIjTdQGXDrCfgkymwi,isFolder=nVAbJcRvYNBoUIjTdQGXDrCfgkymtp,params=nVAbJcRvYNBoUIjTdQGXDrCfgkymtM,isLink=nVAbJcRvYNBoUIjTdQGXDrCfgkymtl)
  xbmcplugin.endOfDirectory(nVAbJcRvYNBoUIjTdQGXDrCfgkymti._addon_handle)
 def dp_Channel_List(nVAbJcRvYNBoUIjTdQGXDrCfgkymti,args):
  nVAbJcRvYNBoUIjTdQGXDrCfgkymtP=nVAbJcRvYNBoUIjTdQGXDrCfgkymti.get_Bitrate_sel()
  for nVAbJcRvYNBoUIjTdQGXDrCfgkymht in nVAbJcRvYNBoUIjTdQGXDrCfgkymtz:
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtL=nVAbJcRvYNBoUIjTdQGXDrCfgkymht.get('title')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhw=nVAbJcRvYNBoUIjTdQGXDrCfgkymht.get('chId')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhz={'mediatype':'episode','title':nVAbJcRvYNBoUIjTdQGXDrCfgkymtL}
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtM={'mode':'LIVE','chId':nVAbJcRvYNBoUIjTdQGXDrCfgkymhw,'maxBitrate':nVAbJcRvYNBoUIjTdQGXDrCfgkymtP,}
   nVAbJcRvYNBoUIjTdQGXDrCfgkymti.add_dir(nVAbJcRvYNBoUIjTdQGXDrCfgkymtL,sublabel='',img='',infoLabels=nVAbJcRvYNBoUIjTdQGXDrCfgkymhz,isFolder=nVAbJcRvYNBoUIjTdQGXDrCfgkymwa,params=nVAbJcRvYNBoUIjTdQGXDrCfgkymtM,isLink=nVAbJcRvYNBoUIjTdQGXDrCfgkymwa)
  xbmcplugin.endOfDirectory(nVAbJcRvYNBoUIjTdQGXDrCfgkymti._addon_handle)
 def dp_Category_List(nVAbJcRvYNBoUIjTdQGXDrCfgkymti,args):
  nVAbJcRvYNBoUIjTdQGXDrCfgkymhi=nVAbJcRvYNBoUIjTdQGXDrCfgkymti.NsportsObj.Get_Category_List()
  for nVAbJcRvYNBoUIjTdQGXDrCfgkymhO in nVAbJcRvYNBoUIjTdQGXDrCfgkymhi:
   nVAbJcRvYNBoUIjTdQGXDrCfgkymha =nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('groupnm')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhs =nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('onairyn')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhx=','.join(nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('category'))
   if nVAbJcRvYNBoUIjTdQGXDrCfgkymhs=='Y':nVAbJcRvYNBoUIjTdQGXDrCfgkymtu='중계중'
   else:nVAbJcRvYNBoUIjTdQGXDrCfgkymtu=''
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtM={'mode':'GAME_LIST','category':nVAbJcRvYNBoUIjTdQGXDrCfgkymhx,}
   nVAbJcRvYNBoUIjTdQGXDrCfgkymti.add_dir(nVAbJcRvYNBoUIjTdQGXDrCfgkymha,sublabel=nVAbJcRvYNBoUIjTdQGXDrCfgkymtu,img='',infoLabels=nVAbJcRvYNBoUIjTdQGXDrCfgkymwi,isFolder=nVAbJcRvYNBoUIjTdQGXDrCfgkymwO,params=nVAbJcRvYNBoUIjTdQGXDrCfgkymtM)
  xbmcplugin.endOfDirectory(nVAbJcRvYNBoUIjTdQGXDrCfgkymti._addon_handle,cacheToDisc=nVAbJcRvYNBoUIjTdQGXDrCfgkymwa)
 def dp_Game_List(nVAbJcRvYNBoUIjTdQGXDrCfgkymti,args):
  nVAbJcRvYNBoUIjTdQGXDrCfgkymhE=args.get('category')
  nVAbJcRvYNBoUIjTdQGXDrCfgkymhi=nVAbJcRvYNBoUIjTdQGXDrCfgkymti.NsportsObj.Get_Game_List(nVAbJcRvYNBoUIjTdQGXDrCfgkymhE)
  for nVAbJcRvYNBoUIjTdQGXDrCfgkymhO in nVAbJcRvYNBoUIjTdQGXDrCfgkymhi:
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhF =nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('gameId')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhK =nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('upperCategoryId')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhe =nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('categoryId')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhL =nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('statusCode')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhH =nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('statusInfo')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhq =nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('isOnAirTv')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhw =nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('chId')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtL =nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('title')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhS =nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('starttime')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhM =nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('endTime')
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhp =nVAbJcRvYNBoUIjTdQGXDrCfgkymhO.get('maxBitrate')
   if nVAbJcRvYNBoUIjTdQGXDrCfgkymtL=='':nVAbJcRvYNBoUIjTdQGXDrCfgkymtL=nVAbJcRvYNBoUIjTdQGXDrCfgkymhF
   if nVAbJcRvYNBoUIjTdQGXDrCfgkymhq=='Y':
    nVAbJcRvYNBoUIjTdQGXDrCfgkymhl='방송중'
   else:
    if nVAbJcRvYNBoUIjTdQGXDrCfgkymhH=='경기취소':
     nVAbJcRvYNBoUIjTdQGXDrCfgkymhl=nVAbJcRvYNBoUIjTdQGXDrCfgkymhH
    else:
     nVAbJcRvYNBoUIjTdQGXDrCfgkymhl=''
   if nVAbJcRvYNBoUIjTdQGXDrCfgkymhS=='':
    nVAbJcRvYNBoUIjTdQGXDrCfgkymtu=nVAbJcRvYNBoUIjTdQGXDrCfgkymhl
   else:
    if nVAbJcRvYNBoUIjTdQGXDrCfgkymhl=='':
     nVAbJcRvYNBoUIjTdQGXDrCfgkymtu=nVAbJcRvYNBoUIjTdQGXDrCfgkymhS
    else:
     nVAbJcRvYNBoUIjTdQGXDrCfgkymtu=nVAbJcRvYNBoUIjTdQGXDrCfgkymhS+' - '+nVAbJcRvYNBoUIjTdQGXDrCfgkymhl
   nVAbJcRvYNBoUIjTdQGXDrCfgkymhz={'mediatype':'episode','title':nVAbJcRvYNBoUIjTdQGXDrCfgkymtL,'plot':'%s\n\n시작 : %s\n종료 : %s'%(nVAbJcRvYNBoUIjTdQGXDrCfgkymtL,nVAbJcRvYNBoUIjTdQGXDrCfgkymhS,nVAbJcRvYNBoUIjTdQGXDrCfgkymhM)}
   nVAbJcRvYNBoUIjTdQGXDrCfgkymtM={'mode':'LIVE','chId':nVAbJcRvYNBoUIjTdQGXDrCfgkymhw,'maxBitrate':nVAbJcRvYNBoUIjTdQGXDrCfgkymhp,}
   nVAbJcRvYNBoUIjTdQGXDrCfgkymti.add_dir(nVAbJcRvYNBoUIjTdQGXDrCfgkymtL,sublabel=nVAbJcRvYNBoUIjTdQGXDrCfgkymtu,img='',infoLabels=nVAbJcRvYNBoUIjTdQGXDrCfgkymhz,isFolder=nVAbJcRvYNBoUIjTdQGXDrCfgkymwa,params=nVAbJcRvYNBoUIjTdQGXDrCfgkymtM)
  xbmcplugin.endOfDirectory(nVAbJcRvYNBoUIjTdQGXDrCfgkymti._addon_handle,cacheToDisc=nVAbJcRvYNBoUIjTdQGXDrCfgkymwa)
 def play_VIDEO(nVAbJcRvYNBoUIjTdQGXDrCfgkymti,args):
  nVAbJcRvYNBoUIjTdQGXDrCfgkymhw =args.get('chId')
  nVAbJcRvYNBoUIjTdQGXDrCfgkymhp =args.get('maxBitrate')
  nVAbJcRvYNBoUIjTdQGXDrCfgkymhu =nVAbJcRvYNBoUIjTdQGXDrCfgkymti.get_Bitrate_sel()
  nVAbJcRvYNBoUIjTdQGXDrCfgkymhP=nVAbJcRvYNBoUIjTdQGXDrCfgkymti.NsportsObj.GetStreamingURL(nVAbJcRvYNBoUIjTdQGXDrCfgkymhw,nVAbJcRvYNBoUIjTdQGXDrCfgkymhu,nVAbJcRvYNBoUIjTdQGXDrCfgkymhp)
  if nVAbJcRvYNBoUIjTdQGXDrCfgkymhP=='':
   nVAbJcRvYNBoUIjTdQGXDrCfgkymti.addon_noti(__language__(30901).encode('utf8'))
   return
  nVAbJcRvYNBoUIjTdQGXDrCfgkymti.addon_log(nVAbJcRvYNBoUIjTdQGXDrCfgkymhP)
  nVAbJcRvYNBoUIjTdQGXDrCfgkymwt=xbmcgui.ListItem(path=nVAbJcRvYNBoUIjTdQGXDrCfgkymhP)
  xbmcplugin.setResolvedUrl(nVAbJcRvYNBoUIjTdQGXDrCfgkymti._addon_handle,nVAbJcRvYNBoUIjTdQGXDrCfgkymwO,nVAbJcRvYNBoUIjTdQGXDrCfgkymwt)
 def nsports_main(nVAbJcRvYNBoUIjTdQGXDrCfgkymti):
  nVAbJcRvYNBoUIjTdQGXDrCfgkymwh=nVAbJcRvYNBoUIjTdQGXDrCfgkymti.main_params.get('mode',nVAbJcRvYNBoUIjTdQGXDrCfgkymwi)
  if nVAbJcRvYNBoUIjTdQGXDrCfgkymwh is nVAbJcRvYNBoUIjTdQGXDrCfgkymwi:
   nVAbJcRvYNBoUIjTdQGXDrCfgkymti.dp_Main_List(nVAbJcRvYNBoUIjTdQGXDrCfgkymti.main_params)
  elif nVAbJcRvYNBoUIjTdQGXDrCfgkymwh=='CATEGORY_LIST':
   nVAbJcRvYNBoUIjTdQGXDrCfgkymti.dp_Category_List(nVAbJcRvYNBoUIjTdQGXDrCfgkymti.main_params)
  elif nVAbJcRvYNBoUIjTdQGXDrCfgkymwh=='GAME_LIST':
   nVAbJcRvYNBoUIjTdQGXDrCfgkymti.dp_Game_List(nVAbJcRvYNBoUIjTdQGXDrCfgkymti.main_params)
  elif nVAbJcRvYNBoUIjTdQGXDrCfgkymwh=='LIVE':
   nVAbJcRvYNBoUIjTdQGXDrCfgkymti.play_VIDEO(nVAbJcRvYNBoUIjTdQGXDrCfgkymti.main_params)
  elif nVAbJcRvYNBoUIjTdQGXDrCfgkymwh=='CHANNEL_LIST':
   nVAbJcRvYNBoUIjTdQGXDrCfgkymti.dp_Channel_List(nVAbJcRvYNBoUIjTdQGXDrCfgkymti.main_params)
  else:
   nVAbJcRvYNBoUIjTdQGXDrCfgkymwi
# Created by pyminifier (https://github.com/liftoff/pyminifier)
