__author__="NightRain"
tTVCgnxBSzqIPoEdHjcGRpQuJbeAvl=object
tTVCgnxBSzqIPoEdHjcGRpQuJbeAvX=None
tTVCgnxBSzqIPoEdHjcGRpQuJbeAvN=True
tTVCgnxBSzqIPoEdHjcGRpQuJbeAvM=False
tTVCgnxBSzqIPoEdHjcGRpQuJbeAvi=type
tTVCgnxBSzqIPoEdHjcGRpQuJbeAvm=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
tTVCgnxBSzqIPoEdHjcGRpQuJbeAUv=[{'title':'경기별 보기','mode':'BS_CATEGORY'},{'title':'채널별 보기','mode':'CHANNEL_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'** 경기중이 아닐때에는 시청이 제한될수 있음 **','mode':'XXX'},]
tTVCgnxBSzqIPoEdHjcGRpQuJbeAUf=[{'chId':'ad1','title':'Spotv1'},{'chId':'ad2','title':'KBS N Sports'},{'chId':'ad3','title':'SBS Sports'},{'chId':'ad4','title':'MBC Sports'},{'chId':'ad5','title':'Spotv2'},]
from nsportsCore import*
class tTVCgnxBSzqIPoEdHjcGRpQuJbeAUF(tTVCgnxBSzqIPoEdHjcGRpQuJbeAvl):
 def __init__(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO,tTVCgnxBSzqIPoEdHjcGRpQuJbeAUh,tTVCgnxBSzqIPoEdHjcGRpQuJbeAUr,tTVCgnxBSzqIPoEdHjcGRpQuJbeAUl):
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO._addon_url =tTVCgnxBSzqIPoEdHjcGRpQuJbeAUh
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO._addon_handle=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUr
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.main_params =tTVCgnxBSzqIPoEdHjcGRpQuJbeAUl
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.NsportsObj =jtIYaVdEphnuJxAMGsmFyBwRkSvWcP() 
 def addon_noti(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO,sting):
  try:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUN=xbmcgui.Dialog()
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUN.notification(__addonname__,sting)
  except:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAvX
 def addon_log(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO,string):
  try:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUM=string.encode('utf-8','ignore')
  except:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUM='addonException: addon_log'
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAUi=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,tTVCgnxBSzqIPoEdHjcGRpQuJbeAUM),level=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUi)
 def get_Bitrate_sel(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO):
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAUm={'0':'5000','1':'2000','2':'800',}
  return tTVCgnxBSzqIPoEdHjcGRpQuJbeAUm.get(__addon__.getSetting('selected_quality'))
 def add_dir(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO,label,sublabel='',img='',infoLabels=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvX,isFolder=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvN,params='',isLink=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvM,ContextMenu=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvX):
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAUs='%s?%s'%(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO._addon_url,urllib.parse.urlencode(params))
  if sublabel:tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa='%s < %s >'%(label,sublabel)
  else: tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa=label
  if not img:img='DefaultFolder.png'
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAUD=xbmcgui.ListItem(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa)
  if tTVCgnxBSzqIPoEdHjcGRpQuJbeAvi(img)==tTVCgnxBSzqIPoEdHjcGRpQuJbeAvm:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUD.setArt(img)
  else:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUD.setArt({'thumb':img,'poster':img})
  if infoLabels:tTVCgnxBSzqIPoEdHjcGRpQuJbeAUD.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUD.setProperty('IsPlayable','true')
  if ContextMenu:tTVCgnxBSzqIPoEdHjcGRpQuJbeAUD.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO._addon_handle,tTVCgnxBSzqIPoEdHjcGRpQuJbeAUs,tTVCgnxBSzqIPoEdHjcGRpQuJbeAUD,isFolder)
 def dp_Main_List(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO,args):
  for tTVCgnxBSzqIPoEdHjcGRpQuJbeAUL in tTVCgnxBSzqIPoEdHjcGRpQuJbeAUv:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUL.get('title')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUk=''
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUK={'mode':tTVCgnxBSzqIPoEdHjcGRpQuJbeAUL.get('mode'),}
   if tTVCgnxBSzqIPoEdHjcGRpQuJbeAUL.get('mode')in['XXX']:
    tTVCgnxBSzqIPoEdHjcGRpQuJbeAUw=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvM
    tTVCgnxBSzqIPoEdHjcGRpQuJbeAUy =tTVCgnxBSzqIPoEdHjcGRpQuJbeAvN
   else:
    tTVCgnxBSzqIPoEdHjcGRpQuJbeAUw=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvN
    tTVCgnxBSzqIPoEdHjcGRpQuJbeAUy =tTVCgnxBSzqIPoEdHjcGRpQuJbeAvM
   if 'icon' in tTVCgnxBSzqIPoEdHjcGRpQuJbeAUL:tTVCgnxBSzqIPoEdHjcGRpQuJbeAUk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',tTVCgnxBSzqIPoEdHjcGRpQuJbeAUL.get('icon')) 
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.add_dir(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa,sublabel='',img=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUk,infoLabels=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvX,isFolder=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUw,params=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUK,isLink=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUy)
  xbmcplugin.endOfDirectory(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO._addon_handle)
 def dp_Channel_List(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO,args):
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAUW=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.get_Bitrate_sel()
  for tTVCgnxBSzqIPoEdHjcGRpQuJbeAFU in tTVCgnxBSzqIPoEdHjcGRpQuJbeAUf:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa=tTVCgnxBSzqIPoEdHjcGRpQuJbeAFU.get('title')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFv=tTVCgnxBSzqIPoEdHjcGRpQuJbeAFU.get('chId')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFf={'mediatype':'episode','title':tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa}
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUK={'mode':'CLIVE','chId':tTVCgnxBSzqIPoEdHjcGRpQuJbeAFv,'maxBitrate':tTVCgnxBSzqIPoEdHjcGRpQuJbeAUW,}
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.add_dir(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa,sublabel='',img='',infoLabels=tTVCgnxBSzqIPoEdHjcGRpQuJbeAFf,isFolder=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvM,params=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUK,isLink=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvM)
  xbmcplugin.endOfDirectory(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO._addon_handle)
 def dp_Category_List(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO,args):
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAFO=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.NsportsObj.Get_Category_List()
  for tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh in tTVCgnxBSzqIPoEdHjcGRpQuJbeAFO:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFr =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('groupnm')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFl =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('onairyn')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFX=','.join(tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('category'))
   if tTVCgnxBSzqIPoEdHjcGRpQuJbeAFl=='Y':tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY='중계중'
   else:tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY=''
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUK={'mode':'GAME_LIST','category':tTVCgnxBSzqIPoEdHjcGRpQuJbeAFX,}
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.add_dir(tTVCgnxBSzqIPoEdHjcGRpQuJbeAFr,sublabel=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY,img='',infoLabels=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvX,isFolder=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvN,params=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUK)
  xbmcplugin.endOfDirectory(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO._addon_handle,cacheToDisc=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvM)
 def dp_Game_List(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO,args):
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAFM=args.get('category')
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAFO=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.NsportsObj.Get_Game_List(tTVCgnxBSzqIPoEdHjcGRpQuJbeAFM)
  for tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh in tTVCgnxBSzqIPoEdHjcGRpQuJbeAFO:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFi =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('gameId')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFm =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('upperCategoryId')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFs =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('categoryId')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFa =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('statusCode')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFD =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('statusInfo')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFL =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('isOnAirTv')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFv =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('chId')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('title')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFk =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('starttime')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFK =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('endTime')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFw =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('maxBitrate')
   if tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa=='':tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa=tTVCgnxBSzqIPoEdHjcGRpQuJbeAFi
   if tTVCgnxBSzqIPoEdHjcGRpQuJbeAFL=='Y':
    tTVCgnxBSzqIPoEdHjcGRpQuJbeAFy='방송중'
   else:
    if tTVCgnxBSzqIPoEdHjcGRpQuJbeAFD=='경기취소':
     tTVCgnxBSzqIPoEdHjcGRpQuJbeAFy=tTVCgnxBSzqIPoEdHjcGRpQuJbeAFD
    else:
     tTVCgnxBSzqIPoEdHjcGRpQuJbeAFy=''
   if tTVCgnxBSzqIPoEdHjcGRpQuJbeAFk=='':
    tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY=tTVCgnxBSzqIPoEdHjcGRpQuJbeAFy
   else:
    if tTVCgnxBSzqIPoEdHjcGRpQuJbeAFy=='':
     tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY=tTVCgnxBSzqIPoEdHjcGRpQuJbeAFk
    else:
     tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY=tTVCgnxBSzqIPoEdHjcGRpQuJbeAFk+' - '+tTVCgnxBSzqIPoEdHjcGRpQuJbeAFy
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFf={'mediatype':'episode','title':tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa,'plot':'%s\n\n시작 : %s\n종료 : %s'%(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa,tTVCgnxBSzqIPoEdHjcGRpQuJbeAFk,tTVCgnxBSzqIPoEdHjcGRpQuJbeAFK)}
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUK={'mode':'LIVE','chId':tTVCgnxBSzqIPoEdHjcGRpQuJbeAFv,'maxBitrate':tTVCgnxBSzqIPoEdHjcGRpQuJbeAFw,'gameId':tTVCgnxBSzqIPoEdHjcGRpQuJbeAFi,}
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.add_dir(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa,sublabel=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY,img='',infoLabels=tTVCgnxBSzqIPoEdHjcGRpQuJbeAFf,isFolder=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvM,params=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUK)
  xbmcplugin.endOfDirectory(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO._addon_handle,cacheToDisc=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvM)
 def dp_BsCategory_List(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO,args):
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAFO=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.NsportsObj.Get_Category_BSjson()
  for tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh in tTVCgnxBSzqIPoEdHjcGRpQuJbeAFO:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFX =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('category')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFY =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('live')
   if tTVCgnxBSzqIPoEdHjcGRpQuJbeAFY=='Y':tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY='중계중'
   else:tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY=''
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUK={'mode':'BS_GAME','category':tTVCgnxBSzqIPoEdHjcGRpQuJbeAFX,}
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.add_dir(tTVCgnxBSzqIPoEdHjcGRpQuJbeAFX,sublabel=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY,img='',infoLabels=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvX,isFolder=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvN,params=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUK)
  xbmcplugin.endOfDirectory(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO._addon_handle,cacheToDisc=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvM)
 def dp_BsGame_List(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO,args):
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAFX=args.get('category')
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAFO=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.NsportsObj.Get_Gamelist_BSjson(tTVCgnxBSzqIPoEdHjcGRpQuJbeAFX)
  for tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh in tTVCgnxBSzqIPoEdHjcGRpQuJbeAFO:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFi =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('gameId')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFW =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('time')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('title')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFY =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('live')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAvU =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('ing')
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAvF =tTVCgnxBSzqIPoEdHjcGRpQuJbeAFh.get('place')
   if tTVCgnxBSzqIPoEdHjcGRpQuJbeAFY=='Y':
    tTVCgnxBSzqIPoEdHjcGRpQuJbeAFy='방송중'
   else:
    tTVCgnxBSzqIPoEdHjcGRpQuJbeAFy=''
   if tTVCgnxBSzqIPoEdHjcGRpQuJbeAFy=='':
    tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY=tTVCgnxBSzqIPoEdHjcGRpQuJbeAFW
   else:
    tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY=tTVCgnxBSzqIPoEdHjcGRpQuJbeAFW+' - '+tTVCgnxBSzqIPoEdHjcGRpQuJbeAFy
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAFf={'mediatype':'episode','title':tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa,'plot':'%s\n\n시간 : %s\n\n%s'%(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa,tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY,tTVCgnxBSzqIPoEdHjcGRpQuJbeAvF)}
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUK={'mode':'LIVE','gameId':tTVCgnxBSzqIPoEdHjcGRpQuJbeAFi,}
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.add_dir(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUa,sublabel=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUY,img='',infoLabels=tTVCgnxBSzqIPoEdHjcGRpQuJbeAFf,isFolder=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvM,params=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUK)
  xbmcplugin.endOfDirectory(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO._addon_handle,cacheToDisc=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvM)
 def play_VIDEO(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO,args):
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAFi =args.get('gameId')
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAvf =tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.get_Bitrate_sel()
  if tTVCgnxBSzqIPoEdHjcGRpQuJbeAFi=='' or tTVCgnxBSzqIPoEdHjcGRpQuJbeAFi==tTVCgnxBSzqIPoEdHjcGRpQuJbeAvX:return
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAvO=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.NsportsObj.GetStreamingRtmp(tTVCgnxBSzqIPoEdHjcGRpQuJbeAFi,tTVCgnxBSzqIPoEdHjcGRpQuJbeAvf)
  if tTVCgnxBSzqIPoEdHjcGRpQuJbeAvO=='':
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.addon_noti(__language__(30901).encode('utf8'))
   return
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.addon_log('gameId : '+tTVCgnxBSzqIPoEdHjcGRpQuJbeAFi)
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.addon_log('GetStreamingRtmp : '+tTVCgnxBSzqIPoEdHjcGRpQuJbeAvO)
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAvh=xbmcgui.ListItem(path=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvO)
  xbmcplugin.setResolvedUrl(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO._addon_handle,tTVCgnxBSzqIPoEdHjcGRpQuJbeAvN,tTVCgnxBSzqIPoEdHjcGRpQuJbeAvh)
 def play_CHANNEL(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO,args):
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAFv =args.get('chId')
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAFw =args.get('maxBitrate')
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAvf =tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.get_Bitrate_sel()
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAvO=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.NsportsObj.GetStreamingURL(tTVCgnxBSzqIPoEdHjcGRpQuJbeAFv,tTVCgnxBSzqIPoEdHjcGRpQuJbeAvf,tTVCgnxBSzqIPoEdHjcGRpQuJbeAFw)
  if tTVCgnxBSzqIPoEdHjcGRpQuJbeAvO=='':
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.addon_noti(__language__(30901).encode('utf8'))
   return
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.addon_log('chId : '+tTVCgnxBSzqIPoEdHjcGRpQuJbeAFv)
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.addon_log('play_CHANNEL : '+tTVCgnxBSzqIPoEdHjcGRpQuJbeAvO)
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAvh=xbmcgui.ListItem(path=tTVCgnxBSzqIPoEdHjcGRpQuJbeAvO)
  xbmcplugin.setResolvedUrl(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO._addon_handle,tTVCgnxBSzqIPoEdHjcGRpQuJbeAvN,tTVCgnxBSzqIPoEdHjcGRpQuJbeAvh)
 def nsports_main(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO):
  tTVCgnxBSzqIPoEdHjcGRpQuJbeAvr=tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.main_params.get('mode',tTVCgnxBSzqIPoEdHjcGRpQuJbeAvX)
  if tTVCgnxBSzqIPoEdHjcGRpQuJbeAvr is tTVCgnxBSzqIPoEdHjcGRpQuJbeAvX:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.dp_Main_List(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.main_params)
  elif tTVCgnxBSzqIPoEdHjcGRpQuJbeAvr=='CATEGORY_LIST':
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.dp_Category_List(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.main_params)
  elif tTVCgnxBSzqIPoEdHjcGRpQuJbeAvr=='BS_CATEGORY':
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.dp_BsCategory_List(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.main_params)
  elif tTVCgnxBSzqIPoEdHjcGRpQuJbeAvr=='GAME_LIST':
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.dp_Game_List(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.main_params)
  elif tTVCgnxBSzqIPoEdHjcGRpQuJbeAvr=='BS_GAME':
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.dp_BsGame_List(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.main_params)
  elif tTVCgnxBSzqIPoEdHjcGRpQuJbeAvr=='LIVE':
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.play_VIDEO(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.main_params)
  elif tTVCgnxBSzqIPoEdHjcGRpQuJbeAvr=='CLIVE':
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.play_CHANNEL(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.main_params)
  elif tTVCgnxBSzqIPoEdHjcGRpQuJbeAvr=='CHANNEL_LIST':
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.dp_Channel_List(tTVCgnxBSzqIPoEdHjcGRpQuJbeAUO.main_params)
  else:
   tTVCgnxBSzqIPoEdHjcGRpQuJbeAvX
# Created by pyminifier (https://github.com/liftoff/pyminifier)
