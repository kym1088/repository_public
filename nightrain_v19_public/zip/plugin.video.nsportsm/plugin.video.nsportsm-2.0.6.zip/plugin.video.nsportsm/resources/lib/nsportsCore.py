__author__="NightRain"
jtIYaVdEphnuJxAMGsmFyBwRkSvWgC=object
jtIYaVdEphnuJxAMGsmFyBwRkSvWge=None
jtIYaVdEphnuJxAMGsmFyBwRkSvWgb=False
jtIYaVdEphnuJxAMGsmFyBwRkSvWgq=True
jtIYaVdEphnuJxAMGsmFyBwRkSvWgX=len
jtIYaVdEphnuJxAMGsmFyBwRkSvWgT=print
jtIYaVdEphnuJxAMGsmFyBwRkSvWgK=Exception
jtIYaVdEphnuJxAMGsmFyBwRkSvWgz=int
jtIYaVdEphnuJxAMGsmFyBwRkSvWgO=str
jtIYaVdEphnuJxAMGsmFyBwRkSvWgi=type
jtIYaVdEphnuJxAMGsmFyBwRkSvWgU=dict
import urllib
import re
import json
import requests
import datetime
from bs4 import BeautifulSoup
class jtIYaVdEphnuJxAMGsmFyBwRkSvWcP(jtIYaVdEphnuJxAMGsmFyBwRkSvWgC):
 def __init__(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL):
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36'
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.DEFAULT_HEADER ={'user-agent':jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.USER_AGENT}
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.genres=[{'groupnm':'야구','category':['kbaseball','wbaseball']},{'groupnm':'축구','category':['kfootball','wfootball']},{'groupnm':'배구','category':['kvolleyball']},{'groupnm':'골프','category':['golf']},{'groupnm':'농구','category':['kbasketball']},{'groupnm':'기타','category':['others']},]
 def callRequestCookies(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL,jobtype,jtIYaVdEphnuJxAMGsmFyBwRkSvWcC,payload=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,params=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,headers=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,cookies=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,redirects=jtIYaVdEphnuJxAMGsmFyBwRkSvWgb):
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcg=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.DEFAULT_HEADER
  if headers:jtIYaVdEphnuJxAMGsmFyBwRkSvWcg.update(headers)
  if jobtype=='Get':
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcf=requests.get(jtIYaVdEphnuJxAMGsmFyBwRkSvWcC,params=params,headers=jtIYaVdEphnuJxAMGsmFyBwRkSvWcg,cookies=cookies,allow_redirects=redirects)
  else:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcf=requests.post(jtIYaVdEphnuJxAMGsmFyBwRkSvWcC,data=payload,params=params,headers=jtIYaVdEphnuJxAMGsmFyBwRkSvWcg,cookies=cookies,allow_redirects=redirects)
  return jtIYaVdEphnuJxAMGsmFyBwRkSvWcf
 def Get_Now_Datetime(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def make_viewdate(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL,dtype='1'):
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcH =jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.Get_Now_Datetime()
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcl =jtIYaVdEphnuJxAMGsmFyBwRkSvWcH+datetime.timedelta(days=-1)
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcN =jtIYaVdEphnuJxAMGsmFyBwRkSvWcH+datetime.timedelta(days=1)
  if dtype=='1':
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcQ=[jtIYaVdEphnuJxAMGsmFyBwRkSvWcH.strftime('%Y%m%d'),]
  elif dtype=='2':
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcQ=[jtIYaVdEphnuJxAMGsmFyBwRkSvWcH.strftime('%Y%m%d'),jtIYaVdEphnuJxAMGsmFyBwRkSvWcN.strftime('%Y%m%d'),]
  elif dtype=='3':
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcQ=[jtIYaVdEphnuJxAMGsmFyBwRkSvWcH.strftime('%Y%m%d'),jtIYaVdEphnuJxAMGsmFyBwRkSvWcl.strftime('%Y%m%d'),jtIYaVdEphnuJxAMGsmFyBwRkSvWcN.strftime('%Y%m%d'),]
  return jtIYaVdEphnuJxAMGsmFyBwRkSvWcQ
 def Get_Category_List(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL):
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcr=[]
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcD=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.make_viewdate(dtype='1')
  try:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcC='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   jtIYaVdEphnuJxAMGsmFyBwRkSvWce=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.callRequestCookies('Get',jtIYaVdEphnuJxAMGsmFyBwRkSvWcC,payload=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,params=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,headers=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,cookies=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,redirects=jtIYaVdEphnuJxAMGsmFyBwRkSvWgq)
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWce.status_code!=200:return[]
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcb=json.loads(jtIYaVdEphnuJxAMGsmFyBwRkSvWce.text)
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcq=jtIYaVdEphnuJxAMGsmFyBwRkSvWcb.get('gameList')
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcX=[]
   for jtIYaVdEphnuJxAMGsmFyBwRkSvWcT in jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.genres:
    jtIYaVdEphnuJxAMGsmFyBwRkSvWcK =jtIYaVdEphnuJxAMGsmFyBwRkSvWcT.get('groupnm')
    jtIYaVdEphnuJxAMGsmFyBwRkSvWcz=[]
    jtIYaVdEphnuJxAMGsmFyBwRkSvWcO ='N'
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWgX(jtIYaVdEphnuJxAMGsmFyBwRkSvWcX)!=0:
     jtIYaVdEphnuJxAMGsmFyBwRkSvWcq =jtIYaVdEphnuJxAMGsmFyBwRkSvWcX
     jtIYaVdEphnuJxAMGsmFyBwRkSvWcX=[]
    for jtIYaVdEphnuJxAMGsmFyBwRkSvWci in jtIYaVdEphnuJxAMGsmFyBwRkSvWcq:
     jtIYaVdEphnuJxAMGsmFyBwRkSvWcU=jtIYaVdEphnuJxAMGsmFyBwRkSvWci.get('upperCategoryId')
     jtIYaVdEphnuJxAMGsmFyBwRkSvWPc =jtIYaVdEphnuJxAMGsmFyBwRkSvWci.get('statusCode')
     jtIYaVdEphnuJxAMGsmFyBwRkSvWPL =jtIYaVdEphnuJxAMGsmFyBwRkSvWci.get('isOnAirTv')
     jtIYaVdEphnuJxAMGsmFyBwRkSvWPg =jtIYaVdEphnuJxAMGsmFyBwRkSvWci.get('gameId')
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWcU in('esports'):continue
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWPc in('RESULT'):continue
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWPg[:8]not in jtIYaVdEphnuJxAMGsmFyBwRkSvWcD and jtIYaVdEphnuJxAMGsmFyBwRkSvWPL!='Y':continue
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWcU in jtIYaVdEphnuJxAMGsmFyBwRkSvWcT.get('category'):
      if jtIYaVdEphnuJxAMGsmFyBwRkSvWcU not in jtIYaVdEphnuJxAMGsmFyBwRkSvWcz:jtIYaVdEphnuJxAMGsmFyBwRkSvWcz.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWcU)
      if jtIYaVdEphnuJxAMGsmFyBwRkSvWPL=='Y':jtIYaVdEphnuJxAMGsmFyBwRkSvWcO='Y'
     else:
      jtIYaVdEphnuJxAMGsmFyBwRkSvWcX.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWci)
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWgX(jtIYaVdEphnuJxAMGsmFyBwRkSvWcz)>0:
     jtIYaVdEphnuJxAMGsmFyBwRkSvWPf={'groupnm':jtIYaVdEphnuJxAMGsmFyBwRkSvWcK,'onairyn':jtIYaVdEphnuJxAMGsmFyBwRkSvWcO,'category':jtIYaVdEphnuJxAMGsmFyBwRkSvWcz,}
     jtIYaVdEphnuJxAMGsmFyBwRkSvWcr.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWPf)
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWgX(jtIYaVdEphnuJxAMGsmFyBwRkSvWcX)==0:break
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcK ='-'
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcz=[]
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcO ='N'
   for jtIYaVdEphnuJxAMGsmFyBwRkSvWci in jtIYaVdEphnuJxAMGsmFyBwRkSvWcX:
    jtIYaVdEphnuJxAMGsmFyBwRkSvWcU=jtIYaVdEphnuJxAMGsmFyBwRkSvWci.get('upperCategoryId')
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPL =jtIYaVdEphnuJxAMGsmFyBwRkSvWci.get('isOnAirTv')
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWcU not in jtIYaVdEphnuJxAMGsmFyBwRkSvWcz:jtIYaVdEphnuJxAMGsmFyBwRkSvWcz.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWcU)
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWPL=='Y':jtIYaVdEphnuJxAMGsmFyBwRkSvWcO='Y'
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWgX(jtIYaVdEphnuJxAMGsmFyBwRkSvWcz)>0:
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPf={'groupnm':'-','onairyn':jtIYaVdEphnuJxAMGsmFyBwRkSvWcO,'category':jtIYaVdEphnuJxAMGsmFyBwRkSvWcz,}
    jtIYaVdEphnuJxAMGsmFyBwRkSvWcr.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWPf)
    jtIYaVdEphnuJxAMGsmFyBwRkSvWgT(jtIYaVdEphnuJxAMGsmFyBwRkSvWcK,jtIYaVdEphnuJxAMGsmFyBwRkSvWcO,jtIYaVdEphnuJxAMGsmFyBwRkSvWcz)
  except jtIYaVdEphnuJxAMGsmFyBwRkSvWgK as exception:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWgT(exception)
   return[]
  return jtIYaVdEphnuJxAMGsmFyBwRkSvWcr
 def Get_Game_List(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL,category):
  jtIYaVdEphnuJxAMGsmFyBwRkSvWPo=category.split(',')
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcr =[]
  jtIYaVdEphnuJxAMGsmFyBwRkSvWPH =[]
  jtIYaVdEphnuJxAMGsmFyBwRkSvWPl =[]
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcD=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.make_viewdate()
  try:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcC='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   jtIYaVdEphnuJxAMGsmFyBwRkSvWce=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.callRequestCookies('Get',jtIYaVdEphnuJxAMGsmFyBwRkSvWcC,payload=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,params=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,headers=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,cookies=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,redirects=jtIYaVdEphnuJxAMGsmFyBwRkSvWgq)
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWce.status_code!=200:return[]
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcb=json.loads(jtIYaVdEphnuJxAMGsmFyBwRkSvWce.text)
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcq=jtIYaVdEphnuJxAMGsmFyBwRkSvWcb.get('gameList')
   for jtIYaVdEphnuJxAMGsmFyBwRkSvWci in jtIYaVdEphnuJxAMGsmFyBwRkSvWcq:
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPg =jtIYaVdEphnuJxAMGsmFyBwRkSvWci.get('gameId')
    jtIYaVdEphnuJxAMGsmFyBwRkSvWcU=jtIYaVdEphnuJxAMGsmFyBwRkSvWci.get('upperCategoryId')
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPN =jtIYaVdEphnuJxAMGsmFyBwRkSvWci.get('categoryId')
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPc =jtIYaVdEphnuJxAMGsmFyBwRkSvWci.get('statusCode')
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPQ =jtIYaVdEphnuJxAMGsmFyBwRkSvWci.get('statusInfo')
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPL =jtIYaVdEphnuJxAMGsmFyBwRkSvWci.get('isOnAirTv')
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWcU in('esports'):continue
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWPc in('RESULT'):continue
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWcU not in jtIYaVdEphnuJxAMGsmFyBwRkSvWPo:continue
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWPg[:8]not in jtIYaVdEphnuJxAMGsmFyBwRkSvWcD and jtIYaVdEphnuJxAMGsmFyBwRkSvWPL!='Y':continue
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPr=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.Get_Game_liveInfo(jtIYaVdEphnuJxAMGsmFyBwRkSvWPg)
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWPr.get('chId')==jtIYaVdEphnuJxAMGsmFyBwRkSvWge:continue
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPf={'gameId':jtIYaVdEphnuJxAMGsmFyBwRkSvWPg,'upperCategoryId':jtIYaVdEphnuJxAMGsmFyBwRkSvWcU,'categoryId':jtIYaVdEphnuJxAMGsmFyBwRkSvWPN,'statusCode':jtIYaVdEphnuJxAMGsmFyBwRkSvWPc,'statusInfo':jtIYaVdEphnuJxAMGsmFyBwRkSvWPQ,'isOnAirTv':jtIYaVdEphnuJxAMGsmFyBwRkSvWPL,'chId':jtIYaVdEphnuJxAMGsmFyBwRkSvWPr.get('chId'),'title':jtIYaVdEphnuJxAMGsmFyBwRkSvWPr.get('title'),'starttime':jtIYaVdEphnuJxAMGsmFyBwRkSvWPr.get('starttime'),'endTime':jtIYaVdEphnuJxAMGsmFyBwRkSvWPr.get('endTime'),'maxBitrate':jtIYaVdEphnuJxAMGsmFyBwRkSvWPr.get('maxBitrate'),}
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWPL=='Y':
     jtIYaVdEphnuJxAMGsmFyBwRkSvWPH.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWPf)
    else:
     jtIYaVdEphnuJxAMGsmFyBwRkSvWPl.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWPf)
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcr=jtIYaVdEphnuJxAMGsmFyBwRkSvWPH+jtIYaVdEphnuJxAMGsmFyBwRkSvWPl
  except jtIYaVdEphnuJxAMGsmFyBwRkSvWgK as exception:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWgT(exception)
   return[]
  return jtIYaVdEphnuJxAMGsmFyBwRkSvWcr
 def Get_Game_liveInfo(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL,jtIYaVdEphnuJxAMGsmFyBwRkSvWPg):
  jtIYaVdEphnuJxAMGsmFyBwRkSvWPD={}
  try:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcC='https://apis.naver.com/pcLive/livePlatform/liveInfo2'
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPC={'env':'pc','inclAudCh':'0','svcId':'12002','svcLiveId':jtIYaVdEphnuJxAMGsmFyBwRkSvWPg,}
   jtIYaVdEphnuJxAMGsmFyBwRkSvWce=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.callRequestCookies('Get',jtIYaVdEphnuJxAMGsmFyBwRkSvWcC,payload=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,params=jtIYaVdEphnuJxAMGsmFyBwRkSvWPC,headers=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,cookies=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,redirects=jtIYaVdEphnuJxAMGsmFyBwRkSvWgq)
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWce.status_code!=200:return[]
   jtIYaVdEphnuJxAMGsmFyBwRkSvWgT(jtIYaVdEphnuJxAMGsmFyBwRkSvWce.text)
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcb=json.loads(jtIYaVdEphnuJxAMGsmFyBwRkSvWce.text)
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPe =jtIYaVdEphnuJxAMGsmFyBwRkSvWcb.get('chList')[0].get('chId')
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPb=jtIYaVdEphnuJxAMGsmFyBwRkSvWcb.get('chConf').get(jtIYaVdEphnuJxAMGsmFyBwRkSvWPe)[0].get('id')
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPq =jtIYaVdEphnuJxAMGsmFyBwRkSvWcb.get('program')
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPX =jtIYaVdEphnuJxAMGsmFyBwRkSvWPq.get('title')
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPT =jtIYaVdEphnuJxAMGsmFyBwRkSvWPq.get('startTime')
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPK =jtIYaVdEphnuJxAMGsmFyBwRkSvWPq.get('endTime')
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWPT!=jtIYaVdEphnuJxAMGsmFyBwRkSvWge:
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPT =datetime.datetime.fromtimestamp(jtIYaVdEphnuJxAMGsmFyBwRkSvWgz(jtIYaVdEphnuJxAMGsmFyBwRkSvWPT),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:jtIYaVdEphnuJxAMGsmFyBwRkSvWPT=''
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWPK!=jtIYaVdEphnuJxAMGsmFyBwRkSvWge:
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPK =datetime.datetime.fromtimestamp(jtIYaVdEphnuJxAMGsmFyBwRkSvWgz(jtIYaVdEphnuJxAMGsmFyBwRkSvWPK),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:jtIYaVdEphnuJxAMGsmFyBwRkSvWPK=''
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPD={'chId':jtIYaVdEphnuJxAMGsmFyBwRkSvWPe,'title':jtIYaVdEphnuJxAMGsmFyBwRkSvWPX,'starttime':jtIYaVdEphnuJxAMGsmFyBwRkSvWPT,'endTime':jtIYaVdEphnuJxAMGsmFyBwRkSvWPK,'maxBitrate':jtIYaVdEphnuJxAMGsmFyBwRkSvWPb,}
  except jtIYaVdEphnuJxAMGsmFyBwRkSvWgK as exception:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWgT(exception)
   return{}
  return jtIYaVdEphnuJxAMGsmFyBwRkSvWPD
 def GetStreamingURL(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL,channelId,setBitrate,jtIYaVdEphnuJxAMGsmFyBwRkSvWPb):
  jtIYaVdEphnuJxAMGsmFyBwRkSvWPz=''
  if jtIYaVdEphnuJxAMGsmFyBwRkSvWgz(setBitrate)>jtIYaVdEphnuJxAMGsmFyBwRkSvWgz(jtIYaVdEphnuJxAMGsmFyBwRkSvWPb):
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPO=jtIYaVdEphnuJxAMGsmFyBwRkSvWPb
  else:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPO=setBitrate
  try:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcC='https://apis.naver.com/pcLive/livePlatform/sUrl'
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPC={'ch':channelId,'q':jtIYaVdEphnuJxAMGsmFyBwRkSvWPO,'p':'hls','cc':'KR','env':'pc',}
   jtIYaVdEphnuJxAMGsmFyBwRkSvWce=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.callRequestCookies('Get',jtIYaVdEphnuJxAMGsmFyBwRkSvWcC,payload=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,params=jtIYaVdEphnuJxAMGsmFyBwRkSvWPC,headers=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,cookies=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,redirects=jtIYaVdEphnuJxAMGsmFyBwRkSvWgq)
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWce.status_code!=200:return ''
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcb=json.loads(jtIYaVdEphnuJxAMGsmFyBwRkSvWce.text)
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPz=jtIYaVdEphnuJxAMGsmFyBwRkSvWcb.get('secUrl')
  except jtIYaVdEphnuJxAMGsmFyBwRkSvWgK as exception:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWgT(exception)
   return ''
  return jtIYaVdEphnuJxAMGsmFyBwRkSvWPz
 def GetStreamingRtmp_bak(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL,jtIYaVdEphnuJxAMGsmFyBwRkSvWPg,setBitrate):
  jtIYaVdEphnuJxAMGsmFyBwRkSvWPz=''
  try:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcC='https://api-gw.sports.naver.com/schedule/%s/lives'%(jtIYaVdEphnuJxAMGsmFyBwRkSvWPg)
   jtIYaVdEphnuJxAMGsmFyBwRkSvWce=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.callRequestCookies('Get',jtIYaVdEphnuJxAMGsmFyBwRkSvWcC,payload=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,params=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,headers=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,cookies=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,redirects=jtIYaVdEphnuJxAMGsmFyBwRkSvWgq)
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWce.status_code!=200:return ''
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcb=json.loads(jtIYaVdEphnuJxAMGsmFyBwRkSvWce.text)
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPi=jtIYaVdEphnuJxAMGsmFyBwRkSvWcb.get('result').get('lives')[0]
   if setBitrate=='5000':
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPz=jtIYaVdEphnuJxAMGsmFyBwRkSvWPi.get('rtmpPlayUrl1080')
   else:
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPz=jtIYaVdEphnuJxAMGsmFyBwRkSvWPi.get('rtmpPlayUrl720')
  except jtIYaVdEphnuJxAMGsmFyBwRkSvWgK as exception:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWgT(exception)
   return ''
  return jtIYaVdEphnuJxAMGsmFyBwRkSvWPz
 def GetStreamingRtmp(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL,jtIYaVdEphnuJxAMGsmFyBwRkSvWPg,setBitrate):
  jtIYaVdEphnuJxAMGsmFyBwRkSvWPz=''
  try:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcC='https://api-gw.sports.naver.com/schedule/%s/lives/first'%(jtIYaVdEphnuJxAMGsmFyBwRkSvWPg)
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPU={'fields':'basic,sportslive'}
   jtIYaVdEphnuJxAMGsmFyBwRkSvWce=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.callRequestCookies('Get',jtIYaVdEphnuJxAMGsmFyBwRkSvWcC,payload=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,params=jtIYaVdEphnuJxAMGsmFyBwRkSvWPU,headers=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,cookies=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,redirects=jtIYaVdEphnuJxAMGsmFyBwRkSvWgq)
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWce.status_code!=200:return ''
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcb=json.loads(jtIYaVdEphnuJxAMGsmFyBwRkSvWce.text)
   jtIYaVdEphnuJxAMGsmFyBwRkSvWLc=jtIYaVdEphnuJxAMGsmFyBwRkSvWcb.get('result').get('liveId')
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWLc=='':return ''
  except jtIYaVdEphnuJxAMGsmFyBwRkSvWgK as exception:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWgT(exception)
   return ''
  try:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcC='https://proxy-gateway.sports.naver.com/livecloud/lives/%s/playback'%(jtIYaVdEphnuJxAMGsmFyBwRkSvWLc)
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPU={'countryCode':'KR','devt':'HTML5_PC','timeMachine':'true','p2p':'true','includeThumbnail':'true',}
   jtIYaVdEphnuJxAMGsmFyBwRkSvWce=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.callRequestCookies('Get',jtIYaVdEphnuJxAMGsmFyBwRkSvWcC,payload=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,params=jtIYaVdEphnuJxAMGsmFyBwRkSvWPU,headers=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,cookies=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,redirects=jtIYaVdEphnuJxAMGsmFyBwRkSvWgq)
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWce.status_code!=200:return ''
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcb=json.loads(jtIYaVdEphnuJxAMGsmFyBwRkSvWce.text)
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPi=jtIYaVdEphnuJxAMGsmFyBwRkSvWcb.get('media')
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWPi=='':return ''
   jtIYaVdEphnuJxAMGsmFyBwRkSvWPz=jtIYaVdEphnuJxAMGsmFyBwRkSvWPi[0].get('path')
  except jtIYaVdEphnuJxAMGsmFyBwRkSvWgK as exception:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWgT(exception)
   return ''
  return jtIYaVdEphnuJxAMGsmFyBwRkSvWPz
 def Get_BSList_Json(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL):
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcr=[]
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcD =jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.make_viewdate(dtype='2')
  try:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcC='https://sports.news.naver.com/scoreboard/index.nhn'
   for jtIYaVdEphnuJxAMGsmFyBwRkSvWLP in jtIYaVdEphnuJxAMGsmFyBwRkSvWcD:
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLg=[]
    jtIYaVdEphnuJxAMGsmFyBwRkSvWPC={'date':jtIYaVdEphnuJxAMGsmFyBwRkSvWLP}
    jtIYaVdEphnuJxAMGsmFyBwRkSvWce=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.callRequestCookies('Get',jtIYaVdEphnuJxAMGsmFyBwRkSvWcC,payload=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,params=jtIYaVdEphnuJxAMGsmFyBwRkSvWPC,headers=jtIYaVdEphnuJxAMGsmFyBwRkSvWge,cookies=jtIYaVdEphnuJxAMGsmFyBwRkSvWge)
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWce.status_code!=200:return[]
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLf=BeautifulSoup(jtIYaVdEphnuJxAMGsmFyBwRkSvWce.text,'html.parser')
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLf=jtIYaVdEphnuJxAMGsmFyBwRkSvWLf.select_one('#content > div > table > tbody')
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLo='%s-%s-%s'%(jtIYaVdEphnuJxAMGsmFyBwRkSvWLP[:4],jtIYaVdEphnuJxAMGsmFyBwRkSvWLP[4:6],jtIYaVdEphnuJxAMGsmFyBwRkSvWLP[-2:])
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLH=jtIYaVdEphnuJxAMGsmFyBwRkSvWLf.find('tr')
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLg+=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.Get_NowTag_List(jtIYaVdEphnuJxAMGsmFyBwRkSvWLH,jtIYaVdEphnuJxAMGsmFyBwRkSvWLo)
    for jtIYaVdEphnuJxAMGsmFyBwRkSvWLH in jtIYaVdEphnuJxAMGsmFyBwRkSvWLH.next_siblings:
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWgO(jtIYaVdEphnuJxAMGsmFyBwRkSvWgi(jtIYaVdEphnuJxAMGsmFyBwRkSvWLH))!="<class 'bs4.element.Tag'>":continue
     jtIYaVdEphnuJxAMGsmFyBwRkSvWLg+=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.Get_NowTag_List(jtIYaVdEphnuJxAMGsmFyBwRkSvWLH,jtIYaVdEphnuJxAMGsmFyBwRkSvWLo)
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLl=''
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLN=''
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLQ =''
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLr=''
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLD=''
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLC=''
    for jtIYaVdEphnuJxAMGsmFyBwRkSvWLe in jtIYaVdEphnuJxAMGsmFyBwRkSvWLg:
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('class')=='game' :jtIYaVdEphnuJxAMGsmFyBwRkSvWLl =jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('cont')
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('class')=='time' :jtIYaVdEphnuJxAMGsmFyBwRkSvWLN =jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('cont')
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('class')=='ing' :jtIYaVdEphnuJxAMGsmFyBwRkSvWLQ =jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('cont')
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('class')=='title':jtIYaVdEphnuJxAMGsmFyBwRkSvWLr =jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('cont')
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('class')=='gameId':jtIYaVdEphnuJxAMGsmFyBwRkSvWLD=jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('cont')
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('class')=='relay':
      jtIYaVdEphnuJxAMGsmFyBwRkSvWLb='-'
      for jtIYaVdEphnuJxAMGsmFyBwRkSvWLq in jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('cont'):
       if jtIYaVdEphnuJxAMGsmFyBwRkSvWLq.get('live')in['Y','N']:
        jtIYaVdEphnuJxAMGsmFyBwRkSvWLb=jtIYaVdEphnuJxAMGsmFyBwRkSvWLq.get('live')
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('class')=='place':
      if jtIYaVdEphnuJxAMGsmFyBwRkSvWLb not in['Y','N']:continue
      jtIYaVdEphnuJxAMGsmFyBwRkSvWLC=jtIYaVdEphnuJxAMGsmFyBwRkSvWLe.get('cont')
      jtIYaVdEphnuJxAMGsmFyBwRkSvWLX={'category':jtIYaVdEphnuJxAMGsmFyBwRkSvWLl,'time':jtIYaVdEphnuJxAMGsmFyBwRkSvWLN,'title':' '.join(jtIYaVdEphnuJxAMGsmFyBwRkSvWLr.split()),'gameId':jtIYaVdEphnuJxAMGsmFyBwRkSvWLD,'live':jtIYaVdEphnuJxAMGsmFyBwRkSvWLb,'ing':jtIYaVdEphnuJxAMGsmFyBwRkSvWLQ,'place':jtIYaVdEphnuJxAMGsmFyBwRkSvWLC,}
      jtIYaVdEphnuJxAMGsmFyBwRkSvWcr.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWLX)
  except jtIYaVdEphnuJxAMGsmFyBwRkSvWgK as exception:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWgT(exception)
   return[]
  return jtIYaVdEphnuJxAMGsmFyBwRkSvWcr
 def Get_NowTag_List(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL,jtIYaVdEphnuJxAMGsmFyBwRkSvWLH,jtIYaVdEphnuJxAMGsmFyBwRkSvWLo):
  jtIYaVdEphnuJxAMGsmFyBwRkSvWLg=[]
  jtIYaVdEphnuJxAMGsmFyBwRkSvWLT=jtIYaVdEphnuJxAMGsmFyBwRkSvWLH.find_all('td')
  for jtIYaVdEphnuJxAMGsmFyBwRkSvWLK in jtIYaVdEphnuJxAMGsmFyBwRkSvWLT:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWLz=jtIYaVdEphnuJxAMGsmFyBwRkSvWLK.get('class')[0]
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWLz=='game':
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLO={'class':'game','cont':jtIYaVdEphnuJxAMGsmFyBwRkSvWLK.text,}
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLg.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWLO)
   elif jtIYaVdEphnuJxAMGsmFyBwRkSvWLz=='time':
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLO={'class':'time','cont':jtIYaVdEphnuJxAMGsmFyBwRkSvWLo+' '+jtIYaVdEphnuJxAMGsmFyBwRkSvWLK.text,}
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLg.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWLO)
   elif jtIYaVdEphnuJxAMGsmFyBwRkSvWLz=='gameinfo':
    pass
   elif jtIYaVdEphnuJxAMGsmFyBwRkSvWLz=='state':
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLi=jtIYaVdEphnuJxAMGsmFyBwRkSvWLK.find_all('img')
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLU='-'
    for jtIYaVdEphnuJxAMGsmFyBwRkSvWgc in jtIYaVdEphnuJxAMGsmFyBwRkSvWLi:
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWgc.get('alt')=='진행중':
      jtIYaVdEphnuJxAMGsmFyBwRkSvWLU='Y'
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLO={'class':'ing','cont':jtIYaVdEphnuJxAMGsmFyBwRkSvWLU,}
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLg.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWLO)
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLO={'class':'title','cont':jtIYaVdEphnuJxAMGsmFyBwRkSvWLK.text,}
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLg.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWLO)
   elif jtIYaVdEphnuJxAMGsmFyBwRkSvWLz=='relay':
    jtIYaVdEphnuJxAMGsmFyBwRkSvWgP=''
    jtIYaVdEphnuJxAMGsmFyBwRkSvWgL=jtIYaVdEphnuJxAMGsmFyBwRkSvWLK.find('a')
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWgL:
     jtIYaVdEphnuJxAMGsmFyBwRkSvWgf=jtIYaVdEphnuJxAMGsmFyBwRkSvWgL.get('href')
     if "'" in jtIYaVdEphnuJxAMGsmFyBwRkSvWgf:jtIYaVdEphnuJxAMGsmFyBwRkSvWgf=jtIYaVdEphnuJxAMGsmFyBwRkSvWgf.split("'")[1]
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWgf.startswith('/game/'):
      jtIYaVdEphnuJxAMGsmFyBwRkSvWgP=jtIYaVdEphnuJxAMGsmFyBwRkSvWgf.split('/')[2]
     elif jtIYaVdEphnuJxAMGsmFyBwRkSvWgf.startswith('/')and '?' in jtIYaVdEphnuJxAMGsmFyBwRkSvWgf:
      jtIYaVdEphnuJxAMGsmFyBwRkSvWgo=urllib.parse.urlsplit(jtIYaVdEphnuJxAMGsmFyBwRkSvWgf)
      jtIYaVdEphnuJxAMGsmFyBwRkSvWgo=jtIYaVdEphnuJxAMGsmFyBwRkSvWgU(urllib.parse.parse_qsl(jtIYaVdEphnuJxAMGsmFyBwRkSvWgo.query))
      jtIYaVdEphnuJxAMGsmFyBwRkSvWgP=jtIYaVdEphnuJxAMGsmFyBwRkSvWgo.get('gameId') 
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLO={'class':'gameId','cont':jtIYaVdEphnuJxAMGsmFyBwRkSvWgP,}
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLg.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWLO)
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLi=jtIYaVdEphnuJxAMGsmFyBwRkSvWLK.find_all('img')
    jtIYaVdEphnuJxAMGsmFyBwRkSvWgH=[]
    for jtIYaVdEphnuJxAMGsmFyBwRkSvWgc in jtIYaVdEphnuJxAMGsmFyBwRkSvWLi:
     jtIYaVdEphnuJxAMGsmFyBwRkSvWgl =jtIYaVdEphnuJxAMGsmFyBwRkSvWgc.get('alt')
     jtIYaVdEphnuJxAMGsmFyBwRkSvWgN=jtIYaVdEphnuJxAMGsmFyBwRkSvWgc.get('onclick')
     jtIYaVdEphnuJxAMGsmFyBwRkSvWgQ ='-'
     if jtIYaVdEphnuJxAMGsmFyBwRkSvWgN:
      if "'scb.tv'" in jtIYaVdEphnuJxAMGsmFyBwRkSvWgN:jtIYaVdEphnuJxAMGsmFyBwRkSvWgQ='Y'
      elif "'scb.tv_off'" in jtIYaVdEphnuJxAMGsmFyBwRkSvWgN:jtIYaVdEphnuJxAMGsmFyBwRkSvWgQ='N'
     jtIYaVdEphnuJxAMGsmFyBwRkSvWgH.append({'alt':jtIYaVdEphnuJxAMGsmFyBwRkSvWgl,'live':jtIYaVdEphnuJxAMGsmFyBwRkSvWgQ})
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLO={'class':'relay','cont':jtIYaVdEphnuJxAMGsmFyBwRkSvWgH,}
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLg.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWLO)
   elif jtIYaVdEphnuJxAMGsmFyBwRkSvWLz=='place':
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLO={'class':'place','cont':jtIYaVdEphnuJxAMGsmFyBwRkSvWLK.text,}
    jtIYaVdEphnuJxAMGsmFyBwRkSvWLg.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWLO)
   else:
    jtIYaVdEphnuJxAMGsmFyBwRkSvWgT(jtIYaVdEphnuJxAMGsmFyBwRkSvWLz)
  return jtIYaVdEphnuJxAMGsmFyBwRkSvWLg
 def Get_Category_BSjson(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL):
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcr=[]
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcq=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.Get_BSList_Json()
  jtIYaVdEphnuJxAMGsmFyBwRkSvWgr=[]
  for jtIYaVdEphnuJxAMGsmFyBwRkSvWgD in jtIYaVdEphnuJxAMGsmFyBwRkSvWcq:
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWgD.get('category')not in jtIYaVdEphnuJxAMGsmFyBwRkSvWgr:
    jtIYaVdEphnuJxAMGsmFyBwRkSvWgr.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWgD.get('category'))
  for jtIYaVdEphnuJxAMGsmFyBwRkSvWcz in jtIYaVdEphnuJxAMGsmFyBwRkSvWgr:
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcO='N'
   for jtIYaVdEphnuJxAMGsmFyBwRkSvWgD in jtIYaVdEphnuJxAMGsmFyBwRkSvWcq:
    if jtIYaVdEphnuJxAMGsmFyBwRkSvWcz==jtIYaVdEphnuJxAMGsmFyBwRkSvWgD.get('category')and jtIYaVdEphnuJxAMGsmFyBwRkSvWgD.get('live')=='Y':
     jtIYaVdEphnuJxAMGsmFyBwRkSvWcO='Y'
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcX={'category':jtIYaVdEphnuJxAMGsmFyBwRkSvWcz,'live':jtIYaVdEphnuJxAMGsmFyBwRkSvWcO,}
   jtIYaVdEphnuJxAMGsmFyBwRkSvWcr.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWcX)
  return jtIYaVdEphnuJxAMGsmFyBwRkSvWcr
 def Get_Gamelist_BSjson(jtIYaVdEphnuJxAMGsmFyBwRkSvWcL,category):
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcr =[]
  jtIYaVdEphnuJxAMGsmFyBwRkSvWcq=jtIYaVdEphnuJxAMGsmFyBwRkSvWcL.Get_BSList_Json()
  for jtIYaVdEphnuJxAMGsmFyBwRkSvWgD in jtIYaVdEphnuJxAMGsmFyBwRkSvWcq:
   if jtIYaVdEphnuJxAMGsmFyBwRkSvWgD.get('category')==category:
    jtIYaVdEphnuJxAMGsmFyBwRkSvWcr.append(jtIYaVdEphnuJxAMGsmFyBwRkSvWgD)
  return jtIYaVdEphnuJxAMGsmFyBwRkSvWcr
# Created by pyminifier (https://github.com/liftoff/pyminifier)
