__author__="NightRain"
PsahWTgApMotrxNBRLUwckbmlfzKnO=object
PsahWTgApMotrxNBRLUwckbmlfzKnE=None
PsahWTgApMotrxNBRLUwckbmlfzKne=False
PsahWTgApMotrxNBRLUwckbmlfzKnQ=True
PsahWTgApMotrxNBRLUwckbmlfzKnu=len
PsahWTgApMotrxNBRLUwckbmlfzKnG=print
PsahWTgApMotrxNBRLUwckbmlfzKnD=Exception
PsahWTgApMotrxNBRLUwckbmlfzKnS=int
PsahWTgApMotrxNBRLUwckbmlfzKnJ=str
PsahWTgApMotrxNBRLUwckbmlfzKnH=type
import urllib
import re
import json
import requests
import datetime
from bs4 import BeautifulSoup
class PsahWTgApMotrxNBRLUwckbmlfzKCV(PsahWTgApMotrxNBRLUwckbmlfzKnO):
 def __init__(PsahWTgApMotrxNBRLUwckbmlfzKCd):
  PsahWTgApMotrxNBRLUwckbmlfzKCd.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36'
  PsahWTgApMotrxNBRLUwckbmlfzKCd.DEFAULT_HEADER ={'user-agent':PsahWTgApMotrxNBRLUwckbmlfzKCd.USER_AGENT}
  PsahWTgApMotrxNBRLUwckbmlfzKCd.genres=[{'groupnm':'야구','category':['kbaseball','wbaseball']},{'groupnm':'축구','category':['kfootball','wfootball']},{'groupnm':'배구','category':['kvolleyball']},{'groupnm':'골프','category':['golf']},{'groupnm':'농구','category':['kbasketball']},{'groupnm':'기타','category':['others']},]
 def callRequestCookies(PsahWTgApMotrxNBRLUwckbmlfzKCd,jobtype,PsahWTgApMotrxNBRLUwckbmlfzKCE,payload=PsahWTgApMotrxNBRLUwckbmlfzKnE,params=PsahWTgApMotrxNBRLUwckbmlfzKnE,headers=PsahWTgApMotrxNBRLUwckbmlfzKnE,cookies=PsahWTgApMotrxNBRLUwckbmlfzKnE,redirects=PsahWTgApMotrxNBRLUwckbmlfzKne):
  PsahWTgApMotrxNBRLUwckbmlfzKCn=PsahWTgApMotrxNBRLUwckbmlfzKCd.DEFAULT_HEADER
  if headers:PsahWTgApMotrxNBRLUwckbmlfzKCn.update(headers)
  if jobtype=='Get':
   PsahWTgApMotrxNBRLUwckbmlfzKCj=requests.get(PsahWTgApMotrxNBRLUwckbmlfzKCE,params=params,headers=PsahWTgApMotrxNBRLUwckbmlfzKCn,cookies=cookies,allow_redirects=redirects)
  else:
   PsahWTgApMotrxNBRLUwckbmlfzKCj=requests.post(PsahWTgApMotrxNBRLUwckbmlfzKCE,data=payload,params=params,headers=PsahWTgApMotrxNBRLUwckbmlfzKCn,cookies=cookies,allow_redirects=redirects)
  return PsahWTgApMotrxNBRLUwckbmlfzKCj
 def Get_Now_Datetime(PsahWTgApMotrxNBRLUwckbmlfzKCd):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def make_viewdate(PsahWTgApMotrxNBRLUwckbmlfzKCd,dtype='1'):
  PsahWTgApMotrxNBRLUwckbmlfzKCF =PsahWTgApMotrxNBRLUwckbmlfzKCd.Get_Now_Datetime()
  PsahWTgApMotrxNBRLUwckbmlfzKCq =PsahWTgApMotrxNBRLUwckbmlfzKCF+datetime.timedelta(days=-1)
  PsahWTgApMotrxNBRLUwckbmlfzKCI =PsahWTgApMotrxNBRLUwckbmlfzKCF+datetime.timedelta(days=1)
  if dtype=='1':
   PsahWTgApMotrxNBRLUwckbmlfzKCX=[PsahWTgApMotrxNBRLUwckbmlfzKCF.strftime('%Y%m%d'),]
  elif dtype=='2':
   PsahWTgApMotrxNBRLUwckbmlfzKCX=[PsahWTgApMotrxNBRLUwckbmlfzKCF.strftime('%Y%m%d'),PsahWTgApMotrxNBRLUwckbmlfzKCI.strftime('%Y%m%d'),]
  elif dtype=='3':
   PsahWTgApMotrxNBRLUwckbmlfzKCX=[PsahWTgApMotrxNBRLUwckbmlfzKCF.strftime('%Y%m%d'),PsahWTgApMotrxNBRLUwckbmlfzKCq.strftime('%Y%m%d'),PsahWTgApMotrxNBRLUwckbmlfzKCI.strftime('%Y%m%d'),]
  return PsahWTgApMotrxNBRLUwckbmlfzKCX
 def Get_Category_List(PsahWTgApMotrxNBRLUwckbmlfzKCd):
  PsahWTgApMotrxNBRLUwckbmlfzKCv=[]
  PsahWTgApMotrxNBRLUwckbmlfzKCO=PsahWTgApMotrxNBRLUwckbmlfzKCd.make_viewdate(dtype='1')
  try:
   PsahWTgApMotrxNBRLUwckbmlfzKCE='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   PsahWTgApMotrxNBRLUwckbmlfzKCe=PsahWTgApMotrxNBRLUwckbmlfzKCd.callRequestCookies('Get',PsahWTgApMotrxNBRLUwckbmlfzKCE,payload=PsahWTgApMotrxNBRLUwckbmlfzKnE,params=PsahWTgApMotrxNBRLUwckbmlfzKnE,headers=PsahWTgApMotrxNBRLUwckbmlfzKnE,cookies=PsahWTgApMotrxNBRLUwckbmlfzKnE,redirects=PsahWTgApMotrxNBRLUwckbmlfzKnQ)
   if PsahWTgApMotrxNBRLUwckbmlfzKCe.status_code!=200:return[]
   PsahWTgApMotrxNBRLUwckbmlfzKCQ=json.loads(PsahWTgApMotrxNBRLUwckbmlfzKCe.text)
   PsahWTgApMotrxNBRLUwckbmlfzKCu=PsahWTgApMotrxNBRLUwckbmlfzKCQ.get('gameList')
   PsahWTgApMotrxNBRLUwckbmlfzKCG=[]
   for PsahWTgApMotrxNBRLUwckbmlfzKCD in PsahWTgApMotrxNBRLUwckbmlfzKCd.genres:
    PsahWTgApMotrxNBRLUwckbmlfzKCS =PsahWTgApMotrxNBRLUwckbmlfzKCD.get('groupnm')
    PsahWTgApMotrxNBRLUwckbmlfzKCJ=[]
    PsahWTgApMotrxNBRLUwckbmlfzKCH ='N'
    if PsahWTgApMotrxNBRLUwckbmlfzKnu(PsahWTgApMotrxNBRLUwckbmlfzKCG)!=0:
     PsahWTgApMotrxNBRLUwckbmlfzKCu =PsahWTgApMotrxNBRLUwckbmlfzKCG
     PsahWTgApMotrxNBRLUwckbmlfzKCG=[]
    for PsahWTgApMotrxNBRLUwckbmlfzKCy in PsahWTgApMotrxNBRLUwckbmlfzKCu:
     PsahWTgApMotrxNBRLUwckbmlfzKCi=PsahWTgApMotrxNBRLUwckbmlfzKCy.get('upperCategoryId')
     PsahWTgApMotrxNBRLUwckbmlfzKVC =PsahWTgApMotrxNBRLUwckbmlfzKCy.get('statusCode')
     PsahWTgApMotrxNBRLUwckbmlfzKVd =PsahWTgApMotrxNBRLUwckbmlfzKCy.get('isOnAirTv')
     PsahWTgApMotrxNBRLUwckbmlfzKVn =PsahWTgApMotrxNBRLUwckbmlfzKCy.get('gameId')
     if PsahWTgApMotrxNBRLUwckbmlfzKCi in('esports'):continue
     if PsahWTgApMotrxNBRLUwckbmlfzKVC in('RESULT'):continue
     if PsahWTgApMotrxNBRLUwckbmlfzKVn[:8]not in PsahWTgApMotrxNBRLUwckbmlfzKCO and PsahWTgApMotrxNBRLUwckbmlfzKVd!='Y':continue
     if PsahWTgApMotrxNBRLUwckbmlfzKCi in PsahWTgApMotrxNBRLUwckbmlfzKCD.get('category'):
      if PsahWTgApMotrxNBRLUwckbmlfzKCi not in PsahWTgApMotrxNBRLUwckbmlfzKCJ:PsahWTgApMotrxNBRLUwckbmlfzKCJ.append(PsahWTgApMotrxNBRLUwckbmlfzKCi)
      if PsahWTgApMotrxNBRLUwckbmlfzKVd=='Y':PsahWTgApMotrxNBRLUwckbmlfzKCH='Y'
     else:
      PsahWTgApMotrxNBRLUwckbmlfzKCG.append(PsahWTgApMotrxNBRLUwckbmlfzKCy)
    if PsahWTgApMotrxNBRLUwckbmlfzKnu(PsahWTgApMotrxNBRLUwckbmlfzKCJ)>0:
     PsahWTgApMotrxNBRLUwckbmlfzKVj={'groupnm':PsahWTgApMotrxNBRLUwckbmlfzKCS,'onairyn':PsahWTgApMotrxNBRLUwckbmlfzKCH,'category':PsahWTgApMotrxNBRLUwckbmlfzKCJ,}
     PsahWTgApMotrxNBRLUwckbmlfzKCv.append(PsahWTgApMotrxNBRLUwckbmlfzKVj)
    if PsahWTgApMotrxNBRLUwckbmlfzKnu(PsahWTgApMotrxNBRLUwckbmlfzKCG)==0:break
   PsahWTgApMotrxNBRLUwckbmlfzKCS ='-'
   PsahWTgApMotrxNBRLUwckbmlfzKCJ=[]
   PsahWTgApMotrxNBRLUwckbmlfzKCH ='N'
   for PsahWTgApMotrxNBRLUwckbmlfzKCy in PsahWTgApMotrxNBRLUwckbmlfzKCG:
    PsahWTgApMotrxNBRLUwckbmlfzKCi=PsahWTgApMotrxNBRLUwckbmlfzKCy.get('upperCategoryId')
    PsahWTgApMotrxNBRLUwckbmlfzKVd =PsahWTgApMotrxNBRLUwckbmlfzKCy.get('isOnAirTv')
    if PsahWTgApMotrxNBRLUwckbmlfzKCi not in PsahWTgApMotrxNBRLUwckbmlfzKCJ:PsahWTgApMotrxNBRLUwckbmlfzKCJ.append(PsahWTgApMotrxNBRLUwckbmlfzKCi)
    if PsahWTgApMotrxNBRLUwckbmlfzKVd=='Y':PsahWTgApMotrxNBRLUwckbmlfzKCH='Y'
   if PsahWTgApMotrxNBRLUwckbmlfzKnu(PsahWTgApMotrxNBRLUwckbmlfzKCJ)>0:
    PsahWTgApMotrxNBRLUwckbmlfzKVj={'groupnm':'-','onairyn':PsahWTgApMotrxNBRLUwckbmlfzKCH,'category':PsahWTgApMotrxNBRLUwckbmlfzKCJ,}
    PsahWTgApMotrxNBRLUwckbmlfzKCv.append(PsahWTgApMotrxNBRLUwckbmlfzKVj)
    PsahWTgApMotrxNBRLUwckbmlfzKnG(PsahWTgApMotrxNBRLUwckbmlfzKCS,PsahWTgApMotrxNBRLUwckbmlfzKCH,PsahWTgApMotrxNBRLUwckbmlfzKCJ)
  except PsahWTgApMotrxNBRLUwckbmlfzKnD as exception:
   PsahWTgApMotrxNBRLUwckbmlfzKnG(exception)
   return[]
  return PsahWTgApMotrxNBRLUwckbmlfzKCv
 def Get_Game_List(PsahWTgApMotrxNBRLUwckbmlfzKCd,category):
  PsahWTgApMotrxNBRLUwckbmlfzKVY=category.split(',')
  PsahWTgApMotrxNBRLUwckbmlfzKCv =[]
  PsahWTgApMotrxNBRLUwckbmlfzKVF =[]
  PsahWTgApMotrxNBRLUwckbmlfzKVq =[]
  PsahWTgApMotrxNBRLUwckbmlfzKCO=PsahWTgApMotrxNBRLUwckbmlfzKCd.make_viewdate()
  try:
   PsahWTgApMotrxNBRLUwckbmlfzKCE='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   PsahWTgApMotrxNBRLUwckbmlfzKCe=PsahWTgApMotrxNBRLUwckbmlfzKCd.callRequestCookies('Get',PsahWTgApMotrxNBRLUwckbmlfzKCE,payload=PsahWTgApMotrxNBRLUwckbmlfzKnE,params=PsahWTgApMotrxNBRLUwckbmlfzKnE,headers=PsahWTgApMotrxNBRLUwckbmlfzKnE,cookies=PsahWTgApMotrxNBRLUwckbmlfzKnE,redirects=PsahWTgApMotrxNBRLUwckbmlfzKnQ)
   if PsahWTgApMotrxNBRLUwckbmlfzKCe.status_code!=200:return[]
   PsahWTgApMotrxNBRLUwckbmlfzKCQ=json.loads(PsahWTgApMotrxNBRLUwckbmlfzKCe.text)
   PsahWTgApMotrxNBRLUwckbmlfzKCu=PsahWTgApMotrxNBRLUwckbmlfzKCQ.get('gameList')
   for PsahWTgApMotrxNBRLUwckbmlfzKCy in PsahWTgApMotrxNBRLUwckbmlfzKCu:
    PsahWTgApMotrxNBRLUwckbmlfzKVn =PsahWTgApMotrxNBRLUwckbmlfzKCy.get('gameId')
    PsahWTgApMotrxNBRLUwckbmlfzKCi=PsahWTgApMotrxNBRLUwckbmlfzKCy.get('upperCategoryId')
    PsahWTgApMotrxNBRLUwckbmlfzKVI =PsahWTgApMotrxNBRLUwckbmlfzKCy.get('categoryId')
    PsahWTgApMotrxNBRLUwckbmlfzKVC =PsahWTgApMotrxNBRLUwckbmlfzKCy.get('statusCode')
    PsahWTgApMotrxNBRLUwckbmlfzKVX =PsahWTgApMotrxNBRLUwckbmlfzKCy.get('statusInfo')
    PsahWTgApMotrxNBRLUwckbmlfzKVd =PsahWTgApMotrxNBRLUwckbmlfzKCy.get('isOnAirTv')
    if PsahWTgApMotrxNBRLUwckbmlfzKCi in('esports'):continue
    if PsahWTgApMotrxNBRLUwckbmlfzKVC in('RESULT'):continue
    if PsahWTgApMotrxNBRLUwckbmlfzKCi not in PsahWTgApMotrxNBRLUwckbmlfzKVY:continue
    if PsahWTgApMotrxNBRLUwckbmlfzKVn[:8]not in PsahWTgApMotrxNBRLUwckbmlfzKCO and PsahWTgApMotrxNBRLUwckbmlfzKVd!='Y':continue
    PsahWTgApMotrxNBRLUwckbmlfzKVv=PsahWTgApMotrxNBRLUwckbmlfzKCd.Get_Game_liveInfo(PsahWTgApMotrxNBRLUwckbmlfzKVn)
    if PsahWTgApMotrxNBRLUwckbmlfzKVv.get('chId')==PsahWTgApMotrxNBRLUwckbmlfzKnE:continue
    PsahWTgApMotrxNBRLUwckbmlfzKVj={'gameId':PsahWTgApMotrxNBRLUwckbmlfzKVn,'upperCategoryId':PsahWTgApMotrxNBRLUwckbmlfzKCi,'categoryId':PsahWTgApMotrxNBRLUwckbmlfzKVI,'statusCode':PsahWTgApMotrxNBRLUwckbmlfzKVC,'statusInfo':PsahWTgApMotrxNBRLUwckbmlfzKVX,'isOnAirTv':PsahWTgApMotrxNBRLUwckbmlfzKVd,'chId':PsahWTgApMotrxNBRLUwckbmlfzKVv.get('chId'),'title':PsahWTgApMotrxNBRLUwckbmlfzKVv.get('title'),'starttime':PsahWTgApMotrxNBRLUwckbmlfzKVv.get('starttime'),'endTime':PsahWTgApMotrxNBRLUwckbmlfzKVv.get('endTime'),'maxBitrate':PsahWTgApMotrxNBRLUwckbmlfzKVv.get('maxBitrate'),}
    if PsahWTgApMotrxNBRLUwckbmlfzKVd=='Y':
     PsahWTgApMotrxNBRLUwckbmlfzKVF.append(PsahWTgApMotrxNBRLUwckbmlfzKVj)
    else:
     PsahWTgApMotrxNBRLUwckbmlfzKVq.append(PsahWTgApMotrxNBRLUwckbmlfzKVj)
   PsahWTgApMotrxNBRLUwckbmlfzKCv=PsahWTgApMotrxNBRLUwckbmlfzKVF+PsahWTgApMotrxNBRLUwckbmlfzKVq
  except PsahWTgApMotrxNBRLUwckbmlfzKnD as exception:
   PsahWTgApMotrxNBRLUwckbmlfzKnG(exception)
   return[]
  return PsahWTgApMotrxNBRLUwckbmlfzKCv
 def Get_Game_liveInfo(PsahWTgApMotrxNBRLUwckbmlfzKCd,PsahWTgApMotrxNBRLUwckbmlfzKVn):
  PsahWTgApMotrxNBRLUwckbmlfzKVO={}
  try:
   PsahWTgApMotrxNBRLUwckbmlfzKCE='https://apis.naver.com/pcLive/livePlatform/liveInfo2'
   PsahWTgApMotrxNBRLUwckbmlfzKVE={'env':'pc','inclAudCh':'0','svcId':'12002','svcLiveId':PsahWTgApMotrxNBRLUwckbmlfzKVn,}
   PsahWTgApMotrxNBRLUwckbmlfzKCe=PsahWTgApMotrxNBRLUwckbmlfzKCd.callRequestCookies('Get',PsahWTgApMotrxNBRLUwckbmlfzKCE,payload=PsahWTgApMotrxNBRLUwckbmlfzKnE,params=PsahWTgApMotrxNBRLUwckbmlfzKVE,headers=PsahWTgApMotrxNBRLUwckbmlfzKnE,cookies=PsahWTgApMotrxNBRLUwckbmlfzKnE,redirects=PsahWTgApMotrxNBRLUwckbmlfzKnQ)
   if PsahWTgApMotrxNBRLUwckbmlfzKCe.status_code!=200:return[]
   PsahWTgApMotrxNBRLUwckbmlfzKCQ=json.loads(PsahWTgApMotrxNBRLUwckbmlfzKCe.text)
   PsahWTgApMotrxNBRLUwckbmlfzKVe =PsahWTgApMotrxNBRLUwckbmlfzKCQ.get('chList')[0].get('chId')
   PsahWTgApMotrxNBRLUwckbmlfzKVQ=PsahWTgApMotrxNBRLUwckbmlfzKCQ.get('chConf').get(PsahWTgApMotrxNBRLUwckbmlfzKVe)[0].get('id')
   PsahWTgApMotrxNBRLUwckbmlfzKVu =PsahWTgApMotrxNBRLUwckbmlfzKCQ.get('program')
   PsahWTgApMotrxNBRLUwckbmlfzKVG =PsahWTgApMotrxNBRLUwckbmlfzKVu.get('title')
   PsahWTgApMotrxNBRLUwckbmlfzKVD =PsahWTgApMotrxNBRLUwckbmlfzKVu.get('startTime')
   PsahWTgApMotrxNBRLUwckbmlfzKVS =PsahWTgApMotrxNBRLUwckbmlfzKVu.get('endTime')
   if PsahWTgApMotrxNBRLUwckbmlfzKVD!=PsahWTgApMotrxNBRLUwckbmlfzKnE:
    PsahWTgApMotrxNBRLUwckbmlfzKVD =datetime.datetime.fromtimestamp(PsahWTgApMotrxNBRLUwckbmlfzKnS(PsahWTgApMotrxNBRLUwckbmlfzKVD),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:PsahWTgApMotrxNBRLUwckbmlfzKVD=''
   if PsahWTgApMotrxNBRLUwckbmlfzKVS!=PsahWTgApMotrxNBRLUwckbmlfzKnE:
    PsahWTgApMotrxNBRLUwckbmlfzKVS =datetime.datetime.fromtimestamp(PsahWTgApMotrxNBRLUwckbmlfzKnS(PsahWTgApMotrxNBRLUwckbmlfzKVS),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:PsahWTgApMotrxNBRLUwckbmlfzKVS=''
   PsahWTgApMotrxNBRLUwckbmlfzKVO={'chId':PsahWTgApMotrxNBRLUwckbmlfzKVe,'title':PsahWTgApMotrxNBRLUwckbmlfzKVG,'starttime':PsahWTgApMotrxNBRLUwckbmlfzKVD,'endTime':PsahWTgApMotrxNBRLUwckbmlfzKVS,'maxBitrate':PsahWTgApMotrxNBRLUwckbmlfzKVQ,}
  except PsahWTgApMotrxNBRLUwckbmlfzKnD as exception:
   PsahWTgApMotrxNBRLUwckbmlfzKnG(exception)
   return{}
  return PsahWTgApMotrxNBRLUwckbmlfzKVO
 def GetStreamingURL(PsahWTgApMotrxNBRLUwckbmlfzKCd,channelId,setBitrate,PsahWTgApMotrxNBRLUwckbmlfzKVQ):
  PsahWTgApMotrxNBRLUwckbmlfzKVJ=''
  if PsahWTgApMotrxNBRLUwckbmlfzKnS(setBitrate)>PsahWTgApMotrxNBRLUwckbmlfzKnS(PsahWTgApMotrxNBRLUwckbmlfzKVQ):
   PsahWTgApMotrxNBRLUwckbmlfzKVH=PsahWTgApMotrxNBRLUwckbmlfzKVQ
  else:
   PsahWTgApMotrxNBRLUwckbmlfzKVH=setBitrate
  try:
   PsahWTgApMotrxNBRLUwckbmlfzKCE='https://apis.naver.com/pcLive/livePlatform/sUrl'
   PsahWTgApMotrxNBRLUwckbmlfzKVE={'ch':channelId,'q':PsahWTgApMotrxNBRLUwckbmlfzKVH,'p':'hls','cc':'KR','env':'pc',}
   PsahWTgApMotrxNBRLUwckbmlfzKCe=PsahWTgApMotrxNBRLUwckbmlfzKCd.callRequestCookies('Get',PsahWTgApMotrxNBRLUwckbmlfzKCE,payload=PsahWTgApMotrxNBRLUwckbmlfzKnE,params=PsahWTgApMotrxNBRLUwckbmlfzKVE,headers=PsahWTgApMotrxNBRLUwckbmlfzKnE,cookies=PsahWTgApMotrxNBRLUwckbmlfzKnE,redirects=PsahWTgApMotrxNBRLUwckbmlfzKnQ)
   if PsahWTgApMotrxNBRLUwckbmlfzKCe.status_code!=200:return ''
   PsahWTgApMotrxNBRLUwckbmlfzKCQ=json.loads(PsahWTgApMotrxNBRLUwckbmlfzKCe.text)
   PsahWTgApMotrxNBRLUwckbmlfzKVJ=PsahWTgApMotrxNBRLUwckbmlfzKCQ.get('secUrl')
  except PsahWTgApMotrxNBRLUwckbmlfzKnD as exception:
   PsahWTgApMotrxNBRLUwckbmlfzKnG(exception)
   return ''
  return PsahWTgApMotrxNBRLUwckbmlfzKVJ
 def GetStreamingRtmp_bak(PsahWTgApMotrxNBRLUwckbmlfzKCd,PsahWTgApMotrxNBRLUwckbmlfzKVn,setBitrate):
  PsahWTgApMotrxNBRLUwckbmlfzKVJ=''
  try:
   PsahWTgApMotrxNBRLUwckbmlfzKCE='https://api-gw.sports.naver.com/schedule/%s/lives'%(PsahWTgApMotrxNBRLUwckbmlfzKVn)
   PsahWTgApMotrxNBRLUwckbmlfzKCe=PsahWTgApMotrxNBRLUwckbmlfzKCd.callRequestCookies('Get',PsahWTgApMotrxNBRLUwckbmlfzKCE,payload=PsahWTgApMotrxNBRLUwckbmlfzKnE,params=PsahWTgApMotrxNBRLUwckbmlfzKnE,headers=PsahWTgApMotrxNBRLUwckbmlfzKnE,cookies=PsahWTgApMotrxNBRLUwckbmlfzKnE,redirects=PsahWTgApMotrxNBRLUwckbmlfzKnQ)
   if PsahWTgApMotrxNBRLUwckbmlfzKCe.status_code!=200:return ''
   PsahWTgApMotrxNBRLUwckbmlfzKCQ=json.loads(PsahWTgApMotrxNBRLUwckbmlfzKCe.text)
   PsahWTgApMotrxNBRLUwckbmlfzKVy=PsahWTgApMotrxNBRLUwckbmlfzKCQ.get('result').get('lives')[0]
   if setBitrate=='5000':
    PsahWTgApMotrxNBRLUwckbmlfzKVJ=PsahWTgApMotrxNBRLUwckbmlfzKVy.get('rtmpPlayUrl1080')
   else:
    PsahWTgApMotrxNBRLUwckbmlfzKVJ=PsahWTgApMotrxNBRLUwckbmlfzKVy.get('rtmpPlayUrl720')
  except PsahWTgApMotrxNBRLUwckbmlfzKnD as exception:
   PsahWTgApMotrxNBRLUwckbmlfzKnG(exception)
   return ''
  return PsahWTgApMotrxNBRLUwckbmlfzKVJ
 def GetStreamingRtmp(PsahWTgApMotrxNBRLUwckbmlfzKCd,PsahWTgApMotrxNBRLUwckbmlfzKVn,setBitrate):
  PsahWTgApMotrxNBRLUwckbmlfzKVJ=''
  try:
   PsahWTgApMotrxNBRLUwckbmlfzKCE='https://api-gw.sports.naver.com/schedule/%s/lives/first'%(PsahWTgApMotrxNBRLUwckbmlfzKVn)
   PsahWTgApMotrxNBRLUwckbmlfzKVi={'fields':'basic,sportslive'}
   PsahWTgApMotrxNBRLUwckbmlfzKCe=PsahWTgApMotrxNBRLUwckbmlfzKCd.callRequestCookies('Get',PsahWTgApMotrxNBRLUwckbmlfzKCE,payload=PsahWTgApMotrxNBRLUwckbmlfzKnE,params=PsahWTgApMotrxNBRLUwckbmlfzKVi,headers=PsahWTgApMotrxNBRLUwckbmlfzKnE,cookies=PsahWTgApMotrxNBRLUwckbmlfzKnE,redirects=PsahWTgApMotrxNBRLUwckbmlfzKnQ)
   if PsahWTgApMotrxNBRLUwckbmlfzKCe.status_code!=200:return ''
   PsahWTgApMotrxNBRLUwckbmlfzKCQ=json.loads(PsahWTgApMotrxNBRLUwckbmlfzKCe.text)
   PsahWTgApMotrxNBRLUwckbmlfzKdC=PsahWTgApMotrxNBRLUwckbmlfzKCQ.get('result').get('liveId')
   if PsahWTgApMotrxNBRLUwckbmlfzKdC=='':return ''
  except PsahWTgApMotrxNBRLUwckbmlfzKnD as exception:
   PsahWTgApMotrxNBRLUwckbmlfzKnG(exception)
   return ''
  try:
   PsahWTgApMotrxNBRLUwckbmlfzKCE='https://proxy-gateway.sports.naver.com/livecloud/lives/%s/playback'%(PsahWTgApMotrxNBRLUwckbmlfzKdC)
   PsahWTgApMotrxNBRLUwckbmlfzKVi={'countryCode':'KR','devt':'HTML5_PC','timeMachine':'true','p2p':'true','includeThumbnail':'true',}
   PsahWTgApMotrxNBRLUwckbmlfzKCe=PsahWTgApMotrxNBRLUwckbmlfzKCd.callRequestCookies('Get',PsahWTgApMotrxNBRLUwckbmlfzKCE,payload=PsahWTgApMotrxNBRLUwckbmlfzKnE,params=PsahWTgApMotrxNBRLUwckbmlfzKVi,headers=PsahWTgApMotrxNBRLUwckbmlfzKnE,cookies=PsahWTgApMotrxNBRLUwckbmlfzKnE,redirects=PsahWTgApMotrxNBRLUwckbmlfzKnQ)
   if PsahWTgApMotrxNBRLUwckbmlfzKCe.status_code!=200:return ''
   PsahWTgApMotrxNBRLUwckbmlfzKCQ=json.loads(PsahWTgApMotrxNBRLUwckbmlfzKCe.text)
   PsahWTgApMotrxNBRLUwckbmlfzKVy=PsahWTgApMotrxNBRLUwckbmlfzKCQ.get('media')
   if PsahWTgApMotrxNBRLUwckbmlfzKVy=='':return ''
   PsahWTgApMotrxNBRLUwckbmlfzKVJ=PsahWTgApMotrxNBRLUwckbmlfzKVy[0].get('path')
  except PsahWTgApMotrxNBRLUwckbmlfzKnD as exception:
   PsahWTgApMotrxNBRLUwckbmlfzKnG(exception)
   return ''
  return PsahWTgApMotrxNBRLUwckbmlfzKVJ
 def Get_BSList_Json(PsahWTgApMotrxNBRLUwckbmlfzKCd):
  PsahWTgApMotrxNBRLUwckbmlfzKCv=[]
  PsahWTgApMotrxNBRLUwckbmlfzKCO =PsahWTgApMotrxNBRLUwckbmlfzKCd.make_viewdate(dtype='2')
  try:
   PsahWTgApMotrxNBRLUwckbmlfzKCE='https://sports.news.naver.com/scoreboard/index.nhn'
   for PsahWTgApMotrxNBRLUwckbmlfzKdV in PsahWTgApMotrxNBRLUwckbmlfzKCO:
    PsahWTgApMotrxNBRLUwckbmlfzKdn=[]
    PsahWTgApMotrxNBRLUwckbmlfzKVE={'date':PsahWTgApMotrxNBRLUwckbmlfzKdV}
    PsahWTgApMotrxNBRLUwckbmlfzKCe=PsahWTgApMotrxNBRLUwckbmlfzKCd.callRequestCookies('Get',PsahWTgApMotrxNBRLUwckbmlfzKCE,payload=PsahWTgApMotrxNBRLUwckbmlfzKnE,params=PsahWTgApMotrxNBRLUwckbmlfzKVE,headers=PsahWTgApMotrxNBRLUwckbmlfzKnE,cookies=PsahWTgApMotrxNBRLUwckbmlfzKnE)
    if PsahWTgApMotrxNBRLUwckbmlfzKCe.status_code!=200:return[]
    PsahWTgApMotrxNBRLUwckbmlfzKdj=BeautifulSoup(PsahWTgApMotrxNBRLUwckbmlfzKCe.text,'html.parser')
    PsahWTgApMotrxNBRLUwckbmlfzKdj=PsahWTgApMotrxNBRLUwckbmlfzKdj.select_one('#content > div > table > tbody')
    PsahWTgApMotrxNBRLUwckbmlfzKdY='%s-%s-%s'%(PsahWTgApMotrxNBRLUwckbmlfzKdV[:4],PsahWTgApMotrxNBRLUwckbmlfzKdV[4:6],PsahWTgApMotrxNBRLUwckbmlfzKdV[-2:])
    PsahWTgApMotrxNBRLUwckbmlfzKdF=PsahWTgApMotrxNBRLUwckbmlfzKdj.find('tr')
    PsahWTgApMotrxNBRLUwckbmlfzKdn+=PsahWTgApMotrxNBRLUwckbmlfzKCd.Get_NowTag_List(PsahWTgApMotrxNBRLUwckbmlfzKdF,PsahWTgApMotrxNBRLUwckbmlfzKdY)
    for PsahWTgApMotrxNBRLUwckbmlfzKdF in PsahWTgApMotrxNBRLUwckbmlfzKdF.next_siblings:
     if PsahWTgApMotrxNBRLUwckbmlfzKnJ(PsahWTgApMotrxNBRLUwckbmlfzKnH(PsahWTgApMotrxNBRLUwckbmlfzKdF))!="<class 'bs4.element.Tag'>":continue
     PsahWTgApMotrxNBRLUwckbmlfzKdn+=PsahWTgApMotrxNBRLUwckbmlfzKCd.Get_NowTag_List(PsahWTgApMotrxNBRLUwckbmlfzKdF,PsahWTgApMotrxNBRLUwckbmlfzKdY)
    PsahWTgApMotrxNBRLUwckbmlfzKdq=''
    PsahWTgApMotrxNBRLUwckbmlfzKdI=''
    PsahWTgApMotrxNBRLUwckbmlfzKdX =''
    PsahWTgApMotrxNBRLUwckbmlfzKdv=''
    PsahWTgApMotrxNBRLUwckbmlfzKdO=''
    PsahWTgApMotrxNBRLUwckbmlfzKdE=''
    for PsahWTgApMotrxNBRLUwckbmlfzKde in PsahWTgApMotrxNBRLUwckbmlfzKdn:
     if PsahWTgApMotrxNBRLUwckbmlfzKde.get('class')=='game' :PsahWTgApMotrxNBRLUwckbmlfzKdq =PsahWTgApMotrxNBRLUwckbmlfzKde.get('cont')
     if PsahWTgApMotrxNBRLUwckbmlfzKde.get('class')=='time' :PsahWTgApMotrxNBRLUwckbmlfzKdI =PsahWTgApMotrxNBRLUwckbmlfzKde.get('cont')
     if PsahWTgApMotrxNBRLUwckbmlfzKde.get('class')=='ing' :PsahWTgApMotrxNBRLUwckbmlfzKdX =PsahWTgApMotrxNBRLUwckbmlfzKde.get('cont')
     if PsahWTgApMotrxNBRLUwckbmlfzKde.get('class')=='title':PsahWTgApMotrxNBRLUwckbmlfzKdv =PsahWTgApMotrxNBRLUwckbmlfzKde.get('cont')
     if PsahWTgApMotrxNBRLUwckbmlfzKde.get('class')=='gameId':PsahWTgApMotrxNBRLUwckbmlfzKdO=PsahWTgApMotrxNBRLUwckbmlfzKde.get('cont')
     if PsahWTgApMotrxNBRLUwckbmlfzKde.get('class')=='relay':
      PsahWTgApMotrxNBRLUwckbmlfzKdQ='-'
      for PsahWTgApMotrxNBRLUwckbmlfzKdu in PsahWTgApMotrxNBRLUwckbmlfzKde.get('cont'):
       if PsahWTgApMotrxNBRLUwckbmlfzKdu.get('live')in['Y','N']:
        PsahWTgApMotrxNBRLUwckbmlfzKdQ=PsahWTgApMotrxNBRLUwckbmlfzKdu.get('live')
     if PsahWTgApMotrxNBRLUwckbmlfzKde.get('class')=='place':
      if PsahWTgApMotrxNBRLUwckbmlfzKdQ not in['Y','N']:continue
      PsahWTgApMotrxNBRLUwckbmlfzKdE=PsahWTgApMotrxNBRLUwckbmlfzKde.get('cont')
      PsahWTgApMotrxNBRLUwckbmlfzKdG={'category':PsahWTgApMotrxNBRLUwckbmlfzKdq,'time':PsahWTgApMotrxNBRLUwckbmlfzKdI,'title':' '.join(PsahWTgApMotrxNBRLUwckbmlfzKdv.split()),'gameId':PsahWTgApMotrxNBRLUwckbmlfzKdO,'live':PsahWTgApMotrxNBRLUwckbmlfzKdQ,'ing':PsahWTgApMotrxNBRLUwckbmlfzKdX,'place':PsahWTgApMotrxNBRLUwckbmlfzKdE,}
      PsahWTgApMotrxNBRLUwckbmlfzKCv.append(PsahWTgApMotrxNBRLUwckbmlfzKdG)
  except PsahWTgApMotrxNBRLUwckbmlfzKnD as exception:
   PsahWTgApMotrxNBRLUwckbmlfzKnG(exception)
   return[]
  return PsahWTgApMotrxNBRLUwckbmlfzKCv
 def Get_NowTag_List(PsahWTgApMotrxNBRLUwckbmlfzKCd,PsahWTgApMotrxNBRLUwckbmlfzKdF,PsahWTgApMotrxNBRLUwckbmlfzKdY):
  PsahWTgApMotrxNBRLUwckbmlfzKdn=[]
  PsahWTgApMotrxNBRLUwckbmlfzKdD=PsahWTgApMotrxNBRLUwckbmlfzKdF.find_all('td')
  for PsahWTgApMotrxNBRLUwckbmlfzKdS in PsahWTgApMotrxNBRLUwckbmlfzKdD:
   PsahWTgApMotrxNBRLUwckbmlfzKdJ=PsahWTgApMotrxNBRLUwckbmlfzKdS.get('class')[0]
   if PsahWTgApMotrxNBRLUwckbmlfzKdJ=='game':
    PsahWTgApMotrxNBRLUwckbmlfzKdH={'class':'game','cont':PsahWTgApMotrxNBRLUwckbmlfzKdS.text,}
    PsahWTgApMotrxNBRLUwckbmlfzKdn.append(PsahWTgApMotrxNBRLUwckbmlfzKdH)
   elif PsahWTgApMotrxNBRLUwckbmlfzKdJ=='time':
    PsahWTgApMotrxNBRLUwckbmlfzKdH={'class':'time','cont':PsahWTgApMotrxNBRLUwckbmlfzKdY+' '+PsahWTgApMotrxNBRLUwckbmlfzKdS.text,}
    PsahWTgApMotrxNBRLUwckbmlfzKdn.append(PsahWTgApMotrxNBRLUwckbmlfzKdH)
   elif PsahWTgApMotrxNBRLUwckbmlfzKdJ=='gameinfo':
    pass
   elif PsahWTgApMotrxNBRLUwckbmlfzKdJ=='state':
    PsahWTgApMotrxNBRLUwckbmlfzKdy=PsahWTgApMotrxNBRLUwckbmlfzKdS.find_all('img')
    PsahWTgApMotrxNBRLUwckbmlfzKdi='-'
    for PsahWTgApMotrxNBRLUwckbmlfzKnC in PsahWTgApMotrxNBRLUwckbmlfzKdy:
     if PsahWTgApMotrxNBRLUwckbmlfzKnC.get('alt')=='진행중':
      PsahWTgApMotrxNBRLUwckbmlfzKdi='Y'
    PsahWTgApMotrxNBRLUwckbmlfzKdH={'class':'ing','cont':PsahWTgApMotrxNBRLUwckbmlfzKdi,}
    PsahWTgApMotrxNBRLUwckbmlfzKdn.append(PsahWTgApMotrxNBRLUwckbmlfzKdH)
    PsahWTgApMotrxNBRLUwckbmlfzKdH={'class':'title','cont':PsahWTgApMotrxNBRLUwckbmlfzKdS.text,}
    PsahWTgApMotrxNBRLUwckbmlfzKdn.append(PsahWTgApMotrxNBRLUwckbmlfzKdH)
   elif PsahWTgApMotrxNBRLUwckbmlfzKdJ=='relay':
    PsahWTgApMotrxNBRLUwckbmlfzKnV=''
    PsahWTgApMotrxNBRLUwckbmlfzKnd=PsahWTgApMotrxNBRLUwckbmlfzKdS.find('a')
    if PsahWTgApMotrxNBRLUwckbmlfzKnd:
     PsahWTgApMotrxNBRLUwckbmlfzKnj=PsahWTgApMotrxNBRLUwckbmlfzKnd.get('href')
     if "'" in PsahWTgApMotrxNBRLUwckbmlfzKnj:PsahWTgApMotrxNBRLUwckbmlfzKnj=PsahWTgApMotrxNBRLUwckbmlfzKnj.split("'")[1]
     if '/' in PsahWTgApMotrxNBRLUwckbmlfzKnj:
      PsahWTgApMotrxNBRLUwckbmlfzKnV=PsahWTgApMotrxNBRLUwckbmlfzKnj.split('/')[2]
    PsahWTgApMotrxNBRLUwckbmlfzKdH={'class':'gameId','cont':PsahWTgApMotrxNBRLUwckbmlfzKnV,}
    PsahWTgApMotrxNBRLUwckbmlfzKdn.append(PsahWTgApMotrxNBRLUwckbmlfzKdH)
    PsahWTgApMotrxNBRLUwckbmlfzKdy=PsahWTgApMotrxNBRLUwckbmlfzKdS.find_all('img')
    PsahWTgApMotrxNBRLUwckbmlfzKnY=[]
    for PsahWTgApMotrxNBRLUwckbmlfzKnC in PsahWTgApMotrxNBRLUwckbmlfzKdy:
     PsahWTgApMotrxNBRLUwckbmlfzKnF =PsahWTgApMotrxNBRLUwckbmlfzKnC.get('alt')
     PsahWTgApMotrxNBRLUwckbmlfzKnq=PsahWTgApMotrxNBRLUwckbmlfzKnC.get('onclick')
     PsahWTgApMotrxNBRLUwckbmlfzKnI ='-'
     if PsahWTgApMotrxNBRLUwckbmlfzKnq:
      if "'scb.tv'" in PsahWTgApMotrxNBRLUwckbmlfzKnq:PsahWTgApMotrxNBRLUwckbmlfzKnI='Y'
      elif "'scb.tv_off'" in PsahWTgApMotrxNBRLUwckbmlfzKnq:PsahWTgApMotrxNBRLUwckbmlfzKnI='N'
     PsahWTgApMotrxNBRLUwckbmlfzKnY.append({'alt':PsahWTgApMotrxNBRLUwckbmlfzKnF,'live':PsahWTgApMotrxNBRLUwckbmlfzKnI})
    PsahWTgApMotrxNBRLUwckbmlfzKdH={'class':'relay','cont':PsahWTgApMotrxNBRLUwckbmlfzKnY,}
    PsahWTgApMotrxNBRLUwckbmlfzKdn.append(PsahWTgApMotrxNBRLUwckbmlfzKdH)
   elif PsahWTgApMotrxNBRLUwckbmlfzKdJ=='place':
    PsahWTgApMotrxNBRLUwckbmlfzKdH={'class':'place','cont':PsahWTgApMotrxNBRLUwckbmlfzKdS.text,}
    PsahWTgApMotrxNBRLUwckbmlfzKdn.append(PsahWTgApMotrxNBRLUwckbmlfzKdH)
   else:
    PsahWTgApMotrxNBRLUwckbmlfzKnG(PsahWTgApMotrxNBRLUwckbmlfzKdJ)
  return PsahWTgApMotrxNBRLUwckbmlfzKdn
 def Get_Category_BSjson(PsahWTgApMotrxNBRLUwckbmlfzKCd):
  PsahWTgApMotrxNBRLUwckbmlfzKCv=[]
  PsahWTgApMotrxNBRLUwckbmlfzKCu=PsahWTgApMotrxNBRLUwckbmlfzKCd.Get_BSList_Json()
  PsahWTgApMotrxNBRLUwckbmlfzKnX=[]
  for PsahWTgApMotrxNBRLUwckbmlfzKnv in PsahWTgApMotrxNBRLUwckbmlfzKCu:
   if PsahWTgApMotrxNBRLUwckbmlfzKnv.get('category')not in PsahWTgApMotrxNBRLUwckbmlfzKnX:
    PsahWTgApMotrxNBRLUwckbmlfzKnX.append(PsahWTgApMotrxNBRLUwckbmlfzKnv.get('category'))
  for PsahWTgApMotrxNBRLUwckbmlfzKCJ in PsahWTgApMotrxNBRLUwckbmlfzKnX:
   PsahWTgApMotrxNBRLUwckbmlfzKCH='N'
   for PsahWTgApMotrxNBRLUwckbmlfzKnv in PsahWTgApMotrxNBRLUwckbmlfzKCu:
    if PsahWTgApMotrxNBRLUwckbmlfzKCJ==PsahWTgApMotrxNBRLUwckbmlfzKnv.get('category')and PsahWTgApMotrxNBRLUwckbmlfzKnv.get('live')=='Y':
     PsahWTgApMotrxNBRLUwckbmlfzKCH='Y'
   PsahWTgApMotrxNBRLUwckbmlfzKCG={'category':PsahWTgApMotrxNBRLUwckbmlfzKCJ,'live':PsahWTgApMotrxNBRLUwckbmlfzKCH,}
   PsahWTgApMotrxNBRLUwckbmlfzKCv.append(PsahWTgApMotrxNBRLUwckbmlfzKCG)
  return PsahWTgApMotrxNBRLUwckbmlfzKCv
 def Get_Gamelist_BSjson(PsahWTgApMotrxNBRLUwckbmlfzKCd,category):
  PsahWTgApMotrxNBRLUwckbmlfzKCv =[]
  PsahWTgApMotrxNBRLUwckbmlfzKCu=PsahWTgApMotrxNBRLUwckbmlfzKCd.Get_BSList_Json()
  for PsahWTgApMotrxNBRLUwckbmlfzKnv in PsahWTgApMotrxNBRLUwckbmlfzKCu:
   if PsahWTgApMotrxNBRLUwckbmlfzKnv.get('category')==category:
    PsahWTgApMotrxNBRLUwckbmlfzKCv.append(PsahWTgApMotrxNBRLUwckbmlfzKnv)
  return PsahWTgApMotrxNBRLUwckbmlfzKCv
# Created by pyminifier (https://github.com/liftoff/pyminifier)
