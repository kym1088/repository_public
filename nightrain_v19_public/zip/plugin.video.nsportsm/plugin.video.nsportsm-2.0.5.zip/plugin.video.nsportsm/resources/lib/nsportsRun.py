__author__="NightRain"
xJLenDXfgksUYoNpTSivKlPrHmajVB=object
xJLenDXfgksUYoNpTSivKlPrHmajVQ=None
xJLenDXfgksUYoNpTSivKlPrHmajVC=True
xJLenDXfgksUYoNpTSivKlPrHmajVb=False
xJLenDXfgksUYoNpTSivKlPrHmajVM=type
xJLenDXfgksUYoNpTSivKlPrHmajVW=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
xJLenDXfgksUYoNpTSivKlPrHmajhV=[{'title':'경기별 보기 (타입1)','mode':'CATEGORY_LIST'},{'title':'경기별 보기 (타입2)','mode':'BS_CATEGORY'},{'title':'채널별 보기','mode':'CHANNEL_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'** 경기중이 아닐때에는 시청이 제한될수 있음 **','mode':'XXX'},]
xJLenDXfgksUYoNpTSivKlPrHmajhu=[{'chId':'ad1','title':'Spotv1'},{'chId':'ad2','title':'KBS N Sports'},{'chId':'ad3','title':'SBS Sports'},{'chId':'ad4','title':'MBC Sports'},{'chId':'ad5','title':'Spotv2'},]
from nsportsCore import*
class xJLenDXfgksUYoNpTSivKlPrHmajhF(xJLenDXfgksUYoNpTSivKlPrHmajVB):
 def __init__(xJLenDXfgksUYoNpTSivKlPrHmajhO,xJLenDXfgksUYoNpTSivKlPrHmajhw,xJLenDXfgksUYoNpTSivKlPrHmajhq,xJLenDXfgksUYoNpTSivKlPrHmajhB):
  xJLenDXfgksUYoNpTSivKlPrHmajhO._addon_url =xJLenDXfgksUYoNpTSivKlPrHmajhw
  xJLenDXfgksUYoNpTSivKlPrHmajhO._addon_handle=xJLenDXfgksUYoNpTSivKlPrHmajhq
  xJLenDXfgksUYoNpTSivKlPrHmajhO.main_params =xJLenDXfgksUYoNpTSivKlPrHmajhB
  xJLenDXfgksUYoNpTSivKlPrHmajhO.NsportsObj =PsahWTgApMotrxNBRLUwckbmlfzKCV() 
 def addon_noti(xJLenDXfgksUYoNpTSivKlPrHmajhO,sting):
  try:
   xJLenDXfgksUYoNpTSivKlPrHmajhC=xbmcgui.Dialog()
   xJLenDXfgksUYoNpTSivKlPrHmajhC.notification(__addonname__,sting)
  except:
   xJLenDXfgksUYoNpTSivKlPrHmajVQ
 def addon_log(xJLenDXfgksUYoNpTSivKlPrHmajhO,string):
  try:
   xJLenDXfgksUYoNpTSivKlPrHmajhb=string.encode('utf-8','ignore')
  except:
   xJLenDXfgksUYoNpTSivKlPrHmajhb='addonException: addon_log'
  xJLenDXfgksUYoNpTSivKlPrHmajhM=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,xJLenDXfgksUYoNpTSivKlPrHmajhb),level=xJLenDXfgksUYoNpTSivKlPrHmajhM)
 def get_Bitrate_sel(xJLenDXfgksUYoNpTSivKlPrHmajhO):
  xJLenDXfgksUYoNpTSivKlPrHmajhW={'0':'5000','1':'2000','2':'800',}
  return xJLenDXfgksUYoNpTSivKlPrHmajhW.get(__addon__.getSetting('selected_quality'))
 def add_dir(xJLenDXfgksUYoNpTSivKlPrHmajhO,label,sublabel='',img='',infoLabels=xJLenDXfgksUYoNpTSivKlPrHmajVQ,isFolder=xJLenDXfgksUYoNpTSivKlPrHmajVC,params='',isLink=xJLenDXfgksUYoNpTSivKlPrHmajVb,ContextMenu=xJLenDXfgksUYoNpTSivKlPrHmajVQ):
  xJLenDXfgksUYoNpTSivKlPrHmajhz='%s?%s'%(xJLenDXfgksUYoNpTSivKlPrHmajhO._addon_url,urllib.parse.urlencode(params))
  if sublabel:xJLenDXfgksUYoNpTSivKlPrHmajhy='%s < %s >'%(label,sublabel)
  else: xJLenDXfgksUYoNpTSivKlPrHmajhy=label
  if not img:img='DefaultFolder.png'
  xJLenDXfgksUYoNpTSivKlPrHmajhA=xbmcgui.ListItem(xJLenDXfgksUYoNpTSivKlPrHmajhy)
  if xJLenDXfgksUYoNpTSivKlPrHmajVM(img)==xJLenDXfgksUYoNpTSivKlPrHmajVW:
   xJLenDXfgksUYoNpTSivKlPrHmajhA.setArt(img)
  else:
   xJLenDXfgksUYoNpTSivKlPrHmajhA.setArt({'thumb':img,'poster':img})
  if infoLabels:xJLenDXfgksUYoNpTSivKlPrHmajhA.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   xJLenDXfgksUYoNpTSivKlPrHmajhA.setProperty('IsPlayable','true')
  if ContextMenu:xJLenDXfgksUYoNpTSivKlPrHmajhA.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(xJLenDXfgksUYoNpTSivKlPrHmajhO._addon_handle,xJLenDXfgksUYoNpTSivKlPrHmajhz,xJLenDXfgksUYoNpTSivKlPrHmajhA,isFolder)
 def dp_Main_List(xJLenDXfgksUYoNpTSivKlPrHmajhO,args):
  for xJLenDXfgksUYoNpTSivKlPrHmajhE in xJLenDXfgksUYoNpTSivKlPrHmajhV:
   xJLenDXfgksUYoNpTSivKlPrHmajhy=xJLenDXfgksUYoNpTSivKlPrHmajhE.get('title')
   xJLenDXfgksUYoNpTSivKlPrHmajhc=''
   xJLenDXfgksUYoNpTSivKlPrHmajht={'mode':xJLenDXfgksUYoNpTSivKlPrHmajhE.get('mode'),}
   if xJLenDXfgksUYoNpTSivKlPrHmajhE.get('mode')in['XXX']:
    xJLenDXfgksUYoNpTSivKlPrHmajhI=xJLenDXfgksUYoNpTSivKlPrHmajVb
    xJLenDXfgksUYoNpTSivKlPrHmajhd =xJLenDXfgksUYoNpTSivKlPrHmajVC
   else:
    xJLenDXfgksUYoNpTSivKlPrHmajhI=xJLenDXfgksUYoNpTSivKlPrHmajVC
    xJLenDXfgksUYoNpTSivKlPrHmajhd =xJLenDXfgksUYoNpTSivKlPrHmajVb
   if 'icon' in xJLenDXfgksUYoNpTSivKlPrHmajhE:xJLenDXfgksUYoNpTSivKlPrHmajhc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',xJLenDXfgksUYoNpTSivKlPrHmajhE.get('icon')) 
   xJLenDXfgksUYoNpTSivKlPrHmajhO.add_dir(xJLenDXfgksUYoNpTSivKlPrHmajhy,sublabel='',img=xJLenDXfgksUYoNpTSivKlPrHmajhc,infoLabels=xJLenDXfgksUYoNpTSivKlPrHmajVQ,isFolder=xJLenDXfgksUYoNpTSivKlPrHmajhI,params=xJLenDXfgksUYoNpTSivKlPrHmajht,isLink=xJLenDXfgksUYoNpTSivKlPrHmajhd)
  xbmcplugin.endOfDirectory(xJLenDXfgksUYoNpTSivKlPrHmajhO._addon_handle)
 def dp_Channel_List(xJLenDXfgksUYoNpTSivKlPrHmajhO,args):
  xJLenDXfgksUYoNpTSivKlPrHmajhG=xJLenDXfgksUYoNpTSivKlPrHmajhO.get_Bitrate_sel()
  for xJLenDXfgksUYoNpTSivKlPrHmajFh in xJLenDXfgksUYoNpTSivKlPrHmajhu:
   xJLenDXfgksUYoNpTSivKlPrHmajhy=xJLenDXfgksUYoNpTSivKlPrHmajFh.get('title')
   xJLenDXfgksUYoNpTSivKlPrHmajFV=xJLenDXfgksUYoNpTSivKlPrHmajFh.get('chId')
   xJLenDXfgksUYoNpTSivKlPrHmajFu={'mediatype':'episode','title':xJLenDXfgksUYoNpTSivKlPrHmajhy}
   xJLenDXfgksUYoNpTSivKlPrHmajht={'mode':'CLIVE','chId':xJLenDXfgksUYoNpTSivKlPrHmajFV,'maxBitrate':xJLenDXfgksUYoNpTSivKlPrHmajhG,}
   xJLenDXfgksUYoNpTSivKlPrHmajhO.add_dir(xJLenDXfgksUYoNpTSivKlPrHmajhy,sublabel='',img='',infoLabels=xJLenDXfgksUYoNpTSivKlPrHmajFu,isFolder=xJLenDXfgksUYoNpTSivKlPrHmajVb,params=xJLenDXfgksUYoNpTSivKlPrHmajht,isLink=xJLenDXfgksUYoNpTSivKlPrHmajVb)
  xbmcplugin.endOfDirectory(xJLenDXfgksUYoNpTSivKlPrHmajhO._addon_handle)
 def dp_Category_List(xJLenDXfgksUYoNpTSivKlPrHmajhO,args):
  xJLenDXfgksUYoNpTSivKlPrHmajFO=xJLenDXfgksUYoNpTSivKlPrHmajhO.NsportsObj.Get_Category_List()
  for xJLenDXfgksUYoNpTSivKlPrHmajFw in xJLenDXfgksUYoNpTSivKlPrHmajFO:
   xJLenDXfgksUYoNpTSivKlPrHmajFq =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('groupnm')
   xJLenDXfgksUYoNpTSivKlPrHmajFB =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('onairyn')
   xJLenDXfgksUYoNpTSivKlPrHmajFQ=','.join(xJLenDXfgksUYoNpTSivKlPrHmajFw.get('category'))
   if xJLenDXfgksUYoNpTSivKlPrHmajFB=='Y':xJLenDXfgksUYoNpTSivKlPrHmajhR='중계중'
   else:xJLenDXfgksUYoNpTSivKlPrHmajhR=''
   xJLenDXfgksUYoNpTSivKlPrHmajht={'mode':'GAME_LIST','category':xJLenDXfgksUYoNpTSivKlPrHmajFQ,}
   xJLenDXfgksUYoNpTSivKlPrHmajhO.add_dir(xJLenDXfgksUYoNpTSivKlPrHmajFq,sublabel=xJLenDXfgksUYoNpTSivKlPrHmajhR,img='',infoLabels=xJLenDXfgksUYoNpTSivKlPrHmajVQ,isFolder=xJLenDXfgksUYoNpTSivKlPrHmajVC,params=xJLenDXfgksUYoNpTSivKlPrHmajht)
  xbmcplugin.endOfDirectory(xJLenDXfgksUYoNpTSivKlPrHmajhO._addon_handle,cacheToDisc=xJLenDXfgksUYoNpTSivKlPrHmajVb)
 def dp_Game_List(xJLenDXfgksUYoNpTSivKlPrHmajhO,args):
  xJLenDXfgksUYoNpTSivKlPrHmajFb=args.get('category')
  xJLenDXfgksUYoNpTSivKlPrHmajFO=xJLenDXfgksUYoNpTSivKlPrHmajhO.NsportsObj.Get_Game_List(xJLenDXfgksUYoNpTSivKlPrHmajFb)
  for xJLenDXfgksUYoNpTSivKlPrHmajFw in xJLenDXfgksUYoNpTSivKlPrHmajFO:
   xJLenDXfgksUYoNpTSivKlPrHmajFM =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('gameId')
   xJLenDXfgksUYoNpTSivKlPrHmajFW =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('upperCategoryId')
   xJLenDXfgksUYoNpTSivKlPrHmajFz =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('categoryId')
   xJLenDXfgksUYoNpTSivKlPrHmajFy =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('statusCode')
   xJLenDXfgksUYoNpTSivKlPrHmajFA =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('statusInfo')
   xJLenDXfgksUYoNpTSivKlPrHmajFE =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('isOnAirTv')
   xJLenDXfgksUYoNpTSivKlPrHmajFV =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('chId')
   xJLenDXfgksUYoNpTSivKlPrHmajhy =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('title')
   xJLenDXfgksUYoNpTSivKlPrHmajFc =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('starttime')
   xJLenDXfgksUYoNpTSivKlPrHmajFt =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('endTime')
   xJLenDXfgksUYoNpTSivKlPrHmajFI =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('maxBitrate')
   if xJLenDXfgksUYoNpTSivKlPrHmajhy=='':xJLenDXfgksUYoNpTSivKlPrHmajhy=xJLenDXfgksUYoNpTSivKlPrHmajFM
   if xJLenDXfgksUYoNpTSivKlPrHmajFE=='Y':
    xJLenDXfgksUYoNpTSivKlPrHmajFd='방송중'
   else:
    if xJLenDXfgksUYoNpTSivKlPrHmajFA=='경기취소':
     xJLenDXfgksUYoNpTSivKlPrHmajFd=xJLenDXfgksUYoNpTSivKlPrHmajFA
    else:
     xJLenDXfgksUYoNpTSivKlPrHmajFd=''
   if xJLenDXfgksUYoNpTSivKlPrHmajFc=='':
    xJLenDXfgksUYoNpTSivKlPrHmajhR=xJLenDXfgksUYoNpTSivKlPrHmajFd
   else:
    if xJLenDXfgksUYoNpTSivKlPrHmajFd=='':
     xJLenDXfgksUYoNpTSivKlPrHmajhR=xJLenDXfgksUYoNpTSivKlPrHmajFc
    else:
     xJLenDXfgksUYoNpTSivKlPrHmajhR=xJLenDXfgksUYoNpTSivKlPrHmajFc+' - '+xJLenDXfgksUYoNpTSivKlPrHmajFd
   xJLenDXfgksUYoNpTSivKlPrHmajFu={'mediatype':'episode','title':xJLenDXfgksUYoNpTSivKlPrHmajhy,'plot':'%s\n\n시작 : %s\n종료 : %s'%(xJLenDXfgksUYoNpTSivKlPrHmajhy,xJLenDXfgksUYoNpTSivKlPrHmajFc,xJLenDXfgksUYoNpTSivKlPrHmajFt)}
   xJLenDXfgksUYoNpTSivKlPrHmajht={'mode':'LIVE','chId':xJLenDXfgksUYoNpTSivKlPrHmajFV,'maxBitrate':xJLenDXfgksUYoNpTSivKlPrHmajFI,'gameId':xJLenDXfgksUYoNpTSivKlPrHmajFM,}
   xJLenDXfgksUYoNpTSivKlPrHmajhO.add_dir(xJLenDXfgksUYoNpTSivKlPrHmajhy,sublabel=xJLenDXfgksUYoNpTSivKlPrHmajhR,img='',infoLabels=xJLenDXfgksUYoNpTSivKlPrHmajFu,isFolder=xJLenDXfgksUYoNpTSivKlPrHmajVb,params=xJLenDXfgksUYoNpTSivKlPrHmajht)
  xbmcplugin.endOfDirectory(xJLenDXfgksUYoNpTSivKlPrHmajhO._addon_handle,cacheToDisc=xJLenDXfgksUYoNpTSivKlPrHmajVb)
 def dp_BsCategory_List(xJLenDXfgksUYoNpTSivKlPrHmajhO,args):
  xJLenDXfgksUYoNpTSivKlPrHmajFO=xJLenDXfgksUYoNpTSivKlPrHmajhO.NsportsObj.Get_Category_BSjson()
  for xJLenDXfgksUYoNpTSivKlPrHmajFw in xJLenDXfgksUYoNpTSivKlPrHmajFO:
   xJLenDXfgksUYoNpTSivKlPrHmajFQ =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('category')
   xJLenDXfgksUYoNpTSivKlPrHmajFR =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('live')
   if xJLenDXfgksUYoNpTSivKlPrHmajFR=='Y':xJLenDXfgksUYoNpTSivKlPrHmajhR='중계중'
   else:xJLenDXfgksUYoNpTSivKlPrHmajhR=''
   xJLenDXfgksUYoNpTSivKlPrHmajht={'mode':'BS_GAME','category':xJLenDXfgksUYoNpTSivKlPrHmajFQ,}
   xJLenDXfgksUYoNpTSivKlPrHmajhO.add_dir(xJLenDXfgksUYoNpTSivKlPrHmajFQ,sublabel=xJLenDXfgksUYoNpTSivKlPrHmajhR,img='',infoLabels=xJLenDXfgksUYoNpTSivKlPrHmajVQ,isFolder=xJLenDXfgksUYoNpTSivKlPrHmajVC,params=xJLenDXfgksUYoNpTSivKlPrHmajht)
  xbmcplugin.endOfDirectory(xJLenDXfgksUYoNpTSivKlPrHmajhO._addon_handle,cacheToDisc=xJLenDXfgksUYoNpTSivKlPrHmajVb)
 def dp_BsGame_List(xJLenDXfgksUYoNpTSivKlPrHmajhO,args):
  xJLenDXfgksUYoNpTSivKlPrHmajFQ=args.get('category')
  xJLenDXfgksUYoNpTSivKlPrHmajFO=xJLenDXfgksUYoNpTSivKlPrHmajhO.NsportsObj.Get_Gamelist_BSjson(xJLenDXfgksUYoNpTSivKlPrHmajFQ)
  for xJLenDXfgksUYoNpTSivKlPrHmajFw in xJLenDXfgksUYoNpTSivKlPrHmajFO:
   xJLenDXfgksUYoNpTSivKlPrHmajFM =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('gameId')
   xJLenDXfgksUYoNpTSivKlPrHmajFG =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('time')
   xJLenDXfgksUYoNpTSivKlPrHmajhy =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('title')
   xJLenDXfgksUYoNpTSivKlPrHmajFR =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('live')
   xJLenDXfgksUYoNpTSivKlPrHmajVh =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('ing')
   xJLenDXfgksUYoNpTSivKlPrHmajVF =xJLenDXfgksUYoNpTSivKlPrHmajFw.get('place')
   if xJLenDXfgksUYoNpTSivKlPrHmajFR=='Y':
    xJLenDXfgksUYoNpTSivKlPrHmajFd='방송중'
   else:
    xJLenDXfgksUYoNpTSivKlPrHmajFd=''
   if xJLenDXfgksUYoNpTSivKlPrHmajFd=='':
    xJLenDXfgksUYoNpTSivKlPrHmajhR=xJLenDXfgksUYoNpTSivKlPrHmajFG
   else:
    xJLenDXfgksUYoNpTSivKlPrHmajhR=xJLenDXfgksUYoNpTSivKlPrHmajFG+' - '+xJLenDXfgksUYoNpTSivKlPrHmajFd
   xJLenDXfgksUYoNpTSivKlPrHmajFu={'mediatype':'episode','title':xJLenDXfgksUYoNpTSivKlPrHmajhy,'plot':'%s\n\n시간 : %s\n\n%s'%(xJLenDXfgksUYoNpTSivKlPrHmajhy,xJLenDXfgksUYoNpTSivKlPrHmajhR,xJLenDXfgksUYoNpTSivKlPrHmajVF)}
   xJLenDXfgksUYoNpTSivKlPrHmajht={'mode':'LIVE','gameId':xJLenDXfgksUYoNpTSivKlPrHmajFM,}
   xJLenDXfgksUYoNpTSivKlPrHmajhO.add_dir(xJLenDXfgksUYoNpTSivKlPrHmajhy,sublabel=xJLenDXfgksUYoNpTSivKlPrHmajhR,img='',infoLabels=xJLenDXfgksUYoNpTSivKlPrHmajFu,isFolder=xJLenDXfgksUYoNpTSivKlPrHmajVb,params=xJLenDXfgksUYoNpTSivKlPrHmajht)
  xbmcplugin.endOfDirectory(xJLenDXfgksUYoNpTSivKlPrHmajhO._addon_handle,cacheToDisc=xJLenDXfgksUYoNpTSivKlPrHmajVb)
 def play_VIDEO(xJLenDXfgksUYoNpTSivKlPrHmajhO,args):
  xJLenDXfgksUYoNpTSivKlPrHmajFM =args.get('gameId')
  xJLenDXfgksUYoNpTSivKlPrHmajVu =xJLenDXfgksUYoNpTSivKlPrHmajhO.get_Bitrate_sel()
  if xJLenDXfgksUYoNpTSivKlPrHmajFM=='' or xJLenDXfgksUYoNpTSivKlPrHmajFM==xJLenDXfgksUYoNpTSivKlPrHmajVQ:return
  xJLenDXfgksUYoNpTSivKlPrHmajVO=xJLenDXfgksUYoNpTSivKlPrHmajhO.NsportsObj.GetStreamingRtmp(xJLenDXfgksUYoNpTSivKlPrHmajFM,xJLenDXfgksUYoNpTSivKlPrHmajVu)
  if xJLenDXfgksUYoNpTSivKlPrHmajVO=='':
   xJLenDXfgksUYoNpTSivKlPrHmajhO.addon_noti(__language__(30901).encode('utf8'))
   return
  xJLenDXfgksUYoNpTSivKlPrHmajhO.addon_log('gameId : '+xJLenDXfgksUYoNpTSivKlPrHmajFM)
  xJLenDXfgksUYoNpTSivKlPrHmajhO.addon_log('GetStreamingRtmp : '+xJLenDXfgksUYoNpTSivKlPrHmajVO)
  xJLenDXfgksUYoNpTSivKlPrHmajVw=xbmcgui.ListItem(path=xJLenDXfgksUYoNpTSivKlPrHmajVO)
  xbmcplugin.setResolvedUrl(xJLenDXfgksUYoNpTSivKlPrHmajhO._addon_handle,xJLenDXfgksUYoNpTSivKlPrHmajVC,xJLenDXfgksUYoNpTSivKlPrHmajVw)
 def play_CHANNEL(xJLenDXfgksUYoNpTSivKlPrHmajhO,args):
  xJLenDXfgksUYoNpTSivKlPrHmajFV =args.get('chId')
  xJLenDXfgksUYoNpTSivKlPrHmajFI =args.get('maxBitrate')
  xJLenDXfgksUYoNpTSivKlPrHmajVu =xJLenDXfgksUYoNpTSivKlPrHmajhO.get_Bitrate_sel()
  xJLenDXfgksUYoNpTSivKlPrHmajVO=xJLenDXfgksUYoNpTSivKlPrHmajhO.NsportsObj.GetStreamingURL(xJLenDXfgksUYoNpTSivKlPrHmajFV,xJLenDXfgksUYoNpTSivKlPrHmajVu,xJLenDXfgksUYoNpTSivKlPrHmajFI)
  if xJLenDXfgksUYoNpTSivKlPrHmajVO=='':
   xJLenDXfgksUYoNpTSivKlPrHmajhO.addon_noti(__language__(30901).encode('utf8'))
   return
  xJLenDXfgksUYoNpTSivKlPrHmajhO.addon_log('chId : '+xJLenDXfgksUYoNpTSivKlPrHmajFV)
  xJLenDXfgksUYoNpTSivKlPrHmajhO.addon_log('play_CHANNEL : '+xJLenDXfgksUYoNpTSivKlPrHmajVO)
  xJLenDXfgksUYoNpTSivKlPrHmajVw=xbmcgui.ListItem(path=xJLenDXfgksUYoNpTSivKlPrHmajVO)
  xbmcplugin.setResolvedUrl(xJLenDXfgksUYoNpTSivKlPrHmajhO._addon_handle,xJLenDXfgksUYoNpTSivKlPrHmajVC,xJLenDXfgksUYoNpTSivKlPrHmajVw)
 def nsports_main(xJLenDXfgksUYoNpTSivKlPrHmajhO):
  xJLenDXfgksUYoNpTSivKlPrHmajVq=xJLenDXfgksUYoNpTSivKlPrHmajhO.main_params.get('mode',xJLenDXfgksUYoNpTSivKlPrHmajVQ)
  if xJLenDXfgksUYoNpTSivKlPrHmajVq is xJLenDXfgksUYoNpTSivKlPrHmajVQ:
   xJLenDXfgksUYoNpTSivKlPrHmajhO.dp_Main_List(xJLenDXfgksUYoNpTSivKlPrHmajhO.main_params)
  elif xJLenDXfgksUYoNpTSivKlPrHmajVq=='CATEGORY_LIST':
   xJLenDXfgksUYoNpTSivKlPrHmajhO.dp_Category_List(xJLenDXfgksUYoNpTSivKlPrHmajhO.main_params)
  elif xJLenDXfgksUYoNpTSivKlPrHmajVq=='BS_CATEGORY':
   xJLenDXfgksUYoNpTSivKlPrHmajhO.dp_BsCategory_List(xJLenDXfgksUYoNpTSivKlPrHmajhO.main_params)
  elif xJLenDXfgksUYoNpTSivKlPrHmajVq=='GAME_LIST':
   xJLenDXfgksUYoNpTSivKlPrHmajhO.dp_Game_List(xJLenDXfgksUYoNpTSivKlPrHmajhO.main_params)
  elif xJLenDXfgksUYoNpTSivKlPrHmajVq=='BS_GAME':
   xJLenDXfgksUYoNpTSivKlPrHmajhO.dp_BsGame_List(xJLenDXfgksUYoNpTSivKlPrHmajhO.main_params)
  elif xJLenDXfgksUYoNpTSivKlPrHmajVq=='LIVE':
   xJLenDXfgksUYoNpTSivKlPrHmajhO.play_VIDEO(xJLenDXfgksUYoNpTSivKlPrHmajhO.main_params)
  elif xJLenDXfgksUYoNpTSivKlPrHmajVq=='CLIVE':
   xJLenDXfgksUYoNpTSivKlPrHmajhO.play_CHANNEL(xJLenDXfgksUYoNpTSivKlPrHmajhO.main_params)
  elif xJLenDXfgksUYoNpTSivKlPrHmajVq=='CHANNEL_LIST':
   xJLenDXfgksUYoNpTSivKlPrHmajhO.dp_Channel_List(xJLenDXfgksUYoNpTSivKlPrHmajhO.main_params)
  else:
   xJLenDXfgksUYoNpTSivKlPrHmajVQ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
