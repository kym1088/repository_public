__author__="NightRain"
VhHSWoUmvreJGDiKzAaCuQwkxTYcOI=object
VhHSWoUmvreJGDiKzAaCuQwkxTYcOj=None
VhHSWoUmvreJGDiKzAaCuQwkxTYcOB=False
VhHSWoUmvreJGDiKzAaCuQwkxTYcOf=True
VhHSWoUmvreJGDiKzAaCuQwkxTYcOL=len
VhHSWoUmvreJGDiKzAaCuQwkxTYcOP=print
VhHSWoUmvreJGDiKzAaCuQwkxTYcOl=Exception
VhHSWoUmvreJGDiKzAaCuQwkxTYcOp=int
VhHSWoUmvreJGDiKzAaCuQwkxTYcOE=str
VhHSWoUmvreJGDiKzAaCuQwkxTYcOq=type
VhHSWoUmvreJGDiKzAaCuQwkxTYcOb=dict
import urllib
import re
import json
import requests
import datetime
from bs4 import BeautifulSoup
class VhHSWoUmvreJGDiKzAaCuQwkxTYcnF(VhHSWoUmvreJGDiKzAaCuQwkxTYcOI):
 def __init__(VhHSWoUmvreJGDiKzAaCuQwkxTYcng):
  VhHSWoUmvreJGDiKzAaCuQwkxTYcng.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36'
  VhHSWoUmvreJGDiKzAaCuQwkxTYcng.DEFAULT_HEADER ={'user-agent':VhHSWoUmvreJGDiKzAaCuQwkxTYcng.USER_AGENT}
  VhHSWoUmvreJGDiKzAaCuQwkxTYcng.genres=[{'groupnm':'야구','category':['kbaseball','wbaseball']},{'groupnm':'축구','category':['kfootball','wfootball']},{'groupnm':'배구','category':['kvolleyball']},{'groupnm':'골프','category':['golf']},{'groupnm':'농구','category':['kbasketball']},{'groupnm':'기타','category':['others']},]
 def callRequestCookies(VhHSWoUmvreJGDiKzAaCuQwkxTYcng,jobtype,VhHSWoUmvreJGDiKzAaCuQwkxTYcnI,payload=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,params=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,headers=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,cookies=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,redirects=VhHSWoUmvreJGDiKzAaCuQwkxTYcOB):
  VhHSWoUmvreJGDiKzAaCuQwkxTYcnO=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.DEFAULT_HEADER
  if headers:VhHSWoUmvreJGDiKzAaCuQwkxTYcnO.update(headers)
  if jobtype=='Get':
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnR=requests.get(VhHSWoUmvreJGDiKzAaCuQwkxTYcnI,params=params,headers=VhHSWoUmvreJGDiKzAaCuQwkxTYcnO,cookies=cookies,allow_redirects=redirects)
  else:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnR=requests.post(VhHSWoUmvreJGDiKzAaCuQwkxTYcnI,data=payload,params=params,headers=VhHSWoUmvreJGDiKzAaCuQwkxTYcnO,cookies=cookies,allow_redirects=redirects)
  return VhHSWoUmvreJGDiKzAaCuQwkxTYcnR
 def Get_Now_Datetime(VhHSWoUmvreJGDiKzAaCuQwkxTYcng):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def make_viewdate(VhHSWoUmvreJGDiKzAaCuQwkxTYcng,dtype='1'):
  VhHSWoUmvreJGDiKzAaCuQwkxTYcnM =VhHSWoUmvreJGDiKzAaCuQwkxTYcng.Get_Now_Datetime()
  VhHSWoUmvreJGDiKzAaCuQwkxTYcnX =VhHSWoUmvreJGDiKzAaCuQwkxTYcnM+datetime.timedelta(days=-1)
  VhHSWoUmvreJGDiKzAaCuQwkxTYcnN =VhHSWoUmvreJGDiKzAaCuQwkxTYcnM+datetime.timedelta(days=1)
  if dtype=='1':
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnd=[VhHSWoUmvreJGDiKzAaCuQwkxTYcnM.strftime('%Y%m%d'),]
  elif dtype=='2':
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnd=[VhHSWoUmvreJGDiKzAaCuQwkxTYcnM.strftime('%Y%m%d'),VhHSWoUmvreJGDiKzAaCuQwkxTYcnN.strftime('%Y%m%d'),]
  elif dtype=='3':
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnd=[VhHSWoUmvreJGDiKzAaCuQwkxTYcnM.strftime('%Y%m%d'),VhHSWoUmvreJGDiKzAaCuQwkxTYcnX.strftime('%Y%m%d'),VhHSWoUmvreJGDiKzAaCuQwkxTYcnN.strftime('%Y%m%d'),]
  return VhHSWoUmvreJGDiKzAaCuQwkxTYcnd
 def Get_Category_List(VhHSWoUmvreJGDiKzAaCuQwkxTYcng):
  VhHSWoUmvreJGDiKzAaCuQwkxTYcnt=[]
  VhHSWoUmvreJGDiKzAaCuQwkxTYcns=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.make_viewdate(dtype='1')
  try:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnI='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnj=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.callRequestCookies('Get',VhHSWoUmvreJGDiKzAaCuQwkxTYcnI,payload=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,params=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,headers=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,cookies=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,redirects=VhHSWoUmvreJGDiKzAaCuQwkxTYcOf)
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.status_code!=200:return[]
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnB=json.loads(VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.text)
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnf=VhHSWoUmvreJGDiKzAaCuQwkxTYcnB.get('gameList')
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnL=[]
   for VhHSWoUmvreJGDiKzAaCuQwkxTYcnP in VhHSWoUmvreJGDiKzAaCuQwkxTYcng.genres:
    VhHSWoUmvreJGDiKzAaCuQwkxTYcnl =VhHSWoUmvreJGDiKzAaCuQwkxTYcnP.get('groupnm')
    VhHSWoUmvreJGDiKzAaCuQwkxTYcnp=[]
    VhHSWoUmvreJGDiKzAaCuQwkxTYcnE ='N'
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcOL(VhHSWoUmvreJGDiKzAaCuQwkxTYcnL)!=0:
     VhHSWoUmvreJGDiKzAaCuQwkxTYcnf =VhHSWoUmvreJGDiKzAaCuQwkxTYcnL
     VhHSWoUmvreJGDiKzAaCuQwkxTYcnL=[]
    for VhHSWoUmvreJGDiKzAaCuQwkxTYcnq in VhHSWoUmvreJGDiKzAaCuQwkxTYcnf:
     VhHSWoUmvreJGDiKzAaCuQwkxTYcnb=VhHSWoUmvreJGDiKzAaCuQwkxTYcnq.get('upperCategoryId')
     VhHSWoUmvreJGDiKzAaCuQwkxTYcFn =VhHSWoUmvreJGDiKzAaCuQwkxTYcnq.get('statusCode')
     VhHSWoUmvreJGDiKzAaCuQwkxTYcFg =VhHSWoUmvreJGDiKzAaCuQwkxTYcnq.get('isOnAirTv')
     VhHSWoUmvreJGDiKzAaCuQwkxTYcFO =VhHSWoUmvreJGDiKzAaCuQwkxTYcnq.get('gameId')
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcnb in('esports'):continue
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcFn in('RESULT'):continue
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcFO[:8]not in VhHSWoUmvreJGDiKzAaCuQwkxTYcns and VhHSWoUmvreJGDiKzAaCuQwkxTYcFg!='Y':continue
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcnb in VhHSWoUmvreJGDiKzAaCuQwkxTYcnP.get('category'):
      if VhHSWoUmvreJGDiKzAaCuQwkxTYcnb not in VhHSWoUmvreJGDiKzAaCuQwkxTYcnp:VhHSWoUmvreJGDiKzAaCuQwkxTYcnp.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcnb)
      if VhHSWoUmvreJGDiKzAaCuQwkxTYcFg=='Y':VhHSWoUmvreJGDiKzAaCuQwkxTYcnE='Y'
     else:
      VhHSWoUmvreJGDiKzAaCuQwkxTYcnL.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcnq)
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcOL(VhHSWoUmvreJGDiKzAaCuQwkxTYcnp)>0:
     VhHSWoUmvreJGDiKzAaCuQwkxTYcFR={'groupnm':VhHSWoUmvreJGDiKzAaCuQwkxTYcnl,'onairyn':VhHSWoUmvreJGDiKzAaCuQwkxTYcnE,'category':VhHSWoUmvreJGDiKzAaCuQwkxTYcnp,}
     VhHSWoUmvreJGDiKzAaCuQwkxTYcnt.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcFR)
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcOL(VhHSWoUmvreJGDiKzAaCuQwkxTYcnL)==0:break
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnl ='-'
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnp=[]
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnE ='N'
   for VhHSWoUmvreJGDiKzAaCuQwkxTYcnq in VhHSWoUmvreJGDiKzAaCuQwkxTYcnL:
    VhHSWoUmvreJGDiKzAaCuQwkxTYcnb=VhHSWoUmvreJGDiKzAaCuQwkxTYcnq.get('upperCategoryId')
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFg =VhHSWoUmvreJGDiKzAaCuQwkxTYcnq.get('isOnAirTv')
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcnb not in VhHSWoUmvreJGDiKzAaCuQwkxTYcnp:VhHSWoUmvreJGDiKzAaCuQwkxTYcnp.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcnb)
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcFg=='Y':VhHSWoUmvreJGDiKzAaCuQwkxTYcnE='Y'
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcOL(VhHSWoUmvreJGDiKzAaCuQwkxTYcnp)>0:
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFR={'groupnm':'-','onairyn':VhHSWoUmvreJGDiKzAaCuQwkxTYcnE,'category':VhHSWoUmvreJGDiKzAaCuQwkxTYcnp,}
    VhHSWoUmvreJGDiKzAaCuQwkxTYcnt.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcFR)
    VhHSWoUmvreJGDiKzAaCuQwkxTYcOP(VhHSWoUmvreJGDiKzAaCuQwkxTYcnl,VhHSWoUmvreJGDiKzAaCuQwkxTYcnE,VhHSWoUmvreJGDiKzAaCuQwkxTYcnp)
  except VhHSWoUmvreJGDiKzAaCuQwkxTYcOl as exception:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcOP(exception)
   return[]
  return VhHSWoUmvreJGDiKzAaCuQwkxTYcnt
 def Get_Game_List(VhHSWoUmvreJGDiKzAaCuQwkxTYcng,category):
  VhHSWoUmvreJGDiKzAaCuQwkxTYcFy=category.split(',')
  VhHSWoUmvreJGDiKzAaCuQwkxTYcnt =[]
  VhHSWoUmvreJGDiKzAaCuQwkxTYcFM =[]
  VhHSWoUmvreJGDiKzAaCuQwkxTYcFX =[]
  VhHSWoUmvreJGDiKzAaCuQwkxTYcns=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.make_viewdate()
  try:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnI='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnj=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.callRequestCookies('Get',VhHSWoUmvreJGDiKzAaCuQwkxTYcnI,payload=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,params=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,headers=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,cookies=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,redirects=VhHSWoUmvreJGDiKzAaCuQwkxTYcOf)
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.status_code!=200:return[]
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnB=json.loads(VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.text)
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnf=VhHSWoUmvreJGDiKzAaCuQwkxTYcnB.get('gameList')
   for VhHSWoUmvreJGDiKzAaCuQwkxTYcnq in VhHSWoUmvreJGDiKzAaCuQwkxTYcnf:
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFO =VhHSWoUmvreJGDiKzAaCuQwkxTYcnq.get('gameId')
    VhHSWoUmvreJGDiKzAaCuQwkxTYcnb=VhHSWoUmvreJGDiKzAaCuQwkxTYcnq.get('upperCategoryId')
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFN =VhHSWoUmvreJGDiKzAaCuQwkxTYcnq.get('categoryId')
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFn =VhHSWoUmvreJGDiKzAaCuQwkxTYcnq.get('statusCode')
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFd =VhHSWoUmvreJGDiKzAaCuQwkxTYcnq.get('statusInfo')
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFg =VhHSWoUmvreJGDiKzAaCuQwkxTYcnq.get('isOnAirTv')
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcnb in('esports'):continue
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcFn in('RESULT'):continue
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcnb not in VhHSWoUmvreJGDiKzAaCuQwkxTYcFy:continue
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcFO[:8]not in VhHSWoUmvreJGDiKzAaCuQwkxTYcns and VhHSWoUmvreJGDiKzAaCuQwkxTYcFg!='Y':continue
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFt=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.Get_Game_liveInfo(VhHSWoUmvreJGDiKzAaCuQwkxTYcFO)
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcFt.get('chId')==VhHSWoUmvreJGDiKzAaCuQwkxTYcOj:continue
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFR={'gameId':VhHSWoUmvreJGDiKzAaCuQwkxTYcFO,'upperCategoryId':VhHSWoUmvreJGDiKzAaCuQwkxTYcnb,'categoryId':VhHSWoUmvreJGDiKzAaCuQwkxTYcFN,'statusCode':VhHSWoUmvreJGDiKzAaCuQwkxTYcFn,'statusInfo':VhHSWoUmvreJGDiKzAaCuQwkxTYcFd,'isOnAirTv':VhHSWoUmvreJGDiKzAaCuQwkxTYcFg,'chId':VhHSWoUmvreJGDiKzAaCuQwkxTYcFt.get('chId'),'title':VhHSWoUmvreJGDiKzAaCuQwkxTYcFt.get('title'),'starttime':VhHSWoUmvreJGDiKzAaCuQwkxTYcFt.get('starttime'),'endTime':VhHSWoUmvreJGDiKzAaCuQwkxTYcFt.get('endTime'),'maxBitrate':VhHSWoUmvreJGDiKzAaCuQwkxTYcFt.get('maxBitrate'),}
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcFg=='Y':
     VhHSWoUmvreJGDiKzAaCuQwkxTYcFM.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcFR)
    else:
     VhHSWoUmvreJGDiKzAaCuQwkxTYcFX.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcFR)
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnt=VhHSWoUmvreJGDiKzAaCuQwkxTYcFM+VhHSWoUmvreJGDiKzAaCuQwkxTYcFX
  except VhHSWoUmvreJGDiKzAaCuQwkxTYcOl as exception:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcOP(exception)
   return[]
  return VhHSWoUmvreJGDiKzAaCuQwkxTYcnt
 def Get_Game_liveInfo(VhHSWoUmvreJGDiKzAaCuQwkxTYcng,VhHSWoUmvreJGDiKzAaCuQwkxTYcFO):
  VhHSWoUmvreJGDiKzAaCuQwkxTYcFs={}
  try:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnI='https://apis.naver.com/pcLive/livePlatform/liveInfo2'
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFI={'env':'pc','inclAudCh':'0','svcId':'12002','svcLiveId':VhHSWoUmvreJGDiKzAaCuQwkxTYcFO,}
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnj=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.callRequestCookies('Get',VhHSWoUmvreJGDiKzAaCuQwkxTYcnI,payload=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,params=VhHSWoUmvreJGDiKzAaCuQwkxTYcFI,headers=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,cookies=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,redirects=VhHSWoUmvreJGDiKzAaCuQwkxTYcOf)
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.status_code!=200:return[]
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnB=json.loads(VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.text)
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFj =VhHSWoUmvreJGDiKzAaCuQwkxTYcnB.get('chList')[0].get('chId')
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFB=VhHSWoUmvreJGDiKzAaCuQwkxTYcnB.get('chConf').get(VhHSWoUmvreJGDiKzAaCuQwkxTYcFj)[0].get('id')
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFf =VhHSWoUmvreJGDiKzAaCuQwkxTYcnB.get('program')
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFL =VhHSWoUmvreJGDiKzAaCuQwkxTYcFf.get('title')
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFP =VhHSWoUmvreJGDiKzAaCuQwkxTYcFf.get('startTime')
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFl =VhHSWoUmvreJGDiKzAaCuQwkxTYcFf.get('endTime')
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcFP!=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj:
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFP =datetime.datetime.fromtimestamp(VhHSWoUmvreJGDiKzAaCuQwkxTYcOp(VhHSWoUmvreJGDiKzAaCuQwkxTYcFP),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:VhHSWoUmvreJGDiKzAaCuQwkxTYcFP=''
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcFl!=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj:
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFl =datetime.datetime.fromtimestamp(VhHSWoUmvreJGDiKzAaCuQwkxTYcOp(VhHSWoUmvreJGDiKzAaCuQwkxTYcFl),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:VhHSWoUmvreJGDiKzAaCuQwkxTYcFl=''
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFs={'chId':VhHSWoUmvreJGDiKzAaCuQwkxTYcFj,'title':VhHSWoUmvreJGDiKzAaCuQwkxTYcFL,'starttime':VhHSWoUmvreJGDiKzAaCuQwkxTYcFP,'endTime':VhHSWoUmvreJGDiKzAaCuQwkxTYcFl,'maxBitrate':VhHSWoUmvreJGDiKzAaCuQwkxTYcFB,}
  except VhHSWoUmvreJGDiKzAaCuQwkxTYcOl as exception:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcOP(exception)
   return{}
  return VhHSWoUmvreJGDiKzAaCuQwkxTYcFs
 def GetStreamingURL(VhHSWoUmvreJGDiKzAaCuQwkxTYcng,channelId,setBitrate,VhHSWoUmvreJGDiKzAaCuQwkxTYcFB):
  VhHSWoUmvreJGDiKzAaCuQwkxTYcFp=''
  if VhHSWoUmvreJGDiKzAaCuQwkxTYcOp(setBitrate)>VhHSWoUmvreJGDiKzAaCuQwkxTYcOp(VhHSWoUmvreJGDiKzAaCuQwkxTYcFB):
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFE=VhHSWoUmvreJGDiKzAaCuQwkxTYcFB
  else:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFE=setBitrate
  try:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnI='https://apis.naver.com/pcLive/livePlatform/sUrl'
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFI={'ch':channelId,'q':VhHSWoUmvreJGDiKzAaCuQwkxTYcFE,'p':'hls','cc':'KR','env':'pc',}
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnj=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.callRequestCookies('Get',VhHSWoUmvreJGDiKzAaCuQwkxTYcnI,payload=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,params=VhHSWoUmvreJGDiKzAaCuQwkxTYcFI,headers=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,cookies=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,redirects=VhHSWoUmvreJGDiKzAaCuQwkxTYcOf)
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.status_code!=200:return ''
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnB=json.loads(VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.text)
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFp=VhHSWoUmvreJGDiKzAaCuQwkxTYcnB.get('secUrl')
  except VhHSWoUmvreJGDiKzAaCuQwkxTYcOl as exception:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcOP(exception)
   return ''
  return VhHSWoUmvreJGDiKzAaCuQwkxTYcFp
 def GetStreamingRtmp_bak(VhHSWoUmvreJGDiKzAaCuQwkxTYcng,VhHSWoUmvreJGDiKzAaCuQwkxTYcFO,setBitrate):
  VhHSWoUmvreJGDiKzAaCuQwkxTYcFp=''
  try:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnI='https://api-gw.sports.naver.com/schedule/%s/lives'%(VhHSWoUmvreJGDiKzAaCuQwkxTYcFO)
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnj=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.callRequestCookies('Get',VhHSWoUmvreJGDiKzAaCuQwkxTYcnI,payload=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,params=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,headers=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,cookies=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,redirects=VhHSWoUmvreJGDiKzAaCuQwkxTYcOf)
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.status_code!=200:return ''
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnB=json.loads(VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.text)
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFq=VhHSWoUmvreJGDiKzAaCuQwkxTYcnB.get('result').get('lives')[0]
   if setBitrate=='5000':
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFp=VhHSWoUmvreJGDiKzAaCuQwkxTYcFq.get('rtmpPlayUrl1080')
   else:
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFp=VhHSWoUmvreJGDiKzAaCuQwkxTYcFq.get('rtmpPlayUrl720')
  except VhHSWoUmvreJGDiKzAaCuQwkxTYcOl as exception:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcOP(exception)
   return ''
  return VhHSWoUmvreJGDiKzAaCuQwkxTYcFp
 def GetStreamingRtmp(VhHSWoUmvreJGDiKzAaCuQwkxTYcng,VhHSWoUmvreJGDiKzAaCuQwkxTYcFO,setBitrate):
  VhHSWoUmvreJGDiKzAaCuQwkxTYcFp=''
  try:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnI='https://api-gw.sports.naver.com/schedule/%s/lives/first'%(VhHSWoUmvreJGDiKzAaCuQwkxTYcFO)
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFb={'fields':'basic,sportslive'}
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnj=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.callRequestCookies('Get',VhHSWoUmvreJGDiKzAaCuQwkxTYcnI,payload=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,params=VhHSWoUmvreJGDiKzAaCuQwkxTYcFb,headers=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,cookies=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,redirects=VhHSWoUmvreJGDiKzAaCuQwkxTYcOf)
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.status_code!=200:return ''
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnB=json.loads(VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.text)
   VhHSWoUmvreJGDiKzAaCuQwkxTYcgn=VhHSWoUmvreJGDiKzAaCuQwkxTYcnB.get('result').get('liveId')
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcgn=='':return ''
  except VhHSWoUmvreJGDiKzAaCuQwkxTYcOl as exception:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcOP(exception)
   return ''
  try:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnI='https://proxy-gateway.sports.naver.com/livecloud/lives/%s/playback'%(VhHSWoUmvreJGDiKzAaCuQwkxTYcgn)
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFb={'countryCode':'KR','devt':'HTML5_PC','timeMachine':'true','p2p':'true','includeThumbnail':'true',}
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnj=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.callRequestCookies('Get',VhHSWoUmvreJGDiKzAaCuQwkxTYcnI,payload=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,params=VhHSWoUmvreJGDiKzAaCuQwkxTYcFb,headers=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,cookies=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,redirects=VhHSWoUmvreJGDiKzAaCuQwkxTYcOf)
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.status_code!=200:return ''
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnB=json.loads(VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.text)
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFq=VhHSWoUmvreJGDiKzAaCuQwkxTYcnB.get('media')
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcFq=='':return ''
   VhHSWoUmvreJGDiKzAaCuQwkxTYcFp=VhHSWoUmvreJGDiKzAaCuQwkxTYcFq[0].get('path')
  except VhHSWoUmvreJGDiKzAaCuQwkxTYcOl as exception:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcOP(exception)
   return ''
  return VhHSWoUmvreJGDiKzAaCuQwkxTYcFp
 def Get_BSList_Json(VhHSWoUmvreJGDiKzAaCuQwkxTYcng):
  VhHSWoUmvreJGDiKzAaCuQwkxTYcnt=[]
  VhHSWoUmvreJGDiKzAaCuQwkxTYcns =VhHSWoUmvreJGDiKzAaCuQwkxTYcng.make_viewdate(dtype='2')
  try:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnI='https://sports.news.naver.com/scoreboard/index.nhn'
   for VhHSWoUmvreJGDiKzAaCuQwkxTYcgF in VhHSWoUmvreJGDiKzAaCuQwkxTYcns:
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgO=[]
    VhHSWoUmvreJGDiKzAaCuQwkxTYcFI={'date':VhHSWoUmvreJGDiKzAaCuQwkxTYcgF}
    VhHSWoUmvreJGDiKzAaCuQwkxTYcnj=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.callRequestCookies('Get',VhHSWoUmvreJGDiKzAaCuQwkxTYcnI,payload=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,params=VhHSWoUmvreJGDiKzAaCuQwkxTYcFI,headers=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj,cookies=VhHSWoUmvreJGDiKzAaCuQwkxTYcOj)
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.status_code!=200:return[]
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgR=BeautifulSoup(VhHSWoUmvreJGDiKzAaCuQwkxTYcnj.text,'html.parser')
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgR=VhHSWoUmvreJGDiKzAaCuQwkxTYcgR.select_one('#content > div > table > tbody')
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgy='%s-%s-%s'%(VhHSWoUmvreJGDiKzAaCuQwkxTYcgF[:4],VhHSWoUmvreJGDiKzAaCuQwkxTYcgF[4:6],VhHSWoUmvreJGDiKzAaCuQwkxTYcgF[-2:])
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgM=VhHSWoUmvreJGDiKzAaCuQwkxTYcgR.find('tr')
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgO+=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.Get_NowTag_List(VhHSWoUmvreJGDiKzAaCuQwkxTYcgM,VhHSWoUmvreJGDiKzAaCuQwkxTYcgy)
    for VhHSWoUmvreJGDiKzAaCuQwkxTYcgM in VhHSWoUmvreJGDiKzAaCuQwkxTYcgM.next_siblings:
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcOE(VhHSWoUmvreJGDiKzAaCuQwkxTYcOq(VhHSWoUmvreJGDiKzAaCuQwkxTYcgM))!="<class 'bs4.element.Tag'>":continue
     VhHSWoUmvreJGDiKzAaCuQwkxTYcgO+=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.Get_NowTag_List(VhHSWoUmvreJGDiKzAaCuQwkxTYcgM,VhHSWoUmvreJGDiKzAaCuQwkxTYcgy)
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgX=''
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgN=''
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgd =''
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgt=''
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgs=''
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgI=''
    for VhHSWoUmvreJGDiKzAaCuQwkxTYcgj in VhHSWoUmvreJGDiKzAaCuQwkxTYcgO:
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('class')=='game' :VhHSWoUmvreJGDiKzAaCuQwkxTYcgX =VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('cont')
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('class')=='time' :VhHSWoUmvreJGDiKzAaCuQwkxTYcgN =VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('cont')
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('class')=='ing' :VhHSWoUmvreJGDiKzAaCuQwkxTYcgd =VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('cont')
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('class')=='title':VhHSWoUmvreJGDiKzAaCuQwkxTYcgt =VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('cont')
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('class')=='gameId':VhHSWoUmvreJGDiKzAaCuQwkxTYcgs=VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('cont')
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('class')=='relay':
      VhHSWoUmvreJGDiKzAaCuQwkxTYcgB='-'
      for VhHSWoUmvreJGDiKzAaCuQwkxTYcgf in VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('cont'):
       if VhHSWoUmvreJGDiKzAaCuQwkxTYcgf.get('live')in['Y','N']:
        VhHSWoUmvreJGDiKzAaCuQwkxTYcgB=VhHSWoUmvreJGDiKzAaCuQwkxTYcgf.get('live')
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('class')=='place':
      if VhHSWoUmvreJGDiKzAaCuQwkxTYcgB not in['Y','N']:continue
      VhHSWoUmvreJGDiKzAaCuQwkxTYcgI=VhHSWoUmvreJGDiKzAaCuQwkxTYcgj.get('cont')
      VhHSWoUmvreJGDiKzAaCuQwkxTYcgL={'category':VhHSWoUmvreJGDiKzAaCuQwkxTYcgX,'time':VhHSWoUmvreJGDiKzAaCuQwkxTYcgN,'title':' '.join(VhHSWoUmvreJGDiKzAaCuQwkxTYcgt.split()),'gameId':VhHSWoUmvreJGDiKzAaCuQwkxTYcgs,'live':VhHSWoUmvreJGDiKzAaCuQwkxTYcgB,'ing':VhHSWoUmvreJGDiKzAaCuQwkxTYcgd,'place':VhHSWoUmvreJGDiKzAaCuQwkxTYcgI,}
      VhHSWoUmvreJGDiKzAaCuQwkxTYcnt.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcgL)
  except VhHSWoUmvreJGDiKzAaCuQwkxTYcOl as exception:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcOP(exception)
   return[]
  return VhHSWoUmvreJGDiKzAaCuQwkxTYcnt
 def Get_NowTag_List(VhHSWoUmvreJGDiKzAaCuQwkxTYcng,VhHSWoUmvreJGDiKzAaCuQwkxTYcgM,VhHSWoUmvreJGDiKzAaCuQwkxTYcgy):
  VhHSWoUmvreJGDiKzAaCuQwkxTYcgO=[]
  VhHSWoUmvreJGDiKzAaCuQwkxTYcgP=VhHSWoUmvreJGDiKzAaCuQwkxTYcgM.find_all('td')
  for VhHSWoUmvreJGDiKzAaCuQwkxTYcgl in VhHSWoUmvreJGDiKzAaCuQwkxTYcgP:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcgp=VhHSWoUmvreJGDiKzAaCuQwkxTYcgl.get('class')[0]
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcgp=='game':
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgE={'class':'game','cont':VhHSWoUmvreJGDiKzAaCuQwkxTYcgl.text,}
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgO.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcgE)
   elif VhHSWoUmvreJGDiKzAaCuQwkxTYcgp=='time':
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgE={'class':'time','cont':VhHSWoUmvreJGDiKzAaCuQwkxTYcgy+' '+VhHSWoUmvreJGDiKzAaCuQwkxTYcgl.text,}
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgO.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcgE)
   elif VhHSWoUmvreJGDiKzAaCuQwkxTYcgp=='gameinfo':
    pass
   elif VhHSWoUmvreJGDiKzAaCuQwkxTYcgp=='state':
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgq=VhHSWoUmvreJGDiKzAaCuQwkxTYcgl.find_all('img')
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgb='-'
    for VhHSWoUmvreJGDiKzAaCuQwkxTYcOn in VhHSWoUmvreJGDiKzAaCuQwkxTYcgq:
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcOn.get('alt')=='진행중':
      VhHSWoUmvreJGDiKzAaCuQwkxTYcgb='Y'
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgE={'class':'ing','cont':VhHSWoUmvreJGDiKzAaCuQwkxTYcgb,}
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgO.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcgE)
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgE={'class':'title','cont':VhHSWoUmvreJGDiKzAaCuQwkxTYcgl.text,}
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgO.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcgE)
   elif VhHSWoUmvreJGDiKzAaCuQwkxTYcgp=='relay':
    VhHSWoUmvreJGDiKzAaCuQwkxTYcOF=''
    VhHSWoUmvreJGDiKzAaCuQwkxTYcOg=VhHSWoUmvreJGDiKzAaCuQwkxTYcgl.find('a')
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcOg:
     VhHSWoUmvreJGDiKzAaCuQwkxTYcOR=VhHSWoUmvreJGDiKzAaCuQwkxTYcOg.get('href')
     if "'" in VhHSWoUmvreJGDiKzAaCuQwkxTYcOR:VhHSWoUmvreJGDiKzAaCuQwkxTYcOR=VhHSWoUmvreJGDiKzAaCuQwkxTYcOR.split("'")[1]
     VhHSWoUmvreJGDiKzAaCuQwkxTYcOy=urllib.parse.urlsplit(VhHSWoUmvreJGDiKzAaCuQwkxTYcOR)
     VhHSWoUmvreJGDiKzAaCuQwkxTYcOy=VhHSWoUmvreJGDiKzAaCuQwkxTYcOb(urllib.parse.parse_qsl(VhHSWoUmvreJGDiKzAaCuQwkxTYcOy.query))
     VhHSWoUmvreJGDiKzAaCuQwkxTYcOF=VhHSWoUmvreJGDiKzAaCuQwkxTYcOy.get('gameId')
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgE={'class':'gameId','cont':VhHSWoUmvreJGDiKzAaCuQwkxTYcOF,}
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgO.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcgE)
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgq=VhHSWoUmvreJGDiKzAaCuQwkxTYcgl.find_all('img')
    VhHSWoUmvreJGDiKzAaCuQwkxTYcOM=[]
    for VhHSWoUmvreJGDiKzAaCuQwkxTYcOn in VhHSWoUmvreJGDiKzAaCuQwkxTYcgq:
     VhHSWoUmvreJGDiKzAaCuQwkxTYcOX =VhHSWoUmvreJGDiKzAaCuQwkxTYcOn.get('alt')
     VhHSWoUmvreJGDiKzAaCuQwkxTYcON=VhHSWoUmvreJGDiKzAaCuQwkxTYcOn.get('onclick')
     VhHSWoUmvreJGDiKzAaCuQwkxTYcOd ='-'
     if VhHSWoUmvreJGDiKzAaCuQwkxTYcON:
      if "'scb.tv'" in VhHSWoUmvreJGDiKzAaCuQwkxTYcON:VhHSWoUmvreJGDiKzAaCuQwkxTYcOd='Y'
      elif "'scb.tv_off'" in VhHSWoUmvreJGDiKzAaCuQwkxTYcON:VhHSWoUmvreJGDiKzAaCuQwkxTYcOd='N'
     VhHSWoUmvreJGDiKzAaCuQwkxTYcOM.append({'alt':VhHSWoUmvreJGDiKzAaCuQwkxTYcOX,'live':VhHSWoUmvreJGDiKzAaCuQwkxTYcOd})
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgE={'class':'relay','cont':VhHSWoUmvreJGDiKzAaCuQwkxTYcOM,}
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgO.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcgE)
   elif VhHSWoUmvreJGDiKzAaCuQwkxTYcgp=='place':
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgE={'class':'place','cont':VhHSWoUmvreJGDiKzAaCuQwkxTYcgl.text,}
    VhHSWoUmvreJGDiKzAaCuQwkxTYcgO.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcgE)
   else:
    VhHSWoUmvreJGDiKzAaCuQwkxTYcOP(VhHSWoUmvreJGDiKzAaCuQwkxTYcgp)
  return VhHSWoUmvreJGDiKzAaCuQwkxTYcgO
 def Get_Category_BSjson(VhHSWoUmvreJGDiKzAaCuQwkxTYcng):
  VhHSWoUmvreJGDiKzAaCuQwkxTYcnt=[]
  VhHSWoUmvreJGDiKzAaCuQwkxTYcnf=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.Get_BSList_Json()
  VhHSWoUmvreJGDiKzAaCuQwkxTYcOt=[]
  for VhHSWoUmvreJGDiKzAaCuQwkxTYcOs in VhHSWoUmvreJGDiKzAaCuQwkxTYcnf:
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcOs.get('category')not in VhHSWoUmvreJGDiKzAaCuQwkxTYcOt:
    VhHSWoUmvreJGDiKzAaCuQwkxTYcOt.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcOs.get('category'))
  for VhHSWoUmvreJGDiKzAaCuQwkxTYcnp in VhHSWoUmvreJGDiKzAaCuQwkxTYcOt:
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnE='N'
   for VhHSWoUmvreJGDiKzAaCuQwkxTYcOs in VhHSWoUmvreJGDiKzAaCuQwkxTYcnf:
    if VhHSWoUmvreJGDiKzAaCuQwkxTYcnp==VhHSWoUmvreJGDiKzAaCuQwkxTYcOs.get('category')and VhHSWoUmvreJGDiKzAaCuQwkxTYcOs.get('live')=='Y':
     VhHSWoUmvreJGDiKzAaCuQwkxTYcnE='Y'
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnL={'category':VhHSWoUmvreJGDiKzAaCuQwkxTYcnp,'live':VhHSWoUmvreJGDiKzAaCuQwkxTYcnE,}
   VhHSWoUmvreJGDiKzAaCuQwkxTYcnt.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcnL)
  return VhHSWoUmvreJGDiKzAaCuQwkxTYcnt
 def Get_Gamelist_BSjson(VhHSWoUmvreJGDiKzAaCuQwkxTYcng,category):
  VhHSWoUmvreJGDiKzAaCuQwkxTYcnt =[]
  VhHSWoUmvreJGDiKzAaCuQwkxTYcnf=VhHSWoUmvreJGDiKzAaCuQwkxTYcng.Get_BSList_Json()
  for VhHSWoUmvreJGDiKzAaCuQwkxTYcOs in VhHSWoUmvreJGDiKzAaCuQwkxTYcnf:
   if VhHSWoUmvreJGDiKzAaCuQwkxTYcOs.get('category')==category:
    VhHSWoUmvreJGDiKzAaCuQwkxTYcnt.append(VhHSWoUmvreJGDiKzAaCuQwkxTYcOs)
  return VhHSWoUmvreJGDiKzAaCuQwkxTYcnt
# Created by pyminifier (https://github.com/liftoff/pyminifier)
