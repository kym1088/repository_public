__author__="NightRain"
VPdGotrJDnxSbaHmTsyOXzuMcqiCve=object
VPdGotrJDnxSbaHmTsyOXzuMcqiCvl=None
VPdGotrJDnxSbaHmTsyOXzuMcqiCvB=True
VPdGotrJDnxSbaHmTsyOXzuMcqiCvY=False
VPdGotrJDnxSbaHmTsyOXzuMcqiCvh=type
VPdGotrJDnxSbaHmTsyOXzuMcqiCvQ=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
VPdGotrJDnxSbaHmTsyOXzuMcqiCUv=[{'title':'경기별 보기 (타입1)','mode':'CATEGORY_LIST'},{'title':'경기별 보기 (타입2)','mode':'BS_CATEGORY'},{'title':'채널별 보기','mode':'CHANNEL_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'** 경기중이 아닐때에는 시청이 제한될수 있음 **','mode':'XXX'},]
VPdGotrJDnxSbaHmTsyOXzuMcqiCUf=[{'chId':'ad1','title':'Spotv1'},{'chId':'ad2','title':'KBS N Sports'},{'chId':'ad3','title':'SBS Sports'},{'chId':'ad4','title':'MBC Sports'},{'chId':'ad5','title':'Spotv2'},]
from nsportsCore import*
class VPdGotrJDnxSbaHmTsyOXzuMcqiCUA(VPdGotrJDnxSbaHmTsyOXzuMcqiCve):
 def __init__(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW,VPdGotrJDnxSbaHmTsyOXzuMcqiCUL,VPdGotrJDnxSbaHmTsyOXzuMcqiCUR,VPdGotrJDnxSbaHmTsyOXzuMcqiCUe):
  VPdGotrJDnxSbaHmTsyOXzuMcqiCUW._addon_url =VPdGotrJDnxSbaHmTsyOXzuMcqiCUL
  VPdGotrJDnxSbaHmTsyOXzuMcqiCUW._addon_handle=VPdGotrJDnxSbaHmTsyOXzuMcqiCUR
  VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.main_params =VPdGotrJDnxSbaHmTsyOXzuMcqiCUe
  VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.NsportsObj =VhHSWoUmvreJGDiKzAaCuQwkxTYcnF() 
 def addon_noti(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW,sting):
  try:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUB=xbmcgui.Dialog()
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUB.notification(__addonname__,sting)
  except:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCvl
 def addon_log(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW,string):
  try:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUY=string.encode('utf-8','ignore')
  except:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUY='addonException: addon_log'
  VPdGotrJDnxSbaHmTsyOXzuMcqiCUh=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,VPdGotrJDnxSbaHmTsyOXzuMcqiCUY),level=VPdGotrJDnxSbaHmTsyOXzuMcqiCUh)
 def get_Bitrate_sel(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW):
  VPdGotrJDnxSbaHmTsyOXzuMcqiCUQ={'0':'5000','1':'2000','2':'800',}
  return VPdGotrJDnxSbaHmTsyOXzuMcqiCUQ.get(__addon__.getSetting('selected_quality'))
 def add_dir(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW,label,sublabel='',img='',infoLabels=VPdGotrJDnxSbaHmTsyOXzuMcqiCvl,isFolder=VPdGotrJDnxSbaHmTsyOXzuMcqiCvB,params='',isLink=VPdGotrJDnxSbaHmTsyOXzuMcqiCvY,ContextMenu=VPdGotrJDnxSbaHmTsyOXzuMcqiCvl):
  VPdGotrJDnxSbaHmTsyOXzuMcqiCUw='%s?%s'%(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW._addon_url,urllib.parse.urlencode(params))
  if sublabel:VPdGotrJDnxSbaHmTsyOXzuMcqiCUk='%s < %s >'%(label,sublabel)
  else: VPdGotrJDnxSbaHmTsyOXzuMcqiCUk=label
  if not img:img='DefaultFolder.png'
  VPdGotrJDnxSbaHmTsyOXzuMcqiCUg=xbmcgui.ListItem(VPdGotrJDnxSbaHmTsyOXzuMcqiCUk)
  if VPdGotrJDnxSbaHmTsyOXzuMcqiCvh(img)==VPdGotrJDnxSbaHmTsyOXzuMcqiCvQ:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUg.setArt(img)
  else:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUg.setArt({'thumb':img,'poster':img})
  if infoLabels:VPdGotrJDnxSbaHmTsyOXzuMcqiCUg.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUg.setProperty('IsPlayable','true')
  if ContextMenu:VPdGotrJDnxSbaHmTsyOXzuMcqiCUg.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW._addon_handle,VPdGotrJDnxSbaHmTsyOXzuMcqiCUw,VPdGotrJDnxSbaHmTsyOXzuMcqiCUg,isFolder)
 def dp_Main_List(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW,args):
  for VPdGotrJDnxSbaHmTsyOXzuMcqiCUF in VPdGotrJDnxSbaHmTsyOXzuMcqiCUv:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUk=VPdGotrJDnxSbaHmTsyOXzuMcqiCUF.get('title')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUK=''
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUN={'mode':VPdGotrJDnxSbaHmTsyOXzuMcqiCUF.get('mode'),}
   if VPdGotrJDnxSbaHmTsyOXzuMcqiCUF.get('mode')in['XXX']:
    VPdGotrJDnxSbaHmTsyOXzuMcqiCUj=VPdGotrJDnxSbaHmTsyOXzuMcqiCvY
    VPdGotrJDnxSbaHmTsyOXzuMcqiCUp =VPdGotrJDnxSbaHmTsyOXzuMcqiCvB
   else:
    VPdGotrJDnxSbaHmTsyOXzuMcqiCUj=VPdGotrJDnxSbaHmTsyOXzuMcqiCvB
    VPdGotrJDnxSbaHmTsyOXzuMcqiCUp =VPdGotrJDnxSbaHmTsyOXzuMcqiCvY
   if 'icon' in VPdGotrJDnxSbaHmTsyOXzuMcqiCUF:VPdGotrJDnxSbaHmTsyOXzuMcqiCUK=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',VPdGotrJDnxSbaHmTsyOXzuMcqiCUF.get('icon')) 
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.add_dir(VPdGotrJDnxSbaHmTsyOXzuMcqiCUk,sublabel='',img=VPdGotrJDnxSbaHmTsyOXzuMcqiCUK,infoLabels=VPdGotrJDnxSbaHmTsyOXzuMcqiCvl,isFolder=VPdGotrJDnxSbaHmTsyOXzuMcqiCUj,params=VPdGotrJDnxSbaHmTsyOXzuMcqiCUN,isLink=VPdGotrJDnxSbaHmTsyOXzuMcqiCUp)
  xbmcplugin.endOfDirectory(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW._addon_handle)
 def dp_Channel_List(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW,args):
  VPdGotrJDnxSbaHmTsyOXzuMcqiCUE=VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.get_Bitrate_sel()
  for VPdGotrJDnxSbaHmTsyOXzuMcqiCAU in VPdGotrJDnxSbaHmTsyOXzuMcqiCUf:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUk=VPdGotrJDnxSbaHmTsyOXzuMcqiCAU.get('title')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAv=VPdGotrJDnxSbaHmTsyOXzuMcqiCAU.get('chId')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAf={'mediatype':'episode','title':VPdGotrJDnxSbaHmTsyOXzuMcqiCUk}
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUN={'mode':'CLIVE','chId':VPdGotrJDnxSbaHmTsyOXzuMcqiCAv,'maxBitrate':VPdGotrJDnxSbaHmTsyOXzuMcqiCUE,}
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.add_dir(VPdGotrJDnxSbaHmTsyOXzuMcqiCUk,sublabel='',img='',infoLabels=VPdGotrJDnxSbaHmTsyOXzuMcqiCAf,isFolder=VPdGotrJDnxSbaHmTsyOXzuMcqiCvY,params=VPdGotrJDnxSbaHmTsyOXzuMcqiCUN,isLink=VPdGotrJDnxSbaHmTsyOXzuMcqiCvY)
  xbmcplugin.endOfDirectory(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW._addon_handle)
 def dp_Category_List(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW,args):
  VPdGotrJDnxSbaHmTsyOXzuMcqiCAW=VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.NsportsObj.Get_Category_List()
  for VPdGotrJDnxSbaHmTsyOXzuMcqiCAL in VPdGotrJDnxSbaHmTsyOXzuMcqiCAW:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAR =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('groupnm')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAe =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('onairyn')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAl=','.join(VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('category'))
   if VPdGotrJDnxSbaHmTsyOXzuMcqiCAe=='Y':VPdGotrJDnxSbaHmTsyOXzuMcqiCUI='중계중'
   else:VPdGotrJDnxSbaHmTsyOXzuMcqiCUI=''
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUN={'mode':'GAME_LIST','category':VPdGotrJDnxSbaHmTsyOXzuMcqiCAl,}
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.add_dir(VPdGotrJDnxSbaHmTsyOXzuMcqiCAR,sublabel=VPdGotrJDnxSbaHmTsyOXzuMcqiCUI,img='',infoLabels=VPdGotrJDnxSbaHmTsyOXzuMcqiCvl,isFolder=VPdGotrJDnxSbaHmTsyOXzuMcqiCvB,params=VPdGotrJDnxSbaHmTsyOXzuMcqiCUN)
  xbmcplugin.endOfDirectory(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW._addon_handle,cacheToDisc=VPdGotrJDnxSbaHmTsyOXzuMcqiCvY)
 def dp_Game_List(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW,args):
  VPdGotrJDnxSbaHmTsyOXzuMcqiCAY=args.get('category')
  VPdGotrJDnxSbaHmTsyOXzuMcqiCAW=VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.NsportsObj.Get_Game_List(VPdGotrJDnxSbaHmTsyOXzuMcqiCAY)
  for VPdGotrJDnxSbaHmTsyOXzuMcqiCAL in VPdGotrJDnxSbaHmTsyOXzuMcqiCAW:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAh =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('gameId')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAQ =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('upperCategoryId')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAw =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('categoryId')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAk =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('statusCode')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAg =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('statusInfo')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAF =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('isOnAirTv')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAv =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('chId')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUk =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('title')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAK =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('starttime')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAN =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('endTime')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAj =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('maxBitrate')
   if VPdGotrJDnxSbaHmTsyOXzuMcqiCUk=='':VPdGotrJDnxSbaHmTsyOXzuMcqiCUk=VPdGotrJDnxSbaHmTsyOXzuMcqiCAh
   if VPdGotrJDnxSbaHmTsyOXzuMcqiCAF=='Y':
    VPdGotrJDnxSbaHmTsyOXzuMcqiCAp='방송중'
   else:
    if VPdGotrJDnxSbaHmTsyOXzuMcqiCAg=='경기취소':
     VPdGotrJDnxSbaHmTsyOXzuMcqiCAp=VPdGotrJDnxSbaHmTsyOXzuMcqiCAg
    else:
     VPdGotrJDnxSbaHmTsyOXzuMcqiCAp=''
   if VPdGotrJDnxSbaHmTsyOXzuMcqiCAK=='':
    VPdGotrJDnxSbaHmTsyOXzuMcqiCUI=VPdGotrJDnxSbaHmTsyOXzuMcqiCAp
   else:
    if VPdGotrJDnxSbaHmTsyOXzuMcqiCAp=='':
     VPdGotrJDnxSbaHmTsyOXzuMcqiCUI=VPdGotrJDnxSbaHmTsyOXzuMcqiCAK
    else:
     VPdGotrJDnxSbaHmTsyOXzuMcqiCUI=VPdGotrJDnxSbaHmTsyOXzuMcqiCAK+' - '+VPdGotrJDnxSbaHmTsyOXzuMcqiCAp
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAf={'mediatype':'episode','title':VPdGotrJDnxSbaHmTsyOXzuMcqiCUk,'plot':'%s\n\n시작 : %s\n종료 : %s'%(VPdGotrJDnxSbaHmTsyOXzuMcqiCUk,VPdGotrJDnxSbaHmTsyOXzuMcqiCAK,VPdGotrJDnxSbaHmTsyOXzuMcqiCAN)}
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUN={'mode':'LIVE','chId':VPdGotrJDnxSbaHmTsyOXzuMcqiCAv,'maxBitrate':VPdGotrJDnxSbaHmTsyOXzuMcqiCAj,'gameId':VPdGotrJDnxSbaHmTsyOXzuMcqiCAh,}
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.add_dir(VPdGotrJDnxSbaHmTsyOXzuMcqiCUk,sublabel=VPdGotrJDnxSbaHmTsyOXzuMcqiCUI,img='',infoLabels=VPdGotrJDnxSbaHmTsyOXzuMcqiCAf,isFolder=VPdGotrJDnxSbaHmTsyOXzuMcqiCvY,params=VPdGotrJDnxSbaHmTsyOXzuMcqiCUN)
  xbmcplugin.endOfDirectory(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW._addon_handle,cacheToDisc=VPdGotrJDnxSbaHmTsyOXzuMcqiCvY)
 def dp_BsCategory_List(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW,args):
  VPdGotrJDnxSbaHmTsyOXzuMcqiCAW=VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.NsportsObj.Get_Category_BSjson()
  for VPdGotrJDnxSbaHmTsyOXzuMcqiCAL in VPdGotrJDnxSbaHmTsyOXzuMcqiCAW:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAl =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('category')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAI =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('live')
   if VPdGotrJDnxSbaHmTsyOXzuMcqiCAI=='Y':VPdGotrJDnxSbaHmTsyOXzuMcqiCUI='중계중'
   else:VPdGotrJDnxSbaHmTsyOXzuMcqiCUI=''
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUN={'mode':'BS_GAME','category':VPdGotrJDnxSbaHmTsyOXzuMcqiCAl,}
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.add_dir(VPdGotrJDnxSbaHmTsyOXzuMcqiCAl,sublabel=VPdGotrJDnxSbaHmTsyOXzuMcqiCUI,img='',infoLabels=VPdGotrJDnxSbaHmTsyOXzuMcqiCvl,isFolder=VPdGotrJDnxSbaHmTsyOXzuMcqiCvB,params=VPdGotrJDnxSbaHmTsyOXzuMcqiCUN)
  xbmcplugin.endOfDirectory(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW._addon_handle,cacheToDisc=VPdGotrJDnxSbaHmTsyOXzuMcqiCvY)
 def dp_BsGame_List(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW,args):
  VPdGotrJDnxSbaHmTsyOXzuMcqiCAl=args.get('category')
  VPdGotrJDnxSbaHmTsyOXzuMcqiCAW=VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.NsportsObj.Get_Gamelist_BSjson(VPdGotrJDnxSbaHmTsyOXzuMcqiCAl)
  for VPdGotrJDnxSbaHmTsyOXzuMcqiCAL in VPdGotrJDnxSbaHmTsyOXzuMcqiCAW:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAh =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('gameId')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAE =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('time')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUk =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('title')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAI =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('live')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCvU =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('ing')
   VPdGotrJDnxSbaHmTsyOXzuMcqiCvA =VPdGotrJDnxSbaHmTsyOXzuMcqiCAL.get('place')
   if VPdGotrJDnxSbaHmTsyOXzuMcqiCAI=='Y':
    VPdGotrJDnxSbaHmTsyOXzuMcqiCAp='방송중'
   else:
    VPdGotrJDnxSbaHmTsyOXzuMcqiCAp=''
   if VPdGotrJDnxSbaHmTsyOXzuMcqiCAp=='':
    VPdGotrJDnxSbaHmTsyOXzuMcqiCUI=VPdGotrJDnxSbaHmTsyOXzuMcqiCAE
   else:
    VPdGotrJDnxSbaHmTsyOXzuMcqiCUI=VPdGotrJDnxSbaHmTsyOXzuMcqiCAE+' - '+VPdGotrJDnxSbaHmTsyOXzuMcqiCAp
   VPdGotrJDnxSbaHmTsyOXzuMcqiCAf={'mediatype':'episode','title':VPdGotrJDnxSbaHmTsyOXzuMcqiCUk,'plot':'%s\n\n시간 : %s\n\n%s'%(VPdGotrJDnxSbaHmTsyOXzuMcqiCUk,VPdGotrJDnxSbaHmTsyOXzuMcqiCUI,VPdGotrJDnxSbaHmTsyOXzuMcqiCvA)}
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUN={'mode':'LIVE','gameId':VPdGotrJDnxSbaHmTsyOXzuMcqiCAh,}
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.add_dir(VPdGotrJDnxSbaHmTsyOXzuMcqiCUk,sublabel=VPdGotrJDnxSbaHmTsyOXzuMcqiCUI,img='',infoLabels=VPdGotrJDnxSbaHmTsyOXzuMcqiCAf,isFolder=VPdGotrJDnxSbaHmTsyOXzuMcqiCvY,params=VPdGotrJDnxSbaHmTsyOXzuMcqiCUN)
  xbmcplugin.endOfDirectory(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW._addon_handle,cacheToDisc=VPdGotrJDnxSbaHmTsyOXzuMcqiCvY)
 def play_VIDEO(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW,args):
  VPdGotrJDnxSbaHmTsyOXzuMcqiCAh =args.get('gameId')
  VPdGotrJDnxSbaHmTsyOXzuMcqiCvf =VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.get_Bitrate_sel()
  if VPdGotrJDnxSbaHmTsyOXzuMcqiCAh=='' or VPdGotrJDnxSbaHmTsyOXzuMcqiCAh==VPdGotrJDnxSbaHmTsyOXzuMcqiCvl:return
  VPdGotrJDnxSbaHmTsyOXzuMcqiCvW=VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.NsportsObj.GetStreamingRtmp(VPdGotrJDnxSbaHmTsyOXzuMcqiCAh,VPdGotrJDnxSbaHmTsyOXzuMcqiCvf)
  if VPdGotrJDnxSbaHmTsyOXzuMcqiCvW=='':
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.addon_noti(__language__(30901).encode('utf8'))
   return
  VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.addon_log(VPdGotrJDnxSbaHmTsyOXzuMcqiCvW)
  VPdGotrJDnxSbaHmTsyOXzuMcqiCvL=xbmcgui.ListItem(path=VPdGotrJDnxSbaHmTsyOXzuMcqiCvW)
  xbmcplugin.setResolvedUrl(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW._addon_handle,VPdGotrJDnxSbaHmTsyOXzuMcqiCvB,VPdGotrJDnxSbaHmTsyOXzuMcqiCvL)
 def play_CHANNEL(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW,args):
  VPdGotrJDnxSbaHmTsyOXzuMcqiCAv =args.get('chId')
  VPdGotrJDnxSbaHmTsyOXzuMcqiCAj =args.get('maxBitrate')
  VPdGotrJDnxSbaHmTsyOXzuMcqiCvf =VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.get_Bitrate_sel()
  VPdGotrJDnxSbaHmTsyOXzuMcqiCvW=VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.NsportsObj.GetStreamingURL(VPdGotrJDnxSbaHmTsyOXzuMcqiCAv,VPdGotrJDnxSbaHmTsyOXzuMcqiCvf,VPdGotrJDnxSbaHmTsyOXzuMcqiCAj)
  if VPdGotrJDnxSbaHmTsyOXzuMcqiCvW=='':
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.addon_noti(__language__(30901).encode('utf8'))
   return
  VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.addon_log(VPdGotrJDnxSbaHmTsyOXzuMcqiCvW)
  VPdGotrJDnxSbaHmTsyOXzuMcqiCvL=xbmcgui.ListItem(path=VPdGotrJDnxSbaHmTsyOXzuMcqiCvW)
  xbmcplugin.setResolvedUrl(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW._addon_handle,VPdGotrJDnxSbaHmTsyOXzuMcqiCvB,VPdGotrJDnxSbaHmTsyOXzuMcqiCvL)
 def nsports_main(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW):
  VPdGotrJDnxSbaHmTsyOXzuMcqiCvR=VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.main_params.get('mode',VPdGotrJDnxSbaHmTsyOXzuMcqiCvl)
  if VPdGotrJDnxSbaHmTsyOXzuMcqiCvR is VPdGotrJDnxSbaHmTsyOXzuMcqiCvl:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.dp_Main_List(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.main_params)
  elif VPdGotrJDnxSbaHmTsyOXzuMcqiCvR=='CATEGORY_LIST':
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.dp_Category_List(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.main_params)
  elif VPdGotrJDnxSbaHmTsyOXzuMcqiCvR=='BS_CATEGORY':
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.dp_BsCategory_List(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.main_params)
  elif VPdGotrJDnxSbaHmTsyOXzuMcqiCvR=='GAME_LIST':
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.dp_Game_List(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.main_params)
  elif VPdGotrJDnxSbaHmTsyOXzuMcqiCvR=='BS_GAME':
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.dp_BsGame_List(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.main_params)
  elif VPdGotrJDnxSbaHmTsyOXzuMcqiCvR=='LIVE':
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.play_VIDEO(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.main_params)
  elif VPdGotrJDnxSbaHmTsyOXzuMcqiCvR=='CLIVE':
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.play_CHANNEL(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.main_params)
  elif VPdGotrJDnxSbaHmTsyOXzuMcqiCvR=='CHANNEL_LIST':
   VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.dp_Channel_List(VPdGotrJDnxSbaHmTsyOXzuMcqiCUW.main_params)
  else:
   VPdGotrJDnxSbaHmTsyOXzuMcqiCvl
# Created by pyminifier (https://github.com/liftoff/pyminifier)
