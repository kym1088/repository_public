__author__="NightRain"
DrXPIkgnWBdLsKtyAeOphQaviESmqx=object
DrXPIkgnWBdLsKtyAeOphQaviESmqF=None
DrXPIkgnWBdLsKtyAeOphQaviESmqR=False
DrXPIkgnWBdLsKtyAeOphQaviESmqM=True
DrXPIkgnWBdLsKtyAeOphQaviESmqf=len
DrXPIkgnWBdLsKtyAeOphQaviESmqz=print
DrXPIkgnWBdLsKtyAeOphQaviESmqV=Exception
DrXPIkgnWBdLsKtyAeOphQaviESmqT=int
DrXPIkgnWBdLsKtyAeOphQaviESmqb=str
DrXPIkgnWBdLsKtyAeOphQaviESmqN=type
import urllib
import re
import json
import requests
import datetime
from bs4 import BeautifulSoup
class DrXPIkgnWBdLsKtyAeOphQaviESmxF(DrXPIkgnWBdLsKtyAeOphQaviESmqx):
 def __init__(DrXPIkgnWBdLsKtyAeOphQaviESmxq):
  DrXPIkgnWBdLsKtyAeOphQaviESmxq.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36'
  DrXPIkgnWBdLsKtyAeOphQaviESmxq.DEFAULT_HEADER ={'user-agent':DrXPIkgnWBdLsKtyAeOphQaviESmxq.USER_AGENT}
  DrXPIkgnWBdLsKtyAeOphQaviESmxq.genres=[{'groupnm':'야구','category':['kbaseball','wbaseball']},{'groupnm':'축구','category':['kfootball','wfootball']},{'groupnm':'배구','category':['kvolleyball']},{'groupnm':'골프','category':['golf']},{'groupnm':'기타','category':['others']},]
 def callRequestCookies(DrXPIkgnWBdLsKtyAeOphQaviESmxq,jobtype,DrXPIkgnWBdLsKtyAeOphQaviESmxN,payload=DrXPIkgnWBdLsKtyAeOphQaviESmqF,params=DrXPIkgnWBdLsKtyAeOphQaviESmqF,headers=DrXPIkgnWBdLsKtyAeOphQaviESmqF,cookies=DrXPIkgnWBdLsKtyAeOphQaviESmqF,redirects=DrXPIkgnWBdLsKtyAeOphQaviESmqR):
  DrXPIkgnWBdLsKtyAeOphQaviESmxR=DrXPIkgnWBdLsKtyAeOphQaviESmxq.DEFAULT_HEADER
  if headers:DrXPIkgnWBdLsKtyAeOphQaviESmxR.update(headers)
  if jobtype=='Get':
   DrXPIkgnWBdLsKtyAeOphQaviESmxM=requests.get(DrXPIkgnWBdLsKtyAeOphQaviESmxN,params=params,headers=DrXPIkgnWBdLsKtyAeOphQaviESmxR,cookies=cookies,allow_redirects=redirects)
  else:
   DrXPIkgnWBdLsKtyAeOphQaviESmxM=requests.post(DrXPIkgnWBdLsKtyAeOphQaviESmxN,data=payload,params=params,headers=DrXPIkgnWBdLsKtyAeOphQaviESmxR,cookies=cookies,allow_redirects=redirects)
  return DrXPIkgnWBdLsKtyAeOphQaviESmxM
 def Get_Now_Datetime(DrXPIkgnWBdLsKtyAeOphQaviESmxq):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def make_viewdate(DrXPIkgnWBdLsKtyAeOphQaviESmxq):
  DrXPIkgnWBdLsKtyAeOphQaviESmxz =DrXPIkgnWBdLsKtyAeOphQaviESmxq.Get_Now_Datetime()
  DrXPIkgnWBdLsKtyAeOphQaviESmxV=[DrXPIkgnWBdLsKtyAeOphQaviESmxz.strftime('%Y%m%d'),]
  return DrXPIkgnWBdLsKtyAeOphQaviESmxV
 def Get_Category_List(DrXPIkgnWBdLsKtyAeOphQaviESmxq):
  DrXPIkgnWBdLsKtyAeOphQaviESmxT=[]
  DrXPIkgnWBdLsKtyAeOphQaviESmxb=DrXPIkgnWBdLsKtyAeOphQaviESmxq.make_viewdate()
  try:
   DrXPIkgnWBdLsKtyAeOphQaviESmxN='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   DrXPIkgnWBdLsKtyAeOphQaviESmxG=DrXPIkgnWBdLsKtyAeOphQaviESmxq.callRequestCookies('Get',DrXPIkgnWBdLsKtyAeOphQaviESmxN,payload=DrXPIkgnWBdLsKtyAeOphQaviESmqF,params=DrXPIkgnWBdLsKtyAeOphQaviESmqF,headers=DrXPIkgnWBdLsKtyAeOphQaviESmqF,cookies=DrXPIkgnWBdLsKtyAeOphQaviESmqF,redirects=DrXPIkgnWBdLsKtyAeOphQaviESmqM)
   if DrXPIkgnWBdLsKtyAeOphQaviESmxG.status_code!=200:return[]
   DrXPIkgnWBdLsKtyAeOphQaviESmxY=json.loads(DrXPIkgnWBdLsKtyAeOphQaviESmxG.text)
   DrXPIkgnWBdLsKtyAeOphQaviESmxU=DrXPIkgnWBdLsKtyAeOphQaviESmxY.get('gameList')
   DrXPIkgnWBdLsKtyAeOphQaviESmxj=[]
   for DrXPIkgnWBdLsKtyAeOphQaviESmxJ in DrXPIkgnWBdLsKtyAeOphQaviESmxq.genres:
    DrXPIkgnWBdLsKtyAeOphQaviESmxC =DrXPIkgnWBdLsKtyAeOphQaviESmxJ.get('groupnm')
    DrXPIkgnWBdLsKtyAeOphQaviESmxl=[]
    DrXPIkgnWBdLsKtyAeOphQaviESmxo ='N'
    if DrXPIkgnWBdLsKtyAeOphQaviESmqf(DrXPIkgnWBdLsKtyAeOphQaviESmxj)!=0:
     DrXPIkgnWBdLsKtyAeOphQaviESmxU =DrXPIkgnWBdLsKtyAeOphQaviESmxj
     DrXPIkgnWBdLsKtyAeOphQaviESmxj=[]
    for DrXPIkgnWBdLsKtyAeOphQaviESmxu in DrXPIkgnWBdLsKtyAeOphQaviESmxU:
     DrXPIkgnWBdLsKtyAeOphQaviESmxc=DrXPIkgnWBdLsKtyAeOphQaviESmxu.get('upperCategoryId')
     DrXPIkgnWBdLsKtyAeOphQaviESmxw =DrXPIkgnWBdLsKtyAeOphQaviESmxu.get('statusCode')
     DrXPIkgnWBdLsKtyAeOphQaviESmxH =DrXPIkgnWBdLsKtyAeOphQaviESmxu.get('isOnAirTv')
     DrXPIkgnWBdLsKtyAeOphQaviESmFx =DrXPIkgnWBdLsKtyAeOphQaviESmxu.get('gameId')
     if DrXPIkgnWBdLsKtyAeOphQaviESmxc in('esports'):continue
     if DrXPIkgnWBdLsKtyAeOphQaviESmxw in('RESULT'):continue
     if DrXPIkgnWBdLsKtyAeOphQaviESmFx[:8]not in DrXPIkgnWBdLsKtyAeOphQaviESmxb:continue
     if DrXPIkgnWBdLsKtyAeOphQaviESmxc in DrXPIkgnWBdLsKtyAeOphQaviESmxJ.get('category'):
      if DrXPIkgnWBdLsKtyAeOphQaviESmxc not in DrXPIkgnWBdLsKtyAeOphQaviESmxl:DrXPIkgnWBdLsKtyAeOphQaviESmxl.append(DrXPIkgnWBdLsKtyAeOphQaviESmxc)
      if DrXPIkgnWBdLsKtyAeOphQaviESmxH=='Y':DrXPIkgnWBdLsKtyAeOphQaviESmxo='Y'
     else:
      DrXPIkgnWBdLsKtyAeOphQaviESmxj.append(DrXPIkgnWBdLsKtyAeOphQaviESmxu)
    if DrXPIkgnWBdLsKtyAeOphQaviESmqf(DrXPIkgnWBdLsKtyAeOphQaviESmxl)>0:
     DrXPIkgnWBdLsKtyAeOphQaviESmFq={'groupnm':DrXPIkgnWBdLsKtyAeOphQaviESmxC,'onairyn':DrXPIkgnWBdLsKtyAeOphQaviESmxo,'category':DrXPIkgnWBdLsKtyAeOphQaviESmxl,}
     DrXPIkgnWBdLsKtyAeOphQaviESmxT.append(DrXPIkgnWBdLsKtyAeOphQaviESmFq)
   DrXPIkgnWBdLsKtyAeOphQaviESmxC ='-'
   DrXPIkgnWBdLsKtyAeOphQaviESmxl=[]
   DrXPIkgnWBdLsKtyAeOphQaviESmxo ='N'
   for DrXPIkgnWBdLsKtyAeOphQaviESmxu in DrXPIkgnWBdLsKtyAeOphQaviESmxj:
    DrXPIkgnWBdLsKtyAeOphQaviESmxc=DrXPIkgnWBdLsKtyAeOphQaviESmxu.get('upperCategoryId')
    DrXPIkgnWBdLsKtyAeOphQaviESmxH =DrXPIkgnWBdLsKtyAeOphQaviESmxu.get('isOnAirTv')
    if DrXPIkgnWBdLsKtyAeOphQaviESmxc not in DrXPIkgnWBdLsKtyAeOphQaviESmxl:DrXPIkgnWBdLsKtyAeOphQaviESmxl.append(DrXPIkgnWBdLsKtyAeOphQaviESmxc)
    if DrXPIkgnWBdLsKtyAeOphQaviESmxH=='Y':DrXPIkgnWBdLsKtyAeOphQaviESmxo='Y'
   if DrXPIkgnWBdLsKtyAeOphQaviESmqf(DrXPIkgnWBdLsKtyAeOphQaviESmxl)>0:
    DrXPIkgnWBdLsKtyAeOphQaviESmFq={'groupnm':'-','onairyn':DrXPIkgnWBdLsKtyAeOphQaviESmxo,'category':DrXPIkgnWBdLsKtyAeOphQaviESmxl,}
    DrXPIkgnWBdLsKtyAeOphQaviESmxT.append(DrXPIkgnWBdLsKtyAeOphQaviESmFq)
    DrXPIkgnWBdLsKtyAeOphQaviESmqz(DrXPIkgnWBdLsKtyAeOphQaviESmxC,DrXPIkgnWBdLsKtyAeOphQaviESmxo,DrXPIkgnWBdLsKtyAeOphQaviESmxl)
  except DrXPIkgnWBdLsKtyAeOphQaviESmqV as exception:
   DrXPIkgnWBdLsKtyAeOphQaviESmqz(exception)
   return[]
  return DrXPIkgnWBdLsKtyAeOphQaviESmxT
 def Get_Game_List(DrXPIkgnWBdLsKtyAeOphQaviESmxq,category):
  DrXPIkgnWBdLsKtyAeOphQaviESmFR=category.split(',')
  DrXPIkgnWBdLsKtyAeOphQaviESmxT =[]
  DrXPIkgnWBdLsKtyAeOphQaviESmFM =[]
  DrXPIkgnWBdLsKtyAeOphQaviESmFf =[]
  DrXPIkgnWBdLsKtyAeOphQaviESmxb=DrXPIkgnWBdLsKtyAeOphQaviESmxq.make_viewdate()
  try:
   DrXPIkgnWBdLsKtyAeOphQaviESmxN='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   DrXPIkgnWBdLsKtyAeOphQaviESmxG=DrXPIkgnWBdLsKtyAeOphQaviESmxq.callRequestCookies('Get',DrXPIkgnWBdLsKtyAeOphQaviESmxN,payload=DrXPIkgnWBdLsKtyAeOphQaviESmqF,params=DrXPIkgnWBdLsKtyAeOphQaviESmqF,headers=DrXPIkgnWBdLsKtyAeOphQaviESmqF,cookies=DrXPIkgnWBdLsKtyAeOphQaviESmqF,redirects=DrXPIkgnWBdLsKtyAeOphQaviESmqM)
   if DrXPIkgnWBdLsKtyAeOphQaviESmxG.status_code!=200:return[]
   DrXPIkgnWBdLsKtyAeOphQaviESmxY=json.loads(DrXPIkgnWBdLsKtyAeOphQaviESmxG.text)
   DrXPIkgnWBdLsKtyAeOphQaviESmxU=DrXPIkgnWBdLsKtyAeOphQaviESmxY.get('gameList')
   for DrXPIkgnWBdLsKtyAeOphQaviESmxu in DrXPIkgnWBdLsKtyAeOphQaviESmxU:
    DrXPIkgnWBdLsKtyAeOphQaviESmFx =DrXPIkgnWBdLsKtyAeOphQaviESmxu.get('gameId')
    DrXPIkgnWBdLsKtyAeOphQaviESmxc=DrXPIkgnWBdLsKtyAeOphQaviESmxu.get('upperCategoryId')
    DrXPIkgnWBdLsKtyAeOphQaviESmFz =DrXPIkgnWBdLsKtyAeOphQaviESmxu.get('categoryId')
    DrXPIkgnWBdLsKtyAeOphQaviESmxw =DrXPIkgnWBdLsKtyAeOphQaviESmxu.get('statusCode')
    DrXPIkgnWBdLsKtyAeOphQaviESmFV =DrXPIkgnWBdLsKtyAeOphQaviESmxu.get('statusInfo')
    DrXPIkgnWBdLsKtyAeOphQaviESmxH =DrXPIkgnWBdLsKtyAeOphQaviESmxu.get('isOnAirTv')
    if DrXPIkgnWBdLsKtyAeOphQaviESmxc in('esports'):continue
    if DrXPIkgnWBdLsKtyAeOphQaviESmxw in('RESULT'):continue
    if DrXPIkgnWBdLsKtyAeOphQaviESmxc not in DrXPIkgnWBdLsKtyAeOphQaviESmFR:continue
    if DrXPIkgnWBdLsKtyAeOphQaviESmFx[:8]not in DrXPIkgnWBdLsKtyAeOphQaviESmxb:continue
    DrXPIkgnWBdLsKtyAeOphQaviESmFT=DrXPIkgnWBdLsKtyAeOphQaviESmxq.Get_Game_liveInfo(DrXPIkgnWBdLsKtyAeOphQaviESmFx)
    if DrXPIkgnWBdLsKtyAeOphQaviESmFT.get('chId')==DrXPIkgnWBdLsKtyAeOphQaviESmqF:continue
    DrXPIkgnWBdLsKtyAeOphQaviESmFq={'gameId':DrXPIkgnWBdLsKtyAeOphQaviESmFx,'upperCategoryId':DrXPIkgnWBdLsKtyAeOphQaviESmxc,'categoryId':DrXPIkgnWBdLsKtyAeOphQaviESmFz,'statusCode':DrXPIkgnWBdLsKtyAeOphQaviESmxw,'statusInfo':DrXPIkgnWBdLsKtyAeOphQaviESmFV,'isOnAirTv':DrXPIkgnWBdLsKtyAeOphQaviESmxH,'chId':DrXPIkgnWBdLsKtyAeOphQaviESmFT.get('chId'),'title':DrXPIkgnWBdLsKtyAeOphQaviESmFT.get('title'),'starttime':DrXPIkgnWBdLsKtyAeOphQaviESmFT.get('starttime'),'endTime':DrXPIkgnWBdLsKtyAeOphQaviESmFT.get('endTime'),'maxBitrate':DrXPIkgnWBdLsKtyAeOphQaviESmFT.get('maxBitrate'),}
    if DrXPIkgnWBdLsKtyAeOphQaviESmxH=='Y':
     DrXPIkgnWBdLsKtyAeOphQaviESmFM.append(DrXPIkgnWBdLsKtyAeOphQaviESmFq)
    else:
     DrXPIkgnWBdLsKtyAeOphQaviESmFf.append(DrXPIkgnWBdLsKtyAeOphQaviESmFq)
   DrXPIkgnWBdLsKtyAeOphQaviESmxT=DrXPIkgnWBdLsKtyAeOphQaviESmFM+DrXPIkgnWBdLsKtyAeOphQaviESmFf
  except DrXPIkgnWBdLsKtyAeOphQaviESmqV as exception:
   DrXPIkgnWBdLsKtyAeOphQaviESmqz(exception)
   return[]
  return DrXPIkgnWBdLsKtyAeOphQaviESmxT
 def Get_Game_liveInfo(DrXPIkgnWBdLsKtyAeOphQaviESmxq,DrXPIkgnWBdLsKtyAeOphQaviESmFx):
  DrXPIkgnWBdLsKtyAeOphQaviESmFb={}
  try:
   DrXPIkgnWBdLsKtyAeOphQaviESmxN='https://apis.naver.com/pcLive/livePlatform/liveInfo2'
   DrXPIkgnWBdLsKtyAeOphQaviESmFN={'env':'pc','inclAudCh':'0','svcId':'12002','svcLiveId':DrXPIkgnWBdLsKtyAeOphQaviESmFx,}
   DrXPIkgnWBdLsKtyAeOphQaviESmxG=DrXPIkgnWBdLsKtyAeOphQaviESmxq.callRequestCookies('Get',DrXPIkgnWBdLsKtyAeOphQaviESmxN,payload=DrXPIkgnWBdLsKtyAeOphQaviESmqF,params=DrXPIkgnWBdLsKtyAeOphQaviESmFN,headers=DrXPIkgnWBdLsKtyAeOphQaviESmqF,cookies=DrXPIkgnWBdLsKtyAeOphQaviESmqF,redirects=DrXPIkgnWBdLsKtyAeOphQaviESmqM)
   if DrXPIkgnWBdLsKtyAeOphQaviESmxG.status_code!=200:return[]
   DrXPIkgnWBdLsKtyAeOphQaviESmxY=json.loads(DrXPIkgnWBdLsKtyAeOphQaviESmxG.text)
   DrXPIkgnWBdLsKtyAeOphQaviESmFG =DrXPIkgnWBdLsKtyAeOphQaviESmxY.get('chList')[0].get('chId')
   DrXPIkgnWBdLsKtyAeOphQaviESmFY=DrXPIkgnWBdLsKtyAeOphQaviESmxY.get('chConf').get(DrXPIkgnWBdLsKtyAeOphQaviESmFG)[0].get('id')
   DrXPIkgnWBdLsKtyAeOphQaviESmFU =DrXPIkgnWBdLsKtyAeOphQaviESmxY.get('program')
   DrXPIkgnWBdLsKtyAeOphQaviESmFj =DrXPIkgnWBdLsKtyAeOphQaviESmFU.get('title')
   DrXPIkgnWBdLsKtyAeOphQaviESmFJ =DrXPIkgnWBdLsKtyAeOphQaviESmFU.get('startTime')
   DrXPIkgnWBdLsKtyAeOphQaviESmFC =DrXPIkgnWBdLsKtyAeOphQaviESmFU.get('endTime')
   if DrXPIkgnWBdLsKtyAeOphQaviESmFJ!=DrXPIkgnWBdLsKtyAeOphQaviESmqF:
    DrXPIkgnWBdLsKtyAeOphQaviESmFJ =datetime.datetime.fromtimestamp(DrXPIkgnWBdLsKtyAeOphQaviESmqT(DrXPIkgnWBdLsKtyAeOphQaviESmFJ),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:DrXPIkgnWBdLsKtyAeOphQaviESmFJ=''
   if DrXPIkgnWBdLsKtyAeOphQaviESmFC!=DrXPIkgnWBdLsKtyAeOphQaviESmqF:
    DrXPIkgnWBdLsKtyAeOphQaviESmFC =datetime.datetime.fromtimestamp(DrXPIkgnWBdLsKtyAeOphQaviESmqT(DrXPIkgnWBdLsKtyAeOphQaviESmFC),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:DrXPIkgnWBdLsKtyAeOphQaviESmFC=''
   DrXPIkgnWBdLsKtyAeOphQaviESmFb={'chId':DrXPIkgnWBdLsKtyAeOphQaviESmFG,'title':DrXPIkgnWBdLsKtyAeOphQaviESmFj,'starttime':DrXPIkgnWBdLsKtyAeOphQaviESmFJ,'endTime':DrXPIkgnWBdLsKtyAeOphQaviESmFC,'maxBitrate':DrXPIkgnWBdLsKtyAeOphQaviESmFY,}
  except DrXPIkgnWBdLsKtyAeOphQaviESmqV as exception:
   DrXPIkgnWBdLsKtyAeOphQaviESmqz(exception)
   return{}
  return DrXPIkgnWBdLsKtyAeOphQaviESmFb
 def GetStreamingURL(DrXPIkgnWBdLsKtyAeOphQaviESmxq,channelId,setBitrate,DrXPIkgnWBdLsKtyAeOphQaviESmFY):
  DrXPIkgnWBdLsKtyAeOphQaviESmFl=''
  if DrXPIkgnWBdLsKtyAeOphQaviESmqT(setBitrate)>DrXPIkgnWBdLsKtyAeOphQaviESmqT(DrXPIkgnWBdLsKtyAeOphQaviESmFY):
   DrXPIkgnWBdLsKtyAeOphQaviESmFo=DrXPIkgnWBdLsKtyAeOphQaviESmFY
  else:
   DrXPIkgnWBdLsKtyAeOphQaviESmFo=setBitrate
  try:
   DrXPIkgnWBdLsKtyAeOphQaviESmxN='https://apis.naver.com/pcLive/livePlatform/sUrl'
   DrXPIkgnWBdLsKtyAeOphQaviESmFN={'ch':channelId,'q':DrXPIkgnWBdLsKtyAeOphQaviESmFo,'p':'hls','cc':'KR','env':'pc',}
   DrXPIkgnWBdLsKtyAeOphQaviESmxG=DrXPIkgnWBdLsKtyAeOphQaviESmxq.callRequestCookies('Get',DrXPIkgnWBdLsKtyAeOphQaviESmxN,payload=DrXPIkgnWBdLsKtyAeOphQaviESmqF,params=DrXPIkgnWBdLsKtyAeOphQaviESmFN,headers=DrXPIkgnWBdLsKtyAeOphQaviESmqF,cookies=DrXPIkgnWBdLsKtyAeOphQaviESmqF,redirects=DrXPIkgnWBdLsKtyAeOphQaviESmqM)
   if DrXPIkgnWBdLsKtyAeOphQaviESmxG.status_code!=200:return ''
   DrXPIkgnWBdLsKtyAeOphQaviESmxY=json.loads(DrXPIkgnWBdLsKtyAeOphQaviESmxG.text)
   DrXPIkgnWBdLsKtyAeOphQaviESmFl=DrXPIkgnWBdLsKtyAeOphQaviESmxY.get('secUrl')
  except DrXPIkgnWBdLsKtyAeOphQaviESmqV as exception:
   DrXPIkgnWBdLsKtyAeOphQaviESmqz(exception)
   return ''
  return DrXPIkgnWBdLsKtyAeOphQaviESmFl
 def GetStreamingURL2(DrXPIkgnWBdLsKtyAeOphQaviESmxq,DrXPIkgnWBdLsKtyAeOphQaviESmFx,setBitrate):
  DrXPIkgnWBdLsKtyAeOphQaviESmFl=''
  try:
   DrXPIkgnWBdLsKtyAeOphQaviESmxN='https://api-gw.sports.naver.com/schedule/%s/lives'%(DrXPIkgnWBdLsKtyAeOphQaviESmFx)
   DrXPIkgnWBdLsKtyAeOphQaviESmxG=DrXPIkgnWBdLsKtyAeOphQaviESmxq.callRequestCookies('Get',DrXPIkgnWBdLsKtyAeOphQaviESmxN,payload=DrXPIkgnWBdLsKtyAeOphQaviESmqF,params=DrXPIkgnWBdLsKtyAeOphQaviESmqF,headers=DrXPIkgnWBdLsKtyAeOphQaviESmqF,cookies=DrXPIkgnWBdLsKtyAeOphQaviESmqF,redirects=DrXPIkgnWBdLsKtyAeOphQaviESmqM)
   if DrXPIkgnWBdLsKtyAeOphQaviESmxG.status_code!=200:return ''
   DrXPIkgnWBdLsKtyAeOphQaviESmxY=json.loads(DrXPIkgnWBdLsKtyAeOphQaviESmxG.text)
   DrXPIkgnWBdLsKtyAeOphQaviESmFu=DrXPIkgnWBdLsKtyAeOphQaviESmxY.get('result').get('lives')[0]
   DrXPIkgnWBdLsKtyAeOphQaviESmqz(DrXPIkgnWBdLsKtyAeOphQaviESmFu)
   if setBitrate=='5000':
    DrXPIkgnWBdLsKtyAeOphQaviESmFl=DrXPIkgnWBdLsKtyAeOphQaviESmFu.get('rtmpPlayUrl1080')
   else:
    DrXPIkgnWBdLsKtyAeOphQaviESmFl=DrXPIkgnWBdLsKtyAeOphQaviESmFu.get('rtmpPlayUrl720')
  except DrXPIkgnWBdLsKtyAeOphQaviESmqV as exception:
   DrXPIkgnWBdLsKtyAeOphQaviESmqz(exception)
   return ''
  return DrXPIkgnWBdLsKtyAeOphQaviESmFl
 def Get_Category_List2(DrXPIkgnWBdLsKtyAeOphQaviESmxq):
  DrXPIkgnWBdLsKtyAeOphQaviESmxT=[]
  DrXPIkgnWBdLsKtyAeOphQaviESmxb=DrXPIkgnWBdLsKtyAeOphQaviESmxq.make_viewdate()
  DrXPIkgnWBdLsKtyAeOphQaviESmxb=['20210519']
  try:
   DrXPIkgnWBdLsKtyAeOphQaviESmxN='https://sports.news.naver.com/scoreboard/index.nhn'
   for DrXPIkgnWBdLsKtyAeOphQaviESmFc in DrXPIkgnWBdLsKtyAeOphQaviESmxb:
    DrXPIkgnWBdLsKtyAeOphQaviESmFN={'date':DrXPIkgnWBdLsKtyAeOphQaviESmFc}
    DrXPIkgnWBdLsKtyAeOphQaviESmxG=DrXPIkgnWBdLsKtyAeOphQaviESmxq.callRequestCookies('Get',DrXPIkgnWBdLsKtyAeOphQaviESmxN,payload=DrXPIkgnWBdLsKtyAeOphQaviESmqF,params=DrXPIkgnWBdLsKtyAeOphQaviESmFN,headers=DrXPIkgnWBdLsKtyAeOphQaviESmqF,cookies=DrXPIkgnWBdLsKtyAeOphQaviESmqF)
    if DrXPIkgnWBdLsKtyAeOphQaviESmxG.status_code!=200:return[]
    DrXPIkgnWBdLsKtyAeOphQaviESmFw=BeautifulSoup(DrXPIkgnWBdLsKtyAeOphQaviESmxG.text,'html.parser')
    DrXPIkgnWBdLsKtyAeOphQaviESmFw=DrXPIkgnWBdLsKtyAeOphQaviESmFw.select_one('#content > div > table > tbody')
    i=0
    for DrXPIkgnWBdLsKtyAeOphQaviESmFH in DrXPIkgnWBdLsKtyAeOphQaviESmFw.tr.next_siblings:
     if DrXPIkgnWBdLsKtyAeOphQaviESmqb(DrXPIkgnWBdLsKtyAeOphQaviESmqN(DrXPIkgnWBdLsKtyAeOphQaviESmFH))!="<class 'bs4.element.Tag'>":continue
     i+=1
     DrXPIkgnWBdLsKtyAeOphQaviESmqz(DrXPIkgnWBdLsKtyAeOphQaviESmqN(DrXPIkgnWBdLsKtyAeOphQaviESmFH))
     DrXPIkgnWBdLsKtyAeOphQaviESmqz(DrXPIkgnWBdLsKtyAeOphQaviESmFH.get('class'))
     if i>3:break
    '''
    START_TAG = soup.find_all('tr', {'class': 'first start'})
    for start_tag in START_TAG:
     TD_TAG = start_tag.find_all('td')
     for td_tag in TD_TAG:
      classnm = td_tag.get('class')[0]
      if classnm == 'game':
       print(td_tag.text )
      elif classnm == 'time':
       print(i_date[:4] + '-' + i_date[4:6] + '-' + i_date[-2:] + ' ' + td_tag.text )
      elif classnm == 'gameinfo':
       pass
      elif classnm == 'state':
       print(' '.join(td_tag.text.split()) )
      elif classnm == 'relay':
       IMG_TAG = td_tag.find_all('img')
       vodTag = []
       for img_tag in IMG_TAG:
        vodTag.append(img_tag.get('alt') )
       print(vodTag )
      elif classnm == 'place':
       print(td_tag.text )
      else:
       print(classnm )
    START_TAG = soup.find_all('tr', {'class': 'start'})
    '''    
  except DrXPIkgnWBdLsKtyAeOphQaviESmqV as exception:
   DrXPIkgnWBdLsKtyAeOphQaviESmqz(exception)
   return[]
  return DrXPIkgnWBdLsKtyAeOphQaviESmxT
# Created by pyminifier (https://github.com/liftoff/pyminifier)
