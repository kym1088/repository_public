__author__="NightRain"
MahdwLmXQRJOKeqSAVbHyjlotNTfcn=object
MahdwLmXQRJOKeqSAVbHyjlotNTfcU=None
MahdwLmXQRJOKeqSAVbHyjlotNTfcg=True
MahdwLmXQRJOKeqSAVbHyjlotNTfcB=False
MahdwLmXQRJOKeqSAVbHyjlotNTfcv=type
MahdwLmXQRJOKeqSAVbHyjlotNTfcD=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
MahdwLmXQRJOKeqSAVbHyjlotNTfic=[{'title':'경기(게임)별 보기','mode':'CATEGORY_LIST'},{'title':'채널별 보기','mode':'CHANNEL_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'** 경기중이 아닐때에는 시청이 제한될수 있음 **','mode':'XXX'},]
MahdwLmXQRJOKeqSAVbHyjlotNTfin=[{'chId':'ad1','title':'Spotv1'},{'chId':'ad2','title':'KBS N Sports'},{'chId':'ad3','title':'SBS Sports'},{'chId':'ad4','title':'MBC Sports'},{'chId':'ad5','title':'Spotv2'},]
from nsportsCore import*
class MahdwLmXQRJOKeqSAVbHyjlotNTfik(MahdwLmXQRJOKeqSAVbHyjlotNTfcn):
 def __init__(MahdwLmXQRJOKeqSAVbHyjlotNTfiU,MahdwLmXQRJOKeqSAVbHyjlotNTfig,MahdwLmXQRJOKeqSAVbHyjlotNTfiB,MahdwLmXQRJOKeqSAVbHyjlotNTfiv):
  MahdwLmXQRJOKeqSAVbHyjlotNTfiU._addon_url =MahdwLmXQRJOKeqSAVbHyjlotNTfig
  MahdwLmXQRJOKeqSAVbHyjlotNTfiU._addon_handle=MahdwLmXQRJOKeqSAVbHyjlotNTfiB
  MahdwLmXQRJOKeqSAVbHyjlotNTfiU.main_params =MahdwLmXQRJOKeqSAVbHyjlotNTfiv
  MahdwLmXQRJOKeqSAVbHyjlotNTfiU.NsportsObj =DrXPIkgnWBdLsKtyAeOphQaviESmxF() 
 def addon_noti(MahdwLmXQRJOKeqSAVbHyjlotNTfiU,sting):
  try:
   MahdwLmXQRJOKeqSAVbHyjlotNTfiP=xbmcgui.Dialog()
   MahdwLmXQRJOKeqSAVbHyjlotNTfiP.notification(__addonname__,sting)
  except:
   MahdwLmXQRJOKeqSAVbHyjlotNTfcU
 def addon_log(MahdwLmXQRJOKeqSAVbHyjlotNTfiU,string):
  try:
   MahdwLmXQRJOKeqSAVbHyjlotNTfis=string.encode('utf-8','ignore')
  except:
   MahdwLmXQRJOKeqSAVbHyjlotNTfis='addonException: addon_log'
  MahdwLmXQRJOKeqSAVbHyjlotNTfip=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,MahdwLmXQRJOKeqSAVbHyjlotNTfis),level=MahdwLmXQRJOKeqSAVbHyjlotNTfip)
 def get_Bitrate_sel(MahdwLmXQRJOKeqSAVbHyjlotNTfiU):
  MahdwLmXQRJOKeqSAVbHyjlotNTfix={'0':'5000','1':'2000','2':'800',}
  return MahdwLmXQRJOKeqSAVbHyjlotNTfix.get(__addon__.getSetting('selected_quality'))
 def add_dir(MahdwLmXQRJOKeqSAVbHyjlotNTfiU,label,sublabel='',img='',infoLabels=MahdwLmXQRJOKeqSAVbHyjlotNTfcU,isFolder=MahdwLmXQRJOKeqSAVbHyjlotNTfcg,params='',isLink=MahdwLmXQRJOKeqSAVbHyjlotNTfcB,ContextMenu=MahdwLmXQRJOKeqSAVbHyjlotNTfcU):
  MahdwLmXQRJOKeqSAVbHyjlotNTfiF='%s?%s'%(MahdwLmXQRJOKeqSAVbHyjlotNTfiU._addon_url,urllib.parse.urlencode(params))
  if sublabel:MahdwLmXQRJOKeqSAVbHyjlotNTfir='%s < %s >'%(label,sublabel)
  else: MahdwLmXQRJOKeqSAVbHyjlotNTfir=label
  if not img:img='DefaultFolder.png'
  MahdwLmXQRJOKeqSAVbHyjlotNTfiE=xbmcgui.ListItem(MahdwLmXQRJOKeqSAVbHyjlotNTfir)
  if MahdwLmXQRJOKeqSAVbHyjlotNTfcv(img)==MahdwLmXQRJOKeqSAVbHyjlotNTfcD:
   MahdwLmXQRJOKeqSAVbHyjlotNTfiE.setArt(img)
  else:
   MahdwLmXQRJOKeqSAVbHyjlotNTfiE.setArt({'thumb':img,'poster':img})
  if infoLabels:MahdwLmXQRJOKeqSAVbHyjlotNTfiE.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   MahdwLmXQRJOKeqSAVbHyjlotNTfiE.setProperty('IsPlayable','true')
  if ContextMenu:MahdwLmXQRJOKeqSAVbHyjlotNTfiE.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(MahdwLmXQRJOKeqSAVbHyjlotNTfiU._addon_handle,MahdwLmXQRJOKeqSAVbHyjlotNTfiF,MahdwLmXQRJOKeqSAVbHyjlotNTfiE,isFolder)
 def dp_Main_List(MahdwLmXQRJOKeqSAVbHyjlotNTfiU,args):
  for MahdwLmXQRJOKeqSAVbHyjlotNTfiW in MahdwLmXQRJOKeqSAVbHyjlotNTfic:
   MahdwLmXQRJOKeqSAVbHyjlotNTfir=MahdwLmXQRJOKeqSAVbHyjlotNTfiW.get('title')
   MahdwLmXQRJOKeqSAVbHyjlotNTfiC=''
   MahdwLmXQRJOKeqSAVbHyjlotNTfiI={'mode':MahdwLmXQRJOKeqSAVbHyjlotNTfiW.get('mode'),}
   if MahdwLmXQRJOKeqSAVbHyjlotNTfiW.get('mode')in['XXX']:
    MahdwLmXQRJOKeqSAVbHyjlotNTfiu=MahdwLmXQRJOKeqSAVbHyjlotNTfcB
    MahdwLmXQRJOKeqSAVbHyjlotNTfiG =MahdwLmXQRJOKeqSAVbHyjlotNTfcg
   else:
    MahdwLmXQRJOKeqSAVbHyjlotNTfiu=MahdwLmXQRJOKeqSAVbHyjlotNTfcg
    MahdwLmXQRJOKeqSAVbHyjlotNTfiG =MahdwLmXQRJOKeqSAVbHyjlotNTfcB
   if 'icon' in MahdwLmXQRJOKeqSAVbHyjlotNTfiW:MahdwLmXQRJOKeqSAVbHyjlotNTfiC=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',MahdwLmXQRJOKeqSAVbHyjlotNTfiW.get('icon')) 
   MahdwLmXQRJOKeqSAVbHyjlotNTfiU.add_dir(MahdwLmXQRJOKeqSAVbHyjlotNTfir,sublabel='',img=MahdwLmXQRJOKeqSAVbHyjlotNTfiC,infoLabels=MahdwLmXQRJOKeqSAVbHyjlotNTfcU,isFolder=MahdwLmXQRJOKeqSAVbHyjlotNTfiu,params=MahdwLmXQRJOKeqSAVbHyjlotNTfiI,isLink=MahdwLmXQRJOKeqSAVbHyjlotNTfiG)
  xbmcplugin.endOfDirectory(MahdwLmXQRJOKeqSAVbHyjlotNTfiU._addon_handle)
 def dp_Channel_List(MahdwLmXQRJOKeqSAVbHyjlotNTfiU,args):
  MahdwLmXQRJOKeqSAVbHyjlotNTfiY=MahdwLmXQRJOKeqSAVbHyjlotNTfiU.get_Bitrate_sel()
  for MahdwLmXQRJOKeqSAVbHyjlotNTfki in MahdwLmXQRJOKeqSAVbHyjlotNTfin:
   MahdwLmXQRJOKeqSAVbHyjlotNTfir=MahdwLmXQRJOKeqSAVbHyjlotNTfki.get('title')
   MahdwLmXQRJOKeqSAVbHyjlotNTfkc=MahdwLmXQRJOKeqSAVbHyjlotNTfki.get('chId')
   MahdwLmXQRJOKeqSAVbHyjlotNTfkn={'mediatype':'episode','title':MahdwLmXQRJOKeqSAVbHyjlotNTfir}
   MahdwLmXQRJOKeqSAVbHyjlotNTfiI={'mode':'CLIVE','chId':MahdwLmXQRJOKeqSAVbHyjlotNTfkc,'maxBitrate':MahdwLmXQRJOKeqSAVbHyjlotNTfiY,}
   MahdwLmXQRJOKeqSAVbHyjlotNTfiU.add_dir(MahdwLmXQRJOKeqSAVbHyjlotNTfir,sublabel='',img='',infoLabels=MahdwLmXQRJOKeqSAVbHyjlotNTfkn,isFolder=MahdwLmXQRJOKeqSAVbHyjlotNTfcB,params=MahdwLmXQRJOKeqSAVbHyjlotNTfiI,isLink=MahdwLmXQRJOKeqSAVbHyjlotNTfcB)
  xbmcplugin.endOfDirectory(MahdwLmXQRJOKeqSAVbHyjlotNTfiU._addon_handle)
 def dp_Category_List(MahdwLmXQRJOKeqSAVbHyjlotNTfiU,args):
  MahdwLmXQRJOKeqSAVbHyjlotNTfkU=MahdwLmXQRJOKeqSAVbHyjlotNTfiU.NsportsObj.Get_Category_List()
  for MahdwLmXQRJOKeqSAVbHyjlotNTfkg in MahdwLmXQRJOKeqSAVbHyjlotNTfkU:
   MahdwLmXQRJOKeqSAVbHyjlotNTfkB =MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('groupnm')
   MahdwLmXQRJOKeqSAVbHyjlotNTfkv =MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('onairyn')
   MahdwLmXQRJOKeqSAVbHyjlotNTfkD=','.join(MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('category'))
   if MahdwLmXQRJOKeqSAVbHyjlotNTfkv=='Y':MahdwLmXQRJOKeqSAVbHyjlotNTfiz='중계중'
   else:MahdwLmXQRJOKeqSAVbHyjlotNTfiz=''
   MahdwLmXQRJOKeqSAVbHyjlotNTfiI={'mode':'GAME_LIST','category':MahdwLmXQRJOKeqSAVbHyjlotNTfkD,}
   MahdwLmXQRJOKeqSAVbHyjlotNTfiU.add_dir(MahdwLmXQRJOKeqSAVbHyjlotNTfkB,sublabel=MahdwLmXQRJOKeqSAVbHyjlotNTfiz,img='',infoLabels=MahdwLmXQRJOKeqSAVbHyjlotNTfcU,isFolder=MahdwLmXQRJOKeqSAVbHyjlotNTfcg,params=MahdwLmXQRJOKeqSAVbHyjlotNTfiI)
  xbmcplugin.endOfDirectory(MahdwLmXQRJOKeqSAVbHyjlotNTfiU._addon_handle,cacheToDisc=MahdwLmXQRJOKeqSAVbHyjlotNTfcB)
 def dp_Game_List(MahdwLmXQRJOKeqSAVbHyjlotNTfiU,args):
  MahdwLmXQRJOKeqSAVbHyjlotNTfks=args.get('category')
  MahdwLmXQRJOKeqSAVbHyjlotNTfkU=MahdwLmXQRJOKeqSAVbHyjlotNTfiU.NsportsObj.Get_Game_List(MahdwLmXQRJOKeqSAVbHyjlotNTfks)
  for MahdwLmXQRJOKeqSAVbHyjlotNTfkg in MahdwLmXQRJOKeqSAVbHyjlotNTfkU:
   MahdwLmXQRJOKeqSAVbHyjlotNTfkp =MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('gameId')
   MahdwLmXQRJOKeqSAVbHyjlotNTfkx =MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('upperCategoryId')
   MahdwLmXQRJOKeqSAVbHyjlotNTfkF =MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('categoryId')
   MahdwLmXQRJOKeqSAVbHyjlotNTfkr =MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('statusCode')
   MahdwLmXQRJOKeqSAVbHyjlotNTfkE =MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('statusInfo')
   MahdwLmXQRJOKeqSAVbHyjlotNTfkW =MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('isOnAirTv')
   MahdwLmXQRJOKeqSAVbHyjlotNTfkc =MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('chId')
   MahdwLmXQRJOKeqSAVbHyjlotNTfir =MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('title')
   MahdwLmXQRJOKeqSAVbHyjlotNTfkC =MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('starttime')
   MahdwLmXQRJOKeqSAVbHyjlotNTfkI =MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('endTime')
   MahdwLmXQRJOKeqSAVbHyjlotNTfku =MahdwLmXQRJOKeqSAVbHyjlotNTfkg.get('maxBitrate')
   if MahdwLmXQRJOKeqSAVbHyjlotNTfir=='':MahdwLmXQRJOKeqSAVbHyjlotNTfir=MahdwLmXQRJOKeqSAVbHyjlotNTfkp
   if MahdwLmXQRJOKeqSAVbHyjlotNTfkW=='Y':
    MahdwLmXQRJOKeqSAVbHyjlotNTfkG='방송중'
   else:
    if MahdwLmXQRJOKeqSAVbHyjlotNTfkE=='경기취소':
     MahdwLmXQRJOKeqSAVbHyjlotNTfkG=MahdwLmXQRJOKeqSAVbHyjlotNTfkE
    else:
     MahdwLmXQRJOKeqSAVbHyjlotNTfkG=''
   if MahdwLmXQRJOKeqSAVbHyjlotNTfkC=='':
    MahdwLmXQRJOKeqSAVbHyjlotNTfiz=MahdwLmXQRJOKeqSAVbHyjlotNTfkG
   else:
    if MahdwLmXQRJOKeqSAVbHyjlotNTfkG=='':
     MahdwLmXQRJOKeqSAVbHyjlotNTfiz=MahdwLmXQRJOKeqSAVbHyjlotNTfkC
    else:
     MahdwLmXQRJOKeqSAVbHyjlotNTfiz=MahdwLmXQRJOKeqSAVbHyjlotNTfkC+' - '+MahdwLmXQRJOKeqSAVbHyjlotNTfkG
   MahdwLmXQRJOKeqSAVbHyjlotNTfkn={'mediatype':'episode','title':MahdwLmXQRJOKeqSAVbHyjlotNTfir,'plot':'%s\n\n시작 : %s\n종료 : %s'%(MahdwLmXQRJOKeqSAVbHyjlotNTfir,MahdwLmXQRJOKeqSAVbHyjlotNTfkC,MahdwLmXQRJOKeqSAVbHyjlotNTfkI)}
   MahdwLmXQRJOKeqSAVbHyjlotNTfiI={'mode':'LIVE','chId':MahdwLmXQRJOKeqSAVbHyjlotNTfkc,'maxBitrate':MahdwLmXQRJOKeqSAVbHyjlotNTfku,'gameId':MahdwLmXQRJOKeqSAVbHyjlotNTfkp,}
   MahdwLmXQRJOKeqSAVbHyjlotNTfiU.add_dir(MahdwLmXQRJOKeqSAVbHyjlotNTfir,sublabel=MahdwLmXQRJOKeqSAVbHyjlotNTfiz,img='',infoLabels=MahdwLmXQRJOKeqSAVbHyjlotNTfkn,isFolder=MahdwLmXQRJOKeqSAVbHyjlotNTfcB,params=MahdwLmXQRJOKeqSAVbHyjlotNTfiI)
  xbmcplugin.endOfDirectory(MahdwLmXQRJOKeqSAVbHyjlotNTfiU._addon_handle,cacheToDisc=MahdwLmXQRJOKeqSAVbHyjlotNTfcB)
 def play_VIDEO(MahdwLmXQRJOKeqSAVbHyjlotNTfiU,args):
  MahdwLmXQRJOKeqSAVbHyjlotNTfkp =args.get('gameId')
  MahdwLmXQRJOKeqSAVbHyjlotNTfkz =MahdwLmXQRJOKeqSAVbHyjlotNTfiU.get_Bitrate_sel()
  MahdwLmXQRJOKeqSAVbHyjlotNTfkY=MahdwLmXQRJOKeqSAVbHyjlotNTfiU.NsportsObj.GetStreamingURL2(MahdwLmXQRJOKeqSAVbHyjlotNTfkp,MahdwLmXQRJOKeqSAVbHyjlotNTfkz)
  if MahdwLmXQRJOKeqSAVbHyjlotNTfkY=='':
   MahdwLmXQRJOKeqSAVbHyjlotNTfiU.addon_noti(__language__(30901).encode('utf8'))
   return
  MahdwLmXQRJOKeqSAVbHyjlotNTfiU.addon_log(MahdwLmXQRJOKeqSAVbHyjlotNTfkY)
  MahdwLmXQRJOKeqSAVbHyjlotNTfci=xbmcgui.ListItem(path=MahdwLmXQRJOKeqSAVbHyjlotNTfkY)
  xbmcplugin.setResolvedUrl(MahdwLmXQRJOKeqSAVbHyjlotNTfiU._addon_handle,MahdwLmXQRJOKeqSAVbHyjlotNTfcg,MahdwLmXQRJOKeqSAVbHyjlotNTfci)
 def play_CHANNEL(MahdwLmXQRJOKeqSAVbHyjlotNTfiU,args):
  MahdwLmXQRJOKeqSAVbHyjlotNTfkc =args.get('chId')
  MahdwLmXQRJOKeqSAVbHyjlotNTfku =args.get('maxBitrate')
  MahdwLmXQRJOKeqSAVbHyjlotNTfkz =MahdwLmXQRJOKeqSAVbHyjlotNTfiU.get_Bitrate_sel()
  MahdwLmXQRJOKeqSAVbHyjlotNTfkY=MahdwLmXQRJOKeqSAVbHyjlotNTfiU.NsportsObj.GetStreamingURL(MahdwLmXQRJOKeqSAVbHyjlotNTfkc,MahdwLmXQRJOKeqSAVbHyjlotNTfkz,MahdwLmXQRJOKeqSAVbHyjlotNTfku)
  if MahdwLmXQRJOKeqSAVbHyjlotNTfkY=='':
   MahdwLmXQRJOKeqSAVbHyjlotNTfiU.addon_noti(__language__(30901).encode('utf8'))
   return
  MahdwLmXQRJOKeqSAVbHyjlotNTfiU.addon_log(MahdwLmXQRJOKeqSAVbHyjlotNTfkY)
  MahdwLmXQRJOKeqSAVbHyjlotNTfci=xbmcgui.ListItem(path=MahdwLmXQRJOKeqSAVbHyjlotNTfkY)
  xbmcplugin.setResolvedUrl(MahdwLmXQRJOKeqSAVbHyjlotNTfiU._addon_handle,MahdwLmXQRJOKeqSAVbHyjlotNTfcg,MahdwLmXQRJOKeqSAVbHyjlotNTfci)
 def nsports_main(MahdwLmXQRJOKeqSAVbHyjlotNTfiU):
  MahdwLmXQRJOKeqSAVbHyjlotNTfck=MahdwLmXQRJOKeqSAVbHyjlotNTfiU.main_params.get('mode',MahdwLmXQRJOKeqSAVbHyjlotNTfcU)
  if MahdwLmXQRJOKeqSAVbHyjlotNTfck is MahdwLmXQRJOKeqSAVbHyjlotNTfcU:
   MahdwLmXQRJOKeqSAVbHyjlotNTfiU.dp_Main_List(MahdwLmXQRJOKeqSAVbHyjlotNTfiU.main_params)
  elif MahdwLmXQRJOKeqSAVbHyjlotNTfck=='CATEGORY_LIST':
   MahdwLmXQRJOKeqSAVbHyjlotNTfiU.dp_Category_List(MahdwLmXQRJOKeqSAVbHyjlotNTfiU.main_params)
  elif MahdwLmXQRJOKeqSAVbHyjlotNTfck=='GAME_LIST':
   MahdwLmXQRJOKeqSAVbHyjlotNTfiU.dp_Game_List(MahdwLmXQRJOKeqSAVbHyjlotNTfiU.main_params)
  elif MahdwLmXQRJOKeqSAVbHyjlotNTfck=='LIVE':
   MahdwLmXQRJOKeqSAVbHyjlotNTfiU.play_VIDEO(MahdwLmXQRJOKeqSAVbHyjlotNTfiU.main_params)
  elif MahdwLmXQRJOKeqSAVbHyjlotNTfck=='CLIVE':
   MahdwLmXQRJOKeqSAVbHyjlotNTfiU.play_CHANNEL(MahdwLmXQRJOKeqSAVbHyjlotNTfiU.main_params)
  elif MahdwLmXQRJOKeqSAVbHyjlotNTfck=='CHANNEL_LIST':
   MahdwLmXQRJOKeqSAVbHyjlotNTfiU.dp_Channel_List(MahdwLmXQRJOKeqSAVbHyjlotNTfiU.main_params)
  else:
   MahdwLmXQRJOKeqSAVbHyjlotNTfcU
# Created by pyminifier (https://github.com/liftoff/pyminifier)
