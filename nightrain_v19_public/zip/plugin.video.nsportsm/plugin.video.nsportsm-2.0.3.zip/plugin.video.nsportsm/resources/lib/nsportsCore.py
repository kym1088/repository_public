__author__="NightRain"
RiCwSyhPYVIDHmrAkBJMqEtWFlexKN=object
RiCwSyhPYVIDHmrAkBJMqEtWFlexKu=None
RiCwSyhPYVIDHmrAkBJMqEtWFlexKj=False
RiCwSyhPYVIDHmrAkBJMqEtWFlexKs=True
RiCwSyhPYVIDHmrAkBJMqEtWFlexKX=len
RiCwSyhPYVIDHmrAkBJMqEtWFlexKp=print
RiCwSyhPYVIDHmrAkBJMqEtWFlexKG=Exception
RiCwSyhPYVIDHmrAkBJMqEtWFlexKQ=int
RiCwSyhPYVIDHmrAkBJMqEtWFlexKb=str
RiCwSyhPYVIDHmrAkBJMqEtWFlexKL=type
RiCwSyhPYVIDHmrAkBJMqEtWFlexKT=dict
import urllib
import re
import json
import requests
import datetime
from bs4 import BeautifulSoup
class RiCwSyhPYVIDHmrAkBJMqEtWFlexoz(RiCwSyhPYVIDHmrAkBJMqEtWFlexKN):
 def __init__(RiCwSyhPYVIDHmrAkBJMqEtWFlexof):
  RiCwSyhPYVIDHmrAkBJMqEtWFlexof.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36'
  RiCwSyhPYVIDHmrAkBJMqEtWFlexof.DEFAULT_HEADER ={'user-agent':RiCwSyhPYVIDHmrAkBJMqEtWFlexof.USER_AGENT}
  RiCwSyhPYVIDHmrAkBJMqEtWFlexof.genres=[{'groupnm':'야구','category':['kbaseball','wbaseball']},{'groupnm':'축구','category':['kfootball','wfootball']},{'groupnm':'배구','category':['kvolleyball']},{'groupnm':'골프','category':['golf']},{'groupnm':'기타','category':['others']},]
 def callRequestCookies(RiCwSyhPYVIDHmrAkBJMqEtWFlexof,jobtype,RiCwSyhPYVIDHmrAkBJMqEtWFlexoj,payload=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,params=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,headers=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,cookies=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,redirects=RiCwSyhPYVIDHmrAkBJMqEtWFlexKj):
  RiCwSyhPYVIDHmrAkBJMqEtWFlexoK=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.DEFAULT_HEADER
  if headers:RiCwSyhPYVIDHmrAkBJMqEtWFlexoK.update(headers)
  if jobtype=='Get':
   RiCwSyhPYVIDHmrAkBJMqEtWFlexov=requests.get(RiCwSyhPYVIDHmrAkBJMqEtWFlexoj,params=params,headers=RiCwSyhPYVIDHmrAkBJMqEtWFlexoK,cookies=cookies,allow_redirects=redirects)
  else:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexov=requests.post(RiCwSyhPYVIDHmrAkBJMqEtWFlexoj,data=payload,params=params,headers=RiCwSyhPYVIDHmrAkBJMqEtWFlexoK,cookies=cookies,allow_redirects=redirects)
  return RiCwSyhPYVIDHmrAkBJMqEtWFlexov
 def Get_Now_Datetime(RiCwSyhPYVIDHmrAkBJMqEtWFlexof):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def make_viewdate(RiCwSyhPYVIDHmrAkBJMqEtWFlexof,dtype='1'):
  RiCwSyhPYVIDHmrAkBJMqEtWFlexoa =RiCwSyhPYVIDHmrAkBJMqEtWFlexof.Get_Now_Datetime()
  RiCwSyhPYVIDHmrAkBJMqEtWFlexoc =RiCwSyhPYVIDHmrAkBJMqEtWFlexoa+datetime.timedelta(days=-1)
  RiCwSyhPYVIDHmrAkBJMqEtWFlexoU =RiCwSyhPYVIDHmrAkBJMqEtWFlexoa+datetime.timedelta(days=1)
  if dtype=='1':
   RiCwSyhPYVIDHmrAkBJMqEtWFlexod=[RiCwSyhPYVIDHmrAkBJMqEtWFlexoa.strftime('%Y%m%d'),]
  elif dtype=='2':
   RiCwSyhPYVIDHmrAkBJMqEtWFlexod=[RiCwSyhPYVIDHmrAkBJMqEtWFlexoa.strftime('%Y%m%d'),RiCwSyhPYVIDHmrAkBJMqEtWFlexoU.strftime('%Y%m%d'),]
  elif dtype=='3':
   RiCwSyhPYVIDHmrAkBJMqEtWFlexod=[RiCwSyhPYVIDHmrAkBJMqEtWFlexoa.strftime('%Y%m%d'),RiCwSyhPYVIDHmrAkBJMqEtWFlexoc.strftime('%Y%m%d'),RiCwSyhPYVIDHmrAkBJMqEtWFlexoU.strftime('%Y%m%d'),]
  return RiCwSyhPYVIDHmrAkBJMqEtWFlexod
 def Get_Category_List(RiCwSyhPYVIDHmrAkBJMqEtWFlexof):
  RiCwSyhPYVIDHmrAkBJMqEtWFlexoN=[]
  RiCwSyhPYVIDHmrAkBJMqEtWFlexou=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.make_viewdate(dtype='1')
  try:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoj='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   RiCwSyhPYVIDHmrAkBJMqEtWFlexos=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.callRequestCookies('Get',RiCwSyhPYVIDHmrAkBJMqEtWFlexoj,payload=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,params=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,headers=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,cookies=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,redirects=RiCwSyhPYVIDHmrAkBJMqEtWFlexKs)
   if RiCwSyhPYVIDHmrAkBJMqEtWFlexos.status_code!=200:return[]
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoX=json.loads(RiCwSyhPYVIDHmrAkBJMqEtWFlexos.text)
   RiCwSyhPYVIDHmrAkBJMqEtWFlexop=RiCwSyhPYVIDHmrAkBJMqEtWFlexoX.get('gameList')
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoG=[]
   for RiCwSyhPYVIDHmrAkBJMqEtWFlexoQ in RiCwSyhPYVIDHmrAkBJMqEtWFlexof.genres:
    RiCwSyhPYVIDHmrAkBJMqEtWFlexob =RiCwSyhPYVIDHmrAkBJMqEtWFlexoQ.get('groupnm')
    RiCwSyhPYVIDHmrAkBJMqEtWFlexoL=[]
    RiCwSyhPYVIDHmrAkBJMqEtWFlexoT ='N'
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexKX(RiCwSyhPYVIDHmrAkBJMqEtWFlexoG)!=0:
     RiCwSyhPYVIDHmrAkBJMqEtWFlexop =RiCwSyhPYVIDHmrAkBJMqEtWFlexoG
     RiCwSyhPYVIDHmrAkBJMqEtWFlexoG=[]
    for RiCwSyhPYVIDHmrAkBJMqEtWFlexog in RiCwSyhPYVIDHmrAkBJMqEtWFlexop:
     RiCwSyhPYVIDHmrAkBJMqEtWFlexon=RiCwSyhPYVIDHmrAkBJMqEtWFlexog.get('upperCategoryId')
     RiCwSyhPYVIDHmrAkBJMqEtWFlexzo =RiCwSyhPYVIDHmrAkBJMqEtWFlexog.get('statusCode')
     RiCwSyhPYVIDHmrAkBJMqEtWFlexzf =RiCwSyhPYVIDHmrAkBJMqEtWFlexog.get('isOnAirTv')
     RiCwSyhPYVIDHmrAkBJMqEtWFlexzK =RiCwSyhPYVIDHmrAkBJMqEtWFlexog.get('gameId')
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexon in('esports'):continue
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexzo in('RESULT'):continue
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexzK[:8]not in RiCwSyhPYVIDHmrAkBJMqEtWFlexou and RiCwSyhPYVIDHmrAkBJMqEtWFlexzf!='Y':continue
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexon in RiCwSyhPYVIDHmrAkBJMqEtWFlexoQ.get('category'):
      if RiCwSyhPYVIDHmrAkBJMqEtWFlexon not in RiCwSyhPYVIDHmrAkBJMqEtWFlexoL:RiCwSyhPYVIDHmrAkBJMqEtWFlexoL.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexon)
      if RiCwSyhPYVIDHmrAkBJMqEtWFlexzf=='Y':RiCwSyhPYVIDHmrAkBJMqEtWFlexoT='Y'
     else:
      RiCwSyhPYVIDHmrAkBJMqEtWFlexoG.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexog)
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexKX(RiCwSyhPYVIDHmrAkBJMqEtWFlexoL)>0:
     RiCwSyhPYVIDHmrAkBJMqEtWFlexzv={'groupnm':RiCwSyhPYVIDHmrAkBJMqEtWFlexob,'onairyn':RiCwSyhPYVIDHmrAkBJMqEtWFlexoT,'category':RiCwSyhPYVIDHmrAkBJMqEtWFlexoL,}
     RiCwSyhPYVIDHmrAkBJMqEtWFlexoN.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexzv)
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexKX(RiCwSyhPYVIDHmrAkBJMqEtWFlexoG)==0:break
   RiCwSyhPYVIDHmrAkBJMqEtWFlexob ='-'
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoL=[]
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoT ='N'
   for RiCwSyhPYVIDHmrAkBJMqEtWFlexog in RiCwSyhPYVIDHmrAkBJMqEtWFlexoG:
    RiCwSyhPYVIDHmrAkBJMqEtWFlexon=RiCwSyhPYVIDHmrAkBJMqEtWFlexog.get('upperCategoryId')
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzf =RiCwSyhPYVIDHmrAkBJMqEtWFlexog.get('isOnAirTv')
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexon not in RiCwSyhPYVIDHmrAkBJMqEtWFlexoL:RiCwSyhPYVIDHmrAkBJMqEtWFlexoL.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexon)
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexzf=='Y':RiCwSyhPYVIDHmrAkBJMqEtWFlexoT='Y'
   if RiCwSyhPYVIDHmrAkBJMqEtWFlexKX(RiCwSyhPYVIDHmrAkBJMqEtWFlexoL)>0:
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzv={'groupnm':'-','onairyn':RiCwSyhPYVIDHmrAkBJMqEtWFlexoT,'category':RiCwSyhPYVIDHmrAkBJMqEtWFlexoL,}
    RiCwSyhPYVIDHmrAkBJMqEtWFlexoN.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexzv)
    RiCwSyhPYVIDHmrAkBJMqEtWFlexKp(RiCwSyhPYVIDHmrAkBJMqEtWFlexob,RiCwSyhPYVIDHmrAkBJMqEtWFlexoT,RiCwSyhPYVIDHmrAkBJMqEtWFlexoL)
  except RiCwSyhPYVIDHmrAkBJMqEtWFlexKG as exception:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexKp(exception)
   return[]
  return RiCwSyhPYVIDHmrAkBJMqEtWFlexoN
 def Get_Game_List(RiCwSyhPYVIDHmrAkBJMqEtWFlexof,category):
  RiCwSyhPYVIDHmrAkBJMqEtWFlexzO=category.split(',')
  RiCwSyhPYVIDHmrAkBJMqEtWFlexoN =[]
  RiCwSyhPYVIDHmrAkBJMqEtWFlexza =[]
  RiCwSyhPYVIDHmrAkBJMqEtWFlexzc =[]
  RiCwSyhPYVIDHmrAkBJMqEtWFlexou=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.make_viewdate()
  try:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoj='https://sports.news.naver.com/tv/ajax/gameList.nhn'
   RiCwSyhPYVIDHmrAkBJMqEtWFlexos=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.callRequestCookies('Get',RiCwSyhPYVIDHmrAkBJMqEtWFlexoj,payload=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,params=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,headers=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,cookies=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,redirects=RiCwSyhPYVIDHmrAkBJMqEtWFlexKs)
   if RiCwSyhPYVIDHmrAkBJMqEtWFlexos.status_code!=200:return[]
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoX=json.loads(RiCwSyhPYVIDHmrAkBJMqEtWFlexos.text)
   RiCwSyhPYVIDHmrAkBJMqEtWFlexop=RiCwSyhPYVIDHmrAkBJMqEtWFlexoX.get('gameList')
   for RiCwSyhPYVIDHmrAkBJMqEtWFlexog in RiCwSyhPYVIDHmrAkBJMqEtWFlexop:
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzK =RiCwSyhPYVIDHmrAkBJMqEtWFlexog.get('gameId')
    RiCwSyhPYVIDHmrAkBJMqEtWFlexon=RiCwSyhPYVIDHmrAkBJMqEtWFlexog.get('upperCategoryId')
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzU =RiCwSyhPYVIDHmrAkBJMqEtWFlexog.get('categoryId')
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzo =RiCwSyhPYVIDHmrAkBJMqEtWFlexog.get('statusCode')
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzd =RiCwSyhPYVIDHmrAkBJMqEtWFlexog.get('statusInfo')
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzf =RiCwSyhPYVIDHmrAkBJMqEtWFlexog.get('isOnAirTv')
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexon in('esports'):continue
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexzo in('RESULT'):continue
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexon not in RiCwSyhPYVIDHmrAkBJMqEtWFlexzO:continue
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexzK[:8]not in RiCwSyhPYVIDHmrAkBJMqEtWFlexou and RiCwSyhPYVIDHmrAkBJMqEtWFlexzf!='Y':continue
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzN=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.Get_Game_liveInfo(RiCwSyhPYVIDHmrAkBJMqEtWFlexzK)
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexzN.get('chId')==RiCwSyhPYVIDHmrAkBJMqEtWFlexKu:continue
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzv={'gameId':RiCwSyhPYVIDHmrAkBJMqEtWFlexzK,'upperCategoryId':RiCwSyhPYVIDHmrAkBJMqEtWFlexon,'categoryId':RiCwSyhPYVIDHmrAkBJMqEtWFlexzU,'statusCode':RiCwSyhPYVIDHmrAkBJMqEtWFlexzo,'statusInfo':RiCwSyhPYVIDHmrAkBJMqEtWFlexzd,'isOnAirTv':RiCwSyhPYVIDHmrAkBJMqEtWFlexzf,'chId':RiCwSyhPYVIDHmrAkBJMqEtWFlexzN.get('chId'),'title':RiCwSyhPYVIDHmrAkBJMqEtWFlexzN.get('title'),'starttime':RiCwSyhPYVIDHmrAkBJMqEtWFlexzN.get('starttime'),'endTime':RiCwSyhPYVIDHmrAkBJMqEtWFlexzN.get('endTime'),'maxBitrate':RiCwSyhPYVIDHmrAkBJMqEtWFlexzN.get('maxBitrate'),}
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexzf=='Y':
     RiCwSyhPYVIDHmrAkBJMqEtWFlexza.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexzv)
    else:
     RiCwSyhPYVIDHmrAkBJMqEtWFlexzc.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexzv)
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoN=RiCwSyhPYVIDHmrAkBJMqEtWFlexza+RiCwSyhPYVIDHmrAkBJMqEtWFlexzc
  except RiCwSyhPYVIDHmrAkBJMqEtWFlexKG as exception:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexKp(exception)
   return[]
  return RiCwSyhPYVIDHmrAkBJMqEtWFlexoN
 def Get_Game_liveInfo(RiCwSyhPYVIDHmrAkBJMqEtWFlexof,RiCwSyhPYVIDHmrAkBJMqEtWFlexzK):
  RiCwSyhPYVIDHmrAkBJMqEtWFlexzu={}
  try:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoj='https://apis.naver.com/pcLive/livePlatform/liveInfo2'
   RiCwSyhPYVIDHmrAkBJMqEtWFlexzj={'env':'pc','inclAudCh':'0','svcId':'12002','svcLiveId':RiCwSyhPYVIDHmrAkBJMqEtWFlexzK,}
   RiCwSyhPYVIDHmrAkBJMqEtWFlexos=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.callRequestCookies('Get',RiCwSyhPYVIDHmrAkBJMqEtWFlexoj,payload=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,params=RiCwSyhPYVIDHmrAkBJMqEtWFlexzj,headers=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,cookies=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,redirects=RiCwSyhPYVIDHmrAkBJMqEtWFlexKs)
   if RiCwSyhPYVIDHmrAkBJMqEtWFlexos.status_code!=200:return[]
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoX=json.loads(RiCwSyhPYVIDHmrAkBJMqEtWFlexos.text)
   RiCwSyhPYVIDHmrAkBJMqEtWFlexzs =RiCwSyhPYVIDHmrAkBJMqEtWFlexoX.get('chList')[0].get('chId')
   RiCwSyhPYVIDHmrAkBJMqEtWFlexzX=RiCwSyhPYVIDHmrAkBJMqEtWFlexoX.get('chConf').get(RiCwSyhPYVIDHmrAkBJMqEtWFlexzs)[0].get('id')
   RiCwSyhPYVIDHmrAkBJMqEtWFlexzp =RiCwSyhPYVIDHmrAkBJMqEtWFlexoX.get('program')
   RiCwSyhPYVIDHmrAkBJMqEtWFlexzG =RiCwSyhPYVIDHmrAkBJMqEtWFlexzp.get('title')
   RiCwSyhPYVIDHmrAkBJMqEtWFlexzQ =RiCwSyhPYVIDHmrAkBJMqEtWFlexzp.get('startTime')
   RiCwSyhPYVIDHmrAkBJMqEtWFlexzb =RiCwSyhPYVIDHmrAkBJMqEtWFlexzp.get('endTime')
   if RiCwSyhPYVIDHmrAkBJMqEtWFlexzQ!=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu:
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzQ =datetime.datetime.fromtimestamp(RiCwSyhPYVIDHmrAkBJMqEtWFlexKQ(RiCwSyhPYVIDHmrAkBJMqEtWFlexzQ),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:RiCwSyhPYVIDHmrAkBJMqEtWFlexzQ=''
   if RiCwSyhPYVIDHmrAkBJMqEtWFlexzb!=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu:
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzb =datetime.datetime.fromtimestamp(RiCwSyhPYVIDHmrAkBJMqEtWFlexKQ(RiCwSyhPYVIDHmrAkBJMqEtWFlexzb),datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul')).strftime('%Y-%m-%d %H:%M')
   else:RiCwSyhPYVIDHmrAkBJMqEtWFlexzb=''
   RiCwSyhPYVIDHmrAkBJMqEtWFlexzu={'chId':RiCwSyhPYVIDHmrAkBJMqEtWFlexzs,'title':RiCwSyhPYVIDHmrAkBJMqEtWFlexzG,'starttime':RiCwSyhPYVIDHmrAkBJMqEtWFlexzQ,'endTime':RiCwSyhPYVIDHmrAkBJMqEtWFlexzb,'maxBitrate':RiCwSyhPYVIDHmrAkBJMqEtWFlexzX,}
  except RiCwSyhPYVIDHmrAkBJMqEtWFlexKG as exception:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexKp(exception)
   return{}
  return RiCwSyhPYVIDHmrAkBJMqEtWFlexzu
 def GetStreamingURL(RiCwSyhPYVIDHmrAkBJMqEtWFlexof,channelId,setBitrate,RiCwSyhPYVIDHmrAkBJMqEtWFlexzX):
  RiCwSyhPYVIDHmrAkBJMqEtWFlexzL=''
  if RiCwSyhPYVIDHmrAkBJMqEtWFlexKQ(setBitrate)>RiCwSyhPYVIDHmrAkBJMqEtWFlexKQ(RiCwSyhPYVIDHmrAkBJMqEtWFlexzX):
   RiCwSyhPYVIDHmrAkBJMqEtWFlexzT=RiCwSyhPYVIDHmrAkBJMqEtWFlexzX
  else:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexzT=setBitrate
  try:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoj='https://apis.naver.com/pcLive/livePlatform/sUrl'
   RiCwSyhPYVIDHmrAkBJMqEtWFlexzj={'ch':channelId,'q':RiCwSyhPYVIDHmrAkBJMqEtWFlexzT,'p':'hls','cc':'KR','env':'pc',}
   RiCwSyhPYVIDHmrAkBJMqEtWFlexos=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.callRequestCookies('Get',RiCwSyhPYVIDHmrAkBJMqEtWFlexoj,payload=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,params=RiCwSyhPYVIDHmrAkBJMqEtWFlexzj,headers=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,cookies=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,redirects=RiCwSyhPYVIDHmrAkBJMqEtWFlexKs)
   if RiCwSyhPYVIDHmrAkBJMqEtWFlexos.status_code!=200:return ''
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoX=json.loads(RiCwSyhPYVIDHmrAkBJMqEtWFlexos.text)
   RiCwSyhPYVIDHmrAkBJMqEtWFlexzL=RiCwSyhPYVIDHmrAkBJMqEtWFlexoX.get('secUrl')
  except RiCwSyhPYVIDHmrAkBJMqEtWFlexKG as exception:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexKp(exception)
   return ''
  return RiCwSyhPYVIDHmrAkBJMqEtWFlexzL
 def GetStreamingRtmp(RiCwSyhPYVIDHmrAkBJMqEtWFlexof,RiCwSyhPYVIDHmrAkBJMqEtWFlexzK,setBitrate):
  RiCwSyhPYVIDHmrAkBJMqEtWFlexzL=''
  try:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoj='https://api-gw.sports.naver.com/schedule/%s/lives'%(RiCwSyhPYVIDHmrAkBJMqEtWFlexzK)
   RiCwSyhPYVIDHmrAkBJMqEtWFlexos=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.callRequestCookies('Get',RiCwSyhPYVIDHmrAkBJMqEtWFlexoj,payload=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,params=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,headers=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,cookies=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,redirects=RiCwSyhPYVIDHmrAkBJMqEtWFlexKs)
   if RiCwSyhPYVIDHmrAkBJMqEtWFlexos.status_code!=200:return ''
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoX=json.loads(RiCwSyhPYVIDHmrAkBJMqEtWFlexos.text)
   RiCwSyhPYVIDHmrAkBJMqEtWFlexzg=RiCwSyhPYVIDHmrAkBJMqEtWFlexoX.get('result').get('lives')[0]
   if setBitrate=='5000':
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzL=RiCwSyhPYVIDHmrAkBJMqEtWFlexzg.get('rtmpPlayUrl1080')
   else:
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzL=RiCwSyhPYVIDHmrAkBJMqEtWFlexzg.get('rtmpPlayUrl720')
  except RiCwSyhPYVIDHmrAkBJMqEtWFlexKG as exception:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexKp(exception)
   return ''
  return RiCwSyhPYVIDHmrAkBJMqEtWFlexzL
 def Get_BSList_Json(RiCwSyhPYVIDHmrAkBJMqEtWFlexof):
  RiCwSyhPYVIDHmrAkBJMqEtWFlexoN=[]
  RiCwSyhPYVIDHmrAkBJMqEtWFlexou =RiCwSyhPYVIDHmrAkBJMqEtWFlexof.make_viewdate(dtype='2')
  try:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoj='https://sports.news.naver.com/scoreboard/index.nhn'
   for RiCwSyhPYVIDHmrAkBJMqEtWFlexzn in RiCwSyhPYVIDHmrAkBJMqEtWFlexou:
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfo=[]
    RiCwSyhPYVIDHmrAkBJMqEtWFlexzj={'date':RiCwSyhPYVIDHmrAkBJMqEtWFlexzn}
    RiCwSyhPYVIDHmrAkBJMqEtWFlexos=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.callRequestCookies('Get',RiCwSyhPYVIDHmrAkBJMqEtWFlexoj,payload=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,params=RiCwSyhPYVIDHmrAkBJMqEtWFlexzj,headers=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu,cookies=RiCwSyhPYVIDHmrAkBJMqEtWFlexKu)
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexos.status_code!=200:return[]
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfz=BeautifulSoup(RiCwSyhPYVIDHmrAkBJMqEtWFlexos.text,'html.parser')
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfz=RiCwSyhPYVIDHmrAkBJMqEtWFlexfz.select_one('#content > div > table > tbody')
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfK='%s-%s-%s'%(RiCwSyhPYVIDHmrAkBJMqEtWFlexzn[:4],RiCwSyhPYVIDHmrAkBJMqEtWFlexzn[4:6],RiCwSyhPYVIDHmrAkBJMqEtWFlexzn[-2:])
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfv=RiCwSyhPYVIDHmrAkBJMqEtWFlexfz.find('tr')
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfo+=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.Get_NowTag_List(RiCwSyhPYVIDHmrAkBJMqEtWFlexfv,RiCwSyhPYVIDHmrAkBJMqEtWFlexfK)
    for RiCwSyhPYVIDHmrAkBJMqEtWFlexfv in RiCwSyhPYVIDHmrAkBJMqEtWFlexfv.next_siblings:
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexKb(RiCwSyhPYVIDHmrAkBJMqEtWFlexKL(RiCwSyhPYVIDHmrAkBJMqEtWFlexfv))!="<class 'bs4.element.Tag'>":continue
     RiCwSyhPYVIDHmrAkBJMqEtWFlexfo+=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.Get_NowTag_List(RiCwSyhPYVIDHmrAkBJMqEtWFlexfv,RiCwSyhPYVIDHmrAkBJMqEtWFlexfK)
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfO=''
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfa=''
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfc =''
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfU=''
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfd=''
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfN=''
    for RiCwSyhPYVIDHmrAkBJMqEtWFlexfu in RiCwSyhPYVIDHmrAkBJMqEtWFlexfo:
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('class')=='game' :RiCwSyhPYVIDHmrAkBJMqEtWFlexfO =RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('cont')
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('class')=='time' :RiCwSyhPYVIDHmrAkBJMqEtWFlexfa =RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('cont')
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('class')=='ing' :RiCwSyhPYVIDHmrAkBJMqEtWFlexfc =RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('cont')
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('class')=='title':RiCwSyhPYVIDHmrAkBJMqEtWFlexfU =RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('cont')
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('class')=='gameId':RiCwSyhPYVIDHmrAkBJMqEtWFlexfd=RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('cont')
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('class')=='relay':
      RiCwSyhPYVIDHmrAkBJMqEtWFlexfj='-'
      for RiCwSyhPYVIDHmrAkBJMqEtWFlexfs in RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('cont'):
       if RiCwSyhPYVIDHmrAkBJMqEtWFlexfs.get('live')in['Y','N']:
        RiCwSyhPYVIDHmrAkBJMqEtWFlexfj=RiCwSyhPYVIDHmrAkBJMqEtWFlexfs.get('live')
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('class')=='place':
      if RiCwSyhPYVIDHmrAkBJMqEtWFlexfj not in['Y','N']:continue
      RiCwSyhPYVIDHmrAkBJMqEtWFlexfN=RiCwSyhPYVIDHmrAkBJMqEtWFlexfu.get('cont')
      RiCwSyhPYVIDHmrAkBJMqEtWFlexfX={'category':RiCwSyhPYVIDHmrAkBJMqEtWFlexfO,'time':RiCwSyhPYVIDHmrAkBJMqEtWFlexfa,'title':' '.join(RiCwSyhPYVIDHmrAkBJMqEtWFlexfU.split()),'gameId':RiCwSyhPYVIDHmrAkBJMqEtWFlexfd,'live':RiCwSyhPYVIDHmrAkBJMqEtWFlexfj,'ing':RiCwSyhPYVIDHmrAkBJMqEtWFlexfc,'place':RiCwSyhPYVIDHmrAkBJMqEtWFlexfN,}
      RiCwSyhPYVIDHmrAkBJMqEtWFlexoN.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexfX)
  except RiCwSyhPYVIDHmrAkBJMqEtWFlexKG as exception:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexKp(exception)
   return[]
  return RiCwSyhPYVIDHmrAkBJMqEtWFlexoN
 def Get_NowTag_List(RiCwSyhPYVIDHmrAkBJMqEtWFlexof,RiCwSyhPYVIDHmrAkBJMqEtWFlexfv,RiCwSyhPYVIDHmrAkBJMqEtWFlexfK):
  RiCwSyhPYVIDHmrAkBJMqEtWFlexfo=[]
  RiCwSyhPYVIDHmrAkBJMqEtWFlexfp=RiCwSyhPYVIDHmrAkBJMqEtWFlexfv.find_all('td')
  for RiCwSyhPYVIDHmrAkBJMqEtWFlexfG in RiCwSyhPYVIDHmrAkBJMqEtWFlexfp:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexfQ=RiCwSyhPYVIDHmrAkBJMqEtWFlexfG.get('class')[0]
   if RiCwSyhPYVIDHmrAkBJMqEtWFlexfQ=='game':
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfb={'class':'game','cont':RiCwSyhPYVIDHmrAkBJMqEtWFlexfG.text,}
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfo.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexfb)
   elif RiCwSyhPYVIDHmrAkBJMqEtWFlexfQ=='time':
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfb={'class':'time','cont':RiCwSyhPYVIDHmrAkBJMqEtWFlexfK+' '+RiCwSyhPYVIDHmrAkBJMqEtWFlexfG.text,}
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfo.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexfb)
   elif RiCwSyhPYVIDHmrAkBJMqEtWFlexfQ=='gameinfo':
    pass
   elif RiCwSyhPYVIDHmrAkBJMqEtWFlexfQ=='state':
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfL=RiCwSyhPYVIDHmrAkBJMqEtWFlexfG.find_all('img')
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfT='-'
    for RiCwSyhPYVIDHmrAkBJMqEtWFlexfg in RiCwSyhPYVIDHmrAkBJMqEtWFlexfL:
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexfg.get('alt')=='진행중':
      RiCwSyhPYVIDHmrAkBJMqEtWFlexfT='Y'
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfb={'class':'ing','cont':RiCwSyhPYVIDHmrAkBJMqEtWFlexfT,}
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfo.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexfb)
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfb={'class':'title','cont':RiCwSyhPYVIDHmrAkBJMqEtWFlexfG.text,}
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfo.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexfb)
   elif RiCwSyhPYVIDHmrAkBJMqEtWFlexfQ=='relay':
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfn=''
    RiCwSyhPYVIDHmrAkBJMqEtWFlexKo=RiCwSyhPYVIDHmrAkBJMqEtWFlexfG.find('a')
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexKo:
     RiCwSyhPYVIDHmrAkBJMqEtWFlexKz=RiCwSyhPYVIDHmrAkBJMqEtWFlexKo.get('href')
     if "'" in RiCwSyhPYVIDHmrAkBJMqEtWFlexKz:RiCwSyhPYVIDHmrAkBJMqEtWFlexKz=RiCwSyhPYVIDHmrAkBJMqEtWFlexKz.split("'")[1]
     RiCwSyhPYVIDHmrAkBJMqEtWFlexKf=urllib.parse.urlsplit(RiCwSyhPYVIDHmrAkBJMqEtWFlexKz)
     RiCwSyhPYVIDHmrAkBJMqEtWFlexKf=RiCwSyhPYVIDHmrAkBJMqEtWFlexKT(urllib.parse.parse_qsl(RiCwSyhPYVIDHmrAkBJMqEtWFlexKf.query))
     RiCwSyhPYVIDHmrAkBJMqEtWFlexfn=RiCwSyhPYVIDHmrAkBJMqEtWFlexKf.get('gameId')
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfb={'class':'gameId','cont':RiCwSyhPYVIDHmrAkBJMqEtWFlexfn,}
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfo.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexfb)
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfL=RiCwSyhPYVIDHmrAkBJMqEtWFlexfG.find_all('img')
    RiCwSyhPYVIDHmrAkBJMqEtWFlexKv=[]
    for RiCwSyhPYVIDHmrAkBJMqEtWFlexfg in RiCwSyhPYVIDHmrAkBJMqEtWFlexfL:
     RiCwSyhPYVIDHmrAkBJMqEtWFlexKO =RiCwSyhPYVIDHmrAkBJMqEtWFlexfg.get('alt')
     RiCwSyhPYVIDHmrAkBJMqEtWFlexKa=RiCwSyhPYVIDHmrAkBJMqEtWFlexfg.get('onclick')
     RiCwSyhPYVIDHmrAkBJMqEtWFlexKc ='-'
     if RiCwSyhPYVIDHmrAkBJMqEtWFlexKa:
      if "'scb.tv'" in RiCwSyhPYVIDHmrAkBJMqEtWFlexKa:RiCwSyhPYVIDHmrAkBJMqEtWFlexKc='Y'
      elif "'scb.tv_off'" in RiCwSyhPYVIDHmrAkBJMqEtWFlexKa:RiCwSyhPYVIDHmrAkBJMqEtWFlexKc='N'
     RiCwSyhPYVIDHmrAkBJMqEtWFlexKv.append({'alt':RiCwSyhPYVIDHmrAkBJMqEtWFlexKO,'live':RiCwSyhPYVIDHmrAkBJMqEtWFlexKc})
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfb={'class':'relay','cont':RiCwSyhPYVIDHmrAkBJMqEtWFlexKv,}
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfo.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexfb)
   elif RiCwSyhPYVIDHmrAkBJMqEtWFlexfQ=='place':
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfb={'class':'place','cont':RiCwSyhPYVIDHmrAkBJMqEtWFlexfG.text,}
    RiCwSyhPYVIDHmrAkBJMqEtWFlexfo.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexfb)
   else:
    RiCwSyhPYVIDHmrAkBJMqEtWFlexKp(RiCwSyhPYVIDHmrAkBJMqEtWFlexfQ)
  return RiCwSyhPYVIDHmrAkBJMqEtWFlexfo
 def Get_Category_BSjson(RiCwSyhPYVIDHmrAkBJMqEtWFlexof):
  RiCwSyhPYVIDHmrAkBJMqEtWFlexoN=[]
  RiCwSyhPYVIDHmrAkBJMqEtWFlexop=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.Get_BSList_Json()
  RiCwSyhPYVIDHmrAkBJMqEtWFlexKU=[]
  for RiCwSyhPYVIDHmrAkBJMqEtWFlexKd in RiCwSyhPYVIDHmrAkBJMqEtWFlexop:
   if RiCwSyhPYVIDHmrAkBJMqEtWFlexKd.get('category')not in RiCwSyhPYVIDHmrAkBJMqEtWFlexKU:
    RiCwSyhPYVIDHmrAkBJMqEtWFlexKU.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexKd.get('category'))
  for RiCwSyhPYVIDHmrAkBJMqEtWFlexoL in RiCwSyhPYVIDHmrAkBJMqEtWFlexKU:
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoT='N'
   for RiCwSyhPYVIDHmrAkBJMqEtWFlexKd in RiCwSyhPYVIDHmrAkBJMqEtWFlexop:
    if RiCwSyhPYVIDHmrAkBJMqEtWFlexoL==RiCwSyhPYVIDHmrAkBJMqEtWFlexKd.get('category')and RiCwSyhPYVIDHmrAkBJMqEtWFlexKd.get('ing')=='Y':
     RiCwSyhPYVIDHmrAkBJMqEtWFlexoT='Y'
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoG={'category':RiCwSyhPYVIDHmrAkBJMqEtWFlexoL,'live':RiCwSyhPYVIDHmrAkBJMqEtWFlexoT,}
   RiCwSyhPYVIDHmrAkBJMqEtWFlexoN.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexoG)
  return RiCwSyhPYVIDHmrAkBJMqEtWFlexoN
 def Get_Gamelist_BSjson(RiCwSyhPYVIDHmrAkBJMqEtWFlexof,category):
  RiCwSyhPYVIDHmrAkBJMqEtWFlexoN =[]
  RiCwSyhPYVIDHmrAkBJMqEtWFlexop=RiCwSyhPYVIDHmrAkBJMqEtWFlexof.Get_BSList_Json()
  for RiCwSyhPYVIDHmrAkBJMqEtWFlexKd in RiCwSyhPYVIDHmrAkBJMqEtWFlexop:
   if RiCwSyhPYVIDHmrAkBJMqEtWFlexKd.get('category')==category:
    RiCwSyhPYVIDHmrAkBJMqEtWFlexoN.append(RiCwSyhPYVIDHmrAkBJMqEtWFlexKd)
  return RiCwSyhPYVIDHmrAkBJMqEtWFlexoN
# Created by pyminifier (https://github.com/liftoff/pyminifier)
