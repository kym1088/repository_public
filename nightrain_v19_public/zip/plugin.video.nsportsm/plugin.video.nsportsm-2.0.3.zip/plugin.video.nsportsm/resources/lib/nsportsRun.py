__author__="NightRain"
SfYVzmidpTwqrJFHlDANCsOQIGaMnK=object
SfYVzmidpTwqrJFHlDANCsOQIGaMnL=None
SfYVzmidpTwqrJFHlDANCsOQIGaMny=True
SfYVzmidpTwqrJFHlDANCsOQIGaMnW=False
SfYVzmidpTwqrJFHlDANCsOQIGaMnx=type
SfYVzmidpTwqrJFHlDANCsOQIGaMnR=dict
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import datetime
import urllib
import json
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
SfYVzmidpTwqrJFHlDANCsOQIGaMcn=[{'title':'경기별 보기 (타입1)','mode':'CATEGORY_LIST'},{'title':'경기별 보기 (타입2)','mode':'BS_CATEGORY'},{'title':'채널별 보기','mode':'CHANNEL_LIST'},{'title':'-----------------','mode':'XXX'},{'title':'** 경기중이 아닐때에는 시청이 제한될수 있음 **','mode':'XXX'},]
SfYVzmidpTwqrJFHlDANCsOQIGaMcP=[{'chId':'ad1','title':'Spotv1'},{'chId':'ad2','title':'KBS N Sports'},{'chId':'ad3','title':'SBS Sports'},{'chId':'ad4','title':'MBC Sports'},{'chId':'ad5','title':'Spotv2'},]
from nsportsCore import*
class SfYVzmidpTwqrJFHlDANCsOQIGaMcU(SfYVzmidpTwqrJFHlDANCsOQIGaMnK):
 def __init__(SfYVzmidpTwqrJFHlDANCsOQIGaMcg,SfYVzmidpTwqrJFHlDANCsOQIGaMcj,SfYVzmidpTwqrJFHlDANCsOQIGaMcv,SfYVzmidpTwqrJFHlDANCsOQIGaMcK):
  SfYVzmidpTwqrJFHlDANCsOQIGaMcg._addon_url =SfYVzmidpTwqrJFHlDANCsOQIGaMcj
  SfYVzmidpTwqrJFHlDANCsOQIGaMcg._addon_handle=SfYVzmidpTwqrJFHlDANCsOQIGaMcv
  SfYVzmidpTwqrJFHlDANCsOQIGaMcg.main_params =SfYVzmidpTwqrJFHlDANCsOQIGaMcK
  SfYVzmidpTwqrJFHlDANCsOQIGaMcg.NsportsObj =RiCwSyhPYVIDHmrAkBJMqEtWFlexoz() 
 def addon_noti(SfYVzmidpTwqrJFHlDANCsOQIGaMcg,sting):
  try:
   SfYVzmidpTwqrJFHlDANCsOQIGaMcy=xbmcgui.Dialog()
   SfYVzmidpTwqrJFHlDANCsOQIGaMcy.notification(__addonname__,sting)
  except:
   SfYVzmidpTwqrJFHlDANCsOQIGaMnL
 def addon_log(SfYVzmidpTwqrJFHlDANCsOQIGaMcg,string):
  try:
   SfYVzmidpTwqrJFHlDANCsOQIGaMcW=string.encode('utf-8','ignore')
  except:
   SfYVzmidpTwqrJFHlDANCsOQIGaMcW='addonException: addon_log'
  SfYVzmidpTwqrJFHlDANCsOQIGaMcx=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,SfYVzmidpTwqrJFHlDANCsOQIGaMcW),level=SfYVzmidpTwqrJFHlDANCsOQIGaMcx)
 def get_Bitrate_sel(SfYVzmidpTwqrJFHlDANCsOQIGaMcg):
  SfYVzmidpTwqrJFHlDANCsOQIGaMcR={'0':'5000','1':'2000','2':'800',}
  return SfYVzmidpTwqrJFHlDANCsOQIGaMcR.get(__addon__.getSetting('selected_quality'))
 def add_dir(SfYVzmidpTwqrJFHlDANCsOQIGaMcg,label,sublabel='',img='',infoLabels=SfYVzmidpTwqrJFHlDANCsOQIGaMnL,isFolder=SfYVzmidpTwqrJFHlDANCsOQIGaMny,params='',isLink=SfYVzmidpTwqrJFHlDANCsOQIGaMnW,ContextMenu=SfYVzmidpTwqrJFHlDANCsOQIGaMnL):
  SfYVzmidpTwqrJFHlDANCsOQIGaMcB='%s?%s'%(SfYVzmidpTwqrJFHlDANCsOQIGaMcg._addon_url,urllib.parse.urlencode(params))
  if sublabel:SfYVzmidpTwqrJFHlDANCsOQIGaMcX='%s < %s >'%(label,sublabel)
  else: SfYVzmidpTwqrJFHlDANCsOQIGaMcX=label
  if not img:img='DefaultFolder.png'
  SfYVzmidpTwqrJFHlDANCsOQIGaMce=xbmcgui.ListItem(SfYVzmidpTwqrJFHlDANCsOQIGaMcX)
  if SfYVzmidpTwqrJFHlDANCsOQIGaMnx(img)==SfYVzmidpTwqrJFHlDANCsOQIGaMnR:
   SfYVzmidpTwqrJFHlDANCsOQIGaMce.setArt(img)
  else:
   SfYVzmidpTwqrJFHlDANCsOQIGaMce.setArt({'thumb':img,'poster':img})
  if infoLabels:SfYVzmidpTwqrJFHlDANCsOQIGaMce.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   SfYVzmidpTwqrJFHlDANCsOQIGaMce.setProperty('IsPlayable','true')
  if ContextMenu:SfYVzmidpTwqrJFHlDANCsOQIGaMce.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(SfYVzmidpTwqrJFHlDANCsOQIGaMcg._addon_handle,SfYVzmidpTwqrJFHlDANCsOQIGaMcB,SfYVzmidpTwqrJFHlDANCsOQIGaMce,isFolder)
 def dp_Main_List(SfYVzmidpTwqrJFHlDANCsOQIGaMcg,args):
  for SfYVzmidpTwqrJFHlDANCsOQIGaMcE in SfYVzmidpTwqrJFHlDANCsOQIGaMcn:
   SfYVzmidpTwqrJFHlDANCsOQIGaMcX=SfYVzmidpTwqrJFHlDANCsOQIGaMcE.get('title')
   SfYVzmidpTwqrJFHlDANCsOQIGaMch=''
   SfYVzmidpTwqrJFHlDANCsOQIGaMct={'mode':SfYVzmidpTwqrJFHlDANCsOQIGaMcE.get('mode'),}
   if SfYVzmidpTwqrJFHlDANCsOQIGaMcE.get('mode')in['XXX']:
    SfYVzmidpTwqrJFHlDANCsOQIGaMcb=SfYVzmidpTwqrJFHlDANCsOQIGaMnW
    SfYVzmidpTwqrJFHlDANCsOQIGaMck =SfYVzmidpTwqrJFHlDANCsOQIGaMny
   else:
    SfYVzmidpTwqrJFHlDANCsOQIGaMcb=SfYVzmidpTwqrJFHlDANCsOQIGaMny
    SfYVzmidpTwqrJFHlDANCsOQIGaMck =SfYVzmidpTwqrJFHlDANCsOQIGaMnW
   if 'icon' in SfYVzmidpTwqrJFHlDANCsOQIGaMcE:SfYVzmidpTwqrJFHlDANCsOQIGaMch=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',SfYVzmidpTwqrJFHlDANCsOQIGaMcE.get('icon')) 
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.add_dir(SfYVzmidpTwqrJFHlDANCsOQIGaMcX,sublabel='',img=SfYVzmidpTwqrJFHlDANCsOQIGaMch,infoLabels=SfYVzmidpTwqrJFHlDANCsOQIGaMnL,isFolder=SfYVzmidpTwqrJFHlDANCsOQIGaMcb,params=SfYVzmidpTwqrJFHlDANCsOQIGaMct,isLink=SfYVzmidpTwqrJFHlDANCsOQIGaMck)
  xbmcplugin.endOfDirectory(SfYVzmidpTwqrJFHlDANCsOQIGaMcg._addon_handle)
 def dp_Channel_List(SfYVzmidpTwqrJFHlDANCsOQIGaMcg,args):
  SfYVzmidpTwqrJFHlDANCsOQIGaMco=SfYVzmidpTwqrJFHlDANCsOQIGaMcg.get_Bitrate_sel()
  for SfYVzmidpTwqrJFHlDANCsOQIGaMUc in SfYVzmidpTwqrJFHlDANCsOQIGaMcP:
   SfYVzmidpTwqrJFHlDANCsOQIGaMcX=SfYVzmidpTwqrJFHlDANCsOQIGaMUc.get('title')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUn=SfYVzmidpTwqrJFHlDANCsOQIGaMUc.get('chId')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUP={'mediatype':'episode','title':SfYVzmidpTwqrJFHlDANCsOQIGaMcX}
   SfYVzmidpTwqrJFHlDANCsOQIGaMct={'mode':'CLIVE','chId':SfYVzmidpTwqrJFHlDANCsOQIGaMUn,'maxBitrate':SfYVzmidpTwqrJFHlDANCsOQIGaMco,}
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.add_dir(SfYVzmidpTwqrJFHlDANCsOQIGaMcX,sublabel='',img='',infoLabels=SfYVzmidpTwqrJFHlDANCsOQIGaMUP,isFolder=SfYVzmidpTwqrJFHlDANCsOQIGaMnW,params=SfYVzmidpTwqrJFHlDANCsOQIGaMct,isLink=SfYVzmidpTwqrJFHlDANCsOQIGaMnW)
  xbmcplugin.endOfDirectory(SfYVzmidpTwqrJFHlDANCsOQIGaMcg._addon_handle)
 def dp_Category_List(SfYVzmidpTwqrJFHlDANCsOQIGaMcg,args):
  SfYVzmidpTwqrJFHlDANCsOQIGaMUg=SfYVzmidpTwqrJFHlDANCsOQIGaMcg.NsportsObj.Get_Category_List()
  for SfYVzmidpTwqrJFHlDANCsOQIGaMUj in SfYVzmidpTwqrJFHlDANCsOQIGaMUg:
   SfYVzmidpTwqrJFHlDANCsOQIGaMUv =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('groupnm')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUK =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('onairyn')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUL=','.join(SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('category'))
   if SfYVzmidpTwqrJFHlDANCsOQIGaMUK=='Y':SfYVzmidpTwqrJFHlDANCsOQIGaMcu='중계중'
   else:SfYVzmidpTwqrJFHlDANCsOQIGaMcu=''
   SfYVzmidpTwqrJFHlDANCsOQIGaMct={'mode':'GAME_LIST','category':SfYVzmidpTwqrJFHlDANCsOQIGaMUL,}
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.add_dir(SfYVzmidpTwqrJFHlDANCsOQIGaMUv,sublabel=SfYVzmidpTwqrJFHlDANCsOQIGaMcu,img='',infoLabels=SfYVzmidpTwqrJFHlDANCsOQIGaMnL,isFolder=SfYVzmidpTwqrJFHlDANCsOQIGaMny,params=SfYVzmidpTwqrJFHlDANCsOQIGaMct)
  xbmcplugin.endOfDirectory(SfYVzmidpTwqrJFHlDANCsOQIGaMcg._addon_handle,cacheToDisc=SfYVzmidpTwqrJFHlDANCsOQIGaMnW)
 def dp_Game_List(SfYVzmidpTwqrJFHlDANCsOQIGaMcg,args):
  SfYVzmidpTwqrJFHlDANCsOQIGaMUW=args.get('category')
  SfYVzmidpTwqrJFHlDANCsOQIGaMUg=SfYVzmidpTwqrJFHlDANCsOQIGaMcg.NsportsObj.Get_Game_List(SfYVzmidpTwqrJFHlDANCsOQIGaMUW)
  for SfYVzmidpTwqrJFHlDANCsOQIGaMUj in SfYVzmidpTwqrJFHlDANCsOQIGaMUg:
   SfYVzmidpTwqrJFHlDANCsOQIGaMUx =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('gameId')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUR =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('upperCategoryId')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUB =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('categoryId')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUX =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('statusCode')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUe =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('statusInfo')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUE =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('isOnAirTv')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUn =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('chId')
   SfYVzmidpTwqrJFHlDANCsOQIGaMcX =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('title')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUh =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('starttime')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUt =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('endTime')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUb =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('maxBitrate')
   if SfYVzmidpTwqrJFHlDANCsOQIGaMcX=='':SfYVzmidpTwqrJFHlDANCsOQIGaMcX=SfYVzmidpTwqrJFHlDANCsOQIGaMUx
   if SfYVzmidpTwqrJFHlDANCsOQIGaMUE=='Y':
    SfYVzmidpTwqrJFHlDANCsOQIGaMUk='방송중'
   else:
    if SfYVzmidpTwqrJFHlDANCsOQIGaMUe=='경기취소':
     SfYVzmidpTwqrJFHlDANCsOQIGaMUk=SfYVzmidpTwqrJFHlDANCsOQIGaMUe
    else:
     SfYVzmidpTwqrJFHlDANCsOQIGaMUk=''
   if SfYVzmidpTwqrJFHlDANCsOQIGaMUh=='':
    SfYVzmidpTwqrJFHlDANCsOQIGaMcu=SfYVzmidpTwqrJFHlDANCsOQIGaMUk
   else:
    if SfYVzmidpTwqrJFHlDANCsOQIGaMUk=='':
     SfYVzmidpTwqrJFHlDANCsOQIGaMcu=SfYVzmidpTwqrJFHlDANCsOQIGaMUh
    else:
     SfYVzmidpTwqrJFHlDANCsOQIGaMcu=SfYVzmidpTwqrJFHlDANCsOQIGaMUh+' - '+SfYVzmidpTwqrJFHlDANCsOQIGaMUk
   SfYVzmidpTwqrJFHlDANCsOQIGaMUP={'mediatype':'episode','title':SfYVzmidpTwqrJFHlDANCsOQIGaMcX,'plot':'%s\n\n시작 : %s\n종료 : %s'%(SfYVzmidpTwqrJFHlDANCsOQIGaMcX,SfYVzmidpTwqrJFHlDANCsOQIGaMUh,SfYVzmidpTwqrJFHlDANCsOQIGaMUt)}
   SfYVzmidpTwqrJFHlDANCsOQIGaMct={'mode':'LIVE','chId':SfYVzmidpTwqrJFHlDANCsOQIGaMUn,'maxBitrate':SfYVzmidpTwqrJFHlDANCsOQIGaMUb,'gameId':SfYVzmidpTwqrJFHlDANCsOQIGaMUx,}
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.add_dir(SfYVzmidpTwqrJFHlDANCsOQIGaMcX,sublabel=SfYVzmidpTwqrJFHlDANCsOQIGaMcu,img='',infoLabels=SfYVzmidpTwqrJFHlDANCsOQIGaMUP,isFolder=SfYVzmidpTwqrJFHlDANCsOQIGaMnW,params=SfYVzmidpTwqrJFHlDANCsOQIGaMct)
  xbmcplugin.endOfDirectory(SfYVzmidpTwqrJFHlDANCsOQIGaMcg._addon_handle,cacheToDisc=SfYVzmidpTwqrJFHlDANCsOQIGaMnW)
 def dp_BsCategory_List(SfYVzmidpTwqrJFHlDANCsOQIGaMcg,args):
  SfYVzmidpTwqrJFHlDANCsOQIGaMUg=SfYVzmidpTwqrJFHlDANCsOQIGaMcg.NsportsObj.Get_Category_BSjson()
  for SfYVzmidpTwqrJFHlDANCsOQIGaMUj in SfYVzmidpTwqrJFHlDANCsOQIGaMUg:
   SfYVzmidpTwqrJFHlDANCsOQIGaMUL =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('category')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUu =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('live')
   if SfYVzmidpTwqrJFHlDANCsOQIGaMUu=='Y':SfYVzmidpTwqrJFHlDANCsOQIGaMcu='중계중'
   else:SfYVzmidpTwqrJFHlDANCsOQIGaMcu=''
   SfYVzmidpTwqrJFHlDANCsOQIGaMct={'mode':'BS_GAME','category':SfYVzmidpTwqrJFHlDANCsOQIGaMUL,}
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.add_dir(SfYVzmidpTwqrJFHlDANCsOQIGaMUL,sublabel=SfYVzmidpTwqrJFHlDANCsOQIGaMcu,img='',infoLabels=SfYVzmidpTwqrJFHlDANCsOQIGaMnL,isFolder=SfYVzmidpTwqrJFHlDANCsOQIGaMny,params=SfYVzmidpTwqrJFHlDANCsOQIGaMct)
  xbmcplugin.endOfDirectory(SfYVzmidpTwqrJFHlDANCsOQIGaMcg._addon_handle,cacheToDisc=SfYVzmidpTwqrJFHlDANCsOQIGaMnW)
 def dp_BsGame_List(SfYVzmidpTwqrJFHlDANCsOQIGaMcg,args):
  SfYVzmidpTwqrJFHlDANCsOQIGaMUL=args.get('category')
  SfYVzmidpTwqrJFHlDANCsOQIGaMUg=SfYVzmidpTwqrJFHlDANCsOQIGaMcg.NsportsObj.Get_Gamelist_BSjson(SfYVzmidpTwqrJFHlDANCsOQIGaMUL)
  for SfYVzmidpTwqrJFHlDANCsOQIGaMUj in SfYVzmidpTwqrJFHlDANCsOQIGaMUg:
   SfYVzmidpTwqrJFHlDANCsOQIGaMUx =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('gameId')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUo =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('time')
   SfYVzmidpTwqrJFHlDANCsOQIGaMcX =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('title')
   SfYVzmidpTwqrJFHlDANCsOQIGaMUu =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('live')
   SfYVzmidpTwqrJFHlDANCsOQIGaMnc =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('ing')
   SfYVzmidpTwqrJFHlDANCsOQIGaMnU =SfYVzmidpTwqrJFHlDANCsOQIGaMUj.get('place')
   if SfYVzmidpTwqrJFHlDANCsOQIGaMUu=='Y':
    SfYVzmidpTwqrJFHlDANCsOQIGaMUk='방송중'
   else:
    SfYVzmidpTwqrJFHlDANCsOQIGaMUk=''
   if SfYVzmidpTwqrJFHlDANCsOQIGaMUk=='':
    SfYVzmidpTwqrJFHlDANCsOQIGaMcu=SfYVzmidpTwqrJFHlDANCsOQIGaMUo
   else:
    SfYVzmidpTwqrJFHlDANCsOQIGaMcu=SfYVzmidpTwqrJFHlDANCsOQIGaMUo+' - '+SfYVzmidpTwqrJFHlDANCsOQIGaMUk
   SfYVzmidpTwqrJFHlDANCsOQIGaMUP={'mediatype':'episode','title':SfYVzmidpTwqrJFHlDANCsOQIGaMcX,'plot':'%s\n\n시간 : %s\n\n%s'%(SfYVzmidpTwqrJFHlDANCsOQIGaMcX,SfYVzmidpTwqrJFHlDANCsOQIGaMcu,SfYVzmidpTwqrJFHlDANCsOQIGaMnU)}
   SfYVzmidpTwqrJFHlDANCsOQIGaMct={'mode':'LIVE','gameId':SfYVzmidpTwqrJFHlDANCsOQIGaMUx,}
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.add_dir(SfYVzmidpTwqrJFHlDANCsOQIGaMcX,sublabel=SfYVzmidpTwqrJFHlDANCsOQIGaMcu,img='',infoLabels=SfYVzmidpTwqrJFHlDANCsOQIGaMUP,isFolder=SfYVzmidpTwqrJFHlDANCsOQIGaMnW,params=SfYVzmidpTwqrJFHlDANCsOQIGaMct)
  xbmcplugin.endOfDirectory(SfYVzmidpTwqrJFHlDANCsOQIGaMcg._addon_handle,cacheToDisc=SfYVzmidpTwqrJFHlDANCsOQIGaMnW)
 def play_VIDEO(SfYVzmidpTwqrJFHlDANCsOQIGaMcg,args):
  SfYVzmidpTwqrJFHlDANCsOQIGaMUx =args.get('gameId')
  SfYVzmidpTwqrJFHlDANCsOQIGaMnP =SfYVzmidpTwqrJFHlDANCsOQIGaMcg.get_Bitrate_sel()
  if SfYVzmidpTwqrJFHlDANCsOQIGaMUx=='' or SfYVzmidpTwqrJFHlDANCsOQIGaMUx==SfYVzmidpTwqrJFHlDANCsOQIGaMnL:return
  SfYVzmidpTwqrJFHlDANCsOQIGaMng=SfYVzmidpTwqrJFHlDANCsOQIGaMcg.NsportsObj.GetStreamingRtmp(SfYVzmidpTwqrJFHlDANCsOQIGaMUx,SfYVzmidpTwqrJFHlDANCsOQIGaMnP)
  if SfYVzmidpTwqrJFHlDANCsOQIGaMng=='':
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.addon_noti(__language__(30901).encode('utf8'))
   return
  SfYVzmidpTwqrJFHlDANCsOQIGaMcg.addon_log(SfYVzmidpTwqrJFHlDANCsOQIGaMng)
  SfYVzmidpTwqrJFHlDANCsOQIGaMnj=xbmcgui.ListItem(path=SfYVzmidpTwqrJFHlDANCsOQIGaMng)
  xbmcplugin.setResolvedUrl(SfYVzmidpTwqrJFHlDANCsOQIGaMcg._addon_handle,SfYVzmidpTwqrJFHlDANCsOQIGaMny,SfYVzmidpTwqrJFHlDANCsOQIGaMnj)
 def play_CHANNEL(SfYVzmidpTwqrJFHlDANCsOQIGaMcg,args):
  SfYVzmidpTwqrJFHlDANCsOQIGaMUn =args.get('chId')
  SfYVzmidpTwqrJFHlDANCsOQIGaMUb =args.get('maxBitrate')
  SfYVzmidpTwqrJFHlDANCsOQIGaMnP =SfYVzmidpTwqrJFHlDANCsOQIGaMcg.get_Bitrate_sel()
  SfYVzmidpTwqrJFHlDANCsOQIGaMng=SfYVzmidpTwqrJFHlDANCsOQIGaMcg.NsportsObj.GetStreamingURL(SfYVzmidpTwqrJFHlDANCsOQIGaMUn,SfYVzmidpTwqrJFHlDANCsOQIGaMnP,SfYVzmidpTwqrJFHlDANCsOQIGaMUb)
  if SfYVzmidpTwqrJFHlDANCsOQIGaMng=='':
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.addon_noti(__language__(30901).encode('utf8'))
   return
  SfYVzmidpTwqrJFHlDANCsOQIGaMcg.addon_log(SfYVzmidpTwqrJFHlDANCsOQIGaMng)
  SfYVzmidpTwqrJFHlDANCsOQIGaMnj=xbmcgui.ListItem(path=SfYVzmidpTwqrJFHlDANCsOQIGaMng)
  xbmcplugin.setResolvedUrl(SfYVzmidpTwqrJFHlDANCsOQIGaMcg._addon_handle,SfYVzmidpTwqrJFHlDANCsOQIGaMny,SfYVzmidpTwqrJFHlDANCsOQIGaMnj)
 def nsports_main(SfYVzmidpTwqrJFHlDANCsOQIGaMcg):
  SfYVzmidpTwqrJFHlDANCsOQIGaMnv=SfYVzmidpTwqrJFHlDANCsOQIGaMcg.main_params.get('mode',SfYVzmidpTwqrJFHlDANCsOQIGaMnL)
  if SfYVzmidpTwqrJFHlDANCsOQIGaMnv is SfYVzmidpTwqrJFHlDANCsOQIGaMnL:
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.dp_Main_List(SfYVzmidpTwqrJFHlDANCsOQIGaMcg.main_params)
  elif SfYVzmidpTwqrJFHlDANCsOQIGaMnv=='CATEGORY_LIST':
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.dp_Category_List(SfYVzmidpTwqrJFHlDANCsOQIGaMcg.main_params)
  elif SfYVzmidpTwqrJFHlDANCsOQIGaMnv=='BS_CATEGORY':
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.dp_BsCategory_List(SfYVzmidpTwqrJFHlDANCsOQIGaMcg.main_params)
  elif SfYVzmidpTwqrJFHlDANCsOQIGaMnv=='GAME_LIST':
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.dp_Game_List(SfYVzmidpTwqrJFHlDANCsOQIGaMcg.main_params)
  elif SfYVzmidpTwqrJFHlDANCsOQIGaMnv=='BS_GAME':
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.dp_BsGame_List(SfYVzmidpTwqrJFHlDANCsOQIGaMcg.main_params)
  elif SfYVzmidpTwqrJFHlDANCsOQIGaMnv=='LIVE':
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.play_VIDEO(SfYVzmidpTwqrJFHlDANCsOQIGaMcg.main_params)
  elif SfYVzmidpTwqrJFHlDANCsOQIGaMnv=='CLIVE':
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.play_CHANNEL(SfYVzmidpTwqrJFHlDANCsOQIGaMcg.main_params)
  elif SfYVzmidpTwqrJFHlDANCsOQIGaMnv=='CHANNEL_LIST':
   SfYVzmidpTwqrJFHlDANCsOQIGaMcg.dp_Channel_List(SfYVzmidpTwqrJFHlDANCsOQIGaMcg.main_params)
  else:
   SfYVzmidpTwqrJFHlDANCsOQIGaMnL
# Created by pyminifier (https://github.com/liftoff/pyminifier)
