__author__="NightRain"
InUXyVHJoWpNiGcwRhePlQDELsfYmd=print
InUXyVHJoWpNiGcwRhePlQDELsfYmO=ImportError
InUXyVHJoWpNiGcwRhePlQDELsfYmT=object
InUXyVHJoWpNiGcwRhePlQDELsfYmv=None
InUXyVHJoWpNiGcwRhePlQDELsfYmx=False
InUXyVHJoWpNiGcwRhePlQDELsfYmB=open
InUXyVHJoWpNiGcwRhePlQDELsfYmt=True
InUXyVHJoWpNiGcwRhePlQDELsfYmq=int
InUXyVHJoWpNiGcwRhePlQDELsfYmu=range
InUXyVHJoWpNiGcwRhePlQDELsfYmC=Exception
InUXyVHJoWpNiGcwRhePlQDELsfYmz=len
InUXyVHJoWpNiGcwRhePlQDELsfYmj=str
InUXyVHJoWpNiGcwRhePlQDELsfYAF=dict
InUXyVHJoWpNiGcwRhePlQDELsfYAr=list
InUXyVHJoWpNiGcwRhePlQDELsfYAg=bytes
InUXyVHJoWpNiGcwRhePlQDELsfYAS=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 InUXyVHJoWpNiGcwRhePlQDELsfYmd('Cryptodome')
except InUXyVHJoWpNiGcwRhePlQDELsfYmO:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 InUXyVHJoWpNiGcwRhePlQDELsfYmd('Crypto')
InUXyVHJoWpNiGcwRhePlQDELsfYFg={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
InUXyVHJoWpNiGcwRhePlQDELsfYFS ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
InUXyVHJoWpNiGcwRhePlQDELsfYFb =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class InUXyVHJoWpNiGcwRhePlQDELsfYFr(InUXyVHJoWpNiGcwRhePlQDELsfYmT):
 def __init__(InUXyVHJoWpNiGcwRhePlQDELsfYFK):
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.NETWORKCODE ='CSND0900'
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.OSCODE ='CSOD0900' 
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TELECODE ='CSCD0900'
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.SCREENCODE ='CSSD0100'
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.SCREENCODE_ATV ='CSSD1300' 
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.LIVE_LIMIT =20 
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.VOD_LIMIT =24 
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.EPISODE_LIMIT =30 
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.SEARCH_LIMIT =30 
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.MOVIE_LIMIT =24 
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN ='https://api.tving.com'
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN ='https://image.tving.com'
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.SEARCH_DOMAIN ='https://search-api.tving.com'
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.LOGIN_DOMAIN ='https://user.tving.com'
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.URL_DOMAIN ='https://www.tving.com'
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.MOVIE_LITE =['2610061','2610161','261062']
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36'
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.DEFAULT_HEADER ={'user-agent':InUXyVHJoWpNiGcwRhePlQDELsfYFK.USER_AGENT}
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV_SESSION_COOKIES1=''
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV_SESSION_COOKIES2=''
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV_STREAM_FILENAME =''
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV_SESSION_TEXT1 =''
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV_SESSION_TEXT2 =''
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.KodiVersion=20
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV ={}
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.Init_TV_Total()
 def Init_TV_Total(InUXyVHJoWpNiGcwRhePlQDELsfYFK):
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N','tving_authToken':'',},}
 def callRequestCookies(InUXyVHJoWpNiGcwRhePlQDELsfYFK,jobtype,InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYmv,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv,redirects=InUXyVHJoWpNiGcwRhePlQDELsfYmx):
  InUXyVHJoWpNiGcwRhePlQDELsfYFm=InUXyVHJoWpNiGcwRhePlQDELsfYFK.DEFAULT_HEADER
  if headers:InUXyVHJoWpNiGcwRhePlQDELsfYFm.update(headers)
  if jobtype=='Get':
   InUXyVHJoWpNiGcwRhePlQDELsfYFA=requests.get(InUXyVHJoWpNiGcwRhePlQDELsfYgF,params=params,headers=InUXyVHJoWpNiGcwRhePlQDELsfYFm,cookies=cookies,allow_redirects=redirects)
  else:
   InUXyVHJoWpNiGcwRhePlQDELsfYFA=requests.post(InUXyVHJoWpNiGcwRhePlQDELsfYgF,data=payload,params=params,headers=InUXyVHJoWpNiGcwRhePlQDELsfYFm,cookies=cookies,allow_redirects=redirects)
  InUXyVHJoWpNiGcwRhePlQDELsfYmd(InUXyVHJoWpNiGcwRhePlQDELsfYFA.url)
  return InUXyVHJoWpNiGcwRhePlQDELsfYFA
 def JsonFile_Save(InUXyVHJoWpNiGcwRhePlQDELsfYFK,filename,InUXyVHJoWpNiGcwRhePlQDELsfYFk):
  if filename=='':return InUXyVHJoWpNiGcwRhePlQDELsfYmx
  try:
   fp=InUXyVHJoWpNiGcwRhePlQDELsfYmB(filename,'w',-1,'utf-8')
   json.dump(InUXyVHJoWpNiGcwRhePlQDELsfYFk,fp,indent=4,ensure_ascii=InUXyVHJoWpNiGcwRhePlQDELsfYmx)
   fp.close()
  except:
   return InUXyVHJoWpNiGcwRhePlQDELsfYmx
  return InUXyVHJoWpNiGcwRhePlQDELsfYmt
 def JsonFile_Load(InUXyVHJoWpNiGcwRhePlQDELsfYFK,filename):
  if filename=='':return{}
  try:
   fp=InUXyVHJoWpNiGcwRhePlQDELsfYmB(filename,'r',-1,'utf-8')
   InUXyVHJoWpNiGcwRhePlQDELsfYFM=json.load(fp)
   fp.close()
  except:
   return{}
  return InUXyVHJoWpNiGcwRhePlQDELsfYFM
 def TextFile_Save(InUXyVHJoWpNiGcwRhePlQDELsfYFK,filename,resText):
  if filename=='':return InUXyVHJoWpNiGcwRhePlQDELsfYmx
  try:
   fp=InUXyVHJoWpNiGcwRhePlQDELsfYmB(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return InUXyVHJoWpNiGcwRhePlQDELsfYmx
  return InUXyVHJoWpNiGcwRhePlQDELsfYmt
 def Save_session_acount(InUXyVHJoWpNiGcwRhePlQDELsfYFK,InUXyVHJoWpNiGcwRhePlQDELsfYFd,InUXyVHJoWpNiGcwRhePlQDELsfYFO,InUXyVHJoWpNiGcwRhePlQDELsfYFT,InUXyVHJoWpNiGcwRhePlQDELsfYFv):
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['account']['tvid'] =base64.standard_b64encode(InUXyVHJoWpNiGcwRhePlQDELsfYFd.encode()).decode('utf-8')
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['account']['tvpw'] =base64.standard_b64encode(InUXyVHJoWpNiGcwRhePlQDELsfYFO.encode()).decode('utf-8')
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['account']['tvtype']=InUXyVHJoWpNiGcwRhePlQDELsfYFT 
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['account']['tvpf'] =InUXyVHJoWpNiGcwRhePlQDELsfYFv 
 def Load_session_acount(InUXyVHJoWpNiGcwRhePlQDELsfYFK):
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYFd =base64.standard_b64decode(InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['account']['tvid']).decode('utf-8')
   InUXyVHJoWpNiGcwRhePlQDELsfYFO =base64.standard_b64decode(InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['account']['tvpw']).decode('utf-8')
   InUXyVHJoWpNiGcwRhePlQDELsfYFT=InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['account']['tvtype']
   InUXyVHJoWpNiGcwRhePlQDELsfYFv =InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return InUXyVHJoWpNiGcwRhePlQDELsfYFd,InUXyVHJoWpNiGcwRhePlQDELsfYFO,InUXyVHJoWpNiGcwRhePlQDELsfYFT,InUXyVHJoWpNiGcwRhePlQDELsfYFv
 def makeDefaultCookies(InUXyVHJoWpNiGcwRhePlQDELsfYFK):
  InUXyVHJoWpNiGcwRhePlQDELsfYFx={}
  if InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_token']:InUXyVHJoWpNiGcwRhePlQDELsfYFx['_tving_token']=InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_token']
  if InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_userinfo']:InUXyVHJoWpNiGcwRhePlQDELsfYFx['POC_USERINFO']=InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_userinfo']
  if InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_maintoken']:InUXyVHJoWpNiGcwRhePlQDELsfYFx[InUXyVHJoWpNiGcwRhePlQDELsfYFK.GLOBAL_COOKIENM['tv_maintoken']]=InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_maintoken']
  if InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_cookiekey']:InUXyVHJoWpNiGcwRhePlQDELsfYFx[InUXyVHJoWpNiGcwRhePlQDELsfYFK.GLOBAL_COOKIENM['tv_cookiekey']]=InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_cookiekey']
  if InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_lockkey']:InUXyVHJoWpNiGcwRhePlQDELsfYFx[InUXyVHJoWpNiGcwRhePlQDELsfYFK.GLOBAL_COOKIENM['tv_lockkey']]=InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_lockkey']
  if InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_authToken']:InUXyVHJoWpNiGcwRhePlQDELsfYFx['authToken']=InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_authToken']
  return InUXyVHJoWpNiGcwRhePlQDELsfYFx
 def makeCookiesStr(InUXyVHJoWpNiGcwRhePlQDELsfYFK):
  return '_tving_token='+InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_token']+';'+ 'POC_USERINFO='+InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_userinfo']+';'+ InUXyVHJoWpNiGcwRhePlQDELsfYFK.GLOBAL_COOKIENM['tv_maintoken']+'='+InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_maintoken']+';'+ InUXyVHJoWpNiGcwRhePlQDELsfYFK.GLOBAL_COOKIENM['tv_cookiekey']+'='+InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_cookiekey']+';'+ InUXyVHJoWpNiGcwRhePlQDELsfYFK.GLOBAL_COOKIENM['tv_lockkey']+'='+InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_lockkey']
 def getDeviceStr(InUXyVHJoWpNiGcwRhePlQDELsfYFK):
  InUXyVHJoWpNiGcwRhePlQDELsfYFB=[]
  InUXyVHJoWpNiGcwRhePlQDELsfYFB.append('Windows') 
  InUXyVHJoWpNiGcwRhePlQDELsfYFB.append('Chrome') 
  InUXyVHJoWpNiGcwRhePlQDELsfYFB.append('ko-KR') 
  InUXyVHJoWpNiGcwRhePlQDELsfYFB.append('undefined') 
  InUXyVHJoWpNiGcwRhePlQDELsfYFB.append('24') 
  InUXyVHJoWpNiGcwRhePlQDELsfYFB.append(u'한국 표준시')
  InUXyVHJoWpNiGcwRhePlQDELsfYFB.append('undefined') 
  InUXyVHJoWpNiGcwRhePlQDELsfYFB.append('undefined') 
  InUXyVHJoWpNiGcwRhePlQDELsfYFB.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  InUXyVHJoWpNiGcwRhePlQDELsfYFt=''
  for InUXyVHJoWpNiGcwRhePlQDELsfYFq in InUXyVHJoWpNiGcwRhePlQDELsfYFB:
   InUXyVHJoWpNiGcwRhePlQDELsfYFt+=InUXyVHJoWpNiGcwRhePlQDELsfYFq+'|'
  return InUXyVHJoWpNiGcwRhePlQDELsfYFt
 def GetDefaultParams(InUXyVHJoWpNiGcwRhePlQDELsfYFK,uhd=InUXyVHJoWpNiGcwRhePlQDELsfYmx):
  if uhd==InUXyVHJoWpNiGcwRhePlQDELsfYmx:
   InUXyVHJoWpNiGcwRhePlQDELsfYFu={'apiKey':InUXyVHJoWpNiGcwRhePlQDELsfYFK.APIKEY,'networkCode':InUXyVHJoWpNiGcwRhePlQDELsfYFK.NETWORKCODE,'osCode':InUXyVHJoWpNiGcwRhePlQDELsfYFK.OSCODE,'teleCode':InUXyVHJoWpNiGcwRhePlQDELsfYFK.TELECODE,'screenCode':InUXyVHJoWpNiGcwRhePlQDELsfYFK.SCREENCODE,}
  else:
   InUXyVHJoWpNiGcwRhePlQDELsfYFu={'apiKey':InUXyVHJoWpNiGcwRhePlQDELsfYFK.APIKEY_ATV,'networkCode':InUXyVHJoWpNiGcwRhePlQDELsfYFK.NETWORKCODE,'osCode':InUXyVHJoWpNiGcwRhePlQDELsfYFK.OSCODE,'teleCode':InUXyVHJoWpNiGcwRhePlQDELsfYFK.TELECODE,'screenCode':InUXyVHJoWpNiGcwRhePlQDELsfYFK.SCREENCODE_ATV,}
  return InUXyVHJoWpNiGcwRhePlQDELsfYFu
 def GetNoCache(InUXyVHJoWpNiGcwRhePlQDELsfYFK,timetype=1):
  if timetype==1:
   return InUXyVHJoWpNiGcwRhePlQDELsfYmq(time.time())
  else:
   return InUXyVHJoWpNiGcwRhePlQDELsfYmq(time.time()*1000)
 def GetUniqueid(InUXyVHJoWpNiGcwRhePlQDELsfYFK,hValue=InUXyVHJoWpNiGcwRhePlQDELsfYmv):
  if hValue:
   import hashlib
   InUXyVHJoWpNiGcwRhePlQDELsfYFC=hashlib.sha1()
   InUXyVHJoWpNiGcwRhePlQDELsfYFC.update(hValue.encode())
   InUXyVHJoWpNiGcwRhePlQDELsfYFz=InUXyVHJoWpNiGcwRhePlQDELsfYFC.hexdigest()[:8]
  else:
   InUXyVHJoWpNiGcwRhePlQDELsfYFj=[0 for i in InUXyVHJoWpNiGcwRhePlQDELsfYmu(256)]
   for i in InUXyVHJoWpNiGcwRhePlQDELsfYmu(256):
    InUXyVHJoWpNiGcwRhePlQDELsfYFj[i]='%02x'%(i)
   InUXyVHJoWpNiGcwRhePlQDELsfYrF=InUXyVHJoWpNiGcwRhePlQDELsfYmq(4294967295*random.random())|0
   InUXyVHJoWpNiGcwRhePlQDELsfYFz=InUXyVHJoWpNiGcwRhePlQDELsfYFj[255&InUXyVHJoWpNiGcwRhePlQDELsfYrF]+InUXyVHJoWpNiGcwRhePlQDELsfYFj[InUXyVHJoWpNiGcwRhePlQDELsfYrF>>8&255]+InUXyVHJoWpNiGcwRhePlQDELsfYFj[InUXyVHJoWpNiGcwRhePlQDELsfYrF>>16&255]+InUXyVHJoWpNiGcwRhePlQDELsfYFj[InUXyVHJoWpNiGcwRhePlQDELsfYrF>>24&255]
  return InUXyVHJoWpNiGcwRhePlQDELsfYFz
 def GetCredential(InUXyVHJoWpNiGcwRhePlQDELsfYFK,user_id,user_pw,login_type,user_pf):
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYrg=InUXyVHJoWpNiGcwRhePlQDELsfYFK.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   InUXyVHJoWpNiGcwRhePlQDELsfYrS={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Post',InUXyVHJoWpNiGcwRhePlQDELsfYrg,payload=InUXyVHJoWpNiGcwRhePlQDELsfYrS,params=InUXyVHJoWpNiGcwRhePlQDELsfYmv,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv)
   for InUXyVHJoWpNiGcwRhePlQDELsfYrK in InUXyVHJoWpNiGcwRhePlQDELsfYrb.cookies:
    if InUXyVHJoWpNiGcwRhePlQDELsfYrK.name=='_tving_token':
     InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_token']=InUXyVHJoWpNiGcwRhePlQDELsfYrK.value
    elif InUXyVHJoWpNiGcwRhePlQDELsfYrK.name=='POC_USERINFO':
     InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_userinfo']=InUXyVHJoWpNiGcwRhePlQDELsfYrK.value
    elif InUXyVHJoWpNiGcwRhePlQDELsfYrK.name=='authToken':
     InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_authToken']=InUXyVHJoWpNiGcwRhePlQDELsfYrK.value
   if not InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_token']:
    InUXyVHJoWpNiGcwRhePlQDELsfYFK.Init_TV_Total()
    return InUXyVHJoWpNiGcwRhePlQDELsfYmx
   InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_maintoken']=InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_token']
   if InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetProfileToken(user_pf)==InUXyVHJoWpNiGcwRhePlQDELsfYmx:
    InUXyVHJoWpNiGcwRhePlQDELsfYFK.Init_TV_Total()
    return InUXyVHJoWpNiGcwRhePlQDELsfYmx
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies'])
   InUXyVHJoWpNiGcwRhePlQDELsfYrm =InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDeviceList()
   if InUXyVHJoWpNiGcwRhePlQDELsfYrm not in['','-']:
    InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_uuid']=InUXyVHJoWpNiGcwRhePlQDELsfYrm+'-'+InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetUniqueid(InUXyVHJoWpNiGcwRhePlQDELsfYrm)
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
   InUXyVHJoWpNiGcwRhePlQDELsfYFK.Init_TV_Total()
   return InUXyVHJoWpNiGcwRhePlQDELsfYmx
  return InUXyVHJoWpNiGcwRhePlQDELsfYmt
 def GetProfileToken(InUXyVHJoWpNiGcwRhePlQDELsfYFK,user_pf):
  InUXyVHJoWpNiGcwRhePlQDELsfYrA=[]
  InUXyVHJoWpNiGcwRhePlQDELsfYrk =''
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYra ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   InUXyVHJoWpNiGcwRhePlQDELsfYFx=InUXyVHJoWpNiGcwRhePlQDELsfYFK.makeDefaultCookies()
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(InUXyVHJoWpNiGcwRhePlQDELsfYFx)
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYra,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYmv,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYFx)
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   InUXyVHJoWpNiGcwRhePlQDELsfYrA =re.findall('data-profile-no="\d+"',InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(InUXyVHJoWpNiGcwRhePlQDELsfYrA)
   for i in InUXyVHJoWpNiGcwRhePlQDELsfYmu(InUXyVHJoWpNiGcwRhePlQDELsfYmz(InUXyVHJoWpNiGcwRhePlQDELsfYrA)):
    InUXyVHJoWpNiGcwRhePlQDELsfYrM =InUXyVHJoWpNiGcwRhePlQDELsfYrA[i].replace('data-profile-no=','').replace('"','')
    InUXyVHJoWpNiGcwRhePlQDELsfYrA[i]=InUXyVHJoWpNiGcwRhePlQDELsfYrM
   InUXyVHJoWpNiGcwRhePlQDELsfYrk=InUXyVHJoWpNiGcwRhePlQDELsfYrA[user_pf]
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
   InUXyVHJoWpNiGcwRhePlQDELsfYFK.Init_TV_Total()
   return InUXyVHJoWpNiGcwRhePlQDELsfYmx
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYra ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   InUXyVHJoWpNiGcwRhePlQDELsfYFx=InUXyVHJoWpNiGcwRhePlQDELsfYFK.makeDefaultCookies()
   InUXyVHJoWpNiGcwRhePlQDELsfYrS={'profileNo':InUXyVHJoWpNiGcwRhePlQDELsfYrk}
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Post',InUXyVHJoWpNiGcwRhePlQDELsfYra,payload=InUXyVHJoWpNiGcwRhePlQDELsfYrS,params=InUXyVHJoWpNiGcwRhePlQDELsfYmv,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYFx)
   for InUXyVHJoWpNiGcwRhePlQDELsfYrK in InUXyVHJoWpNiGcwRhePlQDELsfYrb.cookies:
    if InUXyVHJoWpNiGcwRhePlQDELsfYrK.name=='_tving_token':
     InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_token']=InUXyVHJoWpNiGcwRhePlQDELsfYrK.value
    elif InUXyVHJoWpNiGcwRhePlQDELsfYrK.name==InUXyVHJoWpNiGcwRhePlQDELsfYFK.GLOBAL_COOKIENM['tv_cookiekey']:
     InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_cookiekey']=InUXyVHJoWpNiGcwRhePlQDELsfYrK.value
    elif InUXyVHJoWpNiGcwRhePlQDELsfYrK.name==InUXyVHJoWpNiGcwRhePlQDELsfYFK.GLOBAL_COOKIENM['tv_lockkey']:
     InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_lockkey']=InUXyVHJoWpNiGcwRhePlQDELsfYrK.value
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
   InUXyVHJoWpNiGcwRhePlQDELsfYFK.Init_TV_Total()
   return InUXyVHJoWpNiGcwRhePlQDELsfYmx
  return InUXyVHJoWpNiGcwRhePlQDELsfYmt
 def GetDeviceList(InUXyVHJoWpNiGcwRhePlQDELsfYFK):
  InUXyVHJoWpNiGcwRhePlQDELsfYrd=[]
  InUXyVHJoWpNiGcwRhePlQDELsfYrO='-'
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v1/user/device/list'
   InUXyVHJoWpNiGcwRhePlQDELsfYrT=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYra
   InUXyVHJoWpNiGcwRhePlQDELsfYrv={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   InUXyVHJoWpNiGcwRhePlQDELsfYFx=InUXyVHJoWpNiGcwRhePlQDELsfYFK.makeDefaultCookies()
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYrT,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrv,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYFx)
   InUXyVHJoWpNiGcwRhePlQDELsfYrx=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   InUXyVHJoWpNiGcwRhePlQDELsfYrd=InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']
   for InUXyVHJoWpNiGcwRhePlQDELsfYrB in InUXyVHJoWpNiGcwRhePlQDELsfYrd:
    if InUXyVHJoWpNiGcwRhePlQDELsfYrB['model']=='PC' or InUXyVHJoWpNiGcwRhePlQDELsfYrB['model']=='PC-Chrome':
     InUXyVHJoWpNiGcwRhePlQDELsfYrO=InUXyVHJoWpNiGcwRhePlQDELsfYrB['uuid']
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
  return InUXyVHJoWpNiGcwRhePlQDELsfYrO
 def Get_Now_Datetime(InUXyVHJoWpNiGcwRhePlQDELsfYFK):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(InUXyVHJoWpNiGcwRhePlQDELsfYFK,mediacode,sel_quality,stype,pvrmode='-',optUHD=InUXyVHJoWpNiGcwRhePlQDELsfYmx):
  InUXyVHJoWpNiGcwRhePlQDELsfYrq ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','subtitleYn':InUXyVHJoWpNiGcwRhePlQDELsfYmx,'error_msg':'',}
  InUXyVHJoWpNiGcwRhePlQDELsfYrO =InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_uuid'].split('-')[0] 
  InUXyVHJoWpNiGcwRhePlQDELsfYru =InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_uuid'] 
  InUXyVHJoWpNiGcwRhePlQDELsfYrC=InUXyVHJoWpNiGcwRhePlQDELsfYmx 
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYrz=InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetNoCache(1))
   if stype!='tvingtv':
    InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v2/media/stream/info' 
    InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams()
    InUXyVHJoWpNiGcwRhePlQDELsfYrv={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':InUXyVHJoWpNiGcwRhePlQDELsfYru,'deviceInfo':'PC','noCache':InUXyVHJoWpNiGcwRhePlQDELsfYrz,}
    InUXyVHJoWpNiGcwRhePlQDELsfYrj.update(InUXyVHJoWpNiGcwRhePlQDELsfYrv)
    InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYra
    InUXyVHJoWpNiGcwRhePlQDELsfYFx=InUXyVHJoWpNiGcwRhePlQDELsfYFK.makeDefaultCookies()
    InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrj,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYFx)
    if InUXyVHJoWpNiGcwRhePlQDELsfYrb.status_code!=200:
     InUXyVHJoWpNiGcwRhePlQDELsfYrq['error_msg']='First Step - {} error'.format(InUXyVHJoWpNiGcwRhePlQDELsfYrb.status_code)
     return InUXyVHJoWpNiGcwRhePlQDELsfYrq
    InUXyVHJoWpNiGcwRhePlQDELsfYrx=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
    if InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['result']['code']=='060':
     for InUXyVHJoWpNiGcwRhePlQDELsfYgr,InUXyVHJoWpNiGcwRhePlQDELsfYST in InUXyVHJoWpNiGcwRhePlQDELsfYFg.items():
      if InUXyVHJoWpNiGcwRhePlQDELsfYST==sel_quality:
       InUXyVHJoWpNiGcwRhePlQDELsfYgS=InUXyVHJoWpNiGcwRhePlQDELsfYgr
    elif InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['result']['code']!='000':
     InUXyVHJoWpNiGcwRhePlQDELsfYrq['error_msg']=InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['result']['message']
     return InUXyVHJoWpNiGcwRhePlQDELsfYrq
    else: 
     if not('stream' in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']):return InUXyVHJoWpNiGcwRhePlQDELsfYrq
     InUXyVHJoWpNiGcwRhePlQDELsfYgb=[]
     for InUXyVHJoWpNiGcwRhePlQDELsfYgr,InUXyVHJoWpNiGcwRhePlQDELsfYST in InUXyVHJoWpNiGcwRhePlQDELsfYFg.items():
      for InUXyVHJoWpNiGcwRhePlQDELsfYrB in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['stream']['quality']:
       if InUXyVHJoWpNiGcwRhePlQDELsfYrB['active']=='Y' and InUXyVHJoWpNiGcwRhePlQDELsfYrB['code']==InUXyVHJoWpNiGcwRhePlQDELsfYgr:
        InUXyVHJoWpNiGcwRhePlQDELsfYgb.append({InUXyVHJoWpNiGcwRhePlQDELsfYFg.get(InUXyVHJoWpNiGcwRhePlQDELsfYrB['code']):InUXyVHJoWpNiGcwRhePlQDELsfYrB['code']})
     InUXyVHJoWpNiGcwRhePlQDELsfYgS=InUXyVHJoWpNiGcwRhePlQDELsfYFK.CheckQuality(sel_quality,InUXyVHJoWpNiGcwRhePlQDELsfYgb)
     try:
      if optUHD==InUXyVHJoWpNiGcwRhePlQDELsfYmt and InUXyVHJoWpNiGcwRhePlQDELsfYgS=='stream50' and 'stream_support_info' in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['content']['info']:
       if InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['content']['info']['stream_support_info']!=InUXyVHJoWpNiGcwRhePlQDELsfYmv:
        if 'stream70' in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['content']['info']['stream_support_info']:
         InUXyVHJoWpNiGcwRhePlQDELsfYgS='stream70'
         InUXyVHJoWpNiGcwRhePlQDELsfYrC =InUXyVHJoWpNiGcwRhePlQDELsfYmt
     except:
      pass
     try:
      if optUHD==InUXyVHJoWpNiGcwRhePlQDELsfYmt and InUXyVHJoWpNiGcwRhePlQDELsfYgS=='stream50' and 'stream' in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['content']['info']:
       if InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['content']['info']['stream']!=InUXyVHJoWpNiGcwRhePlQDELsfYmv:
        for InUXyVHJoWpNiGcwRhePlQDELsfYrB in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['content']['info']['stream']:
         if InUXyVHJoWpNiGcwRhePlQDELsfYrB['code']=='stream70':
          InUXyVHJoWpNiGcwRhePlQDELsfYgS='stream70'
          InUXyVHJoWpNiGcwRhePlQDELsfYrC =InUXyVHJoWpNiGcwRhePlQDELsfYmt
          break
     except:
      pass
   else:
    InUXyVHJoWpNiGcwRhePlQDELsfYgS='stream40'
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
   InUXyVHJoWpNiGcwRhePlQDELsfYrq['error_msg']='First Step - except error'
   return InUXyVHJoWpNiGcwRhePlQDELsfYrq
  InUXyVHJoWpNiGcwRhePlQDELsfYmd(InUXyVHJoWpNiGcwRhePlQDELsfYgS)
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYrz=InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetNoCache(1))
   InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v2a/media/stream/info'
   if InUXyVHJoWpNiGcwRhePlQDELsfYrC==InUXyVHJoWpNiGcwRhePlQDELsfYmt:
    InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams(uhd=InUXyVHJoWpNiGcwRhePlQDELsfYmt)
    InUXyVHJoWpNiGcwRhePlQDELsfYrv={'mediaCode':mediacode,'noCache':InUXyVHJoWpNiGcwRhePlQDELsfYrz,'streamType':'hls','streamCode':InUXyVHJoWpNiGcwRhePlQDELsfYgS,'deviceId':InUXyVHJoWpNiGcwRhePlQDELsfYrO,'adReq':'none','wm':'Y','ad_device':'','uuid':InUXyVHJoWpNiGcwRhePlQDELsfYru,'deviceInfo':'android_tv',}
   else:
    InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams()
    InUXyVHJoWpNiGcwRhePlQDELsfYrv={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':InUXyVHJoWpNiGcwRhePlQDELsfYgS,'deviceId':InUXyVHJoWpNiGcwRhePlQDELsfYrO,'uuid':InUXyVHJoWpNiGcwRhePlQDELsfYru,'deviceInfo':'PC_Chrome','noCache':InUXyVHJoWpNiGcwRhePlQDELsfYrz,'wm':'Y'}
   InUXyVHJoWpNiGcwRhePlQDELsfYrj.update(InUXyVHJoWpNiGcwRhePlQDELsfYrv)
   InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYra
   InUXyVHJoWpNiGcwRhePlQDELsfYFx=InUXyVHJoWpNiGcwRhePlQDELsfYFK.makeDefaultCookies()
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrj,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYFx,redirects=InUXyVHJoWpNiGcwRhePlQDELsfYmx)
   InUXyVHJoWpNiGcwRhePlQDELsfYrx=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   if InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['result']['code']!='000':
    InUXyVHJoWpNiGcwRhePlQDELsfYrq['error_msg']=InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['result']['message']
    return InUXyVHJoWpNiGcwRhePlQDELsfYrq
   InUXyVHJoWpNiGcwRhePlQDELsfYgK=InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['stream']
   if 'drm_license_assertion' in InUXyVHJoWpNiGcwRhePlQDELsfYgK:
    InUXyVHJoWpNiGcwRhePlQDELsfYrq['drm_license']=InUXyVHJoWpNiGcwRhePlQDELsfYgK['drm_license_assertion']
    if '4k_nondrm_url' in InUXyVHJoWpNiGcwRhePlQDELsfYgK['broadcast']and InUXyVHJoWpNiGcwRhePlQDELsfYrC==InUXyVHJoWpNiGcwRhePlQDELsfYmt:
     InUXyVHJoWpNiGcwRhePlQDELsfYgm =InUXyVHJoWpNiGcwRhePlQDELsfYgK['broadcast']['4k_nondrm_url']
     InUXyVHJoWpNiGcwRhePlQDELsfYrq['drm_license']=''
    else:
     InUXyVHJoWpNiGcwRhePlQDELsfYgm =InUXyVHJoWpNiGcwRhePlQDELsfYgK['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in InUXyVHJoWpNiGcwRhePlQDELsfYgK['broadcast']):return InUXyVHJoWpNiGcwRhePlQDELsfYrq
    InUXyVHJoWpNiGcwRhePlQDELsfYgm=InUXyVHJoWpNiGcwRhePlQDELsfYgK['broadcast']['broad_url']
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
   InUXyVHJoWpNiGcwRhePlQDELsfYrq['error_msg']='Second Step - except error'
   return InUXyVHJoWpNiGcwRhePlQDELsfYrq
  InUXyVHJoWpNiGcwRhePlQDELsfYgA=InUXyVHJoWpNiGcwRhePlQDELsfYrz
  InUXyVHJoWpNiGcwRhePlQDELsfYgm=InUXyVHJoWpNiGcwRhePlQDELsfYgm.split('|')[1]
  InUXyVHJoWpNiGcwRhePlQDELsfYgm,InUXyVHJoWpNiGcwRhePlQDELsfYgk,InUXyVHJoWpNiGcwRhePlQDELsfYga=InUXyVHJoWpNiGcwRhePlQDELsfYFK.Decrypt_Url(InUXyVHJoWpNiGcwRhePlQDELsfYgm,mediacode,InUXyVHJoWpNiGcwRhePlQDELsfYgA)
  InUXyVHJoWpNiGcwRhePlQDELsfYrq['streaming_url']=InUXyVHJoWpNiGcwRhePlQDELsfYgm
  InUXyVHJoWpNiGcwRhePlQDELsfYrq['watermark'] =InUXyVHJoWpNiGcwRhePlQDELsfYgk
  InUXyVHJoWpNiGcwRhePlQDELsfYrq['watermarkKey']=InUXyVHJoWpNiGcwRhePlQDELsfYga
  if 'subtitles' in InUXyVHJoWpNiGcwRhePlQDELsfYgK:
   for InUXyVHJoWpNiGcwRhePlQDELsfYgM in InUXyVHJoWpNiGcwRhePlQDELsfYgK.get('subtitles'):
    if InUXyVHJoWpNiGcwRhePlQDELsfYgM.get('code')in['KO','KO_CC']:
     InUXyVHJoWpNiGcwRhePlQDELsfYrq['subtitleYn']=InUXyVHJoWpNiGcwRhePlQDELsfYmt
     break
  return InUXyVHJoWpNiGcwRhePlQDELsfYrq
 def Tving_Parse_mpd(InUXyVHJoWpNiGcwRhePlQDELsfYFK,stream_url,watermarkKey=InUXyVHJoWpNiGcwRhePlQDELsfYmv,watermark=InUXyVHJoWpNiGcwRhePlQDELsfYmv):
  if watermarkKey not in['',InUXyVHJoWpNiGcwRhePlQDELsfYmv]:
   InUXyVHJoWpNiGcwRhePlQDELsfYgd={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,'Access-Control-Request-Headers':'x-tving-param1,x-tving-param2',}
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=requests.get(url=stream_url,headers=InUXyVHJoWpNiGcwRhePlQDELsfYgd,allow_redirects=InUXyVHJoWpNiGcwRhePlQDELsfYmx)
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYrb.status_code)+' - '+InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYrb.url))
   InUXyVHJoWpNiGcwRhePlQDELsfYmd('')
  else:
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=requests.get(url=stream_url)
  InUXyVHJoWpNiGcwRhePlQDELsfYgO=InUXyVHJoWpNiGcwRhePlQDELsfYrb.content.decode('utf-8')
  InUXyVHJoWpNiGcwRhePlQDELsfYgT=0
  InUXyVHJoWpNiGcwRhePlQDELsfYgv =ET.ElementTree(ET.fromstring(InUXyVHJoWpNiGcwRhePlQDELsfYgO))
  InUXyVHJoWpNiGcwRhePlQDELsfYgx =InUXyVHJoWpNiGcwRhePlQDELsfYgv.getroot()
  InUXyVHJoWpNiGcwRhePlQDELsfYgB=re.match(r'\{.*\}',InUXyVHJoWpNiGcwRhePlQDELsfYgx.tag)[0] 
  InUXyVHJoWpNiGcwRhePlQDELsfYgt=InUXyVHJoWpNiGcwRhePlQDELsfYAF([node for _,node in ET.iterparse(io.StringIO(InUXyVHJoWpNiGcwRhePlQDELsfYgO),events=['start-ns'])])
  for InUXyVHJoWpNiGcwRhePlQDELsfYgr,InUXyVHJoWpNiGcwRhePlQDELsfYSM in InUXyVHJoWpNiGcwRhePlQDELsfYgt.items():
   if InUXyVHJoWpNiGcwRhePlQDELsfYgr!='ns2':
    ET.register_namespace(InUXyVHJoWpNiGcwRhePlQDELsfYgr,InUXyVHJoWpNiGcwRhePlQDELsfYSM)
  InUXyVHJoWpNiGcwRhePlQDELsfYgq=InUXyVHJoWpNiGcwRhePlQDELsfYgx.find(InUXyVHJoWpNiGcwRhePlQDELsfYgB+'Period')
  for InUXyVHJoWpNiGcwRhePlQDELsfYgu in InUXyVHJoWpNiGcwRhePlQDELsfYgq.findall(InUXyVHJoWpNiGcwRhePlQDELsfYgB+'AdaptationSet'):
   if InUXyVHJoWpNiGcwRhePlQDELsfYgu.attrib.get('mimeType')=='video/mp4':
    for InUXyVHJoWpNiGcwRhePlQDELsfYgC in InUXyVHJoWpNiGcwRhePlQDELsfYgu.findall(InUXyVHJoWpNiGcwRhePlQDELsfYgB+'Representation'):
     InUXyVHJoWpNiGcwRhePlQDELsfYgz=InUXyVHJoWpNiGcwRhePlQDELsfYmq(InUXyVHJoWpNiGcwRhePlQDELsfYgC.attrib.get('bandwidth'))
     if InUXyVHJoWpNiGcwRhePlQDELsfYgT<InUXyVHJoWpNiGcwRhePlQDELsfYgz:InUXyVHJoWpNiGcwRhePlQDELsfYgT=InUXyVHJoWpNiGcwRhePlQDELsfYgz
    for InUXyVHJoWpNiGcwRhePlQDELsfYgC in InUXyVHJoWpNiGcwRhePlQDELsfYgu.findall(InUXyVHJoWpNiGcwRhePlQDELsfYgB+'Representation'):
     if InUXyVHJoWpNiGcwRhePlQDELsfYgT>InUXyVHJoWpNiGcwRhePlQDELsfYmq(InUXyVHJoWpNiGcwRhePlQDELsfYgC.attrib.get('bandwidth')):
      InUXyVHJoWpNiGcwRhePlQDELsfYgu.remove(InUXyVHJoWpNiGcwRhePlQDELsfYgC)
   else:
    continue
  InUXyVHJoWpNiGcwRhePlQDELsfYgj=ET.tostring(InUXyVHJoWpNiGcwRhePlQDELsfYgx).decode('utf-8')
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TextFile_Save(InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV_STREAM_FILENAME,InUXyVHJoWpNiGcwRhePlQDELsfYgj)
  return InUXyVHJoWpNiGcwRhePlQDELsfYmt
 def Tving_Parse_m3u8(InUXyVHJoWpNiGcwRhePlQDELsfYFK,stream_url):
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=requests.get(url=stream_url,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,stream=InUXyVHJoWpNiGcwRhePlQDELsfYmt)
   InUXyVHJoWpNiGcwRhePlQDELsfYSF=InUXyVHJoWpNiGcwRhePlQDELsfYrb.content.decode('utf-8')
   if '#EXTM3U' not in InUXyVHJoWpNiGcwRhePlQDELsfYSF:
    return InUXyVHJoWpNiGcwRhePlQDELsfYmx
   if '#EXT-X-STREAM-INF' not in InUXyVHJoWpNiGcwRhePlQDELsfYSF: 
    return InUXyVHJoWpNiGcwRhePlQDELsfYmx
   InUXyVHJoWpNiGcwRhePlQDELsfYSr=0
   for InUXyVHJoWpNiGcwRhePlQDELsfYSg in InUXyVHJoWpNiGcwRhePlQDELsfYSF.splitlines():
    if InUXyVHJoWpNiGcwRhePlQDELsfYSg.startswith('#EXT-X-STREAM-INF'):
     InUXyVHJoWpNiGcwRhePlQDELsfYSb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.MediaLine_Parse(InUXyVHJoWpNiGcwRhePlQDELsfYSg,'#EXT-X-STREAM-INF')
     if InUXyVHJoWpNiGcwRhePlQDELsfYSr<InUXyVHJoWpNiGcwRhePlQDELsfYmq(InUXyVHJoWpNiGcwRhePlQDELsfYSb.get('BANDWIDTH')):
      InUXyVHJoWpNiGcwRhePlQDELsfYSr=InUXyVHJoWpNiGcwRhePlQDELsfYmq(InUXyVHJoWpNiGcwRhePlQDELsfYSb.get('BANDWIDTH'))
   InUXyVHJoWpNiGcwRhePlQDELsfYSK=[]
   InUXyVHJoWpNiGcwRhePlQDELsfYSm=InUXyVHJoWpNiGcwRhePlQDELsfYmx
   for InUXyVHJoWpNiGcwRhePlQDELsfYSg in InUXyVHJoWpNiGcwRhePlQDELsfYSF.splitlines():
    if InUXyVHJoWpNiGcwRhePlQDELsfYSm==InUXyVHJoWpNiGcwRhePlQDELsfYmt:
     InUXyVHJoWpNiGcwRhePlQDELsfYSm=InUXyVHJoWpNiGcwRhePlQDELsfYmx
     continue
    if InUXyVHJoWpNiGcwRhePlQDELsfYSg.startswith('#EXT-X-STREAM-INF'):
     InUXyVHJoWpNiGcwRhePlQDELsfYSb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.MediaLine_Parse(InUXyVHJoWpNiGcwRhePlQDELsfYSg,'#EXT-X-STREAM-INF')
     if InUXyVHJoWpNiGcwRhePlQDELsfYSr!=InUXyVHJoWpNiGcwRhePlQDELsfYmq(InUXyVHJoWpNiGcwRhePlQDELsfYSb.get('BANDWIDTH')):
      InUXyVHJoWpNiGcwRhePlQDELsfYSm=InUXyVHJoWpNiGcwRhePlQDELsfYmt
      continue
    InUXyVHJoWpNiGcwRhePlQDELsfYSK.append(InUXyVHJoWpNiGcwRhePlQDELsfYSg)
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
   return InUXyVHJoWpNiGcwRhePlQDELsfYmx
  InUXyVHJoWpNiGcwRhePlQDELsfYSA='\n'.join(InUXyVHJoWpNiGcwRhePlQDELsfYSK)
  InUXyVHJoWpNiGcwRhePlQDELsfYFK.TextFile_Save(InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV_STREAM_FILENAME,InUXyVHJoWpNiGcwRhePlQDELsfYSA)
  return InUXyVHJoWpNiGcwRhePlQDELsfYmt
 def MediaLine_Parse(InUXyVHJoWpNiGcwRhePlQDELsfYFK,InUXyVHJoWpNiGcwRhePlQDELsfYSg,prefix):
  InUXyVHJoWpNiGcwRhePlQDELsfYSb={}
  for InUXyVHJoWpNiGcwRhePlQDELsfYSk in InUXyVHJoWpNiGcwRhePlQDELsfYFb.split(InUXyVHJoWpNiGcwRhePlQDELsfYSg.replace(prefix+':',''))[1::2]:
   InUXyVHJoWpNiGcwRhePlQDELsfYSa,InUXyVHJoWpNiGcwRhePlQDELsfYSM=InUXyVHJoWpNiGcwRhePlQDELsfYSk.split('=',1)
   InUXyVHJoWpNiGcwRhePlQDELsfYSb[InUXyVHJoWpNiGcwRhePlQDELsfYSa.upper()]=InUXyVHJoWpNiGcwRhePlQDELsfYSM.replace('"','').strip()
  return InUXyVHJoWpNiGcwRhePlQDELsfYSb
 def CheckQuality(InUXyVHJoWpNiGcwRhePlQDELsfYFK,sel_qt,InUXyVHJoWpNiGcwRhePlQDELsfYgb):
  for InUXyVHJoWpNiGcwRhePlQDELsfYSd in InUXyVHJoWpNiGcwRhePlQDELsfYgb:
   if sel_qt>=InUXyVHJoWpNiGcwRhePlQDELsfYAr(InUXyVHJoWpNiGcwRhePlQDELsfYSd)[0]:return InUXyVHJoWpNiGcwRhePlQDELsfYSd.get(InUXyVHJoWpNiGcwRhePlQDELsfYAr(InUXyVHJoWpNiGcwRhePlQDELsfYSd)[0])
   InUXyVHJoWpNiGcwRhePlQDELsfYSO=InUXyVHJoWpNiGcwRhePlQDELsfYSd.get(InUXyVHJoWpNiGcwRhePlQDELsfYAr(InUXyVHJoWpNiGcwRhePlQDELsfYSd)[0])
  return InUXyVHJoWpNiGcwRhePlQDELsfYSO
 def makeOocUrl(InUXyVHJoWpNiGcwRhePlQDELsfYFK,ooc_params):
  InUXyVHJoWpNiGcwRhePlQDELsfYgF=''
  for InUXyVHJoWpNiGcwRhePlQDELsfYgr,InUXyVHJoWpNiGcwRhePlQDELsfYST in ooc_params.items():
   InUXyVHJoWpNiGcwRhePlQDELsfYgF+="%s=%s^"%(InUXyVHJoWpNiGcwRhePlQDELsfYgr,InUXyVHJoWpNiGcwRhePlQDELsfYST)
  return InUXyVHJoWpNiGcwRhePlQDELsfYgF
 def GetLiveChannelList(InUXyVHJoWpNiGcwRhePlQDELsfYFK,stype,page_int):
  InUXyVHJoWpNiGcwRhePlQDELsfYrd=[]
  InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmx
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v2/media/lives'
   if stype=='onair': 
    InUXyVHJoWpNiGcwRhePlQDELsfYSx='CPCS0100,CPCS0400'
   else:
    InUXyVHJoWpNiGcwRhePlQDELsfYSx='CPCS0300'
   InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams()
   InUXyVHJoWpNiGcwRhePlQDELsfYrv={'cacheType':'main','pageNo':InUXyVHJoWpNiGcwRhePlQDELsfYmj(page_int),'pageSize':InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYFK.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':InUXyVHJoWpNiGcwRhePlQDELsfYSx,}
   InUXyVHJoWpNiGcwRhePlQDELsfYrj.update(InUXyVHJoWpNiGcwRhePlQDELsfYrv)
   InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYra
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrj,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv)
   InUXyVHJoWpNiGcwRhePlQDELsfYrx=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   if not('result' in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']):return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
   InUXyVHJoWpNiGcwRhePlQDELsfYSB=InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['result']
   for InUXyVHJoWpNiGcwRhePlQDELsfYrB in InUXyVHJoWpNiGcwRhePlQDELsfYSB:
    InUXyVHJoWpNiGcwRhePlQDELsfYSt=InUXyVHJoWpNiGcwRhePlQDELsfYSC=InUXyVHJoWpNiGcwRhePlQDELsfYSz=''
    InUXyVHJoWpNiGcwRhePlQDELsfYSq=InUXyVHJoWpNiGcwRhePlQDELsfYbB=''
    InUXyVHJoWpNiGcwRhePlQDELsfYSu=InUXyVHJoWpNiGcwRhePlQDELsfYrB['live_code']
    InUXyVHJoWpNiGcwRhePlQDELsfYSt =InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['channel']['name']['ko']
    if InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['episode']!=InUXyVHJoWpNiGcwRhePlQDELsfYmv:
     InUXyVHJoWpNiGcwRhePlQDELsfYSC =InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['program']['name']['ko']
     InUXyVHJoWpNiGcwRhePlQDELsfYSC =InUXyVHJoWpNiGcwRhePlQDELsfYSC+', '+InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['episode']['frequency'])+'회'
     InUXyVHJoWpNiGcwRhePlQDELsfYSz=InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['episode']['synopsis']['ko']
    else:
     InUXyVHJoWpNiGcwRhePlQDELsfYSC =InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['program']['name']['ko']
     InUXyVHJoWpNiGcwRhePlQDELsfYSz=InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['program']['synopsis']['ko']
    try: 
     InUXyVHJoWpNiGcwRhePlQDELsfYSj =''
     InUXyVHJoWpNiGcwRhePlQDELsfYbF =''
     InUXyVHJoWpNiGcwRhePlQDELsfYbr=''
     InUXyVHJoWpNiGcwRhePlQDELsfYbg =''
     InUXyVHJoWpNiGcwRhePlQDELsfYbS =''
     InUXyVHJoWpNiGcwRhePlQDELsfYbK =''
     for InUXyVHJoWpNiGcwRhePlQDELsfYbm in InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['program']['image']:
      if InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP0900':InUXyVHJoWpNiGcwRhePlQDELsfYbF =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
      elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP1800':InUXyVHJoWpNiGcwRhePlQDELsfYbr=InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
      elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP2000':InUXyVHJoWpNiGcwRhePlQDELsfYbg =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
      elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP1900':InUXyVHJoWpNiGcwRhePlQDELsfYbS =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
      elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP0200':InUXyVHJoWpNiGcwRhePlQDELsfYbK =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
      elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP0500':InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
      elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP0800':InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     if InUXyVHJoWpNiGcwRhePlQDELsfYSj=='':
      for InUXyVHJoWpNiGcwRhePlQDELsfYbm in InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['channel']['image']:
       if InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIC0400':InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
       elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIC1400':InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
       elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIC1900':InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
    except:
     InUXyVHJoWpNiGcwRhePlQDELsfYmv
    try:
     InUXyVHJoWpNiGcwRhePlQDELsfYbA =[]
     InUXyVHJoWpNiGcwRhePlQDELsfYbk=[]
     InUXyVHJoWpNiGcwRhePlQDELsfYba =[]
     InUXyVHJoWpNiGcwRhePlQDELsfYbM=''
     InUXyVHJoWpNiGcwRhePlQDELsfYbd=''
     InUXyVHJoWpNiGcwRhePlQDELsfYbO=''
     for InUXyVHJoWpNiGcwRhePlQDELsfYbT in InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('schedule').get('program').get('actor'):
      if InUXyVHJoWpNiGcwRhePlQDELsfYbT!='' and InUXyVHJoWpNiGcwRhePlQDELsfYbT!=u'없음':InUXyVHJoWpNiGcwRhePlQDELsfYbA.append(InUXyVHJoWpNiGcwRhePlQDELsfYbT)
     for InUXyVHJoWpNiGcwRhePlQDELsfYbv in InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('schedule').get('program').get('director'):
      if InUXyVHJoWpNiGcwRhePlQDELsfYbv!='' and InUXyVHJoWpNiGcwRhePlQDELsfYbv!='-' and InUXyVHJoWpNiGcwRhePlQDELsfYbv!=u'없음':InUXyVHJoWpNiGcwRhePlQDELsfYbk.append(InUXyVHJoWpNiGcwRhePlQDELsfYbv)
     if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('schedule').get('program').get('category1_name').get('ko')!='':
      InUXyVHJoWpNiGcwRhePlQDELsfYba.append(InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['program']['category1_name']['ko'])
     if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('schedule').get('program').get('category2_name').get('ko')!='':
      InUXyVHJoWpNiGcwRhePlQDELsfYba.append(InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['program']['category2_name']['ko'])
     if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('schedule').get('program').get('product_year'):InUXyVHJoWpNiGcwRhePlQDELsfYbM=InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['program']['product_year']
     if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('schedule').get('program').get('grade_code') :InUXyVHJoWpNiGcwRhePlQDELsfYbd= InUXyVHJoWpNiGcwRhePlQDELsfYFS.get(InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['program']['grade_code'])
     if 'broad_dt' in InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('schedule').get('program'):
      InUXyVHJoWpNiGcwRhePlQDELsfYbx =InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('schedule').get('program').get('broad_dt')
      InUXyVHJoWpNiGcwRhePlQDELsfYbO='%s-%s-%s'%(InUXyVHJoWpNiGcwRhePlQDELsfYbx[:4],InUXyVHJoWpNiGcwRhePlQDELsfYbx[4:6],InUXyVHJoWpNiGcwRhePlQDELsfYbx[6:])
    except:
     InUXyVHJoWpNiGcwRhePlQDELsfYmv
    InUXyVHJoWpNiGcwRhePlQDELsfYSq=InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['broadcast_start_time'])[8:12]
    InUXyVHJoWpNiGcwRhePlQDELsfYbB =InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYrB['schedule']['broadcast_end_time'])[8:12]
    InUXyVHJoWpNiGcwRhePlQDELsfYbt={'channel':InUXyVHJoWpNiGcwRhePlQDELsfYSt,'title':InUXyVHJoWpNiGcwRhePlQDELsfYSC,'mediacode':InUXyVHJoWpNiGcwRhePlQDELsfYSu,'thumbnail':{'poster':InUXyVHJoWpNiGcwRhePlQDELsfYbF,'thumb':InUXyVHJoWpNiGcwRhePlQDELsfYSj,'clearlogo':InUXyVHJoWpNiGcwRhePlQDELsfYbr,'icon':InUXyVHJoWpNiGcwRhePlQDELsfYbg,'fanart':InUXyVHJoWpNiGcwRhePlQDELsfYbK},'synopsis':InUXyVHJoWpNiGcwRhePlQDELsfYSz,'channelepg':' [%s:%s ~ %s:%s]'%(InUXyVHJoWpNiGcwRhePlQDELsfYSq[0:2],InUXyVHJoWpNiGcwRhePlQDELsfYSq[2:],InUXyVHJoWpNiGcwRhePlQDELsfYbB[0:2],InUXyVHJoWpNiGcwRhePlQDELsfYbB[2:]),'cast':InUXyVHJoWpNiGcwRhePlQDELsfYbA,'director':InUXyVHJoWpNiGcwRhePlQDELsfYbk,'info_genre':InUXyVHJoWpNiGcwRhePlQDELsfYba,'year':InUXyVHJoWpNiGcwRhePlQDELsfYbM,'mpaa':InUXyVHJoWpNiGcwRhePlQDELsfYbd,'premiered':InUXyVHJoWpNiGcwRhePlQDELsfYbO}
    InUXyVHJoWpNiGcwRhePlQDELsfYrd.append(InUXyVHJoWpNiGcwRhePlQDELsfYbt)
   if InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['has_more']=='Y':
    InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmt
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
  return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
 def GetProgramList(InUXyVHJoWpNiGcwRhePlQDELsfYFK,genre,orderby,page_int,genreCode='all'):
  InUXyVHJoWpNiGcwRhePlQDELsfYrd=[]
  InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmx
  try:
   if genre=='PARAMOUNT':
    InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v2/media/paramount/episodes'
   else:
    InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v2/media/episodes'
   InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams()
   InUXyVHJoWpNiGcwRhePlQDELsfYrv={'cacheType':'main','pageSize':InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYFK.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':InUXyVHJoWpNiGcwRhePlQDELsfYmj(page_int),}
   if genre not in['all','PARAMOUNT']:InUXyVHJoWpNiGcwRhePlQDELsfYrv['categoryCode']=genre
   if genreCode!='all' :InUXyVHJoWpNiGcwRhePlQDELsfYrv['genreCode'] =genreCode 
   InUXyVHJoWpNiGcwRhePlQDELsfYrj.update(InUXyVHJoWpNiGcwRhePlQDELsfYrv)
   InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYra
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrj,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv)
   InUXyVHJoWpNiGcwRhePlQDELsfYrx=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   if not('result' in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']):return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
   InUXyVHJoWpNiGcwRhePlQDELsfYSB=InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['result']
   for InUXyVHJoWpNiGcwRhePlQDELsfYrB in InUXyVHJoWpNiGcwRhePlQDELsfYSB:
    InUXyVHJoWpNiGcwRhePlQDELsfYbq=InUXyVHJoWpNiGcwRhePlQDELsfYrB['program']['code']
    InUXyVHJoWpNiGcwRhePlQDELsfYSC =InUXyVHJoWpNiGcwRhePlQDELsfYrB['program']['name']['ko']
    InUXyVHJoWpNiGcwRhePlQDELsfYbd =InUXyVHJoWpNiGcwRhePlQDELsfYFS.get(InUXyVHJoWpNiGcwRhePlQDELsfYrB['program'].get('grade_code'))
    InUXyVHJoWpNiGcwRhePlQDELsfYbF =''
    InUXyVHJoWpNiGcwRhePlQDELsfYSj =''
    InUXyVHJoWpNiGcwRhePlQDELsfYbr=''
    InUXyVHJoWpNiGcwRhePlQDELsfYbg =''
    InUXyVHJoWpNiGcwRhePlQDELsfYbS =''
    for InUXyVHJoWpNiGcwRhePlQDELsfYbm in InUXyVHJoWpNiGcwRhePlQDELsfYrB['program']['image']:
     if InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP0900':InUXyVHJoWpNiGcwRhePlQDELsfYbF =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP0200':InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP1800':InUXyVHJoWpNiGcwRhePlQDELsfYbr=InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP2000':InUXyVHJoWpNiGcwRhePlQDELsfYbg =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP1900':InUXyVHJoWpNiGcwRhePlQDELsfYbS =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
    InUXyVHJoWpNiGcwRhePlQDELsfYSz =InUXyVHJoWpNiGcwRhePlQDELsfYrB['program']['synopsis']['ko']
    try:
     InUXyVHJoWpNiGcwRhePlQDELsfYbu=InUXyVHJoWpNiGcwRhePlQDELsfYrB['channel']['name']['ko']
    except:
     InUXyVHJoWpNiGcwRhePlQDELsfYbu=''
    try:
     InUXyVHJoWpNiGcwRhePlQDELsfYbA =[]
     InUXyVHJoWpNiGcwRhePlQDELsfYbk=[]
     InUXyVHJoWpNiGcwRhePlQDELsfYba =[]
     InUXyVHJoWpNiGcwRhePlQDELsfYbM =''
     InUXyVHJoWpNiGcwRhePlQDELsfYbO=''
     for InUXyVHJoWpNiGcwRhePlQDELsfYbT in InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('program').get('actor'):
      if InUXyVHJoWpNiGcwRhePlQDELsfYbT!='' and InUXyVHJoWpNiGcwRhePlQDELsfYbT!='-' and InUXyVHJoWpNiGcwRhePlQDELsfYbT!=u'없음':InUXyVHJoWpNiGcwRhePlQDELsfYbA.append(InUXyVHJoWpNiGcwRhePlQDELsfYbT)
     for InUXyVHJoWpNiGcwRhePlQDELsfYbv in InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('program').get('director'):
      if InUXyVHJoWpNiGcwRhePlQDELsfYbv!='' and InUXyVHJoWpNiGcwRhePlQDELsfYbv!='-' and InUXyVHJoWpNiGcwRhePlQDELsfYbv!=u'없음':InUXyVHJoWpNiGcwRhePlQDELsfYbk.append(InUXyVHJoWpNiGcwRhePlQDELsfYbv)
     if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('program').get('category1_name').get('ko')!='':
      InUXyVHJoWpNiGcwRhePlQDELsfYba.append(InUXyVHJoWpNiGcwRhePlQDELsfYrB['program']['category1_name']['ko'])
     if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('program').get('category2_name').get('ko')!='':
      InUXyVHJoWpNiGcwRhePlQDELsfYba.append(InUXyVHJoWpNiGcwRhePlQDELsfYrB['program']['category2_name']['ko'])
     if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('program').get('product_year'):InUXyVHJoWpNiGcwRhePlQDELsfYbM=InUXyVHJoWpNiGcwRhePlQDELsfYrB['program']['product_year']
     if 'broad_dt' in InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('program'):
      InUXyVHJoWpNiGcwRhePlQDELsfYbx =InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('program').get('broad_dt')
      InUXyVHJoWpNiGcwRhePlQDELsfYbO='%s-%s-%s'%(InUXyVHJoWpNiGcwRhePlQDELsfYbx[:4],InUXyVHJoWpNiGcwRhePlQDELsfYbx[4:6],InUXyVHJoWpNiGcwRhePlQDELsfYbx[6:])
    except:
     InUXyVHJoWpNiGcwRhePlQDELsfYmv
    InUXyVHJoWpNiGcwRhePlQDELsfYbt={'program':InUXyVHJoWpNiGcwRhePlQDELsfYbq,'title':InUXyVHJoWpNiGcwRhePlQDELsfYSC,'thumbnail':{'poster':InUXyVHJoWpNiGcwRhePlQDELsfYbF,'thumb':InUXyVHJoWpNiGcwRhePlQDELsfYSj,'clearlogo':InUXyVHJoWpNiGcwRhePlQDELsfYbr,'icon':InUXyVHJoWpNiGcwRhePlQDELsfYbg,'banner':InUXyVHJoWpNiGcwRhePlQDELsfYbS,'fanart':InUXyVHJoWpNiGcwRhePlQDELsfYSj},'synopsis':InUXyVHJoWpNiGcwRhePlQDELsfYSz,'channel':InUXyVHJoWpNiGcwRhePlQDELsfYbu,'cast':InUXyVHJoWpNiGcwRhePlQDELsfYbA,'director':InUXyVHJoWpNiGcwRhePlQDELsfYbk,'info_genre':InUXyVHJoWpNiGcwRhePlQDELsfYba,'year':InUXyVHJoWpNiGcwRhePlQDELsfYbM,'premiered':InUXyVHJoWpNiGcwRhePlQDELsfYbO,'mpaa':InUXyVHJoWpNiGcwRhePlQDELsfYbd}
    InUXyVHJoWpNiGcwRhePlQDELsfYrd.append(InUXyVHJoWpNiGcwRhePlQDELsfYbt)
   if InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['has_more']=='Y':InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmt
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
  return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
 def Get_UHD_ProgramList(InUXyVHJoWpNiGcwRhePlQDELsfYFK,page_int):
  InUXyVHJoWpNiGcwRhePlQDELsfYrd=[]
  InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmx
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v2/operator/highlights'
   InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams(uhd=InUXyVHJoWpNiGcwRhePlQDELsfYmt)
   InUXyVHJoWpNiGcwRhePlQDELsfYrv={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':InUXyVHJoWpNiGcwRhePlQDELsfYmj(page_int),'pocType':'APP_X_TVING_4.0.0',}
   InUXyVHJoWpNiGcwRhePlQDELsfYrj.update(InUXyVHJoWpNiGcwRhePlQDELsfYrv)
   InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYra
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrj,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv)
   InUXyVHJoWpNiGcwRhePlQDELsfYrx=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   if not('result' in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']):return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
   InUXyVHJoWpNiGcwRhePlQDELsfYSB=InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['result']
   for InUXyVHJoWpNiGcwRhePlQDELsfYrB in InUXyVHJoWpNiGcwRhePlQDELsfYSB:
    InUXyVHJoWpNiGcwRhePlQDELsfYbC=InUXyVHJoWpNiGcwRhePlQDELsfYrB['content']['program']
    InUXyVHJoWpNiGcwRhePlQDELsfYbz =InUXyVHJoWpNiGcwRhePlQDELsfYbC['code']
    InUXyVHJoWpNiGcwRhePlQDELsfYSC =InUXyVHJoWpNiGcwRhePlQDELsfYbC['name']['ko'].strip()
    InUXyVHJoWpNiGcwRhePlQDELsfYbd =InUXyVHJoWpNiGcwRhePlQDELsfYFS.get(InUXyVHJoWpNiGcwRhePlQDELsfYbC.get('grade_code'))
    InUXyVHJoWpNiGcwRhePlQDELsfYSz =InUXyVHJoWpNiGcwRhePlQDELsfYbC['synopsis']['ko']
    InUXyVHJoWpNiGcwRhePlQDELsfYbu =InUXyVHJoWpNiGcwRhePlQDELsfYrB['content']['channel']['name']['ko']
    InUXyVHJoWpNiGcwRhePlQDELsfYbM =InUXyVHJoWpNiGcwRhePlQDELsfYbC['product_year']
    InUXyVHJoWpNiGcwRhePlQDELsfYbF =''
    InUXyVHJoWpNiGcwRhePlQDELsfYSj =''
    InUXyVHJoWpNiGcwRhePlQDELsfYbr=''
    InUXyVHJoWpNiGcwRhePlQDELsfYbg =''
    InUXyVHJoWpNiGcwRhePlQDELsfYbS =''
    for InUXyVHJoWpNiGcwRhePlQDELsfYbm in InUXyVHJoWpNiGcwRhePlQDELsfYbC['image']:
     if InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP0900':InUXyVHJoWpNiGcwRhePlQDELsfYbF =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP0200':InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP1800':InUXyVHJoWpNiGcwRhePlQDELsfYbr=InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP2000':InUXyVHJoWpNiGcwRhePlQDELsfYbg =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP1900':InUXyVHJoWpNiGcwRhePlQDELsfYbS =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
    InUXyVHJoWpNiGcwRhePlQDELsfYba =[]
    InUXyVHJoWpNiGcwRhePlQDELsfYbA =[]
    InUXyVHJoWpNiGcwRhePlQDELsfYbk=[]
    InUXyVHJoWpNiGcwRhePlQDELsfYbO =''
    if InUXyVHJoWpNiGcwRhePlQDELsfYbC.get('category1_name').get('ko')!='':
     InUXyVHJoWpNiGcwRhePlQDELsfYba.append(InUXyVHJoWpNiGcwRhePlQDELsfYbC['category1_name']['ko'])
    if InUXyVHJoWpNiGcwRhePlQDELsfYbC.get('category2_name').get('ko')!='':
     InUXyVHJoWpNiGcwRhePlQDELsfYba.append(InUXyVHJoWpNiGcwRhePlQDELsfYbC['category2_name']['ko'])
    for InUXyVHJoWpNiGcwRhePlQDELsfYbT in InUXyVHJoWpNiGcwRhePlQDELsfYbC.get('actor'):
     if InUXyVHJoWpNiGcwRhePlQDELsfYbT!='' and InUXyVHJoWpNiGcwRhePlQDELsfYbT!='-' and InUXyVHJoWpNiGcwRhePlQDELsfYbT!=u'없음':InUXyVHJoWpNiGcwRhePlQDELsfYbA.append(InUXyVHJoWpNiGcwRhePlQDELsfYbT)
    for InUXyVHJoWpNiGcwRhePlQDELsfYbv in InUXyVHJoWpNiGcwRhePlQDELsfYbC.get('director'):
     if InUXyVHJoWpNiGcwRhePlQDELsfYbv!='' and InUXyVHJoWpNiGcwRhePlQDELsfYbv!='-' and InUXyVHJoWpNiGcwRhePlQDELsfYbv!=u'없음':InUXyVHJoWpNiGcwRhePlQDELsfYbk.append(InUXyVHJoWpNiGcwRhePlQDELsfYbv)
    if InUXyVHJoWpNiGcwRhePlQDELsfYbC.get('broad_dt')not in[InUXyVHJoWpNiGcwRhePlQDELsfYmv,'']:
     InUXyVHJoWpNiGcwRhePlQDELsfYbx =InUXyVHJoWpNiGcwRhePlQDELsfYbC.get('broad_dt')
     InUXyVHJoWpNiGcwRhePlQDELsfYbO='%s-%s-%s'%(InUXyVHJoWpNiGcwRhePlQDELsfYbx[:4],InUXyVHJoWpNiGcwRhePlQDELsfYbx[4:6],InUXyVHJoWpNiGcwRhePlQDELsfYbx[6:])
    InUXyVHJoWpNiGcwRhePlQDELsfYbt={'program':InUXyVHJoWpNiGcwRhePlQDELsfYbz,'title':InUXyVHJoWpNiGcwRhePlQDELsfYSC,'mpaa':InUXyVHJoWpNiGcwRhePlQDELsfYbd,'thumbnail':{'poster':InUXyVHJoWpNiGcwRhePlQDELsfYbF,'thumb':InUXyVHJoWpNiGcwRhePlQDELsfYSj,'clearlogo':InUXyVHJoWpNiGcwRhePlQDELsfYbr,'icon':InUXyVHJoWpNiGcwRhePlQDELsfYbg,'banner':InUXyVHJoWpNiGcwRhePlQDELsfYbS,'fanart':InUXyVHJoWpNiGcwRhePlQDELsfYSj},'channel':InUXyVHJoWpNiGcwRhePlQDELsfYbu,'synopsis':InUXyVHJoWpNiGcwRhePlQDELsfYSz,'year':InUXyVHJoWpNiGcwRhePlQDELsfYbM,'info_genre':InUXyVHJoWpNiGcwRhePlQDELsfYba,'cast':InUXyVHJoWpNiGcwRhePlQDELsfYbA,'director':InUXyVHJoWpNiGcwRhePlQDELsfYbk,'premiered':InUXyVHJoWpNiGcwRhePlQDELsfYbO,}
    InUXyVHJoWpNiGcwRhePlQDELsfYrd.append(InUXyVHJoWpNiGcwRhePlQDELsfYbt)
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
  return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
 def Get_Origianl_ProgramList(InUXyVHJoWpNiGcwRhePlQDELsfYFK,page_int):
  InUXyVHJoWpNiGcwRhePlQDELsfYrd=[]
  InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmx
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v2/media/band/originals'
   InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams()
   InUXyVHJoWpNiGcwRhePlQDELsfYrv={'pageSize':InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYFK.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':InUXyVHJoWpNiGcwRhePlQDELsfYmj(page_int),}
   InUXyVHJoWpNiGcwRhePlQDELsfYrj.update(InUXyVHJoWpNiGcwRhePlQDELsfYrv)
   InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYra
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrj,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv)
   InUXyVHJoWpNiGcwRhePlQDELsfYrx=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   if not('contents' in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']):return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
   InUXyVHJoWpNiGcwRhePlQDELsfYSB=InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['contents']
   for InUXyVHJoWpNiGcwRhePlQDELsfYrB in InUXyVHJoWpNiGcwRhePlQDELsfYSB:
    InUXyVHJoWpNiGcwRhePlQDELsfYbq=InUXyVHJoWpNiGcwRhePlQDELsfYrB['vod_code']
    InUXyVHJoWpNiGcwRhePlQDELsfYSC =InUXyVHJoWpNiGcwRhePlQDELsfYrB['vod_name']
    InUXyVHJoWpNiGcwRhePlQDELsfYbF =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYrB['image']
    InUXyVHJoWpNiGcwRhePlQDELsfYbt={'program':InUXyVHJoWpNiGcwRhePlQDELsfYbq,'title':InUXyVHJoWpNiGcwRhePlQDELsfYSC,'thumbnail':{'poster':InUXyVHJoWpNiGcwRhePlQDELsfYbF,'thumb':InUXyVHJoWpNiGcwRhePlQDELsfYbF}}
    InUXyVHJoWpNiGcwRhePlQDELsfYrd.append(InUXyVHJoWpNiGcwRhePlQDELsfYbt)
   if InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['has_more']=='Y':InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmt
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
  return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
 def GetEpisodeList(InUXyVHJoWpNiGcwRhePlQDELsfYFK,program_code,page_int,orderby='desc'):
  InUXyVHJoWpNiGcwRhePlQDELsfYrd=[]
  InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmx
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v2/media/frequency/program/'+program_code
   InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams()
   InUXyVHJoWpNiGcwRhePlQDELsfYrv={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   InUXyVHJoWpNiGcwRhePlQDELsfYrj.update(InUXyVHJoWpNiGcwRhePlQDELsfYrv)
   InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYra
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrj,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv)
   InUXyVHJoWpNiGcwRhePlQDELsfYrx=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   if not('result' in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']):return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
   InUXyVHJoWpNiGcwRhePlQDELsfYSB=InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['result']
   InUXyVHJoWpNiGcwRhePlQDELsfYbj=InUXyVHJoWpNiGcwRhePlQDELsfYmq(InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['total_count'])
   InUXyVHJoWpNiGcwRhePlQDELsfYKF =InUXyVHJoWpNiGcwRhePlQDELsfYmq(InUXyVHJoWpNiGcwRhePlQDELsfYbj//(InUXyVHJoWpNiGcwRhePlQDELsfYFK.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    InUXyVHJoWpNiGcwRhePlQDELsfYKr =(InUXyVHJoWpNiGcwRhePlQDELsfYbj-1)-((page_int-1)*InUXyVHJoWpNiGcwRhePlQDELsfYFK.EPISODE_LIMIT)
   else:
    InUXyVHJoWpNiGcwRhePlQDELsfYKr =(page_int-1)*InUXyVHJoWpNiGcwRhePlQDELsfYFK.EPISODE_LIMIT
   for i in InUXyVHJoWpNiGcwRhePlQDELsfYmu(InUXyVHJoWpNiGcwRhePlQDELsfYFK.EPISODE_LIMIT):
    if orderby=='desc':
     InUXyVHJoWpNiGcwRhePlQDELsfYKg=InUXyVHJoWpNiGcwRhePlQDELsfYKr-i
     if InUXyVHJoWpNiGcwRhePlQDELsfYKg<0:break
    else:
     InUXyVHJoWpNiGcwRhePlQDELsfYKg=InUXyVHJoWpNiGcwRhePlQDELsfYKr+i
     if InUXyVHJoWpNiGcwRhePlQDELsfYKg>=InUXyVHJoWpNiGcwRhePlQDELsfYbj:break
    InUXyVHJoWpNiGcwRhePlQDELsfYKS=InUXyVHJoWpNiGcwRhePlQDELsfYSB[InUXyVHJoWpNiGcwRhePlQDELsfYKg]['episode']['code']
    InUXyVHJoWpNiGcwRhePlQDELsfYSC =InUXyVHJoWpNiGcwRhePlQDELsfYSB[InUXyVHJoWpNiGcwRhePlQDELsfYKg]['vod_name']['ko']
    InUXyVHJoWpNiGcwRhePlQDELsfYKb =''
    try:
     InUXyVHJoWpNiGcwRhePlQDELsfYbx=InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYSB[InUXyVHJoWpNiGcwRhePlQDELsfYKg]['episode']['broadcast_date'])
     InUXyVHJoWpNiGcwRhePlQDELsfYKb='%s-%s-%s'%(InUXyVHJoWpNiGcwRhePlQDELsfYbx[:4],InUXyVHJoWpNiGcwRhePlQDELsfYbx[4:6],InUXyVHJoWpNiGcwRhePlQDELsfYbx[6:])
    except:
     InUXyVHJoWpNiGcwRhePlQDELsfYmv
    try:
     if InUXyVHJoWpNiGcwRhePlQDELsfYSB[InUXyVHJoWpNiGcwRhePlQDELsfYKg]['episode']['pip_cliptype']=='C012':
      InUXyVHJoWpNiGcwRhePlQDELsfYKb+=' - Quick VOD'
    except:
     InUXyVHJoWpNiGcwRhePlQDELsfYmv
    InUXyVHJoWpNiGcwRhePlQDELsfYSz =InUXyVHJoWpNiGcwRhePlQDELsfYSB[InUXyVHJoWpNiGcwRhePlQDELsfYKg]['episode']['synopsis']['ko']
    InUXyVHJoWpNiGcwRhePlQDELsfYbF =''
    InUXyVHJoWpNiGcwRhePlQDELsfYSj =''
    InUXyVHJoWpNiGcwRhePlQDELsfYbr=''
    InUXyVHJoWpNiGcwRhePlQDELsfYbg =''
    InUXyVHJoWpNiGcwRhePlQDELsfYbS =''
    InUXyVHJoWpNiGcwRhePlQDELsfYbK =''
    for InUXyVHJoWpNiGcwRhePlQDELsfYbm in InUXyVHJoWpNiGcwRhePlQDELsfYSB[InUXyVHJoWpNiGcwRhePlQDELsfYKg]['program']['image']:
     if InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP0900':InUXyVHJoWpNiGcwRhePlQDELsfYbF =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP1800':InUXyVHJoWpNiGcwRhePlQDELsfYbr=InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP2000':InUXyVHJoWpNiGcwRhePlQDELsfYbg =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP1900':InUXyVHJoWpNiGcwRhePlQDELsfYbS =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIP0200':InUXyVHJoWpNiGcwRhePlQDELsfYbK =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
    for InUXyVHJoWpNiGcwRhePlQDELsfYbm in InUXyVHJoWpNiGcwRhePlQDELsfYSB[InUXyVHJoWpNiGcwRhePlQDELsfYKg]['episode']['image']:
     if InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIE0400':InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
    try:
     InUXyVHJoWpNiGcwRhePlQDELsfYKm=InUXyVHJoWpNiGcwRhePlQDELsfYKk=InUXyVHJoWpNiGcwRhePlQDELsfYKa=''
     InUXyVHJoWpNiGcwRhePlQDELsfYKA=0
     InUXyVHJoWpNiGcwRhePlQDELsfYKm =InUXyVHJoWpNiGcwRhePlQDELsfYSB[InUXyVHJoWpNiGcwRhePlQDELsfYKg]['program']['name']['ko']
     InUXyVHJoWpNiGcwRhePlQDELsfYKk =InUXyVHJoWpNiGcwRhePlQDELsfYKb
     InUXyVHJoWpNiGcwRhePlQDELsfYKa =InUXyVHJoWpNiGcwRhePlQDELsfYSB[InUXyVHJoWpNiGcwRhePlQDELsfYKg]['channel']['name']['ko']
     if 'frequency' in InUXyVHJoWpNiGcwRhePlQDELsfYSB[InUXyVHJoWpNiGcwRhePlQDELsfYKg]['episode']:InUXyVHJoWpNiGcwRhePlQDELsfYKA=InUXyVHJoWpNiGcwRhePlQDELsfYSB[InUXyVHJoWpNiGcwRhePlQDELsfYKg]['episode']['frequency']
    except:
     InUXyVHJoWpNiGcwRhePlQDELsfYmv
    InUXyVHJoWpNiGcwRhePlQDELsfYbt={'episode':InUXyVHJoWpNiGcwRhePlQDELsfYKS,'title':InUXyVHJoWpNiGcwRhePlQDELsfYSC,'subtitle':InUXyVHJoWpNiGcwRhePlQDELsfYKb,'thumbnail':{'poster':InUXyVHJoWpNiGcwRhePlQDELsfYbF,'thumb':InUXyVHJoWpNiGcwRhePlQDELsfYSj,'clearlogo':InUXyVHJoWpNiGcwRhePlQDELsfYbr,'icon':InUXyVHJoWpNiGcwRhePlQDELsfYbg,'banner':InUXyVHJoWpNiGcwRhePlQDELsfYbS,'fanart':InUXyVHJoWpNiGcwRhePlQDELsfYbK},'synopsis':InUXyVHJoWpNiGcwRhePlQDELsfYSz,'info_title':InUXyVHJoWpNiGcwRhePlQDELsfYKm,'aired':InUXyVHJoWpNiGcwRhePlQDELsfYKk,'studio':InUXyVHJoWpNiGcwRhePlQDELsfYKa,'frequency':InUXyVHJoWpNiGcwRhePlQDELsfYKA}
    InUXyVHJoWpNiGcwRhePlQDELsfYrd.append(InUXyVHJoWpNiGcwRhePlQDELsfYbt)
   if InUXyVHJoWpNiGcwRhePlQDELsfYKF>page_int:InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmt
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
  return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv,InUXyVHJoWpNiGcwRhePlQDELsfYKF
 def GetMovieList(InUXyVHJoWpNiGcwRhePlQDELsfYFK,genre,orderby,page_int):
  InUXyVHJoWpNiGcwRhePlQDELsfYrd=[]
  InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmx
  try:
   if genre=='PARAMOUNT':
    InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v2/media/paramount/movies'
   else:
    InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v2/media/movies'
   InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams()
   InUXyVHJoWpNiGcwRhePlQDELsfYrv={'pageSize':InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYFK.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':InUXyVHJoWpNiGcwRhePlQDELsfYmj(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:InUXyVHJoWpNiGcwRhePlQDELsfYrv['categoryCode']=genre
   InUXyVHJoWpNiGcwRhePlQDELsfYrv['productPackageCode']=','.join(InUXyVHJoWpNiGcwRhePlQDELsfYFK.MOVIE_LITE)
   InUXyVHJoWpNiGcwRhePlQDELsfYrj.update(InUXyVHJoWpNiGcwRhePlQDELsfYrv)
   InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYra
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrj,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv)
   InUXyVHJoWpNiGcwRhePlQDELsfYrx=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   if not('result' in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']):return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
   InUXyVHJoWpNiGcwRhePlQDELsfYSB=InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['result']
   for InUXyVHJoWpNiGcwRhePlQDELsfYrB in InUXyVHJoWpNiGcwRhePlQDELsfYSB:
    if 'release_date' in InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('movie'):
     InUXyVHJoWpNiGcwRhePlQDELsfYbM=InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('movie').get('release_date'))[:4]
    else:
     InUXyVHJoWpNiGcwRhePlQDELsfYbM=InUXyVHJoWpNiGcwRhePlQDELsfYmv
    InUXyVHJoWpNiGcwRhePlQDELsfYKM =InUXyVHJoWpNiGcwRhePlQDELsfYrB['movie']['code']
    InUXyVHJoWpNiGcwRhePlQDELsfYSC =InUXyVHJoWpNiGcwRhePlQDELsfYrB['movie']['name']['ko'].strip()
    if InUXyVHJoWpNiGcwRhePlQDELsfYbM not in[InUXyVHJoWpNiGcwRhePlQDELsfYmv,'0','']:InUXyVHJoWpNiGcwRhePlQDELsfYSC+=u' (%s)'%(InUXyVHJoWpNiGcwRhePlQDELsfYbM)
    InUXyVHJoWpNiGcwRhePlQDELsfYbF=''
    InUXyVHJoWpNiGcwRhePlQDELsfYSj =''
    InUXyVHJoWpNiGcwRhePlQDELsfYbr=''
    for InUXyVHJoWpNiGcwRhePlQDELsfYbm in InUXyVHJoWpNiGcwRhePlQDELsfYrB['movie']['image']:
     if InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIM2100':InUXyVHJoWpNiGcwRhePlQDELsfYbF =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIM0400':InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIM1800':InUXyVHJoWpNiGcwRhePlQDELsfYbr=InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
    InUXyVHJoWpNiGcwRhePlQDELsfYSz =InUXyVHJoWpNiGcwRhePlQDELsfYrB['movie']['story']['ko']
    try:
     InUXyVHJoWpNiGcwRhePlQDELsfYKm =InUXyVHJoWpNiGcwRhePlQDELsfYrB['movie']['name']['ko'].strip()
     InUXyVHJoWpNiGcwRhePlQDELsfYbd =InUXyVHJoWpNiGcwRhePlQDELsfYFS.get(InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('grade_code'))
     InUXyVHJoWpNiGcwRhePlQDELsfYbA=[]
     InUXyVHJoWpNiGcwRhePlQDELsfYbk=[]
     InUXyVHJoWpNiGcwRhePlQDELsfYba=[]
     InUXyVHJoWpNiGcwRhePlQDELsfYKd=0
     InUXyVHJoWpNiGcwRhePlQDELsfYbO=''
     InUXyVHJoWpNiGcwRhePlQDELsfYKa =''
     for InUXyVHJoWpNiGcwRhePlQDELsfYbT in InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('movie').get('actor'):
      if InUXyVHJoWpNiGcwRhePlQDELsfYbT!='':InUXyVHJoWpNiGcwRhePlQDELsfYbA.append(InUXyVHJoWpNiGcwRhePlQDELsfYbT)
     for InUXyVHJoWpNiGcwRhePlQDELsfYbv in InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('movie').get('director'):
      if InUXyVHJoWpNiGcwRhePlQDELsfYbv!='':InUXyVHJoWpNiGcwRhePlQDELsfYbk.append(InUXyVHJoWpNiGcwRhePlQDELsfYbv)
     if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('movie').get('category1_name').get('ko')!='':
      InUXyVHJoWpNiGcwRhePlQDELsfYba.append(InUXyVHJoWpNiGcwRhePlQDELsfYrB['movie']['category1_name']['ko'])
     if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('movie').get('category2_name').get('ko')!='':
      InUXyVHJoWpNiGcwRhePlQDELsfYba.append(InUXyVHJoWpNiGcwRhePlQDELsfYrB['movie']['category2_name']['ko'])
     if 'duration' in InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('movie'):InUXyVHJoWpNiGcwRhePlQDELsfYKd=InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('movie').get('duration')
     if 'release_date' in InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('movie'):
      InUXyVHJoWpNiGcwRhePlQDELsfYbx=InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('movie').get('release_date'))
      if InUXyVHJoWpNiGcwRhePlQDELsfYbx!='0':InUXyVHJoWpNiGcwRhePlQDELsfYbO='%s-%s-%s'%(InUXyVHJoWpNiGcwRhePlQDELsfYbx[:4],InUXyVHJoWpNiGcwRhePlQDELsfYbx[4:6],InUXyVHJoWpNiGcwRhePlQDELsfYbx[6:])
     if 'production' in InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('movie'):InUXyVHJoWpNiGcwRhePlQDELsfYKa=InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('movie').get('production')
    except:
     InUXyVHJoWpNiGcwRhePlQDELsfYmv
    InUXyVHJoWpNiGcwRhePlQDELsfYbt={'moviecode':InUXyVHJoWpNiGcwRhePlQDELsfYKM,'title':InUXyVHJoWpNiGcwRhePlQDELsfYSC,'thumbnail':{'poster':InUXyVHJoWpNiGcwRhePlQDELsfYbF,'thumb':InUXyVHJoWpNiGcwRhePlQDELsfYSj,'clearlogo':InUXyVHJoWpNiGcwRhePlQDELsfYbr,'fanart':InUXyVHJoWpNiGcwRhePlQDELsfYSj},'synopsis':InUXyVHJoWpNiGcwRhePlQDELsfYSz,'info_title':InUXyVHJoWpNiGcwRhePlQDELsfYKm,'year':InUXyVHJoWpNiGcwRhePlQDELsfYbM,'cast':InUXyVHJoWpNiGcwRhePlQDELsfYbA,'director':InUXyVHJoWpNiGcwRhePlQDELsfYbk,'info_genre':InUXyVHJoWpNiGcwRhePlQDELsfYba,'duration':InUXyVHJoWpNiGcwRhePlQDELsfYKd,'premiered':InUXyVHJoWpNiGcwRhePlQDELsfYbO,'studio':InUXyVHJoWpNiGcwRhePlQDELsfYKa,'mpaa':InUXyVHJoWpNiGcwRhePlQDELsfYbd}
    InUXyVHJoWpNiGcwRhePlQDELsfYKO=InUXyVHJoWpNiGcwRhePlQDELsfYmx
    for InUXyVHJoWpNiGcwRhePlQDELsfYKT in InUXyVHJoWpNiGcwRhePlQDELsfYrB['billing_package_id']:
     if InUXyVHJoWpNiGcwRhePlQDELsfYKT in InUXyVHJoWpNiGcwRhePlQDELsfYFK.MOVIE_LITE:
      InUXyVHJoWpNiGcwRhePlQDELsfYKO=InUXyVHJoWpNiGcwRhePlQDELsfYmt
      break
    if InUXyVHJoWpNiGcwRhePlQDELsfYKO==InUXyVHJoWpNiGcwRhePlQDELsfYmx: 
     InUXyVHJoWpNiGcwRhePlQDELsfYbt['title']=InUXyVHJoWpNiGcwRhePlQDELsfYbt['title']+' [개별구매]'
    InUXyVHJoWpNiGcwRhePlQDELsfYrd.append(InUXyVHJoWpNiGcwRhePlQDELsfYbt)
   if InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['has_more']=='Y':InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmt
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
  return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
 def Get_UHD_MovieList(InUXyVHJoWpNiGcwRhePlQDELsfYFK,page_int):
  InUXyVHJoWpNiGcwRhePlQDELsfYrd=[]
  InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmx
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v2/operator/highlights'
   InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams(uhd=InUXyVHJoWpNiGcwRhePlQDELsfYmt)
   InUXyVHJoWpNiGcwRhePlQDELsfYrv={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':InUXyVHJoWpNiGcwRhePlQDELsfYmj(page_int),'pocType':'APP_X_TVING_4.0.0',}
   InUXyVHJoWpNiGcwRhePlQDELsfYrj.update(InUXyVHJoWpNiGcwRhePlQDELsfYrv)
   InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYra
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrj,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv)
   InUXyVHJoWpNiGcwRhePlQDELsfYrx=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   if not('result' in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']):return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
   InUXyVHJoWpNiGcwRhePlQDELsfYSB=InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['result']
   for InUXyVHJoWpNiGcwRhePlQDELsfYrB in InUXyVHJoWpNiGcwRhePlQDELsfYSB:
    InUXyVHJoWpNiGcwRhePlQDELsfYbC=InUXyVHJoWpNiGcwRhePlQDELsfYrB['content']['movie']
    InUXyVHJoWpNiGcwRhePlQDELsfYbz =InUXyVHJoWpNiGcwRhePlQDELsfYbC['code']
    InUXyVHJoWpNiGcwRhePlQDELsfYSC =InUXyVHJoWpNiGcwRhePlQDELsfYbC['name']['ko'].strip()
    InUXyVHJoWpNiGcwRhePlQDELsfYKm =InUXyVHJoWpNiGcwRhePlQDELsfYbC['name']['ko'].strip()
    InUXyVHJoWpNiGcwRhePlQDELsfYbM =InUXyVHJoWpNiGcwRhePlQDELsfYbC['product_year']
    if InUXyVHJoWpNiGcwRhePlQDELsfYbM:InUXyVHJoWpNiGcwRhePlQDELsfYSC+=u' (%s)'%(InUXyVHJoWpNiGcwRhePlQDELsfYbC['product_year'])
    InUXyVHJoWpNiGcwRhePlQDELsfYSz =InUXyVHJoWpNiGcwRhePlQDELsfYbC['story']['ko']
    InUXyVHJoWpNiGcwRhePlQDELsfYKd =InUXyVHJoWpNiGcwRhePlQDELsfYbC['duration']
    InUXyVHJoWpNiGcwRhePlQDELsfYbd =InUXyVHJoWpNiGcwRhePlQDELsfYFS.get(InUXyVHJoWpNiGcwRhePlQDELsfYbC.get('grade_code'))
    InUXyVHJoWpNiGcwRhePlQDELsfYKa =InUXyVHJoWpNiGcwRhePlQDELsfYbC['production']
    InUXyVHJoWpNiGcwRhePlQDELsfYbF=''
    InUXyVHJoWpNiGcwRhePlQDELsfYSj =''
    InUXyVHJoWpNiGcwRhePlQDELsfYbr=''
    InUXyVHJoWpNiGcwRhePlQDELsfYba =[]
    InUXyVHJoWpNiGcwRhePlQDELsfYbA =[]
    InUXyVHJoWpNiGcwRhePlQDELsfYbk=[]
    InUXyVHJoWpNiGcwRhePlQDELsfYbO =''
    for InUXyVHJoWpNiGcwRhePlQDELsfYbm in InUXyVHJoWpNiGcwRhePlQDELsfYbC['image']:
     if InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIM2100':InUXyVHJoWpNiGcwRhePlQDELsfYbF =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIM0400':InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
     elif InUXyVHJoWpNiGcwRhePlQDELsfYbm['code']=='CAIM1800':InUXyVHJoWpNiGcwRhePlQDELsfYbr=InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm['url']
    if InUXyVHJoWpNiGcwRhePlQDELsfYbC['release_date']not in[InUXyVHJoWpNiGcwRhePlQDELsfYmv,0]:
     InUXyVHJoWpNiGcwRhePlQDELsfYbx=InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYbC['release_date'])
     if InUXyVHJoWpNiGcwRhePlQDELsfYbx!='0':InUXyVHJoWpNiGcwRhePlQDELsfYbO='%s-%s-%s'%(InUXyVHJoWpNiGcwRhePlQDELsfYbx[:4],InUXyVHJoWpNiGcwRhePlQDELsfYbx[4:6],InUXyVHJoWpNiGcwRhePlQDELsfYbx[6:])
    if InUXyVHJoWpNiGcwRhePlQDELsfYbC.get('category1_name').get('ko')!='':
     InUXyVHJoWpNiGcwRhePlQDELsfYba.append(InUXyVHJoWpNiGcwRhePlQDELsfYbC['category1_name']['ko'])
    if InUXyVHJoWpNiGcwRhePlQDELsfYbC.get('category2_name').get('ko')!='':
     InUXyVHJoWpNiGcwRhePlQDELsfYba.append(InUXyVHJoWpNiGcwRhePlQDELsfYbC['category2_name']['ko'])
    for InUXyVHJoWpNiGcwRhePlQDELsfYbT in InUXyVHJoWpNiGcwRhePlQDELsfYbC.get('actor'):
     if InUXyVHJoWpNiGcwRhePlQDELsfYbT!='':InUXyVHJoWpNiGcwRhePlQDELsfYbA.append(InUXyVHJoWpNiGcwRhePlQDELsfYbT)
    for InUXyVHJoWpNiGcwRhePlQDELsfYbv in InUXyVHJoWpNiGcwRhePlQDELsfYbC.get('director'):
     if InUXyVHJoWpNiGcwRhePlQDELsfYbv!='':InUXyVHJoWpNiGcwRhePlQDELsfYbk.append(InUXyVHJoWpNiGcwRhePlQDELsfYbv)
    InUXyVHJoWpNiGcwRhePlQDELsfYbt={'moviecode':InUXyVHJoWpNiGcwRhePlQDELsfYbz,'title':InUXyVHJoWpNiGcwRhePlQDELsfYSC,'thumbnail':{'poster':InUXyVHJoWpNiGcwRhePlQDELsfYbF,'thumb':InUXyVHJoWpNiGcwRhePlQDELsfYSj,'clearlogo':InUXyVHJoWpNiGcwRhePlQDELsfYbr,'fanart':InUXyVHJoWpNiGcwRhePlQDELsfYSj},'year':InUXyVHJoWpNiGcwRhePlQDELsfYbM,'info_title':InUXyVHJoWpNiGcwRhePlQDELsfYKm,'synopsis':InUXyVHJoWpNiGcwRhePlQDELsfYSz,'mpaa':InUXyVHJoWpNiGcwRhePlQDELsfYbd,'duration':InUXyVHJoWpNiGcwRhePlQDELsfYKd,'premiered':InUXyVHJoWpNiGcwRhePlQDELsfYbO,'studio':InUXyVHJoWpNiGcwRhePlQDELsfYKa,'info_genre':InUXyVHJoWpNiGcwRhePlQDELsfYba,'cast':InUXyVHJoWpNiGcwRhePlQDELsfYbA,'director':InUXyVHJoWpNiGcwRhePlQDELsfYbk,}
    InUXyVHJoWpNiGcwRhePlQDELsfYrd.append(InUXyVHJoWpNiGcwRhePlQDELsfYbt)
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
  return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
 def GetMovieGenre(InUXyVHJoWpNiGcwRhePlQDELsfYFK):
  InUXyVHJoWpNiGcwRhePlQDELsfYrd=[]
  InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmx
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v2/media/movie/curations'
   InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams()
   InUXyVHJoWpNiGcwRhePlQDELsfYrv={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   InUXyVHJoWpNiGcwRhePlQDELsfYrj.update(InUXyVHJoWpNiGcwRhePlQDELsfYrv)
   InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYra
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrj,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv)
   InUXyVHJoWpNiGcwRhePlQDELsfYrx=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   if not('result' in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']):return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
   InUXyVHJoWpNiGcwRhePlQDELsfYSB=InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['result']
   for InUXyVHJoWpNiGcwRhePlQDELsfYrB in InUXyVHJoWpNiGcwRhePlQDELsfYSB:
    InUXyVHJoWpNiGcwRhePlQDELsfYKv =InUXyVHJoWpNiGcwRhePlQDELsfYrB['curation_code']
    InUXyVHJoWpNiGcwRhePlQDELsfYKx =InUXyVHJoWpNiGcwRhePlQDELsfYrB['curation_name']
    InUXyVHJoWpNiGcwRhePlQDELsfYbt={'curation_code':InUXyVHJoWpNiGcwRhePlQDELsfYKv,'curation_name':InUXyVHJoWpNiGcwRhePlQDELsfYKx}
    InUXyVHJoWpNiGcwRhePlQDELsfYrd.append(InUXyVHJoWpNiGcwRhePlQDELsfYbt)
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
  return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
 def GetSearchList(InUXyVHJoWpNiGcwRhePlQDELsfYFK,search_key,page_int,stype):
  InUXyVHJoWpNiGcwRhePlQDELsfYKB=[]
  InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmx
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYra ='/search/getSearch.jsp'
   InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams()
   InUXyVHJoWpNiGcwRhePlQDELsfYrv={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':InUXyVHJoWpNiGcwRhePlQDELsfYmj(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYFK.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':InUXyVHJoWpNiGcwRhePlQDELsfYFK.SCREENCODE,'os':InUXyVHJoWpNiGcwRhePlQDELsfYFK.OSCODE,'network':InUXyVHJoWpNiGcwRhePlQDELsfYFK.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYFK.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYFK.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':InUXyVHJoWpNiGcwRhePlQDELsfYFK.APIKEY,'networkCode':InUXyVHJoWpNiGcwRhePlQDELsfYFK.NETWORKCODE,'osCode ':InUXyVHJoWpNiGcwRhePlQDELsfYFK.OSCODE,'teleCode ':InUXyVHJoWpNiGcwRhePlQDELsfYFK.TELECODE,'screenCode ':InUXyVHJoWpNiGcwRhePlQDELsfYFK.SCREENCODE}
   InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.SEARCH_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYra
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrv,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv)
   InUXyVHJoWpNiGcwRhePlQDELsfYrx=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   if stype=='vod':
    if not('programRsb' in InUXyVHJoWpNiGcwRhePlQDELsfYrx):return InUXyVHJoWpNiGcwRhePlQDELsfYKB,InUXyVHJoWpNiGcwRhePlQDELsfYSv
    InUXyVHJoWpNiGcwRhePlQDELsfYKt=InUXyVHJoWpNiGcwRhePlQDELsfYrx['programRsb']['dataList']
    InUXyVHJoWpNiGcwRhePlQDELsfYKq =InUXyVHJoWpNiGcwRhePlQDELsfYmq(InUXyVHJoWpNiGcwRhePlQDELsfYrx['programRsb']['count'])
    for InUXyVHJoWpNiGcwRhePlQDELsfYrB in InUXyVHJoWpNiGcwRhePlQDELsfYKt:
     InUXyVHJoWpNiGcwRhePlQDELsfYbq=InUXyVHJoWpNiGcwRhePlQDELsfYrB['mast_cd']
     InUXyVHJoWpNiGcwRhePlQDELsfYSC =InUXyVHJoWpNiGcwRhePlQDELsfYrB['mast_nm']
     InUXyVHJoWpNiGcwRhePlQDELsfYbF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYrB['web_url4']
     InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYrB['web_url']
     try:
      InUXyVHJoWpNiGcwRhePlQDELsfYbA =[]
      InUXyVHJoWpNiGcwRhePlQDELsfYbk=[]
      InUXyVHJoWpNiGcwRhePlQDELsfYba =[]
      InUXyVHJoWpNiGcwRhePlQDELsfYKd =0
      InUXyVHJoWpNiGcwRhePlQDELsfYbd =''
      InUXyVHJoWpNiGcwRhePlQDELsfYbM =''
      InUXyVHJoWpNiGcwRhePlQDELsfYKk =''
      if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('actor') !='' and InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('actor') !='-':InUXyVHJoWpNiGcwRhePlQDELsfYbA =InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('actor').split(',')
      if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('director')!='' and InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('director')!='-':InUXyVHJoWpNiGcwRhePlQDELsfYbk=InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('director').split(',')
      if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('cate_nm')!='' and InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('cate_nm')!='-':InUXyVHJoWpNiGcwRhePlQDELsfYba =InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('cate_nm').split('/')
      if 'targetage' in InUXyVHJoWpNiGcwRhePlQDELsfYrB:InUXyVHJoWpNiGcwRhePlQDELsfYbd=InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('targetage')
      if 'broad_dt' in InUXyVHJoWpNiGcwRhePlQDELsfYrB:
       InUXyVHJoWpNiGcwRhePlQDELsfYbx=InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('broad_dt')
       InUXyVHJoWpNiGcwRhePlQDELsfYKk='%s-%s-%s'%(InUXyVHJoWpNiGcwRhePlQDELsfYbx[:4],InUXyVHJoWpNiGcwRhePlQDELsfYbx[4:6],InUXyVHJoWpNiGcwRhePlQDELsfYbx[6:])
       InUXyVHJoWpNiGcwRhePlQDELsfYbM =InUXyVHJoWpNiGcwRhePlQDELsfYbx[:4]
     except:
      InUXyVHJoWpNiGcwRhePlQDELsfYmv
     InUXyVHJoWpNiGcwRhePlQDELsfYbt={'program':InUXyVHJoWpNiGcwRhePlQDELsfYbq,'title':InUXyVHJoWpNiGcwRhePlQDELsfYSC,'thumbnail':{'poster':InUXyVHJoWpNiGcwRhePlQDELsfYbF,'thumb':InUXyVHJoWpNiGcwRhePlQDELsfYSj,'fanart':InUXyVHJoWpNiGcwRhePlQDELsfYSj},'synopsis':'','cast':InUXyVHJoWpNiGcwRhePlQDELsfYbA,'director':InUXyVHJoWpNiGcwRhePlQDELsfYbk,'info_genre':InUXyVHJoWpNiGcwRhePlQDELsfYba,'duration':InUXyVHJoWpNiGcwRhePlQDELsfYKd,'mpaa':InUXyVHJoWpNiGcwRhePlQDELsfYbd,'year':InUXyVHJoWpNiGcwRhePlQDELsfYbM,'aired':InUXyVHJoWpNiGcwRhePlQDELsfYKk}
     InUXyVHJoWpNiGcwRhePlQDELsfYKB.append(InUXyVHJoWpNiGcwRhePlQDELsfYbt)
   else:
    if not('vodMVRsb' in InUXyVHJoWpNiGcwRhePlQDELsfYrx):return InUXyVHJoWpNiGcwRhePlQDELsfYKB,InUXyVHJoWpNiGcwRhePlQDELsfYSv
    InUXyVHJoWpNiGcwRhePlQDELsfYKu=InUXyVHJoWpNiGcwRhePlQDELsfYrx['vodMVRsb']['dataList']
    InUXyVHJoWpNiGcwRhePlQDELsfYKq =InUXyVHJoWpNiGcwRhePlQDELsfYmq(InUXyVHJoWpNiGcwRhePlQDELsfYrx['vodMVRsb']['count'])
    for InUXyVHJoWpNiGcwRhePlQDELsfYrB in InUXyVHJoWpNiGcwRhePlQDELsfYKu:
     InUXyVHJoWpNiGcwRhePlQDELsfYbq=InUXyVHJoWpNiGcwRhePlQDELsfYrB['mast_cd']
     InUXyVHJoWpNiGcwRhePlQDELsfYSC =InUXyVHJoWpNiGcwRhePlQDELsfYrB['mast_nm'].strip()
     InUXyVHJoWpNiGcwRhePlQDELsfYbF =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYrB['web_url']
     InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYbF
     InUXyVHJoWpNiGcwRhePlQDELsfYbr=''
     try:
      InUXyVHJoWpNiGcwRhePlQDELsfYbA =[]
      InUXyVHJoWpNiGcwRhePlQDELsfYbk=[]
      InUXyVHJoWpNiGcwRhePlQDELsfYba =[]
      InUXyVHJoWpNiGcwRhePlQDELsfYKd =0
      InUXyVHJoWpNiGcwRhePlQDELsfYbd =''
      InUXyVHJoWpNiGcwRhePlQDELsfYbM =''
      InUXyVHJoWpNiGcwRhePlQDELsfYKk =''
      if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('actor') !='' and InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('actor') !='-':InUXyVHJoWpNiGcwRhePlQDELsfYbA =InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('actor').split(',')
      if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('director')!='' and InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('director')!='-':InUXyVHJoWpNiGcwRhePlQDELsfYbk=InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('director').split(',')
      if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('cate_nm')!='' and InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('cate_nm')!='-':InUXyVHJoWpNiGcwRhePlQDELsfYba =InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('cate_nm').split('/')
      if InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('runtime_sec')!='':InUXyVHJoWpNiGcwRhePlQDELsfYKd=InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('runtime_sec')
      if 'grade_nm' in InUXyVHJoWpNiGcwRhePlQDELsfYrB:InUXyVHJoWpNiGcwRhePlQDELsfYbd=InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('grade_nm')
      InUXyVHJoWpNiGcwRhePlQDELsfYbx=InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('broad_dt')
      if data_str!='':
       InUXyVHJoWpNiGcwRhePlQDELsfYKk='%s-%s-%s'%(InUXyVHJoWpNiGcwRhePlQDELsfYbx[:4],InUXyVHJoWpNiGcwRhePlQDELsfYbx[4:6],InUXyVHJoWpNiGcwRhePlQDELsfYbx[6:])
       InUXyVHJoWpNiGcwRhePlQDELsfYbM =InUXyVHJoWpNiGcwRhePlQDELsfYbx[:4]
     except:
      InUXyVHJoWpNiGcwRhePlQDELsfYmv
     InUXyVHJoWpNiGcwRhePlQDELsfYbt={'movie':InUXyVHJoWpNiGcwRhePlQDELsfYbq,'title':InUXyVHJoWpNiGcwRhePlQDELsfYSC,'thumbnail':{'poster':InUXyVHJoWpNiGcwRhePlQDELsfYbF,'thumb':InUXyVHJoWpNiGcwRhePlQDELsfYSj,'fanart':InUXyVHJoWpNiGcwRhePlQDELsfYSj,'clearlogo':InUXyVHJoWpNiGcwRhePlQDELsfYbr},'synopsis':'','cast':InUXyVHJoWpNiGcwRhePlQDELsfYbA,'director':InUXyVHJoWpNiGcwRhePlQDELsfYbk,'info_genre':InUXyVHJoWpNiGcwRhePlQDELsfYba,'duration':InUXyVHJoWpNiGcwRhePlQDELsfYKd,'mpaa':InUXyVHJoWpNiGcwRhePlQDELsfYbd,'year':InUXyVHJoWpNiGcwRhePlQDELsfYbM,'aired':InUXyVHJoWpNiGcwRhePlQDELsfYKk}
     InUXyVHJoWpNiGcwRhePlQDELsfYKO=InUXyVHJoWpNiGcwRhePlQDELsfYmx
     for InUXyVHJoWpNiGcwRhePlQDELsfYKT in InUXyVHJoWpNiGcwRhePlQDELsfYrB['bill']:
      if InUXyVHJoWpNiGcwRhePlQDELsfYKT in InUXyVHJoWpNiGcwRhePlQDELsfYFK.MOVIE_LITE:
       InUXyVHJoWpNiGcwRhePlQDELsfYKO=InUXyVHJoWpNiGcwRhePlQDELsfYmt
       break
     if InUXyVHJoWpNiGcwRhePlQDELsfYKO==InUXyVHJoWpNiGcwRhePlQDELsfYmx: 
      InUXyVHJoWpNiGcwRhePlQDELsfYbt['title']=InUXyVHJoWpNiGcwRhePlQDELsfYbt['title']+' [개별구매]'
     InUXyVHJoWpNiGcwRhePlQDELsfYKB.append(InUXyVHJoWpNiGcwRhePlQDELsfYbt)
   if InUXyVHJoWpNiGcwRhePlQDELsfYKq>(page_int*InUXyVHJoWpNiGcwRhePlQDELsfYFK.SEARCH_LIMIT):InUXyVHJoWpNiGcwRhePlQDELsfYSv=InUXyVHJoWpNiGcwRhePlQDELsfYmt
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
  return InUXyVHJoWpNiGcwRhePlQDELsfYKB,InUXyVHJoWpNiGcwRhePlQDELsfYSv
 def GetBookmarkInfo(InUXyVHJoWpNiGcwRhePlQDELsfYFK,videoid,vidtype):
  InUXyVHJoWpNiGcwRhePlQDELsfYKC={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+'/v2/media/program/'+videoid
   InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams()
   InUXyVHJoWpNiGcwRhePlQDELsfYrv={'pageNo':'1','pageSize':'10','order':'name',}
   InUXyVHJoWpNiGcwRhePlQDELsfYrj.update(InUXyVHJoWpNiGcwRhePlQDELsfYrv)
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrj,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv)
   InUXyVHJoWpNiGcwRhePlQDELsfYKz=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   if not('body' in InUXyVHJoWpNiGcwRhePlQDELsfYKz):return{}
   InUXyVHJoWpNiGcwRhePlQDELsfYKj=InUXyVHJoWpNiGcwRhePlQDELsfYKz['body']
   InUXyVHJoWpNiGcwRhePlQDELsfYSC=InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('name').get('ko').strip()
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['title'] =InUXyVHJoWpNiGcwRhePlQDELsfYSC
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['title']=InUXyVHJoWpNiGcwRhePlQDELsfYSC
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['mpaa'] =InUXyVHJoWpNiGcwRhePlQDELsfYFS.get(InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('grade_code'))
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['plot'] =InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('synopsis').get('ko')
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['year'] =InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('product_year')
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['cast'] =InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('actor')
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['director']=InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('director')
   if InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('category1_name').get('ko')!='':
    InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['genre'].append(InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('category1_name').get('ko'))
   if InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('category2_name').get('ko')!='':
    InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['genre'].append(InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('category2_name').get('ko'))
   InUXyVHJoWpNiGcwRhePlQDELsfYbx=InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('broad_dt'))
   if InUXyVHJoWpNiGcwRhePlQDELsfYbx!='0':InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(InUXyVHJoWpNiGcwRhePlQDELsfYbx[:4],InUXyVHJoWpNiGcwRhePlQDELsfYbx[4:6],InUXyVHJoWpNiGcwRhePlQDELsfYbx[6:])
   InUXyVHJoWpNiGcwRhePlQDELsfYbF =''
   InUXyVHJoWpNiGcwRhePlQDELsfYSj =''
   InUXyVHJoWpNiGcwRhePlQDELsfYbr=''
   InUXyVHJoWpNiGcwRhePlQDELsfYbg =''
   InUXyVHJoWpNiGcwRhePlQDELsfYbS =''
   for InUXyVHJoWpNiGcwRhePlQDELsfYbm in InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('image'):
    if InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('code')=='CAIP0900':InUXyVHJoWpNiGcwRhePlQDELsfYbF =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('url')
    elif InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('code')=='CAIP0200':InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('url')
    elif InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('code')=='CAIP1800':InUXyVHJoWpNiGcwRhePlQDELsfYbr=InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('url')
    elif InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('code')=='CAIP2000':InUXyVHJoWpNiGcwRhePlQDELsfYbg =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('url')
    elif InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('code')=='CAIP1900':InUXyVHJoWpNiGcwRhePlQDELsfYbS =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('url')
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['thumbnail']['poster']=InUXyVHJoWpNiGcwRhePlQDELsfYbF
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['thumbnail']['thumb']=InUXyVHJoWpNiGcwRhePlQDELsfYSj
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['thumbnail']['clearlogo']=InUXyVHJoWpNiGcwRhePlQDELsfYbr
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['thumbnail']['icon']=InUXyVHJoWpNiGcwRhePlQDELsfYbg
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['thumbnail']['banner']=InUXyVHJoWpNiGcwRhePlQDELsfYbS
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['thumbnail']['fanart']=InUXyVHJoWpNiGcwRhePlQDELsfYSj
  else:
   InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+'/v2a/media/stream/info'
   InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams()
   InUXyVHJoWpNiGcwRhePlQDELsfYrv={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_uuid'].split('-')[0],'uuid':InUXyVHJoWpNiGcwRhePlQDELsfYFK.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetNoCache(1)),'wm':'Y',}
   InUXyVHJoWpNiGcwRhePlQDELsfYrj.update(InUXyVHJoWpNiGcwRhePlQDELsfYrv)
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrj,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv)
   InUXyVHJoWpNiGcwRhePlQDELsfYKz=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   if not('content' in InUXyVHJoWpNiGcwRhePlQDELsfYKz['body']):return{}
   InUXyVHJoWpNiGcwRhePlQDELsfYKj=InUXyVHJoWpNiGcwRhePlQDELsfYKz['body']['content']['info']['movie']
   InUXyVHJoWpNiGcwRhePlQDELsfYSC =InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('name').get('ko').strip()
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['title']=InUXyVHJoWpNiGcwRhePlQDELsfYSC
   InUXyVHJoWpNiGcwRhePlQDELsfYSC +=u' (%s)'%(InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('product_year'))
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['title'] =InUXyVHJoWpNiGcwRhePlQDELsfYSC
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['mpaa'] =InUXyVHJoWpNiGcwRhePlQDELsfYFS.get(InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('grade_code'))
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['plot'] =InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('story').get('ko')
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['year'] =InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('product_year')
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['studio'] =InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('production')
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['duration']=InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('duration')
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['cast'] =InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('actor')
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['director']=InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('director')
   if InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('category1_name').get('ko')!='':
    InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['genre'].append(InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('category1_name').get('ko'))
   if InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('category2_name').get('ko')!='':
    InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['genre'].append(InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('category2_name').get('ko'))
   InUXyVHJoWpNiGcwRhePlQDELsfYbx=InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('release_date'))
   if InUXyVHJoWpNiGcwRhePlQDELsfYbx!='0':InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(InUXyVHJoWpNiGcwRhePlQDELsfYbx[:4],InUXyVHJoWpNiGcwRhePlQDELsfYbx[4:6],InUXyVHJoWpNiGcwRhePlQDELsfYbx[6:])
   InUXyVHJoWpNiGcwRhePlQDELsfYbF=''
   InUXyVHJoWpNiGcwRhePlQDELsfYSj =''
   InUXyVHJoWpNiGcwRhePlQDELsfYbr=''
   for InUXyVHJoWpNiGcwRhePlQDELsfYbm in InUXyVHJoWpNiGcwRhePlQDELsfYKj.get('image'):
    if InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('code')=='CAIM2100':InUXyVHJoWpNiGcwRhePlQDELsfYbF =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('url')
    elif InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('code')=='CAIM0400':InUXyVHJoWpNiGcwRhePlQDELsfYSj =InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('url')
    elif InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('code')=='CAIM1800':InUXyVHJoWpNiGcwRhePlQDELsfYbr=InUXyVHJoWpNiGcwRhePlQDELsfYFK.IMG_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYbm.get('url')
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['thumbnail']['poster']=InUXyVHJoWpNiGcwRhePlQDELsfYbF
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['thumbnail']['thumb']=InUXyVHJoWpNiGcwRhePlQDELsfYbF 
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['thumbnail']['clearlogo']=InUXyVHJoWpNiGcwRhePlQDELsfYbr
   InUXyVHJoWpNiGcwRhePlQDELsfYKC['saveinfo']['thumbnail']['fanart']=InUXyVHJoWpNiGcwRhePlQDELsfYSj
  return InUXyVHJoWpNiGcwRhePlQDELsfYKC
 def GetEuroChannelList(InUXyVHJoWpNiGcwRhePlQDELsfYFK):
  InUXyVHJoWpNiGcwRhePlQDELsfYrd=[]
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYra ='/v2/operator/highlights'
   InUXyVHJoWpNiGcwRhePlQDELsfYrj=InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetDefaultParams()
   InUXyVHJoWpNiGcwRhePlQDELsfYrv={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':InUXyVHJoWpNiGcwRhePlQDELsfYmj(InUXyVHJoWpNiGcwRhePlQDELsfYFK.GetNoCache(2))}
   InUXyVHJoWpNiGcwRhePlQDELsfYrj.update(InUXyVHJoWpNiGcwRhePlQDELsfYrv)
   InUXyVHJoWpNiGcwRhePlQDELsfYgF=InUXyVHJoWpNiGcwRhePlQDELsfYFK.API_DOMAIN+InUXyVHJoWpNiGcwRhePlQDELsfYra
   InUXyVHJoWpNiGcwRhePlQDELsfYrb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.callRequestCookies('Get',InUXyVHJoWpNiGcwRhePlQDELsfYgF,payload=InUXyVHJoWpNiGcwRhePlQDELsfYmv,params=InUXyVHJoWpNiGcwRhePlQDELsfYrj,headers=InUXyVHJoWpNiGcwRhePlQDELsfYmv,cookies=InUXyVHJoWpNiGcwRhePlQDELsfYmv)
   InUXyVHJoWpNiGcwRhePlQDELsfYrx=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYrb.text)
   if not('result' in InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']):return InUXyVHJoWpNiGcwRhePlQDELsfYrd,InUXyVHJoWpNiGcwRhePlQDELsfYSv
   InUXyVHJoWpNiGcwRhePlQDELsfYSB=InUXyVHJoWpNiGcwRhePlQDELsfYrx['body']['result']
   InUXyVHJoWpNiGcwRhePlQDELsfYmF =InUXyVHJoWpNiGcwRhePlQDELsfYFK.Get_Now_Datetime()
   InUXyVHJoWpNiGcwRhePlQDELsfYmr=InUXyVHJoWpNiGcwRhePlQDELsfYmF+datetime.timedelta(days=-1)
   InUXyVHJoWpNiGcwRhePlQDELsfYmr=InUXyVHJoWpNiGcwRhePlQDELsfYmq(InUXyVHJoWpNiGcwRhePlQDELsfYmr.strftime('%Y%m%d'))
   for InUXyVHJoWpNiGcwRhePlQDELsfYrB in InUXyVHJoWpNiGcwRhePlQDELsfYSB:
    InUXyVHJoWpNiGcwRhePlQDELsfYmg=InUXyVHJoWpNiGcwRhePlQDELsfYmq(InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('content').get('banner_title2')[:8])
    if InUXyVHJoWpNiGcwRhePlQDELsfYmr<=InUXyVHJoWpNiGcwRhePlQDELsfYmg:
     InUXyVHJoWpNiGcwRhePlQDELsfYbt={'channel':InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('content').get('banner_sub_title3'),'title':InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('content').get('banner_title'),'subtitle':InUXyVHJoWpNiGcwRhePlQDELsfYrB.get('content').get('banner_sub_title2'),}
     InUXyVHJoWpNiGcwRhePlQDELsfYrd.append(InUXyVHJoWpNiGcwRhePlQDELsfYbt)
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
  return InUXyVHJoWpNiGcwRhePlQDELsfYrd
 def Make_DecryptKey(InUXyVHJoWpNiGcwRhePlQDELsfYFK,step,mediacode='000',timecode='000'):
  if step=='1':
   InUXyVHJoWpNiGcwRhePlQDELsfYmS=InUXyVHJoWpNiGcwRhePlQDELsfYAg('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   InUXyVHJoWpNiGcwRhePlQDELsfYmb=InUXyVHJoWpNiGcwRhePlQDELsfYAg('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   InUXyVHJoWpNiGcwRhePlQDELsfYmS=InUXyVHJoWpNiGcwRhePlQDELsfYAg('kss2lym0kdw1lks3','utf-8')
   InUXyVHJoWpNiGcwRhePlQDELsfYmb=InUXyVHJoWpNiGcwRhePlQDELsfYAg([InUXyVHJoWpNiGcwRhePlQDELsfYAS('*'),0x07,InUXyVHJoWpNiGcwRhePlQDELsfYAS('r'),InUXyVHJoWpNiGcwRhePlQDELsfYAS(';'),InUXyVHJoWpNiGcwRhePlQDELsfYAS('7'),0x05,0x1e,0x01,InUXyVHJoWpNiGcwRhePlQDELsfYAS('n'),InUXyVHJoWpNiGcwRhePlQDELsfYAS('D'),0x02,InUXyVHJoWpNiGcwRhePlQDELsfYAS('3'),InUXyVHJoWpNiGcwRhePlQDELsfYAS('*'),InUXyVHJoWpNiGcwRhePlQDELsfYAS('a'),InUXyVHJoWpNiGcwRhePlQDELsfYAS('&'),InUXyVHJoWpNiGcwRhePlQDELsfYAS('<')])
  return InUXyVHJoWpNiGcwRhePlQDELsfYmS,InUXyVHJoWpNiGcwRhePlQDELsfYmb
 def DecryptPlaintext(InUXyVHJoWpNiGcwRhePlQDELsfYFK,ciphertext,encryption_key,init_vector):
  InUXyVHJoWpNiGcwRhePlQDELsfYmK=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  InUXyVHJoWpNiGcwRhePlQDELsfYmA=Padding.unpad(InUXyVHJoWpNiGcwRhePlQDELsfYmK.decrypt(base64.standard_b64decode(ciphertext)),16)
  return InUXyVHJoWpNiGcwRhePlQDELsfYmA.decode('utf-8')
 def Decrypt_Url(InUXyVHJoWpNiGcwRhePlQDELsfYFK,ciphertext,mediacode,InUXyVHJoWpNiGcwRhePlQDELsfYgA):
  InUXyVHJoWpNiGcwRhePlQDELsfYmk=''
  InUXyVHJoWpNiGcwRhePlQDELsfYgk=''
  InUXyVHJoWpNiGcwRhePlQDELsfYga=''
  try:
   InUXyVHJoWpNiGcwRhePlQDELsfYmS,InUXyVHJoWpNiGcwRhePlQDELsfYmb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.Make_DecryptKey('1',mediacode=mediacode,timecode=InUXyVHJoWpNiGcwRhePlQDELsfYgA)
   InUXyVHJoWpNiGcwRhePlQDELsfYma=json.loads(InUXyVHJoWpNiGcwRhePlQDELsfYFK.DecryptPlaintext(ciphertext,InUXyVHJoWpNiGcwRhePlQDELsfYmS,InUXyVHJoWpNiGcwRhePlQDELsfYmb))
   InUXyVHJoWpNiGcwRhePlQDELsfYmM =InUXyVHJoWpNiGcwRhePlQDELsfYma.get('broad_url')
   InUXyVHJoWpNiGcwRhePlQDELsfYgk =InUXyVHJoWpNiGcwRhePlQDELsfYma.get('watermark') if 'watermark' in InUXyVHJoWpNiGcwRhePlQDELsfYma else ''
   InUXyVHJoWpNiGcwRhePlQDELsfYga=InUXyVHJoWpNiGcwRhePlQDELsfYma.get('watermarkKey')if 'watermarkKey' in InUXyVHJoWpNiGcwRhePlQDELsfYma else ''
   InUXyVHJoWpNiGcwRhePlQDELsfYmS,InUXyVHJoWpNiGcwRhePlQDELsfYmb=InUXyVHJoWpNiGcwRhePlQDELsfYFK.Make_DecryptKey('2',mediacode=mediacode,timecode=InUXyVHJoWpNiGcwRhePlQDELsfYgA)
   InUXyVHJoWpNiGcwRhePlQDELsfYmk=InUXyVHJoWpNiGcwRhePlQDELsfYFK.DecryptPlaintext(InUXyVHJoWpNiGcwRhePlQDELsfYmM,InUXyVHJoWpNiGcwRhePlQDELsfYmS,InUXyVHJoWpNiGcwRhePlQDELsfYmb)
  except InUXyVHJoWpNiGcwRhePlQDELsfYmC as exception:
   InUXyVHJoWpNiGcwRhePlQDELsfYmd(exception)
  return InUXyVHJoWpNiGcwRhePlQDELsfYmk,InUXyVHJoWpNiGcwRhePlQDELsfYgk,InUXyVHJoWpNiGcwRhePlQDELsfYga
# Created by pyminifier (https://github.com/liftoff/pyminifier)
