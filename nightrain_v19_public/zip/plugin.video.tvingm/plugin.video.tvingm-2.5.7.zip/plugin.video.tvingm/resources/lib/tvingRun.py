__author__="NightRain"
FwvXYWOkfuailQMemSKrjNdGBVIJyn=object
FwvXYWOkfuailQMemSKrjNdGBVIJyq=None
FwvXYWOkfuailQMemSKrjNdGBVIJyU=int
FwvXYWOkfuailQMemSKrjNdGBVIJyx=True
FwvXYWOkfuailQMemSKrjNdGBVIJyP=False
FwvXYWOkfuailQMemSKrjNdGBVIJyb=type
FwvXYWOkfuailQMemSKrjNdGBVIJsc=dict
FwvXYWOkfuailQMemSKrjNdGBVIJsg=getattr
FwvXYWOkfuailQMemSKrjNdGBVIJsL=list
FwvXYWOkfuailQMemSKrjNdGBVIJsH=len
FwvXYWOkfuailQMemSKrjNdGBVIJsR=str
FwvXYWOkfuailQMemSKrjNdGBVIJsT=range
FwvXYWOkfuailQMemSKrjNdGBVIJsz=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
FwvXYWOkfuailQMemSKrjNdGBVIJcL=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
FwvXYWOkfuailQMemSKrjNdGBVIJcH=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
FwvXYWOkfuailQMemSKrjNdGBVIJcR=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
FwvXYWOkfuailQMemSKrjNdGBVIJcT=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
FwvXYWOkfuailQMemSKrjNdGBVIJcz=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
FwvXYWOkfuailQMemSKrjNdGBVIJcy=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
FwvXYWOkfuailQMemSKrjNdGBVIJcs=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
FwvXYWOkfuailQMemSKrjNdGBVIJcC={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
FwvXYWOkfuailQMemSKrjNdGBVIJcD =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
FwvXYWOkfuailQMemSKrjNdGBVIJco=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class FwvXYWOkfuailQMemSKrjNdGBVIJcg(FwvXYWOkfuailQMemSKrjNdGBVIJyn):
 def __init__(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJcE,FwvXYWOkfuailQMemSKrjNdGBVIJcp,FwvXYWOkfuailQMemSKrjNdGBVIJch):
  FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_url =FwvXYWOkfuailQMemSKrjNdGBVIJcE
  FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle=FwvXYWOkfuailQMemSKrjNdGBVIJcp
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params =FwvXYWOkfuailQMemSKrjNdGBVIJch
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj =InUXyVHJoWpNiGcwRhePlQDELsfYFr() 
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(FwvXYWOkfuailQMemSKrjNdGBVIJcA,sting):
  try:
   FwvXYWOkfuailQMemSKrjNdGBVIJcn=xbmcgui.Dialog()
   FwvXYWOkfuailQMemSKrjNdGBVIJcn.notification(__addonname__,sting)
  except:
   FwvXYWOkfuailQMemSKrjNdGBVIJyq
 def addon_log(FwvXYWOkfuailQMemSKrjNdGBVIJcA,string):
  try:
   FwvXYWOkfuailQMemSKrjNdGBVIJcq=string.encode('utf-8','ignore')
  except:
   FwvXYWOkfuailQMemSKrjNdGBVIJcq='addonException: addon_log'
  FwvXYWOkfuailQMemSKrjNdGBVIJcU=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,FwvXYWOkfuailQMemSKrjNdGBVIJcq),level=FwvXYWOkfuailQMemSKrjNdGBVIJcU)
 def get_keyboard_input(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJgh):
  FwvXYWOkfuailQMemSKrjNdGBVIJcx=FwvXYWOkfuailQMemSKrjNdGBVIJyq
  kb=xbmc.Keyboard()
  kb.setHeading(FwvXYWOkfuailQMemSKrjNdGBVIJgh)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   FwvXYWOkfuailQMemSKrjNdGBVIJcx=kb.getText()
  return FwvXYWOkfuailQMemSKrjNdGBVIJcx
 def get_settings_account(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  FwvXYWOkfuailQMemSKrjNdGBVIJcP =__addon__.getSetting('id')
  FwvXYWOkfuailQMemSKrjNdGBVIJcb =__addon__.getSetting('pw')
  FwvXYWOkfuailQMemSKrjNdGBVIJgc =__addon__.getSetting('login_type')
  FwvXYWOkfuailQMemSKrjNdGBVIJgL=FwvXYWOkfuailQMemSKrjNdGBVIJyU(__addon__.getSetting('selected_profile'))
  return(FwvXYWOkfuailQMemSKrjNdGBVIJcP,FwvXYWOkfuailQMemSKrjNdGBVIJcb,FwvXYWOkfuailQMemSKrjNdGBVIJgc,FwvXYWOkfuailQMemSKrjNdGBVIJgL)
 def get_settings_uhd(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  return FwvXYWOkfuailQMemSKrjNdGBVIJyx if __addon__.getSetting('active_uhd')=='true' else FwvXYWOkfuailQMemSKrjNdGBVIJyP
 def get_settings_playback(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  FwvXYWOkfuailQMemSKrjNdGBVIJgH={'active_uhd':FwvXYWOkfuailQMemSKrjNdGBVIJyx if __addon__.getSetting('active_uhd')=='true' else FwvXYWOkfuailQMemSKrjNdGBVIJyP,'streamFilename':FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.TV_STREAM_FILENAME,}
  return FwvXYWOkfuailQMemSKrjNdGBVIJgH
 def get_settings_proxyport(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  FwvXYWOkfuailQMemSKrjNdGBVIJgR =FwvXYWOkfuailQMemSKrjNdGBVIJyx if __addon__.getSetting('proxyYn')=='true' else FwvXYWOkfuailQMemSKrjNdGBVIJyP
  FwvXYWOkfuailQMemSKrjNdGBVIJgT=FwvXYWOkfuailQMemSKrjNdGBVIJyU(__addon__.getSetting('proxyPort'))
  return FwvXYWOkfuailQMemSKrjNdGBVIJgR,FwvXYWOkfuailQMemSKrjNdGBVIJgT
 def get_settings_totalsearch(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  FwvXYWOkfuailQMemSKrjNdGBVIJgz =FwvXYWOkfuailQMemSKrjNdGBVIJyx if __addon__.getSetting('local_search')=='true' else FwvXYWOkfuailQMemSKrjNdGBVIJyP
  FwvXYWOkfuailQMemSKrjNdGBVIJgy=FwvXYWOkfuailQMemSKrjNdGBVIJyx if __addon__.getSetting('local_history')=='true' else FwvXYWOkfuailQMemSKrjNdGBVIJyP
  FwvXYWOkfuailQMemSKrjNdGBVIJgs =FwvXYWOkfuailQMemSKrjNdGBVIJyx if __addon__.getSetting('total_search')=='true' else FwvXYWOkfuailQMemSKrjNdGBVIJyP
  FwvXYWOkfuailQMemSKrjNdGBVIJgC=FwvXYWOkfuailQMemSKrjNdGBVIJyx if __addon__.getSetting('total_history')=='true' else FwvXYWOkfuailQMemSKrjNdGBVIJyP
  FwvXYWOkfuailQMemSKrjNdGBVIJgD=FwvXYWOkfuailQMemSKrjNdGBVIJyx if __addon__.getSetting('menu_bookmark')=='true' else FwvXYWOkfuailQMemSKrjNdGBVIJyP
  return(FwvXYWOkfuailQMemSKrjNdGBVIJgz,FwvXYWOkfuailQMemSKrjNdGBVIJgy,FwvXYWOkfuailQMemSKrjNdGBVIJgs,FwvXYWOkfuailQMemSKrjNdGBVIJgC,FwvXYWOkfuailQMemSKrjNdGBVIJgD)
 def get_settings_makebookmark(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  return FwvXYWOkfuailQMemSKrjNdGBVIJyx if __addon__.getSetting('make_bookmark')=='true' else FwvXYWOkfuailQMemSKrjNdGBVIJyP
 def get_settings_direct_replay(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  FwvXYWOkfuailQMemSKrjNdGBVIJgo=FwvXYWOkfuailQMemSKrjNdGBVIJyU(__addon__.getSetting('direct_replay'))
  if FwvXYWOkfuailQMemSKrjNdGBVIJgo==0:
   return FwvXYWOkfuailQMemSKrjNdGBVIJyP
  else:
   return FwvXYWOkfuailQMemSKrjNdGBVIJyx
 def set_winEpisodeOrderby(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJgE):
  __addon__.setSetting('tving_orderby',FwvXYWOkfuailQMemSKrjNdGBVIJgE)
  FwvXYWOkfuailQMemSKrjNdGBVIJgA=xbmcgui.Window(10000)
  FwvXYWOkfuailQMemSKrjNdGBVIJgA.setProperty('TVING_M_ORDERBY',FwvXYWOkfuailQMemSKrjNdGBVIJgE)
 def get_winEpisodeOrderby(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  FwvXYWOkfuailQMemSKrjNdGBVIJgE=__addon__.getSetting('tving_orderby')
  if FwvXYWOkfuailQMemSKrjNdGBVIJgE in['',FwvXYWOkfuailQMemSKrjNdGBVIJyq]:FwvXYWOkfuailQMemSKrjNdGBVIJgE='desc'
  return FwvXYWOkfuailQMemSKrjNdGBVIJgE
 def add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJcA,label,sublabel='',img='',infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJyq,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params='',isLink=FwvXYWOkfuailQMemSKrjNdGBVIJyP,ContextMenu=FwvXYWOkfuailQMemSKrjNdGBVIJyq):
  FwvXYWOkfuailQMemSKrjNdGBVIJgp='%s?%s'%(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_url,urllib.parse.urlencode(params))
  if sublabel:FwvXYWOkfuailQMemSKrjNdGBVIJgh='%s < %s >'%(label,sublabel)
  else: FwvXYWOkfuailQMemSKrjNdGBVIJgh=label
  if not img:img='DefaultFolder.png'
  FwvXYWOkfuailQMemSKrjNdGBVIJgt=xbmcgui.ListItem(FwvXYWOkfuailQMemSKrjNdGBVIJgh)
  if FwvXYWOkfuailQMemSKrjNdGBVIJyb(img)==FwvXYWOkfuailQMemSKrjNdGBVIJsc:
   FwvXYWOkfuailQMemSKrjNdGBVIJgt.setArt(img)
  else:
   FwvXYWOkfuailQMemSKrjNdGBVIJgt.setArt({'thumb':img,'poster':img})
  if FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.KodiVersion>=20:
   if infoLabels:FwvXYWOkfuailQMemSKrjNdGBVIJcA.Set_InfoTag(FwvXYWOkfuailQMemSKrjNdGBVIJgt.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:FwvXYWOkfuailQMemSKrjNdGBVIJgt.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   FwvXYWOkfuailQMemSKrjNdGBVIJgt.setProperty('IsPlayable','true')
  if ContextMenu:FwvXYWOkfuailQMemSKrjNdGBVIJgt.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,FwvXYWOkfuailQMemSKrjNdGBVIJgp,FwvXYWOkfuailQMemSKrjNdGBVIJgt,isFolder)
 def get_selQuality(FwvXYWOkfuailQMemSKrjNdGBVIJcA,etype):
  try:
   FwvXYWOkfuailQMemSKrjNdGBVIJgn='selected_quality'
   FwvXYWOkfuailQMemSKrjNdGBVIJgq=[1080,720,480,360]
   FwvXYWOkfuailQMemSKrjNdGBVIJgU=FwvXYWOkfuailQMemSKrjNdGBVIJyU(__addon__.getSetting(FwvXYWOkfuailQMemSKrjNdGBVIJgn))
   return FwvXYWOkfuailQMemSKrjNdGBVIJgq[FwvXYWOkfuailQMemSKrjNdGBVIJgU]
  except:
   FwvXYWOkfuailQMemSKrjNdGBVIJyq
  return 720 
 def Set_InfoTag(FwvXYWOkfuailQMemSKrjNdGBVIJcA,video_InfoTag:xbmc.InfoTagVideo,FwvXYWOkfuailQMemSKrjNdGBVIJLT):
  for FwvXYWOkfuailQMemSKrjNdGBVIJgx,value in FwvXYWOkfuailQMemSKrjNdGBVIJLT.items():
   if FwvXYWOkfuailQMemSKrjNdGBVIJcC[FwvXYWOkfuailQMemSKrjNdGBVIJgx]['type']=='string':
    FwvXYWOkfuailQMemSKrjNdGBVIJsg(video_InfoTag,FwvXYWOkfuailQMemSKrjNdGBVIJcC[FwvXYWOkfuailQMemSKrjNdGBVIJgx]['func'])(value)
   elif FwvXYWOkfuailQMemSKrjNdGBVIJcC[FwvXYWOkfuailQMemSKrjNdGBVIJgx]['type']=='int':
    if FwvXYWOkfuailQMemSKrjNdGBVIJyb(value)==FwvXYWOkfuailQMemSKrjNdGBVIJyU:
     FwvXYWOkfuailQMemSKrjNdGBVIJgP=FwvXYWOkfuailQMemSKrjNdGBVIJyU(value)
    else:
     FwvXYWOkfuailQMemSKrjNdGBVIJgP=0
    FwvXYWOkfuailQMemSKrjNdGBVIJsg(video_InfoTag,FwvXYWOkfuailQMemSKrjNdGBVIJcC[FwvXYWOkfuailQMemSKrjNdGBVIJgx]['func'])(FwvXYWOkfuailQMemSKrjNdGBVIJgP)
   elif FwvXYWOkfuailQMemSKrjNdGBVIJcC[FwvXYWOkfuailQMemSKrjNdGBVIJgx]['type']=='actor':
    if value!=[]:
     FwvXYWOkfuailQMemSKrjNdGBVIJsg(video_InfoTag,FwvXYWOkfuailQMemSKrjNdGBVIJcC[FwvXYWOkfuailQMemSKrjNdGBVIJgx]['func'])([xbmc.Actor(name)for name in value])
   elif FwvXYWOkfuailQMemSKrjNdGBVIJcC[FwvXYWOkfuailQMemSKrjNdGBVIJgx]['type']=='list':
    if FwvXYWOkfuailQMemSKrjNdGBVIJyb(value)==FwvXYWOkfuailQMemSKrjNdGBVIJsL:
     FwvXYWOkfuailQMemSKrjNdGBVIJsg(video_InfoTag,FwvXYWOkfuailQMemSKrjNdGBVIJcC[FwvXYWOkfuailQMemSKrjNdGBVIJgx]['func'])(value)
    else:
     FwvXYWOkfuailQMemSKrjNdGBVIJsg(video_InfoTag,FwvXYWOkfuailQMemSKrjNdGBVIJcC[FwvXYWOkfuailQMemSKrjNdGBVIJgx]['func'])([value])
 def dp_Main_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  (FwvXYWOkfuailQMemSKrjNdGBVIJgz,FwvXYWOkfuailQMemSKrjNdGBVIJgy,FwvXYWOkfuailQMemSKrjNdGBVIJgs,FwvXYWOkfuailQMemSKrjNdGBVIJgC,FwvXYWOkfuailQMemSKrjNdGBVIJgD)=FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_totalsearch()
  for FwvXYWOkfuailQMemSKrjNdGBVIJgb in FwvXYWOkfuailQMemSKrjNdGBVIJcL:
   FwvXYWOkfuailQMemSKrjNdGBVIJgh=FwvXYWOkfuailQMemSKrjNdGBVIJgb.get('title')
   FwvXYWOkfuailQMemSKrjNdGBVIJLc=''
   if FwvXYWOkfuailQMemSKrjNdGBVIJgb.get('mode')=='SEARCH_GROUP' and FwvXYWOkfuailQMemSKrjNdGBVIJgz ==FwvXYWOkfuailQMemSKrjNdGBVIJyP:continue
   elif FwvXYWOkfuailQMemSKrjNdGBVIJgb.get('mode')=='SEARCH_HISTORY' and FwvXYWOkfuailQMemSKrjNdGBVIJgy==FwvXYWOkfuailQMemSKrjNdGBVIJyP:continue
   elif FwvXYWOkfuailQMemSKrjNdGBVIJgb.get('mode')=='TOTAL_SEARCH' and FwvXYWOkfuailQMemSKrjNdGBVIJgs ==FwvXYWOkfuailQMemSKrjNdGBVIJyP:continue
   elif FwvXYWOkfuailQMemSKrjNdGBVIJgb.get('mode')=='TOTAL_HISTORY' and FwvXYWOkfuailQMemSKrjNdGBVIJgC==FwvXYWOkfuailQMemSKrjNdGBVIJyP:continue
   elif FwvXYWOkfuailQMemSKrjNdGBVIJgb.get('mode')=='MENU_BOOKMARK' and FwvXYWOkfuailQMemSKrjNdGBVIJgD==FwvXYWOkfuailQMemSKrjNdGBVIJyP:continue
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':FwvXYWOkfuailQMemSKrjNdGBVIJgb.get('mode'),'stype':FwvXYWOkfuailQMemSKrjNdGBVIJgb.get('stype'),'orderby':FwvXYWOkfuailQMemSKrjNdGBVIJgb.get('orderby'),'ordernm':FwvXYWOkfuailQMemSKrjNdGBVIJgb.get('ordernm'),'page':'1'}
   if FwvXYWOkfuailQMemSKrjNdGBVIJgb.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    FwvXYWOkfuailQMemSKrjNdGBVIJLH=FwvXYWOkfuailQMemSKrjNdGBVIJyP
    FwvXYWOkfuailQMemSKrjNdGBVIJLR =FwvXYWOkfuailQMemSKrjNdGBVIJyx
   else:
    FwvXYWOkfuailQMemSKrjNdGBVIJLH=FwvXYWOkfuailQMemSKrjNdGBVIJyx
    FwvXYWOkfuailQMemSKrjNdGBVIJLR =FwvXYWOkfuailQMemSKrjNdGBVIJyP
   FwvXYWOkfuailQMemSKrjNdGBVIJLT={'title':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'plot':FwvXYWOkfuailQMemSKrjNdGBVIJgh}
   if FwvXYWOkfuailQMemSKrjNdGBVIJgb.get('mode')=='XXX':FwvXYWOkfuailQMemSKrjNdGBVIJLT=FwvXYWOkfuailQMemSKrjNdGBVIJyq
   if 'icon' in FwvXYWOkfuailQMemSKrjNdGBVIJgb:FwvXYWOkfuailQMemSKrjNdGBVIJLc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',FwvXYWOkfuailQMemSKrjNdGBVIJgb.get('icon')) 
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel='',img=FwvXYWOkfuailQMemSKrjNdGBVIJLc,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJLT,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJLH,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg,isLink=FwvXYWOkfuailQMemSKrjNdGBVIJLR)
  xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle)
 def login_main(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  (FwvXYWOkfuailQMemSKrjNdGBVIJLy,FwvXYWOkfuailQMemSKrjNdGBVIJLs,FwvXYWOkfuailQMemSKrjNdGBVIJLC,FwvXYWOkfuailQMemSKrjNdGBVIJLD)=FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_account()
  if not(FwvXYWOkfuailQMemSKrjNdGBVIJLy and FwvXYWOkfuailQMemSKrjNdGBVIJLs):
   FwvXYWOkfuailQMemSKrjNdGBVIJcn=xbmcgui.Dialog()
   FwvXYWOkfuailQMemSKrjNdGBVIJLo=FwvXYWOkfuailQMemSKrjNdGBVIJcn.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if FwvXYWOkfuailQMemSKrjNdGBVIJLo==FwvXYWOkfuailQMemSKrjNdGBVIJyx:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if FwvXYWOkfuailQMemSKrjNdGBVIJcA.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   FwvXYWOkfuailQMemSKrjNdGBVIJLA=0
   while FwvXYWOkfuailQMemSKrjNdGBVIJyx:
    FwvXYWOkfuailQMemSKrjNdGBVIJLA+=1
    time.sleep(0.05)
    if FwvXYWOkfuailQMemSKrjNdGBVIJLA>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  FwvXYWOkfuailQMemSKrjNdGBVIJLE=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.GetCredential(FwvXYWOkfuailQMemSKrjNdGBVIJLy,FwvXYWOkfuailQMemSKrjNdGBVIJLs,FwvXYWOkfuailQMemSKrjNdGBVIJLC,FwvXYWOkfuailQMemSKrjNdGBVIJLD)
  if FwvXYWOkfuailQMemSKrjNdGBVIJLE:FwvXYWOkfuailQMemSKrjNdGBVIJcA.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if FwvXYWOkfuailQMemSKrjNdGBVIJLE==FwvXYWOkfuailQMemSKrjNdGBVIJyP:
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJLp=FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('stype')
  if FwvXYWOkfuailQMemSKrjNdGBVIJLp=='live':
   FwvXYWOkfuailQMemSKrjNdGBVIJLh=FwvXYWOkfuailQMemSKrjNdGBVIJcH
  elif FwvXYWOkfuailQMemSKrjNdGBVIJLp=='vod':
   FwvXYWOkfuailQMemSKrjNdGBVIJLh=FwvXYWOkfuailQMemSKrjNdGBVIJcz
  else:
   FwvXYWOkfuailQMemSKrjNdGBVIJLh=FwvXYWOkfuailQMemSKrjNdGBVIJcy
  for FwvXYWOkfuailQMemSKrjNdGBVIJLt in FwvXYWOkfuailQMemSKrjNdGBVIJLh:
   FwvXYWOkfuailQMemSKrjNdGBVIJgh=FwvXYWOkfuailQMemSKrjNdGBVIJLt.get('title')
   if FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('ordernm')!='-':
    FwvXYWOkfuailQMemSKrjNdGBVIJgh+='  ('+FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('ordernm')+')'
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':FwvXYWOkfuailQMemSKrjNdGBVIJLt.get('mode'),'stype':FwvXYWOkfuailQMemSKrjNdGBVIJLt.get('stype'),'orderby':FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('orderby'),'ordernm':FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('ordernm'),'page':'1'}
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel='',img='',infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJyq,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  if FwvXYWOkfuailQMemSKrjNdGBVIJsH(FwvXYWOkfuailQMemSKrjNdGBVIJLh)>0:xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle)
 def dp_SubTitle_Group(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn): 
  for FwvXYWOkfuailQMemSKrjNdGBVIJLt in FwvXYWOkfuailQMemSKrjNdGBVIJcs:
   FwvXYWOkfuailQMemSKrjNdGBVIJgh=FwvXYWOkfuailQMemSKrjNdGBVIJLt.get('title')
   if FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('ordernm')!='-':
    FwvXYWOkfuailQMemSKrjNdGBVIJgh+='  ('+FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('ordernm')+')'
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':FwvXYWOkfuailQMemSKrjNdGBVIJLt.get('mode'),'genreCode':FwvXYWOkfuailQMemSKrjNdGBVIJLt.get('genreCode'),'stype':FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('stype'),'orderby':FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('orderby'),'page':'1'}
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel='',img='',infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJyq,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  if FwvXYWOkfuailQMemSKrjNdGBVIJsH(FwvXYWOkfuailQMemSKrjNdGBVIJcs)>0:xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle)
 def dp_LiveChannel_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJLp =FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('stype')
  FwvXYWOkfuailQMemSKrjNdGBVIJLq =FwvXYWOkfuailQMemSKrjNdGBVIJyU(FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('page'))
  FwvXYWOkfuailQMemSKrjNdGBVIJLU,FwvXYWOkfuailQMemSKrjNdGBVIJLx=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.GetLiveChannelList(FwvXYWOkfuailQMemSKrjNdGBVIJLp,FwvXYWOkfuailQMemSKrjNdGBVIJLq)
  for FwvXYWOkfuailQMemSKrjNdGBVIJLP in FwvXYWOkfuailQMemSKrjNdGBVIJLU:
   FwvXYWOkfuailQMemSKrjNdGBVIJgh =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('title')
   FwvXYWOkfuailQMemSKrjNdGBVIJLz =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('channel')
   FwvXYWOkfuailQMemSKrjNdGBVIJLb =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('thumbnail')
   FwvXYWOkfuailQMemSKrjNdGBVIJHc =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('synopsis')
   FwvXYWOkfuailQMemSKrjNdGBVIJHg =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('channelepg')
   FwvXYWOkfuailQMemSKrjNdGBVIJHL =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('cast')
   FwvXYWOkfuailQMemSKrjNdGBVIJHR =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('director')
   FwvXYWOkfuailQMemSKrjNdGBVIJHT =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('info_genre')
   FwvXYWOkfuailQMemSKrjNdGBVIJHz =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('year')
   FwvXYWOkfuailQMemSKrjNdGBVIJHy =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('mpaa')
   FwvXYWOkfuailQMemSKrjNdGBVIJHs =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('premiered')
   FwvXYWOkfuailQMemSKrjNdGBVIJHC={'mediatype':'episode','title':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'studio':FwvXYWOkfuailQMemSKrjNdGBVIJLz,'cast':FwvXYWOkfuailQMemSKrjNdGBVIJHL,'director':FwvXYWOkfuailQMemSKrjNdGBVIJHR,'genre':FwvXYWOkfuailQMemSKrjNdGBVIJHT,'plot':'%s\n%s\n%s\n\n%s'%(FwvXYWOkfuailQMemSKrjNdGBVIJLz,FwvXYWOkfuailQMemSKrjNdGBVIJgh,FwvXYWOkfuailQMemSKrjNdGBVIJHg,FwvXYWOkfuailQMemSKrjNdGBVIJHc),'year':FwvXYWOkfuailQMemSKrjNdGBVIJHz,'mpaa':FwvXYWOkfuailQMemSKrjNdGBVIJHy,'premiered':FwvXYWOkfuailQMemSKrjNdGBVIJHs}
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'LIVE','mediacode':FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('mediacode'),'stype':FwvXYWOkfuailQMemSKrjNdGBVIJLp}
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJLz,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJgh,img=FwvXYWOkfuailQMemSKrjNdGBVIJLb,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJHC,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyP,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  if FwvXYWOkfuailQMemSKrjNdGBVIJLx:
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['mode']='CHANNEL' 
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['stype']=FwvXYWOkfuailQMemSKrjNdGBVIJLp 
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['page']=FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJgh='[B]%s >>[/B]'%'다음 페이지'
   FwvXYWOkfuailQMemSKrjNdGBVIJHD=FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJLc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJHD,img=FwvXYWOkfuailQMemSKrjNdGBVIJLc,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJyq,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  if FwvXYWOkfuailQMemSKrjNdGBVIJsH(FwvXYWOkfuailQMemSKrjNdGBVIJLU)>0:xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,cacheToDisc=FwvXYWOkfuailQMemSKrjNdGBVIJyP)
 def dp_Program_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJHo =FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('stype')
  FwvXYWOkfuailQMemSKrjNdGBVIJgE =FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('orderby')
  FwvXYWOkfuailQMemSKrjNdGBVIJLq =FwvXYWOkfuailQMemSKrjNdGBVIJyU(FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('page'))
  FwvXYWOkfuailQMemSKrjNdGBVIJHA=FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('genreCode')
  if FwvXYWOkfuailQMemSKrjNdGBVIJHA==FwvXYWOkfuailQMemSKrjNdGBVIJyq:FwvXYWOkfuailQMemSKrjNdGBVIJHA='all'
  FwvXYWOkfuailQMemSKrjNdGBVIJHE,FwvXYWOkfuailQMemSKrjNdGBVIJLx=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.GetProgramList(FwvXYWOkfuailQMemSKrjNdGBVIJHo,FwvXYWOkfuailQMemSKrjNdGBVIJgE,FwvXYWOkfuailQMemSKrjNdGBVIJLq,FwvXYWOkfuailQMemSKrjNdGBVIJHA)
  for FwvXYWOkfuailQMemSKrjNdGBVIJHp in FwvXYWOkfuailQMemSKrjNdGBVIJHE:
   FwvXYWOkfuailQMemSKrjNdGBVIJgh =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('title')
   FwvXYWOkfuailQMemSKrjNdGBVIJLb =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('thumbnail')
   FwvXYWOkfuailQMemSKrjNdGBVIJHc =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('synopsis')
   FwvXYWOkfuailQMemSKrjNdGBVIJHh =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('channel')
   FwvXYWOkfuailQMemSKrjNdGBVIJHL =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('cast')
   FwvXYWOkfuailQMemSKrjNdGBVIJHR =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('director')
   FwvXYWOkfuailQMemSKrjNdGBVIJHT=FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('info_genre')
   FwvXYWOkfuailQMemSKrjNdGBVIJHz =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('year')
   FwvXYWOkfuailQMemSKrjNdGBVIJHs =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('premiered')
   FwvXYWOkfuailQMemSKrjNdGBVIJHy =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('mpaa')
   FwvXYWOkfuailQMemSKrjNdGBVIJHC={'mediatype':'tvshow','title':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'studio':FwvXYWOkfuailQMemSKrjNdGBVIJHh,'cast':FwvXYWOkfuailQMemSKrjNdGBVIJHL,'director':FwvXYWOkfuailQMemSKrjNdGBVIJHR,'genre':FwvXYWOkfuailQMemSKrjNdGBVIJHT,'year':FwvXYWOkfuailQMemSKrjNdGBVIJHz,'premiered':FwvXYWOkfuailQMemSKrjNdGBVIJHs,'mpaa':FwvXYWOkfuailQMemSKrjNdGBVIJHy,'plot':FwvXYWOkfuailQMemSKrjNdGBVIJHc}
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'EPISODE','programcode':FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('program'),'page':'1'}
   if FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_makebookmark():
    FwvXYWOkfuailQMemSKrjNdGBVIJHt={'videoid':FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('program'),'vidtype':'tvshow','vtitle':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'vsubtitle':FwvXYWOkfuailQMemSKrjNdGBVIJHh,}
    FwvXYWOkfuailQMemSKrjNdGBVIJHn=json.dumps(FwvXYWOkfuailQMemSKrjNdGBVIJHt)
    FwvXYWOkfuailQMemSKrjNdGBVIJHn=urllib.parse.quote(FwvXYWOkfuailQMemSKrjNdGBVIJHn)
    FwvXYWOkfuailQMemSKrjNdGBVIJHq='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(FwvXYWOkfuailQMemSKrjNdGBVIJHn)
    FwvXYWOkfuailQMemSKrjNdGBVIJHU=[('(통합) 찜 영상에 추가',FwvXYWOkfuailQMemSKrjNdGBVIJHq)]
   else:
    FwvXYWOkfuailQMemSKrjNdGBVIJHU=FwvXYWOkfuailQMemSKrjNdGBVIJyq
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJHh,img=FwvXYWOkfuailQMemSKrjNdGBVIJLb,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJHC,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg,ContextMenu=FwvXYWOkfuailQMemSKrjNdGBVIJHU)
  if FwvXYWOkfuailQMemSKrjNdGBVIJLx:
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['mode'] ='PROGRAM' 
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['stype'] =FwvXYWOkfuailQMemSKrjNdGBVIJHo
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['orderby'] =FwvXYWOkfuailQMemSKrjNdGBVIJgE
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['page'] =FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['genreCode']=FwvXYWOkfuailQMemSKrjNdGBVIJHA 
   FwvXYWOkfuailQMemSKrjNdGBVIJgh='[B]%s >>[/B]'%'다음 페이지'
   FwvXYWOkfuailQMemSKrjNdGBVIJHD=FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJLc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJHD,img=FwvXYWOkfuailQMemSKrjNdGBVIJLc,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJyq,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  xbmcplugin.setContent(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,cacheToDisc=FwvXYWOkfuailQMemSKrjNdGBVIJyP)
 def dp_4K_Program_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJLq =FwvXYWOkfuailQMemSKrjNdGBVIJyU(FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('page'))
  FwvXYWOkfuailQMemSKrjNdGBVIJHE,FwvXYWOkfuailQMemSKrjNdGBVIJLx=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Get_UHD_ProgramList(FwvXYWOkfuailQMemSKrjNdGBVIJLq)
  for FwvXYWOkfuailQMemSKrjNdGBVIJHp in FwvXYWOkfuailQMemSKrjNdGBVIJHE:
   FwvXYWOkfuailQMemSKrjNdGBVIJgh =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('title')
   FwvXYWOkfuailQMemSKrjNdGBVIJLb =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('thumbnail')
   FwvXYWOkfuailQMemSKrjNdGBVIJHc =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('synopsis')
   FwvXYWOkfuailQMemSKrjNdGBVIJHh =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('channel')
   FwvXYWOkfuailQMemSKrjNdGBVIJHL =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('cast')
   FwvXYWOkfuailQMemSKrjNdGBVIJHR =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('director')
   FwvXYWOkfuailQMemSKrjNdGBVIJHT=FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('info_genre')
   FwvXYWOkfuailQMemSKrjNdGBVIJHz =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('year')
   FwvXYWOkfuailQMemSKrjNdGBVIJHs =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('premiered')
   FwvXYWOkfuailQMemSKrjNdGBVIJHy =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('mpaa')
   FwvXYWOkfuailQMemSKrjNdGBVIJHC={'mediatype':'tvshow','title':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'studio':FwvXYWOkfuailQMemSKrjNdGBVIJHh,'cast':FwvXYWOkfuailQMemSKrjNdGBVIJHL,'director':FwvXYWOkfuailQMemSKrjNdGBVIJHR,'genre':FwvXYWOkfuailQMemSKrjNdGBVIJHT,'year':FwvXYWOkfuailQMemSKrjNdGBVIJHz,'premiered':FwvXYWOkfuailQMemSKrjNdGBVIJHs,'mpaa':FwvXYWOkfuailQMemSKrjNdGBVIJHy,'plot':FwvXYWOkfuailQMemSKrjNdGBVIJHc}
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'EPISODE','programcode':FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('program'),'page':'1'}
   if FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_makebookmark():
    FwvXYWOkfuailQMemSKrjNdGBVIJHt={'videoid':FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('program'),'vidtype':'tvshow','vtitle':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'vsubtitle':FwvXYWOkfuailQMemSKrjNdGBVIJHh,}
    FwvXYWOkfuailQMemSKrjNdGBVIJHn=json.dumps(FwvXYWOkfuailQMemSKrjNdGBVIJHt)
    FwvXYWOkfuailQMemSKrjNdGBVIJHn=urllib.parse.quote(FwvXYWOkfuailQMemSKrjNdGBVIJHn)
    FwvXYWOkfuailQMemSKrjNdGBVIJHq='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(FwvXYWOkfuailQMemSKrjNdGBVIJHn)
    FwvXYWOkfuailQMemSKrjNdGBVIJHU=[('(통합) 찜 영상에 추가',FwvXYWOkfuailQMemSKrjNdGBVIJHq)]
   else:
    FwvXYWOkfuailQMemSKrjNdGBVIJHU=FwvXYWOkfuailQMemSKrjNdGBVIJyq
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJHh,img=FwvXYWOkfuailQMemSKrjNdGBVIJLb,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJHC,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg,ContextMenu=FwvXYWOkfuailQMemSKrjNdGBVIJHU)
  if FwvXYWOkfuailQMemSKrjNdGBVIJLx:
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['mode'] ='4K_PROGRAM' 
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['page'] =FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJgh='[B]%s >>[/B]'%'다음 페이지'
   FwvXYWOkfuailQMemSKrjNdGBVIJHD=FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJLc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJHD,img=FwvXYWOkfuailQMemSKrjNdGBVIJLc,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJyq,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  xbmcplugin.setContent(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,cacheToDisc=FwvXYWOkfuailQMemSKrjNdGBVIJyP)
 def dp_Ori_Program_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJLq =FwvXYWOkfuailQMemSKrjNdGBVIJyU(FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('page'))
  FwvXYWOkfuailQMemSKrjNdGBVIJHE,FwvXYWOkfuailQMemSKrjNdGBVIJLx=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Get_Origianl_ProgramList(FwvXYWOkfuailQMemSKrjNdGBVIJLq)
  for FwvXYWOkfuailQMemSKrjNdGBVIJHp in FwvXYWOkfuailQMemSKrjNdGBVIJHE:
   FwvXYWOkfuailQMemSKrjNdGBVIJgh =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('title')
   FwvXYWOkfuailQMemSKrjNdGBVIJLb =FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('thumbnail')
   FwvXYWOkfuailQMemSKrjNdGBVIJHC={'mediatype':'tvshow','title':FwvXYWOkfuailQMemSKrjNdGBVIJgh,}
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'EPISODE','programcode':FwvXYWOkfuailQMemSKrjNdGBVIJHp.get('program'),'page':'1',}
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJyq,img=FwvXYWOkfuailQMemSKrjNdGBVIJLb,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJHC,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg,ContextMenu=FwvXYWOkfuailQMemSKrjNdGBVIJyq)
  if FwvXYWOkfuailQMemSKrjNdGBVIJLx:
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['mode'] ='ORI_PROGRAM' 
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['page'] =FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJgh='[B]%s >>[/B]'%'다음 페이지'
   FwvXYWOkfuailQMemSKrjNdGBVIJHD=FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJLc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJHD,img=FwvXYWOkfuailQMemSKrjNdGBVIJLc,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJyq,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  xbmcplugin.setContent(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,cacheToDisc=FwvXYWOkfuailQMemSKrjNdGBVIJyP)
 def dp_Episode_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJHP=FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('programcode')
  FwvXYWOkfuailQMemSKrjNdGBVIJLq =FwvXYWOkfuailQMemSKrjNdGBVIJyU(FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('page'))
  FwvXYWOkfuailQMemSKrjNdGBVIJHb,FwvXYWOkfuailQMemSKrjNdGBVIJLx,FwvXYWOkfuailQMemSKrjNdGBVIJRc=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.GetEpisodeList(FwvXYWOkfuailQMemSKrjNdGBVIJHP,FwvXYWOkfuailQMemSKrjNdGBVIJLq,orderby=FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_winEpisodeOrderby())
  for FwvXYWOkfuailQMemSKrjNdGBVIJRg in FwvXYWOkfuailQMemSKrjNdGBVIJHb:
   FwvXYWOkfuailQMemSKrjNdGBVIJgh =FwvXYWOkfuailQMemSKrjNdGBVIJRg.get('title')
   FwvXYWOkfuailQMemSKrjNdGBVIJHD =FwvXYWOkfuailQMemSKrjNdGBVIJRg.get('subtitle')
   FwvXYWOkfuailQMemSKrjNdGBVIJLb =FwvXYWOkfuailQMemSKrjNdGBVIJRg.get('thumbnail')
   FwvXYWOkfuailQMemSKrjNdGBVIJHc =FwvXYWOkfuailQMemSKrjNdGBVIJRg.get('synopsis')
   FwvXYWOkfuailQMemSKrjNdGBVIJRL=FwvXYWOkfuailQMemSKrjNdGBVIJRg.get('info_title')
   FwvXYWOkfuailQMemSKrjNdGBVIJRH =FwvXYWOkfuailQMemSKrjNdGBVIJRg.get('aired')
   FwvXYWOkfuailQMemSKrjNdGBVIJRT =FwvXYWOkfuailQMemSKrjNdGBVIJRg.get('studio')
   FwvXYWOkfuailQMemSKrjNdGBVIJRz =FwvXYWOkfuailQMemSKrjNdGBVIJRg.get('frequency')
   FwvXYWOkfuailQMemSKrjNdGBVIJHC={'mediatype':'episode','title':FwvXYWOkfuailQMemSKrjNdGBVIJRL,'aired':FwvXYWOkfuailQMemSKrjNdGBVIJRH,'studio':FwvXYWOkfuailQMemSKrjNdGBVIJRT,'episode':FwvXYWOkfuailQMemSKrjNdGBVIJRz,'plot':FwvXYWOkfuailQMemSKrjNdGBVIJHc}
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'VOD','mediacode':FwvXYWOkfuailQMemSKrjNdGBVIJRg.get('episode'),'stype':'vod','programcode':FwvXYWOkfuailQMemSKrjNdGBVIJHP,'title':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'thumbnail':FwvXYWOkfuailQMemSKrjNdGBVIJLb}
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJHD,img=FwvXYWOkfuailQMemSKrjNdGBVIJLb,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJHC,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyP,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  if FwvXYWOkfuailQMemSKrjNdGBVIJLq==1:
   FwvXYWOkfuailQMemSKrjNdGBVIJHC={'plot':'정렬순서를 변경합니다.'}
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={}
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['mode'] ='ORDER_BY' 
   if FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_winEpisodeOrderby()=='desc':
    FwvXYWOkfuailQMemSKrjNdGBVIJgh='정렬순서변경 : 최신화부터 -> 1회부터'
    FwvXYWOkfuailQMemSKrjNdGBVIJLg['orderby']='asc'
   else:
    FwvXYWOkfuailQMemSKrjNdGBVIJgh='정렬순서변경 : 1회부터 -> 최신화부터'
    FwvXYWOkfuailQMemSKrjNdGBVIJLg['orderby']='desc'
   FwvXYWOkfuailQMemSKrjNdGBVIJLc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel='',img=FwvXYWOkfuailQMemSKrjNdGBVIJLc,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJHC,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyP,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg,isLink=FwvXYWOkfuailQMemSKrjNdGBVIJyx)
  if FwvXYWOkfuailQMemSKrjNdGBVIJLx:
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['mode'] ='EPISODE' 
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['programcode']=FwvXYWOkfuailQMemSKrjNdGBVIJHP
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['page'] =FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJgh='[B]%s >>[/B]'%'다음 페이지'
   FwvXYWOkfuailQMemSKrjNdGBVIJHD=FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJLc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJHD,img=FwvXYWOkfuailQMemSKrjNdGBVIJLc,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJyq,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  xbmcplugin.setContent(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,'episodes')
  if FwvXYWOkfuailQMemSKrjNdGBVIJsH(FwvXYWOkfuailQMemSKrjNdGBVIJHb)>0:xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,cacheToDisc=FwvXYWOkfuailQMemSKrjNdGBVIJyx)
 def dp_setEpOrderby(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJgE =FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('orderby')
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.set_winEpisodeOrderby(FwvXYWOkfuailQMemSKrjNdGBVIJgE)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJHo =FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('stype')
  FwvXYWOkfuailQMemSKrjNdGBVIJgE =FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('orderby')
  FwvXYWOkfuailQMemSKrjNdGBVIJLq=FwvXYWOkfuailQMemSKrjNdGBVIJyU(FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('page'))
  FwvXYWOkfuailQMemSKrjNdGBVIJRy,FwvXYWOkfuailQMemSKrjNdGBVIJLx=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.GetMovieList(FwvXYWOkfuailQMemSKrjNdGBVIJHo,FwvXYWOkfuailQMemSKrjNdGBVIJgE,FwvXYWOkfuailQMemSKrjNdGBVIJLq)
  for FwvXYWOkfuailQMemSKrjNdGBVIJRs in FwvXYWOkfuailQMemSKrjNdGBVIJRy:
   FwvXYWOkfuailQMemSKrjNdGBVIJgh =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('title')
   FwvXYWOkfuailQMemSKrjNdGBVIJLb =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('thumbnail')
   FwvXYWOkfuailQMemSKrjNdGBVIJHc =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('synopsis')
   FwvXYWOkfuailQMemSKrjNdGBVIJRL =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('info_title')
   FwvXYWOkfuailQMemSKrjNdGBVIJHz =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('year')
   FwvXYWOkfuailQMemSKrjNdGBVIJHL =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('cast')
   FwvXYWOkfuailQMemSKrjNdGBVIJHR =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('director')
   FwvXYWOkfuailQMemSKrjNdGBVIJHT =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('info_genre')
   FwvXYWOkfuailQMemSKrjNdGBVIJRC =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('duration')
   FwvXYWOkfuailQMemSKrjNdGBVIJHs =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('premiered')
   FwvXYWOkfuailQMemSKrjNdGBVIJRT =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('studio')
   FwvXYWOkfuailQMemSKrjNdGBVIJHy =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('mpaa')
   FwvXYWOkfuailQMemSKrjNdGBVIJHC={'mediatype':'movie','title':FwvXYWOkfuailQMemSKrjNdGBVIJRL,'year':FwvXYWOkfuailQMemSKrjNdGBVIJHz,'cast':FwvXYWOkfuailQMemSKrjNdGBVIJHL,'director':FwvXYWOkfuailQMemSKrjNdGBVIJHR,'genre':FwvXYWOkfuailQMemSKrjNdGBVIJHT,'duration':FwvXYWOkfuailQMemSKrjNdGBVIJRC,'premiered':FwvXYWOkfuailQMemSKrjNdGBVIJHs,'studio':FwvXYWOkfuailQMemSKrjNdGBVIJRT,'mpaa':FwvXYWOkfuailQMemSKrjNdGBVIJHy,'plot':FwvXYWOkfuailQMemSKrjNdGBVIJHc}
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'MOVIE','mediacode':FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('moviecode'),'stype':'movie','title':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'thumbnail':FwvXYWOkfuailQMemSKrjNdGBVIJLb}
   if FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_makebookmark():
    FwvXYWOkfuailQMemSKrjNdGBVIJHt={'videoid':FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('moviecode'),'vidtype':'movie','vtitle':FwvXYWOkfuailQMemSKrjNdGBVIJRL,'vsubtitle':'',}
    FwvXYWOkfuailQMemSKrjNdGBVIJHn=json.dumps(FwvXYWOkfuailQMemSKrjNdGBVIJHt)
    FwvXYWOkfuailQMemSKrjNdGBVIJHn=urllib.parse.quote(FwvXYWOkfuailQMemSKrjNdGBVIJHn)
    FwvXYWOkfuailQMemSKrjNdGBVIJHq='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(FwvXYWOkfuailQMemSKrjNdGBVIJHn)
    FwvXYWOkfuailQMemSKrjNdGBVIJHU=[('(통합) 찜 영상에 추가',FwvXYWOkfuailQMemSKrjNdGBVIJHq)]
   else:
    FwvXYWOkfuailQMemSKrjNdGBVIJHU=FwvXYWOkfuailQMemSKrjNdGBVIJyq
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel='',img=FwvXYWOkfuailQMemSKrjNdGBVIJLb,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJHC,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyP,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg,ContextMenu=FwvXYWOkfuailQMemSKrjNdGBVIJHU)
  if FwvXYWOkfuailQMemSKrjNdGBVIJLx:
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={}
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['mode'] ='MOVIE_SUB' 
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['orderby']=FwvXYWOkfuailQMemSKrjNdGBVIJgE
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['stype'] =FwvXYWOkfuailQMemSKrjNdGBVIJHo
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['page'] =FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJgh='[B]%s >>[/B]'%'다음 페이지'
   FwvXYWOkfuailQMemSKrjNdGBVIJHD=FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJLc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJHD,img=FwvXYWOkfuailQMemSKrjNdGBVIJLc,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJyq,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  xbmcplugin.setContent(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,'movies')
  xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,cacheToDisc=FwvXYWOkfuailQMemSKrjNdGBVIJyP)
 def dp_4K_Movie_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJLq=FwvXYWOkfuailQMemSKrjNdGBVIJyU(FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('page'))
  FwvXYWOkfuailQMemSKrjNdGBVIJRy,FwvXYWOkfuailQMemSKrjNdGBVIJLx=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Get_UHD_MovieList(FwvXYWOkfuailQMemSKrjNdGBVIJLq)
  for FwvXYWOkfuailQMemSKrjNdGBVIJRs in FwvXYWOkfuailQMemSKrjNdGBVIJRy:
   FwvXYWOkfuailQMemSKrjNdGBVIJgh =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('title')
   FwvXYWOkfuailQMemSKrjNdGBVIJLb =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('thumbnail')
   FwvXYWOkfuailQMemSKrjNdGBVIJHc =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('synopsis')
   FwvXYWOkfuailQMemSKrjNdGBVIJRL =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('info_title')
   FwvXYWOkfuailQMemSKrjNdGBVIJHz =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('year')
   FwvXYWOkfuailQMemSKrjNdGBVIJHL =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('cast')
   FwvXYWOkfuailQMemSKrjNdGBVIJHR =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('director')
   FwvXYWOkfuailQMemSKrjNdGBVIJHT =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('info_genre')
   FwvXYWOkfuailQMemSKrjNdGBVIJRC =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('duration')
   FwvXYWOkfuailQMemSKrjNdGBVIJHs =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('premiered')
   FwvXYWOkfuailQMemSKrjNdGBVIJRT =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('studio')
   FwvXYWOkfuailQMemSKrjNdGBVIJHy =FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('mpaa')
   FwvXYWOkfuailQMemSKrjNdGBVIJHC={'mediatype':'movie','title':FwvXYWOkfuailQMemSKrjNdGBVIJRL,'year':FwvXYWOkfuailQMemSKrjNdGBVIJHz,'cast':FwvXYWOkfuailQMemSKrjNdGBVIJHL,'director':FwvXYWOkfuailQMemSKrjNdGBVIJHR,'genre':FwvXYWOkfuailQMemSKrjNdGBVIJHT,'duration':FwvXYWOkfuailQMemSKrjNdGBVIJRC,'premiered':FwvXYWOkfuailQMemSKrjNdGBVIJHs,'studio':FwvXYWOkfuailQMemSKrjNdGBVIJRT,'mpaa':FwvXYWOkfuailQMemSKrjNdGBVIJHy,'plot':FwvXYWOkfuailQMemSKrjNdGBVIJHc}
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'MOVIE','mediacode':FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('moviecode'),'stype':'movie','title':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'thumbnail':FwvXYWOkfuailQMemSKrjNdGBVIJLb}
   if FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_makebookmark():
    FwvXYWOkfuailQMemSKrjNdGBVIJHt={'videoid':FwvXYWOkfuailQMemSKrjNdGBVIJRs.get('moviecode'),'vidtype':'movie','vtitle':FwvXYWOkfuailQMemSKrjNdGBVIJRL,'vsubtitle':'',}
    FwvXYWOkfuailQMemSKrjNdGBVIJHn=json.dumps(FwvXYWOkfuailQMemSKrjNdGBVIJHt)
    FwvXYWOkfuailQMemSKrjNdGBVIJHn=urllib.parse.quote(FwvXYWOkfuailQMemSKrjNdGBVIJHn)
    FwvXYWOkfuailQMemSKrjNdGBVIJHq='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(FwvXYWOkfuailQMemSKrjNdGBVIJHn)
    FwvXYWOkfuailQMemSKrjNdGBVIJHU=[('(통합) 찜 영상에 추가',FwvXYWOkfuailQMemSKrjNdGBVIJHq)]
   else:
    FwvXYWOkfuailQMemSKrjNdGBVIJHU=FwvXYWOkfuailQMemSKrjNdGBVIJyq
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel='',img=FwvXYWOkfuailQMemSKrjNdGBVIJLb,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJHC,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyP,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg,ContextMenu=FwvXYWOkfuailQMemSKrjNdGBVIJHU)
  if FwvXYWOkfuailQMemSKrjNdGBVIJLx:
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={}
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['mode'] ='4K_MOVIE' 
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['page'] =FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJgh='[B]%s >>[/B]'%'다음 페이지'
   FwvXYWOkfuailQMemSKrjNdGBVIJHD=FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJLc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJHD,img=FwvXYWOkfuailQMemSKrjNdGBVIJLc,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJyq,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  xbmcplugin.setContent(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,'movies')
  xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,cacheToDisc=FwvXYWOkfuailQMemSKrjNdGBVIJyP)
 def dp_Set_Bookmark(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJRD=urllib.parse.unquote(FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('bm_param'))
  FwvXYWOkfuailQMemSKrjNdGBVIJRD=json.loads(FwvXYWOkfuailQMemSKrjNdGBVIJRD)
  FwvXYWOkfuailQMemSKrjNdGBVIJRo =FwvXYWOkfuailQMemSKrjNdGBVIJRD.get('videoid')
  FwvXYWOkfuailQMemSKrjNdGBVIJRA =FwvXYWOkfuailQMemSKrjNdGBVIJRD.get('vidtype')
  FwvXYWOkfuailQMemSKrjNdGBVIJRE =FwvXYWOkfuailQMemSKrjNdGBVIJRD.get('vtitle')
  FwvXYWOkfuailQMemSKrjNdGBVIJRp =FwvXYWOkfuailQMemSKrjNdGBVIJRD.get('vsubtitle')
  FwvXYWOkfuailQMemSKrjNdGBVIJcn=xbmcgui.Dialog()
  FwvXYWOkfuailQMemSKrjNdGBVIJLo=FwvXYWOkfuailQMemSKrjNdGBVIJcn.yesno(__language__(30913).encode('utf8'),FwvXYWOkfuailQMemSKrjNdGBVIJRE+' \n\n'+__language__(30914))
  if FwvXYWOkfuailQMemSKrjNdGBVIJLo==FwvXYWOkfuailQMemSKrjNdGBVIJyP:return
  FwvXYWOkfuailQMemSKrjNdGBVIJRh=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.GetBookmarkInfo(FwvXYWOkfuailQMemSKrjNdGBVIJRo,FwvXYWOkfuailQMemSKrjNdGBVIJRA)
  if FwvXYWOkfuailQMemSKrjNdGBVIJRp!='':
   FwvXYWOkfuailQMemSKrjNdGBVIJRh['saveinfo']['subtitle']=FwvXYWOkfuailQMemSKrjNdGBVIJRp 
   if FwvXYWOkfuailQMemSKrjNdGBVIJRA=='tvshow':FwvXYWOkfuailQMemSKrjNdGBVIJRh['saveinfo']['infoLabels']['studio']=FwvXYWOkfuailQMemSKrjNdGBVIJRp 
  FwvXYWOkfuailQMemSKrjNdGBVIJRt=json.dumps(FwvXYWOkfuailQMemSKrjNdGBVIJRh)
  FwvXYWOkfuailQMemSKrjNdGBVIJRt=urllib.parse.quote(FwvXYWOkfuailQMemSKrjNdGBVIJRt)
  FwvXYWOkfuailQMemSKrjNdGBVIJHq ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(FwvXYWOkfuailQMemSKrjNdGBVIJRt)
  xbmc.executebuiltin(FwvXYWOkfuailQMemSKrjNdGBVIJHq)
 def dp_Search_Group(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  if 'search_key' in FwvXYWOkfuailQMemSKrjNdGBVIJLn:
   FwvXYWOkfuailQMemSKrjNdGBVIJRn=FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('search_key')
  else:
   FwvXYWOkfuailQMemSKrjNdGBVIJRn=FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not FwvXYWOkfuailQMemSKrjNdGBVIJRn:
    return
  for FwvXYWOkfuailQMemSKrjNdGBVIJLt in FwvXYWOkfuailQMemSKrjNdGBVIJcT:
   FwvXYWOkfuailQMemSKrjNdGBVIJRq =FwvXYWOkfuailQMemSKrjNdGBVIJLt.get('mode')
   FwvXYWOkfuailQMemSKrjNdGBVIJLp=FwvXYWOkfuailQMemSKrjNdGBVIJLt.get('stype')
   FwvXYWOkfuailQMemSKrjNdGBVIJgh=FwvXYWOkfuailQMemSKrjNdGBVIJLt.get('title')
   (FwvXYWOkfuailQMemSKrjNdGBVIJRU,FwvXYWOkfuailQMemSKrjNdGBVIJLx)=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.GetSearchList(FwvXYWOkfuailQMemSKrjNdGBVIJRn,1,FwvXYWOkfuailQMemSKrjNdGBVIJLp)
   FwvXYWOkfuailQMemSKrjNdGBVIJLT={'plot':'검색어 : '+FwvXYWOkfuailQMemSKrjNdGBVIJRn+'\n\n'+FwvXYWOkfuailQMemSKrjNdGBVIJcA.Search_FreeList(FwvXYWOkfuailQMemSKrjNdGBVIJRU)}
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':FwvXYWOkfuailQMemSKrjNdGBVIJRq,'stype':FwvXYWOkfuailQMemSKrjNdGBVIJLp,'search_key':FwvXYWOkfuailQMemSKrjNdGBVIJRn,'page':'1',}
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel='',img='',infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJLT,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  if FwvXYWOkfuailQMemSKrjNdGBVIJsH(FwvXYWOkfuailQMemSKrjNdGBVIJcT)>0:xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,cacheToDisc=FwvXYWOkfuailQMemSKrjNdGBVIJyx)
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.Save_Searched_List(FwvXYWOkfuailQMemSKrjNdGBVIJRn)
 def Search_FreeList(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJTz):
  FwvXYWOkfuailQMemSKrjNdGBVIJRx=''
  FwvXYWOkfuailQMemSKrjNdGBVIJRP=7
  try:
   if FwvXYWOkfuailQMemSKrjNdGBVIJsH(FwvXYWOkfuailQMemSKrjNdGBVIJTz)==0:return '검색결과 없음'
   for i in FwvXYWOkfuailQMemSKrjNdGBVIJsT(FwvXYWOkfuailQMemSKrjNdGBVIJsH(FwvXYWOkfuailQMemSKrjNdGBVIJTz)):
    if i>=FwvXYWOkfuailQMemSKrjNdGBVIJRP:
     FwvXYWOkfuailQMemSKrjNdGBVIJRx=FwvXYWOkfuailQMemSKrjNdGBVIJRx+'...'
     break
    FwvXYWOkfuailQMemSKrjNdGBVIJRx=FwvXYWOkfuailQMemSKrjNdGBVIJRx+FwvXYWOkfuailQMemSKrjNdGBVIJTz[i]['title']+'\n'
  except:
   return ''
  return FwvXYWOkfuailQMemSKrjNdGBVIJRx
 def dp_Search_History(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJRb=FwvXYWOkfuailQMemSKrjNdGBVIJcA.Load_List_File('search')
  for FwvXYWOkfuailQMemSKrjNdGBVIJTc in FwvXYWOkfuailQMemSKrjNdGBVIJRb:
   FwvXYWOkfuailQMemSKrjNdGBVIJTg=FwvXYWOkfuailQMemSKrjNdGBVIJsc(urllib.parse.parse_qsl(FwvXYWOkfuailQMemSKrjNdGBVIJTc))
   FwvXYWOkfuailQMemSKrjNdGBVIJTL=FwvXYWOkfuailQMemSKrjNdGBVIJTg.get('skey').strip()
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'SEARCH_GROUP','search_key':FwvXYWOkfuailQMemSKrjNdGBVIJTL,}
   FwvXYWOkfuailQMemSKrjNdGBVIJTH={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':FwvXYWOkfuailQMemSKrjNdGBVIJTL,'vType':'-',}
   FwvXYWOkfuailQMemSKrjNdGBVIJTR=urllib.parse.urlencode(FwvXYWOkfuailQMemSKrjNdGBVIJTH)
   FwvXYWOkfuailQMemSKrjNdGBVIJHU=[('선택된 검색어 ( %s ) 삭제'%(FwvXYWOkfuailQMemSKrjNdGBVIJTL),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(FwvXYWOkfuailQMemSKrjNdGBVIJTR))]
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJTL,sublabel='',img=FwvXYWOkfuailQMemSKrjNdGBVIJyq,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJyq,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg,ContextMenu=FwvXYWOkfuailQMemSKrjNdGBVIJHU)
  FwvXYWOkfuailQMemSKrjNdGBVIJHC={'plot':'검색목록 전체를 삭제합니다.'}
  FwvXYWOkfuailQMemSKrjNdGBVIJgh='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  FwvXYWOkfuailQMemSKrjNdGBVIJLc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel='',img=FwvXYWOkfuailQMemSKrjNdGBVIJLc,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJHC,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyP,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg,isLink=FwvXYWOkfuailQMemSKrjNdGBVIJyx)
  xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,cacheToDisc=FwvXYWOkfuailQMemSKrjNdGBVIJyP)
 def dp_Search_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJLq =FwvXYWOkfuailQMemSKrjNdGBVIJyU(FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('page'))
  FwvXYWOkfuailQMemSKrjNdGBVIJLp =FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('stype')
  if 'search_key' in FwvXYWOkfuailQMemSKrjNdGBVIJLn:
   FwvXYWOkfuailQMemSKrjNdGBVIJRn=FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('search_key')
  else:
   FwvXYWOkfuailQMemSKrjNdGBVIJRn=FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not FwvXYWOkfuailQMemSKrjNdGBVIJRn:
    xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle)
    return
  FwvXYWOkfuailQMemSKrjNdGBVIJRU,FwvXYWOkfuailQMemSKrjNdGBVIJLx=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.GetSearchList(FwvXYWOkfuailQMemSKrjNdGBVIJRn,FwvXYWOkfuailQMemSKrjNdGBVIJLq,FwvXYWOkfuailQMemSKrjNdGBVIJLp)
  for FwvXYWOkfuailQMemSKrjNdGBVIJTz in FwvXYWOkfuailQMemSKrjNdGBVIJRU:
   FwvXYWOkfuailQMemSKrjNdGBVIJgh =FwvXYWOkfuailQMemSKrjNdGBVIJTz.get('title')
   FwvXYWOkfuailQMemSKrjNdGBVIJLb =FwvXYWOkfuailQMemSKrjNdGBVIJTz.get('thumbnail')
   FwvXYWOkfuailQMemSKrjNdGBVIJHc =FwvXYWOkfuailQMemSKrjNdGBVIJTz.get('synopsis')
   FwvXYWOkfuailQMemSKrjNdGBVIJTy =FwvXYWOkfuailQMemSKrjNdGBVIJTz.get('program')
   FwvXYWOkfuailQMemSKrjNdGBVIJHL =FwvXYWOkfuailQMemSKrjNdGBVIJTz.get('cast')
   FwvXYWOkfuailQMemSKrjNdGBVIJHR =FwvXYWOkfuailQMemSKrjNdGBVIJTz.get('director')
   FwvXYWOkfuailQMemSKrjNdGBVIJHT=FwvXYWOkfuailQMemSKrjNdGBVIJTz.get('info_genre')
   FwvXYWOkfuailQMemSKrjNdGBVIJRC =FwvXYWOkfuailQMemSKrjNdGBVIJTz.get('duration')
   FwvXYWOkfuailQMemSKrjNdGBVIJHy =FwvXYWOkfuailQMemSKrjNdGBVIJTz.get('mpaa')
   FwvXYWOkfuailQMemSKrjNdGBVIJHz =FwvXYWOkfuailQMemSKrjNdGBVIJTz.get('year')
   FwvXYWOkfuailQMemSKrjNdGBVIJRH =FwvXYWOkfuailQMemSKrjNdGBVIJTz.get('aired')
   FwvXYWOkfuailQMemSKrjNdGBVIJHC={'mediatype':'tvshow' if FwvXYWOkfuailQMemSKrjNdGBVIJLp=='vod' else 'movie','title':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'cast':FwvXYWOkfuailQMemSKrjNdGBVIJHL,'director':FwvXYWOkfuailQMemSKrjNdGBVIJHR,'genre':FwvXYWOkfuailQMemSKrjNdGBVIJHT,'duration':FwvXYWOkfuailQMemSKrjNdGBVIJRC,'mpaa':FwvXYWOkfuailQMemSKrjNdGBVIJHy,'year':FwvXYWOkfuailQMemSKrjNdGBVIJHz,'aired':FwvXYWOkfuailQMemSKrjNdGBVIJRH,'plot':'%s\n\n%s'%(FwvXYWOkfuailQMemSKrjNdGBVIJgh,FwvXYWOkfuailQMemSKrjNdGBVIJHc)}
   if FwvXYWOkfuailQMemSKrjNdGBVIJLp=='vod':
    FwvXYWOkfuailQMemSKrjNdGBVIJRo=FwvXYWOkfuailQMemSKrjNdGBVIJTz.get('program')
    FwvXYWOkfuailQMemSKrjNdGBVIJRA='tvshow'
    FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'EPISODE','programcode':FwvXYWOkfuailQMemSKrjNdGBVIJRo,'page':'1',}
    FwvXYWOkfuailQMemSKrjNdGBVIJLH=FwvXYWOkfuailQMemSKrjNdGBVIJyx
   else:
    FwvXYWOkfuailQMemSKrjNdGBVIJRo=FwvXYWOkfuailQMemSKrjNdGBVIJTz.get('movie')
    FwvXYWOkfuailQMemSKrjNdGBVIJRA='movie'
    FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'MOVIE','mediacode':FwvXYWOkfuailQMemSKrjNdGBVIJRo,'stype':'movie','title':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'thumbnail':FwvXYWOkfuailQMemSKrjNdGBVIJLb,}
    FwvXYWOkfuailQMemSKrjNdGBVIJLH=FwvXYWOkfuailQMemSKrjNdGBVIJyP
   if FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_makebookmark():
    FwvXYWOkfuailQMemSKrjNdGBVIJHt={'videoid':FwvXYWOkfuailQMemSKrjNdGBVIJRo,'vidtype':FwvXYWOkfuailQMemSKrjNdGBVIJRA,'vtitle':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'vsubtitle':'',}
    FwvXYWOkfuailQMemSKrjNdGBVIJHn=json.dumps(FwvXYWOkfuailQMemSKrjNdGBVIJHt)
    FwvXYWOkfuailQMemSKrjNdGBVIJHn=urllib.parse.quote(FwvXYWOkfuailQMemSKrjNdGBVIJHn)
    FwvXYWOkfuailQMemSKrjNdGBVIJHq='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(FwvXYWOkfuailQMemSKrjNdGBVIJHn)
    FwvXYWOkfuailQMemSKrjNdGBVIJHU=[('(통합) 찜 영상에 추가',FwvXYWOkfuailQMemSKrjNdGBVIJHq)]
   else:
    FwvXYWOkfuailQMemSKrjNdGBVIJHU=FwvXYWOkfuailQMemSKrjNdGBVIJyq
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel='',img=FwvXYWOkfuailQMemSKrjNdGBVIJLb,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJHC,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJLH,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg,isLink=FwvXYWOkfuailQMemSKrjNdGBVIJyP,ContextMenu=FwvXYWOkfuailQMemSKrjNdGBVIJHU)
  if FwvXYWOkfuailQMemSKrjNdGBVIJLx:
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['mode'] ='SEARCH' 
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['search_key']=FwvXYWOkfuailQMemSKrjNdGBVIJRn
   FwvXYWOkfuailQMemSKrjNdGBVIJLg['page'] =FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJgh='[B]%s >>[/B]'%'다음 페이지'
   FwvXYWOkfuailQMemSKrjNdGBVIJHD=FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJLq+1)
   FwvXYWOkfuailQMemSKrjNdGBVIJLc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJHD,img=FwvXYWOkfuailQMemSKrjNdGBVIJLc,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJyq,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  if FwvXYWOkfuailQMemSKrjNdGBVIJLp=='movie':xbmcplugin.setContent(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,'movies')
  else:xbmcplugin.setContent(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,cacheToDisc=FwvXYWOkfuailQMemSKrjNdGBVIJyP)
 def dp_History_Remove(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJTs=FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('delType')
  FwvXYWOkfuailQMemSKrjNdGBVIJTC =FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('sKey')
  FwvXYWOkfuailQMemSKrjNdGBVIJTD =FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('vType')
  FwvXYWOkfuailQMemSKrjNdGBVIJcn=xbmcgui.Dialog()
  if FwvXYWOkfuailQMemSKrjNdGBVIJTs=='SEARCH_ALL':
   FwvXYWOkfuailQMemSKrjNdGBVIJLo=FwvXYWOkfuailQMemSKrjNdGBVIJcn.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif FwvXYWOkfuailQMemSKrjNdGBVIJTs=='SEARCH_ONE':
   FwvXYWOkfuailQMemSKrjNdGBVIJLo=FwvXYWOkfuailQMemSKrjNdGBVIJcn.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif FwvXYWOkfuailQMemSKrjNdGBVIJTs=='WATCH_ALL':
   FwvXYWOkfuailQMemSKrjNdGBVIJLo=FwvXYWOkfuailQMemSKrjNdGBVIJcn.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif FwvXYWOkfuailQMemSKrjNdGBVIJTs=='WATCH_ONE':
   FwvXYWOkfuailQMemSKrjNdGBVIJLo=FwvXYWOkfuailQMemSKrjNdGBVIJcn.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if FwvXYWOkfuailQMemSKrjNdGBVIJLo==FwvXYWOkfuailQMemSKrjNdGBVIJyP:sys.exit()
  if FwvXYWOkfuailQMemSKrjNdGBVIJTs=='SEARCH_ALL':
   if os.path.isfile(FwvXYWOkfuailQMemSKrjNdGBVIJco):os.remove(FwvXYWOkfuailQMemSKrjNdGBVIJco)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJTs=='SEARCH_ONE':
   try:
    FwvXYWOkfuailQMemSKrjNdGBVIJTo=FwvXYWOkfuailQMemSKrjNdGBVIJco
    FwvXYWOkfuailQMemSKrjNdGBVIJTA=FwvXYWOkfuailQMemSKrjNdGBVIJcA.Load_List_File('search') 
    fp=FwvXYWOkfuailQMemSKrjNdGBVIJsz(FwvXYWOkfuailQMemSKrjNdGBVIJTo,'w',-1,'utf-8')
    for FwvXYWOkfuailQMemSKrjNdGBVIJTE in FwvXYWOkfuailQMemSKrjNdGBVIJTA:
     FwvXYWOkfuailQMemSKrjNdGBVIJTp=FwvXYWOkfuailQMemSKrjNdGBVIJsc(urllib.parse.parse_qsl(FwvXYWOkfuailQMemSKrjNdGBVIJTE))
     FwvXYWOkfuailQMemSKrjNdGBVIJTh=FwvXYWOkfuailQMemSKrjNdGBVIJTp.get('skey').strip()
     if FwvXYWOkfuailQMemSKrjNdGBVIJTC!=FwvXYWOkfuailQMemSKrjNdGBVIJTh:
      fp.write(FwvXYWOkfuailQMemSKrjNdGBVIJTE)
    fp.close()
   except:
    FwvXYWOkfuailQMemSKrjNdGBVIJyq
  elif FwvXYWOkfuailQMemSKrjNdGBVIJTs=='WATCH_ALL':
   FwvXYWOkfuailQMemSKrjNdGBVIJTo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FwvXYWOkfuailQMemSKrjNdGBVIJTD))
   if os.path.isfile(FwvXYWOkfuailQMemSKrjNdGBVIJTo):os.remove(FwvXYWOkfuailQMemSKrjNdGBVIJTo)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJTs=='WATCH_ONE':
   FwvXYWOkfuailQMemSKrjNdGBVIJTo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FwvXYWOkfuailQMemSKrjNdGBVIJTD))
   try:
    FwvXYWOkfuailQMemSKrjNdGBVIJTA=FwvXYWOkfuailQMemSKrjNdGBVIJcA.Load_List_File(FwvXYWOkfuailQMemSKrjNdGBVIJTD) 
    fp=FwvXYWOkfuailQMemSKrjNdGBVIJsz(FwvXYWOkfuailQMemSKrjNdGBVIJTo,'w',-1,'utf-8')
    for FwvXYWOkfuailQMemSKrjNdGBVIJTE in FwvXYWOkfuailQMemSKrjNdGBVIJTA:
     FwvXYWOkfuailQMemSKrjNdGBVIJTp=FwvXYWOkfuailQMemSKrjNdGBVIJsc(urllib.parse.parse_qsl(FwvXYWOkfuailQMemSKrjNdGBVIJTE))
     FwvXYWOkfuailQMemSKrjNdGBVIJTh=FwvXYWOkfuailQMemSKrjNdGBVIJTp.get('code').strip()
     if FwvXYWOkfuailQMemSKrjNdGBVIJTC!=FwvXYWOkfuailQMemSKrjNdGBVIJTh:
      fp.write(FwvXYWOkfuailQMemSKrjNdGBVIJTE)
    fp.close()
   except:
    FwvXYWOkfuailQMemSKrjNdGBVIJyq
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLp): 
  try:
   if FwvXYWOkfuailQMemSKrjNdGBVIJLp=='search':
    FwvXYWOkfuailQMemSKrjNdGBVIJTo=FwvXYWOkfuailQMemSKrjNdGBVIJco
   elif FwvXYWOkfuailQMemSKrjNdGBVIJLp in['vod','movie']:
    FwvXYWOkfuailQMemSKrjNdGBVIJTo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FwvXYWOkfuailQMemSKrjNdGBVIJLp))
   else:
    return[]
   fp=FwvXYWOkfuailQMemSKrjNdGBVIJsz(FwvXYWOkfuailQMemSKrjNdGBVIJTo,'r',-1,'utf-8')
   FwvXYWOkfuailQMemSKrjNdGBVIJTt=fp.readlines()
   fp.close()
  except:
   FwvXYWOkfuailQMemSKrjNdGBVIJTt=[]
  return FwvXYWOkfuailQMemSKrjNdGBVIJTt
 def Save_Watched_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLp,FwvXYWOkfuailQMemSKrjNdGBVIJch):
  try:
   FwvXYWOkfuailQMemSKrjNdGBVIJTn=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%FwvXYWOkfuailQMemSKrjNdGBVIJLp))
   FwvXYWOkfuailQMemSKrjNdGBVIJTA=FwvXYWOkfuailQMemSKrjNdGBVIJcA.Load_List_File(FwvXYWOkfuailQMemSKrjNdGBVIJLp) 
   fp=FwvXYWOkfuailQMemSKrjNdGBVIJsz(FwvXYWOkfuailQMemSKrjNdGBVIJTn,'w',-1,'utf-8')
   FwvXYWOkfuailQMemSKrjNdGBVIJTq=urllib.parse.urlencode(FwvXYWOkfuailQMemSKrjNdGBVIJch)
   FwvXYWOkfuailQMemSKrjNdGBVIJTq=FwvXYWOkfuailQMemSKrjNdGBVIJTq+'\n'
   fp.write(FwvXYWOkfuailQMemSKrjNdGBVIJTq)
   FwvXYWOkfuailQMemSKrjNdGBVIJTU=0
   for FwvXYWOkfuailQMemSKrjNdGBVIJTE in FwvXYWOkfuailQMemSKrjNdGBVIJTA:
    FwvXYWOkfuailQMemSKrjNdGBVIJTp=FwvXYWOkfuailQMemSKrjNdGBVIJsc(urllib.parse.parse_qsl(FwvXYWOkfuailQMemSKrjNdGBVIJTE))
    FwvXYWOkfuailQMemSKrjNdGBVIJTx=FwvXYWOkfuailQMemSKrjNdGBVIJch.get('code').strip()
    FwvXYWOkfuailQMemSKrjNdGBVIJTP=FwvXYWOkfuailQMemSKrjNdGBVIJTp.get('code').strip()
    if FwvXYWOkfuailQMemSKrjNdGBVIJLp=='vod' and FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_direct_replay()==FwvXYWOkfuailQMemSKrjNdGBVIJyx:
     FwvXYWOkfuailQMemSKrjNdGBVIJTx=FwvXYWOkfuailQMemSKrjNdGBVIJch.get('videoid').strip()
     FwvXYWOkfuailQMemSKrjNdGBVIJTP=FwvXYWOkfuailQMemSKrjNdGBVIJTp.get('videoid').strip()if FwvXYWOkfuailQMemSKrjNdGBVIJTP!=FwvXYWOkfuailQMemSKrjNdGBVIJyq else '-'
    if FwvXYWOkfuailQMemSKrjNdGBVIJTx!=FwvXYWOkfuailQMemSKrjNdGBVIJTP:
     fp.write(FwvXYWOkfuailQMemSKrjNdGBVIJTE)
     FwvXYWOkfuailQMemSKrjNdGBVIJTU+=1
     if FwvXYWOkfuailQMemSKrjNdGBVIJTU>=50:break
   fp.close()
  except:
   FwvXYWOkfuailQMemSKrjNdGBVIJyq
 def dp_Watch_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJLp =FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('stype')
  FwvXYWOkfuailQMemSKrjNdGBVIJgo=FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_direct_replay()
  if FwvXYWOkfuailQMemSKrjNdGBVIJLp=='-':
   for FwvXYWOkfuailQMemSKrjNdGBVIJLt in FwvXYWOkfuailQMemSKrjNdGBVIJcR:
    FwvXYWOkfuailQMemSKrjNdGBVIJgh=FwvXYWOkfuailQMemSKrjNdGBVIJLt.get('title')
    FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':FwvXYWOkfuailQMemSKrjNdGBVIJLt.get('mode'),'stype':FwvXYWOkfuailQMemSKrjNdGBVIJLt.get('stype')}
    FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel='',img='',infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJyq,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyx,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
   if FwvXYWOkfuailQMemSKrjNdGBVIJsH(FwvXYWOkfuailQMemSKrjNdGBVIJcR)>0:xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle)
  else:
   FwvXYWOkfuailQMemSKrjNdGBVIJTb=FwvXYWOkfuailQMemSKrjNdGBVIJcA.Load_List_File(FwvXYWOkfuailQMemSKrjNdGBVIJLp)
   for FwvXYWOkfuailQMemSKrjNdGBVIJzc in FwvXYWOkfuailQMemSKrjNdGBVIJTb:
    FwvXYWOkfuailQMemSKrjNdGBVIJTg=FwvXYWOkfuailQMemSKrjNdGBVIJsc(urllib.parse.parse_qsl(FwvXYWOkfuailQMemSKrjNdGBVIJzc))
    FwvXYWOkfuailQMemSKrjNdGBVIJzg =FwvXYWOkfuailQMemSKrjNdGBVIJTg.get('code').strip()
    FwvXYWOkfuailQMemSKrjNdGBVIJgh =FwvXYWOkfuailQMemSKrjNdGBVIJTg.get('title').strip()
    FwvXYWOkfuailQMemSKrjNdGBVIJLb=FwvXYWOkfuailQMemSKrjNdGBVIJTg.get('img').strip()
    FwvXYWOkfuailQMemSKrjNdGBVIJRo =FwvXYWOkfuailQMemSKrjNdGBVIJTg.get('videoid').strip()
    try:
     FwvXYWOkfuailQMemSKrjNdGBVIJLb=FwvXYWOkfuailQMemSKrjNdGBVIJLb.replace('\'','\"')
     FwvXYWOkfuailQMemSKrjNdGBVIJLb=json.loads(FwvXYWOkfuailQMemSKrjNdGBVIJLb)
    except:
     FwvXYWOkfuailQMemSKrjNdGBVIJyq
    FwvXYWOkfuailQMemSKrjNdGBVIJHC={}
    FwvXYWOkfuailQMemSKrjNdGBVIJHC['plot']=FwvXYWOkfuailQMemSKrjNdGBVIJgh
    if FwvXYWOkfuailQMemSKrjNdGBVIJLp=='vod':
     if FwvXYWOkfuailQMemSKrjNdGBVIJgo==FwvXYWOkfuailQMemSKrjNdGBVIJyP or FwvXYWOkfuailQMemSKrjNdGBVIJRo==FwvXYWOkfuailQMemSKrjNdGBVIJyq:
      FwvXYWOkfuailQMemSKrjNdGBVIJHC['mediatype']='tvshow'
      FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'EPISODE','programcode':FwvXYWOkfuailQMemSKrjNdGBVIJzg,'page':'1'}
      FwvXYWOkfuailQMemSKrjNdGBVIJLH=FwvXYWOkfuailQMemSKrjNdGBVIJyx
     else:
      FwvXYWOkfuailQMemSKrjNdGBVIJHC['mediatype']='episode'
      FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'VOD','mediacode':FwvXYWOkfuailQMemSKrjNdGBVIJRo,'stype':'vod','programcode':FwvXYWOkfuailQMemSKrjNdGBVIJzg,'title':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'thumbnail':FwvXYWOkfuailQMemSKrjNdGBVIJLb}
      FwvXYWOkfuailQMemSKrjNdGBVIJLH=FwvXYWOkfuailQMemSKrjNdGBVIJyP
    else:
     FwvXYWOkfuailQMemSKrjNdGBVIJHC['mediatype']='movie'
     FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'MOVIE','mediacode':FwvXYWOkfuailQMemSKrjNdGBVIJzg,'stype':'movie','title':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'thumbnail':FwvXYWOkfuailQMemSKrjNdGBVIJLb}
     FwvXYWOkfuailQMemSKrjNdGBVIJLH=FwvXYWOkfuailQMemSKrjNdGBVIJyP
    FwvXYWOkfuailQMemSKrjNdGBVIJTH={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':FwvXYWOkfuailQMemSKrjNdGBVIJzg,'vType':FwvXYWOkfuailQMemSKrjNdGBVIJLp,}
    FwvXYWOkfuailQMemSKrjNdGBVIJTR=urllib.parse.urlencode(FwvXYWOkfuailQMemSKrjNdGBVIJTH)
    FwvXYWOkfuailQMemSKrjNdGBVIJHU=[('선택된 시청이력 ( %s ) 삭제'%(FwvXYWOkfuailQMemSKrjNdGBVIJgh),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(FwvXYWOkfuailQMemSKrjNdGBVIJTR))]
    FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel='',img=FwvXYWOkfuailQMemSKrjNdGBVIJLb,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJHC,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJLH,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg,ContextMenu=FwvXYWOkfuailQMemSKrjNdGBVIJHU)
   FwvXYWOkfuailQMemSKrjNdGBVIJHC={'plot':'시청목록을 삭제합니다.'}
   FwvXYWOkfuailQMemSKrjNdGBVIJgh='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':FwvXYWOkfuailQMemSKrjNdGBVIJLp,}
   FwvXYWOkfuailQMemSKrjNdGBVIJLc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel='',img=FwvXYWOkfuailQMemSKrjNdGBVIJLc,infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJHC,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyP,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg,isLink=FwvXYWOkfuailQMemSKrjNdGBVIJyx)
   if FwvXYWOkfuailQMemSKrjNdGBVIJLp=='movie':xbmcplugin.setContent(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,'movies')
   else:xbmcplugin.setContent(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,cacheToDisc=FwvXYWOkfuailQMemSKrjNdGBVIJyP)
 def Save_Searched_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJRn):
  try:
   FwvXYWOkfuailQMemSKrjNdGBVIJzL=FwvXYWOkfuailQMemSKrjNdGBVIJco
   FwvXYWOkfuailQMemSKrjNdGBVIJTA=FwvXYWOkfuailQMemSKrjNdGBVIJcA.Load_List_File('search') 
   FwvXYWOkfuailQMemSKrjNdGBVIJzH={'skey':FwvXYWOkfuailQMemSKrjNdGBVIJRn.strip()}
   fp=FwvXYWOkfuailQMemSKrjNdGBVIJsz(FwvXYWOkfuailQMemSKrjNdGBVIJzL,'w',-1,'utf-8')
   FwvXYWOkfuailQMemSKrjNdGBVIJTq=urllib.parse.urlencode(FwvXYWOkfuailQMemSKrjNdGBVIJzH)
   FwvXYWOkfuailQMemSKrjNdGBVIJTq=FwvXYWOkfuailQMemSKrjNdGBVIJTq+'\n'
   fp.write(FwvXYWOkfuailQMemSKrjNdGBVIJTq)
   FwvXYWOkfuailQMemSKrjNdGBVIJTU=0
   for FwvXYWOkfuailQMemSKrjNdGBVIJTE in FwvXYWOkfuailQMemSKrjNdGBVIJTA:
    FwvXYWOkfuailQMemSKrjNdGBVIJTp=FwvXYWOkfuailQMemSKrjNdGBVIJsc(urllib.parse.parse_qsl(FwvXYWOkfuailQMemSKrjNdGBVIJTE))
    FwvXYWOkfuailQMemSKrjNdGBVIJTx=FwvXYWOkfuailQMemSKrjNdGBVIJzH.get('skey').strip()
    FwvXYWOkfuailQMemSKrjNdGBVIJTP=FwvXYWOkfuailQMemSKrjNdGBVIJTp.get('skey').strip()
    if FwvXYWOkfuailQMemSKrjNdGBVIJTx!=FwvXYWOkfuailQMemSKrjNdGBVIJTP:
     fp.write(FwvXYWOkfuailQMemSKrjNdGBVIJTE)
     FwvXYWOkfuailQMemSKrjNdGBVIJTU+=1
     if FwvXYWOkfuailQMemSKrjNdGBVIJTU>=50:break
   fp.close()
  except:
   FwvXYWOkfuailQMemSKrjNdGBVIJyq
 def play_VIDEO(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJzR =FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('mediacode')
  FwvXYWOkfuailQMemSKrjNdGBVIJLp =FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('stype')
  FwvXYWOkfuailQMemSKrjNdGBVIJzT =FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('pvrmode')
  FwvXYWOkfuailQMemSKrjNdGBVIJzy=FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_selQuality(FwvXYWOkfuailQMemSKrjNdGBVIJLp)
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(FwvXYWOkfuailQMemSKrjNdGBVIJzR,FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJzy),FwvXYWOkfuailQMemSKrjNdGBVIJLp,FwvXYWOkfuailQMemSKrjNdGBVIJzT))
  FwvXYWOkfuailQMemSKrjNdGBVIJzs=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.GetBroadURL(FwvXYWOkfuailQMemSKrjNdGBVIJzR,FwvXYWOkfuailQMemSKrjNdGBVIJzy,FwvXYWOkfuailQMemSKrjNdGBVIJLp,FwvXYWOkfuailQMemSKrjNdGBVIJzT,optUHD=FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_uhd())
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_log('qt, stype, url : %s - %s - %s'%(FwvXYWOkfuailQMemSKrjNdGBVIJsR(FwvXYWOkfuailQMemSKrjNdGBVIJzy),FwvXYWOkfuailQMemSKrjNdGBVIJLp,FwvXYWOkfuailQMemSKrjNdGBVIJzs['streaming_url']))
  if FwvXYWOkfuailQMemSKrjNdGBVIJzs['streaming_url']=='':
   if FwvXYWOkfuailQMemSKrjNdGBVIJzs['error_msg']=='':
    FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_noti(__language__(30908).encode('utf8'))
   else:
    FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_noti(FwvXYWOkfuailQMemSKrjNdGBVIJzs['error_msg'].encode('utf8'))
   return
  FwvXYWOkfuailQMemSKrjNdGBVIJzC='user-agent={}'.format(FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.USER_AGENT)
  if FwvXYWOkfuailQMemSKrjNdGBVIJzs['watermark'] !='':
   FwvXYWOkfuailQMemSKrjNdGBVIJzC='{}&x-tving-param1={}&x-tving-param2={}'.format(FwvXYWOkfuailQMemSKrjNdGBVIJzC,FwvXYWOkfuailQMemSKrjNdGBVIJzs['watermarkKey'],FwvXYWOkfuailQMemSKrjNdGBVIJzs['watermark'])
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_log('streaming_url = {}'.format(FwvXYWOkfuailQMemSKrjNdGBVIJzs['streaming_url']))
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_log('drm_license   = {}'.format(FwvXYWOkfuailQMemSKrjNdGBVIJzs['drm_license']))
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_log('watermark     = {}'.format(FwvXYWOkfuailQMemSKrjNdGBVIJzs['watermark']))
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_log('watermarkKey  = {}'.format(FwvXYWOkfuailQMemSKrjNdGBVIJzs['watermarkKey']))
  FwvXYWOkfuailQMemSKrjNdGBVIJzD =FwvXYWOkfuailQMemSKrjNdGBVIJyP
  FwvXYWOkfuailQMemSKrjNdGBVIJzo =FwvXYWOkfuailQMemSKrjNdGBVIJzs['streaming_url'].find('Policy=')
  if FwvXYWOkfuailQMemSKrjNdGBVIJzo!=-1:
   FwvXYWOkfuailQMemSKrjNdGBVIJzA =FwvXYWOkfuailQMemSKrjNdGBVIJzs['streaming_url'].split('?')[0]
   FwvXYWOkfuailQMemSKrjNdGBVIJzE=FwvXYWOkfuailQMemSKrjNdGBVIJsc(urllib.parse.parse_qsl(urllib.parse.urlsplit(FwvXYWOkfuailQMemSKrjNdGBVIJzs['streaming_url']).query))
   FwvXYWOkfuailQMemSKrjNdGBVIJzp='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(FwvXYWOkfuailQMemSKrjNdGBVIJzE['Policy'],FwvXYWOkfuailQMemSKrjNdGBVIJzE['Signature'],FwvXYWOkfuailQMemSKrjNdGBVIJzE['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in FwvXYWOkfuailQMemSKrjNdGBVIJzA:
    FwvXYWOkfuailQMemSKrjNdGBVIJzD=FwvXYWOkfuailQMemSKrjNdGBVIJyx
    FwvXYWOkfuailQMemSKrjNdGBVIJzh =FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    FwvXYWOkfuailQMemSKrjNdGBVIJzt=FwvXYWOkfuailQMemSKrjNdGBVIJzh.strftime('%Y-%m-%d-%H:%M:%S')
    if FwvXYWOkfuailQMemSKrjNdGBVIJyU(FwvXYWOkfuailQMemSKrjNdGBVIJzt.replace('-','').replace(':',''))<FwvXYWOkfuailQMemSKrjNdGBVIJyU(FwvXYWOkfuailQMemSKrjNdGBVIJzE['end'].replace('-','').replace(':','')):
     FwvXYWOkfuailQMemSKrjNdGBVIJzE['end']=FwvXYWOkfuailQMemSKrjNdGBVIJzt
     FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_noti(__language__(30915).encode('utf8'))
    FwvXYWOkfuailQMemSKrjNdGBVIJzA ='%s?%s'%(FwvXYWOkfuailQMemSKrjNdGBVIJzA,urllib.parse.urlencode(FwvXYWOkfuailQMemSKrjNdGBVIJzE,doseq=FwvXYWOkfuailQMemSKrjNdGBVIJyx))
    FwvXYWOkfuailQMemSKrjNdGBVIJzn='{}|{}&Cookie={}'.format(FwvXYWOkfuailQMemSKrjNdGBVIJzA,FwvXYWOkfuailQMemSKrjNdGBVIJzC,FwvXYWOkfuailQMemSKrjNdGBVIJzp)
   else:
    FwvXYWOkfuailQMemSKrjNdGBVIJzn='{}|{}&Cookie={}'.format(FwvXYWOkfuailQMemSKrjNdGBVIJzs['streaming_url'],FwvXYWOkfuailQMemSKrjNdGBVIJzC,FwvXYWOkfuailQMemSKrjNdGBVIJzp)
  else:
   FwvXYWOkfuailQMemSKrjNdGBVIJzn=FwvXYWOkfuailQMemSKrjNdGBVIJzs['streaming_url']+'|'+FwvXYWOkfuailQMemSKrjNdGBVIJzC
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_log('if tmp_pos == -1')
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_log(FwvXYWOkfuailQMemSKrjNdGBVIJzn)
  FwvXYWOkfuailQMemSKrjNdGBVIJgR,FwvXYWOkfuailQMemSKrjNdGBVIJgT=FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_proxyport()
  FwvXYWOkfuailQMemSKrjNdGBVIJgH=FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_playback()
  FwvXYWOkfuailQMemSKrjNdGBVIJzq=urllib.parse.urlparse(FwvXYWOkfuailQMemSKrjNdGBVIJzs['streaming_url'])
  FwvXYWOkfuailQMemSKrjNdGBVIJzq=FwvXYWOkfuailQMemSKrjNdGBVIJzq.path.strip('/').split('/')
  FwvXYWOkfuailQMemSKrjNdGBVIJzq=FwvXYWOkfuailQMemSKrjNdGBVIJzq[FwvXYWOkfuailQMemSKrjNdGBVIJsH(FwvXYWOkfuailQMemSKrjNdGBVIJzq)-1] 
  if(FwvXYWOkfuailQMemSKrjNdGBVIJgR and FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('mode')in['VOD','MOVIE']and FwvXYWOkfuailQMemSKrjNdGBVIJzD==FwvXYWOkfuailQMemSKrjNdGBVIJyP and(FwvXYWOkfuailQMemSKrjNdGBVIJzs['drm_license']!='' or FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.KodiVersion>=21)):
   if FwvXYWOkfuailQMemSKrjNdGBVIJzq.split('.')[1]=='mpd':
    FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Tving_Parse_mpd(FwvXYWOkfuailQMemSKrjNdGBVIJzs['streaming_url'],FwvXYWOkfuailQMemSKrjNdGBVIJzs['watermarkKey'],FwvXYWOkfuailQMemSKrjNdGBVIJzs['watermark'])
   else:
    FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Tving_Parse_m3u8(FwvXYWOkfuailQMemSKrjNdGBVIJzs['streaming_url'])
   FwvXYWOkfuailQMemSKrjNdGBVIJzU={'addon':'tvingm','playOption':FwvXYWOkfuailQMemSKrjNdGBVIJgH,}
   FwvXYWOkfuailQMemSKrjNdGBVIJzU=json.dumps(FwvXYWOkfuailQMemSKrjNdGBVIJzU,separators=(',',':'))
   FwvXYWOkfuailQMemSKrjNdGBVIJzU=base64.standard_b64encode(FwvXYWOkfuailQMemSKrjNdGBVIJzU.encode()).decode('utf-8')
   FwvXYWOkfuailQMemSKrjNdGBVIJzn ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(FwvXYWOkfuailQMemSKrjNdGBVIJgT,FwvXYWOkfuailQMemSKrjNdGBVIJzn,FwvXYWOkfuailQMemSKrjNdGBVIJzU)
   FwvXYWOkfuailQMemSKrjNdGBVIJzC='{}&proxy-mini={}'.format(FwvXYWOkfuailQMemSKrjNdGBVIJzC,FwvXYWOkfuailQMemSKrjNdGBVIJzU)
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_log(FwvXYWOkfuailQMemSKrjNdGBVIJzn)
  FwvXYWOkfuailQMemSKrjNdGBVIJzx=xbmcgui.ListItem(path=FwvXYWOkfuailQMemSKrjNdGBVIJzn)
  if FwvXYWOkfuailQMemSKrjNdGBVIJzs['drm_license']!='':
   FwvXYWOkfuailQMemSKrjNdGBVIJzP=FwvXYWOkfuailQMemSKrjNdGBVIJzs['drm_license']
   FwvXYWOkfuailQMemSKrjNdGBVIJzb ='https://cj.drmkeyserver.com/widevine_license'
   FwvXYWOkfuailQMemSKrjNdGBVIJyc ='mpd'
   FwvXYWOkfuailQMemSKrjNdGBVIJyg ='com.widevine.alpha'
   FwvXYWOkfuailQMemSKrjNdGBVIJyL =inputstreamhelper.Helper(FwvXYWOkfuailQMemSKrjNdGBVIJyc,drm='widevine')
   if FwvXYWOkfuailQMemSKrjNdGBVIJyL.check_inputstream():
    FwvXYWOkfuailQMemSKrjNdGBVIJyH={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.USER_AGENT,'AcquireLicenseAssertion':FwvXYWOkfuailQMemSKrjNdGBVIJzP,'Host':'cj.drmkeyserver.com',}
    FwvXYWOkfuailQMemSKrjNdGBVIJyR=FwvXYWOkfuailQMemSKrjNdGBVIJzb+'|'+urllib.parse.urlencode(FwvXYWOkfuailQMemSKrjNdGBVIJyH)+'|R{SSM}|'
    FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('inputstream',FwvXYWOkfuailQMemSKrjNdGBVIJyL.inputstream_addon)
    FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('inputstream.adaptive.manifest_type',FwvXYWOkfuailQMemSKrjNdGBVIJyc)
    FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('inputstream.adaptive.license_type',FwvXYWOkfuailQMemSKrjNdGBVIJyg)
    FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('inputstream.adaptive.license_key',FwvXYWOkfuailQMemSKrjNdGBVIJyR)
    FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('inputstream.adaptive.stream_headers',FwvXYWOkfuailQMemSKrjNdGBVIJzC)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('mode')in['VOD','MOVIE']:
   FwvXYWOkfuailQMemSKrjNdGBVIJzx.setContentLookup(FwvXYWOkfuailQMemSKrjNdGBVIJyP)
   FwvXYWOkfuailQMemSKrjNdGBVIJzx.setMimeType('application/x-mpegURL')
   FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('inputstream','inputstream.adaptive')
   FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('inputstream.adaptive.manifest_type','hls')
   FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('inputstream.adaptive.stream_headers',FwvXYWOkfuailQMemSKrjNdGBVIJzC)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJzD==FwvXYWOkfuailQMemSKrjNdGBVIJyx:
   FwvXYWOkfuailQMemSKrjNdGBVIJzx.setContentLookup(FwvXYWOkfuailQMemSKrjNdGBVIJyP)
   FwvXYWOkfuailQMemSKrjNdGBVIJzx.setMimeType('application/x-mpegURL')
   FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('inputstream','inputstream.ffmpegdirect')
   FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('ResumeTime','0')
   FwvXYWOkfuailQMemSKrjNdGBVIJzx.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,FwvXYWOkfuailQMemSKrjNdGBVIJyx,FwvXYWOkfuailQMemSKrjNdGBVIJzx)
  try:
   if FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('mode')in['VOD','MOVIE']and FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('title'):
    FwvXYWOkfuailQMemSKrjNdGBVIJLg={'code':FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('programcode')if FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('mode')=='VOD' else FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('mediacode'),'img':FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('thumbnail'),'title':FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('title'),'videoid':FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('mediacode')}
    FwvXYWOkfuailQMemSKrjNdGBVIJcA.Save_Watched_List(FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('stype'),FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  except:
   FwvXYWOkfuailQMemSKrjNdGBVIJyq
 def logout(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  FwvXYWOkfuailQMemSKrjNdGBVIJcn=xbmcgui.Dialog()
  FwvXYWOkfuailQMemSKrjNdGBVIJLo=FwvXYWOkfuailQMemSKrjNdGBVIJcn.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if FwvXYWOkfuailQMemSKrjNdGBVIJLo==FwvXYWOkfuailQMemSKrjNdGBVIJyP:sys.exit()
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Init_TV_Total()
  if os.path.isfile(FwvXYWOkfuailQMemSKrjNdGBVIJcD):os.remove(FwvXYWOkfuailQMemSKrjNdGBVIJcD)
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  FwvXYWOkfuailQMemSKrjNdGBVIJyT =FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Get_Now_Datetime()
  FwvXYWOkfuailQMemSKrjNdGBVIJyz=FwvXYWOkfuailQMemSKrjNdGBVIJyT+datetime.timedelta(days=FwvXYWOkfuailQMemSKrjNdGBVIJyU(__addon__.getSetting('cache_ttl')))
  (FwvXYWOkfuailQMemSKrjNdGBVIJLy,FwvXYWOkfuailQMemSKrjNdGBVIJLs,FwvXYWOkfuailQMemSKrjNdGBVIJLC,FwvXYWOkfuailQMemSKrjNdGBVIJLD)=FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_account()
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Save_session_acount(FwvXYWOkfuailQMemSKrjNdGBVIJLy,FwvXYWOkfuailQMemSKrjNdGBVIJLs,FwvXYWOkfuailQMemSKrjNdGBVIJLC,FwvXYWOkfuailQMemSKrjNdGBVIJLD)
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.TV['account']['token_limit']=FwvXYWOkfuailQMemSKrjNdGBVIJyz.strftime('%Y%m%d')
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.JsonFile_Save(FwvXYWOkfuailQMemSKrjNdGBVIJcD,FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.TV)
 def cookiefile_check(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.TV=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.JsonFile_Load(FwvXYWOkfuailQMemSKrjNdGBVIJcD)
  if 'account' not in FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.TV:
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Init_TV_Total()
   return FwvXYWOkfuailQMemSKrjNdGBVIJyP
  (FwvXYWOkfuailQMemSKrjNdGBVIJys,FwvXYWOkfuailQMemSKrjNdGBVIJyC,FwvXYWOkfuailQMemSKrjNdGBVIJyD,FwvXYWOkfuailQMemSKrjNdGBVIJyo)=FwvXYWOkfuailQMemSKrjNdGBVIJcA.get_settings_account()
  (FwvXYWOkfuailQMemSKrjNdGBVIJyA,FwvXYWOkfuailQMemSKrjNdGBVIJyE,FwvXYWOkfuailQMemSKrjNdGBVIJyp,FwvXYWOkfuailQMemSKrjNdGBVIJyh)=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Load_session_acount()
  if FwvXYWOkfuailQMemSKrjNdGBVIJys!=FwvXYWOkfuailQMemSKrjNdGBVIJyA or FwvXYWOkfuailQMemSKrjNdGBVIJyC!=FwvXYWOkfuailQMemSKrjNdGBVIJyE or FwvXYWOkfuailQMemSKrjNdGBVIJyD!=FwvXYWOkfuailQMemSKrjNdGBVIJyp or FwvXYWOkfuailQMemSKrjNdGBVIJyo!=FwvXYWOkfuailQMemSKrjNdGBVIJyh:
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Init_TV_Total()
   return FwvXYWOkfuailQMemSKrjNdGBVIJyP
  if FwvXYWOkfuailQMemSKrjNdGBVIJyU(FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>FwvXYWOkfuailQMemSKrjNdGBVIJyU(FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.TV['account']['token_limit']):
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.Init_TV_Total()
   return FwvXYWOkfuailQMemSKrjNdGBVIJyP
  return FwvXYWOkfuailQMemSKrjNdGBVIJyx
 def dp_Global_Search(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJRq=FwvXYWOkfuailQMemSKrjNdGBVIJLn.get('mode')
  if FwvXYWOkfuailQMemSKrjNdGBVIJRq=='TOTAL_SEARCH':
   FwvXYWOkfuailQMemSKrjNdGBVIJyt='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   FwvXYWOkfuailQMemSKrjNdGBVIJyt='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(FwvXYWOkfuailQMemSKrjNdGBVIJyt)
 def dp_Bookmark_Menu(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJyt='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(FwvXYWOkfuailQMemSKrjNdGBVIJyt)
 def dp_EuroLive_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA,FwvXYWOkfuailQMemSKrjNdGBVIJLn):
  FwvXYWOkfuailQMemSKrjNdGBVIJLU=FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.GetEuroChannelList()
  for FwvXYWOkfuailQMemSKrjNdGBVIJLP in FwvXYWOkfuailQMemSKrjNdGBVIJLU:
   FwvXYWOkfuailQMemSKrjNdGBVIJHh =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('channel')
   FwvXYWOkfuailQMemSKrjNdGBVIJgh =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('title')
   FwvXYWOkfuailQMemSKrjNdGBVIJHD =FwvXYWOkfuailQMemSKrjNdGBVIJLP.get('subtitle')
   FwvXYWOkfuailQMemSKrjNdGBVIJHC={'mediatype':'episode','title':FwvXYWOkfuailQMemSKrjNdGBVIJgh,'plot':'%s\n%s'%(FwvXYWOkfuailQMemSKrjNdGBVIJgh,FwvXYWOkfuailQMemSKrjNdGBVIJHD)}
   FwvXYWOkfuailQMemSKrjNdGBVIJLg={'mode':'LIVE','mediacode':FwvXYWOkfuailQMemSKrjNdGBVIJHh,'stype':'onair',}
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.add_dir(FwvXYWOkfuailQMemSKrjNdGBVIJgh,sublabel=FwvXYWOkfuailQMemSKrjNdGBVIJHD,img='',infoLabels=FwvXYWOkfuailQMemSKrjNdGBVIJHC,isFolder=FwvXYWOkfuailQMemSKrjNdGBVIJyP,params=FwvXYWOkfuailQMemSKrjNdGBVIJLg)
  if FwvXYWOkfuailQMemSKrjNdGBVIJsH(FwvXYWOkfuailQMemSKrjNdGBVIJLU)>0:xbmcplugin.endOfDirectory(FwvXYWOkfuailQMemSKrjNdGBVIJcA._addon_handle,cacheToDisc=FwvXYWOkfuailQMemSKrjNdGBVIJyP)
 def tving_main(FwvXYWOkfuailQMemSKrjNdGBVIJcA):
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.TvingObj.KodiVersion=FwvXYWOkfuailQMemSKrjNdGBVIJyU(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  FwvXYWOkfuailQMemSKrjNdGBVIJRq=FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params.get('mode',FwvXYWOkfuailQMemSKrjNdGBVIJyq)
  if FwvXYWOkfuailQMemSKrjNdGBVIJRq=='LOGOUT':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.logout()
   return
  FwvXYWOkfuailQMemSKrjNdGBVIJcA.login_main()
  if FwvXYWOkfuailQMemSKrjNdGBVIJRq is FwvXYWOkfuailQMemSKrjNdGBVIJyq:
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_Main_List()
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_Title_Group(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq in['GLOBAL_GROUP']:
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_SubTitle_Group(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='CHANNEL':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_LiveChannel_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq in['LIVE','VOD','MOVIE']:
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.play_VIDEO(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='PROGRAM':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_Program_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='4K_PROGRAM':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_4K_Program_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='ORI_PROGRAM':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_Ori_Program_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='EPISODE':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_Episode_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='MOVIE_SUB':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_Movie_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='4K_MOVIE':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_4K_Movie_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='SEARCH_GROUP':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_Search_Group(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq in['SEARCH','LOCAL_SEARCH']:
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_Search_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='WATCH':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_Watch_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_History_Remove(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='ORDER_BY':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_setEpOrderby(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='SET_BOOKMARK':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_Set_Bookmark(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq in['TOTAL_SEARCH','TOTAL_HISTORY']:
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_Global_Search(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='SEARCH_HISTORY':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_Search_History(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='MENU_BOOKMARK':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_Bookmark_Menu(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  elif FwvXYWOkfuailQMemSKrjNdGBVIJRq=='EURO_GROUP':
   FwvXYWOkfuailQMemSKrjNdGBVIJcA.dp_EuroLive_List(FwvXYWOkfuailQMemSKrjNdGBVIJcA.main_params)
  else:
   FwvXYWOkfuailQMemSKrjNdGBVIJyq
# Created by pyminifier (https://github.com/liftoff/pyminifier)
