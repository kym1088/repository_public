__author__="NightRain"
MiYyFXtBxoljhbpWELQeDCNswfaGHV=object
MiYyFXtBxoljhbpWELQeDCNswfaGHz=None
MiYyFXtBxoljhbpWELQeDCNswfaGHq=int
MiYyFXtBxoljhbpWELQeDCNswfaGHn=False
MiYyFXtBxoljhbpWELQeDCNswfaGHg=True
MiYyFXtBxoljhbpWELQeDCNswfaGHc=len
MiYyFXtBxoljhbpWELQeDCNswfaGHA=str
MiYyFXtBxoljhbpWELQeDCNswfaGHP=open
MiYyFXtBxoljhbpWELQeDCNswfaGSv=dict
MiYyFXtBxoljhbpWELQeDCNswfaGSO=Exception
MiYyFXtBxoljhbpWELQeDCNswfaGSU=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
MiYyFXtBxoljhbpWELQeDCNswfaGvU=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
MiYyFXtBxoljhbpWELQeDCNswfaGvm=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
MiYyFXtBxoljhbpWELQeDCNswfaGvd=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
MiYyFXtBxoljhbpWELQeDCNswfaGvH=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
MiYyFXtBxoljhbpWELQeDCNswfaGvS=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
MiYyFXtBxoljhbpWELQeDCNswfaGvR=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
MiYyFXtBxoljhbpWELQeDCNswfaGvu=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
MiYyFXtBxoljhbpWELQeDCNswfaGvI=xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class MiYyFXtBxoljhbpWELQeDCNswfaGvO(MiYyFXtBxoljhbpWELQeDCNswfaGHV):
 def __init__(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGvK,MiYyFXtBxoljhbpWELQeDCNswfaGvr,MiYyFXtBxoljhbpWELQeDCNswfaGvk):
  MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_url =MiYyFXtBxoljhbpWELQeDCNswfaGvK
  MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle=MiYyFXtBxoljhbpWELQeDCNswfaGvr
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params =MiYyFXtBxoljhbpWELQeDCNswfaGvk
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj =eBNhylkPaspxIJdqHGvVWwcirzoDMT() 
 def addon_noti(MiYyFXtBxoljhbpWELQeDCNswfaGvT,sting):
  try:
   MiYyFXtBxoljhbpWELQeDCNswfaGvV=xbmcgui.Dialog()
   MiYyFXtBxoljhbpWELQeDCNswfaGvV.notification(__addonname__,sting)
  except:
   MiYyFXtBxoljhbpWELQeDCNswfaGHz
 def addon_log(MiYyFXtBxoljhbpWELQeDCNswfaGvT,string):
  try:
   MiYyFXtBxoljhbpWELQeDCNswfaGvz=string.encode('utf-8','ignore')
  except:
   MiYyFXtBxoljhbpWELQeDCNswfaGvz='addonException: addon_log'
  MiYyFXtBxoljhbpWELQeDCNswfaGvq=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,MiYyFXtBxoljhbpWELQeDCNswfaGvz),level=MiYyFXtBxoljhbpWELQeDCNswfaGvq)
 def get_keyboard_input(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGOR):
  MiYyFXtBxoljhbpWELQeDCNswfaGvn=MiYyFXtBxoljhbpWELQeDCNswfaGHz
  kb=xbmc.Keyboard()
  kb.setHeading(MiYyFXtBxoljhbpWELQeDCNswfaGOR)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   MiYyFXtBxoljhbpWELQeDCNswfaGvn=kb.getText()
  return MiYyFXtBxoljhbpWELQeDCNswfaGvn
 def get_settings_login_info(MiYyFXtBxoljhbpWELQeDCNswfaGvT):
  MiYyFXtBxoljhbpWELQeDCNswfaGvg =__addon__.getSetting('id')
  MiYyFXtBxoljhbpWELQeDCNswfaGvc =__addon__.getSetting('pw')
  MiYyFXtBxoljhbpWELQeDCNswfaGvA =__addon__.getSetting('login_type')
  MiYyFXtBxoljhbpWELQeDCNswfaGvP=MiYyFXtBxoljhbpWELQeDCNswfaGHq(__addon__.getSetting('selected_profile'))
  return(MiYyFXtBxoljhbpWELQeDCNswfaGvg,MiYyFXtBxoljhbpWELQeDCNswfaGvc,MiYyFXtBxoljhbpWELQeDCNswfaGvA,MiYyFXtBxoljhbpWELQeDCNswfaGvP)
 def get_settings_premiumyn(MiYyFXtBxoljhbpWELQeDCNswfaGvT):
  MiYyFXtBxoljhbpWELQeDCNswfaGOv =__addon__.getSetting('premium_movieyn')
  if MiYyFXtBxoljhbpWELQeDCNswfaGOv=='false':
   return MiYyFXtBxoljhbpWELQeDCNswfaGHn
  else:
   return MiYyFXtBxoljhbpWELQeDCNswfaGHg
 def get_settings_direct_replay(MiYyFXtBxoljhbpWELQeDCNswfaGvT):
  MiYyFXtBxoljhbpWELQeDCNswfaGOU=MiYyFXtBxoljhbpWELQeDCNswfaGHq(__addon__.getSetting('direct_replay'))
  if MiYyFXtBxoljhbpWELQeDCNswfaGOU==0:
   return MiYyFXtBxoljhbpWELQeDCNswfaGHn
  else:
   return MiYyFXtBxoljhbpWELQeDCNswfaGHg
 def get_settings_thumbnail_landyn(MiYyFXtBxoljhbpWELQeDCNswfaGvT):
  MiYyFXtBxoljhbpWELQeDCNswfaGOm =MiYyFXtBxoljhbpWELQeDCNswfaGHq(__addon__.getSetting('thumbnail_way'))
  if MiYyFXtBxoljhbpWELQeDCNswfaGOm==0:
   return MiYyFXtBxoljhbpWELQeDCNswfaGHg
  else:
   return MiYyFXtBxoljhbpWELQeDCNswfaGHn
 def set_winCredential(MiYyFXtBxoljhbpWELQeDCNswfaGvT,credential):
  MiYyFXtBxoljhbpWELQeDCNswfaGOd=xbmcgui.Window(10000)
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_LOGINTIME',MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(MiYyFXtBxoljhbpWELQeDCNswfaGvT):
  MiYyFXtBxoljhbpWELQeDCNswfaGOd=xbmcgui.Window(10000)
  MiYyFXtBxoljhbpWELQeDCNswfaGOH={'tving_token':MiYyFXtBxoljhbpWELQeDCNswfaGOd.getProperty('TVING_M_TOKEN'),'poc_userinfo':MiYyFXtBxoljhbpWELQeDCNswfaGOd.getProperty('TVING_M_USERINFO'),'tving_uuid':MiYyFXtBxoljhbpWELQeDCNswfaGOd.getProperty('TVING_M_UUID'),'tving_maintoken':MiYyFXtBxoljhbpWELQeDCNswfaGOd.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':MiYyFXtBxoljhbpWELQeDCNswfaGOd.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':MiYyFXtBxoljhbpWELQeDCNswfaGOd.getProperty('TVING_M_LOCKKEY')}
  return MiYyFXtBxoljhbpWELQeDCNswfaGOH
 def set_winEpisodeOrderby(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUn):
  MiYyFXtBxoljhbpWELQeDCNswfaGOd=xbmcgui.Window(10000)
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_ORDERBY',MiYyFXtBxoljhbpWELQeDCNswfaGUn)
 def get_winEpisodeOrderby(MiYyFXtBxoljhbpWELQeDCNswfaGvT):
  MiYyFXtBxoljhbpWELQeDCNswfaGOd=xbmcgui.Window(10000)
  return MiYyFXtBxoljhbpWELQeDCNswfaGOd.getProperty('TVING_M_ORDERBY')
 def add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGvT,label,sublabel='',img='',infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGHz,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHg,params=''):
  MiYyFXtBxoljhbpWELQeDCNswfaGOS='%s?%s'%(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_url,urllib.parse.urlencode(params))
  if sublabel:MiYyFXtBxoljhbpWELQeDCNswfaGOR='%s < %s >'%(label,sublabel)
  else: MiYyFXtBxoljhbpWELQeDCNswfaGOR=label
  if not img:img='DefaultFolder.png'
  MiYyFXtBxoljhbpWELQeDCNswfaGOu=xbmcgui.ListItem(MiYyFXtBxoljhbpWELQeDCNswfaGOR)
  MiYyFXtBxoljhbpWELQeDCNswfaGOu.setArt({'thumb':img,'icon':img,'poster':img})
  if infoLabels:MiYyFXtBxoljhbpWELQeDCNswfaGOu.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:MiYyFXtBxoljhbpWELQeDCNswfaGOu.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle,MiYyFXtBxoljhbpWELQeDCNswfaGOS,MiYyFXtBxoljhbpWELQeDCNswfaGOu,isFolder)
 def get_selQuality(MiYyFXtBxoljhbpWELQeDCNswfaGvT,etype):
  try:
   MiYyFXtBxoljhbpWELQeDCNswfaGOI='selected_quality'
   MiYyFXtBxoljhbpWELQeDCNswfaGOT=[1080,720,480,360]
   MiYyFXtBxoljhbpWELQeDCNswfaGOK=MiYyFXtBxoljhbpWELQeDCNswfaGHq(__addon__.getSetting(MiYyFXtBxoljhbpWELQeDCNswfaGOI))
   return MiYyFXtBxoljhbpWELQeDCNswfaGOT[MiYyFXtBxoljhbpWELQeDCNswfaGOK]
  except:
   MiYyFXtBxoljhbpWELQeDCNswfaGHz
  return 720 
 def dp_Main_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT):
  for MiYyFXtBxoljhbpWELQeDCNswfaGOr in MiYyFXtBxoljhbpWELQeDCNswfaGvU:
   MiYyFXtBxoljhbpWELQeDCNswfaGOR=MiYyFXtBxoljhbpWELQeDCNswfaGOr.get('title')
   MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':MiYyFXtBxoljhbpWELQeDCNswfaGOr.get('mode'),'stype':MiYyFXtBxoljhbpWELQeDCNswfaGOr.get('stype'),'orderby':MiYyFXtBxoljhbpWELQeDCNswfaGOr.get('orderby'),'ordernm':MiYyFXtBxoljhbpWELQeDCNswfaGOr.get('ordernm'),'page':'1'}
   if MiYyFXtBxoljhbpWELQeDCNswfaGOr.get('mode')=='XXX':
    MiYyFXtBxoljhbpWELQeDCNswfaGOk['mode']='XXX'
    MiYyFXtBxoljhbpWELQeDCNswfaGOJ=MiYyFXtBxoljhbpWELQeDCNswfaGHn
   else:
    MiYyFXtBxoljhbpWELQeDCNswfaGOJ=MiYyFXtBxoljhbpWELQeDCNswfaGHg
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel='',img='',infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGHz,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGOJ,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGHc(MiYyFXtBxoljhbpWELQeDCNswfaGvU)>0:xbmcplugin.endOfDirectory(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle)
 def login_main(MiYyFXtBxoljhbpWELQeDCNswfaGvT):
  (MiYyFXtBxoljhbpWELQeDCNswfaGOz,MiYyFXtBxoljhbpWELQeDCNswfaGOq,MiYyFXtBxoljhbpWELQeDCNswfaGOn,MiYyFXtBxoljhbpWELQeDCNswfaGOg)=MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_settings_login_info()
  if not(MiYyFXtBxoljhbpWELQeDCNswfaGOz and MiYyFXtBxoljhbpWELQeDCNswfaGOq):
   MiYyFXtBxoljhbpWELQeDCNswfaGvV=xbmcgui.Dialog()
   MiYyFXtBxoljhbpWELQeDCNswfaGOc=MiYyFXtBxoljhbpWELQeDCNswfaGvV.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if MiYyFXtBxoljhbpWELQeDCNswfaGOc==MiYyFXtBxoljhbpWELQeDCNswfaGHg:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_winEpisodeOrderby()=='':
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.set_winEpisodeOrderby('desc')
  if MiYyFXtBxoljhbpWELQeDCNswfaGvT.cookiefile_check():return
  MiYyFXtBxoljhbpWELQeDCNswfaGOA =MiYyFXtBxoljhbpWELQeDCNswfaGHq(MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  MiYyFXtBxoljhbpWELQeDCNswfaGOP=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if MiYyFXtBxoljhbpWELQeDCNswfaGOP==MiYyFXtBxoljhbpWELQeDCNswfaGHz or MiYyFXtBxoljhbpWELQeDCNswfaGOP=='':
   MiYyFXtBxoljhbpWELQeDCNswfaGOP=MiYyFXtBxoljhbpWELQeDCNswfaGHq('19000101')
  else:
   MiYyFXtBxoljhbpWELQeDCNswfaGOP=MiYyFXtBxoljhbpWELQeDCNswfaGHq(re.sub('-','',MiYyFXtBxoljhbpWELQeDCNswfaGOP))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   MiYyFXtBxoljhbpWELQeDCNswfaGUv=0
   while MiYyFXtBxoljhbpWELQeDCNswfaGHg:
    MiYyFXtBxoljhbpWELQeDCNswfaGUv+=1
    time.sleep(0.05)
    if MiYyFXtBxoljhbpWELQeDCNswfaGOP>=MiYyFXtBxoljhbpWELQeDCNswfaGOA:return
    if MiYyFXtBxoljhbpWELQeDCNswfaGUv>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if MiYyFXtBxoljhbpWELQeDCNswfaGOP>=MiYyFXtBxoljhbpWELQeDCNswfaGOA:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.GetCredential(MiYyFXtBxoljhbpWELQeDCNswfaGOz,MiYyFXtBxoljhbpWELQeDCNswfaGOq,MiYyFXtBxoljhbpWELQeDCNswfaGOn,MiYyFXtBxoljhbpWELQeDCNswfaGOg):
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.set_winCredential(MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.LoadCredential())
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUH):
  MiYyFXtBxoljhbpWELQeDCNswfaGUO=MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('stype')
  if MiYyFXtBxoljhbpWELQeDCNswfaGUO=='live':
   MiYyFXtBxoljhbpWELQeDCNswfaGUm=MiYyFXtBxoljhbpWELQeDCNswfaGvm
  elif MiYyFXtBxoljhbpWELQeDCNswfaGUO=='vod':
   MiYyFXtBxoljhbpWELQeDCNswfaGUm=MiYyFXtBxoljhbpWELQeDCNswfaGvS
  else:
   MiYyFXtBxoljhbpWELQeDCNswfaGUm=MiYyFXtBxoljhbpWELQeDCNswfaGvR
  for MiYyFXtBxoljhbpWELQeDCNswfaGUd in MiYyFXtBxoljhbpWELQeDCNswfaGUm:
   MiYyFXtBxoljhbpWELQeDCNswfaGOR=MiYyFXtBxoljhbpWELQeDCNswfaGUd.get('title')
   if MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('ordernm')!='-':
    MiYyFXtBxoljhbpWELQeDCNswfaGOR+='  ('+MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('ordernm')+')'
   MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':MiYyFXtBxoljhbpWELQeDCNswfaGUd.get('mode'),'stype':MiYyFXtBxoljhbpWELQeDCNswfaGUd.get('stype'),'orderby':MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('orderby'),'ordernm':MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('ordernm'),'page':'1'}
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel='',img='',infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGHz,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHg,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGHc(MiYyFXtBxoljhbpWELQeDCNswfaGUm)>0:xbmcplugin.endOfDirectory(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle)
 def dp_SubTitle_Group(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUH): 
  for MiYyFXtBxoljhbpWELQeDCNswfaGUd in MiYyFXtBxoljhbpWELQeDCNswfaGvu:
   MiYyFXtBxoljhbpWELQeDCNswfaGOR=MiYyFXtBxoljhbpWELQeDCNswfaGUd.get('title')
   if MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('ordernm')!='-':
    MiYyFXtBxoljhbpWELQeDCNswfaGOR+='  ('+MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('ordernm')+')'
   MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':MiYyFXtBxoljhbpWELQeDCNswfaGUd.get('mode'),'genreCode':MiYyFXtBxoljhbpWELQeDCNswfaGUd.get('genreCode'),'stype':MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('stype'),'orderby':MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('orderby'),'page':'1'}
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel='',img='',infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGHz,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHg,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGHc(MiYyFXtBxoljhbpWELQeDCNswfaGvu)>0:xbmcplugin.endOfDirectory(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle)
 def dp_LiveChannel_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUH):
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.SaveCredential(MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_winCredential())
  MiYyFXtBxoljhbpWELQeDCNswfaGUO =MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('stype')
  MiYyFXtBxoljhbpWELQeDCNswfaGUS =MiYyFXtBxoljhbpWELQeDCNswfaGHq(MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('page'))
  MiYyFXtBxoljhbpWELQeDCNswfaGUR,MiYyFXtBxoljhbpWELQeDCNswfaGUu=MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.GetLiveChannelList(MiYyFXtBxoljhbpWELQeDCNswfaGUO,MiYyFXtBxoljhbpWELQeDCNswfaGUS)
  for MiYyFXtBxoljhbpWELQeDCNswfaGUI in MiYyFXtBxoljhbpWELQeDCNswfaGUR:
   MiYyFXtBxoljhbpWELQeDCNswfaGOR =MiYyFXtBxoljhbpWELQeDCNswfaGUI.get('title')
   MiYyFXtBxoljhbpWELQeDCNswfaGOV =MiYyFXtBxoljhbpWELQeDCNswfaGUI.get('channel')
   MiYyFXtBxoljhbpWELQeDCNswfaGUT =MiYyFXtBxoljhbpWELQeDCNswfaGUI.get('thumbnail')
   MiYyFXtBxoljhbpWELQeDCNswfaGUK =MiYyFXtBxoljhbpWELQeDCNswfaGUI.get('synopsis')
   MiYyFXtBxoljhbpWELQeDCNswfaGUr =MiYyFXtBxoljhbpWELQeDCNswfaGUI.get('channelepg')
   MiYyFXtBxoljhbpWELQeDCNswfaGUk =MiYyFXtBxoljhbpWELQeDCNswfaGUI.get('cast')
   MiYyFXtBxoljhbpWELQeDCNswfaGUJ =MiYyFXtBxoljhbpWELQeDCNswfaGUI.get('info_genre')
   MiYyFXtBxoljhbpWELQeDCNswfaGUV={'mediatype':'video','title':MiYyFXtBxoljhbpWELQeDCNswfaGOR,'studio':MiYyFXtBxoljhbpWELQeDCNswfaGOV,'cast':MiYyFXtBxoljhbpWELQeDCNswfaGUk,'genre':MiYyFXtBxoljhbpWELQeDCNswfaGUJ,'plot':'%s\n%s\n%s\n\n%s'%(MiYyFXtBxoljhbpWELQeDCNswfaGOV,MiYyFXtBxoljhbpWELQeDCNswfaGOR,MiYyFXtBxoljhbpWELQeDCNswfaGUr,MiYyFXtBxoljhbpWELQeDCNswfaGUK)}
   MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':'LIVE','mediacode':MiYyFXtBxoljhbpWELQeDCNswfaGUI.get('mediacode'),'stype':MiYyFXtBxoljhbpWELQeDCNswfaGUO}
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOV,sublabel=MiYyFXtBxoljhbpWELQeDCNswfaGOR,img=MiYyFXtBxoljhbpWELQeDCNswfaGUT,infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGUV,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHn,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGUu:
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['mode']='CHANNEL' 
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['stype']=MiYyFXtBxoljhbpWELQeDCNswfaGUO 
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['page']=MiYyFXtBxoljhbpWELQeDCNswfaGHA(MiYyFXtBxoljhbpWELQeDCNswfaGUS+1)
   MiYyFXtBxoljhbpWELQeDCNswfaGOR='[B]%s >>[/B]'%'다음 페이지'
   MiYyFXtBxoljhbpWELQeDCNswfaGUz=MiYyFXtBxoljhbpWELQeDCNswfaGHA(MiYyFXtBxoljhbpWELQeDCNswfaGUS+1)
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel=MiYyFXtBxoljhbpWELQeDCNswfaGUz,img='',infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGHz,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHg,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGHc(MiYyFXtBxoljhbpWELQeDCNswfaGUR)>0:xbmcplugin.endOfDirectory(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle,cacheToDisc=MiYyFXtBxoljhbpWELQeDCNswfaGHn)
 def dp_Program_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUH):
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.SaveCredential(MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_winCredential())
  MiYyFXtBxoljhbpWELQeDCNswfaGUq =MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('stype')
  MiYyFXtBxoljhbpWELQeDCNswfaGUn =MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('orderby')
  MiYyFXtBxoljhbpWELQeDCNswfaGUS =MiYyFXtBxoljhbpWELQeDCNswfaGHq(MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('page'))
  MiYyFXtBxoljhbpWELQeDCNswfaGUg=MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('genreCode')
  if MiYyFXtBxoljhbpWELQeDCNswfaGUg==MiYyFXtBxoljhbpWELQeDCNswfaGHz:MiYyFXtBxoljhbpWELQeDCNswfaGUg='all'
  MiYyFXtBxoljhbpWELQeDCNswfaGUc,MiYyFXtBxoljhbpWELQeDCNswfaGUu=MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.GetProgramList(MiYyFXtBxoljhbpWELQeDCNswfaGUq,MiYyFXtBxoljhbpWELQeDCNswfaGUn,MiYyFXtBxoljhbpWELQeDCNswfaGUS,MiYyFXtBxoljhbpWELQeDCNswfaGUg,landyn=MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_settings_thumbnail_landyn())
  for MiYyFXtBxoljhbpWELQeDCNswfaGUA in MiYyFXtBxoljhbpWELQeDCNswfaGUc:
   MiYyFXtBxoljhbpWELQeDCNswfaGOR =MiYyFXtBxoljhbpWELQeDCNswfaGUA.get('title')
   MiYyFXtBxoljhbpWELQeDCNswfaGUT =MiYyFXtBxoljhbpWELQeDCNswfaGUA.get('thumbnail')
   MiYyFXtBxoljhbpWELQeDCNswfaGUK =MiYyFXtBxoljhbpWELQeDCNswfaGUA.get('synopsis')
   MiYyFXtBxoljhbpWELQeDCNswfaGUP =MiYyFXtBxoljhbpWELQeDCNswfaGUA.get('channel')
   MiYyFXtBxoljhbpWELQeDCNswfaGUk =MiYyFXtBxoljhbpWELQeDCNswfaGUA.get('cast')
   MiYyFXtBxoljhbpWELQeDCNswfaGmv =MiYyFXtBxoljhbpWELQeDCNswfaGUA.get('director')
   MiYyFXtBxoljhbpWELQeDCNswfaGUJ=MiYyFXtBxoljhbpWELQeDCNswfaGUA.get('info_genre')
   MiYyFXtBxoljhbpWELQeDCNswfaGmO =MiYyFXtBxoljhbpWELQeDCNswfaGUA.get('year')
   MiYyFXtBxoljhbpWELQeDCNswfaGmU =MiYyFXtBxoljhbpWELQeDCNswfaGUA.get('aired')
   MiYyFXtBxoljhbpWELQeDCNswfaGUV={'mediatype':'episode','title':MiYyFXtBxoljhbpWELQeDCNswfaGOR,'studio':MiYyFXtBxoljhbpWELQeDCNswfaGUP,'cast':MiYyFXtBxoljhbpWELQeDCNswfaGUk,'director':MiYyFXtBxoljhbpWELQeDCNswfaGmv,'genre':MiYyFXtBxoljhbpWELQeDCNswfaGUJ,'year':MiYyFXtBxoljhbpWELQeDCNswfaGmO,'aired':MiYyFXtBxoljhbpWELQeDCNswfaGmU,'plot':'%s <%s>\n\n%s'%(MiYyFXtBxoljhbpWELQeDCNswfaGOR,MiYyFXtBxoljhbpWELQeDCNswfaGUP,MiYyFXtBxoljhbpWELQeDCNswfaGUK)}
   MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':'EPISODE','programcode':MiYyFXtBxoljhbpWELQeDCNswfaGUA.get('program'),'page':'1'}
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel=MiYyFXtBxoljhbpWELQeDCNswfaGUP,img=MiYyFXtBxoljhbpWELQeDCNswfaGUT,infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGUV,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHg,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGUu:
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['mode'] ='PROGRAM' 
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['stype'] =MiYyFXtBxoljhbpWELQeDCNswfaGUq
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['orderby'] =MiYyFXtBxoljhbpWELQeDCNswfaGUn
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['page'] =MiYyFXtBxoljhbpWELQeDCNswfaGHA(MiYyFXtBxoljhbpWELQeDCNswfaGUS+1)
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['genreCode']=MiYyFXtBxoljhbpWELQeDCNswfaGUg 
   MiYyFXtBxoljhbpWELQeDCNswfaGOR='[B]%s >>[/B]'%'다음 페이지'
   MiYyFXtBxoljhbpWELQeDCNswfaGUz=MiYyFXtBxoljhbpWELQeDCNswfaGHA(MiYyFXtBxoljhbpWELQeDCNswfaGUS+1)
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel=MiYyFXtBxoljhbpWELQeDCNswfaGUz,img='',infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGHz,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHg,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGHc(MiYyFXtBxoljhbpWELQeDCNswfaGUc)>0:xbmcplugin.endOfDirectory(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle,cacheToDisc=MiYyFXtBxoljhbpWELQeDCNswfaGHn)
 def dp_Episode_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUH):
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.SaveCredential(MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_winCredential())
  MiYyFXtBxoljhbpWELQeDCNswfaGmd=MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('programcode')
  MiYyFXtBxoljhbpWELQeDCNswfaGUS =MiYyFXtBxoljhbpWELQeDCNswfaGHq(MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('page'))
  MiYyFXtBxoljhbpWELQeDCNswfaGmH,MiYyFXtBxoljhbpWELQeDCNswfaGUu,MiYyFXtBxoljhbpWELQeDCNswfaGmS=MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.GetEpisodoList(MiYyFXtBxoljhbpWELQeDCNswfaGmd,MiYyFXtBxoljhbpWELQeDCNswfaGUS,orderby=MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_winEpisodeOrderby())
  for MiYyFXtBxoljhbpWELQeDCNswfaGmR in MiYyFXtBxoljhbpWELQeDCNswfaGmH:
   MiYyFXtBxoljhbpWELQeDCNswfaGOR =MiYyFXtBxoljhbpWELQeDCNswfaGmR.get('title')
   MiYyFXtBxoljhbpWELQeDCNswfaGUz =MiYyFXtBxoljhbpWELQeDCNswfaGmR.get('subtitle')
   MiYyFXtBxoljhbpWELQeDCNswfaGUT =MiYyFXtBxoljhbpWELQeDCNswfaGmR.get('thumbnail')
   MiYyFXtBxoljhbpWELQeDCNswfaGUK =MiYyFXtBxoljhbpWELQeDCNswfaGmR.get('synopsis')
   MiYyFXtBxoljhbpWELQeDCNswfaGmu=MiYyFXtBxoljhbpWELQeDCNswfaGmR.get('info_title')
   MiYyFXtBxoljhbpWELQeDCNswfaGmU =MiYyFXtBxoljhbpWELQeDCNswfaGmR.get('aired')
   MiYyFXtBxoljhbpWELQeDCNswfaGmI =MiYyFXtBxoljhbpWELQeDCNswfaGmR.get('studio')
   MiYyFXtBxoljhbpWELQeDCNswfaGmT =MiYyFXtBxoljhbpWELQeDCNswfaGmR.get('frequency')
   MiYyFXtBxoljhbpWELQeDCNswfaGUV={'mediatype':'episode','title':MiYyFXtBxoljhbpWELQeDCNswfaGmu,'aired':MiYyFXtBxoljhbpWELQeDCNswfaGmU,'studio':MiYyFXtBxoljhbpWELQeDCNswfaGmI,'episode':MiYyFXtBxoljhbpWELQeDCNswfaGmT,'plot':'%s\n\n%s'%(MiYyFXtBxoljhbpWELQeDCNswfaGOR,MiYyFXtBxoljhbpWELQeDCNswfaGUK)}
   MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':'VOD','mediacode':MiYyFXtBxoljhbpWELQeDCNswfaGmR.get('episode'),'stype':'vod','programcode':MiYyFXtBxoljhbpWELQeDCNswfaGmd,'title':MiYyFXtBxoljhbpWELQeDCNswfaGOR,'thumbnail':MiYyFXtBxoljhbpWELQeDCNswfaGUT}
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel=MiYyFXtBxoljhbpWELQeDCNswfaGUz,img=MiYyFXtBxoljhbpWELQeDCNswfaGUT,infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGUV,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHn,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGUS==1:
   MiYyFXtBxoljhbpWELQeDCNswfaGUV={'plot':'정렬순서를 변경합니다.'}
   MiYyFXtBxoljhbpWELQeDCNswfaGOk={}
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['mode'] ='ORDER_BY' 
   if MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_winEpisodeOrderby()=='desc':
    MiYyFXtBxoljhbpWELQeDCNswfaGOR='정렬순서변경 : 최신화부터 -> 1회부터'
    MiYyFXtBxoljhbpWELQeDCNswfaGOk['orderby']='asc'
   else:
    MiYyFXtBxoljhbpWELQeDCNswfaGOR='정렬순서변경 : 1회부터 -> 최신화부터'
    MiYyFXtBxoljhbpWELQeDCNswfaGOk['orderby']='desc'
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel='',img='',infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGUV,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHn,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGUu:
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['mode'] ='EPISODE' 
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['programcode']=MiYyFXtBxoljhbpWELQeDCNswfaGmd
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['page'] =MiYyFXtBxoljhbpWELQeDCNswfaGHA(MiYyFXtBxoljhbpWELQeDCNswfaGUS+1)
   MiYyFXtBxoljhbpWELQeDCNswfaGOR='[B]%s >>[/B]'%'다음 페이지'
   MiYyFXtBxoljhbpWELQeDCNswfaGUz=MiYyFXtBxoljhbpWELQeDCNswfaGHA(MiYyFXtBxoljhbpWELQeDCNswfaGUS+1)
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel=MiYyFXtBxoljhbpWELQeDCNswfaGUz,img='',infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGHz,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHg,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGHc(MiYyFXtBxoljhbpWELQeDCNswfaGmH)>0:xbmcplugin.endOfDirectory(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle,cacheToDisc=MiYyFXtBxoljhbpWELQeDCNswfaGHg)
 def dp_setEpOrderby(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUH):
  MiYyFXtBxoljhbpWELQeDCNswfaGUn =MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('orderby')
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.set_winEpisodeOrderby(MiYyFXtBxoljhbpWELQeDCNswfaGUn)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUH):
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.SaveCredential(MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_winCredential())
  MiYyFXtBxoljhbpWELQeDCNswfaGUq =MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('stype')
  MiYyFXtBxoljhbpWELQeDCNswfaGUn =MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('orderby')
  MiYyFXtBxoljhbpWELQeDCNswfaGUS=MiYyFXtBxoljhbpWELQeDCNswfaGHq(MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('page'))
  MiYyFXtBxoljhbpWELQeDCNswfaGmK,MiYyFXtBxoljhbpWELQeDCNswfaGUu=MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.GetMovieList(MiYyFXtBxoljhbpWELQeDCNswfaGUq,MiYyFXtBxoljhbpWELQeDCNswfaGUn,MiYyFXtBxoljhbpWELQeDCNswfaGUS,landyn=MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_settings_thumbnail_landyn())
  for MiYyFXtBxoljhbpWELQeDCNswfaGmr in MiYyFXtBxoljhbpWELQeDCNswfaGmK:
   MiYyFXtBxoljhbpWELQeDCNswfaGOR =MiYyFXtBxoljhbpWELQeDCNswfaGmr.get('title')
   MiYyFXtBxoljhbpWELQeDCNswfaGUT =MiYyFXtBxoljhbpWELQeDCNswfaGmr.get('thumbnail')
   MiYyFXtBxoljhbpWELQeDCNswfaGUK =MiYyFXtBxoljhbpWELQeDCNswfaGmr.get('synopsis')
   MiYyFXtBxoljhbpWELQeDCNswfaGmu =MiYyFXtBxoljhbpWELQeDCNswfaGmr.get('info_title')
   MiYyFXtBxoljhbpWELQeDCNswfaGmO =MiYyFXtBxoljhbpWELQeDCNswfaGmr.get('year')
   MiYyFXtBxoljhbpWELQeDCNswfaGUk =MiYyFXtBxoljhbpWELQeDCNswfaGmr.get('cast')
   MiYyFXtBxoljhbpWELQeDCNswfaGmv =MiYyFXtBxoljhbpWELQeDCNswfaGmr.get('director')
   MiYyFXtBxoljhbpWELQeDCNswfaGUJ =MiYyFXtBxoljhbpWELQeDCNswfaGmr.get('info_genre')
   MiYyFXtBxoljhbpWELQeDCNswfaGmk =MiYyFXtBxoljhbpWELQeDCNswfaGmr.get('duration')
   MiYyFXtBxoljhbpWELQeDCNswfaGmU =MiYyFXtBxoljhbpWELQeDCNswfaGmr.get('aired')
   MiYyFXtBxoljhbpWELQeDCNswfaGUV={'mediatype':'movie','title':MiYyFXtBxoljhbpWELQeDCNswfaGmu,'year':MiYyFXtBxoljhbpWELQeDCNswfaGmO,'cast':MiYyFXtBxoljhbpWELQeDCNswfaGUk,'director':MiYyFXtBxoljhbpWELQeDCNswfaGmv,'genre':MiYyFXtBxoljhbpWELQeDCNswfaGUJ,'duration':MiYyFXtBxoljhbpWELQeDCNswfaGmk,'aired':MiYyFXtBxoljhbpWELQeDCNswfaGmU,'plot':'%s\n\n%s'%(MiYyFXtBxoljhbpWELQeDCNswfaGOR,MiYyFXtBxoljhbpWELQeDCNswfaGUK)}
   MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':'MOVIE','mediacode':MiYyFXtBxoljhbpWELQeDCNswfaGmr.get('moviecode'),'stype':'movie','title':MiYyFXtBxoljhbpWELQeDCNswfaGOR,'thumbnail':MiYyFXtBxoljhbpWELQeDCNswfaGUT}
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel='',img=MiYyFXtBxoljhbpWELQeDCNswfaGUT,infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGUV,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHn,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGUu:
   MiYyFXtBxoljhbpWELQeDCNswfaGOk={}
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['mode'] ='MOVIE_SUB' 
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['orderby']=MiYyFXtBxoljhbpWELQeDCNswfaGUn
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['stype'] =MiYyFXtBxoljhbpWELQeDCNswfaGUq
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['page'] =MiYyFXtBxoljhbpWELQeDCNswfaGHA(MiYyFXtBxoljhbpWELQeDCNswfaGUS+1)
   MiYyFXtBxoljhbpWELQeDCNswfaGOR='[B]%s >>[/B]'%'다음 페이지'
   MiYyFXtBxoljhbpWELQeDCNswfaGUz=MiYyFXtBxoljhbpWELQeDCNswfaGHA(MiYyFXtBxoljhbpWELQeDCNswfaGUS+1)
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel=MiYyFXtBxoljhbpWELQeDCNswfaGUz,img='',infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGHz,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHg,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGHc(MiYyFXtBxoljhbpWELQeDCNswfaGmK)>0:xbmcplugin.endOfDirectory(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle,cacheToDisc=MiYyFXtBxoljhbpWELQeDCNswfaGHn)
 def dp_Search_Group(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUH):
  for MiYyFXtBxoljhbpWELQeDCNswfaGUd in MiYyFXtBxoljhbpWELQeDCNswfaGvH:
   MiYyFXtBxoljhbpWELQeDCNswfaGOR=MiYyFXtBxoljhbpWELQeDCNswfaGUd.get('title')
   MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':MiYyFXtBxoljhbpWELQeDCNswfaGUd.get('mode'),'stype':MiYyFXtBxoljhbpWELQeDCNswfaGUd.get('stype'),'page':'1'}
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel='',img='',infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGHz,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHg,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGHc(MiYyFXtBxoljhbpWELQeDCNswfaGvH)>0:xbmcplugin.endOfDirectory(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle)
 def dp_Search_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUH):
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.SaveCredential(MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_winCredential())
  MiYyFXtBxoljhbpWELQeDCNswfaGmJ =__addon__.getSetting('id')
  MiYyFXtBxoljhbpWELQeDCNswfaGUS =MiYyFXtBxoljhbpWELQeDCNswfaGHq(MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('page'))
  MiYyFXtBxoljhbpWELQeDCNswfaGUO =MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('stype')
  if 'search_key' in MiYyFXtBxoljhbpWELQeDCNswfaGUH:
   MiYyFXtBxoljhbpWELQeDCNswfaGmV=MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('search_key')
  else:
   MiYyFXtBxoljhbpWELQeDCNswfaGmV=MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not MiYyFXtBxoljhbpWELQeDCNswfaGmV:return
  MiYyFXtBxoljhbpWELQeDCNswfaGmz,MiYyFXtBxoljhbpWELQeDCNswfaGUu=MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.GetSearchList(MiYyFXtBxoljhbpWELQeDCNswfaGmV,MiYyFXtBxoljhbpWELQeDCNswfaGmJ,MiYyFXtBxoljhbpWELQeDCNswfaGUS,MiYyFXtBxoljhbpWELQeDCNswfaGUO,landyn=MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_settings_thumbnail_landyn())
  if MiYyFXtBxoljhbpWELQeDCNswfaGHc(MiYyFXtBxoljhbpWELQeDCNswfaGmz)==0:return
  for MiYyFXtBxoljhbpWELQeDCNswfaGmq in MiYyFXtBxoljhbpWELQeDCNswfaGmz:
   MiYyFXtBxoljhbpWELQeDCNswfaGOR =MiYyFXtBxoljhbpWELQeDCNswfaGmq.get('title')
   MiYyFXtBxoljhbpWELQeDCNswfaGUT =MiYyFXtBxoljhbpWELQeDCNswfaGmq.get('thumbnail')
   MiYyFXtBxoljhbpWELQeDCNswfaGUK =MiYyFXtBxoljhbpWELQeDCNswfaGmq.get('synopsis')
   MiYyFXtBxoljhbpWELQeDCNswfaGmn =MiYyFXtBxoljhbpWELQeDCNswfaGmq.get('program')
   MiYyFXtBxoljhbpWELQeDCNswfaGUk =MiYyFXtBxoljhbpWELQeDCNswfaGmq.get('cast')
   MiYyFXtBxoljhbpWELQeDCNswfaGmv =MiYyFXtBxoljhbpWELQeDCNswfaGmq.get('director')
   MiYyFXtBxoljhbpWELQeDCNswfaGUJ=MiYyFXtBxoljhbpWELQeDCNswfaGmq.get('info_genre')
   MiYyFXtBxoljhbpWELQeDCNswfaGmk =MiYyFXtBxoljhbpWELQeDCNswfaGmq.get('duration')
   MiYyFXtBxoljhbpWELQeDCNswfaGmg =MiYyFXtBxoljhbpWELQeDCNswfaGmq.get('mpaa')
   MiYyFXtBxoljhbpWELQeDCNswfaGmO =MiYyFXtBxoljhbpWELQeDCNswfaGmq.get('year')
   MiYyFXtBxoljhbpWELQeDCNswfaGmU =MiYyFXtBxoljhbpWELQeDCNswfaGmq.get('aired')
   MiYyFXtBxoljhbpWELQeDCNswfaGUV={'mediatype':'episode' if MiYyFXtBxoljhbpWELQeDCNswfaGUO=='vod' else 'movie','title':MiYyFXtBxoljhbpWELQeDCNswfaGOR,'cast':MiYyFXtBxoljhbpWELQeDCNswfaGUk,'director':MiYyFXtBxoljhbpWELQeDCNswfaGmv,'genre':MiYyFXtBxoljhbpWELQeDCNswfaGUJ,'duration':MiYyFXtBxoljhbpWELQeDCNswfaGmk,'mpaa':MiYyFXtBxoljhbpWELQeDCNswfaGmg,'year':MiYyFXtBxoljhbpWELQeDCNswfaGmO,'aired':MiYyFXtBxoljhbpWELQeDCNswfaGmU,'plot':'%s\n\n%s'%(MiYyFXtBxoljhbpWELQeDCNswfaGOR,MiYyFXtBxoljhbpWELQeDCNswfaGUK)}
   if MiYyFXtBxoljhbpWELQeDCNswfaGUO=='vod':
    MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':'EPISODE','programcode':MiYyFXtBxoljhbpWELQeDCNswfaGmq.get('program'),'page':'1'}
    MiYyFXtBxoljhbpWELQeDCNswfaGOJ=MiYyFXtBxoljhbpWELQeDCNswfaGHg
   else:
    MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':'MOVIE','mediacode':MiYyFXtBxoljhbpWELQeDCNswfaGmq.get('movie'),'stype':'movie','title':MiYyFXtBxoljhbpWELQeDCNswfaGOR,'thumbnail':MiYyFXtBxoljhbpWELQeDCNswfaGUT}
    MiYyFXtBxoljhbpWELQeDCNswfaGOJ=MiYyFXtBxoljhbpWELQeDCNswfaGHn
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel='',img=MiYyFXtBxoljhbpWELQeDCNswfaGUT,infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGUV,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGOJ,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGUu:
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['mode'] ='SEARCH' 
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['search_key']=MiYyFXtBxoljhbpWELQeDCNswfaGmV
   MiYyFXtBxoljhbpWELQeDCNswfaGOk['page'] =MiYyFXtBxoljhbpWELQeDCNswfaGHA(MiYyFXtBxoljhbpWELQeDCNswfaGUS+1)
   MiYyFXtBxoljhbpWELQeDCNswfaGOR='[B]%s >>[/B]'%'다음 페이지'
   MiYyFXtBxoljhbpWELQeDCNswfaGUz=MiYyFXtBxoljhbpWELQeDCNswfaGHA(MiYyFXtBxoljhbpWELQeDCNswfaGUS+1)
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel=MiYyFXtBxoljhbpWELQeDCNswfaGUz,img='',infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGHz,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHg,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  if MiYyFXtBxoljhbpWELQeDCNswfaGHc(MiYyFXtBxoljhbpWELQeDCNswfaGmz)>0:xbmcplugin.endOfDirectory(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle)
 def Delete_Watched_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUO):
  try:
   MiYyFXtBxoljhbpWELQeDCNswfaGmc=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%MiYyFXtBxoljhbpWELQeDCNswfaGUO))
   fp=MiYyFXtBxoljhbpWELQeDCNswfaGHP(MiYyFXtBxoljhbpWELQeDCNswfaGmc,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   MiYyFXtBxoljhbpWELQeDCNswfaGHz
 def dp_WatchList_Delete(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUH):
  MiYyFXtBxoljhbpWELQeDCNswfaGUO=MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('stype')
  MiYyFXtBxoljhbpWELQeDCNswfaGvV=xbmcgui.Dialog()
  MiYyFXtBxoljhbpWELQeDCNswfaGOc=MiYyFXtBxoljhbpWELQeDCNswfaGvV.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if MiYyFXtBxoljhbpWELQeDCNswfaGOc==MiYyFXtBxoljhbpWELQeDCNswfaGHn:sys.exit()
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.Delete_Watched_List(MiYyFXtBxoljhbpWELQeDCNswfaGUO)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUO):
  try:
   MiYyFXtBxoljhbpWELQeDCNswfaGmc=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%MiYyFXtBxoljhbpWELQeDCNswfaGUO))
   fp=MiYyFXtBxoljhbpWELQeDCNswfaGHP(MiYyFXtBxoljhbpWELQeDCNswfaGmc,'r',-1,'utf-8')
   MiYyFXtBxoljhbpWELQeDCNswfaGmA=fp.readlines()
   fp.close()
  except:
   MiYyFXtBxoljhbpWELQeDCNswfaGmA=[]
  return MiYyFXtBxoljhbpWELQeDCNswfaGmA
 def Save_Watched_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUO,MiYyFXtBxoljhbpWELQeDCNswfaGvk):
  try:
   MiYyFXtBxoljhbpWELQeDCNswfaGmc=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%MiYyFXtBxoljhbpWELQeDCNswfaGUO))
   MiYyFXtBxoljhbpWELQeDCNswfaGmP=MiYyFXtBxoljhbpWELQeDCNswfaGvT.Load_Watched_List(MiYyFXtBxoljhbpWELQeDCNswfaGUO) 
   fp=MiYyFXtBxoljhbpWELQeDCNswfaGHP(MiYyFXtBxoljhbpWELQeDCNswfaGmc,'w',-1,'utf-8')
   MiYyFXtBxoljhbpWELQeDCNswfaGdv=urllib.parse.urlencode(MiYyFXtBxoljhbpWELQeDCNswfaGvk)
   MiYyFXtBxoljhbpWELQeDCNswfaGdv=MiYyFXtBxoljhbpWELQeDCNswfaGdv+'\n'
   fp.write(MiYyFXtBxoljhbpWELQeDCNswfaGdv)
   MiYyFXtBxoljhbpWELQeDCNswfaGdO=0
   for MiYyFXtBxoljhbpWELQeDCNswfaGdU in MiYyFXtBxoljhbpWELQeDCNswfaGmP:
    MiYyFXtBxoljhbpWELQeDCNswfaGdm=MiYyFXtBxoljhbpWELQeDCNswfaGSv(urllib.parse.parse_qsl(MiYyFXtBxoljhbpWELQeDCNswfaGdU))
    MiYyFXtBxoljhbpWELQeDCNswfaGdH=MiYyFXtBxoljhbpWELQeDCNswfaGvk.get('code').strip()
    MiYyFXtBxoljhbpWELQeDCNswfaGdS=MiYyFXtBxoljhbpWELQeDCNswfaGdm.get('code').strip()
    if MiYyFXtBxoljhbpWELQeDCNswfaGUO=='vod' and MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_settings_direct_replay()==MiYyFXtBxoljhbpWELQeDCNswfaGHg:
     MiYyFXtBxoljhbpWELQeDCNswfaGdH=MiYyFXtBxoljhbpWELQeDCNswfaGvk.get('videoid').strip()
     MiYyFXtBxoljhbpWELQeDCNswfaGdS=MiYyFXtBxoljhbpWELQeDCNswfaGdm.get('videoid').strip()if MiYyFXtBxoljhbpWELQeDCNswfaGdS!=MiYyFXtBxoljhbpWELQeDCNswfaGHz else '-'
    if MiYyFXtBxoljhbpWELQeDCNswfaGdH!=MiYyFXtBxoljhbpWELQeDCNswfaGdS:
     fp.write(MiYyFXtBxoljhbpWELQeDCNswfaGdU)
     MiYyFXtBxoljhbpWELQeDCNswfaGdO+=1
     if MiYyFXtBxoljhbpWELQeDCNswfaGdO>=50:break
   fp.close()
  except:
   MiYyFXtBxoljhbpWELQeDCNswfaGHz
 def dp_Watch_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUH):
  MiYyFXtBxoljhbpWELQeDCNswfaGUO =MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('stype')
  MiYyFXtBxoljhbpWELQeDCNswfaGOU=MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_settings_direct_replay()
  if MiYyFXtBxoljhbpWELQeDCNswfaGUO=='-':
   for MiYyFXtBxoljhbpWELQeDCNswfaGUd in MiYyFXtBxoljhbpWELQeDCNswfaGvd:
    MiYyFXtBxoljhbpWELQeDCNswfaGOR=MiYyFXtBxoljhbpWELQeDCNswfaGUd.get('title')
    MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':MiYyFXtBxoljhbpWELQeDCNswfaGUd.get('mode'),'stype':MiYyFXtBxoljhbpWELQeDCNswfaGUd.get('stype')}
    MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel='',img='',infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGHz,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHg,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
   if MiYyFXtBxoljhbpWELQeDCNswfaGHc(MiYyFXtBxoljhbpWELQeDCNswfaGvd)>0:xbmcplugin.endOfDirectory(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle)
  else:
   MiYyFXtBxoljhbpWELQeDCNswfaGdR=MiYyFXtBxoljhbpWELQeDCNswfaGvT.Load_Watched_List(MiYyFXtBxoljhbpWELQeDCNswfaGUO)
   for MiYyFXtBxoljhbpWELQeDCNswfaGdu in MiYyFXtBxoljhbpWELQeDCNswfaGdR:
    MiYyFXtBxoljhbpWELQeDCNswfaGdI=MiYyFXtBxoljhbpWELQeDCNswfaGSv(urllib.parse.parse_qsl(MiYyFXtBxoljhbpWELQeDCNswfaGdu))
    MiYyFXtBxoljhbpWELQeDCNswfaGdT =MiYyFXtBxoljhbpWELQeDCNswfaGdI.get('code').strip()
    MiYyFXtBxoljhbpWELQeDCNswfaGOR =MiYyFXtBxoljhbpWELQeDCNswfaGdI.get('title').strip()
    MiYyFXtBxoljhbpWELQeDCNswfaGUT=MiYyFXtBxoljhbpWELQeDCNswfaGdI.get('img').strip()
    MiYyFXtBxoljhbpWELQeDCNswfaGdK =MiYyFXtBxoljhbpWELQeDCNswfaGdI.get('videoid').strip()
    MiYyFXtBxoljhbpWELQeDCNswfaGUV={}
    MiYyFXtBxoljhbpWELQeDCNswfaGUV['plot']=MiYyFXtBxoljhbpWELQeDCNswfaGOR
    if MiYyFXtBxoljhbpWELQeDCNswfaGUO=='vod':
     if MiYyFXtBxoljhbpWELQeDCNswfaGOU==MiYyFXtBxoljhbpWELQeDCNswfaGHn or MiYyFXtBxoljhbpWELQeDCNswfaGdK==MiYyFXtBxoljhbpWELQeDCNswfaGHz:
      MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':'EPISODE','programcode':MiYyFXtBxoljhbpWELQeDCNswfaGdT,'page':'1'}
      MiYyFXtBxoljhbpWELQeDCNswfaGOJ=MiYyFXtBxoljhbpWELQeDCNswfaGHg
     else:
      MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':'VOD','mediacode':MiYyFXtBxoljhbpWELQeDCNswfaGdK,'stype':'vod','programcode':MiYyFXtBxoljhbpWELQeDCNswfaGdT,'title':MiYyFXtBxoljhbpWELQeDCNswfaGOR,'thumbnail':MiYyFXtBxoljhbpWELQeDCNswfaGUT}
      MiYyFXtBxoljhbpWELQeDCNswfaGOJ=MiYyFXtBxoljhbpWELQeDCNswfaGHn
    else:
     MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':'MOVIE','mediacode':MiYyFXtBxoljhbpWELQeDCNswfaGdT,'stype':'movie','title':MiYyFXtBxoljhbpWELQeDCNswfaGOR,'thumbnail':MiYyFXtBxoljhbpWELQeDCNswfaGUT}
     MiYyFXtBxoljhbpWELQeDCNswfaGOJ=MiYyFXtBxoljhbpWELQeDCNswfaGHn
    MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel='',img=MiYyFXtBxoljhbpWELQeDCNswfaGUT,infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGUV,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGOJ,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
   MiYyFXtBxoljhbpWELQeDCNswfaGUV={'plot':'시청목록을 삭제합니다.'}
   MiYyFXtBxoljhbpWELQeDCNswfaGOR='*** 시청목록 삭제 ***'
   MiYyFXtBxoljhbpWELQeDCNswfaGOk={'mode':'MYVIEW_REMOVE','stype':MiYyFXtBxoljhbpWELQeDCNswfaGUO}
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.add_dir(MiYyFXtBxoljhbpWELQeDCNswfaGOR,sublabel='',img='',infoLabels=MiYyFXtBxoljhbpWELQeDCNswfaGUV,isFolder=MiYyFXtBxoljhbpWELQeDCNswfaGHn,params=MiYyFXtBxoljhbpWELQeDCNswfaGOk)
   xbmcplugin.endOfDirectory(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle,cacheToDisc=MiYyFXtBxoljhbpWELQeDCNswfaGHn)
 def play_VIDEO(MiYyFXtBxoljhbpWELQeDCNswfaGvT,MiYyFXtBxoljhbpWELQeDCNswfaGUH):
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.SaveCredential(MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_winCredential())
  MiYyFXtBxoljhbpWELQeDCNswfaGdk =MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('mediacode')
  MiYyFXtBxoljhbpWELQeDCNswfaGUO =MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('stype')
  MiYyFXtBxoljhbpWELQeDCNswfaGdJ =MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('pvrmode')
  MiYyFXtBxoljhbpWELQeDCNswfaGdV=MiYyFXtBxoljhbpWELQeDCNswfaGvT.get_selQuality(MiYyFXtBxoljhbpWELQeDCNswfaGUO)
  MiYyFXtBxoljhbpWELQeDCNswfaGdz,MiYyFXtBxoljhbpWELQeDCNswfaGdq=MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.GetBroadURL(MiYyFXtBxoljhbpWELQeDCNswfaGdk,MiYyFXtBxoljhbpWELQeDCNswfaGdV,MiYyFXtBxoljhbpWELQeDCNswfaGUO,MiYyFXtBxoljhbpWELQeDCNswfaGdJ)
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.addon_log('qt, stype, url : %s - %s - %s'%(MiYyFXtBxoljhbpWELQeDCNswfaGHA(MiYyFXtBxoljhbpWELQeDCNswfaGdV),MiYyFXtBxoljhbpWELQeDCNswfaGUO,MiYyFXtBxoljhbpWELQeDCNswfaGdz))
  if MiYyFXtBxoljhbpWELQeDCNswfaGdz=='':
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.addon_noti(__language__(30908).encode('utf8'))
   return
  MiYyFXtBxoljhbpWELQeDCNswfaGdn =MiYyFXtBxoljhbpWELQeDCNswfaGdz.find('Policy=')
  if MiYyFXtBxoljhbpWELQeDCNswfaGdn!=-1:
   MiYyFXtBxoljhbpWELQeDCNswfaGdg =MiYyFXtBxoljhbpWELQeDCNswfaGdz.split('?')[0]
   MiYyFXtBxoljhbpWELQeDCNswfaGdc=MiYyFXtBxoljhbpWELQeDCNswfaGSv(urllib.parse.parse_qsl(urllib.parse.urlsplit(MiYyFXtBxoljhbpWELQeDCNswfaGdz).query))
   MiYyFXtBxoljhbpWELQeDCNswfaGdc=urllib.parse.urlencode(MiYyFXtBxoljhbpWELQeDCNswfaGdc)
   MiYyFXtBxoljhbpWELQeDCNswfaGdc=MiYyFXtBxoljhbpWELQeDCNswfaGdc.replace('&',';')
   MiYyFXtBxoljhbpWELQeDCNswfaGdc=MiYyFXtBxoljhbpWELQeDCNswfaGdc.replace('Policy','CloudFront-Policy')
   MiYyFXtBxoljhbpWELQeDCNswfaGdc=MiYyFXtBxoljhbpWELQeDCNswfaGdc.replace('Signature','CloudFront-Signature')
   MiYyFXtBxoljhbpWELQeDCNswfaGdc=MiYyFXtBxoljhbpWELQeDCNswfaGdc.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   MiYyFXtBxoljhbpWELQeDCNswfaGdA='%s|Cookie=%s'%(MiYyFXtBxoljhbpWELQeDCNswfaGdg,MiYyFXtBxoljhbpWELQeDCNswfaGdc)
  else:
   MiYyFXtBxoljhbpWELQeDCNswfaGdA=MiYyFXtBxoljhbpWELQeDCNswfaGdz
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.addon_log(MiYyFXtBxoljhbpWELQeDCNswfaGdA)
  MiYyFXtBxoljhbpWELQeDCNswfaGdP=xbmcgui.ListItem(path=MiYyFXtBxoljhbpWELQeDCNswfaGdA)
  if MiYyFXtBxoljhbpWELQeDCNswfaGdq!='':
   MiYyFXtBxoljhbpWELQeDCNswfaGHv=MiYyFXtBxoljhbpWELQeDCNswfaGdq
   MiYyFXtBxoljhbpWELQeDCNswfaGHO ='https://cj.drmkeyserver.com/widevine_license'
   MiYyFXtBxoljhbpWELQeDCNswfaGHU ='mpd'
   MiYyFXtBxoljhbpWELQeDCNswfaGHm ='com.widevine.alpha'
   MiYyFXtBxoljhbpWELQeDCNswfaGHd =inputstreamhelper.Helper(MiYyFXtBxoljhbpWELQeDCNswfaGHU,drm='widevine')
   if MiYyFXtBxoljhbpWELQeDCNswfaGHd.check_inputstream():
    MiYyFXtBxoljhbpWELQeDCNswfaGHS={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%MiYyFXtBxoljhbpWELQeDCNswfaGdk,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.USER_AGENT,'AcquireLicenseAssertion':MiYyFXtBxoljhbpWELQeDCNswfaGHv,'Host':'cj.drmkeyserver.com'}
    MiYyFXtBxoljhbpWELQeDCNswfaGHR=MiYyFXtBxoljhbpWELQeDCNswfaGHO+'|'+urllib.parse.urlencode(MiYyFXtBxoljhbpWELQeDCNswfaGHS)+'|R{SSM}|'
    MiYyFXtBxoljhbpWELQeDCNswfaGdP.setProperty('inputstream',MiYyFXtBxoljhbpWELQeDCNswfaGHd.inputstream_addon)
    MiYyFXtBxoljhbpWELQeDCNswfaGdP.setProperty('inputstream.adaptive.manifest_type',MiYyFXtBxoljhbpWELQeDCNswfaGHU)
    MiYyFXtBxoljhbpWELQeDCNswfaGdP.setProperty('inputstream.adaptive.license_type',MiYyFXtBxoljhbpWELQeDCNswfaGHm)
    MiYyFXtBxoljhbpWELQeDCNswfaGdP.setProperty('inputstream.adaptive.license_key',MiYyFXtBxoljhbpWELQeDCNswfaGHR)
    MiYyFXtBxoljhbpWELQeDCNswfaGdP.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.USER_AGENT))
  xbmcplugin.setResolvedUrl(MiYyFXtBxoljhbpWELQeDCNswfaGvT._addon_handle,MiYyFXtBxoljhbpWELQeDCNswfaGHg,MiYyFXtBxoljhbpWELQeDCNswfaGdP)
  try:
   if MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('mode')in['VOD','MOVIE']and MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('title'):
    MiYyFXtBxoljhbpWELQeDCNswfaGOk={'code':MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('programcode')if MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('mode')=='VOD' else MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('mediacode'),'img':MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('thumbnail'),'title':MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('title'),'videoid':MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('mediacode')}
    MiYyFXtBxoljhbpWELQeDCNswfaGvT.Save_Watched_List(MiYyFXtBxoljhbpWELQeDCNswfaGUH.get('stype'),MiYyFXtBxoljhbpWELQeDCNswfaGOk)
  except:
   MiYyFXtBxoljhbpWELQeDCNswfaGHz
 def logout(MiYyFXtBxoljhbpWELQeDCNswfaGvT):
  MiYyFXtBxoljhbpWELQeDCNswfaGvV=xbmcgui.Dialog()
  MiYyFXtBxoljhbpWELQeDCNswfaGOc=MiYyFXtBxoljhbpWELQeDCNswfaGvV.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if MiYyFXtBxoljhbpWELQeDCNswfaGOc==MiYyFXtBxoljhbpWELQeDCNswfaGHn:sys.exit()
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.wininfo_clear()
  if os.path.isfile(MiYyFXtBxoljhbpWELQeDCNswfaGvI):os.remove(MiYyFXtBxoljhbpWELQeDCNswfaGvI)
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(MiYyFXtBxoljhbpWELQeDCNswfaGvT):
  MiYyFXtBxoljhbpWELQeDCNswfaGOd=xbmcgui.Window(10000)
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_TOKEN','')
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_USERINFO','')
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_UUID','')
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_LOGINTIME','')
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_MAINTOKEN','')
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_COOKIEKEY','')
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(MiYyFXtBxoljhbpWELQeDCNswfaGvT):
  MiYyFXtBxoljhbpWELQeDCNswfaGHu =MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.Get_Now_Datetime()
  MiYyFXtBxoljhbpWELQeDCNswfaGHI=MiYyFXtBxoljhbpWELQeDCNswfaGHu+datetime.timedelta(days=MiYyFXtBxoljhbpWELQeDCNswfaGHq(__addon__.getSetting('cache_ttl')))
  MiYyFXtBxoljhbpWELQeDCNswfaGOd=xbmcgui.Window(10000)
  MiYyFXtBxoljhbpWELQeDCNswfaGHT={'tving_token':MiYyFXtBxoljhbpWELQeDCNswfaGOd.getProperty('TVING_M_TOKEN'),'tving_userinfo':MiYyFXtBxoljhbpWELQeDCNswfaGOd.getProperty('TVING_M_USERINFO'),'tving_uuid':MiYyFXtBxoljhbpWELQeDCNswfaGOd.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':MiYyFXtBxoljhbpWELQeDCNswfaGHI.strftime('%Y-%m-%d'),'tving_maintoken':MiYyFXtBxoljhbpWELQeDCNswfaGOd.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':MiYyFXtBxoljhbpWELQeDCNswfaGOd.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':MiYyFXtBxoljhbpWELQeDCNswfaGOd.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=MiYyFXtBxoljhbpWELQeDCNswfaGHP(MiYyFXtBxoljhbpWELQeDCNswfaGvI,'w',-1,'utf-8')
   json.dump(MiYyFXtBxoljhbpWELQeDCNswfaGHT,fp)
   fp.close()
  except MiYyFXtBxoljhbpWELQeDCNswfaGSO as exception:
   MiYyFXtBxoljhbpWELQeDCNswfaGSU(exception)
 def cookiefile_check(MiYyFXtBxoljhbpWELQeDCNswfaGvT):
  MiYyFXtBxoljhbpWELQeDCNswfaGHT={}
  try: 
   fp=MiYyFXtBxoljhbpWELQeDCNswfaGHP(MiYyFXtBxoljhbpWELQeDCNswfaGvI,'r',-1,'utf-8')
   MiYyFXtBxoljhbpWELQeDCNswfaGHT= json.load(fp)
   fp.close()
  except MiYyFXtBxoljhbpWELQeDCNswfaGSO as exception:
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.wininfo_clear()
   return MiYyFXtBxoljhbpWELQeDCNswfaGHn
  MiYyFXtBxoljhbpWELQeDCNswfaGOz =__addon__.getSetting('id')
  MiYyFXtBxoljhbpWELQeDCNswfaGOq =__addon__.getSetting('pw')
  MiYyFXtBxoljhbpWELQeDCNswfaGHK=__addon__.getSetting('login_type')
  MiYyFXtBxoljhbpWELQeDCNswfaGHr =__addon__.getSetting('selected_profile')
  MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_id']=base64.standard_b64decode(MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_id']).decode('utf-8')
  MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_pw']=base64.standard_b64decode(MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_pw']).decode('utf-8')
  try:
   MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_profile']
  except:
   MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_profile']='0'
  if MiYyFXtBxoljhbpWELQeDCNswfaGOz!=MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_id']or MiYyFXtBxoljhbpWELQeDCNswfaGOq!=MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_pw']or MiYyFXtBxoljhbpWELQeDCNswfaGHK!=MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_logintype']or MiYyFXtBxoljhbpWELQeDCNswfaGHr!=MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_profile']:
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.wininfo_clear()
   return MiYyFXtBxoljhbpWELQeDCNswfaGHn
  MiYyFXtBxoljhbpWELQeDCNswfaGOA =MiYyFXtBxoljhbpWELQeDCNswfaGHq(MiYyFXtBxoljhbpWELQeDCNswfaGvT.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  MiYyFXtBxoljhbpWELQeDCNswfaGHk=MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_limitdate']
  MiYyFXtBxoljhbpWELQeDCNswfaGOP =MiYyFXtBxoljhbpWELQeDCNswfaGHq(re.sub('-','',MiYyFXtBxoljhbpWELQeDCNswfaGHk))
  if MiYyFXtBxoljhbpWELQeDCNswfaGOP<MiYyFXtBxoljhbpWELQeDCNswfaGOA:
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.wininfo_clear()
   return MiYyFXtBxoljhbpWELQeDCNswfaGHn
  MiYyFXtBxoljhbpWELQeDCNswfaGOd=xbmcgui.Window(10000)
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_TOKEN',MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_token'])
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_USERINFO',MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_userinfo'])
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_UUID',MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_uuid'])
  MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_LOGINTIME',MiYyFXtBxoljhbpWELQeDCNswfaGHk)
  try:
   MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_MAINTOKEN',MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_maintoken'])
   MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_COOKIEKEY',MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_cookiekey'])
   MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_LOCKKEY',MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_lockkey'])
  except:
   MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_MAINTOKEN',MiYyFXtBxoljhbpWELQeDCNswfaGHT['tving_token'])
   MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_COOKIEKEY','Y')
   MiYyFXtBxoljhbpWELQeDCNswfaGOd.setProperty('TVING_M_LOCKKEY','N')
  return MiYyFXtBxoljhbpWELQeDCNswfaGHg
 def tving_main(MiYyFXtBxoljhbpWELQeDCNswfaGvT):
  MiYyFXtBxoljhbpWELQeDCNswfaGHJ=MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params.get('mode',MiYyFXtBxoljhbpWELQeDCNswfaGHz)
  if MiYyFXtBxoljhbpWELQeDCNswfaGHJ=='LOGOUT':
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.logout()
   return
  MiYyFXtBxoljhbpWELQeDCNswfaGvT.login_main()
  if MiYyFXtBxoljhbpWELQeDCNswfaGHJ is MiYyFXtBxoljhbpWELQeDCNswfaGHz:
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.dp_Main_List()
  elif MiYyFXtBxoljhbpWELQeDCNswfaGHJ in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.dp_Title_Group(MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params)
  elif MiYyFXtBxoljhbpWELQeDCNswfaGHJ in['GLOBAL_GROUP']:
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.dp_SubTitle_Group(MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params)
  elif MiYyFXtBxoljhbpWELQeDCNswfaGHJ=='CHANNEL':
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.dp_LiveChannel_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params)
  elif MiYyFXtBxoljhbpWELQeDCNswfaGHJ in['LIVE','VOD','MOVIE']:
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.play_VIDEO(MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params)
  elif MiYyFXtBxoljhbpWELQeDCNswfaGHJ=='PROGRAM':
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.dp_Program_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params)
  elif MiYyFXtBxoljhbpWELQeDCNswfaGHJ=='EPISODE':
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.dp_Episode_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params)
  elif MiYyFXtBxoljhbpWELQeDCNswfaGHJ=='MOVIE_SUB':
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.dp_Movie_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params)
  elif MiYyFXtBxoljhbpWELQeDCNswfaGHJ=='SEARCH_GROUP':
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.dp_Search_Group(MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params)
  elif MiYyFXtBxoljhbpWELQeDCNswfaGHJ=='SEARCH':
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.dp_Search_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params)
  elif MiYyFXtBxoljhbpWELQeDCNswfaGHJ=='WATCH':
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.dp_Watch_List(MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params)
  elif MiYyFXtBxoljhbpWELQeDCNswfaGHJ=='MYVIEW_REMOVE':
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.dp_WatchList_Delete(MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params)
  elif MiYyFXtBxoljhbpWELQeDCNswfaGHJ=='ORDER_BY':
   MiYyFXtBxoljhbpWELQeDCNswfaGvT.dp_setEpOrderby(MiYyFXtBxoljhbpWELQeDCNswfaGvT.main_params)
  else:
   MiYyFXtBxoljhbpWELQeDCNswfaGHz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
