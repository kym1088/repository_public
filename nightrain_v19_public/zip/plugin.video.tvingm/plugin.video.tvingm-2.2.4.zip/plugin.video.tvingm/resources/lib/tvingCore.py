__author__="NightRain"
eBNhylkPaspxIJdqHGvVWwcirzoDXg=object
eBNhylkPaspxIJdqHGvVWwcirzoDXS=None
eBNhylkPaspxIJdqHGvVWwcirzoDXF=False
eBNhylkPaspxIJdqHGvVWwcirzoDXC=int
eBNhylkPaspxIJdqHGvVWwcirzoDXn=range
eBNhylkPaspxIJdqHGvVWwcirzoDXQ=True
eBNhylkPaspxIJdqHGvVWwcirzoDXA=Exception
eBNhylkPaspxIJdqHGvVWwcirzoDXb=print
eBNhylkPaspxIJdqHGvVWwcirzoDXE=str
eBNhylkPaspxIJdqHGvVWwcirzoDXK=list
eBNhylkPaspxIJdqHGvVWwcirzoDUM=len
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import random
eBNhylkPaspxIJdqHGvVWwcirzoDMj={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
class eBNhylkPaspxIJdqHGvVWwcirzoDMT(eBNhylkPaspxIJdqHGvVWwcirzoDXg):
 def __init__(eBNhylkPaspxIJdqHGvVWwcirzoDMR):
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_TOKEN =''
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.POC_USERINFO =''
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_UUID ='-'
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_MAINTOKEN=''
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVIGN_COOKIEKEY=''
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_LOCKKEY =''
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.NETWORKCODE ='CSND0900'
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.OSCODE ='CSOD0900' 
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.TELECODE ='CSCD0900'
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.SCREENCODE ='CSSD0100'
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.LIVE_LIMIT =23
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.VOD_LIMIT =20
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.EPISODE_LIMIT =30 
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.SEARCH_LIMIT =80 
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.MOVIE_LIMIT =18
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.API_DOMAIN ='https://api.tving.com'
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN ='https://image.tving.com'
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.SEARCH_DOMAIN ='https://search.tving.com'
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.LOGIN_DOMAIN ='https://user.tving.com'
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.URL_DOMAIN ='https://www.tving.com'
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.MOVIE_LITE =['2610061','2610161','261062']
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.DEFAULT_HEADER ={'user-agent':eBNhylkPaspxIJdqHGvVWwcirzoDMR.USER_AGENT}
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(eBNhylkPaspxIJdqHGvVWwcirzoDMR,jobtype,eBNhylkPaspxIJdqHGvVWwcirzoDTu,payload=eBNhylkPaspxIJdqHGvVWwcirzoDXS,params=eBNhylkPaspxIJdqHGvVWwcirzoDXS,headers=eBNhylkPaspxIJdqHGvVWwcirzoDXS,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDXS,redirects=eBNhylkPaspxIJdqHGvVWwcirzoDXF):
  eBNhylkPaspxIJdqHGvVWwcirzoDMX=eBNhylkPaspxIJdqHGvVWwcirzoDMR.DEFAULT_HEADER
  if headers:eBNhylkPaspxIJdqHGvVWwcirzoDMX.update(headers)
  if jobtype=='Get':
   eBNhylkPaspxIJdqHGvVWwcirzoDMU=requests.get(eBNhylkPaspxIJdqHGvVWwcirzoDTu,params=params,headers=eBNhylkPaspxIJdqHGvVWwcirzoDMX,cookies=cookies,allow_redirects=redirects)
  else:
   eBNhylkPaspxIJdqHGvVWwcirzoDMU=requests.post(eBNhylkPaspxIJdqHGvVWwcirzoDTu,data=payload,params=params,headers=eBNhylkPaspxIJdqHGvVWwcirzoDMX,cookies=cookies,allow_redirects=redirects)
  return eBNhylkPaspxIJdqHGvVWwcirzoDMU
 def makeDefaultCookies(eBNhylkPaspxIJdqHGvVWwcirzoDMR,vToken=eBNhylkPaspxIJdqHGvVWwcirzoDXS,vUserinfo=eBNhylkPaspxIJdqHGvVWwcirzoDXS):
  eBNhylkPaspxIJdqHGvVWwcirzoDMm={}
  eBNhylkPaspxIJdqHGvVWwcirzoDMm['_tving_token']=eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_TOKEN if vToken==eBNhylkPaspxIJdqHGvVWwcirzoDXS else vToken
  eBNhylkPaspxIJdqHGvVWwcirzoDMm['POC_USERINFO']=eBNhylkPaspxIJdqHGvVWwcirzoDMR.POC_USERINFO if vToken==eBNhylkPaspxIJdqHGvVWwcirzoDXS else vUserinfo
  if eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_MAINTOKEN!='':eBNhylkPaspxIJdqHGvVWwcirzoDMm[eBNhylkPaspxIJdqHGvVWwcirzoDMR.GLOBAL_COOKIENM['tv_maintoken']]=eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_MAINTOKEN
  if eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVIGN_COOKIEKEY!='':eBNhylkPaspxIJdqHGvVWwcirzoDMm[eBNhylkPaspxIJdqHGvVWwcirzoDMR.GLOBAL_COOKIENM['tv_cookiekey']]=eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVIGN_COOKIEKEY
  if eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_LOCKKEY !='':eBNhylkPaspxIJdqHGvVWwcirzoDMm[eBNhylkPaspxIJdqHGvVWwcirzoDMR.GLOBAL_COOKIENM['tv_lockkey']] =eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_LOCKKEY
  return eBNhylkPaspxIJdqHGvVWwcirzoDMm
 def getDeviceStr(eBNhylkPaspxIJdqHGvVWwcirzoDMR):
  eBNhylkPaspxIJdqHGvVWwcirzoDML=[]
  eBNhylkPaspxIJdqHGvVWwcirzoDML.append('Windows') 
  eBNhylkPaspxIJdqHGvVWwcirzoDML.append('Chrome') 
  eBNhylkPaspxIJdqHGvVWwcirzoDML.append('ko-KR') 
  eBNhylkPaspxIJdqHGvVWwcirzoDML.append('undefined') 
  eBNhylkPaspxIJdqHGvVWwcirzoDML.append('24') 
  eBNhylkPaspxIJdqHGvVWwcirzoDML.append(u'한국 표준시')
  eBNhylkPaspxIJdqHGvVWwcirzoDML.append('undefined') 
  eBNhylkPaspxIJdqHGvVWwcirzoDML.append('undefined') 
  eBNhylkPaspxIJdqHGvVWwcirzoDML.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  eBNhylkPaspxIJdqHGvVWwcirzoDMf=''
  for eBNhylkPaspxIJdqHGvVWwcirzoDMO in eBNhylkPaspxIJdqHGvVWwcirzoDML:
   eBNhylkPaspxIJdqHGvVWwcirzoDMf+=eBNhylkPaspxIJdqHGvVWwcirzoDMO+'|'
  return eBNhylkPaspxIJdqHGvVWwcirzoDMf
 def SaveCredential(eBNhylkPaspxIJdqHGvVWwcirzoDMR,eBNhylkPaspxIJdqHGvVWwcirzoDMt):
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_TOKEN =eBNhylkPaspxIJdqHGvVWwcirzoDMt.get('tving_token')
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.POC_USERINFO =eBNhylkPaspxIJdqHGvVWwcirzoDMt.get('poc_userinfo')
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_UUID =eBNhylkPaspxIJdqHGvVWwcirzoDMt.get('tving_uuid')
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_MAINTOKEN=eBNhylkPaspxIJdqHGvVWwcirzoDMt.get('tving_maintoken')
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVIGN_COOKIEKEY=eBNhylkPaspxIJdqHGvVWwcirzoDMt.get('tving_cookiekey')
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_LOCKKEY =eBNhylkPaspxIJdqHGvVWwcirzoDMt.get('tving_lockkey')
 def LoadCredential(eBNhylkPaspxIJdqHGvVWwcirzoDMR):
  eBNhylkPaspxIJdqHGvVWwcirzoDMt={'tving_token':eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_TOKEN,'poc_userinfo':eBNhylkPaspxIJdqHGvVWwcirzoDMR.POC_USERINFO,'tving_uuid':eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_UUID,'tving_maintoken':eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_MAINTOKEN,'tving_cookiekey':eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVIGN_COOKIEKEY,'tving_lockkey':eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_LOCKKEY}
  return eBNhylkPaspxIJdqHGvVWwcirzoDMt
 def GetDefaultParams(eBNhylkPaspxIJdqHGvVWwcirzoDMR):
  eBNhylkPaspxIJdqHGvVWwcirzoDMY={'apiKey':eBNhylkPaspxIJdqHGvVWwcirzoDMR.APIKEY,'networkCode':eBNhylkPaspxIJdqHGvVWwcirzoDMR.NETWORKCODE,'osCode':eBNhylkPaspxIJdqHGvVWwcirzoDMR.OSCODE,'teleCode':eBNhylkPaspxIJdqHGvVWwcirzoDMR.TELECODE,'screenCode':eBNhylkPaspxIJdqHGvVWwcirzoDMR.SCREENCODE}
  return eBNhylkPaspxIJdqHGvVWwcirzoDMY
 def GetNoCache(eBNhylkPaspxIJdqHGvVWwcirzoDMR,timetype=1):
  if timetype==1:
   return eBNhylkPaspxIJdqHGvVWwcirzoDXC(time.time())
  else:
   return eBNhylkPaspxIJdqHGvVWwcirzoDXC(time.time()*1000)
 def GetUniqueid(eBNhylkPaspxIJdqHGvVWwcirzoDMR):
  eBNhylkPaspxIJdqHGvVWwcirzoDMu=[0 for i in eBNhylkPaspxIJdqHGvVWwcirzoDXn(256)]
  for i in eBNhylkPaspxIJdqHGvVWwcirzoDXn(256):
   eBNhylkPaspxIJdqHGvVWwcirzoDMu[i]='%02x'%(i)
  eBNhylkPaspxIJdqHGvVWwcirzoDMg=eBNhylkPaspxIJdqHGvVWwcirzoDXC(4294967295*random.random())|0
  eBNhylkPaspxIJdqHGvVWwcirzoDMS=eBNhylkPaspxIJdqHGvVWwcirzoDMu[255&eBNhylkPaspxIJdqHGvVWwcirzoDMg]+eBNhylkPaspxIJdqHGvVWwcirzoDMu[eBNhylkPaspxIJdqHGvVWwcirzoDMg>>8&255]+eBNhylkPaspxIJdqHGvVWwcirzoDMu[eBNhylkPaspxIJdqHGvVWwcirzoDMg>>16&255]+eBNhylkPaspxIJdqHGvVWwcirzoDMu[eBNhylkPaspxIJdqHGvVWwcirzoDMg>>24&255]
  return eBNhylkPaspxIJdqHGvVWwcirzoDMS
 def GetCredential(eBNhylkPaspxIJdqHGvVWwcirzoDMR,user_id,user_pw,login_type,user_pf):
  eBNhylkPaspxIJdqHGvVWwcirzoDMF=eBNhylkPaspxIJdqHGvVWwcirzoDXF
  eBNhylkPaspxIJdqHGvVWwcirzoDMC=eBNhylkPaspxIJdqHGvVWwcirzoDMK=eBNhylkPaspxIJdqHGvVWwcirzoDTM=eBNhylkPaspxIJdqHGvVWwcirzoDTj=eBNhylkPaspxIJdqHGvVWwcirzoDTR='' 
  eBNhylkPaspxIJdqHGvVWwcirzoDMn ='-'
  try:
   eBNhylkPaspxIJdqHGvVWwcirzoDMQ=eBNhylkPaspxIJdqHGvVWwcirzoDMR.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   eBNhylkPaspxIJdqHGvVWwcirzoDMA={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   eBNhylkPaspxIJdqHGvVWwcirzoDMb=eBNhylkPaspxIJdqHGvVWwcirzoDMR.callRequestCookies('Post',eBNhylkPaspxIJdqHGvVWwcirzoDMQ,payload=eBNhylkPaspxIJdqHGvVWwcirzoDMA,params=eBNhylkPaspxIJdqHGvVWwcirzoDXS,headers=eBNhylkPaspxIJdqHGvVWwcirzoDXS,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDXS)
   for eBNhylkPaspxIJdqHGvVWwcirzoDME in eBNhylkPaspxIJdqHGvVWwcirzoDMb.cookies:
    if eBNhylkPaspxIJdqHGvVWwcirzoDME.name=='_tving_token':
     eBNhylkPaspxIJdqHGvVWwcirzoDMK=eBNhylkPaspxIJdqHGvVWwcirzoDME.value
    elif eBNhylkPaspxIJdqHGvVWwcirzoDME.name=='POC_USERINFO':
     eBNhylkPaspxIJdqHGvVWwcirzoDTM=eBNhylkPaspxIJdqHGvVWwcirzoDME.value
   if eBNhylkPaspxIJdqHGvVWwcirzoDMK=='':return eBNhylkPaspxIJdqHGvVWwcirzoDMF
   eBNhylkPaspxIJdqHGvVWwcirzoDMC=eBNhylkPaspxIJdqHGvVWwcirzoDMK
   eBNhylkPaspxIJdqHGvVWwcirzoDMK,eBNhylkPaspxIJdqHGvVWwcirzoDTj,eBNhylkPaspxIJdqHGvVWwcirzoDTR=eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetProfileToken(eBNhylkPaspxIJdqHGvVWwcirzoDMK,eBNhylkPaspxIJdqHGvVWwcirzoDTM,user_pf)
   eBNhylkPaspxIJdqHGvVWwcirzoDMF=eBNhylkPaspxIJdqHGvVWwcirzoDXQ
   eBNhylkPaspxIJdqHGvVWwcirzoDMn =eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetDeviceList(eBNhylkPaspxIJdqHGvVWwcirzoDMK,eBNhylkPaspxIJdqHGvVWwcirzoDTM)
   eBNhylkPaspxIJdqHGvVWwcirzoDMn =eBNhylkPaspxIJdqHGvVWwcirzoDMn+'-'+eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetUniqueid()
  except eBNhylkPaspxIJdqHGvVWwcirzoDXA as exception:
   eBNhylkPaspxIJdqHGvVWwcirzoDMC=eBNhylkPaspxIJdqHGvVWwcirzoDMK=eBNhylkPaspxIJdqHGvVWwcirzoDTM=eBNhylkPaspxIJdqHGvVWwcirzoDTj=eBNhylkPaspxIJdqHGvVWwcirzoDTR=''
   eBNhylkPaspxIJdqHGvVWwcirzoDMn='-'
   eBNhylkPaspxIJdqHGvVWwcirzoDXb(exception)
  eBNhylkPaspxIJdqHGvVWwcirzoDMt={'tving_token':eBNhylkPaspxIJdqHGvVWwcirzoDMK,'poc_userinfo':eBNhylkPaspxIJdqHGvVWwcirzoDTM,'tving_uuid':eBNhylkPaspxIJdqHGvVWwcirzoDMn,'tving_maintoken':eBNhylkPaspxIJdqHGvVWwcirzoDMC,'tving_cookiekey':eBNhylkPaspxIJdqHGvVWwcirzoDTj,'tving_lockkey':eBNhylkPaspxIJdqHGvVWwcirzoDTR}
  eBNhylkPaspxIJdqHGvVWwcirzoDMR.SaveCredential(eBNhylkPaspxIJdqHGvVWwcirzoDMt)
  return eBNhylkPaspxIJdqHGvVWwcirzoDMF
 def Get_Now_Datetime(eBNhylkPaspxIJdqHGvVWwcirzoDMR):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(eBNhylkPaspxIJdqHGvVWwcirzoDMR,mediacode,sel_quality,stype,pvrmode='-'):
  eBNhylkPaspxIJdqHGvVWwcirzoDTU=''
  eBNhylkPaspxIJdqHGvVWwcirzoDTm=''
  eBNhylkPaspxIJdqHGvVWwcirzoDTL =eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_UUID.split('-')[0] 
  eBNhylkPaspxIJdqHGvVWwcirzoDTf =eBNhylkPaspxIJdqHGvVWwcirzoDMR.TVING_UUID 
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    eBNhylkPaspxIJdqHGvVWwcirzoDTO ='/v2a/media/stream/info' 
    eBNhylkPaspxIJdqHGvVWwcirzoDTt=eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetDefaultParams()
    eBNhylkPaspxIJdqHGvVWwcirzoDTY={'info':'N','mediaCode':mediacode,'noCache':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':eBNhylkPaspxIJdqHGvVWwcirzoDTL,'uuid':eBNhylkPaspxIJdqHGvVWwcirzoDTf,'deviceInfo':'PC','wm':'Y'}
    eBNhylkPaspxIJdqHGvVWwcirzoDTt.update(eBNhylkPaspxIJdqHGvVWwcirzoDTY)
    eBNhylkPaspxIJdqHGvVWwcirzoDTu=eBNhylkPaspxIJdqHGvVWwcirzoDMR.API_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTO
    eBNhylkPaspxIJdqHGvVWwcirzoDMm=eBNhylkPaspxIJdqHGvVWwcirzoDMR.makeDefaultCookies()
    eBNhylkPaspxIJdqHGvVWwcirzoDMb=eBNhylkPaspxIJdqHGvVWwcirzoDMR.callRequestCookies('Get',eBNhylkPaspxIJdqHGvVWwcirzoDTu,payload=eBNhylkPaspxIJdqHGvVWwcirzoDXS,params=eBNhylkPaspxIJdqHGvVWwcirzoDTt,headers=eBNhylkPaspxIJdqHGvVWwcirzoDXS,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDMm)
    eBNhylkPaspxIJdqHGvVWwcirzoDTg=json.loads(eBNhylkPaspxIJdqHGvVWwcirzoDMb.text)
    if not('stream' in eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']):return eBNhylkPaspxIJdqHGvVWwcirzoDTU,eBNhylkPaspxIJdqHGvVWwcirzoDTm 
    eBNhylkPaspxIJdqHGvVWwcirzoDTS=eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']['stream']
    eBNhylkPaspxIJdqHGvVWwcirzoDXb(eBNhylkPaspxIJdqHGvVWwcirzoDTS)
    eBNhylkPaspxIJdqHGvVWwcirzoDTF=eBNhylkPaspxIJdqHGvVWwcirzoDTS['quality']
    eBNhylkPaspxIJdqHGvVWwcirzoDTC=[]
    for eBNhylkPaspxIJdqHGvVWwcirzoDTn in eBNhylkPaspxIJdqHGvVWwcirzoDTF:
     if eBNhylkPaspxIJdqHGvVWwcirzoDTn['active']=='Y':
      eBNhylkPaspxIJdqHGvVWwcirzoDTC.append({eBNhylkPaspxIJdqHGvVWwcirzoDMj.get(eBNhylkPaspxIJdqHGvVWwcirzoDTn['code']):eBNhylkPaspxIJdqHGvVWwcirzoDTn['code']})
    eBNhylkPaspxIJdqHGvVWwcirzoDTQ=eBNhylkPaspxIJdqHGvVWwcirzoDMR.CheckQuality(sel_quality,eBNhylkPaspxIJdqHGvVWwcirzoDTC)
   else:
    for eBNhylkPaspxIJdqHGvVWwcirzoDTA,eBNhylkPaspxIJdqHGvVWwcirzoDjU in eBNhylkPaspxIJdqHGvVWwcirzoDMj.items():
     if eBNhylkPaspxIJdqHGvVWwcirzoDjU==sel_quality:
      eBNhylkPaspxIJdqHGvVWwcirzoDTQ=eBNhylkPaspxIJdqHGvVWwcirzoDTA
  except eBNhylkPaspxIJdqHGvVWwcirzoDXA as exception:
   eBNhylkPaspxIJdqHGvVWwcirzoDXb(exception)
   for eBNhylkPaspxIJdqHGvVWwcirzoDTA,eBNhylkPaspxIJdqHGvVWwcirzoDjU in eBNhylkPaspxIJdqHGvVWwcirzoDMj.items():
    if eBNhylkPaspxIJdqHGvVWwcirzoDjU==sel_quality:
     eBNhylkPaspxIJdqHGvVWwcirzoDTQ=eBNhylkPaspxIJdqHGvVWwcirzoDTA
   return eBNhylkPaspxIJdqHGvVWwcirzoDTU,eBNhylkPaspxIJdqHGvVWwcirzoDTm
  eBNhylkPaspxIJdqHGvVWwcirzoDXb(eBNhylkPaspxIJdqHGvVWwcirzoDTQ)
  try:
   eBNhylkPaspxIJdqHGvVWwcirzoDTO ='/streaming/info'
   eBNhylkPaspxIJdqHGvVWwcirzoDTt=eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetDefaultParams()
   if stype=='onair':eBNhylkPaspxIJdqHGvVWwcirzoDTt['osCode']='CSOD0400' 
   eBNhylkPaspxIJdqHGvVWwcirzoDTb={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   eBNhylkPaspxIJdqHGvVWwcirzoDTE=eBNhylkPaspxIJdqHGvVWwcirzoDMR.makeOocUrl(eBNhylkPaspxIJdqHGvVWwcirzoDTb)
   eBNhylkPaspxIJdqHGvVWwcirzoDTK=urllib.parse.quote(eBNhylkPaspxIJdqHGvVWwcirzoDTE)
   eBNhylkPaspxIJdqHGvVWwcirzoDTY={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':eBNhylkPaspxIJdqHGvVWwcirzoDTQ,'adReq':'adproxy','ooc':eBNhylkPaspxIJdqHGvVWwcirzoDTE,'deviceId':eBNhylkPaspxIJdqHGvVWwcirzoDTL,'uuid':eBNhylkPaspxIJdqHGvVWwcirzoDTf,'deviceInfo':'PC'}
   eBNhylkPaspxIJdqHGvVWwcirzoDjM =eBNhylkPaspxIJdqHGvVWwcirzoDTt
   eBNhylkPaspxIJdqHGvVWwcirzoDjM.update(eBNhylkPaspxIJdqHGvVWwcirzoDTY)
   eBNhylkPaspxIJdqHGvVWwcirzoDTu=eBNhylkPaspxIJdqHGvVWwcirzoDMR.URL_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTO
   eBNhylkPaspxIJdqHGvVWwcirzoDjT={'origin':'https://www.tving.com'}
   if stype=='onair':eBNhylkPaspxIJdqHGvVWwcirzoDjT['Referer']='https://www.tving.com/live/player/'+mediacode
   else: eBNhylkPaspxIJdqHGvVWwcirzoDjT['Referer']='https://www.tving.com/vod/player/'+mediacode
   eBNhylkPaspxIJdqHGvVWwcirzoDMm=eBNhylkPaspxIJdqHGvVWwcirzoDMR.makeDefaultCookies()
   eBNhylkPaspxIJdqHGvVWwcirzoDMm['onClickEvent2']=eBNhylkPaspxIJdqHGvVWwcirzoDTK
   eBNhylkPaspxIJdqHGvVWwcirzoDMb=eBNhylkPaspxIJdqHGvVWwcirzoDMR.callRequestCookies('Post',eBNhylkPaspxIJdqHGvVWwcirzoDTu,payload=eBNhylkPaspxIJdqHGvVWwcirzoDjM,params=eBNhylkPaspxIJdqHGvVWwcirzoDXS,headers=eBNhylkPaspxIJdqHGvVWwcirzoDjT,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDMm,redirects=eBNhylkPaspxIJdqHGvVWwcirzoDXF)
   eBNhylkPaspxIJdqHGvVWwcirzoDTg=json.loads(eBNhylkPaspxIJdqHGvVWwcirzoDMb.text)
   if 'drm_license_assertion' in eBNhylkPaspxIJdqHGvVWwcirzoDTg['stream']:
    eBNhylkPaspxIJdqHGvVWwcirzoDTm =eBNhylkPaspxIJdqHGvVWwcirzoDTg['stream']['drm_license_assertion']
    eBNhylkPaspxIJdqHGvVWwcirzoDTU=eBNhylkPaspxIJdqHGvVWwcirzoDTg['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in eBNhylkPaspxIJdqHGvVWwcirzoDTg['stream']['broadcast']):return eBNhylkPaspxIJdqHGvVWwcirzoDTU,eBNhylkPaspxIJdqHGvVWwcirzoDTm
    eBNhylkPaspxIJdqHGvVWwcirzoDTU=eBNhylkPaspxIJdqHGvVWwcirzoDTg['stream']['broadcast']['broad_url']
  except eBNhylkPaspxIJdqHGvVWwcirzoDXA as exception:
   eBNhylkPaspxIJdqHGvVWwcirzoDXb(exception)
  return eBNhylkPaspxIJdqHGvVWwcirzoDTU,eBNhylkPaspxIJdqHGvVWwcirzoDTm
 def CheckQuality(eBNhylkPaspxIJdqHGvVWwcirzoDMR,sel_qt,eBNhylkPaspxIJdqHGvVWwcirzoDTC):
  for eBNhylkPaspxIJdqHGvVWwcirzoDjR in eBNhylkPaspxIJdqHGvVWwcirzoDTC:
   if sel_qt>=eBNhylkPaspxIJdqHGvVWwcirzoDXK(eBNhylkPaspxIJdqHGvVWwcirzoDjR)[0]:return eBNhylkPaspxIJdqHGvVWwcirzoDjR.get(eBNhylkPaspxIJdqHGvVWwcirzoDXK(eBNhylkPaspxIJdqHGvVWwcirzoDjR)[0])
   eBNhylkPaspxIJdqHGvVWwcirzoDjX=eBNhylkPaspxIJdqHGvVWwcirzoDjR.get(eBNhylkPaspxIJdqHGvVWwcirzoDXK(eBNhylkPaspxIJdqHGvVWwcirzoDjR)[0])
  return eBNhylkPaspxIJdqHGvVWwcirzoDjX
 def makeOocUrl(eBNhylkPaspxIJdqHGvVWwcirzoDMR,eBNhylkPaspxIJdqHGvVWwcirzoDTb):
  eBNhylkPaspxIJdqHGvVWwcirzoDTu=''
  for eBNhylkPaspxIJdqHGvVWwcirzoDTA,eBNhylkPaspxIJdqHGvVWwcirzoDjU in eBNhylkPaspxIJdqHGvVWwcirzoDTb.items():
   eBNhylkPaspxIJdqHGvVWwcirzoDTu+="%s=%s^"%(eBNhylkPaspxIJdqHGvVWwcirzoDTA,eBNhylkPaspxIJdqHGvVWwcirzoDjU)
  return eBNhylkPaspxIJdqHGvVWwcirzoDTu
 def GetLiveChannelList(eBNhylkPaspxIJdqHGvVWwcirzoDMR,stype,page_int):
  eBNhylkPaspxIJdqHGvVWwcirzoDjm=[]
  eBNhylkPaspxIJdqHGvVWwcirzoDjL=eBNhylkPaspxIJdqHGvVWwcirzoDXF
  try:
   eBNhylkPaspxIJdqHGvVWwcirzoDTO ='/v2/media/lives'
   if stype=='onair': 
    eBNhylkPaspxIJdqHGvVWwcirzoDjf='CPCS0100,CPCS0400'
   else:
    eBNhylkPaspxIJdqHGvVWwcirzoDjf='CPCS0300'
   eBNhylkPaspxIJdqHGvVWwcirzoDTt=eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetDefaultParams()
   eBNhylkPaspxIJdqHGvVWwcirzoDTY={'pageNo':eBNhylkPaspxIJdqHGvVWwcirzoDXE(page_int),'pageSize':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':eBNhylkPaspxIJdqHGvVWwcirzoDjf,'_':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetNoCache(2))}
   eBNhylkPaspxIJdqHGvVWwcirzoDTt.update(eBNhylkPaspxIJdqHGvVWwcirzoDTY)
   eBNhylkPaspxIJdqHGvVWwcirzoDTu=eBNhylkPaspxIJdqHGvVWwcirzoDMR.API_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTO
   eBNhylkPaspxIJdqHGvVWwcirzoDMb=eBNhylkPaspxIJdqHGvVWwcirzoDMR.callRequestCookies('Get',eBNhylkPaspxIJdqHGvVWwcirzoDTu,payload=eBNhylkPaspxIJdqHGvVWwcirzoDXS,params=eBNhylkPaspxIJdqHGvVWwcirzoDTt,headers=eBNhylkPaspxIJdqHGvVWwcirzoDXS,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDXS)
   eBNhylkPaspxIJdqHGvVWwcirzoDTg=json.loads(eBNhylkPaspxIJdqHGvVWwcirzoDMb.text)
   if not('result' in eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']):return eBNhylkPaspxIJdqHGvVWwcirzoDjm,eBNhylkPaspxIJdqHGvVWwcirzoDjL
   eBNhylkPaspxIJdqHGvVWwcirzoDjO=eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']['result']
   for eBNhylkPaspxIJdqHGvVWwcirzoDTn in eBNhylkPaspxIJdqHGvVWwcirzoDjO:
    eBNhylkPaspxIJdqHGvVWwcirzoDjt=eBNhylkPaspxIJdqHGvVWwcirzoDjg=eBNhylkPaspxIJdqHGvVWwcirzoDjS=eBNhylkPaspxIJdqHGvVWwcirzoDjF=''
    eBNhylkPaspxIJdqHGvVWwcirzoDjY=eBNhylkPaspxIJdqHGvVWwcirzoDjA=''
    eBNhylkPaspxIJdqHGvVWwcirzoDju=eBNhylkPaspxIJdqHGvVWwcirzoDTn['live_code']
    eBNhylkPaspxIJdqHGvVWwcirzoDjt =eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['channel']['name']['ko']
    if eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['episode']!=eBNhylkPaspxIJdqHGvVWwcirzoDXS:
     eBNhylkPaspxIJdqHGvVWwcirzoDjg =eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['program']['name']['ko']
     eBNhylkPaspxIJdqHGvVWwcirzoDjg =eBNhylkPaspxIJdqHGvVWwcirzoDjg+', '+eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['episode']['frequency'])+'회'
     if eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['episode']['image']!=[]:
      eBNhylkPaspxIJdqHGvVWwcirzoDjS=eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['episode']['image'][0]['url']
     eBNhylkPaspxIJdqHGvVWwcirzoDjF=eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['episode']['synopsis']['ko']
    else:
     eBNhylkPaspxIJdqHGvVWwcirzoDjg =eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['program']['name']['ko']
     if eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['program']['image']!=[]:
      eBNhylkPaspxIJdqHGvVWwcirzoDjS=eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['program']['image'][0]['url']
     eBNhylkPaspxIJdqHGvVWwcirzoDjF=eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['program']['synopsis']['ko']
    try:
     eBNhylkPaspxIJdqHGvVWwcirzoDjC =[]
     eBNhylkPaspxIJdqHGvVWwcirzoDjn=[]
     for eBNhylkPaspxIJdqHGvVWwcirzoDjQ in eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('schedule').get('program').get('actor'):
      if eBNhylkPaspxIJdqHGvVWwcirzoDjQ!='' and eBNhylkPaspxIJdqHGvVWwcirzoDjQ!=u'없음':eBNhylkPaspxIJdqHGvVWwcirzoDjC.append(eBNhylkPaspxIJdqHGvVWwcirzoDjQ)
     if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('schedule').get('program').get('category1_name').get('ko')!='':
      eBNhylkPaspxIJdqHGvVWwcirzoDjn.append(eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['program']['category1_name']['ko'])
     if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('schedule').get('program').get('category2_name').get('ko')!='':
      eBNhylkPaspxIJdqHGvVWwcirzoDjn.append(eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['program']['category2_name']['ko'])
    except:
     eBNhylkPaspxIJdqHGvVWwcirzoDXS
    if eBNhylkPaspxIJdqHGvVWwcirzoDjS=='':
     eBNhylkPaspxIJdqHGvVWwcirzoDjS=eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['channel']['image'][0]['url']
    if eBNhylkPaspxIJdqHGvVWwcirzoDjS!='':eBNhylkPaspxIJdqHGvVWwcirzoDjS=eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDjS
    eBNhylkPaspxIJdqHGvVWwcirzoDjY=eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['broadcast_start_time'])[8:12]
    eBNhylkPaspxIJdqHGvVWwcirzoDjA =eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDTn['schedule']['broadcast_end_time'])[8:12]
    eBNhylkPaspxIJdqHGvVWwcirzoDjb={'channel':eBNhylkPaspxIJdqHGvVWwcirzoDjt,'title':eBNhylkPaspxIJdqHGvVWwcirzoDjg,'mediacode':eBNhylkPaspxIJdqHGvVWwcirzoDju,'thumbnail':eBNhylkPaspxIJdqHGvVWwcirzoDjS,'synopsis':eBNhylkPaspxIJdqHGvVWwcirzoDjF,'channelepg':' [%s:%s ~ %s:%s]'%(eBNhylkPaspxIJdqHGvVWwcirzoDjY[0:2],eBNhylkPaspxIJdqHGvVWwcirzoDjY[2:],eBNhylkPaspxIJdqHGvVWwcirzoDjA[0:2],eBNhylkPaspxIJdqHGvVWwcirzoDjA[2:]),'cast':eBNhylkPaspxIJdqHGvVWwcirzoDjC,'info_genre':eBNhylkPaspxIJdqHGvVWwcirzoDjn}
    eBNhylkPaspxIJdqHGvVWwcirzoDjm.append(eBNhylkPaspxIJdqHGvVWwcirzoDjb)
   if eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']['has_more']=='Y':eBNhylkPaspxIJdqHGvVWwcirzoDjL=eBNhylkPaspxIJdqHGvVWwcirzoDXQ
  except eBNhylkPaspxIJdqHGvVWwcirzoDXA as exception:
   eBNhylkPaspxIJdqHGvVWwcirzoDXb(exception)
  return eBNhylkPaspxIJdqHGvVWwcirzoDjm,eBNhylkPaspxIJdqHGvVWwcirzoDjL
 def GetProgramList(eBNhylkPaspxIJdqHGvVWwcirzoDMR,genre,orderby,page_int,genreCode='all',landyn=eBNhylkPaspxIJdqHGvVWwcirzoDXF):
  eBNhylkPaspxIJdqHGvVWwcirzoDjm=[]
  eBNhylkPaspxIJdqHGvVWwcirzoDjL=eBNhylkPaspxIJdqHGvVWwcirzoDXF
  try:
   eBNhylkPaspxIJdqHGvVWwcirzoDTO ='/v2/media/episodes'
   eBNhylkPaspxIJdqHGvVWwcirzoDTt=eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetDefaultParams()
   eBNhylkPaspxIJdqHGvVWwcirzoDTY={'pageNo':eBNhylkPaspxIJdqHGvVWwcirzoDXE(page_int),'pageSize':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetNoCache(2))}
   if genre !='all':eBNhylkPaspxIJdqHGvVWwcirzoDTY['categoryCode']=genre
   if genreCode!='all':eBNhylkPaspxIJdqHGvVWwcirzoDTY['genreCode'] =genreCode 
   eBNhylkPaspxIJdqHGvVWwcirzoDTt.update(eBNhylkPaspxIJdqHGvVWwcirzoDTY)
   eBNhylkPaspxIJdqHGvVWwcirzoDTu=eBNhylkPaspxIJdqHGvVWwcirzoDMR.API_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTO
   eBNhylkPaspxIJdqHGvVWwcirzoDMb=eBNhylkPaspxIJdqHGvVWwcirzoDMR.callRequestCookies('Get',eBNhylkPaspxIJdqHGvVWwcirzoDTu,payload=eBNhylkPaspxIJdqHGvVWwcirzoDXS,params=eBNhylkPaspxIJdqHGvVWwcirzoDTt,headers=eBNhylkPaspxIJdqHGvVWwcirzoDXS,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDXS)
   eBNhylkPaspxIJdqHGvVWwcirzoDTg=json.loads(eBNhylkPaspxIJdqHGvVWwcirzoDMb.text)
   if not('result' in eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']):return eBNhylkPaspxIJdqHGvVWwcirzoDjm,eBNhylkPaspxIJdqHGvVWwcirzoDjL
   eBNhylkPaspxIJdqHGvVWwcirzoDjO=eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']['result']
   for eBNhylkPaspxIJdqHGvVWwcirzoDTn in eBNhylkPaspxIJdqHGvVWwcirzoDjO:
    eBNhylkPaspxIJdqHGvVWwcirzoDjE=eBNhylkPaspxIJdqHGvVWwcirzoDTn['program']['code']
    eBNhylkPaspxIJdqHGvVWwcirzoDjg =eBNhylkPaspxIJdqHGvVWwcirzoDTn['program']['name']['ko']
    eBNhylkPaspxIJdqHGvVWwcirzoDjS =eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTn['program']['image'][0]['url']
    eBNhylkPaspxIJdqHGvVWwcirzoDjK='CAIP0200' if landyn else 'CAIP0900' 
    for eBNhylkPaspxIJdqHGvVWwcirzoDRM in eBNhylkPaspxIJdqHGvVWwcirzoDTn['program']['image']:
     if eBNhylkPaspxIJdqHGvVWwcirzoDRM['code']==eBNhylkPaspxIJdqHGvVWwcirzoDjK:
      eBNhylkPaspxIJdqHGvVWwcirzoDjS =eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDRM['url']
      break
    eBNhylkPaspxIJdqHGvVWwcirzoDjF =eBNhylkPaspxIJdqHGvVWwcirzoDTn['program']['synopsis']['ko']
    try:
     eBNhylkPaspxIJdqHGvVWwcirzoDRT=eBNhylkPaspxIJdqHGvVWwcirzoDTn['channel']['name']['ko']
    except:
     eBNhylkPaspxIJdqHGvVWwcirzoDRT=''
    try:
     eBNhylkPaspxIJdqHGvVWwcirzoDjC =[]
     eBNhylkPaspxIJdqHGvVWwcirzoDRj=[]
     eBNhylkPaspxIJdqHGvVWwcirzoDjn =[]
     eBNhylkPaspxIJdqHGvVWwcirzoDRX =''
     eBNhylkPaspxIJdqHGvVWwcirzoDRU=''
     for eBNhylkPaspxIJdqHGvVWwcirzoDjQ in eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('program').get('actor'):
      if eBNhylkPaspxIJdqHGvVWwcirzoDjQ!='' and eBNhylkPaspxIJdqHGvVWwcirzoDjQ!='-' and eBNhylkPaspxIJdqHGvVWwcirzoDjQ!=u'없음':eBNhylkPaspxIJdqHGvVWwcirzoDjC.append(eBNhylkPaspxIJdqHGvVWwcirzoDjQ)
     for eBNhylkPaspxIJdqHGvVWwcirzoDRm in eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('program').get('director'):
      if eBNhylkPaspxIJdqHGvVWwcirzoDRm!='' and eBNhylkPaspxIJdqHGvVWwcirzoDRm!='-' and eBNhylkPaspxIJdqHGvVWwcirzoDRm!=u'없음':eBNhylkPaspxIJdqHGvVWwcirzoDRj.append(eBNhylkPaspxIJdqHGvVWwcirzoDRm)
     if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('program').get('category1_name').get('ko')!='':
      eBNhylkPaspxIJdqHGvVWwcirzoDjn.append(eBNhylkPaspxIJdqHGvVWwcirzoDTn['program']['category1_name']['ko'])
     if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('program').get('category2_name').get('ko')!='':
      eBNhylkPaspxIJdqHGvVWwcirzoDjn.append(eBNhylkPaspxIJdqHGvVWwcirzoDTn['program']['category2_name']['ko'])
     if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('program').get('product_year'):eBNhylkPaspxIJdqHGvVWwcirzoDRX=eBNhylkPaspxIJdqHGvVWwcirzoDTn['program']['product_year']
     if 'broad_dt' in eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('program'):
      eBNhylkPaspxIJdqHGvVWwcirzoDRL=eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('program').get('broad_dt')
      eBNhylkPaspxIJdqHGvVWwcirzoDRU='%s-%s-%s'%(eBNhylkPaspxIJdqHGvVWwcirzoDRL[:4],eBNhylkPaspxIJdqHGvVWwcirzoDRL[4:6],eBNhylkPaspxIJdqHGvVWwcirzoDRL[6:])
    except:
     eBNhylkPaspxIJdqHGvVWwcirzoDXS
    eBNhylkPaspxIJdqHGvVWwcirzoDjb={'program':eBNhylkPaspxIJdqHGvVWwcirzoDjE,'title':eBNhylkPaspxIJdqHGvVWwcirzoDjg,'thumbnail':eBNhylkPaspxIJdqHGvVWwcirzoDjS,'synopsis':eBNhylkPaspxIJdqHGvVWwcirzoDjF,'channel':eBNhylkPaspxIJdqHGvVWwcirzoDRT,'cast':eBNhylkPaspxIJdqHGvVWwcirzoDjC,'director':eBNhylkPaspxIJdqHGvVWwcirzoDRj,'info_genre':eBNhylkPaspxIJdqHGvVWwcirzoDjn,'year':eBNhylkPaspxIJdqHGvVWwcirzoDRX,'aired':eBNhylkPaspxIJdqHGvVWwcirzoDRU}
    eBNhylkPaspxIJdqHGvVWwcirzoDjm.append(eBNhylkPaspxIJdqHGvVWwcirzoDjb)
   if eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']['has_more']=='Y':eBNhylkPaspxIJdqHGvVWwcirzoDjL=eBNhylkPaspxIJdqHGvVWwcirzoDXQ
  except eBNhylkPaspxIJdqHGvVWwcirzoDXA as exception:
   eBNhylkPaspxIJdqHGvVWwcirzoDXb(exception)
  return eBNhylkPaspxIJdqHGvVWwcirzoDjm,eBNhylkPaspxIJdqHGvVWwcirzoDjL
 def GetEpisodoList(eBNhylkPaspxIJdqHGvVWwcirzoDMR,program_code,page_int,orderby='desc'):
  eBNhylkPaspxIJdqHGvVWwcirzoDjm=[]
  eBNhylkPaspxIJdqHGvVWwcirzoDjL=eBNhylkPaspxIJdqHGvVWwcirzoDXF
  try:
   eBNhylkPaspxIJdqHGvVWwcirzoDTO ='/v2/media/frequency/program/'+program_code
   eBNhylkPaspxIJdqHGvVWwcirzoDTt=eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetDefaultParams()
   eBNhylkPaspxIJdqHGvVWwcirzoDTY={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetNoCache(2))}
   eBNhylkPaspxIJdqHGvVWwcirzoDTt.update(eBNhylkPaspxIJdqHGvVWwcirzoDTY)
   eBNhylkPaspxIJdqHGvVWwcirzoDTu=eBNhylkPaspxIJdqHGvVWwcirzoDMR.API_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTO
   eBNhylkPaspxIJdqHGvVWwcirzoDMb=eBNhylkPaspxIJdqHGvVWwcirzoDMR.callRequestCookies('Get',eBNhylkPaspxIJdqHGvVWwcirzoDTu,payload=eBNhylkPaspxIJdqHGvVWwcirzoDXS,params=eBNhylkPaspxIJdqHGvVWwcirzoDTt,headers=eBNhylkPaspxIJdqHGvVWwcirzoDXS,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDXS)
   eBNhylkPaspxIJdqHGvVWwcirzoDTg=json.loads(eBNhylkPaspxIJdqHGvVWwcirzoDMb.text)
   if not('result' in eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']):return eBNhylkPaspxIJdqHGvVWwcirzoDjm,eBNhylkPaspxIJdqHGvVWwcirzoDjL
   eBNhylkPaspxIJdqHGvVWwcirzoDjO=eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']['result']
   eBNhylkPaspxIJdqHGvVWwcirzoDRf=eBNhylkPaspxIJdqHGvVWwcirzoDXC(eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']['total_count'])
   eBNhylkPaspxIJdqHGvVWwcirzoDRO =eBNhylkPaspxIJdqHGvVWwcirzoDXC(eBNhylkPaspxIJdqHGvVWwcirzoDRf//(eBNhylkPaspxIJdqHGvVWwcirzoDMR.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    eBNhylkPaspxIJdqHGvVWwcirzoDRt =(eBNhylkPaspxIJdqHGvVWwcirzoDRf-1)-((page_int-1)*eBNhylkPaspxIJdqHGvVWwcirzoDMR.EPISODE_LIMIT)
   else:
    eBNhylkPaspxIJdqHGvVWwcirzoDRt =(page_int-1)*eBNhylkPaspxIJdqHGvVWwcirzoDMR.EPISODE_LIMIT
   for i in eBNhylkPaspxIJdqHGvVWwcirzoDXn(eBNhylkPaspxIJdqHGvVWwcirzoDMR.EPISODE_LIMIT):
    if orderby=='desc':
     eBNhylkPaspxIJdqHGvVWwcirzoDRY=eBNhylkPaspxIJdqHGvVWwcirzoDRt-i
     if eBNhylkPaspxIJdqHGvVWwcirzoDRY<0:break
    else:
     eBNhylkPaspxIJdqHGvVWwcirzoDRY=eBNhylkPaspxIJdqHGvVWwcirzoDRt+i
     if eBNhylkPaspxIJdqHGvVWwcirzoDRY>=eBNhylkPaspxIJdqHGvVWwcirzoDRf:break
    eBNhylkPaspxIJdqHGvVWwcirzoDRu=eBNhylkPaspxIJdqHGvVWwcirzoDjO[eBNhylkPaspxIJdqHGvVWwcirzoDRY]['episode']['code']
    eBNhylkPaspxIJdqHGvVWwcirzoDjg =eBNhylkPaspxIJdqHGvVWwcirzoDjO[eBNhylkPaspxIJdqHGvVWwcirzoDRY]['vod_name']['ko']
    eBNhylkPaspxIJdqHGvVWwcirzoDRg =''
    try:
     eBNhylkPaspxIJdqHGvVWwcirzoDRL=eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDjO[eBNhylkPaspxIJdqHGvVWwcirzoDRY]['episode']['broadcast_date'])
     eBNhylkPaspxIJdqHGvVWwcirzoDRg='%s-%s-%s'%(eBNhylkPaspxIJdqHGvVWwcirzoDRL[:4],eBNhylkPaspxIJdqHGvVWwcirzoDRL[4:6],eBNhylkPaspxIJdqHGvVWwcirzoDRL[6:])
    except:
     eBNhylkPaspxIJdqHGvVWwcirzoDXS
    if eBNhylkPaspxIJdqHGvVWwcirzoDjO[eBNhylkPaspxIJdqHGvVWwcirzoDRY]['episode']['image']!=[]:
     eBNhylkPaspxIJdqHGvVWwcirzoDjS=eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDjO[eBNhylkPaspxIJdqHGvVWwcirzoDRY]['episode']['image'][0]['url']
    else:
     eBNhylkPaspxIJdqHGvVWwcirzoDjS=eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDjO[eBNhylkPaspxIJdqHGvVWwcirzoDRY]['program']['image'][0]['url']
    eBNhylkPaspxIJdqHGvVWwcirzoDjF =eBNhylkPaspxIJdqHGvVWwcirzoDjO[eBNhylkPaspxIJdqHGvVWwcirzoDRY]['episode']['synopsis']['ko']
    try:
     eBNhylkPaspxIJdqHGvVWwcirzoDRS=eBNhylkPaspxIJdqHGvVWwcirzoDRU=eBNhylkPaspxIJdqHGvVWwcirzoDRC=''
     eBNhylkPaspxIJdqHGvVWwcirzoDRF=0
     eBNhylkPaspxIJdqHGvVWwcirzoDRS =eBNhylkPaspxIJdqHGvVWwcirzoDjO[eBNhylkPaspxIJdqHGvVWwcirzoDRY]['program']['name']['ko']
     eBNhylkPaspxIJdqHGvVWwcirzoDRU =eBNhylkPaspxIJdqHGvVWwcirzoDRg
     eBNhylkPaspxIJdqHGvVWwcirzoDRC =eBNhylkPaspxIJdqHGvVWwcirzoDjO[eBNhylkPaspxIJdqHGvVWwcirzoDRY]['channel']['name']['ko']
     if 'frequency' in eBNhylkPaspxIJdqHGvVWwcirzoDjO[eBNhylkPaspxIJdqHGvVWwcirzoDRY]['episode']:eBNhylkPaspxIJdqHGvVWwcirzoDRF=eBNhylkPaspxIJdqHGvVWwcirzoDjO[eBNhylkPaspxIJdqHGvVWwcirzoDRY]['episode']['frequency']
    except:
     eBNhylkPaspxIJdqHGvVWwcirzoDXS
    eBNhylkPaspxIJdqHGvVWwcirzoDjb={'episode':eBNhylkPaspxIJdqHGvVWwcirzoDRu,'title':eBNhylkPaspxIJdqHGvVWwcirzoDjg,'subtitle':eBNhylkPaspxIJdqHGvVWwcirzoDRg,'thumbnail':eBNhylkPaspxIJdqHGvVWwcirzoDjS,'synopsis':eBNhylkPaspxIJdqHGvVWwcirzoDjF,'info_title':eBNhylkPaspxIJdqHGvVWwcirzoDRS,'aired':eBNhylkPaspxIJdqHGvVWwcirzoDRU,'studio':eBNhylkPaspxIJdqHGvVWwcirzoDRC,'frequency':eBNhylkPaspxIJdqHGvVWwcirzoDRF}
    eBNhylkPaspxIJdqHGvVWwcirzoDjm.append(eBNhylkPaspxIJdqHGvVWwcirzoDjb)
   if eBNhylkPaspxIJdqHGvVWwcirzoDRO>page_int:eBNhylkPaspxIJdqHGvVWwcirzoDjL=eBNhylkPaspxIJdqHGvVWwcirzoDXQ
  except eBNhylkPaspxIJdqHGvVWwcirzoDXA as exception:
   eBNhylkPaspxIJdqHGvVWwcirzoDXb(exception)
  return eBNhylkPaspxIJdqHGvVWwcirzoDjm,eBNhylkPaspxIJdqHGvVWwcirzoDjL,eBNhylkPaspxIJdqHGvVWwcirzoDRO
 def GetMovieList(eBNhylkPaspxIJdqHGvVWwcirzoDMR,genre,orderby,page_int,landyn=eBNhylkPaspxIJdqHGvVWwcirzoDXF):
  eBNhylkPaspxIJdqHGvVWwcirzoDjm=[]
  eBNhylkPaspxIJdqHGvVWwcirzoDjL=eBNhylkPaspxIJdqHGvVWwcirzoDXF
  try:
   eBNhylkPaspxIJdqHGvVWwcirzoDTO ='/v2/media/movies'
   eBNhylkPaspxIJdqHGvVWwcirzoDTt=eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetDefaultParams()
   eBNhylkPaspxIJdqHGvVWwcirzoDTY={'pageNo':eBNhylkPaspxIJdqHGvVWwcirzoDXE(page_int),'pageSize':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetNoCache(2))}
   if genre!='all' :eBNhylkPaspxIJdqHGvVWwcirzoDTY['multiCategoryCode']=genre
   if orderby=='new':eBNhylkPaspxIJdqHGvVWwcirzoDTY['productPackageCode']=','.join(eBNhylkPaspxIJdqHGvVWwcirzoDMR.MOVIE_LITE)
   eBNhylkPaspxIJdqHGvVWwcirzoDTt.update(eBNhylkPaspxIJdqHGvVWwcirzoDTY)
   eBNhylkPaspxIJdqHGvVWwcirzoDTu=eBNhylkPaspxIJdqHGvVWwcirzoDMR.API_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTO
   eBNhylkPaspxIJdqHGvVWwcirzoDMb=eBNhylkPaspxIJdqHGvVWwcirzoDMR.callRequestCookies('Get',eBNhylkPaspxIJdqHGvVWwcirzoDTu,payload=eBNhylkPaspxIJdqHGvVWwcirzoDXS,params=eBNhylkPaspxIJdqHGvVWwcirzoDTt,headers=eBNhylkPaspxIJdqHGvVWwcirzoDXS,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDXS)
   eBNhylkPaspxIJdqHGvVWwcirzoDTg=json.loads(eBNhylkPaspxIJdqHGvVWwcirzoDMb.text)
   if not('result' in eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']):return eBNhylkPaspxIJdqHGvVWwcirzoDjm,eBNhylkPaspxIJdqHGvVWwcirzoDjL
   eBNhylkPaspxIJdqHGvVWwcirzoDjO=eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']['result']
   for eBNhylkPaspxIJdqHGvVWwcirzoDTn in eBNhylkPaspxIJdqHGvVWwcirzoDjO:
    eBNhylkPaspxIJdqHGvVWwcirzoDRn =eBNhylkPaspxIJdqHGvVWwcirzoDTn['movie']['code']
    eBNhylkPaspxIJdqHGvVWwcirzoDjg =eBNhylkPaspxIJdqHGvVWwcirzoDTn['movie']['name']['ko'].strip()
    eBNhylkPaspxIJdqHGvVWwcirzoDjg +=u' (%s년)'%(eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('movie').get('product_year'))
    eBNhylkPaspxIJdqHGvVWwcirzoDjS =eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTn['movie']['image'][0]['url']
    eBNhylkPaspxIJdqHGvVWwcirzoDjK='CAIM0400' if landyn else 'CAIM2100' 
    for eBNhylkPaspxIJdqHGvVWwcirzoDRM in eBNhylkPaspxIJdqHGvVWwcirzoDTn['movie']['image']:
     if eBNhylkPaspxIJdqHGvVWwcirzoDRM['code']==eBNhylkPaspxIJdqHGvVWwcirzoDjK:
      eBNhylkPaspxIJdqHGvVWwcirzoDjS =eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDRM['url']
      break
    eBNhylkPaspxIJdqHGvVWwcirzoDjF =eBNhylkPaspxIJdqHGvVWwcirzoDTn['movie']['story']['ko']
    try:
     eBNhylkPaspxIJdqHGvVWwcirzoDRS =eBNhylkPaspxIJdqHGvVWwcirzoDTn['movie']['name']['ko'].strip()
     eBNhylkPaspxIJdqHGvVWwcirzoDRX =eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('movie').get('product_year')
     eBNhylkPaspxIJdqHGvVWwcirzoDjC=[]
     eBNhylkPaspxIJdqHGvVWwcirzoDRj=[]
     eBNhylkPaspxIJdqHGvVWwcirzoDjn=[]
     eBNhylkPaspxIJdqHGvVWwcirzoDRQ=0
     eBNhylkPaspxIJdqHGvVWwcirzoDRU=''
     for eBNhylkPaspxIJdqHGvVWwcirzoDjQ in eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('movie').get('actor'):
      if eBNhylkPaspxIJdqHGvVWwcirzoDjQ!='':eBNhylkPaspxIJdqHGvVWwcirzoDjC.append(eBNhylkPaspxIJdqHGvVWwcirzoDjQ)
     for eBNhylkPaspxIJdqHGvVWwcirzoDRm in eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('movie').get('director'):
      if eBNhylkPaspxIJdqHGvVWwcirzoDRm!='':eBNhylkPaspxIJdqHGvVWwcirzoDRj.append(eBNhylkPaspxIJdqHGvVWwcirzoDRm)
     if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('movie').get('category1_name').get('ko')!='':
      eBNhylkPaspxIJdqHGvVWwcirzoDjn.append(eBNhylkPaspxIJdqHGvVWwcirzoDTn['movie']['category1_name']['ko'])
     if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('movie').get('category2_name').get('ko')!='':
      eBNhylkPaspxIJdqHGvVWwcirzoDjn.append(eBNhylkPaspxIJdqHGvVWwcirzoDTn['movie']['category2_name']['ko'])
     if 'duration' in eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('movie'):eBNhylkPaspxIJdqHGvVWwcirzoDRQ=eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('movie').get('duration')
     if 'release_date' in eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('movie'):
      eBNhylkPaspxIJdqHGvVWwcirzoDRL=eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('movie').get('release_date'))
      if eBNhylkPaspxIJdqHGvVWwcirzoDRL!='0':eBNhylkPaspxIJdqHGvVWwcirzoDRU='%s-%s-%s'%(eBNhylkPaspxIJdqHGvVWwcirzoDRL[:4],eBNhylkPaspxIJdqHGvVWwcirzoDRL[4:6],eBNhylkPaspxIJdqHGvVWwcirzoDRL[6:])
    except:
     eBNhylkPaspxIJdqHGvVWwcirzoDXS
    eBNhylkPaspxIJdqHGvVWwcirzoDjb={'moviecode':eBNhylkPaspxIJdqHGvVWwcirzoDRn,'title':eBNhylkPaspxIJdqHGvVWwcirzoDjg,'thumbnail':eBNhylkPaspxIJdqHGvVWwcirzoDjS,'synopsis':eBNhylkPaspxIJdqHGvVWwcirzoDjF,'info_title':eBNhylkPaspxIJdqHGvVWwcirzoDRS,'year':eBNhylkPaspxIJdqHGvVWwcirzoDRX,'cast':eBNhylkPaspxIJdqHGvVWwcirzoDjC,'director':eBNhylkPaspxIJdqHGvVWwcirzoDRj,'info_genre':eBNhylkPaspxIJdqHGvVWwcirzoDjn,'duration':eBNhylkPaspxIJdqHGvVWwcirzoDRQ,'aired':eBNhylkPaspxIJdqHGvVWwcirzoDRU}
    eBNhylkPaspxIJdqHGvVWwcirzoDRA=eBNhylkPaspxIJdqHGvVWwcirzoDXF
    for eBNhylkPaspxIJdqHGvVWwcirzoDRb in eBNhylkPaspxIJdqHGvVWwcirzoDTn['billing_package_id']:
     if eBNhylkPaspxIJdqHGvVWwcirzoDRb in eBNhylkPaspxIJdqHGvVWwcirzoDMR.MOVIE_LITE:
      eBNhylkPaspxIJdqHGvVWwcirzoDRA=eBNhylkPaspxIJdqHGvVWwcirzoDXQ
      break
    if eBNhylkPaspxIJdqHGvVWwcirzoDRA==eBNhylkPaspxIJdqHGvVWwcirzoDXF: 
     eBNhylkPaspxIJdqHGvVWwcirzoDjb['title']=eBNhylkPaspxIJdqHGvVWwcirzoDjb['title']+' [개별구매]'
    eBNhylkPaspxIJdqHGvVWwcirzoDjm.append(eBNhylkPaspxIJdqHGvVWwcirzoDjb)
   if eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']['has_more']=='Y':eBNhylkPaspxIJdqHGvVWwcirzoDjL=eBNhylkPaspxIJdqHGvVWwcirzoDXQ
  except eBNhylkPaspxIJdqHGvVWwcirzoDXA as exception:
   eBNhylkPaspxIJdqHGvVWwcirzoDXb(exception)
  return eBNhylkPaspxIJdqHGvVWwcirzoDjm,eBNhylkPaspxIJdqHGvVWwcirzoDjL
 def GetMovieListGenre(eBNhylkPaspxIJdqHGvVWwcirzoDMR,genre,page_int):
  eBNhylkPaspxIJdqHGvVWwcirzoDjm=[]
  eBNhylkPaspxIJdqHGvVWwcirzoDjL=eBNhylkPaspxIJdqHGvVWwcirzoDXF
  try:
   eBNhylkPaspxIJdqHGvVWwcirzoDTO ='/v2/media/movie/curation/'+genre
   eBNhylkPaspxIJdqHGvVWwcirzoDTt=eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetDefaultParams()
   eBNhylkPaspxIJdqHGvVWwcirzoDTY={'pageNo':eBNhylkPaspxIJdqHGvVWwcirzoDXE(page_int),'pageSize':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.MOVIE_LIMIT),'_':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetNoCache(2))}
   eBNhylkPaspxIJdqHGvVWwcirzoDTt.update(eBNhylkPaspxIJdqHGvVWwcirzoDTY)
   eBNhylkPaspxIJdqHGvVWwcirzoDTu=eBNhylkPaspxIJdqHGvVWwcirzoDMR.API_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTO
   eBNhylkPaspxIJdqHGvVWwcirzoDMb=eBNhylkPaspxIJdqHGvVWwcirzoDMR.callRequestCookies('Get',eBNhylkPaspxIJdqHGvVWwcirzoDTu,payload=eBNhylkPaspxIJdqHGvVWwcirzoDXS,params=eBNhylkPaspxIJdqHGvVWwcirzoDTt,headers=eBNhylkPaspxIJdqHGvVWwcirzoDXS,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDXS)
   eBNhylkPaspxIJdqHGvVWwcirzoDTg=json.loads(eBNhylkPaspxIJdqHGvVWwcirzoDMb.text)
   if not('movies' in eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']):return eBNhylkPaspxIJdqHGvVWwcirzoDjm,eBNhylkPaspxIJdqHGvVWwcirzoDjL
   eBNhylkPaspxIJdqHGvVWwcirzoDjO=eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']['movies']
   for eBNhylkPaspxIJdqHGvVWwcirzoDTn in eBNhylkPaspxIJdqHGvVWwcirzoDjO:
    eBNhylkPaspxIJdqHGvVWwcirzoDRn =eBNhylkPaspxIJdqHGvVWwcirzoDTn['code']
    eBNhylkPaspxIJdqHGvVWwcirzoDjg =eBNhylkPaspxIJdqHGvVWwcirzoDTn['name']['ko']
    eBNhylkPaspxIJdqHGvVWwcirzoDjS =eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTn['image'][0]['url']
    for eBNhylkPaspxIJdqHGvVWwcirzoDRM in eBNhylkPaspxIJdqHGvVWwcirzoDTn['image']:
     if eBNhylkPaspxIJdqHGvVWwcirzoDRM['code']=='CAIM2100':
      eBNhylkPaspxIJdqHGvVWwcirzoDjS =eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDRM['url']
    eBNhylkPaspxIJdqHGvVWwcirzoDjF =eBNhylkPaspxIJdqHGvVWwcirzoDTn['story']['ko']
    eBNhylkPaspxIJdqHGvVWwcirzoDjb={'moviecode':eBNhylkPaspxIJdqHGvVWwcirzoDRn,'title':eBNhylkPaspxIJdqHGvVWwcirzoDjg.strip(),'thumbnail':eBNhylkPaspxIJdqHGvVWwcirzoDjS,'synopsis':eBNhylkPaspxIJdqHGvVWwcirzoDjF}
    eBNhylkPaspxIJdqHGvVWwcirzoDjm.append(eBNhylkPaspxIJdqHGvVWwcirzoDjb)
  except eBNhylkPaspxIJdqHGvVWwcirzoDXA as exception:
   eBNhylkPaspxIJdqHGvVWwcirzoDXb(exception)
  return eBNhylkPaspxIJdqHGvVWwcirzoDjm,eBNhylkPaspxIJdqHGvVWwcirzoDjL
 def GetMovieGenre(eBNhylkPaspxIJdqHGvVWwcirzoDMR):
  eBNhylkPaspxIJdqHGvVWwcirzoDjm=[]
  eBNhylkPaspxIJdqHGvVWwcirzoDjL=eBNhylkPaspxIJdqHGvVWwcirzoDXF
  try:
   eBNhylkPaspxIJdqHGvVWwcirzoDTO ='/v2/media/movie/curations'
   eBNhylkPaspxIJdqHGvVWwcirzoDTt=eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetDefaultParams()
   eBNhylkPaspxIJdqHGvVWwcirzoDTY={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetNoCache(2))}
   eBNhylkPaspxIJdqHGvVWwcirzoDTt.update(eBNhylkPaspxIJdqHGvVWwcirzoDTY)
   eBNhylkPaspxIJdqHGvVWwcirzoDTu=eBNhylkPaspxIJdqHGvVWwcirzoDMR.API_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTO
   eBNhylkPaspxIJdqHGvVWwcirzoDMb=eBNhylkPaspxIJdqHGvVWwcirzoDMR.callRequestCookies('Get',eBNhylkPaspxIJdqHGvVWwcirzoDTu,payload=eBNhylkPaspxIJdqHGvVWwcirzoDXS,params=eBNhylkPaspxIJdqHGvVWwcirzoDTt,headers=eBNhylkPaspxIJdqHGvVWwcirzoDXS,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDXS)
   eBNhylkPaspxIJdqHGvVWwcirzoDTg=json.loads(eBNhylkPaspxIJdqHGvVWwcirzoDMb.text)
   if not('result' in eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']):return eBNhylkPaspxIJdqHGvVWwcirzoDjm,eBNhylkPaspxIJdqHGvVWwcirzoDjL
   eBNhylkPaspxIJdqHGvVWwcirzoDjO=eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']['result']
   for eBNhylkPaspxIJdqHGvVWwcirzoDTn in eBNhylkPaspxIJdqHGvVWwcirzoDjO:
    eBNhylkPaspxIJdqHGvVWwcirzoDRE =eBNhylkPaspxIJdqHGvVWwcirzoDTn['curation_code']
    eBNhylkPaspxIJdqHGvVWwcirzoDRK =eBNhylkPaspxIJdqHGvVWwcirzoDTn['curation_name']
    eBNhylkPaspxIJdqHGvVWwcirzoDjb={'curation_code':eBNhylkPaspxIJdqHGvVWwcirzoDRE,'curation_name':eBNhylkPaspxIJdqHGvVWwcirzoDRK}
    eBNhylkPaspxIJdqHGvVWwcirzoDjm.append(eBNhylkPaspxIJdqHGvVWwcirzoDjb)
  except eBNhylkPaspxIJdqHGvVWwcirzoDXA as exception:
   eBNhylkPaspxIJdqHGvVWwcirzoDXb(exception)
  return eBNhylkPaspxIJdqHGvVWwcirzoDjm,eBNhylkPaspxIJdqHGvVWwcirzoDjL
 def GetSearchList(eBNhylkPaspxIJdqHGvVWwcirzoDMR,search_key,userid,page_int,stype,landyn=eBNhylkPaspxIJdqHGvVWwcirzoDXF):
  eBNhylkPaspxIJdqHGvVWwcirzoDXM=[]
  eBNhylkPaspxIJdqHGvVWwcirzoDjL=eBNhylkPaspxIJdqHGvVWwcirzoDXF
  try:
   eBNhylkPaspxIJdqHGvVWwcirzoDTO ='/search/getSearch.jsp'
   eBNhylkPaspxIJdqHGvVWwcirzoDTY={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':eBNhylkPaspxIJdqHGvVWwcirzoDXE(page_int),'pageSize':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':eBNhylkPaspxIJdqHGvVWwcirzoDMR.SCREENCODE,'os':eBNhylkPaspxIJdqHGvVWwcirzoDMR.OSCODE,'network':eBNhylkPaspxIJdqHGvVWwcirzoDMR.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.SEARCH_LIMIT),'vodMVReqCnt':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':eBNhylkPaspxIJdqHGvVWwcirzoDXE(eBNhylkPaspxIJdqHGvVWwcirzoDMR.GetNoCache(2))}
   eBNhylkPaspxIJdqHGvVWwcirzoDTu=eBNhylkPaspxIJdqHGvVWwcirzoDMR.SEARCH_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTO
   eBNhylkPaspxIJdqHGvVWwcirzoDMb=eBNhylkPaspxIJdqHGvVWwcirzoDMR.callRequestCookies('Get',eBNhylkPaspxIJdqHGvVWwcirzoDTu,payload=eBNhylkPaspxIJdqHGvVWwcirzoDXS,params=eBNhylkPaspxIJdqHGvVWwcirzoDTY,headers=eBNhylkPaspxIJdqHGvVWwcirzoDXS,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDXS)
   eBNhylkPaspxIJdqHGvVWwcirzoDTg=json.loads(eBNhylkPaspxIJdqHGvVWwcirzoDMb.text)
   if stype=='vod':
    if not('programRsb' in eBNhylkPaspxIJdqHGvVWwcirzoDTg):return eBNhylkPaspxIJdqHGvVWwcirzoDXM,eBNhylkPaspxIJdqHGvVWwcirzoDjL
    eBNhylkPaspxIJdqHGvVWwcirzoDXT=eBNhylkPaspxIJdqHGvVWwcirzoDTg['programRsb']['dataList']
    eBNhylkPaspxIJdqHGvVWwcirzoDXj =eBNhylkPaspxIJdqHGvVWwcirzoDXC(eBNhylkPaspxIJdqHGvVWwcirzoDTg['programRsb']['count'])
    for eBNhylkPaspxIJdqHGvVWwcirzoDTn in eBNhylkPaspxIJdqHGvVWwcirzoDXT:
     eBNhylkPaspxIJdqHGvVWwcirzoDjE=eBNhylkPaspxIJdqHGvVWwcirzoDTn['mast_cd']
     eBNhylkPaspxIJdqHGvVWwcirzoDjg =eBNhylkPaspxIJdqHGvVWwcirzoDTn['mast_nm']
     eBNhylkPaspxIJdqHGvVWwcirzoDjS =eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTn['web_url']
     if landyn==eBNhylkPaspxIJdqHGvVWwcirzoDXF:
      eBNhylkPaspxIJdqHGvVWwcirzoDjS =eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTn['web_url4']
     try:
      eBNhylkPaspxIJdqHGvVWwcirzoDjC =[]
      eBNhylkPaspxIJdqHGvVWwcirzoDRj=[]
      eBNhylkPaspxIJdqHGvVWwcirzoDjn =[]
      eBNhylkPaspxIJdqHGvVWwcirzoDRQ =0
      eBNhylkPaspxIJdqHGvVWwcirzoDXR =''
      eBNhylkPaspxIJdqHGvVWwcirzoDRX =''
      eBNhylkPaspxIJdqHGvVWwcirzoDRU =''
      if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('actor') !='' and eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('actor') !='-':eBNhylkPaspxIJdqHGvVWwcirzoDjC =eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('actor').split(',')
      if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('director')!='' and eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('director')!='-':eBNhylkPaspxIJdqHGvVWwcirzoDRj=eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('director').split(',')
      if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('cate_nm')!='' and eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('cate_nm')!='-':eBNhylkPaspxIJdqHGvVWwcirzoDjn =eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('cate_nm').split('/')
      if 'targetage' in eBNhylkPaspxIJdqHGvVWwcirzoDTn:eBNhylkPaspxIJdqHGvVWwcirzoDXR=eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('targetage')
      if 'broad_dt' in eBNhylkPaspxIJdqHGvVWwcirzoDTn:
       eBNhylkPaspxIJdqHGvVWwcirzoDRL=eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('broad_dt')
       eBNhylkPaspxIJdqHGvVWwcirzoDRU='%s-%s-%s'%(eBNhylkPaspxIJdqHGvVWwcirzoDRL[:4],eBNhylkPaspxIJdqHGvVWwcirzoDRL[4:6],eBNhylkPaspxIJdqHGvVWwcirzoDRL[6:])
       eBNhylkPaspxIJdqHGvVWwcirzoDRX =eBNhylkPaspxIJdqHGvVWwcirzoDRL[:4]
     except:
      eBNhylkPaspxIJdqHGvVWwcirzoDXS
     eBNhylkPaspxIJdqHGvVWwcirzoDjb={'program':eBNhylkPaspxIJdqHGvVWwcirzoDjE,'title':eBNhylkPaspxIJdqHGvVWwcirzoDjg,'thumbnail':eBNhylkPaspxIJdqHGvVWwcirzoDjS,'synopsis':'','cast':eBNhylkPaspxIJdqHGvVWwcirzoDjC,'director':eBNhylkPaspxIJdqHGvVWwcirzoDRj,'info_genre':eBNhylkPaspxIJdqHGvVWwcirzoDjn,'duration':eBNhylkPaspxIJdqHGvVWwcirzoDRQ,'mpaa':eBNhylkPaspxIJdqHGvVWwcirzoDXR,'year':eBNhylkPaspxIJdqHGvVWwcirzoDRX,'aired':eBNhylkPaspxIJdqHGvVWwcirzoDRU}
     eBNhylkPaspxIJdqHGvVWwcirzoDXM.append(eBNhylkPaspxIJdqHGvVWwcirzoDjb)
   else:
    if not('vodMVRsb' in eBNhylkPaspxIJdqHGvVWwcirzoDTg):return eBNhylkPaspxIJdqHGvVWwcirzoDXM,eBNhylkPaspxIJdqHGvVWwcirzoDjL
    eBNhylkPaspxIJdqHGvVWwcirzoDXU=eBNhylkPaspxIJdqHGvVWwcirzoDTg['vodMVRsb']['dataList']
    eBNhylkPaspxIJdqHGvVWwcirzoDXj =eBNhylkPaspxIJdqHGvVWwcirzoDXC(eBNhylkPaspxIJdqHGvVWwcirzoDTg['vodMVRsb']['count'])
    for eBNhylkPaspxIJdqHGvVWwcirzoDTn in eBNhylkPaspxIJdqHGvVWwcirzoDXU:
     eBNhylkPaspxIJdqHGvVWwcirzoDjE=eBNhylkPaspxIJdqHGvVWwcirzoDTn['mast_cd']
     eBNhylkPaspxIJdqHGvVWwcirzoDjg =eBNhylkPaspxIJdqHGvVWwcirzoDTn['mast_nm'].strip()
     eBNhylkPaspxIJdqHGvVWwcirzoDjS =eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTn['web_url']
     if landyn==eBNhylkPaspxIJdqHGvVWwcirzoDXF:
      eBNhylkPaspxIJdqHGvVWwcirzoDjS =eBNhylkPaspxIJdqHGvVWwcirzoDMR.IMG_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTn['web_url5']
     try:
      eBNhylkPaspxIJdqHGvVWwcirzoDjC =[]
      eBNhylkPaspxIJdqHGvVWwcirzoDRj=[]
      eBNhylkPaspxIJdqHGvVWwcirzoDjn =[]
      eBNhylkPaspxIJdqHGvVWwcirzoDRQ =0
      eBNhylkPaspxIJdqHGvVWwcirzoDXR =''
      eBNhylkPaspxIJdqHGvVWwcirzoDRX =''
      eBNhylkPaspxIJdqHGvVWwcirzoDRU =''
      if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('actor') !='' and eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('actor') !='-':eBNhylkPaspxIJdqHGvVWwcirzoDjC =eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('actor').split(',')
      if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('director')!='' and eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('director')!='-':eBNhylkPaspxIJdqHGvVWwcirzoDRj=eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('director').split(',')
      if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('cate_nm')!='' and eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('cate_nm')!='-':eBNhylkPaspxIJdqHGvVWwcirzoDjn =eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('cate_nm').split('/')
      if eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('runtime_sec')!='':eBNhylkPaspxIJdqHGvVWwcirzoDRQ=eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('runtime_sec')
      if 'grade_nm' in eBNhylkPaspxIJdqHGvVWwcirzoDTn:eBNhylkPaspxIJdqHGvVWwcirzoDXR=eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('grade_nm')
      eBNhylkPaspxIJdqHGvVWwcirzoDRL=eBNhylkPaspxIJdqHGvVWwcirzoDTn.get('broad_dt')
      if data_str!='':
       eBNhylkPaspxIJdqHGvVWwcirzoDRU='%s-%s-%s'%(eBNhylkPaspxIJdqHGvVWwcirzoDRL[:4],eBNhylkPaspxIJdqHGvVWwcirzoDRL[4:6],eBNhylkPaspxIJdqHGvVWwcirzoDRL[6:])
       eBNhylkPaspxIJdqHGvVWwcirzoDRX =eBNhylkPaspxIJdqHGvVWwcirzoDRL[:4]
     except:
      eBNhylkPaspxIJdqHGvVWwcirzoDXS
     eBNhylkPaspxIJdqHGvVWwcirzoDjb={'movie':eBNhylkPaspxIJdqHGvVWwcirzoDjE,'title':eBNhylkPaspxIJdqHGvVWwcirzoDjg,'thumbnail':eBNhylkPaspxIJdqHGvVWwcirzoDjS,'synopsis':'','cast':eBNhylkPaspxIJdqHGvVWwcirzoDjC,'director':eBNhylkPaspxIJdqHGvVWwcirzoDRj,'info_genre':eBNhylkPaspxIJdqHGvVWwcirzoDjn,'duration':eBNhylkPaspxIJdqHGvVWwcirzoDRQ,'mpaa':eBNhylkPaspxIJdqHGvVWwcirzoDXR,'year':eBNhylkPaspxIJdqHGvVWwcirzoDRX,'aired':eBNhylkPaspxIJdqHGvVWwcirzoDRU}
     eBNhylkPaspxIJdqHGvVWwcirzoDRA=eBNhylkPaspxIJdqHGvVWwcirzoDXF
     for eBNhylkPaspxIJdqHGvVWwcirzoDRb in eBNhylkPaspxIJdqHGvVWwcirzoDTn['bill']:
      if eBNhylkPaspxIJdqHGvVWwcirzoDRb in eBNhylkPaspxIJdqHGvVWwcirzoDMR.MOVIE_LITE:
       eBNhylkPaspxIJdqHGvVWwcirzoDRA=eBNhylkPaspxIJdqHGvVWwcirzoDXQ
       break
     if eBNhylkPaspxIJdqHGvVWwcirzoDRA==eBNhylkPaspxIJdqHGvVWwcirzoDXF: 
      eBNhylkPaspxIJdqHGvVWwcirzoDjb['title']=eBNhylkPaspxIJdqHGvVWwcirzoDjb['title']+' [개별구매]'
     eBNhylkPaspxIJdqHGvVWwcirzoDXM.append(eBNhylkPaspxIJdqHGvVWwcirzoDjb)
  except eBNhylkPaspxIJdqHGvVWwcirzoDXA as exception:
   eBNhylkPaspxIJdqHGvVWwcirzoDXb(exception)
  return eBNhylkPaspxIJdqHGvVWwcirzoDXM,eBNhylkPaspxIJdqHGvVWwcirzoDjL
 def GetDeviceList(eBNhylkPaspxIJdqHGvVWwcirzoDMR,eBNhylkPaspxIJdqHGvVWwcirzoDMK,eBNhylkPaspxIJdqHGvVWwcirzoDTM):
  eBNhylkPaspxIJdqHGvVWwcirzoDjm=[]
  eBNhylkPaspxIJdqHGvVWwcirzoDTL='-'
  try:
   eBNhylkPaspxIJdqHGvVWwcirzoDTO ='/v1/user/device/list'
   eBNhylkPaspxIJdqHGvVWwcirzoDXm=eBNhylkPaspxIJdqHGvVWwcirzoDMR.API_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTO
   eBNhylkPaspxIJdqHGvVWwcirzoDTY={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   eBNhylkPaspxIJdqHGvVWwcirzoDMm=eBNhylkPaspxIJdqHGvVWwcirzoDMR.makeDefaultCookies(vToken=eBNhylkPaspxIJdqHGvVWwcirzoDMK,vUserinfo=eBNhylkPaspxIJdqHGvVWwcirzoDTM)
   eBNhylkPaspxIJdqHGvVWwcirzoDMb=eBNhylkPaspxIJdqHGvVWwcirzoDMR.callRequestCookies('Get',eBNhylkPaspxIJdqHGvVWwcirzoDXm,payload=eBNhylkPaspxIJdqHGvVWwcirzoDXS,params=eBNhylkPaspxIJdqHGvVWwcirzoDTY,headers=eBNhylkPaspxIJdqHGvVWwcirzoDXS,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDMm)
   eBNhylkPaspxIJdqHGvVWwcirzoDTg=json.loads(eBNhylkPaspxIJdqHGvVWwcirzoDMb.text)
   eBNhylkPaspxIJdqHGvVWwcirzoDjm=eBNhylkPaspxIJdqHGvVWwcirzoDTg['body']
   for eBNhylkPaspxIJdqHGvVWwcirzoDTn in eBNhylkPaspxIJdqHGvVWwcirzoDjm:
    if eBNhylkPaspxIJdqHGvVWwcirzoDTn['model']=='PC':
     eBNhylkPaspxIJdqHGvVWwcirzoDTL=eBNhylkPaspxIJdqHGvVWwcirzoDTn['uuid']
  except eBNhylkPaspxIJdqHGvVWwcirzoDXA as exception:
   eBNhylkPaspxIJdqHGvVWwcirzoDXb(exception)
  return eBNhylkPaspxIJdqHGvVWwcirzoDTL
 def GetProfileToken(eBNhylkPaspxIJdqHGvVWwcirzoDMR,eBNhylkPaspxIJdqHGvVWwcirzoDMK,eBNhylkPaspxIJdqHGvVWwcirzoDTM,user_pf):
  eBNhylkPaspxIJdqHGvVWwcirzoDXL=[]
  eBNhylkPaspxIJdqHGvVWwcirzoDXf =''
  eBNhylkPaspxIJdqHGvVWwcirzoDXO =''
  eBNhylkPaspxIJdqHGvVWwcirzoDXt='Y'
  eBNhylkPaspxIJdqHGvVWwcirzoDXY ='N'
  try:
   eBNhylkPaspxIJdqHGvVWwcirzoDTO ='/profile/select.do'
   eBNhylkPaspxIJdqHGvVWwcirzoDXm=eBNhylkPaspxIJdqHGvVWwcirzoDMR.URL_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTO
   eBNhylkPaspxIJdqHGvVWwcirzoDMm=eBNhylkPaspxIJdqHGvVWwcirzoDMR.makeDefaultCookies(vToken=eBNhylkPaspxIJdqHGvVWwcirzoDMK,vUserinfo=eBNhylkPaspxIJdqHGvVWwcirzoDTM)
   eBNhylkPaspxIJdqHGvVWwcirzoDMb=eBNhylkPaspxIJdqHGvVWwcirzoDMR.callRequestCookies('Get',eBNhylkPaspxIJdqHGvVWwcirzoDXm,payload=eBNhylkPaspxIJdqHGvVWwcirzoDXS,params=eBNhylkPaspxIJdqHGvVWwcirzoDXS,headers=eBNhylkPaspxIJdqHGvVWwcirzoDXS,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDMm)
   eBNhylkPaspxIJdqHGvVWwcirzoDXL =re.findall('data-profile-no="\d+"',eBNhylkPaspxIJdqHGvVWwcirzoDMb.text)
   for i in eBNhylkPaspxIJdqHGvVWwcirzoDXn(eBNhylkPaspxIJdqHGvVWwcirzoDUM(eBNhylkPaspxIJdqHGvVWwcirzoDXL)):
    eBNhylkPaspxIJdqHGvVWwcirzoDXu =eBNhylkPaspxIJdqHGvVWwcirzoDXL[i].replace('data-profile-no=','').replace('"','')
    eBNhylkPaspxIJdqHGvVWwcirzoDXL[i]=eBNhylkPaspxIJdqHGvVWwcirzoDXu
   eBNhylkPaspxIJdqHGvVWwcirzoDXf=eBNhylkPaspxIJdqHGvVWwcirzoDXL[user_pf]
  except eBNhylkPaspxIJdqHGvVWwcirzoDXA as exception:
   eBNhylkPaspxIJdqHGvVWwcirzoDXb(exception)
   return eBNhylkPaspxIJdqHGvVWwcirzoDXO,eBNhylkPaspxIJdqHGvVWwcirzoDXt,eBNhylkPaspxIJdqHGvVWwcirzoDXY
  try:
   eBNhylkPaspxIJdqHGvVWwcirzoDTO ='/profile/api/select.do'
   eBNhylkPaspxIJdqHGvVWwcirzoDXm=eBNhylkPaspxIJdqHGvVWwcirzoDMR.URL_DOMAIN+eBNhylkPaspxIJdqHGvVWwcirzoDTO
   eBNhylkPaspxIJdqHGvVWwcirzoDMm=eBNhylkPaspxIJdqHGvVWwcirzoDMR.makeDefaultCookies(vToken=eBNhylkPaspxIJdqHGvVWwcirzoDMK,vUserinfo=eBNhylkPaspxIJdqHGvVWwcirzoDTM)
   eBNhylkPaspxIJdqHGvVWwcirzoDMA={'profileNo':eBNhylkPaspxIJdqHGvVWwcirzoDXf}
   eBNhylkPaspxIJdqHGvVWwcirzoDMb=eBNhylkPaspxIJdqHGvVWwcirzoDMR.callRequestCookies('Post',eBNhylkPaspxIJdqHGvVWwcirzoDXm,payload=eBNhylkPaspxIJdqHGvVWwcirzoDMA,params=eBNhylkPaspxIJdqHGvVWwcirzoDXS,headers=eBNhylkPaspxIJdqHGvVWwcirzoDXS,cookies=eBNhylkPaspxIJdqHGvVWwcirzoDMm)
   for eBNhylkPaspxIJdqHGvVWwcirzoDME in eBNhylkPaspxIJdqHGvVWwcirzoDMb.cookies:
    if eBNhylkPaspxIJdqHGvVWwcirzoDME.name=='_tving_token':
     eBNhylkPaspxIJdqHGvVWwcirzoDXO=eBNhylkPaspxIJdqHGvVWwcirzoDME.value
    elif eBNhylkPaspxIJdqHGvVWwcirzoDME.name==eBNhylkPaspxIJdqHGvVWwcirzoDMR.GLOBAL_COOKIENM['tv_cookiekey']:
     eBNhylkPaspxIJdqHGvVWwcirzoDXt=eBNhylkPaspxIJdqHGvVWwcirzoDME.value
    elif eBNhylkPaspxIJdqHGvVWwcirzoDME.name==eBNhylkPaspxIJdqHGvVWwcirzoDMR.GLOBAL_COOKIENM['tv_lockkey']:
     eBNhylkPaspxIJdqHGvVWwcirzoDXY=eBNhylkPaspxIJdqHGvVWwcirzoDME.value
  except eBNhylkPaspxIJdqHGvVWwcirzoDXA as exception:
   eBNhylkPaspxIJdqHGvVWwcirzoDXb(exception)
  return eBNhylkPaspxIJdqHGvVWwcirzoDXO,eBNhylkPaspxIJdqHGvVWwcirzoDXt,eBNhylkPaspxIJdqHGvVWwcirzoDXY
# Created by pyminifier (https://github.com/liftoff/pyminifier)
