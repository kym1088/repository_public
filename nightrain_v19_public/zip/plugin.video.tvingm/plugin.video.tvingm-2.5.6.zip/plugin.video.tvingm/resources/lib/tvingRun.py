__author__="NightRain"
KwEivmyQCaTURufplVHBDjrnbtdqYe=object
KwEivmyQCaTURufplVHBDjrnbtdqYM=None
KwEivmyQCaTURufplVHBDjrnbtdqYS=int
KwEivmyQCaTURufplVHBDjrnbtdqYh=True
KwEivmyQCaTURufplVHBDjrnbtdqYk=False
KwEivmyQCaTURufplVHBDjrnbtdqYN=type
KwEivmyQCaTURufplVHBDjrnbtdqxG=dict
KwEivmyQCaTURufplVHBDjrnbtdqxW=getattr
KwEivmyQCaTURufplVHBDjrnbtdqxs=list
KwEivmyQCaTURufplVHBDjrnbtdqxP=len
KwEivmyQCaTURufplVHBDjrnbtdqxX=str
KwEivmyQCaTURufplVHBDjrnbtdqxO=range
KwEivmyQCaTURufplVHBDjrnbtdqxz=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
KwEivmyQCaTURufplVHBDjrnbtdqGs=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
KwEivmyQCaTURufplVHBDjrnbtdqGP=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
KwEivmyQCaTURufplVHBDjrnbtdqGX=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
KwEivmyQCaTURufplVHBDjrnbtdqGO=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
KwEivmyQCaTURufplVHBDjrnbtdqGz=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
KwEivmyQCaTURufplVHBDjrnbtdqGY=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
KwEivmyQCaTURufplVHBDjrnbtdqGx=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
KwEivmyQCaTURufplVHBDjrnbtdqGA={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
KwEivmyQCaTURufplVHBDjrnbtdqGg =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
KwEivmyQCaTURufplVHBDjrnbtdqGF=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class KwEivmyQCaTURufplVHBDjrnbtdqGW(KwEivmyQCaTURufplVHBDjrnbtdqYe):
 def __init__(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqGI,KwEivmyQCaTURufplVHBDjrnbtdqGo,KwEivmyQCaTURufplVHBDjrnbtdqGL):
  KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_url =KwEivmyQCaTURufplVHBDjrnbtdqGI
  KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle=KwEivmyQCaTURufplVHBDjrnbtdqGo
  KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params =KwEivmyQCaTURufplVHBDjrnbtdqGL
  KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj =CMHiVyzBwukmsJhaNgoSeXqjtFObEK() 
  KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(KwEivmyQCaTURufplVHBDjrnbtdqGc,sting):
  try:
   KwEivmyQCaTURufplVHBDjrnbtdqGe=xbmcgui.Dialog()
   KwEivmyQCaTURufplVHBDjrnbtdqGe.notification(__addonname__,sting)
  except:
   KwEivmyQCaTURufplVHBDjrnbtdqYM
 def addon_log(KwEivmyQCaTURufplVHBDjrnbtdqGc,string):
  try:
   KwEivmyQCaTURufplVHBDjrnbtdqGM=string.encode('utf-8','ignore')
  except:
   KwEivmyQCaTURufplVHBDjrnbtdqGM='addonException: addon_log'
  KwEivmyQCaTURufplVHBDjrnbtdqGS=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,KwEivmyQCaTURufplVHBDjrnbtdqGM),level=KwEivmyQCaTURufplVHBDjrnbtdqGS)
 def get_keyboard_input(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqWL):
  KwEivmyQCaTURufplVHBDjrnbtdqGh=KwEivmyQCaTURufplVHBDjrnbtdqYM
  kb=xbmc.Keyboard()
  kb.setHeading(KwEivmyQCaTURufplVHBDjrnbtdqWL)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   KwEivmyQCaTURufplVHBDjrnbtdqGh=kb.getText()
  return KwEivmyQCaTURufplVHBDjrnbtdqGh
 def get_settings_account(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  KwEivmyQCaTURufplVHBDjrnbtdqGk =__addon__.getSetting('id')
  KwEivmyQCaTURufplVHBDjrnbtdqGN =__addon__.getSetting('pw')
  KwEivmyQCaTURufplVHBDjrnbtdqWG =__addon__.getSetting('login_type')
  KwEivmyQCaTURufplVHBDjrnbtdqWs=KwEivmyQCaTURufplVHBDjrnbtdqYS(__addon__.getSetting('selected_profile'))
  return(KwEivmyQCaTURufplVHBDjrnbtdqGk,KwEivmyQCaTURufplVHBDjrnbtdqGN,KwEivmyQCaTURufplVHBDjrnbtdqWG,KwEivmyQCaTURufplVHBDjrnbtdqWs)
 def get_settings_uhd(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  return KwEivmyQCaTURufplVHBDjrnbtdqYh if __addon__.getSetting('active_uhd')=='true' else KwEivmyQCaTURufplVHBDjrnbtdqYk
 def get_settings_playback(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  KwEivmyQCaTURufplVHBDjrnbtdqWP={'active_uhd':KwEivmyQCaTURufplVHBDjrnbtdqYh if __addon__.getSetting('active_uhd')=='true' else KwEivmyQCaTURufplVHBDjrnbtdqYk,'streamFilename':KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.TV_STREAM_FILENAME,}
  return KwEivmyQCaTURufplVHBDjrnbtdqWP
 def get_settings_proxyport(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  KwEivmyQCaTURufplVHBDjrnbtdqWX =KwEivmyQCaTURufplVHBDjrnbtdqYh if __addon__.getSetting('proxyYn')=='true' else KwEivmyQCaTURufplVHBDjrnbtdqYk
  KwEivmyQCaTURufplVHBDjrnbtdqWO=KwEivmyQCaTURufplVHBDjrnbtdqYS(__addon__.getSetting('proxyPort'))
  return KwEivmyQCaTURufplVHBDjrnbtdqWX,KwEivmyQCaTURufplVHBDjrnbtdqWO
 def get_settings_totalsearch(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  KwEivmyQCaTURufplVHBDjrnbtdqWz =KwEivmyQCaTURufplVHBDjrnbtdqYh if __addon__.getSetting('local_search')=='true' else KwEivmyQCaTURufplVHBDjrnbtdqYk
  KwEivmyQCaTURufplVHBDjrnbtdqWY=KwEivmyQCaTURufplVHBDjrnbtdqYh if __addon__.getSetting('local_history')=='true' else KwEivmyQCaTURufplVHBDjrnbtdqYk
  KwEivmyQCaTURufplVHBDjrnbtdqWx =KwEivmyQCaTURufplVHBDjrnbtdqYh if __addon__.getSetting('total_search')=='true' else KwEivmyQCaTURufplVHBDjrnbtdqYk
  KwEivmyQCaTURufplVHBDjrnbtdqWA=KwEivmyQCaTURufplVHBDjrnbtdqYh if __addon__.getSetting('total_history')=='true' else KwEivmyQCaTURufplVHBDjrnbtdqYk
  KwEivmyQCaTURufplVHBDjrnbtdqWg=KwEivmyQCaTURufplVHBDjrnbtdqYh if __addon__.getSetting('menu_bookmark')=='true' else KwEivmyQCaTURufplVHBDjrnbtdqYk
  return(KwEivmyQCaTURufplVHBDjrnbtdqWz,KwEivmyQCaTURufplVHBDjrnbtdqWY,KwEivmyQCaTURufplVHBDjrnbtdqWx,KwEivmyQCaTURufplVHBDjrnbtdqWA,KwEivmyQCaTURufplVHBDjrnbtdqWg)
 def get_settings_makebookmark(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  return KwEivmyQCaTURufplVHBDjrnbtdqYh if __addon__.getSetting('make_bookmark')=='true' else KwEivmyQCaTURufplVHBDjrnbtdqYk
 def get_settings_direct_replay(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  KwEivmyQCaTURufplVHBDjrnbtdqWF=KwEivmyQCaTURufplVHBDjrnbtdqYS(__addon__.getSetting('direct_replay'))
  if KwEivmyQCaTURufplVHBDjrnbtdqWF==0:
   return KwEivmyQCaTURufplVHBDjrnbtdqYk
  else:
   return KwEivmyQCaTURufplVHBDjrnbtdqYh
 def set_winEpisodeOrderby(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqWI):
  __addon__.setSetting('tving_orderby',KwEivmyQCaTURufplVHBDjrnbtdqWI)
  KwEivmyQCaTURufplVHBDjrnbtdqWc=xbmcgui.Window(10000)
  KwEivmyQCaTURufplVHBDjrnbtdqWc.setProperty('TVING_M_ORDERBY',KwEivmyQCaTURufplVHBDjrnbtdqWI)
 def get_winEpisodeOrderby(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  KwEivmyQCaTURufplVHBDjrnbtdqWI=__addon__.getSetting('tving_orderby')
  if KwEivmyQCaTURufplVHBDjrnbtdqWI in['',KwEivmyQCaTURufplVHBDjrnbtdqYM]:KwEivmyQCaTURufplVHBDjrnbtdqWI='desc'
  return KwEivmyQCaTURufplVHBDjrnbtdqWI
 def add_dir(KwEivmyQCaTURufplVHBDjrnbtdqGc,label,sublabel='',img='',infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqYM,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params='',isLink=KwEivmyQCaTURufplVHBDjrnbtdqYk,ContextMenu=KwEivmyQCaTURufplVHBDjrnbtdqYM):
  KwEivmyQCaTURufplVHBDjrnbtdqWo='%s?%s'%(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_url,urllib.parse.urlencode(params))
  if sublabel:KwEivmyQCaTURufplVHBDjrnbtdqWL='%s < %s >'%(label,sublabel)
  else: KwEivmyQCaTURufplVHBDjrnbtdqWL=label
  if not img:img='DefaultFolder.png'
  KwEivmyQCaTURufplVHBDjrnbtdqWJ=xbmcgui.ListItem(KwEivmyQCaTURufplVHBDjrnbtdqWL)
  if KwEivmyQCaTURufplVHBDjrnbtdqYN(img)==KwEivmyQCaTURufplVHBDjrnbtdqxG:
   KwEivmyQCaTURufplVHBDjrnbtdqWJ.setArt(img)
  else:
   KwEivmyQCaTURufplVHBDjrnbtdqWJ.setArt({'thumb':img,'poster':img})
  if KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.KodiVersion>=20:
   if infoLabels:KwEivmyQCaTURufplVHBDjrnbtdqGc.Set_InfoTag(KwEivmyQCaTURufplVHBDjrnbtdqWJ.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:KwEivmyQCaTURufplVHBDjrnbtdqWJ.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   KwEivmyQCaTURufplVHBDjrnbtdqWJ.setProperty('IsPlayable','true')
  if ContextMenu:KwEivmyQCaTURufplVHBDjrnbtdqWJ.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,KwEivmyQCaTURufplVHBDjrnbtdqWo,KwEivmyQCaTURufplVHBDjrnbtdqWJ,isFolder)
 def get_selQuality(KwEivmyQCaTURufplVHBDjrnbtdqGc,etype):
  try:
   KwEivmyQCaTURufplVHBDjrnbtdqWe='selected_quality'
   KwEivmyQCaTURufplVHBDjrnbtdqWM=[1080,720,480,360]
   KwEivmyQCaTURufplVHBDjrnbtdqWS=KwEivmyQCaTURufplVHBDjrnbtdqYS(__addon__.getSetting(KwEivmyQCaTURufplVHBDjrnbtdqWe))
   return KwEivmyQCaTURufplVHBDjrnbtdqWM[KwEivmyQCaTURufplVHBDjrnbtdqWS]
  except:
   KwEivmyQCaTURufplVHBDjrnbtdqYM
  return 720 
 def Set_InfoTag(KwEivmyQCaTURufplVHBDjrnbtdqGc,video_InfoTag:xbmc.InfoTagVideo,KwEivmyQCaTURufplVHBDjrnbtdqsO):
  for KwEivmyQCaTURufplVHBDjrnbtdqWh,value in KwEivmyQCaTURufplVHBDjrnbtdqsO.items():
   if KwEivmyQCaTURufplVHBDjrnbtdqGA[KwEivmyQCaTURufplVHBDjrnbtdqWh]['type']=='string':
    KwEivmyQCaTURufplVHBDjrnbtdqxW(video_InfoTag,KwEivmyQCaTURufplVHBDjrnbtdqGA[KwEivmyQCaTURufplVHBDjrnbtdqWh]['func'])(value)
   elif KwEivmyQCaTURufplVHBDjrnbtdqGA[KwEivmyQCaTURufplVHBDjrnbtdqWh]['type']=='int':
    if KwEivmyQCaTURufplVHBDjrnbtdqYN(value)==KwEivmyQCaTURufplVHBDjrnbtdqYS:
     KwEivmyQCaTURufplVHBDjrnbtdqWk=KwEivmyQCaTURufplVHBDjrnbtdqYS(value)
    else:
     KwEivmyQCaTURufplVHBDjrnbtdqWk=0
    KwEivmyQCaTURufplVHBDjrnbtdqxW(video_InfoTag,KwEivmyQCaTURufplVHBDjrnbtdqGA[KwEivmyQCaTURufplVHBDjrnbtdqWh]['func'])(KwEivmyQCaTURufplVHBDjrnbtdqWk)
   elif KwEivmyQCaTURufplVHBDjrnbtdqGA[KwEivmyQCaTURufplVHBDjrnbtdqWh]['type']=='actor':
    if value!=[]:
     KwEivmyQCaTURufplVHBDjrnbtdqxW(video_InfoTag,KwEivmyQCaTURufplVHBDjrnbtdqGA[KwEivmyQCaTURufplVHBDjrnbtdqWh]['func'])([xbmc.Actor(name)for name in value])
   elif KwEivmyQCaTURufplVHBDjrnbtdqGA[KwEivmyQCaTURufplVHBDjrnbtdqWh]['type']=='list':
    if KwEivmyQCaTURufplVHBDjrnbtdqYN(value)==KwEivmyQCaTURufplVHBDjrnbtdqxs:
     KwEivmyQCaTURufplVHBDjrnbtdqxW(video_InfoTag,KwEivmyQCaTURufplVHBDjrnbtdqGA[KwEivmyQCaTURufplVHBDjrnbtdqWh]['func'])(value)
    else:
     KwEivmyQCaTURufplVHBDjrnbtdqxW(video_InfoTag,KwEivmyQCaTURufplVHBDjrnbtdqGA[KwEivmyQCaTURufplVHBDjrnbtdqWh]['func'])([value])
 def dp_Main_List(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  (KwEivmyQCaTURufplVHBDjrnbtdqWz,KwEivmyQCaTURufplVHBDjrnbtdqWY,KwEivmyQCaTURufplVHBDjrnbtdqWx,KwEivmyQCaTURufplVHBDjrnbtdqWA,KwEivmyQCaTURufplVHBDjrnbtdqWg)=KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_totalsearch()
  for KwEivmyQCaTURufplVHBDjrnbtdqWN in KwEivmyQCaTURufplVHBDjrnbtdqGs:
   KwEivmyQCaTURufplVHBDjrnbtdqWL=KwEivmyQCaTURufplVHBDjrnbtdqWN.get('title')
   KwEivmyQCaTURufplVHBDjrnbtdqsG=''
   if KwEivmyQCaTURufplVHBDjrnbtdqWN.get('mode')=='SEARCH_GROUP' and KwEivmyQCaTURufplVHBDjrnbtdqWz ==KwEivmyQCaTURufplVHBDjrnbtdqYk:continue
   elif KwEivmyQCaTURufplVHBDjrnbtdqWN.get('mode')=='SEARCH_HISTORY' and KwEivmyQCaTURufplVHBDjrnbtdqWY==KwEivmyQCaTURufplVHBDjrnbtdqYk:continue
   elif KwEivmyQCaTURufplVHBDjrnbtdqWN.get('mode')=='TOTAL_SEARCH' and KwEivmyQCaTURufplVHBDjrnbtdqWx ==KwEivmyQCaTURufplVHBDjrnbtdqYk:continue
   elif KwEivmyQCaTURufplVHBDjrnbtdqWN.get('mode')=='TOTAL_HISTORY' and KwEivmyQCaTURufplVHBDjrnbtdqWA==KwEivmyQCaTURufplVHBDjrnbtdqYk:continue
   elif KwEivmyQCaTURufplVHBDjrnbtdqWN.get('mode')=='MENU_BOOKMARK' and KwEivmyQCaTURufplVHBDjrnbtdqWg==KwEivmyQCaTURufplVHBDjrnbtdqYk:continue
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':KwEivmyQCaTURufplVHBDjrnbtdqWN.get('mode'),'stype':KwEivmyQCaTURufplVHBDjrnbtdqWN.get('stype'),'orderby':KwEivmyQCaTURufplVHBDjrnbtdqWN.get('orderby'),'ordernm':KwEivmyQCaTURufplVHBDjrnbtdqWN.get('ordernm'),'page':'1'}
   if KwEivmyQCaTURufplVHBDjrnbtdqWN.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    KwEivmyQCaTURufplVHBDjrnbtdqsP=KwEivmyQCaTURufplVHBDjrnbtdqYk
    KwEivmyQCaTURufplVHBDjrnbtdqsX =KwEivmyQCaTURufplVHBDjrnbtdqYh
   else:
    KwEivmyQCaTURufplVHBDjrnbtdqsP=KwEivmyQCaTURufplVHBDjrnbtdqYh
    KwEivmyQCaTURufplVHBDjrnbtdqsX =KwEivmyQCaTURufplVHBDjrnbtdqYk
   KwEivmyQCaTURufplVHBDjrnbtdqsO={'title':KwEivmyQCaTURufplVHBDjrnbtdqWL,'plot':KwEivmyQCaTURufplVHBDjrnbtdqWL}
   if KwEivmyQCaTURufplVHBDjrnbtdqWN.get('mode')=='XXX':KwEivmyQCaTURufplVHBDjrnbtdqsO=KwEivmyQCaTURufplVHBDjrnbtdqYM
   if 'icon' in KwEivmyQCaTURufplVHBDjrnbtdqWN:KwEivmyQCaTURufplVHBDjrnbtdqsG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',KwEivmyQCaTURufplVHBDjrnbtdqWN.get('icon')) 
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel='',img=KwEivmyQCaTURufplVHBDjrnbtdqsG,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqsO,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqsP,params=KwEivmyQCaTURufplVHBDjrnbtdqsW,isLink=KwEivmyQCaTURufplVHBDjrnbtdqsX)
  xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle)
 def login_main(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  (KwEivmyQCaTURufplVHBDjrnbtdqsY,KwEivmyQCaTURufplVHBDjrnbtdqsx,KwEivmyQCaTURufplVHBDjrnbtdqsA,KwEivmyQCaTURufplVHBDjrnbtdqsg)=KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_account()
  if not(KwEivmyQCaTURufplVHBDjrnbtdqsY and KwEivmyQCaTURufplVHBDjrnbtdqsx):
   KwEivmyQCaTURufplVHBDjrnbtdqGe=xbmcgui.Dialog()
   KwEivmyQCaTURufplVHBDjrnbtdqsF=KwEivmyQCaTURufplVHBDjrnbtdqGe.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if KwEivmyQCaTURufplVHBDjrnbtdqsF==KwEivmyQCaTURufplVHBDjrnbtdqYh:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if KwEivmyQCaTURufplVHBDjrnbtdqGc.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   KwEivmyQCaTURufplVHBDjrnbtdqsc=0
   while KwEivmyQCaTURufplVHBDjrnbtdqYh:
    KwEivmyQCaTURufplVHBDjrnbtdqsc+=1
    time.sleep(0.05)
    if KwEivmyQCaTURufplVHBDjrnbtdqsc>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  KwEivmyQCaTURufplVHBDjrnbtdqsI=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.GetCredential(KwEivmyQCaTURufplVHBDjrnbtdqsY,KwEivmyQCaTURufplVHBDjrnbtdqsx,KwEivmyQCaTURufplVHBDjrnbtdqsA,KwEivmyQCaTURufplVHBDjrnbtdqsg)
  if KwEivmyQCaTURufplVHBDjrnbtdqsI:KwEivmyQCaTURufplVHBDjrnbtdqGc.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if KwEivmyQCaTURufplVHBDjrnbtdqsI==KwEivmyQCaTURufplVHBDjrnbtdqYk:
   KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqso=KwEivmyQCaTURufplVHBDjrnbtdqse.get('stype')
  if KwEivmyQCaTURufplVHBDjrnbtdqso=='live':
   KwEivmyQCaTURufplVHBDjrnbtdqsL=KwEivmyQCaTURufplVHBDjrnbtdqGP
  elif KwEivmyQCaTURufplVHBDjrnbtdqso=='vod':
   KwEivmyQCaTURufplVHBDjrnbtdqsL=KwEivmyQCaTURufplVHBDjrnbtdqGz
  else:
   KwEivmyQCaTURufplVHBDjrnbtdqsL=KwEivmyQCaTURufplVHBDjrnbtdqGY
  for KwEivmyQCaTURufplVHBDjrnbtdqsJ in KwEivmyQCaTURufplVHBDjrnbtdqsL:
   KwEivmyQCaTURufplVHBDjrnbtdqWL=KwEivmyQCaTURufplVHBDjrnbtdqsJ.get('title')
   if KwEivmyQCaTURufplVHBDjrnbtdqse.get('ordernm')!='-':
    KwEivmyQCaTURufplVHBDjrnbtdqWL+='  ('+KwEivmyQCaTURufplVHBDjrnbtdqse.get('ordernm')+')'
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':KwEivmyQCaTURufplVHBDjrnbtdqsJ.get('mode'),'stype':KwEivmyQCaTURufplVHBDjrnbtdqsJ.get('stype'),'orderby':KwEivmyQCaTURufplVHBDjrnbtdqse.get('orderby'),'ordernm':KwEivmyQCaTURufplVHBDjrnbtdqse.get('ordernm'),'page':'1'}
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel='',img='',infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqYM,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  if KwEivmyQCaTURufplVHBDjrnbtdqxP(KwEivmyQCaTURufplVHBDjrnbtdqsL)>0:xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle)
 def dp_SubTitle_Group(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse): 
  for KwEivmyQCaTURufplVHBDjrnbtdqsJ in KwEivmyQCaTURufplVHBDjrnbtdqGx:
   KwEivmyQCaTURufplVHBDjrnbtdqWL=KwEivmyQCaTURufplVHBDjrnbtdqsJ.get('title')
   if KwEivmyQCaTURufplVHBDjrnbtdqse.get('ordernm')!='-':
    KwEivmyQCaTURufplVHBDjrnbtdqWL+='  ('+KwEivmyQCaTURufplVHBDjrnbtdqse.get('ordernm')+')'
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':KwEivmyQCaTURufplVHBDjrnbtdqsJ.get('mode'),'genreCode':KwEivmyQCaTURufplVHBDjrnbtdqsJ.get('genreCode'),'stype':KwEivmyQCaTURufplVHBDjrnbtdqse.get('stype'),'orderby':KwEivmyQCaTURufplVHBDjrnbtdqse.get('orderby'),'page':'1'}
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel='',img='',infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqYM,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  if KwEivmyQCaTURufplVHBDjrnbtdqxP(KwEivmyQCaTURufplVHBDjrnbtdqGx)>0:xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle)
 def dp_LiveChannel_List(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqso =KwEivmyQCaTURufplVHBDjrnbtdqse.get('stype')
  KwEivmyQCaTURufplVHBDjrnbtdqsM =KwEivmyQCaTURufplVHBDjrnbtdqYS(KwEivmyQCaTURufplVHBDjrnbtdqse.get('page'))
  KwEivmyQCaTURufplVHBDjrnbtdqsS,KwEivmyQCaTURufplVHBDjrnbtdqsh=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.GetLiveChannelList(KwEivmyQCaTURufplVHBDjrnbtdqso,KwEivmyQCaTURufplVHBDjrnbtdqsM)
  for KwEivmyQCaTURufplVHBDjrnbtdqsk in KwEivmyQCaTURufplVHBDjrnbtdqsS:
   KwEivmyQCaTURufplVHBDjrnbtdqWL =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('title')
   KwEivmyQCaTURufplVHBDjrnbtdqsz =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('channel')
   KwEivmyQCaTURufplVHBDjrnbtdqsN =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('thumbnail')
   KwEivmyQCaTURufplVHBDjrnbtdqPG =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('synopsis')
   KwEivmyQCaTURufplVHBDjrnbtdqPW =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('channelepg')
   KwEivmyQCaTURufplVHBDjrnbtdqPs =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('cast')
   KwEivmyQCaTURufplVHBDjrnbtdqPX =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('director')
   KwEivmyQCaTURufplVHBDjrnbtdqPO =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('info_genre')
   KwEivmyQCaTURufplVHBDjrnbtdqPz =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('year')
   KwEivmyQCaTURufplVHBDjrnbtdqPY =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('mpaa')
   KwEivmyQCaTURufplVHBDjrnbtdqPx =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('premiered')
   KwEivmyQCaTURufplVHBDjrnbtdqPA={'mediatype':'episode','title':KwEivmyQCaTURufplVHBDjrnbtdqWL,'studio':KwEivmyQCaTURufplVHBDjrnbtdqsz,'cast':KwEivmyQCaTURufplVHBDjrnbtdqPs,'director':KwEivmyQCaTURufplVHBDjrnbtdqPX,'genre':KwEivmyQCaTURufplVHBDjrnbtdqPO,'plot':'%s\n%s\n%s\n\n%s'%(KwEivmyQCaTURufplVHBDjrnbtdqsz,KwEivmyQCaTURufplVHBDjrnbtdqWL,KwEivmyQCaTURufplVHBDjrnbtdqPW,KwEivmyQCaTURufplVHBDjrnbtdqPG),'year':KwEivmyQCaTURufplVHBDjrnbtdqPz,'mpaa':KwEivmyQCaTURufplVHBDjrnbtdqPY,'premiered':KwEivmyQCaTURufplVHBDjrnbtdqPx}
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'LIVE','mediacode':KwEivmyQCaTURufplVHBDjrnbtdqsk.get('mediacode'),'stype':KwEivmyQCaTURufplVHBDjrnbtdqso}
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqsz,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqWL,img=KwEivmyQCaTURufplVHBDjrnbtdqsN,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqPA,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYk,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  if KwEivmyQCaTURufplVHBDjrnbtdqsh:
   KwEivmyQCaTURufplVHBDjrnbtdqsW['mode']='CHANNEL' 
   KwEivmyQCaTURufplVHBDjrnbtdqsW['stype']=KwEivmyQCaTURufplVHBDjrnbtdqso 
   KwEivmyQCaTURufplVHBDjrnbtdqsW['page']=KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqWL='[B]%s >>[/B]'%'다음 페이지'
   KwEivmyQCaTURufplVHBDjrnbtdqPg=KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqsG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqPg,img=KwEivmyQCaTURufplVHBDjrnbtdqsG,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqYM,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  if KwEivmyQCaTURufplVHBDjrnbtdqxP(KwEivmyQCaTURufplVHBDjrnbtdqsS)>0:xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,cacheToDisc=KwEivmyQCaTURufplVHBDjrnbtdqYk)
 def dp_Program_List(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqPF =KwEivmyQCaTURufplVHBDjrnbtdqse.get('stype')
  KwEivmyQCaTURufplVHBDjrnbtdqWI =KwEivmyQCaTURufplVHBDjrnbtdqse.get('orderby')
  KwEivmyQCaTURufplVHBDjrnbtdqsM =KwEivmyQCaTURufplVHBDjrnbtdqYS(KwEivmyQCaTURufplVHBDjrnbtdqse.get('page'))
  KwEivmyQCaTURufplVHBDjrnbtdqPc=KwEivmyQCaTURufplVHBDjrnbtdqse.get('genreCode')
  if KwEivmyQCaTURufplVHBDjrnbtdqPc==KwEivmyQCaTURufplVHBDjrnbtdqYM:KwEivmyQCaTURufplVHBDjrnbtdqPc='all'
  KwEivmyQCaTURufplVHBDjrnbtdqPI,KwEivmyQCaTURufplVHBDjrnbtdqsh=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.GetProgramList(KwEivmyQCaTURufplVHBDjrnbtdqPF,KwEivmyQCaTURufplVHBDjrnbtdqWI,KwEivmyQCaTURufplVHBDjrnbtdqsM,KwEivmyQCaTURufplVHBDjrnbtdqPc)
  for KwEivmyQCaTURufplVHBDjrnbtdqPo in KwEivmyQCaTURufplVHBDjrnbtdqPI:
   KwEivmyQCaTURufplVHBDjrnbtdqWL =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('title')
   KwEivmyQCaTURufplVHBDjrnbtdqsN =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('thumbnail')
   KwEivmyQCaTURufplVHBDjrnbtdqPG =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('synopsis')
   KwEivmyQCaTURufplVHBDjrnbtdqPL =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('channel')
   KwEivmyQCaTURufplVHBDjrnbtdqPs =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('cast')
   KwEivmyQCaTURufplVHBDjrnbtdqPX =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('director')
   KwEivmyQCaTURufplVHBDjrnbtdqPO=KwEivmyQCaTURufplVHBDjrnbtdqPo.get('info_genre')
   KwEivmyQCaTURufplVHBDjrnbtdqPz =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('year')
   KwEivmyQCaTURufplVHBDjrnbtdqPx =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('premiered')
   KwEivmyQCaTURufplVHBDjrnbtdqPY =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('mpaa')
   KwEivmyQCaTURufplVHBDjrnbtdqPA={'mediatype':'tvshow','title':KwEivmyQCaTURufplVHBDjrnbtdqWL,'studio':KwEivmyQCaTURufplVHBDjrnbtdqPL,'cast':KwEivmyQCaTURufplVHBDjrnbtdqPs,'director':KwEivmyQCaTURufplVHBDjrnbtdqPX,'genre':KwEivmyQCaTURufplVHBDjrnbtdqPO,'year':KwEivmyQCaTURufplVHBDjrnbtdqPz,'premiered':KwEivmyQCaTURufplVHBDjrnbtdqPx,'mpaa':KwEivmyQCaTURufplVHBDjrnbtdqPY,'plot':KwEivmyQCaTURufplVHBDjrnbtdqPG}
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'EPISODE','programcode':KwEivmyQCaTURufplVHBDjrnbtdqPo.get('program'),'page':'1'}
   if KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_makebookmark():
    KwEivmyQCaTURufplVHBDjrnbtdqPJ={'videoid':KwEivmyQCaTURufplVHBDjrnbtdqPo.get('program'),'vidtype':'tvshow','vtitle':KwEivmyQCaTURufplVHBDjrnbtdqWL,'vsubtitle':KwEivmyQCaTURufplVHBDjrnbtdqPL,}
    KwEivmyQCaTURufplVHBDjrnbtdqPe=json.dumps(KwEivmyQCaTURufplVHBDjrnbtdqPJ)
    KwEivmyQCaTURufplVHBDjrnbtdqPe=urllib.parse.quote(KwEivmyQCaTURufplVHBDjrnbtdqPe)
    KwEivmyQCaTURufplVHBDjrnbtdqPM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(KwEivmyQCaTURufplVHBDjrnbtdqPe)
    KwEivmyQCaTURufplVHBDjrnbtdqPS=[('(통합) 찜 영상에 추가',KwEivmyQCaTURufplVHBDjrnbtdqPM)]
   else:
    KwEivmyQCaTURufplVHBDjrnbtdqPS=KwEivmyQCaTURufplVHBDjrnbtdqYM
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqPL,img=KwEivmyQCaTURufplVHBDjrnbtdqsN,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqPA,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW,ContextMenu=KwEivmyQCaTURufplVHBDjrnbtdqPS)
  if KwEivmyQCaTURufplVHBDjrnbtdqsh:
   KwEivmyQCaTURufplVHBDjrnbtdqsW['mode'] ='PROGRAM' 
   KwEivmyQCaTURufplVHBDjrnbtdqsW['stype'] =KwEivmyQCaTURufplVHBDjrnbtdqPF
   KwEivmyQCaTURufplVHBDjrnbtdqsW['orderby'] =KwEivmyQCaTURufplVHBDjrnbtdqWI
   KwEivmyQCaTURufplVHBDjrnbtdqsW['page'] =KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqsW['genreCode']=KwEivmyQCaTURufplVHBDjrnbtdqPc 
   KwEivmyQCaTURufplVHBDjrnbtdqWL='[B]%s >>[/B]'%'다음 페이지'
   KwEivmyQCaTURufplVHBDjrnbtdqPg=KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqsG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqPg,img=KwEivmyQCaTURufplVHBDjrnbtdqsG,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqYM,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  xbmcplugin.setContent(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,cacheToDisc=KwEivmyQCaTURufplVHBDjrnbtdqYk)
 def dp_4K_Program_List(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqsM =KwEivmyQCaTURufplVHBDjrnbtdqYS(KwEivmyQCaTURufplVHBDjrnbtdqse.get('page'))
  KwEivmyQCaTURufplVHBDjrnbtdqPI,KwEivmyQCaTURufplVHBDjrnbtdqsh=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Get_UHD_ProgramList(KwEivmyQCaTURufplVHBDjrnbtdqsM)
  for KwEivmyQCaTURufplVHBDjrnbtdqPo in KwEivmyQCaTURufplVHBDjrnbtdqPI:
   KwEivmyQCaTURufplVHBDjrnbtdqWL =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('title')
   KwEivmyQCaTURufplVHBDjrnbtdqsN =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('thumbnail')
   KwEivmyQCaTURufplVHBDjrnbtdqPG =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('synopsis')
   KwEivmyQCaTURufplVHBDjrnbtdqPL =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('channel')
   KwEivmyQCaTURufplVHBDjrnbtdqPs =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('cast')
   KwEivmyQCaTURufplVHBDjrnbtdqPX =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('director')
   KwEivmyQCaTURufplVHBDjrnbtdqPO=KwEivmyQCaTURufplVHBDjrnbtdqPo.get('info_genre')
   KwEivmyQCaTURufplVHBDjrnbtdqPz =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('year')
   KwEivmyQCaTURufplVHBDjrnbtdqPx =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('premiered')
   KwEivmyQCaTURufplVHBDjrnbtdqPY =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('mpaa')
   KwEivmyQCaTURufplVHBDjrnbtdqPA={'mediatype':'tvshow','title':KwEivmyQCaTURufplVHBDjrnbtdqWL,'studio':KwEivmyQCaTURufplVHBDjrnbtdqPL,'cast':KwEivmyQCaTURufplVHBDjrnbtdqPs,'director':KwEivmyQCaTURufplVHBDjrnbtdqPX,'genre':KwEivmyQCaTURufplVHBDjrnbtdqPO,'year':KwEivmyQCaTURufplVHBDjrnbtdqPz,'premiered':KwEivmyQCaTURufplVHBDjrnbtdqPx,'mpaa':KwEivmyQCaTURufplVHBDjrnbtdqPY,'plot':KwEivmyQCaTURufplVHBDjrnbtdqPG}
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'EPISODE','programcode':KwEivmyQCaTURufplVHBDjrnbtdqPo.get('program'),'page':'1'}
   if KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_makebookmark():
    KwEivmyQCaTURufplVHBDjrnbtdqPJ={'videoid':KwEivmyQCaTURufplVHBDjrnbtdqPo.get('program'),'vidtype':'tvshow','vtitle':KwEivmyQCaTURufplVHBDjrnbtdqWL,'vsubtitle':KwEivmyQCaTURufplVHBDjrnbtdqPL,}
    KwEivmyQCaTURufplVHBDjrnbtdqPe=json.dumps(KwEivmyQCaTURufplVHBDjrnbtdqPJ)
    KwEivmyQCaTURufplVHBDjrnbtdqPe=urllib.parse.quote(KwEivmyQCaTURufplVHBDjrnbtdqPe)
    KwEivmyQCaTURufplVHBDjrnbtdqPM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(KwEivmyQCaTURufplVHBDjrnbtdqPe)
    KwEivmyQCaTURufplVHBDjrnbtdqPS=[('(통합) 찜 영상에 추가',KwEivmyQCaTURufplVHBDjrnbtdqPM)]
   else:
    KwEivmyQCaTURufplVHBDjrnbtdqPS=KwEivmyQCaTURufplVHBDjrnbtdqYM
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqPL,img=KwEivmyQCaTURufplVHBDjrnbtdqsN,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqPA,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW,ContextMenu=KwEivmyQCaTURufplVHBDjrnbtdqPS)
  if KwEivmyQCaTURufplVHBDjrnbtdqsh:
   KwEivmyQCaTURufplVHBDjrnbtdqsW['mode'] ='4K_PROGRAM' 
   KwEivmyQCaTURufplVHBDjrnbtdqsW['page'] =KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqWL='[B]%s >>[/B]'%'다음 페이지'
   KwEivmyQCaTURufplVHBDjrnbtdqPg=KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqsG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqPg,img=KwEivmyQCaTURufplVHBDjrnbtdqsG,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqYM,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  xbmcplugin.setContent(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,cacheToDisc=KwEivmyQCaTURufplVHBDjrnbtdqYk)
 def dp_Ori_Program_List(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqsM =KwEivmyQCaTURufplVHBDjrnbtdqYS(KwEivmyQCaTURufplVHBDjrnbtdqse.get('page'))
  KwEivmyQCaTURufplVHBDjrnbtdqPI,KwEivmyQCaTURufplVHBDjrnbtdqsh=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Get_Origianl_ProgramList(KwEivmyQCaTURufplVHBDjrnbtdqsM)
  for KwEivmyQCaTURufplVHBDjrnbtdqPo in KwEivmyQCaTURufplVHBDjrnbtdqPI:
   KwEivmyQCaTURufplVHBDjrnbtdqWL =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('title')
   KwEivmyQCaTURufplVHBDjrnbtdqsN =KwEivmyQCaTURufplVHBDjrnbtdqPo.get('thumbnail')
   KwEivmyQCaTURufplVHBDjrnbtdqPA={'mediatype':'tvshow','title':KwEivmyQCaTURufplVHBDjrnbtdqWL,}
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'EPISODE','programcode':KwEivmyQCaTURufplVHBDjrnbtdqPo.get('program'),'page':'1',}
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqYM,img=KwEivmyQCaTURufplVHBDjrnbtdqsN,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqPA,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW,ContextMenu=KwEivmyQCaTURufplVHBDjrnbtdqYM)
  if KwEivmyQCaTURufplVHBDjrnbtdqsh:
   KwEivmyQCaTURufplVHBDjrnbtdqsW['mode'] ='ORI_PROGRAM' 
   KwEivmyQCaTURufplVHBDjrnbtdqsW['page'] =KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqWL='[B]%s >>[/B]'%'다음 페이지'
   KwEivmyQCaTURufplVHBDjrnbtdqPg=KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqsG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqPg,img=KwEivmyQCaTURufplVHBDjrnbtdqsG,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqYM,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  xbmcplugin.setContent(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,cacheToDisc=KwEivmyQCaTURufplVHBDjrnbtdqYk)
 def dp_Episode_List(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqPk=KwEivmyQCaTURufplVHBDjrnbtdqse.get('programcode')
  KwEivmyQCaTURufplVHBDjrnbtdqsM =KwEivmyQCaTURufplVHBDjrnbtdqYS(KwEivmyQCaTURufplVHBDjrnbtdqse.get('page'))
  KwEivmyQCaTURufplVHBDjrnbtdqPN,KwEivmyQCaTURufplVHBDjrnbtdqsh,KwEivmyQCaTURufplVHBDjrnbtdqXG=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.GetEpisodeList(KwEivmyQCaTURufplVHBDjrnbtdqPk,KwEivmyQCaTURufplVHBDjrnbtdqsM,orderby=KwEivmyQCaTURufplVHBDjrnbtdqGc.get_winEpisodeOrderby())
  for KwEivmyQCaTURufplVHBDjrnbtdqXW in KwEivmyQCaTURufplVHBDjrnbtdqPN:
   KwEivmyQCaTURufplVHBDjrnbtdqWL =KwEivmyQCaTURufplVHBDjrnbtdqXW.get('title')
   KwEivmyQCaTURufplVHBDjrnbtdqPg =KwEivmyQCaTURufplVHBDjrnbtdqXW.get('subtitle')
   KwEivmyQCaTURufplVHBDjrnbtdqsN =KwEivmyQCaTURufplVHBDjrnbtdqXW.get('thumbnail')
   KwEivmyQCaTURufplVHBDjrnbtdqPG =KwEivmyQCaTURufplVHBDjrnbtdqXW.get('synopsis')
   KwEivmyQCaTURufplVHBDjrnbtdqXs=KwEivmyQCaTURufplVHBDjrnbtdqXW.get('info_title')
   KwEivmyQCaTURufplVHBDjrnbtdqXP =KwEivmyQCaTURufplVHBDjrnbtdqXW.get('aired')
   KwEivmyQCaTURufplVHBDjrnbtdqXO =KwEivmyQCaTURufplVHBDjrnbtdqXW.get('studio')
   KwEivmyQCaTURufplVHBDjrnbtdqXz =KwEivmyQCaTURufplVHBDjrnbtdqXW.get('frequency')
   KwEivmyQCaTURufplVHBDjrnbtdqPA={'mediatype':'episode','title':KwEivmyQCaTURufplVHBDjrnbtdqXs,'aired':KwEivmyQCaTURufplVHBDjrnbtdqXP,'studio':KwEivmyQCaTURufplVHBDjrnbtdqXO,'episode':KwEivmyQCaTURufplVHBDjrnbtdqXz,'plot':KwEivmyQCaTURufplVHBDjrnbtdqPG}
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'VOD','mediacode':KwEivmyQCaTURufplVHBDjrnbtdqXW.get('episode'),'stype':'vod','programcode':KwEivmyQCaTURufplVHBDjrnbtdqPk,'title':KwEivmyQCaTURufplVHBDjrnbtdqWL,'thumbnail':KwEivmyQCaTURufplVHBDjrnbtdqsN}
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqPg,img=KwEivmyQCaTURufplVHBDjrnbtdqsN,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqPA,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYk,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  if KwEivmyQCaTURufplVHBDjrnbtdqsM==1:
   KwEivmyQCaTURufplVHBDjrnbtdqPA={'plot':'정렬순서를 변경합니다.'}
   KwEivmyQCaTURufplVHBDjrnbtdqsW={}
   KwEivmyQCaTURufplVHBDjrnbtdqsW['mode'] ='ORDER_BY' 
   if KwEivmyQCaTURufplVHBDjrnbtdqGc.get_winEpisodeOrderby()=='desc':
    KwEivmyQCaTURufplVHBDjrnbtdqWL='정렬순서변경 : 최신화부터 -> 1회부터'
    KwEivmyQCaTURufplVHBDjrnbtdqsW['orderby']='asc'
   else:
    KwEivmyQCaTURufplVHBDjrnbtdqWL='정렬순서변경 : 1회부터 -> 최신화부터'
    KwEivmyQCaTURufplVHBDjrnbtdqsW['orderby']='desc'
   KwEivmyQCaTURufplVHBDjrnbtdqsG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel='',img=KwEivmyQCaTURufplVHBDjrnbtdqsG,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqPA,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYk,params=KwEivmyQCaTURufplVHBDjrnbtdqsW,isLink=KwEivmyQCaTURufplVHBDjrnbtdqYh)
  if KwEivmyQCaTURufplVHBDjrnbtdqsh:
   KwEivmyQCaTURufplVHBDjrnbtdqsW['mode'] ='EPISODE' 
   KwEivmyQCaTURufplVHBDjrnbtdqsW['programcode']=KwEivmyQCaTURufplVHBDjrnbtdqPk
   KwEivmyQCaTURufplVHBDjrnbtdqsW['page'] =KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqWL='[B]%s >>[/B]'%'다음 페이지'
   KwEivmyQCaTURufplVHBDjrnbtdqPg=KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqsG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqPg,img=KwEivmyQCaTURufplVHBDjrnbtdqsG,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqYM,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  xbmcplugin.setContent(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,'episodes')
  if KwEivmyQCaTURufplVHBDjrnbtdqxP(KwEivmyQCaTURufplVHBDjrnbtdqPN)>0:xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,cacheToDisc=KwEivmyQCaTURufplVHBDjrnbtdqYh)
 def dp_setEpOrderby(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqWI =KwEivmyQCaTURufplVHBDjrnbtdqse.get('orderby')
  KwEivmyQCaTURufplVHBDjrnbtdqGc.set_winEpisodeOrderby(KwEivmyQCaTURufplVHBDjrnbtdqWI)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqPF =KwEivmyQCaTURufplVHBDjrnbtdqse.get('stype')
  KwEivmyQCaTURufplVHBDjrnbtdqWI =KwEivmyQCaTURufplVHBDjrnbtdqse.get('orderby')
  KwEivmyQCaTURufplVHBDjrnbtdqsM=KwEivmyQCaTURufplVHBDjrnbtdqYS(KwEivmyQCaTURufplVHBDjrnbtdqse.get('page'))
  KwEivmyQCaTURufplVHBDjrnbtdqXY,KwEivmyQCaTURufplVHBDjrnbtdqsh=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.GetMovieList(KwEivmyQCaTURufplVHBDjrnbtdqPF,KwEivmyQCaTURufplVHBDjrnbtdqWI,KwEivmyQCaTURufplVHBDjrnbtdqsM)
  for KwEivmyQCaTURufplVHBDjrnbtdqXx in KwEivmyQCaTURufplVHBDjrnbtdqXY:
   KwEivmyQCaTURufplVHBDjrnbtdqWL =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('title')
   KwEivmyQCaTURufplVHBDjrnbtdqsN =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('thumbnail')
   KwEivmyQCaTURufplVHBDjrnbtdqPG =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('synopsis')
   KwEivmyQCaTURufplVHBDjrnbtdqXs =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('info_title')
   KwEivmyQCaTURufplVHBDjrnbtdqPz =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('year')
   KwEivmyQCaTURufplVHBDjrnbtdqPs =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('cast')
   KwEivmyQCaTURufplVHBDjrnbtdqPX =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('director')
   KwEivmyQCaTURufplVHBDjrnbtdqPO =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('info_genre')
   KwEivmyQCaTURufplVHBDjrnbtdqXA =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('duration')
   KwEivmyQCaTURufplVHBDjrnbtdqPx =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('premiered')
   KwEivmyQCaTURufplVHBDjrnbtdqXO =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('studio')
   KwEivmyQCaTURufplVHBDjrnbtdqPY =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('mpaa')
   KwEivmyQCaTURufplVHBDjrnbtdqPA={'mediatype':'movie','title':KwEivmyQCaTURufplVHBDjrnbtdqXs,'year':KwEivmyQCaTURufplVHBDjrnbtdqPz,'cast':KwEivmyQCaTURufplVHBDjrnbtdqPs,'director':KwEivmyQCaTURufplVHBDjrnbtdqPX,'genre':KwEivmyQCaTURufplVHBDjrnbtdqPO,'duration':KwEivmyQCaTURufplVHBDjrnbtdqXA,'premiered':KwEivmyQCaTURufplVHBDjrnbtdqPx,'studio':KwEivmyQCaTURufplVHBDjrnbtdqXO,'mpaa':KwEivmyQCaTURufplVHBDjrnbtdqPY,'plot':KwEivmyQCaTURufplVHBDjrnbtdqPG}
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'MOVIE','mediacode':KwEivmyQCaTURufplVHBDjrnbtdqXx.get('moviecode'),'stype':'movie','title':KwEivmyQCaTURufplVHBDjrnbtdqWL,'thumbnail':KwEivmyQCaTURufplVHBDjrnbtdqsN}
   if KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_makebookmark():
    KwEivmyQCaTURufplVHBDjrnbtdqPJ={'videoid':KwEivmyQCaTURufplVHBDjrnbtdqXx.get('moviecode'),'vidtype':'movie','vtitle':KwEivmyQCaTURufplVHBDjrnbtdqXs,'vsubtitle':'',}
    KwEivmyQCaTURufplVHBDjrnbtdqPe=json.dumps(KwEivmyQCaTURufplVHBDjrnbtdqPJ)
    KwEivmyQCaTURufplVHBDjrnbtdqPe=urllib.parse.quote(KwEivmyQCaTURufplVHBDjrnbtdqPe)
    KwEivmyQCaTURufplVHBDjrnbtdqPM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(KwEivmyQCaTURufplVHBDjrnbtdqPe)
    KwEivmyQCaTURufplVHBDjrnbtdqPS=[('(통합) 찜 영상에 추가',KwEivmyQCaTURufplVHBDjrnbtdqPM)]
   else:
    KwEivmyQCaTURufplVHBDjrnbtdqPS=KwEivmyQCaTURufplVHBDjrnbtdqYM
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel='',img=KwEivmyQCaTURufplVHBDjrnbtdqsN,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqPA,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYk,params=KwEivmyQCaTURufplVHBDjrnbtdqsW,ContextMenu=KwEivmyQCaTURufplVHBDjrnbtdqPS)
  if KwEivmyQCaTURufplVHBDjrnbtdqsh:
   KwEivmyQCaTURufplVHBDjrnbtdqsW={}
   KwEivmyQCaTURufplVHBDjrnbtdqsW['mode'] ='MOVIE_SUB' 
   KwEivmyQCaTURufplVHBDjrnbtdqsW['orderby']=KwEivmyQCaTURufplVHBDjrnbtdqWI
   KwEivmyQCaTURufplVHBDjrnbtdqsW['stype'] =KwEivmyQCaTURufplVHBDjrnbtdqPF
   KwEivmyQCaTURufplVHBDjrnbtdqsW['page'] =KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqWL='[B]%s >>[/B]'%'다음 페이지'
   KwEivmyQCaTURufplVHBDjrnbtdqPg=KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqsG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqPg,img=KwEivmyQCaTURufplVHBDjrnbtdqsG,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqYM,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  xbmcplugin.setContent(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,'movies')
  xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,cacheToDisc=KwEivmyQCaTURufplVHBDjrnbtdqYk)
 def dp_4K_Movie_List(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqsM=KwEivmyQCaTURufplVHBDjrnbtdqYS(KwEivmyQCaTURufplVHBDjrnbtdqse.get('page'))
  KwEivmyQCaTURufplVHBDjrnbtdqXY,KwEivmyQCaTURufplVHBDjrnbtdqsh=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Get_UHD_MovieList(KwEivmyQCaTURufplVHBDjrnbtdqsM)
  for KwEivmyQCaTURufplVHBDjrnbtdqXx in KwEivmyQCaTURufplVHBDjrnbtdqXY:
   KwEivmyQCaTURufplVHBDjrnbtdqWL =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('title')
   KwEivmyQCaTURufplVHBDjrnbtdqsN =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('thumbnail')
   KwEivmyQCaTURufplVHBDjrnbtdqPG =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('synopsis')
   KwEivmyQCaTURufplVHBDjrnbtdqXs =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('info_title')
   KwEivmyQCaTURufplVHBDjrnbtdqPz =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('year')
   KwEivmyQCaTURufplVHBDjrnbtdqPs =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('cast')
   KwEivmyQCaTURufplVHBDjrnbtdqPX =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('director')
   KwEivmyQCaTURufplVHBDjrnbtdqPO =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('info_genre')
   KwEivmyQCaTURufplVHBDjrnbtdqXA =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('duration')
   KwEivmyQCaTURufplVHBDjrnbtdqPx =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('premiered')
   KwEivmyQCaTURufplVHBDjrnbtdqXO =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('studio')
   KwEivmyQCaTURufplVHBDjrnbtdqPY =KwEivmyQCaTURufplVHBDjrnbtdqXx.get('mpaa')
   KwEivmyQCaTURufplVHBDjrnbtdqPA={'mediatype':'movie','title':KwEivmyQCaTURufplVHBDjrnbtdqXs,'year':KwEivmyQCaTURufplVHBDjrnbtdqPz,'cast':KwEivmyQCaTURufplVHBDjrnbtdqPs,'director':KwEivmyQCaTURufplVHBDjrnbtdqPX,'genre':KwEivmyQCaTURufplVHBDjrnbtdqPO,'duration':KwEivmyQCaTURufplVHBDjrnbtdqXA,'premiered':KwEivmyQCaTURufplVHBDjrnbtdqPx,'studio':KwEivmyQCaTURufplVHBDjrnbtdqXO,'mpaa':KwEivmyQCaTURufplVHBDjrnbtdqPY,'plot':KwEivmyQCaTURufplVHBDjrnbtdqPG}
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'MOVIE','mediacode':KwEivmyQCaTURufplVHBDjrnbtdqXx.get('moviecode'),'stype':'movie','title':KwEivmyQCaTURufplVHBDjrnbtdqWL,'thumbnail':KwEivmyQCaTURufplVHBDjrnbtdqsN}
   if KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_makebookmark():
    KwEivmyQCaTURufplVHBDjrnbtdqPJ={'videoid':KwEivmyQCaTURufplVHBDjrnbtdqXx.get('moviecode'),'vidtype':'movie','vtitle':KwEivmyQCaTURufplVHBDjrnbtdqXs,'vsubtitle':'',}
    KwEivmyQCaTURufplVHBDjrnbtdqPe=json.dumps(KwEivmyQCaTURufplVHBDjrnbtdqPJ)
    KwEivmyQCaTURufplVHBDjrnbtdqPe=urllib.parse.quote(KwEivmyQCaTURufplVHBDjrnbtdqPe)
    KwEivmyQCaTURufplVHBDjrnbtdqPM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(KwEivmyQCaTURufplVHBDjrnbtdqPe)
    KwEivmyQCaTURufplVHBDjrnbtdqPS=[('(통합) 찜 영상에 추가',KwEivmyQCaTURufplVHBDjrnbtdqPM)]
   else:
    KwEivmyQCaTURufplVHBDjrnbtdqPS=KwEivmyQCaTURufplVHBDjrnbtdqYM
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel='',img=KwEivmyQCaTURufplVHBDjrnbtdqsN,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqPA,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYk,params=KwEivmyQCaTURufplVHBDjrnbtdqsW,ContextMenu=KwEivmyQCaTURufplVHBDjrnbtdqPS)
  if KwEivmyQCaTURufplVHBDjrnbtdqsh:
   KwEivmyQCaTURufplVHBDjrnbtdqsW={}
   KwEivmyQCaTURufplVHBDjrnbtdqsW['mode'] ='4K_MOVIE' 
   KwEivmyQCaTURufplVHBDjrnbtdqsW['page'] =KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqWL='[B]%s >>[/B]'%'다음 페이지'
   KwEivmyQCaTURufplVHBDjrnbtdqPg=KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqsG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqPg,img=KwEivmyQCaTURufplVHBDjrnbtdqsG,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqYM,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  xbmcplugin.setContent(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,'movies')
  xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,cacheToDisc=KwEivmyQCaTURufplVHBDjrnbtdqYk)
 def dp_Set_Bookmark(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqXg=urllib.parse.unquote(KwEivmyQCaTURufplVHBDjrnbtdqse.get('bm_param'))
  KwEivmyQCaTURufplVHBDjrnbtdqXg=json.loads(KwEivmyQCaTURufplVHBDjrnbtdqXg)
  KwEivmyQCaTURufplVHBDjrnbtdqXF =KwEivmyQCaTURufplVHBDjrnbtdqXg.get('videoid')
  KwEivmyQCaTURufplVHBDjrnbtdqXc =KwEivmyQCaTURufplVHBDjrnbtdqXg.get('vidtype')
  KwEivmyQCaTURufplVHBDjrnbtdqXI =KwEivmyQCaTURufplVHBDjrnbtdqXg.get('vtitle')
  KwEivmyQCaTURufplVHBDjrnbtdqXo =KwEivmyQCaTURufplVHBDjrnbtdqXg.get('vsubtitle')
  KwEivmyQCaTURufplVHBDjrnbtdqGe=xbmcgui.Dialog()
  KwEivmyQCaTURufplVHBDjrnbtdqsF=KwEivmyQCaTURufplVHBDjrnbtdqGe.yesno(__language__(30913).encode('utf8'),KwEivmyQCaTURufplVHBDjrnbtdqXI+' \n\n'+__language__(30914))
  if KwEivmyQCaTURufplVHBDjrnbtdqsF==KwEivmyQCaTURufplVHBDjrnbtdqYk:return
  KwEivmyQCaTURufplVHBDjrnbtdqXL=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.GetBookmarkInfo(KwEivmyQCaTURufplVHBDjrnbtdqXF,KwEivmyQCaTURufplVHBDjrnbtdqXc)
  if KwEivmyQCaTURufplVHBDjrnbtdqXo!='':
   KwEivmyQCaTURufplVHBDjrnbtdqXL['saveinfo']['subtitle']=KwEivmyQCaTURufplVHBDjrnbtdqXo 
   if KwEivmyQCaTURufplVHBDjrnbtdqXc=='tvshow':KwEivmyQCaTURufplVHBDjrnbtdqXL['saveinfo']['infoLabels']['studio']=KwEivmyQCaTURufplVHBDjrnbtdqXo 
  KwEivmyQCaTURufplVHBDjrnbtdqXJ=json.dumps(KwEivmyQCaTURufplVHBDjrnbtdqXL)
  KwEivmyQCaTURufplVHBDjrnbtdqXJ=urllib.parse.quote(KwEivmyQCaTURufplVHBDjrnbtdqXJ)
  KwEivmyQCaTURufplVHBDjrnbtdqPM ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(KwEivmyQCaTURufplVHBDjrnbtdqXJ)
  xbmc.executebuiltin(KwEivmyQCaTURufplVHBDjrnbtdqPM)
 def dp_Search_Group(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  if 'search_key' in KwEivmyQCaTURufplVHBDjrnbtdqse:
   KwEivmyQCaTURufplVHBDjrnbtdqXe=KwEivmyQCaTURufplVHBDjrnbtdqse.get('search_key')
  else:
   KwEivmyQCaTURufplVHBDjrnbtdqXe=KwEivmyQCaTURufplVHBDjrnbtdqGc.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not KwEivmyQCaTURufplVHBDjrnbtdqXe:
    return
  for KwEivmyQCaTURufplVHBDjrnbtdqsJ in KwEivmyQCaTURufplVHBDjrnbtdqGO:
   KwEivmyQCaTURufplVHBDjrnbtdqXM =KwEivmyQCaTURufplVHBDjrnbtdqsJ.get('mode')
   KwEivmyQCaTURufplVHBDjrnbtdqso=KwEivmyQCaTURufplVHBDjrnbtdqsJ.get('stype')
   KwEivmyQCaTURufplVHBDjrnbtdqWL=KwEivmyQCaTURufplVHBDjrnbtdqsJ.get('title')
   (KwEivmyQCaTURufplVHBDjrnbtdqXS,KwEivmyQCaTURufplVHBDjrnbtdqsh)=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.GetSearchList(KwEivmyQCaTURufplVHBDjrnbtdqXe,1,KwEivmyQCaTURufplVHBDjrnbtdqso)
   KwEivmyQCaTURufplVHBDjrnbtdqsO={'plot':'검색어 : '+KwEivmyQCaTURufplVHBDjrnbtdqXe+'\n\n'+KwEivmyQCaTURufplVHBDjrnbtdqGc.Search_FreeList(KwEivmyQCaTURufplVHBDjrnbtdqXS)}
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':KwEivmyQCaTURufplVHBDjrnbtdqXM,'stype':KwEivmyQCaTURufplVHBDjrnbtdqso,'search_key':KwEivmyQCaTURufplVHBDjrnbtdqXe,'page':'1',}
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel='',img='',infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqsO,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  if KwEivmyQCaTURufplVHBDjrnbtdqxP(KwEivmyQCaTURufplVHBDjrnbtdqGO)>0:xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,cacheToDisc=KwEivmyQCaTURufplVHBDjrnbtdqYh)
  KwEivmyQCaTURufplVHBDjrnbtdqGc.Save_Searched_List(KwEivmyQCaTURufplVHBDjrnbtdqXe)
 def Search_FreeList(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqOz):
  KwEivmyQCaTURufplVHBDjrnbtdqXh=''
  KwEivmyQCaTURufplVHBDjrnbtdqXk=7
  try:
   if KwEivmyQCaTURufplVHBDjrnbtdqxP(KwEivmyQCaTURufplVHBDjrnbtdqOz)==0:return '검색결과 없음'
   for i in KwEivmyQCaTURufplVHBDjrnbtdqxO(KwEivmyQCaTURufplVHBDjrnbtdqxP(KwEivmyQCaTURufplVHBDjrnbtdqOz)):
    if i>=KwEivmyQCaTURufplVHBDjrnbtdqXk:
     KwEivmyQCaTURufplVHBDjrnbtdqXh=KwEivmyQCaTURufplVHBDjrnbtdqXh+'...'
     break
    KwEivmyQCaTURufplVHBDjrnbtdqXh=KwEivmyQCaTURufplVHBDjrnbtdqXh+KwEivmyQCaTURufplVHBDjrnbtdqOz[i]['title']+'\n'
  except:
   return ''
  return KwEivmyQCaTURufplVHBDjrnbtdqXh
 def dp_Search_History(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqXN=KwEivmyQCaTURufplVHBDjrnbtdqGc.Load_List_File('search')
  for KwEivmyQCaTURufplVHBDjrnbtdqOG in KwEivmyQCaTURufplVHBDjrnbtdqXN:
   KwEivmyQCaTURufplVHBDjrnbtdqOW=KwEivmyQCaTURufplVHBDjrnbtdqxG(urllib.parse.parse_qsl(KwEivmyQCaTURufplVHBDjrnbtdqOG))
   KwEivmyQCaTURufplVHBDjrnbtdqOs=KwEivmyQCaTURufplVHBDjrnbtdqOW.get('skey').strip()
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'SEARCH_GROUP','search_key':KwEivmyQCaTURufplVHBDjrnbtdqOs,}
   KwEivmyQCaTURufplVHBDjrnbtdqOP={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':KwEivmyQCaTURufplVHBDjrnbtdqOs,'vType':'-',}
   KwEivmyQCaTURufplVHBDjrnbtdqOX=urllib.parse.urlencode(KwEivmyQCaTURufplVHBDjrnbtdqOP)
   KwEivmyQCaTURufplVHBDjrnbtdqPS=[('선택된 검색어 ( %s ) 삭제'%(KwEivmyQCaTURufplVHBDjrnbtdqOs),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(KwEivmyQCaTURufplVHBDjrnbtdqOX))]
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqOs,sublabel='',img=KwEivmyQCaTURufplVHBDjrnbtdqYM,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqYM,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW,ContextMenu=KwEivmyQCaTURufplVHBDjrnbtdqPS)
  KwEivmyQCaTURufplVHBDjrnbtdqPA={'plot':'검색목록 전체를 삭제합니다.'}
  KwEivmyQCaTURufplVHBDjrnbtdqWL='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  KwEivmyQCaTURufplVHBDjrnbtdqsG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel='',img=KwEivmyQCaTURufplVHBDjrnbtdqsG,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqPA,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYk,params=KwEivmyQCaTURufplVHBDjrnbtdqsW,isLink=KwEivmyQCaTURufplVHBDjrnbtdqYh)
  xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,cacheToDisc=KwEivmyQCaTURufplVHBDjrnbtdqYk)
 def dp_Search_List(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqsM =KwEivmyQCaTURufplVHBDjrnbtdqYS(KwEivmyQCaTURufplVHBDjrnbtdqse.get('page'))
  KwEivmyQCaTURufplVHBDjrnbtdqso =KwEivmyQCaTURufplVHBDjrnbtdqse.get('stype')
  if 'search_key' in KwEivmyQCaTURufplVHBDjrnbtdqse:
   KwEivmyQCaTURufplVHBDjrnbtdqXe=KwEivmyQCaTURufplVHBDjrnbtdqse.get('search_key')
  else:
   KwEivmyQCaTURufplVHBDjrnbtdqXe=KwEivmyQCaTURufplVHBDjrnbtdqGc.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not KwEivmyQCaTURufplVHBDjrnbtdqXe:
    xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle)
    return
  KwEivmyQCaTURufplVHBDjrnbtdqXS,KwEivmyQCaTURufplVHBDjrnbtdqsh=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.GetSearchList(KwEivmyQCaTURufplVHBDjrnbtdqXe,KwEivmyQCaTURufplVHBDjrnbtdqsM,KwEivmyQCaTURufplVHBDjrnbtdqso)
  for KwEivmyQCaTURufplVHBDjrnbtdqOz in KwEivmyQCaTURufplVHBDjrnbtdqXS:
   KwEivmyQCaTURufplVHBDjrnbtdqWL =KwEivmyQCaTURufplVHBDjrnbtdqOz.get('title')
   KwEivmyQCaTURufplVHBDjrnbtdqsN =KwEivmyQCaTURufplVHBDjrnbtdqOz.get('thumbnail')
   KwEivmyQCaTURufplVHBDjrnbtdqPG =KwEivmyQCaTURufplVHBDjrnbtdqOz.get('synopsis')
   KwEivmyQCaTURufplVHBDjrnbtdqOY =KwEivmyQCaTURufplVHBDjrnbtdqOz.get('program')
   KwEivmyQCaTURufplVHBDjrnbtdqPs =KwEivmyQCaTURufplVHBDjrnbtdqOz.get('cast')
   KwEivmyQCaTURufplVHBDjrnbtdqPX =KwEivmyQCaTURufplVHBDjrnbtdqOz.get('director')
   KwEivmyQCaTURufplVHBDjrnbtdqPO=KwEivmyQCaTURufplVHBDjrnbtdqOz.get('info_genre')
   KwEivmyQCaTURufplVHBDjrnbtdqXA =KwEivmyQCaTURufplVHBDjrnbtdqOz.get('duration')
   KwEivmyQCaTURufplVHBDjrnbtdqPY =KwEivmyQCaTURufplVHBDjrnbtdqOz.get('mpaa')
   KwEivmyQCaTURufplVHBDjrnbtdqPz =KwEivmyQCaTURufplVHBDjrnbtdqOz.get('year')
   KwEivmyQCaTURufplVHBDjrnbtdqXP =KwEivmyQCaTURufplVHBDjrnbtdqOz.get('aired')
   KwEivmyQCaTURufplVHBDjrnbtdqPA={'mediatype':'tvshow' if KwEivmyQCaTURufplVHBDjrnbtdqso=='vod' else 'movie','title':KwEivmyQCaTURufplVHBDjrnbtdqWL,'cast':KwEivmyQCaTURufplVHBDjrnbtdqPs,'director':KwEivmyQCaTURufplVHBDjrnbtdqPX,'genre':KwEivmyQCaTURufplVHBDjrnbtdqPO,'duration':KwEivmyQCaTURufplVHBDjrnbtdqXA,'mpaa':KwEivmyQCaTURufplVHBDjrnbtdqPY,'year':KwEivmyQCaTURufplVHBDjrnbtdqPz,'aired':KwEivmyQCaTURufplVHBDjrnbtdqXP,'plot':'%s\n\n%s'%(KwEivmyQCaTURufplVHBDjrnbtdqWL,KwEivmyQCaTURufplVHBDjrnbtdqPG)}
   if KwEivmyQCaTURufplVHBDjrnbtdqso=='vod':
    KwEivmyQCaTURufplVHBDjrnbtdqXF=KwEivmyQCaTURufplVHBDjrnbtdqOz.get('program')
    KwEivmyQCaTURufplVHBDjrnbtdqXc='tvshow'
    KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'EPISODE','programcode':KwEivmyQCaTURufplVHBDjrnbtdqXF,'page':'1',}
    KwEivmyQCaTURufplVHBDjrnbtdqsP=KwEivmyQCaTURufplVHBDjrnbtdqYh
   else:
    KwEivmyQCaTURufplVHBDjrnbtdqXF=KwEivmyQCaTURufplVHBDjrnbtdqOz.get('movie')
    KwEivmyQCaTURufplVHBDjrnbtdqXc='movie'
    KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'MOVIE','mediacode':KwEivmyQCaTURufplVHBDjrnbtdqXF,'stype':'movie','title':KwEivmyQCaTURufplVHBDjrnbtdqWL,'thumbnail':KwEivmyQCaTURufplVHBDjrnbtdqsN,}
    KwEivmyQCaTURufplVHBDjrnbtdqsP=KwEivmyQCaTURufplVHBDjrnbtdqYk
   if KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_makebookmark():
    KwEivmyQCaTURufplVHBDjrnbtdqPJ={'videoid':KwEivmyQCaTURufplVHBDjrnbtdqXF,'vidtype':KwEivmyQCaTURufplVHBDjrnbtdqXc,'vtitle':KwEivmyQCaTURufplVHBDjrnbtdqWL,'vsubtitle':'',}
    KwEivmyQCaTURufplVHBDjrnbtdqPe=json.dumps(KwEivmyQCaTURufplVHBDjrnbtdqPJ)
    KwEivmyQCaTURufplVHBDjrnbtdqPe=urllib.parse.quote(KwEivmyQCaTURufplVHBDjrnbtdqPe)
    KwEivmyQCaTURufplVHBDjrnbtdqPM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(KwEivmyQCaTURufplVHBDjrnbtdqPe)
    KwEivmyQCaTURufplVHBDjrnbtdqPS=[('(통합) 찜 영상에 추가',KwEivmyQCaTURufplVHBDjrnbtdqPM)]
   else:
    KwEivmyQCaTURufplVHBDjrnbtdqPS=KwEivmyQCaTURufplVHBDjrnbtdqYM
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel='',img=KwEivmyQCaTURufplVHBDjrnbtdqsN,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqPA,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqsP,params=KwEivmyQCaTURufplVHBDjrnbtdqsW,isLink=KwEivmyQCaTURufplVHBDjrnbtdqYk,ContextMenu=KwEivmyQCaTURufplVHBDjrnbtdqPS)
  if KwEivmyQCaTURufplVHBDjrnbtdqsh:
   KwEivmyQCaTURufplVHBDjrnbtdqsW['mode'] ='SEARCH' 
   KwEivmyQCaTURufplVHBDjrnbtdqsW['search_key']=KwEivmyQCaTURufplVHBDjrnbtdqXe
   KwEivmyQCaTURufplVHBDjrnbtdqsW['page'] =KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqWL='[B]%s >>[/B]'%'다음 페이지'
   KwEivmyQCaTURufplVHBDjrnbtdqPg=KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqsM+1)
   KwEivmyQCaTURufplVHBDjrnbtdqsG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqPg,img=KwEivmyQCaTURufplVHBDjrnbtdqsG,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqYM,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  if KwEivmyQCaTURufplVHBDjrnbtdqso=='movie':xbmcplugin.setContent(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,'movies')
  else:xbmcplugin.setContent(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,cacheToDisc=KwEivmyQCaTURufplVHBDjrnbtdqYk)
 def dp_History_Remove(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqOx=KwEivmyQCaTURufplVHBDjrnbtdqse.get('delType')
  KwEivmyQCaTURufplVHBDjrnbtdqOA =KwEivmyQCaTURufplVHBDjrnbtdqse.get('sKey')
  KwEivmyQCaTURufplVHBDjrnbtdqOg =KwEivmyQCaTURufplVHBDjrnbtdqse.get('vType')
  KwEivmyQCaTURufplVHBDjrnbtdqGe=xbmcgui.Dialog()
  if KwEivmyQCaTURufplVHBDjrnbtdqOx=='SEARCH_ALL':
   KwEivmyQCaTURufplVHBDjrnbtdqsF=KwEivmyQCaTURufplVHBDjrnbtdqGe.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif KwEivmyQCaTURufplVHBDjrnbtdqOx=='SEARCH_ONE':
   KwEivmyQCaTURufplVHBDjrnbtdqsF=KwEivmyQCaTURufplVHBDjrnbtdqGe.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif KwEivmyQCaTURufplVHBDjrnbtdqOx=='WATCH_ALL':
   KwEivmyQCaTURufplVHBDjrnbtdqsF=KwEivmyQCaTURufplVHBDjrnbtdqGe.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif KwEivmyQCaTURufplVHBDjrnbtdqOx=='WATCH_ONE':
   KwEivmyQCaTURufplVHBDjrnbtdqsF=KwEivmyQCaTURufplVHBDjrnbtdqGe.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if KwEivmyQCaTURufplVHBDjrnbtdqsF==KwEivmyQCaTURufplVHBDjrnbtdqYk:sys.exit()
  if KwEivmyQCaTURufplVHBDjrnbtdqOx=='SEARCH_ALL':
   if os.path.isfile(KwEivmyQCaTURufplVHBDjrnbtdqGF):os.remove(KwEivmyQCaTURufplVHBDjrnbtdqGF)
  elif KwEivmyQCaTURufplVHBDjrnbtdqOx=='SEARCH_ONE':
   try:
    KwEivmyQCaTURufplVHBDjrnbtdqOF=KwEivmyQCaTURufplVHBDjrnbtdqGF
    KwEivmyQCaTURufplVHBDjrnbtdqOc=KwEivmyQCaTURufplVHBDjrnbtdqGc.Load_List_File('search') 
    fp=KwEivmyQCaTURufplVHBDjrnbtdqxz(KwEivmyQCaTURufplVHBDjrnbtdqOF,'w',-1,'utf-8')
    for KwEivmyQCaTURufplVHBDjrnbtdqOI in KwEivmyQCaTURufplVHBDjrnbtdqOc:
     KwEivmyQCaTURufplVHBDjrnbtdqOo=KwEivmyQCaTURufplVHBDjrnbtdqxG(urllib.parse.parse_qsl(KwEivmyQCaTURufplVHBDjrnbtdqOI))
     KwEivmyQCaTURufplVHBDjrnbtdqOL=KwEivmyQCaTURufplVHBDjrnbtdqOo.get('skey').strip()
     if KwEivmyQCaTURufplVHBDjrnbtdqOA!=KwEivmyQCaTURufplVHBDjrnbtdqOL:
      fp.write(KwEivmyQCaTURufplVHBDjrnbtdqOI)
    fp.close()
   except:
    KwEivmyQCaTURufplVHBDjrnbtdqYM
  elif KwEivmyQCaTURufplVHBDjrnbtdqOx=='WATCH_ALL':
   KwEivmyQCaTURufplVHBDjrnbtdqOF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%KwEivmyQCaTURufplVHBDjrnbtdqOg))
   if os.path.isfile(KwEivmyQCaTURufplVHBDjrnbtdqOF):os.remove(KwEivmyQCaTURufplVHBDjrnbtdqOF)
  elif KwEivmyQCaTURufplVHBDjrnbtdqOx=='WATCH_ONE':
   KwEivmyQCaTURufplVHBDjrnbtdqOF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%KwEivmyQCaTURufplVHBDjrnbtdqOg))
   try:
    KwEivmyQCaTURufplVHBDjrnbtdqOc=KwEivmyQCaTURufplVHBDjrnbtdqGc.Load_List_File(KwEivmyQCaTURufplVHBDjrnbtdqOg) 
    fp=KwEivmyQCaTURufplVHBDjrnbtdqxz(KwEivmyQCaTURufplVHBDjrnbtdqOF,'w',-1,'utf-8')
    for KwEivmyQCaTURufplVHBDjrnbtdqOI in KwEivmyQCaTURufplVHBDjrnbtdqOc:
     KwEivmyQCaTURufplVHBDjrnbtdqOo=KwEivmyQCaTURufplVHBDjrnbtdqxG(urllib.parse.parse_qsl(KwEivmyQCaTURufplVHBDjrnbtdqOI))
     KwEivmyQCaTURufplVHBDjrnbtdqOL=KwEivmyQCaTURufplVHBDjrnbtdqOo.get('code').strip()
     if KwEivmyQCaTURufplVHBDjrnbtdqOA!=KwEivmyQCaTURufplVHBDjrnbtdqOL:
      fp.write(KwEivmyQCaTURufplVHBDjrnbtdqOI)
    fp.close()
   except:
    KwEivmyQCaTURufplVHBDjrnbtdqYM
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqso): 
  try:
   if KwEivmyQCaTURufplVHBDjrnbtdqso=='search':
    KwEivmyQCaTURufplVHBDjrnbtdqOF=KwEivmyQCaTURufplVHBDjrnbtdqGF
   elif KwEivmyQCaTURufplVHBDjrnbtdqso in['vod','movie']:
    KwEivmyQCaTURufplVHBDjrnbtdqOF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%KwEivmyQCaTURufplVHBDjrnbtdqso))
   else:
    return[]
   fp=KwEivmyQCaTURufplVHBDjrnbtdqxz(KwEivmyQCaTURufplVHBDjrnbtdqOF,'r',-1,'utf-8')
   KwEivmyQCaTURufplVHBDjrnbtdqOJ=fp.readlines()
   fp.close()
  except:
   KwEivmyQCaTURufplVHBDjrnbtdqOJ=[]
  return KwEivmyQCaTURufplVHBDjrnbtdqOJ
 def Save_Watched_List(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqso,KwEivmyQCaTURufplVHBDjrnbtdqGL):
  try:
   KwEivmyQCaTURufplVHBDjrnbtdqOe=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%KwEivmyQCaTURufplVHBDjrnbtdqso))
   KwEivmyQCaTURufplVHBDjrnbtdqOc=KwEivmyQCaTURufplVHBDjrnbtdqGc.Load_List_File(KwEivmyQCaTURufplVHBDjrnbtdqso) 
   fp=KwEivmyQCaTURufplVHBDjrnbtdqxz(KwEivmyQCaTURufplVHBDjrnbtdqOe,'w',-1,'utf-8')
   KwEivmyQCaTURufplVHBDjrnbtdqOM=urllib.parse.urlencode(KwEivmyQCaTURufplVHBDjrnbtdqGL)
   KwEivmyQCaTURufplVHBDjrnbtdqOM=KwEivmyQCaTURufplVHBDjrnbtdqOM+'\n'
   fp.write(KwEivmyQCaTURufplVHBDjrnbtdqOM)
   KwEivmyQCaTURufplVHBDjrnbtdqOS=0
   for KwEivmyQCaTURufplVHBDjrnbtdqOI in KwEivmyQCaTURufplVHBDjrnbtdqOc:
    KwEivmyQCaTURufplVHBDjrnbtdqOo=KwEivmyQCaTURufplVHBDjrnbtdqxG(urllib.parse.parse_qsl(KwEivmyQCaTURufplVHBDjrnbtdqOI))
    KwEivmyQCaTURufplVHBDjrnbtdqOh=KwEivmyQCaTURufplVHBDjrnbtdqGL.get('code').strip()
    KwEivmyQCaTURufplVHBDjrnbtdqOk=KwEivmyQCaTURufplVHBDjrnbtdqOo.get('code').strip()
    if KwEivmyQCaTURufplVHBDjrnbtdqso=='vod' and KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_direct_replay()==KwEivmyQCaTURufplVHBDjrnbtdqYh:
     KwEivmyQCaTURufplVHBDjrnbtdqOh=KwEivmyQCaTURufplVHBDjrnbtdqGL.get('videoid').strip()
     KwEivmyQCaTURufplVHBDjrnbtdqOk=KwEivmyQCaTURufplVHBDjrnbtdqOo.get('videoid').strip()if KwEivmyQCaTURufplVHBDjrnbtdqOk!=KwEivmyQCaTURufplVHBDjrnbtdqYM else '-'
    if KwEivmyQCaTURufplVHBDjrnbtdqOh!=KwEivmyQCaTURufplVHBDjrnbtdqOk:
     fp.write(KwEivmyQCaTURufplVHBDjrnbtdqOI)
     KwEivmyQCaTURufplVHBDjrnbtdqOS+=1
     if KwEivmyQCaTURufplVHBDjrnbtdqOS>=50:break
   fp.close()
  except:
   KwEivmyQCaTURufplVHBDjrnbtdqYM
 def dp_Watch_List(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqso =KwEivmyQCaTURufplVHBDjrnbtdqse.get('stype')
  KwEivmyQCaTURufplVHBDjrnbtdqWF=KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_direct_replay()
  if KwEivmyQCaTURufplVHBDjrnbtdqso=='-':
   for KwEivmyQCaTURufplVHBDjrnbtdqsJ in KwEivmyQCaTURufplVHBDjrnbtdqGX:
    KwEivmyQCaTURufplVHBDjrnbtdqWL=KwEivmyQCaTURufplVHBDjrnbtdqsJ.get('title')
    KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':KwEivmyQCaTURufplVHBDjrnbtdqsJ.get('mode'),'stype':KwEivmyQCaTURufplVHBDjrnbtdqsJ.get('stype')}
    KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel='',img='',infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqYM,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYh,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
   if KwEivmyQCaTURufplVHBDjrnbtdqxP(KwEivmyQCaTURufplVHBDjrnbtdqGX)>0:xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle)
  else:
   KwEivmyQCaTURufplVHBDjrnbtdqON=KwEivmyQCaTURufplVHBDjrnbtdqGc.Load_List_File(KwEivmyQCaTURufplVHBDjrnbtdqso)
   for KwEivmyQCaTURufplVHBDjrnbtdqzG in KwEivmyQCaTURufplVHBDjrnbtdqON:
    KwEivmyQCaTURufplVHBDjrnbtdqOW=KwEivmyQCaTURufplVHBDjrnbtdqxG(urllib.parse.parse_qsl(KwEivmyQCaTURufplVHBDjrnbtdqzG))
    KwEivmyQCaTURufplVHBDjrnbtdqzW =KwEivmyQCaTURufplVHBDjrnbtdqOW.get('code').strip()
    KwEivmyQCaTURufplVHBDjrnbtdqWL =KwEivmyQCaTURufplVHBDjrnbtdqOW.get('title').strip()
    KwEivmyQCaTURufplVHBDjrnbtdqsN=KwEivmyQCaTURufplVHBDjrnbtdqOW.get('img').strip()
    KwEivmyQCaTURufplVHBDjrnbtdqXF =KwEivmyQCaTURufplVHBDjrnbtdqOW.get('videoid').strip()
    try:
     KwEivmyQCaTURufplVHBDjrnbtdqsN=KwEivmyQCaTURufplVHBDjrnbtdqsN.replace('\'','\"')
     KwEivmyQCaTURufplVHBDjrnbtdqsN=json.loads(KwEivmyQCaTURufplVHBDjrnbtdqsN)
    except:
     KwEivmyQCaTURufplVHBDjrnbtdqYM
    KwEivmyQCaTURufplVHBDjrnbtdqPA={}
    KwEivmyQCaTURufplVHBDjrnbtdqPA['plot']=KwEivmyQCaTURufplVHBDjrnbtdqWL
    if KwEivmyQCaTURufplVHBDjrnbtdqso=='vod':
     if KwEivmyQCaTURufplVHBDjrnbtdqWF==KwEivmyQCaTURufplVHBDjrnbtdqYk or KwEivmyQCaTURufplVHBDjrnbtdqXF==KwEivmyQCaTURufplVHBDjrnbtdqYM:
      KwEivmyQCaTURufplVHBDjrnbtdqPA['mediatype']='tvshow'
      KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'EPISODE','programcode':KwEivmyQCaTURufplVHBDjrnbtdqzW,'page':'1'}
      KwEivmyQCaTURufplVHBDjrnbtdqsP=KwEivmyQCaTURufplVHBDjrnbtdqYh
     else:
      KwEivmyQCaTURufplVHBDjrnbtdqPA['mediatype']='episode'
      KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'VOD','mediacode':KwEivmyQCaTURufplVHBDjrnbtdqXF,'stype':'vod','programcode':KwEivmyQCaTURufplVHBDjrnbtdqzW,'title':KwEivmyQCaTURufplVHBDjrnbtdqWL,'thumbnail':KwEivmyQCaTURufplVHBDjrnbtdqsN}
      KwEivmyQCaTURufplVHBDjrnbtdqsP=KwEivmyQCaTURufplVHBDjrnbtdqYk
    else:
     KwEivmyQCaTURufplVHBDjrnbtdqPA['mediatype']='movie'
     KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'MOVIE','mediacode':KwEivmyQCaTURufplVHBDjrnbtdqzW,'stype':'movie','title':KwEivmyQCaTURufplVHBDjrnbtdqWL,'thumbnail':KwEivmyQCaTURufplVHBDjrnbtdqsN}
     KwEivmyQCaTURufplVHBDjrnbtdqsP=KwEivmyQCaTURufplVHBDjrnbtdqYk
    KwEivmyQCaTURufplVHBDjrnbtdqOP={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':KwEivmyQCaTURufplVHBDjrnbtdqzW,'vType':KwEivmyQCaTURufplVHBDjrnbtdqso,}
    KwEivmyQCaTURufplVHBDjrnbtdqOX=urllib.parse.urlencode(KwEivmyQCaTURufplVHBDjrnbtdqOP)
    KwEivmyQCaTURufplVHBDjrnbtdqPS=[('선택된 시청이력 ( %s ) 삭제'%(KwEivmyQCaTURufplVHBDjrnbtdqWL),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(KwEivmyQCaTURufplVHBDjrnbtdqOX))]
    KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel='',img=KwEivmyQCaTURufplVHBDjrnbtdqsN,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqPA,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqsP,params=KwEivmyQCaTURufplVHBDjrnbtdqsW,ContextMenu=KwEivmyQCaTURufplVHBDjrnbtdqPS)
   KwEivmyQCaTURufplVHBDjrnbtdqPA={'plot':'시청목록을 삭제합니다.'}
   KwEivmyQCaTURufplVHBDjrnbtdqWL='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':KwEivmyQCaTURufplVHBDjrnbtdqso,}
   KwEivmyQCaTURufplVHBDjrnbtdqsG=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel='',img=KwEivmyQCaTURufplVHBDjrnbtdqsG,infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqPA,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYk,params=KwEivmyQCaTURufplVHBDjrnbtdqsW,isLink=KwEivmyQCaTURufplVHBDjrnbtdqYh)
   if KwEivmyQCaTURufplVHBDjrnbtdqso=='movie':xbmcplugin.setContent(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,'movies')
   else:xbmcplugin.setContent(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,cacheToDisc=KwEivmyQCaTURufplVHBDjrnbtdqYk)
 def Save_Searched_List(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqXe):
  try:
   KwEivmyQCaTURufplVHBDjrnbtdqzs=KwEivmyQCaTURufplVHBDjrnbtdqGF
   KwEivmyQCaTURufplVHBDjrnbtdqOc=KwEivmyQCaTURufplVHBDjrnbtdqGc.Load_List_File('search') 
   KwEivmyQCaTURufplVHBDjrnbtdqzP={'skey':KwEivmyQCaTURufplVHBDjrnbtdqXe.strip()}
   fp=KwEivmyQCaTURufplVHBDjrnbtdqxz(KwEivmyQCaTURufplVHBDjrnbtdqzs,'w',-1,'utf-8')
   KwEivmyQCaTURufplVHBDjrnbtdqOM=urllib.parse.urlencode(KwEivmyQCaTURufplVHBDjrnbtdqzP)
   KwEivmyQCaTURufplVHBDjrnbtdqOM=KwEivmyQCaTURufplVHBDjrnbtdqOM+'\n'
   fp.write(KwEivmyQCaTURufplVHBDjrnbtdqOM)
   KwEivmyQCaTURufplVHBDjrnbtdqOS=0
   for KwEivmyQCaTURufplVHBDjrnbtdqOI in KwEivmyQCaTURufplVHBDjrnbtdqOc:
    KwEivmyQCaTURufplVHBDjrnbtdqOo=KwEivmyQCaTURufplVHBDjrnbtdqxG(urllib.parse.parse_qsl(KwEivmyQCaTURufplVHBDjrnbtdqOI))
    KwEivmyQCaTURufplVHBDjrnbtdqOh=KwEivmyQCaTURufplVHBDjrnbtdqzP.get('skey').strip()
    KwEivmyQCaTURufplVHBDjrnbtdqOk=KwEivmyQCaTURufplVHBDjrnbtdqOo.get('skey').strip()
    if KwEivmyQCaTURufplVHBDjrnbtdqOh!=KwEivmyQCaTURufplVHBDjrnbtdqOk:
     fp.write(KwEivmyQCaTURufplVHBDjrnbtdqOI)
     KwEivmyQCaTURufplVHBDjrnbtdqOS+=1
     if KwEivmyQCaTURufplVHBDjrnbtdqOS>=50:break
   fp.close()
  except:
   KwEivmyQCaTURufplVHBDjrnbtdqYM
 def play_VIDEO(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqzX =KwEivmyQCaTURufplVHBDjrnbtdqse.get('mediacode')
  KwEivmyQCaTURufplVHBDjrnbtdqso =KwEivmyQCaTURufplVHBDjrnbtdqse.get('stype')
  KwEivmyQCaTURufplVHBDjrnbtdqzO =KwEivmyQCaTURufplVHBDjrnbtdqse.get('pvrmode')
  KwEivmyQCaTURufplVHBDjrnbtdqzY=KwEivmyQCaTURufplVHBDjrnbtdqGc.get_selQuality(KwEivmyQCaTURufplVHBDjrnbtdqso)
  KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(KwEivmyQCaTURufplVHBDjrnbtdqzX,KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqzY),KwEivmyQCaTURufplVHBDjrnbtdqso,KwEivmyQCaTURufplVHBDjrnbtdqzO))
  KwEivmyQCaTURufplVHBDjrnbtdqzx=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.GetBroadURL(KwEivmyQCaTURufplVHBDjrnbtdqzX,KwEivmyQCaTURufplVHBDjrnbtdqzY,KwEivmyQCaTURufplVHBDjrnbtdqso,KwEivmyQCaTURufplVHBDjrnbtdqzO,optUHD=KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_uhd())
  KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_log('qt, stype, url : %s - %s - %s'%(KwEivmyQCaTURufplVHBDjrnbtdqxX(KwEivmyQCaTURufplVHBDjrnbtdqzY),KwEivmyQCaTURufplVHBDjrnbtdqso,KwEivmyQCaTURufplVHBDjrnbtdqzx['streaming_url']))
  if KwEivmyQCaTURufplVHBDjrnbtdqzx['streaming_url']=='':
   if KwEivmyQCaTURufplVHBDjrnbtdqzx['error_msg']=='':
    KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_noti(__language__(30908).encode('utf8'))
   else:
    KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_noti(KwEivmyQCaTURufplVHBDjrnbtdqzx['error_msg'].encode('utf8'))
   return
  KwEivmyQCaTURufplVHBDjrnbtdqzA='user-agent={}'.format(KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.USER_AGENT)
  if KwEivmyQCaTURufplVHBDjrnbtdqzx['watermark'] !='':
   KwEivmyQCaTURufplVHBDjrnbtdqzA='{}&x-tving-param1={}&x-tving-param2={}'.format(KwEivmyQCaTURufplVHBDjrnbtdqzA,KwEivmyQCaTURufplVHBDjrnbtdqzx['watermarkKey'],KwEivmyQCaTURufplVHBDjrnbtdqzx['watermark'])
  KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_log('streaming_url = {}'.format(KwEivmyQCaTURufplVHBDjrnbtdqzx['streaming_url']))
  KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_log('drm_license   = {}'.format(KwEivmyQCaTURufplVHBDjrnbtdqzx['drm_license']))
  KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_log('watermark     = {}'.format(KwEivmyQCaTURufplVHBDjrnbtdqzx['watermark']))
  KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_log('watermarkKey  = {}'.format(KwEivmyQCaTURufplVHBDjrnbtdqzx['watermarkKey']))
  KwEivmyQCaTURufplVHBDjrnbtdqzg =KwEivmyQCaTURufplVHBDjrnbtdqYk
  KwEivmyQCaTURufplVHBDjrnbtdqzF =KwEivmyQCaTURufplVHBDjrnbtdqzx['streaming_url'].find('Policy=')
  if KwEivmyQCaTURufplVHBDjrnbtdqzF!=-1:
   KwEivmyQCaTURufplVHBDjrnbtdqzc =KwEivmyQCaTURufplVHBDjrnbtdqzx['streaming_url'].split('?')[0]
   KwEivmyQCaTURufplVHBDjrnbtdqzI=KwEivmyQCaTURufplVHBDjrnbtdqxG(urllib.parse.parse_qsl(urllib.parse.urlsplit(KwEivmyQCaTURufplVHBDjrnbtdqzx['streaming_url']).query))
   KwEivmyQCaTURufplVHBDjrnbtdqzo='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(KwEivmyQCaTURufplVHBDjrnbtdqzI['Policy'],KwEivmyQCaTURufplVHBDjrnbtdqzI['Signature'],KwEivmyQCaTURufplVHBDjrnbtdqzI['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in KwEivmyQCaTURufplVHBDjrnbtdqzc:
    KwEivmyQCaTURufplVHBDjrnbtdqzg=KwEivmyQCaTURufplVHBDjrnbtdqYh
    KwEivmyQCaTURufplVHBDjrnbtdqzL =KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    KwEivmyQCaTURufplVHBDjrnbtdqzJ=KwEivmyQCaTURufplVHBDjrnbtdqzL.strftime('%Y-%m-%d-%H:%M:%S')
    if KwEivmyQCaTURufplVHBDjrnbtdqYS(KwEivmyQCaTURufplVHBDjrnbtdqzJ.replace('-','').replace(':',''))<KwEivmyQCaTURufplVHBDjrnbtdqYS(KwEivmyQCaTURufplVHBDjrnbtdqzI['end'].replace('-','').replace(':','')):
     KwEivmyQCaTURufplVHBDjrnbtdqzI['end']=KwEivmyQCaTURufplVHBDjrnbtdqzJ
     KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_noti(__language__(30915).encode('utf8'))
    KwEivmyQCaTURufplVHBDjrnbtdqzc ='%s?%s'%(KwEivmyQCaTURufplVHBDjrnbtdqzc,urllib.parse.urlencode(KwEivmyQCaTURufplVHBDjrnbtdqzI,doseq=KwEivmyQCaTURufplVHBDjrnbtdqYh))
    KwEivmyQCaTURufplVHBDjrnbtdqze='{}|{}&Cookie={}'.format(KwEivmyQCaTURufplVHBDjrnbtdqzc,KwEivmyQCaTURufplVHBDjrnbtdqzA,KwEivmyQCaTURufplVHBDjrnbtdqzo)
   else:
    KwEivmyQCaTURufplVHBDjrnbtdqze='{}|{}&Cookie={}'.format(KwEivmyQCaTURufplVHBDjrnbtdqzx['streaming_url'],KwEivmyQCaTURufplVHBDjrnbtdqzA,KwEivmyQCaTURufplVHBDjrnbtdqzo)
  else:
   KwEivmyQCaTURufplVHBDjrnbtdqze=KwEivmyQCaTURufplVHBDjrnbtdqzx['streaming_url']+'|'+KwEivmyQCaTURufplVHBDjrnbtdqzA
   KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_log('if tmp_pos == -1')
  KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_log(KwEivmyQCaTURufplVHBDjrnbtdqze)
  KwEivmyQCaTURufplVHBDjrnbtdqWX,KwEivmyQCaTURufplVHBDjrnbtdqWO=KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_proxyport()
  KwEivmyQCaTURufplVHBDjrnbtdqWP=KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_playback()
  KwEivmyQCaTURufplVHBDjrnbtdqzM=urllib.parse.urlparse(KwEivmyQCaTURufplVHBDjrnbtdqzx['streaming_url'])
  KwEivmyQCaTURufplVHBDjrnbtdqzM=KwEivmyQCaTURufplVHBDjrnbtdqzM.path.strip('/').split('/')
  KwEivmyQCaTURufplVHBDjrnbtdqzM=KwEivmyQCaTURufplVHBDjrnbtdqzM[KwEivmyQCaTURufplVHBDjrnbtdqxP(KwEivmyQCaTURufplVHBDjrnbtdqzM)-1] 
  if(KwEivmyQCaTURufplVHBDjrnbtdqWX and KwEivmyQCaTURufplVHBDjrnbtdqse.get('mode')in['VOD','MOVIE']and KwEivmyQCaTURufplVHBDjrnbtdqzg==KwEivmyQCaTURufplVHBDjrnbtdqYk and(KwEivmyQCaTURufplVHBDjrnbtdqzx['drm_license']!='' or KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.KodiVersion>=21)):
   if KwEivmyQCaTURufplVHBDjrnbtdqzM.split('.')[1]=='mpd':
    KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Tving_Parse_mpd(KwEivmyQCaTURufplVHBDjrnbtdqzx['streaming_url'],KwEivmyQCaTURufplVHBDjrnbtdqzx['watermarkKey'],KwEivmyQCaTURufplVHBDjrnbtdqzx['watermark'])
   else:
    KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Tving_Parse_m3u8(KwEivmyQCaTURufplVHBDjrnbtdqzx['streaming_url'])
   KwEivmyQCaTURufplVHBDjrnbtdqzS={'addon':'tvingm','playOption':KwEivmyQCaTURufplVHBDjrnbtdqWP,}
   KwEivmyQCaTURufplVHBDjrnbtdqzS=json.dumps(KwEivmyQCaTURufplVHBDjrnbtdqzS,separators=(',',':'))
   KwEivmyQCaTURufplVHBDjrnbtdqzS=base64.standard_b64encode(KwEivmyQCaTURufplVHBDjrnbtdqzS.encode()).decode('utf-8')
   KwEivmyQCaTURufplVHBDjrnbtdqze ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(KwEivmyQCaTURufplVHBDjrnbtdqWO,KwEivmyQCaTURufplVHBDjrnbtdqze,KwEivmyQCaTURufplVHBDjrnbtdqzS)
   KwEivmyQCaTURufplVHBDjrnbtdqzA='{}&proxy-mini={}'.format(KwEivmyQCaTURufplVHBDjrnbtdqzA,KwEivmyQCaTURufplVHBDjrnbtdqzS)
  KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_log(KwEivmyQCaTURufplVHBDjrnbtdqze)
  KwEivmyQCaTURufplVHBDjrnbtdqzh=xbmcgui.ListItem(path=KwEivmyQCaTURufplVHBDjrnbtdqze)
  if KwEivmyQCaTURufplVHBDjrnbtdqzx['drm_license']!='':
   KwEivmyQCaTURufplVHBDjrnbtdqzk=KwEivmyQCaTURufplVHBDjrnbtdqzx['drm_license']
   KwEivmyQCaTURufplVHBDjrnbtdqzN ='https://cj.drmkeyserver.com/widevine_license'
   KwEivmyQCaTURufplVHBDjrnbtdqYG ='mpd'
   KwEivmyQCaTURufplVHBDjrnbtdqYW ='com.widevine.alpha'
   KwEivmyQCaTURufplVHBDjrnbtdqYs =inputstreamhelper.Helper(KwEivmyQCaTURufplVHBDjrnbtdqYG,drm='widevine')
   if KwEivmyQCaTURufplVHBDjrnbtdqYs.check_inputstream():
    KwEivmyQCaTURufplVHBDjrnbtdqYP={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.USER_AGENT,'AcquireLicenseAssertion':KwEivmyQCaTURufplVHBDjrnbtdqzk,'Host':'cj.drmkeyserver.com',}
    KwEivmyQCaTURufplVHBDjrnbtdqYX=KwEivmyQCaTURufplVHBDjrnbtdqzN+'|'+urllib.parse.urlencode(KwEivmyQCaTURufplVHBDjrnbtdqYP)+'|R{SSM}|'
    KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('inputstream',KwEivmyQCaTURufplVHBDjrnbtdqYs.inputstream_addon)
    KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('inputstream.adaptive.manifest_type',KwEivmyQCaTURufplVHBDjrnbtdqYG)
    KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('inputstream.adaptive.license_type',KwEivmyQCaTURufplVHBDjrnbtdqYW)
    KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('inputstream.adaptive.license_key',KwEivmyQCaTURufplVHBDjrnbtdqYX)
    KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('inputstream.adaptive.stream_headers',KwEivmyQCaTURufplVHBDjrnbtdqzA)
  elif KwEivmyQCaTURufplVHBDjrnbtdqse.get('mode')in['VOD','MOVIE']:
   KwEivmyQCaTURufplVHBDjrnbtdqzh.setContentLookup(KwEivmyQCaTURufplVHBDjrnbtdqYk)
   KwEivmyQCaTURufplVHBDjrnbtdqzh.setMimeType('application/x-mpegURL')
   KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('inputstream','inputstream.adaptive')
   KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('inputstream.adaptive.manifest_type','hls')
   KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('inputstream.adaptive.stream_headers',KwEivmyQCaTURufplVHBDjrnbtdqzA)
  elif KwEivmyQCaTURufplVHBDjrnbtdqzg==KwEivmyQCaTURufplVHBDjrnbtdqYh:
   KwEivmyQCaTURufplVHBDjrnbtdqzh.setContentLookup(KwEivmyQCaTURufplVHBDjrnbtdqYk)
   KwEivmyQCaTURufplVHBDjrnbtdqzh.setMimeType('application/x-mpegURL')
   KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('inputstream','inputstream.ffmpegdirect')
   KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('ResumeTime','0')
   KwEivmyQCaTURufplVHBDjrnbtdqzh.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,KwEivmyQCaTURufplVHBDjrnbtdqYh,KwEivmyQCaTURufplVHBDjrnbtdqzh)
  try:
   if KwEivmyQCaTURufplVHBDjrnbtdqse.get('mode')in['VOD','MOVIE']and KwEivmyQCaTURufplVHBDjrnbtdqse.get('title'):
    KwEivmyQCaTURufplVHBDjrnbtdqsW={'code':KwEivmyQCaTURufplVHBDjrnbtdqse.get('programcode')if KwEivmyQCaTURufplVHBDjrnbtdqse.get('mode')=='VOD' else KwEivmyQCaTURufplVHBDjrnbtdqse.get('mediacode'),'img':KwEivmyQCaTURufplVHBDjrnbtdqse.get('thumbnail'),'title':KwEivmyQCaTURufplVHBDjrnbtdqse.get('title'),'videoid':KwEivmyQCaTURufplVHBDjrnbtdqse.get('mediacode')}
    KwEivmyQCaTURufplVHBDjrnbtdqGc.Save_Watched_List(KwEivmyQCaTURufplVHBDjrnbtdqse.get('stype'),KwEivmyQCaTURufplVHBDjrnbtdqsW)
  except:
   KwEivmyQCaTURufplVHBDjrnbtdqYM
 def logout(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  KwEivmyQCaTURufplVHBDjrnbtdqGe=xbmcgui.Dialog()
  KwEivmyQCaTURufplVHBDjrnbtdqsF=KwEivmyQCaTURufplVHBDjrnbtdqGe.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if KwEivmyQCaTURufplVHBDjrnbtdqsF==KwEivmyQCaTURufplVHBDjrnbtdqYk:sys.exit()
  KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Init_TV_Total()
  if os.path.isfile(KwEivmyQCaTURufplVHBDjrnbtdqGg):os.remove(KwEivmyQCaTURufplVHBDjrnbtdqGg)
  KwEivmyQCaTURufplVHBDjrnbtdqGc.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  KwEivmyQCaTURufplVHBDjrnbtdqYO =KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Get_Now_Datetime()
  KwEivmyQCaTURufplVHBDjrnbtdqYz=KwEivmyQCaTURufplVHBDjrnbtdqYO+datetime.timedelta(days=KwEivmyQCaTURufplVHBDjrnbtdqYS(__addon__.getSetting('cache_ttl')))
  (KwEivmyQCaTURufplVHBDjrnbtdqsY,KwEivmyQCaTURufplVHBDjrnbtdqsx,KwEivmyQCaTURufplVHBDjrnbtdqsA,KwEivmyQCaTURufplVHBDjrnbtdqsg)=KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_account()
  KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Save_session_acount(KwEivmyQCaTURufplVHBDjrnbtdqsY,KwEivmyQCaTURufplVHBDjrnbtdqsx,KwEivmyQCaTURufplVHBDjrnbtdqsA,KwEivmyQCaTURufplVHBDjrnbtdqsg)
  KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.TV['account']['token_limit']=KwEivmyQCaTURufplVHBDjrnbtdqYz.strftime('%Y%m%d')
  KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.JsonFile_Save(KwEivmyQCaTURufplVHBDjrnbtdqGg,KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.TV)
 def cookiefile_check(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.TV=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.JsonFile_Load(KwEivmyQCaTURufplVHBDjrnbtdqGg)
  if 'account' not in KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.TV:
   KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Init_TV_Total()
   return KwEivmyQCaTURufplVHBDjrnbtdqYk
  (KwEivmyQCaTURufplVHBDjrnbtdqYx,KwEivmyQCaTURufplVHBDjrnbtdqYA,KwEivmyQCaTURufplVHBDjrnbtdqYg,KwEivmyQCaTURufplVHBDjrnbtdqYF)=KwEivmyQCaTURufplVHBDjrnbtdqGc.get_settings_account()
  (KwEivmyQCaTURufplVHBDjrnbtdqYc,KwEivmyQCaTURufplVHBDjrnbtdqYI,KwEivmyQCaTURufplVHBDjrnbtdqYo,KwEivmyQCaTURufplVHBDjrnbtdqYL)=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Load_session_acount()
  if KwEivmyQCaTURufplVHBDjrnbtdqYx!=KwEivmyQCaTURufplVHBDjrnbtdqYc or KwEivmyQCaTURufplVHBDjrnbtdqYA!=KwEivmyQCaTURufplVHBDjrnbtdqYI or KwEivmyQCaTURufplVHBDjrnbtdqYg!=KwEivmyQCaTURufplVHBDjrnbtdqYo or KwEivmyQCaTURufplVHBDjrnbtdqYF!=KwEivmyQCaTURufplVHBDjrnbtdqYL:
   KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Init_TV_Total()
   return KwEivmyQCaTURufplVHBDjrnbtdqYk
  if KwEivmyQCaTURufplVHBDjrnbtdqYS(KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>KwEivmyQCaTURufplVHBDjrnbtdqYS(KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.TV['account']['token_limit']):
   KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.Init_TV_Total()
   return KwEivmyQCaTURufplVHBDjrnbtdqYk
  return KwEivmyQCaTURufplVHBDjrnbtdqYh
 def dp_Global_Search(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqXM=KwEivmyQCaTURufplVHBDjrnbtdqse.get('mode')
  if KwEivmyQCaTURufplVHBDjrnbtdqXM=='TOTAL_SEARCH':
   KwEivmyQCaTURufplVHBDjrnbtdqYJ='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   KwEivmyQCaTURufplVHBDjrnbtdqYJ='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(KwEivmyQCaTURufplVHBDjrnbtdqYJ)
 def dp_Bookmark_Menu(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqYJ='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(KwEivmyQCaTURufplVHBDjrnbtdqYJ)
 def dp_EuroLive_List(KwEivmyQCaTURufplVHBDjrnbtdqGc,KwEivmyQCaTURufplVHBDjrnbtdqse):
  KwEivmyQCaTURufplVHBDjrnbtdqsS=KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.GetEuroChannelList()
  for KwEivmyQCaTURufplVHBDjrnbtdqsk in KwEivmyQCaTURufplVHBDjrnbtdqsS:
   KwEivmyQCaTURufplVHBDjrnbtdqPL =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('channel')
   KwEivmyQCaTURufplVHBDjrnbtdqWL =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('title')
   KwEivmyQCaTURufplVHBDjrnbtdqPg =KwEivmyQCaTURufplVHBDjrnbtdqsk.get('subtitle')
   KwEivmyQCaTURufplVHBDjrnbtdqPA={'mediatype':'episode','title':KwEivmyQCaTURufplVHBDjrnbtdqWL,'plot':'%s\n%s'%(KwEivmyQCaTURufplVHBDjrnbtdqWL,KwEivmyQCaTURufplVHBDjrnbtdqPg)}
   KwEivmyQCaTURufplVHBDjrnbtdqsW={'mode':'LIVE','mediacode':KwEivmyQCaTURufplVHBDjrnbtdqPL,'stype':'onair',}
   KwEivmyQCaTURufplVHBDjrnbtdqGc.add_dir(KwEivmyQCaTURufplVHBDjrnbtdqWL,sublabel=KwEivmyQCaTURufplVHBDjrnbtdqPg,img='',infoLabels=KwEivmyQCaTURufplVHBDjrnbtdqPA,isFolder=KwEivmyQCaTURufplVHBDjrnbtdqYk,params=KwEivmyQCaTURufplVHBDjrnbtdqsW)
  if KwEivmyQCaTURufplVHBDjrnbtdqxP(KwEivmyQCaTURufplVHBDjrnbtdqsS)>0:xbmcplugin.endOfDirectory(KwEivmyQCaTURufplVHBDjrnbtdqGc._addon_handle,cacheToDisc=KwEivmyQCaTURufplVHBDjrnbtdqYk)
 def tving_main(KwEivmyQCaTURufplVHBDjrnbtdqGc):
  KwEivmyQCaTURufplVHBDjrnbtdqGc.TvingObj.KodiVersion=KwEivmyQCaTURufplVHBDjrnbtdqYS(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  KwEivmyQCaTURufplVHBDjrnbtdqXM=KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params.get('mode',KwEivmyQCaTURufplVHBDjrnbtdqYM)
  if KwEivmyQCaTURufplVHBDjrnbtdqXM=='LOGOUT':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.logout()
   return
  KwEivmyQCaTURufplVHBDjrnbtdqGc.login_main()
  if KwEivmyQCaTURufplVHBDjrnbtdqXM is KwEivmyQCaTURufplVHBDjrnbtdqYM:
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_Main_List()
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_Title_Group(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM in['GLOBAL_GROUP']:
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_SubTitle_Group(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='CHANNEL':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_LiveChannel_List(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM in['LIVE','VOD','MOVIE']:
   KwEivmyQCaTURufplVHBDjrnbtdqGc.play_VIDEO(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='PROGRAM':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_Program_List(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='4K_PROGRAM':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_4K_Program_List(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='ORI_PROGRAM':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_Ori_Program_List(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='EPISODE':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_Episode_List(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='MOVIE_SUB':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_Movie_List(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='4K_MOVIE':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_4K_Movie_List(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='SEARCH_GROUP':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_Search_Group(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM in['SEARCH','LOCAL_SEARCH']:
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_Search_List(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='WATCH':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_Watch_List(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_History_Remove(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='ORDER_BY':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_setEpOrderby(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='SET_BOOKMARK':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_Set_Bookmark(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM in['TOTAL_SEARCH','TOTAL_HISTORY']:
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_Global_Search(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='SEARCH_HISTORY':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_Search_History(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='MENU_BOOKMARK':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_Bookmark_Menu(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  elif KwEivmyQCaTURufplVHBDjrnbtdqXM=='EURO_GROUP':
   KwEivmyQCaTURufplVHBDjrnbtdqGc.dp_EuroLive_List(KwEivmyQCaTURufplVHBDjrnbtdqGc.main_params)
  else:
   KwEivmyQCaTURufplVHBDjrnbtdqYM
# Created by pyminifier (https://github.com/liftoff/pyminifier)
