__author__="NightRain"
CMHiVyzBwukmsJhaNgoSeXqjtFObnQ=print
CMHiVyzBwukmsJhaNgoSeXqjtFObnT=ImportError
CMHiVyzBwukmsJhaNgoSeXqjtFObnd=object
CMHiVyzBwukmsJhaNgoSeXqjtFObnL=None
CMHiVyzBwukmsJhaNgoSeXqjtFObnY=False
CMHiVyzBwukmsJhaNgoSeXqjtFObnU=open
CMHiVyzBwukmsJhaNgoSeXqjtFObnx=True
CMHiVyzBwukmsJhaNgoSeXqjtFObnA=int
CMHiVyzBwukmsJhaNgoSeXqjtFObnf=range
CMHiVyzBwukmsJhaNgoSeXqjtFObnv=Exception
CMHiVyzBwukmsJhaNgoSeXqjtFObnP=len
CMHiVyzBwukmsJhaNgoSeXqjtFObnp=str
CMHiVyzBwukmsJhaNgoSeXqjtFObIE=dict
CMHiVyzBwukmsJhaNgoSeXqjtFObIK=list
CMHiVyzBwukmsJhaNgoSeXqjtFObIl=bytes
CMHiVyzBwukmsJhaNgoSeXqjtFObIW=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 CMHiVyzBwukmsJhaNgoSeXqjtFObnQ('Cryptodome')
except CMHiVyzBwukmsJhaNgoSeXqjtFObnT:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 CMHiVyzBwukmsJhaNgoSeXqjtFObnQ('Crypto')
CMHiVyzBwukmsJhaNgoSeXqjtFObEl={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
CMHiVyzBwukmsJhaNgoSeXqjtFObEW ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
CMHiVyzBwukmsJhaNgoSeXqjtFObED =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class CMHiVyzBwukmsJhaNgoSeXqjtFObEK(CMHiVyzBwukmsJhaNgoSeXqjtFObnd):
 def __init__(CMHiVyzBwukmsJhaNgoSeXqjtFObER):
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.NETWORKCODE ='CSND0900'
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.OSCODE ='CSOD0900' 
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TELECODE ='CSCD0900'
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.SCREENCODE ='CSSD0100'
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.SCREENCODE_ATV ='CSSD1300' 
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.LIVE_LIMIT =20 
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.VOD_LIMIT =24 
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.EPISODE_LIMIT =30 
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.SEARCH_LIMIT =30 
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.MOVIE_LIMIT =24 
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN ='https://api.tving.com'
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN ='https://image.tving.com'
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.SEARCH_DOMAIN ='https://search.tving.com'
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.LOGIN_DOMAIN ='https://user.tving.com'
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.URL_DOMAIN ='https://www.tving.com'
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.MOVIE_LITE =['2610061','2610161','261062']
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36'
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.DEFAULT_HEADER ={'user-agent':CMHiVyzBwukmsJhaNgoSeXqjtFObER.USER_AGENT}
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV_SESSION_COOKIES1=''
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV_SESSION_COOKIES2=''
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV_STREAM_FILENAME =''
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV_SESSION_TEXT1 =''
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV_SESSION_TEXT2 =''
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.KodiVersion=20
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV ={}
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.Init_TV_Total()
 def Init_TV_Total(CMHiVyzBwukmsJhaNgoSeXqjtFObER):
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N','tving_authToken':'',},}
 def callRequestCookies(CMHiVyzBwukmsJhaNgoSeXqjtFObER,jobtype,CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,redirects=CMHiVyzBwukmsJhaNgoSeXqjtFObnY):
  CMHiVyzBwukmsJhaNgoSeXqjtFObEn=CMHiVyzBwukmsJhaNgoSeXqjtFObER.DEFAULT_HEADER
  if headers:CMHiVyzBwukmsJhaNgoSeXqjtFObEn.update(headers)
  if jobtype=='Get':
   CMHiVyzBwukmsJhaNgoSeXqjtFObEI=requests.get(CMHiVyzBwukmsJhaNgoSeXqjtFOblE,params=params,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObEn,cookies=cookies,allow_redirects=redirects)
  else:
   CMHiVyzBwukmsJhaNgoSeXqjtFObEI=requests.post(CMHiVyzBwukmsJhaNgoSeXqjtFOblE,data=payload,params=params,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObEn,cookies=cookies,allow_redirects=redirects)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObEI
 def JsonFile_Save(CMHiVyzBwukmsJhaNgoSeXqjtFObER,filename,CMHiVyzBwukmsJhaNgoSeXqjtFObEc):
  if filename=='':return CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  try:
   fp=CMHiVyzBwukmsJhaNgoSeXqjtFObnU(filename,'w',-1,'utf-8')
   json.dump(CMHiVyzBwukmsJhaNgoSeXqjtFObEc,fp,indent=4,ensure_ascii=CMHiVyzBwukmsJhaNgoSeXqjtFObnY)
   fp.close()
  except:
   return CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  return CMHiVyzBwukmsJhaNgoSeXqjtFObnx
 def JsonFile_Load(CMHiVyzBwukmsJhaNgoSeXqjtFObER,filename):
  if filename=='':return{}
  try:
   fp=CMHiVyzBwukmsJhaNgoSeXqjtFObnU(filename,'r',-1,'utf-8')
   CMHiVyzBwukmsJhaNgoSeXqjtFObEr=json.load(fp)
   fp.close()
  except:
   return{}
  return CMHiVyzBwukmsJhaNgoSeXqjtFObEr
 def TextFile_Save(CMHiVyzBwukmsJhaNgoSeXqjtFObER,filename,resText):
  if filename=='':return CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  try:
   fp=CMHiVyzBwukmsJhaNgoSeXqjtFObnU(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  return CMHiVyzBwukmsJhaNgoSeXqjtFObnx
 def Save_session_acount(CMHiVyzBwukmsJhaNgoSeXqjtFObER,CMHiVyzBwukmsJhaNgoSeXqjtFObEQ,CMHiVyzBwukmsJhaNgoSeXqjtFObET,CMHiVyzBwukmsJhaNgoSeXqjtFObEd,CMHiVyzBwukmsJhaNgoSeXqjtFObEL):
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['account']['tvid'] =base64.standard_b64encode(CMHiVyzBwukmsJhaNgoSeXqjtFObEQ.encode()).decode('utf-8')
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['account']['tvpw'] =base64.standard_b64encode(CMHiVyzBwukmsJhaNgoSeXqjtFObET.encode()).decode('utf-8')
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['account']['tvtype']=CMHiVyzBwukmsJhaNgoSeXqjtFObEd 
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['account']['tvpf'] =CMHiVyzBwukmsJhaNgoSeXqjtFObEL 
 def Load_session_acount(CMHiVyzBwukmsJhaNgoSeXqjtFObER):
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObEQ =base64.standard_b64decode(CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['account']['tvid']).decode('utf-8')
   CMHiVyzBwukmsJhaNgoSeXqjtFObET =base64.standard_b64decode(CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['account']['tvpw']).decode('utf-8')
   CMHiVyzBwukmsJhaNgoSeXqjtFObEd=CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['account']['tvtype']
   CMHiVyzBwukmsJhaNgoSeXqjtFObEL =CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return CMHiVyzBwukmsJhaNgoSeXqjtFObEQ,CMHiVyzBwukmsJhaNgoSeXqjtFObET,CMHiVyzBwukmsJhaNgoSeXqjtFObEd,CMHiVyzBwukmsJhaNgoSeXqjtFObEL
 def makeDefaultCookies(CMHiVyzBwukmsJhaNgoSeXqjtFObER):
  CMHiVyzBwukmsJhaNgoSeXqjtFObEY={}
  if CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_token']:CMHiVyzBwukmsJhaNgoSeXqjtFObEY['_tving_token']=CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_token']
  if CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_userinfo']:CMHiVyzBwukmsJhaNgoSeXqjtFObEY['POC_USERINFO']=CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_userinfo']
  if CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_maintoken']:CMHiVyzBwukmsJhaNgoSeXqjtFObEY[CMHiVyzBwukmsJhaNgoSeXqjtFObER.GLOBAL_COOKIENM['tv_maintoken']]=CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_maintoken']
  if CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_cookiekey']:CMHiVyzBwukmsJhaNgoSeXqjtFObEY[CMHiVyzBwukmsJhaNgoSeXqjtFObER.GLOBAL_COOKIENM['tv_cookiekey']]=CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_cookiekey']
  if CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_lockkey']:CMHiVyzBwukmsJhaNgoSeXqjtFObEY[CMHiVyzBwukmsJhaNgoSeXqjtFObER.GLOBAL_COOKIENM['tv_lockkey']]=CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_lockkey']
  if CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_authToken']:CMHiVyzBwukmsJhaNgoSeXqjtFObEY['authToken']=CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_authToken']
  return CMHiVyzBwukmsJhaNgoSeXqjtFObEY
 def makeCookiesStr(CMHiVyzBwukmsJhaNgoSeXqjtFObER):
  return '_tving_token='+CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_token']+';'+ 'POC_USERINFO='+CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_userinfo']+';'+ CMHiVyzBwukmsJhaNgoSeXqjtFObER.GLOBAL_COOKIENM['tv_maintoken']+'='+CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_maintoken']+';'+ CMHiVyzBwukmsJhaNgoSeXqjtFObER.GLOBAL_COOKIENM['tv_cookiekey']+'='+CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_cookiekey']+';'+ CMHiVyzBwukmsJhaNgoSeXqjtFObER.GLOBAL_COOKIENM['tv_lockkey']+'='+CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_lockkey']
 def getDeviceStr(CMHiVyzBwukmsJhaNgoSeXqjtFObER):
  CMHiVyzBwukmsJhaNgoSeXqjtFObEU=[]
  CMHiVyzBwukmsJhaNgoSeXqjtFObEU.append('Windows') 
  CMHiVyzBwukmsJhaNgoSeXqjtFObEU.append('Chrome') 
  CMHiVyzBwukmsJhaNgoSeXqjtFObEU.append('ko-KR') 
  CMHiVyzBwukmsJhaNgoSeXqjtFObEU.append('undefined') 
  CMHiVyzBwukmsJhaNgoSeXqjtFObEU.append('24') 
  CMHiVyzBwukmsJhaNgoSeXqjtFObEU.append(u'한국 표준시')
  CMHiVyzBwukmsJhaNgoSeXqjtFObEU.append('undefined') 
  CMHiVyzBwukmsJhaNgoSeXqjtFObEU.append('undefined') 
  CMHiVyzBwukmsJhaNgoSeXqjtFObEU.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  CMHiVyzBwukmsJhaNgoSeXqjtFObEx=''
  for CMHiVyzBwukmsJhaNgoSeXqjtFObEA in CMHiVyzBwukmsJhaNgoSeXqjtFObEU:
   CMHiVyzBwukmsJhaNgoSeXqjtFObEx+=CMHiVyzBwukmsJhaNgoSeXqjtFObEA+'|'
  return CMHiVyzBwukmsJhaNgoSeXqjtFObEx
 def GetDefaultParams(CMHiVyzBwukmsJhaNgoSeXqjtFObER,uhd=CMHiVyzBwukmsJhaNgoSeXqjtFObnY):
  if uhd==CMHiVyzBwukmsJhaNgoSeXqjtFObnY:
   CMHiVyzBwukmsJhaNgoSeXqjtFObEf={'apiKey':CMHiVyzBwukmsJhaNgoSeXqjtFObER.APIKEY,'networkCode':CMHiVyzBwukmsJhaNgoSeXqjtFObER.NETWORKCODE,'osCode':CMHiVyzBwukmsJhaNgoSeXqjtFObER.OSCODE,'teleCode':CMHiVyzBwukmsJhaNgoSeXqjtFObER.TELECODE,'screenCode':CMHiVyzBwukmsJhaNgoSeXqjtFObER.SCREENCODE,}
  else:
   CMHiVyzBwukmsJhaNgoSeXqjtFObEf={'apiKey':CMHiVyzBwukmsJhaNgoSeXqjtFObER.APIKEY_ATV,'networkCode':CMHiVyzBwukmsJhaNgoSeXqjtFObER.NETWORKCODE,'osCode':CMHiVyzBwukmsJhaNgoSeXqjtFObER.OSCODE,'teleCode':CMHiVyzBwukmsJhaNgoSeXqjtFObER.TELECODE,'screenCode':CMHiVyzBwukmsJhaNgoSeXqjtFObER.SCREENCODE_ATV,}
  return CMHiVyzBwukmsJhaNgoSeXqjtFObEf
 def GetNoCache(CMHiVyzBwukmsJhaNgoSeXqjtFObER,timetype=1):
  if timetype==1:
   return CMHiVyzBwukmsJhaNgoSeXqjtFObnA(time.time())
  else:
   return CMHiVyzBwukmsJhaNgoSeXqjtFObnA(time.time()*1000)
 def GetUniqueid(CMHiVyzBwukmsJhaNgoSeXqjtFObER,hValue=CMHiVyzBwukmsJhaNgoSeXqjtFObnL):
  if hValue:
   import hashlib
   CMHiVyzBwukmsJhaNgoSeXqjtFObEv=hashlib.sha1()
   CMHiVyzBwukmsJhaNgoSeXqjtFObEv.update(hValue.encode())
   CMHiVyzBwukmsJhaNgoSeXqjtFObEP=CMHiVyzBwukmsJhaNgoSeXqjtFObEv.hexdigest()[:8]
  else:
   CMHiVyzBwukmsJhaNgoSeXqjtFObEp=[0 for i in CMHiVyzBwukmsJhaNgoSeXqjtFObnf(256)]
   for i in CMHiVyzBwukmsJhaNgoSeXqjtFObnf(256):
    CMHiVyzBwukmsJhaNgoSeXqjtFObEp[i]='%02x'%(i)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKE=CMHiVyzBwukmsJhaNgoSeXqjtFObnA(4294967295*random.random())|0
   CMHiVyzBwukmsJhaNgoSeXqjtFObEP=CMHiVyzBwukmsJhaNgoSeXqjtFObEp[255&CMHiVyzBwukmsJhaNgoSeXqjtFObKE]+CMHiVyzBwukmsJhaNgoSeXqjtFObEp[CMHiVyzBwukmsJhaNgoSeXqjtFObKE>>8&255]+CMHiVyzBwukmsJhaNgoSeXqjtFObEp[CMHiVyzBwukmsJhaNgoSeXqjtFObKE>>16&255]+CMHiVyzBwukmsJhaNgoSeXqjtFObEp[CMHiVyzBwukmsJhaNgoSeXqjtFObKE>>24&255]
  return CMHiVyzBwukmsJhaNgoSeXqjtFObEP
 def GetCredential(CMHiVyzBwukmsJhaNgoSeXqjtFObER,user_id,user_pw,login_type,user_pf):
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKl=CMHiVyzBwukmsJhaNgoSeXqjtFObER.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   CMHiVyzBwukmsJhaNgoSeXqjtFObKW={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Post',CMHiVyzBwukmsJhaNgoSeXqjtFObKl,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObKW,params=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL)
   for CMHiVyzBwukmsJhaNgoSeXqjtFObKR in CMHiVyzBwukmsJhaNgoSeXqjtFObKD.cookies:
    if CMHiVyzBwukmsJhaNgoSeXqjtFObKR.name=='_tving_token':
     CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_token']=CMHiVyzBwukmsJhaNgoSeXqjtFObKR.value
    elif CMHiVyzBwukmsJhaNgoSeXqjtFObKR.name=='POC_USERINFO':
     CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_userinfo']=CMHiVyzBwukmsJhaNgoSeXqjtFObKR.value
    elif CMHiVyzBwukmsJhaNgoSeXqjtFObKR.name=='authToken':
     CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_authToken']=CMHiVyzBwukmsJhaNgoSeXqjtFObKR.value
   if not CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_token']:
    CMHiVyzBwukmsJhaNgoSeXqjtFObER.Init_TV_Total()
    return CMHiVyzBwukmsJhaNgoSeXqjtFObnY
   CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_maintoken']=CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_token']
   if CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetProfileToken(user_pf)==CMHiVyzBwukmsJhaNgoSeXqjtFObnY:
    CMHiVyzBwukmsJhaNgoSeXqjtFObER.Init_TV_Total()
    return CMHiVyzBwukmsJhaNgoSeXqjtFObnY
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies'])
   CMHiVyzBwukmsJhaNgoSeXqjtFObKn =CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDeviceList()
   if CMHiVyzBwukmsJhaNgoSeXqjtFObKn not in['','-']:
    CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_uuid']=CMHiVyzBwukmsJhaNgoSeXqjtFObKn+'-'+CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetUniqueid(CMHiVyzBwukmsJhaNgoSeXqjtFObKn)
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
   CMHiVyzBwukmsJhaNgoSeXqjtFObER.Init_TV_Total()
   return CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  return CMHiVyzBwukmsJhaNgoSeXqjtFObnx
 def GetProfileToken(CMHiVyzBwukmsJhaNgoSeXqjtFObER,user_pf):
  CMHiVyzBwukmsJhaNgoSeXqjtFObKI=[]
  CMHiVyzBwukmsJhaNgoSeXqjtFObKc =''
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   CMHiVyzBwukmsJhaNgoSeXqjtFObEY=CMHiVyzBwukmsJhaNgoSeXqjtFObER.makeDefaultCookies()
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(CMHiVyzBwukmsJhaNgoSeXqjtFObEY)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFObKG,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObEY)
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKI =re.findall('data-profile-no="\d+"',CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(CMHiVyzBwukmsJhaNgoSeXqjtFObKI)
   for i in CMHiVyzBwukmsJhaNgoSeXqjtFObnf(CMHiVyzBwukmsJhaNgoSeXqjtFObnP(CMHiVyzBwukmsJhaNgoSeXqjtFObKI)):
    CMHiVyzBwukmsJhaNgoSeXqjtFObKr =CMHiVyzBwukmsJhaNgoSeXqjtFObKI[i].replace('data-profile-no=','').replace('"','')
    CMHiVyzBwukmsJhaNgoSeXqjtFObKI[i]=CMHiVyzBwukmsJhaNgoSeXqjtFObKr
   CMHiVyzBwukmsJhaNgoSeXqjtFObKc=CMHiVyzBwukmsJhaNgoSeXqjtFObKI[user_pf]
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
   CMHiVyzBwukmsJhaNgoSeXqjtFObER.Init_TV_Total()
   return CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   CMHiVyzBwukmsJhaNgoSeXqjtFObEY=CMHiVyzBwukmsJhaNgoSeXqjtFObER.makeDefaultCookies()
   CMHiVyzBwukmsJhaNgoSeXqjtFObKW={'profileNo':CMHiVyzBwukmsJhaNgoSeXqjtFObKc}
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Post',CMHiVyzBwukmsJhaNgoSeXqjtFObKG,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObKW,params=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObEY)
   for CMHiVyzBwukmsJhaNgoSeXqjtFObKR in CMHiVyzBwukmsJhaNgoSeXqjtFObKD.cookies:
    if CMHiVyzBwukmsJhaNgoSeXqjtFObKR.name=='_tving_token':
     CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_token']=CMHiVyzBwukmsJhaNgoSeXqjtFObKR.value
    elif CMHiVyzBwukmsJhaNgoSeXqjtFObKR.name==CMHiVyzBwukmsJhaNgoSeXqjtFObER.GLOBAL_COOKIENM['tv_cookiekey']:
     CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_cookiekey']=CMHiVyzBwukmsJhaNgoSeXqjtFObKR.value
    elif CMHiVyzBwukmsJhaNgoSeXqjtFObKR.name==CMHiVyzBwukmsJhaNgoSeXqjtFObER.GLOBAL_COOKIENM['tv_lockkey']:
     CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_lockkey']=CMHiVyzBwukmsJhaNgoSeXqjtFObKR.value
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
   CMHiVyzBwukmsJhaNgoSeXqjtFObER.Init_TV_Total()
   return CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  return CMHiVyzBwukmsJhaNgoSeXqjtFObnx
 def GetDeviceList(CMHiVyzBwukmsJhaNgoSeXqjtFObER):
  CMHiVyzBwukmsJhaNgoSeXqjtFObKQ=[]
  CMHiVyzBwukmsJhaNgoSeXqjtFObKT='-'
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v1/user/device/list'
   CMHiVyzBwukmsJhaNgoSeXqjtFObKd=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKG
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   CMHiVyzBwukmsJhaNgoSeXqjtFObEY=CMHiVyzBwukmsJhaNgoSeXqjtFObER.makeDefaultCookies()
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFObKd,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKL,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObEY)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKY=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKQ=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']
   for CMHiVyzBwukmsJhaNgoSeXqjtFObKU in CMHiVyzBwukmsJhaNgoSeXqjtFObKQ:
    if CMHiVyzBwukmsJhaNgoSeXqjtFObKU['model']=='PC' or CMHiVyzBwukmsJhaNgoSeXqjtFObKU['model']=='PC-Chrome':
     CMHiVyzBwukmsJhaNgoSeXqjtFObKT=CMHiVyzBwukmsJhaNgoSeXqjtFObKU['uuid']
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObKT
 def Get_Now_Datetime(CMHiVyzBwukmsJhaNgoSeXqjtFObER):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(CMHiVyzBwukmsJhaNgoSeXqjtFObER,mediacode,sel_quality,stype,pvrmode='-',optUHD=CMHiVyzBwukmsJhaNgoSeXqjtFObnY):
  CMHiVyzBwukmsJhaNgoSeXqjtFObKA ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','subtitleYn':CMHiVyzBwukmsJhaNgoSeXqjtFObnY,'error_msg':'',}
  CMHiVyzBwukmsJhaNgoSeXqjtFObKT =CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_uuid'].split('-')[0] 
  CMHiVyzBwukmsJhaNgoSeXqjtFObKf =CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_uuid'] 
  CMHiVyzBwukmsJhaNgoSeXqjtFObKv=CMHiVyzBwukmsJhaNgoSeXqjtFObnY 
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKP=CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetNoCache(1))
   if stype!='tvingtv':
    CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v2/media/stream/info' 
    CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams()
    CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':CMHiVyzBwukmsJhaNgoSeXqjtFObKf,'deviceInfo':'PC','noCache':CMHiVyzBwukmsJhaNgoSeXqjtFObKP,}
    CMHiVyzBwukmsJhaNgoSeXqjtFObKp.update(CMHiVyzBwukmsJhaNgoSeXqjtFObKL)
    CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKG
    CMHiVyzBwukmsJhaNgoSeXqjtFObEY=CMHiVyzBwukmsJhaNgoSeXqjtFObER.makeDefaultCookies()
    CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKp,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObEY)
    if CMHiVyzBwukmsJhaNgoSeXqjtFObKD.status_code!=200:
     CMHiVyzBwukmsJhaNgoSeXqjtFObKA['error_msg']='First Step - {} error'.format(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.status_code)
     return CMHiVyzBwukmsJhaNgoSeXqjtFObKA
    CMHiVyzBwukmsJhaNgoSeXqjtFObKY=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
    if CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['result']['code']=='060':
     for CMHiVyzBwukmsJhaNgoSeXqjtFOblK,CMHiVyzBwukmsJhaNgoSeXqjtFObWd in CMHiVyzBwukmsJhaNgoSeXqjtFObEl.items():
      if CMHiVyzBwukmsJhaNgoSeXqjtFObWd==sel_quality:
       CMHiVyzBwukmsJhaNgoSeXqjtFOblW=CMHiVyzBwukmsJhaNgoSeXqjtFOblK
    elif CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['result']['code']!='000':
     CMHiVyzBwukmsJhaNgoSeXqjtFObKA['error_msg']=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['result']['message']
     return CMHiVyzBwukmsJhaNgoSeXqjtFObKA
    else: 
     if not('stream' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']):return CMHiVyzBwukmsJhaNgoSeXqjtFObKA
     CMHiVyzBwukmsJhaNgoSeXqjtFOblD=[]
     for CMHiVyzBwukmsJhaNgoSeXqjtFOblK,CMHiVyzBwukmsJhaNgoSeXqjtFObWd in CMHiVyzBwukmsJhaNgoSeXqjtFObEl.items():
      for CMHiVyzBwukmsJhaNgoSeXqjtFObKU in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['stream']['quality']:
       if CMHiVyzBwukmsJhaNgoSeXqjtFObKU['active']=='Y' and CMHiVyzBwukmsJhaNgoSeXqjtFObKU['code']==CMHiVyzBwukmsJhaNgoSeXqjtFOblK:
        CMHiVyzBwukmsJhaNgoSeXqjtFOblD.append({CMHiVyzBwukmsJhaNgoSeXqjtFObEl.get(CMHiVyzBwukmsJhaNgoSeXqjtFObKU['code']):CMHiVyzBwukmsJhaNgoSeXqjtFObKU['code']})
     CMHiVyzBwukmsJhaNgoSeXqjtFOblW=CMHiVyzBwukmsJhaNgoSeXqjtFObER.CheckQuality(sel_quality,CMHiVyzBwukmsJhaNgoSeXqjtFOblD)
     try:
      if optUHD==CMHiVyzBwukmsJhaNgoSeXqjtFObnx and CMHiVyzBwukmsJhaNgoSeXqjtFOblW=='stream50' and 'stream_support_info' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['content']['info']:
       if CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['content']['info']['stream_support_info']!=CMHiVyzBwukmsJhaNgoSeXqjtFObnL:
        if 'stream70' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['content']['info']['stream_support_info']:
         CMHiVyzBwukmsJhaNgoSeXqjtFOblW='stream70'
         CMHiVyzBwukmsJhaNgoSeXqjtFObKv =CMHiVyzBwukmsJhaNgoSeXqjtFObnx
     except:
      pass
     try:
      if optUHD==CMHiVyzBwukmsJhaNgoSeXqjtFObnx and CMHiVyzBwukmsJhaNgoSeXqjtFOblW=='stream50' and 'stream' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['content']['info']:
       if CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['content']['info']['stream']!=CMHiVyzBwukmsJhaNgoSeXqjtFObnL:
        for CMHiVyzBwukmsJhaNgoSeXqjtFObKU in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['content']['info']['stream']:
         if CMHiVyzBwukmsJhaNgoSeXqjtFObKU['code']=='stream70':
          CMHiVyzBwukmsJhaNgoSeXqjtFOblW='stream70'
          CMHiVyzBwukmsJhaNgoSeXqjtFObKv =CMHiVyzBwukmsJhaNgoSeXqjtFObnx
          break
     except:
      pass
   else:
    CMHiVyzBwukmsJhaNgoSeXqjtFOblW='stream40'
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKA['error_msg']='First Step - except error'
   return CMHiVyzBwukmsJhaNgoSeXqjtFObKA
  CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(CMHiVyzBwukmsJhaNgoSeXqjtFOblW)
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKP=CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetNoCache(1))
   CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v2a/media/stream/info'
   if CMHiVyzBwukmsJhaNgoSeXqjtFObKv==CMHiVyzBwukmsJhaNgoSeXqjtFObnx:
    CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams(uhd=CMHiVyzBwukmsJhaNgoSeXqjtFObnx)
    CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'mediaCode':mediacode,'noCache':CMHiVyzBwukmsJhaNgoSeXqjtFObKP,'streamType':'hls','streamCode':CMHiVyzBwukmsJhaNgoSeXqjtFOblW,'deviceId':CMHiVyzBwukmsJhaNgoSeXqjtFObKT,'adReq':'none','wm':'Y','ad_device':'','uuid':CMHiVyzBwukmsJhaNgoSeXqjtFObKf,'deviceInfo':'android_tv',}
   else:
    CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams()
    CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':CMHiVyzBwukmsJhaNgoSeXqjtFOblW,'deviceId':CMHiVyzBwukmsJhaNgoSeXqjtFObKT,'uuid':CMHiVyzBwukmsJhaNgoSeXqjtFObKf,'deviceInfo':'PC_Chrome','noCache':CMHiVyzBwukmsJhaNgoSeXqjtFObKP,'wm':'Y'}
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp.update(CMHiVyzBwukmsJhaNgoSeXqjtFObKL)
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKG
   CMHiVyzBwukmsJhaNgoSeXqjtFObEY=CMHiVyzBwukmsJhaNgoSeXqjtFObER.makeDefaultCookies()
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKp,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObEY,redirects=CMHiVyzBwukmsJhaNgoSeXqjtFObnY)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKY=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   if CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['result']['code']!='000':
    CMHiVyzBwukmsJhaNgoSeXqjtFObKA['error_msg']=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['result']['message']
    return CMHiVyzBwukmsJhaNgoSeXqjtFObKA
   CMHiVyzBwukmsJhaNgoSeXqjtFOblR=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['stream']
   if 'drm_license_assertion' in CMHiVyzBwukmsJhaNgoSeXqjtFOblR:
    CMHiVyzBwukmsJhaNgoSeXqjtFObKA['drm_license']=CMHiVyzBwukmsJhaNgoSeXqjtFOblR['drm_license_assertion']
    if '4k_nondrm_url' in CMHiVyzBwukmsJhaNgoSeXqjtFOblR['broadcast']and CMHiVyzBwukmsJhaNgoSeXqjtFObKv==CMHiVyzBwukmsJhaNgoSeXqjtFObnx:
     CMHiVyzBwukmsJhaNgoSeXqjtFObln =CMHiVyzBwukmsJhaNgoSeXqjtFOblR['broadcast']['4k_nondrm_url']
     CMHiVyzBwukmsJhaNgoSeXqjtFObKA['drm_license']=''
    else:
     CMHiVyzBwukmsJhaNgoSeXqjtFObln =CMHiVyzBwukmsJhaNgoSeXqjtFOblR['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in CMHiVyzBwukmsJhaNgoSeXqjtFOblR['broadcast']):return CMHiVyzBwukmsJhaNgoSeXqjtFObKA
    CMHiVyzBwukmsJhaNgoSeXqjtFObln=CMHiVyzBwukmsJhaNgoSeXqjtFOblR['broadcast']['broad_url']
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKA['error_msg']='Second Step - except error'
   return CMHiVyzBwukmsJhaNgoSeXqjtFObKA
  CMHiVyzBwukmsJhaNgoSeXqjtFOblI=CMHiVyzBwukmsJhaNgoSeXqjtFObKP
  CMHiVyzBwukmsJhaNgoSeXqjtFObln=CMHiVyzBwukmsJhaNgoSeXqjtFObln.split('|')[1]
  CMHiVyzBwukmsJhaNgoSeXqjtFObln,CMHiVyzBwukmsJhaNgoSeXqjtFOblc,CMHiVyzBwukmsJhaNgoSeXqjtFOblG=CMHiVyzBwukmsJhaNgoSeXqjtFObER.Decrypt_Url(CMHiVyzBwukmsJhaNgoSeXqjtFObln,mediacode,CMHiVyzBwukmsJhaNgoSeXqjtFOblI)
  CMHiVyzBwukmsJhaNgoSeXqjtFObKA['streaming_url']=CMHiVyzBwukmsJhaNgoSeXqjtFObln
  CMHiVyzBwukmsJhaNgoSeXqjtFObKA['watermark'] =CMHiVyzBwukmsJhaNgoSeXqjtFOblc
  CMHiVyzBwukmsJhaNgoSeXqjtFObKA['watermarkKey']=CMHiVyzBwukmsJhaNgoSeXqjtFOblG
  if 'subtitles' in CMHiVyzBwukmsJhaNgoSeXqjtFOblR:
   for CMHiVyzBwukmsJhaNgoSeXqjtFOblr in CMHiVyzBwukmsJhaNgoSeXqjtFOblR.get('subtitles'):
    if CMHiVyzBwukmsJhaNgoSeXqjtFOblr.get('code')in['KO','KO_CC']:
     CMHiVyzBwukmsJhaNgoSeXqjtFObKA['subtitleYn']=CMHiVyzBwukmsJhaNgoSeXqjtFObnx
     break
  return CMHiVyzBwukmsJhaNgoSeXqjtFObKA
 def Tving_Parse_mpd(CMHiVyzBwukmsJhaNgoSeXqjtFObER,stream_url,watermarkKey=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,watermark=CMHiVyzBwukmsJhaNgoSeXqjtFObnL):
  if watermarkKey not in['',CMHiVyzBwukmsJhaNgoSeXqjtFObnL]:
   CMHiVyzBwukmsJhaNgoSeXqjtFOblQ={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,'Access-Control-Request-Headers':'x-tving-param1,x-tving-param2',}
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=requests.get(url=stream_url,headers=CMHiVyzBwukmsJhaNgoSeXqjtFOblQ,allow_redirects=CMHiVyzBwukmsJhaNgoSeXqjtFObnY)
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.status_code)+' - '+CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.url))
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ('')
  else:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=requests.get(url=stream_url)
  CMHiVyzBwukmsJhaNgoSeXqjtFOblT=CMHiVyzBwukmsJhaNgoSeXqjtFObKD.content.decode('utf-8')
  CMHiVyzBwukmsJhaNgoSeXqjtFObld=0
  CMHiVyzBwukmsJhaNgoSeXqjtFOblL =ET.ElementTree(ET.fromstring(CMHiVyzBwukmsJhaNgoSeXqjtFOblT))
  CMHiVyzBwukmsJhaNgoSeXqjtFOblY =CMHiVyzBwukmsJhaNgoSeXqjtFOblL.getroot()
  CMHiVyzBwukmsJhaNgoSeXqjtFOblU=re.match(r'\{.*\}',CMHiVyzBwukmsJhaNgoSeXqjtFOblY.tag)[0] 
  CMHiVyzBwukmsJhaNgoSeXqjtFOblx=CMHiVyzBwukmsJhaNgoSeXqjtFObIE([node for _,node in ET.iterparse(io.StringIO(CMHiVyzBwukmsJhaNgoSeXqjtFOblT),events=['start-ns'])])
  for CMHiVyzBwukmsJhaNgoSeXqjtFOblK,CMHiVyzBwukmsJhaNgoSeXqjtFObWr in CMHiVyzBwukmsJhaNgoSeXqjtFOblx.items():
   if CMHiVyzBwukmsJhaNgoSeXqjtFOblK!='ns2':
    ET.register_namespace(CMHiVyzBwukmsJhaNgoSeXqjtFOblK,CMHiVyzBwukmsJhaNgoSeXqjtFObWr)
  CMHiVyzBwukmsJhaNgoSeXqjtFOblA=CMHiVyzBwukmsJhaNgoSeXqjtFOblY.find(CMHiVyzBwukmsJhaNgoSeXqjtFOblU+'Period')
  for CMHiVyzBwukmsJhaNgoSeXqjtFOblf in CMHiVyzBwukmsJhaNgoSeXqjtFOblA.findall(CMHiVyzBwukmsJhaNgoSeXqjtFOblU+'AdaptationSet'):
   if CMHiVyzBwukmsJhaNgoSeXqjtFOblf.attrib.get('mimeType')=='video/mp4':
    for CMHiVyzBwukmsJhaNgoSeXqjtFOblv in CMHiVyzBwukmsJhaNgoSeXqjtFOblf.findall(CMHiVyzBwukmsJhaNgoSeXqjtFOblU+'Representation'):
     CMHiVyzBwukmsJhaNgoSeXqjtFOblP=CMHiVyzBwukmsJhaNgoSeXqjtFObnA(CMHiVyzBwukmsJhaNgoSeXqjtFOblv.attrib.get('bandwidth'))
     if CMHiVyzBwukmsJhaNgoSeXqjtFObld<CMHiVyzBwukmsJhaNgoSeXqjtFOblP:CMHiVyzBwukmsJhaNgoSeXqjtFObld=CMHiVyzBwukmsJhaNgoSeXqjtFOblP
    for CMHiVyzBwukmsJhaNgoSeXqjtFOblv in CMHiVyzBwukmsJhaNgoSeXqjtFOblf.findall(CMHiVyzBwukmsJhaNgoSeXqjtFOblU+'Representation'):
     if CMHiVyzBwukmsJhaNgoSeXqjtFObld>CMHiVyzBwukmsJhaNgoSeXqjtFObnA(CMHiVyzBwukmsJhaNgoSeXqjtFOblv.attrib.get('bandwidth')):
      CMHiVyzBwukmsJhaNgoSeXqjtFOblf.remove(CMHiVyzBwukmsJhaNgoSeXqjtFOblv)
   else:
    continue
  CMHiVyzBwukmsJhaNgoSeXqjtFOblp=ET.tostring(CMHiVyzBwukmsJhaNgoSeXqjtFOblY).decode('utf-8')
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TextFile_Save(CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV_STREAM_FILENAME,CMHiVyzBwukmsJhaNgoSeXqjtFOblp)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObnx
 def Tving_Parse_m3u8(CMHiVyzBwukmsJhaNgoSeXqjtFObER,stream_url):
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=requests.get(url=stream_url,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,stream=CMHiVyzBwukmsJhaNgoSeXqjtFObnx)
   CMHiVyzBwukmsJhaNgoSeXqjtFObWE=CMHiVyzBwukmsJhaNgoSeXqjtFObKD.content.decode('utf-8')
   if '#EXTM3U' not in CMHiVyzBwukmsJhaNgoSeXqjtFObWE:
    return CMHiVyzBwukmsJhaNgoSeXqjtFObnY
   if '#EXT-X-STREAM-INF' not in CMHiVyzBwukmsJhaNgoSeXqjtFObWE: 
    return CMHiVyzBwukmsJhaNgoSeXqjtFObnY
   CMHiVyzBwukmsJhaNgoSeXqjtFObWK=0
   for CMHiVyzBwukmsJhaNgoSeXqjtFObWl in CMHiVyzBwukmsJhaNgoSeXqjtFObWE.splitlines():
    if CMHiVyzBwukmsJhaNgoSeXqjtFObWl.startswith('#EXT-X-STREAM-INF'):
     CMHiVyzBwukmsJhaNgoSeXqjtFObWD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.MediaLine_Parse(CMHiVyzBwukmsJhaNgoSeXqjtFObWl,'#EXT-X-STREAM-INF')
     if CMHiVyzBwukmsJhaNgoSeXqjtFObWK<CMHiVyzBwukmsJhaNgoSeXqjtFObnA(CMHiVyzBwukmsJhaNgoSeXqjtFObWD.get('BANDWIDTH')):
      CMHiVyzBwukmsJhaNgoSeXqjtFObWK=CMHiVyzBwukmsJhaNgoSeXqjtFObnA(CMHiVyzBwukmsJhaNgoSeXqjtFObWD.get('BANDWIDTH'))
   CMHiVyzBwukmsJhaNgoSeXqjtFObWR=[]
   CMHiVyzBwukmsJhaNgoSeXqjtFObWn=CMHiVyzBwukmsJhaNgoSeXqjtFObnY
   for CMHiVyzBwukmsJhaNgoSeXqjtFObWl in CMHiVyzBwukmsJhaNgoSeXqjtFObWE.splitlines():
    if CMHiVyzBwukmsJhaNgoSeXqjtFObWn==CMHiVyzBwukmsJhaNgoSeXqjtFObnx:
     CMHiVyzBwukmsJhaNgoSeXqjtFObWn=CMHiVyzBwukmsJhaNgoSeXqjtFObnY
     continue
    if CMHiVyzBwukmsJhaNgoSeXqjtFObWl.startswith('#EXT-X-STREAM-INF'):
     CMHiVyzBwukmsJhaNgoSeXqjtFObWD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.MediaLine_Parse(CMHiVyzBwukmsJhaNgoSeXqjtFObWl,'#EXT-X-STREAM-INF')
     if CMHiVyzBwukmsJhaNgoSeXqjtFObWK!=CMHiVyzBwukmsJhaNgoSeXqjtFObnA(CMHiVyzBwukmsJhaNgoSeXqjtFObWD.get('BANDWIDTH')):
      CMHiVyzBwukmsJhaNgoSeXqjtFObWn=CMHiVyzBwukmsJhaNgoSeXqjtFObnx
      continue
    CMHiVyzBwukmsJhaNgoSeXqjtFObWR.append(CMHiVyzBwukmsJhaNgoSeXqjtFObWl)
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
   return CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  CMHiVyzBwukmsJhaNgoSeXqjtFObWI='\n'.join(CMHiVyzBwukmsJhaNgoSeXqjtFObWR)
  CMHiVyzBwukmsJhaNgoSeXqjtFObER.TextFile_Save(CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV_STREAM_FILENAME,CMHiVyzBwukmsJhaNgoSeXqjtFObWI)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObnx
 def MediaLine_Parse(CMHiVyzBwukmsJhaNgoSeXqjtFObER,CMHiVyzBwukmsJhaNgoSeXqjtFObWl,prefix):
  CMHiVyzBwukmsJhaNgoSeXqjtFObWD={}
  for CMHiVyzBwukmsJhaNgoSeXqjtFObWc in CMHiVyzBwukmsJhaNgoSeXqjtFObED.split(CMHiVyzBwukmsJhaNgoSeXqjtFObWl.replace(prefix+':',''))[1::2]:
   CMHiVyzBwukmsJhaNgoSeXqjtFObWG,CMHiVyzBwukmsJhaNgoSeXqjtFObWr=CMHiVyzBwukmsJhaNgoSeXqjtFObWc.split('=',1)
   CMHiVyzBwukmsJhaNgoSeXqjtFObWD[CMHiVyzBwukmsJhaNgoSeXqjtFObWG.upper()]=CMHiVyzBwukmsJhaNgoSeXqjtFObWr.replace('"','').strip()
  return CMHiVyzBwukmsJhaNgoSeXqjtFObWD
 def CheckQuality(CMHiVyzBwukmsJhaNgoSeXqjtFObER,sel_qt,CMHiVyzBwukmsJhaNgoSeXqjtFOblD):
  for CMHiVyzBwukmsJhaNgoSeXqjtFObWQ in CMHiVyzBwukmsJhaNgoSeXqjtFOblD:
   if sel_qt>=CMHiVyzBwukmsJhaNgoSeXqjtFObIK(CMHiVyzBwukmsJhaNgoSeXqjtFObWQ)[0]:return CMHiVyzBwukmsJhaNgoSeXqjtFObWQ.get(CMHiVyzBwukmsJhaNgoSeXqjtFObIK(CMHiVyzBwukmsJhaNgoSeXqjtFObWQ)[0])
   CMHiVyzBwukmsJhaNgoSeXqjtFObWT=CMHiVyzBwukmsJhaNgoSeXqjtFObWQ.get(CMHiVyzBwukmsJhaNgoSeXqjtFObIK(CMHiVyzBwukmsJhaNgoSeXqjtFObWQ)[0])
  return CMHiVyzBwukmsJhaNgoSeXqjtFObWT
 def makeOocUrl(CMHiVyzBwukmsJhaNgoSeXqjtFObER,ooc_params):
  CMHiVyzBwukmsJhaNgoSeXqjtFOblE=''
  for CMHiVyzBwukmsJhaNgoSeXqjtFOblK,CMHiVyzBwukmsJhaNgoSeXqjtFObWd in ooc_params.items():
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE+="%s=%s^"%(CMHiVyzBwukmsJhaNgoSeXqjtFOblK,CMHiVyzBwukmsJhaNgoSeXqjtFObWd)
  return CMHiVyzBwukmsJhaNgoSeXqjtFOblE
 def GetLiveChannelList(CMHiVyzBwukmsJhaNgoSeXqjtFObER,stype,page_int):
  CMHiVyzBwukmsJhaNgoSeXqjtFObKQ=[]
  CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v2/media/lives'
   if stype=='onair': 
    CMHiVyzBwukmsJhaNgoSeXqjtFObWY='CPCS0100,CPCS0400'
   else:
    CMHiVyzBwukmsJhaNgoSeXqjtFObWY='CPCS0300'
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams()
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'cacheType':'main','pageNo':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(page_int),'pageSize':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObER.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':CMHiVyzBwukmsJhaNgoSeXqjtFObWY,}
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp.update(CMHiVyzBwukmsJhaNgoSeXqjtFObKL)
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKG
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKp,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKY=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   if not('result' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']):return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
   CMHiVyzBwukmsJhaNgoSeXqjtFObWU=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['result']
   for CMHiVyzBwukmsJhaNgoSeXqjtFObKU in CMHiVyzBwukmsJhaNgoSeXqjtFObWU:
    CMHiVyzBwukmsJhaNgoSeXqjtFObWx=CMHiVyzBwukmsJhaNgoSeXqjtFObWv=CMHiVyzBwukmsJhaNgoSeXqjtFObWP=''
    CMHiVyzBwukmsJhaNgoSeXqjtFObWA=CMHiVyzBwukmsJhaNgoSeXqjtFObDU=''
    CMHiVyzBwukmsJhaNgoSeXqjtFObWf=CMHiVyzBwukmsJhaNgoSeXqjtFObKU['live_code']
    CMHiVyzBwukmsJhaNgoSeXqjtFObWx =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['channel']['name']['ko']
    if CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['episode']!=CMHiVyzBwukmsJhaNgoSeXqjtFObnL:
     CMHiVyzBwukmsJhaNgoSeXqjtFObWv =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['program']['name']['ko']
     CMHiVyzBwukmsJhaNgoSeXqjtFObWv =CMHiVyzBwukmsJhaNgoSeXqjtFObWv+', '+CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['episode']['frequency'])+'회'
     CMHiVyzBwukmsJhaNgoSeXqjtFObWP=CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['episode']['synopsis']['ko']
    else:
     CMHiVyzBwukmsJhaNgoSeXqjtFObWv =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['program']['name']['ko']
     CMHiVyzBwukmsJhaNgoSeXqjtFObWP=CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['program']['synopsis']['ko']
    try: 
     CMHiVyzBwukmsJhaNgoSeXqjtFObWp =''
     CMHiVyzBwukmsJhaNgoSeXqjtFObDE =''
     CMHiVyzBwukmsJhaNgoSeXqjtFObDK=''
     CMHiVyzBwukmsJhaNgoSeXqjtFObDl =''
     CMHiVyzBwukmsJhaNgoSeXqjtFObDW =''
     CMHiVyzBwukmsJhaNgoSeXqjtFObDR =''
     for CMHiVyzBwukmsJhaNgoSeXqjtFObDn in CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['program']['image']:
      if CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP0900':CMHiVyzBwukmsJhaNgoSeXqjtFObDE =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
      elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP1800':CMHiVyzBwukmsJhaNgoSeXqjtFObDK=CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
      elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP2000':CMHiVyzBwukmsJhaNgoSeXqjtFObDl =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
      elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP1900':CMHiVyzBwukmsJhaNgoSeXqjtFObDW =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
      elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP0200':CMHiVyzBwukmsJhaNgoSeXqjtFObDR =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
      elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP0500':CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
      elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP0800':CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     if CMHiVyzBwukmsJhaNgoSeXqjtFObWp=='':
      for CMHiVyzBwukmsJhaNgoSeXqjtFObDn in CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['channel']['image']:
       if CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIC0400':CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
       elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIC1400':CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
       elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIC1900':CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
    except:
     CMHiVyzBwukmsJhaNgoSeXqjtFObnL
    try:
     CMHiVyzBwukmsJhaNgoSeXqjtFObDI =[]
     CMHiVyzBwukmsJhaNgoSeXqjtFObDc=[]
     CMHiVyzBwukmsJhaNgoSeXqjtFObDG =[]
     CMHiVyzBwukmsJhaNgoSeXqjtFObDr=''
     CMHiVyzBwukmsJhaNgoSeXqjtFObDQ=''
     CMHiVyzBwukmsJhaNgoSeXqjtFObDT=''
     for CMHiVyzBwukmsJhaNgoSeXqjtFObDd in CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('schedule').get('program').get('actor'):
      if CMHiVyzBwukmsJhaNgoSeXqjtFObDd!='' and CMHiVyzBwukmsJhaNgoSeXqjtFObDd!=u'없음':CMHiVyzBwukmsJhaNgoSeXqjtFObDI.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDd)
     for CMHiVyzBwukmsJhaNgoSeXqjtFObDL in CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('schedule').get('program').get('director'):
      if CMHiVyzBwukmsJhaNgoSeXqjtFObDL!='' and CMHiVyzBwukmsJhaNgoSeXqjtFObDL!='-' and CMHiVyzBwukmsJhaNgoSeXqjtFObDL!=u'없음':CMHiVyzBwukmsJhaNgoSeXqjtFObDc.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDL)
     if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('schedule').get('program').get('category1_name').get('ko')!='':
      CMHiVyzBwukmsJhaNgoSeXqjtFObDG.append(CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['program']['category1_name']['ko'])
     if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('schedule').get('program').get('category2_name').get('ko')!='':
      CMHiVyzBwukmsJhaNgoSeXqjtFObDG.append(CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['program']['category2_name']['ko'])
     if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('schedule').get('program').get('product_year'):CMHiVyzBwukmsJhaNgoSeXqjtFObDr=CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['program']['product_year']
     if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('schedule').get('program').get('grade_code') :CMHiVyzBwukmsJhaNgoSeXqjtFObDQ= CMHiVyzBwukmsJhaNgoSeXqjtFObEW.get(CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['program']['grade_code'])
     if 'broad_dt' in CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('schedule').get('program'):
      CMHiVyzBwukmsJhaNgoSeXqjtFObDY =CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('schedule').get('program').get('broad_dt')
      CMHiVyzBwukmsJhaNgoSeXqjtFObDT='%s-%s-%s'%(CMHiVyzBwukmsJhaNgoSeXqjtFObDY[:4],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[4:6],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[6:])
    except:
     CMHiVyzBwukmsJhaNgoSeXqjtFObnL
    CMHiVyzBwukmsJhaNgoSeXqjtFObWA=CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['broadcast_start_time'])[8:12]
    CMHiVyzBwukmsJhaNgoSeXqjtFObDU =CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObKU['schedule']['broadcast_end_time'])[8:12]
    CMHiVyzBwukmsJhaNgoSeXqjtFObDx={'channel':CMHiVyzBwukmsJhaNgoSeXqjtFObWx,'title':CMHiVyzBwukmsJhaNgoSeXqjtFObWv,'mediacode':CMHiVyzBwukmsJhaNgoSeXqjtFObWf,'thumbnail':{'poster':CMHiVyzBwukmsJhaNgoSeXqjtFObDE,'thumb':CMHiVyzBwukmsJhaNgoSeXqjtFObWp,'clearlogo':CMHiVyzBwukmsJhaNgoSeXqjtFObDK,'icon':CMHiVyzBwukmsJhaNgoSeXqjtFObDl,'fanart':CMHiVyzBwukmsJhaNgoSeXqjtFObDR},'synopsis':CMHiVyzBwukmsJhaNgoSeXqjtFObWP,'channelepg':' [%s:%s ~ %s:%s]'%(CMHiVyzBwukmsJhaNgoSeXqjtFObWA[0:2],CMHiVyzBwukmsJhaNgoSeXqjtFObWA[2:],CMHiVyzBwukmsJhaNgoSeXqjtFObDU[0:2],CMHiVyzBwukmsJhaNgoSeXqjtFObDU[2:]),'cast':CMHiVyzBwukmsJhaNgoSeXqjtFObDI,'director':CMHiVyzBwukmsJhaNgoSeXqjtFObDc,'info_genre':CMHiVyzBwukmsJhaNgoSeXqjtFObDG,'year':CMHiVyzBwukmsJhaNgoSeXqjtFObDr,'mpaa':CMHiVyzBwukmsJhaNgoSeXqjtFObDQ,'premiered':CMHiVyzBwukmsJhaNgoSeXqjtFObDT}
    CMHiVyzBwukmsJhaNgoSeXqjtFObKQ.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDx)
   if CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['has_more']=='Y':
    CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnx
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
 def GetProgramList(CMHiVyzBwukmsJhaNgoSeXqjtFObER,genre,orderby,page_int,genreCode='all'):
  CMHiVyzBwukmsJhaNgoSeXqjtFObKQ=[]
  CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  try:
   if genre=='PARAMOUNT':
    CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v2/media/paramount/episodes'
   else:
    CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v2/media/episodes'
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams()
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'cacheType':'main','pageSize':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObER.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(page_int),}
   if genre not in['all','PARAMOUNT']:CMHiVyzBwukmsJhaNgoSeXqjtFObKL['categoryCode']=genre
   if genreCode!='all' :CMHiVyzBwukmsJhaNgoSeXqjtFObKL['genreCode'] =genreCode 
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp.update(CMHiVyzBwukmsJhaNgoSeXqjtFObKL)
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKG
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKp,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKY=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   if not('result' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']):return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
   CMHiVyzBwukmsJhaNgoSeXqjtFObWU=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['result']
   for CMHiVyzBwukmsJhaNgoSeXqjtFObKU in CMHiVyzBwukmsJhaNgoSeXqjtFObWU:
    CMHiVyzBwukmsJhaNgoSeXqjtFObDA=CMHiVyzBwukmsJhaNgoSeXqjtFObKU['program']['code']
    CMHiVyzBwukmsJhaNgoSeXqjtFObWv =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['program']['name']['ko']
    CMHiVyzBwukmsJhaNgoSeXqjtFObDQ =CMHiVyzBwukmsJhaNgoSeXqjtFObEW.get(CMHiVyzBwukmsJhaNgoSeXqjtFObKU['program'].get('grade_code'))
    CMHiVyzBwukmsJhaNgoSeXqjtFObDE =''
    CMHiVyzBwukmsJhaNgoSeXqjtFObWp =''
    CMHiVyzBwukmsJhaNgoSeXqjtFObDK=''
    CMHiVyzBwukmsJhaNgoSeXqjtFObDl =''
    CMHiVyzBwukmsJhaNgoSeXqjtFObDW =''
    for CMHiVyzBwukmsJhaNgoSeXqjtFObDn in CMHiVyzBwukmsJhaNgoSeXqjtFObKU['program']['image']:
     if CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP0900':CMHiVyzBwukmsJhaNgoSeXqjtFObDE =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP0200':CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP1800':CMHiVyzBwukmsJhaNgoSeXqjtFObDK=CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP2000':CMHiVyzBwukmsJhaNgoSeXqjtFObDl =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP1900':CMHiVyzBwukmsJhaNgoSeXqjtFObDW =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
    CMHiVyzBwukmsJhaNgoSeXqjtFObWP =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['program']['synopsis']['ko']
    try:
     CMHiVyzBwukmsJhaNgoSeXqjtFObDf=CMHiVyzBwukmsJhaNgoSeXqjtFObKU['channel']['name']['ko']
    except:
     CMHiVyzBwukmsJhaNgoSeXqjtFObDf=''
    try:
     CMHiVyzBwukmsJhaNgoSeXqjtFObDI =[]
     CMHiVyzBwukmsJhaNgoSeXqjtFObDc=[]
     CMHiVyzBwukmsJhaNgoSeXqjtFObDG =[]
     CMHiVyzBwukmsJhaNgoSeXqjtFObDr =''
     CMHiVyzBwukmsJhaNgoSeXqjtFObDT=''
     for CMHiVyzBwukmsJhaNgoSeXqjtFObDd in CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('program').get('actor'):
      if CMHiVyzBwukmsJhaNgoSeXqjtFObDd!='' and CMHiVyzBwukmsJhaNgoSeXqjtFObDd!='-' and CMHiVyzBwukmsJhaNgoSeXqjtFObDd!=u'없음':CMHiVyzBwukmsJhaNgoSeXqjtFObDI.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDd)
     for CMHiVyzBwukmsJhaNgoSeXqjtFObDL in CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('program').get('director'):
      if CMHiVyzBwukmsJhaNgoSeXqjtFObDL!='' and CMHiVyzBwukmsJhaNgoSeXqjtFObDL!='-' and CMHiVyzBwukmsJhaNgoSeXqjtFObDL!=u'없음':CMHiVyzBwukmsJhaNgoSeXqjtFObDc.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDL)
     if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('program').get('category1_name').get('ko')!='':
      CMHiVyzBwukmsJhaNgoSeXqjtFObDG.append(CMHiVyzBwukmsJhaNgoSeXqjtFObKU['program']['category1_name']['ko'])
     if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('program').get('category2_name').get('ko')!='':
      CMHiVyzBwukmsJhaNgoSeXqjtFObDG.append(CMHiVyzBwukmsJhaNgoSeXqjtFObKU['program']['category2_name']['ko'])
     if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('program').get('product_year'):CMHiVyzBwukmsJhaNgoSeXqjtFObDr=CMHiVyzBwukmsJhaNgoSeXqjtFObKU['program']['product_year']
     if 'broad_dt' in CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('program'):
      CMHiVyzBwukmsJhaNgoSeXqjtFObDY =CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('program').get('broad_dt')
      CMHiVyzBwukmsJhaNgoSeXqjtFObDT='%s-%s-%s'%(CMHiVyzBwukmsJhaNgoSeXqjtFObDY[:4],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[4:6],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[6:])
    except:
     CMHiVyzBwukmsJhaNgoSeXqjtFObnL
    CMHiVyzBwukmsJhaNgoSeXqjtFObDx={'program':CMHiVyzBwukmsJhaNgoSeXqjtFObDA,'title':CMHiVyzBwukmsJhaNgoSeXqjtFObWv,'thumbnail':{'poster':CMHiVyzBwukmsJhaNgoSeXqjtFObDE,'thumb':CMHiVyzBwukmsJhaNgoSeXqjtFObWp,'clearlogo':CMHiVyzBwukmsJhaNgoSeXqjtFObDK,'icon':CMHiVyzBwukmsJhaNgoSeXqjtFObDl,'banner':CMHiVyzBwukmsJhaNgoSeXqjtFObDW,'fanart':CMHiVyzBwukmsJhaNgoSeXqjtFObWp},'synopsis':CMHiVyzBwukmsJhaNgoSeXqjtFObWP,'channel':CMHiVyzBwukmsJhaNgoSeXqjtFObDf,'cast':CMHiVyzBwukmsJhaNgoSeXqjtFObDI,'director':CMHiVyzBwukmsJhaNgoSeXqjtFObDc,'info_genre':CMHiVyzBwukmsJhaNgoSeXqjtFObDG,'year':CMHiVyzBwukmsJhaNgoSeXqjtFObDr,'premiered':CMHiVyzBwukmsJhaNgoSeXqjtFObDT,'mpaa':CMHiVyzBwukmsJhaNgoSeXqjtFObDQ}
    CMHiVyzBwukmsJhaNgoSeXqjtFObKQ.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDx)
   if CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['has_more']=='Y':CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnx
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
 def Get_UHD_ProgramList(CMHiVyzBwukmsJhaNgoSeXqjtFObER,page_int):
  CMHiVyzBwukmsJhaNgoSeXqjtFObKQ=[]
  CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v2/operator/highlights'
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams(uhd=CMHiVyzBwukmsJhaNgoSeXqjtFObnx)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(page_int),'pocType':'APP_X_TVING_4.0.0',}
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp.update(CMHiVyzBwukmsJhaNgoSeXqjtFObKL)
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKG
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKp,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKY=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   if not('result' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']):return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
   CMHiVyzBwukmsJhaNgoSeXqjtFObWU=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['result']
   for CMHiVyzBwukmsJhaNgoSeXqjtFObKU in CMHiVyzBwukmsJhaNgoSeXqjtFObWU:
    CMHiVyzBwukmsJhaNgoSeXqjtFObDv=CMHiVyzBwukmsJhaNgoSeXqjtFObKU['content']['program']
    CMHiVyzBwukmsJhaNgoSeXqjtFObDP =CMHiVyzBwukmsJhaNgoSeXqjtFObDv['code']
    CMHiVyzBwukmsJhaNgoSeXqjtFObWv =CMHiVyzBwukmsJhaNgoSeXqjtFObDv['name']['ko'].strip()
    CMHiVyzBwukmsJhaNgoSeXqjtFObDQ =CMHiVyzBwukmsJhaNgoSeXqjtFObEW.get(CMHiVyzBwukmsJhaNgoSeXqjtFObDv.get('grade_code'))
    CMHiVyzBwukmsJhaNgoSeXqjtFObWP =CMHiVyzBwukmsJhaNgoSeXqjtFObDv['synopsis']['ko']
    CMHiVyzBwukmsJhaNgoSeXqjtFObDf =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['content']['channel']['name']['ko']
    CMHiVyzBwukmsJhaNgoSeXqjtFObDr =CMHiVyzBwukmsJhaNgoSeXqjtFObDv['product_year']
    CMHiVyzBwukmsJhaNgoSeXqjtFObDE =''
    CMHiVyzBwukmsJhaNgoSeXqjtFObWp =''
    CMHiVyzBwukmsJhaNgoSeXqjtFObDK=''
    CMHiVyzBwukmsJhaNgoSeXqjtFObDl =''
    CMHiVyzBwukmsJhaNgoSeXqjtFObDW =''
    for CMHiVyzBwukmsJhaNgoSeXqjtFObDn in CMHiVyzBwukmsJhaNgoSeXqjtFObDv['image']:
     if CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP0900':CMHiVyzBwukmsJhaNgoSeXqjtFObDE =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP0200':CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP1800':CMHiVyzBwukmsJhaNgoSeXqjtFObDK=CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP2000':CMHiVyzBwukmsJhaNgoSeXqjtFObDl =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP1900':CMHiVyzBwukmsJhaNgoSeXqjtFObDW =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
    CMHiVyzBwukmsJhaNgoSeXqjtFObDG =[]
    CMHiVyzBwukmsJhaNgoSeXqjtFObDI =[]
    CMHiVyzBwukmsJhaNgoSeXqjtFObDc=[]
    CMHiVyzBwukmsJhaNgoSeXqjtFObDT =''
    if CMHiVyzBwukmsJhaNgoSeXqjtFObDv.get('category1_name').get('ko')!='':
     CMHiVyzBwukmsJhaNgoSeXqjtFObDG.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDv['category1_name']['ko'])
    if CMHiVyzBwukmsJhaNgoSeXqjtFObDv.get('category2_name').get('ko')!='':
     CMHiVyzBwukmsJhaNgoSeXqjtFObDG.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDv['category2_name']['ko'])
    for CMHiVyzBwukmsJhaNgoSeXqjtFObDd in CMHiVyzBwukmsJhaNgoSeXqjtFObDv.get('actor'):
     if CMHiVyzBwukmsJhaNgoSeXqjtFObDd!='' and CMHiVyzBwukmsJhaNgoSeXqjtFObDd!='-' and CMHiVyzBwukmsJhaNgoSeXqjtFObDd!=u'없음':CMHiVyzBwukmsJhaNgoSeXqjtFObDI.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDd)
    for CMHiVyzBwukmsJhaNgoSeXqjtFObDL in CMHiVyzBwukmsJhaNgoSeXqjtFObDv.get('director'):
     if CMHiVyzBwukmsJhaNgoSeXqjtFObDL!='' and CMHiVyzBwukmsJhaNgoSeXqjtFObDL!='-' and CMHiVyzBwukmsJhaNgoSeXqjtFObDL!=u'없음':CMHiVyzBwukmsJhaNgoSeXqjtFObDc.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDL)
    if CMHiVyzBwukmsJhaNgoSeXqjtFObDv.get('broad_dt')not in[CMHiVyzBwukmsJhaNgoSeXqjtFObnL,'']:
     CMHiVyzBwukmsJhaNgoSeXqjtFObDY =CMHiVyzBwukmsJhaNgoSeXqjtFObDv.get('broad_dt')
     CMHiVyzBwukmsJhaNgoSeXqjtFObDT='%s-%s-%s'%(CMHiVyzBwukmsJhaNgoSeXqjtFObDY[:4],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[4:6],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[6:])
    CMHiVyzBwukmsJhaNgoSeXqjtFObDx={'program':CMHiVyzBwukmsJhaNgoSeXqjtFObDP,'title':CMHiVyzBwukmsJhaNgoSeXqjtFObWv,'mpaa':CMHiVyzBwukmsJhaNgoSeXqjtFObDQ,'thumbnail':{'poster':CMHiVyzBwukmsJhaNgoSeXqjtFObDE,'thumb':CMHiVyzBwukmsJhaNgoSeXqjtFObWp,'clearlogo':CMHiVyzBwukmsJhaNgoSeXqjtFObDK,'icon':CMHiVyzBwukmsJhaNgoSeXqjtFObDl,'banner':CMHiVyzBwukmsJhaNgoSeXqjtFObDW,'fanart':CMHiVyzBwukmsJhaNgoSeXqjtFObWp},'channel':CMHiVyzBwukmsJhaNgoSeXqjtFObDf,'synopsis':CMHiVyzBwukmsJhaNgoSeXqjtFObWP,'year':CMHiVyzBwukmsJhaNgoSeXqjtFObDr,'info_genre':CMHiVyzBwukmsJhaNgoSeXqjtFObDG,'cast':CMHiVyzBwukmsJhaNgoSeXqjtFObDI,'director':CMHiVyzBwukmsJhaNgoSeXqjtFObDc,'premiered':CMHiVyzBwukmsJhaNgoSeXqjtFObDT,}
    CMHiVyzBwukmsJhaNgoSeXqjtFObKQ.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDx)
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
 def Get_Origianl_ProgramList(CMHiVyzBwukmsJhaNgoSeXqjtFObER,page_int):
  CMHiVyzBwukmsJhaNgoSeXqjtFObKQ=[]
  CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v2/media/band/originals'
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams()
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'pageSize':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObER.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(page_int),}
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp.update(CMHiVyzBwukmsJhaNgoSeXqjtFObKL)
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKG
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKp,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKY=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   if not('contents' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']):return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
   CMHiVyzBwukmsJhaNgoSeXqjtFObWU=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['contents']
   for CMHiVyzBwukmsJhaNgoSeXqjtFObKU in CMHiVyzBwukmsJhaNgoSeXqjtFObWU:
    CMHiVyzBwukmsJhaNgoSeXqjtFObDA=CMHiVyzBwukmsJhaNgoSeXqjtFObKU['vod_code']
    CMHiVyzBwukmsJhaNgoSeXqjtFObWv =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['vod_name']
    CMHiVyzBwukmsJhaNgoSeXqjtFObDE =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKU['image']
    CMHiVyzBwukmsJhaNgoSeXqjtFObDx={'program':CMHiVyzBwukmsJhaNgoSeXqjtFObDA,'title':CMHiVyzBwukmsJhaNgoSeXqjtFObWv,'thumbnail':{'poster':CMHiVyzBwukmsJhaNgoSeXqjtFObDE,'thumb':CMHiVyzBwukmsJhaNgoSeXqjtFObDE}}
    CMHiVyzBwukmsJhaNgoSeXqjtFObKQ.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDx)
   if CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['has_more']=='Y':CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnx
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
 def GetEpisodeList(CMHiVyzBwukmsJhaNgoSeXqjtFObER,program_code,page_int,orderby='desc'):
  CMHiVyzBwukmsJhaNgoSeXqjtFObKQ=[]
  CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v2/media/frequency/program/'+program_code
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams()
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp.update(CMHiVyzBwukmsJhaNgoSeXqjtFObKL)
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKG
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKp,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKY=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   if not('result' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']):return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
   CMHiVyzBwukmsJhaNgoSeXqjtFObWU=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['result']
   CMHiVyzBwukmsJhaNgoSeXqjtFObDp=CMHiVyzBwukmsJhaNgoSeXqjtFObnA(CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['total_count'])
   CMHiVyzBwukmsJhaNgoSeXqjtFObRE =CMHiVyzBwukmsJhaNgoSeXqjtFObnA(CMHiVyzBwukmsJhaNgoSeXqjtFObDp//(CMHiVyzBwukmsJhaNgoSeXqjtFObER.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    CMHiVyzBwukmsJhaNgoSeXqjtFObRK =(CMHiVyzBwukmsJhaNgoSeXqjtFObDp-1)-((page_int-1)*CMHiVyzBwukmsJhaNgoSeXqjtFObER.EPISODE_LIMIT)
   else:
    CMHiVyzBwukmsJhaNgoSeXqjtFObRK =(page_int-1)*CMHiVyzBwukmsJhaNgoSeXqjtFObER.EPISODE_LIMIT
   for i in CMHiVyzBwukmsJhaNgoSeXqjtFObnf(CMHiVyzBwukmsJhaNgoSeXqjtFObER.EPISODE_LIMIT):
    if orderby=='desc':
     CMHiVyzBwukmsJhaNgoSeXqjtFObRl=CMHiVyzBwukmsJhaNgoSeXqjtFObRK-i
     if CMHiVyzBwukmsJhaNgoSeXqjtFObRl<0:break
    else:
     CMHiVyzBwukmsJhaNgoSeXqjtFObRl=CMHiVyzBwukmsJhaNgoSeXqjtFObRK+i
     if CMHiVyzBwukmsJhaNgoSeXqjtFObRl>=CMHiVyzBwukmsJhaNgoSeXqjtFObDp:break
    CMHiVyzBwukmsJhaNgoSeXqjtFObRW=CMHiVyzBwukmsJhaNgoSeXqjtFObWU[CMHiVyzBwukmsJhaNgoSeXqjtFObRl]['episode']['code']
    CMHiVyzBwukmsJhaNgoSeXqjtFObWv =CMHiVyzBwukmsJhaNgoSeXqjtFObWU[CMHiVyzBwukmsJhaNgoSeXqjtFObRl]['vod_name']['ko']
    CMHiVyzBwukmsJhaNgoSeXqjtFObRD =''
    try:
     CMHiVyzBwukmsJhaNgoSeXqjtFObDY=CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObWU[CMHiVyzBwukmsJhaNgoSeXqjtFObRl]['episode']['broadcast_date'])
     CMHiVyzBwukmsJhaNgoSeXqjtFObRD='%s-%s-%s'%(CMHiVyzBwukmsJhaNgoSeXqjtFObDY[:4],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[4:6],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[6:])
    except:
     CMHiVyzBwukmsJhaNgoSeXqjtFObnL
    try:
     if CMHiVyzBwukmsJhaNgoSeXqjtFObWU[CMHiVyzBwukmsJhaNgoSeXqjtFObRl]['episode']['pip_cliptype']=='C012':
      CMHiVyzBwukmsJhaNgoSeXqjtFObRD+=' - Quick VOD'
    except:
     CMHiVyzBwukmsJhaNgoSeXqjtFObnL
    CMHiVyzBwukmsJhaNgoSeXqjtFObWP =CMHiVyzBwukmsJhaNgoSeXqjtFObWU[CMHiVyzBwukmsJhaNgoSeXqjtFObRl]['episode']['synopsis']['ko']
    CMHiVyzBwukmsJhaNgoSeXqjtFObDE =''
    CMHiVyzBwukmsJhaNgoSeXqjtFObWp =''
    CMHiVyzBwukmsJhaNgoSeXqjtFObDK=''
    CMHiVyzBwukmsJhaNgoSeXqjtFObDl =''
    CMHiVyzBwukmsJhaNgoSeXqjtFObDW =''
    CMHiVyzBwukmsJhaNgoSeXqjtFObDR =''
    for CMHiVyzBwukmsJhaNgoSeXqjtFObDn in CMHiVyzBwukmsJhaNgoSeXqjtFObWU[CMHiVyzBwukmsJhaNgoSeXqjtFObRl]['program']['image']:
     if CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP0900':CMHiVyzBwukmsJhaNgoSeXqjtFObDE =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP1800':CMHiVyzBwukmsJhaNgoSeXqjtFObDK=CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP2000':CMHiVyzBwukmsJhaNgoSeXqjtFObDl =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP1900':CMHiVyzBwukmsJhaNgoSeXqjtFObDW =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIP0200':CMHiVyzBwukmsJhaNgoSeXqjtFObDR =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
    for CMHiVyzBwukmsJhaNgoSeXqjtFObDn in CMHiVyzBwukmsJhaNgoSeXqjtFObWU[CMHiVyzBwukmsJhaNgoSeXqjtFObRl]['episode']['image']:
     if CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIE0400':CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
    try:
     CMHiVyzBwukmsJhaNgoSeXqjtFObRn=CMHiVyzBwukmsJhaNgoSeXqjtFObRc=CMHiVyzBwukmsJhaNgoSeXqjtFObRG=''
     CMHiVyzBwukmsJhaNgoSeXqjtFObRI=0
     CMHiVyzBwukmsJhaNgoSeXqjtFObRn =CMHiVyzBwukmsJhaNgoSeXqjtFObWU[CMHiVyzBwukmsJhaNgoSeXqjtFObRl]['program']['name']['ko']
     CMHiVyzBwukmsJhaNgoSeXqjtFObRc =CMHiVyzBwukmsJhaNgoSeXqjtFObRD
     CMHiVyzBwukmsJhaNgoSeXqjtFObRG =CMHiVyzBwukmsJhaNgoSeXqjtFObWU[CMHiVyzBwukmsJhaNgoSeXqjtFObRl]['channel']['name']['ko']
     if 'frequency' in CMHiVyzBwukmsJhaNgoSeXqjtFObWU[CMHiVyzBwukmsJhaNgoSeXqjtFObRl]['episode']:CMHiVyzBwukmsJhaNgoSeXqjtFObRI=CMHiVyzBwukmsJhaNgoSeXqjtFObWU[CMHiVyzBwukmsJhaNgoSeXqjtFObRl]['episode']['frequency']
    except:
     CMHiVyzBwukmsJhaNgoSeXqjtFObnL
    CMHiVyzBwukmsJhaNgoSeXqjtFObDx={'episode':CMHiVyzBwukmsJhaNgoSeXqjtFObRW,'title':CMHiVyzBwukmsJhaNgoSeXqjtFObWv,'subtitle':CMHiVyzBwukmsJhaNgoSeXqjtFObRD,'thumbnail':{'poster':CMHiVyzBwukmsJhaNgoSeXqjtFObDE,'thumb':CMHiVyzBwukmsJhaNgoSeXqjtFObWp,'clearlogo':CMHiVyzBwukmsJhaNgoSeXqjtFObDK,'icon':CMHiVyzBwukmsJhaNgoSeXqjtFObDl,'banner':CMHiVyzBwukmsJhaNgoSeXqjtFObDW,'fanart':CMHiVyzBwukmsJhaNgoSeXqjtFObDR},'synopsis':CMHiVyzBwukmsJhaNgoSeXqjtFObWP,'info_title':CMHiVyzBwukmsJhaNgoSeXqjtFObRn,'aired':CMHiVyzBwukmsJhaNgoSeXqjtFObRc,'studio':CMHiVyzBwukmsJhaNgoSeXqjtFObRG,'frequency':CMHiVyzBwukmsJhaNgoSeXqjtFObRI}
    CMHiVyzBwukmsJhaNgoSeXqjtFObKQ.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDx)
   if CMHiVyzBwukmsJhaNgoSeXqjtFObRE>page_int:CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnx
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL,CMHiVyzBwukmsJhaNgoSeXqjtFObRE
 def GetMovieList(CMHiVyzBwukmsJhaNgoSeXqjtFObER,genre,orderby,page_int):
  CMHiVyzBwukmsJhaNgoSeXqjtFObKQ=[]
  CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  try:
   if genre=='PARAMOUNT':
    CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v2/media/paramount/movies'
   else:
    CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v2/media/movies'
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams()
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'pageSize':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObER.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:CMHiVyzBwukmsJhaNgoSeXqjtFObKL['categoryCode']=genre
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL['productPackageCode']=','.join(CMHiVyzBwukmsJhaNgoSeXqjtFObER.MOVIE_LITE)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp.update(CMHiVyzBwukmsJhaNgoSeXqjtFObKL)
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKG
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKp,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKY=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   if not('result' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']):return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
   CMHiVyzBwukmsJhaNgoSeXqjtFObWU=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['result']
   for CMHiVyzBwukmsJhaNgoSeXqjtFObKU in CMHiVyzBwukmsJhaNgoSeXqjtFObWU:
    if 'release_date' in CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('movie'):
     CMHiVyzBwukmsJhaNgoSeXqjtFObDr=CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('movie').get('release_date'))[:4]
    else:
     CMHiVyzBwukmsJhaNgoSeXqjtFObDr=CMHiVyzBwukmsJhaNgoSeXqjtFObnL
    CMHiVyzBwukmsJhaNgoSeXqjtFObRr =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['movie']['code']
    CMHiVyzBwukmsJhaNgoSeXqjtFObWv =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['movie']['name']['ko'].strip()
    if CMHiVyzBwukmsJhaNgoSeXqjtFObDr not in[CMHiVyzBwukmsJhaNgoSeXqjtFObnL,'0','']:CMHiVyzBwukmsJhaNgoSeXqjtFObWv+=u' (%s)'%(CMHiVyzBwukmsJhaNgoSeXqjtFObDr)
    CMHiVyzBwukmsJhaNgoSeXqjtFObDE=''
    CMHiVyzBwukmsJhaNgoSeXqjtFObWp =''
    CMHiVyzBwukmsJhaNgoSeXqjtFObDK=''
    for CMHiVyzBwukmsJhaNgoSeXqjtFObDn in CMHiVyzBwukmsJhaNgoSeXqjtFObKU['movie']['image']:
     if CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIM2100':CMHiVyzBwukmsJhaNgoSeXqjtFObDE =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIM0400':CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIM1800':CMHiVyzBwukmsJhaNgoSeXqjtFObDK=CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
    CMHiVyzBwukmsJhaNgoSeXqjtFObWP =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['movie']['story']['ko']
    try:
     CMHiVyzBwukmsJhaNgoSeXqjtFObRn =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['movie']['name']['ko'].strip()
     CMHiVyzBwukmsJhaNgoSeXqjtFObDQ =CMHiVyzBwukmsJhaNgoSeXqjtFObEW.get(CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('grade_code'))
     CMHiVyzBwukmsJhaNgoSeXqjtFObDI=[]
     CMHiVyzBwukmsJhaNgoSeXqjtFObDc=[]
     CMHiVyzBwukmsJhaNgoSeXqjtFObDG=[]
     CMHiVyzBwukmsJhaNgoSeXqjtFObRQ=0
     CMHiVyzBwukmsJhaNgoSeXqjtFObDT=''
     CMHiVyzBwukmsJhaNgoSeXqjtFObRG =''
     for CMHiVyzBwukmsJhaNgoSeXqjtFObDd in CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('movie').get('actor'):
      if CMHiVyzBwukmsJhaNgoSeXqjtFObDd!='':CMHiVyzBwukmsJhaNgoSeXqjtFObDI.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDd)
     for CMHiVyzBwukmsJhaNgoSeXqjtFObDL in CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('movie').get('director'):
      if CMHiVyzBwukmsJhaNgoSeXqjtFObDL!='':CMHiVyzBwukmsJhaNgoSeXqjtFObDc.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDL)
     if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('movie').get('category1_name').get('ko')!='':
      CMHiVyzBwukmsJhaNgoSeXqjtFObDG.append(CMHiVyzBwukmsJhaNgoSeXqjtFObKU['movie']['category1_name']['ko'])
     if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('movie').get('category2_name').get('ko')!='':
      CMHiVyzBwukmsJhaNgoSeXqjtFObDG.append(CMHiVyzBwukmsJhaNgoSeXqjtFObKU['movie']['category2_name']['ko'])
     if 'duration' in CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('movie'):CMHiVyzBwukmsJhaNgoSeXqjtFObRQ=CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('movie').get('duration')
     if 'release_date' in CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('movie'):
      CMHiVyzBwukmsJhaNgoSeXqjtFObDY=CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('movie').get('release_date'))
      if CMHiVyzBwukmsJhaNgoSeXqjtFObDY!='0':CMHiVyzBwukmsJhaNgoSeXqjtFObDT='%s-%s-%s'%(CMHiVyzBwukmsJhaNgoSeXqjtFObDY[:4],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[4:6],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[6:])
     if 'production' in CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('movie'):CMHiVyzBwukmsJhaNgoSeXqjtFObRG=CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('movie').get('production')
    except:
     CMHiVyzBwukmsJhaNgoSeXqjtFObnL
    CMHiVyzBwukmsJhaNgoSeXqjtFObDx={'moviecode':CMHiVyzBwukmsJhaNgoSeXqjtFObRr,'title':CMHiVyzBwukmsJhaNgoSeXqjtFObWv,'thumbnail':{'poster':CMHiVyzBwukmsJhaNgoSeXqjtFObDE,'thumb':CMHiVyzBwukmsJhaNgoSeXqjtFObWp,'clearlogo':CMHiVyzBwukmsJhaNgoSeXqjtFObDK,'fanart':CMHiVyzBwukmsJhaNgoSeXqjtFObWp},'synopsis':CMHiVyzBwukmsJhaNgoSeXqjtFObWP,'info_title':CMHiVyzBwukmsJhaNgoSeXqjtFObRn,'year':CMHiVyzBwukmsJhaNgoSeXqjtFObDr,'cast':CMHiVyzBwukmsJhaNgoSeXqjtFObDI,'director':CMHiVyzBwukmsJhaNgoSeXqjtFObDc,'info_genre':CMHiVyzBwukmsJhaNgoSeXqjtFObDG,'duration':CMHiVyzBwukmsJhaNgoSeXqjtFObRQ,'premiered':CMHiVyzBwukmsJhaNgoSeXqjtFObDT,'studio':CMHiVyzBwukmsJhaNgoSeXqjtFObRG,'mpaa':CMHiVyzBwukmsJhaNgoSeXqjtFObDQ}
    CMHiVyzBwukmsJhaNgoSeXqjtFObRT=CMHiVyzBwukmsJhaNgoSeXqjtFObnY
    for CMHiVyzBwukmsJhaNgoSeXqjtFObRd in CMHiVyzBwukmsJhaNgoSeXqjtFObKU['billing_package_id']:
     if CMHiVyzBwukmsJhaNgoSeXqjtFObRd in CMHiVyzBwukmsJhaNgoSeXqjtFObER.MOVIE_LITE:
      CMHiVyzBwukmsJhaNgoSeXqjtFObRT=CMHiVyzBwukmsJhaNgoSeXqjtFObnx
      break
    if CMHiVyzBwukmsJhaNgoSeXqjtFObRT==CMHiVyzBwukmsJhaNgoSeXqjtFObnY: 
     CMHiVyzBwukmsJhaNgoSeXqjtFObDx['title']=CMHiVyzBwukmsJhaNgoSeXqjtFObDx['title']+' [개별구매]'
    CMHiVyzBwukmsJhaNgoSeXqjtFObKQ.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDx)
   if CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['has_more']=='Y':CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnx
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
 def Get_UHD_MovieList(CMHiVyzBwukmsJhaNgoSeXqjtFObER,page_int):
  CMHiVyzBwukmsJhaNgoSeXqjtFObKQ=[]
  CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v2/operator/highlights'
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams(uhd=CMHiVyzBwukmsJhaNgoSeXqjtFObnx)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(page_int),'pocType':'APP_X_TVING_4.0.0',}
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp.update(CMHiVyzBwukmsJhaNgoSeXqjtFObKL)
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKG
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKp,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKY=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   if not('result' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']):return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
   CMHiVyzBwukmsJhaNgoSeXqjtFObWU=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['result']
   for CMHiVyzBwukmsJhaNgoSeXqjtFObKU in CMHiVyzBwukmsJhaNgoSeXqjtFObWU:
    CMHiVyzBwukmsJhaNgoSeXqjtFObDv=CMHiVyzBwukmsJhaNgoSeXqjtFObKU['content']['movie']
    CMHiVyzBwukmsJhaNgoSeXqjtFObDP =CMHiVyzBwukmsJhaNgoSeXqjtFObDv['code']
    CMHiVyzBwukmsJhaNgoSeXqjtFObWv =CMHiVyzBwukmsJhaNgoSeXqjtFObDv['name']['ko'].strip()
    CMHiVyzBwukmsJhaNgoSeXqjtFObRn =CMHiVyzBwukmsJhaNgoSeXqjtFObDv['name']['ko'].strip()
    CMHiVyzBwukmsJhaNgoSeXqjtFObDr =CMHiVyzBwukmsJhaNgoSeXqjtFObDv['product_year']
    if CMHiVyzBwukmsJhaNgoSeXqjtFObDr:CMHiVyzBwukmsJhaNgoSeXqjtFObWv+=u' (%s)'%(CMHiVyzBwukmsJhaNgoSeXqjtFObDv['product_year'])
    CMHiVyzBwukmsJhaNgoSeXqjtFObWP =CMHiVyzBwukmsJhaNgoSeXqjtFObDv['story']['ko']
    CMHiVyzBwukmsJhaNgoSeXqjtFObRQ =CMHiVyzBwukmsJhaNgoSeXqjtFObDv['duration']
    CMHiVyzBwukmsJhaNgoSeXqjtFObDQ =CMHiVyzBwukmsJhaNgoSeXqjtFObEW.get(CMHiVyzBwukmsJhaNgoSeXqjtFObDv.get('grade_code'))
    CMHiVyzBwukmsJhaNgoSeXqjtFObRG =CMHiVyzBwukmsJhaNgoSeXqjtFObDv['production']
    CMHiVyzBwukmsJhaNgoSeXqjtFObDE=''
    CMHiVyzBwukmsJhaNgoSeXqjtFObWp =''
    CMHiVyzBwukmsJhaNgoSeXqjtFObDK=''
    CMHiVyzBwukmsJhaNgoSeXqjtFObDG =[]
    CMHiVyzBwukmsJhaNgoSeXqjtFObDI =[]
    CMHiVyzBwukmsJhaNgoSeXqjtFObDc=[]
    CMHiVyzBwukmsJhaNgoSeXqjtFObDT =''
    for CMHiVyzBwukmsJhaNgoSeXqjtFObDn in CMHiVyzBwukmsJhaNgoSeXqjtFObDv['image']:
     if CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIM2100':CMHiVyzBwukmsJhaNgoSeXqjtFObDE =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIM0400':CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
     elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn['code']=='CAIM1800':CMHiVyzBwukmsJhaNgoSeXqjtFObDK=CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn['url']
    if CMHiVyzBwukmsJhaNgoSeXqjtFObDv['release_date']not in[CMHiVyzBwukmsJhaNgoSeXqjtFObnL,0]:
     CMHiVyzBwukmsJhaNgoSeXqjtFObDY=CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObDv['release_date'])
     if CMHiVyzBwukmsJhaNgoSeXqjtFObDY!='0':CMHiVyzBwukmsJhaNgoSeXqjtFObDT='%s-%s-%s'%(CMHiVyzBwukmsJhaNgoSeXqjtFObDY[:4],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[4:6],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[6:])
    if CMHiVyzBwukmsJhaNgoSeXqjtFObDv.get('category1_name').get('ko')!='':
     CMHiVyzBwukmsJhaNgoSeXqjtFObDG.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDv['category1_name']['ko'])
    if CMHiVyzBwukmsJhaNgoSeXqjtFObDv.get('category2_name').get('ko')!='':
     CMHiVyzBwukmsJhaNgoSeXqjtFObDG.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDv['category2_name']['ko'])
    for CMHiVyzBwukmsJhaNgoSeXqjtFObDd in CMHiVyzBwukmsJhaNgoSeXqjtFObDv.get('actor'):
     if CMHiVyzBwukmsJhaNgoSeXqjtFObDd!='':CMHiVyzBwukmsJhaNgoSeXqjtFObDI.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDd)
    for CMHiVyzBwukmsJhaNgoSeXqjtFObDL in CMHiVyzBwukmsJhaNgoSeXqjtFObDv.get('director'):
     if CMHiVyzBwukmsJhaNgoSeXqjtFObDL!='':CMHiVyzBwukmsJhaNgoSeXqjtFObDc.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDL)
    CMHiVyzBwukmsJhaNgoSeXqjtFObDx={'moviecode':CMHiVyzBwukmsJhaNgoSeXqjtFObDP,'title':CMHiVyzBwukmsJhaNgoSeXqjtFObWv,'thumbnail':{'poster':CMHiVyzBwukmsJhaNgoSeXqjtFObDE,'thumb':CMHiVyzBwukmsJhaNgoSeXqjtFObWp,'clearlogo':CMHiVyzBwukmsJhaNgoSeXqjtFObDK,'fanart':CMHiVyzBwukmsJhaNgoSeXqjtFObWp},'year':CMHiVyzBwukmsJhaNgoSeXqjtFObDr,'info_title':CMHiVyzBwukmsJhaNgoSeXqjtFObRn,'synopsis':CMHiVyzBwukmsJhaNgoSeXqjtFObWP,'mpaa':CMHiVyzBwukmsJhaNgoSeXqjtFObDQ,'duration':CMHiVyzBwukmsJhaNgoSeXqjtFObRQ,'premiered':CMHiVyzBwukmsJhaNgoSeXqjtFObDT,'studio':CMHiVyzBwukmsJhaNgoSeXqjtFObRG,'info_genre':CMHiVyzBwukmsJhaNgoSeXqjtFObDG,'cast':CMHiVyzBwukmsJhaNgoSeXqjtFObDI,'director':CMHiVyzBwukmsJhaNgoSeXqjtFObDc,}
    CMHiVyzBwukmsJhaNgoSeXqjtFObKQ.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDx)
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
 def GetMovieGenre(CMHiVyzBwukmsJhaNgoSeXqjtFObER):
  CMHiVyzBwukmsJhaNgoSeXqjtFObKQ=[]
  CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v2/media/movie/curations'
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams()
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp.update(CMHiVyzBwukmsJhaNgoSeXqjtFObKL)
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKG
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKp,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKY=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   if not('result' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']):return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
   CMHiVyzBwukmsJhaNgoSeXqjtFObWU=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['result']
   for CMHiVyzBwukmsJhaNgoSeXqjtFObKU in CMHiVyzBwukmsJhaNgoSeXqjtFObWU:
    CMHiVyzBwukmsJhaNgoSeXqjtFObRL =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['curation_code']
    CMHiVyzBwukmsJhaNgoSeXqjtFObRY =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['curation_name']
    CMHiVyzBwukmsJhaNgoSeXqjtFObDx={'curation_code':CMHiVyzBwukmsJhaNgoSeXqjtFObRL,'curation_name':CMHiVyzBwukmsJhaNgoSeXqjtFObRY}
    CMHiVyzBwukmsJhaNgoSeXqjtFObKQ.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDx)
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
 def GetSearchList(CMHiVyzBwukmsJhaNgoSeXqjtFObER,search_key,page_int,stype):
  CMHiVyzBwukmsJhaNgoSeXqjtFObRU=[]
  CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnY
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/search/getSearch.jsp'
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(page_int),'pageSize':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObER.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':CMHiVyzBwukmsJhaNgoSeXqjtFObER.SCREENCODE,'os':CMHiVyzBwukmsJhaNgoSeXqjtFObER.OSCODE,'network':CMHiVyzBwukmsJhaNgoSeXqjtFObER.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObER.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObER.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.SEARCH_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKG
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKL,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKY=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   if stype=='vod':
    if not('programRsb' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY):return CMHiVyzBwukmsJhaNgoSeXqjtFObRU,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
    CMHiVyzBwukmsJhaNgoSeXqjtFObRx=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['programRsb']['dataList']
    CMHiVyzBwukmsJhaNgoSeXqjtFObRA =CMHiVyzBwukmsJhaNgoSeXqjtFObnA(CMHiVyzBwukmsJhaNgoSeXqjtFObKY['programRsb']['count'])
    for CMHiVyzBwukmsJhaNgoSeXqjtFObKU in CMHiVyzBwukmsJhaNgoSeXqjtFObRx:
     CMHiVyzBwukmsJhaNgoSeXqjtFObDA=CMHiVyzBwukmsJhaNgoSeXqjtFObKU['mast_cd']
     CMHiVyzBwukmsJhaNgoSeXqjtFObWv =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['mast_nm']
     CMHiVyzBwukmsJhaNgoSeXqjtFObDE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKU['web_url4']
     CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKU['web_url']
     try:
      CMHiVyzBwukmsJhaNgoSeXqjtFObDI =[]
      CMHiVyzBwukmsJhaNgoSeXqjtFObDc=[]
      CMHiVyzBwukmsJhaNgoSeXqjtFObDG =[]
      CMHiVyzBwukmsJhaNgoSeXqjtFObRQ =0
      CMHiVyzBwukmsJhaNgoSeXqjtFObDQ =''
      CMHiVyzBwukmsJhaNgoSeXqjtFObDr =''
      CMHiVyzBwukmsJhaNgoSeXqjtFObRc =''
      if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('actor') !='' and CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('actor') !='-':CMHiVyzBwukmsJhaNgoSeXqjtFObDI =CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('actor').split(',')
      if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('director')!='' and CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('director')!='-':CMHiVyzBwukmsJhaNgoSeXqjtFObDc=CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('director').split(',')
      if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('cate_nm')!='' and CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('cate_nm')!='-':CMHiVyzBwukmsJhaNgoSeXqjtFObDG =CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('cate_nm').split('/')
      if 'targetage' in CMHiVyzBwukmsJhaNgoSeXqjtFObKU:CMHiVyzBwukmsJhaNgoSeXqjtFObDQ=CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('targetage')
      if 'broad_dt' in CMHiVyzBwukmsJhaNgoSeXqjtFObKU:
       CMHiVyzBwukmsJhaNgoSeXqjtFObDY=CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('broad_dt')
       CMHiVyzBwukmsJhaNgoSeXqjtFObRc='%s-%s-%s'%(CMHiVyzBwukmsJhaNgoSeXqjtFObDY[:4],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[4:6],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[6:])
       CMHiVyzBwukmsJhaNgoSeXqjtFObDr =CMHiVyzBwukmsJhaNgoSeXqjtFObDY[:4]
     except:
      CMHiVyzBwukmsJhaNgoSeXqjtFObnL
     CMHiVyzBwukmsJhaNgoSeXqjtFObDx={'program':CMHiVyzBwukmsJhaNgoSeXqjtFObDA,'title':CMHiVyzBwukmsJhaNgoSeXqjtFObWv,'thumbnail':{'poster':CMHiVyzBwukmsJhaNgoSeXqjtFObDE,'thumb':CMHiVyzBwukmsJhaNgoSeXqjtFObWp,'fanart':CMHiVyzBwukmsJhaNgoSeXqjtFObWp},'synopsis':'','cast':CMHiVyzBwukmsJhaNgoSeXqjtFObDI,'director':CMHiVyzBwukmsJhaNgoSeXqjtFObDc,'info_genre':CMHiVyzBwukmsJhaNgoSeXqjtFObDG,'duration':CMHiVyzBwukmsJhaNgoSeXqjtFObRQ,'mpaa':CMHiVyzBwukmsJhaNgoSeXqjtFObDQ,'year':CMHiVyzBwukmsJhaNgoSeXqjtFObDr,'aired':CMHiVyzBwukmsJhaNgoSeXqjtFObRc}
     CMHiVyzBwukmsJhaNgoSeXqjtFObRU.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDx)
   else:
    if not('vodMVRsb' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY):return CMHiVyzBwukmsJhaNgoSeXqjtFObRU,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
    CMHiVyzBwukmsJhaNgoSeXqjtFObRf=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['vodMVRsb']['dataList']
    CMHiVyzBwukmsJhaNgoSeXqjtFObRA =CMHiVyzBwukmsJhaNgoSeXqjtFObnA(CMHiVyzBwukmsJhaNgoSeXqjtFObKY['vodMVRsb']['count'])
    for CMHiVyzBwukmsJhaNgoSeXqjtFObKU in CMHiVyzBwukmsJhaNgoSeXqjtFObRf:
     CMHiVyzBwukmsJhaNgoSeXqjtFObDA=CMHiVyzBwukmsJhaNgoSeXqjtFObKU['mast_cd']
     CMHiVyzBwukmsJhaNgoSeXqjtFObWv =CMHiVyzBwukmsJhaNgoSeXqjtFObKU['mast_nm'].strip()
     CMHiVyzBwukmsJhaNgoSeXqjtFObDE =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKU['web_url']
     CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObDE
     CMHiVyzBwukmsJhaNgoSeXqjtFObDK=''
     try:
      CMHiVyzBwukmsJhaNgoSeXqjtFObDI =[]
      CMHiVyzBwukmsJhaNgoSeXqjtFObDc=[]
      CMHiVyzBwukmsJhaNgoSeXqjtFObDG =[]
      CMHiVyzBwukmsJhaNgoSeXqjtFObRQ =0
      CMHiVyzBwukmsJhaNgoSeXqjtFObDQ =''
      CMHiVyzBwukmsJhaNgoSeXqjtFObDr =''
      CMHiVyzBwukmsJhaNgoSeXqjtFObRc =''
      if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('actor') !='' and CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('actor') !='-':CMHiVyzBwukmsJhaNgoSeXqjtFObDI =CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('actor').split(',')
      if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('director')!='' and CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('director')!='-':CMHiVyzBwukmsJhaNgoSeXqjtFObDc=CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('director').split(',')
      if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('cate_nm')!='' and CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('cate_nm')!='-':CMHiVyzBwukmsJhaNgoSeXqjtFObDG =CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('cate_nm').split('/')
      if CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('runtime_sec')!='':CMHiVyzBwukmsJhaNgoSeXqjtFObRQ=CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('runtime_sec')
      if 'grade_nm' in CMHiVyzBwukmsJhaNgoSeXqjtFObKU:CMHiVyzBwukmsJhaNgoSeXqjtFObDQ=CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('grade_nm')
      CMHiVyzBwukmsJhaNgoSeXqjtFObDY=CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('broad_dt')
      if data_str!='':
       CMHiVyzBwukmsJhaNgoSeXqjtFObRc='%s-%s-%s'%(CMHiVyzBwukmsJhaNgoSeXqjtFObDY[:4],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[4:6],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[6:])
       CMHiVyzBwukmsJhaNgoSeXqjtFObDr =CMHiVyzBwukmsJhaNgoSeXqjtFObDY[:4]
     except:
      CMHiVyzBwukmsJhaNgoSeXqjtFObnL
     CMHiVyzBwukmsJhaNgoSeXqjtFObDx={'movie':CMHiVyzBwukmsJhaNgoSeXqjtFObDA,'title':CMHiVyzBwukmsJhaNgoSeXqjtFObWv,'thumbnail':{'poster':CMHiVyzBwukmsJhaNgoSeXqjtFObDE,'thumb':CMHiVyzBwukmsJhaNgoSeXqjtFObWp,'fanart':CMHiVyzBwukmsJhaNgoSeXqjtFObWp,'clearlogo':CMHiVyzBwukmsJhaNgoSeXqjtFObDK},'synopsis':'','cast':CMHiVyzBwukmsJhaNgoSeXqjtFObDI,'director':CMHiVyzBwukmsJhaNgoSeXqjtFObDc,'info_genre':CMHiVyzBwukmsJhaNgoSeXqjtFObDG,'duration':CMHiVyzBwukmsJhaNgoSeXqjtFObRQ,'mpaa':CMHiVyzBwukmsJhaNgoSeXqjtFObDQ,'year':CMHiVyzBwukmsJhaNgoSeXqjtFObDr,'aired':CMHiVyzBwukmsJhaNgoSeXqjtFObRc}
     CMHiVyzBwukmsJhaNgoSeXqjtFObRT=CMHiVyzBwukmsJhaNgoSeXqjtFObnY
     for CMHiVyzBwukmsJhaNgoSeXqjtFObRd in CMHiVyzBwukmsJhaNgoSeXqjtFObKU['bill']:
      if CMHiVyzBwukmsJhaNgoSeXqjtFObRd in CMHiVyzBwukmsJhaNgoSeXqjtFObER.MOVIE_LITE:
       CMHiVyzBwukmsJhaNgoSeXqjtFObRT=CMHiVyzBwukmsJhaNgoSeXqjtFObnx
       break
     if CMHiVyzBwukmsJhaNgoSeXqjtFObRT==CMHiVyzBwukmsJhaNgoSeXqjtFObnY: 
      CMHiVyzBwukmsJhaNgoSeXqjtFObDx['title']=CMHiVyzBwukmsJhaNgoSeXqjtFObDx['title']+' [개별구매]'
     CMHiVyzBwukmsJhaNgoSeXqjtFObRU.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDx)
   if CMHiVyzBwukmsJhaNgoSeXqjtFObRA>(page_int*CMHiVyzBwukmsJhaNgoSeXqjtFObER.SEARCH_LIMIT):CMHiVyzBwukmsJhaNgoSeXqjtFObWL=CMHiVyzBwukmsJhaNgoSeXqjtFObnx
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObRU,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
 def GetBookmarkInfo(CMHiVyzBwukmsJhaNgoSeXqjtFObER,videoid,vidtype):
  CMHiVyzBwukmsJhaNgoSeXqjtFObRv={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+'/v2/media/program/'+videoid
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams()
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'pageNo':'1','pageSize':'10','order':'name',}
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp.update(CMHiVyzBwukmsJhaNgoSeXqjtFObKL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKp,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObRP=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   if not('body' in CMHiVyzBwukmsJhaNgoSeXqjtFObRP):return{}
   CMHiVyzBwukmsJhaNgoSeXqjtFObRp=CMHiVyzBwukmsJhaNgoSeXqjtFObRP['body']
   CMHiVyzBwukmsJhaNgoSeXqjtFObWv=CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('name').get('ko').strip()
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['title'] =CMHiVyzBwukmsJhaNgoSeXqjtFObWv
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['title']=CMHiVyzBwukmsJhaNgoSeXqjtFObWv
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['mpaa'] =CMHiVyzBwukmsJhaNgoSeXqjtFObEW.get(CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('grade_code'))
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['plot'] =CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('synopsis').get('ko')
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['year'] =CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('product_year')
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['cast'] =CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('actor')
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['director']=CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('director')
   if CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('category1_name').get('ko')!='':
    CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['genre'].append(CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('category1_name').get('ko'))
   if CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('category2_name').get('ko')!='':
    CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['genre'].append(CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('category2_name').get('ko'))
   CMHiVyzBwukmsJhaNgoSeXqjtFObDY=CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('broad_dt'))
   if CMHiVyzBwukmsJhaNgoSeXqjtFObDY!='0':CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(CMHiVyzBwukmsJhaNgoSeXqjtFObDY[:4],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[4:6],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[6:])
   CMHiVyzBwukmsJhaNgoSeXqjtFObDE =''
   CMHiVyzBwukmsJhaNgoSeXqjtFObWp =''
   CMHiVyzBwukmsJhaNgoSeXqjtFObDK=''
   CMHiVyzBwukmsJhaNgoSeXqjtFObDl =''
   CMHiVyzBwukmsJhaNgoSeXqjtFObDW =''
   for CMHiVyzBwukmsJhaNgoSeXqjtFObDn in CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('image'):
    if CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('code')=='CAIP0900':CMHiVyzBwukmsJhaNgoSeXqjtFObDE =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('url')
    elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('code')=='CAIP0200':CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('url')
    elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('code')=='CAIP1800':CMHiVyzBwukmsJhaNgoSeXqjtFObDK=CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('url')
    elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('code')=='CAIP2000':CMHiVyzBwukmsJhaNgoSeXqjtFObDl =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('url')
    elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('code')=='CAIP1900':CMHiVyzBwukmsJhaNgoSeXqjtFObDW =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('url')
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['thumbnail']['poster']=CMHiVyzBwukmsJhaNgoSeXqjtFObDE
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['thumbnail']['thumb']=CMHiVyzBwukmsJhaNgoSeXqjtFObWp
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['thumbnail']['clearlogo']=CMHiVyzBwukmsJhaNgoSeXqjtFObDK
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['thumbnail']['icon']=CMHiVyzBwukmsJhaNgoSeXqjtFObDl
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['thumbnail']['banner']=CMHiVyzBwukmsJhaNgoSeXqjtFObDW
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['thumbnail']['fanart']=CMHiVyzBwukmsJhaNgoSeXqjtFObWp
  else:
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+'/v2a/media/stream/info'
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams()
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_uuid'].split('-')[0],'uuid':CMHiVyzBwukmsJhaNgoSeXqjtFObER.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetNoCache(1)),'wm':'Y',}
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp.update(CMHiVyzBwukmsJhaNgoSeXqjtFObKL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKp,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObRP=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   if not('content' in CMHiVyzBwukmsJhaNgoSeXqjtFObRP['body']):return{}
   CMHiVyzBwukmsJhaNgoSeXqjtFObRp=CMHiVyzBwukmsJhaNgoSeXqjtFObRP['body']['content']['info']['movie']
   CMHiVyzBwukmsJhaNgoSeXqjtFObWv =CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('name').get('ko').strip()
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['title']=CMHiVyzBwukmsJhaNgoSeXqjtFObWv
   CMHiVyzBwukmsJhaNgoSeXqjtFObWv +=u' (%s)'%(CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('product_year'))
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['title'] =CMHiVyzBwukmsJhaNgoSeXqjtFObWv
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['mpaa'] =CMHiVyzBwukmsJhaNgoSeXqjtFObEW.get(CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('grade_code'))
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['plot'] =CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('story').get('ko')
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['year'] =CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('product_year')
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['studio'] =CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('production')
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['duration']=CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('duration')
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['cast'] =CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('actor')
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['director']=CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('director')
   if CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('category1_name').get('ko')!='':
    CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['genre'].append(CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('category1_name').get('ko'))
   if CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('category2_name').get('ko')!='':
    CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['genre'].append(CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('category2_name').get('ko'))
   CMHiVyzBwukmsJhaNgoSeXqjtFObDY=CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('release_date'))
   if CMHiVyzBwukmsJhaNgoSeXqjtFObDY!='0':CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(CMHiVyzBwukmsJhaNgoSeXqjtFObDY[:4],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[4:6],CMHiVyzBwukmsJhaNgoSeXqjtFObDY[6:])
   CMHiVyzBwukmsJhaNgoSeXqjtFObDE=''
   CMHiVyzBwukmsJhaNgoSeXqjtFObWp =''
   CMHiVyzBwukmsJhaNgoSeXqjtFObDK=''
   for CMHiVyzBwukmsJhaNgoSeXqjtFObDn in CMHiVyzBwukmsJhaNgoSeXqjtFObRp.get('image'):
    if CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('code')=='CAIM2100':CMHiVyzBwukmsJhaNgoSeXqjtFObDE =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('url')
    elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('code')=='CAIM0400':CMHiVyzBwukmsJhaNgoSeXqjtFObWp =CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('url')
    elif CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('code')=='CAIM1800':CMHiVyzBwukmsJhaNgoSeXqjtFObDK=CMHiVyzBwukmsJhaNgoSeXqjtFObER.IMG_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObDn.get('url')
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['thumbnail']['poster']=CMHiVyzBwukmsJhaNgoSeXqjtFObDE
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['thumbnail']['thumb']=CMHiVyzBwukmsJhaNgoSeXqjtFObDE 
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['thumbnail']['clearlogo']=CMHiVyzBwukmsJhaNgoSeXqjtFObDK
   CMHiVyzBwukmsJhaNgoSeXqjtFObRv['saveinfo']['thumbnail']['fanart']=CMHiVyzBwukmsJhaNgoSeXqjtFObWp
  return CMHiVyzBwukmsJhaNgoSeXqjtFObRv
 def GetEuroChannelList(CMHiVyzBwukmsJhaNgoSeXqjtFObER):
  CMHiVyzBwukmsJhaNgoSeXqjtFObKQ=[]
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObKG ='/v2/operator/highlights'
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp=CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetDefaultParams()
   CMHiVyzBwukmsJhaNgoSeXqjtFObKL={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':CMHiVyzBwukmsJhaNgoSeXqjtFObnp(CMHiVyzBwukmsJhaNgoSeXqjtFObER.GetNoCache(2))}
   CMHiVyzBwukmsJhaNgoSeXqjtFObKp.update(CMHiVyzBwukmsJhaNgoSeXqjtFObKL)
   CMHiVyzBwukmsJhaNgoSeXqjtFOblE=CMHiVyzBwukmsJhaNgoSeXqjtFObER.API_DOMAIN+CMHiVyzBwukmsJhaNgoSeXqjtFObKG
   CMHiVyzBwukmsJhaNgoSeXqjtFObKD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.callRequestCookies('Get',CMHiVyzBwukmsJhaNgoSeXqjtFOblE,payload=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,params=CMHiVyzBwukmsJhaNgoSeXqjtFObKp,headers=CMHiVyzBwukmsJhaNgoSeXqjtFObnL,cookies=CMHiVyzBwukmsJhaNgoSeXqjtFObnL)
   CMHiVyzBwukmsJhaNgoSeXqjtFObKY=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObKD.text)
   if not('result' in CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']):return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ,CMHiVyzBwukmsJhaNgoSeXqjtFObWL
   CMHiVyzBwukmsJhaNgoSeXqjtFObWU=CMHiVyzBwukmsJhaNgoSeXqjtFObKY['body']['result']
   CMHiVyzBwukmsJhaNgoSeXqjtFObnE =CMHiVyzBwukmsJhaNgoSeXqjtFObER.Get_Now_Datetime()
   CMHiVyzBwukmsJhaNgoSeXqjtFObnK=CMHiVyzBwukmsJhaNgoSeXqjtFObnE+datetime.timedelta(days=-1)
   CMHiVyzBwukmsJhaNgoSeXqjtFObnK=CMHiVyzBwukmsJhaNgoSeXqjtFObnA(CMHiVyzBwukmsJhaNgoSeXqjtFObnK.strftime('%Y%m%d'))
   for CMHiVyzBwukmsJhaNgoSeXqjtFObKU in CMHiVyzBwukmsJhaNgoSeXqjtFObWU:
    CMHiVyzBwukmsJhaNgoSeXqjtFObnl=CMHiVyzBwukmsJhaNgoSeXqjtFObnA(CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('content').get('banner_title2')[:8])
    if CMHiVyzBwukmsJhaNgoSeXqjtFObnK<=CMHiVyzBwukmsJhaNgoSeXqjtFObnl:
     CMHiVyzBwukmsJhaNgoSeXqjtFObDx={'channel':CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('content').get('banner_sub_title3'),'title':CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('content').get('banner_title'),'subtitle':CMHiVyzBwukmsJhaNgoSeXqjtFObKU.get('content').get('banner_sub_title2'),}
     CMHiVyzBwukmsJhaNgoSeXqjtFObKQ.append(CMHiVyzBwukmsJhaNgoSeXqjtFObDx)
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObKQ
 def Make_DecryptKey(CMHiVyzBwukmsJhaNgoSeXqjtFObER,step,mediacode='000',timecode='000'):
  if step=='1':
   CMHiVyzBwukmsJhaNgoSeXqjtFObnW=CMHiVyzBwukmsJhaNgoSeXqjtFObIl('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   CMHiVyzBwukmsJhaNgoSeXqjtFObnD=CMHiVyzBwukmsJhaNgoSeXqjtFObIl('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnW=CMHiVyzBwukmsJhaNgoSeXqjtFObIl('kss2lym0kdw1lks3','utf-8')
   CMHiVyzBwukmsJhaNgoSeXqjtFObnD=CMHiVyzBwukmsJhaNgoSeXqjtFObIl([CMHiVyzBwukmsJhaNgoSeXqjtFObIW('*'),0x07,CMHiVyzBwukmsJhaNgoSeXqjtFObIW('r'),CMHiVyzBwukmsJhaNgoSeXqjtFObIW(';'),CMHiVyzBwukmsJhaNgoSeXqjtFObIW('7'),0x05,0x1e,0x01,CMHiVyzBwukmsJhaNgoSeXqjtFObIW('n'),CMHiVyzBwukmsJhaNgoSeXqjtFObIW('D'),0x02,CMHiVyzBwukmsJhaNgoSeXqjtFObIW('3'),CMHiVyzBwukmsJhaNgoSeXqjtFObIW('*'),CMHiVyzBwukmsJhaNgoSeXqjtFObIW('a'),CMHiVyzBwukmsJhaNgoSeXqjtFObIW('&'),CMHiVyzBwukmsJhaNgoSeXqjtFObIW('<')])
  return CMHiVyzBwukmsJhaNgoSeXqjtFObnW,CMHiVyzBwukmsJhaNgoSeXqjtFObnD
 def DecryptPlaintext(CMHiVyzBwukmsJhaNgoSeXqjtFObER,ciphertext,encryption_key,init_vector):
  CMHiVyzBwukmsJhaNgoSeXqjtFObnR=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  CMHiVyzBwukmsJhaNgoSeXqjtFObnI=Padding.unpad(CMHiVyzBwukmsJhaNgoSeXqjtFObnR.decrypt(base64.standard_b64decode(ciphertext)),16)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObnI.decode('utf-8')
 def Decrypt_Url(CMHiVyzBwukmsJhaNgoSeXqjtFObER,ciphertext,mediacode,CMHiVyzBwukmsJhaNgoSeXqjtFOblI):
  CMHiVyzBwukmsJhaNgoSeXqjtFObnc=''
  CMHiVyzBwukmsJhaNgoSeXqjtFOblc=''
  CMHiVyzBwukmsJhaNgoSeXqjtFOblG=''
  try:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnW,CMHiVyzBwukmsJhaNgoSeXqjtFObnD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.Make_DecryptKey('1',mediacode=mediacode,timecode=CMHiVyzBwukmsJhaNgoSeXqjtFOblI)
   CMHiVyzBwukmsJhaNgoSeXqjtFObnG=json.loads(CMHiVyzBwukmsJhaNgoSeXqjtFObER.DecryptPlaintext(ciphertext,CMHiVyzBwukmsJhaNgoSeXqjtFObnW,CMHiVyzBwukmsJhaNgoSeXqjtFObnD))
   CMHiVyzBwukmsJhaNgoSeXqjtFObnr =CMHiVyzBwukmsJhaNgoSeXqjtFObnG.get('broad_url')
   CMHiVyzBwukmsJhaNgoSeXqjtFOblc =CMHiVyzBwukmsJhaNgoSeXqjtFObnG.get('watermark') if 'watermark' in CMHiVyzBwukmsJhaNgoSeXqjtFObnG else ''
   CMHiVyzBwukmsJhaNgoSeXqjtFOblG=CMHiVyzBwukmsJhaNgoSeXqjtFObnG.get('watermarkKey')if 'watermarkKey' in CMHiVyzBwukmsJhaNgoSeXqjtFObnG else ''
   CMHiVyzBwukmsJhaNgoSeXqjtFObnW,CMHiVyzBwukmsJhaNgoSeXqjtFObnD=CMHiVyzBwukmsJhaNgoSeXqjtFObER.Make_DecryptKey('2',mediacode=mediacode,timecode=CMHiVyzBwukmsJhaNgoSeXqjtFOblI)
   CMHiVyzBwukmsJhaNgoSeXqjtFObnc=CMHiVyzBwukmsJhaNgoSeXqjtFObER.DecryptPlaintext(CMHiVyzBwukmsJhaNgoSeXqjtFObnr,CMHiVyzBwukmsJhaNgoSeXqjtFObnW,CMHiVyzBwukmsJhaNgoSeXqjtFObnD)
  except CMHiVyzBwukmsJhaNgoSeXqjtFObnv as exception:
   CMHiVyzBwukmsJhaNgoSeXqjtFObnQ(exception)
  return CMHiVyzBwukmsJhaNgoSeXqjtFObnc,CMHiVyzBwukmsJhaNgoSeXqjtFOblc,CMHiVyzBwukmsJhaNgoSeXqjtFOblG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
