__author__="NightRain"
cmwYqROxSuTQBJipkWEMhfNgFVIoUA=object
cmwYqROxSuTQBJipkWEMhfNgFVIoUC=None
cmwYqROxSuTQBJipkWEMhfNgFVIoUv=False
cmwYqROxSuTQBJipkWEMhfNgFVIoUD=int
cmwYqROxSuTQBJipkWEMhfNgFVIoUb=range
cmwYqROxSuTQBJipkWEMhfNgFVIoUK=True
cmwYqROxSuTQBJipkWEMhfNgFVIoUl=Exception
cmwYqROxSuTQBJipkWEMhfNgFVIoUL=print
cmwYqROxSuTQBJipkWEMhfNgFVIoUy=str
cmwYqROxSuTQBJipkWEMhfNgFVIoUG=list
cmwYqROxSuTQBJipkWEMhfNgFVIoUt=len
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
cmwYqROxSuTQBJipkWEMhfNgFVIonj={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
cmwYqROxSuTQBJipkWEMhfNgFVIonP ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class cmwYqROxSuTQBJipkWEMhfNgFVIona(cmwYqROxSuTQBJipkWEMhfNgFVIoUA):
 def __init__(cmwYqROxSuTQBJipkWEMhfNgFVIonX):
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_TOKEN =''
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.POC_USERINFO =''
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_UUID ='-'
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_MAINTOKEN=''
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVIGN_COOKIEKEY=''
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_LOCKKEY =''
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.NETWORKCODE ='CSND0900'
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.OSCODE ='CSOD0900' 
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.TELECODE ='CSCD0900'
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.SCREENCODE ='CSSD0100'
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.LIVE_LIMIT =23
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.VOD_LIMIT =20
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.EPISODE_LIMIT =30 
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.SEARCH_LIMIT =30 
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.MOVIE_LIMIT =18
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.API_DOMAIN ='https://api.tving.com'
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN ='https://image.tving.com'
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.SEARCH_DOMAIN ='https://search.tving.com'
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.LOGIN_DOMAIN ='https://user.tving.com'
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.URL_DOMAIN ='https://www.tving.com'
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.MOVIE_LITE =['2610061','2610161','261062']
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.DEFAULT_HEADER ={'user-agent':cmwYqROxSuTQBJipkWEMhfNgFVIonX.USER_AGENT}
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(cmwYqROxSuTQBJipkWEMhfNgFVIonX,jobtype,cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,redirects=cmwYqROxSuTQBJipkWEMhfNgFVIoUv):
  cmwYqROxSuTQBJipkWEMhfNgFVIonU=cmwYqROxSuTQBJipkWEMhfNgFVIonX.DEFAULT_HEADER
  if headers:cmwYqROxSuTQBJipkWEMhfNgFVIonU.update(headers)
  if jobtype=='Get':
   cmwYqROxSuTQBJipkWEMhfNgFVIons=requests.get(cmwYqROxSuTQBJipkWEMhfNgFVIoab,params=params,headers=cmwYqROxSuTQBJipkWEMhfNgFVIonU,cookies=cookies,allow_redirects=redirects)
  else:
   cmwYqROxSuTQBJipkWEMhfNgFVIons=requests.post(cmwYqROxSuTQBJipkWEMhfNgFVIoab,data=payload,params=params,headers=cmwYqROxSuTQBJipkWEMhfNgFVIonU,cookies=cookies,allow_redirects=redirects)
  return cmwYqROxSuTQBJipkWEMhfNgFVIons
 def makeDefaultCookies(cmwYqROxSuTQBJipkWEMhfNgFVIonX,vToken=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,vUserinfo=cmwYqROxSuTQBJipkWEMhfNgFVIoUC):
  cmwYqROxSuTQBJipkWEMhfNgFVIonr={}
  cmwYqROxSuTQBJipkWEMhfNgFVIonr['_tving_token']=cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_TOKEN if vToken==cmwYqROxSuTQBJipkWEMhfNgFVIoUC else vToken
  cmwYqROxSuTQBJipkWEMhfNgFVIonr['POC_USERINFO']=cmwYqROxSuTQBJipkWEMhfNgFVIonX.POC_USERINFO if vToken==cmwYqROxSuTQBJipkWEMhfNgFVIoUC else vUserinfo
  if cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_MAINTOKEN!='':cmwYqROxSuTQBJipkWEMhfNgFVIonr[cmwYqROxSuTQBJipkWEMhfNgFVIonX.GLOBAL_COOKIENM['tv_maintoken']]=cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_MAINTOKEN
  if cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVIGN_COOKIEKEY!='':cmwYqROxSuTQBJipkWEMhfNgFVIonr[cmwYqROxSuTQBJipkWEMhfNgFVIonX.GLOBAL_COOKIENM['tv_cookiekey']]=cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVIGN_COOKIEKEY
  if cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_LOCKKEY !='':cmwYqROxSuTQBJipkWEMhfNgFVIonr[cmwYqROxSuTQBJipkWEMhfNgFVIonX.GLOBAL_COOKIENM['tv_lockkey']] =cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_LOCKKEY
  return cmwYqROxSuTQBJipkWEMhfNgFVIonr
 def getDeviceStr(cmwYqROxSuTQBJipkWEMhfNgFVIonX):
  cmwYqROxSuTQBJipkWEMhfNgFVIonz=[]
  cmwYqROxSuTQBJipkWEMhfNgFVIonz.append('Windows') 
  cmwYqROxSuTQBJipkWEMhfNgFVIonz.append('Chrome') 
  cmwYqROxSuTQBJipkWEMhfNgFVIonz.append('ko-KR') 
  cmwYqROxSuTQBJipkWEMhfNgFVIonz.append('undefined') 
  cmwYqROxSuTQBJipkWEMhfNgFVIonz.append('24') 
  cmwYqROxSuTQBJipkWEMhfNgFVIonz.append(u'한국 표준시')
  cmwYqROxSuTQBJipkWEMhfNgFVIonz.append('undefined') 
  cmwYqROxSuTQBJipkWEMhfNgFVIonz.append('undefined') 
  cmwYqROxSuTQBJipkWEMhfNgFVIonz.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  cmwYqROxSuTQBJipkWEMhfNgFVIonA=''
  for cmwYqROxSuTQBJipkWEMhfNgFVIonC in cmwYqROxSuTQBJipkWEMhfNgFVIonz:
   cmwYqROxSuTQBJipkWEMhfNgFVIonA+=cmwYqROxSuTQBJipkWEMhfNgFVIonC+'|'
  return cmwYqROxSuTQBJipkWEMhfNgFVIonA
 def SaveCredential(cmwYqROxSuTQBJipkWEMhfNgFVIonX,cmwYqROxSuTQBJipkWEMhfNgFVIonv):
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_TOKEN =cmwYqROxSuTQBJipkWEMhfNgFVIonv.get('tving_token')
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.POC_USERINFO =cmwYqROxSuTQBJipkWEMhfNgFVIonv.get('poc_userinfo')
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_UUID =cmwYqROxSuTQBJipkWEMhfNgFVIonv.get('tving_uuid')
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_MAINTOKEN=cmwYqROxSuTQBJipkWEMhfNgFVIonv.get('tving_maintoken')
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVIGN_COOKIEKEY=cmwYqROxSuTQBJipkWEMhfNgFVIonv.get('tving_cookiekey')
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_LOCKKEY =cmwYqROxSuTQBJipkWEMhfNgFVIonv.get('tving_lockkey')
 def LoadCredential(cmwYqROxSuTQBJipkWEMhfNgFVIonX):
  cmwYqROxSuTQBJipkWEMhfNgFVIonv={'tving_token':cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_TOKEN,'poc_userinfo':cmwYqROxSuTQBJipkWEMhfNgFVIonX.POC_USERINFO,'tving_uuid':cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_UUID,'tving_maintoken':cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_MAINTOKEN,'tving_cookiekey':cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVIGN_COOKIEKEY,'tving_lockkey':cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_LOCKKEY}
  return cmwYqROxSuTQBJipkWEMhfNgFVIonv
 def GetDefaultParams(cmwYqROxSuTQBJipkWEMhfNgFVIonX):
  cmwYqROxSuTQBJipkWEMhfNgFVIonD={'apiKey':cmwYqROxSuTQBJipkWEMhfNgFVIonX.APIKEY,'networkCode':cmwYqROxSuTQBJipkWEMhfNgFVIonX.NETWORKCODE,'osCode':cmwYqROxSuTQBJipkWEMhfNgFVIonX.OSCODE,'teleCode':cmwYqROxSuTQBJipkWEMhfNgFVIonX.TELECODE,'screenCode':cmwYqROxSuTQBJipkWEMhfNgFVIonX.SCREENCODE}
  return cmwYqROxSuTQBJipkWEMhfNgFVIonD
 def GetNoCache(cmwYqROxSuTQBJipkWEMhfNgFVIonX,timetype=1):
  if timetype==1:
   return cmwYqROxSuTQBJipkWEMhfNgFVIoUD(time.time())
  else:
   return cmwYqROxSuTQBJipkWEMhfNgFVIoUD(time.time()*1000)
 def GetUniqueid(cmwYqROxSuTQBJipkWEMhfNgFVIonX):
  cmwYqROxSuTQBJipkWEMhfNgFVIonb=[0 for i in cmwYqROxSuTQBJipkWEMhfNgFVIoUb(256)]
  for i in cmwYqROxSuTQBJipkWEMhfNgFVIoUb(256):
   cmwYqROxSuTQBJipkWEMhfNgFVIonb[i]='%02x'%(i)
  cmwYqROxSuTQBJipkWEMhfNgFVIonK=cmwYqROxSuTQBJipkWEMhfNgFVIoUD(4294967295*random.random())|0
  cmwYqROxSuTQBJipkWEMhfNgFVIonl=cmwYqROxSuTQBJipkWEMhfNgFVIonb[255&cmwYqROxSuTQBJipkWEMhfNgFVIonK]+cmwYqROxSuTQBJipkWEMhfNgFVIonb[cmwYqROxSuTQBJipkWEMhfNgFVIonK>>8&255]+cmwYqROxSuTQBJipkWEMhfNgFVIonb[cmwYqROxSuTQBJipkWEMhfNgFVIonK>>16&255]+cmwYqROxSuTQBJipkWEMhfNgFVIonb[cmwYqROxSuTQBJipkWEMhfNgFVIonK>>24&255]
  return cmwYqROxSuTQBJipkWEMhfNgFVIonl
 def GetCredential(cmwYqROxSuTQBJipkWEMhfNgFVIonX,user_id,user_pw,login_type,user_pf):
  cmwYqROxSuTQBJipkWEMhfNgFVIonL=cmwYqROxSuTQBJipkWEMhfNgFVIoUv
  cmwYqROxSuTQBJipkWEMhfNgFVIony=cmwYqROxSuTQBJipkWEMhfNgFVIoan=cmwYqROxSuTQBJipkWEMhfNgFVIoaj=cmwYqROxSuTQBJipkWEMhfNgFVIoaP=cmwYqROxSuTQBJipkWEMhfNgFVIoaX='' 
  cmwYqROxSuTQBJipkWEMhfNgFVIonG ='-'
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIont=cmwYqROxSuTQBJipkWEMhfNgFVIonX.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   cmwYqROxSuTQBJipkWEMhfNgFVIond={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Post',cmwYqROxSuTQBJipkWEMhfNgFVIont,payload=cmwYqROxSuTQBJipkWEMhfNgFVIond,params=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIoUC)
   for cmwYqROxSuTQBJipkWEMhfNgFVIonH in cmwYqROxSuTQBJipkWEMhfNgFVIone.cookies:
    if cmwYqROxSuTQBJipkWEMhfNgFVIonH.name=='_tving_token':
     cmwYqROxSuTQBJipkWEMhfNgFVIoan=cmwYqROxSuTQBJipkWEMhfNgFVIonH.value
    elif cmwYqROxSuTQBJipkWEMhfNgFVIonH.name=='POC_USERINFO':
     cmwYqROxSuTQBJipkWEMhfNgFVIoaj=cmwYqROxSuTQBJipkWEMhfNgFVIonH.value
   if cmwYqROxSuTQBJipkWEMhfNgFVIoan=='':return cmwYqROxSuTQBJipkWEMhfNgFVIonL
   cmwYqROxSuTQBJipkWEMhfNgFVIony=cmwYqROxSuTQBJipkWEMhfNgFVIoan
   cmwYqROxSuTQBJipkWEMhfNgFVIoan,cmwYqROxSuTQBJipkWEMhfNgFVIoaP,cmwYqROxSuTQBJipkWEMhfNgFVIoaX=cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetProfileToken(cmwYqROxSuTQBJipkWEMhfNgFVIoan,cmwYqROxSuTQBJipkWEMhfNgFVIoaj,user_pf)
   cmwYqROxSuTQBJipkWEMhfNgFVIonL=cmwYqROxSuTQBJipkWEMhfNgFVIoUK
   cmwYqROxSuTQBJipkWEMhfNgFVIonG =cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetDeviceList(cmwYqROxSuTQBJipkWEMhfNgFVIoan,cmwYqROxSuTQBJipkWEMhfNgFVIoaj)
   cmwYqROxSuTQBJipkWEMhfNgFVIonG =cmwYqROxSuTQBJipkWEMhfNgFVIonG+'-'+cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetUniqueid()
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIony=cmwYqROxSuTQBJipkWEMhfNgFVIoan=cmwYqROxSuTQBJipkWEMhfNgFVIoaj=cmwYqROxSuTQBJipkWEMhfNgFVIoaP=cmwYqROxSuTQBJipkWEMhfNgFVIoaX=''
   cmwYqROxSuTQBJipkWEMhfNgFVIonG='-'
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  cmwYqROxSuTQBJipkWEMhfNgFVIonv={'tving_token':cmwYqROxSuTQBJipkWEMhfNgFVIoan,'poc_userinfo':cmwYqROxSuTQBJipkWEMhfNgFVIoaj,'tving_uuid':cmwYqROxSuTQBJipkWEMhfNgFVIonG,'tving_maintoken':cmwYqROxSuTQBJipkWEMhfNgFVIony,'tving_cookiekey':cmwYqROxSuTQBJipkWEMhfNgFVIoaP,'tving_lockkey':cmwYqROxSuTQBJipkWEMhfNgFVIoaX}
  cmwYqROxSuTQBJipkWEMhfNgFVIonX.SaveCredential(cmwYqROxSuTQBJipkWEMhfNgFVIonv)
  return cmwYqROxSuTQBJipkWEMhfNgFVIonL
 def Get_Now_Datetime(cmwYqROxSuTQBJipkWEMhfNgFVIonX):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(cmwYqROxSuTQBJipkWEMhfNgFVIonX,mediacode,sel_quality,stype,pvrmode='-'):
  cmwYqROxSuTQBJipkWEMhfNgFVIoas=''
  cmwYqROxSuTQBJipkWEMhfNgFVIoar=''
  cmwYqROxSuTQBJipkWEMhfNgFVIoaz =cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_UUID.split('-')[0] 
  cmwYqROxSuTQBJipkWEMhfNgFVIoaA =cmwYqROxSuTQBJipkWEMhfNgFVIonX.TVING_UUID 
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/v2a/media/stream/info' 
    cmwYqROxSuTQBJipkWEMhfNgFVIoav=cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetDefaultParams()
    cmwYqROxSuTQBJipkWEMhfNgFVIoaD={'info':'N','mediaCode':mediacode,'noCache':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':cmwYqROxSuTQBJipkWEMhfNgFVIoaz,'uuid':cmwYqROxSuTQBJipkWEMhfNgFVIoaA,'deviceInfo':'PC','wm':'Y'}
    cmwYqROxSuTQBJipkWEMhfNgFVIoav.update(cmwYqROxSuTQBJipkWEMhfNgFVIoaD)
    cmwYqROxSuTQBJipkWEMhfNgFVIoab=cmwYqROxSuTQBJipkWEMhfNgFVIonX.API_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
    cmwYqROxSuTQBJipkWEMhfNgFVIonr=cmwYqROxSuTQBJipkWEMhfNgFVIonX.makeDefaultCookies()
    cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoav,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIonr)
    if cmwYqROxSuTQBJipkWEMhfNgFVIone.status_code!=200:return cmwYqROxSuTQBJipkWEMhfNgFVIoas,cmwYqROxSuTQBJipkWEMhfNgFVIoar
    cmwYqROxSuTQBJipkWEMhfNgFVIoaK=json.loads(cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
    if cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['result']['code']!='000':
     cmwYqROxSuTQBJipkWEMhfNgFVIoar=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['result']['message']
     return cmwYqROxSuTQBJipkWEMhfNgFVIoas,cmwYqROxSuTQBJipkWEMhfNgFVIoar
    if not('stream' in cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']):return cmwYqROxSuTQBJipkWEMhfNgFVIoas,cmwYqROxSuTQBJipkWEMhfNgFVIoar 
    cmwYqROxSuTQBJipkWEMhfNgFVIoal=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['stream']
    cmwYqROxSuTQBJipkWEMhfNgFVIoaL=cmwYqROxSuTQBJipkWEMhfNgFVIoal['quality']
    cmwYqROxSuTQBJipkWEMhfNgFVIoay=[]
    for cmwYqROxSuTQBJipkWEMhfNgFVIoaG in cmwYqROxSuTQBJipkWEMhfNgFVIoaL:
     if cmwYqROxSuTQBJipkWEMhfNgFVIoaG['active']=='Y':
      cmwYqROxSuTQBJipkWEMhfNgFVIoay.append({cmwYqROxSuTQBJipkWEMhfNgFVIonj.get(cmwYqROxSuTQBJipkWEMhfNgFVIoaG['code']):cmwYqROxSuTQBJipkWEMhfNgFVIoaG['code']})
    cmwYqROxSuTQBJipkWEMhfNgFVIoat=cmwYqROxSuTQBJipkWEMhfNgFVIonX.CheckQuality(sel_quality,cmwYqROxSuTQBJipkWEMhfNgFVIoay)
   else:
    for cmwYqROxSuTQBJipkWEMhfNgFVIoad,cmwYqROxSuTQBJipkWEMhfNgFVIojs in cmwYqROxSuTQBJipkWEMhfNgFVIonj.items():
     if cmwYqROxSuTQBJipkWEMhfNgFVIojs==sel_quality:
      cmwYqROxSuTQBJipkWEMhfNgFVIoat=cmwYqROxSuTQBJipkWEMhfNgFVIoad
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
   for cmwYqROxSuTQBJipkWEMhfNgFVIoad,cmwYqROxSuTQBJipkWEMhfNgFVIojs in cmwYqROxSuTQBJipkWEMhfNgFVIonj.items():
    if cmwYqROxSuTQBJipkWEMhfNgFVIojs==sel_quality:
     cmwYqROxSuTQBJipkWEMhfNgFVIoat=cmwYqROxSuTQBJipkWEMhfNgFVIoad
   return cmwYqROxSuTQBJipkWEMhfNgFVIoas,cmwYqROxSuTQBJipkWEMhfNgFVIoar
  cmwYqROxSuTQBJipkWEMhfNgFVIoUL(cmwYqROxSuTQBJipkWEMhfNgFVIoat)
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/streaming/info'
   cmwYqROxSuTQBJipkWEMhfNgFVIoav=cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetDefaultParams()
   if stype=='onair':cmwYqROxSuTQBJipkWEMhfNgFVIoav['osCode']='CSOD0400' 
   cmwYqROxSuTQBJipkWEMhfNgFVIoae={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   cmwYqROxSuTQBJipkWEMhfNgFVIoaH=cmwYqROxSuTQBJipkWEMhfNgFVIonX.makeOocUrl(cmwYqROxSuTQBJipkWEMhfNgFVIoae)
   cmwYqROxSuTQBJipkWEMhfNgFVIojn=urllib.parse.quote(cmwYqROxSuTQBJipkWEMhfNgFVIoaH)
   cmwYqROxSuTQBJipkWEMhfNgFVIoaD={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':cmwYqROxSuTQBJipkWEMhfNgFVIoat,'adReq':'adproxy','ooc':cmwYqROxSuTQBJipkWEMhfNgFVIoaH,'deviceId':cmwYqROxSuTQBJipkWEMhfNgFVIoaz,'uuid':cmwYqROxSuTQBJipkWEMhfNgFVIoaA,'deviceInfo':'PC'}
   cmwYqROxSuTQBJipkWEMhfNgFVIoja =cmwYqROxSuTQBJipkWEMhfNgFVIoav
   cmwYqROxSuTQBJipkWEMhfNgFVIoja.update(cmwYqROxSuTQBJipkWEMhfNgFVIoaD)
   cmwYqROxSuTQBJipkWEMhfNgFVIoab=cmwYqROxSuTQBJipkWEMhfNgFVIonX.URL_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIojP={'origin':'https://www.tving.com'}
   if stype=='onair':cmwYqROxSuTQBJipkWEMhfNgFVIojP['Referer']='https://www.tving.com/live/player/'+mediacode
   else: cmwYqROxSuTQBJipkWEMhfNgFVIojP['Referer']='https://www.tving.com/vod/player/'+mediacode
   cmwYqROxSuTQBJipkWEMhfNgFVIonr=cmwYqROxSuTQBJipkWEMhfNgFVIonX.makeDefaultCookies()
   cmwYqROxSuTQBJipkWEMhfNgFVIonr['onClickEvent2']=cmwYqROxSuTQBJipkWEMhfNgFVIojn
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Post',cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoja,params=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,headers=cmwYqROxSuTQBJipkWEMhfNgFVIojP,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIonr,redirects=cmwYqROxSuTQBJipkWEMhfNgFVIoUv)
   cmwYqROxSuTQBJipkWEMhfNgFVIoaK=json.loads(cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   if 'drm_license_assertion' in cmwYqROxSuTQBJipkWEMhfNgFVIoaK['stream']:
    cmwYqROxSuTQBJipkWEMhfNgFVIoar =cmwYqROxSuTQBJipkWEMhfNgFVIoaK['stream']['drm_license_assertion']
    cmwYqROxSuTQBJipkWEMhfNgFVIoas=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in cmwYqROxSuTQBJipkWEMhfNgFVIoaK['stream']['broadcast']):return cmwYqROxSuTQBJipkWEMhfNgFVIoas,cmwYqROxSuTQBJipkWEMhfNgFVIoar
    cmwYqROxSuTQBJipkWEMhfNgFVIoas=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['stream']['broadcast']['broad_url']
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  return cmwYqROxSuTQBJipkWEMhfNgFVIoas,cmwYqROxSuTQBJipkWEMhfNgFVIoar
 def CheckQuality(cmwYqROxSuTQBJipkWEMhfNgFVIonX,sel_qt,cmwYqROxSuTQBJipkWEMhfNgFVIoay):
  for cmwYqROxSuTQBJipkWEMhfNgFVIojX in cmwYqROxSuTQBJipkWEMhfNgFVIoay:
   if sel_qt>=cmwYqROxSuTQBJipkWEMhfNgFVIoUG(cmwYqROxSuTQBJipkWEMhfNgFVIojX)[0]:return cmwYqROxSuTQBJipkWEMhfNgFVIojX.get(cmwYqROxSuTQBJipkWEMhfNgFVIoUG(cmwYqROxSuTQBJipkWEMhfNgFVIojX)[0])
   cmwYqROxSuTQBJipkWEMhfNgFVIojU=cmwYqROxSuTQBJipkWEMhfNgFVIojX.get(cmwYqROxSuTQBJipkWEMhfNgFVIoUG(cmwYqROxSuTQBJipkWEMhfNgFVIojX)[0])
  return cmwYqROxSuTQBJipkWEMhfNgFVIojU
 def makeOocUrl(cmwYqROxSuTQBJipkWEMhfNgFVIonX,cmwYqROxSuTQBJipkWEMhfNgFVIoae):
  cmwYqROxSuTQBJipkWEMhfNgFVIoab=''
  for cmwYqROxSuTQBJipkWEMhfNgFVIoad,cmwYqROxSuTQBJipkWEMhfNgFVIojs in cmwYqROxSuTQBJipkWEMhfNgFVIoae.items():
   cmwYqROxSuTQBJipkWEMhfNgFVIoab+="%s=%s^"%(cmwYqROxSuTQBJipkWEMhfNgFVIoad,cmwYqROxSuTQBJipkWEMhfNgFVIojs)
  return cmwYqROxSuTQBJipkWEMhfNgFVIoab
 def GetLiveChannelList(cmwYqROxSuTQBJipkWEMhfNgFVIonX,stype,page_int):
  cmwYqROxSuTQBJipkWEMhfNgFVIojr=[]
  cmwYqROxSuTQBJipkWEMhfNgFVIojz=cmwYqROxSuTQBJipkWEMhfNgFVIoUv
  cmwYqROxSuTQBJipkWEMhfNgFVIojA=cmwYqROxSuTQBJipkWEMhfNgFVIoUv
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/v2/media/lives'
   if stype=='onair': 
    cmwYqROxSuTQBJipkWEMhfNgFVIojC='CPCS0100,CPCS0400'
   else:
    cmwYqROxSuTQBJipkWEMhfNgFVIojC='CPCS0300'
   cmwYqROxSuTQBJipkWEMhfNgFVIoav=cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetDefaultParams()
   cmwYqROxSuTQBJipkWEMhfNgFVIoaD={'pageNo':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(page_int),'pageSize':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':cmwYqROxSuTQBJipkWEMhfNgFVIojC,'_':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetNoCache(2))}
   cmwYqROxSuTQBJipkWEMhfNgFVIoav.update(cmwYqROxSuTQBJipkWEMhfNgFVIoaD)
   cmwYqROxSuTQBJipkWEMhfNgFVIoab=cmwYqROxSuTQBJipkWEMhfNgFVIonX.API_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoav,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIoUC)
   cmwYqROxSuTQBJipkWEMhfNgFVIoaK=json.loads(cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   if not('result' in cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']):return cmwYqROxSuTQBJipkWEMhfNgFVIojr,cmwYqROxSuTQBJipkWEMhfNgFVIojz
   cmwYqROxSuTQBJipkWEMhfNgFVIojv=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['result']
   for cmwYqROxSuTQBJipkWEMhfNgFVIoaG in cmwYqROxSuTQBJipkWEMhfNgFVIojv:
    cmwYqROxSuTQBJipkWEMhfNgFVIojD=cmwYqROxSuTQBJipkWEMhfNgFVIojl=cmwYqROxSuTQBJipkWEMhfNgFVIojL=''
    cmwYqROxSuTQBJipkWEMhfNgFVIojb=cmwYqROxSuTQBJipkWEMhfNgFVIoPv=''
    cmwYqROxSuTQBJipkWEMhfNgFVIojK=cmwYqROxSuTQBJipkWEMhfNgFVIoaG['live_code']
    if cmwYqROxSuTQBJipkWEMhfNgFVIojK=='C01345':cmwYqROxSuTQBJipkWEMhfNgFVIojA=cmwYqROxSuTQBJipkWEMhfNgFVIoUK 
    cmwYqROxSuTQBJipkWEMhfNgFVIojD =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['channel']['name']['ko']
    if cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['episode']!=cmwYqROxSuTQBJipkWEMhfNgFVIoUC:
     cmwYqROxSuTQBJipkWEMhfNgFVIojl =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['program']['name']['ko']
     cmwYqROxSuTQBJipkWEMhfNgFVIojl =cmwYqROxSuTQBJipkWEMhfNgFVIojl+', '+cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['episode']['frequency'])+'회'
     cmwYqROxSuTQBJipkWEMhfNgFVIojL=cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['episode']['synopsis']['ko']
    else:
     cmwYqROxSuTQBJipkWEMhfNgFVIojl =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['program']['name']['ko']
     cmwYqROxSuTQBJipkWEMhfNgFVIojL=cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['program']['synopsis']['ko']
    try: 
     cmwYqROxSuTQBJipkWEMhfNgFVIojy =''
     cmwYqROxSuTQBJipkWEMhfNgFVIojG =''
     cmwYqROxSuTQBJipkWEMhfNgFVIojt=''
     cmwYqROxSuTQBJipkWEMhfNgFVIojd =''
     cmwYqROxSuTQBJipkWEMhfNgFVIoje =''
     cmwYqROxSuTQBJipkWEMhfNgFVIojH =''
     for cmwYqROxSuTQBJipkWEMhfNgFVIoPn in cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['program']['image']:
      if cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP0900':cmwYqROxSuTQBJipkWEMhfNgFVIojG =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
      elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP1800':cmwYqROxSuTQBJipkWEMhfNgFVIojt=cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
      elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP2000':cmwYqROxSuTQBJipkWEMhfNgFVIojd =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
      elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP1900':cmwYqROxSuTQBJipkWEMhfNgFVIoje =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
      elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP0200':cmwYqROxSuTQBJipkWEMhfNgFVIojH =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
      elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP0500':cmwYqROxSuTQBJipkWEMhfNgFVIojy =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
      elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP0800':cmwYqROxSuTQBJipkWEMhfNgFVIojy =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
     if cmwYqROxSuTQBJipkWEMhfNgFVIojy=='':
      for cmwYqROxSuTQBJipkWEMhfNgFVIoPn in cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['channel']['image']:
       if cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIC0400':cmwYqROxSuTQBJipkWEMhfNgFVIojy =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
       elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIC1400':cmwYqROxSuTQBJipkWEMhfNgFVIojy =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
       elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIC1900':cmwYqROxSuTQBJipkWEMhfNgFVIojy =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
    except:
     cmwYqROxSuTQBJipkWEMhfNgFVIoUC
    try:
     cmwYqROxSuTQBJipkWEMhfNgFVIoPa =[]
     cmwYqROxSuTQBJipkWEMhfNgFVIoPj=[]
     cmwYqROxSuTQBJipkWEMhfNgFVIoPX =[]
     cmwYqROxSuTQBJipkWEMhfNgFVIoPU=''
     cmwYqROxSuTQBJipkWEMhfNgFVIoPs=''
     cmwYqROxSuTQBJipkWEMhfNgFVIoPr=''
     for cmwYqROxSuTQBJipkWEMhfNgFVIoPz in cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('schedule').get('program').get('actor'):
      if cmwYqROxSuTQBJipkWEMhfNgFVIoPz!='' and cmwYqROxSuTQBJipkWEMhfNgFVIoPz!=u'없음':cmwYqROxSuTQBJipkWEMhfNgFVIoPa.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPz)
     for cmwYqROxSuTQBJipkWEMhfNgFVIoPA in cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('schedule').get('program').get('director'):
      if cmwYqROxSuTQBJipkWEMhfNgFVIoPA!='' and cmwYqROxSuTQBJipkWEMhfNgFVIoPA!='-' and cmwYqROxSuTQBJipkWEMhfNgFVIoPA!=u'없음':cmwYqROxSuTQBJipkWEMhfNgFVIoPj.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPA)
     if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('schedule').get('program').get('category1_name').get('ko')!='':
      cmwYqROxSuTQBJipkWEMhfNgFVIoPX.append(cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['program']['category1_name']['ko'])
     if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('schedule').get('program').get('category2_name').get('ko')!='':
      cmwYqROxSuTQBJipkWEMhfNgFVIoPX.append(cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['program']['category2_name']['ko'])
     if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('schedule').get('program').get('product_year'):cmwYqROxSuTQBJipkWEMhfNgFVIoPU=cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['program']['product_year']
     if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('schedule').get('program').get('grade_code') :cmwYqROxSuTQBJipkWEMhfNgFVIoPs= cmwYqROxSuTQBJipkWEMhfNgFVIonP.get(cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['program']['grade_code'])
     if 'broad_dt' in cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('schedule').get('program'):
      cmwYqROxSuTQBJipkWEMhfNgFVIoPC =cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('schedule').get('program').get('broad_dt')
      cmwYqROxSuTQBJipkWEMhfNgFVIoPr='%s-%s-%s'%(cmwYqROxSuTQBJipkWEMhfNgFVIoPC[:4],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[4:6],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[6:])
    except:
     cmwYqROxSuTQBJipkWEMhfNgFVIoUC
    cmwYqROxSuTQBJipkWEMhfNgFVIojb=cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['broadcast_start_time'])[8:12]
    cmwYqROxSuTQBJipkWEMhfNgFVIoPv =cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIoaG['schedule']['broadcast_end_time'])[8:12]
    cmwYqROxSuTQBJipkWEMhfNgFVIoPD={'channel':cmwYqROxSuTQBJipkWEMhfNgFVIojD,'title':cmwYqROxSuTQBJipkWEMhfNgFVIojl,'mediacode':cmwYqROxSuTQBJipkWEMhfNgFVIojK,'thumbnail':{'poster':cmwYqROxSuTQBJipkWEMhfNgFVIojG,'thumb':cmwYqROxSuTQBJipkWEMhfNgFVIojy,'clearlogo':cmwYqROxSuTQBJipkWEMhfNgFVIojt,'icon':cmwYqROxSuTQBJipkWEMhfNgFVIojd,'fanart':cmwYqROxSuTQBJipkWEMhfNgFVIojH},'synopsis':cmwYqROxSuTQBJipkWEMhfNgFVIojL,'channelepg':' [%s:%s ~ %s:%s]'%(cmwYqROxSuTQBJipkWEMhfNgFVIojb[0:2],cmwYqROxSuTQBJipkWEMhfNgFVIojb[2:],cmwYqROxSuTQBJipkWEMhfNgFVIoPv[0:2],cmwYqROxSuTQBJipkWEMhfNgFVIoPv[2:]),'cast':cmwYqROxSuTQBJipkWEMhfNgFVIoPa,'director':cmwYqROxSuTQBJipkWEMhfNgFVIoPj,'info_genre':cmwYqROxSuTQBJipkWEMhfNgFVIoPX,'year':cmwYqROxSuTQBJipkWEMhfNgFVIoPU,'mpaa':cmwYqROxSuTQBJipkWEMhfNgFVIoPs,'premiered':cmwYqROxSuTQBJipkWEMhfNgFVIoPr}
    cmwYqROxSuTQBJipkWEMhfNgFVIojr.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPD)
   if cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['has_more']=='Y':
    cmwYqROxSuTQBJipkWEMhfNgFVIojz=cmwYqROxSuTQBJipkWEMhfNgFVIoUK
   else:
    cmwYqROxSuTQBJipkWEMhfNgFVIoPD={'channel':'OCN Original','title':'temp','mediacode':'C01345','thumbnail':'http://image.tving.com/upload/cms/caic/CAIC0400/C01345.png','cast':[],'director':[]}
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  return cmwYqROxSuTQBJipkWEMhfNgFVIojr,cmwYqROxSuTQBJipkWEMhfNgFVIojz
 def GetProgramList(cmwYqROxSuTQBJipkWEMhfNgFVIonX,genre,orderby,page_int,genreCode='all'):
  cmwYqROxSuTQBJipkWEMhfNgFVIojr=[]
  cmwYqROxSuTQBJipkWEMhfNgFVIojz=cmwYqROxSuTQBJipkWEMhfNgFVIoUv
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/v2/media/episodes'
   cmwYqROxSuTQBJipkWEMhfNgFVIoav=cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetDefaultParams()
   cmwYqROxSuTQBJipkWEMhfNgFVIoaD={'pageNo':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(page_int),'pageSize':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetNoCache(2))}
   if genre !='all':cmwYqROxSuTQBJipkWEMhfNgFVIoaD['categoryCode']=genre
   if genreCode!='all':cmwYqROxSuTQBJipkWEMhfNgFVIoaD['genreCode'] =genreCode 
   cmwYqROxSuTQBJipkWEMhfNgFVIoav.update(cmwYqROxSuTQBJipkWEMhfNgFVIoaD)
   cmwYqROxSuTQBJipkWEMhfNgFVIoab=cmwYqROxSuTQBJipkWEMhfNgFVIonX.API_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoav,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIoUC)
   cmwYqROxSuTQBJipkWEMhfNgFVIoaK=json.loads(cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   if not('result' in cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']):return cmwYqROxSuTQBJipkWEMhfNgFVIojr,cmwYqROxSuTQBJipkWEMhfNgFVIojz
   cmwYqROxSuTQBJipkWEMhfNgFVIojv=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['result']
   for cmwYqROxSuTQBJipkWEMhfNgFVIoaG in cmwYqROxSuTQBJipkWEMhfNgFVIojv:
    cmwYqROxSuTQBJipkWEMhfNgFVIoPb=cmwYqROxSuTQBJipkWEMhfNgFVIoaG['program']['code']
    cmwYqROxSuTQBJipkWEMhfNgFVIojl =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['program']['name']['ko']
    cmwYqROxSuTQBJipkWEMhfNgFVIoPs =cmwYqROxSuTQBJipkWEMhfNgFVIonP.get(cmwYqROxSuTQBJipkWEMhfNgFVIoaG['program'].get('grade_code'))
    cmwYqROxSuTQBJipkWEMhfNgFVIojG =''
    cmwYqROxSuTQBJipkWEMhfNgFVIojy =''
    cmwYqROxSuTQBJipkWEMhfNgFVIojt=''
    cmwYqROxSuTQBJipkWEMhfNgFVIojd =''
    cmwYqROxSuTQBJipkWEMhfNgFVIoje =''
    for cmwYqROxSuTQBJipkWEMhfNgFVIoPn in cmwYqROxSuTQBJipkWEMhfNgFVIoaG['program']['image']:
     if cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP0900':cmwYqROxSuTQBJipkWEMhfNgFVIojG =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
     elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP0200':cmwYqROxSuTQBJipkWEMhfNgFVIojy =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
     elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP1800':cmwYqROxSuTQBJipkWEMhfNgFVIojt=cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
     elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP2000':cmwYqROxSuTQBJipkWEMhfNgFVIojd =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
     elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP1900':cmwYqROxSuTQBJipkWEMhfNgFVIoje =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
    cmwYqROxSuTQBJipkWEMhfNgFVIojL =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['program']['synopsis']['ko']
    try:
     cmwYqROxSuTQBJipkWEMhfNgFVIoPK=cmwYqROxSuTQBJipkWEMhfNgFVIoaG['channel']['name']['ko']
    except:
     cmwYqROxSuTQBJipkWEMhfNgFVIoPK=''
    try:
     cmwYqROxSuTQBJipkWEMhfNgFVIoPa =[]
     cmwYqROxSuTQBJipkWEMhfNgFVIoPj=[]
     cmwYqROxSuTQBJipkWEMhfNgFVIoPX =[]
     cmwYqROxSuTQBJipkWEMhfNgFVIoPU =''
     cmwYqROxSuTQBJipkWEMhfNgFVIoPr=''
     for cmwYqROxSuTQBJipkWEMhfNgFVIoPz in cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('program').get('actor'):
      if cmwYqROxSuTQBJipkWEMhfNgFVIoPz!='' and cmwYqROxSuTQBJipkWEMhfNgFVIoPz!='-' and cmwYqROxSuTQBJipkWEMhfNgFVIoPz!=u'없음':cmwYqROxSuTQBJipkWEMhfNgFVIoPa.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPz)
     for cmwYqROxSuTQBJipkWEMhfNgFVIoPA in cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('program').get('director'):
      if cmwYqROxSuTQBJipkWEMhfNgFVIoPA!='' and cmwYqROxSuTQBJipkWEMhfNgFVIoPA!='-' and cmwYqROxSuTQBJipkWEMhfNgFVIoPA!=u'없음':cmwYqROxSuTQBJipkWEMhfNgFVIoPj.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPA)
     if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('program').get('category1_name').get('ko')!='':
      cmwYqROxSuTQBJipkWEMhfNgFVIoPX.append(cmwYqROxSuTQBJipkWEMhfNgFVIoaG['program']['category1_name']['ko'])
     if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('program').get('category2_name').get('ko')!='':
      cmwYqROxSuTQBJipkWEMhfNgFVIoPX.append(cmwYqROxSuTQBJipkWEMhfNgFVIoaG['program']['category2_name']['ko'])
     if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('program').get('product_year'):cmwYqROxSuTQBJipkWEMhfNgFVIoPU=cmwYqROxSuTQBJipkWEMhfNgFVIoaG['program']['product_year']
     if 'broad_dt' in cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('program'):
      cmwYqROxSuTQBJipkWEMhfNgFVIoPC =cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('program').get('broad_dt')
      cmwYqROxSuTQBJipkWEMhfNgFVIoPr='%s-%s-%s'%(cmwYqROxSuTQBJipkWEMhfNgFVIoPC[:4],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[4:6],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[6:])
    except:
     cmwYqROxSuTQBJipkWEMhfNgFVIoUC
    cmwYqROxSuTQBJipkWEMhfNgFVIoPD={'program':cmwYqROxSuTQBJipkWEMhfNgFVIoPb,'title':cmwYqROxSuTQBJipkWEMhfNgFVIojl,'thumbnail':{'poster':cmwYqROxSuTQBJipkWEMhfNgFVIojG,'thumb':cmwYqROxSuTQBJipkWEMhfNgFVIojy,'clearlogo':cmwYqROxSuTQBJipkWEMhfNgFVIojt,'icon':cmwYqROxSuTQBJipkWEMhfNgFVIojd,'banner':cmwYqROxSuTQBJipkWEMhfNgFVIoje,'fanart':cmwYqROxSuTQBJipkWEMhfNgFVIojy},'synopsis':cmwYqROxSuTQBJipkWEMhfNgFVIojL,'channel':cmwYqROxSuTQBJipkWEMhfNgFVIoPK,'cast':cmwYqROxSuTQBJipkWEMhfNgFVIoPa,'director':cmwYqROxSuTQBJipkWEMhfNgFVIoPj,'info_genre':cmwYqROxSuTQBJipkWEMhfNgFVIoPX,'year':cmwYqROxSuTQBJipkWEMhfNgFVIoPU,'premiered':cmwYqROxSuTQBJipkWEMhfNgFVIoPr,'mpaa':cmwYqROxSuTQBJipkWEMhfNgFVIoPs}
    cmwYqROxSuTQBJipkWEMhfNgFVIojr.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPD)
   if cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['has_more']=='Y':cmwYqROxSuTQBJipkWEMhfNgFVIojz=cmwYqROxSuTQBJipkWEMhfNgFVIoUK
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  return cmwYqROxSuTQBJipkWEMhfNgFVIojr,cmwYqROxSuTQBJipkWEMhfNgFVIojz
 def GetEpisodeList(cmwYqROxSuTQBJipkWEMhfNgFVIonX,program_code,page_int,orderby='desc'):
  cmwYqROxSuTQBJipkWEMhfNgFVIojr=[]
  cmwYqROxSuTQBJipkWEMhfNgFVIojz=cmwYqROxSuTQBJipkWEMhfNgFVIoUv
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/v2/media/frequency/program/'+program_code
   cmwYqROxSuTQBJipkWEMhfNgFVIoav=cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetDefaultParams()
   cmwYqROxSuTQBJipkWEMhfNgFVIoaD={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetNoCache(2))}
   cmwYqROxSuTQBJipkWEMhfNgFVIoav.update(cmwYqROxSuTQBJipkWEMhfNgFVIoaD)
   cmwYqROxSuTQBJipkWEMhfNgFVIoab=cmwYqROxSuTQBJipkWEMhfNgFVIonX.API_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoav,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIoUC)
   cmwYqROxSuTQBJipkWEMhfNgFVIoaK=json.loads(cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   if not('result' in cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']):return cmwYqROxSuTQBJipkWEMhfNgFVIojr,cmwYqROxSuTQBJipkWEMhfNgFVIojz
   cmwYqROxSuTQBJipkWEMhfNgFVIojv=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['result']
   cmwYqROxSuTQBJipkWEMhfNgFVIoPl=cmwYqROxSuTQBJipkWEMhfNgFVIoUD(cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['total_count'])
   cmwYqROxSuTQBJipkWEMhfNgFVIoPL =cmwYqROxSuTQBJipkWEMhfNgFVIoUD(cmwYqROxSuTQBJipkWEMhfNgFVIoPl//(cmwYqROxSuTQBJipkWEMhfNgFVIonX.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    cmwYqROxSuTQBJipkWEMhfNgFVIoPy =(cmwYqROxSuTQBJipkWEMhfNgFVIoPl-1)-((page_int-1)*cmwYqROxSuTQBJipkWEMhfNgFVIonX.EPISODE_LIMIT)
   else:
    cmwYqROxSuTQBJipkWEMhfNgFVIoPy =(page_int-1)*cmwYqROxSuTQBJipkWEMhfNgFVIonX.EPISODE_LIMIT
   for i in cmwYqROxSuTQBJipkWEMhfNgFVIoUb(cmwYqROxSuTQBJipkWEMhfNgFVIonX.EPISODE_LIMIT):
    if orderby=='desc':
     cmwYqROxSuTQBJipkWEMhfNgFVIoPG=cmwYqROxSuTQBJipkWEMhfNgFVIoPy-i
     if cmwYqROxSuTQBJipkWEMhfNgFVIoPG<0:break
    else:
     cmwYqROxSuTQBJipkWEMhfNgFVIoPG=cmwYqROxSuTQBJipkWEMhfNgFVIoPy+i
     if cmwYqROxSuTQBJipkWEMhfNgFVIoPG>=cmwYqROxSuTQBJipkWEMhfNgFVIoPl:break
    cmwYqROxSuTQBJipkWEMhfNgFVIoPt=cmwYqROxSuTQBJipkWEMhfNgFVIojv[cmwYqROxSuTQBJipkWEMhfNgFVIoPG]['episode']['code']
    cmwYqROxSuTQBJipkWEMhfNgFVIojl =cmwYqROxSuTQBJipkWEMhfNgFVIojv[cmwYqROxSuTQBJipkWEMhfNgFVIoPG]['vod_name']['ko']
    cmwYqROxSuTQBJipkWEMhfNgFVIoPd =''
    try:
     cmwYqROxSuTQBJipkWEMhfNgFVIoPC=cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIojv[cmwYqROxSuTQBJipkWEMhfNgFVIoPG]['episode']['broadcast_date'])
     cmwYqROxSuTQBJipkWEMhfNgFVIoPd='%s-%s-%s'%(cmwYqROxSuTQBJipkWEMhfNgFVIoPC[:4],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[4:6],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[6:])
    except:
     cmwYqROxSuTQBJipkWEMhfNgFVIoUC
    try:
     if cmwYqROxSuTQBJipkWEMhfNgFVIojv[cmwYqROxSuTQBJipkWEMhfNgFVIoPG]['episode']['pip_cliptype']=='C012':
      cmwYqROxSuTQBJipkWEMhfNgFVIoPd+=' - Quick VOD'
    except:
     cmwYqROxSuTQBJipkWEMhfNgFVIoUC
    cmwYqROxSuTQBJipkWEMhfNgFVIojL =cmwYqROxSuTQBJipkWEMhfNgFVIojv[cmwYqROxSuTQBJipkWEMhfNgFVIoPG]['episode']['synopsis']['ko']
    cmwYqROxSuTQBJipkWEMhfNgFVIojG =''
    cmwYqROxSuTQBJipkWEMhfNgFVIojy =''
    cmwYqROxSuTQBJipkWEMhfNgFVIojt=''
    cmwYqROxSuTQBJipkWEMhfNgFVIojd =''
    cmwYqROxSuTQBJipkWEMhfNgFVIoje =''
    cmwYqROxSuTQBJipkWEMhfNgFVIojH =''
    for cmwYqROxSuTQBJipkWEMhfNgFVIoPn in cmwYqROxSuTQBJipkWEMhfNgFVIojv[cmwYqROxSuTQBJipkWEMhfNgFVIoPG]['program']['image']:
     if cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP0900':cmwYqROxSuTQBJipkWEMhfNgFVIojG =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
     elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP1800':cmwYqROxSuTQBJipkWEMhfNgFVIojt=cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
     elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP2000':cmwYqROxSuTQBJipkWEMhfNgFVIojd =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
     elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP1900':cmwYqROxSuTQBJipkWEMhfNgFVIoje =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
     elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIP0200':cmwYqROxSuTQBJipkWEMhfNgFVIojH =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
    for cmwYqROxSuTQBJipkWEMhfNgFVIoPn in cmwYqROxSuTQBJipkWEMhfNgFVIojv[cmwYqROxSuTQBJipkWEMhfNgFVIoPG]['episode']['image']:
     if cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIE0400':cmwYqROxSuTQBJipkWEMhfNgFVIojy =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
    try:
     cmwYqROxSuTQBJipkWEMhfNgFVIoPe=cmwYqROxSuTQBJipkWEMhfNgFVIoXn=cmwYqROxSuTQBJipkWEMhfNgFVIoXa=''
     cmwYqROxSuTQBJipkWEMhfNgFVIoPH=0
     cmwYqROxSuTQBJipkWEMhfNgFVIoPe =cmwYqROxSuTQBJipkWEMhfNgFVIojv[cmwYqROxSuTQBJipkWEMhfNgFVIoPG]['program']['name']['ko']
     cmwYqROxSuTQBJipkWEMhfNgFVIoXn =cmwYqROxSuTQBJipkWEMhfNgFVIoPd
     cmwYqROxSuTQBJipkWEMhfNgFVIoXa =cmwYqROxSuTQBJipkWEMhfNgFVIojv[cmwYqROxSuTQBJipkWEMhfNgFVIoPG]['channel']['name']['ko']
     if 'frequency' in cmwYqROxSuTQBJipkWEMhfNgFVIojv[cmwYqROxSuTQBJipkWEMhfNgFVIoPG]['episode']:cmwYqROxSuTQBJipkWEMhfNgFVIoPH=cmwYqROxSuTQBJipkWEMhfNgFVIojv[cmwYqROxSuTQBJipkWEMhfNgFVIoPG]['episode']['frequency']
    except:
     cmwYqROxSuTQBJipkWEMhfNgFVIoUC
    cmwYqROxSuTQBJipkWEMhfNgFVIoPD={'episode':cmwYqROxSuTQBJipkWEMhfNgFVIoPt,'title':cmwYqROxSuTQBJipkWEMhfNgFVIojl,'subtitle':cmwYqROxSuTQBJipkWEMhfNgFVIoPd,'thumbnail':{'poster':cmwYqROxSuTQBJipkWEMhfNgFVIojG,'thumb':cmwYqROxSuTQBJipkWEMhfNgFVIojy,'clearlogo':cmwYqROxSuTQBJipkWEMhfNgFVIojt,'icon':cmwYqROxSuTQBJipkWEMhfNgFVIojd,'banner':cmwYqROxSuTQBJipkWEMhfNgFVIoje,'fanart':cmwYqROxSuTQBJipkWEMhfNgFVIojH},'synopsis':cmwYqROxSuTQBJipkWEMhfNgFVIojL,'info_title':cmwYqROxSuTQBJipkWEMhfNgFVIoPe,'aired':cmwYqROxSuTQBJipkWEMhfNgFVIoXn,'studio':cmwYqROxSuTQBJipkWEMhfNgFVIoXa,'frequency':cmwYqROxSuTQBJipkWEMhfNgFVIoPH}
    cmwYqROxSuTQBJipkWEMhfNgFVIojr.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPD)
   if cmwYqROxSuTQBJipkWEMhfNgFVIoPL>page_int:cmwYqROxSuTQBJipkWEMhfNgFVIojz=cmwYqROxSuTQBJipkWEMhfNgFVIoUK
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  return cmwYqROxSuTQBJipkWEMhfNgFVIojr,cmwYqROxSuTQBJipkWEMhfNgFVIojz,cmwYqROxSuTQBJipkWEMhfNgFVIoPL
 def GetMovieList(cmwYqROxSuTQBJipkWEMhfNgFVIonX,genre,orderby,page_int):
  cmwYqROxSuTQBJipkWEMhfNgFVIojr=[]
  cmwYqROxSuTQBJipkWEMhfNgFVIojz=cmwYqROxSuTQBJipkWEMhfNgFVIoUv
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/v2/media/movies'
   cmwYqROxSuTQBJipkWEMhfNgFVIoav=cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetDefaultParams()
   cmwYqROxSuTQBJipkWEMhfNgFVIoaD={'pageNo':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(page_int),'pageSize':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetNoCache(2))}
   if genre!='all' :cmwYqROxSuTQBJipkWEMhfNgFVIoaD['multiCategoryCode']=genre
   cmwYqROxSuTQBJipkWEMhfNgFVIoaD['productPackageCode']=','.join(cmwYqROxSuTQBJipkWEMhfNgFVIonX.MOVIE_LITE)
   cmwYqROxSuTQBJipkWEMhfNgFVIoav.update(cmwYqROxSuTQBJipkWEMhfNgFVIoaD)
   cmwYqROxSuTQBJipkWEMhfNgFVIoab=cmwYqROxSuTQBJipkWEMhfNgFVIonX.API_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoav,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIoUC)
   cmwYqROxSuTQBJipkWEMhfNgFVIoaK=json.loads(cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   if not('result' in cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']):return cmwYqROxSuTQBJipkWEMhfNgFVIojr,cmwYqROxSuTQBJipkWEMhfNgFVIojz
   cmwYqROxSuTQBJipkWEMhfNgFVIojv=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['result']
   for cmwYqROxSuTQBJipkWEMhfNgFVIoaG in cmwYqROxSuTQBJipkWEMhfNgFVIojv:
    cmwYqROxSuTQBJipkWEMhfNgFVIoXj =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['movie']['code']
    cmwYqROxSuTQBJipkWEMhfNgFVIojl =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['movie']['name']['ko'].strip()
    cmwYqROxSuTQBJipkWEMhfNgFVIojl +=u' (%s)'%(cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('movie').get('product_year'))
    cmwYqROxSuTQBJipkWEMhfNgFVIojG=''
    cmwYqROxSuTQBJipkWEMhfNgFVIojy =''
    cmwYqROxSuTQBJipkWEMhfNgFVIojt=''
    for cmwYqROxSuTQBJipkWEMhfNgFVIoPn in cmwYqROxSuTQBJipkWEMhfNgFVIoaG['movie']['image']:
     if cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIM2100':cmwYqROxSuTQBJipkWEMhfNgFVIojG =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
     elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIM0400':cmwYqROxSuTQBJipkWEMhfNgFVIojy =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
     elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIM1800':cmwYqROxSuTQBJipkWEMhfNgFVIojt=cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
    cmwYqROxSuTQBJipkWEMhfNgFVIojL =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['movie']['story']['ko']
    try:
     cmwYqROxSuTQBJipkWEMhfNgFVIoPe =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['movie']['name']['ko'].strip()
     cmwYqROxSuTQBJipkWEMhfNgFVIoPU =cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('movie').get('product_year')
     cmwYqROxSuTQBJipkWEMhfNgFVIoPs =cmwYqROxSuTQBJipkWEMhfNgFVIonP.get(cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('grade_code'))
     cmwYqROxSuTQBJipkWEMhfNgFVIoPa=[]
     cmwYqROxSuTQBJipkWEMhfNgFVIoPj=[]
     cmwYqROxSuTQBJipkWEMhfNgFVIoPX=[]
     cmwYqROxSuTQBJipkWEMhfNgFVIoXP=0
     cmwYqROxSuTQBJipkWEMhfNgFVIoPr=''
     cmwYqROxSuTQBJipkWEMhfNgFVIoXa =''
     for cmwYqROxSuTQBJipkWEMhfNgFVIoPz in cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('movie').get('actor'):
      if cmwYqROxSuTQBJipkWEMhfNgFVIoPz!='':cmwYqROxSuTQBJipkWEMhfNgFVIoPa.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPz)
     for cmwYqROxSuTQBJipkWEMhfNgFVIoPA in cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('movie').get('director'):
      if cmwYqROxSuTQBJipkWEMhfNgFVIoPA!='':cmwYqROxSuTQBJipkWEMhfNgFVIoPj.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPA)
     if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('movie').get('category1_name').get('ko')!='':
      cmwYqROxSuTQBJipkWEMhfNgFVIoPX.append(cmwYqROxSuTQBJipkWEMhfNgFVIoaG['movie']['category1_name']['ko'])
     if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('movie').get('category2_name').get('ko')!='':
      cmwYqROxSuTQBJipkWEMhfNgFVIoPX.append(cmwYqROxSuTQBJipkWEMhfNgFVIoaG['movie']['category2_name']['ko'])
     if 'duration' in cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('movie'):cmwYqROxSuTQBJipkWEMhfNgFVIoXP=cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('movie').get('duration')
     if 'release_date' in cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('movie'):
      cmwYqROxSuTQBJipkWEMhfNgFVIoPC=cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('movie').get('release_date'))
      if cmwYqROxSuTQBJipkWEMhfNgFVIoPC!='0':cmwYqROxSuTQBJipkWEMhfNgFVIoPr='%s-%s-%s'%(cmwYqROxSuTQBJipkWEMhfNgFVIoPC[:4],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[4:6],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[6:])
     if 'production' in cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('movie'):cmwYqROxSuTQBJipkWEMhfNgFVIoXa=cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('movie').get('production')
    except:
     cmwYqROxSuTQBJipkWEMhfNgFVIoUC
    cmwYqROxSuTQBJipkWEMhfNgFVIoPD={'moviecode':cmwYqROxSuTQBJipkWEMhfNgFVIoXj,'title':cmwYqROxSuTQBJipkWEMhfNgFVIojl,'thumbnail':{'poster':cmwYqROxSuTQBJipkWEMhfNgFVIojG,'thumb':cmwYqROxSuTQBJipkWEMhfNgFVIojy,'clearlogo':cmwYqROxSuTQBJipkWEMhfNgFVIojt,'fanart':cmwYqROxSuTQBJipkWEMhfNgFVIojy},'synopsis':cmwYqROxSuTQBJipkWEMhfNgFVIojL,'info_title':cmwYqROxSuTQBJipkWEMhfNgFVIoPe,'year':cmwYqROxSuTQBJipkWEMhfNgFVIoPU,'cast':cmwYqROxSuTQBJipkWEMhfNgFVIoPa,'director':cmwYqROxSuTQBJipkWEMhfNgFVIoPj,'info_genre':cmwYqROxSuTQBJipkWEMhfNgFVIoPX,'duration':cmwYqROxSuTQBJipkWEMhfNgFVIoXP,'premiered':cmwYqROxSuTQBJipkWEMhfNgFVIoPr,'studio':cmwYqROxSuTQBJipkWEMhfNgFVIoXa,'mpaa':cmwYqROxSuTQBJipkWEMhfNgFVIoPs}
    cmwYqROxSuTQBJipkWEMhfNgFVIoXU=cmwYqROxSuTQBJipkWEMhfNgFVIoUv
    for cmwYqROxSuTQBJipkWEMhfNgFVIoXs in cmwYqROxSuTQBJipkWEMhfNgFVIoaG['billing_package_id']:
     if cmwYqROxSuTQBJipkWEMhfNgFVIoXs in cmwYqROxSuTQBJipkWEMhfNgFVIonX.MOVIE_LITE:
      cmwYqROxSuTQBJipkWEMhfNgFVIoXU=cmwYqROxSuTQBJipkWEMhfNgFVIoUK
      break
    if cmwYqROxSuTQBJipkWEMhfNgFVIoXU==cmwYqROxSuTQBJipkWEMhfNgFVIoUv: 
     cmwYqROxSuTQBJipkWEMhfNgFVIoPD['title']=cmwYqROxSuTQBJipkWEMhfNgFVIoPD['title']+' [개별구매]'
    cmwYqROxSuTQBJipkWEMhfNgFVIojr.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPD)
   if cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['has_more']=='Y':cmwYqROxSuTQBJipkWEMhfNgFVIojz=cmwYqROxSuTQBJipkWEMhfNgFVIoUK
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  return cmwYqROxSuTQBJipkWEMhfNgFVIojr,cmwYqROxSuTQBJipkWEMhfNgFVIojz
 def GetMovieListGenre(cmwYqROxSuTQBJipkWEMhfNgFVIonX,genre,page_int):
  cmwYqROxSuTQBJipkWEMhfNgFVIojr=[]
  cmwYqROxSuTQBJipkWEMhfNgFVIojz=cmwYqROxSuTQBJipkWEMhfNgFVIoUv
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/v2/media/movie/curation/'+genre
   cmwYqROxSuTQBJipkWEMhfNgFVIoav=cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetDefaultParams()
   cmwYqROxSuTQBJipkWEMhfNgFVIoaD={'pageNo':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(page_int),'pageSize':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.MOVIE_LIMIT),'_':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetNoCache(2))}
   cmwYqROxSuTQBJipkWEMhfNgFVIoav.update(cmwYqROxSuTQBJipkWEMhfNgFVIoaD)
   cmwYqROxSuTQBJipkWEMhfNgFVIoab=cmwYqROxSuTQBJipkWEMhfNgFVIonX.API_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoav,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIoUC)
   cmwYqROxSuTQBJipkWEMhfNgFVIoaK=json.loads(cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   if not('movies' in cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']):return cmwYqROxSuTQBJipkWEMhfNgFVIojr,cmwYqROxSuTQBJipkWEMhfNgFVIojz
   cmwYqROxSuTQBJipkWEMhfNgFVIojv=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['movies']
   for cmwYqROxSuTQBJipkWEMhfNgFVIoaG in cmwYqROxSuTQBJipkWEMhfNgFVIojv:
    cmwYqROxSuTQBJipkWEMhfNgFVIoXj =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['code']
    cmwYqROxSuTQBJipkWEMhfNgFVIojl =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['name']['ko']
    cmwYqROxSuTQBJipkWEMhfNgFVIoXr =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaG['image'][0]['url']
    for cmwYqROxSuTQBJipkWEMhfNgFVIoPn in cmwYqROxSuTQBJipkWEMhfNgFVIoaG['image']:
     if cmwYqROxSuTQBJipkWEMhfNgFVIoPn['code']=='CAIM2100':
      cmwYqROxSuTQBJipkWEMhfNgFVIoXr =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn['url']
    cmwYqROxSuTQBJipkWEMhfNgFVIojL =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['story']['ko']
    cmwYqROxSuTQBJipkWEMhfNgFVIoPD={'moviecode':cmwYqROxSuTQBJipkWEMhfNgFVIoXj,'title':cmwYqROxSuTQBJipkWEMhfNgFVIojl.strip(),'thumbnail':cmwYqROxSuTQBJipkWEMhfNgFVIoXr,'synopsis':cmwYqROxSuTQBJipkWEMhfNgFVIojL}
    cmwYqROxSuTQBJipkWEMhfNgFVIojr.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPD)
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  return cmwYqROxSuTQBJipkWEMhfNgFVIojr,cmwYqROxSuTQBJipkWEMhfNgFVIojz
 def GetMovieGenre(cmwYqROxSuTQBJipkWEMhfNgFVIonX):
  cmwYqROxSuTQBJipkWEMhfNgFVIojr=[]
  cmwYqROxSuTQBJipkWEMhfNgFVIojz=cmwYqROxSuTQBJipkWEMhfNgFVIoUv
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/v2/media/movie/curations'
   cmwYqROxSuTQBJipkWEMhfNgFVIoav=cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetDefaultParams()
   cmwYqROxSuTQBJipkWEMhfNgFVIoaD={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetNoCache(2))}
   cmwYqROxSuTQBJipkWEMhfNgFVIoav.update(cmwYqROxSuTQBJipkWEMhfNgFVIoaD)
   cmwYqROxSuTQBJipkWEMhfNgFVIoab=cmwYqROxSuTQBJipkWEMhfNgFVIonX.API_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoav,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIoUC)
   cmwYqROxSuTQBJipkWEMhfNgFVIoaK=json.loads(cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   if not('result' in cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']):return cmwYqROxSuTQBJipkWEMhfNgFVIojr,cmwYqROxSuTQBJipkWEMhfNgFVIojz
   cmwYqROxSuTQBJipkWEMhfNgFVIojv=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['result']
   for cmwYqROxSuTQBJipkWEMhfNgFVIoaG in cmwYqROxSuTQBJipkWEMhfNgFVIojv:
    cmwYqROxSuTQBJipkWEMhfNgFVIoXz =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['curation_code']
    cmwYqROxSuTQBJipkWEMhfNgFVIoXA =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['curation_name']
    cmwYqROxSuTQBJipkWEMhfNgFVIoPD={'curation_code':cmwYqROxSuTQBJipkWEMhfNgFVIoXz,'curation_name':cmwYqROxSuTQBJipkWEMhfNgFVIoXA}
    cmwYqROxSuTQBJipkWEMhfNgFVIojr.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPD)
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  return cmwYqROxSuTQBJipkWEMhfNgFVIojr,cmwYqROxSuTQBJipkWEMhfNgFVIojz
 def GetSearchList(cmwYqROxSuTQBJipkWEMhfNgFVIonX,search_key,page_int,stype):
  cmwYqROxSuTQBJipkWEMhfNgFVIoXC=[]
  cmwYqROxSuTQBJipkWEMhfNgFVIojz=cmwYqROxSuTQBJipkWEMhfNgFVIoUv
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/search/getSearch.jsp'
   cmwYqROxSuTQBJipkWEMhfNgFVIoaD={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(page_int),'pageSize':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':cmwYqROxSuTQBJipkWEMhfNgFVIonX.SCREENCODE,'os':cmwYqROxSuTQBJipkWEMhfNgFVIonX.OSCODE,'network':cmwYqROxSuTQBJipkWEMhfNgFVIonX.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetNoCache(2))}
   cmwYqROxSuTQBJipkWEMhfNgFVIoab=cmwYqROxSuTQBJipkWEMhfNgFVIonX.SEARCH_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoaD,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIoUC)
   cmwYqROxSuTQBJipkWEMhfNgFVIoaK=json.loads(cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   if stype=='vod':
    if not('programRsb' in cmwYqROxSuTQBJipkWEMhfNgFVIoaK):return cmwYqROxSuTQBJipkWEMhfNgFVIoXC,cmwYqROxSuTQBJipkWEMhfNgFVIojz
    cmwYqROxSuTQBJipkWEMhfNgFVIoXv=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['programRsb']['dataList']
    cmwYqROxSuTQBJipkWEMhfNgFVIoXD =cmwYqROxSuTQBJipkWEMhfNgFVIoUD(cmwYqROxSuTQBJipkWEMhfNgFVIoaK['programRsb']['count'])
    for cmwYqROxSuTQBJipkWEMhfNgFVIoaG in cmwYqROxSuTQBJipkWEMhfNgFVIoXv:
     cmwYqROxSuTQBJipkWEMhfNgFVIoPb=cmwYqROxSuTQBJipkWEMhfNgFVIoaG['mast_cd']
     cmwYqROxSuTQBJipkWEMhfNgFVIojl =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['mast_nm']
     cmwYqROxSuTQBJipkWEMhfNgFVIojG=cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaG['web_url4']
     cmwYqROxSuTQBJipkWEMhfNgFVIojy =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaG['web_url']
     try:
      cmwYqROxSuTQBJipkWEMhfNgFVIoPa =[]
      cmwYqROxSuTQBJipkWEMhfNgFVIoPj=[]
      cmwYqROxSuTQBJipkWEMhfNgFVIoPX =[]
      cmwYqROxSuTQBJipkWEMhfNgFVIoXP =0
      cmwYqROxSuTQBJipkWEMhfNgFVIoPs =''
      cmwYqROxSuTQBJipkWEMhfNgFVIoPU =''
      cmwYqROxSuTQBJipkWEMhfNgFVIoXn =''
      if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('actor') !='' and cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('actor') !='-':cmwYqROxSuTQBJipkWEMhfNgFVIoPa =cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('actor').split(',')
      if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('director')!='' and cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('director')!='-':cmwYqROxSuTQBJipkWEMhfNgFVIoPj=cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('director').split(',')
      if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('cate_nm')!='' and cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('cate_nm')!='-':cmwYqROxSuTQBJipkWEMhfNgFVIoPX =cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('cate_nm').split('/')
      if 'targetage' in cmwYqROxSuTQBJipkWEMhfNgFVIoaG:cmwYqROxSuTQBJipkWEMhfNgFVIoPs=cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('targetage')
      if 'broad_dt' in cmwYqROxSuTQBJipkWEMhfNgFVIoaG:
       cmwYqROxSuTQBJipkWEMhfNgFVIoPC=cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('broad_dt')
       cmwYqROxSuTQBJipkWEMhfNgFVIoXn='%s-%s-%s'%(cmwYqROxSuTQBJipkWEMhfNgFVIoPC[:4],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[4:6],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[6:])
       cmwYqROxSuTQBJipkWEMhfNgFVIoPU =cmwYqROxSuTQBJipkWEMhfNgFVIoPC[:4]
     except:
      cmwYqROxSuTQBJipkWEMhfNgFVIoUC
     cmwYqROxSuTQBJipkWEMhfNgFVIoPD={'program':cmwYqROxSuTQBJipkWEMhfNgFVIoPb,'title':cmwYqROxSuTQBJipkWEMhfNgFVIojl,'thumbnail':{'poster':cmwYqROxSuTQBJipkWEMhfNgFVIojG,'thumb':cmwYqROxSuTQBJipkWEMhfNgFVIojy,'fanart':cmwYqROxSuTQBJipkWEMhfNgFVIojy},'synopsis':'','cast':cmwYqROxSuTQBJipkWEMhfNgFVIoPa,'director':cmwYqROxSuTQBJipkWEMhfNgFVIoPj,'info_genre':cmwYqROxSuTQBJipkWEMhfNgFVIoPX,'duration':cmwYqROxSuTQBJipkWEMhfNgFVIoXP,'mpaa':cmwYqROxSuTQBJipkWEMhfNgFVIoPs,'year':cmwYqROxSuTQBJipkWEMhfNgFVIoPU,'aired':cmwYqROxSuTQBJipkWEMhfNgFVIoXn}
     cmwYqROxSuTQBJipkWEMhfNgFVIoXC.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPD)
   else:
    if not('vodMVRsb' in cmwYqROxSuTQBJipkWEMhfNgFVIoaK):return cmwYqROxSuTQBJipkWEMhfNgFVIoXC,cmwYqROxSuTQBJipkWEMhfNgFVIojz
    cmwYqROxSuTQBJipkWEMhfNgFVIoXb=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['vodMVRsb']['dataList']
    cmwYqROxSuTQBJipkWEMhfNgFVIoXD =cmwYqROxSuTQBJipkWEMhfNgFVIoUD(cmwYqROxSuTQBJipkWEMhfNgFVIoaK['vodMVRsb']['count'])
    for cmwYqROxSuTQBJipkWEMhfNgFVIoaG in cmwYqROxSuTQBJipkWEMhfNgFVIoXb:
     cmwYqROxSuTQBJipkWEMhfNgFVIoPb=cmwYqROxSuTQBJipkWEMhfNgFVIoaG['mast_cd']
     cmwYqROxSuTQBJipkWEMhfNgFVIojl =cmwYqROxSuTQBJipkWEMhfNgFVIoaG['mast_nm'].strip()
     cmwYqROxSuTQBJipkWEMhfNgFVIojG =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaG['web_url']
     cmwYqROxSuTQBJipkWEMhfNgFVIojy =cmwYqROxSuTQBJipkWEMhfNgFVIojG
     cmwYqROxSuTQBJipkWEMhfNgFVIojt=''
     try:
      cmwYqROxSuTQBJipkWEMhfNgFVIoPa =[]
      cmwYqROxSuTQBJipkWEMhfNgFVIoPj=[]
      cmwYqROxSuTQBJipkWEMhfNgFVIoPX =[]
      cmwYqROxSuTQBJipkWEMhfNgFVIoXP =0
      cmwYqROxSuTQBJipkWEMhfNgFVIoPs =''
      cmwYqROxSuTQBJipkWEMhfNgFVIoPU =''
      cmwYqROxSuTQBJipkWEMhfNgFVIoXn =''
      if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('actor') !='' and cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('actor') !='-':cmwYqROxSuTQBJipkWEMhfNgFVIoPa =cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('actor').split(',')
      if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('director')!='' and cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('director')!='-':cmwYqROxSuTQBJipkWEMhfNgFVIoPj=cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('director').split(',')
      if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('cate_nm')!='' and cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('cate_nm')!='-':cmwYqROxSuTQBJipkWEMhfNgFVIoPX =cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('cate_nm').split('/')
      if cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('runtime_sec')!='':cmwYqROxSuTQBJipkWEMhfNgFVIoXP=cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('runtime_sec')
      if 'grade_nm' in cmwYqROxSuTQBJipkWEMhfNgFVIoaG:cmwYqROxSuTQBJipkWEMhfNgFVIoPs=cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('grade_nm')
      cmwYqROxSuTQBJipkWEMhfNgFVIoPC=cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('broad_dt')
      if data_str!='':
       cmwYqROxSuTQBJipkWEMhfNgFVIoXn='%s-%s-%s'%(cmwYqROxSuTQBJipkWEMhfNgFVIoPC[:4],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[4:6],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[6:])
       cmwYqROxSuTQBJipkWEMhfNgFVIoPU =cmwYqROxSuTQBJipkWEMhfNgFVIoPC[:4]
     except:
      cmwYqROxSuTQBJipkWEMhfNgFVIoUC
     cmwYqROxSuTQBJipkWEMhfNgFVIoPD={'movie':cmwYqROxSuTQBJipkWEMhfNgFVIoPb,'title':cmwYqROxSuTQBJipkWEMhfNgFVIojl,'thumbnail':{'poster':cmwYqROxSuTQBJipkWEMhfNgFVIojG,'thumb':cmwYqROxSuTQBJipkWEMhfNgFVIojy,'fanart':cmwYqROxSuTQBJipkWEMhfNgFVIojy,'clearlogo':cmwYqROxSuTQBJipkWEMhfNgFVIojt},'synopsis':'','cast':cmwYqROxSuTQBJipkWEMhfNgFVIoPa,'director':cmwYqROxSuTQBJipkWEMhfNgFVIoPj,'info_genre':cmwYqROxSuTQBJipkWEMhfNgFVIoPX,'duration':cmwYqROxSuTQBJipkWEMhfNgFVIoXP,'mpaa':cmwYqROxSuTQBJipkWEMhfNgFVIoPs,'year':cmwYqROxSuTQBJipkWEMhfNgFVIoPU,'aired':cmwYqROxSuTQBJipkWEMhfNgFVIoXn}
     cmwYqROxSuTQBJipkWEMhfNgFVIoXU=cmwYqROxSuTQBJipkWEMhfNgFVIoUv
     for cmwYqROxSuTQBJipkWEMhfNgFVIoXs in cmwYqROxSuTQBJipkWEMhfNgFVIoaG['bill']:
      if cmwYqROxSuTQBJipkWEMhfNgFVIoXs in cmwYqROxSuTQBJipkWEMhfNgFVIonX.MOVIE_LITE:
       cmwYqROxSuTQBJipkWEMhfNgFVIoXU=cmwYqROxSuTQBJipkWEMhfNgFVIoUK
       break
     if cmwYqROxSuTQBJipkWEMhfNgFVIoXU==cmwYqROxSuTQBJipkWEMhfNgFVIoUv: 
      cmwYqROxSuTQBJipkWEMhfNgFVIoPD['title']=cmwYqROxSuTQBJipkWEMhfNgFVIoPD['title']+' [개별구매]'
     cmwYqROxSuTQBJipkWEMhfNgFVIoXC.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPD)
   if cmwYqROxSuTQBJipkWEMhfNgFVIoXD>(page_int*cmwYqROxSuTQBJipkWEMhfNgFVIonX.SEARCH_LIMIT):cmwYqROxSuTQBJipkWEMhfNgFVIojz=cmwYqROxSuTQBJipkWEMhfNgFVIoUK
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  return cmwYqROxSuTQBJipkWEMhfNgFVIoXC,cmwYqROxSuTQBJipkWEMhfNgFVIojz
 def GetDeviceList(cmwYqROxSuTQBJipkWEMhfNgFVIonX,cmwYqROxSuTQBJipkWEMhfNgFVIoan,cmwYqROxSuTQBJipkWEMhfNgFVIoaj):
  cmwYqROxSuTQBJipkWEMhfNgFVIojr=[]
  cmwYqROxSuTQBJipkWEMhfNgFVIoaz='-'
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/v1/user/device/list'
   cmwYqROxSuTQBJipkWEMhfNgFVIoXK=cmwYqROxSuTQBJipkWEMhfNgFVIonX.API_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIoaD={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   cmwYqROxSuTQBJipkWEMhfNgFVIonr=cmwYqROxSuTQBJipkWEMhfNgFVIonX.makeDefaultCookies(vToken=cmwYqROxSuTQBJipkWEMhfNgFVIoan,vUserinfo=cmwYqROxSuTQBJipkWEMhfNgFVIoaj)
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoXK,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoaD,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIonr)
   cmwYqROxSuTQBJipkWEMhfNgFVIoaK=json.loads(cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   cmwYqROxSuTQBJipkWEMhfNgFVIojr=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']
   for cmwYqROxSuTQBJipkWEMhfNgFVIoaG in cmwYqROxSuTQBJipkWEMhfNgFVIojr:
    if cmwYqROxSuTQBJipkWEMhfNgFVIoaG['model']=='PC':
     cmwYqROxSuTQBJipkWEMhfNgFVIoaz=cmwYqROxSuTQBJipkWEMhfNgFVIoaG['uuid']
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  return cmwYqROxSuTQBJipkWEMhfNgFVIoaz
 def GetProfileToken(cmwYqROxSuTQBJipkWEMhfNgFVIonX,cmwYqROxSuTQBJipkWEMhfNgFVIoan,cmwYqROxSuTQBJipkWEMhfNgFVIoaj,user_pf):
  cmwYqROxSuTQBJipkWEMhfNgFVIoXl=[]
  cmwYqROxSuTQBJipkWEMhfNgFVIoXL =''
  cmwYqROxSuTQBJipkWEMhfNgFVIoXy =''
  cmwYqROxSuTQBJipkWEMhfNgFVIoXG='Y'
  cmwYqROxSuTQBJipkWEMhfNgFVIoXt ='N'
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/profile/select.do'
   cmwYqROxSuTQBJipkWEMhfNgFVIoXK=cmwYqROxSuTQBJipkWEMhfNgFVIonX.URL_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIonr=cmwYqROxSuTQBJipkWEMhfNgFVIonX.makeDefaultCookies(vToken=cmwYqROxSuTQBJipkWEMhfNgFVIoan,vUserinfo=cmwYqROxSuTQBJipkWEMhfNgFVIoaj)
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoXK,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIonr)
   cmwYqROxSuTQBJipkWEMhfNgFVIoXl =re.findall('data-profile-no="\d+"',cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   for i in cmwYqROxSuTQBJipkWEMhfNgFVIoUb(cmwYqROxSuTQBJipkWEMhfNgFVIoUt(cmwYqROxSuTQBJipkWEMhfNgFVIoXl)):
    cmwYqROxSuTQBJipkWEMhfNgFVIoXd =cmwYqROxSuTQBJipkWEMhfNgFVIoXl[i].replace('data-profile-no=','').replace('"','')
    cmwYqROxSuTQBJipkWEMhfNgFVIoXl[i]=cmwYqROxSuTQBJipkWEMhfNgFVIoXd
   cmwYqROxSuTQBJipkWEMhfNgFVIoXL=cmwYqROxSuTQBJipkWEMhfNgFVIoXl[user_pf]
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
   return cmwYqROxSuTQBJipkWEMhfNgFVIoXy,cmwYqROxSuTQBJipkWEMhfNgFVIoXG,cmwYqROxSuTQBJipkWEMhfNgFVIoXt
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/profile/api/select.do'
   cmwYqROxSuTQBJipkWEMhfNgFVIoXK=cmwYqROxSuTQBJipkWEMhfNgFVIonX.URL_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIonr=cmwYqROxSuTQBJipkWEMhfNgFVIonX.makeDefaultCookies(vToken=cmwYqROxSuTQBJipkWEMhfNgFVIoan,vUserinfo=cmwYqROxSuTQBJipkWEMhfNgFVIoaj)
   cmwYqROxSuTQBJipkWEMhfNgFVIond={'profileNo':cmwYqROxSuTQBJipkWEMhfNgFVIoXL}
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Post',cmwYqROxSuTQBJipkWEMhfNgFVIoXK,payload=cmwYqROxSuTQBJipkWEMhfNgFVIond,params=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIonr)
   for cmwYqROxSuTQBJipkWEMhfNgFVIonH in cmwYqROxSuTQBJipkWEMhfNgFVIone.cookies:
    if cmwYqROxSuTQBJipkWEMhfNgFVIonH.name=='_tving_token':
     cmwYqROxSuTQBJipkWEMhfNgFVIoXy=cmwYqROxSuTQBJipkWEMhfNgFVIonH.value
    elif cmwYqROxSuTQBJipkWEMhfNgFVIonH.name==cmwYqROxSuTQBJipkWEMhfNgFVIonX.GLOBAL_COOKIENM['tv_cookiekey']:
     cmwYqROxSuTQBJipkWEMhfNgFVIoXG=cmwYqROxSuTQBJipkWEMhfNgFVIonH.value
    elif cmwYqROxSuTQBJipkWEMhfNgFVIonH.name==cmwYqROxSuTQBJipkWEMhfNgFVIonX.GLOBAL_COOKIENM['tv_lockkey']:
     cmwYqROxSuTQBJipkWEMhfNgFVIoXt=cmwYqROxSuTQBJipkWEMhfNgFVIonH.value
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  return cmwYqROxSuTQBJipkWEMhfNgFVIoXy,cmwYqROxSuTQBJipkWEMhfNgFVIoXG,cmwYqROxSuTQBJipkWEMhfNgFVIoXt
 def GetProfileLockYN(cmwYqROxSuTQBJipkWEMhfNgFVIonX,cmwYqROxSuTQBJipkWEMhfNgFVIoan,cmwYqROxSuTQBJipkWEMhfNgFVIoaj):
  cmwYqROxSuTQBJipkWEMhfNgFVIoXl=[]
  cmwYqROxSuTQBJipkWEMhfNgFVIoXt ='N'
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/profile/select.do'
   cmwYqROxSuTQBJipkWEMhfNgFVIoXK=cmwYqROxSuTQBJipkWEMhfNgFVIonX.URL_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIonr=cmwYqROxSuTQBJipkWEMhfNgFVIonX.makeDefaultCookies(vToken=cmwYqROxSuTQBJipkWEMhfNgFVIoan,vUserinfo=cmwYqROxSuTQBJipkWEMhfNgFVIoaj)
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoXK,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIonr)
   cmwYqROxSuTQBJipkWEMhfNgFVIoXl =re.findall('data-profile-no="\d+"',cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   for i in cmwYqROxSuTQBJipkWEMhfNgFVIoUb(cmwYqROxSuTQBJipkWEMhfNgFVIoUt(cmwYqROxSuTQBJipkWEMhfNgFVIoXl)):
    cmwYqROxSuTQBJipkWEMhfNgFVIoXd =cmwYqROxSuTQBJipkWEMhfNgFVIoXl[i].replace('data-profile-no=','').replace('"','')
    cmwYqROxSuTQBJipkWEMhfNgFVIoXl[i]=cmwYqROxSuTQBJipkWEMhfNgFVIoXd
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
   return cmwYqROxSuTQBJipkWEMhfNgFVIoXt
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/profile/api/select.do'
   cmwYqROxSuTQBJipkWEMhfNgFVIoXK=cmwYqROxSuTQBJipkWEMhfNgFVIonX.URL_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIonr=cmwYqROxSuTQBJipkWEMhfNgFVIonX.makeDefaultCookies(vToken=cmwYqROxSuTQBJipkWEMhfNgFVIoan,vUserinfo=cmwYqROxSuTQBJipkWEMhfNgFVIoaj)
   for i in cmwYqROxSuTQBJipkWEMhfNgFVIoUb(cmwYqROxSuTQBJipkWEMhfNgFVIoUt(cmwYqROxSuTQBJipkWEMhfNgFVIoXl)):
    cmwYqROxSuTQBJipkWEMhfNgFVIond={'profileNo':cmwYqROxSuTQBJipkWEMhfNgFVIoXl[i]}
    cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Post',cmwYqROxSuTQBJipkWEMhfNgFVIoXK,payload=cmwYqROxSuTQBJipkWEMhfNgFVIond,params=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIonr)
    for cmwYqROxSuTQBJipkWEMhfNgFVIonH in cmwYqROxSuTQBJipkWEMhfNgFVIone.cookies:
     if cmwYqROxSuTQBJipkWEMhfNgFVIonH.name=='_tving_token':
      cmwYqROxSuTQBJipkWEMhfNgFVIoXe=cmwYqROxSuTQBJipkWEMhfNgFVIonH.value
     elif cmwYqROxSuTQBJipkWEMhfNgFVIonH.name==cmwYqROxSuTQBJipkWEMhfNgFVIonX.GLOBAL_COOKIENM['tv_lockkey']:
      cmwYqROxSuTQBJipkWEMhfNgFVIoXH=cmwYqROxSuTQBJipkWEMhfNgFVIonH.value
    if cmwYqROxSuTQBJipkWEMhfNgFVIoXe==cmwYqROxSuTQBJipkWEMhfNgFVIoan:
     cmwYqROxSuTQBJipkWEMhfNgFVIoXt=cmwYqROxSuTQBJipkWEMhfNgFVIoXH
     cmwYqROxSuTQBJipkWEMhfNgFVIoUL(cmwYqROxSuTQBJipkWEMhfNgFVIoan)
     break
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  return cmwYqROxSuTQBJipkWEMhfNgFVIoXt
 def GetBookmarkInfo(cmwYqROxSuTQBJipkWEMhfNgFVIonX,videoid,vidtype):
  cmwYqROxSuTQBJipkWEMhfNgFVIoUn={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   cmwYqROxSuTQBJipkWEMhfNgFVIoab=cmwYqROxSuTQBJipkWEMhfNgFVIonX.API_DOMAIN+'/v2/media/program/'+videoid
   cmwYqROxSuTQBJipkWEMhfNgFVIoav=cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetDefaultParams()
   cmwYqROxSuTQBJipkWEMhfNgFVIoaD={'pageNo':'1','pageSize':'10','order':'name',}
   cmwYqROxSuTQBJipkWEMhfNgFVIoav.update(cmwYqROxSuTQBJipkWEMhfNgFVIoaD)
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoav,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIoUC)
   cmwYqROxSuTQBJipkWEMhfNgFVIoUa=json.loads(cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   if not('body' in cmwYqROxSuTQBJipkWEMhfNgFVIoUa):return{}
   cmwYqROxSuTQBJipkWEMhfNgFVIoUj=cmwYqROxSuTQBJipkWEMhfNgFVIoUa['body']
   cmwYqROxSuTQBJipkWEMhfNgFVIojl=cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('name').get('ko').strip()
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['title'] =cmwYqROxSuTQBJipkWEMhfNgFVIojl
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['title']=cmwYqROxSuTQBJipkWEMhfNgFVIojl
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['mpaa'] =cmwYqROxSuTQBJipkWEMhfNgFVIonP.get(cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('grade_code'))
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['plot'] =cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('synopsis').get('ko')
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['year'] =cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('product_year')
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['cast'] =cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('actor')
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['director']=cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('director')
   if cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('category1_name').get('ko')!='':
    cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['genre'].append(cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('category1_name').get('ko'))
   if cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('category2_name').get('ko')!='':
    cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['genre'].append(cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('category2_name').get('ko'))
   cmwYqROxSuTQBJipkWEMhfNgFVIoPC=cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('broad_dt'))
   if cmwYqROxSuTQBJipkWEMhfNgFVIoPC!='0':cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(cmwYqROxSuTQBJipkWEMhfNgFVIoPC[:4],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[4:6],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[6:])
   cmwYqROxSuTQBJipkWEMhfNgFVIojG =''
   cmwYqROxSuTQBJipkWEMhfNgFVIojy =''
   cmwYqROxSuTQBJipkWEMhfNgFVIojt=''
   cmwYqROxSuTQBJipkWEMhfNgFVIojd =''
   cmwYqROxSuTQBJipkWEMhfNgFVIoje =''
   for cmwYqROxSuTQBJipkWEMhfNgFVIoPn in cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('image'):
    if cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('code')=='CAIP0900':cmwYqROxSuTQBJipkWEMhfNgFVIojG =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('url')
    elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('code')=='CAIP0200':cmwYqROxSuTQBJipkWEMhfNgFVIojy =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('url')
    elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('code')=='CAIP1800':cmwYqROxSuTQBJipkWEMhfNgFVIojt=cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('url')
    elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('code')=='CAIP2000':cmwYqROxSuTQBJipkWEMhfNgFVIojd =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('url')
    elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('code')=='CAIP1900':cmwYqROxSuTQBJipkWEMhfNgFVIoje =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('url')
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['thumbnail']['poster']=cmwYqROxSuTQBJipkWEMhfNgFVIojG
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['thumbnail']['thumb']=cmwYqROxSuTQBJipkWEMhfNgFVIojy
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['thumbnail']['clearlogo']=cmwYqROxSuTQBJipkWEMhfNgFVIojt
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['thumbnail']['icon']=cmwYqROxSuTQBJipkWEMhfNgFVIojd
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['thumbnail']['banner']=cmwYqROxSuTQBJipkWEMhfNgFVIoje
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['thumbnail']['fanart']=cmwYqROxSuTQBJipkWEMhfNgFVIojy
  else:
   cmwYqROxSuTQBJipkWEMhfNgFVIoab=cmwYqROxSuTQBJipkWEMhfNgFVIonX.API_DOMAIN+'/v2a/media/stream/info'
   cmwYqROxSuTQBJipkWEMhfNgFVIoav=cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetDefaultParams()
   cmwYqROxSuTQBJipkWEMhfNgFVIoaD={'info':'Y','mediaCode':videoid,'noCache':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':'','uuid':'','deviceInfo':'PC','wm':'Y',}
   cmwYqROxSuTQBJipkWEMhfNgFVIoav.update(cmwYqROxSuTQBJipkWEMhfNgFVIoaD)
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoav,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIoUC)
   cmwYqROxSuTQBJipkWEMhfNgFVIoUa=json.loads(cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   if not('content' in cmwYqROxSuTQBJipkWEMhfNgFVIoUa['body']):return{}
   cmwYqROxSuTQBJipkWEMhfNgFVIoUj=cmwYqROxSuTQBJipkWEMhfNgFVIoUa['body']['content']['info']['movie']
   cmwYqROxSuTQBJipkWEMhfNgFVIojl =cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('name').get('ko').strip()
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['title']=cmwYqROxSuTQBJipkWEMhfNgFVIojl
   cmwYqROxSuTQBJipkWEMhfNgFVIojl +=u' (%s)'%(cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('product_year'))
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['title'] =cmwYqROxSuTQBJipkWEMhfNgFVIojl
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['mpaa'] =cmwYqROxSuTQBJipkWEMhfNgFVIonP.get(cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('grade_code'))
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['plot'] =cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('story').get('ko')
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['year'] =cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('product_year')
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['studio'] =cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('production')
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['duration']=cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('duration')
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['cast'] =cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('actor')
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['director']=cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('director')
   if cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('category1_name').get('ko')!='':
    cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['genre'].append(cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('category1_name').get('ko'))
   if cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('category2_name').get('ko')!='':
    cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['genre'].append(cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('category2_name').get('ko'))
   cmwYqROxSuTQBJipkWEMhfNgFVIoPC=cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('release_date'))
   if cmwYqROxSuTQBJipkWEMhfNgFVIoPC!='0':cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(cmwYqROxSuTQBJipkWEMhfNgFVIoPC[:4],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[4:6],cmwYqROxSuTQBJipkWEMhfNgFVIoPC[6:])
   cmwYqROxSuTQBJipkWEMhfNgFVIojG=''
   cmwYqROxSuTQBJipkWEMhfNgFVIojy =''
   cmwYqROxSuTQBJipkWEMhfNgFVIojt=''
   for cmwYqROxSuTQBJipkWEMhfNgFVIoPn in cmwYqROxSuTQBJipkWEMhfNgFVIoUj.get('image'):
    if cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('code')=='CAIM2100':cmwYqROxSuTQBJipkWEMhfNgFVIojG =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('url')
    elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('code')=='CAIM0400':cmwYqROxSuTQBJipkWEMhfNgFVIojy =cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('url')
    elif cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('code')=='CAIM1800':cmwYqROxSuTQBJipkWEMhfNgFVIojt=cmwYqROxSuTQBJipkWEMhfNgFVIonX.IMG_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoPn.get('url')
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['thumbnail']['poster']=cmwYqROxSuTQBJipkWEMhfNgFVIojG
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['thumbnail']['thumb']=cmwYqROxSuTQBJipkWEMhfNgFVIojG 
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['thumbnail']['clearlogo']=cmwYqROxSuTQBJipkWEMhfNgFVIojt
   cmwYqROxSuTQBJipkWEMhfNgFVIoUn['saveinfo']['thumbnail']['fanart']=cmwYqROxSuTQBJipkWEMhfNgFVIojy
  return cmwYqROxSuTQBJipkWEMhfNgFVIoUn
 def GetEuroChannelList(cmwYqROxSuTQBJipkWEMhfNgFVIonX):
  cmwYqROxSuTQBJipkWEMhfNgFVIojr=[]
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoaC ='/v2/operator/highlights'
   cmwYqROxSuTQBJipkWEMhfNgFVIoav=cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetDefaultParams()
   cmwYqROxSuTQBJipkWEMhfNgFVIoaD={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':cmwYqROxSuTQBJipkWEMhfNgFVIoUy(cmwYqROxSuTQBJipkWEMhfNgFVIonX.GetNoCache(2))}
   cmwYqROxSuTQBJipkWEMhfNgFVIoav.update(cmwYqROxSuTQBJipkWEMhfNgFVIoaD)
   cmwYqROxSuTQBJipkWEMhfNgFVIoab=cmwYqROxSuTQBJipkWEMhfNgFVIonX.API_DOMAIN+cmwYqROxSuTQBJipkWEMhfNgFVIoaC
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoav,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIoUC)
   cmwYqROxSuTQBJipkWEMhfNgFVIoaK=json.loads(cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   if not('result' in cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']):return cmwYqROxSuTQBJipkWEMhfNgFVIojr,cmwYqROxSuTQBJipkWEMhfNgFVIojz
   cmwYqROxSuTQBJipkWEMhfNgFVIojv=cmwYqROxSuTQBJipkWEMhfNgFVIoaK['body']['result']
   cmwYqROxSuTQBJipkWEMhfNgFVIoUP =cmwYqROxSuTQBJipkWEMhfNgFVIonX.Get_Now_Datetime()
   cmwYqROxSuTQBJipkWEMhfNgFVIoUX=cmwYqROxSuTQBJipkWEMhfNgFVIoUP+datetime.timedelta(days=-1)
   cmwYqROxSuTQBJipkWEMhfNgFVIoUX=cmwYqROxSuTQBJipkWEMhfNgFVIoUD(cmwYqROxSuTQBJipkWEMhfNgFVIoUX.strftime('%Y%m%d'))
   for cmwYqROxSuTQBJipkWEMhfNgFVIoaG in cmwYqROxSuTQBJipkWEMhfNgFVIojv:
    cmwYqROxSuTQBJipkWEMhfNgFVIoUs=cmwYqROxSuTQBJipkWEMhfNgFVIoUD(cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('content').get('banner_title2')[:8])
    if cmwYqROxSuTQBJipkWEMhfNgFVIoUX<=cmwYqROxSuTQBJipkWEMhfNgFVIoUs:
     cmwYqROxSuTQBJipkWEMhfNgFVIoPD={'channel':cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('content').get('banner_sub_title3'),'title':cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('content').get('banner_title'),'subtitle':cmwYqROxSuTQBJipkWEMhfNgFVIoaG.get('content').get('banner_sub_title2'),}
     cmwYqROxSuTQBJipkWEMhfNgFVIojr.append(cmwYqROxSuTQBJipkWEMhfNgFVIoPD)
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  return cmwYqROxSuTQBJipkWEMhfNgFVIojr
 def Get_Naver_Login(cmwYqROxSuTQBJipkWEMhfNgFVIonX):
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoab='https://user.tving.com/oauth/oauthLogin.tving?target=naver&from=pc&rtUrl=https://user.tving.com/pc/user/login.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fmain.do%3FretRef%3DY%26source%3Dhttps%3A%2F%2Fwww.google.com%2F&csite=&isAuto=false'
   cmwYqROxSuTQBJipkWEMhfNgFVIone=cmwYqROxSuTQBJipkWEMhfNgFVIonX.callRequestCookies('Get',cmwYqROxSuTQBJipkWEMhfNgFVIoab,payload=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,params=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,headers=cmwYqROxSuTQBJipkWEMhfNgFVIoUC,cookies=cmwYqROxSuTQBJipkWEMhfNgFVIoUC)
   if cmwYqROxSuTQBJipkWEMhfNgFVIone.status_code!=200:return cmwYqROxSuTQBJipkWEMhfNgFVIoUv
   cmwYqROxSuTQBJipkWEMhfNgFVIoUr=re.findall('\'https://nid.naver.com/(?:[a-zA-Z]|[0-9]|[$\-@\.&+:/?=_]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+\'',cmwYqROxSuTQBJipkWEMhfNgFVIone.text)
   cmwYqROxSuTQBJipkWEMhfNgFVIoUz=cmwYqROxSuTQBJipkWEMhfNgFVIoUr[0].replace('\'','')
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(cmwYqROxSuTQBJipkWEMhfNgFVIoUz)
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL('n login pass1 error')
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  try:
   cmwYqROxSuTQBJipkWEMhfNgFVIoab=cmwYqROxSuTQBJipkWEMhfNgFVIoUz
  except cmwYqROxSuTQBJipkWEMhfNgFVIoUl as exception:
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL('n login pass1 error')
   cmwYqROxSuTQBJipkWEMhfNgFVIoUL(exception)
  return cmwYqROxSuTQBJipkWEMhfNgFVIoUK
# Created by pyminifier (https://github.com/liftoff/pyminifier)
