__author__="NightRain"
CpmUxcEzXtjJaNgRAeukBIHWoFOrKL=object
CpmUxcEzXtjJaNgRAeukBIHWoFOrKn=None
CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ=int
CpmUxcEzXtjJaNgRAeukBIHWoFOrKq=True
CpmUxcEzXtjJaNgRAeukBIHWoFOrKD=False
CpmUxcEzXtjJaNgRAeukBIHWoFOrKY=type
CpmUxcEzXtjJaNgRAeukBIHWoFOrKV=dict
CpmUxcEzXtjJaNgRAeukBIHWoFOrKh=len
CpmUxcEzXtjJaNgRAeukBIHWoFOrKy=str
CpmUxcEzXtjJaNgRAeukBIHWoFOrKT=range
CpmUxcEzXtjJaNgRAeukBIHWoFOrKS=open
CpmUxcEzXtjJaNgRAeukBIHWoFOrKd=Exception
CpmUxcEzXtjJaNgRAeukBIHWoFOrKl=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
CpmUxcEzXtjJaNgRAeukBIHWoFOrbs=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
CpmUxcEzXtjJaNgRAeukBIHWoFOrbL=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
CpmUxcEzXtjJaNgRAeukBIHWoFOrbn=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
CpmUxcEzXtjJaNgRAeukBIHWoFOrbQ=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
CpmUxcEzXtjJaNgRAeukBIHWoFOrbq=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
CpmUxcEzXtjJaNgRAeukBIHWoFOrbK=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
CpmUxcEzXtjJaNgRAeukBIHWoFOrbD=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
CpmUxcEzXtjJaNgRAeukBIHWoFOrbY =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
CpmUxcEzXtjJaNgRAeukBIHWoFOrbV=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class CpmUxcEzXtjJaNgRAeukBIHWoFOrbi(CpmUxcEzXtjJaNgRAeukBIHWoFOrKL):
 def __init__(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrby,CpmUxcEzXtjJaNgRAeukBIHWoFOrbT,CpmUxcEzXtjJaNgRAeukBIHWoFOrbS):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_url =CpmUxcEzXtjJaNgRAeukBIHWoFOrby
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle=CpmUxcEzXtjJaNgRAeukBIHWoFOrbT
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params =CpmUxcEzXtjJaNgRAeukBIHWoFOrbS
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj =cmwYqROxSuTQBJipkWEMhfNgFVIona() 
 def addon_noti(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,sting):
  try:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbl=xbmcgui.Dialog()
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbl.notification(__addonname__,sting)
  except:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
 def addon_log(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,string):
  try:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbw=string.encode('utf-8','ignore')
  except:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbw='addonException: addon_log'
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbM=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,CpmUxcEzXtjJaNgRAeukBIHWoFOrbw),level=CpmUxcEzXtjJaNgRAeukBIHWoFOrbM)
 def get_keyboard_input(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrih):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbP=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
  kb=xbmc.Keyboard()
  kb.setHeading(CpmUxcEzXtjJaNgRAeukBIHWoFOrih)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbP=kb.getText()
  return CpmUxcEzXtjJaNgRAeukBIHWoFOrbP
 def get_settings_login_info(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbG =__addon__.getSetting('id')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbv =__addon__.getSetting('pw')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbf =__addon__.getSetting('login_type')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrib=CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(__addon__.getSetting('selected_profile'))
  return(CpmUxcEzXtjJaNgRAeukBIHWoFOrbG,CpmUxcEzXtjJaNgRAeukBIHWoFOrbv,CpmUxcEzXtjJaNgRAeukBIHWoFOrbf,CpmUxcEzXtjJaNgRAeukBIHWoFOrib)
 def get_settings_totalsearch(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOris =CpmUxcEzXtjJaNgRAeukBIHWoFOrKq if __addon__.getSetting('local_search')=='true' else CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
  CpmUxcEzXtjJaNgRAeukBIHWoFOriL=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq if __addon__.getSetting('local_history')=='true' else CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
  CpmUxcEzXtjJaNgRAeukBIHWoFOrin =CpmUxcEzXtjJaNgRAeukBIHWoFOrKq if __addon__.getSetting('total_search')=='true' else CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
  CpmUxcEzXtjJaNgRAeukBIHWoFOriQ=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq if __addon__.getSetting('total_history')=='true' else CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
  CpmUxcEzXtjJaNgRAeukBIHWoFOriq=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq if __addon__.getSetting('menu_bookmark')=='true' else CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
  return(CpmUxcEzXtjJaNgRAeukBIHWoFOris,CpmUxcEzXtjJaNgRAeukBIHWoFOriL,CpmUxcEzXtjJaNgRAeukBIHWoFOrin,CpmUxcEzXtjJaNgRAeukBIHWoFOriQ,CpmUxcEzXtjJaNgRAeukBIHWoFOriq)
 def get_settings_makebookmark(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh):
  return CpmUxcEzXtjJaNgRAeukBIHWoFOrKq if __addon__.getSetting('make_bookmark')=='true' else CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
 def get_settings_direct_replay(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOriK=CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(__addon__.getSetting('direct_replay'))
  if CpmUxcEzXtjJaNgRAeukBIHWoFOriK==0:
   return CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
  else:
   return CpmUxcEzXtjJaNgRAeukBIHWoFOrKq
 def set_winCredential(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,credential):
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD=xbmcgui.Window(10000)
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_LOGINTIME',CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD=xbmcgui.Window(10000)
  CpmUxcEzXtjJaNgRAeukBIHWoFOriY={'tving_token':CpmUxcEzXtjJaNgRAeukBIHWoFOriD.getProperty('TVING_M_TOKEN'),'poc_userinfo':CpmUxcEzXtjJaNgRAeukBIHWoFOriD.getProperty('TVING_M_USERINFO'),'tving_uuid':CpmUxcEzXtjJaNgRAeukBIHWoFOriD.getProperty('TVING_M_UUID'),'tving_maintoken':CpmUxcEzXtjJaNgRAeukBIHWoFOriD.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':CpmUxcEzXtjJaNgRAeukBIHWoFOriD.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':CpmUxcEzXtjJaNgRAeukBIHWoFOriD.getProperty('TVING_M_LOCKKEY')}
  return CpmUxcEzXtjJaNgRAeukBIHWoFOriY
 def set_winEpisodeOrderby(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrLq):
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD=xbmcgui.Window(10000)
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_ORDERBY',CpmUxcEzXtjJaNgRAeukBIHWoFOrLq)
 def get_winEpisodeOrderby(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD=xbmcgui.Window(10000)
  return CpmUxcEzXtjJaNgRAeukBIHWoFOriD.getProperty('TVING_M_ORDERBY')
 def add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,label,sublabel='',img='',infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq,params='',isLink=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD,ContextMenu=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn):
  CpmUxcEzXtjJaNgRAeukBIHWoFOriV='%s?%s'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_url,urllib.parse.urlencode(params))
  if sublabel:CpmUxcEzXtjJaNgRAeukBIHWoFOrih='%s < %s >'%(label,sublabel)
  else: CpmUxcEzXtjJaNgRAeukBIHWoFOrih=label
  if not img:img='DefaultFolder.png'
  CpmUxcEzXtjJaNgRAeukBIHWoFOriy=xbmcgui.ListItem(CpmUxcEzXtjJaNgRAeukBIHWoFOrih)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrKY(img)==CpmUxcEzXtjJaNgRAeukBIHWoFOrKV:
   CpmUxcEzXtjJaNgRAeukBIHWoFOriy.setArt(img)
  else:
   CpmUxcEzXtjJaNgRAeukBIHWoFOriy.setArt({'thumb':img,'poster':img})
  if infoLabels:CpmUxcEzXtjJaNgRAeukBIHWoFOriy.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   CpmUxcEzXtjJaNgRAeukBIHWoFOriy.setProperty('IsPlayable','true')
  if ContextMenu:CpmUxcEzXtjJaNgRAeukBIHWoFOriy.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,CpmUxcEzXtjJaNgRAeukBIHWoFOriV,CpmUxcEzXtjJaNgRAeukBIHWoFOriy,isFolder)
 def get_selQuality(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,etype):
  try:
   CpmUxcEzXtjJaNgRAeukBIHWoFOriT='selected_quality'
   CpmUxcEzXtjJaNgRAeukBIHWoFOriS=[1080,720,480,360]
   CpmUxcEzXtjJaNgRAeukBIHWoFOrid=CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(__addon__.getSetting(CpmUxcEzXtjJaNgRAeukBIHWoFOriT))
   return CpmUxcEzXtjJaNgRAeukBIHWoFOriS[CpmUxcEzXtjJaNgRAeukBIHWoFOrid]
  except:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
  return 720 
 def dp_Main_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh):
  (CpmUxcEzXtjJaNgRAeukBIHWoFOris,CpmUxcEzXtjJaNgRAeukBIHWoFOriL,CpmUxcEzXtjJaNgRAeukBIHWoFOrin,CpmUxcEzXtjJaNgRAeukBIHWoFOriQ,CpmUxcEzXtjJaNgRAeukBIHWoFOriq)=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_settings_totalsearch()
  for CpmUxcEzXtjJaNgRAeukBIHWoFOril in CpmUxcEzXtjJaNgRAeukBIHWoFOrbs:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih=CpmUxcEzXtjJaNgRAeukBIHWoFOril.get('title')
   CpmUxcEzXtjJaNgRAeukBIHWoFOriw=''
   if CpmUxcEzXtjJaNgRAeukBIHWoFOril.get('mode')=='SEARCH_GROUP' and CpmUxcEzXtjJaNgRAeukBIHWoFOris ==CpmUxcEzXtjJaNgRAeukBIHWoFOrKD:continue
   elif CpmUxcEzXtjJaNgRAeukBIHWoFOril.get('mode')=='SEARCH_HISTORY' and CpmUxcEzXtjJaNgRAeukBIHWoFOriL==CpmUxcEzXtjJaNgRAeukBIHWoFOrKD:continue
   elif CpmUxcEzXtjJaNgRAeukBIHWoFOril.get('mode')=='TOTAL_SEARCH' and CpmUxcEzXtjJaNgRAeukBIHWoFOrin ==CpmUxcEzXtjJaNgRAeukBIHWoFOrKD:continue
   elif CpmUxcEzXtjJaNgRAeukBIHWoFOril.get('mode')=='TOTAL_HISTORY' and CpmUxcEzXtjJaNgRAeukBIHWoFOriQ==CpmUxcEzXtjJaNgRAeukBIHWoFOrKD:continue
   elif CpmUxcEzXtjJaNgRAeukBIHWoFOril.get('mode')=='MENU_BOOKMARK' and CpmUxcEzXtjJaNgRAeukBIHWoFOriq==CpmUxcEzXtjJaNgRAeukBIHWoFOrKD:continue
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':CpmUxcEzXtjJaNgRAeukBIHWoFOril.get('mode'),'stype':CpmUxcEzXtjJaNgRAeukBIHWoFOril.get('stype'),'orderby':CpmUxcEzXtjJaNgRAeukBIHWoFOril.get('orderby'),'ordernm':CpmUxcEzXtjJaNgRAeukBIHWoFOril.get('ordernm'),'page':'1'}
   if CpmUxcEzXtjJaNgRAeukBIHWoFOril.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    CpmUxcEzXtjJaNgRAeukBIHWoFOriP=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
    CpmUxcEzXtjJaNgRAeukBIHWoFOriG =CpmUxcEzXtjJaNgRAeukBIHWoFOrKq
   else:
    CpmUxcEzXtjJaNgRAeukBIHWoFOriP=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq
    CpmUxcEzXtjJaNgRAeukBIHWoFOriG =CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
   if 'icon' in CpmUxcEzXtjJaNgRAeukBIHWoFOril:CpmUxcEzXtjJaNgRAeukBIHWoFOriw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',CpmUxcEzXtjJaNgRAeukBIHWoFOril.get('icon')) 
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel='',img=CpmUxcEzXtjJaNgRAeukBIHWoFOriw,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOriP,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM,isLink=CpmUxcEzXtjJaNgRAeukBIHWoFOriG)
  xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle)
 def login_main(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh):
  (CpmUxcEzXtjJaNgRAeukBIHWoFOrif,CpmUxcEzXtjJaNgRAeukBIHWoFOrsb,CpmUxcEzXtjJaNgRAeukBIHWoFOrsi,CpmUxcEzXtjJaNgRAeukBIHWoFOrsL)=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_settings_login_info()
  if not(CpmUxcEzXtjJaNgRAeukBIHWoFOrif and CpmUxcEzXtjJaNgRAeukBIHWoFOrsb):
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbl=xbmcgui.Dialog()
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsn=CpmUxcEzXtjJaNgRAeukBIHWoFOrbl.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrsn==CpmUxcEzXtjJaNgRAeukBIHWoFOrKq:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_winEpisodeOrderby()=='':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.set_winEpisodeOrderby('desc')
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.cookiefile_check():return
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsQ =CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsq=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsq==CpmUxcEzXtjJaNgRAeukBIHWoFOrKn or CpmUxcEzXtjJaNgRAeukBIHWoFOrsq=='':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsq=CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ('19000101')
  else:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsq=CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(re.sub('-','',CpmUxcEzXtjJaNgRAeukBIHWoFOrsq))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsK=0
   while CpmUxcEzXtjJaNgRAeukBIHWoFOrKq:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrsK+=1
    time.sleep(0.05)
    if CpmUxcEzXtjJaNgRAeukBIHWoFOrsq>=CpmUxcEzXtjJaNgRAeukBIHWoFOrsQ:return
    if CpmUxcEzXtjJaNgRAeukBIHWoFOrsK>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsq>=CpmUxcEzXtjJaNgRAeukBIHWoFOrsQ:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.GetCredential(CpmUxcEzXtjJaNgRAeukBIHWoFOrif,CpmUxcEzXtjJaNgRAeukBIHWoFOrsb,CpmUxcEzXtjJaNgRAeukBIHWoFOrsi,CpmUxcEzXtjJaNgRAeukBIHWoFOrsL):
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.set_winCredential(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.LoadCredential())
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('stype')
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='live':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsY=CpmUxcEzXtjJaNgRAeukBIHWoFOrbL
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='vod':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsY=CpmUxcEzXtjJaNgRAeukBIHWoFOrbq
  else:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsY=CpmUxcEzXtjJaNgRAeukBIHWoFOrbK
  for CpmUxcEzXtjJaNgRAeukBIHWoFOrsV in CpmUxcEzXtjJaNgRAeukBIHWoFOrsY:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih=CpmUxcEzXtjJaNgRAeukBIHWoFOrsV.get('title')
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('ordernm')!='-':
    CpmUxcEzXtjJaNgRAeukBIHWoFOrih+='  ('+CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('ordernm')+')'
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':CpmUxcEzXtjJaNgRAeukBIHWoFOrsV.get('mode'),'stype':CpmUxcEzXtjJaNgRAeukBIHWoFOrsV.get('stype'),'orderby':CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('orderby'),'ordernm':CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('ordernm'),'page':'1'}
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel='',img='',infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrKh(CpmUxcEzXtjJaNgRAeukBIHWoFOrsY)>0:xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle)
 def dp_SubTitle_Group(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh): 
  for CpmUxcEzXtjJaNgRAeukBIHWoFOrsV in CpmUxcEzXtjJaNgRAeukBIHWoFOrbD:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih=CpmUxcEzXtjJaNgRAeukBIHWoFOrsV.get('title')
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('ordernm')!='-':
    CpmUxcEzXtjJaNgRAeukBIHWoFOrih+='  ('+CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('ordernm')+')'
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':CpmUxcEzXtjJaNgRAeukBIHWoFOrsV.get('mode'),'genreCode':CpmUxcEzXtjJaNgRAeukBIHWoFOrsV.get('genreCode'),'stype':CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('stype'),'orderby':CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('orderby'),'page':'1'}
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel='',img='',infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrKh(CpmUxcEzXtjJaNgRAeukBIHWoFOrbD)>0:xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle)
 def dp_LiveChannel_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.SaveCredential(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_winCredential())
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsD =CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('stype')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsy =CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('page'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsT,CpmUxcEzXtjJaNgRAeukBIHWoFOrsS=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.GetLiveChannelList(CpmUxcEzXtjJaNgRAeukBIHWoFOrsD,CpmUxcEzXtjJaNgRAeukBIHWoFOrsy)
  for CpmUxcEzXtjJaNgRAeukBIHWoFOrsd in CpmUxcEzXtjJaNgRAeukBIHWoFOrsT:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('title')
   CpmUxcEzXtjJaNgRAeukBIHWoFOriv =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('channel')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsl =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('thumbnail')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsw =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('synopsis')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsM =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('channelepg')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsP =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('cast')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsG =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('director')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsv =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('info_genre')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsf =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('year')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLb =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('mpaa')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLi =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('premiered')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLs={'mediatype':'episode','title':CpmUxcEzXtjJaNgRAeukBIHWoFOrih,'studio':CpmUxcEzXtjJaNgRAeukBIHWoFOriv,'cast':CpmUxcEzXtjJaNgRAeukBIHWoFOrsP,'director':CpmUxcEzXtjJaNgRAeukBIHWoFOrsG,'genre':CpmUxcEzXtjJaNgRAeukBIHWoFOrsv,'plot':'%s\n%s\n%s\n\n%s'%(CpmUxcEzXtjJaNgRAeukBIHWoFOriv,CpmUxcEzXtjJaNgRAeukBIHWoFOrih,CpmUxcEzXtjJaNgRAeukBIHWoFOrsM,CpmUxcEzXtjJaNgRAeukBIHWoFOrsw),'year':CpmUxcEzXtjJaNgRAeukBIHWoFOrsf,'mpaa':CpmUxcEzXtjJaNgRAeukBIHWoFOrLb,'premiered':CpmUxcEzXtjJaNgRAeukBIHWoFOrLi}
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':'LIVE','mediacode':CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('mediacode'),'stype':CpmUxcEzXtjJaNgRAeukBIHWoFOrsD}
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOriv,sublabel=CpmUxcEzXtjJaNgRAeukBIHWoFOrih,img=CpmUxcEzXtjJaNgRAeukBIHWoFOrsl,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrLs,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsS:
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['mode']='CHANNEL' 
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['stype']=CpmUxcEzXtjJaNgRAeukBIHWoFOrsD 
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['page']=CpmUxcEzXtjJaNgRAeukBIHWoFOrKy(CpmUxcEzXtjJaNgRAeukBIHWoFOrsy+1)
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih='[B]%s >>[/B]'%'다음 페이지'
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLn=CpmUxcEzXtjJaNgRAeukBIHWoFOrKy(CpmUxcEzXtjJaNgRAeukBIHWoFOrsy+1)
   CpmUxcEzXtjJaNgRAeukBIHWoFOriw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel=CpmUxcEzXtjJaNgRAeukBIHWoFOrLn,img=CpmUxcEzXtjJaNgRAeukBIHWoFOriw,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrKh(CpmUxcEzXtjJaNgRAeukBIHWoFOrsT)>0:xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,cacheToDisc=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD)
 def dp_Program_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.SaveCredential(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_winCredential())
  CpmUxcEzXtjJaNgRAeukBIHWoFOrLQ =CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('stype')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrLq =CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('orderby')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsy =CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('page'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOrLK=CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('genreCode')
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrLK==CpmUxcEzXtjJaNgRAeukBIHWoFOrKn:CpmUxcEzXtjJaNgRAeukBIHWoFOrLK='all'
  CpmUxcEzXtjJaNgRAeukBIHWoFOrLD,CpmUxcEzXtjJaNgRAeukBIHWoFOrsS=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.GetProgramList(CpmUxcEzXtjJaNgRAeukBIHWoFOrLQ,CpmUxcEzXtjJaNgRAeukBIHWoFOrLq,CpmUxcEzXtjJaNgRAeukBIHWoFOrsy,CpmUxcEzXtjJaNgRAeukBIHWoFOrLK)
  for CpmUxcEzXtjJaNgRAeukBIHWoFOrLY in CpmUxcEzXtjJaNgRAeukBIHWoFOrLD:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih =CpmUxcEzXtjJaNgRAeukBIHWoFOrLY.get('title')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsl =CpmUxcEzXtjJaNgRAeukBIHWoFOrLY.get('thumbnail')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsw =CpmUxcEzXtjJaNgRAeukBIHWoFOrLY.get('synopsis')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLV =CpmUxcEzXtjJaNgRAeukBIHWoFOrLY.get('channel')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsP =CpmUxcEzXtjJaNgRAeukBIHWoFOrLY.get('cast')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsG =CpmUxcEzXtjJaNgRAeukBIHWoFOrLY.get('director')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsv=CpmUxcEzXtjJaNgRAeukBIHWoFOrLY.get('info_genre')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsf =CpmUxcEzXtjJaNgRAeukBIHWoFOrLY.get('year')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLi =CpmUxcEzXtjJaNgRAeukBIHWoFOrLY.get('premiered')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLb =CpmUxcEzXtjJaNgRAeukBIHWoFOrLY.get('mpaa')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLs={'mediatype':'tvshow','title':CpmUxcEzXtjJaNgRAeukBIHWoFOrih,'studio':CpmUxcEzXtjJaNgRAeukBIHWoFOrLV,'cast':CpmUxcEzXtjJaNgRAeukBIHWoFOrsP,'director':CpmUxcEzXtjJaNgRAeukBIHWoFOrsG,'genre':CpmUxcEzXtjJaNgRAeukBIHWoFOrsv,'year':CpmUxcEzXtjJaNgRAeukBIHWoFOrsf,'premiered':CpmUxcEzXtjJaNgRAeukBIHWoFOrLi,'mpaa':CpmUxcEzXtjJaNgRAeukBIHWoFOrLb,'plot':CpmUxcEzXtjJaNgRAeukBIHWoFOrsw}
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':'EPISODE','programcode':CpmUxcEzXtjJaNgRAeukBIHWoFOrLY.get('program'),'page':'1'}
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_settings_makebookmark():
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLh={'videoid':CpmUxcEzXtjJaNgRAeukBIHWoFOrLY.get('program'),'vidtype':'tvshow','vtitle':CpmUxcEzXtjJaNgRAeukBIHWoFOrih,'vsubtitle':CpmUxcEzXtjJaNgRAeukBIHWoFOrLV,}
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLy=json.dumps(CpmUxcEzXtjJaNgRAeukBIHWoFOrLh)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLy=urllib.parse.quote(CpmUxcEzXtjJaNgRAeukBIHWoFOrLy)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLT='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrLy)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLS=[('(통합) 찜 영상에 추가',CpmUxcEzXtjJaNgRAeukBIHWoFOrLT)]
   else:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLS=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel=CpmUxcEzXtjJaNgRAeukBIHWoFOrLV,img=CpmUxcEzXtjJaNgRAeukBIHWoFOrsl,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrLs,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM,ContextMenu=CpmUxcEzXtjJaNgRAeukBIHWoFOrLS)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsS:
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['mode'] ='PROGRAM' 
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['stype'] =CpmUxcEzXtjJaNgRAeukBIHWoFOrLQ
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['orderby'] =CpmUxcEzXtjJaNgRAeukBIHWoFOrLq
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['page'] =CpmUxcEzXtjJaNgRAeukBIHWoFOrKy(CpmUxcEzXtjJaNgRAeukBIHWoFOrsy+1)
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['genreCode']=CpmUxcEzXtjJaNgRAeukBIHWoFOrLK 
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih='[B]%s >>[/B]'%'다음 페이지'
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLn=CpmUxcEzXtjJaNgRAeukBIHWoFOrKy(CpmUxcEzXtjJaNgRAeukBIHWoFOrsy+1)
   CpmUxcEzXtjJaNgRAeukBIHWoFOriw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel=CpmUxcEzXtjJaNgRAeukBIHWoFOrLn,img=CpmUxcEzXtjJaNgRAeukBIHWoFOriw,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
  xbmcplugin.setContent(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,cacheToDisc=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD)
 def dp_Episode_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.SaveCredential(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_winCredential())
  CpmUxcEzXtjJaNgRAeukBIHWoFOrLl=CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('programcode')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsy =CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('page'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOrLw,CpmUxcEzXtjJaNgRAeukBIHWoFOrsS,CpmUxcEzXtjJaNgRAeukBIHWoFOrLM=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.GetEpisodeList(CpmUxcEzXtjJaNgRAeukBIHWoFOrLl,CpmUxcEzXtjJaNgRAeukBIHWoFOrsy,orderby=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_winEpisodeOrderby())
  for CpmUxcEzXtjJaNgRAeukBIHWoFOrLP in CpmUxcEzXtjJaNgRAeukBIHWoFOrLw:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih =CpmUxcEzXtjJaNgRAeukBIHWoFOrLP.get('title')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLn =CpmUxcEzXtjJaNgRAeukBIHWoFOrLP.get('subtitle')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsl =CpmUxcEzXtjJaNgRAeukBIHWoFOrLP.get('thumbnail')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsw =CpmUxcEzXtjJaNgRAeukBIHWoFOrLP.get('synopsis')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLG=CpmUxcEzXtjJaNgRAeukBIHWoFOrLP.get('info_title')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLv =CpmUxcEzXtjJaNgRAeukBIHWoFOrLP.get('aired')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLf =CpmUxcEzXtjJaNgRAeukBIHWoFOrLP.get('studio')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrnb =CpmUxcEzXtjJaNgRAeukBIHWoFOrLP.get('frequency')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLs={'mediatype':'episode','title':CpmUxcEzXtjJaNgRAeukBIHWoFOrLG,'aired':CpmUxcEzXtjJaNgRAeukBIHWoFOrLv,'studio':CpmUxcEzXtjJaNgRAeukBIHWoFOrLf,'episode':CpmUxcEzXtjJaNgRAeukBIHWoFOrnb,'plot':CpmUxcEzXtjJaNgRAeukBIHWoFOrsw}
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':'VOD','mediacode':CpmUxcEzXtjJaNgRAeukBIHWoFOrLP.get('episode'),'stype':'vod','programcode':CpmUxcEzXtjJaNgRAeukBIHWoFOrLl,'title':CpmUxcEzXtjJaNgRAeukBIHWoFOrih,'thumbnail':CpmUxcEzXtjJaNgRAeukBIHWoFOrsl}
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel=CpmUxcEzXtjJaNgRAeukBIHWoFOrLn,img=CpmUxcEzXtjJaNgRAeukBIHWoFOrsl,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrLs,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsy==1:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLs={'plot':'정렬순서를 변경합니다.'}
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM={}
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['mode'] ='ORDER_BY' 
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_winEpisodeOrderby()=='desc':
    CpmUxcEzXtjJaNgRAeukBIHWoFOrih='정렬순서변경 : 최신화부터 -> 1회부터'
    CpmUxcEzXtjJaNgRAeukBIHWoFOriM['orderby']='asc'
   else:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrih='정렬순서변경 : 1회부터 -> 최신화부터'
    CpmUxcEzXtjJaNgRAeukBIHWoFOriM['orderby']='desc'
   CpmUxcEzXtjJaNgRAeukBIHWoFOriw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel='',img=CpmUxcEzXtjJaNgRAeukBIHWoFOriw,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrLs,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM,isLink=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsS:
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['mode'] ='EPISODE' 
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['programcode']=CpmUxcEzXtjJaNgRAeukBIHWoFOrLl
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['page'] =CpmUxcEzXtjJaNgRAeukBIHWoFOrKy(CpmUxcEzXtjJaNgRAeukBIHWoFOrsy+1)
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih='[B]%s >>[/B]'%'다음 페이지'
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLn=CpmUxcEzXtjJaNgRAeukBIHWoFOrKy(CpmUxcEzXtjJaNgRAeukBIHWoFOrsy+1)
   CpmUxcEzXtjJaNgRAeukBIHWoFOriw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel=CpmUxcEzXtjJaNgRAeukBIHWoFOrLn,img=CpmUxcEzXtjJaNgRAeukBIHWoFOriw,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
  xbmcplugin.setContent(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,'episodes')
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrKh(CpmUxcEzXtjJaNgRAeukBIHWoFOrLw)>0:xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,cacheToDisc=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq)
 def dp_setEpOrderby(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrLq =CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('orderby')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.set_winEpisodeOrderby(CpmUxcEzXtjJaNgRAeukBIHWoFOrLq)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.SaveCredential(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_winCredential())
  CpmUxcEzXtjJaNgRAeukBIHWoFOrLQ =CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('stype')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrLq =CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('orderby')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsy=CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('page'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOrni,CpmUxcEzXtjJaNgRAeukBIHWoFOrsS=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.GetMovieList(CpmUxcEzXtjJaNgRAeukBIHWoFOrLQ,CpmUxcEzXtjJaNgRAeukBIHWoFOrLq,CpmUxcEzXtjJaNgRAeukBIHWoFOrsy)
  for CpmUxcEzXtjJaNgRAeukBIHWoFOrns in CpmUxcEzXtjJaNgRAeukBIHWoFOrni:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih =CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('title')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsl =CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('thumbnail')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsw =CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('synopsis')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLG =CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('info_title')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsf =CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('year')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsP =CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('cast')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsG =CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('director')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsv =CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('info_genre')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrnL =CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('duration')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLi =CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('premiered')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLf =CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('studio')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLb =CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('mpaa')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLs={'mediatype':'movie','title':CpmUxcEzXtjJaNgRAeukBIHWoFOrLG,'year':CpmUxcEzXtjJaNgRAeukBIHWoFOrsf,'cast':CpmUxcEzXtjJaNgRAeukBIHWoFOrsP,'director':CpmUxcEzXtjJaNgRAeukBIHWoFOrsG,'genre':CpmUxcEzXtjJaNgRAeukBIHWoFOrsv,'duration':CpmUxcEzXtjJaNgRAeukBIHWoFOrnL,'premiered':CpmUxcEzXtjJaNgRAeukBIHWoFOrLi,'studio':CpmUxcEzXtjJaNgRAeukBIHWoFOrLf,'mpaa':CpmUxcEzXtjJaNgRAeukBIHWoFOrLb,'plot':CpmUxcEzXtjJaNgRAeukBIHWoFOrsw}
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':'MOVIE','mediacode':CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('moviecode'),'stype':'movie','title':CpmUxcEzXtjJaNgRAeukBIHWoFOrih,'thumbnail':CpmUxcEzXtjJaNgRAeukBIHWoFOrsl}
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_settings_makebookmark():
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLh={'videoid':CpmUxcEzXtjJaNgRAeukBIHWoFOrns.get('moviecode'),'vidtype':'movie','vtitle':CpmUxcEzXtjJaNgRAeukBIHWoFOrLG,'vsubtitle':'',}
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLy=json.dumps(CpmUxcEzXtjJaNgRAeukBIHWoFOrLh)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLy=urllib.parse.quote(CpmUxcEzXtjJaNgRAeukBIHWoFOrLy)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLT='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrLy)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLS=[('(통합) 찜 영상에 추가',CpmUxcEzXtjJaNgRAeukBIHWoFOrLT)]
   else:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLS=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel='',img=CpmUxcEzXtjJaNgRAeukBIHWoFOrsl,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrLs,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM,ContextMenu=CpmUxcEzXtjJaNgRAeukBIHWoFOrLS)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsS:
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM={}
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['mode'] ='MOVIE_SUB' 
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['orderby']=CpmUxcEzXtjJaNgRAeukBIHWoFOrLq
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['stype'] =CpmUxcEzXtjJaNgRAeukBIHWoFOrLQ
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['page'] =CpmUxcEzXtjJaNgRAeukBIHWoFOrKy(CpmUxcEzXtjJaNgRAeukBIHWoFOrsy+1)
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih='[B]%s >>[/B]'%'다음 페이지'
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLn=CpmUxcEzXtjJaNgRAeukBIHWoFOrKy(CpmUxcEzXtjJaNgRAeukBIHWoFOrsy+1)
   CpmUxcEzXtjJaNgRAeukBIHWoFOriw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel=CpmUxcEzXtjJaNgRAeukBIHWoFOrLn,img=CpmUxcEzXtjJaNgRAeukBIHWoFOriw,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
  xbmcplugin.setContent(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,'movies')
  xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,cacheToDisc=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD)
 def dp_Set_Bookmark(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnQ=urllib.parse.unquote(CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('bm_param'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnQ=json.loads(CpmUxcEzXtjJaNgRAeukBIHWoFOrnQ)
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnq =CpmUxcEzXtjJaNgRAeukBIHWoFOrnQ.get('videoid')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnK =CpmUxcEzXtjJaNgRAeukBIHWoFOrnQ.get('vidtype')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnD =CpmUxcEzXtjJaNgRAeukBIHWoFOrnQ.get('vtitle')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnY =CpmUxcEzXtjJaNgRAeukBIHWoFOrnQ.get('vsubtitle')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbl=xbmcgui.Dialog()
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsn=CpmUxcEzXtjJaNgRAeukBIHWoFOrbl.yesno(__language__(30913).encode('utf8'),CpmUxcEzXtjJaNgRAeukBIHWoFOrnD+' \n\n'+__language__(30914))
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsn==CpmUxcEzXtjJaNgRAeukBIHWoFOrKD:return
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnV=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.GetBookmarkInfo(CpmUxcEzXtjJaNgRAeukBIHWoFOrnq,CpmUxcEzXtjJaNgRAeukBIHWoFOrnK)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrnY!='':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrnV['saveinfo']['subtitle']=CpmUxcEzXtjJaNgRAeukBIHWoFOrnY 
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrnK=='tvshow':CpmUxcEzXtjJaNgRAeukBIHWoFOrnV['saveinfo']['infoLabels']['studio']=CpmUxcEzXtjJaNgRAeukBIHWoFOrnY 
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnh=json.dumps(CpmUxcEzXtjJaNgRAeukBIHWoFOrnV)
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnh=urllib.parse.quote(CpmUxcEzXtjJaNgRAeukBIHWoFOrnh)
  CpmUxcEzXtjJaNgRAeukBIHWoFOrLT ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrnh)
  xbmc.executebuiltin(CpmUxcEzXtjJaNgRAeukBIHWoFOrLT)
 def dp_Search_Group(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  if 'search_key' in CpmUxcEzXtjJaNgRAeukBIHWoFOrsh:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrny=CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('search_key')
  else:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrny=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not CpmUxcEzXtjJaNgRAeukBIHWoFOrny:
    return
  for CpmUxcEzXtjJaNgRAeukBIHWoFOrsV in CpmUxcEzXtjJaNgRAeukBIHWoFOrbQ:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrnT =CpmUxcEzXtjJaNgRAeukBIHWoFOrsV.get('mode')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=CpmUxcEzXtjJaNgRAeukBIHWoFOrsV.get('stype')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih=CpmUxcEzXtjJaNgRAeukBIHWoFOrsV.get('title')
   (CpmUxcEzXtjJaNgRAeukBIHWoFOrnS,CpmUxcEzXtjJaNgRAeukBIHWoFOrsS)=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.GetSearchList(CpmUxcEzXtjJaNgRAeukBIHWoFOrny,1,CpmUxcEzXtjJaNgRAeukBIHWoFOrsD)
   CpmUxcEzXtjJaNgRAeukBIHWoFOrnd={'plot':'검색어 : '+CpmUxcEzXtjJaNgRAeukBIHWoFOrny+'\n\n'+CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.Search_FreeList(CpmUxcEzXtjJaNgRAeukBIHWoFOrnS)}
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':CpmUxcEzXtjJaNgRAeukBIHWoFOrnT,'stype':CpmUxcEzXtjJaNgRAeukBIHWoFOrsD,'search_key':CpmUxcEzXtjJaNgRAeukBIHWoFOrny,'page':'1',}
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel='',img='',infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrnd,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrKh(CpmUxcEzXtjJaNgRAeukBIHWoFOrbQ)>0:xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,cacheToDisc=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq)
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.Save_Searched_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrny)
 def Search_FreeList(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrQi):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnl=''
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnw=7
  try:
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrKh(CpmUxcEzXtjJaNgRAeukBIHWoFOrQi)==0:return '검색결과 없음'
   for i in CpmUxcEzXtjJaNgRAeukBIHWoFOrKT(CpmUxcEzXtjJaNgRAeukBIHWoFOrKh(CpmUxcEzXtjJaNgRAeukBIHWoFOrQi)):
    if i>=CpmUxcEzXtjJaNgRAeukBIHWoFOrnw:
     CpmUxcEzXtjJaNgRAeukBIHWoFOrnl=CpmUxcEzXtjJaNgRAeukBIHWoFOrnl+'...'
     break
    CpmUxcEzXtjJaNgRAeukBIHWoFOrnl=CpmUxcEzXtjJaNgRAeukBIHWoFOrnl+CpmUxcEzXtjJaNgRAeukBIHWoFOrQi[i]['title']+'\n'
  except:
   return ''
  return CpmUxcEzXtjJaNgRAeukBIHWoFOrnl
 def dp_Search_History(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnM=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.Load_List_File('search')
  for CpmUxcEzXtjJaNgRAeukBIHWoFOrnP in CpmUxcEzXtjJaNgRAeukBIHWoFOrnM:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrnG=CpmUxcEzXtjJaNgRAeukBIHWoFOrKV(urllib.parse.parse_qsl(CpmUxcEzXtjJaNgRAeukBIHWoFOrnP))
   CpmUxcEzXtjJaNgRAeukBIHWoFOrnv=CpmUxcEzXtjJaNgRAeukBIHWoFOrnG.get('skey').strip()
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':'SEARCH_GROUP','search_key':CpmUxcEzXtjJaNgRAeukBIHWoFOrnv,}
   CpmUxcEzXtjJaNgRAeukBIHWoFOrnf={'mode':'SEARCH_REMOVE','stype':'ONE','skey':CpmUxcEzXtjJaNgRAeukBIHWoFOrnv,}
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQb=urllib.parse.urlencode(CpmUxcEzXtjJaNgRAeukBIHWoFOrnf)
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLS=[('선택된 검색어 ( %s ) 삭제'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrnv),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrQb))]
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrnv,sublabel='',img=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM,ContextMenu=CpmUxcEzXtjJaNgRAeukBIHWoFOrLS)
  CpmUxcEzXtjJaNgRAeukBIHWoFOrLs={'plot':'검색목록 전체를 삭제합니다.'}
  CpmUxcEzXtjJaNgRAeukBIHWoFOrih='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  CpmUxcEzXtjJaNgRAeukBIHWoFOriw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel='',img=CpmUxcEzXtjJaNgRAeukBIHWoFOriw,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrLs,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM,isLink=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq)
  xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,cacheToDisc=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD)
 def dp_Search_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.SaveCredential(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_winCredential())
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsy =CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('page'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsD =CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('stype')
  if 'search_key' in CpmUxcEzXtjJaNgRAeukBIHWoFOrsh:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrny=CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('search_key')
  else:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrny=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not CpmUxcEzXtjJaNgRAeukBIHWoFOrny:
    xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle)
    return
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnS,CpmUxcEzXtjJaNgRAeukBIHWoFOrsS=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.GetSearchList(CpmUxcEzXtjJaNgRAeukBIHWoFOrny,CpmUxcEzXtjJaNgRAeukBIHWoFOrsy,CpmUxcEzXtjJaNgRAeukBIHWoFOrsD)
  for CpmUxcEzXtjJaNgRAeukBIHWoFOrQi in CpmUxcEzXtjJaNgRAeukBIHWoFOrnS:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih =CpmUxcEzXtjJaNgRAeukBIHWoFOrQi.get('title')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsl =CpmUxcEzXtjJaNgRAeukBIHWoFOrQi.get('thumbnail')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsw =CpmUxcEzXtjJaNgRAeukBIHWoFOrQi.get('synopsis')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQs =CpmUxcEzXtjJaNgRAeukBIHWoFOrQi.get('program')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsP =CpmUxcEzXtjJaNgRAeukBIHWoFOrQi.get('cast')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsG =CpmUxcEzXtjJaNgRAeukBIHWoFOrQi.get('director')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsv=CpmUxcEzXtjJaNgRAeukBIHWoFOrQi.get('info_genre')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrnL =CpmUxcEzXtjJaNgRAeukBIHWoFOrQi.get('duration')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLb =CpmUxcEzXtjJaNgRAeukBIHWoFOrQi.get('mpaa')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsf =CpmUxcEzXtjJaNgRAeukBIHWoFOrQi.get('year')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLv =CpmUxcEzXtjJaNgRAeukBIHWoFOrQi.get('aired')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLs={'mediatype':'tvshow' if CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='vod' else 'movie','title':CpmUxcEzXtjJaNgRAeukBIHWoFOrih,'cast':CpmUxcEzXtjJaNgRAeukBIHWoFOrsP,'director':CpmUxcEzXtjJaNgRAeukBIHWoFOrsG,'genre':CpmUxcEzXtjJaNgRAeukBIHWoFOrsv,'duration':CpmUxcEzXtjJaNgRAeukBIHWoFOrnL,'mpaa':CpmUxcEzXtjJaNgRAeukBIHWoFOrLb,'year':CpmUxcEzXtjJaNgRAeukBIHWoFOrsf,'aired':CpmUxcEzXtjJaNgRAeukBIHWoFOrLv,'plot':'%s\n\n%s'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,CpmUxcEzXtjJaNgRAeukBIHWoFOrsw)}
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='vod':
    CpmUxcEzXtjJaNgRAeukBIHWoFOrnq=CpmUxcEzXtjJaNgRAeukBIHWoFOrQi.get('program')
    CpmUxcEzXtjJaNgRAeukBIHWoFOrnK='tvshow'
    CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':'EPISODE','programcode':CpmUxcEzXtjJaNgRAeukBIHWoFOrnq,'page':'1',}
    CpmUxcEzXtjJaNgRAeukBIHWoFOriP=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq
   else:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrnq=CpmUxcEzXtjJaNgRAeukBIHWoFOrQi.get('movie')
    CpmUxcEzXtjJaNgRAeukBIHWoFOrnK='movie'
    CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':'MOVIE','mediacode':CpmUxcEzXtjJaNgRAeukBIHWoFOrnq,'stype':'movie','title':CpmUxcEzXtjJaNgRAeukBIHWoFOrih,'thumbnail':CpmUxcEzXtjJaNgRAeukBIHWoFOrsl,}
    CpmUxcEzXtjJaNgRAeukBIHWoFOriP=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_settings_makebookmark():
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLh={'videoid':CpmUxcEzXtjJaNgRAeukBIHWoFOrnq,'vidtype':CpmUxcEzXtjJaNgRAeukBIHWoFOrnK,'vtitle':CpmUxcEzXtjJaNgRAeukBIHWoFOrih,'vsubtitle':'',}
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLy=json.dumps(CpmUxcEzXtjJaNgRAeukBIHWoFOrLh)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLy=urllib.parse.quote(CpmUxcEzXtjJaNgRAeukBIHWoFOrLy)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLT='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrLy)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLS=[('(통합) 찜 영상에 추가',CpmUxcEzXtjJaNgRAeukBIHWoFOrLT)]
   else:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLS=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel='',img=CpmUxcEzXtjJaNgRAeukBIHWoFOrsl,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrLs,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOriP,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM,isLink=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD,ContextMenu=CpmUxcEzXtjJaNgRAeukBIHWoFOrLS)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsS:
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['mode'] ='SEARCH' 
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['search_key']=CpmUxcEzXtjJaNgRAeukBIHWoFOrny
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM['page'] =CpmUxcEzXtjJaNgRAeukBIHWoFOrKy(CpmUxcEzXtjJaNgRAeukBIHWoFOrsy+1)
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih='[B]%s >>[/B]'%'다음 페이지'
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLn=CpmUxcEzXtjJaNgRAeukBIHWoFOrKy(CpmUxcEzXtjJaNgRAeukBIHWoFOrsy+1)
   CpmUxcEzXtjJaNgRAeukBIHWoFOriw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel=CpmUxcEzXtjJaNgRAeukBIHWoFOrLn,img=CpmUxcEzXtjJaNgRAeukBIHWoFOriw,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='movie':xbmcplugin.setContent(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,'movies')
  else:xbmcplugin.setContent(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,cacheToDisc=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD)
 def Delete_List_File(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsD,skey='-'):
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='ALL':
   try:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrQL=CpmUxcEzXtjJaNgRAeukBIHWoFOrbV
    fp=CpmUxcEzXtjJaNgRAeukBIHWoFOrKS(CpmUxcEzXtjJaNgRAeukBIHWoFOrQL,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='ONE':
   try:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrQL=CpmUxcEzXtjJaNgRAeukBIHWoFOrbV
    CpmUxcEzXtjJaNgRAeukBIHWoFOrQn=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.Load_List_File('search') 
    fp=CpmUxcEzXtjJaNgRAeukBIHWoFOrKS(CpmUxcEzXtjJaNgRAeukBIHWoFOrQL,'w',-1,'utf-8')
    for CpmUxcEzXtjJaNgRAeukBIHWoFOrQq in CpmUxcEzXtjJaNgRAeukBIHWoFOrQn:
     CpmUxcEzXtjJaNgRAeukBIHWoFOrQK=CpmUxcEzXtjJaNgRAeukBIHWoFOrKV(urllib.parse.parse_qsl(CpmUxcEzXtjJaNgRAeukBIHWoFOrQq))
     CpmUxcEzXtjJaNgRAeukBIHWoFOrQD=CpmUxcEzXtjJaNgRAeukBIHWoFOrQK.get('skey').strip()
     if skey!=CpmUxcEzXtjJaNgRAeukBIHWoFOrQD:
      fp.write(CpmUxcEzXtjJaNgRAeukBIHWoFOrQq)
    fp.close()
   except:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrsD in['vod','movie']:
   try:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrQL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%CpmUxcEzXtjJaNgRAeukBIHWoFOrsD))
    fp=CpmUxcEzXtjJaNgRAeukBIHWoFOrKS(CpmUxcEzXtjJaNgRAeukBIHWoFOrQL,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
 def dp_Listfile_Delete(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('stype')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnv =CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('skey')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbl=xbmcgui.Dialog()
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='ALL':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsn=CpmUxcEzXtjJaNgRAeukBIHWoFOrbl.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='ONE':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsn=CpmUxcEzXtjJaNgRAeukBIHWoFOrbl.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrsD in['vod','movie']:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrsn=CpmUxcEzXtjJaNgRAeukBIHWoFOrbl.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsn==CpmUxcEzXtjJaNgRAeukBIHWoFOrKD:sys.exit()
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.Delete_List_File(CpmUxcEzXtjJaNgRAeukBIHWoFOrsD,skey=CpmUxcEzXtjJaNgRAeukBIHWoFOrnv)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsD): 
  try:
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='search':
    CpmUxcEzXtjJaNgRAeukBIHWoFOrQL=CpmUxcEzXtjJaNgRAeukBIHWoFOrbV
   elif CpmUxcEzXtjJaNgRAeukBIHWoFOrsD in['vod','movie']:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrQL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%CpmUxcEzXtjJaNgRAeukBIHWoFOrsD))
   else:
    return[]
   fp=CpmUxcEzXtjJaNgRAeukBIHWoFOrKS(CpmUxcEzXtjJaNgRAeukBIHWoFOrQL,'r',-1,'utf-8')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQY=fp.readlines()
   fp.close()
  except:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQY=[]
  return CpmUxcEzXtjJaNgRAeukBIHWoFOrQY
 def Save_Watched_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsD,CpmUxcEzXtjJaNgRAeukBIHWoFOrbS):
  try:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%CpmUxcEzXtjJaNgRAeukBIHWoFOrsD))
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQn=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.Load_List_File(CpmUxcEzXtjJaNgRAeukBIHWoFOrsD) 
   fp=CpmUxcEzXtjJaNgRAeukBIHWoFOrKS(CpmUxcEzXtjJaNgRAeukBIHWoFOrQV,'w',-1,'utf-8')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQh=urllib.parse.urlencode(CpmUxcEzXtjJaNgRAeukBIHWoFOrbS)
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQh=CpmUxcEzXtjJaNgRAeukBIHWoFOrQh+'\n'
   fp.write(CpmUxcEzXtjJaNgRAeukBIHWoFOrQh)
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQy=0
   for CpmUxcEzXtjJaNgRAeukBIHWoFOrQq in CpmUxcEzXtjJaNgRAeukBIHWoFOrQn:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrQK=CpmUxcEzXtjJaNgRAeukBIHWoFOrKV(urllib.parse.parse_qsl(CpmUxcEzXtjJaNgRAeukBIHWoFOrQq))
    CpmUxcEzXtjJaNgRAeukBIHWoFOrQT=CpmUxcEzXtjJaNgRAeukBIHWoFOrbS.get('code').strip()
    CpmUxcEzXtjJaNgRAeukBIHWoFOrQS=CpmUxcEzXtjJaNgRAeukBIHWoFOrQK.get('code').strip()
    if CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='vod' and CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_settings_direct_replay()==CpmUxcEzXtjJaNgRAeukBIHWoFOrKq:
     CpmUxcEzXtjJaNgRAeukBIHWoFOrQT=CpmUxcEzXtjJaNgRAeukBIHWoFOrbS.get('videoid').strip()
     CpmUxcEzXtjJaNgRAeukBIHWoFOrQS=CpmUxcEzXtjJaNgRAeukBIHWoFOrQK.get('videoid').strip()if CpmUxcEzXtjJaNgRAeukBIHWoFOrQS!=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn else '-'
    if CpmUxcEzXtjJaNgRAeukBIHWoFOrQT!=CpmUxcEzXtjJaNgRAeukBIHWoFOrQS:
     fp.write(CpmUxcEzXtjJaNgRAeukBIHWoFOrQq)
     CpmUxcEzXtjJaNgRAeukBIHWoFOrQy+=1
     if CpmUxcEzXtjJaNgRAeukBIHWoFOrQy>=50:break
   fp.close()
  except:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
 def dp_Watch_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsD =CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('stype')
  CpmUxcEzXtjJaNgRAeukBIHWoFOriK=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_settings_direct_replay()
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='-':
   for CpmUxcEzXtjJaNgRAeukBIHWoFOrsV in CpmUxcEzXtjJaNgRAeukBIHWoFOrbn:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrih=CpmUxcEzXtjJaNgRAeukBIHWoFOrsV.get('title')
    CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':CpmUxcEzXtjJaNgRAeukBIHWoFOrsV.get('mode'),'stype':CpmUxcEzXtjJaNgRAeukBIHWoFOrsV.get('stype')}
    CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel='',img='',infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrKn,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrKh(CpmUxcEzXtjJaNgRAeukBIHWoFOrbn)>0:xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle)
  else:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQd=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.Load_List_File(CpmUxcEzXtjJaNgRAeukBIHWoFOrsD)
   for CpmUxcEzXtjJaNgRAeukBIHWoFOrQl in CpmUxcEzXtjJaNgRAeukBIHWoFOrQd:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrnG=CpmUxcEzXtjJaNgRAeukBIHWoFOrKV(urllib.parse.parse_qsl(CpmUxcEzXtjJaNgRAeukBIHWoFOrQl))
    CpmUxcEzXtjJaNgRAeukBIHWoFOrQw =CpmUxcEzXtjJaNgRAeukBIHWoFOrnG.get('code').strip()
    CpmUxcEzXtjJaNgRAeukBIHWoFOrih =CpmUxcEzXtjJaNgRAeukBIHWoFOrnG.get('title').strip()
    CpmUxcEzXtjJaNgRAeukBIHWoFOrsl=CpmUxcEzXtjJaNgRAeukBIHWoFOrnG.get('img').strip()
    CpmUxcEzXtjJaNgRAeukBIHWoFOrnq =CpmUxcEzXtjJaNgRAeukBIHWoFOrnG.get('videoid').strip()
    try:
     CpmUxcEzXtjJaNgRAeukBIHWoFOrsl=CpmUxcEzXtjJaNgRAeukBIHWoFOrsl.replace('\'','\"')
     CpmUxcEzXtjJaNgRAeukBIHWoFOrsl=json.loads(CpmUxcEzXtjJaNgRAeukBIHWoFOrsl)
    except:
     CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLs={}
    CpmUxcEzXtjJaNgRAeukBIHWoFOrLs['plot']=CpmUxcEzXtjJaNgRAeukBIHWoFOrih
    if CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='vod':
     if CpmUxcEzXtjJaNgRAeukBIHWoFOriK==CpmUxcEzXtjJaNgRAeukBIHWoFOrKD or CpmUxcEzXtjJaNgRAeukBIHWoFOrnq==CpmUxcEzXtjJaNgRAeukBIHWoFOrKn:
      CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':'EPISODE','programcode':CpmUxcEzXtjJaNgRAeukBIHWoFOrQw,'page':'1'}
      CpmUxcEzXtjJaNgRAeukBIHWoFOriP=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq
     else:
      CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':'VOD','mediacode':CpmUxcEzXtjJaNgRAeukBIHWoFOrnq,'stype':'vod','programcode':CpmUxcEzXtjJaNgRAeukBIHWoFOrQw,'title':CpmUxcEzXtjJaNgRAeukBIHWoFOrih,'thumbnail':CpmUxcEzXtjJaNgRAeukBIHWoFOrsl}
      CpmUxcEzXtjJaNgRAeukBIHWoFOriP=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
    else:
     CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':'MOVIE','mediacode':CpmUxcEzXtjJaNgRAeukBIHWoFOrQw,'stype':'movie','title':CpmUxcEzXtjJaNgRAeukBIHWoFOrih,'thumbnail':CpmUxcEzXtjJaNgRAeukBIHWoFOrsl}
     CpmUxcEzXtjJaNgRAeukBIHWoFOriP=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
    CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel='',img=CpmUxcEzXtjJaNgRAeukBIHWoFOrsl,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrLs,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOriP,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLs={'plot':'시청목록을 삭제합니다.'}
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih='*** 시청목록 삭제 ***'
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':'MYVIEW_REMOVE','stype':CpmUxcEzXtjJaNgRAeukBIHWoFOrsD,'skey':'-',}
   CpmUxcEzXtjJaNgRAeukBIHWoFOriw=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel='',img=CpmUxcEzXtjJaNgRAeukBIHWoFOriw,infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrLs,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM,isLink=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq)
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrsD=='movie':xbmcplugin.setContent(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,'movies')
   else:xbmcplugin.setContent(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,cacheToDisc=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD)
 def Save_Searched_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrny):
  try:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQM=CpmUxcEzXtjJaNgRAeukBIHWoFOrbV
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQn=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.Load_List_File('search') 
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQP={'skey':CpmUxcEzXtjJaNgRAeukBIHWoFOrny.strip()}
   fp=CpmUxcEzXtjJaNgRAeukBIHWoFOrKS(CpmUxcEzXtjJaNgRAeukBIHWoFOrQM,'w',-1,'utf-8')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQh=urllib.parse.urlencode(CpmUxcEzXtjJaNgRAeukBIHWoFOrQP)
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQh=CpmUxcEzXtjJaNgRAeukBIHWoFOrQh+'\n'
   fp.write(CpmUxcEzXtjJaNgRAeukBIHWoFOrQh)
   CpmUxcEzXtjJaNgRAeukBIHWoFOrQy=0
   for CpmUxcEzXtjJaNgRAeukBIHWoFOrQq in CpmUxcEzXtjJaNgRAeukBIHWoFOrQn:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrQK=CpmUxcEzXtjJaNgRAeukBIHWoFOrKV(urllib.parse.parse_qsl(CpmUxcEzXtjJaNgRAeukBIHWoFOrQq))
    CpmUxcEzXtjJaNgRAeukBIHWoFOrQT=CpmUxcEzXtjJaNgRAeukBIHWoFOrQP.get('skey').strip()
    CpmUxcEzXtjJaNgRAeukBIHWoFOrQS=CpmUxcEzXtjJaNgRAeukBIHWoFOrQK.get('skey').strip()
    if CpmUxcEzXtjJaNgRAeukBIHWoFOrQT!=CpmUxcEzXtjJaNgRAeukBIHWoFOrQS:
     fp.write(CpmUxcEzXtjJaNgRAeukBIHWoFOrQq)
     CpmUxcEzXtjJaNgRAeukBIHWoFOrQy+=1
     if CpmUxcEzXtjJaNgRAeukBIHWoFOrQy>=50:break
   fp.close()
  except:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
 def play_VIDEO(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.SaveCredential(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_winCredential())
  CpmUxcEzXtjJaNgRAeukBIHWoFOrQG =CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('mediacode')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsD =CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('stype')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrQv =CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('pvrmode')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrQf=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_selQuality(CpmUxcEzXtjJaNgRAeukBIHWoFOrsD)
  CpmUxcEzXtjJaNgRAeukBIHWoFOrqb,CpmUxcEzXtjJaNgRAeukBIHWoFOrqi=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.GetBroadURL(CpmUxcEzXtjJaNgRAeukBIHWoFOrQG,CpmUxcEzXtjJaNgRAeukBIHWoFOrQf,CpmUxcEzXtjJaNgRAeukBIHWoFOrsD,CpmUxcEzXtjJaNgRAeukBIHWoFOrQv)
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.addon_log('qt, stype, url : %s - %s - %s'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrKy(CpmUxcEzXtjJaNgRAeukBIHWoFOrQf),CpmUxcEzXtjJaNgRAeukBIHWoFOrsD,CpmUxcEzXtjJaNgRAeukBIHWoFOrqb))
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrqb=='':
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrqi=='':
    CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.addon_noti(__language__(30908).encode('utf8'))
   else:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.addon_noti(CpmUxcEzXtjJaNgRAeukBIHWoFOrqi.encode('utf8'))
   return
  CpmUxcEzXtjJaNgRAeukBIHWoFOrqs =CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
  CpmUxcEzXtjJaNgRAeukBIHWoFOrqL =CpmUxcEzXtjJaNgRAeukBIHWoFOrqb.find('Policy=')
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrqL!=-1:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqn =CpmUxcEzXtjJaNgRAeukBIHWoFOrqb.split('?')[0]
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqQ=CpmUxcEzXtjJaNgRAeukBIHWoFOrKV(urllib.parse.parse_qsl(urllib.parse.urlsplit(CpmUxcEzXtjJaNgRAeukBIHWoFOrqb).query))
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqK='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrqQ['Policy'],CpmUxcEzXtjJaNgRAeukBIHWoFOrqQ['Signature'],CpmUxcEzXtjJaNgRAeukBIHWoFOrqQ['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in CpmUxcEzXtjJaNgRAeukBIHWoFOrqn:
    CpmUxcEzXtjJaNgRAeukBIHWoFOrqs=CpmUxcEzXtjJaNgRAeukBIHWoFOrKq
    CpmUxcEzXtjJaNgRAeukBIHWoFOrqD =CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrqY=CpmUxcEzXtjJaNgRAeukBIHWoFOrqD.strftime('%Y-%m-%d-%H:%M:%S')
    if CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(CpmUxcEzXtjJaNgRAeukBIHWoFOrqY.replace('-','').replace(':',''))<CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(CpmUxcEzXtjJaNgRAeukBIHWoFOrqQ['end'].replace('-','').replace(':','')):
     CpmUxcEzXtjJaNgRAeukBIHWoFOrqQ['end']=CpmUxcEzXtjJaNgRAeukBIHWoFOrqY
     CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.addon_noti(__language__(30915).encode('utf8'))
    CpmUxcEzXtjJaNgRAeukBIHWoFOrqn ='%s?start=%s&end=%s'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrqn,CpmUxcEzXtjJaNgRAeukBIHWoFOrqQ['start'],CpmUxcEzXtjJaNgRAeukBIHWoFOrqQ['end'])
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqV='%s|Cookie=%s'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrqn,CpmUxcEzXtjJaNgRAeukBIHWoFOrqK)
  else:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqV=CpmUxcEzXtjJaNgRAeukBIHWoFOrqb
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.addon_log(CpmUxcEzXtjJaNgRAeukBIHWoFOrqV)
  CpmUxcEzXtjJaNgRAeukBIHWoFOrqh=xbmcgui.ListItem(path=CpmUxcEzXtjJaNgRAeukBIHWoFOrqV)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrqi!='':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqy=CpmUxcEzXtjJaNgRAeukBIHWoFOrqi
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqT ='https://cj.drmkeyserver.com/widevine_license'
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqS ='mpd'
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqd ='com.widevine.alpha'
   CpmUxcEzXtjJaNgRAeukBIHWoFOrql =inputstreamhelper.Helper(CpmUxcEzXtjJaNgRAeukBIHWoFOrqS,drm='widevine')
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrql.check_inputstream():
    CpmUxcEzXtjJaNgRAeukBIHWoFOrqw={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%CpmUxcEzXtjJaNgRAeukBIHWoFOrQG,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.USER_AGENT,'AcquireLicenseAssertion':CpmUxcEzXtjJaNgRAeukBIHWoFOrqy,'Host':'cj.drmkeyserver.com'}
    CpmUxcEzXtjJaNgRAeukBIHWoFOrqM=CpmUxcEzXtjJaNgRAeukBIHWoFOrqT+'|'+urllib.parse.urlencode(CpmUxcEzXtjJaNgRAeukBIHWoFOrqw)+'|R{SSM}|'
    CpmUxcEzXtjJaNgRAeukBIHWoFOrqh.setProperty('inputstream',CpmUxcEzXtjJaNgRAeukBIHWoFOrql.inputstream_addon)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrqh.setProperty('inputstream.adaptive.manifest_type',CpmUxcEzXtjJaNgRAeukBIHWoFOrqS)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrqh.setProperty('inputstream.adaptive.license_type',CpmUxcEzXtjJaNgRAeukBIHWoFOrqd)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrqh.setProperty('inputstream.adaptive.license_key',CpmUxcEzXtjJaNgRAeukBIHWoFOrqM)
    CpmUxcEzXtjJaNgRAeukBIHWoFOrqh.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.USER_AGENT))
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrqs==CpmUxcEzXtjJaNgRAeukBIHWoFOrKq:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqh.setContentLookup(CpmUxcEzXtjJaNgRAeukBIHWoFOrKD)
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqh.setMimeType('application/x-mpegURL')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqh.setProperty('inputstream','inputstream.ffmpegdirect')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqh.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqh.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqh.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqh.setProperty('ResumeTime','0')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqh.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,CpmUxcEzXtjJaNgRAeukBIHWoFOrKq,CpmUxcEzXtjJaNgRAeukBIHWoFOrqh)
  try:
   if CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('mode')in['VOD','MOVIE']and CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('title'):
    CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'code':CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('programcode')if CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('mode')=='VOD' else CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('mediacode'),'img':CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('thumbnail'),'title':CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('title'),'videoid':CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('mediacode')}
    CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.Save_Watched_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('stype'),CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
  except:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
 def logout(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbl=xbmcgui.Dialog()
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsn=CpmUxcEzXtjJaNgRAeukBIHWoFOrbl.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsn==CpmUxcEzXtjJaNgRAeukBIHWoFOrKD:sys.exit()
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.wininfo_clear()
  if os.path.isfile(CpmUxcEzXtjJaNgRAeukBIHWoFOrbY):os.remove(CpmUxcEzXtjJaNgRAeukBIHWoFOrbY)
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD=xbmcgui.Window(10000)
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_TOKEN','')
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_USERINFO','')
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_UUID','')
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_LOGINTIME','')
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_MAINTOKEN','')
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_COOKIEKEY','')
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrqP =CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.Get_Now_Datetime()
  CpmUxcEzXtjJaNgRAeukBIHWoFOrqG=CpmUxcEzXtjJaNgRAeukBIHWoFOrqP+datetime.timedelta(days=CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(__addon__.getSetting('cache_ttl')))
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD=xbmcgui.Window(10000)
  CpmUxcEzXtjJaNgRAeukBIHWoFOrqv={'tving_token':CpmUxcEzXtjJaNgRAeukBIHWoFOriD.getProperty('TVING_M_TOKEN'),'tving_userinfo':CpmUxcEzXtjJaNgRAeukBIHWoFOriD.getProperty('TVING_M_USERINFO'),'tving_uuid':CpmUxcEzXtjJaNgRAeukBIHWoFOriD.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':CpmUxcEzXtjJaNgRAeukBIHWoFOrqG.strftime('%Y-%m-%d'),'tving_maintoken':CpmUxcEzXtjJaNgRAeukBIHWoFOriD.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':CpmUxcEzXtjJaNgRAeukBIHWoFOriD.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':CpmUxcEzXtjJaNgRAeukBIHWoFOriD.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=CpmUxcEzXtjJaNgRAeukBIHWoFOrKS(CpmUxcEzXtjJaNgRAeukBIHWoFOrbY,'w',-1,'utf-8')
   json.dump(CpmUxcEzXtjJaNgRAeukBIHWoFOrqv,fp)
   fp.close()
  except CpmUxcEzXtjJaNgRAeukBIHWoFOrKd as exception:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrKl(exception)
 def cookiefile_check(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrqv={}
  try: 
   fp=CpmUxcEzXtjJaNgRAeukBIHWoFOrKS(CpmUxcEzXtjJaNgRAeukBIHWoFOrbY,'r',-1,'utf-8')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqv= json.load(fp)
   fp.close()
  except CpmUxcEzXtjJaNgRAeukBIHWoFOrKd as exception:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.wininfo_clear()
   return CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
  CpmUxcEzXtjJaNgRAeukBIHWoFOrif =__addon__.getSetting('id')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsb =__addon__.getSetting('pw')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrqf=__addon__.getSetting('login_type')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrKb =__addon__.getSetting('selected_profile')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_id']=base64.standard_b64decode(CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_id']).decode('utf-8')
  CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_pw']=base64.standard_b64decode(CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_pw']).decode('utf-8')
  try:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_profile']
  except:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_profile']='0'
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrif!=CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_id']or CpmUxcEzXtjJaNgRAeukBIHWoFOrsb!=CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_pw']or CpmUxcEzXtjJaNgRAeukBIHWoFOrqf!=CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_logintype']or CpmUxcEzXtjJaNgRAeukBIHWoFOrKb!=CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_profile']:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.wininfo_clear()
   return CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsQ =CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  CpmUxcEzXtjJaNgRAeukBIHWoFOrKi=CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_limitdate']
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsq =CpmUxcEzXtjJaNgRAeukBIHWoFOrKQ(re.sub('-','',CpmUxcEzXtjJaNgRAeukBIHWoFOrKi))
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrsq<CpmUxcEzXtjJaNgRAeukBIHWoFOrsQ:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.wininfo_clear()
   return CpmUxcEzXtjJaNgRAeukBIHWoFOrKD
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD=xbmcgui.Window(10000)
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_TOKEN',CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_token'])
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_USERINFO',CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_userinfo'])
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_UUID',CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_uuid'])
  CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_LOGINTIME',CpmUxcEzXtjJaNgRAeukBIHWoFOrKi)
  try:
   CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_MAINTOKEN',CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_maintoken'])
   CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_COOKIEKEY',CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_cookiekey'])
   CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_LOCKKEY',CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_lockkey'])
  except:
   CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_MAINTOKEN',CpmUxcEzXtjJaNgRAeukBIHWoFOrqv['tving_token'])
   CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_COOKIEKEY','Y')
   CpmUxcEzXtjJaNgRAeukBIHWoFOriD.setProperty('TVING_M_LOCKKEY','N')
  return CpmUxcEzXtjJaNgRAeukBIHWoFOrKq
 def dp_Global_Search(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=CpmUxcEzXtjJaNgRAeukBIHWoFOrsh.get('mode')
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=='TOTAL_SEARCH':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrKs='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrKs='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(CpmUxcEzXtjJaNgRAeukBIHWoFOrKs)
 def dp_Bookmark_Menu(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrKs='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(CpmUxcEzXtjJaNgRAeukBIHWoFOrKs)
 def dp_EuroLive_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh,CpmUxcEzXtjJaNgRAeukBIHWoFOrsh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.SaveCredential(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.get_winCredential())
  CpmUxcEzXtjJaNgRAeukBIHWoFOrsT=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.TvingObj.GetEuroChannelList()
  for CpmUxcEzXtjJaNgRAeukBIHWoFOrsd in CpmUxcEzXtjJaNgRAeukBIHWoFOrsT:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLV =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('channel')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrih =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('title')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLn =CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('subtitle')
   CpmUxcEzXtjJaNgRAeukBIHWoFOrLs={'mediatype':'episode','title':CpmUxcEzXtjJaNgRAeukBIHWoFOrih,'plot':'%s\n%s'%(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,CpmUxcEzXtjJaNgRAeukBIHWoFOrLn)}
   CpmUxcEzXtjJaNgRAeukBIHWoFOriM={'mode':'LIVE','mediacode':CpmUxcEzXtjJaNgRAeukBIHWoFOrsd.get('channel'),'stype':'onair',}
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.add_dir(CpmUxcEzXtjJaNgRAeukBIHWoFOrih,sublabel=CpmUxcEzXtjJaNgRAeukBIHWoFOrLn,img='',infoLabels=CpmUxcEzXtjJaNgRAeukBIHWoFOrLs,isFolder=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD,params=CpmUxcEzXtjJaNgRAeukBIHWoFOriM)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrKh(CpmUxcEzXtjJaNgRAeukBIHWoFOrsT)>0:xbmcplugin.endOfDirectory(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh._addon_handle,cacheToDisc=CpmUxcEzXtjJaNgRAeukBIHWoFOrKD)
 def tving_main(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh):
  CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params.get('mode',CpmUxcEzXtjJaNgRAeukBIHWoFOrKn)
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=='LOGOUT':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.logout()
   return
  CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.login_main()
  if CpmUxcEzXtjJaNgRAeukBIHWoFOrnT is CpmUxcEzXtjJaNgRAeukBIHWoFOrKn:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_Main_List()
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_Title_Group(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT in['GLOBAL_GROUP']:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_SubTitle_Group(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=='CHANNEL':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_LiveChannel_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT in['LIVE','VOD','MOVIE']:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.play_VIDEO(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=='PROGRAM':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_Program_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=='EPISODE':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_Episode_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=='MOVIE_SUB':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_Movie_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=='SEARCH_GROUP':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_Search_Group(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT in['SEARCH','LOCAL_SEARCH']:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_Search_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=='WATCH':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_Watch_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_Listfile_Delete(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=='ORDER_BY':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_setEpOrderby(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=='SET_BOOKMARK':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_Set_Bookmark(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT in['TOTAL_SEARCH','TOTAL_HISTORY']:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_Global_Search(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=='SEARCH_HISTORY':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_Search_History(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=='MENU_BOOKMARK':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_Bookmark_Menu(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  elif CpmUxcEzXtjJaNgRAeukBIHWoFOrnT=='EURO_GROUP':
   CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.dp_EuroLive_List(CpmUxcEzXtjJaNgRAeukBIHWoFOrbh.main_params)
  else:
   CpmUxcEzXtjJaNgRAeukBIHWoFOrKn
# Created by pyminifier (https://github.com/liftoff/pyminifier)
