__author__="NightRain"
AXsiKfMvEuoOetrGUxgTbNwYzhjPkR=object
AXsiKfMvEuoOetrGUxgTbNwYzhjPkF=None
AXsiKfMvEuoOetrGUxgTbNwYzhjPkm=int
AXsiKfMvEuoOetrGUxgTbNwYzhjPkq=True
AXsiKfMvEuoOetrGUxgTbNwYzhjPkD=False
AXsiKfMvEuoOetrGUxgTbNwYzhjPka=type
AXsiKfMvEuoOetrGUxgTbNwYzhjPkp=dict
AXsiKfMvEuoOetrGUxgTbNwYzhjPkV=len
AXsiKfMvEuoOetrGUxgTbNwYzhjPkI=str
AXsiKfMvEuoOetrGUxgTbNwYzhjPkH=range
AXsiKfMvEuoOetrGUxgTbNwYzhjPky=open
AXsiKfMvEuoOetrGUxgTbNwYzhjPkJ=Exception
AXsiKfMvEuoOetrGUxgTbNwYzhjPkS=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
AXsiKfMvEuoOetrGUxgTbNwYzhjPQW=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
AXsiKfMvEuoOetrGUxgTbNwYzhjPQc=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
AXsiKfMvEuoOetrGUxgTbNwYzhjPQB=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
AXsiKfMvEuoOetrGUxgTbNwYzhjPQR=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
AXsiKfMvEuoOetrGUxgTbNwYzhjPQF=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
AXsiKfMvEuoOetrGUxgTbNwYzhjPQk=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
AXsiKfMvEuoOetrGUxgTbNwYzhjPQm=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
AXsiKfMvEuoOetrGUxgTbNwYzhjPQq =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
AXsiKfMvEuoOetrGUxgTbNwYzhjPQD=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class AXsiKfMvEuoOetrGUxgTbNwYzhjPQC(AXsiKfMvEuoOetrGUxgTbNwYzhjPkR):
 def __init__(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPQp,AXsiKfMvEuoOetrGUxgTbNwYzhjPQV,AXsiKfMvEuoOetrGUxgTbNwYzhjPQI):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_url =AXsiKfMvEuoOetrGUxgTbNwYzhjPQp
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle=AXsiKfMvEuoOetrGUxgTbNwYzhjPQV
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params =AXsiKfMvEuoOetrGUxgTbNwYzhjPQI
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj =XQePEDxIrkoVRFTwtBhLOjMmSNqYac() 
 def addon_noti(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,sting):
  try:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQy=xbmcgui.Dialog()
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQy.notification(__addonname__,sting)
  except:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
 def addon_log(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,string):
  try:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQJ=string.encode('utf-8','ignore')
  except:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQJ='addonException: addon_log'
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQS=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,AXsiKfMvEuoOetrGUxgTbNwYzhjPQJ),level=AXsiKfMvEuoOetrGUxgTbNwYzhjPQS)
 def get_keyboard_input(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPCa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQd=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
  kb=xbmc.Keyboard()
  kb.setHeading(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQd=kb.getText()
  return AXsiKfMvEuoOetrGUxgTbNwYzhjPQd
 def get_settings_login_info(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQL =__addon__.getSetting('id')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQn =__addon__.getSetting('pw')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQl =__addon__.getSetting('login_type')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCQ=AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(__addon__.getSetting('selected_profile'))
  return(AXsiKfMvEuoOetrGUxgTbNwYzhjPQL,AXsiKfMvEuoOetrGUxgTbNwYzhjPQn,AXsiKfMvEuoOetrGUxgTbNwYzhjPQl,AXsiKfMvEuoOetrGUxgTbNwYzhjPCQ)
 def get_settings_totalsearch(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCW =AXsiKfMvEuoOetrGUxgTbNwYzhjPkq if __addon__.getSetting('local_search')=='true' else AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCc=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq if __addon__.getSetting('local_history')=='true' else AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCB =AXsiKfMvEuoOetrGUxgTbNwYzhjPkq if __addon__.getSetting('total_search')=='true' else AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCR=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq if __addon__.getSetting('total_history')=='true' else AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCF=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq if __addon__.getSetting('menu_bookmark')=='true' else AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
  return(AXsiKfMvEuoOetrGUxgTbNwYzhjPCW,AXsiKfMvEuoOetrGUxgTbNwYzhjPCc,AXsiKfMvEuoOetrGUxgTbNwYzhjPCB,AXsiKfMvEuoOetrGUxgTbNwYzhjPCR,AXsiKfMvEuoOetrGUxgTbNwYzhjPCF)
 def get_settings_makebookmark(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa):
  return AXsiKfMvEuoOetrGUxgTbNwYzhjPkq if __addon__.getSetting('make_bookmark')=='true' else AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
 def get_settings_direct_replay(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCk=AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(__addon__.getSetting('direct_replay'))
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPCk==0:
   return AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
  else:
   return AXsiKfMvEuoOetrGUxgTbNwYzhjPkq
 def set_winCredential(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,credential):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm=xbmcgui.Window(10000)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_LOGINTIME',AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm=xbmcgui.Window(10000)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCq={'tving_token':AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.getProperty('TVING_M_TOKEN'),'poc_userinfo':AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.getProperty('TVING_M_USERINFO'),'tving_uuid':AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.getProperty('TVING_M_UUID'),'tving_maintoken':AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.getProperty('TVING_M_LOCKKEY')}
  return AXsiKfMvEuoOetrGUxgTbNwYzhjPCq
 def set_winEpisodeOrderby(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPcF):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm=xbmcgui.Window(10000)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_ORDERBY',AXsiKfMvEuoOetrGUxgTbNwYzhjPcF)
 def get_winEpisodeOrderby(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm=xbmcgui.Window(10000)
  return AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.getProperty('TVING_M_ORDERBY')
 def add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,label,sublabel='',img='',infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq,params='',isLink=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD,ContextMenu=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCD='%s?%s'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_url,urllib.parse.urlencode(params))
  if sublabel:AXsiKfMvEuoOetrGUxgTbNwYzhjPCa='%s < %s >'%(label,sublabel)
  else: AXsiKfMvEuoOetrGUxgTbNwYzhjPCa=label
  if not img:img='DefaultFolder.png'
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCp=xbmcgui.ListItem(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPka(img)==AXsiKfMvEuoOetrGUxgTbNwYzhjPkp:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCp.setArt(img)
  else:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCp.setArt({'thumb':img,'poster':img})
  if infoLabels:AXsiKfMvEuoOetrGUxgTbNwYzhjPCp.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCp.setProperty('IsPlayable','true')
  if ContextMenu:AXsiKfMvEuoOetrGUxgTbNwYzhjPCp.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,AXsiKfMvEuoOetrGUxgTbNwYzhjPCD,AXsiKfMvEuoOetrGUxgTbNwYzhjPCp,isFolder)
 def get_selQuality(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,etype):
  try:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCV='selected_quality'
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCI=[1080,720,480,360]
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCH=AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(__addon__.getSetting(AXsiKfMvEuoOetrGUxgTbNwYzhjPCV))
   return AXsiKfMvEuoOetrGUxgTbNwYzhjPCI[AXsiKfMvEuoOetrGUxgTbNwYzhjPCH]
  except:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
  return 720 
 def dp_Main_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa):
  (AXsiKfMvEuoOetrGUxgTbNwYzhjPCW,AXsiKfMvEuoOetrGUxgTbNwYzhjPCc,AXsiKfMvEuoOetrGUxgTbNwYzhjPCB,AXsiKfMvEuoOetrGUxgTbNwYzhjPCR,AXsiKfMvEuoOetrGUxgTbNwYzhjPCF)=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_settings_totalsearch()
  for AXsiKfMvEuoOetrGUxgTbNwYzhjPCy in AXsiKfMvEuoOetrGUxgTbNwYzhjPQW:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa=AXsiKfMvEuoOetrGUxgTbNwYzhjPCy.get('title')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ=''
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPCy.get('mode')=='SEARCH_GROUP' and AXsiKfMvEuoOetrGUxgTbNwYzhjPCW ==AXsiKfMvEuoOetrGUxgTbNwYzhjPkD:continue
   elif AXsiKfMvEuoOetrGUxgTbNwYzhjPCy.get('mode')=='SEARCH_HISTORY' and AXsiKfMvEuoOetrGUxgTbNwYzhjPCc==AXsiKfMvEuoOetrGUxgTbNwYzhjPkD:continue
   elif AXsiKfMvEuoOetrGUxgTbNwYzhjPCy.get('mode')=='TOTAL_SEARCH' and AXsiKfMvEuoOetrGUxgTbNwYzhjPCB ==AXsiKfMvEuoOetrGUxgTbNwYzhjPkD:continue
   elif AXsiKfMvEuoOetrGUxgTbNwYzhjPCy.get('mode')=='TOTAL_HISTORY' and AXsiKfMvEuoOetrGUxgTbNwYzhjPCR==AXsiKfMvEuoOetrGUxgTbNwYzhjPkD:continue
   elif AXsiKfMvEuoOetrGUxgTbNwYzhjPCy.get('mode')=='MENU_BOOKMARK' and AXsiKfMvEuoOetrGUxgTbNwYzhjPCF==AXsiKfMvEuoOetrGUxgTbNwYzhjPkD:continue
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':AXsiKfMvEuoOetrGUxgTbNwYzhjPCy.get('mode'),'stype':AXsiKfMvEuoOetrGUxgTbNwYzhjPCy.get('stype'),'orderby':AXsiKfMvEuoOetrGUxgTbNwYzhjPCy.get('orderby'),'ordernm':AXsiKfMvEuoOetrGUxgTbNwYzhjPCy.get('ordernm'),'page':'1'}
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPCy.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCd=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCL =AXsiKfMvEuoOetrGUxgTbNwYzhjPkq
   else:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCd=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCL =AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
   if 'icon' in AXsiKfMvEuoOetrGUxgTbNwYzhjPCy:AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',AXsiKfMvEuoOetrGUxgTbNwYzhjPCy.get('icon')) 
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel='',img=AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPCd,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS,isLink=AXsiKfMvEuoOetrGUxgTbNwYzhjPCL)
  xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle)
 def login_main(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa):
  (AXsiKfMvEuoOetrGUxgTbNwYzhjPCl,AXsiKfMvEuoOetrGUxgTbNwYzhjPWQ,AXsiKfMvEuoOetrGUxgTbNwYzhjPWC,AXsiKfMvEuoOetrGUxgTbNwYzhjPWc)=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_settings_login_info()
  if not(AXsiKfMvEuoOetrGUxgTbNwYzhjPCl and AXsiKfMvEuoOetrGUxgTbNwYzhjPWQ):
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQy=xbmcgui.Dialog()
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWB=AXsiKfMvEuoOetrGUxgTbNwYzhjPQy.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPWB==AXsiKfMvEuoOetrGUxgTbNwYzhjPkq:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_winEpisodeOrderby()=='':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.set_winEpisodeOrderby('desc')
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.cookiefile_check():return
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWR =AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWF=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWF==AXsiKfMvEuoOetrGUxgTbNwYzhjPkF or AXsiKfMvEuoOetrGUxgTbNwYzhjPWF=='':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWF=AXsiKfMvEuoOetrGUxgTbNwYzhjPkm('19000101')
  else:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWF=AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(re.sub('-','',AXsiKfMvEuoOetrGUxgTbNwYzhjPWF))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWk=0
   while AXsiKfMvEuoOetrGUxgTbNwYzhjPkq:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPWk+=1
    time.sleep(0.05)
    if AXsiKfMvEuoOetrGUxgTbNwYzhjPWF>=AXsiKfMvEuoOetrGUxgTbNwYzhjPWR:return
    if AXsiKfMvEuoOetrGUxgTbNwYzhjPWk>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWF>=AXsiKfMvEuoOetrGUxgTbNwYzhjPWR:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.GetCredential(AXsiKfMvEuoOetrGUxgTbNwYzhjPCl,AXsiKfMvEuoOetrGUxgTbNwYzhjPWQ,AXsiKfMvEuoOetrGUxgTbNwYzhjPWC,AXsiKfMvEuoOetrGUxgTbNwYzhjPWc):
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.set_winCredential(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.LoadCredential())
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('stype')
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='live':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWq=AXsiKfMvEuoOetrGUxgTbNwYzhjPQc
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='vod':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWq=AXsiKfMvEuoOetrGUxgTbNwYzhjPQF
  else:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWq=AXsiKfMvEuoOetrGUxgTbNwYzhjPQk
  for AXsiKfMvEuoOetrGUxgTbNwYzhjPWD in AXsiKfMvEuoOetrGUxgTbNwYzhjPWq:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa=AXsiKfMvEuoOetrGUxgTbNwYzhjPWD.get('title')
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('ordernm')!='-':
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCa+='  ('+AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('ordernm')+')'
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':AXsiKfMvEuoOetrGUxgTbNwYzhjPWD.get('mode'),'stype':AXsiKfMvEuoOetrGUxgTbNwYzhjPWD.get('stype'),'orderby':AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('orderby'),'ordernm':AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('ordernm'),'page':'1'}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel='',img='',infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPkV(AXsiKfMvEuoOetrGUxgTbNwYzhjPWq)>0:xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle)
 def dp_SubTitle_Group(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa): 
  for AXsiKfMvEuoOetrGUxgTbNwYzhjPWD in AXsiKfMvEuoOetrGUxgTbNwYzhjPQm:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa=AXsiKfMvEuoOetrGUxgTbNwYzhjPWD.get('title')
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('ordernm')!='-':
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCa+='  ('+AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('ordernm')+')'
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':AXsiKfMvEuoOetrGUxgTbNwYzhjPWD.get('mode'),'genreCode':AXsiKfMvEuoOetrGUxgTbNwYzhjPWD.get('genreCode'),'stype':AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('stype'),'orderby':AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('orderby'),'page':'1'}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel='',img='',infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPkV(AXsiKfMvEuoOetrGUxgTbNwYzhjPQm)>0:xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle)
 def dp_LiveChannel_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.SaveCredential(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_winCredential())
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWm =AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('stype')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWp =AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('page'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWV,AXsiKfMvEuoOetrGUxgTbNwYzhjPWI=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.GetLiveChannelList(AXsiKfMvEuoOetrGUxgTbNwYzhjPWm,AXsiKfMvEuoOetrGUxgTbNwYzhjPWp)
  for AXsiKfMvEuoOetrGUxgTbNwYzhjPWH in AXsiKfMvEuoOetrGUxgTbNwYzhjPWV:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('title')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCn =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('channel')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWy =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('thumbnail')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWJ =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('synopsis')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWS =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('channelepg')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWd =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('cast')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWL =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('director')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWn =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('info_genre')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWl =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('year')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcQ =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('mpaa')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcC =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('premiered')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcW={'mediatype':'episode','title':AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,'studio':AXsiKfMvEuoOetrGUxgTbNwYzhjPCn,'cast':AXsiKfMvEuoOetrGUxgTbNwYzhjPWd,'director':AXsiKfMvEuoOetrGUxgTbNwYzhjPWL,'genre':AXsiKfMvEuoOetrGUxgTbNwYzhjPWn,'plot':'%s\n%s\n%s\n\n%s'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPCn,AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWS,AXsiKfMvEuoOetrGUxgTbNwYzhjPWJ),'year':AXsiKfMvEuoOetrGUxgTbNwYzhjPWl,'mpaa':AXsiKfMvEuoOetrGUxgTbNwYzhjPcQ,'premiered':AXsiKfMvEuoOetrGUxgTbNwYzhjPcC}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':'LIVE','mediacode':AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('mediacode'),'stype':AXsiKfMvEuoOetrGUxgTbNwYzhjPWm}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCn,sublabel=AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,img=AXsiKfMvEuoOetrGUxgTbNwYzhjPWy,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPcW,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWI:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['mode']='CHANNEL' 
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['stype']=AXsiKfMvEuoOetrGUxgTbNwYzhjPWm 
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['page']=AXsiKfMvEuoOetrGUxgTbNwYzhjPkI(AXsiKfMvEuoOetrGUxgTbNwYzhjPWp+1)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa='[B]%s >>[/B]'%'다음 페이지'
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcB=AXsiKfMvEuoOetrGUxgTbNwYzhjPkI(AXsiKfMvEuoOetrGUxgTbNwYzhjPWp+1)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel=AXsiKfMvEuoOetrGUxgTbNwYzhjPcB,img=AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPkV(AXsiKfMvEuoOetrGUxgTbNwYzhjPWV)>0:xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,cacheToDisc=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD)
 def dp_Program_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.SaveCredential(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_winCredential())
  AXsiKfMvEuoOetrGUxgTbNwYzhjPcR =AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('stype')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPcF =AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('orderby')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWp =AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('page'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPck=AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('genreCode')
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPck==AXsiKfMvEuoOetrGUxgTbNwYzhjPkF:AXsiKfMvEuoOetrGUxgTbNwYzhjPck='all'
  AXsiKfMvEuoOetrGUxgTbNwYzhjPcm,AXsiKfMvEuoOetrGUxgTbNwYzhjPWI=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.GetProgramList(AXsiKfMvEuoOetrGUxgTbNwYzhjPcR,AXsiKfMvEuoOetrGUxgTbNwYzhjPcF,AXsiKfMvEuoOetrGUxgTbNwYzhjPWp,AXsiKfMvEuoOetrGUxgTbNwYzhjPck)
  for AXsiKfMvEuoOetrGUxgTbNwYzhjPcq in AXsiKfMvEuoOetrGUxgTbNwYzhjPcm:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa =AXsiKfMvEuoOetrGUxgTbNwYzhjPcq.get('title')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWy =AXsiKfMvEuoOetrGUxgTbNwYzhjPcq.get('thumbnail')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWJ =AXsiKfMvEuoOetrGUxgTbNwYzhjPcq.get('synopsis')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcD =AXsiKfMvEuoOetrGUxgTbNwYzhjPcq.get('channel')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWd =AXsiKfMvEuoOetrGUxgTbNwYzhjPcq.get('cast')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWL =AXsiKfMvEuoOetrGUxgTbNwYzhjPcq.get('director')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWn=AXsiKfMvEuoOetrGUxgTbNwYzhjPcq.get('info_genre')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWl =AXsiKfMvEuoOetrGUxgTbNwYzhjPcq.get('year')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcC =AXsiKfMvEuoOetrGUxgTbNwYzhjPcq.get('premiered')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcQ =AXsiKfMvEuoOetrGUxgTbNwYzhjPcq.get('mpaa')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcW={'mediatype':'tvshow','title':AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,'studio':AXsiKfMvEuoOetrGUxgTbNwYzhjPcD,'cast':AXsiKfMvEuoOetrGUxgTbNwYzhjPWd,'director':AXsiKfMvEuoOetrGUxgTbNwYzhjPWL,'genre':AXsiKfMvEuoOetrGUxgTbNwYzhjPWn,'year':AXsiKfMvEuoOetrGUxgTbNwYzhjPWl,'premiered':AXsiKfMvEuoOetrGUxgTbNwYzhjPcC,'mpaa':AXsiKfMvEuoOetrGUxgTbNwYzhjPcQ,'plot':AXsiKfMvEuoOetrGUxgTbNwYzhjPWJ}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':'EPISODE','programcode':AXsiKfMvEuoOetrGUxgTbNwYzhjPcq.get('program'),'page':'1'}
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_settings_makebookmark():
    AXsiKfMvEuoOetrGUxgTbNwYzhjPca={'videoid':AXsiKfMvEuoOetrGUxgTbNwYzhjPcq.get('program'),'vidtype':'tvshow','vtitle':AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,'vsubtitle':AXsiKfMvEuoOetrGUxgTbNwYzhjPcD,}
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcp=AXsiKfMvEuoOetrGUxgTbNwYzhjPFl.dumps(AXsiKfMvEuoOetrGUxgTbNwYzhjPca)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcp=urllib.parse.quote(AXsiKfMvEuoOetrGUxgTbNwYzhjPcp)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcV='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPcp)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcI=[('(통합) 찜 영상에 추가',AXsiKfMvEuoOetrGUxgTbNwYzhjPcV)]
   else:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcI=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel=AXsiKfMvEuoOetrGUxgTbNwYzhjPcD,img=AXsiKfMvEuoOetrGUxgTbNwYzhjPWy,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPcW,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS,ContextMenu=AXsiKfMvEuoOetrGUxgTbNwYzhjPcI)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWI:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['mode'] ='PROGRAM' 
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['stype'] =AXsiKfMvEuoOetrGUxgTbNwYzhjPcR
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['orderby'] =AXsiKfMvEuoOetrGUxgTbNwYzhjPcF
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['page'] =AXsiKfMvEuoOetrGUxgTbNwYzhjPkI(AXsiKfMvEuoOetrGUxgTbNwYzhjPWp+1)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['genreCode']=AXsiKfMvEuoOetrGUxgTbNwYzhjPck 
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa='[B]%s >>[/B]'%'다음 페이지'
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcB=AXsiKfMvEuoOetrGUxgTbNwYzhjPkI(AXsiKfMvEuoOetrGUxgTbNwYzhjPWp+1)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel=AXsiKfMvEuoOetrGUxgTbNwYzhjPcB,img=AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
  xbmcplugin.setContent(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,cacheToDisc=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD)
 def dp_Episode_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.SaveCredential(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_winCredential())
  AXsiKfMvEuoOetrGUxgTbNwYzhjPcy=AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('programcode')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWp =AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('page'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPcJ,AXsiKfMvEuoOetrGUxgTbNwYzhjPWI,AXsiKfMvEuoOetrGUxgTbNwYzhjPcS=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.GetEpisodeList(AXsiKfMvEuoOetrGUxgTbNwYzhjPcy,AXsiKfMvEuoOetrGUxgTbNwYzhjPWp,orderby=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_winEpisodeOrderby())
  for AXsiKfMvEuoOetrGUxgTbNwYzhjPcd in AXsiKfMvEuoOetrGUxgTbNwYzhjPcJ:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa =AXsiKfMvEuoOetrGUxgTbNwYzhjPcd.get('title')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcB =AXsiKfMvEuoOetrGUxgTbNwYzhjPcd.get('subtitle')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWy =AXsiKfMvEuoOetrGUxgTbNwYzhjPcd.get('thumbnail')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWJ =AXsiKfMvEuoOetrGUxgTbNwYzhjPcd.get('synopsis')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcL=AXsiKfMvEuoOetrGUxgTbNwYzhjPcd.get('info_title')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcn =AXsiKfMvEuoOetrGUxgTbNwYzhjPcd.get('aired')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcl =AXsiKfMvEuoOetrGUxgTbNwYzhjPcd.get('studio')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPBQ =AXsiKfMvEuoOetrGUxgTbNwYzhjPcd.get('frequency')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcW={'mediatype':'episode','title':AXsiKfMvEuoOetrGUxgTbNwYzhjPcL,'aired':AXsiKfMvEuoOetrGUxgTbNwYzhjPcn,'studio':AXsiKfMvEuoOetrGUxgTbNwYzhjPcl,'episode':AXsiKfMvEuoOetrGUxgTbNwYzhjPBQ,'plot':AXsiKfMvEuoOetrGUxgTbNwYzhjPWJ}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':'VOD','mediacode':AXsiKfMvEuoOetrGUxgTbNwYzhjPcd.get('episode'),'stype':'vod','programcode':AXsiKfMvEuoOetrGUxgTbNwYzhjPcy,'title':AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,'thumbnail':AXsiKfMvEuoOetrGUxgTbNwYzhjPWy}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel=AXsiKfMvEuoOetrGUxgTbNwYzhjPcB,img=AXsiKfMvEuoOetrGUxgTbNwYzhjPWy,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPcW,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWp==1:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcW={'plot':'정렬순서를 변경합니다.'}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['mode'] ='ORDER_BY' 
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_winEpisodeOrderby()=='desc':
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCa='정렬순서변경 : 최신화부터 -> 1회부터'
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['orderby']='asc'
   else:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCa='정렬순서변경 : 1회부터 -> 최신화부터'
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['orderby']='desc'
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel='',img=AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPcW,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS,isLink=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWI:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['mode'] ='EPISODE' 
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['programcode']=AXsiKfMvEuoOetrGUxgTbNwYzhjPcy
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['page'] =AXsiKfMvEuoOetrGUxgTbNwYzhjPkI(AXsiKfMvEuoOetrGUxgTbNwYzhjPWp+1)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa='[B]%s >>[/B]'%'다음 페이지'
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcB=AXsiKfMvEuoOetrGUxgTbNwYzhjPkI(AXsiKfMvEuoOetrGUxgTbNwYzhjPWp+1)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel=AXsiKfMvEuoOetrGUxgTbNwYzhjPcB,img=AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
  xbmcplugin.setContent(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,'episodes')
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPkV(AXsiKfMvEuoOetrGUxgTbNwYzhjPcJ)>0:xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,cacheToDisc=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq)
 def dp_setEpOrderby(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPcF =AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('orderby')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.set_winEpisodeOrderby(AXsiKfMvEuoOetrGUxgTbNwYzhjPcF)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.SaveCredential(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_winCredential())
  AXsiKfMvEuoOetrGUxgTbNwYzhjPcR =AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('stype')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPcF =AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('orderby')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWp=AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('page'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBC,AXsiKfMvEuoOetrGUxgTbNwYzhjPWI=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.GetMovieList(AXsiKfMvEuoOetrGUxgTbNwYzhjPcR,AXsiKfMvEuoOetrGUxgTbNwYzhjPcF,AXsiKfMvEuoOetrGUxgTbNwYzhjPWp)
  for AXsiKfMvEuoOetrGUxgTbNwYzhjPBW in AXsiKfMvEuoOetrGUxgTbNwYzhjPBC:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa =AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('title')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWy =AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('thumbnail')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWJ =AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('synopsis')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcL =AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('info_title')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWl =AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('year')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWd =AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('cast')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWL =AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('director')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWn =AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('info_genre')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPBc =AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('duration')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcC =AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('premiered')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcl =AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('studio')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcQ =AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('mpaa')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcW={'mediatype':'movie','title':AXsiKfMvEuoOetrGUxgTbNwYzhjPcL,'year':AXsiKfMvEuoOetrGUxgTbNwYzhjPWl,'cast':AXsiKfMvEuoOetrGUxgTbNwYzhjPWd,'director':AXsiKfMvEuoOetrGUxgTbNwYzhjPWL,'genre':AXsiKfMvEuoOetrGUxgTbNwYzhjPWn,'duration':AXsiKfMvEuoOetrGUxgTbNwYzhjPBc,'premiered':AXsiKfMvEuoOetrGUxgTbNwYzhjPcC,'studio':AXsiKfMvEuoOetrGUxgTbNwYzhjPcl,'mpaa':AXsiKfMvEuoOetrGUxgTbNwYzhjPcQ,'plot':AXsiKfMvEuoOetrGUxgTbNwYzhjPWJ}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':'MOVIE','mediacode':AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('moviecode'),'stype':'movie','title':AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,'thumbnail':AXsiKfMvEuoOetrGUxgTbNwYzhjPWy}
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_settings_makebookmark():
    AXsiKfMvEuoOetrGUxgTbNwYzhjPca={'videoid':AXsiKfMvEuoOetrGUxgTbNwYzhjPBW.get('moviecode'),'vidtype':'movie','vtitle':AXsiKfMvEuoOetrGUxgTbNwYzhjPcL,'vsubtitle':'',}
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcp=AXsiKfMvEuoOetrGUxgTbNwYzhjPFl.dumps(AXsiKfMvEuoOetrGUxgTbNwYzhjPca)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcp=urllib.parse.quote(AXsiKfMvEuoOetrGUxgTbNwYzhjPcp)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcV='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPcp)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcI=[('(통합) 찜 영상에 추가',AXsiKfMvEuoOetrGUxgTbNwYzhjPcV)]
   else:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcI=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel='',img=AXsiKfMvEuoOetrGUxgTbNwYzhjPWy,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPcW,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS,ContextMenu=AXsiKfMvEuoOetrGUxgTbNwYzhjPcI)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWI:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['mode'] ='MOVIE_SUB' 
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['orderby']=AXsiKfMvEuoOetrGUxgTbNwYzhjPcF
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['stype'] =AXsiKfMvEuoOetrGUxgTbNwYzhjPcR
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['page'] =AXsiKfMvEuoOetrGUxgTbNwYzhjPkI(AXsiKfMvEuoOetrGUxgTbNwYzhjPWp+1)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa='[B]%s >>[/B]'%'다음 페이지'
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcB=AXsiKfMvEuoOetrGUxgTbNwYzhjPkI(AXsiKfMvEuoOetrGUxgTbNwYzhjPWp+1)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel=AXsiKfMvEuoOetrGUxgTbNwYzhjPcB,img=AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
  xbmcplugin.setContent(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,'movies')
  xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,cacheToDisc=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD)
 def dp_Set_Bookmark(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBR=urllib.parse.unquote(AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('bm_param'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBR=AXsiKfMvEuoOetrGUxgTbNwYzhjPFl.loads(AXsiKfMvEuoOetrGUxgTbNwYzhjPBR)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBF =AXsiKfMvEuoOetrGUxgTbNwYzhjPBR.get('videoid')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBk =AXsiKfMvEuoOetrGUxgTbNwYzhjPBR.get('vidtype')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBm =AXsiKfMvEuoOetrGUxgTbNwYzhjPBR.get('vtitle')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBq =AXsiKfMvEuoOetrGUxgTbNwYzhjPBR.get('vsubtitle')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQy=xbmcgui.Dialog()
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWB=AXsiKfMvEuoOetrGUxgTbNwYzhjPQy.yesno(__language__(30913).encode('utf8'),AXsiKfMvEuoOetrGUxgTbNwYzhjPBm+' \n\n'+__language__(30914))
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWB==AXsiKfMvEuoOetrGUxgTbNwYzhjPkD:return
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBD=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.GetBookmarkInfo(AXsiKfMvEuoOetrGUxgTbNwYzhjPBF,AXsiKfMvEuoOetrGUxgTbNwYzhjPBk)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPBq!='':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPBD['saveinfo']['subtitle']=AXsiKfMvEuoOetrGUxgTbNwYzhjPBq 
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPBk=='tvshow':AXsiKfMvEuoOetrGUxgTbNwYzhjPBD['saveinfo']['infoLabels']['studio']=AXsiKfMvEuoOetrGUxgTbNwYzhjPBq 
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBa=AXsiKfMvEuoOetrGUxgTbNwYzhjPFl.dumps(AXsiKfMvEuoOetrGUxgTbNwYzhjPBD)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBa=urllib.parse.quote(AXsiKfMvEuoOetrGUxgTbNwYzhjPBa)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPcV ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPBa)
  xbmc.executebuiltin(AXsiKfMvEuoOetrGUxgTbNwYzhjPcV)
 def dp_Search_Group(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  if 'search_key' in AXsiKfMvEuoOetrGUxgTbNwYzhjPWa:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPBp=AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('search_key')
  else:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPBp=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not AXsiKfMvEuoOetrGUxgTbNwYzhjPBp:
    return
  for AXsiKfMvEuoOetrGUxgTbNwYzhjPWD in AXsiKfMvEuoOetrGUxgTbNwYzhjPQR:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPBV =AXsiKfMvEuoOetrGUxgTbNwYzhjPWD.get('mode')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=AXsiKfMvEuoOetrGUxgTbNwYzhjPWD.get('stype')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa=AXsiKfMvEuoOetrGUxgTbNwYzhjPWD.get('title')
   (AXsiKfMvEuoOetrGUxgTbNwYzhjPBI,AXsiKfMvEuoOetrGUxgTbNwYzhjPWI)=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.GetSearchList(AXsiKfMvEuoOetrGUxgTbNwYzhjPBp,1,AXsiKfMvEuoOetrGUxgTbNwYzhjPWm)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPBH={'plot':'검색어 : '+AXsiKfMvEuoOetrGUxgTbNwYzhjPBp+'\n\n'+AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.Search_FreeList(AXsiKfMvEuoOetrGUxgTbNwYzhjPBI)}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':AXsiKfMvEuoOetrGUxgTbNwYzhjPBV,'stype':AXsiKfMvEuoOetrGUxgTbNwYzhjPWm,'search_key':AXsiKfMvEuoOetrGUxgTbNwYzhjPBp,'page':'1',}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel='',img='',infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPBH,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPkV(AXsiKfMvEuoOetrGUxgTbNwYzhjPQR)>0:xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,cacheToDisc=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.Save_Searched_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPBp)
 def Search_FreeList(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPRC):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBy=''
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBJ=7
  try:
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPkV(AXsiKfMvEuoOetrGUxgTbNwYzhjPRC)==0:return '검색결과 없음'
   for i in AXsiKfMvEuoOetrGUxgTbNwYzhjPkH(AXsiKfMvEuoOetrGUxgTbNwYzhjPkV(AXsiKfMvEuoOetrGUxgTbNwYzhjPRC)):
    if i>=AXsiKfMvEuoOetrGUxgTbNwYzhjPBJ:
     AXsiKfMvEuoOetrGUxgTbNwYzhjPBy=AXsiKfMvEuoOetrGUxgTbNwYzhjPBy+'...'
     break
    AXsiKfMvEuoOetrGUxgTbNwYzhjPBy=AXsiKfMvEuoOetrGUxgTbNwYzhjPBy+AXsiKfMvEuoOetrGUxgTbNwYzhjPRC[i]['title']+'\n'
  except:
   return ''
  return AXsiKfMvEuoOetrGUxgTbNwYzhjPBy
 def dp_Search_History(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBS=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.Load_List_File('search')
  for AXsiKfMvEuoOetrGUxgTbNwYzhjPBd in AXsiKfMvEuoOetrGUxgTbNwYzhjPBS:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPBL=AXsiKfMvEuoOetrGUxgTbNwYzhjPkp(urllib.parse.parse_qsl(AXsiKfMvEuoOetrGUxgTbNwYzhjPBd))
   AXsiKfMvEuoOetrGUxgTbNwYzhjPBn=AXsiKfMvEuoOetrGUxgTbNwYzhjPBL.get('skey').strip()
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':'SEARCH_GROUP','search_key':AXsiKfMvEuoOetrGUxgTbNwYzhjPBn,}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPBl={'mode':'SEARCH_REMOVE','stype':'ONE','skey':AXsiKfMvEuoOetrGUxgTbNwYzhjPBn,}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRQ=urllib.parse.urlencode(AXsiKfMvEuoOetrGUxgTbNwYzhjPBl)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcI=[('선택된 검색어 ( %s ) 삭제'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPBn),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPRQ))]
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPBn,sublabel='',img=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS,ContextMenu=AXsiKfMvEuoOetrGUxgTbNwYzhjPcI)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPcW={'plot':'검색목록 전체를 삭제합니다.'}
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCa='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel='',img=AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPcW,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS,isLink=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq)
  xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,cacheToDisc=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD)
 def dp_Search_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.SaveCredential(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_winCredential())
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWp =AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('page'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWm =AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('stype')
  if 'search_key' in AXsiKfMvEuoOetrGUxgTbNwYzhjPWa:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPBp=AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('search_key')
  else:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPBp=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not AXsiKfMvEuoOetrGUxgTbNwYzhjPBp:
    xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle)
    return
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBI,AXsiKfMvEuoOetrGUxgTbNwYzhjPWI=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.GetSearchList(AXsiKfMvEuoOetrGUxgTbNwYzhjPBp,AXsiKfMvEuoOetrGUxgTbNwYzhjPWp,AXsiKfMvEuoOetrGUxgTbNwYzhjPWm)
  for AXsiKfMvEuoOetrGUxgTbNwYzhjPRC in AXsiKfMvEuoOetrGUxgTbNwYzhjPBI:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa =AXsiKfMvEuoOetrGUxgTbNwYzhjPRC.get('title')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWy =AXsiKfMvEuoOetrGUxgTbNwYzhjPRC.get('thumbnail')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWJ =AXsiKfMvEuoOetrGUxgTbNwYzhjPRC.get('synopsis')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRW =AXsiKfMvEuoOetrGUxgTbNwYzhjPRC.get('program')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWd =AXsiKfMvEuoOetrGUxgTbNwYzhjPRC.get('cast')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWL =AXsiKfMvEuoOetrGUxgTbNwYzhjPRC.get('director')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWn=AXsiKfMvEuoOetrGUxgTbNwYzhjPRC.get('info_genre')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPBc =AXsiKfMvEuoOetrGUxgTbNwYzhjPRC.get('duration')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcQ =AXsiKfMvEuoOetrGUxgTbNwYzhjPRC.get('mpaa')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWl =AXsiKfMvEuoOetrGUxgTbNwYzhjPRC.get('year')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcn =AXsiKfMvEuoOetrGUxgTbNwYzhjPRC.get('aired')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcW={'mediatype':'tvshow' if AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='vod' else 'movie','title':AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,'cast':AXsiKfMvEuoOetrGUxgTbNwYzhjPWd,'director':AXsiKfMvEuoOetrGUxgTbNwYzhjPWL,'genre':AXsiKfMvEuoOetrGUxgTbNwYzhjPWn,'duration':AXsiKfMvEuoOetrGUxgTbNwYzhjPBc,'mpaa':AXsiKfMvEuoOetrGUxgTbNwYzhjPcQ,'year':AXsiKfMvEuoOetrGUxgTbNwYzhjPWl,'aired':AXsiKfMvEuoOetrGUxgTbNwYzhjPcn,'plot':'%s\n\n%s'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWJ)}
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='vod':
    AXsiKfMvEuoOetrGUxgTbNwYzhjPBF=AXsiKfMvEuoOetrGUxgTbNwYzhjPRC.get('program')
    AXsiKfMvEuoOetrGUxgTbNwYzhjPBk='tvshow'
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':'EPISODE','programcode':AXsiKfMvEuoOetrGUxgTbNwYzhjPBF,'page':'1',}
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCd=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq
   else:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPBF=AXsiKfMvEuoOetrGUxgTbNwYzhjPRC.get('movie')
    AXsiKfMvEuoOetrGUxgTbNwYzhjPBk='movie'
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':'MOVIE','mediacode':AXsiKfMvEuoOetrGUxgTbNwYzhjPBF,'stype':'movie','title':AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,'thumbnail':AXsiKfMvEuoOetrGUxgTbNwYzhjPWy,}
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCd=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_settings_makebookmark():
    AXsiKfMvEuoOetrGUxgTbNwYzhjPca={'videoid':AXsiKfMvEuoOetrGUxgTbNwYzhjPBF,'vidtype':AXsiKfMvEuoOetrGUxgTbNwYzhjPBk,'vtitle':AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,'vsubtitle':'',}
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcp=AXsiKfMvEuoOetrGUxgTbNwYzhjPFl.dumps(AXsiKfMvEuoOetrGUxgTbNwYzhjPca)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcp=urllib.parse.quote(AXsiKfMvEuoOetrGUxgTbNwYzhjPcp)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcV='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPcp)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcI=[('(통합) 찜 영상에 추가',AXsiKfMvEuoOetrGUxgTbNwYzhjPcV)]
   else:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcI=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel='',img=AXsiKfMvEuoOetrGUxgTbNwYzhjPWy,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPcW,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPCd,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS,isLink=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD,ContextMenu=AXsiKfMvEuoOetrGUxgTbNwYzhjPcI)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWI:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['mode'] ='SEARCH' 
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['search_key']=AXsiKfMvEuoOetrGUxgTbNwYzhjPBp
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS['page'] =AXsiKfMvEuoOetrGUxgTbNwYzhjPkI(AXsiKfMvEuoOetrGUxgTbNwYzhjPWp+1)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa='[B]%s >>[/B]'%'다음 페이지'
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcB=AXsiKfMvEuoOetrGUxgTbNwYzhjPkI(AXsiKfMvEuoOetrGUxgTbNwYzhjPWp+1)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel=AXsiKfMvEuoOetrGUxgTbNwYzhjPcB,img=AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='movie':xbmcplugin.setContent(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,'movies')
  else:xbmcplugin.setContent(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,cacheToDisc=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD)
 def Delete_List_File(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWm,skey='-'):
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='ALL':
   try:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPRc=AXsiKfMvEuoOetrGUxgTbNwYzhjPQD
    fp=AXsiKfMvEuoOetrGUxgTbNwYzhjPky(AXsiKfMvEuoOetrGUxgTbNwYzhjPRc,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='ONE':
   try:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPRc=AXsiKfMvEuoOetrGUxgTbNwYzhjPQD
    AXsiKfMvEuoOetrGUxgTbNwYzhjPRB=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.Load_List_File('search') 
    fp=AXsiKfMvEuoOetrGUxgTbNwYzhjPky(AXsiKfMvEuoOetrGUxgTbNwYzhjPRc,'w',-1,'utf-8')
    for AXsiKfMvEuoOetrGUxgTbNwYzhjPRF in AXsiKfMvEuoOetrGUxgTbNwYzhjPRB:
     AXsiKfMvEuoOetrGUxgTbNwYzhjPRk=AXsiKfMvEuoOetrGUxgTbNwYzhjPkp(urllib.parse.parse_qsl(AXsiKfMvEuoOetrGUxgTbNwYzhjPRF))
     AXsiKfMvEuoOetrGUxgTbNwYzhjPRm=AXsiKfMvEuoOetrGUxgTbNwYzhjPRk.get('skey').strip()
     if skey!=AXsiKfMvEuoOetrGUxgTbNwYzhjPRm:
      fp.write(AXsiKfMvEuoOetrGUxgTbNwYzhjPRF)
    fp.close()
   except:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPWm in['vod','movie']:
   try:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPRc=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AXsiKfMvEuoOetrGUxgTbNwYzhjPWm))
    fp=AXsiKfMvEuoOetrGUxgTbNwYzhjPky(AXsiKfMvEuoOetrGUxgTbNwYzhjPRc,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
 def dp_Listfile_Delete(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('stype')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBn =AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('skey')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQy=xbmcgui.Dialog()
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='ALL':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWB=AXsiKfMvEuoOetrGUxgTbNwYzhjPQy.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='ONE':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWB=AXsiKfMvEuoOetrGUxgTbNwYzhjPQy.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPWm in['vod','movie']:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPWB=AXsiKfMvEuoOetrGUxgTbNwYzhjPQy.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWB==AXsiKfMvEuoOetrGUxgTbNwYzhjPkD:sys.exit()
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.Delete_List_File(AXsiKfMvEuoOetrGUxgTbNwYzhjPWm,skey=AXsiKfMvEuoOetrGUxgTbNwYzhjPBn)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWm): 
  try:
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='search':
    AXsiKfMvEuoOetrGUxgTbNwYzhjPRc=AXsiKfMvEuoOetrGUxgTbNwYzhjPQD
   elif AXsiKfMvEuoOetrGUxgTbNwYzhjPWm in['vod','movie']:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPRc=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AXsiKfMvEuoOetrGUxgTbNwYzhjPWm))
   else:
    return[]
   fp=AXsiKfMvEuoOetrGUxgTbNwYzhjPky(AXsiKfMvEuoOetrGUxgTbNwYzhjPRc,'r',-1,'utf-8')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRq=fp.readlines()
   fp.close()
  except:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRq=[]
  return AXsiKfMvEuoOetrGUxgTbNwYzhjPRq
 def Save_Watched_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWm,AXsiKfMvEuoOetrGUxgTbNwYzhjPQI):
  try:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRD=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AXsiKfMvEuoOetrGUxgTbNwYzhjPWm))
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRB=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.Load_List_File(AXsiKfMvEuoOetrGUxgTbNwYzhjPWm) 
   fp=AXsiKfMvEuoOetrGUxgTbNwYzhjPky(AXsiKfMvEuoOetrGUxgTbNwYzhjPRD,'w',-1,'utf-8')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRa=urllib.parse.urlencode(AXsiKfMvEuoOetrGUxgTbNwYzhjPQI)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRa=AXsiKfMvEuoOetrGUxgTbNwYzhjPRa+'\n'
   fp.write(AXsiKfMvEuoOetrGUxgTbNwYzhjPRa)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRp=0
   for AXsiKfMvEuoOetrGUxgTbNwYzhjPRF in AXsiKfMvEuoOetrGUxgTbNwYzhjPRB:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPRk=AXsiKfMvEuoOetrGUxgTbNwYzhjPkp(urllib.parse.parse_qsl(AXsiKfMvEuoOetrGUxgTbNwYzhjPRF))
    AXsiKfMvEuoOetrGUxgTbNwYzhjPRV=AXsiKfMvEuoOetrGUxgTbNwYzhjPQI.get('code').strip()
    AXsiKfMvEuoOetrGUxgTbNwYzhjPRI=AXsiKfMvEuoOetrGUxgTbNwYzhjPRk.get('code').strip()
    if AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='vod' and AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_settings_direct_replay()==AXsiKfMvEuoOetrGUxgTbNwYzhjPkq:
     AXsiKfMvEuoOetrGUxgTbNwYzhjPRV=AXsiKfMvEuoOetrGUxgTbNwYzhjPQI.get('videoid').strip()
     AXsiKfMvEuoOetrGUxgTbNwYzhjPRI=AXsiKfMvEuoOetrGUxgTbNwYzhjPRk.get('videoid').strip()if AXsiKfMvEuoOetrGUxgTbNwYzhjPRI!=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF else '-'
    if AXsiKfMvEuoOetrGUxgTbNwYzhjPRV!=AXsiKfMvEuoOetrGUxgTbNwYzhjPRI:
     fp.write(AXsiKfMvEuoOetrGUxgTbNwYzhjPRF)
     AXsiKfMvEuoOetrGUxgTbNwYzhjPRp+=1
     if AXsiKfMvEuoOetrGUxgTbNwYzhjPRp>=50:break
   fp.close()
  except:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
 def dp_Watch_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWm =AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('stype')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCk=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_settings_direct_replay()
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='-':
   for AXsiKfMvEuoOetrGUxgTbNwYzhjPWD in AXsiKfMvEuoOetrGUxgTbNwYzhjPQB:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCa=AXsiKfMvEuoOetrGUxgTbNwYzhjPWD.get('title')
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':AXsiKfMvEuoOetrGUxgTbNwYzhjPWD.get('mode'),'stype':AXsiKfMvEuoOetrGUxgTbNwYzhjPWD.get('stype')}
    AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel='',img='',infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPkF,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPkV(AXsiKfMvEuoOetrGUxgTbNwYzhjPQB)>0:xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle)
  else:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRH=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.Load_List_File(AXsiKfMvEuoOetrGUxgTbNwYzhjPWm)
   for AXsiKfMvEuoOetrGUxgTbNwYzhjPRy in AXsiKfMvEuoOetrGUxgTbNwYzhjPRH:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPBL=AXsiKfMvEuoOetrGUxgTbNwYzhjPkp(urllib.parse.parse_qsl(AXsiKfMvEuoOetrGUxgTbNwYzhjPRy))
    AXsiKfMvEuoOetrGUxgTbNwYzhjPRJ =AXsiKfMvEuoOetrGUxgTbNwYzhjPBL.get('code').strip()
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCa =AXsiKfMvEuoOetrGUxgTbNwYzhjPBL.get('title').strip()
    AXsiKfMvEuoOetrGUxgTbNwYzhjPWy=AXsiKfMvEuoOetrGUxgTbNwYzhjPBL.get('img').strip()
    AXsiKfMvEuoOetrGUxgTbNwYzhjPBF =AXsiKfMvEuoOetrGUxgTbNwYzhjPBL.get('videoid').strip()
    try:
     AXsiKfMvEuoOetrGUxgTbNwYzhjPWy=AXsiKfMvEuoOetrGUxgTbNwYzhjPWy.replace('\'','\"')
     AXsiKfMvEuoOetrGUxgTbNwYzhjPWy=AXsiKfMvEuoOetrGUxgTbNwYzhjPFl.loads(AXsiKfMvEuoOetrGUxgTbNwYzhjPWy)
    except:
     AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcW={}
    AXsiKfMvEuoOetrGUxgTbNwYzhjPcW['plot']=AXsiKfMvEuoOetrGUxgTbNwYzhjPCa
    if AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='vod':
     if AXsiKfMvEuoOetrGUxgTbNwYzhjPCk==AXsiKfMvEuoOetrGUxgTbNwYzhjPkD or AXsiKfMvEuoOetrGUxgTbNwYzhjPBF==AXsiKfMvEuoOetrGUxgTbNwYzhjPkF:
      AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':'EPISODE','programcode':AXsiKfMvEuoOetrGUxgTbNwYzhjPRJ,'page':'1'}
      AXsiKfMvEuoOetrGUxgTbNwYzhjPCd=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq
     else:
      AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':'VOD','mediacode':AXsiKfMvEuoOetrGUxgTbNwYzhjPBF,'stype':'vod','programcode':AXsiKfMvEuoOetrGUxgTbNwYzhjPRJ,'title':AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,'thumbnail':AXsiKfMvEuoOetrGUxgTbNwYzhjPWy}
      AXsiKfMvEuoOetrGUxgTbNwYzhjPCd=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
    else:
     AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':'MOVIE','mediacode':AXsiKfMvEuoOetrGUxgTbNwYzhjPRJ,'stype':'movie','title':AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,'thumbnail':AXsiKfMvEuoOetrGUxgTbNwYzhjPWy}
     AXsiKfMvEuoOetrGUxgTbNwYzhjPCd=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
    AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel='',img=AXsiKfMvEuoOetrGUxgTbNwYzhjPWy,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPcW,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPCd,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcW={'plot':'시청목록을 삭제합니다.'}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa='*** 시청목록 삭제 ***'
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':'MYVIEW_REMOVE','stype':AXsiKfMvEuoOetrGUxgTbNwYzhjPWm,'skey':'-',}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel='',img=AXsiKfMvEuoOetrGUxgTbNwYzhjPCJ,infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPcW,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS,isLink=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq)
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPWm=='movie':xbmcplugin.setContent(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,'movies')
   else:xbmcplugin.setContent(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,cacheToDisc=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD)
 def Save_Searched_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPBp):
  try:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRS=AXsiKfMvEuoOetrGUxgTbNwYzhjPQD
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRB=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.Load_List_File('search') 
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRd={'skey':AXsiKfMvEuoOetrGUxgTbNwYzhjPBp.strip()}
   fp=AXsiKfMvEuoOetrGUxgTbNwYzhjPky(AXsiKfMvEuoOetrGUxgTbNwYzhjPRS,'w',-1,'utf-8')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRa=urllib.parse.urlencode(AXsiKfMvEuoOetrGUxgTbNwYzhjPRd)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRa=AXsiKfMvEuoOetrGUxgTbNwYzhjPRa+'\n'
   fp.write(AXsiKfMvEuoOetrGUxgTbNwYzhjPRa)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPRp=0
   for AXsiKfMvEuoOetrGUxgTbNwYzhjPRF in AXsiKfMvEuoOetrGUxgTbNwYzhjPRB:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPRk=AXsiKfMvEuoOetrGUxgTbNwYzhjPkp(urllib.parse.parse_qsl(AXsiKfMvEuoOetrGUxgTbNwYzhjPRF))
    AXsiKfMvEuoOetrGUxgTbNwYzhjPRV=AXsiKfMvEuoOetrGUxgTbNwYzhjPRd.get('skey').strip()
    AXsiKfMvEuoOetrGUxgTbNwYzhjPRI=AXsiKfMvEuoOetrGUxgTbNwYzhjPRk.get('skey').strip()
    if AXsiKfMvEuoOetrGUxgTbNwYzhjPRV!=AXsiKfMvEuoOetrGUxgTbNwYzhjPRI:
     fp.write(AXsiKfMvEuoOetrGUxgTbNwYzhjPRF)
     AXsiKfMvEuoOetrGUxgTbNwYzhjPRp+=1
     if AXsiKfMvEuoOetrGUxgTbNwYzhjPRp>=50:break
   fp.close()
  except:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
 def play_VIDEO(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.SaveCredential(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_winCredential())
  AXsiKfMvEuoOetrGUxgTbNwYzhjPRL =AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('mediacode')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWm =AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('stype')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPRn =AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('pvrmode')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPRl=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_selQuality(AXsiKfMvEuoOetrGUxgTbNwYzhjPWm)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPRL,AXsiKfMvEuoOetrGUxgTbNwYzhjPkI(AXsiKfMvEuoOetrGUxgTbNwYzhjPRl),AXsiKfMvEuoOetrGUxgTbNwYzhjPWm,AXsiKfMvEuoOetrGUxgTbNwYzhjPRn))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPFQ,AXsiKfMvEuoOetrGUxgTbNwYzhjPFC=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.GetBroadURL(AXsiKfMvEuoOetrGUxgTbNwYzhjPRL,AXsiKfMvEuoOetrGUxgTbNwYzhjPRl,AXsiKfMvEuoOetrGUxgTbNwYzhjPWm,AXsiKfMvEuoOetrGUxgTbNwYzhjPRn)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.addon_log('qt, stype, url : %s - %s - %s'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPkI(AXsiKfMvEuoOetrGUxgTbNwYzhjPRl),AXsiKfMvEuoOetrGUxgTbNwYzhjPWm,AXsiKfMvEuoOetrGUxgTbNwYzhjPFQ))
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPFQ=='':
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPFC=='':
    AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.addon_noti(__language__(30908).encode('utf8'))
   else:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.addon_noti(AXsiKfMvEuoOetrGUxgTbNwYzhjPFC.encode('utf8'))
   return
  AXsiKfMvEuoOetrGUxgTbNwYzhjPFW =AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
  AXsiKfMvEuoOetrGUxgTbNwYzhjPFc =AXsiKfMvEuoOetrGUxgTbNwYzhjPFQ.find('Policy=')
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPFc!=-1:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFB =AXsiKfMvEuoOetrGUxgTbNwYzhjPFQ.split('?')[0]
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFR=AXsiKfMvEuoOetrGUxgTbNwYzhjPkp(urllib.parse.parse_qsl(urllib.parse.urlsplit(AXsiKfMvEuoOetrGUxgTbNwYzhjPFQ).query))
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFk='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPFR['Policy'],AXsiKfMvEuoOetrGUxgTbNwYzhjPFR['Signature'],AXsiKfMvEuoOetrGUxgTbNwYzhjPFR['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in AXsiKfMvEuoOetrGUxgTbNwYzhjPFB:
    AXsiKfMvEuoOetrGUxgTbNwYzhjPFW=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq
    AXsiKfMvEuoOetrGUxgTbNwYzhjPFm =AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPFq=AXsiKfMvEuoOetrGUxgTbNwYzhjPFm.strftime('%Y-%m-%d-%H:%M:%S')
    if AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(AXsiKfMvEuoOetrGUxgTbNwYzhjPFq.replace('-','').replace(':',''))<AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(AXsiKfMvEuoOetrGUxgTbNwYzhjPFR['end'].replace('-','').replace(':','')):
     AXsiKfMvEuoOetrGUxgTbNwYzhjPFR['end']=AXsiKfMvEuoOetrGUxgTbNwYzhjPFq
     AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.addon_noti(__language__(30915).encode('utf8'))
    AXsiKfMvEuoOetrGUxgTbNwYzhjPFB ='%s?%s'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPFB,urllib.parse.urlencode(AXsiKfMvEuoOetrGUxgTbNwYzhjPFR,doseq=AXsiKfMvEuoOetrGUxgTbNwYzhjPkq))
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFD='%s|Cookie=%s'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPFB,AXsiKfMvEuoOetrGUxgTbNwYzhjPFk)
  else:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFD=AXsiKfMvEuoOetrGUxgTbNwYzhjPFQ
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.addon_log(AXsiKfMvEuoOetrGUxgTbNwYzhjPFD)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPFa=xbmcgui.ListItem(path=AXsiKfMvEuoOetrGUxgTbNwYzhjPFD)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPFC!='':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFp=AXsiKfMvEuoOetrGUxgTbNwYzhjPFC
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFV ='https://cj.drmkeyserver.com/widevine_license'
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFI ='mpd'
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFH ='com.widevine.alpha'
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFy =inputstreamhelper.Helper(AXsiKfMvEuoOetrGUxgTbNwYzhjPFI,drm='widevine')
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPFy.check_inputstream():
    AXsiKfMvEuoOetrGUxgTbNwYzhjPFJ={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%AXsiKfMvEuoOetrGUxgTbNwYzhjPRL,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.USER_AGENT,'AcquireLicenseAssertion':AXsiKfMvEuoOetrGUxgTbNwYzhjPFp,'Host':'cj.drmkeyserver.com'}
    AXsiKfMvEuoOetrGUxgTbNwYzhjPFS=AXsiKfMvEuoOetrGUxgTbNwYzhjPFV+'|'+urllib.parse.urlencode(AXsiKfMvEuoOetrGUxgTbNwYzhjPFJ)+'|R{SSM}|'
    AXsiKfMvEuoOetrGUxgTbNwYzhjPFa.setProperty('inputstream',AXsiKfMvEuoOetrGUxgTbNwYzhjPFy.inputstream_addon)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPFa.setProperty('inputstream.adaptive.manifest_type',AXsiKfMvEuoOetrGUxgTbNwYzhjPFI)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPFa.setProperty('inputstream.adaptive.license_type',AXsiKfMvEuoOetrGUxgTbNwYzhjPFH)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPFa.setProperty('inputstream.adaptive.license_key',AXsiKfMvEuoOetrGUxgTbNwYzhjPFS)
    AXsiKfMvEuoOetrGUxgTbNwYzhjPFa.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.USER_AGENT))
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPFW==AXsiKfMvEuoOetrGUxgTbNwYzhjPkq:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFa.setContentLookup(AXsiKfMvEuoOetrGUxgTbNwYzhjPkD)
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFa.setMimeType('application/x-mpegURL')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFa.setProperty('inputstream','inputstream.ffmpegdirect')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFa.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFa.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFa.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFa.setProperty('ResumeTime','0')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFa.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,AXsiKfMvEuoOetrGUxgTbNwYzhjPkq,AXsiKfMvEuoOetrGUxgTbNwYzhjPFa)
  try:
   if AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('mode')in['VOD','MOVIE']and AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('title'):
    AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'code':AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('programcode')if AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('mode')=='VOD' else AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('mediacode'),'img':AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('thumbnail'),'title':AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('title'),'videoid':AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('mediacode')}
    AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.Save_Watched_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('stype'),AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
  except:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
 def logout(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQy=xbmcgui.Dialog()
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWB=AXsiKfMvEuoOetrGUxgTbNwYzhjPQy.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWB==AXsiKfMvEuoOetrGUxgTbNwYzhjPkD:sys.exit()
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.wininfo_clear()
  if os.path.isfile(AXsiKfMvEuoOetrGUxgTbNwYzhjPQq):os.remove(AXsiKfMvEuoOetrGUxgTbNwYzhjPQq)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm=xbmcgui.Window(10000)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_TOKEN','')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_USERINFO','')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_UUID','')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_LOGINTIME','')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_MAINTOKEN','')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_COOKIEKEY','')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPFd =AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.Get_Now_Datetime()
  AXsiKfMvEuoOetrGUxgTbNwYzhjPFL=AXsiKfMvEuoOetrGUxgTbNwYzhjPFd+datetime.timedelta(days=AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(__addon__.getSetting('cache_ttl')))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm=xbmcgui.Window(10000)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPFn={'tving_token':AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.getProperty('TVING_M_TOKEN'),'tving_userinfo':AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.getProperty('TVING_M_USERINFO'),'tving_uuid':AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':AXsiKfMvEuoOetrGUxgTbNwYzhjPFL.strftime('%Y-%m-%d'),'tving_maintoken':AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=AXsiKfMvEuoOetrGUxgTbNwYzhjPky(AXsiKfMvEuoOetrGUxgTbNwYzhjPQq,'w',-1,'utf-8')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFl.dump(AXsiKfMvEuoOetrGUxgTbNwYzhjPFn,fp,indent=4,ensure_ascii=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD)
   fp.close()
  except AXsiKfMvEuoOetrGUxgTbNwYzhjPkJ as exception:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPkS(exception)
 def cookiefile_check(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPFn={}
  try: 
   fp=AXsiKfMvEuoOetrGUxgTbNwYzhjPky(AXsiKfMvEuoOetrGUxgTbNwYzhjPQq,'r',-1,'utf-8')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFn= AXsiKfMvEuoOetrGUxgTbNwYzhjPFl.load(fp)
   fp.close()
  except AXsiKfMvEuoOetrGUxgTbNwYzhjPkJ as exception:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.wininfo_clear()
   return AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCl =__addon__.getSetting('id')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWQ =__addon__.getSetting('pw')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPkC=__addon__.getSetting('login_type')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPkW =__addon__.getSetting('selected_profile')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_id']=base64.standard_b64decode(AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_id']).decode('utf-8')
  AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_pw']=base64.standard_b64decode(AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_pw']).decode('utf-8')
  try:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_profile']
  except:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_profile']='0'
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPCl!=AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_id']or AXsiKfMvEuoOetrGUxgTbNwYzhjPWQ!=AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_pw']or AXsiKfMvEuoOetrGUxgTbNwYzhjPkC!=AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_logintype']or AXsiKfMvEuoOetrGUxgTbNwYzhjPkW!=AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_profile']or AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_token']=='':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.wininfo_clear()
   return AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWR =AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  AXsiKfMvEuoOetrGUxgTbNwYzhjPkc=AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_limitdate']
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWF =AXsiKfMvEuoOetrGUxgTbNwYzhjPkm(re.sub('-','',AXsiKfMvEuoOetrGUxgTbNwYzhjPkc))
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPWF<AXsiKfMvEuoOetrGUxgTbNwYzhjPWR:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.wininfo_clear()
   return AXsiKfMvEuoOetrGUxgTbNwYzhjPkD
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm=xbmcgui.Window(10000)
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_TOKEN',AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_token'])
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_USERINFO',AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_userinfo'])
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_UUID',AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_uuid'])
  AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_LOGINTIME',AXsiKfMvEuoOetrGUxgTbNwYzhjPkc)
  try:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_MAINTOKEN',AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_maintoken'])
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_COOKIEKEY',AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_cookiekey'])
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_LOCKKEY',AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_lockkey'])
  except:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_MAINTOKEN',AXsiKfMvEuoOetrGUxgTbNwYzhjPFn['tving_token'])
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_COOKIEKEY','Y')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCm.setProperty('TVING_M_LOCKKEY','N')
  return AXsiKfMvEuoOetrGUxgTbNwYzhjPkq
 def dp_Global_Search(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=AXsiKfMvEuoOetrGUxgTbNwYzhjPWa.get('mode')
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=='TOTAL_SEARCH':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPkB='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPkB='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(AXsiKfMvEuoOetrGUxgTbNwYzhjPkB)
 def dp_Bookmark_Menu(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPkB='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(AXsiKfMvEuoOetrGUxgTbNwYzhjPkB)
 def dp_EuroLive_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa,AXsiKfMvEuoOetrGUxgTbNwYzhjPWa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.SaveCredential(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.get_winCredential())
  AXsiKfMvEuoOetrGUxgTbNwYzhjPWV=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.TvingObj.GetEuroChannelList()
  for AXsiKfMvEuoOetrGUxgTbNwYzhjPWH in AXsiKfMvEuoOetrGUxgTbNwYzhjPWV:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcD =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('channel')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCa =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('title')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcB =AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('subtitle')
   AXsiKfMvEuoOetrGUxgTbNwYzhjPcW={'mediatype':'episode','title':AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,'plot':'%s\n%s'%(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,AXsiKfMvEuoOetrGUxgTbNwYzhjPcB)}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPCS={'mode':'LIVE','mediacode':AXsiKfMvEuoOetrGUxgTbNwYzhjPWH.get('channel'),'stype':'onair',}
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.add_dir(AXsiKfMvEuoOetrGUxgTbNwYzhjPCa,sublabel=AXsiKfMvEuoOetrGUxgTbNwYzhjPcB,img='',infoLabels=AXsiKfMvEuoOetrGUxgTbNwYzhjPcW,isFolder=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD,params=AXsiKfMvEuoOetrGUxgTbNwYzhjPCS)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPkV(AXsiKfMvEuoOetrGUxgTbNwYzhjPWV)>0:xbmcplugin.endOfDirectory(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa._addon_handle,cacheToDisc=AXsiKfMvEuoOetrGUxgTbNwYzhjPkD)
 def tving_main(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa):
  AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params.get('mode',AXsiKfMvEuoOetrGUxgTbNwYzhjPkF)
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=='LOGOUT':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.logout()
   return
  AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.login_main()
  if AXsiKfMvEuoOetrGUxgTbNwYzhjPBV is AXsiKfMvEuoOetrGUxgTbNwYzhjPkF:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_Main_List()
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_Title_Group(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV in['GLOBAL_GROUP']:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_SubTitle_Group(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=='CHANNEL':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_LiveChannel_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV in['LIVE','VOD','MOVIE']:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.play_VIDEO(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=='PROGRAM':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_Program_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=='EPISODE':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_Episode_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=='MOVIE_SUB':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_Movie_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=='SEARCH_GROUP':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_Search_Group(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV in['SEARCH','LOCAL_SEARCH']:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_Search_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=='WATCH':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_Watch_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_Listfile_Delete(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=='ORDER_BY':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_setEpOrderby(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=='SET_BOOKMARK':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_Set_Bookmark(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV in['TOTAL_SEARCH','TOTAL_HISTORY']:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_Global_Search(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=='SEARCH_HISTORY':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_Search_History(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=='MENU_BOOKMARK':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_Bookmark_Menu(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  elif AXsiKfMvEuoOetrGUxgTbNwYzhjPBV=='EURO_GROUP':
   AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.dp_EuroLive_List(AXsiKfMvEuoOetrGUxgTbNwYzhjPQa.main_params)
  else:
   AXsiKfMvEuoOetrGUxgTbNwYzhjPkF
# Created by pyminifier (https://github.com/liftoff/pyminifier)
