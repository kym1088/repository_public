__author__="NightRain"
XQePEDxIrkoVRFTwtBhLOjMmSNqYzi=ImportError
XQePEDxIrkoVRFTwtBhLOjMmSNqYzd=object
XQePEDxIrkoVRFTwtBhLOjMmSNqYzb=None
XQePEDxIrkoVRFTwtBhLOjMmSNqYzy=False
XQePEDxIrkoVRFTwtBhLOjMmSNqYzH=int
XQePEDxIrkoVRFTwtBhLOjMmSNqYzC=range
XQePEDxIrkoVRFTwtBhLOjMmSNqYzW=True
XQePEDxIrkoVRFTwtBhLOjMmSNqYzn=print
XQePEDxIrkoVRFTwtBhLOjMmSNqYzg=Exception
XQePEDxIrkoVRFTwtBhLOjMmSNqYzs=str
XQePEDxIrkoVRFTwtBhLOjMmSNqYzv=list
XQePEDxIrkoVRFTwtBhLOjMmSNqYzp=len
XQePEDxIrkoVRFTwtBhLOjMmSNqYfa=bytes
XQePEDxIrkoVRFTwtBhLOjMmSNqYfc=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
try:
 from Cryptodome.PublicKey import RSA
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
except XQePEDxIrkoVRFTwtBhLOjMmSNqYzi:
 from Crypto.PublicKey import RSA
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
XQePEDxIrkoVRFTwtBhLOjMmSNqYaA={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
XQePEDxIrkoVRFTwtBhLOjMmSNqYaJ ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class XQePEDxIrkoVRFTwtBhLOjMmSNqYac(XQePEDxIrkoVRFTwtBhLOjMmSNqYzd):
 def __init__(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_TOKEN =''
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.POC_USERINFO =''
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_UUID ='-'
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_MAINTOKEN=''
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVIGN_COOKIEKEY=''
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_LOCKKEY =''
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.NETWORKCODE ='CSND0900'
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.OSCODE ='CSOD0900' 
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TELECODE ='CSCD0900'
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.SCREENCODE ='CSSD0100'
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.LIVE_LIMIT =23
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.VOD_LIMIT =20
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.EPISODE_LIMIT =30 
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.SEARCH_LIMIT =30 
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.MOVIE_LIMIT =18
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.API_DOMAIN ='https://api.tving.com'
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN ='https://image.tving.com'
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.SEARCH_DOMAIN ='https://search.tving.com'
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.LOGIN_DOMAIN ='https://user.tving.com'
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.URL_DOMAIN ='https://www.tving.com'
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.MOVIE_LITE =['2610061','2610161','261062']
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.DEFAULT_HEADER ={'user-agent':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.USER_AGENT}
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,jobtype,XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,redirects=XQePEDxIrkoVRFTwtBhLOjMmSNqYzy):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaz=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.DEFAULT_HEADER
  if headers:XQePEDxIrkoVRFTwtBhLOjMmSNqYaz.update(headers)
  if jobtype=='Get':
   XQePEDxIrkoVRFTwtBhLOjMmSNqYaf=requests.get(XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,params=params,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYaz,cookies=cookies,allow_redirects=redirects)
  else:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYaf=requests.post(XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,data=payload,params=params,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYaz,cookies=cookies,allow_redirects=redirects)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYaf
 def makeDefaultCookies(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,vToken=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,vUserinfo=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaU={}
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaU['_tving_token']=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_TOKEN if vToken==XQePEDxIrkoVRFTwtBhLOjMmSNqYzb else vToken
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaU['POC_USERINFO']=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.POC_USERINFO if vToken==XQePEDxIrkoVRFTwtBhLOjMmSNqYzb else vUserinfo
  if XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_MAINTOKEN!='':XQePEDxIrkoVRFTwtBhLOjMmSNqYaU[XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GLOBAL_COOKIENM['tv_maintoken']]=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_MAINTOKEN
  if XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVIGN_COOKIEKEY!='':XQePEDxIrkoVRFTwtBhLOjMmSNqYaU[XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GLOBAL_COOKIENM['tv_cookiekey']]=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVIGN_COOKIEKEY
  if XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_LOCKKEY !='':XQePEDxIrkoVRFTwtBhLOjMmSNqYaU[XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GLOBAL_COOKIENM['tv_lockkey']] =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_LOCKKEY
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYaU
 def getDeviceStr(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaK=[]
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaK.append('Windows') 
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaK.append('Chrome') 
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaK.append('ko-KR') 
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaK.append('undefined') 
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaK.append('24') 
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaK.append(u'한국 표준시')
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaK.append('undefined') 
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaK.append('undefined') 
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaK.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  XQePEDxIrkoVRFTwtBhLOjMmSNqYau=''
  for XQePEDxIrkoVRFTwtBhLOjMmSNqYal in XQePEDxIrkoVRFTwtBhLOjMmSNqYaK:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYau+=XQePEDxIrkoVRFTwtBhLOjMmSNqYal+'|'
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYau
 def SaveCredential(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,XQePEDxIrkoVRFTwtBhLOjMmSNqYai):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_TOKEN =XQePEDxIrkoVRFTwtBhLOjMmSNqYai.get('tving_token')
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.POC_USERINFO =XQePEDxIrkoVRFTwtBhLOjMmSNqYai.get('poc_userinfo')
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_UUID =XQePEDxIrkoVRFTwtBhLOjMmSNqYai.get('tving_uuid')
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_MAINTOKEN=XQePEDxIrkoVRFTwtBhLOjMmSNqYai.get('tving_maintoken')
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVIGN_COOKIEKEY=XQePEDxIrkoVRFTwtBhLOjMmSNqYai.get('tving_cookiekey')
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_LOCKKEY =XQePEDxIrkoVRFTwtBhLOjMmSNqYai.get('tving_lockkey')
 def LoadCredential(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYai={'tving_token':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_TOKEN,'poc_userinfo':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.POC_USERINFO,'tving_uuid':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_UUID,'tving_maintoken':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_MAINTOKEN,'tving_cookiekey':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVIGN_COOKIEKEY,'tving_lockkey':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_LOCKKEY}
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYai
 def GetDefaultParams(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYad={'apiKey':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.APIKEY,'networkCode':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.NETWORKCODE,'osCode':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.OSCODE,'teleCode':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TELECODE,'screenCode':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.SCREENCODE}
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYad
 def GetNoCache(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,timetype=1):
  if timetype==1:
   return XQePEDxIrkoVRFTwtBhLOjMmSNqYzH(time.time())
  else:
   return XQePEDxIrkoVRFTwtBhLOjMmSNqYzH(time.time()*1000)
 def GetUniqueid(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYab=[0 for i in XQePEDxIrkoVRFTwtBhLOjMmSNqYzC(256)]
  for i in XQePEDxIrkoVRFTwtBhLOjMmSNqYzC(256):
   XQePEDxIrkoVRFTwtBhLOjMmSNqYab[i]='%02x'%(i)
  XQePEDxIrkoVRFTwtBhLOjMmSNqYay=XQePEDxIrkoVRFTwtBhLOjMmSNqYzH(4294967295*random.random())|0
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaH=XQePEDxIrkoVRFTwtBhLOjMmSNqYab[255&XQePEDxIrkoVRFTwtBhLOjMmSNqYay]+XQePEDxIrkoVRFTwtBhLOjMmSNqYab[XQePEDxIrkoVRFTwtBhLOjMmSNqYay>>8&255]+XQePEDxIrkoVRFTwtBhLOjMmSNqYab[XQePEDxIrkoVRFTwtBhLOjMmSNqYay>>16&255]+XQePEDxIrkoVRFTwtBhLOjMmSNqYab[XQePEDxIrkoVRFTwtBhLOjMmSNqYay>>24&255]
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYaH
 def GetCredential(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,user_id,user_pw,login_type,user_pf):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaC=XQePEDxIrkoVRFTwtBhLOjMmSNqYzy
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaW=XQePEDxIrkoVRFTwtBhLOjMmSNqYca=XQePEDxIrkoVRFTwtBhLOjMmSNqYcA=XQePEDxIrkoVRFTwtBhLOjMmSNqYcJ=XQePEDxIrkoVRFTwtBhLOjMmSNqYcG='' 
  XQePEDxIrkoVRFTwtBhLOjMmSNqYan ='-'
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYag=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYas={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Post',XQePEDxIrkoVRFTwtBhLOjMmSNqYag,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYas,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb)
   for XQePEDxIrkoVRFTwtBhLOjMmSNqYap in XQePEDxIrkoVRFTwtBhLOjMmSNqYav.cookies:
    if XQePEDxIrkoVRFTwtBhLOjMmSNqYap.name=='_tving_token':
     XQePEDxIrkoVRFTwtBhLOjMmSNqYca=XQePEDxIrkoVRFTwtBhLOjMmSNqYap.value
    elif XQePEDxIrkoVRFTwtBhLOjMmSNqYap.name=='POC_USERINFO':
     XQePEDxIrkoVRFTwtBhLOjMmSNqYcA=XQePEDxIrkoVRFTwtBhLOjMmSNqYap.value
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYca=='':return XQePEDxIrkoVRFTwtBhLOjMmSNqYaC
   XQePEDxIrkoVRFTwtBhLOjMmSNqYaW=XQePEDxIrkoVRFTwtBhLOjMmSNqYca
   XQePEDxIrkoVRFTwtBhLOjMmSNqYca,XQePEDxIrkoVRFTwtBhLOjMmSNqYcJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYcG=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetProfileToken(XQePEDxIrkoVRFTwtBhLOjMmSNqYca,XQePEDxIrkoVRFTwtBhLOjMmSNqYcA,user_pf)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYaC=XQePEDxIrkoVRFTwtBhLOjMmSNqYzW
   XQePEDxIrkoVRFTwtBhLOjMmSNqYan =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetDeviceList(XQePEDxIrkoVRFTwtBhLOjMmSNqYca,XQePEDxIrkoVRFTwtBhLOjMmSNqYcA)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYan =XQePEDxIrkoVRFTwtBhLOjMmSNqYan+'-'+XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetUniqueid()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(XQePEDxIrkoVRFTwtBhLOjMmSNqYan)
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYaW=XQePEDxIrkoVRFTwtBhLOjMmSNqYca=XQePEDxIrkoVRFTwtBhLOjMmSNqYcA=XQePEDxIrkoVRFTwtBhLOjMmSNqYcJ=XQePEDxIrkoVRFTwtBhLOjMmSNqYcG=''
   XQePEDxIrkoVRFTwtBhLOjMmSNqYan='-'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  XQePEDxIrkoVRFTwtBhLOjMmSNqYai={'tving_token':XQePEDxIrkoVRFTwtBhLOjMmSNqYca,'poc_userinfo':XQePEDxIrkoVRFTwtBhLOjMmSNqYcA,'tving_uuid':XQePEDxIrkoVRFTwtBhLOjMmSNqYan,'tving_maintoken':XQePEDxIrkoVRFTwtBhLOjMmSNqYaW,'tving_cookiekey':XQePEDxIrkoVRFTwtBhLOjMmSNqYcJ,'tving_lockkey':XQePEDxIrkoVRFTwtBhLOjMmSNqYcG}
  XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.SaveCredential(XQePEDxIrkoVRFTwtBhLOjMmSNqYai)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYaC
 def Get_Now_Datetime(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,mediacode,sel_quality,stype,pvrmode='-'):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYcf=''
  XQePEDxIrkoVRFTwtBhLOjMmSNqYcU=''
  XQePEDxIrkoVRFTwtBhLOjMmSNqYcK =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_UUID.split('-')[0] 
  XQePEDxIrkoVRFTwtBhLOjMmSNqYcu =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.TVING_UUID 
  XQePEDxIrkoVRFTwtBhLOjMmSNqYcl=XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetNoCache(1))
  try:
   if stype!='tvingtv':
    XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='/v2/media/stream/info' 
    XQePEDxIrkoVRFTwtBhLOjMmSNqYcd=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetDefaultParams()
    XQePEDxIrkoVRFTwtBhLOjMmSNqYcb={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':XQePEDxIrkoVRFTwtBhLOjMmSNqYcu,'deviceInfo':'PC','noCache':XQePEDxIrkoVRFTwtBhLOjMmSNqYcl,}
    XQePEDxIrkoVRFTwtBhLOjMmSNqYcd.update(XQePEDxIrkoVRFTwtBhLOjMmSNqYcb)
    XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.API_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYci
    XQePEDxIrkoVRFTwtBhLOjMmSNqYaU=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.makeDefaultCookies()
    XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYcd,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYaU)
    if XQePEDxIrkoVRFTwtBhLOjMmSNqYav.status_code!=200:return XQePEDxIrkoVRFTwtBhLOjMmSNqYcf,XQePEDxIrkoVRFTwtBhLOjMmSNqYcU
    XQePEDxIrkoVRFTwtBhLOjMmSNqYcH=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
    if XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['result']['code']=='060':
     for XQePEDxIrkoVRFTwtBhLOjMmSNqYcC,XQePEDxIrkoVRFTwtBhLOjMmSNqYAc in XQePEDxIrkoVRFTwtBhLOjMmSNqYaA.items():
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYAc==sel_quality:
       XQePEDxIrkoVRFTwtBhLOjMmSNqYcW=XQePEDxIrkoVRFTwtBhLOjMmSNqYcC
    elif XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['result']['code']!='000':
     XQePEDxIrkoVRFTwtBhLOjMmSNqYcU=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['result']['message']
     return XQePEDxIrkoVRFTwtBhLOjMmSNqYcf,XQePEDxIrkoVRFTwtBhLOjMmSNqYcU
    else: 
     if not('stream' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']):return XQePEDxIrkoVRFTwtBhLOjMmSNqYcf,XQePEDxIrkoVRFTwtBhLOjMmSNqYcU 
     XQePEDxIrkoVRFTwtBhLOjMmSNqYcn=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['stream']
     XQePEDxIrkoVRFTwtBhLOjMmSNqYcg=XQePEDxIrkoVRFTwtBhLOjMmSNqYcn['quality']
     XQePEDxIrkoVRFTwtBhLOjMmSNqYcs=[]
     for XQePEDxIrkoVRFTwtBhLOjMmSNqYcv in XQePEDxIrkoVRFTwtBhLOjMmSNqYcg:
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['active']=='Y':
       XQePEDxIrkoVRFTwtBhLOjMmSNqYcs.append({XQePEDxIrkoVRFTwtBhLOjMmSNqYaA.get(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['code']):XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['code']})
     XQePEDxIrkoVRFTwtBhLOjMmSNqYcW=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.CheckQuality(sel_quality,XQePEDxIrkoVRFTwtBhLOjMmSNqYcs)
   else:
    XQePEDxIrkoVRFTwtBhLOjMmSNqYcW='stream40'
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
   return XQePEDxIrkoVRFTwtBhLOjMmSNqYcf,XQePEDxIrkoVRFTwtBhLOjMmSNqYcU
  XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(XQePEDxIrkoVRFTwtBhLOjMmSNqYcW)
  XQePEDxIrkoVRFTwtBhLOjMmSNqYcl=XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetNoCache(1))
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='/v2a/media/stream/info'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetDefaultParams()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcb={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':XQePEDxIrkoVRFTwtBhLOjMmSNqYcW,'deviceId':XQePEDxIrkoVRFTwtBhLOjMmSNqYcK,'uuid':XQePEDxIrkoVRFTwtBhLOjMmSNqYcu,'deviceInfo':'PC_Chrome','noCache':XQePEDxIrkoVRFTwtBhLOjMmSNqYcl,'wm':'Y'}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd.update(XQePEDxIrkoVRFTwtBhLOjMmSNqYcb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.API_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYci
   XQePEDxIrkoVRFTwtBhLOjMmSNqYaU=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.makeDefaultCookies()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYcd,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYaU,redirects=XQePEDxIrkoVRFTwtBhLOjMmSNqYzy)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcH=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['result']['code']!='000':
    XQePEDxIrkoVRFTwtBhLOjMmSNqYcU=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['result']['message']
    return XQePEDxIrkoVRFTwtBhLOjMmSNqYcf,XQePEDxIrkoVRFTwtBhLOjMmSNqYcU
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcn=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['stream']
   if 'drm_license_assertion' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcn:
    XQePEDxIrkoVRFTwtBhLOjMmSNqYcU =XQePEDxIrkoVRFTwtBhLOjMmSNqYcn['drm_license_assertion']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYcf=XQePEDxIrkoVRFTwtBhLOjMmSNqYcn['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcn['broadcast']):return XQePEDxIrkoVRFTwtBhLOjMmSNqYcf,XQePEDxIrkoVRFTwtBhLOjMmSNqYcU
    XQePEDxIrkoVRFTwtBhLOjMmSNqYcf=XQePEDxIrkoVRFTwtBhLOjMmSNqYcn['broadcast']['broad_url']
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  XQePEDxIrkoVRFTwtBhLOjMmSNqYcf=XQePEDxIrkoVRFTwtBhLOjMmSNqYcf.split('|')[1]
  XQePEDxIrkoVRFTwtBhLOjMmSNqYcf=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.Decrypt_Url(XQePEDxIrkoVRFTwtBhLOjMmSNqYcf,mediacode=mediacode,timecode=XQePEDxIrkoVRFTwtBhLOjMmSNqYcl)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYcf,XQePEDxIrkoVRFTwtBhLOjMmSNqYcU
 def CheckQuality(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,sel_qt,XQePEDxIrkoVRFTwtBhLOjMmSNqYcs):
  for XQePEDxIrkoVRFTwtBhLOjMmSNqYcp in XQePEDxIrkoVRFTwtBhLOjMmSNqYcs:
   if sel_qt>=XQePEDxIrkoVRFTwtBhLOjMmSNqYzv(XQePEDxIrkoVRFTwtBhLOjMmSNqYcp)[0]:return XQePEDxIrkoVRFTwtBhLOjMmSNqYcp.get(XQePEDxIrkoVRFTwtBhLOjMmSNqYzv(XQePEDxIrkoVRFTwtBhLOjMmSNqYcp)[0])
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAa=XQePEDxIrkoVRFTwtBhLOjMmSNqYcp.get(XQePEDxIrkoVRFTwtBhLOjMmSNqYzv(XQePEDxIrkoVRFTwtBhLOjMmSNqYcp)[0])
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYAa
 def makeOocUrl(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,ooc_params):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=''
  for XQePEDxIrkoVRFTwtBhLOjMmSNqYcC,XQePEDxIrkoVRFTwtBhLOjMmSNqYAc in ooc_params.items():
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy+="%s=%s^"%(XQePEDxIrkoVRFTwtBhLOjMmSNqYcC,XQePEDxIrkoVRFTwtBhLOjMmSNqYAc)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYcy
 def GetLiveChannelList(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,stype,page_int):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ=[]
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAG=XQePEDxIrkoVRFTwtBhLOjMmSNqYzy
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAz=XQePEDxIrkoVRFTwtBhLOjMmSNqYzy
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='/v2/media/lives'
   if stype=='onair': 
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAf='CPCS0100,CPCS0400'
   else:
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAf='CPCS0300'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetDefaultParams()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcb={'pageNo':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(page_int),'pageSize':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':XQePEDxIrkoVRFTwtBhLOjMmSNqYAf,'_':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetNoCache(2))}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd.update(XQePEDxIrkoVRFTwtBhLOjMmSNqYcb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.API_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYci
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYcd,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcH=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   if not('result' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']):return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAU=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['result']
   for XQePEDxIrkoVRFTwtBhLOjMmSNqYcv in XQePEDxIrkoVRFTwtBhLOjMmSNqYAU:
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAK=XQePEDxIrkoVRFTwtBhLOjMmSNqYAi=XQePEDxIrkoVRFTwtBhLOjMmSNqYAd=''
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAu=XQePEDxIrkoVRFTwtBhLOjMmSNqYJU=''
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAl=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['live_code']
    if XQePEDxIrkoVRFTwtBhLOjMmSNqYAl=='C01345':XQePEDxIrkoVRFTwtBhLOjMmSNqYAz=XQePEDxIrkoVRFTwtBhLOjMmSNqYzW 
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAK =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['channel']['name']['ko']
    if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['episode']!=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAi =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['program']['name']['ko']
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAi =XQePEDxIrkoVRFTwtBhLOjMmSNqYAi+', '+XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['episode']['frequency'])+'회'
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAd=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['episode']['synopsis']['ko']
    else:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAi =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['program']['name']['ko']
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAd=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['program']['synopsis']['ko']
    try: 
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =''
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAy =''
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAH=''
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAC =''
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAW =''
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAn =''
     for XQePEDxIrkoVRFTwtBhLOjMmSNqYAg in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['program']['image']:
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP0900':XQePEDxIrkoVRFTwtBhLOjMmSNqYAy =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
      elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP1800':XQePEDxIrkoVRFTwtBhLOjMmSNqYAH=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
      elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP2000':XQePEDxIrkoVRFTwtBhLOjMmSNqYAC =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
      elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP1900':XQePEDxIrkoVRFTwtBhLOjMmSNqYAW =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
      elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP0200':XQePEDxIrkoVRFTwtBhLOjMmSNqYAn =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
      elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP0500':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
      elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP0800':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYAb=='':
      for XQePEDxIrkoVRFTwtBhLOjMmSNqYAg in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['channel']['image']:
       if XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIC0400':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
       elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIC1400':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
       elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIC1900':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
    except:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYzb
    try:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAs =[]
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAv=[]
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAp =[]
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJa=''
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJc=''
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJA=''
     for XQePEDxIrkoVRFTwtBhLOjMmSNqYJG in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('schedule').get('program').get('actor'):
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYJG!='' and XQePEDxIrkoVRFTwtBhLOjMmSNqYJG!=u'없음':XQePEDxIrkoVRFTwtBhLOjMmSNqYAs.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJG)
     for XQePEDxIrkoVRFTwtBhLOjMmSNqYJz in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('schedule').get('program').get('director'):
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYJz!='' and XQePEDxIrkoVRFTwtBhLOjMmSNqYJz!='-' and XQePEDxIrkoVRFTwtBhLOjMmSNqYJz!=u'없음':XQePEDxIrkoVRFTwtBhLOjMmSNqYAv.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJz)
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('schedule').get('program').get('category1_name').get('ko')!='':
      XQePEDxIrkoVRFTwtBhLOjMmSNqYAp.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['program']['category1_name']['ko'])
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('schedule').get('program').get('category2_name').get('ko')!='':
      XQePEDxIrkoVRFTwtBhLOjMmSNqYAp.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['program']['category2_name']['ko'])
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('schedule').get('program').get('product_year'):XQePEDxIrkoVRFTwtBhLOjMmSNqYJa=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['program']['product_year']
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('schedule').get('program').get('grade_code') :XQePEDxIrkoVRFTwtBhLOjMmSNqYJc= XQePEDxIrkoVRFTwtBhLOjMmSNqYaJ.get(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['program']['grade_code'])
     if 'broad_dt' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('schedule').get('program'):
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJf =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('schedule').get('program').get('broad_dt')
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJA='%s-%s-%s'%(XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[:4],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[4:6],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[6:])
    except:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYzb
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAu=XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['broadcast_start_time'])[8:12]
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJU =XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['schedule']['broadcast_end_time'])[8:12]
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJK={'channel':XQePEDxIrkoVRFTwtBhLOjMmSNqYAK,'title':XQePEDxIrkoVRFTwtBhLOjMmSNqYAi,'mediacode':XQePEDxIrkoVRFTwtBhLOjMmSNqYAl,'thumbnail':{'poster':XQePEDxIrkoVRFTwtBhLOjMmSNqYAy,'thumb':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb,'clearlogo':XQePEDxIrkoVRFTwtBhLOjMmSNqYAH,'icon':XQePEDxIrkoVRFTwtBhLOjMmSNqYAC,'fanart':XQePEDxIrkoVRFTwtBhLOjMmSNqYAn},'synopsis':XQePEDxIrkoVRFTwtBhLOjMmSNqYAd,'channelepg':' [%s:%s ~ %s:%s]'%(XQePEDxIrkoVRFTwtBhLOjMmSNqYAu[0:2],XQePEDxIrkoVRFTwtBhLOjMmSNqYAu[2:],XQePEDxIrkoVRFTwtBhLOjMmSNqYJU[0:2],XQePEDxIrkoVRFTwtBhLOjMmSNqYJU[2:]),'cast':XQePEDxIrkoVRFTwtBhLOjMmSNqYAs,'director':XQePEDxIrkoVRFTwtBhLOjMmSNqYAv,'info_genre':XQePEDxIrkoVRFTwtBhLOjMmSNqYAp,'year':XQePEDxIrkoVRFTwtBhLOjMmSNqYJa,'mpaa':XQePEDxIrkoVRFTwtBhLOjMmSNqYJc,'premiered':XQePEDxIrkoVRFTwtBhLOjMmSNqYJA}
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJK)
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['has_more']=='Y':
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAG=XQePEDxIrkoVRFTwtBhLOjMmSNqYzW
   else:
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJK={'channel':'OCN Original','title':'temp','mediacode':'C01345','thumbnail':'http://image.tving.com/upload/cms/caic/CAIC0400/C01345.png','cast':[],'director':[]}
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
 def GetProgramList(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,genre,orderby,page_int,genreCode='all'):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ=[]
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAG=XQePEDxIrkoVRFTwtBhLOjMmSNqYzy
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='/v2/media/episodes'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetDefaultParams()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcb={'pageNo':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(page_int),'pageSize':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetNoCache(2))}
   if genre !='all':XQePEDxIrkoVRFTwtBhLOjMmSNqYcb['categoryCode']=genre
   if genreCode!='all':XQePEDxIrkoVRFTwtBhLOjMmSNqYcb['genreCode'] =genreCode 
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd.update(XQePEDxIrkoVRFTwtBhLOjMmSNqYcb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.API_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYci
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYcd,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcH=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   if not('result' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']):return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAU=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['result']
   for XQePEDxIrkoVRFTwtBhLOjMmSNqYcv in XQePEDxIrkoVRFTwtBhLOjMmSNqYAU:
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJu=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['program']['code']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAi =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['program']['name']['ko']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJc =XQePEDxIrkoVRFTwtBhLOjMmSNqYaJ.get(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['program'].get('grade_code'))
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAy =''
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =''
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAH=''
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAC =''
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAW =''
    for XQePEDxIrkoVRFTwtBhLOjMmSNqYAg in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['program']['image']:
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP0900':XQePEDxIrkoVRFTwtBhLOjMmSNqYAy =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
     elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP0200':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
     elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP1800':XQePEDxIrkoVRFTwtBhLOjMmSNqYAH=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
     elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP2000':XQePEDxIrkoVRFTwtBhLOjMmSNqYAC =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
     elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP1900':XQePEDxIrkoVRFTwtBhLOjMmSNqYAW =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAd =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['program']['synopsis']['ko']
    try:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJl=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['channel']['name']['ko']
    except:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJl=''
    try:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAs =[]
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAv=[]
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAp =[]
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJa =''
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJA=''
     for XQePEDxIrkoVRFTwtBhLOjMmSNqYJG in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('program').get('actor'):
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYJG!='' and XQePEDxIrkoVRFTwtBhLOjMmSNqYJG!='-' and XQePEDxIrkoVRFTwtBhLOjMmSNqYJG!=u'없음':XQePEDxIrkoVRFTwtBhLOjMmSNqYAs.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJG)
     for XQePEDxIrkoVRFTwtBhLOjMmSNqYJz in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('program').get('director'):
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYJz!='' and XQePEDxIrkoVRFTwtBhLOjMmSNqYJz!='-' and XQePEDxIrkoVRFTwtBhLOjMmSNqYJz!=u'없음':XQePEDxIrkoVRFTwtBhLOjMmSNqYAv.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJz)
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('program').get('category1_name').get('ko')!='':
      XQePEDxIrkoVRFTwtBhLOjMmSNqYAp.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['program']['category1_name']['ko'])
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('program').get('category2_name').get('ko')!='':
      XQePEDxIrkoVRFTwtBhLOjMmSNqYAp.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['program']['category2_name']['ko'])
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('program').get('product_year'):XQePEDxIrkoVRFTwtBhLOjMmSNqYJa=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['program']['product_year']
     if 'broad_dt' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('program'):
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJf =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('program').get('broad_dt')
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJA='%s-%s-%s'%(XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[:4],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[4:6],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[6:])
    except:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYzb
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJK={'program':XQePEDxIrkoVRFTwtBhLOjMmSNqYJu,'title':XQePEDxIrkoVRFTwtBhLOjMmSNqYAi,'thumbnail':{'poster':XQePEDxIrkoVRFTwtBhLOjMmSNqYAy,'thumb':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb,'clearlogo':XQePEDxIrkoVRFTwtBhLOjMmSNqYAH,'icon':XQePEDxIrkoVRFTwtBhLOjMmSNqYAC,'banner':XQePEDxIrkoVRFTwtBhLOjMmSNqYAW,'fanart':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb},'synopsis':XQePEDxIrkoVRFTwtBhLOjMmSNqYAd,'channel':XQePEDxIrkoVRFTwtBhLOjMmSNqYJl,'cast':XQePEDxIrkoVRFTwtBhLOjMmSNqYAs,'director':XQePEDxIrkoVRFTwtBhLOjMmSNqYAv,'info_genre':XQePEDxIrkoVRFTwtBhLOjMmSNqYAp,'year':XQePEDxIrkoVRFTwtBhLOjMmSNqYJa,'premiered':XQePEDxIrkoVRFTwtBhLOjMmSNqYJA,'mpaa':XQePEDxIrkoVRFTwtBhLOjMmSNqYJc}
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJK)
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['has_more']=='Y':XQePEDxIrkoVRFTwtBhLOjMmSNqYAG=XQePEDxIrkoVRFTwtBhLOjMmSNqYzW
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
 def GetEpisodeList(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,program_code,page_int,orderby='desc'):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ=[]
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAG=XQePEDxIrkoVRFTwtBhLOjMmSNqYzy
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='/v2/media/frequency/program/'+program_code
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetDefaultParams()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcb={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetNoCache(2))}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd.update(XQePEDxIrkoVRFTwtBhLOjMmSNqYcb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.API_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYci
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYcd,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcH=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   if not('result' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']):return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAU=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['result']
   XQePEDxIrkoVRFTwtBhLOjMmSNqYJi=XQePEDxIrkoVRFTwtBhLOjMmSNqYzH(XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['total_count'])
   XQePEDxIrkoVRFTwtBhLOjMmSNqYJd =XQePEDxIrkoVRFTwtBhLOjMmSNqYzH(XQePEDxIrkoVRFTwtBhLOjMmSNqYJi//(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJb =(XQePEDxIrkoVRFTwtBhLOjMmSNqYJi-1)-((page_int-1)*XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.EPISODE_LIMIT)
   else:
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJb =(page_int-1)*XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.EPISODE_LIMIT
   for i in XQePEDxIrkoVRFTwtBhLOjMmSNqYzC(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.EPISODE_LIMIT):
    if orderby=='desc':
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJy=XQePEDxIrkoVRFTwtBhLOjMmSNqYJb-i
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYJy<0:break
    else:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJy=XQePEDxIrkoVRFTwtBhLOjMmSNqYJb+i
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYJy>=XQePEDxIrkoVRFTwtBhLOjMmSNqYJi:break
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJH=XQePEDxIrkoVRFTwtBhLOjMmSNqYAU[XQePEDxIrkoVRFTwtBhLOjMmSNqYJy]['episode']['code']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAi =XQePEDxIrkoVRFTwtBhLOjMmSNqYAU[XQePEDxIrkoVRFTwtBhLOjMmSNqYJy]['vod_name']['ko']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJC =''
    try:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJf=XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYAU[XQePEDxIrkoVRFTwtBhLOjMmSNqYJy]['episode']['broadcast_date'])
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJC='%s-%s-%s'%(XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[:4],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[4:6],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[6:])
    except:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYzb
    try:
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYAU[XQePEDxIrkoVRFTwtBhLOjMmSNqYJy]['episode']['pip_cliptype']=='C012':
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJC+=' - Quick VOD'
    except:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYzb
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAd =XQePEDxIrkoVRFTwtBhLOjMmSNqYAU[XQePEDxIrkoVRFTwtBhLOjMmSNqYJy]['episode']['synopsis']['ko']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAy =''
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =''
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAH=''
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAC =''
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAW =''
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAn =''
    for XQePEDxIrkoVRFTwtBhLOjMmSNqYAg in XQePEDxIrkoVRFTwtBhLOjMmSNqYAU[XQePEDxIrkoVRFTwtBhLOjMmSNqYJy]['program']['image']:
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP0900':XQePEDxIrkoVRFTwtBhLOjMmSNqYAy =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
     elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP1800':XQePEDxIrkoVRFTwtBhLOjMmSNqYAH=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
     elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP2000':XQePEDxIrkoVRFTwtBhLOjMmSNqYAC =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
     elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP1900':XQePEDxIrkoVRFTwtBhLOjMmSNqYAW =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
     elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIP0200':XQePEDxIrkoVRFTwtBhLOjMmSNqYAn =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
    for XQePEDxIrkoVRFTwtBhLOjMmSNqYAg in XQePEDxIrkoVRFTwtBhLOjMmSNqYAU[XQePEDxIrkoVRFTwtBhLOjMmSNqYJy]['episode']['image']:
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIE0400':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
    try:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJW=XQePEDxIrkoVRFTwtBhLOjMmSNqYJg=XQePEDxIrkoVRFTwtBhLOjMmSNqYJs=''
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJn=0
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJW =XQePEDxIrkoVRFTwtBhLOjMmSNqYAU[XQePEDxIrkoVRFTwtBhLOjMmSNqYJy]['program']['name']['ko']
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJg =XQePEDxIrkoVRFTwtBhLOjMmSNqYJC
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJs =XQePEDxIrkoVRFTwtBhLOjMmSNqYAU[XQePEDxIrkoVRFTwtBhLOjMmSNqYJy]['channel']['name']['ko']
     if 'frequency' in XQePEDxIrkoVRFTwtBhLOjMmSNqYAU[XQePEDxIrkoVRFTwtBhLOjMmSNqYJy]['episode']:XQePEDxIrkoVRFTwtBhLOjMmSNqYJn=XQePEDxIrkoVRFTwtBhLOjMmSNqYAU[XQePEDxIrkoVRFTwtBhLOjMmSNqYJy]['episode']['frequency']
    except:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYzb
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJK={'episode':XQePEDxIrkoVRFTwtBhLOjMmSNqYJH,'title':XQePEDxIrkoVRFTwtBhLOjMmSNqYAi,'subtitle':XQePEDxIrkoVRFTwtBhLOjMmSNqYJC,'thumbnail':{'poster':XQePEDxIrkoVRFTwtBhLOjMmSNqYAy,'thumb':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb,'clearlogo':XQePEDxIrkoVRFTwtBhLOjMmSNqYAH,'icon':XQePEDxIrkoVRFTwtBhLOjMmSNqYAC,'banner':XQePEDxIrkoVRFTwtBhLOjMmSNqYAW,'fanart':XQePEDxIrkoVRFTwtBhLOjMmSNqYAn},'synopsis':XQePEDxIrkoVRFTwtBhLOjMmSNqYAd,'info_title':XQePEDxIrkoVRFTwtBhLOjMmSNqYJW,'aired':XQePEDxIrkoVRFTwtBhLOjMmSNqYJg,'studio':XQePEDxIrkoVRFTwtBhLOjMmSNqYJs,'frequency':XQePEDxIrkoVRFTwtBhLOjMmSNqYJn}
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJK)
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYJd>page_int:XQePEDxIrkoVRFTwtBhLOjMmSNqYAG=XQePEDxIrkoVRFTwtBhLOjMmSNqYzW
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG,XQePEDxIrkoVRFTwtBhLOjMmSNqYJd
 def GetMovieList(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,genre,orderby,page_int):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ=[]
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAG=XQePEDxIrkoVRFTwtBhLOjMmSNqYzy
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='/v2/media/movies'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetDefaultParams()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcb={'pageNo':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(page_int),'pageSize':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetNoCache(2))}
   if genre!='all' :XQePEDxIrkoVRFTwtBhLOjMmSNqYcb['multiCategoryCode']=genre
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcb['productPackageCode']=','.join(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.MOVIE_LITE)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd.update(XQePEDxIrkoVRFTwtBhLOjMmSNqYcb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.API_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYci
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYcd,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcH=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   if not('result' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']):return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAU=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['result']
   for XQePEDxIrkoVRFTwtBhLOjMmSNqYcv in XQePEDxIrkoVRFTwtBhLOjMmSNqYAU:
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJv =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['movie']['code']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAi =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['movie']['name']['ko'].strip()
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAi +=u' (%s)'%(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('movie').get('product_year'))
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAy=''
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =''
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAH=''
    for XQePEDxIrkoVRFTwtBhLOjMmSNqYAg in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['movie']['image']:
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIM2100':XQePEDxIrkoVRFTwtBhLOjMmSNqYAy =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
     elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIM0400':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
     elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIM1800':XQePEDxIrkoVRFTwtBhLOjMmSNqYAH=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAd =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['movie']['story']['ko']
    try:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJW =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['movie']['name']['ko'].strip()
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJa =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('movie').get('product_year')
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJc =XQePEDxIrkoVRFTwtBhLOjMmSNqYaJ.get(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('grade_code'))
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAs=[]
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAv=[]
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAp=[]
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJp=0
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJA=''
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJs =''
     for XQePEDxIrkoVRFTwtBhLOjMmSNqYJG in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('movie').get('actor'):
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYJG!='':XQePEDxIrkoVRFTwtBhLOjMmSNqYAs.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJG)
     for XQePEDxIrkoVRFTwtBhLOjMmSNqYJz in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('movie').get('director'):
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYJz!='':XQePEDxIrkoVRFTwtBhLOjMmSNqYAv.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJz)
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('movie').get('category1_name').get('ko')!='':
      XQePEDxIrkoVRFTwtBhLOjMmSNqYAp.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['movie']['category1_name']['ko'])
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('movie').get('category2_name').get('ko')!='':
      XQePEDxIrkoVRFTwtBhLOjMmSNqYAp.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['movie']['category2_name']['ko'])
     if 'duration' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('movie'):XQePEDxIrkoVRFTwtBhLOjMmSNqYJp=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('movie').get('duration')
     if 'release_date' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('movie'):
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJf=XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('movie').get('release_date'))
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYJf!='0':XQePEDxIrkoVRFTwtBhLOjMmSNqYJA='%s-%s-%s'%(XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[:4],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[4:6],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[6:])
     if 'production' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('movie'):XQePEDxIrkoVRFTwtBhLOjMmSNqYJs=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('movie').get('production')
    except:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYzb
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJK={'moviecode':XQePEDxIrkoVRFTwtBhLOjMmSNqYJv,'title':XQePEDxIrkoVRFTwtBhLOjMmSNqYAi,'thumbnail':{'poster':XQePEDxIrkoVRFTwtBhLOjMmSNqYAy,'thumb':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb,'clearlogo':XQePEDxIrkoVRFTwtBhLOjMmSNqYAH,'fanart':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb},'synopsis':XQePEDxIrkoVRFTwtBhLOjMmSNqYAd,'info_title':XQePEDxIrkoVRFTwtBhLOjMmSNqYJW,'year':XQePEDxIrkoVRFTwtBhLOjMmSNqYJa,'cast':XQePEDxIrkoVRFTwtBhLOjMmSNqYAs,'director':XQePEDxIrkoVRFTwtBhLOjMmSNqYAv,'info_genre':XQePEDxIrkoVRFTwtBhLOjMmSNqYAp,'duration':XQePEDxIrkoVRFTwtBhLOjMmSNqYJp,'premiered':XQePEDxIrkoVRFTwtBhLOjMmSNqYJA,'studio':XQePEDxIrkoVRFTwtBhLOjMmSNqYJs,'mpaa':XQePEDxIrkoVRFTwtBhLOjMmSNqYJc}
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGa=XQePEDxIrkoVRFTwtBhLOjMmSNqYzy
    for XQePEDxIrkoVRFTwtBhLOjMmSNqYGc in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['billing_package_id']:
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYGc in XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.MOVIE_LITE:
      XQePEDxIrkoVRFTwtBhLOjMmSNqYGa=XQePEDxIrkoVRFTwtBhLOjMmSNqYzW
      break
    if XQePEDxIrkoVRFTwtBhLOjMmSNqYGa==XQePEDxIrkoVRFTwtBhLOjMmSNqYzy: 
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJK['title']=XQePEDxIrkoVRFTwtBhLOjMmSNqYJK['title']+' [개별구매]'
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJK)
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['has_more']=='Y':XQePEDxIrkoVRFTwtBhLOjMmSNqYAG=XQePEDxIrkoVRFTwtBhLOjMmSNqYzW
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
 def GetMovieListGenre(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,genre,page_int):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ=[]
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAG=XQePEDxIrkoVRFTwtBhLOjMmSNqYzy
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='/v2/media/movie/curation/'+genre
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetDefaultParams()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcb={'pageNo':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(page_int),'pageSize':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.MOVIE_LIMIT),'_':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetNoCache(2))}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd.update(XQePEDxIrkoVRFTwtBhLOjMmSNqYcb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.API_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYci
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYcd,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcH=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   if not('movies' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']):return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAU=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['movies']
   for XQePEDxIrkoVRFTwtBhLOjMmSNqYcv in XQePEDxIrkoVRFTwtBhLOjMmSNqYAU:
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJv =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['code']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAi =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['name']['ko']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGA =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['image'][0]['url']
    for XQePEDxIrkoVRFTwtBhLOjMmSNqYAg in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['image']:
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['code']=='CAIM2100':
      XQePEDxIrkoVRFTwtBhLOjMmSNqYGA =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg['url']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAd =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['story']['ko']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJK={'moviecode':XQePEDxIrkoVRFTwtBhLOjMmSNqYJv,'title':XQePEDxIrkoVRFTwtBhLOjMmSNqYAi.strip(),'thumbnail':XQePEDxIrkoVRFTwtBhLOjMmSNqYGA,'synopsis':XQePEDxIrkoVRFTwtBhLOjMmSNqYAd}
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJK)
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
 def GetMovieGenre(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ=[]
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAG=XQePEDxIrkoVRFTwtBhLOjMmSNqYzy
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='/v2/media/movie/curations'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetDefaultParams()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcb={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetNoCache(2))}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd.update(XQePEDxIrkoVRFTwtBhLOjMmSNqYcb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.API_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYci
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYcd,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcH=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   if not('result' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']):return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAU=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['result']
   for XQePEDxIrkoVRFTwtBhLOjMmSNqYcv in XQePEDxIrkoVRFTwtBhLOjMmSNqYAU:
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGJ =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['curation_code']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGz =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['curation_name']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYJK={'curation_code':XQePEDxIrkoVRFTwtBhLOjMmSNqYGJ,'curation_name':XQePEDxIrkoVRFTwtBhLOjMmSNqYGz}
    XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJK)
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
 def GetSearchList(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,search_key,page_int,stype):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYGf=[]
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAG=XQePEDxIrkoVRFTwtBhLOjMmSNqYzy
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='/search/getSearch.jsp'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcb={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(page_int),'pageSize':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.SCREENCODE,'os':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.OSCODE,'network':XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetNoCache(2))}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.SEARCH_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYci
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYcb,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcH=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   if stype=='vod':
    if not('programRsb' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcH):return XQePEDxIrkoVRFTwtBhLOjMmSNqYGf,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGU=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['programRsb']['dataList']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGK =XQePEDxIrkoVRFTwtBhLOjMmSNqYzH(XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['programRsb']['count'])
    for XQePEDxIrkoVRFTwtBhLOjMmSNqYcv in XQePEDxIrkoVRFTwtBhLOjMmSNqYGU:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJu=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['mast_cd']
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAi =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['mast_nm']
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAy=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['web_url4']
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['web_url']
     try:
      XQePEDxIrkoVRFTwtBhLOjMmSNqYAs =[]
      XQePEDxIrkoVRFTwtBhLOjMmSNqYAv=[]
      XQePEDxIrkoVRFTwtBhLOjMmSNqYAp =[]
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJp =0
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJc =''
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJa =''
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJg =''
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('actor') !='' and XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('actor') !='-':XQePEDxIrkoVRFTwtBhLOjMmSNqYAs =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('actor').split(',')
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('director')!='' and XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('director')!='-':XQePEDxIrkoVRFTwtBhLOjMmSNqYAv=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('director').split(',')
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('cate_nm')!='' and XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('cate_nm')!='-':XQePEDxIrkoVRFTwtBhLOjMmSNqYAp =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('cate_nm').split('/')
      if 'targetage' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv:XQePEDxIrkoVRFTwtBhLOjMmSNqYJc=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('targetage')
      if 'broad_dt' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv:
       XQePEDxIrkoVRFTwtBhLOjMmSNqYJf=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('broad_dt')
       XQePEDxIrkoVRFTwtBhLOjMmSNqYJg='%s-%s-%s'%(XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[:4],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[4:6],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[6:])
       XQePEDxIrkoVRFTwtBhLOjMmSNqYJa =XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[:4]
     except:
      XQePEDxIrkoVRFTwtBhLOjMmSNqYzb
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJK={'program':XQePEDxIrkoVRFTwtBhLOjMmSNqYJu,'title':XQePEDxIrkoVRFTwtBhLOjMmSNqYAi,'thumbnail':{'poster':XQePEDxIrkoVRFTwtBhLOjMmSNqYAy,'thumb':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb,'fanart':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb},'synopsis':'','cast':XQePEDxIrkoVRFTwtBhLOjMmSNqYAs,'director':XQePEDxIrkoVRFTwtBhLOjMmSNqYAv,'info_genre':XQePEDxIrkoVRFTwtBhLOjMmSNqYAp,'duration':XQePEDxIrkoVRFTwtBhLOjMmSNqYJp,'mpaa':XQePEDxIrkoVRFTwtBhLOjMmSNqYJc,'year':XQePEDxIrkoVRFTwtBhLOjMmSNqYJa,'aired':XQePEDxIrkoVRFTwtBhLOjMmSNqYJg}
     XQePEDxIrkoVRFTwtBhLOjMmSNqYGf.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJK)
   else:
    if not('vodMVRsb' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcH):return XQePEDxIrkoVRFTwtBhLOjMmSNqYGf,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGu=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['vodMVRsb']['dataList']
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGK =XQePEDxIrkoVRFTwtBhLOjMmSNqYzH(XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['vodMVRsb']['count'])
    for XQePEDxIrkoVRFTwtBhLOjMmSNqYcv in XQePEDxIrkoVRFTwtBhLOjMmSNqYGu:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJu=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['mast_cd']
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAi =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['mast_nm'].strip()
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAy =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['web_url']
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =XQePEDxIrkoVRFTwtBhLOjMmSNqYAy
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAH=''
     try:
      XQePEDxIrkoVRFTwtBhLOjMmSNqYAs =[]
      XQePEDxIrkoVRFTwtBhLOjMmSNqYAv=[]
      XQePEDxIrkoVRFTwtBhLOjMmSNqYAp =[]
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJp =0
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJc =''
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJa =''
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJg =''
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('actor') !='' and XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('actor') !='-':XQePEDxIrkoVRFTwtBhLOjMmSNqYAs =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('actor').split(',')
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('director')!='' and XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('director')!='-':XQePEDxIrkoVRFTwtBhLOjMmSNqYAv=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('director').split(',')
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('cate_nm')!='' and XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('cate_nm')!='-':XQePEDxIrkoVRFTwtBhLOjMmSNqYAp =XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('cate_nm').split('/')
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('runtime_sec')!='':XQePEDxIrkoVRFTwtBhLOjMmSNqYJp=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('runtime_sec')
      if 'grade_nm' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv:XQePEDxIrkoVRFTwtBhLOjMmSNqYJc=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('grade_nm')
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJf=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('broad_dt')
      if data_str!='':
       XQePEDxIrkoVRFTwtBhLOjMmSNqYJg='%s-%s-%s'%(XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[:4],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[4:6],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[6:])
       XQePEDxIrkoVRFTwtBhLOjMmSNqYJa =XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[:4]
     except:
      XQePEDxIrkoVRFTwtBhLOjMmSNqYzb
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJK={'movie':XQePEDxIrkoVRFTwtBhLOjMmSNqYJu,'title':XQePEDxIrkoVRFTwtBhLOjMmSNqYAi,'thumbnail':{'poster':XQePEDxIrkoVRFTwtBhLOjMmSNqYAy,'thumb':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb,'fanart':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb,'clearlogo':XQePEDxIrkoVRFTwtBhLOjMmSNqYAH},'synopsis':'','cast':XQePEDxIrkoVRFTwtBhLOjMmSNqYAs,'director':XQePEDxIrkoVRFTwtBhLOjMmSNqYAv,'info_genre':XQePEDxIrkoVRFTwtBhLOjMmSNqYAp,'duration':XQePEDxIrkoVRFTwtBhLOjMmSNqYJp,'mpaa':XQePEDxIrkoVRFTwtBhLOjMmSNqYJc,'year':XQePEDxIrkoVRFTwtBhLOjMmSNqYJa,'aired':XQePEDxIrkoVRFTwtBhLOjMmSNqYJg}
     XQePEDxIrkoVRFTwtBhLOjMmSNqYGa=XQePEDxIrkoVRFTwtBhLOjMmSNqYzy
     for XQePEDxIrkoVRFTwtBhLOjMmSNqYGc in XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['bill']:
      if XQePEDxIrkoVRFTwtBhLOjMmSNqYGc in XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.MOVIE_LITE:
       XQePEDxIrkoVRFTwtBhLOjMmSNqYGa=XQePEDxIrkoVRFTwtBhLOjMmSNqYzW
       break
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYGa==XQePEDxIrkoVRFTwtBhLOjMmSNqYzy: 
      XQePEDxIrkoVRFTwtBhLOjMmSNqYJK['title']=XQePEDxIrkoVRFTwtBhLOjMmSNqYJK['title']+' [개별구매]'
     XQePEDxIrkoVRFTwtBhLOjMmSNqYGf.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJK)
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYGK>(page_int*XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.SEARCH_LIMIT):XQePEDxIrkoVRFTwtBhLOjMmSNqYAG=XQePEDxIrkoVRFTwtBhLOjMmSNqYzW
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYGf,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
 def GetDeviceList(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,XQePEDxIrkoVRFTwtBhLOjMmSNqYca,XQePEDxIrkoVRFTwtBhLOjMmSNqYcA):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ=[]
  XQePEDxIrkoVRFTwtBhLOjMmSNqYcK='-'
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='/v1/user/device/list'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGl=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.API_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYci
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcb={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYaU=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.makeDefaultCookies(vToken=XQePEDxIrkoVRFTwtBhLOjMmSNqYca,vUserinfo=XQePEDxIrkoVRFTwtBhLOjMmSNqYcA)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYGl,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYcb,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYaU)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcH=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(XQePEDxIrkoVRFTwtBhLOjMmSNqYcH)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']
   for XQePEDxIrkoVRFTwtBhLOjMmSNqYcv in XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ:
    if XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['model']=='PC' or XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['model']=='PC-Chrome':
     XQePEDxIrkoVRFTwtBhLOjMmSNqYcK=XQePEDxIrkoVRFTwtBhLOjMmSNqYcv['uuid']
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYcK
 def GetProfileToken(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,XQePEDxIrkoVRFTwtBhLOjMmSNqYca,XQePEDxIrkoVRFTwtBhLOjMmSNqYcA,user_pf):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYGi=[]
  XQePEDxIrkoVRFTwtBhLOjMmSNqYGd =''
  XQePEDxIrkoVRFTwtBhLOjMmSNqYGb =''
  XQePEDxIrkoVRFTwtBhLOjMmSNqYGy='Y'
  XQePEDxIrkoVRFTwtBhLOjMmSNqYGH ='N'
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYaU=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.makeDefaultCookies(vToken=XQePEDxIrkoVRFTwtBhLOjMmSNqYca,vUserinfo=XQePEDxIrkoVRFTwtBhLOjMmSNqYcA)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYci,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYaU)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGi =re.findall('data-profile-no="\d+"',XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   for i in XQePEDxIrkoVRFTwtBhLOjMmSNqYzC(XQePEDxIrkoVRFTwtBhLOjMmSNqYzp(XQePEDxIrkoVRFTwtBhLOjMmSNqYGi)):
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGC =XQePEDxIrkoVRFTwtBhLOjMmSNqYGi[i].replace('data-profile-no=','').replace('"','')
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGi[i]=XQePEDxIrkoVRFTwtBhLOjMmSNqYGC
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGd=XQePEDxIrkoVRFTwtBhLOjMmSNqYGi[user_pf]
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
   return XQePEDxIrkoVRFTwtBhLOjMmSNqYGb,XQePEDxIrkoVRFTwtBhLOjMmSNqYGy,XQePEDxIrkoVRFTwtBhLOjMmSNqYGH
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYaU=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.makeDefaultCookies(vToken=XQePEDxIrkoVRFTwtBhLOjMmSNqYca,vUserinfo=XQePEDxIrkoVRFTwtBhLOjMmSNqYcA)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYas={'profileNo':XQePEDxIrkoVRFTwtBhLOjMmSNqYGd}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Post',XQePEDxIrkoVRFTwtBhLOjMmSNqYci,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYas,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYaU)
   for XQePEDxIrkoVRFTwtBhLOjMmSNqYap in XQePEDxIrkoVRFTwtBhLOjMmSNqYav.cookies:
    if XQePEDxIrkoVRFTwtBhLOjMmSNqYap.name=='_tving_token':
     XQePEDxIrkoVRFTwtBhLOjMmSNqYGb=XQePEDxIrkoVRFTwtBhLOjMmSNqYap.value
    elif XQePEDxIrkoVRFTwtBhLOjMmSNqYap.name==XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GLOBAL_COOKIENM['tv_cookiekey']:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYGy=XQePEDxIrkoVRFTwtBhLOjMmSNqYap.value
    elif XQePEDxIrkoVRFTwtBhLOjMmSNqYap.name==XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GLOBAL_COOKIENM['tv_lockkey']:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYGH=XQePEDxIrkoVRFTwtBhLOjMmSNqYap.value
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYGb,XQePEDxIrkoVRFTwtBhLOjMmSNqYGy,XQePEDxIrkoVRFTwtBhLOjMmSNqYGH
 def GetProfileLockYN(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,XQePEDxIrkoVRFTwtBhLOjMmSNqYca,XQePEDxIrkoVRFTwtBhLOjMmSNqYcA):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYGi=[]
  XQePEDxIrkoVRFTwtBhLOjMmSNqYGH ='N'
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='/profile/select.do'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGl=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.URL_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYci
   XQePEDxIrkoVRFTwtBhLOjMmSNqYaU=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.makeDefaultCookies(vToken=XQePEDxIrkoVRFTwtBhLOjMmSNqYca,vUserinfo=XQePEDxIrkoVRFTwtBhLOjMmSNqYcA)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYGl,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYaU)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGi =re.findall('data-profile-no="\d+"',XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   for i in XQePEDxIrkoVRFTwtBhLOjMmSNqYzC(XQePEDxIrkoVRFTwtBhLOjMmSNqYzp(XQePEDxIrkoVRFTwtBhLOjMmSNqYGi)):
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGC =XQePEDxIrkoVRFTwtBhLOjMmSNqYGi[i].replace('data-profile-no=','').replace('"','')
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGi[i]=XQePEDxIrkoVRFTwtBhLOjMmSNqYGC
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
   return XQePEDxIrkoVRFTwtBhLOjMmSNqYGH
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='/profile/api/select.do'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGl=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.URL_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYci
   XQePEDxIrkoVRFTwtBhLOjMmSNqYaU=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.makeDefaultCookies(vToken=XQePEDxIrkoVRFTwtBhLOjMmSNqYca,vUserinfo=XQePEDxIrkoVRFTwtBhLOjMmSNqYcA)
   for i in XQePEDxIrkoVRFTwtBhLOjMmSNqYzC(XQePEDxIrkoVRFTwtBhLOjMmSNqYzp(XQePEDxIrkoVRFTwtBhLOjMmSNqYGi)):
    XQePEDxIrkoVRFTwtBhLOjMmSNqYas={'profileNo':XQePEDxIrkoVRFTwtBhLOjMmSNqYGi[i]}
    XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Post',XQePEDxIrkoVRFTwtBhLOjMmSNqYGl,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYas,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYaU)
    for XQePEDxIrkoVRFTwtBhLOjMmSNqYap in XQePEDxIrkoVRFTwtBhLOjMmSNqYav.cookies:
     if XQePEDxIrkoVRFTwtBhLOjMmSNqYap.name=='_tving_token':
      XQePEDxIrkoVRFTwtBhLOjMmSNqYGW=XQePEDxIrkoVRFTwtBhLOjMmSNqYap.value
     elif XQePEDxIrkoVRFTwtBhLOjMmSNqYap.name==XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GLOBAL_COOKIENM['tv_lockkey']:
      XQePEDxIrkoVRFTwtBhLOjMmSNqYGn=XQePEDxIrkoVRFTwtBhLOjMmSNqYap.value
    if XQePEDxIrkoVRFTwtBhLOjMmSNqYGW==XQePEDxIrkoVRFTwtBhLOjMmSNqYca:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYGH=XQePEDxIrkoVRFTwtBhLOjMmSNqYGn
     XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(XQePEDxIrkoVRFTwtBhLOjMmSNqYca)
     break
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYGH
 def GetBookmarkInfo(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,videoid,vidtype):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYGg={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.API_DOMAIN+'/v2/media/program/'+videoid
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetDefaultParams()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcb={'pageNo':'1','pageSize':'10','order':'name',}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd.update(XQePEDxIrkoVRFTwtBhLOjMmSNqYcb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYcd,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGs=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   if not('body' in XQePEDxIrkoVRFTwtBhLOjMmSNqYGs):return{}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGv=XQePEDxIrkoVRFTwtBhLOjMmSNqYGs['body']
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAi=XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('name').get('ko').strip()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['title'] =XQePEDxIrkoVRFTwtBhLOjMmSNqYAi
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['title']=XQePEDxIrkoVRFTwtBhLOjMmSNqYAi
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['mpaa'] =XQePEDxIrkoVRFTwtBhLOjMmSNqYaJ.get(XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('grade_code'))
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['plot'] =XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('synopsis').get('ko')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['year'] =XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('product_year')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['cast'] =XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('actor')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['director']=XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('director')
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('category1_name').get('ko')!='':
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['genre'].append(XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('category1_name').get('ko'))
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('category2_name').get('ko')!='':
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['genre'].append(XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('category2_name').get('ko'))
   XQePEDxIrkoVRFTwtBhLOjMmSNqYJf=XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('broad_dt'))
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYJf!='0':XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[:4],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[4:6],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[6:])
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAy =''
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =''
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAH=''
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAC =''
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAW =''
   for XQePEDxIrkoVRFTwtBhLOjMmSNqYAg in XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('image'):
    if XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('code')=='CAIP0900':XQePEDxIrkoVRFTwtBhLOjMmSNqYAy =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('url')
    elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('code')=='CAIP0200':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('url')
    elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('code')=='CAIP1800':XQePEDxIrkoVRFTwtBhLOjMmSNqYAH=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('url')
    elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('code')=='CAIP2000':XQePEDxIrkoVRFTwtBhLOjMmSNqYAC =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('url')
    elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('code')=='CAIP1900':XQePEDxIrkoVRFTwtBhLOjMmSNqYAW =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('url')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['thumbnail']['poster']=XQePEDxIrkoVRFTwtBhLOjMmSNqYAy
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['thumbnail']['thumb']=XQePEDxIrkoVRFTwtBhLOjMmSNqYAb
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['thumbnail']['clearlogo']=XQePEDxIrkoVRFTwtBhLOjMmSNqYAH
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['thumbnail']['icon']=XQePEDxIrkoVRFTwtBhLOjMmSNqYAC
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['thumbnail']['banner']=XQePEDxIrkoVRFTwtBhLOjMmSNqYAW
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['thumbnail']['fanart']=XQePEDxIrkoVRFTwtBhLOjMmSNqYAb
  else:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.API_DOMAIN+'/v2a/media/stream/info'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetDefaultParams()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcb={'info':'Y','mediaCode':videoid,'noCache':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':'','uuid':'','deviceInfo':'PC','wm':'Y',}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd.update(XQePEDxIrkoVRFTwtBhLOjMmSNqYcb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYcd,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGs=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   if not('content' in XQePEDxIrkoVRFTwtBhLOjMmSNqYGs['body']):return{}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGv=XQePEDxIrkoVRFTwtBhLOjMmSNqYGs['body']['content']['info']['movie']
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAi =XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('name').get('ko').strip()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['title']=XQePEDxIrkoVRFTwtBhLOjMmSNqYAi
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAi +=u' (%s)'%(XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('product_year'))
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['title'] =XQePEDxIrkoVRFTwtBhLOjMmSNqYAi
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['mpaa'] =XQePEDxIrkoVRFTwtBhLOjMmSNqYaJ.get(XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('grade_code'))
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['plot'] =XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('story').get('ko')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['year'] =XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('product_year')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['studio'] =XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('production')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['duration']=XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('duration')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['cast'] =XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('actor')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['director']=XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('director')
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('category1_name').get('ko')!='':
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['genre'].append(XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('category1_name').get('ko'))
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('category2_name').get('ko')!='':
    XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['genre'].append(XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('category2_name').get('ko'))
   XQePEDxIrkoVRFTwtBhLOjMmSNqYJf=XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('release_date'))
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYJf!='0':XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[:4],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[4:6],XQePEDxIrkoVRFTwtBhLOjMmSNqYJf[6:])
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAy=''
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =''
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAH=''
   for XQePEDxIrkoVRFTwtBhLOjMmSNqYAg in XQePEDxIrkoVRFTwtBhLOjMmSNqYGv.get('image'):
    if XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('code')=='CAIM2100':XQePEDxIrkoVRFTwtBhLOjMmSNqYAy =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('url')
    elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('code')=='CAIM0400':XQePEDxIrkoVRFTwtBhLOjMmSNqYAb =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('url')
    elif XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('code')=='CAIM1800':XQePEDxIrkoVRFTwtBhLOjMmSNqYAH=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.IMG_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYAg.get('url')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['thumbnail']['poster']=XQePEDxIrkoVRFTwtBhLOjMmSNqYAy
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['thumbnail']['thumb']=XQePEDxIrkoVRFTwtBhLOjMmSNqYAy 
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['thumbnail']['clearlogo']=XQePEDxIrkoVRFTwtBhLOjMmSNqYAH
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGg['saveinfo']['thumbnail']['fanart']=XQePEDxIrkoVRFTwtBhLOjMmSNqYAb
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYGg
 def GetEuroChannelList(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ=[]
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYci ='/v2/operator/highlights'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetDefaultParams()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcb={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':XQePEDxIrkoVRFTwtBhLOjMmSNqYzs(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.GetNoCache(2))}
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcd.update(XQePEDxIrkoVRFTwtBhLOjMmSNqYcb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.API_DOMAIN+XQePEDxIrkoVRFTwtBhLOjMmSNqYci
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYcd,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcH=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   if not('result' in XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']):return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ,XQePEDxIrkoVRFTwtBhLOjMmSNqYAG
   XQePEDxIrkoVRFTwtBhLOjMmSNqYAU=XQePEDxIrkoVRFTwtBhLOjMmSNqYcH['body']['result']
   XQePEDxIrkoVRFTwtBhLOjMmSNqYGp =XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.Get_Now_Datetime()
   XQePEDxIrkoVRFTwtBhLOjMmSNqYza=XQePEDxIrkoVRFTwtBhLOjMmSNqYGp+datetime.timedelta(days=-1)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYza=XQePEDxIrkoVRFTwtBhLOjMmSNqYzH(XQePEDxIrkoVRFTwtBhLOjMmSNqYza.strftime('%Y%m%d'))
   for XQePEDxIrkoVRFTwtBhLOjMmSNqYcv in XQePEDxIrkoVRFTwtBhLOjMmSNqYAU:
    XQePEDxIrkoVRFTwtBhLOjMmSNqYzc=XQePEDxIrkoVRFTwtBhLOjMmSNqYzH(XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('content').get('banner_title2')[:8])
    if XQePEDxIrkoVRFTwtBhLOjMmSNqYza<=XQePEDxIrkoVRFTwtBhLOjMmSNqYzc:
     XQePEDxIrkoVRFTwtBhLOjMmSNqYJK={'channel':XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('content').get('banner_sub_title3'),'title':XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('content').get('banner_title'),'subtitle':XQePEDxIrkoVRFTwtBhLOjMmSNqYcv.get('content').get('banner_sub_title2'),}
     XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ.append(XQePEDxIrkoVRFTwtBhLOjMmSNqYJK)
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYAJ
 def Make_DecryptKey(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,step,mediacode='000',timecode='000'):
  if step=='1':
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzA=XQePEDxIrkoVRFTwtBhLOjMmSNqYfa('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzJ=XQePEDxIrkoVRFTwtBhLOjMmSNqYfa('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzA=XQePEDxIrkoVRFTwtBhLOjMmSNqYfa('kss2lym0kdw1lks3','utf-8')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzJ=XQePEDxIrkoVRFTwtBhLOjMmSNqYfa([XQePEDxIrkoVRFTwtBhLOjMmSNqYfc('*'),0x07,XQePEDxIrkoVRFTwtBhLOjMmSNqYfc('r'),XQePEDxIrkoVRFTwtBhLOjMmSNqYfc(';'),XQePEDxIrkoVRFTwtBhLOjMmSNqYfc('7'),0x05,0x1e,0x01,XQePEDxIrkoVRFTwtBhLOjMmSNqYfc('n'),XQePEDxIrkoVRFTwtBhLOjMmSNqYfc('D'),0x02,XQePEDxIrkoVRFTwtBhLOjMmSNqYfc('3'),XQePEDxIrkoVRFTwtBhLOjMmSNqYfc('*'),XQePEDxIrkoVRFTwtBhLOjMmSNqYfc('a'),XQePEDxIrkoVRFTwtBhLOjMmSNqYfc('&'),XQePEDxIrkoVRFTwtBhLOjMmSNqYfc('<')])
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYzA,XQePEDxIrkoVRFTwtBhLOjMmSNqYzJ
 def DecryptPlaintext(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,ciphertext,encryption_key,init_vector):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYzG=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  XQePEDxIrkoVRFTwtBhLOjMmSNqYzf=Padding.unpad(XQePEDxIrkoVRFTwtBhLOjMmSNqYzG.decrypt(base64.standard_b64decode(ciphertext)),16)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYzf.decode('utf-8')
 def Decrypt_Url(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG,ciphertext,mediacode,XQePEDxIrkoVRFTwtBhLOjMmSNqYcl):
  XQePEDxIrkoVRFTwtBhLOjMmSNqYzU=''
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzA,XQePEDxIrkoVRFTwtBhLOjMmSNqYzJ=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.Make_DecryptKey('1',mediacode=mediacode,timecode=XQePEDxIrkoVRFTwtBhLOjMmSNqYcl)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzK=json.loads(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.DecryptPlaintext(ciphertext,XQePEDxIrkoVRFTwtBhLOjMmSNqYzA,XQePEDxIrkoVRFTwtBhLOjMmSNqYzJ)).get('broad_url')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzA,XQePEDxIrkoVRFTwtBhLOjMmSNqYzJ=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.Make_DecryptKey('2')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzU=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.DecryptPlaintext(XQePEDxIrkoVRFTwtBhLOjMmSNqYzK,XQePEDxIrkoVRFTwtBhLOjMmSNqYzA,XQePEDxIrkoVRFTwtBhLOjMmSNqYzJ)
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYzU
 def Get_Naver_Login(XQePEDxIrkoVRFTwtBhLOjMmSNqYaG):
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy='https://user.tving.com/oauth/oauthLogin.tving?target=naver&from=pc&rtUrl=https://user.tving.com/pc/user/login.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fmain.do%3FretRef%3DY%26source%3Dhttps%3A%2F%2Fwww.google.com%2F&csite=&isAuto=false'
   XQePEDxIrkoVRFTwtBhLOjMmSNqYav=XQePEDxIrkoVRFTwtBhLOjMmSNqYaG.callRequestCookies('Get',XQePEDxIrkoVRFTwtBhLOjMmSNqYcy,payload=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,params=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,headers=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb,cookies=XQePEDxIrkoVRFTwtBhLOjMmSNqYzb)
   if XQePEDxIrkoVRFTwtBhLOjMmSNqYav.status_code!=200:return XQePEDxIrkoVRFTwtBhLOjMmSNqYzy
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzu=re.findall('\'https://nid.naver.com/(?:[a-zA-Z]|[0-9]|[$\-@\.&+:/?=_]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+\'',XQePEDxIrkoVRFTwtBhLOjMmSNqYav.text)
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzl=XQePEDxIrkoVRFTwtBhLOjMmSNqYzu[0].replace('\'','')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(XQePEDxIrkoVRFTwtBhLOjMmSNqYzl)
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn('n login pass1 error')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  try:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYcy=XQePEDxIrkoVRFTwtBhLOjMmSNqYzl
  except XQePEDxIrkoVRFTwtBhLOjMmSNqYzg as exception:
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn('n login pass1 error')
   XQePEDxIrkoVRFTwtBhLOjMmSNqYzn(exception)
  return XQePEDxIrkoVRFTwtBhLOjMmSNqYzW
# Created by pyminifier (https://github.com/liftoff/pyminifier)
