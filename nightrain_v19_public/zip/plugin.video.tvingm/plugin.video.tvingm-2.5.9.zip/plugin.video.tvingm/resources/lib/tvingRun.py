__author__="NightRain"
ApTWbJvUeRyQjiwtGDNECnuxFcMfsq=object
ApTWbJvUeRyQjiwtGDNECnuxFcMfsa=None
ApTWbJvUeRyQjiwtGDNECnuxFcMfsg=int
ApTWbJvUeRyQjiwtGDNECnuxFcMfsL=True
ApTWbJvUeRyQjiwtGDNECnuxFcMfsS=False
ApTWbJvUeRyQjiwtGDNECnuxFcMfmH=type
ApTWbJvUeRyQjiwtGDNECnuxFcMfmk=dict
ApTWbJvUeRyQjiwtGDNECnuxFcMfmO=getattr
ApTWbJvUeRyQjiwtGDNECnuxFcMfmh=list
ApTWbJvUeRyQjiwtGDNECnuxFcMfmI=len
ApTWbJvUeRyQjiwtGDNECnuxFcMfmX=str
ApTWbJvUeRyQjiwtGDNECnuxFcMfmY=range
ApTWbJvUeRyQjiwtGDNECnuxFcMfms=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
ApTWbJvUeRyQjiwtGDNECnuxFcMfHO=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
ApTWbJvUeRyQjiwtGDNECnuxFcMfHh=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
ApTWbJvUeRyQjiwtGDNECnuxFcMfHI=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
ApTWbJvUeRyQjiwtGDNECnuxFcMfHX=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
ApTWbJvUeRyQjiwtGDNECnuxFcMfHY=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
ApTWbJvUeRyQjiwtGDNECnuxFcMfHs=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
ApTWbJvUeRyQjiwtGDNECnuxFcMfHm=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
ApTWbJvUeRyQjiwtGDNECnuxFcMfHK={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
ApTWbJvUeRyQjiwtGDNECnuxFcMfHB =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
ApTWbJvUeRyQjiwtGDNECnuxFcMfHz=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class ApTWbJvUeRyQjiwtGDNECnuxFcMfHk(ApTWbJvUeRyQjiwtGDNECnuxFcMfsq):
 def __init__(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfHd,ApTWbJvUeRyQjiwtGDNECnuxFcMfHr,ApTWbJvUeRyQjiwtGDNECnuxFcMfHl):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_url =ApTWbJvUeRyQjiwtGDNECnuxFcMfHd
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle=ApTWbJvUeRyQjiwtGDNECnuxFcMfHr
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params =ApTWbJvUeRyQjiwtGDNECnuxFcMfHl
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj =iQUMlausXwdvtNjnFSBJPbKzEhoOkV() 
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,sting):
  try:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHo=xbmcgui.Dialog()
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHo.notification(__addonname__,sting)
  except:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
 def addon_log(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,string):
  try:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHq=string.encode('utf-8','ignore')
  except:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHq='addonException: addon_log'
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHa=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,ApTWbJvUeRyQjiwtGDNECnuxFcMfHq),level=ApTWbJvUeRyQjiwtGDNECnuxFcMfHa)
 def get_keyboard_input(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfkl):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHg=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
  kb=xbmc.Keyboard()
  kb.setHeading(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHg=kb.getText()
  return ApTWbJvUeRyQjiwtGDNECnuxFcMfHg
 def get_settings_account(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHL =__addon__.getSetting('id')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHS =__addon__.getSetting('pw')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkH =__addon__.getSetting('login_type')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkO=ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(__addon__.getSetting('selected_profile'))
  return(ApTWbJvUeRyQjiwtGDNECnuxFcMfHL,ApTWbJvUeRyQjiwtGDNECnuxFcMfHS,ApTWbJvUeRyQjiwtGDNECnuxFcMfkH,ApTWbJvUeRyQjiwtGDNECnuxFcMfkO)
 def get_settings_uhd(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  return ApTWbJvUeRyQjiwtGDNECnuxFcMfsL if __addon__.getSetting('active_uhd')=='true' else ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
 def get_settings_playback(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkh={'active_uhd':ApTWbJvUeRyQjiwtGDNECnuxFcMfsL if __addon__.getSetting('active_uhd')=='true' else ApTWbJvUeRyQjiwtGDNECnuxFcMfsS,'streamFilename':ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.TV_STREAM_FILENAME,}
  return ApTWbJvUeRyQjiwtGDNECnuxFcMfkh
 def get_settings_proxyport(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkI =ApTWbJvUeRyQjiwtGDNECnuxFcMfsL if __addon__.getSetting('proxyYn')=='true' else ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkX=ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(__addon__.getSetting('proxyPort'))
  return ApTWbJvUeRyQjiwtGDNECnuxFcMfkI,ApTWbJvUeRyQjiwtGDNECnuxFcMfkX
 def get_settings_totalsearch(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkY =ApTWbJvUeRyQjiwtGDNECnuxFcMfsL if __addon__.getSetting('local_search')=='true' else ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
  ApTWbJvUeRyQjiwtGDNECnuxFcMfks=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL if __addon__.getSetting('local_history')=='true' else ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkm =ApTWbJvUeRyQjiwtGDNECnuxFcMfsL if __addon__.getSetting('total_search')=='true' else ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkK=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL if __addon__.getSetting('total_history')=='true' else ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkB=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL if __addon__.getSetting('menu_bookmark')=='true' else ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
  return(ApTWbJvUeRyQjiwtGDNECnuxFcMfkY,ApTWbJvUeRyQjiwtGDNECnuxFcMfks,ApTWbJvUeRyQjiwtGDNECnuxFcMfkm,ApTWbJvUeRyQjiwtGDNECnuxFcMfkK,ApTWbJvUeRyQjiwtGDNECnuxFcMfkB)
 def get_settings_makebookmark(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  return ApTWbJvUeRyQjiwtGDNECnuxFcMfsL if __addon__.getSetting('make_bookmark')=='true' else ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
 def get_settings_direct_replay(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkz=ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(__addon__.getSetting('direct_replay'))
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfkz==0:
   return ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
  else:
   return ApTWbJvUeRyQjiwtGDNECnuxFcMfsL
 def set_winEpisodeOrderby(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfkd):
  __addon__.setSetting('tving_orderby',ApTWbJvUeRyQjiwtGDNECnuxFcMfkd)
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkP=xbmcgui.Window(10000)
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkP.setProperty('TVING_M_ORDERBY',ApTWbJvUeRyQjiwtGDNECnuxFcMfkd)
 def get_winEpisodeOrderby(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkd=__addon__.getSetting('tving_orderby')
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfkd in['',ApTWbJvUeRyQjiwtGDNECnuxFcMfsa]:ApTWbJvUeRyQjiwtGDNECnuxFcMfkd='desc'
  return ApTWbJvUeRyQjiwtGDNECnuxFcMfkd
 def add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,label,sublabel='',img='',infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params='',isLink=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS,ContextMenu=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkr='%s?%s'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_url,urllib.parse.urlencode(params))
  if sublabel:ApTWbJvUeRyQjiwtGDNECnuxFcMfkl='%s < %s >'%(label,sublabel)
  else: ApTWbJvUeRyQjiwtGDNECnuxFcMfkl=label
  if not img:img='DefaultFolder.png'
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkV=xbmcgui.ListItem(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfmH(img)==ApTWbJvUeRyQjiwtGDNECnuxFcMfmk:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkV.setArt(img)
  else:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkV.setArt({'thumb':img,'poster':img})
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.KodiVersion>=20:
   if infoLabels:ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.Set_InfoTag(ApTWbJvUeRyQjiwtGDNECnuxFcMfkV.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:ApTWbJvUeRyQjiwtGDNECnuxFcMfkV.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkV.setProperty('IsPlayable','true')
  if ContextMenu:ApTWbJvUeRyQjiwtGDNECnuxFcMfkV.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,ApTWbJvUeRyQjiwtGDNECnuxFcMfkr,ApTWbJvUeRyQjiwtGDNECnuxFcMfkV,isFolder)
 def get_selQuality(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,etype):
  try:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfko='selected_quality'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkq=[1080,720,480,360]
   ApTWbJvUeRyQjiwtGDNECnuxFcMfka=ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(__addon__.getSetting(ApTWbJvUeRyQjiwtGDNECnuxFcMfko))
   return ApTWbJvUeRyQjiwtGDNECnuxFcMfkq[ApTWbJvUeRyQjiwtGDNECnuxFcMfka]
  except:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
  return 720 
 def Set_InfoTag(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,video_InfoTag:xbmc.InfoTagVideo,ApTWbJvUeRyQjiwtGDNECnuxFcMfOX):
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfkg,value in ApTWbJvUeRyQjiwtGDNECnuxFcMfOX.items():
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfHK[ApTWbJvUeRyQjiwtGDNECnuxFcMfkg]['type']=='string':
    ApTWbJvUeRyQjiwtGDNECnuxFcMfmO(video_InfoTag,ApTWbJvUeRyQjiwtGDNECnuxFcMfHK[ApTWbJvUeRyQjiwtGDNECnuxFcMfkg]['func'])(value)
   elif ApTWbJvUeRyQjiwtGDNECnuxFcMfHK[ApTWbJvUeRyQjiwtGDNECnuxFcMfkg]['type']=='int':
    if ApTWbJvUeRyQjiwtGDNECnuxFcMfmH(value)==ApTWbJvUeRyQjiwtGDNECnuxFcMfsg:
     ApTWbJvUeRyQjiwtGDNECnuxFcMfkL=ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(value)
    else:
     ApTWbJvUeRyQjiwtGDNECnuxFcMfkL=0
    ApTWbJvUeRyQjiwtGDNECnuxFcMfmO(video_InfoTag,ApTWbJvUeRyQjiwtGDNECnuxFcMfHK[ApTWbJvUeRyQjiwtGDNECnuxFcMfkg]['func'])(ApTWbJvUeRyQjiwtGDNECnuxFcMfkL)
   elif ApTWbJvUeRyQjiwtGDNECnuxFcMfHK[ApTWbJvUeRyQjiwtGDNECnuxFcMfkg]['type']=='actor':
    if value!=[]:
     ApTWbJvUeRyQjiwtGDNECnuxFcMfmO(video_InfoTag,ApTWbJvUeRyQjiwtGDNECnuxFcMfHK[ApTWbJvUeRyQjiwtGDNECnuxFcMfkg]['func'])([xbmc.Actor(name)for name in value])
   elif ApTWbJvUeRyQjiwtGDNECnuxFcMfHK[ApTWbJvUeRyQjiwtGDNECnuxFcMfkg]['type']=='list':
    if ApTWbJvUeRyQjiwtGDNECnuxFcMfmH(value)==ApTWbJvUeRyQjiwtGDNECnuxFcMfmh:
     ApTWbJvUeRyQjiwtGDNECnuxFcMfmO(video_InfoTag,ApTWbJvUeRyQjiwtGDNECnuxFcMfHK[ApTWbJvUeRyQjiwtGDNECnuxFcMfkg]['func'])(value)
    else:
     ApTWbJvUeRyQjiwtGDNECnuxFcMfmO(video_InfoTag,ApTWbJvUeRyQjiwtGDNECnuxFcMfHK[ApTWbJvUeRyQjiwtGDNECnuxFcMfkg]['func'])([value])
 def dp_Main_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  (ApTWbJvUeRyQjiwtGDNECnuxFcMfkY,ApTWbJvUeRyQjiwtGDNECnuxFcMfks,ApTWbJvUeRyQjiwtGDNECnuxFcMfkm,ApTWbJvUeRyQjiwtGDNECnuxFcMfkK,ApTWbJvUeRyQjiwtGDNECnuxFcMfkB)=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_totalsearch()
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfkS in ApTWbJvUeRyQjiwtGDNECnuxFcMfHO:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl=ApTWbJvUeRyQjiwtGDNECnuxFcMfkS.get('title')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOH=''
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfkS.get('mode')=='SEARCH_GROUP' and ApTWbJvUeRyQjiwtGDNECnuxFcMfkY ==ApTWbJvUeRyQjiwtGDNECnuxFcMfsS:continue
   elif ApTWbJvUeRyQjiwtGDNECnuxFcMfkS.get('mode')=='SEARCH_HISTORY' and ApTWbJvUeRyQjiwtGDNECnuxFcMfks==ApTWbJvUeRyQjiwtGDNECnuxFcMfsS:continue
   elif ApTWbJvUeRyQjiwtGDNECnuxFcMfkS.get('mode')=='TOTAL_SEARCH' and ApTWbJvUeRyQjiwtGDNECnuxFcMfkm ==ApTWbJvUeRyQjiwtGDNECnuxFcMfsS:continue
   elif ApTWbJvUeRyQjiwtGDNECnuxFcMfkS.get('mode')=='TOTAL_HISTORY' and ApTWbJvUeRyQjiwtGDNECnuxFcMfkK==ApTWbJvUeRyQjiwtGDNECnuxFcMfsS:continue
   elif ApTWbJvUeRyQjiwtGDNECnuxFcMfkS.get('mode')=='MENU_BOOKMARK' and ApTWbJvUeRyQjiwtGDNECnuxFcMfkB==ApTWbJvUeRyQjiwtGDNECnuxFcMfsS:continue
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':ApTWbJvUeRyQjiwtGDNECnuxFcMfkS.get('mode'),'stype':ApTWbJvUeRyQjiwtGDNECnuxFcMfkS.get('stype'),'orderby':ApTWbJvUeRyQjiwtGDNECnuxFcMfkS.get('orderby'),'ordernm':ApTWbJvUeRyQjiwtGDNECnuxFcMfkS.get('ordernm'),'page':'1'}
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfkS.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOh=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOI =ApTWbJvUeRyQjiwtGDNECnuxFcMfsL
   else:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOh=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOI =ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOX={'title':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'plot':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl}
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfkS.get('mode')=='XXX':ApTWbJvUeRyQjiwtGDNECnuxFcMfOX=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
   if 'icon' in ApTWbJvUeRyQjiwtGDNECnuxFcMfkS:ApTWbJvUeRyQjiwtGDNECnuxFcMfOH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',ApTWbJvUeRyQjiwtGDNECnuxFcMfkS.get('icon')) 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel='',img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOH,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfOX,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfOh,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk,isLink=ApTWbJvUeRyQjiwtGDNECnuxFcMfOI)
  xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle)
 def login_main(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  (ApTWbJvUeRyQjiwtGDNECnuxFcMfOs,ApTWbJvUeRyQjiwtGDNECnuxFcMfOm,ApTWbJvUeRyQjiwtGDNECnuxFcMfOK,ApTWbJvUeRyQjiwtGDNECnuxFcMfOB)=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_account()
  if not(ApTWbJvUeRyQjiwtGDNECnuxFcMfOs and ApTWbJvUeRyQjiwtGDNECnuxFcMfOm):
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHo=xbmcgui.Dialog()
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOz=ApTWbJvUeRyQjiwtGDNECnuxFcMfHo.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfOz==ApTWbJvUeRyQjiwtGDNECnuxFcMfsL:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOP=0
   while ApTWbJvUeRyQjiwtGDNECnuxFcMfsL:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOP+=1
    time.sleep(0.05)
    if ApTWbJvUeRyQjiwtGDNECnuxFcMfOP>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOd=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.GetCredential(ApTWbJvUeRyQjiwtGDNECnuxFcMfOs,ApTWbJvUeRyQjiwtGDNECnuxFcMfOm,ApTWbJvUeRyQjiwtGDNECnuxFcMfOK,ApTWbJvUeRyQjiwtGDNECnuxFcMfOB)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOd:ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOd==ApTWbJvUeRyQjiwtGDNECnuxFcMfsS:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOr=ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('stype')
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOr=='live':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOl=ApTWbJvUeRyQjiwtGDNECnuxFcMfHh
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfOr=='vod':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOl=ApTWbJvUeRyQjiwtGDNECnuxFcMfHY
  else:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOl=ApTWbJvUeRyQjiwtGDNECnuxFcMfHs
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfOV in ApTWbJvUeRyQjiwtGDNECnuxFcMfOl:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl=ApTWbJvUeRyQjiwtGDNECnuxFcMfOV.get('title')
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('ordernm')!='-':
    ApTWbJvUeRyQjiwtGDNECnuxFcMfkl+='  ('+ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('ordernm')+')'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':ApTWbJvUeRyQjiwtGDNECnuxFcMfOV.get('mode'),'stype':ApTWbJvUeRyQjiwtGDNECnuxFcMfOV.get('stype'),'orderby':ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('orderby'),'ordernm':ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('ordernm'),'page':'1'}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel='',img='',infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfmI(ApTWbJvUeRyQjiwtGDNECnuxFcMfOl)>0:xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle)
 def dp_SubTitle_Group(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo): 
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfOV in ApTWbJvUeRyQjiwtGDNECnuxFcMfHm:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl=ApTWbJvUeRyQjiwtGDNECnuxFcMfOV.get('title')
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('ordernm')!='-':
    ApTWbJvUeRyQjiwtGDNECnuxFcMfkl+='  ('+ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('ordernm')+')'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':ApTWbJvUeRyQjiwtGDNECnuxFcMfOV.get('mode'),'genreCode':ApTWbJvUeRyQjiwtGDNECnuxFcMfOV.get('genreCode'),'stype':ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('stype'),'orderby':ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('orderby'),'page':'1'}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel='',img='',infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfmI(ApTWbJvUeRyQjiwtGDNECnuxFcMfHm)>0:xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle)
 def dp_LiveChannel_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOr =ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('stype')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOq =ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('page'))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOa,ApTWbJvUeRyQjiwtGDNECnuxFcMfOg=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.GetLiveChannelList(ApTWbJvUeRyQjiwtGDNECnuxFcMfOr,ApTWbJvUeRyQjiwtGDNECnuxFcMfOq)
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfOL in ApTWbJvUeRyQjiwtGDNECnuxFcMfOa:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('title')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOY =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('channel')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOS =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('thumbnail')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhH =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('synopsis')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhk =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('channelepg')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhO =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('cast')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhI =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('director')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhX =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('info_genre')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhY =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('year')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhs =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('mpaa')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhm =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('premiered')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhK={'mediatype':'episode','title':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'studio':ApTWbJvUeRyQjiwtGDNECnuxFcMfOY,'cast':ApTWbJvUeRyQjiwtGDNECnuxFcMfhO,'director':ApTWbJvUeRyQjiwtGDNECnuxFcMfhI,'genre':ApTWbJvUeRyQjiwtGDNECnuxFcMfhX,'plot':'%s\n%s\n%s\n\n%s'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfOY,ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,ApTWbJvUeRyQjiwtGDNECnuxFcMfhk,ApTWbJvUeRyQjiwtGDNECnuxFcMfhH),'year':ApTWbJvUeRyQjiwtGDNECnuxFcMfhY,'mpaa':ApTWbJvUeRyQjiwtGDNECnuxFcMfhs,'premiered':ApTWbJvUeRyQjiwtGDNECnuxFcMfhm}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'LIVE','mediacode':ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('mediacode'),'stype':ApTWbJvUeRyQjiwtGDNECnuxFcMfOr}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfOY,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOS,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfhK,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOg:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['mode']='CHANNEL' 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['stype']=ApTWbJvUeRyQjiwtGDNECnuxFcMfOr 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['page']=ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl='[B]%s >>[/B]'%'다음 페이지'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhB=ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfhB,img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOH,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfmI(ApTWbJvUeRyQjiwtGDNECnuxFcMfOa)>0:xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,cacheToDisc=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS)
 def dp_Program_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfhz =ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('stype')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkd =ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('orderby')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOq =ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('page'))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfhP=ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('genreCode')
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfhP==ApTWbJvUeRyQjiwtGDNECnuxFcMfsa:ApTWbJvUeRyQjiwtGDNECnuxFcMfhP='all'
  ApTWbJvUeRyQjiwtGDNECnuxFcMfhd,ApTWbJvUeRyQjiwtGDNECnuxFcMfOg=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.GetProgramList(ApTWbJvUeRyQjiwtGDNECnuxFcMfhz,ApTWbJvUeRyQjiwtGDNECnuxFcMfkd,ApTWbJvUeRyQjiwtGDNECnuxFcMfOq,ApTWbJvUeRyQjiwtGDNECnuxFcMfhP)
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfhr in ApTWbJvUeRyQjiwtGDNECnuxFcMfhd:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('title')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOS =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('thumbnail')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhH =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('synopsis')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhl =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('channel')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhO =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('cast')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhI =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('director')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhX=ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('info_genre')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhY =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('year')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhm =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('premiered')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhs =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('mpaa')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhK={'mediatype':'tvshow','title':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'studio':ApTWbJvUeRyQjiwtGDNECnuxFcMfhl,'cast':ApTWbJvUeRyQjiwtGDNECnuxFcMfhO,'director':ApTWbJvUeRyQjiwtGDNECnuxFcMfhI,'genre':ApTWbJvUeRyQjiwtGDNECnuxFcMfhX,'year':ApTWbJvUeRyQjiwtGDNECnuxFcMfhY,'premiered':ApTWbJvUeRyQjiwtGDNECnuxFcMfhm,'mpaa':ApTWbJvUeRyQjiwtGDNECnuxFcMfhs,'plot':ApTWbJvUeRyQjiwtGDNECnuxFcMfhH}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'EPISODE','programcode':ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('program'),'page':'1'}
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_makebookmark():
    ApTWbJvUeRyQjiwtGDNECnuxFcMfhV={'videoid':ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('program'),'vidtype':'tvshow','vtitle':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'vsubtitle':ApTWbJvUeRyQjiwtGDNECnuxFcMfhl,}
    ApTWbJvUeRyQjiwtGDNECnuxFcMfho=json.dumps(ApTWbJvUeRyQjiwtGDNECnuxFcMfhV)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfho=urllib.parse.quote(ApTWbJvUeRyQjiwtGDNECnuxFcMfho)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfhq='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfho)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfha=[('(통합) 찜 영상에 추가',ApTWbJvUeRyQjiwtGDNECnuxFcMfhq)]
   else:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfha=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfhl,img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOS,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfhK,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk,ContextMenu=ApTWbJvUeRyQjiwtGDNECnuxFcMfha)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOg:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['mode'] ='PROGRAM' 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['stype'] =ApTWbJvUeRyQjiwtGDNECnuxFcMfhz
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['orderby'] =ApTWbJvUeRyQjiwtGDNECnuxFcMfkd
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['page'] =ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['genreCode']=ApTWbJvUeRyQjiwtGDNECnuxFcMfhP 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl='[B]%s >>[/B]'%'다음 페이지'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhB=ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfhB,img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOH,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  xbmcplugin.setContent(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,cacheToDisc=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS)
 def dp_4K_Program_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOq =ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('page'))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfhd,ApTWbJvUeRyQjiwtGDNECnuxFcMfOg=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Get_UHD_ProgramList(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq)
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfhr in ApTWbJvUeRyQjiwtGDNECnuxFcMfhd:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('title')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOS =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('thumbnail')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhH =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('synopsis')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhl =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('channel')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhO =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('cast')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhI =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('director')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhX=ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('info_genre')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhY =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('year')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhm =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('premiered')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhs =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('mpaa')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhK={'mediatype':'tvshow','title':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'studio':ApTWbJvUeRyQjiwtGDNECnuxFcMfhl,'cast':ApTWbJvUeRyQjiwtGDNECnuxFcMfhO,'director':ApTWbJvUeRyQjiwtGDNECnuxFcMfhI,'genre':ApTWbJvUeRyQjiwtGDNECnuxFcMfhX,'year':ApTWbJvUeRyQjiwtGDNECnuxFcMfhY,'premiered':ApTWbJvUeRyQjiwtGDNECnuxFcMfhm,'mpaa':ApTWbJvUeRyQjiwtGDNECnuxFcMfhs,'plot':ApTWbJvUeRyQjiwtGDNECnuxFcMfhH}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'EPISODE','programcode':ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('program'),'page':'1'}
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_makebookmark():
    ApTWbJvUeRyQjiwtGDNECnuxFcMfhV={'videoid':ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('program'),'vidtype':'tvshow','vtitle':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'vsubtitle':ApTWbJvUeRyQjiwtGDNECnuxFcMfhl,}
    ApTWbJvUeRyQjiwtGDNECnuxFcMfho=json.dumps(ApTWbJvUeRyQjiwtGDNECnuxFcMfhV)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfho=urllib.parse.quote(ApTWbJvUeRyQjiwtGDNECnuxFcMfho)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfhq='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfho)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfha=[('(통합) 찜 영상에 추가',ApTWbJvUeRyQjiwtGDNECnuxFcMfhq)]
   else:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfha=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfhl,img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOS,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfhK,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk,ContextMenu=ApTWbJvUeRyQjiwtGDNECnuxFcMfha)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOg:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['mode'] ='4K_PROGRAM' 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['page'] =ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl='[B]%s >>[/B]'%'다음 페이지'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhB=ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfhB,img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOH,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  xbmcplugin.setContent(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,cacheToDisc=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS)
 def dp_Ori_Program_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOq =ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('page'))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfhd,ApTWbJvUeRyQjiwtGDNECnuxFcMfOg=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Get_Origianl_ProgramList(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq)
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfhr in ApTWbJvUeRyQjiwtGDNECnuxFcMfhd:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('title')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOS =ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('thumbnail')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhK={'mediatype':'tvshow','title':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'EPISODE','programcode':ApTWbJvUeRyQjiwtGDNECnuxFcMfhr.get('program'),'page':'1',}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOS,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfhK,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk,ContextMenu=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOg:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['mode'] ='ORI_PROGRAM' 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['page'] =ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl='[B]%s >>[/B]'%'다음 페이지'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhB=ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfhB,img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOH,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  xbmcplugin.setContent(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,cacheToDisc=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS)
 def dp_Episode_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfhL=ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('programcode')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOq =ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('page'))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfhS,ApTWbJvUeRyQjiwtGDNECnuxFcMfOg,ApTWbJvUeRyQjiwtGDNECnuxFcMfIH=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.GetEpisodeList(ApTWbJvUeRyQjiwtGDNECnuxFcMfhL,ApTWbJvUeRyQjiwtGDNECnuxFcMfOq,orderby=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_winEpisodeOrderby())
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfIk in ApTWbJvUeRyQjiwtGDNECnuxFcMfhS:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl =ApTWbJvUeRyQjiwtGDNECnuxFcMfIk.get('title')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhB =ApTWbJvUeRyQjiwtGDNECnuxFcMfIk.get('subtitle')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOS =ApTWbJvUeRyQjiwtGDNECnuxFcMfIk.get('thumbnail')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhH =ApTWbJvUeRyQjiwtGDNECnuxFcMfIk.get('synopsis')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIO=ApTWbJvUeRyQjiwtGDNECnuxFcMfIk.get('info_title')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIh =ApTWbJvUeRyQjiwtGDNECnuxFcMfIk.get('aired')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIX =ApTWbJvUeRyQjiwtGDNECnuxFcMfIk.get('studio')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIY =ApTWbJvUeRyQjiwtGDNECnuxFcMfIk.get('frequency')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhK={'mediatype':'episode','title':ApTWbJvUeRyQjiwtGDNECnuxFcMfIO,'aired':ApTWbJvUeRyQjiwtGDNECnuxFcMfIh,'studio':ApTWbJvUeRyQjiwtGDNECnuxFcMfIX,'episode':ApTWbJvUeRyQjiwtGDNECnuxFcMfIY,'plot':ApTWbJvUeRyQjiwtGDNECnuxFcMfhH}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'VOD','mediacode':ApTWbJvUeRyQjiwtGDNECnuxFcMfIk.get('episode'),'stype':'vod','programcode':ApTWbJvUeRyQjiwtGDNECnuxFcMfhL,'title':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'thumbnail':ApTWbJvUeRyQjiwtGDNECnuxFcMfOS}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfhB,img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOS,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfhK,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOq==1:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhK={'plot':'정렬순서를 변경합니다.'}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['mode'] ='ORDER_BY' 
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_winEpisodeOrderby()=='desc':
    ApTWbJvUeRyQjiwtGDNECnuxFcMfkl='정렬순서변경 : 최신화부터 -> 1회부터'
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['orderby']='asc'
   else:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfkl='정렬순서변경 : 1회부터 -> 최신화부터'
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['orderby']='desc'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel='',img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOH,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfhK,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk,isLink=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOg:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['mode'] ='EPISODE' 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['programcode']=ApTWbJvUeRyQjiwtGDNECnuxFcMfhL
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['page'] =ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl='[B]%s >>[/B]'%'다음 페이지'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhB=ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfhB,img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOH,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  xbmcplugin.setContent(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,'episodes')
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfmI(ApTWbJvUeRyQjiwtGDNECnuxFcMfhS)>0:xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,cacheToDisc=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL)
 def dp_setEpOrderby(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkd =ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('orderby')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.set_winEpisodeOrderby(ApTWbJvUeRyQjiwtGDNECnuxFcMfkd)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfhz =ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('stype')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkd =ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('orderby')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOq=ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('page'))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIs,ApTWbJvUeRyQjiwtGDNECnuxFcMfOg=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.GetMovieList(ApTWbJvUeRyQjiwtGDNECnuxFcMfhz,ApTWbJvUeRyQjiwtGDNECnuxFcMfkd,ApTWbJvUeRyQjiwtGDNECnuxFcMfOq)
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfIm in ApTWbJvUeRyQjiwtGDNECnuxFcMfIs:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('title')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOS =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('thumbnail')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhH =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('synopsis')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIO =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('info_title')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhY =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('year')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhO =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('cast')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhI =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('director')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhX =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('info_genre')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIK =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('duration')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhm =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('premiered')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIX =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('studio')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhs =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('mpaa')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhK={'mediatype':'movie','title':ApTWbJvUeRyQjiwtGDNECnuxFcMfIO,'year':ApTWbJvUeRyQjiwtGDNECnuxFcMfhY,'cast':ApTWbJvUeRyQjiwtGDNECnuxFcMfhO,'director':ApTWbJvUeRyQjiwtGDNECnuxFcMfhI,'genre':ApTWbJvUeRyQjiwtGDNECnuxFcMfhX,'duration':ApTWbJvUeRyQjiwtGDNECnuxFcMfIK,'premiered':ApTWbJvUeRyQjiwtGDNECnuxFcMfhm,'studio':ApTWbJvUeRyQjiwtGDNECnuxFcMfIX,'mpaa':ApTWbJvUeRyQjiwtGDNECnuxFcMfhs,'plot':ApTWbJvUeRyQjiwtGDNECnuxFcMfhH}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'MOVIE','mediacode':ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('moviecode'),'stype':'movie','title':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'thumbnail':ApTWbJvUeRyQjiwtGDNECnuxFcMfOS}
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_makebookmark():
    ApTWbJvUeRyQjiwtGDNECnuxFcMfhV={'videoid':ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('moviecode'),'vidtype':'movie','vtitle':ApTWbJvUeRyQjiwtGDNECnuxFcMfIO,'vsubtitle':'',}
    ApTWbJvUeRyQjiwtGDNECnuxFcMfho=json.dumps(ApTWbJvUeRyQjiwtGDNECnuxFcMfhV)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfho=urllib.parse.quote(ApTWbJvUeRyQjiwtGDNECnuxFcMfho)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfhq='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfho)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfha=[('(통합) 찜 영상에 추가',ApTWbJvUeRyQjiwtGDNECnuxFcMfhq)]
   else:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfha=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel='',img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOS,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfhK,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk,ContextMenu=ApTWbJvUeRyQjiwtGDNECnuxFcMfha)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOg:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['mode'] ='MOVIE_SUB' 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['orderby']=ApTWbJvUeRyQjiwtGDNECnuxFcMfkd
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['stype'] =ApTWbJvUeRyQjiwtGDNECnuxFcMfhz
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['page'] =ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl='[B]%s >>[/B]'%'다음 페이지'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhB=ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfhB,img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOH,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  xbmcplugin.setContent(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,'movies')
  xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,cacheToDisc=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS)
 def dp_4K_Movie_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOq=ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('page'))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIs,ApTWbJvUeRyQjiwtGDNECnuxFcMfOg=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Get_UHD_MovieList(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq)
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfIm in ApTWbJvUeRyQjiwtGDNECnuxFcMfIs:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('title')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOS =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('thumbnail')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhH =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('synopsis')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIO =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('info_title')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhY =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('year')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhO =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('cast')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhI =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('director')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhX =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('info_genre')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIK =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('duration')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhm =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('premiered')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIX =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('studio')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhs =ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('mpaa')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhK={'mediatype':'movie','title':ApTWbJvUeRyQjiwtGDNECnuxFcMfIO,'year':ApTWbJvUeRyQjiwtGDNECnuxFcMfhY,'cast':ApTWbJvUeRyQjiwtGDNECnuxFcMfhO,'director':ApTWbJvUeRyQjiwtGDNECnuxFcMfhI,'genre':ApTWbJvUeRyQjiwtGDNECnuxFcMfhX,'duration':ApTWbJvUeRyQjiwtGDNECnuxFcMfIK,'premiered':ApTWbJvUeRyQjiwtGDNECnuxFcMfhm,'studio':ApTWbJvUeRyQjiwtGDNECnuxFcMfIX,'mpaa':ApTWbJvUeRyQjiwtGDNECnuxFcMfhs,'plot':ApTWbJvUeRyQjiwtGDNECnuxFcMfhH}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'MOVIE','mediacode':ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('moviecode'),'stype':'movie','title':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'thumbnail':ApTWbJvUeRyQjiwtGDNECnuxFcMfOS}
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_makebookmark():
    ApTWbJvUeRyQjiwtGDNECnuxFcMfhV={'videoid':ApTWbJvUeRyQjiwtGDNECnuxFcMfIm.get('moviecode'),'vidtype':'movie','vtitle':ApTWbJvUeRyQjiwtGDNECnuxFcMfIO,'vsubtitle':'',}
    ApTWbJvUeRyQjiwtGDNECnuxFcMfho=json.dumps(ApTWbJvUeRyQjiwtGDNECnuxFcMfhV)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfho=urllib.parse.quote(ApTWbJvUeRyQjiwtGDNECnuxFcMfho)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfhq='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfho)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfha=[('(통합) 찜 영상에 추가',ApTWbJvUeRyQjiwtGDNECnuxFcMfhq)]
   else:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfha=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel='',img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOS,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfhK,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk,ContextMenu=ApTWbJvUeRyQjiwtGDNECnuxFcMfha)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOg:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['mode'] ='4K_MOVIE' 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['page'] =ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl='[B]%s >>[/B]'%'다음 페이지'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhB=ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfhB,img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOH,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  xbmcplugin.setContent(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,'movies')
  xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,cacheToDisc=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS)
 def dp_Set_Bookmark(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIB=urllib.parse.unquote(ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('bm_param'))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIB=json.loads(ApTWbJvUeRyQjiwtGDNECnuxFcMfIB)
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIz =ApTWbJvUeRyQjiwtGDNECnuxFcMfIB.get('videoid')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIP =ApTWbJvUeRyQjiwtGDNECnuxFcMfIB.get('vidtype')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfId =ApTWbJvUeRyQjiwtGDNECnuxFcMfIB.get('vtitle')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIr =ApTWbJvUeRyQjiwtGDNECnuxFcMfIB.get('vsubtitle')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHo=xbmcgui.Dialog()
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOz=ApTWbJvUeRyQjiwtGDNECnuxFcMfHo.yesno(__language__(30913).encode('utf8'),ApTWbJvUeRyQjiwtGDNECnuxFcMfId+' \n\n'+__language__(30914))
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOz==ApTWbJvUeRyQjiwtGDNECnuxFcMfsS:return
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIl=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.GetBookmarkInfo(ApTWbJvUeRyQjiwtGDNECnuxFcMfIz,ApTWbJvUeRyQjiwtGDNECnuxFcMfIP)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfIr!='':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIl['saveinfo']['subtitle']=ApTWbJvUeRyQjiwtGDNECnuxFcMfIr 
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfIP=='tvshow':ApTWbJvUeRyQjiwtGDNECnuxFcMfIl['saveinfo']['infoLabels']['studio']=ApTWbJvUeRyQjiwtGDNECnuxFcMfIr 
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIV=json.dumps(ApTWbJvUeRyQjiwtGDNECnuxFcMfIl)
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIV=urllib.parse.quote(ApTWbJvUeRyQjiwtGDNECnuxFcMfIV)
  ApTWbJvUeRyQjiwtGDNECnuxFcMfhq ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfIV)
  xbmc.executebuiltin(ApTWbJvUeRyQjiwtGDNECnuxFcMfhq)
 def dp_Search_Group(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  if 'search_key' in ApTWbJvUeRyQjiwtGDNECnuxFcMfOo:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIo=ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('search_key')
  else:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIo=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not ApTWbJvUeRyQjiwtGDNECnuxFcMfIo:
    return
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfOV in ApTWbJvUeRyQjiwtGDNECnuxFcMfHX:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIq =ApTWbJvUeRyQjiwtGDNECnuxFcMfOV.get('mode')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOr=ApTWbJvUeRyQjiwtGDNECnuxFcMfOV.get('stype')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl=ApTWbJvUeRyQjiwtGDNECnuxFcMfOV.get('title')
   (ApTWbJvUeRyQjiwtGDNECnuxFcMfIa,ApTWbJvUeRyQjiwtGDNECnuxFcMfOg)=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.GetSearchList(ApTWbJvUeRyQjiwtGDNECnuxFcMfIo,1,ApTWbJvUeRyQjiwtGDNECnuxFcMfOr)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOX={'plot':'검색어 : '+ApTWbJvUeRyQjiwtGDNECnuxFcMfIo+'\n\n'+ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.Search_FreeList(ApTWbJvUeRyQjiwtGDNECnuxFcMfIa)}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':ApTWbJvUeRyQjiwtGDNECnuxFcMfIq,'stype':ApTWbJvUeRyQjiwtGDNECnuxFcMfOr,'search_key':ApTWbJvUeRyQjiwtGDNECnuxFcMfIo,'page':'1',}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel='',img='',infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfOX,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfmI(ApTWbJvUeRyQjiwtGDNECnuxFcMfHX)>0:xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,cacheToDisc=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL)
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.Save_Searched_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfIo)
 def Search_FreeList(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfXY):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIg=''
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIL=7
  try:
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfmI(ApTWbJvUeRyQjiwtGDNECnuxFcMfXY)==0:return '검색결과 없음'
   for i in ApTWbJvUeRyQjiwtGDNECnuxFcMfmY(ApTWbJvUeRyQjiwtGDNECnuxFcMfmI(ApTWbJvUeRyQjiwtGDNECnuxFcMfXY)):
    if i>=ApTWbJvUeRyQjiwtGDNECnuxFcMfIL:
     ApTWbJvUeRyQjiwtGDNECnuxFcMfIg=ApTWbJvUeRyQjiwtGDNECnuxFcMfIg+'...'
     break
    ApTWbJvUeRyQjiwtGDNECnuxFcMfIg=ApTWbJvUeRyQjiwtGDNECnuxFcMfIg+ApTWbJvUeRyQjiwtGDNECnuxFcMfXY[i]['title']+'\n'
  except:
   return ''
  return ApTWbJvUeRyQjiwtGDNECnuxFcMfIg
 def dp_Search_History(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIS=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.Load_List_File('search')
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfXH in ApTWbJvUeRyQjiwtGDNECnuxFcMfIS:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXk=ApTWbJvUeRyQjiwtGDNECnuxFcMfmk(urllib.parse.parse_qsl(ApTWbJvUeRyQjiwtGDNECnuxFcMfXH))
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXO=ApTWbJvUeRyQjiwtGDNECnuxFcMfXk.get('skey').strip()
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'SEARCH_GROUP','search_key':ApTWbJvUeRyQjiwtGDNECnuxFcMfXO,}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXh={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':ApTWbJvUeRyQjiwtGDNECnuxFcMfXO,'vType':'-',}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXI=urllib.parse.urlencode(ApTWbJvUeRyQjiwtGDNECnuxFcMfXh)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfha=[('선택된 검색어 ( %s ) 삭제'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfXO),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfXI))]
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfXO,sublabel='',img=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk,ContextMenu=ApTWbJvUeRyQjiwtGDNECnuxFcMfha)
  ApTWbJvUeRyQjiwtGDNECnuxFcMfhK={'plot':'검색목록 전체를 삭제합니다.'}
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkl='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel='',img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOH,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfhK,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk,isLink=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL)
  xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,cacheToDisc=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS)
 def dp_Search_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOq =ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('page'))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOr =ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('stype')
  if 'search_key' in ApTWbJvUeRyQjiwtGDNECnuxFcMfOo:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIo=ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('search_key')
  else:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIo=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not ApTWbJvUeRyQjiwtGDNECnuxFcMfIo:
    xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle)
    return
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIa,ApTWbJvUeRyQjiwtGDNECnuxFcMfOg=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.GetSearchList(ApTWbJvUeRyQjiwtGDNECnuxFcMfIo,ApTWbJvUeRyQjiwtGDNECnuxFcMfOq,ApTWbJvUeRyQjiwtGDNECnuxFcMfOr)
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfXY in ApTWbJvUeRyQjiwtGDNECnuxFcMfIa:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl =ApTWbJvUeRyQjiwtGDNECnuxFcMfXY.get('title')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOS =ApTWbJvUeRyQjiwtGDNECnuxFcMfXY.get('thumbnail')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhH =ApTWbJvUeRyQjiwtGDNECnuxFcMfXY.get('synopsis')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXs =ApTWbJvUeRyQjiwtGDNECnuxFcMfXY.get('program')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhO =ApTWbJvUeRyQjiwtGDNECnuxFcMfXY.get('cast')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhI =ApTWbJvUeRyQjiwtGDNECnuxFcMfXY.get('director')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhX=ApTWbJvUeRyQjiwtGDNECnuxFcMfXY.get('info_genre')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIK =ApTWbJvUeRyQjiwtGDNECnuxFcMfXY.get('duration')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhs =ApTWbJvUeRyQjiwtGDNECnuxFcMfXY.get('mpaa')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhY =ApTWbJvUeRyQjiwtGDNECnuxFcMfXY.get('year')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfIh =ApTWbJvUeRyQjiwtGDNECnuxFcMfXY.get('aired')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhK={'mediatype':'tvshow' if ApTWbJvUeRyQjiwtGDNECnuxFcMfOr=='vod' else 'movie','title':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'cast':ApTWbJvUeRyQjiwtGDNECnuxFcMfhO,'director':ApTWbJvUeRyQjiwtGDNECnuxFcMfhI,'genre':ApTWbJvUeRyQjiwtGDNECnuxFcMfhX,'duration':ApTWbJvUeRyQjiwtGDNECnuxFcMfIK,'mpaa':ApTWbJvUeRyQjiwtGDNECnuxFcMfhs,'year':ApTWbJvUeRyQjiwtGDNECnuxFcMfhY,'aired':ApTWbJvUeRyQjiwtGDNECnuxFcMfIh,'plot':'%s\n\n%s'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,ApTWbJvUeRyQjiwtGDNECnuxFcMfhH)}
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfOr=='vod':
    ApTWbJvUeRyQjiwtGDNECnuxFcMfIz=ApTWbJvUeRyQjiwtGDNECnuxFcMfXY.get('program')
    ApTWbJvUeRyQjiwtGDNECnuxFcMfIP='tvshow'
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'EPISODE','programcode':ApTWbJvUeRyQjiwtGDNECnuxFcMfIz,'page':'1',}
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOh=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL
   else:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfIz=ApTWbJvUeRyQjiwtGDNECnuxFcMfXY.get('movie')
    ApTWbJvUeRyQjiwtGDNECnuxFcMfIP='movie'
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'MOVIE','mediacode':ApTWbJvUeRyQjiwtGDNECnuxFcMfIz,'stype':'movie','title':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'thumbnail':ApTWbJvUeRyQjiwtGDNECnuxFcMfOS,}
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOh=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_makebookmark():
    ApTWbJvUeRyQjiwtGDNECnuxFcMfhV={'videoid':ApTWbJvUeRyQjiwtGDNECnuxFcMfIz,'vidtype':ApTWbJvUeRyQjiwtGDNECnuxFcMfIP,'vtitle':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'vsubtitle':'',}
    ApTWbJvUeRyQjiwtGDNECnuxFcMfho=json.dumps(ApTWbJvUeRyQjiwtGDNECnuxFcMfhV)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfho=urllib.parse.quote(ApTWbJvUeRyQjiwtGDNECnuxFcMfho)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfhq='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfho)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfha=[('(통합) 찜 영상에 추가',ApTWbJvUeRyQjiwtGDNECnuxFcMfhq)]
   else:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfha=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel='',img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOS,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfhK,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfOh,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk,isLink=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS,ContextMenu=ApTWbJvUeRyQjiwtGDNECnuxFcMfha)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOg:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['mode'] ='SEARCH' 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['search_key']=ApTWbJvUeRyQjiwtGDNECnuxFcMfIo
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk['page'] =ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl='[B]%s >>[/B]'%'다음 페이지'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhB=ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfOq+1)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfhB,img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOH,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOr=='movie':xbmcplugin.setContent(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,'movies')
  else:xbmcplugin.setContent(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,cacheToDisc=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS)
 def dp_History_Remove(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfXm=ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('delType')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfXK =ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('sKey')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfXB =ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('vType')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHo=xbmcgui.Dialog()
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfXm=='SEARCH_ALL':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOz=ApTWbJvUeRyQjiwtGDNECnuxFcMfHo.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfXm=='SEARCH_ONE':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOz=ApTWbJvUeRyQjiwtGDNECnuxFcMfHo.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfXm=='WATCH_ALL':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOz=ApTWbJvUeRyQjiwtGDNECnuxFcMfHo.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfXm=='WATCH_ONE':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOz=ApTWbJvUeRyQjiwtGDNECnuxFcMfHo.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOz==ApTWbJvUeRyQjiwtGDNECnuxFcMfsS:sys.exit()
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfXm=='SEARCH_ALL':
   if os.path.isfile(ApTWbJvUeRyQjiwtGDNECnuxFcMfHz):os.remove(ApTWbJvUeRyQjiwtGDNECnuxFcMfHz)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfXm=='SEARCH_ONE':
   try:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXz=ApTWbJvUeRyQjiwtGDNECnuxFcMfHz
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXP=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.Load_List_File('search') 
    fp=ApTWbJvUeRyQjiwtGDNECnuxFcMfms(ApTWbJvUeRyQjiwtGDNECnuxFcMfXz,'w',-1,'utf-8')
    for ApTWbJvUeRyQjiwtGDNECnuxFcMfXd in ApTWbJvUeRyQjiwtGDNECnuxFcMfXP:
     ApTWbJvUeRyQjiwtGDNECnuxFcMfXr=ApTWbJvUeRyQjiwtGDNECnuxFcMfmk(urllib.parse.parse_qsl(ApTWbJvUeRyQjiwtGDNECnuxFcMfXd))
     ApTWbJvUeRyQjiwtGDNECnuxFcMfXl=ApTWbJvUeRyQjiwtGDNECnuxFcMfXr.get('skey').strip()
     if ApTWbJvUeRyQjiwtGDNECnuxFcMfXK!=ApTWbJvUeRyQjiwtGDNECnuxFcMfXl:
      fp.write(ApTWbJvUeRyQjiwtGDNECnuxFcMfXd)
    fp.close()
   except:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfXm=='WATCH_ALL':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ApTWbJvUeRyQjiwtGDNECnuxFcMfXB))
   if os.path.isfile(ApTWbJvUeRyQjiwtGDNECnuxFcMfXz):os.remove(ApTWbJvUeRyQjiwtGDNECnuxFcMfXz)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfXm=='WATCH_ONE':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ApTWbJvUeRyQjiwtGDNECnuxFcMfXB))
   try:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXP=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.Load_List_File(ApTWbJvUeRyQjiwtGDNECnuxFcMfXB) 
    fp=ApTWbJvUeRyQjiwtGDNECnuxFcMfms(ApTWbJvUeRyQjiwtGDNECnuxFcMfXz,'w',-1,'utf-8')
    for ApTWbJvUeRyQjiwtGDNECnuxFcMfXd in ApTWbJvUeRyQjiwtGDNECnuxFcMfXP:
     ApTWbJvUeRyQjiwtGDNECnuxFcMfXr=ApTWbJvUeRyQjiwtGDNECnuxFcMfmk(urllib.parse.parse_qsl(ApTWbJvUeRyQjiwtGDNECnuxFcMfXd))
     ApTWbJvUeRyQjiwtGDNECnuxFcMfXl=ApTWbJvUeRyQjiwtGDNECnuxFcMfXr.get('code').strip()
     if ApTWbJvUeRyQjiwtGDNECnuxFcMfXK!=ApTWbJvUeRyQjiwtGDNECnuxFcMfXl:
      fp.write(ApTWbJvUeRyQjiwtGDNECnuxFcMfXd)
    fp.close()
   except:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOr): 
  try:
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfOr=='search':
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXz=ApTWbJvUeRyQjiwtGDNECnuxFcMfHz
   elif ApTWbJvUeRyQjiwtGDNECnuxFcMfOr in['vod','movie']:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ApTWbJvUeRyQjiwtGDNECnuxFcMfOr))
   else:
    return[]
   fp=ApTWbJvUeRyQjiwtGDNECnuxFcMfms(ApTWbJvUeRyQjiwtGDNECnuxFcMfXz,'r',-1,'utf-8')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXV=fp.readlines()
   fp.close()
  except:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXV=[]
  return ApTWbJvUeRyQjiwtGDNECnuxFcMfXV
 def Save_Watched_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOr,ApTWbJvUeRyQjiwtGDNECnuxFcMfHl):
  try:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%ApTWbJvUeRyQjiwtGDNECnuxFcMfOr))
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXP=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.Load_List_File(ApTWbJvUeRyQjiwtGDNECnuxFcMfOr) 
   fp=ApTWbJvUeRyQjiwtGDNECnuxFcMfms(ApTWbJvUeRyQjiwtGDNECnuxFcMfXo,'w',-1,'utf-8')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXq=urllib.parse.urlencode(ApTWbJvUeRyQjiwtGDNECnuxFcMfHl)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXq=ApTWbJvUeRyQjiwtGDNECnuxFcMfXq+'\n'
   fp.write(ApTWbJvUeRyQjiwtGDNECnuxFcMfXq)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXa=0
   for ApTWbJvUeRyQjiwtGDNECnuxFcMfXd in ApTWbJvUeRyQjiwtGDNECnuxFcMfXP:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXr=ApTWbJvUeRyQjiwtGDNECnuxFcMfmk(urllib.parse.parse_qsl(ApTWbJvUeRyQjiwtGDNECnuxFcMfXd))
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXg=ApTWbJvUeRyQjiwtGDNECnuxFcMfHl.get('code').strip()
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXL=ApTWbJvUeRyQjiwtGDNECnuxFcMfXr.get('code').strip()
    if ApTWbJvUeRyQjiwtGDNECnuxFcMfOr=='vod' and ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_direct_replay()==ApTWbJvUeRyQjiwtGDNECnuxFcMfsL:
     ApTWbJvUeRyQjiwtGDNECnuxFcMfXg=ApTWbJvUeRyQjiwtGDNECnuxFcMfHl.get('videoid').strip()
     ApTWbJvUeRyQjiwtGDNECnuxFcMfXL=ApTWbJvUeRyQjiwtGDNECnuxFcMfXr.get('videoid').strip()if ApTWbJvUeRyQjiwtGDNECnuxFcMfXL!=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa else '-'
    if ApTWbJvUeRyQjiwtGDNECnuxFcMfXg!=ApTWbJvUeRyQjiwtGDNECnuxFcMfXL:
     fp.write(ApTWbJvUeRyQjiwtGDNECnuxFcMfXd)
     ApTWbJvUeRyQjiwtGDNECnuxFcMfXa+=1
     if ApTWbJvUeRyQjiwtGDNECnuxFcMfXa>=50:break
   fp.close()
  except:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
 def dp_Watch_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOr =ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('stype')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkz=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_direct_replay()
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOr=='-':
   for ApTWbJvUeRyQjiwtGDNECnuxFcMfOV in ApTWbJvUeRyQjiwtGDNECnuxFcMfHI:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfkl=ApTWbJvUeRyQjiwtGDNECnuxFcMfOV.get('title')
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':ApTWbJvUeRyQjiwtGDNECnuxFcMfOV.get('mode'),'stype':ApTWbJvUeRyQjiwtGDNECnuxFcMfOV.get('stype')}
    ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel='',img='',infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfsa,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfmI(ApTWbJvUeRyQjiwtGDNECnuxFcMfHI)>0:xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle)
  else:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXS=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.Load_List_File(ApTWbJvUeRyQjiwtGDNECnuxFcMfOr)
   for ApTWbJvUeRyQjiwtGDNECnuxFcMfYH in ApTWbJvUeRyQjiwtGDNECnuxFcMfXS:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXk=ApTWbJvUeRyQjiwtGDNECnuxFcMfmk(urllib.parse.parse_qsl(ApTWbJvUeRyQjiwtGDNECnuxFcMfYH))
    ApTWbJvUeRyQjiwtGDNECnuxFcMfYk =ApTWbJvUeRyQjiwtGDNECnuxFcMfXk.get('code').strip()
    ApTWbJvUeRyQjiwtGDNECnuxFcMfkl =ApTWbJvUeRyQjiwtGDNECnuxFcMfXk.get('title').strip()
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOS=ApTWbJvUeRyQjiwtGDNECnuxFcMfXk.get('img').strip()
    ApTWbJvUeRyQjiwtGDNECnuxFcMfIz =ApTWbJvUeRyQjiwtGDNECnuxFcMfXk.get('videoid').strip()
    try:
     ApTWbJvUeRyQjiwtGDNECnuxFcMfOS=ApTWbJvUeRyQjiwtGDNECnuxFcMfOS.replace('\'','\"')
     ApTWbJvUeRyQjiwtGDNECnuxFcMfOS=json.loads(ApTWbJvUeRyQjiwtGDNECnuxFcMfOS)
    except:
     ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
    ApTWbJvUeRyQjiwtGDNECnuxFcMfhK={}
    ApTWbJvUeRyQjiwtGDNECnuxFcMfhK['plot']=ApTWbJvUeRyQjiwtGDNECnuxFcMfkl
    if ApTWbJvUeRyQjiwtGDNECnuxFcMfOr=='vod':
     if ApTWbJvUeRyQjiwtGDNECnuxFcMfkz==ApTWbJvUeRyQjiwtGDNECnuxFcMfsS or ApTWbJvUeRyQjiwtGDNECnuxFcMfIz==ApTWbJvUeRyQjiwtGDNECnuxFcMfsa:
      ApTWbJvUeRyQjiwtGDNECnuxFcMfhK['mediatype']='tvshow'
      ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'EPISODE','programcode':ApTWbJvUeRyQjiwtGDNECnuxFcMfYk,'page':'1'}
      ApTWbJvUeRyQjiwtGDNECnuxFcMfOh=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL
     else:
      ApTWbJvUeRyQjiwtGDNECnuxFcMfhK['mediatype']='episode'
      ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'VOD','mediacode':ApTWbJvUeRyQjiwtGDNECnuxFcMfIz,'stype':'vod','programcode':ApTWbJvUeRyQjiwtGDNECnuxFcMfYk,'title':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'thumbnail':ApTWbJvUeRyQjiwtGDNECnuxFcMfOS}
      ApTWbJvUeRyQjiwtGDNECnuxFcMfOh=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
    else:
     ApTWbJvUeRyQjiwtGDNECnuxFcMfhK['mediatype']='movie'
     ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'MOVIE','mediacode':ApTWbJvUeRyQjiwtGDNECnuxFcMfYk,'stype':'movie','title':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'thumbnail':ApTWbJvUeRyQjiwtGDNECnuxFcMfOS}
     ApTWbJvUeRyQjiwtGDNECnuxFcMfOh=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXh={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':ApTWbJvUeRyQjiwtGDNECnuxFcMfYk,'vType':ApTWbJvUeRyQjiwtGDNECnuxFcMfOr,}
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXI=urllib.parse.urlencode(ApTWbJvUeRyQjiwtGDNECnuxFcMfXh)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfha=[('선택된 시청이력 ( %s ) 삭제'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfXI))]
    ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel='',img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOS,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfhK,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfOh,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk,ContextMenu=ApTWbJvUeRyQjiwtGDNECnuxFcMfha)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhK={'plot':'시청목록을 삭제합니다.'}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':ApTWbJvUeRyQjiwtGDNECnuxFcMfOr,}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel='',img=ApTWbJvUeRyQjiwtGDNECnuxFcMfOH,infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfhK,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk,isLink=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL)
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfOr=='movie':xbmcplugin.setContent(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,'movies')
   else:xbmcplugin.setContent(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,cacheToDisc=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS)
 def Save_Searched_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfIo):
  try:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYO=ApTWbJvUeRyQjiwtGDNECnuxFcMfHz
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXP=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.Load_List_File('search') 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYh={'skey':ApTWbJvUeRyQjiwtGDNECnuxFcMfIo.strip()}
   fp=ApTWbJvUeRyQjiwtGDNECnuxFcMfms(ApTWbJvUeRyQjiwtGDNECnuxFcMfYO,'w',-1,'utf-8')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXq=urllib.parse.urlencode(ApTWbJvUeRyQjiwtGDNECnuxFcMfYh)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXq=ApTWbJvUeRyQjiwtGDNECnuxFcMfXq+'\n'
   fp.write(ApTWbJvUeRyQjiwtGDNECnuxFcMfXq)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfXa=0
   for ApTWbJvUeRyQjiwtGDNECnuxFcMfXd in ApTWbJvUeRyQjiwtGDNECnuxFcMfXP:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXr=ApTWbJvUeRyQjiwtGDNECnuxFcMfmk(urllib.parse.parse_qsl(ApTWbJvUeRyQjiwtGDNECnuxFcMfXd))
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXg=ApTWbJvUeRyQjiwtGDNECnuxFcMfYh.get('skey').strip()
    ApTWbJvUeRyQjiwtGDNECnuxFcMfXL=ApTWbJvUeRyQjiwtGDNECnuxFcMfXr.get('skey').strip()
    if ApTWbJvUeRyQjiwtGDNECnuxFcMfXg!=ApTWbJvUeRyQjiwtGDNECnuxFcMfXL:
     fp.write(ApTWbJvUeRyQjiwtGDNECnuxFcMfXd)
     ApTWbJvUeRyQjiwtGDNECnuxFcMfXa+=1
     if ApTWbJvUeRyQjiwtGDNECnuxFcMfXa>=50:break
   fp.close()
  except:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
 def play_VIDEO(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfYI =ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('mediacode')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOr =ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('stype')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfYX =ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('pvrmode')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfYs=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_selQuality(ApTWbJvUeRyQjiwtGDNECnuxFcMfOr)
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfYI,ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfYs),ApTWbJvUeRyQjiwtGDNECnuxFcMfOr,ApTWbJvUeRyQjiwtGDNECnuxFcMfYX))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfYm=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.GetBroadURL(ApTWbJvUeRyQjiwtGDNECnuxFcMfYI,ApTWbJvUeRyQjiwtGDNECnuxFcMfYs,ApTWbJvUeRyQjiwtGDNECnuxFcMfOr,ApTWbJvUeRyQjiwtGDNECnuxFcMfYX,optUHD=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_uhd())
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_log('qt, stype, url : %s - %s - %s'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfmX(ApTWbJvUeRyQjiwtGDNECnuxFcMfYs),ApTWbJvUeRyQjiwtGDNECnuxFcMfOr,ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['streaming_url']))
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['streaming_url']=='':
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['error_msg']=='':
    ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_noti(__language__(30908).encode('utf8'))
   else:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_noti(ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['error_msg'].encode('utf8'))
   return
  ApTWbJvUeRyQjiwtGDNECnuxFcMfYK={'user-agent':ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.USER_AGENT}
  ApTWbJvUeRyQjiwtGDNECnuxFcMfYB=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.makeDefaultCookies() 
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['watermark'] !='':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYK['x-tving-param1']=ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['watermarkKey']
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYK['x-tving-param2']=ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['watermark'] 
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_log('streaming_url = {}'.format(ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['streaming_url']))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_log('drm_license   = {}'.format(ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['drm_license']))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_log('watermark     = {}'.format(ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['watermark']))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_log('watermarkKey  = {}'.format(ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['watermarkKey']))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfYz =ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
  ApTWbJvUeRyQjiwtGDNECnuxFcMfYP =ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['streaming_url'].find('Policy=')
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfYP!=-1:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYd =ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['streaming_url'].split('?')[0]
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYr=ApTWbJvUeRyQjiwtGDNECnuxFcMfmk(urllib.parse.parse_qsl(urllib.parse.urlsplit(ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['streaming_url']).query))
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYB['CloudFront-Policy'] =ApTWbJvUeRyQjiwtGDNECnuxFcMfYr['Policy'] 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYB['CloudFront-Signature'] =ApTWbJvUeRyQjiwtGDNECnuxFcMfYr['Signature'] 
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYB['CloudFront-Key-Pair-Id']=ApTWbJvUeRyQjiwtGDNECnuxFcMfYr['Key-Pair-Id'] 
   if 'quickvod-mcdn.tving.com' in ApTWbJvUeRyQjiwtGDNECnuxFcMfYd and 1==2:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfYz=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL
    ApTWbJvUeRyQjiwtGDNECnuxFcMfYl =ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfYV=ApTWbJvUeRyQjiwtGDNECnuxFcMfYl.strftime('%Y-%m-%d-%H:%M:%S')
    if ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(ApTWbJvUeRyQjiwtGDNECnuxFcMfYV.replace('-','').replace(':',''))<ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(ApTWbJvUeRyQjiwtGDNECnuxFcMfYr['end'].replace('-','').replace(':','')):
     ApTWbJvUeRyQjiwtGDNECnuxFcMfYr['end']=ApTWbJvUeRyQjiwtGDNECnuxFcMfYV
     ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_noti(__language__(30915).encode('utf8'))
    ApTWbJvUeRyQjiwtGDNECnuxFcMfYd ='%s?%s'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfYd,urllib.parse.urlencode(ApTWbJvUeRyQjiwtGDNECnuxFcMfYr,doseq=ApTWbJvUeRyQjiwtGDNECnuxFcMfsL))
    ApTWbJvUeRyQjiwtGDNECnuxFcMfYo='{}|{}'.format(ApTWbJvUeRyQjiwtGDNECnuxFcMfYd,ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.make_stream_header(ApTWbJvUeRyQjiwtGDNECnuxFcMfYK,ApTWbJvUeRyQjiwtGDNECnuxFcMfYB))
   else:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfYo='{}|{}'.format(ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['streaming_url'],ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.make_stream_header(ApTWbJvUeRyQjiwtGDNECnuxFcMfYK,ApTWbJvUeRyQjiwtGDNECnuxFcMfYB))
  else:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYo='{}|{}'.format(ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['streaming_url'],ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.make_stream_header(ApTWbJvUeRyQjiwtGDNECnuxFcMfYK,ApTWbJvUeRyQjiwtGDNECnuxFcMfYB))
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_log('if tmp_pos == -1')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkI,ApTWbJvUeRyQjiwtGDNECnuxFcMfkX=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_proxyport()
  ApTWbJvUeRyQjiwtGDNECnuxFcMfkh=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_playback()
  ApTWbJvUeRyQjiwtGDNECnuxFcMfYq=urllib.parse.urlparse(ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['streaming_url'])
  ApTWbJvUeRyQjiwtGDNECnuxFcMfYq=ApTWbJvUeRyQjiwtGDNECnuxFcMfYq.path.strip('/').split('/')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfYq=ApTWbJvUeRyQjiwtGDNECnuxFcMfYq[ApTWbJvUeRyQjiwtGDNECnuxFcMfmI(ApTWbJvUeRyQjiwtGDNECnuxFcMfYq)-1] 
  if(ApTWbJvUeRyQjiwtGDNECnuxFcMfkI and ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('mode')in['VOD','MOVIE']and ApTWbJvUeRyQjiwtGDNECnuxFcMfYz==ApTWbJvUeRyQjiwtGDNECnuxFcMfsS and ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['drm_license']!=''):
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfYq.split('.')[1]=='mpd':
    ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Tving_Parse_mpd(ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['streaming_url'],ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['watermarkKey'],ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['watermark'])
   else:
    ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Tving_Parse_m3u8(ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['streaming_url'])
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_log('xxx '+ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['streaming_url'])
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYa={'addon':'tvingm','playOption':ApTWbJvUeRyQjiwtGDNECnuxFcMfkh,}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYa=json.dumps(ApTWbJvUeRyQjiwtGDNECnuxFcMfYa,separators=(',',':'))
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYa=base64.standard_b64encode(ApTWbJvUeRyQjiwtGDNECnuxFcMfYa.encode()).decode('utf-8')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYo ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(ApTWbJvUeRyQjiwtGDNECnuxFcMfkX,ApTWbJvUeRyQjiwtGDNECnuxFcMfYo,ApTWbJvUeRyQjiwtGDNECnuxFcMfYa)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYK['proxy-mini']=ApTWbJvUeRyQjiwtGDNECnuxFcMfYa 
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_log('surl(2) : {}'.format(ApTWbJvUeRyQjiwtGDNECnuxFcMfYo))
  ApTWbJvUeRyQjiwtGDNECnuxFcMfYg=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.make_stream_header(ApTWbJvUeRyQjiwtGDNECnuxFcMfYK,ApTWbJvUeRyQjiwtGDNECnuxFcMfYB)
  ApTWbJvUeRyQjiwtGDNECnuxFcMfYL=xbmcgui.ListItem(path=ApTWbJvUeRyQjiwtGDNECnuxFcMfYo)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['drm_license']!='':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYS=ApTWbJvUeRyQjiwtGDNECnuxFcMfYm['drm_license']
   ApTWbJvUeRyQjiwtGDNECnuxFcMfsH ='https://cj.drmkeyserver.com/widevine_license'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfsk ='mpd'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfsO ='com.widevine.alpha'
   ApTWbJvUeRyQjiwtGDNECnuxFcMfsh =inputstreamhelper.Helper(ApTWbJvUeRyQjiwtGDNECnuxFcMfsk,drm='widevine')
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfsh.check_inputstream():
    ApTWbJvUeRyQjiwtGDNECnuxFcMfsI={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.USER_AGENT,'AcquireLicenseAssertion':ApTWbJvUeRyQjiwtGDNECnuxFcMfYS,'Host':'cj.drmkeyserver.com',}
    ApTWbJvUeRyQjiwtGDNECnuxFcMfsX=ApTWbJvUeRyQjiwtGDNECnuxFcMfsH+'|'+urllib.parse.urlencode(ApTWbJvUeRyQjiwtGDNECnuxFcMfsI)+'|R{SSM}|'
    ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('inputstream',ApTWbJvUeRyQjiwtGDNECnuxFcMfsh.inputstream_addon)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('inputstream.adaptive.manifest_type',ApTWbJvUeRyQjiwtGDNECnuxFcMfsk)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('inputstream.adaptive.license_type',ApTWbJvUeRyQjiwtGDNECnuxFcMfsO)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('inputstream.adaptive.license_key',ApTWbJvUeRyQjiwtGDNECnuxFcMfsX)
    ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('inputstream.adaptive.stream_headers',ApTWbJvUeRyQjiwtGDNECnuxFcMfYg)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('mode')in['VOD','MOVIE']:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setContentLookup(ApTWbJvUeRyQjiwtGDNECnuxFcMfsS)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setMimeType('application/x-mpegURL')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('inputstream','inputstream.adaptive')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('inputstream.adaptive.manifest_type','hls')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('inputstream.adaptive.stream_headers',ApTWbJvUeRyQjiwtGDNECnuxFcMfYg)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfYz==ApTWbJvUeRyQjiwtGDNECnuxFcMfsL:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setContentLookup(ApTWbJvUeRyQjiwtGDNECnuxFcMfsS)
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setMimeType('application/x-mpegURL')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('inputstream','inputstream.ffmpegdirect')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('ResumeTime','0')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfYL.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,ApTWbJvUeRyQjiwtGDNECnuxFcMfsL,ApTWbJvUeRyQjiwtGDNECnuxFcMfYL)
  try:
   if ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('mode')in['VOD','MOVIE']and ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('title'):
    ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'code':ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('programcode')if ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('mode')=='VOD' else ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('mediacode'),'img':ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('thumbnail'),'title':ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('title'),'videoid':ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('mediacode')}
    ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.Save_Watched_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('stype'),ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  except:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
 def logout(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHo=xbmcgui.Dialog()
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOz=ApTWbJvUeRyQjiwtGDNECnuxFcMfHo.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfOz==ApTWbJvUeRyQjiwtGDNECnuxFcMfsS:sys.exit()
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Init_TV_Total()
  if os.path.isfile(ApTWbJvUeRyQjiwtGDNECnuxFcMfHB):os.remove(ApTWbJvUeRyQjiwtGDNECnuxFcMfHB)
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfsY =ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Get_Now_Datetime()
  ApTWbJvUeRyQjiwtGDNECnuxFcMfsm=ApTWbJvUeRyQjiwtGDNECnuxFcMfsY+datetime.timedelta(days=ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(__addon__.getSetting('cache_ttl')))
  (ApTWbJvUeRyQjiwtGDNECnuxFcMfOs,ApTWbJvUeRyQjiwtGDNECnuxFcMfOm,ApTWbJvUeRyQjiwtGDNECnuxFcMfOK,ApTWbJvUeRyQjiwtGDNECnuxFcMfOB)=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_account()
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Save_session_acount(ApTWbJvUeRyQjiwtGDNECnuxFcMfOs,ApTWbJvUeRyQjiwtGDNECnuxFcMfOm,ApTWbJvUeRyQjiwtGDNECnuxFcMfOK,ApTWbJvUeRyQjiwtGDNECnuxFcMfOB)
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.TV['account']['token_limit']=ApTWbJvUeRyQjiwtGDNECnuxFcMfsm.strftime('%Y%m%d')
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.JsonFile_Save(ApTWbJvUeRyQjiwtGDNECnuxFcMfHB,ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.TV)
 def cookiefile_check(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.TV=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.JsonFile_Load(ApTWbJvUeRyQjiwtGDNECnuxFcMfHB)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.TV=={}:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Init_TV_Total()
   return ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
  if '_tving_token' not in ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.TV.get('cookies'):
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Init_TV_Total()
   return ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
  (ApTWbJvUeRyQjiwtGDNECnuxFcMfsK,ApTWbJvUeRyQjiwtGDNECnuxFcMfsB,ApTWbJvUeRyQjiwtGDNECnuxFcMfsz,ApTWbJvUeRyQjiwtGDNECnuxFcMfsP)=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.get_settings_account()
  (ApTWbJvUeRyQjiwtGDNECnuxFcMfsd,ApTWbJvUeRyQjiwtGDNECnuxFcMfsr,ApTWbJvUeRyQjiwtGDNECnuxFcMfsl,ApTWbJvUeRyQjiwtGDNECnuxFcMfsV)=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Load_session_acount()
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfsK!=ApTWbJvUeRyQjiwtGDNECnuxFcMfsd or ApTWbJvUeRyQjiwtGDNECnuxFcMfsB!=ApTWbJvUeRyQjiwtGDNECnuxFcMfsr or ApTWbJvUeRyQjiwtGDNECnuxFcMfsz!=ApTWbJvUeRyQjiwtGDNECnuxFcMfsl or ApTWbJvUeRyQjiwtGDNECnuxFcMfsP!=ApTWbJvUeRyQjiwtGDNECnuxFcMfsV:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Init_TV_Total()
   return ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.TV['account']['token_limit']):
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.Init_TV_Total()
   return ApTWbJvUeRyQjiwtGDNECnuxFcMfsS
  return ApTWbJvUeRyQjiwtGDNECnuxFcMfsL
 def dp_Global_Search(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=ApTWbJvUeRyQjiwtGDNECnuxFcMfOo.get('mode')
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='TOTAL_SEARCH':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfso='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfso='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(ApTWbJvUeRyQjiwtGDNECnuxFcMfso)
 def dp_Bookmark_Menu(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfso='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(ApTWbJvUeRyQjiwtGDNECnuxFcMfso)
 def dp_EuroLive_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP,ApTWbJvUeRyQjiwtGDNECnuxFcMfOo):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfOa=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.GetEuroChannelList()
  for ApTWbJvUeRyQjiwtGDNECnuxFcMfOL in ApTWbJvUeRyQjiwtGDNECnuxFcMfOa:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhl =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('channel')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfkl =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('title')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhB =ApTWbJvUeRyQjiwtGDNECnuxFcMfOL.get('subtitle')
   ApTWbJvUeRyQjiwtGDNECnuxFcMfhK={'mediatype':'episode','title':ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,'plot':'%s\n%s'%(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,ApTWbJvUeRyQjiwtGDNECnuxFcMfhB)}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfOk={'mode':'LIVE','mediacode':ApTWbJvUeRyQjiwtGDNECnuxFcMfhl,'stype':'onair',}
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.add_dir(ApTWbJvUeRyQjiwtGDNECnuxFcMfkl,sublabel=ApTWbJvUeRyQjiwtGDNECnuxFcMfhB,img='',infoLabels=ApTWbJvUeRyQjiwtGDNECnuxFcMfhK,isFolder=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS,params=ApTWbJvUeRyQjiwtGDNECnuxFcMfOk)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfmI(ApTWbJvUeRyQjiwtGDNECnuxFcMfOa)>0:xbmcplugin.endOfDirectory(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP._addon_handle,cacheToDisc=ApTWbJvUeRyQjiwtGDNECnuxFcMfsS)
 def tving_main(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP):
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.TvingObj.KodiVersion=ApTWbJvUeRyQjiwtGDNECnuxFcMfsg(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params.get('mode',ApTWbJvUeRyQjiwtGDNECnuxFcMfsa)
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='LOGOUT':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.logout()
   return
  ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.login_main()
  if ApTWbJvUeRyQjiwtGDNECnuxFcMfIq is ApTWbJvUeRyQjiwtGDNECnuxFcMfsa:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_Main_List()
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_Title_Group(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq in['GLOBAL_GROUP']:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_SubTitle_Group(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='CHANNEL':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_LiveChannel_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq in['LIVE','VOD','MOVIE']:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.play_VIDEO(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='PROGRAM':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_Program_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='4K_PROGRAM':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_4K_Program_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='ORI_PROGRAM':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_Ori_Program_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='EPISODE':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_Episode_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='MOVIE_SUB':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_Movie_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='4K_MOVIE':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_4K_Movie_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='SEARCH_GROUP':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_Search_Group(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq in['SEARCH','LOCAL_SEARCH']:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_Search_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='WATCH':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_Watch_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_History_Remove(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='ORDER_BY':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_setEpOrderby(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='SET_BOOKMARK':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_Set_Bookmark(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq in['TOTAL_SEARCH','TOTAL_HISTORY']:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_Global_Search(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='SEARCH_HISTORY':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_Search_History(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='MENU_BOOKMARK':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_Bookmark_Menu(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  elif ApTWbJvUeRyQjiwtGDNECnuxFcMfIq=='EURO_GROUP':
   ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.dp_EuroLive_List(ApTWbJvUeRyQjiwtGDNECnuxFcMfHP.main_params)
  else:
   ApTWbJvUeRyQjiwtGDNECnuxFcMfsa
# Created by pyminifier (https://github.com/liftoff/pyminifier)
