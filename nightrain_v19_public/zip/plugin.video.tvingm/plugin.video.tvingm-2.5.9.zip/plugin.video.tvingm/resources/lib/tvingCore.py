__author__="NightRain"
iQUMlausXwdvtNjnFSBJPbKzEhoOLf=print
iQUMlausXwdvtNjnFSBJPbKzEhoOLH=ImportError
iQUMlausXwdvtNjnFSBJPbKzEhoOLI=object
iQUMlausXwdvtNjnFSBJPbKzEhoOLD=None
iQUMlausXwdvtNjnFSBJPbKzEhoOLR=False
iQUMlausXwdvtNjnFSBJPbKzEhoOLC=open
iQUMlausXwdvtNjnFSBJPbKzEhoOLx=True
iQUMlausXwdvtNjnFSBJPbKzEhoOyk=int
iQUMlausXwdvtNjnFSBJPbKzEhoOyV=range
iQUMlausXwdvtNjnFSBJPbKzEhoOyg=Exception
iQUMlausXwdvtNjnFSBJPbKzEhoOyr=len
iQUMlausXwdvtNjnFSBJPbKzEhoOyc=str
iQUMlausXwdvtNjnFSBJPbKzEhoOyq=dict
iQUMlausXwdvtNjnFSBJPbKzEhoOyL=list
iQUMlausXwdvtNjnFSBJPbKzEhoOym=bytes
iQUMlausXwdvtNjnFSBJPbKzEhoOyY=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 iQUMlausXwdvtNjnFSBJPbKzEhoOLf('Cryptodome')
except iQUMlausXwdvtNjnFSBJPbKzEhoOLH:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 iQUMlausXwdvtNjnFSBJPbKzEhoOLf('Crypto')
iQUMlausXwdvtNjnFSBJPbKzEhoOkg={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
iQUMlausXwdvtNjnFSBJPbKzEhoOkr ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
iQUMlausXwdvtNjnFSBJPbKzEhoOkc =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
iQUMlausXwdvtNjnFSBJPbKzEhoOkq=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class iQUMlausXwdvtNjnFSBJPbKzEhoOkV(iQUMlausXwdvtNjnFSBJPbKzEhoOLI):
 def __init__(iQUMlausXwdvtNjnFSBJPbKzEhoOkL):
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.NETWORKCODE ='CSND0900'
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.OSCODE ='CSOD0900' 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TELECODE ='CSCD0900'
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.SCREENCODE ='CSSD0100'
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.SCREENCODE_ATV ='CSSD1300' 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.LIVE_LIMIT =20 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.VOD_LIMIT =24 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.EPISODE_LIMIT =30 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.SEARCH_LIMIT =30 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.MOVIE_LIMIT =24 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN ='https://api.tving.com'
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN ='https://image.tving.com'
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.SEARCH_DOMAIN ='https://search-api.tving.com'
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.LOGIN_DOMAIN ='https://user.tving.com'
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.URL_DOMAIN ='https://www.tving.com'
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.MOVIE_LITE =['2610061','2610161','261062']
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.DEFAULT_HEADER ={'user-agent':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.USER_AGENT}
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.COOKIE_FILE_NAME =''
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV_SESSION_COOKIES1=''
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV_SESSION_COOKIES2=''
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV_STREAM_FILENAME =''
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV_SESSION_TEXT1 =''
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV_SESSION_TEXT2 =''
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.KodiVersion=20
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV ={}
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.Init_TV_Total()
 def Init_TV_Total(iQUMlausXwdvtNjnFSBJPbKzEhoOkL):
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV={'account':{},'cookies':{},}
 def callRequestCookies(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,jobtype,iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,redirects=iQUMlausXwdvtNjnFSBJPbKzEhoOLR):
  iQUMlausXwdvtNjnFSBJPbKzEhoOky=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.DEFAULT_HEADER
  if headers:iQUMlausXwdvtNjnFSBJPbKzEhoOky.update(headers)
  if jobtype=='Get':
   iQUMlausXwdvtNjnFSBJPbKzEhoOkm=requests.get(iQUMlausXwdvtNjnFSBJPbKzEhoOgm,params=params,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOky,cookies=cookies,allow_redirects=redirects)
  else:
   iQUMlausXwdvtNjnFSBJPbKzEhoOkm=requests.post(iQUMlausXwdvtNjnFSBJPbKzEhoOgm,data=payload,params=params,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOky,cookies=cookies,allow_redirects=redirects)
  iQUMlausXwdvtNjnFSBJPbKzEhoOLf(iQUMlausXwdvtNjnFSBJPbKzEhoOkm.url)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOkm
 def JsonFile_Save(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,filename,iQUMlausXwdvtNjnFSBJPbKzEhoOkY):
  if filename=='':return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  try:
   fp=iQUMlausXwdvtNjnFSBJPbKzEhoOLC(filename,'w',-1,'utf-8')
   json.dump(iQUMlausXwdvtNjnFSBJPbKzEhoOkY,fp,indent=4,ensure_ascii=iQUMlausXwdvtNjnFSBJPbKzEhoOLR)
   fp.close()
  except:
   return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  return iQUMlausXwdvtNjnFSBJPbKzEhoOLx
 def JsonFile_Load(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,filename):
  if filename=='':return{}
  try:
   fp=iQUMlausXwdvtNjnFSBJPbKzEhoOLC(filename,'r',-1,'utf-8')
   iQUMlausXwdvtNjnFSBJPbKzEhoOkp=json.load(fp)
   fp.close()
  except:
   return{}
  return iQUMlausXwdvtNjnFSBJPbKzEhoOkp
 def TextFile_Save(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,filename,resText):
  if filename=='':return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  try:
   fp=iQUMlausXwdvtNjnFSBJPbKzEhoOLC(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  return iQUMlausXwdvtNjnFSBJPbKzEhoOLx
 def Save_session_acount(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,iQUMlausXwdvtNjnFSBJPbKzEhoOkW,iQUMlausXwdvtNjnFSBJPbKzEhoOke,iQUMlausXwdvtNjnFSBJPbKzEhoOkT,iQUMlausXwdvtNjnFSBJPbKzEhoOkA):
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['account']['tvid'] =base64.standard_b64encode(iQUMlausXwdvtNjnFSBJPbKzEhoOkW.encode()).decode('utf-8')
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['account']['tvpw'] =base64.standard_b64encode(iQUMlausXwdvtNjnFSBJPbKzEhoOke.encode()).decode('utf-8')
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['account']['tvtype']=iQUMlausXwdvtNjnFSBJPbKzEhoOkT 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['account']['tvpf'] =iQUMlausXwdvtNjnFSBJPbKzEhoOkA 
 def Load_session_acount(iQUMlausXwdvtNjnFSBJPbKzEhoOkL):
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOkW =base64.standard_b64decode(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['account']['tvid']).decode('utf-8')
   iQUMlausXwdvtNjnFSBJPbKzEhoOke =base64.standard_b64decode(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['account']['tvpw']).decode('utf-8')
   iQUMlausXwdvtNjnFSBJPbKzEhoOkT=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['account']['tvtype']
   iQUMlausXwdvtNjnFSBJPbKzEhoOkA =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return iQUMlausXwdvtNjnFSBJPbKzEhoOkW,iQUMlausXwdvtNjnFSBJPbKzEhoOke,iQUMlausXwdvtNjnFSBJPbKzEhoOkT,iQUMlausXwdvtNjnFSBJPbKzEhoOkA
 def makeDefaultCookies(iQUMlausXwdvtNjnFSBJPbKzEhoOkL):
  iQUMlausXwdvtNjnFSBJPbKzEhoOkf={}
  for iQUMlausXwdvtNjnFSBJPbKzEhoOkH,iQUMlausXwdvtNjnFSBJPbKzEhoOVx in iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies'].items():
   iQUMlausXwdvtNjnFSBJPbKzEhoOkf[iQUMlausXwdvtNjnFSBJPbKzEhoOkH]=iQUMlausXwdvtNjnFSBJPbKzEhoOVx
  return iQUMlausXwdvtNjnFSBJPbKzEhoOkf
 def getDeviceStr(iQUMlausXwdvtNjnFSBJPbKzEhoOkL):
  iQUMlausXwdvtNjnFSBJPbKzEhoOkI=[]
  iQUMlausXwdvtNjnFSBJPbKzEhoOkI.append('Windows') 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkI.append('Chrome') 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkI.append('ko-KR') 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkI.append('undefined') 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkI.append('24') 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkI.append(u'한국 표준시')
  iQUMlausXwdvtNjnFSBJPbKzEhoOkI.append('undefined') 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkI.append('undefined') 
  iQUMlausXwdvtNjnFSBJPbKzEhoOkI.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  iQUMlausXwdvtNjnFSBJPbKzEhoOkD=''
  for iQUMlausXwdvtNjnFSBJPbKzEhoOkR in iQUMlausXwdvtNjnFSBJPbKzEhoOkI:
   iQUMlausXwdvtNjnFSBJPbKzEhoOkD+=iQUMlausXwdvtNjnFSBJPbKzEhoOkR+'|'
  return iQUMlausXwdvtNjnFSBJPbKzEhoOkD
 def GetDefaultParams(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,uhd=iQUMlausXwdvtNjnFSBJPbKzEhoOLR):
  if uhd==iQUMlausXwdvtNjnFSBJPbKzEhoOLR:
   iQUMlausXwdvtNjnFSBJPbKzEhoOkC={'apiKey':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.APIKEY,'networkCode':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.NETWORKCODE,'osCode':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.OSCODE,'teleCode':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TELECODE,'screenCode':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.SCREENCODE,}
  else:
   iQUMlausXwdvtNjnFSBJPbKzEhoOkC={'apiKey':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.APIKEY_ATV,'networkCode':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.NETWORKCODE,'osCode':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.OSCODE,'teleCode':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TELECODE,'screenCode':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.SCREENCODE_ATV,}
  return iQUMlausXwdvtNjnFSBJPbKzEhoOkC
 def GetNoCache(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,timetype=1):
  if timetype==1:
   return iQUMlausXwdvtNjnFSBJPbKzEhoOyk(time.time())
  else:
   return iQUMlausXwdvtNjnFSBJPbKzEhoOyk(time.time()*1000)
 def GetUniqueid(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,hValue=iQUMlausXwdvtNjnFSBJPbKzEhoOLD):
  if hValue:
   import hashlib
   iQUMlausXwdvtNjnFSBJPbKzEhoOkx=hashlib.sha1()
   iQUMlausXwdvtNjnFSBJPbKzEhoOkx.update(hValue.encode())
   iQUMlausXwdvtNjnFSBJPbKzEhoOVk=iQUMlausXwdvtNjnFSBJPbKzEhoOkx.hexdigest()[:8]
  else:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVg=[0 for i in iQUMlausXwdvtNjnFSBJPbKzEhoOyV(256)]
   for i in iQUMlausXwdvtNjnFSBJPbKzEhoOyV(256):
    iQUMlausXwdvtNjnFSBJPbKzEhoOVg[i]='%02x'%(i)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVr=iQUMlausXwdvtNjnFSBJPbKzEhoOyk(4294967295*random.random())|0
   iQUMlausXwdvtNjnFSBJPbKzEhoOVk=iQUMlausXwdvtNjnFSBJPbKzEhoOVg[255&iQUMlausXwdvtNjnFSBJPbKzEhoOVr]+iQUMlausXwdvtNjnFSBJPbKzEhoOVg[iQUMlausXwdvtNjnFSBJPbKzEhoOVr>>8&255]+iQUMlausXwdvtNjnFSBJPbKzEhoOVg[iQUMlausXwdvtNjnFSBJPbKzEhoOVr>>16&255]+iQUMlausXwdvtNjnFSBJPbKzEhoOVg[iQUMlausXwdvtNjnFSBJPbKzEhoOVr>>24&255]
  return iQUMlausXwdvtNjnFSBJPbKzEhoOVk
 def GetCredential(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,user_id,user_pw,login_type,user_pf):
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVc=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   iQUMlausXwdvtNjnFSBJPbKzEhoOVq={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Post',iQUMlausXwdvtNjnFSBJPbKzEhoOVc,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOVq,params=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVy in iQUMlausXwdvtNjnFSBJPbKzEhoOVL.cookies:
    iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies'][iQUMlausXwdvtNjnFSBJPbKzEhoOVy.name]=iQUMlausXwdvtNjnFSBJPbKzEhoOVy.value
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
   iQUMlausXwdvtNjnFSBJPbKzEhoOkL.Init_TV_Total()
   return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  iQUMlausXwdvtNjnFSBJPbKzEhoOVm=[]
  iQUMlausXwdvtNjnFSBJPbKzEhoOVY =''
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   iQUMlausXwdvtNjnFSBJPbKzEhoOkf=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.makeDefaultCookies()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOVG,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOkf)
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVy in iQUMlausXwdvtNjnFSBJPbKzEhoOVL.cookies:
    iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies'][iQUMlausXwdvtNjnFSBJPbKzEhoOVy.name]=iQUMlausXwdvtNjnFSBJPbKzEhoOVy.value
   iQUMlausXwdvtNjnFSBJPbKzEhoOVm =re.findall('data-profile-no="\d+"',iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   for i in iQUMlausXwdvtNjnFSBJPbKzEhoOyV(iQUMlausXwdvtNjnFSBJPbKzEhoOyr(iQUMlausXwdvtNjnFSBJPbKzEhoOVm)):
    iQUMlausXwdvtNjnFSBJPbKzEhoOVp =iQUMlausXwdvtNjnFSBJPbKzEhoOVm[i].replace('data-profile-no=','').replace('"','')
    iQUMlausXwdvtNjnFSBJPbKzEhoOVm[i]=iQUMlausXwdvtNjnFSBJPbKzEhoOVp
   iQUMlausXwdvtNjnFSBJPbKzEhoOVY=iQUMlausXwdvtNjnFSBJPbKzEhoOVm[user_pf]
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
   iQUMlausXwdvtNjnFSBJPbKzEhoOkL.Init_TV_Total()
   return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   iQUMlausXwdvtNjnFSBJPbKzEhoOkf=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.makeDefaultCookies()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVq={'profileNo':iQUMlausXwdvtNjnFSBJPbKzEhoOVY}
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Post',iQUMlausXwdvtNjnFSBJPbKzEhoOVG,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOVq,params=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOkf)
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVy in iQUMlausXwdvtNjnFSBJPbKzEhoOVL.cookies:
    iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies'][iQUMlausXwdvtNjnFSBJPbKzEhoOVy.name]=iQUMlausXwdvtNjnFSBJPbKzEhoOVy.value
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
   iQUMlausXwdvtNjnFSBJPbKzEhoOkL.Init_TV_Total()
   return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  iQUMlausXwdvtNjnFSBJPbKzEhoOVW =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDeviceList()
  if iQUMlausXwdvtNjnFSBJPbKzEhoOVW not in['','-']:
   iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_uuid']=iQUMlausXwdvtNjnFSBJPbKzEhoOVW+'-'+iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetUniqueid(iQUMlausXwdvtNjnFSBJPbKzEhoOVW)
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.JsonFile_Save(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.COOKIE_FILE_NAME,iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOLx
 def GetCredential_old(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,user_id,user_pw,login_type,user_pf):
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVc=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   iQUMlausXwdvtNjnFSBJPbKzEhoOVq={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Post',iQUMlausXwdvtNjnFSBJPbKzEhoOVc,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOVq,params=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVy in iQUMlausXwdvtNjnFSBJPbKzEhoOVL.cookies:
    if iQUMlausXwdvtNjnFSBJPbKzEhoOVy.name=='_tving_token':
     iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_token']=iQUMlausXwdvtNjnFSBJPbKzEhoOVy.value
    elif iQUMlausXwdvtNjnFSBJPbKzEhoOVy.name=='POC_USERINFO':
     iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_userinfo']=iQUMlausXwdvtNjnFSBJPbKzEhoOVy.value
    elif iQUMlausXwdvtNjnFSBJPbKzEhoOVy.name=='authToken':
     iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_authToken']=iQUMlausXwdvtNjnFSBJPbKzEhoOVy.value
   if not iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_token']:
    iQUMlausXwdvtNjnFSBJPbKzEhoOkL.Init_TV_Total()
    return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
   iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_maintoken']=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_token']
   if iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetProfileToken(user_pf)==iQUMlausXwdvtNjnFSBJPbKzEhoOLR:
    iQUMlausXwdvtNjnFSBJPbKzEhoOkL.Init_TV_Total()
    return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies'])
   iQUMlausXwdvtNjnFSBJPbKzEhoOVW =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDeviceList()
   if iQUMlausXwdvtNjnFSBJPbKzEhoOVW not in['','-']:
    iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_uuid']=iQUMlausXwdvtNjnFSBJPbKzEhoOVW+'-'+iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetUniqueid(iQUMlausXwdvtNjnFSBJPbKzEhoOVW)
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
   iQUMlausXwdvtNjnFSBJPbKzEhoOkL.Init_TV_Total()
   return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  return iQUMlausXwdvtNjnFSBJPbKzEhoOLx
 def GetProfileToken(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,user_pf):
  iQUMlausXwdvtNjnFSBJPbKzEhoOVm=[]
  iQUMlausXwdvtNjnFSBJPbKzEhoOVY =''
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   iQUMlausXwdvtNjnFSBJPbKzEhoOkf=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.makeDefaultCookies()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOVG,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOkf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVm =re.findall('data-profile-no="\d+"',iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(iQUMlausXwdvtNjnFSBJPbKzEhoOVm)
   for i in iQUMlausXwdvtNjnFSBJPbKzEhoOyV(iQUMlausXwdvtNjnFSBJPbKzEhoOyr(iQUMlausXwdvtNjnFSBJPbKzEhoOVm)):
    iQUMlausXwdvtNjnFSBJPbKzEhoOVp =iQUMlausXwdvtNjnFSBJPbKzEhoOVm[i].replace('data-profile-no=','').replace('"','')
    iQUMlausXwdvtNjnFSBJPbKzEhoOVm[i]=iQUMlausXwdvtNjnFSBJPbKzEhoOVp
   iQUMlausXwdvtNjnFSBJPbKzEhoOVY=iQUMlausXwdvtNjnFSBJPbKzEhoOVm[user_pf]
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
   iQUMlausXwdvtNjnFSBJPbKzEhoOkL.Init_TV_Total()
   return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   iQUMlausXwdvtNjnFSBJPbKzEhoOkf=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.makeDefaultCookies()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVq={'profileNo':iQUMlausXwdvtNjnFSBJPbKzEhoOVY}
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Post',iQUMlausXwdvtNjnFSBJPbKzEhoOVG,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOVq,params=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOkf)
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVy in iQUMlausXwdvtNjnFSBJPbKzEhoOVL.cookies:
    if iQUMlausXwdvtNjnFSBJPbKzEhoOVy.name=='_tving_token':
     iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_token']=iQUMlausXwdvtNjnFSBJPbKzEhoOVy.value
    elif iQUMlausXwdvtNjnFSBJPbKzEhoOVy.name==iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GLOBAL_COOKIENM['tv_cookiekey']:
     iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_cookiekey']=iQUMlausXwdvtNjnFSBJPbKzEhoOVy.value
    elif iQUMlausXwdvtNjnFSBJPbKzEhoOVy.name==iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GLOBAL_COOKIENM['tv_lockkey']:
     iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_lockkey']=iQUMlausXwdvtNjnFSBJPbKzEhoOVy.value
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
   iQUMlausXwdvtNjnFSBJPbKzEhoOkL.Init_TV_Total()
   return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  return iQUMlausXwdvtNjnFSBJPbKzEhoOLx
 def GetDeviceList(iQUMlausXwdvtNjnFSBJPbKzEhoOkL):
  iQUMlausXwdvtNjnFSBJPbKzEhoOVe=[]
  iQUMlausXwdvtNjnFSBJPbKzEhoOVT='-'
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v1/user/device/list'
   iQUMlausXwdvtNjnFSBJPbKzEhoOVA=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVG
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams()
   iQUMlausXwdvtNjnFSBJPbKzEhoOkf=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.makeDefaultCookies()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOVA,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOVf,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOkf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVH=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVe=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVI in iQUMlausXwdvtNjnFSBJPbKzEhoOVe:
    if iQUMlausXwdvtNjnFSBJPbKzEhoOVI['model'].lower().startswith('pc'):
     iQUMlausXwdvtNjnFSBJPbKzEhoOVT=iQUMlausXwdvtNjnFSBJPbKzEhoOVI['uuid']
     break
   if iQUMlausXwdvtNjnFSBJPbKzEhoOVT=='-':
    iQUMlausXwdvtNjnFSBJPbKzEhoOVT=iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetNoCache(timetype=1))
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOVT
 def Get_Now_Datetime(iQUMlausXwdvtNjnFSBJPbKzEhoOkL):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def make_stream_header(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,iQUMlausXwdvtNjnFSBJPbKzEhoOgk,iQUMlausXwdvtNjnFSBJPbKzEhoOkf):
  iQUMlausXwdvtNjnFSBJPbKzEhoOVR=''
  if iQUMlausXwdvtNjnFSBJPbKzEhoOkf not in[{},iQUMlausXwdvtNjnFSBJPbKzEhoOLD,'']:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVC=iQUMlausXwdvtNjnFSBJPbKzEhoOyr(iQUMlausXwdvtNjnFSBJPbKzEhoOkf)
   for iQUMlausXwdvtNjnFSBJPbKzEhoOkH,iQUMlausXwdvtNjnFSBJPbKzEhoOVx in iQUMlausXwdvtNjnFSBJPbKzEhoOkf.items():
    iQUMlausXwdvtNjnFSBJPbKzEhoOVR+='{}={}'.format(iQUMlausXwdvtNjnFSBJPbKzEhoOkH,iQUMlausXwdvtNjnFSBJPbKzEhoOVx)
    iQUMlausXwdvtNjnFSBJPbKzEhoOVC+=-1
    if iQUMlausXwdvtNjnFSBJPbKzEhoOVC>0:iQUMlausXwdvtNjnFSBJPbKzEhoOVR+='; '
   iQUMlausXwdvtNjnFSBJPbKzEhoOgk['cookie']=iQUMlausXwdvtNjnFSBJPbKzEhoOVR
  iQUMlausXwdvtNjnFSBJPbKzEhoOgV=''
  i=0
  for iQUMlausXwdvtNjnFSBJPbKzEhoOkH,iQUMlausXwdvtNjnFSBJPbKzEhoOVx in iQUMlausXwdvtNjnFSBJPbKzEhoOgk.items():
   i=i+1
   if i>1:iQUMlausXwdvtNjnFSBJPbKzEhoOgV+='&'
   iQUMlausXwdvtNjnFSBJPbKzEhoOgV+='{}={}'.format(iQUMlausXwdvtNjnFSBJPbKzEhoOkH,urllib.parse.quote(iQUMlausXwdvtNjnFSBJPbKzEhoOVx))
  return iQUMlausXwdvtNjnFSBJPbKzEhoOgV
 def GetBroadURL(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,mediacode,sel_quality,stype,pvrmode='-',optUHD=iQUMlausXwdvtNjnFSBJPbKzEhoOLR):
  iQUMlausXwdvtNjnFSBJPbKzEhoOgr ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','subtitleYn':iQUMlausXwdvtNjnFSBJPbKzEhoOLR,'error_msg':'',}
  iQUMlausXwdvtNjnFSBJPbKzEhoOVT =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_uuid'].split('-')[0] 
  iQUMlausXwdvtNjnFSBJPbKzEhoOgc =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_uuid'] 
  iQUMlausXwdvtNjnFSBJPbKzEhoOgq=iQUMlausXwdvtNjnFSBJPbKzEhoOLR 
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOgL=iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetNoCache(1))
   if stype!='tvingtv':
    iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v2/media/stream/info' 
    iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams()
    iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':iQUMlausXwdvtNjnFSBJPbKzEhoOgc,'deviceInfo':'PC','noCache':iQUMlausXwdvtNjnFSBJPbKzEhoOgL,}
    iQUMlausXwdvtNjnFSBJPbKzEhoOgy.update(iQUMlausXwdvtNjnFSBJPbKzEhoOVf)
    iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVG
    iQUMlausXwdvtNjnFSBJPbKzEhoOkf=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.makeDefaultCookies()
    iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOgy,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOkf)
    if iQUMlausXwdvtNjnFSBJPbKzEhoOVL.status_code!=200:
     iQUMlausXwdvtNjnFSBJPbKzEhoOgr['error_msg']='First Step - {} error'.format(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.status_code)
     return iQUMlausXwdvtNjnFSBJPbKzEhoOgr
    iQUMlausXwdvtNjnFSBJPbKzEhoOVH=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
    if iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['result']['code']=='060':
     for iQUMlausXwdvtNjnFSBJPbKzEhoOkH,iQUMlausXwdvtNjnFSBJPbKzEhoOVx in iQUMlausXwdvtNjnFSBJPbKzEhoOkg.items():
      if iQUMlausXwdvtNjnFSBJPbKzEhoOVx==sel_quality:
       iQUMlausXwdvtNjnFSBJPbKzEhoOgY=iQUMlausXwdvtNjnFSBJPbKzEhoOkH
    elif iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['result']['code']!='000':
     iQUMlausXwdvtNjnFSBJPbKzEhoOgr['error_msg']=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['result']['message']
     return iQUMlausXwdvtNjnFSBJPbKzEhoOgr
    else: 
     if not('stream' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']):return iQUMlausXwdvtNjnFSBJPbKzEhoOgr
     iQUMlausXwdvtNjnFSBJPbKzEhoOgG=[]
     for iQUMlausXwdvtNjnFSBJPbKzEhoOkH,iQUMlausXwdvtNjnFSBJPbKzEhoOVx in iQUMlausXwdvtNjnFSBJPbKzEhoOkg.items():
      for iQUMlausXwdvtNjnFSBJPbKzEhoOVI in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['stream']['quality']:
       if iQUMlausXwdvtNjnFSBJPbKzEhoOVI['active']=='Y' and iQUMlausXwdvtNjnFSBJPbKzEhoOVI['code']==iQUMlausXwdvtNjnFSBJPbKzEhoOkH:
        iQUMlausXwdvtNjnFSBJPbKzEhoOgG.append({iQUMlausXwdvtNjnFSBJPbKzEhoOkg.get(iQUMlausXwdvtNjnFSBJPbKzEhoOVI['code']):iQUMlausXwdvtNjnFSBJPbKzEhoOVI['code']})
     iQUMlausXwdvtNjnFSBJPbKzEhoOgY=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.CheckQuality(sel_quality,iQUMlausXwdvtNjnFSBJPbKzEhoOgG)
     try:
      if optUHD==iQUMlausXwdvtNjnFSBJPbKzEhoOLx and iQUMlausXwdvtNjnFSBJPbKzEhoOgY=='stream50' and 'stream_support_info' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['content']['info']:
       if iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['content']['info']['stream_support_info']!=iQUMlausXwdvtNjnFSBJPbKzEhoOLD:
        if 'stream70' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['content']['info']['stream_support_info']:
         iQUMlausXwdvtNjnFSBJPbKzEhoOgY='stream70'
         iQUMlausXwdvtNjnFSBJPbKzEhoOgq =iQUMlausXwdvtNjnFSBJPbKzEhoOLx
     except:
      pass
     try:
      if optUHD==iQUMlausXwdvtNjnFSBJPbKzEhoOLx and iQUMlausXwdvtNjnFSBJPbKzEhoOgY=='stream50' and 'stream' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['content']['info']:
       if iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['content']['info']['stream']!=iQUMlausXwdvtNjnFSBJPbKzEhoOLD:
        for iQUMlausXwdvtNjnFSBJPbKzEhoOVI in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['content']['info']['stream']:
         if iQUMlausXwdvtNjnFSBJPbKzEhoOVI['code']=='stream70':
          iQUMlausXwdvtNjnFSBJPbKzEhoOgY='stream70'
          iQUMlausXwdvtNjnFSBJPbKzEhoOgq =iQUMlausXwdvtNjnFSBJPbKzEhoOLx
          break
     except:
      pass
   else:
    iQUMlausXwdvtNjnFSBJPbKzEhoOgY='stream40'
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
   iQUMlausXwdvtNjnFSBJPbKzEhoOgr['error_msg']='First Step - except error'
   return iQUMlausXwdvtNjnFSBJPbKzEhoOgr
  iQUMlausXwdvtNjnFSBJPbKzEhoOLf(iQUMlausXwdvtNjnFSBJPbKzEhoOgY)
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOgL=iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetNoCache(1))
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v2a/media/stream/info'
   if iQUMlausXwdvtNjnFSBJPbKzEhoOgq==iQUMlausXwdvtNjnFSBJPbKzEhoOLx:
    iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams(uhd=iQUMlausXwdvtNjnFSBJPbKzEhoOLx)
    iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'mediaCode':mediacode,'noCache':iQUMlausXwdvtNjnFSBJPbKzEhoOgL,'streamType':'hls','streamCode':iQUMlausXwdvtNjnFSBJPbKzEhoOgY,'deviceId':iQUMlausXwdvtNjnFSBJPbKzEhoOVT,'adReq':'none','wm':'Y','ad_device':'','uuid':iQUMlausXwdvtNjnFSBJPbKzEhoOgc,'deviceInfo':'android_tv',}
   else:
    iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams()
    iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':iQUMlausXwdvtNjnFSBJPbKzEhoOgY,'deviceId':iQUMlausXwdvtNjnFSBJPbKzEhoOVT,'uuid':iQUMlausXwdvtNjnFSBJPbKzEhoOgc,'deviceInfo':'PC_Chrome','noCache':iQUMlausXwdvtNjnFSBJPbKzEhoOgL,'wm':'Y'}
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy.update(iQUMlausXwdvtNjnFSBJPbKzEhoOVf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVG
   iQUMlausXwdvtNjnFSBJPbKzEhoOkf=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.makeDefaultCookies()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOgy,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOkf,redirects=iQUMlausXwdvtNjnFSBJPbKzEhoOLx)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVH=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   if iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['result']['code']!='000':
    iQUMlausXwdvtNjnFSBJPbKzEhoOgr['error_msg']=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['result']['message']
    return iQUMlausXwdvtNjnFSBJPbKzEhoOgr
   iQUMlausXwdvtNjnFSBJPbKzEhoOgp=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['stream']
   if 'drm_license_assertion' in iQUMlausXwdvtNjnFSBJPbKzEhoOgp:
    iQUMlausXwdvtNjnFSBJPbKzEhoOgr['drm_license']=iQUMlausXwdvtNjnFSBJPbKzEhoOgp['drm_license_assertion']
    if '4k_nondrm_url' in iQUMlausXwdvtNjnFSBJPbKzEhoOgp['broadcast']and iQUMlausXwdvtNjnFSBJPbKzEhoOgq==iQUMlausXwdvtNjnFSBJPbKzEhoOLx:
     iQUMlausXwdvtNjnFSBJPbKzEhoOgW =iQUMlausXwdvtNjnFSBJPbKzEhoOgp['broadcast']['4k_nondrm_url']
     iQUMlausXwdvtNjnFSBJPbKzEhoOgr['drm_license']=''
    else:
     iQUMlausXwdvtNjnFSBJPbKzEhoOgW =iQUMlausXwdvtNjnFSBJPbKzEhoOgp['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in iQUMlausXwdvtNjnFSBJPbKzEhoOgp['broadcast']):return iQUMlausXwdvtNjnFSBJPbKzEhoOgr
    iQUMlausXwdvtNjnFSBJPbKzEhoOgW=iQUMlausXwdvtNjnFSBJPbKzEhoOgp['broadcast']['broad_url']
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
   iQUMlausXwdvtNjnFSBJPbKzEhoOgr['error_msg']='Second Step - except error'
   return iQUMlausXwdvtNjnFSBJPbKzEhoOgr
  iQUMlausXwdvtNjnFSBJPbKzEhoOge=iQUMlausXwdvtNjnFSBJPbKzEhoOgL
  iQUMlausXwdvtNjnFSBJPbKzEhoOgW=iQUMlausXwdvtNjnFSBJPbKzEhoOgW.split('|')[1]
  iQUMlausXwdvtNjnFSBJPbKzEhoOgW,iQUMlausXwdvtNjnFSBJPbKzEhoOgT,iQUMlausXwdvtNjnFSBJPbKzEhoOgA=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.Decrypt_Url(iQUMlausXwdvtNjnFSBJPbKzEhoOgW,mediacode,iQUMlausXwdvtNjnFSBJPbKzEhoOge)
  iQUMlausXwdvtNjnFSBJPbKzEhoOgr['streaming_url']=iQUMlausXwdvtNjnFSBJPbKzEhoOgW
  iQUMlausXwdvtNjnFSBJPbKzEhoOgr['watermark'] =iQUMlausXwdvtNjnFSBJPbKzEhoOgT
  iQUMlausXwdvtNjnFSBJPbKzEhoOgr['watermarkKey']=iQUMlausXwdvtNjnFSBJPbKzEhoOgA
  if 'subtitles' in iQUMlausXwdvtNjnFSBJPbKzEhoOgp:
   for iQUMlausXwdvtNjnFSBJPbKzEhoOgf in iQUMlausXwdvtNjnFSBJPbKzEhoOgp.get('subtitles'):
    if iQUMlausXwdvtNjnFSBJPbKzEhoOgf.get('code')in['KO','KO_CC']:
     iQUMlausXwdvtNjnFSBJPbKzEhoOgr['subtitleYn']=iQUMlausXwdvtNjnFSBJPbKzEhoOLx
     break
  return iQUMlausXwdvtNjnFSBJPbKzEhoOgr
 def Tving_Parse_mpd(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,stream_url,watermarkKey=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,watermark=iQUMlausXwdvtNjnFSBJPbKzEhoOLD):
  if watermarkKey not in['',iQUMlausXwdvtNjnFSBJPbKzEhoOLD]:
   iQUMlausXwdvtNjnFSBJPbKzEhoOgk={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,'Access-Control-Request-Headers':'x-tving-param1,x-tving-param2',}
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=requests.get(url=stream_url,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOgk,allow_redirects=iQUMlausXwdvtNjnFSBJPbKzEhoOLR)
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.status_code)+' - '+iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.url))
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf('')
  else:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=requests.get(url=stream_url)
  iQUMlausXwdvtNjnFSBJPbKzEhoOgH=iQUMlausXwdvtNjnFSBJPbKzEhoOVL.content.decode('utf-8')
  iQUMlausXwdvtNjnFSBJPbKzEhoOgI=0
  iQUMlausXwdvtNjnFSBJPbKzEhoOgD =ET.ElementTree(ET.fromstring(iQUMlausXwdvtNjnFSBJPbKzEhoOgH))
  iQUMlausXwdvtNjnFSBJPbKzEhoOgR =iQUMlausXwdvtNjnFSBJPbKzEhoOgD.getroot()
  iQUMlausXwdvtNjnFSBJPbKzEhoOgC=re.match(r'\{.*\}',iQUMlausXwdvtNjnFSBJPbKzEhoOgR.tag)[0] 
  iQUMlausXwdvtNjnFSBJPbKzEhoOgx=iQUMlausXwdvtNjnFSBJPbKzEhoOyq([node for _,node in ET.iterparse(io.StringIO(iQUMlausXwdvtNjnFSBJPbKzEhoOgH),events=['start-ns'])])
  for iQUMlausXwdvtNjnFSBJPbKzEhoOkH,iQUMlausXwdvtNjnFSBJPbKzEhoOrf in iQUMlausXwdvtNjnFSBJPbKzEhoOgx.items():
   if iQUMlausXwdvtNjnFSBJPbKzEhoOkH!='ns2':
    ET.register_namespace(iQUMlausXwdvtNjnFSBJPbKzEhoOkH,iQUMlausXwdvtNjnFSBJPbKzEhoOrf)
  iQUMlausXwdvtNjnFSBJPbKzEhoOrk=iQUMlausXwdvtNjnFSBJPbKzEhoOgR.find(iQUMlausXwdvtNjnFSBJPbKzEhoOgC+'Period')
  for iQUMlausXwdvtNjnFSBJPbKzEhoOrV in iQUMlausXwdvtNjnFSBJPbKzEhoOrk.findall(iQUMlausXwdvtNjnFSBJPbKzEhoOgC+'AdaptationSet'):
   if iQUMlausXwdvtNjnFSBJPbKzEhoOrV.attrib.get('mimeType')=='video/mp4':
    for iQUMlausXwdvtNjnFSBJPbKzEhoOrg in iQUMlausXwdvtNjnFSBJPbKzEhoOrV.findall(iQUMlausXwdvtNjnFSBJPbKzEhoOgC+'Representation'):
     iQUMlausXwdvtNjnFSBJPbKzEhoOrc=iQUMlausXwdvtNjnFSBJPbKzEhoOyk(iQUMlausXwdvtNjnFSBJPbKzEhoOrg.attrib.get('bandwidth'))
     if iQUMlausXwdvtNjnFSBJPbKzEhoOgI<iQUMlausXwdvtNjnFSBJPbKzEhoOrc:iQUMlausXwdvtNjnFSBJPbKzEhoOgI=iQUMlausXwdvtNjnFSBJPbKzEhoOrc
    for iQUMlausXwdvtNjnFSBJPbKzEhoOrg in iQUMlausXwdvtNjnFSBJPbKzEhoOrV.findall(iQUMlausXwdvtNjnFSBJPbKzEhoOgC+'Representation'):
     if iQUMlausXwdvtNjnFSBJPbKzEhoOgI>iQUMlausXwdvtNjnFSBJPbKzEhoOyk(iQUMlausXwdvtNjnFSBJPbKzEhoOrg.attrib.get('bandwidth')):
      iQUMlausXwdvtNjnFSBJPbKzEhoOrV.remove(iQUMlausXwdvtNjnFSBJPbKzEhoOrg)
   else:
    continue
  iQUMlausXwdvtNjnFSBJPbKzEhoOrq=ET.tostring(iQUMlausXwdvtNjnFSBJPbKzEhoOgR).decode('utf-8')
  iQUMlausXwdvtNjnFSBJPbKzEhoOrL='<?xml version="1.0" encoding="UTF-8"?>\n'
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TextFile_Save(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV_STREAM_FILENAME,iQUMlausXwdvtNjnFSBJPbKzEhoOrL+iQUMlausXwdvtNjnFSBJPbKzEhoOrq)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOLx
 def Tving_Parse_m3u8(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,stream_url):
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=requests.get(url=stream_url,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,stream=iQUMlausXwdvtNjnFSBJPbKzEhoOLx)
   iQUMlausXwdvtNjnFSBJPbKzEhoOry=iQUMlausXwdvtNjnFSBJPbKzEhoOVL.content.decode('utf-8')
   if '#EXTM3U' not in iQUMlausXwdvtNjnFSBJPbKzEhoOry:
    return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
   if '#EXT-X-STREAM-INF' not in iQUMlausXwdvtNjnFSBJPbKzEhoOry: 
    return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
   iQUMlausXwdvtNjnFSBJPbKzEhoOrm=0
   for iQUMlausXwdvtNjnFSBJPbKzEhoOrY in iQUMlausXwdvtNjnFSBJPbKzEhoOry.splitlines():
    if iQUMlausXwdvtNjnFSBJPbKzEhoOrY.startswith('#EXT-X-STREAM-INF'):
     iQUMlausXwdvtNjnFSBJPbKzEhoOrG=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.MediaLine_Parse(iQUMlausXwdvtNjnFSBJPbKzEhoOrY,'#EXT-X-STREAM-INF')
     if iQUMlausXwdvtNjnFSBJPbKzEhoOrm<iQUMlausXwdvtNjnFSBJPbKzEhoOyk(iQUMlausXwdvtNjnFSBJPbKzEhoOrG.get('BANDWIDTH')):
      iQUMlausXwdvtNjnFSBJPbKzEhoOrm=iQUMlausXwdvtNjnFSBJPbKzEhoOyk(iQUMlausXwdvtNjnFSBJPbKzEhoOrG.get('BANDWIDTH'))
   iQUMlausXwdvtNjnFSBJPbKzEhoOrp=[]
   iQUMlausXwdvtNjnFSBJPbKzEhoOrW=iQUMlausXwdvtNjnFSBJPbKzEhoOLR
   for iQUMlausXwdvtNjnFSBJPbKzEhoOrY in iQUMlausXwdvtNjnFSBJPbKzEhoOry.splitlines():
    if iQUMlausXwdvtNjnFSBJPbKzEhoOrW==iQUMlausXwdvtNjnFSBJPbKzEhoOLx:
     iQUMlausXwdvtNjnFSBJPbKzEhoOrW=iQUMlausXwdvtNjnFSBJPbKzEhoOLR
     continue
    if iQUMlausXwdvtNjnFSBJPbKzEhoOrY.startswith('#EXT-X-STREAM-INF'):
     iQUMlausXwdvtNjnFSBJPbKzEhoOrG=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.MediaLine_Parse(iQUMlausXwdvtNjnFSBJPbKzEhoOrY,'#EXT-X-STREAM-INF')
     if iQUMlausXwdvtNjnFSBJPbKzEhoOrm!=iQUMlausXwdvtNjnFSBJPbKzEhoOyk(iQUMlausXwdvtNjnFSBJPbKzEhoOrG.get('BANDWIDTH')):
      iQUMlausXwdvtNjnFSBJPbKzEhoOrW=iQUMlausXwdvtNjnFSBJPbKzEhoOLx
      continue
    iQUMlausXwdvtNjnFSBJPbKzEhoOrp.append(iQUMlausXwdvtNjnFSBJPbKzEhoOrY)
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
   return iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  iQUMlausXwdvtNjnFSBJPbKzEhoOre='\n'.join(iQUMlausXwdvtNjnFSBJPbKzEhoOrp)
  iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TextFile_Save(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV_STREAM_FILENAME,iQUMlausXwdvtNjnFSBJPbKzEhoOre)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOLx
 def MediaLine_Parse(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,iQUMlausXwdvtNjnFSBJPbKzEhoOrY,prefix):
  iQUMlausXwdvtNjnFSBJPbKzEhoOrG={}
  for iQUMlausXwdvtNjnFSBJPbKzEhoOrT in iQUMlausXwdvtNjnFSBJPbKzEhoOkc.split(iQUMlausXwdvtNjnFSBJPbKzEhoOrY.replace(prefix+':',''))[1::2]:
   iQUMlausXwdvtNjnFSBJPbKzEhoOrA,iQUMlausXwdvtNjnFSBJPbKzEhoOrf=iQUMlausXwdvtNjnFSBJPbKzEhoOrT.split('=',1)
   iQUMlausXwdvtNjnFSBJPbKzEhoOrG[iQUMlausXwdvtNjnFSBJPbKzEhoOrA.upper()]=iQUMlausXwdvtNjnFSBJPbKzEhoOrf.replace('"','').strip()
  return iQUMlausXwdvtNjnFSBJPbKzEhoOrG
 def CheckQuality(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,sel_qt,iQUMlausXwdvtNjnFSBJPbKzEhoOgG):
  for iQUMlausXwdvtNjnFSBJPbKzEhoOrH in iQUMlausXwdvtNjnFSBJPbKzEhoOgG:
   if sel_qt>=iQUMlausXwdvtNjnFSBJPbKzEhoOyL(iQUMlausXwdvtNjnFSBJPbKzEhoOrH)[0]:return iQUMlausXwdvtNjnFSBJPbKzEhoOrH.get(iQUMlausXwdvtNjnFSBJPbKzEhoOyL(iQUMlausXwdvtNjnFSBJPbKzEhoOrH)[0])
   iQUMlausXwdvtNjnFSBJPbKzEhoOrI=iQUMlausXwdvtNjnFSBJPbKzEhoOrH.get(iQUMlausXwdvtNjnFSBJPbKzEhoOyL(iQUMlausXwdvtNjnFSBJPbKzEhoOrH)[0])
  return iQUMlausXwdvtNjnFSBJPbKzEhoOrI
 def makeOocUrl(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,ooc_params):
  iQUMlausXwdvtNjnFSBJPbKzEhoOgm=''
  for iQUMlausXwdvtNjnFSBJPbKzEhoOkH,iQUMlausXwdvtNjnFSBJPbKzEhoOVx in ooc_params.items():
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm+="%s=%s^"%(iQUMlausXwdvtNjnFSBJPbKzEhoOkH,iQUMlausXwdvtNjnFSBJPbKzEhoOVx)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOgm
 def GetLiveChannelList(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,stype,page_int):
  iQUMlausXwdvtNjnFSBJPbKzEhoOVe=[]
  iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v2/media/lives'
   if stype=='onair': 
    iQUMlausXwdvtNjnFSBJPbKzEhoOrR='CPCS0100,CPCS0400'
   else:
    iQUMlausXwdvtNjnFSBJPbKzEhoOrR='CPCS0300'
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'cacheType':'main','pageNo':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(page_int),'pageSize':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':iQUMlausXwdvtNjnFSBJPbKzEhoOrR,}
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy.update(iQUMlausXwdvtNjnFSBJPbKzEhoOVf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVG
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOgy,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVH=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   if not('result' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']):return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
   iQUMlausXwdvtNjnFSBJPbKzEhoOrC=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['result']
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVI in iQUMlausXwdvtNjnFSBJPbKzEhoOrC:
    iQUMlausXwdvtNjnFSBJPbKzEhoOrx=iQUMlausXwdvtNjnFSBJPbKzEhoOcg=iQUMlausXwdvtNjnFSBJPbKzEhoOcr=''
    iQUMlausXwdvtNjnFSBJPbKzEhoOck=iQUMlausXwdvtNjnFSBJPbKzEhoOcC=''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcV=iQUMlausXwdvtNjnFSBJPbKzEhoOVI['live_code']
    iQUMlausXwdvtNjnFSBJPbKzEhoOrx =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['channel']['name']['ko']
    if iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['episode']!=iQUMlausXwdvtNjnFSBJPbKzEhoOLD:
     iQUMlausXwdvtNjnFSBJPbKzEhoOcg =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['program']['name']['ko']
     iQUMlausXwdvtNjnFSBJPbKzEhoOcg =iQUMlausXwdvtNjnFSBJPbKzEhoOcg+', '+iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['episode']['frequency'])+'회'
     iQUMlausXwdvtNjnFSBJPbKzEhoOcr=iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['episode']['synopsis']['ko']
    else:
     iQUMlausXwdvtNjnFSBJPbKzEhoOcg =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['program']['name']['ko']
     iQUMlausXwdvtNjnFSBJPbKzEhoOcr=iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['program']['synopsis']['ko']
    try: 
     iQUMlausXwdvtNjnFSBJPbKzEhoOcq =''
     iQUMlausXwdvtNjnFSBJPbKzEhoOcL =''
     iQUMlausXwdvtNjnFSBJPbKzEhoOcy=''
     iQUMlausXwdvtNjnFSBJPbKzEhoOcm =''
     iQUMlausXwdvtNjnFSBJPbKzEhoOcY =''
     iQUMlausXwdvtNjnFSBJPbKzEhoOcG =''
     for iQUMlausXwdvtNjnFSBJPbKzEhoOcp in iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['program']['image']:
      if iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP0900':iQUMlausXwdvtNjnFSBJPbKzEhoOcL =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
      elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP1800':iQUMlausXwdvtNjnFSBJPbKzEhoOcy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
      elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP2000':iQUMlausXwdvtNjnFSBJPbKzEhoOcm =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
      elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP1900':iQUMlausXwdvtNjnFSBJPbKzEhoOcY =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
      elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP0200':iQUMlausXwdvtNjnFSBJPbKzEhoOcG =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
      elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP0500':iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
      elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP0800':iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     if iQUMlausXwdvtNjnFSBJPbKzEhoOcq=='':
      for iQUMlausXwdvtNjnFSBJPbKzEhoOcp in iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['channel']['image']:
       if iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIC0400':iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
       elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIC1400':iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
       elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIC1900':iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
    except:
     iQUMlausXwdvtNjnFSBJPbKzEhoOLD
    try:
     iQUMlausXwdvtNjnFSBJPbKzEhoOcW =[]
     iQUMlausXwdvtNjnFSBJPbKzEhoOce=[]
     iQUMlausXwdvtNjnFSBJPbKzEhoOcT =[]
     iQUMlausXwdvtNjnFSBJPbKzEhoOcA=''
     iQUMlausXwdvtNjnFSBJPbKzEhoOcf=''
     iQUMlausXwdvtNjnFSBJPbKzEhoOcH=''
     for iQUMlausXwdvtNjnFSBJPbKzEhoOcI in iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('schedule').get('program').get('actor'):
      if iQUMlausXwdvtNjnFSBJPbKzEhoOcI!='' and iQUMlausXwdvtNjnFSBJPbKzEhoOcI!=u'없음':iQUMlausXwdvtNjnFSBJPbKzEhoOcW.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcI)
     for iQUMlausXwdvtNjnFSBJPbKzEhoOcD in iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('schedule').get('program').get('director'):
      if iQUMlausXwdvtNjnFSBJPbKzEhoOcD!='' and iQUMlausXwdvtNjnFSBJPbKzEhoOcD!='-' and iQUMlausXwdvtNjnFSBJPbKzEhoOcD!=u'없음':iQUMlausXwdvtNjnFSBJPbKzEhoOce.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcD)
     if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('schedule').get('program').get('category1_name').get('ko')!='':
      iQUMlausXwdvtNjnFSBJPbKzEhoOcT.append(iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['program']['category1_name']['ko'])
     if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('schedule').get('program').get('category2_name').get('ko')!='':
      iQUMlausXwdvtNjnFSBJPbKzEhoOcT.append(iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['program']['category2_name']['ko'])
     if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('schedule').get('program').get('product_year'):iQUMlausXwdvtNjnFSBJPbKzEhoOcA=iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['program']['product_year']
     if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('schedule').get('program').get('grade_code') :iQUMlausXwdvtNjnFSBJPbKzEhoOcf= iQUMlausXwdvtNjnFSBJPbKzEhoOkr.get(iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['program']['grade_code'])
     if 'broad_dt' in iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('schedule').get('program'):
      iQUMlausXwdvtNjnFSBJPbKzEhoOcR =iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('schedule').get('program').get('broad_dt')
      iQUMlausXwdvtNjnFSBJPbKzEhoOcH='%s-%s-%s'%(iQUMlausXwdvtNjnFSBJPbKzEhoOcR[:4],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[4:6],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[6:])
    except:
     iQUMlausXwdvtNjnFSBJPbKzEhoOLD
    iQUMlausXwdvtNjnFSBJPbKzEhoOck=iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['broadcast_start_time'])[8:12]
    iQUMlausXwdvtNjnFSBJPbKzEhoOcC =iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOVI['schedule']['broadcast_end_time'])[8:12]
    iQUMlausXwdvtNjnFSBJPbKzEhoOcx={'channel':iQUMlausXwdvtNjnFSBJPbKzEhoOrx,'title':iQUMlausXwdvtNjnFSBJPbKzEhoOcg,'mediacode':iQUMlausXwdvtNjnFSBJPbKzEhoOcV,'thumbnail':{'poster':iQUMlausXwdvtNjnFSBJPbKzEhoOcL,'thumb':iQUMlausXwdvtNjnFSBJPbKzEhoOcq,'clearlogo':iQUMlausXwdvtNjnFSBJPbKzEhoOcy,'icon':iQUMlausXwdvtNjnFSBJPbKzEhoOcm,'fanart':iQUMlausXwdvtNjnFSBJPbKzEhoOcG},'synopsis':iQUMlausXwdvtNjnFSBJPbKzEhoOcr,'channelepg':' [%s:%s ~ %s:%s]'%(iQUMlausXwdvtNjnFSBJPbKzEhoOck[0:2],iQUMlausXwdvtNjnFSBJPbKzEhoOck[2:],iQUMlausXwdvtNjnFSBJPbKzEhoOcC[0:2],iQUMlausXwdvtNjnFSBJPbKzEhoOcC[2:]),'cast':iQUMlausXwdvtNjnFSBJPbKzEhoOcW,'director':iQUMlausXwdvtNjnFSBJPbKzEhoOce,'info_genre':iQUMlausXwdvtNjnFSBJPbKzEhoOcT,'year':iQUMlausXwdvtNjnFSBJPbKzEhoOcA,'mpaa':iQUMlausXwdvtNjnFSBJPbKzEhoOcf,'premiered':iQUMlausXwdvtNjnFSBJPbKzEhoOcH}
    iQUMlausXwdvtNjnFSBJPbKzEhoOVe.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcx)
   if iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['has_more']=='Y':
    iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLx
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
 def GetProgramList(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,genre,orderby,page_int,genreCode='all'):
  iQUMlausXwdvtNjnFSBJPbKzEhoOVe=[]
  iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  try:
   if genre=='PARAMOUNT':
    iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v2/media/paramount/episodes'
   else:
    iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v2/media/episodes'
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'cacheType':'main','pageSize':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(page_int),}
   if genre not in['all','PARAMOUNT']:iQUMlausXwdvtNjnFSBJPbKzEhoOVf['categoryCode']=genre
   if genreCode!='all' :iQUMlausXwdvtNjnFSBJPbKzEhoOVf['genreCode'] =genreCode 
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy.update(iQUMlausXwdvtNjnFSBJPbKzEhoOVf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVG
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOgy,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVH=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   if not('result' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']):return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
   iQUMlausXwdvtNjnFSBJPbKzEhoOrC=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['result']
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVI in iQUMlausXwdvtNjnFSBJPbKzEhoOrC:
    iQUMlausXwdvtNjnFSBJPbKzEhoOqk=iQUMlausXwdvtNjnFSBJPbKzEhoOVI['program']['code']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcg =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['program']['name']['ko']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcf =iQUMlausXwdvtNjnFSBJPbKzEhoOkr.get(iQUMlausXwdvtNjnFSBJPbKzEhoOVI['program'].get('grade_code'))
    iQUMlausXwdvtNjnFSBJPbKzEhoOcL =''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcq =''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcy=''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcm =''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcY =''
    for iQUMlausXwdvtNjnFSBJPbKzEhoOcp in iQUMlausXwdvtNjnFSBJPbKzEhoOVI['program']['image']:
     if iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP0900':iQUMlausXwdvtNjnFSBJPbKzEhoOcL =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP0200':iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP1800':iQUMlausXwdvtNjnFSBJPbKzEhoOcy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP2000':iQUMlausXwdvtNjnFSBJPbKzEhoOcm =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP1900':iQUMlausXwdvtNjnFSBJPbKzEhoOcY =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcr =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['program']['synopsis']['ko']
    try:
     iQUMlausXwdvtNjnFSBJPbKzEhoOqV=iQUMlausXwdvtNjnFSBJPbKzEhoOVI['channel']['name']['ko']
    except:
     iQUMlausXwdvtNjnFSBJPbKzEhoOqV=''
    try:
     iQUMlausXwdvtNjnFSBJPbKzEhoOcW =[]
     iQUMlausXwdvtNjnFSBJPbKzEhoOce=[]
     iQUMlausXwdvtNjnFSBJPbKzEhoOcT =[]
     iQUMlausXwdvtNjnFSBJPbKzEhoOcA =''
     iQUMlausXwdvtNjnFSBJPbKzEhoOcH=''
     for iQUMlausXwdvtNjnFSBJPbKzEhoOcI in iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('program').get('actor'):
      if iQUMlausXwdvtNjnFSBJPbKzEhoOcI!='' and iQUMlausXwdvtNjnFSBJPbKzEhoOcI!='-' and iQUMlausXwdvtNjnFSBJPbKzEhoOcI!=u'없음':iQUMlausXwdvtNjnFSBJPbKzEhoOcW.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcI)
     for iQUMlausXwdvtNjnFSBJPbKzEhoOcD in iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('program').get('director'):
      if iQUMlausXwdvtNjnFSBJPbKzEhoOcD!='' and iQUMlausXwdvtNjnFSBJPbKzEhoOcD!='-' and iQUMlausXwdvtNjnFSBJPbKzEhoOcD!=u'없음':iQUMlausXwdvtNjnFSBJPbKzEhoOce.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcD)
     if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('program').get('category1_name').get('ko')!='':
      iQUMlausXwdvtNjnFSBJPbKzEhoOcT.append(iQUMlausXwdvtNjnFSBJPbKzEhoOVI['program']['category1_name']['ko'])
     if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('program').get('category2_name').get('ko')!='':
      iQUMlausXwdvtNjnFSBJPbKzEhoOcT.append(iQUMlausXwdvtNjnFSBJPbKzEhoOVI['program']['category2_name']['ko'])
     if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('program').get('product_year'):iQUMlausXwdvtNjnFSBJPbKzEhoOcA=iQUMlausXwdvtNjnFSBJPbKzEhoOVI['program']['product_year']
     if 'broad_dt' in iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('program'):
      iQUMlausXwdvtNjnFSBJPbKzEhoOcR =iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('program').get('broad_dt')
      iQUMlausXwdvtNjnFSBJPbKzEhoOcH='%s-%s-%s'%(iQUMlausXwdvtNjnFSBJPbKzEhoOcR[:4],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[4:6],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[6:])
    except:
     iQUMlausXwdvtNjnFSBJPbKzEhoOLD
    iQUMlausXwdvtNjnFSBJPbKzEhoOcx={'program':iQUMlausXwdvtNjnFSBJPbKzEhoOqk,'title':iQUMlausXwdvtNjnFSBJPbKzEhoOcg,'thumbnail':{'poster':iQUMlausXwdvtNjnFSBJPbKzEhoOcL,'thumb':iQUMlausXwdvtNjnFSBJPbKzEhoOcq,'clearlogo':iQUMlausXwdvtNjnFSBJPbKzEhoOcy,'icon':iQUMlausXwdvtNjnFSBJPbKzEhoOcm,'banner':iQUMlausXwdvtNjnFSBJPbKzEhoOcY,'fanart':iQUMlausXwdvtNjnFSBJPbKzEhoOcq},'synopsis':iQUMlausXwdvtNjnFSBJPbKzEhoOcr,'channel':iQUMlausXwdvtNjnFSBJPbKzEhoOqV,'cast':iQUMlausXwdvtNjnFSBJPbKzEhoOcW,'director':iQUMlausXwdvtNjnFSBJPbKzEhoOce,'info_genre':iQUMlausXwdvtNjnFSBJPbKzEhoOcT,'year':iQUMlausXwdvtNjnFSBJPbKzEhoOcA,'premiered':iQUMlausXwdvtNjnFSBJPbKzEhoOcH,'mpaa':iQUMlausXwdvtNjnFSBJPbKzEhoOcf}
    iQUMlausXwdvtNjnFSBJPbKzEhoOVe.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcx)
   if iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['has_more']=='Y':iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLx
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
 def Get_UHD_ProgramList(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,page_int):
  iQUMlausXwdvtNjnFSBJPbKzEhoOVe=[]
  iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v2/operator/highlights'
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams(uhd=iQUMlausXwdvtNjnFSBJPbKzEhoOLx)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(page_int),'pocType':'APP_X_TVING_4.0.0',}
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy.update(iQUMlausXwdvtNjnFSBJPbKzEhoOVf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVG
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOgy,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVH=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   if not('result' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']):return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
   iQUMlausXwdvtNjnFSBJPbKzEhoOrC=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['result']
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVI in iQUMlausXwdvtNjnFSBJPbKzEhoOrC:
    iQUMlausXwdvtNjnFSBJPbKzEhoOqg=iQUMlausXwdvtNjnFSBJPbKzEhoOVI['content']['program']
    iQUMlausXwdvtNjnFSBJPbKzEhoOqr =iQUMlausXwdvtNjnFSBJPbKzEhoOqg['code']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcg =iQUMlausXwdvtNjnFSBJPbKzEhoOqg['name']['ko'].strip()
    iQUMlausXwdvtNjnFSBJPbKzEhoOcf =iQUMlausXwdvtNjnFSBJPbKzEhoOkr.get(iQUMlausXwdvtNjnFSBJPbKzEhoOqg.get('grade_code'))
    iQUMlausXwdvtNjnFSBJPbKzEhoOcr =iQUMlausXwdvtNjnFSBJPbKzEhoOqg['synopsis']['ko']
    iQUMlausXwdvtNjnFSBJPbKzEhoOqV =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['content']['channel']['name']['ko']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcA =iQUMlausXwdvtNjnFSBJPbKzEhoOqg['product_year']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcL =''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcq =''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcy=''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcm =''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcY =''
    for iQUMlausXwdvtNjnFSBJPbKzEhoOcp in iQUMlausXwdvtNjnFSBJPbKzEhoOqg['image']:
     if iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP0900':iQUMlausXwdvtNjnFSBJPbKzEhoOcL =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP0200':iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP1800':iQUMlausXwdvtNjnFSBJPbKzEhoOcy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP2000':iQUMlausXwdvtNjnFSBJPbKzEhoOcm =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP1900':iQUMlausXwdvtNjnFSBJPbKzEhoOcY =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcT =[]
    iQUMlausXwdvtNjnFSBJPbKzEhoOcW =[]
    iQUMlausXwdvtNjnFSBJPbKzEhoOce=[]
    iQUMlausXwdvtNjnFSBJPbKzEhoOcH =''
    if iQUMlausXwdvtNjnFSBJPbKzEhoOqg.get('category1_name').get('ko')!='':
     iQUMlausXwdvtNjnFSBJPbKzEhoOcT.append(iQUMlausXwdvtNjnFSBJPbKzEhoOqg['category1_name']['ko'])
    if iQUMlausXwdvtNjnFSBJPbKzEhoOqg.get('category2_name').get('ko')!='':
     iQUMlausXwdvtNjnFSBJPbKzEhoOcT.append(iQUMlausXwdvtNjnFSBJPbKzEhoOqg['category2_name']['ko'])
    for iQUMlausXwdvtNjnFSBJPbKzEhoOcI in iQUMlausXwdvtNjnFSBJPbKzEhoOqg.get('actor'):
     if iQUMlausXwdvtNjnFSBJPbKzEhoOcI!='' and iQUMlausXwdvtNjnFSBJPbKzEhoOcI!='-' and iQUMlausXwdvtNjnFSBJPbKzEhoOcI!=u'없음':iQUMlausXwdvtNjnFSBJPbKzEhoOcW.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcI)
    for iQUMlausXwdvtNjnFSBJPbKzEhoOcD in iQUMlausXwdvtNjnFSBJPbKzEhoOqg.get('director'):
     if iQUMlausXwdvtNjnFSBJPbKzEhoOcD!='' and iQUMlausXwdvtNjnFSBJPbKzEhoOcD!='-' and iQUMlausXwdvtNjnFSBJPbKzEhoOcD!=u'없음':iQUMlausXwdvtNjnFSBJPbKzEhoOce.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcD)
    if iQUMlausXwdvtNjnFSBJPbKzEhoOqg.get('broad_dt')not in[iQUMlausXwdvtNjnFSBJPbKzEhoOLD,'']:
     iQUMlausXwdvtNjnFSBJPbKzEhoOcR =iQUMlausXwdvtNjnFSBJPbKzEhoOqg.get('broad_dt')
     iQUMlausXwdvtNjnFSBJPbKzEhoOcH='%s-%s-%s'%(iQUMlausXwdvtNjnFSBJPbKzEhoOcR[:4],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[4:6],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[6:])
    iQUMlausXwdvtNjnFSBJPbKzEhoOcx={'program':iQUMlausXwdvtNjnFSBJPbKzEhoOqr,'title':iQUMlausXwdvtNjnFSBJPbKzEhoOcg,'mpaa':iQUMlausXwdvtNjnFSBJPbKzEhoOcf,'thumbnail':{'poster':iQUMlausXwdvtNjnFSBJPbKzEhoOcL,'thumb':iQUMlausXwdvtNjnFSBJPbKzEhoOcq,'clearlogo':iQUMlausXwdvtNjnFSBJPbKzEhoOcy,'icon':iQUMlausXwdvtNjnFSBJPbKzEhoOcm,'banner':iQUMlausXwdvtNjnFSBJPbKzEhoOcY,'fanart':iQUMlausXwdvtNjnFSBJPbKzEhoOcq},'channel':iQUMlausXwdvtNjnFSBJPbKzEhoOqV,'synopsis':iQUMlausXwdvtNjnFSBJPbKzEhoOcr,'year':iQUMlausXwdvtNjnFSBJPbKzEhoOcA,'info_genre':iQUMlausXwdvtNjnFSBJPbKzEhoOcT,'cast':iQUMlausXwdvtNjnFSBJPbKzEhoOcW,'director':iQUMlausXwdvtNjnFSBJPbKzEhoOce,'premiered':iQUMlausXwdvtNjnFSBJPbKzEhoOcH,}
    iQUMlausXwdvtNjnFSBJPbKzEhoOVe.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcx)
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
 def Get_Origianl_ProgramList(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,page_int):
  iQUMlausXwdvtNjnFSBJPbKzEhoOVe=[]
  iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v2/media/band/originals'
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'pageSize':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(page_int),}
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy.update(iQUMlausXwdvtNjnFSBJPbKzEhoOVf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVG
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOgy,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVH=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   if not('contents' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']):return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
   iQUMlausXwdvtNjnFSBJPbKzEhoOrC=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['contents']
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVI in iQUMlausXwdvtNjnFSBJPbKzEhoOrC:
    iQUMlausXwdvtNjnFSBJPbKzEhoOqk=iQUMlausXwdvtNjnFSBJPbKzEhoOVI['vod_code']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcg =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['vod_name']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcL =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVI['image']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcx={'program':iQUMlausXwdvtNjnFSBJPbKzEhoOqk,'title':iQUMlausXwdvtNjnFSBJPbKzEhoOcg,'thumbnail':{'poster':iQUMlausXwdvtNjnFSBJPbKzEhoOcL,'thumb':iQUMlausXwdvtNjnFSBJPbKzEhoOcL}}
    iQUMlausXwdvtNjnFSBJPbKzEhoOVe.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcx)
   if iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['has_more']=='Y':iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLx
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
 def GetEpisodeList(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,program_code,page_int,orderby='desc'):
  iQUMlausXwdvtNjnFSBJPbKzEhoOVe=[]
  iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v2/media/frequency/program/'+program_code
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy.update(iQUMlausXwdvtNjnFSBJPbKzEhoOVf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVG
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOgy,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVH=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   if not('result' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']):return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
   iQUMlausXwdvtNjnFSBJPbKzEhoOrC=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['result']
   iQUMlausXwdvtNjnFSBJPbKzEhoOqc=iQUMlausXwdvtNjnFSBJPbKzEhoOyk(iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['total_count'])
   iQUMlausXwdvtNjnFSBJPbKzEhoOqL =iQUMlausXwdvtNjnFSBJPbKzEhoOyk(iQUMlausXwdvtNjnFSBJPbKzEhoOqc//(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    iQUMlausXwdvtNjnFSBJPbKzEhoOqy =(iQUMlausXwdvtNjnFSBJPbKzEhoOqc-1)-((page_int-1)*iQUMlausXwdvtNjnFSBJPbKzEhoOkL.EPISODE_LIMIT)
   else:
    iQUMlausXwdvtNjnFSBJPbKzEhoOqy =(page_int-1)*iQUMlausXwdvtNjnFSBJPbKzEhoOkL.EPISODE_LIMIT
   for i in iQUMlausXwdvtNjnFSBJPbKzEhoOyV(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.EPISODE_LIMIT):
    if orderby=='desc':
     iQUMlausXwdvtNjnFSBJPbKzEhoOqm=iQUMlausXwdvtNjnFSBJPbKzEhoOqy-i
     if iQUMlausXwdvtNjnFSBJPbKzEhoOqm<0:break
    else:
     iQUMlausXwdvtNjnFSBJPbKzEhoOqm=iQUMlausXwdvtNjnFSBJPbKzEhoOqy+i
     if iQUMlausXwdvtNjnFSBJPbKzEhoOqm>=iQUMlausXwdvtNjnFSBJPbKzEhoOqc:break
    iQUMlausXwdvtNjnFSBJPbKzEhoOqY=iQUMlausXwdvtNjnFSBJPbKzEhoOrC[iQUMlausXwdvtNjnFSBJPbKzEhoOqm]['episode']['code']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcg =iQUMlausXwdvtNjnFSBJPbKzEhoOrC[iQUMlausXwdvtNjnFSBJPbKzEhoOqm]['vod_name']['ko']
    iQUMlausXwdvtNjnFSBJPbKzEhoOqG =''
    try:
     iQUMlausXwdvtNjnFSBJPbKzEhoOcR=iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOrC[iQUMlausXwdvtNjnFSBJPbKzEhoOqm]['episode']['broadcast_date'])
     iQUMlausXwdvtNjnFSBJPbKzEhoOqG='%s-%s-%s'%(iQUMlausXwdvtNjnFSBJPbKzEhoOcR[:4],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[4:6],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[6:])
    except:
     iQUMlausXwdvtNjnFSBJPbKzEhoOLD
    try:
     if iQUMlausXwdvtNjnFSBJPbKzEhoOrC[iQUMlausXwdvtNjnFSBJPbKzEhoOqm]['episode']['pip_cliptype']=='C012':
      iQUMlausXwdvtNjnFSBJPbKzEhoOqG+=' - Quick VOD'
    except:
     iQUMlausXwdvtNjnFSBJPbKzEhoOLD
    iQUMlausXwdvtNjnFSBJPbKzEhoOcr =iQUMlausXwdvtNjnFSBJPbKzEhoOrC[iQUMlausXwdvtNjnFSBJPbKzEhoOqm]['episode']['synopsis']['ko']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcL =''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcq =''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcy=''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcm =''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcY =''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcG =''
    for iQUMlausXwdvtNjnFSBJPbKzEhoOcp in iQUMlausXwdvtNjnFSBJPbKzEhoOrC[iQUMlausXwdvtNjnFSBJPbKzEhoOqm]['program']['image']:
     if iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP0900':iQUMlausXwdvtNjnFSBJPbKzEhoOcL =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP1800':iQUMlausXwdvtNjnFSBJPbKzEhoOcy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP2000':iQUMlausXwdvtNjnFSBJPbKzEhoOcm =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP1900':iQUMlausXwdvtNjnFSBJPbKzEhoOcY =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIP0200':iQUMlausXwdvtNjnFSBJPbKzEhoOcG =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
    for iQUMlausXwdvtNjnFSBJPbKzEhoOcp in iQUMlausXwdvtNjnFSBJPbKzEhoOrC[iQUMlausXwdvtNjnFSBJPbKzEhoOqm]['episode']['image']:
     if iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIE0400':iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
    try:
     iQUMlausXwdvtNjnFSBJPbKzEhoOqp=iQUMlausXwdvtNjnFSBJPbKzEhoOqe=iQUMlausXwdvtNjnFSBJPbKzEhoOqT=''
     iQUMlausXwdvtNjnFSBJPbKzEhoOqW=0
     iQUMlausXwdvtNjnFSBJPbKzEhoOqp =iQUMlausXwdvtNjnFSBJPbKzEhoOrC[iQUMlausXwdvtNjnFSBJPbKzEhoOqm]['program']['name']['ko']
     iQUMlausXwdvtNjnFSBJPbKzEhoOqe =iQUMlausXwdvtNjnFSBJPbKzEhoOqG
     iQUMlausXwdvtNjnFSBJPbKzEhoOqT =iQUMlausXwdvtNjnFSBJPbKzEhoOrC[iQUMlausXwdvtNjnFSBJPbKzEhoOqm]['channel']['name']['ko']
     if 'frequency' in iQUMlausXwdvtNjnFSBJPbKzEhoOrC[iQUMlausXwdvtNjnFSBJPbKzEhoOqm]['episode']:iQUMlausXwdvtNjnFSBJPbKzEhoOqW=iQUMlausXwdvtNjnFSBJPbKzEhoOrC[iQUMlausXwdvtNjnFSBJPbKzEhoOqm]['episode']['frequency']
    except:
     iQUMlausXwdvtNjnFSBJPbKzEhoOLD
    iQUMlausXwdvtNjnFSBJPbKzEhoOcx={'episode':iQUMlausXwdvtNjnFSBJPbKzEhoOqY,'title':iQUMlausXwdvtNjnFSBJPbKzEhoOcg,'subtitle':iQUMlausXwdvtNjnFSBJPbKzEhoOqG,'thumbnail':{'poster':iQUMlausXwdvtNjnFSBJPbKzEhoOcL,'thumb':iQUMlausXwdvtNjnFSBJPbKzEhoOcq,'clearlogo':iQUMlausXwdvtNjnFSBJPbKzEhoOcy,'icon':iQUMlausXwdvtNjnFSBJPbKzEhoOcm,'banner':iQUMlausXwdvtNjnFSBJPbKzEhoOcY,'fanart':iQUMlausXwdvtNjnFSBJPbKzEhoOcG},'synopsis':iQUMlausXwdvtNjnFSBJPbKzEhoOcr,'info_title':iQUMlausXwdvtNjnFSBJPbKzEhoOqp,'aired':iQUMlausXwdvtNjnFSBJPbKzEhoOqe,'studio':iQUMlausXwdvtNjnFSBJPbKzEhoOqT,'frequency':iQUMlausXwdvtNjnFSBJPbKzEhoOqW}
    iQUMlausXwdvtNjnFSBJPbKzEhoOVe.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcx)
   if iQUMlausXwdvtNjnFSBJPbKzEhoOqL>page_int:iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLx
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD,iQUMlausXwdvtNjnFSBJPbKzEhoOqL
 def GetMovieList(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,genre,orderby,page_int):
  iQUMlausXwdvtNjnFSBJPbKzEhoOVe=[]
  iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  try:
   if genre=='PARAMOUNT':
    iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v2/media/paramount/movies'
   else:
    iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v2/media/movies'
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'pageSize':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:iQUMlausXwdvtNjnFSBJPbKzEhoOVf['categoryCode']=genre
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf['productPackageCode']=','.join(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.MOVIE_LITE)
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy.update(iQUMlausXwdvtNjnFSBJPbKzEhoOVf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVG
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOgy,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVH=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   if not('result' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']):return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
   iQUMlausXwdvtNjnFSBJPbKzEhoOrC=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['result']
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVI in iQUMlausXwdvtNjnFSBJPbKzEhoOrC:
    if 'release_date' in iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('movie'):
     iQUMlausXwdvtNjnFSBJPbKzEhoOcA=iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('movie').get('release_date'))[:4]
    else:
     iQUMlausXwdvtNjnFSBJPbKzEhoOcA=iQUMlausXwdvtNjnFSBJPbKzEhoOLD
    iQUMlausXwdvtNjnFSBJPbKzEhoOqA =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['movie']['code']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcg =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['movie']['name']['ko'].strip()
    if iQUMlausXwdvtNjnFSBJPbKzEhoOcA not in[iQUMlausXwdvtNjnFSBJPbKzEhoOLD,'0','']:iQUMlausXwdvtNjnFSBJPbKzEhoOcg+=u' (%s)'%(iQUMlausXwdvtNjnFSBJPbKzEhoOcA)
    iQUMlausXwdvtNjnFSBJPbKzEhoOcL=''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcq =''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcy=''
    for iQUMlausXwdvtNjnFSBJPbKzEhoOcp in iQUMlausXwdvtNjnFSBJPbKzEhoOVI['movie']['image']:
     if iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIM2100':iQUMlausXwdvtNjnFSBJPbKzEhoOcL =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIM0400':iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIM1800':iQUMlausXwdvtNjnFSBJPbKzEhoOcy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcr =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['movie']['story']['ko']
    try:
     iQUMlausXwdvtNjnFSBJPbKzEhoOqp =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['movie']['name']['ko'].strip()
     iQUMlausXwdvtNjnFSBJPbKzEhoOcf =iQUMlausXwdvtNjnFSBJPbKzEhoOkr.get(iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('grade_code'))
     iQUMlausXwdvtNjnFSBJPbKzEhoOcW=[]
     iQUMlausXwdvtNjnFSBJPbKzEhoOce=[]
     iQUMlausXwdvtNjnFSBJPbKzEhoOcT=[]
     iQUMlausXwdvtNjnFSBJPbKzEhoOqf=0
     iQUMlausXwdvtNjnFSBJPbKzEhoOcH=''
     iQUMlausXwdvtNjnFSBJPbKzEhoOqT =''
     for iQUMlausXwdvtNjnFSBJPbKzEhoOcI in iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('movie').get('actor'):
      if iQUMlausXwdvtNjnFSBJPbKzEhoOcI!='':iQUMlausXwdvtNjnFSBJPbKzEhoOcW.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcI)
     for iQUMlausXwdvtNjnFSBJPbKzEhoOcD in iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('movie').get('director'):
      if iQUMlausXwdvtNjnFSBJPbKzEhoOcD!='':iQUMlausXwdvtNjnFSBJPbKzEhoOce.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcD)
     if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('movie').get('category1_name').get('ko')!='':
      iQUMlausXwdvtNjnFSBJPbKzEhoOcT.append(iQUMlausXwdvtNjnFSBJPbKzEhoOVI['movie']['category1_name']['ko'])
     if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('movie').get('category2_name').get('ko')!='':
      iQUMlausXwdvtNjnFSBJPbKzEhoOcT.append(iQUMlausXwdvtNjnFSBJPbKzEhoOVI['movie']['category2_name']['ko'])
     if 'duration' in iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('movie'):iQUMlausXwdvtNjnFSBJPbKzEhoOqf=iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('movie').get('duration')
     if 'release_date' in iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('movie'):
      iQUMlausXwdvtNjnFSBJPbKzEhoOcR=iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('movie').get('release_date'))
      if iQUMlausXwdvtNjnFSBJPbKzEhoOcR!='0':iQUMlausXwdvtNjnFSBJPbKzEhoOcH='%s-%s-%s'%(iQUMlausXwdvtNjnFSBJPbKzEhoOcR[:4],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[4:6],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[6:])
     if 'production' in iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('movie'):iQUMlausXwdvtNjnFSBJPbKzEhoOqT=iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('movie').get('production')
    except:
     iQUMlausXwdvtNjnFSBJPbKzEhoOLD
    iQUMlausXwdvtNjnFSBJPbKzEhoOcx={'moviecode':iQUMlausXwdvtNjnFSBJPbKzEhoOqA,'title':iQUMlausXwdvtNjnFSBJPbKzEhoOcg,'thumbnail':{'poster':iQUMlausXwdvtNjnFSBJPbKzEhoOcL,'thumb':iQUMlausXwdvtNjnFSBJPbKzEhoOcq,'clearlogo':iQUMlausXwdvtNjnFSBJPbKzEhoOcy,'fanart':iQUMlausXwdvtNjnFSBJPbKzEhoOcq},'synopsis':iQUMlausXwdvtNjnFSBJPbKzEhoOcr,'info_title':iQUMlausXwdvtNjnFSBJPbKzEhoOqp,'year':iQUMlausXwdvtNjnFSBJPbKzEhoOcA,'cast':iQUMlausXwdvtNjnFSBJPbKzEhoOcW,'director':iQUMlausXwdvtNjnFSBJPbKzEhoOce,'info_genre':iQUMlausXwdvtNjnFSBJPbKzEhoOcT,'duration':iQUMlausXwdvtNjnFSBJPbKzEhoOqf,'premiered':iQUMlausXwdvtNjnFSBJPbKzEhoOcH,'studio':iQUMlausXwdvtNjnFSBJPbKzEhoOqT,'mpaa':iQUMlausXwdvtNjnFSBJPbKzEhoOcf}
    iQUMlausXwdvtNjnFSBJPbKzEhoOqH=iQUMlausXwdvtNjnFSBJPbKzEhoOLR
    for iQUMlausXwdvtNjnFSBJPbKzEhoOqI in iQUMlausXwdvtNjnFSBJPbKzEhoOVI['billing_package_id']:
     if iQUMlausXwdvtNjnFSBJPbKzEhoOqI in iQUMlausXwdvtNjnFSBJPbKzEhoOkL.MOVIE_LITE:
      iQUMlausXwdvtNjnFSBJPbKzEhoOqH=iQUMlausXwdvtNjnFSBJPbKzEhoOLx
      break
    if iQUMlausXwdvtNjnFSBJPbKzEhoOqH==iQUMlausXwdvtNjnFSBJPbKzEhoOLR: 
     iQUMlausXwdvtNjnFSBJPbKzEhoOcx['title']=iQUMlausXwdvtNjnFSBJPbKzEhoOcx['title']+' [개별구매]'
    iQUMlausXwdvtNjnFSBJPbKzEhoOVe.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcx)
   if iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['has_more']=='Y':iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLx
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
 def Get_UHD_MovieList(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,page_int):
  iQUMlausXwdvtNjnFSBJPbKzEhoOVe=[]
  iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v2/operator/highlights'
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams(uhd=iQUMlausXwdvtNjnFSBJPbKzEhoOLx)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(page_int),'pocType':'APP_X_TVING_4.0.0',}
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy.update(iQUMlausXwdvtNjnFSBJPbKzEhoOVf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVG
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOgy,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVH=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   if not('result' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']):return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
   iQUMlausXwdvtNjnFSBJPbKzEhoOrC=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['result']
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVI in iQUMlausXwdvtNjnFSBJPbKzEhoOrC:
    iQUMlausXwdvtNjnFSBJPbKzEhoOqg=iQUMlausXwdvtNjnFSBJPbKzEhoOVI['content']['movie']
    iQUMlausXwdvtNjnFSBJPbKzEhoOqr =iQUMlausXwdvtNjnFSBJPbKzEhoOqg['code']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcg =iQUMlausXwdvtNjnFSBJPbKzEhoOqg['name']['ko'].strip()
    iQUMlausXwdvtNjnFSBJPbKzEhoOqp =iQUMlausXwdvtNjnFSBJPbKzEhoOqg['name']['ko'].strip()
    iQUMlausXwdvtNjnFSBJPbKzEhoOcA =iQUMlausXwdvtNjnFSBJPbKzEhoOqg['product_year']
    if iQUMlausXwdvtNjnFSBJPbKzEhoOcA:iQUMlausXwdvtNjnFSBJPbKzEhoOcg+=u' (%s)'%(iQUMlausXwdvtNjnFSBJPbKzEhoOqg['product_year'])
    iQUMlausXwdvtNjnFSBJPbKzEhoOcr =iQUMlausXwdvtNjnFSBJPbKzEhoOqg['story']['ko']
    iQUMlausXwdvtNjnFSBJPbKzEhoOqf =iQUMlausXwdvtNjnFSBJPbKzEhoOqg['duration']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcf =iQUMlausXwdvtNjnFSBJPbKzEhoOkr.get(iQUMlausXwdvtNjnFSBJPbKzEhoOqg.get('grade_code'))
    iQUMlausXwdvtNjnFSBJPbKzEhoOqT =iQUMlausXwdvtNjnFSBJPbKzEhoOqg['production']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcL=''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcq =''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcy=''
    iQUMlausXwdvtNjnFSBJPbKzEhoOcT =[]
    iQUMlausXwdvtNjnFSBJPbKzEhoOcW =[]
    iQUMlausXwdvtNjnFSBJPbKzEhoOce=[]
    iQUMlausXwdvtNjnFSBJPbKzEhoOcH =''
    for iQUMlausXwdvtNjnFSBJPbKzEhoOcp in iQUMlausXwdvtNjnFSBJPbKzEhoOqg['image']:
     if iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIM2100':iQUMlausXwdvtNjnFSBJPbKzEhoOcL =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIM0400':iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
     elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp['code']=='CAIM1800':iQUMlausXwdvtNjnFSBJPbKzEhoOcy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp['url']
    if iQUMlausXwdvtNjnFSBJPbKzEhoOqg['release_date']not in[iQUMlausXwdvtNjnFSBJPbKzEhoOLD,0]:
     iQUMlausXwdvtNjnFSBJPbKzEhoOcR=iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOqg['release_date'])
     if iQUMlausXwdvtNjnFSBJPbKzEhoOcR!='0':iQUMlausXwdvtNjnFSBJPbKzEhoOcH='%s-%s-%s'%(iQUMlausXwdvtNjnFSBJPbKzEhoOcR[:4],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[4:6],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[6:])
    if iQUMlausXwdvtNjnFSBJPbKzEhoOqg.get('category1_name').get('ko')!='':
     iQUMlausXwdvtNjnFSBJPbKzEhoOcT.append(iQUMlausXwdvtNjnFSBJPbKzEhoOqg['category1_name']['ko'])
    if iQUMlausXwdvtNjnFSBJPbKzEhoOqg.get('category2_name').get('ko')!='':
     iQUMlausXwdvtNjnFSBJPbKzEhoOcT.append(iQUMlausXwdvtNjnFSBJPbKzEhoOqg['category2_name']['ko'])
    for iQUMlausXwdvtNjnFSBJPbKzEhoOcI in iQUMlausXwdvtNjnFSBJPbKzEhoOqg.get('actor'):
     if iQUMlausXwdvtNjnFSBJPbKzEhoOcI!='':iQUMlausXwdvtNjnFSBJPbKzEhoOcW.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcI)
    for iQUMlausXwdvtNjnFSBJPbKzEhoOcD in iQUMlausXwdvtNjnFSBJPbKzEhoOqg.get('director'):
     if iQUMlausXwdvtNjnFSBJPbKzEhoOcD!='':iQUMlausXwdvtNjnFSBJPbKzEhoOce.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcD)
    iQUMlausXwdvtNjnFSBJPbKzEhoOcx={'moviecode':iQUMlausXwdvtNjnFSBJPbKzEhoOqr,'title':iQUMlausXwdvtNjnFSBJPbKzEhoOcg,'thumbnail':{'poster':iQUMlausXwdvtNjnFSBJPbKzEhoOcL,'thumb':iQUMlausXwdvtNjnFSBJPbKzEhoOcq,'clearlogo':iQUMlausXwdvtNjnFSBJPbKzEhoOcy,'fanart':iQUMlausXwdvtNjnFSBJPbKzEhoOcq},'year':iQUMlausXwdvtNjnFSBJPbKzEhoOcA,'info_title':iQUMlausXwdvtNjnFSBJPbKzEhoOqp,'synopsis':iQUMlausXwdvtNjnFSBJPbKzEhoOcr,'mpaa':iQUMlausXwdvtNjnFSBJPbKzEhoOcf,'duration':iQUMlausXwdvtNjnFSBJPbKzEhoOqf,'premiered':iQUMlausXwdvtNjnFSBJPbKzEhoOcH,'studio':iQUMlausXwdvtNjnFSBJPbKzEhoOqT,'info_genre':iQUMlausXwdvtNjnFSBJPbKzEhoOcT,'cast':iQUMlausXwdvtNjnFSBJPbKzEhoOcW,'director':iQUMlausXwdvtNjnFSBJPbKzEhoOce,}
    iQUMlausXwdvtNjnFSBJPbKzEhoOVe.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcx)
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
 def GetMovieGenre(iQUMlausXwdvtNjnFSBJPbKzEhoOkL):
  iQUMlausXwdvtNjnFSBJPbKzEhoOVe=[]
  iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v2/media/movie/curations'
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy.update(iQUMlausXwdvtNjnFSBJPbKzEhoOVf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVG
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOgy,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVH=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   if not('result' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']):return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
   iQUMlausXwdvtNjnFSBJPbKzEhoOrC=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['result']
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVI in iQUMlausXwdvtNjnFSBJPbKzEhoOrC:
    iQUMlausXwdvtNjnFSBJPbKzEhoOqD =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['curation_code']
    iQUMlausXwdvtNjnFSBJPbKzEhoOqR =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['curation_name']
    iQUMlausXwdvtNjnFSBJPbKzEhoOcx={'curation_code':iQUMlausXwdvtNjnFSBJPbKzEhoOqD,'curation_name':iQUMlausXwdvtNjnFSBJPbKzEhoOqR}
    iQUMlausXwdvtNjnFSBJPbKzEhoOVe.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcx)
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
 def GetSearchList(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,search_key,page_int,stype):
  iQUMlausXwdvtNjnFSBJPbKzEhoOqC=[]
  iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLR
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/search/getSearch.jsp'
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.SCREENCODE,'os':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.OSCODE,'network':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.APIKEY,'networkCode':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.NETWORKCODE,'osCode ':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.OSCODE,'teleCode ':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TELECODE,'screenCode ':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.SCREENCODE}
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.SEARCH_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVG
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOVf,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVH=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   if stype=='vod':
    if not('programRsb' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH):return iQUMlausXwdvtNjnFSBJPbKzEhoOqC,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
    iQUMlausXwdvtNjnFSBJPbKzEhoOqx=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['programRsb']['dataList']
    iQUMlausXwdvtNjnFSBJPbKzEhoOLk =iQUMlausXwdvtNjnFSBJPbKzEhoOyk(iQUMlausXwdvtNjnFSBJPbKzEhoOVH['programRsb']['count'])
    for iQUMlausXwdvtNjnFSBJPbKzEhoOVI in iQUMlausXwdvtNjnFSBJPbKzEhoOqx:
     iQUMlausXwdvtNjnFSBJPbKzEhoOqk=iQUMlausXwdvtNjnFSBJPbKzEhoOVI['mast_cd']
     iQUMlausXwdvtNjnFSBJPbKzEhoOcg =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['mast_nm']
     iQUMlausXwdvtNjnFSBJPbKzEhoOcL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVI['web_url4']
     iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVI['web_url']
     try:
      iQUMlausXwdvtNjnFSBJPbKzEhoOcW =[]
      iQUMlausXwdvtNjnFSBJPbKzEhoOce=[]
      iQUMlausXwdvtNjnFSBJPbKzEhoOcT =[]
      iQUMlausXwdvtNjnFSBJPbKzEhoOqf =0
      iQUMlausXwdvtNjnFSBJPbKzEhoOcf =''
      iQUMlausXwdvtNjnFSBJPbKzEhoOcA =''
      iQUMlausXwdvtNjnFSBJPbKzEhoOqe =''
      if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('actor') !='' and iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('actor') !='-':iQUMlausXwdvtNjnFSBJPbKzEhoOcW =iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('actor').split(',')
      if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('director')!='' and iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('director')!='-':iQUMlausXwdvtNjnFSBJPbKzEhoOce=iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('director').split(',')
      if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('cate_nm')!='' and iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('cate_nm')!='-':iQUMlausXwdvtNjnFSBJPbKzEhoOcT =iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('cate_nm').split('/')
      if 'targetage' in iQUMlausXwdvtNjnFSBJPbKzEhoOVI:iQUMlausXwdvtNjnFSBJPbKzEhoOcf=iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('targetage')
      if 'broad_dt' in iQUMlausXwdvtNjnFSBJPbKzEhoOVI:
       iQUMlausXwdvtNjnFSBJPbKzEhoOcR=iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('broad_dt')
       iQUMlausXwdvtNjnFSBJPbKzEhoOqe='%s-%s-%s'%(iQUMlausXwdvtNjnFSBJPbKzEhoOcR[:4],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[4:6],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[6:])
       iQUMlausXwdvtNjnFSBJPbKzEhoOcA =iQUMlausXwdvtNjnFSBJPbKzEhoOcR[:4]
     except:
      iQUMlausXwdvtNjnFSBJPbKzEhoOLD
     iQUMlausXwdvtNjnFSBJPbKzEhoOcx={'program':iQUMlausXwdvtNjnFSBJPbKzEhoOqk,'title':iQUMlausXwdvtNjnFSBJPbKzEhoOcg,'thumbnail':{'poster':iQUMlausXwdvtNjnFSBJPbKzEhoOcL,'thumb':iQUMlausXwdvtNjnFSBJPbKzEhoOcq,'fanart':iQUMlausXwdvtNjnFSBJPbKzEhoOcq},'synopsis':'','cast':iQUMlausXwdvtNjnFSBJPbKzEhoOcW,'director':iQUMlausXwdvtNjnFSBJPbKzEhoOce,'info_genre':iQUMlausXwdvtNjnFSBJPbKzEhoOcT,'duration':iQUMlausXwdvtNjnFSBJPbKzEhoOqf,'mpaa':iQUMlausXwdvtNjnFSBJPbKzEhoOcf,'year':iQUMlausXwdvtNjnFSBJPbKzEhoOcA,'aired':iQUMlausXwdvtNjnFSBJPbKzEhoOqe}
     iQUMlausXwdvtNjnFSBJPbKzEhoOqC.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcx)
   else:
    if not('vodMVRsb' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH):return iQUMlausXwdvtNjnFSBJPbKzEhoOqC,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
    iQUMlausXwdvtNjnFSBJPbKzEhoOLV=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['vodMVRsb']['dataList']
    iQUMlausXwdvtNjnFSBJPbKzEhoOLk =iQUMlausXwdvtNjnFSBJPbKzEhoOyk(iQUMlausXwdvtNjnFSBJPbKzEhoOVH['vodMVRsb']['count'])
    for iQUMlausXwdvtNjnFSBJPbKzEhoOVI in iQUMlausXwdvtNjnFSBJPbKzEhoOLV:
     iQUMlausXwdvtNjnFSBJPbKzEhoOqk=iQUMlausXwdvtNjnFSBJPbKzEhoOVI['mast_cd']
     iQUMlausXwdvtNjnFSBJPbKzEhoOcg =iQUMlausXwdvtNjnFSBJPbKzEhoOVI['mast_nm'].strip()
     iQUMlausXwdvtNjnFSBJPbKzEhoOcL =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVI['web_url']
     iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOcL
     iQUMlausXwdvtNjnFSBJPbKzEhoOcy=''
     try:
      iQUMlausXwdvtNjnFSBJPbKzEhoOcW =[]
      iQUMlausXwdvtNjnFSBJPbKzEhoOce=[]
      iQUMlausXwdvtNjnFSBJPbKzEhoOcT =[]
      iQUMlausXwdvtNjnFSBJPbKzEhoOqf =0
      iQUMlausXwdvtNjnFSBJPbKzEhoOcf =''
      iQUMlausXwdvtNjnFSBJPbKzEhoOcA =''
      iQUMlausXwdvtNjnFSBJPbKzEhoOqe =''
      if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('actor') !='' and iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('actor') !='-':iQUMlausXwdvtNjnFSBJPbKzEhoOcW =iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('actor').split(',')
      if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('director')!='' and iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('director')!='-':iQUMlausXwdvtNjnFSBJPbKzEhoOce=iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('director').split(',')
      if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('cate_nm')!='' and iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('cate_nm')!='-':iQUMlausXwdvtNjnFSBJPbKzEhoOcT =iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('cate_nm').split('/')
      if iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('runtime_sec')!='':iQUMlausXwdvtNjnFSBJPbKzEhoOqf=iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('runtime_sec')
      if 'grade_nm' in iQUMlausXwdvtNjnFSBJPbKzEhoOVI:iQUMlausXwdvtNjnFSBJPbKzEhoOcf=iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('grade_nm')
      iQUMlausXwdvtNjnFSBJPbKzEhoOcR=iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('broad_dt')
      if data_str!='':
       iQUMlausXwdvtNjnFSBJPbKzEhoOqe='%s-%s-%s'%(iQUMlausXwdvtNjnFSBJPbKzEhoOcR[:4],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[4:6],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[6:])
       iQUMlausXwdvtNjnFSBJPbKzEhoOcA =iQUMlausXwdvtNjnFSBJPbKzEhoOcR[:4]
     except:
      iQUMlausXwdvtNjnFSBJPbKzEhoOLD
     iQUMlausXwdvtNjnFSBJPbKzEhoOcx={'movie':iQUMlausXwdvtNjnFSBJPbKzEhoOqk,'title':iQUMlausXwdvtNjnFSBJPbKzEhoOcg,'thumbnail':{'poster':iQUMlausXwdvtNjnFSBJPbKzEhoOcL,'thumb':iQUMlausXwdvtNjnFSBJPbKzEhoOcq,'fanart':iQUMlausXwdvtNjnFSBJPbKzEhoOcq,'clearlogo':iQUMlausXwdvtNjnFSBJPbKzEhoOcy},'synopsis':'','cast':iQUMlausXwdvtNjnFSBJPbKzEhoOcW,'director':iQUMlausXwdvtNjnFSBJPbKzEhoOce,'info_genre':iQUMlausXwdvtNjnFSBJPbKzEhoOcT,'duration':iQUMlausXwdvtNjnFSBJPbKzEhoOqf,'mpaa':iQUMlausXwdvtNjnFSBJPbKzEhoOcf,'year':iQUMlausXwdvtNjnFSBJPbKzEhoOcA,'aired':iQUMlausXwdvtNjnFSBJPbKzEhoOqe}
     iQUMlausXwdvtNjnFSBJPbKzEhoOqH=iQUMlausXwdvtNjnFSBJPbKzEhoOLR
     for iQUMlausXwdvtNjnFSBJPbKzEhoOqI in iQUMlausXwdvtNjnFSBJPbKzEhoOVI['bill']:
      if iQUMlausXwdvtNjnFSBJPbKzEhoOqI in iQUMlausXwdvtNjnFSBJPbKzEhoOkL.MOVIE_LITE:
       iQUMlausXwdvtNjnFSBJPbKzEhoOqH=iQUMlausXwdvtNjnFSBJPbKzEhoOLx
       break
     if iQUMlausXwdvtNjnFSBJPbKzEhoOqH==iQUMlausXwdvtNjnFSBJPbKzEhoOLR: 
      iQUMlausXwdvtNjnFSBJPbKzEhoOcx['title']=iQUMlausXwdvtNjnFSBJPbKzEhoOcx['title']+' [개별구매]'
     iQUMlausXwdvtNjnFSBJPbKzEhoOqC.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcx)
   if iQUMlausXwdvtNjnFSBJPbKzEhoOLk>(page_int*iQUMlausXwdvtNjnFSBJPbKzEhoOkL.SEARCH_LIMIT):iQUMlausXwdvtNjnFSBJPbKzEhoOrD=iQUMlausXwdvtNjnFSBJPbKzEhoOLx
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOqC,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
 def GetBookmarkInfo(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,videoid,vidtype):
  iQUMlausXwdvtNjnFSBJPbKzEhoOLg={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+'/v2/media/program/'+videoid
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'pageNo':'1','pageSize':'10','order':'name',}
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy.update(iQUMlausXwdvtNjnFSBJPbKzEhoOVf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOgy,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   iQUMlausXwdvtNjnFSBJPbKzEhoOLr=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   if not('body' in iQUMlausXwdvtNjnFSBJPbKzEhoOLr):return{}
   iQUMlausXwdvtNjnFSBJPbKzEhoOLc=iQUMlausXwdvtNjnFSBJPbKzEhoOLr['body']
   iQUMlausXwdvtNjnFSBJPbKzEhoOcg=iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('name').get('ko').strip()
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['title'] =iQUMlausXwdvtNjnFSBJPbKzEhoOcg
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['title']=iQUMlausXwdvtNjnFSBJPbKzEhoOcg
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['mpaa'] =iQUMlausXwdvtNjnFSBJPbKzEhoOkr.get(iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('grade_code'))
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['plot'] =iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('synopsis').get('ko')
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['year'] =iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('product_year')
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['cast'] =iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('actor')
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['director']=iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('director')
   if iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('category1_name').get('ko')!='':
    iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['genre'].append(iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('category1_name').get('ko'))
   if iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('category2_name').get('ko')!='':
    iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['genre'].append(iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('category2_name').get('ko'))
   iQUMlausXwdvtNjnFSBJPbKzEhoOcR=iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('broad_dt'))
   if iQUMlausXwdvtNjnFSBJPbKzEhoOcR!='0':iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(iQUMlausXwdvtNjnFSBJPbKzEhoOcR[:4],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[4:6],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[6:])
   iQUMlausXwdvtNjnFSBJPbKzEhoOcL =''
   iQUMlausXwdvtNjnFSBJPbKzEhoOcq =''
   iQUMlausXwdvtNjnFSBJPbKzEhoOcy=''
   iQUMlausXwdvtNjnFSBJPbKzEhoOcm =''
   iQUMlausXwdvtNjnFSBJPbKzEhoOcY =''
   for iQUMlausXwdvtNjnFSBJPbKzEhoOcp in iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('image'):
    if iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('code')=='CAIP0900':iQUMlausXwdvtNjnFSBJPbKzEhoOcL =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('url')
    elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('code')=='CAIP0200':iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('url')
    elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('code')=='CAIP1800':iQUMlausXwdvtNjnFSBJPbKzEhoOcy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('url')
    elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('code')=='CAIP2000':iQUMlausXwdvtNjnFSBJPbKzEhoOcm =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('url')
    elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('code')=='CAIP1900':iQUMlausXwdvtNjnFSBJPbKzEhoOcY =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('url')
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['thumbnail']['poster']=iQUMlausXwdvtNjnFSBJPbKzEhoOcL
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['thumbnail']['thumb']=iQUMlausXwdvtNjnFSBJPbKzEhoOcq
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['thumbnail']['clearlogo']=iQUMlausXwdvtNjnFSBJPbKzEhoOcy
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['thumbnail']['icon']=iQUMlausXwdvtNjnFSBJPbKzEhoOcm
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['thumbnail']['banner']=iQUMlausXwdvtNjnFSBJPbKzEhoOcY
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['thumbnail']['fanart']=iQUMlausXwdvtNjnFSBJPbKzEhoOcq
  else:
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+'/v2a/media/stream/info'
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_uuid'].split('-')[0],'uuid':iQUMlausXwdvtNjnFSBJPbKzEhoOkL.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetNoCache(1)),'wm':'Y',}
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy.update(iQUMlausXwdvtNjnFSBJPbKzEhoOVf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOgy,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   iQUMlausXwdvtNjnFSBJPbKzEhoOLr=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   if not('content' in iQUMlausXwdvtNjnFSBJPbKzEhoOLr['body']):return{}
   iQUMlausXwdvtNjnFSBJPbKzEhoOLc=iQUMlausXwdvtNjnFSBJPbKzEhoOLr['body']['content']['info']['movie']
   iQUMlausXwdvtNjnFSBJPbKzEhoOcg =iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('name').get('ko').strip()
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['title']=iQUMlausXwdvtNjnFSBJPbKzEhoOcg
   iQUMlausXwdvtNjnFSBJPbKzEhoOcg +=u' (%s)'%(iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('product_year'))
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['title'] =iQUMlausXwdvtNjnFSBJPbKzEhoOcg
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['mpaa'] =iQUMlausXwdvtNjnFSBJPbKzEhoOkr.get(iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('grade_code'))
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['plot'] =iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('story').get('ko')
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['year'] =iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('product_year')
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['studio'] =iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('production')
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['duration']=iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('duration')
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['cast'] =iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('actor')
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['director']=iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('director')
   if iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('category1_name').get('ko')!='':
    iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['genre'].append(iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('category1_name').get('ko'))
   if iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('category2_name').get('ko')!='':
    iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['genre'].append(iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('category2_name').get('ko'))
   iQUMlausXwdvtNjnFSBJPbKzEhoOcR=iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('release_date'))
   if iQUMlausXwdvtNjnFSBJPbKzEhoOcR!='0':iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(iQUMlausXwdvtNjnFSBJPbKzEhoOcR[:4],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[4:6],iQUMlausXwdvtNjnFSBJPbKzEhoOcR[6:])
   iQUMlausXwdvtNjnFSBJPbKzEhoOcL=''
   iQUMlausXwdvtNjnFSBJPbKzEhoOcq =''
   iQUMlausXwdvtNjnFSBJPbKzEhoOcy=''
   for iQUMlausXwdvtNjnFSBJPbKzEhoOcp in iQUMlausXwdvtNjnFSBJPbKzEhoOLc.get('image'):
    if iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('code')=='CAIM2100':iQUMlausXwdvtNjnFSBJPbKzEhoOcL =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('url')
    elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('code')=='CAIM0400':iQUMlausXwdvtNjnFSBJPbKzEhoOcq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('url')
    elif iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('code')=='CAIM1800':iQUMlausXwdvtNjnFSBJPbKzEhoOcy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.IMG_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOcp.get('url')
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['thumbnail']['poster']=iQUMlausXwdvtNjnFSBJPbKzEhoOcL
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['thumbnail']['thumb']=iQUMlausXwdvtNjnFSBJPbKzEhoOcL 
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['thumbnail']['clearlogo']=iQUMlausXwdvtNjnFSBJPbKzEhoOcy
   iQUMlausXwdvtNjnFSBJPbKzEhoOLg['saveinfo']['thumbnail']['fanart']=iQUMlausXwdvtNjnFSBJPbKzEhoOcq
  return iQUMlausXwdvtNjnFSBJPbKzEhoOLg
 def GetEuroChannelList(iQUMlausXwdvtNjnFSBJPbKzEhoOkL):
  iQUMlausXwdvtNjnFSBJPbKzEhoOVe=[]
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOVG ='/v2/operator/highlights'
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetDefaultParams()
   iQUMlausXwdvtNjnFSBJPbKzEhoOVf={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':iQUMlausXwdvtNjnFSBJPbKzEhoOyc(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.GetNoCache(2))}
   iQUMlausXwdvtNjnFSBJPbKzEhoOgy.update(iQUMlausXwdvtNjnFSBJPbKzEhoOVf)
   iQUMlausXwdvtNjnFSBJPbKzEhoOgm=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.API_DOMAIN+iQUMlausXwdvtNjnFSBJPbKzEhoOVG
   iQUMlausXwdvtNjnFSBJPbKzEhoOVL=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.callRequestCookies('Get',iQUMlausXwdvtNjnFSBJPbKzEhoOgm,payload=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,params=iQUMlausXwdvtNjnFSBJPbKzEhoOgy,headers=iQUMlausXwdvtNjnFSBJPbKzEhoOLD,cookies=iQUMlausXwdvtNjnFSBJPbKzEhoOLD)
   iQUMlausXwdvtNjnFSBJPbKzEhoOVH=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOVL.text)
   if not('result' in iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']):return iQUMlausXwdvtNjnFSBJPbKzEhoOVe,iQUMlausXwdvtNjnFSBJPbKzEhoOrD
   iQUMlausXwdvtNjnFSBJPbKzEhoOrC=iQUMlausXwdvtNjnFSBJPbKzEhoOVH['body']['result']
   iQUMlausXwdvtNjnFSBJPbKzEhoOLq =iQUMlausXwdvtNjnFSBJPbKzEhoOkL.Get_Now_Datetime()
   iQUMlausXwdvtNjnFSBJPbKzEhoOLy=iQUMlausXwdvtNjnFSBJPbKzEhoOLq+datetime.timedelta(days=-1)
   iQUMlausXwdvtNjnFSBJPbKzEhoOLy=iQUMlausXwdvtNjnFSBJPbKzEhoOyk(iQUMlausXwdvtNjnFSBJPbKzEhoOLy.strftime('%Y%m%d'))
   for iQUMlausXwdvtNjnFSBJPbKzEhoOVI in iQUMlausXwdvtNjnFSBJPbKzEhoOrC:
    iQUMlausXwdvtNjnFSBJPbKzEhoOLm=iQUMlausXwdvtNjnFSBJPbKzEhoOyk(iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('content').get('banner_title2')[:8])
    if iQUMlausXwdvtNjnFSBJPbKzEhoOLy<=iQUMlausXwdvtNjnFSBJPbKzEhoOLm:
     iQUMlausXwdvtNjnFSBJPbKzEhoOcx={'channel':iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('content').get('banner_sub_title3'),'title':iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('content').get('banner_title'),'subtitle':iQUMlausXwdvtNjnFSBJPbKzEhoOVI.get('content').get('banner_sub_title2'),}
     iQUMlausXwdvtNjnFSBJPbKzEhoOVe.append(iQUMlausXwdvtNjnFSBJPbKzEhoOcx)
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOVe
 def Make_DecryptKey(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,step,mediacode='000',timecode='000'):
  if step=='1':
   iQUMlausXwdvtNjnFSBJPbKzEhoOLY=iQUMlausXwdvtNjnFSBJPbKzEhoOym('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   iQUMlausXwdvtNjnFSBJPbKzEhoOLG=iQUMlausXwdvtNjnFSBJPbKzEhoOym('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLY=iQUMlausXwdvtNjnFSBJPbKzEhoOym('kss2lym0kdw1lks3','utf-8')
   iQUMlausXwdvtNjnFSBJPbKzEhoOLG=iQUMlausXwdvtNjnFSBJPbKzEhoOym([iQUMlausXwdvtNjnFSBJPbKzEhoOyY('*'),0x07,iQUMlausXwdvtNjnFSBJPbKzEhoOyY('r'),iQUMlausXwdvtNjnFSBJPbKzEhoOyY(';'),iQUMlausXwdvtNjnFSBJPbKzEhoOyY('7'),0x05,0x1e,0x01,iQUMlausXwdvtNjnFSBJPbKzEhoOyY('n'),iQUMlausXwdvtNjnFSBJPbKzEhoOyY('D'),0x02,iQUMlausXwdvtNjnFSBJPbKzEhoOyY('3'),iQUMlausXwdvtNjnFSBJPbKzEhoOyY('*'),iQUMlausXwdvtNjnFSBJPbKzEhoOyY('a'),iQUMlausXwdvtNjnFSBJPbKzEhoOyY('&'),iQUMlausXwdvtNjnFSBJPbKzEhoOyY('<')])
  return iQUMlausXwdvtNjnFSBJPbKzEhoOLY,iQUMlausXwdvtNjnFSBJPbKzEhoOLG
 def DecryptPlaintext(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,ciphertext,encryption_key,init_vector):
  iQUMlausXwdvtNjnFSBJPbKzEhoOLp=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  iQUMlausXwdvtNjnFSBJPbKzEhoOLW=Padding.unpad(iQUMlausXwdvtNjnFSBJPbKzEhoOLp.decrypt(base64.standard_b64decode(ciphertext)),16)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOLW.decode('utf-8')
 def Decrypt_Url(iQUMlausXwdvtNjnFSBJPbKzEhoOkL,ciphertext,mediacode,iQUMlausXwdvtNjnFSBJPbKzEhoOge):
  iQUMlausXwdvtNjnFSBJPbKzEhoOLe=''
  iQUMlausXwdvtNjnFSBJPbKzEhoOgT=''
  iQUMlausXwdvtNjnFSBJPbKzEhoOgA=''
  try:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLY,iQUMlausXwdvtNjnFSBJPbKzEhoOLG=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.Make_DecryptKey('1',mediacode=mediacode,timecode=iQUMlausXwdvtNjnFSBJPbKzEhoOge)
   iQUMlausXwdvtNjnFSBJPbKzEhoOLT=json.loads(iQUMlausXwdvtNjnFSBJPbKzEhoOkL.DecryptPlaintext(ciphertext,iQUMlausXwdvtNjnFSBJPbKzEhoOLY,iQUMlausXwdvtNjnFSBJPbKzEhoOLG))
   iQUMlausXwdvtNjnFSBJPbKzEhoOLA =iQUMlausXwdvtNjnFSBJPbKzEhoOLT.get('broad_url')
   iQUMlausXwdvtNjnFSBJPbKzEhoOgT =iQUMlausXwdvtNjnFSBJPbKzEhoOLT.get('watermark') if 'watermark' in iQUMlausXwdvtNjnFSBJPbKzEhoOLT else ''
   iQUMlausXwdvtNjnFSBJPbKzEhoOgA=iQUMlausXwdvtNjnFSBJPbKzEhoOLT.get('watermarkKey')if 'watermarkKey' in iQUMlausXwdvtNjnFSBJPbKzEhoOLT else ''
   iQUMlausXwdvtNjnFSBJPbKzEhoOLY,iQUMlausXwdvtNjnFSBJPbKzEhoOLG=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.Make_DecryptKey('2',mediacode=mediacode,timecode=iQUMlausXwdvtNjnFSBJPbKzEhoOge)
   iQUMlausXwdvtNjnFSBJPbKzEhoOLe=iQUMlausXwdvtNjnFSBJPbKzEhoOkL.DecryptPlaintext(iQUMlausXwdvtNjnFSBJPbKzEhoOLA,iQUMlausXwdvtNjnFSBJPbKzEhoOLY,iQUMlausXwdvtNjnFSBJPbKzEhoOLG)
  except iQUMlausXwdvtNjnFSBJPbKzEhoOyg as exception:
   iQUMlausXwdvtNjnFSBJPbKzEhoOLf(exception)
  return iQUMlausXwdvtNjnFSBJPbKzEhoOLe,iQUMlausXwdvtNjnFSBJPbKzEhoOgT,iQUMlausXwdvtNjnFSBJPbKzEhoOgA
# Created by pyminifier (https://github.com/liftoff/pyminifier)
