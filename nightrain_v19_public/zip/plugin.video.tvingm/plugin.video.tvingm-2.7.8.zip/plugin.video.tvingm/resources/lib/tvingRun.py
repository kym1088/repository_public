__author__="NightRain"
wmECryhRDQjJgaxLqOIfuUciPGbKsd=object
wmECryhRDQjJgaxLqOIfuUciPGbKst=None
wmECryhRDQjJgaxLqOIfuUciPGbKsk=int
wmECryhRDQjJgaxLqOIfuUciPGbKsB=False
wmECryhRDQjJgaxLqOIfuUciPGbKsM=True
wmECryhRDQjJgaxLqOIfuUciPGbKsV=type
wmECryhRDQjJgaxLqOIfuUciPGbKsA=dict
wmECryhRDQjJgaxLqOIfuUciPGbKsY=getattr
wmECryhRDQjJgaxLqOIfuUciPGbKse=list
wmECryhRDQjJgaxLqOIfuUciPGbKsv=len
wmECryhRDQjJgaxLqOIfuUciPGbKsH=str
wmECryhRDQjJgaxLqOIfuUciPGbKsW=range
wmECryhRDQjJgaxLqOIfuUciPGbKsT=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
wmECryhRDQjJgaxLqOIfuUciPGbKdk=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'실시간 인기 드라마','mode':'BAND_VODLIST','bandKey':'HM218820','bandGroup':''},{'title':'실시간 인기 예능','mode':'BAND_VODLIST','bandKey':'HM156521','bandGroup':''},{'title':'Apple TV+ 실시간 인기','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'TVING_APPLE_HOUR'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'드라마 - 인기순','mode':'DRAMA_GROUP','stype':'drama','orderby':'hit','ordernm':'인기'},{'title':'드라마 - 업데이트','mode':'DRAMA_GROUP','stype':'drama','orderby':'update','ordernm':'업데이트'},{'title':'예능   - 인기순','mode':'ENTER_GROUP','stype':'enter','orderby':'hit','ordernm':'인기'},{'title':'예능   - 업데이트','mode':'ENTER_GROUP','stype':'enter','orderby':'update','ordernm':'업데이트'},{'title':'영화 - 인기순','mode':'MOVIE_GROUP','stype':'movie','orderby':'hit','ordernm':'인기'},{'title':'영화 - 업데이트','mode':'MOVIE_GROUP','stype':'movie','orderby':'update','ordernm':'업데이트'},{'title':'Apple TV+','mode':'APPLE_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'},]
wmECryhRDQjJgaxLqOIfuUciPGbKdB=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
wmECryhRDQjJgaxLqOIfuUciPGbKdM=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
wmECryhRDQjJgaxLqOIfuUciPGbKdV=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
wmECryhRDQjJgaxLqOIfuUciPGbKdA=[{'title':'전체','mode':'GN2_LIST','genre':'PCA','stype':'tvshow'},{'title':'로맨스','mode':'GN2_LIST','genre':'PCA007','stype':'tvshow'},{'title':'코미디','mode':'GN2_LIST','genre':'PCA020','stype':'tvshow'},{'title':'판타지','mode':'GN2_LIST','genre':'PCA023','stype':'tvshow'},{'title':'무협','mode':'GN2_LIST','genre':'PCAB','stype':'tvshow'},{'title':'공포','mode':'GN2_LIST','genre':'PCAD','stype':'tvshow'},{'title':'복수','mode':'GN2_LIST','genre':'PCA030','stype':'tvshow'},{'title':'휴먼','mode':'GN2_LIST','genre':'PCA024','stype':'tvshow'},{'title':'범죄 스릴러','mode':'GN2_LIST','genre':'PCA015','stype':'tvshow'},{'title':'의학','mode':'GN2_LIST','genre':'PCA025','stype':'tvshow'},{'title':'웹튠/소설 원작','mode':'GN2_LIST','genre':'PCA028','stype':'tvshow'},{'title':'정치/권력','mode':'GN2_LIST','genre':'PCA034','stype':'tvshow'},{'title':'법정','mode':'GN2_LIST','genre':'PCA036','stype':'tvshow'},{'title':'청춘(성장)','mode':'GN2_LIST','genre':'PCA029','stype':'tvshow'},{'title':'오피스 드라마','mode':'GN2_LIST','genre':'PCA040','stype':'tvshow'},{'title':'사극/시대극','mode':'GN2_LIST','genre':'PCA017','stype':'tvshow'},{'title':'타임슬립','mode':'GN2_LIST','genre':'PCA026','stype':'tvshow'},{'title':'단막극','mode':'GN2_LIST','genre':'PCA038','stype':'tvshow'},{'title':'해외드라마','mode':'GN2_LIST','genre':'PCPOS','stype':'tvshow'},{'title':'미국드라마','mode':'GN2_LIST','genre':'POS007','stype':'tvshow'},{'title':'영국드라마','mode':'GN2_LIST','genre':'POS008','stype':'tvshow'},{'title':'중국드라마','mode':'GN2_LIST','genre':'POS005','stype':'tvshow'},{'title':'일본드라마','mode':'GN2_LIST','genre':'POS006','stype':'tvshow'}]
wmECryhRDQjJgaxLqOIfuUciPGbKdY=[{'title':'버라이어티','mode':'GN2_LIST','genre':'PCD005','stype':'tvshow'},{'title':'다큐멘터리','mode':'GN2_LIST','genre':'PCT','stype':'tvshow'},{'title':'여행','mode':'GN2_LIST','genre':'PCD003','stype':'tvshow'},{'title':'쿡방/먹방','mode':'GN2_LIST','genre':'PCD023','stype':'tvshow'},{'title':'연애 리얼리티','mode':'GN2_LIST','genre':'PCAB','stype':'PCD010'},{'title':'나영석 예능','mode':'GN2_LIST','genre':'PCD032','stype':'tvshow'},{'title':'게임/퀴즈쇼','mode':'GN2_LIST','genre':'PCD029','stype':'tvshow'},{'title':'토크쇼','mode':'GN2_LIST','genre':'PCD011','stype':'tvshow'},{'title':'서바이벌','mode':'GN2_LIST','genre':'PCD025','stype':'tvshow'},{'title':'관찰리얼리티','mode':'GN2_LIST','genre':'PCD024','stype':'tvshow'},{'title':'스포츠','mode':'GN2_LIST','genre':'PCD037','stype':'tvshow'},{'title':'교육&독서','mode':'GN2_LIST','genre':'PCD038','stype':'tvshow'},{'title':'힐링 예능','mode':'GN2_LIST','genre':'PCD034','stype':'tvshow'},{'title':'아이돌','mode':'GN2_LIST','genre':'PCD01','stype':'tvshow'},{'title':'음악 서바이벌','mode':'GN2_LIST','genre':'PCD027','stype':'tvshow'},{'title':'음악예능','mode':'GN2_LIST','genre':'PCD021','stype':'tvshow'},{'title':'코미디','mode':'GN2_LIST','genre':'PCD017','stype':'tvshow'},{'title':'가족예능','mode':'GN2_LIST','genre':'PCD035','stype':'tvshow'},{'title':'뷰티/스타일','mode':'GN2_LIST','genre':'PCD022','stype':'tvshow'},{'title':'펫/애니멀','mode':'GN2_LIST','genre':'PCD026','stype':'tvshow'},{'title':'콘서트/시상식','mode':'GN2_LIST','genre':'PCD009','stype':'tvshow'},{'title':'예능 스페셜','mode':'GN2_LIST','genre':'PCD042','stype':'tvshow'}]
wmECryhRDQjJgaxLqOIfuUciPGbKds=[{'title':'드라마','mode':'GN2_LIST','genre':'MG100','stype':'movie'},{'title':'로맨스','mode':'GN2_LIST','genre':'MG130','stype':'movie'},{'title':'코미디','mode':'GN2_LIST','genre':'MG110','stype':'movie'},{'title':'애니메이션','mode':'GN2_LIST','genre':'MG240','stype':'movie'},{'title':'스릴러','mode':'GN2_LIST','genre':'MG140','stype':'movie'},{'title':'미스터리','mode':'GN2_LIST','genre':'MG150','stype':'movie'},{'title':'모험','mode':'GN2_LIST','genre':'MG170','stype':'movie'},{'title':'액션','mode':'GN2_LIST','genre':'MG120','stype':'movie'},{'title':'판타지','mode':'GN2_LIST','genre':'MG200','stype':'movie'},{'title':'SF','mode':'GN2_LIST','genre':'MG210','stype':'movie'},{'title':'공포','mode':'GN2_LIST','genre':'MG160','stype':'movie'},{'title':'다큐멘터리','mode':'GN2_LIST','genre':'MG250','stype':'movie'}]
wmECryhRDQjJgaxLqOIfuUciPGbKde={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
class wmECryhRDQjJgaxLqOIfuUciPGbKdt(wmECryhRDQjJgaxLqOIfuUciPGbKsd):
 def __init__(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKdH,wmECryhRDQjJgaxLqOIfuUciPGbKdW,wmECryhRDQjJgaxLqOIfuUciPGbKdT):
  wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_url =wmECryhRDQjJgaxLqOIfuUciPGbKdH
  wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle=wmECryhRDQjJgaxLqOIfuUciPGbKdW
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params =wmECryhRDQjJgaxLqOIfuUciPGbKdT
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj =WSHpOXoxYqkDRvclaBGQyPMzgIALjf() 
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_COOKIE_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_TOKEN_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_token.json'))
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.SEARCHED_FILE_NAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
 def addon_noti(wmECryhRDQjJgaxLqOIfuUciPGbKdv,sting):
  try:
   wmECryhRDQjJgaxLqOIfuUciPGbKdp=xbmcgui.Dialog()
   wmECryhRDQjJgaxLqOIfuUciPGbKdp.notification(__addonname__,sting)
  except:
   wmECryhRDQjJgaxLqOIfuUciPGbKst
 def addon_log(wmECryhRDQjJgaxLqOIfuUciPGbKdv,string):
  try:
   wmECryhRDQjJgaxLqOIfuUciPGbKdl=string.encode('utf-8','ignore')
  except:
   wmECryhRDQjJgaxLqOIfuUciPGbKdl='addonException: addon_log'
  wmECryhRDQjJgaxLqOIfuUciPGbKdz=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,wmECryhRDQjJgaxLqOIfuUciPGbKdl),level=wmECryhRDQjJgaxLqOIfuUciPGbKdz)
 def get_keyboard_input(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKtT):
  wmECryhRDQjJgaxLqOIfuUciPGbKdS=wmECryhRDQjJgaxLqOIfuUciPGbKst
  kb=xbmc.Keyboard()
  kb.setHeading(wmECryhRDQjJgaxLqOIfuUciPGbKtT)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   wmECryhRDQjJgaxLqOIfuUciPGbKdS=kb.getText()
  return wmECryhRDQjJgaxLqOIfuUciPGbKdS
 def get_settings_account(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  wmECryhRDQjJgaxLqOIfuUciPGbKdF =__addon__.getSetting('id')
  wmECryhRDQjJgaxLqOIfuUciPGbKdX =__addon__.getSetting('pw')
  wmECryhRDQjJgaxLqOIfuUciPGbKdo =__addon__.getSetting('login_type')
  wmECryhRDQjJgaxLqOIfuUciPGbKdN=wmECryhRDQjJgaxLqOIfuUciPGbKsk(__addon__.getSetting('selected_profile'))
  return(wmECryhRDQjJgaxLqOIfuUciPGbKdF,wmECryhRDQjJgaxLqOIfuUciPGbKdX,wmECryhRDQjJgaxLqOIfuUciPGbKdo,wmECryhRDQjJgaxLqOIfuUciPGbKdN)
 def get_settings_uhd(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  return wmECryhRDQjJgaxLqOIfuUciPGbKsB
 def get_settings_playback(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  wmECryhRDQjJgaxLqOIfuUciPGbKtd={'active_uhd':wmECryhRDQjJgaxLqOIfuUciPGbKsM if __addon__.getSetting('active_uhd')=='true' else wmECryhRDQjJgaxLqOIfuUciPGbKsB,'streamFilename':wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_STREAM_FILENAME,}
  return wmECryhRDQjJgaxLqOIfuUciPGbKtd
 def get_settings_proxyport(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  wmECryhRDQjJgaxLqOIfuUciPGbKtk =wmECryhRDQjJgaxLqOIfuUciPGbKsM if __addon__.getSetting('proxyYn')=='true' else wmECryhRDQjJgaxLqOIfuUciPGbKsB
  wmECryhRDQjJgaxLqOIfuUciPGbKtB=wmECryhRDQjJgaxLqOIfuUciPGbKsk(__addon__.getSetting('proxyPort'))
  return wmECryhRDQjJgaxLqOIfuUciPGbKtk,wmECryhRDQjJgaxLqOIfuUciPGbKtB
 def get_settings_totalsearch(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  wmECryhRDQjJgaxLqOIfuUciPGbKtM =wmECryhRDQjJgaxLqOIfuUciPGbKsM if __addon__.getSetting('local_search')=='true' else wmECryhRDQjJgaxLqOIfuUciPGbKsB
  wmECryhRDQjJgaxLqOIfuUciPGbKtV=wmECryhRDQjJgaxLqOIfuUciPGbKsM if __addon__.getSetting('local_history')=='true' else wmECryhRDQjJgaxLqOIfuUciPGbKsB
  wmECryhRDQjJgaxLqOIfuUciPGbKtA =wmECryhRDQjJgaxLqOIfuUciPGbKsM if __addon__.getSetting('total_search')=='true' else wmECryhRDQjJgaxLqOIfuUciPGbKsB
  wmECryhRDQjJgaxLqOIfuUciPGbKtY=wmECryhRDQjJgaxLqOIfuUciPGbKsM if __addon__.getSetting('total_history')=='true' else wmECryhRDQjJgaxLqOIfuUciPGbKsB
  wmECryhRDQjJgaxLqOIfuUciPGbKts=wmECryhRDQjJgaxLqOIfuUciPGbKsM if __addon__.getSetting('menu_bookmark')=='true' else wmECryhRDQjJgaxLqOIfuUciPGbKsB
  return(wmECryhRDQjJgaxLqOIfuUciPGbKtM,wmECryhRDQjJgaxLqOIfuUciPGbKtV,wmECryhRDQjJgaxLqOIfuUciPGbKtA,wmECryhRDQjJgaxLqOIfuUciPGbKtY,wmECryhRDQjJgaxLqOIfuUciPGbKts)
 def get_settings_makebookmark(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  return wmECryhRDQjJgaxLqOIfuUciPGbKsM if __addon__.getSetting('make_bookmark')=='true' else wmECryhRDQjJgaxLqOIfuUciPGbKsB
 def get_settings_direct_replay(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  wmECryhRDQjJgaxLqOIfuUciPGbKte=wmECryhRDQjJgaxLqOIfuUciPGbKsk(__addon__.getSetting('direct_replay'))
  if wmECryhRDQjJgaxLqOIfuUciPGbKte==0:
   return wmECryhRDQjJgaxLqOIfuUciPGbKsB
  else:
   return wmECryhRDQjJgaxLqOIfuUciPGbKsM
 def set_winEpisodeOrderby(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKtH):
  __addon__.setSetting('tving_orderby',wmECryhRDQjJgaxLqOIfuUciPGbKtH)
  wmECryhRDQjJgaxLqOIfuUciPGbKtv=xbmcgui.Window(10000)
  wmECryhRDQjJgaxLqOIfuUciPGbKtv.setProperty('TVING_M_ORDERBY',wmECryhRDQjJgaxLqOIfuUciPGbKtH)
 def get_winEpisodeOrderby(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  wmECryhRDQjJgaxLqOIfuUciPGbKtH=__addon__.getSetting('tving_orderby')
  if wmECryhRDQjJgaxLqOIfuUciPGbKtH in['',wmECryhRDQjJgaxLqOIfuUciPGbKst]:wmECryhRDQjJgaxLqOIfuUciPGbKtH='desc'
  return wmECryhRDQjJgaxLqOIfuUciPGbKtH
 def add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKdv,label,sublabel='',img='',infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKst,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params='',isLink=wmECryhRDQjJgaxLqOIfuUciPGbKsB,ContextMenu=wmECryhRDQjJgaxLqOIfuUciPGbKst):
  wmECryhRDQjJgaxLqOIfuUciPGbKtW='%s?%s'%(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_url,urllib.parse.urlencode(params))
  if sublabel:wmECryhRDQjJgaxLqOIfuUciPGbKtT='%s < %s >'%(label,sublabel)
  else: wmECryhRDQjJgaxLqOIfuUciPGbKtT=label
  if not img:img='DefaultFolder.png'
  wmECryhRDQjJgaxLqOIfuUciPGbKtn=xbmcgui.ListItem(wmECryhRDQjJgaxLqOIfuUciPGbKtT)
  if wmECryhRDQjJgaxLqOIfuUciPGbKsV(img)==wmECryhRDQjJgaxLqOIfuUciPGbKsA:
   wmECryhRDQjJgaxLqOIfuUciPGbKtn.setArt(img)
  else:
   wmECryhRDQjJgaxLqOIfuUciPGbKtn.setArt({'thumb':img,'poster':img})
  if wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.KodiVersion>=20:
   if infoLabels:wmECryhRDQjJgaxLqOIfuUciPGbKdv.Set_InfoTag(wmECryhRDQjJgaxLqOIfuUciPGbKtn.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:wmECryhRDQjJgaxLqOIfuUciPGbKtn.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   wmECryhRDQjJgaxLqOIfuUciPGbKtn.setProperty('IsPlayable','true')
  if ContextMenu:wmECryhRDQjJgaxLqOIfuUciPGbKtn.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,wmECryhRDQjJgaxLqOIfuUciPGbKtW,wmECryhRDQjJgaxLqOIfuUciPGbKtn,isFolder)
 def get_selQuality(wmECryhRDQjJgaxLqOIfuUciPGbKdv,etype):
  try:
   wmECryhRDQjJgaxLqOIfuUciPGbKtp='selected_quality'
   wmECryhRDQjJgaxLqOIfuUciPGbKtl=[1080,720,480,360]
   wmECryhRDQjJgaxLqOIfuUciPGbKtz=wmECryhRDQjJgaxLqOIfuUciPGbKsk(__addon__.getSetting(wmECryhRDQjJgaxLqOIfuUciPGbKtp))
   return wmECryhRDQjJgaxLqOIfuUciPGbKtl[wmECryhRDQjJgaxLqOIfuUciPGbKtz]
  except:
   wmECryhRDQjJgaxLqOIfuUciPGbKst
  return 720 
 def Set_InfoTag(wmECryhRDQjJgaxLqOIfuUciPGbKdv,video_InfoTag:xbmc.InfoTagVideo,wmECryhRDQjJgaxLqOIfuUciPGbKkB):
  for wmECryhRDQjJgaxLqOIfuUciPGbKtS,value in wmECryhRDQjJgaxLqOIfuUciPGbKkB.items():
   if wmECryhRDQjJgaxLqOIfuUciPGbKde[wmECryhRDQjJgaxLqOIfuUciPGbKtS]['type']=='string':
    wmECryhRDQjJgaxLqOIfuUciPGbKsY(video_InfoTag,wmECryhRDQjJgaxLqOIfuUciPGbKde[wmECryhRDQjJgaxLqOIfuUciPGbKtS]['func'])(value)
   elif wmECryhRDQjJgaxLqOIfuUciPGbKde[wmECryhRDQjJgaxLqOIfuUciPGbKtS]['type']=='int':
    if wmECryhRDQjJgaxLqOIfuUciPGbKsV(value)==wmECryhRDQjJgaxLqOIfuUciPGbKsk:
     wmECryhRDQjJgaxLqOIfuUciPGbKtF=wmECryhRDQjJgaxLqOIfuUciPGbKsk(value)
    else:
     wmECryhRDQjJgaxLqOIfuUciPGbKtF=0
    wmECryhRDQjJgaxLqOIfuUciPGbKsY(video_InfoTag,wmECryhRDQjJgaxLqOIfuUciPGbKde[wmECryhRDQjJgaxLqOIfuUciPGbKtS]['func'])(wmECryhRDQjJgaxLqOIfuUciPGbKtF)
   elif wmECryhRDQjJgaxLqOIfuUciPGbKde[wmECryhRDQjJgaxLqOIfuUciPGbKtS]['type']=='actor':
    if value!=[]:
     wmECryhRDQjJgaxLqOIfuUciPGbKsY(video_InfoTag,wmECryhRDQjJgaxLqOIfuUciPGbKde[wmECryhRDQjJgaxLqOIfuUciPGbKtS]['func'])([xbmc.Actor(name)for name in value])
   elif wmECryhRDQjJgaxLqOIfuUciPGbKde[wmECryhRDQjJgaxLqOIfuUciPGbKtS]['type']=='list':
    if wmECryhRDQjJgaxLqOIfuUciPGbKsV(value)==wmECryhRDQjJgaxLqOIfuUciPGbKse:
     wmECryhRDQjJgaxLqOIfuUciPGbKsY(video_InfoTag,wmECryhRDQjJgaxLqOIfuUciPGbKde[wmECryhRDQjJgaxLqOIfuUciPGbKtS]['func'])(value)
    else:
     wmECryhRDQjJgaxLqOIfuUciPGbKsY(video_InfoTag,wmECryhRDQjJgaxLqOIfuUciPGbKde[wmECryhRDQjJgaxLqOIfuUciPGbKtS]['func'])([value])
 def dp_Main_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  (wmECryhRDQjJgaxLqOIfuUciPGbKtM,wmECryhRDQjJgaxLqOIfuUciPGbKtV,wmECryhRDQjJgaxLqOIfuUciPGbKtA,wmECryhRDQjJgaxLqOIfuUciPGbKtY,wmECryhRDQjJgaxLqOIfuUciPGbKts)=wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_settings_totalsearch()
  for wmECryhRDQjJgaxLqOIfuUciPGbKtX in wmECryhRDQjJgaxLqOIfuUciPGbKdk:
   wmECryhRDQjJgaxLqOIfuUciPGbKtT=wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('title')
   wmECryhRDQjJgaxLqOIfuUciPGbKto=''
   if wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('mode')=='SEARCH_GROUP' and wmECryhRDQjJgaxLqOIfuUciPGbKtM ==wmECryhRDQjJgaxLqOIfuUciPGbKsB:continue
   elif wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('mode')=='SEARCH_HISTORY' and wmECryhRDQjJgaxLqOIfuUciPGbKtV==wmECryhRDQjJgaxLqOIfuUciPGbKsB:continue
   elif wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('mode')=='TOTAL_SEARCH' and wmECryhRDQjJgaxLqOIfuUciPGbKtA ==wmECryhRDQjJgaxLqOIfuUciPGbKsB:continue
   elif wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('mode')=='TOTAL_HISTORY' and wmECryhRDQjJgaxLqOIfuUciPGbKtY==wmECryhRDQjJgaxLqOIfuUciPGbKsB:continue
   elif wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('mode')=='MENU_BOOKMARK' and wmECryhRDQjJgaxLqOIfuUciPGbKts==wmECryhRDQjJgaxLqOIfuUciPGbKsB:continue
   wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('mode'),'stype':wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('stype'),'orderby':wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('orderby'),'ordernm':wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('ordernm'),'page':'1','bandKey':wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('bandKey'),'bandGroup':wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('bandGroup'),'nextApiUrl':'-',}
   if wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    wmECryhRDQjJgaxLqOIfuUciPGbKkd=wmECryhRDQjJgaxLqOIfuUciPGbKsB
    wmECryhRDQjJgaxLqOIfuUciPGbKkt =wmECryhRDQjJgaxLqOIfuUciPGbKsM
   else:
    wmECryhRDQjJgaxLqOIfuUciPGbKkd=wmECryhRDQjJgaxLqOIfuUciPGbKsM
    wmECryhRDQjJgaxLqOIfuUciPGbKkt =wmECryhRDQjJgaxLqOIfuUciPGbKsB
   wmECryhRDQjJgaxLqOIfuUciPGbKkB={'title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'plot':wmECryhRDQjJgaxLqOIfuUciPGbKtT}
   if wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('mode')=='XXX':wmECryhRDQjJgaxLqOIfuUciPGbKkB=wmECryhRDQjJgaxLqOIfuUciPGbKst
   if 'icon' in wmECryhRDQjJgaxLqOIfuUciPGbKtX:wmECryhRDQjJgaxLqOIfuUciPGbKto=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',wmECryhRDQjJgaxLqOIfuUciPGbKtX.get('icon')) 
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel='',img=wmECryhRDQjJgaxLqOIfuUciPGbKto,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKkB,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKkd,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN,isLink=wmECryhRDQjJgaxLqOIfuUciPGbKkt)
  xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle)
 def login_main(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  (wmECryhRDQjJgaxLqOIfuUciPGbKkV,wmECryhRDQjJgaxLqOIfuUciPGbKkA,wmECryhRDQjJgaxLqOIfuUciPGbKkY,wmECryhRDQjJgaxLqOIfuUciPGbKks)=wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_settings_account()
  if not(wmECryhRDQjJgaxLqOIfuUciPGbKkV and wmECryhRDQjJgaxLqOIfuUciPGbKkA):
   wmECryhRDQjJgaxLqOIfuUciPGbKdp=xbmcgui.Dialog()
   wmECryhRDQjJgaxLqOIfuUciPGbKke=wmECryhRDQjJgaxLqOIfuUciPGbKdp.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if wmECryhRDQjJgaxLqOIfuUciPGbKke==wmECryhRDQjJgaxLqOIfuUciPGbKsM:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if wmECryhRDQjJgaxLqOIfuUciPGbKdv.cookiefile_check():return
  if base64.standard_b64encode(wmECryhRDQjJgaxLqOIfuUciPGbKkV.encode()).decode('utf-8')in['a3ltOTUxMDg4','a3ltMTA4OA==']:
   wmECryhRDQjJgaxLqOIfuUciPGbKkv=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.GetCredential2(wmECryhRDQjJgaxLqOIfuUciPGbKkV,wmECryhRDQjJgaxLqOIfuUciPGbKkA,wmECryhRDQjJgaxLqOIfuUciPGbKkY,wmECryhRDQjJgaxLqOIfuUciPGbKks)
  else:
   wmECryhRDQjJgaxLqOIfuUciPGbKdp=xbmcgui.Dialog()
   wmECryhRDQjJgaxLqOIfuUciPGbKkH=wmECryhRDQjJgaxLqOIfuUciPGbKdp.browse(1,__language__(30917).encode('utf8'),'','.twc',wmECryhRDQjJgaxLqOIfuUciPGbKsB,wmECryhRDQjJgaxLqOIfuUciPGbKsB,'',wmECryhRDQjJgaxLqOIfuUciPGbKsB)
   if wmECryhRDQjJgaxLqOIfuUciPGbKkH!='':
    wmECryhRDQjJgaxLqOIfuUciPGbKkW=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'))
    xbmcvfs.copy(wmECryhRDQjJgaxLqOIfuUciPGbKkH,wmECryhRDQjJgaxLqOIfuUciPGbKkW)
    wmECryhRDQjJgaxLqOIfuUciPGbKkv=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.WebCookies_Load(wmECryhRDQjJgaxLqOIfuUciPGbKkW)
    xbmcvfs.delete(wmECryhRDQjJgaxLqOIfuUciPGbKkW)
    if wmECryhRDQjJgaxLqOIfuUciPGbKkv:
     wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.JsonFile_Save(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_COOKIE_FILENAME,wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV)
     wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    wmECryhRDQjJgaxLqOIfuUciPGbKkv=wmECryhRDQjJgaxLqOIfuUciPGbKsB
  if wmECryhRDQjJgaxLqOIfuUciPGbKkv==wmECryhRDQjJgaxLqOIfuUciPGbKsM:
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.cookiefile_save()
  else:
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKkT=wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('stype')
  if wmECryhRDQjJgaxLqOIfuUciPGbKkT=='live':
   wmECryhRDQjJgaxLqOIfuUciPGbKkn=wmECryhRDQjJgaxLqOIfuUciPGbKdB
  elif wmECryhRDQjJgaxLqOIfuUciPGbKkT=='drama':
   wmECryhRDQjJgaxLqOIfuUciPGbKkn=wmECryhRDQjJgaxLqOIfuUciPGbKdA
  elif wmECryhRDQjJgaxLqOIfuUciPGbKkT=='enter':
   wmECryhRDQjJgaxLqOIfuUciPGbKkn=wmECryhRDQjJgaxLqOIfuUciPGbKdY
  else:
   wmECryhRDQjJgaxLqOIfuUciPGbKkn=wmECryhRDQjJgaxLqOIfuUciPGbKds
  for wmECryhRDQjJgaxLqOIfuUciPGbKkp in wmECryhRDQjJgaxLqOIfuUciPGbKkn:
   wmECryhRDQjJgaxLqOIfuUciPGbKtT=wmECryhRDQjJgaxLqOIfuUciPGbKkp.get('title')
   if wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('ordernm')!='-':
    wmECryhRDQjJgaxLqOIfuUciPGbKtT+='  ('+wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('ordernm')+')'
   wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':wmECryhRDQjJgaxLqOIfuUciPGbKkp.get('mode'),'stype':wmECryhRDQjJgaxLqOIfuUciPGbKkp.get('stype'),'genre':wmECryhRDQjJgaxLqOIfuUciPGbKkp.get('genre'),'orderby':wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('orderby'),'ordernm':wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('ordernm'),'page':'1',}
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel='',img='',infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKst,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN)
  if wmECryhRDQjJgaxLqOIfuUciPGbKsv(wmECryhRDQjJgaxLqOIfuUciPGbKkn)>0:xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle)
 def dp_LiveChannel_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKkT =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('stype')
  wmECryhRDQjJgaxLqOIfuUciPGbKkz =wmECryhRDQjJgaxLqOIfuUciPGbKsk(wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('page'))
  wmECryhRDQjJgaxLqOIfuUciPGbKkS,wmECryhRDQjJgaxLqOIfuUciPGbKkF=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.GetLiveChannelList(wmECryhRDQjJgaxLqOIfuUciPGbKkT,wmECryhRDQjJgaxLqOIfuUciPGbKkz)
  for wmECryhRDQjJgaxLqOIfuUciPGbKkX in wmECryhRDQjJgaxLqOIfuUciPGbKkS:
   wmECryhRDQjJgaxLqOIfuUciPGbKtT =wmECryhRDQjJgaxLqOIfuUciPGbKkX.get('title')
   wmECryhRDQjJgaxLqOIfuUciPGbKkM =wmECryhRDQjJgaxLqOIfuUciPGbKkX.get('channel')
   wmECryhRDQjJgaxLqOIfuUciPGbKko =wmECryhRDQjJgaxLqOIfuUciPGbKkX.get('thumbnail')
   wmECryhRDQjJgaxLqOIfuUciPGbKkN =wmECryhRDQjJgaxLqOIfuUciPGbKkX.get('synopsis')
   wmECryhRDQjJgaxLqOIfuUciPGbKBd =wmECryhRDQjJgaxLqOIfuUciPGbKkX.get('channelepg')
   wmECryhRDQjJgaxLqOIfuUciPGbKBt =wmECryhRDQjJgaxLqOIfuUciPGbKkX.get('cast')
   wmECryhRDQjJgaxLqOIfuUciPGbKBk =wmECryhRDQjJgaxLqOIfuUciPGbKkX.get('director')
   wmECryhRDQjJgaxLqOIfuUciPGbKBM =wmECryhRDQjJgaxLqOIfuUciPGbKkX.get('info_genre')
   wmECryhRDQjJgaxLqOIfuUciPGbKBV =wmECryhRDQjJgaxLqOIfuUciPGbKkX.get('year')
   wmECryhRDQjJgaxLqOIfuUciPGbKBA =wmECryhRDQjJgaxLqOIfuUciPGbKkX.get('mpaa')
   wmECryhRDQjJgaxLqOIfuUciPGbKBY =wmECryhRDQjJgaxLqOIfuUciPGbKkX.get('premiered')
   wmECryhRDQjJgaxLqOIfuUciPGbKBs={'mediatype':'episode','title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'studio':wmECryhRDQjJgaxLqOIfuUciPGbKkM,'cast':wmECryhRDQjJgaxLqOIfuUciPGbKBt,'director':wmECryhRDQjJgaxLqOIfuUciPGbKBk,'genre':wmECryhRDQjJgaxLqOIfuUciPGbKBM,'plot':'%s\n%s\n%s\n\n%s'%(wmECryhRDQjJgaxLqOIfuUciPGbKkM,wmECryhRDQjJgaxLqOIfuUciPGbKtT,wmECryhRDQjJgaxLqOIfuUciPGbKBd,wmECryhRDQjJgaxLqOIfuUciPGbKkN),'year':wmECryhRDQjJgaxLqOIfuUciPGbKBV,'mpaa':wmECryhRDQjJgaxLqOIfuUciPGbKBA,'premiered':wmECryhRDQjJgaxLqOIfuUciPGbKBY}
   wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'LIVE','mediacode':wmECryhRDQjJgaxLqOIfuUciPGbKkX.get('mediacode'),'stype':wmECryhRDQjJgaxLqOIfuUciPGbKkT}
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKkM,sublabel=wmECryhRDQjJgaxLqOIfuUciPGbKtT,img=wmECryhRDQjJgaxLqOIfuUciPGbKko,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKBs,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsB,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN)
  if wmECryhRDQjJgaxLqOIfuUciPGbKkF:
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['mode']='CHANNEL' 
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['stype']=wmECryhRDQjJgaxLqOIfuUciPGbKkT 
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['page']=wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKtT='[B]%s >>[/B]'%'다음 페이지'
   wmECryhRDQjJgaxLqOIfuUciPGbKBe=wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKto=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel=wmECryhRDQjJgaxLqOIfuUciPGbKBe,img=wmECryhRDQjJgaxLqOIfuUciPGbKto,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKst,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN)
  if wmECryhRDQjJgaxLqOIfuUciPGbKsv(wmECryhRDQjJgaxLqOIfuUciPGbKkS)>0:xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,cacheToDisc=wmECryhRDQjJgaxLqOIfuUciPGbKsB)
 def dp_Program_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKBv =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('stype')
  wmECryhRDQjJgaxLqOIfuUciPGbKtH =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('orderby')
  wmECryhRDQjJgaxLqOIfuUciPGbKkz =wmECryhRDQjJgaxLqOIfuUciPGbKsk(wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('page'))
  wmECryhRDQjJgaxLqOIfuUciPGbKBH=wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('genreCode')
  if wmECryhRDQjJgaxLqOIfuUciPGbKBH==wmECryhRDQjJgaxLqOIfuUciPGbKst:wmECryhRDQjJgaxLqOIfuUciPGbKBH='all'
  wmECryhRDQjJgaxLqOIfuUciPGbKBW,wmECryhRDQjJgaxLqOIfuUciPGbKkF=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.GetProgramList(wmECryhRDQjJgaxLqOIfuUciPGbKBv,wmECryhRDQjJgaxLqOIfuUciPGbKtH,wmECryhRDQjJgaxLqOIfuUciPGbKkz,wmECryhRDQjJgaxLqOIfuUciPGbKBH)
  for wmECryhRDQjJgaxLqOIfuUciPGbKBT in wmECryhRDQjJgaxLqOIfuUciPGbKBW:
   wmECryhRDQjJgaxLqOIfuUciPGbKtT =wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('title')
   wmECryhRDQjJgaxLqOIfuUciPGbKko =wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('thumbnail')
   wmECryhRDQjJgaxLqOIfuUciPGbKkN =wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('synopsis')
   wmECryhRDQjJgaxLqOIfuUciPGbKBn =wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('channel')
   wmECryhRDQjJgaxLqOIfuUciPGbKBt =wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('cast')
   wmECryhRDQjJgaxLqOIfuUciPGbKBk =wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('director')
   wmECryhRDQjJgaxLqOIfuUciPGbKBM=wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('info_genre')
   wmECryhRDQjJgaxLqOIfuUciPGbKBV =wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('year')
   wmECryhRDQjJgaxLqOIfuUciPGbKBY =wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('premiered')
   wmECryhRDQjJgaxLqOIfuUciPGbKBA =wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('mpaa')
   wmECryhRDQjJgaxLqOIfuUciPGbKBs={'mediatype':'tvshow','title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'studio':wmECryhRDQjJgaxLqOIfuUciPGbKBn,'cast':wmECryhRDQjJgaxLqOIfuUciPGbKBt,'director':wmECryhRDQjJgaxLqOIfuUciPGbKBk,'genre':wmECryhRDQjJgaxLqOIfuUciPGbKBM,'year':wmECryhRDQjJgaxLqOIfuUciPGbKBV,'premiered':wmECryhRDQjJgaxLqOIfuUciPGbKBY,'mpaa':wmECryhRDQjJgaxLqOIfuUciPGbKBA,'plot':wmECryhRDQjJgaxLqOIfuUciPGbKkN}
   wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'EPISODE','programcode':wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('program'),'page':'1'}
   if wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_settings_makebookmark():
    wmECryhRDQjJgaxLqOIfuUciPGbKBp={'videoid':wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('program'),'vidtype':'tvshow','vtitle':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'vsubtitle':wmECryhRDQjJgaxLqOIfuUciPGbKBn,}
    wmECryhRDQjJgaxLqOIfuUciPGbKBl=json.dumps(wmECryhRDQjJgaxLqOIfuUciPGbKBp)
    wmECryhRDQjJgaxLqOIfuUciPGbKBl=urllib.parse.quote(wmECryhRDQjJgaxLqOIfuUciPGbKBl)
    wmECryhRDQjJgaxLqOIfuUciPGbKBz='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(wmECryhRDQjJgaxLqOIfuUciPGbKBl)
    wmECryhRDQjJgaxLqOIfuUciPGbKBS=[('(통합) 찜 영상에 추가',wmECryhRDQjJgaxLqOIfuUciPGbKBz)]
   else:
    wmECryhRDQjJgaxLqOIfuUciPGbKBS=wmECryhRDQjJgaxLqOIfuUciPGbKst
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel=wmECryhRDQjJgaxLqOIfuUciPGbKBn,img=wmECryhRDQjJgaxLqOIfuUciPGbKko,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKBs,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN,ContextMenu=wmECryhRDQjJgaxLqOIfuUciPGbKBS)
  if wmECryhRDQjJgaxLqOIfuUciPGbKkF:
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['mode'] ='PROGRAM' 
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['stype'] =wmECryhRDQjJgaxLqOIfuUciPGbKBv
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['orderby'] =wmECryhRDQjJgaxLqOIfuUciPGbKtH
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['page'] =wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['genreCode']=wmECryhRDQjJgaxLqOIfuUciPGbKBH 
   wmECryhRDQjJgaxLqOIfuUciPGbKtT='[B]%s >>[/B]'%'다음 페이지'
   wmECryhRDQjJgaxLqOIfuUciPGbKBe=wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKto=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel=wmECryhRDQjJgaxLqOIfuUciPGbKBe,img=wmECryhRDQjJgaxLqOIfuUciPGbKto,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKst,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN)
  xbmcplugin.setContent(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,cacheToDisc=wmECryhRDQjJgaxLqOIfuUciPGbKsB)
 def dp_Episode_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKBX=wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('programcode')
  wmECryhRDQjJgaxLqOIfuUciPGbKkz =wmECryhRDQjJgaxLqOIfuUciPGbKsk(wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('page'))
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_log('programcode : {}'.format(wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('programcode')))
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_log('page        : {}'.format(wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('page')))
  wmECryhRDQjJgaxLqOIfuUciPGbKBo,wmECryhRDQjJgaxLqOIfuUciPGbKkF,wmECryhRDQjJgaxLqOIfuUciPGbKBN=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.GetEpisodeList(wmECryhRDQjJgaxLqOIfuUciPGbKBX,wmECryhRDQjJgaxLqOIfuUciPGbKkz,orderby=wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_winEpisodeOrderby())
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_log('count       : {}'.format(wmECryhRDQjJgaxLqOIfuUciPGbKsv(wmECryhRDQjJgaxLqOIfuUciPGbKBo)))
  for wmECryhRDQjJgaxLqOIfuUciPGbKMd in wmECryhRDQjJgaxLqOIfuUciPGbKBo:
   wmECryhRDQjJgaxLqOIfuUciPGbKtT =wmECryhRDQjJgaxLqOIfuUciPGbKMd.get('title')
   wmECryhRDQjJgaxLqOIfuUciPGbKBe =wmECryhRDQjJgaxLqOIfuUciPGbKMd.get('subtitle')
   wmECryhRDQjJgaxLqOIfuUciPGbKko =wmECryhRDQjJgaxLqOIfuUciPGbKMd.get('thumbnail')
   wmECryhRDQjJgaxLqOIfuUciPGbKkN =wmECryhRDQjJgaxLqOIfuUciPGbKMd.get('synopsis')
   wmECryhRDQjJgaxLqOIfuUciPGbKMt=wmECryhRDQjJgaxLqOIfuUciPGbKMd.get('info_title')
   wmECryhRDQjJgaxLqOIfuUciPGbKMk =wmECryhRDQjJgaxLqOIfuUciPGbKMd.get('aired')
   wmECryhRDQjJgaxLqOIfuUciPGbKMB =wmECryhRDQjJgaxLqOIfuUciPGbKMd.get('studio')
   wmECryhRDQjJgaxLqOIfuUciPGbKMV =wmECryhRDQjJgaxLqOIfuUciPGbKMd.get('frequency')
   wmECryhRDQjJgaxLqOIfuUciPGbKBs={'mediatype':'episode','title':wmECryhRDQjJgaxLqOIfuUciPGbKMt,'aired':wmECryhRDQjJgaxLqOIfuUciPGbKMk,'studio':wmECryhRDQjJgaxLqOIfuUciPGbKMB,'episode':wmECryhRDQjJgaxLqOIfuUciPGbKMV,'plot':wmECryhRDQjJgaxLqOIfuUciPGbKkN}
   wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'VOD','mediacode':wmECryhRDQjJgaxLqOIfuUciPGbKMd.get('episode'),'stype':'vod','programcode':wmECryhRDQjJgaxLqOIfuUciPGbKBX,'title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'thumbnail':wmECryhRDQjJgaxLqOIfuUciPGbKko}
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel=wmECryhRDQjJgaxLqOIfuUciPGbKBe,img=wmECryhRDQjJgaxLqOIfuUciPGbKko,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKBs,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsB,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN)
  if wmECryhRDQjJgaxLqOIfuUciPGbKkz==1:
   wmECryhRDQjJgaxLqOIfuUciPGbKBs={'plot':'정렬순서를 변경합니다.'}
   wmECryhRDQjJgaxLqOIfuUciPGbKtN={}
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['mode'] ='ORDER_BY' 
   if wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_winEpisodeOrderby()=='desc':
    wmECryhRDQjJgaxLqOIfuUciPGbKtT='정렬순서변경 : 최신화부터 -> 1회부터'
    wmECryhRDQjJgaxLqOIfuUciPGbKtN['orderby']='asc'
   else:
    wmECryhRDQjJgaxLqOIfuUciPGbKtT='정렬순서변경 : 1회부터 -> 최신화부터'
    wmECryhRDQjJgaxLqOIfuUciPGbKtN['orderby']='desc'
   wmECryhRDQjJgaxLqOIfuUciPGbKto=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel='',img=wmECryhRDQjJgaxLqOIfuUciPGbKto,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKBs,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsB,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN,isLink=wmECryhRDQjJgaxLqOIfuUciPGbKsM)
  if wmECryhRDQjJgaxLqOIfuUciPGbKkF:
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['mode'] ='EPISODE' 
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['programcode']=wmECryhRDQjJgaxLqOIfuUciPGbKBX
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['page'] =wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKtT='[B]%s >>[/B]'%'다음 페이지'
   wmECryhRDQjJgaxLqOIfuUciPGbKBe=wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKto=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel=wmECryhRDQjJgaxLqOIfuUciPGbKBe,img=wmECryhRDQjJgaxLqOIfuUciPGbKto,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKst,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN)
  xbmcplugin.setContent(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,'episodes')
  if wmECryhRDQjJgaxLqOIfuUciPGbKsv(wmECryhRDQjJgaxLqOIfuUciPGbKBo)>0:xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,cacheToDisc=wmECryhRDQjJgaxLqOIfuUciPGbKsB)
 def dp_setEpOrderby(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKtH =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('orderby')
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.set_winEpisodeOrderby(wmECryhRDQjJgaxLqOIfuUciPGbKtH)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKBv =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('stype')
  wmECryhRDQjJgaxLqOIfuUciPGbKtH =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('orderby')
  wmECryhRDQjJgaxLqOIfuUciPGbKkz=wmECryhRDQjJgaxLqOIfuUciPGbKsk(wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('page'))
  wmECryhRDQjJgaxLqOIfuUciPGbKMA,wmECryhRDQjJgaxLqOIfuUciPGbKkF=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.GetMovieList(wmECryhRDQjJgaxLqOIfuUciPGbKBv,wmECryhRDQjJgaxLqOIfuUciPGbKtH,wmECryhRDQjJgaxLqOIfuUciPGbKkz)
  for wmECryhRDQjJgaxLqOIfuUciPGbKMY in wmECryhRDQjJgaxLqOIfuUciPGbKMA:
   wmECryhRDQjJgaxLqOIfuUciPGbKtT =wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('title')
   wmECryhRDQjJgaxLqOIfuUciPGbKko =wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('thumbnail')
   wmECryhRDQjJgaxLqOIfuUciPGbKkN =wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('synopsis')
   wmECryhRDQjJgaxLqOIfuUciPGbKMt =wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('info_title')
   wmECryhRDQjJgaxLqOIfuUciPGbKBV =wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('year')
   wmECryhRDQjJgaxLqOIfuUciPGbKBt =wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('cast')
   wmECryhRDQjJgaxLqOIfuUciPGbKBk =wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('director')
   wmECryhRDQjJgaxLqOIfuUciPGbKBM =wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('info_genre')
   wmECryhRDQjJgaxLqOIfuUciPGbKMs =wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('duration')
   wmECryhRDQjJgaxLqOIfuUciPGbKBY =wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('premiered')
   wmECryhRDQjJgaxLqOIfuUciPGbKMB =wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('studio')
   wmECryhRDQjJgaxLqOIfuUciPGbKBA =wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('mpaa')
   wmECryhRDQjJgaxLqOIfuUciPGbKBs={'mediatype':'movie','title':wmECryhRDQjJgaxLqOIfuUciPGbKMt,'year':wmECryhRDQjJgaxLqOIfuUciPGbKBV,'cast':wmECryhRDQjJgaxLqOIfuUciPGbKBt,'director':wmECryhRDQjJgaxLqOIfuUciPGbKBk,'genre':wmECryhRDQjJgaxLqOIfuUciPGbKBM,'duration':wmECryhRDQjJgaxLqOIfuUciPGbKMs,'premiered':wmECryhRDQjJgaxLqOIfuUciPGbKBY,'studio':wmECryhRDQjJgaxLqOIfuUciPGbKMB,'mpaa':wmECryhRDQjJgaxLqOIfuUciPGbKBA,'plot':wmECryhRDQjJgaxLqOIfuUciPGbKkN}
   wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'MOVIE','mediacode':wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('moviecode'),'stype':'movie','title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'thumbnail':wmECryhRDQjJgaxLqOIfuUciPGbKko}
   if wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_settings_makebookmark():
    wmECryhRDQjJgaxLqOIfuUciPGbKBp={'videoid':wmECryhRDQjJgaxLqOIfuUciPGbKMY.get('moviecode'),'vidtype':'movie','vtitle':wmECryhRDQjJgaxLqOIfuUciPGbKMt,'vsubtitle':'',}
    wmECryhRDQjJgaxLqOIfuUciPGbKBl=json.dumps(wmECryhRDQjJgaxLqOIfuUciPGbKBp)
    wmECryhRDQjJgaxLqOIfuUciPGbKBl=urllib.parse.quote(wmECryhRDQjJgaxLqOIfuUciPGbKBl)
    wmECryhRDQjJgaxLqOIfuUciPGbKBz='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(wmECryhRDQjJgaxLqOIfuUciPGbKBl)
    wmECryhRDQjJgaxLqOIfuUciPGbKBS=[('(통합) 찜 영상에 추가',wmECryhRDQjJgaxLqOIfuUciPGbKBz)]
   else:
    wmECryhRDQjJgaxLqOIfuUciPGbKBS=wmECryhRDQjJgaxLqOIfuUciPGbKst
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel='',img=wmECryhRDQjJgaxLqOIfuUciPGbKko,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKBs,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsB,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN,ContextMenu=wmECryhRDQjJgaxLqOIfuUciPGbKBS)
  if wmECryhRDQjJgaxLqOIfuUciPGbKkF:
   wmECryhRDQjJgaxLqOIfuUciPGbKtN={}
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['mode'] ='MOVIE_SUB' 
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['orderby']=wmECryhRDQjJgaxLqOIfuUciPGbKtH
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['stype'] =wmECryhRDQjJgaxLqOIfuUciPGbKBv
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['page'] =wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKtT='[B]%s >>[/B]'%'다음 페이지'
   wmECryhRDQjJgaxLqOIfuUciPGbKBe=wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKto=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel=wmECryhRDQjJgaxLqOIfuUciPGbKBe,img=wmECryhRDQjJgaxLqOIfuUciPGbKto,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKst,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN)
  xbmcplugin.setContent(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,'movies')
  xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,cacheToDisc=wmECryhRDQjJgaxLqOIfuUciPGbKsB)
 def dp_Set_Bookmark(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKMe=urllib.parse.unquote(wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('bm_param'))
  wmECryhRDQjJgaxLqOIfuUciPGbKMe=json.loads(wmECryhRDQjJgaxLqOIfuUciPGbKMe)
  wmECryhRDQjJgaxLqOIfuUciPGbKMv =wmECryhRDQjJgaxLqOIfuUciPGbKMe.get('videoid')
  wmECryhRDQjJgaxLqOIfuUciPGbKMH =wmECryhRDQjJgaxLqOIfuUciPGbKMe.get('vidtype')
  wmECryhRDQjJgaxLqOIfuUciPGbKMW =wmECryhRDQjJgaxLqOIfuUciPGbKMe.get('vtitle')
  wmECryhRDQjJgaxLqOIfuUciPGbKMT =wmECryhRDQjJgaxLqOIfuUciPGbKMe.get('vsubtitle')
  wmECryhRDQjJgaxLqOIfuUciPGbKdp=xbmcgui.Dialog()
  wmECryhRDQjJgaxLqOIfuUciPGbKke=wmECryhRDQjJgaxLqOIfuUciPGbKdp.yesno(__language__(30913).encode('utf8'),wmECryhRDQjJgaxLqOIfuUciPGbKMW+' \n\n'+__language__(30914))
  if wmECryhRDQjJgaxLqOIfuUciPGbKke==wmECryhRDQjJgaxLqOIfuUciPGbKsB:return
  wmECryhRDQjJgaxLqOIfuUciPGbKMn=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.GetBookmarkInfo(wmECryhRDQjJgaxLqOIfuUciPGbKMv,wmECryhRDQjJgaxLqOIfuUciPGbKMH)
  if wmECryhRDQjJgaxLqOIfuUciPGbKMT!='':
   wmECryhRDQjJgaxLqOIfuUciPGbKMn['saveinfo']['subtitle']=wmECryhRDQjJgaxLqOIfuUciPGbKMT 
   if wmECryhRDQjJgaxLqOIfuUciPGbKMH=='tvshow':wmECryhRDQjJgaxLqOIfuUciPGbKMn['saveinfo']['infoLabels']['studio']=wmECryhRDQjJgaxLqOIfuUciPGbKMT 
  wmECryhRDQjJgaxLqOIfuUciPGbKMp=json.dumps(wmECryhRDQjJgaxLqOIfuUciPGbKMn)
  wmECryhRDQjJgaxLqOIfuUciPGbKMp=urllib.parse.quote(wmECryhRDQjJgaxLqOIfuUciPGbKMp)
  wmECryhRDQjJgaxLqOIfuUciPGbKBz ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(wmECryhRDQjJgaxLqOIfuUciPGbKMp)
  xbmc.executebuiltin(wmECryhRDQjJgaxLqOIfuUciPGbKBz)
 def dp_Search_Group(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  if 'search_key' in wmECryhRDQjJgaxLqOIfuUciPGbKkl:
   wmECryhRDQjJgaxLqOIfuUciPGbKMl=wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('search_key')
  else:
   wmECryhRDQjJgaxLqOIfuUciPGbKMl=wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not wmECryhRDQjJgaxLqOIfuUciPGbKMl:
    return
  for wmECryhRDQjJgaxLqOIfuUciPGbKkp in wmECryhRDQjJgaxLqOIfuUciPGbKdV:
   wmECryhRDQjJgaxLqOIfuUciPGbKMz =wmECryhRDQjJgaxLqOIfuUciPGbKkp.get('mode')
   wmECryhRDQjJgaxLqOIfuUciPGbKkT=wmECryhRDQjJgaxLqOIfuUciPGbKkp.get('stype')
   wmECryhRDQjJgaxLqOIfuUciPGbKtT=wmECryhRDQjJgaxLqOIfuUciPGbKkp.get('title')
   (wmECryhRDQjJgaxLqOIfuUciPGbKMS,wmECryhRDQjJgaxLqOIfuUciPGbKkF)=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Gn2_Search_List(wmECryhRDQjJgaxLqOIfuUciPGbKMl,1,wmECryhRDQjJgaxLqOIfuUciPGbKkT)
   wmECryhRDQjJgaxLqOIfuUciPGbKkB={'plot':'검색어 : '+wmECryhRDQjJgaxLqOIfuUciPGbKMl+'\n\n'+wmECryhRDQjJgaxLqOIfuUciPGbKdv.Search_FreeList(wmECryhRDQjJgaxLqOIfuUciPGbKMS)}
   wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':wmECryhRDQjJgaxLqOIfuUciPGbKMz,'stype':wmECryhRDQjJgaxLqOIfuUciPGbKkT,'search_key':wmECryhRDQjJgaxLqOIfuUciPGbKMl,'page':'1',}
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel='',img='',infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKkB,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN)
  if wmECryhRDQjJgaxLqOIfuUciPGbKsv(wmECryhRDQjJgaxLqOIfuUciPGbKdV)>0:xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,cacheToDisc=wmECryhRDQjJgaxLqOIfuUciPGbKsM)
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.Save_Searched_List(wmECryhRDQjJgaxLqOIfuUciPGbKMl)
 def Search_FreeList(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKVM):
  wmECryhRDQjJgaxLqOIfuUciPGbKMF=''
  wmECryhRDQjJgaxLqOIfuUciPGbKMX=7
  try:
   if wmECryhRDQjJgaxLqOIfuUciPGbKsv(wmECryhRDQjJgaxLqOIfuUciPGbKVM)==0:return '검색결과 없음'
   for i in wmECryhRDQjJgaxLqOIfuUciPGbKsW(wmECryhRDQjJgaxLqOIfuUciPGbKsv(wmECryhRDQjJgaxLqOIfuUciPGbKVM)):
    if i>=wmECryhRDQjJgaxLqOIfuUciPGbKMX:
     wmECryhRDQjJgaxLqOIfuUciPGbKMF=wmECryhRDQjJgaxLqOIfuUciPGbKMF+'...'
     break
    wmECryhRDQjJgaxLqOIfuUciPGbKMF=wmECryhRDQjJgaxLqOIfuUciPGbKMF+wmECryhRDQjJgaxLqOIfuUciPGbKVM[i]['title']+'\n'
  except:
   return ''
  return wmECryhRDQjJgaxLqOIfuUciPGbKMF
 def dp_Search_History(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKMo=wmECryhRDQjJgaxLqOIfuUciPGbKdv.Load_List_File('search')
  for wmECryhRDQjJgaxLqOIfuUciPGbKMN in wmECryhRDQjJgaxLqOIfuUciPGbKMo:
   wmECryhRDQjJgaxLqOIfuUciPGbKVd=wmECryhRDQjJgaxLqOIfuUciPGbKsA(urllib.parse.parse_qsl(wmECryhRDQjJgaxLqOIfuUciPGbKMN))
   wmECryhRDQjJgaxLqOIfuUciPGbKVt=wmECryhRDQjJgaxLqOIfuUciPGbKVd.get('skey').strip()
   wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'SEARCH_GROUP','search_key':wmECryhRDQjJgaxLqOIfuUciPGbKVt,}
   wmECryhRDQjJgaxLqOIfuUciPGbKVk={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':wmECryhRDQjJgaxLqOIfuUciPGbKVt,'vType':'-',}
   wmECryhRDQjJgaxLqOIfuUciPGbKVB=urllib.parse.urlencode(wmECryhRDQjJgaxLqOIfuUciPGbKVk)
   wmECryhRDQjJgaxLqOIfuUciPGbKBS=[('선택된 검색어 ( %s ) 삭제'%(wmECryhRDQjJgaxLqOIfuUciPGbKVt),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(wmECryhRDQjJgaxLqOIfuUciPGbKVB))]
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKVt,sublabel='',img=wmECryhRDQjJgaxLqOIfuUciPGbKst,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKst,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN,ContextMenu=wmECryhRDQjJgaxLqOIfuUciPGbKBS)
  wmECryhRDQjJgaxLqOIfuUciPGbKBs={'plot':'검색목록 전체를 삭제합니다.'}
  wmECryhRDQjJgaxLqOIfuUciPGbKtT='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  wmECryhRDQjJgaxLqOIfuUciPGbKto=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel='',img=wmECryhRDQjJgaxLqOIfuUciPGbKto,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKBs,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsB,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN,isLink=wmECryhRDQjJgaxLqOIfuUciPGbKsM)
  xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,cacheToDisc=wmECryhRDQjJgaxLqOIfuUciPGbKsB)
 def dp_Search_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKkz =wmECryhRDQjJgaxLqOIfuUciPGbKsk(wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('page'))
  wmECryhRDQjJgaxLqOIfuUciPGbKkT =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('stype')
  if 'search_key' in wmECryhRDQjJgaxLqOIfuUciPGbKkl:
   wmECryhRDQjJgaxLqOIfuUciPGbKMl=wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('search_key')
  else:
   wmECryhRDQjJgaxLqOIfuUciPGbKMl=wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not wmECryhRDQjJgaxLqOIfuUciPGbKMl:
    xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle)
    return
  wmECryhRDQjJgaxLqOIfuUciPGbKMS,wmECryhRDQjJgaxLqOIfuUciPGbKkF=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Gn2_Search_List(wmECryhRDQjJgaxLqOIfuUciPGbKMl,wmECryhRDQjJgaxLqOIfuUciPGbKkz,wmECryhRDQjJgaxLqOIfuUciPGbKkT)
  for wmECryhRDQjJgaxLqOIfuUciPGbKVM in wmECryhRDQjJgaxLqOIfuUciPGbKMS:
   wmECryhRDQjJgaxLqOIfuUciPGbKtT =wmECryhRDQjJgaxLqOIfuUciPGbKVM.get('title')
   wmECryhRDQjJgaxLqOIfuUciPGbKko =wmECryhRDQjJgaxLqOIfuUciPGbKVM.get('thumbnail')
   wmECryhRDQjJgaxLqOIfuUciPGbKBs={'mediatype':'tvshow' if wmECryhRDQjJgaxLqOIfuUciPGbKkT=='vod' else 'movie','title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'plot':'%s'%(wmECryhRDQjJgaxLqOIfuUciPGbKtT)}
   if wmECryhRDQjJgaxLqOIfuUciPGbKkT=='vod':
    wmECryhRDQjJgaxLqOIfuUciPGbKMv=wmECryhRDQjJgaxLqOIfuUciPGbKVM.get('program')
    wmECryhRDQjJgaxLqOIfuUciPGbKMH='tvshow'
    wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'EPISODE','programcode':wmECryhRDQjJgaxLqOIfuUciPGbKMv,'page':'1',}
    wmECryhRDQjJgaxLqOIfuUciPGbKkd=wmECryhRDQjJgaxLqOIfuUciPGbKsM
   else:
    wmECryhRDQjJgaxLqOIfuUciPGbKMv=wmECryhRDQjJgaxLqOIfuUciPGbKVM.get('movie')
    wmECryhRDQjJgaxLqOIfuUciPGbKMH='movie'
    wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'MOVIE','mediacode':wmECryhRDQjJgaxLqOIfuUciPGbKMv,'stype':'movie','title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'thumbnail':wmECryhRDQjJgaxLqOIfuUciPGbKko,}
    wmECryhRDQjJgaxLqOIfuUciPGbKkd=wmECryhRDQjJgaxLqOIfuUciPGbKsB
   if wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_settings_makebookmark():
    wmECryhRDQjJgaxLqOIfuUciPGbKBp={'videoid':wmECryhRDQjJgaxLqOIfuUciPGbKMv,'vidtype':wmECryhRDQjJgaxLqOIfuUciPGbKMH,'vtitle':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'vsubtitle':'',}
    wmECryhRDQjJgaxLqOIfuUciPGbKBl=json.dumps(wmECryhRDQjJgaxLqOIfuUciPGbKBp)
    wmECryhRDQjJgaxLqOIfuUciPGbKBl=urllib.parse.quote(wmECryhRDQjJgaxLqOIfuUciPGbKBl)
    wmECryhRDQjJgaxLqOIfuUciPGbKBz='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(wmECryhRDQjJgaxLqOIfuUciPGbKBl)
    wmECryhRDQjJgaxLqOIfuUciPGbKBS=[('(통합) 찜 영상에 추가',wmECryhRDQjJgaxLqOIfuUciPGbKBz)]
   else:
    wmECryhRDQjJgaxLqOIfuUciPGbKBS=wmECryhRDQjJgaxLqOIfuUciPGbKst
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel='',img=wmECryhRDQjJgaxLqOIfuUciPGbKko,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKBs,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKkd,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN,isLink=wmECryhRDQjJgaxLqOIfuUciPGbKsB,ContextMenu=wmECryhRDQjJgaxLqOIfuUciPGbKBS)
  if wmECryhRDQjJgaxLqOIfuUciPGbKkF:
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['mode'] ='SEARCH' 
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['search_key']=wmECryhRDQjJgaxLqOIfuUciPGbKMl
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['page'] =wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKtT='[B]%s >>[/B]'%'다음 페이지'
   wmECryhRDQjJgaxLqOIfuUciPGbKBe=wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKto=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel=wmECryhRDQjJgaxLqOIfuUciPGbKBe,img=wmECryhRDQjJgaxLqOIfuUciPGbKto,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKst,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN)
  if wmECryhRDQjJgaxLqOIfuUciPGbKkT=='movie':xbmcplugin.setContent(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,'movies')
  else:xbmcplugin.setContent(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,cacheToDisc=wmECryhRDQjJgaxLqOIfuUciPGbKsB)
 def dp_History_Remove(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKVA=wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('delType')
  wmECryhRDQjJgaxLqOIfuUciPGbKVY =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('sKey')
  wmECryhRDQjJgaxLqOIfuUciPGbKVs =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('vType')
  wmECryhRDQjJgaxLqOIfuUciPGbKdp=xbmcgui.Dialog()
  if wmECryhRDQjJgaxLqOIfuUciPGbKVA=='SEARCH_ALL':
   wmECryhRDQjJgaxLqOIfuUciPGbKke=wmECryhRDQjJgaxLqOIfuUciPGbKdp.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif wmECryhRDQjJgaxLqOIfuUciPGbKVA=='SEARCH_ONE':
   wmECryhRDQjJgaxLqOIfuUciPGbKke=wmECryhRDQjJgaxLqOIfuUciPGbKdp.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif wmECryhRDQjJgaxLqOIfuUciPGbKVA=='WATCH_ALL':
   wmECryhRDQjJgaxLqOIfuUciPGbKke=wmECryhRDQjJgaxLqOIfuUciPGbKdp.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif wmECryhRDQjJgaxLqOIfuUciPGbKVA=='WATCH_ONE':
   wmECryhRDQjJgaxLqOIfuUciPGbKke=wmECryhRDQjJgaxLqOIfuUciPGbKdp.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if wmECryhRDQjJgaxLqOIfuUciPGbKke==wmECryhRDQjJgaxLqOIfuUciPGbKsB:sys.exit()
  if wmECryhRDQjJgaxLqOIfuUciPGbKVA=='SEARCH_ALL':
   if os.path.isfile(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.SEARCHED_FILE_NAME):os.remove(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.SEARCHED_FILE_NAME)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKVA=='SEARCH_ONE':
   try:
    wmECryhRDQjJgaxLqOIfuUciPGbKVe=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.SEARCHED_FILE_NAME
    wmECryhRDQjJgaxLqOIfuUciPGbKVv=wmECryhRDQjJgaxLqOIfuUciPGbKdv.Load_List_File('search') 
    fp=wmECryhRDQjJgaxLqOIfuUciPGbKsT(wmECryhRDQjJgaxLqOIfuUciPGbKVe,'w',-1,'utf-8')
    for wmECryhRDQjJgaxLqOIfuUciPGbKVH in wmECryhRDQjJgaxLqOIfuUciPGbKVv:
     wmECryhRDQjJgaxLqOIfuUciPGbKVW=wmECryhRDQjJgaxLqOIfuUciPGbKsA(urllib.parse.parse_qsl(wmECryhRDQjJgaxLqOIfuUciPGbKVH))
     wmECryhRDQjJgaxLqOIfuUciPGbKVT=wmECryhRDQjJgaxLqOIfuUciPGbKVW.get('skey').strip()
     if wmECryhRDQjJgaxLqOIfuUciPGbKVY!=wmECryhRDQjJgaxLqOIfuUciPGbKVT:
      fp.write(wmECryhRDQjJgaxLqOIfuUciPGbKVH)
    fp.close()
   except:
    wmECryhRDQjJgaxLqOIfuUciPGbKst
  elif wmECryhRDQjJgaxLqOIfuUciPGbKVA=='WATCH_ALL':
   wmECryhRDQjJgaxLqOIfuUciPGbKVe=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wmECryhRDQjJgaxLqOIfuUciPGbKVs))
   if os.path.isfile(wmECryhRDQjJgaxLqOIfuUciPGbKVe):os.remove(wmECryhRDQjJgaxLqOIfuUciPGbKVe)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKVA=='WATCH_ONE':
   wmECryhRDQjJgaxLqOIfuUciPGbKVe=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wmECryhRDQjJgaxLqOIfuUciPGbKVs))
   try:
    wmECryhRDQjJgaxLqOIfuUciPGbKVv=wmECryhRDQjJgaxLqOIfuUciPGbKdv.Load_List_File(wmECryhRDQjJgaxLqOIfuUciPGbKVs) 
    fp=wmECryhRDQjJgaxLqOIfuUciPGbKsT(wmECryhRDQjJgaxLqOIfuUciPGbKVe,'w',-1,'utf-8')
    for wmECryhRDQjJgaxLqOIfuUciPGbKVH in wmECryhRDQjJgaxLqOIfuUciPGbKVv:
     wmECryhRDQjJgaxLqOIfuUciPGbKVW=wmECryhRDQjJgaxLqOIfuUciPGbKsA(urllib.parse.parse_qsl(wmECryhRDQjJgaxLqOIfuUciPGbKVH))
     wmECryhRDQjJgaxLqOIfuUciPGbKVT=wmECryhRDQjJgaxLqOIfuUciPGbKVW.get('code').strip()
     if wmECryhRDQjJgaxLqOIfuUciPGbKVY!=wmECryhRDQjJgaxLqOIfuUciPGbKVT:
      fp.write(wmECryhRDQjJgaxLqOIfuUciPGbKVH)
    fp.close()
   except:
    wmECryhRDQjJgaxLqOIfuUciPGbKst
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkT): 
  try:
   if wmECryhRDQjJgaxLqOIfuUciPGbKkT=='search':
    wmECryhRDQjJgaxLqOIfuUciPGbKVe=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.SEARCHED_FILE_NAME
   elif wmECryhRDQjJgaxLqOIfuUciPGbKkT in['vod','movie']:
    wmECryhRDQjJgaxLqOIfuUciPGbKVe=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wmECryhRDQjJgaxLqOIfuUciPGbKkT))
   else:
    return[]
   fp=wmECryhRDQjJgaxLqOIfuUciPGbKsT(wmECryhRDQjJgaxLqOIfuUciPGbKVe,'r',-1,'utf-8')
   wmECryhRDQjJgaxLqOIfuUciPGbKVn=fp.readlines()
   fp.close()
  except:
   wmECryhRDQjJgaxLqOIfuUciPGbKVn=[]
  return wmECryhRDQjJgaxLqOIfuUciPGbKVn
 def Save_Watched_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkT,wmECryhRDQjJgaxLqOIfuUciPGbKdT):
  try:
   wmECryhRDQjJgaxLqOIfuUciPGbKVp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%wmECryhRDQjJgaxLqOIfuUciPGbKkT))
   wmECryhRDQjJgaxLqOIfuUciPGbKVv=wmECryhRDQjJgaxLqOIfuUciPGbKdv.Load_List_File(wmECryhRDQjJgaxLqOIfuUciPGbKkT) 
   fp=wmECryhRDQjJgaxLqOIfuUciPGbKsT(wmECryhRDQjJgaxLqOIfuUciPGbKVp,'w',-1,'utf-8')
   wmECryhRDQjJgaxLqOIfuUciPGbKVl=urllib.parse.urlencode(wmECryhRDQjJgaxLqOIfuUciPGbKdT)
   wmECryhRDQjJgaxLqOIfuUciPGbKVl=wmECryhRDQjJgaxLqOIfuUciPGbKVl+'\n'
   fp.write(wmECryhRDQjJgaxLqOIfuUciPGbKVl)
   wmECryhRDQjJgaxLqOIfuUciPGbKVz=0
   for wmECryhRDQjJgaxLqOIfuUciPGbKVH in wmECryhRDQjJgaxLqOIfuUciPGbKVv:
    wmECryhRDQjJgaxLqOIfuUciPGbKVW=wmECryhRDQjJgaxLqOIfuUciPGbKsA(urllib.parse.parse_qsl(wmECryhRDQjJgaxLqOIfuUciPGbKVH))
    wmECryhRDQjJgaxLqOIfuUciPGbKVS=wmECryhRDQjJgaxLqOIfuUciPGbKdT.get('code').strip()
    wmECryhRDQjJgaxLqOIfuUciPGbKVF=wmECryhRDQjJgaxLqOIfuUciPGbKVW.get('code').strip()
    if wmECryhRDQjJgaxLqOIfuUciPGbKkT=='vod' and wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_settings_direct_replay()==wmECryhRDQjJgaxLqOIfuUciPGbKsM:
     wmECryhRDQjJgaxLqOIfuUciPGbKVS=wmECryhRDQjJgaxLqOIfuUciPGbKdT.get('videoid').strip()
     wmECryhRDQjJgaxLqOIfuUciPGbKVF=wmECryhRDQjJgaxLqOIfuUciPGbKVW.get('videoid').strip()if wmECryhRDQjJgaxLqOIfuUciPGbKVF!=wmECryhRDQjJgaxLqOIfuUciPGbKst else '-'
    if wmECryhRDQjJgaxLqOIfuUciPGbKVS!=wmECryhRDQjJgaxLqOIfuUciPGbKVF:
     fp.write(wmECryhRDQjJgaxLqOIfuUciPGbKVH)
     wmECryhRDQjJgaxLqOIfuUciPGbKVz+=1
     if wmECryhRDQjJgaxLqOIfuUciPGbKVz>=50:break
   fp.close()
  except:
   wmECryhRDQjJgaxLqOIfuUciPGbKst
 def dp_Watch_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKkT =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('stype')
  wmECryhRDQjJgaxLqOIfuUciPGbKte=wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_settings_direct_replay()
  if wmECryhRDQjJgaxLqOIfuUciPGbKkT=='-':
   for wmECryhRDQjJgaxLqOIfuUciPGbKkp in wmECryhRDQjJgaxLqOIfuUciPGbKdM:
    wmECryhRDQjJgaxLqOIfuUciPGbKtT=wmECryhRDQjJgaxLqOIfuUciPGbKkp.get('title')
    wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':wmECryhRDQjJgaxLqOIfuUciPGbKkp.get('mode'),'stype':wmECryhRDQjJgaxLqOIfuUciPGbKkp.get('stype')}
    wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel='',img='',infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKst,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN)
   if wmECryhRDQjJgaxLqOIfuUciPGbKsv(wmECryhRDQjJgaxLqOIfuUciPGbKdM)>0:xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle)
  else:
   wmECryhRDQjJgaxLqOIfuUciPGbKVX=wmECryhRDQjJgaxLqOIfuUciPGbKdv.Load_List_File(wmECryhRDQjJgaxLqOIfuUciPGbKkT)
   for wmECryhRDQjJgaxLqOIfuUciPGbKVo in wmECryhRDQjJgaxLqOIfuUciPGbKVX:
    wmECryhRDQjJgaxLqOIfuUciPGbKVd=wmECryhRDQjJgaxLqOIfuUciPGbKsA(urllib.parse.parse_qsl(wmECryhRDQjJgaxLqOIfuUciPGbKVo))
    wmECryhRDQjJgaxLqOIfuUciPGbKVN =wmECryhRDQjJgaxLqOIfuUciPGbKVd.get('code').strip()
    wmECryhRDQjJgaxLqOIfuUciPGbKtT =wmECryhRDQjJgaxLqOIfuUciPGbKVd.get('title').strip()
    wmECryhRDQjJgaxLqOIfuUciPGbKko=wmECryhRDQjJgaxLqOIfuUciPGbKVd.get('img').strip()
    wmECryhRDQjJgaxLqOIfuUciPGbKMv =wmECryhRDQjJgaxLqOIfuUciPGbKVd.get('videoid').strip()
    try:
     wmECryhRDQjJgaxLqOIfuUciPGbKko=wmECryhRDQjJgaxLqOIfuUciPGbKko.replace('\'','\"')
     wmECryhRDQjJgaxLqOIfuUciPGbKko=json.loads(wmECryhRDQjJgaxLqOIfuUciPGbKko)
    except:
     wmECryhRDQjJgaxLqOIfuUciPGbKst
    wmECryhRDQjJgaxLqOIfuUciPGbKBs={}
    wmECryhRDQjJgaxLqOIfuUciPGbKBs['plot']=wmECryhRDQjJgaxLqOIfuUciPGbKtT
    if wmECryhRDQjJgaxLqOIfuUciPGbKkT=='vod':
     if wmECryhRDQjJgaxLqOIfuUciPGbKte==wmECryhRDQjJgaxLqOIfuUciPGbKsB or wmECryhRDQjJgaxLqOIfuUciPGbKMv==wmECryhRDQjJgaxLqOIfuUciPGbKst:
      wmECryhRDQjJgaxLqOIfuUciPGbKBs['mediatype']='tvshow'
      wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'EPISODE','programcode':wmECryhRDQjJgaxLqOIfuUciPGbKVN,'page':'1'}
      wmECryhRDQjJgaxLqOIfuUciPGbKkd=wmECryhRDQjJgaxLqOIfuUciPGbKsM
     else:
      wmECryhRDQjJgaxLqOIfuUciPGbKBs['mediatype']='episode'
      wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'VOD','mediacode':wmECryhRDQjJgaxLqOIfuUciPGbKMv,'stype':'vod','programcode':wmECryhRDQjJgaxLqOIfuUciPGbKVN,'title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'thumbnail':wmECryhRDQjJgaxLqOIfuUciPGbKko}
      wmECryhRDQjJgaxLqOIfuUciPGbKkd=wmECryhRDQjJgaxLqOIfuUciPGbKsB
    else:
     wmECryhRDQjJgaxLqOIfuUciPGbKBs['mediatype']='movie'
     wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'MOVIE','mediacode':wmECryhRDQjJgaxLqOIfuUciPGbKVN,'stype':'movie','title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'thumbnail':wmECryhRDQjJgaxLqOIfuUciPGbKko}
     wmECryhRDQjJgaxLqOIfuUciPGbKkd=wmECryhRDQjJgaxLqOIfuUciPGbKsB
    wmECryhRDQjJgaxLqOIfuUciPGbKVk={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':wmECryhRDQjJgaxLqOIfuUciPGbKVN,'vType':wmECryhRDQjJgaxLqOIfuUciPGbKkT,}
    wmECryhRDQjJgaxLqOIfuUciPGbKVB=urllib.parse.urlencode(wmECryhRDQjJgaxLqOIfuUciPGbKVk)
    wmECryhRDQjJgaxLqOIfuUciPGbKBS=[('선택된 시청이력 ( %s ) 삭제'%(wmECryhRDQjJgaxLqOIfuUciPGbKtT),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(wmECryhRDQjJgaxLqOIfuUciPGbKVB))]
    wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel='',img=wmECryhRDQjJgaxLqOIfuUciPGbKko,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKBs,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKkd,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN,ContextMenu=wmECryhRDQjJgaxLqOIfuUciPGbKBS)
   wmECryhRDQjJgaxLqOIfuUciPGbKBs={'plot':'시청목록을 삭제합니다.'}
   wmECryhRDQjJgaxLqOIfuUciPGbKtT='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':wmECryhRDQjJgaxLqOIfuUciPGbKkT,}
   wmECryhRDQjJgaxLqOIfuUciPGbKto=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel='',img=wmECryhRDQjJgaxLqOIfuUciPGbKto,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKBs,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsB,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN,isLink=wmECryhRDQjJgaxLqOIfuUciPGbKsM)
   if wmECryhRDQjJgaxLqOIfuUciPGbKkT=='movie':xbmcplugin.setContent(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,'movies')
   else:xbmcplugin.setContent(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,cacheToDisc=wmECryhRDQjJgaxLqOIfuUciPGbKsB)
 def Save_Searched_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKMl):
  try:
   wmECryhRDQjJgaxLqOIfuUciPGbKAd=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.SEARCHED_FILE_NAME
   wmECryhRDQjJgaxLqOIfuUciPGbKVv=wmECryhRDQjJgaxLqOIfuUciPGbKdv.Load_List_File('search') 
   wmECryhRDQjJgaxLqOIfuUciPGbKAt={'skey':wmECryhRDQjJgaxLqOIfuUciPGbKMl.strip()}
   fp=wmECryhRDQjJgaxLqOIfuUciPGbKsT(wmECryhRDQjJgaxLqOIfuUciPGbKAd,'w',-1,'utf-8')
   wmECryhRDQjJgaxLqOIfuUciPGbKVl=urllib.parse.urlencode(wmECryhRDQjJgaxLqOIfuUciPGbKAt)
   wmECryhRDQjJgaxLqOIfuUciPGbKVl=wmECryhRDQjJgaxLqOIfuUciPGbKVl+'\n'
   fp.write(wmECryhRDQjJgaxLqOIfuUciPGbKVl)
   wmECryhRDQjJgaxLqOIfuUciPGbKVz=0
   for wmECryhRDQjJgaxLqOIfuUciPGbKVH in wmECryhRDQjJgaxLqOIfuUciPGbKVv:
    wmECryhRDQjJgaxLqOIfuUciPGbKVW=wmECryhRDQjJgaxLqOIfuUciPGbKsA(urllib.parse.parse_qsl(wmECryhRDQjJgaxLqOIfuUciPGbKVH))
    wmECryhRDQjJgaxLqOIfuUciPGbKVS=wmECryhRDQjJgaxLqOIfuUciPGbKAt.get('skey').strip()
    wmECryhRDQjJgaxLqOIfuUciPGbKVF=wmECryhRDQjJgaxLqOIfuUciPGbKVW.get('skey').strip()
    if wmECryhRDQjJgaxLqOIfuUciPGbKVS!=wmECryhRDQjJgaxLqOIfuUciPGbKVF:
     fp.write(wmECryhRDQjJgaxLqOIfuUciPGbKVH)
     wmECryhRDQjJgaxLqOIfuUciPGbKVz+=1
     if wmECryhRDQjJgaxLqOIfuUciPGbKVz>=50:break
   fp.close()
  except:
   wmECryhRDQjJgaxLqOIfuUciPGbKst
 def play_VIDEO(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKAk =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('mediacode')
  wmECryhRDQjJgaxLqOIfuUciPGbKkT =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('stype')
  wmECryhRDQjJgaxLqOIfuUciPGbKAB =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('pvrmode')
  wmECryhRDQjJgaxLqOIfuUciPGbKAM=wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_selQuality(wmECryhRDQjJgaxLqOIfuUciPGbKkT)
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(wmECryhRDQjJgaxLqOIfuUciPGbKAk,wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKAM),wmECryhRDQjJgaxLqOIfuUciPGbKkT,wmECryhRDQjJgaxLqOIfuUciPGbKAB))
  wmECryhRDQjJgaxLqOIfuUciPGbKAV=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.GetBroadURL(wmECryhRDQjJgaxLqOIfuUciPGbKAk,wmECryhRDQjJgaxLqOIfuUciPGbKAM,wmECryhRDQjJgaxLqOIfuUciPGbKkT,wmECryhRDQjJgaxLqOIfuUciPGbKAB,optUHD=wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_settings_uhd())
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_log('qt, stype, url : %s - %s - %s'%(wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKAM),wmECryhRDQjJgaxLqOIfuUciPGbKkT,wmECryhRDQjJgaxLqOIfuUciPGbKAV['streaming_url']))
  if wmECryhRDQjJgaxLqOIfuUciPGbKAV['streaming_url']=='':
   if wmECryhRDQjJgaxLqOIfuUciPGbKAV['error_msg']=='':
    wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_noti(__language__(30908).encode('utf8'))
   else:
    wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_noti(wmECryhRDQjJgaxLqOIfuUciPGbKAV['error_msg'].encode('utf8'))
   return
  if wmECryhRDQjJgaxLqOIfuUciPGbKAV['qt_stream']=='stream70':
   wmECryhRDQjJgaxLqOIfuUciPGbKAY={'user-agent':wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.USER_AGENT_ATV}
  else:
   wmECryhRDQjJgaxLqOIfuUciPGbKAY={'user-agent':wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.USER_AGENT}
  wmECryhRDQjJgaxLqOIfuUciPGbKAs=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.makeDefaultCookies() 
  if wmECryhRDQjJgaxLqOIfuUciPGbKAV['watermark'] !='':
   wmECryhRDQjJgaxLqOIfuUciPGbKAY['x-tving-param1']=wmECryhRDQjJgaxLqOIfuUciPGbKAV['watermarkKey']
   wmECryhRDQjJgaxLqOIfuUciPGbKAY['x-tving-param2']=wmECryhRDQjJgaxLqOIfuUciPGbKAV['watermark'] 
  if wmECryhRDQjJgaxLqOIfuUciPGbKAV['drm_server_url'] !='':
   wmECryhRDQjJgaxLqOIfuUciPGbKAY[wmECryhRDQjJgaxLqOIfuUciPGbKAV['drm_header_key']]=wmECryhRDQjJgaxLqOIfuUciPGbKAV['drm_header_value']
  wmECryhRDQjJgaxLqOIfuUciPGbKAe =wmECryhRDQjJgaxLqOIfuUciPGbKsB
  wmECryhRDQjJgaxLqOIfuUciPGbKAv =wmECryhRDQjJgaxLqOIfuUciPGbKAV['streaming_url'].find('Policy=')
  if wmECryhRDQjJgaxLqOIfuUciPGbKAv!=-1:
   wmECryhRDQjJgaxLqOIfuUciPGbKAH =wmECryhRDQjJgaxLqOIfuUciPGbKAV['streaming_url'].split('?')[0]
   wmECryhRDQjJgaxLqOIfuUciPGbKAW=wmECryhRDQjJgaxLqOIfuUciPGbKsA(urllib.parse.parse_qsl(urllib.parse.urlsplit(wmECryhRDQjJgaxLqOIfuUciPGbKAV['streaming_url']).query))
   wmECryhRDQjJgaxLqOIfuUciPGbKAs['CloudFront-Policy'] =wmECryhRDQjJgaxLqOIfuUciPGbKAW['Policy'] 
   wmECryhRDQjJgaxLqOIfuUciPGbKAs['CloudFront-Signature'] =wmECryhRDQjJgaxLqOIfuUciPGbKAW['Signature'] 
   wmECryhRDQjJgaxLqOIfuUciPGbKAs['CloudFront-Key-Pair-Id']=wmECryhRDQjJgaxLqOIfuUciPGbKAW['Key-Pair-Id'] 
   wmECryhRDQjJgaxLqOIfuUciPGbKAT=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.make_stream_header(wmECryhRDQjJgaxLqOIfuUciPGbKAY,wmECryhRDQjJgaxLqOIfuUciPGbKAs)
   if 'quickvod-mcdn.tving.com' in wmECryhRDQjJgaxLqOIfuUciPGbKAH:
    wmECryhRDQjJgaxLqOIfuUciPGbKAe=wmECryhRDQjJgaxLqOIfuUciPGbKsM
    wmECryhRDQjJgaxLqOIfuUciPGbKAn =wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    wmECryhRDQjJgaxLqOIfuUciPGbKAp=wmECryhRDQjJgaxLqOIfuUciPGbKAn.strftime('%Y-%m-%d-%H:%M:%S')
    if wmECryhRDQjJgaxLqOIfuUciPGbKsk(wmECryhRDQjJgaxLqOIfuUciPGbKAp.replace('-','').replace(':',''))<wmECryhRDQjJgaxLqOIfuUciPGbKsk(wmECryhRDQjJgaxLqOIfuUciPGbKAW['end'].replace('-','').replace(':','')):
     wmECryhRDQjJgaxLqOIfuUciPGbKAW['end']=wmECryhRDQjJgaxLqOIfuUciPGbKAp
     wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_noti(__language__(30915).encode('utf8'))
    wmECryhRDQjJgaxLqOIfuUciPGbKAH ='%s?%s'%(wmECryhRDQjJgaxLqOIfuUciPGbKAH,urllib.parse.urlencode(wmECryhRDQjJgaxLqOIfuUciPGbKAW,doseq=wmECryhRDQjJgaxLqOIfuUciPGbKsM))
    wmECryhRDQjJgaxLqOIfuUciPGbKAl='{}|{}'.format(wmECryhRDQjJgaxLqOIfuUciPGbKAH,wmECryhRDQjJgaxLqOIfuUciPGbKAT)
   else:
    wmECryhRDQjJgaxLqOIfuUciPGbKAl='{}|{}'.format(wmECryhRDQjJgaxLqOIfuUciPGbKAV['streaming_url'],wmECryhRDQjJgaxLqOIfuUciPGbKAT)
  else:
   wmECryhRDQjJgaxLqOIfuUciPGbKAT=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.make_stream_header(wmECryhRDQjJgaxLqOIfuUciPGbKAY,wmECryhRDQjJgaxLqOIfuUciPGbKAs)
   wmECryhRDQjJgaxLqOIfuUciPGbKAl='{}|{}'.format(wmECryhRDQjJgaxLqOIfuUciPGbKAV['streaming_url'],wmECryhRDQjJgaxLqOIfuUciPGbKAT)
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_log('if tmp_pos == -1')
  wmECryhRDQjJgaxLqOIfuUciPGbKtk,wmECryhRDQjJgaxLqOIfuUciPGbKtB=wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_settings_proxyport()
  wmECryhRDQjJgaxLqOIfuUciPGbKtd=wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_settings_playback()
  if(wmECryhRDQjJgaxLqOIfuUciPGbKtk and wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('mode')in['VOD','MOVIE']and wmECryhRDQjJgaxLqOIfuUciPGbKAe==wmECryhRDQjJgaxLqOIfuUciPGbKsB and(wmECryhRDQjJgaxLqOIfuUciPGbKAV['drm_server_url']!='' or(wmECryhRDQjJgaxLqOIfuUciPGbKAV['url_filename'].split('.')[1]=='mpd')or(wmECryhRDQjJgaxLqOIfuUciPGbKAV['url_filename'].split('.')[1]!='mpd' and wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.KodiVersion>=21 and wmECryhRDQjJgaxLqOIfuUciPGbKAV['qt_stream']=='stream70'))):
   if wmECryhRDQjJgaxLqOIfuUciPGbKAV['url_filename'].split('.')[1]=='mpd':
    wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Tving_Parse_mpd(wmECryhRDQjJgaxLqOIfuUciPGbKAV['streaming_url'],wmECryhRDQjJgaxLqOIfuUciPGbKAV['watermarkKey'],wmECryhRDQjJgaxLqOIfuUciPGbKAV['watermark'])
   else:
    wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Tving_Parse_m3u8(wmECryhRDQjJgaxLqOIfuUciPGbKAV['streaming_url'])
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_log('xxx '+wmECryhRDQjJgaxLqOIfuUciPGbKAV['streaming_url'])
   wmECryhRDQjJgaxLqOIfuUciPGbKAz={'addon':'tvingm','playOption':wmECryhRDQjJgaxLqOIfuUciPGbKtd,'url_filename':wmECryhRDQjJgaxLqOIfuUciPGbKAV['url_filename'],}
   wmECryhRDQjJgaxLqOIfuUciPGbKAz=json.dumps(wmECryhRDQjJgaxLqOIfuUciPGbKAz,separators=(',',':'))
   wmECryhRDQjJgaxLqOIfuUciPGbKAz=base64.standard_b64encode(wmECryhRDQjJgaxLqOIfuUciPGbKAz.encode()).decode('utf-8')
   wmECryhRDQjJgaxLqOIfuUciPGbKAl ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(wmECryhRDQjJgaxLqOIfuUciPGbKtB,wmECryhRDQjJgaxLqOIfuUciPGbKAl,wmECryhRDQjJgaxLqOIfuUciPGbKAz)
   wmECryhRDQjJgaxLqOIfuUciPGbKAY['proxy-mini']=wmECryhRDQjJgaxLqOIfuUciPGbKAz 
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_log('surl(2) : {}'.format(wmECryhRDQjJgaxLqOIfuUciPGbKAl))
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_log('drm     : {}'.format(wmECryhRDQjJgaxLqOIfuUciPGbKAV['drm_server_url']))
  wmECryhRDQjJgaxLqOIfuUciPGbKAT=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.make_stream_header(wmECryhRDQjJgaxLqOIfuUciPGbKAY,wmECryhRDQjJgaxLqOIfuUciPGbKAs)
  wmECryhRDQjJgaxLqOIfuUciPGbKAS=xbmcgui.ListItem(path=wmECryhRDQjJgaxLqOIfuUciPGbKAl)
  if wmECryhRDQjJgaxLqOIfuUciPGbKAV['drm_server_url']!='':
   wmECryhRDQjJgaxLqOIfuUciPGbKAF=wmECryhRDQjJgaxLqOIfuUciPGbKAV['drm_server_url']
   wmECryhRDQjJgaxLqOIfuUciPGbKAX ='https://license-global.pallycon.com/ri/licenseManager.do' 
   wmECryhRDQjJgaxLqOIfuUciPGbKAo ='mpd'
   wmECryhRDQjJgaxLqOIfuUciPGbKAN ='com.widevine.alpha'
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   wmECryhRDQjJgaxLqOIfuUciPGbKYt={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.USER_AGENT,wmECryhRDQjJgaxLqOIfuUciPGbKAV['drm_header_key']:wmECryhRDQjJgaxLqOIfuUciPGbKAV['drm_header_value'],}
   wmECryhRDQjJgaxLqOIfuUciPGbKYk=wmECryhRDQjJgaxLqOIfuUciPGbKAX+'|'+urllib.parse.urlencode(wmECryhRDQjJgaxLqOIfuUciPGbKYt)+'|R{SSM}|'
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream','inputstream.adaptive')
   if wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.KodiVersion<=20:
    wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream.adaptive.manifest_type',wmECryhRDQjJgaxLqOIfuUciPGbKAo)
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream.adaptive.license_type',wmECryhRDQjJgaxLqOIfuUciPGbKAN)
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream.adaptive.license_key',wmECryhRDQjJgaxLqOIfuUciPGbKYk)
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream.adaptive.stream_headers',wmECryhRDQjJgaxLqOIfuUciPGbKAT)
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream.adaptive.manifest_headers',wmECryhRDQjJgaxLqOIfuUciPGbKAT)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('mode')in['VOD','MOVIE']:
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setContentLookup(wmECryhRDQjJgaxLqOIfuUciPGbKsB)
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setMimeType('application/x-mpegURL')
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream','inputstream.adaptive')
   if wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.KodiVersion<=20:
    wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream.adaptive.manifest_type','hls')
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream.adaptive.stream_headers',wmECryhRDQjJgaxLqOIfuUciPGbKAT)
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream.adaptive.manifest_headers',wmECryhRDQjJgaxLqOIfuUciPGbKAT)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKAe==wmECryhRDQjJgaxLqOIfuUciPGbKsM:
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setContentLookup(wmECryhRDQjJgaxLqOIfuUciPGbKsB)
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setMimeType('application/x-mpegURL')
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream','inputstream.ffmpegdirect')
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('ResumeTime','0')
   wmECryhRDQjJgaxLqOIfuUciPGbKAS.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,wmECryhRDQjJgaxLqOIfuUciPGbKsM,wmECryhRDQjJgaxLqOIfuUciPGbKAS)
  try:
   if wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('mode')in['VOD','MOVIE']and wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('title'):
    wmECryhRDQjJgaxLqOIfuUciPGbKtN={'code':wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('programcode')if wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('mode')=='VOD' else wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('mediacode'),'img':wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('thumbnail'),'title':wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('title'),'videoid':wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('mediacode')}
    wmECryhRDQjJgaxLqOIfuUciPGbKdv.Save_Watched_List(wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('stype'),wmECryhRDQjJgaxLqOIfuUciPGbKtN)
  except:
   wmECryhRDQjJgaxLqOIfuUciPGbKst
 def logout(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  wmECryhRDQjJgaxLqOIfuUciPGbKdp=xbmcgui.Dialog()
  wmECryhRDQjJgaxLqOIfuUciPGbKke=wmECryhRDQjJgaxLqOIfuUciPGbKdp.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if wmECryhRDQjJgaxLqOIfuUciPGbKke==wmECryhRDQjJgaxLqOIfuUciPGbKsB:sys.exit()
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Init_TV_Total()
  if os.path.isfile(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_COOKIE_FILENAME):os.remove(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_COOKIE_FILENAME)
  if os.path.isfile(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_TOKEN_FILENAME): os.remove(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_TOKEN_FILENAME)
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  wmECryhRDQjJgaxLqOIfuUciPGbKYB =wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Get_Now_Datetime()
  wmECryhRDQjJgaxLqOIfuUciPGbKYM=wmECryhRDQjJgaxLqOIfuUciPGbKYB+datetime.timedelta(days=30) 
  (wmECryhRDQjJgaxLqOIfuUciPGbKkV,wmECryhRDQjJgaxLqOIfuUciPGbKkA,wmECryhRDQjJgaxLqOIfuUciPGbKkY,wmECryhRDQjJgaxLqOIfuUciPGbKks)=wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_settings_account()
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Save_session_acount(wmECryhRDQjJgaxLqOIfuUciPGbKkV,wmECryhRDQjJgaxLqOIfuUciPGbKkA,wmECryhRDQjJgaxLqOIfuUciPGbKkY,wmECryhRDQjJgaxLqOIfuUciPGbKks)
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV['account']['token_limit']=wmECryhRDQjJgaxLqOIfuUciPGbKYM.strftime('%Y%m%d')
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.JsonFile_Save(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_COOKIE_FILENAME,wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV)
 def cookiefile_check(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.JsonFile_Load(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_COOKIE_FILENAME)
  if wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV=={}:
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Init_TV_Total()
   return wmECryhRDQjJgaxLqOIfuUciPGbKsB
  (wmECryhRDQjJgaxLqOIfuUciPGbKYV,wmECryhRDQjJgaxLqOIfuUciPGbKYA,wmECryhRDQjJgaxLqOIfuUciPGbKYs,wmECryhRDQjJgaxLqOIfuUciPGbKYe)=wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_settings_account()
  (wmECryhRDQjJgaxLqOIfuUciPGbKYv,wmECryhRDQjJgaxLqOIfuUciPGbKYH,wmECryhRDQjJgaxLqOIfuUciPGbKYW,wmECryhRDQjJgaxLqOIfuUciPGbKYT)=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Load_session_acount()
  if(wmECryhRDQjJgaxLqOIfuUciPGbKYV!=wmECryhRDQjJgaxLqOIfuUciPGbKYv or wmECryhRDQjJgaxLqOIfuUciPGbKYA!=wmECryhRDQjJgaxLqOIfuUciPGbKYH or wmECryhRDQjJgaxLqOIfuUciPGbKYs!=wmECryhRDQjJgaxLqOIfuUciPGbKYW or wmECryhRDQjJgaxLqOIfuUciPGbKYe!=wmECryhRDQjJgaxLqOIfuUciPGbKYT)and wmECryhRDQjJgaxLqOIfuUciPGbKYv!='xxxxx':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Init_TV_Total()
   return wmECryhRDQjJgaxLqOIfuUciPGbKsB
  if wmECryhRDQjJgaxLqOIfuUciPGbKsk(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>wmECryhRDQjJgaxLqOIfuUciPGbKsk(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV['account']['token_limit']):
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Init_TV_Total()
   return wmECryhRDQjJgaxLqOIfuUciPGbKsB
  return wmECryhRDQjJgaxLqOIfuUciPGbKsM
 def tokenfile_check(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_TOKEN=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.JsonFile_Load(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_TOKEN_FILENAME)
  if wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_TOKEN=={}:
   return wmECryhRDQjJgaxLqOIfuUciPGbKsB
  if wmECryhRDQjJgaxLqOIfuUciPGbKsk(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>wmECryhRDQjJgaxLqOIfuUciPGbKsk(wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_TOKEN['token_date']):
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.TV_TOKEN={}
   return wmECryhRDQjJgaxLqOIfuUciPGbKsB
  return wmECryhRDQjJgaxLqOIfuUciPGbKsM
 def get_reToken(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  if wmECryhRDQjJgaxLqOIfuUciPGbKdv.tokenfile_check()==wmECryhRDQjJgaxLqOIfuUciPGbKsB:
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Get_AccessToken()
 def dp_Global_Search(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKMz=wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('mode')
  if wmECryhRDQjJgaxLqOIfuUciPGbKMz=='TOTAL_SEARCH':
   wmECryhRDQjJgaxLqOIfuUciPGbKYn='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   wmECryhRDQjJgaxLqOIfuUciPGbKYn='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(wmECryhRDQjJgaxLqOIfuUciPGbKYn)
 def dp_Bookmark_Menu(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKYn='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(wmECryhRDQjJgaxLqOIfuUciPGbKYn)
 def dp_Apple_Group(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKYp=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Get_AppleGroup_List()
  for wmECryhRDQjJgaxLqOIfuUciPGbKYl in wmECryhRDQjJgaxLqOIfuUciPGbKYp:
   wmECryhRDQjJgaxLqOIfuUciPGbKYz =wmECryhRDQjJgaxLqOIfuUciPGbKYl.get('bandName')
   wmECryhRDQjJgaxLqOIfuUciPGbKYS =wmECryhRDQjJgaxLqOIfuUciPGbKYl.get('bandKey')
   wmECryhRDQjJgaxLqOIfuUciPGbKBs={'mediatype':'tvshow','title':wmECryhRDQjJgaxLqOIfuUciPGbKYz,'plot':'%s'%(wmECryhRDQjJgaxLqOIfuUciPGbKYS),}
   wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'BAND_VODLIST','bandKey':wmECryhRDQjJgaxLqOIfuUciPGbKYS,'page':'1','nextApiUrl':'-',}
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKYz,sublabel=wmECryhRDQjJgaxLqOIfuUciPGbKst,img='',infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKBs,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN)
  if wmECryhRDQjJgaxLqOIfuUciPGbKsv(wmECryhRDQjJgaxLqOIfuUciPGbKYp)>0:xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,cacheToDisc=wmECryhRDQjJgaxLqOIfuUciPGbKsB)
 def dp_Band_VodList(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKYS =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('bandKey') 
  wmECryhRDQjJgaxLqOIfuUciPGbKYF =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('bandGroup') 
  wmECryhRDQjJgaxLqOIfuUciPGbKYX =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('nextApiUrl')
  wmECryhRDQjJgaxLqOIfuUciPGbKYo =''
  wmECryhRDQjJgaxLqOIfuUciPGbKkz =wmECryhRDQjJgaxLqOIfuUciPGbKsk(wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('page'))
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_log('bandKey    : {}'.format(wmECryhRDQjJgaxLqOIfuUciPGbKYS))
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_log('bandGroup  : {}'.format(wmECryhRDQjJgaxLqOIfuUciPGbKYF))
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_log('nextApiUrl : {}'.format(wmECryhRDQjJgaxLqOIfuUciPGbKYX))
  if wmECryhRDQjJgaxLqOIfuUciPGbKYF=='TVING_APPLE_HOUR':
   wmECryhRDQjJgaxLqOIfuUciPGbKBW,wmECryhRDQjJgaxLqOIfuUciPGbKYX=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Get_Apple_NowList()
  else:
   if wmECryhRDQjJgaxLqOIfuUciPGbKYF not in['',wmECryhRDQjJgaxLqOIfuUciPGbKst]:
    wmECryhRDQjJgaxLqOIfuUciPGbKYS=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Get_bandCode_GroupCode(wmECryhRDQjJgaxLqOIfuUciPGbKYF)
    wmECryhRDQjJgaxLqOIfuUciPGbKdv.addon_log('new bandKey    : {}'.format(wmECryhRDQjJgaxLqOIfuUciPGbKYS))
   wmECryhRDQjJgaxLqOIfuUciPGbKBW,wmECryhRDQjJgaxLqOIfuUciPGbKYX=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Get_Band_VodList(wmECryhRDQjJgaxLqOIfuUciPGbKYS,wmECryhRDQjJgaxLqOIfuUciPGbKYX)
  for wmECryhRDQjJgaxLqOIfuUciPGbKBT in wmECryhRDQjJgaxLqOIfuUciPGbKBW:
   wmECryhRDQjJgaxLqOIfuUciPGbKtT =wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('title')
   wmECryhRDQjJgaxLqOIfuUciPGbKko =wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('thumbnail')
   wmECryhRDQjJgaxLqOIfuUciPGbKMv =wmECryhRDQjJgaxLqOIfuUciPGbKBT.get('program')
   wmECryhRDQjJgaxLqOIfuUciPGbKBs={'mediatype':'tvshow' if not wmECryhRDQjJgaxLqOIfuUciPGbKMv.startswith('M')else 'movie','title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'plot':wmECryhRDQjJgaxLqOIfuUciPGbKtT+'\n'+'tvshow' if not wmECryhRDQjJgaxLqOIfuUciPGbKMv.startswith('M')else 'movie',}
   if not wmECryhRDQjJgaxLqOIfuUciPGbKMv.startswith('M'):
    wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'EPISODE','programcode':wmECryhRDQjJgaxLqOIfuUciPGbKMv,'page':'1',}
    wmECryhRDQjJgaxLqOIfuUciPGbKkd=wmECryhRDQjJgaxLqOIfuUciPGbKsM
   else:
    wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'MOVIE','mediacode':wmECryhRDQjJgaxLqOIfuUciPGbKMv,'stype':'movie','title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'thumbnail':wmECryhRDQjJgaxLqOIfuUciPGbKko,}
    wmECryhRDQjJgaxLqOIfuUciPGbKkd=wmECryhRDQjJgaxLqOIfuUciPGbKsB
   if wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_settings_makebookmark():
    wmECryhRDQjJgaxLqOIfuUciPGbKBp={'videoid':wmECryhRDQjJgaxLqOIfuUciPGbKMv,'vidtype':'tvshow','vtitle':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'vsubtitle':wmECryhRDQjJgaxLqOIfuUciPGbKYo,}
    wmECryhRDQjJgaxLqOIfuUciPGbKBl=json.dumps(wmECryhRDQjJgaxLqOIfuUciPGbKBp)
    wmECryhRDQjJgaxLqOIfuUciPGbKBl=urllib.parse.quote(wmECryhRDQjJgaxLqOIfuUciPGbKBl)
    wmECryhRDQjJgaxLqOIfuUciPGbKBz='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(wmECryhRDQjJgaxLqOIfuUciPGbKBl)
    wmECryhRDQjJgaxLqOIfuUciPGbKBS=[('(통합) 찜 영상에 추가',wmECryhRDQjJgaxLqOIfuUciPGbKBz)]
   else:
    wmECryhRDQjJgaxLqOIfuUciPGbKBS=wmECryhRDQjJgaxLqOIfuUciPGbKst
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel=wmECryhRDQjJgaxLqOIfuUciPGbKYo,img=wmECryhRDQjJgaxLqOIfuUciPGbKko,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKBs,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKkd,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN,ContextMenu=wmECryhRDQjJgaxLqOIfuUciPGbKBS)
  if wmECryhRDQjJgaxLqOIfuUciPGbKYX not in[wmECryhRDQjJgaxLqOIfuUciPGbKst,'','-']:
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['mode'] ='BAND_VODLIST' 
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['bandKey'] =wmECryhRDQjJgaxLqOIfuUciPGbKYS
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['nextApiUrl']=wmECryhRDQjJgaxLqOIfuUciPGbKYX
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['page'] =wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKtT='[B]%s >>[/B]'%'다음 페이지'
   wmECryhRDQjJgaxLqOIfuUciPGbKBe=wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKto=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel=wmECryhRDQjJgaxLqOIfuUciPGbKBe,img=wmECryhRDQjJgaxLqOIfuUciPGbKto,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKst,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN)
  xbmcplugin.setContent(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,cacheToDisc=wmECryhRDQjJgaxLqOIfuUciPGbKsB)
 def dp_Gn2_Program(wmECryhRDQjJgaxLqOIfuUciPGbKdv,wmECryhRDQjJgaxLqOIfuUciPGbKkl):
  wmECryhRDQjJgaxLqOIfuUciPGbKBv =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('genre')
  wmECryhRDQjJgaxLqOIfuUciPGbKkT =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('stype')
  wmECryhRDQjJgaxLqOIfuUciPGbKtH =wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('orderby')
  wmECryhRDQjJgaxLqOIfuUciPGbKkz=wmECryhRDQjJgaxLqOIfuUciPGbKsk(wmECryhRDQjJgaxLqOIfuUciPGbKkl.get('page'))
  wmECryhRDQjJgaxLqOIfuUciPGbKBW,wmECryhRDQjJgaxLqOIfuUciPGbKkF=wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.Gn2_Program_List(wmECryhRDQjJgaxLqOIfuUciPGbKBv,wmECryhRDQjJgaxLqOIfuUciPGbKtH,wmECryhRDQjJgaxLqOIfuUciPGbKkz)
  for wmECryhRDQjJgaxLqOIfuUciPGbKYN in wmECryhRDQjJgaxLqOIfuUciPGbKBW:
   wmECryhRDQjJgaxLqOIfuUciPGbKtT =wmECryhRDQjJgaxLqOIfuUciPGbKYN.get('title')
   wmECryhRDQjJgaxLqOIfuUciPGbKko =wmECryhRDQjJgaxLqOIfuUciPGbKYN.get('thumbnail')
   wmECryhRDQjJgaxLqOIfuUciPGbKBs={'mediatype':wmECryhRDQjJgaxLqOIfuUciPGbKkT,'title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'plot':wmECryhRDQjJgaxLqOIfuUciPGbKtT,}
   if wmECryhRDQjJgaxLqOIfuUciPGbKkT=='movie':
    wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'MOVIE','mediacode':wmECryhRDQjJgaxLqOIfuUciPGbKYN.get('code'),'stype':wmECryhRDQjJgaxLqOIfuUciPGbKkT,'title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'thumbnail':wmECryhRDQjJgaxLqOIfuUciPGbKko,}
    wmECryhRDQjJgaxLqOIfuUciPGbKkd=wmECryhRDQjJgaxLqOIfuUciPGbKsB
   else:
    wmECryhRDQjJgaxLqOIfuUciPGbKtN={'mode':'EPISODE','programcode':wmECryhRDQjJgaxLqOIfuUciPGbKYN.get('code'),'stype':wmECryhRDQjJgaxLqOIfuUciPGbKkT,'title':wmECryhRDQjJgaxLqOIfuUciPGbKtT,'thumbnail':wmECryhRDQjJgaxLqOIfuUciPGbKko,'page':'1',}
    wmECryhRDQjJgaxLqOIfuUciPGbKkd=wmECryhRDQjJgaxLqOIfuUciPGbKsM
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel='',img=wmECryhRDQjJgaxLqOIfuUciPGbKko,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKBs,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKkd,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN,ContextMenu=wmECryhRDQjJgaxLqOIfuUciPGbKst)
  if wmECryhRDQjJgaxLqOIfuUciPGbKkF:
   wmECryhRDQjJgaxLqOIfuUciPGbKtN={}
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['mode'] ='GN2_LIST' 
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['orderby']=wmECryhRDQjJgaxLqOIfuUciPGbKtH
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['stype'] =wmECryhRDQjJgaxLqOIfuUciPGbKkT
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['genre'] =wmECryhRDQjJgaxLqOIfuUciPGbKBv
   wmECryhRDQjJgaxLqOIfuUciPGbKtN['page'] =wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKtT='[B]%s >>[/B]'%'다음 페이지'
   wmECryhRDQjJgaxLqOIfuUciPGbKBe=wmECryhRDQjJgaxLqOIfuUciPGbKsH(wmECryhRDQjJgaxLqOIfuUciPGbKkz+1)
   wmECryhRDQjJgaxLqOIfuUciPGbKto=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.add_dir(wmECryhRDQjJgaxLqOIfuUciPGbKtT,sublabel=wmECryhRDQjJgaxLqOIfuUciPGbKBe,img=wmECryhRDQjJgaxLqOIfuUciPGbKto,infoLabels=wmECryhRDQjJgaxLqOIfuUciPGbKst,isFolder=wmECryhRDQjJgaxLqOIfuUciPGbKsM,params=wmECryhRDQjJgaxLqOIfuUciPGbKtN)
  if wmECryhRDQjJgaxLqOIfuUciPGbKkT=='movie':
   xbmcplugin.setContent(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,'movies')
  else:
   xbmcplugin.setContent(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(wmECryhRDQjJgaxLqOIfuUciPGbKdv._addon_handle,cacheToDisc=wmECryhRDQjJgaxLqOIfuUciPGbKsB)
 def tving_main(wmECryhRDQjJgaxLqOIfuUciPGbKdv):
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.TvingObj.KodiVersion=wmECryhRDQjJgaxLqOIfuUciPGbKsk(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  wmECryhRDQjJgaxLqOIfuUciPGbKMz=wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params.get('mode',wmECryhRDQjJgaxLqOIfuUciPGbKst)
  if wmECryhRDQjJgaxLqOIfuUciPGbKMz=='LOGOUT':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.logout()
   return
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.login_main()
  wmECryhRDQjJgaxLqOIfuUciPGbKdv.get_reToken()
  if wmECryhRDQjJgaxLqOIfuUciPGbKMz is wmECryhRDQjJgaxLqOIfuUciPGbKst:
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Main_List()
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz in['LIVE_GROUP','DRAMA_GROUP','ENTER_GROUP','MOVIE_GROUP']:
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Title_Group(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz=='CHANNEL':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_LiveChannel_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz in['LIVE','VOD','MOVIE']:
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.play_VIDEO(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz=='PROGRAM':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Program_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz=='EPISODE':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Episode_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz=='SEARCH_GROUP':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Search_Group(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz in['SEARCH','LOCAL_SEARCH']:
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Search_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz=='WATCH':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Watch_List(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_History_Remove(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz=='ORDER_BY':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_setEpOrderby(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz=='SET_BOOKMARK':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Set_Bookmark(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz in['TOTAL_SEARCH','TOTAL_HISTORY']:
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Global_Search(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz=='SEARCH_HISTORY':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Search_History(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz=='MENU_BOOKMARK':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Bookmark_Menu(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz=='APPLE_GROUP':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Apple_Group(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz=='BAND_VODLIST':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Band_VodList(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  elif wmECryhRDQjJgaxLqOIfuUciPGbKMz=='GN2_LIST':
   wmECryhRDQjJgaxLqOIfuUciPGbKdv.dp_Gn2_Program(wmECryhRDQjJgaxLqOIfuUciPGbKdv.main_params)
  else:
   wmECryhRDQjJgaxLqOIfuUciPGbKst
# Created by pyminifier (https://github.com/liftoff/pyminifier)
