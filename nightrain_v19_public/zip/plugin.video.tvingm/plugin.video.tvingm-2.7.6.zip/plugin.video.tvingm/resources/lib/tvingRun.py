__author__="NightRain"
eOfgWoXNTdxsybtwImuakrYCvDjHpU=object
eOfgWoXNTdxsybtwImuakrYCvDjHpl=None
eOfgWoXNTdxsybtwImuakrYCvDjHpq=int
eOfgWoXNTdxsybtwImuakrYCvDjHpc=False
eOfgWoXNTdxsybtwImuakrYCvDjHpQ=True
eOfgWoXNTdxsybtwImuakrYCvDjHph=type
eOfgWoXNTdxsybtwImuakrYCvDjHpG=dict
eOfgWoXNTdxsybtwImuakrYCvDjHpM=getattr
eOfgWoXNTdxsybtwImuakrYCvDjHpi=list
eOfgWoXNTdxsybtwImuakrYCvDjHpE=len
eOfgWoXNTdxsybtwImuakrYCvDjHpR=str
eOfgWoXNTdxsybtwImuakrYCvDjHpB=range
eOfgWoXNTdxsybtwImuakrYCvDjHpA=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
eOfgWoXNTdxsybtwImuakrYCvDjHUq=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'실시간 인기 드라마','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'POP20_DRAMA_HOUR'},{'title':'실시간 인기 예능','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'POP20_UNSCRT_HOUR'},{'title':'Apple TV+ 실시간 인기','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'TVING_APPLE_HOUR'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'드라마 - 인기순','mode':'DRAMA_GROUP','stype':'drama','orderby':'hit','ordernm':'인기'},{'title':'드라마 - 업데이트','mode':'DRAMA_GROUP','stype':'drama','orderby':'update','ordernm':'업데이트'},{'title':'예능   - 인기순','mode':'ENTER_GROUP','stype':'enter','orderby':'hit','ordernm':'인기'},{'title':'예능   - 업데이트','mode':'ENTER_GROUP','stype':'enter','orderby':'update','ordernm':'업데이트'},{'title':'영화 - 인기순','mode':'MOVIE_GROUP','stype':'movie','orderby':'hit','ordernm':'인기'},{'title':'영화 - 업데이트','mode':'MOVIE_GROUP','stype':'movie','orderby':'update','ordernm':'업데이트'},{'title':'Apple TV+','mode':'APPLE_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'},]
eOfgWoXNTdxsybtwImuakrYCvDjHUc=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
eOfgWoXNTdxsybtwImuakrYCvDjHUQ=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
eOfgWoXNTdxsybtwImuakrYCvDjHUh=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
eOfgWoXNTdxsybtwImuakrYCvDjHUG=[{'title':'전체','mode':'GN2_LIST','genre':'PCA','stype':'tvshow'},{'title':'로맨스','mode':'GN2_LIST','genre':'PCA007','stype':'tvshow'},{'title':'코미디','mode':'GN2_LIST','genre':'PCA020','stype':'tvshow'},{'title':'판타지','mode':'GN2_LIST','genre':'PCA023','stype':'tvshow'},{'title':'무협','mode':'GN2_LIST','genre':'PCAB','stype':'tvshow'},{'title':'공포','mode':'GN2_LIST','genre':'PCAD','stype':'tvshow'},{'title':'복수','mode':'GN2_LIST','genre':'PCA030','stype':'tvshow'},{'title':'휴먼','mode':'GN2_LIST','genre':'PCA024','stype':'tvshow'},{'title':'범죄 스릴러','mode':'GN2_LIST','genre':'PCA015','stype':'tvshow'},{'title':'의학','mode':'GN2_LIST','genre':'PCA025','stype':'tvshow'},{'title':'웹튠/소설 원작','mode':'GN2_LIST','genre':'PCA028','stype':'tvshow'},{'title':'정치/권력','mode':'GN2_LIST','genre':'PCA034','stype':'tvshow'},{'title':'법정','mode':'GN2_LIST','genre':'PCA036','stype':'tvshow'},{'title':'청춘(성장)','mode':'GN2_LIST','genre':'PCA029','stype':'tvshow'},{'title':'오피스 드라마','mode':'GN2_LIST','genre':'PCA040','stype':'tvshow'},{'title':'사극/시대극','mode':'GN2_LIST','genre':'PCA017','stype':'tvshow'},{'title':'타임슬립','mode':'GN2_LIST','genre':'PCA026','stype':'tvshow'},{'title':'단막극','mode':'GN2_LIST','genre':'PCA038','stype':'tvshow'},{'title':'해외드라마','mode':'GN2_LIST','genre':'PCPOS','stype':'tvshow'},{'title':'미국드라마','mode':'GN2_LIST','genre':'POS007','stype':'tvshow'},{'title':'영국드라마','mode':'GN2_LIST','genre':'POS008','stype':'tvshow'},{'title':'중국드라마','mode':'GN2_LIST','genre':'POS005','stype':'tvshow'},{'title':'일본드라마','mode':'GN2_LIST','genre':'POS006','stype':'tvshow'}]
eOfgWoXNTdxsybtwImuakrYCvDjHUM=[{'title':'버라이어티','mode':'GN2_LIST','genre':'PCD005','stype':'tvshow'},{'title':'다큐멘터리','mode':'GN2_LIST','genre':'PCT','stype':'tvshow'},{'title':'여행','mode':'GN2_LIST','genre':'PCD003','stype':'tvshow'},{'title':'쿡방/먹방','mode':'GN2_LIST','genre':'PCD023','stype':'tvshow'},{'title':'연애 리얼리티','mode':'GN2_LIST','genre':'PCAB','stype':'PCD010'},{'title':'나영석 예능','mode':'GN2_LIST','genre':'PCD032','stype':'tvshow'},{'title':'게임/퀴즈쇼','mode':'GN2_LIST','genre':'PCD029','stype':'tvshow'},{'title':'토크쇼','mode':'GN2_LIST','genre':'PCD011','stype':'tvshow'},{'title':'서바이벌','mode':'GN2_LIST','genre':'PCD025','stype':'tvshow'},{'title':'관찰리얼리티','mode':'GN2_LIST','genre':'PCD024','stype':'tvshow'},{'title':'스포츠','mode':'GN2_LIST','genre':'PCD037','stype':'tvshow'},{'title':'교육&독서','mode':'GN2_LIST','genre':'PCD038','stype':'tvshow'},{'title':'힐링 예능','mode':'GN2_LIST','genre':'PCD034','stype':'tvshow'},{'title':'아이돌','mode':'GN2_LIST','genre':'PCD01','stype':'tvshow'},{'title':'음악 서바이벌','mode':'GN2_LIST','genre':'PCD027','stype':'tvshow'},{'title':'음악예능','mode':'GN2_LIST','genre':'PCD021','stype':'tvshow'},{'title':'코미디','mode':'GN2_LIST','genre':'PCD017','stype':'tvshow'},{'title':'가족예능','mode':'GN2_LIST','genre':'PCD035','stype':'tvshow'},{'title':'뷰티/스타일','mode':'GN2_LIST','genre':'PCD022','stype':'tvshow'},{'title':'펫/애니멀','mode':'GN2_LIST','genre':'PCD026','stype':'tvshow'},{'title':'콘서트/시상식','mode':'GN2_LIST','genre':'PCD009','stype':'tvshow'},{'title':'예능 스페셜','mode':'GN2_LIST','genre':'PCD042','stype':'tvshow'}]
eOfgWoXNTdxsybtwImuakrYCvDjHUp=[{'title':'드라마','mode':'GN2_LIST','genre':'MG100','stype':'movie'},{'title':'로맨스','mode':'GN2_LIST','genre':'MG130','stype':'movie'},{'title':'코미디','mode':'GN2_LIST','genre':'MG110','stype':'movie'},{'title':'애니메이션','mode':'GN2_LIST','genre':'MG240','stype':'movie'},{'title':'스릴러','mode':'GN2_LIST','genre':'MG140','stype':'movie'},{'title':'미스터리','mode':'GN2_LIST','genre':'MG150','stype':'movie'},{'title':'모험','mode':'GN2_LIST','genre':'MG170','stype':'movie'},{'title':'액션','mode':'GN2_LIST','genre':'MG120','stype':'movie'},{'title':'판타지','mode':'GN2_LIST','genre':'MG200','stype':'movie'},{'title':'SF','mode':'GN2_LIST','genre':'MG210','stype':'movie'},{'title':'공포','mode':'GN2_LIST','genre':'MG160','stype':'movie'},{'title':'다큐멘터리','mode':'GN2_LIST','genre':'MG250','stype':'movie'}]
eOfgWoXNTdxsybtwImuakrYCvDjHUi={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
class eOfgWoXNTdxsybtwImuakrYCvDjHUl(eOfgWoXNTdxsybtwImuakrYCvDjHpU):
 def __init__(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHUR,eOfgWoXNTdxsybtwImuakrYCvDjHUB,eOfgWoXNTdxsybtwImuakrYCvDjHUA):
  eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_url =eOfgWoXNTdxsybtwImuakrYCvDjHUR
  eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle=eOfgWoXNTdxsybtwImuakrYCvDjHUB
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params =eOfgWoXNTdxsybtwImuakrYCvDjHUA
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj =gPGIuQjvRYifchFsBpeHozSdyktUJL() 
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_COOKIE_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_TOKEN_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_token.json'))
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.SEARCHED_FILE_NAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
 def addon_noti(eOfgWoXNTdxsybtwImuakrYCvDjHUE,sting):
  try:
   eOfgWoXNTdxsybtwImuakrYCvDjHUJ=xbmcgui.Dialog()
   eOfgWoXNTdxsybtwImuakrYCvDjHUJ.notification(__addonname__,sting)
  except:
   eOfgWoXNTdxsybtwImuakrYCvDjHpl
 def addon_log(eOfgWoXNTdxsybtwImuakrYCvDjHUE,string):
  try:
   eOfgWoXNTdxsybtwImuakrYCvDjHUS=string.encode('utf-8','ignore')
  except:
   eOfgWoXNTdxsybtwImuakrYCvDjHUS='addonException: addon_log'
  eOfgWoXNTdxsybtwImuakrYCvDjHUV=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,eOfgWoXNTdxsybtwImuakrYCvDjHUS),level=eOfgWoXNTdxsybtwImuakrYCvDjHUV)
 def get_keyboard_input(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHlA):
  eOfgWoXNTdxsybtwImuakrYCvDjHUP=eOfgWoXNTdxsybtwImuakrYCvDjHpl
  kb=xbmc.Keyboard()
  kb.setHeading(eOfgWoXNTdxsybtwImuakrYCvDjHlA)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   eOfgWoXNTdxsybtwImuakrYCvDjHUP=kb.getText()
  return eOfgWoXNTdxsybtwImuakrYCvDjHUP
 def get_settings_account(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  eOfgWoXNTdxsybtwImuakrYCvDjHUz =__addon__.getSetting('id')
  eOfgWoXNTdxsybtwImuakrYCvDjHUn =__addon__.getSetting('pw')
  eOfgWoXNTdxsybtwImuakrYCvDjHUL =__addon__.getSetting('login_type')
  eOfgWoXNTdxsybtwImuakrYCvDjHUK=eOfgWoXNTdxsybtwImuakrYCvDjHpq(__addon__.getSetting('selected_profile'))
  return(eOfgWoXNTdxsybtwImuakrYCvDjHUz,eOfgWoXNTdxsybtwImuakrYCvDjHUn,eOfgWoXNTdxsybtwImuakrYCvDjHUL,eOfgWoXNTdxsybtwImuakrYCvDjHUK)
 def get_settings_uhd(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  return eOfgWoXNTdxsybtwImuakrYCvDjHpc
 def get_settings_playback(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  eOfgWoXNTdxsybtwImuakrYCvDjHlU={'active_uhd':eOfgWoXNTdxsybtwImuakrYCvDjHpQ if __addon__.getSetting('active_uhd')=='true' else eOfgWoXNTdxsybtwImuakrYCvDjHpc,'streamFilename':eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_STREAM_FILENAME,}
  return eOfgWoXNTdxsybtwImuakrYCvDjHlU
 def get_settings_proxyport(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  eOfgWoXNTdxsybtwImuakrYCvDjHlq =eOfgWoXNTdxsybtwImuakrYCvDjHpQ if __addon__.getSetting('proxyYn')=='true' else eOfgWoXNTdxsybtwImuakrYCvDjHpc
  eOfgWoXNTdxsybtwImuakrYCvDjHlc=eOfgWoXNTdxsybtwImuakrYCvDjHpq(__addon__.getSetting('proxyPort'))
  return eOfgWoXNTdxsybtwImuakrYCvDjHlq,eOfgWoXNTdxsybtwImuakrYCvDjHlc
 def get_settings_totalsearch(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  eOfgWoXNTdxsybtwImuakrYCvDjHlQ =eOfgWoXNTdxsybtwImuakrYCvDjHpQ if __addon__.getSetting('local_search')=='true' else eOfgWoXNTdxsybtwImuakrYCvDjHpc
  eOfgWoXNTdxsybtwImuakrYCvDjHlh=eOfgWoXNTdxsybtwImuakrYCvDjHpQ if __addon__.getSetting('local_history')=='true' else eOfgWoXNTdxsybtwImuakrYCvDjHpc
  eOfgWoXNTdxsybtwImuakrYCvDjHlG =eOfgWoXNTdxsybtwImuakrYCvDjHpQ if __addon__.getSetting('total_search')=='true' else eOfgWoXNTdxsybtwImuakrYCvDjHpc
  eOfgWoXNTdxsybtwImuakrYCvDjHlM=eOfgWoXNTdxsybtwImuakrYCvDjHpQ if __addon__.getSetting('total_history')=='true' else eOfgWoXNTdxsybtwImuakrYCvDjHpc
  eOfgWoXNTdxsybtwImuakrYCvDjHlp=eOfgWoXNTdxsybtwImuakrYCvDjHpQ if __addon__.getSetting('menu_bookmark')=='true' else eOfgWoXNTdxsybtwImuakrYCvDjHpc
  return(eOfgWoXNTdxsybtwImuakrYCvDjHlQ,eOfgWoXNTdxsybtwImuakrYCvDjHlh,eOfgWoXNTdxsybtwImuakrYCvDjHlG,eOfgWoXNTdxsybtwImuakrYCvDjHlM,eOfgWoXNTdxsybtwImuakrYCvDjHlp)
 def get_settings_makebookmark(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  return eOfgWoXNTdxsybtwImuakrYCvDjHpQ if __addon__.getSetting('make_bookmark')=='true' else eOfgWoXNTdxsybtwImuakrYCvDjHpc
 def get_settings_direct_replay(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  eOfgWoXNTdxsybtwImuakrYCvDjHli=eOfgWoXNTdxsybtwImuakrYCvDjHpq(__addon__.getSetting('direct_replay'))
  if eOfgWoXNTdxsybtwImuakrYCvDjHli==0:
   return eOfgWoXNTdxsybtwImuakrYCvDjHpc
  else:
   return eOfgWoXNTdxsybtwImuakrYCvDjHpQ
 def set_winEpisodeOrderby(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHlR):
  __addon__.setSetting('tving_orderby',eOfgWoXNTdxsybtwImuakrYCvDjHlR)
  eOfgWoXNTdxsybtwImuakrYCvDjHlE=xbmcgui.Window(10000)
  eOfgWoXNTdxsybtwImuakrYCvDjHlE.setProperty('TVING_M_ORDERBY',eOfgWoXNTdxsybtwImuakrYCvDjHlR)
 def get_winEpisodeOrderby(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  eOfgWoXNTdxsybtwImuakrYCvDjHlR=__addon__.getSetting('tving_orderby')
  if eOfgWoXNTdxsybtwImuakrYCvDjHlR in['',eOfgWoXNTdxsybtwImuakrYCvDjHpl]:eOfgWoXNTdxsybtwImuakrYCvDjHlR='desc'
  return eOfgWoXNTdxsybtwImuakrYCvDjHlR
 def add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHUE,label,sublabel='',img='',infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHpl,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params='',isLink=eOfgWoXNTdxsybtwImuakrYCvDjHpc,ContextMenu=eOfgWoXNTdxsybtwImuakrYCvDjHpl):
  eOfgWoXNTdxsybtwImuakrYCvDjHlB='%s?%s'%(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_url,urllib.parse.urlencode(params))
  if sublabel:eOfgWoXNTdxsybtwImuakrYCvDjHlA='%s < %s >'%(label,sublabel)
  else: eOfgWoXNTdxsybtwImuakrYCvDjHlA=label
  if not img:img='DefaultFolder.png'
  eOfgWoXNTdxsybtwImuakrYCvDjHlF=xbmcgui.ListItem(eOfgWoXNTdxsybtwImuakrYCvDjHlA)
  if eOfgWoXNTdxsybtwImuakrYCvDjHph(img)==eOfgWoXNTdxsybtwImuakrYCvDjHpG:
   eOfgWoXNTdxsybtwImuakrYCvDjHlF.setArt(img)
  else:
   eOfgWoXNTdxsybtwImuakrYCvDjHlF.setArt({'thumb':img,'poster':img})
  if eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.KodiVersion>=20:
   if infoLabels:eOfgWoXNTdxsybtwImuakrYCvDjHUE.Set_InfoTag(eOfgWoXNTdxsybtwImuakrYCvDjHlF.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:eOfgWoXNTdxsybtwImuakrYCvDjHlF.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   eOfgWoXNTdxsybtwImuakrYCvDjHlF.setProperty('IsPlayable','true')
  if ContextMenu:eOfgWoXNTdxsybtwImuakrYCvDjHlF.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,eOfgWoXNTdxsybtwImuakrYCvDjHlB,eOfgWoXNTdxsybtwImuakrYCvDjHlF,isFolder)
 def get_selQuality(eOfgWoXNTdxsybtwImuakrYCvDjHUE,etype):
  try:
   eOfgWoXNTdxsybtwImuakrYCvDjHlJ='selected_quality'
   eOfgWoXNTdxsybtwImuakrYCvDjHlS=[1080,720,480,360]
   eOfgWoXNTdxsybtwImuakrYCvDjHlV=eOfgWoXNTdxsybtwImuakrYCvDjHpq(__addon__.getSetting(eOfgWoXNTdxsybtwImuakrYCvDjHlJ))
   return eOfgWoXNTdxsybtwImuakrYCvDjHlS[eOfgWoXNTdxsybtwImuakrYCvDjHlV]
  except:
   eOfgWoXNTdxsybtwImuakrYCvDjHpl
  return 720 
 def Set_InfoTag(eOfgWoXNTdxsybtwImuakrYCvDjHUE,video_InfoTag:xbmc.InfoTagVideo,eOfgWoXNTdxsybtwImuakrYCvDjHqc):
  for eOfgWoXNTdxsybtwImuakrYCvDjHlP,value in eOfgWoXNTdxsybtwImuakrYCvDjHqc.items():
   if eOfgWoXNTdxsybtwImuakrYCvDjHUi[eOfgWoXNTdxsybtwImuakrYCvDjHlP]['type']=='string':
    eOfgWoXNTdxsybtwImuakrYCvDjHpM(video_InfoTag,eOfgWoXNTdxsybtwImuakrYCvDjHUi[eOfgWoXNTdxsybtwImuakrYCvDjHlP]['func'])(value)
   elif eOfgWoXNTdxsybtwImuakrYCvDjHUi[eOfgWoXNTdxsybtwImuakrYCvDjHlP]['type']=='int':
    if eOfgWoXNTdxsybtwImuakrYCvDjHph(value)==eOfgWoXNTdxsybtwImuakrYCvDjHpq:
     eOfgWoXNTdxsybtwImuakrYCvDjHlz=eOfgWoXNTdxsybtwImuakrYCvDjHpq(value)
    else:
     eOfgWoXNTdxsybtwImuakrYCvDjHlz=0
    eOfgWoXNTdxsybtwImuakrYCvDjHpM(video_InfoTag,eOfgWoXNTdxsybtwImuakrYCvDjHUi[eOfgWoXNTdxsybtwImuakrYCvDjHlP]['func'])(eOfgWoXNTdxsybtwImuakrYCvDjHlz)
   elif eOfgWoXNTdxsybtwImuakrYCvDjHUi[eOfgWoXNTdxsybtwImuakrYCvDjHlP]['type']=='actor':
    if value!=[]:
     eOfgWoXNTdxsybtwImuakrYCvDjHpM(video_InfoTag,eOfgWoXNTdxsybtwImuakrYCvDjHUi[eOfgWoXNTdxsybtwImuakrYCvDjHlP]['func'])([xbmc.Actor(name)for name in value])
   elif eOfgWoXNTdxsybtwImuakrYCvDjHUi[eOfgWoXNTdxsybtwImuakrYCvDjHlP]['type']=='list':
    if eOfgWoXNTdxsybtwImuakrYCvDjHph(value)==eOfgWoXNTdxsybtwImuakrYCvDjHpi:
     eOfgWoXNTdxsybtwImuakrYCvDjHpM(video_InfoTag,eOfgWoXNTdxsybtwImuakrYCvDjHUi[eOfgWoXNTdxsybtwImuakrYCvDjHlP]['func'])(value)
    else:
     eOfgWoXNTdxsybtwImuakrYCvDjHpM(video_InfoTag,eOfgWoXNTdxsybtwImuakrYCvDjHUi[eOfgWoXNTdxsybtwImuakrYCvDjHlP]['func'])([value])
 def dp_Main_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  (eOfgWoXNTdxsybtwImuakrYCvDjHlQ,eOfgWoXNTdxsybtwImuakrYCvDjHlh,eOfgWoXNTdxsybtwImuakrYCvDjHlG,eOfgWoXNTdxsybtwImuakrYCvDjHlM,eOfgWoXNTdxsybtwImuakrYCvDjHlp)=eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_settings_totalsearch()
  for eOfgWoXNTdxsybtwImuakrYCvDjHln in eOfgWoXNTdxsybtwImuakrYCvDjHUq:
   eOfgWoXNTdxsybtwImuakrYCvDjHlA=eOfgWoXNTdxsybtwImuakrYCvDjHln.get('title')
   eOfgWoXNTdxsybtwImuakrYCvDjHlL=''
   if eOfgWoXNTdxsybtwImuakrYCvDjHln.get('mode')=='SEARCH_GROUP' and eOfgWoXNTdxsybtwImuakrYCvDjHlQ ==eOfgWoXNTdxsybtwImuakrYCvDjHpc:continue
   elif eOfgWoXNTdxsybtwImuakrYCvDjHln.get('mode')=='SEARCH_HISTORY' and eOfgWoXNTdxsybtwImuakrYCvDjHlh==eOfgWoXNTdxsybtwImuakrYCvDjHpc:continue
   elif eOfgWoXNTdxsybtwImuakrYCvDjHln.get('mode')=='TOTAL_SEARCH' and eOfgWoXNTdxsybtwImuakrYCvDjHlG ==eOfgWoXNTdxsybtwImuakrYCvDjHpc:continue
   elif eOfgWoXNTdxsybtwImuakrYCvDjHln.get('mode')=='TOTAL_HISTORY' and eOfgWoXNTdxsybtwImuakrYCvDjHlM==eOfgWoXNTdxsybtwImuakrYCvDjHpc:continue
   elif eOfgWoXNTdxsybtwImuakrYCvDjHln.get('mode')=='MENU_BOOKMARK' and eOfgWoXNTdxsybtwImuakrYCvDjHlp==eOfgWoXNTdxsybtwImuakrYCvDjHpc:continue
   eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':eOfgWoXNTdxsybtwImuakrYCvDjHln.get('mode'),'stype':eOfgWoXNTdxsybtwImuakrYCvDjHln.get('stype'),'orderby':eOfgWoXNTdxsybtwImuakrYCvDjHln.get('orderby'),'ordernm':eOfgWoXNTdxsybtwImuakrYCvDjHln.get('ordernm'),'page':'1','bandKey':eOfgWoXNTdxsybtwImuakrYCvDjHln.get('bandKey'),'bandGroup':eOfgWoXNTdxsybtwImuakrYCvDjHln.get('bandGroup'),'nextApiUrl':'-',}
   if eOfgWoXNTdxsybtwImuakrYCvDjHln.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    eOfgWoXNTdxsybtwImuakrYCvDjHqU=eOfgWoXNTdxsybtwImuakrYCvDjHpc
    eOfgWoXNTdxsybtwImuakrYCvDjHql =eOfgWoXNTdxsybtwImuakrYCvDjHpQ
   else:
    eOfgWoXNTdxsybtwImuakrYCvDjHqU=eOfgWoXNTdxsybtwImuakrYCvDjHpQ
    eOfgWoXNTdxsybtwImuakrYCvDjHql =eOfgWoXNTdxsybtwImuakrYCvDjHpc
   eOfgWoXNTdxsybtwImuakrYCvDjHqc={'title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'plot':eOfgWoXNTdxsybtwImuakrYCvDjHlA}
   if eOfgWoXNTdxsybtwImuakrYCvDjHln.get('mode')=='XXX':eOfgWoXNTdxsybtwImuakrYCvDjHqc=eOfgWoXNTdxsybtwImuakrYCvDjHpl
   if 'icon' in eOfgWoXNTdxsybtwImuakrYCvDjHln:eOfgWoXNTdxsybtwImuakrYCvDjHlL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',eOfgWoXNTdxsybtwImuakrYCvDjHln.get('icon')) 
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel='',img=eOfgWoXNTdxsybtwImuakrYCvDjHlL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHqc,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHqU,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK,isLink=eOfgWoXNTdxsybtwImuakrYCvDjHql)
  xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle)
 def login_main(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  (eOfgWoXNTdxsybtwImuakrYCvDjHqh,eOfgWoXNTdxsybtwImuakrYCvDjHqG,eOfgWoXNTdxsybtwImuakrYCvDjHqM,eOfgWoXNTdxsybtwImuakrYCvDjHqp)=eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_settings_account()
  if not(eOfgWoXNTdxsybtwImuakrYCvDjHqh and eOfgWoXNTdxsybtwImuakrYCvDjHqG):
   eOfgWoXNTdxsybtwImuakrYCvDjHUJ=xbmcgui.Dialog()
   eOfgWoXNTdxsybtwImuakrYCvDjHqi=eOfgWoXNTdxsybtwImuakrYCvDjHUJ.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if eOfgWoXNTdxsybtwImuakrYCvDjHqi==eOfgWoXNTdxsybtwImuakrYCvDjHpQ:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if eOfgWoXNTdxsybtwImuakrYCvDjHUE.cookiefile_check():return
  if base64.standard_b64encode(eOfgWoXNTdxsybtwImuakrYCvDjHqh.encode()).decode('utf-8')in['a3ltOTUxMDg4','a3ltMTA4OA==']:
   eOfgWoXNTdxsybtwImuakrYCvDjHqE=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.GetCredential2(eOfgWoXNTdxsybtwImuakrYCvDjHqh,eOfgWoXNTdxsybtwImuakrYCvDjHqG,eOfgWoXNTdxsybtwImuakrYCvDjHqM,eOfgWoXNTdxsybtwImuakrYCvDjHqp)
  else:
   eOfgWoXNTdxsybtwImuakrYCvDjHUJ=xbmcgui.Dialog()
   eOfgWoXNTdxsybtwImuakrYCvDjHqR=eOfgWoXNTdxsybtwImuakrYCvDjHUJ.browse(1,__language__(30917).encode('utf8'),'','.twc',eOfgWoXNTdxsybtwImuakrYCvDjHpc,eOfgWoXNTdxsybtwImuakrYCvDjHpc,'',eOfgWoXNTdxsybtwImuakrYCvDjHpc)
   if eOfgWoXNTdxsybtwImuakrYCvDjHqR!='':
    eOfgWoXNTdxsybtwImuakrYCvDjHqB=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'))
    xbmcvfs.copy(eOfgWoXNTdxsybtwImuakrYCvDjHqR,eOfgWoXNTdxsybtwImuakrYCvDjHqB)
    eOfgWoXNTdxsybtwImuakrYCvDjHqE=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.WebCookies_Load(eOfgWoXNTdxsybtwImuakrYCvDjHqB)
    xbmcvfs.delete(eOfgWoXNTdxsybtwImuakrYCvDjHqB)
    if eOfgWoXNTdxsybtwImuakrYCvDjHqE:
     eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.JsonFile_Save(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_COOKIE_FILENAME,eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV)
     eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    eOfgWoXNTdxsybtwImuakrYCvDjHqE=eOfgWoXNTdxsybtwImuakrYCvDjHpc
  if eOfgWoXNTdxsybtwImuakrYCvDjHqE==eOfgWoXNTdxsybtwImuakrYCvDjHpQ:
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.cookiefile_save()
  else:
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHqA=eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('stype')
  if eOfgWoXNTdxsybtwImuakrYCvDjHqA=='live':
   eOfgWoXNTdxsybtwImuakrYCvDjHqF=eOfgWoXNTdxsybtwImuakrYCvDjHUc
  elif eOfgWoXNTdxsybtwImuakrYCvDjHqA=='drama':
   eOfgWoXNTdxsybtwImuakrYCvDjHqF=eOfgWoXNTdxsybtwImuakrYCvDjHUG
  elif eOfgWoXNTdxsybtwImuakrYCvDjHqA=='enter':
   eOfgWoXNTdxsybtwImuakrYCvDjHqF=eOfgWoXNTdxsybtwImuakrYCvDjHUM
  else:
   eOfgWoXNTdxsybtwImuakrYCvDjHqF=eOfgWoXNTdxsybtwImuakrYCvDjHUp
  for eOfgWoXNTdxsybtwImuakrYCvDjHqJ in eOfgWoXNTdxsybtwImuakrYCvDjHqF:
   eOfgWoXNTdxsybtwImuakrYCvDjHlA=eOfgWoXNTdxsybtwImuakrYCvDjHqJ.get('title')
   if eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('ordernm')!='-':
    eOfgWoXNTdxsybtwImuakrYCvDjHlA+='  ('+eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('ordernm')+')'
   eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':eOfgWoXNTdxsybtwImuakrYCvDjHqJ.get('mode'),'stype':eOfgWoXNTdxsybtwImuakrYCvDjHqJ.get('stype'),'genre':eOfgWoXNTdxsybtwImuakrYCvDjHqJ.get('genre'),'orderby':eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('orderby'),'ordernm':eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('ordernm'),'page':'1',}
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel='',img='',infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHpl,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK)
  if eOfgWoXNTdxsybtwImuakrYCvDjHpE(eOfgWoXNTdxsybtwImuakrYCvDjHqF)>0:xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle)
 def dp_LiveChannel_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHqA =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('stype')
  eOfgWoXNTdxsybtwImuakrYCvDjHqV =eOfgWoXNTdxsybtwImuakrYCvDjHpq(eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('page'))
  eOfgWoXNTdxsybtwImuakrYCvDjHqP,eOfgWoXNTdxsybtwImuakrYCvDjHqz=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.GetLiveChannelList(eOfgWoXNTdxsybtwImuakrYCvDjHqA,eOfgWoXNTdxsybtwImuakrYCvDjHqV)
  for eOfgWoXNTdxsybtwImuakrYCvDjHqn in eOfgWoXNTdxsybtwImuakrYCvDjHqP:
   eOfgWoXNTdxsybtwImuakrYCvDjHlA =eOfgWoXNTdxsybtwImuakrYCvDjHqn.get('title')
   eOfgWoXNTdxsybtwImuakrYCvDjHqQ =eOfgWoXNTdxsybtwImuakrYCvDjHqn.get('channel')
   eOfgWoXNTdxsybtwImuakrYCvDjHqL =eOfgWoXNTdxsybtwImuakrYCvDjHqn.get('thumbnail')
   eOfgWoXNTdxsybtwImuakrYCvDjHqK =eOfgWoXNTdxsybtwImuakrYCvDjHqn.get('synopsis')
   eOfgWoXNTdxsybtwImuakrYCvDjHcU =eOfgWoXNTdxsybtwImuakrYCvDjHqn.get('channelepg')
   eOfgWoXNTdxsybtwImuakrYCvDjHcl =eOfgWoXNTdxsybtwImuakrYCvDjHqn.get('cast')
   eOfgWoXNTdxsybtwImuakrYCvDjHcq =eOfgWoXNTdxsybtwImuakrYCvDjHqn.get('director')
   eOfgWoXNTdxsybtwImuakrYCvDjHcQ =eOfgWoXNTdxsybtwImuakrYCvDjHqn.get('info_genre')
   eOfgWoXNTdxsybtwImuakrYCvDjHch =eOfgWoXNTdxsybtwImuakrYCvDjHqn.get('year')
   eOfgWoXNTdxsybtwImuakrYCvDjHcG =eOfgWoXNTdxsybtwImuakrYCvDjHqn.get('mpaa')
   eOfgWoXNTdxsybtwImuakrYCvDjHcM =eOfgWoXNTdxsybtwImuakrYCvDjHqn.get('premiered')
   eOfgWoXNTdxsybtwImuakrYCvDjHcp={'mediatype':'episode','title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'studio':eOfgWoXNTdxsybtwImuakrYCvDjHqQ,'cast':eOfgWoXNTdxsybtwImuakrYCvDjHcl,'director':eOfgWoXNTdxsybtwImuakrYCvDjHcq,'genre':eOfgWoXNTdxsybtwImuakrYCvDjHcQ,'plot':'%s\n%s\n%s\n\n%s'%(eOfgWoXNTdxsybtwImuakrYCvDjHqQ,eOfgWoXNTdxsybtwImuakrYCvDjHlA,eOfgWoXNTdxsybtwImuakrYCvDjHcU,eOfgWoXNTdxsybtwImuakrYCvDjHqK),'year':eOfgWoXNTdxsybtwImuakrYCvDjHch,'mpaa':eOfgWoXNTdxsybtwImuakrYCvDjHcG,'premiered':eOfgWoXNTdxsybtwImuakrYCvDjHcM}
   eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'LIVE','mediacode':eOfgWoXNTdxsybtwImuakrYCvDjHqn.get('mediacode'),'stype':eOfgWoXNTdxsybtwImuakrYCvDjHqA}
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHqQ,sublabel=eOfgWoXNTdxsybtwImuakrYCvDjHlA,img=eOfgWoXNTdxsybtwImuakrYCvDjHqL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHcp,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpc,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK)
  if eOfgWoXNTdxsybtwImuakrYCvDjHqz:
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['mode']='CHANNEL' 
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['stype']=eOfgWoXNTdxsybtwImuakrYCvDjHqA 
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['page']=eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlA='[B]%s >>[/B]'%'다음 페이지'
   eOfgWoXNTdxsybtwImuakrYCvDjHci=eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel=eOfgWoXNTdxsybtwImuakrYCvDjHci,img=eOfgWoXNTdxsybtwImuakrYCvDjHlL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHpl,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK)
  if eOfgWoXNTdxsybtwImuakrYCvDjHpE(eOfgWoXNTdxsybtwImuakrYCvDjHqP)>0:xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,cacheToDisc=eOfgWoXNTdxsybtwImuakrYCvDjHpc)
 def dp_Program_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHcE =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('stype')
  eOfgWoXNTdxsybtwImuakrYCvDjHlR =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('orderby')
  eOfgWoXNTdxsybtwImuakrYCvDjHqV =eOfgWoXNTdxsybtwImuakrYCvDjHpq(eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('page'))
  eOfgWoXNTdxsybtwImuakrYCvDjHcR=eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('genreCode')
  if eOfgWoXNTdxsybtwImuakrYCvDjHcR==eOfgWoXNTdxsybtwImuakrYCvDjHpl:eOfgWoXNTdxsybtwImuakrYCvDjHcR='all'
  eOfgWoXNTdxsybtwImuakrYCvDjHcB,eOfgWoXNTdxsybtwImuakrYCvDjHqz=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.GetProgramList(eOfgWoXNTdxsybtwImuakrYCvDjHcE,eOfgWoXNTdxsybtwImuakrYCvDjHlR,eOfgWoXNTdxsybtwImuakrYCvDjHqV,eOfgWoXNTdxsybtwImuakrYCvDjHcR)
  for eOfgWoXNTdxsybtwImuakrYCvDjHcA in eOfgWoXNTdxsybtwImuakrYCvDjHcB:
   eOfgWoXNTdxsybtwImuakrYCvDjHlA =eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('title')
   eOfgWoXNTdxsybtwImuakrYCvDjHqL =eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('thumbnail')
   eOfgWoXNTdxsybtwImuakrYCvDjHqK =eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('synopsis')
   eOfgWoXNTdxsybtwImuakrYCvDjHcF =eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('channel')
   eOfgWoXNTdxsybtwImuakrYCvDjHcl =eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('cast')
   eOfgWoXNTdxsybtwImuakrYCvDjHcq =eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('director')
   eOfgWoXNTdxsybtwImuakrYCvDjHcQ=eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('info_genre')
   eOfgWoXNTdxsybtwImuakrYCvDjHch =eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('year')
   eOfgWoXNTdxsybtwImuakrYCvDjHcM =eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('premiered')
   eOfgWoXNTdxsybtwImuakrYCvDjHcG =eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('mpaa')
   eOfgWoXNTdxsybtwImuakrYCvDjHcp={'mediatype':'tvshow','title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'studio':eOfgWoXNTdxsybtwImuakrYCvDjHcF,'cast':eOfgWoXNTdxsybtwImuakrYCvDjHcl,'director':eOfgWoXNTdxsybtwImuakrYCvDjHcq,'genre':eOfgWoXNTdxsybtwImuakrYCvDjHcQ,'year':eOfgWoXNTdxsybtwImuakrYCvDjHch,'premiered':eOfgWoXNTdxsybtwImuakrYCvDjHcM,'mpaa':eOfgWoXNTdxsybtwImuakrYCvDjHcG,'plot':eOfgWoXNTdxsybtwImuakrYCvDjHqK}
   eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'EPISODE','programcode':eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('program'),'page':'1'}
   if eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_settings_makebookmark():
    eOfgWoXNTdxsybtwImuakrYCvDjHcJ={'videoid':eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('program'),'vidtype':'tvshow','vtitle':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'vsubtitle':eOfgWoXNTdxsybtwImuakrYCvDjHcF,}
    eOfgWoXNTdxsybtwImuakrYCvDjHcS=json.dumps(eOfgWoXNTdxsybtwImuakrYCvDjHcJ)
    eOfgWoXNTdxsybtwImuakrYCvDjHcS=urllib.parse.quote(eOfgWoXNTdxsybtwImuakrYCvDjHcS)
    eOfgWoXNTdxsybtwImuakrYCvDjHcV='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(eOfgWoXNTdxsybtwImuakrYCvDjHcS)
    eOfgWoXNTdxsybtwImuakrYCvDjHcP=[('(통합) 찜 영상에 추가',eOfgWoXNTdxsybtwImuakrYCvDjHcV)]
   else:
    eOfgWoXNTdxsybtwImuakrYCvDjHcP=eOfgWoXNTdxsybtwImuakrYCvDjHpl
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel=eOfgWoXNTdxsybtwImuakrYCvDjHcF,img=eOfgWoXNTdxsybtwImuakrYCvDjHqL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHcp,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK,ContextMenu=eOfgWoXNTdxsybtwImuakrYCvDjHcP)
  if eOfgWoXNTdxsybtwImuakrYCvDjHqz:
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['mode'] ='PROGRAM' 
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['stype'] =eOfgWoXNTdxsybtwImuakrYCvDjHcE
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['orderby'] =eOfgWoXNTdxsybtwImuakrYCvDjHlR
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['page'] =eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['genreCode']=eOfgWoXNTdxsybtwImuakrYCvDjHcR 
   eOfgWoXNTdxsybtwImuakrYCvDjHlA='[B]%s >>[/B]'%'다음 페이지'
   eOfgWoXNTdxsybtwImuakrYCvDjHci=eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel=eOfgWoXNTdxsybtwImuakrYCvDjHci,img=eOfgWoXNTdxsybtwImuakrYCvDjHlL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHpl,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK)
  xbmcplugin.setContent(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,cacheToDisc=eOfgWoXNTdxsybtwImuakrYCvDjHpc)
 def dp_Episode_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHcn=eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('programcode')
  eOfgWoXNTdxsybtwImuakrYCvDjHqV =eOfgWoXNTdxsybtwImuakrYCvDjHpq(eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('page'))
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_log('programcode : {}'.format(eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('programcode')))
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_log('page        : {}'.format(eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('page')))
  eOfgWoXNTdxsybtwImuakrYCvDjHcL,eOfgWoXNTdxsybtwImuakrYCvDjHqz,eOfgWoXNTdxsybtwImuakrYCvDjHcK=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.GetEpisodeList(eOfgWoXNTdxsybtwImuakrYCvDjHcn,eOfgWoXNTdxsybtwImuakrYCvDjHqV,orderby=eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_winEpisodeOrderby())
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_log('count       : {}'.format(eOfgWoXNTdxsybtwImuakrYCvDjHpE(eOfgWoXNTdxsybtwImuakrYCvDjHcL)))
  for eOfgWoXNTdxsybtwImuakrYCvDjHQU in eOfgWoXNTdxsybtwImuakrYCvDjHcL:
   eOfgWoXNTdxsybtwImuakrYCvDjHlA =eOfgWoXNTdxsybtwImuakrYCvDjHQU.get('title')
   eOfgWoXNTdxsybtwImuakrYCvDjHci =eOfgWoXNTdxsybtwImuakrYCvDjHQU.get('subtitle')
   eOfgWoXNTdxsybtwImuakrYCvDjHqL =eOfgWoXNTdxsybtwImuakrYCvDjHQU.get('thumbnail')
   eOfgWoXNTdxsybtwImuakrYCvDjHqK =eOfgWoXNTdxsybtwImuakrYCvDjHQU.get('synopsis')
   eOfgWoXNTdxsybtwImuakrYCvDjHQl=eOfgWoXNTdxsybtwImuakrYCvDjHQU.get('info_title')
   eOfgWoXNTdxsybtwImuakrYCvDjHQq =eOfgWoXNTdxsybtwImuakrYCvDjHQU.get('aired')
   eOfgWoXNTdxsybtwImuakrYCvDjHQc =eOfgWoXNTdxsybtwImuakrYCvDjHQU.get('studio')
   eOfgWoXNTdxsybtwImuakrYCvDjHQh =eOfgWoXNTdxsybtwImuakrYCvDjHQU.get('frequency')
   eOfgWoXNTdxsybtwImuakrYCvDjHcp={'mediatype':'episode','title':eOfgWoXNTdxsybtwImuakrYCvDjHQl,'aired':eOfgWoXNTdxsybtwImuakrYCvDjHQq,'studio':eOfgWoXNTdxsybtwImuakrYCvDjHQc,'episode':eOfgWoXNTdxsybtwImuakrYCvDjHQh,'plot':eOfgWoXNTdxsybtwImuakrYCvDjHqK}
   eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'VOD','mediacode':eOfgWoXNTdxsybtwImuakrYCvDjHQU.get('episode'),'stype':'vod','programcode':eOfgWoXNTdxsybtwImuakrYCvDjHcn,'title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'thumbnail':eOfgWoXNTdxsybtwImuakrYCvDjHqL}
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel=eOfgWoXNTdxsybtwImuakrYCvDjHci,img=eOfgWoXNTdxsybtwImuakrYCvDjHqL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHcp,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpc,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK)
  if eOfgWoXNTdxsybtwImuakrYCvDjHqV==1:
   eOfgWoXNTdxsybtwImuakrYCvDjHcp={'plot':'정렬순서를 변경합니다.'}
   eOfgWoXNTdxsybtwImuakrYCvDjHlK={}
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['mode'] ='ORDER_BY' 
   if eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_winEpisodeOrderby()=='desc':
    eOfgWoXNTdxsybtwImuakrYCvDjHlA='정렬순서변경 : 최신화부터 -> 1회부터'
    eOfgWoXNTdxsybtwImuakrYCvDjHlK['orderby']='asc'
   else:
    eOfgWoXNTdxsybtwImuakrYCvDjHlA='정렬순서변경 : 1회부터 -> 최신화부터'
    eOfgWoXNTdxsybtwImuakrYCvDjHlK['orderby']='desc'
   eOfgWoXNTdxsybtwImuakrYCvDjHlL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel='',img=eOfgWoXNTdxsybtwImuakrYCvDjHlL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHcp,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpc,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK,isLink=eOfgWoXNTdxsybtwImuakrYCvDjHpQ)
  if eOfgWoXNTdxsybtwImuakrYCvDjHqz:
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['mode'] ='EPISODE' 
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['programcode']=eOfgWoXNTdxsybtwImuakrYCvDjHcn
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['page'] =eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlA='[B]%s >>[/B]'%'다음 페이지'
   eOfgWoXNTdxsybtwImuakrYCvDjHci=eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel=eOfgWoXNTdxsybtwImuakrYCvDjHci,img=eOfgWoXNTdxsybtwImuakrYCvDjHlL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHpl,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK)
  xbmcplugin.setContent(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,'episodes')
  if eOfgWoXNTdxsybtwImuakrYCvDjHpE(eOfgWoXNTdxsybtwImuakrYCvDjHcL)>0:xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,cacheToDisc=eOfgWoXNTdxsybtwImuakrYCvDjHpc)
 def dp_setEpOrderby(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHlR =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('orderby')
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.set_winEpisodeOrderby(eOfgWoXNTdxsybtwImuakrYCvDjHlR)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHcE =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('stype')
  eOfgWoXNTdxsybtwImuakrYCvDjHlR =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('orderby')
  eOfgWoXNTdxsybtwImuakrYCvDjHqV=eOfgWoXNTdxsybtwImuakrYCvDjHpq(eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('page'))
  eOfgWoXNTdxsybtwImuakrYCvDjHQG,eOfgWoXNTdxsybtwImuakrYCvDjHqz=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.GetMovieList(eOfgWoXNTdxsybtwImuakrYCvDjHcE,eOfgWoXNTdxsybtwImuakrYCvDjHlR,eOfgWoXNTdxsybtwImuakrYCvDjHqV)
  for eOfgWoXNTdxsybtwImuakrYCvDjHQM in eOfgWoXNTdxsybtwImuakrYCvDjHQG:
   eOfgWoXNTdxsybtwImuakrYCvDjHlA =eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('title')
   eOfgWoXNTdxsybtwImuakrYCvDjHqL =eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('thumbnail')
   eOfgWoXNTdxsybtwImuakrYCvDjHqK =eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('synopsis')
   eOfgWoXNTdxsybtwImuakrYCvDjHQl =eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('info_title')
   eOfgWoXNTdxsybtwImuakrYCvDjHch =eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('year')
   eOfgWoXNTdxsybtwImuakrYCvDjHcl =eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('cast')
   eOfgWoXNTdxsybtwImuakrYCvDjHcq =eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('director')
   eOfgWoXNTdxsybtwImuakrYCvDjHcQ =eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('info_genre')
   eOfgWoXNTdxsybtwImuakrYCvDjHQp =eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('duration')
   eOfgWoXNTdxsybtwImuakrYCvDjHcM =eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('premiered')
   eOfgWoXNTdxsybtwImuakrYCvDjHQc =eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('studio')
   eOfgWoXNTdxsybtwImuakrYCvDjHcG =eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('mpaa')
   eOfgWoXNTdxsybtwImuakrYCvDjHcp={'mediatype':'movie','title':eOfgWoXNTdxsybtwImuakrYCvDjHQl,'year':eOfgWoXNTdxsybtwImuakrYCvDjHch,'cast':eOfgWoXNTdxsybtwImuakrYCvDjHcl,'director':eOfgWoXNTdxsybtwImuakrYCvDjHcq,'genre':eOfgWoXNTdxsybtwImuakrYCvDjHcQ,'duration':eOfgWoXNTdxsybtwImuakrYCvDjHQp,'premiered':eOfgWoXNTdxsybtwImuakrYCvDjHcM,'studio':eOfgWoXNTdxsybtwImuakrYCvDjHQc,'mpaa':eOfgWoXNTdxsybtwImuakrYCvDjHcG,'plot':eOfgWoXNTdxsybtwImuakrYCvDjHqK}
   eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'MOVIE','mediacode':eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('moviecode'),'stype':'movie','title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'thumbnail':eOfgWoXNTdxsybtwImuakrYCvDjHqL}
   if eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_settings_makebookmark():
    eOfgWoXNTdxsybtwImuakrYCvDjHcJ={'videoid':eOfgWoXNTdxsybtwImuakrYCvDjHQM.get('moviecode'),'vidtype':'movie','vtitle':eOfgWoXNTdxsybtwImuakrYCvDjHQl,'vsubtitle':'',}
    eOfgWoXNTdxsybtwImuakrYCvDjHcS=json.dumps(eOfgWoXNTdxsybtwImuakrYCvDjHcJ)
    eOfgWoXNTdxsybtwImuakrYCvDjHcS=urllib.parse.quote(eOfgWoXNTdxsybtwImuakrYCvDjHcS)
    eOfgWoXNTdxsybtwImuakrYCvDjHcV='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(eOfgWoXNTdxsybtwImuakrYCvDjHcS)
    eOfgWoXNTdxsybtwImuakrYCvDjHcP=[('(통합) 찜 영상에 추가',eOfgWoXNTdxsybtwImuakrYCvDjHcV)]
   else:
    eOfgWoXNTdxsybtwImuakrYCvDjHcP=eOfgWoXNTdxsybtwImuakrYCvDjHpl
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel='',img=eOfgWoXNTdxsybtwImuakrYCvDjHqL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHcp,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpc,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK,ContextMenu=eOfgWoXNTdxsybtwImuakrYCvDjHcP)
  if eOfgWoXNTdxsybtwImuakrYCvDjHqz:
   eOfgWoXNTdxsybtwImuakrYCvDjHlK={}
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['mode'] ='MOVIE_SUB' 
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['orderby']=eOfgWoXNTdxsybtwImuakrYCvDjHlR
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['stype'] =eOfgWoXNTdxsybtwImuakrYCvDjHcE
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['page'] =eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlA='[B]%s >>[/B]'%'다음 페이지'
   eOfgWoXNTdxsybtwImuakrYCvDjHci=eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel=eOfgWoXNTdxsybtwImuakrYCvDjHci,img=eOfgWoXNTdxsybtwImuakrYCvDjHlL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHpl,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK)
  xbmcplugin.setContent(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,'movies')
  xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,cacheToDisc=eOfgWoXNTdxsybtwImuakrYCvDjHpc)
 def dp_Set_Bookmark(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHQi=urllib.parse.unquote(eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('bm_param'))
  eOfgWoXNTdxsybtwImuakrYCvDjHQi=json.loads(eOfgWoXNTdxsybtwImuakrYCvDjHQi)
  eOfgWoXNTdxsybtwImuakrYCvDjHQE =eOfgWoXNTdxsybtwImuakrYCvDjHQi.get('videoid')
  eOfgWoXNTdxsybtwImuakrYCvDjHQR =eOfgWoXNTdxsybtwImuakrYCvDjHQi.get('vidtype')
  eOfgWoXNTdxsybtwImuakrYCvDjHQB =eOfgWoXNTdxsybtwImuakrYCvDjHQi.get('vtitle')
  eOfgWoXNTdxsybtwImuakrYCvDjHQA =eOfgWoXNTdxsybtwImuakrYCvDjHQi.get('vsubtitle')
  eOfgWoXNTdxsybtwImuakrYCvDjHUJ=xbmcgui.Dialog()
  eOfgWoXNTdxsybtwImuakrYCvDjHqi=eOfgWoXNTdxsybtwImuakrYCvDjHUJ.yesno(__language__(30913).encode('utf8'),eOfgWoXNTdxsybtwImuakrYCvDjHQB+' \n\n'+__language__(30914))
  if eOfgWoXNTdxsybtwImuakrYCvDjHqi==eOfgWoXNTdxsybtwImuakrYCvDjHpc:return
  eOfgWoXNTdxsybtwImuakrYCvDjHQF=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.GetBookmarkInfo(eOfgWoXNTdxsybtwImuakrYCvDjHQE,eOfgWoXNTdxsybtwImuakrYCvDjHQR)
  if eOfgWoXNTdxsybtwImuakrYCvDjHQA!='':
   eOfgWoXNTdxsybtwImuakrYCvDjHQF['saveinfo']['subtitle']=eOfgWoXNTdxsybtwImuakrYCvDjHQA 
   if eOfgWoXNTdxsybtwImuakrYCvDjHQR=='tvshow':eOfgWoXNTdxsybtwImuakrYCvDjHQF['saveinfo']['infoLabels']['studio']=eOfgWoXNTdxsybtwImuakrYCvDjHQA 
  eOfgWoXNTdxsybtwImuakrYCvDjHQJ=json.dumps(eOfgWoXNTdxsybtwImuakrYCvDjHQF)
  eOfgWoXNTdxsybtwImuakrYCvDjHQJ=urllib.parse.quote(eOfgWoXNTdxsybtwImuakrYCvDjHQJ)
  eOfgWoXNTdxsybtwImuakrYCvDjHcV ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(eOfgWoXNTdxsybtwImuakrYCvDjHQJ)
  xbmc.executebuiltin(eOfgWoXNTdxsybtwImuakrYCvDjHcV)
 def dp_Search_Group(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  if 'search_key' in eOfgWoXNTdxsybtwImuakrYCvDjHqS:
   eOfgWoXNTdxsybtwImuakrYCvDjHQS=eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('search_key')
  else:
   eOfgWoXNTdxsybtwImuakrYCvDjHQS=eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not eOfgWoXNTdxsybtwImuakrYCvDjHQS:
    return
  for eOfgWoXNTdxsybtwImuakrYCvDjHqJ in eOfgWoXNTdxsybtwImuakrYCvDjHUh:
   eOfgWoXNTdxsybtwImuakrYCvDjHQV =eOfgWoXNTdxsybtwImuakrYCvDjHqJ.get('mode')
   eOfgWoXNTdxsybtwImuakrYCvDjHqA=eOfgWoXNTdxsybtwImuakrYCvDjHqJ.get('stype')
   eOfgWoXNTdxsybtwImuakrYCvDjHlA=eOfgWoXNTdxsybtwImuakrYCvDjHqJ.get('title')
   (eOfgWoXNTdxsybtwImuakrYCvDjHQP,eOfgWoXNTdxsybtwImuakrYCvDjHqz)=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Gn2_Search_List(eOfgWoXNTdxsybtwImuakrYCvDjHQS,1,eOfgWoXNTdxsybtwImuakrYCvDjHqA)
   eOfgWoXNTdxsybtwImuakrYCvDjHqc={'plot':'검색어 : '+eOfgWoXNTdxsybtwImuakrYCvDjHQS+'\n\n'+eOfgWoXNTdxsybtwImuakrYCvDjHUE.Search_FreeList(eOfgWoXNTdxsybtwImuakrYCvDjHQP)}
   eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':eOfgWoXNTdxsybtwImuakrYCvDjHQV,'stype':eOfgWoXNTdxsybtwImuakrYCvDjHqA,'search_key':eOfgWoXNTdxsybtwImuakrYCvDjHQS,'page':'1',}
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel='',img='',infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHqc,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK)
  if eOfgWoXNTdxsybtwImuakrYCvDjHpE(eOfgWoXNTdxsybtwImuakrYCvDjHUh)>0:xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,cacheToDisc=eOfgWoXNTdxsybtwImuakrYCvDjHpQ)
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.Save_Searched_List(eOfgWoXNTdxsybtwImuakrYCvDjHQS)
 def Search_FreeList(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHhQ):
  eOfgWoXNTdxsybtwImuakrYCvDjHQz=''
  eOfgWoXNTdxsybtwImuakrYCvDjHQn=7
  try:
   if eOfgWoXNTdxsybtwImuakrYCvDjHpE(eOfgWoXNTdxsybtwImuakrYCvDjHhQ)==0:return '검색결과 없음'
   for i in eOfgWoXNTdxsybtwImuakrYCvDjHpB(eOfgWoXNTdxsybtwImuakrYCvDjHpE(eOfgWoXNTdxsybtwImuakrYCvDjHhQ)):
    if i>=eOfgWoXNTdxsybtwImuakrYCvDjHQn:
     eOfgWoXNTdxsybtwImuakrYCvDjHQz=eOfgWoXNTdxsybtwImuakrYCvDjHQz+'...'
     break
    eOfgWoXNTdxsybtwImuakrYCvDjHQz=eOfgWoXNTdxsybtwImuakrYCvDjHQz+eOfgWoXNTdxsybtwImuakrYCvDjHhQ[i]['title']+'\n'
  except:
   return ''
  return eOfgWoXNTdxsybtwImuakrYCvDjHQz
 def dp_Search_History(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHQL=eOfgWoXNTdxsybtwImuakrYCvDjHUE.Load_List_File('search')
  for eOfgWoXNTdxsybtwImuakrYCvDjHQK in eOfgWoXNTdxsybtwImuakrYCvDjHQL:
   eOfgWoXNTdxsybtwImuakrYCvDjHhU=eOfgWoXNTdxsybtwImuakrYCvDjHpG(urllib.parse.parse_qsl(eOfgWoXNTdxsybtwImuakrYCvDjHQK))
   eOfgWoXNTdxsybtwImuakrYCvDjHhl=eOfgWoXNTdxsybtwImuakrYCvDjHhU.get('skey').strip()
   eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'SEARCH_GROUP','search_key':eOfgWoXNTdxsybtwImuakrYCvDjHhl,}
   eOfgWoXNTdxsybtwImuakrYCvDjHhq={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':eOfgWoXNTdxsybtwImuakrYCvDjHhl,'vType':'-',}
   eOfgWoXNTdxsybtwImuakrYCvDjHhc=urllib.parse.urlencode(eOfgWoXNTdxsybtwImuakrYCvDjHhq)
   eOfgWoXNTdxsybtwImuakrYCvDjHcP=[('선택된 검색어 ( %s ) 삭제'%(eOfgWoXNTdxsybtwImuakrYCvDjHhl),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(eOfgWoXNTdxsybtwImuakrYCvDjHhc))]
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHhl,sublabel='',img=eOfgWoXNTdxsybtwImuakrYCvDjHpl,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHpl,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK,ContextMenu=eOfgWoXNTdxsybtwImuakrYCvDjHcP)
  eOfgWoXNTdxsybtwImuakrYCvDjHcp={'plot':'검색목록 전체를 삭제합니다.'}
  eOfgWoXNTdxsybtwImuakrYCvDjHlA='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  eOfgWoXNTdxsybtwImuakrYCvDjHlL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel='',img=eOfgWoXNTdxsybtwImuakrYCvDjHlL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHcp,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpc,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK,isLink=eOfgWoXNTdxsybtwImuakrYCvDjHpQ)
  xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,cacheToDisc=eOfgWoXNTdxsybtwImuakrYCvDjHpc)
 def dp_Search_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHqV =eOfgWoXNTdxsybtwImuakrYCvDjHpq(eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('page'))
  eOfgWoXNTdxsybtwImuakrYCvDjHqA =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('stype')
  if 'search_key' in eOfgWoXNTdxsybtwImuakrYCvDjHqS:
   eOfgWoXNTdxsybtwImuakrYCvDjHQS=eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('search_key')
  else:
   eOfgWoXNTdxsybtwImuakrYCvDjHQS=eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not eOfgWoXNTdxsybtwImuakrYCvDjHQS:
    xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle)
    return
  eOfgWoXNTdxsybtwImuakrYCvDjHQP,eOfgWoXNTdxsybtwImuakrYCvDjHqz=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Gn2_Search_List(eOfgWoXNTdxsybtwImuakrYCvDjHQS,eOfgWoXNTdxsybtwImuakrYCvDjHqV,eOfgWoXNTdxsybtwImuakrYCvDjHqA)
  for eOfgWoXNTdxsybtwImuakrYCvDjHhQ in eOfgWoXNTdxsybtwImuakrYCvDjHQP:
   eOfgWoXNTdxsybtwImuakrYCvDjHlA =eOfgWoXNTdxsybtwImuakrYCvDjHhQ.get('title')
   eOfgWoXNTdxsybtwImuakrYCvDjHqL =eOfgWoXNTdxsybtwImuakrYCvDjHhQ.get('thumbnail')
   eOfgWoXNTdxsybtwImuakrYCvDjHcp={'mediatype':'tvshow' if eOfgWoXNTdxsybtwImuakrYCvDjHqA=='vod' else 'movie','title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'plot':'%s'%(eOfgWoXNTdxsybtwImuakrYCvDjHlA)}
   if eOfgWoXNTdxsybtwImuakrYCvDjHqA=='vod':
    eOfgWoXNTdxsybtwImuakrYCvDjHQE=eOfgWoXNTdxsybtwImuakrYCvDjHhQ.get('program')
    eOfgWoXNTdxsybtwImuakrYCvDjHQR='tvshow'
    eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'EPISODE','programcode':eOfgWoXNTdxsybtwImuakrYCvDjHQE,'page':'1',}
    eOfgWoXNTdxsybtwImuakrYCvDjHqU=eOfgWoXNTdxsybtwImuakrYCvDjHpQ
   else:
    eOfgWoXNTdxsybtwImuakrYCvDjHQE=eOfgWoXNTdxsybtwImuakrYCvDjHhQ.get('movie')
    eOfgWoXNTdxsybtwImuakrYCvDjHQR='movie'
    eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'MOVIE','mediacode':eOfgWoXNTdxsybtwImuakrYCvDjHQE,'stype':'movie','title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'thumbnail':eOfgWoXNTdxsybtwImuakrYCvDjHqL,}
    eOfgWoXNTdxsybtwImuakrYCvDjHqU=eOfgWoXNTdxsybtwImuakrYCvDjHpc
   if eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_settings_makebookmark():
    eOfgWoXNTdxsybtwImuakrYCvDjHcJ={'videoid':eOfgWoXNTdxsybtwImuakrYCvDjHQE,'vidtype':eOfgWoXNTdxsybtwImuakrYCvDjHQR,'vtitle':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'vsubtitle':'',}
    eOfgWoXNTdxsybtwImuakrYCvDjHcS=json.dumps(eOfgWoXNTdxsybtwImuakrYCvDjHcJ)
    eOfgWoXNTdxsybtwImuakrYCvDjHcS=urllib.parse.quote(eOfgWoXNTdxsybtwImuakrYCvDjHcS)
    eOfgWoXNTdxsybtwImuakrYCvDjHcV='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(eOfgWoXNTdxsybtwImuakrYCvDjHcS)
    eOfgWoXNTdxsybtwImuakrYCvDjHcP=[('(통합) 찜 영상에 추가',eOfgWoXNTdxsybtwImuakrYCvDjHcV)]
   else:
    eOfgWoXNTdxsybtwImuakrYCvDjHcP=eOfgWoXNTdxsybtwImuakrYCvDjHpl
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel='',img=eOfgWoXNTdxsybtwImuakrYCvDjHqL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHcp,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHqU,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK,isLink=eOfgWoXNTdxsybtwImuakrYCvDjHpc,ContextMenu=eOfgWoXNTdxsybtwImuakrYCvDjHcP)
  if eOfgWoXNTdxsybtwImuakrYCvDjHqz:
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['mode'] ='SEARCH' 
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['search_key']=eOfgWoXNTdxsybtwImuakrYCvDjHQS
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['page'] =eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlA='[B]%s >>[/B]'%'다음 페이지'
   eOfgWoXNTdxsybtwImuakrYCvDjHci=eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel=eOfgWoXNTdxsybtwImuakrYCvDjHci,img=eOfgWoXNTdxsybtwImuakrYCvDjHlL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHpl,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK)
  if eOfgWoXNTdxsybtwImuakrYCvDjHqA=='movie':xbmcplugin.setContent(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,'movies')
  else:xbmcplugin.setContent(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,cacheToDisc=eOfgWoXNTdxsybtwImuakrYCvDjHpc)
 def dp_History_Remove(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHhG=eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('delType')
  eOfgWoXNTdxsybtwImuakrYCvDjHhM =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('sKey')
  eOfgWoXNTdxsybtwImuakrYCvDjHhp =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('vType')
  eOfgWoXNTdxsybtwImuakrYCvDjHUJ=xbmcgui.Dialog()
  if eOfgWoXNTdxsybtwImuakrYCvDjHhG=='SEARCH_ALL':
   eOfgWoXNTdxsybtwImuakrYCvDjHqi=eOfgWoXNTdxsybtwImuakrYCvDjHUJ.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif eOfgWoXNTdxsybtwImuakrYCvDjHhG=='SEARCH_ONE':
   eOfgWoXNTdxsybtwImuakrYCvDjHqi=eOfgWoXNTdxsybtwImuakrYCvDjHUJ.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif eOfgWoXNTdxsybtwImuakrYCvDjHhG=='WATCH_ALL':
   eOfgWoXNTdxsybtwImuakrYCvDjHqi=eOfgWoXNTdxsybtwImuakrYCvDjHUJ.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif eOfgWoXNTdxsybtwImuakrYCvDjHhG=='WATCH_ONE':
   eOfgWoXNTdxsybtwImuakrYCvDjHqi=eOfgWoXNTdxsybtwImuakrYCvDjHUJ.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if eOfgWoXNTdxsybtwImuakrYCvDjHqi==eOfgWoXNTdxsybtwImuakrYCvDjHpc:sys.exit()
  if eOfgWoXNTdxsybtwImuakrYCvDjHhG=='SEARCH_ALL':
   if os.path.isfile(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.SEARCHED_FILE_NAME):os.remove(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.SEARCHED_FILE_NAME)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHhG=='SEARCH_ONE':
   try:
    eOfgWoXNTdxsybtwImuakrYCvDjHhi=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.SEARCHED_FILE_NAME
    eOfgWoXNTdxsybtwImuakrYCvDjHhE=eOfgWoXNTdxsybtwImuakrYCvDjHUE.Load_List_File('search') 
    fp=eOfgWoXNTdxsybtwImuakrYCvDjHpA(eOfgWoXNTdxsybtwImuakrYCvDjHhi,'w',-1,'utf-8')
    for eOfgWoXNTdxsybtwImuakrYCvDjHhR in eOfgWoXNTdxsybtwImuakrYCvDjHhE:
     eOfgWoXNTdxsybtwImuakrYCvDjHhB=eOfgWoXNTdxsybtwImuakrYCvDjHpG(urllib.parse.parse_qsl(eOfgWoXNTdxsybtwImuakrYCvDjHhR))
     eOfgWoXNTdxsybtwImuakrYCvDjHhA=eOfgWoXNTdxsybtwImuakrYCvDjHhB.get('skey').strip()
     if eOfgWoXNTdxsybtwImuakrYCvDjHhM!=eOfgWoXNTdxsybtwImuakrYCvDjHhA:
      fp.write(eOfgWoXNTdxsybtwImuakrYCvDjHhR)
    fp.close()
   except:
    eOfgWoXNTdxsybtwImuakrYCvDjHpl
  elif eOfgWoXNTdxsybtwImuakrYCvDjHhG=='WATCH_ALL':
   eOfgWoXNTdxsybtwImuakrYCvDjHhi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eOfgWoXNTdxsybtwImuakrYCvDjHhp))
   if os.path.isfile(eOfgWoXNTdxsybtwImuakrYCvDjHhi):os.remove(eOfgWoXNTdxsybtwImuakrYCvDjHhi)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHhG=='WATCH_ONE':
   eOfgWoXNTdxsybtwImuakrYCvDjHhi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eOfgWoXNTdxsybtwImuakrYCvDjHhp))
   try:
    eOfgWoXNTdxsybtwImuakrYCvDjHhE=eOfgWoXNTdxsybtwImuakrYCvDjHUE.Load_List_File(eOfgWoXNTdxsybtwImuakrYCvDjHhp) 
    fp=eOfgWoXNTdxsybtwImuakrYCvDjHpA(eOfgWoXNTdxsybtwImuakrYCvDjHhi,'w',-1,'utf-8')
    for eOfgWoXNTdxsybtwImuakrYCvDjHhR in eOfgWoXNTdxsybtwImuakrYCvDjHhE:
     eOfgWoXNTdxsybtwImuakrYCvDjHhB=eOfgWoXNTdxsybtwImuakrYCvDjHpG(urllib.parse.parse_qsl(eOfgWoXNTdxsybtwImuakrYCvDjHhR))
     eOfgWoXNTdxsybtwImuakrYCvDjHhA=eOfgWoXNTdxsybtwImuakrYCvDjHhB.get('code').strip()
     if eOfgWoXNTdxsybtwImuakrYCvDjHhM!=eOfgWoXNTdxsybtwImuakrYCvDjHhA:
      fp.write(eOfgWoXNTdxsybtwImuakrYCvDjHhR)
    fp.close()
   except:
    eOfgWoXNTdxsybtwImuakrYCvDjHpl
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqA): 
  try:
   if eOfgWoXNTdxsybtwImuakrYCvDjHqA=='search':
    eOfgWoXNTdxsybtwImuakrYCvDjHhi=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.SEARCHED_FILE_NAME
   elif eOfgWoXNTdxsybtwImuakrYCvDjHqA in['vod','movie']:
    eOfgWoXNTdxsybtwImuakrYCvDjHhi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eOfgWoXNTdxsybtwImuakrYCvDjHqA))
   else:
    return[]
   fp=eOfgWoXNTdxsybtwImuakrYCvDjHpA(eOfgWoXNTdxsybtwImuakrYCvDjHhi,'r',-1,'utf-8')
   eOfgWoXNTdxsybtwImuakrYCvDjHhF=fp.readlines()
   fp.close()
  except:
   eOfgWoXNTdxsybtwImuakrYCvDjHhF=[]
  return eOfgWoXNTdxsybtwImuakrYCvDjHhF
 def Save_Watched_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqA,eOfgWoXNTdxsybtwImuakrYCvDjHUA):
  try:
   eOfgWoXNTdxsybtwImuakrYCvDjHhJ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eOfgWoXNTdxsybtwImuakrYCvDjHqA))
   eOfgWoXNTdxsybtwImuakrYCvDjHhE=eOfgWoXNTdxsybtwImuakrYCvDjHUE.Load_List_File(eOfgWoXNTdxsybtwImuakrYCvDjHqA) 
   fp=eOfgWoXNTdxsybtwImuakrYCvDjHpA(eOfgWoXNTdxsybtwImuakrYCvDjHhJ,'w',-1,'utf-8')
   eOfgWoXNTdxsybtwImuakrYCvDjHhS=urllib.parse.urlencode(eOfgWoXNTdxsybtwImuakrYCvDjHUA)
   eOfgWoXNTdxsybtwImuakrYCvDjHhS=eOfgWoXNTdxsybtwImuakrYCvDjHhS+'\n'
   fp.write(eOfgWoXNTdxsybtwImuakrYCvDjHhS)
   eOfgWoXNTdxsybtwImuakrYCvDjHhV=0
   for eOfgWoXNTdxsybtwImuakrYCvDjHhR in eOfgWoXNTdxsybtwImuakrYCvDjHhE:
    eOfgWoXNTdxsybtwImuakrYCvDjHhB=eOfgWoXNTdxsybtwImuakrYCvDjHpG(urllib.parse.parse_qsl(eOfgWoXNTdxsybtwImuakrYCvDjHhR))
    eOfgWoXNTdxsybtwImuakrYCvDjHhP=eOfgWoXNTdxsybtwImuakrYCvDjHUA.get('code').strip()
    eOfgWoXNTdxsybtwImuakrYCvDjHhz=eOfgWoXNTdxsybtwImuakrYCvDjHhB.get('code').strip()
    if eOfgWoXNTdxsybtwImuakrYCvDjHqA=='vod' and eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_settings_direct_replay()==eOfgWoXNTdxsybtwImuakrYCvDjHpQ:
     eOfgWoXNTdxsybtwImuakrYCvDjHhP=eOfgWoXNTdxsybtwImuakrYCvDjHUA.get('videoid').strip()
     eOfgWoXNTdxsybtwImuakrYCvDjHhz=eOfgWoXNTdxsybtwImuakrYCvDjHhB.get('videoid').strip()if eOfgWoXNTdxsybtwImuakrYCvDjHhz!=eOfgWoXNTdxsybtwImuakrYCvDjHpl else '-'
    if eOfgWoXNTdxsybtwImuakrYCvDjHhP!=eOfgWoXNTdxsybtwImuakrYCvDjHhz:
     fp.write(eOfgWoXNTdxsybtwImuakrYCvDjHhR)
     eOfgWoXNTdxsybtwImuakrYCvDjHhV+=1
     if eOfgWoXNTdxsybtwImuakrYCvDjHhV>=50:break
   fp.close()
  except:
   eOfgWoXNTdxsybtwImuakrYCvDjHpl
 def dp_Watch_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHqA =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('stype')
  eOfgWoXNTdxsybtwImuakrYCvDjHli=eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_settings_direct_replay()
  if eOfgWoXNTdxsybtwImuakrYCvDjHqA=='-':
   for eOfgWoXNTdxsybtwImuakrYCvDjHqJ in eOfgWoXNTdxsybtwImuakrYCvDjHUQ:
    eOfgWoXNTdxsybtwImuakrYCvDjHlA=eOfgWoXNTdxsybtwImuakrYCvDjHqJ.get('title')
    eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':eOfgWoXNTdxsybtwImuakrYCvDjHqJ.get('mode'),'stype':eOfgWoXNTdxsybtwImuakrYCvDjHqJ.get('stype')}
    eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel='',img='',infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHpl,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK)
   if eOfgWoXNTdxsybtwImuakrYCvDjHpE(eOfgWoXNTdxsybtwImuakrYCvDjHUQ)>0:xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle)
  else:
   eOfgWoXNTdxsybtwImuakrYCvDjHhn=eOfgWoXNTdxsybtwImuakrYCvDjHUE.Load_List_File(eOfgWoXNTdxsybtwImuakrYCvDjHqA)
   for eOfgWoXNTdxsybtwImuakrYCvDjHhL in eOfgWoXNTdxsybtwImuakrYCvDjHhn:
    eOfgWoXNTdxsybtwImuakrYCvDjHhU=eOfgWoXNTdxsybtwImuakrYCvDjHpG(urllib.parse.parse_qsl(eOfgWoXNTdxsybtwImuakrYCvDjHhL))
    eOfgWoXNTdxsybtwImuakrYCvDjHhK =eOfgWoXNTdxsybtwImuakrYCvDjHhU.get('code').strip()
    eOfgWoXNTdxsybtwImuakrYCvDjHlA =eOfgWoXNTdxsybtwImuakrYCvDjHhU.get('title').strip()
    eOfgWoXNTdxsybtwImuakrYCvDjHqL=eOfgWoXNTdxsybtwImuakrYCvDjHhU.get('img').strip()
    eOfgWoXNTdxsybtwImuakrYCvDjHQE =eOfgWoXNTdxsybtwImuakrYCvDjHhU.get('videoid').strip()
    try:
     eOfgWoXNTdxsybtwImuakrYCvDjHqL=eOfgWoXNTdxsybtwImuakrYCvDjHqL.replace('\'','\"')
     eOfgWoXNTdxsybtwImuakrYCvDjHqL=json.loads(eOfgWoXNTdxsybtwImuakrYCvDjHqL)
    except:
     eOfgWoXNTdxsybtwImuakrYCvDjHpl
    eOfgWoXNTdxsybtwImuakrYCvDjHcp={}
    eOfgWoXNTdxsybtwImuakrYCvDjHcp['plot']=eOfgWoXNTdxsybtwImuakrYCvDjHlA
    if eOfgWoXNTdxsybtwImuakrYCvDjHqA=='vod':
     if eOfgWoXNTdxsybtwImuakrYCvDjHli==eOfgWoXNTdxsybtwImuakrYCvDjHpc or eOfgWoXNTdxsybtwImuakrYCvDjHQE==eOfgWoXNTdxsybtwImuakrYCvDjHpl:
      eOfgWoXNTdxsybtwImuakrYCvDjHcp['mediatype']='tvshow'
      eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'EPISODE','programcode':eOfgWoXNTdxsybtwImuakrYCvDjHhK,'page':'1'}
      eOfgWoXNTdxsybtwImuakrYCvDjHqU=eOfgWoXNTdxsybtwImuakrYCvDjHpQ
     else:
      eOfgWoXNTdxsybtwImuakrYCvDjHcp['mediatype']='episode'
      eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'VOD','mediacode':eOfgWoXNTdxsybtwImuakrYCvDjHQE,'stype':'vod','programcode':eOfgWoXNTdxsybtwImuakrYCvDjHhK,'title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'thumbnail':eOfgWoXNTdxsybtwImuakrYCvDjHqL}
      eOfgWoXNTdxsybtwImuakrYCvDjHqU=eOfgWoXNTdxsybtwImuakrYCvDjHpc
    else:
     eOfgWoXNTdxsybtwImuakrYCvDjHcp['mediatype']='movie'
     eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'MOVIE','mediacode':eOfgWoXNTdxsybtwImuakrYCvDjHhK,'stype':'movie','title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'thumbnail':eOfgWoXNTdxsybtwImuakrYCvDjHqL}
     eOfgWoXNTdxsybtwImuakrYCvDjHqU=eOfgWoXNTdxsybtwImuakrYCvDjHpc
    eOfgWoXNTdxsybtwImuakrYCvDjHhq={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':eOfgWoXNTdxsybtwImuakrYCvDjHhK,'vType':eOfgWoXNTdxsybtwImuakrYCvDjHqA,}
    eOfgWoXNTdxsybtwImuakrYCvDjHhc=urllib.parse.urlencode(eOfgWoXNTdxsybtwImuakrYCvDjHhq)
    eOfgWoXNTdxsybtwImuakrYCvDjHcP=[('선택된 시청이력 ( %s ) 삭제'%(eOfgWoXNTdxsybtwImuakrYCvDjHlA),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(eOfgWoXNTdxsybtwImuakrYCvDjHhc))]
    eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel='',img=eOfgWoXNTdxsybtwImuakrYCvDjHqL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHcp,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHqU,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK,ContextMenu=eOfgWoXNTdxsybtwImuakrYCvDjHcP)
   eOfgWoXNTdxsybtwImuakrYCvDjHcp={'plot':'시청목록을 삭제합니다.'}
   eOfgWoXNTdxsybtwImuakrYCvDjHlA='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':eOfgWoXNTdxsybtwImuakrYCvDjHqA,}
   eOfgWoXNTdxsybtwImuakrYCvDjHlL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel='',img=eOfgWoXNTdxsybtwImuakrYCvDjHlL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHcp,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpc,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK,isLink=eOfgWoXNTdxsybtwImuakrYCvDjHpQ)
   if eOfgWoXNTdxsybtwImuakrYCvDjHqA=='movie':xbmcplugin.setContent(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,'movies')
   else:xbmcplugin.setContent(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,cacheToDisc=eOfgWoXNTdxsybtwImuakrYCvDjHpc)
 def Save_Searched_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHQS):
  try:
   eOfgWoXNTdxsybtwImuakrYCvDjHGU=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.SEARCHED_FILE_NAME
   eOfgWoXNTdxsybtwImuakrYCvDjHhE=eOfgWoXNTdxsybtwImuakrYCvDjHUE.Load_List_File('search') 
   eOfgWoXNTdxsybtwImuakrYCvDjHGl={'skey':eOfgWoXNTdxsybtwImuakrYCvDjHQS.strip()}
   fp=eOfgWoXNTdxsybtwImuakrYCvDjHpA(eOfgWoXNTdxsybtwImuakrYCvDjHGU,'w',-1,'utf-8')
   eOfgWoXNTdxsybtwImuakrYCvDjHhS=urllib.parse.urlencode(eOfgWoXNTdxsybtwImuakrYCvDjHGl)
   eOfgWoXNTdxsybtwImuakrYCvDjHhS=eOfgWoXNTdxsybtwImuakrYCvDjHhS+'\n'
   fp.write(eOfgWoXNTdxsybtwImuakrYCvDjHhS)
   eOfgWoXNTdxsybtwImuakrYCvDjHhV=0
   for eOfgWoXNTdxsybtwImuakrYCvDjHhR in eOfgWoXNTdxsybtwImuakrYCvDjHhE:
    eOfgWoXNTdxsybtwImuakrYCvDjHhB=eOfgWoXNTdxsybtwImuakrYCvDjHpG(urllib.parse.parse_qsl(eOfgWoXNTdxsybtwImuakrYCvDjHhR))
    eOfgWoXNTdxsybtwImuakrYCvDjHhP=eOfgWoXNTdxsybtwImuakrYCvDjHGl.get('skey').strip()
    eOfgWoXNTdxsybtwImuakrYCvDjHhz=eOfgWoXNTdxsybtwImuakrYCvDjHhB.get('skey').strip()
    if eOfgWoXNTdxsybtwImuakrYCvDjHhP!=eOfgWoXNTdxsybtwImuakrYCvDjHhz:
     fp.write(eOfgWoXNTdxsybtwImuakrYCvDjHhR)
     eOfgWoXNTdxsybtwImuakrYCvDjHhV+=1
     if eOfgWoXNTdxsybtwImuakrYCvDjHhV>=50:break
   fp.close()
  except:
   eOfgWoXNTdxsybtwImuakrYCvDjHpl
 def play_VIDEO(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHGq =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('mediacode')
  eOfgWoXNTdxsybtwImuakrYCvDjHqA =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('stype')
  eOfgWoXNTdxsybtwImuakrYCvDjHGc =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('pvrmode')
  eOfgWoXNTdxsybtwImuakrYCvDjHGQ=eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_selQuality(eOfgWoXNTdxsybtwImuakrYCvDjHqA)
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(eOfgWoXNTdxsybtwImuakrYCvDjHGq,eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHGQ),eOfgWoXNTdxsybtwImuakrYCvDjHqA,eOfgWoXNTdxsybtwImuakrYCvDjHGc))
  eOfgWoXNTdxsybtwImuakrYCvDjHGh=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.GetBroadURL(eOfgWoXNTdxsybtwImuakrYCvDjHGq,eOfgWoXNTdxsybtwImuakrYCvDjHGQ,eOfgWoXNTdxsybtwImuakrYCvDjHqA,eOfgWoXNTdxsybtwImuakrYCvDjHGc,optUHD=eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_settings_uhd())
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_log('qt, stype, url : %s - %s - %s'%(eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHGQ),eOfgWoXNTdxsybtwImuakrYCvDjHqA,eOfgWoXNTdxsybtwImuakrYCvDjHGh['streaming_url']))
  if eOfgWoXNTdxsybtwImuakrYCvDjHGh['streaming_url']=='':
   if eOfgWoXNTdxsybtwImuakrYCvDjHGh['error_msg']=='':
    eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_noti(__language__(30908).encode('utf8'))
   else:
    eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_noti(eOfgWoXNTdxsybtwImuakrYCvDjHGh['error_msg'].encode('utf8'))
   return
  if eOfgWoXNTdxsybtwImuakrYCvDjHGh['qt_stream']=='stream70':
   eOfgWoXNTdxsybtwImuakrYCvDjHGM={'user-agent':eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.USER_AGENT_ATV}
  else:
   eOfgWoXNTdxsybtwImuakrYCvDjHGM={'user-agent':eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.USER_AGENT}
  eOfgWoXNTdxsybtwImuakrYCvDjHGp=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.makeDefaultCookies() 
  if eOfgWoXNTdxsybtwImuakrYCvDjHGh['watermark'] !='':
   eOfgWoXNTdxsybtwImuakrYCvDjHGM['x-tving-param1']=eOfgWoXNTdxsybtwImuakrYCvDjHGh['watermarkKey']
   eOfgWoXNTdxsybtwImuakrYCvDjHGM['x-tving-param2']=eOfgWoXNTdxsybtwImuakrYCvDjHGh['watermark'] 
  if eOfgWoXNTdxsybtwImuakrYCvDjHGh['drm_server_url'] !='':
   eOfgWoXNTdxsybtwImuakrYCvDjHGM[eOfgWoXNTdxsybtwImuakrYCvDjHGh['drm_header_key']]=eOfgWoXNTdxsybtwImuakrYCvDjHGh['drm_header_value']
  eOfgWoXNTdxsybtwImuakrYCvDjHGi =eOfgWoXNTdxsybtwImuakrYCvDjHpc
  eOfgWoXNTdxsybtwImuakrYCvDjHGE =eOfgWoXNTdxsybtwImuakrYCvDjHGh['streaming_url'].find('Policy=')
  if eOfgWoXNTdxsybtwImuakrYCvDjHGE!=-1:
   eOfgWoXNTdxsybtwImuakrYCvDjHGR =eOfgWoXNTdxsybtwImuakrYCvDjHGh['streaming_url'].split('?')[0]
   eOfgWoXNTdxsybtwImuakrYCvDjHGB=eOfgWoXNTdxsybtwImuakrYCvDjHpG(urllib.parse.parse_qsl(urllib.parse.urlsplit(eOfgWoXNTdxsybtwImuakrYCvDjHGh['streaming_url']).query))
   eOfgWoXNTdxsybtwImuakrYCvDjHGp['CloudFront-Policy'] =eOfgWoXNTdxsybtwImuakrYCvDjHGB['Policy'] 
   eOfgWoXNTdxsybtwImuakrYCvDjHGp['CloudFront-Signature'] =eOfgWoXNTdxsybtwImuakrYCvDjHGB['Signature'] 
   eOfgWoXNTdxsybtwImuakrYCvDjHGp['CloudFront-Key-Pair-Id']=eOfgWoXNTdxsybtwImuakrYCvDjHGB['Key-Pair-Id'] 
   eOfgWoXNTdxsybtwImuakrYCvDjHGA=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.make_stream_header(eOfgWoXNTdxsybtwImuakrYCvDjHGM,eOfgWoXNTdxsybtwImuakrYCvDjHGp)
   if 'quickvod-mcdn.tving.com' in eOfgWoXNTdxsybtwImuakrYCvDjHGR:
    eOfgWoXNTdxsybtwImuakrYCvDjHGi=eOfgWoXNTdxsybtwImuakrYCvDjHpQ
    eOfgWoXNTdxsybtwImuakrYCvDjHGF =eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    eOfgWoXNTdxsybtwImuakrYCvDjHGJ=eOfgWoXNTdxsybtwImuakrYCvDjHGF.strftime('%Y-%m-%d-%H:%M:%S')
    if eOfgWoXNTdxsybtwImuakrYCvDjHpq(eOfgWoXNTdxsybtwImuakrYCvDjHGJ.replace('-','').replace(':',''))<eOfgWoXNTdxsybtwImuakrYCvDjHpq(eOfgWoXNTdxsybtwImuakrYCvDjHGB['end'].replace('-','').replace(':','')):
     eOfgWoXNTdxsybtwImuakrYCvDjHGB['end']=eOfgWoXNTdxsybtwImuakrYCvDjHGJ
     eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_noti(__language__(30915).encode('utf8'))
    eOfgWoXNTdxsybtwImuakrYCvDjHGR ='%s?%s'%(eOfgWoXNTdxsybtwImuakrYCvDjHGR,urllib.parse.urlencode(eOfgWoXNTdxsybtwImuakrYCvDjHGB,doseq=eOfgWoXNTdxsybtwImuakrYCvDjHpQ))
    eOfgWoXNTdxsybtwImuakrYCvDjHGS='{}|{}'.format(eOfgWoXNTdxsybtwImuakrYCvDjHGR,eOfgWoXNTdxsybtwImuakrYCvDjHGA)
   else:
    eOfgWoXNTdxsybtwImuakrYCvDjHGS='{}|{}'.format(eOfgWoXNTdxsybtwImuakrYCvDjHGh['streaming_url'],eOfgWoXNTdxsybtwImuakrYCvDjHGA)
  else:
   eOfgWoXNTdxsybtwImuakrYCvDjHGA=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.make_stream_header(eOfgWoXNTdxsybtwImuakrYCvDjHGM,eOfgWoXNTdxsybtwImuakrYCvDjHGp)
   eOfgWoXNTdxsybtwImuakrYCvDjHGS='{}|{}'.format(eOfgWoXNTdxsybtwImuakrYCvDjHGh['streaming_url'],eOfgWoXNTdxsybtwImuakrYCvDjHGA)
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_log('if tmp_pos == -1')
  eOfgWoXNTdxsybtwImuakrYCvDjHlq,eOfgWoXNTdxsybtwImuakrYCvDjHlc=eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_settings_proxyport()
  eOfgWoXNTdxsybtwImuakrYCvDjHlU=eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_settings_playback()
  if(eOfgWoXNTdxsybtwImuakrYCvDjHlq and eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('mode')in['VOD','MOVIE']and eOfgWoXNTdxsybtwImuakrYCvDjHGi==eOfgWoXNTdxsybtwImuakrYCvDjHpc and(eOfgWoXNTdxsybtwImuakrYCvDjHGh['drm_server_url']!='' or(eOfgWoXNTdxsybtwImuakrYCvDjHGh['url_filename'].split('.')[1]=='mpd')or(eOfgWoXNTdxsybtwImuakrYCvDjHGh['url_filename'].split('.')[1]!='mpd' and eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.KodiVersion>=21 and eOfgWoXNTdxsybtwImuakrYCvDjHGh['qt_stream']=='stream70'))):
   if eOfgWoXNTdxsybtwImuakrYCvDjHGh['url_filename'].split('.')[1]=='mpd':
    eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Tving_Parse_mpd(eOfgWoXNTdxsybtwImuakrYCvDjHGh['streaming_url'],eOfgWoXNTdxsybtwImuakrYCvDjHGh['watermarkKey'],eOfgWoXNTdxsybtwImuakrYCvDjHGh['watermark'])
   else:
    eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Tving_Parse_m3u8(eOfgWoXNTdxsybtwImuakrYCvDjHGh['streaming_url'])
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_log('xxx '+eOfgWoXNTdxsybtwImuakrYCvDjHGh['streaming_url'])
   eOfgWoXNTdxsybtwImuakrYCvDjHGV={'addon':'tvingm','playOption':eOfgWoXNTdxsybtwImuakrYCvDjHlU,'url_filename':eOfgWoXNTdxsybtwImuakrYCvDjHGh['url_filename'],}
   eOfgWoXNTdxsybtwImuakrYCvDjHGV=json.dumps(eOfgWoXNTdxsybtwImuakrYCvDjHGV,separators=(',',':'))
   eOfgWoXNTdxsybtwImuakrYCvDjHGV=base64.standard_b64encode(eOfgWoXNTdxsybtwImuakrYCvDjHGV.encode()).decode('utf-8')
   eOfgWoXNTdxsybtwImuakrYCvDjHGS ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(eOfgWoXNTdxsybtwImuakrYCvDjHlc,eOfgWoXNTdxsybtwImuakrYCvDjHGS,eOfgWoXNTdxsybtwImuakrYCvDjHGV)
   eOfgWoXNTdxsybtwImuakrYCvDjHGM['proxy-mini']=eOfgWoXNTdxsybtwImuakrYCvDjHGV 
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_log('surl(2) : {}'.format(eOfgWoXNTdxsybtwImuakrYCvDjHGS))
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_log('drm     : {}'.format(eOfgWoXNTdxsybtwImuakrYCvDjHGh['drm_server_url']))
  eOfgWoXNTdxsybtwImuakrYCvDjHGA=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.make_stream_header(eOfgWoXNTdxsybtwImuakrYCvDjHGM,eOfgWoXNTdxsybtwImuakrYCvDjHGp)
  eOfgWoXNTdxsybtwImuakrYCvDjHGP=xbmcgui.ListItem(path=eOfgWoXNTdxsybtwImuakrYCvDjHGS)
  if eOfgWoXNTdxsybtwImuakrYCvDjHGh['drm_server_url']!='':
   eOfgWoXNTdxsybtwImuakrYCvDjHGz=eOfgWoXNTdxsybtwImuakrYCvDjHGh['drm_server_url']
   eOfgWoXNTdxsybtwImuakrYCvDjHGn ='https://license-global.pallycon.com/ri/licenseManager.do' 
   eOfgWoXNTdxsybtwImuakrYCvDjHGL ='mpd'
   eOfgWoXNTdxsybtwImuakrYCvDjHGK ='com.widevine.alpha'
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   eOfgWoXNTdxsybtwImuakrYCvDjHMl={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.USER_AGENT,eOfgWoXNTdxsybtwImuakrYCvDjHGh['drm_header_key']:eOfgWoXNTdxsybtwImuakrYCvDjHGh['drm_header_value'],}
   eOfgWoXNTdxsybtwImuakrYCvDjHMq=eOfgWoXNTdxsybtwImuakrYCvDjHGn+'|'+urllib.parse.urlencode(eOfgWoXNTdxsybtwImuakrYCvDjHMl)+'|R{SSM}|'
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream','inputstream.adaptive')
   if eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.KodiVersion<=20:
    eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream.adaptive.manifest_type',eOfgWoXNTdxsybtwImuakrYCvDjHGL)
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream.adaptive.license_type',eOfgWoXNTdxsybtwImuakrYCvDjHGK)
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream.adaptive.license_key',eOfgWoXNTdxsybtwImuakrYCvDjHMq)
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream.adaptive.stream_headers',eOfgWoXNTdxsybtwImuakrYCvDjHGA)
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream.adaptive.manifest_headers',eOfgWoXNTdxsybtwImuakrYCvDjHGA)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('mode')in['VOD','MOVIE']:
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setContentLookup(eOfgWoXNTdxsybtwImuakrYCvDjHpc)
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setMimeType('application/x-mpegURL')
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream','inputstream.adaptive')
   if eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.KodiVersion<=20:
    eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream.adaptive.manifest_type','hls')
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream.adaptive.stream_headers',eOfgWoXNTdxsybtwImuakrYCvDjHGA)
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream.adaptive.manifest_headers',eOfgWoXNTdxsybtwImuakrYCvDjHGA)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHGi==eOfgWoXNTdxsybtwImuakrYCvDjHpQ:
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setContentLookup(eOfgWoXNTdxsybtwImuakrYCvDjHpc)
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setMimeType('application/x-mpegURL')
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream','inputstream.ffmpegdirect')
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('ResumeTime','0')
   eOfgWoXNTdxsybtwImuakrYCvDjHGP.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,eOfgWoXNTdxsybtwImuakrYCvDjHpQ,eOfgWoXNTdxsybtwImuakrYCvDjHGP)
  try:
   if eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('mode')in['VOD','MOVIE']and eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('title'):
    eOfgWoXNTdxsybtwImuakrYCvDjHlK={'code':eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('programcode')if eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('mode')=='VOD' else eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('mediacode'),'img':eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('thumbnail'),'title':eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('title'),'videoid':eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('mediacode')}
    eOfgWoXNTdxsybtwImuakrYCvDjHUE.Save_Watched_List(eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('stype'),eOfgWoXNTdxsybtwImuakrYCvDjHlK)
  except:
   eOfgWoXNTdxsybtwImuakrYCvDjHpl
 def logout(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  eOfgWoXNTdxsybtwImuakrYCvDjHUJ=xbmcgui.Dialog()
  eOfgWoXNTdxsybtwImuakrYCvDjHqi=eOfgWoXNTdxsybtwImuakrYCvDjHUJ.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if eOfgWoXNTdxsybtwImuakrYCvDjHqi==eOfgWoXNTdxsybtwImuakrYCvDjHpc:sys.exit()
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Init_TV_Total()
  if os.path.isfile(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_COOKIE_FILENAME):os.remove(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_COOKIE_FILENAME)
  if os.path.isfile(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_TOKEN_FILENAME): os.remove(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_TOKEN_FILENAME)
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  eOfgWoXNTdxsybtwImuakrYCvDjHMc =eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Get_Now_Datetime()
  eOfgWoXNTdxsybtwImuakrYCvDjHMQ=eOfgWoXNTdxsybtwImuakrYCvDjHMc+datetime.timedelta(days=30) 
  (eOfgWoXNTdxsybtwImuakrYCvDjHqh,eOfgWoXNTdxsybtwImuakrYCvDjHqG,eOfgWoXNTdxsybtwImuakrYCvDjHqM,eOfgWoXNTdxsybtwImuakrYCvDjHqp)=eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_settings_account()
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Save_session_acount(eOfgWoXNTdxsybtwImuakrYCvDjHqh,eOfgWoXNTdxsybtwImuakrYCvDjHqG,eOfgWoXNTdxsybtwImuakrYCvDjHqM,eOfgWoXNTdxsybtwImuakrYCvDjHqp)
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV['account']['token_limit']=eOfgWoXNTdxsybtwImuakrYCvDjHMQ.strftime('%Y%m%d')
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.JsonFile_Save(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_COOKIE_FILENAME,eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV)
 def cookiefile_check(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.JsonFile_Load(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_COOKIE_FILENAME)
  if eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV=={}:
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Init_TV_Total()
   return eOfgWoXNTdxsybtwImuakrYCvDjHpc
  (eOfgWoXNTdxsybtwImuakrYCvDjHMh,eOfgWoXNTdxsybtwImuakrYCvDjHMG,eOfgWoXNTdxsybtwImuakrYCvDjHMp,eOfgWoXNTdxsybtwImuakrYCvDjHMi)=eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_settings_account()
  (eOfgWoXNTdxsybtwImuakrYCvDjHME,eOfgWoXNTdxsybtwImuakrYCvDjHMR,eOfgWoXNTdxsybtwImuakrYCvDjHMB,eOfgWoXNTdxsybtwImuakrYCvDjHMA)=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Load_session_acount()
  if(eOfgWoXNTdxsybtwImuakrYCvDjHMh!=eOfgWoXNTdxsybtwImuakrYCvDjHME or eOfgWoXNTdxsybtwImuakrYCvDjHMG!=eOfgWoXNTdxsybtwImuakrYCvDjHMR or eOfgWoXNTdxsybtwImuakrYCvDjHMp!=eOfgWoXNTdxsybtwImuakrYCvDjHMB or eOfgWoXNTdxsybtwImuakrYCvDjHMi!=eOfgWoXNTdxsybtwImuakrYCvDjHMA)and eOfgWoXNTdxsybtwImuakrYCvDjHME!='xxxxx':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Init_TV_Total()
   return eOfgWoXNTdxsybtwImuakrYCvDjHpc
  if eOfgWoXNTdxsybtwImuakrYCvDjHpq(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>eOfgWoXNTdxsybtwImuakrYCvDjHpq(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV['account']['token_limit']):
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Init_TV_Total()
   return eOfgWoXNTdxsybtwImuakrYCvDjHpc
  return eOfgWoXNTdxsybtwImuakrYCvDjHpQ
 def tokenfile_check(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_TOKEN=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.JsonFile_Load(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_TOKEN_FILENAME)
  if eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_TOKEN=={}:
   return eOfgWoXNTdxsybtwImuakrYCvDjHpc
  if eOfgWoXNTdxsybtwImuakrYCvDjHpq(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>eOfgWoXNTdxsybtwImuakrYCvDjHpq(eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_TOKEN['token_date']):
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.TV_TOKEN={}
   return eOfgWoXNTdxsybtwImuakrYCvDjHpc
  return eOfgWoXNTdxsybtwImuakrYCvDjHpQ
 def get_reToken(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  if eOfgWoXNTdxsybtwImuakrYCvDjHUE.tokenfile_check()==eOfgWoXNTdxsybtwImuakrYCvDjHpc:
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Get_AccessToken()
 def dp_Global_Search(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHQV=eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('mode')
  if eOfgWoXNTdxsybtwImuakrYCvDjHQV=='TOTAL_SEARCH':
   eOfgWoXNTdxsybtwImuakrYCvDjHMF='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   eOfgWoXNTdxsybtwImuakrYCvDjHMF='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(eOfgWoXNTdxsybtwImuakrYCvDjHMF)
 def dp_Bookmark_Menu(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHMF='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(eOfgWoXNTdxsybtwImuakrYCvDjHMF)
 def dp_Apple_Group(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHMJ=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Get_AppleGroup_List()
  for eOfgWoXNTdxsybtwImuakrYCvDjHMS in eOfgWoXNTdxsybtwImuakrYCvDjHMJ:
   eOfgWoXNTdxsybtwImuakrYCvDjHMV =eOfgWoXNTdxsybtwImuakrYCvDjHMS.get('bandName')
   eOfgWoXNTdxsybtwImuakrYCvDjHMP =eOfgWoXNTdxsybtwImuakrYCvDjHMS.get('bandKey')
   eOfgWoXNTdxsybtwImuakrYCvDjHcp={'mediatype':'tvshow','title':eOfgWoXNTdxsybtwImuakrYCvDjHMV,'plot':'%s'%(eOfgWoXNTdxsybtwImuakrYCvDjHMP),}
   eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'BAND_VODLIST','bandKey':eOfgWoXNTdxsybtwImuakrYCvDjHMP,'page':'1','nextApiUrl':'-',}
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHMV,sublabel=eOfgWoXNTdxsybtwImuakrYCvDjHpl,img='',infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHcp,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK)
  if eOfgWoXNTdxsybtwImuakrYCvDjHpE(eOfgWoXNTdxsybtwImuakrYCvDjHMJ)>0:xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,cacheToDisc=eOfgWoXNTdxsybtwImuakrYCvDjHpc)
 def dp_Band_VodList(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHMP =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('bandKey') 
  eOfgWoXNTdxsybtwImuakrYCvDjHMz =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('bandGroup') 
  eOfgWoXNTdxsybtwImuakrYCvDjHMn =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('nextApiUrl')
  eOfgWoXNTdxsybtwImuakrYCvDjHML =''
  eOfgWoXNTdxsybtwImuakrYCvDjHqV =eOfgWoXNTdxsybtwImuakrYCvDjHpq(eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('page'))
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_log('bandKey    : {}'.format(eOfgWoXNTdxsybtwImuakrYCvDjHMP))
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_log('bandGroup  : {}'.format(eOfgWoXNTdxsybtwImuakrYCvDjHMz))
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_log('nextApiUrl : {}'.format(eOfgWoXNTdxsybtwImuakrYCvDjHMn))
  if eOfgWoXNTdxsybtwImuakrYCvDjHMz=='TVING_APPLE_HOUR':
   eOfgWoXNTdxsybtwImuakrYCvDjHcB,eOfgWoXNTdxsybtwImuakrYCvDjHMn=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Get_Apple_NowList()
  else:
   if eOfgWoXNTdxsybtwImuakrYCvDjHMz not in['',eOfgWoXNTdxsybtwImuakrYCvDjHpl]:
    eOfgWoXNTdxsybtwImuakrYCvDjHMP=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Get_bandCode_GroupCode(eOfgWoXNTdxsybtwImuakrYCvDjHMz)
    eOfgWoXNTdxsybtwImuakrYCvDjHUE.addon_log('new bandKey    : {}'.format(eOfgWoXNTdxsybtwImuakrYCvDjHMP))
   eOfgWoXNTdxsybtwImuakrYCvDjHcB,eOfgWoXNTdxsybtwImuakrYCvDjHMn=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Get_Band_VodList(eOfgWoXNTdxsybtwImuakrYCvDjHMP,eOfgWoXNTdxsybtwImuakrYCvDjHMn)
  for eOfgWoXNTdxsybtwImuakrYCvDjHcA in eOfgWoXNTdxsybtwImuakrYCvDjHcB:
   eOfgWoXNTdxsybtwImuakrYCvDjHlA =eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('title')
   eOfgWoXNTdxsybtwImuakrYCvDjHqL =eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('thumbnail')
   eOfgWoXNTdxsybtwImuakrYCvDjHQE =eOfgWoXNTdxsybtwImuakrYCvDjHcA.get('program')
   eOfgWoXNTdxsybtwImuakrYCvDjHcp={'mediatype':'tvshow' if not eOfgWoXNTdxsybtwImuakrYCvDjHQE.startswith('M')else 'movie','title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'plot':eOfgWoXNTdxsybtwImuakrYCvDjHlA+'\n'+'tvshow' if not eOfgWoXNTdxsybtwImuakrYCvDjHQE.startswith('M')else 'movie',}
   if not eOfgWoXNTdxsybtwImuakrYCvDjHQE.startswith('M'):
    eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'EPISODE','programcode':eOfgWoXNTdxsybtwImuakrYCvDjHQE,'page':'1',}
    eOfgWoXNTdxsybtwImuakrYCvDjHqU=eOfgWoXNTdxsybtwImuakrYCvDjHpQ
   else:
    eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'MOVIE','mediacode':eOfgWoXNTdxsybtwImuakrYCvDjHQE,'stype':'movie','title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'thumbnail':eOfgWoXNTdxsybtwImuakrYCvDjHqL,}
    eOfgWoXNTdxsybtwImuakrYCvDjHqU=eOfgWoXNTdxsybtwImuakrYCvDjHpc
   if eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_settings_makebookmark():
    eOfgWoXNTdxsybtwImuakrYCvDjHcJ={'videoid':eOfgWoXNTdxsybtwImuakrYCvDjHQE,'vidtype':'tvshow','vtitle':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'vsubtitle':eOfgWoXNTdxsybtwImuakrYCvDjHML,}
    eOfgWoXNTdxsybtwImuakrYCvDjHcS=json.dumps(eOfgWoXNTdxsybtwImuakrYCvDjHcJ)
    eOfgWoXNTdxsybtwImuakrYCvDjHcS=urllib.parse.quote(eOfgWoXNTdxsybtwImuakrYCvDjHcS)
    eOfgWoXNTdxsybtwImuakrYCvDjHcV='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(eOfgWoXNTdxsybtwImuakrYCvDjHcS)
    eOfgWoXNTdxsybtwImuakrYCvDjHcP=[('(통합) 찜 영상에 추가',eOfgWoXNTdxsybtwImuakrYCvDjHcV)]
   else:
    eOfgWoXNTdxsybtwImuakrYCvDjHcP=eOfgWoXNTdxsybtwImuakrYCvDjHpl
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel=eOfgWoXNTdxsybtwImuakrYCvDjHML,img=eOfgWoXNTdxsybtwImuakrYCvDjHqL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHcp,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHqU,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK,ContextMenu=eOfgWoXNTdxsybtwImuakrYCvDjHcP)
  if eOfgWoXNTdxsybtwImuakrYCvDjHMn not in[eOfgWoXNTdxsybtwImuakrYCvDjHpl,'','-']:
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['mode'] ='BAND_VODLIST' 
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['bandKey'] =eOfgWoXNTdxsybtwImuakrYCvDjHMP
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['nextApiUrl']=eOfgWoXNTdxsybtwImuakrYCvDjHMn
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['page'] =eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlA='[B]%s >>[/B]'%'다음 페이지'
   eOfgWoXNTdxsybtwImuakrYCvDjHci=eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel=eOfgWoXNTdxsybtwImuakrYCvDjHci,img=eOfgWoXNTdxsybtwImuakrYCvDjHlL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHpl,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK)
  xbmcplugin.setContent(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,cacheToDisc=eOfgWoXNTdxsybtwImuakrYCvDjHpc)
 def dp_Gn2_Program(eOfgWoXNTdxsybtwImuakrYCvDjHUE,eOfgWoXNTdxsybtwImuakrYCvDjHqS):
  eOfgWoXNTdxsybtwImuakrYCvDjHcE =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('genre')
  eOfgWoXNTdxsybtwImuakrYCvDjHqA =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('stype')
  eOfgWoXNTdxsybtwImuakrYCvDjHlR =eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('orderby')
  eOfgWoXNTdxsybtwImuakrYCvDjHqV=eOfgWoXNTdxsybtwImuakrYCvDjHpq(eOfgWoXNTdxsybtwImuakrYCvDjHqS.get('page'))
  eOfgWoXNTdxsybtwImuakrYCvDjHcB,eOfgWoXNTdxsybtwImuakrYCvDjHqz=eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.Gn2_Program_List(eOfgWoXNTdxsybtwImuakrYCvDjHcE,eOfgWoXNTdxsybtwImuakrYCvDjHlR,eOfgWoXNTdxsybtwImuakrYCvDjHqV)
  for eOfgWoXNTdxsybtwImuakrYCvDjHMK in eOfgWoXNTdxsybtwImuakrYCvDjHcB:
   eOfgWoXNTdxsybtwImuakrYCvDjHlA =eOfgWoXNTdxsybtwImuakrYCvDjHMK.get('title')
   eOfgWoXNTdxsybtwImuakrYCvDjHqL =eOfgWoXNTdxsybtwImuakrYCvDjHMK.get('thumbnail')
   eOfgWoXNTdxsybtwImuakrYCvDjHcp={'mediatype':eOfgWoXNTdxsybtwImuakrYCvDjHqA,'title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'plot':eOfgWoXNTdxsybtwImuakrYCvDjHlA,}
   if eOfgWoXNTdxsybtwImuakrYCvDjHqA=='movie':
    eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'MOVIE','mediacode':eOfgWoXNTdxsybtwImuakrYCvDjHMK.get('code'),'stype':eOfgWoXNTdxsybtwImuakrYCvDjHqA,'title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'thumbnail':eOfgWoXNTdxsybtwImuakrYCvDjHqL,}
    eOfgWoXNTdxsybtwImuakrYCvDjHqU=eOfgWoXNTdxsybtwImuakrYCvDjHpc
   else:
    eOfgWoXNTdxsybtwImuakrYCvDjHlK={'mode':'EPISODE','programcode':eOfgWoXNTdxsybtwImuakrYCvDjHMK.get('code'),'stype':eOfgWoXNTdxsybtwImuakrYCvDjHqA,'title':eOfgWoXNTdxsybtwImuakrYCvDjHlA,'thumbnail':eOfgWoXNTdxsybtwImuakrYCvDjHqL,'page':'1',}
    eOfgWoXNTdxsybtwImuakrYCvDjHqU=eOfgWoXNTdxsybtwImuakrYCvDjHpQ
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel='',img=eOfgWoXNTdxsybtwImuakrYCvDjHqL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHcp,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHqU,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK,ContextMenu=eOfgWoXNTdxsybtwImuakrYCvDjHpl)
  if eOfgWoXNTdxsybtwImuakrYCvDjHqz:
   eOfgWoXNTdxsybtwImuakrYCvDjHlK={}
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['mode'] ='GN2_LIST' 
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['orderby']=eOfgWoXNTdxsybtwImuakrYCvDjHlR
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['stype'] =eOfgWoXNTdxsybtwImuakrYCvDjHqA
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['genre'] =eOfgWoXNTdxsybtwImuakrYCvDjHcE
   eOfgWoXNTdxsybtwImuakrYCvDjHlK['page'] =eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlA='[B]%s >>[/B]'%'다음 페이지'
   eOfgWoXNTdxsybtwImuakrYCvDjHci=eOfgWoXNTdxsybtwImuakrYCvDjHpR(eOfgWoXNTdxsybtwImuakrYCvDjHqV+1)
   eOfgWoXNTdxsybtwImuakrYCvDjHlL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.add_dir(eOfgWoXNTdxsybtwImuakrYCvDjHlA,sublabel=eOfgWoXNTdxsybtwImuakrYCvDjHci,img=eOfgWoXNTdxsybtwImuakrYCvDjHlL,infoLabels=eOfgWoXNTdxsybtwImuakrYCvDjHpl,isFolder=eOfgWoXNTdxsybtwImuakrYCvDjHpQ,params=eOfgWoXNTdxsybtwImuakrYCvDjHlK)
  if eOfgWoXNTdxsybtwImuakrYCvDjHqA=='movie':
   xbmcplugin.setContent(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,'movies')
  else:
   xbmcplugin.setContent(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(eOfgWoXNTdxsybtwImuakrYCvDjHUE._addon_handle,cacheToDisc=eOfgWoXNTdxsybtwImuakrYCvDjHpc)
 def tving_main(eOfgWoXNTdxsybtwImuakrYCvDjHUE):
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.TvingObj.KodiVersion=eOfgWoXNTdxsybtwImuakrYCvDjHpq(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  eOfgWoXNTdxsybtwImuakrYCvDjHQV=eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params.get('mode',eOfgWoXNTdxsybtwImuakrYCvDjHpl)
  if eOfgWoXNTdxsybtwImuakrYCvDjHQV=='LOGOUT':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.logout()
   return
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.login_main()
  eOfgWoXNTdxsybtwImuakrYCvDjHUE.get_reToken()
  if eOfgWoXNTdxsybtwImuakrYCvDjHQV is eOfgWoXNTdxsybtwImuakrYCvDjHpl:
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Main_List()
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV in['LIVE_GROUP','DRAMA_GROUP','ENTER_GROUP','MOVIE_GROUP']:
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Title_Group(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV=='CHANNEL':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_LiveChannel_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV in['LIVE','VOD','MOVIE']:
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.play_VIDEO(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV=='PROGRAM':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Program_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV=='EPISODE':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Episode_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV=='SEARCH_GROUP':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Search_Group(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV in['SEARCH','LOCAL_SEARCH']:
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Search_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV=='WATCH':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Watch_List(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_History_Remove(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV=='ORDER_BY':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_setEpOrderby(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV=='SET_BOOKMARK':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Set_Bookmark(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV in['TOTAL_SEARCH','TOTAL_HISTORY']:
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Global_Search(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV=='SEARCH_HISTORY':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Search_History(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV=='MENU_BOOKMARK':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Bookmark_Menu(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV=='APPLE_GROUP':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Apple_Group(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV=='BAND_VODLIST':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Band_VodList(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  elif eOfgWoXNTdxsybtwImuakrYCvDjHQV=='GN2_LIST':
   eOfgWoXNTdxsybtwImuakrYCvDjHUE.dp_Gn2_Program(eOfgWoXNTdxsybtwImuakrYCvDjHUE.main_params)
  else:
   eOfgWoXNTdxsybtwImuakrYCvDjHpl
# Created by pyminifier (https://github.com/liftoff/pyminifier)
