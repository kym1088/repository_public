# -*- coding: utf-8 -*-
__author__ = "NightRain"

import xbmc, xbmcaddon, xbmcvfs
import os
import sys


ADDON_PATH = xbmcvfs.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
PROXY_PATH   = os.path.join( ADDON_PATH, 'resources', 'lib' )
sys.path.append( PROXY_PATH )

from tvingProxy import *


monitor = xbmc.Monitor()
proxyObj = TvingProxy()
xbmc.sleep(1000) # 1.0초
proxyObj.PORT = int( xbmcaddon.Addon().getSetting( 'proxyPort' ) )

proxyObj.start()
    
while not monitor.abortRequested():
	if monitor.waitForAbort(60): # 1분
		break


proxyObj.stop()


	
