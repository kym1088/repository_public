__author__="NightRain"
EVjAykFxCeQtSLhYNTvgMcsIDKlJOH=object
EVjAykFxCeQtSLhYNTvgMcsIDKlJOu=None
EVjAykFxCeQtSLhYNTvgMcsIDKlJOU=int
EVjAykFxCeQtSLhYNTvgMcsIDKlJOn=True
EVjAykFxCeQtSLhYNTvgMcsIDKlJOf=False
EVjAykFxCeQtSLhYNTvgMcsIDKlJOr=type
EVjAykFxCeQtSLhYNTvgMcsIDKlJOd=dict
EVjAykFxCeQtSLhYNTvgMcsIDKlJqo=getattr
EVjAykFxCeQtSLhYNTvgMcsIDKlJqz=list
EVjAykFxCeQtSLhYNTvgMcsIDKlJqX=len
EVjAykFxCeQtSLhYNTvgMcsIDKlJqm=str
EVjAykFxCeQtSLhYNTvgMcsIDKlJqG=range
EVjAykFxCeQtSLhYNTvgMcsIDKlJqb=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
EVjAykFxCeQtSLhYNTvgMcsIDKlJoX=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
EVjAykFxCeQtSLhYNTvgMcsIDKlJom=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
EVjAykFxCeQtSLhYNTvgMcsIDKlJoG=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
EVjAykFxCeQtSLhYNTvgMcsIDKlJob=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
EVjAykFxCeQtSLhYNTvgMcsIDKlJoa=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
EVjAykFxCeQtSLhYNTvgMcsIDKlJoO=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
EVjAykFxCeQtSLhYNTvgMcsIDKlJoq=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
EVjAykFxCeQtSLhYNTvgMcsIDKlJop={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
EVjAykFxCeQtSLhYNTvgMcsIDKlJoW =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
EVjAykFxCeQtSLhYNTvgMcsIDKlJoB=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class EVjAykFxCeQtSLhYNTvgMcsIDKlJoz(EVjAykFxCeQtSLhYNTvgMcsIDKlJOH):
 def __init__(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJow,EVjAykFxCeQtSLhYNTvgMcsIDKlJoP,EVjAykFxCeQtSLhYNTvgMcsIDKlJoR):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_url =EVjAykFxCeQtSLhYNTvgMcsIDKlJow
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle=EVjAykFxCeQtSLhYNTvgMcsIDKlJoP
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params =EVjAykFxCeQtSLhYNTvgMcsIDKlJoR
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxeh() 
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream.mpd'))
 def addon_noti(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,sting):
  try:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJou=xbmcgui.Dialog()
   EVjAykFxCeQtSLhYNTvgMcsIDKlJou.notification(__addonname__,sting)
  except:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
 def addon_log(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,string):
  try:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoU=string.encode('utf-8','ignore')
  except:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoU='addonException: addon_log'
  EVjAykFxCeQtSLhYNTvgMcsIDKlJon=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,EVjAykFxCeQtSLhYNTvgMcsIDKlJoU),level=EVjAykFxCeQtSLhYNTvgMcsIDKlJon)
 def get_keyboard_input(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJzR):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJof=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
  kb=xbmc.Keyboard()
  kb.setHeading(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   EVjAykFxCeQtSLhYNTvgMcsIDKlJof=kb.getText()
  return EVjAykFxCeQtSLhYNTvgMcsIDKlJof
 def get_settings_account(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJor =__addon__.getSetting('id')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJod =__addon__.getSetting('pw')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzo =__addon__.getSetting('login_type')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzX=EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(__addon__.getSetting('selected_profile'))
  return(EVjAykFxCeQtSLhYNTvgMcsIDKlJor,EVjAykFxCeQtSLhYNTvgMcsIDKlJod,EVjAykFxCeQtSLhYNTvgMcsIDKlJzo,EVjAykFxCeQtSLhYNTvgMcsIDKlJzX)
 def get_settings_uhd(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  return EVjAykFxCeQtSLhYNTvgMcsIDKlJOn if __addon__.getSetting('active_uhd')=='true' else EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
 def get_settings_playback(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzm={'active_uhd':EVjAykFxCeQtSLhYNTvgMcsIDKlJOn if __addon__.getSetting('active_uhd')=='true' else EVjAykFxCeQtSLhYNTvgMcsIDKlJOf,'streamFilename':EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.TV_STREAM_FILENAME,}
  return EVjAykFxCeQtSLhYNTvgMcsIDKlJzm
 def get_settings_proxyport(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzG =EVjAykFxCeQtSLhYNTvgMcsIDKlJOn if __addon__.getSetting('proxyYn')=='true' else EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzb=EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(__addon__.getSetting('proxyPort'))
  return EVjAykFxCeQtSLhYNTvgMcsIDKlJzG,EVjAykFxCeQtSLhYNTvgMcsIDKlJzb
 def get_settings_totalsearch(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJza =EVjAykFxCeQtSLhYNTvgMcsIDKlJOn if __addon__.getSetting('local_search')=='true' else EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzO=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn if __addon__.getSetting('local_history')=='true' else EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzq =EVjAykFxCeQtSLhYNTvgMcsIDKlJOn if __addon__.getSetting('total_search')=='true' else EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzp=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn if __addon__.getSetting('total_history')=='true' else EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzW=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn if __addon__.getSetting('menu_bookmark')=='true' else EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
  return(EVjAykFxCeQtSLhYNTvgMcsIDKlJza,EVjAykFxCeQtSLhYNTvgMcsIDKlJzO,EVjAykFxCeQtSLhYNTvgMcsIDKlJzq,EVjAykFxCeQtSLhYNTvgMcsIDKlJzp,EVjAykFxCeQtSLhYNTvgMcsIDKlJzW)
 def get_settings_makebookmark(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  return EVjAykFxCeQtSLhYNTvgMcsIDKlJOn if __addon__.getSetting('make_bookmark')=='true' else EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
 def get_settings_direct_replay(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzB=EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(__addon__.getSetting('direct_replay'))
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJzB==0:
   return EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
  else:
   return EVjAykFxCeQtSLhYNTvgMcsIDKlJOn
 def set_winEpisodeOrderby(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJzw):
  __addon__.setSetting('tving_orderby',EVjAykFxCeQtSLhYNTvgMcsIDKlJzw)
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzi=xbmcgui.Window(10000)
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzi.setProperty('TVING_M_ORDERBY',EVjAykFxCeQtSLhYNTvgMcsIDKlJzw)
 def get_winEpisodeOrderby(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzw=__addon__.getSetting('tving_orderby')
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJzw in['',EVjAykFxCeQtSLhYNTvgMcsIDKlJOu]:EVjAykFxCeQtSLhYNTvgMcsIDKlJzw='desc'
  return EVjAykFxCeQtSLhYNTvgMcsIDKlJzw
 def add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,label,sublabel='',img='',infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params='',isLink=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf,ContextMenu=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzP='%s?%s'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_url,urllib.parse.urlencode(params))
  if sublabel:EVjAykFxCeQtSLhYNTvgMcsIDKlJzR='%s < %s >'%(label,sublabel)
  else: EVjAykFxCeQtSLhYNTvgMcsIDKlJzR=label
  if not img:img='DefaultFolder.png'
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzH=xbmcgui.ListItem(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJOr(img)==EVjAykFxCeQtSLhYNTvgMcsIDKlJOd:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzH.setArt(img)
  else:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzH.setArt({'thumb':img,'poster':img})
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.KodiVersion>=20:
   if infoLabels:EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.Set_InfoTag(EVjAykFxCeQtSLhYNTvgMcsIDKlJzH.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:EVjAykFxCeQtSLhYNTvgMcsIDKlJzH.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzH.setProperty('IsPlayable','true')
  if ContextMenu:EVjAykFxCeQtSLhYNTvgMcsIDKlJzH.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,EVjAykFxCeQtSLhYNTvgMcsIDKlJzP,EVjAykFxCeQtSLhYNTvgMcsIDKlJzH,isFolder)
 def get_selQuality(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,etype):
  try:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzu='selected_quality'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzU=[1080,720,480,360]
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzn=EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(__addon__.getSetting(EVjAykFxCeQtSLhYNTvgMcsIDKlJzu))
   return EVjAykFxCeQtSLhYNTvgMcsIDKlJzU[EVjAykFxCeQtSLhYNTvgMcsIDKlJzn]
  except:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
  return 720 
 def Set_InfoTag(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,video_InfoTag:xbmc.InfoTagVideo,EVjAykFxCeQtSLhYNTvgMcsIDKlJXb):
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJzf,value in EVjAykFxCeQtSLhYNTvgMcsIDKlJXb.items():
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJop[EVjAykFxCeQtSLhYNTvgMcsIDKlJzf]['type']=='string':
    EVjAykFxCeQtSLhYNTvgMcsIDKlJqo(video_InfoTag,EVjAykFxCeQtSLhYNTvgMcsIDKlJop[EVjAykFxCeQtSLhYNTvgMcsIDKlJzf]['func'])(value)
   elif EVjAykFxCeQtSLhYNTvgMcsIDKlJop[EVjAykFxCeQtSLhYNTvgMcsIDKlJzf]['type']=='int':
    if EVjAykFxCeQtSLhYNTvgMcsIDKlJOr(value)==EVjAykFxCeQtSLhYNTvgMcsIDKlJOU:
     EVjAykFxCeQtSLhYNTvgMcsIDKlJzr=EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(value)
    else:
     EVjAykFxCeQtSLhYNTvgMcsIDKlJzr=0
    EVjAykFxCeQtSLhYNTvgMcsIDKlJqo(video_InfoTag,EVjAykFxCeQtSLhYNTvgMcsIDKlJop[EVjAykFxCeQtSLhYNTvgMcsIDKlJzf]['func'])(EVjAykFxCeQtSLhYNTvgMcsIDKlJzr)
   elif EVjAykFxCeQtSLhYNTvgMcsIDKlJop[EVjAykFxCeQtSLhYNTvgMcsIDKlJzf]['type']=='actor':
    if value!=[]:
     EVjAykFxCeQtSLhYNTvgMcsIDKlJqo(video_InfoTag,EVjAykFxCeQtSLhYNTvgMcsIDKlJop[EVjAykFxCeQtSLhYNTvgMcsIDKlJzf]['func'])([xbmc.Actor(name)for name in value])
   elif EVjAykFxCeQtSLhYNTvgMcsIDKlJop[EVjAykFxCeQtSLhYNTvgMcsIDKlJzf]['type']=='list':
    if EVjAykFxCeQtSLhYNTvgMcsIDKlJOr(value)==EVjAykFxCeQtSLhYNTvgMcsIDKlJqz:
     EVjAykFxCeQtSLhYNTvgMcsIDKlJqo(video_InfoTag,EVjAykFxCeQtSLhYNTvgMcsIDKlJop[EVjAykFxCeQtSLhYNTvgMcsIDKlJzf]['func'])(value)
    else:
     EVjAykFxCeQtSLhYNTvgMcsIDKlJqo(video_InfoTag,EVjAykFxCeQtSLhYNTvgMcsIDKlJop[EVjAykFxCeQtSLhYNTvgMcsIDKlJzf]['func'])([value])
 def dp_Main_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  (EVjAykFxCeQtSLhYNTvgMcsIDKlJza,EVjAykFxCeQtSLhYNTvgMcsIDKlJzO,EVjAykFxCeQtSLhYNTvgMcsIDKlJzq,EVjAykFxCeQtSLhYNTvgMcsIDKlJzp,EVjAykFxCeQtSLhYNTvgMcsIDKlJzW)=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_totalsearch()
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJzd in EVjAykFxCeQtSLhYNTvgMcsIDKlJoX:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR=EVjAykFxCeQtSLhYNTvgMcsIDKlJzd.get('title')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXo=''
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJzd.get('mode')=='SEARCH_GROUP' and EVjAykFxCeQtSLhYNTvgMcsIDKlJza ==EVjAykFxCeQtSLhYNTvgMcsIDKlJOf:continue
   elif EVjAykFxCeQtSLhYNTvgMcsIDKlJzd.get('mode')=='SEARCH_HISTORY' and EVjAykFxCeQtSLhYNTvgMcsIDKlJzO==EVjAykFxCeQtSLhYNTvgMcsIDKlJOf:continue
   elif EVjAykFxCeQtSLhYNTvgMcsIDKlJzd.get('mode')=='TOTAL_SEARCH' and EVjAykFxCeQtSLhYNTvgMcsIDKlJzq ==EVjAykFxCeQtSLhYNTvgMcsIDKlJOf:continue
   elif EVjAykFxCeQtSLhYNTvgMcsIDKlJzd.get('mode')=='TOTAL_HISTORY' and EVjAykFxCeQtSLhYNTvgMcsIDKlJzp==EVjAykFxCeQtSLhYNTvgMcsIDKlJOf:continue
   elif EVjAykFxCeQtSLhYNTvgMcsIDKlJzd.get('mode')=='MENU_BOOKMARK' and EVjAykFxCeQtSLhYNTvgMcsIDKlJzW==EVjAykFxCeQtSLhYNTvgMcsIDKlJOf:continue
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':EVjAykFxCeQtSLhYNTvgMcsIDKlJzd.get('mode'),'stype':EVjAykFxCeQtSLhYNTvgMcsIDKlJzd.get('stype'),'orderby':EVjAykFxCeQtSLhYNTvgMcsIDKlJzd.get('orderby'),'ordernm':EVjAykFxCeQtSLhYNTvgMcsIDKlJzd.get('ordernm'),'page':'1'}
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJzd.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXm=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXG =EVjAykFxCeQtSLhYNTvgMcsIDKlJOn
   else:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXm=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXG =EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXb={'title':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'plot':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR}
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJzd.get('mode')=='XXX':EVjAykFxCeQtSLhYNTvgMcsIDKlJXb=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
   if 'icon' in EVjAykFxCeQtSLhYNTvgMcsIDKlJzd:EVjAykFxCeQtSLhYNTvgMcsIDKlJXo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',EVjAykFxCeQtSLhYNTvgMcsIDKlJzd.get('icon')) 
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel='',img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXo,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJXb,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJXm,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz,isLink=EVjAykFxCeQtSLhYNTvgMcsIDKlJXG)
  xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle)
 def login_main(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  (EVjAykFxCeQtSLhYNTvgMcsIDKlJXO,EVjAykFxCeQtSLhYNTvgMcsIDKlJXq,EVjAykFxCeQtSLhYNTvgMcsIDKlJXp,EVjAykFxCeQtSLhYNTvgMcsIDKlJXW)=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_account()
  if not(EVjAykFxCeQtSLhYNTvgMcsIDKlJXO and EVjAykFxCeQtSLhYNTvgMcsIDKlJXq):
   EVjAykFxCeQtSLhYNTvgMcsIDKlJou=xbmcgui.Dialog()
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXB=EVjAykFxCeQtSLhYNTvgMcsIDKlJou.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJXB==EVjAykFxCeQtSLhYNTvgMcsIDKlJOn:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXi=0
   while EVjAykFxCeQtSLhYNTvgMcsIDKlJOn:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXi+=1
    time.sleep(0.05)
    if EVjAykFxCeQtSLhYNTvgMcsIDKlJXi>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXw=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.GetCredential(EVjAykFxCeQtSLhYNTvgMcsIDKlJXO,EVjAykFxCeQtSLhYNTvgMcsIDKlJXq,EVjAykFxCeQtSLhYNTvgMcsIDKlJXp,EVjAykFxCeQtSLhYNTvgMcsIDKlJXW)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXw:EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXw==EVjAykFxCeQtSLhYNTvgMcsIDKlJOf:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXP=EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('stype')
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXP=='live':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXR=EVjAykFxCeQtSLhYNTvgMcsIDKlJom
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJXP=='vod':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXR=EVjAykFxCeQtSLhYNTvgMcsIDKlJoa
  else:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXR=EVjAykFxCeQtSLhYNTvgMcsIDKlJoO
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJXH in EVjAykFxCeQtSLhYNTvgMcsIDKlJXR:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR=EVjAykFxCeQtSLhYNTvgMcsIDKlJXH.get('title')
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('ordernm')!='-':
    EVjAykFxCeQtSLhYNTvgMcsIDKlJzR+='  ('+EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('ordernm')+')'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':EVjAykFxCeQtSLhYNTvgMcsIDKlJXH.get('mode'),'stype':EVjAykFxCeQtSLhYNTvgMcsIDKlJXH.get('stype'),'orderby':EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('orderby'),'ordernm':EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('ordernm'),'page':'1'}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel='',img='',infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJqX(EVjAykFxCeQtSLhYNTvgMcsIDKlJXR)>0:xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle)
 def dp_SubTitle_Group(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu): 
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJXH in EVjAykFxCeQtSLhYNTvgMcsIDKlJoq:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR=EVjAykFxCeQtSLhYNTvgMcsIDKlJXH.get('title')
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('ordernm')!='-':
    EVjAykFxCeQtSLhYNTvgMcsIDKlJzR+='  ('+EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('ordernm')+')'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':EVjAykFxCeQtSLhYNTvgMcsIDKlJXH.get('mode'),'genreCode':EVjAykFxCeQtSLhYNTvgMcsIDKlJXH.get('genreCode'),'stype':EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('stype'),'orderby':EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('orderby'),'page':'1'}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel='',img='',infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJqX(EVjAykFxCeQtSLhYNTvgMcsIDKlJoq)>0:xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle)
 def dp_LiveChannel_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXP =EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('stype')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXU =EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('page'))
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXn,EVjAykFxCeQtSLhYNTvgMcsIDKlJXf=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.GetLiveChannelList(EVjAykFxCeQtSLhYNTvgMcsIDKlJXP,EVjAykFxCeQtSLhYNTvgMcsIDKlJXU)
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJXr in EVjAykFxCeQtSLhYNTvgMcsIDKlJXn:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('title')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXa =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('channel')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXd =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('thumbnail')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmo =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('synopsis')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmz =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('channelepg')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmX =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('cast')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmG =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('director')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmb =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('info_genre')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJma =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('year')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmO =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('mpaa')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmq =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('premiered')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmp={'mediatype':'episode','title':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'studio':EVjAykFxCeQtSLhYNTvgMcsIDKlJXa,'cast':EVjAykFxCeQtSLhYNTvgMcsIDKlJmX,'director':EVjAykFxCeQtSLhYNTvgMcsIDKlJmG,'genre':EVjAykFxCeQtSLhYNTvgMcsIDKlJmb,'plot':'%s\n%s\n%s\n\n%s'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJXa,EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,EVjAykFxCeQtSLhYNTvgMcsIDKlJmz,EVjAykFxCeQtSLhYNTvgMcsIDKlJmo),'year':EVjAykFxCeQtSLhYNTvgMcsIDKlJma,'mpaa':EVjAykFxCeQtSLhYNTvgMcsIDKlJmO,'premiered':EVjAykFxCeQtSLhYNTvgMcsIDKlJmq}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'LIVE','mediacode':EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('mediacode'),'stype':EVjAykFxCeQtSLhYNTvgMcsIDKlJXP}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJXa,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXd,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJmp,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXf:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['mode']='CHANNEL' 
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['stype']=EVjAykFxCeQtSLhYNTvgMcsIDKlJXP 
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['page']=EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR='[B]%s >>[/B]'%'다음 페이지'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmW=EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJmW,img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXo,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJqX(EVjAykFxCeQtSLhYNTvgMcsIDKlJXn)>0:xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,cacheToDisc=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf)
 def dp_Program_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJmB =EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('stype')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzw =EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('orderby')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXU =EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('page'))
  EVjAykFxCeQtSLhYNTvgMcsIDKlJmi=EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('genreCode')
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJmi==EVjAykFxCeQtSLhYNTvgMcsIDKlJOu:EVjAykFxCeQtSLhYNTvgMcsIDKlJmi='all'
  EVjAykFxCeQtSLhYNTvgMcsIDKlJmw,EVjAykFxCeQtSLhYNTvgMcsIDKlJXf=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.GetProgramList(EVjAykFxCeQtSLhYNTvgMcsIDKlJmB,EVjAykFxCeQtSLhYNTvgMcsIDKlJzw,EVjAykFxCeQtSLhYNTvgMcsIDKlJXU,EVjAykFxCeQtSLhYNTvgMcsIDKlJmi)
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJmP in EVjAykFxCeQtSLhYNTvgMcsIDKlJmw:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('title')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXd =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('thumbnail')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmo =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('synopsis')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmR =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('channel')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmX =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('cast')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmG =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('director')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmb=EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('info_genre')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJma =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('year')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmq =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('premiered')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmO =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('mpaa')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmp={'mediatype':'tvshow','title':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'studio':EVjAykFxCeQtSLhYNTvgMcsIDKlJmR,'cast':EVjAykFxCeQtSLhYNTvgMcsIDKlJmX,'director':EVjAykFxCeQtSLhYNTvgMcsIDKlJmG,'genre':EVjAykFxCeQtSLhYNTvgMcsIDKlJmb,'year':EVjAykFxCeQtSLhYNTvgMcsIDKlJma,'premiered':EVjAykFxCeQtSLhYNTvgMcsIDKlJmq,'mpaa':EVjAykFxCeQtSLhYNTvgMcsIDKlJmO,'plot':EVjAykFxCeQtSLhYNTvgMcsIDKlJmo}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'EPISODE','programcode':EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('program'),'page':'1'}
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_makebookmark():
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmH={'videoid':EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('program'),'vidtype':'tvshow','vtitle':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'vsubtitle':EVjAykFxCeQtSLhYNTvgMcsIDKlJmR,}
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmu=json.dumps(EVjAykFxCeQtSLhYNTvgMcsIDKlJmH)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmu=urllib.parse.quote(EVjAykFxCeQtSLhYNTvgMcsIDKlJmu)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmU='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJmu)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmn=[('(통합) 찜 영상에 추가',EVjAykFxCeQtSLhYNTvgMcsIDKlJmU)]
   else:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmn=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJmR,img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXd,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJmp,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz,ContextMenu=EVjAykFxCeQtSLhYNTvgMcsIDKlJmn)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXf:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['mode'] ='PROGRAM' 
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['stype'] =EVjAykFxCeQtSLhYNTvgMcsIDKlJmB
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['orderby'] =EVjAykFxCeQtSLhYNTvgMcsIDKlJzw
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['page'] =EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['genreCode']=EVjAykFxCeQtSLhYNTvgMcsIDKlJmi 
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR='[B]%s >>[/B]'%'다음 페이지'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmW=EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJmW,img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXo,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  xbmcplugin.setContent(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,cacheToDisc=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf)
 def dp_4K_Program_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXU =EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('page'))
  EVjAykFxCeQtSLhYNTvgMcsIDKlJmw,EVjAykFxCeQtSLhYNTvgMcsIDKlJXf=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.Get_UHD_ProgramList(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU)
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJmP in EVjAykFxCeQtSLhYNTvgMcsIDKlJmw:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('title')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXd =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('thumbnail')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmo =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('synopsis')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmR =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('channel')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmX =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('cast')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmG =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('director')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmb=EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('info_genre')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJma =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('year')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmq =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('premiered')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmO =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('mpaa')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmp={'mediatype':'tvshow','title':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'studio':EVjAykFxCeQtSLhYNTvgMcsIDKlJmR,'cast':EVjAykFxCeQtSLhYNTvgMcsIDKlJmX,'director':EVjAykFxCeQtSLhYNTvgMcsIDKlJmG,'genre':EVjAykFxCeQtSLhYNTvgMcsIDKlJmb,'year':EVjAykFxCeQtSLhYNTvgMcsIDKlJma,'premiered':EVjAykFxCeQtSLhYNTvgMcsIDKlJmq,'mpaa':EVjAykFxCeQtSLhYNTvgMcsIDKlJmO,'plot':EVjAykFxCeQtSLhYNTvgMcsIDKlJmo}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'EPISODE','programcode':EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('program'),'page':'1'}
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_makebookmark():
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmH={'videoid':EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('program'),'vidtype':'tvshow','vtitle':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'vsubtitle':EVjAykFxCeQtSLhYNTvgMcsIDKlJmR,}
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmu=json.dumps(EVjAykFxCeQtSLhYNTvgMcsIDKlJmH)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmu=urllib.parse.quote(EVjAykFxCeQtSLhYNTvgMcsIDKlJmu)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmU='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJmu)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmn=[('(통합) 찜 영상에 추가',EVjAykFxCeQtSLhYNTvgMcsIDKlJmU)]
   else:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmn=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJmR,img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXd,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJmp,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz,ContextMenu=EVjAykFxCeQtSLhYNTvgMcsIDKlJmn)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXf:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['mode'] ='4K_PROGRAM' 
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['page'] =EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR='[B]%s >>[/B]'%'다음 페이지'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmW=EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJmW,img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXo,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  xbmcplugin.setContent(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,cacheToDisc=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf)
 def dp_Ori_Program_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXU =EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('page'))
  EVjAykFxCeQtSLhYNTvgMcsIDKlJmw,EVjAykFxCeQtSLhYNTvgMcsIDKlJXf=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.Get_Origianl_ProgramList(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU)
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJmP in EVjAykFxCeQtSLhYNTvgMcsIDKlJmw:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('title')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXd =EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('thumbnail')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmp={'mediatype':'tvshow','title':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'EPISODE','programcode':EVjAykFxCeQtSLhYNTvgMcsIDKlJmP.get('program'),'page':'1',}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXd,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJmp,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz,ContextMenu=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXf:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['mode'] ='ORI_PROGRAM' 
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['page'] =EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR='[B]%s >>[/B]'%'다음 페이지'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmW=EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJmW,img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXo,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  xbmcplugin.setContent(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,cacheToDisc=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf)
 def dp_Episode_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJmr=EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('programcode')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXU =EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('page'))
  EVjAykFxCeQtSLhYNTvgMcsIDKlJmd,EVjAykFxCeQtSLhYNTvgMcsIDKlJXf,EVjAykFxCeQtSLhYNTvgMcsIDKlJGo=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.GetEpisodeList(EVjAykFxCeQtSLhYNTvgMcsIDKlJmr,EVjAykFxCeQtSLhYNTvgMcsIDKlJXU,orderby=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_winEpisodeOrderby())
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJGz in EVjAykFxCeQtSLhYNTvgMcsIDKlJmd:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR =EVjAykFxCeQtSLhYNTvgMcsIDKlJGz.get('title')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmW =EVjAykFxCeQtSLhYNTvgMcsIDKlJGz.get('subtitle')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXd =EVjAykFxCeQtSLhYNTvgMcsIDKlJGz.get('thumbnail')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmo =EVjAykFxCeQtSLhYNTvgMcsIDKlJGz.get('synopsis')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGX=EVjAykFxCeQtSLhYNTvgMcsIDKlJGz.get('info_title')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGm =EVjAykFxCeQtSLhYNTvgMcsIDKlJGz.get('aired')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGb =EVjAykFxCeQtSLhYNTvgMcsIDKlJGz.get('studio')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGa =EVjAykFxCeQtSLhYNTvgMcsIDKlJGz.get('frequency')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmp={'mediatype':'episode','title':EVjAykFxCeQtSLhYNTvgMcsIDKlJGX,'aired':EVjAykFxCeQtSLhYNTvgMcsIDKlJGm,'studio':EVjAykFxCeQtSLhYNTvgMcsIDKlJGb,'episode':EVjAykFxCeQtSLhYNTvgMcsIDKlJGa,'plot':EVjAykFxCeQtSLhYNTvgMcsIDKlJmo}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'VOD','mediacode':EVjAykFxCeQtSLhYNTvgMcsIDKlJGz.get('episode'),'stype':'vod','programcode':EVjAykFxCeQtSLhYNTvgMcsIDKlJmr,'title':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'thumbnail':EVjAykFxCeQtSLhYNTvgMcsIDKlJXd}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJmW,img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXd,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJmp,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXU==1:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmp={'plot':'정렬순서를 변경합니다.'}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['mode'] ='ORDER_BY' 
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_winEpisodeOrderby()=='desc':
    EVjAykFxCeQtSLhYNTvgMcsIDKlJzR='정렬순서변경 : 최신화부터 -> 1회부터'
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['orderby']='asc'
   else:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJzR='정렬순서변경 : 1회부터 -> 최신화부터'
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['orderby']='desc'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel='',img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXo,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJmp,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz,isLink=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXf:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['mode'] ='EPISODE' 
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['programcode']=EVjAykFxCeQtSLhYNTvgMcsIDKlJmr
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['page'] =EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR='[B]%s >>[/B]'%'다음 페이지'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmW=EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJmW,img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXo,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  xbmcplugin.setContent(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,'episodes')
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJqX(EVjAykFxCeQtSLhYNTvgMcsIDKlJmd)>0:xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,cacheToDisc=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn)
 def dp_setEpOrderby(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzw =EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('orderby')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.set_winEpisodeOrderby(EVjAykFxCeQtSLhYNTvgMcsIDKlJzw)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJmB =EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('stype')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzw =EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('orderby')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXU=EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('page'))
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGO,EVjAykFxCeQtSLhYNTvgMcsIDKlJXf=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.GetMovieList(EVjAykFxCeQtSLhYNTvgMcsIDKlJmB,EVjAykFxCeQtSLhYNTvgMcsIDKlJzw,EVjAykFxCeQtSLhYNTvgMcsIDKlJXU)
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJGq in EVjAykFxCeQtSLhYNTvgMcsIDKlJGO:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('title')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXd =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('thumbnail')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmo =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('synopsis')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGX =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('info_title')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJma =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('year')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmX =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('cast')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmG =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('director')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmb =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('info_genre')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGp =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('duration')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmq =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('premiered')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGb =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('studio')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmO =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('mpaa')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmp={'mediatype':'movie','title':EVjAykFxCeQtSLhYNTvgMcsIDKlJGX,'year':EVjAykFxCeQtSLhYNTvgMcsIDKlJma,'cast':EVjAykFxCeQtSLhYNTvgMcsIDKlJmX,'director':EVjAykFxCeQtSLhYNTvgMcsIDKlJmG,'genre':EVjAykFxCeQtSLhYNTvgMcsIDKlJmb,'duration':EVjAykFxCeQtSLhYNTvgMcsIDKlJGp,'premiered':EVjAykFxCeQtSLhYNTvgMcsIDKlJmq,'studio':EVjAykFxCeQtSLhYNTvgMcsIDKlJGb,'mpaa':EVjAykFxCeQtSLhYNTvgMcsIDKlJmO,'plot':EVjAykFxCeQtSLhYNTvgMcsIDKlJmo}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'MOVIE','mediacode':EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('moviecode'),'stype':'movie','title':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'thumbnail':EVjAykFxCeQtSLhYNTvgMcsIDKlJXd}
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_makebookmark():
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmH={'videoid':EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('moviecode'),'vidtype':'movie','vtitle':EVjAykFxCeQtSLhYNTvgMcsIDKlJGX,'vsubtitle':'',}
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmu=json.dumps(EVjAykFxCeQtSLhYNTvgMcsIDKlJmH)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmu=urllib.parse.quote(EVjAykFxCeQtSLhYNTvgMcsIDKlJmu)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmU='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJmu)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmn=[('(통합) 찜 영상에 추가',EVjAykFxCeQtSLhYNTvgMcsIDKlJmU)]
   else:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmn=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel='',img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXd,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJmp,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz,ContextMenu=EVjAykFxCeQtSLhYNTvgMcsIDKlJmn)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXf:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['mode'] ='MOVIE_SUB' 
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['orderby']=EVjAykFxCeQtSLhYNTvgMcsIDKlJzw
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['stype'] =EVjAykFxCeQtSLhYNTvgMcsIDKlJmB
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['page'] =EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR='[B]%s >>[/B]'%'다음 페이지'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmW=EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJmW,img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXo,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  xbmcplugin.setContent(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,'movies')
  xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,cacheToDisc=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf)
 def dp_4K_Movie_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXU=EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('page'))
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGO,EVjAykFxCeQtSLhYNTvgMcsIDKlJXf=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.Get_UHD_MovieList(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU)
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJGq in EVjAykFxCeQtSLhYNTvgMcsIDKlJGO:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('title')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXd =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('thumbnail')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmo =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('synopsis')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGX =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('info_title')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJma =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('year')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmX =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('cast')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmG =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('director')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmb =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('info_genre')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGp =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('duration')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmq =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('premiered')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGb =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('studio')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmO =EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('mpaa')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmp={'mediatype':'movie','title':EVjAykFxCeQtSLhYNTvgMcsIDKlJGX,'year':EVjAykFxCeQtSLhYNTvgMcsIDKlJma,'cast':EVjAykFxCeQtSLhYNTvgMcsIDKlJmX,'director':EVjAykFxCeQtSLhYNTvgMcsIDKlJmG,'genre':EVjAykFxCeQtSLhYNTvgMcsIDKlJmb,'duration':EVjAykFxCeQtSLhYNTvgMcsIDKlJGp,'premiered':EVjAykFxCeQtSLhYNTvgMcsIDKlJmq,'studio':EVjAykFxCeQtSLhYNTvgMcsIDKlJGb,'mpaa':EVjAykFxCeQtSLhYNTvgMcsIDKlJmO,'plot':EVjAykFxCeQtSLhYNTvgMcsIDKlJmo}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'MOVIE','mediacode':EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('moviecode'),'stype':'movie','title':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'thumbnail':EVjAykFxCeQtSLhYNTvgMcsIDKlJXd}
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_makebookmark():
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmH={'videoid':EVjAykFxCeQtSLhYNTvgMcsIDKlJGq.get('moviecode'),'vidtype':'movie','vtitle':EVjAykFxCeQtSLhYNTvgMcsIDKlJGX,'vsubtitle':'',}
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmu=json.dumps(EVjAykFxCeQtSLhYNTvgMcsIDKlJmH)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmu=urllib.parse.quote(EVjAykFxCeQtSLhYNTvgMcsIDKlJmu)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmU='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJmu)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmn=[('(통합) 찜 영상에 추가',EVjAykFxCeQtSLhYNTvgMcsIDKlJmU)]
   else:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmn=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel='',img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXd,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJmp,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz,ContextMenu=EVjAykFxCeQtSLhYNTvgMcsIDKlJmn)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXf:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['mode'] ='4K_MOVIE' 
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['page'] =EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR='[B]%s >>[/B]'%'다음 페이지'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmW=EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJmW,img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXo,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  xbmcplugin.setContent(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,'movies')
  xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,cacheToDisc=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf)
 def dp_Set_Bookmark(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGW=urllib.parse.unquote(EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('bm_param'))
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGW=json.loads(EVjAykFxCeQtSLhYNTvgMcsIDKlJGW)
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGB =EVjAykFxCeQtSLhYNTvgMcsIDKlJGW.get('videoid')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGi =EVjAykFxCeQtSLhYNTvgMcsIDKlJGW.get('vidtype')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGw =EVjAykFxCeQtSLhYNTvgMcsIDKlJGW.get('vtitle')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGP =EVjAykFxCeQtSLhYNTvgMcsIDKlJGW.get('vsubtitle')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJou=xbmcgui.Dialog()
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXB=EVjAykFxCeQtSLhYNTvgMcsIDKlJou.yesno(__language__(30913).encode('utf8'),EVjAykFxCeQtSLhYNTvgMcsIDKlJGw+' \n\n'+__language__(30914))
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXB==EVjAykFxCeQtSLhYNTvgMcsIDKlJOf:return
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGR=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.GetBookmarkInfo(EVjAykFxCeQtSLhYNTvgMcsIDKlJGB,EVjAykFxCeQtSLhYNTvgMcsIDKlJGi)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJGP!='':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGR['saveinfo']['subtitle']=EVjAykFxCeQtSLhYNTvgMcsIDKlJGP 
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJGi=='tvshow':EVjAykFxCeQtSLhYNTvgMcsIDKlJGR['saveinfo']['infoLabels']['studio']=EVjAykFxCeQtSLhYNTvgMcsIDKlJGP 
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGH=json.dumps(EVjAykFxCeQtSLhYNTvgMcsIDKlJGR)
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGH=urllib.parse.quote(EVjAykFxCeQtSLhYNTvgMcsIDKlJGH)
  EVjAykFxCeQtSLhYNTvgMcsIDKlJmU ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJGH)
  xbmc.executebuiltin(EVjAykFxCeQtSLhYNTvgMcsIDKlJmU)
 def dp_Search_Group(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  if 'search_key' in EVjAykFxCeQtSLhYNTvgMcsIDKlJXu:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGu=EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('search_key')
  else:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGu=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not EVjAykFxCeQtSLhYNTvgMcsIDKlJGu:
    return
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJXH in EVjAykFxCeQtSLhYNTvgMcsIDKlJob:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGU =EVjAykFxCeQtSLhYNTvgMcsIDKlJXH.get('mode')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXP=EVjAykFxCeQtSLhYNTvgMcsIDKlJXH.get('stype')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR=EVjAykFxCeQtSLhYNTvgMcsIDKlJXH.get('title')
   (EVjAykFxCeQtSLhYNTvgMcsIDKlJGn,EVjAykFxCeQtSLhYNTvgMcsIDKlJXf)=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.GetSearchList(EVjAykFxCeQtSLhYNTvgMcsIDKlJGu,1,EVjAykFxCeQtSLhYNTvgMcsIDKlJXP)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXb={'plot':'검색어 : '+EVjAykFxCeQtSLhYNTvgMcsIDKlJGu+'\n\n'+EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.Search_FreeList(EVjAykFxCeQtSLhYNTvgMcsIDKlJGn)}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':EVjAykFxCeQtSLhYNTvgMcsIDKlJGU,'stype':EVjAykFxCeQtSLhYNTvgMcsIDKlJXP,'search_key':EVjAykFxCeQtSLhYNTvgMcsIDKlJGu,'page':'1',}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel='',img='',infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJXb,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJqX(EVjAykFxCeQtSLhYNTvgMcsIDKlJob)>0:xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,cacheToDisc=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn)
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.Save_Searched_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJGu)
 def Search_FreeList(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJba):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGf=''
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGr=7
  try:
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJqX(EVjAykFxCeQtSLhYNTvgMcsIDKlJba)==0:return '검색결과 없음'
   for i in EVjAykFxCeQtSLhYNTvgMcsIDKlJqG(EVjAykFxCeQtSLhYNTvgMcsIDKlJqX(EVjAykFxCeQtSLhYNTvgMcsIDKlJba)):
    if i>=EVjAykFxCeQtSLhYNTvgMcsIDKlJGr:
     EVjAykFxCeQtSLhYNTvgMcsIDKlJGf=EVjAykFxCeQtSLhYNTvgMcsIDKlJGf+'...'
     break
    EVjAykFxCeQtSLhYNTvgMcsIDKlJGf=EVjAykFxCeQtSLhYNTvgMcsIDKlJGf+EVjAykFxCeQtSLhYNTvgMcsIDKlJba[i]['title']+'\n'
  except:
   return ''
  return EVjAykFxCeQtSLhYNTvgMcsIDKlJGf
 def dp_Search_History(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGd=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.Load_List_File('search')
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJbo in EVjAykFxCeQtSLhYNTvgMcsIDKlJGd:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbz=EVjAykFxCeQtSLhYNTvgMcsIDKlJOd(urllib.parse.parse_qsl(EVjAykFxCeQtSLhYNTvgMcsIDKlJbo))
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbX=EVjAykFxCeQtSLhYNTvgMcsIDKlJbz.get('skey').strip()
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'SEARCH_GROUP','search_key':EVjAykFxCeQtSLhYNTvgMcsIDKlJbX,}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbm={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':EVjAykFxCeQtSLhYNTvgMcsIDKlJbX,'vType':'-',}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbG=urllib.parse.urlencode(EVjAykFxCeQtSLhYNTvgMcsIDKlJbm)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmn=[('선택된 검색어 ( %s ) 삭제'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJbX),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJbG))]
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJbX,sublabel='',img=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz,ContextMenu=EVjAykFxCeQtSLhYNTvgMcsIDKlJmn)
  EVjAykFxCeQtSLhYNTvgMcsIDKlJmp={'plot':'검색목록 전체를 삭제합니다.'}
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzR='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel='',img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXo,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJmp,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz,isLink=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn)
  xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,cacheToDisc=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf)
 def dp_Search_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXU =EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('page'))
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXP =EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('stype')
  if 'search_key' in EVjAykFxCeQtSLhYNTvgMcsIDKlJXu:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGu=EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('search_key')
  else:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGu=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not EVjAykFxCeQtSLhYNTvgMcsIDKlJGu:
    xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle)
    return
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGn,EVjAykFxCeQtSLhYNTvgMcsIDKlJXf=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.GetSearchList(EVjAykFxCeQtSLhYNTvgMcsIDKlJGu,EVjAykFxCeQtSLhYNTvgMcsIDKlJXU,EVjAykFxCeQtSLhYNTvgMcsIDKlJXP)
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJba in EVjAykFxCeQtSLhYNTvgMcsIDKlJGn:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR =EVjAykFxCeQtSLhYNTvgMcsIDKlJba.get('title')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXd =EVjAykFxCeQtSLhYNTvgMcsIDKlJba.get('thumbnail')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmo =EVjAykFxCeQtSLhYNTvgMcsIDKlJba.get('synopsis')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbO =EVjAykFxCeQtSLhYNTvgMcsIDKlJba.get('program')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmX =EVjAykFxCeQtSLhYNTvgMcsIDKlJba.get('cast')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmG =EVjAykFxCeQtSLhYNTvgMcsIDKlJba.get('director')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmb=EVjAykFxCeQtSLhYNTvgMcsIDKlJba.get('info_genre')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGp =EVjAykFxCeQtSLhYNTvgMcsIDKlJba.get('duration')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmO =EVjAykFxCeQtSLhYNTvgMcsIDKlJba.get('mpaa')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJma =EVjAykFxCeQtSLhYNTvgMcsIDKlJba.get('year')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJGm =EVjAykFxCeQtSLhYNTvgMcsIDKlJba.get('aired')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmp={'mediatype':'tvshow' if EVjAykFxCeQtSLhYNTvgMcsIDKlJXP=='vod' else 'movie','title':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'cast':EVjAykFxCeQtSLhYNTvgMcsIDKlJmX,'director':EVjAykFxCeQtSLhYNTvgMcsIDKlJmG,'genre':EVjAykFxCeQtSLhYNTvgMcsIDKlJmb,'duration':EVjAykFxCeQtSLhYNTvgMcsIDKlJGp,'mpaa':EVjAykFxCeQtSLhYNTvgMcsIDKlJmO,'year':EVjAykFxCeQtSLhYNTvgMcsIDKlJma,'aired':EVjAykFxCeQtSLhYNTvgMcsIDKlJGm,'plot':'%s\n\n%s'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,EVjAykFxCeQtSLhYNTvgMcsIDKlJmo)}
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJXP=='vod':
    EVjAykFxCeQtSLhYNTvgMcsIDKlJGB=EVjAykFxCeQtSLhYNTvgMcsIDKlJba.get('program')
    EVjAykFxCeQtSLhYNTvgMcsIDKlJGi='tvshow'
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'EPISODE','programcode':EVjAykFxCeQtSLhYNTvgMcsIDKlJGB,'page':'1',}
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXm=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn
   else:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJGB=EVjAykFxCeQtSLhYNTvgMcsIDKlJba.get('movie')
    EVjAykFxCeQtSLhYNTvgMcsIDKlJGi='movie'
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'MOVIE','mediacode':EVjAykFxCeQtSLhYNTvgMcsIDKlJGB,'stype':'movie','title':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'thumbnail':EVjAykFxCeQtSLhYNTvgMcsIDKlJXd,}
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXm=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_makebookmark():
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmH={'videoid':EVjAykFxCeQtSLhYNTvgMcsIDKlJGB,'vidtype':EVjAykFxCeQtSLhYNTvgMcsIDKlJGi,'vtitle':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'vsubtitle':'',}
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmu=json.dumps(EVjAykFxCeQtSLhYNTvgMcsIDKlJmH)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmu=urllib.parse.quote(EVjAykFxCeQtSLhYNTvgMcsIDKlJmu)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmU='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJmu)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmn=[('(통합) 찜 영상에 추가',EVjAykFxCeQtSLhYNTvgMcsIDKlJmU)]
   else:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmn=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel='',img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXd,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJmp,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJXm,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz,isLink=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf,ContextMenu=EVjAykFxCeQtSLhYNTvgMcsIDKlJmn)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXf:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['mode'] ='SEARCH' 
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['search_key']=EVjAykFxCeQtSLhYNTvgMcsIDKlJGu
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz['page'] =EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR='[B]%s >>[/B]'%'다음 페이지'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmW=EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJXU+1)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJmW,img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXo,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXP=='movie':xbmcplugin.setContent(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,'movies')
  else:xbmcplugin.setContent(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,cacheToDisc=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf)
 def dp_History_Remove(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJbq=EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('delType')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJbp =EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('sKey')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJbW =EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('vType')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJou=xbmcgui.Dialog()
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJbq=='SEARCH_ALL':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXB=EVjAykFxCeQtSLhYNTvgMcsIDKlJou.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJbq=='SEARCH_ONE':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXB=EVjAykFxCeQtSLhYNTvgMcsIDKlJou.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJbq=='WATCH_ALL':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXB=EVjAykFxCeQtSLhYNTvgMcsIDKlJou.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJbq=='WATCH_ONE':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXB=EVjAykFxCeQtSLhYNTvgMcsIDKlJou.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXB==EVjAykFxCeQtSLhYNTvgMcsIDKlJOf:sys.exit()
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJbq=='SEARCH_ALL':
   if os.path.isfile(EVjAykFxCeQtSLhYNTvgMcsIDKlJoB):os.remove(EVjAykFxCeQtSLhYNTvgMcsIDKlJoB)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJbq=='SEARCH_ONE':
   try:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbB=EVjAykFxCeQtSLhYNTvgMcsIDKlJoB
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbi=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.Load_List_File('search') 
    fp=EVjAykFxCeQtSLhYNTvgMcsIDKlJqb(EVjAykFxCeQtSLhYNTvgMcsIDKlJbB,'w',-1,'utf-8')
    for EVjAykFxCeQtSLhYNTvgMcsIDKlJbw in EVjAykFxCeQtSLhYNTvgMcsIDKlJbi:
     EVjAykFxCeQtSLhYNTvgMcsIDKlJbP=EVjAykFxCeQtSLhYNTvgMcsIDKlJOd(urllib.parse.parse_qsl(EVjAykFxCeQtSLhYNTvgMcsIDKlJbw))
     EVjAykFxCeQtSLhYNTvgMcsIDKlJbR=EVjAykFxCeQtSLhYNTvgMcsIDKlJbP.get('skey').strip()
     if EVjAykFxCeQtSLhYNTvgMcsIDKlJbp!=EVjAykFxCeQtSLhYNTvgMcsIDKlJbR:
      fp.write(EVjAykFxCeQtSLhYNTvgMcsIDKlJbw)
    fp.close()
   except:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJbq=='WATCH_ALL':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbB=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EVjAykFxCeQtSLhYNTvgMcsIDKlJbW))
   if os.path.isfile(EVjAykFxCeQtSLhYNTvgMcsIDKlJbB):os.remove(EVjAykFxCeQtSLhYNTvgMcsIDKlJbB)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJbq=='WATCH_ONE':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbB=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EVjAykFxCeQtSLhYNTvgMcsIDKlJbW))
   try:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbi=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.Load_List_File(EVjAykFxCeQtSLhYNTvgMcsIDKlJbW) 
    fp=EVjAykFxCeQtSLhYNTvgMcsIDKlJqb(EVjAykFxCeQtSLhYNTvgMcsIDKlJbB,'w',-1,'utf-8')
    for EVjAykFxCeQtSLhYNTvgMcsIDKlJbw in EVjAykFxCeQtSLhYNTvgMcsIDKlJbi:
     EVjAykFxCeQtSLhYNTvgMcsIDKlJbP=EVjAykFxCeQtSLhYNTvgMcsIDKlJOd(urllib.parse.parse_qsl(EVjAykFxCeQtSLhYNTvgMcsIDKlJbw))
     EVjAykFxCeQtSLhYNTvgMcsIDKlJbR=EVjAykFxCeQtSLhYNTvgMcsIDKlJbP.get('code').strip()
     if EVjAykFxCeQtSLhYNTvgMcsIDKlJbp!=EVjAykFxCeQtSLhYNTvgMcsIDKlJbR:
      fp.write(EVjAykFxCeQtSLhYNTvgMcsIDKlJbw)
    fp.close()
   except:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXP): 
  try:
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJXP=='search':
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbB=EVjAykFxCeQtSLhYNTvgMcsIDKlJoB
   elif EVjAykFxCeQtSLhYNTvgMcsIDKlJXP in['vod','movie']:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbB=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EVjAykFxCeQtSLhYNTvgMcsIDKlJXP))
   else:
    return[]
   fp=EVjAykFxCeQtSLhYNTvgMcsIDKlJqb(EVjAykFxCeQtSLhYNTvgMcsIDKlJbB,'r',-1,'utf-8')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbH=fp.readlines()
   fp.close()
  except:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbH=[]
  return EVjAykFxCeQtSLhYNTvgMcsIDKlJbH
 def Save_Watched_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXP,EVjAykFxCeQtSLhYNTvgMcsIDKlJoR):
  try:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EVjAykFxCeQtSLhYNTvgMcsIDKlJXP))
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbi=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.Load_List_File(EVjAykFxCeQtSLhYNTvgMcsIDKlJXP) 
   fp=EVjAykFxCeQtSLhYNTvgMcsIDKlJqb(EVjAykFxCeQtSLhYNTvgMcsIDKlJbu,'w',-1,'utf-8')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbU=urllib.parse.urlencode(EVjAykFxCeQtSLhYNTvgMcsIDKlJoR)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbU=EVjAykFxCeQtSLhYNTvgMcsIDKlJbU+'\n'
   fp.write(EVjAykFxCeQtSLhYNTvgMcsIDKlJbU)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbn=0
   for EVjAykFxCeQtSLhYNTvgMcsIDKlJbw in EVjAykFxCeQtSLhYNTvgMcsIDKlJbi:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbP=EVjAykFxCeQtSLhYNTvgMcsIDKlJOd(urllib.parse.parse_qsl(EVjAykFxCeQtSLhYNTvgMcsIDKlJbw))
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbf=EVjAykFxCeQtSLhYNTvgMcsIDKlJoR.get('code').strip()
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbr=EVjAykFxCeQtSLhYNTvgMcsIDKlJbP.get('code').strip()
    if EVjAykFxCeQtSLhYNTvgMcsIDKlJXP=='vod' and EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_direct_replay()==EVjAykFxCeQtSLhYNTvgMcsIDKlJOn:
     EVjAykFxCeQtSLhYNTvgMcsIDKlJbf=EVjAykFxCeQtSLhYNTvgMcsIDKlJoR.get('videoid').strip()
     EVjAykFxCeQtSLhYNTvgMcsIDKlJbr=EVjAykFxCeQtSLhYNTvgMcsIDKlJbP.get('videoid').strip()if EVjAykFxCeQtSLhYNTvgMcsIDKlJbr!=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu else '-'
    if EVjAykFxCeQtSLhYNTvgMcsIDKlJbf!=EVjAykFxCeQtSLhYNTvgMcsIDKlJbr:
     fp.write(EVjAykFxCeQtSLhYNTvgMcsIDKlJbw)
     EVjAykFxCeQtSLhYNTvgMcsIDKlJbn+=1
     if EVjAykFxCeQtSLhYNTvgMcsIDKlJbn>=50:break
   fp.close()
  except:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
 def dp_Watch_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXP =EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('stype')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzB=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_direct_replay()
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXP=='-':
   for EVjAykFxCeQtSLhYNTvgMcsIDKlJXH in EVjAykFxCeQtSLhYNTvgMcsIDKlJoG:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJzR=EVjAykFxCeQtSLhYNTvgMcsIDKlJXH.get('title')
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':EVjAykFxCeQtSLhYNTvgMcsIDKlJXH.get('mode'),'stype':EVjAykFxCeQtSLhYNTvgMcsIDKlJXH.get('stype')}
    EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel='',img='',infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJOu,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJqX(EVjAykFxCeQtSLhYNTvgMcsIDKlJoG)>0:xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle)
  else:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbd=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.Load_List_File(EVjAykFxCeQtSLhYNTvgMcsIDKlJXP)
   for EVjAykFxCeQtSLhYNTvgMcsIDKlJao in EVjAykFxCeQtSLhYNTvgMcsIDKlJbd:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbz=EVjAykFxCeQtSLhYNTvgMcsIDKlJOd(urllib.parse.parse_qsl(EVjAykFxCeQtSLhYNTvgMcsIDKlJao))
    EVjAykFxCeQtSLhYNTvgMcsIDKlJaz =EVjAykFxCeQtSLhYNTvgMcsIDKlJbz.get('code').strip()
    EVjAykFxCeQtSLhYNTvgMcsIDKlJzR =EVjAykFxCeQtSLhYNTvgMcsIDKlJbz.get('title').strip()
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXd=EVjAykFxCeQtSLhYNTvgMcsIDKlJbz.get('img').strip()
    EVjAykFxCeQtSLhYNTvgMcsIDKlJGB =EVjAykFxCeQtSLhYNTvgMcsIDKlJbz.get('videoid').strip()
    try:
     EVjAykFxCeQtSLhYNTvgMcsIDKlJXd=EVjAykFxCeQtSLhYNTvgMcsIDKlJXd.replace('\'','\"')
     EVjAykFxCeQtSLhYNTvgMcsIDKlJXd=json.loads(EVjAykFxCeQtSLhYNTvgMcsIDKlJXd)
    except:
     EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmp={}
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmp['plot']=EVjAykFxCeQtSLhYNTvgMcsIDKlJzR
    if EVjAykFxCeQtSLhYNTvgMcsIDKlJXP=='vod':
     if EVjAykFxCeQtSLhYNTvgMcsIDKlJzB==EVjAykFxCeQtSLhYNTvgMcsIDKlJOf or EVjAykFxCeQtSLhYNTvgMcsIDKlJGB==EVjAykFxCeQtSLhYNTvgMcsIDKlJOu:
      EVjAykFxCeQtSLhYNTvgMcsIDKlJmp['mediatype']='tvshow'
      EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'EPISODE','programcode':EVjAykFxCeQtSLhYNTvgMcsIDKlJaz,'page':'1'}
      EVjAykFxCeQtSLhYNTvgMcsIDKlJXm=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn
     else:
      EVjAykFxCeQtSLhYNTvgMcsIDKlJmp['mediatype']='episode'
      EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'VOD','mediacode':EVjAykFxCeQtSLhYNTvgMcsIDKlJGB,'stype':'vod','programcode':EVjAykFxCeQtSLhYNTvgMcsIDKlJaz,'title':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'thumbnail':EVjAykFxCeQtSLhYNTvgMcsIDKlJXd}
      EVjAykFxCeQtSLhYNTvgMcsIDKlJXm=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
    else:
     EVjAykFxCeQtSLhYNTvgMcsIDKlJmp['mediatype']='movie'
     EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'MOVIE','mediacode':EVjAykFxCeQtSLhYNTvgMcsIDKlJaz,'stype':'movie','title':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'thumbnail':EVjAykFxCeQtSLhYNTvgMcsIDKlJXd}
     EVjAykFxCeQtSLhYNTvgMcsIDKlJXm=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbm={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':EVjAykFxCeQtSLhYNTvgMcsIDKlJaz,'vType':EVjAykFxCeQtSLhYNTvgMcsIDKlJXP,}
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbG=urllib.parse.urlencode(EVjAykFxCeQtSLhYNTvgMcsIDKlJbm)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJmn=[('선택된 시청이력 ( %s ) 삭제'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJbG))]
    EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel='',img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXd,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJmp,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJXm,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz,ContextMenu=EVjAykFxCeQtSLhYNTvgMcsIDKlJmn)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmp={'plot':'시청목록을 삭제합니다.'}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':EVjAykFxCeQtSLhYNTvgMcsIDKlJXP,}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel='',img=EVjAykFxCeQtSLhYNTvgMcsIDKlJXo,infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJmp,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz,isLink=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn)
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJXP=='movie':xbmcplugin.setContent(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,'movies')
   else:xbmcplugin.setContent(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,cacheToDisc=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf)
 def Save_Searched_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJGu):
  try:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJaX=EVjAykFxCeQtSLhYNTvgMcsIDKlJoB
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbi=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.Load_List_File('search') 
   EVjAykFxCeQtSLhYNTvgMcsIDKlJam={'skey':EVjAykFxCeQtSLhYNTvgMcsIDKlJGu.strip()}
   fp=EVjAykFxCeQtSLhYNTvgMcsIDKlJqb(EVjAykFxCeQtSLhYNTvgMcsIDKlJaX,'w',-1,'utf-8')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbU=urllib.parse.urlencode(EVjAykFxCeQtSLhYNTvgMcsIDKlJam)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbU=EVjAykFxCeQtSLhYNTvgMcsIDKlJbU+'\n'
   fp.write(EVjAykFxCeQtSLhYNTvgMcsIDKlJbU)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJbn=0
   for EVjAykFxCeQtSLhYNTvgMcsIDKlJbw in EVjAykFxCeQtSLhYNTvgMcsIDKlJbi:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbP=EVjAykFxCeQtSLhYNTvgMcsIDKlJOd(urllib.parse.parse_qsl(EVjAykFxCeQtSLhYNTvgMcsIDKlJbw))
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbf=EVjAykFxCeQtSLhYNTvgMcsIDKlJam.get('skey').strip()
    EVjAykFxCeQtSLhYNTvgMcsIDKlJbr=EVjAykFxCeQtSLhYNTvgMcsIDKlJbP.get('skey').strip()
    if EVjAykFxCeQtSLhYNTvgMcsIDKlJbf!=EVjAykFxCeQtSLhYNTvgMcsIDKlJbr:
     fp.write(EVjAykFxCeQtSLhYNTvgMcsIDKlJbw)
     EVjAykFxCeQtSLhYNTvgMcsIDKlJbn+=1
     if EVjAykFxCeQtSLhYNTvgMcsIDKlJbn>=50:break
   fp.close()
  except:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
 def play_VIDEO(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJaG =EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('mediacode')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXP =EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('stype')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJab =EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('pvrmode')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJaO=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_selQuality(EVjAykFxCeQtSLhYNTvgMcsIDKlJXP)
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJaG,EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJaO),EVjAykFxCeQtSLhYNTvgMcsIDKlJXP,EVjAykFxCeQtSLhYNTvgMcsIDKlJab))
  EVjAykFxCeQtSLhYNTvgMcsIDKlJaq=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.GetBroadURL(EVjAykFxCeQtSLhYNTvgMcsIDKlJaG,EVjAykFxCeQtSLhYNTvgMcsIDKlJaO,EVjAykFxCeQtSLhYNTvgMcsIDKlJXP,EVjAykFxCeQtSLhYNTvgMcsIDKlJab,optUHD=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_uhd())
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.addon_log('qt, stype, url : %s - %s - %s'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJqm(EVjAykFxCeQtSLhYNTvgMcsIDKlJaO),EVjAykFxCeQtSLhYNTvgMcsIDKlJXP,EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['streaming_url']))
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['streaming_url']=='':
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['error_msg']=='':
    EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.addon_noti(__language__(30908).encode('utf8'))
   else:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.addon_noti(EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['error_msg'].encode('utf8'))
   return
  EVjAykFxCeQtSLhYNTvgMcsIDKlJap='user-agent={}'.format(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.USER_AGENT)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['watermark'] !='':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJap='{}&x-tving-param1={}&x-tving-param2={}'.format(EVjAykFxCeQtSLhYNTvgMcsIDKlJap,EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['watermarkKey'],EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['watermark'])
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.addon_log('streaming_url = {}'.format(EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['streaming_url']))
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.addon_log('watermark     = {}'.format(EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['watermark']))
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.addon_log('watermarkKey  = {}'.format(EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['watermarkKey']))
  EVjAykFxCeQtSLhYNTvgMcsIDKlJaW =EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
  EVjAykFxCeQtSLhYNTvgMcsIDKlJaB =EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['streaming_url'].find('Policy=')
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJaB!=-1:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJai =EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['streaming_url'].split('?')[0]
   EVjAykFxCeQtSLhYNTvgMcsIDKlJaw=EVjAykFxCeQtSLhYNTvgMcsIDKlJOd(urllib.parse.parse_qsl(urllib.parse.urlsplit(EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['streaming_url']).query))
   EVjAykFxCeQtSLhYNTvgMcsIDKlJaP='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJaw['Policy'],EVjAykFxCeQtSLhYNTvgMcsIDKlJaw['Signature'],EVjAykFxCeQtSLhYNTvgMcsIDKlJaw['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in EVjAykFxCeQtSLhYNTvgMcsIDKlJai:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJaW=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn
    EVjAykFxCeQtSLhYNTvgMcsIDKlJaR =EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJaH=EVjAykFxCeQtSLhYNTvgMcsIDKlJaR.strftime('%Y-%m-%d-%H:%M:%S')
    if EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(EVjAykFxCeQtSLhYNTvgMcsIDKlJaH.replace('-','').replace(':',''))<EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(EVjAykFxCeQtSLhYNTvgMcsIDKlJaw['end'].replace('-','').replace(':','')):
     EVjAykFxCeQtSLhYNTvgMcsIDKlJaw['end']=EVjAykFxCeQtSLhYNTvgMcsIDKlJaH
     EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.addon_noti(__language__(30915).encode('utf8'))
    EVjAykFxCeQtSLhYNTvgMcsIDKlJai ='%s?%s'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJai,urllib.parse.urlencode(EVjAykFxCeQtSLhYNTvgMcsIDKlJaw,doseq=EVjAykFxCeQtSLhYNTvgMcsIDKlJOn))
    EVjAykFxCeQtSLhYNTvgMcsIDKlJau='{}|{}&Cookie={}'.format(EVjAykFxCeQtSLhYNTvgMcsIDKlJai,EVjAykFxCeQtSLhYNTvgMcsIDKlJap,EVjAykFxCeQtSLhYNTvgMcsIDKlJaP)
   else:
    EVjAykFxCeQtSLhYNTvgMcsIDKlJau='{}|{}&Cookie={}'.format(EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['streaming_url'],EVjAykFxCeQtSLhYNTvgMcsIDKlJap,EVjAykFxCeQtSLhYNTvgMcsIDKlJaP)
  else:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJau=EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['streaming_url']+'|'+EVjAykFxCeQtSLhYNTvgMcsIDKlJap
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.addon_log('if tmp_pos == -1')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.addon_log(EVjAykFxCeQtSLhYNTvgMcsIDKlJau)
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzG,EVjAykFxCeQtSLhYNTvgMcsIDKlJzb=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_proxyport()
  EVjAykFxCeQtSLhYNTvgMcsIDKlJzm=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_playback()
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJzG and EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('mode')in['VOD','MOVIE']and EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['drm_license']!='':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.Tving_Parse_mpd(EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['streaming_url'])
   EVjAykFxCeQtSLhYNTvgMcsIDKlJaU={'addon':'tvingm','playOption':EVjAykFxCeQtSLhYNTvgMcsIDKlJzm,}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJaU=json.dumps(EVjAykFxCeQtSLhYNTvgMcsIDKlJaU,separators=(',',':'))
   EVjAykFxCeQtSLhYNTvgMcsIDKlJaU=base64.standard_b64encode(EVjAykFxCeQtSLhYNTvgMcsIDKlJaU.encode()).decode('utf-8')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJau ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(EVjAykFxCeQtSLhYNTvgMcsIDKlJzb,EVjAykFxCeQtSLhYNTvgMcsIDKlJau,EVjAykFxCeQtSLhYNTvgMcsIDKlJaU)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJap='{}&proxy-mini={}'.format(EVjAykFxCeQtSLhYNTvgMcsIDKlJap,EVjAykFxCeQtSLhYNTvgMcsIDKlJaU)
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.addon_log(EVjAykFxCeQtSLhYNTvgMcsIDKlJau)
  EVjAykFxCeQtSLhYNTvgMcsIDKlJan=xbmcgui.ListItem(path=EVjAykFxCeQtSLhYNTvgMcsIDKlJau)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['drm_license']!='':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJaf=EVjAykFxCeQtSLhYNTvgMcsIDKlJaq['drm_license']
   EVjAykFxCeQtSLhYNTvgMcsIDKlJar ='https://cj.drmkeyserver.com/widevine_license'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJad ='mpd'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJOo ='com.widevine.alpha'
   EVjAykFxCeQtSLhYNTvgMcsIDKlJOz =inputstreamhelper.Helper(EVjAykFxCeQtSLhYNTvgMcsIDKlJad,drm='widevine')
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJOz.check_inputstream():
    EVjAykFxCeQtSLhYNTvgMcsIDKlJOX={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.USER_AGENT,'AcquireLicenseAssertion':EVjAykFxCeQtSLhYNTvgMcsIDKlJaf,'Host':'cj.drmkeyserver.com',}
    EVjAykFxCeQtSLhYNTvgMcsIDKlJOm=EVjAykFxCeQtSLhYNTvgMcsIDKlJar+'|'+urllib.parse.urlencode(EVjAykFxCeQtSLhYNTvgMcsIDKlJOX)+'|R{SSM}|'
    EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setProperty('inputstream',EVjAykFxCeQtSLhYNTvgMcsIDKlJOz.inputstream_addon)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setProperty('inputstream.adaptive.manifest_type',EVjAykFxCeQtSLhYNTvgMcsIDKlJad)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setProperty('inputstream.adaptive.license_type',EVjAykFxCeQtSLhYNTvgMcsIDKlJOo)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setProperty('inputstream.adaptive.license_key',EVjAykFxCeQtSLhYNTvgMcsIDKlJOm)
    EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setProperty('inputstream.adaptive.stream_headers',EVjAykFxCeQtSLhYNTvgMcsIDKlJap)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJaW==EVjAykFxCeQtSLhYNTvgMcsIDKlJOn:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setContentLookup(EVjAykFxCeQtSLhYNTvgMcsIDKlJOf)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setMimeType('application/x-mpegURL')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setProperty('inputstream','inputstream.ffmpegdirect')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setProperty('ResumeTime','0')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setProperty('TotalTime','10000')
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('mode')in['VOD','MOVIE']:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setContentLookup(EVjAykFxCeQtSLhYNTvgMcsIDKlJOf)
   EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setMimeType('application/x-mpegURL')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setProperty('inputstream','inputstream.adaptive')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJan.setProperty('inputstream.adaptive.manifest_type','hls')
  xbmcplugin.setResolvedUrl(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,EVjAykFxCeQtSLhYNTvgMcsIDKlJOn,EVjAykFxCeQtSLhYNTvgMcsIDKlJan)
  try:
   if EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('mode')in['VOD','MOVIE']and EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('title'):
    EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'code':EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('programcode')if EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('mode')=='VOD' else EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('mediacode'),'img':EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('thumbnail'),'title':EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('title'),'videoid':EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('mediacode')}
    EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.Save_Watched_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('stype'),EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  except:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
 def logout(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJou=xbmcgui.Dialog()
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXB=EVjAykFxCeQtSLhYNTvgMcsIDKlJou.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJXB==EVjAykFxCeQtSLhYNTvgMcsIDKlJOf:sys.exit()
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.Init_TV_Total()
  if os.path.isfile(EVjAykFxCeQtSLhYNTvgMcsIDKlJoW):os.remove(EVjAykFxCeQtSLhYNTvgMcsIDKlJoW)
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJOG =EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.Get_Now_Datetime()
  EVjAykFxCeQtSLhYNTvgMcsIDKlJOb=EVjAykFxCeQtSLhYNTvgMcsIDKlJOG+datetime.timedelta(days=EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(__addon__.getSetting('cache_ttl')))
  (EVjAykFxCeQtSLhYNTvgMcsIDKlJXO,EVjAykFxCeQtSLhYNTvgMcsIDKlJXq,EVjAykFxCeQtSLhYNTvgMcsIDKlJXp,EVjAykFxCeQtSLhYNTvgMcsIDKlJXW)=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_account()
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.Save_session_acount(EVjAykFxCeQtSLhYNTvgMcsIDKlJXO,EVjAykFxCeQtSLhYNTvgMcsIDKlJXq,EVjAykFxCeQtSLhYNTvgMcsIDKlJXp,EVjAykFxCeQtSLhYNTvgMcsIDKlJXW)
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.TV['account']['token_limit']=EVjAykFxCeQtSLhYNTvgMcsIDKlJOb.strftime('%Y%m%d')
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.JsonFile_Save(EVjAykFxCeQtSLhYNTvgMcsIDKlJoW,EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.TV)
 def cookiefile_check(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.TV=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.JsonFile_Load(EVjAykFxCeQtSLhYNTvgMcsIDKlJoW)
  if 'account' not in EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.TV:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.Init_TV_Total()
   return EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
  (EVjAykFxCeQtSLhYNTvgMcsIDKlJOa,EVjAykFxCeQtSLhYNTvgMcsIDKlJOq,EVjAykFxCeQtSLhYNTvgMcsIDKlJOp,EVjAykFxCeQtSLhYNTvgMcsIDKlJOW)=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.get_settings_account()
  (EVjAykFxCeQtSLhYNTvgMcsIDKlJOB,EVjAykFxCeQtSLhYNTvgMcsIDKlJOi,EVjAykFxCeQtSLhYNTvgMcsIDKlJOw,EVjAykFxCeQtSLhYNTvgMcsIDKlJOP)=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.Load_session_acount()
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJOa!=EVjAykFxCeQtSLhYNTvgMcsIDKlJOB or EVjAykFxCeQtSLhYNTvgMcsIDKlJOq!=EVjAykFxCeQtSLhYNTvgMcsIDKlJOi or EVjAykFxCeQtSLhYNTvgMcsIDKlJOp!=EVjAykFxCeQtSLhYNTvgMcsIDKlJOw or EVjAykFxCeQtSLhYNTvgMcsIDKlJOW!=EVjAykFxCeQtSLhYNTvgMcsIDKlJOP:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.Init_TV_Total()
   return EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.TV['account']['token_limit']):
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.Init_TV_Total()
   return EVjAykFxCeQtSLhYNTvgMcsIDKlJOf
  return EVjAykFxCeQtSLhYNTvgMcsIDKlJOn
 def dp_Global_Search(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=EVjAykFxCeQtSLhYNTvgMcsIDKlJXu.get('mode')
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='TOTAL_SEARCH':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJOR='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJOR='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(EVjAykFxCeQtSLhYNTvgMcsIDKlJOR)
 def dp_Bookmark_Menu(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJOR='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(EVjAykFxCeQtSLhYNTvgMcsIDKlJOR)
 def dp_EuroLive_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi,EVjAykFxCeQtSLhYNTvgMcsIDKlJXu):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJXn=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.GetEuroChannelList()
  for EVjAykFxCeQtSLhYNTvgMcsIDKlJXr in EVjAykFxCeQtSLhYNTvgMcsIDKlJXn:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmR =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('channel')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJzR =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('title')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmW =EVjAykFxCeQtSLhYNTvgMcsIDKlJXr.get('subtitle')
   EVjAykFxCeQtSLhYNTvgMcsIDKlJmp={'mediatype':'episode','title':EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,'plot':'%s\n%s'%(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,EVjAykFxCeQtSLhYNTvgMcsIDKlJmW)}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJXz={'mode':'LIVE','mediacode':EVjAykFxCeQtSLhYNTvgMcsIDKlJmR,'stype':'onair',}
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.add_dir(EVjAykFxCeQtSLhYNTvgMcsIDKlJzR,sublabel=EVjAykFxCeQtSLhYNTvgMcsIDKlJmW,img='',infoLabels=EVjAykFxCeQtSLhYNTvgMcsIDKlJmp,isFolder=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf,params=EVjAykFxCeQtSLhYNTvgMcsIDKlJXz)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJqX(EVjAykFxCeQtSLhYNTvgMcsIDKlJXn)>0:xbmcplugin.endOfDirectory(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi._addon_handle,cacheToDisc=EVjAykFxCeQtSLhYNTvgMcsIDKlJOf)
 def tving_main(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi):
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.TvingObj.KodiVersion=EVjAykFxCeQtSLhYNTvgMcsIDKlJOU(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params.get('mode',EVjAykFxCeQtSLhYNTvgMcsIDKlJOu)
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='LOGOUT':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.logout()
   return
  EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.login_main()
  if EVjAykFxCeQtSLhYNTvgMcsIDKlJGU is EVjAykFxCeQtSLhYNTvgMcsIDKlJOu:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_Main_List()
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_Title_Group(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU in['GLOBAL_GROUP']:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_SubTitle_Group(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='CHANNEL':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_LiveChannel_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU in['LIVE','VOD','MOVIE']:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.play_VIDEO(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='PROGRAM':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_Program_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='4K_PROGRAM':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_4K_Program_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='ORI_PROGRAM':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_Ori_Program_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='EPISODE':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_Episode_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='MOVIE_SUB':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_Movie_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='4K_MOVIE':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_4K_Movie_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='SEARCH_GROUP':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_Search_Group(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU in['SEARCH','LOCAL_SEARCH']:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_Search_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='WATCH':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_Watch_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_History_Remove(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='ORDER_BY':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_setEpOrderby(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='SET_BOOKMARK':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_Set_Bookmark(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU in['TOTAL_SEARCH','TOTAL_HISTORY']:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_Global_Search(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='SEARCH_HISTORY':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_Search_History(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='MENU_BOOKMARK':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_Bookmark_Menu(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  elif EVjAykFxCeQtSLhYNTvgMcsIDKlJGU=='EURO_GROUP':
   EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.dp_EuroLive_List(EVjAykFxCeQtSLhYNTvgMcsIDKlJoi.main_params)
  else:
   EVjAykFxCeQtSLhYNTvgMcsIDKlJOu
# Created by pyminifier (https://github.com/liftoff/pyminifier)
