__author__="NightRain"
PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC=print
PLEQMbXcUIgRFvpVBOAKqDaHTfGxdm=ImportError
PLEQMbXcUIgRFvpVBOAKqDaHTfGxre=object
PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh=None
PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn=False
PLEQMbXcUIgRFvpVBOAKqDaHTfGxry=open
PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl=True
PLEQMbXcUIgRFvpVBOAKqDaHTfGxrd=int
PLEQMbXcUIgRFvpVBOAKqDaHTfGxrz=range
PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW=Exception
PLEQMbXcUIgRFvpVBOAKqDaHTfGxrk=len
PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt=str
PLEQMbXcUIgRFvpVBOAKqDaHTfGxrj=dict
PLEQMbXcUIgRFvpVBOAKqDaHTfGxrN=list
PLEQMbXcUIgRFvpVBOAKqDaHTfGxro=bytes
PLEQMbXcUIgRFvpVBOAKqDaHTfGxrs=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC('Cryptodome')
except PLEQMbXcUIgRFvpVBOAKqDaHTfGxdm:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC('Crypto')
PLEQMbXcUIgRFvpVBOAKqDaHTfGxen={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
PLEQMbXcUIgRFvpVBOAKqDaHTfGxey ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class PLEQMbXcUIgRFvpVBOAKqDaHTfGxeh(PLEQMbXcUIgRFvpVBOAKqDaHTfGxre):
 def __init__(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.NETWORKCODE ='CSND0900'
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.OSCODE ='CSOD0900' 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TELECODE ='CSCD0900'
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.SCREENCODE ='CSSD0100'
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.SCREENCODE_ATV ='CSSD1300' 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.LIVE_LIMIT =20 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.VOD_LIMIT =24 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.EPISODE_LIMIT =30 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.SEARCH_LIMIT =30 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.MOVIE_LIMIT =24 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN ='https://api.tving.com'
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN ='https://image.tving.com'
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.SEARCH_DOMAIN ='https://search.tving.com'
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.LOGIN_DOMAIN ='https://user.tving.com'
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.URL_DOMAIN ='https://www.tving.com'
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.MOVIE_LITE =['2610061','2610161','261062']
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.DEFAULT_HEADER ={'user-agent':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.USER_AGENT}
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV_SESSION_COOKIES1=''
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV_SESSION_COOKIES2=''
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV_STREAM_FILENAME =''
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.KodiVersion=20
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV ={}
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.Init_TV_Total()
 def Init_TV_Total(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N','tving_authToken':'',},}
 def callRequestCookies(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,jobtype,PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,redirects=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxed=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.DEFAULT_HEADER
  if headers:PLEQMbXcUIgRFvpVBOAKqDaHTfGxed.update(headers)
  if jobtype=='Get':
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxer=requests.get(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,params=params,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxed,cookies=cookies,allow_redirects=redirects)
  else:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxer=requests.post(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,data=payload,params=params,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxed,cookies=cookies,allow_redirects=redirects)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxer
 def JsonFile_Save(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,filename,PLEQMbXcUIgRFvpVBOAKqDaHTfGxez):
  if filename=='':return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  try:
   fp=PLEQMbXcUIgRFvpVBOAKqDaHTfGxry(filename,'w',-1,'utf-8')
   json.dump(PLEQMbXcUIgRFvpVBOAKqDaHTfGxez,fp,indent=4,ensure_ascii=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn)
   fp.close()
  except:
   return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
 def JsonFile_Load(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,filename):
  if filename=='':return{}
  try:
   fp=PLEQMbXcUIgRFvpVBOAKqDaHTfGxry(filename,'r',-1,'utf-8')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxek=json.load(fp)
   fp.close()
  except:
   return{}
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxek
 def TextFile_Save(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,filename,resText):
  if filename=='':return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  try:
   fp=PLEQMbXcUIgRFvpVBOAKqDaHTfGxry(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
 def Save_session_acount(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,PLEQMbXcUIgRFvpVBOAKqDaHTfGxet,PLEQMbXcUIgRFvpVBOAKqDaHTfGxej,PLEQMbXcUIgRFvpVBOAKqDaHTfGxeN,PLEQMbXcUIgRFvpVBOAKqDaHTfGxeo):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['account']['tvid'] =base64.standard_b64encode(PLEQMbXcUIgRFvpVBOAKqDaHTfGxet.encode()).decode('utf-8')
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['account']['tvpw'] =base64.standard_b64encode(PLEQMbXcUIgRFvpVBOAKqDaHTfGxej.encode()).decode('utf-8')
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['account']['tvtype']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxeN 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['account']['tvpf'] =PLEQMbXcUIgRFvpVBOAKqDaHTfGxeo 
 def Load_session_acount(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel):
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxet =base64.standard_b64decode(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['account']['tvid']).decode('utf-8')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxej =base64.standard_b64decode(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['account']['tvpw']).decode('utf-8')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxeN=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['account']['tvtype']
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxeo =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxet,PLEQMbXcUIgRFvpVBOAKqDaHTfGxej,PLEQMbXcUIgRFvpVBOAKqDaHTfGxeN,PLEQMbXcUIgRFvpVBOAKqDaHTfGxeo
 def makeDefaultCookies(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxes={}
  if PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_token']:PLEQMbXcUIgRFvpVBOAKqDaHTfGxes['_tving_token']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_token']
  if PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_userinfo']:PLEQMbXcUIgRFvpVBOAKqDaHTfGxes['POC_USERINFO']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_userinfo']
  if PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_maintoken']:PLEQMbXcUIgRFvpVBOAKqDaHTfGxes[PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GLOBAL_COOKIENM['tv_maintoken']]=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_maintoken']
  if PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_cookiekey']:PLEQMbXcUIgRFvpVBOAKqDaHTfGxes[PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GLOBAL_COOKIENM['tv_cookiekey']]=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_cookiekey']
  if PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_lockkey']:PLEQMbXcUIgRFvpVBOAKqDaHTfGxes[PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GLOBAL_COOKIENM['tv_lockkey']]=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_lockkey']
  if PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_authToken']:PLEQMbXcUIgRFvpVBOAKqDaHTfGxes['authToken']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_authToken']
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxes
 def makeCookiesStr(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel):
  return '_tving_token='+PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_token']+';'+ 'POC_USERINFO='+PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_userinfo']+';'+ PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GLOBAL_COOKIENM['tv_maintoken']+'='+PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_maintoken']+';'+ PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GLOBAL_COOKIENM['tv_cookiekey']+'='+PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_cookiekey']+';'+ PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GLOBAL_COOKIENM['tv_lockkey']+'='+PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_lockkey']
 def getDeviceStr(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxeY=[]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxeY.append('Windows') 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxeY.append('Chrome') 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxeY.append('ko-KR') 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxeY.append('undefined') 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxeY.append('24') 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxeY.append(u'한국 표준시')
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxeY.append('undefined') 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxeY.append('undefined') 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxeY.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxew=''
  for PLEQMbXcUIgRFvpVBOAKqDaHTfGxei in PLEQMbXcUIgRFvpVBOAKqDaHTfGxeY:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxew+=PLEQMbXcUIgRFvpVBOAKqDaHTfGxei+'|'
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxew
 def GetDefaultParams(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,uhd=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn):
  if uhd==PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxeS={'apiKey':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.APIKEY,'networkCode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.NETWORKCODE,'osCode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.OSCODE,'teleCode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TELECODE,'screenCode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.SCREENCODE,}
  else:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxeS={'apiKey':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.APIKEY_ATV,'networkCode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.NETWORKCODE,'osCode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.OSCODE,'teleCode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TELECODE,'screenCode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.SCREENCODE_ATV,}
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxeS
 def GetNoCache(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,timetype=1):
  if timetype==1:
   return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrd(time.time())
  else:
   return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrd(time.time()*1000)
 def GetUniqueid(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,hValue=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh):
  if hValue:
   import hashlib
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxeu=hashlib.sha1()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxeu.update(hValue.encode())
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxeJ=PLEQMbXcUIgRFvpVBOAKqDaHTfGxeu.hexdigest()[:8]
  else:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxeC=[0 for i in PLEQMbXcUIgRFvpVBOAKqDaHTfGxrz(256)]
   for i in PLEQMbXcUIgRFvpVBOAKqDaHTfGxrz(256):
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxeC[i]='%02x'%(i)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxem=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrd(4294967295*random.random())|0
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxeJ=PLEQMbXcUIgRFvpVBOAKqDaHTfGxeC[255&PLEQMbXcUIgRFvpVBOAKqDaHTfGxem]+PLEQMbXcUIgRFvpVBOAKqDaHTfGxeC[PLEQMbXcUIgRFvpVBOAKqDaHTfGxem>>8&255]+PLEQMbXcUIgRFvpVBOAKqDaHTfGxeC[PLEQMbXcUIgRFvpVBOAKqDaHTfGxem>>16&255]+PLEQMbXcUIgRFvpVBOAKqDaHTfGxeC[PLEQMbXcUIgRFvpVBOAKqDaHTfGxem>>24&255]
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxeJ
 def GetCredential(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,user_id,user_pw,login_type,user_pf):
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhe=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhn={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Post',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhe,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhn,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh)
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.cookies:
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl.name=='_tving_token':
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_token']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl.value
    elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl.name=='POC_USERINFO':
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_userinfo']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl.value
    elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl.name=='authToken':
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_authToken']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl.value
   if not PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_token']:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.Init_TV_Total()
    return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_maintoken']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_token']
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetProfileToken(user_pf)==PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.Init_TV_Total()
    return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies'])
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhd =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDeviceList()
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhd not in['','-']:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_uuid']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhd+'-'+PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetUniqueid(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhd)
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.Init_TV_Total()
   return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
 def GetProfileToken(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,user_pf):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxhr=[]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxhz =''
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxes=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.makeDefaultCookies()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(PLEQMbXcUIgRFvpVBOAKqDaHTfGxes)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxes)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhr =re.findall('data-profile-no="\d+"',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhr)
   for i in PLEQMbXcUIgRFvpVBOAKqDaHTfGxrz(PLEQMbXcUIgRFvpVBOAKqDaHTfGxrk(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhr)):
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhk =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhr[i].replace('data-profile-no=','').replace('"','')
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhr[i]=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhk
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhz=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhr[user_pf]
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.Init_TV_Total()
   return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxes=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.makeDefaultCookies()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhn={'profileNo':PLEQMbXcUIgRFvpVBOAKqDaHTfGxhz}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Post',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhn,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxes)
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.cookies:
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl.name=='_tving_token':
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_token']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl.value
    elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl.name==PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GLOBAL_COOKIENM['tv_cookiekey']:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_cookiekey']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl.value
    elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl.name==PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GLOBAL_COOKIENM['tv_lockkey']:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_lockkey']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhl.value
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.Init_TV_Total()
   return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
 def GetDeviceList(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxht=[]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxhj='-'
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v1/user/device/list'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhN=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxes=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.makeDefaultCookies()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhN,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxho,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxes)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxht=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY in PLEQMbXcUIgRFvpVBOAKqDaHTfGxht:
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['model']=='PC' or PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['model']=='PC-Chrome':
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxhj=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['uuid']
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxhj
 def Get_Now_Datetime(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,mediacode,sel_quality,stype,pvrmode='-',optUHD=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','subtitleYn':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn,'error_msg':'',}
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxhj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_uuid'].split('-')[0] 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxhS =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_uuid'] 
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxhu=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn 
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhJ=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetNoCache(1))
   if stype!='tvingtv':
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v2/media/stream/info' 
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams()
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':PLEQMbXcUIgRFvpVBOAKqDaHTfGxhS,'deviceInfo':'PC','noCache':PLEQMbXcUIgRFvpVBOAKqDaHTfGxhJ,}
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC.update(PLEQMbXcUIgRFvpVBOAKqDaHTfGxho)
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxes=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.makeDefaultCookies()
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxes)
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.status_code!=200:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi['error_msg']='First Step - {} error'.format(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.status_code)
     return PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['result']['code']=='060':
     for PLEQMbXcUIgRFvpVBOAKqDaHTfGxne,PLEQMbXcUIgRFvpVBOAKqDaHTfGxye in PLEQMbXcUIgRFvpVBOAKqDaHTfGxen.items():
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxye==sel_quality:
       PLEQMbXcUIgRFvpVBOAKqDaHTfGxnh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxne
    elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['result']['code']!='000':
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi['error_msg']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['result']['message']
     return PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi
    else: 
     if not('stream' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']):return PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxny=[]
     for PLEQMbXcUIgRFvpVBOAKqDaHTfGxne,PLEQMbXcUIgRFvpVBOAKqDaHTfGxye in PLEQMbXcUIgRFvpVBOAKqDaHTfGxen.items():
      for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['stream']['quality']:
       if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['active']=='Y' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['code']==PLEQMbXcUIgRFvpVBOAKqDaHTfGxne:
        PLEQMbXcUIgRFvpVBOAKqDaHTfGxny.append({PLEQMbXcUIgRFvpVBOAKqDaHTfGxen.get(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['code']):PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['code']})
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxnh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.CheckQuality(sel_quality,PLEQMbXcUIgRFvpVBOAKqDaHTfGxny)
     try:
      if optUHD==PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl and PLEQMbXcUIgRFvpVBOAKqDaHTfGxnh=='stream50' and 'stream_support_info' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['content']['info']:
       if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['content']['info']['stream_support_info']!=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh:
        if 'stream70' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['content']['info']['stream_support_info']:
         PLEQMbXcUIgRFvpVBOAKqDaHTfGxnh='stream70'
         PLEQMbXcUIgRFvpVBOAKqDaHTfGxhu =PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
     except:
      pass
     try:
      if optUHD==PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl and PLEQMbXcUIgRFvpVBOAKqDaHTfGxnh=='stream50' and 'stream' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['content']['info']:
       if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['content']['info']['stream']!=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh:
        for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['content']['info']['stream']:
         if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['code']=='stream70':
          PLEQMbXcUIgRFvpVBOAKqDaHTfGxnh='stream70'
          PLEQMbXcUIgRFvpVBOAKqDaHTfGxhu =PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
          break
     except:
      pass
   else:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxnh='stream40'
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi['error_msg']='First Step - except error'
   return PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(PLEQMbXcUIgRFvpVBOAKqDaHTfGxnh)
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhJ=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetNoCache(1))
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v2a/media/stream/info'
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhu==PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams(uhd=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl)
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'mediaCode':mediacode,'noCache':PLEQMbXcUIgRFvpVBOAKqDaHTfGxhJ,'streamType':'hls','streamCode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxnh,'deviceId':PLEQMbXcUIgRFvpVBOAKqDaHTfGxhj,'adReq':'none','wm':'Y','ad_device':'','uuid':PLEQMbXcUIgRFvpVBOAKqDaHTfGxhS,'deviceInfo':'android_tv',}
   else:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams()
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxnh,'deviceId':PLEQMbXcUIgRFvpVBOAKqDaHTfGxhj,'uuid':PLEQMbXcUIgRFvpVBOAKqDaHTfGxhS,'deviceInfo':'PC_Chrome','noCache':PLEQMbXcUIgRFvpVBOAKqDaHTfGxhJ,'wm':'Y'}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC.update(PLEQMbXcUIgRFvpVBOAKqDaHTfGxho)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxes=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.makeDefaultCookies()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxes,redirects=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['result']['code']!='000':
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi['error_msg']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['result']['message']
    return PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxnl=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['stream']
   if 'drm_license_assertion' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxnl:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi['drm_license']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxnl['drm_license_assertion']
    if '4k_nondrm_url' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxnl['broadcast']and PLEQMbXcUIgRFvpVBOAKqDaHTfGxhu==PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxnd =PLEQMbXcUIgRFvpVBOAKqDaHTfGxnl['broadcast']['4k_nondrm_url']
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi['drm_license']=''
    else:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxnd =PLEQMbXcUIgRFvpVBOAKqDaHTfGxnl['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxnl['broadcast']):return PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxnd=PLEQMbXcUIgRFvpVBOAKqDaHTfGxnl['broadcast']['broad_url']
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi['error_msg']='Second Step - except error'
   return PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxnr=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhJ
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxnd=PLEQMbXcUIgRFvpVBOAKqDaHTfGxnd.split('|')[1]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxnd,PLEQMbXcUIgRFvpVBOAKqDaHTfGxnz,PLEQMbXcUIgRFvpVBOAKqDaHTfGxnW=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.Decrypt_Url(PLEQMbXcUIgRFvpVBOAKqDaHTfGxnd,mediacode,PLEQMbXcUIgRFvpVBOAKqDaHTfGxnr)
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi['streaming_url']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxnd
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi['watermark'] =PLEQMbXcUIgRFvpVBOAKqDaHTfGxnz
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi['watermarkKey']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxnW
  if 'subtitles' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxnl:
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxnk in PLEQMbXcUIgRFvpVBOAKqDaHTfGxnl.get('subtitles'):
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxnk.get('code')in['KO','KO_CC']:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi['subtitleYn']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
     break
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxhi
 def Tving_Parse_mpd(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,stream_url):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=requests.get(url=stream_url)
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxnt=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.content.decode('utf-8')
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxnj=0
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxnN =ET.ElementTree(ET.fromstring(PLEQMbXcUIgRFvpVBOAKqDaHTfGxnt))
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxno =PLEQMbXcUIgRFvpVBOAKqDaHTfGxnN.getroot()
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxns=re.match(r'\{.*\}',PLEQMbXcUIgRFvpVBOAKqDaHTfGxno.tag)[0]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxnY=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrj([node for _,node in ET.iterparse(io.StringIO(PLEQMbXcUIgRFvpVBOAKqDaHTfGxnt),events=['start-ns'])])
  for PLEQMbXcUIgRFvpVBOAKqDaHTfGxne,value in PLEQMbXcUIgRFvpVBOAKqDaHTfGxnY.items():
   ET.register_namespace(PLEQMbXcUIgRFvpVBOAKqDaHTfGxne,value)
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxnw=PLEQMbXcUIgRFvpVBOAKqDaHTfGxno.find(PLEQMbXcUIgRFvpVBOAKqDaHTfGxns+'Period')
  for PLEQMbXcUIgRFvpVBOAKqDaHTfGxni in PLEQMbXcUIgRFvpVBOAKqDaHTfGxnw.findall(PLEQMbXcUIgRFvpVBOAKqDaHTfGxns+'AdaptationSet'):
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxni.attrib.get('mimeType')=='video/mp4':
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxnS in PLEQMbXcUIgRFvpVBOAKqDaHTfGxni.findall(PLEQMbXcUIgRFvpVBOAKqDaHTfGxns+'Representation'):
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxnu=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrd(PLEQMbXcUIgRFvpVBOAKqDaHTfGxnS.attrib.get('bandwidth'))
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxnj<PLEQMbXcUIgRFvpVBOAKqDaHTfGxnu:PLEQMbXcUIgRFvpVBOAKqDaHTfGxnj=PLEQMbXcUIgRFvpVBOAKqDaHTfGxnu
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxnS in PLEQMbXcUIgRFvpVBOAKqDaHTfGxni.findall(PLEQMbXcUIgRFvpVBOAKqDaHTfGxns+'Representation'):
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxnj>PLEQMbXcUIgRFvpVBOAKqDaHTfGxrd(PLEQMbXcUIgRFvpVBOAKqDaHTfGxnS.attrib.get('bandwidth')):
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxni.remove(PLEQMbXcUIgRFvpVBOAKqDaHTfGxnS)
   else:
    continue
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxnJ=ET.tostring(PLEQMbXcUIgRFvpVBOAKqDaHTfGxno).decode('utf-8')
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TextFile_Save(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV_STREAM_FILENAME,PLEQMbXcUIgRFvpVBOAKqDaHTfGxnJ)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
 def CheckQuality(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,sel_qt,PLEQMbXcUIgRFvpVBOAKqDaHTfGxny):
  for PLEQMbXcUIgRFvpVBOAKqDaHTfGxnC in PLEQMbXcUIgRFvpVBOAKqDaHTfGxny:
   if sel_qt>=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrN(PLEQMbXcUIgRFvpVBOAKqDaHTfGxnC)[0]:return PLEQMbXcUIgRFvpVBOAKqDaHTfGxnC.get(PLEQMbXcUIgRFvpVBOAKqDaHTfGxrN(PLEQMbXcUIgRFvpVBOAKqDaHTfGxnC)[0])
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxnm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxnC.get(PLEQMbXcUIgRFvpVBOAKqDaHTfGxrN(PLEQMbXcUIgRFvpVBOAKqDaHTfGxnC)[0])
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxnm
 def makeOocUrl(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,ooc_params):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=''
  for PLEQMbXcUIgRFvpVBOAKqDaHTfGxne,PLEQMbXcUIgRFvpVBOAKqDaHTfGxye in ooc_params.items():
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm+="%s=%s^"%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxne,PLEQMbXcUIgRFvpVBOAKqDaHTfGxye)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm
 def GetLiveChannelList(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,stype,page_int):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxht=[]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v2/media/lives'
   if stype=='onair': 
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyn='CPCS0100,CPCS0400'
   else:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyn='CPCS0300'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'cacheType':'main','pageNo':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(page_int),'pageSize':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyn,}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC.update(PLEQMbXcUIgRFvpVBOAKqDaHTfGxho)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   if not('result' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']):return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['result']
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY in PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyd=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk=''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyr=PLEQMbXcUIgRFvpVBOAKqDaHTfGxly=''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyz=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['live_code']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyd =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['channel']['name']['ko']
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['episode']!=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['program']['name']['ko']
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW =PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW+', '+PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['episode']['frequency'])+'회'
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['episode']['synopsis']['ko']
    else:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['program']['name']['ko']
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['program']['synopsis']['ko']
    try: 
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =''
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =''
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=''
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo =''
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxys =''
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyY =''
     for PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['program']['image']:
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP0900':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
      elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP1800':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
      elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP2000':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
      elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP1900':PLEQMbXcUIgRFvpVBOAKqDaHTfGxys =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
      elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP0200':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyY =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
      elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP0500':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
      elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP0800':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt=='':
      for PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['channel']['image']:
       if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIC0400':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
       elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIC1400':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
       elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIC1900':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
    except:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh
    try:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi =[]
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS=[]
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu =[]
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ=''
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC=''
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxym=''
     for PLEQMbXcUIgRFvpVBOAKqDaHTfGxle in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('schedule').get('program').get('actor'):
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxle!='' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxle!=u'없음':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxle)
     for PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('schedule').get('program').get('director'):
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh!='' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh!='-' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh!=u'없음':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh)
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('schedule').get('program').get('category1_name').get('ko')!='':
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['program']['category1_name']['ko'])
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('schedule').get('program').get('category2_name').get('ko')!='':
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['program']['category2_name']['ko'])
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('schedule').get('program').get('product_year'):PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['program']['product_year']
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('schedule').get('program').get('grade_code') :PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC= PLEQMbXcUIgRFvpVBOAKqDaHTfGxey.get(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['program']['grade_code'])
     if 'broad_dt' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('schedule').get('program'):
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxln =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('schedule').get('program').get('broad_dt')
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxym='%s-%s-%s'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[:4],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[4:6],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[6:])
    except:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyr=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['broadcast_start_time'])[8:12]
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxly =PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['schedule']['broadcast_end_time'])[8:12]
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxld={'channel':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyd,'title':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW,'mediacode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyz,'thumbnail':{'poster':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj,'thumb':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt,'clearlogo':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN,'icon':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo,'fanart':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyY},'synopsis':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk,'channelepg':' [%s:%s ~ %s:%s]'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxyr[0:2],PLEQMbXcUIgRFvpVBOAKqDaHTfGxyr[2:],PLEQMbXcUIgRFvpVBOAKqDaHTfGxly[0:2],PLEQMbXcUIgRFvpVBOAKqDaHTfGxly[2:]),'cast':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi,'director':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS,'info_genre':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu,'year':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ,'mpaa':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC,'premiered':PLEQMbXcUIgRFvpVBOAKqDaHTfGxym}
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxht.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxld)
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['has_more']=='Y':
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
 def GetProgramList(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,genre,orderby,page_int,genreCode='all'):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxht=[]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  try:
   if genre=='PARAMOUNT':
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v2/media/paramount/episodes'
   else:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v2/media/episodes'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'cacheType':'main','pageSize':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(page_int),}
   if genre not in['all','PARAMOUNT']:PLEQMbXcUIgRFvpVBOAKqDaHTfGxho['categoryCode']=genre
   if genreCode!='all' :PLEQMbXcUIgRFvpVBOAKqDaHTfGxho['genreCode'] =genreCode 
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC.update(PLEQMbXcUIgRFvpVBOAKqDaHTfGxho)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   if not('result' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']):return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['result']
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY in PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlr=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['program']['code']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['program']['name']['ko']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC =PLEQMbXcUIgRFvpVBOAKqDaHTfGxey.get(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['program'].get('grade_code'))
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo =''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxys =''
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['program']['image']:
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP0900':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP0200':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP1800':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP2000':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP1900':PLEQMbXcUIgRFvpVBOAKqDaHTfGxys =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['program']['synopsis']['ko']
    try:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlz=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['channel']['name']['ko']
    except:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlz=''
    try:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi =[]
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS=[]
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu =[]
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ =''
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxym=''
     for PLEQMbXcUIgRFvpVBOAKqDaHTfGxle in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('program').get('actor'):
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxle!='' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxle!='-' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxle!=u'없음':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxle)
     for PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('program').get('director'):
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh!='' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh!='-' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh!=u'없음':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh)
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('program').get('category1_name').get('ko')!='':
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['program']['category1_name']['ko'])
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('program').get('category2_name').get('ko')!='':
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['program']['category2_name']['ko'])
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('program').get('product_year'):PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['program']['product_year']
     if 'broad_dt' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('program'):
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxln =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('program').get('broad_dt')
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxym='%s-%s-%s'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[:4],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[4:6],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[6:])
    except:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxld={'program':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlr,'title':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW,'thumbnail':{'poster':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj,'thumb':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt,'clearlogo':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN,'icon':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo,'banner':PLEQMbXcUIgRFvpVBOAKqDaHTfGxys,'fanart':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt},'synopsis':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk,'channel':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlz,'cast':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi,'director':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS,'info_genre':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu,'year':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ,'premiered':PLEQMbXcUIgRFvpVBOAKqDaHTfGxym,'mpaa':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC}
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxht.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxld)
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['has_more']=='Y':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
 def Get_UHD_ProgramList(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,page_int):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxht=[]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v2/operator/highlights'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams(uhd=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(page_int),'pocType':'APP_X_TVING_4.0.0',}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC.update(PLEQMbXcUIgRFvpVBOAKqDaHTfGxho)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   if not('result' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']):return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['result']
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY in PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['content']['program']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlk =PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['code']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW =PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['name']['ko'].strip()
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC =PLEQMbXcUIgRFvpVBOAKqDaHTfGxey.get(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW.get('grade_code'))
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk =PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['synopsis']['ko']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlz =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['content']['channel']['name']['ko']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ =PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['product_year']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo =''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxys =''
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw in PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['image']:
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP0900':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP0200':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP1800':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP2000':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP1900':PLEQMbXcUIgRFvpVBOAKqDaHTfGxys =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu =[]
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi =[]
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS=[]
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxym =''
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW.get('category1_name').get('ko')!='':
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['category1_name']['ko'])
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW.get('category2_name').get('ko')!='':
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['category2_name']['ko'])
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxle in PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW.get('actor'):
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxle!='' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxle!='-' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxle!=u'없음':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxle)
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh in PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW.get('director'):
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh!='' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh!='-' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh!=u'없음':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh)
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW.get('broad_dt')not in[PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,'']:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxln =PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW.get('broad_dt')
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxym='%s-%s-%s'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[:4],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[4:6],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[6:])
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxld={'program':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlk,'title':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW,'mpaa':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC,'thumbnail':{'poster':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj,'thumb':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt,'clearlogo':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN,'icon':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo,'banner':PLEQMbXcUIgRFvpVBOAKqDaHTfGxys,'fanart':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt},'channel':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlz,'synopsis':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk,'year':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ,'info_genre':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu,'cast':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi,'director':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS,'premiered':PLEQMbXcUIgRFvpVBOAKqDaHTfGxym,}
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxht.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxld)
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
 def Get_Origianl_ProgramList(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,page_int):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxht=[]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v2/media/band/originals'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'pageSize':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(page_int),}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC.update(PLEQMbXcUIgRFvpVBOAKqDaHTfGxho)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   if not('contents' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']):return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['contents']
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY in PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlr=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['vod_code']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['vod_name']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['image']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxld={'program':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlr,'title':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW,'thumbnail':{'poster':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj,'thumb':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj}}
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxht.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxld)
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['has_more']=='Y':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
 def GetEpisodeList(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,program_code,page_int,orderby='desc'):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxht=[]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v2/media/frequency/program/'+program_code
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC.update(PLEQMbXcUIgRFvpVBOAKqDaHTfGxho)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   if not('result' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']):return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['result']
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxlt=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrd(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['total_count'])
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxlj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxrd(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlt//(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlN =(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlt-1)-((page_int-1)*PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.EPISODE_LIMIT)
   else:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlN =(page_int-1)*PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.EPISODE_LIMIT
   for i in PLEQMbXcUIgRFvpVBOAKqDaHTfGxrz(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.EPISODE_LIMIT):
    if orderby=='desc':
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo=PLEQMbXcUIgRFvpVBOAKqDaHTfGxlN-i
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo<0:break
    else:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo=PLEQMbXcUIgRFvpVBOAKqDaHTfGxlN+i
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo>=PLEQMbXcUIgRFvpVBOAKqDaHTfGxlt:break
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxls=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl[PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo]['episode']['code']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW =PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl[PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo]['vod_name']['ko']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlY =''
    try:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxln=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl[PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo]['episode']['broadcast_date'])
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlY='%s-%s-%s'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[:4],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[4:6],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[6:])
    except:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh
    try:
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl[PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo]['episode']['pip_cliptype']=='C012':
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxlY+=' - Quick VOD'
    except:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk =PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl[PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo]['episode']['synopsis']['ko']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo =''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxys =''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyY =''
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw in PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl[PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo]['program']['image']:
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP0900':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP1800':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP2000':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP1900':PLEQMbXcUIgRFvpVBOAKqDaHTfGxys =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIP0200':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyY =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw in PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl[PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo]['episode']['image']:
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIE0400':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
    try:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlw=PLEQMbXcUIgRFvpVBOAKqDaHTfGxlS=PLEQMbXcUIgRFvpVBOAKqDaHTfGxlu=''
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxli=0
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlw =PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl[PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo]['program']['name']['ko']
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlS =PLEQMbXcUIgRFvpVBOAKqDaHTfGxlY
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlu =PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl[PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo]['channel']['name']['ko']
     if 'frequency' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl[PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo]['episode']:PLEQMbXcUIgRFvpVBOAKqDaHTfGxli=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl[PLEQMbXcUIgRFvpVBOAKqDaHTfGxlo]['episode']['frequency']
    except:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxld={'episode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxls,'title':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW,'subtitle':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlY,'thumbnail':{'poster':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj,'thumb':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt,'clearlogo':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN,'icon':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo,'banner':PLEQMbXcUIgRFvpVBOAKqDaHTfGxys,'fanart':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyY},'synopsis':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk,'info_title':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlw,'aired':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlS,'studio':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlu,'frequency':PLEQMbXcUIgRFvpVBOAKqDaHTfGxli}
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxht.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxld)
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlj>page_int:PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh,PLEQMbXcUIgRFvpVBOAKqDaHTfGxlj
 def GetMovieList(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,genre,orderby,page_int):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxht=[]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  try:
   if genre=='PARAMOUNT':
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v2/media/paramount/movies'
   else:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v2/media/movies'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'pageSize':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:PLEQMbXcUIgRFvpVBOAKqDaHTfGxho['categoryCode']=genre
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho['productPackageCode']=','.join(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.MOVIE_LITE)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC.update(PLEQMbXcUIgRFvpVBOAKqDaHTfGxho)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   if not('result' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']):return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['result']
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY in PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl:
    if 'release_date' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('movie'):
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('movie').get('release_date'))[:4]
    else:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlJ =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['movie']['code']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['movie']['name']['ko'].strip()
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ not in[PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,'0','']:PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW+=u' (%s)'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ)
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj=''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=''
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['movie']['image']:
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIM2100':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIM0400':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIM1800':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['movie']['story']['ko']
    try:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlw =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['movie']['name']['ko'].strip()
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC =PLEQMbXcUIgRFvpVBOAKqDaHTfGxey.get(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('grade_code'))
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi=[]
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS=[]
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu=[]
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlC=0
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxym=''
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlu =''
     for PLEQMbXcUIgRFvpVBOAKqDaHTfGxle in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('movie').get('actor'):
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxle!='':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxle)
     for PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('movie').get('director'):
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh!='':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh)
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('movie').get('category1_name').get('ko')!='':
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['movie']['category1_name']['ko'])
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('movie').get('category2_name').get('ko')!='':
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['movie']['category2_name']['ko'])
     if 'duration' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('movie'):PLEQMbXcUIgRFvpVBOAKqDaHTfGxlC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('movie').get('duration')
     if 'release_date' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('movie'):
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxln=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('movie').get('release_date'))
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxln!='0':PLEQMbXcUIgRFvpVBOAKqDaHTfGxym='%s-%s-%s'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[:4],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[4:6],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[6:])
     if 'production' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('movie'):PLEQMbXcUIgRFvpVBOAKqDaHTfGxlu=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('movie').get('production')
    except:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxld={'moviecode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlJ,'title':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW,'thumbnail':{'poster':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj,'thumb':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt,'clearlogo':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN,'fanart':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt},'synopsis':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk,'info_title':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlw,'year':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ,'cast':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi,'director':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS,'info_genre':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu,'duration':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlC,'premiered':PLEQMbXcUIgRFvpVBOAKqDaHTfGxym,'studio':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlu,'mpaa':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC}
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxde in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['billing_package_id']:
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxde in PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.MOVIE_LITE:
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxlm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
      break
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlm==PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn: 
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxld['title']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxld['title']+' [개별구매]'
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxht.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxld)
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['has_more']=='Y':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
 def Get_UHD_MovieList(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,page_int):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxht=[]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v2/operator/highlights'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams(uhd=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(page_int),'pocType':'APP_X_TVING_4.0.0',}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC.update(PLEQMbXcUIgRFvpVBOAKqDaHTfGxho)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   if not('result' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']):return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['result']
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY in PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['content']['movie']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlk =PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['code']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW =PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['name']['ko'].strip()
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlw =PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['name']['ko'].strip()
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ =PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['product_year']
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ:PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW+=u' (%s)'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['product_year'])
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk =PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['story']['ko']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlC =PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['duration']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC =PLEQMbXcUIgRFvpVBOAKqDaHTfGxey.get(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW.get('grade_code'))
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxlu =PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['production']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj=''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=''
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu =[]
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi =[]
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS=[]
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxym =''
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw in PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['image']:
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIM2100':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIM0400':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
     elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['code']=='CAIM1800':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw['url']
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['release_date']not in[PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,0]:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxln=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['release_date'])
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxln!='0':PLEQMbXcUIgRFvpVBOAKqDaHTfGxym='%s-%s-%s'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[:4],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[4:6],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[6:])
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW.get('category1_name').get('ko')!='':
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['category1_name']['ko'])
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW.get('category2_name').get('ko')!='':
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW['category2_name']['ko'])
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxle in PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW.get('actor'):
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxle!='':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxle)
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh in PLEQMbXcUIgRFvpVBOAKqDaHTfGxlW.get('director'):
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh!='':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxlh)
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxld={'moviecode':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlk,'title':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW,'thumbnail':{'poster':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj,'thumb':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt,'clearlogo':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN,'fanart':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt},'year':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ,'info_title':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlw,'synopsis':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyk,'mpaa':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC,'duration':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlC,'premiered':PLEQMbXcUIgRFvpVBOAKqDaHTfGxym,'studio':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlu,'info_genre':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu,'cast':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi,'director':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS,}
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxht.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxld)
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
 def GetMovieGenre(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxht=[]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v2/media/movie/curations'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC.update(PLEQMbXcUIgRFvpVBOAKqDaHTfGxho)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   if not('result' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']):return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['result']
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY in PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxdh =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['curation_code']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxdn =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['curation_name']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxld={'curation_code':PLEQMbXcUIgRFvpVBOAKqDaHTfGxdh,'curation_name':PLEQMbXcUIgRFvpVBOAKqDaHTfGxdn}
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxht.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxld)
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
 def GetSearchList(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,search_key,page_int,stype):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxdy=[]
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/search/getSearch.jsp'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(page_int),'pageSize':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.SCREENCODE,'os':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.OSCODE,'network':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.SEARCH_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxho,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   if stype=='vod':
    if not('programRsb' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs):return PLEQMbXcUIgRFvpVBOAKqDaHTfGxdy,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxdl=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['programRsb']['dataList']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxdr =PLEQMbXcUIgRFvpVBOAKqDaHTfGxrd(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['programRsb']['count'])
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY in PLEQMbXcUIgRFvpVBOAKqDaHTfGxdl:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlr=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['mast_cd']
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['mast_nm']
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['web_url4']
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['web_url']
     try:
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi =[]
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS=[]
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu =[]
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxlC =0
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC =''
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ =''
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxlS =''
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('actor') !='' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('actor') !='-':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('actor').split(',')
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('director')!='' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('director')!='-':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('director').split(',')
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('cate_nm')!='' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('cate_nm')!='-':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('cate_nm').split('/')
      if 'targetage' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY:PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('targetage')
      if 'broad_dt' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY:
       PLEQMbXcUIgRFvpVBOAKqDaHTfGxln=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('broad_dt')
       PLEQMbXcUIgRFvpVBOAKqDaHTfGxlS='%s-%s-%s'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[:4],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[4:6],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[6:])
       PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ =PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[:4]
     except:
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxld={'program':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlr,'title':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW,'thumbnail':{'poster':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj,'thumb':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt,'fanart':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt},'synopsis':'','cast':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi,'director':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS,'info_genre':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu,'duration':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlC,'mpaa':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC,'year':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ,'aired':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlS}
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxdy.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxld)
   else:
    if not('vodMVRsb' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs):return PLEQMbXcUIgRFvpVBOAKqDaHTfGxdy,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxdz=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['vodMVRsb']['dataList']
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxdr =PLEQMbXcUIgRFvpVBOAKqDaHTfGxrd(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['vodMVRsb']['count'])
    for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY in PLEQMbXcUIgRFvpVBOAKqDaHTfGxdz:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlr=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['mast_cd']
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['mast_nm'].strip()
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['web_url']
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=''
     try:
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi =[]
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS=[]
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu =[]
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxlC =0
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC =''
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ =''
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxlS =''
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('actor') !='' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('actor') !='-':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('actor').split(',')
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('director')!='' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('director')!='-':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('director').split(',')
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('cate_nm')!='' and PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('cate_nm')!='-':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu =PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('cate_nm').split('/')
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('runtime_sec')!='':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('runtime_sec')
      if 'grade_nm' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY:PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('grade_nm')
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxln=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('broad_dt')
      if data_str!='':
       PLEQMbXcUIgRFvpVBOAKqDaHTfGxlS='%s-%s-%s'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[:4],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[4:6],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[6:])
       PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ =PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[:4]
     except:
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxld={'movie':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlr,'title':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW,'thumbnail':{'poster':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj,'thumb':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt,'fanart':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt,'clearlogo':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN},'synopsis':'','cast':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyi,'director':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyS,'info_genre':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyu,'duration':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlC,'mpaa':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyC,'year':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyJ,'aired':PLEQMbXcUIgRFvpVBOAKqDaHTfGxlS}
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxlm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn
     for PLEQMbXcUIgRFvpVBOAKqDaHTfGxde in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY['bill']:
      if PLEQMbXcUIgRFvpVBOAKqDaHTfGxde in PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.MOVIE_LITE:
       PLEQMbXcUIgRFvpVBOAKqDaHTfGxlm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
       break
     if PLEQMbXcUIgRFvpVBOAKqDaHTfGxlm==PLEQMbXcUIgRFvpVBOAKqDaHTfGxrn: 
      PLEQMbXcUIgRFvpVBOAKqDaHTfGxld['title']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxld['title']+' [개별구매]'
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxdy.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxld)
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxdr>(page_int*PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.SEARCH_LIMIT):PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrl
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxdy,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
 def GetBookmarkInfo(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,videoid,vidtype):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+'/v2/media/program/'+videoid
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'pageNo':'1','pageSize':'10','order':'name',}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC.update(PLEQMbXcUIgRFvpVBOAKqDaHTfGxho)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdk=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   if not('body' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxdk):return{}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt=PLEQMbXcUIgRFvpVBOAKqDaHTfGxdk['body']
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW=PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('name').get('ko').strip()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['title'] =PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['title']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['mpaa'] =PLEQMbXcUIgRFvpVBOAKqDaHTfGxey.get(PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('grade_code'))
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['plot'] =PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('synopsis').get('ko')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['year'] =PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('product_year')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['cast'] =PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('actor')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['director']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('director')
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('category1_name').get('ko')!='':
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['genre'].append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('category1_name').get('ko'))
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('category2_name').get('ko')!='':
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['genre'].append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('category2_name').get('ko'))
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxln=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('broad_dt'))
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxln!='0':PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[:4],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[4:6],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[6:])
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =''
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =''
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=''
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo =''
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxys =''
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw in PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('image'):
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('code')=='CAIP0900':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('url')
    elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('code')=='CAIP0200':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('url')
    elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('code')=='CAIP1800':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('url')
    elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('code')=='CAIP2000':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('url')
    elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('code')=='CAIP1900':PLEQMbXcUIgRFvpVBOAKqDaHTfGxys =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('url')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['thumbnail']['poster']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['thumbnail']['thumb']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['thumbnail']['clearlogo']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['thumbnail']['icon']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyo
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['thumbnail']['banner']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxys
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['thumbnail']['fanart']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt
  else:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+'/v2a/media/stream/info'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_uuid'].split('-')[0],'uuid':PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetNoCache(1)),'wm':'Y',}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC.update(PLEQMbXcUIgRFvpVBOAKqDaHTfGxho)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdk=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   if not('content' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxdk['body']):return{}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt=PLEQMbXcUIgRFvpVBOAKqDaHTfGxdk['body']['content']['info']['movie']
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW =PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('name').get('ko').strip()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['title']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW +=u' (%s)'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('product_year'))
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['title'] =PLEQMbXcUIgRFvpVBOAKqDaHTfGxyW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['mpaa'] =PLEQMbXcUIgRFvpVBOAKqDaHTfGxey.get(PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('grade_code'))
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['plot'] =PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('story').get('ko')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['year'] =PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('product_year')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['studio'] =PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('production')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['duration']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('duration')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['cast'] =PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('actor')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['director']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('director')
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('category1_name').get('ko')!='':
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['genre'].append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('category1_name').get('ko'))
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('category2_name').get('ko')!='':
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['genre'].append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('category2_name').get('ko'))
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxln=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('release_date'))
   if PLEQMbXcUIgRFvpVBOAKqDaHTfGxln!='0':PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[:4],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[4:6],PLEQMbXcUIgRFvpVBOAKqDaHTfGxln[6:])
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj=''
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =''
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=''
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw in PLEQMbXcUIgRFvpVBOAKqDaHTfGxdt.get('image'):
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('code')=='CAIM2100':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('url')
    elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('code')=='CAIM0400':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('url')
    elif PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('code')=='CAIM1800':PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.IMG_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxyw.get('url')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['thumbnail']['poster']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['thumbnail']['thumb']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyj 
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['thumbnail']['clearlogo']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyN
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW['saveinfo']['thumbnail']['fanart']=PLEQMbXcUIgRFvpVBOAKqDaHTfGxyt
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxdW
 def GetEuroChannelList(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxht=[]
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW ='/v2/operator/highlights'
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetDefaultParams()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxho={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':PLEQMbXcUIgRFvpVBOAKqDaHTfGxrt(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.GetNoCache(2))}
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC.update(PLEQMbXcUIgRFvpVBOAKqDaHTfGxho)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.API_DOMAIN+PLEQMbXcUIgRFvpVBOAKqDaHTfGxhW
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.callRequestCookies('Get',PLEQMbXcUIgRFvpVBOAKqDaHTfGxhm,payload=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,params=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhC,headers=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh,cookies=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrh)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhy.text)
   if not('result' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']):return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht,PLEQMbXcUIgRFvpVBOAKqDaHTfGxyh
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl=PLEQMbXcUIgRFvpVBOAKqDaHTfGxhs['body']['result']
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdj =PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.Get_Now_Datetime()
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdN=PLEQMbXcUIgRFvpVBOAKqDaHTfGxdj+datetime.timedelta(days=-1)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdN=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrd(PLEQMbXcUIgRFvpVBOAKqDaHTfGxdN.strftime('%Y%m%d'))
   for PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY in PLEQMbXcUIgRFvpVBOAKqDaHTfGxyl:
    PLEQMbXcUIgRFvpVBOAKqDaHTfGxdo=PLEQMbXcUIgRFvpVBOAKqDaHTfGxrd(PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('content').get('banner_title2')[:8])
    if PLEQMbXcUIgRFvpVBOAKqDaHTfGxdN<=PLEQMbXcUIgRFvpVBOAKqDaHTfGxdo:
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxld={'channel':PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('content').get('banner_sub_title3'),'title':PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('content').get('banner_title'),'subtitle':PLEQMbXcUIgRFvpVBOAKqDaHTfGxhY.get('content').get('banner_sub_title2'),}
     PLEQMbXcUIgRFvpVBOAKqDaHTfGxht.append(PLEQMbXcUIgRFvpVBOAKqDaHTfGxld)
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxht
 def Make_DecryptKey(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,step,mediacode='000',timecode='000'):
  if step=='1':
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxds=PLEQMbXcUIgRFvpVBOAKqDaHTfGxro('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdY=PLEQMbXcUIgRFvpVBOAKqDaHTfGxro('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxds=PLEQMbXcUIgRFvpVBOAKqDaHTfGxro('kss2lym0kdw1lks3','utf-8')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdY=PLEQMbXcUIgRFvpVBOAKqDaHTfGxro([PLEQMbXcUIgRFvpVBOAKqDaHTfGxrs('*'),0x07,PLEQMbXcUIgRFvpVBOAKqDaHTfGxrs('r'),PLEQMbXcUIgRFvpVBOAKqDaHTfGxrs(';'),PLEQMbXcUIgRFvpVBOAKqDaHTfGxrs('7'),0x05,0x1e,0x01,PLEQMbXcUIgRFvpVBOAKqDaHTfGxrs('n'),PLEQMbXcUIgRFvpVBOAKqDaHTfGxrs('D'),0x02,PLEQMbXcUIgRFvpVBOAKqDaHTfGxrs('3'),PLEQMbXcUIgRFvpVBOAKqDaHTfGxrs('*'),PLEQMbXcUIgRFvpVBOAKqDaHTfGxrs('a'),PLEQMbXcUIgRFvpVBOAKqDaHTfGxrs('&'),PLEQMbXcUIgRFvpVBOAKqDaHTfGxrs('<')])
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxds,PLEQMbXcUIgRFvpVBOAKqDaHTfGxdY
 def DecryptPlaintext(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,ciphertext,encryption_key,init_vector):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxdw=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxdi=Padding.unpad(PLEQMbXcUIgRFvpVBOAKqDaHTfGxdw.decrypt(base64.standard_b64decode(ciphertext)),16)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxdi.decode('utf-8')
 def Decrypt_Url(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel,ciphertext,mediacode,PLEQMbXcUIgRFvpVBOAKqDaHTfGxnr):
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxdS=''
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxnz=''
  PLEQMbXcUIgRFvpVBOAKqDaHTfGxnW=''
  try:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxds,PLEQMbXcUIgRFvpVBOAKqDaHTfGxdY=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.Make_DecryptKey('1',mediacode=mediacode,timecode=PLEQMbXcUIgRFvpVBOAKqDaHTfGxnr)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdu=json.loads(PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.DecryptPlaintext(ciphertext,PLEQMbXcUIgRFvpVBOAKqDaHTfGxds,PLEQMbXcUIgRFvpVBOAKqDaHTfGxdY))
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdJ =PLEQMbXcUIgRFvpVBOAKqDaHTfGxdu.get('broad_url')
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxnz =PLEQMbXcUIgRFvpVBOAKqDaHTfGxdu.get('watermark') if 'watermark' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxdu else ''
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxnW=PLEQMbXcUIgRFvpVBOAKqDaHTfGxdu.get('watermarkKey')if 'watermarkKey' in PLEQMbXcUIgRFvpVBOAKqDaHTfGxdu else ''
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxds,PLEQMbXcUIgRFvpVBOAKqDaHTfGxdY=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.Make_DecryptKey('2',mediacode=mediacode,timecode=PLEQMbXcUIgRFvpVBOAKqDaHTfGxnr)
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdS=PLEQMbXcUIgRFvpVBOAKqDaHTfGxel.DecryptPlaintext(PLEQMbXcUIgRFvpVBOAKqDaHTfGxdJ,PLEQMbXcUIgRFvpVBOAKqDaHTfGxds,PLEQMbXcUIgRFvpVBOAKqDaHTfGxdY)
  except PLEQMbXcUIgRFvpVBOAKqDaHTfGxrW as exception:
   PLEQMbXcUIgRFvpVBOAKqDaHTfGxdC(exception)
  return PLEQMbXcUIgRFvpVBOAKqDaHTfGxdS,PLEQMbXcUIgRFvpVBOAKqDaHTfGxnz,PLEQMbXcUIgRFvpVBOAKqDaHTfGxnW
# Created by pyminifier (https://github.com/liftoff/pyminifier)
