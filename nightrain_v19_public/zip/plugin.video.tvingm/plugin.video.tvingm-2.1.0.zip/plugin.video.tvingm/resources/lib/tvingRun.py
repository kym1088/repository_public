__author__="NightRain"
zJOAYINCxKWoVMuhvXTFmHerbDkwsd=object
zJOAYINCxKWoVMuhvXTFmHerbDkwRp=None
zJOAYINCxKWoVMuhvXTFmHerbDkwRt=False
zJOAYINCxKWoVMuhvXTFmHerbDkwRq=True
zJOAYINCxKWoVMuhvXTFmHerbDkwRa=int
zJOAYINCxKWoVMuhvXTFmHerbDkwRs=len
zJOAYINCxKWoVMuhvXTFmHerbDkwRf=str
zJOAYINCxKWoVMuhvXTFmHerbDkwRi=open
zJOAYINCxKWoVMuhvXTFmHerbDkwRc=dict
zJOAYINCxKWoVMuhvXTFmHerbDkwRj=Exception
zJOAYINCxKWoVMuhvXTFmHerbDkwRU=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
zJOAYINCxKWoVMuhvXTFmHerbDkwpq=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 (인기순)','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 (최신순)','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'월정액 영화관 (인기)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'-'},{'title':'월정액 영화관 (최신)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
zJOAYINCxKWoVMuhvXTFmHerbDkwpa=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
zJOAYINCxKWoVMuhvXTFmHerbDkwps=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
zJOAYINCxKWoVMuhvXTFmHerbDkwpR=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
zJOAYINCxKWoVMuhvXTFmHerbDkwpf=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'PROGRAM','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
zJOAYINCxKWoVMuhvXTFmHerbDkwpi={'C00551':'tvN','C00544':'중화TV','C00575':'Olive','C00579':'Mnet','C00590':'OGN','C01141':'XtvN','C01142':'ONSTYLE','C01143':'OtvN','C04601':'CGV','C06941':'tooniverse','C07381':'OCN','C07382':'SUPER ACTION','C15251':'OGN x LOL','C15252':'OGN x 오버워치','C15042':'티빙라이브','C01581':'TV CHOSUN','C01583':'채널A','C00708':'MBN','C00593':'YTN','C01101':'YTN Life','C15347':'YTN science','C01723':'연합뉴스TV','C15152':'DIA TV','C01582':'JTBC','C00588':'JTBC Golf','C15741':'JTBC2','C00805':'JTBC3 FOX Sports','C05661':'디즈니채널','C18641':'IHQ','C22041':'JTBC4','C23343':'t.cast','C23441':'E channel','C17341':'히스토리','C00585':'TV CHOSUN2','C17141':'채널A 플러스','C00611':'LIFETIME','C08041':'tvN go','C05901':'채널W','C23442':"D'LIVE",'C27441':'KBS N'}
zJOAYINCxKWoVMuhvXTFmHerbDkwpc ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
zJOAYINCxKWoVMuhvXTFmHerbDkwpj=xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class zJOAYINCxKWoVMuhvXTFmHerbDkwpt(zJOAYINCxKWoVMuhvXTFmHerbDkwsd):
 def __init__(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwpy,zJOAYINCxKWoVMuhvXTFmHerbDkwpQ,zJOAYINCxKWoVMuhvXTFmHerbDkwpG):
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_url =zJOAYINCxKWoVMuhvXTFmHerbDkwpy
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_handle=zJOAYINCxKWoVMuhvXTFmHerbDkwpQ
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.main_params =zJOAYINCxKWoVMuhvXTFmHerbDkwpG
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj =iNBAmXQcetsguwTxSlMUpRrIzoGLHj() 
 def addon_noti(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,sting):
  try:
   zJOAYINCxKWoVMuhvXTFmHerbDkwpl=xbmcgui.Dialog()
   zJOAYINCxKWoVMuhvXTFmHerbDkwpl.notification(__addonname__,sting)
  except:
   zJOAYINCxKWoVMuhvXTFmHerbDkwRp
 def addon_log(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,string):
  try:
   zJOAYINCxKWoVMuhvXTFmHerbDkwpB=string.encode('utf-8','ignore')
  except:
   zJOAYINCxKWoVMuhvXTFmHerbDkwpB='addonException: addon_log'
  zJOAYINCxKWoVMuhvXTFmHerbDkwpn=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,zJOAYINCxKWoVMuhvXTFmHerbDkwpB),level=zJOAYINCxKWoVMuhvXTFmHerbDkwpn)
 def get_keyboard_input(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwtf):
  zJOAYINCxKWoVMuhvXTFmHerbDkwpS=zJOAYINCxKWoVMuhvXTFmHerbDkwRp
  kb=xbmc.Keyboard()
  kb.setHeading(zJOAYINCxKWoVMuhvXTFmHerbDkwtf)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   zJOAYINCxKWoVMuhvXTFmHerbDkwpS=kb.getText()
  return zJOAYINCxKWoVMuhvXTFmHerbDkwpS
 def get_settings_login_info(zJOAYINCxKWoVMuhvXTFmHerbDkwpU):
  zJOAYINCxKWoVMuhvXTFmHerbDkwpP =__addon__.getSetting('id')
  zJOAYINCxKWoVMuhvXTFmHerbDkwpL =__addon__.getSetting('pw')
  zJOAYINCxKWoVMuhvXTFmHerbDkwpE =__addon__.getSetting('login_type')
  return(zJOAYINCxKWoVMuhvXTFmHerbDkwpP,zJOAYINCxKWoVMuhvXTFmHerbDkwpL,zJOAYINCxKWoVMuhvXTFmHerbDkwpE)
 def get_settings_premiumyn(zJOAYINCxKWoVMuhvXTFmHerbDkwpU):
  zJOAYINCxKWoVMuhvXTFmHerbDkwpd =__addon__.getSetting('premium_movieyn')
  if zJOAYINCxKWoVMuhvXTFmHerbDkwpd=='false':
   return zJOAYINCxKWoVMuhvXTFmHerbDkwRt
  else:
   return zJOAYINCxKWoVMuhvXTFmHerbDkwRq
 def get_settings_direct_replay(zJOAYINCxKWoVMuhvXTFmHerbDkwpU):
  zJOAYINCxKWoVMuhvXTFmHerbDkwtp=zJOAYINCxKWoVMuhvXTFmHerbDkwRa(__addon__.getSetting('direct_replay'))
  if zJOAYINCxKWoVMuhvXTFmHerbDkwtp==0:
   return zJOAYINCxKWoVMuhvXTFmHerbDkwRt
  else:
   return zJOAYINCxKWoVMuhvXTFmHerbDkwRq
 def get_settings_thumbnail_landyn(zJOAYINCxKWoVMuhvXTFmHerbDkwpU):
  zJOAYINCxKWoVMuhvXTFmHerbDkwtq =zJOAYINCxKWoVMuhvXTFmHerbDkwRa(__addon__.getSetting('thumbnail_way'))
  if zJOAYINCxKWoVMuhvXTFmHerbDkwtq==0:
   return zJOAYINCxKWoVMuhvXTFmHerbDkwRq
  else:
   return zJOAYINCxKWoVMuhvXTFmHerbDkwRt
 def set_winCredential(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,credential):
  zJOAYINCxKWoVMuhvXTFmHerbDkwta=xbmcgui.Window(10000)
  zJOAYINCxKWoVMuhvXTFmHerbDkwta.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  zJOAYINCxKWoVMuhvXTFmHerbDkwta.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  zJOAYINCxKWoVMuhvXTFmHerbDkwta.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  zJOAYINCxKWoVMuhvXTFmHerbDkwta.setProperty('TVING_M_LOGINTIME',zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(zJOAYINCxKWoVMuhvXTFmHerbDkwpU):
  zJOAYINCxKWoVMuhvXTFmHerbDkwta=xbmcgui.Window(10000)
  zJOAYINCxKWoVMuhvXTFmHerbDkwts={'tving_token':zJOAYINCxKWoVMuhvXTFmHerbDkwta.getProperty('TVING_M_TOKEN'),'poc_userinfo':zJOAYINCxKWoVMuhvXTFmHerbDkwta.getProperty('TVING_M_USERINFO'),'tving_uuid':zJOAYINCxKWoVMuhvXTFmHerbDkwta.getProperty('TVING_M_UUID')}
  return zJOAYINCxKWoVMuhvXTFmHerbDkwts
 def set_winEpisodeOrderby(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwqG):
  zJOAYINCxKWoVMuhvXTFmHerbDkwta=xbmcgui.Window(10000)
  zJOAYINCxKWoVMuhvXTFmHerbDkwta.setProperty('TVING_M_ORDERBY',zJOAYINCxKWoVMuhvXTFmHerbDkwqG)
 def get_winEpisodeOrderby(zJOAYINCxKWoVMuhvXTFmHerbDkwpU):
  zJOAYINCxKWoVMuhvXTFmHerbDkwta=xbmcgui.Window(10000)
  return zJOAYINCxKWoVMuhvXTFmHerbDkwta.getProperty('TVING_M_ORDERBY')
 def add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,label,sublabel='',img='',infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwRp,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRq,params=''):
  zJOAYINCxKWoVMuhvXTFmHerbDkwtR='%s?%s'%(zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_url,urllib.parse.urlencode(params))
  if sublabel:zJOAYINCxKWoVMuhvXTFmHerbDkwtf='%s < %s >'%(label,sublabel)
  else: zJOAYINCxKWoVMuhvXTFmHerbDkwtf=label
  if not img:img='DefaultFolder.png'
  zJOAYINCxKWoVMuhvXTFmHerbDkwti=xbmcgui.ListItem(zJOAYINCxKWoVMuhvXTFmHerbDkwtf)
  zJOAYINCxKWoVMuhvXTFmHerbDkwti.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:zJOAYINCxKWoVMuhvXTFmHerbDkwti.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:zJOAYINCxKWoVMuhvXTFmHerbDkwti.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_handle,zJOAYINCxKWoVMuhvXTFmHerbDkwtR,zJOAYINCxKWoVMuhvXTFmHerbDkwti,isFolder)
 def get_selQuality(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,etype):
  try:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtc='selected_quality'
   zJOAYINCxKWoVMuhvXTFmHerbDkwtj=[1080,720,480,360]
   zJOAYINCxKWoVMuhvXTFmHerbDkwtU=zJOAYINCxKWoVMuhvXTFmHerbDkwRa(__addon__.getSetting(zJOAYINCxKWoVMuhvXTFmHerbDkwtc))
   return zJOAYINCxKWoVMuhvXTFmHerbDkwtj[zJOAYINCxKWoVMuhvXTFmHerbDkwtU]
  except:
   zJOAYINCxKWoVMuhvXTFmHerbDkwRp
  return 720 
 def dp_Main_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU):
  for zJOAYINCxKWoVMuhvXTFmHerbDkwty in zJOAYINCxKWoVMuhvXTFmHerbDkwpq:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf=zJOAYINCxKWoVMuhvXTFmHerbDkwty.get('title')
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':zJOAYINCxKWoVMuhvXTFmHerbDkwty.get('mode'),'stype':zJOAYINCxKWoVMuhvXTFmHerbDkwty.get('stype'),'orderby':zJOAYINCxKWoVMuhvXTFmHerbDkwty.get('orderby'),'ordernm':zJOAYINCxKWoVMuhvXTFmHerbDkwty.get('ordernm'),'page':'1'}
   if zJOAYINCxKWoVMuhvXTFmHerbDkwty.get('mode')=='XXX':
    zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['mode']='XXX'
    zJOAYINCxKWoVMuhvXTFmHerbDkwtG=zJOAYINCxKWoVMuhvXTFmHerbDkwRt
   else:
    zJOAYINCxKWoVMuhvXTFmHerbDkwtG=zJOAYINCxKWoVMuhvXTFmHerbDkwRq
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel='',img='',infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwRp,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwtG,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwRs(zJOAYINCxKWoVMuhvXTFmHerbDkwpq)>0:xbmcplugin.endOfDirectory(zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_handle)
 def login_main(zJOAYINCxKWoVMuhvXTFmHerbDkwpU):
  (zJOAYINCxKWoVMuhvXTFmHerbDkwtl,zJOAYINCxKWoVMuhvXTFmHerbDkwtB,zJOAYINCxKWoVMuhvXTFmHerbDkwtn)=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_settings_login_info()
  if not(zJOAYINCxKWoVMuhvXTFmHerbDkwtl and zJOAYINCxKWoVMuhvXTFmHerbDkwtB):
   zJOAYINCxKWoVMuhvXTFmHerbDkwpl=xbmcgui.Dialog()
   zJOAYINCxKWoVMuhvXTFmHerbDkwtS=zJOAYINCxKWoVMuhvXTFmHerbDkwpl.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if zJOAYINCxKWoVMuhvXTFmHerbDkwtS==zJOAYINCxKWoVMuhvXTFmHerbDkwRq:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_winEpisodeOrderby()=='':
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.set_winEpisodeOrderby('desc')
  if zJOAYINCxKWoVMuhvXTFmHerbDkwpU.cookiefile_check():return
  zJOAYINCxKWoVMuhvXTFmHerbDkwtP =zJOAYINCxKWoVMuhvXTFmHerbDkwRa(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  zJOAYINCxKWoVMuhvXTFmHerbDkwtL=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if zJOAYINCxKWoVMuhvXTFmHerbDkwtL==zJOAYINCxKWoVMuhvXTFmHerbDkwRp or zJOAYINCxKWoVMuhvXTFmHerbDkwtL=='':
   zJOAYINCxKWoVMuhvXTFmHerbDkwtL=zJOAYINCxKWoVMuhvXTFmHerbDkwRa('19000101')
  else:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtL=zJOAYINCxKWoVMuhvXTFmHerbDkwRa(re.sub('-','',zJOAYINCxKWoVMuhvXTFmHerbDkwtL))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   zJOAYINCxKWoVMuhvXTFmHerbDkwtE=0
   while zJOAYINCxKWoVMuhvXTFmHerbDkwRq:
    zJOAYINCxKWoVMuhvXTFmHerbDkwtE+=1
    time.sleep(0.05)
    if zJOAYINCxKWoVMuhvXTFmHerbDkwtL>=zJOAYINCxKWoVMuhvXTFmHerbDkwtP:return
    if zJOAYINCxKWoVMuhvXTFmHerbDkwtE>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if zJOAYINCxKWoVMuhvXTFmHerbDkwtL>=zJOAYINCxKWoVMuhvXTFmHerbDkwtP:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.GetCredential(zJOAYINCxKWoVMuhvXTFmHerbDkwtl,zJOAYINCxKWoVMuhvXTFmHerbDkwtB,zJOAYINCxKWoVMuhvXTFmHerbDkwtn):
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.set_winCredential(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.LoadCredential())
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwqa):
  zJOAYINCxKWoVMuhvXTFmHerbDkwtd=zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('stype')
  if zJOAYINCxKWoVMuhvXTFmHerbDkwtd=='live':
   zJOAYINCxKWoVMuhvXTFmHerbDkwqp=zJOAYINCxKWoVMuhvXTFmHerbDkwpa
  else:
   zJOAYINCxKWoVMuhvXTFmHerbDkwqp=zJOAYINCxKWoVMuhvXTFmHerbDkwpf
  for zJOAYINCxKWoVMuhvXTFmHerbDkwqt in zJOAYINCxKWoVMuhvXTFmHerbDkwqp:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf=zJOAYINCxKWoVMuhvXTFmHerbDkwqt.get('title')
   if zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('ordernm')!='-':
    zJOAYINCxKWoVMuhvXTFmHerbDkwtf+='  ('+zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('ordernm')+')'
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':zJOAYINCxKWoVMuhvXTFmHerbDkwqt.get('mode'),'stype':zJOAYINCxKWoVMuhvXTFmHerbDkwqt.get('stype'),'orderby':zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('orderby'),'page':'1'}
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel='',img='',infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwRp,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRq,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwRs(zJOAYINCxKWoVMuhvXTFmHerbDkwqp)>0:xbmcplugin.endOfDirectory(zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_handle)
 def dp_LiveChannel_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwqa):
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.SaveCredential(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_winCredential())
  zJOAYINCxKWoVMuhvXTFmHerbDkwtd =zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('stype')
  zJOAYINCxKWoVMuhvXTFmHerbDkwqs =zJOAYINCxKWoVMuhvXTFmHerbDkwRa(zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('page'))
  zJOAYINCxKWoVMuhvXTFmHerbDkwqR,zJOAYINCxKWoVMuhvXTFmHerbDkwqf=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.GetLiveChannelList(zJOAYINCxKWoVMuhvXTFmHerbDkwtd,zJOAYINCxKWoVMuhvXTFmHerbDkwqs)
  for zJOAYINCxKWoVMuhvXTFmHerbDkwqi in zJOAYINCxKWoVMuhvXTFmHerbDkwqR:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf =zJOAYINCxKWoVMuhvXTFmHerbDkwqi.get('title')
   zJOAYINCxKWoVMuhvXTFmHerbDkwtg =zJOAYINCxKWoVMuhvXTFmHerbDkwqi.get('channel')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqc =zJOAYINCxKWoVMuhvXTFmHerbDkwqi.get('thumbnail')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqj =zJOAYINCxKWoVMuhvXTFmHerbDkwqi.get('synopsis')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqU=zJOAYINCxKWoVMuhvXTFmHerbDkwqi.get('channelepg')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqy=zJOAYINCxKWoVMuhvXTFmHerbDkwqi.get('info')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqy['plot']='%s\n%s\n%s\n\n%s'%(zJOAYINCxKWoVMuhvXTFmHerbDkwtg,zJOAYINCxKWoVMuhvXTFmHerbDkwtf,zJOAYINCxKWoVMuhvXTFmHerbDkwqU,zJOAYINCxKWoVMuhvXTFmHerbDkwqj)
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':'LIVE','mediacode':zJOAYINCxKWoVMuhvXTFmHerbDkwqi.get('mediacode'),'stype':zJOAYINCxKWoVMuhvXTFmHerbDkwtd}
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtg,sublabel=zJOAYINCxKWoVMuhvXTFmHerbDkwtf,img=zJOAYINCxKWoVMuhvXTFmHerbDkwqc,infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwqy,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRt,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwqf:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['mode']='CHANNEL' 
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['stype']=zJOAYINCxKWoVMuhvXTFmHerbDkwtd 
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['page']=zJOAYINCxKWoVMuhvXTFmHerbDkwRf(zJOAYINCxKWoVMuhvXTFmHerbDkwqs+1)
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf='[B]%s >>[/B]'%'다음 페이지'
   zJOAYINCxKWoVMuhvXTFmHerbDkwqQ=zJOAYINCxKWoVMuhvXTFmHerbDkwRf(zJOAYINCxKWoVMuhvXTFmHerbDkwqs+1)
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel=zJOAYINCxKWoVMuhvXTFmHerbDkwqQ,img='',infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwRp,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRq,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwRs(zJOAYINCxKWoVMuhvXTFmHerbDkwqR)>0:xbmcplugin.endOfDirectory(zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_handle,cacheToDisc=zJOAYINCxKWoVMuhvXTFmHerbDkwRt)
 def dp_Program_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwqa):
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.SaveCredential(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_winCredential())
  zJOAYINCxKWoVMuhvXTFmHerbDkwtd =zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('stype')
  zJOAYINCxKWoVMuhvXTFmHerbDkwqG =zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('orderby')
  zJOAYINCxKWoVMuhvXTFmHerbDkwqs =zJOAYINCxKWoVMuhvXTFmHerbDkwRa(zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('page'))
  zJOAYINCxKWoVMuhvXTFmHerbDkwqg,zJOAYINCxKWoVMuhvXTFmHerbDkwqf=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.GetProgramList(zJOAYINCxKWoVMuhvXTFmHerbDkwtd,zJOAYINCxKWoVMuhvXTFmHerbDkwqG,zJOAYINCxKWoVMuhvXTFmHerbDkwqs,landyn=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_settings_thumbnail_landyn())
  for zJOAYINCxKWoVMuhvXTFmHerbDkwql in zJOAYINCxKWoVMuhvXTFmHerbDkwqg:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf =zJOAYINCxKWoVMuhvXTFmHerbDkwql.get('title')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqc=zJOAYINCxKWoVMuhvXTFmHerbDkwql.get('thumbnail')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqj =zJOAYINCxKWoVMuhvXTFmHerbDkwql.get('synopsis')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqB =zJOAYINCxKWoVMuhvXTFmHerbDkwpi.get(zJOAYINCxKWoVMuhvXTFmHerbDkwql.get('channel'))
   zJOAYINCxKWoVMuhvXTFmHerbDkwqy=zJOAYINCxKWoVMuhvXTFmHerbDkwql.get('info')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqy['studio']=zJOAYINCxKWoVMuhvXTFmHerbDkwqB
   zJOAYINCxKWoVMuhvXTFmHerbDkwqy['plot']='%s <%s>\n\n%s'%(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,zJOAYINCxKWoVMuhvXTFmHerbDkwqB,zJOAYINCxKWoVMuhvXTFmHerbDkwqj)
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':'EPISODE','programcode':zJOAYINCxKWoVMuhvXTFmHerbDkwql.get('program'),'page':'1'}
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel=zJOAYINCxKWoVMuhvXTFmHerbDkwqB,img=zJOAYINCxKWoVMuhvXTFmHerbDkwqc,infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwqy,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRq,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwqf:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['mode'] ='PROGRAM' 
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['stype'] =zJOAYINCxKWoVMuhvXTFmHerbDkwtd
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['orderby']=zJOAYINCxKWoVMuhvXTFmHerbDkwqG
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['page'] =zJOAYINCxKWoVMuhvXTFmHerbDkwRf(zJOAYINCxKWoVMuhvXTFmHerbDkwqs+1)
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf='[B]%s >>[/B]'%'다음 페이지'
   zJOAYINCxKWoVMuhvXTFmHerbDkwqQ=zJOAYINCxKWoVMuhvXTFmHerbDkwRf(zJOAYINCxKWoVMuhvXTFmHerbDkwqs+1)
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel=zJOAYINCxKWoVMuhvXTFmHerbDkwqQ,img='',infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwRp,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRq,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwRs(zJOAYINCxKWoVMuhvXTFmHerbDkwqg)>0:xbmcplugin.endOfDirectory(zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_handle,cacheToDisc=zJOAYINCxKWoVMuhvXTFmHerbDkwRt)
 def dp_Episode_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwqa):
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.SaveCredential(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_winCredential())
  zJOAYINCxKWoVMuhvXTFmHerbDkwqn=zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('programcode')
  zJOAYINCxKWoVMuhvXTFmHerbDkwqs =zJOAYINCxKWoVMuhvXTFmHerbDkwRa(zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('page'))
  zJOAYINCxKWoVMuhvXTFmHerbDkwqS,zJOAYINCxKWoVMuhvXTFmHerbDkwqf,zJOAYINCxKWoVMuhvXTFmHerbDkwqP=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.GetEpisodoList(zJOAYINCxKWoVMuhvXTFmHerbDkwqn,zJOAYINCxKWoVMuhvXTFmHerbDkwqs,orderby=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_winEpisodeOrderby())
  for zJOAYINCxKWoVMuhvXTFmHerbDkwqL in zJOAYINCxKWoVMuhvXTFmHerbDkwqS:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf =zJOAYINCxKWoVMuhvXTFmHerbDkwqL.get('title')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqQ =zJOAYINCxKWoVMuhvXTFmHerbDkwqL.get('subtitle')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqc=zJOAYINCxKWoVMuhvXTFmHerbDkwqL.get('thumbnail')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqj =zJOAYINCxKWoVMuhvXTFmHerbDkwqL.get('synopsis')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqy=zJOAYINCxKWoVMuhvXTFmHerbDkwqL.get('info')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqy['plot']='%s\n\n%s'%(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,zJOAYINCxKWoVMuhvXTFmHerbDkwqj)
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':'VOD','mediacode':zJOAYINCxKWoVMuhvXTFmHerbDkwqL.get('episode'),'stype':'vod','programcode':zJOAYINCxKWoVMuhvXTFmHerbDkwqn,'title':zJOAYINCxKWoVMuhvXTFmHerbDkwtf,'thumbnail':zJOAYINCxKWoVMuhvXTFmHerbDkwqc}
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel=zJOAYINCxKWoVMuhvXTFmHerbDkwqQ,img=zJOAYINCxKWoVMuhvXTFmHerbDkwqc,infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwqy,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRt,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwqs==1:
   zJOAYINCxKWoVMuhvXTFmHerbDkwqy={'plot':'정렬순서를 변경합니다.'}
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={}
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['mode'] ='ORDER_BY' 
   if zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_winEpisodeOrderby()=='desc':
    zJOAYINCxKWoVMuhvXTFmHerbDkwtf='정렬순서변경 : 최신화부터 -> 1회부터'
    zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['orderby']='asc'
   else:
    zJOAYINCxKWoVMuhvXTFmHerbDkwtf='정렬순서변경 : 1회부터 -> 최신화부터'
    zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['orderby']='desc'
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel='',img='',infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwqy,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRt,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwqf:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['mode'] ='EPISODE' 
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['programcode']=zJOAYINCxKWoVMuhvXTFmHerbDkwqn
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['page'] =zJOAYINCxKWoVMuhvXTFmHerbDkwRf(zJOAYINCxKWoVMuhvXTFmHerbDkwqs+1)
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf='[B]%s >>[/B]'%'다음 페이지'
   zJOAYINCxKWoVMuhvXTFmHerbDkwqQ=zJOAYINCxKWoVMuhvXTFmHerbDkwRf(zJOAYINCxKWoVMuhvXTFmHerbDkwqs+1)
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel=zJOAYINCxKWoVMuhvXTFmHerbDkwqQ,img='',infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwRp,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRq,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwRs(zJOAYINCxKWoVMuhvXTFmHerbDkwqS)>0:xbmcplugin.endOfDirectory(zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_handle,cacheToDisc=zJOAYINCxKWoVMuhvXTFmHerbDkwRq)
 def dp_setEpOrderby(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwqa):
  zJOAYINCxKWoVMuhvXTFmHerbDkwqG =zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('orderby')
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.set_winEpisodeOrderby(zJOAYINCxKWoVMuhvXTFmHerbDkwqG)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwqa):
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.SaveCredential(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_winCredential())
  zJOAYINCxKWoVMuhvXTFmHerbDkwqG =zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('orderby')
  zJOAYINCxKWoVMuhvXTFmHerbDkwqs=zJOAYINCxKWoVMuhvXTFmHerbDkwRa(zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('page'))
  zJOAYINCxKWoVMuhvXTFmHerbDkwqE,zJOAYINCxKWoVMuhvXTFmHerbDkwqf=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.GetMovieList(zJOAYINCxKWoVMuhvXTFmHerbDkwqG,zJOAYINCxKWoVMuhvXTFmHerbDkwqs,premiumyn=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_settings_premiumyn(),landyn=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_settings_thumbnail_landyn())
  for zJOAYINCxKWoVMuhvXTFmHerbDkwqd in zJOAYINCxKWoVMuhvXTFmHerbDkwqE:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf =zJOAYINCxKWoVMuhvXTFmHerbDkwqd.get('title')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqc=zJOAYINCxKWoVMuhvXTFmHerbDkwqd.get('thumbnail')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqj =zJOAYINCxKWoVMuhvXTFmHerbDkwqd.get('synopsis')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqy=zJOAYINCxKWoVMuhvXTFmHerbDkwqd.get('info')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqy['plot']='%s\n\n%s'%(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,zJOAYINCxKWoVMuhvXTFmHerbDkwqj)
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':'MOVIE','mediacode':zJOAYINCxKWoVMuhvXTFmHerbDkwqd.get('moviecode'),'stype':'movie','title':zJOAYINCxKWoVMuhvXTFmHerbDkwtf,'thumbnail':zJOAYINCxKWoVMuhvXTFmHerbDkwqc}
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel='',img=zJOAYINCxKWoVMuhvXTFmHerbDkwqc,infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwqy,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRt,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwqf:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['mode'] ='MOVIE_GROUP' 
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['orderby']=zJOAYINCxKWoVMuhvXTFmHerbDkwqG
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['page'] =zJOAYINCxKWoVMuhvXTFmHerbDkwRf(zJOAYINCxKWoVMuhvXTFmHerbDkwqs+1)
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf='[B]%s >>[/B]'%'다음 페이지'
   zJOAYINCxKWoVMuhvXTFmHerbDkwqQ=zJOAYINCxKWoVMuhvXTFmHerbDkwRf(zJOAYINCxKWoVMuhvXTFmHerbDkwqs+1)
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel=zJOAYINCxKWoVMuhvXTFmHerbDkwqQ,img='',infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwRp,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRq,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwRs(zJOAYINCxKWoVMuhvXTFmHerbDkwqE)>0:xbmcplugin.endOfDirectory(zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_handle,cacheToDisc=zJOAYINCxKWoVMuhvXTFmHerbDkwRt)
 def dp_Search_Group(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwqa):
  for zJOAYINCxKWoVMuhvXTFmHerbDkwqt in zJOAYINCxKWoVMuhvXTFmHerbDkwpR:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf=zJOAYINCxKWoVMuhvXTFmHerbDkwqt.get('title')
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':zJOAYINCxKWoVMuhvXTFmHerbDkwqt.get('mode'),'stype':zJOAYINCxKWoVMuhvXTFmHerbDkwqt.get('stype'),'page':'1'}
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel='',img='',infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwRp,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRq,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwRs(zJOAYINCxKWoVMuhvXTFmHerbDkwpR)>0:xbmcplugin.endOfDirectory(zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_handle)
 def dp_Search_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwqa):
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.SaveCredential(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_winCredential())
  zJOAYINCxKWoVMuhvXTFmHerbDkwap =__addon__.getSetting('id')
  zJOAYINCxKWoVMuhvXTFmHerbDkwqs =zJOAYINCxKWoVMuhvXTFmHerbDkwRa(zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('page'))
  zJOAYINCxKWoVMuhvXTFmHerbDkwtd =zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('stype')
  if 'search_key' in zJOAYINCxKWoVMuhvXTFmHerbDkwqa:
   zJOAYINCxKWoVMuhvXTFmHerbDkwat=zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('search_key')
  else:
   zJOAYINCxKWoVMuhvXTFmHerbDkwat=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not zJOAYINCxKWoVMuhvXTFmHerbDkwat:return
  zJOAYINCxKWoVMuhvXTFmHerbDkwaq,zJOAYINCxKWoVMuhvXTFmHerbDkwqf=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.GetSearchList(zJOAYINCxKWoVMuhvXTFmHerbDkwat,zJOAYINCxKWoVMuhvXTFmHerbDkwap,zJOAYINCxKWoVMuhvXTFmHerbDkwqs,zJOAYINCxKWoVMuhvXTFmHerbDkwtd,premiumyn=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_settings_premiumyn(),landyn=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_settings_thumbnail_landyn())
  if zJOAYINCxKWoVMuhvXTFmHerbDkwRs(zJOAYINCxKWoVMuhvXTFmHerbDkwaq)==0:return
  for zJOAYINCxKWoVMuhvXTFmHerbDkwas in zJOAYINCxKWoVMuhvXTFmHerbDkwaq:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf =zJOAYINCxKWoVMuhvXTFmHerbDkwas.get('title')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqc=zJOAYINCxKWoVMuhvXTFmHerbDkwas.get('thumbnail')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqj =zJOAYINCxKWoVMuhvXTFmHerbDkwas.get('synopsis')
   zJOAYINCxKWoVMuhvXTFmHerbDkwaR =zJOAYINCxKWoVMuhvXTFmHerbDkwas.get('program')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqy=zJOAYINCxKWoVMuhvXTFmHerbDkwas.get('info')
   zJOAYINCxKWoVMuhvXTFmHerbDkwqy['plot']='%s\n\n%s'%(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,zJOAYINCxKWoVMuhvXTFmHerbDkwqj)
   if zJOAYINCxKWoVMuhvXTFmHerbDkwtd=='vod':
    zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':'EPISODE','programcode':zJOAYINCxKWoVMuhvXTFmHerbDkwas.get('program'),'page':'1'}
    zJOAYINCxKWoVMuhvXTFmHerbDkwtG=zJOAYINCxKWoVMuhvXTFmHerbDkwRq
   else:
    zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':'MOVIE','mediacode':zJOAYINCxKWoVMuhvXTFmHerbDkwas.get('movie'),'stype':'movie','title':zJOAYINCxKWoVMuhvXTFmHerbDkwtf,'thumbnail':zJOAYINCxKWoVMuhvXTFmHerbDkwqc}
    zJOAYINCxKWoVMuhvXTFmHerbDkwtG=zJOAYINCxKWoVMuhvXTFmHerbDkwRt
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel='',img=zJOAYINCxKWoVMuhvXTFmHerbDkwqc,infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwqy,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwtG,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwqf:
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['mode'] ='SEARCH' 
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['search_key']=zJOAYINCxKWoVMuhvXTFmHerbDkwat
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ['page'] =zJOAYINCxKWoVMuhvXTFmHerbDkwRf(zJOAYINCxKWoVMuhvXTFmHerbDkwqs+1)
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf='[B]%s >>[/B]'%'다음 페이지'
   zJOAYINCxKWoVMuhvXTFmHerbDkwqQ=zJOAYINCxKWoVMuhvXTFmHerbDkwRf(zJOAYINCxKWoVMuhvXTFmHerbDkwqs+1)
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel=zJOAYINCxKWoVMuhvXTFmHerbDkwqQ,img='',infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwRp,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRq,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwRs(zJOAYINCxKWoVMuhvXTFmHerbDkwaq)>0:xbmcplugin.endOfDirectory(zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_handle)
 def Delete_Watched_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwtd):
  try:
   zJOAYINCxKWoVMuhvXTFmHerbDkwaf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%zJOAYINCxKWoVMuhvXTFmHerbDkwtd))
   fp=zJOAYINCxKWoVMuhvXTFmHerbDkwRi(zJOAYINCxKWoVMuhvXTFmHerbDkwaf,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   zJOAYINCxKWoVMuhvXTFmHerbDkwRp
 def dp_WatchList_Delete(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwqa):
  zJOAYINCxKWoVMuhvXTFmHerbDkwtd=zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('stype')
  zJOAYINCxKWoVMuhvXTFmHerbDkwpl=xbmcgui.Dialog()
  zJOAYINCxKWoVMuhvXTFmHerbDkwtS=zJOAYINCxKWoVMuhvXTFmHerbDkwpl.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if zJOAYINCxKWoVMuhvXTFmHerbDkwtS==zJOAYINCxKWoVMuhvXTFmHerbDkwRt:sys.exit()
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.Delete_Watched_List(zJOAYINCxKWoVMuhvXTFmHerbDkwtd)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwtd):
  try:
   zJOAYINCxKWoVMuhvXTFmHerbDkwaf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%zJOAYINCxKWoVMuhvXTFmHerbDkwtd))
   fp=zJOAYINCxKWoVMuhvXTFmHerbDkwRi(zJOAYINCxKWoVMuhvXTFmHerbDkwaf,'r',-1,'utf-8')
   zJOAYINCxKWoVMuhvXTFmHerbDkwai=fp.readlines()
   fp.close()
  except:
   zJOAYINCxKWoVMuhvXTFmHerbDkwai=[]
  return zJOAYINCxKWoVMuhvXTFmHerbDkwai
 def Save_Watched_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwtd,zJOAYINCxKWoVMuhvXTFmHerbDkwpG):
  try:
   zJOAYINCxKWoVMuhvXTFmHerbDkwaf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%zJOAYINCxKWoVMuhvXTFmHerbDkwtd))
   zJOAYINCxKWoVMuhvXTFmHerbDkwac=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.Load_Watched_List(zJOAYINCxKWoVMuhvXTFmHerbDkwtd) 
   fp=zJOAYINCxKWoVMuhvXTFmHerbDkwRi(zJOAYINCxKWoVMuhvXTFmHerbDkwaf,'w',-1,'utf-8')
   zJOAYINCxKWoVMuhvXTFmHerbDkwaj=urllib.parse.urlencode(zJOAYINCxKWoVMuhvXTFmHerbDkwpG)
   zJOAYINCxKWoVMuhvXTFmHerbDkwaj=zJOAYINCxKWoVMuhvXTFmHerbDkwaj+'\n'
   fp.write(zJOAYINCxKWoVMuhvXTFmHerbDkwaj)
   zJOAYINCxKWoVMuhvXTFmHerbDkwaU=0
   for zJOAYINCxKWoVMuhvXTFmHerbDkway in zJOAYINCxKWoVMuhvXTFmHerbDkwac:
    zJOAYINCxKWoVMuhvXTFmHerbDkwaQ=zJOAYINCxKWoVMuhvXTFmHerbDkwRc(urllib.parse.parse_qsl(zJOAYINCxKWoVMuhvXTFmHerbDkway))
    zJOAYINCxKWoVMuhvXTFmHerbDkwaG=zJOAYINCxKWoVMuhvXTFmHerbDkwpG.get('code').strip()
    zJOAYINCxKWoVMuhvXTFmHerbDkwag=zJOAYINCxKWoVMuhvXTFmHerbDkwaQ.get('code').strip()
    if zJOAYINCxKWoVMuhvXTFmHerbDkwtd=='vod' and zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_settings_direct_replay()==zJOAYINCxKWoVMuhvXTFmHerbDkwRq:
     zJOAYINCxKWoVMuhvXTFmHerbDkwaG=zJOAYINCxKWoVMuhvXTFmHerbDkwpG.get('videoid').strip()
     zJOAYINCxKWoVMuhvXTFmHerbDkwag=zJOAYINCxKWoVMuhvXTFmHerbDkwaQ.get('videoid').strip()if zJOAYINCxKWoVMuhvXTFmHerbDkwag!=zJOAYINCxKWoVMuhvXTFmHerbDkwRp else '-'
    if zJOAYINCxKWoVMuhvXTFmHerbDkwaG!=zJOAYINCxKWoVMuhvXTFmHerbDkwag:
     fp.write(zJOAYINCxKWoVMuhvXTFmHerbDkway)
     zJOAYINCxKWoVMuhvXTFmHerbDkwaU+=1
     if zJOAYINCxKWoVMuhvXTFmHerbDkwaU>=50:break
   fp.close()
  except:
   zJOAYINCxKWoVMuhvXTFmHerbDkwRp
 def dp_Watch_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwqa):
  zJOAYINCxKWoVMuhvXTFmHerbDkwtd =zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('stype')
  zJOAYINCxKWoVMuhvXTFmHerbDkwtp=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_settings_direct_replay()
  if zJOAYINCxKWoVMuhvXTFmHerbDkwtd=='-':
   for zJOAYINCxKWoVMuhvXTFmHerbDkwqt in zJOAYINCxKWoVMuhvXTFmHerbDkwps:
    zJOAYINCxKWoVMuhvXTFmHerbDkwtf=zJOAYINCxKWoVMuhvXTFmHerbDkwqt.get('title')
    zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':zJOAYINCxKWoVMuhvXTFmHerbDkwqt.get('mode'),'stype':zJOAYINCxKWoVMuhvXTFmHerbDkwqt.get('stype')}
    zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel='',img='',infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwRp,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRq,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
   if zJOAYINCxKWoVMuhvXTFmHerbDkwRs(zJOAYINCxKWoVMuhvXTFmHerbDkwps)>0:xbmcplugin.endOfDirectory(zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_handle)
  else:
   zJOAYINCxKWoVMuhvXTFmHerbDkwal=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.Load_Watched_List(zJOAYINCxKWoVMuhvXTFmHerbDkwtd)
   for zJOAYINCxKWoVMuhvXTFmHerbDkwaB in zJOAYINCxKWoVMuhvXTFmHerbDkwal:
    zJOAYINCxKWoVMuhvXTFmHerbDkwan=zJOAYINCxKWoVMuhvXTFmHerbDkwRc(urllib.parse.parse_qsl(zJOAYINCxKWoVMuhvXTFmHerbDkwaB))
    zJOAYINCxKWoVMuhvXTFmHerbDkwaS =zJOAYINCxKWoVMuhvXTFmHerbDkwan.get('code').strip()
    zJOAYINCxKWoVMuhvXTFmHerbDkwtf =zJOAYINCxKWoVMuhvXTFmHerbDkwan.get('title').strip()
    zJOAYINCxKWoVMuhvXTFmHerbDkwqc=zJOAYINCxKWoVMuhvXTFmHerbDkwan.get('img').strip()
    zJOAYINCxKWoVMuhvXTFmHerbDkwaP =zJOAYINCxKWoVMuhvXTFmHerbDkwan.get('videoid').strip()
    zJOAYINCxKWoVMuhvXTFmHerbDkwqy={}
    zJOAYINCxKWoVMuhvXTFmHerbDkwqy['plot']=zJOAYINCxKWoVMuhvXTFmHerbDkwtf
    if zJOAYINCxKWoVMuhvXTFmHerbDkwtd=='vod':
     if zJOAYINCxKWoVMuhvXTFmHerbDkwtp==zJOAYINCxKWoVMuhvXTFmHerbDkwRt or zJOAYINCxKWoVMuhvXTFmHerbDkwaP==zJOAYINCxKWoVMuhvXTFmHerbDkwRp:
      zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':'EPISODE','programcode':zJOAYINCxKWoVMuhvXTFmHerbDkwaS,'page':'1'}
      zJOAYINCxKWoVMuhvXTFmHerbDkwtG=zJOAYINCxKWoVMuhvXTFmHerbDkwRq
     else:
      zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':'VOD','mediacode':zJOAYINCxKWoVMuhvXTFmHerbDkwaP,'stype':'vod','programcode':zJOAYINCxKWoVMuhvXTFmHerbDkwaS,'title':zJOAYINCxKWoVMuhvXTFmHerbDkwtf,'thumbnail':zJOAYINCxKWoVMuhvXTFmHerbDkwqc}
      zJOAYINCxKWoVMuhvXTFmHerbDkwtG=zJOAYINCxKWoVMuhvXTFmHerbDkwRt
    else:
     zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':'MOVIE','mediacode':zJOAYINCxKWoVMuhvXTFmHerbDkwaS,'stype':'movie','title':zJOAYINCxKWoVMuhvXTFmHerbDkwtf,'thumbnail':zJOAYINCxKWoVMuhvXTFmHerbDkwqc}
     zJOAYINCxKWoVMuhvXTFmHerbDkwtG=zJOAYINCxKWoVMuhvXTFmHerbDkwRt
    zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel='',img=zJOAYINCxKWoVMuhvXTFmHerbDkwqc,infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwqy,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwtG,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
   zJOAYINCxKWoVMuhvXTFmHerbDkwqy={'plot':'시청목록을 삭제합니다.'}
   zJOAYINCxKWoVMuhvXTFmHerbDkwtf='*** 시청목록 삭제 ***'
   zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'mode':'MYVIEW_REMOVE','stype':zJOAYINCxKWoVMuhvXTFmHerbDkwtd}
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.add_dir(zJOAYINCxKWoVMuhvXTFmHerbDkwtf,sublabel='',img='',infoLabels=zJOAYINCxKWoVMuhvXTFmHerbDkwqy,isFolder=zJOAYINCxKWoVMuhvXTFmHerbDkwRt,params=zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
   xbmcplugin.endOfDirectory(zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_handle,cacheToDisc=zJOAYINCxKWoVMuhvXTFmHerbDkwRt)
 def play_VIDEO(zJOAYINCxKWoVMuhvXTFmHerbDkwpU,zJOAYINCxKWoVMuhvXTFmHerbDkwqa):
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.SaveCredential(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_winCredential())
  zJOAYINCxKWoVMuhvXTFmHerbDkwaE =zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('mediacode')
  zJOAYINCxKWoVMuhvXTFmHerbDkwtd =zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('stype')
  zJOAYINCxKWoVMuhvXTFmHerbDkwad =zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('pvrmode')
  zJOAYINCxKWoVMuhvXTFmHerbDkwsp=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.get_selQuality(zJOAYINCxKWoVMuhvXTFmHerbDkwtd)
  zJOAYINCxKWoVMuhvXTFmHerbDkwst,zJOAYINCxKWoVMuhvXTFmHerbDkwsq=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.GetBroadURL(zJOAYINCxKWoVMuhvXTFmHerbDkwaE,zJOAYINCxKWoVMuhvXTFmHerbDkwsp,zJOAYINCxKWoVMuhvXTFmHerbDkwtd,zJOAYINCxKWoVMuhvXTFmHerbDkwad)
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.addon_log('qt, stype, url : %s - %s - %s'%(zJOAYINCxKWoVMuhvXTFmHerbDkwRf(zJOAYINCxKWoVMuhvXTFmHerbDkwsp),zJOAYINCxKWoVMuhvXTFmHerbDkwtd,zJOAYINCxKWoVMuhvXTFmHerbDkwst))
  if zJOAYINCxKWoVMuhvXTFmHerbDkwst=='':
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.addon_noti(__language__(30908).encode('utf8'))
   return
  zJOAYINCxKWoVMuhvXTFmHerbDkwsa =zJOAYINCxKWoVMuhvXTFmHerbDkwst.find('Policy=')
  if zJOAYINCxKWoVMuhvXTFmHerbDkwsa!=-1:
   zJOAYINCxKWoVMuhvXTFmHerbDkwsR =zJOAYINCxKWoVMuhvXTFmHerbDkwst.split('?')[0]
   zJOAYINCxKWoVMuhvXTFmHerbDkwsf=zJOAYINCxKWoVMuhvXTFmHerbDkwRc(urllib.parse.parse_qsl(urllib.parse.urlsplit(zJOAYINCxKWoVMuhvXTFmHerbDkwst).query))
   zJOAYINCxKWoVMuhvXTFmHerbDkwsf=urllib.parse.urlencode(zJOAYINCxKWoVMuhvXTFmHerbDkwsf)
   zJOAYINCxKWoVMuhvXTFmHerbDkwsf=zJOAYINCxKWoVMuhvXTFmHerbDkwsf.replace('&',';')
   zJOAYINCxKWoVMuhvXTFmHerbDkwsf=zJOAYINCxKWoVMuhvXTFmHerbDkwsf.replace('Policy','CloudFront-Policy')
   zJOAYINCxKWoVMuhvXTFmHerbDkwsf=zJOAYINCxKWoVMuhvXTFmHerbDkwsf.replace('Signature','CloudFront-Signature')
   zJOAYINCxKWoVMuhvXTFmHerbDkwsf=zJOAYINCxKWoVMuhvXTFmHerbDkwsf.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   zJOAYINCxKWoVMuhvXTFmHerbDkwsi='%s|Cookie=%s'%(zJOAYINCxKWoVMuhvXTFmHerbDkwsR,zJOAYINCxKWoVMuhvXTFmHerbDkwsf)
  else:
   zJOAYINCxKWoVMuhvXTFmHerbDkwsi=zJOAYINCxKWoVMuhvXTFmHerbDkwst
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.addon_log(zJOAYINCxKWoVMuhvXTFmHerbDkwsi)
  zJOAYINCxKWoVMuhvXTFmHerbDkwsc=xbmcgui.ListItem(path=zJOAYINCxKWoVMuhvXTFmHerbDkwsi)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwsq!='':
   zJOAYINCxKWoVMuhvXTFmHerbDkwsj=zJOAYINCxKWoVMuhvXTFmHerbDkwsq
   zJOAYINCxKWoVMuhvXTFmHerbDkwsU ='https://cj.drmkeyserver.com/widevine_license'
   zJOAYINCxKWoVMuhvXTFmHerbDkwsy ='mpd'
   zJOAYINCxKWoVMuhvXTFmHerbDkwsQ ='com.widevine.alpha'
   zJOAYINCxKWoVMuhvXTFmHerbDkwsG =inputstreamhelper.Helper(zJOAYINCxKWoVMuhvXTFmHerbDkwsy,drm='widevine')
   if zJOAYINCxKWoVMuhvXTFmHerbDkwsG.check_inputstream():
    zJOAYINCxKWoVMuhvXTFmHerbDkwsg={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%zJOAYINCxKWoVMuhvXTFmHerbDkwaE,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':zJOAYINCxKWoVMuhvXTFmHerbDkwpc,'AcquireLicenseAssertion':zJOAYINCxKWoVMuhvXTFmHerbDkwsj,'Host':'cj.drmkeyserver.com'}
    zJOAYINCxKWoVMuhvXTFmHerbDkwsl=zJOAYINCxKWoVMuhvXTFmHerbDkwsU+'|'+urllib.parse.urlencode(zJOAYINCxKWoVMuhvXTFmHerbDkwsg)+'|R{SSM}|'
    zJOAYINCxKWoVMuhvXTFmHerbDkwsc.setProperty('inputstream',zJOAYINCxKWoVMuhvXTFmHerbDkwsG.inputstream_addon)
    zJOAYINCxKWoVMuhvXTFmHerbDkwsc.setProperty('inputstream.adaptive.manifest_type',zJOAYINCxKWoVMuhvXTFmHerbDkwsy)
    zJOAYINCxKWoVMuhvXTFmHerbDkwsc.setProperty('inputstream.adaptive.license_type',zJOAYINCxKWoVMuhvXTFmHerbDkwsQ)
    zJOAYINCxKWoVMuhvXTFmHerbDkwsc.setProperty('inputstream.adaptive.license_key',zJOAYINCxKWoVMuhvXTFmHerbDkwsl)
    zJOAYINCxKWoVMuhvXTFmHerbDkwsc.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(zJOAYINCxKWoVMuhvXTFmHerbDkwpc))
  xbmcplugin.setResolvedUrl(zJOAYINCxKWoVMuhvXTFmHerbDkwpU._addon_handle,zJOAYINCxKWoVMuhvXTFmHerbDkwRq,zJOAYINCxKWoVMuhvXTFmHerbDkwsc)
  try:
   if zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('mode')in['VOD','MOVIE']and zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('title'):
    zJOAYINCxKWoVMuhvXTFmHerbDkwtQ={'code':zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('programcode')if zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('mode')=='VOD' else zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('mediacode'),'img':zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('thumbnail'),'title':zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('title'),'videoid':zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('mediacode')}
    zJOAYINCxKWoVMuhvXTFmHerbDkwpU.Save_Watched_List(zJOAYINCxKWoVMuhvXTFmHerbDkwqa.get('stype'),zJOAYINCxKWoVMuhvXTFmHerbDkwtQ)
  except:
   zJOAYINCxKWoVMuhvXTFmHerbDkwRp
 def logout(zJOAYINCxKWoVMuhvXTFmHerbDkwpU):
  zJOAYINCxKWoVMuhvXTFmHerbDkwpl=xbmcgui.Dialog()
  zJOAYINCxKWoVMuhvXTFmHerbDkwtS=zJOAYINCxKWoVMuhvXTFmHerbDkwpl.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if zJOAYINCxKWoVMuhvXTFmHerbDkwtS==zJOAYINCxKWoVMuhvXTFmHerbDkwRt:sys.exit()
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.wininfo_clear()
  if os.path.isfile(zJOAYINCxKWoVMuhvXTFmHerbDkwpj):os.remove(zJOAYINCxKWoVMuhvXTFmHerbDkwpj)
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(zJOAYINCxKWoVMuhvXTFmHerbDkwpU):
  zJOAYINCxKWoVMuhvXTFmHerbDkwta=xbmcgui.Window(10000)
  zJOAYINCxKWoVMuhvXTFmHerbDkwta.setProperty('TVING_M_TOKEN','')
  zJOAYINCxKWoVMuhvXTFmHerbDkwta.setProperty('TVING_M_USERINFO','')
  zJOAYINCxKWoVMuhvXTFmHerbDkwta.setProperty('TVING_M_UUID','')
  zJOAYINCxKWoVMuhvXTFmHerbDkwta.setProperty('TVING_M_LOGINTIME','')
 def cookiefile_save(zJOAYINCxKWoVMuhvXTFmHerbDkwpU):
  zJOAYINCxKWoVMuhvXTFmHerbDkwsB =zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.Get_Now_Datetime()
  zJOAYINCxKWoVMuhvXTFmHerbDkwsn=zJOAYINCxKWoVMuhvXTFmHerbDkwsB+datetime.timedelta(days=zJOAYINCxKWoVMuhvXTFmHerbDkwRa(__addon__.getSetting('cache_ttl')))
  zJOAYINCxKWoVMuhvXTFmHerbDkwta=xbmcgui.Window(10000)
  zJOAYINCxKWoVMuhvXTFmHerbDkwsS={'tving_token':zJOAYINCxKWoVMuhvXTFmHerbDkwta.getProperty('TVING_M_TOKEN'),'tving_userinfo':zJOAYINCxKWoVMuhvXTFmHerbDkwta.getProperty('TVING_M_USERINFO'),'tving_uuid':zJOAYINCxKWoVMuhvXTFmHerbDkwta.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_limitdate':zJOAYINCxKWoVMuhvXTFmHerbDkwsn.strftime('%Y-%m-%d')}
  try: 
   fp=zJOAYINCxKWoVMuhvXTFmHerbDkwRi(zJOAYINCxKWoVMuhvXTFmHerbDkwpj,'w',-1,'utf-8')
   json.dump(zJOAYINCxKWoVMuhvXTFmHerbDkwsS,fp)
   fp.close()
  except zJOAYINCxKWoVMuhvXTFmHerbDkwRj as exception:
   zJOAYINCxKWoVMuhvXTFmHerbDkwRU(exception)
 def cookiefile_check(zJOAYINCxKWoVMuhvXTFmHerbDkwpU):
  zJOAYINCxKWoVMuhvXTFmHerbDkwsS={}
  try: 
   fp=zJOAYINCxKWoVMuhvXTFmHerbDkwRi(zJOAYINCxKWoVMuhvXTFmHerbDkwpj,'r',-1,'utf-8')
   zJOAYINCxKWoVMuhvXTFmHerbDkwsS= json.load(fp)
   fp.close()
  except zJOAYINCxKWoVMuhvXTFmHerbDkwRj as exception:
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.wininfo_clear()
   return zJOAYINCxKWoVMuhvXTFmHerbDkwRt
  zJOAYINCxKWoVMuhvXTFmHerbDkwtl =__addon__.getSetting('id')
  zJOAYINCxKWoVMuhvXTFmHerbDkwtB =__addon__.getSetting('pw')
  zJOAYINCxKWoVMuhvXTFmHerbDkwsP=__addon__.getSetting('login_type')
  zJOAYINCxKWoVMuhvXTFmHerbDkwsS['tving_id']=base64.standard_b64decode(zJOAYINCxKWoVMuhvXTFmHerbDkwsS['tving_id']).decode('utf-8')
  zJOAYINCxKWoVMuhvXTFmHerbDkwsS['tving_pw']=base64.standard_b64decode(zJOAYINCxKWoVMuhvXTFmHerbDkwsS['tving_pw']).decode('utf-8')
  if zJOAYINCxKWoVMuhvXTFmHerbDkwtl!=zJOAYINCxKWoVMuhvXTFmHerbDkwsS['tving_id']or zJOAYINCxKWoVMuhvXTFmHerbDkwtB!=zJOAYINCxKWoVMuhvXTFmHerbDkwsS['tving_pw']or zJOAYINCxKWoVMuhvXTFmHerbDkwsP!=zJOAYINCxKWoVMuhvXTFmHerbDkwsS['tving_logintype']:
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.wininfo_clear()
   return zJOAYINCxKWoVMuhvXTFmHerbDkwRt
  zJOAYINCxKWoVMuhvXTFmHerbDkwtP =zJOAYINCxKWoVMuhvXTFmHerbDkwRa(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  zJOAYINCxKWoVMuhvXTFmHerbDkwsL=zJOAYINCxKWoVMuhvXTFmHerbDkwsS['tving_limitdate']
  zJOAYINCxKWoVMuhvXTFmHerbDkwtL =zJOAYINCxKWoVMuhvXTFmHerbDkwRa(re.sub('-','',zJOAYINCxKWoVMuhvXTFmHerbDkwsL))
  if zJOAYINCxKWoVMuhvXTFmHerbDkwtL<zJOAYINCxKWoVMuhvXTFmHerbDkwtP:
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.wininfo_clear()
   return zJOAYINCxKWoVMuhvXTFmHerbDkwRt
  zJOAYINCxKWoVMuhvXTFmHerbDkwta=xbmcgui.Window(10000)
  zJOAYINCxKWoVMuhvXTFmHerbDkwta.setProperty('TVING_M_TOKEN',zJOAYINCxKWoVMuhvXTFmHerbDkwsS['tving_token'])
  zJOAYINCxKWoVMuhvXTFmHerbDkwta.setProperty('TVING_M_USERINFO',zJOAYINCxKWoVMuhvXTFmHerbDkwsS['tving_userinfo'])
  zJOAYINCxKWoVMuhvXTFmHerbDkwta.setProperty('TVING_M_UUID',zJOAYINCxKWoVMuhvXTFmHerbDkwsS['tving_uuid'])
  zJOAYINCxKWoVMuhvXTFmHerbDkwta.setProperty('TVING_M_LOGINTIME',zJOAYINCxKWoVMuhvXTFmHerbDkwsL)
  return zJOAYINCxKWoVMuhvXTFmHerbDkwRq
 def tving_main(zJOAYINCxKWoVMuhvXTFmHerbDkwpU):
  zJOAYINCxKWoVMuhvXTFmHerbDkwsE=zJOAYINCxKWoVMuhvXTFmHerbDkwpU.main_params.get('mode',zJOAYINCxKWoVMuhvXTFmHerbDkwRp)
  if zJOAYINCxKWoVMuhvXTFmHerbDkwsE=='LOGOUT':
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.logout()
   return
  zJOAYINCxKWoVMuhvXTFmHerbDkwpU.login_main()
  if zJOAYINCxKWoVMuhvXTFmHerbDkwsE is zJOAYINCxKWoVMuhvXTFmHerbDkwRp:
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.dp_Main_List()
  elif zJOAYINCxKWoVMuhvXTFmHerbDkwsE in['LIVE_GROUP','VOD_GROUP']:
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.dp_Title_Group(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.main_params)
  elif zJOAYINCxKWoVMuhvXTFmHerbDkwsE=='CHANNEL':
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.dp_LiveChannel_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.main_params)
  elif zJOAYINCxKWoVMuhvXTFmHerbDkwsE in['LIVE','VOD','MOVIE']:
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.play_VIDEO(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.main_params)
  elif zJOAYINCxKWoVMuhvXTFmHerbDkwsE=='PROGRAM':
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.dp_Program_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.main_params)
  elif zJOAYINCxKWoVMuhvXTFmHerbDkwsE=='EPISODE':
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.dp_Episode_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.main_params)
  elif zJOAYINCxKWoVMuhvXTFmHerbDkwsE=='MOVIE_GROUP':
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.dp_Movie_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.main_params)
  elif zJOAYINCxKWoVMuhvXTFmHerbDkwsE=='SEARCH_GROUP':
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.dp_Search_Group(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.main_params)
  elif zJOAYINCxKWoVMuhvXTFmHerbDkwsE=='SEARCH':
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.dp_Search_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.main_params)
  elif zJOAYINCxKWoVMuhvXTFmHerbDkwsE=='WATCH':
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.dp_Watch_List(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.main_params)
  elif zJOAYINCxKWoVMuhvXTFmHerbDkwsE=='MYVIEW_REMOVE':
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.dp_WatchList_Delete(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.main_params)
  elif zJOAYINCxKWoVMuhvXTFmHerbDkwsE=='ORDER_BY':
   zJOAYINCxKWoVMuhvXTFmHerbDkwpU.dp_setEpOrderby(zJOAYINCxKWoVMuhvXTFmHerbDkwpU.main_params)
  else:
   zJOAYINCxKWoVMuhvXTFmHerbDkwRp
# Created by pyminifier (https://github.com/liftoff/pyminifier)
