__author__="NightRain"
iNBAmXQcetsguwTxSlMUpRrIzoGLPF=object
iNBAmXQcetsguwTxSlMUpRrIzoGLPW=None
iNBAmXQcetsguwTxSlMUpRrIzoGLPk=False
iNBAmXQcetsguwTxSlMUpRrIzoGLyH=int
iNBAmXQcetsguwTxSlMUpRrIzoGLyj=True
iNBAmXQcetsguwTxSlMUpRrIzoGLyY=Exception
iNBAmXQcetsguwTxSlMUpRrIzoGLyP=print
iNBAmXQcetsguwTxSlMUpRrIzoGLyd=str
iNBAmXQcetsguwTxSlMUpRrIzoGLyD=list
iNBAmXQcetsguwTxSlMUpRrIzoGLyf=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
iNBAmXQcetsguwTxSlMUpRrIzoGLHY ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
iNBAmXQcetsguwTxSlMUpRrIzoGLHP={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
class iNBAmXQcetsguwTxSlMUpRrIzoGLHj(iNBAmXQcetsguwTxSlMUpRrIzoGLPF):
 def __init__(iNBAmXQcetsguwTxSlMUpRrIzoGLHy):
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.TVING_TOKEN =''
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.POC_USERINFO =''
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.TVING_UUID ='-'
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.NETWORKCODE ='CSND0900'
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.OSCODE ='CSOD0900' 
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.TELECODE ='CSCD0900'
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.SCREENCODE ='CSSD0100'
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.LIVE_LIMIT =23
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.VOD_LIMIT =20
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.EPISODE_LIMIT=30 
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.SEARCH_LIMIT =80 
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.MOVIE_LIMIT =18
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.API_DOMAIN ='https://api.tving.com'
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN ='https://image.tving.com'
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.SEARCH_DOMAIN='https://search.tving.com'
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.LOGIN_DOMAIN ='https://user.tving.com'
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.URL_DOMAIN ='https://www.tving.com'
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.MOVIE_LITE ='338723'
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.MOVIE_PREMIUM='1513561'
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.DEFAULT_HEADER={'user-agent':iNBAmXQcetsguwTxSlMUpRrIzoGLHY}
 def callRequestCookies(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,jobtype,iNBAmXQcetsguwTxSlMUpRrIzoGLHa,payload=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,params=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,cookies=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,redirects=iNBAmXQcetsguwTxSlMUpRrIzoGLPk):
  iNBAmXQcetsguwTxSlMUpRrIzoGLHd=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.DEFAULT_HEADER
  if headers:iNBAmXQcetsguwTxSlMUpRrIzoGLHd.update(headers)
  if jobtype=='Get':
   iNBAmXQcetsguwTxSlMUpRrIzoGLHD=requests.get(iNBAmXQcetsguwTxSlMUpRrIzoGLHa,params=params,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLHd,cookies=cookies,allow_redirects=redirects)
  else:
   iNBAmXQcetsguwTxSlMUpRrIzoGLHD=requests.post(iNBAmXQcetsguwTxSlMUpRrIzoGLHa,data=payload,params=params,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLHd,cookies=cookies,allow_redirects=redirects)
  return iNBAmXQcetsguwTxSlMUpRrIzoGLHD
 def makeDefaultCookies(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,vToken=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,vUserinfo=iNBAmXQcetsguwTxSlMUpRrIzoGLPW):
  iNBAmXQcetsguwTxSlMUpRrIzoGLHf={}
  iNBAmXQcetsguwTxSlMUpRrIzoGLHf['_tving_token']=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.TVING_TOKEN if vToken==iNBAmXQcetsguwTxSlMUpRrIzoGLPW else vToken
  iNBAmXQcetsguwTxSlMUpRrIzoGLHf['POC_USERINFO']=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.POC_USERINFO if vToken==iNBAmXQcetsguwTxSlMUpRrIzoGLPW else vUserinfo
  return iNBAmXQcetsguwTxSlMUpRrIzoGLHf
 def getDeviceStr(iNBAmXQcetsguwTxSlMUpRrIzoGLHy):
  iNBAmXQcetsguwTxSlMUpRrIzoGLHn=[]
  iNBAmXQcetsguwTxSlMUpRrIzoGLHn.append('Windows') 
  iNBAmXQcetsguwTxSlMUpRrIzoGLHn.append('Chrome') 
  iNBAmXQcetsguwTxSlMUpRrIzoGLHn.append('ko-KR') 
  iNBAmXQcetsguwTxSlMUpRrIzoGLHn.append('undefined') 
  iNBAmXQcetsguwTxSlMUpRrIzoGLHn.append('24') 
  iNBAmXQcetsguwTxSlMUpRrIzoGLHn.append(u'한국 표준시')
  iNBAmXQcetsguwTxSlMUpRrIzoGLHn.append('undefined') 
  iNBAmXQcetsguwTxSlMUpRrIzoGLHn.append('undefined') 
  iNBAmXQcetsguwTxSlMUpRrIzoGLHn.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  iNBAmXQcetsguwTxSlMUpRrIzoGLHO=''
  for iNBAmXQcetsguwTxSlMUpRrIzoGLHJ in iNBAmXQcetsguwTxSlMUpRrIzoGLHn:
   iNBAmXQcetsguwTxSlMUpRrIzoGLHO+=iNBAmXQcetsguwTxSlMUpRrIzoGLHJ+'|'
  return iNBAmXQcetsguwTxSlMUpRrIzoGLHO
 def SaveCredential(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,iNBAmXQcetsguwTxSlMUpRrIzoGLHK):
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.TVING_TOKEN =iNBAmXQcetsguwTxSlMUpRrIzoGLHK.get('tving_token')
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.POC_USERINFO=iNBAmXQcetsguwTxSlMUpRrIzoGLHK.get('poc_userinfo')
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.TVING_UUID =iNBAmXQcetsguwTxSlMUpRrIzoGLHK.get('tving_uuid')
 def LoadCredential(iNBAmXQcetsguwTxSlMUpRrIzoGLHy):
  iNBAmXQcetsguwTxSlMUpRrIzoGLHK={'tving_token':iNBAmXQcetsguwTxSlMUpRrIzoGLHy.TVING_TOKEN,'poc_userinfo':iNBAmXQcetsguwTxSlMUpRrIzoGLHy.POC_USERINFO,'tving_uuid':iNBAmXQcetsguwTxSlMUpRrIzoGLHy.TVING_UUID}
  return iNBAmXQcetsguwTxSlMUpRrIzoGLHK
 def GetDefaultParams(iNBAmXQcetsguwTxSlMUpRrIzoGLHy):
  iNBAmXQcetsguwTxSlMUpRrIzoGLHb={'apiKey':iNBAmXQcetsguwTxSlMUpRrIzoGLHy.APIKEY,'networkCode':iNBAmXQcetsguwTxSlMUpRrIzoGLHy.NETWORKCODE,'osCode':iNBAmXQcetsguwTxSlMUpRrIzoGLHy.OSCODE,'teleCode':iNBAmXQcetsguwTxSlMUpRrIzoGLHy.TELECODE,'screenCode':iNBAmXQcetsguwTxSlMUpRrIzoGLHy.SCREENCODE}
  return iNBAmXQcetsguwTxSlMUpRrIzoGLHb
 def GetNoCache(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,timetype=1):
  if timetype==1:
   return iNBAmXQcetsguwTxSlMUpRrIzoGLyH(time.time())
  else:
   return iNBAmXQcetsguwTxSlMUpRrIzoGLyH(time.time()*1000)
 def makeurl(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,domain,path,query1=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,query2=iNBAmXQcetsguwTxSlMUpRrIzoGLPW):
  iNBAmXQcetsguwTxSlMUpRrIzoGLHa=domain+path
  if query1:
   iNBAmXQcetsguwTxSlMUpRrIzoGLHa+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   iNBAmXQcetsguwTxSlMUpRrIzoGLHa+='&%s'%urllib.parse.urlencode(query2)
  return iNBAmXQcetsguwTxSlMUpRrIzoGLHa
 def GetCredential(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,user_id,user_pw,login_type):
  iNBAmXQcetsguwTxSlMUpRrIzoGLHE=iNBAmXQcetsguwTxSlMUpRrIzoGLPk
  iNBAmXQcetsguwTxSlMUpRrIzoGLHV=iNBAmXQcetsguwTxSlMUpRrIzoGLjH='' 
  iNBAmXQcetsguwTxSlMUpRrIzoGLHC='-'
  try:
   iNBAmXQcetsguwTxSlMUpRrIzoGLHh=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   iNBAmXQcetsguwTxSlMUpRrIzoGLHF={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'','csite':''}
   iNBAmXQcetsguwTxSlMUpRrIzoGLHW=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.callRequestCookies('Post',iNBAmXQcetsguwTxSlMUpRrIzoGLHh,payload=iNBAmXQcetsguwTxSlMUpRrIzoGLHF,params=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,cookies=iNBAmXQcetsguwTxSlMUpRrIzoGLPW)
   for iNBAmXQcetsguwTxSlMUpRrIzoGLHk in iNBAmXQcetsguwTxSlMUpRrIzoGLHW.cookies:
    if iNBAmXQcetsguwTxSlMUpRrIzoGLHk.name=='_tving_token':
     iNBAmXQcetsguwTxSlMUpRrIzoGLHV=iNBAmXQcetsguwTxSlMUpRrIzoGLHk.value
    elif iNBAmXQcetsguwTxSlMUpRrIzoGLHk.name=='POC_USERINFO':
     iNBAmXQcetsguwTxSlMUpRrIzoGLjH=iNBAmXQcetsguwTxSlMUpRrIzoGLHk.value
   if iNBAmXQcetsguwTxSlMUpRrIzoGLHV:iNBAmXQcetsguwTxSlMUpRrIzoGLHE=iNBAmXQcetsguwTxSlMUpRrIzoGLyj
   iNBAmXQcetsguwTxSlMUpRrIzoGLHC=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetDeviceList(iNBAmXQcetsguwTxSlMUpRrIzoGLHV,iNBAmXQcetsguwTxSlMUpRrIzoGLjH)
  except iNBAmXQcetsguwTxSlMUpRrIzoGLyY as exception:
   iNBAmXQcetsguwTxSlMUpRrIzoGLHV=iNBAmXQcetsguwTxSlMUpRrIzoGLjH='' 
   iNBAmXQcetsguwTxSlMUpRrIzoGLHC='-'
   iNBAmXQcetsguwTxSlMUpRrIzoGLyP(exception)
  iNBAmXQcetsguwTxSlMUpRrIzoGLHK={'tving_token':iNBAmXQcetsguwTxSlMUpRrIzoGLHV,'poc_userinfo':iNBAmXQcetsguwTxSlMUpRrIzoGLjH,'tving_uuid':iNBAmXQcetsguwTxSlMUpRrIzoGLHC}
  iNBAmXQcetsguwTxSlMUpRrIzoGLHy.SaveCredential(iNBAmXQcetsguwTxSlMUpRrIzoGLHK)
  return iNBAmXQcetsguwTxSlMUpRrIzoGLHE
 def Get_Now_Datetime(iNBAmXQcetsguwTxSlMUpRrIzoGLHy):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,mediacode,sel_quality,stype,pvrmode='-'):
  iNBAmXQcetsguwTxSlMUpRrIzoGLjP=''
  iNBAmXQcetsguwTxSlMUpRrIzoGLjy=''
  iNBAmXQcetsguwTxSlMUpRrIzoGLjd=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.TVING_UUID 
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    iNBAmXQcetsguwTxSlMUpRrIzoGLjD ='/v2/media/stream/info'
    iNBAmXQcetsguwTxSlMUpRrIzoGLjf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetDefaultParams()
    iNBAmXQcetsguwTxSlMUpRrIzoGLjn={'info':'N','mediaCode':mediacode,'noCache':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetNoCache(1)),'callingFrom':'HTML5','adReq':'none','ooc':'','deviceId':iNBAmXQcetsguwTxSlMUpRrIzoGLjd,'wm':'Y'}
    iNBAmXQcetsguwTxSlMUpRrIzoGLjf.update(iNBAmXQcetsguwTxSlMUpRrIzoGLjn)
    iNBAmXQcetsguwTxSlMUpRrIzoGLHa=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeurl(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.API_DOMAIN,iNBAmXQcetsguwTxSlMUpRrIzoGLjD)
    iNBAmXQcetsguwTxSlMUpRrIzoGLHf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeDefaultCookies()
    iNBAmXQcetsguwTxSlMUpRrIzoGLHW=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.callRequestCookies('Get',iNBAmXQcetsguwTxSlMUpRrIzoGLHa,payload=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,params=iNBAmXQcetsguwTxSlMUpRrIzoGLjf,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,cookies=iNBAmXQcetsguwTxSlMUpRrIzoGLHf)
    iNBAmXQcetsguwTxSlMUpRrIzoGLjO=json.loads(iNBAmXQcetsguwTxSlMUpRrIzoGLHW.text)
    if not('stream' in iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']):return iNBAmXQcetsguwTxSlMUpRrIzoGLjP,iNBAmXQcetsguwTxSlMUpRrIzoGLjy 
    iNBAmXQcetsguwTxSlMUpRrIzoGLjJ=iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']['stream']
    iNBAmXQcetsguwTxSlMUpRrIzoGLjK=iNBAmXQcetsguwTxSlMUpRrIzoGLjJ['quality']
    iNBAmXQcetsguwTxSlMUpRrIzoGLjb=[]
    for iNBAmXQcetsguwTxSlMUpRrIzoGLja in iNBAmXQcetsguwTxSlMUpRrIzoGLjK:
     if iNBAmXQcetsguwTxSlMUpRrIzoGLja['active']=='Y':
      iNBAmXQcetsguwTxSlMUpRrIzoGLjb.append({iNBAmXQcetsguwTxSlMUpRrIzoGLHP.get(iNBAmXQcetsguwTxSlMUpRrIzoGLja['code']):iNBAmXQcetsguwTxSlMUpRrIzoGLja['code']})
    iNBAmXQcetsguwTxSlMUpRrIzoGLjq=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.CheckQuality(sel_quality,iNBAmXQcetsguwTxSlMUpRrIzoGLjb)
   else:
    for iNBAmXQcetsguwTxSlMUpRrIzoGLjv,iNBAmXQcetsguwTxSlMUpRrIzoGLYH in iNBAmXQcetsguwTxSlMUpRrIzoGLHP.items():
     if iNBAmXQcetsguwTxSlMUpRrIzoGLYH==sel_quality:
      iNBAmXQcetsguwTxSlMUpRrIzoGLjq=iNBAmXQcetsguwTxSlMUpRrIzoGLjv
  except iNBAmXQcetsguwTxSlMUpRrIzoGLyY as exception:
   iNBAmXQcetsguwTxSlMUpRrIzoGLyP(exception)
   for iNBAmXQcetsguwTxSlMUpRrIzoGLjv,iNBAmXQcetsguwTxSlMUpRrIzoGLYH in iNBAmXQcetsguwTxSlMUpRrIzoGLHP.items():
    if iNBAmXQcetsguwTxSlMUpRrIzoGLYH==sel_quality:
     iNBAmXQcetsguwTxSlMUpRrIzoGLjq=iNBAmXQcetsguwTxSlMUpRrIzoGLjv
   return iNBAmXQcetsguwTxSlMUpRrIzoGLjP,iNBAmXQcetsguwTxSlMUpRrIzoGLjy
  try:
   iNBAmXQcetsguwTxSlMUpRrIzoGLjD ='/streaming/info'
   iNBAmXQcetsguwTxSlMUpRrIzoGLjf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetDefaultParams()
   if stype=='onair':iNBAmXQcetsguwTxSlMUpRrIzoGLjf['osCode']='CSOD0400' 
   iNBAmXQcetsguwTxSlMUpRrIzoGLjE={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2158.7350000045262','returnValue':'true','cancelBubble':'false'}
   iNBAmXQcetsguwTxSlMUpRrIzoGLjV=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeOocUrl(iNBAmXQcetsguwTxSlMUpRrIzoGLjE)
   iNBAmXQcetsguwTxSlMUpRrIzoGLjC=urllib.parse.quote(iNBAmXQcetsguwTxSlMUpRrIzoGLjV)
   iNBAmXQcetsguwTxSlMUpRrIzoGLjn={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':iNBAmXQcetsguwTxSlMUpRrIzoGLjq,'adReq':'none','ooc':iNBAmXQcetsguwTxSlMUpRrIzoGLjV,'deviceId':iNBAmXQcetsguwTxSlMUpRrIzoGLjd}
   iNBAmXQcetsguwTxSlMUpRrIzoGLjh =iNBAmXQcetsguwTxSlMUpRrIzoGLjf
   iNBAmXQcetsguwTxSlMUpRrIzoGLjh.update(iNBAmXQcetsguwTxSlMUpRrIzoGLjn)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHa=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.URL_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLjD
   iNBAmXQcetsguwTxSlMUpRrIzoGLjF={'origin':'https://www.tving.com','Referer':'https://www.tving.com/vod/player/'+mediacode}
   iNBAmXQcetsguwTxSlMUpRrIzoGLHf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeDefaultCookies()
   iNBAmXQcetsguwTxSlMUpRrIzoGLHf['onClickEvent2']=iNBAmXQcetsguwTxSlMUpRrIzoGLjC
   iNBAmXQcetsguwTxSlMUpRrIzoGLHW=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.callRequestCookies('Post',iNBAmXQcetsguwTxSlMUpRrIzoGLHa,payload=iNBAmXQcetsguwTxSlMUpRrIzoGLjh,params=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLjF,cookies=iNBAmXQcetsguwTxSlMUpRrIzoGLHf)
   iNBAmXQcetsguwTxSlMUpRrIzoGLjO=json.loads(iNBAmXQcetsguwTxSlMUpRrIzoGLHW.text)
   if 'drm_license_assertion' in iNBAmXQcetsguwTxSlMUpRrIzoGLjO['stream']:
    iNBAmXQcetsguwTxSlMUpRrIzoGLjy =iNBAmXQcetsguwTxSlMUpRrIzoGLjO['stream']['drm_license_assertion']
    iNBAmXQcetsguwTxSlMUpRrIzoGLjP=iNBAmXQcetsguwTxSlMUpRrIzoGLjO['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in iNBAmXQcetsguwTxSlMUpRrIzoGLjO['stream']['broadcast']):return iNBAmXQcetsguwTxSlMUpRrIzoGLjP,iNBAmXQcetsguwTxSlMUpRrIzoGLjy
    iNBAmXQcetsguwTxSlMUpRrIzoGLjP=iNBAmXQcetsguwTxSlMUpRrIzoGLjO['stream']['broadcast']['broad_url']
  except iNBAmXQcetsguwTxSlMUpRrIzoGLyY as exception:
   iNBAmXQcetsguwTxSlMUpRrIzoGLyP(exception)
  return iNBAmXQcetsguwTxSlMUpRrIzoGLjP,iNBAmXQcetsguwTxSlMUpRrIzoGLjy
 def CheckQuality(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,sel_qt,iNBAmXQcetsguwTxSlMUpRrIzoGLjb):
  for iNBAmXQcetsguwTxSlMUpRrIzoGLjW in iNBAmXQcetsguwTxSlMUpRrIzoGLjb:
   if sel_qt>=iNBAmXQcetsguwTxSlMUpRrIzoGLyD(iNBAmXQcetsguwTxSlMUpRrIzoGLjW)[0]:return iNBAmXQcetsguwTxSlMUpRrIzoGLjW.get(iNBAmXQcetsguwTxSlMUpRrIzoGLyD(iNBAmXQcetsguwTxSlMUpRrIzoGLjW)[0])
   iNBAmXQcetsguwTxSlMUpRrIzoGLjk=iNBAmXQcetsguwTxSlMUpRrIzoGLjW.get(iNBAmXQcetsguwTxSlMUpRrIzoGLyD(iNBAmXQcetsguwTxSlMUpRrIzoGLjW)[0])
  return iNBAmXQcetsguwTxSlMUpRrIzoGLjk
 def makeOocUrl(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,iNBAmXQcetsguwTxSlMUpRrIzoGLjE):
  iNBAmXQcetsguwTxSlMUpRrIzoGLHa=''
  for iNBAmXQcetsguwTxSlMUpRrIzoGLjv,iNBAmXQcetsguwTxSlMUpRrIzoGLYH in iNBAmXQcetsguwTxSlMUpRrIzoGLjE.items():
   iNBAmXQcetsguwTxSlMUpRrIzoGLHa+="%s=%s^"%(iNBAmXQcetsguwTxSlMUpRrIzoGLjv,iNBAmXQcetsguwTxSlMUpRrIzoGLYH)
  return iNBAmXQcetsguwTxSlMUpRrIzoGLHa
 def GetLiveChannelList(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,stype,page_int):
  iNBAmXQcetsguwTxSlMUpRrIzoGLYj=[]
  iNBAmXQcetsguwTxSlMUpRrIzoGLYP=iNBAmXQcetsguwTxSlMUpRrIzoGLPk
  try:
   iNBAmXQcetsguwTxSlMUpRrIzoGLjD ='/v2/media/lives'
   if stype=='onair':
    iNBAmXQcetsguwTxSlMUpRrIzoGLYy='CPCS0100,CPCS0400'
   else:
    iNBAmXQcetsguwTxSlMUpRrIzoGLYy='CPCS0300'
   iNBAmXQcetsguwTxSlMUpRrIzoGLjf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetDefaultParams()
   iNBAmXQcetsguwTxSlMUpRrIzoGLjn={'pageNo':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(page_int),'pageSize':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':iNBAmXQcetsguwTxSlMUpRrIzoGLYy,'_':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetNoCache(2))}
   iNBAmXQcetsguwTxSlMUpRrIzoGLjf.update(iNBAmXQcetsguwTxSlMUpRrIzoGLjn)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHa=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeurl(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.API_DOMAIN,iNBAmXQcetsguwTxSlMUpRrIzoGLjD)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeDefaultCookies()
   iNBAmXQcetsguwTxSlMUpRrIzoGLHW=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.callRequestCookies('Get',iNBAmXQcetsguwTxSlMUpRrIzoGLHa,payload=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,params=iNBAmXQcetsguwTxSlMUpRrIzoGLjf,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,cookies=iNBAmXQcetsguwTxSlMUpRrIzoGLHf)
   iNBAmXQcetsguwTxSlMUpRrIzoGLjO=json.loads(iNBAmXQcetsguwTxSlMUpRrIzoGLHW.text)
   if not('result' in iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']):return iNBAmXQcetsguwTxSlMUpRrIzoGLYj,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
   iNBAmXQcetsguwTxSlMUpRrIzoGLYd=iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']['result']
   for iNBAmXQcetsguwTxSlMUpRrIzoGLja in iNBAmXQcetsguwTxSlMUpRrIzoGLYd:
    iNBAmXQcetsguwTxSlMUpRrIzoGLYD={}
    iNBAmXQcetsguwTxSlMUpRrIzoGLYD['mediatype']='video'
    iNBAmXQcetsguwTxSlMUpRrIzoGLYf=iNBAmXQcetsguwTxSlMUpRrIzoGLYJ=iNBAmXQcetsguwTxSlMUpRrIzoGLYK=iNBAmXQcetsguwTxSlMUpRrIzoGLYb=''
    iNBAmXQcetsguwTxSlMUpRrIzoGLYn=iNBAmXQcetsguwTxSlMUpRrIzoGLYE=''
    iNBAmXQcetsguwTxSlMUpRrIzoGLYO=iNBAmXQcetsguwTxSlMUpRrIzoGLja['live_code']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYf =iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['channel']['name']['ko']
    if iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['episode']!=iNBAmXQcetsguwTxSlMUpRrIzoGLPW:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYJ =iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['program']['name']['ko']
     iNBAmXQcetsguwTxSlMUpRrIzoGLYJ =iNBAmXQcetsguwTxSlMUpRrIzoGLYJ+', '+iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['episode']['frequency'])+'회'
     if iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['episode']['image']!=[]:
      iNBAmXQcetsguwTxSlMUpRrIzoGLYK=iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['episode']['image'][0]['url']
     iNBAmXQcetsguwTxSlMUpRrIzoGLYb=iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['episode']['synopsis']['ko']
    else:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYJ =iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['program']['name']['ko']
     if iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['program']['image']!=[]:
      iNBAmXQcetsguwTxSlMUpRrIzoGLYK=iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['program']['image'][0]['url']
     iNBAmXQcetsguwTxSlMUpRrIzoGLYb=iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['program']['synopsis']['ko']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYD['title'] =iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['program']['name']['ko']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYD['studio'] =iNBAmXQcetsguwTxSlMUpRrIzoGLYf
    try:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYa=[]
     for iNBAmXQcetsguwTxSlMUpRrIzoGLYq in iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('schedule').get('program').get('actor'):iNBAmXQcetsguwTxSlMUpRrIzoGLYa.append(iNBAmXQcetsguwTxSlMUpRrIzoGLYq)
     if iNBAmXQcetsguwTxSlMUpRrIzoGLYa[0]!='' and iNBAmXQcetsguwTxSlMUpRrIzoGLYa[0]!=u'없음':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['cast']=iNBAmXQcetsguwTxSlMUpRrIzoGLYa
    except:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPW
    try:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYv=[]
     if iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('schedule').get('program').get('category1_name').get('ko')!='':
      iNBAmXQcetsguwTxSlMUpRrIzoGLYv.append(iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['program']['category1_name']['ko'])
     if iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('schedule').get('program').get('category2_name').get('ko')!='':
      iNBAmXQcetsguwTxSlMUpRrIzoGLYv.append(iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['program']['category2_name']['ko'])
     if iNBAmXQcetsguwTxSlMUpRrIzoGLYv[0]!='':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['genre']=iNBAmXQcetsguwTxSlMUpRrIzoGLYv
    except:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPW
    if iNBAmXQcetsguwTxSlMUpRrIzoGLYK=='':
     iNBAmXQcetsguwTxSlMUpRrIzoGLYK=iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['channel']['image'][0]['url']
    if iNBAmXQcetsguwTxSlMUpRrIzoGLYK!='':iNBAmXQcetsguwTxSlMUpRrIzoGLYK=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLYK
    iNBAmXQcetsguwTxSlMUpRrIzoGLYn=iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['broadcast_start_time'])[8:12]
    iNBAmXQcetsguwTxSlMUpRrIzoGLYE =iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLja['schedule']['broadcast_end_time'])[8:12]
    iNBAmXQcetsguwTxSlMUpRrIzoGLYV={'channel':iNBAmXQcetsguwTxSlMUpRrIzoGLYf,'title':iNBAmXQcetsguwTxSlMUpRrIzoGLYJ,'mediacode':iNBAmXQcetsguwTxSlMUpRrIzoGLYO,'thumbnail':iNBAmXQcetsguwTxSlMUpRrIzoGLYK,'synopsis':iNBAmXQcetsguwTxSlMUpRrIzoGLYb,'channelepg':' [%s:%s ~ %s:%s]'%(iNBAmXQcetsguwTxSlMUpRrIzoGLYn[0:2],iNBAmXQcetsguwTxSlMUpRrIzoGLYn[2:],iNBAmXQcetsguwTxSlMUpRrIzoGLYE[0:2],iNBAmXQcetsguwTxSlMUpRrIzoGLYE[2:]),'info':iNBAmXQcetsguwTxSlMUpRrIzoGLYD}
    iNBAmXQcetsguwTxSlMUpRrIzoGLYj.append(iNBAmXQcetsguwTxSlMUpRrIzoGLYV)
   if iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']['has_more']=='Y':iNBAmXQcetsguwTxSlMUpRrIzoGLYP=iNBAmXQcetsguwTxSlMUpRrIzoGLyj
  except iNBAmXQcetsguwTxSlMUpRrIzoGLyY as exception:
   iNBAmXQcetsguwTxSlMUpRrIzoGLyP(exception)
  return iNBAmXQcetsguwTxSlMUpRrIzoGLYj,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
 def GetProgramList(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,stype,orderby,page_int,landyn=iNBAmXQcetsguwTxSlMUpRrIzoGLPk):
  iNBAmXQcetsguwTxSlMUpRrIzoGLYj=[]
  iNBAmXQcetsguwTxSlMUpRrIzoGLYP=iNBAmXQcetsguwTxSlMUpRrIzoGLPk
  try:
   iNBAmXQcetsguwTxSlMUpRrIzoGLjD ='/v2/media/episodes'
   iNBAmXQcetsguwTxSlMUpRrIzoGLjf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetDefaultParams()
   iNBAmXQcetsguwTxSlMUpRrIzoGLjn={'pageNo':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(page_int),'pageSize':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetNoCache(2))}
   if stype!='all':iNBAmXQcetsguwTxSlMUpRrIzoGLjn['multiCategoryCode']=stype
   iNBAmXQcetsguwTxSlMUpRrIzoGLjf.update(iNBAmXQcetsguwTxSlMUpRrIzoGLjn)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHa=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeurl(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.API_DOMAIN,iNBAmXQcetsguwTxSlMUpRrIzoGLjD)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeDefaultCookies()
   iNBAmXQcetsguwTxSlMUpRrIzoGLHW=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.callRequestCookies('Get',iNBAmXQcetsguwTxSlMUpRrIzoGLHa,payload=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,params=iNBAmXQcetsguwTxSlMUpRrIzoGLjf,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,cookies=iNBAmXQcetsguwTxSlMUpRrIzoGLHf)
   iNBAmXQcetsguwTxSlMUpRrIzoGLjO=json.loads(iNBAmXQcetsguwTxSlMUpRrIzoGLHW.text)
   if not('result' in iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']):return iNBAmXQcetsguwTxSlMUpRrIzoGLYj,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
   iNBAmXQcetsguwTxSlMUpRrIzoGLYd=iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']['result']
   for iNBAmXQcetsguwTxSlMUpRrIzoGLja in iNBAmXQcetsguwTxSlMUpRrIzoGLYd:
    iNBAmXQcetsguwTxSlMUpRrIzoGLYC=iNBAmXQcetsguwTxSlMUpRrIzoGLja['program']['code']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYJ =iNBAmXQcetsguwTxSlMUpRrIzoGLja['program']['name']['ko']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYK =iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLja['program']['image'][0]['url']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYh='CAIP0200' if landyn else 'CAIP0900' 
    for iNBAmXQcetsguwTxSlMUpRrIzoGLYF in iNBAmXQcetsguwTxSlMUpRrIzoGLja['program']['image']:
     if iNBAmXQcetsguwTxSlMUpRrIzoGLYF['code']==iNBAmXQcetsguwTxSlMUpRrIzoGLYh:
      iNBAmXQcetsguwTxSlMUpRrIzoGLYK =iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLYF['url']
      break
    iNBAmXQcetsguwTxSlMUpRrIzoGLYb =iNBAmXQcetsguwTxSlMUpRrIzoGLja['program']['synopsis']['ko']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYW=iNBAmXQcetsguwTxSlMUpRrIzoGLja['program']['channel_code']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYD={}
    iNBAmXQcetsguwTxSlMUpRrIzoGLYD['title'] =iNBAmXQcetsguwTxSlMUpRrIzoGLYJ 
    iNBAmXQcetsguwTxSlMUpRrIzoGLYD['mediatype']='episode' 
    try:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYa=[]
     for iNBAmXQcetsguwTxSlMUpRrIzoGLYq in iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('program').get('actor'):iNBAmXQcetsguwTxSlMUpRrIzoGLYa.append(iNBAmXQcetsguwTxSlMUpRrIzoGLYq)
     if iNBAmXQcetsguwTxSlMUpRrIzoGLYa[0]!='' and iNBAmXQcetsguwTxSlMUpRrIzoGLYa[0]!='-':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['cast']=iNBAmXQcetsguwTxSlMUpRrIzoGLYa
    except:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPW
    try:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYk=[]
     for iNBAmXQcetsguwTxSlMUpRrIzoGLPH in iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('program').get('director'):iNBAmXQcetsguwTxSlMUpRrIzoGLYk.append(iNBAmXQcetsguwTxSlMUpRrIzoGLPH)
     if iNBAmXQcetsguwTxSlMUpRrIzoGLYk[0]!='' and iNBAmXQcetsguwTxSlMUpRrIzoGLYk[0]!='-':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['director']=iNBAmXQcetsguwTxSlMUpRrIzoGLYk
    except:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPW
    iNBAmXQcetsguwTxSlMUpRrIzoGLYv=[]
    if iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('program').get('category1_name').get('ko')!='':
     iNBAmXQcetsguwTxSlMUpRrIzoGLYv.append(iNBAmXQcetsguwTxSlMUpRrIzoGLja['program']['category1_name']['ko'])
    if iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('program').get('category2_name').get('ko')!='':
     iNBAmXQcetsguwTxSlMUpRrIzoGLYv.append(iNBAmXQcetsguwTxSlMUpRrIzoGLja['program']['category2_name']['ko'])
    if iNBAmXQcetsguwTxSlMUpRrIzoGLYv[0]!='':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['genre']=iNBAmXQcetsguwTxSlMUpRrIzoGLYv
    try:
     if iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('program').get('product_year'):iNBAmXQcetsguwTxSlMUpRrIzoGLYD['year']=iNBAmXQcetsguwTxSlMUpRrIzoGLja['program']['product_year']
     if 'broad_dt' in iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('program'):
      iNBAmXQcetsguwTxSlMUpRrIzoGLPj=iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('program').get('broad_dt')
      iNBAmXQcetsguwTxSlMUpRrIzoGLYD['aired']='%s-%s-%s'%(iNBAmXQcetsguwTxSlMUpRrIzoGLPj[:4],iNBAmXQcetsguwTxSlMUpRrIzoGLPj[4:6],iNBAmXQcetsguwTxSlMUpRrIzoGLPj[6:])
    except:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPW
    iNBAmXQcetsguwTxSlMUpRrIzoGLYV={'program':iNBAmXQcetsguwTxSlMUpRrIzoGLYC,'title':iNBAmXQcetsguwTxSlMUpRrIzoGLYJ,'thumbnail':iNBAmXQcetsguwTxSlMUpRrIzoGLYK,'synopsis':iNBAmXQcetsguwTxSlMUpRrIzoGLYb,'channel':iNBAmXQcetsguwTxSlMUpRrIzoGLYW,'info':iNBAmXQcetsguwTxSlMUpRrIzoGLYD}
    iNBAmXQcetsguwTxSlMUpRrIzoGLYj.append(iNBAmXQcetsguwTxSlMUpRrIzoGLYV)
   if iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']['has_more']=='Y':iNBAmXQcetsguwTxSlMUpRrIzoGLYP=iNBAmXQcetsguwTxSlMUpRrIzoGLyj
  except iNBAmXQcetsguwTxSlMUpRrIzoGLyY as exception:
   iNBAmXQcetsguwTxSlMUpRrIzoGLyP(exception)
  return iNBAmXQcetsguwTxSlMUpRrIzoGLYj,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
 def GetEpisodoList(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,program_code,page_int,orderby='desc'):
  iNBAmXQcetsguwTxSlMUpRrIzoGLYj=[]
  iNBAmXQcetsguwTxSlMUpRrIzoGLYP=iNBAmXQcetsguwTxSlMUpRrIzoGLPk
  try:
   iNBAmXQcetsguwTxSlMUpRrIzoGLjD ='/v2/media/frequency/program/'+program_code
   iNBAmXQcetsguwTxSlMUpRrIzoGLjf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetDefaultParams()
   iNBAmXQcetsguwTxSlMUpRrIzoGLjn={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetNoCache(2))}
   iNBAmXQcetsguwTxSlMUpRrIzoGLjf.update(iNBAmXQcetsguwTxSlMUpRrIzoGLjn)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHa=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeurl(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.API_DOMAIN,iNBAmXQcetsguwTxSlMUpRrIzoGLjD)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeDefaultCookies()
   iNBAmXQcetsguwTxSlMUpRrIzoGLHW=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.callRequestCookies('Get',iNBAmXQcetsguwTxSlMUpRrIzoGLHa,payload=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,params=iNBAmXQcetsguwTxSlMUpRrIzoGLjf,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,cookies=iNBAmXQcetsguwTxSlMUpRrIzoGLHf)
   iNBAmXQcetsguwTxSlMUpRrIzoGLjO=json.loads(iNBAmXQcetsguwTxSlMUpRrIzoGLHW.text)
   if not('result' in iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']):return iNBAmXQcetsguwTxSlMUpRrIzoGLYj,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
   iNBAmXQcetsguwTxSlMUpRrIzoGLYd=iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']['result']
   iNBAmXQcetsguwTxSlMUpRrIzoGLPY=iNBAmXQcetsguwTxSlMUpRrIzoGLyH(iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']['total_count'])
   iNBAmXQcetsguwTxSlMUpRrIzoGLPy =iNBAmXQcetsguwTxSlMUpRrIzoGLyH(iNBAmXQcetsguwTxSlMUpRrIzoGLPY//(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    iNBAmXQcetsguwTxSlMUpRrIzoGLPd =(iNBAmXQcetsguwTxSlMUpRrIzoGLPY-1)-((page_int-1)*iNBAmXQcetsguwTxSlMUpRrIzoGLHy.EPISODE_LIMIT)
   else:
    iNBAmXQcetsguwTxSlMUpRrIzoGLPd =(page_int-1)*iNBAmXQcetsguwTxSlMUpRrIzoGLHy.EPISODE_LIMIT
   for i in iNBAmXQcetsguwTxSlMUpRrIzoGLyf(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.EPISODE_LIMIT):
    if orderby=='desc':
     iNBAmXQcetsguwTxSlMUpRrIzoGLPD=iNBAmXQcetsguwTxSlMUpRrIzoGLPd-i
     if iNBAmXQcetsguwTxSlMUpRrIzoGLPD<0:break
    else:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPD=iNBAmXQcetsguwTxSlMUpRrIzoGLPd+i
     if iNBAmXQcetsguwTxSlMUpRrIzoGLPD>=iNBAmXQcetsguwTxSlMUpRrIzoGLPY:break
    iNBAmXQcetsguwTxSlMUpRrIzoGLPf=iNBAmXQcetsguwTxSlMUpRrIzoGLYd[iNBAmXQcetsguwTxSlMUpRrIzoGLPD]['episode']['code']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYJ =iNBAmXQcetsguwTxSlMUpRrIzoGLYd[iNBAmXQcetsguwTxSlMUpRrIzoGLPD]['vod_name']['ko']
    iNBAmXQcetsguwTxSlMUpRrIzoGLPn =''
    try:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPj=iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLYd[iNBAmXQcetsguwTxSlMUpRrIzoGLPD]['episode']['broadcast_date'])
     iNBAmXQcetsguwTxSlMUpRrIzoGLPn='%s-%s-%s'%(iNBAmXQcetsguwTxSlMUpRrIzoGLPj[:4],iNBAmXQcetsguwTxSlMUpRrIzoGLPj[4:6],iNBAmXQcetsguwTxSlMUpRrIzoGLPj[6:])
    except:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPW
    if iNBAmXQcetsguwTxSlMUpRrIzoGLYd[iNBAmXQcetsguwTxSlMUpRrIzoGLPD]['episode']['image']!=[]:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYK=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLYd[iNBAmXQcetsguwTxSlMUpRrIzoGLPD]['episode']['image'][0]['url']
    else:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYK=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLYd[iNBAmXQcetsguwTxSlMUpRrIzoGLPD]['program']['image'][0]['url']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYb =iNBAmXQcetsguwTxSlMUpRrIzoGLYd[iNBAmXQcetsguwTxSlMUpRrIzoGLPD]['episode']['synopsis']['ko']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYD={}
    iNBAmXQcetsguwTxSlMUpRrIzoGLYD['mediatype']='episode' 
    try:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYD['title'] =iNBAmXQcetsguwTxSlMUpRrIzoGLYd[iNBAmXQcetsguwTxSlMUpRrIzoGLPD]['program']['name']['ko']
     iNBAmXQcetsguwTxSlMUpRrIzoGLYD['aired'] =iNBAmXQcetsguwTxSlMUpRrIzoGLPn
     iNBAmXQcetsguwTxSlMUpRrIzoGLYD['studio'] =iNBAmXQcetsguwTxSlMUpRrIzoGLYd[iNBAmXQcetsguwTxSlMUpRrIzoGLPD]['channel']['name']['ko']
     if 'frequency' in iNBAmXQcetsguwTxSlMUpRrIzoGLYd[iNBAmXQcetsguwTxSlMUpRrIzoGLPD]['episode']:iNBAmXQcetsguwTxSlMUpRrIzoGLYD['episode']=iNBAmXQcetsguwTxSlMUpRrIzoGLYd[iNBAmXQcetsguwTxSlMUpRrIzoGLPD]['episode']['frequency']
    except:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPW
    iNBAmXQcetsguwTxSlMUpRrIzoGLYV={'episode':iNBAmXQcetsguwTxSlMUpRrIzoGLPf,'title':iNBAmXQcetsguwTxSlMUpRrIzoGLYJ,'subtitle':iNBAmXQcetsguwTxSlMUpRrIzoGLPn,'thumbnail':iNBAmXQcetsguwTxSlMUpRrIzoGLYK,'synopsis':iNBAmXQcetsguwTxSlMUpRrIzoGLYb,'info':iNBAmXQcetsguwTxSlMUpRrIzoGLYD}
    iNBAmXQcetsguwTxSlMUpRrIzoGLYj.append(iNBAmXQcetsguwTxSlMUpRrIzoGLYV)
   if iNBAmXQcetsguwTxSlMUpRrIzoGLPy>page_int:iNBAmXQcetsguwTxSlMUpRrIzoGLYP=iNBAmXQcetsguwTxSlMUpRrIzoGLyj
  except iNBAmXQcetsguwTxSlMUpRrIzoGLyY as exception:
   iNBAmXQcetsguwTxSlMUpRrIzoGLyP(exception)
  return iNBAmXQcetsguwTxSlMUpRrIzoGLYj,iNBAmXQcetsguwTxSlMUpRrIzoGLYP,iNBAmXQcetsguwTxSlMUpRrIzoGLPy
 def GetMovieList(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,orderby,page_int,premiumyn=iNBAmXQcetsguwTxSlMUpRrIzoGLPk,landyn=iNBAmXQcetsguwTxSlMUpRrIzoGLPk):
  iNBAmXQcetsguwTxSlMUpRrIzoGLYj=[]
  iNBAmXQcetsguwTxSlMUpRrIzoGLYP=iNBAmXQcetsguwTxSlMUpRrIzoGLPk
  if premiumyn==iNBAmXQcetsguwTxSlMUpRrIzoGLyj:
   iNBAmXQcetsguwTxSlMUpRrIzoGLPO=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.MOVIE_LITE+','+iNBAmXQcetsguwTxSlMUpRrIzoGLHy.MOVIE_PREMIUM
  else:
   iNBAmXQcetsguwTxSlMUpRrIzoGLPO=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.MOVIE_LITE
  try:
   iNBAmXQcetsguwTxSlMUpRrIzoGLjD ='/v2/media/movies'
   iNBAmXQcetsguwTxSlMUpRrIzoGLjf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetDefaultParams()
   iNBAmXQcetsguwTxSlMUpRrIzoGLjn={'pageNo':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(page_int),'pageSize':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','productPackageCode':iNBAmXQcetsguwTxSlMUpRrIzoGLPO,'_':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetNoCache(2))}
   iNBAmXQcetsguwTxSlMUpRrIzoGLjf.update(iNBAmXQcetsguwTxSlMUpRrIzoGLjn)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHa=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeurl(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.API_DOMAIN,iNBAmXQcetsguwTxSlMUpRrIzoGLjD)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeDefaultCookies()
   iNBAmXQcetsguwTxSlMUpRrIzoGLHW=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.callRequestCookies('Get',iNBAmXQcetsguwTxSlMUpRrIzoGLHa,payload=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,params=iNBAmXQcetsguwTxSlMUpRrIzoGLjf,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,cookies=iNBAmXQcetsguwTxSlMUpRrIzoGLHf)
   iNBAmXQcetsguwTxSlMUpRrIzoGLjO=json.loads(iNBAmXQcetsguwTxSlMUpRrIzoGLHW.text)
   if not('result' in iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']):return iNBAmXQcetsguwTxSlMUpRrIzoGLYj,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
   iNBAmXQcetsguwTxSlMUpRrIzoGLYd=iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']['result']
   for iNBAmXQcetsguwTxSlMUpRrIzoGLja in iNBAmXQcetsguwTxSlMUpRrIzoGLYd:
    iNBAmXQcetsguwTxSlMUpRrIzoGLPJ =iNBAmXQcetsguwTxSlMUpRrIzoGLja['movie']['code']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYJ =iNBAmXQcetsguwTxSlMUpRrIzoGLja['movie']['name']['ko'].strip()
    iNBAmXQcetsguwTxSlMUpRrIzoGLYJ +=u' (%s년)'%(iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('movie').get('product_year'))
    iNBAmXQcetsguwTxSlMUpRrIzoGLYK =iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLja['movie']['image'][0]['url']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYh='CAIM0400' if landyn else 'CAIM2100' 
    for iNBAmXQcetsguwTxSlMUpRrIzoGLYF in iNBAmXQcetsguwTxSlMUpRrIzoGLja['movie']['image']:
     if iNBAmXQcetsguwTxSlMUpRrIzoGLYF['code']==iNBAmXQcetsguwTxSlMUpRrIzoGLYh:
      iNBAmXQcetsguwTxSlMUpRrIzoGLYK =iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLYF['url']
      break
    iNBAmXQcetsguwTxSlMUpRrIzoGLYb =iNBAmXQcetsguwTxSlMUpRrIzoGLja['movie']['story']['ko']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYD={}
    iNBAmXQcetsguwTxSlMUpRrIzoGLYD['mediatype']='movie' 
    iNBAmXQcetsguwTxSlMUpRrIzoGLYD['title'] = iNBAmXQcetsguwTxSlMUpRrIzoGLja['movie']['name']['ko'].strip()
    iNBAmXQcetsguwTxSlMUpRrIzoGLYD['year'] =iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('movie').get('product_year')
    try:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYa=[]
     for iNBAmXQcetsguwTxSlMUpRrIzoGLYq in iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('movie').get('actor'):iNBAmXQcetsguwTxSlMUpRrIzoGLYa.append(iNBAmXQcetsguwTxSlMUpRrIzoGLYq)
     if iNBAmXQcetsguwTxSlMUpRrIzoGLYa[0]!='':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['cast']=iNBAmXQcetsguwTxSlMUpRrIzoGLYa
    except:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPW
    try:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYk=[]
     for iNBAmXQcetsguwTxSlMUpRrIzoGLPH in iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('movie').get('director'):iNBAmXQcetsguwTxSlMUpRrIzoGLYk.append(iNBAmXQcetsguwTxSlMUpRrIzoGLPH)
     if iNBAmXQcetsguwTxSlMUpRrIzoGLYk[0]!='':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['director']=iNBAmXQcetsguwTxSlMUpRrIzoGLYk
    except:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPW
    try:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYv=[]
     if iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('movie').get('category1_name').get('ko')!='':
      iNBAmXQcetsguwTxSlMUpRrIzoGLYv.append(iNBAmXQcetsguwTxSlMUpRrIzoGLja['movie']['category1_name']['ko'])
     if iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('movie').get('category2_name').get('ko')!='':
      iNBAmXQcetsguwTxSlMUpRrIzoGLYv.append(iNBAmXQcetsguwTxSlMUpRrIzoGLja['movie']['category2_name']['ko'])
     if iNBAmXQcetsguwTxSlMUpRrIzoGLYv[0]!='':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['genre']=iNBAmXQcetsguwTxSlMUpRrIzoGLYv
    except:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPW
    try:
     if 'release_date' in iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('movie'):
      iNBAmXQcetsguwTxSlMUpRrIzoGLPj=iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('movie').get('release_date'))
      iNBAmXQcetsguwTxSlMUpRrIzoGLYD['aired']='%s-%s-%s'%(iNBAmXQcetsguwTxSlMUpRrIzoGLPj[:4],iNBAmXQcetsguwTxSlMUpRrIzoGLPj[4:6],iNBAmXQcetsguwTxSlMUpRrIzoGLPj[6:])
    except:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPW
    try:
     if 'duration' in iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('movie'):iNBAmXQcetsguwTxSlMUpRrIzoGLYD['duration']=iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('movie').get('duration')
    except:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPW
    iNBAmXQcetsguwTxSlMUpRrIzoGLYV={'moviecode':iNBAmXQcetsguwTxSlMUpRrIzoGLPJ,'title':iNBAmXQcetsguwTxSlMUpRrIzoGLYJ,'thumbnail':iNBAmXQcetsguwTxSlMUpRrIzoGLYK,'synopsis':iNBAmXQcetsguwTxSlMUpRrIzoGLYb,'info':iNBAmXQcetsguwTxSlMUpRrIzoGLYD}
    if premiumyn==iNBAmXQcetsguwTxSlMUpRrIzoGLyj:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPK=iNBAmXQcetsguwTxSlMUpRrIzoGLPk
     for iNBAmXQcetsguwTxSlMUpRrIzoGLPb in iNBAmXQcetsguwTxSlMUpRrIzoGLja['billing_package_id']:
      if iNBAmXQcetsguwTxSlMUpRrIzoGLPb==iNBAmXQcetsguwTxSlMUpRrIzoGLHy.MOVIE_LITE:
       iNBAmXQcetsguwTxSlMUpRrIzoGLPK=iNBAmXQcetsguwTxSlMUpRrIzoGLyj
       break
     if iNBAmXQcetsguwTxSlMUpRrIzoGLPK==iNBAmXQcetsguwTxSlMUpRrIzoGLPk:
      iNBAmXQcetsguwTxSlMUpRrIzoGLYV['title']=iNBAmXQcetsguwTxSlMUpRrIzoGLYV['title']+' [Premium]'
    iNBAmXQcetsguwTxSlMUpRrIzoGLYj.append(iNBAmXQcetsguwTxSlMUpRrIzoGLYV)
   if iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']['has_more']=='Y':iNBAmXQcetsguwTxSlMUpRrIzoGLYP=iNBAmXQcetsguwTxSlMUpRrIzoGLyj
  except iNBAmXQcetsguwTxSlMUpRrIzoGLyY as exception:
   iNBAmXQcetsguwTxSlMUpRrIzoGLyP(exception)
  return iNBAmXQcetsguwTxSlMUpRrIzoGLYj,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
 def GetMovieListGenre(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,genre,page_int,premiumyn=iNBAmXQcetsguwTxSlMUpRrIzoGLPk):
  iNBAmXQcetsguwTxSlMUpRrIzoGLYj=[]
  iNBAmXQcetsguwTxSlMUpRrIzoGLYP=iNBAmXQcetsguwTxSlMUpRrIzoGLPk
  if premiumyn==iNBAmXQcetsguwTxSlMUpRrIzoGLyj:
   iNBAmXQcetsguwTxSlMUpRrIzoGLPO=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.MOVIE_LITE+','+iNBAmXQcetsguwTxSlMUpRrIzoGLHy.MOVIE_PREMIUM
  else:
   iNBAmXQcetsguwTxSlMUpRrIzoGLPO=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.MOVIE_LITE
  try:
   iNBAmXQcetsguwTxSlMUpRrIzoGLjD ='/v2/media/movie/curation/'+genre
   iNBAmXQcetsguwTxSlMUpRrIzoGLjf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetDefaultParams()
   iNBAmXQcetsguwTxSlMUpRrIzoGLjn={'pageNo':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(page_int),'pageSize':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.MOVIE_LIMIT),'productPackageCode':iNBAmXQcetsguwTxSlMUpRrIzoGLPO,'_':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetNoCache(2))}
   iNBAmXQcetsguwTxSlMUpRrIzoGLjf.update(iNBAmXQcetsguwTxSlMUpRrIzoGLjn)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHa=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeurl(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.API_DOMAIN,iNBAmXQcetsguwTxSlMUpRrIzoGLjD)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeDefaultCookies()
   iNBAmXQcetsguwTxSlMUpRrIzoGLHW=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.callRequestCookies('Get',iNBAmXQcetsguwTxSlMUpRrIzoGLHa,payload=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,params=iNBAmXQcetsguwTxSlMUpRrIzoGLjf,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,cookies=iNBAmXQcetsguwTxSlMUpRrIzoGLHf)
   iNBAmXQcetsguwTxSlMUpRrIzoGLjO=json.loads(iNBAmXQcetsguwTxSlMUpRrIzoGLHW.text)
   if not('movies' in iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']):return iNBAmXQcetsguwTxSlMUpRrIzoGLYj,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
   iNBAmXQcetsguwTxSlMUpRrIzoGLYd=iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']['movies']
   for iNBAmXQcetsguwTxSlMUpRrIzoGLja in iNBAmXQcetsguwTxSlMUpRrIzoGLYd:
    iNBAmXQcetsguwTxSlMUpRrIzoGLPJ =iNBAmXQcetsguwTxSlMUpRrIzoGLja['code']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYJ =iNBAmXQcetsguwTxSlMUpRrIzoGLja['name']['ko']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYK =iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLja['image'][0]['url']
    for iNBAmXQcetsguwTxSlMUpRrIzoGLYF in iNBAmXQcetsguwTxSlMUpRrIzoGLja['image']:
     if iNBAmXQcetsguwTxSlMUpRrIzoGLYF['code']=='CAIM2100':
      iNBAmXQcetsguwTxSlMUpRrIzoGLYK =iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLYF['url']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYb =iNBAmXQcetsguwTxSlMUpRrIzoGLja['story']['ko']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYV={'moviecode':iNBAmXQcetsguwTxSlMUpRrIzoGLPJ,'title':iNBAmXQcetsguwTxSlMUpRrIzoGLYJ.strip(),'thumbnail':iNBAmXQcetsguwTxSlMUpRrIzoGLYK,'synopsis':iNBAmXQcetsguwTxSlMUpRrIzoGLYb}
    if premiumyn==iNBAmXQcetsguwTxSlMUpRrIzoGLyj:
     iNBAmXQcetsguwTxSlMUpRrIzoGLPK=iNBAmXQcetsguwTxSlMUpRrIzoGLPk
     for iNBAmXQcetsguwTxSlMUpRrIzoGLPb in iNBAmXQcetsguwTxSlMUpRrIzoGLja['billing_package_id']:
      if iNBAmXQcetsguwTxSlMUpRrIzoGLPb==iNBAmXQcetsguwTxSlMUpRrIzoGLHy.MOVIE_LITE:
       iNBAmXQcetsguwTxSlMUpRrIzoGLPK=iNBAmXQcetsguwTxSlMUpRrIzoGLyj
       break
     if iNBAmXQcetsguwTxSlMUpRrIzoGLPK==iNBAmXQcetsguwTxSlMUpRrIzoGLPk:
      iNBAmXQcetsguwTxSlMUpRrIzoGLYV['title']=iNBAmXQcetsguwTxSlMUpRrIzoGLYV['title']+' [Premium]'
    iNBAmXQcetsguwTxSlMUpRrIzoGLYj.append(iNBAmXQcetsguwTxSlMUpRrIzoGLYV)
  except iNBAmXQcetsguwTxSlMUpRrIzoGLyY as exception:
   iNBAmXQcetsguwTxSlMUpRrIzoGLyP(exception)
  return iNBAmXQcetsguwTxSlMUpRrIzoGLYj,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
 def GetMovieGenre(iNBAmXQcetsguwTxSlMUpRrIzoGLHy):
  iNBAmXQcetsguwTxSlMUpRrIzoGLYj=[]
  iNBAmXQcetsguwTxSlMUpRrIzoGLYP=iNBAmXQcetsguwTxSlMUpRrIzoGLPk
  try:
   iNBAmXQcetsguwTxSlMUpRrIzoGLjD ='/v2/media/movie/curations'
   iNBAmXQcetsguwTxSlMUpRrIzoGLjf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetDefaultParams()
   iNBAmXQcetsguwTxSlMUpRrIzoGLjn={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetNoCache(2))}
   iNBAmXQcetsguwTxSlMUpRrIzoGLjf.update(iNBAmXQcetsguwTxSlMUpRrIzoGLjn)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHa=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeurl(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.API_DOMAIN,iNBAmXQcetsguwTxSlMUpRrIzoGLjD)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeDefaultCookies()
   iNBAmXQcetsguwTxSlMUpRrIzoGLHW=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.callRequestCookies('Get',iNBAmXQcetsguwTxSlMUpRrIzoGLHa,payload=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,params=iNBAmXQcetsguwTxSlMUpRrIzoGLjf,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,cookies=iNBAmXQcetsguwTxSlMUpRrIzoGLHf)
   iNBAmXQcetsguwTxSlMUpRrIzoGLjO=json.loads(iNBAmXQcetsguwTxSlMUpRrIzoGLHW.text)
   if not('result' in iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']):return iNBAmXQcetsguwTxSlMUpRrIzoGLYj,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
   iNBAmXQcetsguwTxSlMUpRrIzoGLYd=iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']['result']
   for iNBAmXQcetsguwTxSlMUpRrIzoGLja in iNBAmXQcetsguwTxSlMUpRrIzoGLYd:
    iNBAmXQcetsguwTxSlMUpRrIzoGLPa =iNBAmXQcetsguwTxSlMUpRrIzoGLja['curation_code']
    iNBAmXQcetsguwTxSlMUpRrIzoGLPq =iNBAmXQcetsguwTxSlMUpRrIzoGLja['curation_name']
    iNBAmXQcetsguwTxSlMUpRrIzoGLYV={'curation_code':iNBAmXQcetsguwTxSlMUpRrIzoGLPa,'curation_name':iNBAmXQcetsguwTxSlMUpRrIzoGLPq}
    iNBAmXQcetsguwTxSlMUpRrIzoGLYj.append(iNBAmXQcetsguwTxSlMUpRrIzoGLYV)
  except iNBAmXQcetsguwTxSlMUpRrIzoGLyY as exception:
   iNBAmXQcetsguwTxSlMUpRrIzoGLyP(exception)
  return iNBAmXQcetsguwTxSlMUpRrIzoGLYj,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
 def GetSearchList(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,search_key,userid,page_int,stype,premiumyn=iNBAmXQcetsguwTxSlMUpRrIzoGLPk,landyn=iNBAmXQcetsguwTxSlMUpRrIzoGLPk):
  iNBAmXQcetsguwTxSlMUpRrIzoGLPv=[]
  iNBAmXQcetsguwTxSlMUpRrIzoGLYP=iNBAmXQcetsguwTxSlMUpRrIzoGLPk
  try:
   iNBAmXQcetsguwTxSlMUpRrIzoGLjD ='/search/getSearch.jsp'
   iNBAmXQcetsguwTxSlMUpRrIzoGLjn={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'TOTAL','pageNum':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(page_int),'pageSize':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':iNBAmXQcetsguwTxSlMUpRrIzoGLHy.SCREENCODE,'os':iNBAmXQcetsguwTxSlMUpRrIzoGLHy.OSCODE,'network':iNBAmXQcetsguwTxSlMUpRrIzoGLHy.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.SEARCH_LIMIT),'vodMVReqCnt':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':iNBAmXQcetsguwTxSlMUpRrIzoGLyd(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.GetNoCache(2))}
   iNBAmXQcetsguwTxSlMUpRrIzoGLHa=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeurl(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.SEARCH_DOMAIN,iNBAmXQcetsguwTxSlMUpRrIzoGLjD)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeDefaultCookies()
   iNBAmXQcetsguwTxSlMUpRrIzoGLHW=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.callRequestCookies('Get',iNBAmXQcetsguwTxSlMUpRrIzoGLHa,payload=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,params=iNBAmXQcetsguwTxSlMUpRrIzoGLjn,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,cookies=iNBAmXQcetsguwTxSlMUpRrIzoGLHf)
   iNBAmXQcetsguwTxSlMUpRrIzoGLjO=json.loads(iNBAmXQcetsguwTxSlMUpRrIzoGLHW.text)
   if stype=='vod':
    if not('programRsb' in iNBAmXQcetsguwTxSlMUpRrIzoGLjO):return iNBAmXQcetsguwTxSlMUpRrIzoGLPv,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
    iNBAmXQcetsguwTxSlMUpRrIzoGLPE=iNBAmXQcetsguwTxSlMUpRrIzoGLjO['programRsb']['dataList']
    iNBAmXQcetsguwTxSlMUpRrIzoGLPV =iNBAmXQcetsguwTxSlMUpRrIzoGLyH(iNBAmXQcetsguwTxSlMUpRrIzoGLjO['programRsb']['count'])
    for iNBAmXQcetsguwTxSlMUpRrIzoGLja in iNBAmXQcetsguwTxSlMUpRrIzoGLPE:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYC=iNBAmXQcetsguwTxSlMUpRrIzoGLja['mast_cd']
     iNBAmXQcetsguwTxSlMUpRrIzoGLYJ =iNBAmXQcetsguwTxSlMUpRrIzoGLja['mast_nm']
     iNBAmXQcetsguwTxSlMUpRrIzoGLYK =iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLja['web_url']
     if landyn==iNBAmXQcetsguwTxSlMUpRrIzoGLPk:
      iNBAmXQcetsguwTxSlMUpRrIzoGLYK =iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLja['web_url4']
     iNBAmXQcetsguwTxSlMUpRrIzoGLYD={}
     iNBAmXQcetsguwTxSlMUpRrIzoGLYD['title']=iNBAmXQcetsguwTxSlMUpRrIzoGLja['mast_nm']
     iNBAmXQcetsguwTxSlMUpRrIzoGLYD['mediatype']='episode' 
     try:
      if iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('actor')!='' and iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('actor')!='-':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['cast'] =iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('actor').split(',')
      if iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('director')!='' and iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('director')!='-':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['director']=iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('director').split(',')
      if iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('cate_nm')!='':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['genre'] =iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('cate_nm').split('/')
      if 'targetage' in iNBAmXQcetsguwTxSlMUpRrIzoGLja:iNBAmXQcetsguwTxSlMUpRrIzoGLYD['mpaa']=iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('targetage')
     except:
      iNBAmXQcetsguwTxSlMUpRrIzoGLPW
     try:
      if 'broad_dt' in iNBAmXQcetsguwTxSlMUpRrIzoGLja:
       iNBAmXQcetsguwTxSlMUpRrIzoGLPj=iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('broad_dt')
       iNBAmXQcetsguwTxSlMUpRrIzoGLYD['aired']='%s-%s-%s'%(iNBAmXQcetsguwTxSlMUpRrIzoGLPj[:4],iNBAmXQcetsguwTxSlMUpRrIzoGLPj[4:6],iNBAmXQcetsguwTxSlMUpRrIzoGLPj[6:])
     except:
      iNBAmXQcetsguwTxSlMUpRrIzoGLPW
     iNBAmXQcetsguwTxSlMUpRrIzoGLYV={'program':iNBAmXQcetsguwTxSlMUpRrIzoGLYC,'title':iNBAmXQcetsguwTxSlMUpRrIzoGLYJ,'thumbnail':iNBAmXQcetsguwTxSlMUpRrIzoGLYK,'synopsis':'','info':iNBAmXQcetsguwTxSlMUpRrIzoGLYD}
     iNBAmXQcetsguwTxSlMUpRrIzoGLPv.append(iNBAmXQcetsguwTxSlMUpRrIzoGLYV)
   else:
    if not('vodMVRsb' in iNBAmXQcetsguwTxSlMUpRrIzoGLjO):return iNBAmXQcetsguwTxSlMUpRrIzoGLPv,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
    iNBAmXQcetsguwTxSlMUpRrIzoGLPC=iNBAmXQcetsguwTxSlMUpRrIzoGLjO['vodMVRsb']['dataList']
    iNBAmXQcetsguwTxSlMUpRrIzoGLPV =iNBAmXQcetsguwTxSlMUpRrIzoGLyH(iNBAmXQcetsguwTxSlMUpRrIzoGLjO['vodMVRsb']['count'])
    for iNBAmXQcetsguwTxSlMUpRrIzoGLja in iNBAmXQcetsguwTxSlMUpRrIzoGLPC:
     iNBAmXQcetsguwTxSlMUpRrIzoGLYC=iNBAmXQcetsguwTxSlMUpRrIzoGLja['mast_cd']
     iNBAmXQcetsguwTxSlMUpRrIzoGLYJ =iNBAmXQcetsguwTxSlMUpRrIzoGLja['mast_nm'].strip()
     iNBAmXQcetsguwTxSlMUpRrIzoGLYK =iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLja['web_url']
     if landyn==iNBAmXQcetsguwTxSlMUpRrIzoGLPk:
      iNBAmXQcetsguwTxSlMUpRrIzoGLYK =iNBAmXQcetsguwTxSlMUpRrIzoGLHy.IMG_DOMAIN+iNBAmXQcetsguwTxSlMUpRrIzoGLja['web_url5']
     iNBAmXQcetsguwTxSlMUpRrIzoGLYD={}
     iNBAmXQcetsguwTxSlMUpRrIzoGLYD['title'] =iNBAmXQcetsguwTxSlMUpRrIzoGLYJ
     iNBAmXQcetsguwTxSlMUpRrIzoGLYD['mediatype']='movie' 
     try:
      if iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('actor') !='':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['cast'] =iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('actor').split(',')
      if iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('cate_nm')!='':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['genre'] =iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('cate_nm').split('/')
      if iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('runtime_sec')!='':iNBAmXQcetsguwTxSlMUpRrIzoGLYD['duration']=iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('runtime_sec')
      if 'grade_nm' in iNBAmXQcetsguwTxSlMUpRrIzoGLja:iNBAmXQcetsguwTxSlMUpRrIzoGLYD['mpaa']=iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('grade_nm')
     except:
      iNBAmXQcetsguwTxSlMUpRrIzoGLPW
     try:
      iNBAmXQcetsguwTxSlMUpRrIzoGLPj=iNBAmXQcetsguwTxSlMUpRrIzoGLja.get('broad_dt')
      if data_str!='':
       iNBAmXQcetsguwTxSlMUpRrIzoGLYD['aired']='%s-%s-%s'%(iNBAmXQcetsguwTxSlMUpRrIzoGLPj[:4],iNBAmXQcetsguwTxSlMUpRrIzoGLPj[4:6],iNBAmXQcetsguwTxSlMUpRrIzoGLPj[6:])
       iNBAmXQcetsguwTxSlMUpRrIzoGLYD['year']=iNBAmXQcetsguwTxSlMUpRrIzoGLPj[:4]
     except:
      iNBAmXQcetsguwTxSlMUpRrIzoGLPW
     if iNBAmXQcetsguwTxSlMUpRrIzoGLyj:
      iNBAmXQcetsguwTxSlMUpRrIzoGLYV={'movie':iNBAmXQcetsguwTxSlMUpRrIzoGLYC,'title':iNBAmXQcetsguwTxSlMUpRrIzoGLYJ,'thumbnail':iNBAmXQcetsguwTxSlMUpRrIzoGLYK,'synopsis':'','info':iNBAmXQcetsguwTxSlMUpRrIzoGLYD}
      iNBAmXQcetsguwTxSlMUpRrIzoGLPv.append(iNBAmXQcetsguwTxSlMUpRrIzoGLYV)
  except iNBAmXQcetsguwTxSlMUpRrIzoGLyY as exception:
   iNBAmXQcetsguwTxSlMUpRrIzoGLyP(exception)
  return iNBAmXQcetsguwTxSlMUpRrIzoGLPv,iNBAmXQcetsguwTxSlMUpRrIzoGLYP
 def GetDeviceList(iNBAmXQcetsguwTxSlMUpRrIzoGLHy,iNBAmXQcetsguwTxSlMUpRrIzoGLHV,iNBAmXQcetsguwTxSlMUpRrIzoGLjH):
  iNBAmXQcetsguwTxSlMUpRrIzoGLYj=[]
  iNBAmXQcetsguwTxSlMUpRrIzoGLjd='-'
  try:
   iNBAmXQcetsguwTxSlMUpRrIzoGLjD ='/v1/user/device/list'
   iNBAmXQcetsguwTxSlMUpRrIzoGLPh=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeurl(iNBAmXQcetsguwTxSlMUpRrIzoGLHy.API_DOMAIN,iNBAmXQcetsguwTxSlMUpRrIzoGLjD)
   iNBAmXQcetsguwTxSlMUpRrIzoGLjn={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   iNBAmXQcetsguwTxSlMUpRrIzoGLHf=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.makeDefaultCookies(vToken=iNBAmXQcetsguwTxSlMUpRrIzoGLHV,vUserinfo=iNBAmXQcetsguwTxSlMUpRrIzoGLjH)
   iNBAmXQcetsguwTxSlMUpRrIzoGLHW=iNBAmXQcetsguwTxSlMUpRrIzoGLHy.callRequestCookies('Get',iNBAmXQcetsguwTxSlMUpRrIzoGLPh,payload=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,params=iNBAmXQcetsguwTxSlMUpRrIzoGLjn,headers=iNBAmXQcetsguwTxSlMUpRrIzoGLPW,cookies=iNBAmXQcetsguwTxSlMUpRrIzoGLHf)
   iNBAmXQcetsguwTxSlMUpRrIzoGLjO=json.loads(iNBAmXQcetsguwTxSlMUpRrIzoGLHW.text)
   iNBAmXQcetsguwTxSlMUpRrIzoGLYj=iNBAmXQcetsguwTxSlMUpRrIzoGLjO['body']
   for iNBAmXQcetsguwTxSlMUpRrIzoGLja in iNBAmXQcetsguwTxSlMUpRrIzoGLYj:
    if iNBAmXQcetsguwTxSlMUpRrIzoGLja['model']=='PC':
     iNBAmXQcetsguwTxSlMUpRrIzoGLjd=iNBAmXQcetsguwTxSlMUpRrIzoGLja['uuid']
  except iNBAmXQcetsguwTxSlMUpRrIzoGLyY as exception:
   iNBAmXQcetsguwTxSlMUpRrIzoGLyP(exception)
  return iNBAmXQcetsguwTxSlMUpRrIzoGLjd
# Created by pyminifier (https://github.com/liftoff/pyminifier)
