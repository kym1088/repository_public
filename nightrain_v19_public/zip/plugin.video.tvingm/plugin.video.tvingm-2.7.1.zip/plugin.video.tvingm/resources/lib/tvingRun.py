__author__="NightRain"
TDyGQtFLmhgvqsWeIEOazjdKJwuxol=object
TDyGQtFLmhgvqsWeIEOazjdKJwuxoY=None
TDyGQtFLmhgvqsWeIEOazjdKJwuxoP=int
TDyGQtFLmhgvqsWeIEOazjdKJwuxon=True
TDyGQtFLmhgvqsWeIEOazjdKJwuxoS=False
TDyGQtFLmhgvqsWeIEOazjdKJwuxoR=type
TDyGQtFLmhgvqsWeIEOazjdKJwuxoA=dict
TDyGQtFLmhgvqsWeIEOazjdKJwuxoU=getattr
TDyGQtFLmhgvqsWeIEOazjdKJwuxor=list
TDyGQtFLmhgvqsWeIEOazjdKJwuxoB=len
TDyGQtFLmhgvqsWeIEOazjdKJwuxoc=str
TDyGQtFLmhgvqsWeIEOazjdKJwuxob=range
TDyGQtFLmhgvqsWeIEOazjdKJwuxof=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
TDyGQtFLmhgvqsWeIEOazjdKJwuxVp=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'Apple TV+','mode':'APPLE_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
TDyGQtFLmhgvqsWeIEOazjdKJwuxVl=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
TDyGQtFLmhgvqsWeIEOazjdKJwuxVY=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
TDyGQtFLmhgvqsWeIEOazjdKJwuxVP=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
TDyGQtFLmhgvqsWeIEOazjdKJwuxVn=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
TDyGQtFLmhgvqsWeIEOazjdKJwuxVS=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
TDyGQtFLmhgvqsWeIEOazjdKJwuxVo=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
TDyGQtFLmhgvqsWeIEOazjdKJwuxVR={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
TDyGQtFLmhgvqsWeIEOazjdKJwuxVA =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
TDyGQtFLmhgvqsWeIEOazjdKJwuxVU=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class TDyGQtFLmhgvqsWeIEOazjdKJwuxVN(TDyGQtFLmhgvqsWeIEOazjdKJwuxol):
 def __init__(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxVB,TDyGQtFLmhgvqsWeIEOazjdKJwuxVc,TDyGQtFLmhgvqsWeIEOazjdKJwuxVb):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_url =TDyGQtFLmhgvqsWeIEOazjdKJwuxVB
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle=TDyGQtFLmhgvqsWeIEOazjdKJwuxVc
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params =TDyGQtFLmhgvqsWeIEOazjdKJwuxVb
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj =GIvuqfgHAhaMrKxWJteSzPRCBQiVnb() 
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,sting):
  try:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVi=xbmcgui.Dialog()
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVi.notification(__addonname__,sting)
  except:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
 def addon_log(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,string):
  try:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVX=string.encode('utf-8','ignore')
  except:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVX='addonException: addon_log'
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVM=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,TDyGQtFLmhgvqsWeIEOazjdKJwuxVX),level=TDyGQtFLmhgvqsWeIEOazjdKJwuxVM)
 def get_keyboard_input(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxNb):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVk=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
  kb=xbmc.Keyboard()
  kb.setHeading(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVk=kb.getText()
  return TDyGQtFLmhgvqsWeIEOazjdKJwuxVk
 def get_settings_account(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVC =__addon__.getSetting('id')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVH =__addon__.getSetting('pw')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNV =__addon__.getSetting('login_type')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNp=TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(__addon__.getSetting('selected_profile'))
  return(TDyGQtFLmhgvqsWeIEOazjdKJwuxVC,TDyGQtFLmhgvqsWeIEOazjdKJwuxVH,TDyGQtFLmhgvqsWeIEOazjdKJwuxNV,TDyGQtFLmhgvqsWeIEOazjdKJwuxNp)
 def get_settings_uhd(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  return TDyGQtFLmhgvqsWeIEOazjdKJwuxon if __addon__.getSetting('active_uhd')=='true' else TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
 def get_settings_playback(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNl={'active_uhd':TDyGQtFLmhgvqsWeIEOazjdKJwuxon if __addon__.getSetting('active_uhd')=='true' else TDyGQtFLmhgvqsWeIEOazjdKJwuxoS,'streamFilename':TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.TV_STREAM_FILENAME,}
  return TDyGQtFLmhgvqsWeIEOazjdKJwuxNl
 def get_settings_proxyport(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNY =TDyGQtFLmhgvqsWeIEOazjdKJwuxon if __addon__.getSetting('proxyYn')=='true' else TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNP=TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(__addon__.getSetting('proxyPort'))
  return TDyGQtFLmhgvqsWeIEOazjdKJwuxNY,TDyGQtFLmhgvqsWeIEOazjdKJwuxNP
 def get_settings_totalsearch(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNn =TDyGQtFLmhgvqsWeIEOazjdKJwuxon if __addon__.getSetting('local_search')=='true' else TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNS=TDyGQtFLmhgvqsWeIEOazjdKJwuxon if __addon__.getSetting('local_history')=='true' else TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNo =TDyGQtFLmhgvqsWeIEOazjdKJwuxon if __addon__.getSetting('total_search')=='true' else TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNR=TDyGQtFLmhgvqsWeIEOazjdKJwuxon if __addon__.getSetting('total_history')=='true' else TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNA=TDyGQtFLmhgvqsWeIEOazjdKJwuxon if __addon__.getSetting('menu_bookmark')=='true' else TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
  return(TDyGQtFLmhgvqsWeIEOazjdKJwuxNn,TDyGQtFLmhgvqsWeIEOazjdKJwuxNS,TDyGQtFLmhgvqsWeIEOazjdKJwuxNo,TDyGQtFLmhgvqsWeIEOazjdKJwuxNR,TDyGQtFLmhgvqsWeIEOazjdKJwuxNA)
 def get_settings_makebookmark(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  return TDyGQtFLmhgvqsWeIEOazjdKJwuxon if __addon__.getSetting('make_bookmark')=='true' else TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
 def get_settings_direct_replay(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNU=TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(__addon__.getSetting('direct_replay'))
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxNU==0:
   return TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
  else:
   return TDyGQtFLmhgvqsWeIEOazjdKJwuxon
 def set_winEpisodeOrderby(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxNB):
  __addon__.setSetting('tving_orderby',TDyGQtFLmhgvqsWeIEOazjdKJwuxNB)
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNr=xbmcgui.Window(10000)
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNr.setProperty('TVING_M_ORDERBY',TDyGQtFLmhgvqsWeIEOazjdKJwuxNB)
 def get_winEpisodeOrderby(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNB=__addon__.getSetting('tving_orderby')
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxNB in['',TDyGQtFLmhgvqsWeIEOazjdKJwuxoY]:TDyGQtFLmhgvqsWeIEOazjdKJwuxNB='desc'
  return TDyGQtFLmhgvqsWeIEOazjdKJwuxNB
 def add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,label,sublabel='',img='',infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params='',isLink=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS,ContextMenu=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNc='%s?%s'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_url,urllib.parse.urlencode(params))
  if sublabel:TDyGQtFLmhgvqsWeIEOazjdKJwuxNb='%s < %s >'%(label,sublabel)
  else: TDyGQtFLmhgvqsWeIEOazjdKJwuxNb=label
  if not img:img='DefaultFolder.png'
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNf=xbmcgui.ListItem(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxoR(img)==TDyGQtFLmhgvqsWeIEOazjdKJwuxoA:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNf.setArt(img)
  else:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNf.setArt({'thumb':img,'poster':img})
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.KodiVersion>=20:
   if infoLabels:TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.Set_InfoTag(TDyGQtFLmhgvqsWeIEOazjdKJwuxNf.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:TDyGQtFLmhgvqsWeIEOazjdKJwuxNf.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNf.setProperty('IsPlayable','true')
  if ContextMenu:TDyGQtFLmhgvqsWeIEOazjdKJwuxNf.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,TDyGQtFLmhgvqsWeIEOazjdKJwuxNc,TDyGQtFLmhgvqsWeIEOazjdKJwuxNf,isFolder)
 def get_selQuality(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,etype):
  try:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNi='selected_quality'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNX=[1080,720,480,360]
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNM=TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(__addon__.getSetting(TDyGQtFLmhgvqsWeIEOazjdKJwuxNi))
   return TDyGQtFLmhgvqsWeIEOazjdKJwuxNX[TDyGQtFLmhgvqsWeIEOazjdKJwuxNM]
  except:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
  return 720 
 def Set_InfoTag(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,video_InfoTag:xbmc.InfoTagVideo,TDyGQtFLmhgvqsWeIEOazjdKJwuxpP):
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxNk,value in TDyGQtFLmhgvqsWeIEOazjdKJwuxpP.items():
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxVR[TDyGQtFLmhgvqsWeIEOazjdKJwuxNk]['type']=='string':
    TDyGQtFLmhgvqsWeIEOazjdKJwuxoU(video_InfoTag,TDyGQtFLmhgvqsWeIEOazjdKJwuxVR[TDyGQtFLmhgvqsWeIEOazjdKJwuxNk]['func'])(value)
   elif TDyGQtFLmhgvqsWeIEOazjdKJwuxVR[TDyGQtFLmhgvqsWeIEOazjdKJwuxNk]['type']=='int':
    if TDyGQtFLmhgvqsWeIEOazjdKJwuxoR(value)==TDyGQtFLmhgvqsWeIEOazjdKJwuxoP:
     TDyGQtFLmhgvqsWeIEOazjdKJwuxNC=TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(value)
    else:
     TDyGQtFLmhgvqsWeIEOazjdKJwuxNC=0
    TDyGQtFLmhgvqsWeIEOazjdKJwuxoU(video_InfoTag,TDyGQtFLmhgvqsWeIEOazjdKJwuxVR[TDyGQtFLmhgvqsWeIEOazjdKJwuxNk]['func'])(TDyGQtFLmhgvqsWeIEOazjdKJwuxNC)
   elif TDyGQtFLmhgvqsWeIEOazjdKJwuxVR[TDyGQtFLmhgvqsWeIEOazjdKJwuxNk]['type']=='actor':
    if value!=[]:
     TDyGQtFLmhgvqsWeIEOazjdKJwuxoU(video_InfoTag,TDyGQtFLmhgvqsWeIEOazjdKJwuxVR[TDyGQtFLmhgvqsWeIEOazjdKJwuxNk]['func'])([xbmc.Actor(name)for name in value])
   elif TDyGQtFLmhgvqsWeIEOazjdKJwuxVR[TDyGQtFLmhgvqsWeIEOazjdKJwuxNk]['type']=='list':
    if TDyGQtFLmhgvqsWeIEOazjdKJwuxoR(value)==TDyGQtFLmhgvqsWeIEOazjdKJwuxor:
     TDyGQtFLmhgvqsWeIEOazjdKJwuxoU(video_InfoTag,TDyGQtFLmhgvqsWeIEOazjdKJwuxVR[TDyGQtFLmhgvqsWeIEOazjdKJwuxNk]['func'])(value)
    else:
     TDyGQtFLmhgvqsWeIEOazjdKJwuxoU(video_InfoTag,TDyGQtFLmhgvqsWeIEOazjdKJwuxVR[TDyGQtFLmhgvqsWeIEOazjdKJwuxNk]['func'])([value])
 def dp_Main_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  (TDyGQtFLmhgvqsWeIEOazjdKJwuxNn,TDyGQtFLmhgvqsWeIEOazjdKJwuxNS,TDyGQtFLmhgvqsWeIEOazjdKJwuxNo,TDyGQtFLmhgvqsWeIEOazjdKJwuxNR,TDyGQtFLmhgvqsWeIEOazjdKJwuxNA)=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_totalsearch()
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxNH in TDyGQtFLmhgvqsWeIEOazjdKJwuxVp:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb=TDyGQtFLmhgvqsWeIEOazjdKJwuxNH.get('title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpV=''
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxNH.get('mode')=='SEARCH_GROUP' and TDyGQtFLmhgvqsWeIEOazjdKJwuxNn ==TDyGQtFLmhgvqsWeIEOazjdKJwuxoS:continue
   elif TDyGQtFLmhgvqsWeIEOazjdKJwuxNH.get('mode')=='SEARCH_HISTORY' and TDyGQtFLmhgvqsWeIEOazjdKJwuxNS==TDyGQtFLmhgvqsWeIEOazjdKJwuxoS:continue
   elif TDyGQtFLmhgvqsWeIEOazjdKJwuxNH.get('mode')=='TOTAL_SEARCH' and TDyGQtFLmhgvqsWeIEOazjdKJwuxNo ==TDyGQtFLmhgvqsWeIEOazjdKJwuxoS:continue
   elif TDyGQtFLmhgvqsWeIEOazjdKJwuxNH.get('mode')=='TOTAL_HISTORY' and TDyGQtFLmhgvqsWeIEOazjdKJwuxNR==TDyGQtFLmhgvqsWeIEOazjdKJwuxoS:continue
   elif TDyGQtFLmhgvqsWeIEOazjdKJwuxNH.get('mode')=='MENU_BOOKMARK' and TDyGQtFLmhgvqsWeIEOazjdKJwuxNA==TDyGQtFLmhgvqsWeIEOazjdKJwuxoS:continue
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':TDyGQtFLmhgvqsWeIEOazjdKJwuxNH.get('mode'),'stype':TDyGQtFLmhgvqsWeIEOazjdKJwuxNH.get('stype'),'orderby':TDyGQtFLmhgvqsWeIEOazjdKJwuxNH.get('orderby'),'ordernm':TDyGQtFLmhgvqsWeIEOazjdKJwuxNH.get('ordernm'),'page':'1'}
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxNH.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpl=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpY =TDyGQtFLmhgvqsWeIEOazjdKJwuxon
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpl=TDyGQtFLmhgvqsWeIEOazjdKJwuxon
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpY =TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpP={'title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'plot':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb}
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxNH.get('mode')=='XXX':TDyGQtFLmhgvqsWeIEOazjdKJwuxpP=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
   if 'icon' in TDyGQtFLmhgvqsWeIEOazjdKJwuxNH:TDyGQtFLmhgvqsWeIEOazjdKJwuxpV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',TDyGQtFLmhgvqsWeIEOazjdKJwuxNH.get('icon')) 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel='',img=TDyGQtFLmhgvqsWeIEOazjdKJwuxpV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxpP,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxpl,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN,isLink=TDyGQtFLmhgvqsWeIEOazjdKJwuxpY)
  xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle)
 def login_main(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  (TDyGQtFLmhgvqsWeIEOazjdKJwuxpS,TDyGQtFLmhgvqsWeIEOazjdKJwuxpo,TDyGQtFLmhgvqsWeIEOazjdKJwuxpR,TDyGQtFLmhgvqsWeIEOazjdKJwuxpA)=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_account()
  if not(TDyGQtFLmhgvqsWeIEOazjdKJwuxpS and TDyGQtFLmhgvqsWeIEOazjdKJwuxpo):
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVi=xbmcgui.Dialog()
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpU=TDyGQtFLmhgvqsWeIEOazjdKJwuxVi.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxpU==TDyGQtFLmhgvqsWeIEOazjdKJwuxon:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.cookiefile_check():return
  if base64.standard_b64encode(TDyGQtFLmhgvqsWeIEOazjdKJwuxpS.encode()).decode('utf-8')=='a3ltOTUxMDg4':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpr=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.GetCredential2(TDyGQtFLmhgvqsWeIEOazjdKJwuxpS,TDyGQtFLmhgvqsWeIEOazjdKJwuxpo,TDyGQtFLmhgvqsWeIEOazjdKJwuxpR,TDyGQtFLmhgvqsWeIEOazjdKJwuxpA)
  else:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVi=xbmcgui.Dialog()
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpB=TDyGQtFLmhgvqsWeIEOazjdKJwuxVi.browse(1,__language__(30917).encode('utf8'),'','.twc',TDyGQtFLmhgvqsWeIEOazjdKJwuxoS,TDyGQtFLmhgvqsWeIEOazjdKJwuxoS,'',TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxpB!='':
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpc=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'))
    xbmcvfs.copy(TDyGQtFLmhgvqsWeIEOazjdKJwuxpB,TDyGQtFLmhgvqsWeIEOazjdKJwuxpc)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpr=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.WebCookies_Load(TDyGQtFLmhgvqsWeIEOazjdKJwuxpc)
    xbmcvfs.delete(TDyGQtFLmhgvqsWeIEOazjdKJwuxpc)
    if TDyGQtFLmhgvqsWeIEOazjdKJwuxpr:
     TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.JsonFile_Save(TDyGQtFLmhgvqsWeIEOazjdKJwuxVA,TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.TV)
     TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpr=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpr==TDyGQtFLmhgvqsWeIEOazjdKJwuxon:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.cookiefile_save()
  else:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpb=TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('stype')
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpb=='live':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpf=TDyGQtFLmhgvqsWeIEOazjdKJwuxVl
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxpb=='vod':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpf=TDyGQtFLmhgvqsWeIEOazjdKJwuxVn
  else:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpf=TDyGQtFLmhgvqsWeIEOazjdKJwuxVS
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxpi in TDyGQtFLmhgvqsWeIEOazjdKJwuxpf:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb=TDyGQtFLmhgvqsWeIEOazjdKJwuxpi.get('title')
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('ordernm')!='-':
    TDyGQtFLmhgvqsWeIEOazjdKJwuxNb+='  ('+TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('ordernm')+')'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':TDyGQtFLmhgvqsWeIEOazjdKJwuxpi.get('mode'),'stype':TDyGQtFLmhgvqsWeIEOazjdKJwuxpi.get('stype'),'orderby':TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('orderby'),'ordernm':TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('ordernm'),'page':'1'}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel='',img='',infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxoB(TDyGQtFLmhgvqsWeIEOazjdKJwuxpf)>0:xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle)
 def dp_SubTitle_Group(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX): 
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxpi in TDyGQtFLmhgvqsWeIEOazjdKJwuxVo:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb=TDyGQtFLmhgvqsWeIEOazjdKJwuxpi.get('title')
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('ordernm')!='-':
    TDyGQtFLmhgvqsWeIEOazjdKJwuxNb+='  ('+TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('ordernm')+')'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':TDyGQtFLmhgvqsWeIEOazjdKJwuxpi.get('mode'),'genreCode':TDyGQtFLmhgvqsWeIEOazjdKJwuxpi.get('genreCode'),'stype':TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('stype'),'orderby':TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('orderby'),'page':'1'}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel='',img='',infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxoB(TDyGQtFLmhgvqsWeIEOazjdKJwuxVo)>0:xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle)
 def dp_LiveChannel_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpb =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('stype')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpM =TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('page'))
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpk,TDyGQtFLmhgvqsWeIEOazjdKJwuxpC=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.GetLiveChannelList(TDyGQtFLmhgvqsWeIEOazjdKJwuxpb,TDyGQtFLmhgvqsWeIEOazjdKJwuxpM)
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxpH in TDyGQtFLmhgvqsWeIEOazjdKJwuxpk:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpn =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('channel')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlV =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('thumbnail')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlN =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('synopsis')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlp =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('channelepg')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlY =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('cast')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlP =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('director')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxln =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('info_genre')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlS =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('year')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlo =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('mpaa')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlR =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('premiered')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'mediatype':'episode','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'studio':TDyGQtFLmhgvqsWeIEOazjdKJwuxpn,'cast':TDyGQtFLmhgvqsWeIEOazjdKJwuxlY,'director':TDyGQtFLmhgvqsWeIEOazjdKJwuxlP,'genre':TDyGQtFLmhgvqsWeIEOazjdKJwuxln,'plot':'%s\n%s\n%s\n\n%s'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxpn,TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,TDyGQtFLmhgvqsWeIEOazjdKJwuxlp,TDyGQtFLmhgvqsWeIEOazjdKJwuxlN),'year':TDyGQtFLmhgvqsWeIEOazjdKJwuxlS,'mpaa':TDyGQtFLmhgvqsWeIEOazjdKJwuxlo,'premiered':TDyGQtFLmhgvqsWeIEOazjdKJwuxlR}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'LIVE','mediacode':TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('mediacode'),'stype':TDyGQtFLmhgvqsWeIEOazjdKJwuxpb}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxpn,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxlV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpC:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['mode']='CHANNEL' 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['stype']=TDyGQtFLmhgvqsWeIEOazjdKJwuxpb 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['page']=TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb='[B]%s >>[/B]'%'다음 페이지'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlU=TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxlU,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxpV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxoB(TDyGQtFLmhgvqsWeIEOazjdKJwuxpk)>0:xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
 def dp_Program_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxlr =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('stype')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNB =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('orderby')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpM =TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('page'))
  TDyGQtFLmhgvqsWeIEOazjdKJwuxlB=TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('genreCode')
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxlB==TDyGQtFLmhgvqsWeIEOazjdKJwuxoY:TDyGQtFLmhgvqsWeIEOazjdKJwuxlB='all'
  TDyGQtFLmhgvqsWeIEOazjdKJwuxlc,TDyGQtFLmhgvqsWeIEOazjdKJwuxpC=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.GetProgramList(TDyGQtFLmhgvqsWeIEOazjdKJwuxlr,TDyGQtFLmhgvqsWeIEOazjdKJwuxNB,TDyGQtFLmhgvqsWeIEOazjdKJwuxpM,TDyGQtFLmhgvqsWeIEOazjdKJwuxlB)
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxlb in TDyGQtFLmhgvqsWeIEOazjdKJwuxlc:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlV =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('thumbnail')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlN =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('synopsis')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlf =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('channel')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlY =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('cast')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlP =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('director')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxln=TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('info_genre')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlS =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('year')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlR =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('premiered')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlo =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('mpaa')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'mediatype':'tvshow','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'studio':TDyGQtFLmhgvqsWeIEOazjdKJwuxlf,'cast':TDyGQtFLmhgvqsWeIEOazjdKJwuxlY,'director':TDyGQtFLmhgvqsWeIEOazjdKJwuxlP,'genre':TDyGQtFLmhgvqsWeIEOazjdKJwuxln,'year':TDyGQtFLmhgvqsWeIEOazjdKJwuxlS,'premiered':TDyGQtFLmhgvqsWeIEOazjdKJwuxlR,'mpaa':TDyGQtFLmhgvqsWeIEOazjdKJwuxlo,'plot':TDyGQtFLmhgvqsWeIEOazjdKJwuxlN}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'EPISODE','programcode':TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('program'),'page':'1'}
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_makebookmark():
    TDyGQtFLmhgvqsWeIEOazjdKJwuxli={'videoid':TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('program'),'vidtype':'tvshow','vtitle':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'vsubtitle':TDyGQtFLmhgvqsWeIEOazjdKJwuxlf,}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlX=json.dumps(TDyGQtFLmhgvqsWeIEOazjdKJwuxli)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlX=urllib.parse.quote(TDyGQtFLmhgvqsWeIEOazjdKJwuxlX)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxlX)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=[('(통합) 찜 영상에 추가',TDyGQtFLmhgvqsWeIEOazjdKJwuxlM)]
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxlf,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxlV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN,ContextMenu=TDyGQtFLmhgvqsWeIEOazjdKJwuxlk)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpC:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['mode'] ='PROGRAM' 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['stype'] =TDyGQtFLmhgvqsWeIEOazjdKJwuxlr
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['orderby'] =TDyGQtFLmhgvqsWeIEOazjdKJwuxNB
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['page'] =TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['genreCode']=TDyGQtFLmhgvqsWeIEOazjdKJwuxlB 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb='[B]%s >>[/B]'%'다음 페이지'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlU=TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxlU,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxpV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  xbmcplugin.setContent(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
 def dp_4K_Program_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpM =TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('page'))
  TDyGQtFLmhgvqsWeIEOazjdKJwuxlc,TDyGQtFLmhgvqsWeIEOazjdKJwuxpC=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Get_UHD_ProgramList(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM)
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxlb in TDyGQtFLmhgvqsWeIEOazjdKJwuxlc:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlV =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('thumbnail')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlN =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('synopsis')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlf =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('channel')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlY =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('cast')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlP =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('director')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxln=TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('info_genre')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlS =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('year')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlR =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('premiered')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlo =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('mpaa')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'mediatype':'tvshow','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'studio':TDyGQtFLmhgvqsWeIEOazjdKJwuxlf,'cast':TDyGQtFLmhgvqsWeIEOazjdKJwuxlY,'director':TDyGQtFLmhgvqsWeIEOazjdKJwuxlP,'genre':TDyGQtFLmhgvqsWeIEOazjdKJwuxln,'year':TDyGQtFLmhgvqsWeIEOazjdKJwuxlS,'premiered':TDyGQtFLmhgvqsWeIEOazjdKJwuxlR,'mpaa':TDyGQtFLmhgvqsWeIEOazjdKJwuxlo,'plot':TDyGQtFLmhgvqsWeIEOazjdKJwuxlN}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'EPISODE','programcode':TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('program'),'page':'1'}
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_makebookmark():
    TDyGQtFLmhgvqsWeIEOazjdKJwuxli={'videoid':TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('program'),'vidtype':'tvshow','vtitle':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'vsubtitle':TDyGQtFLmhgvqsWeIEOazjdKJwuxlf,}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlX=json.dumps(TDyGQtFLmhgvqsWeIEOazjdKJwuxli)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlX=urllib.parse.quote(TDyGQtFLmhgvqsWeIEOazjdKJwuxlX)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxlX)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=[('(통합) 찜 영상에 추가',TDyGQtFLmhgvqsWeIEOazjdKJwuxlM)]
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxlf,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxlV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN,ContextMenu=TDyGQtFLmhgvqsWeIEOazjdKJwuxlk)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpC:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['mode'] ='4K_PROGRAM' 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['page'] =TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb='[B]%s >>[/B]'%'다음 페이지'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlU=TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxlU,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxpV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  xbmcplugin.setContent(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
 def dp_Ori_Program_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpM =TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('page'))
  TDyGQtFLmhgvqsWeIEOazjdKJwuxlc,TDyGQtFLmhgvqsWeIEOazjdKJwuxpC=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Get_Origianl_ProgramList(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM)
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxlb in TDyGQtFLmhgvqsWeIEOazjdKJwuxlc:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlV =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('thumbnail')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlH =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('vod_type')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYV =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('vod_code')
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxlH=='vod':
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'mediatype':'tvshow','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'EPISODE','programcode':TDyGQtFLmhgvqsWeIEOazjdKJwuxYV,'page':'1',}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpl=TDyGQtFLmhgvqsWeIEOazjdKJwuxon
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'mediatype':'movie','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'plot':'movie',}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'MOVIE','mediacode':TDyGQtFLmhgvqsWeIEOazjdKJwuxYV,'stype':'movie','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'thumbnail':TDyGQtFLmhgvqsWeIEOazjdKJwuxlV,}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpl=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxlV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxpl,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN,ContextMenu=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpC:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['mode'] ='ORI_PROGRAM' 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['page'] =TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb='[B]%s >>[/B]'%'다음 페이지'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlU=TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxlU,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxpV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  xbmcplugin.setContent(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
 def dp_Episode_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYN=TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('programcode')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpM =TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('page'))
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_log('programcode : '+TDyGQtFLmhgvqsWeIEOazjdKJwuxYN)
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYp,TDyGQtFLmhgvqsWeIEOazjdKJwuxpC,TDyGQtFLmhgvqsWeIEOazjdKJwuxYl=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.GetEpisodeList(TDyGQtFLmhgvqsWeIEOazjdKJwuxYN,TDyGQtFLmhgvqsWeIEOazjdKJwuxpM,orderby=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_winEpisodeOrderby())
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxYP in TDyGQtFLmhgvqsWeIEOazjdKJwuxYp:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb =TDyGQtFLmhgvqsWeIEOazjdKJwuxYP.get('title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlU =TDyGQtFLmhgvqsWeIEOazjdKJwuxYP.get('subtitle')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlV =TDyGQtFLmhgvqsWeIEOazjdKJwuxYP.get('thumbnail')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlN =TDyGQtFLmhgvqsWeIEOazjdKJwuxYP.get('synopsis')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYn=TDyGQtFLmhgvqsWeIEOazjdKJwuxYP.get('info_title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYS =TDyGQtFLmhgvqsWeIEOazjdKJwuxYP.get('aired')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYo =TDyGQtFLmhgvqsWeIEOazjdKJwuxYP.get('studio')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYR =TDyGQtFLmhgvqsWeIEOazjdKJwuxYP.get('frequency')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'mediatype':'episode','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxYn,'aired':TDyGQtFLmhgvqsWeIEOazjdKJwuxYS,'studio':TDyGQtFLmhgvqsWeIEOazjdKJwuxYo,'episode':TDyGQtFLmhgvqsWeIEOazjdKJwuxYR,'plot':TDyGQtFLmhgvqsWeIEOazjdKJwuxlN}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'VOD','mediacode':TDyGQtFLmhgvqsWeIEOazjdKJwuxYP.get('episode'),'stype':'vod','programcode':TDyGQtFLmhgvqsWeIEOazjdKJwuxYN,'title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'thumbnail':TDyGQtFLmhgvqsWeIEOazjdKJwuxlV}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxlU,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxlV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpM==1:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'plot':'정렬순서를 변경합니다.'}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['mode'] ='ORDER_BY' 
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_winEpisodeOrderby()=='desc':
    TDyGQtFLmhgvqsWeIEOazjdKJwuxNb='정렬순서변경 : 최신화부터 -> 1회부터'
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['orderby']='asc'
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxNb='정렬순서변경 : 1회부터 -> 최신화부터'
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['orderby']='desc'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel='',img=TDyGQtFLmhgvqsWeIEOazjdKJwuxpV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN,isLink=TDyGQtFLmhgvqsWeIEOazjdKJwuxon)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpC:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['mode'] ='EPISODE' 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['programcode']=TDyGQtFLmhgvqsWeIEOazjdKJwuxYN
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['page'] =TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb='[B]%s >>[/B]'%'다음 페이지'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlU=TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxlU,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxpV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  xbmcplugin.setContent(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,'episodes')
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxoB(TDyGQtFLmhgvqsWeIEOazjdKJwuxYp)>0:xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxon)
 def dp_setEpOrderby(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNB =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('orderby')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.set_winEpisodeOrderby(TDyGQtFLmhgvqsWeIEOazjdKJwuxNB)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxlr =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('stype')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNB =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('orderby')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpM=TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('page'))
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYA,TDyGQtFLmhgvqsWeIEOazjdKJwuxpC=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.GetMovieList(TDyGQtFLmhgvqsWeIEOazjdKJwuxlr,TDyGQtFLmhgvqsWeIEOazjdKJwuxNB,TDyGQtFLmhgvqsWeIEOazjdKJwuxpM)
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxYU in TDyGQtFLmhgvqsWeIEOazjdKJwuxYA:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlV =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('thumbnail')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlN =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('synopsis')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYn =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('info_title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlS =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('year')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlY =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('cast')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlP =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('director')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxln =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('info_genre')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYr =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('duration')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlR =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('premiered')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYo =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('studio')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlo =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('mpaa')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'mediatype':'movie','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxYn,'year':TDyGQtFLmhgvqsWeIEOazjdKJwuxlS,'cast':TDyGQtFLmhgvqsWeIEOazjdKJwuxlY,'director':TDyGQtFLmhgvqsWeIEOazjdKJwuxlP,'genre':TDyGQtFLmhgvqsWeIEOazjdKJwuxln,'duration':TDyGQtFLmhgvqsWeIEOazjdKJwuxYr,'premiered':TDyGQtFLmhgvqsWeIEOazjdKJwuxlR,'studio':TDyGQtFLmhgvqsWeIEOazjdKJwuxYo,'mpaa':TDyGQtFLmhgvqsWeIEOazjdKJwuxlo,'plot':TDyGQtFLmhgvqsWeIEOazjdKJwuxlN}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'MOVIE','mediacode':TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('moviecode'),'stype':'movie','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'thumbnail':TDyGQtFLmhgvqsWeIEOazjdKJwuxlV}
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_makebookmark():
    TDyGQtFLmhgvqsWeIEOazjdKJwuxli={'videoid':TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('moviecode'),'vidtype':'movie','vtitle':TDyGQtFLmhgvqsWeIEOazjdKJwuxYn,'vsubtitle':'',}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlX=json.dumps(TDyGQtFLmhgvqsWeIEOazjdKJwuxli)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlX=urllib.parse.quote(TDyGQtFLmhgvqsWeIEOazjdKJwuxlX)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxlX)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=[('(통합) 찜 영상에 추가',TDyGQtFLmhgvqsWeIEOazjdKJwuxlM)]
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel='',img=TDyGQtFLmhgvqsWeIEOazjdKJwuxlV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN,ContextMenu=TDyGQtFLmhgvqsWeIEOazjdKJwuxlk)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpC:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['mode'] ='MOVIE_SUB' 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['orderby']=TDyGQtFLmhgvqsWeIEOazjdKJwuxNB
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['stype'] =TDyGQtFLmhgvqsWeIEOazjdKJwuxlr
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['page'] =TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb='[B]%s >>[/B]'%'다음 페이지'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlU=TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxlU,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxpV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  xbmcplugin.setContent(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,'movies')
  xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
 def dp_4K_Movie_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpM=TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('page'))
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYA,TDyGQtFLmhgvqsWeIEOazjdKJwuxpC=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Get_UHD_MovieList(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM)
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxYU in TDyGQtFLmhgvqsWeIEOazjdKJwuxYA:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlV =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('thumbnail')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlN =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('synopsis')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYn =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('info_title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlS =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('year')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlY =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('cast')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlP =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('director')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxln =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('info_genre')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYr =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('duration')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlR =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('premiered')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYo =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('studio')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlo =TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('mpaa')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'mediatype':'movie','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxYn,'year':TDyGQtFLmhgvqsWeIEOazjdKJwuxlS,'cast':TDyGQtFLmhgvqsWeIEOazjdKJwuxlY,'director':TDyGQtFLmhgvqsWeIEOazjdKJwuxlP,'genre':TDyGQtFLmhgvqsWeIEOazjdKJwuxln,'duration':TDyGQtFLmhgvqsWeIEOazjdKJwuxYr,'premiered':TDyGQtFLmhgvqsWeIEOazjdKJwuxlR,'studio':TDyGQtFLmhgvqsWeIEOazjdKJwuxYo,'mpaa':TDyGQtFLmhgvqsWeIEOazjdKJwuxlo,'plot':TDyGQtFLmhgvqsWeIEOazjdKJwuxlN}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'MOVIE','mediacode':TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('moviecode'),'stype':'movie','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'thumbnail':TDyGQtFLmhgvqsWeIEOazjdKJwuxlV}
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_makebookmark():
    TDyGQtFLmhgvqsWeIEOazjdKJwuxli={'videoid':TDyGQtFLmhgvqsWeIEOazjdKJwuxYU.get('moviecode'),'vidtype':'movie','vtitle':TDyGQtFLmhgvqsWeIEOazjdKJwuxYn,'vsubtitle':'',}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlX=json.dumps(TDyGQtFLmhgvqsWeIEOazjdKJwuxli)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlX=urllib.parse.quote(TDyGQtFLmhgvqsWeIEOazjdKJwuxlX)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxlX)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=[('(통합) 찜 영상에 추가',TDyGQtFLmhgvqsWeIEOazjdKJwuxlM)]
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel='',img=TDyGQtFLmhgvqsWeIEOazjdKJwuxlV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN,ContextMenu=TDyGQtFLmhgvqsWeIEOazjdKJwuxlk)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpC:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['mode'] ='4K_MOVIE' 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['page'] =TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb='[B]%s >>[/B]'%'다음 페이지'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlU=TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxlU,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxpV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  xbmcplugin.setContent(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,'movies')
  xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
 def dp_Set_Bookmark(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYB=urllib.parse.unquote(TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('bm_param'))
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYB=json.loads(TDyGQtFLmhgvqsWeIEOazjdKJwuxYB)
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYc =TDyGQtFLmhgvqsWeIEOazjdKJwuxYB.get('videoid')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYb =TDyGQtFLmhgvqsWeIEOazjdKJwuxYB.get('vidtype')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYf =TDyGQtFLmhgvqsWeIEOazjdKJwuxYB.get('vtitle')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYi =TDyGQtFLmhgvqsWeIEOazjdKJwuxYB.get('vsubtitle')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVi=xbmcgui.Dialog()
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpU=TDyGQtFLmhgvqsWeIEOazjdKJwuxVi.yesno(__language__(30913).encode('utf8'),TDyGQtFLmhgvqsWeIEOazjdKJwuxYf+' \n\n'+__language__(30914))
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpU==TDyGQtFLmhgvqsWeIEOazjdKJwuxoS:return
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYX=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.GetBookmarkInfo(TDyGQtFLmhgvqsWeIEOazjdKJwuxYc,TDyGQtFLmhgvqsWeIEOazjdKJwuxYb)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxYi!='':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYX['saveinfo']['subtitle']=TDyGQtFLmhgvqsWeIEOazjdKJwuxYi 
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxYb=='tvshow':TDyGQtFLmhgvqsWeIEOazjdKJwuxYX['saveinfo']['infoLabels']['studio']=TDyGQtFLmhgvqsWeIEOazjdKJwuxYi 
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYM=json.dumps(TDyGQtFLmhgvqsWeIEOazjdKJwuxYX)
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYM=urllib.parse.quote(TDyGQtFLmhgvqsWeIEOazjdKJwuxYM)
  TDyGQtFLmhgvqsWeIEOazjdKJwuxlM ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxYM)
  xbmc.executebuiltin(TDyGQtFLmhgvqsWeIEOazjdKJwuxlM)
 def dp_Search_Group(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  if 'search_key' in TDyGQtFLmhgvqsWeIEOazjdKJwuxpX:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYk=TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('search_key')
  else:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYk=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not TDyGQtFLmhgvqsWeIEOazjdKJwuxYk:
    return
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxpi in TDyGQtFLmhgvqsWeIEOazjdKJwuxVP:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYC =TDyGQtFLmhgvqsWeIEOazjdKJwuxpi.get('mode')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpb=TDyGQtFLmhgvqsWeIEOazjdKJwuxpi.get('stype')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb=TDyGQtFLmhgvqsWeIEOazjdKJwuxpi.get('title')
   (TDyGQtFLmhgvqsWeIEOazjdKJwuxYH,TDyGQtFLmhgvqsWeIEOazjdKJwuxpC)=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.GetSearchList(TDyGQtFLmhgvqsWeIEOazjdKJwuxYk,1,TDyGQtFLmhgvqsWeIEOazjdKJwuxpb)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpP={'plot':'검색어 : '+TDyGQtFLmhgvqsWeIEOazjdKJwuxYk+'\n\n'+TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.Search_FreeList(TDyGQtFLmhgvqsWeIEOazjdKJwuxYH)}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':TDyGQtFLmhgvqsWeIEOazjdKJwuxYC,'stype':TDyGQtFLmhgvqsWeIEOazjdKJwuxpb,'search_key':TDyGQtFLmhgvqsWeIEOazjdKJwuxYk,'page':'1',}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel='',img='',infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxpP,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxoB(TDyGQtFLmhgvqsWeIEOazjdKJwuxVP)>0:xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxon)
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.Save_Searched_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxYk)
 def Search_FreeList(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxPR):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxPV=''
  TDyGQtFLmhgvqsWeIEOazjdKJwuxPN=7
  try:
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxoB(TDyGQtFLmhgvqsWeIEOazjdKJwuxPR)==0:return '검색결과 없음'
   for i in TDyGQtFLmhgvqsWeIEOazjdKJwuxob(TDyGQtFLmhgvqsWeIEOazjdKJwuxoB(TDyGQtFLmhgvqsWeIEOazjdKJwuxPR)):
    if i>=TDyGQtFLmhgvqsWeIEOazjdKJwuxPN:
     TDyGQtFLmhgvqsWeIEOazjdKJwuxPV=TDyGQtFLmhgvqsWeIEOazjdKJwuxPV+'...'
     break
    TDyGQtFLmhgvqsWeIEOazjdKJwuxPV=TDyGQtFLmhgvqsWeIEOazjdKJwuxPV+TDyGQtFLmhgvqsWeIEOazjdKJwuxPR[i]['title']+'\n'
  except:
   return ''
  return TDyGQtFLmhgvqsWeIEOazjdKJwuxPV
 def dp_Search_History(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxPp=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.Load_List_File('search')
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxPl in TDyGQtFLmhgvqsWeIEOazjdKJwuxPp:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPY=TDyGQtFLmhgvqsWeIEOazjdKJwuxoA(urllib.parse.parse_qsl(TDyGQtFLmhgvqsWeIEOazjdKJwuxPl))
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPn=TDyGQtFLmhgvqsWeIEOazjdKJwuxPY.get('skey').strip()
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'SEARCH_GROUP','search_key':TDyGQtFLmhgvqsWeIEOazjdKJwuxPn,}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPS={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':TDyGQtFLmhgvqsWeIEOazjdKJwuxPn,'vType':'-',}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPo=urllib.parse.urlencode(TDyGQtFLmhgvqsWeIEOazjdKJwuxPS)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=[('선택된 검색어 ( %s ) 삭제'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxPn),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxPo))]
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxPn,sublabel='',img=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN,ContextMenu=TDyGQtFLmhgvqsWeIEOazjdKJwuxlk)
  TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'plot':'검색목록 전체를 삭제합니다.'}
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNb='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel='',img=TDyGQtFLmhgvqsWeIEOazjdKJwuxpV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN,isLink=TDyGQtFLmhgvqsWeIEOazjdKJwuxon)
  xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
 def dp_Search_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpM =TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('page'))
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpb =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('stype')
  if 'search_key' in TDyGQtFLmhgvqsWeIEOazjdKJwuxpX:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYk=TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('search_key')
  else:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYk=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not TDyGQtFLmhgvqsWeIEOazjdKJwuxYk:
    xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle)
    return
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYH,TDyGQtFLmhgvqsWeIEOazjdKJwuxpC=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.GetSearchList(TDyGQtFLmhgvqsWeIEOazjdKJwuxYk,TDyGQtFLmhgvqsWeIEOazjdKJwuxpM,TDyGQtFLmhgvqsWeIEOazjdKJwuxpb)
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxPR in TDyGQtFLmhgvqsWeIEOazjdKJwuxYH:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb =TDyGQtFLmhgvqsWeIEOazjdKJwuxPR.get('title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlV =TDyGQtFLmhgvqsWeIEOazjdKJwuxPR.get('thumbnail')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlN =TDyGQtFLmhgvqsWeIEOazjdKJwuxPR.get('synopsis')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPA =TDyGQtFLmhgvqsWeIEOazjdKJwuxPR.get('program')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlY =TDyGQtFLmhgvqsWeIEOazjdKJwuxPR.get('cast')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlP =TDyGQtFLmhgvqsWeIEOazjdKJwuxPR.get('director')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxln=TDyGQtFLmhgvqsWeIEOazjdKJwuxPR.get('info_genre')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYr =TDyGQtFLmhgvqsWeIEOazjdKJwuxPR.get('duration')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlo =TDyGQtFLmhgvqsWeIEOazjdKJwuxPR.get('mpaa')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlS =TDyGQtFLmhgvqsWeIEOazjdKJwuxPR.get('year')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYS =TDyGQtFLmhgvqsWeIEOazjdKJwuxPR.get('aired')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'mediatype':'tvshow' if TDyGQtFLmhgvqsWeIEOazjdKJwuxpb=='vod' else 'movie','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'cast':TDyGQtFLmhgvqsWeIEOazjdKJwuxlY,'director':TDyGQtFLmhgvqsWeIEOazjdKJwuxlP,'genre':TDyGQtFLmhgvqsWeIEOazjdKJwuxln,'duration':TDyGQtFLmhgvqsWeIEOazjdKJwuxYr,'mpaa':TDyGQtFLmhgvqsWeIEOazjdKJwuxlo,'year':TDyGQtFLmhgvqsWeIEOazjdKJwuxlS,'aired':TDyGQtFLmhgvqsWeIEOazjdKJwuxYS,'plot':'%s\n\n%s'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,TDyGQtFLmhgvqsWeIEOazjdKJwuxlN)}
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxpb=='vod':
    TDyGQtFLmhgvqsWeIEOazjdKJwuxYc=TDyGQtFLmhgvqsWeIEOazjdKJwuxPR.get('program')
    TDyGQtFLmhgvqsWeIEOazjdKJwuxYb='tvshow'
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'EPISODE','programcode':TDyGQtFLmhgvqsWeIEOazjdKJwuxYc,'page':'1',}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpl=TDyGQtFLmhgvqsWeIEOazjdKJwuxon
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxYc=TDyGQtFLmhgvqsWeIEOazjdKJwuxPR.get('movie')
    TDyGQtFLmhgvqsWeIEOazjdKJwuxYb='movie'
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'MOVIE','mediacode':TDyGQtFLmhgvqsWeIEOazjdKJwuxYc,'stype':'movie','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'thumbnail':TDyGQtFLmhgvqsWeIEOazjdKJwuxlV,}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpl=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_makebookmark():
    TDyGQtFLmhgvqsWeIEOazjdKJwuxli={'videoid':TDyGQtFLmhgvqsWeIEOazjdKJwuxYc,'vidtype':TDyGQtFLmhgvqsWeIEOazjdKJwuxYb,'vtitle':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'vsubtitle':'',}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlX=json.dumps(TDyGQtFLmhgvqsWeIEOazjdKJwuxli)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlX=urllib.parse.quote(TDyGQtFLmhgvqsWeIEOazjdKJwuxlX)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxlX)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=[('(통합) 찜 영상에 추가',TDyGQtFLmhgvqsWeIEOazjdKJwuxlM)]
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel='',img=TDyGQtFLmhgvqsWeIEOazjdKJwuxlV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxpl,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN,isLink=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS,ContextMenu=TDyGQtFLmhgvqsWeIEOazjdKJwuxlk)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpC:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['mode'] ='SEARCH' 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['search_key']=TDyGQtFLmhgvqsWeIEOazjdKJwuxYk
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN['page'] =TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb='[B]%s >>[/B]'%'다음 페이지'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlU=TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxpM+1)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxlU,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxpV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpb=='movie':xbmcplugin.setContent(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,'movies')
  else:xbmcplugin.setContent(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
 def dp_History_Remove(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxPU=TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('delType')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxPr =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('sKey')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxPB =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('vType')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVi=xbmcgui.Dialog()
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxPU=='SEARCH_ALL':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpU=TDyGQtFLmhgvqsWeIEOazjdKJwuxVi.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxPU=='SEARCH_ONE':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpU=TDyGQtFLmhgvqsWeIEOazjdKJwuxVi.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxPU=='WATCH_ALL':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpU=TDyGQtFLmhgvqsWeIEOazjdKJwuxVi.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxPU=='WATCH_ONE':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpU=TDyGQtFLmhgvqsWeIEOazjdKJwuxVi.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpU==TDyGQtFLmhgvqsWeIEOazjdKJwuxoS:sys.exit()
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxPU=='SEARCH_ALL':
   if os.path.isfile(TDyGQtFLmhgvqsWeIEOazjdKJwuxVU):os.remove(TDyGQtFLmhgvqsWeIEOazjdKJwuxVU)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxPU=='SEARCH_ONE':
   try:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxPc=TDyGQtFLmhgvqsWeIEOazjdKJwuxVU
    TDyGQtFLmhgvqsWeIEOazjdKJwuxPb=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.Load_List_File('search') 
    fp=TDyGQtFLmhgvqsWeIEOazjdKJwuxof(TDyGQtFLmhgvqsWeIEOazjdKJwuxPc,'w',-1,'utf-8')
    for TDyGQtFLmhgvqsWeIEOazjdKJwuxPf in TDyGQtFLmhgvqsWeIEOazjdKJwuxPb:
     TDyGQtFLmhgvqsWeIEOazjdKJwuxPi=TDyGQtFLmhgvqsWeIEOazjdKJwuxoA(urllib.parse.parse_qsl(TDyGQtFLmhgvqsWeIEOazjdKJwuxPf))
     TDyGQtFLmhgvqsWeIEOazjdKJwuxPX=TDyGQtFLmhgvqsWeIEOazjdKJwuxPi.get('skey').strip()
     if TDyGQtFLmhgvqsWeIEOazjdKJwuxPr!=TDyGQtFLmhgvqsWeIEOazjdKJwuxPX:
      fp.write(TDyGQtFLmhgvqsWeIEOazjdKJwuxPf)
    fp.close()
   except:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxPU=='WATCH_ALL':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPc=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TDyGQtFLmhgvqsWeIEOazjdKJwuxPB))
   if os.path.isfile(TDyGQtFLmhgvqsWeIEOazjdKJwuxPc):os.remove(TDyGQtFLmhgvqsWeIEOazjdKJwuxPc)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxPU=='WATCH_ONE':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPc=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TDyGQtFLmhgvqsWeIEOazjdKJwuxPB))
   try:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxPb=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.Load_List_File(TDyGQtFLmhgvqsWeIEOazjdKJwuxPB) 
    fp=TDyGQtFLmhgvqsWeIEOazjdKJwuxof(TDyGQtFLmhgvqsWeIEOazjdKJwuxPc,'w',-1,'utf-8')
    for TDyGQtFLmhgvqsWeIEOazjdKJwuxPf in TDyGQtFLmhgvqsWeIEOazjdKJwuxPb:
     TDyGQtFLmhgvqsWeIEOazjdKJwuxPi=TDyGQtFLmhgvqsWeIEOazjdKJwuxoA(urllib.parse.parse_qsl(TDyGQtFLmhgvqsWeIEOazjdKJwuxPf))
     TDyGQtFLmhgvqsWeIEOazjdKJwuxPX=TDyGQtFLmhgvqsWeIEOazjdKJwuxPi.get('code').strip()
     if TDyGQtFLmhgvqsWeIEOazjdKJwuxPr!=TDyGQtFLmhgvqsWeIEOazjdKJwuxPX:
      fp.write(TDyGQtFLmhgvqsWeIEOazjdKJwuxPf)
    fp.close()
   except:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpb): 
  try:
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxpb=='search':
    TDyGQtFLmhgvqsWeIEOazjdKJwuxPc=TDyGQtFLmhgvqsWeIEOazjdKJwuxVU
   elif TDyGQtFLmhgvqsWeIEOazjdKJwuxpb in['vod','movie']:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxPc=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TDyGQtFLmhgvqsWeIEOazjdKJwuxpb))
   else:
    return[]
   fp=TDyGQtFLmhgvqsWeIEOazjdKJwuxof(TDyGQtFLmhgvqsWeIEOazjdKJwuxPc,'r',-1,'utf-8')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPM=fp.readlines()
   fp.close()
  except:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPM=[]
  return TDyGQtFLmhgvqsWeIEOazjdKJwuxPM
 def Save_Watched_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpb,TDyGQtFLmhgvqsWeIEOazjdKJwuxVb):
  try:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TDyGQtFLmhgvqsWeIEOazjdKJwuxpb))
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPb=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.Load_List_File(TDyGQtFLmhgvqsWeIEOazjdKJwuxpb) 
   fp=TDyGQtFLmhgvqsWeIEOazjdKJwuxof(TDyGQtFLmhgvqsWeIEOazjdKJwuxPk,'w',-1,'utf-8')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPC=urllib.parse.urlencode(TDyGQtFLmhgvqsWeIEOazjdKJwuxVb)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPC=TDyGQtFLmhgvqsWeIEOazjdKJwuxPC+'\n'
   fp.write(TDyGQtFLmhgvqsWeIEOazjdKJwuxPC)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPH=0
   for TDyGQtFLmhgvqsWeIEOazjdKJwuxPf in TDyGQtFLmhgvqsWeIEOazjdKJwuxPb:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxPi=TDyGQtFLmhgvqsWeIEOazjdKJwuxoA(urllib.parse.parse_qsl(TDyGQtFLmhgvqsWeIEOazjdKJwuxPf))
    TDyGQtFLmhgvqsWeIEOazjdKJwuxnV=TDyGQtFLmhgvqsWeIEOazjdKJwuxVb.get('code').strip()
    TDyGQtFLmhgvqsWeIEOazjdKJwuxnN=TDyGQtFLmhgvqsWeIEOazjdKJwuxPi.get('code').strip()
    if TDyGQtFLmhgvqsWeIEOazjdKJwuxpb=='vod' and TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_direct_replay()==TDyGQtFLmhgvqsWeIEOazjdKJwuxon:
     TDyGQtFLmhgvqsWeIEOazjdKJwuxnV=TDyGQtFLmhgvqsWeIEOazjdKJwuxVb.get('videoid').strip()
     TDyGQtFLmhgvqsWeIEOazjdKJwuxnN=TDyGQtFLmhgvqsWeIEOazjdKJwuxPi.get('videoid').strip()if TDyGQtFLmhgvqsWeIEOazjdKJwuxnN!=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY else '-'
    if TDyGQtFLmhgvqsWeIEOazjdKJwuxnV!=TDyGQtFLmhgvqsWeIEOazjdKJwuxnN:
     fp.write(TDyGQtFLmhgvqsWeIEOazjdKJwuxPf)
     TDyGQtFLmhgvqsWeIEOazjdKJwuxPH+=1
     if TDyGQtFLmhgvqsWeIEOazjdKJwuxPH>=50:break
   fp.close()
  except:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
 def dp_Watch_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpb =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('stype')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNU=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_direct_replay()
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpb=='-':
   for TDyGQtFLmhgvqsWeIEOazjdKJwuxpi in TDyGQtFLmhgvqsWeIEOazjdKJwuxVY:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxNb=TDyGQtFLmhgvqsWeIEOazjdKJwuxpi.get('title')
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':TDyGQtFLmhgvqsWeIEOazjdKJwuxpi.get('mode'),'stype':TDyGQtFLmhgvqsWeIEOazjdKJwuxpi.get('stype')}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel='',img='',infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxoB(TDyGQtFLmhgvqsWeIEOazjdKJwuxVY)>0:xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle)
  else:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnp=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.Load_List_File(TDyGQtFLmhgvqsWeIEOazjdKJwuxpb)
   for TDyGQtFLmhgvqsWeIEOazjdKJwuxnl in TDyGQtFLmhgvqsWeIEOazjdKJwuxnp:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxPY=TDyGQtFLmhgvqsWeIEOazjdKJwuxoA(urllib.parse.parse_qsl(TDyGQtFLmhgvqsWeIEOazjdKJwuxnl))
    TDyGQtFLmhgvqsWeIEOazjdKJwuxnY =TDyGQtFLmhgvqsWeIEOazjdKJwuxPY.get('code').strip()
    TDyGQtFLmhgvqsWeIEOazjdKJwuxNb =TDyGQtFLmhgvqsWeIEOazjdKJwuxPY.get('title').strip()
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlV=TDyGQtFLmhgvqsWeIEOazjdKJwuxPY.get('img').strip()
    TDyGQtFLmhgvqsWeIEOazjdKJwuxYc =TDyGQtFLmhgvqsWeIEOazjdKJwuxPY.get('videoid').strip()
    try:
     TDyGQtFLmhgvqsWeIEOazjdKJwuxlV=TDyGQtFLmhgvqsWeIEOazjdKJwuxlV.replace('\'','\"')
     TDyGQtFLmhgvqsWeIEOazjdKJwuxlV=json.loads(TDyGQtFLmhgvqsWeIEOazjdKJwuxlV)
    except:
     TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlA['plot']=TDyGQtFLmhgvqsWeIEOazjdKJwuxNb
    if TDyGQtFLmhgvqsWeIEOazjdKJwuxpb=='vod':
     if TDyGQtFLmhgvqsWeIEOazjdKJwuxNU==TDyGQtFLmhgvqsWeIEOazjdKJwuxoS or TDyGQtFLmhgvqsWeIEOazjdKJwuxYc==TDyGQtFLmhgvqsWeIEOazjdKJwuxoY:
      TDyGQtFLmhgvqsWeIEOazjdKJwuxlA['mediatype']='tvshow'
      TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'EPISODE','programcode':TDyGQtFLmhgvqsWeIEOazjdKJwuxnY,'page':'1'}
      TDyGQtFLmhgvqsWeIEOazjdKJwuxpl=TDyGQtFLmhgvqsWeIEOazjdKJwuxon
     else:
      TDyGQtFLmhgvqsWeIEOazjdKJwuxlA['mediatype']='episode'
      TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'VOD','mediacode':TDyGQtFLmhgvqsWeIEOazjdKJwuxYc,'stype':'vod','programcode':TDyGQtFLmhgvqsWeIEOazjdKJwuxnY,'title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'thumbnail':TDyGQtFLmhgvqsWeIEOazjdKJwuxlV}
      TDyGQtFLmhgvqsWeIEOazjdKJwuxpl=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
    else:
     TDyGQtFLmhgvqsWeIEOazjdKJwuxlA['mediatype']='movie'
     TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'MOVIE','mediacode':TDyGQtFLmhgvqsWeIEOazjdKJwuxnY,'stype':'movie','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'thumbnail':TDyGQtFLmhgvqsWeIEOazjdKJwuxlV}
     TDyGQtFLmhgvqsWeIEOazjdKJwuxpl=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
    TDyGQtFLmhgvqsWeIEOazjdKJwuxPS={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':TDyGQtFLmhgvqsWeIEOazjdKJwuxnY,'vType':TDyGQtFLmhgvqsWeIEOazjdKJwuxpb,}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxPo=urllib.parse.urlencode(TDyGQtFLmhgvqsWeIEOazjdKJwuxPS)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=[('선택된 시청이력 ( %s ) 삭제'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxPo))]
    TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel='',img=TDyGQtFLmhgvqsWeIEOazjdKJwuxlV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxpl,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN,ContextMenu=TDyGQtFLmhgvqsWeIEOazjdKJwuxlk)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'plot':'시청목록을 삭제합니다.'}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':TDyGQtFLmhgvqsWeIEOazjdKJwuxpb,}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel='',img=TDyGQtFLmhgvqsWeIEOazjdKJwuxpV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN,isLink=TDyGQtFLmhgvqsWeIEOazjdKJwuxon)
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxpb=='movie':xbmcplugin.setContent(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,'movies')
   else:xbmcplugin.setContent(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
 def Save_Searched_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxYk):
  try:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnP=TDyGQtFLmhgvqsWeIEOazjdKJwuxVU
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPb=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.Load_List_File('search') 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnS={'skey':TDyGQtFLmhgvqsWeIEOazjdKJwuxYk.strip()}
   fp=TDyGQtFLmhgvqsWeIEOazjdKJwuxof(TDyGQtFLmhgvqsWeIEOazjdKJwuxnP,'w',-1,'utf-8')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPC=urllib.parse.urlencode(TDyGQtFLmhgvqsWeIEOazjdKJwuxnS)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPC=TDyGQtFLmhgvqsWeIEOazjdKJwuxPC+'\n'
   fp.write(TDyGQtFLmhgvqsWeIEOazjdKJwuxPC)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxPH=0
   for TDyGQtFLmhgvqsWeIEOazjdKJwuxPf in TDyGQtFLmhgvqsWeIEOazjdKJwuxPb:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxPi=TDyGQtFLmhgvqsWeIEOazjdKJwuxoA(urllib.parse.parse_qsl(TDyGQtFLmhgvqsWeIEOazjdKJwuxPf))
    TDyGQtFLmhgvqsWeIEOazjdKJwuxnV=TDyGQtFLmhgvqsWeIEOazjdKJwuxnS.get('skey').strip()
    TDyGQtFLmhgvqsWeIEOazjdKJwuxnN=TDyGQtFLmhgvqsWeIEOazjdKJwuxPi.get('skey').strip()
    if TDyGQtFLmhgvqsWeIEOazjdKJwuxnV!=TDyGQtFLmhgvqsWeIEOazjdKJwuxnN:
     fp.write(TDyGQtFLmhgvqsWeIEOazjdKJwuxPf)
     TDyGQtFLmhgvqsWeIEOazjdKJwuxPH+=1
     if TDyGQtFLmhgvqsWeIEOazjdKJwuxPH>=50:break
   fp.close()
  except:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
 def play_VIDEO(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxno =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('mediacode')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpb =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('stype')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxnR =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('pvrmode')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxnA=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_selQuality(TDyGQtFLmhgvqsWeIEOazjdKJwuxpb)
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxno,TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxnA),TDyGQtFLmhgvqsWeIEOazjdKJwuxpb,TDyGQtFLmhgvqsWeIEOazjdKJwuxnR))
  TDyGQtFLmhgvqsWeIEOazjdKJwuxnU=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.GetBroadURL(TDyGQtFLmhgvqsWeIEOazjdKJwuxno,TDyGQtFLmhgvqsWeIEOazjdKJwuxnA,TDyGQtFLmhgvqsWeIEOazjdKJwuxpb,TDyGQtFLmhgvqsWeIEOazjdKJwuxnR,optUHD=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_uhd())
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_log('qt, stype, url : %s - %s - %s'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxoc(TDyGQtFLmhgvqsWeIEOazjdKJwuxnA),TDyGQtFLmhgvqsWeIEOazjdKJwuxpb,TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['streaming_url']))
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['streaming_url']=='':
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['error_msg']=='':
    TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_noti(__language__(30908).encode('utf8'))
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_noti(TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['error_msg'].encode('utf8'))
   return
  TDyGQtFLmhgvqsWeIEOazjdKJwuxnr={'user-agent':TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.USER_AGENT}
  TDyGQtFLmhgvqsWeIEOazjdKJwuxnB=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.makeDefaultCookies() 
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['watermark'] !='':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnr['x-tving-param1']=TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['watermarkKey']
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnr['x-tving-param2']=TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['watermark'] 
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['drm_server_url'] !='':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnr[TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['drm_header_key']]=TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['drm_header_value']
  TDyGQtFLmhgvqsWeIEOazjdKJwuxnc =TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
  TDyGQtFLmhgvqsWeIEOazjdKJwuxnb =TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['streaming_url'].find('Policy=')
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxnb!=-1:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnf =TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['streaming_url'].split('?')[0]
   TDyGQtFLmhgvqsWeIEOazjdKJwuxni=TDyGQtFLmhgvqsWeIEOazjdKJwuxoA(urllib.parse.parse_qsl(urllib.parse.urlsplit(TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['streaming_url']).query))
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnB['CloudFront-Policy'] =TDyGQtFLmhgvqsWeIEOazjdKJwuxni['Policy'] 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnB['CloudFront-Signature'] =TDyGQtFLmhgvqsWeIEOazjdKJwuxni['Signature'] 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnB['CloudFront-Key-Pair-Id']=TDyGQtFLmhgvqsWeIEOazjdKJwuxni['Key-Pair-Id'] 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnX=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.make_stream_header(TDyGQtFLmhgvqsWeIEOazjdKJwuxnr,TDyGQtFLmhgvqsWeIEOazjdKJwuxnB)
   if 'quickvod-mcdn.tving.com' in TDyGQtFLmhgvqsWeIEOazjdKJwuxnf:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxnc=TDyGQtFLmhgvqsWeIEOazjdKJwuxon
    TDyGQtFLmhgvqsWeIEOazjdKJwuxnM =TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxnk=TDyGQtFLmhgvqsWeIEOazjdKJwuxnM.strftime('%Y-%m-%d-%H:%M:%S')
    if TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(TDyGQtFLmhgvqsWeIEOazjdKJwuxnk.replace('-','').replace(':',''))<TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(TDyGQtFLmhgvqsWeIEOazjdKJwuxni['end'].replace('-','').replace(':','')):
     TDyGQtFLmhgvqsWeIEOazjdKJwuxni['end']=TDyGQtFLmhgvqsWeIEOazjdKJwuxnk
     TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_noti(__language__(30915).encode('utf8'))
    TDyGQtFLmhgvqsWeIEOazjdKJwuxnf ='%s?%s'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxnf,urllib.parse.urlencode(TDyGQtFLmhgvqsWeIEOazjdKJwuxni,doseq=TDyGQtFLmhgvqsWeIEOazjdKJwuxon))
    TDyGQtFLmhgvqsWeIEOazjdKJwuxnC='{}|{}'.format(TDyGQtFLmhgvqsWeIEOazjdKJwuxnf,TDyGQtFLmhgvqsWeIEOazjdKJwuxnX)
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxnC='{}|{}'.format(TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['streaming_url'],TDyGQtFLmhgvqsWeIEOazjdKJwuxnX)
  else:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnX=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.make_stream_header(TDyGQtFLmhgvqsWeIEOazjdKJwuxnr,TDyGQtFLmhgvqsWeIEOazjdKJwuxnB)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnC='{}|{}'.format(TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['streaming_url'],TDyGQtFLmhgvqsWeIEOazjdKJwuxnX)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_log('if tmp_pos == -1')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNY,TDyGQtFLmhgvqsWeIEOazjdKJwuxNP=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_proxyport()
  TDyGQtFLmhgvqsWeIEOazjdKJwuxNl=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_playback()
  if(TDyGQtFLmhgvqsWeIEOazjdKJwuxNY and TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('mode')in['VOD','MOVIE']and TDyGQtFLmhgvqsWeIEOazjdKJwuxnc==TDyGQtFLmhgvqsWeIEOazjdKJwuxoS and(TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['drm_server_url']!='' or(TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['url_filename'].split('.')[1]=='mpd')or(TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['url_filename'].split('.')[1]!='mpd' and TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.KodiVersion>=21 and TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['qt_stream']=='stream70'))):
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['url_filename'].split('.')[1]=='mpd':
    TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Tving_Parse_mpd(TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['streaming_url'],TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['watermarkKey'],TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['watermark'])
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Tving_Parse_m3u8(TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['streaming_url'])
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_log('xxx '+TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['streaming_url'])
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnH={'addon':'tvingm','playOption':TDyGQtFLmhgvqsWeIEOazjdKJwuxNl,'url_filename':TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['url_filename'],}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnH=json.dumps(TDyGQtFLmhgvqsWeIEOazjdKJwuxnH,separators=(',',':'))
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnH=base64.standard_b64encode(TDyGQtFLmhgvqsWeIEOazjdKJwuxnH.encode()).decode('utf-8')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnC ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(TDyGQtFLmhgvqsWeIEOazjdKJwuxNP,TDyGQtFLmhgvqsWeIEOazjdKJwuxnC,TDyGQtFLmhgvqsWeIEOazjdKJwuxnH)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxnr['proxy-mini']=TDyGQtFLmhgvqsWeIEOazjdKJwuxnH 
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_log('surl(2) : {}'.format(TDyGQtFLmhgvqsWeIEOazjdKJwuxnC))
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_log('drm     : {}'.format(TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['drm_server_url']))
  TDyGQtFLmhgvqsWeIEOazjdKJwuxnX=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.make_stream_header(TDyGQtFLmhgvqsWeIEOazjdKJwuxnr,TDyGQtFLmhgvqsWeIEOazjdKJwuxnB)
  TDyGQtFLmhgvqsWeIEOazjdKJwuxSV=xbmcgui.ListItem(path=TDyGQtFLmhgvqsWeIEOazjdKJwuxnC)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['drm_server_url']!='':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSN=TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['drm_server_url']
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSp ='https://license-global.pallycon.com/ri/licenseManager.do' 
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSl ='mpd'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSY ='com.widevine.alpha'
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSn={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.USER_AGENT,TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['drm_header_key']:TDyGQtFLmhgvqsWeIEOazjdKJwuxnU['drm_header_value'],}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSo=TDyGQtFLmhgvqsWeIEOazjdKJwuxSp+'|'+urllib.parse.urlencode(TDyGQtFLmhgvqsWeIEOazjdKJwuxSn)+'|R{SSM}|'
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream','inputstream.adaptive')
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.KodiVersion<=20:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream.adaptive.manifest_type',TDyGQtFLmhgvqsWeIEOazjdKJwuxSl)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream.adaptive.license_type',TDyGQtFLmhgvqsWeIEOazjdKJwuxSY)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream.adaptive.license_key',TDyGQtFLmhgvqsWeIEOazjdKJwuxSo)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream.adaptive.stream_headers',TDyGQtFLmhgvqsWeIEOazjdKJwuxnX)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream.adaptive.manifest_headers',TDyGQtFLmhgvqsWeIEOazjdKJwuxnX)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('mode')in['VOD','MOVIE']:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setContentLookup(TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setMimeType('application/x-mpegURL')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream','inputstream.adaptive')
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.KodiVersion<=20:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream.adaptive.manifest_type','hls')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream.adaptive.stream_headers',TDyGQtFLmhgvqsWeIEOazjdKJwuxnX)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream.adaptive.manifest_headers',TDyGQtFLmhgvqsWeIEOazjdKJwuxnX)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxnc==TDyGQtFLmhgvqsWeIEOazjdKJwuxon:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setContentLookup(TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setMimeType('application/x-mpegURL')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream','inputstream.ffmpegdirect')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('ResumeTime','0')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSV.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,TDyGQtFLmhgvqsWeIEOazjdKJwuxon,TDyGQtFLmhgvqsWeIEOazjdKJwuxSV)
  try:
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('mode')in['VOD','MOVIE']and TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('title'):
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'code':TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('programcode')if TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('mode')=='VOD' else TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('mediacode'),'img':TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('thumbnail'),'title':TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('title'),'videoid':TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('mediacode')}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.Save_Watched_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('stype'),TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  except:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
 def logout(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVi=xbmcgui.Dialog()
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpU=TDyGQtFLmhgvqsWeIEOazjdKJwuxVi.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxpU==TDyGQtFLmhgvqsWeIEOazjdKJwuxoS:sys.exit()
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Init_TV_Total()
  if os.path.isfile(TDyGQtFLmhgvqsWeIEOazjdKJwuxVA):os.remove(TDyGQtFLmhgvqsWeIEOazjdKJwuxVA)
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxSR =TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Get_Now_Datetime()
  TDyGQtFLmhgvqsWeIEOazjdKJwuxSA=TDyGQtFLmhgvqsWeIEOazjdKJwuxSR+datetime.timedelta(days=30) 
  (TDyGQtFLmhgvqsWeIEOazjdKJwuxpS,TDyGQtFLmhgvqsWeIEOazjdKJwuxpo,TDyGQtFLmhgvqsWeIEOazjdKJwuxpR,TDyGQtFLmhgvqsWeIEOazjdKJwuxpA)=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_account()
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Save_session_acount(TDyGQtFLmhgvqsWeIEOazjdKJwuxpS,TDyGQtFLmhgvqsWeIEOazjdKJwuxpo,TDyGQtFLmhgvqsWeIEOazjdKJwuxpR,TDyGQtFLmhgvqsWeIEOazjdKJwuxpA)
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.TV['account']['token_limit']=TDyGQtFLmhgvqsWeIEOazjdKJwuxSA.strftime('%Y%m%d')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.JsonFile_Save(TDyGQtFLmhgvqsWeIEOazjdKJwuxVA,TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.TV)
 def cookiefile_check(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.TV=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.JsonFile_Load(TDyGQtFLmhgvqsWeIEOazjdKJwuxVA)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.TV=={}:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Init_TV_Total()
   return TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
  (TDyGQtFLmhgvqsWeIEOazjdKJwuxSU,TDyGQtFLmhgvqsWeIEOazjdKJwuxSr,TDyGQtFLmhgvqsWeIEOazjdKJwuxSB,TDyGQtFLmhgvqsWeIEOazjdKJwuxSc)=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_account()
  (TDyGQtFLmhgvqsWeIEOazjdKJwuxSb,TDyGQtFLmhgvqsWeIEOazjdKJwuxSf,TDyGQtFLmhgvqsWeIEOazjdKJwuxSi,TDyGQtFLmhgvqsWeIEOazjdKJwuxSX)=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Load_session_acount()
  if(TDyGQtFLmhgvqsWeIEOazjdKJwuxSU!=TDyGQtFLmhgvqsWeIEOazjdKJwuxSb or TDyGQtFLmhgvqsWeIEOazjdKJwuxSr!=TDyGQtFLmhgvqsWeIEOazjdKJwuxSf or TDyGQtFLmhgvqsWeIEOazjdKJwuxSB!=TDyGQtFLmhgvqsWeIEOazjdKJwuxSi or TDyGQtFLmhgvqsWeIEOazjdKJwuxSc!=TDyGQtFLmhgvqsWeIEOazjdKJwuxSX)and TDyGQtFLmhgvqsWeIEOazjdKJwuxSb!='xxxxx':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Init_TV_Total()
   return TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.TV['account']['token_limit']):
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Init_TV_Total()
   return TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
  return TDyGQtFLmhgvqsWeIEOazjdKJwuxon
 def dp_Global_Search(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('mode')
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='TOTAL_SEARCH':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSM='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSM='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(TDyGQtFLmhgvqsWeIEOazjdKJwuxSM)
 def dp_Bookmark_Menu(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxSM='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(TDyGQtFLmhgvqsWeIEOazjdKJwuxSM)
 def dp_EuroLive_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxpk=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.GetEuroChannelList()
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxpH in TDyGQtFLmhgvqsWeIEOazjdKJwuxpk:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlf =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('channel')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlU =TDyGQtFLmhgvqsWeIEOazjdKJwuxpH.get('subtitle')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'mediatype':'episode','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'plot':'%s\n%s'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,TDyGQtFLmhgvqsWeIEOazjdKJwuxlU)}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'LIVE','mediacode':TDyGQtFLmhgvqsWeIEOazjdKJwuxlf,'stype':'onair',}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxlU,img='',infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxoB(TDyGQtFLmhgvqsWeIEOazjdKJwuxpk)>0:xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
 def dp_Apple_Group(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxSk=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Get_AppleGroup_List()
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxSC in TDyGQtFLmhgvqsWeIEOazjdKJwuxSk:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxSH =TDyGQtFLmhgvqsWeIEOazjdKJwuxSC.get('bandName')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxoV =TDyGQtFLmhgvqsWeIEOazjdKJwuxSC.get('bandKey')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxoN =TDyGQtFLmhgvqsWeIEOazjdKJwuxSC.get('moreUrl')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'mediatype':'tvshow','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxSH,'plot':'%s'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxoV),}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'BAND_VODLIST','bandKey':TDyGQtFLmhgvqsWeIEOazjdKJwuxoV,'moreUrl':TDyGQtFLmhgvqsWeIEOazjdKJwuxoN,}
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxSH,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY,img='',infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxon,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxoB(TDyGQtFLmhgvqsWeIEOazjdKJwuxSk)>0:xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
 def dp_Band_VodList(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr,TDyGQtFLmhgvqsWeIEOazjdKJwuxpX):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxoV =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('bandKey')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxoN =TDyGQtFLmhgvqsWeIEOazjdKJwuxpX.get('moreUrl')
  TDyGQtFLmhgvqsWeIEOazjdKJwuxop ='Apple TV+'
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.addon_log('bandCode : '+TDyGQtFLmhgvqsWeIEOazjdKJwuxoV)
  TDyGQtFLmhgvqsWeIEOazjdKJwuxlc=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.Get_Band_VodList(TDyGQtFLmhgvqsWeIEOazjdKJwuxoV,TDyGQtFLmhgvqsWeIEOazjdKJwuxoN)
  for TDyGQtFLmhgvqsWeIEOazjdKJwuxlb in TDyGQtFLmhgvqsWeIEOazjdKJwuxlc:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxNb =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('title')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlV =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('thumbnail')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxYc =TDyGQtFLmhgvqsWeIEOazjdKJwuxlb.get('program')
   TDyGQtFLmhgvqsWeIEOazjdKJwuxlA={'mediatype':'tvshow' if not TDyGQtFLmhgvqsWeIEOazjdKJwuxYc.startswith('M')else 'movie','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'plot':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb+'\n'+'tvshow' if not TDyGQtFLmhgvqsWeIEOazjdKJwuxYc.startswith('M')else 'movie',}
   if not TDyGQtFLmhgvqsWeIEOazjdKJwuxYc.startswith('M'):
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'EPISODE','programcode':TDyGQtFLmhgvqsWeIEOazjdKJwuxYc,'page':'1',}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpl=TDyGQtFLmhgvqsWeIEOazjdKJwuxon
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpN={'mode':'MOVIE','mediacode':TDyGQtFLmhgvqsWeIEOazjdKJwuxYc,'stype':'movie','title':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'thumbnail':TDyGQtFLmhgvqsWeIEOazjdKJwuxlV,}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxpl=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS
   if TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.get_settings_makebookmark():
    TDyGQtFLmhgvqsWeIEOazjdKJwuxli={'videoid':TDyGQtFLmhgvqsWeIEOazjdKJwuxYc,'vidtype':'tvshow','vtitle':TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,'vsubtitle':TDyGQtFLmhgvqsWeIEOazjdKJwuxop,}
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlX=json.dumps(TDyGQtFLmhgvqsWeIEOazjdKJwuxli)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlX=urllib.parse.quote(TDyGQtFLmhgvqsWeIEOazjdKJwuxlX)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(TDyGQtFLmhgvqsWeIEOazjdKJwuxlX)
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=[('(통합) 찜 영상에 추가',TDyGQtFLmhgvqsWeIEOazjdKJwuxlM)]
   else:
    TDyGQtFLmhgvqsWeIEOazjdKJwuxlk=TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.add_dir(TDyGQtFLmhgvqsWeIEOazjdKJwuxNb,sublabel=TDyGQtFLmhgvqsWeIEOazjdKJwuxop,img=TDyGQtFLmhgvqsWeIEOazjdKJwuxlV,infoLabels=TDyGQtFLmhgvqsWeIEOazjdKJwuxlA,isFolder=TDyGQtFLmhgvqsWeIEOazjdKJwuxpl,params=TDyGQtFLmhgvqsWeIEOazjdKJwuxpN,ContextMenu=TDyGQtFLmhgvqsWeIEOazjdKJwuxlk)
  xbmcplugin.setContent(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr._addon_handle,cacheToDisc=TDyGQtFLmhgvqsWeIEOazjdKJwuxoS)
 def tving_main(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr):
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.TvingObj.KodiVersion=TDyGQtFLmhgvqsWeIEOazjdKJwuxoP(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params.get('mode',TDyGQtFLmhgvqsWeIEOazjdKJwuxoY)
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='LOGOUT':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.logout()
   return
  TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.login_main()
  if TDyGQtFLmhgvqsWeIEOazjdKJwuxYC is TDyGQtFLmhgvqsWeIEOazjdKJwuxoY:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Main_List()
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Title_Group(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC in['GLOBAL_GROUP']:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_SubTitle_Group(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='CHANNEL':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_LiveChannel_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC in['LIVE','VOD','MOVIE']:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.play_VIDEO(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='PROGRAM':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Program_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='4K_PROGRAM':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_4K_Program_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='ORI_PROGRAM':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Ori_Program_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='EPISODE':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Episode_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='MOVIE_SUB':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Movie_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='4K_MOVIE':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_4K_Movie_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='SEARCH_GROUP':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Search_Group(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC in['SEARCH','LOCAL_SEARCH']:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Search_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='WATCH':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Watch_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_History_Remove(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='ORDER_BY':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_setEpOrderby(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='SET_BOOKMARK':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Set_Bookmark(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC in['TOTAL_SEARCH','TOTAL_HISTORY']:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Global_Search(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='SEARCH_HISTORY':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Search_History(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='MENU_BOOKMARK':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Bookmark_Menu(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='EURO_GROUP':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_EuroLive_List(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='APPLE_GROUP':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Apple_Group(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  elif TDyGQtFLmhgvqsWeIEOazjdKJwuxYC=='BAND_VODLIST':
   TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.dp_Band_VodList(TDyGQtFLmhgvqsWeIEOazjdKJwuxVr.main_params)
  else:
   TDyGQtFLmhgvqsWeIEOazjdKJwuxoY
# Created by pyminifier (https://github.com/liftoff/pyminifier)
