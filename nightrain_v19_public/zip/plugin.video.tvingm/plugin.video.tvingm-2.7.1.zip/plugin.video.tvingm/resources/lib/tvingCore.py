__author__="NightRain"
GIvuqfgHAhaMrKxWJteSzPRCBQiVlT=print
GIvuqfgHAhaMrKxWJteSzPRCBQiVlU=ImportError
GIvuqfgHAhaMrKxWJteSzPRCBQiVls=object
GIvuqfgHAhaMrKxWJteSzPRCBQiVyn=None
GIvuqfgHAhaMrKxWJteSzPRCBQiVyb=False
GIvuqfgHAhaMrKxWJteSzPRCBQiVyk=str
GIvuqfgHAhaMrKxWJteSzPRCBQiVyd=open
GIvuqfgHAhaMrKxWJteSzPRCBQiVyX=True
GIvuqfgHAhaMrKxWJteSzPRCBQiVyN=len
GIvuqfgHAhaMrKxWJteSzPRCBQiVyD=int
GIvuqfgHAhaMrKxWJteSzPRCBQiVyl=range
GIvuqfgHAhaMrKxWJteSzPRCBQiVyj=bytes
GIvuqfgHAhaMrKxWJteSzPRCBQiVym=Exception
GIvuqfgHAhaMrKxWJteSzPRCBQiVyp=dict
GIvuqfgHAhaMrKxWJteSzPRCBQiVyF=list
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 GIvuqfgHAhaMrKxWJteSzPRCBQiVlT('Cryptodome')
except GIvuqfgHAhaMrKxWJteSzPRCBQiVlU:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 GIvuqfgHAhaMrKxWJteSzPRCBQiVlT('Crypto')
GIvuqfgHAhaMrKxWJteSzPRCBQiVnk={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
GIvuqfgHAhaMrKxWJteSzPRCBQiVnd ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
GIvuqfgHAhaMrKxWJteSzPRCBQiVnX =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
GIvuqfgHAhaMrKxWJteSzPRCBQiVnN=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class GIvuqfgHAhaMrKxWJteSzPRCBQiVnb(GIvuqfgHAhaMrKxWJteSzPRCBQiVls):
 def __init__(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.NETWORKCODE ='CSND0900'
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.OSCODE ='CSOD0900' 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TELECODE ='CSCD0900'
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.SCREENCODE ='CSSD0100'
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.SCREENCODE_ATV ='CSSD1300' 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.LIVE_LIMIT =20 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.VOD_LIMIT =24 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.EPISODE_LIMIT =30 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.SEARCH_LIMIT =30 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.MOVIE_LIMIT =24 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN ='https://api.tving.com'
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN ='https://image.tving.com'
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.SEARCH_DOMAIN ='https://search-api.tving.com'
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.LOGIN_DOMAIN ='https://user.tving.com'
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.URL_DOMAIN ='https://www.tving.com'
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.MOVIE_LITE =['2610061','2610161','261062']
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.MODEL ='chrome_128.0.0.0' 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.DEFAULT_HEADER ={'user-agent':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.USER_AGENT}
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.COOKIE_FILE_NAME =''
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV_SESSION_COOKIES1=''
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV_SESSION_COOKIES2=''
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV_STREAM_FILENAME =''
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV_SESSION_TEXT1 =''
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV_SESSION_TEXT2 =''
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.KodiVersion=20
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV ={}
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Init_TV_Total()
 def Init_TV_Total(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV={'account':{},'cookies':{},}
 def callRequestCookies(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,jobtype,GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,json=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,redirects=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnl=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.DEFAULT_HEADER
  if headers:GIvuqfgHAhaMrKxWJteSzPRCBQiVnl.update(headers)
  if jobtype=='Get':
   GIvuqfgHAhaMrKxWJteSzPRCBQiVny=requests.get(GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,params=params,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVnl,cookies=cookies,allow_redirects=redirects)
  else:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVny=requests.post(GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,data=payload,json=json,params=params,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVnl,cookies=cookies,allow_redirects=redirects)
  GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVny.status_code)+' - '+GIvuqfgHAhaMrKxWJteSzPRCBQiVny.url)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVny
 def JsonFile_Save(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,filename,GIvuqfgHAhaMrKxWJteSzPRCBQiVnj):
  if filename=='':return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  try:
   fp=GIvuqfgHAhaMrKxWJteSzPRCBQiVyd(filename,'w',-1,'utf-8')
   json.dump(GIvuqfgHAhaMrKxWJteSzPRCBQiVnj,fp,indent=4,ensure_ascii=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb)
   fp.close()
  except:
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
 def JsonFile_Load(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,filename):
  if filename=='':return{}
  try:
   fp=GIvuqfgHAhaMrKxWJteSzPRCBQiVyd(filename,'r',-1,'utf-8')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnp=json.load(fp)
   fp.close()
  except:
   return{}
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVnp
 def TextFile_Save(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,filename,resText):
  if filename=='':return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  try:
   fp=GIvuqfgHAhaMrKxWJteSzPRCBQiVyd(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
 def Save_session_acount(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,GIvuqfgHAhaMrKxWJteSzPRCBQiVnF,GIvuqfgHAhaMrKxWJteSzPRCBQiVnw,GIvuqfgHAhaMrKxWJteSzPRCBQiVnL,GIvuqfgHAhaMrKxWJteSzPRCBQiVnE):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['account']['tvid'] =base64.standard_b64encode(GIvuqfgHAhaMrKxWJteSzPRCBQiVnF.encode()).decode('utf-8')
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['account']['tvpw'] =base64.standard_b64encode(GIvuqfgHAhaMrKxWJteSzPRCBQiVnw.encode()).decode('utf-8')
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['account']['tvtype']=GIvuqfgHAhaMrKxWJteSzPRCBQiVnL 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['account']['tvpf'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVnE 
 def Load_session_acount(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD):
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnF =base64.standard_b64decode(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['account']['tvid']).decode('utf-8')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnw =base64.standard_b64decode(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['account']['tvpw']).decode('utf-8')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnL=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['account']['tvtype']
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnE =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVnF,GIvuqfgHAhaMrKxWJteSzPRCBQiVnw,GIvuqfgHAhaMrKxWJteSzPRCBQiVnL,GIvuqfgHAhaMrKxWJteSzPRCBQiVnE
 def make_stream_header(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,GIvuqfgHAhaMrKxWJteSzPRCBQiVnT,GIvuqfgHAhaMrKxWJteSzPRCBQiVns):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnO=''
  if GIvuqfgHAhaMrKxWJteSzPRCBQiVns not in[{},GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,'']:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVno=GIvuqfgHAhaMrKxWJteSzPRCBQiVyN(GIvuqfgHAhaMrKxWJteSzPRCBQiVns)
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVnc in GIvuqfgHAhaMrKxWJteSzPRCBQiVns.items():
    GIvuqfgHAhaMrKxWJteSzPRCBQiVnO+='{}={}'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVnc)
    GIvuqfgHAhaMrKxWJteSzPRCBQiVno+=-1
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVno>0:GIvuqfgHAhaMrKxWJteSzPRCBQiVnO+='; '
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnT['cookie']=GIvuqfgHAhaMrKxWJteSzPRCBQiVnO
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnU=''
  i=0
  for GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVnc in GIvuqfgHAhaMrKxWJteSzPRCBQiVnT.items():
   i=i+1
   if i>1:GIvuqfgHAhaMrKxWJteSzPRCBQiVnU+='&'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnU+='{}={}'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,urllib.parse.quote(GIvuqfgHAhaMrKxWJteSzPRCBQiVnc))
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVnU
 def makeDefaultCookies(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVns={}
  for GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVnc in GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies'].items():
   GIvuqfgHAhaMrKxWJteSzPRCBQiVns[GIvuqfgHAhaMrKxWJteSzPRCBQiVnY]=GIvuqfgHAhaMrKxWJteSzPRCBQiVnc
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVns
 def getDeviceStr(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbn=[]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbn.append('Windows') 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbn.append('Chrome') 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbn.append('ko-KR') 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbn.append('undefined') 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbn.append('24') 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbn.append(u'한국 표준시')
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbn.append('undefined') 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbn.append('undefined') 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbn.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbk=''
  for GIvuqfgHAhaMrKxWJteSzPRCBQiVbd in GIvuqfgHAhaMrKxWJteSzPRCBQiVbn:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbk+=GIvuqfgHAhaMrKxWJteSzPRCBQiVbd+'|'
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVbk
 def GetDefaultParams(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,uhd=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb):
  if uhd==GIvuqfgHAhaMrKxWJteSzPRCBQiVyb:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbX={'apiKey':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.APIKEY,'networkCode':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.NETWORKCODE,'osCode':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.OSCODE,'teleCode':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TELECODE,'screenCode':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.SCREENCODE,}
  else:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbX={'apiKey':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.APIKEY_ATV,'networkCode':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.NETWORKCODE,'osCode':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.OSCODE,'teleCode':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TELECODE,'screenCode':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.SCREENCODE_ATV,}
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVbX
 def GetNoCache(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,timetype=1):
  if timetype==1:
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(time.time())
  else:
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(time.time()*1000)
 def GetUniqueid(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,hValue=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn):
  if hValue:
   import hashlib
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbN=hashlib.sha1()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbN.update(hValue.encode())
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbD=GIvuqfgHAhaMrKxWJteSzPRCBQiVbN.hexdigest()[:8]
  else:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbl=[0 for i in GIvuqfgHAhaMrKxWJteSzPRCBQiVyl(256)]
   for i in GIvuqfgHAhaMrKxWJteSzPRCBQiVyl(256):
    GIvuqfgHAhaMrKxWJteSzPRCBQiVbl[i]='%02x'%(i)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVby=GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(4294967295*random.random())|0
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbD=GIvuqfgHAhaMrKxWJteSzPRCBQiVbl[255&GIvuqfgHAhaMrKxWJteSzPRCBQiVby]+GIvuqfgHAhaMrKxWJteSzPRCBQiVbl[GIvuqfgHAhaMrKxWJteSzPRCBQiVby>>8&255]+GIvuqfgHAhaMrKxWJteSzPRCBQiVbl[GIvuqfgHAhaMrKxWJteSzPRCBQiVby>>16&255]+GIvuqfgHAhaMrKxWJteSzPRCBQiVbl[GIvuqfgHAhaMrKxWJteSzPRCBQiVby>>24&255]
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVbD
 def Web_DecryptKey(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbj=GIvuqfgHAhaMrKxWJteSzPRCBQiVyj('kss2lym0kdw1lks3','utf-8')
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbm=GIvuqfgHAhaMrKxWJteSzPRCBQiVyj('6yhlJ4WF9ZIj6I8n','utf-8')
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVbj,GIvuqfgHAhaMrKxWJteSzPRCBQiVbm
 def Web_EncryptCiphertext(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,GIvuqfgHAhaMrKxWJteSzPRCBQiVbE):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbp,GIvuqfgHAhaMrKxWJteSzPRCBQiVbF=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Web_DecryptKey()
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbw=AES.new(GIvuqfgHAhaMrKxWJteSzPRCBQiVbp,AES.MODE_CBC,GIvuqfgHAhaMrKxWJteSzPRCBQiVbF,)
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbL=GIvuqfgHAhaMrKxWJteSzPRCBQiVbw.encrypt(Padding.pad(GIvuqfgHAhaMrKxWJteSzPRCBQiVbE.encode('utf-8'),16))
  return base64.standard_b64encode(GIvuqfgHAhaMrKxWJteSzPRCBQiVbL).decode('utf-8')
 def Web_DecryptPlaintext(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,GIvuqfgHAhaMrKxWJteSzPRCBQiVbL):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbp,GIvuqfgHAhaMrKxWJteSzPRCBQiVbF=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Web_DecryptKey()
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbw=AES.new(GIvuqfgHAhaMrKxWJteSzPRCBQiVbp,AES.MODE_CBC,GIvuqfgHAhaMrKxWJteSzPRCBQiVbF,)
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbE=Padding.unpad(GIvuqfgHAhaMrKxWJteSzPRCBQiVbw.decrypt(base64.standard_b64decode(GIvuqfgHAhaMrKxWJteSzPRCBQiVbL)),16)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVbE.decode('utf-8')
 def WebCookies_Load(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,wc_file):
  try:
   fp=GIvuqfgHAhaMrKxWJteSzPRCBQiVyd(wc_file,'r',-1,'utf-8')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbO=fp.read()
   fp.close()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbo=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Web_DecryptPlaintext(GIvuqfgHAhaMrKxWJteSzPRCBQiVbO)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbo)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbY =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDeviceList()
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVbY not in['','-']:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies']['tving_uuid']=GIvuqfgHAhaMrKxWJteSzPRCBQiVbY+'-'+GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetUniqueid(GIvuqfgHAhaMrKxWJteSzPRCBQiVbY)
  except:
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
 def GetCredential2(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,user_id,user_pw,login_type,user_pf):
  try:
   if base64.standard_b64encode(user_id.encode()).decode('utf-8')=='a3ltOTUxMDg4':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVbc='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx'
   else:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVbc='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbT={'addon':'tvingm','method':'LOGIN','data':{'type':login_type,'id':user_id,'pw':user_pw,'pf':user_pf,}}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbT=json.dumps(GIvuqfgHAhaMrKxWJteSzPRCBQiVbT,separators=(',',':'))
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbT=base64.standard_b64encode(GIvuqfgHAhaMrKxWJteSzPRCBQiVbT.encode()).decode('utf-8')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnT={'proxy-mini':GIvuqfgHAhaMrKxWJteSzPRCBQiVbT}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=requests.get(base64.standard_b64decode(GIvuqfgHAhaMrKxWJteSzPRCBQiVbc).decode('utf-8'),headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVnT)
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.status_code!=200:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Init_TV_Total()
    return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbs=base64.standard_b64decode(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text).decode('utf-8')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbs=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbs)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies']=GIvuqfgHAhaMrKxWJteSzPRCBQiVbs
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Init_TV_Total()
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
 def GetCredential(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,user_id,user_pw,login_type,user_pf):
  from curl_cffi import requests
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkn='chrome' 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkb=requests.Session()
  try:
   if login_type=='0':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkd='https://user.tving.com/pc/user/otherLogin.tving?loginType=10&from=pc&csite=&isAuto=false&rtUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   else:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkd='https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnT={'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language':'ko-KR,ko;q=0.9','cache-control':'no-cache','pragma':'no-cache','priority':'u=0, i','referer':'https://www.tving.com/',}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVkb.get(GIvuqfgHAhaMrKxWJteSzPRCBQiVkd,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVnT,impersonate=GIvuqfgHAhaMrKxWJteSzPRCBQiVkn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT('{} - {}'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.status_code,GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.url))
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVkX in GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.cookies.jar:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies'][GIvuqfgHAhaMrKxWJteSzPRCBQiVkX.name]=GIvuqfgHAhaMrKxWJteSzPRCBQiVkX.value
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Init_TV_Total()
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkN=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkD={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':GIvuqfgHAhaMrKxWJteSzPRCBQiVyb,'cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnT['referer']=GIvuqfgHAhaMrKxWJteSzPRCBQiVkd
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVkb.post(url=GIvuqfgHAhaMrKxWJteSzPRCBQiVkN,data=GIvuqfgHAhaMrKxWJteSzPRCBQiVkD,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVnT,impersonate=GIvuqfgHAhaMrKxWJteSzPRCBQiVkn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT('{} - {}'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.status_code,GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.url))
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVkX in GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.cookies.jar:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies'][GIvuqfgHAhaMrKxWJteSzPRCBQiVkX.name]=GIvuqfgHAhaMrKxWJteSzPRCBQiVkX.value
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Init_TV_Total()
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkl=[]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVky =''
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnT['referer']=GIvuqfgHAhaMrKxWJteSzPRCBQiVkN
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVkb.get(url=GIvuqfgHAhaMrKxWJteSzPRCBQiVkj,data=GIvuqfgHAhaMrKxWJteSzPRCBQiVkD,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVnT,impersonate=GIvuqfgHAhaMrKxWJteSzPRCBQiVkn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT('{} - {}'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.status_code,GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.url))
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVkX in GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.cookies.jar:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies'][GIvuqfgHAhaMrKxWJteSzPRCBQiVkX.name]=GIvuqfgHAhaMrKxWJteSzPRCBQiVkX.value
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkl =re.findall('data-profile-no="\d+"',GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   for i in GIvuqfgHAhaMrKxWJteSzPRCBQiVyl(GIvuqfgHAhaMrKxWJteSzPRCBQiVyN(GIvuqfgHAhaMrKxWJteSzPRCBQiVkl)):
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkm =GIvuqfgHAhaMrKxWJteSzPRCBQiVkl[i].replace('data-profile-no=','').replace('"','')
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkl[i]=GIvuqfgHAhaMrKxWJteSzPRCBQiVkm
   GIvuqfgHAhaMrKxWJteSzPRCBQiVky=GIvuqfgHAhaMrKxWJteSzPRCBQiVkl[user_pf]
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Init_TV_Total()
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkp ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnT['referer']=GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkD={'profileNo':GIvuqfgHAhaMrKxWJteSzPRCBQiVky}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVkb.post(url=GIvuqfgHAhaMrKxWJteSzPRCBQiVkp,data=GIvuqfgHAhaMrKxWJteSzPRCBQiVkD,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVnT,impersonate=GIvuqfgHAhaMrKxWJteSzPRCBQiVkn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT('{} - {}'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.status_code,GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.url))
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVkX in GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.cookies.jar:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies'][GIvuqfgHAhaMrKxWJteSzPRCBQiVkX.name]=GIvuqfgHAhaMrKxWJteSzPRCBQiVkX.value
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Init_TV_Total()
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbY =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDeviceList()
  if GIvuqfgHAhaMrKxWJteSzPRCBQiVbY not in['','-']:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies']['tving_uuid']=GIvuqfgHAhaMrKxWJteSzPRCBQiVbY+'-'+GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetUniqueid(GIvuqfgHAhaMrKxWJteSzPRCBQiVbY)
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.JsonFile_Save(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.COOKIE_FILE_NAME,GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
 def GetDeviceList(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkF=[]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkw='-'
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v1/user/device/list'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkL=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVns=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.makeDefaultCookies()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVkL,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVkE,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVns)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkF=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(GIvuqfgHAhaMrKxWJteSzPRCBQiVkF)
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVkF:
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVko['model'].lower().startswith('pc'):
     GIvuqfgHAhaMrKxWJteSzPRCBQiVkw=GIvuqfgHAhaMrKxWJteSzPRCBQiVko['uuid']
     break
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVkw=='-':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkw=GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetNoCache(timetype=1))
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVkw
 def Get_Now_Datetime(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,mediacode,sel_quality,stype,pvrmode='-',optUHD=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkc ={'streaming_url':'','subtitleYn':GIvuqfgHAhaMrKxWJteSzPRCBQiVyb,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'','watermark':'','watermarkKey':'','qt_stream':'',}
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkw =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies']['tving_uuid'].split('-')[0] 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkT =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies']['tving_uuid'] 
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkU=GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetNoCache(1))
   if stype!='tvingtv':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v2/media/stream/info'
    GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':GIvuqfgHAhaMrKxWJteSzPRCBQiVkT,'deviceInfo':'PC','noCache':GIvuqfgHAhaMrKxWJteSzPRCBQiVkU,}
    GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
    GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
    GIvuqfgHAhaMrKxWJteSzPRCBQiVns=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.makeDefaultCookies()
    GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVns)
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.status_code!=200:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['error_msg']='First Step - {} error'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.status_code)
     return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']['code']=='060':
     for GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVnc in GIvuqfgHAhaMrKxWJteSzPRCBQiVnk.items():
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVnc==sel_quality:
       GIvuqfgHAhaMrKxWJteSzPRCBQiVdn=GIvuqfgHAhaMrKxWJteSzPRCBQiVnY
    elif GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']['code']!='000':
     GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['error_msg']=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']['message']
     return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
    else: 
     if not('stream' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']):return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
     GIvuqfgHAhaMrKxWJteSzPRCBQiVdb=[]
     for GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVnc in GIvuqfgHAhaMrKxWJteSzPRCBQiVnk.items():
      for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['stream']['quality']:
       if GIvuqfgHAhaMrKxWJteSzPRCBQiVko['active']=='Y' and GIvuqfgHAhaMrKxWJteSzPRCBQiVko['code']==GIvuqfgHAhaMrKxWJteSzPRCBQiVnY:
        GIvuqfgHAhaMrKxWJteSzPRCBQiVdb.append({GIvuqfgHAhaMrKxWJteSzPRCBQiVnk.get(GIvuqfgHAhaMrKxWJteSzPRCBQiVko['code']):GIvuqfgHAhaMrKxWJteSzPRCBQiVko['code']})
     GIvuqfgHAhaMrKxWJteSzPRCBQiVdn=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.CheckQuality(sel_quality,GIvuqfgHAhaMrKxWJteSzPRCBQiVdb)
     try:
      if optUHD==GIvuqfgHAhaMrKxWJteSzPRCBQiVyX and GIvuqfgHAhaMrKxWJteSzPRCBQiVdn=='stream50' and 'stream_support_info' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['content']['info']:
       if GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['content']['info']['stream_support_info']!=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn:
        if 'stream70' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['content']['info']['stream_support_info']:
         GIvuqfgHAhaMrKxWJteSzPRCBQiVdn='stream70'
         GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['qt_stream']='stream70'
     except:
      pass
     try:
      if optUHD==GIvuqfgHAhaMrKxWJteSzPRCBQiVyX and GIvuqfgHAhaMrKxWJteSzPRCBQiVdn=='stream50' and 'stream' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['content']['info']:
       if GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['content']['info']['stream']!=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn:
        for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['content']['info']['stream']:
         if GIvuqfgHAhaMrKxWJteSzPRCBQiVko['code']=='stream70':
          GIvuqfgHAhaMrKxWJteSzPRCBQiVdn='stream70'
          break
     except:
      pass
   else:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVdn='stream40'
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['error_msg']='First Step - except error'
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['qt_stream']=GIvuqfgHAhaMrKxWJteSzPRCBQiVdn
  GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(GIvuqfgHAhaMrKxWJteSzPRCBQiVdn)
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkU=GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetNoCache(1))
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v3/media/stream/info'
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['qt_stream']=='stream70':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams(uhd=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX)
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'mediaCode':mediacode,'deviceId':GIvuqfgHAhaMrKxWJteSzPRCBQiVkw,'uuid':GIvuqfgHAhaMrKxWJteSzPRCBQiVkT,'deviceInfo':'PC_Chrome WebView','streamCode':GIvuqfgHAhaMrKxWJteSzPRCBQiVdn,'noCache':GIvuqfgHAhaMrKxWJteSzPRCBQiVkU,'callingFrom':'HTML5','model':'chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   else:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'mediaCode':mediacode,'deviceId':GIvuqfgHAhaMrKxWJteSzPRCBQiVkw,'uuid':GIvuqfgHAhaMrKxWJteSzPRCBQiVkT,'deviceInfo':'PC_Chrome','streamCode':GIvuqfgHAhaMrKxWJteSzPRCBQiVdn,'noCache':GIvuqfgHAhaMrKxWJteSzPRCBQiVkU,'callingFrom':'HTML5','model':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVns=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.makeDefaultCookies()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Post',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVns,redirects=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']['code']!='000':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['error_msg']=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']['message']
    return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
   GIvuqfgHAhaMrKxWJteSzPRCBQiVdk=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['stream']
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVdk['drm_yn']=='Y':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVdX=GIvuqfgHAhaMrKxWJteSzPRCBQiVdk['playback']['drm']['widevine']
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVdN in GIvuqfgHAhaMrKxWJteSzPRCBQiVdk['playback']['drm']['license']['drm_license_data']:
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVdN['drm_type']=='Widevine':
      GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['drm_server_url'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVdN['drm_server_url']
      GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['drm_header_key'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVdN['drm_header_key']
      GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['drm_header_value']=GIvuqfgHAhaMrKxWJteSzPRCBQiVdN['drm_header_value']
      break
   else:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVdX=GIvuqfgHAhaMrKxWJteSzPRCBQiVdk['playback']['non_drm']
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['error_msg']='Second Step - except error'
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdD=GIvuqfgHAhaMrKxWJteSzPRCBQiVkU
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdX=GIvuqfgHAhaMrKxWJteSzPRCBQiVdX.split('|')[1]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdX,GIvuqfgHAhaMrKxWJteSzPRCBQiVdl,GIvuqfgHAhaMrKxWJteSzPRCBQiVdy=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Decrypt_Url(GIvuqfgHAhaMrKxWJteSzPRCBQiVdX,mediacode,GIvuqfgHAhaMrKxWJteSzPRCBQiVdD)
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url']=GIvuqfgHAhaMrKxWJteSzPRCBQiVdX
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['watermark'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVdl
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['watermarkKey']=GIvuqfgHAhaMrKxWJteSzPRCBQiVdy
  if 'subtitles' in GIvuqfgHAhaMrKxWJteSzPRCBQiVdk:
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVdj in GIvuqfgHAhaMrKxWJteSzPRCBQiVdk.get('subtitles'):
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVdj.get('code')in['KO','KO_CC']:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['subtitleYn']=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
     break
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdm=urllib.parse.urlparse(GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url'])
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdp =GIvuqfgHAhaMrKxWJteSzPRCBQiVdm.path.strip('/').split('/')
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['url_filename']=GIvuqfgHAhaMrKxWJteSzPRCBQiVdp[GIvuqfgHAhaMrKxWJteSzPRCBQiVyN(GIvuqfgHAhaMrKxWJteSzPRCBQiVdp)-1]
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
 def Tving_Parse_mpd(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,stream_url,watermarkKey=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,watermark=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn):
  if watermarkKey not in['',GIvuqfgHAhaMrKxWJteSzPRCBQiVyn]:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnT={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=requests.get(url=stream_url,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVnT,allow_redirects=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb)
  else:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=requests.get(url=stream_url)
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdF=GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.content.decode('utf-8')
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdw=0
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdL =ET.ElementTree(ET.fromstring(GIvuqfgHAhaMrKxWJteSzPRCBQiVdF))
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdE =GIvuqfgHAhaMrKxWJteSzPRCBQiVdL.getroot()
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdO=re.match(r'\{.*\}',GIvuqfgHAhaMrKxWJteSzPRCBQiVdE.tag)[0] 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdo=GIvuqfgHAhaMrKxWJteSzPRCBQiVyp([node for _,node in ET.iterparse(io.StringIO(GIvuqfgHAhaMrKxWJteSzPRCBQiVdF),events=['start-ns'])])
  for GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVXp in GIvuqfgHAhaMrKxWJteSzPRCBQiVdo.items():
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVnY!='ns2':
    ET.register_namespace(GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVXp)
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdY=GIvuqfgHAhaMrKxWJteSzPRCBQiVdE.find(GIvuqfgHAhaMrKxWJteSzPRCBQiVdO+'Period')
  for GIvuqfgHAhaMrKxWJteSzPRCBQiVdc in GIvuqfgHAhaMrKxWJteSzPRCBQiVdY.findall(GIvuqfgHAhaMrKxWJteSzPRCBQiVdO+'AdaptationSet'):
   if(GIvuqfgHAhaMrKxWJteSzPRCBQiVdc.attrib.get('mimeType')=='video/mp4' or GIvuqfgHAhaMrKxWJteSzPRCBQiVdc.attrib.get('contentType')=='video'):
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVdT in GIvuqfgHAhaMrKxWJteSzPRCBQiVdc.findall(GIvuqfgHAhaMrKxWJteSzPRCBQiVdO+'Representation'):
     GIvuqfgHAhaMrKxWJteSzPRCBQiVdU=GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(GIvuqfgHAhaMrKxWJteSzPRCBQiVdT.attrib.get('bandwidth'))
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVdw<GIvuqfgHAhaMrKxWJteSzPRCBQiVdU:GIvuqfgHAhaMrKxWJteSzPRCBQiVdw=GIvuqfgHAhaMrKxWJteSzPRCBQiVdU
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVdT in GIvuqfgHAhaMrKxWJteSzPRCBQiVdc.findall(GIvuqfgHAhaMrKxWJteSzPRCBQiVdO+'Representation'):
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVdw>GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(GIvuqfgHAhaMrKxWJteSzPRCBQiVdT.attrib.get('bandwidth')):
      GIvuqfgHAhaMrKxWJteSzPRCBQiVdc.remove(GIvuqfgHAhaMrKxWJteSzPRCBQiVdT)
   else:
    continue
  GIvuqfgHAhaMrKxWJteSzPRCBQiVds=ET.tostring(GIvuqfgHAhaMrKxWJteSzPRCBQiVdE).decode('utf-8')
  GIvuqfgHAhaMrKxWJteSzPRCBQiVXn='<?xml version="1.0" encoding="UTF-8"?>\n'
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TextFile_Save(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV_STREAM_FILENAME,GIvuqfgHAhaMrKxWJteSzPRCBQiVXn+GIvuqfgHAhaMrKxWJteSzPRCBQiVds)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
 def Tving_Parse_m3u8(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,stream_url):
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=requests.get(url=stream_url,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,stream=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXb=GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.content.decode('utf-8')
   if '#EXTM3U' not in GIvuqfgHAhaMrKxWJteSzPRCBQiVXb:
    return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
   if '#EXT-X-STREAM-INF' not in GIvuqfgHAhaMrKxWJteSzPRCBQiVXb: 
    return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXk=0
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVXd in GIvuqfgHAhaMrKxWJteSzPRCBQiVXb.splitlines():
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVXd.startswith('#EXT-X-STREAM-INF'):
     GIvuqfgHAhaMrKxWJteSzPRCBQiVXN=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.MediaLine_Parse(GIvuqfgHAhaMrKxWJteSzPRCBQiVXd,'#EXT-X-STREAM-INF')
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVXk<GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(GIvuqfgHAhaMrKxWJteSzPRCBQiVXN.get('BANDWIDTH')):
      GIvuqfgHAhaMrKxWJteSzPRCBQiVXk=GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(GIvuqfgHAhaMrKxWJteSzPRCBQiVXN.get('BANDWIDTH'))
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXD=[]
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXl=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVXd in GIvuqfgHAhaMrKxWJteSzPRCBQiVXb.splitlines():
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVXl==GIvuqfgHAhaMrKxWJteSzPRCBQiVyX:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVXl=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
     continue
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVXd.startswith('#EXT-X-STREAM-INF'):
     GIvuqfgHAhaMrKxWJteSzPRCBQiVXN=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.MediaLine_Parse(GIvuqfgHAhaMrKxWJteSzPRCBQiVXd,'#EXT-X-STREAM-INF')
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVXk!=GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(GIvuqfgHAhaMrKxWJteSzPRCBQiVXN.get('BANDWIDTH')):
      GIvuqfgHAhaMrKxWJteSzPRCBQiVXl=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
      continue
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXD.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVXd)
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  GIvuqfgHAhaMrKxWJteSzPRCBQiVXy='\n'.join(GIvuqfgHAhaMrKxWJteSzPRCBQiVXD)
  GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TextFile_Save(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV_STREAM_FILENAME,GIvuqfgHAhaMrKxWJteSzPRCBQiVXy)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
 def MediaLine_Parse(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,GIvuqfgHAhaMrKxWJteSzPRCBQiVXd,prefix):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVXN={}
  for GIvuqfgHAhaMrKxWJteSzPRCBQiVXj in GIvuqfgHAhaMrKxWJteSzPRCBQiVnX.split(GIvuqfgHAhaMrKxWJteSzPRCBQiVXd.replace(prefix+':',''))[1::2]:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXm,GIvuqfgHAhaMrKxWJteSzPRCBQiVXp=GIvuqfgHAhaMrKxWJteSzPRCBQiVXj.split('=',1)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXN[GIvuqfgHAhaMrKxWJteSzPRCBQiVXm.upper()]=GIvuqfgHAhaMrKxWJteSzPRCBQiVXp.replace('"','').strip()
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVXN
 def CheckQuality(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,sel_qt,GIvuqfgHAhaMrKxWJteSzPRCBQiVdb):
  for GIvuqfgHAhaMrKxWJteSzPRCBQiVXF in GIvuqfgHAhaMrKxWJteSzPRCBQiVdb:
   if sel_qt>=GIvuqfgHAhaMrKxWJteSzPRCBQiVyF(GIvuqfgHAhaMrKxWJteSzPRCBQiVXF)[0]:return GIvuqfgHAhaMrKxWJteSzPRCBQiVXF.get(GIvuqfgHAhaMrKxWJteSzPRCBQiVyF(GIvuqfgHAhaMrKxWJteSzPRCBQiVXF)[0])
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXw=GIvuqfgHAhaMrKxWJteSzPRCBQiVXF.get(GIvuqfgHAhaMrKxWJteSzPRCBQiVyF(GIvuqfgHAhaMrKxWJteSzPRCBQiVXF)[0])
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVXw
 def makeOocUrl(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,ooc_params):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=''
  for GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVnc in ooc_params.items():
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc+="%s=%s^"%(GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVnc)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVbc
 def GetLiveChannelList(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,stype,page_int):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkF=[]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v2/media/lives'
   if stype=='onair': 
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXE='CPCS0100,CPCS0400'
   else:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXE='CPCS0300'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'cacheType':'main','pageNo':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(page_int),'pageSize':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':GIvuqfgHAhaMrKxWJteSzPRCBQiVXE,}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if not('result' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']):return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXO=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVXO:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXo=GIvuqfgHAhaMrKxWJteSzPRCBQiVXT=GIvuqfgHAhaMrKxWJteSzPRCBQiVXU=''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXY=GIvuqfgHAhaMrKxWJteSzPRCBQiVNO=''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXc=GIvuqfgHAhaMrKxWJteSzPRCBQiVko['live_code']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXo =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['channel']['name']['ko']
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['episode']!=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVXT =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['program']['name']['ko']
     GIvuqfgHAhaMrKxWJteSzPRCBQiVXT =GIvuqfgHAhaMrKxWJteSzPRCBQiVXT+', '+GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['episode']['frequency'])+'회'
     GIvuqfgHAhaMrKxWJteSzPRCBQiVXU=GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['episode']['synopsis']['ko']
    else:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVXT =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['program']['name']['ko']
     GIvuqfgHAhaMrKxWJteSzPRCBQiVXU=GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['program']['synopsis']['ko']
    try: 
     GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =''
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =''
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=''
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNk =''
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNd =''
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNX =''
     for GIvuqfgHAhaMrKxWJteSzPRCBQiVND in GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['program']['image']:
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP0900':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
      elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP1800':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
      elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP2000':GIvuqfgHAhaMrKxWJteSzPRCBQiVNk =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
      elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP1900':GIvuqfgHAhaMrKxWJteSzPRCBQiVNd =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
      elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP0200':GIvuqfgHAhaMrKxWJteSzPRCBQiVNX =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
      elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP0500':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
      elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP0800':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVXs=='':
      for GIvuqfgHAhaMrKxWJteSzPRCBQiVND in GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['channel']['image']:
       if GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIC0400':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
       elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIC1400':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
       elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIC1900':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
    except:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVyn
    try:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNl =[]
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNy=[]
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNj =[]
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNm=''
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNp=''
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNF=''
     for GIvuqfgHAhaMrKxWJteSzPRCBQiVNw in GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('schedule').get('program').get('actor'):
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVNw!='' and GIvuqfgHAhaMrKxWJteSzPRCBQiVNw!=u'없음':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNw)
     for GIvuqfgHAhaMrKxWJteSzPRCBQiVNL in GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('schedule').get('program').get('director'):
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVNL!='' and GIvuqfgHAhaMrKxWJteSzPRCBQiVNL!='-' and GIvuqfgHAhaMrKxWJteSzPRCBQiVNL!=u'없음':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNL)
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('schedule').get('program').get('category1_name').get('ko')!='':
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNj.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['program']['category1_name']['ko'])
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('schedule').get('program').get('category2_name').get('ko')!='':
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNj.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['program']['category2_name']['ko'])
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('schedule').get('program').get('product_year'):GIvuqfgHAhaMrKxWJteSzPRCBQiVNm=GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['program']['product_year']
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('schedule').get('program').get('grade_code') :GIvuqfgHAhaMrKxWJteSzPRCBQiVNp= GIvuqfgHAhaMrKxWJteSzPRCBQiVnd.get(GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['program']['grade_code'])
     if 'broad_dt' in GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('schedule').get('program'):
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNE =GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('schedule').get('program').get('broad_dt')
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNF='%s-%s-%s'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[:4],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[4:6],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[6:])
    except:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVyn
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXY=GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['broadcast_start_time'])[8:12]
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNO =GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVko['schedule']['broadcast_end_time'])[8:12]
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNo={'channel':GIvuqfgHAhaMrKxWJteSzPRCBQiVXo,'title':GIvuqfgHAhaMrKxWJteSzPRCBQiVXT,'mediacode':GIvuqfgHAhaMrKxWJteSzPRCBQiVXc,'thumbnail':{'poster':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn,'thumb':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs,'clearlogo':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb,'icon':GIvuqfgHAhaMrKxWJteSzPRCBQiVNk,'fanart':GIvuqfgHAhaMrKxWJteSzPRCBQiVNX},'synopsis':GIvuqfgHAhaMrKxWJteSzPRCBQiVXU,'channelepg':' [%s:%s ~ %s:%s]'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVXY[0:2],GIvuqfgHAhaMrKxWJteSzPRCBQiVXY[2:],GIvuqfgHAhaMrKxWJteSzPRCBQiVNO[0:2],GIvuqfgHAhaMrKxWJteSzPRCBQiVNO[2:]),'cast':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl,'director':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy,'info_genre':GIvuqfgHAhaMrKxWJteSzPRCBQiVNj,'year':GIvuqfgHAhaMrKxWJteSzPRCBQiVNm,'mpaa':GIvuqfgHAhaMrKxWJteSzPRCBQiVNp,'premiered':GIvuqfgHAhaMrKxWJteSzPRCBQiVNF}
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkF.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNo)
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['has_more']=='Y':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
 def GetProgramList(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,genre,orderby,page_int,genreCode='all'):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkF=[]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v2/media/episodes'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'cacheType':'main','pageSize':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(page_int),}
   if genre not in['all','PARAMOUNT']:GIvuqfgHAhaMrKxWJteSzPRCBQiVkE['categoryCode']=genre
   if genreCode!='all' :GIvuqfgHAhaMrKxWJteSzPRCBQiVkE['genreCode'] =genreCode 
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if not('result' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']):return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXO=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVXO:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNY=GIvuqfgHAhaMrKxWJteSzPRCBQiVko['program']['code']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXT =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['program']['name']['ko']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNp =GIvuqfgHAhaMrKxWJteSzPRCBQiVnd.get(GIvuqfgHAhaMrKxWJteSzPRCBQiVko['program'].get('grade_code'))
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNk =''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNd =''
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVND in GIvuqfgHAhaMrKxWJteSzPRCBQiVko['program']['image']:
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP0900':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP0200':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP1800':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP2000':GIvuqfgHAhaMrKxWJteSzPRCBQiVNk =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP1900':GIvuqfgHAhaMrKxWJteSzPRCBQiVNd =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXU =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['program']['synopsis']['ko']
    try:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNc=GIvuqfgHAhaMrKxWJteSzPRCBQiVko['channel']['name']['ko']
    except:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNc=''
    try:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNl =[]
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNy=[]
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNj =[]
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNm =''
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNF=''
     for GIvuqfgHAhaMrKxWJteSzPRCBQiVNw in GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('program').get('actor'):
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVNw!='' and GIvuqfgHAhaMrKxWJteSzPRCBQiVNw!='-' and GIvuqfgHAhaMrKxWJteSzPRCBQiVNw!=u'없음':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNw)
     for GIvuqfgHAhaMrKxWJteSzPRCBQiVNL in GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('program').get('director'):
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVNL!='' and GIvuqfgHAhaMrKxWJteSzPRCBQiVNL!='-' and GIvuqfgHAhaMrKxWJteSzPRCBQiVNL!=u'없음':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNL)
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('program').get('category1_name').get('ko')!='':
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNj.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVko['program']['category1_name']['ko'])
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('program').get('category2_name').get('ko')!='':
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNj.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVko['program']['category2_name']['ko'])
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('program').get('product_year'):GIvuqfgHAhaMrKxWJteSzPRCBQiVNm=GIvuqfgHAhaMrKxWJteSzPRCBQiVko['program']['product_year']
     if 'broad_dt' in GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('program'):
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNE =GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('program').get('broad_dt')
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNF='%s-%s-%s'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[:4],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[4:6],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[6:])
    except:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVyn
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNo={'program':GIvuqfgHAhaMrKxWJteSzPRCBQiVNY,'title':GIvuqfgHAhaMrKxWJteSzPRCBQiVXT,'thumbnail':{'poster':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn,'thumb':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs,'clearlogo':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb,'icon':GIvuqfgHAhaMrKxWJteSzPRCBQiVNk,'banner':GIvuqfgHAhaMrKxWJteSzPRCBQiVNd,'fanart':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs},'synopsis':GIvuqfgHAhaMrKxWJteSzPRCBQiVXU,'channel':GIvuqfgHAhaMrKxWJteSzPRCBQiVNc,'cast':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl,'director':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy,'info_genre':GIvuqfgHAhaMrKxWJteSzPRCBQiVNj,'year':GIvuqfgHAhaMrKxWJteSzPRCBQiVNm,'premiered':GIvuqfgHAhaMrKxWJteSzPRCBQiVNF,'mpaa':GIvuqfgHAhaMrKxWJteSzPRCBQiVNp}
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkF.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNo)
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['has_more']=='Y':GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
 def Get_UHD_ProgramList(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,page_int):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkF=[]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v2/operator/highlights'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams(uhd=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(page_int),'pocType':'APP_X_TVING_4.0.0',}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if not('result' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']):return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXO=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVXO:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNT=GIvuqfgHAhaMrKxWJteSzPRCBQiVko['content']['program']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNU =GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['code']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXT =GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['name']['ko'].strip()
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNp =GIvuqfgHAhaMrKxWJteSzPRCBQiVnd.get(GIvuqfgHAhaMrKxWJteSzPRCBQiVNT.get('grade_code'))
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXU =GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['synopsis']['ko']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNc =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['content']['channel']['name']['ko']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNm =GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['product_year']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNk =''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNd =''
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVND in GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['image']:
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP0900':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP0200':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP1800':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP2000':GIvuqfgHAhaMrKxWJteSzPRCBQiVNk =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP1900':GIvuqfgHAhaMrKxWJteSzPRCBQiVNd =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNj =[]
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNl =[]
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNy=[]
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNF =''
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVNT.get('category1_name').get('ko')!='':
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNj.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['category1_name']['ko'])
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVNT.get('category2_name').get('ko')!='':
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNj.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['category2_name']['ko'])
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVNw in GIvuqfgHAhaMrKxWJteSzPRCBQiVNT.get('actor'):
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVNw!='' and GIvuqfgHAhaMrKxWJteSzPRCBQiVNw!='-' and GIvuqfgHAhaMrKxWJteSzPRCBQiVNw!=u'없음':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNw)
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVNL in GIvuqfgHAhaMrKxWJteSzPRCBQiVNT.get('director'):
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVNL!='' and GIvuqfgHAhaMrKxWJteSzPRCBQiVNL!='-' and GIvuqfgHAhaMrKxWJteSzPRCBQiVNL!=u'없음':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNL)
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVNT.get('broad_dt')not in[GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,'']:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNE =GIvuqfgHAhaMrKxWJteSzPRCBQiVNT.get('broad_dt')
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNF='%s-%s-%s'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[:4],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[4:6],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[6:])
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNo={'program':GIvuqfgHAhaMrKxWJteSzPRCBQiVNU,'title':GIvuqfgHAhaMrKxWJteSzPRCBQiVXT,'mpaa':GIvuqfgHAhaMrKxWJteSzPRCBQiVNp,'thumbnail':{'poster':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn,'thumb':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs,'clearlogo':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb,'icon':GIvuqfgHAhaMrKxWJteSzPRCBQiVNk,'banner':GIvuqfgHAhaMrKxWJteSzPRCBQiVNd,'fanart':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs},'channel':GIvuqfgHAhaMrKxWJteSzPRCBQiVNc,'synopsis':GIvuqfgHAhaMrKxWJteSzPRCBQiVXU,'year':GIvuqfgHAhaMrKxWJteSzPRCBQiVNm,'info_genre':GIvuqfgHAhaMrKxWJteSzPRCBQiVNj,'cast':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl,'director':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy,'premiered':GIvuqfgHAhaMrKxWJteSzPRCBQiVNF,}
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkF.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNo)
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
 def Get_Origianl_ProgramList(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,page_int):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkF=[]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v2/media/band/originals'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'pageSize':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(page_int),}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVNs=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.JsonFile_Save(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV_SESSION_COOKIES2,GIvuqfgHAhaMrKxWJteSzPRCBQiVNs)
   if not('contents' in GIvuqfgHAhaMrKxWJteSzPRCBQiVNs['body']):return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXO=GIvuqfgHAhaMrKxWJteSzPRCBQiVNs['body']['contents']
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVXO:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDn =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['vod_code']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXT =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['vod_name']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVko['image']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDb ='movie' if GIvuqfgHAhaMrKxWJteSzPRCBQiVDn.startswith('M')else 'vod'
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNo={'vod_code':GIvuqfgHAhaMrKxWJteSzPRCBQiVDn,'title':GIvuqfgHAhaMrKxWJteSzPRCBQiVXT,'thumbnail':{'poster':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn,'thumb':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn},'vod_type':GIvuqfgHAhaMrKxWJteSzPRCBQiVDb,}
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkF.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNo)
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVNs['body']['has_more']=='Y':GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
 def GetEpisodeList(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,program_code,page_int,orderby='desc'):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkF=[]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v2/media/frequency/program/'+program_code
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if not('result' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']):return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXO=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']
   GIvuqfgHAhaMrKxWJteSzPRCBQiVDk=GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['total_count'])
   GIvuqfgHAhaMrKxWJteSzPRCBQiVDd =GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(GIvuqfgHAhaMrKxWJteSzPRCBQiVDk//(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDX =(GIvuqfgHAhaMrKxWJteSzPRCBQiVDk-1)-((page_int-1)*GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.EPISODE_LIMIT)
   else:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDX =(page_int-1)*GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.EPISODE_LIMIT
   for i in GIvuqfgHAhaMrKxWJteSzPRCBQiVyl(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.EPISODE_LIMIT):
    if orderby=='desc':
     GIvuqfgHAhaMrKxWJteSzPRCBQiVDN=GIvuqfgHAhaMrKxWJteSzPRCBQiVDX-i
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVDN<0:break
    else:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVDN=GIvuqfgHAhaMrKxWJteSzPRCBQiVDX+i
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVDN>=GIvuqfgHAhaMrKxWJteSzPRCBQiVDk:break
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDl=GIvuqfgHAhaMrKxWJteSzPRCBQiVXO[GIvuqfgHAhaMrKxWJteSzPRCBQiVDN]['episode']['code']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXT =GIvuqfgHAhaMrKxWJteSzPRCBQiVXO[GIvuqfgHAhaMrKxWJteSzPRCBQiVDN]['vod_name']['ko']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDy =''
    try:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNE=GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVXO[GIvuqfgHAhaMrKxWJteSzPRCBQiVDN]['episode']['broadcast_date'])
     GIvuqfgHAhaMrKxWJteSzPRCBQiVDy='%s-%s-%s'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[:4],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[4:6],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[6:])
    except:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVyn
    try:
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVXO[GIvuqfgHAhaMrKxWJteSzPRCBQiVDN]['episode']['pip_cliptype']=='C012':
      GIvuqfgHAhaMrKxWJteSzPRCBQiVDy+=' - Quick VOD'
    except:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVyn
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXU =GIvuqfgHAhaMrKxWJteSzPRCBQiVXO[GIvuqfgHAhaMrKxWJteSzPRCBQiVDN]['episode']['synopsis']['ko']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNk =''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNd =''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNX =''
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVND in GIvuqfgHAhaMrKxWJteSzPRCBQiVXO[GIvuqfgHAhaMrKxWJteSzPRCBQiVDN]['program']['image']:
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP0900':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP1800':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP2000':GIvuqfgHAhaMrKxWJteSzPRCBQiVNk =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP1900':GIvuqfgHAhaMrKxWJteSzPRCBQiVNd =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIP0200':GIvuqfgHAhaMrKxWJteSzPRCBQiVNX =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVND in GIvuqfgHAhaMrKxWJteSzPRCBQiVXO[GIvuqfgHAhaMrKxWJteSzPRCBQiVDN]['episode']['image']:
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIE0400':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
    try:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVDj=GIvuqfgHAhaMrKxWJteSzPRCBQiVDp=GIvuqfgHAhaMrKxWJteSzPRCBQiVDF=''
     GIvuqfgHAhaMrKxWJteSzPRCBQiVDm=0
     GIvuqfgHAhaMrKxWJteSzPRCBQiVDj =GIvuqfgHAhaMrKxWJteSzPRCBQiVXO[GIvuqfgHAhaMrKxWJteSzPRCBQiVDN]['program']['name']['ko']
     GIvuqfgHAhaMrKxWJteSzPRCBQiVDp =GIvuqfgHAhaMrKxWJteSzPRCBQiVDy
     GIvuqfgHAhaMrKxWJteSzPRCBQiVDF =GIvuqfgHAhaMrKxWJteSzPRCBQiVXO[GIvuqfgHAhaMrKxWJteSzPRCBQiVDN]['channel']['name']['ko']
     if 'frequency' in GIvuqfgHAhaMrKxWJteSzPRCBQiVXO[GIvuqfgHAhaMrKxWJteSzPRCBQiVDN]['episode']:GIvuqfgHAhaMrKxWJteSzPRCBQiVDm=GIvuqfgHAhaMrKxWJteSzPRCBQiVXO[GIvuqfgHAhaMrKxWJteSzPRCBQiVDN]['episode']['frequency']
    except:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVyn
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNo={'episode':GIvuqfgHAhaMrKxWJteSzPRCBQiVDl,'title':GIvuqfgHAhaMrKxWJteSzPRCBQiVXT,'subtitle':GIvuqfgHAhaMrKxWJteSzPRCBQiVDy,'thumbnail':{'poster':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn,'thumb':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs,'clearlogo':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb,'icon':GIvuqfgHAhaMrKxWJteSzPRCBQiVNk,'banner':GIvuqfgHAhaMrKxWJteSzPRCBQiVNd,'fanart':GIvuqfgHAhaMrKxWJteSzPRCBQiVNX},'synopsis':GIvuqfgHAhaMrKxWJteSzPRCBQiVXU,'info_title':GIvuqfgHAhaMrKxWJteSzPRCBQiVDj,'aired':GIvuqfgHAhaMrKxWJteSzPRCBQiVDp,'studio':GIvuqfgHAhaMrKxWJteSzPRCBQiVDF,'frequency':GIvuqfgHAhaMrKxWJteSzPRCBQiVDm}
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkF.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNo)
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVDd>page_int:GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL,GIvuqfgHAhaMrKxWJteSzPRCBQiVDd
 def GetMovieList(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,genre,orderby,page_int):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkF=[]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v2/media/movies'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'pageSize':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:GIvuqfgHAhaMrKxWJteSzPRCBQiVkE['categoryCode']=genre
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE['productPackageCode']=','.join(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.MOVIE_LITE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if not('result' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']):return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXO=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVXO:
    if 'release_date' in GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('movie'):
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNm=GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('movie').get('release_date'))[:4]
    else:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNm=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDw =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['movie']['code']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXT =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['movie']['name']['ko'].strip()
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVNm not in[GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,'0','']:GIvuqfgHAhaMrKxWJteSzPRCBQiVXT+=u' (%s)'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVNm)
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNn=''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=''
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVND in GIvuqfgHAhaMrKxWJteSzPRCBQiVko['movie']['image']:
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIM2100':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIM0400':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIM1800':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXU =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['movie']['story']['ko']
    try:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVDj =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['movie']['name']['ko'].strip()
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNp =GIvuqfgHAhaMrKxWJteSzPRCBQiVnd.get(GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('grade_code'))
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNl=[]
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNy=[]
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNj=[]
     GIvuqfgHAhaMrKxWJteSzPRCBQiVDL=0
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNF=''
     GIvuqfgHAhaMrKxWJteSzPRCBQiVDF =''
     for GIvuqfgHAhaMrKxWJteSzPRCBQiVNw in GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('movie').get('actor'):
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVNw!='':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNw)
     for GIvuqfgHAhaMrKxWJteSzPRCBQiVNL in GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('movie').get('director'):
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVNL!='':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNL)
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('movie').get('category1_name').get('ko')!='':
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNj.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVko['movie']['category1_name']['ko'])
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('movie').get('category2_name').get('ko')!='':
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNj.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVko['movie']['category2_name']['ko'])
     if 'duration' in GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('movie'):GIvuqfgHAhaMrKxWJteSzPRCBQiVDL=GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('movie').get('duration')
     if 'release_date' in GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('movie'):
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNE=GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('movie').get('release_date'))
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVNE!='0':GIvuqfgHAhaMrKxWJteSzPRCBQiVNF='%s-%s-%s'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[:4],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[4:6],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[6:])
     if 'production' in GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('movie'):GIvuqfgHAhaMrKxWJteSzPRCBQiVDF=GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('movie').get('production')
    except:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVyn
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNo={'moviecode':GIvuqfgHAhaMrKxWJteSzPRCBQiVDw,'title':GIvuqfgHAhaMrKxWJteSzPRCBQiVXT,'thumbnail':{'poster':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn,'thumb':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs,'clearlogo':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb,'fanart':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs},'synopsis':GIvuqfgHAhaMrKxWJteSzPRCBQiVXU,'info_title':GIvuqfgHAhaMrKxWJteSzPRCBQiVDj,'year':GIvuqfgHAhaMrKxWJteSzPRCBQiVNm,'cast':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl,'director':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy,'info_genre':GIvuqfgHAhaMrKxWJteSzPRCBQiVNj,'duration':GIvuqfgHAhaMrKxWJteSzPRCBQiVDL,'premiered':GIvuqfgHAhaMrKxWJteSzPRCBQiVNF,'studio':GIvuqfgHAhaMrKxWJteSzPRCBQiVDF,'mpaa':GIvuqfgHAhaMrKxWJteSzPRCBQiVNp}
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDE=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVDO in GIvuqfgHAhaMrKxWJteSzPRCBQiVko['billing_package_id']:
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVDO in GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.MOVIE_LITE:
      GIvuqfgHAhaMrKxWJteSzPRCBQiVDE=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
      break
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVDE==GIvuqfgHAhaMrKxWJteSzPRCBQiVyb: 
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNo['title']=GIvuqfgHAhaMrKxWJteSzPRCBQiVNo['title']+' [개별구매]'
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkF.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNo)
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['has_more']=='Y':GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
 def Get_UHD_MovieList(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,page_int):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkF=[]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v2/operator/highlights'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams(uhd=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(page_int),'pocType':'APP_X_TVING_4.0.0',}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if not('result' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']):return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXO=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVXO:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNT=GIvuqfgHAhaMrKxWJteSzPRCBQiVko['content']['movie']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNU =GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['code']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXT =GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['name']['ko'].strip()
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDj =GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['name']['ko'].strip()
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNm =GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['product_year']
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVNm:GIvuqfgHAhaMrKxWJteSzPRCBQiVXT+=u' (%s)'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['product_year'])
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXU =GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['story']['ko']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDL =GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['duration']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNp =GIvuqfgHAhaMrKxWJteSzPRCBQiVnd.get(GIvuqfgHAhaMrKxWJteSzPRCBQiVNT.get('grade_code'))
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDF =GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['production']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNn=''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=''
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNj =[]
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNl =[]
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNy=[]
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNF =''
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVND in GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['image']:
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIM2100':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIM0400':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
     elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND['code']=='CAIM1800':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND['url']
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['release_date']not in[GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,0]:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNE=GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['release_date'])
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVNE!='0':GIvuqfgHAhaMrKxWJteSzPRCBQiVNF='%s-%s-%s'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[:4],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[4:6],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[6:])
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVNT.get('category1_name').get('ko')!='':
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNj.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['category1_name']['ko'])
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVNT.get('category2_name').get('ko')!='':
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNj.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNT['category2_name']['ko'])
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVNw in GIvuqfgHAhaMrKxWJteSzPRCBQiVNT.get('actor'):
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVNw!='':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNw)
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVNL in GIvuqfgHAhaMrKxWJteSzPRCBQiVNT.get('director'):
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVNL!='':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNL)
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNo={'moviecode':GIvuqfgHAhaMrKxWJteSzPRCBQiVNU,'title':GIvuqfgHAhaMrKxWJteSzPRCBQiVXT,'thumbnail':{'poster':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn,'thumb':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs,'clearlogo':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb,'fanart':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs},'year':GIvuqfgHAhaMrKxWJteSzPRCBQiVNm,'info_title':GIvuqfgHAhaMrKxWJteSzPRCBQiVDj,'synopsis':GIvuqfgHAhaMrKxWJteSzPRCBQiVXU,'mpaa':GIvuqfgHAhaMrKxWJteSzPRCBQiVNp,'duration':GIvuqfgHAhaMrKxWJteSzPRCBQiVDL,'premiered':GIvuqfgHAhaMrKxWJteSzPRCBQiVNF,'studio':GIvuqfgHAhaMrKxWJteSzPRCBQiVDF,'info_genre':GIvuqfgHAhaMrKxWJteSzPRCBQiVNj,'cast':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl,'director':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy,}
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkF.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNo)
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
 def GetMovieGenre(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkF=[]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v2/media/movie/curations'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if not('result' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']):return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXO=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVXO:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDo =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['curation_code']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDY =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['curation_name']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNo={'curation_code':GIvuqfgHAhaMrKxWJteSzPRCBQiVDo,'curation_name':GIvuqfgHAhaMrKxWJteSzPRCBQiVDY}
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkF.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNo)
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
 def GetSearchList(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,search_key,page_int,stype):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVDc=[]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyb
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/search/getSearch.jsp'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.SCREENCODE,'os':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.OSCODE,'network':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.APIKEY,'networkCode':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.NETWORKCODE,'osCode ':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.OSCODE,'teleCode ':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TELECODE,'screenCode ':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.SCREENCODE}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.SEARCH_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVkE,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if stype=='vod':
    if not('programRsb' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO):return GIvuqfgHAhaMrKxWJteSzPRCBQiVDc,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDT=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['programRsb']['dataList']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDU =GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['programRsb']['count'])
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVDT:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNY=GIvuqfgHAhaMrKxWJteSzPRCBQiVko['mast_cd']
     GIvuqfgHAhaMrKxWJteSzPRCBQiVXT =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['mast_nm']
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNn=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVko['web_url4']
     GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVko['web_url']
     try:
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNl =[]
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNy=[]
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNj =[]
      GIvuqfgHAhaMrKxWJteSzPRCBQiVDL =0
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNp =''
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNm =''
      GIvuqfgHAhaMrKxWJteSzPRCBQiVDp =''
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('actor') !='' and GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('actor') !='-':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl =GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('actor').split(',')
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('director')!='' and GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('director')!='-':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy=GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('director').split(',')
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('cate_nm')!='' and GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('cate_nm')!='-':GIvuqfgHAhaMrKxWJteSzPRCBQiVNj =GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('cate_nm').split('/')
      if 'targetage' in GIvuqfgHAhaMrKxWJteSzPRCBQiVko:GIvuqfgHAhaMrKxWJteSzPRCBQiVNp=GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('targetage')
      if 'broad_dt' in GIvuqfgHAhaMrKxWJteSzPRCBQiVko:
       GIvuqfgHAhaMrKxWJteSzPRCBQiVNE=GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('broad_dt')
       GIvuqfgHAhaMrKxWJteSzPRCBQiVDp='%s-%s-%s'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[:4],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[4:6],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[6:])
       GIvuqfgHAhaMrKxWJteSzPRCBQiVNm =GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[:4]
     except:
      GIvuqfgHAhaMrKxWJteSzPRCBQiVyn
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNo={'program':GIvuqfgHAhaMrKxWJteSzPRCBQiVNY,'title':GIvuqfgHAhaMrKxWJteSzPRCBQiVXT,'thumbnail':{'poster':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn,'thumb':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs,'fanart':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs},'synopsis':'','cast':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl,'director':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy,'info_genre':GIvuqfgHAhaMrKxWJteSzPRCBQiVNj,'duration':GIvuqfgHAhaMrKxWJteSzPRCBQiVDL,'mpaa':GIvuqfgHAhaMrKxWJteSzPRCBQiVNp,'year':GIvuqfgHAhaMrKxWJteSzPRCBQiVNm,'aired':GIvuqfgHAhaMrKxWJteSzPRCBQiVDp}
     GIvuqfgHAhaMrKxWJteSzPRCBQiVDc.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNo)
   else:
    if not('vodMVRsb' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO):return GIvuqfgHAhaMrKxWJteSzPRCBQiVDc,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDs=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['vodMVRsb']['dataList']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVDU =GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['vodMVRsb']['count'])
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVDs:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNY=GIvuqfgHAhaMrKxWJteSzPRCBQiVko['mast_cd']
     GIvuqfgHAhaMrKxWJteSzPRCBQiVXT =GIvuqfgHAhaMrKxWJteSzPRCBQiVko['mast_nm'].strip()
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVko['web_url']
     GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVNn
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=''
     try:
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNl =[]
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNy=[]
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNj =[]
      GIvuqfgHAhaMrKxWJteSzPRCBQiVDL =0
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNp =''
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNm =''
      GIvuqfgHAhaMrKxWJteSzPRCBQiVDp =''
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('actor') !='' and GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('actor') !='-':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl =GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('actor').split(',')
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('director')!='' and GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('director')!='-':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy=GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('director').split(',')
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('cate_nm')!='' and GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('cate_nm')!='-':GIvuqfgHAhaMrKxWJteSzPRCBQiVNj =GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('cate_nm').split('/')
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('runtime_sec')!='':GIvuqfgHAhaMrKxWJteSzPRCBQiVDL=GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('runtime_sec')
      if 'grade_nm' in GIvuqfgHAhaMrKxWJteSzPRCBQiVko:GIvuqfgHAhaMrKxWJteSzPRCBQiVNp=GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('grade_nm')
      GIvuqfgHAhaMrKxWJteSzPRCBQiVNE=GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('broad_dt')
      if data_str!='':
       GIvuqfgHAhaMrKxWJteSzPRCBQiVDp='%s-%s-%s'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[:4],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[4:6],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[6:])
       GIvuqfgHAhaMrKxWJteSzPRCBQiVNm =GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[:4]
     except:
      GIvuqfgHAhaMrKxWJteSzPRCBQiVyn
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNo={'movie':GIvuqfgHAhaMrKxWJteSzPRCBQiVNY,'title':GIvuqfgHAhaMrKxWJteSzPRCBQiVXT,'thumbnail':{'poster':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn,'thumb':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs,'fanart':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs,'clearlogo':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb},'synopsis':'','cast':GIvuqfgHAhaMrKxWJteSzPRCBQiVNl,'director':GIvuqfgHAhaMrKxWJteSzPRCBQiVNy,'info_genre':GIvuqfgHAhaMrKxWJteSzPRCBQiVNj,'duration':GIvuqfgHAhaMrKxWJteSzPRCBQiVDL,'mpaa':GIvuqfgHAhaMrKxWJteSzPRCBQiVNp,'year':GIvuqfgHAhaMrKxWJteSzPRCBQiVNm,'aired':GIvuqfgHAhaMrKxWJteSzPRCBQiVDp}
     GIvuqfgHAhaMrKxWJteSzPRCBQiVDc.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNo)
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVDU>(page_int*GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.SEARCH_LIMIT):GIvuqfgHAhaMrKxWJteSzPRCBQiVXL=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVDc,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
 def GetBookmarkInfo(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,videoid,vidtype):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVln={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+'/v2/media/program/'+videoid
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'pageNo':'1','pageSize':'10','order':'name',}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVNs=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if not('body' in GIvuqfgHAhaMrKxWJteSzPRCBQiVNs):return{}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlb=GIvuqfgHAhaMrKxWJteSzPRCBQiVNs['body']
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXT=GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('name').get('ko').strip()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['title'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVXT
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['title']=GIvuqfgHAhaMrKxWJteSzPRCBQiVXT
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['mpaa'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVnd.get(GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('grade_code'))
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['plot'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('synopsis').get('ko')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['year'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('product_year')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['cast'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('actor')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['director']=GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('director')
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('category1_name').get('ko')!='':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['genre'].append(GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('category1_name').get('ko'))
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('category2_name').get('ko')!='':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['genre'].append(GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('category2_name').get('ko'))
   GIvuqfgHAhaMrKxWJteSzPRCBQiVNE=GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('broad_dt'))
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVNE!='0':GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[:4],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[4:6],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[6:])
   GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =''
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =''
   GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=''
   GIvuqfgHAhaMrKxWJteSzPRCBQiVNk =''
   GIvuqfgHAhaMrKxWJteSzPRCBQiVNd =''
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVND in GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('image'):
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('code')=='CAIP0900':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('url')
    elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('code')=='CAIP0200':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('url')
    elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('code')=='CAIP1800':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('url')
    elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('code')=='CAIP2000':GIvuqfgHAhaMrKxWJteSzPRCBQiVNk =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('url')
    elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('code')=='CAIP1900':GIvuqfgHAhaMrKxWJteSzPRCBQiVNd =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('url')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['thumbnail']['poster']=GIvuqfgHAhaMrKxWJteSzPRCBQiVNn
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['thumbnail']['thumb']=GIvuqfgHAhaMrKxWJteSzPRCBQiVXs
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['thumbnail']['clearlogo']=GIvuqfgHAhaMrKxWJteSzPRCBQiVNb
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['thumbnail']['icon']=GIvuqfgHAhaMrKxWJteSzPRCBQiVNk
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['thumbnail']['banner']=GIvuqfgHAhaMrKxWJteSzPRCBQiVNd
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['thumbnail']['fanart']=GIvuqfgHAhaMrKxWJteSzPRCBQiVXs
  else:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+'/v2a/media/stream/info'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies']['tving_uuid'].split('-')[0],'uuid':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetNoCache(1)),'wm':'Y',}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVNs=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if not('content' in GIvuqfgHAhaMrKxWJteSzPRCBQiVNs['body']):return{}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlb=GIvuqfgHAhaMrKxWJteSzPRCBQiVNs['body']['content']['info']['movie']
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXT =GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('name').get('ko').strip()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['title']=GIvuqfgHAhaMrKxWJteSzPRCBQiVXT
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXT +=u' (%s)'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('product_year'))
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['title'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVXT
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['mpaa'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVnd.get(GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('grade_code'))
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['plot'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('story').get('ko')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['year'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('product_year')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['studio'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('production')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['duration']=GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('duration')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['cast'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('actor')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['director']=GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('director')
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('category1_name').get('ko')!='':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['genre'].append(GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('category1_name').get('ko'))
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('category2_name').get('ko')!='':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['genre'].append(GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('category2_name').get('ko'))
   GIvuqfgHAhaMrKxWJteSzPRCBQiVNE=GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('release_date'))
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVNE!='0':GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[:4],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[4:6],GIvuqfgHAhaMrKxWJteSzPRCBQiVNE[6:])
   GIvuqfgHAhaMrKxWJteSzPRCBQiVNn=''
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =''
   GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=''
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVND in GIvuqfgHAhaMrKxWJteSzPRCBQiVlb.get('image'):
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('code')=='CAIM2100':GIvuqfgHAhaMrKxWJteSzPRCBQiVNn =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('url')
    elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('code')=='CAIM0400':GIvuqfgHAhaMrKxWJteSzPRCBQiVXs =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('url')
    elif GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('code')=='CAIM1800':GIvuqfgHAhaMrKxWJteSzPRCBQiVNb=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.IMG_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVND.get('url')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['thumbnail']['poster']=GIvuqfgHAhaMrKxWJteSzPRCBQiVNn
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['thumbnail']['thumb']=GIvuqfgHAhaMrKxWJteSzPRCBQiVNn 
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['thumbnail']['clearlogo']=GIvuqfgHAhaMrKxWJteSzPRCBQiVNb
   GIvuqfgHAhaMrKxWJteSzPRCBQiVln['saveinfo']['thumbnail']['fanart']=GIvuqfgHAhaMrKxWJteSzPRCBQiVXs
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVln
 def GetEuroChannelList(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkF=[]
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v2/operator/highlights'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetNoCache(2))}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if not('result' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']):return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF,GIvuqfgHAhaMrKxWJteSzPRCBQiVXL
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXO=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlk =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Get_Now_Datetime()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVld=GIvuqfgHAhaMrKxWJteSzPRCBQiVlk+datetime.timedelta(days=-1)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVld=GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(GIvuqfgHAhaMrKxWJteSzPRCBQiVld.strftime('%Y%m%d'))
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVXO:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVlX=GIvuqfgHAhaMrKxWJteSzPRCBQiVyD(GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('content').get('banner_title2')[:8])
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVld<=GIvuqfgHAhaMrKxWJteSzPRCBQiVlX:
     GIvuqfgHAhaMrKxWJteSzPRCBQiVNo={'channel':GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('content').get('banner_sub_title3'),'title':GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('content').get('banner_title'),'subtitle':GIvuqfgHAhaMrKxWJteSzPRCBQiVko.get('content').get('banner_sub_title2'),}
     GIvuqfgHAhaMrKxWJteSzPRCBQiVkF.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNo)
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVkF
 def Make_DecryptKey(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,step,mediacode='000',timecode='000'):
  if step=='1':
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbj=GIvuqfgHAhaMrKxWJteSzPRCBQiVyj('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbm=GIvuqfgHAhaMrKxWJteSzPRCBQiVyj('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbj=GIvuqfgHAhaMrKxWJteSzPRCBQiVyj('kss2lym0kdw1lks3','utf-8')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbm=GIvuqfgHAhaMrKxWJteSzPRCBQiVyj([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVbj,GIvuqfgHAhaMrKxWJteSzPRCBQiVbm
 def DecryptPlaintext(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,GIvuqfgHAhaMrKxWJteSzPRCBQiVbL,GIvuqfgHAhaMrKxWJteSzPRCBQiVbp,GIvuqfgHAhaMrKxWJteSzPRCBQiVbF):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbw=AES.new(GIvuqfgHAhaMrKxWJteSzPRCBQiVbp,AES.MODE_CBC,GIvuqfgHAhaMrKxWJteSzPRCBQiVbF,)
  GIvuqfgHAhaMrKxWJteSzPRCBQiVbE=Padding.unpad(GIvuqfgHAhaMrKxWJteSzPRCBQiVbw.decrypt(base64.standard_b64decode(GIvuqfgHAhaMrKxWJteSzPRCBQiVbL)),16)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVbE.decode('utf-8')
 def Decrypt_Url(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,GIvuqfgHAhaMrKxWJteSzPRCBQiVbL,mediacode,GIvuqfgHAhaMrKxWJteSzPRCBQiVdD):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVlN=''
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdl=''
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdy=''
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbj,GIvuqfgHAhaMrKxWJteSzPRCBQiVbm=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Make_DecryptKey('1',mediacode=mediacode,timecode=GIvuqfgHAhaMrKxWJteSzPRCBQiVdD)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlD=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.DecryptPlaintext(GIvuqfgHAhaMrKxWJteSzPRCBQiVbL,GIvuqfgHAhaMrKxWJteSzPRCBQiVbj,GIvuqfgHAhaMrKxWJteSzPRCBQiVbm))
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(GIvuqfgHAhaMrKxWJteSzPRCBQiVlD)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVly =GIvuqfgHAhaMrKxWJteSzPRCBQiVlD.get('url')
   GIvuqfgHAhaMrKxWJteSzPRCBQiVdl =GIvuqfgHAhaMrKxWJteSzPRCBQiVlD.get('watermark') if 'watermark' in GIvuqfgHAhaMrKxWJteSzPRCBQiVlD else ''
   GIvuqfgHAhaMrKxWJteSzPRCBQiVdy=GIvuqfgHAhaMrKxWJteSzPRCBQiVlD.get('watermark_key')if 'watermark_key' in GIvuqfgHAhaMrKxWJteSzPRCBQiVlD else ''
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbj,GIvuqfgHAhaMrKxWJteSzPRCBQiVbm=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Make_DecryptKey('2',mediacode=mediacode,timecode=GIvuqfgHAhaMrKxWJteSzPRCBQiVdD)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlN=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.DecryptPlaintext(GIvuqfgHAhaMrKxWJteSzPRCBQiVly,GIvuqfgHAhaMrKxWJteSzPRCBQiVbj,GIvuqfgHAhaMrKxWJteSzPRCBQiVbm)
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVlN,GIvuqfgHAhaMrKxWJteSzPRCBQiVdl,GIvuqfgHAhaMrKxWJteSzPRCBQiVdy
 def Get_Apple_buildId(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVlj=''
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc ='https://www.tving.com/more/special/SP0071'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlm=r'"buildId":"(.*?)"'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlj =re.compile(GIvuqfgHAhaMrKxWJteSzPRCBQiVlm,re.DOTALL).findall(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)[0]
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVlj
 def Get_AppleGroup_List(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVlp=[]
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlj=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Get_Apple_buildId()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/_next/data/{}/ko/more/special/SP0071.json'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVlj)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'key':'SP0071'}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.URL_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVkE,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVNs=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if not('pageProps' in GIvuqfgHAhaMrKxWJteSzPRCBQiVNs):return GIvuqfgHAhaMrKxWJteSzPRCBQiVlp
   GIvuqfgHAhaMrKxWJteSzPRCBQiVXO=GIvuqfgHAhaMrKxWJteSzPRCBQiVNs['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVlF in GIvuqfgHAhaMrKxWJteSzPRCBQiVXO:
    if GIvuqfgHAhaMrKxWJteSzPRCBQiVlF['bandType']not in['VOD_BASIC']:continue
    GIvuqfgHAhaMrKxWJteSzPRCBQiVlw =re.findall('/band/\w+|/curation/\w+',GIvuqfgHAhaMrKxWJteSzPRCBQiVlF['moreUrl'])[0]
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNo={'bandName':GIvuqfgHAhaMrKxWJteSzPRCBQiVlF['bandName'],'bandKey':GIvuqfgHAhaMrKxWJteSzPRCBQiVlw.split('/')[2],'moreUrl':GIvuqfgHAhaMrKxWJteSzPRCBQiVlw,}
    GIvuqfgHAhaMrKxWJteSzPRCBQiVlp.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNo)
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVlp
 def Get_Band_VodList(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,bandKey,GIvuqfgHAhaMrKxWJteSzPRCBQiVlw):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVlL=[]
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlj=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Get_Apple_buildId()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/_next/data/{}/ko/more{}.json'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVlj,GIvuqfgHAhaMrKxWJteSzPRCBQiVlw)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'key':bandKey}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.URL_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVkE,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVNs=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if not('pageProps' in GIvuqfgHAhaMrKxWJteSzPRCBQiVNs):return GIvuqfgHAhaMrKxWJteSzPRCBQiVlL
   if 'band' in GIvuqfgHAhaMrKxWJteSzPRCBQiVlw:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXO=GIvuqfgHAhaMrKxWJteSzPRCBQiVNs['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['band']['items']
   else:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVXO=GIvuqfgHAhaMrKxWJteSzPRCBQiVNs['pageProps']['dehydratedState']['queries'][0]['state']['data']['data']['bands'][0]['items']
   for GIvuqfgHAhaMrKxWJteSzPRCBQiVlF in GIvuqfgHAhaMrKxWJteSzPRCBQiVXO:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVlE=GIvuqfgHAhaMrKxWJteSzPRCBQiVlF['imageUrl']
    GIvuqfgHAhaMrKxWJteSzPRCBQiVNo={'program':GIvuqfgHAhaMrKxWJteSzPRCBQiVlF['code'],'title':GIvuqfgHAhaMrKxWJteSzPRCBQiVlF['title'],'thumbnail':{'poster':GIvuqfgHAhaMrKxWJteSzPRCBQiVlE,'thumb':GIvuqfgHAhaMrKxWJteSzPRCBQiVlE,'fanart':GIvuqfgHAhaMrKxWJteSzPRCBQiVlE},}
    GIvuqfgHAhaMrKxWJteSzPRCBQiVlL.append(GIvuqfgHAhaMrKxWJteSzPRCBQiVNo)
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVlL
 def GetLiveURL_Test(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD,mediacode,sel_quality):
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkc ={'streaming_url':'','subtitleYn':GIvuqfgHAhaMrKxWJteSzPRCBQiVyb,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkw =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies']['tving_uuid'].split('-')[0] 
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkT =GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.TV['cookies']['tving_uuid'] 
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkU=GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetNoCache(1))
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v2/media/stream/info' 
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':GIvuqfgHAhaMrKxWJteSzPRCBQiVkT,'deviceInfo':'PC','noCache':GIvuqfgHAhaMrKxWJteSzPRCBQiVkU,}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVns=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.makeDefaultCookies()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Get',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVns)
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.status_code!=200:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['error_msg']='First Step - {} error'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.status_code)
    return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']['code']=='060':
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVnc in GIvuqfgHAhaMrKxWJteSzPRCBQiVnk.items():
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVnc==sel_quality:
      GIvuqfgHAhaMrKxWJteSzPRCBQiVdn=GIvuqfgHAhaMrKxWJteSzPRCBQiVnY
   elif GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']['code']!='000':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['error_msg']=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']['message']
    return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
   else: 
    if not('stream' in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']):return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
    GIvuqfgHAhaMrKxWJteSzPRCBQiVdb=[]
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVnc in GIvuqfgHAhaMrKxWJteSzPRCBQiVnk.items():
     for GIvuqfgHAhaMrKxWJteSzPRCBQiVko in GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['stream']['quality']:
      if GIvuqfgHAhaMrKxWJteSzPRCBQiVko['active']=='Y' and GIvuqfgHAhaMrKxWJteSzPRCBQiVko['code']==GIvuqfgHAhaMrKxWJteSzPRCBQiVnY:
       GIvuqfgHAhaMrKxWJteSzPRCBQiVdb.append({GIvuqfgHAhaMrKxWJteSzPRCBQiVnk.get(GIvuqfgHAhaMrKxWJteSzPRCBQiVko['code']):GIvuqfgHAhaMrKxWJteSzPRCBQiVko['code']})
    GIvuqfgHAhaMrKxWJteSzPRCBQiVdn=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.CheckQuality(sel_quality,GIvuqfgHAhaMrKxWJteSzPRCBQiVdb)
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['error_msg']='First Step - except error'
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
  try:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkU=GIvuqfgHAhaMrKxWJteSzPRCBQiVyk(GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetNoCache(1))
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkj ='/v3/media/stream/info'
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.GetDefaultParams()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkE={'mediaCode':mediacode,'deviceId':GIvuqfgHAhaMrKxWJteSzPRCBQiVkw,'uuid':GIvuqfgHAhaMrKxWJteSzPRCBQiVkT,'deviceInfo':'PC_Chrome','streamCode':GIvuqfgHAhaMrKxWJteSzPRCBQiVdn,'noCache':GIvuqfgHAhaMrKxWJteSzPRCBQiVkU,'callingFrom':'HTML5','model':GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   GIvuqfgHAhaMrKxWJteSzPRCBQiVks.update(GIvuqfgHAhaMrKxWJteSzPRCBQiVkE)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbc=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.API_DOMAIN+GIvuqfgHAhaMrKxWJteSzPRCBQiVkj
   GIvuqfgHAhaMrKxWJteSzPRCBQiVns=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.makeDefaultCookies()
   GIvuqfgHAhaMrKxWJteSzPRCBQiVbU=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.callRequestCookies('Post',GIvuqfgHAhaMrKxWJteSzPRCBQiVbc,payload=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,params=GIvuqfgHAhaMrKxWJteSzPRCBQiVks,headers=GIvuqfgHAhaMrKxWJteSzPRCBQiVyn,cookies=GIvuqfgHAhaMrKxWJteSzPRCBQiVns,redirects=GIvuqfgHAhaMrKxWJteSzPRCBQiVyX)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkO=json.loads(GIvuqfgHAhaMrKxWJteSzPRCBQiVbU.text)
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']['code']!='000':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['error_msg']=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['result']['message']
    return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
   GIvuqfgHAhaMrKxWJteSzPRCBQiVdk=GIvuqfgHAhaMrKxWJteSzPRCBQiVkO['body']['stream']
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVdk['drm_yn']=='Y':
    GIvuqfgHAhaMrKxWJteSzPRCBQiVdX=GIvuqfgHAhaMrKxWJteSzPRCBQiVdk['playback']['drm']['widevine']
    for GIvuqfgHAhaMrKxWJteSzPRCBQiVdN in GIvuqfgHAhaMrKxWJteSzPRCBQiVdk['playback']['drm']['license']['drm_license_data']:
     if GIvuqfgHAhaMrKxWJteSzPRCBQiVdN['drm_type']=='Widevine':
      GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['drm_server_url'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVdN['drm_server_url']
      GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['drm_header_key'] =GIvuqfgHAhaMrKxWJteSzPRCBQiVdN['drm_header_key']
      GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['drm_header_value']=GIvuqfgHAhaMrKxWJteSzPRCBQiVdN['drm_header_value']
      break
   else:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVdX=GIvuqfgHAhaMrKxWJteSzPRCBQiVdk['playback']['non_drm']
  except GIvuqfgHAhaMrKxWJteSzPRCBQiVym as exception:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(exception)
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['error_msg']='Second Step - except error'
   return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdD=GIvuqfgHAhaMrKxWJteSzPRCBQiVkU
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdX=GIvuqfgHAhaMrKxWJteSzPRCBQiVdX.split('|')[1]
  GIvuqfgHAhaMrKxWJteSzPRCBQiVdX,GIvuqfgHAhaMrKxWJteSzPRCBQiVdl,GIvuqfgHAhaMrKxWJteSzPRCBQiVdy=GIvuqfgHAhaMrKxWJteSzPRCBQiVnD.Decrypt_Url(GIvuqfgHAhaMrKxWJteSzPRCBQiVdX,mediacode,GIvuqfgHAhaMrKxWJteSzPRCBQiVdD)
  GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url']=GIvuqfgHAhaMrKxWJteSzPRCBQiVdX
  GIvuqfgHAhaMrKxWJteSzPRCBQiVlO =GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url'].find('Policy=')
  if GIvuqfgHAhaMrKxWJteSzPRCBQiVlO!=-1:
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlo =GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url'].split('?')[0]
   GIvuqfgHAhaMrKxWJteSzPRCBQiVlY=GIvuqfgHAhaMrKxWJteSzPRCBQiVyp(urllib.parse.parse_qsl(urllib.parse.urlsplit(GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url']).query))
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url']='{}&CloudFront-Policy={}'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url'],GIvuqfgHAhaMrKxWJteSzPRCBQiVlY['Policy'])
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url']='{}&CloudFront-Signature={}'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url'],GIvuqfgHAhaMrKxWJteSzPRCBQiVlY['Signature'])
   GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url'],GIvuqfgHAhaMrKxWJteSzPRCBQiVlY['Key-Pair-Id'])
  GIvuqfgHAhaMrKxWJteSzPRCBQiVlc=['_tving_token','accessToken','authToken',]
  for GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVnc in GIvuqfgHAhaMrKxWJteSzPRCBQiVns.items():
   if GIvuqfgHAhaMrKxWJteSzPRCBQiVnY in GIvuqfgHAhaMrKxWJteSzPRCBQiVlc:
    GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url']='{}&{}={}'.format(GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url'],GIvuqfgHAhaMrKxWJteSzPRCBQiVnY,GIvuqfgHAhaMrKxWJteSzPRCBQiVnc)
  GIvuqfgHAhaMrKxWJteSzPRCBQiVlT(GIvuqfgHAhaMrKxWJteSzPRCBQiVkc['streaming_url'])
  return GIvuqfgHAhaMrKxWJteSzPRCBQiVkc
# Created by pyminifier (https://github.com/liftoff/pyminifier)
