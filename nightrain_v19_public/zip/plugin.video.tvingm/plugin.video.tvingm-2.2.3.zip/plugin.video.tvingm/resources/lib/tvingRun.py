__author__="NightRain"
BjytDAMovruKdFLcaCkfwQeIhWXYnP=object
BjytDAMovruKdFLcaCkfwQeIhWXYnz=None
BjytDAMovruKdFLcaCkfwQeIhWXYnO=int
BjytDAMovruKdFLcaCkfwQeIhWXYnb=False
BjytDAMovruKdFLcaCkfwQeIhWXYnR=True
BjytDAMovruKdFLcaCkfwQeIhWXYni=len
BjytDAMovruKdFLcaCkfwQeIhWXYnH=str
BjytDAMovruKdFLcaCkfwQeIhWXYnx=open
BjytDAMovruKdFLcaCkfwQeIhWXYnT=dict
BjytDAMovruKdFLcaCkfwQeIhWXYnl=Exception
BjytDAMovruKdFLcaCkfwQeIhWXYnN=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
BjytDAMovruKdFLcaCkfwQeIhWXYgp=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
BjytDAMovruKdFLcaCkfwQeIhWXYgP=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
BjytDAMovruKdFLcaCkfwQeIhWXYgz=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
BjytDAMovruKdFLcaCkfwQeIhWXYgn=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
BjytDAMovruKdFLcaCkfwQeIhWXYgO=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'PROGRAM','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
BjytDAMovruKdFLcaCkfwQeIhWXYgb=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
BjytDAMovruKdFLcaCkfwQeIhWXYgR={'C00551':'tvN','C00544':'중화TV','C00575':'Olive','C00579':'Mnet','C00590':'OGN','C01141':'XtvN','C01142':'ONSTYLE','C01143':'OtvN','C04601':'OCN Movies','C06941':'tooniverse','C07381':'OCN','C07382':'OCN Thrills','C15251':'OGN x LOL','C15252':'OGN x 오버워치','C15042':'티빙라이브','C01581':'TV CHOSUN','C01583':'채널A','C00708':'MBN','C00593':'YTN','C01101':'YTN Life','C15347':'YTN science','C01723':'연합뉴스TV','C15152':'CH.DIA','C01582':'JTBC','C00588':'JTBC Golf','C15741':'JTBC2','C00805':'JTBC3 FOX Sports','C05661':'디즈니채널','C18641':'IHQ','C22041':'JTBC4','C23343':'t.cast','C23441':'E channel','C17341':'히스토리','C00585':'TV CHOSUN2','C17141':'채널A 플러스','C00611':'LIFETIME','C08041':'tvN go','C05901':'채널W','C23442':"D'LIVE",'C27441':'KBS N','C15846':'SBS CNBC','C43241':'Nickelodeon','C43242':'SBS MTV','C43341':'SBS FiL','C43342':'KPOP','C17142':'MBN+'}
BjytDAMovruKdFLcaCkfwQeIhWXYgi=xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class BjytDAMovruKdFLcaCkfwQeIhWXYgU(BjytDAMovruKdFLcaCkfwQeIhWXYnP):
 def __init__(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYgx,BjytDAMovruKdFLcaCkfwQeIhWXYgT,BjytDAMovruKdFLcaCkfwQeIhWXYgl):
  BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_url =BjytDAMovruKdFLcaCkfwQeIhWXYgx
  BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_handle=BjytDAMovruKdFLcaCkfwQeIhWXYgT
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.main_params =BjytDAMovruKdFLcaCkfwQeIhWXYgl
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj =fyNVzJxHPFSboIgTdjaXrlpLiDuewm() 
 def addon_noti(BjytDAMovruKdFLcaCkfwQeIhWXYgH,sting):
  try:
   BjytDAMovruKdFLcaCkfwQeIhWXYgE=xbmcgui.Dialog()
   BjytDAMovruKdFLcaCkfwQeIhWXYgE.notification(__addonname__,sting)
  except:
   BjytDAMovruKdFLcaCkfwQeIhWXYnz
 def addon_log(BjytDAMovruKdFLcaCkfwQeIhWXYgH,string):
  try:
   BjytDAMovruKdFLcaCkfwQeIhWXYgG=string.encode('utf-8','ignore')
  except:
   BjytDAMovruKdFLcaCkfwQeIhWXYgG='addonException: addon_log'
  BjytDAMovruKdFLcaCkfwQeIhWXYgq=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,BjytDAMovruKdFLcaCkfwQeIhWXYgG),level=BjytDAMovruKdFLcaCkfwQeIhWXYgq)
 def get_keyboard_input(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYUb):
  BjytDAMovruKdFLcaCkfwQeIhWXYgV=BjytDAMovruKdFLcaCkfwQeIhWXYnz
  kb=xbmc.Keyboard()
  kb.setHeading(BjytDAMovruKdFLcaCkfwQeIhWXYUb)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   BjytDAMovruKdFLcaCkfwQeIhWXYgV=kb.getText()
  return BjytDAMovruKdFLcaCkfwQeIhWXYgV
 def get_settings_login_info(BjytDAMovruKdFLcaCkfwQeIhWXYgH):
  BjytDAMovruKdFLcaCkfwQeIhWXYgS =__addon__.getSetting('id')
  BjytDAMovruKdFLcaCkfwQeIhWXYgJ =__addon__.getSetting('pw')
  BjytDAMovruKdFLcaCkfwQeIhWXYgm =__addon__.getSetting('login_type')
  BjytDAMovruKdFLcaCkfwQeIhWXYgs=BjytDAMovruKdFLcaCkfwQeIhWXYnO(__addon__.getSetting('selected_profile'))
  return(BjytDAMovruKdFLcaCkfwQeIhWXYgS,BjytDAMovruKdFLcaCkfwQeIhWXYgJ,BjytDAMovruKdFLcaCkfwQeIhWXYgm,BjytDAMovruKdFLcaCkfwQeIhWXYgs)
 def get_settings_premiumyn(BjytDAMovruKdFLcaCkfwQeIhWXYgH):
  BjytDAMovruKdFLcaCkfwQeIhWXYUg =__addon__.getSetting('premium_movieyn')
  if BjytDAMovruKdFLcaCkfwQeIhWXYUg=='false':
   return BjytDAMovruKdFLcaCkfwQeIhWXYnb
  else:
   return BjytDAMovruKdFLcaCkfwQeIhWXYnR
 def get_settings_direct_replay(BjytDAMovruKdFLcaCkfwQeIhWXYgH):
  BjytDAMovruKdFLcaCkfwQeIhWXYUp=BjytDAMovruKdFLcaCkfwQeIhWXYnO(__addon__.getSetting('direct_replay'))
  if BjytDAMovruKdFLcaCkfwQeIhWXYUp==0:
   return BjytDAMovruKdFLcaCkfwQeIhWXYnb
  else:
   return BjytDAMovruKdFLcaCkfwQeIhWXYnR
 def get_settings_thumbnail_landyn(BjytDAMovruKdFLcaCkfwQeIhWXYgH):
  BjytDAMovruKdFLcaCkfwQeIhWXYUP =BjytDAMovruKdFLcaCkfwQeIhWXYnO(__addon__.getSetting('thumbnail_way'))
  if BjytDAMovruKdFLcaCkfwQeIhWXYUP==0:
   return BjytDAMovruKdFLcaCkfwQeIhWXYnR
  else:
   return BjytDAMovruKdFLcaCkfwQeIhWXYnb
 def set_winCredential(BjytDAMovruKdFLcaCkfwQeIhWXYgH,credential):
  BjytDAMovruKdFLcaCkfwQeIhWXYUz=xbmcgui.Window(10000)
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_LOGINTIME',BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(BjytDAMovruKdFLcaCkfwQeIhWXYgH):
  BjytDAMovruKdFLcaCkfwQeIhWXYUz=xbmcgui.Window(10000)
  BjytDAMovruKdFLcaCkfwQeIhWXYUn={'tving_token':BjytDAMovruKdFLcaCkfwQeIhWXYUz.getProperty('TVING_M_TOKEN'),'poc_userinfo':BjytDAMovruKdFLcaCkfwQeIhWXYUz.getProperty('TVING_M_USERINFO'),'tving_uuid':BjytDAMovruKdFLcaCkfwQeIhWXYUz.getProperty('TVING_M_UUID'),'tving_maintoken':BjytDAMovruKdFLcaCkfwQeIhWXYUz.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':BjytDAMovruKdFLcaCkfwQeIhWXYUz.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':BjytDAMovruKdFLcaCkfwQeIhWXYUz.getProperty('TVING_M_LOCKKEY')}
  return BjytDAMovruKdFLcaCkfwQeIhWXYUn
 def set_winEpisodeOrderby(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpG):
  BjytDAMovruKdFLcaCkfwQeIhWXYUz=xbmcgui.Window(10000)
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_ORDERBY',BjytDAMovruKdFLcaCkfwQeIhWXYpG)
 def get_winEpisodeOrderby(BjytDAMovruKdFLcaCkfwQeIhWXYgH):
  BjytDAMovruKdFLcaCkfwQeIhWXYUz=xbmcgui.Window(10000)
  return BjytDAMovruKdFLcaCkfwQeIhWXYUz.getProperty('TVING_M_ORDERBY')
 def add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYgH,label,sublabel='',img='',infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYnz,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnR,params=''):
  BjytDAMovruKdFLcaCkfwQeIhWXYUO='%s?%s'%(BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_url,urllib.parse.urlencode(params))
  if sublabel:BjytDAMovruKdFLcaCkfwQeIhWXYUb='%s < %s >'%(label,sublabel)
  else: BjytDAMovruKdFLcaCkfwQeIhWXYUb=label
  if not img:img='DefaultFolder.png'
  BjytDAMovruKdFLcaCkfwQeIhWXYUR=xbmcgui.ListItem(BjytDAMovruKdFLcaCkfwQeIhWXYUb)
  BjytDAMovruKdFLcaCkfwQeIhWXYUR.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:BjytDAMovruKdFLcaCkfwQeIhWXYUR.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:BjytDAMovruKdFLcaCkfwQeIhWXYUR.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_handle,BjytDAMovruKdFLcaCkfwQeIhWXYUO,BjytDAMovruKdFLcaCkfwQeIhWXYUR,isFolder)
 def get_selQuality(BjytDAMovruKdFLcaCkfwQeIhWXYgH,etype):
  try:
   BjytDAMovruKdFLcaCkfwQeIhWXYUi='selected_quality'
   BjytDAMovruKdFLcaCkfwQeIhWXYUH=[1080,720,480,360]
   BjytDAMovruKdFLcaCkfwQeIhWXYUx=BjytDAMovruKdFLcaCkfwQeIhWXYnO(__addon__.getSetting(BjytDAMovruKdFLcaCkfwQeIhWXYUi))
   return BjytDAMovruKdFLcaCkfwQeIhWXYUH[BjytDAMovruKdFLcaCkfwQeIhWXYUx]
  except:
   BjytDAMovruKdFLcaCkfwQeIhWXYnz
  return 720 
 def dp_Main_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH):
  for BjytDAMovruKdFLcaCkfwQeIhWXYUT in BjytDAMovruKdFLcaCkfwQeIhWXYgp:
   BjytDAMovruKdFLcaCkfwQeIhWXYUb=BjytDAMovruKdFLcaCkfwQeIhWXYUT.get('title')
   BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':BjytDAMovruKdFLcaCkfwQeIhWXYUT.get('mode'),'stype':BjytDAMovruKdFLcaCkfwQeIhWXYUT.get('stype'),'orderby':BjytDAMovruKdFLcaCkfwQeIhWXYUT.get('orderby'),'ordernm':BjytDAMovruKdFLcaCkfwQeIhWXYUT.get('ordernm'),'page':'1'}
   if BjytDAMovruKdFLcaCkfwQeIhWXYUT.get('mode')=='XXX':
    BjytDAMovruKdFLcaCkfwQeIhWXYUl['mode']='XXX'
    BjytDAMovruKdFLcaCkfwQeIhWXYUN=BjytDAMovruKdFLcaCkfwQeIhWXYnb
   else:
    BjytDAMovruKdFLcaCkfwQeIhWXYUN=BjytDAMovruKdFLcaCkfwQeIhWXYnR
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel='',img='',infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYnz,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYUN,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYni(BjytDAMovruKdFLcaCkfwQeIhWXYgp)>0:xbmcplugin.endOfDirectory(BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_handle)
 def login_main(BjytDAMovruKdFLcaCkfwQeIhWXYgH):
  (BjytDAMovruKdFLcaCkfwQeIhWXYUG,BjytDAMovruKdFLcaCkfwQeIhWXYUq,BjytDAMovruKdFLcaCkfwQeIhWXYUV,BjytDAMovruKdFLcaCkfwQeIhWXYUS)=BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_settings_login_info()
  if not(BjytDAMovruKdFLcaCkfwQeIhWXYUG and BjytDAMovruKdFLcaCkfwQeIhWXYUq):
   BjytDAMovruKdFLcaCkfwQeIhWXYgE=xbmcgui.Dialog()
   BjytDAMovruKdFLcaCkfwQeIhWXYUJ=BjytDAMovruKdFLcaCkfwQeIhWXYgE.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if BjytDAMovruKdFLcaCkfwQeIhWXYUJ==BjytDAMovruKdFLcaCkfwQeIhWXYnR:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_winEpisodeOrderby()=='':
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.set_winEpisodeOrderby('desc')
  if BjytDAMovruKdFLcaCkfwQeIhWXYgH.cookiefile_check():return
  BjytDAMovruKdFLcaCkfwQeIhWXYUm =BjytDAMovruKdFLcaCkfwQeIhWXYnO(BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  BjytDAMovruKdFLcaCkfwQeIhWXYUs=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if BjytDAMovruKdFLcaCkfwQeIhWXYUs==BjytDAMovruKdFLcaCkfwQeIhWXYnz or BjytDAMovruKdFLcaCkfwQeIhWXYUs=='':
   BjytDAMovruKdFLcaCkfwQeIhWXYUs=BjytDAMovruKdFLcaCkfwQeIhWXYnO('19000101')
  else:
   BjytDAMovruKdFLcaCkfwQeIhWXYUs=BjytDAMovruKdFLcaCkfwQeIhWXYnO(re.sub('-','',BjytDAMovruKdFLcaCkfwQeIhWXYUs))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   BjytDAMovruKdFLcaCkfwQeIhWXYpg=0
   while BjytDAMovruKdFLcaCkfwQeIhWXYnR:
    BjytDAMovruKdFLcaCkfwQeIhWXYpg+=1
    time.sleep(0.05)
    if BjytDAMovruKdFLcaCkfwQeIhWXYUs>=BjytDAMovruKdFLcaCkfwQeIhWXYUm:return
    if BjytDAMovruKdFLcaCkfwQeIhWXYpg>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if BjytDAMovruKdFLcaCkfwQeIhWXYUs>=BjytDAMovruKdFLcaCkfwQeIhWXYUm:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.GetCredential(BjytDAMovruKdFLcaCkfwQeIhWXYUG,BjytDAMovruKdFLcaCkfwQeIhWXYUq,BjytDAMovruKdFLcaCkfwQeIhWXYUV,BjytDAMovruKdFLcaCkfwQeIhWXYUS):
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.set_winCredential(BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.LoadCredential())
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpn):
  BjytDAMovruKdFLcaCkfwQeIhWXYpU=BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('stype')
  if BjytDAMovruKdFLcaCkfwQeIhWXYpU=='live':
   BjytDAMovruKdFLcaCkfwQeIhWXYpP=BjytDAMovruKdFLcaCkfwQeIhWXYgP
  elif BjytDAMovruKdFLcaCkfwQeIhWXYpU=='vod':
   BjytDAMovruKdFLcaCkfwQeIhWXYpP=BjytDAMovruKdFLcaCkfwQeIhWXYgO
  else:
   BjytDAMovruKdFLcaCkfwQeIhWXYpP=BjytDAMovruKdFLcaCkfwQeIhWXYgb
  for BjytDAMovruKdFLcaCkfwQeIhWXYpz in BjytDAMovruKdFLcaCkfwQeIhWXYpP:
   BjytDAMovruKdFLcaCkfwQeIhWXYUb=BjytDAMovruKdFLcaCkfwQeIhWXYpz.get('title')
   if BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('ordernm')!='-':
    BjytDAMovruKdFLcaCkfwQeIhWXYUb+='  ('+BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('ordernm')+')'
   BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':BjytDAMovruKdFLcaCkfwQeIhWXYpz.get('mode'),'stype':BjytDAMovruKdFLcaCkfwQeIhWXYpz.get('stype'),'orderby':BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('orderby'),'page':'1'}
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel='',img='',infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYnz,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnR,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYni(BjytDAMovruKdFLcaCkfwQeIhWXYpP)>0:xbmcplugin.endOfDirectory(BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_handle)
 def dp_LiveChannel_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpn):
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.SaveCredential(BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_winCredential())
  BjytDAMovruKdFLcaCkfwQeIhWXYpU =BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('stype')
  BjytDAMovruKdFLcaCkfwQeIhWXYpO =BjytDAMovruKdFLcaCkfwQeIhWXYnO(BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('page'))
  BjytDAMovruKdFLcaCkfwQeIhWXYpb,BjytDAMovruKdFLcaCkfwQeIhWXYpR=BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.GetLiveChannelList(BjytDAMovruKdFLcaCkfwQeIhWXYpU,BjytDAMovruKdFLcaCkfwQeIhWXYpO)
  for BjytDAMovruKdFLcaCkfwQeIhWXYpi in BjytDAMovruKdFLcaCkfwQeIhWXYpb:
   BjytDAMovruKdFLcaCkfwQeIhWXYUb =BjytDAMovruKdFLcaCkfwQeIhWXYpi.get('title')
   BjytDAMovruKdFLcaCkfwQeIhWXYUE =BjytDAMovruKdFLcaCkfwQeIhWXYpi.get('channel')
   BjytDAMovruKdFLcaCkfwQeIhWXYpH =BjytDAMovruKdFLcaCkfwQeIhWXYpi.get('thumbnail')
   BjytDAMovruKdFLcaCkfwQeIhWXYpx =BjytDAMovruKdFLcaCkfwQeIhWXYpi.get('synopsis')
   BjytDAMovruKdFLcaCkfwQeIhWXYpT=BjytDAMovruKdFLcaCkfwQeIhWXYpi.get('channelepg')
   BjytDAMovruKdFLcaCkfwQeIhWXYpl=BjytDAMovruKdFLcaCkfwQeIhWXYpi.get('info')
   BjytDAMovruKdFLcaCkfwQeIhWXYpl['plot']='%s\n%s\n%s\n\n%s'%(BjytDAMovruKdFLcaCkfwQeIhWXYUE,BjytDAMovruKdFLcaCkfwQeIhWXYUb,BjytDAMovruKdFLcaCkfwQeIhWXYpT,BjytDAMovruKdFLcaCkfwQeIhWXYpx)
   BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':'LIVE','mediacode':BjytDAMovruKdFLcaCkfwQeIhWXYpi.get('mediacode'),'stype':BjytDAMovruKdFLcaCkfwQeIhWXYpU}
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUE,sublabel=BjytDAMovruKdFLcaCkfwQeIhWXYUb,img=BjytDAMovruKdFLcaCkfwQeIhWXYpH,infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYpl,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnb,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYpR:
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['mode']='CHANNEL' 
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['stype']=BjytDAMovruKdFLcaCkfwQeIhWXYpU 
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['page']=BjytDAMovruKdFLcaCkfwQeIhWXYnH(BjytDAMovruKdFLcaCkfwQeIhWXYpO+1)
   BjytDAMovruKdFLcaCkfwQeIhWXYUb='[B]%s >>[/B]'%'다음 페이지'
   BjytDAMovruKdFLcaCkfwQeIhWXYpN=BjytDAMovruKdFLcaCkfwQeIhWXYnH(BjytDAMovruKdFLcaCkfwQeIhWXYpO+1)
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel=BjytDAMovruKdFLcaCkfwQeIhWXYpN,img='',infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYnz,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnR,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYni(BjytDAMovruKdFLcaCkfwQeIhWXYpb)>0:xbmcplugin.endOfDirectory(BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_handle,cacheToDisc=BjytDAMovruKdFLcaCkfwQeIhWXYnb)
 def dp_Program_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpn):
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.SaveCredential(BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_winCredential())
  BjytDAMovruKdFLcaCkfwQeIhWXYpE =BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('stype')
  BjytDAMovruKdFLcaCkfwQeIhWXYpG =BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('orderby')
  BjytDAMovruKdFLcaCkfwQeIhWXYpO =BjytDAMovruKdFLcaCkfwQeIhWXYnO(BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('page'))
  BjytDAMovruKdFLcaCkfwQeIhWXYpq,BjytDAMovruKdFLcaCkfwQeIhWXYpR=BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.GetProgramList(BjytDAMovruKdFLcaCkfwQeIhWXYpE,BjytDAMovruKdFLcaCkfwQeIhWXYpG,BjytDAMovruKdFLcaCkfwQeIhWXYpO,landyn=BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_settings_thumbnail_landyn())
  for BjytDAMovruKdFLcaCkfwQeIhWXYpV in BjytDAMovruKdFLcaCkfwQeIhWXYpq:
   BjytDAMovruKdFLcaCkfwQeIhWXYUb =BjytDAMovruKdFLcaCkfwQeIhWXYpV.get('title')
   BjytDAMovruKdFLcaCkfwQeIhWXYpH=BjytDAMovruKdFLcaCkfwQeIhWXYpV.get('thumbnail')
   BjytDAMovruKdFLcaCkfwQeIhWXYpx =BjytDAMovruKdFLcaCkfwQeIhWXYpV.get('synopsis')
   BjytDAMovruKdFLcaCkfwQeIhWXYpS =BjytDAMovruKdFLcaCkfwQeIhWXYgR.get(BjytDAMovruKdFLcaCkfwQeIhWXYpV.get('channel'))
   BjytDAMovruKdFLcaCkfwQeIhWXYpl=BjytDAMovruKdFLcaCkfwQeIhWXYpV.get('info')
   BjytDAMovruKdFLcaCkfwQeIhWXYpl['studio']=BjytDAMovruKdFLcaCkfwQeIhWXYpS
   BjytDAMovruKdFLcaCkfwQeIhWXYpl['plot']='%s <%s>\n\n%s'%(BjytDAMovruKdFLcaCkfwQeIhWXYUb,BjytDAMovruKdFLcaCkfwQeIhWXYpS,BjytDAMovruKdFLcaCkfwQeIhWXYpx)
   BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':'EPISODE','programcode':BjytDAMovruKdFLcaCkfwQeIhWXYpV.get('program'),'page':'1'}
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel=BjytDAMovruKdFLcaCkfwQeIhWXYpS,img=BjytDAMovruKdFLcaCkfwQeIhWXYpH,infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYpl,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnR,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYpR:
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['mode'] ='PROGRAM' 
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['stype'] =BjytDAMovruKdFLcaCkfwQeIhWXYpE
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['orderby']=BjytDAMovruKdFLcaCkfwQeIhWXYpG
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['page'] =BjytDAMovruKdFLcaCkfwQeIhWXYnH(BjytDAMovruKdFLcaCkfwQeIhWXYpO+1)
   BjytDAMovruKdFLcaCkfwQeIhWXYUb='[B]%s >>[/B]'%'다음 페이지'
   BjytDAMovruKdFLcaCkfwQeIhWXYpN=BjytDAMovruKdFLcaCkfwQeIhWXYnH(BjytDAMovruKdFLcaCkfwQeIhWXYpO+1)
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel=BjytDAMovruKdFLcaCkfwQeIhWXYpN,img='',infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYnz,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnR,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYni(BjytDAMovruKdFLcaCkfwQeIhWXYpq)>0:xbmcplugin.endOfDirectory(BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_handle,cacheToDisc=BjytDAMovruKdFLcaCkfwQeIhWXYnb)
 def dp_Episode_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpn):
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.SaveCredential(BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_winCredential())
  BjytDAMovruKdFLcaCkfwQeIhWXYpJ=BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('programcode')
  BjytDAMovruKdFLcaCkfwQeIhWXYpO =BjytDAMovruKdFLcaCkfwQeIhWXYnO(BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('page'))
  BjytDAMovruKdFLcaCkfwQeIhWXYpm,BjytDAMovruKdFLcaCkfwQeIhWXYpR,BjytDAMovruKdFLcaCkfwQeIhWXYps=BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.GetEpisodoList(BjytDAMovruKdFLcaCkfwQeIhWXYpJ,BjytDAMovruKdFLcaCkfwQeIhWXYpO,orderby=BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_winEpisodeOrderby())
  for BjytDAMovruKdFLcaCkfwQeIhWXYPg in BjytDAMovruKdFLcaCkfwQeIhWXYpm:
   BjytDAMovruKdFLcaCkfwQeIhWXYUb =BjytDAMovruKdFLcaCkfwQeIhWXYPg.get('title')
   BjytDAMovruKdFLcaCkfwQeIhWXYpN =BjytDAMovruKdFLcaCkfwQeIhWXYPg.get('subtitle')
   BjytDAMovruKdFLcaCkfwQeIhWXYpH=BjytDAMovruKdFLcaCkfwQeIhWXYPg.get('thumbnail')
   BjytDAMovruKdFLcaCkfwQeIhWXYpx =BjytDAMovruKdFLcaCkfwQeIhWXYPg.get('synopsis')
   BjytDAMovruKdFLcaCkfwQeIhWXYpl=BjytDAMovruKdFLcaCkfwQeIhWXYPg.get('info')
   BjytDAMovruKdFLcaCkfwQeIhWXYpl['plot']='%s\n\n%s'%(BjytDAMovruKdFLcaCkfwQeIhWXYUb,BjytDAMovruKdFLcaCkfwQeIhWXYpx)
   BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':'VOD','mediacode':BjytDAMovruKdFLcaCkfwQeIhWXYPg.get('episode'),'stype':'vod','programcode':BjytDAMovruKdFLcaCkfwQeIhWXYpJ,'title':BjytDAMovruKdFLcaCkfwQeIhWXYUb,'thumbnail':BjytDAMovruKdFLcaCkfwQeIhWXYpH}
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel=BjytDAMovruKdFLcaCkfwQeIhWXYpN,img=BjytDAMovruKdFLcaCkfwQeIhWXYpH,infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYpl,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnb,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYpO==1:
   BjytDAMovruKdFLcaCkfwQeIhWXYpl={'plot':'정렬순서를 변경합니다.'}
   BjytDAMovruKdFLcaCkfwQeIhWXYUl={}
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['mode'] ='ORDER_BY' 
   if BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_winEpisodeOrderby()=='desc':
    BjytDAMovruKdFLcaCkfwQeIhWXYUb='정렬순서변경 : 최신화부터 -> 1회부터'
    BjytDAMovruKdFLcaCkfwQeIhWXYUl['orderby']='asc'
   else:
    BjytDAMovruKdFLcaCkfwQeIhWXYUb='정렬순서변경 : 1회부터 -> 최신화부터'
    BjytDAMovruKdFLcaCkfwQeIhWXYUl['orderby']='desc'
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel='',img='',infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYpl,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnb,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYpR:
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['mode'] ='EPISODE' 
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['programcode']=BjytDAMovruKdFLcaCkfwQeIhWXYpJ
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['page'] =BjytDAMovruKdFLcaCkfwQeIhWXYnH(BjytDAMovruKdFLcaCkfwQeIhWXYpO+1)
   BjytDAMovruKdFLcaCkfwQeIhWXYUb='[B]%s >>[/B]'%'다음 페이지'
   BjytDAMovruKdFLcaCkfwQeIhWXYpN=BjytDAMovruKdFLcaCkfwQeIhWXYnH(BjytDAMovruKdFLcaCkfwQeIhWXYpO+1)
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel=BjytDAMovruKdFLcaCkfwQeIhWXYpN,img='',infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYnz,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnR,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYni(BjytDAMovruKdFLcaCkfwQeIhWXYpm)>0:xbmcplugin.endOfDirectory(BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_handle,cacheToDisc=BjytDAMovruKdFLcaCkfwQeIhWXYnR)
 def dp_setEpOrderby(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpn):
  BjytDAMovruKdFLcaCkfwQeIhWXYpG =BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('orderby')
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.set_winEpisodeOrderby(BjytDAMovruKdFLcaCkfwQeIhWXYpG)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpn):
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.SaveCredential(BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_winCredential())
  BjytDAMovruKdFLcaCkfwQeIhWXYpE =BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('stype')
  BjytDAMovruKdFLcaCkfwQeIhWXYpG =BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('orderby')
  BjytDAMovruKdFLcaCkfwQeIhWXYpO=BjytDAMovruKdFLcaCkfwQeIhWXYnO(BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('page'))
  BjytDAMovruKdFLcaCkfwQeIhWXYPU,BjytDAMovruKdFLcaCkfwQeIhWXYpR=BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.GetMovieList(BjytDAMovruKdFLcaCkfwQeIhWXYpE,BjytDAMovruKdFLcaCkfwQeIhWXYpG,BjytDAMovruKdFLcaCkfwQeIhWXYpO,landyn=BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_settings_thumbnail_landyn())
  for BjytDAMovruKdFLcaCkfwQeIhWXYPp in BjytDAMovruKdFLcaCkfwQeIhWXYPU:
   BjytDAMovruKdFLcaCkfwQeIhWXYUb =BjytDAMovruKdFLcaCkfwQeIhWXYPp.get('title')
   BjytDAMovruKdFLcaCkfwQeIhWXYpH=BjytDAMovruKdFLcaCkfwQeIhWXYPp.get('thumbnail')
   BjytDAMovruKdFLcaCkfwQeIhWXYpx =BjytDAMovruKdFLcaCkfwQeIhWXYPp.get('synopsis')
   BjytDAMovruKdFLcaCkfwQeIhWXYpl=BjytDAMovruKdFLcaCkfwQeIhWXYPp.get('info')
   BjytDAMovruKdFLcaCkfwQeIhWXYpl['plot']='%s\n\n%s'%(BjytDAMovruKdFLcaCkfwQeIhWXYUb,BjytDAMovruKdFLcaCkfwQeIhWXYpx)
   BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':'MOVIE','mediacode':BjytDAMovruKdFLcaCkfwQeIhWXYPp.get('moviecode'),'stype':'movie','title':BjytDAMovruKdFLcaCkfwQeIhWXYUb,'thumbnail':BjytDAMovruKdFLcaCkfwQeIhWXYpH}
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel='',img=BjytDAMovruKdFLcaCkfwQeIhWXYpH,infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYpl,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnb,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYpR:
   BjytDAMovruKdFLcaCkfwQeIhWXYUl={}
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['mode'] ='MOVIE_SUB' 
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['orderby']=BjytDAMovruKdFLcaCkfwQeIhWXYpG
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['stype'] =BjytDAMovruKdFLcaCkfwQeIhWXYpE
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['page'] =BjytDAMovruKdFLcaCkfwQeIhWXYnH(BjytDAMovruKdFLcaCkfwQeIhWXYpO+1)
   BjytDAMovruKdFLcaCkfwQeIhWXYUb='[B]%s >>[/B]'%'다음 페이지'
   BjytDAMovruKdFLcaCkfwQeIhWXYpN=BjytDAMovruKdFLcaCkfwQeIhWXYnH(BjytDAMovruKdFLcaCkfwQeIhWXYpO+1)
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel=BjytDAMovruKdFLcaCkfwQeIhWXYpN,img='',infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYnz,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnR,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYni(BjytDAMovruKdFLcaCkfwQeIhWXYPU)>0:xbmcplugin.endOfDirectory(BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_handle,cacheToDisc=BjytDAMovruKdFLcaCkfwQeIhWXYnb)
 def dp_Search_Group(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpn):
  for BjytDAMovruKdFLcaCkfwQeIhWXYpz in BjytDAMovruKdFLcaCkfwQeIhWXYgn:
   BjytDAMovruKdFLcaCkfwQeIhWXYUb=BjytDAMovruKdFLcaCkfwQeIhWXYpz.get('title')
   BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':BjytDAMovruKdFLcaCkfwQeIhWXYpz.get('mode'),'stype':BjytDAMovruKdFLcaCkfwQeIhWXYpz.get('stype'),'page':'1'}
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel='',img='',infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYnz,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnR,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYni(BjytDAMovruKdFLcaCkfwQeIhWXYgn)>0:xbmcplugin.endOfDirectory(BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_handle)
 def dp_Search_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpn):
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.SaveCredential(BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_winCredential())
  BjytDAMovruKdFLcaCkfwQeIhWXYPz =__addon__.getSetting('id')
  BjytDAMovruKdFLcaCkfwQeIhWXYpO =BjytDAMovruKdFLcaCkfwQeIhWXYnO(BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('page'))
  BjytDAMovruKdFLcaCkfwQeIhWXYpU =BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('stype')
  if 'search_key' in BjytDAMovruKdFLcaCkfwQeIhWXYpn:
   BjytDAMovruKdFLcaCkfwQeIhWXYPn=BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('search_key')
  else:
   BjytDAMovruKdFLcaCkfwQeIhWXYPn=BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not BjytDAMovruKdFLcaCkfwQeIhWXYPn:return
  BjytDAMovruKdFLcaCkfwQeIhWXYPO,BjytDAMovruKdFLcaCkfwQeIhWXYpR=BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.GetSearchList(BjytDAMovruKdFLcaCkfwQeIhWXYPn,BjytDAMovruKdFLcaCkfwQeIhWXYPz,BjytDAMovruKdFLcaCkfwQeIhWXYpO,BjytDAMovruKdFLcaCkfwQeIhWXYpU,landyn=BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_settings_thumbnail_landyn())
  if BjytDAMovruKdFLcaCkfwQeIhWXYni(BjytDAMovruKdFLcaCkfwQeIhWXYPO)==0:return
  for BjytDAMovruKdFLcaCkfwQeIhWXYPb in BjytDAMovruKdFLcaCkfwQeIhWXYPO:
   BjytDAMovruKdFLcaCkfwQeIhWXYUb =BjytDAMovruKdFLcaCkfwQeIhWXYPb.get('title')
   BjytDAMovruKdFLcaCkfwQeIhWXYpH=BjytDAMovruKdFLcaCkfwQeIhWXYPb.get('thumbnail')
   BjytDAMovruKdFLcaCkfwQeIhWXYpx =BjytDAMovruKdFLcaCkfwQeIhWXYPb.get('synopsis')
   BjytDAMovruKdFLcaCkfwQeIhWXYPR =BjytDAMovruKdFLcaCkfwQeIhWXYPb.get('program')
   BjytDAMovruKdFLcaCkfwQeIhWXYpl=BjytDAMovruKdFLcaCkfwQeIhWXYPb.get('info')
   BjytDAMovruKdFLcaCkfwQeIhWXYpl['plot']='%s\n\n%s'%(BjytDAMovruKdFLcaCkfwQeIhWXYUb,BjytDAMovruKdFLcaCkfwQeIhWXYpx)
   if BjytDAMovruKdFLcaCkfwQeIhWXYpU=='vod':
    BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':'EPISODE','programcode':BjytDAMovruKdFLcaCkfwQeIhWXYPb.get('program'),'page':'1'}
    BjytDAMovruKdFLcaCkfwQeIhWXYUN=BjytDAMovruKdFLcaCkfwQeIhWXYnR
   else:
    BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':'MOVIE','mediacode':BjytDAMovruKdFLcaCkfwQeIhWXYPb.get('movie'),'stype':'movie','title':BjytDAMovruKdFLcaCkfwQeIhWXYUb,'thumbnail':BjytDAMovruKdFLcaCkfwQeIhWXYpH}
    BjytDAMovruKdFLcaCkfwQeIhWXYUN=BjytDAMovruKdFLcaCkfwQeIhWXYnb
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel='',img=BjytDAMovruKdFLcaCkfwQeIhWXYpH,infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYpl,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYUN,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYpR:
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['mode'] ='SEARCH' 
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['search_key']=BjytDAMovruKdFLcaCkfwQeIhWXYPn
   BjytDAMovruKdFLcaCkfwQeIhWXYUl['page'] =BjytDAMovruKdFLcaCkfwQeIhWXYnH(BjytDAMovruKdFLcaCkfwQeIhWXYpO+1)
   BjytDAMovruKdFLcaCkfwQeIhWXYUb='[B]%s >>[/B]'%'다음 페이지'
   BjytDAMovruKdFLcaCkfwQeIhWXYpN=BjytDAMovruKdFLcaCkfwQeIhWXYnH(BjytDAMovruKdFLcaCkfwQeIhWXYpO+1)
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel=BjytDAMovruKdFLcaCkfwQeIhWXYpN,img='',infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYnz,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnR,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  if BjytDAMovruKdFLcaCkfwQeIhWXYni(BjytDAMovruKdFLcaCkfwQeIhWXYPO)>0:xbmcplugin.endOfDirectory(BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_handle)
 def Delete_Watched_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpU):
  try:
   BjytDAMovruKdFLcaCkfwQeIhWXYPi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BjytDAMovruKdFLcaCkfwQeIhWXYpU))
   fp=BjytDAMovruKdFLcaCkfwQeIhWXYnx(BjytDAMovruKdFLcaCkfwQeIhWXYPi,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   BjytDAMovruKdFLcaCkfwQeIhWXYnz
 def dp_WatchList_Delete(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpn):
  BjytDAMovruKdFLcaCkfwQeIhWXYpU=BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('stype')
  BjytDAMovruKdFLcaCkfwQeIhWXYgE=xbmcgui.Dialog()
  BjytDAMovruKdFLcaCkfwQeIhWXYUJ=BjytDAMovruKdFLcaCkfwQeIhWXYgE.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if BjytDAMovruKdFLcaCkfwQeIhWXYUJ==BjytDAMovruKdFLcaCkfwQeIhWXYnb:sys.exit()
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.Delete_Watched_List(BjytDAMovruKdFLcaCkfwQeIhWXYpU)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpU):
  try:
   BjytDAMovruKdFLcaCkfwQeIhWXYPi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BjytDAMovruKdFLcaCkfwQeIhWXYpU))
   fp=BjytDAMovruKdFLcaCkfwQeIhWXYnx(BjytDAMovruKdFLcaCkfwQeIhWXYPi,'r',-1,'utf-8')
   BjytDAMovruKdFLcaCkfwQeIhWXYPH=fp.readlines()
   fp.close()
  except:
   BjytDAMovruKdFLcaCkfwQeIhWXYPH=[]
  return BjytDAMovruKdFLcaCkfwQeIhWXYPH
 def Save_Watched_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpU,BjytDAMovruKdFLcaCkfwQeIhWXYgl):
  try:
   BjytDAMovruKdFLcaCkfwQeIhWXYPi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%BjytDAMovruKdFLcaCkfwQeIhWXYpU))
   BjytDAMovruKdFLcaCkfwQeIhWXYPx=BjytDAMovruKdFLcaCkfwQeIhWXYgH.Load_Watched_List(BjytDAMovruKdFLcaCkfwQeIhWXYpU) 
   fp=BjytDAMovruKdFLcaCkfwQeIhWXYnx(BjytDAMovruKdFLcaCkfwQeIhWXYPi,'w',-1,'utf-8')
   BjytDAMovruKdFLcaCkfwQeIhWXYPT=urllib.parse.urlencode(BjytDAMovruKdFLcaCkfwQeIhWXYgl)
   BjytDAMovruKdFLcaCkfwQeIhWXYPT=BjytDAMovruKdFLcaCkfwQeIhWXYPT+'\n'
   fp.write(BjytDAMovruKdFLcaCkfwQeIhWXYPT)
   BjytDAMovruKdFLcaCkfwQeIhWXYPl=0
   for BjytDAMovruKdFLcaCkfwQeIhWXYPN in BjytDAMovruKdFLcaCkfwQeIhWXYPx:
    BjytDAMovruKdFLcaCkfwQeIhWXYPE=BjytDAMovruKdFLcaCkfwQeIhWXYnT(urllib.parse.parse_qsl(BjytDAMovruKdFLcaCkfwQeIhWXYPN))
    BjytDAMovruKdFLcaCkfwQeIhWXYPG=BjytDAMovruKdFLcaCkfwQeIhWXYgl.get('code').strip()
    BjytDAMovruKdFLcaCkfwQeIhWXYPq=BjytDAMovruKdFLcaCkfwQeIhWXYPE.get('code').strip()
    if BjytDAMovruKdFLcaCkfwQeIhWXYpU=='vod' and BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_settings_direct_replay()==BjytDAMovruKdFLcaCkfwQeIhWXYnR:
     BjytDAMovruKdFLcaCkfwQeIhWXYPG=BjytDAMovruKdFLcaCkfwQeIhWXYgl.get('videoid').strip()
     BjytDAMovruKdFLcaCkfwQeIhWXYPq=BjytDAMovruKdFLcaCkfwQeIhWXYPE.get('videoid').strip()if BjytDAMovruKdFLcaCkfwQeIhWXYPq!=BjytDAMovruKdFLcaCkfwQeIhWXYnz else '-'
    if BjytDAMovruKdFLcaCkfwQeIhWXYPG!=BjytDAMovruKdFLcaCkfwQeIhWXYPq:
     fp.write(BjytDAMovruKdFLcaCkfwQeIhWXYPN)
     BjytDAMovruKdFLcaCkfwQeIhWXYPl+=1
     if BjytDAMovruKdFLcaCkfwQeIhWXYPl>=50:break
   fp.close()
  except:
   BjytDAMovruKdFLcaCkfwQeIhWXYnz
 def dp_Watch_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpn):
  BjytDAMovruKdFLcaCkfwQeIhWXYpU =BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('stype')
  BjytDAMovruKdFLcaCkfwQeIhWXYUp=BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_settings_direct_replay()
  if BjytDAMovruKdFLcaCkfwQeIhWXYpU=='-':
   for BjytDAMovruKdFLcaCkfwQeIhWXYpz in BjytDAMovruKdFLcaCkfwQeIhWXYgz:
    BjytDAMovruKdFLcaCkfwQeIhWXYUb=BjytDAMovruKdFLcaCkfwQeIhWXYpz.get('title')
    BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':BjytDAMovruKdFLcaCkfwQeIhWXYpz.get('mode'),'stype':BjytDAMovruKdFLcaCkfwQeIhWXYpz.get('stype')}
    BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel='',img='',infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYnz,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnR,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
   if BjytDAMovruKdFLcaCkfwQeIhWXYni(BjytDAMovruKdFLcaCkfwQeIhWXYgz)>0:xbmcplugin.endOfDirectory(BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_handle)
  else:
   BjytDAMovruKdFLcaCkfwQeIhWXYPV=BjytDAMovruKdFLcaCkfwQeIhWXYgH.Load_Watched_List(BjytDAMovruKdFLcaCkfwQeIhWXYpU)
   for BjytDAMovruKdFLcaCkfwQeIhWXYPS in BjytDAMovruKdFLcaCkfwQeIhWXYPV:
    BjytDAMovruKdFLcaCkfwQeIhWXYPJ=BjytDAMovruKdFLcaCkfwQeIhWXYnT(urllib.parse.parse_qsl(BjytDAMovruKdFLcaCkfwQeIhWXYPS))
    BjytDAMovruKdFLcaCkfwQeIhWXYPm =BjytDAMovruKdFLcaCkfwQeIhWXYPJ.get('code').strip()
    BjytDAMovruKdFLcaCkfwQeIhWXYUb =BjytDAMovruKdFLcaCkfwQeIhWXYPJ.get('title').strip()
    BjytDAMovruKdFLcaCkfwQeIhWXYpH=BjytDAMovruKdFLcaCkfwQeIhWXYPJ.get('img').strip()
    BjytDAMovruKdFLcaCkfwQeIhWXYPs =BjytDAMovruKdFLcaCkfwQeIhWXYPJ.get('videoid').strip()
    BjytDAMovruKdFLcaCkfwQeIhWXYpl={}
    BjytDAMovruKdFLcaCkfwQeIhWXYpl['plot']=BjytDAMovruKdFLcaCkfwQeIhWXYUb
    if BjytDAMovruKdFLcaCkfwQeIhWXYpU=='vod':
     if BjytDAMovruKdFLcaCkfwQeIhWXYUp==BjytDAMovruKdFLcaCkfwQeIhWXYnb or BjytDAMovruKdFLcaCkfwQeIhWXYPs==BjytDAMovruKdFLcaCkfwQeIhWXYnz:
      BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':'EPISODE','programcode':BjytDAMovruKdFLcaCkfwQeIhWXYPm,'page':'1'}
      BjytDAMovruKdFLcaCkfwQeIhWXYUN=BjytDAMovruKdFLcaCkfwQeIhWXYnR
     else:
      BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':'VOD','mediacode':BjytDAMovruKdFLcaCkfwQeIhWXYPs,'stype':'vod','programcode':BjytDAMovruKdFLcaCkfwQeIhWXYPm,'title':BjytDAMovruKdFLcaCkfwQeIhWXYUb,'thumbnail':BjytDAMovruKdFLcaCkfwQeIhWXYpH}
      BjytDAMovruKdFLcaCkfwQeIhWXYUN=BjytDAMovruKdFLcaCkfwQeIhWXYnb
    else:
     BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':'MOVIE','mediacode':BjytDAMovruKdFLcaCkfwQeIhWXYPm,'stype':'movie','title':BjytDAMovruKdFLcaCkfwQeIhWXYUb,'thumbnail':BjytDAMovruKdFLcaCkfwQeIhWXYpH}
     BjytDAMovruKdFLcaCkfwQeIhWXYUN=BjytDAMovruKdFLcaCkfwQeIhWXYnb
    BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel='',img=BjytDAMovruKdFLcaCkfwQeIhWXYpH,infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYpl,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYUN,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
   BjytDAMovruKdFLcaCkfwQeIhWXYpl={'plot':'시청목록을 삭제합니다.'}
   BjytDAMovruKdFLcaCkfwQeIhWXYUb='*** 시청목록 삭제 ***'
   BjytDAMovruKdFLcaCkfwQeIhWXYUl={'mode':'MYVIEW_REMOVE','stype':BjytDAMovruKdFLcaCkfwQeIhWXYpU}
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.add_dir(BjytDAMovruKdFLcaCkfwQeIhWXYUb,sublabel='',img='',infoLabels=BjytDAMovruKdFLcaCkfwQeIhWXYpl,isFolder=BjytDAMovruKdFLcaCkfwQeIhWXYnb,params=BjytDAMovruKdFLcaCkfwQeIhWXYUl)
   xbmcplugin.endOfDirectory(BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_handle,cacheToDisc=BjytDAMovruKdFLcaCkfwQeIhWXYnb)
 def play_VIDEO(BjytDAMovruKdFLcaCkfwQeIhWXYgH,BjytDAMovruKdFLcaCkfwQeIhWXYpn):
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.SaveCredential(BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_winCredential())
  BjytDAMovruKdFLcaCkfwQeIhWXYzU =BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('mediacode')
  BjytDAMovruKdFLcaCkfwQeIhWXYpU =BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('stype')
  BjytDAMovruKdFLcaCkfwQeIhWXYzp =BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('pvrmode')
  BjytDAMovruKdFLcaCkfwQeIhWXYzP=BjytDAMovruKdFLcaCkfwQeIhWXYgH.get_selQuality(BjytDAMovruKdFLcaCkfwQeIhWXYpU)
  BjytDAMovruKdFLcaCkfwQeIhWXYzn,BjytDAMovruKdFLcaCkfwQeIhWXYzO=BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.GetBroadURL(BjytDAMovruKdFLcaCkfwQeIhWXYzU,BjytDAMovruKdFLcaCkfwQeIhWXYzP,BjytDAMovruKdFLcaCkfwQeIhWXYpU,BjytDAMovruKdFLcaCkfwQeIhWXYzp)
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.addon_log('qt, stype, url : %s - %s - %s'%(BjytDAMovruKdFLcaCkfwQeIhWXYnH(BjytDAMovruKdFLcaCkfwQeIhWXYzP),BjytDAMovruKdFLcaCkfwQeIhWXYpU,BjytDAMovruKdFLcaCkfwQeIhWXYzn))
  if BjytDAMovruKdFLcaCkfwQeIhWXYzn=='':
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.addon_noti(__language__(30908).encode('utf8'))
   return
  BjytDAMovruKdFLcaCkfwQeIhWXYzb =BjytDAMovruKdFLcaCkfwQeIhWXYzn.find('Policy=')
  if BjytDAMovruKdFLcaCkfwQeIhWXYzb!=-1:
   BjytDAMovruKdFLcaCkfwQeIhWXYzR =BjytDAMovruKdFLcaCkfwQeIhWXYzn.split('?')[0]
   BjytDAMovruKdFLcaCkfwQeIhWXYzi=BjytDAMovruKdFLcaCkfwQeIhWXYnT(urllib.parse.parse_qsl(urllib.parse.urlsplit(BjytDAMovruKdFLcaCkfwQeIhWXYzn).query))
   BjytDAMovruKdFLcaCkfwQeIhWXYzi=urllib.parse.urlencode(BjytDAMovruKdFLcaCkfwQeIhWXYzi)
   BjytDAMovruKdFLcaCkfwQeIhWXYzi=BjytDAMovruKdFLcaCkfwQeIhWXYzi.replace('&',';')
   BjytDAMovruKdFLcaCkfwQeIhWXYzi=BjytDAMovruKdFLcaCkfwQeIhWXYzi.replace('Policy','CloudFront-Policy')
   BjytDAMovruKdFLcaCkfwQeIhWXYzi=BjytDAMovruKdFLcaCkfwQeIhWXYzi.replace('Signature','CloudFront-Signature')
   BjytDAMovruKdFLcaCkfwQeIhWXYzi=BjytDAMovruKdFLcaCkfwQeIhWXYzi.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   BjytDAMovruKdFLcaCkfwQeIhWXYzH='%s|Cookie=%s'%(BjytDAMovruKdFLcaCkfwQeIhWXYzR,BjytDAMovruKdFLcaCkfwQeIhWXYzi)
  else:
   BjytDAMovruKdFLcaCkfwQeIhWXYzH=BjytDAMovruKdFLcaCkfwQeIhWXYzn
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.addon_log(BjytDAMovruKdFLcaCkfwQeIhWXYzH)
  BjytDAMovruKdFLcaCkfwQeIhWXYzx=xbmcgui.ListItem(path=BjytDAMovruKdFLcaCkfwQeIhWXYzH)
  if BjytDAMovruKdFLcaCkfwQeIhWXYzO!='':
   BjytDAMovruKdFLcaCkfwQeIhWXYzT=BjytDAMovruKdFLcaCkfwQeIhWXYzO
   BjytDAMovruKdFLcaCkfwQeIhWXYzl ='https://cj.drmkeyserver.com/widevine_license'
   BjytDAMovruKdFLcaCkfwQeIhWXYzN ='mpd'
   BjytDAMovruKdFLcaCkfwQeIhWXYzE ='com.widevine.alpha'
   BjytDAMovruKdFLcaCkfwQeIhWXYzG =inputstreamhelper.Helper(BjytDAMovruKdFLcaCkfwQeIhWXYzN,drm='widevine')
   if BjytDAMovruKdFLcaCkfwQeIhWXYzG.check_inputstream():
    BjytDAMovruKdFLcaCkfwQeIhWXYzq={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%BjytDAMovruKdFLcaCkfwQeIhWXYzU,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.USER_AGENT,'AcquireLicenseAssertion':BjytDAMovruKdFLcaCkfwQeIhWXYzT,'Host':'cj.drmkeyserver.com'}
    BjytDAMovruKdFLcaCkfwQeIhWXYzV=BjytDAMovruKdFLcaCkfwQeIhWXYzl+'|'+urllib.parse.urlencode(BjytDAMovruKdFLcaCkfwQeIhWXYzq)+'|R{SSM}|'
    BjytDAMovruKdFLcaCkfwQeIhWXYzx.setProperty('inputstream',BjytDAMovruKdFLcaCkfwQeIhWXYzG.inputstream_addon)
    BjytDAMovruKdFLcaCkfwQeIhWXYzx.setProperty('inputstream.adaptive.manifest_type',BjytDAMovruKdFLcaCkfwQeIhWXYzN)
    BjytDAMovruKdFLcaCkfwQeIhWXYzx.setProperty('inputstream.adaptive.license_type',BjytDAMovruKdFLcaCkfwQeIhWXYzE)
    BjytDAMovruKdFLcaCkfwQeIhWXYzx.setProperty('inputstream.adaptive.license_key',BjytDAMovruKdFLcaCkfwQeIhWXYzV)
    BjytDAMovruKdFLcaCkfwQeIhWXYzx.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.USER_AGENT))
  xbmcplugin.setResolvedUrl(BjytDAMovruKdFLcaCkfwQeIhWXYgH._addon_handle,BjytDAMovruKdFLcaCkfwQeIhWXYnR,BjytDAMovruKdFLcaCkfwQeIhWXYzx)
  try:
   if BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('mode')in['VOD','MOVIE']and BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('title'):
    BjytDAMovruKdFLcaCkfwQeIhWXYUl={'code':BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('programcode')if BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('mode')=='VOD' else BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('mediacode'),'img':BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('thumbnail'),'title':BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('title'),'videoid':BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('mediacode')}
    BjytDAMovruKdFLcaCkfwQeIhWXYgH.Save_Watched_List(BjytDAMovruKdFLcaCkfwQeIhWXYpn.get('stype'),BjytDAMovruKdFLcaCkfwQeIhWXYUl)
  except:
   BjytDAMovruKdFLcaCkfwQeIhWXYnz
 def logout(BjytDAMovruKdFLcaCkfwQeIhWXYgH):
  BjytDAMovruKdFLcaCkfwQeIhWXYgE=xbmcgui.Dialog()
  BjytDAMovruKdFLcaCkfwQeIhWXYUJ=BjytDAMovruKdFLcaCkfwQeIhWXYgE.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if BjytDAMovruKdFLcaCkfwQeIhWXYUJ==BjytDAMovruKdFLcaCkfwQeIhWXYnb:sys.exit()
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.wininfo_clear()
  if os.path.isfile(BjytDAMovruKdFLcaCkfwQeIhWXYgi):os.remove(BjytDAMovruKdFLcaCkfwQeIhWXYgi)
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(BjytDAMovruKdFLcaCkfwQeIhWXYgH):
  BjytDAMovruKdFLcaCkfwQeIhWXYUz=xbmcgui.Window(10000)
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_TOKEN','')
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_USERINFO','')
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_UUID','')
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_LOGINTIME','')
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_MAINTOKEN','')
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_COOKIEKEY','')
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(BjytDAMovruKdFLcaCkfwQeIhWXYgH):
  BjytDAMovruKdFLcaCkfwQeIhWXYzS =BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.Get_Now_Datetime()
  BjytDAMovruKdFLcaCkfwQeIhWXYzJ=BjytDAMovruKdFLcaCkfwQeIhWXYzS+datetime.timedelta(days=BjytDAMovruKdFLcaCkfwQeIhWXYnO(__addon__.getSetting('cache_ttl')))
  BjytDAMovruKdFLcaCkfwQeIhWXYUz=xbmcgui.Window(10000)
  BjytDAMovruKdFLcaCkfwQeIhWXYzm={'tving_token':BjytDAMovruKdFLcaCkfwQeIhWXYUz.getProperty('TVING_M_TOKEN'),'tving_userinfo':BjytDAMovruKdFLcaCkfwQeIhWXYUz.getProperty('TVING_M_USERINFO'),'tving_uuid':BjytDAMovruKdFLcaCkfwQeIhWXYUz.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':BjytDAMovruKdFLcaCkfwQeIhWXYzJ.strftime('%Y-%m-%d'),'tving_maintoken':BjytDAMovruKdFLcaCkfwQeIhWXYUz.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':BjytDAMovruKdFLcaCkfwQeIhWXYUz.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':BjytDAMovruKdFLcaCkfwQeIhWXYUz.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=BjytDAMovruKdFLcaCkfwQeIhWXYnx(BjytDAMovruKdFLcaCkfwQeIhWXYgi,'w',-1,'utf-8')
   json.dump(BjytDAMovruKdFLcaCkfwQeIhWXYzm,fp)
   fp.close()
  except BjytDAMovruKdFLcaCkfwQeIhWXYnl as exception:
   BjytDAMovruKdFLcaCkfwQeIhWXYnN(exception)
 def cookiefile_check(BjytDAMovruKdFLcaCkfwQeIhWXYgH):
  BjytDAMovruKdFLcaCkfwQeIhWXYzm={}
  try: 
   fp=BjytDAMovruKdFLcaCkfwQeIhWXYnx(BjytDAMovruKdFLcaCkfwQeIhWXYgi,'r',-1,'utf-8')
   BjytDAMovruKdFLcaCkfwQeIhWXYzm= json.load(fp)
   fp.close()
  except BjytDAMovruKdFLcaCkfwQeIhWXYnl as exception:
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.wininfo_clear()
   return BjytDAMovruKdFLcaCkfwQeIhWXYnb
  BjytDAMovruKdFLcaCkfwQeIhWXYUG =__addon__.getSetting('id')
  BjytDAMovruKdFLcaCkfwQeIhWXYUq =__addon__.getSetting('pw')
  BjytDAMovruKdFLcaCkfwQeIhWXYzs=__addon__.getSetting('login_type')
  BjytDAMovruKdFLcaCkfwQeIhWXYng =__addon__.getSetting('selected_profile')
  BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_id']=base64.standard_b64decode(BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_id']).decode('utf-8')
  BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_pw']=base64.standard_b64decode(BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_pw']).decode('utf-8')
  try:
   BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_profile']
  except:
   BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_profile']='0'
  if BjytDAMovruKdFLcaCkfwQeIhWXYUG!=BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_id']or BjytDAMovruKdFLcaCkfwQeIhWXYUq!=BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_pw']or BjytDAMovruKdFLcaCkfwQeIhWXYzs!=BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_logintype']or BjytDAMovruKdFLcaCkfwQeIhWXYng!=BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_profile']:
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.wininfo_clear()
   return BjytDAMovruKdFLcaCkfwQeIhWXYnb
  BjytDAMovruKdFLcaCkfwQeIhWXYUm =BjytDAMovruKdFLcaCkfwQeIhWXYnO(BjytDAMovruKdFLcaCkfwQeIhWXYgH.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  BjytDAMovruKdFLcaCkfwQeIhWXYnU=BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_limitdate']
  BjytDAMovruKdFLcaCkfwQeIhWXYUs =BjytDAMovruKdFLcaCkfwQeIhWXYnO(re.sub('-','',BjytDAMovruKdFLcaCkfwQeIhWXYnU))
  if BjytDAMovruKdFLcaCkfwQeIhWXYUs<BjytDAMovruKdFLcaCkfwQeIhWXYUm:
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.wininfo_clear()
   return BjytDAMovruKdFLcaCkfwQeIhWXYnb
  BjytDAMovruKdFLcaCkfwQeIhWXYUz=xbmcgui.Window(10000)
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_TOKEN',BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_token'])
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_USERINFO',BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_userinfo'])
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_UUID',BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_uuid'])
  BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_LOGINTIME',BjytDAMovruKdFLcaCkfwQeIhWXYnU)
  try:
   BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_MAINTOKEN',BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_maintoken'])
   BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_COOKIEKEY',BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_cookiekey'])
   BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_LOCKKEY',BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_lockkey'])
  except:
   BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_MAINTOKEN',BjytDAMovruKdFLcaCkfwQeIhWXYzm['tving_token'])
   BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_COOKIEKEY','Y')
   BjytDAMovruKdFLcaCkfwQeIhWXYUz.setProperty('TVING_M_LOCKKEY','N')
  return BjytDAMovruKdFLcaCkfwQeIhWXYnR
 def tving_main(BjytDAMovruKdFLcaCkfwQeIhWXYgH):
  BjytDAMovruKdFLcaCkfwQeIhWXYnp=BjytDAMovruKdFLcaCkfwQeIhWXYgH.main_params.get('mode',BjytDAMovruKdFLcaCkfwQeIhWXYnz)
  if BjytDAMovruKdFLcaCkfwQeIhWXYnp=='LOGOUT':
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.logout()
   return
  BjytDAMovruKdFLcaCkfwQeIhWXYgH.login_main()
  if BjytDAMovruKdFLcaCkfwQeIhWXYnp is BjytDAMovruKdFLcaCkfwQeIhWXYnz:
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.dp_Main_List()
  elif BjytDAMovruKdFLcaCkfwQeIhWXYnp in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.dp_Title_Group(BjytDAMovruKdFLcaCkfwQeIhWXYgH.main_params)
  elif BjytDAMovruKdFLcaCkfwQeIhWXYnp=='CHANNEL':
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.dp_LiveChannel_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH.main_params)
  elif BjytDAMovruKdFLcaCkfwQeIhWXYnp in['LIVE','VOD','MOVIE']:
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.play_VIDEO(BjytDAMovruKdFLcaCkfwQeIhWXYgH.main_params)
  elif BjytDAMovruKdFLcaCkfwQeIhWXYnp=='PROGRAM':
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.dp_Program_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH.main_params)
  elif BjytDAMovruKdFLcaCkfwQeIhWXYnp=='EPISODE':
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.dp_Episode_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH.main_params)
  elif BjytDAMovruKdFLcaCkfwQeIhWXYnp=='MOVIE_SUB':
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.dp_Movie_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH.main_params)
  elif BjytDAMovruKdFLcaCkfwQeIhWXYnp=='SEARCH_GROUP':
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.dp_Search_Group(BjytDAMovruKdFLcaCkfwQeIhWXYgH.main_params)
  elif BjytDAMovruKdFLcaCkfwQeIhWXYnp=='SEARCH':
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.dp_Search_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH.main_params)
  elif BjytDAMovruKdFLcaCkfwQeIhWXYnp=='WATCH':
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.dp_Watch_List(BjytDAMovruKdFLcaCkfwQeIhWXYgH.main_params)
  elif BjytDAMovruKdFLcaCkfwQeIhWXYnp=='MYVIEW_REMOVE':
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.dp_WatchList_Delete(BjytDAMovruKdFLcaCkfwQeIhWXYgH.main_params)
  elif BjytDAMovruKdFLcaCkfwQeIhWXYnp=='ORDER_BY':
   BjytDAMovruKdFLcaCkfwQeIhWXYgH.dp_setEpOrderby(BjytDAMovruKdFLcaCkfwQeIhWXYgH.main_params)
  else:
   BjytDAMovruKdFLcaCkfwQeIhWXYnz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
