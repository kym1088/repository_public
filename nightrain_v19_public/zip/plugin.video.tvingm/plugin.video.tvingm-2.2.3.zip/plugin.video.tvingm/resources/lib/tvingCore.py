__author__="NightRain"
fyNVzJxHPFSboIgTdjaXrlpLiDueEU=object
fyNVzJxHPFSboIgTdjaXrlpLiDueEA=None
fyNVzJxHPFSboIgTdjaXrlpLiDueEB=False
fyNVzJxHPFSboIgTdjaXrlpLiDueEC=int
fyNVzJxHPFSboIgTdjaXrlpLiDueEW=range
fyNVzJxHPFSboIgTdjaXrlpLiDueEn=True
fyNVzJxHPFSboIgTdjaXrlpLiDueEk=Exception
fyNVzJxHPFSboIgTdjaXrlpLiDueEh=print
fyNVzJxHPFSboIgTdjaXrlpLiDueEq=str
fyNVzJxHPFSboIgTdjaXrlpLiDueEs=list
fyNVzJxHPFSboIgTdjaXrlpLiDueEK=len
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import random
fyNVzJxHPFSboIgTdjaXrlpLiDuewQ={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
class fyNVzJxHPFSboIgTdjaXrlpLiDuewm(fyNVzJxHPFSboIgTdjaXrlpLiDueEU):
 def __init__(fyNVzJxHPFSboIgTdjaXrlpLiDuewt):
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_TOKEN =''
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.POC_USERINFO =''
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_UUID ='-'
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_MAINTOKEN=''
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVIGN_COOKIEKEY=''
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_LOCKKEY =''
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.NETWORKCODE ='CSND0900'
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.OSCODE ='CSOD0900' 
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TELECODE ='CSCD0900'
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.SCREENCODE ='CSSD0100'
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.LIVE_LIMIT =23
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.VOD_LIMIT =20
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.EPISODE_LIMIT =30 
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.SEARCH_LIMIT =80 
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.MOVIE_LIMIT =18
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.API_DOMAIN ='https://api.tving.com'
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN ='https://image.tving.com'
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.SEARCH_DOMAIN ='https://search.tving.com'
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.LOGIN_DOMAIN ='https://user.tving.com'
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.URL_DOMAIN ='https://www.tving.com'
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.MOVIE_LITE =['2610061','2610161','261062']
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.DEFAULT_HEADER ={'user-agent':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.USER_AGENT}
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,jobtype,fyNVzJxHPFSboIgTdjaXrlpLiDuemn,payload=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,params=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,redirects=fyNVzJxHPFSboIgTdjaXrlpLiDueEB):
  fyNVzJxHPFSboIgTdjaXrlpLiDuewE=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.DEFAULT_HEADER
  if headers:fyNVzJxHPFSboIgTdjaXrlpLiDuewE.update(headers)
  if jobtype=='Get':
   fyNVzJxHPFSboIgTdjaXrlpLiDuewO=requests.get(fyNVzJxHPFSboIgTdjaXrlpLiDuemn,params=params,headers=fyNVzJxHPFSboIgTdjaXrlpLiDuewE,cookies=cookies,allow_redirects=redirects)
  else:
   fyNVzJxHPFSboIgTdjaXrlpLiDuewO=requests.post(fyNVzJxHPFSboIgTdjaXrlpLiDuemn,data=payload,params=params,headers=fyNVzJxHPFSboIgTdjaXrlpLiDuewE,cookies=cookies,allow_redirects=redirects)
  return fyNVzJxHPFSboIgTdjaXrlpLiDuewO
 def makeDefaultCookies(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,vToken=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,vUserinfo=fyNVzJxHPFSboIgTdjaXrlpLiDueEA):
  fyNVzJxHPFSboIgTdjaXrlpLiDuewU={}
  fyNVzJxHPFSboIgTdjaXrlpLiDuewU['_tving_token']=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_TOKEN if vToken==fyNVzJxHPFSboIgTdjaXrlpLiDueEA else vToken
  fyNVzJxHPFSboIgTdjaXrlpLiDuewU['POC_USERINFO']=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.POC_USERINFO if vToken==fyNVzJxHPFSboIgTdjaXrlpLiDueEA else vUserinfo
  if fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_MAINTOKEN!='':fyNVzJxHPFSboIgTdjaXrlpLiDuewU[fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GLOBAL_COOKIENM['tv_maintoken']]=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_MAINTOKEN
  if fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVIGN_COOKIEKEY!='':fyNVzJxHPFSboIgTdjaXrlpLiDuewU[fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GLOBAL_COOKIENM['tv_cookiekey']]=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVIGN_COOKIEKEY
  if fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_LOCKKEY !='':fyNVzJxHPFSboIgTdjaXrlpLiDuewU[fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GLOBAL_COOKIENM['tv_lockkey']] =fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_LOCKKEY
  return fyNVzJxHPFSboIgTdjaXrlpLiDuewU
 def getDeviceStr(fyNVzJxHPFSboIgTdjaXrlpLiDuewt):
  fyNVzJxHPFSboIgTdjaXrlpLiDuewA=[]
  fyNVzJxHPFSboIgTdjaXrlpLiDuewA.append('Windows') 
  fyNVzJxHPFSboIgTdjaXrlpLiDuewA.append('Chrome') 
  fyNVzJxHPFSboIgTdjaXrlpLiDuewA.append('ko-KR') 
  fyNVzJxHPFSboIgTdjaXrlpLiDuewA.append('undefined') 
  fyNVzJxHPFSboIgTdjaXrlpLiDuewA.append('24') 
  fyNVzJxHPFSboIgTdjaXrlpLiDuewA.append(u'한국 표준시')
  fyNVzJxHPFSboIgTdjaXrlpLiDuewA.append('undefined') 
  fyNVzJxHPFSboIgTdjaXrlpLiDuewA.append('undefined') 
  fyNVzJxHPFSboIgTdjaXrlpLiDuewA.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  fyNVzJxHPFSboIgTdjaXrlpLiDuewB=''
  for fyNVzJxHPFSboIgTdjaXrlpLiDuewC in fyNVzJxHPFSboIgTdjaXrlpLiDuewA:
   fyNVzJxHPFSboIgTdjaXrlpLiDuewB+=fyNVzJxHPFSboIgTdjaXrlpLiDuewC+'|'
  return fyNVzJxHPFSboIgTdjaXrlpLiDuewB
 def SaveCredential(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,fyNVzJxHPFSboIgTdjaXrlpLiDuewW):
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_TOKEN =fyNVzJxHPFSboIgTdjaXrlpLiDuewW.get('tving_token')
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.POC_USERINFO =fyNVzJxHPFSboIgTdjaXrlpLiDuewW.get('poc_userinfo')
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_UUID =fyNVzJxHPFSboIgTdjaXrlpLiDuewW.get('tving_uuid')
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_MAINTOKEN=fyNVzJxHPFSboIgTdjaXrlpLiDuewW.get('tving_maintoken')
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVIGN_COOKIEKEY=fyNVzJxHPFSboIgTdjaXrlpLiDuewW.get('tving_cookiekey')
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_LOCKKEY =fyNVzJxHPFSboIgTdjaXrlpLiDuewW.get('tving_lockkey')
 def LoadCredential(fyNVzJxHPFSboIgTdjaXrlpLiDuewt):
  fyNVzJxHPFSboIgTdjaXrlpLiDuewW={'tving_token':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_TOKEN,'poc_userinfo':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.POC_USERINFO,'tving_uuid':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_UUID,'tving_maintoken':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_MAINTOKEN,'tving_cookiekey':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVIGN_COOKIEKEY,'tving_lockkey':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_LOCKKEY}
  return fyNVzJxHPFSboIgTdjaXrlpLiDuewW
 def GetDefaultParams(fyNVzJxHPFSboIgTdjaXrlpLiDuewt):
  fyNVzJxHPFSboIgTdjaXrlpLiDuewn={'apiKey':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.APIKEY,'networkCode':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.NETWORKCODE,'osCode':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.OSCODE,'teleCode':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TELECODE,'screenCode':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.SCREENCODE}
  return fyNVzJxHPFSboIgTdjaXrlpLiDuewn
 def GetNoCache(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,timetype=1):
  if timetype==1:
   return fyNVzJxHPFSboIgTdjaXrlpLiDueEC(time.time())
  else:
   return fyNVzJxHPFSboIgTdjaXrlpLiDueEC(time.time()*1000)
 def GetUniqueid(fyNVzJxHPFSboIgTdjaXrlpLiDuewt):
  fyNVzJxHPFSboIgTdjaXrlpLiDuewk=[0 for i in fyNVzJxHPFSboIgTdjaXrlpLiDueEW(256)]
  for i in fyNVzJxHPFSboIgTdjaXrlpLiDueEW(256):
   fyNVzJxHPFSboIgTdjaXrlpLiDuewk[i]='%02x'%(i)
  fyNVzJxHPFSboIgTdjaXrlpLiDuewh=fyNVzJxHPFSboIgTdjaXrlpLiDueEC(4294967295*random.random())|0
  fyNVzJxHPFSboIgTdjaXrlpLiDuewq=fyNVzJxHPFSboIgTdjaXrlpLiDuewk[255&fyNVzJxHPFSboIgTdjaXrlpLiDuewh]+fyNVzJxHPFSboIgTdjaXrlpLiDuewk[fyNVzJxHPFSboIgTdjaXrlpLiDuewh>>8&255]+fyNVzJxHPFSboIgTdjaXrlpLiDuewk[fyNVzJxHPFSboIgTdjaXrlpLiDuewh>>16&255]+fyNVzJxHPFSboIgTdjaXrlpLiDuewk[fyNVzJxHPFSboIgTdjaXrlpLiDuewh>>24&255]
  return fyNVzJxHPFSboIgTdjaXrlpLiDuewq
 def GetCredential(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,user_id,user_pw,login_type,user_pf):
  fyNVzJxHPFSboIgTdjaXrlpLiDuews=fyNVzJxHPFSboIgTdjaXrlpLiDueEB
  fyNVzJxHPFSboIgTdjaXrlpLiDuewK=fyNVzJxHPFSboIgTdjaXrlpLiDuewv=fyNVzJxHPFSboIgTdjaXrlpLiDuemw=fyNVzJxHPFSboIgTdjaXrlpLiDuemQ=fyNVzJxHPFSboIgTdjaXrlpLiDuemt='' 
  fyNVzJxHPFSboIgTdjaXrlpLiDuewM ='-'
  try:
   fyNVzJxHPFSboIgTdjaXrlpLiDuewR=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   fyNVzJxHPFSboIgTdjaXrlpLiDuewG={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   fyNVzJxHPFSboIgTdjaXrlpLiDuewY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.callRequestCookies('Post',fyNVzJxHPFSboIgTdjaXrlpLiDuewR,payload=fyNVzJxHPFSboIgTdjaXrlpLiDuewG,params=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDueEA)
   for fyNVzJxHPFSboIgTdjaXrlpLiDuewc in fyNVzJxHPFSboIgTdjaXrlpLiDuewY.cookies:
    if fyNVzJxHPFSboIgTdjaXrlpLiDuewc.name=='_tving_token':
     fyNVzJxHPFSboIgTdjaXrlpLiDuewv=fyNVzJxHPFSboIgTdjaXrlpLiDuewc.value
    elif fyNVzJxHPFSboIgTdjaXrlpLiDuewc.name=='POC_USERINFO':
     fyNVzJxHPFSboIgTdjaXrlpLiDuemw=fyNVzJxHPFSboIgTdjaXrlpLiDuewc.value
   if fyNVzJxHPFSboIgTdjaXrlpLiDuewv=='':return fyNVzJxHPFSboIgTdjaXrlpLiDuews
   fyNVzJxHPFSboIgTdjaXrlpLiDuewK=fyNVzJxHPFSboIgTdjaXrlpLiDuewv
   fyNVzJxHPFSboIgTdjaXrlpLiDuewv,fyNVzJxHPFSboIgTdjaXrlpLiDuemQ,fyNVzJxHPFSboIgTdjaXrlpLiDuemt=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetProfileToken(fyNVzJxHPFSboIgTdjaXrlpLiDuewv,fyNVzJxHPFSboIgTdjaXrlpLiDuemw,user_pf)
   fyNVzJxHPFSboIgTdjaXrlpLiDuews=fyNVzJxHPFSboIgTdjaXrlpLiDueEn
   fyNVzJxHPFSboIgTdjaXrlpLiDuewM =fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetDeviceList(fyNVzJxHPFSboIgTdjaXrlpLiDuewv,fyNVzJxHPFSboIgTdjaXrlpLiDuemw)
   fyNVzJxHPFSboIgTdjaXrlpLiDuewM =fyNVzJxHPFSboIgTdjaXrlpLiDuewM+'-'+fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetUniqueid()
  except fyNVzJxHPFSboIgTdjaXrlpLiDueEk as exception:
   fyNVzJxHPFSboIgTdjaXrlpLiDuewK=fyNVzJxHPFSboIgTdjaXrlpLiDuewv=fyNVzJxHPFSboIgTdjaXrlpLiDuemw=fyNVzJxHPFSboIgTdjaXrlpLiDuemQ=fyNVzJxHPFSboIgTdjaXrlpLiDuemt=''
   fyNVzJxHPFSboIgTdjaXrlpLiDuewM='-'
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(exception)
  fyNVzJxHPFSboIgTdjaXrlpLiDuewW={'tving_token':fyNVzJxHPFSboIgTdjaXrlpLiDuewv,'poc_userinfo':fyNVzJxHPFSboIgTdjaXrlpLiDuemw,'tving_uuid':fyNVzJxHPFSboIgTdjaXrlpLiDuewM,'tving_maintoken':fyNVzJxHPFSboIgTdjaXrlpLiDuewK,'tving_cookiekey':fyNVzJxHPFSboIgTdjaXrlpLiDuemQ,'tving_lockkey':fyNVzJxHPFSboIgTdjaXrlpLiDuemt}
  fyNVzJxHPFSboIgTdjaXrlpLiDuewt.SaveCredential(fyNVzJxHPFSboIgTdjaXrlpLiDuewW)
  return fyNVzJxHPFSboIgTdjaXrlpLiDuews
 def Get_Now_Datetime(fyNVzJxHPFSboIgTdjaXrlpLiDuewt):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,mediacode,sel_quality,stype,pvrmode='-'):
  fyNVzJxHPFSboIgTdjaXrlpLiDuemO=''
  fyNVzJxHPFSboIgTdjaXrlpLiDuemU=''
  fyNVzJxHPFSboIgTdjaXrlpLiDuemA=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.TVING_UUID 
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    fyNVzJxHPFSboIgTdjaXrlpLiDuemB ='/v2a/media/stream/info' 
    fyNVzJxHPFSboIgTdjaXrlpLiDuemC=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetDefaultParams()
    fyNVzJxHPFSboIgTdjaXrlpLiDuemW={'info':'N','mediaCode':mediacode,'noCache':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','uuid':fyNVzJxHPFSboIgTdjaXrlpLiDuemA,'deviceInfo':'PC','wm':'Y'}
    fyNVzJxHPFSboIgTdjaXrlpLiDuemC.update(fyNVzJxHPFSboIgTdjaXrlpLiDuemW)
    fyNVzJxHPFSboIgTdjaXrlpLiDuemn=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.API_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemB
    fyNVzJxHPFSboIgTdjaXrlpLiDuewU=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.makeDefaultCookies()
    fyNVzJxHPFSboIgTdjaXrlpLiDuewY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.callRequestCookies('Get',fyNVzJxHPFSboIgTdjaXrlpLiDuemn,payload=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,params=fyNVzJxHPFSboIgTdjaXrlpLiDuemC,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDuewU)
    fyNVzJxHPFSboIgTdjaXrlpLiDuemk=json.loads(fyNVzJxHPFSboIgTdjaXrlpLiDuewY.text)
    if not('stream' in fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']):return fyNVzJxHPFSboIgTdjaXrlpLiDuemO,fyNVzJxHPFSboIgTdjaXrlpLiDuemU 
    fyNVzJxHPFSboIgTdjaXrlpLiDuemh=fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']['stream']
    fyNVzJxHPFSboIgTdjaXrlpLiDuemq=fyNVzJxHPFSboIgTdjaXrlpLiDuemh['quality']
    fyNVzJxHPFSboIgTdjaXrlpLiDuems=[]
    for fyNVzJxHPFSboIgTdjaXrlpLiDuemK in fyNVzJxHPFSboIgTdjaXrlpLiDuemq:
     if fyNVzJxHPFSboIgTdjaXrlpLiDuemK['active']=='Y':
      fyNVzJxHPFSboIgTdjaXrlpLiDuems.append({fyNVzJxHPFSboIgTdjaXrlpLiDuewQ.get(fyNVzJxHPFSboIgTdjaXrlpLiDuemK['code']):fyNVzJxHPFSboIgTdjaXrlpLiDuemK['code']})
    fyNVzJxHPFSboIgTdjaXrlpLiDuemM=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.CheckQuality(sel_quality,fyNVzJxHPFSboIgTdjaXrlpLiDuems)
   else:
    for fyNVzJxHPFSboIgTdjaXrlpLiDuemR,fyNVzJxHPFSboIgTdjaXrlpLiDueQE in fyNVzJxHPFSboIgTdjaXrlpLiDuewQ.items():
     if fyNVzJxHPFSboIgTdjaXrlpLiDueQE==sel_quality:
      fyNVzJxHPFSboIgTdjaXrlpLiDuemM=fyNVzJxHPFSboIgTdjaXrlpLiDuemR
  except fyNVzJxHPFSboIgTdjaXrlpLiDueEk as exception:
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(exception)
   for fyNVzJxHPFSboIgTdjaXrlpLiDuemR,fyNVzJxHPFSboIgTdjaXrlpLiDueQE in fyNVzJxHPFSboIgTdjaXrlpLiDuewQ.items():
    if fyNVzJxHPFSboIgTdjaXrlpLiDueQE==sel_quality:
     fyNVzJxHPFSboIgTdjaXrlpLiDuemM=fyNVzJxHPFSboIgTdjaXrlpLiDuemR
   return fyNVzJxHPFSboIgTdjaXrlpLiDuemO,fyNVzJxHPFSboIgTdjaXrlpLiDuemU
  fyNVzJxHPFSboIgTdjaXrlpLiDueEh(fyNVzJxHPFSboIgTdjaXrlpLiDuemM)
  try:
   fyNVzJxHPFSboIgTdjaXrlpLiDuemB ='/streaming/info'
   fyNVzJxHPFSboIgTdjaXrlpLiDuemC=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetDefaultParams()
   if stype=='onair':fyNVzJxHPFSboIgTdjaXrlpLiDuemC['osCode']='CSOD0400' 
   fyNVzJxHPFSboIgTdjaXrlpLiDuemG={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   fyNVzJxHPFSboIgTdjaXrlpLiDuemY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.makeOocUrl(fyNVzJxHPFSboIgTdjaXrlpLiDuemG)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemc=urllib.parse.quote(fyNVzJxHPFSboIgTdjaXrlpLiDuemY)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemW={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':fyNVzJxHPFSboIgTdjaXrlpLiDuemM,'adReq':'adproxy','ooc':fyNVzJxHPFSboIgTdjaXrlpLiDuemY,'uuid':fyNVzJxHPFSboIgTdjaXrlpLiDuemA,'deviceInfo':'PC'}
   fyNVzJxHPFSboIgTdjaXrlpLiDuemv =fyNVzJxHPFSboIgTdjaXrlpLiDuemC
   fyNVzJxHPFSboIgTdjaXrlpLiDuemv.update(fyNVzJxHPFSboIgTdjaXrlpLiDuemW)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemn=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.URL_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemB
   fyNVzJxHPFSboIgTdjaXrlpLiDueQw={'origin':'https://www.tving.com'}
   if stype=='onair':fyNVzJxHPFSboIgTdjaXrlpLiDueQw['Referer']='https://www.tving.com/live/player/'+mediacode
   else: fyNVzJxHPFSboIgTdjaXrlpLiDueQw['Referer']='https://www.tving.com/vod/player/'+mediacode
   fyNVzJxHPFSboIgTdjaXrlpLiDuewU=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.makeDefaultCookies()
   fyNVzJxHPFSboIgTdjaXrlpLiDuewU['onClickEvent2']=fyNVzJxHPFSboIgTdjaXrlpLiDuemc
   fyNVzJxHPFSboIgTdjaXrlpLiDuewY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.callRequestCookies('Post',fyNVzJxHPFSboIgTdjaXrlpLiDuemn,payload=fyNVzJxHPFSboIgTdjaXrlpLiDuemv,params=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueQw,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDuewU,redirects=fyNVzJxHPFSboIgTdjaXrlpLiDueEB)
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(fyNVzJxHPFSboIgTdjaXrlpLiDuewY.status_code)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemk=json.loads(fyNVzJxHPFSboIgTdjaXrlpLiDuewY.text)
   if 'drm_license_assertion' in fyNVzJxHPFSboIgTdjaXrlpLiDuemk['stream']:
    fyNVzJxHPFSboIgTdjaXrlpLiDuemU =fyNVzJxHPFSboIgTdjaXrlpLiDuemk['stream']['drm_license_assertion']
    fyNVzJxHPFSboIgTdjaXrlpLiDuemO=fyNVzJxHPFSboIgTdjaXrlpLiDuemk['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in fyNVzJxHPFSboIgTdjaXrlpLiDuemk['stream']['broadcast']):return fyNVzJxHPFSboIgTdjaXrlpLiDuemO,fyNVzJxHPFSboIgTdjaXrlpLiDuemU
    fyNVzJxHPFSboIgTdjaXrlpLiDuemO=fyNVzJxHPFSboIgTdjaXrlpLiDuemk['stream']['broadcast']['broad_url']
  except fyNVzJxHPFSboIgTdjaXrlpLiDueEk as exception:
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(exception)
  return fyNVzJxHPFSboIgTdjaXrlpLiDuemO,fyNVzJxHPFSboIgTdjaXrlpLiDuemU
 def CheckQuality(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,sel_qt,fyNVzJxHPFSboIgTdjaXrlpLiDuems):
  for fyNVzJxHPFSboIgTdjaXrlpLiDueQm in fyNVzJxHPFSboIgTdjaXrlpLiDuems:
   if sel_qt>=fyNVzJxHPFSboIgTdjaXrlpLiDueEs(fyNVzJxHPFSboIgTdjaXrlpLiDueQm)[0]:return fyNVzJxHPFSboIgTdjaXrlpLiDueQm.get(fyNVzJxHPFSboIgTdjaXrlpLiDueEs(fyNVzJxHPFSboIgTdjaXrlpLiDueQm)[0])
   fyNVzJxHPFSboIgTdjaXrlpLiDueQt=fyNVzJxHPFSboIgTdjaXrlpLiDueQm.get(fyNVzJxHPFSboIgTdjaXrlpLiDueEs(fyNVzJxHPFSboIgTdjaXrlpLiDueQm)[0])
  return fyNVzJxHPFSboIgTdjaXrlpLiDueQt
 def makeOocUrl(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,fyNVzJxHPFSboIgTdjaXrlpLiDuemG):
  fyNVzJxHPFSboIgTdjaXrlpLiDuemn=''
  for fyNVzJxHPFSboIgTdjaXrlpLiDuemR,fyNVzJxHPFSboIgTdjaXrlpLiDueQE in fyNVzJxHPFSboIgTdjaXrlpLiDuemG.items():
   fyNVzJxHPFSboIgTdjaXrlpLiDuemn+="%s=%s^"%(fyNVzJxHPFSboIgTdjaXrlpLiDuemR,fyNVzJxHPFSboIgTdjaXrlpLiDueQE)
  return fyNVzJxHPFSboIgTdjaXrlpLiDuemn
 def GetLiveChannelList(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,stype,page_int):
  fyNVzJxHPFSboIgTdjaXrlpLiDueQO=[]
  fyNVzJxHPFSboIgTdjaXrlpLiDueQU=fyNVzJxHPFSboIgTdjaXrlpLiDueEB
  try:
   fyNVzJxHPFSboIgTdjaXrlpLiDuemB ='/v2/media/lives'
   if stype=='onair':
    fyNVzJxHPFSboIgTdjaXrlpLiDueQA='CPCS0100,CPCS0400'
   else:
    fyNVzJxHPFSboIgTdjaXrlpLiDueQA='CPCS0300'
   fyNVzJxHPFSboIgTdjaXrlpLiDuemC=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetDefaultParams()
   fyNVzJxHPFSboIgTdjaXrlpLiDuemW={'pageNo':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(page_int),'pageSize':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':fyNVzJxHPFSboIgTdjaXrlpLiDueQA,'_':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetNoCache(2))}
   fyNVzJxHPFSboIgTdjaXrlpLiDuemC.update(fyNVzJxHPFSboIgTdjaXrlpLiDuemW)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemn=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.API_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemB
   fyNVzJxHPFSboIgTdjaXrlpLiDuewU=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.makeDefaultCookies()
   fyNVzJxHPFSboIgTdjaXrlpLiDuewY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.callRequestCookies('Get',fyNVzJxHPFSboIgTdjaXrlpLiDuemn,payload=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,params=fyNVzJxHPFSboIgTdjaXrlpLiDuemC,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDuewU)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemk=json.loads(fyNVzJxHPFSboIgTdjaXrlpLiDuewY.text)
   if not('result' in fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']):return fyNVzJxHPFSboIgTdjaXrlpLiDueQO,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
   fyNVzJxHPFSboIgTdjaXrlpLiDueQB=fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']['result']
   for fyNVzJxHPFSboIgTdjaXrlpLiDuemK in fyNVzJxHPFSboIgTdjaXrlpLiDueQB:
    fyNVzJxHPFSboIgTdjaXrlpLiDueQC={}
    fyNVzJxHPFSboIgTdjaXrlpLiDueQC['mediatype']='video'
    fyNVzJxHPFSboIgTdjaXrlpLiDueQW=fyNVzJxHPFSboIgTdjaXrlpLiDueQh=fyNVzJxHPFSboIgTdjaXrlpLiDueQq=fyNVzJxHPFSboIgTdjaXrlpLiDueQs=''
    fyNVzJxHPFSboIgTdjaXrlpLiDueQn=fyNVzJxHPFSboIgTdjaXrlpLiDueQG=''
    fyNVzJxHPFSboIgTdjaXrlpLiDueQk=fyNVzJxHPFSboIgTdjaXrlpLiDuemK['live_code']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQW =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['channel']['name']['ko']
    if fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['episode']!=fyNVzJxHPFSboIgTdjaXrlpLiDueEA:
     fyNVzJxHPFSboIgTdjaXrlpLiDueQh =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['program']['name']['ko']
     fyNVzJxHPFSboIgTdjaXrlpLiDueQh =fyNVzJxHPFSboIgTdjaXrlpLiDueQh+', '+fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['episode']['frequency'])+'회'
     if fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['episode']['image']!=[]:
      fyNVzJxHPFSboIgTdjaXrlpLiDueQq=fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['episode']['image'][0]['url']
     fyNVzJxHPFSboIgTdjaXrlpLiDueQs=fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['episode']['synopsis']['ko']
    else:
     fyNVzJxHPFSboIgTdjaXrlpLiDueQh =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['program']['name']['ko']
     if fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['program']['image']!=[]:
      fyNVzJxHPFSboIgTdjaXrlpLiDueQq=fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['program']['image'][0]['url']
     fyNVzJxHPFSboIgTdjaXrlpLiDueQs=fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['program']['synopsis']['ko']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQC['title'] =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['program']['name']['ko']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQC['studio'] =fyNVzJxHPFSboIgTdjaXrlpLiDueQW
    try:
     fyNVzJxHPFSboIgTdjaXrlpLiDueQK=[]
     for fyNVzJxHPFSboIgTdjaXrlpLiDueQM in fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('schedule').get('program').get('actor'):fyNVzJxHPFSboIgTdjaXrlpLiDueQK.append(fyNVzJxHPFSboIgTdjaXrlpLiDueQM)
     if fyNVzJxHPFSboIgTdjaXrlpLiDueQK[0]!='' and fyNVzJxHPFSboIgTdjaXrlpLiDueQK[0]!=u'없음':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['cast']=fyNVzJxHPFSboIgTdjaXrlpLiDueQK
    except:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEA
    try:
     fyNVzJxHPFSboIgTdjaXrlpLiDueQR=[]
     if fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('schedule').get('program').get('category1_name').get('ko')!='':
      fyNVzJxHPFSboIgTdjaXrlpLiDueQR.append(fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['program']['category1_name']['ko'])
     if fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('schedule').get('program').get('category2_name').get('ko')!='':
      fyNVzJxHPFSboIgTdjaXrlpLiDueQR.append(fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['program']['category2_name']['ko'])
     if fyNVzJxHPFSboIgTdjaXrlpLiDueQR[0]!='':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['genre']=fyNVzJxHPFSboIgTdjaXrlpLiDueQR
    except:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEA
    if fyNVzJxHPFSboIgTdjaXrlpLiDueQq=='':
     fyNVzJxHPFSboIgTdjaXrlpLiDueQq=fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['channel']['image'][0]['url']
    if fyNVzJxHPFSboIgTdjaXrlpLiDueQq!='':fyNVzJxHPFSboIgTdjaXrlpLiDueQq=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDueQq
    fyNVzJxHPFSboIgTdjaXrlpLiDueQn=fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['broadcast_start_time'])[8:12]
    fyNVzJxHPFSboIgTdjaXrlpLiDueQG =fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuemK['schedule']['broadcast_end_time'])[8:12]
    fyNVzJxHPFSboIgTdjaXrlpLiDueQY={'channel':fyNVzJxHPFSboIgTdjaXrlpLiDueQW,'title':fyNVzJxHPFSboIgTdjaXrlpLiDueQh,'mediacode':fyNVzJxHPFSboIgTdjaXrlpLiDueQk,'thumbnail':fyNVzJxHPFSboIgTdjaXrlpLiDueQq,'synopsis':fyNVzJxHPFSboIgTdjaXrlpLiDueQs,'channelepg':' [%s:%s ~ %s:%s]'%(fyNVzJxHPFSboIgTdjaXrlpLiDueQn[0:2],fyNVzJxHPFSboIgTdjaXrlpLiDueQn[2:],fyNVzJxHPFSboIgTdjaXrlpLiDueQG[0:2],fyNVzJxHPFSboIgTdjaXrlpLiDueQG[2:]),'info':fyNVzJxHPFSboIgTdjaXrlpLiDueQC}
    fyNVzJxHPFSboIgTdjaXrlpLiDueQO.append(fyNVzJxHPFSboIgTdjaXrlpLiDueQY)
   if fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']['has_more']=='Y':fyNVzJxHPFSboIgTdjaXrlpLiDueQU=fyNVzJxHPFSboIgTdjaXrlpLiDueEn
  except fyNVzJxHPFSboIgTdjaXrlpLiDueEk as exception:
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(exception)
  return fyNVzJxHPFSboIgTdjaXrlpLiDueQO,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
 def GetProgramList(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,genre,orderby,page_int,landyn=fyNVzJxHPFSboIgTdjaXrlpLiDueEB):
  fyNVzJxHPFSboIgTdjaXrlpLiDueQO=[]
  fyNVzJxHPFSboIgTdjaXrlpLiDueQU=fyNVzJxHPFSboIgTdjaXrlpLiDueEB
  try:
   fyNVzJxHPFSboIgTdjaXrlpLiDuemB ='/v2/media/episodes'
   fyNVzJxHPFSboIgTdjaXrlpLiDuemC=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetDefaultParams()
   fyNVzJxHPFSboIgTdjaXrlpLiDuemW={'pageNo':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(page_int),'pageSize':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetNoCache(2))}
   if genre!='all':fyNVzJxHPFSboIgTdjaXrlpLiDuemW['multiCategoryCode']=genre
   fyNVzJxHPFSboIgTdjaXrlpLiDuemC.update(fyNVzJxHPFSboIgTdjaXrlpLiDuemW)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemn=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.API_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemB
   fyNVzJxHPFSboIgTdjaXrlpLiDuewU=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.makeDefaultCookies()
   fyNVzJxHPFSboIgTdjaXrlpLiDuewY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.callRequestCookies('Get',fyNVzJxHPFSboIgTdjaXrlpLiDuemn,payload=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,params=fyNVzJxHPFSboIgTdjaXrlpLiDuemC,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDuewU)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemk=json.loads(fyNVzJxHPFSboIgTdjaXrlpLiDuewY.text)
   if not('result' in fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']):return fyNVzJxHPFSboIgTdjaXrlpLiDueQO,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
   fyNVzJxHPFSboIgTdjaXrlpLiDueQB=fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']['result']
   for fyNVzJxHPFSboIgTdjaXrlpLiDuemK in fyNVzJxHPFSboIgTdjaXrlpLiDueQB:
    fyNVzJxHPFSboIgTdjaXrlpLiDueQc=fyNVzJxHPFSboIgTdjaXrlpLiDuemK['program']['code']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQh =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['program']['name']['ko']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQq =fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemK['program']['image'][0]['url']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQv='CAIP0200' if landyn else 'CAIP0900' 
    for fyNVzJxHPFSboIgTdjaXrlpLiDuetw in fyNVzJxHPFSboIgTdjaXrlpLiDuemK['program']['image']:
     if fyNVzJxHPFSboIgTdjaXrlpLiDuetw['code']==fyNVzJxHPFSboIgTdjaXrlpLiDueQv:
      fyNVzJxHPFSboIgTdjaXrlpLiDueQq =fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuetw['url']
      break
    fyNVzJxHPFSboIgTdjaXrlpLiDueQs =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['program']['synopsis']['ko']
    fyNVzJxHPFSboIgTdjaXrlpLiDuetm=fyNVzJxHPFSboIgTdjaXrlpLiDuemK['program']['channel_code']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQC={}
    fyNVzJxHPFSboIgTdjaXrlpLiDueQC['title'] =fyNVzJxHPFSboIgTdjaXrlpLiDueQh 
    fyNVzJxHPFSboIgTdjaXrlpLiDueQC['mediatype']='episode' 
    try:
     fyNVzJxHPFSboIgTdjaXrlpLiDueQK=[]
     for fyNVzJxHPFSboIgTdjaXrlpLiDueQM in fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('program').get('actor'):fyNVzJxHPFSboIgTdjaXrlpLiDueQK.append(fyNVzJxHPFSboIgTdjaXrlpLiDueQM)
     if fyNVzJxHPFSboIgTdjaXrlpLiDueQK[0]!='' and fyNVzJxHPFSboIgTdjaXrlpLiDueQK[0]!='-':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['cast']=fyNVzJxHPFSboIgTdjaXrlpLiDueQK
    except:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEA
    try:
     fyNVzJxHPFSboIgTdjaXrlpLiDuetQ=[]
     for fyNVzJxHPFSboIgTdjaXrlpLiDuetE in fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('program').get('director'):fyNVzJxHPFSboIgTdjaXrlpLiDuetQ.append(fyNVzJxHPFSboIgTdjaXrlpLiDuetE)
     if fyNVzJxHPFSboIgTdjaXrlpLiDuetQ[0]!='' and fyNVzJxHPFSboIgTdjaXrlpLiDuetQ[0]!='-':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['director']=fyNVzJxHPFSboIgTdjaXrlpLiDuetQ
    except:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEA
    fyNVzJxHPFSboIgTdjaXrlpLiDueQR=[]
    if fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('program').get('category1_name').get('ko')!='':
     fyNVzJxHPFSboIgTdjaXrlpLiDueQR.append(fyNVzJxHPFSboIgTdjaXrlpLiDuemK['program']['category1_name']['ko'])
    if fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('program').get('category2_name').get('ko')!='':
     fyNVzJxHPFSboIgTdjaXrlpLiDueQR.append(fyNVzJxHPFSboIgTdjaXrlpLiDuemK['program']['category2_name']['ko'])
    if fyNVzJxHPFSboIgTdjaXrlpLiDueQR[0]!='':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['genre']=fyNVzJxHPFSboIgTdjaXrlpLiDueQR
    try:
     if fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('program').get('product_year'):fyNVzJxHPFSboIgTdjaXrlpLiDueQC['year']=fyNVzJxHPFSboIgTdjaXrlpLiDuemK['program']['product_year']
     if 'broad_dt' in fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('program'):
      fyNVzJxHPFSboIgTdjaXrlpLiDuetO=fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('program').get('broad_dt')
      fyNVzJxHPFSboIgTdjaXrlpLiDueQC['aired']='%s-%s-%s'%(fyNVzJxHPFSboIgTdjaXrlpLiDuetO[:4],fyNVzJxHPFSboIgTdjaXrlpLiDuetO[4:6],fyNVzJxHPFSboIgTdjaXrlpLiDuetO[6:])
    except:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEA
    fyNVzJxHPFSboIgTdjaXrlpLiDueQY={'program':fyNVzJxHPFSboIgTdjaXrlpLiDueQc,'title':fyNVzJxHPFSboIgTdjaXrlpLiDueQh,'thumbnail':fyNVzJxHPFSboIgTdjaXrlpLiDueQq,'synopsis':fyNVzJxHPFSboIgTdjaXrlpLiDueQs,'channel':fyNVzJxHPFSboIgTdjaXrlpLiDuetm,'info':fyNVzJxHPFSboIgTdjaXrlpLiDueQC}
    fyNVzJxHPFSboIgTdjaXrlpLiDueQO.append(fyNVzJxHPFSboIgTdjaXrlpLiDueQY)
   if fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']['has_more']=='Y':fyNVzJxHPFSboIgTdjaXrlpLiDueQU=fyNVzJxHPFSboIgTdjaXrlpLiDueEn
  except fyNVzJxHPFSboIgTdjaXrlpLiDueEk as exception:
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(exception)
  return fyNVzJxHPFSboIgTdjaXrlpLiDueQO,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
 def GetEpisodoList(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,program_code,page_int,orderby='desc'):
  fyNVzJxHPFSboIgTdjaXrlpLiDueQO=[]
  fyNVzJxHPFSboIgTdjaXrlpLiDueQU=fyNVzJxHPFSboIgTdjaXrlpLiDueEB
  try:
   fyNVzJxHPFSboIgTdjaXrlpLiDuemB ='/v2/media/frequency/program/'+program_code
   fyNVzJxHPFSboIgTdjaXrlpLiDuemC=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetDefaultParams()
   fyNVzJxHPFSboIgTdjaXrlpLiDuemW={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetNoCache(2))}
   fyNVzJxHPFSboIgTdjaXrlpLiDuemC.update(fyNVzJxHPFSboIgTdjaXrlpLiDuemW)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemn=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.API_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemB
   fyNVzJxHPFSboIgTdjaXrlpLiDuewU=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.makeDefaultCookies()
   fyNVzJxHPFSboIgTdjaXrlpLiDuewY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.callRequestCookies('Get',fyNVzJxHPFSboIgTdjaXrlpLiDuemn,payload=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,params=fyNVzJxHPFSboIgTdjaXrlpLiDuemC,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDuewU)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemk=json.loads(fyNVzJxHPFSboIgTdjaXrlpLiDuewY.text)
   if not('result' in fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']):return fyNVzJxHPFSboIgTdjaXrlpLiDueQO,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
   fyNVzJxHPFSboIgTdjaXrlpLiDueQB=fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']['result']
   fyNVzJxHPFSboIgTdjaXrlpLiDuetU=fyNVzJxHPFSboIgTdjaXrlpLiDueEC(fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']['total_count'])
   fyNVzJxHPFSboIgTdjaXrlpLiDuetA =fyNVzJxHPFSboIgTdjaXrlpLiDueEC(fyNVzJxHPFSboIgTdjaXrlpLiDuetU//(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    fyNVzJxHPFSboIgTdjaXrlpLiDuetB =(fyNVzJxHPFSboIgTdjaXrlpLiDuetU-1)-((page_int-1)*fyNVzJxHPFSboIgTdjaXrlpLiDuewt.EPISODE_LIMIT)
   else:
    fyNVzJxHPFSboIgTdjaXrlpLiDuetB =(page_int-1)*fyNVzJxHPFSboIgTdjaXrlpLiDuewt.EPISODE_LIMIT
   for i in fyNVzJxHPFSboIgTdjaXrlpLiDueEW(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.EPISODE_LIMIT):
    if orderby=='desc':
     fyNVzJxHPFSboIgTdjaXrlpLiDuetC=fyNVzJxHPFSboIgTdjaXrlpLiDuetB-i
     if fyNVzJxHPFSboIgTdjaXrlpLiDuetC<0:break
    else:
     fyNVzJxHPFSboIgTdjaXrlpLiDuetC=fyNVzJxHPFSboIgTdjaXrlpLiDuetB+i
     if fyNVzJxHPFSboIgTdjaXrlpLiDuetC>=fyNVzJxHPFSboIgTdjaXrlpLiDuetU:break
    fyNVzJxHPFSboIgTdjaXrlpLiDuetW=fyNVzJxHPFSboIgTdjaXrlpLiDueQB[fyNVzJxHPFSboIgTdjaXrlpLiDuetC]['episode']['code']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQh =fyNVzJxHPFSboIgTdjaXrlpLiDueQB[fyNVzJxHPFSboIgTdjaXrlpLiDuetC]['vod_name']['ko']
    fyNVzJxHPFSboIgTdjaXrlpLiDuetn =''
    try:
     fyNVzJxHPFSboIgTdjaXrlpLiDuetO=fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDueQB[fyNVzJxHPFSboIgTdjaXrlpLiDuetC]['episode']['broadcast_date'])
     fyNVzJxHPFSboIgTdjaXrlpLiDuetn='%s-%s-%s'%(fyNVzJxHPFSboIgTdjaXrlpLiDuetO[:4],fyNVzJxHPFSboIgTdjaXrlpLiDuetO[4:6],fyNVzJxHPFSboIgTdjaXrlpLiDuetO[6:])
    except:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEA
    if fyNVzJxHPFSboIgTdjaXrlpLiDueQB[fyNVzJxHPFSboIgTdjaXrlpLiDuetC]['episode']['image']!=[]:
     fyNVzJxHPFSboIgTdjaXrlpLiDueQq=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDueQB[fyNVzJxHPFSboIgTdjaXrlpLiDuetC]['episode']['image'][0]['url']
    else:
     fyNVzJxHPFSboIgTdjaXrlpLiDueQq=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDueQB[fyNVzJxHPFSboIgTdjaXrlpLiDuetC]['program']['image'][0]['url']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQs =fyNVzJxHPFSboIgTdjaXrlpLiDueQB[fyNVzJxHPFSboIgTdjaXrlpLiDuetC]['episode']['synopsis']['ko']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQC={}
    fyNVzJxHPFSboIgTdjaXrlpLiDueQC['mediatype']='episode' 
    try:
     fyNVzJxHPFSboIgTdjaXrlpLiDueQC['title'] =fyNVzJxHPFSboIgTdjaXrlpLiDueQB[fyNVzJxHPFSboIgTdjaXrlpLiDuetC]['program']['name']['ko']
     fyNVzJxHPFSboIgTdjaXrlpLiDueQC['aired'] =fyNVzJxHPFSboIgTdjaXrlpLiDuetn
     fyNVzJxHPFSboIgTdjaXrlpLiDueQC['studio'] =fyNVzJxHPFSboIgTdjaXrlpLiDueQB[fyNVzJxHPFSboIgTdjaXrlpLiDuetC]['channel']['name']['ko']
     if 'frequency' in fyNVzJxHPFSboIgTdjaXrlpLiDueQB[fyNVzJxHPFSboIgTdjaXrlpLiDuetC]['episode']:fyNVzJxHPFSboIgTdjaXrlpLiDueQC['episode']=fyNVzJxHPFSboIgTdjaXrlpLiDueQB[fyNVzJxHPFSboIgTdjaXrlpLiDuetC]['episode']['frequency']
    except:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEA
    fyNVzJxHPFSboIgTdjaXrlpLiDueQY={'episode':fyNVzJxHPFSboIgTdjaXrlpLiDuetW,'title':fyNVzJxHPFSboIgTdjaXrlpLiDueQh,'subtitle':fyNVzJxHPFSboIgTdjaXrlpLiDuetn,'thumbnail':fyNVzJxHPFSboIgTdjaXrlpLiDueQq,'synopsis':fyNVzJxHPFSboIgTdjaXrlpLiDueQs,'info':fyNVzJxHPFSboIgTdjaXrlpLiDueQC}
    fyNVzJxHPFSboIgTdjaXrlpLiDueQO.append(fyNVzJxHPFSboIgTdjaXrlpLiDueQY)
   if fyNVzJxHPFSboIgTdjaXrlpLiDuetA>page_int:fyNVzJxHPFSboIgTdjaXrlpLiDueQU=fyNVzJxHPFSboIgTdjaXrlpLiDueEn
  except fyNVzJxHPFSboIgTdjaXrlpLiDueEk as exception:
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(exception)
  return fyNVzJxHPFSboIgTdjaXrlpLiDueQO,fyNVzJxHPFSboIgTdjaXrlpLiDueQU,fyNVzJxHPFSboIgTdjaXrlpLiDuetA
 def GetMovieList(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,genre,orderby,page_int,landyn=fyNVzJxHPFSboIgTdjaXrlpLiDueEB):
  fyNVzJxHPFSboIgTdjaXrlpLiDueQO=[]
  fyNVzJxHPFSboIgTdjaXrlpLiDueQU=fyNVzJxHPFSboIgTdjaXrlpLiDueEB
  try:
   fyNVzJxHPFSboIgTdjaXrlpLiDuemB ='/v2/media/movies'
   fyNVzJxHPFSboIgTdjaXrlpLiDuemC=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetDefaultParams()
   fyNVzJxHPFSboIgTdjaXrlpLiDuemW={'pageNo':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(page_int),'pageSize':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetNoCache(2))}
   if genre!='all' :fyNVzJxHPFSboIgTdjaXrlpLiDuemW['multiCategoryCode']=genre
   if orderby=='new':fyNVzJxHPFSboIgTdjaXrlpLiDuemW['productPackageCode']=','.join(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.MOVIE_LITE)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemC.update(fyNVzJxHPFSboIgTdjaXrlpLiDuemW)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemn=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.API_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemB
   fyNVzJxHPFSboIgTdjaXrlpLiDuewU=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.makeDefaultCookies()
   fyNVzJxHPFSboIgTdjaXrlpLiDuewY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.callRequestCookies('Get',fyNVzJxHPFSboIgTdjaXrlpLiDuemn,payload=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,params=fyNVzJxHPFSboIgTdjaXrlpLiDuemC,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDuewU)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemk=json.loads(fyNVzJxHPFSboIgTdjaXrlpLiDuewY.text)
   if not('result' in fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']):return fyNVzJxHPFSboIgTdjaXrlpLiDueQO,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
   fyNVzJxHPFSboIgTdjaXrlpLiDueQB=fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']['result']
   for fyNVzJxHPFSboIgTdjaXrlpLiDuemK in fyNVzJxHPFSboIgTdjaXrlpLiDueQB:
    fyNVzJxHPFSboIgTdjaXrlpLiDuetk =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['movie']['code']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQh =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['movie']['name']['ko'].strip()
    fyNVzJxHPFSboIgTdjaXrlpLiDueQh +=u' (%s년)'%(fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('movie').get('product_year'))
    fyNVzJxHPFSboIgTdjaXrlpLiDueQq =fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemK['movie']['image'][0]['url']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQv='CAIM0400' if landyn else 'CAIM2100' 
    for fyNVzJxHPFSboIgTdjaXrlpLiDuetw in fyNVzJxHPFSboIgTdjaXrlpLiDuemK['movie']['image']:
     if fyNVzJxHPFSboIgTdjaXrlpLiDuetw['code']==fyNVzJxHPFSboIgTdjaXrlpLiDueQv:
      fyNVzJxHPFSboIgTdjaXrlpLiDueQq =fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuetw['url']
      break
    fyNVzJxHPFSboIgTdjaXrlpLiDueQs =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['movie']['story']['ko']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQC={}
    fyNVzJxHPFSboIgTdjaXrlpLiDueQC['mediatype']='movie' 
    fyNVzJxHPFSboIgTdjaXrlpLiDueQC['title'] = fyNVzJxHPFSboIgTdjaXrlpLiDuemK['movie']['name']['ko'].strip()
    fyNVzJxHPFSboIgTdjaXrlpLiDueQC['year'] =fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('movie').get('product_year')
    try:
     fyNVzJxHPFSboIgTdjaXrlpLiDueQK=[]
     for fyNVzJxHPFSboIgTdjaXrlpLiDueQM in fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('movie').get('actor'):fyNVzJxHPFSboIgTdjaXrlpLiDueQK.append(fyNVzJxHPFSboIgTdjaXrlpLiDueQM)
     if fyNVzJxHPFSboIgTdjaXrlpLiDueQK[0]!='':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['cast']=fyNVzJxHPFSboIgTdjaXrlpLiDueQK
    except:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEA
    try:
     fyNVzJxHPFSboIgTdjaXrlpLiDuetQ=[]
     for fyNVzJxHPFSboIgTdjaXrlpLiDuetE in fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('movie').get('director'):fyNVzJxHPFSboIgTdjaXrlpLiDuetQ.append(fyNVzJxHPFSboIgTdjaXrlpLiDuetE)
     if fyNVzJxHPFSboIgTdjaXrlpLiDuetQ[0]!='':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['director']=fyNVzJxHPFSboIgTdjaXrlpLiDuetQ
    except:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEA
    try:
     fyNVzJxHPFSboIgTdjaXrlpLiDueQR=[]
     if fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('movie').get('category1_name').get('ko')!='':
      fyNVzJxHPFSboIgTdjaXrlpLiDueQR.append(fyNVzJxHPFSboIgTdjaXrlpLiDuemK['movie']['category1_name']['ko'])
     if fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('movie').get('category2_name').get('ko')!='':
      fyNVzJxHPFSboIgTdjaXrlpLiDueQR.append(fyNVzJxHPFSboIgTdjaXrlpLiDuemK['movie']['category2_name']['ko'])
     if fyNVzJxHPFSboIgTdjaXrlpLiDueQR[0]!='':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['genre']=fyNVzJxHPFSboIgTdjaXrlpLiDueQR
    except:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEA
    try:
     if 'release_date' in fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('movie'):
      fyNVzJxHPFSboIgTdjaXrlpLiDuetO=fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('movie').get('release_date'))
      fyNVzJxHPFSboIgTdjaXrlpLiDueQC['aired']='%s-%s-%s'%(fyNVzJxHPFSboIgTdjaXrlpLiDuetO[:4],fyNVzJxHPFSboIgTdjaXrlpLiDuetO[4:6],fyNVzJxHPFSboIgTdjaXrlpLiDuetO[6:])
    except:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEA
    try:
     if 'duration' in fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('movie'):fyNVzJxHPFSboIgTdjaXrlpLiDueQC['duration']=fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('movie').get('duration')
    except:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEA
    fyNVzJxHPFSboIgTdjaXrlpLiDueQY={'moviecode':fyNVzJxHPFSboIgTdjaXrlpLiDuetk,'title':fyNVzJxHPFSboIgTdjaXrlpLiDueQh,'thumbnail':fyNVzJxHPFSboIgTdjaXrlpLiDueQq,'synopsis':fyNVzJxHPFSboIgTdjaXrlpLiDueQs,'info':fyNVzJxHPFSboIgTdjaXrlpLiDueQC}
    fyNVzJxHPFSboIgTdjaXrlpLiDueth=fyNVzJxHPFSboIgTdjaXrlpLiDueEB
    for fyNVzJxHPFSboIgTdjaXrlpLiDuetq in fyNVzJxHPFSboIgTdjaXrlpLiDuemK['billing_package_id']:
     if fyNVzJxHPFSboIgTdjaXrlpLiDuetq in fyNVzJxHPFSboIgTdjaXrlpLiDuewt.MOVIE_LITE:
      fyNVzJxHPFSboIgTdjaXrlpLiDueth=fyNVzJxHPFSboIgTdjaXrlpLiDueEn
      break
    if fyNVzJxHPFSboIgTdjaXrlpLiDueth==fyNVzJxHPFSboIgTdjaXrlpLiDueEB: 
     fyNVzJxHPFSboIgTdjaXrlpLiDueQY['title']=fyNVzJxHPFSboIgTdjaXrlpLiDueQY['title']+' [개별구매]'
    fyNVzJxHPFSboIgTdjaXrlpLiDueQO.append(fyNVzJxHPFSboIgTdjaXrlpLiDueQY)
   if fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']['has_more']=='Y':fyNVzJxHPFSboIgTdjaXrlpLiDueQU=fyNVzJxHPFSboIgTdjaXrlpLiDueEn
  except fyNVzJxHPFSboIgTdjaXrlpLiDueEk as exception:
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(exception)
  return fyNVzJxHPFSboIgTdjaXrlpLiDueQO,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
 def GetMovieListGenre(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,genre,page_int):
  fyNVzJxHPFSboIgTdjaXrlpLiDueQO=[]
  fyNVzJxHPFSboIgTdjaXrlpLiDueQU=fyNVzJxHPFSboIgTdjaXrlpLiDueEB
  try:
   fyNVzJxHPFSboIgTdjaXrlpLiDuemB ='/v2/media/movie/curation/'+genre
   fyNVzJxHPFSboIgTdjaXrlpLiDuemC=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetDefaultParams()
   fyNVzJxHPFSboIgTdjaXrlpLiDuemW={'pageNo':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(page_int),'pageSize':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.MOVIE_LIMIT),'_':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetNoCache(2))}
   fyNVzJxHPFSboIgTdjaXrlpLiDuemC.update(fyNVzJxHPFSboIgTdjaXrlpLiDuemW)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemn=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.API_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemB
   fyNVzJxHPFSboIgTdjaXrlpLiDuewU=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.makeDefaultCookies()
   fyNVzJxHPFSboIgTdjaXrlpLiDuewY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.callRequestCookies('Get',fyNVzJxHPFSboIgTdjaXrlpLiDuemn,payload=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,params=fyNVzJxHPFSboIgTdjaXrlpLiDuemC,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDuewU)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemk=json.loads(fyNVzJxHPFSboIgTdjaXrlpLiDuewY.text)
   if not('movies' in fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']):return fyNVzJxHPFSboIgTdjaXrlpLiDueQO,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
   fyNVzJxHPFSboIgTdjaXrlpLiDueQB=fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']['movies']
   for fyNVzJxHPFSboIgTdjaXrlpLiDuemK in fyNVzJxHPFSboIgTdjaXrlpLiDueQB:
    fyNVzJxHPFSboIgTdjaXrlpLiDuetk =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['code']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQh =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['name']['ko']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQq =fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemK['image'][0]['url']
    for fyNVzJxHPFSboIgTdjaXrlpLiDuetw in fyNVzJxHPFSboIgTdjaXrlpLiDuemK['image']:
     if fyNVzJxHPFSboIgTdjaXrlpLiDuetw['code']=='CAIM2100':
      fyNVzJxHPFSboIgTdjaXrlpLiDueQq =fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuetw['url']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQs =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['story']['ko']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQY={'moviecode':fyNVzJxHPFSboIgTdjaXrlpLiDuetk,'title':fyNVzJxHPFSboIgTdjaXrlpLiDueQh.strip(),'thumbnail':fyNVzJxHPFSboIgTdjaXrlpLiDueQq,'synopsis':fyNVzJxHPFSboIgTdjaXrlpLiDueQs}
    fyNVzJxHPFSboIgTdjaXrlpLiDueQO.append(fyNVzJxHPFSboIgTdjaXrlpLiDueQY)
  except fyNVzJxHPFSboIgTdjaXrlpLiDueEk as exception:
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(exception)
  return fyNVzJxHPFSboIgTdjaXrlpLiDueQO,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
 def GetMovieGenre(fyNVzJxHPFSboIgTdjaXrlpLiDuewt):
  fyNVzJxHPFSboIgTdjaXrlpLiDueQO=[]
  fyNVzJxHPFSboIgTdjaXrlpLiDueQU=fyNVzJxHPFSboIgTdjaXrlpLiDueEB
  try:
   fyNVzJxHPFSboIgTdjaXrlpLiDuemB ='/v2/media/movie/curations'
   fyNVzJxHPFSboIgTdjaXrlpLiDuemC=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetDefaultParams()
   fyNVzJxHPFSboIgTdjaXrlpLiDuemW={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetNoCache(2))}
   fyNVzJxHPFSboIgTdjaXrlpLiDuemC.update(fyNVzJxHPFSboIgTdjaXrlpLiDuemW)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemn=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.API_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemB
   fyNVzJxHPFSboIgTdjaXrlpLiDuewU=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.makeDefaultCookies()
   fyNVzJxHPFSboIgTdjaXrlpLiDuewY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.callRequestCookies('Get',fyNVzJxHPFSboIgTdjaXrlpLiDuemn,payload=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,params=fyNVzJxHPFSboIgTdjaXrlpLiDuemC,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDuewU)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemk=json.loads(fyNVzJxHPFSboIgTdjaXrlpLiDuewY.text)
   if not('result' in fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']):return fyNVzJxHPFSboIgTdjaXrlpLiDueQO,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
   fyNVzJxHPFSboIgTdjaXrlpLiDueQB=fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']['result']
   for fyNVzJxHPFSboIgTdjaXrlpLiDuemK in fyNVzJxHPFSboIgTdjaXrlpLiDueQB:
    fyNVzJxHPFSboIgTdjaXrlpLiDuets =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['curation_code']
    fyNVzJxHPFSboIgTdjaXrlpLiDuetK =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['curation_name']
    fyNVzJxHPFSboIgTdjaXrlpLiDueQY={'curation_code':fyNVzJxHPFSboIgTdjaXrlpLiDuets,'curation_name':fyNVzJxHPFSboIgTdjaXrlpLiDuetK}
    fyNVzJxHPFSboIgTdjaXrlpLiDueQO.append(fyNVzJxHPFSboIgTdjaXrlpLiDueQY)
  except fyNVzJxHPFSboIgTdjaXrlpLiDueEk as exception:
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(exception)
  return fyNVzJxHPFSboIgTdjaXrlpLiDueQO,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
 def GetSearchList(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,search_key,userid,page_int,stype,landyn=fyNVzJxHPFSboIgTdjaXrlpLiDueEB):
  fyNVzJxHPFSboIgTdjaXrlpLiDuetM=[]
  fyNVzJxHPFSboIgTdjaXrlpLiDueQU=fyNVzJxHPFSboIgTdjaXrlpLiDueEB
  try:
   fyNVzJxHPFSboIgTdjaXrlpLiDuemB ='/search/getSearch.jsp'
   fyNVzJxHPFSboIgTdjaXrlpLiDuemW={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(page_int),'pageSize':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.SCREENCODE,'os':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.OSCODE,'network':fyNVzJxHPFSboIgTdjaXrlpLiDuewt.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.SEARCH_LIMIT),'vodMVReqCnt':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':fyNVzJxHPFSboIgTdjaXrlpLiDueEq(fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GetNoCache(2))}
   fyNVzJxHPFSboIgTdjaXrlpLiDuemn=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.SEARCH_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemB
   fyNVzJxHPFSboIgTdjaXrlpLiDuewU=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.makeDefaultCookies()
   fyNVzJxHPFSboIgTdjaXrlpLiDuewY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.callRequestCookies('Get',fyNVzJxHPFSboIgTdjaXrlpLiDuemn,payload=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,params=fyNVzJxHPFSboIgTdjaXrlpLiDuemW,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDuewU)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemk=json.loads(fyNVzJxHPFSboIgTdjaXrlpLiDuewY.text)
   if stype=='vod':
    if not('programRsb' in fyNVzJxHPFSboIgTdjaXrlpLiDuemk):return fyNVzJxHPFSboIgTdjaXrlpLiDuetM,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
    fyNVzJxHPFSboIgTdjaXrlpLiDuetR=fyNVzJxHPFSboIgTdjaXrlpLiDuemk['programRsb']['dataList']
    fyNVzJxHPFSboIgTdjaXrlpLiDuetG =fyNVzJxHPFSboIgTdjaXrlpLiDueEC(fyNVzJxHPFSboIgTdjaXrlpLiDuemk['programRsb']['count'])
    for fyNVzJxHPFSboIgTdjaXrlpLiDuemK in fyNVzJxHPFSboIgTdjaXrlpLiDuetR:
     fyNVzJxHPFSboIgTdjaXrlpLiDueQc=fyNVzJxHPFSboIgTdjaXrlpLiDuemK['mast_cd']
     fyNVzJxHPFSboIgTdjaXrlpLiDueQh =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['mast_nm']
     fyNVzJxHPFSboIgTdjaXrlpLiDueQq =fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemK['web_url']
     if landyn==fyNVzJxHPFSboIgTdjaXrlpLiDueEB:
      fyNVzJxHPFSboIgTdjaXrlpLiDueQq =fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemK['web_url4']
     fyNVzJxHPFSboIgTdjaXrlpLiDueQC={}
     fyNVzJxHPFSboIgTdjaXrlpLiDueQC['title']=fyNVzJxHPFSboIgTdjaXrlpLiDuemK['mast_nm']
     fyNVzJxHPFSboIgTdjaXrlpLiDueQC['mediatype']='episode' 
     try:
      if fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('actor')!='' and fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('actor')!='-':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['cast'] =fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('actor').split(',')
      if fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('director')!='' and fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('director')!='-':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['director']=fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('director').split(',')
      if fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('cate_nm')!='':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['genre'] =fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('cate_nm').split('/')
      if 'targetage' in fyNVzJxHPFSboIgTdjaXrlpLiDuemK:fyNVzJxHPFSboIgTdjaXrlpLiDueQC['mpaa']=fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('targetage')
     except:
      fyNVzJxHPFSboIgTdjaXrlpLiDueEA
     try:
      if 'broad_dt' in fyNVzJxHPFSboIgTdjaXrlpLiDuemK:
       fyNVzJxHPFSboIgTdjaXrlpLiDuetO=fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('broad_dt')
       fyNVzJxHPFSboIgTdjaXrlpLiDueQC['aired']='%s-%s-%s'%(fyNVzJxHPFSboIgTdjaXrlpLiDuetO[:4],fyNVzJxHPFSboIgTdjaXrlpLiDuetO[4:6],fyNVzJxHPFSboIgTdjaXrlpLiDuetO[6:])
     except:
      fyNVzJxHPFSboIgTdjaXrlpLiDueEA
     fyNVzJxHPFSboIgTdjaXrlpLiDueQY={'program':fyNVzJxHPFSboIgTdjaXrlpLiDueQc,'title':fyNVzJxHPFSboIgTdjaXrlpLiDueQh,'thumbnail':fyNVzJxHPFSboIgTdjaXrlpLiDueQq,'synopsis':'','info':fyNVzJxHPFSboIgTdjaXrlpLiDueQC}
     fyNVzJxHPFSboIgTdjaXrlpLiDuetM.append(fyNVzJxHPFSboIgTdjaXrlpLiDueQY)
   else:
    if not('vodMVRsb' in fyNVzJxHPFSboIgTdjaXrlpLiDuemk):return fyNVzJxHPFSboIgTdjaXrlpLiDuetM,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
    fyNVzJxHPFSboIgTdjaXrlpLiDuetY=fyNVzJxHPFSboIgTdjaXrlpLiDuemk['vodMVRsb']['dataList']
    fyNVzJxHPFSboIgTdjaXrlpLiDuetG =fyNVzJxHPFSboIgTdjaXrlpLiDueEC(fyNVzJxHPFSboIgTdjaXrlpLiDuemk['vodMVRsb']['count'])
    for fyNVzJxHPFSboIgTdjaXrlpLiDuemK in fyNVzJxHPFSboIgTdjaXrlpLiDuetY:
     fyNVzJxHPFSboIgTdjaXrlpLiDueQc=fyNVzJxHPFSboIgTdjaXrlpLiDuemK['mast_cd']
     fyNVzJxHPFSboIgTdjaXrlpLiDueQh =fyNVzJxHPFSboIgTdjaXrlpLiDuemK['mast_nm'].strip()
     fyNVzJxHPFSboIgTdjaXrlpLiDueQq =fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemK['web_url']
     if landyn==fyNVzJxHPFSboIgTdjaXrlpLiDueEB:
      fyNVzJxHPFSboIgTdjaXrlpLiDueQq =fyNVzJxHPFSboIgTdjaXrlpLiDuewt.IMG_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemK['web_url5']
     fyNVzJxHPFSboIgTdjaXrlpLiDueQC={}
     fyNVzJxHPFSboIgTdjaXrlpLiDueQC['title'] =fyNVzJxHPFSboIgTdjaXrlpLiDueQh
     fyNVzJxHPFSboIgTdjaXrlpLiDueQC['mediatype']='movie' 
     try:
      if fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('actor') !='':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['cast'] =fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('actor').split(',')
      if fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('cate_nm')!='':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['genre'] =fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('cate_nm').split('/')
      if fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('runtime_sec')!='':fyNVzJxHPFSboIgTdjaXrlpLiDueQC['duration']=fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('runtime_sec')
      if 'grade_nm' in fyNVzJxHPFSboIgTdjaXrlpLiDuemK:fyNVzJxHPFSboIgTdjaXrlpLiDueQC['mpaa']=fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('grade_nm')
     except:
      fyNVzJxHPFSboIgTdjaXrlpLiDueEA
     try:
      fyNVzJxHPFSboIgTdjaXrlpLiDuetO=fyNVzJxHPFSboIgTdjaXrlpLiDuemK.get('broad_dt')
      if data_str!='':
       fyNVzJxHPFSboIgTdjaXrlpLiDueQC['aired']='%s-%s-%s'%(fyNVzJxHPFSboIgTdjaXrlpLiDuetO[:4],fyNVzJxHPFSboIgTdjaXrlpLiDuetO[4:6],fyNVzJxHPFSboIgTdjaXrlpLiDuetO[6:])
       fyNVzJxHPFSboIgTdjaXrlpLiDueQC['year']=fyNVzJxHPFSboIgTdjaXrlpLiDuetO[:4]
     except:
      fyNVzJxHPFSboIgTdjaXrlpLiDueEA
     fyNVzJxHPFSboIgTdjaXrlpLiDueQY={'movie':fyNVzJxHPFSboIgTdjaXrlpLiDueQc,'title':fyNVzJxHPFSboIgTdjaXrlpLiDueQh,'thumbnail':fyNVzJxHPFSboIgTdjaXrlpLiDueQq,'synopsis':'','info':fyNVzJxHPFSboIgTdjaXrlpLiDueQC}
     fyNVzJxHPFSboIgTdjaXrlpLiDueth=fyNVzJxHPFSboIgTdjaXrlpLiDueEB
     for fyNVzJxHPFSboIgTdjaXrlpLiDuetq in fyNVzJxHPFSboIgTdjaXrlpLiDuemK['bill']:
      if fyNVzJxHPFSboIgTdjaXrlpLiDuetq in fyNVzJxHPFSboIgTdjaXrlpLiDuewt.MOVIE_LITE:
       fyNVzJxHPFSboIgTdjaXrlpLiDueth=fyNVzJxHPFSboIgTdjaXrlpLiDueEn
       break
     if fyNVzJxHPFSboIgTdjaXrlpLiDueth==fyNVzJxHPFSboIgTdjaXrlpLiDueEB: 
      fyNVzJxHPFSboIgTdjaXrlpLiDueQY['title']=fyNVzJxHPFSboIgTdjaXrlpLiDueQY['title']+' [개별구매]'
     fyNVzJxHPFSboIgTdjaXrlpLiDuetM.append(fyNVzJxHPFSboIgTdjaXrlpLiDueQY)
  except fyNVzJxHPFSboIgTdjaXrlpLiDueEk as exception:
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(exception)
  return fyNVzJxHPFSboIgTdjaXrlpLiDuetM,fyNVzJxHPFSboIgTdjaXrlpLiDueQU
 def GetDeviceList(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,fyNVzJxHPFSboIgTdjaXrlpLiDuewv,fyNVzJxHPFSboIgTdjaXrlpLiDuemw):
  fyNVzJxHPFSboIgTdjaXrlpLiDueQO=[]
  fyNVzJxHPFSboIgTdjaXrlpLiDuemA='-'
  try:
   fyNVzJxHPFSboIgTdjaXrlpLiDuemB ='/v1/user/device/list'
   fyNVzJxHPFSboIgTdjaXrlpLiDuetc=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.API_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemB
   fyNVzJxHPFSboIgTdjaXrlpLiDuemW={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   fyNVzJxHPFSboIgTdjaXrlpLiDuewU=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.makeDefaultCookies(vToken=fyNVzJxHPFSboIgTdjaXrlpLiDuewv,vUserinfo=fyNVzJxHPFSboIgTdjaXrlpLiDuemw)
   fyNVzJxHPFSboIgTdjaXrlpLiDuewY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.callRequestCookies('Get',fyNVzJxHPFSboIgTdjaXrlpLiDuetc,payload=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,params=fyNVzJxHPFSboIgTdjaXrlpLiDuemW,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDuewU)
   fyNVzJxHPFSboIgTdjaXrlpLiDuemk=json.loads(fyNVzJxHPFSboIgTdjaXrlpLiDuewY.text)
   fyNVzJxHPFSboIgTdjaXrlpLiDueQO=fyNVzJxHPFSboIgTdjaXrlpLiDuemk['body']
   for fyNVzJxHPFSboIgTdjaXrlpLiDuemK in fyNVzJxHPFSboIgTdjaXrlpLiDueQO:
    if fyNVzJxHPFSboIgTdjaXrlpLiDuemK['model']=='PC':
     fyNVzJxHPFSboIgTdjaXrlpLiDuemA=fyNVzJxHPFSboIgTdjaXrlpLiDuemK['uuid']
  except fyNVzJxHPFSboIgTdjaXrlpLiDueEk as exception:
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(exception)
  return fyNVzJxHPFSboIgTdjaXrlpLiDuemA
 def GetProfileToken(fyNVzJxHPFSboIgTdjaXrlpLiDuewt,fyNVzJxHPFSboIgTdjaXrlpLiDuewv,fyNVzJxHPFSboIgTdjaXrlpLiDuemw,user_pf):
  fyNVzJxHPFSboIgTdjaXrlpLiDuetv=[]
  fyNVzJxHPFSboIgTdjaXrlpLiDueEw =''
  fyNVzJxHPFSboIgTdjaXrlpLiDueEm =''
  fyNVzJxHPFSboIgTdjaXrlpLiDueEQ='Y'
  fyNVzJxHPFSboIgTdjaXrlpLiDueEt ='N'
  try:
   fyNVzJxHPFSboIgTdjaXrlpLiDuemB ='/profile/select.do'
   fyNVzJxHPFSboIgTdjaXrlpLiDuetc=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.URL_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemB
   fyNVzJxHPFSboIgTdjaXrlpLiDuewU=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.makeDefaultCookies(vToken=fyNVzJxHPFSboIgTdjaXrlpLiDuewv,vUserinfo=fyNVzJxHPFSboIgTdjaXrlpLiDuemw)
   fyNVzJxHPFSboIgTdjaXrlpLiDuewY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.callRequestCookies('Get',fyNVzJxHPFSboIgTdjaXrlpLiDuetc,payload=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,params=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDuewU)
   fyNVzJxHPFSboIgTdjaXrlpLiDuetv =re.findall('data-profile-no="\d+"',fyNVzJxHPFSboIgTdjaXrlpLiDuewY.text)
   for i in fyNVzJxHPFSboIgTdjaXrlpLiDueEW(fyNVzJxHPFSboIgTdjaXrlpLiDueEK(fyNVzJxHPFSboIgTdjaXrlpLiDuetv)):
    fyNVzJxHPFSboIgTdjaXrlpLiDueEO =fyNVzJxHPFSboIgTdjaXrlpLiDuetv[i].replace('data-profile-no=','').replace('"','')
    fyNVzJxHPFSboIgTdjaXrlpLiDuetv[i]=fyNVzJxHPFSboIgTdjaXrlpLiDueEO
   fyNVzJxHPFSboIgTdjaXrlpLiDueEw=fyNVzJxHPFSboIgTdjaXrlpLiDuetv[user_pf]
  except fyNVzJxHPFSboIgTdjaXrlpLiDueEk as exception:
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(exception)
   return fyNVzJxHPFSboIgTdjaXrlpLiDueEm,fyNVzJxHPFSboIgTdjaXrlpLiDueEQ,fyNVzJxHPFSboIgTdjaXrlpLiDueEt
  try:
   fyNVzJxHPFSboIgTdjaXrlpLiDuemB ='/profile/api/select.do'
   fyNVzJxHPFSboIgTdjaXrlpLiDuetc=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.URL_DOMAIN+fyNVzJxHPFSboIgTdjaXrlpLiDuemB
   fyNVzJxHPFSboIgTdjaXrlpLiDuewU=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.makeDefaultCookies(vToken=fyNVzJxHPFSboIgTdjaXrlpLiDuewv,vUserinfo=fyNVzJxHPFSboIgTdjaXrlpLiDuemw)
   fyNVzJxHPFSboIgTdjaXrlpLiDuewG={'profileNo':fyNVzJxHPFSboIgTdjaXrlpLiDueEw}
   fyNVzJxHPFSboIgTdjaXrlpLiDuewY=fyNVzJxHPFSboIgTdjaXrlpLiDuewt.callRequestCookies('Post',fyNVzJxHPFSboIgTdjaXrlpLiDuetc,payload=fyNVzJxHPFSboIgTdjaXrlpLiDuewG,params=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,headers=fyNVzJxHPFSboIgTdjaXrlpLiDueEA,cookies=fyNVzJxHPFSboIgTdjaXrlpLiDuewU)
   for fyNVzJxHPFSboIgTdjaXrlpLiDuewc in fyNVzJxHPFSboIgTdjaXrlpLiDuewY.cookies:
    if fyNVzJxHPFSboIgTdjaXrlpLiDuewc.name=='_tving_token':
     fyNVzJxHPFSboIgTdjaXrlpLiDueEm=fyNVzJxHPFSboIgTdjaXrlpLiDuewc.value
    elif fyNVzJxHPFSboIgTdjaXrlpLiDuewc.name==fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GLOBAL_COOKIENM['tv_cookiekey']:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEQ=fyNVzJxHPFSboIgTdjaXrlpLiDuewc.value
    elif fyNVzJxHPFSboIgTdjaXrlpLiDuewc.name==fyNVzJxHPFSboIgTdjaXrlpLiDuewt.GLOBAL_COOKIENM['tv_lockkey']:
     fyNVzJxHPFSboIgTdjaXrlpLiDueEt=fyNVzJxHPFSboIgTdjaXrlpLiDuewc.value
  except fyNVzJxHPFSboIgTdjaXrlpLiDueEk as exception:
   fyNVzJxHPFSboIgTdjaXrlpLiDueEh(exception)
  return fyNVzJxHPFSboIgTdjaXrlpLiDueEm,fyNVzJxHPFSboIgTdjaXrlpLiDueEQ,fyNVzJxHPFSboIgTdjaXrlpLiDueEt
# Created by pyminifier (https://github.com/liftoff/pyminifier)
