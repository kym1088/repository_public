__author__="NightRain"
eybOdhCcSUrXjGpfEgIFizkvqmTJAQ=object
eybOdhCcSUrXjGpfEgIFizkvqmTJAR=None
eybOdhCcSUrXjGpfEgIFizkvqmTJAB=int
eybOdhCcSUrXjGpfEgIFizkvqmTJAw=True
eybOdhCcSUrXjGpfEgIFizkvqmTJAt=False
eybOdhCcSUrXjGpfEgIFizkvqmTJlD=type
eybOdhCcSUrXjGpfEgIFizkvqmTJlK=dict
eybOdhCcSUrXjGpfEgIFizkvqmTJlu=getattr
eybOdhCcSUrXjGpfEgIFizkvqmTJlW=list
eybOdhCcSUrXjGpfEgIFizkvqmTJlM=len
eybOdhCcSUrXjGpfEgIFizkvqmTJlH=str
eybOdhCcSUrXjGpfEgIFizkvqmTJlY=range
eybOdhCcSUrXjGpfEgIFizkvqmTJlA=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
eybOdhCcSUrXjGpfEgIFizkvqmTJDu=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
eybOdhCcSUrXjGpfEgIFizkvqmTJDW=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
eybOdhCcSUrXjGpfEgIFizkvqmTJDM=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
eybOdhCcSUrXjGpfEgIFizkvqmTJDH=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
eybOdhCcSUrXjGpfEgIFizkvqmTJDY=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
eybOdhCcSUrXjGpfEgIFizkvqmTJDA=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
eybOdhCcSUrXjGpfEgIFizkvqmTJDl=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
eybOdhCcSUrXjGpfEgIFizkvqmTJDx={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
eybOdhCcSUrXjGpfEgIFizkvqmTJDP =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
eybOdhCcSUrXjGpfEgIFizkvqmTJDL=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class eybOdhCcSUrXjGpfEgIFizkvqmTJDK(eybOdhCcSUrXjGpfEgIFizkvqmTJAQ):
 def __init__(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJDo,eybOdhCcSUrXjGpfEgIFizkvqmTJDV,eybOdhCcSUrXjGpfEgIFizkvqmTJDn):
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_url =eybOdhCcSUrXjGpfEgIFizkvqmTJDo
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle=eybOdhCcSUrXjGpfEgIFizkvqmTJDV
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params =eybOdhCcSUrXjGpfEgIFizkvqmTJDn
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj =reNjaihzARLCxOmPwMvcQSnXoHVysF() 
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,sting):
  try:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDN=xbmcgui.Dialog()
   eybOdhCcSUrXjGpfEgIFizkvqmTJDN.notification(__addonname__,sting)
  except:
   eybOdhCcSUrXjGpfEgIFizkvqmTJAR
 def addon_log(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,string):
  try:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDQ=string.encode('utf-8','ignore')
  except:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDQ='addonException: addon_log'
  eybOdhCcSUrXjGpfEgIFizkvqmTJDR=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,eybOdhCcSUrXjGpfEgIFizkvqmTJDQ),level=eybOdhCcSUrXjGpfEgIFizkvqmTJDR)
 def get_keyboard_input(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJKn):
  eybOdhCcSUrXjGpfEgIFizkvqmTJDB=eybOdhCcSUrXjGpfEgIFizkvqmTJAR
  kb=xbmc.Keyboard()
  kb.setHeading(eybOdhCcSUrXjGpfEgIFizkvqmTJKn)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   eybOdhCcSUrXjGpfEgIFizkvqmTJDB=kb.getText()
  return eybOdhCcSUrXjGpfEgIFizkvqmTJDB
 def get_settings_account(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  eybOdhCcSUrXjGpfEgIFizkvqmTJDw =__addon__.getSetting('id')
  eybOdhCcSUrXjGpfEgIFizkvqmTJDt =__addon__.getSetting('pw')
  eybOdhCcSUrXjGpfEgIFizkvqmTJKD =__addon__.getSetting('login_type')
  eybOdhCcSUrXjGpfEgIFizkvqmTJKu=eybOdhCcSUrXjGpfEgIFizkvqmTJAB(__addon__.getSetting('selected_profile'))
  return(eybOdhCcSUrXjGpfEgIFizkvqmTJDw,eybOdhCcSUrXjGpfEgIFizkvqmTJDt,eybOdhCcSUrXjGpfEgIFizkvqmTJKD,eybOdhCcSUrXjGpfEgIFizkvqmTJKu)
 def get_settings_uhd(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  return eybOdhCcSUrXjGpfEgIFizkvqmTJAw if __addon__.getSetting('active_uhd')=='true' else eybOdhCcSUrXjGpfEgIFizkvqmTJAt
 def get_settings_playback(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  eybOdhCcSUrXjGpfEgIFizkvqmTJKW={'active_uhd':eybOdhCcSUrXjGpfEgIFizkvqmTJAw if __addon__.getSetting('active_uhd')=='true' else eybOdhCcSUrXjGpfEgIFizkvqmTJAt,'streamFilename':eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.TV_STREAM_FILENAME,}
  return eybOdhCcSUrXjGpfEgIFizkvqmTJKW
 def get_settings_proxyport(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  eybOdhCcSUrXjGpfEgIFizkvqmTJKM =eybOdhCcSUrXjGpfEgIFizkvqmTJAw if __addon__.getSetting('proxyYn')=='true' else eybOdhCcSUrXjGpfEgIFizkvqmTJAt
  eybOdhCcSUrXjGpfEgIFizkvqmTJKH=eybOdhCcSUrXjGpfEgIFizkvqmTJAB(__addon__.getSetting('proxyPort'))
  return eybOdhCcSUrXjGpfEgIFizkvqmTJKM,eybOdhCcSUrXjGpfEgIFizkvqmTJKH
 def get_settings_totalsearch(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  eybOdhCcSUrXjGpfEgIFizkvqmTJKY =eybOdhCcSUrXjGpfEgIFizkvqmTJAw if __addon__.getSetting('local_search')=='true' else eybOdhCcSUrXjGpfEgIFizkvqmTJAt
  eybOdhCcSUrXjGpfEgIFizkvqmTJKA=eybOdhCcSUrXjGpfEgIFizkvqmTJAw if __addon__.getSetting('local_history')=='true' else eybOdhCcSUrXjGpfEgIFizkvqmTJAt
  eybOdhCcSUrXjGpfEgIFizkvqmTJKl =eybOdhCcSUrXjGpfEgIFizkvqmTJAw if __addon__.getSetting('total_search')=='true' else eybOdhCcSUrXjGpfEgIFizkvqmTJAt
  eybOdhCcSUrXjGpfEgIFizkvqmTJKx=eybOdhCcSUrXjGpfEgIFizkvqmTJAw if __addon__.getSetting('total_history')=='true' else eybOdhCcSUrXjGpfEgIFizkvqmTJAt
  eybOdhCcSUrXjGpfEgIFizkvqmTJKP=eybOdhCcSUrXjGpfEgIFizkvqmTJAw if __addon__.getSetting('menu_bookmark')=='true' else eybOdhCcSUrXjGpfEgIFizkvqmTJAt
  return(eybOdhCcSUrXjGpfEgIFizkvqmTJKY,eybOdhCcSUrXjGpfEgIFizkvqmTJKA,eybOdhCcSUrXjGpfEgIFizkvqmTJKl,eybOdhCcSUrXjGpfEgIFizkvqmTJKx,eybOdhCcSUrXjGpfEgIFizkvqmTJKP)
 def get_settings_makebookmark(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  return eybOdhCcSUrXjGpfEgIFizkvqmTJAw if __addon__.getSetting('make_bookmark')=='true' else eybOdhCcSUrXjGpfEgIFizkvqmTJAt
 def get_settings_direct_replay(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  eybOdhCcSUrXjGpfEgIFizkvqmTJKL=eybOdhCcSUrXjGpfEgIFizkvqmTJAB(__addon__.getSetting('direct_replay'))
  if eybOdhCcSUrXjGpfEgIFizkvqmTJKL==0:
   return eybOdhCcSUrXjGpfEgIFizkvqmTJAt
  else:
   return eybOdhCcSUrXjGpfEgIFizkvqmTJAw
 def set_winEpisodeOrderby(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJKo):
  __addon__.setSetting('tving_orderby',eybOdhCcSUrXjGpfEgIFizkvqmTJKo)
  eybOdhCcSUrXjGpfEgIFizkvqmTJKs=xbmcgui.Window(10000)
  eybOdhCcSUrXjGpfEgIFizkvqmTJKs.setProperty('TVING_M_ORDERBY',eybOdhCcSUrXjGpfEgIFizkvqmTJKo)
 def get_winEpisodeOrderby(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  eybOdhCcSUrXjGpfEgIFizkvqmTJKo=__addon__.getSetting('tving_orderby')
  if eybOdhCcSUrXjGpfEgIFizkvqmTJKo in['',eybOdhCcSUrXjGpfEgIFizkvqmTJAR]:eybOdhCcSUrXjGpfEgIFizkvqmTJKo='desc'
  return eybOdhCcSUrXjGpfEgIFizkvqmTJKo
 def add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,label,sublabel='',img='',infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params='',isLink=eybOdhCcSUrXjGpfEgIFizkvqmTJAt,ContextMenu=eybOdhCcSUrXjGpfEgIFizkvqmTJAR):
  eybOdhCcSUrXjGpfEgIFizkvqmTJKV='%s?%s'%(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_url,urllib.parse.urlencode(params))
  if sublabel:eybOdhCcSUrXjGpfEgIFizkvqmTJKn='%s < %s >'%(label,sublabel)
  else: eybOdhCcSUrXjGpfEgIFizkvqmTJKn=label
  if not img:img='DefaultFolder.png'
  eybOdhCcSUrXjGpfEgIFizkvqmTJKa=xbmcgui.ListItem(eybOdhCcSUrXjGpfEgIFizkvqmTJKn)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJlD(img)==eybOdhCcSUrXjGpfEgIFizkvqmTJlK:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKa.setArt(img)
  else:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKa.setArt({'thumb':img,'poster':img})
  if eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.KodiVersion>=20:
   if infoLabels:eybOdhCcSUrXjGpfEgIFizkvqmTJDs.Set_InfoTag(eybOdhCcSUrXjGpfEgIFizkvqmTJKa.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:eybOdhCcSUrXjGpfEgIFizkvqmTJKa.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKa.setProperty('IsPlayable','true')
  if ContextMenu:eybOdhCcSUrXjGpfEgIFizkvqmTJKa.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,eybOdhCcSUrXjGpfEgIFizkvqmTJKV,eybOdhCcSUrXjGpfEgIFizkvqmTJKa,isFolder)
 def get_selQuality(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,etype):
  try:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKN='selected_quality'
   eybOdhCcSUrXjGpfEgIFizkvqmTJKQ=[1080,720,480,360]
   eybOdhCcSUrXjGpfEgIFizkvqmTJKR=eybOdhCcSUrXjGpfEgIFizkvqmTJAB(__addon__.getSetting(eybOdhCcSUrXjGpfEgIFizkvqmTJKN))
   return eybOdhCcSUrXjGpfEgIFizkvqmTJKQ[eybOdhCcSUrXjGpfEgIFizkvqmTJKR]
  except:
   eybOdhCcSUrXjGpfEgIFizkvqmTJAR
  return 720 
 def Set_InfoTag(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,video_InfoTag:xbmc.InfoTagVideo,eybOdhCcSUrXjGpfEgIFizkvqmTJuH):
  for eybOdhCcSUrXjGpfEgIFizkvqmTJKB,value in eybOdhCcSUrXjGpfEgIFizkvqmTJuH.items():
   if eybOdhCcSUrXjGpfEgIFizkvqmTJDx[eybOdhCcSUrXjGpfEgIFizkvqmTJKB]['type']=='string':
    eybOdhCcSUrXjGpfEgIFizkvqmTJlu(video_InfoTag,eybOdhCcSUrXjGpfEgIFizkvqmTJDx[eybOdhCcSUrXjGpfEgIFizkvqmTJKB]['func'])(value)
   elif eybOdhCcSUrXjGpfEgIFizkvqmTJDx[eybOdhCcSUrXjGpfEgIFizkvqmTJKB]['type']=='int':
    if eybOdhCcSUrXjGpfEgIFizkvqmTJlD(value)==eybOdhCcSUrXjGpfEgIFizkvqmTJAB:
     eybOdhCcSUrXjGpfEgIFizkvqmTJKw=eybOdhCcSUrXjGpfEgIFizkvqmTJAB(value)
    else:
     eybOdhCcSUrXjGpfEgIFizkvqmTJKw=0
    eybOdhCcSUrXjGpfEgIFizkvqmTJlu(video_InfoTag,eybOdhCcSUrXjGpfEgIFizkvqmTJDx[eybOdhCcSUrXjGpfEgIFizkvqmTJKB]['func'])(eybOdhCcSUrXjGpfEgIFizkvqmTJKw)
   elif eybOdhCcSUrXjGpfEgIFizkvqmTJDx[eybOdhCcSUrXjGpfEgIFizkvqmTJKB]['type']=='actor':
    if value!=[]:
     eybOdhCcSUrXjGpfEgIFizkvqmTJlu(video_InfoTag,eybOdhCcSUrXjGpfEgIFizkvqmTJDx[eybOdhCcSUrXjGpfEgIFizkvqmTJKB]['func'])([xbmc.Actor(name)for name in value])
   elif eybOdhCcSUrXjGpfEgIFizkvqmTJDx[eybOdhCcSUrXjGpfEgIFizkvqmTJKB]['type']=='list':
    if eybOdhCcSUrXjGpfEgIFizkvqmTJlD(value)==eybOdhCcSUrXjGpfEgIFizkvqmTJlW:
     eybOdhCcSUrXjGpfEgIFizkvqmTJlu(video_InfoTag,eybOdhCcSUrXjGpfEgIFizkvqmTJDx[eybOdhCcSUrXjGpfEgIFizkvqmTJKB]['func'])(value)
    else:
     eybOdhCcSUrXjGpfEgIFizkvqmTJlu(video_InfoTag,eybOdhCcSUrXjGpfEgIFizkvqmTJDx[eybOdhCcSUrXjGpfEgIFizkvqmTJKB]['func'])([value])
 def dp_Main_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  (eybOdhCcSUrXjGpfEgIFizkvqmTJKY,eybOdhCcSUrXjGpfEgIFizkvqmTJKA,eybOdhCcSUrXjGpfEgIFizkvqmTJKl,eybOdhCcSUrXjGpfEgIFizkvqmTJKx,eybOdhCcSUrXjGpfEgIFizkvqmTJKP)=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_totalsearch()
  for eybOdhCcSUrXjGpfEgIFizkvqmTJKt in eybOdhCcSUrXjGpfEgIFizkvqmTJDu:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn=eybOdhCcSUrXjGpfEgIFizkvqmTJKt.get('title')
   eybOdhCcSUrXjGpfEgIFizkvqmTJuD=''
   if eybOdhCcSUrXjGpfEgIFizkvqmTJKt.get('mode')=='SEARCH_GROUP' and eybOdhCcSUrXjGpfEgIFizkvqmTJKY ==eybOdhCcSUrXjGpfEgIFizkvqmTJAt:continue
   elif eybOdhCcSUrXjGpfEgIFizkvqmTJKt.get('mode')=='SEARCH_HISTORY' and eybOdhCcSUrXjGpfEgIFizkvqmTJKA==eybOdhCcSUrXjGpfEgIFizkvqmTJAt:continue
   elif eybOdhCcSUrXjGpfEgIFizkvqmTJKt.get('mode')=='TOTAL_SEARCH' and eybOdhCcSUrXjGpfEgIFizkvqmTJKl ==eybOdhCcSUrXjGpfEgIFizkvqmTJAt:continue
   elif eybOdhCcSUrXjGpfEgIFizkvqmTJKt.get('mode')=='TOTAL_HISTORY' and eybOdhCcSUrXjGpfEgIFizkvqmTJKx==eybOdhCcSUrXjGpfEgIFizkvqmTJAt:continue
   elif eybOdhCcSUrXjGpfEgIFizkvqmTJKt.get('mode')=='MENU_BOOKMARK' and eybOdhCcSUrXjGpfEgIFizkvqmTJKP==eybOdhCcSUrXjGpfEgIFizkvqmTJAt:continue
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':eybOdhCcSUrXjGpfEgIFizkvqmTJKt.get('mode'),'stype':eybOdhCcSUrXjGpfEgIFizkvqmTJKt.get('stype'),'orderby':eybOdhCcSUrXjGpfEgIFizkvqmTJKt.get('orderby'),'ordernm':eybOdhCcSUrXjGpfEgIFizkvqmTJKt.get('ordernm'),'page':'1'}
   if eybOdhCcSUrXjGpfEgIFizkvqmTJKt.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    eybOdhCcSUrXjGpfEgIFizkvqmTJuW=eybOdhCcSUrXjGpfEgIFizkvqmTJAt
    eybOdhCcSUrXjGpfEgIFizkvqmTJuM =eybOdhCcSUrXjGpfEgIFizkvqmTJAw
   else:
    eybOdhCcSUrXjGpfEgIFizkvqmTJuW=eybOdhCcSUrXjGpfEgIFizkvqmTJAw
    eybOdhCcSUrXjGpfEgIFizkvqmTJuM =eybOdhCcSUrXjGpfEgIFizkvqmTJAt
   eybOdhCcSUrXjGpfEgIFizkvqmTJuH={'title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'plot':eybOdhCcSUrXjGpfEgIFizkvqmTJKn}
   if eybOdhCcSUrXjGpfEgIFizkvqmTJKt.get('mode')=='XXX':eybOdhCcSUrXjGpfEgIFizkvqmTJuH=eybOdhCcSUrXjGpfEgIFizkvqmTJAR
   if 'icon' in eybOdhCcSUrXjGpfEgIFizkvqmTJKt:eybOdhCcSUrXjGpfEgIFizkvqmTJuD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',eybOdhCcSUrXjGpfEgIFizkvqmTJKt.get('icon')) 
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel='',img=eybOdhCcSUrXjGpfEgIFizkvqmTJuD,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJuH,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJuW,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK,isLink=eybOdhCcSUrXjGpfEgIFizkvqmTJuM)
  xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle)
 def login_main(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  (eybOdhCcSUrXjGpfEgIFizkvqmTJuA,eybOdhCcSUrXjGpfEgIFizkvqmTJul,eybOdhCcSUrXjGpfEgIFizkvqmTJux,eybOdhCcSUrXjGpfEgIFizkvqmTJuP)=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_account()
  if not(eybOdhCcSUrXjGpfEgIFizkvqmTJuA and eybOdhCcSUrXjGpfEgIFizkvqmTJul):
   eybOdhCcSUrXjGpfEgIFizkvqmTJDN=xbmcgui.Dialog()
   eybOdhCcSUrXjGpfEgIFizkvqmTJuL=eybOdhCcSUrXjGpfEgIFizkvqmTJDN.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if eybOdhCcSUrXjGpfEgIFizkvqmTJuL==eybOdhCcSUrXjGpfEgIFizkvqmTJAw:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if eybOdhCcSUrXjGpfEgIFizkvqmTJDs.cookiefile_check():return
  if base64.standard_b64encode(eybOdhCcSUrXjGpfEgIFizkvqmTJuA.encode()).decode('utf-8')=='a3ltOTUxMDg4':
   eybOdhCcSUrXjGpfEgIFizkvqmTJus=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.GetCredential2(eybOdhCcSUrXjGpfEgIFizkvqmTJuA,eybOdhCcSUrXjGpfEgIFizkvqmTJul,eybOdhCcSUrXjGpfEgIFizkvqmTJux,eybOdhCcSUrXjGpfEgIFizkvqmTJuP)
  else:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDN=xbmcgui.Dialog()
   eybOdhCcSUrXjGpfEgIFizkvqmTJuo=eybOdhCcSUrXjGpfEgIFizkvqmTJDN.browse(1,__language__(30917).encode('utf8'),'','.twc',eybOdhCcSUrXjGpfEgIFizkvqmTJAt,eybOdhCcSUrXjGpfEgIFizkvqmTJAt,'',eybOdhCcSUrXjGpfEgIFizkvqmTJAt)
   if eybOdhCcSUrXjGpfEgIFizkvqmTJuo!='':
    eybOdhCcSUrXjGpfEgIFizkvqmTJus=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.WebCookies_Load(eybOdhCcSUrXjGpfEgIFizkvqmTJuo)
    if eybOdhCcSUrXjGpfEgIFizkvqmTJus:
     eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.JsonFile_Save(eybOdhCcSUrXjGpfEgIFizkvqmTJDP,eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.TV)
     eybOdhCcSUrXjGpfEgIFizkvqmTJDs.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    eybOdhCcSUrXjGpfEgIFizkvqmTJus=eybOdhCcSUrXjGpfEgIFizkvqmTJAt
  if eybOdhCcSUrXjGpfEgIFizkvqmTJus==eybOdhCcSUrXjGpfEgIFizkvqmTJAw:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.cookiefile_save()
  else:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJuV=eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('stype')
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuV=='live':
   eybOdhCcSUrXjGpfEgIFizkvqmTJun=eybOdhCcSUrXjGpfEgIFizkvqmTJDW
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJuV=='vod':
   eybOdhCcSUrXjGpfEgIFizkvqmTJun=eybOdhCcSUrXjGpfEgIFizkvqmTJDY
  else:
   eybOdhCcSUrXjGpfEgIFizkvqmTJun=eybOdhCcSUrXjGpfEgIFizkvqmTJDA
  for eybOdhCcSUrXjGpfEgIFizkvqmTJua in eybOdhCcSUrXjGpfEgIFizkvqmTJun:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn=eybOdhCcSUrXjGpfEgIFizkvqmTJua.get('title')
   if eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('ordernm')!='-':
    eybOdhCcSUrXjGpfEgIFizkvqmTJKn+='  ('+eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('ordernm')+')'
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':eybOdhCcSUrXjGpfEgIFizkvqmTJua.get('mode'),'stype':eybOdhCcSUrXjGpfEgIFizkvqmTJua.get('stype'),'orderby':eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('orderby'),'ordernm':eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('ordernm'),'page':'1'}
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel='',img='',infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJlM(eybOdhCcSUrXjGpfEgIFizkvqmTJun)>0:xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle)
 def dp_SubTitle_Group(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN): 
  for eybOdhCcSUrXjGpfEgIFizkvqmTJua in eybOdhCcSUrXjGpfEgIFizkvqmTJDl:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn=eybOdhCcSUrXjGpfEgIFizkvqmTJua.get('title')
   if eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('ordernm')!='-':
    eybOdhCcSUrXjGpfEgIFizkvqmTJKn+='  ('+eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('ordernm')+')'
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':eybOdhCcSUrXjGpfEgIFizkvqmTJua.get('mode'),'genreCode':eybOdhCcSUrXjGpfEgIFizkvqmTJua.get('genreCode'),'stype':eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('stype'),'orderby':eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('orderby'),'page':'1'}
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel='',img='',infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJlM(eybOdhCcSUrXjGpfEgIFizkvqmTJDl)>0:xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle)
 def dp_LiveChannel_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJuV =eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('stype')
  eybOdhCcSUrXjGpfEgIFizkvqmTJuQ =eybOdhCcSUrXjGpfEgIFizkvqmTJAB(eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('page'))
  eybOdhCcSUrXjGpfEgIFizkvqmTJuR,eybOdhCcSUrXjGpfEgIFizkvqmTJuB=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.GetLiveChannelList(eybOdhCcSUrXjGpfEgIFizkvqmTJuV,eybOdhCcSUrXjGpfEgIFizkvqmTJuQ)
  for eybOdhCcSUrXjGpfEgIFizkvqmTJuw in eybOdhCcSUrXjGpfEgIFizkvqmTJuR:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('title')
   eybOdhCcSUrXjGpfEgIFizkvqmTJuY =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('channel')
   eybOdhCcSUrXjGpfEgIFizkvqmTJut =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('thumbnail')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWD =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('synopsis')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWK =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('channelepg')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWu =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('cast')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWM =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('director')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWH =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('info_genre')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWY =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('year')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWA =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('mpaa')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWl =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('premiered')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWx={'mediatype':'episode','title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'studio':eybOdhCcSUrXjGpfEgIFizkvqmTJuY,'cast':eybOdhCcSUrXjGpfEgIFizkvqmTJWu,'director':eybOdhCcSUrXjGpfEgIFizkvqmTJWM,'genre':eybOdhCcSUrXjGpfEgIFizkvqmTJWH,'plot':'%s\n%s\n%s\n\n%s'%(eybOdhCcSUrXjGpfEgIFizkvqmTJuY,eybOdhCcSUrXjGpfEgIFizkvqmTJKn,eybOdhCcSUrXjGpfEgIFizkvqmTJWK,eybOdhCcSUrXjGpfEgIFizkvqmTJWD),'year':eybOdhCcSUrXjGpfEgIFizkvqmTJWY,'mpaa':eybOdhCcSUrXjGpfEgIFizkvqmTJWA,'premiered':eybOdhCcSUrXjGpfEgIFizkvqmTJWl}
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'LIVE','mediacode':eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('mediacode'),'stype':eybOdhCcSUrXjGpfEgIFizkvqmTJuV}
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJuY,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJKn,img=eybOdhCcSUrXjGpfEgIFizkvqmTJut,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJWx,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAt,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuB:
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['mode']='CHANNEL' 
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['stype']=eybOdhCcSUrXjGpfEgIFizkvqmTJuV 
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['page']=eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn='[B]%s >>[/B]'%'다음 페이지'
   eybOdhCcSUrXjGpfEgIFizkvqmTJWP=eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJuD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJWP,img=eybOdhCcSUrXjGpfEgIFizkvqmTJuD,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJlM(eybOdhCcSUrXjGpfEgIFizkvqmTJuR)>0:xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,cacheToDisc=eybOdhCcSUrXjGpfEgIFizkvqmTJAt)
 def dp_Program_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJWL =eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('stype')
  eybOdhCcSUrXjGpfEgIFizkvqmTJKo =eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('orderby')
  eybOdhCcSUrXjGpfEgIFizkvqmTJuQ =eybOdhCcSUrXjGpfEgIFizkvqmTJAB(eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('page'))
  eybOdhCcSUrXjGpfEgIFizkvqmTJWs=eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('genreCode')
  if eybOdhCcSUrXjGpfEgIFizkvqmTJWs==eybOdhCcSUrXjGpfEgIFizkvqmTJAR:eybOdhCcSUrXjGpfEgIFizkvqmTJWs='all'
  eybOdhCcSUrXjGpfEgIFizkvqmTJWo,eybOdhCcSUrXjGpfEgIFizkvqmTJuB=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.GetProgramList(eybOdhCcSUrXjGpfEgIFizkvqmTJWL,eybOdhCcSUrXjGpfEgIFizkvqmTJKo,eybOdhCcSUrXjGpfEgIFizkvqmTJuQ,eybOdhCcSUrXjGpfEgIFizkvqmTJWs)
  for eybOdhCcSUrXjGpfEgIFizkvqmTJWV in eybOdhCcSUrXjGpfEgIFizkvqmTJWo:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('title')
   eybOdhCcSUrXjGpfEgIFizkvqmTJut =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('thumbnail')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWD =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('synopsis')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWn =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('channel')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWu =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('cast')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWM =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('director')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWH=eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('info_genre')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWY =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('year')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWl =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('premiered')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWA =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('mpaa')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWx={'mediatype':'tvshow','title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'studio':eybOdhCcSUrXjGpfEgIFizkvqmTJWn,'cast':eybOdhCcSUrXjGpfEgIFizkvqmTJWu,'director':eybOdhCcSUrXjGpfEgIFizkvqmTJWM,'genre':eybOdhCcSUrXjGpfEgIFizkvqmTJWH,'year':eybOdhCcSUrXjGpfEgIFizkvqmTJWY,'premiered':eybOdhCcSUrXjGpfEgIFizkvqmTJWl,'mpaa':eybOdhCcSUrXjGpfEgIFizkvqmTJWA,'plot':eybOdhCcSUrXjGpfEgIFizkvqmTJWD}
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'EPISODE','programcode':eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('program'),'page':'1'}
   if eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_makebookmark():
    eybOdhCcSUrXjGpfEgIFizkvqmTJWa={'videoid':eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('program'),'vidtype':'tvshow','vtitle':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'vsubtitle':eybOdhCcSUrXjGpfEgIFizkvqmTJWn,}
    eybOdhCcSUrXjGpfEgIFizkvqmTJWN=json.dumps(eybOdhCcSUrXjGpfEgIFizkvqmTJWa)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWN=urllib.parse.quote(eybOdhCcSUrXjGpfEgIFizkvqmTJWN)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(eybOdhCcSUrXjGpfEgIFizkvqmTJWN)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWR=[('(통합) 찜 영상에 추가',eybOdhCcSUrXjGpfEgIFizkvqmTJWQ)]
   else:
    eybOdhCcSUrXjGpfEgIFizkvqmTJWR=eybOdhCcSUrXjGpfEgIFizkvqmTJAR
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJWn,img=eybOdhCcSUrXjGpfEgIFizkvqmTJut,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJWx,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK,ContextMenu=eybOdhCcSUrXjGpfEgIFizkvqmTJWR)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuB:
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['mode'] ='PROGRAM' 
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['stype'] =eybOdhCcSUrXjGpfEgIFizkvqmTJWL
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['orderby'] =eybOdhCcSUrXjGpfEgIFizkvqmTJKo
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['page'] =eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['genreCode']=eybOdhCcSUrXjGpfEgIFizkvqmTJWs 
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn='[B]%s >>[/B]'%'다음 페이지'
   eybOdhCcSUrXjGpfEgIFizkvqmTJWP=eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJuD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJWP,img=eybOdhCcSUrXjGpfEgIFizkvqmTJuD,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  xbmcplugin.setContent(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,cacheToDisc=eybOdhCcSUrXjGpfEgIFizkvqmTJAt)
 def dp_4K_Program_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJuQ =eybOdhCcSUrXjGpfEgIFizkvqmTJAB(eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('page'))
  eybOdhCcSUrXjGpfEgIFizkvqmTJWo,eybOdhCcSUrXjGpfEgIFizkvqmTJuB=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Get_UHD_ProgramList(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ)
  for eybOdhCcSUrXjGpfEgIFizkvqmTJWV in eybOdhCcSUrXjGpfEgIFizkvqmTJWo:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('title')
   eybOdhCcSUrXjGpfEgIFizkvqmTJut =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('thumbnail')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWD =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('synopsis')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWn =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('channel')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWu =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('cast')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWM =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('director')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWH=eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('info_genre')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWY =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('year')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWl =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('premiered')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWA =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('mpaa')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWx={'mediatype':'tvshow','title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'studio':eybOdhCcSUrXjGpfEgIFizkvqmTJWn,'cast':eybOdhCcSUrXjGpfEgIFizkvqmTJWu,'director':eybOdhCcSUrXjGpfEgIFizkvqmTJWM,'genre':eybOdhCcSUrXjGpfEgIFizkvqmTJWH,'year':eybOdhCcSUrXjGpfEgIFizkvqmTJWY,'premiered':eybOdhCcSUrXjGpfEgIFizkvqmTJWl,'mpaa':eybOdhCcSUrXjGpfEgIFizkvqmTJWA,'plot':eybOdhCcSUrXjGpfEgIFizkvqmTJWD}
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'EPISODE','programcode':eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('program'),'page':'1'}
   if eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_makebookmark():
    eybOdhCcSUrXjGpfEgIFizkvqmTJWa={'videoid':eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('program'),'vidtype':'tvshow','vtitle':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'vsubtitle':eybOdhCcSUrXjGpfEgIFizkvqmTJWn,}
    eybOdhCcSUrXjGpfEgIFizkvqmTJWN=json.dumps(eybOdhCcSUrXjGpfEgIFizkvqmTJWa)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWN=urllib.parse.quote(eybOdhCcSUrXjGpfEgIFizkvqmTJWN)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(eybOdhCcSUrXjGpfEgIFizkvqmTJWN)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWR=[('(통합) 찜 영상에 추가',eybOdhCcSUrXjGpfEgIFizkvqmTJWQ)]
   else:
    eybOdhCcSUrXjGpfEgIFizkvqmTJWR=eybOdhCcSUrXjGpfEgIFizkvqmTJAR
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJWn,img=eybOdhCcSUrXjGpfEgIFizkvqmTJut,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJWx,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK,ContextMenu=eybOdhCcSUrXjGpfEgIFizkvqmTJWR)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuB:
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['mode'] ='4K_PROGRAM' 
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['page'] =eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn='[B]%s >>[/B]'%'다음 페이지'
   eybOdhCcSUrXjGpfEgIFizkvqmTJWP=eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJuD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJWP,img=eybOdhCcSUrXjGpfEgIFizkvqmTJuD,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  xbmcplugin.setContent(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,cacheToDisc=eybOdhCcSUrXjGpfEgIFizkvqmTJAt)
 def dp_Ori_Program_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJuQ =eybOdhCcSUrXjGpfEgIFizkvqmTJAB(eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('page'))
  eybOdhCcSUrXjGpfEgIFizkvqmTJWo,eybOdhCcSUrXjGpfEgIFizkvqmTJuB=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Get_Origianl_ProgramList(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ)
  for eybOdhCcSUrXjGpfEgIFizkvqmTJWV in eybOdhCcSUrXjGpfEgIFizkvqmTJWo:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('title')
   eybOdhCcSUrXjGpfEgIFizkvqmTJut =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('thumbnail')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWw =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('vod_type')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWt =eybOdhCcSUrXjGpfEgIFizkvqmTJWV.get('vod_code')
   if eybOdhCcSUrXjGpfEgIFizkvqmTJWw=='vod':
    eybOdhCcSUrXjGpfEgIFizkvqmTJWx={'mediatype':'tvshow','title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,}
    eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'EPISODE','programcode':eybOdhCcSUrXjGpfEgIFizkvqmTJWt,'page':'1',}
    eybOdhCcSUrXjGpfEgIFizkvqmTJuW=eybOdhCcSUrXjGpfEgIFizkvqmTJAw
   else:
    eybOdhCcSUrXjGpfEgIFizkvqmTJWx={'mediatype':'movie','title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'plot':'movie',}
    eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'MOVIE','mediacode':eybOdhCcSUrXjGpfEgIFizkvqmTJWt,'stype':'movie','title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'thumbnail':eybOdhCcSUrXjGpfEgIFizkvqmTJut,}
    eybOdhCcSUrXjGpfEgIFizkvqmTJuW=eybOdhCcSUrXjGpfEgIFizkvqmTJAt
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,img=eybOdhCcSUrXjGpfEgIFizkvqmTJut,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJWx,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJuW,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK,ContextMenu=eybOdhCcSUrXjGpfEgIFizkvqmTJAR)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuB:
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['mode'] ='ORI_PROGRAM' 
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['page'] =eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn='[B]%s >>[/B]'%'다음 페이지'
   eybOdhCcSUrXjGpfEgIFizkvqmTJWP=eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJuD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJWP,img=eybOdhCcSUrXjGpfEgIFizkvqmTJuD,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  xbmcplugin.setContent(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,cacheToDisc=eybOdhCcSUrXjGpfEgIFizkvqmTJAt)
 def dp_Episode_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJMD=eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('programcode')
  eybOdhCcSUrXjGpfEgIFizkvqmTJuQ =eybOdhCcSUrXjGpfEgIFizkvqmTJAB(eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('page'))
  eybOdhCcSUrXjGpfEgIFizkvqmTJMK,eybOdhCcSUrXjGpfEgIFizkvqmTJuB,eybOdhCcSUrXjGpfEgIFizkvqmTJMu=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.GetEpisodeList(eybOdhCcSUrXjGpfEgIFizkvqmTJMD,eybOdhCcSUrXjGpfEgIFizkvqmTJuQ,orderby=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_winEpisodeOrderby())
  for eybOdhCcSUrXjGpfEgIFizkvqmTJMW in eybOdhCcSUrXjGpfEgIFizkvqmTJMK:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn =eybOdhCcSUrXjGpfEgIFizkvqmTJMW.get('title')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWP =eybOdhCcSUrXjGpfEgIFizkvqmTJMW.get('subtitle')
   eybOdhCcSUrXjGpfEgIFizkvqmTJut =eybOdhCcSUrXjGpfEgIFizkvqmTJMW.get('thumbnail')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWD =eybOdhCcSUrXjGpfEgIFizkvqmTJMW.get('synopsis')
   eybOdhCcSUrXjGpfEgIFizkvqmTJMH=eybOdhCcSUrXjGpfEgIFizkvqmTJMW.get('info_title')
   eybOdhCcSUrXjGpfEgIFizkvqmTJMY =eybOdhCcSUrXjGpfEgIFizkvqmTJMW.get('aired')
   eybOdhCcSUrXjGpfEgIFizkvqmTJMA =eybOdhCcSUrXjGpfEgIFizkvqmTJMW.get('studio')
   eybOdhCcSUrXjGpfEgIFizkvqmTJMl =eybOdhCcSUrXjGpfEgIFizkvqmTJMW.get('frequency')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWx={'mediatype':'episode','title':eybOdhCcSUrXjGpfEgIFizkvqmTJMH,'aired':eybOdhCcSUrXjGpfEgIFizkvqmTJMY,'studio':eybOdhCcSUrXjGpfEgIFizkvqmTJMA,'episode':eybOdhCcSUrXjGpfEgIFizkvqmTJMl,'plot':eybOdhCcSUrXjGpfEgIFizkvqmTJWD}
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'VOD','mediacode':eybOdhCcSUrXjGpfEgIFizkvqmTJMW.get('episode'),'stype':'vod','programcode':eybOdhCcSUrXjGpfEgIFizkvqmTJMD,'title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'thumbnail':eybOdhCcSUrXjGpfEgIFizkvqmTJut}
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJWP,img=eybOdhCcSUrXjGpfEgIFizkvqmTJut,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJWx,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAt,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuQ==1:
   eybOdhCcSUrXjGpfEgIFizkvqmTJWx={'plot':'정렬순서를 변경합니다.'}
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={}
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['mode'] ='ORDER_BY' 
   if eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_winEpisodeOrderby()=='desc':
    eybOdhCcSUrXjGpfEgIFizkvqmTJKn='정렬순서변경 : 최신화부터 -> 1회부터'
    eybOdhCcSUrXjGpfEgIFizkvqmTJuK['orderby']='asc'
   else:
    eybOdhCcSUrXjGpfEgIFizkvqmTJKn='정렬순서변경 : 1회부터 -> 최신화부터'
    eybOdhCcSUrXjGpfEgIFizkvqmTJuK['orderby']='desc'
   eybOdhCcSUrXjGpfEgIFizkvqmTJuD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel='',img=eybOdhCcSUrXjGpfEgIFizkvqmTJuD,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJWx,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAt,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK,isLink=eybOdhCcSUrXjGpfEgIFizkvqmTJAw)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuB:
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['mode'] ='EPISODE' 
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['programcode']=eybOdhCcSUrXjGpfEgIFizkvqmTJMD
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['page'] =eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn='[B]%s >>[/B]'%'다음 페이지'
   eybOdhCcSUrXjGpfEgIFizkvqmTJWP=eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJuD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJWP,img=eybOdhCcSUrXjGpfEgIFizkvqmTJuD,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  xbmcplugin.setContent(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,'episodes')
  if eybOdhCcSUrXjGpfEgIFizkvqmTJlM(eybOdhCcSUrXjGpfEgIFizkvqmTJMK)>0:xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,cacheToDisc=eybOdhCcSUrXjGpfEgIFizkvqmTJAw)
 def dp_setEpOrderby(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJKo =eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('orderby')
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.set_winEpisodeOrderby(eybOdhCcSUrXjGpfEgIFizkvqmTJKo)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJWL =eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('stype')
  eybOdhCcSUrXjGpfEgIFizkvqmTJKo =eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('orderby')
  eybOdhCcSUrXjGpfEgIFizkvqmTJuQ=eybOdhCcSUrXjGpfEgIFizkvqmTJAB(eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('page'))
  eybOdhCcSUrXjGpfEgIFizkvqmTJMx,eybOdhCcSUrXjGpfEgIFizkvqmTJuB=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.GetMovieList(eybOdhCcSUrXjGpfEgIFizkvqmTJWL,eybOdhCcSUrXjGpfEgIFizkvqmTJKo,eybOdhCcSUrXjGpfEgIFizkvqmTJuQ)
  for eybOdhCcSUrXjGpfEgIFizkvqmTJMP in eybOdhCcSUrXjGpfEgIFizkvqmTJMx:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('title')
   eybOdhCcSUrXjGpfEgIFizkvqmTJut =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('thumbnail')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWD =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('synopsis')
   eybOdhCcSUrXjGpfEgIFizkvqmTJMH =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('info_title')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWY =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('year')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWu =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('cast')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWM =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('director')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWH =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('info_genre')
   eybOdhCcSUrXjGpfEgIFizkvqmTJML =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('duration')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWl =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('premiered')
   eybOdhCcSUrXjGpfEgIFizkvqmTJMA =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('studio')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWA =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('mpaa')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWx={'mediatype':'movie','title':eybOdhCcSUrXjGpfEgIFizkvqmTJMH,'year':eybOdhCcSUrXjGpfEgIFizkvqmTJWY,'cast':eybOdhCcSUrXjGpfEgIFizkvqmTJWu,'director':eybOdhCcSUrXjGpfEgIFizkvqmTJWM,'genre':eybOdhCcSUrXjGpfEgIFizkvqmTJWH,'duration':eybOdhCcSUrXjGpfEgIFizkvqmTJML,'premiered':eybOdhCcSUrXjGpfEgIFizkvqmTJWl,'studio':eybOdhCcSUrXjGpfEgIFizkvqmTJMA,'mpaa':eybOdhCcSUrXjGpfEgIFizkvqmTJWA,'plot':eybOdhCcSUrXjGpfEgIFizkvqmTJWD}
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'MOVIE','mediacode':eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('moviecode'),'stype':'movie','title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'thumbnail':eybOdhCcSUrXjGpfEgIFizkvqmTJut}
   if eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_makebookmark():
    eybOdhCcSUrXjGpfEgIFizkvqmTJWa={'videoid':eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('moviecode'),'vidtype':'movie','vtitle':eybOdhCcSUrXjGpfEgIFizkvqmTJMH,'vsubtitle':'',}
    eybOdhCcSUrXjGpfEgIFizkvqmTJWN=json.dumps(eybOdhCcSUrXjGpfEgIFizkvqmTJWa)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWN=urllib.parse.quote(eybOdhCcSUrXjGpfEgIFizkvqmTJWN)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(eybOdhCcSUrXjGpfEgIFizkvqmTJWN)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWR=[('(통합) 찜 영상에 추가',eybOdhCcSUrXjGpfEgIFizkvqmTJWQ)]
   else:
    eybOdhCcSUrXjGpfEgIFizkvqmTJWR=eybOdhCcSUrXjGpfEgIFizkvqmTJAR
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel='',img=eybOdhCcSUrXjGpfEgIFizkvqmTJut,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJWx,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAt,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK,ContextMenu=eybOdhCcSUrXjGpfEgIFizkvqmTJWR)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuB:
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={}
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['mode'] ='MOVIE_SUB' 
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['orderby']=eybOdhCcSUrXjGpfEgIFizkvqmTJKo
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['stype'] =eybOdhCcSUrXjGpfEgIFizkvqmTJWL
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['page'] =eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn='[B]%s >>[/B]'%'다음 페이지'
   eybOdhCcSUrXjGpfEgIFizkvqmTJWP=eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJuD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJWP,img=eybOdhCcSUrXjGpfEgIFizkvqmTJuD,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  xbmcplugin.setContent(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,'movies')
  xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,cacheToDisc=eybOdhCcSUrXjGpfEgIFizkvqmTJAt)
 def dp_4K_Movie_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJuQ=eybOdhCcSUrXjGpfEgIFizkvqmTJAB(eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('page'))
  eybOdhCcSUrXjGpfEgIFizkvqmTJMx,eybOdhCcSUrXjGpfEgIFizkvqmTJuB=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Get_UHD_MovieList(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ)
  for eybOdhCcSUrXjGpfEgIFizkvqmTJMP in eybOdhCcSUrXjGpfEgIFizkvqmTJMx:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('title')
   eybOdhCcSUrXjGpfEgIFizkvqmTJut =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('thumbnail')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWD =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('synopsis')
   eybOdhCcSUrXjGpfEgIFizkvqmTJMH =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('info_title')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWY =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('year')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWu =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('cast')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWM =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('director')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWH =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('info_genre')
   eybOdhCcSUrXjGpfEgIFizkvqmTJML =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('duration')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWl =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('premiered')
   eybOdhCcSUrXjGpfEgIFizkvqmTJMA =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('studio')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWA =eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('mpaa')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWx={'mediatype':'movie','title':eybOdhCcSUrXjGpfEgIFizkvqmTJMH,'year':eybOdhCcSUrXjGpfEgIFizkvqmTJWY,'cast':eybOdhCcSUrXjGpfEgIFizkvqmTJWu,'director':eybOdhCcSUrXjGpfEgIFizkvqmTJWM,'genre':eybOdhCcSUrXjGpfEgIFizkvqmTJWH,'duration':eybOdhCcSUrXjGpfEgIFizkvqmTJML,'premiered':eybOdhCcSUrXjGpfEgIFizkvqmTJWl,'studio':eybOdhCcSUrXjGpfEgIFizkvqmTJMA,'mpaa':eybOdhCcSUrXjGpfEgIFizkvqmTJWA,'plot':eybOdhCcSUrXjGpfEgIFizkvqmTJWD}
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'MOVIE','mediacode':eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('moviecode'),'stype':'movie','title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'thumbnail':eybOdhCcSUrXjGpfEgIFizkvqmTJut}
   if eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_makebookmark():
    eybOdhCcSUrXjGpfEgIFizkvqmTJWa={'videoid':eybOdhCcSUrXjGpfEgIFizkvqmTJMP.get('moviecode'),'vidtype':'movie','vtitle':eybOdhCcSUrXjGpfEgIFizkvqmTJMH,'vsubtitle':'',}
    eybOdhCcSUrXjGpfEgIFizkvqmTJWN=json.dumps(eybOdhCcSUrXjGpfEgIFizkvqmTJWa)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWN=urllib.parse.quote(eybOdhCcSUrXjGpfEgIFizkvqmTJWN)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(eybOdhCcSUrXjGpfEgIFizkvqmTJWN)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWR=[('(통합) 찜 영상에 추가',eybOdhCcSUrXjGpfEgIFizkvqmTJWQ)]
   else:
    eybOdhCcSUrXjGpfEgIFizkvqmTJWR=eybOdhCcSUrXjGpfEgIFizkvqmTJAR
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel='',img=eybOdhCcSUrXjGpfEgIFizkvqmTJut,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJWx,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAt,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK,ContextMenu=eybOdhCcSUrXjGpfEgIFizkvqmTJWR)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuB:
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={}
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['mode'] ='4K_MOVIE' 
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['page'] =eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn='[B]%s >>[/B]'%'다음 페이지'
   eybOdhCcSUrXjGpfEgIFizkvqmTJWP=eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJuD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJWP,img=eybOdhCcSUrXjGpfEgIFizkvqmTJuD,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  xbmcplugin.setContent(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,'movies')
  xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,cacheToDisc=eybOdhCcSUrXjGpfEgIFizkvqmTJAt)
 def dp_Set_Bookmark(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJMs=urllib.parse.unquote(eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('bm_param'))
  eybOdhCcSUrXjGpfEgIFizkvqmTJMs=json.loads(eybOdhCcSUrXjGpfEgIFizkvqmTJMs)
  eybOdhCcSUrXjGpfEgIFizkvqmTJMo =eybOdhCcSUrXjGpfEgIFizkvqmTJMs.get('videoid')
  eybOdhCcSUrXjGpfEgIFizkvqmTJMV =eybOdhCcSUrXjGpfEgIFizkvqmTJMs.get('vidtype')
  eybOdhCcSUrXjGpfEgIFizkvqmTJMn =eybOdhCcSUrXjGpfEgIFizkvqmTJMs.get('vtitle')
  eybOdhCcSUrXjGpfEgIFizkvqmTJMa =eybOdhCcSUrXjGpfEgIFizkvqmTJMs.get('vsubtitle')
  eybOdhCcSUrXjGpfEgIFizkvqmTJDN=xbmcgui.Dialog()
  eybOdhCcSUrXjGpfEgIFizkvqmTJuL=eybOdhCcSUrXjGpfEgIFizkvqmTJDN.yesno(__language__(30913).encode('utf8'),eybOdhCcSUrXjGpfEgIFizkvqmTJMn+' \n\n'+__language__(30914))
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuL==eybOdhCcSUrXjGpfEgIFizkvqmTJAt:return
  eybOdhCcSUrXjGpfEgIFizkvqmTJMN=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.GetBookmarkInfo(eybOdhCcSUrXjGpfEgIFizkvqmTJMo,eybOdhCcSUrXjGpfEgIFizkvqmTJMV)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJMa!='':
   eybOdhCcSUrXjGpfEgIFizkvqmTJMN['saveinfo']['subtitle']=eybOdhCcSUrXjGpfEgIFizkvqmTJMa 
   if eybOdhCcSUrXjGpfEgIFizkvqmTJMV=='tvshow':eybOdhCcSUrXjGpfEgIFizkvqmTJMN['saveinfo']['infoLabels']['studio']=eybOdhCcSUrXjGpfEgIFizkvqmTJMa 
  eybOdhCcSUrXjGpfEgIFizkvqmTJMQ=json.dumps(eybOdhCcSUrXjGpfEgIFizkvqmTJMN)
  eybOdhCcSUrXjGpfEgIFizkvqmTJMQ=urllib.parse.quote(eybOdhCcSUrXjGpfEgIFizkvqmTJMQ)
  eybOdhCcSUrXjGpfEgIFizkvqmTJWQ ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(eybOdhCcSUrXjGpfEgIFizkvqmTJMQ)
  xbmc.executebuiltin(eybOdhCcSUrXjGpfEgIFizkvqmTJWQ)
 def dp_Search_Group(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  if 'search_key' in eybOdhCcSUrXjGpfEgIFizkvqmTJuN:
   eybOdhCcSUrXjGpfEgIFizkvqmTJMR=eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('search_key')
  else:
   eybOdhCcSUrXjGpfEgIFizkvqmTJMR=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not eybOdhCcSUrXjGpfEgIFizkvqmTJMR:
    return
  for eybOdhCcSUrXjGpfEgIFizkvqmTJua in eybOdhCcSUrXjGpfEgIFizkvqmTJDH:
   eybOdhCcSUrXjGpfEgIFizkvqmTJMB =eybOdhCcSUrXjGpfEgIFizkvqmTJua.get('mode')
   eybOdhCcSUrXjGpfEgIFizkvqmTJuV=eybOdhCcSUrXjGpfEgIFizkvqmTJua.get('stype')
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn=eybOdhCcSUrXjGpfEgIFizkvqmTJua.get('title')
   (eybOdhCcSUrXjGpfEgIFizkvqmTJMw,eybOdhCcSUrXjGpfEgIFizkvqmTJuB)=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.GetSearchList(eybOdhCcSUrXjGpfEgIFizkvqmTJMR,1,eybOdhCcSUrXjGpfEgIFizkvqmTJuV)
   eybOdhCcSUrXjGpfEgIFizkvqmTJuH={'plot':'검색어 : '+eybOdhCcSUrXjGpfEgIFizkvqmTJMR+'\n\n'+eybOdhCcSUrXjGpfEgIFizkvqmTJDs.Search_FreeList(eybOdhCcSUrXjGpfEgIFizkvqmTJMw)}
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':eybOdhCcSUrXjGpfEgIFizkvqmTJMB,'stype':eybOdhCcSUrXjGpfEgIFizkvqmTJuV,'search_key':eybOdhCcSUrXjGpfEgIFizkvqmTJMR,'page':'1',}
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel='',img='',infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJuH,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJlM(eybOdhCcSUrXjGpfEgIFizkvqmTJDH)>0:xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,cacheToDisc=eybOdhCcSUrXjGpfEgIFizkvqmTJAw)
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.Save_Searched_List(eybOdhCcSUrXjGpfEgIFizkvqmTJMR)
 def Search_FreeList(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJHl):
  eybOdhCcSUrXjGpfEgIFizkvqmTJMt=''
  eybOdhCcSUrXjGpfEgIFizkvqmTJHD=7
  try:
   if eybOdhCcSUrXjGpfEgIFizkvqmTJlM(eybOdhCcSUrXjGpfEgIFizkvqmTJHl)==0:return '검색결과 없음'
   for i in eybOdhCcSUrXjGpfEgIFizkvqmTJlY(eybOdhCcSUrXjGpfEgIFizkvqmTJlM(eybOdhCcSUrXjGpfEgIFizkvqmTJHl)):
    if i>=eybOdhCcSUrXjGpfEgIFizkvqmTJHD:
     eybOdhCcSUrXjGpfEgIFizkvqmTJMt=eybOdhCcSUrXjGpfEgIFizkvqmTJMt+'...'
     break
    eybOdhCcSUrXjGpfEgIFizkvqmTJMt=eybOdhCcSUrXjGpfEgIFizkvqmTJMt+eybOdhCcSUrXjGpfEgIFizkvqmTJHl[i]['title']+'\n'
  except:
   return ''
  return eybOdhCcSUrXjGpfEgIFizkvqmTJMt
 def dp_Search_History(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJHK=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.Load_List_File('search')
  for eybOdhCcSUrXjGpfEgIFizkvqmTJHu in eybOdhCcSUrXjGpfEgIFizkvqmTJHK:
   eybOdhCcSUrXjGpfEgIFizkvqmTJHW=eybOdhCcSUrXjGpfEgIFizkvqmTJlK(urllib.parse.parse_qsl(eybOdhCcSUrXjGpfEgIFizkvqmTJHu))
   eybOdhCcSUrXjGpfEgIFizkvqmTJHM=eybOdhCcSUrXjGpfEgIFizkvqmTJHW.get('skey').strip()
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'SEARCH_GROUP','search_key':eybOdhCcSUrXjGpfEgIFizkvqmTJHM,}
   eybOdhCcSUrXjGpfEgIFizkvqmTJHY={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':eybOdhCcSUrXjGpfEgIFizkvqmTJHM,'vType':'-',}
   eybOdhCcSUrXjGpfEgIFizkvqmTJHA=urllib.parse.urlencode(eybOdhCcSUrXjGpfEgIFizkvqmTJHY)
   eybOdhCcSUrXjGpfEgIFizkvqmTJWR=[('선택된 검색어 ( %s ) 삭제'%(eybOdhCcSUrXjGpfEgIFizkvqmTJHM),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(eybOdhCcSUrXjGpfEgIFizkvqmTJHA))]
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJHM,sublabel='',img=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK,ContextMenu=eybOdhCcSUrXjGpfEgIFizkvqmTJWR)
  eybOdhCcSUrXjGpfEgIFizkvqmTJWx={'plot':'검색목록 전체를 삭제합니다.'}
  eybOdhCcSUrXjGpfEgIFizkvqmTJKn='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  eybOdhCcSUrXjGpfEgIFizkvqmTJuD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel='',img=eybOdhCcSUrXjGpfEgIFizkvqmTJuD,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJWx,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAt,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK,isLink=eybOdhCcSUrXjGpfEgIFizkvqmTJAw)
  xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,cacheToDisc=eybOdhCcSUrXjGpfEgIFizkvqmTJAt)
 def dp_Search_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJuQ =eybOdhCcSUrXjGpfEgIFizkvqmTJAB(eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('page'))
  eybOdhCcSUrXjGpfEgIFizkvqmTJuV =eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('stype')
  if 'search_key' in eybOdhCcSUrXjGpfEgIFizkvqmTJuN:
   eybOdhCcSUrXjGpfEgIFizkvqmTJMR=eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('search_key')
  else:
   eybOdhCcSUrXjGpfEgIFizkvqmTJMR=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not eybOdhCcSUrXjGpfEgIFizkvqmTJMR:
    xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle)
    return
  eybOdhCcSUrXjGpfEgIFizkvqmTJMw,eybOdhCcSUrXjGpfEgIFizkvqmTJuB=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.GetSearchList(eybOdhCcSUrXjGpfEgIFizkvqmTJMR,eybOdhCcSUrXjGpfEgIFizkvqmTJuQ,eybOdhCcSUrXjGpfEgIFizkvqmTJuV)
  for eybOdhCcSUrXjGpfEgIFizkvqmTJHl in eybOdhCcSUrXjGpfEgIFizkvqmTJMw:
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn =eybOdhCcSUrXjGpfEgIFizkvqmTJHl.get('title')
   eybOdhCcSUrXjGpfEgIFizkvqmTJut =eybOdhCcSUrXjGpfEgIFizkvqmTJHl.get('thumbnail')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWD =eybOdhCcSUrXjGpfEgIFizkvqmTJHl.get('synopsis')
   eybOdhCcSUrXjGpfEgIFizkvqmTJHx =eybOdhCcSUrXjGpfEgIFizkvqmTJHl.get('program')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWu =eybOdhCcSUrXjGpfEgIFizkvqmTJHl.get('cast')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWM =eybOdhCcSUrXjGpfEgIFizkvqmTJHl.get('director')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWH=eybOdhCcSUrXjGpfEgIFizkvqmTJHl.get('info_genre')
   eybOdhCcSUrXjGpfEgIFizkvqmTJML =eybOdhCcSUrXjGpfEgIFizkvqmTJHl.get('duration')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWA =eybOdhCcSUrXjGpfEgIFizkvqmTJHl.get('mpaa')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWY =eybOdhCcSUrXjGpfEgIFizkvqmTJHl.get('year')
   eybOdhCcSUrXjGpfEgIFizkvqmTJMY =eybOdhCcSUrXjGpfEgIFizkvqmTJHl.get('aired')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWx={'mediatype':'tvshow' if eybOdhCcSUrXjGpfEgIFizkvqmTJuV=='vod' else 'movie','title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'cast':eybOdhCcSUrXjGpfEgIFizkvqmTJWu,'director':eybOdhCcSUrXjGpfEgIFizkvqmTJWM,'genre':eybOdhCcSUrXjGpfEgIFizkvqmTJWH,'duration':eybOdhCcSUrXjGpfEgIFizkvqmTJML,'mpaa':eybOdhCcSUrXjGpfEgIFizkvqmTJWA,'year':eybOdhCcSUrXjGpfEgIFizkvqmTJWY,'aired':eybOdhCcSUrXjGpfEgIFizkvqmTJMY,'plot':'%s\n\n%s'%(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,eybOdhCcSUrXjGpfEgIFizkvqmTJWD)}
   if eybOdhCcSUrXjGpfEgIFizkvqmTJuV=='vod':
    eybOdhCcSUrXjGpfEgIFizkvqmTJMo=eybOdhCcSUrXjGpfEgIFizkvqmTJHl.get('program')
    eybOdhCcSUrXjGpfEgIFizkvqmTJMV='tvshow'
    eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'EPISODE','programcode':eybOdhCcSUrXjGpfEgIFizkvqmTJMo,'page':'1',}
    eybOdhCcSUrXjGpfEgIFizkvqmTJuW=eybOdhCcSUrXjGpfEgIFizkvqmTJAw
   else:
    eybOdhCcSUrXjGpfEgIFizkvqmTJMo=eybOdhCcSUrXjGpfEgIFizkvqmTJHl.get('movie')
    eybOdhCcSUrXjGpfEgIFizkvqmTJMV='movie'
    eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'MOVIE','mediacode':eybOdhCcSUrXjGpfEgIFizkvqmTJMo,'stype':'movie','title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'thumbnail':eybOdhCcSUrXjGpfEgIFizkvqmTJut,}
    eybOdhCcSUrXjGpfEgIFizkvqmTJuW=eybOdhCcSUrXjGpfEgIFizkvqmTJAt
   if eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_makebookmark():
    eybOdhCcSUrXjGpfEgIFizkvqmTJWa={'videoid':eybOdhCcSUrXjGpfEgIFizkvqmTJMo,'vidtype':eybOdhCcSUrXjGpfEgIFizkvqmTJMV,'vtitle':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'vsubtitle':'',}
    eybOdhCcSUrXjGpfEgIFizkvqmTJWN=json.dumps(eybOdhCcSUrXjGpfEgIFizkvqmTJWa)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWN=urllib.parse.quote(eybOdhCcSUrXjGpfEgIFizkvqmTJWN)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(eybOdhCcSUrXjGpfEgIFizkvqmTJWN)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWR=[('(통합) 찜 영상에 추가',eybOdhCcSUrXjGpfEgIFizkvqmTJWQ)]
   else:
    eybOdhCcSUrXjGpfEgIFizkvqmTJWR=eybOdhCcSUrXjGpfEgIFizkvqmTJAR
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel='',img=eybOdhCcSUrXjGpfEgIFizkvqmTJut,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJWx,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJuW,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK,isLink=eybOdhCcSUrXjGpfEgIFizkvqmTJAt,ContextMenu=eybOdhCcSUrXjGpfEgIFizkvqmTJWR)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuB:
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['mode'] ='SEARCH' 
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['search_key']=eybOdhCcSUrXjGpfEgIFizkvqmTJMR
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK['page'] =eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn='[B]%s >>[/B]'%'다음 페이지'
   eybOdhCcSUrXjGpfEgIFizkvqmTJWP=eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJuQ+1)
   eybOdhCcSUrXjGpfEgIFizkvqmTJuD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJWP,img=eybOdhCcSUrXjGpfEgIFizkvqmTJuD,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuV=='movie':xbmcplugin.setContent(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,'movies')
  else:xbmcplugin.setContent(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,cacheToDisc=eybOdhCcSUrXjGpfEgIFizkvqmTJAt)
 def dp_History_Remove(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJHP=eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('delType')
  eybOdhCcSUrXjGpfEgIFizkvqmTJHL =eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('sKey')
  eybOdhCcSUrXjGpfEgIFizkvqmTJHs =eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('vType')
  eybOdhCcSUrXjGpfEgIFizkvqmTJDN=xbmcgui.Dialog()
  if eybOdhCcSUrXjGpfEgIFizkvqmTJHP=='SEARCH_ALL':
   eybOdhCcSUrXjGpfEgIFizkvqmTJuL=eybOdhCcSUrXjGpfEgIFizkvqmTJDN.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJHP=='SEARCH_ONE':
   eybOdhCcSUrXjGpfEgIFizkvqmTJuL=eybOdhCcSUrXjGpfEgIFizkvqmTJDN.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJHP=='WATCH_ALL':
   eybOdhCcSUrXjGpfEgIFizkvqmTJuL=eybOdhCcSUrXjGpfEgIFizkvqmTJDN.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJHP=='WATCH_ONE':
   eybOdhCcSUrXjGpfEgIFizkvqmTJuL=eybOdhCcSUrXjGpfEgIFizkvqmTJDN.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuL==eybOdhCcSUrXjGpfEgIFizkvqmTJAt:sys.exit()
  if eybOdhCcSUrXjGpfEgIFizkvqmTJHP=='SEARCH_ALL':
   if os.path.isfile(eybOdhCcSUrXjGpfEgIFizkvqmTJDL):os.remove(eybOdhCcSUrXjGpfEgIFizkvqmTJDL)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJHP=='SEARCH_ONE':
   try:
    eybOdhCcSUrXjGpfEgIFizkvqmTJHo=eybOdhCcSUrXjGpfEgIFizkvqmTJDL
    eybOdhCcSUrXjGpfEgIFizkvqmTJHV=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.Load_List_File('search') 
    fp=eybOdhCcSUrXjGpfEgIFizkvqmTJlA(eybOdhCcSUrXjGpfEgIFizkvqmTJHo,'w',-1,'utf-8')
    for eybOdhCcSUrXjGpfEgIFizkvqmTJHn in eybOdhCcSUrXjGpfEgIFizkvqmTJHV:
     eybOdhCcSUrXjGpfEgIFizkvqmTJHa=eybOdhCcSUrXjGpfEgIFizkvqmTJlK(urllib.parse.parse_qsl(eybOdhCcSUrXjGpfEgIFizkvqmTJHn))
     eybOdhCcSUrXjGpfEgIFizkvqmTJHN=eybOdhCcSUrXjGpfEgIFizkvqmTJHa.get('skey').strip()
     if eybOdhCcSUrXjGpfEgIFizkvqmTJHL!=eybOdhCcSUrXjGpfEgIFizkvqmTJHN:
      fp.write(eybOdhCcSUrXjGpfEgIFizkvqmTJHn)
    fp.close()
   except:
    eybOdhCcSUrXjGpfEgIFizkvqmTJAR
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJHP=='WATCH_ALL':
   eybOdhCcSUrXjGpfEgIFizkvqmTJHo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eybOdhCcSUrXjGpfEgIFizkvqmTJHs))
   if os.path.isfile(eybOdhCcSUrXjGpfEgIFizkvqmTJHo):os.remove(eybOdhCcSUrXjGpfEgIFizkvqmTJHo)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJHP=='WATCH_ONE':
   eybOdhCcSUrXjGpfEgIFizkvqmTJHo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eybOdhCcSUrXjGpfEgIFizkvqmTJHs))
   try:
    eybOdhCcSUrXjGpfEgIFizkvqmTJHV=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.Load_List_File(eybOdhCcSUrXjGpfEgIFizkvqmTJHs) 
    fp=eybOdhCcSUrXjGpfEgIFizkvqmTJlA(eybOdhCcSUrXjGpfEgIFizkvqmTJHo,'w',-1,'utf-8')
    for eybOdhCcSUrXjGpfEgIFizkvqmTJHn in eybOdhCcSUrXjGpfEgIFizkvqmTJHV:
     eybOdhCcSUrXjGpfEgIFizkvqmTJHa=eybOdhCcSUrXjGpfEgIFizkvqmTJlK(urllib.parse.parse_qsl(eybOdhCcSUrXjGpfEgIFizkvqmTJHn))
     eybOdhCcSUrXjGpfEgIFizkvqmTJHN=eybOdhCcSUrXjGpfEgIFizkvqmTJHa.get('code').strip()
     if eybOdhCcSUrXjGpfEgIFizkvqmTJHL!=eybOdhCcSUrXjGpfEgIFizkvqmTJHN:
      fp.write(eybOdhCcSUrXjGpfEgIFizkvqmTJHn)
    fp.close()
   except:
    eybOdhCcSUrXjGpfEgIFizkvqmTJAR
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuV): 
  try:
   if eybOdhCcSUrXjGpfEgIFizkvqmTJuV=='search':
    eybOdhCcSUrXjGpfEgIFizkvqmTJHo=eybOdhCcSUrXjGpfEgIFizkvqmTJDL
   elif eybOdhCcSUrXjGpfEgIFizkvqmTJuV in['vod','movie']:
    eybOdhCcSUrXjGpfEgIFizkvqmTJHo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eybOdhCcSUrXjGpfEgIFizkvqmTJuV))
   else:
    return[]
   fp=eybOdhCcSUrXjGpfEgIFizkvqmTJlA(eybOdhCcSUrXjGpfEgIFizkvqmTJHo,'r',-1,'utf-8')
   eybOdhCcSUrXjGpfEgIFizkvqmTJHQ=fp.readlines()
   fp.close()
  except:
   eybOdhCcSUrXjGpfEgIFizkvqmTJHQ=[]
  return eybOdhCcSUrXjGpfEgIFizkvqmTJHQ
 def Save_Watched_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuV,eybOdhCcSUrXjGpfEgIFizkvqmTJDn):
  try:
   eybOdhCcSUrXjGpfEgIFizkvqmTJHR=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%eybOdhCcSUrXjGpfEgIFizkvqmTJuV))
   eybOdhCcSUrXjGpfEgIFizkvqmTJHV=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.Load_List_File(eybOdhCcSUrXjGpfEgIFizkvqmTJuV) 
   fp=eybOdhCcSUrXjGpfEgIFizkvqmTJlA(eybOdhCcSUrXjGpfEgIFizkvqmTJHR,'w',-1,'utf-8')
   eybOdhCcSUrXjGpfEgIFizkvqmTJHB=urllib.parse.urlencode(eybOdhCcSUrXjGpfEgIFizkvqmTJDn)
   eybOdhCcSUrXjGpfEgIFizkvqmTJHB=eybOdhCcSUrXjGpfEgIFizkvqmTJHB+'\n'
   fp.write(eybOdhCcSUrXjGpfEgIFizkvqmTJHB)
   eybOdhCcSUrXjGpfEgIFizkvqmTJHw=0
   for eybOdhCcSUrXjGpfEgIFizkvqmTJHn in eybOdhCcSUrXjGpfEgIFizkvqmTJHV:
    eybOdhCcSUrXjGpfEgIFizkvqmTJHa=eybOdhCcSUrXjGpfEgIFizkvqmTJlK(urllib.parse.parse_qsl(eybOdhCcSUrXjGpfEgIFizkvqmTJHn))
    eybOdhCcSUrXjGpfEgIFizkvqmTJHt=eybOdhCcSUrXjGpfEgIFizkvqmTJDn.get('code').strip()
    eybOdhCcSUrXjGpfEgIFizkvqmTJYD=eybOdhCcSUrXjGpfEgIFizkvqmTJHa.get('code').strip()
    if eybOdhCcSUrXjGpfEgIFizkvqmTJuV=='vod' and eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_direct_replay()==eybOdhCcSUrXjGpfEgIFizkvqmTJAw:
     eybOdhCcSUrXjGpfEgIFizkvqmTJHt=eybOdhCcSUrXjGpfEgIFizkvqmTJDn.get('videoid').strip()
     eybOdhCcSUrXjGpfEgIFizkvqmTJYD=eybOdhCcSUrXjGpfEgIFizkvqmTJHa.get('videoid').strip()if eybOdhCcSUrXjGpfEgIFizkvqmTJYD!=eybOdhCcSUrXjGpfEgIFizkvqmTJAR else '-'
    if eybOdhCcSUrXjGpfEgIFizkvqmTJHt!=eybOdhCcSUrXjGpfEgIFizkvqmTJYD:
     fp.write(eybOdhCcSUrXjGpfEgIFizkvqmTJHn)
     eybOdhCcSUrXjGpfEgIFizkvqmTJHw+=1
     if eybOdhCcSUrXjGpfEgIFizkvqmTJHw>=50:break
   fp.close()
  except:
   eybOdhCcSUrXjGpfEgIFizkvqmTJAR
 def dp_Watch_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJuV =eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('stype')
  eybOdhCcSUrXjGpfEgIFizkvqmTJKL=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_direct_replay()
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuV=='-':
   for eybOdhCcSUrXjGpfEgIFizkvqmTJua in eybOdhCcSUrXjGpfEgIFizkvqmTJDM:
    eybOdhCcSUrXjGpfEgIFizkvqmTJKn=eybOdhCcSUrXjGpfEgIFizkvqmTJua.get('title')
    eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':eybOdhCcSUrXjGpfEgIFizkvqmTJua.get('mode'),'stype':eybOdhCcSUrXjGpfEgIFizkvqmTJua.get('stype')}
    eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel='',img='',infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJAR,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAw,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
   if eybOdhCcSUrXjGpfEgIFizkvqmTJlM(eybOdhCcSUrXjGpfEgIFizkvqmTJDM)>0:xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle)
  else:
   eybOdhCcSUrXjGpfEgIFizkvqmTJYK=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.Load_List_File(eybOdhCcSUrXjGpfEgIFizkvqmTJuV)
   for eybOdhCcSUrXjGpfEgIFizkvqmTJYu in eybOdhCcSUrXjGpfEgIFizkvqmTJYK:
    eybOdhCcSUrXjGpfEgIFizkvqmTJHW=eybOdhCcSUrXjGpfEgIFizkvqmTJlK(urllib.parse.parse_qsl(eybOdhCcSUrXjGpfEgIFizkvqmTJYu))
    eybOdhCcSUrXjGpfEgIFizkvqmTJYW =eybOdhCcSUrXjGpfEgIFizkvqmTJHW.get('code').strip()
    eybOdhCcSUrXjGpfEgIFizkvqmTJKn =eybOdhCcSUrXjGpfEgIFizkvqmTJHW.get('title').strip()
    eybOdhCcSUrXjGpfEgIFizkvqmTJut=eybOdhCcSUrXjGpfEgIFizkvqmTJHW.get('img').strip()
    eybOdhCcSUrXjGpfEgIFizkvqmTJMo =eybOdhCcSUrXjGpfEgIFizkvqmTJHW.get('videoid').strip()
    try:
     eybOdhCcSUrXjGpfEgIFizkvqmTJut=eybOdhCcSUrXjGpfEgIFizkvqmTJut.replace('\'','\"')
     eybOdhCcSUrXjGpfEgIFizkvqmTJut=json.loads(eybOdhCcSUrXjGpfEgIFizkvqmTJut)
    except:
     eybOdhCcSUrXjGpfEgIFizkvqmTJAR
    eybOdhCcSUrXjGpfEgIFizkvqmTJWx={}
    eybOdhCcSUrXjGpfEgIFizkvqmTJWx['plot']=eybOdhCcSUrXjGpfEgIFizkvqmTJKn
    if eybOdhCcSUrXjGpfEgIFizkvqmTJuV=='vod':
     if eybOdhCcSUrXjGpfEgIFizkvqmTJKL==eybOdhCcSUrXjGpfEgIFizkvqmTJAt or eybOdhCcSUrXjGpfEgIFizkvqmTJMo==eybOdhCcSUrXjGpfEgIFizkvqmTJAR:
      eybOdhCcSUrXjGpfEgIFizkvqmTJWx['mediatype']='tvshow'
      eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'EPISODE','programcode':eybOdhCcSUrXjGpfEgIFizkvqmTJYW,'page':'1'}
      eybOdhCcSUrXjGpfEgIFizkvqmTJuW=eybOdhCcSUrXjGpfEgIFizkvqmTJAw
     else:
      eybOdhCcSUrXjGpfEgIFizkvqmTJWx['mediatype']='episode'
      eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'VOD','mediacode':eybOdhCcSUrXjGpfEgIFizkvqmTJMo,'stype':'vod','programcode':eybOdhCcSUrXjGpfEgIFizkvqmTJYW,'title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'thumbnail':eybOdhCcSUrXjGpfEgIFizkvqmTJut}
      eybOdhCcSUrXjGpfEgIFizkvqmTJuW=eybOdhCcSUrXjGpfEgIFizkvqmTJAt
    else:
     eybOdhCcSUrXjGpfEgIFizkvqmTJWx['mediatype']='movie'
     eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'MOVIE','mediacode':eybOdhCcSUrXjGpfEgIFizkvqmTJYW,'stype':'movie','title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'thumbnail':eybOdhCcSUrXjGpfEgIFizkvqmTJut}
     eybOdhCcSUrXjGpfEgIFizkvqmTJuW=eybOdhCcSUrXjGpfEgIFizkvqmTJAt
    eybOdhCcSUrXjGpfEgIFizkvqmTJHY={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':eybOdhCcSUrXjGpfEgIFizkvqmTJYW,'vType':eybOdhCcSUrXjGpfEgIFizkvqmTJuV,}
    eybOdhCcSUrXjGpfEgIFizkvqmTJHA=urllib.parse.urlencode(eybOdhCcSUrXjGpfEgIFizkvqmTJHY)
    eybOdhCcSUrXjGpfEgIFizkvqmTJWR=[('선택된 시청이력 ( %s ) 삭제'%(eybOdhCcSUrXjGpfEgIFizkvqmTJKn),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(eybOdhCcSUrXjGpfEgIFizkvqmTJHA))]
    eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel='',img=eybOdhCcSUrXjGpfEgIFizkvqmTJut,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJWx,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJuW,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK,ContextMenu=eybOdhCcSUrXjGpfEgIFizkvqmTJWR)
   eybOdhCcSUrXjGpfEgIFizkvqmTJWx={'plot':'시청목록을 삭제합니다.'}
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':eybOdhCcSUrXjGpfEgIFizkvqmTJuV,}
   eybOdhCcSUrXjGpfEgIFizkvqmTJuD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel='',img=eybOdhCcSUrXjGpfEgIFizkvqmTJuD,infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJWx,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAt,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK,isLink=eybOdhCcSUrXjGpfEgIFizkvqmTJAw)
   if eybOdhCcSUrXjGpfEgIFizkvqmTJuV=='movie':xbmcplugin.setContent(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,'movies')
   else:xbmcplugin.setContent(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,cacheToDisc=eybOdhCcSUrXjGpfEgIFizkvqmTJAt)
 def Save_Searched_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJMR):
  try:
   eybOdhCcSUrXjGpfEgIFizkvqmTJYM=eybOdhCcSUrXjGpfEgIFizkvqmTJDL
   eybOdhCcSUrXjGpfEgIFizkvqmTJHV=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.Load_List_File('search') 
   eybOdhCcSUrXjGpfEgIFizkvqmTJYH={'skey':eybOdhCcSUrXjGpfEgIFizkvqmTJMR.strip()}
   fp=eybOdhCcSUrXjGpfEgIFizkvqmTJlA(eybOdhCcSUrXjGpfEgIFizkvqmTJYM,'w',-1,'utf-8')
   eybOdhCcSUrXjGpfEgIFizkvqmTJHB=urllib.parse.urlencode(eybOdhCcSUrXjGpfEgIFizkvqmTJYH)
   eybOdhCcSUrXjGpfEgIFizkvqmTJHB=eybOdhCcSUrXjGpfEgIFizkvqmTJHB+'\n'
   fp.write(eybOdhCcSUrXjGpfEgIFizkvqmTJHB)
   eybOdhCcSUrXjGpfEgIFizkvqmTJHw=0
   for eybOdhCcSUrXjGpfEgIFizkvqmTJHn in eybOdhCcSUrXjGpfEgIFizkvqmTJHV:
    eybOdhCcSUrXjGpfEgIFizkvqmTJHa=eybOdhCcSUrXjGpfEgIFizkvqmTJlK(urllib.parse.parse_qsl(eybOdhCcSUrXjGpfEgIFizkvqmTJHn))
    eybOdhCcSUrXjGpfEgIFizkvqmTJHt=eybOdhCcSUrXjGpfEgIFizkvqmTJYH.get('skey').strip()
    eybOdhCcSUrXjGpfEgIFizkvqmTJYD=eybOdhCcSUrXjGpfEgIFizkvqmTJHa.get('skey').strip()
    if eybOdhCcSUrXjGpfEgIFizkvqmTJHt!=eybOdhCcSUrXjGpfEgIFizkvqmTJYD:
     fp.write(eybOdhCcSUrXjGpfEgIFizkvqmTJHn)
     eybOdhCcSUrXjGpfEgIFizkvqmTJHw+=1
     if eybOdhCcSUrXjGpfEgIFizkvqmTJHw>=50:break
   fp.close()
  except:
   eybOdhCcSUrXjGpfEgIFizkvqmTJAR
 def play_VIDEO(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJYA =eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('mediacode')
  eybOdhCcSUrXjGpfEgIFizkvqmTJuV =eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('stype')
  eybOdhCcSUrXjGpfEgIFizkvqmTJYl =eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('pvrmode')
  eybOdhCcSUrXjGpfEgIFizkvqmTJYx=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_selQuality(eybOdhCcSUrXjGpfEgIFizkvqmTJuV)
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(eybOdhCcSUrXjGpfEgIFizkvqmTJYA,eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJYx),eybOdhCcSUrXjGpfEgIFizkvqmTJuV,eybOdhCcSUrXjGpfEgIFizkvqmTJYl))
  eybOdhCcSUrXjGpfEgIFizkvqmTJYP=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.GetBroadURL(eybOdhCcSUrXjGpfEgIFizkvqmTJYA,eybOdhCcSUrXjGpfEgIFizkvqmTJYx,eybOdhCcSUrXjGpfEgIFizkvqmTJuV,eybOdhCcSUrXjGpfEgIFizkvqmTJYl,optUHD=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_uhd())
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.addon_log('qt, stype, url : %s - %s - %s'%(eybOdhCcSUrXjGpfEgIFizkvqmTJlH(eybOdhCcSUrXjGpfEgIFizkvqmTJYx),eybOdhCcSUrXjGpfEgIFizkvqmTJuV,eybOdhCcSUrXjGpfEgIFizkvqmTJYP['streaming_url']))
  if eybOdhCcSUrXjGpfEgIFizkvqmTJYP['streaming_url']=='':
   if eybOdhCcSUrXjGpfEgIFizkvqmTJYP['error_msg']=='':
    eybOdhCcSUrXjGpfEgIFizkvqmTJDs.addon_noti(__language__(30908).encode('utf8'))
   else:
    eybOdhCcSUrXjGpfEgIFizkvqmTJDs.addon_noti(eybOdhCcSUrXjGpfEgIFizkvqmTJYP['error_msg'].encode('utf8'))
   return
  eybOdhCcSUrXjGpfEgIFizkvqmTJYL={'user-agent':eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.USER_AGENT}
  eybOdhCcSUrXjGpfEgIFizkvqmTJYs=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.makeDefaultCookies() 
  if eybOdhCcSUrXjGpfEgIFizkvqmTJYP['drm_server_url'] !='':
   eybOdhCcSUrXjGpfEgIFizkvqmTJYL[eybOdhCcSUrXjGpfEgIFizkvqmTJYP['drm_header_key']]=eybOdhCcSUrXjGpfEgIFizkvqmTJYP['drm_header_value']
  eybOdhCcSUrXjGpfEgIFizkvqmTJYo =eybOdhCcSUrXjGpfEgIFizkvqmTJAt
  eybOdhCcSUrXjGpfEgIFizkvqmTJYV =eybOdhCcSUrXjGpfEgIFizkvqmTJYP['streaming_url'].find('Policy=')
  if eybOdhCcSUrXjGpfEgIFizkvqmTJYV!=-1:
   eybOdhCcSUrXjGpfEgIFizkvqmTJYn =eybOdhCcSUrXjGpfEgIFizkvqmTJYP['streaming_url'].split('?')[0]
   eybOdhCcSUrXjGpfEgIFizkvqmTJYa=eybOdhCcSUrXjGpfEgIFizkvqmTJlK(urllib.parse.parse_qsl(urllib.parse.urlsplit(eybOdhCcSUrXjGpfEgIFizkvqmTJYP['streaming_url']).query))
   eybOdhCcSUrXjGpfEgIFizkvqmTJYs['CloudFront-Policy'] =eybOdhCcSUrXjGpfEgIFizkvqmTJYa['Policy'] 
   eybOdhCcSUrXjGpfEgIFizkvqmTJYs['CloudFront-Signature'] =eybOdhCcSUrXjGpfEgIFizkvqmTJYa['Signature'] 
   eybOdhCcSUrXjGpfEgIFizkvqmTJYs['CloudFront-Key-Pair-Id']=eybOdhCcSUrXjGpfEgIFizkvqmTJYa['Key-Pair-Id'] 
   eybOdhCcSUrXjGpfEgIFizkvqmTJYN=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.make_stream_header(eybOdhCcSUrXjGpfEgIFizkvqmTJYL,eybOdhCcSUrXjGpfEgIFizkvqmTJYs)
   if 'quickvod-mcdn.tving.com' in eybOdhCcSUrXjGpfEgIFizkvqmTJYn:
    eybOdhCcSUrXjGpfEgIFizkvqmTJYo=eybOdhCcSUrXjGpfEgIFizkvqmTJAw
    eybOdhCcSUrXjGpfEgIFizkvqmTJYQ =eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    eybOdhCcSUrXjGpfEgIFizkvqmTJYR=eybOdhCcSUrXjGpfEgIFizkvqmTJYQ.strftime('%Y-%m-%d-%H:%M:%S')
    if eybOdhCcSUrXjGpfEgIFizkvqmTJAB(eybOdhCcSUrXjGpfEgIFizkvqmTJYR.replace('-','').replace(':',''))<eybOdhCcSUrXjGpfEgIFizkvqmTJAB(eybOdhCcSUrXjGpfEgIFizkvqmTJYa['end'].replace('-','').replace(':','')):
     eybOdhCcSUrXjGpfEgIFizkvqmTJYa['end']=eybOdhCcSUrXjGpfEgIFizkvqmTJYR
     eybOdhCcSUrXjGpfEgIFizkvqmTJDs.addon_noti(__language__(30915).encode('utf8'))
    eybOdhCcSUrXjGpfEgIFizkvqmTJYn ='%s?%s'%(eybOdhCcSUrXjGpfEgIFizkvqmTJYn,urllib.parse.urlencode(eybOdhCcSUrXjGpfEgIFizkvqmTJYa,doseq=eybOdhCcSUrXjGpfEgIFizkvqmTJAw))
    eybOdhCcSUrXjGpfEgIFizkvqmTJYB='{}|{}'.format(eybOdhCcSUrXjGpfEgIFizkvqmTJYn,eybOdhCcSUrXjGpfEgIFizkvqmTJYN)
   else:
    eybOdhCcSUrXjGpfEgIFizkvqmTJYB='{}|{}'.format(eybOdhCcSUrXjGpfEgIFizkvqmTJYP['streaming_url'],eybOdhCcSUrXjGpfEgIFizkvqmTJYN)
  else:
   eybOdhCcSUrXjGpfEgIFizkvqmTJYN=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.make_stream_header(eybOdhCcSUrXjGpfEgIFizkvqmTJYL,eybOdhCcSUrXjGpfEgIFizkvqmTJYs)
   eybOdhCcSUrXjGpfEgIFizkvqmTJYB='{}|{}'.format(eybOdhCcSUrXjGpfEgIFizkvqmTJYP['streaming_url'],eybOdhCcSUrXjGpfEgIFizkvqmTJYN)
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.addon_log('if tmp_pos == -1')
  eybOdhCcSUrXjGpfEgIFizkvqmTJKM,eybOdhCcSUrXjGpfEgIFizkvqmTJKH=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_proxyport()
  eybOdhCcSUrXjGpfEgIFizkvqmTJKW=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_playback()
  if(eybOdhCcSUrXjGpfEgIFizkvqmTJKM and eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('mode')in['VOD','MOVIE']and eybOdhCcSUrXjGpfEgIFizkvqmTJYo==eybOdhCcSUrXjGpfEgIFizkvqmTJAt and(eybOdhCcSUrXjGpfEgIFizkvqmTJYP['drm_server_url']!='' or eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.KodiVersion>=21)):
   if eybOdhCcSUrXjGpfEgIFizkvqmTJYP['url_filename'].split('.')[1]=='mpd':
    eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Tving_Parse_mpd(eybOdhCcSUrXjGpfEgIFizkvqmTJYP['streaming_url'])
   else:
    eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Tving_Parse_m3u8(eybOdhCcSUrXjGpfEgIFizkvqmTJYP['streaming_url'])
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.addon_log('xxx '+eybOdhCcSUrXjGpfEgIFizkvqmTJYP['streaming_url'])
   eybOdhCcSUrXjGpfEgIFizkvqmTJYw={'addon':'tvingm','playOption':eybOdhCcSUrXjGpfEgIFizkvqmTJKW,'url_filename':eybOdhCcSUrXjGpfEgIFizkvqmTJYP['url_filename'],}
   eybOdhCcSUrXjGpfEgIFizkvqmTJYw=json.dumps(eybOdhCcSUrXjGpfEgIFizkvqmTJYw,separators=(',',':'))
   eybOdhCcSUrXjGpfEgIFizkvqmTJYw=base64.standard_b64encode(eybOdhCcSUrXjGpfEgIFizkvqmTJYw.encode()).decode('utf-8')
   eybOdhCcSUrXjGpfEgIFizkvqmTJYB ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(eybOdhCcSUrXjGpfEgIFizkvqmTJKH,eybOdhCcSUrXjGpfEgIFizkvqmTJYB,eybOdhCcSUrXjGpfEgIFizkvqmTJYw)
   eybOdhCcSUrXjGpfEgIFizkvqmTJYL['proxy-mini']=eybOdhCcSUrXjGpfEgIFizkvqmTJYw 
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.addon_log('surl(2) : {}'.format(eybOdhCcSUrXjGpfEgIFizkvqmTJYB))
  eybOdhCcSUrXjGpfEgIFizkvqmTJYN=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.make_stream_header(eybOdhCcSUrXjGpfEgIFizkvqmTJYL,eybOdhCcSUrXjGpfEgIFizkvqmTJYs)
  eybOdhCcSUrXjGpfEgIFizkvqmTJYt=xbmcgui.ListItem(path=eybOdhCcSUrXjGpfEgIFizkvqmTJYB)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJYP['drm_server_url']!='':
   eybOdhCcSUrXjGpfEgIFizkvqmTJAD=eybOdhCcSUrXjGpfEgIFizkvqmTJYP['drm_server_url']
   eybOdhCcSUrXjGpfEgIFizkvqmTJAK ='https://license-global.pallycon.com/ri/licenseManager.do' 
   eybOdhCcSUrXjGpfEgIFizkvqmTJAu ='mpd'
   eybOdhCcSUrXjGpfEgIFizkvqmTJAW ='com.widevine.alpha'
   eybOdhCcSUrXjGpfEgIFizkvqmTJAM={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.USER_AGENT,eybOdhCcSUrXjGpfEgIFizkvqmTJYP['drm_header_key']:eybOdhCcSUrXjGpfEgIFizkvqmTJYP['drm_header_value'],}
   eybOdhCcSUrXjGpfEgIFizkvqmTJAH=eybOdhCcSUrXjGpfEgIFizkvqmTJAK+'|'+urllib.parse.urlencode(eybOdhCcSUrXjGpfEgIFizkvqmTJAM)+'|R{SSM}|'
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream','inputstream.adaptive')
   if eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.KodiVersion<=20:
    eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream.adaptive.manifest_type',eybOdhCcSUrXjGpfEgIFizkvqmTJAu)
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream.adaptive.license_type',eybOdhCcSUrXjGpfEgIFizkvqmTJAW)
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream.adaptive.license_key',eybOdhCcSUrXjGpfEgIFizkvqmTJAH)
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream.adaptive.stream_headers',eybOdhCcSUrXjGpfEgIFizkvqmTJYN)
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream.adaptive.manifest_headers',eybOdhCcSUrXjGpfEgIFizkvqmTJYN)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('mode')in['VOD','MOVIE']:
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setContentLookup(eybOdhCcSUrXjGpfEgIFizkvqmTJAt)
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setMimeType('application/x-mpegURL')
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream','inputstream.adaptive')
   if eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.KodiVersion<=20:
    eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream.adaptive.manifest_type','hls')
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream.adaptive.stream_headers',eybOdhCcSUrXjGpfEgIFizkvqmTJYN)
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream.adaptive.manifest_headers',eybOdhCcSUrXjGpfEgIFizkvqmTJYN)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJYo==eybOdhCcSUrXjGpfEgIFizkvqmTJAw:
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setContentLookup(eybOdhCcSUrXjGpfEgIFizkvqmTJAt)
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setMimeType('application/x-mpegURL')
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream','inputstream.ffmpegdirect')
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('ResumeTime','0')
   eybOdhCcSUrXjGpfEgIFizkvqmTJYt.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,eybOdhCcSUrXjGpfEgIFizkvqmTJAw,eybOdhCcSUrXjGpfEgIFizkvqmTJYt)
  try:
   if eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('mode')in['VOD','MOVIE']and eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('title'):
    eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'code':eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('programcode')if eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('mode')=='VOD' else eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('mediacode'),'img':eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('thumbnail'),'title':eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('title'),'videoid':eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('mediacode')}
    eybOdhCcSUrXjGpfEgIFizkvqmTJDs.Save_Watched_List(eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('stype'),eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  except:
   eybOdhCcSUrXjGpfEgIFizkvqmTJAR
 def logout(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  eybOdhCcSUrXjGpfEgIFizkvqmTJDN=xbmcgui.Dialog()
  eybOdhCcSUrXjGpfEgIFizkvqmTJuL=eybOdhCcSUrXjGpfEgIFizkvqmTJDN.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if eybOdhCcSUrXjGpfEgIFizkvqmTJuL==eybOdhCcSUrXjGpfEgIFizkvqmTJAt:sys.exit()
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Init_TV_Total()
  if os.path.isfile(eybOdhCcSUrXjGpfEgIFizkvqmTJDP):os.remove(eybOdhCcSUrXjGpfEgIFizkvqmTJDP)
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  eybOdhCcSUrXjGpfEgIFizkvqmTJAY =eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Get_Now_Datetime()
  eybOdhCcSUrXjGpfEgIFizkvqmTJAl=eybOdhCcSUrXjGpfEgIFizkvqmTJAY+datetime.timedelta(days=30) 
  (eybOdhCcSUrXjGpfEgIFizkvqmTJuA,eybOdhCcSUrXjGpfEgIFizkvqmTJul,eybOdhCcSUrXjGpfEgIFizkvqmTJux,eybOdhCcSUrXjGpfEgIFizkvqmTJuP)=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_account()
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Save_session_acount(eybOdhCcSUrXjGpfEgIFizkvqmTJuA,eybOdhCcSUrXjGpfEgIFizkvqmTJul,eybOdhCcSUrXjGpfEgIFizkvqmTJux,eybOdhCcSUrXjGpfEgIFizkvqmTJuP)
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.TV['account']['token_limit']=eybOdhCcSUrXjGpfEgIFizkvqmTJAl.strftime('%Y%m%d')
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.JsonFile_Save(eybOdhCcSUrXjGpfEgIFizkvqmTJDP,eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.TV)
 def cookiefile_check(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.TV=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.JsonFile_Load(eybOdhCcSUrXjGpfEgIFizkvqmTJDP)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.TV=={}:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Init_TV_Total()
   return eybOdhCcSUrXjGpfEgIFizkvqmTJAt
  (eybOdhCcSUrXjGpfEgIFizkvqmTJAx,eybOdhCcSUrXjGpfEgIFizkvqmTJAP,eybOdhCcSUrXjGpfEgIFizkvqmTJAL,eybOdhCcSUrXjGpfEgIFizkvqmTJAs)=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.get_settings_account()
  (eybOdhCcSUrXjGpfEgIFizkvqmTJAo,eybOdhCcSUrXjGpfEgIFizkvqmTJAV,eybOdhCcSUrXjGpfEgIFizkvqmTJAn,eybOdhCcSUrXjGpfEgIFizkvqmTJAa)=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Load_session_acount()
  if(eybOdhCcSUrXjGpfEgIFizkvqmTJAx!=eybOdhCcSUrXjGpfEgIFizkvqmTJAo or eybOdhCcSUrXjGpfEgIFizkvqmTJAP!=eybOdhCcSUrXjGpfEgIFizkvqmTJAV or eybOdhCcSUrXjGpfEgIFizkvqmTJAL!=eybOdhCcSUrXjGpfEgIFizkvqmTJAn or eybOdhCcSUrXjGpfEgIFizkvqmTJAs!=eybOdhCcSUrXjGpfEgIFizkvqmTJAa)and eybOdhCcSUrXjGpfEgIFizkvqmTJAo!='xxxxx':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Init_TV_Total()
   return eybOdhCcSUrXjGpfEgIFizkvqmTJAt
  if eybOdhCcSUrXjGpfEgIFizkvqmTJAB(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>eybOdhCcSUrXjGpfEgIFizkvqmTJAB(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.TV['account']['token_limit']):
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.Init_TV_Total()
   return eybOdhCcSUrXjGpfEgIFizkvqmTJAt
  return eybOdhCcSUrXjGpfEgIFizkvqmTJAw
 def dp_Global_Search(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJMB=eybOdhCcSUrXjGpfEgIFizkvqmTJuN.get('mode')
  if eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='TOTAL_SEARCH':
   eybOdhCcSUrXjGpfEgIFizkvqmTJAN='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   eybOdhCcSUrXjGpfEgIFizkvqmTJAN='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(eybOdhCcSUrXjGpfEgIFizkvqmTJAN)
 def dp_Bookmark_Menu(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJAN='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(eybOdhCcSUrXjGpfEgIFizkvqmTJAN)
 def dp_EuroLive_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs,eybOdhCcSUrXjGpfEgIFizkvqmTJuN):
  eybOdhCcSUrXjGpfEgIFizkvqmTJuR=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.GetEuroChannelList()
  for eybOdhCcSUrXjGpfEgIFizkvqmTJuw in eybOdhCcSUrXjGpfEgIFizkvqmTJuR:
   eybOdhCcSUrXjGpfEgIFizkvqmTJWn =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('channel')
   eybOdhCcSUrXjGpfEgIFizkvqmTJKn =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('title')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWP =eybOdhCcSUrXjGpfEgIFizkvqmTJuw.get('subtitle')
   eybOdhCcSUrXjGpfEgIFizkvqmTJWx={'mediatype':'episode','title':eybOdhCcSUrXjGpfEgIFizkvqmTJKn,'plot':'%s\n%s'%(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,eybOdhCcSUrXjGpfEgIFizkvqmTJWP)}
   eybOdhCcSUrXjGpfEgIFizkvqmTJuK={'mode':'LIVE','mediacode':eybOdhCcSUrXjGpfEgIFizkvqmTJWn,'stype':'onair',}
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.add_dir(eybOdhCcSUrXjGpfEgIFizkvqmTJKn,sublabel=eybOdhCcSUrXjGpfEgIFizkvqmTJWP,img='',infoLabels=eybOdhCcSUrXjGpfEgIFizkvqmTJWx,isFolder=eybOdhCcSUrXjGpfEgIFizkvqmTJAt,params=eybOdhCcSUrXjGpfEgIFizkvqmTJuK)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJlM(eybOdhCcSUrXjGpfEgIFizkvqmTJuR)>0:xbmcplugin.endOfDirectory(eybOdhCcSUrXjGpfEgIFizkvqmTJDs._addon_handle,cacheToDisc=eybOdhCcSUrXjGpfEgIFizkvqmTJAt)
 def tving_main(eybOdhCcSUrXjGpfEgIFizkvqmTJDs):
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.TvingObj.KodiVersion=eybOdhCcSUrXjGpfEgIFizkvqmTJAB(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  eybOdhCcSUrXjGpfEgIFizkvqmTJMB=eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params.get('mode',eybOdhCcSUrXjGpfEgIFizkvqmTJAR)
  if eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='LOGOUT':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.logout()
   return
  eybOdhCcSUrXjGpfEgIFizkvqmTJDs.login_main()
  if eybOdhCcSUrXjGpfEgIFizkvqmTJMB is eybOdhCcSUrXjGpfEgIFizkvqmTJAR:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_Main_List()
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_Title_Group(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB in['GLOBAL_GROUP']:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_SubTitle_Group(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='CHANNEL':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_LiveChannel_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB in['LIVE','VOD','MOVIE']:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.play_VIDEO(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='PROGRAM':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_Program_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='4K_PROGRAM':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_4K_Program_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='ORI_PROGRAM':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_Ori_Program_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='EPISODE':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_Episode_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='MOVIE_SUB':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_Movie_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='4K_MOVIE':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_4K_Movie_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='SEARCH_GROUP':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_Search_Group(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB in['SEARCH','LOCAL_SEARCH']:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_Search_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='WATCH':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_Watch_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_History_Remove(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='ORDER_BY':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_setEpOrderby(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='SET_BOOKMARK':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_Set_Bookmark(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB in['TOTAL_SEARCH','TOTAL_HISTORY']:
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_Global_Search(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='SEARCH_HISTORY':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_Search_History(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='MENU_BOOKMARK':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_Bookmark_Menu(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  elif eybOdhCcSUrXjGpfEgIFizkvqmTJMB=='EURO_GROUP':
   eybOdhCcSUrXjGpfEgIFizkvqmTJDs.dp_EuroLive_List(eybOdhCcSUrXjGpfEgIFizkvqmTJDs.main_params)
  else:
   eybOdhCcSUrXjGpfEgIFizkvqmTJAR
# Created by pyminifier (https://github.com/liftoff/pyminifier)
