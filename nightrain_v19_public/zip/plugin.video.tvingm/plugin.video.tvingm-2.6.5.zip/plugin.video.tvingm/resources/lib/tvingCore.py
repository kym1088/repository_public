__author__="NightRain"
reNjaihzARLCxOmPwMvcQSnXoHVyWU=print
reNjaihzARLCxOmPwMvcQSnXoHVyWG=ImportError
reNjaihzARLCxOmPwMvcQSnXoHVyWd=object
reNjaihzARLCxOmPwMvcQSnXoHVyWT=None
reNjaihzARLCxOmPwMvcQSnXoHVyWb=False
reNjaihzARLCxOmPwMvcQSnXoHVyWE=str
reNjaihzARLCxOmPwMvcQSnXoHVyWt=open
reNjaihzARLCxOmPwMvcQSnXoHVyWB=True
reNjaihzARLCxOmPwMvcQSnXoHVyWq=len
reNjaihzARLCxOmPwMvcQSnXoHVyWp=int
reNjaihzARLCxOmPwMvcQSnXoHVyWl=range
reNjaihzARLCxOmPwMvcQSnXoHVyKs=bytes
reNjaihzARLCxOmPwMvcQSnXoHVyKF=Exception
reNjaihzARLCxOmPwMvcQSnXoHVyKk=dict
reNjaihzARLCxOmPwMvcQSnXoHVyKD=list
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 reNjaihzARLCxOmPwMvcQSnXoHVyWU('Cryptodome')
except reNjaihzARLCxOmPwMvcQSnXoHVyWG:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 reNjaihzARLCxOmPwMvcQSnXoHVyWU('Crypto')
reNjaihzARLCxOmPwMvcQSnXoHVysk={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
reNjaihzARLCxOmPwMvcQSnXoHVysD ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
reNjaihzARLCxOmPwMvcQSnXoHVysf =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
reNjaihzARLCxOmPwMvcQSnXoHVysg=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class reNjaihzARLCxOmPwMvcQSnXoHVysF(reNjaihzARLCxOmPwMvcQSnXoHVyWd):
 def __init__(reNjaihzARLCxOmPwMvcQSnXoHVysI):
  reNjaihzARLCxOmPwMvcQSnXoHVysI.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  reNjaihzARLCxOmPwMvcQSnXoHVysI.NETWORKCODE ='CSND0900'
  reNjaihzARLCxOmPwMvcQSnXoHVysI.OSCODE ='CSOD0900' 
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TELECODE ='CSCD0900'
  reNjaihzARLCxOmPwMvcQSnXoHVysI.SCREENCODE ='CSSD0100'
  reNjaihzARLCxOmPwMvcQSnXoHVysI.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  reNjaihzARLCxOmPwMvcQSnXoHVysI.SCREENCODE_ATV ='CSSD1300' 
  reNjaihzARLCxOmPwMvcQSnXoHVysI.LIVE_LIMIT =20 
  reNjaihzARLCxOmPwMvcQSnXoHVysI.VOD_LIMIT =24 
  reNjaihzARLCxOmPwMvcQSnXoHVysI.EPISODE_LIMIT =30 
  reNjaihzARLCxOmPwMvcQSnXoHVysI.SEARCH_LIMIT =30 
  reNjaihzARLCxOmPwMvcQSnXoHVysI.MOVIE_LIMIT =24 
  reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN ='https://api.tving.com'
  reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN ='https://image.tving.com'
  reNjaihzARLCxOmPwMvcQSnXoHVysI.SEARCH_DOMAIN ='https://search-api.tving.com'
  reNjaihzARLCxOmPwMvcQSnXoHVysI.LOGIN_DOMAIN ='https://user.tving.com'
  reNjaihzARLCxOmPwMvcQSnXoHVysI.URL_DOMAIN ='https://www.tving.com'
  reNjaihzARLCxOmPwMvcQSnXoHVysI.MOVIE_LITE =['2610061','2610161','261062']
  reNjaihzARLCxOmPwMvcQSnXoHVysI.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  reNjaihzARLCxOmPwMvcQSnXoHVysI.MODEL ='chrome_128.0.0.0' 
  reNjaihzARLCxOmPwMvcQSnXoHVysI.DEFAULT_HEADER ={'user-agent':reNjaihzARLCxOmPwMvcQSnXoHVysI.USER_AGENT}
  reNjaihzARLCxOmPwMvcQSnXoHVysI.COOKIE_FILE_NAME =''
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TV_SESSION_COOKIES1=''
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TV_SESSION_COOKIES2=''
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TV_STREAM_FILENAME =''
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TV_SESSION_TEXT1 =''
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TV_SESSION_TEXT2 =''
  reNjaihzARLCxOmPwMvcQSnXoHVysI.KodiVersion=20
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TV ={}
  reNjaihzARLCxOmPwMvcQSnXoHVysI.Init_TV_Total()
 def Init_TV_Total(reNjaihzARLCxOmPwMvcQSnXoHVysI):
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TV={'account':{},'cookies':{},}
 def callRequestCookies(reNjaihzARLCxOmPwMvcQSnXoHVysI,jobtype,reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,json=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyWT,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVyWT,redirects=reNjaihzARLCxOmPwMvcQSnXoHVyWb):
  reNjaihzARLCxOmPwMvcQSnXoHVysW=reNjaihzARLCxOmPwMvcQSnXoHVysI.DEFAULT_HEADER
  if headers:reNjaihzARLCxOmPwMvcQSnXoHVysW.update(headers)
  if jobtype=='Get':
   reNjaihzARLCxOmPwMvcQSnXoHVysK=requests.get(reNjaihzARLCxOmPwMvcQSnXoHVyFB,params=params,headers=reNjaihzARLCxOmPwMvcQSnXoHVysW,cookies=cookies,allow_redirects=redirects)
  else:
   reNjaihzARLCxOmPwMvcQSnXoHVysK=requests.post(reNjaihzARLCxOmPwMvcQSnXoHVyFB,data=payload,json=json,params=params,headers=reNjaihzARLCxOmPwMvcQSnXoHVysW,cookies=cookies,allow_redirects=redirects)
  reNjaihzARLCxOmPwMvcQSnXoHVyWU(reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysK.status_code)+' - '+reNjaihzARLCxOmPwMvcQSnXoHVysK.url)
  return reNjaihzARLCxOmPwMvcQSnXoHVysK
 def JsonFile_Save(reNjaihzARLCxOmPwMvcQSnXoHVysI,filename,reNjaihzARLCxOmPwMvcQSnXoHVysJ):
  if filename=='':return reNjaihzARLCxOmPwMvcQSnXoHVyWb
  try:
   fp=reNjaihzARLCxOmPwMvcQSnXoHVyWt(filename,'w',-1,'utf-8')
   json.dump(reNjaihzARLCxOmPwMvcQSnXoHVysJ,fp,indent=4,ensure_ascii=reNjaihzARLCxOmPwMvcQSnXoHVyWb)
   fp.close()
  except:
   return reNjaihzARLCxOmPwMvcQSnXoHVyWb
  return reNjaihzARLCxOmPwMvcQSnXoHVyWB
 def JsonFile_Load(reNjaihzARLCxOmPwMvcQSnXoHVysI,filename):
  if filename=='':return{}
  try:
   fp=reNjaihzARLCxOmPwMvcQSnXoHVyWt(filename,'r',-1,'utf-8')
   reNjaihzARLCxOmPwMvcQSnXoHVysY=json.load(fp)
   fp.close()
  except:
   return{}
  return reNjaihzARLCxOmPwMvcQSnXoHVysY
 def TextFile_Save(reNjaihzARLCxOmPwMvcQSnXoHVysI,filename,resText):
  if filename=='':return reNjaihzARLCxOmPwMvcQSnXoHVyWb
  try:
   fp=reNjaihzARLCxOmPwMvcQSnXoHVyWt(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return reNjaihzARLCxOmPwMvcQSnXoHVyWb
  return reNjaihzARLCxOmPwMvcQSnXoHVyWB
 def Save_session_acount(reNjaihzARLCxOmPwMvcQSnXoHVysI,reNjaihzARLCxOmPwMvcQSnXoHVysU,reNjaihzARLCxOmPwMvcQSnXoHVysG,reNjaihzARLCxOmPwMvcQSnXoHVysd,reNjaihzARLCxOmPwMvcQSnXoHVysT):
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['account']['tvid'] =base64.standard_b64encode(reNjaihzARLCxOmPwMvcQSnXoHVysU.encode()).decode('utf-8')
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['account']['tvpw'] =base64.standard_b64encode(reNjaihzARLCxOmPwMvcQSnXoHVysG.encode()).decode('utf-8')
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['account']['tvtype']=reNjaihzARLCxOmPwMvcQSnXoHVysd 
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['account']['tvpf'] =reNjaihzARLCxOmPwMvcQSnXoHVysT 
 def Load_session_acount(reNjaihzARLCxOmPwMvcQSnXoHVysI):
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVysU =base64.standard_b64decode(reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['account']['tvid']).decode('utf-8')
   reNjaihzARLCxOmPwMvcQSnXoHVysG =base64.standard_b64decode(reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['account']['tvpw']).decode('utf-8')
   reNjaihzARLCxOmPwMvcQSnXoHVysd=reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['account']['tvtype']
   reNjaihzARLCxOmPwMvcQSnXoHVysT =reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return reNjaihzARLCxOmPwMvcQSnXoHVysU,reNjaihzARLCxOmPwMvcQSnXoHVysG,reNjaihzARLCxOmPwMvcQSnXoHVysd,reNjaihzARLCxOmPwMvcQSnXoHVysT
 def make_stream_header(reNjaihzARLCxOmPwMvcQSnXoHVysI,reNjaihzARLCxOmPwMvcQSnXoHVysq,reNjaihzARLCxOmPwMvcQSnXoHVysl):
  reNjaihzARLCxOmPwMvcQSnXoHVysb=''
  if reNjaihzARLCxOmPwMvcQSnXoHVysl not in[{},reNjaihzARLCxOmPwMvcQSnXoHVyWT,'']:
   reNjaihzARLCxOmPwMvcQSnXoHVysE=reNjaihzARLCxOmPwMvcQSnXoHVyWq(reNjaihzARLCxOmPwMvcQSnXoHVysl)
   for reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVysB in reNjaihzARLCxOmPwMvcQSnXoHVysl.items():
    reNjaihzARLCxOmPwMvcQSnXoHVysb+='{}={}'.format(reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVysB)
    reNjaihzARLCxOmPwMvcQSnXoHVysE+=-1
    if reNjaihzARLCxOmPwMvcQSnXoHVysE>0:reNjaihzARLCxOmPwMvcQSnXoHVysb+='; '
   reNjaihzARLCxOmPwMvcQSnXoHVysq['cookie']=reNjaihzARLCxOmPwMvcQSnXoHVysb
  reNjaihzARLCxOmPwMvcQSnXoHVysp=''
  i=0
  for reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVysB in reNjaihzARLCxOmPwMvcQSnXoHVysq.items():
   i=i+1
   if i>1:reNjaihzARLCxOmPwMvcQSnXoHVysp+='&'
   reNjaihzARLCxOmPwMvcQSnXoHVysp+='{}={}'.format(reNjaihzARLCxOmPwMvcQSnXoHVyst,urllib.parse.quote(reNjaihzARLCxOmPwMvcQSnXoHVysB))
  return reNjaihzARLCxOmPwMvcQSnXoHVysp
 def makeDefaultCookies(reNjaihzARLCxOmPwMvcQSnXoHVysI):
  reNjaihzARLCxOmPwMvcQSnXoHVysl={}
  for reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVysB in reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies'].items():
   reNjaihzARLCxOmPwMvcQSnXoHVysl[reNjaihzARLCxOmPwMvcQSnXoHVyst]=reNjaihzARLCxOmPwMvcQSnXoHVysB
  return reNjaihzARLCxOmPwMvcQSnXoHVysl
 def getDeviceStr(reNjaihzARLCxOmPwMvcQSnXoHVysI):
  reNjaihzARLCxOmPwMvcQSnXoHVyFs=[]
  reNjaihzARLCxOmPwMvcQSnXoHVyFs.append('Windows') 
  reNjaihzARLCxOmPwMvcQSnXoHVyFs.append('Chrome') 
  reNjaihzARLCxOmPwMvcQSnXoHVyFs.append('ko-KR') 
  reNjaihzARLCxOmPwMvcQSnXoHVyFs.append('undefined') 
  reNjaihzARLCxOmPwMvcQSnXoHVyFs.append('24') 
  reNjaihzARLCxOmPwMvcQSnXoHVyFs.append(u'한국 표준시')
  reNjaihzARLCxOmPwMvcQSnXoHVyFs.append('undefined') 
  reNjaihzARLCxOmPwMvcQSnXoHVyFs.append('undefined') 
  reNjaihzARLCxOmPwMvcQSnXoHVyFs.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  reNjaihzARLCxOmPwMvcQSnXoHVyFk=''
  for reNjaihzARLCxOmPwMvcQSnXoHVyFD in reNjaihzARLCxOmPwMvcQSnXoHVyFs:
   reNjaihzARLCxOmPwMvcQSnXoHVyFk+=reNjaihzARLCxOmPwMvcQSnXoHVyFD+'|'
  return reNjaihzARLCxOmPwMvcQSnXoHVyFk
 def GetDefaultParams(reNjaihzARLCxOmPwMvcQSnXoHVysI,uhd=reNjaihzARLCxOmPwMvcQSnXoHVyWb):
  if uhd==reNjaihzARLCxOmPwMvcQSnXoHVyWb:
   reNjaihzARLCxOmPwMvcQSnXoHVyFf={'apiKey':reNjaihzARLCxOmPwMvcQSnXoHVysI.APIKEY,'networkCode':reNjaihzARLCxOmPwMvcQSnXoHVysI.NETWORKCODE,'osCode':reNjaihzARLCxOmPwMvcQSnXoHVysI.OSCODE,'teleCode':reNjaihzARLCxOmPwMvcQSnXoHVysI.TELECODE,'screenCode':reNjaihzARLCxOmPwMvcQSnXoHVysI.SCREENCODE,}
  else:
   reNjaihzARLCxOmPwMvcQSnXoHVyFf={'apiKey':reNjaihzARLCxOmPwMvcQSnXoHVysI.APIKEY_ATV,'networkCode':reNjaihzARLCxOmPwMvcQSnXoHVysI.NETWORKCODE,'osCode':reNjaihzARLCxOmPwMvcQSnXoHVysI.OSCODE,'teleCode':reNjaihzARLCxOmPwMvcQSnXoHVysI.TELECODE,'screenCode':reNjaihzARLCxOmPwMvcQSnXoHVysI.SCREENCODE_ATV,}
  return reNjaihzARLCxOmPwMvcQSnXoHVyFf
 def GetNoCache(reNjaihzARLCxOmPwMvcQSnXoHVysI,timetype=1):
  if timetype==1:
   return reNjaihzARLCxOmPwMvcQSnXoHVyWp(time.time())
  else:
   return reNjaihzARLCxOmPwMvcQSnXoHVyWp(time.time()*1000)
 def GetUniqueid(reNjaihzARLCxOmPwMvcQSnXoHVysI,hValue=reNjaihzARLCxOmPwMvcQSnXoHVyWT):
  if hValue:
   import hashlib
   reNjaihzARLCxOmPwMvcQSnXoHVyFg=hashlib.sha1()
   reNjaihzARLCxOmPwMvcQSnXoHVyFg.update(hValue.encode())
   reNjaihzARLCxOmPwMvcQSnXoHVyFI=reNjaihzARLCxOmPwMvcQSnXoHVyFg.hexdigest()[:8]
  else:
   reNjaihzARLCxOmPwMvcQSnXoHVyFW=[0 for i in reNjaihzARLCxOmPwMvcQSnXoHVyWl(256)]
   for i in reNjaihzARLCxOmPwMvcQSnXoHVyWl(256):
    reNjaihzARLCxOmPwMvcQSnXoHVyFW[i]='%02x'%(i)
   reNjaihzARLCxOmPwMvcQSnXoHVyFK=reNjaihzARLCxOmPwMvcQSnXoHVyWp(4294967295*random.random())|0
   reNjaihzARLCxOmPwMvcQSnXoHVyFI=reNjaihzARLCxOmPwMvcQSnXoHVyFW[255&reNjaihzARLCxOmPwMvcQSnXoHVyFK]+reNjaihzARLCxOmPwMvcQSnXoHVyFW[reNjaihzARLCxOmPwMvcQSnXoHVyFK>>8&255]+reNjaihzARLCxOmPwMvcQSnXoHVyFW[reNjaihzARLCxOmPwMvcQSnXoHVyFK>>16&255]+reNjaihzARLCxOmPwMvcQSnXoHVyFW[reNjaihzARLCxOmPwMvcQSnXoHVyFK>>24&255]
  return reNjaihzARLCxOmPwMvcQSnXoHVyFI
 def Web_DecryptKey(reNjaihzARLCxOmPwMvcQSnXoHVysI):
  reNjaihzARLCxOmPwMvcQSnXoHVyFJ=reNjaihzARLCxOmPwMvcQSnXoHVyKs('kss2lym0kdw1lks3','utf-8')
  reNjaihzARLCxOmPwMvcQSnXoHVyFu=reNjaihzARLCxOmPwMvcQSnXoHVyKs('6yhlJ4WF9ZIj6I8n','utf-8')
  return reNjaihzARLCxOmPwMvcQSnXoHVyFJ,reNjaihzARLCxOmPwMvcQSnXoHVyFu
 def Web_EncryptCiphertext(reNjaihzARLCxOmPwMvcQSnXoHVysI,reNjaihzARLCxOmPwMvcQSnXoHVyFT):
  reNjaihzARLCxOmPwMvcQSnXoHVyFY,reNjaihzARLCxOmPwMvcQSnXoHVyFU=reNjaihzARLCxOmPwMvcQSnXoHVysI.Web_DecryptKey()
  reNjaihzARLCxOmPwMvcQSnXoHVyFG=AES.new(reNjaihzARLCxOmPwMvcQSnXoHVyFY,AES.MODE_CBC,reNjaihzARLCxOmPwMvcQSnXoHVyFU,)
  reNjaihzARLCxOmPwMvcQSnXoHVyFd=reNjaihzARLCxOmPwMvcQSnXoHVyFG.encrypt(Padding.pad(reNjaihzARLCxOmPwMvcQSnXoHVyFT.encode('utf-8'),16))
  return base64.standard_b64encode(reNjaihzARLCxOmPwMvcQSnXoHVyFd).decode('utf-8')
 def Web_DecryptPlaintext(reNjaihzARLCxOmPwMvcQSnXoHVysI,reNjaihzARLCxOmPwMvcQSnXoHVyFd):
  reNjaihzARLCxOmPwMvcQSnXoHVyFY,reNjaihzARLCxOmPwMvcQSnXoHVyFU=reNjaihzARLCxOmPwMvcQSnXoHVysI.Web_DecryptKey()
  reNjaihzARLCxOmPwMvcQSnXoHVyFG=AES.new(reNjaihzARLCxOmPwMvcQSnXoHVyFY,AES.MODE_CBC,reNjaihzARLCxOmPwMvcQSnXoHVyFU,)
  reNjaihzARLCxOmPwMvcQSnXoHVyFT=Padding.unpad(reNjaihzARLCxOmPwMvcQSnXoHVyFG.decrypt(base64.standard_b64decode(reNjaihzARLCxOmPwMvcQSnXoHVyFd)),16)
  return reNjaihzARLCxOmPwMvcQSnXoHVyFT.decode('utf-8')
 def WebCookies_Load(reNjaihzARLCxOmPwMvcQSnXoHVysI,wc_file):
  try:
   fp=reNjaihzARLCxOmPwMvcQSnXoHVyWt(wc_file,'r',-1,'utf-8')
   reNjaihzARLCxOmPwMvcQSnXoHVyFb=fp.read()
   fp.close()
   reNjaihzARLCxOmPwMvcQSnXoHVyFE=reNjaihzARLCxOmPwMvcQSnXoHVysI.Web_DecryptPlaintext(reNjaihzARLCxOmPwMvcQSnXoHVyFb)
   reNjaihzARLCxOmPwMvcQSnXoHVysI.TV=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFE)
   reNjaihzARLCxOmPwMvcQSnXoHVyFt =reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDeviceList()
   if reNjaihzARLCxOmPwMvcQSnXoHVyFt not in['','-']:
    reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies']['tving_uuid']=reNjaihzARLCxOmPwMvcQSnXoHVyFt+'-'+reNjaihzARLCxOmPwMvcQSnXoHVysI.GetUniqueid(reNjaihzARLCxOmPwMvcQSnXoHVyFt)
  except:
   return reNjaihzARLCxOmPwMvcQSnXoHVyWb
  return reNjaihzARLCxOmPwMvcQSnXoHVyWB
 def GetCredential2(reNjaihzARLCxOmPwMvcQSnXoHVysI,user_id,user_pw,login_type,user_pf):
  try:
   if base64.standard_b64encode(user_id.encode()).decode('utf-8')=='a3ltOTUxMDg4':
    reNjaihzARLCxOmPwMvcQSnXoHVyFB='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx'
   else:
    reNjaihzARLCxOmPwMvcQSnXoHVyFB='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx'
   reNjaihzARLCxOmPwMvcQSnXoHVyFq={'addon':'tvingm','method':'LOGIN','data':{'type':login_type,'id':user_id,'pw':user_pw,'pf':user_pf,}}
   reNjaihzARLCxOmPwMvcQSnXoHVyFq=json.dumps(reNjaihzARLCxOmPwMvcQSnXoHVyFq,separators=(',',':'))
   reNjaihzARLCxOmPwMvcQSnXoHVyFq=base64.standard_b64encode(reNjaihzARLCxOmPwMvcQSnXoHVyFq.encode()).decode('utf-8')
   reNjaihzARLCxOmPwMvcQSnXoHVysq={'proxy-mini':reNjaihzARLCxOmPwMvcQSnXoHVyFq}
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=requests.get(base64.standard_b64decode(reNjaihzARLCxOmPwMvcQSnXoHVyFB).decode('utf-8'),headers=reNjaihzARLCxOmPwMvcQSnXoHVysq)
   if reNjaihzARLCxOmPwMvcQSnXoHVyFp.status_code!=200:
    reNjaihzARLCxOmPwMvcQSnXoHVysI.Init_TV_Total()
    return reNjaihzARLCxOmPwMvcQSnXoHVyWb
   reNjaihzARLCxOmPwMvcQSnXoHVyFl=base64.standard_b64decode(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text).decode('utf-8')
   reNjaihzARLCxOmPwMvcQSnXoHVyFl=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFl)
   reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies']=reNjaihzARLCxOmPwMvcQSnXoHVyFl
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
   reNjaihzARLCxOmPwMvcQSnXoHVysI.Init_TV_Total()
   return reNjaihzARLCxOmPwMvcQSnXoHVyWb
  return reNjaihzARLCxOmPwMvcQSnXoHVyWB
 def GetCredential(reNjaihzARLCxOmPwMvcQSnXoHVysI,user_id,user_pw,login_type,user_pf):
  from curl_cffi import requests
  reNjaihzARLCxOmPwMvcQSnXoHVyks='chrome' 
  reNjaihzARLCxOmPwMvcQSnXoHVykF=requests.Session()
  try:
   if login_type=='0':
    reNjaihzARLCxOmPwMvcQSnXoHVykD='https://user.tving.com/pc/user/otherLogin.tving?loginType=10&from=pc&csite=&isAuto=false&rtUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   else:
    reNjaihzARLCxOmPwMvcQSnXoHVykD='https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   reNjaihzARLCxOmPwMvcQSnXoHVysq={'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language':'ko-KR,ko;q=0.9','cache-control':'no-cache','pragma':'no-cache','priority':'u=0, i','referer':'https://www.tving.com/',}
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVykF.get(reNjaihzARLCxOmPwMvcQSnXoHVykD,headers=reNjaihzARLCxOmPwMvcQSnXoHVysq,impersonate=reNjaihzARLCxOmPwMvcQSnXoHVyks)
   reNjaihzARLCxOmPwMvcQSnXoHVyWU('{} - {}'.format(reNjaihzARLCxOmPwMvcQSnXoHVyFp.status_code,reNjaihzARLCxOmPwMvcQSnXoHVyFp.url))
   for reNjaihzARLCxOmPwMvcQSnXoHVykf in reNjaihzARLCxOmPwMvcQSnXoHVyFp.cookies.jar:
    reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies'][reNjaihzARLCxOmPwMvcQSnXoHVykf.name]=reNjaihzARLCxOmPwMvcQSnXoHVykf.value
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
   reNjaihzARLCxOmPwMvcQSnXoHVysI.Init_TV_Total()
   return reNjaihzARLCxOmPwMvcQSnXoHVyWb
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykg=reNjaihzARLCxOmPwMvcQSnXoHVysI.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   reNjaihzARLCxOmPwMvcQSnXoHVykI={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':reNjaihzARLCxOmPwMvcQSnXoHVyWb,'cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   reNjaihzARLCxOmPwMvcQSnXoHVysq['referer']=reNjaihzARLCxOmPwMvcQSnXoHVykD
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVykF.post(url=reNjaihzARLCxOmPwMvcQSnXoHVykg,data=reNjaihzARLCxOmPwMvcQSnXoHVykI,headers=reNjaihzARLCxOmPwMvcQSnXoHVysq,impersonate=reNjaihzARLCxOmPwMvcQSnXoHVyks)
   reNjaihzARLCxOmPwMvcQSnXoHVyWU('{} - {}'.format(reNjaihzARLCxOmPwMvcQSnXoHVyFp.status_code,reNjaihzARLCxOmPwMvcQSnXoHVyFp.url))
   for reNjaihzARLCxOmPwMvcQSnXoHVykf in reNjaihzARLCxOmPwMvcQSnXoHVyFp.cookies.jar:
    reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies'][reNjaihzARLCxOmPwMvcQSnXoHVykf.name]=reNjaihzARLCxOmPwMvcQSnXoHVykf.value
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
   reNjaihzARLCxOmPwMvcQSnXoHVysI.Init_TV_Total()
   return reNjaihzARLCxOmPwMvcQSnXoHVyWb
  reNjaihzARLCxOmPwMvcQSnXoHVykW=[]
  reNjaihzARLCxOmPwMvcQSnXoHVykK =''
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykJ ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   reNjaihzARLCxOmPwMvcQSnXoHVysq['referer']=reNjaihzARLCxOmPwMvcQSnXoHVykg
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVykF.get(url=reNjaihzARLCxOmPwMvcQSnXoHVykJ,data=reNjaihzARLCxOmPwMvcQSnXoHVykI,headers=reNjaihzARLCxOmPwMvcQSnXoHVysq,impersonate=reNjaihzARLCxOmPwMvcQSnXoHVyks)
   reNjaihzARLCxOmPwMvcQSnXoHVyWU('{} - {}'.format(reNjaihzARLCxOmPwMvcQSnXoHVyFp.status_code,reNjaihzARLCxOmPwMvcQSnXoHVyFp.url))
   for reNjaihzARLCxOmPwMvcQSnXoHVykf in reNjaihzARLCxOmPwMvcQSnXoHVyFp.cookies.jar:
    reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies'][reNjaihzARLCxOmPwMvcQSnXoHVykf.name]=reNjaihzARLCxOmPwMvcQSnXoHVykf.value
   reNjaihzARLCxOmPwMvcQSnXoHVykW =re.findall('data-profile-no="\d+"',reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   for i in reNjaihzARLCxOmPwMvcQSnXoHVyWl(reNjaihzARLCxOmPwMvcQSnXoHVyWq(reNjaihzARLCxOmPwMvcQSnXoHVykW)):
    reNjaihzARLCxOmPwMvcQSnXoHVyku =reNjaihzARLCxOmPwMvcQSnXoHVykW[i].replace('data-profile-no=','').replace('"','')
    reNjaihzARLCxOmPwMvcQSnXoHVykW[i]=reNjaihzARLCxOmPwMvcQSnXoHVyku
   reNjaihzARLCxOmPwMvcQSnXoHVykK=reNjaihzARLCxOmPwMvcQSnXoHVykW[user_pf]
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
   reNjaihzARLCxOmPwMvcQSnXoHVysI.Init_TV_Total()
   return reNjaihzARLCxOmPwMvcQSnXoHVyWb
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykY ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   reNjaihzARLCxOmPwMvcQSnXoHVysq['referer']=reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVykI={'profileNo':reNjaihzARLCxOmPwMvcQSnXoHVykK}
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVykF.post(url=reNjaihzARLCxOmPwMvcQSnXoHVykY,data=reNjaihzARLCxOmPwMvcQSnXoHVykI,headers=reNjaihzARLCxOmPwMvcQSnXoHVysq,impersonate=reNjaihzARLCxOmPwMvcQSnXoHVyks)
   reNjaihzARLCxOmPwMvcQSnXoHVyWU('{} - {}'.format(reNjaihzARLCxOmPwMvcQSnXoHVyFp.status_code,reNjaihzARLCxOmPwMvcQSnXoHVyFp.url))
   for reNjaihzARLCxOmPwMvcQSnXoHVykf in reNjaihzARLCxOmPwMvcQSnXoHVyFp.cookies.jar:
    reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies'][reNjaihzARLCxOmPwMvcQSnXoHVykf.name]=reNjaihzARLCxOmPwMvcQSnXoHVykf.value
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
   reNjaihzARLCxOmPwMvcQSnXoHVysI.Init_TV_Total()
   return reNjaihzARLCxOmPwMvcQSnXoHVyWb
  reNjaihzARLCxOmPwMvcQSnXoHVyFt =reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDeviceList()
  if reNjaihzARLCxOmPwMvcQSnXoHVyFt not in['','-']:
   reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies']['tving_uuid']=reNjaihzARLCxOmPwMvcQSnXoHVyFt+'-'+reNjaihzARLCxOmPwMvcQSnXoHVysI.GetUniqueid(reNjaihzARLCxOmPwMvcQSnXoHVyFt)
  reNjaihzARLCxOmPwMvcQSnXoHVysI.JsonFile_Save(reNjaihzARLCxOmPwMvcQSnXoHVysI.COOKIE_FILE_NAME,reNjaihzARLCxOmPwMvcQSnXoHVysI.TV)
  return reNjaihzARLCxOmPwMvcQSnXoHVyWB
 def GetDeviceList(reNjaihzARLCxOmPwMvcQSnXoHVysI):
  reNjaihzARLCxOmPwMvcQSnXoHVykU=[]
  reNjaihzARLCxOmPwMvcQSnXoHVykG='-'
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v1/user/device/list'
   reNjaihzARLCxOmPwMvcQSnXoHVykd=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVykT=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
   reNjaihzARLCxOmPwMvcQSnXoHVysl=reNjaihzARLCxOmPwMvcQSnXoHVysI.makeDefaultCookies()
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVykd,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVykT,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVysl)
   reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   reNjaihzARLCxOmPwMvcQSnXoHVykU=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']
   for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVykU:
    if reNjaihzARLCxOmPwMvcQSnXoHVykE['model'].lower().startswith('pc'):
     reNjaihzARLCxOmPwMvcQSnXoHVykG=reNjaihzARLCxOmPwMvcQSnXoHVykE['uuid']
     break
   if reNjaihzARLCxOmPwMvcQSnXoHVykG=='-':
    reNjaihzARLCxOmPwMvcQSnXoHVykG=reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.GetNoCache(timetype=1))
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
  return reNjaihzARLCxOmPwMvcQSnXoHVykG
 def Get_Now_Datetime(reNjaihzARLCxOmPwMvcQSnXoHVysI):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(reNjaihzARLCxOmPwMvcQSnXoHVysI,mediacode,sel_quality,stype,pvrmode='-',optUHD=reNjaihzARLCxOmPwMvcQSnXoHVyWb):
  reNjaihzARLCxOmPwMvcQSnXoHVykB ={'streaming_url':'','subtitleYn':reNjaihzARLCxOmPwMvcQSnXoHVyWb,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  reNjaihzARLCxOmPwMvcQSnXoHVykG =reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies']['tving_uuid'].split('-')[0] 
  reNjaihzARLCxOmPwMvcQSnXoHVykq =reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies']['tving_uuid'] 
  reNjaihzARLCxOmPwMvcQSnXoHVykp=reNjaihzARLCxOmPwMvcQSnXoHVyWb 
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykl=reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.GetNoCache(1))
   if stype!='tvingtv':
    reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v2/media/stream/info'
    reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
    reNjaihzARLCxOmPwMvcQSnXoHVykT={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':reNjaihzARLCxOmPwMvcQSnXoHVykq,'deviceInfo':'PC','noCache':reNjaihzARLCxOmPwMvcQSnXoHVykl,}
    reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
    reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
    reNjaihzARLCxOmPwMvcQSnXoHVysl=reNjaihzARLCxOmPwMvcQSnXoHVysI.makeDefaultCookies()
    reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVysl)
    if reNjaihzARLCxOmPwMvcQSnXoHVyFp.status_code!=200:
     reNjaihzARLCxOmPwMvcQSnXoHVykB['error_msg']='First Step - {} error'.format(reNjaihzARLCxOmPwMvcQSnXoHVyFp.status_code)
     return reNjaihzARLCxOmPwMvcQSnXoHVykB
    reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
    if reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']['code']=='060':
     for reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVysB in reNjaihzARLCxOmPwMvcQSnXoHVysk.items():
      if reNjaihzARLCxOmPwMvcQSnXoHVysB==sel_quality:
       reNjaihzARLCxOmPwMvcQSnXoHVyDF=reNjaihzARLCxOmPwMvcQSnXoHVyst
    elif reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']['code']!='000':
     reNjaihzARLCxOmPwMvcQSnXoHVykB['error_msg']=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']['message']
     return reNjaihzARLCxOmPwMvcQSnXoHVykB
    else: 
     if not('stream' in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']):return reNjaihzARLCxOmPwMvcQSnXoHVykB
     reNjaihzARLCxOmPwMvcQSnXoHVyDk=[]
     for reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVysB in reNjaihzARLCxOmPwMvcQSnXoHVysk.items():
      for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['stream']['quality']:
       if reNjaihzARLCxOmPwMvcQSnXoHVykE['active']=='Y' and reNjaihzARLCxOmPwMvcQSnXoHVykE['code']==reNjaihzARLCxOmPwMvcQSnXoHVyst:
        reNjaihzARLCxOmPwMvcQSnXoHVyDk.append({reNjaihzARLCxOmPwMvcQSnXoHVysk.get(reNjaihzARLCxOmPwMvcQSnXoHVykE['code']):reNjaihzARLCxOmPwMvcQSnXoHVykE['code']})
     reNjaihzARLCxOmPwMvcQSnXoHVyDF=reNjaihzARLCxOmPwMvcQSnXoHVysI.CheckQuality(sel_quality,reNjaihzARLCxOmPwMvcQSnXoHVyDk)
     try:
      if optUHD==reNjaihzARLCxOmPwMvcQSnXoHVyWB and reNjaihzARLCxOmPwMvcQSnXoHVyDF=='stream50' and 'stream_support_info' in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['content']['info']:
       if reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['content']['info']['stream_support_info']!=reNjaihzARLCxOmPwMvcQSnXoHVyWT:
        if 'stream70' in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['content']['info']['stream_support_info']:
         reNjaihzARLCxOmPwMvcQSnXoHVyDF='stream70'
         reNjaihzARLCxOmPwMvcQSnXoHVykp =reNjaihzARLCxOmPwMvcQSnXoHVyWB
     except:
      pass
     try:
      if optUHD==reNjaihzARLCxOmPwMvcQSnXoHVyWB and reNjaihzARLCxOmPwMvcQSnXoHVyDF=='stream50' and 'stream' in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['content']['info']:
       if reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['content']['info']['stream']!=reNjaihzARLCxOmPwMvcQSnXoHVyWT:
        for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['content']['info']['stream']:
         if reNjaihzARLCxOmPwMvcQSnXoHVykE['code']=='stream70':
          reNjaihzARLCxOmPwMvcQSnXoHVyDF='stream70'
          reNjaihzARLCxOmPwMvcQSnXoHVykp =reNjaihzARLCxOmPwMvcQSnXoHVyWB
          break
     except:
      pass
   else:
    reNjaihzARLCxOmPwMvcQSnXoHVyDF='stream40'
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
   reNjaihzARLCxOmPwMvcQSnXoHVykB['error_msg']='First Step - except error'
   return reNjaihzARLCxOmPwMvcQSnXoHVykB
  reNjaihzARLCxOmPwMvcQSnXoHVyWU(reNjaihzARLCxOmPwMvcQSnXoHVyDF)
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykl=reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.GetNoCache(1))
   reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v3/media/stream/info'
   if reNjaihzARLCxOmPwMvcQSnXoHVykp==reNjaihzARLCxOmPwMvcQSnXoHVyWB:
    reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams(uhd=reNjaihzARLCxOmPwMvcQSnXoHVyWB)
    reNjaihzARLCxOmPwMvcQSnXoHVykT={'mediaCode':mediacode,'deviceId':reNjaihzARLCxOmPwMvcQSnXoHVykG,'uuid':reNjaihzARLCxOmPwMvcQSnXoHVykq,'deviceInfo':'PC_Chrome WebView','streamCode':reNjaihzARLCxOmPwMvcQSnXoHVyDF,'noCache':reNjaihzARLCxOmPwMvcQSnXoHVykl,'callingFrom':'HTML5','model':'chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   else:
    reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
    reNjaihzARLCxOmPwMvcQSnXoHVykT={'mediaCode':mediacode,'deviceId':reNjaihzARLCxOmPwMvcQSnXoHVykG,'uuid':reNjaihzARLCxOmPwMvcQSnXoHVykq,'deviceInfo':'PC_Chrome','streamCode':reNjaihzARLCxOmPwMvcQSnXoHVyDF,'noCache':reNjaihzARLCxOmPwMvcQSnXoHVykl,'callingFrom':'HTML5','model':reNjaihzARLCxOmPwMvcQSnXoHVysI.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVysl=reNjaihzARLCxOmPwMvcQSnXoHVysI.makeDefaultCookies()
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Post',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVysl,redirects=reNjaihzARLCxOmPwMvcQSnXoHVyWB)
   reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']['code']!='000':
    reNjaihzARLCxOmPwMvcQSnXoHVykB['error_msg']=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']['message']
    return reNjaihzARLCxOmPwMvcQSnXoHVykB
   reNjaihzARLCxOmPwMvcQSnXoHVyDf=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['stream']
   if reNjaihzARLCxOmPwMvcQSnXoHVyDf['drm_yn']=='Y':
    reNjaihzARLCxOmPwMvcQSnXoHVyDg=reNjaihzARLCxOmPwMvcQSnXoHVyDf['playback']['drm']['widevine']
    for reNjaihzARLCxOmPwMvcQSnXoHVyDI in reNjaihzARLCxOmPwMvcQSnXoHVyDf['playback']['drm']['license']['drm_license_data']:
     if reNjaihzARLCxOmPwMvcQSnXoHVyDI['drm_type']=='Widevine':
      reNjaihzARLCxOmPwMvcQSnXoHVykB['drm_server_url'] =reNjaihzARLCxOmPwMvcQSnXoHVyDI['drm_server_url']
      reNjaihzARLCxOmPwMvcQSnXoHVykB['drm_header_key'] =reNjaihzARLCxOmPwMvcQSnXoHVyDI['drm_header_key']
      reNjaihzARLCxOmPwMvcQSnXoHVykB['drm_header_value']=reNjaihzARLCxOmPwMvcQSnXoHVyDI['drm_header_value']
      break
   else:
    reNjaihzARLCxOmPwMvcQSnXoHVyDg=reNjaihzARLCxOmPwMvcQSnXoHVyDf['playback']['non_drm']
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
   reNjaihzARLCxOmPwMvcQSnXoHVykB['error_msg']='Second Step - except error'
   return reNjaihzARLCxOmPwMvcQSnXoHVykB
  reNjaihzARLCxOmPwMvcQSnXoHVyDW=reNjaihzARLCxOmPwMvcQSnXoHVykl
  reNjaihzARLCxOmPwMvcQSnXoHVyDg=reNjaihzARLCxOmPwMvcQSnXoHVyDg.split('|')[1]
  reNjaihzARLCxOmPwMvcQSnXoHVyDg=reNjaihzARLCxOmPwMvcQSnXoHVysI.Decrypt_Url(reNjaihzARLCxOmPwMvcQSnXoHVyDg,mediacode,reNjaihzARLCxOmPwMvcQSnXoHVyDW)
  reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url']=reNjaihzARLCxOmPwMvcQSnXoHVyDg
  if 'subtitles' in reNjaihzARLCxOmPwMvcQSnXoHVyDf:
   for reNjaihzARLCxOmPwMvcQSnXoHVyDK in reNjaihzARLCxOmPwMvcQSnXoHVyDf.get('subtitles'):
    if reNjaihzARLCxOmPwMvcQSnXoHVyDK.get('code')in['KO','KO_CC']:
     reNjaihzARLCxOmPwMvcQSnXoHVykB['subtitleYn']=reNjaihzARLCxOmPwMvcQSnXoHVyWB
     break
  reNjaihzARLCxOmPwMvcQSnXoHVyDJ=urllib.parse.urlparse(reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url'])
  reNjaihzARLCxOmPwMvcQSnXoHVyDu =reNjaihzARLCxOmPwMvcQSnXoHVyDJ.path.strip('/').split('/')
  reNjaihzARLCxOmPwMvcQSnXoHVykB['url_filename']=reNjaihzARLCxOmPwMvcQSnXoHVyDu[reNjaihzARLCxOmPwMvcQSnXoHVyWq(reNjaihzARLCxOmPwMvcQSnXoHVyDu)-1]
  return reNjaihzARLCxOmPwMvcQSnXoHVykB
 def Tving_Parse_mpd(reNjaihzARLCxOmPwMvcQSnXoHVysI,stream_url):
  reNjaihzARLCxOmPwMvcQSnXoHVyFp=requests.get(url=stream_url)
  reNjaihzARLCxOmPwMvcQSnXoHVyDY=reNjaihzARLCxOmPwMvcQSnXoHVyFp.content.decode('utf-8')
  reNjaihzARLCxOmPwMvcQSnXoHVyDU=0
  reNjaihzARLCxOmPwMvcQSnXoHVyDG =ET.ElementTree(ET.fromstring(reNjaihzARLCxOmPwMvcQSnXoHVyDY))
  reNjaihzARLCxOmPwMvcQSnXoHVyDd =reNjaihzARLCxOmPwMvcQSnXoHVyDG.getroot()
  reNjaihzARLCxOmPwMvcQSnXoHVyDT=re.match(r'\{.*\}',reNjaihzARLCxOmPwMvcQSnXoHVyDd.tag)[0] 
  reNjaihzARLCxOmPwMvcQSnXoHVyDb=reNjaihzARLCxOmPwMvcQSnXoHVyKk([node for _,node in ET.iterparse(io.StringIO(reNjaihzARLCxOmPwMvcQSnXoHVyDY),events=['start-ns'])])
  for reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVyfu in reNjaihzARLCxOmPwMvcQSnXoHVyDb.items():
   if reNjaihzARLCxOmPwMvcQSnXoHVyst!='ns2':
    ET.register_namespace(reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVyfu)
  reNjaihzARLCxOmPwMvcQSnXoHVyDE=reNjaihzARLCxOmPwMvcQSnXoHVyDd.find(reNjaihzARLCxOmPwMvcQSnXoHVyDT+'Period')
  for reNjaihzARLCxOmPwMvcQSnXoHVyDt in reNjaihzARLCxOmPwMvcQSnXoHVyDE.findall(reNjaihzARLCxOmPwMvcQSnXoHVyDT+'AdaptationSet'):
   if reNjaihzARLCxOmPwMvcQSnXoHVyDt.attrib.get('mimeType')=='video/mp4':
    for reNjaihzARLCxOmPwMvcQSnXoHVyDB in reNjaihzARLCxOmPwMvcQSnXoHVyDt.findall(reNjaihzARLCxOmPwMvcQSnXoHVyDT+'Representation'):
     reNjaihzARLCxOmPwMvcQSnXoHVyDq=reNjaihzARLCxOmPwMvcQSnXoHVyWp(reNjaihzARLCxOmPwMvcQSnXoHVyDB.attrib.get('bandwidth'))
     if reNjaihzARLCxOmPwMvcQSnXoHVyDU<reNjaihzARLCxOmPwMvcQSnXoHVyDq:reNjaihzARLCxOmPwMvcQSnXoHVyDU=reNjaihzARLCxOmPwMvcQSnXoHVyDq
    for reNjaihzARLCxOmPwMvcQSnXoHVyDB in reNjaihzARLCxOmPwMvcQSnXoHVyDt.findall(reNjaihzARLCxOmPwMvcQSnXoHVyDT+'Representation'):
     if reNjaihzARLCxOmPwMvcQSnXoHVyDU>reNjaihzARLCxOmPwMvcQSnXoHVyWp(reNjaihzARLCxOmPwMvcQSnXoHVyDB.attrib.get('bandwidth')):
      reNjaihzARLCxOmPwMvcQSnXoHVyDt.remove(reNjaihzARLCxOmPwMvcQSnXoHVyDB)
   else:
    continue
  reNjaihzARLCxOmPwMvcQSnXoHVyDp=ET.tostring(reNjaihzARLCxOmPwMvcQSnXoHVyDd).decode('utf-8')
  reNjaihzARLCxOmPwMvcQSnXoHVyDl='<?xml version="1.0" encoding="UTF-8"?>\n'
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TextFile_Save(reNjaihzARLCxOmPwMvcQSnXoHVysI.TV_STREAM_FILENAME,reNjaihzARLCxOmPwMvcQSnXoHVyDl+reNjaihzARLCxOmPwMvcQSnXoHVyDp)
  return reNjaihzARLCxOmPwMvcQSnXoHVyWB
 def Tving_Parse_m3u8(reNjaihzARLCxOmPwMvcQSnXoHVysI,stream_url):
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=requests.get(url=stream_url,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,stream=reNjaihzARLCxOmPwMvcQSnXoHVyWB)
   reNjaihzARLCxOmPwMvcQSnXoHVyfs=reNjaihzARLCxOmPwMvcQSnXoHVyFp.content.decode('utf-8')
   if '#EXTM3U' not in reNjaihzARLCxOmPwMvcQSnXoHVyfs:
    return reNjaihzARLCxOmPwMvcQSnXoHVyWb
   if '#EXT-X-STREAM-INF' not in reNjaihzARLCxOmPwMvcQSnXoHVyfs: 
    return reNjaihzARLCxOmPwMvcQSnXoHVyWb
   reNjaihzARLCxOmPwMvcQSnXoHVyfF=0
   for reNjaihzARLCxOmPwMvcQSnXoHVyfk in reNjaihzARLCxOmPwMvcQSnXoHVyfs.splitlines():
    if reNjaihzARLCxOmPwMvcQSnXoHVyfk.startswith('#EXT-X-STREAM-INF'):
     reNjaihzARLCxOmPwMvcQSnXoHVyfD=reNjaihzARLCxOmPwMvcQSnXoHVysI.MediaLine_Parse(reNjaihzARLCxOmPwMvcQSnXoHVyfk,'#EXT-X-STREAM-INF')
     if reNjaihzARLCxOmPwMvcQSnXoHVyfF<reNjaihzARLCxOmPwMvcQSnXoHVyWp(reNjaihzARLCxOmPwMvcQSnXoHVyfD.get('BANDWIDTH')):
      reNjaihzARLCxOmPwMvcQSnXoHVyfF=reNjaihzARLCxOmPwMvcQSnXoHVyWp(reNjaihzARLCxOmPwMvcQSnXoHVyfD.get('BANDWIDTH'))
   reNjaihzARLCxOmPwMvcQSnXoHVyfg=[]
   reNjaihzARLCxOmPwMvcQSnXoHVyfI=reNjaihzARLCxOmPwMvcQSnXoHVyWb
   for reNjaihzARLCxOmPwMvcQSnXoHVyfk in reNjaihzARLCxOmPwMvcQSnXoHVyfs.splitlines():
    if reNjaihzARLCxOmPwMvcQSnXoHVyfI==reNjaihzARLCxOmPwMvcQSnXoHVyWB:
     reNjaihzARLCxOmPwMvcQSnXoHVyfI=reNjaihzARLCxOmPwMvcQSnXoHVyWb
     continue
    if reNjaihzARLCxOmPwMvcQSnXoHVyfk.startswith('#EXT-X-STREAM-INF'):
     reNjaihzARLCxOmPwMvcQSnXoHVyfD=reNjaihzARLCxOmPwMvcQSnXoHVysI.MediaLine_Parse(reNjaihzARLCxOmPwMvcQSnXoHVyfk,'#EXT-X-STREAM-INF')
     if reNjaihzARLCxOmPwMvcQSnXoHVyfF!=reNjaihzARLCxOmPwMvcQSnXoHVyWp(reNjaihzARLCxOmPwMvcQSnXoHVyfD.get('BANDWIDTH')):
      reNjaihzARLCxOmPwMvcQSnXoHVyfI=reNjaihzARLCxOmPwMvcQSnXoHVyWB
      continue
    reNjaihzARLCxOmPwMvcQSnXoHVyfg.append(reNjaihzARLCxOmPwMvcQSnXoHVyfk)
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
   return reNjaihzARLCxOmPwMvcQSnXoHVyWb
  reNjaihzARLCxOmPwMvcQSnXoHVyfW='\n'.join(reNjaihzARLCxOmPwMvcQSnXoHVyfg)
  reNjaihzARLCxOmPwMvcQSnXoHVysI.TextFile_Save(reNjaihzARLCxOmPwMvcQSnXoHVysI.TV_STREAM_FILENAME,reNjaihzARLCxOmPwMvcQSnXoHVyfW)
  return reNjaihzARLCxOmPwMvcQSnXoHVyWB
 def MediaLine_Parse(reNjaihzARLCxOmPwMvcQSnXoHVysI,reNjaihzARLCxOmPwMvcQSnXoHVyfk,prefix):
  reNjaihzARLCxOmPwMvcQSnXoHVyfD={}
  for reNjaihzARLCxOmPwMvcQSnXoHVyfK in reNjaihzARLCxOmPwMvcQSnXoHVysf.split(reNjaihzARLCxOmPwMvcQSnXoHVyfk.replace(prefix+':',''))[1::2]:
   reNjaihzARLCxOmPwMvcQSnXoHVyfJ,reNjaihzARLCxOmPwMvcQSnXoHVyfu=reNjaihzARLCxOmPwMvcQSnXoHVyfK.split('=',1)
   reNjaihzARLCxOmPwMvcQSnXoHVyfD[reNjaihzARLCxOmPwMvcQSnXoHVyfJ.upper()]=reNjaihzARLCxOmPwMvcQSnXoHVyfu.replace('"','').strip()
  return reNjaihzARLCxOmPwMvcQSnXoHVyfD
 def CheckQuality(reNjaihzARLCxOmPwMvcQSnXoHVysI,sel_qt,reNjaihzARLCxOmPwMvcQSnXoHVyDk):
  for reNjaihzARLCxOmPwMvcQSnXoHVyfY in reNjaihzARLCxOmPwMvcQSnXoHVyDk:
   if sel_qt>=reNjaihzARLCxOmPwMvcQSnXoHVyKD(reNjaihzARLCxOmPwMvcQSnXoHVyfY)[0]:return reNjaihzARLCxOmPwMvcQSnXoHVyfY.get(reNjaihzARLCxOmPwMvcQSnXoHVyKD(reNjaihzARLCxOmPwMvcQSnXoHVyfY)[0])
   reNjaihzARLCxOmPwMvcQSnXoHVyfU=reNjaihzARLCxOmPwMvcQSnXoHVyfY.get(reNjaihzARLCxOmPwMvcQSnXoHVyKD(reNjaihzARLCxOmPwMvcQSnXoHVyfY)[0])
  return reNjaihzARLCxOmPwMvcQSnXoHVyfU
 def makeOocUrl(reNjaihzARLCxOmPwMvcQSnXoHVysI,ooc_params):
  reNjaihzARLCxOmPwMvcQSnXoHVyFB=''
  for reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVysB in ooc_params.items():
   reNjaihzARLCxOmPwMvcQSnXoHVyFB+="%s=%s^"%(reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVysB)
  return reNjaihzARLCxOmPwMvcQSnXoHVyFB
 def GetLiveChannelList(reNjaihzARLCxOmPwMvcQSnXoHVysI,stype,page_int):
  reNjaihzARLCxOmPwMvcQSnXoHVykU=[]
  reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWb
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v2/media/lives'
   if stype=='onair': 
    reNjaihzARLCxOmPwMvcQSnXoHVyfd='CPCS0100,CPCS0400'
   else:
    reNjaihzARLCxOmPwMvcQSnXoHVyfd='CPCS0300'
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'cacheType':'main','pageNo':reNjaihzARLCxOmPwMvcQSnXoHVyWE(page_int),'pageSize':reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':reNjaihzARLCxOmPwMvcQSnXoHVyfd,}
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVyWT)
   reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if not('result' in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']):return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
   reNjaihzARLCxOmPwMvcQSnXoHVyfT=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']
   for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVyfT:
    reNjaihzARLCxOmPwMvcQSnXoHVyfb=reNjaihzARLCxOmPwMvcQSnXoHVyfB=reNjaihzARLCxOmPwMvcQSnXoHVyfq=''
    reNjaihzARLCxOmPwMvcQSnXoHVyfE=reNjaihzARLCxOmPwMvcQSnXoHVygT=''
    reNjaihzARLCxOmPwMvcQSnXoHVyft=reNjaihzARLCxOmPwMvcQSnXoHVykE['live_code']
    reNjaihzARLCxOmPwMvcQSnXoHVyfb =reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['channel']['name']['ko']
    if reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['episode']!=reNjaihzARLCxOmPwMvcQSnXoHVyWT:
     reNjaihzARLCxOmPwMvcQSnXoHVyfB =reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['program']['name']['ko']
     reNjaihzARLCxOmPwMvcQSnXoHVyfB =reNjaihzARLCxOmPwMvcQSnXoHVyfB+', '+reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['episode']['frequency'])+'회'
     reNjaihzARLCxOmPwMvcQSnXoHVyfq=reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['episode']['synopsis']['ko']
    else:
     reNjaihzARLCxOmPwMvcQSnXoHVyfB =reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['program']['name']['ko']
     reNjaihzARLCxOmPwMvcQSnXoHVyfq=reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['program']['synopsis']['ko']
    try: 
     reNjaihzARLCxOmPwMvcQSnXoHVyfp =''
     reNjaihzARLCxOmPwMvcQSnXoHVyfl =''
     reNjaihzARLCxOmPwMvcQSnXoHVygs=''
     reNjaihzARLCxOmPwMvcQSnXoHVygF =''
     reNjaihzARLCxOmPwMvcQSnXoHVygk =''
     reNjaihzARLCxOmPwMvcQSnXoHVygD =''
     for reNjaihzARLCxOmPwMvcQSnXoHVygf in reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['program']['image']:
      if reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP0900':reNjaihzARLCxOmPwMvcQSnXoHVyfl =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
      elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP1800':reNjaihzARLCxOmPwMvcQSnXoHVygs=reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
      elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP2000':reNjaihzARLCxOmPwMvcQSnXoHVygF =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
      elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP1900':reNjaihzARLCxOmPwMvcQSnXoHVygk =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
      elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP0200':reNjaihzARLCxOmPwMvcQSnXoHVygD =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
      elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP0500':reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
      elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP0800':reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     if reNjaihzARLCxOmPwMvcQSnXoHVyfp=='':
      for reNjaihzARLCxOmPwMvcQSnXoHVygf in reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['channel']['image']:
       if reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIC0400':reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
       elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIC1400':reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
       elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIC1900':reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
    except:
     reNjaihzARLCxOmPwMvcQSnXoHVyWT
    try:
     reNjaihzARLCxOmPwMvcQSnXoHVygI =[]
     reNjaihzARLCxOmPwMvcQSnXoHVygW=[]
     reNjaihzARLCxOmPwMvcQSnXoHVygK =[]
     reNjaihzARLCxOmPwMvcQSnXoHVygJ=''
     reNjaihzARLCxOmPwMvcQSnXoHVygu=''
     reNjaihzARLCxOmPwMvcQSnXoHVygY=''
     for reNjaihzARLCxOmPwMvcQSnXoHVygU in reNjaihzARLCxOmPwMvcQSnXoHVykE.get('schedule').get('program').get('actor'):
      if reNjaihzARLCxOmPwMvcQSnXoHVygU!='' and reNjaihzARLCxOmPwMvcQSnXoHVygU!=u'없음':reNjaihzARLCxOmPwMvcQSnXoHVygI.append(reNjaihzARLCxOmPwMvcQSnXoHVygU)
     for reNjaihzARLCxOmPwMvcQSnXoHVygG in reNjaihzARLCxOmPwMvcQSnXoHVykE.get('schedule').get('program').get('director'):
      if reNjaihzARLCxOmPwMvcQSnXoHVygG!='' and reNjaihzARLCxOmPwMvcQSnXoHVygG!='-' and reNjaihzARLCxOmPwMvcQSnXoHVygG!=u'없음':reNjaihzARLCxOmPwMvcQSnXoHVygW.append(reNjaihzARLCxOmPwMvcQSnXoHVygG)
     if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('schedule').get('program').get('category1_name').get('ko')!='':
      reNjaihzARLCxOmPwMvcQSnXoHVygK.append(reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['program']['category1_name']['ko'])
     if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('schedule').get('program').get('category2_name').get('ko')!='':
      reNjaihzARLCxOmPwMvcQSnXoHVygK.append(reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['program']['category2_name']['ko'])
     if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('schedule').get('program').get('product_year'):reNjaihzARLCxOmPwMvcQSnXoHVygJ=reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['program']['product_year']
     if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('schedule').get('program').get('grade_code') :reNjaihzARLCxOmPwMvcQSnXoHVygu= reNjaihzARLCxOmPwMvcQSnXoHVysD.get(reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['program']['grade_code'])
     if 'broad_dt' in reNjaihzARLCxOmPwMvcQSnXoHVykE.get('schedule').get('program'):
      reNjaihzARLCxOmPwMvcQSnXoHVygd =reNjaihzARLCxOmPwMvcQSnXoHVykE.get('schedule').get('program').get('broad_dt')
      reNjaihzARLCxOmPwMvcQSnXoHVygY='%s-%s-%s'%(reNjaihzARLCxOmPwMvcQSnXoHVygd[:4],reNjaihzARLCxOmPwMvcQSnXoHVygd[4:6],reNjaihzARLCxOmPwMvcQSnXoHVygd[6:])
    except:
     reNjaihzARLCxOmPwMvcQSnXoHVyWT
    reNjaihzARLCxOmPwMvcQSnXoHVyfE=reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['broadcast_start_time'])[8:12]
    reNjaihzARLCxOmPwMvcQSnXoHVygT =reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVykE['schedule']['broadcast_end_time'])[8:12]
    reNjaihzARLCxOmPwMvcQSnXoHVygb={'channel':reNjaihzARLCxOmPwMvcQSnXoHVyfb,'title':reNjaihzARLCxOmPwMvcQSnXoHVyfB,'mediacode':reNjaihzARLCxOmPwMvcQSnXoHVyft,'thumbnail':{'poster':reNjaihzARLCxOmPwMvcQSnXoHVyfl,'thumb':reNjaihzARLCxOmPwMvcQSnXoHVyfp,'clearlogo':reNjaihzARLCxOmPwMvcQSnXoHVygs,'icon':reNjaihzARLCxOmPwMvcQSnXoHVygF,'fanart':reNjaihzARLCxOmPwMvcQSnXoHVygD},'synopsis':reNjaihzARLCxOmPwMvcQSnXoHVyfq,'channelepg':' [%s:%s ~ %s:%s]'%(reNjaihzARLCxOmPwMvcQSnXoHVyfE[0:2],reNjaihzARLCxOmPwMvcQSnXoHVyfE[2:],reNjaihzARLCxOmPwMvcQSnXoHVygT[0:2],reNjaihzARLCxOmPwMvcQSnXoHVygT[2:]),'cast':reNjaihzARLCxOmPwMvcQSnXoHVygI,'director':reNjaihzARLCxOmPwMvcQSnXoHVygW,'info_genre':reNjaihzARLCxOmPwMvcQSnXoHVygK,'year':reNjaihzARLCxOmPwMvcQSnXoHVygJ,'mpaa':reNjaihzARLCxOmPwMvcQSnXoHVygu,'premiered':reNjaihzARLCxOmPwMvcQSnXoHVygY}
    reNjaihzARLCxOmPwMvcQSnXoHVykU.append(reNjaihzARLCxOmPwMvcQSnXoHVygb)
   if reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['has_more']=='Y':
    reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWB
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
  return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
 def GetProgramList(reNjaihzARLCxOmPwMvcQSnXoHVysI,genre,orderby,page_int,genreCode='all'):
  reNjaihzARLCxOmPwMvcQSnXoHVykU=[]
  reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWb
  try:
   if genre=='PARAMOUNT':
    reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v2/media/paramount/episodes'
   else:
    reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v2/media/episodes'
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'cacheType':'main','pageSize':reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':reNjaihzARLCxOmPwMvcQSnXoHVyWE(page_int),}
   if genre not in['all','PARAMOUNT']:reNjaihzARLCxOmPwMvcQSnXoHVykT['categoryCode']=genre
   if genreCode!='all' :reNjaihzARLCxOmPwMvcQSnXoHVykT['genreCode'] =genreCode 
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVyWT)
   reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if not('result' in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']):return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
   reNjaihzARLCxOmPwMvcQSnXoHVyfT=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']
   for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVyfT:
    reNjaihzARLCxOmPwMvcQSnXoHVygE=reNjaihzARLCxOmPwMvcQSnXoHVykE['program']['code']
    reNjaihzARLCxOmPwMvcQSnXoHVyfB =reNjaihzARLCxOmPwMvcQSnXoHVykE['program']['name']['ko']
    reNjaihzARLCxOmPwMvcQSnXoHVygu =reNjaihzARLCxOmPwMvcQSnXoHVysD.get(reNjaihzARLCxOmPwMvcQSnXoHVykE['program'].get('grade_code'))
    reNjaihzARLCxOmPwMvcQSnXoHVyfl =''
    reNjaihzARLCxOmPwMvcQSnXoHVyfp =''
    reNjaihzARLCxOmPwMvcQSnXoHVygs=''
    reNjaihzARLCxOmPwMvcQSnXoHVygF =''
    reNjaihzARLCxOmPwMvcQSnXoHVygk =''
    for reNjaihzARLCxOmPwMvcQSnXoHVygf in reNjaihzARLCxOmPwMvcQSnXoHVykE['program']['image']:
     if reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP0900':reNjaihzARLCxOmPwMvcQSnXoHVyfl =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP0200':reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP1800':reNjaihzARLCxOmPwMvcQSnXoHVygs=reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP2000':reNjaihzARLCxOmPwMvcQSnXoHVygF =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP1900':reNjaihzARLCxOmPwMvcQSnXoHVygk =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
    reNjaihzARLCxOmPwMvcQSnXoHVyfq =reNjaihzARLCxOmPwMvcQSnXoHVykE['program']['synopsis']['ko']
    try:
     reNjaihzARLCxOmPwMvcQSnXoHVygt=reNjaihzARLCxOmPwMvcQSnXoHVykE['channel']['name']['ko']
    except:
     reNjaihzARLCxOmPwMvcQSnXoHVygt=''
    try:
     reNjaihzARLCxOmPwMvcQSnXoHVygI =[]
     reNjaihzARLCxOmPwMvcQSnXoHVygW=[]
     reNjaihzARLCxOmPwMvcQSnXoHVygK =[]
     reNjaihzARLCxOmPwMvcQSnXoHVygJ =''
     reNjaihzARLCxOmPwMvcQSnXoHVygY=''
     for reNjaihzARLCxOmPwMvcQSnXoHVygU in reNjaihzARLCxOmPwMvcQSnXoHVykE.get('program').get('actor'):
      if reNjaihzARLCxOmPwMvcQSnXoHVygU!='' and reNjaihzARLCxOmPwMvcQSnXoHVygU!='-' and reNjaihzARLCxOmPwMvcQSnXoHVygU!=u'없음':reNjaihzARLCxOmPwMvcQSnXoHVygI.append(reNjaihzARLCxOmPwMvcQSnXoHVygU)
     for reNjaihzARLCxOmPwMvcQSnXoHVygG in reNjaihzARLCxOmPwMvcQSnXoHVykE.get('program').get('director'):
      if reNjaihzARLCxOmPwMvcQSnXoHVygG!='' and reNjaihzARLCxOmPwMvcQSnXoHVygG!='-' and reNjaihzARLCxOmPwMvcQSnXoHVygG!=u'없음':reNjaihzARLCxOmPwMvcQSnXoHVygW.append(reNjaihzARLCxOmPwMvcQSnXoHVygG)
     if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('program').get('category1_name').get('ko')!='':
      reNjaihzARLCxOmPwMvcQSnXoHVygK.append(reNjaihzARLCxOmPwMvcQSnXoHVykE['program']['category1_name']['ko'])
     if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('program').get('category2_name').get('ko')!='':
      reNjaihzARLCxOmPwMvcQSnXoHVygK.append(reNjaihzARLCxOmPwMvcQSnXoHVykE['program']['category2_name']['ko'])
     if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('program').get('product_year'):reNjaihzARLCxOmPwMvcQSnXoHVygJ=reNjaihzARLCxOmPwMvcQSnXoHVykE['program']['product_year']
     if 'broad_dt' in reNjaihzARLCxOmPwMvcQSnXoHVykE.get('program'):
      reNjaihzARLCxOmPwMvcQSnXoHVygd =reNjaihzARLCxOmPwMvcQSnXoHVykE.get('program').get('broad_dt')
      reNjaihzARLCxOmPwMvcQSnXoHVygY='%s-%s-%s'%(reNjaihzARLCxOmPwMvcQSnXoHVygd[:4],reNjaihzARLCxOmPwMvcQSnXoHVygd[4:6],reNjaihzARLCxOmPwMvcQSnXoHVygd[6:])
    except:
     reNjaihzARLCxOmPwMvcQSnXoHVyWT
    reNjaihzARLCxOmPwMvcQSnXoHVygb={'program':reNjaihzARLCxOmPwMvcQSnXoHVygE,'title':reNjaihzARLCxOmPwMvcQSnXoHVyfB,'thumbnail':{'poster':reNjaihzARLCxOmPwMvcQSnXoHVyfl,'thumb':reNjaihzARLCxOmPwMvcQSnXoHVyfp,'clearlogo':reNjaihzARLCxOmPwMvcQSnXoHVygs,'icon':reNjaihzARLCxOmPwMvcQSnXoHVygF,'banner':reNjaihzARLCxOmPwMvcQSnXoHVygk,'fanart':reNjaihzARLCxOmPwMvcQSnXoHVyfp},'synopsis':reNjaihzARLCxOmPwMvcQSnXoHVyfq,'channel':reNjaihzARLCxOmPwMvcQSnXoHVygt,'cast':reNjaihzARLCxOmPwMvcQSnXoHVygI,'director':reNjaihzARLCxOmPwMvcQSnXoHVygW,'info_genre':reNjaihzARLCxOmPwMvcQSnXoHVygK,'year':reNjaihzARLCxOmPwMvcQSnXoHVygJ,'premiered':reNjaihzARLCxOmPwMvcQSnXoHVygY,'mpaa':reNjaihzARLCxOmPwMvcQSnXoHVygu}
    reNjaihzARLCxOmPwMvcQSnXoHVykU.append(reNjaihzARLCxOmPwMvcQSnXoHVygb)
   if reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['has_more']=='Y':reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWB
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
  return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
 def Get_UHD_ProgramList(reNjaihzARLCxOmPwMvcQSnXoHVysI,page_int):
  reNjaihzARLCxOmPwMvcQSnXoHVykU=[]
  reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWb
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v2/operator/highlights'
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams(uhd=reNjaihzARLCxOmPwMvcQSnXoHVyWB)
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':reNjaihzARLCxOmPwMvcQSnXoHVyWE(page_int),'pocType':'APP_X_TVING_4.0.0',}
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVyWT)
   reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if not('result' in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']):return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
   reNjaihzARLCxOmPwMvcQSnXoHVyfT=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']
   for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVyfT:
    reNjaihzARLCxOmPwMvcQSnXoHVygB=reNjaihzARLCxOmPwMvcQSnXoHVykE['content']['program']
    reNjaihzARLCxOmPwMvcQSnXoHVygq =reNjaihzARLCxOmPwMvcQSnXoHVygB['code']
    reNjaihzARLCxOmPwMvcQSnXoHVyfB =reNjaihzARLCxOmPwMvcQSnXoHVygB['name']['ko'].strip()
    reNjaihzARLCxOmPwMvcQSnXoHVygu =reNjaihzARLCxOmPwMvcQSnXoHVysD.get(reNjaihzARLCxOmPwMvcQSnXoHVygB.get('grade_code'))
    reNjaihzARLCxOmPwMvcQSnXoHVyfq =reNjaihzARLCxOmPwMvcQSnXoHVygB['synopsis']['ko']
    reNjaihzARLCxOmPwMvcQSnXoHVygt =reNjaihzARLCxOmPwMvcQSnXoHVykE['content']['channel']['name']['ko']
    reNjaihzARLCxOmPwMvcQSnXoHVygJ =reNjaihzARLCxOmPwMvcQSnXoHVygB['product_year']
    reNjaihzARLCxOmPwMvcQSnXoHVyfl =''
    reNjaihzARLCxOmPwMvcQSnXoHVyfp =''
    reNjaihzARLCxOmPwMvcQSnXoHVygs=''
    reNjaihzARLCxOmPwMvcQSnXoHVygF =''
    reNjaihzARLCxOmPwMvcQSnXoHVygk =''
    for reNjaihzARLCxOmPwMvcQSnXoHVygf in reNjaihzARLCxOmPwMvcQSnXoHVygB['image']:
     if reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP0900':reNjaihzARLCxOmPwMvcQSnXoHVyfl =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP0200':reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP1800':reNjaihzARLCxOmPwMvcQSnXoHVygs=reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP2000':reNjaihzARLCxOmPwMvcQSnXoHVygF =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP1900':reNjaihzARLCxOmPwMvcQSnXoHVygk =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
    reNjaihzARLCxOmPwMvcQSnXoHVygK =[]
    reNjaihzARLCxOmPwMvcQSnXoHVygI =[]
    reNjaihzARLCxOmPwMvcQSnXoHVygW=[]
    reNjaihzARLCxOmPwMvcQSnXoHVygY =''
    if reNjaihzARLCxOmPwMvcQSnXoHVygB.get('category1_name').get('ko')!='':
     reNjaihzARLCxOmPwMvcQSnXoHVygK.append(reNjaihzARLCxOmPwMvcQSnXoHVygB['category1_name']['ko'])
    if reNjaihzARLCxOmPwMvcQSnXoHVygB.get('category2_name').get('ko')!='':
     reNjaihzARLCxOmPwMvcQSnXoHVygK.append(reNjaihzARLCxOmPwMvcQSnXoHVygB['category2_name']['ko'])
    for reNjaihzARLCxOmPwMvcQSnXoHVygU in reNjaihzARLCxOmPwMvcQSnXoHVygB.get('actor'):
     if reNjaihzARLCxOmPwMvcQSnXoHVygU!='' and reNjaihzARLCxOmPwMvcQSnXoHVygU!='-' and reNjaihzARLCxOmPwMvcQSnXoHVygU!=u'없음':reNjaihzARLCxOmPwMvcQSnXoHVygI.append(reNjaihzARLCxOmPwMvcQSnXoHVygU)
    for reNjaihzARLCxOmPwMvcQSnXoHVygG in reNjaihzARLCxOmPwMvcQSnXoHVygB.get('director'):
     if reNjaihzARLCxOmPwMvcQSnXoHVygG!='' and reNjaihzARLCxOmPwMvcQSnXoHVygG!='-' and reNjaihzARLCxOmPwMvcQSnXoHVygG!=u'없음':reNjaihzARLCxOmPwMvcQSnXoHVygW.append(reNjaihzARLCxOmPwMvcQSnXoHVygG)
    if reNjaihzARLCxOmPwMvcQSnXoHVygB.get('broad_dt')not in[reNjaihzARLCxOmPwMvcQSnXoHVyWT,'']:
     reNjaihzARLCxOmPwMvcQSnXoHVygd =reNjaihzARLCxOmPwMvcQSnXoHVygB.get('broad_dt')
     reNjaihzARLCxOmPwMvcQSnXoHVygY='%s-%s-%s'%(reNjaihzARLCxOmPwMvcQSnXoHVygd[:4],reNjaihzARLCxOmPwMvcQSnXoHVygd[4:6],reNjaihzARLCxOmPwMvcQSnXoHVygd[6:])
    reNjaihzARLCxOmPwMvcQSnXoHVygb={'program':reNjaihzARLCxOmPwMvcQSnXoHVygq,'title':reNjaihzARLCxOmPwMvcQSnXoHVyfB,'mpaa':reNjaihzARLCxOmPwMvcQSnXoHVygu,'thumbnail':{'poster':reNjaihzARLCxOmPwMvcQSnXoHVyfl,'thumb':reNjaihzARLCxOmPwMvcQSnXoHVyfp,'clearlogo':reNjaihzARLCxOmPwMvcQSnXoHVygs,'icon':reNjaihzARLCxOmPwMvcQSnXoHVygF,'banner':reNjaihzARLCxOmPwMvcQSnXoHVygk,'fanart':reNjaihzARLCxOmPwMvcQSnXoHVyfp},'channel':reNjaihzARLCxOmPwMvcQSnXoHVygt,'synopsis':reNjaihzARLCxOmPwMvcQSnXoHVyfq,'year':reNjaihzARLCxOmPwMvcQSnXoHVygJ,'info_genre':reNjaihzARLCxOmPwMvcQSnXoHVygK,'cast':reNjaihzARLCxOmPwMvcQSnXoHVygI,'director':reNjaihzARLCxOmPwMvcQSnXoHVygW,'premiered':reNjaihzARLCxOmPwMvcQSnXoHVygY,}
    reNjaihzARLCxOmPwMvcQSnXoHVykU.append(reNjaihzARLCxOmPwMvcQSnXoHVygb)
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
  return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
 def Get_Origianl_ProgramList(reNjaihzARLCxOmPwMvcQSnXoHVysI,page_int):
  reNjaihzARLCxOmPwMvcQSnXoHVykU=[]
  reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWb
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v2/media/band/originals'
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'pageSize':reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':reNjaihzARLCxOmPwMvcQSnXoHVyWE(page_int),}
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVyWT)
   reNjaihzARLCxOmPwMvcQSnXoHVygp=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   reNjaihzARLCxOmPwMvcQSnXoHVysI.JsonFile_Save(reNjaihzARLCxOmPwMvcQSnXoHVysI.TV_SESSION_COOKIES2,reNjaihzARLCxOmPwMvcQSnXoHVygp)
   if not('contents' in reNjaihzARLCxOmPwMvcQSnXoHVygp['body']):return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
   reNjaihzARLCxOmPwMvcQSnXoHVyfT=reNjaihzARLCxOmPwMvcQSnXoHVygp['body']['contents']
   for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVyfT:
    reNjaihzARLCxOmPwMvcQSnXoHVygl =reNjaihzARLCxOmPwMvcQSnXoHVykE['vod_code']
    reNjaihzARLCxOmPwMvcQSnXoHVyfB =reNjaihzARLCxOmPwMvcQSnXoHVykE['vod_name']
    reNjaihzARLCxOmPwMvcQSnXoHVyfl =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykE['image']
    reNjaihzARLCxOmPwMvcQSnXoHVyIs ='movie' if reNjaihzARLCxOmPwMvcQSnXoHVygl.startswith('M')else 'vod'
    reNjaihzARLCxOmPwMvcQSnXoHVygb={'vod_code':reNjaihzARLCxOmPwMvcQSnXoHVygl,'title':reNjaihzARLCxOmPwMvcQSnXoHVyfB,'thumbnail':{'poster':reNjaihzARLCxOmPwMvcQSnXoHVyfl,'thumb':reNjaihzARLCxOmPwMvcQSnXoHVyfl},'vod_type':reNjaihzARLCxOmPwMvcQSnXoHVyIs,}
    reNjaihzARLCxOmPwMvcQSnXoHVykU.append(reNjaihzARLCxOmPwMvcQSnXoHVygb)
   if reNjaihzARLCxOmPwMvcQSnXoHVygp['body']['has_more']=='Y':reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWB
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
  return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
 def GetEpisodeList(reNjaihzARLCxOmPwMvcQSnXoHVysI,program_code,page_int,orderby='desc'):
  reNjaihzARLCxOmPwMvcQSnXoHVykU=[]
  reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWb
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v2/media/frequency/program/'+program_code
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVyWT)
   reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if not('result' in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']):return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
   reNjaihzARLCxOmPwMvcQSnXoHVyfT=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']
   reNjaihzARLCxOmPwMvcQSnXoHVyIF=reNjaihzARLCxOmPwMvcQSnXoHVyWp(reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['total_count'])
   reNjaihzARLCxOmPwMvcQSnXoHVyIk =reNjaihzARLCxOmPwMvcQSnXoHVyWp(reNjaihzARLCxOmPwMvcQSnXoHVyIF//(reNjaihzARLCxOmPwMvcQSnXoHVysI.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    reNjaihzARLCxOmPwMvcQSnXoHVyID =(reNjaihzARLCxOmPwMvcQSnXoHVyIF-1)-((page_int-1)*reNjaihzARLCxOmPwMvcQSnXoHVysI.EPISODE_LIMIT)
   else:
    reNjaihzARLCxOmPwMvcQSnXoHVyID =(page_int-1)*reNjaihzARLCxOmPwMvcQSnXoHVysI.EPISODE_LIMIT
   for i in reNjaihzARLCxOmPwMvcQSnXoHVyWl(reNjaihzARLCxOmPwMvcQSnXoHVysI.EPISODE_LIMIT):
    if orderby=='desc':
     reNjaihzARLCxOmPwMvcQSnXoHVyIf=reNjaihzARLCxOmPwMvcQSnXoHVyID-i
     if reNjaihzARLCxOmPwMvcQSnXoHVyIf<0:break
    else:
     reNjaihzARLCxOmPwMvcQSnXoHVyIf=reNjaihzARLCxOmPwMvcQSnXoHVyID+i
     if reNjaihzARLCxOmPwMvcQSnXoHVyIf>=reNjaihzARLCxOmPwMvcQSnXoHVyIF:break
    reNjaihzARLCxOmPwMvcQSnXoHVyIg=reNjaihzARLCxOmPwMvcQSnXoHVyfT[reNjaihzARLCxOmPwMvcQSnXoHVyIf]['episode']['code']
    reNjaihzARLCxOmPwMvcQSnXoHVyfB =reNjaihzARLCxOmPwMvcQSnXoHVyfT[reNjaihzARLCxOmPwMvcQSnXoHVyIf]['vod_name']['ko']
    reNjaihzARLCxOmPwMvcQSnXoHVyIW =''
    try:
     reNjaihzARLCxOmPwMvcQSnXoHVygd=reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVyfT[reNjaihzARLCxOmPwMvcQSnXoHVyIf]['episode']['broadcast_date'])
     reNjaihzARLCxOmPwMvcQSnXoHVyIW='%s-%s-%s'%(reNjaihzARLCxOmPwMvcQSnXoHVygd[:4],reNjaihzARLCxOmPwMvcQSnXoHVygd[4:6],reNjaihzARLCxOmPwMvcQSnXoHVygd[6:])
    except:
     reNjaihzARLCxOmPwMvcQSnXoHVyWT
    try:
     if reNjaihzARLCxOmPwMvcQSnXoHVyfT[reNjaihzARLCxOmPwMvcQSnXoHVyIf]['episode']['pip_cliptype']=='C012':
      reNjaihzARLCxOmPwMvcQSnXoHVyIW+=' - Quick VOD'
    except:
     reNjaihzARLCxOmPwMvcQSnXoHVyWT
    reNjaihzARLCxOmPwMvcQSnXoHVyfq =reNjaihzARLCxOmPwMvcQSnXoHVyfT[reNjaihzARLCxOmPwMvcQSnXoHVyIf]['episode']['synopsis']['ko']
    reNjaihzARLCxOmPwMvcQSnXoHVyfl =''
    reNjaihzARLCxOmPwMvcQSnXoHVyfp =''
    reNjaihzARLCxOmPwMvcQSnXoHVygs=''
    reNjaihzARLCxOmPwMvcQSnXoHVygF =''
    reNjaihzARLCxOmPwMvcQSnXoHVygk =''
    reNjaihzARLCxOmPwMvcQSnXoHVygD =''
    for reNjaihzARLCxOmPwMvcQSnXoHVygf in reNjaihzARLCxOmPwMvcQSnXoHVyfT[reNjaihzARLCxOmPwMvcQSnXoHVyIf]['program']['image']:
     if reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP0900':reNjaihzARLCxOmPwMvcQSnXoHVyfl =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP1800':reNjaihzARLCxOmPwMvcQSnXoHVygs=reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP2000':reNjaihzARLCxOmPwMvcQSnXoHVygF =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP1900':reNjaihzARLCxOmPwMvcQSnXoHVygk =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIP0200':reNjaihzARLCxOmPwMvcQSnXoHVygD =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
    for reNjaihzARLCxOmPwMvcQSnXoHVygf in reNjaihzARLCxOmPwMvcQSnXoHVyfT[reNjaihzARLCxOmPwMvcQSnXoHVyIf]['episode']['image']:
     if reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIE0400':reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
    try:
     reNjaihzARLCxOmPwMvcQSnXoHVyIK=reNjaihzARLCxOmPwMvcQSnXoHVyIu=reNjaihzARLCxOmPwMvcQSnXoHVyIY=''
     reNjaihzARLCxOmPwMvcQSnXoHVyIJ=0
     reNjaihzARLCxOmPwMvcQSnXoHVyIK =reNjaihzARLCxOmPwMvcQSnXoHVyfT[reNjaihzARLCxOmPwMvcQSnXoHVyIf]['program']['name']['ko']
     reNjaihzARLCxOmPwMvcQSnXoHVyIu =reNjaihzARLCxOmPwMvcQSnXoHVyIW
     reNjaihzARLCxOmPwMvcQSnXoHVyIY =reNjaihzARLCxOmPwMvcQSnXoHVyfT[reNjaihzARLCxOmPwMvcQSnXoHVyIf]['channel']['name']['ko']
     if 'frequency' in reNjaihzARLCxOmPwMvcQSnXoHVyfT[reNjaihzARLCxOmPwMvcQSnXoHVyIf]['episode']:reNjaihzARLCxOmPwMvcQSnXoHVyIJ=reNjaihzARLCxOmPwMvcQSnXoHVyfT[reNjaihzARLCxOmPwMvcQSnXoHVyIf]['episode']['frequency']
    except:
     reNjaihzARLCxOmPwMvcQSnXoHVyWT
    reNjaihzARLCxOmPwMvcQSnXoHVygb={'episode':reNjaihzARLCxOmPwMvcQSnXoHVyIg,'title':reNjaihzARLCxOmPwMvcQSnXoHVyfB,'subtitle':reNjaihzARLCxOmPwMvcQSnXoHVyIW,'thumbnail':{'poster':reNjaihzARLCxOmPwMvcQSnXoHVyfl,'thumb':reNjaihzARLCxOmPwMvcQSnXoHVyfp,'clearlogo':reNjaihzARLCxOmPwMvcQSnXoHVygs,'icon':reNjaihzARLCxOmPwMvcQSnXoHVygF,'banner':reNjaihzARLCxOmPwMvcQSnXoHVygk,'fanart':reNjaihzARLCxOmPwMvcQSnXoHVygD},'synopsis':reNjaihzARLCxOmPwMvcQSnXoHVyfq,'info_title':reNjaihzARLCxOmPwMvcQSnXoHVyIK,'aired':reNjaihzARLCxOmPwMvcQSnXoHVyIu,'studio':reNjaihzARLCxOmPwMvcQSnXoHVyIY,'frequency':reNjaihzARLCxOmPwMvcQSnXoHVyIJ}
    reNjaihzARLCxOmPwMvcQSnXoHVykU.append(reNjaihzARLCxOmPwMvcQSnXoHVygb)
   if reNjaihzARLCxOmPwMvcQSnXoHVyIk>page_int:reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWB
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
  return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG,reNjaihzARLCxOmPwMvcQSnXoHVyIk
 def GetMovieList(reNjaihzARLCxOmPwMvcQSnXoHVysI,genre,orderby,page_int):
  reNjaihzARLCxOmPwMvcQSnXoHVykU=[]
  reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWb
  try:
   if genre=='PARAMOUNT':
    reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v2/media/paramount/movies'
   else:
    reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v2/media/movies'
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'pageSize':reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':reNjaihzARLCxOmPwMvcQSnXoHVyWE(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:reNjaihzARLCxOmPwMvcQSnXoHVykT['categoryCode']=genre
   reNjaihzARLCxOmPwMvcQSnXoHVykT['productPackageCode']=','.join(reNjaihzARLCxOmPwMvcQSnXoHVysI.MOVIE_LITE)
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVyWT)
   reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if not('result' in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']):return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
   reNjaihzARLCxOmPwMvcQSnXoHVyfT=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']
   for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVyfT:
    if 'release_date' in reNjaihzARLCxOmPwMvcQSnXoHVykE.get('movie'):
     reNjaihzARLCxOmPwMvcQSnXoHVygJ=reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVykE.get('movie').get('release_date'))[:4]
    else:
     reNjaihzARLCxOmPwMvcQSnXoHVygJ=reNjaihzARLCxOmPwMvcQSnXoHVyWT
    reNjaihzARLCxOmPwMvcQSnXoHVyIU =reNjaihzARLCxOmPwMvcQSnXoHVykE['movie']['code']
    reNjaihzARLCxOmPwMvcQSnXoHVyfB =reNjaihzARLCxOmPwMvcQSnXoHVykE['movie']['name']['ko'].strip()
    if reNjaihzARLCxOmPwMvcQSnXoHVygJ not in[reNjaihzARLCxOmPwMvcQSnXoHVyWT,'0','']:reNjaihzARLCxOmPwMvcQSnXoHVyfB+=u' (%s)'%(reNjaihzARLCxOmPwMvcQSnXoHVygJ)
    reNjaihzARLCxOmPwMvcQSnXoHVyfl=''
    reNjaihzARLCxOmPwMvcQSnXoHVyfp =''
    reNjaihzARLCxOmPwMvcQSnXoHVygs=''
    for reNjaihzARLCxOmPwMvcQSnXoHVygf in reNjaihzARLCxOmPwMvcQSnXoHVykE['movie']['image']:
     if reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIM2100':reNjaihzARLCxOmPwMvcQSnXoHVyfl =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIM0400':reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIM1800':reNjaihzARLCxOmPwMvcQSnXoHVygs=reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
    reNjaihzARLCxOmPwMvcQSnXoHVyfq =reNjaihzARLCxOmPwMvcQSnXoHVykE['movie']['story']['ko']
    try:
     reNjaihzARLCxOmPwMvcQSnXoHVyIK =reNjaihzARLCxOmPwMvcQSnXoHVykE['movie']['name']['ko'].strip()
     reNjaihzARLCxOmPwMvcQSnXoHVygu =reNjaihzARLCxOmPwMvcQSnXoHVysD.get(reNjaihzARLCxOmPwMvcQSnXoHVykE.get('grade_code'))
     reNjaihzARLCxOmPwMvcQSnXoHVygI=[]
     reNjaihzARLCxOmPwMvcQSnXoHVygW=[]
     reNjaihzARLCxOmPwMvcQSnXoHVygK=[]
     reNjaihzARLCxOmPwMvcQSnXoHVyIG=0
     reNjaihzARLCxOmPwMvcQSnXoHVygY=''
     reNjaihzARLCxOmPwMvcQSnXoHVyIY =''
     for reNjaihzARLCxOmPwMvcQSnXoHVygU in reNjaihzARLCxOmPwMvcQSnXoHVykE.get('movie').get('actor'):
      if reNjaihzARLCxOmPwMvcQSnXoHVygU!='':reNjaihzARLCxOmPwMvcQSnXoHVygI.append(reNjaihzARLCxOmPwMvcQSnXoHVygU)
     for reNjaihzARLCxOmPwMvcQSnXoHVygG in reNjaihzARLCxOmPwMvcQSnXoHVykE.get('movie').get('director'):
      if reNjaihzARLCxOmPwMvcQSnXoHVygG!='':reNjaihzARLCxOmPwMvcQSnXoHVygW.append(reNjaihzARLCxOmPwMvcQSnXoHVygG)
     if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('movie').get('category1_name').get('ko')!='':
      reNjaihzARLCxOmPwMvcQSnXoHVygK.append(reNjaihzARLCxOmPwMvcQSnXoHVykE['movie']['category1_name']['ko'])
     if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('movie').get('category2_name').get('ko')!='':
      reNjaihzARLCxOmPwMvcQSnXoHVygK.append(reNjaihzARLCxOmPwMvcQSnXoHVykE['movie']['category2_name']['ko'])
     if 'duration' in reNjaihzARLCxOmPwMvcQSnXoHVykE.get('movie'):reNjaihzARLCxOmPwMvcQSnXoHVyIG=reNjaihzARLCxOmPwMvcQSnXoHVykE.get('movie').get('duration')
     if 'release_date' in reNjaihzARLCxOmPwMvcQSnXoHVykE.get('movie'):
      reNjaihzARLCxOmPwMvcQSnXoHVygd=reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVykE.get('movie').get('release_date'))
      if reNjaihzARLCxOmPwMvcQSnXoHVygd!='0':reNjaihzARLCxOmPwMvcQSnXoHVygY='%s-%s-%s'%(reNjaihzARLCxOmPwMvcQSnXoHVygd[:4],reNjaihzARLCxOmPwMvcQSnXoHVygd[4:6],reNjaihzARLCxOmPwMvcQSnXoHVygd[6:])
     if 'production' in reNjaihzARLCxOmPwMvcQSnXoHVykE.get('movie'):reNjaihzARLCxOmPwMvcQSnXoHVyIY=reNjaihzARLCxOmPwMvcQSnXoHVykE.get('movie').get('production')
    except:
     reNjaihzARLCxOmPwMvcQSnXoHVyWT
    reNjaihzARLCxOmPwMvcQSnXoHVygb={'moviecode':reNjaihzARLCxOmPwMvcQSnXoHVyIU,'title':reNjaihzARLCxOmPwMvcQSnXoHVyfB,'thumbnail':{'poster':reNjaihzARLCxOmPwMvcQSnXoHVyfl,'thumb':reNjaihzARLCxOmPwMvcQSnXoHVyfp,'clearlogo':reNjaihzARLCxOmPwMvcQSnXoHVygs,'fanart':reNjaihzARLCxOmPwMvcQSnXoHVyfp},'synopsis':reNjaihzARLCxOmPwMvcQSnXoHVyfq,'info_title':reNjaihzARLCxOmPwMvcQSnXoHVyIK,'year':reNjaihzARLCxOmPwMvcQSnXoHVygJ,'cast':reNjaihzARLCxOmPwMvcQSnXoHVygI,'director':reNjaihzARLCxOmPwMvcQSnXoHVygW,'info_genre':reNjaihzARLCxOmPwMvcQSnXoHVygK,'duration':reNjaihzARLCxOmPwMvcQSnXoHVyIG,'premiered':reNjaihzARLCxOmPwMvcQSnXoHVygY,'studio':reNjaihzARLCxOmPwMvcQSnXoHVyIY,'mpaa':reNjaihzARLCxOmPwMvcQSnXoHVygu}
    reNjaihzARLCxOmPwMvcQSnXoHVyId=reNjaihzARLCxOmPwMvcQSnXoHVyWb
    for reNjaihzARLCxOmPwMvcQSnXoHVyIT in reNjaihzARLCxOmPwMvcQSnXoHVykE['billing_package_id']:
     if reNjaihzARLCxOmPwMvcQSnXoHVyIT in reNjaihzARLCxOmPwMvcQSnXoHVysI.MOVIE_LITE:
      reNjaihzARLCxOmPwMvcQSnXoHVyId=reNjaihzARLCxOmPwMvcQSnXoHVyWB
      break
    if reNjaihzARLCxOmPwMvcQSnXoHVyId==reNjaihzARLCxOmPwMvcQSnXoHVyWb: 
     reNjaihzARLCxOmPwMvcQSnXoHVygb['title']=reNjaihzARLCxOmPwMvcQSnXoHVygb['title']+' [개별구매]'
    reNjaihzARLCxOmPwMvcQSnXoHVykU.append(reNjaihzARLCxOmPwMvcQSnXoHVygb)
   if reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['has_more']=='Y':reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWB
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
  return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
 def Get_UHD_MovieList(reNjaihzARLCxOmPwMvcQSnXoHVysI,page_int):
  reNjaihzARLCxOmPwMvcQSnXoHVykU=[]
  reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWb
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v2/operator/highlights'
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams(uhd=reNjaihzARLCxOmPwMvcQSnXoHVyWB)
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':reNjaihzARLCxOmPwMvcQSnXoHVyWE(page_int),'pocType':'APP_X_TVING_4.0.0',}
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVyWT)
   reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if not('result' in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']):return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
   reNjaihzARLCxOmPwMvcQSnXoHVyfT=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']
   for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVyfT:
    reNjaihzARLCxOmPwMvcQSnXoHVygB=reNjaihzARLCxOmPwMvcQSnXoHVykE['content']['movie']
    reNjaihzARLCxOmPwMvcQSnXoHVygq =reNjaihzARLCxOmPwMvcQSnXoHVygB['code']
    reNjaihzARLCxOmPwMvcQSnXoHVyfB =reNjaihzARLCxOmPwMvcQSnXoHVygB['name']['ko'].strip()
    reNjaihzARLCxOmPwMvcQSnXoHVyIK =reNjaihzARLCxOmPwMvcQSnXoHVygB['name']['ko'].strip()
    reNjaihzARLCxOmPwMvcQSnXoHVygJ =reNjaihzARLCxOmPwMvcQSnXoHVygB['product_year']
    if reNjaihzARLCxOmPwMvcQSnXoHVygJ:reNjaihzARLCxOmPwMvcQSnXoHVyfB+=u' (%s)'%(reNjaihzARLCxOmPwMvcQSnXoHVygB['product_year'])
    reNjaihzARLCxOmPwMvcQSnXoHVyfq =reNjaihzARLCxOmPwMvcQSnXoHVygB['story']['ko']
    reNjaihzARLCxOmPwMvcQSnXoHVyIG =reNjaihzARLCxOmPwMvcQSnXoHVygB['duration']
    reNjaihzARLCxOmPwMvcQSnXoHVygu =reNjaihzARLCxOmPwMvcQSnXoHVysD.get(reNjaihzARLCxOmPwMvcQSnXoHVygB.get('grade_code'))
    reNjaihzARLCxOmPwMvcQSnXoHVyIY =reNjaihzARLCxOmPwMvcQSnXoHVygB['production']
    reNjaihzARLCxOmPwMvcQSnXoHVyfl=''
    reNjaihzARLCxOmPwMvcQSnXoHVyfp =''
    reNjaihzARLCxOmPwMvcQSnXoHVygs=''
    reNjaihzARLCxOmPwMvcQSnXoHVygK =[]
    reNjaihzARLCxOmPwMvcQSnXoHVygI =[]
    reNjaihzARLCxOmPwMvcQSnXoHVygW=[]
    reNjaihzARLCxOmPwMvcQSnXoHVygY =''
    for reNjaihzARLCxOmPwMvcQSnXoHVygf in reNjaihzARLCxOmPwMvcQSnXoHVygB['image']:
     if reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIM2100':reNjaihzARLCxOmPwMvcQSnXoHVyfl =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIM0400':reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
     elif reNjaihzARLCxOmPwMvcQSnXoHVygf['code']=='CAIM1800':reNjaihzARLCxOmPwMvcQSnXoHVygs=reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf['url']
    if reNjaihzARLCxOmPwMvcQSnXoHVygB['release_date']not in[reNjaihzARLCxOmPwMvcQSnXoHVyWT,0]:
     reNjaihzARLCxOmPwMvcQSnXoHVygd=reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVygB['release_date'])
     if reNjaihzARLCxOmPwMvcQSnXoHVygd!='0':reNjaihzARLCxOmPwMvcQSnXoHVygY='%s-%s-%s'%(reNjaihzARLCxOmPwMvcQSnXoHVygd[:4],reNjaihzARLCxOmPwMvcQSnXoHVygd[4:6],reNjaihzARLCxOmPwMvcQSnXoHVygd[6:])
    if reNjaihzARLCxOmPwMvcQSnXoHVygB.get('category1_name').get('ko')!='':
     reNjaihzARLCxOmPwMvcQSnXoHVygK.append(reNjaihzARLCxOmPwMvcQSnXoHVygB['category1_name']['ko'])
    if reNjaihzARLCxOmPwMvcQSnXoHVygB.get('category2_name').get('ko')!='':
     reNjaihzARLCxOmPwMvcQSnXoHVygK.append(reNjaihzARLCxOmPwMvcQSnXoHVygB['category2_name']['ko'])
    for reNjaihzARLCxOmPwMvcQSnXoHVygU in reNjaihzARLCxOmPwMvcQSnXoHVygB.get('actor'):
     if reNjaihzARLCxOmPwMvcQSnXoHVygU!='':reNjaihzARLCxOmPwMvcQSnXoHVygI.append(reNjaihzARLCxOmPwMvcQSnXoHVygU)
    for reNjaihzARLCxOmPwMvcQSnXoHVygG in reNjaihzARLCxOmPwMvcQSnXoHVygB.get('director'):
     if reNjaihzARLCxOmPwMvcQSnXoHVygG!='':reNjaihzARLCxOmPwMvcQSnXoHVygW.append(reNjaihzARLCxOmPwMvcQSnXoHVygG)
    reNjaihzARLCxOmPwMvcQSnXoHVygb={'moviecode':reNjaihzARLCxOmPwMvcQSnXoHVygq,'title':reNjaihzARLCxOmPwMvcQSnXoHVyfB,'thumbnail':{'poster':reNjaihzARLCxOmPwMvcQSnXoHVyfl,'thumb':reNjaihzARLCxOmPwMvcQSnXoHVyfp,'clearlogo':reNjaihzARLCxOmPwMvcQSnXoHVygs,'fanart':reNjaihzARLCxOmPwMvcQSnXoHVyfp},'year':reNjaihzARLCxOmPwMvcQSnXoHVygJ,'info_title':reNjaihzARLCxOmPwMvcQSnXoHVyIK,'synopsis':reNjaihzARLCxOmPwMvcQSnXoHVyfq,'mpaa':reNjaihzARLCxOmPwMvcQSnXoHVygu,'duration':reNjaihzARLCxOmPwMvcQSnXoHVyIG,'premiered':reNjaihzARLCxOmPwMvcQSnXoHVygY,'studio':reNjaihzARLCxOmPwMvcQSnXoHVyIY,'info_genre':reNjaihzARLCxOmPwMvcQSnXoHVygK,'cast':reNjaihzARLCxOmPwMvcQSnXoHVygI,'director':reNjaihzARLCxOmPwMvcQSnXoHVygW,}
    reNjaihzARLCxOmPwMvcQSnXoHVykU.append(reNjaihzARLCxOmPwMvcQSnXoHVygb)
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
  return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
 def GetMovieGenre(reNjaihzARLCxOmPwMvcQSnXoHVysI):
  reNjaihzARLCxOmPwMvcQSnXoHVykU=[]
  reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWb
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v2/media/movie/curations'
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVyWT)
   reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if not('result' in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']):return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
   reNjaihzARLCxOmPwMvcQSnXoHVyfT=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']
   for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVyfT:
    reNjaihzARLCxOmPwMvcQSnXoHVyIb =reNjaihzARLCxOmPwMvcQSnXoHVykE['curation_code']
    reNjaihzARLCxOmPwMvcQSnXoHVyIE =reNjaihzARLCxOmPwMvcQSnXoHVykE['curation_name']
    reNjaihzARLCxOmPwMvcQSnXoHVygb={'curation_code':reNjaihzARLCxOmPwMvcQSnXoHVyIb,'curation_name':reNjaihzARLCxOmPwMvcQSnXoHVyIE}
    reNjaihzARLCxOmPwMvcQSnXoHVykU.append(reNjaihzARLCxOmPwMvcQSnXoHVygb)
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
  return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
 def GetSearchList(reNjaihzARLCxOmPwMvcQSnXoHVysI,search_key,page_int,stype):
  reNjaihzARLCxOmPwMvcQSnXoHVyIt=[]
  reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWb
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/search/getSearch.jsp'
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':reNjaihzARLCxOmPwMvcQSnXoHVyWE(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':reNjaihzARLCxOmPwMvcQSnXoHVysI.SCREENCODE,'os':reNjaihzARLCxOmPwMvcQSnXoHVysI.OSCODE,'network':reNjaihzARLCxOmPwMvcQSnXoHVysI.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':reNjaihzARLCxOmPwMvcQSnXoHVysI.APIKEY,'networkCode':reNjaihzARLCxOmPwMvcQSnXoHVysI.NETWORKCODE,'osCode ':reNjaihzARLCxOmPwMvcQSnXoHVysI.OSCODE,'teleCode ':reNjaihzARLCxOmPwMvcQSnXoHVysI.TELECODE,'screenCode ':reNjaihzARLCxOmPwMvcQSnXoHVysI.SCREENCODE}
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.SEARCH_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVykT,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVyWT)
   reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if stype=='vod':
    if not('programRsb' in reNjaihzARLCxOmPwMvcQSnXoHVykb):return reNjaihzARLCxOmPwMvcQSnXoHVyIt,reNjaihzARLCxOmPwMvcQSnXoHVyfG
    reNjaihzARLCxOmPwMvcQSnXoHVyIB=reNjaihzARLCxOmPwMvcQSnXoHVykb['programRsb']['dataList']
    reNjaihzARLCxOmPwMvcQSnXoHVyIq =reNjaihzARLCxOmPwMvcQSnXoHVyWp(reNjaihzARLCxOmPwMvcQSnXoHVykb['programRsb']['count'])
    for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVyIB:
     reNjaihzARLCxOmPwMvcQSnXoHVygE=reNjaihzARLCxOmPwMvcQSnXoHVykE['mast_cd']
     reNjaihzARLCxOmPwMvcQSnXoHVyfB =reNjaihzARLCxOmPwMvcQSnXoHVykE['mast_nm']
     reNjaihzARLCxOmPwMvcQSnXoHVyfl=reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykE['web_url4']
     reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykE['web_url']
     try:
      reNjaihzARLCxOmPwMvcQSnXoHVygI =[]
      reNjaihzARLCxOmPwMvcQSnXoHVygW=[]
      reNjaihzARLCxOmPwMvcQSnXoHVygK =[]
      reNjaihzARLCxOmPwMvcQSnXoHVyIG =0
      reNjaihzARLCxOmPwMvcQSnXoHVygu =''
      reNjaihzARLCxOmPwMvcQSnXoHVygJ =''
      reNjaihzARLCxOmPwMvcQSnXoHVyIu =''
      if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('actor') !='' and reNjaihzARLCxOmPwMvcQSnXoHVykE.get('actor') !='-':reNjaihzARLCxOmPwMvcQSnXoHVygI =reNjaihzARLCxOmPwMvcQSnXoHVykE.get('actor').split(',')
      if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('director')!='' and reNjaihzARLCxOmPwMvcQSnXoHVykE.get('director')!='-':reNjaihzARLCxOmPwMvcQSnXoHVygW=reNjaihzARLCxOmPwMvcQSnXoHVykE.get('director').split(',')
      if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('cate_nm')!='' and reNjaihzARLCxOmPwMvcQSnXoHVykE.get('cate_nm')!='-':reNjaihzARLCxOmPwMvcQSnXoHVygK =reNjaihzARLCxOmPwMvcQSnXoHVykE.get('cate_nm').split('/')
      if 'targetage' in reNjaihzARLCxOmPwMvcQSnXoHVykE:reNjaihzARLCxOmPwMvcQSnXoHVygu=reNjaihzARLCxOmPwMvcQSnXoHVykE.get('targetage')
      if 'broad_dt' in reNjaihzARLCxOmPwMvcQSnXoHVykE:
       reNjaihzARLCxOmPwMvcQSnXoHVygd=reNjaihzARLCxOmPwMvcQSnXoHVykE.get('broad_dt')
       reNjaihzARLCxOmPwMvcQSnXoHVyIu='%s-%s-%s'%(reNjaihzARLCxOmPwMvcQSnXoHVygd[:4],reNjaihzARLCxOmPwMvcQSnXoHVygd[4:6],reNjaihzARLCxOmPwMvcQSnXoHVygd[6:])
       reNjaihzARLCxOmPwMvcQSnXoHVygJ =reNjaihzARLCxOmPwMvcQSnXoHVygd[:4]
     except:
      reNjaihzARLCxOmPwMvcQSnXoHVyWT
     reNjaihzARLCxOmPwMvcQSnXoHVygb={'program':reNjaihzARLCxOmPwMvcQSnXoHVygE,'title':reNjaihzARLCxOmPwMvcQSnXoHVyfB,'thumbnail':{'poster':reNjaihzARLCxOmPwMvcQSnXoHVyfl,'thumb':reNjaihzARLCxOmPwMvcQSnXoHVyfp,'fanart':reNjaihzARLCxOmPwMvcQSnXoHVyfp},'synopsis':'','cast':reNjaihzARLCxOmPwMvcQSnXoHVygI,'director':reNjaihzARLCxOmPwMvcQSnXoHVygW,'info_genre':reNjaihzARLCxOmPwMvcQSnXoHVygK,'duration':reNjaihzARLCxOmPwMvcQSnXoHVyIG,'mpaa':reNjaihzARLCxOmPwMvcQSnXoHVygu,'year':reNjaihzARLCxOmPwMvcQSnXoHVygJ,'aired':reNjaihzARLCxOmPwMvcQSnXoHVyIu}
     reNjaihzARLCxOmPwMvcQSnXoHVyIt.append(reNjaihzARLCxOmPwMvcQSnXoHVygb)
   else:
    if not('vodMVRsb' in reNjaihzARLCxOmPwMvcQSnXoHVykb):return reNjaihzARLCxOmPwMvcQSnXoHVyIt,reNjaihzARLCxOmPwMvcQSnXoHVyfG
    reNjaihzARLCxOmPwMvcQSnXoHVyIp=reNjaihzARLCxOmPwMvcQSnXoHVykb['vodMVRsb']['dataList']
    reNjaihzARLCxOmPwMvcQSnXoHVyIq =reNjaihzARLCxOmPwMvcQSnXoHVyWp(reNjaihzARLCxOmPwMvcQSnXoHVykb['vodMVRsb']['count'])
    for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVyIp:
     reNjaihzARLCxOmPwMvcQSnXoHVygE=reNjaihzARLCxOmPwMvcQSnXoHVykE['mast_cd']
     reNjaihzARLCxOmPwMvcQSnXoHVyfB =reNjaihzARLCxOmPwMvcQSnXoHVykE['mast_nm'].strip()
     reNjaihzARLCxOmPwMvcQSnXoHVyfl =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykE['web_url']
     reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVyfl
     reNjaihzARLCxOmPwMvcQSnXoHVygs=''
     try:
      reNjaihzARLCxOmPwMvcQSnXoHVygI =[]
      reNjaihzARLCxOmPwMvcQSnXoHVygW=[]
      reNjaihzARLCxOmPwMvcQSnXoHVygK =[]
      reNjaihzARLCxOmPwMvcQSnXoHVyIG =0
      reNjaihzARLCxOmPwMvcQSnXoHVygu =''
      reNjaihzARLCxOmPwMvcQSnXoHVygJ =''
      reNjaihzARLCxOmPwMvcQSnXoHVyIu =''
      if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('actor') !='' and reNjaihzARLCxOmPwMvcQSnXoHVykE.get('actor') !='-':reNjaihzARLCxOmPwMvcQSnXoHVygI =reNjaihzARLCxOmPwMvcQSnXoHVykE.get('actor').split(',')
      if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('director')!='' and reNjaihzARLCxOmPwMvcQSnXoHVykE.get('director')!='-':reNjaihzARLCxOmPwMvcQSnXoHVygW=reNjaihzARLCxOmPwMvcQSnXoHVykE.get('director').split(',')
      if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('cate_nm')!='' and reNjaihzARLCxOmPwMvcQSnXoHVykE.get('cate_nm')!='-':reNjaihzARLCxOmPwMvcQSnXoHVygK =reNjaihzARLCxOmPwMvcQSnXoHVykE.get('cate_nm').split('/')
      if reNjaihzARLCxOmPwMvcQSnXoHVykE.get('runtime_sec')!='':reNjaihzARLCxOmPwMvcQSnXoHVyIG=reNjaihzARLCxOmPwMvcQSnXoHVykE.get('runtime_sec')
      if 'grade_nm' in reNjaihzARLCxOmPwMvcQSnXoHVykE:reNjaihzARLCxOmPwMvcQSnXoHVygu=reNjaihzARLCxOmPwMvcQSnXoHVykE.get('grade_nm')
      reNjaihzARLCxOmPwMvcQSnXoHVygd=reNjaihzARLCxOmPwMvcQSnXoHVykE.get('broad_dt')
      if data_str!='':
       reNjaihzARLCxOmPwMvcQSnXoHVyIu='%s-%s-%s'%(reNjaihzARLCxOmPwMvcQSnXoHVygd[:4],reNjaihzARLCxOmPwMvcQSnXoHVygd[4:6],reNjaihzARLCxOmPwMvcQSnXoHVygd[6:])
       reNjaihzARLCxOmPwMvcQSnXoHVygJ =reNjaihzARLCxOmPwMvcQSnXoHVygd[:4]
     except:
      reNjaihzARLCxOmPwMvcQSnXoHVyWT
     reNjaihzARLCxOmPwMvcQSnXoHVygb={'movie':reNjaihzARLCxOmPwMvcQSnXoHVygE,'title':reNjaihzARLCxOmPwMvcQSnXoHVyfB,'thumbnail':{'poster':reNjaihzARLCxOmPwMvcQSnXoHVyfl,'thumb':reNjaihzARLCxOmPwMvcQSnXoHVyfp,'fanart':reNjaihzARLCxOmPwMvcQSnXoHVyfp,'clearlogo':reNjaihzARLCxOmPwMvcQSnXoHVygs},'synopsis':'','cast':reNjaihzARLCxOmPwMvcQSnXoHVygI,'director':reNjaihzARLCxOmPwMvcQSnXoHVygW,'info_genre':reNjaihzARLCxOmPwMvcQSnXoHVygK,'duration':reNjaihzARLCxOmPwMvcQSnXoHVyIG,'mpaa':reNjaihzARLCxOmPwMvcQSnXoHVygu,'year':reNjaihzARLCxOmPwMvcQSnXoHVygJ,'aired':reNjaihzARLCxOmPwMvcQSnXoHVyIu}
     reNjaihzARLCxOmPwMvcQSnXoHVyIt.append(reNjaihzARLCxOmPwMvcQSnXoHVygb)
   if reNjaihzARLCxOmPwMvcQSnXoHVyIq>(page_int*reNjaihzARLCxOmPwMvcQSnXoHVysI.SEARCH_LIMIT):reNjaihzARLCxOmPwMvcQSnXoHVyfG=reNjaihzARLCxOmPwMvcQSnXoHVyWB
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
  return reNjaihzARLCxOmPwMvcQSnXoHVyIt,reNjaihzARLCxOmPwMvcQSnXoHVyfG
 def GetBookmarkInfo(reNjaihzARLCxOmPwMvcQSnXoHVysI,videoid,vidtype):
  reNjaihzARLCxOmPwMvcQSnXoHVyIl={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+'/v2/media/program/'+videoid
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'pageNo':'1','pageSize':'10','order':'name',}
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVyWT)
   reNjaihzARLCxOmPwMvcQSnXoHVygp=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if not('body' in reNjaihzARLCxOmPwMvcQSnXoHVygp):return{}
   reNjaihzARLCxOmPwMvcQSnXoHVyWs=reNjaihzARLCxOmPwMvcQSnXoHVygp['body']
   reNjaihzARLCxOmPwMvcQSnXoHVyfB=reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('name').get('ko').strip()
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['title'] =reNjaihzARLCxOmPwMvcQSnXoHVyfB
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['title']=reNjaihzARLCxOmPwMvcQSnXoHVyfB
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['mpaa'] =reNjaihzARLCxOmPwMvcQSnXoHVysD.get(reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('grade_code'))
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['plot'] =reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('synopsis').get('ko')
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['year'] =reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('product_year')
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['cast'] =reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('actor')
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['director']=reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('director')
   if reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('category1_name').get('ko')!='':
    reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['genre'].append(reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('category1_name').get('ko'))
   if reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('category2_name').get('ko')!='':
    reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['genre'].append(reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('category2_name').get('ko'))
   reNjaihzARLCxOmPwMvcQSnXoHVygd=reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('broad_dt'))
   if reNjaihzARLCxOmPwMvcQSnXoHVygd!='0':reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(reNjaihzARLCxOmPwMvcQSnXoHVygd[:4],reNjaihzARLCxOmPwMvcQSnXoHVygd[4:6],reNjaihzARLCxOmPwMvcQSnXoHVygd[6:])
   reNjaihzARLCxOmPwMvcQSnXoHVyfl =''
   reNjaihzARLCxOmPwMvcQSnXoHVyfp =''
   reNjaihzARLCxOmPwMvcQSnXoHVygs=''
   reNjaihzARLCxOmPwMvcQSnXoHVygF =''
   reNjaihzARLCxOmPwMvcQSnXoHVygk =''
   for reNjaihzARLCxOmPwMvcQSnXoHVygf in reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('image'):
    if reNjaihzARLCxOmPwMvcQSnXoHVygf.get('code')=='CAIP0900':reNjaihzARLCxOmPwMvcQSnXoHVyfl =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf.get('url')
    elif reNjaihzARLCxOmPwMvcQSnXoHVygf.get('code')=='CAIP0200':reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf.get('url')
    elif reNjaihzARLCxOmPwMvcQSnXoHVygf.get('code')=='CAIP1800':reNjaihzARLCxOmPwMvcQSnXoHVygs=reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf.get('url')
    elif reNjaihzARLCxOmPwMvcQSnXoHVygf.get('code')=='CAIP2000':reNjaihzARLCxOmPwMvcQSnXoHVygF =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf.get('url')
    elif reNjaihzARLCxOmPwMvcQSnXoHVygf.get('code')=='CAIP1900':reNjaihzARLCxOmPwMvcQSnXoHVygk =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf.get('url')
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['thumbnail']['poster']=reNjaihzARLCxOmPwMvcQSnXoHVyfl
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['thumbnail']['thumb']=reNjaihzARLCxOmPwMvcQSnXoHVyfp
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['thumbnail']['clearlogo']=reNjaihzARLCxOmPwMvcQSnXoHVygs
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['thumbnail']['icon']=reNjaihzARLCxOmPwMvcQSnXoHVygF
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['thumbnail']['banner']=reNjaihzARLCxOmPwMvcQSnXoHVygk
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['thumbnail']['fanart']=reNjaihzARLCxOmPwMvcQSnXoHVyfp
  else:
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+'/v2a/media/stream/info'
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies']['tving_uuid'].split('-')[0],'uuid':reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.GetNoCache(1)),'wm':'Y',}
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVyWT)
   reNjaihzARLCxOmPwMvcQSnXoHVygp=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if not('content' in reNjaihzARLCxOmPwMvcQSnXoHVygp['body']):return{}
   reNjaihzARLCxOmPwMvcQSnXoHVyWs=reNjaihzARLCxOmPwMvcQSnXoHVygp['body']['content']['info']['movie']
   reNjaihzARLCxOmPwMvcQSnXoHVyfB =reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('name').get('ko').strip()
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['title']=reNjaihzARLCxOmPwMvcQSnXoHVyfB
   reNjaihzARLCxOmPwMvcQSnXoHVyfB +=u' (%s)'%(reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('product_year'))
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['title'] =reNjaihzARLCxOmPwMvcQSnXoHVyfB
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['mpaa'] =reNjaihzARLCxOmPwMvcQSnXoHVysD.get(reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('grade_code'))
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['plot'] =reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('story').get('ko')
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['year'] =reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('product_year')
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['studio'] =reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('production')
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['duration']=reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('duration')
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['cast'] =reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('actor')
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['director']=reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('director')
   if reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('category1_name').get('ko')!='':
    reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['genre'].append(reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('category1_name').get('ko'))
   if reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('category2_name').get('ko')!='':
    reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['genre'].append(reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('category2_name').get('ko'))
   reNjaihzARLCxOmPwMvcQSnXoHVygd=reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('release_date'))
   if reNjaihzARLCxOmPwMvcQSnXoHVygd!='0':reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(reNjaihzARLCxOmPwMvcQSnXoHVygd[:4],reNjaihzARLCxOmPwMvcQSnXoHVygd[4:6],reNjaihzARLCxOmPwMvcQSnXoHVygd[6:])
   reNjaihzARLCxOmPwMvcQSnXoHVyfl=''
   reNjaihzARLCxOmPwMvcQSnXoHVyfp =''
   reNjaihzARLCxOmPwMvcQSnXoHVygs=''
   for reNjaihzARLCxOmPwMvcQSnXoHVygf in reNjaihzARLCxOmPwMvcQSnXoHVyWs.get('image'):
    if reNjaihzARLCxOmPwMvcQSnXoHVygf.get('code')=='CAIM2100':reNjaihzARLCxOmPwMvcQSnXoHVyfl =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf.get('url')
    elif reNjaihzARLCxOmPwMvcQSnXoHVygf.get('code')=='CAIM0400':reNjaihzARLCxOmPwMvcQSnXoHVyfp =reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf.get('url')
    elif reNjaihzARLCxOmPwMvcQSnXoHVygf.get('code')=='CAIM1800':reNjaihzARLCxOmPwMvcQSnXoHVygs=reNjaihzARLCxOmPwMvcQSnXoHVysI.IMG_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVygf.get('url')
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['thumbnail']['poster']=reNjaihzARLCxOmPwMvcQSnXoHVyfl
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['thumbnail']['thumb']=reNjaihzARLCxOmPwMvcQSnXoHVyfl 
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['thumbnail']['clearlogo']=reNjaihzARLCxOmPwMvcQSnXoHVygs
   reNjaihzARLCxOmPwMvcQSnXoHVyIl['saveinfo']['thumbnail']['fanart']=reNjaihzARLCxOmPwMvcQSnXoHVyfp
  return reNjaihzARLCxOmPwMvcQSnXoHVyIl
 def GetEuroChannelList(reNjaihzARLCxOmPwMvcQSnXoHVysI):
  reNjaihzARLCxOmPwMvcQSnXoHVykU=[]
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v2/operator/highlights'
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.GetNoCache(2))}
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVyWT)
   reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if not('result' in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']):return reNjaihzARLCxOmPwMvcQSnXoHVykU,reNjaihzARLCxOmPwMvcQSnXoHVyfG
   reNjaihzARLCxOmPwMvcQSnXoHVyfT=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']
   reNjaihzARLCxOmPwMvcQSnXoHVyWF =reNjaihzARLCxOmPwMvcQSnXoHVysI.Get_Now_Datetime()
   reNjaihzARLCxOmPwMvcQSnXoHVyWk=reNjaihzARLCxOmPwMvcQSnXoHVyWF+datetime.timedelta(days=-1)
   reNjaihzARLCxOmPwMvcQSnXoHVyWk=reNjaihzARLCxOmPwMvcQSnXoHVyWp(reNjaihzARLCxOmPwMvcQSnXoHVyWk.strftime('%Y%m%d'))
   for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVyfT:
    reNjaihzARLCxOmPwMvcQSnXoHVyWD=reNjaihzARLCxOmPwMvcQSnXoHVyWp(reNjaihzARLCxOmPwMvcQSnXoHVykE.get('content').get('banner_title2')[:8])
    if reNjaihzARLCxOmPwMvcQSnXoHVyWk<=reNjaihzARLCxOmPwMvcQSnXoHVyWD:
     reNjaihzARLCxOmPwMvcQSnXoHVygb={'channel':reNjaihzARLCxOmPwMvcQSnXoHVykE.get('content').get('banner_sub_title3'),'title':reNjaihzARLCxOmPwMvcQSnXoHVykE.get('content').get('banner_title'),'subtitle':reNjaihzARLCxOmPwMvcQSnXoHVykE.get('content').get('banner_sub_title2'),}
     reNjaihzARLCxOmPwMvcQSnXoHVykU.append(reNjaihzARLCxOmPwMvcQSnXoHVygb)
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
  return reNjaihzARLCxOmPwMvcQSnXoHVykU
 def Make_DecryptKey(reNjaihzARLCxOmPwMvcQSnXoHVysI,step,mediacode='000',timecode='000'):
  if step=='1':
   reNjaihzARLCxOmPwMvcQSnXoHVyFJ=reNjaihzARLCxOmPwMvcQSnXoHVyKs('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   reNjaihzARLCxOmPwMvcQSnXoHVyFu=reNjaihzARLCxOmPwMvcQSnXoHVyKs('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   reNjaihzARLCxOmPwMvcQSnXoHVyFJ=reNjaihzARLCxOmPwMvcQSnXoHVyKs('kss2lym0kdw1lks3','utf-8')
   reNjaihzARLCxOmPwMvcQSnXoHVyFu=reNjaihzARLCxOmPwMvcQSnXoHVyKs([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return reNjaihzARLCxOmPwMvcQSnXoHVyFJ,reNjaihzARLCxOmPwMvcQSnXoHVyFu
 def DecryptPlaintext(reNjaihzARLCxOmPwMvcQSnXoHVysI,reNjaihzARLCxOmPwMvcQSnXoHVyFd,reNjaihzARLCxOmPwMvcQSnXoHVyFY,reNjaihzARLCxOmPwMvcQSnXoHVyFU):
  reNjaihzARLCxOmPwMvcQSnXoHVyFG=AES.new(reNjaihzARLCxOmPwMvcQSnXoHVyFY,AES.MODE_CBC,reNjaihzARLCxOmPwMvcQSnXoHVyFU,)
  reNjaihzARLCxOmPwMvcQSnXoHVyFT=Padding.unpad(reNjaihzARLCxOmPwMvcQSnXoHVyFG.decrypt(base64.standard_b64decode(reNjaihzARLCxOmPwMvcQSnXoHVyFd)),16)
  return reNjaihzARLCxOmPwMvcQSnXoHVyFT.decode('utf-8')
 def Decrypt_Url(reNjaihzARLCxOmPwMvcQSnXoHVysI,reNjaihzARLCxOmPwMvcQSnXoHVyFd,mediacode,reNjaihzARLCxOmPwMvcQSnXoHVyDW):
  reNjaihzARLCxOmPwMvcQSnXoHVyWf=''
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVyFJ,reNjaihzARLCxOmPwMvcQSnXoHVyFu=reNjaihzARLCxOmPwMvcQSnXoHVysI.Make_DecryptKey('1',mediacode=mediacode,timecode=reNjaihzARLCxOmPwMvcQSnXoHVyDW)
   reNjaihzARLCxOmPwMvcQSnXoHVyWg=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVysI.DecryptPlaintext(reNjaihzARLCxOmPwMvcQSnXoHVyFd,reNjaihzARLCxOmPwMvcQSnXoHVyFJ,reNjaihzARLCxOmPwMvcQSnXoHVyFu))
   reNjaihzARLCxOmPwMvcQSnXoHVyWI =reNjaihzARLCxOmPwMvcQSnXoHVyWg.get('url')
   reNjaihzARLCxOmPwMvcQSnXoHVyFJ,reNjaihzARLCxOmPwMvcQSnXoHVyFu=reNjaihzARLCxOmPwMvcQSnXoHVysI.Make_DecryptKey('2',mediacode=mediacode,timecode=reNjaihzARLCxOmPwMvcQSnXoHVyDW)
   reNjaihzARLCxOmPwMvcQSnXoHVyWf=reNjaihzARLCxOmPwMvcQSnXoHVysI.DecryptPlaintext(reNjaihzARLCxOmPwMvcQSnXoHVyWI,reNjaihzARLCxOmPwMvcQSnXoHVyFJ,reNjaihzARLCxOmPwMvcQSnXoHVyFu)
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
  return reNjaihzARLCxOmPwMvcQSnXoHVyWf
 def GetLiveURL_Test(reNjaihzARLCxOmPwMvcQSnXoHVysI,mediacode,sel_quality):
  reNjaihzARLCxOmPwMvcQSnXoHVykB ={'streaming_url':'','subtitleYn':reNjaihzARLCxOmPwMvcQSnXoHVyWb,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  reNjaihzARLCxOmPwMvcQSnXoHVykG =reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies']['tving_uuid'].split('-')[0] 
  reNjaihzARLCxOmPwMvcQSnXoHVykq =reNjaihzARLCxOmPwMvcQSnXoHVysI.TV['cookies']['tving_uuid'] 
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykl=reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.GetNoCache(1))
   reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v2/media/stream/info' 
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':reNjaihzARLCxOmPwMvcQSnXoHVykq,'deviceInfo':'PC','noCache':reNjaihzARLCxOmPwMvcQSnXoHVykl,}
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVysl=reNjaihzARLCxOmPwMvcQSnXoHVysI.makeDefaultCookies()
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Get',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVysl)
   if reNjaihzARLCxOmPwMvcQSnXoHVyFp.status_code!=200:
    reNjaihzARLCxOmPwMvcQSnXoHVykB['error_msg']='First Step - {} error'.format(reNjaihzARLCxOmPwMvcQSnXoHVyFp.status_code)
    return reNjaihzARLCxOmPwMvcQSnXoHVykB
   reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']['code']=='060':
    for reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVysB in reNjaihzARLCxOmPwMvcQSnXoHVysk.items():
     if reNjaihzARLCxOmPwMvcQSnXoHVysB==sel_quality:
      reNjaihzARLCxOmPwMvcQSnXoHVyDF=reNjaihzARLCxOmPwMvcQSnXoHVyst
   elif reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']['code']!='000':
    reNjaihzARLCxOmPwMvcQSnXoHVykB['error_msg']=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']['message']
    return reNjaihzARLCxOmPwMvcQSnXoHVykB
   else: 
    if not('stream' in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']):return reNjaihzARLCxOmPwMvcQSnXoHVykB
    reNjaihzARLCxOmPwMvcQSnXoHVyDk=[]
    for reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVysB in reNjaihzARLCxOmPwMvcQSnXoHVysk.items():
     for reNjaihzARLCxOmPwMvcQSnXoHVykE in reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['stream']['quality']:
      if reNjaihzARLCxOmPwMvcQSnXoHVykE['active']=='Y' and reNjaihzARLCxOmPwMvcQSnXoHVykE['code']==reNjaihzARLCxOmPwMvcQSnXoHVyst:
       reNjaihzARLCxOmPwMvcQSnXoHVyDk.append({reNjaihzARLCxOmPwMvcQSnXoHVysk.get(reNjaihzARLCxOmPwMvcQSnXoHVykE['code']):reNjaihzARLCxOmPwMvcQSnXoHVykE['code']})
    reNjaihzARLCxOmPwMvcQSnXoHVyDF=reNjaihzARLCxOmPwMvcQSnXoHVysI.CheckQuality(sel_quality,reNjaihzARLCxOmPwMvcQSnXoHVyDk)
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
   reNjaihzARLCxOmPwMvcQSnXoHVykB['error_msg']='First Step - except error'
   return reNjaihzARLCxOmPwMvcQSnXoHVykB
  try:
   reNjaihzARLCxOmPwMvcQSnXoHVykl=reNjaihzARLCxOmPwMvcQSnXoHVyWE(reNjaihzARLCxOmPwMvcQSnXoHVysI.GetNoCache(1))
   reNjaihzARLCxOmPwMvcQSnXoHVykJ ='/v3/media/stream/info'
   reNjaihzARLCxOmPwMvcQSnXoHVyDs=reNjaihzARLCxOmPwMvcQSnXoHVysI.GetDefaultParams()
   reNjaihzARLCxOmPwMvcQSnXoHVykT={'mediaCode':mediacode,'deviceId':reNjaihzARLCxOmPwMvcQSnXoHVykG,'uuid':reNjaihzARLCxOmPwMvcQSnXoHVykq,'deviceInfo':'PC_Chrome','streamCode':reNjaihzARLCxOmPwMvcQSnXoHVyDF,'noCache':reNjaihzARLCxOmPwMvcQSnXoHVykl,'callingFrom':'HTML5','model':reNjaihzARLCxOmPwMvcQSnXoHVysI.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   reNjaihzARLCxOmPwMvcQSnXoHVyDs.update(reNjaihzARLCxOmPwMvcQSnXoHVykT)
   reNjaihzARLCxOmPwMvcQSnXoHVyFB=reNjaihzARLCxOmPwMvcQSnXoHVysI.API_DOMAIN+reNjaihzARLCxOmPwMvcQSnXoHVykJ
   reNjaihzARLCxOmPwMvcQSnXoHVysl=reNjaihzARLCxOmPwMvcQSnXoHVysI.makeDefaultCookies()
   reNjaihzARLCxOmPwMvcQSnXoHVyFp=reNjaihzARLCxOmPwMvcQSnXoHVysI.callRequestCookies('Post',reNjaihzARLCxOmPwMvcQSnXoHVyFB,payload=reNjaihzARLCxOmPwMvcQSnXoHVyWT,params=reNjaihzARLCxOmPwMvcQSnXoHVyDs,headers=reNjaihzARLCxOmPwMvcQSnXoHVyWT,cookies=reNjaihzARLCxOmPwMvcQSnXoHVysl,redirects=reNjaihzARLCxOmPwMvcQSnXoHVyWB)
   reNjaihzARLCxOmPwMvcQSnXoHVykb=json.loads(reNjaihzARLCxOmPwMvcQSnXoHVyFp.text)
   if reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']['code']!='000':
    reNjaihzARLCxOmPwMvcQSnXoHVykB['error_msg']=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['result']['message']
    return reNjaihzARLCxOmPwMvcQSnXoHVykB
   reNjaihzARLCxOmPwMvcQSnXoHVyDf=reNjaihzARLCxOmPwMvcQSnXoHVykb['body']['stream']
   if reNjaihzARLCxOmPwMvcQSnXoHVyDf['drm_yn']=='Y':
    reNjaihzARLCxOmPwMvcQSnXoHVyDg=reNjaihzARLCxOmPwMvcQSnXoHVyDf['playback']['drm']['widevine']
    for reNjaihzARLCxOmPwMvcQSnXoHVyDI in reNjaihzARLCxOmPwMvcQSnXoHVyDf['playback']['drm']['license']['drm_license_data']:
     if reNjaihzARLCxOmPwMvcQSnXoHVyDI['drm_type']=='Widevine':
      reNjaihzARLCxOmPwMvcQSnXoHVykB['drm_server_url'] =reNjaihzARLCxOmPwMvcQSnXoHVyDI['drm_server_url']
      reNjaihzARLCxOmPwMvcQSnXoHVykB['drm_header_key'] =reNjaihzARLCxOmPwMvcQSnXoHVyDI['drm_header_key']
      reNjaihzARLCxOmPwMvcQSnXoHVykB['drm_header_value']=reNjaihzARLCxOmPwMvcQSnXoHVyDI['drm_header_value']
      break
   else:
    reNjaihzARLCxOmPwMvcQSnXoHVyDg=reNjaihzARLCxOmPwMvcQSnXoHVyDf['playback']['non_drm']
  except reNjaihzARLCxOmPwMvcQSnXoHVyKF as exception:
   reNjaihzARLCxOmPwMvcQSnXoHVyWU(exception)
   reNjaihzARLCxOmPwMvcQSnXoHVykB['error_msg']='Second Step - except error'
   return reNjaihzARLCxOmPwMvcQSnXoHVykB
  reNjaihzARLCxOmPwMvcQSnXoHVyDW=reNjaihzARLCxOmPwMvcQSnXoHVykl
  reNjaihzARLCxOmPwMvcQSnXoHVyDg=reNjaihzARLCxOmPwMvcQSnXoHVyDg.split('|')[1]
  reNjaihzARLCxOmPwMvcQSnXoHVyDg=reNjaihzARLCxOmPwMvcQSnXoHVysI.Decrypt_Url(reNjaihzARLCxOmPwMvcQSnXoHVyDg,mediacode,reNjaihzARLCxOmPwMvcQSnXoHVyDW)
  reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url']=reNjaihzARLCxOmPwMvcQSnXoHVyDg
  reNjaihzARLCxOmPwMvcQSnXoHVyWK =reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url'].find('Policy=')
  if reNjaihzARLCxOmPwMvcQSnXoHVyWK!=-1:
   reNjaihzARLCxOmPwMvcQSnXoHVyWJ =reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url'].split('?')[0]
   reNjaihzARLCxOmPwMvcQSnXoHVyWu=reNjaihzARLCxOmPwMvcQSnXoHVyKk(urllib.parse.parse_qsl(urllib.parse.urlsplit(reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url']).query))
   reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url']='{}&CloudFront-Policy={}'.format(reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url'],reNjaihzARLCxOmPwMvcQSnXoHVyWu['Policy'])
   reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url']='{}&CloudFront-Signature={}'.format(reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url'],reNjaihzARLCxOmPwMvcQSnXoHVyWu['Signature'])
   reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url'],reNjaihzARLCxOmPwMvcQSnXoHVyWu['Key-Pair-Id'])
  reNjaihzARLCxOmPwMvcQSnXoHVyWY=['_tving_token','accessToken','authToken',]
  for reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVysB in reNjaihzARLCxOmPwMvcQSnXoHVysl.items():
   if reNjaihzARLCxOmPwMvcQSnXoHVyst in reNjaihzARLCxOmPwMvcQSnXoHVyWY:
    reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url']='{}&{}={}'.format(reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url'],reNjaihzARLCxOmPwMvcQSnXoHVyst,reNjaihzARLCxOmPwMvcQSnXoHVysB)
  reNjaihzARLCxOmPwMvcQSnXoHVyWU(reNjaihzARLCxOmPwMvcQSnXoHVykB['streaming_url'])
  return reNjaihzARLCxOmPwMvcQSnXoHVykB
# Created by pyminifier (https://github.com/liftoff/pyminifier)
