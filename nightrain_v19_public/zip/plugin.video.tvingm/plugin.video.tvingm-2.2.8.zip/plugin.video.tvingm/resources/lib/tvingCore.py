__author__="NightRain"
EoYtfvMCicjlUsSLqAIQzTpdrFWNJG=object
EoYtfvMCicjlUsSLqAIQzTpdrFWNJP=None
EoYtfvMCicjlUsSLqAIQzTpdrFWNky=False
EoYtfvMCicjlUsSLqAIQzTpdrFWNkD=int
EoYtfvMCicjlUsSLqAIQzTpdrFWNkK=range
EoYtfvMCicjlUsSLqAIQzTpdrFWNkO=True
EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ=Exception
EoYtfvMCicjlUsSLqAIQzTpdrFWNkX=print
EoYtfvMCicjlUsSLqAIQzTpdrFWNke=str
EoYtfvMCicjlUsSLqAIQzTpdrFWNkB=list
EoYtfvMCicjlUsSLqAIQzTpdrFWNkR=len
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
EoYtfvMCicjlUsSLqAIQzTpdrFWNyK={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
EoYtfvMCicjlUsSLqAIQzTpdrFWNyO ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class EoYtfvMCicjlUsSLqAIQzTpdrFWNyD(EoYtfvMCicjlUsSLqAIQzTpdrFWNJG):
 def __init__(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_TOKEN =''
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.POC_USERINFO =''
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_UUID ='-'
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_MAINTOKEN=''
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVIGN_COOKIEKEY=''
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_LOCKKEY =''
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.NETWORKCODE ='CSND0900'
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.OSCODE ='CSOD0900' 
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TELECODE ='CSCD0900'
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.SCREENCODE ='CSSD0100'
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.LIVE_LIMIT =23
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.VOD_LIMIT =20
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.EPISODE_LIMIT =30 
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.SEARCH_LIMIT =30 
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.MOVIE_LIMIT =18
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.API_DOMAIN ='https://api.tving.com'
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN ='https://image.tving.com'
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.SEARCH_DOMAIN ='https://search.tving.com'
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.LOGIN_DOMAIN ='https://user.tving.com'
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.URL_DOMAIN ='https://www.tving.com'
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.MOVIE_LITE =['2610061','2610161','261062']
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.DEFAULT_HEADER ={'user-agent':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.USER_AGENT}
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,jobtype,EoYtfvMCicjlUsSLqAIQzTpdrFWNDx,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,redirects=EoYtfvMCicjlUsSLqAIQzTpdrFWNky):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyk=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.DEFAULT_HEADER
  if headers:EoYtfvMCicjlUsSLqAIQzTpdrFWNyk.update(headers)
  if jobtype=='Get':
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyX=requests.get(EoYtfvMCicjlUsSLqAIQzTpdrFWNDx,params=params,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNyk,cookies=cookies,allow_redirects=redirects)
  else:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyX=requests.post(EoYtfvMCicjlUsSLqAIQzTpdrFWNDx,data=payload,params=params,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNyk,cookies=cookies,allow_redirects=redirects)
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNyX
 def makeDefaultCookies(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,vToken=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,vUserinfo=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNye={}
  EoYtfvMCicjlUsSLqAIQzTpdrFWNye['_tving_token']=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_TOKEN if vToken==EoYtfvMCicjlUsSLqAIQzTpdrFWNJP else vToken
  EoYtfvMCicjlUsSLqAIQzTpdrFWNye['POC_USERINFO']=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.POC_USERINFO if vToken==EoYtfvMCicjlUsSLqAIQzTpdrFWNJP else vUserinfo
  if EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_MAINTOKEN!='':EoYtfvMCicjlUsSLqAIQzTpdrFWNye[EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GLOBAL_COOKIENM['tv_maintoken']]=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_MAINTOKEN
  if EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVIGN_COOKIEKEY!='':EoYtfvMCicjlUsSLqAIQzTpdrFWNye[EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GLOBAL_COOKIENM['tv_cookiekey']]=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVIGN_COOKIEKEY
  if EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_LOCKKEY !='':EoYtfvMCicjlUsSLqAIQzTpdrFWNye[EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GLOBAL_COOKIENM['tv_lockkey']] =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_LOCKKEY
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNye
 def getDeviceStr(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyB=[]
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyB.append('Windows') 
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyB.append('Chrome') 
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyB.append('ko-KR') 
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyB.append('undefined') 
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyB.append('24') 
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyB.append(u'한국 표준시')
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyB.append('undefined') 
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyB.append('undefined') 
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyB.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyR=''
  for EoYtfvMCicjlUsSLqAIQzTpdrFWNyH in EoYtfvMCicjlUsSLqAIQzTpdrFWNyB:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyR+=EoYtfvMCicjlUsSLqAIQzTpdrFWNyH+'|'
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNyR
 def SaveCredential(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,EoYtfvMCicjlUsSLqAIQzTpdrFWNyu):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_TOKEN =EoYtfvMCicjlUsSLqAIQzTpdrFWNyu.get('tving_token')
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.POC_USERINFO =EoYtfvMCicjlUsSLqAIQzTpdrFWNyu.get('poc_userinfo')
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_UUID =EoYtfvMCicjlUsSLqAIQzTpdrFWNyu.get('tving_uuid')
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_MAINTOKEN=EoYtfvMCicjlUsSLqAIQzTpdrFWNyu.get('tving_maintoken')
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVIGN_COOKIEKEY=EoYtfvMCicjlUsSLqAIQzTpdrFWNyu.get('tving_cookiekey')
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_LOCKKEY =EoYtfvMCicjlUsSLqAIQzTpdrFWNyu.get('tving_lockkey')
 def LoadCredential(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyu={'tving_token':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_TOKEN,'poc_userinfo':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.POC_USERINFO,'tving_uuid':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_UUID,'tving_maintoken':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_MAINTOKEN,'tving_cookiekey':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVIGN_COOKIEKEY,'tving_lockkey':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_LOCKKEY}
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNyu
 def GetDefaultParams(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyw={'apiKey':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.APIKEY,'networkCode':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.NETWORKCODE,'osCode':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.OSCODE,'teleCode':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TELECODE,'screenCode':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.SCREENCODE}
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNyw
 def GetNoCache(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,timetype=1):
  if timetype==1:
   return EoYtfvMCicjlUsSLqAIQzTpdrFWNkD(time.time())
  else:
   return EoYtfvMCicjlUsSLqAIQzTpdrFWNkD(time.time()*1000)
 def GetUniqueid(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyx=[0 for i in EoYtfvMCicjlUsSLqAIQzTpdrFWNkK(256)]
  for i in EoYtfvMCicjlUsSLqAIQzTpdrFWNkK(256):
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyx[i]='%02x'%(i)
  EoYtfvMCicjlUsSLqAIQzTpdrFWNym=EoYtfvMCicjlUsSLqAIQzTpdrFWNkD(4294967295*random.random())|0
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyV=EoYtfvMCicjlUsSLqAIQzTpdrFWNyx[255&EoYtfvMCicjlUsSLqAIQzTpdrFWNym]+EoYtfvMCicjlUsSLqAIQzTpdrFWNyx[EoYtfvMCicjlUsSLqAIQzTpdrFWNym>>8&255]+EoYtfvMCicjlUsSLqAIQzTpdrFWNyx[EoYtfvMCicjlUsSLqAIQzTpdrFWNym>>16&255]+EoYtfvMCicjlUsSLqAIQzTpdrFWNyx[EoYtfvMCicjlUsSLqAIQzTpdrFWNym>>24&255]
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNyV
 def GetCredential(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,user_id,user_pw,login_type,user_pf):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyg=EoYtfvMCicjlUsSLqAIQzTpdrFWNky
  EoYtfvMCicjlUsSLqAIQzTpdrFWNya=EoYtfvMCicjlUsSLqAIQzTpdrFWNDy=EoYtfvMCicjlUsSLqAIQzTpdrFWNDK=EoYtfvMCicjlUsSLqAIQzTpdrFWNDO=EoYtfvMCicjlUsSLqAIQzTpdrFWNDJ='' 
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyh ='-'
  try:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyn=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyb={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyG=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.callRequestCookies('Post',EoYtfvMCicjlUsSLqAIQzTpdrFWNyn,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNyb,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP)
   for EoYtfvMCicjlUsSLqAIQzTpdrFWNyP in EoYtfvMCicjlUsSLqAIQzTpdrFWNyG.cookies:
    if EoYtfvMCicjlUsSLqAIQzTpdrFWNyP.name=='_tving_token':
     EoYtfvMCicjlUsSLqAIQzTpdrFWNDy=EoYtfvMCicjlUsSLqAIQzTpdrFWNyP.value
    elif EoYtfvMCicjlUsSLqAIQzTpdrFWNyP.name=='POC_USERINFO':
     EoYtfvMCicjlUsSLqAIQzTpdrFWNDK=EoYtfvMCicjlUsSLqAIQzTpdrFWNyP.value
   if EoYtfvMCicjlUsSLqAIQzTpdrFWNDy=='':return EoYtfvMCicjlUsSLqAIQzTpdrFWNyg
   EoYtfvMCicjlUsSLqAIQzTpdrFWNya=EoYtfvMCicjlUsSLqAIQzTpdrFWNDy
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDy,EoYtfvMCicjlUsSLqAIQzTpdrFWNDO,EoYtfvMCicjlUsSLqAIQzTpdrFWNDJ=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetProfileToken(EoYtfvMCicjlUsSLqAIQzTpdrFWNDy,EoYtfvMCicjlUsSLqAIQzTpdrFWNDK,user_pf)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyg=EoYtfvMCicjlUsSLqAIQzTpdrFWNkO
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyh =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetDeviceList(EoYtfvMCicjlUsSLqAIQzTpdrFWNDy,EoYtfvMCicjlUsSLqAIQzTpdrFWNDK)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyh =EoYtfvMCicjlUsSLqAIQzTpdrFWNyh+'-'+EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetUniqueid()
  except EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ as exception:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNya=EoYtfvMCicjlUsSLqAIQzTpdrFWNDy=EoYtfvMCicjlUsSLqAIQzTpdrFWNDK=EoYtfvMCicjlUsSLqAIQzTpdrFWNDO=EoYtfvMCicjlUsSLqAIQzTpdrFWNDJ=''
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyh='-'
   EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(exception)
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyu={'tving_token':EoYtfvMCicjlUsSLqAIQzTpdrFWNDy,'poc_userinfo':EoYtfvMCicjlUsSLqAIQzTpdrFWNDK,'tving_uuid':EoYtfvMCicjlUsSLqAIQzTpdrFWNyh,'tving_maintoken':EoYtfvMCicjlUsSLqAIQzTpdrFWNya,'tving_cookiekey':EoYtfvMCicjlUsSLqAIQzTpdrFWNDO,'tving_lockkey':EoYtfvMCicjlUsSLqAIQzTpdrFWNDJ}
  EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.SaveCredential(EoYtfvMCicjlUsSLqAIQzTpdrFWNyu)
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNyg
 def Get_Now_Datetime(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,mediacode,sel_quality,stype,pvrmode='-'):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNDX=''
  EoYtfvMCicjlUsSLqAIQzTpdrFWNDe=''
  EoYtfvMCicjlUsSLqAIQzTpdrFWNDB =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_UUID.split('-')[0] 
  EoYtfvMCicjlUsSLqAIQzTpdrFWNDR =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.TVING_UUID 
  if mediacode=='C01345':
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDX='http://ocn-mcdn.tving.com/ocn/live5000.smil/playlist.m3u8?Policy=eyJTdGF0ZW1lbnQiOiBbeyJSZXNvdXJjZSI6Imh0dHA6Ly8qIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNjEwODMwODAwfSwiSXBBZGRyZXNzIjp7IkFXUzpTb3VyY2VJcCI6IjAuMC4wLjAvMCJ9fX1dfQ__&Signature=eqJMOA5c~hIlgUVIDOtLCCfKXnNO0XHex3uQVQE87ZfuutuH2hqAgddlijKNWDz2Qrg5ScRkuXuU-7QQoj4QFSPPjyvwJSSrrZtNNVxU8xERXywdUKUwQGfDvl78F4rhS7WP-O1Q86KnLwif9QW0GPRK~n8ceOITlYq22rVLqp~EKwmoGQ3cvw01TMBFRInvobRtXR-zGyMZCx9MDgeHMRay0U9Ibp7nUPb3~T~set~W3so1ovUnF0iLuQpuarXQA3QIBy25O24NVbwalTtzjPoULkpEHeuVsMx-ACom3MTM65kB5TKJNIx19sdlAFQIII7n39FpWgSOO6A8jvu~rA__&Key-Pair-Id=APKAIXCIJCFRGOUEZDWA'
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    EoYtfvMCicjlUsSLqAIQzTpdrFWNDH ='/v2a/media/stream/info' 
    EoYtfvMCicjlUsSLqAIQzTpdrFWNDu=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetDefaultParams()
    EoYtfvMCicjlUsSLqAIQzTpdrFWNDw={'info':'N','mediaCode':mediacode,'noCache':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':EoYtfvMCicjlUsSLqAIQzTpdrFWNDB,'uuid':EoYtfvMCicjlUsSLqAIQzTpdrFWNDR,'deviceInfo':'PC','wm':'Y'}
    EoYtfvMCicjlUsSLqAIQzTpdrFWNDu.update(EoYtfvMCicjlUsSLqAIQzTpdrFWNDw)
    EoYtfvMCicjlUsSLqAIQzTpdrFWNDx=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.API_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDH
    EoYtfvMCicjlUsSLqAIQzTpdrFWNye=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.makeDefaultCookies()
    EoYtfvMCicjlUsSLqAIQzTpdrFWNyG=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.callRequestCookies('Get',EoYtfvMCicjlUsSLqAIQzTpdrFWNDx,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNDu,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNye)
    EoYtfvMCicjlUsSLqAIQzTpdrFWNDm=json.loads(EoYtfvMCicjlUsSLqAIQzTpdrFWNyG.text)
    if not('stream' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']):return EoYtfvMCicjlUsSLqAIQzTpdrFWNDX,EoYtfvMCicjlUsSLqAIQzTpdrFWNDe 
    EoYtfvMCicjlUsSLqAIQzTpdrFWNDV=EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']['stream']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNDg=EoYtfvMCicjlUsSLqAIQzTpdrFWNDV['quality']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNDa=[]
    for EoYtfvMCicjlUsSLqAIQzTpdrFWNDh in EoYtfvMCicjlUsSLqAIQzTpdrFWNDg:
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['active']=='Y':
      EoYtfvMCicjlUsSLqAIQzTpdrFWNDa.append({EoYtfvMCicjlUsSLqAIQzTpdrFWNyK.get(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['code']):EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['code']})
    EoYtfvMCicjlUsSLqAIQzTpdrFWNDn=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.CheckQuality(sel_quality,EoYtfvMCicjlUsSLqAIQzTpdrFWNDa)
   else:
    for EoYtfvMCicjlUsSLqAIQzTpdrFWNDb,EoYtfvMCicjlUsSLqAIQzTpdrFWNKX in EoYtfvMCicjlUsSLqAIQzTpdrFWNyK.items():
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNKX==sel_quality:
      EoYtfvMCicjlUsSLqAIQzTpdrFWNDn=EoYtfvMCicjlUsSLqAIQzTpdrFWNDb
  except EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ as exception:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(exception)
   for EoYtfvMCicjlUsSLqAIQzTpdrFWNDb,EoYtfvMCicjlUsSLqAIQzTpdrFWNKX in EoYtfvMCicjlUsSLqAIQzTpdrFWNyK.items():
    if EoYtfvMCicjlUsSLqAIQzTpdrFWNKX==sel_quality:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNDn=EoYtfvMCicjlUsSLqAIQzTpdrFWNDb
   return EoYtfvMCicjlUsSLqAIQzTpdrFWNDX,EoYtfvMCicjlUsSLqAIQzTpdrFWNDe
  EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(EoYtfvMCicjlUsSLqAIQzTpdrFWNDn)
  try:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDH ='/streaming/info'
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDu=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetDefaultParams()
   if stype=='onair':EoYtfvMCicjlUsSLqAIQzTpdrFWNDu['osCode']='CSOD0400' 
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDG={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDP=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.makeOocUrl(EoYtfvMCicjlUsSLqAIQzTpdrFWNDG)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNKy=urllib.parse.quote(EoYtfvMCicjlUsSLqAIQzTpdrFWNDP)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDw={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':EoYtfvMCicjlUsSLqAIQzTpdrFWNDn,'adReq':'adproxy','ooc':EoYtfvMCicjlUsSLqAIQzTpdrFWNDP,'deviceId':EoYtfvMCicjlUsSLqAIQzTpdrFWNDB,'uuid':EoYtfvMCicjlUsSLqAIQzTpdrFWNDR,'deviceInfo':'PC'}
   EoYtfvMCicjlUsSLqAIQzTpdrFWNKD =EoYtfvMCicjlUsSLqAIQzTpdrFWNDu
   EoYtfvMCicjlUsSLqAIQzTpdrFWNKD.update(EoYtfvMCicjlUsSLqAIQzTpdrFWNDw)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDx=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.URL_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDH
   EoYtfvMCicjlUsSLqAIQzTpdrFWNKO={'origin':'https://www.tving.com'}
   if stype=='onair':EoYtfvMCicjlUsSLqAIQzTpdrFWNKO['Referer']='https://www.tving.com/live/player/'+mediacode
   else: EoYtfvMCicjlUsSLqAIQzTpdrFWNKO['Referer']='https://www.tving.com/vod/player/'+mediacode
   EoYtfvMCicjlUsSLqAIQzTpdrFWNye=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.makeDefaultCookies()
   EoYtfvMCicjlUsSLqAIQzTpdrFWNye['onClickEvent2']=EoYtfvMCicjlUsSLqAIQzTpdrFWNKy
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyG=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.callRequestCookies('Post',EoYtfvMCicjlUsSLqAIQzTpdrFWNDx,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNKD,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNKO,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNye,redirects=EoYtfvMCicjlUsSLqAIQzTpdrFWNky)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDm=json.loads(EoYtfvMCicjlUsSLqAIQzTpdrFWNyG.text)
   if 'drm_license_assertion' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['stream']:
    EoYtfvMCicjlUsSLqAIQzTpdrFWNDe =EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['stream']['drm_license_assertion']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNDX=EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['stream']['broadcast']):return EoYtfvMCicjlUsSLqAIQzTpdrFWNDX,EoYtfvMCicjlUsSLqAIQzTpdrFWNDe
    EoYtfvMCicjlUsSLqAIQzTpdrFWNDX=EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['stream']['broadcast']['broad_url']
  except EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ as exception:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(exception)
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNDX,EoYtfvMCicjlUsSLqAIQzTpdrFWNDe
 def CheckQuality(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,sel_qt,EoYtfvMCicjlUsSLqAIQzTpdrFWNDa):
  for EoYtfvMCicjlUsSLqAIQzTpdrFWNKJ in EoYtfvMCicjlUsSLqAIQzTpdrFWNDa:
   if sel_qt>=EoYtfvMCicjlUsSLqAIQzTpdrFWNkB(EoYtfvMCicjlUsSLqAIQzTpdrFWNKJ)[0]:return EoYtfvMCicjlUsSLqAIQzTpdrFWNKJ.get(EoYtfvMCicjlUsSLqAIQzTpdrFWNkB(EoYtfvMCicjlUsSLqAIQzTpdrFWNKJ)[0])
   EoYtfvMCicjlUsSLqAIQzTpdrFWNKk=EoYtfvMCicjlUsSLqAIQzTpdrFWNKJ.get(EoYtfvMCicjlUsSLqAIQzTpdrFWNkB(EoYtfvMCicjlUsSLqAIQzTpdrFWNKJ)[0])
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNKk
 def makeOocUrl(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,EoYtfvMCicjlUsSLqAIQzTpdrFWNDG):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNDx=''
  for EoYtfvMCicjlUsSLqAIQzTpdrFWNDb,EoYtfvMCicjlUsSLqAIQzTpdrFWNKX in EoYtfvMCicjlUsSLqAIQzTpdrFWNDG.items():
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDx+="%s=%s^"%(EoYtfvMCicjlUsSLqAIQzTpdrFWNDb,EoYtfvMCicjlUsSLqAIQzTpdrFWNKX)
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNDx
 def GetLiveChannelList(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,stype,page_int):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKe=[]
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKB=EoYtfvMCicjlUsSLqAIQzTpdrFWNky
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKR=EoYtfvMCicjlUsSLqAIQzTpdrFWNky
  try:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDH ='/v2/media/lives'
   if stype=='onair': 
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKH='CPCS0100,CPCS0400'
   else:
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKH='CPCS0300'
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDu=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetDefaultParams()
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDw={'pageNo':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(page_int),'pageSize':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':EoYtfvMCicjlUsSLqAIQzTpdrFWNKH,'_':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetNoCache(2))}
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDu.update(EoYtfvMCicjlUsSLqAIQzTpdrFWNDw)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDx=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.API_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDH
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyG=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.callRequestCookies('Get',EoYtfvMCicjlUsSLqAIQzTpdrFWNDx,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNDu,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDm=json.loads(EoYtfvMCicjlUsSLqAIQzTpdrFWNyG.text)
   if not('result' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']):return EoYtfvMCicjlUsSLqAIQzTpdrFWNKe,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
   EoYtfvMCicjlUsSLqAIQzTpdrFWNKu=EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']['result']
   for EoYtfvMCicjlUsSLqAIQzTpdrFWNDh in EoYtfvMCicjlUsSLqAIQzTpdrFWNKu:
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKw=EoYtfvMCicjlUsSLqAIQzTpdrFWNKV=EoYtfvMCicjlUsSLqAIQzTpdrFWNKg=''
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKx=EoYtfvMCicjlUsSLqAIQzTpdrFWNOu=''
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKm=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['live_code']
    if EoYtfvMCicjlUsSLqAIQzTpdrFWNKm=='C01345':EoYtfvMCicjlUsSLqAIQzTpdrFWNKR=EoYtfvMCicjlUsSLqAIQzTpdrFWNkO 
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKw =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['channel']['name']['ko']
    if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['episode']!=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKV =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['program']['name']['ko']
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKV =EoYtfvMCicjlUsSLqAIQzTpdrFWNKV+', '+EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['episode']['frequency'])+'회'
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKg=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['episode']['synopsis']['ko']
    else:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKV =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['program']['name']['ko']
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKg=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['program']['synopsis']['ko']
    try: 
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =''
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKh =''
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKn=''
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKb =''
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKG =''
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKP =''
     for EoYtfvMCicjlUsSLqAIQzTpdrFWNOy in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['program']['image']:
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP0900':EoYtfvMCicjlUsSLqAIQzTpdrFWNKh =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
      elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP1800':EoYtfvMCicjlUsSLqAIQzTpdrFWNKn=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
      elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP2000':EoYtfvMCicjlUsSLqAIQzTpdrFWNKb =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
      elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP1900':EoYtfvMCicjlUsSLqAIQzTpdrFWNKG =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
      elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP0200':EoYtfvMCicjlUsSLqAIQzTpdrFWNKP =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
      elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP0500':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
      elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP0800':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNKa=='':
      for EoYtfvMCicjlUsSLqAIQzTpdrFWNOy in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['channel']['image']:
       if EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIC0400':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
       elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIC1400':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
       elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIC1900':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
    except:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJP
    try:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOD =[]
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOK=[]
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ =[]
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOk=''
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOX=''
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOe=''
     for EoYtfvMCicjlUsSLqAIQzTpdrFWNOB in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('schedule').get('program').get('actor'):
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNOB!='' and EoYtfvMCicjlUsSLqAIQzTpdrFWNOB!=u'없음':EoYtfvMCicjlUsSLqAIQzTpdrFWNOD.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOB)
     for EoYtfvMCicjlUsSLqAIQzTpdrFWNOR in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('schedule').get('program').get('director'):
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNOR!='' and EoYtfvMCicjlUsSLqAIQzTpdrFWNOR!='-' and EoYtfvMCicjlUsSLqAIQzTpdrFWNOR!=u'없음':EoYtfvMCicjlUsSLqAIQzTpdrFWNOK.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOR)
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('schedule').get('program').get('category1_name').get('ko')!='':
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['program']['category1_name']['ko'])
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('schedule').get('program').get('category2_name').get('ko')!='':
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['program']['category2_name']['ko'])
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('schedule').get('program').get('product_year'):EoYtfvMCicjlUsSLqAIQzTpdrFWNOk=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['program']['product_year']
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('schedule').get('program').get('grade_code') :EoYtfvMCicjlUsSLqAIQzTpdrFWNOX= EoYtfvMCicjlUsSLqAIQzTpdrFWNyO.get(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['program']['grade_code'])
     if 'broad_dt' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('schedule').get('program'):
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOH =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('schedule').get('program').get('broad_dt')
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOe='%s-%s-%s'%(EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[:4],EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[4:6],EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[6:])
    except:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJP
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKx=EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['broadcast_start_time'])[8:12]
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOu =EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['schedule']['broadcast_end_time'])[8:12]
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOw={'channel':EoYtfvMCicjlUsSLqAIQzTpdrFWNKw,'title':EoYtfvMCicjlUsSLqAIQzTpdrFWNKV,'mediacode':EoYtfvMCicjlUsSLqAIQzTpdrFWNKm,'thumbnail':{'poster':EoYtfvMCicjlUsSLqAIQzTpdrFWNKh,'thumb':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa,'clearlogo':EoYtfvMCicjlUsSLqAIQzTpdrFWNKn,'icon':EoYtfvMCicjlUsSLqAIQzTpdrFWNKb,'fanart':EoYtfvMCicjlUsSLqAIQzTpdrFWNKP},'synopsis':EoYtfvMCicjlUsSLqAIQzTpdrFWNKg,'channelepg':' [%s:%s ~ %s:%s]'%(EoYtfvMCicjlUsSLqAIQzTpdrFWNKx[0:2],EoYtfvMCicjlUsSLqAIQzTpdrFWNKx[2:],EoYtfvMCicjlUsSLqAIQzTpdrFWNOu[0:2],EoYtfvMCicjlUsSLqAIQzTpdrFWNOu[2:]),'cast':EoYtfvMCicjlUsSLqAIQzTpdrFWNOD,'director':EoYtfvMCicjlUsSLqAIQzTpdrFWNOK,'info_genre':EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ,'year':EoYtfvMCicjlUsSLqAIQzTpdrFWNOk,'mpaa':EoYtfvMCicjlUsSLqAIQzTpdrFWNOX,'premiered':EoYtfvMCicjlUsSLqAIQzTpdrFWNOe}
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKe.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOw)
   if EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']['has_more']=='Y':
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKB=EoYtfvMCicjlUsSLqAIQzTpdrFWNkO
   else:
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOw={'channel':'OCN Original','title':'temp','mediacode':'C01345','thumbnail':'http://image.tving.com/upload/cms/caic/CAIC0400/C01345.png','cast':[],'director':[]}
  except EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ as exception:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(exception)
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNKe,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
 def GetProgramList(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,genre,orderby,page_int,genreCode='all'):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKe=[]
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKB=EoYtfvMCicjlUsSLqAIQzTpdrFWNky
  try:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDH ='/v2/media/episodes'
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDu=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetDefaultParams()
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDw={'pageNo':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(page_int),'pageSize':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetNoCache(2))}
   if genre !='all':EoYtfvMCicjlUsSLqAIQzTpdrFWNDw['categoryCode']=genre
   if genreCode!='all':EoYtfvMCicjlUsSLqAIQzTpdrFWNDw['genreCode'] =genreCode 
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDu.update(EoYtfvMCicjlUsSLqAIQzTpdrFWNDw)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDx=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.API_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDH
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyG=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.callRequestCookies('Get',EoYtfvMCicjlUsSLqAIQzTpdrFWNDx,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNDu,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDm=json.loads(EoYtfvMCicjlUsSLqAIQzTpdrFWNyG.text)
   if not('result' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']):return EoYtfvMCicjlUsSLqAIQzTpdrFWNKe,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
   EoYtfvMCicjlUsSLqAIQzTpdrFWNKu=EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']['result']
   for EoYtfvMCicjlUsSLqAIQzTpdrFWNDh in EoYtfvMCicjlUsSLqAIQzTpdrFWNKu:
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOx=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['program']['code']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKV =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['program']['name']['ko']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOX =EoYtfvMCicjlUsSLqAIQzTpdrFWNyO.get(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['program'].get('grade_code'))
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKh =''
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =''
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKn=''
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKb =''
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKG =''
    for EoYtfvMCicjlUsSLqAIQzTpdrFWNOy in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['program']['image']:
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP0900':EoYtfvMCicjlUsSLqAIQzTpdrFWNKh =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
     elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP0200':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
     elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP1800':EoYtfvMCicjlUsSLqAIQzTpdrFWNKn=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
     elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP2000':EoYtfvMCicjlUsSLqAIQzTpdrFWNKb =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
     elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP1900':EoYtfvMCicjlUsSLqAIQzTpdrFWNKG =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKg =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['program']['synopsis']['ko']
    try:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOm=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['channel']['name']['ko']
    except:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOm=''
    try:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOD =[]
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOK=[]
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ =[]
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOk =''
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOe=''
     for EoYtfvMCicjlUsSLqAIQzTpdrFWNOB in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('program').get('actor'):
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNOB!='' and EoYtfvMCicjlUsSLqAIQzTpdrFWNOB!='-' and EoYtfvMCicjlUsSLqAIQzTpdrFWNOB!=u'없음':EoYtfvMCicjlUsSLqAIQzTpdrFWNOD.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOB)
     for EoYtfvMCicjlUsSLqAIQzTpdrFWNOR in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('program').get('director'):
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNOR!='' and EoYtfvMCicjlUsSLqAIQzTpdrFWNOR!='-' and EoYtfvMCicjlUsSLqAIQzTpdrFWNOR!=u'없음':EoYtfvMCicjlUsSLqAIQzTpdrFWNOK.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOR)
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('program').get('category1_name').get('ko')!='':
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['program']['category1_name']['ko'])
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('program').get('category2_name').get('ko')!='':
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['program']['category2_name']['ko'])
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('program').get('product_year'):EoYtfvMCicjlUsSLqAIQzTpdrFWNOk=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['program']['product_year']
     if 'broad_dt' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('program'):
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOH =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('program').get('broad_dt')
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOe='%s-%s-%s'%(EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[:4],EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[4:6],EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[6:])
    except:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJP
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOw={'program':EoYtfvMCicjlUsSLqAIQzTpdrFWNOx,'title':EoYtfvMCicjlUsSLqAIQzTpdrFWNKV,'thumbnail':{'poster':EoYtfvMCicjlUsSLqAIQzTpdrFWNKh,'thumb':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa,'clearlogo':EoYtfvMCicjlUsSLqAIQzTpdrFWNKn,'icon':EoYtfvMCicjlUsSLqAIQzTpdrFWNKb,'banner':EoYtfvMCicjlUsSLqAIQzTpdrFWNKG,'fanart':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa},'synopsis':EoYtfvMCicjlUsSLqAIQzTpdrFWNKg,'channel':EoYtfvMCicjlUsSLqAIQzTpdrFWNOm,'cast':EoYtfvMCicjlUsSLqAIQzTpdrFWNOD,'director':EoYtfvMCicjlUsSLqAIQzTpdrFWNOK,'info_genre':EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ,'year':EoYtfvMCicjlUsSLqAIQzTpdrFWNOk,'premiered':EoYtfvMCicjlUsSLqAIQzTpdrFWNOe,'mpaa':EoYtfvMCicjlUsSLqAIQzTpdrFWNOX}
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKe.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOw)
   if EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']['has_more']=='Y':EoYtfvMCicjlUsSLqAIQzTpdrFWNKB=EoYtfvMCicjlUsSLqAIQzTpdrFWNkO
  except EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ as exception:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(exception)
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNKe,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
 def GetEpisodeList(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,program_code,page_int,orderby='desc'):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKe=[]
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKB=EoYtfvMCicjlUsSLqAIQzTpdrFWNky
  try:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDH ='/v2/media/frequency/program/'+program_code
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDu=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetDefaultParams()
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDw={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetNoCache(2))}
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDu.update(EoYtfvMCicjlUsSLqAIQzTpdrFWNDw)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDx=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.API_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDH
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyG=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.callRequestCookies('Get',EoYtfvMCicjlUsSLqAIQzTpdrFWNDx,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNDu,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDm=json.loads(EoYtfvMCicjlUsSLqAIQzTpdrFWNyG.text)
   if not('result' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']):return EoYtfvMCicjlUsSLqAIQzTpdrFWNKe,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
   EoYtfvMCicjlUsSLqAIQzTpdrFWNKu=EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']['result']
   EoYtfvMCicjlUsSLqAIQzTpdrFWNOV=EoYtfvMCicjlUsSLqAIQzTpdrFWNkD(EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']['total_count'])
   EoYtfvMCicjlUsSLqAIQzTpdrFWNOg =EoYtfvMCicjlUsSLqAIQzTpdrFWNkD(EoYtfvMCicjlUsSLqAIQzTpdrFWNOV//(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOa =(EoYtfvMCicjlUsSLqAIQzTpdrFWNOV-1)-((page_int-1)*EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.EPISODE_LIMIT)
   else:
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOa =(page_int-1)*EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.EPISODE_LIMIT
   for i in EoYtfvMCicjlUsSLqAIQzTpdrFWNkK(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.EPISODE_LIMIT):
    if orderby=='desc':
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOh=EoYtfvMCicjlUsSLqAIQzTpdrFWNOa-i
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNOh<0:break
    else:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOh=EoYtfvMCicjlUsSLqAIQzTpdrFWNOa+i
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNOh>=EoYtfvMCicjlUsSLqAIQzTpdrFWNOV:break
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOn=EoYtfvMCicjlUsSLqAIQzTpdrFWNKu[EoYtfvMCicjlUsSLqAIQzTpdrFWNOh]['episode']['code']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKV =EoYtfvMCicjlUsSLqAIQzTpdrFWNKu[EoYtfvMCicjlUsSLqAIQzTpdrFWNOh]['vod_name']['ko']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOb =''
    try:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOH=EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNKu[EoYtfvMCicjlUsSLqAIQzTpdrFWNOh]['episode']['broadcast_date'])
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOb='%s-%s-%s'%(EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[:4],EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[4:6],EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[6:])
    except:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJP
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKg =EoYtfvMCicjlUsSLqAIQzTpdrFWNKu[EoYtfvMCicjlUsSLqAIQzTpdrFWNOh]['episode']['synopsis']['ko']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKh =''
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =''
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKn=''
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKb =''
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKG =''
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKP =''
    for EoYtfvMCicjlUsSLqAIQzTpdrFWNOy in EoYtfvMCicjlUsSLqAIQzTpdrFWNKu[EoYtfvMCicjlUsSLqAIQzTpdrFWNOh]['program']['image']:
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP0900':EoYtfvMCicjlUsSLqAIQzTpdrFWNKh =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
     elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP1800':EoYtfvMCicjlUsSLqAIQzTpdrFWNKn=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
     elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP2000':EoYtfvMCicjlUsSLqAIQzTpdrFWNKb =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
     elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP1900':EoYtfvMCicjlUsSLqAIQzTpdrFWNKG =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
     elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIP0200':EoYtfvMCicjlUsSLqAIQzTpdrFWNKP =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
    for EoYtfvMCicjlUsSLqAIQzTpdrFWNOy in EoYtfvMCicjlUsSLqAIQzTpdrFWNKu[EoYtfvMCicjlUsSLqAIQzTpdrFWNOh]['episode']['image']:
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIE0400':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
    try:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOG=EoYtfvMCicjlUsSLqAIQzTpdrFWNJy=EoYtfvMCicjlUsSLqAIQzTpdrFWNJD=''
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOP=0
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOG =EoYtfvMCicjlUsSLqAIQzTpdrFWNKu[EoYtfvMCicjlUsSLqAIQzTpdrFWNOh]['program']['name']['ko']
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJy =EoYtfvMCicjlUsSLqAIQzTpdrFWNOb
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJD =EoYtfvMCicjlUsSLqAIQzTpdrFWNKu[EoYtfvMCicjlUsSLqAIQzTpdrFWNOh]['channel']['name']['ko']
     if 'frequency' in EoYtfvMCicjlUsSLqAIQzTpdrFWNKu[EoYtfvMCicjlUsSLqAIQzTpdrFWNOh]['episode']:EoYtfvMCicjlUsSLqAIQzTpdrFWNOP=EoYtfvMCicjlUsSLqAIQzTpdrFWNKu[EoYtfvMCicjlUsSLqAIQzTpdrFWNOh]['episode']['frequency']
    except:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJP
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOw={'episode':EoYtfvMCicjlUsSLqAIQzTpdrFWNOn,'title':EoYtfvMCicjlUsSLqAIQzTpdrFWNKV,'subtitle':EoYtfvMCicjlUsSLqAIQzTpdrFWNOb,'thumbnail':{'poster':EoYtfvMCicjlUsSLqAIQzTpdrFWNKh,'thumb':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa,'clearlogo':EoYtfvMCicjlUsSLqAIQzTpdrFWNKn,'icon':EoYtfvMCicjlUsSLqAIQzTpdrFWNKb,'banner':EoYtfvMCicjlUsSLqAIQzTpdrFWNKG,'fanart':EoYtfvMCicjlUsSLqAIQzTpdrFWNKP},'synopsis':EoYtfvMCicjlUsSLqAIQzTpdrFWNKg,'info_title':EoYtfvMCicjlUsSLqAIQzTpdrFWNOG,'aired':EoYtfvMCicjlUsSLqAIQzTpdrFWNJy,'studio':EoYtfvMCicjlUsSLqAIQzTpdrFWNJD,'frequency':EoYtfvMCicjlUsSLqAIQzTpdrFWNOP}
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKe.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOw)
   if EoYtfvMCicjlUsSLqAIQzTpdrFWNOg>page_int:EoYtfvMCicjlUsSLqAIQzTpdrFWNKB=EoYtfvMCicjlUsSLqAIQzTpdrFWNkO
  except EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ as exception:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(exception)
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNKe,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB,EoYtfvMCicjlUsSLqAIQzTpdrFWNOg
 def GetMovieList(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,genre,orderby,page_int):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKe=[]
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKB=EoYtfvMCicjlUsSLqAIQzTpdrFWNky
  try:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDH ='/v2/media/movies'
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDu=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetDefaultParams()
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDw={'pageNo':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(page_int),'pageSize':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetNoCache(2))}
   if genre!='all' :EoYtfvMCicjlUsSLqAIQzTpdrFWNDw['multiCategoryCode']=genre
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDw['productPackageCode']=','.join(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.MOVIE_LITE)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDu.update(EoYtfvMCicjlUsSLqAIQzTpdrFWNDw)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDx=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.API_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDH
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyG=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.callRequestCookies('Get',EoYtfvMCicjlUsSLqAIQzTpdrFWNDx,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNDu,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDm=json.loads(EoYtfvMCicjlUsSLqAIQzTpdrFWNyG.text)
   if not('result' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']):return EoYtfvMCicjlUsSLqAIQzTpdrFWNKe,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
   EoYtfvMCicjlUsSLqAIQzTpdrFWNKu=EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']['result']
   for EoYtfvMCicjlUsSLqAIQzTpdrFWNDh in EoYtfvMCicjlUsSLqAIQzTpdrFWNKu:
    EoYtfvMCicjlUsSLqAIQzTpdrFWNJK =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['movie']['code']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKV =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['movie']['name']['ko'].strip()
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKV +=u' (%s년)'%(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('movie').get('product_year'))
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKh=''
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =''
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKn=''
    for EoYtfvMCicjlUsSLqAIQzTpdrFWNOy in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['movie']['image']:
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIM2100':EoYtfvMCicjlUsSLqAIQzTpdrFWNKh =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
     elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIM0400':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
     elif EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIM1800':EoYtfvMCicjlUsSLqAIQzTpdrFWNKn=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKg =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['movie']['story']['ko']
    try:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOG =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['movie']['name']['ko'].strip()
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOk =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('movie').get('product_year')
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOX =EoYtfvMCicjlUsSLqAIQzTpdrFWNyO.get(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('grade_code'))
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOD=[]
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOK=[]
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ=[]
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJO=0
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOe=''
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJD =''
     for EoYtfvMCicjlUsSLqAIQzTpdrFWNOB in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('movie').get('actor'):
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNOB!='':EoYtfvMCicjlUsSLqAIQzTpdrFWNOD.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOB)
     for EoYtfvMCicjlUsSLqAIQzTpdrFWNOR in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('movie').get('director'):
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNOR!='':EoYtfvMCicjlUsSLqAIQzTpdrFWNOK.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOR)
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('movie').get('category1_name').get('ko')!='':
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['movie']['category1_name']['ko'])
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('movie').get('category2_name').get('ko')!='':
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['movie']['category2_name']['ko'])
     if 'duration' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('movie'):EoYtfvMCicjlUsSLqAIQzTpdrFWNJO=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('movie').get('duration')
     if 'release_date' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('movie'):
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOH=EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('movie').get('release_date'))
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNOH!='0':EoYtfvMCicjlUsSLqAIQzTpdrFWNOe='%s-%s-%s'%(EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[:4],EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[4:6],EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[6:])
     if 'production' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('movie'):EoYtfvMCicjlUsSLqAIQzTpdrFWNJD=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('movie').get('production')
    except:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJP
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOw={'moviecode':EoYtfvMCicjlUsSLqAIQzTpdrFWNJK,'title':EoYtfvMCicjlUsSLqAIQzTpdrFWNKV,'thumbnail':{'poster':EoYtfvMCicjlUsSLqAIQzTpdrFWNKh,'thumb':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa,'clearlogo':EoYtfvMCicjlUsSLqAIQzTpdrFWNKn,'fanart':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa},'synopsis':EoYtfvMCicjlUsSLqAIQzTpdrFWNKg,'info_title':EoYtfvMCicjlUsSLqAIQzTpdrFWNOG,'year':EoYtfvMCicjlUsSLqAIQzTpdrFWNOk,'cast':EoYtfvMCicjlUsSLqAIQzTpdrFWNOD,'director':EoYtfvMCicjlUsSLqAIQzTpdrFWNOK,'info_genre':EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ,'duration':EoYtfvMCicjlUsSLqAIQzTpdrFWNJO,'premiered':EoYtfvMCicjlUsSLqAIQzTpdrFWNOe,'studio':EoYtfvMCicjlUsSLqAIQzTpdrFWNJD,'mpaa':EoYtfvMCicjlUsSLqAIQzTpdrFWNOX}
    EoYtfvMCicjlUsSLqAIQzTpdrFWNJk=EoYtfvMCicjlUsSLqAIQzTpdrFWNky
    for EoYtfvMCicjlUsSLqAIQzTpdrFWNJX in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['billing_package_id']:
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNJX in EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.MOVIE_LITE:
      EoYtfvMCicjlUsSLqAIQzTpdrFWNJk=EoYtfvMCicjlUsSLqAIQzTpdrFWNkO
      break
    if EoYtfvMCicjlUsSLqAIQzTpdrFWNJk==EoYtfvMCicjlUsSLqAIQzTpdrFWNky: 
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOw['title']=EoYtfvMCicjlUsSLqAIQzTpdrFWNOw['title']+' [개별구매]'
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKe.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOw)
   if EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']['has_more']=='Y':EoYtfvMCicjlUsSLqAIQzTpdrFWNKB=EoYtfvMCicjlUsSLqAIQzTpdrFWNkO
  except EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ as exception:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(exception)
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNKe,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
 def GetMovieListGenre(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,genre,page_int):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKe=[]
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKB=EoYtfvMCicjlUsSLqAIQzTpdrFWNky
  try:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDH ='/v2/media/movie/curation/'+genre
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDu=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetDefaultParams()
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDw={'pageNo':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(page_int),'pageSize':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.MOVIE_LIMIT),'_':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetNoCache(2))}
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDu.update(EoYtfvMCicjlUsSLqAIQzTpdrFWNDw)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDx=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.API_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDH
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyG=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.callRequestCookies('Get',EoYtfvMCicjlUsSLqAIQzTpdrFWNDx,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNDu,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDm=json.loads(EoYtfvMCicjlUsSLqAIQzTpdrFWNyG.text)
   if not('movies' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']):return EoYtfvMCicjlUsSLqAIQzTpdrFWNKe,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
   EoYtfvMCicjlUsSLqAIQzTpdrFWNKu=EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']['movies']
   for EoYtfvMCicjlUsSLqAIQzTpdrFWNDh in EoYtfvMCicjlUsSLqAIQzTpdrFWNKu:
    EoYtfvMCicjlUsSLqAIQzTpdrFWNJK =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['code']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKV =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['name']['ko']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNJe =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['image'][0]['url']
    for EoYtfvMCicjlUsSLqAIQzTpdrFWNOy in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['image']:
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['code']=='CAIM2100':
      EoYtfvMCicjlUsSLqAIQzTpdrFWNJe =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNOy['url']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKg =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['story']['ko']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOw={'moviecode':EoYtfvMCicjlUsSLqAIQzTpdrFWNJK,'title':EoYtfvMCicjlUsSLqAIQzTpdrFWNKV.strip(),'thumbnail':EoYtfvMCicjlUsSLqAIQzTpdrFWNJe,'synopsis':EoYtfvMCicjlUsSLqAIQzTpdrFWNKg}
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKe.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOw)
  except EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ as exception:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(exception)
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNKe,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
 def GetMovieGenre(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKe=[]
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKB=EoYtfvMCicjlUsSLqAIQzTpdrFWNky
  try:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDH ='/v2/media/movie/curations'
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDu=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetDefaultParams()
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDw={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetNoCache(2))}
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDu.update(EoYtfvMCicjlUsSLqAIQzTpdrFWNDw)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDx=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.API_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDH
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyG=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.callRequestCookies('Get',EoYtfvMCicjlUsSLqAIQzTpdrFWNDx,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNDu,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDm=json.loads(EoYtfvMCicjlUsSLqAIQzTpdrFWNyG.text)
   if not('result' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']):return EoYtfvMCicjlUsSLqAIQzTpdrFWNKe,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
   EoYtfvMCicjlUsSLqAIQzTpdrFWNKu=EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']['result']
   for EoYtfvMCicjlUsSLqAIQzTpdrFWNDh in EoYtfvMCicjlUsSLqAIQzTpdrFWNKu:
    EoYtfvMCicjlUsSLqAIQzTpdrFWNJB =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['curation_code']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNJR =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['curation_name']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNOw={'curation_code':EoYtfvMCicjlUsSLqAIQzTpdrFWNJB,'curation_name':EoYtfvMCicjlUsSLqAIQzTpdrFWNJR}
    EoYtfvMCicjlUsSLqAIQzTpdrFWNKe.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOw)
  except EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ as exception:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(exception)
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNKe,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
 def GetSearchList(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,search_key,page_int,stype):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNJH=[]
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKB=EoYtfvMCicjlUsSLqAIQzTpdrFWNky
  try:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDH ='/search/getSearch.jsp'
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDw={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(page_int),'pageSize':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.SCREENCODE,'os':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.OSCODE,'network':EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':EoYtfvMCicjlUsSLqAIQzTpdrFWNke(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GetNoCache(2))}
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDx=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.SEARCH_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDH
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyG=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.callRequestCookies('Get',EoYtfvMCicjlUsSLqAIQzTpdrFWNDx,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNDw,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDm=json.loads(EoYtfvMCicjlUsSLqAIQzTpdrFWNyG.text)
   if stype=='vod':
    if not('programRsb' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDm):return EoYtfvMCicjlUsSLqAIQzTpdrFWNJH,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
    EoYtfvMCicjlUsSLqAIQzTpdrFWNJu=EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['programRsb']['dataList']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNJw =EoYtfvMCicjlUsSLqAIQzTpdrFWNkD(EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['programRsb']['count'])
    for EoYtfvMCicjlUsSLqAIQzTpdrFWNDh in EoYtfvMCicjlUsSLqAIQzTpdrFWNJu:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOx=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['mast_cd']
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKV =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['mast_nm']
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKh=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['web_url4']
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['web_url']
     try:
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOD =[]
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOK=[]
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ =[]
      EoYtfvMCicjlUsSLqAIQzTpdrFWNJO =0
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOX =''
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOk =''
      EoYtfvMCicjlUsSLqAIQzTpdrFWNJy =''
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('actor') !='' and EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('actor') !='-':EoYtfvMCicjlUsSLqAIQzTpdrFWNOD =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('actor').split(',')
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('director')!='' and EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('director')!='-':EoYtfvMCicjlUsSLqAIQzTpdrFWNOK=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('director').split(',')
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('cate_nm')!='' and EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('cate_nm')!='-':EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('cate_nm').split('/')
      if 'targetage' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh:EoYtfvMCicjlUsSLqAIQzTpdrFWNOX=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('targetage')
      if 'broad_dt' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh:
       EoYtfvMCicjlUsSLqAIQzTpdrFWNOH=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('broad_dt')
       EoYtfvMCicjlUsSLqAIQzTpdrFWNJy='%s-%s-%s'%(EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[:4],EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[4:6],EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[6:])
       EoYtfvMCicjlUsSLqAIQzTpdrFWNOk =EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[:4]
     except:
      EoYtfvMCicjlUsSLqAIQzTpdrFWNJP
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOw={'program':EoYtfvMCicjlUsSLqAIQzTpdrFWNOx,'title':EoYtfvMCicjlUsSLqAIQzTpdrFWNKV,'thumbnail':{'poster':EoYtfvMCicjlUsSLqAIQzTpdrFWNKh,'thumb':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa,'fanart':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa},'synopsis':'','cast':EoYtfvMCicjlUsSLqAIQzTpdrFWNOD,'director':EoYtfvMCicjlUsSLqAIQzTpdrFWNOK,'info_genre':EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ,'duration':EoYtfvMCicjlUsSLqAIQzTpdrFWNJO,'mpaa':EoYtfvMCicjlUsSLqAIQzTpdrFWNOX,'year':EoYtfvMCicjlUsSLqAIQzTpdrFWNOk,'aired':EoYtfvMCicjlUsSLqAIQzTpdrFWNJy}
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJH.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOw)
   else:
    if not('vodMVRsb' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDm):return EoYtfvMCicjlUsSLqAIQzTpdrFWNJH,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
    EoYtfvMCicjlUsSLqAIQzTpdrFWNJx=EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['vodMVRsb']['dataList']
    EoYtfvMCicjlUsSLqAIQzTpdrFWNJw =EoYtfvMCicjlUsSLqAIQzTpdrFWNkD(EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['vodMVRsb']['count'])
    for EoYtfvMCicjlUsSLqAIQzTpdrFWNDh in EoYtfvMCicjlUsSLqAIQzTpdrFWNJx:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOx=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['mast_cd']
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKV =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['mast_nm'].strip()
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKh =EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.IMG_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['web_url']
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKa =EoYtfvMCicjlUsSLqAIQzTpdrFWNKh
     EoYtfvMCicjlUsSLqAIQzTpdrFWNKn=''
     try:
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOD =[]
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOK=[]
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ =[]
      EoYtfvMCicjlUsSLqAIQzTpdrFWNJO =0
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOX =''
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOk =''
      EoYtfvMCicjlUsSLqAIQzTpdrFWNJy =''
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('actor') !='' and EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('actor') !='-':EoYtfvMCicjlUsSLqAIQzTpdrFWNOD =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('actor').split(',')
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('director')!='' and EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('director')!='-':EoYtfvMCicjlUsSLqAIQzTpdrFWNOK=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('director').split(',')
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('cate_nm')!='' and EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('cate_nm')!='-':EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ =EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('cate_nm').split('/')
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('runtime_sec')!='':EoYtfvMCicjlUsSLqAIQzTpdrFWNJO=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('runtime_sec')
      if 'grade_nm' in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh:EoYtfvMCicjlUsSLqAIQzTpdrFWNOX=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('grade_nm')
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOH=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh.get('broad_dt')
      if data_str!='':
       EoYtfvMCicjlUsSLqAIQzTpdrFWNJy='%s-%s-%s'%(EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[:4],EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[4:6],EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[6:])
       EoYtfvMCicjlUsSLqAIQzTpdrFWNOk =EoYtfvMCicjlUsSLqAIQzTpdrFWNOH[:4]
     except:
      EoYtfvMCicjlUsSLqAIQzTpdrFWNJP
     EoYtfvMCicjlUsSLqAIQzTpdrFWNOw={'movie':EoYtfvMCicjlUsSLqAIQzTpdrFWNOx,'title':EoYtfvMCicjlUsSLqAIQzTpdrFWNKV,'thumbnail':{'poster':EoYtfvMCicjlUsSLqAIQzTpdrFWNKh,'thumb':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa,'fanart':EoYtfvMCicjlUsSLqAIQzTpdrFWNKa,'clearlogo':EoYtfvMCicjlUsSLqAIQzTpdrFWNKn},'synopsis':'','cast':EoYtfvMCicjlUsSLqAIQzTpdrFWNOD,'director':EoYtfvMCicjlUsSLqAIQzTpdrFWNOK,'info_genre':EoYtfvMCicjlUsSLqAIQzTpdrFWNOJ,'duration':EoYtfvMCicjlUsSLqAIQzTpdrFWNJO,'mpaa':EoYtfvMCicjlUsSLqAIQzTpdrFWNOX,'year':EoYtfvMCicjlUsSLqAIQzTpdrFWNOk,'aired':EoYtfvMCicjlUsSLqAIQzTpdrFWNJy}
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJk=EoYtfvMCicjlUsSLqAIQzTpdrFWNky
     for EoYtfvMCicjlUsSLqAIQzTpdrFWNJX in EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['bill']:
      if EoYtfvMCicjlUsSLqAIQzTpdrFWNJX in EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.MOVIE_LITE:
       EoYtfvMCicjlUsSLqAIQzTpdrFWNJk=EoYtfvMCicjlUsSLqAIQzTpdrFWNkO
       break
     if EoYtfvMCicjlUsSLqAIQzTpdrFWNJk==EoYtfvMCicjlUsSLqAIQzTpdrFWNky: 
      EoYtfvMCicjlUsSLqAIQzTpdrFWNOw['title']=EoYtfvMCicjlUsSLqAIQzTpdrFWNOw['title']+' [개별구매]'
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJH.append(EoYtfvMCicjlUsSLqAIQzTpdrFWNOw)
   if EoYtfvMCicjlUsSLqAIQzTpdrFWNJw>(page_int*EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.SEARCH_LIMIT):EoYtfvMCicjlUsSLqAIQzTpdrFWNKB=EoYtfvMCicjlUsSLqAIQzTpdrFWNkO
  except EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ as exception:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(exception)
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNJH,EoYtfvMCicjlUsSLqAIQzTpdrFWNKB
 def GetDeviceList(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,EoYtfvMCicjlUsSLqAIQzTpdrFWNDy,EoYtfvMCicjlUsSLqAIQzTpdrFWNDK):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNKe=[]
  EoYtfvMCicjlUsSLqAIQzTpdrFWNDB='-'
  try:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDH ='/v1/user/device/list'
   EoYtfvMCicjlUsSLqAIQzTpdrFWNJm=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.API_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDH
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDw={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   EoYtfvMCicjlUsSLqAIQzTpdrFWNye=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.makeDefaultCookies(vToken=EoYtfvMCicjlUsSLqAIQzTpdrFWNDy,vUserinfo=EoYtfvMCicjlUsSLqAIQzTpdrFWNDK)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyG=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.callRequestCookies('Get',EoYtfvMCicjlUsSLqAIQzTpdrFWNJm,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNDw,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNye)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDm=json.loads(EoYtfvMCicjlUsSLqAIQzTpdrFWNyG.text)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNKe=EoYtfvMCicjlUsSLqAIQzTpdrFWNDm['body']
   for EoYtfvMCicjlUsSLqAIQzTpdrFWNDh in EoYtfvMCicjlUsSLqAIQzTpdrFWNKe:
    if EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['model']=='PC':
     EoYtfvMCicjlUsSLqAIQzTpdrFWNDB=EoYtfvMCicjlUsSLqAIQzTpdrFWNDh['uuid']
  except EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ as exception:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(exception)
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNDB
 def GetProfileToken(EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ,EoYtfvMCicjlUsSLqAIQzTpdrFWNDy,EoYtfvMCicjlUsSLqAIQzTpdrFWNDK,user_pf):
  EoYtfvMCicjlUsSLqAIQzTpdrFWNJV=[]
  EoYtfvMCicjlUsSLqAIQzTpdrFWNJg =''
  EoYtfvMCicjlUsSLqAIQzTpdrFWNJa =''
  EoYtfvMCicjlUsSLqAIQzTpdrFWNJh='Y'
  EoYtfvMCicjlUsSLqAIQzTpdrFWNJn ='N'
  try:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDH ='/profile/select.do'
   EoYtfvMCicjlUsSLqAIQzTpdrFWNJm=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.URL_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDH
   EoYtfvMCicjlUsSLqAIQzTpdrFWNye=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.makeDefaultCookies(vToken=EoYtfvMCicjlUsSLqAIQzTpdrFWNDy,vUserinfo=EoYtfvMCicjlUsSLqAIQzTpdrFWNDK)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyG=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.callRequestCookies('Get',EoYtfvMCicjlUsSLqAIQzTpdrFWNJm,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNye)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNJV =re.findall('data-profile-no="\d+"',EoYtfvMCicjlUsSLqAIQzTpdrFWNyG.text)
   for i in EoYtfvMCicjlUsSLqAIQzTpdrFWNkK(EoYtfvMCicjlUsSLqAIQzTpdrFWNkR(EoYtfvMCicjlUsSLqAIQzTpdrFWNJV)):
    EoYtfvMCicjlUsSLqAIQzTpdrFWNJb =EoYtfvMCicjlUsSLqAIQzTpdrFWNJV[i].replace('data-profile-no=','').replace('"','')
    EoYtfvMCicjlUsSLqAIQzTpdrFWNJV[i]=EoYtfvMCicjlUsSLqAIQzTpdrFWNJb
   EoYtfvMCicjlUsSLqAIQzTpdrFWNJg=EoYtfvMCicjlUsSLqAIQzTpdrFWNJV[user_pf]
  except EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ as exception:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(exception)
   return EoYtfvMCicjlUsSLqAIQzTpdrFWNJa,EoYtfvMCicjlUsSLqAIQzTpdrFWNJh,EoYtfvMCicjlUsSLqAIQzTpdrFWNJn
  try:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNDH ='/profile/api/select.do'
   EoYtfvMCicjlUsSLqAIQzTpdrFWNJm=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.URL_DOMAIN+EoYtfvMCicjlUsSLqAIQzTpdrFWNDH
   EoYtfvMCicjlUsSLqAIQzTpdrFWNye=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.makeDefaultCookies(vToken=EoYtfvMCicjlUsSLqAIQzTpdrFWNDy,vUserinfo=EoYtfvMCicjlUsSLqAIQzTpdrFWNDK)
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyb={'profileNo':EoYtfvMCicjlUsSLqAIQzTpdrFWNJg}
   EoYtfvMCicjlUsSLqAIQzTpdrFWNyG=EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.callRequestCookies('Post',EoYtfvMCicjlUsSLqAIQzTpdrFWNJm,payload=EoYtfvMCicjlUsSLqAIQzTpdrFWNyb,params=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,headers=EoYtfvMCicjlUsSLqAIQzTpdrFWNJP,cookies=EoYtfvMCicjlUsSLqAIQzTpdrFWNye)
   for EoYtfvMCicjlUsSLqAIQzTpdrFWNyP in EoYtfvMCicjlUsSLqAIQzTpdrFWNyG.cookies:
    if EoYtfvMCicjlUsSLqAIQzTpdrFWNyP.name=='_tving_token':
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJa=EoYtfvMCicjlUsSLqAIQzTpdrFWNyP.value
    elif EoYtfvMCicjlUsSLqAIQzTpdrFWNyP.name==EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GLOBAL_COOKIENM['tv_cookiekey']:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJh=EoYtfvMCicjlUsSLqAIQzTpdrFWNyP.value
    elif EoYtfvMCicjlUsSLqAIQzTpdrFWNyP.name==EoYtfvMCicjlUsSLqAIQzTpdrFWNyJ.GLOBAL_COOKIENM['tv_lockkey']:
     EoYtfvMCicjlUsSLqAIQzTpdrFWNJn=EoYtfvMCicjlUsSLqAIQzTpdrFWNyP.value
  except EoYtfvMCicjlUsSLqAIQzTpdrFWNkJ as exception:
   EoYtfvMCicjlUsSLqAIQzTpdrFWNkX(exception)
  return EoYtfvMCicjlUsSLqAIQzTpdrFWNJa,EoYtfvMCicjlUsSLqAIQzTpdrFWNJh,EoYtfvMCicjlUsSLqAIQzTpdrFWNJn
# Created by pyminifier (https://github.com/liftoff/pyminifier)
