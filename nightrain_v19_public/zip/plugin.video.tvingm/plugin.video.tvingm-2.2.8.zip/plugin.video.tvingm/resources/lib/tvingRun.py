__author__="NightRain"
rKiNhGqbFkedzvxVWARHIyotSTlPJD=object
rKiNhGqbFkedzvxVWARHIyotSTlPJO=None
rKiNhGqbFkedzvxVWARHIyotSTlPJL=int
rKiNhGqbFkedzvxVWARHIyotSTlPJM=True
rKiNhGqbFkedzvxVWARHIyotSTlPJp=False
rKiNhGqbFkedzvxVWARHIyotSTlPJw=type
rKiNhGqbFkedzvxVWARHIyotSTlPJm=dict
rKiNhGqbFkedzvxVWARHIyotSTlPJj=len
rKiNhGqbFkedzvxVWARHIyotSTlPJs=str
rKiNhGqbFkedzvxVWARHIyotSTlPJf=range
rKiNhGqbFkedzvxVWARHIyotSTlPJu=open
rKiNhGqbFkedzvxVWARHIyotSTlPXQ=Exception
rKiNhGqbFkedzvxVWARHIyotSTlPXa=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
rKiNhGqbFkedzvxVWARHIyotSTlPQg=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'}]
rKiNhGqbFkedzvxVWARHIyotSTlPQU=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
rKiNhGqbFkedzvxVWARHIyotSTlPQn=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
rKiNhGqbFkedzvxVWARHIyotSTlPQC=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
rKiNhGqbFkedzvxVWARHIyotSTlPQJ=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
rKiNhGqbFkedzvxVWARHIyotSTlPQX=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
rKiNhGqbFkedzvxVWARHIyotSTlPQY=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
rKiNhGqbFkedzvxVWARHIyotSTlPQc =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
rKiNhGqbFkedzvxVWARHIyotSTlPQE=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class rKiNhGqbFkedzvxVWARHIyotSTlPQa(rKiNhGqbFkedzvxVWARHIyotSTlPJD):
 def __init__(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPQD,rKiNhGqbFkedzvxVWARHIyotSTlPQO,rKiNhGqbFkedzvxVWARHIyotSTlPQL):
  rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_url =rKiNhGqbFkedzvxVWARHIyotSTlPQD
  rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle=rKiNhGqbFkedzvxVWARHIyotSTlPQO
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params =rKiNhGqbFkedzvxVWARHIyotSTlPQL
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj =EoYtfvMCicjlUsSLqAIQzTpdrFWNyD() 
 def addon_noti(rKiNhGqbFkedzvxVWARHIyotSTlPQB,sting):
  try:
   rKiNhGqbFkedzvxVWARHIyotSTlPQp=xbmcgui.Dialog()
   rKiNhGqbFkedzvxVWARHIyotSTlPQp.notification(__addonname__,sting)
  except:
   rKiNhGqbFkedzvxVWARHIyotSTlPJO
 def addon_log(rKiNhGqbFkedzvxVWARHIyotSTlPQB,string):
  try:
   rKiNhGqbFkedzvxVWARHIyotSTlPQw=string.encode('utf-8','ignore')
  except:
   rKiNhGqbFkedzvxVWARHIyotSTlPQw='addonException: addon_log'
  rKiNhGqbFkedzvxVWARHIyotSTlPQm=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,rKiNhGqbFkedzvxVWARHIyotSTlPQw),level=rKiNhGqbFkedzvxVWARHIyotSTlPQm)
 def get_keyboard_input(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPaE):
  rKiNhGqbFkedzvxVWARHIyotSTlPQj=rKiNhGqbFkedzvxVWARHIyotSTlPJO
  kb=xbmc.Keyboard()
  kb.setHeading(rKiNhGqbFkedzvxVWARHIyotSTlPaE)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   rKiNhGqbFkedzvxVWARHIyotSTlPQj=kb.getText()
  return rKiNhGqbFkedzvxVWARHIyotSTlPQj
 def get_settings_login_info(rKiNhGqbFkedzvxVWARHIyotSTlPQB):
  rKiNhGqbFkedzvxVWARHIyotSTlPQs =__addon__.getSetting('id')
  rKiNhGqbFkedzvxVWARHIyotSTlPQf =__addon__.getSetting('pw')
  rKiNhGqbFkedzvxVWARHIyotSTlPQu =__addon__.getSetting('login_type')
  rKiNhGqbFkedzvxVWARHIyotSTlPaQ=rKiNhGqbFkedzvxVWARHIyotSTlPJL(__addon__.getSetting('selected_profile'))
  return(rKiNhGqbFkedzvxVWARHIyotSTlPQs,rKiNhGqbFkedzvxVWARHIyotSTlPQf,rKiNhGqbFkedzvxVWARHIyotSTlPQu,rKiNhGqbFkedzvxVWARHIyotSTlPaQ)
 def get_settings_totalsearch(rKiNhGqbFkedzvxVWARHIyotSTlPQB):
  rKiNhGqbFkedzvxVWARHIyotSTlPag =rKiNhGqbFkedzvxVWARHIyotSTlPJM if __addon__.getSetting('local_search')=='true' else rKiNhGqbFkedzvxVWARHIyotSTlPJp
  rKiNhGqbFkedzvxVWARHIyotSTlPaU=rKiNhGqbFkedzvxVWARHIyotSTlPJM if __addon__.getSetting('local_history')=='true' else rKiNhGqbFkedzvxVWARHIyotSTlPJp
  rKiNhGqbFkedzvxVWARHIyotSTlPan =rKiNhGqbFkedzvxVWARHIyotSTlPJM if __addon__.getSetting('total_search')=='true' else rKiNhGqbFkedzvxVWARHIyotSTlPJp
  rKiNhGqbFkedzvxVWARHIyotSTlPaC=rKiNhGqbFkedzvxVWARHIyotSTlPJM if __addon__.getSetting('total_history')=='true' else rKiNhGqbFkedzvxVWARHIyotSTlPJp
  return(rKiNhGqbFkedzvxVWARHIyotSTlPag,rKiNhGqbFkedzvxVWARHIyotSTlPaU,rKiNhGqbFkedzvxVWARHIyotSTlPan,rKiNhGqbFkedzvxVWARHIyotSTlPaC)
 def get_settings_direct_replay(rKiNhGqbFkedzvxVWARHIyotSTlPQB):
  rKiNhGqbFkedzvxVWARHIyotSTlPaJ=rKiNhGqbFkedzvxVWARHIyotSTlPJL(__addon__.getSetting('direct_replay'))
  if rKiNhGqbFkedzvxVWARHIyotSTlPaJ==0:
   return rKiNhGqbFkedzvxVWARHIyotSTlPJp
  else:
   return rKiNhGqbFkedzvxVWARHIyotSTlPJM
 def set_winCredential(rKiNhGqbFkedzvxVWARHIyotSTlPQB,credential):
  rKiNhGqbFkedzvxVWARHIyotSTlPaX=xbmcgui.Window(10000)
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_LOGINTIME',rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(rKiNhGqbFkedzvxVWARHIyotSTlPQB):
  rKiNhGqbFkedzvxVWARHIyotSTlPaX=xbmcgui.Window(10000)
  rKiNhGqbFkedzvxVWARHIyotSTlPaY={'tving_token':rKiNhGqbFkedzvxVWARHIyotSTlPaX.getProperty('TVING_M_TOKEN'),'poc_userinfo':rKiNhGqbFkedzvxVWARHIyotSTlPaX.getProperty('TVING_M_USERINFO'),'tving_uuid':rKiNhGqbFkedzvxVWARHIyotSTlPaX.getProperty('TVING_M_UUID'),'tving_maintoken':rKiNhGqbFkedzvxVWARHIyotSTlPaX.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':rKiNhGqbFkedzvxVWARHIyotSTlPaX.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':rKiNhGqbFkedzvxVWARHIyotSTlPaX.getProperty('TVING_M_LOCKKEY')}
  return rKiNhGqbFkedzvxVWARHIyotSTlPaY
 def set_winEpisodeOrderby(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPUC):
  rKiNhGqbFkedzvxVWARHIyotSTlPaX=xbmcgui.Window(10000)
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_ORDERBY',rKiNhGqbFkedzvxVWARHIyotSTlPUC)
 def get_winEpisodeOrderby(rKiNhGqbFkedzvxVWARHIyotSTlPQB):
  rKiNhGqbFkedzvxVWARHIyotSTlPaX=xbmcgui.Window(10000)
  return rKiNhGqbFkedzvxVWARHIyotSTlPaX.getProperty('TVING_M_ORDERBY')
 def add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPQB,label,sublabel='',img='',infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPJO,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJM,params='',isLink=rKiNhGqbFkedzvxVWARHIyotSTlPJp,ContextMenu=rKiNhGqbFkedzvxVWARHIyotSTlPJO):
  rKiNhGqbFkedzvxVWARHIyotSTlPac='%s?%s'%(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_url,urllib.parse.urlencode(params))
  if sublabel:rKiNhGqbFkedzvxVWARHIyotSTlPaE='%s < %s >'%(label,sublabel)
  else: rKiNhGqbFkedzvxVWARHIyotSTlPaE=label
  if not img:img='DefaultFolder.png'
  rKiNhGqbFkedzvxVWARHIyotSTlPaB=xbmcgui.ListItem(rKiNhGqbFkedzvxVWARHIyotSTlPaE)
  if rKiNhGqbFkedzvxVWARHIyotSTlPJw(img)==rKiNhGqbFkedzvxVWARHIyotSTlPJm:
   rKiNhGqbFkedzvxVWARHIyotSTlPaB.setArt(img)
  else:
   rKiNhGqbFkedzvxVWARHIyotSTlPaB.setArt({'thumb':img,'poster':img})
  if infoLabels:rKiNhGqbFkedzvxVWARHIyotSTlPaB.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   rKiNhGqbFkedzvxVWARHIyotSTlPaB.setProperty('IsPlayable','true')
  if ContextMenu:rKiNhGqbFkedzvxVWARHIyotSTlPaB.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle,rKiNhGqbFkedzvxVWARHIyotSTlPac,rKiNhGqbFkedzvxVWARHIyotSTlPaB,isFolder)
 def get_selQuality(rKiNhGqbFkedzvxVWARHIyotSTlPQB,etype):
  try:
   rKiNhGqbFkedzvxVWARHIyotSTlPaD='selected_quality'
   rKiNhGqbFkedzvxVWARHIyotSTlPaO=[1080,720,480,360]
   rKiNhGqbFkedzvxVWARHIyotSTlPaL=rKiNhGqbFkedzvxVWARHIyotSTlPJL(__addon__.getSetting(rKiNhGqbFkedzvxVWARHIyotSTlPaD))
   return rKiNhGqbFkedzvxVWARHIyotSTlPaO[rKiNhGqbFkedzvxVWARHIyotSTlPaL]
  except:
   rKiNhGqbFkedzvxVWARHIyotSTlPJO
  return 720 
 def dp_Main_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB):
  (rKiNhGqbFkedzvxVWARHIyotSTlPag,rKiNhGqbFkedzvxVWARHIyotSTlPaU,rKiNhGqbFkedzvxVWARHIyotSTlPan,rKiNhGqbFkedzvxVWARHIyotSTlPaC)=rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_settings_totalsearch()
  for rKiNhGqbFkedzvxVWARHIyotSTlPaM in rKiNhGqbFkedzvxVWARHIyotSTlPQg:
   rKiNhGqbFkedzvxVWARHIyotSTlPaE=rKiNhGqbFkedzvxVWARHIyotSTlPaM.get('title')
   rKiNhGqbFkedzvxVWARHIyotSTlPap=''
   if rKiNhGqbFkedzvxVWARHIyotSTlPaM.get('mode')=='SEARCH_GROUP' and rKiNhGqbFkedzvxVWARHIyotSTlPag ==rKiNhGqbFkedzvxVWARHIyotSTlPJp:continue
   elif rKiNhGqbFkedzvxVWARHIyotSTlPaM.get('mode')=='SEARCH_HISTORY' and rKiNhGqbFkedzvxVWARHIyotSTlPaU==rKiNhGqbFkedzvxVWARHIyotSTlPJp:continue
   elif rKiNhGqbFkedzvxVWARHIyotSTlPaM.get('mode')=='TOTAL_SEARCH' and rKiNhGqbFkedzvxVWARHIyotSTlPan ==rKiNhGqbFkedzvxVWARHIyotSTlPJp:continue
   elif rKiNhGqbFkedzvxVWARHIyotSTlPaM.get('mode')=='TOTAL_HISTORY' and rKiNhGqbFkedzvxVWARHIyotSTlPaC==rKiNhGqbFkedzvxVWARHIyotSTlPJp:continue
   rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':rKiNhGqbFkedzvxVWARHIyotSTlPaM.get('mode'),'stype':rKiNhGqbFkedzvxVWARHIyotSTlPaM.get('stype'),'orderby':rKiNhGqbFkedzvxVWARHIyotSTlPaM.get('orderby'),'ordernm':rKiNhGqbFkedzvxVWARHIyotSTlPaM.get('ordernm'),'page':'1'}
   if rKiNhGqbFkedzvxVWARHIyotSTlPaM.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY']:
    rKiNhGqbFkedzvxVWARHIyotSTlPam=rKiNhGqbFkedzvxVWARHIyotSTlPJp
    rKiNhGqbFkedzvxVWARHIyotSTlPaj =rKiNhGqbFkedzvxVWARHIyotSTlPJM
   else:
    rKiNhGqbFkedzvxVWARHIyotSTlPam=rKiNhGqbFkedzvxVWARHIyotSTlPJM
    rKiNhGqbFkedzvxVWARHIyotSTlPaj =rKiNhGqbFkedzvxVWARHIyotSTlPJp
   if 'icon' in rKiNhGqbFkedzvxVWARHIyotSTlPaM:rKiNhGqbFkedzvxVWARHIyotSTlPap=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',rKiNhGqbFkedzvxVWARHIyotSTlPaM.get('icon')) 
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel='',img=rKiNhGqbFkedzvxVWARHIyotSTlPap,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPJO,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPam,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw,isLink=rKiNhGqbFkedzvxVWARHIyotSTlPaj)
  if rKiNhGqbFkedzvxVWARHIyotSTlPJj(rKiNhGqbFkedzvxVWARHIyotSTlPQg)>0:xbmcplugin.endOfDirectory(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle)
 def login_main(rKiNhGqbFkedzvxVWARHIyotSTlPQB):
  (rKiNhGqbFkedzvxVWARHIyotSTlPaf,rKiNhGqbFkedzvxVWARHIyotSTlPau,rKiNhGqbFkedzvxVWARHIyotSTlPgQ,rKiNhGqbFkedzvxVWARHIyotSTlPga)=rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_settings_login_info()
  if not(rKiNhGqbFkedzvxVWARHIyotSTlPaf and rKiNhGqbFkedzvxVWARHIyotSTlPau):
   rKiNhGqbFkedzvxVWARHIyotSTlPQp=xbmcgui.Dialog()
   rKiNhGqbFkedzvxVWARHIyotSTlPgU=rKiNhGqbFkedzvxVWARHIyotSTlPQp.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if rKiNhGqbFkedzvxVWARHIyotSTlPgU==rKiNhGqbFkedzvxVWARHIyotSTlPJM:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_winEpisodeOrderby()=='':
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.set_winEpisodeOrderby('desc')
  if rKiNhGqbFkedzvxVWARHIyotSTlPQB.cookiefile_check():return
  rKiNhGqbFkedzvxVWARHIyotSTlPgn =rKiNhGqbFkedzvxVWARHIyotSTlPJL(rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  rKiNhGqbFkedzvxVWARHIyotSTlPgC=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if rKiNhGqbFkedzvxVWARHIyotSTlPgC==rKiNhGqbFkedzvxVWARHIyotSTlPJO or rKiNhGqbFkedzvxVWARHIyotSTlPgC=='':
   rKiNhGqbFkedzvxVWARHIyotSTlPgC=rKiNhGqbFkedzvxVWARHIyotSTlPJL('19000101')
  else:
   rKiNhGqbFkedzvxVWARHIyotSTlPgC=rKiNhGqbFkedzvxVWARHIyotSTlPJL(re.sub('-','',rKiNhGqbFkedzvxVWARHIyotSTlPgC))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   rKiNhGqbFkedzvxVWARHIyotSTlPgJ=0
   while rKiNhGqbFkedzvxVWARHIyotSTlPJM:
    rKiNhGqbFkedzvxVWARHIyotSTlPgJ+=1
    time.sleep(0.05)
    if rKiNhGqbFkedzvxVWARHIyotSTlPgC>=rKiNhGqbFkedzvxVWARHIyotSTlPgn:return
    if rKiNhGqbFkedzvxVWARHIyotSTlPgJ>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if rKiNhGqbFkedzvxVWARHIyotSTlPgC>=rKiNhGqbFkedzvxVWARHIyotSTlPgn:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.GetCredential(rKiNhGqbFkedzvxVWARHIyotSTlPaf,rKiNhGqbFkedzvxVWARHIyotSTlPau,rKiNhGqbFkedzvxVWARHIyotSTlPgQ,rKiNhGqbFkedzvxVWARHIyotSTlPga):
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.set_winCredential(rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.LoadCredential())
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE):
  rKiNhGqbFkedzvxVWARHIyotSTlPgX=rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('stype')
  if rKiNhGqbFkedzvxVWARHIyotSTlPgX=='live':
   rKiNhGqbFkedzvxVWARHIyotSTlPgY=rKiNhGqbFkedzvxVWARHIyotSTlPQU
  elif rKiNhGqbFkedzvxVWARHIyotSTlPgX=='vod':
   rKiNhGqbFkedzvxVWARHIyotSTlPgY=rKiNhGqbFkedzvxVWARHIyotSTlPQJ
  else:
   rKiNhGqbFkedzvxVWARHIyotSTlPgY=rKiNhGqbFkedzvxVWARHIyotSTlPQX
  for rKiNhGqbFkedzvxVWARHIyotSTlPgc in rKiNhGqbFkedzvxVWARHIyotSTlPgY:
   rKiNhGqbFkedzvxVWARHIyotSTlPaE=rKiNhGqbFkedzvxVWARHIyotSTlPgc.get('title')
   if rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('ordernm')!='-':
    rKiNhGqbFkedzvxVWARHIyotSTlPaE+='  ('+rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('ordernm')+')'
   rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':rKiNhGqbFkedzvxVWARHIyotSTlPgc.get('mode'),'stype':rKiNhGqbFkedzvxVWARHIyotSTlPgc.get('stype'),'orderby':rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('orderby'),'ordernm':rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('ordernm'),'page':'1'}
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel='',img='',infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPJO,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJM,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  if rKiNhGqbFkedzvxVWARHIyotSTlPJj(rKiNhGqbFkedzvxVWARHIyotSTlPgY)>0:xbmcplugin.endOfDirectory(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle)
 def dp_SubTitle_Group(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE): 
  for rKiNhGqbFkedzvxVWARHIyotSTlPgc in rKiNhGqbFkedzvxVWARHIyotSTlPQY:
   rKiNhGqbFkedzvxVWARHIyotSTlPaE=rKiNhGqbFkedzvxVWARHIyotSTlPgc.get('title')
   if rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('ordernm')!='-':
    rKiNhGqbFkedzvxVWARHIyotSTlPaE+='  ('+rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('ordernm')+')'
   rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':rKiNhGqbFkedzvxVWARHIyotSTlPgc.get('mode'),'genreCode':rKiNhGqbFkedzvxVWARHIyotSTlPgc.get('genreCode'),'stype':rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('stype'),'orderby':rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('orderby'),'page':'1'}
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel='',img='',infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPJO,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJM,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  if rKiNhGqbFkedzvxVWARHIyotSTlPJj(rKiNhGqbFkedzvxVWARHIyotSTlPQY)>0:xbmcplugin.endOfDirectory(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle)
 def dp_LiveChannel_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE):
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.SaveCredential(rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_winCredential())
  rKiNhGqbFkedzvxVWARHIyotSTlPgX =rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('stype')
  rKiNhGqbFkedzvxVWARHIyotSTlPgB =rKiNhGqbFkedzvxVWARHIyotSTlPJL(rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('page'))
  rKiNhGqbFkedzvxVWARHIyotSTlPgD,rKiNhGqbFkedzvxVWARHIyotSTlPgO=rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.GetLiveChannelList(rKiNhGqbFkedzvxVWARHIyotSTlPgX,rKiNhGqbFkedzvxVWARHIyotSTlPgB)
  for rKiNhGqbFkedzvxVWARHIyotSTlPgL in rKiNhGqbFkedzvxVWARHIyotSTlPgD:
   rKiNhGqbFkedzvxVWARHIyotSTlPaE =rKiNhGqbFkedzvxVWARHIyotSTlPgL.get('title')
   rKiNhGqbFkedzvxVWARHIyotSTlPas =rKiNhGqbFkedzvxVWARHIyotSTlPgL.get('channel')
   rKiNhGqbFkedzvxVWARHIyotSTlPgM =rKiNhGqbFkedzvxVWARHIyotSTlPgL.get('thumbnail')
   rKiNhGqbFkedzvxVWARHIyotSTlPgp =rKiNhGqbFkedzvxVWARHIyotSTlPgL.get('synopsis')
   rKiNhGqbFkedzvxVWARHIyotSTlPgw =rKiNhGqbFkedzvxVWARHIyotSTlPgL.get('channelepg')
   rKiNhGqbFkedzvxVWARHIyotSTlPgm =rKiNhGqbFkedzvxVWARHIyotSTlPgL.get('cast')
   rKiNhGqbFkedzvxVWARHIyotSTlPgj =rKiNhGqbFkedzvxVWARHIyotSTlPgL.get('director')
   rKiNhGqbFkedzvxVWARHIyotSTlPgs =rKiNhGqbFkedzvxVWARHIyotSTlPgL.get('info_genre')
   rKiNhGqbFkedzvxVWARHIyotSTlPgf =rKiNhGqbFkedzvxVWARHIyotSTlPgL.get('year')
   rKiNhGqbFkedzvxVWARHIyotSTlPgu =rKiNhGqbFkedzvxVWARHIyotSTlPgL.get('mpaa')
   rKiNhGqbFkedzvxVWARHIyotSTlPUQ =rKiNhGqbFkedzvxVWARHIyotSTlPgL.get('premiered')
   rKiNhGqbFkedzvxVWARHIyotSTlPUa={'mediatype':'episode','title':rKiNhGqbFkedzvxVWARHIyotSTlPaE,'studio':rKiNhGqbFkedzvxVWARHIyotSTlPas,'cast':rKiNhGqbFkedzvxVWARHIyotSTlPgm,'director':rKiNhGqbFkedzvxVWARHIyotSTlPgj,'genre':rKiNhGqbFkedzvxVWARHIyotSTlPgs,'plot':'%s\n%s\n%s\n\n%s'%(rKiNhGqbFkedzvxVWARHIyotSTlPas,rKiNhGqbFkedzvxVWARHIyotSTlPaE,rKiNhGqbFkedzvxVWARHIyotSTlPgw,rKiNhGqbFkedzvxVWARHIyotSTlPgp),'year':rKiNhGqbFkedzvxVWARHIyotSTlPgf,'mpaa':rKiNhGqbFkedzvxVWARHIyotSTlPgu,'premiered':rKiNhGqbFkedzvxVWARHIyotSTlPUQ}
   rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':'LIVE','mediacode':rKiNhGqbFkedzvxVWARHIyotSTlPgL.get('mediacode'),'stype':rKiNhGqbFkedzvxVWARHIyotSTlPgX}
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPas,sublabel=rKiNhGqbFkedzvxVWARHIyotSTlPaE,img=rKiNhGqbFkedzvxVWARHIyotSTlPgM,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPUa,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJp,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  if rKiNhGqbFkedzvxVWARHIyotSTlPgO:
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['mode']='CHANNEL' 
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['stype']=rKiNhGqbFkedzvxVWARHIyotSTlPgX 
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['page']=rKiNhGqbFkedzvxVWARHIyotSTlPJs(rKiNhGqbFkedzvxVWARHIyotSTlPgB+1)
   rKiNhGqbFkedzvxVWARHIyotSTlPaE='[B]%s >>[/B]'%'다음 페이지'
   rKiNhGqbFkedzvxVWARHIyotSTlPUg=rKiNhGqbFkedzvxVWARHIyotSTlPJs(rKiNhGqbFkedzvxVWARHIyotSTlPgB+1)
   rKiNhGqbFkedzvxVWARHIyotSTlPap=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel=rKiNhGqbFkedzvxVWARHIyotSTlPUg,img=rKiNhGqbFkedzvxVWARHIyotSTlPap,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPJO,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJM,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  if rKiNhGqbFkedzvxVWARHIyotSTlPJj(rKiNhGqbFkedzvxVWARHIyotSTlPgD)>0:xbmcplugin.endOfDirectory(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle,cacheToDisc=rKiNhGqbFkedzvxVWARHIyotSTlPJp)
 def dp_Program_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE):
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.SaveCredential(rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_winCredential())
  rKiNhGqbFkedzvxVWARHIyotSTlPUn =rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('stype')
  rKiNhGqbFkedzvxVWARHIyotSTlPUC =rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('orderby')
  rKiNhGqbFkedzvxVWARHIyotSTlPgB =rKiNhGqbFkedzvxVWARHIyotSTlPJL(rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('page'))
  rKiNhGqbFkedzvxVWARHIyotSTlPUJ=rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('genreCode')
  if rKiNhGqbFkedzvxVWARHIyotSTlPUJ==rKiNhGqbFkedzvxVWARHIyotSTlPJO:rKiNhGqbFkedzvxVWARHIyotSTlPUJ='all'
  rKiNhGqbFkedzvxVWARHIyotSTlPUX,rKiNhGqbFkedzvxVWARHIyotSTlPgO=rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.GetProgramList(rKiNhGqbFkedzvxVWARHIyotSTlPUn,rKiNhGqbFkedzvxVWARHIyotSTlPUC,rKiNhGqbFkedzvxVWARHIyotSTlPgB,rKiNhGqbFkedzvxVWARHIyotSTlPUJ)
  for rKiNhGqbFkedzvxVWARHIyotSTlPUY in rKiNhGqbFkedzvxVWARHIyotSTlPUX:
   rKiNhGqbFkedzvxVWARHIyotSTlPaE =rKiNhGqbFkedzvxVWARHIyotSTlPUY.get('title')
   rKiNhGqbFkedzvxVWARHIyotSTlPgM =rKiNhGqbFkedzvxVWARHIyotSTlPUY.get('thumbnail')
   rKiNhGqbFkedzvxVWARHIyotSTlPgp =rKiNhGqbFkedzvxVWARHIyotSTlPUY.get('synopsis')
   rKiNhGqbFkedzvxVWARHIyotSTlPUc =rKiNhGqbFkedzvxVWARHIyotSTlPUY.get('channel')
   rKiNhGqbFkedzvxVWARHIyotSTlPgm =rKiNhGqbFkedzvxVWARHIyotSTlPUY.get('cast')
   rKiNhGqbFkedzvxVWARHIyotSTlPgj =rKiNhGqbFkedzvxVWARHIyotSTlPUY.get('director')
   rKiNhGqbFkedzvxVWARHIyotSTlPgs=rKiNhGqbFkedzvxVWARHIyotSTlPUY.get('info_genre')
   rKiNhGqbFkedzvxVWARHIyotSTlPgf =rKiNhGqbFkedzvxVWARHIyotSTlPUY.get('year')
   rKiNhGqbFkedzvxVWARHIyotSTlPUQ =rKiNhGqbFkedzvxVWARHIyotSTlPUY.get('premiered')
   rKiNhGqbFkedzvxVWARHIyotSTlPgu =rKiNhGqbFkedzvxVWARHIyotSTlPUY.get('mpaa')
   rKiNhGqbFkedzvxVWARHIyotSTlPUa={'mediatype':'tvshow','title':rKiNhGqbFkedzvxVWARHIyotSTlPaE,'studio':rKiNhGqbFkedzvxVWARHIyotSTlPUc,'cast':rKiNhGqbFkedzvxVWARHIyotSTlPgm,'director':rKiNhGqbFkedzvxVWARHIyotSTlPgj,'genre':rKiNhGqbFkedzvxVWARHIyotSTlPgs,'year':rKiNhGqbFkedzvxVWARHIyotSTlPgf,'premiered':rKiNhGqbFkedzvxVWARHIyotSTlPUQ,'mpaa':rKiNhGqbFkedzvxVWARHIyotSTlPgu,'plot':rKiNhGqbFkedzvxVWARHIyotSTlPgp}
   rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':'EPISODE','programcode':rKiNhGqbFkedzvxVWARHIyotSTlPUY.get('program'),'page':'1'}
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel=rKiNhGqbFkedzvxVWARHIyotSTlPUc,img=rKiNhGqbFkedzvxVWARHIyotSTlPgM,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPUa,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJM,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  if rKiNhGqbFkedzvxVWARHIyotSTlPgO:
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['mode'] ='PROGRAM' 
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['stype'] =rKiNhGqbFkedzvxVWARHIyotSTlPUn
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['orderby'] =rKiNhGqbFkedzvxVWARHIyotSTlPUC
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['page'] =rKiNhGqbFkedzvxVWARHIyotSTlPJs(rKiNhGqbFkedzvxVWARHIyotSTlPgB+1)
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['genreCode']=rKiNhGqbFkedzvxVWARHIyotSTlPUJ 
   rKiNhGqbFkedzvxVWARHIyotSTlPaE='[B]%s >>[/B]'%'다음 페이지'
   rKiNhGqbFkedzvxVWARHIyotSTlPUg=rKiNhGqbFkedzvxVWARHIyotSTlPJs(rKiNhGqbFkedzvxVWARHIyotSTlPgB+1)
   rKiNhGqbFkedzvxVWARHIyotSTlPap=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel=rKiNhGqbFkedzvxVWARHIyotSTlPUg,img=rKiNhGqbFkedzvxVWARHIyotSTlPap,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPJO,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJM,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  if rKiNhGqbFkedzvxVWARHIyotSTlPJj(rKiNhGqbFkedzvxVWARHIyotSTlPUX)>0:xbmcplugin.endOfDirectory(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle,cacheToDisc=rKiNhGqbFkedzvxVWARHIyotSTlPJp)
 def dp_Episode_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE):
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.SaveCredential(rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_winCredential())
  rKiNhGqbFkedzvxVWARHIyotSTlPUE=rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('programcode')
  rKiNhGqbFkedzvxVWARHIyotSTlPgB =rKiNhGqbFkedzvxVWARHIyotSTlPJL(rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('page'))
  rKiNhGqbFkedzvxVWARHIyotSTlPUB,rKiNhGqbFkedzvxVWARHIyotSTlPgO,rKiNhGqbFkedzvxVWARHIyotSTlPUD=rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.GetEpisodeList(rKiNhGqbFkedzvxVWARHIyotSTlPUE,rKiNhGqbFkedzvxVWARHIyotSTlPgB,orderby=rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_winEpisodeOrderby())
  for rKiNhGqbFkedzvxVWARHIyotSTlPUO in rKiNhGqbFkedzvxVWARHIyotSTlPUB:
   rKiNhGqbFkedzvxVWARHIyotSTlPaE =rKiNhGqbFkedzvxVWARHIyotSTlPUO.get('title')
   rKiNhGqbFkedzvxVWARHIyotSTlPUg =rKiNhGqbFkedzvxVWARHIyotSTlPUO.get('subtitle')
   rKiNhGqbFkedzvxVWARHIyotSTlPgM =rKiNhGqbFkedzvxVWARHIyotSTlPUO.get('thumbnail')
   rKiNhGqbFkedzvxVWARHIyotSTlPgp =rKiNhGqbFkedzvxVWARHIyotSTlPUO.get('synopsis')
   rKiNhGqbFkedzvxVWARHIyotSTlPUL=rKiNhGqbFkedzvxVWARHIyotSTlPUO.get('info_title')
   rKiNhGqbFkedzvxVWARHIyotSTlPUM =rKiNhGqbFkedzvxVWARHIyotSTlPUO.get('aired')
   rKiNhGqbFkedzvxVWARHIyotSTlPUp =rKiNhGqbFkedzvxVWARHIyotSTlPUO.get('studio')
   rKiNhGqbFkedzvxVWARHIyotSTlPUw =rKiNhGqbFkedzvxVWARHIyotSTlPUO.get('frequency')
   rKiNhGqbFkedzvxVWARHIyotSTlPUa={'mediatype':'episode','title':rKiNhGqbFkedzvxVWARHIyotSTlPUL,'aired':rKiNhGqbFkedzvxVWARHIyotSTlPUM,'studio':rKiNhGqbFkedzvxVWARHIyotSTlPUp,'episode':rKiNhGqbFkedzvxVWARHIyotSTlPUw,'plot':rKiNhGqbFkedzvxVWARHIyotSTlPgp}
   rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':'VOD','mediacode':rKiNhGqbFkedzvxVWARHIyotSTlPUO.get('episode'),'stype':'vod','programcode':rKiNhGqbFkedzvxVWARHIyotSTlPUE,'title':rKiNhGqbFkedzvxVWARHIyotSTlPaE,'thumbnail':rKiNhGqbFkedzvxVWARHIyotSTlPgM}
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel=rKiNhGqbFkedzvxVWARHIyotSTlPUg,img=rKiNhGqbFkedzvxVWARHIyotSTlPgM,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPUa,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJp,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  if rKiNhGqbFkedzvxVWARHIyotSTlPgB==1:
   rKiNhGqbFkedzvxVWARHIyotSTlPUa={'plot':'정렬순서를 변경합니다.'}
   rKiNhGqbFkedzvxVWARHIyotSTlPaw={}
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['mode'] ='ORDER_BY' 
   if rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_winEpisodeOrderby()=='desc':
    rKiNhGqbFkedzvxVWARHIyotSTlPaE='정렬순서변경 : 최신화부터 -> 1회부터'
    rKiNhGqbFkedzvxVWARHIyotSTlPaw['orderby']='asc'
   else:
    rKiNhGqbFkedzvxVWARHIyotSTlPaE='정렬순서변경 : 1회부터 -> 최신화부터'
    rKiNhGqbFkedzvxVWARHIyotSTlPaw['orderby']='desc'
   rKiNhGqbFkedzvxVWARHIyotSTlPap=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel='',img=rKiNhGqbFkedzvxVWARHIyotSTlPap,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPUa,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJp,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw,isLink=rKiNhGqbFkedzvxVWARHIyotSTlPJM)
  if rKiNhGqbFkedzvxVWARHIyotSTlPgO:
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['mode'] ='EPISODE' 
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['programcode']=rKiNhGqbFkedzvxVWARHIyotSTlPUE
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['page'] =rKiNhGqbFkedzvxVWARHIyotSTlPJs(rKiNhGqbFkedzvxVWARHIyotSTlPgB+1)
   rKiNhGqbFkedzvxVWARHIyotSTlPaE='[B]%s >>[/B]'%'다음 페이지'
   rKiNhGqbFkedzvxVWARHIyotSTlPUg=rKiNhGqbFkedzvxVWARHIyotSTlPJs(rKiNhGqbFkedzvxVWARHIyotSTlPgB+1)
   rKiNhGqbFkedzvxVWARHIyotSTlPap=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel=rKiNhGqbFkedzvxVWARHIyotSTlPUg,img=rKiNhGqbFkedzvxVWARHIyotSTlPap,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPJO,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJM,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  if rKiNhGqbFkedzvxVWARHIyotSTlPJj(rKiNhGqbFkedzvxVWARHIyotSTlPUB)>0:xbmcplugin.endOfDirectory(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle,cacheToDisc=rKiNhGqbFkedzvxVWARHIyotSTlPJM)
 def dp_setEpOrderby(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE):
  rKiNhGqbFkedzvxVWARHIyotSTlPUC =rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('orderby')
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.set_winEpisodeOrderby(rKiNhGqbFkedzvxVWARHIyotSTlPUC)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE):
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.SaveCredential(rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_winCredential())
  rKiNhGqbFkedzvxVWARHIyotSTlPUn =rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('stype')
  rKiNhGqbFkedzvxVWARHIyotSTlPUC =rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('orderby')
  rKiNhGqbFkedzvxVWARHIyotSTlPgB=rKiNhGqbFkedzvxVWARHIyotSTlPJL(rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('page'))
  rKiNhGqbFkedzvxVWARHIyotSTlPUm,rKiNhGqbFkedzvxVWARHIyotSTlPgO=rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.GetMovieList(rKiNhGqbFkedzvxVWARHIyotSTlPUn,rKiNhGqbFkedzvxVWARHIyotSTlPUC,rKiNhGqbFkedzvxVWARHIyotSTlPgB)
  for rKiNhGqbFkedzvxVWARHIyotSTlPUj in rKiNhGqbFkedzvxVWARHIyotSTlPUm:
   rKiNhGqbFkedzvxVWARHIyotSTlPaE =rKiNhGqbFkedzvxVWARHIyotSTlPUj.get('title')
   rKiNhGqbFkedzvxVWARHIyotSTlPgM =rKiNhGqbFkedzvxVWARHIyotSTlPUj.get('thumbnail')
   rKiNhGqbFkedzvxVWARHIyotSTlPgp =rKiNhGqbFkedzvxVWARHIyotSTlPUj.get('synopsis')
   rKiNhGqbFkedzvxVWARHIyotSTlPUL =rKiNhGqbFkedzvxVWARHIyotSTlPUj.get('info_title')
   rKiNhGqbFkedzvxVWARHIyotSTlPgf =rKiNhGqbFkedzvxVWARHIyotSTlPUj.get('year')
   rKiNhGqbFkedzvxVWARHIyotSTlPgm =rKiNhGqbFkedzvxVWARHIyotSTlPUj.get('cast')
   rKiNhGqbFkedzvxVWARHIyotSTlPgj =rKiNhGqbFkedzvxVWARHIyotSTlPUj.get('director')
   rKiNhGqbFkedzvxVWARHIyotSTlPgs =rKiNhGqbFkedzvxVWARHIyotSTlPUj.get('info_genre')
   rKiNhGqbFkedzvxVWARHIyotSTlPUs =rKiNhGqbFkedzvxVWARHIyotSTlPUj.get('duration')
   rKiNhGqbFkedzvxVWARHIyotSTlPUQ =rKiNhGqbFkedzvxVWARHIyotSTlPUj.get('premiered')
   rKiNhGqbFkedzvxVWARHIyotSTlPUp =rKiNhGqbFkedzvxVWARHIyotSTlPUj.get('studio')
   rKiNhGqbFkedzvxVWARHIyotSTlPgu =rKiNhGqbFkedzvxVWARHIyotSTlPUj.get('mpaa')
   rKiNhGqbFkedzvxVWARHIyotSTlPUa={'mediatype':'movie','title':rKiNhGqbFkedzvxVWARHIyotSTlPUL,'year':rKiNhGqbFkedzvxVWARHIyotSTlPgf,'cast':rKiNhGqbFkedzvxVWARHIyotSTlPgm,'director':rKiNhGqbFkedzvxVWARHIyotSTlPgj,'genre':rKiNhGqbFkedzvxVWARHIyotSTlPgs,'duration':rKiNhGqbFkedzvxVWARHIyotSTlPUs,'premiered':rKiNhGqbFkedzvxVWARHIyotSTlPUQ,'studio':rKiNhGqbFkedzvxVWARHIyotSTlPUp,'mpaa':rKiNhGqbFkedzvxVWARHIyotSTlPgu,'plot':rKiNhGqbFkedzvxVWARHIyotSTlPgp}
   rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':'MOVIE','mediacode':rKiNhGqbFkedzvxVWARHIyotSTlPUj.get('moviecode'),'stype':'movie','title':rKiNhGqbFkedzvxVWARHIyotSTlPaE,'thumbnail':rKiNhGqbFkedzvxVWARHIyotSTlPgM}
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel='',img=rKiNhGqbFkedzvxVWARHIyotSTlPgM,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPUa,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJp,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  if rKiNhGqbFkedzvxVWARHIyotSTlPgO:
   rKiNhGqbFkedzvxVWARHIyotSTlPaw={}
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['mode'] ='MOVIE_SUB' 
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['orderby']=rKiNhGqbFkedzvxVWARHIyotSTlPUC
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['stype'] =rKiNhGqbFkedzvxVWARHIyotSTlPUn
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['page'] =rKiNhGqbFkedzvxVWARHIyotSTlPJs(rKiNhGqbFkedzvxVWARHIyotSTlPgB+1)
   rKiNhGqbFkedzvxVWARHIyotSTlPaE='[B]%s >>[/B]'%'다음 페이지'
   rKiNhGqbFkedzvxVWARHIyotSTlPUg=rKiNhGqbFkedzvxVWARHIyotSTlPJs(rKiNhGqbFkedzvxVWARHIyotSTlPgB+1)
   rKiNhGqbFkedzvxVWARHIyotSTlPap=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel=rKiNhGqbFkedzvxVWARHIyotSTlPUg,img=rKiNhGqbFkedzvxVWARHIyotSTlPap,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPJO,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJM,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  if rKiNhGqbFkedzvxVWARHIyotSTlPJj(rKiNhGqbFkedzvxVWARHIyotSTlPUm)>0:xbmcplugin.endOfDirectory(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle,cacheToDisc=rKiNhGqbFkedzvxVWARHIyotSTlPJp)
 def dp_Strm_Make(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE):
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.addon_noti('aa')
 def dp_Search_Group(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE):
  if 'search_key' in rKiNhGqbFkedzvxVWARHIyotSTlPgE:
   rKiNhGqbFkedzvxVWARHIyotSTlPUf=rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('search_key')
  else:
   rKiNhGqbFkedzvxVWARHIyotSTlPUf=rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not rKiNhGqbFkedzvxVWARHIyotSTlPUf:
    return
  for rKiNhGqbFkedzvxVWARHIyotSTlPgc in rKiNhGqbFkedzvxVWARHIyotSTlPQC:
   rKiNhGqbFkedzvxVWARHIyotSTlPUu =rKiNhGqbFkedzvxVWARHIyotSTlPgc.get('mode')
   rKiNhGqbFkedzvxVWARHIyotSTlPgX=rKiNhGqbFkedzvxVWARHIyotSTlPgc.get('stype')
   rKiNhGqbFkedzvxVWARHIyotSTlPaE=rKiNhGqbFkedzvxVWARHIyotSTlPgc.get('title')
   (rKiNhGqbFkedzvxVWARHIyotSTlPnQ,rKiNhGqbFkedzvxVWARHIyotSTlPgO)=rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.GetSearchList(rKiNhGqbFkedzvxVWARHIyotSTlPUf,1,rKiNhGqbFkedzvxVWARHIyotSTlPgX)
   rKiNhGqbFkedzvxVWARHIyotSTlPna={'plot':'검색어 : '+rKiNhGqbFkedzvxVWARHIyotSTlPUf+'\n\n'+rKiNhGqbFkedzvxVWARHIyotSTlPQB.Search_FreeList(rKiNhGqbFkedzvxVWARHIyotSTlPnQ)}
   rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':rKiNhGqbFkedzvxVWARHIyotSTlPUu,'stype':rKiNhGqbFkedzvxVWARHIyotSTlPgX,'search_key':rKiNhGqbFkedzvxVWARHIyotSTlPUf,'page':'1',}
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel='',img='',infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPna,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJM,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  if rKiNhGqbFkedzvxVWARHIyotSTlPJj(rKiNhGqbFkedzvxVWARHIyotSTlPQC)>0:xbmcplugin.endOfDirectory(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle,cacheToDisc=rKiNhGqbFkedzvxVWARHIyotSTlPJM)
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.Save_Searched_List(rKiNhGqbFkedzvxVWARHIyotSTlPUf)
 def Search_FreeList(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPnO):
  rKiNhGqbFkedzvxVWARHIyotSTlPng=''
  rKiNhGqbFkedzvxVWARHIyotSTlPnU=7
  try:
   if rKiNhGqbFkedzvxVWARHIyotSTlPJj(rKiNhGqbFkedzvxVWARHIyotSTlPnO)==0:return '검색결과 없음'
   for i in rKiNhGqbFkedzvxVWARHIyotSTlPJf(rKiNhGqbFkedzvxVWARHIyotSTlPJj(rKiNhGqbFkedzvxVWARHIyotSTlPnO)):
    if i>=rKiNhGqbFkedzvxVWARHIyotSTlPnU:
     rKiNhGqbFkedzvxVWARHIyotSTlPng=rKiNhGqbFkedzvxVWARHIyotSTlPng+'...'
     break
    rKiNhGqbFkedzvxVWARHIyotSTlPng=rKiNhGqbFkedzvxVWARHIyotSTlPng+rKiNhGqbFkedzvxVWARHIyotSTlPnO[i]['title']+'\n'
  except:
   return ''
  return rKiNhGqbFkedzvxVWARHIyotSTlPng
 def dp_Search_History(rKiNhGqbFkedzvxVWARHIyotSTlPQB):
  rKiNhGqbFkedzvxVWARHIyotSTlPnC=rKiNhGqbFkedzvxVWARHIyotSTlPQB.Load_List_File('search')
  for rKiNhGqbFkedzvxVWARHIyotSTlPnJ in rKiNhGqbFkedzvxVWARHIyotSTlPnC:
   rKiNhGqbFkedzvxVWARHIyotSTlPnX=rKiNhGqbFkedzvxVWARHIyotSTlPJm(urllib.parse.parse_qsl(rKiNhGqbFkedzvxVWARHIyotSTlPnJ))
   rKiNhGqbFkedzvxVWARHIyotSTlPnY=rKiNhGqbFkedzvxVWARHIyotSTlPnX.get('skey').strip()
   rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':'SEARCH_GROUP','search_key':rKiNhGqbFkedzvxVWARHIyotSTlPnY,}
   rKiNhGqbFkedzvxVWARHIyotSTlPnc={'mode':'SEARCH_REMOVE','stype':'ONE','skey':rKiNhGqbFkedzvxVWARHIyotSTlPnY,}
   rKiNhGqbFkedzvxVWARHIyotSTlPnE=urllib.parse.urlencode(rKiNhGqbFkedzvxVWARHIyotSTlPnc)
   rKiNhGqbFkedzvxVWARHIyotSTlPnB=[('선택된 검색어 ( %s ) 삭제'%(rKiNhGqbFkedzvxVWARHIyotSTlPnY),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(rKiNhGqbFkedzvxVWARHIyotSTlPnE))]
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPnY,sublabel='',img=rKiNhGqbFkedzvxVWARHIyotSTlPJO,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPJO,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJM,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw,ContextMenu=rKiNhGqbFkedzvxVWARHIyotSTlPnB)
  rKiNhGqbFkedzvxVWARHIyotSTlPUa={'plot':'검색목록 전체를 삭제합니다.'}
  rKiNhGqbFkedzvxVWARHIyotSTlPaE='*** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) ***'
  rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  rKiNhGqbFkedzvxVWARHIyotSTlPap=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel='',img=rKiNhGqbFkedzvxVWARHIyotSTlPap,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPUa,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJp,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw,isLink=rKiNhGqbFkedzvxVWARHIyotSTlPJM)
  xbmcplugin.endOfDirectory(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle,cacheToDisc=rKiNhGqbFkedzvxVWARHIyotSTlPJp)
 def dp_Search_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE):
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.SaveCredential(rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_winCredential())
  rKiNhGqbFkedzvxVWARHIyotSTlPgB =rKiNhGqbFkedzvxVWARHIyotSTlPJL(rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('page'))
  rKiNhGqbFkedzvxVWARHIyotSTlPgX =rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('stype')
  if 'search_key' in rKiNhGqbFkedzvxVWARHIyotSTlPgE:
   rKiNhGqbFkedzvxVWARHIyotSTlPUf=rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('search_key')
  else:
   rKiNhGqbFkedzvxVWARHIyotSTlPUf=rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not rKiNhGqbFkedzvxVWARHIyotSTlPUf:
    xbmcplugin.endOfDirectory(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle)
    return
  rKiNhGqbFkedzvxVWARHIyotSTlPnQ,rKiNhGqbFkedzvxVWARHIyotSTlPgO=rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.GetSearchList(rKiNhGqbFkedzvxVWARHIyotSTlPUf,rKiNhGqbFkedzvxVWARHIyotSTlPgB,rKiNhGqbFkedzvxVWARHIyotSTlPgX)
  for rKiNhGqbFkedzvxVWARHIyotSTlPnO in rKiNhGqbFkedzvxVWARHIyotSTlPnQ:
   rKiNhGqbFkedzvxVWARHIyotSTlPaE =rKiNhGqbFkedzvxVWARHIyotSTlPnO.get('title')
   rKiNhGqbFkedzvxVWARHIyotSTlPgM =rKiNhGqbFkedzvxVWARHIyotSTlPnO.get('thumbnail')
   rKiNhGqbFkedzvxVWARHIyotSTlPgp =rKiNhGqbFkedzvxVWARHIyotSTlPnO.get('synopsis')
   rKiNhGqbFkedzvxVWARHIyotSTlPnL =rKiNhGqbFkedzvxVWARHIyotSTlPnO.get('program')
   rKiNhGqbFkedzvxVWARHIyotSTlPgm =rKiNhGqbFkedzvxVWARHIyotSTlPnO.get('cast')
   rKiNhGqbFkedzvxVWARHIyotSTlPgj =rKiNhGqbFkedzvxVWARHIyotSTlPnO.get('director')
   rKiNhGqbFkedzvxVWARHIyotSTlPgs=rKiNhGqbFkedzvxVWARHIyotSTlPnO.get('info_genre')
   rKiNhGqbFkedzvxVWARHIyotSTlPUs =rKiNhGqbFkedzvxVWARHIyotSTlPnO.get('duration')
   rKiNhGqbFkedzvxVWARHIyotSTlPgu =rKiNhGqbFkedzvxVWARHIyotSTlPnO.get('mpaa')
   rKiNhGqbFkedzvxVWARHIyotSTlPgf =rKiNhGqbFkedzvxVWARHIyotSTlPnO.get('year')
   rKiNhGqbFkedzvxVWARHIyotSTlPUM =rKiNhGqbFkedzvxVWARHIyotSTlPnO.get('aired')
   rKiNhGqbFkedzvxVWARHIyotSTlPUa={'mediatype':'tvshow' if rKiNhGqbFkedzvxVWARHIyotSTlPgX=='vod' else 'movie','title':rKiNhGqbFkedzvxVWARHIyotSTlPaE,'cast':rKiNhGqbFkedzvxVWARHIyotSTlPgm,'director':rKiNhGqbFkedzvxVWARHIyotSTlPgj,'genre':rKiNhGqbFkedzvxVWARHIyotSTlPgs,'duration':rKiNhGqbFkedzvxVWARHIyotSTlPUs,'mpaa':rKiNhGqbFkedzvxVWARHIyotSTlPgu,'year':rKiNhGqbFkedzvxVWARHIyotSTlPgf,'aired':rKiNhGqbFkedzvxVWARHIyotSTlPUM,'plot':'%s\n\n%s'%(rKiNhGqbFkedzvxVWARHIyotSTlPaE,rKiNhGqbFkedzvxVWARHIyotSTlPgp)}
   if rKiNhGqbFkedzvxVWARHIyotSTlPgX=='vod':
    rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':'EPISODE','programcode':rKiNhGqbFkedzvxVWARHIyotSTlPnO.get('program'),'page':'1'}
    rKiNhGqbFkedzvxVWARHIyotSTlPam=rKiNhGqbFkedzvxVWARHIyotSTlPJM
   else:
    rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':'MOVIE','mediacode':rKiNhGqbFkedzvxVWARHIyotSTlPnO.get('movie'),'stype':'movie','title':rKiNhGqbFkedzvxVWARHIyotSTlPaE,'thumbnail':rKiNhGqbFkedzvxVWARHIyotSTlPgM}
    rKiNhGqbFkedzvxVWARHIyotSTlPam=rKiNhGqbFkedzvxVWARHIyotSTlPJp
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel='',img=rKiNhGqbFkedzvxVWARHIyotSTlPgM,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPUa,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPam,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  if rKiNhGqbFkedzvxVWARHIyotSTlPgO:
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['mode'] ='SEARCH' 
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['search_key']=rKiNhGqbFkedzvxVWARHIyotSTlPUf
   rKiNhGqbFkedzvxVWARHIyotSTlPaw['page'] =rKiNhGqbFkedzvxVWARHIyotSTlPJs(rKiNhGqbFkedzvxVWARHIyotSTlPgB+1)
   rKiNhGqbFkedzvxVWARHIyotSTlPaE='[B]%s >>[/B]'%'다음 페이지'
   rKiNhGqbFkedzvxVWARHIyotSTlPUg=rKiNhGqbFkedzvxVWARHIyotSTlPJs(rKiNhGqbFkedzvxVWARHIyotSTlPgB+1)
   rKiNhGqbFkedzvxVWARHIyotSTlPap=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel=rKiNhGqbFkedzvxVWARHIyotSTlPUg,img=rKiNhGqbFkedzvxVWARHIyotSTlPap,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPJO,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJM,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  xbmcplugin.endOfDirectory(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle,cacheToDisc=rKiNhGqbFkedzvxVWARHIyotSTlPJp)
 def Delete_List_File(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgX,skey='-'):
  if rKiNhGqbFkedzvxVWARHIyotSTlPgX=='ALL':
   try:
    rKiNhGqbFkedzvxVWARHIyotSTlPnM=rKiNhGqbFkedzvxVWARHIyotSTlPQE
    fp=rKiNhGqbFkedzvxVWARHIyotSTlPJu(rKiNhGqbFkedzvxVWARHIyotSTlPnM,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    rKiNhGqbFkedzvxVWARHIyotSTlPJO
  elif rKiNhGqbFkedzvxVWARHIyotSTlPgX=='ONE':
   try:
    rKiNhGqbFkedzvxVWARHIyotSTlPnM=rKiNhGqbFkedzvxVWARHIyotSTlPQE
    rKiNhGqbFkedzvxVWARHIyotSTlPnp=rKiNhGqbFkedzvxVWARHIyotSTlPQB.Load_List_File('search') 
    fp=rKiNhGqbFkedzvxVWARHIyotSTlPJu(rKiNhGqbFkedzvxVWARHIyotSTlPnM,'w',-1,'utf-8')
    for rKiNhGqbFkedzvxVWARHIyotSTlPnw in rKiNhGqbFkedzvxVWARHIyotSTlPnp:
     rKiNhGqbFkedzvxVWARHIyotSTlPnm=rKiNhGqbFkedzvxVWARHIyotSTlPJm(urllib.parse.parse_qsl(rKiNhGqbFkedzvxVWARHIyotSTlPnw))
     rKiNhGqbFkedzvxVWARHIyotSTlPnj=rKiNhGqbFkedzvxVWARHIyotSTlPnm.get('skey').strip()
     if skey!=rKiNhGqbFkedzvxVWARHIyotSTlPnj:
      fp.write(rKiNhGqbFkedzvxVWARHIyotSTlPnw)
    fp.close()
   except:
    rKiNhGqbFkedzvxVWARHIyotSTlPJO
  elif rKiNhGqbFkedzvxVWARHIyotSTlPgX in['vod','movie']:
   try:
    rKiNhGqbFkedzvxVWARHIyotSTlPnM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rKiNhGqbFkedzvxVWARHIyotSTlPgX))
    fp=rKiNhGqbFkedzvxVWARHIyotSTlPJu(rKiNhGqbFkedzvxVWARHIyotSTlPnM,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    rKiNhGqbFkedzvxVWARHIyotSTlPJO
 def dp_Listfile_Delete(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE):
  rKiNhGqbFkedzvxVWARHIyotSTlPgX=rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('stype')
  rKiNhGqbFkedzvxVWARHIyotSTlPnY =rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('skey')
  rKiNhGqbFkedzvxVWARHIyotSTlPQp=xbmcgui.Dialog()
  if rKiNhGqbFkedzvxVWARHIyotSTlPgX=='ALL':
   rKiNhGqbFkedzvxVWARHIyotSTlPgU=rKiNhGqbFkedzvxVWARHIyotSTlPQp.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif rKiNhGqbFkedzvxVWARHIyotSTlPgX=='ONE':
   rKiNhGqbFkedzvxVWARHIyotSTlPgU=rKiNhGqbFkedzvxVWARHIyotSTlPQp.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif rKiNhGqbFkedzvxVWARHIyotSTlPgX in['vod','movie']:
   rKiNhGqbFkedzvxVWARHIyotSTlPgU=rKiNhGqbFkedzvxVWARHIyotSTlPQp.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if rKiNhGqbFkedzvxVWARHIyotSTlPgU==rKiNhGqbFkedzvxVWARHIyotSTlPJp:sys.exit()
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.Delete_List_File(rKiNhGqbFkedzvxVWARHIyotSTlPgX,skey=rKiNhGqbFkedzvxVWARHIyotSTlPnY)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgX): 
  try:
   if rKiNhGqbFkedzvxVWARHIyotSTlPgX=='search':
    rKiNhGqbFkedzvxVWARHIyotSTlPnM=rKiNhGqbFkedzvxVWARHIyotSTlPQE
   elif rKiNhGqbFkedzvxVWARHIyotSTlPgX in['vod','movie']:
    rKiNhGqbFkedzvxVWARHIyotSTlPnM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rKiNhGqbFkedzvxVWARHIyotSTlPgX))
   else:
    return[]
   fp=rKiNhGqbFkedzvxVWARHIyotSTlPJu(rKiNhGqbFkedzvxVWARHIyotSTlPnM,'r',-1,'utf-8')
   rKiNhGqbFkedzvxVWARHIyotSTlPns=fp.readlines()
   fp.close()
  except:
   rKiNhGqbFkedzvxVWARHIyotSTlPns=[]
  return rKiNhGqbFkedzvxVWARHIyotSTlPns
 def Save_Watched_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgX,rKiNhGqbFkedzvxVWARHIyotSTlPQL):
  try:
   rKiNhGqbFkedzvxVWARHIyotSTlPnf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rKiNhGqbFkedzvxVWARHIyotSTlPgX))
   rKiNhGqbFkedzvxVWARHIyotSTlPnp=rKiNhGqbFkedzvxVWARHIyotSTlPQB.Load_List_File(rKiNhGqbFkedzvxVWARHIyotSTlPgX) 
   fp=rKiNhGqbFkedzvxVWARHIyotSTlPJu(rKiNhGqbFkedzvxVWARHIyotSTlPnf,'w',-1,'utf-8')
   rKiNhGqbFkedzvxVWARHIyotSTlPnu=urllib.parse.urlencode(rKiNhGqbFkedzvxVWARHIyotSTlPQL)
   rKiNhGqbFkedzvxVWARHIyotSTlPnu=rKiNhGqbFkedzvxVWARHIyotSTlPnu+'\n'
   fp.write(rKiNhGqbFkedzvxVWARHIyotSTlPnu)
   rKiNhGqbFkedzvxVWARHIyotSTlPCQ=0
   for rKiNhGqbFkedzvxVWARHIyotSTlPnw in rKiNhGqbFkedzvxVWARHIyotSTlPnp:
    rKiNhGqbFkedzvxVWARHIyotSTlPnm=rKiNhGqbFkedzvxVWARHIyotSTlPJm(urllib.parse.parse_qsl(rKiNhGqbFkedzvxVWARHIyotSTlPnw))
    rKiNhGqbFkedzvxVWARHIyotSTlPCa=rKiNhGqbFkedzvxVWARHIyotSTlPQL.get('code').strip()
    rKiNhGqbFkedzvxVWARHIyotSTlPCg=rKiNhGqbFkedzvxVWARHIyotSTlPnm.get('code').strip()
    if rKiNhGqbFkedzvxVWARHIyotSTlPgX=='vod' and rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_settings_direct_replay()==rKiNhGqbFkedzvxVWARHIyotSTlPJM:
     rKiNhGqbFkedzvxVWARHIyotSTlPCa=rKiNhGqbFkedzvxVWARHIyotSTlPQL.get('videoid').strip()
     rKiNhGqbFkedzvxVWARHIyotSTlPCg=rKiNhGqbFkedzvxVWARHIyotSTlPnm.get('videoid').strip()if rKiNhGqbFkedzvxVWARHIyotSTlPCg!=rKiNhGqbFkedzvxVWARHIyotSTlPJO else '-'
    if rKiNhGqbFkedzvxVWARHIyotSTlPCa!=rKiNhGqbFkedzvxVWARHIyotSTlPCg:
     fp.write(rKiNhGqbFkedzvxVWARHIyotSTlPnw)
     rKiNhGqbFkedzvxVWARHIyotSTlPCQ+=1
     if rKiNhGqbFkedzvxVWARHIyotSTlPCQ>=50:break
   fp.close()
  except:
   rKiNhGqbFkedzvxVWARHIyotSTlPJO
 def dp_Watch_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE):
  rKiNhGqbFkedzvxVWARHIyotSTlPgX =rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('stype')
  rKiNhGqbFkedzvxVWARHIyotSTlPaJ=rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_settings_direct_replay()
  if rKiNhGqbFkedzvxVWARHIyotSTlPgX=='-':
   for rKiNhGqbFkedzvxVWARHIyotSTlPgc in rKiNhGqbFkedzvxVWARHIyotSTlPQn:
    rKiNhGqbFkedzvxVWARHIyotSTlPaE=rKiNhGqbFkedzvxVWARHIyotSTlPgc.get('title')
    rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':rKiNhGqbFkedzvxVWARHIyotSTlPgc.get('mode'),'stype':rKiNhGqbFkedzvxVWARHIyotSTlPgc.get('stype')}
    rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel='',img='',infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPJO,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJM,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
   if rKiNhGqbFkedzvxVWARHIyotSTlPJj(rKiNhGqbFkedzvxVWARHIyotSTlPQn)>0:xbmcplugin.endOfDirectory(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle)
  else:
   rKiNhGqbFkedzvxVWARHIyotSTlPCU=rKiNhGqbFkedzvxVWARHIyotSTlPQB.Load_List_File(rKiNhGqbFkedzvxVWARHIyotSTlPgX)
   for rKiNhGqbFkedzvxVWARHIyotSTlPCn in rKiNhGqbFkedzvxVWARHIyotSTlPCU:
    rKiNhGqbFkedzvxVWARHIyotSTlPnX=rKiNhGqbFkedzvxVWARHIyotSTlPJm(urllib.parse.parse_qsl(rKiNhGqbFkedzvxVWARHIyotSTlPCn))
    rKiNhGqbFkedzvxVWARHIyotSTlPCJ =rKiNhGqbFkedzvxVWARHIyotSTlPnX.get('code').strip()
    rKiNhGqbFkedzvxVWARHIyotSTlPaE =rKiNhGqbFkedzvxVWARHIyotSTlPnX.get('title').strip()
    rKiNhGqbFkedzvxVWARHIyotSTlPgM=rKiNhGqbFkedzvxVWARHIyotSTlPnX.get('img').strip()
    rKiNhGqbFkedzvxVWARHIyotSTlPCX =rKiNhGqbFkedzvxVWARHIyotSTlPnX.get('videoid').strip()
    try:
     rKiNhGqbFkedzvxVWARHIyotSTlPgM=rKiNhGqbFkedzvxVWARHIyotSTlPgM.replace('\'','\"')
     rKiNhGqbFkedzvxVWARHIyotSTlPgM=json.loads(rKiNhGqbFkedzvxVWARHIyotSTlPgM)
    except:
     rKiNhGqbFkedzvxVWARHIyotSTlPJO
    rKiNhGqbFkedzvxVWARHIyotSTlPUa={}
    rKiNhGqbFkedzvxVWARHIyotSTlPUa['plot']=rKiNhGqbFkedzvxVWARHIyotSTlPaE
    if rKiNhGqbFkedzvxVWARHIyotSTlPgX=='vod':
     if rKiNhGqbFkedzvxVWARHIyotSTlPaJ==rKiNhGqbFkedzvxVWARHIyotSTlPJp or rKiNhGqbFkedzvxVWARHIyotSTlPCX==rKiNhGqbFkedzvxVWARHIyotSTlPJO:
      rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':'EPISODE','programcode':rKiNhGqbFkedzvxVWARHIyotSTlPCJ,'page':'1'}
      rKiNhGqbFkedzvxVWARHIyotSTlPam=rKiNhGqbFkedzvxVWARHIyotSTlPJM
     else:
      rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':'VOD','mediacode':rKiNhGqbFkedzvxVWARHIyotSTlPCX,'stype':'vod','programcode':rKiNhGqbFkedzvxVWARHIyotSTlPCJ,'title':rKiNhGqbFkedzvxVWARHIyotSTlPaE,'thumbnail':rKiNhGqbFkedzvxVWARHIyotSTlPgM}
      rKiNhGqbFkedzvxVWARHIyotSTlPam=rKiNhGqbFkedzvxVWARHIyotSTlPJp
    else:
     rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':'MOVIE','mediacode':rKiNhGqbFkedzvxVWARHIyotSTlPCJ,'stype':'movie','title':rKiNhGqbFkedzvxVWARHIyotSTlPaE,'thumbnail':rKiNhGqbFkedzvxVWARHIyotSTlPgM}
     rKiNhGqbFkedzvxVWARHIyotSTlPam=rKiNhGqbFkedzvxVWARHIyotSTlPJp
    rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel='',img=rKiNhGqbFkedzvxVWARHIyotSTlPgM,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPUa,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPam,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw)
   rKiNhGqbFkedzvxVWARHIyotSTlPUa={'plot':'시청목록을 삭제합니다.'}
   rKiNhGqbFkedzvxVWARHIyotSTlPaE='*** 시청목록 삭제 ***'
   rKiNhGqbFkedzvxVWARHIyotSTlPaw={'mode':'MYVIEW_REMOVE','stype':rKiNhGqbFkedzvxVWARHIyotSTlPgX,'skey':'-',}
   rKiNhGqbFkedzvxVWARHIyotSTlPap=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.add_dir(rKiNhGqbFkedzvxVWARHIyotSTlPaE,sublabel='',img=rKiNhGqbFkedzvxVWARHIyotSTlPap,infoLabels=rKiNhGqbFkedzvxVWARHIyotSTlPUa,isFolder=rKiNhGqbFkedzvxVWARHIyotSTlPJp,params=rKiNhGqbFkedzvxVWARHIyotSTlPaw,isLink=rKiNhGqbFkedzvxVWARHIyotSTlPJM)
   xbmcplugin.endOfDirectory(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle,cacheToDisc=rKiNhGqbFkedzvxVWARHIyotSTlPJp)
 def Save_Searched_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPUf):
  try:
   rKiNhGqbFkedzvxVWARHIyotSTlPCY=rKiNhGqbFkedzvxVWARHIyotSTlPQE
   rKiNhGqbFkedzvxVWARHIyotSTlPnp=rKiNhGqbFkedzvxVWARHIyotSTlPQB.Load_List_File('search') 
   rKiNhGqbFkedzvxVWARHIyotSTlPCc={'skey':rKiNhGqbFkedzvxVWARHIyotSTlPUf.strip()}
   fp=rKiNhGqbFkedzvxVWARHIyotSTlPJu(rKiNhGqbFkedzvxVWARHIyotSTlPCY,'w',-1,'utf-8')
   rKiNhGqbFkedzvxVWARHIyotSTlPnu=urllib.parse.urlencode(rKiNhGqbFkedzvxVWARHIyotSTlPCc)
   rKiNhGqbFkedzvxVWARHIyotSTlPnu=rKiNhGqbFkedzvxVWARHIyotSTlPnu+'\n'
   fp.write(rKiNhGqbFkedzvxVWARHIyotSTlPnu)
   rKiNhGqbFkedzvxVWARHIyotSTlPCQ=0
   for rKiNhGqbFkedzvxVWARHIyotSTlPnw in rKiNhGqbFkedzvxVWARHIyotSTlPnp:
    rKiNhGqbFkedzvxVWARHIyotSTlPnm=rKiNhGqbFkedzvxVWARHIyotSTlPJm(urllib.parse.parse_qsl(rKiNhGqbFkedzvxVWARHIyotSTlPnw))
    rKiNhGqbFkedzvxVWARHIyotSTlPCa=rKiNhGqbFkedzvxVWARHIyotSTlPCc.get('skey').strip()
    rKiNhGqbFkedzvxVWARHIyotSTlPCg=rKiNhGqbFkedzvxVWARHIyotSTlPnm.get('skey').strip()
    if rKiNhGqbFkedzvxVWARHIyotSTlPCa!=rKiNhGqbFkedzvxVWARHIyotSTlPCg:
     fp.write(rKiNhGqbFkedzvxVWARHIyotSTlPnw)
     rKiNhGqbFkedzvxVWARHIyotSTlPCQ+=1
     if rKiNhGqbFkedzvxVWARHIyotSTlPCQ>=50:break
   fp.close()
  except:
   rKiNhGqbFkedzvxVWARHIyotSTlPJO
 def play_VIDEO(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE):
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.SaveCredential(rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_winCredential())
  rKiNhGqbFkedzvxVWARHIyotSTlPCE =rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('mediacode')
  rKiNhGqbFkedzvxVWARHIyotSTlPgX =rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('stype')
  rKiNhGqbFkedzvxVWARHIyotSTlPCB =rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('pvrmode')
  rKiNhGqbFkedzvxVWARHIyotSTlPCD=rKiNhGqbFkedzvxVWARHIyotSTlPQB.get_selQuality(rKiNhGqbFkedzvxVWARHIyotSTlPgX)
  rKiNhGqbFkedzvxVWARHIyotSTlPCO,rKiNhGqbFkedzvxVWARHIyotSTlPCL=rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.GetBroadURL(rKiNhGqbFkedzvxVWARHIyotSTlPCE,rKiNhGqbFkedzvxVWARHIyotSTlPCD,rKiNhGqbFkedzvxVWARHIyotSTlPgX,rKiNhGqbFkedzvxVWARHIyotSTlPCB)
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.addon_log('qt, stype, url : %s - %s - %s'%(rKiNhGqbFkedzvxVWARHIyotSTlPJs(rKiNhGqbFkedzvxVWARHIyotSTlPCD),rKiNhGqbFkedzvxVWARHIyotSTlPgX,rKiNhGqbFkedzvxVWARHIyotSTlPCO))
  if rKiNhGqbFkedzvxVWARHIyotSTlPCO=='':
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.addon_noti(__language__(30908).encode('utf8'))
   return
  rKiNhGqbFkedzvxVWARHIyotSTlPCM =rKiNhGqbFkedzvxVWARHIyotSTlPCO.find('Policy=')
  if rKiNhGqbFkedzvxVWARHIyotSTlPCM!=-1:
   rKiNhGqbFkedzvxVWARHIyotSTlPCp =rKiNhGqbFkedzvxVWARHIyotSTlPCO.split('?')[0]
   rKiNhGqbFkedzvxVWARHIyotSTlPCw=rKiNhGqbFkedzvxVWARHIyotSTlPJm(urllib.parse.parse_qsl(urllib.parse.urlsplit(rKiNhGqbFkedzvxVWARHIyotSTlPCO).query))
   rKiNhGqbFkedzvxVWARHIyotSTlPCw=urllib.parse.urlencode(rKiNhGqbFkedzvxVWARHIyotSTlPCw)
   rKiNhGqbFkedzvxVWARHIyotSTlPCw=rKiNhGqbFkedzvxVWARHIyotSTlPCw.replace('&',';')
   rKiNhGqbFkedzvxVWARHIyotSTlPCw=rKiNhGqbFkedzvxVWARHIyotSTlPCw.replace('Policy','CloudFront-Policy')
   rKiNhGqbFkedzvxVWARHIyotSTlPCw=rKiNhGqbFkedzvxVWARHIyotSTlPCw.replace('Signature','CloudFront-Signature')
   rKiNhGqbFkedzvxVWARHIyotSTlPCw=rKiNhGqbFkedzvxVWARHIyotSTlPCw.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   rKiNhGqbFkedzvxVWARHIyotSTlPCm='%s|Cookie=%s'%(rKiNhGqbFkedzvxVWARHIyotSTlPCp,rKiNhGqbFkedzvxVWARHIyotSTlPCw)
  else:
   rKiNhGqbFkedzvxVWARHIyotSTlPCm=rKiNhGqbFkedzvxVWARHIyotSTlPCO
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.addon_log(rKiNhGqbFkedzvxVWARHIyotSTlPCm)
  rKiNhGqbFkedzvxVWARHIyotSTlPCj=xbmcgui.ListItem(path=rKiNhGqbFkedzvxVWARHIyotSTlPCm)
  if rKiNhGqbFkedzvxVWARHIyotSTlPCL!='':
   rKiNhGqbFkedzvxVWARHIyotSTlPCs=rKiNhGqbFkedzvxVWARHIyotSTlPCL
   rKiNhGqbFkedzvxVWARHIyotSTlPCf ='https://cj.drmkeyserver.com/widevine_license'
   rKiNhGqbFkedzvxVWARHIyotSTlPCu ='mpd'
   rKiNhGqbFkedzvxVWARHIyotSTlPJQ ='com.widevine.alpha'
   rKiNhGqbFkedzvxVWARHIyotSTlPJa =inputstreamhelper.Helper(rKiNhGqbFkedzvxVWARHIyotSTlPCu,drm='widevine')
   if rKiNhGqbFkedzvxVWARHIyotSTlPJa.check_inputstream():
    rKiNhGqbFkedzvxVWARHIyotSTlPJg={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%rKiNhGqbFkedzvxVWARHIyotSTlPCE,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.USER_AGENT,'AcquireLicenseAssertion':rKiNhGqbFkedzvxVWARHIyotSTlPCs,'Host':'cj.drmkeyserver.com'}
    rKiNhGqbFkedzvxVWARHIyotSTlPJU=rKiNhGqbFkedzvxVWARHIyotSTlPCf+'|'+urllib.parse.urlencode(rKiNhGqbFkedzvxVWARHIyotSTlPJg)+'|R{SSM}|'
    rKiNhGqbFkedzvxVWARHIyotSTlPCj.setProperty('inputstream',rKiNhGqbFkedzvxVWARHIyotSTlPJa.inputstream_addon)
    rKiNhGqbFkedzvxVWARHIyotSTlPCj.setProperty('inputstream.adaptive.manifest_type',rKiNhGqbFkedzvxVWARHIyotSTlPCu)
    rKiNhGqbFkedzvxVWARHIyotSTlPCj.setProperty('inputstream.adaptive.license_type',rKiNhGqbFkedzvxVWARHIyotSTlPJQ)
    rKiNhGqbFkedzvxVWARHIyotSTlPCj.setProperty('inputstream.adaptive.license_key',rKiNhGqbFkedzvxVWARHIyotSTlPJU)
    rKiNhGqbFkedzvxVWARHIyotSTlPCj.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.USER_AGENT))
  xbmcplugin.setResolvedUrl(rKiNhGqbFkedzvxVWARHIyotSTlPQB._addon_handle,rKiNhGqbFkedzvxVWARHIyotSTlPJM,rKiNhGqbFkedzvxVWARHIyotSTlPCj)
  try:
   if rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('mode')in['VOD','MOVIE']and rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('title'):
    rKiNhGqbFkedzvxVWARHIyotSTlPaw={'code':rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('programcode')if rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('mode')=='VOD' else rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('mediacode'),'img':rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('thumbnail'),'title':rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('title'),'videoid':rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('mediacode')}
    rKiNhGqbFkedzvxVWARHIyotSTlPQB.Save_Watched_List(rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('stype'),rKiNhGqbFkedzvxVWARHIyotSTlPaw)
  except:
   rKiNhGqbFkedzvxVWARHIyotSTlPJO
 def logout(rKiNhGqbFkedzvxVWARHIyotSTlPQB):
  rKiNhGqbFkedzvxVWARHIyotSTlPQp=xbmcgui.Dialog()
  rKiNhGqbFkedzvxVWARHIyotSTlPgU=rKiNhGqbFkedzvxVWARHIyotSTlPQp.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if rKiNhGqbFkedzvxVWARHIyotSTlPgU==rKiNhGqbFkedzvxVWARHIyotSTlPJp:sys.exit()
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.wininfo_clear()
  if os.path.isfile(rKiNhGqbFkedzvxVWARHIyotSTlPQc):os.remove(rKiNhGqbFkedzvxVWARHIyotSTlPQc)
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(rKiNhGqbFkedzvxVWARHIyotSTlPQB):
  rKiNhGqbFkedzvxVWARHIyotSTlPaX=xbmcgui.Window(10000)
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_TOKEN','')
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_USERINFO','')
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_UUID','')
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_LOGINTIME','')
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_MAINTOKEN','')
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_COOKIEKEY','')
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(rKiNhGqbFkedzvxVWARHIyotSTlPQB):
  rKiNhGqbFkedzvxVWARHIyotSTlPJn =rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.Get_Now_Datetime()
  rKiNhGqbFkedzvxVWARHIyotSTlPJC=rKiNhGqbFkedzvxVWARHIyotSTlPJn+datetime.timedelta(days=rKiNhGqbFkedzvxVWARHIyotSTlPJL(__addon__.getSetting('cache_ttl')))
  rKiNhGqbFkedzvxVWARHIyotSTlPaX=xbmcgui.Window(10000)
  rKiNhGqbFkedzvxVWARHIyotSTlPJX={'tving_token':rKiNhGqbFkedzvxVWARHIyotSTlPaX.getProperty('TVING_M_TOKEN'),'tving_userinfo':rKiNhGqbFkedzvxVWARHIyotSTlPaX.getProperty('TVING_M_USERINFO'),'tving_uuid':rKiNhGqbFkedzvxVWARHIyotSTlPaX.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':rKiNhGqbFkedzvxVWARHIyotSTlPJC.strftime('%Y-%m-%d'),'tving_maintoken':rKiNhGqbFkedzvxVWARHIyotSTlPaX.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':rKiNhGqbFkedzvxVWARHIyotSTlPaX.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':rKiNhGqbFkedzvxVWARHIyotSTlPaX.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=rKiNhGqbFkedzvxVWARHIyotSTlPJu(rKiNhGqbFkedzvxVWARHIyotSTlPQc,'w',-1,'utf-8')
   json.dump(rKiNhGqbFkedzvxVWARHIyotSTlPJX,fp)
   fp.close()
  except rKiNhGqbFkedzvxVWARHIyotSTlPXQ as exception:
   rKiNhGqbFkedzvxVWARHIyotSTlPXa(exception)
 def cookiefile_check(rKiNhGqbFkedzvxVWARHIyotSTlPQB):
  rKiNhGqbFkedzvxVWARHIyotSTlPJX={}
  try: 
   fp=rKiNhGqbFkedzvxVWARHIyotSTlPJu(rKiNhGqbFkedzvxVWARHIyotSTlPQc,'r',-1,'utf-8')
   rKiNhGqbFkedzvxVWARHIyotSTlPJX= json.load(fp)
   fp.close()
  except rKiNhGqbFkedzvxVWARHIyotSTlPXQ as exception:
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.wininfo_clear()
   return rKiNhGqbFkedzvxVWARHIyotSTlPJp
  rKiNhGqbFkedzvxVWARHIyotSTlPaf =__addon__.getSetting('id')
  rKiNhGqbFkedzvxVWARHIyotSTlPau =__addon__.getSetting('pw')
  rKiNhGqbFkedzvxVWARHIyotSTlPJY=__addon__.getSetting('login_type')
  rKiNhGqbFkedzvxVWARHIyotSTlPJc =__addon__.getSetting('selected_profile')
  rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_id']=base64.standard_b64decode(rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_id']).decode('utf-8')
  rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_pw']=base64.standard_b64decode(rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_pw']).decode('utf-8')
  try:
   rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_profile']
  except:
   rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_profile']='0'
  if rKiNhGqbFkedzvxVWARHIyotSTlPaf!=rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_id']or rKiNhGqbFkedzvxVWARHIyotSTlPau!=rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_pw']or rKiNhGqbFkedzvxVWARHIyotSTlPJY!=rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_logintype']or rKiNhGqbFkedzvxVWARHIyotSTlPJc!=rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_profile']:
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.wininfo_clear()
   return rKiNhGqbFkedzvxVWARHIyotSTlPJp
  rKiNhGqbFkedzvxVWARHIyotSTlPgn =rKiNhGqbFkedzvxVWARHIyotSTlPJL(rKiNhGqbFkedzvxVWARHIyotSTlPQB.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  rKiNhGqbFkedzvxVWARHIyotSTlPJE=rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_limitdate']
  rKiNhGqbFkedzvxVWARHIyotSTlPgC =rKiNhGqbFkedzvxVWARHIyotSTlPJL(re.sub('-','',rKiNhGqbFkedzvxVWARHIyotSTlPJE))
  if rKiNhGqbFkedzvxVWARHIyotSTlPgC<rKiNhGqbFkedzvxVWARHIyotSTlPgn:
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.wininfo_clear()
   return rKiNhGqbFkedzvxVWARHIyotSTlPJp
  rKiNhGqbFkedzvxVWARHIyotSTlPaX=xbmcgui.Window(10000)
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_TOKEN',rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_token'])
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_USERINFO',rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_userinfo'])
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_UUID',rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_uuid'])
  rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_LOGINTIME',rKiNhGqbFkedzvxVWARHIyotSTlPJE)
  try:
   rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_MAINTOKEN',rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_maintoken'])
   rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_COOKIEKEY',rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_cookiekey'])
   rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_LOCKKEY',rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_lockkey'])
  except:
   rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_MAINTOKEN',rKiNhGqbFkedzvxVWARHIyotSTlPJX['tving_token'])
   rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_COOKIEKEY','Y')
   rKiNhGqbFkedzvxVWARHIyotSTlPaX.setProperty('TVING_M_LOCKKEY','N')
  return rKiNhGqbFkedzvxVWARHIyotSTlPJM
 def dp_Global_Search(rKiNhGqbFkedzvxVWARHIyotSTlPQB,rKiNhGqbFkedzvxVWARHIyotSTlPgE):
  rKiNhGqbFkedzvxVWARHIyotSTlPUu=rKiNhGqbFkedzvxVWARHIyotSTlPgE.get('mode')
  if rKiNhGqbFkedzvxVWARHIyotSTlPUu=='TOTAL_SEARCH':
   rKiNhGqbFkedzvxVWARHIyotSTlPJB='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   rKiNhGqbFkedzvxVWARHIyotSTlPJB='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(rKiNhGqbFkedzvxVWARHIyotSTlPJB)
 def tving_main(rKiNhGqbFkedzvxVWARHIyotSTlPQB):
  rKiNhGqbFkedzvxVWARHIyotSTlPUu=rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params.get('mode',rKiNhGqbFkedzvxVWARHIyotSTlPJO)
  if rKiNhGqbFkedzvxVWARHIyotSTlPUu=='LOGOUT':
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.logout()
   return
  rKiNhGqbFkedzvxVWARHIyotSTlPQB.login_main()
  if rKiNhGqbFkedzvxVWARHIyotSTlPUu is rKiNhGqbFkedzvxVWARHIyotSTlPJO:
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_Main_List()
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_Title_Group(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu in['GLOBAL_GROUP']:
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_SubTitle_Group(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu=='CHANNEL':
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_LiveChannel_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu in['LIVE','VOD','MOVIE']:
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.play_VIDEO(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu=='PROGRAM':
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_Program_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu=='EPISODE':
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_Episode_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu=='MOVIE_SUB':
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_Movie_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu=='SEARCH_GROUP':
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_Search_Group(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu in['SEARCH','LOCAL_SEARCH']:
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_Search_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu=='WATCH':
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_Watch_List(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_Listfile_Delete(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu=='ORDER_BY':
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_setEpOrderby(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu=='MAKE_STRM':
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_Strm_Make(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu in['TOTAL_SEARCH','TOTAL_HISTORY']:
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_Global_Search(rKiNhGqbFkedzvxVWARHIyotSTlPQB.main_params)
  elif rKiNhGqbFkedzvxVWARHIyotSTlPUu=='SEARCH_HISTORY':
   rKiNhGqbFkedzvxVWARHIyotSTlPQB.dp_Search_History()
  else:
   rKiNhGqbFkedzvxVWARHIyotSTlPJO
# Created by pyminifier (https://github.com/liftoff/pyminifier)
