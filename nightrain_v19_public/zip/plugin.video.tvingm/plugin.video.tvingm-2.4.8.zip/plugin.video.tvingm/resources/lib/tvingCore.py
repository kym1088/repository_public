__author__="NightRain"
KDAQgcxdGLzvhayieCIlHnpWuPNXbr=print
KDAQgcxdGLzvhayieCIlHnpWuPNXbV=ImportError
KDAQgcxdGLzvhayieCIlHnpWuPNXbw=object
KDAQgcxdGLzvhayieCIlHnpWuPNXbR=None
KDAQgcxdGLzvhayieCIlHnpWuPNXbO=False
KDAQgcxdGLzvhayieCIlHnpWuPNXbY=open
KDAQgcxdGLzvhayieCIlHnpWuPNXbF=True
KDAQgcxdGLzvhayieCIlHnpWuPNXbs=int
KDAQgcxdGLzvhayieCIlHnpWuPNXbE=range
KDAQgcxdGLzvhayieCIlHnpWuPNXbq=Exception
KDAQgcxdGLzvhayieCIlHnpWuPNXbU=len
KDAQgcxdGLzvhayieCIlHnpWuPNXbf=str
KDAQgcxdGLzvhayieCIlHnpWuPNXbj=list
KDAQgcxdGLzvhayieCIlHnpWuPNXbT=bytes
KDAQgcxdGLzvhayieCIlHnpWuPNXMo=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 KDAQgcxdGLzvhayieCIlHnpWuPNXbr('Cryptodome')
except KDAQgcxdGLzvhayieCIlHnpWuPNXbV:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 KDAQgcxdGLzvhayieCIlHnpWuPNXbr('Crypto')
KDAQgcxdGLzvhayieCIlHnpWuPNXoJ={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
KDAQgcxdGLzvhayieCIlHnpWuPNXot ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class KDAQgcxdGLzvhayieCIlHnpWuPNXok(KDAQgcxdGLzvhayieCIlHnpWuPNXbw):
 def __init__(KDAQgcxdGLzvhayieCIlHnpWuPNXoB):
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.NETWORKCODE ='CSND0900'
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.OSCODE ='CSOD0900' 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TELECODE ='CSCD0900'
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.SCREENCODE ='CSSD0100'
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.APIKEY_ATV ='b6ac9e6384d93d6e533b144b3ef22c42' 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.SCREENCODE_ATV ='CSSD1300' 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.LIVE_LIMIT =20 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.VOD_LIMIT =24 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.EPISODE_LIMIT =30 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.SEARCH_LIMIT =30 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.MOVIE_LIMIT =24 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN ='https://api.tving.com'
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN ='https://image.tving.com'
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.SEARCH_DOMAIN ='https://search.tving.com'
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.LOGIN_DOMAIN ='https://user.tving.com'
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.URL_DOMAIN ='https://www.tving.com'
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.MOVIE_LITE =['2610061','2610161','261062']
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.DEFAULT_HEADER ={'user-agent':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.USER_AGENT}
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV_SESSION_COOKIES1=''
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV_SESSION_COOKIES2=''
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV ={}
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.Init_TV_Total()
 def Init_TV_Total(KDAQgcxdGLzvhayieCIlHnpWuPNXoB):
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N',},}
 def callRequestCookies(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,jobtype,KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,redirects=KDAQgcxdGLzvhayieCIlHnpWuPNXbO):
  KDAQgcxdGLzvhayieCIlHnpWuPNXob=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.DEFAULT_HEADER
  if headers:KDAQgcxdGLzvhayieCIlHnpWuPNXob.update(headers)
  if jobtype=='Get':
   KDAQgcxdGLzvhayieCIlHnpWuPNXoM=requests.get(KDAQgcxdGLzvhayieCIlHnpWuPNXkT,params=params,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXob,cookies=cookies,allow_redirects=redirects)
  else:
   KDAQgcxdGLzvhayieCIlHnpWuPNXoM=requests.post(KDAQgcxdGLzvhayieCIlHnpWuPNXkT,data=payload,params=params,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXob,cookies=cookies,allow_redirects=redirects)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXoM
 def JsonFile_Save(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,filename,KDAQgcxdGLzvhayieCIlHnpWuPNXom):
  if filename=='':return KDAQgcxdGLzvhayieCIlHnpWuPNXbO
  try:
   fp=KDAQgcxdGLzvhayieCIlHnpWuPNXbY(filename,'w',-1,'utf-8')
   json.dump(KDAQgcxdGLzvhayieCIlHnpWuPNXom,fp,indent=4,ensure_ascii=KDAQgcxdGLzvhayieCIlHnpWuPNXbO)
   fp.close()
  except:
   return KDAQgcxdGLzvhayieCIlHnpWuPNXbO
  return KDAQgcxdGLzvhayieCIlHnpWuPNXbF
 def JsonFile_Load(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,filename):
  if filename=='':return{}
  try:
   fp=KDAQgcxdGLzvhayieCIlHnpWuPNXbY(filename,'r',-1,'utf-8')
   KDAQgcxdGLzvhayieCIlHnpWuPNXor=json.load(fp)
   fp.close()
  except:
   return{}
  return KDAQgcxdGLzvhayieCIlHnpWuPNXor
 def Save_session_acount(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,KDAQgcxdGLzvhayieCIlHnpWuPNXoV,KDAQgcxdGLzvhayieCIlHnpWuPNXow,KDAQgcxdGLzvhayieCIlHnpWuPNXoR,KDAQgcxdGLzvhayieCIlHnpWuPNXoO):
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['account']['tvid'] =base64.standard_b64encode(KDAQgcxdGLzvhayieCIlHnpWuPNXoV.encode()).decode('utf-8')
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['account']['tvpw'] =base64.standard_b64encode(KDAQgcxdGLzvhayieCIlHnpWuPNXow.encode()).decode('utf-8')
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['account']['tvtype']=KDAQgcxdGLzvhayieCIlHnpWuPNXoR 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['account']['tvpf'] =KDAQgcxdGLzvhayieCIlHnpWuPNXoO 
 def Load_session_acount(KDAQgcxdGLzvhayieCIlHnpWuPNXoB):
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXoV =base64.standard_b64decode(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['account']['tvid']).decode('utf-8')
   KDAQgcxdGLzvhayieCIlHnpWuPNXow =base64.standard_b64decode(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['account']['tvpw']).decode('utf-8')
   KDAQgcxdGLzvhayieCIlHnpWuPNXoR=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['account']['tvtype']
   KDAQgcxdGLzvhayieCIlHnpWuPNXoO =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return KDAQgcxdGLzvhayieCIlHnpWuPNXoV,KDAQgcxdGLzvhayieCIlHnpWuPNXow,KDAQgcxdGLzvhayieCIlHnpWuPNXoR,KDAQgcxdGLzvhayieCIlHnpWuPNXoO
 def makeDefaultCookies(KDAQgcxdGLzvhayieCIlHnpWuPNXoB):
  KDAQgcxdGLzvhayieCIlHnpWuPNXoY={}
  if KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_token']:KDAQgcxdGLzvhayieCIlHnpWuPNXoY['_tving_token']=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_token']
  if KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_userinfo']:KDAQgcxdGLzvhayieCIlHnpWuPNXoY['POC_USERINFO']=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_userinfo']
  if KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_maintoken']:KDAQgcxdGLzvhayieCIlHnpWuPNXoY[KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GLOBAL_COOKIENM['tv_maintoken']]=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_maintoken']
  if KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_cookiekey']:KDAQgcxdGLzvhayieCIlHnpWuPNXoY[KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GLOBAL_COOKIENM['tv_cookiekey']]=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_cookiekey']
  if KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_lockkey']:KDAQgcxdGLzvhayieCIlHnpWuPNXoY[KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GLOBAL_COOKIENM['tv_lockkey']]=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_lockkey']
  return KDAQgcxdGLzvhayieCIlHnpWuPNXoY
 def getDeviceStr(KDAQgcxdGLzvhayieCIlHnpWuPNXoB):
  KDAQgcxdGLzvhayieCIlHnpWuPNXoF=[]
  KDAQgcxdGLzvhayieCIlHnpWuPNXoF.append('Windows') 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoF.append('Chrome') 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoF.append('ko-KR') 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoF.append('undefined') 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoF.append('24') 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoF.append(u'한국 표준시')
  KDAQgcxdGLzvhayieCIlHnpWuPNXoF.append('undefined') 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoF.append('undefined') 
  KDAQgcxdGLzvhayieCIlHnpWuPNXoF.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  KDAQgcxdGLzvhayieCIlHnpWuPNXos=''
  for KDAQgcxdGLzvhayieCIlHnpWuPNXoE in KDAQgcxdGLzvhayieCIlHnpWuPNXoF:
   KDAQgcxdGLzvhayieCIlHnpWuPNXos+=KDAQgcxdGLzvhayieCIlHnpWuPNXoE+'|'
  return KDAQgcxdGLzvhayieCIlHnpWuPNXos
 def GetDefaultParams(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,uhd=KDAQgcxdGLzvhayieCIlHnpWuPNXbO):
  if uhd==KDAQgcxdGLzvhayieCIlHnpWuPNXbO:
   KDAQgcxdGLzvhayieCIlHnpWuPNXoq={'apiKey':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.APIKEY,'networkCode':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.NETWORKCODE,'osCode':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.OSCODE,'teleCode':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TELECODE,'screenCode':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.SCREENCODE,}
  else:
   KDAQgcxdGLzvhayieCIlHnpWuPNXoq={'apiKey':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.APIKEY_ATV,'networkCode':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.NETWORKCODE,'osCode':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.OSCODE,'teleCode':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TELECODE,'screenCode':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.SCREENCODE_ATV,}
  return KDAQgcxdGLzvhayieCIlHnpWuPNXoq
 def GetNoCache(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,timetype=1):
  if timetype==1:
   return KDAQgcxdGLzvhayieCIlHnpWuPNXbs(time.time())
  else:
   return KDAQgcxdGLzvhayieCIlHnpWuPNXbs(time.time()*1000)
 def GetUniqueid(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,hValue=KDAQgcxdGLzvhayieCIlHnpWuPNXbR):
  if hValue:
   import hashlib
   KDAQgcxdGLzvhayieCIlHnpWuPNXoU=hashlib.sha1()
   KDAQgcxdGLzvhayieCIlHnpWuPNXoU.update(hValue.encode())
   KDAQgcxdGLzvhayieCIlHnpWuPNXof=KDAQgcxdGLzvhayieCIlHnpWuPNXoU.hexdigest()[:8]
  else:
   KDAQgcxdGLzvhayieCIlHnpWuPNXoj=[0 for i in KDAQgcxdGLzvhayieCIlHnpWuPNXbE(256)]
   for i in KDAQgcxdGLzvhayieCIlHnpWuPNXbE(256):
    KDAQgcxdGLzvhayieCIlHnpWuPNXoj[i]='%02x'%(i)
   KDAQgcxdGLzvhayieCIlHnpWuPNXoT=KDAQgcxdGLzvhayieCIlHnpWuPNXbs(4294967295*random.random())|0
   KDAQgcxdGLzvhayieCIlHnpWuPNXof=KDAQgcxdGLzvhayieCIlHnpWuPNXoj[255&KDAQgcxdGLzvhayieCIlHnpWuPNXoT]+KDAQgcxdGLzvhayieCIlHnpWuPNXoj[KDAQgcxdGLzvhayieCIlHnpWuPNXoT>>8&255]+KDAQgcxdGLzvhayieCIlHnpWuPNXoj[KDAQgcxdGLzvhayieCIlHnpWuPNXoT>>16&255]+KDAQgcxdGLzvhayieCIlHnpWuPNXoj[KDAQgcxdGLzvhayieCIlHnpWuPNXoT>>24&255]
  return KDAQgcxdGLzvhayieCIlHnpWuPNXof
 def GetCredential(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,user_id,user_pw,login_type,user_pf):
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXko=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   KDAQgcxdGLzvhayieCIlHnpWuPNXkJ={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Post',KDAQgcxdGLzvhayieCIlHnpWuPNXko,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXkJ,params=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXbR)
   for KDAQgcxdGLzvhayieCIlHnpWuPNXkB in KDAQgcxdGLzvhayieCIlHnpWuPNXkt.cookies:
    if KDAQgcxdGLzvhayieCIlHnpWuPNXkB.name=='_tving_token':
     KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_token']=KDAQgcxdGLzvhayieCIlHnpWuPNXkB.value
    elif KDAQgcxdGLzvhayieCIlHnpWuPNXkB.name=='POC_USERINFO':
     KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_userinfo']=KDAQgcxdGLzvhayieCIlHnpWuPNXkB.value
   if not KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_token']:
    KDAQgcxdGLzvhayieCIlHnpWuPNXoB.Init_TV_Total()
    return KDAQgcxdGLzvhayieCIlHnpWuPNXbO
   KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_maintoken']=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_token']
   if KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetProfileToken(user_pf)==KDAQgcxdGLzvhayieCIlHnpWuPNXbO:
    KDAQgcxdGLzvhayieCIlHnpWuPNXoB.Init_TV_Total()
    return KDAQgcxdGLzvhayieCIlHnpWuPNXbO
   KDAQgcxdGLzvhayieCIlHnpWuPNXkb =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDeviceList()
   if KDAQgcxdGLzvhayieCIlHnpWuPNXkb not in['','-']:
    KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_uuid']=KDAQgcxdGLzvhayieCIlHnpWuPNXkb+'-'+KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetUniqueid(KDAQgcxdGLzvhayieCIlHnpWuPNXkb)
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
   KDAQgcxdGLzvhayieCIlHnpWuPNXoB.Init_TV_Total()
   return KDAQgcxdGLzvhayieCIlHnpWuPNXbO
  return KDAQgcxdGLzvhayieCIlHnpWuPNXbF
 def GetProfileToken(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,user_pf):
  KDAQgcxdGLzvhayieCIlHnpWuPNXkM=[]
  KDAQgcxdGLzvhayieCIlHnpWuPNXkm =''
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   KDAQgcxdGLzvhayieCIlHnpWuPNXoY=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.makeDefaultCookies()
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkS,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXoY)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkM =re.findall('data-profile-no="\d+"',KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   for i in KDAQgcxdGLzvhayieCIlHnpWuPNXbE(KDAQgcxdGLzvhayieCIlHnpWuPNXbU(KDAQgcxdGLzvhayieCIlHnpWuPNXkM)):
    KDAQgcxdGLzvhayieCIlHnpWuPNXkr =KDAQgcxdGLzvhayieCIlHnpWuPNXkM[i].replace('data-profile-no=','').replace('"','')
    KDAQgcxdGLzvhayieCIlHnpWuPNXkM[i]=KDAQgcxdGLzvhayieCIlHnpWuPNXkr
   KDAQgcxdGLzvhayieCIlHnpWuPNXkm=KDAQgcxdGLzvhayieCIlHnpWuPNXkM[user_pf]
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
   KDAQgcxdGLzvhayieCIlHnpWuPNXoB.Init_TV_Total()
   return KDAQgcxdGLzvhayieCIlHnpWuPNXbO
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   KDAQgcxdGLzvhayieCIlHnpWuPNXoY=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.makeDefaultCookies()
   KDAQgcxdGLzvhayieCIlHnpWuPNXkJ={'profileNo':KDAQgcxdGLzvhayieCIlHnpWuPNXkm}
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Post',KDAQgcxdGLzvhayieCIlHnpWuPNXkS,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXkJ,params=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXoY)
   for KDAQgcxdGLzvhayieCIlHnpWuPNXkB in KDAQgcxdGLzvhayieCIlHnpWuPNXkt.cookies:
    if KDAQgcxdGLzvhayieCIlHnpWuPNXkB.name=='_tving_token':
     KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_token']=KDAQgcxdGLzvhayieCIlHnpWuPNXkB.value
    elif KDAQgcxdGLzvhayieCIlHnpWuPNXkB.name==KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GLOBAL_COOKIENM['tv_cookiekey']:
     KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_cookiekey']=KDAQgcxdGLzvhayieCIlHnpWuPNXkB.value
    elif KDAQgcxdGLzvhayieCIlHnpWuPNXkB.name==KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GLOBAL_COOKIENM['tv_lockkey']:
     KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_lockkey']=KDAQgcxdGLzvhayieCIlHnpWuPNXkB.value
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
   KDAQgcxdGLzvhayieCIlHnpWuPNXoB.Init_TV_Total()
   return KDAQgcxdGLzvhayieCIlHnpWuPNXbO
  return KDAQgcxdGLzvhayieCIlHnpWuPNXbF
 def GetDeviceList(KDAQgcxdGLzvhayieCIlHnpWuPNXoB):
  KDAQgcxdGLzvhayieCIlHnpWuPNXkV=[]
  KDAQgcxdGLzvhayieCIlHnpWuPNXkw='-'
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/v1/user/device/list'
   KDAQgcxdGLzvhayieCIlHnpWuPNXkR=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkS
   KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   KDAQgcxdGLzvhayieCIlHnpWuPNXoY=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.makeDefaultCookies()
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkR,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkO,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXoY)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkY=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkV=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']
   for KDAQgcxdGLzvhayieCIlHnpWuPNXkF in KDAQgcxdGLzvhayieCIlHnpWuPNXkV:
    if KDAQgcxdGLzvhayieCIlHnpWuPNXkF['model']=='PC' or KDAQgcxdGLzvhayieCIlHnpWuPNXkF['model']=='PC-Chrome':
     KDAQgcxdGLzvhayieCIlHnpWuPNXkw=KDAQgcxdGLzvhayieCIlHnpWuPNXkF['uuid']
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXkw
 def Get_Now_Datetime(KDAQgcxdGLzvhayieCIlHnpWuPNXoB):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,mediacode,sel_quality,stype,pvrmode='-',optUHD=KDAQgcxdGLzvhayieCIlHnpWuPNXbO):
  KDAQgcxdGLzvhayieCIlHnpWuPNXkE ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','error_msg':'',}
  KDAQgcxdGLzvhayieCIlHnpWuPNXkw =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_uuid'].split('-')[0] 
  KDAQgcxdGLzvhayieCIlHnpWuPNXkq =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_uuid'] 
  KDAQgcxdGLzvhayieCIlHnpWuPNXkU=KDAQgcxdGLzvhayieCIlHnpWuPNXbO 
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXkf=KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetNoCache(1))
   if stype!='tvingtv':
    KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/v2/media/stream/info' 
    KDAQgcxdGLzvhayieCIlHnpWuPNXkj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDefaultParams()
    KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':KDAQgcxdGLzvhayieCIlHnpWuPNXkq,'deviceInfo':'PC','noCache':KDAQgcxdGLzvhayieCIlHnpWuPNXkf,}
    KDAQgcxdGLzvhayieCIlHnpWuPNXkj.update(KDAQgcxdGLzvhayieCIlHnpWuPNXkO)
    KDAQgcxdGLzvhayieCIlHnpWuPNXkT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkS
    KDAQgcxdGLzvhayieCIlHnpWuPNXoY=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.makeDefaultCookies()
    KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkj,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXoY)
    if KDAQgcxdGLzvhayieCIlHnpWuPNXkt.status_code!=200:
     KDAQgcxdGLzvhayieCIlHnpWuPNXkE['error_msg']='First Step - {} error'.format(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.status_code)
     return KDAQgcxdGLzvhayieCIlHnpWuPNXkE
    KDAQgcxdGLzvhayieCIlHnpWuPNXkY=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
    if KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['result']['code']=='060':
     for KDAQgcxdGLzvhayieCIlHnpWuPNXJo,KDAQgcxdGLzvhayieCIlHnpWuPNXJw in KDAQgcxdGLzvhayieCIlHnpWuPNXoJ.items():
      if KDAQgcxdGLzvhayieCIlHnpWuPNXJw==sel_quality:
       KDAQgcxdGLzvhayieCIlHnpWuPNXJk=KDAQgcxdGLzvhayieCIlHnpWuPNXJo
    elif KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['result']['code']!='000':
     KDAQgcxdGLzvhayieCIlHnpWuPNXkE['error_msg']=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['result']['message']
     return KDAQgcxdGLzvhayieCIlHnpWuPNXkE
    else: 
     if not('stream' in KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']):return KDAQgcxdGLzvhayieCIlHnpWuPNXkE
     KDAQgcxdGLzvhayieCIlHnpWuPNXJt=[]
     for KDAQgcxdGLzvhayieCIlHnpWuPNXJo,KDAQgcxdGLzvhayieCIlHnpWuPNXJw in KDAQgcxdGLzvhayieCIlHnpWuPNXoJ.items():
      for KDAQgcxdGLzvhayieCIlHnpWuPNXkF in KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['stream']['quality']:
       if KDAQgcxdGLzvhayieCIlHnpWuPNXkF['active']=='Y' and KDAQgcxdGLzvhayieCIlHnpWuPNXkF['code']==KDAQgcxdGLzvhayieCIlHnpWuPNXJo:
        KDAQgcxdGLzvhayieCIlHnpWuPNXJt.append({KDAQgcxdGLzvhayieCIlHnpWuPNXoJ.get(KDAQgcxdGLzvhayieCIlHnpWuPNXkF['code']):KDAQgcxdGLzvhayieCIlHnpWuPNXkF['code']})
     KDAQgcxdGLzvhayieCIlHnpWuPNXJk=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.CheckQuality(sel_quality,KDAQgcxdGLzvhayieCIlHnpWuPNXJt)
     try:
      if optUHD==KDAQgcxdGLzvhayieCIlHnpWuPNXbF and KDAQgcxdGLzvhayieCIlHnpWuPNXJk=='stream50' and 'stream_support_info' in KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['content']['info']:
       if 'stream70' in KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['content']['info']['stream_support_info']:
        KDAQgcxdGLzvhayieCIlHnpWuPNXJk='stream70'
        KDAQgcxdGLzvhayieCIlHnpWuPNXkU =KDAQgcxdGLzvhayieCIlHnpWuPNXbF
     except:
      pass
   else:
    KDAQgcxdGLzvhayieCIlHnpWuPNXJk='stream40'
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkE['error_msg']='First Step - except error'
   return KDAQgcxdGLzvhayieCIlHnpWuPNXkE
  KDAQgcxdGLzvhayieCIlHnpWuPNXbr(KDAQgcxdGLzvhayieCIlHnpWuPNXJk)
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXkf=KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetNoCache(1))
   KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/v2a/media/stream/info'
   if KDAQgcxdGLzvhayieCIlHnpWuPNXkU==KDAQgcxdGLzvhayieCIlHnpWuPNXbF:
    KDAQgcxdGLzvhayieCIlHnpWuPNXkj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDefaultParams(uhd=KDAQgcxdGLzvhayieCIlHnpWuPNXbF)
    KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'mediaCode':mediacode,'noCache':KDAQgcxdGLzvhayieCIlHnpWuPNXkf,'streamType':'hls','streamCode':KDAQgcxdGLzvhayieCIlHnpWuPNXJk,'deviceId':KDAQgcxdGLzvhayieCIlHnpWuPNXkw,'adReq':'none','wm':'Y','ad_device':'','uuid':KDAQgcxdGLzvhayieCIlHnpWuPNXkq,'deviceInfo':'android_tv',}
   else:
    KDAQgcxdGLzvhayieCIlHnpWuPNXkj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDefaultParams()
    KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':KDAQgcxdGLzvhayieCIlHnpWuPNXJk,'deviceId':KDAQgcxdGLzvhayieCIlHnpWuPNXkw,'uuid':KDAQgcxdGLzvhayieCIlHnpWuPNXkq,'deviceInfo':'PC_Chrome','noCache':KDAQgcxdGLzvhayieCIlHnpWuPNXkf,'wm':'Y'}
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj.update(KDAQgcxdGLzvhayieCIlHnpWuPNXkO)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkS
   KDAQgcxdGLzvhayieCIlHnpWuPNXoY=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.makeDefaultCookies()
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkj,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXoY,redirects=KDAQgcxdGLzvhayieCIlHnpWuPNXbO)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkY=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   KDAQgcxdGLzvhayieCIlHnpWuPNXoB.JsonFile_Save(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV_SESSION_COOKIES1,KDAQgcxdGLzvhayieCIlHnpWuPNXkY)
   if KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['result']['code']!='000':
    KDAQgcxdGLzvhayieCIlHnpWuPNXkE['error_msg']=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['result']['message']
    return KDAQgcxdGLzvhayieCIlHnpWuPNXkE
   KDAQgcxdGLzvhayieCIlHnpWuPNXJB=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['stream']
   if 'drm_license_assertion' in KDAQgcxdGLzvhayieCIlHnpWuPNXJB:
    KDAQgcxdGLzvhayieCIlHnpWuPNXkE['drm_license']=KDAQgcxdGLzvhayieCIlHnpWuPNXJB['drm_license_assertion']
    if '4k_nondrm_url' in KDAQgcxdGLzvhayieCIlHnpWuPNXJB['broadcast']and KDAQgcxdGLzvhayieCIlHnpWuPNXkU==KDAQgcxdGLzvhayieCIlHnpWuPNXbF:
     KDAQgcxdGLzvhayieCIlHnpWuPNXJb =KDAQgcxdGLzvhayieCIlHnpWuPNXJB['broadcast']['4k_nondrm_url']
     KDAQgcxdGLzvhayieCIlHnpWuPNXkE['drm_license']=''
    else:
     KDAQgcxdGLzvhayieCIlHnpWuPNXJb =KDAQgcxdGLzvhayieCIlHnpWuPNXJB['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in KDAQgcxdGLzvhayieCIlHnpWuPNXJB['broadcast']):return KDAQgcxdGLzvhayieCIlHnpWuPNXkE
    KDAQgcxdGLzvhayieCIlHnpWuPNXJb=KDAQgcxdGLzvhayieCIlHnpWuPNXJB['broadcast']['broad_url']
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkE['error_msg']='Second Step - except error'
   return KDAQgcxdGLzvhayieCIlHnpWuPNXkE
  KDAQgcxdGLzvhayieCIlHnpWuPNXJM=KDAQgcxdGLzvhayieCIlHnpWuPNXkf
  KDAQgcxdGLzvhayieCIlHnpWuPNXJb=KDAQgcxdGLzvhayieCIlHnpWuPNXJb.split('|')[1]
  KDAQgcxdGLzvhayieCIlHnpWuPNXJb,KDAQgcxdGLzvhayieCIlHnpWuPNXJm,KDAQgcxdGLzvhayieCIlHnpWuPNXJS=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.Decrypt_Url(KDAQgcxdGLzvhayieCIlHnpWuPNXJb,mediacode,KDAQgcxdGLzvhayieCIlHnpWuPNXJM)
  KDAQgcxdGLzvhayieCIlHnpWuPNXkE['streaming_url']=KDAQgcxdGLzvhayieCIlHnpWuPNXJb
  KDAQgcxdGLzvhayieCIlHnpWuPNXkE['watermark'] =KDAQgcxdGLzvhayieCIlHnpWuPNXJm
  KDAQgcxdGLzvhayieCIlHnpWuPNXkE['watermarkKey']=KDAQgcxdGLzvhayieCIlHnpWuPNXJS
  return KDAQgcxdGLzvhayieCIlHnpWuPNXkE
 def CheckQuality(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,sel_qt,KDAQgcxdGLzvhayieCIlHnpWuPNXJt):
  for KDAQgcxdGLzvhayieCIlHnpWuPNXJr in KDAQgcxdGLzvhayieCIlHnpWuPNXJt:
   if sel_qt>=KDAQgcxdGLzvhayieCIlHnpWuPNXbj(KDAQgcxdGLzvhayieCIlHnpWuPNXJr)[0]:return KDAQgcxdGLzvhayieCIlHnpWuPNXJr.get(KDAQgcxdGLzvhayieCIlHnpWuPNXbj(KDAQgcxdGLzvhayieCIlHnpWuPNXJr)[0])
   KDAQgcxdGLzvhayieCIlHnpWuPNXJV=KDAQgcxdGLzvhayieCIlHnpWuPNXJr.get(KDAQgcxdGLzvhayieCIlHnpWuPNXbj(KDAQgcxdGLzvhayieCIlHnpWuPNXJr)[0])
  return KDAQgcxdGLzvhayieCIlHnpWuPNXJV
 def makeOocUrl(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,ooc_params):
  KDAQgcxdGLzvhayieCIlHnpWuPNXkT=''
  for KDAQgcxdGLzvhayieCIlHnpWuPNXJo,KDAQgcxdGLzvhayieCIlHnpWuPNXJw in ooc_params.items():
   KDAQgcxdGLzvhayieCIlHnpWuPNXkT+="%s=%s^"%(KDAQgcxdGLzvhayieCIlHnpWuPNXJo,KDAQgcxdGLzvhayieCIlHnpWuPNXJw)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXkT
 def GetLiveChannelList(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,stype,page_int):
  KDAQgcxdGLzvhayieCIlHnpWuPNXkV=[]
  KDAQgcxdGLzvhayieCIlHnpWuPNXJR=KDAQgcxdGLzvhayieCIlHnpWuPNXbO
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/v2/media/lives'
   if stype=='onair': 
    KDAQgcxdGLzvhayieCIlHnpWuPNXJO='CPCS0100,CPCS0400'
   else:
    KDAQgcxdGLzvhayieCIlHnpWuPNXJO='CPCS0300'
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDefaultParams()
   KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'cacheType':'main','pageNo':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(page_int),'pageSize':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':KDAQgcxdGLzvhayieCIlHnpWuPNXJO,}
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj.update(KDAQgcxdGLzvhayieCIlHnpWuPNXkO)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkS
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkj,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXbR)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkY=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   if not('result' in KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']):return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
   KDAQgcxdGLzvhayieCIlHnpWuPNXJY=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['result']
   for KDAQgcxdGLzvhayieCIlHnpWuPNXkF in KDAQgcxdGLzvhayieCIlHnpWuPNXJY:
    KDAQgcxdGLzvhayieCIlHnpWuPNXJF=KDAQgcxdGLzvhayieCIlHnpWuPNXJq=KDAQgcxdGLzvhayieCIlHnpWuPNXJU=''
    KDAQgcxdGLzvhayieCIlHnpWuPNXJs=KDAQgcxdGLzvhayieCIlHnpWuPNXtY=''
    KDAQgcxdGLzvhayieCIlHnpWuPNXJE=KDAQgcxdGLzvhayieCIlHnpWuPNXkF['live_code']
    KDAQgcxdGLzvhayieCIlHnpWuPNXJF =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['channel']['name']['ko']
    if KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['episode']!=KDAQgcxdGLzvhayieCIlHnpWuPNXbR:
     KDAQgcxdGLzvhayieCIlHnpWuPNXJq =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['program']['name']['ko']
     KDAQgcxdGLzvhayieCIlHnpWuPNXJq =KDAQgcxdGLzvhayieCIlHnpWuPNXJq+', '+KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['episode']['frequency'])+'회'
     KDAQgcxdGLzvhayieCIlHnpWuPNXJU=KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['episode']['synopsis']['ko']
    else:
     KDAQgcxdGLzvhayieCIlHnpWuPNXJq =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['program']['name']['ko']
     KDAQgcxdGLzvhayieCIlHnpWuPNXJU=KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['program']['synopsis']['ko']
    try: 
     KDAQgcxdGLzvhayieCIlHnpWuPNXJf =''
     KDAQgcxdGLzvhayieCIlHnpWuPNXJj =''
     KDAQgcxdGLzvhayieCIlHnpWuPNXJT=''
     KDAQgcxdGLzvhayieCIlHnpWuPNXto =''
     KDAQgcxdGLzvhayieCIlHnpWuPNXtk =''
     KDAQgcxdGLzvhayieCIlHnpWuPNXtJ =''
     for KDAQgcxdGLzvhayieCIlHnpWuPNXtB in KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['program']['image']:
      if KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP0900':KDAQgcxdGLzvhayieCIlHnpWuPNXJj =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
      elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP1800':KDAQgcxdGLzvhayieCIlHnpWuPNXJT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
      elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP2000':KDAQgcxdGLzvhayieCIlHnpWuPNXto =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
      elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP1900':KDAQgcxdGLzvhayieCIlHnpWuPNXtk =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
      elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP0200':KDAQgcxdGLzvhayieCIlHnpWuPNXtJ =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
      elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP0500':KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
      elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP0800':KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     if KDAQgcxdGLzvhayieCIlHnpWuPNXJf=='':
      for KDAQgcxdGLzvhayieCIlHnpWuPNXtB in KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['channel']['image']:
       if KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIC0400':KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
       elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIC1400':KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
       elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIC1900':KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
    except:
     KDAQgcxdGLzvhayieCIlHnpWuPNXbR
    try:
     KDAQgcxdGLzvhayieCIlHnpWuPNXtb =[]
     KDAQgcxdGLzvhayieCIlHnpWuPNXtM=[]
     KDAQgcxdGLzvhayieCIlHnpWuPNXtm =[]
     KDAQgcxdGLzvhayieCIlHnpWuPNXtS=''
     KDAQgcxdGLzvhayieCIlHnpWuPNXtr=''
     KDAQgcxdGLzvhayieCIlHnpWuPNXtV=''
     for KDAQgcxdGLzvhayieCIlHnpWuPNXtw in KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('schedule').get('program').get('actor'):
      if KDAQgcxdGLzvhayieCIlHnpWuPNXtw!='' and KDAQgcxdGLzvhayieCIlHnpWuPNXtw!=u'없음':KDAQgcxdGLzvhayieCIlHnpWuPNXtb.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtw)
     for KDAQgcxdGLzvhayieCIlHnpWuPNXtR in KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('schedule').get('program').get('director'):
      if KDAQgcxdGLzvhayieCIlHnpWuPNXtR!='' and KDAQgcxdGLzvhayieCIlHnpWuPNXtR!='-' and KDAQgcxdGLzvhayieCIlHnpWuPNXtR!=u'없음':KDAQgcxdGLzvhayieCIlHnpWuPNXtM.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtR)
     if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('schedule').get('program').get('category1_name').get('ko')!='':
      KDAQgcxdGLzvhayieCIlHnpWuPNXtm.append(KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['program']['category1_name']['ko'])
     if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('schedule').get('program').get('category2_name').get('ko')!='':
      KDAQgcxdGLzvhayieCIlHnpWuPNXtm.append(KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['program']['category2_name']['ko'])
     if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('schedule').get('program').get('product_year'):KDAQgcxdGLzvhayieCIlHnpWuPNXtS=KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['program']['product_year']
     if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('schedule').get('program').get('grade_code') :KDAQgcxdGLzvhayieCIlHnpWuPNXtr= KDAQgcxdGLzvhayieCIlHnpWuPNXot.get(KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['program']['grade_code'])
     if 'broad_dt' in KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('schedule').get('program'):
      KDAQgcxdGLzvhayieCIlHnpWuPNXtO =KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('schedule').get('program').get('broad_dt')
      KDAQgcxdGLzvhayieCIlHnpWuPNXtV='%s-%s-%s'%(KDAQgcxdGLzvhayieCIlHnpWuPNXtO[:4],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[4:6],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[6:])
    except:
     KDAQgcxdGLzvhayieCIlHnpWuPNXbR
    KDAQgcxdGLzvhayieCIlHnpWuPNXJs=KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['broadcast_start_time'])[8:12]
    KDAQgcxdGLzvhayieCIlHnpWuPNXtY =KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXkF['schedule']['broadcast_end_time'])[8:12]
    KDAQgcxdGLzvhayieCIlHnpWuPNXtF={'channel':KDAQgcxdGLzvhayieCIlHnpWuPNXJF,'title':KDAQgcxdGLzvhayieCIlHnpWuPNXJq,'mediacode':KDAQgcxdGLzvhayieCIlHnpWuPNXJE,'thumbnail':{'poster':KDAQgcxdGLzvhayieCIlHnpWuPNXJj,'thumb':KDAQgcxdGLzvhayieCIlHnpWuPNXJf,'clearlogo':KDAQgcxdGLzvhayieCIlHnpWuPNXJT,'icon':KDAQgcxdGLzvhayieCIlHnpWuPNXto,'fanart':KDAQgcxdGLzvhayieCIlHnpWuPNXtJ},'synopsis':KDAQgcxdGLzvhayieCIlHnpWuPNXJU,'channelepg':' [%s:%s ~ %s:%s]'%(KDAQgcxdGLzvhayieCIlHnpWuPNXJs[0:2],KDAQgcxdGLzvhayieCIlHnpWuPNXJs[2:],KDAQgcxdGLzvhayieCIlHnpWuPNXtY[0:2],KDAQgcxdGLzvhayieCIlHnpWuPNXtY[2:]),'cast':KDAQgcxdGLzvhayieCIlHnpWuPNXtb,'director':KDAQgcxdGLzvhayieCIlHnpWuPNXtM,'info_genre':KDAQgcxdGLzvhayieCIlHnpWuPNXtm,'year':KDAQgcxdGLzvhayieCIlHnpWuPNXtS,'mpaa':KDAQgcxdGLzvhayieCIlHnpWuPNXtr,'premiered':KDAQgcxdGLzvhayieCIlHnpWuPNXtV}
    KDAQgcxdGLzvhayieCIlHnpWuPNXkV.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtF)
   if KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['has_more']=='Y':
    KDAQgcxdGLzvhayieCIlHnpWuPNXJR=KDAQgcxdGLzvhayieCIlHnpWuPNXbF
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
 def GetProgramList(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,genre,orderby,page_int,genreCode='all'):
  KDAQgcxdGLzvhayieCIlHnpWuPNXkV=[]
  KDAQgcxdGLzvhayieCIlHnpWuPNXJR=KDAQgcxdGLzvhayieCIlHnpWuPNXbO
  try:
   if genre=='PARAMOUNT':
    KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/v2/media/paramount/episodes'
   else:
    KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/v2/media/episodes'
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDefaultParams()
   KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'cacheType':'main','pageSize':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(page_int),}
   if genre not in['all','PARAMOUNT']:KDAQgcxdGLzvhayieCIlHnpWuPNXkO['categoryCode']=genre
   if genreCode!='all' :KDAQgcxdGLzvhayieCIlHnpWuPNXkO['genreCode'] =genreCode 
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj.update(KDAQgcxdGLzvhayieCIlHnpWuPNXkO)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkS
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkj,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXbR)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkY=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   if not('result' in KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']):return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
   KDAQgcxdGLzvhayieCIlHnpWuPNXJY=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['result']
   for KDAQgcxdGLzvhayieCIlHnpWuPNXkF in KDAQgcxdGLzvhayieCIlHnpWuPNXJY:
    KDAQgcxdGLzvhayieCIlHnpWuPNXts=KDAQgcxdGLzvhayieCIlHnpWuPNXkF['program']['code']
    KDAQgcxdGLzvhayieCIlHnpWuPNXJq =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['program']['name']['ko']
    KDAQgcxdGLzvhayieCIlHnpWuPNXtr =KDAQgcxdGLzvhayieCIlHnpWuPNXot.get(KDAQgcxdGLzvhayieCIlHnpWuPNXkF['program'].get('grade_code'))
    KDAQgcxdGLzvhayieCIlHnpWuPNXJj =''
    KDAQgcxdGLzvhayieCIlHnpWuPNXJf =''
    KDAQgcxdGLzvhayieCIlHnpWuPNXJT=''
    KDAQgcxdGLzvhayieCIlHnpWuPNXto =''
    KDAQgcxdGLzvhayieCIlHnpWuPNXtk =''
    for KDAQgcxdGLzvhayieCIlHnpWuPNXtB in KDAQgcxdGLzvhayieCIlHnpWuPNXkF['program']['image']:
     if KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP0900':KDAQgcxdGLzvhayieCIlHnpWuPNXJj =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP0200':KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP1800':KDAQgcxdGLzvhayieCIlHnpWuPNXJT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP2000':KDAQgcxdGLzvhayieCIlHnpWuPNXto =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP1900':KDAQgcxdGLzvhayieCIlHnpWuPNXtk =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
    KDAQgcxdGLzvhayieCIlHnpWuPNXJU =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['program']['synopsis']['ko']
    try:
     KDAQgcxdGLzvhayieCIlHnpWuPNXtE=KDAQgcxdGLzvhayieCIlHnpWuPNXkF['channel']['name']['ko']
    except:
     KDAQgcxdGLzvhayieCIlHnpWuPNXtE=''
    try:
     KDAQgcxdGLzvhayieCIlHnpWuPNXtb =[]
     KDAQgcxdGLzvhayieCIlHnpWuPNXtM=[]
     KDAQgcxdGLzvhayieCIlHnpWuPNXtm =[]
     KDAQgcxdGLzvhayieCIlHnpWuPNXtS =''
     KDAQgcxdGLzvhayieCIlHnpWuPNXtV=''
     for KDAQgcxdGLzvhayieCIlHnpWuPNXtw in KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('program').get('actor'):
      if KDAQgcxdGLzvhayieCIlHnpWuPNXtw!='' and KDAQgcxdGLzvhayieCIlHnpWuPNXtw!='-' and KDAQgcxdGLzvhayieCIlHnpWuPNXtw!=u'없음':KDAQgcxdGLzvhayieCIlHnpWuPNXtb.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtw)
     for KDAQgcxdGLzvhayieCIlHnpWuPNXtR in KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('program').get('director'):
      if KDAQgcxdGLzvhayieCIlHnpWuPNXtR!='' and KDAQgcxdGLzvhayieCIlHnpWuPNXtR!='-' and KDAQgcxdGLzvhayieCIlHnpWuPNXtR!=u'없음':KDAQgcxdGLzvhayieCIlHnpWuPNXtM.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtR)
     if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('program').get('category1_name').get('ko')!='':
      KDAQgcxdGLzvhayieCIlHnpWuPNXtm.append(KDAQgcxdGLzvhayieCIlHnpWuPNXkF['program']['category1_name']['ko'])
     if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('program').get('category2_name').get('ko')!='':
      KDAQgcxdGLzvhayieCIlHnpWuPNXtm.append(KDAQgcxdGLzvhayieCIlHnpWuPNXkF['program']['category2_name']['ko'])
     if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('program').get('product_year'):KDAQgcxdGLzvhayieCIlHnpWuPNXtS=KDAQgcxdGLzvhayieCIlHnpWuPNXkF['program']['product_year']
     if 'broad_dt' in KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('program'):
      KDAQgcxdGLzvhayieCIlHnpWuPNXtO =KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('program').get('broad_dt')
      KDAQgcxdGLzvhayieCIlHnpWuPNXtV='%s-%s-%s'%(KDAQgcxdGLzvhayieCIlHnpWuPNXtO[:4],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[4:6],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[6:])
    except:
     KDAQgcxdGLzvhayieCIlHnpWuPNXbR
    KDAQgcxdGLzvhayieCIlHnpWuPNXtF={'program':KDAQgcxdGLzvhayieCIlHnpWuPNXts,'title':KDAQgcxdGLzvhayieCIlHnpWuPNXJq,'thumbnail':{'poster':KDAQgcxdGLzvhayieCIlHnpWuPNXJj,'thumb':KDAQgcxdGLzvhayieCIlHnpWuPNXJf,'clearlogo':KDAQgcxdGLzvhayieCIlHnpWuPNXJT,'icon':KDAQgcxdGLzvhayieCIlHnpWuPNXto,'banner':KDAQgcxdGLzvhayieCIlHnpWuPNXtk,'fanart':KDAQgcxdGLzvhayieCIlHnpWuPNXJf},'synopsis':KDAQgcxdGLzvhayieCIlHnpWuPNXJU,'channel':KDAQgcxdGLzvhayieCIlHnpWuPNXtE,'cast':KDAQgcxdGLzvhayieCIlHnpWuPNXtb,'director':KDAQgcxdGLzvhayieCIlHnpWuPNXtM,'info_genre':KDAQgcxdGLzvhayieCIlHnpWuPNXtm,'year':KDAQgcxdGLzvhayieCIlHnpWuPNXtS,'premiered':KDAQgcxdGLzvhayieCIlHnpWuPNXtV,'mpaa':KDAQgcxdGLzvhayieCIlHnpWuPNXtr}
    KDAQgcxdGLzvhayieCIlHnpWuPNXkV.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtF)
   if KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['has_more']=='Y':KDAQgcxdGLzvhayieCIlHnpWuPNXJR=KDAQgcxdGLzvhayieCIlHnpWuPNXbF
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
 def Get_UHD_ProgramList(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,page_int):
  KDAQgcxdGLzvhayieCIlHnpWuPNXkV=[]
  KDAQgcxdGLzvhayieCIlHnpWuPNXJR=KDAQgcxdGLzvhayieCIlHnpWuPNXbO
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/v2/operator/highlights'
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDefaultParams(uhd=KDAQgcxdGLzvhayieCIlHnpWuPNXbF)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(page_int),'pocType':'APP_X_TVING_4.0.0',}
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj.update(KDAQgcxdGLzvhayieCIlHnpWuPNXkO)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkS
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkj,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXbR)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkY=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   if not('result' in KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']):return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
   KDAQgcxdGLzvhayieCIlHnpWuPNXJY=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['result']
   for KDAQgcxdGLzvhayieCIlHnpWuPNXkF in KDAQgcxdGLzvhayieCIlHnpWuPNXJY:
    KDAQgcxdGLzvhayieCIlHnpWuPNXtq=KDAQgcxdGLzvhayieCIlHnpWuPNXkF['content']['program']
    KDAQgcxdGLzvhayieCIlHnpWuPNXtU =KDAQgcxdGLzvhayieCIlHnpWuPNXtq['code']
    KDAQgcxdGLzvhayieCIlHnpWuPNXJq =KDAQgcxdGLzvhayieCIlHnpWuPNXtq['name']['ko'].strip()
    KDAQgcxdGLzvhayieCIlHnpWuPNXtr =KDAQgcxdGLzvhayieCIlHnpWuPNXot.get(KDAQgcxdGLzvhayieCIlHnpWuPNXtq.get('grade_code'))
    KDAQgcxdGLzvhayieCIlHnpWuPNXJU =KDAQgcxdGLzvhayieCIlHnpWuPNXtq['synopsis']['ko']
    KDAQgcxdGLzvhayieCIlHnpWuPNXtE =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['content']['channel']['name']['ko']
    KDAQgcxdGLzvhayieCIlHnpWuPNXtS =KDAQgcxdGLzvhayieCIlHnpWuPNXtq['product_year']
    KDAQgcxdGLzvhayieCIlHnpWuPNXJj =''
    KDAQgcxdGLzvhayieCIlHnpWuPNXJf =''
    KDAQgcxdGLzvhayieCIlHnpWuPNXJT=''
    KDAQgcxdGLzvhayieCIlHnpWuPNXto =''
    KDAQgcxdGLzvhayieCIlHnpWuPNXtk =''
    for KDAQgcxdGLzvhayieCIlHnpWuPNXtB in KDAQgcxdGLzvhayieCIlHnpWuPNXtq['image']:
     if KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP0900':KDAQgcxdGLzvhayieCIlHnpWuPNXJj =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP0200':KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP1800':KDAQgcxdGLzvhayieCIlHnpWuPNXJT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP2000':KDAQgcxdGLzvhayieCIlHnpWuPNXto =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP1900':KDAQgcxdGLzvhayieCIlHnpWuPNXtk =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
    KDAQgcxdGLzvhayieCIlHnpWuPNXtm =[]
    KDAQgcxdGLzvhayieCIlHnpWuPNXtb =[]
    KDAQgcxdGLzvhayieCIlHnpWuPNXtM=[]
    KDAQgcxdGLzvhayieCIlHnpWuPNXtV =''
    if KDAQgcxdGLzvhayieCIlHnpWuPNXtq.get('category1_name').get('ko')!='':
     KDAQgcxdGLzvhayieCIlHnpWuPNXtm.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtq['category1_name']['ko'])
    if KDAQgcxdGLzvhayieCIlHnpWuPNXtq.get('category2_name').get('ko')!='':
     KDAQgcxdGLzvhayieCIlHnpWuPNXtm.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtq['category2_name']['ko'])
    for KDAQgcxdGLzvhayieCIlHnpWuPNXtw in KDAQgcxdGLzvhayieCIlHnpWuPNXtq.get('actor'):
     if KDAQgcxdGLzvhayieCIlHnpWuPNXtw!='' and KDAQgcxdGLzvhayieCIlHnpWuPNXtw!='-' and KDAQgcxdGLzvhayieCIlHnpWuPNXtw!=u'없음':KDAQgcxdGLzvhayieCIlHnpWuPNXtb.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtw)
    for KDAQgcxdGLzvhayieCIlHnpWuPNXtR in KDAQgcxdGLzvhayieCIlHnpWuPNXtq.get('director'):
     if KDAQgcxdGLzvhayieCIlHnpWuPNXtR!='' and KDAQgcxdGLzvhayieCIlHnpWuPNXtR!='-' and KDAQgcxdGLzvhayieCIlHnpWuPNXtR!=u'없음':KDAQgcxdGLzvhayieCIlHnpWuPNXtM.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtR)
    if KDAQgcxdGLzvhayieCIlHnpWuPNXtq.get('broad_dt')not in[KDAQgcxdGLzvhayieCIlHnpWuPNXbR,'']:
     KDAQgcxdGLzvhayieCIlHnpWuPNXtO =KDAQgcxdGLzvhayieCIlHnpWuPNXtq.get('broad_dt')
     KDAQgcxdGLzvhayieCIlHnpWuPNXtV='%s-%s-%s'%(KDAQgcxdGLzvhayieCIlHnpWuPNXtO[:4],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[4:6],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[6:])
    KDAQgcxdGLzvhayieCIlHnpWuPNXtF={'program':KDAQgcxdGLzvhayieCIlHnpWuPNXtU,'title':KDAQgcxdGLzvhayieCIlHnpWuPNXJq,'mpaa':KDAQgcxdGLzvhayieCIlHnpWuPNXtr,'thumbnail':{'poster':KDAQgcxdGLzvhayieCIlHnpWuPNXJj,'thumb':KDAQgcxdGLzvhayieCIlHnpWuPNXJf,'clearlogo':KDAQgcxdGLzvhayieCIlHnpWuPNXJT,'icon':KDAQgcxdGLzvhayieCIlHnpWuPNXto,'banner':KDAQgcxdGLzvhayieCIlHnpWuPNXtk,'fanart':KDAQgcxdGLzvhayieCIlHnpWuPNXJf},'channel':KDAQgcxdGLzvhayieCIlHnpWuPNXtE,'synopsis':KDAQgcxdGLzvhayieCIlHnpWuPNXJU,'year':KDAQgcxdGLzvhayieCIlHnpWuPNXtS,'info_genre':KDAQgcxdGLzvhayieCIlHnpWuPNXtm,'cast':KDAQgcxdGLzvhayieCIlHnpWuPNXtb,'director':KDAQgcxdGLzvhayieCIlHnpWuPNXtM,'premiered':KDAQgcxdGLzvhayieCIlHnpWuPNXtV,}
    KDAQgcxdGLzvhayieCIlHnpWuPNXkV.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtF)
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
 def GetEpisodeList(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,program_code,page_int,orderby='desc'):
  KDAQgcxdGLzvhayieCIlHnpWuPNXkV=[]
  KDAQgcxdGLzvhayieCIlHnpWuPNXJR=KDAQgcxdGLzvhayieCIlHnpWuPNXbO
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/v2/media/frequency/program/'+program_code
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDefaultParams()
   KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj.update(KDAQgcxdGLzvhayieCIlHnpWuPNXkO)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkS
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkj,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXbR)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkY=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   if not('result' in KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']):return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
   KDAQgcxdGLzvhayieCIlHnpWuPNXJY=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['result']
   KDAQgcxdGLzvhayieCIlHnpWuPNXtf=KDAQgcxdGLzvhayieCIlHnpWuPNXbs(KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['total_count'])
   KDAQgcxdGLzvhayieCIlHnpWuPNXtj =KDAQgcxdGLzvhayieCIlHnpWuPNXbs(KDAQgcxdGLzvhayieCIlHnpWuPNXtf//(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    KDAQgcxdGLzvhayieCIlHnpWuPNXtT =(KDAQgcxdGLzvhayieCIlHnpWuPNXtf-1)-((page_int-1)*KDAQgcxdGLzvhayieCIlHnpWuPNXoB.EPISODE_LIMIT)
   else:
    KDAQgcxdGLzvhayieCIlHnpWuPNXtT =(page_int-1)*KDAQgcxdGLzvhayieCIlHnpWuPNXoB.EPISODE_LIMIT
   for i in KDAQgcxdGLzvhayieCIlHnpWuPNXbE(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.EPISODE_LIMIT):
    if orderby=='desc':
     KDAQgcxdGLzvhayieCIlHnpWuPNXBo=KDAQgcxdGLzvhayieCIlHnpWuPNXtT-i
     if KDAQgcxdGLzvhayieCIlHnpWuPNXBo<0:break
    else:
     KDAQgcxdGLzvhayieCIlHnpWuPNXBo=KDAQgcxdGLzvhayieCIlHnpWuPNXtT+i
     if KDAQgcxdGLzvhayieCIlHnpWuPNXBo>=KDAQgcxdGLzvhayieCIlHnpWuPNXtf:break
    KDAQgcxdGLzvhayieCIlHnpWuPNXBk=KDAQgcxdGLzvhayieCIlHnpWuPNXJY[KDAQgcxdGLzvhayieCIlHnpWuPNXBo]['episode']['code']
    KDAQgcxdGLzvhayieCIlHnpWuPNXJq =KDAQgcxdGLzvhayieCIlHnpWuPNXJY[KDAQgcxdGLzvhayieCIlHnpWuPNXBo]['vod_name']['ko']
    KDAQgcxdGLzvhayieCIlHnpWuPNXBJ =''
    try:
     KDAQgcxdGLzvhayieCIlHnpWuPNXtO=KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXJY[KDAQgcxdGLzvhayieCIlHnpWuPNXBo]['episode']['broadcast_date'])
     KDAQgcxdGLzvhayieCIlHnpWuPNXBJ='%s-%s-%s'%(KDAQgcxdGLzvhayieCIlHnpWuPNXtO[:4],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[4:6],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[6:])
    except:
     KDAQgcxdGLzvhayieCIlHnpWuPNXbR
    try:
     if KDAQgcxdGLzvhayieCIlHnpWuPNXJY[KDAQgcxdGLzvhayieCIlHnpWuPNXBo]['episode']['pip_cliptype']=='C012':
      KDAQgcxdGLzvhayieCIlHnpWuPNXBJ+=' - Quick VOD'
    except:
     KDAQgcxdGLzvhayieCIlHnpWuPNXbR
    KDAQgcxdGLzvhayieCIlHnpWuPNXJU =KDAQgcxdGLzvhayieCIlHnpWuPNXJY[KDAQgcxdGLzvhayieCIlHnpWuPNXBo]['episode']['synopsis']['ko']
    KDAQgcxdGLzvhayieCIlHnpWuPNXJj =''
    KDAQgcxdGLzvhayieCIlHnpWuPNXJf =''
    KDAQgcxdGLzvhayieCIlHnpWuPNXJT=''
    KDAQgcxdGLzvhayieCIlHnpWuPNXto =''
    KDAQgcxdGLzvhayieCIlHnpWuPNXtk =''
    KDAQgcxdGLzvhayieCIlHnpWuPNXtJ =''
    for KDAQgcxdGLzvhayieCIlHnpWuPNXtB in KDAQgcxdGLzvhayieCIlHnpWuPNXJY[KDAQgcxdGLzvhayieCIlHnpWuPNXBo]['program']['image']:
     if KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP0900':KDAQgcxdGLzvhayieCIlHnpWuPNXJj =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP1800':KDAQgcxdGLzvhayieCIlHnpWuPNXJT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP2000':KDAQgcxdGLzvhayieCIlHnpWuPNXto =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP1900':KDAQgcxdGLzvhayieCIlHnpWuPNXtk =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIP0200':KDAQgcxdGLzvhayieCIlHnpWuPNXtJ =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
    for KDAQgcxdGLzvhayieCIlHnpWuPNXtB in KDAQgcxdGLzvhayieCIlHnpWuPNXJY[KDAQgcxdGLzvhayieCIlHnpWuPNXBo]['episode']['image']:
     if KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIE0400':KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
    try:
     KDAQgcxdGLzvhayieCIlHnpWuPNXBt=KDAQgcxdGLzvhayieCIlHnpWuPNXBM=KDAQgcxdGLzvhayieCIlHnpWuPNXBm=''
     KDAQgcxdGLzvhayieCIlHnpWuPNXBb=0
     KDAQgcxdGLzvhayieCIlHnpWuPNXBt =KDAQgcxdGLzvhayieCIlHnpWuPNXJY[KDAQgcxdGLzvhayieCIlHnpWuPNXBo]['program']['name']['ko']
     KDAQgcxdGLzvhayieCIlHnpWuPNXBM =KDAQgcxdGLzvhayieCIlHnpWuPNXBJ
     KDAQgcxdGLzvhayieCIlHnpWuPNXBm =KDAQgcxdGLzvhayieCIlHnpWuPNXJY[KDAQgcxdGLzvhayieCIlHnpWuPNXBo]['channel']['name']['ko']
     if 'frequency' in KDAQgcxdGLzvhayieCIlHnpWuPNXJY[KDAQgcxdGLzvhayieCIlHnpWuPNXBo]['episode']:KDAQgcxdGLzvhayieCIlHnpWuPNXBb=KDAQgcxdGLzvhayieCIlHnpWuPNXJY[KDAQgcxdGLzvhayieCIlHnpWuPNXBo]['episode']['frequency']
    except:
     KDAQgcxdGLzvhayieCIlHnpWuPNXbR
    KDAQgcxdGLzvhayieCIlHnpWuPNXtF={'episode':KDAQgcxdGLzvhayieCIlHnpWuPNXBk,'title':KDAQgcxdGLzvhayieCIlHnpWuPNXJq,'subtitle':KDAQgcxdGLzvhayieCIlHnpWuPNXBJ,'thumbnail':{'poster':KDAQgcxdGLzvhayieCIlHnpWuPNXJj,'thumb':KDAQgcxdGLzvhayieCIlHnpWuPNXJf,'clearlogo':KDAQgcxdGLzvhayieCIlHnpWuPNXJT,'icon':KDAQgcxdGLzvhayieCIlHnpWuPNXto,'banner':KDAQgcxdGLzvhayieCIlHnpWuPNXtk,'fanart':KDAQgcxdGLzvhayieCIlHnpWuPNXtJ},'synopsis':KDAQgcxdGLzvhayieCIlHnpWuPNXJU,'info_title':KDAQgcxdGLzvhayieCIlHnpWuPNXBt,'aired':KDAQgcxdGLzvhayieCIlHnpWuPNXBM,'studio':KDAQgcxdGLzvhayieCIlHnpWuPNXBm,'frequency':KDAQgcxdGLzvhayieCIlHnpWuPNXBb}
    KDAQgcxdGLzvhayieCIlHnpWuPNXkV.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtF)
   if KDAQgcxdGLzvhayieCIlHnpWuPNXtj>page_int:KDAQgcxdGLzvhayieCIlHnpWuPNXJR=KDAQgcxdGLzvhayieCIlHnpWuPNXbF
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR,KDAQgcxdGLzvhayieCIlHnpWuPNXtj
 def GetMovieList(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,genre,orderby,page_int):
  KDAQgcxdGLzvhayieCIlHnpWuPNXkV=[]
  KDAQgcxdGLzvhayieCIlHnpWuPNXJR=KDAQgcxdGLzvhayieCIlHnpWuPNXbO
  try:
   if genre=='PARAMOUNT':
    KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/v2/media/paramount/movies'
   else:
    KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/v2/media/movies'
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDefaultParams()
   KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'pageSize':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N','pageNo':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(page_int),}
   if genre not in['all','PARAMOUNT']:KDAQgcxdGLzvhayieCIlHnpWuPNXkO['categoryCode']=genre
   KDAQgcxdGLzvhayieCIlHnpWuPNXkO['productPackageCode']=','.join(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.MOVIE_LITE)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj.update(KDAQgcxdGLzvhayieCIlHnpWuPNXkO)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkS
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkj,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXbR)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkY=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   if not('result' in KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']):return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
   KDAQgcxdGLzvhayieCIlHnpWuPNXJY=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['result']
   for KDAQgcxdGLzvhayieCIlHnpWuPNXkF in KDAQgcxdGLzvhayieCIlHnpWuPNXJY:
    if 'release_date' in KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('movie'):
     KDAQgcxdGLzvhayieCIlHnpWuPNXtS=KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('movie').get('release_date'))[:4]
    else:
     KDAQgcxdGLzvhayieCIlHnpWuPNXtS=KDAQgcxdGLzvhayieCIlHnpWuPNXbR
    KDAQgcxdGLzvhayieCIlHnpWuPNXBS =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['movie']['code']
    KDAQgcxdGLzvhayieCIlHnpWuPNXJq =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['movie']['name']['ko'].strip()
    if KDAQgcxdGLzvhayieCIlHnpWuPNXtS not in[KDAQgcxdGLzvhayieCIlHnpWuPNXbR,'0','']:KDAQgcxdGLzvhayieCIlHnpWuPNXJq+=u' (%s)'%(KDAQgcxdGLzvhayieCIlHnpWuPNXtS)
    KDAQgcxdGLzvhayieCIlHnpWuPNXJj=''
    KDAQgcxdGLzvhayieCIlHnpWuPNXJf =''
    KDAQgcxdGLzvhayieCIlHnpWuPNXJT=''
    for KDAQgcxdGLzvhayieCIlHnpWuPNXtB in KDAQgcxdGLzvhayieCIlHnpWuPNXkF['movie']['image']:
     if KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIM2100':KDAQgcxdGLzvhayieCIlHnpWuPNXJj =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIM0400':KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIM1800':KDAQgcxdGLzvhayieCIlHnpWuPNXJT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
    KDAQgcxdGLzvhayieCIlHnpWuPNXJU =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['movie']['story']['ko']
    try:
     KDAQgcxdGLzvhayieCIlHnpWuPNXBt =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['movie']['name']['ko'].strip()
     KDAQgcxdGLzvhayieCIlHnpWuPNXtr =KDAQgcxdGLzvhayieCIlHnpWuPNXot.get(KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('grade_code'))
     KDAQgcxdGLzvhayieCIlHnpWuPNXtb=[]
     KDAQgcxdGLzvhayieCIlHnpWuPNXtM=[]
     KDAQgcxdGLzvhayieCIlHnpWuPNXtm=[]
     KDAQgcxdGLzvhayieCIlHnpWuPNXBr=0
     KDAQgcxdGLzvhayieCIlHnpWuPNXtV=''
     KDAQgcxdGLzvhayieCIlHnpWuPNXBm =''
     for KDAQgcxdGLzvhayieCIlHnpWuPNXtw in KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('movie').get('actor'):
      if KDAQgcxdGLzvhayieCIlHnpWuPNXtw!='':KDAQgcxdGLzvhayieCIlHnpWuPNXtb.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtw)
     for KDAQgcxdGLzvhayieCIlHnpWuPNXtR in KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('movie').get('director'):
      if KDAQgcxdGLzvhayieCIlHnpWuPNXtR!='':KDAQgcxdGLzvhayieCIlHnpWuPNXtM.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtR)
     if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('movie').get('category1_name').get('ko')!='':
      KDAQgcxdGLzvhayieCIlHnpWuPNXtm.append(KDAQgcxdGLzvhayieCIlHnpWuPNXkF['movie']['category1_name']['ko'])
     if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('movie').get('category2_name').get('ko')!='':
      KDAQgcxdGLzvhayieCIlHnpWuPNXtm.append(KDAQgcxdGLzvhayieCIlHnpWuPNXkF['movie']['category2_name']['ko'])
     if 'duration' in KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('movie'):KDAQgcxdGLzvhayieCIlHnpWuPNXBr=KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('movie').get('duration')
     if 'release_date' in KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('movie'):
      KDAQgcxdGLzvhayieCIlHnpWuPNXtO=KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('movie').get('release_date'))
      if KDAQgcxdGLzvhayieCIlHnpWuPNXtO!='0':KDAQgcxdGLzvhayieCIlHnpWuPNXtV='%s-%s-%s'%(KDAQgcxdGLzvhayieCIlHnpWuPNXtO[:4],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[4:6],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[6:])
     if 'production' in KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('movie'):KDAQgcxdGLzvhayieCIlHnpWuPNXBm=KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('movie').get('production')
    except:
     KDAQgcxdGLzvhayieCIlHnpWuPNXbR
    KDAQgcxdGLzvhayieCIlHnpWuPNXtF={'moviecode':KDAQgcxdGLzvhayieCIlHnpWuPNXBS,'title':KDAQgcxdGLzvhayieCIlHnpWuPNXJq,'thumbnail':{'poster':KDAQgcxdGLzvhayieCIlHnpWuPNXJj,'thumb':KDAQgcxdGLzvhayieCIlHnpWuPNXJf,'clearlogo':KDAQgcxdGLzvhayieCIlHnpWuPNXJT,'fanart':KDAQgcxdGLzvhayieCIlHnpWuPNXJf},'synopsis':KDAQgcxdGLzvhayieCIlHnpWuPNXJU,'info_title':KDAQgcxdGLzvhayieCIlHnpWuPNXBt,'year':KDAQgcxdGLzvhayieCIlHnpWuPNXtS,'cast':KDAQgcxdGLzvhayieCIlHnpWuPNXtb,'director':KDAQgcxdGLzvhayieCIlHnpWuPNXtM,'info_genre':KDAQgcxdGLzvhayieCIlHnpWuPNXtm,'duration':KDAQgcxdGLzvhayieCIlHnpWuPNXBr,'premiered':KDAQgcxdGLzvhayieCIlHnpWuPNXtV,'studio':KDAQgcxdGLzvhayieCIlHnpWuPNXBm,'mpaa':KDAQgcxdGLzvhayieCIlHnpWuPNXtr}
    KDAQgcxdGLzvhayieCIlHnpWuPNXBV=KDAQgcxdGLzvhayieCIlHnpWuPNXbO
    for KDAQgcxdGLzvhayieCIlHnpWuPNXBw in KDAQgcxdGLzvhayieCIlHnpWuPNXkF['billing_package_id']:
     if KDAQgcxdGLzvhayieCIlHnpWuPNXBw in KDAQgcxdGLzvhayieCIlHnpWuPNXoB.MOVIE_LITE:
      KDAQgcxdGLzvhayieCIlHnpWuPNXBV=KDAQgcxdGLzvhayieCIlHnpWuPNXbF
      break
    if KDAQgcxdGLzvhayieCIlHnpWuPNXBV==KDAQgcxdGLzvhayieCIlHnpWuPNXbO: 
     KDAQgcxdGLzvhayieCIlHnpWuPNXtF['title']=KDAQgcxdGLzvhayieCIlHnpWuPNXtF['title']+' [개별구매]'
    KDAQgcxdGLzvhayieCIlHnpWuPNXkV.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtF)
   if KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['has_more']=='Y':KDAQgcxdGLzvhayieCIlHnpWuPNXJR=KDAQgcxdGLzvhayieCIlHnpWuPNXbF
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
 def Get_UHD_MovieList(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,page_int):
  KDAQgcxdGLzvhayieCIlHnpWuPNXkV=[]
  KDAQgcxdGLzvhayieCIlHnpWuPNXJR=KDAQgcxdGLzvhayieCIlHnpWuPNXbO
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/v2/operator/highlights'
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDefaultParams(uhd=KDAQgcxdGLzvhayieCIlHnpWuPNXbF)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(page_int),'pocType':'APP_X_TVING_4.0.0',}
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj.update(KDAQgcxdGLzvhayieCIlHnpWuPNXkO)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkS
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkj,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXbR)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkY=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   if not('result' in KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']):return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
   KDAQgcxdGLzvhayieCIlHnpWuPNXJY=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['result']
   for KDAQgcxdGLzvhayieCIlHnpWuPNXkF in KDAQgcxdGLzvhayieCIlHnpWuPNXJY:
    KDAQgcxdGLzvhayieCIlHnpWuPNXtq=KDAQgcxdGLzvhayieCIlHnpWuPNXkF['content']['movie']
    KDAQgcxdGLzvhayieCIlHnpWuPNXtU =KDAQgcxdGLzvhayieCIlHnpWuPNXtq['code']
    KDAQgcxdGLzvhayieCIlHnpWuPNXJq =KDAQgcxdGLzvhayieCIlHnpWuPNXtq['name']['ko'].strip()
    KDAQgcxdGLzvhayieCIlHnpWuPNXBt =KDAQgcxdGLzvhayieCIlHnpWuPNXtq['name']['ko'].strip()
    KDAQgcxdGLzvhayieCIlHnpWuPNXtS =KDAQgcxdGLzvhayieCIlHnpWuPNXtq['product_year']
    if KDAQgcxdGLzvhayieCIlHnpWuPNXtS:KDAQgcxdGLzvhayieCIlHnpWuPNXJq+=u' (%s)'%(KDAQgcxdGLzvhayieCIlHnpWuPNXtq['product_year'])
    KDAQgcxdGLzvhayieCIlHnpWuPNXJU =KDAQgcxdGLzvhayieCIlHnpWuPNXtq['story']['ko']
    KDAQgcxdGLzvhayieCIlHnpWuPNXBr =KDAQgcxdGLzvhayieCIlHnpWuPNXtq['duration']
    KDAQgcxdGLzvhayieCIlHnpWuPNXtr =KDAQgcxdGLzvhayieCIlHnpWuPNXot.get(KDAQgcxdGLzvhayieCIlHnpWuPNXtq.get('grade_code'))
    KDAQgcxdGLzvhayieCIlHnpWuPNXBm =KDAQgcxdGLzvhayieCIlHnpWuPNXtq['production']
    KDAQgcxdGLzvhayieCIlHnpWuPNXJj=''
    KDAQgcxdGLzvhayieCIlHnpWuPNXJf =''
    KDAQgcxdGLzvhayieCIlHnpWuPNXJT=''
    KDAQgcxdGLzvhayieCIlHnpWuPNXtm =[]
    KDAQgcxdGLzvhayieCIlHnpWuPNXtb =[]
    KDAQgcxdGLzvhayieCIlHnpWuPNXtM=[]
    KDAQgcxdGLzvhayieCIlHnpWuPNXtV =''
    for KDAQgcxdGLzvhayieCIlHnpWuPNXtB in KDAQgcxdGLzvhayieCIlHnpWuPNXtq['image']:
     if KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIM2100':KDAQgcxdGLzvhayieCIlHnpWuPNXJj =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIM0400':KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
     elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB['code']=='CAIM1800':KDAQgcxdGLzvhayieCIlHnpWuPNXJT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB['url']
    if KDAQgcxdGLzvhayieCIlHnpWuPNXtq['release_date']not in[KDAQgcxdGLzvhayieCIlHnpWuPNXbR,0]:
     KDAQgcxdGLzvhayieCIlHnpWuPNXtO=KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXtq['release_date'])
     if KDAQgcxdGLzvhayieCIlHnpWuPNXtO!='0':KDAQgcxdGLzvhayieCIlHnpWuPNXtV='%s-%s-%s'%(KDAQgcxdGLzvhayieCIlHnpWuPNXtO[:4],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[4:6],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[6:])
    if KDAQgcxdGLzvhayieCIlHnpWuPNXtq.get('category1_name').get('ko')!='':
     KDAQgcxdGLzvhayieCIlHnpWuPNXtm.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtq['category1_name']['ko'])
    if KDAQgcxdGLzvhayieCIlHnpWuPNXtq.get('category2_name').get('ko')!='':
     KDAQgcxdGLzvhayieCIlHnpWuPNXtm.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtq['category2_name']['ko'])
    for KDAQgcxdGLzvhayieCIlHnpWuPNXtw in KDAQgcxdGLzvhayieCIlHnpWuPNXtq.get('actor'):
     if KDAQgcxdGLzvhayieCIlHnpWuPNXtw!='':KDAQgcxdGLzvhayieCIlHnpWuPNXtb.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtw)
    for KDAQgcxdGLzvhayieCIlHnpWuPNXtR in KDAQgcxdGLzvhayieCIlHnpWuPNXtq.get('director'):
     if KDAQgcxdGLzvhayieCIlHnpWuPNXtR!='':KDAQgcxdGLzvhayieCIlHnpWuPNXtM.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtR)
    KDAQgcxdGLzvhayieCIlHnpWuPNXtF={'moviecode':KDAQgcxdGLzvhayieCIlHnpWuPNXtU,'title':KDAQgcxdGLzvhayieCIlHnpWuPNXJq,'thumbnail':{'poster':KDAQgcxdGLzvhayieCIlHnpWuPNXJj,'thumb':KDAQgcxdGLzvhayieCIlHnpWuPNXJf,'clearlogo':KDAQgcxdGLzvhayieCIlHnpWuPNXJT,'fanart':KDAQgcxdGLzvhayieCIlHnpWuPNXJf},'year':KDAQgcxdGLzvhayieCIlHnpWuPNXtS,'info_title':KDAQgcxdGLzvhayieCIlHnpWuPNXBt,'synopsis':KDAQgcxdGLzvhayieCIlHnpWuPNXJU,'mpaa':KDAQgcxdGLzvhayieCIlHnpWuPNXtr,'duration':KDAQgcxdGLzvhayieCIlHnpWuPNXBr,'premiered':KDAQgcxdGLzvhayieCIlHnpWuPNXtV,'studio':KDAQgcxdGLzvhayieCIlHnpWuPNXBm,'info_genre':KDAQgcxdGLzvhayieCIlHnpWuPNXtm,'cast':KDAQgcxdGLzvhayieCIlHnpWuPNXtb,'director':KDAQgcxdGLzvhayieCIlHnpWuPNXtM,}
    KDAQgcxdGLzvhayieCIlHnpWuPNXkV.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtF)
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
 def GetMovieGenre(KDAQgcxdGLzvhayieCIlHnpWuPNXoB):
  KDAQgcxdGLzvhayieCIlHnpWuPNXkV=[]
  KDAQgcxdGLzvhayieCIlHnpWuPNXJR=KDAQgcxdGLzvhayieCIlHnpWuPNXbO
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/v2/media/movie/curations'
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDefaultParams()
   KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj.update(KDAQgcxdGLzvhayieCIlHnpWuPNXkO)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkS
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkj,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXbR)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkY=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   if not('result' in KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']):return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
   KDAQgcxdGLzvhayieCIlHnpWuPNXJY=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['result']
   for KDAQgcxdGLzvhayieCIlHnpWuPNXkF in KDAQgcxdGLzvhayieCIlHnpWuPNXJY:
    KDAQgcxdGLzvhayieCIlHnpWuPNXBR =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['curation_code']
    KDAQgcxdGLzvhayieCIlHnpWuPNXBO =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['curation_name']
    KDAQgcxdGLzvhayieCIlHnpWuPNXtF={'curation_code':KDAQgcxdGLzvhayieCIlHnpWuPNXBR,'curation_name':KDAQgcxdGLzvhayieCIlHnpWuPNXBO}
    KDAQgcxdGLzvhayieCIlHnpWuPNXkV.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtF)
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
 def GetSearchList(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,search_key,page_int,stype):
  KDAQgcxdGLzvhayieCIlHnpWuPNXBY=[]
  KDAQgcxdGLzvhayieCIlHnpWuPNXJR=KDAQgcxdGLzvhayieCIlHnpWuPNXbO
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/search/getSearch.jsp'
   KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(page_int),'pageSize':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.SCREENCODE,'os':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.OSCODE,'network':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   KDAQgcxdGLzvhayieCIlHnpWuPNXkT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.SEARCH_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkS
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkO,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXbR)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkY=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   if stype=='vod':
    if not('programRsb' in KDAQgcxdGLzvhayieCIlHnpWuPNXkY):return KDAQgcxdGLzvhayieCIlHnpWuPNXBY,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
    KDAQgcxdGLzvhayieCIlHnpWuPNXBF=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['programRsb']['dataList']
    KDAQgcxdGLzvhayieCIlHnpWuPNXBs =KDAQgcxdGLzvhayieCIlHnpWuPNXbs(KDAQgcxdGLzvhayieCIlHnpWuPNXkY['programRsb']['count'])
    for KDAQgcxdGLzvhayieCIlHnpWuPNXkF in KDAQgcxdGLzvhayieCIlHnpWuPNXBF:
     KDAQgcxdGLzvhayieCIlHnpWuPNXts=KDAQgcxdGLzvhayieCIlHnpWuPNXkF['mast_cd']
     KDAQgcxdGLzvhayieCIlHnpWuPNXJq =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['mast_nm']
     KDAQgcxdGLzvhayieCIlHnpWuPNXJj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkF['web_url4']
     KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkF['web_url']
     try:
      KDAQgcxdGLzvhayieCIlHnpWuPNXtb =[]
      KDAQgcxdGLzvhayieCIlHnpWuPNXtM=[]
      KDAQgcxdGLzvhayieCIlHnpWuPNXtm =[]
      KDAQgcxdGLzvhayieCIlHnpWuPNXBr =0
      KDAQgcxdGLzvhayieCIlHnpWuPNXtr =''
      KDAQgcxdGLzvhayieCIlHnpWuPNXtS =''
      KDAQgcxdGLzvhayieCIlHnpWuPNXBM =''
      if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('actor') !='' and KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('actor') !='-':KDAQgcxdGLzvhayieCIlHnpWuPNXtb =KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('actor').split(',')
      if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('director')!='' and KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('director')!='-':KDAQgcxdGLzvhayieCIlHnpWuPNXtM=KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('director').split(',')
      if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('cate_nm')!='' and KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('cate_nm')!='-':KDAQgcxdGLzvhayieCIlHnpWuPNXtm =KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('cate_nm').split('/')
      if 'targetage' in KDAQgcxdGLzvhayieCIlHnpWuPNXkF:KDAQgcxdGLzvhayieCIlHnpWuPNXtr=KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('targetage')
      if 'broad_dt' in KDAQgcxdGLzvhayieCIlHnpWuPNXkF:
       KDAQgcxdGLzvhayieCIlHnpWuPNXtO=KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('broad_dt')
       KDAQgcxdGLzvhayieCIlHnpWuPNXBM='%s-%s-%s'%(KDAQgcxdGLzvhayieCIlHnpWuPNXtO[:4],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[4:6],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[6:])
       KDAQgcxdGLzvhayieCIlHnpWuPNXtS =KDAQgcxdGLzvhayieCIlHnpWuPNXtO[:4]
     except:
      KDAQgcxdGLzvhayieCIlHnpWuPNXbR
     KDAQgcxdGLzvhayieCIlHnpWuPNXtF={'program':KDAQgcxdGLzvhayieCIlHnpWuPNXts,'title':KDAQgcxdGLzvhayieCIlHnpWuPNXJq,'thumbnail':{'poster':KDAQgcxdGLzvhayieCIlHnpWuPNXJj,'thumb':KDAQgcxdGLzvhayieCIlHnpWuPNXJf,'fanart':KDAQgcxdGLzvhayieCIlHnpWuPNXJf},'synopsis':'','cast':KDAQgcxdGLzvhayieCIlHnpWuPNXtb,'director':KDAQgcxdGLzvhayieCIlHnpWuPNXtM,'info_genre':KDAQgcxdGLzvhayieCIlHnpWuPNXtm,'duration':KDAQgcxdGLzvhayieCIlHnpWuPNXBr,'mpaa':KDAQgcxdGLzvhayieCIlHnpWuPNXtr,'year':KDAQgcxdGLzvhayieCIlHnpWuPNXtS,'aired':KDAQgcxdGLzvhayieCIlHnpWuPNXBM}
     KDAQgcxdGLzvhayieCIlHnpWuPNXBY.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtF)
   else:
    if not('vodMVRsb' in KDAQgcxdGLzvhayieCIlHnpWuPNXkY):return KDAQgcxdGLzvhayieCIlHnpWuPNXBY,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
    KDAQgcxdGLzvhayieCIlHnpWuPNXBE=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['vodMVRsb']['dataList']
    KDAQgcxdGLzvhayieCIlHnpWuPNXBs =KDAQgcxdGLzvhayieCIlHnpWuPNXbs(KDAQgcxdGLzvhayieCIlHnpWuPNXkY['vodMVRsb']['count'])
    for KDAQgcxdGLzvhayieCIlHnpWuPNXkF in KDAQgcxdGLzvhayieCIlHnpWuPNXBE:
     KDAQgcxdGLzvhayieCIlHnpWuPNXts=KDAQgcxdGLzvhayieCIlHnpWuPNXkF['mast_cd']
     KDAQgcxdGLzvhayieCIlHnpWuPNXJq =KDAQgcxdGLzvhayieCIlHnpWuPNXkF['mast_nm'].strip()
     KDAQgcxdGLzvhayieCIlHnpWuPNXJj =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkF['web_url']
     KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXJj
     KDAQgcxdGLzvhayieCIlHnpWuPNXJT=''
     try:
      KDAQgcxdGLzvhayieCIlHnpWuPNXtb =[]
      KDAQgcxdGLzvhayieCIlHnpWuPNXtM=[]
      KDAQgcxdGLzvhayieCIlHnpWuPNXtm =[]
      KDAQgcxdGLzvhayieCIlHnpWuPNXBr =0
      KDAQgcxdGLzvhayieCIlHnpWuPNXtr =''
      KDAQgcxdGLzvhayieCIlHnpWuPNXtS =''
      KDAQgcxdGLzvhayieCIlHnpWuPNXBM =''
      if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('actor') !='' and KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('actor') !='-':KDAQgcxdGLzvhayieCIlHnpWuPNXtb =KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('actor').split(',')
      if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('director')!='' and KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('director')!='-':KDAQgcxdGLzvhayieCIlHnpWuPNXtM=KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('director').split(',')
      if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('cate_nm')!='' and KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('cate_nm')!='-':KDAQgcxdGLzvhayieCIlHnpWuPNXtm =KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('cate_nm').split('/')
      if KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('runtime_sec')!='':KDAQgcxdGLzvhayieCIlHnpWuPNXBr=KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('runtime_sec')
      if 'grade_nm' in KDAQgcxdGLzvhayieCIlHnpWuPNXkF:KDAQgcxdGLzvhayieCIlHnpWuPNXtr=KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('grade_nm')
      KDAQgcxdGLzvhayieCIlHnpWuPNXtO=KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('broad_dt')
      if data_str!='':
       KDAQgcxdGLzvhayieCIlHnpWuPNXBM='%s-%s-%s'%(KDAQgcxdGLzvhayieCIlHnpWuPNXtO[:4],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[4:6],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[6:])
       KDAQgcxdGLzvhayieCIlHnpWuPNXtS =KDAQgcxdGLzvhayieCIlHnpWuPNXtO[:4]
     except:
      KDAQgcxdGLzvhayieCIlHnpWuPNXbR
     KDAQgcxdGLzvhayieCIlHnpWuPNXtF={'movie':KDAQgcxdGLzvhayieCIlHnpWuPNXts,'title':KDAQgcxdGLzvhayieCIlHnpWuPNXJq,'thumbnail':{'poster':KDAQgcxdGLzvhayieCIlHnpWuPNXJj,'thumb':KDAQgcxdGLzvhayieCIlHnpWuPNXJf,'fanart':KDAQgcxdGLzvhayieCIlHnpWuPNXJf,'clearlogo':KDAQgcxdGLzvhayieCIlHnpWuPNXJT},'synopsis':'','cast':KDAQgcxdGLzvhayieCIlHnpWuPNXtb,'director':KDAQgcxdGLzvhayieCIlHnpWuPNXtM,'info_genre':KDAQgcxdGLzvhayieCIlHnpWuPNXtm,'duration':KDAQgcxdGLzvhayieCIlHnpWuPNXBr,'mpaa':KDAQgcxdGLzvhayieCIlHnpWuPNXtr,'year':KDAQgcxdGLzvhayieCIlHnpWuPNXtS,'aired':KDAQgcxdGLzvhayieCIlHnpWuPNXBM}
     KDAQgcxdGLzvhayieCIlHnpWuPNXBV=KDAQgcxdGLzvhayieCIlHnpWuPNXbO
     for KDAQgcxdGLzvhayieCIlHnpWuPNXBw in KDAQgcxdGLzvhayieCIlHnpWuPNXkF['bill']:
      if KDAQgcxdGLzvhayieCIlHnpWuPNXBw in KDAQgcxdGLzvhayieCIlHnpWuPNXoB.MOVIE_LITE:
       KDAQgcxdGLzvhayieCIlHnpWuPNXBV=KDAQgcxdGLzvhayieCIlHnpWuPNXbF
       break
     if KDAQgcxdGLzvhayieCIlHnpWuPNXBV==KDAQgcxdGLzvhayieCIlHnpWuPNXbO: 
      KDAQgcxdGLzvhayieCIlHnpWuPNXtF['title']=KDAQgcxdGLzvhayieCIlHnpWuPNXtF['title']+' [개별구매]'
     KDAQgcxdGLzvhayieCIlHnpWuPNXBY.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtF)
   if KDAQgcxdGLzvhayieCIlHnpWuPNXBs>(page_int*KDAQgcxdGLzvhayieCIlHnpWuPNXoB.SEARCH_LIMIT):KDAQgcxdGLzvhayieCIlHnpWuPNXJR=KDAQgcxdGLzvhayieCIlHnpWuPNXbF
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXBY,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
 def GetBookmarkInfo(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,videoid,vidtype):
  KDAQgcxdGLzvhayieCIlHnpWuPNXBq={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   KDAQgcxdGLzvhayieCIlHnpWuPNXkT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN+'/v2/media/program/'+videoid
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDefaultParams()
   KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'pageNo':'1','pageSize':'10','order':'name',}
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj.update(KDAQgcxdGLzvhayieCIlHnpWuPNXkO)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkj,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXbR)
   KDAQgcxdGLzvhayieCIlHnpWuPNXBU=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   if not('body' in KDAQgcxdGLzvhayieCIlHnpWuPNXBU):return{}
   KDAQgcxdGLzvhayieCIlHnpWuPNXBf=KDAQgcxdGLzvhayieCIlHnpWuPNXBU['body']
   KDAQgcxdGLzvhayieCIlHnpWuPNXJq=KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('name').get('ko').strip()
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['title'] =KDAQgcxdGLzvhayieCIlHnpWuPNXJq
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['title']=KDAQgcxdGLzvhayieCIlHnpWuPNXJq
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['mpaa'] =KDAQgcxdGLzvhayieCIlHnpWuPNXot.get(KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('grade_code'))
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['plot'] =KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('synopsis').get('ko')
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['year'] =KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('product_year')
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['cast'] =KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('actor')
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['director']=KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('director')
   if KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('category1_name').get('ko')!='':
    KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['genre'].append(KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('category1_name').get('ko'))
   if KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('category2_name').get('ko')!='':
    KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['genre'].append(KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('category2_name').get('ko'))
   KDAQgcxdGLzvhayieCIlHnpWuPNXtO=KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('broad_dt'))
   if KDAQgcxdGLzvhayieCIlHnpWuPNXtO!='0':KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(KDAQgcxdGLzvhayieCIlHnpWuPNXtO[:4],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[4:6],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[6:])
   KDAQgcxdGLzvhayieCIlHnpWuPNXJj =''
   KDAQgcxdGLzvhayieCIlHnpWuPNXJf =''
   KDAQgcxdGLzvhayieCIlHnpWuPNXJT=''
   KDAQgcxdGLzvhayieCIlHnpWuPNXto =''
   KDAQgcxdGLzvhayieCIlHnpWuPNXtk =''
   for KDAQgcxdGLzvhayieCIlHnpWuPNXtB in KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('image'):
    if KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('code')=='CAIP0900':KDAQgcxdGLzvhayieCIlHnpWuPNXJj =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('url')
    elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('code')=='CAIP0200':KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('url')
    elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('code')=='CAIP1800':KDAQgcxdGLzvhayieCIlHnpWuPNXJT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('url')
    elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('code')=='CAIP2000':KDAQgcxdGLzvhayieCIlHnpWuPNXto =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('url')
    elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('code')=='CAIP1900':KDAQgcxdGLzvhayieCIlHnpWuPNXtk =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('url')
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['thumbnail']['poster']=KDAQgcxdGLzvhayieCIlHnpWuPNXJj
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['thumbnail']['thumb']=KDAQgcxdGLzvhayieCIlHnpWuPNXJf
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['thumbnail']['clearlogo']=KDAQgcxdGLzvhayieCIlHnpWuPNXJT
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['thumbnail']['icon']=KDAQgcxdGLzvhayieCIlHnpWuPNXto
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['thumbnail']['banner']=KDAQgcxdGLzvhayieCIlHnpWuPNXtk
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['thumbnail']['fanart']=KDAQgcxdGLzvhayieCIlHnpWuPNXJf
  else:
   KDAQgcxdGLzvhayieCIlHnpWuPNXkT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN+'/v2a/media/stream/info'
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDefaultParams()
   KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_uuid'].split('-')[0],'uuid':KDAQgcxdGLzvhayieCIlHnpWuPNXoB.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetNoCache(1)),'wm':'Y',}
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj.update(KDAQgcxdGLzvhayieCIlHnpWuPNXkO)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkj,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXbR)
   KDAQgcxdGLzvhayieCIlHnpWuPNXBU=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   if not('content' in KDAQgcxdGLzvhayieCIlHnpWuPNXBU['body']):return{}
   KDAQgcxdGLzvhayieCIlHnpWuPNXBf=KDAQgcxdGLzvhayieCIlHnpWuPNXBU['body']['content']['info']['movie']
   KDAQgcxdGLzvhayieCIlHnpWuPNXJq =KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('name').get('ko').strip()
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['title']=KDAQgcxdGLzvhayieCIlHnpWuPNXJq
   KDAQgcxdGLzvhayieCIlHnpWuPNXJq +=u' (%s)'%(KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('product_year'))
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['title'] =KDAQgcxdGLzvhayieCIlHnpWuPNXJq
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['mpaa'] =KDAQgcxdGLzvhayieCIlHnpWuPNXot.get(KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('grade_code'))
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['plot'] =KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('story').get('ko')
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['year'] =KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('product_year')
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['studio'] =KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('production')
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['duration']=KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('duration')
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['cast'] =KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('actor')
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['director']=KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('director')
   if KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('category1_name').get('ko')!='':
    KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['genre'].append(KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('category1_name').get('ko'))
   if KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('category2_name').get('ko')!='':
    KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['genre'].append(KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('category2_name').get('ko'))
   KDAQgcxdGLzvhayieCIlHnpWuPNXtO=KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('release_date'))
   if KDAQgcxdGLzvhayieCIlHnpWuPNXtO!='0':KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(KDAQgcxdGLzvhayieCIlHnpWuPNXtO[:4],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[4:6],KDAQgcxdGLzvhayieCIlHnpWuPNXtO[6:])
   KDAQgcxdGLzvhayieCIlHnpWuPNXJj=''
   KDAQgcxdGLzvhayieCIlHnpWuPNXJf =''
   KDAQgcxdGLzvhayieCIlHnpWuPNXJT=''
   for KDAQgcxdGLzvhayieCIlHnpWuPNXtB in KDAQgcxdGLzvhayieCIlHnpWuPNXBf.get('image'):
    if KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('code')=='CAIM2100':KDAQgcxdGLzvhayieCIlHnpWuPNXJj =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('url')
    elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('code')=='CAIM0400':KDAQgcxdGLzvhayieCIlHnpWuPNXJf =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('url')
    elif KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('code')=='CAIM1800':KDAQgcxdGLzvhayieCIlHnpWuPNXJT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.IMG_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXtB.get('url')
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['thumbnail']['poster']=KDAQgcxdGLzvhayieCIlHnpWuPNXJj
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['thumbnail']['thumb']=KDAQgcxdGLzvhayieCIlHnpWuPNXJj 
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['thumbnail']['clearlogo']=KDAQgcxdGLzvhayieCIlHnpWuPNXJT
   KDAQgcxdGLzvhayieCIlHnpWuPNXBq['saveinfo']['thumbnail']['fanart']=KDAQgcxdGLzvhayieCIlHnpWuPNXJf
  return KDAQgcxdGLzvhayieCIlHnpWuPNXBq
 def GetEuroChannelList(KDAQgcxdGLzvhayieCIlHnpWuPNXoB):
  KDAQgcxdGLzvhayieCIlHnpWuPNXkV=[]
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXkS ='/v2/operator/highlights'
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetDefaultParams()
   KDAQgcxdGLzvhayieCIlHnpWuPNXkO={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':KDAQgcxdGLzvhayieCIlHnpWuPNXbf(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.GetNoCache(2))}
   KDAQgcxdGLzvhayieCIlHnpWuPNXkj.update(KDAQgcxdGLzvhayieCIlHnpWuPNXkO)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkT=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.API_DOMAIN+KDAQgcxdGLzvhayieCIlHnpWuPNXkS
   KDAQgcxdGLzvhayieCIlHnpWuPNXkt=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.callRequestCookies('Get',KDAQgcxdGLzvhayieCIlHnpWuPNXkT,payload=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,params=KDAQgcxdGLzvhayieCIlHnpWuPNXkj,headers=KDAQgcxdGLzvhayieCIlHnpWuPNXbR,cookies=KDAQgcxdGLzvhayieCIlHnpWuPNXbR)
   KDAQgcxdGLzvhayieCIlHnpWuPNXkY=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXkt.text)
   if not('result' in KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']):return KDAQgcxdGLzvhayieCIlHnpWuPNXkV,KDAQgcxdGLzvhayieCIlHnpWuPNXJR
   KDAQgcxdGLzvhayieCIlHnpWuPNXJY=KDAQgcxdGLzvhayieCIlHnpWuPNXkY['body']['result']
   KDAQgcxdGLzvhayieCIlHnpWuPNXBj =KDAQgcxdGLzvhayieCIlHnpWuPNXoB.Get_Now_Datetime()
   KDAQgcxdGLzvhayieCIlHnpWuPNXBT=KDAQgcxdGLzvhayieCIlHnpWuPNXBj+datetime.timedelta(days=-1)
   KDAQgcxdGLzvhayieCIlHnpWuPNXBT=KDAQgcxdGLzvhayieCIlHnpWuPNXbs(KDAQgcxdGLzvhayieCIlHnpWuPNXBT.strftime('%Y%m%d'))
   for KDAQgcxdGLzvhayieCIlHnpWuPNXkF in KDAQgcxdGLzvhayieCIlHnpWuPNXJY:
    KDAQgcxdGLzvhayieCIlHnpWuPNXbo=KDAQgcxdGLzvhayieCIlHnpWuPNXbs(KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('content').get('banner_title2')[:8])
    if KDAQgcxdGLzvhayieCIlHnpWuPNXBT<=KDAQgcxdGLzvhayieCIlHnpWuPNXbo:
     KDAQgcxdGLzvhayieCIlHnpWuPNXtF={'channel':KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('content').get('banner_sub_title3'),'title':KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('content').get('banner_title'),'subtitle':KDAQgcxdGLzvhayieCIlHnpWuPNXkF.get('content').get('banner_sub_title2'),}
     KDAQgcxdGLzvhayieCIlHnpWuPNXkV.append(KDAQgcxdGLzvhayieCIlHnpWuPNXtF)
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXkV
 def Make_DecryptKey(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,step,mediacode='000',timecode='000'):
  if step=='1':
   KDAQgcxdGLzvhayieCIlHnpWuPNXbk=KDAQgcxdGLzvhayieCIlHnpWuPNXbT('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   KDAQgcxdGLzvhayieCIlHnpWuPNXbJ=KDAQgcxdGLzvhayieCIlHnpWuPNXbT('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbk=KDAQgcxdGLzvhayieCIlHnpWuPNXbT('kss2lym0kdw1lks3','utf-8')
   KDAQgcxdGLzvhayieCIlHnpWuPNXbJ=KDAQgcxdGLzvhayieCIlHnpWuPNXbT([KDAQgcxdGLzvhayieCIlHnpWuPNXMo('*'),0x07,KDAQgcxdGLzvhayieCIlHnpWuPNXMo('r'),KDAQgcxdGLzvhayieCIlHnpWuPNXMo(';'),KDAQgcxdGLzvhayieCIlHnpWuPNXMo('7'),0x05,0x1e,0x01,KDAQgcxdGLzvhayieCIlHnpWuPNXMo('n'),KDAQgcxdGLzvhayieCIlHnpWuPNXMo('D'),0x02,KDAQgcxdGLzvhayieCIlHnpWuPNXMo('3'),KDAQgcxdGLzvhayieCIlHnpWuPNXMo('*'),KDAQgcxdGLzvhayieCIlHnpWuPNXMo('a'),KDAQgcxdGLzvhayieCIlHnpWuPNXMo('&'),KDAQgcxdGLzvhayieCIlHnpWuPNXMo('<')])
  return KDAQgcxdGLzvhayieCIlHnpWuPNXbk,KDAQgcxdGLzvhayieCIlHnpWuPNXbJ
 def DecryptPlaintext(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,ciphertext,encryption_key,init_vector):
  KDAQgcxdGLzvhayieCIlHnpWuPNXbt=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  KDAQgcxdGLzvhayieCIlHnpWuPNXbB=Padding.unpad(KDAQgcxdGLzvhayieCIlHnpWuPNXbt.decrypt(base64.standard_b64decode(ciphertext)),16)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXbB.decode('utf-8')
 def Decrypt_Url(KDAQgcxdGLzvhayieCIlHnpWuPNXoB,ciphertext,mediacode,KDAQgcxdGLzvhayieCIlHnpWuPNXJM):
  KDAQgcxdGLzvhayieCIlHnpWuPNXbM=''
  KDAQgcxdGLzvhayieCIlHnpWuPNXJm=''
  KDAQgcxdGLzvhayieCIlHnpWuPNXJS=''
  try:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbk,KDAQgcxdGLzvhayieCIlHnpWuPNXbJ=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.Make_DecryptKey('1',mediacode=mediacode,timecode=KDAQgcxdGLzvhayieCIlHnpWuPNXJM)
   KDAQgcxdGLzvhayieCIlHnpWuPNXbm=json.loads(KDAQgcxdGLzvhayieCIlHnpWuPNXoB.DecryptPlaintext(ciphertext,KDAQgcxdGLzvhayieCIlHnpWuPNXbk,KDAQgcxdGLzvhayieCIlHnpWuPNXbJ))
   KDAQgcxdGLzvhayieCIlHnpWuPNXbS =KDAQgcxdGLzvhayieCIlHnpWuPNXbm.get('broad_url')
   KDAQgcxdGLzvhayieCIlHnpWuPNXJm =KDAQgcxdGLzvhayieCIlHnpWuPNXbm.get('watermark') if 'watermark' in KDAQgcxdGLzvhayieCIlHnpWuPNXbm else ''
   KDAQgcxdGLzvhayieCIlHnpWuPNXJS=KDAQgcxdGLzvhayieCIlHnpWuPNXbm.get('watermarkKey')if 'watermarkKey' in KDAQgcxdGLzvhayieCIlHnpWuPNXbm else ''
   KDAQgcxdGLzvhayieCIlHnpWuPNXbk,KDAQgcxdGLzvhayieCIlHnpWuPNXbJ=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.Make_DecryptKey('2',mediacode=mediacode,timecode=KDAQgcxdGLzvhayieCIlHnpWuPNXJM)
   KDAQgcxdGLzvhayieCIlHnpWuPNXbM=KDAQgcxdGLzvhayieCIlHnpWuPNXoB.DecryptPlaintext(KDAQgcxdGLzvhayieCIlHnpWuPNXbS,KDAQgcxdGLzvhayieCIlHnpWuPNXbk,KDAQgcxdGLzvhayieCIlHnpWuPNXbJ)
  except KDAQgcxdGLzvhayieCIlHnpWuPNXbq as exception:
   KDAQgcxdGLzvhayieCIlHnpWuPNXbr(exception)
  return KDAQgcxdGLzvhayieCIlHnpWuPNXbM,KDAQgcxdGLzvhayieCIlHnpWuPNXJm,KDAQgcxdGLzvhayieCIlHnpWuPNXJS
# Created by pyminifier (https://github.com/liftoff/pyminifier)
