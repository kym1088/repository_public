__author__="NightRain"
LSGOkacCwMeQojWxygBUqihDAdPfuV=object
LSGOkacCwMeQojWxygBUqihDAdPfut=None
LSGOkacCwMeQojWxygBUqihDAdPfuF=int
LSGOkacCwMeQojWxygBUqihDAdPfur=True
LSGOkacCwMeQojWxygBUqihDAdPfuK=False
LSGOkacCwMeQojWxygBUqihDAdPfuT=type
LSGOkacCwMeQojWxygBUqihDAdPfuN=dict
LSGOkacCwMeQojWxygBUqihDAdPfuz=len
LSGOkacCwMeQojWxygBUqihDAdPful=str
LSGOkacCwMeQojWxygBUqihDAdPfuY=range
LSGOkacCwMeQojWxygBUqihDAdPfus=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
LSGOkacCwMeQojWxygBUqihDAdPfHp=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
LSGOkacCwMeQojWxygBUqihDAdPfHR=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
LSGOkacCwMeQojWxygBUqihDAdPfHn=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
LSGOkacCwMeQojWxygBUqihDAdPfHI=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
LSGOkacCwMeQojWxygBUqihDAdPfHm=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
LSGOkacCwMeQojWxygBUqihDAdPfHu=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG160,MG140,MG150'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐/클래식','mode':'MOVIE_SUB','stype':'MG250,MG330'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
LSGOkacCwMeQojWxygBUqihDAdPfHJ=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
LSGOkacCwMeQojWxygBUqihDAdPfHV =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
LSGOkacCwMeQojWxygBUqihDAdPfHt=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class LSGOkacCwMeQojWxygBUqihDAdPfHE(LSGOkacCwMeQojWxygBUqihDAdPfuV):
 def __init__(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfHr,LSGOkacCwMeQojWxygBUqihDAdPfHK,LSGOkacCwMeQojWxygBUqihDAdPfHT):
  LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_url =LSGOkacCwMeQojWxygBUqihDAdPfHr
  LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle=LSGOkacCwMeQojWxygBUqihDAdPfHK
  LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params =LSGOkacCwMeQojWxygBUqihDAdPfHT
  LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj =KDAQgcxdGLzvhayieCIlHnpWuPNXok() 
 def addon_noti(LSGOkacCwMeQojWxygBUqihDAdPfHF,sting):
  try:
   LSGOkacCwMeQojWxygBUqihDAdPfHz=xbmcgui.Dialog()
   LSGOkacCwMeQojWxygBUqihDAdPfHz.notification(__addonname__,sting)
  except:
   LSGOkacCwMeQojWxygBUqihDAdPfut
 def addon_log(LSGOkacCwMeQojWxygBUqihDAdPfHF,string):
  try:
   LSGOkacCwMeQojWxygBUqihDAdPfHl=string.encode('utf-8','ignore')
  except:
   LSGOkacCwMeQojWxygBUqihDAdPfHl='addonException: addon_log'
  LSGOkacCwMeQojWxygBUqihDAdPfHY=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,LSGOkacCwMeQojWxygBUqihDAdPfHl),level=LSGOkacCwMeQojWxygBUqihDAdPfHY)
 def get_keyboard_input(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfEF):
  LSGOkacCwMeQojWxygBUqihDAdPfHs=LSGOkacCwMeQojWxygBUqihDAdPfut
  kb=xbmc.Keyboard()
  kb.setHeading(LSGOkacCwMeQojWxygBUqihDAdPfEF)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   LSGOkacCwMeQojWxygBUqihDAdPfHs=kb.getText()
  return LSGOkacCwMeQojWxygBUqihDAdPfHs
 def get_settings_account(LSGOkacCwMeQojWxygBUqihDAdPfHF):
  LSGOkacCwMeQojWxygBUqihDAdPfHX =__addon__.getSetting('id')
  LSGOkacCwMeQojWxygBUqihDAdPfHv =__addon__.getSetting('pw')
  LSGOkacCwMeQojWxygBUqihDAdPfHb =__addon__.getSetting('login_type')
  LSGOkacCwMeQojWxygBUqihDAdPfEH=LSGOkacCwMeQojWxygBUqihDAdPfuF(__addon__.getSetting('selected_profile'))
  return(LSGOkacCwMeQojWxygBUqihDAdPfHX,LSGOkacCwMeQojWxygBUqihDAdPfHv,LSGOkacCwMeQojWxygBUqihDAdPfHb,LSGOkacCwMeQojWxygBUqihDAdPfEH)
 def get_settings_uhd(LSGOkacCwMeQojWxygBUqihDAdPfHF):
  return LSGOkacCwMeQojWxygBUqihDAdPfur if __addon__.getSetting('active_uhd')=='true' else LSGOkacCwMeQojWxygBUqihDAdPfuK
 def get_settings_totalsearch(LSGOkacCwMeQojWxygBUqihDAdPfHF):
  LSGOkacCwMeQojWxygBUqihDAdPfEp =LSGOkacCwMeQojWxygBUqihDAdPfur if __addon__.getSetting('local_search')=='true' else LSGOkacCwMeQojWxygBUqihDAdPfuK
  LSGOkacCwMeQojWxygBUqihDAdPfER=LSGOkacCwMeQojWxygBUqihDAdPfur if __addon__.getSetting('local_history')=='true' else LSGOkacCwMeQojWxygBUqihDAdPfuK
  LSGOkacCwMeQojWxygBUqihDAdPfEn =LSGOkacCwMeQojWxygBUqihDAdPfur if __addon__.getSetting('total_search')=='true' else LSGOkacCwMeQojWxygBUqihDAdPfuK
  LSGOkacCwMeQojWxygBUqihDAdPfEI=LSGOkacCwMeQojWxygBUqihDAdPfur if __addon__.getSetting('total_history')=='true' else LSGOkacCwMeQojWxygBUqihDAdPfuK
  LSGOkacCwMeQojWxygBUqihDAdPfEm=LSGOkacCwMeQojWxygBUqihDAdPfur if __addon__.getSetting('menu_bookmark')=='true' else LSGOkacCwMeQojWxygBUqihDAdPfuK
  return(LSGOkacCwMeQojWxygBUqihDAdPfEp,LSGOkacCwMeQojWxygBUqihDAdPfER,LSGOkacCwMeQojWxygBUqihDAdPfEn,LSGOkacCwMeQojWxygBUqihDAdPfEI,LSGOkacCwMeQojWxygBUqihDAdPfEm)
 def get_settings_makebookmark(LSGOkacCwMeQojWxygBUqihDAdPfHF):
  return LSGOkacCwMeQojWxygBUqihDAdPfur if __addon__.getSetting('make_bookmark')=='true' else LSGOkacCwMeQojWxygBUqihDAdPfuK
 def get_settings_direct_replay(LSGOkacCwMeQojWxygBUqihDAdPfHF):
  LSGOkacCwMeQojWxygBUqihDAdPfEu=LSGOkacCwMeQojWxygBUqihDAdPfuF(__addon__.getSetting('direct_replay'))
  if LSGOkacCwMeQojWxygBUqihDAdPfEu==0:
   return LSGOkacCwMeQojWxygBUqihDAdPfuK
  else:
   return LSGOkacCwMeQojWxygBUqihDAdPfur
 def set_winEpisodeOrderby(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfEV):
  __addon__.setSetting('tving_orderby',LSGOkacCwMeQojWxygBUqihDAdPfEV)
  LSGOkacCwMeQojWxygBUqihDAdPfEJ=xbmcgui.Window(10000)
  LSGOkacCwMeQojWxygBUqihDAdPfEJ.setProperty('TVING_M_ORDERBY',LSGOkacCwMeQojWxygBUqihDAdPfEV)
 def get_winEpisodeOrderby(LSGOkacCwMeQojWxygBUqihDAdPfHF):
  LSGOkacCwMeQojWxygBUqihDAdPfEV=__addon__.getSetting('tving_orderby')
  if LSGOkacCwMeQojWxygBUqihDAdPfEV in['',LSGOkacCwMeQojWxygBUqihDAdPfut]:LSGOkacCwMeQojWxygBUqihDAdPfEV='desc'
  return LSGOkacCwMeQojWxygBUqihDAdPfEV
 def add_dir(LSGOkacCwMeQojWxygBUqihDAdPfHF,label,sublabel='',img='',infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfut,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params='',isLink=LSGOkacCwMeQojWxygBUqihDAdPfuK,ContextMenu=LSGOkacCwMeQojWxygBUqihDAdPfut):
  LSGOkacCwMeQojWxygBUqihDAdPfEt='%s?%s'%(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_url,urllib.parse.urlencode(params))
  if sublabel:LSGOkacCwMeQojWxygBUqihDAdPfEF='%s < %s >'%(label,sublabel)
  else: LSGOkacCwMeQojWxygBUqihDAdPfEF=label
  if not img:img='DefaultFolder.png'
  LSGOkacCwMeQojWxygBUqihDAdPfEr=xbmcgui.ListItem(LSGOkacCwMeQojWxygBUqihDAdPfEF)
  if LSGOkacCwMeQojWxygBUqihDAdPfuT(img)==LSGOkacCwMeQojWxygBUqihDAdPfuN:
   LSGOkacCwMeQojWxygBUqihDAdPfEr.setArt(img)
  else:
   LSGOkacCwMeQojWxygBUqihDAdPfEr.setArt({'thumb':img,'poster':img})
  if infoLabels:LSGOkacCwMeQojWxygBUqihDAdPfEr.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   LSGOkacCwMeQojWxygBUqihDAdPfEr.setProperty('IsPlayable','true')
  if ContextMenu:LSGOkacCwMeQojWxygBUqihDAdPfEr.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,LSGOkacCwMeQojWxygBUqihDAdPfEt,LSGOkacCwMeQojWxygBUqihDAdPfEr,isFolder)
 def get_selQuality(LSGOkacCwMeQojWxygBUqihDAdPfHF,etype):
  try:
   LSGOkacCwMeQojWxygBUqihDAdPfEK='selected_quality'
   LSGOkacCwMeQojWxygBUqihDAdPfET=[1080,720,480,360]
   LSGOkacCwMeQojWxygBUqihDAdPfEN=LSGOkacCwMeQojWxygBUqihDAdPfuF(__addon__.getSetting(LSGOkacCwMeQojWxygBUqihDAdPfEK))
   return LSGOkacCwMeQojWxygBUqihDAdPfET[LSGOkacCwMeQojWxygBUqihDAdPfEN]
  except:
   LSGOkacCwMeQojWxygBUqihDAdPfut
  return 720 
 def dp_Main_List(LSGOkacCwMeQojWxygBUqihDAdPfHF):
  (LSGOkacCwMeQojWxygBUqihDAdPfEp,LSGOkacCwMeQojWxygBUqihDAdPfER,LSGOkacCwMeQojWxygBUqihDAdPfEn,LSGOkacCwMeQojWxygBUqihDAdPfEI,LSGOkacCwMeQojWxygBUqihDAdPfEm)=LSGOkacCwMeQojWxygBUqihDAdPfHF.get_settings_totalsearch()
  for LSGOkacCwMeQojWxygBUqihDAdPfEz in LSGOkacCwMeQojWxygBUqihDAdPfHp:
   LSGOkacCwMeQojWxygBUqihDAdPfEF=LSGOkacCwMeQojWxygBUqihDAdPfEz.get('title')
   LSGOkacCwMeQojWxygBUqihDAdPfEl=''
   if LSGOkacCwMeQojWxygBUqihDAdPfEz.get('mode')=='SEARCH_GROUP' and LSGOkacCwMeQojWxygBUqihDAdPfEp ==LSGOkacCwMeQojWxygBUqihDAdPfuK:continue
   elif LSGOkacCwMeQojWxygBUqihDAdPfEz.get('mode')=='SEARCH_HISTORY' and LSGOkacCwMeQojWxygBUqihDAdPfER==LSGOkacCwMeQojWxygBUqihDAdPfuK:continue
   elif LSGOkacCwMeQojWxygBUqihDAdPfEz.get('mode')=='TOTAL_SEARCH' and LSGOkacCwMeQojWxygBUqihDAdPfEn ==LSGOkacCwMeQojWxygBUqihDAdPfuK:continue
   elif LSGOkacCwMeQojWxygBUqihDAdPfEz.get('mode')=='TOTAL_HISTORY' and LSGOkacCwMeQojWxygBUqihDAdPfEI==LSGOkacCwMeQojWxygBUqihDAdPfuK:continue
   elif LSGOkacCwMeQojWxygBUqihDAdPfEz.get('mode')=='MENU_BOOKMARK' and LSGOkacCwMeQojWxygBUqihDAdPfEm==LSGOkacCwMeQojWxygBUqihDAdPfuK:continue
   LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':LSGOkacCwMeQojWxygBUqihDAdPfEz.get('mode'),'stype':LSGOkacCwMeQojWxygBUqihDAdPfEz.get('stype'),'orderby':LSGOkacCwMeQojWxygBUqihDAdPfEz.get('orderby'),'ordernm':LSGOkacCwMeQojWxygBUqihDAdPfEz.get('ordernm'),'page':'1'}
   if LSGOkacCwMeQojWxygBUqihDAdPfEz.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    LSGOkacCwMeQojWxygBUqihDAdPfEs=LSGOkacCwMeQojWxygBUqihDAdPfuK
    LSGOkacCwMeQojWxygBUqihDAdPfEX =LSGOkacCwMeQojWxygBUqihDAdPfur
   else:
    LSGOkacCwMeQojWxygBUqihDAdPfEs=LSGOkacCwMeQojWxygBUqihDAdPfur
    LSGOkacCwMeQojWxygBUqihDAdPfEX =LSGOkacCwMeQojWxygBUqihDAdPfuK
   if 'icon' in LSGOkacCwMeQojWxygBUqihDAdPfEz:LSGOkacCwMeQojWxygBUqihDAdPfEl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',LSGOkacCwMeQojWxygBUqihDAdPfEz.get('icon')) 
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel='',img=LSGOkacCwMeQojWxygBUqihDAdPfEl,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfut,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfEs,params=LSGOkacCwMeQojWxygBUqihDAdPfEY,isLink=LSGOkacCwMeQojWxygBUqihDAdPfEX)
  xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle)
 def login_main(LSGOkacCwMeQojWxygBUqihDAdPfHF):
  (LSGOkacCwMeQojWxygBUqihDAdPfEb,LSGOkacCwMeQojWxygBUqihDAdPfpH,LSGOkacCwMeQojWxygBUqihDAdPfpE,LSGOkacCwMeQojWxygBUqihDAdPfpR)=LSGOkacCwMeQojWxygBUqihDAdPfHF.get_settings_account()
  if not(LSGOkacCwMeQojWxygBUqihDAdPfEb and LSGOkacCwMeQojWxygBUqihDAdPfpH):
   LSGOkacCwMeQojWxygBUqihDAdPfHz=xbmcgui.Dialog()
   LSGOkacCwMeQojWxygBUqihDAdPfpn=LSGOkacCwMeQojWxygBUqihDAdPfHz.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if LSGOkacCwMeQojWxygBUqihDAdPfpn==LSGOkacCwMeQojWxygBUqihDAdPfur:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if LSGOkacCwMeQojWxygBUqihDAdPfHF.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   LSGOkacCwMeQojWxygBUqihDAdPfpI=0
   while LSGOkacCwMeQojWxygBUqihDAdPfur:
    LSGOkacCwMeQojWxygBUqihDAdPfpI+=1
    time.sleep(0.05)
    if LSGOkacCwMeQojWxygBUqihDAdPfpI>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  LSGOkacCwMeQojWxygBUqihDAdPfpm=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.GetCredential(LSGOkacCwMeQojWxygBUqihDAdPfEb,LSGOkacCwMeQojWxygBUqihDAdPfpH,LSGOkacCwMeQojWxygBUqihDAdPfpE,LSGOkacCwMeQojWxygBUqihDAdPfpR)
  if LSGOkacCwMeQojWxygBUqihDAdPfpm:LSGOkacCwMeQojWxygBUqihDAdPfHF.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if LSGOkacCwMeQojWxygBUqihDAdPfpm==LSGOkacCwMeQojWxygBUqihDAdPfuK:
   LSGOkacCwMeQojWxygBUqihDAdPfHF.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfpu=LSGOkacCwMeQojWxygBUqihDAdPfpt.get('stype')
  if LSGOkacCwMeQojWxygBUqihDAdPfpu=='live':
   LSGOkacCwMeQojWxygBUqihDAdPfpJ=LSGOkacCwMeQojWxygBUqihDAdPfHR
  elif LSGOkacCwMeQojWxygBUqihDAdPfpu=='vod':
   LSGOkacCwMeQojWxygBUqihDAdPfpJ=LSGOkacCwMeQojWxygBUqihDAdPfHm
  else:
   LSGOkacCwMeQojWxygBUqihDAdPfpJ=LSGOkacCwMeQojWxygBUqihDAdPfHu
  for LSGOkacCwMeQojWxygBUqihDAdPfpV in LSGOkacCwMeQojWxygBUqihDAdPfpJ:
   LSGOkacCwMeQojWxygBUqihDAdPfEF=LSGOkacCwMeQojWxygBUqihDAdPfpV.get('title')
   if LSGOkacCwMeQojWxygBUqihDAdPfpt.get('ordernm')!='-':
    LSGOkacCwMeQojWxygBUqihDAdPfEF+='  ('+LSGOkacCwMeQojWxygBUqihDAdPfpt.get('ordernm')+')'
   LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':LSGOkacCwMeQojWxygBUqihDAdPfpV.get('mode'),'stype':LSGOkacCwMeQojWxygBUqihDAdPfpV.get('stype'),'orderby':LSGOkacCwMeQojWxygBUqihDAdPfpt.get('orderby'),'ordernm':LSGOkacCwMeQojWxygBUqihDAdPfpt.get('ordernm'),'page':'1'}
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel='',img='',infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfut,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
  if LSGOkacCwMeQojWxygBUqihDAdPfuz(LSGOkacCwMeQojWxygBUqihDAdPfpJ)>0:xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle)
 def dp_SubTitle_Group(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt): 
  for LSGOkacCwMeQojWxygBUqihDAdPfpV in LSGOkacCwMeQojWxygBUqihDAdPfHJ:
   LSGOkacCwMeQojWxygBUqihDAdPfEF=LSGOkacCwMeQojWxygBUqihDAdPfpV.get('title')
   if LSGOkacCwMeQojWxygBUqihDAdPfpt.get('ordernm')!='-':
    LSGOkacCwMeQojWxygBUqihDAdPfEF+='  ('+LSGOkacCwMeQojWxygBUqihDAdPfpt.get('ordernm')+')'
   LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':LSGOkacCwMeQojWxygBUqihDAdPfpV.get('mode'),'genreCode':LSGOkacCwMeQojWxygBUqihDAdPfpV.get('genreCode'),'stype':LSGOkacCwMeQojWxygBUqihDAdPfpt.get('stype'),'orderby':LSGOkacCwMeQojWxygBUqihDAdPfpt.get('orderby'),'page':'1'}
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel='',img='',infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfut,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
  if LSGOkacCwMeQojWxygBUqihDAdPfuz(LSGOkacCwMeQojWxygBUqihDAdPfHJ)>0:xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle)
 def dp_LiveChannel_List(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfpu =LSGOkacCwMeQojWxygBUqihDAdPfpt.get('stype')
  LSGOkacCwMeQojWxygBUqihDAdPfpF =LSGOkacCwMeQojWxygBUqihDAdPfuF(LSGOkacCwMeQojWxygBUqihDAdPfpt.get('page'))
  LSGOkacCwMeQojWxygBUqihDAdPfpr,LSGOkacCwMeQojWxygBUqihDAdPfpK=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.GetLiveChannelList(LSGOkacCwMeQojWxygBUqihDAdPfpu,LSGOkacCwMeQojWxygBUqihDAdPfpF)
  for LSGOkacCwMeQojWxygBUqihDAdPfpT in LSGOkacCwMeQojWxygBUqihDAdPfpr:
   LSGOkacCwMeQojWxygBUqihDAdPfEF =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('title')
   LSGOkacCwMeQojWxygBUqihDAdPfEv =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('channel')
   LSGOkacCwMeQojWxygBUqihDAdPfpN =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('thumbnail')
   LSGOkacCwMeQojWxygBUqihDAdPfpz =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('synopsis')
   LSGOkacCwMeQojWxygBUqihDAdPfpl =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('channelepg')
   LSGOkacCwMeQojWxygBUqihDAdPfpY =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('cast')
   LSGOkacCwMeQojWxygBUqihDAdPfps =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('director')
   LSGOkacCwMeQojWxygBUqihDAdPfpX =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('info_genre')
   LSGOkacCwMeQojWxygBUqihDAdPfpv =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('year')
   LSGOkacCwMeQojWxygBUqihDAdPfpb =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('mpaa')
   LSGOkacCwMeQojWxygBUqihDAdPfRH =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('premiered')
   LSGOkacCwMeQojWxygBUqihDAdPfRE={'mediatype':'episode','title':LSGOkacCwMeQojWxygBUqihDAdPfEF,'studio':LSGOkacCwMeQojWxygBUqihDAdPfEv,'cast':LSGOkacCwMeQojWxygBUqihDAdPfpY,'director':LSGOkacCwMeQojWxygBUqihDAdPfps,'genre':LSGOkacCwMeQojWxygBUqihDAdPfpX,'plot':'%s\n%s\n%s\n\n%s'%(LSGOkacCwMeQojWxygBUqihDAdPfEv,LSGOkacCwMeQojWxygBUqihDAdPfEF,LSGOkacCwMeQojWxygBUqihDAdPfpl,LSGOkacCwMeQojWxygBUqihDAdPfpz),'year':LSGOkacCwMeQojWxygBUqihDAdPfpv,'mpaa':LSGOkacCwMeQojWxygBUqihDAdPfpb,'premiered':LSGOkacCwMeQojWxygBUqihDAdPfRH}
   LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'LIVE','mediacode':LSGOkacCwMeQojWxygBUqihDAdPfpT.get('mediacode'),'stype':LSGOkacCwMeQojWxygBUqihDAdPfpu}
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEv,sublabel=LSGOkacCwMeQojWxygBUqihDAdPfEF,img=LSGOkacCwMeQojWxygBUqihDAdPfpN,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfRE,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfuK,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
  if LSGOkacCwMeQojWxygBUqihDAdPfpK:
   LSGOkacCwMeQojWxygBUqihDAdPfEY['mode']='CHANNEL' 
   LSGOkacCwMeQojWxygBUqihDAdPfEY['stype']=LSGOkacCwMeQojWxygBUqihDAdPfpu 
   LSGOkacCwMeQojWxygBUqihDAdPfEY['page']=LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEF='[B]%s >>[/B]'%'다음 페이지'
   LSGOkacCwMeQojWxygBUqihDAdPfRp=LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel=LSGOkacCwMeQojWxygBUqihDAdPfRp,img=LSGOkacCwMeQojWxygBUqihDAdPfEl,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfut,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
  if LSGOkacCwMeQojWxygBUqihDAdPfuz(LSGOkacCwMeQojWxygBUqihDAdPfpr)>0:xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,cacheToDisc=LSGOkacCwMeQojWxygBUqihDAdPfuK)
 def dp_Program_List(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfRn =LSGOkacCwMeQojWxygBUqihDAdPfpt.get('stype')
  LSGOkacCwMeQojWxygBUqihDAdPfEV =LSGOkacCwMeQojWxygBUqihDAdPfpt.get('orderby')
  LSGOkacCwMeQojWxygBUqihDAdPfpF =LSGOkacCwMeQojWxygBUqihDAdPfuF(LSGOkacCwMeQojWxygBUqihDAdPfpt.get('page'))
  LSGOkacCwMeQojWxygBUqihDAdPfRI=LSGOkacCwMeQojWxygBUqihDAdPfpt.get('genreCode')
  if LSGOkacCwMeQojWxygBUqihDAdPfRI==LSGOkacCwMeQojWxygBUqihDAdPfut:LSGOkacCwMeQojWxygBUqihDAdPfRI='all'
  LSGOkacCwMeQojWxygBUqihDAdPfRm,LSGOkacCwMeQojWxygBUqihDAdPfpK=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.GetProgramList(LSGOkacCwMeQojWxygBUqihDAdPfRn,LSGOkacCwMeQojWxygBUqihDAdPfEV,LSGOkacCwMeQojWxygBUqihDAdPfpF,LSGOkacCwMeQojWxygBUqihDAdPfRI)
  for LSGOkacCwMeQojWxygBUqihDAdPfRu in LSGOkacCwMeQojWxygBUqihDAdPfRm:
   LSGOkacCwMeQojWxygBUqihDAdPfEF =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('title')
   LSGOkacCwMeQojWxygBUqihDAdPfpN =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('thumbnail')
   LSGOkacCwMeQojWxygBUqihDAdPfpz =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('synopsis')
   LSGOkacCwMeQojWxygBUqihDAdPfRJ =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('channel')
   LSGOkacCwMeQojWxygBUqihDAdPfpY =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('cast')
   LSGOkacCwMeQojWxygBUqihDAdPfps =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('director')
   LSGOkacCwMeQojWxygBUqihDAdPfpX=LSGOkacCwMeQojWxygBUqihDAdPfRu.get('info_genre')
   LSGOkacCwMeQojWxygBUqihDAdPfpv =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('year')
   LSGOkacCwMeQojWxygBUqihDAdPfRH =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('premiered')
   LSGOkacCwMeQojWxygBUqihDAdPfpb =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('mpaa')
   LSGOkacCwMeQojWxygBUqihDAdPfRE={'mediatype':'tvshow','title':LSGOkacCwMeQojWxygBUqihDAdPfEF,'studio':LSGOkacCwMeQojWxygBUqihDAdPfRJ,'cast':LSGOkacCwMeQojWxygBUqihDAdPfpY,'director':LSGOkacCwMeQojWxygBUqihDAdPfps,'genre':LSGOkacCwMeQojWxygBUqihDAdPfpX,'year':LSGOkacCwMeQojWxygBUqihDAdPfpv,'premiered':LSGOkacCwMeQojWxygBUqihDAdPfRH,'mpaa':LSGOkacCwMeQojWxygBUqihDAdPfpb,'plot':LSGOkacCwMeQojWxygBUqihDAdPfpz}
   LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'EPISODE','programcode':LSGOkacCwMeQojWxygBUqihDAdPfRu.get('program'),'page':'1'}
   if LSGOkacCwMeQojWxygBUqihDAdPfHF.get_settings_makebookmark():
    LSGOkacCwMeQojWxygBUqihDAdPfRV={'videoid':LSGOkacCwMeQojWxygBUqihDAdPfRu.get('program'),'vidtype':'tvshow','vtitle':LSGOkacCwMeQojWxygBUqihDAdPfEF,'vsubtitle':LSGOkacCwMeQojWxygBUqihDAdPfRJ,}
    LSGOkacCwMeQojWxygBUqihDAdPfRt=json.dumps(LSGOkacCwMeQojWxygBUqihDAdPfRV)
    LSGOkacCwMeQojWxygBUqihDAdPfRt=urllib.parse.quote(LSGOkacCwMeQojWxygBUqihDAdPfRt)
    LSGOkacCwMeQojWxygBUqihDAdPfRF='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(LSGOkacCwMeQojWxygBUqihDAdPfRt)
    LSGOkacCwMeQojWxygBUqihDAdPfRr=[('(통합) 찜 영상에 추가',LSGOkacCwMeQojWxygBUqihDAdPfRF)]
   else:
    LSGOkacCwMeQojWxygBUqihDAdPfRr=LSGOkacCwMeQojWxygBUqihDAdPfut
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel=LSGOkacCwMeQojWxygBUqihDAdPfRJ,img=LSGOkacCwMeQojWxygBUqihDAdPfpN,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfRE,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY,ContextMenu=LSGOkacCwMeQojWxygBUqihDAdPfRr)
  if LSGOkacCwMeQojWxygBUqihDAdPfpK:
   LSGOkacCwMeQojWxygBUqihDAdPfEY['mode'] ='PROGRAM' 
   LSGOkacCwMeQojWxygBUqihDAdPfEY['stype'] =LSGOkacCwMeQojWxygBUqihDAdPfRn
   LSGOkacCwMeQojWxygBUqihDAdPfEY['orderby'] =LSGOkacCwMeQojWxygBUqihDAdPfEV
   LSGOkacCwMeQojWxygBUqihDAdPfEY['page'] =LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEY['genreCode']=LSGOkacCwMeQojWxygBUqihDAdPfRI 
   LSGOkacCwMeQojWxygBUqihDAdPfEF='[B]%s >>[/B]'%'다음 페이지'
   LSGOkacCwMeQojWxygBUqihDAdPfRp=LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel=LSGOkacCwMeQojWxygBUqihDAdPfRp,img=LSGOkacCwMeQojWxygBUqihDAdPfEl,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfut,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
  xbmcplugin.setContent(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,cacheToDisc=LSGOkacCwMeQojWxygBUqihDAdPfuK)
 def dp_4K_Program_List(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfpF =LSGOkacCwMeQojWxygBUqihDAdPfuF(LSGOkacCwMeQojWxygBUqihDAdPfpt.get('page'))
  LSGOkacCwMeQojWxygBUqihDAdPfRm,LSGOkacCwMeQojWxygBUqihDAdPfpK=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.Get_UHD_ProgramList(LSGOkacCwMeQojWxygBUqihDAdPfpF)
  for LSGOkacCwMeQojWxygBUqihDAdPfRu in LSGOkacCwMeQojWxygBUqihDAdPfRm:
   LSGOkacCwMeQojWxygBUqihDAdPfEF =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('title')
   LSGOkacCwMeQojWxygBUqihDAdPfpN =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('thumbnail')
   LSGOkacCwMeQojWxygBUqihDAdPfpz =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('synopsis')
   LSGOkacCwMeQojWxygBUqihDAdPfRJ =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('channel')
   LSGOkacCwMeQojWxygBUqihDAdPfpY =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('cast')
   LSGOkacCwMeQojWxygBUqihDAdPfps =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('director')
   LSGOkacCwMeQojWxygBUqihDAdPfpX=LSGOkacCwMeQojWxygBUqihDAdPfRu.get('info_genre')
   LSGOkacCwMeQojWxygBUqihDAdPfpv =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('year')
   LSGOkacCwMeQojWxygBUqihDAdPfRH =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('premiered')
   LSGOkacCwMeQojWxygBUqihDAdPfpb =LSGOkacCwMeQojWxygBUqihDAdPfRu.get('mpaa')
   LSGOkacCwMeQojWxygBUqihDAdPfRE={'mediatype':'tvshow','title':LSGOkacCwMeQojWxygBUqihDAdPfEF,'studio':LSGOkacCwMeQojWxygBUqihDAdPfRJ,'cast':LSGOkacCwMeQojWxygBUqihDAdPfpY,'director':LSGOkacCwMeQojWxygBUqihDAdPfps,'genre':LSGOkacCwMeQojWxygBUqihDAdPfpX,'year':LSGOkacCwMeQojWxygBUqihDAdPfpv,'premiered':LSGOkacCwMeQojWxygBUqihDAdPfRH,'mpaa':LSGOkacCwMeQojWxygBUqihDAdPfpb,'plot':LSGOkacCwMeQojWxygBUqihDAdPfpz}
   LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'EPISODE','programcode':LSGOkacCwMeQojWxygBUqihDAdPfRu.get('program'),'page':'1'}
   if LSGOkacCwMeQojWxygBUqihDAdPfHF.get_settings_makebookmark():
    LSGOkacCwMeQojWxygBUqihDAdPfRV={'videoid':LSGOkacCwMeQojWxygBUqihDAdPfRu.get('program'),'vidtype':'tvshow','vtitle':LSGOkacCwMeQojWxygBUqihDAdPfEF,'vsubtitle':LSGOkacCwMeQojWxygBUqihDAdPfRJ,}
    LSGOkacCwMeQojWxygBUqihDAdPfRt=json.dumps(LSGOkacCwMeQojWxygBUqihDAdPfRV)
    LSGOkacCwMeQojWxygBUqihDAdPfRt=urllib.parse.quote(LSGOkacCwMeQojWxygBUqihDAdPfRt)
    LSGOkacCwMeQojWxygBUqihDAdPfRF='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(LSGOkacCwMeQojWxygBUqihDAdPfRt)
    LSGOkacCwMeQojWxygBUqihDAdPfRr=[('(통합) 찜 영상에 추가',LSGOkacCwMeQojWxygBUqihDAdPfRF)]
   else:
    LSGOkacCwMeQojWxygBUqihDAdPfRr=LSGOkacCwMeQojWxygBUqihDAdPfut
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel=LSGOkacCwMeQojWxygBUqihDAdPfRJ,img=LSGOkacCwMeQojWxygBUqihDAdPfpN,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfRE,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY,ContextMenu=LSGOkacCwMeQojWxygBUqihDAdPfRr)
  if LSGOkacCwMeQojWxygBUqihDAdPfpK:
   LSGOkacCwMeQojWxygBUqihDAdPfEY['mode'] ='4K_PROGRAM' 
   LSGOkacCwMeQojWxygBUqihDAdPfEY['page'] =LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEF='[B]%s >>[/B]'%'다음 페이지'
   LSGOkacCwMeQojWxygBUqihDAdPfRp=LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel=LSGOkacCwMeQojWxygBUqihDAdPfRp,img=LSGOkacCwMeQojWxygBUqihDAdPfEl,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfut,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
  xbmcplugin.setContent(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,cacheToDisc=LSGOkacCwMeQojWxygBUqihDAdPfuK)
 def dp_Episode_List(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfRT=LSGOkacCwMeQojWxygBUqihDAdPfpt.get('programcode')
  LSGOkacCwMeQojWxygBUqihDAdPfpF =LSGOkacCwMeQojWxygBUqihDAdPfuF(LSGOkacCwMeQojWxygBUqihDAdPfpt.get('page'))
  LSGOkacCwMeQojWxygBUqihDAdPfRN,LSGOkacCwMeQojWxygBUqihDAdPfpK,LSGOkacCwMeQojWxygBUqihDAdPfRz=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.GetEpisodeList(LSGOkacCwMeQojWxygBUqihDAdPfRT,LSGOkacCwMeQojWxygBUqihDAdPfpF,orderby=LSGOkacCwMeQojWxygBUqihDAdPfHF.get_winEpisodeOrderby())
  for LSGOkacCwMeQojWxygBUqihDAdPfRl in LSGOkacCwMeQojWxygBUqihDAdPfRN:
   LSGOkacCwMeQojWxygBUqihDAdPfEF =LSGOkacCwMeQojWxygBUqihDAdPfRl.get('title')
   LSGOkacCwMeQojWxygBUqihDAdPfRp =LSGOkacCwMeQojWxygBUqihDAdPfRl.get('subtitle')
   LSGOkacCwMeQojWxygBUqihDAdPfpN =LSGOkacCwMeQojWxygBUqihDAdPfRl.get('thumbnail')
   LSGOkacCwMeQojWxygBUqihDAdPfpz =LSGOkacCwMeQojWxygBUqihDAdPfRl.get('synopsis')
   LSGOkacCwMeQojWxygBUqihDAdPfRY=LSGOkacCwMeQojWxygBUqihDAdPfRl.get('info_title')
   LSGOkacCwMeQojWxygBUqihDAdPfRs =LSGOkacCwMeQojWxygBUqihDAdPfRl.get('aired')
   LSGOkacCwMeQojWxygBUqihDAdPfRX =LSGOkacCwMeQojWxygBUqihDAdPfRl.get('studio')
   LSGOkacCwMeQojWxygBUqihDAdPfRv =LSGOkacCwMeQojWxygBUqihDAdPfRl.get('frequency')
   LSGOkacCwMeQojWxygBUqihDAdPfRE={'mediatype':'episode','title':LSGOkacCwMeQojWxygBUqihDAdPfRY,'aired':LSGOkacCwMeQojWxygBUqihDAdPfRs,'studio':LSGOkacCwMeQojWxygBUqihDAdPfRX,'episode':LSGOkacCwMeQojWxygBUqihDAdPfRv,'plot':LSGOkacCwMeQojWxygBUqihDAdPfpz}
   LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'VOD','mediacode':LSGOkacCwMeQojWxygBUqihDAdPfRl.get('episode'),'stype':'vod','programcode':LSGOkacCwMeQojWxygBUqihDAdPfRT,'title':LSGOkacCwMeQojWxygBUqihDAdPfEF,'thumbnail':LSGOkacCwMeQojWxygBUqihDAdPfpN}
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel=LSGOkacCwMeQojWxygBUqihDAdPfRp,img=LSGOkacCwMeQojWxygBUqihDAdPfpN,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfRE,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfuK,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
  if LSGOkacCwMeQojWxygBUqihDAdPfpF==1:
   LSGOkacCwMeQojWxygBUqihDAdPfRE={'plot':'정렬순서를 변경합니다.'}
   LSGOkacCwMeQojWxygBUqihDAdPfEY={}
   LSGOkacCwMeQojWxygBUqihDAdPfEY['mode'] ='ORDER_BY' 
   if LSGOkacCwMeQojWxygBUqihDAdPfHF.get_winEpisodeOrderby()=='desc':
    LSGOkacCwMeQojWxygBUqihDAdPfEF='정렬순서변경 : 최신화부터 -> 1회부터'
    LSGOkacCwMeQojWxygBUqihDAdPfEY['orderby']='asc'
   else:
    LSGOkacCwMeQojWxygBUqihDAdPfEF='정렬순서변경 : 1회부터 -> 최신화부터'
    LSGOkacCwMeQojWxygBUqihDAdPfEY['orderby']='desc'
   LSGOkacCwMeQojWxygBUqihDAdPfEl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel='',img=LSGOkacCwMeQojWxygBUqihDAdPfEl,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfRE,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfuK,params=LSGOkacCwMeQojWxygBUqihDAdPfEY,isLink=LSGOkacCwMeQojWxygBUqihDAdPfur)
  if LSGOkacCwMeQojWxygBUqihDAdPfpK:
   LSGOkacCwMeQojWxygBUqihDAdPfEY['mode'] ='EPISODE' 
   LSGOkacCwMeQojWxygBUqihDAdPfEY['programcode']=LSGOkacCwMeQojWxygBUqihDAdPfRT
   LSGOkacCwMeQojWxygBUqihDAdPfEY['page'] =LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEF='[B]%s >>[/B]'%'다음 페이지'
   LSGOkacCwMeQojWxygBUqihDAdPfRp=LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel=LSGOkacCwMeQojWxygBUqihDAdPfRp,img=LSGOkacCwMeQojWxygBUqihDAdPfEl,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfut,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
  xbmcplugin.setContent(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,'episodes')
  if LSGOkacCwMeQojWxygBUqihDAdPfuz(LSGOkacCwMeQojWxygBUqihDAdPfRN)>0:xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,cacheToDisc=LSGOkacCwMeQojWxygBUqihDAdPfur)
 def dp_setEpOrderby(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfEV =LSGOkacCwMeQojWxygBUqihDAdPfpt.get('orderby')
  LSGOkacCwMeQojWxygBUqihDAdPfHF.set_winEpisodeOrderby(LSGOkacCwMeQojWxygBUqihDAdPfEV)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfRn =LSGOkacCwMeQojWxygBUqihDAdPfpt.get('stype')
  LSGOkacCwMeQojWxygBUqihDAdPfEV =LSGOkacCwMeQojWxygBUqihDAdPfpt.get('orderby')
  LSGOkacCwMeQojWxygBUqihDAdPfpF=LSGOkacCwMeQojWxygBUqihDAdPfuF(LSGOkacCwMeQojWxygBUqihDAdPfpt.get('page'))
  LSGOkacCwMeQojWxygBUqihDAdPfRb,LSGOkacCwMeQojWxygBUqihDAdPfpK=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.GetMovieList(LSGOkacCwMeQojWxygBUqihDAdPfRn,LSGOkacCwMeQojWxygBUqihDAdPfEV,LSGOkacCwMeQojWxygBUqihDAdPfpF)
  for LSGOkacCwMeQojWxygBUqihDAdPfnH in LSGOkacCwMeQojWxygBUqihDAdPfRb:
   LSGOkacCwMeQojWxygBUqihDAdPfEF =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('title')
   LSGOkacCwMeQojWxygBUqihDAdPfpN =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('thumbnail')
   LSGOkacCwMeQojWxygBUqihDAdPfpz =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('synopsis')
   LSGOkacCwMeQojWxygBUqihDAdPfRY =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('info_title')
   LSGOkacCwMeQojWxygBUqihDAdPfpv =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('year')
   LSGOkacCwMeQojWxygBUqihDAdPfpY =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('cast')
   LSGOkacCwMeQojWxygBUqihDAdPfps =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('director')
   LSGOkacCwMeQojWxygBUqihDAdPfpX =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('info_genre')
   LSGOkacCwMeQojWxygBUqihDAdPfnE =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('duration')
   LSGOkacCwMeQojWxygBUqihDAdPfRH =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('premiered')
   LSGOkacCwMeQojWxygBUqihDAdPfRX =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('studio')
   LSGOkacCwMeQojWxygBUqihDAdPfpb =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('mpaa')
   LSGOkacCwMeQojWxygBUqihDAdPfRE={'mediatype':'movie','title':LSGOkacCwMeQojWxygBUqihDAdPfRY,'year':LSGOkacCwMeQojWxygBUqihDAdPfpv,'cast':LSGOkacCwMeQojWxygBUqihDAdPfpY,'director':LSGOkacCwMeQojWxygBUqihDAdPfps,'genre':LSGOkacCwMeQojWxygBUqihDAdPfpX,'duration':LSGOkacCwMeQojWxygBUqihDAdPfnE,'premiered':LSGOkacCwMeQojWxygBUqihDAdPfRH,'studio':LSGOkacCwMeQojWxygBUqihDAdPfRX,'mpaa':LSGOkacCwMeQojWxygBUqihDAdPfpb,'plot':LSGOkacCwMeQojWxygBUqihDAdPfpz}
   LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'MOVIE','mediacode':LSGOkacCwMeQojWxygBUqihDAdPfnH.get('moviecode'),'stype':'movie','title':LSGOkacCwMeQojWxygBUqihDAdPfEF,'thumbnail':LSGOkacCwMeQojWxygBUqihDAdPfpN}
   if LSGOkacCwMeQojWxygBUqihDAdPfHF.get_settings_makebookmark():
    LSGOkacCwMeQojWxygBUqihDAdPfRV={'videoid':LSGOkacCwMeQojWxygBUqihDAdPfnH.get('moviecode'),'vidtype':'movie','vtitle':LSGOkacCwMeQojWxygBUqihDAdPfRY,'vsubtitle':'',}
    LSGOkacCwMeQojWxygBUqihDAdPfRt=json.dumps(LSGOkacCwMeQojWxygBUqihDAdPfRV)
    LSGOkacCwMeQojWxygBUqihDAdPfRt=urllib.parse.quote(LSGOkacCwMeQojWxygBUqihDAdPfRt)
    LSGOkacCwMeQojWxygBUqihDAdPfRF='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(LSGOkacCwMeQojWxygBUqihDAdPfRt)
    LSGOkacCwMeQojWxygBUqihDAdPfRr=[('(통합) 찜 영상에 추가',LSGOkacCwMeQojWxygBUqihDAdPfRF)]
   else:
    LSGOkacCwMeQojWxygBUqihDAdPfRr=LSGOkacCwMeQojWxygBUqihDAdPfut
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel='',img=LSGOkacCwMeQojWxygBUqihDAdPfpN,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfRE,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfuK,params=LSGOkacCwMeQojWxygBUqihDAdPfEY,ContextMenu=LSGOkacCwMeQojWxygBUqihDAdPfRr)
  if LSGOkacCwMeQojWxygBUqihDAdPfpK:
   LSGOkacCwMeQojWxygBUqihDAdPfEY={}
   LSGOkacCwMeQojWxygBUqihDAdPfEY['mode'] ='MOVIE_SUB' 
   LSGOkacCwMeQojWxygBUqihDAdPfEY['orderby']=LSGOkacCwMeQojWxygBUqihDAdPfEV
   LSGOkacCwMeQojWxygBUqihDAdPfEY['stype'] =LSGOkacCwMeQojWxygBUqihDAdPfRn
   LSGOkacCwMeQojWxygBUqihDAdPfEY['page'] =LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEF='[B]%s >>[/B]'%'다음 페이지'
   LSGOkacCwMeQojWxygBUqihDAdPfRp=LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel=LSGOkacCwMeQojWxygBUqihDAdPfRp,img=LSGOkacCwMeQojWxygBUqihDAdPfEl,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfut,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
  xbmcplugin.setContent(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,'movies')
  xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,cacheToDisc=LSGOkacCwMeQojWxygBUqihDAdPfuK)
 def dp_4K_Movie_List(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfpF=LSGOkacCwMeQojWxygBUqihDAdPfuF(LSGOkacCwMeQojWxygBUqihDAdPfpt.get('page'))
  LSGOkacCwMeQojWxygBUqihDAdPfRb,LSGOkacCwMeQojWxygBUqihDAdPfpK=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.Get_UHD_MovieList(LSGOkacCwMeQojWxygBUqihDAdPfpF)
  for LSGOkacCwMeQojWxygBUqihDAdPfnH in LSGOkacCwMeQojWxygBUqihDAdPfRb:
   LSGOkacCwMeQojWxygBUqihDAdPfEF =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('title')
   LSGOkacCwMeQojWxygBUqihDAdPfpN =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('thumbnail')
   LSGOkacCwMeQojWxygBUqihDAdPfpz =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('synopsis')
   LSGOkacCwMeQojWxygBUqihDAdPfRY =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('info_title')
   LSGOkacCwMeQojWxygBUqihDAdPfpv =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('year')
   LSGOkacCwMeQojWxygBUqihDAdPfpY =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('cast')
   LSGOkacCwMeQojWxygBUqihDAdPfps =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('director')
   LSGOkacCwMeQojWxygBUqihDAdPfpX =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('info_genre')
   LSGOkacCwMeQojWxygBUqihDAdPfnE =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('duration')
   LSGOkacCwMeQojWxygBUqihDAdPfRH =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('premiered')
   LSGOkacCwMeQojWxygBUqihDAdPfRX =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('studio')
   LSGOkacCwMeQojWxygBUqihDAdPfpb =LSGOkacCwMeQojWxygBUqihDAdPfnH.get('mpaa')
   LSGOkacCwMeQojWxygBUqihDAdPfRE={'mediatype':'movie','title':LSGOkacCwMeQojWxygBUqihDAdPfRY,'year':LSGOkacCwMeQojWxygBUqihDAdPfpv,'cast':LSGOkacCwMeQojWxygBUqihDAdPfpY,'director':LSGOkacCwMeQojWxygBUqihDAdPfps,'genre':LSGOkacCwMeQojWxygBUqihDAdPfpX,'duration':LSGOkacCwMeQojWxygBUqihDAdPfnE,'premiered':LSGOkacCwMeQojWxygBUqihDAdPfRH,'studio':LSGOkacCwMeQojWxygBUqihDAdPfRX,'mpaa':LSGOkacCwMeQojWxygBUqihDAdPfpb,'plot':LSGOkacCwMeQojWxygBUqihDAdPfpz}
   LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'MOVIE','mediacode':LSGOkacCwMeQojWxygBUqihDAdPfnH.get('moviecode'),'stype':'movie','title':LSGOkacCwMeQojWxygBUqihDAdPfEF,'thumbnail':LSGOkacCwMeQojWxygBUqihDAdPfpN}
   if LSGOkacCwMeQojWxygBUqihDAdPfHF.get_settings_makebookmark():
    LSGOkacCwMeQojWxygBUqihDAdPfRV={'videoid':LSGOkacCwMeQojWxygBUqihDAdPfnH.get('moviecode'),'vidtype':'movie','vtitle':LSGOkacCwMeQojWxygBUqihDAdPfRY,'vsubtitle':'',}
    LSGOkacCwMeQojWxygBUqihDAdPfRt=json.dumps(LSGOkacCwMeQojWxygBUqihDAdPfRV)
    LSGOkacCwMeQojWxygBUqihDAdPfRt=urllib.parse.quote(LSGOkacCwMeQojWxygBUqihDAdPfRt)
    LSGOkacCwMeQojWxygBUqihDAdPfRF='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(LSGOkacCwMeQojWxygBUqihDAdPfRt)
    LSGOkacCwMeQojWxygBUqihDAdPfRr=[('(통합) 찜 영상에 추가',LSGOkacCwMeQojWxygBUqihDAdPfRF)]
   else:
    LSGOkacCwMeQojWxygBUqihDAdPfRr=LSGOkacCwMeQojWxygBUqihDAdPfut
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel='',img=LSGOkacCwMeQojWxygBUqihDAdPfpN,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfRE,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfuK,params=LSGOkacCwMeQojWxygBUqihDAdPfEY,ContextMenu=LSGOkacCwMeQojWxygBUqihDAdPfRr)
  if LSGOkacCwMeQojWxygBUqihDAdPfpK:
   LSGOkacCwMeQojWxygBUqihDAdPfEY={}
   LSGOkacCwMeQojWxygBUqihDAdPfEY['mode'] ='4K_MOVIE' 
   LSGOkacCwMeQojWxygBUqihDAdPfEY['page'] =LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEF='[B]%s >>[/B]'%'다음 페이지'
   LSGOkacCwMeQojWxygBUqihDAdPfRp=LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel=LSGOkacCwMeQojWxygBUqihDAdPfRp,img=LSGOkacCwMeQojWxygBUqihDAdPfEl,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfut,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
  xbmcplugin.setContent(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,'movies')
  xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,cacheToDisc=LSGOkacCwMeQojWxygBUqihDAdPfuK)
 def dp_Set_Bookmark(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfnp=urllib.parse.unquote(LSGOkacCwMeQojWxygBUqihDAdPfpt.get('bm_param'))
  LSGOkacCwMeQojWxygBUqihDAdPfnp=json.loads(LSGOkacCwMeQojWxygBUqihDAdPfnp)
  LSGOkacCwMeQojWxygBUqihDAdPfnR =LSGOkacCwMeQojWxygBUqihDAdPfnp.get('videoid')
  LSGOkacCwMeQojWxygBUqihDAdPfnI =LSGOkacCwMeQojWxygBUqihDAdPfnp.get('vidtype')
  LSGOkacCwMeQojWxygBUqihDAdPfnm =LSGOkacCwMeQojWxygBUqihDAdPfnp.get('vtitle')
  LSGOkacCwMeQojWxygBUqihDAdPfnu =LSGOkacCwMeQojWxygBUqihDAdPfnp.get('vsubtitle')
  LSGOkacCwMeQojWxygBUqihDAdPfHz=xbmcgui.Dialog()
  LSGOkacCwMeQojWxygBUqihDAdPfpn=LSGOkacCwMeQojWxygBUqihDAdPfHz.yesno(__language__(30913).encode('utf8'),LSGOkacCwMeQojWxygBUqihDAdPfnm+' \n\n'+__language__(30914))
  if LSGOkacCwMeQojWxygBUqihDAdPfpn==LSGOkacCwMeQojWxygBUqihDAdPfuK:return
  LSGOkacCwMeQojWxygBUqihDAdPfnJ=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.GetBookmarkInfo(LSGOkacCwMeQojWxygBUqihDAdPfnR,LSGOkacCwMeQojWxygBUqihDAdPfnI)
  if LSGOkacCwMeQojWxygBUqihDAdPfnu!='':
   LSGOkacCwMeQojWxygBUqihDAdPfnJ['saveinfo']['subtitle']=LSGOkacCwMeQojWxygBUqihDAdPfnu 
   if LSGOkacCwMeQojWxygBUqihDAdPfnI=='tvshow':LSGOkacCwMeQojWxygBUqihDAdPfnJ['saveinfo']['infoLabels']['studio']=LSGOkacCwMeQojWxygBUqihDAdPfnu 
  LSGOkacCwMeQojWxygBUqihDAdPfnV=json.dumps(LSGOkacCwMeQojWxygBUqihDAdPfnJ)
  LSGOkacCwMeQojWxygBUqihDAdPfnV=urllib.parse.quote(LSGOkacCwMeQojWxygBUqihDAdPfnV)
  LSGOkacCwMeQojWxygBUqihDAdPfRF ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(LSGOkacCwMeQojWxygBUqihDAdPfnV)
  xbmc.executebuiltin(LSGOkacCwMeQojWxygBUqihDAdPfRF)
 def dp_Search_Group(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  if 'search_key' in LSGOkacCwMeQojWxygBUqihDAdPfpt:
   LSGOkacCwMeQojWxygBUqihDAdPfnt=LSGOkacCwMeQojWxygBUqihDAdPfpt.get('search_key')
  else:
   LSGOkacCwMeQojWxygBUqihDAdPfnt=LSGOkacCwMeQojWxygBUqihDAdPfHF.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not LSGOkacCwMeQojWxygBUqihDAdPfnt:
    return
  for LSGOkacCwMeQojWxygBUqihDAdPfpV in LSGOkacCwMeQojWxygBUqihDAdPfHI:
   LSGOkacCwMeQojWxygBUqihDAdPfnF =LSGOkacCwMeQojWxygBUqihDAdPfpV.get('mode')
   LSGOkacCwMeQojWxygBUqihDAdPfpu=LSGOkacCwMeQojWxygBUqihDAdPfpV.get('stype')
   LSGOkacCwMeQojWxygBUqihDAdPfEF=LSGOkacCwMeQojWxygBUqihDAdPfpV.get('title')
   (LSGOkacCwMeQojWxygBUqihDAdPfnr,LSGOkacCwMeQojWxygBUqihDAdPfpK)=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.GetSearchList(LSGOkacCwMeQojWxygBUqihDAdPfnt,1,LSGOkacCwMeQojWxygBUqihDAdPfpu)
   LSGOkacCwMeQojWxygBUqihDAdPfnK={'plot':'검색어 : '+LSGOkacCwMeQojWxygBUqihDAdPfnt+'\n\n'+LSGOkacCwMeQojWxygBUqihDAdPfHF.Search_FreeList(LSGOkacCwMeQojWxygBUqihDAdPfnr)}
   LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':LSGOkacCwMeQojWxygBUqihDAdPfnF,'stype':LSGOkacCwMeQojWxygBUqihDAdPfpu,'search_key':LSGOkacCwMeQojWxygBUqihDAdPfnt,'page':'1',}
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel='',img='',infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfnK,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
  if LSGOkacCwMeQojWxygBUqihDAdPfuz(LSGOkacCwMeQojWxygBUqihDAdPfHI)>0:xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,cacheToDisc=LSGOkacCwMeQojWxygBUqihDAdPfur)
  LSGOkacCwMeQojWxygBUqihDAdPfHF.Save_Searched_List(LSGOkacCwMeQojWxygBUqihDAdPfnt)
 def Search_FreeList(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfnb):
  LSGOkacCwMeQojWxygBUqihDAdPfnT=''
  LSGOkacCwMeQojWxygBUqihDAdPfnN=7
  try:
   if LSGOkacCwMeQojWxygBUqihDAdPfuz(LSGOkacCwMeQojWxygBUqihDAdPfnb)==0:return '검색결과 없음'
   for i in LSGOkacCwMeQojWxygBUqihDAdPfuY(LSGOkacCwMeQojWxygBUqihDAdPfuz(LSGOkacCwMeQojWxygBUqihDAdPfnb)):
    if i>=LSGOkacCwMeQojWxygBUqihDAdPfnN:
     LSGOkacCwMeQojWxygBUqihDAdPfnT=LSGOkacCwMeQojWxygBUqihDAdPfnT+'...'
     break
    LSGOkacCwMeQojWxygBUqihDAdPfnT=LSGOkacCwMeQojWxygBUqihDAdPfnT+LSGOkacCwMeQojWxygBUqihDAdPfnb[i]['title']+'\n'
  except:
   return ''
  return LSGOkacCwMeQojWxygBUqihDAdPfnT
 def dp_Search_History(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfnz=LSGOkacCwMeQojWxygBUqihDAdPfHF.Load_List_File('search')
  for LSGOkacCwMeQojWxygBUqihDAdPfnl in LSGOkacCwMeQojWxygBUqihDAdPfnz:
   LSGOkacCwMeQojWxygBUqihDAdPfnY=LSGOkacCwMeQojWxygBUqihDAdPfuN(urllib.parse.parse_qsl(LSGOkacCwMeQojWxygBUqihDAdPfnl))
   LSGOkacCwMeQojWxygBUqihDAdPfns=LSGOkacCwMeQojWxygBUqihDAdPfnY.get('skey').strip()
   LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'SEARCH_GROUP','search_key':LSGOkacCwMeQojWxygBUqihDAdPfns,}
   LSGOkacCwMeQojWxygBUqihDAdPfnX={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':LSGOkacCwMeQojWxygBUqihDAdPfns,'vType':'-',}
   LSGOkacCwMeQojWxygBUqihDAdPfnv=urllib.parse.urlencode(LSGOkacCwMeQojWxygBUqihDAdPfnX)
   LSGOkacCwMeQojWxygBUqihDAdPfRr=[('선택된 검색어 ( %s ) 삭제'%(LSGOkacCwMeQojWxygBUqihDAdPfns),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(LSGOkacCwMeQojWxygBUqihDAdPfnv))]
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfns,sublabel='',img=LSGOkacCwMeQojWxygBUqihDAdPfut,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfut,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY,ContextMenu=LSGOkacCwMeQojWxygBUqihDAdPfRr)
  LSGOkacCwMeQojWxygBUqihDAdPfRE={'plot':'검색목록 전체를 삭제합니다.'}
  LSGOkacCwMeQojWxygBUqihDAdPfEF='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  LSGOkacCwMeQojWxygBUqihDAdPfEl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel='',img=LSGOkacCwMeQojWxygBUqihDAdPfEl,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfRE,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfuK,params=LSGOkacCwMeQojWxygBUqihDAdPfEY,isLink=LSGOkacCwMeQojWxygBUqihDAdPfur)
  xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,cacheToDisc=LSGOkacCwMeQojWxygBUqihDAdPfuK)
 def dp_Search_List(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfpF =LSGOkacCwMeQojWxygBUqihDAdPfuF(LSGOkacCwMeQojWxygBUqihDAdPfpt.get('page'))
  LSGOkacCwMeQojWxygBUqihDAdPfpu =LSGOkacCwMeQojWxygBUqihDAdPfpt.get('stype')
  if 'search_key' in LSGOkacCwMeQojWxygBUqihDAdPfpt:
   LSGOkacCwMeQojWxygBUqihDAdPfnt=LSGOkacCwMeQojWxygBUqihDAdPfpt.get('search_key')
  else:
   LSGOkacCwMeQojWxygBUqihDAdPfnt=LSGOkacCwMeQojWxygBUqihDAdPfHF.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not LSGOkacCwMeQojWxygBUqihDAdPfnt:
    xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle)
    return
  LSGOkacCwMeQojWxygBUqihDAdPfnr,LSGOkacCwMeQojWxygBUqihDAdPfpK=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.GetSearchList(LSGOkacCwMeQojWxygBUqihDAdPfnt,LSGOkacCwMeQojWxygBUqihDAdPfpF,LSGOkacCwMeQojWxygBUqihDAdPfpu)
  for LSGOkacCwMeQojWxygBUqihDAdPfnb in LSGOkacCwMeQojWxygBUqihDAdPfnr:
   LSGOkacCwMeQojWxygBUqihDAdPfEF =LSGOkacCwMeQojWxygBUqihDAdPfnb.get('title')
   LSGOkacCwMeQojWxygBUqihDAdPfpN =LSGOkacCwMeQojWxygBUqihDAdPfnb.get('thumbnail')
   LSGOkacCwMeQojWxygBUqihDAdPfpz =LSGOkacCwMeQojWxygBUqihDAdPfnb.get('synopsis')
   LSGOkacCwMeQojWxygBUqihDAdPfIH =LSGOkacCwMeQojWxygBUqihDAdPfnb.get('program')
   LSGOkacCwMeQojWxygBUqihDAdPfpY =LSGOkacCwMeQojWxygBUqihDAdPfnb.get('cast')
   LSGOkacCwMeQojWxygBUqihDAdPfps =LSGOkacCwMeQojWxygBUqihDAdPfnb.get('director')
   LSGOkacCwMeQojWxygBUqihDAdPfpX=LSGOkacCwMeQojWxygBUqihDAdPfnb.get('info_genre')
   LSGOkacCwMeQojWxygBUqihDAdPfnE =LSGOkacCwMeQojWxygBUqihDAdPfnb.get('duration')
   LSGOkacCwMeQojWxygBUqihDAdPfpb =LSGOkacCwMeQojWxygBUqihDAdPfnb.get('mpaa')
   LSGOkacCwMeQojWxygBUqihDAdPfpv =LSGOkacCwMeQojWxygBUqihDAdPfnb.get('year')
   LSGOkacCwMeQojWxygBUqihDAdPfRs =LSGOkacCwMeQojWxygBUqihDAdPfnb.get('aired')
   LSGOkacCwMeQojWxygBUqihDAdPfRE={'mediatype':'tvshow' if LSGOkacCwMeQojWxygBUqihDAdPfpu=='vod' else 'movie','title':LSGOkacCwMeQojWxygBUqihDAdPfEF,'cast':LSGOkacCwMeQojWxygBUqihDAdPfpY,'director':LSGOkacCwMeQojWxygBUqihDAdPfps,'genre':LSGOkacCwMeQojWxygBUqihDAdPfpX,'duration':LSGOkacCwMeQojWxygBUqihDAdPfnE,'mpaa':LSGOkacCwMeQojWxygBUqihDAdPfpb,'year':LSGOkacCwMeQojWxygBUqihDAdPfpv,'aired':LSGOkacCwMeQojWxygBUqihDAdPfRs,'plot':'%s\n\n%s'%(LSGOkacCwMeQojWxygBUqihDAdPfEF,LSGOkacCwMeQojWxygBUqihDAdPfpz)}
   if LSGOkacCwMeQojWxygBUqihDAdPfpu=='vod':
    LSGOkacCwMeQojWxygBUqihDAdPfnR=LSGOkacCwMeQojWxygBUqihDAdPfnb.get('program')
    LSGOkacCwMeQojWxygBUqihDAdPfnI='tvshow'
    LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'EPISODE','programcode':LSGOkacCwMeQojWxygBUqihDAdPfnR,'page':'1',}
    LSGOkacCwMeQojWxygBUqihDAdPfEs=LSGOkacCwMeQojWxygBUqihDAdPfur
   else:
    LSGOkacCwMeQojWxygBUqihDAdPfnR=LSGOkacCwMeQojWxygBUqihDAdPfnb.get('movie')
    LSGOkacCwMeQojWxygBUqihDAdPfnI='movie'
    LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'MOVIE','mediacode':LSGOkacCwMeQojWxygBUqihDAdPfnR,'stype':'movie','title':LSGOkacCwMeQojWxygBUqihDAdPfEF,'thumbnail':LSGOkacCwMeQojWxygBUqihDAdPfpN,}
    LSGOkacCwMeQojWxygBUqihDAdPfEs=LSGOkacCwMeQojWxygBUqihDAdPfuK
   if LSGOkacCwMeQojWxygBUqihDAdPfHF.get_settings_makebookmark():
    LSGOkacCwMeQojWxygBUqihDAdPfRV={'videoid':LSGOkacCwMeQojWxygBUqihDAdPfnR,'vidtype':LSGOkacCwMeQojWxygBUqihDAdPfnI,'vtitle':LSGOkacCwMeQojWxygBUqihDAdPfEF,'vsubtitle':'',}
    LSGOkacCwMeQojWxygBUqihDAdPfRt=json.dumps(LSGOkacCwMeQojWxygBUqihDAdPfRV)
    LSGOkacCwMeQojWxygBUqihDAdPfRt=urllib.parse.quote(LSGOkacCwMeQojWxygBUqihDAdPfRt)
    LSGOkacCwMeQojWxygBUqihDAdPfRF='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(LSGOkacCwMeQojWxygBUqihDAdPfRt)
    LSGOkacCwMeQojWxygBUqihDAdPfRr=[('(통합) 찜 영상에 추가',LSGOkacCwMeQojWxygBUqihDAdPfRF)]
   else:
    LSGOkacCwMeQojWxygBUqihDAdPfRr=LSGOkacCwMeQojWxygBUqihDAdPfut
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel='',img=LSGOkacCwMeQojWxygBUqihDAdPfpN,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfRE,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfEs,params=LSGOkacCwMeQojWxygBUqihDAdPfEY,isLink=LSGOkacCwMeQojWxygBUqihDAdPfuK,ContextMenu=LSGOkacCwMeQojWxygBUqihDAdPfRr)
  if LSGOkacCwMeQojWxygBUqihDAdPfpK:
   LSGOkacCwMeQojWxygBUqihDAdPfEY['mode'] ='SEARCH' 
   LSGOkacCwMeQojWxygBUqihDAdPfEY['search_key']=LSGOkacCwMeQojWxygBUqihDAdPfnt
   LSGOkacCwMeQojWxygBUqihDAdPfEY['page'] =LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEF='[B]%s >>[/B]'%'다음 페이지'
   LSGOkacCwMeQojWxygBUqihDAdPfRp=LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfpF+1)
   LSGOkacCwMeQojWxygBUqihDAdPfEl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel=LSGOkacCwMeQojWxygBUqihDAdPfRp,img=LSGOkacCwMeQojWxygBUqihDAdPfEl,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfut,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
  if LSGOkacCwMeQojWxygBUqihDAdPfpu=='movie':xbmcplugin.setContent(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,'movies')
  else:xbmcplugin.setContent(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,cacheToDisc=LSGOkacCwMeQojWxygBUqihDAdPfuK)
 def dp_History_Remove(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfIE=LSGOkacCwMeQojWxygBUqihDAdPfpt.get('delType')
  LSGOkacCwMeQojWxygBUqihDAdPfIp =LSGOkacCwMeQojWxygBUqihDAdPfpt.get('sKey')
  LSGOkacCwMeQojWxygBUqihDAdPfIR =LSGOkacCwMeQojWxygBUqihDAdPfpt.get('vType')
  LSGOkacCwMeQojWxygBUqihDAdPfHz=xbmcgui.Dialog()
  if LSGOkacCwMeQojWxygBUqihDAdPfIE=='SEARCH_ALL':
   LSGOkacCwMeQojWxygBUqihDAdPfpn=LSGOkacCwMeQojWxygBUqihDAdPfHz.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif LSGOkacCwMeQojWxygBUqihDAdPfIE=='SEARCH_ONE':
   LSGOkacCwMeQojWxygBUqihDAdPfpn=LSGOkacCwMeQojWxygBUqihDAdPfHz.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif LSGOkacCwMeQojWxygBUqihDAdPfIE=='WATCH_ALL':
   LSGOkacCwMeQojWxygBUqihDAdPfpn=LSGOkacCwMeQojWxygBUqihDAdPfHz.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif LSGOkacCwMeQojWxygBUqihDAdPfIE=='WATCH_ONE':
   LSGOkacCwMeQojWxygBUqihDAdPfpn=LSGOkacCwMeQojWxygBUqihDAdPfHz.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if LSGOkacCwMeQojWxygBUqihDAdPfpn==LSGOkacCwMeQojWxygBUqihDAdPfuK:sys.exit()
  if LSGOkacCwMeQojWxygBUqihDAdPfIE=='SEARCH_ALL':
   if os.path.isfile(LSGOkacCwMeQojWxygBUqihDAdPfHt):os.remove(LSGOkacCwMeQojWxygBUqihDAdPfHt)
  elif LSGOkacCwMeQojWxygBUqihDAdPfIE=='SEARCH_ONE':
   try:
    LSGOkacCwMeQojWxygBUqihDAdPfIn=LSGOkacCwMeQojWxygBUqihDAdPfHt
    LSGOkacCwMeQojWxygBUqihDAdPfIm=LSGOkacCwMeQojWxygBUqihDAdPfHF.Load_List_File('search') 
    fp=LSGOkacCwMeQojWxygBUqihDAdPfus(LSGOkacCwMeQojWxygBUqihDAdPfIn,'w',-1,'utf-8')
    for LSGOkacCwMeQojWxygBUqihDAdPfIu in LSGOkacCwMeQojWxygBUqihDAdPfIm:
     LSGOkacCwMeQojWxygBUqihDAdPfIJ=LSGOkacCwMeQojWxygBUqihDAdPfuN(urllib.parse.parse_qsl(LSGOkacCwMeQojWxygBUqihDAdPfIu))
     LSGOkacCwMeQojWxygBUqihDAdPfIV=LSGOkacCwMeQojWxygBUqihDAdPfIJ.get('skey').strip()
     if LSGOkacCwMeQojWxygBUqihDAdPfIp!=LSGOkacCwMeQojWxygBUqihDAdPfIV:
      fp.write(LSGOkacCwMeQojWxygBUqihDAdPfIu)
    fp.close()
   except:
    LSGOkacCwMeQojWxygBUqihDAdPfut
  elif LSGOkacCwMeQojWxygBUqihDAdPfIE=='WATCH_ALL':
   LSGOkacCwMeQojWxygBUqihDAdPfIn=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%LSGOkacCwMeQojWxygBUqihDAdPfIR))
   if os.path.isfile(LSGOkacCwMeQojWxygBUqihDAdPfIn):os.remove(LSGOkacCwMeQojWxygBUqihDAdPfIn)
  elif LSGOkacCwMeQojWxygBUqihDAdPfIE=='WATCH_ONE':
   LSGOkacCwMeQojWxygBUqihDAdPfIn=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%LSGOkacCwMeQojWxygBUqihDAdPfIR))
   try:
    LSGOkacCwMeQojWxygBUqihDAdPfIm=LSGOkacCwMeQojWxygBUqihDAdPfHF.Load_List_File(LSGOkacCwMeQojWxygBUqihDAdPfIR) 
    fp=LSGOkacCwMeQojWxygBUqihDAdPfus(LSGOkacCwMeQojWxygBUqihDAdPfIn,'w',-1,'utf-8')
    for LSGOkacCwMeQojWxygBUqihDAdPfIu in LSGOkacCwMeQojWxygBUqihDAdPfIm:
     LSGOkacCwMeQojWxygBUqihDAdPfIJ=LSGOkacCwMeQojWxygBUqihDAdPfuN(urllib.parse.parse_qsl(LSGOkacCwMeQojWxygBUqihDAdPfIu))
     LSGOkacCwMeQojWxygBUqihDAdPfIV=LSGOkacCwMeQojWxygBUqihDAdPfIJ.get('code').strip()
     if LSGOkacCwMeQojWxygBUqihDAdPfIp!=LSGOkacCwMeQojWxygBUqihDAdPfIV:
      fp.write(LSGOkacCwMeQojWxygBUqihDAdPfIu)
    fp.close()
   except:
    LSGOkacCwMeQojWxygBUqihDAdPfut
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpu): 
  try:
   if LSGOkacCwMeQojWxygBUqihDAdPfpu=='search':
    LSGOkacCwMeQojWxygBUqihDAdPfIn=LSGOkacCwMeQojWxygBUqihDAdPfHt
   elif LSGOkacCwMeQojWxygBUqihDAdPfpu in['vod','movie']:
    LSGOkacCwMeQojWxygBUqihDAdPfIn=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%LSGOkacCwMeQojWxygBUqihDAdPfpu))
   else:
    return[]
   fp=LSGOkacCwMeQojWxygBUqihDAdPfus(LSGOkacCwMeQojWxygBUqihDAdPfIn,'r',-1,'utf-8')
   LSGOkacCwMeQojWxygBUqihDAdPfIt=fp.readlines()
   fp.close()
  except:
   LSGOkacCwMeQojWxygBUqihDAdPfIt=[]
  return LSGOkacCwMeQojWxygBUqihDAdPfIt
 def Save_Watched_List(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpu,LSGOkacCwMeQojWxygBUqihDAdPfHT):
  try:
   LSGOkacCwMeQojWxygBUqihDAdPfIF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%LSGOkacCwMeQojWxygBUqihDAdPfpu))
   LSGOkacCwMeQojWxygBUqihDAdPfIm=LSGOkacCwMeQojWxygBUqihDAdPfHF.Load_List_File(LSGOkacCwMeQojWxygBUqihDAdPfpu) 
   fp=LSGOkacCwMeQojWxygBUqihDAdPfus(LSGOkacCwMeQojWxygBUqihDAdPfIF,'w',-1,'utf-8')
   LSGOkacCwMeQojWxygBUqihDAdPfIr=urllib.parse.urlencode(LSGOkacCwMeQojWxygBUqihDAdPfHT)
   LSGOkacCwMeQojWxygBUqihDAdPfIr=LSGOkacCwMeQojWxygBUqihDAdPfIr+'\n'
   fp.write(LSGOkacCwMeQojWxygBUqihDAdPfIr)
   LSGOkacCwMeQojWxygBUqihDAdPfIK=0
   for LSGOkacCwMeQojWxygBUqihDAdPfIu in LSGOkacCwMeQojWxygBUqihDAdPfIm:
    LSGOkacCwMeQojWxygBUqihDAdPfIJ=LSGOkacCwMeQojWxygBUqihDAdPfuN(urllib.parse.parse_qsl(LSGOkacCwMeQojWxygBUqihDAdPfIu))
    LSGOkacCwMeQojWxygBUqihDAdPfIT=LSGOkacCwMeQojWxygBUqihDAdPfHT.get('code').strip()
    LSGOkacCwMeQojWxygBUqihDAdPfIN=LSGOkacCwMeQojWxygBUqihDAdPfIJ.get('code').strip()
    if LSGOkacCwMeQojWxygBUqihDAdPfpu=='vod' and LSGOkacCwMeQojWxygBUqihDAdPfHF.get_settings_direct_replay()==LSGOkacCwMeQojWxygBUqihDAdPfur:
     LSGOkacCwMeQojWxygBUqihDAdPfIT=LSGOkacCwMeQojWxygBUqihDAdPfHT.get('videoid').strip()
     LSGOkacCwMeQojWxygBUqihDAdPfIN=LSGOkacCwMeQojWxygBUqihDAdPfIJ.get('videoid').strip()if LSGOkacCwMeQojWxygBUqihDAdPfIN!=LSGOkacCwMeQojWxygBUqihDAdPfut else '-'
    if LSGOkacCwMeQojWxygBUqihDAdPfIT!=LSGOkacCwMeQojWxygBUqihDAdPfIN:
     fp.write(LSGOkacCwMeQojWxygBUqihDAdPfIu)
     LSGOkacCwMeQojWxygBUqihDAdPfIK+=1
     if LSGOkacCwMeQojWxygBUqihDAdPfIK>=50:break
   fp.close()
  except:
   LSGOkacCwMeQojWxygBUqihDAdPfut
 def dp_Watch_List(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfpu =LSGOkacCwMeQojWxygBUqihDAdPfpt.get('stype')
  LSGOkacCwMeQojWxygBUqihDAdPfEu=LSGOkacCwMeQojWxygBUqihDAdPfHF.get_settings_direct_replay()
  if LSGOkacCwMeQojWxygBUqihDAdPfpu=='-':
   for LSGOkacCwMeQojWxygBUqihDAdPfpV in LSGOkacCwMeQojWxygBUqihDAdPfHn:
    LSGOkacCwMeQojWxygBUqihDAdPfEF=LSGOkacCwMeQojWxygBUqihDAdPfpV.get('title')
    LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':LSGOkacCwMeQojWxygBUqihDAdPfpV.get('mode'),'stype':LSGOkacCwMeQojWxygBUqihDAdPfpV.get('stype')}
    LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel='',img='',infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfut,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfur,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
   if LSGOkacCwMeQojWxygBUqihDAdPfuz(LSGOkacCwMeQojWxygBUqihDAdPfHn)>0:xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle)
  else:
   LSGOkacCwMeQojWxygBUqihDAdPfIz=LSGOkacCwMeQojWxygBUqihDAdPfHF.Load_List_File(LSGOkacCwMeQojWxygBUqihDAdPfpu)
   for LSGOkacCwMeQojWxygBUqihDAdPfIl in LSGOkacCwMeQojWxygBUqihDAdPfIz:
    LSGOkacCwMeQojWxygBUqihDAdPfnY=LSGOkacCwMeQojWxygBUqihDAdPfuN(urllib.parse.parse_qsl(LSGOkacCwMeQojWxygBUqihDAdPfIl))
    LSGOkacCwMeQojWxygBUqihDAdPfIY =LSGOkacCwMeQojWxygBUqihDAdPfnY.get('code').strip()
    LSGOkacCwMeQojWxygBUqihDAdPfEF =LSGOkacCwMeQojWxygBUqihDAdPfnY.get('title').strip()
    LSGOkacCwMeQojWxygBUqihDAdPfpN=LSGOkacCwMeQojWxygBUqihDAdPfnY.get('img').strip()
    LSGOkacCwMeQojWxygBUqihDAdPfnR =LSGOkacCwMeQojWxygBUqihDAdPfnY.get('videoid').strip()
    try:
     LSGOkacCwMeQojWxygBUqihDAdPfpN=LSGOkacCwMeQojWxygBUqihDAdPfpN.replace('\'','\"')
     LSGOkacCwMeQojWxygBUqihDAdPfpN=json.loads(LSGOkacCwMeQojWxygBUqihDAdPfpN)
    except:
     LSGOkacCwMeQojWxygBUqihDAdPfut
    LSGOkacCwMeQojWxygBUqihDAdPfRE={}
    LSGOkacCwMeQojWxygBUqihDAdPfRE['plot']=LSGOkacCwMeQojWxygBUqihDAdPfEF
    if LSGOkacCwMeQojWxygBUqihDAdPfpu=='vod':
     if LSGOkacCwMeQojWxygBUqihDAdPfEu==LSGOkacCwMeQojWxygBUqihDAdPfuK or LSGOkacCwMeQojWxygBUqihDAdPfnR==LSGOkacCwMeQojWxygBUqihDAdPfut:
      LSGOkacCwMeQojWxygBUqihDAdPfRE['mediatype']='tvshow'
      LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'EPISODE','programcode':LSGOkacCwMeQojWxygBUqihDAdPfIY,'page':'1'}
      LSGOkacCwMeQojWxygBUqihDAdPfEs=LSGOkacCwMeQojWxygBUqihDAdPfur
     else:
      LSGOkacCwMeQojWxygBUqihDAdPfRE['mediatype']='episode'
      LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'VOD','mediacode':LSGOkacCwMeQojWxygBUqihDAdPfnR,'stype':'vod','programcode':LSGOkacCwMeQojWxygBUqihDAdPfIY,'title':LSGOkacCwMeQojWxygBUqihDAdPfEF,'thumbnail':LSGOkacCwMeQojWxygBUqihDAdPfpN}
      LSGOkacCwMeQojWxygBUqihDAdPfEs=LSGOkacCwMeQojWxygBUqihDAdPfuK
    else:
     LSGOkacCwMeQojWxygBUqihDAdPfRE['mediatype']='movie'
     LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'MOVIE','mediacode':LSGOkacCwMeQojWxygBUqihDAdPfIY,'stype':'movie','title':LSGOkacCwMeQojWxygBUqihDAdPfEF,'thumbnail':LSGOkacCwMeQojWxygBUqihDAdPfpN}
     LSGOkacCwMeQojWxygBUqihDAdPfEs=LSGOkacCwMeQojWxygBUqihDAdPfuK
    LSGOkacCwMeQojWxygBUqihDAdPfnX={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':LSGOkacCwMeQojWxygBUqihDAdPfIY,'vType':LSGOkacCwMeQojWxygBUqihDAdPfpu,}
    LSGOkacCwMeQojWxygBUqihDAdPfnv=urllib.parse.urlencode(LSGOkacCwMeQojWxygBUqihDAdPfnX)
    LSGOkacCwMeQojWxygBUqihDAdPfRr=[('선택된 시청이력 ( %s ) 삭제'%(LSGOkacCwMeQojWxygBUqihDAdPfEF),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(LSGOkacCwMeQojWxygBUqihDAdPfnv))]
    LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel='',img=LSGOkacCwMeQojWxygBUqihDAdPfpN,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfRE,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfEs,params=LSGOkacCwMeQojWxygBUqihDAdPfEY,ContextMenu=LSGOkacCwMeQojWxygBUqihDAdPfRr)
   LSGOkacCwMeQojWxygBUqihDAdPfRE={'plot':'시청목록을 삭제합니다.'}
   LSGOkacCwMeQojWxygBUqihDAdPfEF='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':LSGOkacCwMeQojWxygBUqihDAdPfpu,}
   LSGOkacCwMeQojWxygBUqihDAdPfEl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel='',img=LSGOkacCwMeQojWxygBUqihDAdPfEl,infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfRE,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfuK,params=LSGOkacCwMeQojWxygBUqihDAdPfEY,isLink=LSGOkacCwMeQojWxygBUqihDAdPfur)
   if LSGOkacCwMeQojWxygBUqihDAdPfpu=='movie':xbmcplugin.setContent(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,'movies')
   else:xbmcplugin.setContent(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,cacheToDisc=LSGOkacCwMeQojWxygBUqihDAdPfuK)
 def Save_Searched_List(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfnt):
  try:
   LSGOkacCwMeQojWxygBUqihDAdPfIs=LSGOkacCwMeQojWxygBUqihDAdPfHt
   LSGOkacCwMeQojWxygBUqihDAdPfIm=LSGOkacCwMeQojWxygBUqihDAdPfHF.Load_List_File('search') 
   LSGOkacCwMeQojWxygBUqihDAdPfIX={'skey':LSGOkacCwMeQojWxygBUqihDAdPfnt.strip()}
   fp=LSGOkacCwMeQojWxygBUqihDAdPfus(LSGOkacCwMeQojWxygBUqihDAdPfIs,'w',-1,'utf-8')
   LSGOkacCwMeQojWxygBUqihDAdPfIr=urllib.parse.urlencode(LSGOkacCwMeQojWxygBUqihDAdPfIX)
   LSGOkacCwMeQojWxygBUqihDAdPfIr=LSGOkacCwMeQojWxygBUqihDAdPfIr+'\n'
   fp.write(LSGOkacCwMeQojWxygBUqihDAdPfIr)
   LSGOkacCwMeQojWxygBUqihDAdPfIK=0
   for LSGOkacCwMeQojWxygBUqihDAdPfIu in LSGOkacCwMeQojWxygBUqihDAdPfIm:
    LSGOkacCwMeQojWxygBUqihDAdPfIJ=LSGOkacCwMeQojWxygBUqihDAdPfuN(urllib.parse.parse_qsl(LSGOkacCwMeQojWxygBUqihDAdPfIu))
    LSGOkacCwMeQojWxygBUqihDAdPfIT=LSGOkacCwMeQojWxygBUqihDAdPfIX.get('skey').strip()
    LSGOkacCwMeQojWxygBUqihDAdPfIN=LSGOkacCwMeQojWxygBUqihDAdPfIJ.get('skey').strip()
    if LSGOkacCwMeQojWxygBUqihDAdPfIT!=LSGOkacCwMeQojWxygBUqihDAdPfIN:
     fp.write(LSGOkacCwMeQojWxygBUqihDAdPfIu)
     LSGOkacCwMeQojWxygBUqihDAdPfIK+=1
     if LSGOkacCwMeQojWxygBUqihDAdPfIK>=50:break
   fp.close()
  except:
   LSGOkacCwMeQojWxygBUqihDAdPfut
 def play_VIDEO(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfIv =LSGOkacCwMeQojWxygBUqihDAdPfpt.get('mediacode')
  LSGOkacCwMeQojWxygBUqihDAdPfpu =LSGOkacCwMeQojWxygBUqihDAdPfpt.get('stype')
  LSGOkacCwMeQojWxygBUqihDAdPfIb =LSGOkacCwMeQojWxygBUqihDAdPfpt.get('pvrmode')
  LSGOkacCwMeQojWxygBUqihDAdPfmH=LSGOkacCwMeQojWxygBUqihDAdPfHF.get_selQuality(LSGOkacCwMeQojWxygBUqihDAdPfpu)
  LSGOkacCwMeQojWxygBUqihDAdPfHF.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(LSGOkacCwMeQojWxygBUqihDAdPfIv,LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfmH),LSGOkacCwMeQojWxygBUqihDAdPfpu,LSGOkacCwMeQojWxygBUqihDAdPfIb))
  LSGOkacCwMeQojWxygBUqihDAdPfmE=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.GetBroadURL(LSGOkacCwMeQojWxygBUqihDAdPfIv,LSGOkacCwMeQojWxygBUqihDAdPfmH,LSGOkacCwMeQojWxygBUqihDAdPfpu,LSGOkacCwMeQojWxygBUqihDAdPfIb,optUHD=LSGOkacCwMeQojWxygBUqihDAdPfHF.get_settings_uhd())
  LSGOkacCwMeQojWxygBUqihDAdPfHF.addon_log('qt, stype, url : %s - %s - %s'%(LSGOkacCwMeQojWxygBUqihDAdPful(LSGOkacCwMeQojWxygBUqihDAdPfmH),LSGOkacCwMeQojWxygBUqihDAdPfpu,LSGOkacCwMeQojWxygBUqihDAdPfmE['streaming_url']))
  if LSGOkacCwMeQojWxygBUqihDAdPfmE['streaming_url']=='':
   if LSGOkacCwMeQojWxygBUqihDAdPfmE['error_msg']=='':
    LSGOkacCwMeQojWxygBUqihDAdPfHF.addon_noti(__language__(30908).encode('utf8'))
   else:
    LSGOkacCwMeQojWxygBUqihDAdPfHF.addon_noti(LSGOkacCwMeQojWxygBUqihDAdPfmE['error_msg'].encode('utf8'))
   return
  LSGOkacCwMeQojWxygBUqihDAdPfmp='user-agent={}'.format(LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.USER_AGENT)
  if LSGOkacCwMeQojWxygBUqihDAdPfmE['watermark'] !='':
   LSGOkacCwMeQojWxygBUqihDAdPfmp='{}&x-tving-param1={}&x-tving-param2={}'.format(LSGOkacCwMeQojWxygBUqihDAdPfmp,LSGOkacCwMeQojWxygBUqihDAdPfmE['watermarkKey'],LSGOkacCwMeQojWxygBUqihDAdPfmE['watermark'])
  LSGOkacCwMeQojWxygBUqihDAdPfmR =LSGOkacCwMeQojWxygBUqihDAdPfuK
  LSGOkacCwMeQojWxygBUqihDAdPfmn =LSGOkacCwMeQojWxygBUqihDAdPfmE['streaming_url'].find('Policy=')
  if LSGOkacCwMeQojWxygBUqihDAdPfmn!=-1:
   LSGOkacCwMeQojWxygBUqihDAdPfmI =LSGOkacCwMeQojWxygBUqihDAdPfmE['streaming_url'].split('?')[0]
   LSGOkacCwMeQojWxygBUqihDAdPfmu=LSGOkacCwMeQojWxygBUqihDAdPfuN(urllib.parse.parse_qsl(urllib.parse.urlsplit(LSGOkacCwMeQojWxygBUqihDAdPfmE['streaming_url']).query))
   LSGOkacCwMeQojWxygBUqihDAdPfmJ='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(LSGOkacCwMeQojWxygBUqihDAdPfmu['Policy'],LSGOkacCwMeQojWxygBUqihDAdPfmu['Signature'],LSGOkacCwMeQojWxygBUqihDAdPfmu['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in LSGOkacCwMeQojWxygBUqihDAdPfmI:
    LSGOkacCwMeQojWxygBUqihDAdPfmR=LSGOkacCwMeQojWxygBUqihDAdPfur
    LSGOkacCwMeQojWxygBUqihDAdPfmV =LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    LSGOkacCwMeQojWxygBUqihDAdPfmt=LSGOkacCwMeQojWxygBUqihDAdPfmV.strftime('%Y-%m-%d-%H:%M:%S')
    if LSGOkacCwMeQojWxygBUqihDAdPfuF(LSGOkacCwMeQojWxygBUqihDAdPfmt.replace('-','').replace(':',''))<LSGOkacCwMeQojWxygBUqihDAdPfuF(LSGOkacCwMeQojWxygBUqihDAdPfmu['end'].replace('-','').replace(':','')):
     LSGOkacCwMeQojWxygBUqihDAdPfmu['end']=LSGOkacCwMeQojWxygBUqihDAdPfmt
     LSGOkacCwMeQojWxygBUqihDAdPfHF.addon_noti(__language__(30915).encode('utf8'))
    LSGOkacCwMeQojWxygBUqihDAdPfmI ='%s?%s'%(LSGOkacCwMeQojWxygBUqihDAdPfmI,urllib.parse.urlencode(LSGOkacCwMeQojWxygBUqihDAdPfmu,doseq=LSGOkacCwMeQojWxygBUqihDAdPfur))
   LSGOkacCwMeQojWxygBUqihDAdPfmF='{}|{}&Cookie={}'.format(LSGOkacCwMeQojWxygBUqihDAdPfmI,LSGOkacCwMeQojWxygBUqihDAdPfmp,LSGOkacCwMeQojWxygBUqihDAdPfmJ)
  else:
   LSGOkacCwMeQojWxygBUqihDAdPfmF=LSGOkacCwMeQojWxygBUqihDAdPfmE['streaming_url']+'|'+LSGOkacCwMeQojWxygBUqihDAdPfmp
   LSGOkacCwMeQojWxygBUqihDAdPfHF.addon_log('if tmp_pos == -1')
  LSGOkacCwMeQojWxygBUqihDAdPfHF.addon_log(LSGOkacCwMeQojWxygBUqihDAdPfmF)
  LSGOkacCwMeQojWxygBUqihDAdPfmr=xbmcgui.ListItem(path=LSGOkacCwMeQojWxygBUqihDAdPfmF)
  if LSGOkacCwMeQojWxygBUqihDAdPfmE['drm_license']!='':
   LSGOkacCwMeQojWxygBUqihDAdPfmK=LSGOkacCwMeQojWxygBUqihDAdPfmE['drm_license']
   LSGOkacCwMeQojWxygBUqihDAdPfmT ='https://cj.drmkeyserver.com/widevine_license'
   LSGOkacCwMeQojWxygBUqihDAdPfmN ='mpd'
   LSGOkacCwMeQojWxygBUqihDAdPfmz ='com.widevine.alpha'
   LSGOkacCwMeQojWxygBUqihDAdPfml =inputstreamhelper.Helper(LSGOkacCwMeQojWxygBUqihDAdPfmN,drm='widevine')
   if LSGOkacCwMeQojWxygBUqihDAdPfml.check_inputstream():
    LSGOkacCwMeQojWxygBUqihDAdPfmY={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.USER_AGENT,'AcquireLicenseAssertion':LSGOkacCwMeQojWxygBUqihDAdPfmK,'Host':'cj.drmkeyserver.com',}
    LSGOkacCwMeQojWxygBUqihDAdPfms=LSGOkacCwMeQojWxygBUqihDAdPfmT+'|'+urllib.parse.urlencode(LSGOkacCwMeQojWxygBUqihDAdPfmY)+'|R{SSM}|'
    LSGOkacCwMeQojWxygBUqihDAdPfmr.setProperty('inputstream',LSGOkacCwMeQojWxygBUqihDAdPfml.inputstream_addon)
    LSGOkacCwMeQojWxygBUqihDAdPfmr.setProperty('inputstream.adaptive.manifest_type',LSGOkacCwMeQojWxygBUqihDAdPfmN)
    LSGOkacCwMeQojWxygBUqihDAdPfmr.setProperty('inputstream.adaptive.license_type',LSGOkacCwMeQojWxygBUqihDAdPfmz)
    LSGOkacCwMeQojWxygBUqihDAdPfmr.setProperty('inputstream.adaptive.license_key',LSGOkacCwMeQojWxygBUqihDAdPfms)
    LSGOkacCwMeQojWxygBUqihDAdPfmr.setProperty('inputstream.adaptive.stream_headers',LSGOkacCwMeQojWxygBUqihDAdPfmp)
  elif LSGOkacCwMeQojWxygBUqihDAdPfmR==LSGOkacCwMeQojWxygBUqihDAdPfur:
   LSGOkacCwMeQojWxygBUqihDAdPfmr.setContentLookup(LSGOkacCwMeQojWxygBUqihDAdPfuK)
   LSGOkacCwMeQojWxygBUqihDAdPfmr.setMimeType('application/x-mpegURL')
   LSGOkacCwMeQojWxygBUqihDAdPfmr.setProperty('inputstream','inputstream.ffmpegdirect')
   LSGOkacCwMeQojWxygBUqihDAdPfmr.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   LSGOkacCwMeQojWxygBUqihDAdPfmr.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   LSGOkacCwMeQojWxygBUqihDAdPfmr.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   LSGOkacCwMeQojWxygBUqihDAdPfmr.setProperty('ResumeTime','0')
   LSGOkacCwMeQojWxygBUqihDAdPfmr.setProperty('TotalTime','10000')
  elif LSGOkacCwMeQojWxygBUqihDAdPfpt.get('mode')in['VOD','MOVIE']:
   LSGOkacCwMeQojWxygBUqihDAdPfmr.setContentLookup(LSGOkacCwMeQojWxygBUqihDAdPfuK)
   LSGOkacCwMeQojWxygBUqihDAdPfmr.setMimeType('application/x-mpegURL')
   LSGOkacCwMeQojWxygBUqihDAdPfmr.setProperty('inputstream','inputstream.adaptive')
   LSGOkacCwMeQojWxygBUqihDAdPfmr.setProperty('inputstream.adaptive.manifest_type','hls')
  xbmcplugin.setResolvedUrl(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,LSGOkacCwMeQojWxygBUqihDAdPfur,LSGOkacCwMeQojWxygBUqihDAdPfmr)
  try:
   if LSGOkacCwMeQojWxygBUqihDAdPfpt.get('mode')in['VOD','MOVIE']and LSGOkacCwMeQojWxygBUqihDAdPfpt.get('title'):
    LSGOkacCwMeQojWxygBUqihDAdPfEY={'code':LSGOkacCwMeQojWxygBUqihDAdPfpt.get('programcode')if LSGOkacCwMeQojWxygBUqihDAdPfpt.get('mode')=='VOD' else LSGOkacCwMeQojWxygBUqihDAdPfpt.get('mediacode'),'img':LSGOkacCwMeQojWxygBUqihDAdPfpt.get('thumbnail'),'title':LSGOkacCwMeQojWxygBUqihDAdPfpt.get('title'),'videoid':LSGOkacCwMeQojWxygBUqihDAdPfpt.get('mediacode')}
    LSGOkacCwMeQojWxygBUqihDAdPfHF.Save_Watched_List(LSGOkacCwMeQojWxygBUqihDAdPfpt.get('stype'),LSGOkacCwMeQojWxygBUqihDAdPfEY)
  except:
   LSGOkacCwMeQojWxygBUqihDAdPfut
 def logout(LSGOkacCwMeQojWxygBUqihDAdPfHF):
  LSGOkacCwMeQojWxygBUqihDAdPfHz=xbmcgui.Dialog()
  LSGOkacCwMeQojWxygBUqihDAdPfpn=LSGOkacCwMeQojWxygBUqihDAdPfHz.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if LSGOkacCwMeQojWxygBUqihDAdPfpn==LSGOkacCwMeQojWxygBUqihDAdPfuK:sys.exit()
  LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.Init_TV_Total()
  if os.path.isfile(LSGOkacCwMeQojWxygBUqihDAdPfHV):os.remove(LSGOkacCwMeQojWxygBUqihDAdPfHV)
  LSGOkacCwMeQojWxygBUqihDAdPfHF.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(LSGOkacCwMeQojWxygBUqihDAdPfHF):
  LSGOkacCwMeQojWxygBUqihDAdPfmX =LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.Get_Now_Datetime()
  LSGOkacCwMeQojWxygBUqihDAdPfmv=LSGOkacCwMeQojWxygBUqihDAdPfmX+datetime.timedelta(days=LSGOkacCwMeQojWxygBUqihDAdPfuF(__addon__.getSetting('cache_ttl')))
  (LSGOkacCwMeQojWxygBUqihDAdPfEb,LSGOkacCwMeQojWxygBUqihDAdPfpH,LSGOkacCwMeQojWxygBUqihDAdPfpE,LSGOkacCwMeQojWxygBUqihDAdPfpR)=LSGOkacCwMeQojWxygBUqihDAdPfHF.get_settings_account()
  LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.Save_session_acount(LSGOkacCwMeQojWxygBUqihDAdPfEb,LSGOkacCwMeQojWxygBUqihDAdPfpH,LSGOkacCwMeQojWxygBUqihDAdPfpE,LSGOkacCwMeQojWxygBUqihDAdPfpR)
  LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.TV['account']['token_limit']=LSGOkacCwMeQojWxygBUqihDAdPfmv.strftime('%Y%m%d')
  LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.JsonFile_Save(LSGOkacCwMeQojWxygBUqihDAdPfHV,LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.TV)
 def cookiefile_check(LSGOkacCwMeQojWxygBUqihDAdPfHF):
  LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.TV=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.JsonFile_Load(LSGOkacCwMeQojWxygBUqihDAdPfHV)
  if 'account' not in LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.TV:
   LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.Init_TV_Total()
   return LSGOkacCwMeQojWxygBUqihDAdPfuK
  (LSGOkacCwMeQojWxygBUqihDAdPfmb,LSGOkacCwMeQojWxygBUqihDAdPfuH,LSGOkacCwMeQojWxygBUqihDAdPfuE,LSGOkacCwMeQojWxygBUqihDAdPfup)=LSGOkacCwMeQojWxygBUqihDAdPfHF.get_settings_account()
  (LSGOkacCwMeQojWxygBUqihDAdPfuR,LSGOkacCwMeQojWxygBUqihDAdPfun,LSGOkacCwMeQojWxygBUqihDAdPfuI,LSGOkacCwMeQojWxygBUqihDAdPfum)=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.Load_session_acount()
  if LSGOkacCwMeQojWxygBUqihDAdPfmb!=LSGOkacCwMeQojWxygBUqihDAdPfuR or LSGOkacCwMeQojWxygBUqihDAdPfuH!=LSGOkacCwMeQojWxygBUqihDAdPfun or LSGOkacCwMeQojWxygBUqihDAdPfuE!=LSGOkacCwMeQojWxygBUqihDAdPfuI or LSGOkacCwMeQojWxygBUqihDAdPfup!=LSGOkacCwMeQojWxygBUqihDAdPfum:
   LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.Init_TV_Total()
   return LSGOkacCwMeQojWxygBUqihDAdPfuK
  if LSGOkacCwMeQojWxygBUqihDAdPfuF(LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>LSGOkacCwMeQojWxygBUqihDAdPfuF(LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.TV['account']['token_limit']):
   LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.Init_TV_Total()
   return LSGOkacCwMeQojWxygBUqihDAdPfuK
  return LSGOkacCwMeQojWxygBUqihDAdPfur
 def dp_Global_Search(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfnF=LSGOkacCwMeQojWxygBUqihDAdPfpt.get('mode')
  if LSGOkacCwMeQojWxygBUqihDAdPfnF=='TOTAL_SEARCH':
   LSGOkacCwMeQojWxygBUqihDAdPfuJ='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   LSGOkacCwMeQojWxygBUqihDAdPfuJ='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(LSGOkacCwMeQojWxygBUqihDAdPfuJ)
 def dp_Bookmark_Menu(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfuJ='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(LSGOkacCwMeQojWxygBUqihDAdPfuJ)
 def dp_EuroLive_List(LSGOkacCwMeQojWxygBUqihDAdPfHF,LSGOkacCwMeQojWxygBUqihDAdPfpt):
  LSGOkacCwMeQojWxygBUqihDAdPfpr=LSGOkacCwMeQojWxygBUqihDAdPfHF.TvingObj.GetEuroChannelList()
  for LSGOkacCwMeQojWxygBUqihDAdPfpT in LSGOkacCwMeQojWxygBUqihDAdPfpr:
   LSGOkacCwMeQojWxygBUqihDAdPfRJ =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('channel')
   LSGOkacCwMeQojWxygBUqihDAdPfEF =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('title')
   LSGOkacCwMeQojWxygBUqihDAdPfRp =LSGOkacCwMeQojWxygBUqihDAdPfpT.get('subtitle')
   LSGOkacCwMeQojWxygBUqihDAdPfRE={'mediatype':'episode','title':LSGOkacCwMeQojWxygBUqihDAdPfEF,'plot':'%s\n%s'%(LSGOkacCwMeQojWxygBUqihDAdPfEF,LSGOkacCwMeQojWxygBUqihDAdPfRp)}
   LSGOkacCwMeQojWxygBUqihDAdPfEY={'mode':'LIVE','mediacode':LSGOkacCwMeQojWxygBUqihDAdPfRJ,'stype':'onair',}
   LSGOkacCwMeQojWxygBUqihDAdPfHF.add_dir(LSGOkacCwMeQojWxygBUqihDAdPfEF,sublabel=LSGOkacCwMeQojWxygBUqihDAdPfRp,img='',infoLabels=LSGOkacCwMeQojWxygBUqihDAdPfRE,isFolder=LSGOkacCwMeQojWxygBUqihDAdPfuK,params=LSGOkacCwMeQojWxygBUqihDAdPfEY)
  if LSGOkacCwMeQojWxygBUqihDAdPfuz(LSGOkacCwMeQojWxygBUqihDAdPfpr)>0:xbmcplugin.endOfDirectory(LSGOkacCwMeQojWxygBUqihDAdPfHF._addon_handle,cacheToDisc=LSGOkacCwMeQojWxygBUqihDAdPfuK)
 def tving_main(LSGOkacCwMeQojWxygBUqihDAdPfHF):
  LSGOkacCwMeQojWxygBUqihDAdPfnF=LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params.get('mode',LSGOkacCwMeQojWxygBUqihDAdPfut)
  if LSGOkacCwMeQojWxygBUqihDAdPfnF=='LOGOUT':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.logout()
   return
  LSGOkacCwMeQojWxygBUqihDAdPfHF.login_main()
  if LSGOkacCwMeQojWxygBUqihDAdPfnF is LSGOkacCwMeQojWxygBUqihDAdPfut:
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_Main_List()
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_Title_Group(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF in['GLOBAL_GROUP']:
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_SubTitle_Group(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF=='CHANNEL':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_LiveChannel_List(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF in['LIVE','VOD','MOVIE']:
   LSGOkacCwMeQojWxygBUqihDAdPfHF.play_VIDEO(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF=='PROGRAM':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_Program_List(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF=='4K_PROGRAM':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_4K_Program_List(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF=='EPISODE':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_Episode_List(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF=='MOVIE_SUB':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_Movie_List(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF=='4K_MOVIE':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_4K_Movie_List(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF=='SEARCH_GROUP':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_Search_Group(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF in['SEARCH','LOCAL_SEARCH']:
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_Search_List(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF=='WATCH':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_Watch_List(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_History_Remove(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF=='ORDER_BY':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_setEpOrderby(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF=='SET_BOOKMARK':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_Set_Bookmark(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF in['TOTAL_SEARCH','TOTAL_HISTORY']:
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_Global_Search(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF=='SEARCH_HISTORY':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_Search_History(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF=='MENU_BOOKMARK':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_Bookmark_Menu(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  elif LSGOkacCwMeQojWxygBUqihDAdPfnF=='EURO_GROUP':
   LSGOkacCwMeQojWxygBUqihDAdPfHF.dp_EuroLive_List(LSGOkacCwMeQojWxygBUqihDAdPfHF.main_params)
  else:
   LSGOkacCwMeQojWxygBUqihDAdPfut
# Created by pyminifier (https://github.com/liftoff/pyminifier)
