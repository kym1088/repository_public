__author__="NightRain"
HzDeCOWGrbpsdNXEaASiocftFRlMPj=object
HzDeCOWGrbpsdNXEaASiocftFRlMPV=None
HzDeCOWGrbpsdNXEaASiocftFRlMPw=int
HzDeCOWGrbpsdNXEaASiocftFRlMPh=True
HzDeCOWGrbpsdNXEaASiocftFRlMPT=False
HzDeCOWGrbpsdNXEaASiocftFRlMPQ=type
HzDeCOWGrbpsdNXEaASiocftFRlMPY=dict
HzDeCOWGrbpsdNXEaASiocftFRlMPB=len
HzDeCOWGrbpsdNXEaASiocftFRlMPL=str
HzDeCOWGrbpsdNXEaASiocftFRlMPm=range
HzDeCOWGrbpsdNXEaASiocftFRlMkq=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
HzDeCOWGrbpsdNXEaASiocftFRlMqJ=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
HzDeCOWGrbpsdNXEaASiocftFRlMqI=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
HzDeCOWGrbpsdNXEaASiocftFRlMqy=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
HzDeCOWGrbpsdNXEaASiocftFRlMqv=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
HzDeCOWGrbpsdNXEaASiocftFRlMqU=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
HzDeCOWGrbpsdNXEaASiocftFRlMqP=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
HzDeCOWGrbpsdNXEaASiocftFRlMqk=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
HzDeCOWGrbpsdNXEaASiocftFRlMqn =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
HzDeCOWGrbpsdNXEaASiocftFRlMqx=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class HzDeCOWGrbpsdNXEaASiocftFRlMqg(HzDeCOWGrbpsdNXEaASiocftFRlMPj):
 def __init__(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMqK,HzDeCOWGrbpsdNXEaASiocftFRlMqj,HzDeCOWGrbpsdNXEaASiocftFRlMqV):
  HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_url =HzDeCOWGrbpsdNXEaASiocftFRlMqK
  HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle=HzDeCOWGrbpsdNXEaASiocftFRlMqj
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params =HzDeCOWGrbpsdNXEaASiocftFRlMqV
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj =VyLJMTENbukgYcxKnlwFpSIDmjtCaU() 
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream.mpd'))
 def addon_noti(HzDeCOWGrbpsdNXEaASiocftFRlMqu,sting):
  try:
   HzDeCOWGrbpsdNXEaASiocftFRlMqh=xbmcgui.Dialog()
   HzDeCOWGrbpsdNXEaASiocftFRlMqh.notification(__addonname__,sting)
  except:
   HzDeCOWGrbpsdNXEaASiocftFRlMPV
 def addon_log(HzDeCOWGrbpsdNXEaASiocftFRlMqu,string):
  try:
   HzDeCOWGrbpsdNXEaASiocftFRlMqT=string.encode('utf-8','ignore')
  except:
   HzDeCOWGrbpsdNXEaASiocftFRlMqT='addonException: addon_log'
  HzDeCOWGrbpsdNXEaASiocftFRlMqQ=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,HzDeCOWGrbpsdNXEaASiocftFRlMqT),level=HzDeCOWGrbpsdNXEaASiocftFRlMqQ)
 def get_keyboard_input(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMgV):
  HzDeCOWGrbpsdNXEaASiocftFRlMqY=HzDeCOWGrbpsdNXEaASiocftFRlMPV
  kb=xbmc.Keyboard()
  kb.setHeading(HzDeCOWGrbpsdNXEaASiocftFRlMgV)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   HzDeCOWGrbpsdNXEaASiocftFRlMqY=kb.getText()
  return HzDeCOWGrbpsdNXEaASiocftFRlMqY
 def get_settings_account(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  HzDeCOWGrbpsdNXEaASiocftFRlMqB =__addon__.getSetting('id')
  HzDeCOWGrbpsdNXEaASiocftFRlMqL =__addon__.getSetting('pw')
  HzDeCOWGrbpsdNXEaASiocftFRlMqm =__addon__.getSetting('login_type')
  HzDeCOWGrbpsdNXEaASiocftFRlMgq=HzDeCOWGrbpsdNXEaASiocftFRlMPw(__addon__.getSetting('selected_profile'))
  return(HzDeCOWGrbpsdNXEaASiocftFRlMqB,HzDeCOWGrbpsdNXEaASiocftFRlMqL,HzDeCOWGrbpsdNXEaASiocftFRlMqm,HzDeCOWGrbpsdNXEaASiocftFRlMgq)
 def get_settings_uhd(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  return HzDeCOWGrbpsdNXEaASiocftFRlMPh if __addon__.getSetting('active_uhd')=='true' else HzDeCOWGrbpsdNXEaASiocftFRlMPT
 def get_settings_playback(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  HzDeCOWGrbpsdNXEaASiocftFRlMgJ={'active_uhd':HzDeCOWGrbpsdNXEaASiocftFRlMPh if __addon__.getSetting('active_uhd')=='true' else HzDeCOWGrbpsdNXEaASiocftFRlMPT,'streamFilename':HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.TV_STREAM_FILENAME,}
  return HzDeCOWGrbpsdNXEaASiocftFRlMgJ
 def get_settings_proxyport(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  HzDeCOWGrbpsdNXEaASiocftFRlMgI =HzDeCOWGrbpsdNXEaASiocftFRlMPh if __addon__.getSetting('proxyYn')=='true' else HzDeCOWGrbpsdNXEaASiocftFRlMPT
  HzDeCOWGrbpsdNXEaASiocftFRlMgy=HzDeCOWGrbpsdNXEaASiocftFRlMPw(__addon__.getSetting('proxyPort'))
  return HzDeCOWGrbpsdNXEaASiocftFRlMgI,HzDeCOWGrbpsdNXEaASiocftFRlMgy
 def get_settings_totalsearch(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  HzDeCOWGrbpsdNXEaASiocftFRlMgv =HzDeCOWGrbpsdNXEaASiocftFRlMPh if __addon__.getSetting('local_search')=='true' else HzDeCOWGrbpsdNXEaASiocftFRlMPT
  HzDeCOWGrbpsdNXEaASiocftFRlMgU=HzDeCOWGrbpsdNXEaASiocftFRlMPh if __addon__.getSetting('local_history')=='true' else HzDeCOWGrbpsdNXEaASiocftFRlMPT
  HzDeCOWGrbpsdNXEaASiocftFRlMgP =HzDeCOWGrbpsdNXEaASiocftFRlMPh if __addon__.getSetting('total_search')=='true' else HzDeCOWGrbpsdNXEaASiocftFRlMPT
  HzDeCOWGrbpsdNXEaASiocftFRlMgk=HzDeCOWGrbpsdNXEaASiocftFRlMPh if __addon__.getSetting('total_history')=='true' else HzDeCOWGrbpsdNXEaASiocftFRlMPT
  HzDeCOWGrbpsdNXEaASiocftFRlMgn=HzDeCOWGrbpsdNXEaASiocftFRlMPh if __addon__.getSetting('menu_bookmark')=='true' else HzDeCOWGrbpsdNXEaASiocftFRlMPT
  return(HzDeCOWGrbpsdNXEaASiocftFRlMgv,HzDeCOWGrbpsdNXEaASiocftFRlMgU,HzDeCOWGrbpsdNXEaASiocftFRlMgP,HzDeCOWGrbpsdNXEaASiocftFRlMgk,HzDeCOWGrbpsdNXEaASiocftFRlMgn)
 def get_settings_makebookmark(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  return HzDeCOWGrbpsdNXEaASiocftFRlMPh if __addon__.getSetting('make_bookmark')=='true' else HzDeCOWGrbpsdNXEaASiocftFRlMPT
 def get_settings_direct_replay(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  HzDeCOWGrbpsdNXEaASiocftFRlMgx=HzDeCOWGrbpsdNXEaASiocftFRlMPw(__addon__.getSetting('direct_replay'))
  if HzDeCOWGrbpsdNXEaASiocftFRlMgx==0:
   return HzDeCOWGrbpsdNXEaASiocftFRlMPT
  else:
   return HzDeCOWGrbpsdNXEaASiocftFRlMPh
 def set_winEpisodeOrderby(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMgK):
  __addon__.setSetting('tving_orderby',HzDeCOWGrbpsdNXEaASiocftFRlMgK)
  HzDeCOWGrbpsdNXEaASiocftFRlMgu=xbmcgui.Window(10000)
  HzDeCOWGrbpsdNXEaASiocftFRlMgu.setProperty('TVING_M_ORDERBY',HzDeCOWGrbpsdNXEaASiocftFRlMgK)
 def get_winEpisodeOrderby(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  HzDeCOWGrbpsdNXEaASiocftFRlMgK=__addon__.getSetting('tving_orderby')
  if HzDeCOWGrbpsdNXEaASiocftFRlMgK in['',HzDeCOWGrbpsdNXEaASiocftFRlMPV]:HzDeCOWGrbpsdNXEaASiocftFRlMgK='desc'
  return HzDeCOWGrbpsdNXEaASiocftFRlMgK
 def add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMqu,label,sublabel='',img='',infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params='',isLink=HzDeCOWGrbpsdNXEaASiocftFRlMPT,ContextMenu=HzDeCOWGrbpsdNXEaASiocftFRlMPV):
  HzDeCOWGrbpsdNXEaASiocftFRlMgj='%s?%s'%(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_url,urllib.parse.urlencode(params))
  if sublabel:HzDeCOWGrbpsdNXEaASiocftFRlMgV='%s < %s >'%(label,sublabel)
  else: HzDeCOWGrbpsdNXEaASiocftFRlMgV=label
  if not img:img='DefaultFolder.png'
  HzDeCOWGrbpsdNXEaASiocftFRlMgw=xbmcgui.ListItem(HzDeCOWGrbpsdNXEaASiocftFRlMgV)
  if HzDeCOWGrbpsdNXEaASiocftFRlMPQ(img)==HzDeCOWGrbpsdNXEaASiocftFRlMPY:
   HzDeCOWGrbpsdNXEaASiocftFRlMgw.setArt(img)
  else:
   HzDeCOWGrbpsdNXEaASiocftFRlMgw.setArt({'thumb':img,'poster':img})
  if infoLabels:HzDeCOWGrbpsdNXEaASiocftFRlMgw.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   HzDeCOWGrbpsdNXEaASiocftFRlMgw.setProperty('IsPlayable','true')
  if ContextMenu:HzDeCOWGrbpsdNXEaASiocftFRlMgw.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,HzDeCOWGrbpsdNXEaASiocftFRlMgj,HzDeCOWGrbpsdNXEaASiocftFRlMgw,isFolder)
 def get_selQuality(HzDeCOWGrbpsdNXEaASiocftFRlMqu,etype):
  try:
   HzDeCOWGrbpsdNXEaASiocftFRlMgh='selected_quality'
   HzDeCOWGrbpsdNXEaASiocftFRlMgT=[1080,720,480,360]
   HzDeCOWGrbpsdNXEaASiocftFRlMgQ=HzDeCOWGrbpsdNXEaASiocftFRlMPw(__addon__.getSetting(HzDeCOWGrbpsdNXEaASiocftFRlMgh))
   return HzDeCOWGrbpsdNXEaASiocftFRlMgT[HzDeCOWGrbpsdNXEaASiocftFRlMgQ]
  except:
   HzDeCOWGrbpsdNXEaASiocftFRlMPV
  return 720 
 def dp_Main_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  (HzDeCOWGrbpsdNXEaASiocftFRlMgv,HzDeCOWGrbpsdNXEaASiocftFRlMgU,HzDeCOWGrbpsdNXEaASiocftFRlMgP,HzDeCOWGrbpsdNXEaASiocftFRlMgk,HzDeCOWGrbpsdNXEaASiocftFRlMgn)=HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_totalsearch()
  for HzDeCOWGrbpsdNXEaASiocftFRlMgY in HzDeCOWGrbpsdNXEaASiocftFRlMqJ:
   HzDeCOWGrbpsdNXEaASiocftFRlMgV=HzDeCOWGrbpsdNXEaASiocftFRlMgY.get('title')
   HzDeCOWGrbpsdNXEaASiocftFRlMgB=''
   if HzDeCOWGrbpsdNXEaASiocftFRlMgY.get('mode')=='SEARCH_GROUP' and HzDeCOWGrbpsdNXEaASiocftFRlMgv ==HzDeCOWGrbpsdNXEaASiocftFRlMPT:continue
   elif HzDeCOWGrbpsdNXEaASiocftFRlMgY.get('mode')=='SEARCH_HISTORY' and HzDeCOWGrbpsdNXEaASiocftFRlMgU==HzDeCOWGrbpsdNXEaASiocftFRlMPT:continue
   elif HzDeCOWGrbpsdNXEaASiocftFRlMgY.get('mode')=='TOTAL_SEARCH' and HzDeCOWGrbpsdNXEaASiocftFRlMgP ==HzDeCOWGrbpsdNXEaASiocftFRlMPT:continue
   elif HzDeCOWGrbpsdNXEaASiocftFRlMgY.get('mode')=='TOTAL_HISTORY' and HzDeCOWGrbpsdNXEaASiocftFRlMgk==HzDeCOWGrbpsdNXEaASiocftFRlMPT:continue
   elif HzDeCOWGrbpsdNXEaASiocftFRlMgY.get('mode')=='MENU_BOOKMARK' and HzDeCOWGrbpsdNXEaASiocftFRlMgn==HzDeCOWGrbpsdNXEaASiocftFRlMPT:continue
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':HzDeCOWGrbpsdNXEaASiocftFRlMgY.get('mode'),'stype':HzDeCOWGrbpsdNXEaASiocftFRlMgY.get('stype'),'orderby':HzDeCOWGrbpsdNXEaASiocftFRlMgY.get('orderby'),'ordernm':HzDeCOWGrbpsdNXEaASiocftFRlMgY.get('ordernm'),'page':'1'}
   if HzDeCOWGrbpsdNXEaASiocftFRlMgY.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    HzDeCOWGrbpsdNXEaASiocftFRlMgm=HzDeCOWGrbpsdNXEaASiocftFRlMPT
    HzDeCOWGrbpsdNXEaASiocftFRlMJq =HzDeCOWGrbpsdNXEaASiocftFRlMPh
   else:
    HzDeCOWGrbpsdNXEaASiocftFRlMgm=HzDeCOWGrbpsdNXEaASiocftFRlMPh
    HzDeCOWGrbpsdNXEaASiocftFRlMJq =HzDeCOWGrbpsdNXEaASiocftFRlMPT
   if 'icon' in HzDeCOWGrbpsdNXEaASiocftFRlMgY:HzDeCOWGrbpsdNXEaASiocftFRlMgB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',HzDeCOWGrbpsdNXEaASiocftFRlMgY.get('icon')) 
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel='',img=HzDeCOWGrbpsdNXEaASiocftFRlMgB,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMgm,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL,isLink=HzDeCOWGrbpsdNXEaASiocftFRlMJq)
  xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle)
 def login_main(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  (HzDeCOWGrbpsdNXEaASiocftFRlMJI,HzDeCOWGrbpsdNXEaASiocftFRlMJy,HzDeCOWGrbpsdNXEaASiocftFRlMJv,HzDeCOWGrbpsdNXEaASiocftFRlMJU)=HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_account()
  if not(HzDeCOWGrbpsdNXEaASiocftFRlMJI and HzDeCOWGrbpsdNXEaASiocftFRlMJy):
   HzDeCOWGrbpsdNXEaASiocftFRlMqh=xbmcgui.Dialog()
   HzDeCOWGrbpsdNXEaASiocftFRlMJP=HzDeCOWGrbpsdNXEaASiocftFRlMqh.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if HzDeCOWGrbpsdNXEaASiocftFRlMJP==HzDeCOWGrbpsdNXEaASiocftFRlMPh:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if HzDeCOWGrbpsdNXEaASiocftFRlMqu.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   HzDeCOWGrbpsdNXEaASiocftFRlMJk=0
   while HzDeCOWGrbpsdNXEaASiocftFRlMPh:
    HzDeCOWGrbpsdNXEaASiocftFRlMJk+=1
    time.sleep(0.05)
    if HzDeCOWGrbpsdNXEaASiocftFRlMJk>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  HzDeCOWGrbpsdNXEaASiocftFRlMJn=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.GetCredential(HzDeCOWGrbpsdNXEaASiocftFRlMJI,HzDeCOWGrbpsdNXEaASiocftFRlMJy,HzDeCOWGrbpsdNXEaASiocftFRlMJv,HzDeCOWGrbpsdNXEaASiocftFRlMJU)
  if HzDeCOWGrbpsdNXEaASiocftFRlMJn:HzDeCOWGrbpsdNXEaASiocftFRlMqu.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if HzDeCOWGrbpsdNXEaASiocftFRlMJn==HzDeCOWGrbpsdNXEaASiocftFRlMPT:
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMJx=HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('stype')
  if HzDeCOWGrbpsdNXEaASiocftFRlMJx=='live':
   HzDeCOWGrbpsdNXEaASiocftFRlMJu=HzDeCOWGrbpsdNXEaASiocftFRlMqI
  elif HzDeCOWGrbpsdNXEaASiocftFRlMJx=='vod':
   HzDeCOWGrbpsdNXEaASiocftFRlMJu=HzDeCOWGrbpsdNXEaASiocftFRlMqU
  else:
   HzDeCOWGrbpsdNXEaASiocftFRlMJu=HzDeCOWGrbpsdNXEaASiocftFRlMqP
  for HzDeCOWGrbpsdNXEaASiocftFRlMJK in HzDeCOWGrbpsdNXEaASiocftFRlMJu:
   HzDeCOWGrbpsdNXEaASiocftFRlMgV=HzDeCOWGrbpsdNXEaASiocftFRlMJK.get('title')
   if HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('ordernm')!='-':
    HzDeCOWGrbpsdNXEaASiocftFRlMgV+='  ('+HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('ordernm')+')'
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':HzDeCOWGrbpsdNXEaASiocftFRlMJK.get('mode'),'stype':HzDeCOWGrbpsdNXEaASiocftFRlMJK.get('stype'),'orderby':HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('orderby'),'ordernm':HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('ordernm'),'page':'1'}
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel='',img='',infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  if HzDeCOWGrbpsdNXEaASiocftFRlMPB(HzDeCOWGrbpsdNXEaASiocftFRlMJu)>0:xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle)
 def dp_SubTitle_Group(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj): 
  for HzDeCOWGrbpsdNXEaASiocftFRlMJK in HzDeCOWGrbpsdNXEaASiocftFRlMqk:
   HzDeCOWGrbpsdNXEaASiocftFRlMgV=HzDeCOWGrbpsdNXEaASiocftFRlMJK.get('title')
   if HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('ordernm')!='-':
    HzDeCOWGrbpsdNXEaASiocftFRlMgV+='  ('+HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('ordernm')+')'
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':HzDeCOWGrbpsdNXEaASiocftFRlMJK.get('mode'),'genreCode':HzDeCOWGrbpsdNXEaASiocftFRlMJK.get('genreCode'),'stype':HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('stype'),'orderby':HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('orderby'),'page':'1'}
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel='',img='',infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  if HzDeCOWGrbpsdNXEaASiocftFRlMPB(HzDeCOWGrbpsdNXEaASiocftFRlMqk)>0:xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle)
 def dp_LiveChannel_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMJx =HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('stype')
  HzDeCOWGrbpsdNXEaASiocftFRlMJV =HzDeCOWGrbpsdNXEaASiocftFRlMPw(HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('page'))
  HzDeCOWGrbpsdNXEaASiocftFRlMJw,HzDeCOWGrbpsdNXEaASiocftFRlMJh=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.GetLiveChannelList(HzDeCOWGrbpsdNXEaASiocftFRlMJx,HzDeCOWGrbpsdNXEaASiocftFRlMJV)
  for HzDeCOWGrbpsdNXEaASiocftFRlMJT in HzDeCOWGrbpsdNXEaASiocftFRlMJw:
   HzDeCOWGrbpsdNXEaASiocftFRlMgV =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('title')
   HzDeCOWGrbpsdNXEaASiocftFRlMJg =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('channel')
   HzDeCOWGrbpsdNXEaASiocftFRlMJQ =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('thumbnail')
   HzDeCOWGrbpsdNXEaASiocftFRlMJY =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('synopsis')
   HzDeCOWGrbpsdNXEaASiocftFRlMJB =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('channelepg')
   HzDeCOWGrbpsdNXEaASiocftFRlMJL =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('cast')
   HzDeCOWGrbpsdNXEaASiocftFRlMJm =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('director')
   HzDeCOWGrbpsdNXEaASiocftFRlMIq =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('info_genre')
   HzDeCOWGrbpsdNXEaASiocftFRlMIg =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('year')
   HzDeCOWGrbpsdNXEaASiocftFRlMIJ =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('mpaa')
   HzDeCOWGrbpsdNXEaASiocftFRlMIy =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('premiered')
   HzDeCOWGrbpsdNXEaASiocftFRlMIv={'mediatype':'episode','title':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'studio':HzDeCOWGrbpsdNXEaASiocftFRlMJg,'cast':HzDeCOWGrbpsdNXEaASiocftFRlMJL,'director':HzDeCOWGrbpsdNXEaASiocftFRlMJm,'genre':HzDeCOWGrbpsdNXEaASiocftFRlMIq,'plot':'%s\n%s\n%s\n\n%s'%(HzDeCOWGrbpsdNXEaASiocftFRlMJg,HzDeCOWGrbpsdNXEaASiocftFRlMgV,HzDeCOWGrbpsdNXEaASiocftFRlMJB,HzDeCOWGrbpsdNXEaASiocftFRlMJY),'year':HzDeCOWGrbpsdNXEaASiocftFRlMIg,'mpaa':HzDeCOWGrbpsdNXEaASiocftFRlMIJ,'premiered':HzDeCOWGrbpsdNXEaASiocftFRlMIy}
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'LIVE','mediacode':HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('mediacode'),'stype':HzDeCOWGrbpsdNXEaASiocftFRlMJx}
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMJg,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMgV,img=HzDeCOWGrbpsdNXEaASiocftFRlMJQ,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMIv,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPT,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  if HzDeCOWGrbpsdNXEaASiocftFRlMJh:
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['mode']='CHANNEL' 
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['stype']=HzDeCOWGrbpsdNXEaASiocftFRlMJx 
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['page']=HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgV='[B]%s >>[/B]'%'다음 페이지'
   HzDeCOWGrbpsdNXEaASiocftFRlMIU=HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMIU,img=HzDeCOWGrbpsdNXEaASiocftFRlMgB,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  if HzDeCOWGrbpsdNXEaASiocftFRlMPB(HzDeCOWGrbpsdNXEaASiocftFRlMJw)>0:xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,cacheToDisc=HzDeCOWGrbpsdNXEaASiocftFRlMPT)
 def dp_Program_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMIP =HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('stype')
  HzDeCOWGrbpsdNXEaASiocftFRlMgK =HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('orderby')
  HzDeCOWGrbpsdNXEaASiocftFRlMJV =HzDeCOWGrbpsdNXEaASiocftFRlMPw(HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('page'))
  HzDeCOWGrbpsdNXEaASiocftFRlMIk=HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('genreCode')
  if HzDeCOWGrbpsdNXEaASiocftFRlMIk==HzDeCOWGrbpsdNXEaASiocftFRlMPV:HzDeCOWGrbpsdNXEaASiocftFRlMIk='all'
  HzDeCOWGrbpsdNXEaASiocftFRlMIn,HzDeCOWGrbpsdNXEaASiocftFRlMJh=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.GetProgramList(HzDeCOWGrbpsdNXEaASiocftFRlMIP,HzDeCOWGrbpsdNXEaASiocftFRlMgK,HzDeCOWGrbpsdNXEaASiocftFRlMJV,HzDeCOWGrbpsdNXEaASiocftFRlMIk)
  for HzDeCOWGrbpsdNXEaASiocftFRlMIx in HzDeCOWGrbpsdNXEaASiocftFRlMIn:
   HzDeCOWGrbpsdNXEaASiocftFRlMgV =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('title')
   HzDeCOWGrbpsdNXEaASiocftFRlMJQ =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('thumbnail')
   HzDeCOWGrbpsdNXEaASiocftFRlMJY =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('synopsis')
   HzDeCOWGrbpsdNXEaASiocftFRlMIu =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('channel')
   HzDeCOWGrbpsdNXEaASiocftFRlMJL =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('cast')
   HzDeCOWGrbpsdNXEaASiocftFRlMJm =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('director')
   HzDeCOWGrbpsdNXEaASiocftFRlMIq=HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('info_genre')
   HzDeCOWGrbpsdNXEaASiocftFRlMIg =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('year')
   HzDeCOWGrbpsdNXEaASiocftFRlMIy =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('premiered')
   HzDeCOWGrbpsdNXEaASiocftFRlMIJ =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('mpaa')
   HzDeCOWGrbpsdNXEaASiocftFRlMIv={'mediatype':'tvshow','title':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'studio':HzDeCOWGrbpsdNXEaASiocftFRlMIu,'cast':HzDeCOWGrbpsdNXEaASiocftFRlMJL,'director':HzDeCOWGrbpsdNXEaASiocftFRlMJm,'genre':HzDeCOWGrbpsdNXEaASiocftFRlMIq,'year':HzDeCOWGrbpsdNXEaASiocftFRlMIg,'premiered':HzDeCOWGrbpsdNXEaASiocftFRlMIy,'mpaa':HzDeCOWGrbpsdNXEaASiocftFRlMIJ,'plot':HzDeCOWGrbpsdNXEaASiocftFRlMJY}
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'EPISODE','programcode':HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('program'),'page':'1'}
   if HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_makebookmark():
    HzDeCOWGrbpsdNXEaASiocftFRlMIK={'videoid':HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('program'),'vidtype':'tvshow','vtitle':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'vsubtitle':HzDeCOWGrbpsdNXEaASiocftFRlMIu,}
    HzDeCOWGrbpsdNXEaASiocftFRlMIj=json.dumps(HzDeCOWGrbpsdNXEaASiocftFRlMIK)
    HzDeCOWGrbpsdNXEaASiocftFRlMIj=urllib.parse.quote(HzDeCOWGrbpsdNXEaASiocftFRlMIj)
    HzDeCOWGrbpsdNXEaASiocftFRlMIV='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(HzDeCOWGrbpsdNXEaASiocftFRlMIj)
    HzDeCOWGrbpsdNXEaASiocftFRlMIw=[('(통합) 찜 영상에 추가',HzDeCOWGrbpsdNXEaASiocftFRlMIV)]
   else:
    HzDeCOWGrbpsdNXEaASiocftFRlMIw=HzDeCOWGrbpsdNXEaASiocftFRlMPV
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMIu,img=HzDeCOWGrbpsdNXEaASiocftFRlMJQ,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMIv,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL,ContextMenu=HzDeCOWGrbpsdNXEaASiocftFRlMIw)
  if HzDeCOWGrbpsdNXEaASiocftFRlMJh:
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['mode'] ='PROGRAM' 
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['stype'] =HzDeCOWGrbpsdNXEaASiocftFRlMIP
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['orderby'] =HzDeCOWGrbpsdNXEaASiocftFRlMgK
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['page'] =HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['genreCode']=HzDeCOWGrbpsdNXEaASiocftFRlMIk 
   HzDeCOWGrbpsdNXEaASiocftFRlMgV='[B]%s >>[/B]'%'다음 페이지'
   HzDeCOWGrbpsdNXEaASiocftFRlMIU=HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMIU,img=HzDeCOWGrbpsdNXEaASiocftFRlMgB,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  xbmcplugin.setContent(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,cacheToDisc=HzDeCOWGrbpsdNXEaASiocftFRlMPT)
 def dp_4K_Program_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMJV =HzDeCOWGrbpsdNXEaASiocftFRlMPw(HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('page'))
  HzDeCOWGrbpsdNXEaASiocftFRlMIn,HzDeCOWGrbpsdNXEaASiocftFRlMJh=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.Get_UHD_ProgramList(HzDeCOWGrbpsdNXEaASiocftFRlMJV)
  for HzDeCOWGrbpsdNXEaASiocftFRlMIx in HzDeCOWGrbpsdNXEaASiocftFRlMIn:
   HzDeCOWGrbpsdNXEaASiocftFRlMgV =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('title')
   HzDeCOWGrbpsdNXEaASiocftFRlMJQ =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('thumbnail')
   HzDeCOWGrbpsdNXEaASiocftFRlMJY =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('synopsis')
   HzDeCOWGrbpsdNXEaASiocftFRlMIu =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('channel')
   HzDeCOWGrbpsdNXEaASiocftFRlMJL =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('cast')
   HzDeCOWGrbpsdNXEaASiocftFRlMJm =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('director')
   HzDeCOWGrbpsdNXEaASiocftFRlMIq=HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('info_genre')
   HzDeCOWGrbpsdNXEaASiocftFRlMIg =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('year')
   HzDeCOWGrbpsdNXEaASiocftFRlMIy =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('premiered')
   HzDeCOWGrbpsdNXEaASiocftFRlMIJ =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('mpaa')
   HzDeCOWGrbpsdNXEaASiocftFRlMIv={'mediatype':'tvshow','title':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'studio':HzDeCOWGrbpsdNXEaASiocftFRlMIu,'cast':HzDeCOWGrbpsdNXEaASiocftFRlMJL,'director':HzDeCOWGrbpsdNXEaASiocftFRlMJm,'genre':HzDeCOWGrbpsdNXEaASiocftFRlMIq,'year':HzDeCOWGrbpsdNXEaASiocftFRlMIg,'premiered':HzDeCOWGrbpsdNXEaASiocftFRlMIy,'mpaa':HzDeCOWGrbpsdNXEaASiocftFRlMIJ,'plot':HzDeCOWGrbpsdNXEaASiocftFRlMJY}
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'EPISODE','programcode':HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('program'),'page':'1'}
   if HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_makebookmark():
    HzDeCOWGrbpsdNXEaASiocftFRlMIK={'videoid':HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('program'),'vidtype':'tvshow','vtitle':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'vsubtitle':HzDeCOWGrbpsdNXEaASiocftFRlMIu,}
    HzDeCOWGrbpsdNXEaASiocftFRlMIj=json.dumps(HzDeCOWGrbpsdNXEaASiocftFRlMIK)
    HzDeCOWGrbpsdNXEaASiocftFRlMIj=urllib.parse.quote(HzDeCOWGrbpsdNXEaASiocftFRlMIj)
    HzDeCOWGrbpsdNXEaASiocftFRlMIV='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(HzDeCOWGrbpsdNXEaASiocftFRlMIj)
    HzDeCOWGrbpsdNXEaASiocftFRlMIw=[('(통합) 찜 영상에 추가',HzDeCOWGrbpsdNXEaASiocftFRlMIV)]
   else:
    HzDeCOWGrbpsdNXEaASiocftFRlMIw=HzDeCOWGrbpsdNXEaASiocftFRlMPV
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMIu,img=HzDeCOWGrbpsdNXEaASiocftFRlMJQ,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMIv,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL,ContextMenu=HzDeCOWGrbpsdNXEaASiocftFRlMIw)
  if HzDeCOWGrbpsdNXEaASiocftFRlMJh:
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['mode'] ='4K_PROGRAM' 
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['page'] =HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgV='[B]%s >>[/B]'%'다음 페이지'
   HzDeCOWGrbpsdNXEaASiocftFRlMIU=HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMIU,img=HzDeCOWGrbpsdNXEaASiocftFRlMgB,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  xbmcplugin.setContent(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,cacheToDisc=HzDeCOWGrbpsdNXEaASiocftFRlMPT)
 def dp_Ori_Program_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMJV =HzDeCOWGrbpsdNXEaASiocftFRlMPw(HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('page'))
  HzDeCOWGrbpsdNXEaASiocftFRlMIn,HzDeCOWGrbpsdNXEaASiocftFRlMJh=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.Get_Origianl_ProgramList(HzDeCOWGrbpsdNXEaASiocftFRlMJV)
  for HzDeCOWGrbpsdNXEaASiocftFRlMIx in HzDeCOWGrbpsdNXEaASiocftFRlMIn:
   HzDeCOWGrbpsdNXEaASiocftFRlMgV =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('title')
   HzDeCOWGrbpsdNXEaASiocftFRlMJQ =HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('thumbnail')
   HzDeCOWGrbpsdNXEaASiocftFRlMIv={'mediatype':'tvshow','title':HzDeCOWGrbpsdNXEaASiocftFRlMgV,}
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'EPISODE','programcode':HzDeCOWGrbpsdNXEaASiocftFRlMIx.get('program'),'page':'1',}
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMPV,img=HzDeCOWGrbpsdNXEaASiocftFRlMJQ,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMIv,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL,ContextMenu=HzDeCOWGrbpsdNXEaASiocftFRlMPV)
  if HzDeCOWGrbpsdNXEaASiocftFRlMJh:
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['mode'] ='ORI_PROGRAM' 
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['page'] =HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgV='[B]%s >>[/B]'%'다음 페이지'
   HzDeCOWGrbpsdNXEaASiocftFRlMIU=HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMIU,img=HzDeCOWGrbpsdNXEaASiocftFRlMgB,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  xbmcplugin.setContent(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,cacheToDisc=HzDeCOWGrbpsdNXEaASiocftFRlMPT)
 def dp_Episode_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMIT=HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('programcode')
  HzDeCOWGrbpsdNXEaASiocftFRlMJV =HzDeCOWGrbpsdNXEaASiocftFRlMPw(HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('page'))
  HzDeCOWGrbpsdNXEaASiocftFRlMIQ,HzDeCOWGrbpsdNXEaASiocftFRlMJh,HzDeCOWGrbpsdNXEaASiocftFRlMIY=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.GetEpisodeList(HzDeCOWGrbpsdNXEaASiocftFRlMIT,HzDeCOWGrbpsdNXEaASiocftFRlMJV,orderby=HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_winEpisodeOrderby())
  for HzDeCOWGrbpsdNXEaASiocftFRlMIB in HzDeCOWGrbpsdNXEaASiocftFRlMIQ:
   HzDeCOWGrbpsdNXEaASiocftFRlMgV =HzDeCOWGrbpsdNXEaASiocftFRlMIB.get('title')
   HzDeCOWGrbpsdNXEaASiocftFRlMIU =HzDeCOWGrbpsdNXEaASiocftFRlMIB.get('subtitle')
   HzDeCOWGrbpsdNXEaASiocftFRlMJQ =HzDeCOWGrbpsdNXEaASiocftFRlMIB.get('thumbnail')
   HzDeCOWGrbpsdNXEaASiocftFRlMJY =HzDeCOWGrbpsdNXEaASiocftFRlMIB.get('synopsis')
   HzDeCOWGrbpsdNXEaASiocftFRlMIL=HzDeCOWGrbpsdNXEaASiocftFRlMIB.get('info_title')
   HzDeCOWGrbpsdNXEaASiocftFRlMIm =HzDeCOWGrbpsdNXEaASiocftFRlMIB.get('aired')
   HzDeCOWGrbpsdNXEaASiocftFRlMyq =HzDeCOWGrbpsdNXEaASiocftFRlMIB.get('studio')
   HzDeCOWGrbpsdNXEaASiocftFRlMyg =HzDeCOWGrbpsdNXEaASiocftFRlMIB.get('frequency')
   HzDeCOWGrbpsdNXEaASiocftFRlMIv={'mediatype':'episode','title':HzDeCOWGrbpsdNXEaASiocftFRlMIL,'aired':HzDeCOWGrbpsdNXEaASiocftFRlMIm,'studio':HzDeCOWGrbpsdNXEaASiocftFRlMyq,'episode':HzDeCOWGrbpsdNXEaASiocftFRlMyg,'plot':HzDeCOWGrbpsdNXEaASiocftFRlMJY}
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'VOD','mediacode':HzDeCOWGrbpsdNXEaASiocftFRlMIB.get('episode'),'stype':'vod','programcode':HzDeCOWGrbpsdNXEaASiocftFRlMIT,'title':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'thumbnail':HzDeCOWGrbpsdNXEaASiocftFRlMJQ}
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMIU,img=HzDeCOWGrbpsdNXEaASiocftFRlMJQ,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMIv,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPT,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  if HzDeCOWGrbpsdNXEaASiocftFRlMJV==1:
   HzDeCOWGrbpsdNXEaASiocftFRlMIv={'plot':'정렬순서를 변경합니다.'}
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={}
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['mode'] ='ORDER_BY' 
   if HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_winEpisodeOrderby()=='desc':
    HzDeCOWGrbpsdNXEaASiocftFRlMgV='정렬순서변경 : 최신화부터 -> 1회부터'
    HzDeCOWGrbpsdNXEaASiocftFRlMgL['orderby']='asc'
   else:
    HzDeCOWGrbpsdNXEaASiocftFRlMgV='정렬순서변경 : 1회부터 -> 최신화부터'
    HzDeCOWGrbpsdNXEaASiocftFRlMgL['orderby']='desc'
   HzDeCOWGrbpsdNXEaASiocftFRlMgB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel='',img=HzDeCOWGrbpsdNXEaASiocftFRlMgB,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMIv,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPT,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL,isLink=HzDeCOWGrbpsdNXEaASiocftFRlMPh)
  if HzDeCOWGrbpsdNXEaASiocftFRlMJh:
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['mode'] ='EPISODE' 
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['programcode']=HzDeCOWGrbpsdNXEaASiocftFRlMIT
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['page'] =HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgV='[B]%s >>[/B]'%'다음 페이지'
   HzDeCOWGrbpsdNXEaASiocftFRlMIU=HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMIU,img=HzDeCOWGrbpsdNXEaASiocftFRlMgB,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  xbmcplugin.setContent(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,'episodes')
  if HzDeCOWGrbpsdNXEaASiocftFRlMPB(HzDeCOWGrbpsdNXEaASiocftFRlMIQ)>0:xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,cacheToDisc=HzDeCOWGrbpsdNXEaASiocftFRlMPh)
 def dp_setEpOrderby(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMgK =HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('orderby')
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.set_winEpisodeOrderby(HzDeCOWGrbpsdNXEaASiocftFRlMgK)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMIP =HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('stype')
  HzDeCOWGrbpsdNXEaASiocftFRlMgK =HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('orderby')
  HzDeCOWGrbpsdNXEaASiocftFRlMJV=HzDeCOWGrbpsdNXEaASiocftFRlMPw(HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('page'))
  HzDeCOWGrbpsdNXEaASiocftFRlMyJ,HzDeCOWGrbpsdNXEaASiocftFRlMJh=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.GetMovieList(HzDeCOWGrbpsdNXEaASiocftFRlMIP,HzDeCOWGrbpsdNXEaASiocftFRlMgK,HzDeCOWGrbpsdNXEaASiocftFRlMJV)
  for HzDeCOWGrbpsdNXEaASiocftFRlMyI in HzDeCOWGrbpsdNXEaASiocftFRlMyJ:
   HzDeCOWGrbpsdNXEaASiocftFRlMgV =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('title')
   HzDeCOWGrbpsdNXEaASiocftFRlMJQ =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('thumbnail')
   HzDeCOWGrbpsdNXEaASiocftFRlMJY =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('synopsis')
   HzDeCOWGrbpsdNXEaASiocftFRlMIL =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('info_title')
   HzDeCOWGrbpsdNXEaASiocftFRlMIg =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('year')
   HzDeCOWGrbpsdNXEaASiocftFRlMJL =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('cast')
   HzDeCOWGrbpsdNXEaASiocftFRlMJm =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('director')
   HzDeCOWGrbpsdNXEaASiocftFRlMIq =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('info_genre')
   HzDeCOWGrbpsdNXEaASiocftFRlMyv =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('duration')
   HzDeCOWGrbpsdNXEaASiocftFRlMIy =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('premiered')
   HzDeCOWGrbpsdNXEaASiocftFRlMyq =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('studio')
   HzDeCOWGrbpsdNXEaASiocftFRlMIJ =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('mpaa')
   HzDeCOWGrbpsdNXEaASiocftFRlMIv={'mediatype':'movie','title':HzDeCOWGrbpsdNXEaASiocftFRlMIL,'year':HzDeCOWGrbpsdNXEaASiocftFRlMIg,'cast':HzDeCOWGrbpsdNXEaASiocftFRlMJL,'director':HzDeCOWGrbpsdNXEaASiocftFRlMJm,'genre':HzDeCOWGrbpsdNXEaASiocftFRlMIq,'duration':HzDeCOWGrbpsdNXEaASiocftFRlMyv,'premiered':HzDeCOWGrbpsdNXEaASiocftFRlMIy,'studio':HzDeCOWGrbpsdNXEaASiocftFRlMyq,'mpaa':HzDeCOWGrbpsdNXEaASiocftFRlMIJ,'plot':HzDeCOWGrbpsdNXEaASiocftFRlMJY}
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'MOVIE','mediacode':HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('moviecode'),'stype':'movie','title':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'thumbnail':HzDeCOWGrbpsdNXEaASiocftFRlMJQ}
   if HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_makebookmark():
    HzDeCOWGrbpsdNXEaASiocftFRlMIK={'videoid':HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('moviecode'),'vidtype':'movie','vtitle':HzDeCOWGrbpsdNXEaASiocftFRlMIL,'vsubtitle':'',}
    HzDeCOWGrbpsdNXEaASiocftFRlMIj=json.dumps(HzDeCOWGrbpsdNXEaASiocftFRlMIK)
    HzDeCOWGrbpsdNXEaASiocftFRlMIj=urllib.parse.quote(HzDeCOWGrbpsdNXEaASiocftFRlMIj)
    HzDeCOWGrbpsdNXEaASiocftFRlMIV='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(HzDeCOWGrbpsdNXEaASiocftFRlMIj)
    HzDeCOWGrbpsdNXEaASiocftFRlMIw=[('(통합) 찜 영상에 추가',HzDeCOWGrbpsdNXEaASiocftFRlMIV)]
   else:
    HzDeCOWGrbpsdNXEaASiocftFRlMIw=HzDeCOWGrbpsdNXEaASiocftFRlMPV
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel='',img=HzDeCOWGrbpsdNXEaASiocftFRlMJQ,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMIv,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPT,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL,ContextMenu=HzDeCOWGrbpsdNXEaASiocftFRlMIw)
  if HzDeCOWGrbpsdNXEaASiocftFRlMJh:
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={}
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['mode'] ='MOVIE_SUB' 
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['orderby']=HzDeCOWGrbpsdNXEaASiocftFRlMgK
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['stype'] =HzDeCOWGrbpsdNXEaASiocftFRlMIP
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['page'] =HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgV='[B]%s >>[/B]'%'다음 페이지'
   HzDeCOWGrbpsdNXEaASiocftFRlMIU=HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMIU,img=HzDeCOWGrbpsdNXEaASiocftFRlMgB,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  xbmcplugin.setContent(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,'movies')
  xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,cacheToDisc=HzDeCOWGrbpsdNXEaASiocftFRlMPT)
 def dp_4K_Movie_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMJV=HzDeCOWGrbpsdNXEaASiocftFRlMPw(HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('page'))
  HzDeCOWGrbpsdNXEaASiocftFRlMyJ,HzDeCOWGrbpsdNXEaASiocftFRlMJh=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.Get_UHD_MovieList(HzDeCOWGrbpsdNXEaASiocftFRlMJV)
  for HzDeCOWGrbpsdNXEaASiocftFRlMyI in HzDeCOWGrbpsdNXEaASiocftFRlMyJ:
   HzDeCOWGrbpsdNXEaASiocftFRlMgV =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('title')
   HzDeCOWGrbpsdNXEaASiocftFRlMJQ =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('thumbnail')
   HzDeCOWGrbpsdNXEaASiocftFRlMJY =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('synopsis')
   HzDeCOWGrbpsdNXEaASiocftFRlMIL =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('info_title')
   HzDeCOWGrbpsdNXEaASiocftFRlMIg =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('year')
   HzDeCOWGrbpsdNXEaASiocftFRlMJL =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('cast')
   HzDeCOWGrbpsdNXEaASiocftFRlMJm =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('director')
   HzDeCOWGrbpsdNXEaASiocftFRlMIq =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('info_genre')
   HzDeCOWGrbpsdNXEaASiocftFRlMyv =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('duration')
   HzDeCOWGrbpsdNXEaASiocftFRlMIy =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('premiered')
   HzDeCOWGrbpsdNXEaASiocftFRlMyq =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('studio')
   HzDeCOWGrbpsdNXEaASiocftFRlMIJ =HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('mpaa')
   HzDeCOWGrbpsdNXEaASiocftFRlMIv={'mediatype':'movie','title':HzDeCOWGrbpsdNXEaASiocftFRlMIL,'year':HzDeCOWGrbpsdNXEaASiocftFRlMIg,'cast':HzDeCOWGrbpsdNXEaASiocftFRlMJL,'director':HzDeCOWGrbpsdNXEaASiocftFRlMJm,'genre':HzDeCOWGrbpsdNXEaASiocftFRlMIq,'duration':HzDeCOWGrbpsdNXEaASiocftFRlMyv,'premiered':HzDeCOWGrbpsdNXEaASiocftFRlMIy,'studio':HzDeCOWGrbpsdNXEaASiocftFRlMyq,'mpaa':HzDeCOWGrbpsdNXEaASiocftFRlMIJ,'plot':HzDeCOWGrbpsdNXEaASiocftFRlMJY}
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'MOVIE','mediacode':HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('moviecode'),'stype':'movie','title':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'thumbnail':HzDeCOWGrbpsdNXEaASiocftFRlMJQ}
   if HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_makebookmark():
    HzDeCOWGrbpsdNXEaASiocftFRlMIK={'videoid':HzDeCOWGrbpsdNXEaASiocftFRlMyI.get('moviecode'),'vidtype':'movie','vtitle':HzDeCOWGrbpsdNXEaASiocftFRlMIL,'vsubtitle':'',}
    HzDeCOWGrbpsdNXEaASiocftFRlMIj=json.dumps(HzDeCOWGrbpsdNXEaASiocftFRlMIK)
    HzDeCOWGrbpsdNXEaASiocftFRlMIj=urllib.parse.quote(HzDeCOWGrbpsdNXEaASiocftFRlMIj)
    HzDeCOWGrbpsdNXEaASiocftFRlMIV='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(HzDeCOWGrbpsdNXEaASiocftFRlMIj)
    HzDeCOWGrbpsdNXEaASiocftFRlMIw=[('(통합) 찜 영상에 추가',HzDeCOWGrbpsdNXEaASiocftFRlMIV)]
   else:
    HzDeCOWGrbpsdNXEaASiocftFRlMIw=HzDeCOWGrbpsdNXEaASiocftFRlMPV
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel='',img=HzDeCOWGrbpsdNXEaASiocftFRlMJQ,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMIv,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPT,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL,ContextMenu=HzDeCOWGrbpsdNXEaASiocftFRlMIw)
  if HzDeCOWGrbpsdNXEaASiocftFRlMJh:
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={}
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['mode'] ='4K_MOVIE' 
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['page'] =HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgV='[B]%s >>[/B]'%'다음 페이지'
   HzDeCOWGrbpsdNXEaASiocftFRlMIU=HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMIU,img=HzDeCOWGrbpsdNXEaASiocftFRlMgB,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  xbmcplugin.setContent(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,'movies')
  xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,cacheToDisc=HzDeCOWGrbpsdNXEaASiocftFRlMPT)
 def dp_Set_Bookmark(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMyU=urllib.parse.unquote(HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('bm_param'))
  HzDeCOWGrbpsdNXEaASiocftFRlMyU=json.loads(HzDeCOWGrbpsdNXEaASiocftFRlMyU)
  HzDeCOWGrbpsdNXEaASiocftFRlMyP =HzDeCOWGrbpsdNXEaASiocftFRlMyU.get('videoid')
  HzDeCOWGrbpsdNXEaASiocftFRlMyk =HzDeCOWGrbpsdNXEaASiocftFRlMyU.get('vidtype')
  HzDeCOWGrbpsdNXEaASiocftFRlMyn =HzDeCOWGrbpsdNXEaASiocftFRlMyU.get('vtitle')
  HzDeCOWGrbpsdNXEaASiocftFRlMyx =HzDeCOWGrbpsdNXEaASiocftFRlMyU.get('vsubtitle')
  HzDeCOWGrbpsdNXEaASiocftFRlMqh=xbmcgui.Dialog()
  HzDeCOWGrbpsdNXEaASiocftFRlMJP=HzDeCOWGrbpsdNXEaASiocftFRlMqh.yesno(__language__(30913).encode('utf8'),HzDeCOWGrbpsdNXEaASiocftFRlMyn+' \n\n'+__language__(30914))
  if HzDeCOWGrbpsdNXEaASiocftFRlMJP==HzDeCOWGrbpsdNXEaASiocftFRlMPT:return
  HzDeCOWGrbpsdNXEaASiocftFRlMyu=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.GetBookmarkInfo(HzDeCOWGrbpsdNXEaASiocftFRlMyP,HzDeCOWGrbpsdNXEaASiocftFRlMyk)
  if HzDeCOWGrbpsdNXEaASiocftFRlMyx!='':
   HzDeCOWGrbpsdNXEaASiocftFRlMyu['saveinfo']['subtitle']=HzDeCOWGrbpsdNXEaASiocftFRlMyx 
   if HzDeCOWGrbpsdNXEaASiocftFRlMyk=='tvshow':HzDeCOWGrbpsdNXEaASiocftFRlMyu['saveinfo']['infoLabels']['studio']=HzDeCOWGrbpsdNXEaASiocftFRlMyx 
  HzDeCOWGrbpsdNXEaASiocftFRlMyK=json.dumps(HzDeCOWGrbpsdNXEaASiocftFRlMyu)
  HzDeCOWGrbpsdNXEaASiocftFRlMyK=urllib.parse.quote(HzDeCOWGrbpsdNXEaASiocftFRlMyK)
  HzDeCOWGrbpsdNXEaASiocftFRlMIV ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(HzDeCOWGrbpsdNXEaASiocftFRlMyK)
  xbmc.executebuiltin(HzDeCOWGrbpsdNXEaASiocftFRlMIV)
 def dp_Search_Group(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  if 'search_key' in HzDeCOWGrbpsdNXEaASiocftFRlMJj:
   HzDeCOWGrbpsdNXEaASiocftFRlMyj=HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('search_key')
  else:
   HzDeCOWGrbpsdNXEaASiocftFRlMyj=HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not HzDeCOWGrbpsdNXEaASiocftFRlMyj:
    return
  for HzDeCOWGrbpsdNXEaASiocftFRlMJK in HzDeCOWGrbpsdNXEaASiocftFRlMqv:
   HzDeCOWGrbpsdNXEaASiocftFRlMyV =HzDeCOWGrbpsdNXEaASiocftFRlMJK.get('mode')
   HzDeCOWGrbpsdNXEaASiocftFRlMJx=HzDeCOWGrbpsdNXEaASiocftFRlMJK.get('stype')
   HzDeCOWGrbpsdNXEaASiocftFRlMgV=HzDeCOWGrbpsdNXEaASiocftFRlMJK.get('title')
   (HzDeCOWGrbpsdNXEaASiocftFRlMyw,HzDeCOWGrbpsdNXEaASiocftFRlMJh)=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.GetSearchList(HzDeCOWGrbpsdNXEaASiocftFRlMyj,1,HzDeCOWGrbpsdNXEaASiocftFRlMJx)
   HzDeCOWGrbpsdNXEaASiocftFRlMyh={'plot':'검색어 : '+HzDeCOWGrbpsdNXEaASiocftFRlMyj+'\n\n'+HzDeCOWGrbpsdNXEaASiocftFRlMqu.Search_FreeList(HzDeCOWGrbpsdNXEaASiocftFRlMyw)}
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':HzDeCOWGrbpsdNXEaASiocftFRlMyV,'stype':HzDeCOWGrbpsdNXEaASiocftFRlMJx,'search_key':HzDeCOWGrbpsdNXEaASiocftFRlMyj,'page':'1',}
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel='',img='',infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMyh,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  if HzDeCOWGrbpsdNXEaASiocftFRlMPB(HzDeCOWGrbpsdNXEaASiocftFRlMqv)>0:xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,cacheToDisc=HzDeCOWGrbpsdNXEaASiocftFRlMPh)
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.Save_Searched_List(HzDeCOWGrbpsdNXEaASiocftFRlMyj)
 def Search_FreeList(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMvJ):
  HzDeCOWGrbpsdNXEaASiocftFRlMyT=''
  HzDeCOWGrbpsdNXEaASiocftFRlMyQ=7
  try:
   if HzDeCOWGrbpsdNXEaASiocftFRlMPB(HzDeCOWGrbpsdNXEaASiocftFRlMvJ)==0:return '검색결과 없음'
   for i in HzDeCOWGrbpsdNXEaASiocftFRlMPm(HzDeCOWGrbpsdNXEaASiocftFRlMPB(HzDeCOWGrbpsdNXEaASiocftFRlMvJ)):
    if i>=HzDeCOWGrbpsdNXEaASiocftFRlMyQ:
     HzDeCOWGrbpsdNXEaASiocftFRlMyT=HzDeCOWGrbpsdNXEaASiocftFRlMyT+'...'
     break
    HzDeCOWGrbpsdNXEaASiocftFRlMyT=HzDeCOWGrbpsdNXEaASiocftFRlMyT+HzDeCOWGrbpsdNXEaASiocftFRlMvJ[i]['title']+'\n'
  except:
   return ''
  return HzDeCOWGrbpsdNXEaASiocftFRlMyT
 def dp_Search_History(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMyY=HzDeCOWGrbpsdNXEaASiocftFRlMqu.Load_List_File('search')
  for HzDeCOWGrbpsdNXEaASiocftFRlMyB in HzDeCOWGrbpsdNXEaASiocftFRlMyY:
   HzDeCOWGrbpsdNXEaASiocftFRlMyL=HzDeCOWGrbpsdNXEaASiocftFRlMPY(urllib.parse.parse_qsl(HzDeCOWGrbpsdNXEaASiocftFRlMyB))
   HzDeCOWGrbpsdNXEaASiocftFRlMym=HzDeCOWGrbpsdNXEaASiocftFRlMyL.get('skey').strip()
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'SEARCH_GROUP','search_key':HzDeCOWGrbpsdNXEaASiocftFRlMym,}
   HzDeCOWGrbpsdNXEaASiocftFRlMvq={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':HzDeCOWGrbpsdNXEaASiocftFRlMym,'vType':'-',}
   HzDeCOWGrbpsdNXEaASiocftFRlMvg=urllib.parse.urlencode(HzDeCOWGrbpsdNXEaASiocftFRlMvq)
   HzDeCOWGrbpsdNXEaASiocftFRlMIw=[('선택된 검색어 ( %s ) 삭제'%(HzDeCOWGrbpsdNXEaASiocftFRlMym),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(HzDeCOWGrbpsdNXEaASiocftFRlMvg))]
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMym,sublabel='',img=HzDeCOWGrbpsdNXEaASiocftFRlMPV,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL,ContextMenu=HzDeCOWGrbpsdNXEaASiocftFRlMIw)
  HzDeCOWGrbpsdNXEaASiocftFRlMIv={'plot':'검색목록 전체를 삭제합니다.'}
  HzDeCOWGrbpsdNXEaASiocftFRlMgV='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  HzDeCOWGrbpsdNXEaASiocftFRlMgB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel='',img=HzDeCOWGrbpsdNXEaASiocftFRlMgB,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMIv,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPT,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL,isLink=HzDeCOWGrbpsdNXEaASiocftFRlMPh)
  xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,cacheToDisc=HzDeCOWGrbpsdNXEaASiocftFRlMPT)
 def dp_Search_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMJV =HzDeCOWGrbpsdNXEaASiocftFRlMPw(HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('page'))
  HzDeCOWGrbpsdNXEaASiocftFRlMJx =HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('stype')
  if 'search_key' in HzDeCOWGrbpsdNXEaASiocftFRlMJj:
   HzDeCOWGrbpsdNXEaASiocftFRlMyj=HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('search_key')
  else:
   HzDeCOWGrbpsdNXEaASiocftFRlMyj=HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not HzDeCOWGrbpsdNXEaASiocftFRlMyj:
    xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle)
    return
  HzDeCOWGrbpsdNXEaASiocftFRlMyw,HzDeCOWGrbpsdNXEaASiocftFRlMJh=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.GetSearchList(HzDeCOWGrbpsdNXEaASiocftFRlMyj,HzDeCOWGrbpsdNXEaASiocftFRlMJV,HzDeCOWGrbpsdNXEaASiocftFRlMJx)
  for HzDeCOWGrbpsdNXEaASiocftFRlMvJ in HzDeCOWGrbpsdNXEaASiocftFRlMyw:
   HzDeCOWGrbpsdNXEaASiocftFRlMgV =HzDeCOWGrbpsdNXEaASiocftFRlMvJ.get('title')
   HzDeCOWGrbpsdNXEaASiocftFRlMJQ =HzDeCOWGrbpsdNXEaASiocftFRlMvJ.get('thumbnail')
   HzDeCOWGrbpsdNXEaASiocftFRlMJY =HzDeCOWGrbpsdNXEaASiocftFRlMvJ.get('synopsis')
   HzDeCOWGrbpsdNXEaASiocftFRlMvI =HzDeCOWGrbpsdNXEaASiocftFRlMvJ.get('program')
   HzDeCOWGrbpsdNXEaASiocftFRlMJL =HzDeCOWGrbpsdNXEaASiocftFRlMvJ.get('cast')
   HzDeCOWGrbpsdNXEaASiocftFRlMJm =HzDeCOWGrbpsdNXEaASiocftFRlMvJ.get('director')
   HzDeCOWGrbpsdNXEaASiocftFRlMIq=HzDeCOWGrbpsdNXEaASiocftFRlMvJ.get('info_genre')
   HzDeCOWGrbpsdNXEaASiocftFRlMyv =HzDeCOWGrbpsdNXEaASiocftFRlMvJ.get('duration')
   HzDeCOWGrbpsdNXEaASiocftFRlMIJ =HzDeCOWGrbpsdNXEaASiocftFRlMvJ.get('mpaa')
   HzDeCOWGrbpsdNXEaASiocftFRlMIg =HzDeCOWGrbpsdNXEaASiocftFRlMvJ.get('year')
   HzDeCOWGrbpsdNXEaASiocftFRlMIm =HzDeCOWGrbpsdNXEaASiocftFRlMvJ.get('aired')
   HzDeCOWGrbpsdNXEaASiocftFRlMIv={'mediatype':'tvshow' if HzDeCOWGrbpsdNXEaASiocftFRlMJx=='vod' else 'movie','title':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'cast':HzDeCOWGrbpsdNXEaASiocftFRlMJL,'director':HzDeCOWGrbpsdNXEaASiocftFRlMJm,'genre':HzDeCOWGrbpsdNXEaASiocftFRlMIq,'duration':HzDeCOWGrbpsdNXEaASiocftFRlMyv,'mpaa':HzDeCOWGrbpsdNXEaASiocftFRlMIJ,'year':HzDeCOWGrbpsdNXEaASiocftFRlMIg,'aired':HzDeCOWGrbpsdNXEaASiocftFRlMIm,'plot':'%s\n\n%s'%(HzDeCOWGrbpsdNXEaASiocftFRlMgV,HzDeCOWGrbpsdNXEaASiocftFRlMJY)}
   if HzDeCOWGrbpsdNXEaASiocftFRlMJx=='vod':
    HzDeCOWGrbpsdNXEaASiocftFRlMyP=HzDeCOWGrbpsdNXEaASiocftFRlMvJ.get('program')
    HzDeCOWGrbpsdNXEaASiocftFRlMyk='tvshow'
    HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'EPISODE','programcode':HzDeCOWGrbpsdNXEaASiocftFRlMyP,'page':'1',}
    HzDeCOWGrbpsdNXEaASiocftFRlMgm=HzDeCOWGrbpsdNXEaASiocftFRlMPh
   else:
    HzDeCOWGrbpsdNXEaASiocftFRlMyP=HzDeCOWGrbpsdNXEaASiocftFRlMvJ.get('movie')
    HzDeCOWGrbpsdNXEaASiocftFRlMyk='movie'
    HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'MOVIE','mediacode':HzDeCOWGrbpsdNXEaASiocftFRlMyP,'stype':'movie','title':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'thumbnail':HzDeCOWGrbpsdNXEaASiocftFRlMJQ,}
    HzDeCOWGrbpsdNXEaASiocftFRlMgm=HzDeCOWGrbpsdNXEaASiocftFRlMPT
   if HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_makebookmark():
    HzDeCOWGrbpsdNXEaASiocftFRlMIK={'videoid':HzDeCOWGrbpsdNXEaASiocftFRlMyP,'vidtype':HzDeCOWGrbpsdNXEaASiocftFRlMyk,'vtitle':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'vsubtitle':'',}
    HzDeCOWGrbpsdNXEaASiocftFRlMIj=json.dumps(HzDeCOWGrbpsdNXEaASiocftFRlMIK)
    HzDeCOWGrbpsdNXEaASiocftFRlMIj=urllib.parse.quote(HzDeCOWGrbpsdNXEaASiocftFRlMIj)
    HzDeCOWGrbpsdNXEaASiocftFRlMIV='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(HzDeCOWGrbpsdNXEaASiocftFRlMIj)
    HzDeCOWGrbpsdNXEaASiocftFRlMIw=[('(통합) 찜 영상에 추가',HzDeCOWGrbpsdNXEaASiocftFRlMIV)]
   else:
    HzDeCOWGrbpsdNXEaASiocftFRlMIw=HzDeCOWGrbpsdNXEaASiocftFRlMPV
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel='',img=HzDeCOWGrbpsdNXEaASiocftFRlMJQ,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMIv,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMgm,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL,isLink=HzDeCOWGrbpsdNXEaASiocftFRlMPT,ContextMenu=HzDeCOWGrbpsdNXEaASiocftFRlMIw)
  if HzDeCOWGrbpsdNXEaASiocftFRlMJh:
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['mode'] ='SEARCH' 
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['search_key']=HzDeCOWGrbpsdNXEaASiocftFRlMyj
   HzDeCOWGrbpsdNXEaASiocftFRlMgL['page'] =HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgV='[B]%s >>[/B]'%'다음 페이지'
   HzDeCOWGrbpsdNXEaASiocftFRlMIU=HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMJV+1)
   HzDeCOWGrbpsdNXEaASiocftFRlMgB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMIU,img=HzDeCOWGrbpsdNXEaASiocftFRlMgB,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  if HzDeCOWGrbpsdNXEaASiocftFRlMJx=='movie':xbmcplugin.setContent(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,'movies')
  else:xbmcplugin.setContent(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,cacheToDisc=HzDeCOWGrbpsdNXEaASiocftFRlMPT)
 def dp_History_Remove(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMvy=HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('delType')
  HzDeCOWGrbpsdNXEaASiocftFRlMvU =HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('sKey')
  HzDeCOWGrbpsdNXEaASiocftFRlMvP =HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('vType')
  HzDeCOWGrbpsdNXEaASiocftFRlMqh=xbmcgui.Dialog()
  if HzDeCOWGrbpsdNXEaASiocftFRlMvy=='SEARCH_ALL':
   HzDeCOWGrbpsdNXEaASiocftFRlMJP=HzDeCOWGrbpsdNXEaASiocftFRlMqh.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif HzDeCOWGrbpsdNXEaASiocftFRlMvy=='SEARCH_ONE':
   HzDeCOWGrbpsdNXEaASiocftFRlMJP=HzDeCOWGrbpsdNXEaASiocftFRlMqh.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif HzDeCOWGrbpsdNXEaASiocftFRlMvy=='WATCH_ALL':
   HzDeCOWGrbpsdNXEaASiocftFRlMJP=HzDeCOWGrbpsdNXEaASiocftFRlMqh.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif HzDeCOWGrbpsdNXEaASiocftFRlMvy=='WATCH_ONE':
   HzDeCOWGrbpsdNXEaASiocftFRlMJP=HzDeCOWGrbpsdNXEaASiocftFRlMqh.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if HzDeCOWGrbpsdNXEaASiocftFRlMJP==HzDeCOWGrbpsdNXEaASiocftFRlMPT:sys.exit()
  if HzDeCOWGrbpsdNXEaASiocftFRlMvy=='SEARCH_ALL':
   if os.path.isfile(HzDeCOWGrbpsdNXEaASiocftFRlMqx):os.remove(HzDeCOWGrbpsdNXEaASiocftFRlMqx)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMvy=='SEARCH_ONE':
   try:
    HzDeCOWGrbpsdNXEaASiocftFRlMvk=HzDeCOWGrbpsdNXEaASiocftFRlMqx
    HzDeCOWGrbpsdNXEaASiocftFRlMvn=HzDeCOWGrbpsdNXEaASiocftFRlMqu.Load_List_File('search') 
    fp=HzDeCOWGrbpsdNXEaASiocftFRlMkq(HzDeCOWGrbpsdNXEaASiocftFRlMvk,'w',-1,'utf-8')
    for HzDeCOWGrbpsdNXEaASiocftFRlMvx in HzDeCOWGrbpsdNXEaASiocftFRlMvn:
     HzDeCOWGrbpsdNXEaASiocftFRlMvu=HzDeCOWGrbpsdNXEaASiocftFRlMPY(urllib.parse.parse_qsl(HzDeCOWGrbpsdNXEaASiocftFRlMvx))
     HzDeCOWGrbpsdNXEaASiocftFRlMvK=HzDeCOWGrbpsdNXEaASiocftFRlMvu.get('skey').strip()
     if HzDeCOWGrbpsdNXEaASiocftFRlMvU!=HzDeCOWGrbpsdNXEaASiocftFRlMvK:
      fp.write(HzDeCOWGrbpsdNXEaASiocftFRlMvx)
    fp.close()
   except:
    HzDeCOWGrbpsdNXEaASiocftFRlMPV
  elif HzDeCOWGrbpsdNXEaASiocftFRlMvy=='WATCH_ALL':
   HzDeCOWGrbpsdNXEaASiocftFRlMvk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%HzDeCOWGrbpsdNXEaASiocftFRlMvP))
   if os.path.isfile(HzDeCOWGrbpsdNXEaASiocftFRlMvk):os.remove(HzDeCOWGrbpsdNXEaASiocftFRlMvk)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMvy=='WATCH_ONE':
   HzDeCOWGrbpsdNXEaASiocftFRlMvk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%HzDeCOWGrbpsdNXEaASiocftFRlMvP))
   try:
    HzDeCOWGrbpsdNXEaASiocftFRlMvn=HzDeCOWGrbpsdNXEaASiocftFRlMqu.Load_List_File(HzDeCOWGrbpsdNXEaASiocftFRlMvP) 
    fp=HzDeCOWGrbpsdNXEaASiocftFRlMkq(HzDeCOWGrbpsdNXEaASiocftFRlMvk,'w',-1,'utf-8')
    for HzDeCOWGrbpsdNXEaASiocftFRlMvx in HzDeCOWGrbpsdNXEaASiocftFRlMvn:
     HzDeCOWGrbpsdNXEaASiocftFRlMvu=HzDeCOWGrbpsdNXEaASiocftFRlMPY(urllib.parse.parse_qsl(HzDeCOWGrbpsdNXEaASiocftFRlMvx))
     HzDeCOWGrbpsdNXEaASiocftFRlMvK=HzDeCOWGrbpsdNXEaASiocftFRlMvu.get('code').strip()
     if HzDeCOWGrbpsdNXEaASiocftFRlMvU!=HzDeCOWGrbpsdNXEaASiocftFRlMvK:
      fp.write(HzDeCOWGrbpsdNXEaASiocftFRlMvx)
    fp.close()
   except:
    HzDeCOWGrbpsdNXEaASiocftFRlMPV
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJx): 
  try:
   if HzDeCOWGrbpsdNXEaASiocftFRlMJx=='search':
    HzDeCOWGrbpsdNXEaASiocftFRlMvk=HzDeCOWGrbpsdNXEaASiocftFRlMqx
   elif HzDeCOWGrbpsdNXEaASiocftFRlMJx in['vod','movie']:
    HzDeCOWGrbpsdNXEaASiocftFRlMvk=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%HzDeCOWGrbpsdNXEaASiocftFRlMJx))
   else:
    return[]
   fp=HzDeCOWGrbpsdNXEaASiocftFRlMkq(HzDeCOWGrbpsdNXEaASiocftFRlMvk,'r',-1,'utf-8')
   HzDeCOWGrbpsdNXEaASiocftFRlMvj=fp.readlines()
   fp.close()
  except:
   HzDeCOWGrbpsdNXEaASiocftFRlMvj=[]
  return HzDeCOWGrbpsdNXEaASiocftFRlMvj
 def Save_Watched_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJx,HzDeCOWGrbpsdNXEaASiocftFRlMqV):
  try:
   HzDeCOWGrbpsdNXEaASiocftFRlMvV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%HzDeCOWGrbpsdNXEaASiocftFRlMJx))
   HzDeCOWGrbpsdNXEaASiocftFRlMvn=HzDeCOWGrbpsdNXEaASiocftFRlMqu.Load_List_File(HzDeCOWGrbpsdNXEaASiocftFRlMJx) 
   fp=HzDeCOWGrbpsdNXEaASiocftFRlMkq(HzDeCOWGrbpsdNXEaASiocftFRlMvV,'w',-1,'utf-8')
   HzDeCOWGrbpsdNXEaASiocftFRlMvw=urllib.parse.urlencode(HzDeCOWGrbpsdNXEaASiocftFRlMqV)
   HzDeCOWGrbpsdNXEaASiocftFRlMvw=HzDeCOWGrbpsdNXEaASiocftFRlMvw+'\n'
   fp.write(HzDeCOWGrbpsdNXEaASiocftFRlMvw)
   HzDeCOWGrbpsdNXEaASiocftFRlMvh=0
   for HzDeCOWGrbpsdNXEaASiocftFRlMvx in HzDeCOWGrbpsdNXEaASiocftFRlMvn:
    HzDeCOWGrbpsdNXEaASiocftFRlMvu=HzDeCOWGrbpsdNXEaASiocftFRlMPY(urllib.parse.parse_qsl(HzDeCOWGrbpsdNXEaASiocftFRlMvx))
    HzDeCOWGrbpsdNXEaASiocftFRlMvT=HzDeCOWGrbpsdNXEaASiocftFRlMqV.get('code').strip()
    HzDeCOWGrbpsdNXEaASiocftFRlMvQ=HzDeCOWGrbpsdNXEaASiocftFRlMvu.get('code').strip()
    if HzDeCOWGrbpsdNXEaASiocftFRlMJx=='vod' and HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_direct_replay()==HzDeCOWGrbpsdNXEaASiocftFRlMPh:
     HzDeCOWGrbpsdNXEaASiocftFRlMvT=HzDeCOWGrbpsdNXEaASiocftFRlMqV.get('videoid').strip()
     HzDeCOWGrbpsdNXEaASiocftFRlMvQ=HzDeCOWGrbpsdNXEaASiocftFRlMvu.get('videoid').strip()if HzDeCOWGrbpsdNXEaASiocftFRlMvQ!=HzDeCOWGrbpsdNXEaASiocftFRlMPV else '-'
    if HzDeCOWGrbpsdNXEaASiocftFRlMvT!=HzDeCOWGrbpsdNXEaASiocftFRlMvQ:
     fp.write(HzDeCOWGrbpsdNXEaASiocftFRlMvx)
     HzDeCOWGrbpsdNXEaASiocftFRlMvh+=1
     if HzDeCOWGrbpsdNXEaASiocftFRlMvh>=50:break
   fp.close()
  except:
   HzDeCOWGrbpsdNXEaASiocftFRlMPV
 def dp_Watch_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMJx =HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('stype')
  HzDeCOWGrbpsdNXEaASiocftFRlMgx=HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_direct_replay()
  if HzDeCOWGrbpsdNXEaASiocftFRlMJx=='-':
   for HzDeCOWGrbpsdNXEaASiocftFRlMJK in HzDeCOWGrbpsdNXEaASiocftFRlMqy:
    HzDeCOWGrbpsdNXEaASiocftFRlMgV=HzDeCOWGrbpsdNXEaASiocftFRlMJK.get('title')
    HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':HzDeCOWGrbpsdNXEaASiocftFRlMJK.get('mode'),'stype':HzDeCOWGrbpsdNXEaASiocftFRlMJK.get('stype')}
    HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel='',img='',infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMPV,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPh,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
   if HzDeCOWGrbpsdNXEaASiocftFRlMPB(HzDeCOWGrbpsdNXEaASiocftFRlMqy)>0:xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle)
  else:
   HzDeCOWGrbpsdNXEaASiocftFRlMvY=HzDeCOWGrbpsdNXEaASiocftFRlMqu.Load_List_File(HzDeCOWGrbpsdNXEaASiocftFRlMJx)
   for HzDeCOWGrbpsdNXEaASiocftFRlMvB in HzDeCOWGrbpsdNXEaASiocftFRlMvY:
    HzDeCOWGrbpsdNXEaASiocftFRlMyL=HzDeCOWGrbpsdNXEaASiocftFRlMPY(urllib.parse.parse_qsl(HzDeCOWGrbpsdNXEaASiocftFRlMvB))
    HzDeCOWGrbpsdNXEaASiocftFRlMvL =HzDeCOWGrbpsdNXEaASiocftFRlMyL.get('code').strip()
    HzDeCOWGrbpsdNXEaASiocftFRlMgV =HzDeCOWGrbpsdNXEaASiocftFRlMyL.get('title').strip()
    HzDeCOWGrbpsdNXEaASiocftFRlMJQ=HzDeCOWGrbpsdNXEaASiocftFRlMyL.get('img').strip()
    HzDeCOWGrbpsdNXEaASiocftFRlMyP =HzDeCOWGrbpsdNXEaASiocftFRlMyL.get('videoid').strip()
    try:
     HzDeCOWGrbpsdNXEaASiocftFRlMJQ=HzDeCOWGrbpsdNXEaASiocftFRlMJQ.replace('\'','\"')
     HzDeCOWGrbpsdNXEaASiocftFRlMJQ=json.loads(HzDeCOWGrbpsdNXEaASiocftFRlMJQ)
    except:
     HzDeCOWGrbpsdNXEaASiocftFRlMPV
    HzDeCOWGrbpsdNXEaASiocftFRlMIv={}
    HzDeCOWGrbpsdNXEaASiocftFRlMIv['plot']=HzDeCOWGrbpsdNXEaASiocftFRlMgV
    if HzDeCOWGrbpsdNXEaASiocftFRlMJx=='vod':
     if HzDeCOWGrbpsdNXEaASiocftFRlMgx==HzDeCOWGrbpsdNXEaASiocftFRlMPT or HzDeCOWGrbpsdNXEaASiocftFRlMyP==HzDeCOWGrbpsdNXEaASiocftFRlMPV:
      HzDeCOWGrbpsdNXEaASiocftFRlMIv['mediatype']='tvshow'
      HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'EPISODE','programcode':HzDeCOWGrbpsdNXEaASiocftFRlMvL,'page':'1'}
      HzDeCOWGrbpsdNXEaASiocftFRlMgm=HzDeCOWGrbpsdNXEaASiocftFRlMPh
     else:
      HzDeCOWGrbpsdNXEaASiocftFRlMIv['mediatype']='episode'
      HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'VOD','mediacode':HzDeCOWGrbpsdNXEaASiocftFRlMyP,'stype':'vod','programcode':HzDeCOWGrbpsdNXEaASiocftFRlMvL,'title':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'thumbnail':HzDeCOWGrbpsdNXEaASiocftFRlMJQ}
      HzDeCOWGrbpsdNXEaASiocftFRlMgm=HzDeCOWGrbpsdNXEaASiocftFRlMPT
    else:
     HzDeCOWGrbpsdNXEaASiocftFRlMIv['mediatype']='movie'
     HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'MOVIE','mediacode':HzDeCOWGrbpsdNXEaASiocftFRlMvL,'stype':'movie','title':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'thumbnail':HzDeCOWGrbpsdNXEaASiocftFRlMJQ}
     HzDeCOWGrbpsdNXEaASiocftFRlMgm=HzDeCOWGrbpsdNXEaASiocftFRlMPT
    HzDeCOWGrbpsdNXEaASiocftFRlMvq={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':HzDeCOWGrbpsdNXEaASiocftFRlMvL,'vType':HzDeCOWGrbpsdNXEaASiocftFRlMJx,}
    HzDeCOWGrbpsdNXEaASiocftFRlMvg=urllib.parse.urlencode(HzDeCOWGrbpsdNXEaASiocftFRlMvq)
    HzDeCOWGrbpsdNXEaASiocftFRlMIw=[('선택된 시청이력 ( %s ) 삭제'%(HzDeCOWGrbpsdNXEaASiocftFRlMgV),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(HzDeCOWGrbpsdNXEaASiocftFRlMvg))]
    HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel='',img=HzDeCOWGrbpsdNXEaASiocftFRlMJQ,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMIv,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMgm,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL,ContextMenu=HzDeCOWGrbpsdNXEaASiocftFRlMIw)
   HzDeCOWGrbpsdNXEaASiocftFRlMIv={'plot':'시청목록을 삭제합니다.'}
   HzDeCOWGrbpsdNXEaASiocftFRlMgV='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':HzDeCOWGrbpsdNXEaASiocftFRlMJx,}
   HzDeCOWGrbpsdNXEaASiocftFRlMgB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel='',img=HzDeCOWGrbpsdNXEaASiocftFRlMgB,infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMIv,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPT,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL,isLink=HzDeCOWGrbpsdNXEaASiocftFRlMPh)
   if HzDeCOWGrbpsdNXEaASiocftFRlMJx=='movie':xbmcplugin.setContent(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,'movies')
   else:xbmcplugin.setContent(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,cacheToDisc=HzDeCOWGrbpsdNXEaASiocftFRlMPT)
 def Save_Searched_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMyj):
  try:
   HzDeCOWGrbpsdNXEaASiocftFRlMvm=HzDeCOWGrbpsdNXEaASiocftFRlMqx
   HzDeCOWGrbpsdNXEaASiocftFRlMvn=HzDeCOWGrbpsdNXEaASiocftFRlMqu.Load_List_File('search') 
   HzDeCOWGrbpsdNXEaASiocftFRlMUq={'skey':HzDeCOWGrbpsdNXEaASiocftFRlMyj.strip()}
   fp=HzDeCOWGrbpsdNXEaASiocftFRlMkq(HzDeCOWGrbpsdNXEaASiocftFRlMvm,'w',-1,'utf-8')
   HzDeCOWGrbpsdNXEaASiocftFRlMvw=urllib.parse.urlencode(HzDeCOWGrbpsdNXEaASiocftFRlMUq)
   HzDeCOWGrbpsdNXEaASiocftFRlMvw=HzDeCOWGrbpsdNXEaASiocftFRlMvw+'\n'
   fp.write(HzDeCOWGrbpsdNXEaASiocftFRlMvw)
   HzDeCOWGrbpsdNXEaASiocftFRlMvh=0
   for HzDeCOWGrbpsdNXEaASiocftFRlMvx in HzDeCOWGrbpsdNXEaASiocftFRlMvn:
    HzDeCOWGrbpsdNXEaASiocftFRlMvu=HzDeCOWGrbpsdNXEaASiocftFRlMPY(urllib.parse.parse_qsl(HzDeCOWGrbpsdNXEaASiocftFRlMvx))
    HzDeCOWGrbpsdNXEaASiocftFRlMvT=HzDeCOWGrbpsdNXEaASiocftFRlMUq.get('skey').strip()
    HzDeCOWGrbpsdNXEaASiocftFRlMvQ=HzDeCOWGrbpsdNXEaASiocftFRlMvu.get('skey').strip()
    if HzDeCOWGrbpsdNXEaASiocftFRlMvT!=HzDeCOWGrbpsdNXEaASiocftFRlMvQ:
     fp.write(HzDeCOWGrbpsdNXEaASiocftFRlMvx)
     HzDeCOWGrbpsdNXEaASiocftFRlMvh+=1
     if HzDeCOWGrbpsdNXEaASiocftFRlMvh>=50:break
   fp.close()
  except:
   HzDeCOWGrbpsdNXEaASiocftFRlMPV
 def play_VIDEO(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMUg =HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('mediacode')
  HzDeCOWGrbpsdNXEaASiocftFRlMJx =HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('stype')
  HzDeCOWGrbpsdNXEaASiocftFRlMUJ =HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('pvrmode')
  HzDeCOWGrbpsdNXEaASiocftFRlMUI=HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_selQuality(HzDeCOWGrbpsdNXEaASiocftFRlMJx)
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(HzDeCOWGrbpsdNXEaASiocftFRlMUg,HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMUI),HzDeCOWGrbpsdNXEaASiocftFRlMJx,HzDeCOWGrbpsdNXEaASiocftFRlMUJ))
  HzDeCOWGrbpsdNXEaASiocftFRlMUy=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.GetBroadURL(HzDeCOWGrbpsdNXEaASiocftFRlMUg,HzDeCOWGrbpsdNXEaASiocftFRlMUI,HzDeCOWGrbpsdNXEaASiocftFRlMJx,HzDeCOWGrbpsdNXEaASiocftFRlMUJ,optUHD=HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_uhd())
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.addon_log('qt, stype, url : %s - %s - %s'%(HzDeCOWGrbpsdNXEaASiocftFRlMPL(HzDeCOWGrbpsdNXEaASiocftFRlMUI),HzDeCOWGrbpsdNXEaASiocftFRlMJx,HzDeCOWGrbpsdNXEaASiocftFRlMUy['streaming_url']))
  if HzDeCOWGrbpsdNXEaASiocftFRlMUy['streaming_url']=='':
   if HzDeCOWGrbpsdNXEaASiocftFRlMUy['error_msg']=='':
    HzDeCOWGrbpsdNXEaASiocftFRlMqu.addon_noti(__language__(30908).encode('utf8'))
   else:
    HzDeCOWGrbpsdNXEaASiocftFRlMqu.addon_noti(HzDeCOWGrbpsdNXEaASiocftFRlMUy['error_msg'].encode('utf8'))
   return
  HzDeCOWGrbpsdNXEaASiocftFRlMUv='user-agent={}'.format(HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.USER_AGENT)
  if HzDeCOWGrbpsdNXEaASiocftFRlMUy['watermark'] !='':
   HzDeCOWGrbpsdNXEaASiocftFRlMUv='{}&x-tving-param1={}&x-tving-param2={}'.format(HzDeCOWGrbpsdNXEaASiocftFRlMUv,HzDeCOWGrbpsdNXEaASiocftFRlMUy['watermarkKey'],HzDeCOWGrbpsdNXEaASiocftFRlMUy['watermark'])
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.addon_log('streaming_url = {}'.format(HzDeCOWGrbpsdNXEaASiocftFRlMUy['streaming_url']))
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.addon_log('watermark     = {}'.format(HzDeCOWGrbpsdNXEaASiocftFRlMUy['watermark']))
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.addon_log('watermarkKey  = {}'.format(HzDeCOWGrbpsdNXEaASiocftFRlMUy['watermarkKey']))
  HzDeCOWGrbpsdNXEaASiocftFRlMUP =HzDeCOWGrbpsdNXEaASiocftFRlMPT
  HzDeCOWGrbpsdNXEaASiocftFRlMUk =HzDeCOWGrbpsdNXEaASiocftFRlMUy['streaming_url'].find('Policy=')
  if HzDeCOWGrbpsdNXEaASiocftFRlMUk!=-1:
   HzDeCOWGrbpsdNXEaASiocftFRlMUn =HzDeCOWGrbpsdNXEaASiocftFRlMUy['streaming_url'].split('?')[0]
   HzDeCOWGrbpsdNXEaASiocftFRlMUx=HzDeCOWGrbpsdNXEaASiocftFRlMPY(urllib.parse.parse_qsl(urllib.parse.urlsplit(HzDeCOWGrbpsdNXEaASiocftFRlMUy['streaming_url']).query))
   HzDeCOWGrbpsdNXEaASiocftFRlMUu='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(HzDeCOWGrbpsdNXEaASiocftFRlMUx['Policy'],HzDeCOWGrbpsdNXEaASiocftFRlMUx['Signature'],HzDeCOWGrbpsdNXEaASiocftFRlMUx['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in HzDeCOWGrbpsdNXEaASiocftFRlMUn:
    HzDeCOWGrbpsdNXEaASiocftFRlMUP=HzDeCOWGrbpsdNXEaASiocftFRlMPh
    HzDeCOWGrbpsdNXEaASiocftFRlMUK =HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    HzDeCOWGrbpsdNXEaASiocftFRlMUj=HzDeCOWGrbpsdNXEaASiocftFRlMUK.strftime('%Y-%m-%d-%H:%M:%S')
    if HzDeCOWGrbpsdNXEaASiocftFRlMPw(HzDeCOWGrbpsdNXEaASiocftFRlMUj.replace('-','').replace(':',''))<HzDeCOWGrbpsdNXEaASiocftFRlMPw(HzDeCOWGrbpsdNXEaASiocftFRlMUx['end'].replace('-','').replace(':','')):
     HzDeCOWGrbpsdNXEaASiocftFRlMUx['end']=HzDeCOWGrbpsdNXEaASiocftFRlMUj
     HzDeCOWGrbpsdNXEaASiocftFRlMqu.addon_noti(__language__(30915).encode('utf8'))
    HzDeCOWGrbpsdNXEaASiocftFRlMUn ='%s?%s'%(HzDeCOWGrbpsdNXEaASiocftFRlMUn,urllib.parse.urlencode(HzDeCOWGrbpsdNXEaASiocftFRlMUx,doseq=HzDeCOWGrbpsdNXEaASiocftFRlMPh))
    HzDeCOWGrbpsdNXEaASiocftFRlMUV='{}|{}&Cookie={}'.format(HzDeCOWGrbpsdNXEaASiocftFRlMUn,HzDeCOWGrbpsdNXEaASiocftFRlMUv,HzDeCOWGrbpsdNXEaASiocftFRlMUu)
   else:
    HzDeCOWGrbpsdNXEaASiocftFRlMUV='{}|{}&Cookie={}'.format(HzDeCOWGrbpsdNXEaASiocftFRlMUy['streaming_url'],HzDeCOWGrbpsdNXEaASiocftFRlMUv,HzDeCOWGrbpsdNXEaASiocftFRlMUu)
  else:
   HzDeCOWGrbpsdNXEaASiocftFRlMUV=HzDeCOWGrbpsdNXEaASiocftFRlMUy['streaming_url']+'|'+HzDeCOWGrbpsdNXEaASiocftFRlMUv
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.addon_log('if tmp_pos == -1')
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.addon_log(HzDeCOWGrbpsdNXEaASiocftFRlMUV)
  HzDeCOWGrbpsdNXEaASiocftFRlMgI,HzDeCOWGrbpsdNXEaASiocftFRlMgy=HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_proxyport()
  HzDeCOWGrbpsdNXEaASiocftFRlMgJ=HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_playback()
  if HzDeCOWGrbpsdNXEaASiocftFRlMgI and HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('mode')in['VOD','MOVIE']and HzDeCOWGrbpsdNXEaASiocftFRlMUy['drm_license']!='':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.Tving_Parse_mpd(HzDeCOWGrbpsdNXEaASiocftFRlMUy['streaming_url'])
   HzDeCOWGrbpsdNXEaASiocftFRlMUw={'addon':'tvingm','playOption':HzDeCOWGrbpsdNXEaASiocftFRlMgJ,}
   HzDeCOWGrbpsdNXEaASiocftFRlMUw=json.dumps(HzDeCOWGrbpsdNXEaASiocftFRlMUw,separators=(',',':'))
   HzDeCOWGrbpsdNXEaASiocftFRlMUw=base64.standard_b64encode(HzDeCOWGrbpsdNXEaASiocftFRlMUw.encode()).decode('utf-8')
   HzDeCOWGrbpsdNXEaASiocftFRlMUV ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(HzDeCOWGrbpsdNXEaASiocftFRlMgy,HzDeCOWGrbpsdNXEaASiocftFRlMUV,HzDeCOWGrbpsdNXEaASiocftFRlMUw)
   HzDeCOWGrbpsdNXEaASiocftFRlMUv='{}&proxy-mini={}'.format(HzDeCOWGrbpsdNXEaASiocftFRlMUv,HzDeCOWGrbpsdNXEaASiocftFRlMUw)
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.addon_log(HzDeCOWGrbpsdNXEaASiocftFRlMUV)
  HzDeCOWGrbpsdNXEaASiocftFRlMUh=xbmcgui.ListItem(path=HzDeCOWGrbpsdNXEaASiocftFRlMUV)
  if HzDeCOWGrbpsdNXEaASiocftFRlMUy['drm_license']!='':
   HzDeCOWGrbpsdNXEaASiocftFRlMUT=HzDeCOWGrbpsdNXEaASiocftFRlMUy['drm_license']
   HzDeCOWGrbpsdNXEaASiocftFRlMUQ ='https://cj.drmkeyserver.com/widevine_license'
   HzDeCOWGrbpsdNXEaASiocftFRlMUY ='mpd'
   HzDeCOWGrbpsdNXEaASiocftFRlMUB ='com.widevine.alpha'
   HzDeCOWGrbpsdNXEaASiocftFRlMUL =inputstreamhelper.Helper(HzDeCOWGrbpsdNXEaASiocftFRlMUY,drm='widevine')
   if HzDeCOWGrbpsdNXEaASiocftFRlMUL.check_inputstream():
    HzDeCOWGrbpsdNXEaASiocftFRlMUm={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.USER_AGENT,'AcquireLicenseAssertion':HzDeCOWGrbpsdNXEaASiocftFRlMUT,'Host':'cj.drmkeyserver.com',}
    HzDeCOWGrbpsdNXEaASiocftFRlMPq=HzDeCOWGrbpsdNXEaASiocftFRlMUQ+'|'+urllib.parse.urlencode(HzDeCOWGrbpsdNXEaASiocftFRlMUm)+'|R{SSM}|'
    HzDeCOWGrbpsdNXEaASiocftFRlMUh.setProperty('inputstream',HzDeCOWGrbpsdNXEaASiocftFRlMUL.inputstream_addon)
    HzDeCOWGrbpsdNXEaASiocftFRlMUh.setProperty('inputstream.adaptive.manifest_type',HzDeCOWGrbpsdNXEaASiocftFRlMUY)
    HzDeCOWGrbpsdNXEaASiocftFRlMUh.setProperty('inputstream.adaptive.license_type',HzDeCOWGrbpsdNXEaASiocftFRlMUB)
    HzDeCOWGrbpsdNXEaASiocftFRlMUh.setProperty('inputstream.adaptive.license_key',HzDeCOWGrbpsdNXEaASiocftFRlMPq)
    HzDeCOWGrbpsdNXEaASiocftFRlMUh.setProperty('inputstream.adaptive.stream_headers',HzDeCOWGrbpsdNXEaASiocftFRlMUv)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMUP==HzDeCOWGrbpsdNXEaASiocftFRlMPh:
   HzDeCOWGrbpsdNXEaASiocftFRlMUh.setContentLookup(HzDeCOWGrbpsdNXEaASiocftFRlMPT)
   HzDeCOWGrbpsdNXEaASiocftFRlMUh.setMimeType('application/x-mpegURL')
   HzDeCOWGrbpsdNXEaASiocftFRlMUh.setProperty('inputstream','inputstream.ffmpegdirect')
   HzDeCOWGrbpsdNXEaASiocftFRlMUh.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   HzDeCOWGrbpsdNXEaASiocftFRlMUh.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   HzDeCOWGrbpsdNXEaASiocftFRlMUh.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   HzDeCOWGrbpsdNXEaASiocftFRlMUh.setProperty('ResumeTime','0')
   HzDeCOWGrbpsdNXEaASiocftFRlMUh.setProperty('TotalTime','10000')
  elif HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('mode')in['VOD','MOVIE']:
   HzDeCOWGrbpsdNXEaASiocftFRlMUh.setContentLookup(HzDeCOWGrbpsdNXEaASiocftFRlMPT)
   HzDeCOWGrbpsdNXEaASiocftFRlMUh.setMimeType('application/x-mpegURL')
   HzDeCOWGrbpsdNXEaASiocftFRlMUh.setProperty('inputstream','inputstream.adaptive')
   HzDeCOWGrbpsdNXEaASiocftFRlMUh.setProperty('inputstream.adaptive.manifest_type','hls')
  xbmcplugin.setResolvedUrl(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,HzDeCOWGrbpsdNXEaASiocftFRlMPh,HzDeCOWGrbpsdNXEaASiocftFRlMUh)
  try:
   if HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('mode')in['VOD','MOVIE']and HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('title'):
    HzDeCOWGrbpsdNXEaASiocftFRlMgL={'code':HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('programcode')if HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('mode')=='VOD' else HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('mediacode'),'img':HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('thumbnail'),'title':HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('title'),'videoid':HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('mediacode')}
    HzDeCOWGrbpsdNXEaASiocftFRlMqu.Save_Watched_List(HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('stype'),HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  except:
   HzDeCOWGrbpsdNXEaASiocftFRlMPV
 def logout(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  HzDeCOWGrbpsdNXEaASiocftFRlMqh=xbmcgui.Dialog()
  HzDeCOWGrbpsdNXEaASiocftFRlMJP=HzDeCOWGrbpsdNXEaASiocftFRlMqh.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if HzDeCOWGrbpsdNXEaASiocftFRlMJP==HzDeCOWGrbpsdNXEaASiocftFRlMPT:sys.exit()
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.Init_TV_Total()
  if os.path.isfile(HzDeCOWGrbpsdNXEaASiocftFRlMqn):os.remove(HzDeCOWGrbpsdNXEaASiocftFRlMqn)
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  HzDeCOWGrbpsdNXEaASiocftFRlMPg =HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.Get_Now_Datetime()
  HzDeCOWGrbpsdNXEaASiocftFRlMPJ=HzDeCOWGrbpsdNXEaASiocftFRlMPg+datetime.timedelta(days=HzDeCOWGrbpsdNXEaASiocftFRlMPw(__addon__.getSetting('cache_ttl')))
  (HzDeCOWGrbpsdNXEaASiocftFRlMJI,HzDeCOWGrbpsdNXEaASiocftFRlMJy,HzDeCOWGrbpsdNXEaASiocftFRlMJv,HzDeCOWGrbpsdNXEaASiocftFRlMJU)=HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_account()
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.Save_session_acount(HzDeCOWGrbpsdNXEaASiocftFRlMJI,HzDeCOWGrbpsdNXEaASiocftFRlMJy,HzDeCOWGrbpsdNXEaASiocftFRlMJv,HzDeCOWGrbpsdNXEaASiocftFRlMJU)
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.TV['account']['token_limit']=HzDeCOWGrbpsdNXEaASiocftFRlMPJ.strftime('%Y%m%d')
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.JsonFile_Save(HzDeCOWGrbpsdNXEaASiocftFRlMqn,HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.TV)
 def cookiefile_check(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.TV=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.JsonFile_Load(HzDeCOWGrbpsdNXEaASiocftFRlMqn)
  if 'account' not in HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.TV:
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.Init_TV_Total()
   return HzDeCOWGrbpsdNXEaASiocftFRlMPT
  (HzDeCOWGrbpsdNXEaASiocftFRlMPI,HzDeCOWGrbpsdNXEaASiocftFRlMPy,HzDeCOWGrbpsdNXEaASiocftFRlMPv,HzDeCOWGrbpsdNXEaASiocftFRlMPU)=HzDeCOWGrbpsdNXEaASiocftFRlMqu.get_settings_account()
  (HzDeCOWGrbpsdNXEaASiocftFRlMPk,HzDeCOWGrbpsdNXEaASiocftFRlMPn,HzDeCOWGrbpsdNXEaASiocftFRlMPx,HzDeCOWGrbpsdNXEaASiocftFRlMPu)=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.Load_session_acount()
  if HzDeCOWGrbpsdNXEaASiocftFRlMPI!=HzDeCOWGrbpsdNXEaASiocftFRlMPk or HzDeCOWGrbpsdNXEaASiocftFRlMPy!=HzDeCOWGrbpsdNXEaASiocftFRlMPn or HzDeCOWGrbpsdNXEaASiocftFRlMPv!=HzDeCOWGrbpsdNXEaASiocftFRlMPx or HzDeCOWGrbpsdNXEaASiocftFRlMPU!=HzDeCOWGrbpsdNXEaASiocftFRlMPu:
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.Init_TV_Total()
   return HzDeCOWGrbpsdNXEaASiocftFRlMPT
  if HzDeCOWGrbpsdNXEaASiocftFRlMPw(HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>HzDeCOWGrbpsdNXEaASiocftFRlMPw(HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.TV['account']['token_limit']):
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.Init_TV_Total()
   return HzDeCOWGrbpsdNXEaASiocftFRlMPT
  return HzDeCOWGrbpsdNXEaASiocftFRlMPh
 def dp_Global_Search(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMyV=HzDeCOWGrbpsdNXEaASiocftFRlMJj.get('mode')
  if HzDeCOWGrbpsdNXEaASiocftFRlMyV=='TOTAL_SEARCH':
   HzDeCOWGrbpsdNXEaASiocftFRlMPK='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   HzDeCOWGrbpsdNXEaASiocftFRlMPK='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(HzDeCOWGrbpsdNXEaASiocftFRlMPK)
 def dp_Bookmark_Menu(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMPK='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(HzDeCOWGrbpsdNXEaASiocftFRlMPK)
 def dp_EuroLive_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu,HzDeCOWGrbpsdNXEaASiocftFRlMJj):
  HzDeCOWGrbpsdNXEaASiocftFRlMJw=HzDeCOWGrbpsdNXEaASiocftFRlMqu.TvingObj.GetEuroChannelList()
  for HzDeCOWGrbpsdNXEaASiocftFRlMJT in HzDeCOWGrbpsdNXEaASiocftFRlMJw:
   HzDeCOWGrbpsdNXEaASiocftFRlMIu =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('channel')
   HzDeCOWGrbpsdNXEaASiocftFRlMgV =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('title')
   HzDeCOWGrbpsdNXEaASiocftFRlMIU =HzDeCOWGrbpsdNXEaASiocftFRlMJT.get('subtitle')
   HzDeCOWGrbpsdNXEaASiocftFRlMIv={'mediatype':'episode','title':HzDeCOWGrbpsdNXEaASiocftFRlMgV,'plot':'%s\n%s'%(HzDeCOWGrbpsdNXEaASiocftFRlMgV,HzDeCOWGrbpsdNXEaASiocftFRlMIU)}
   HzDeCOWGrbpsdNXEaASiocftFRlMgL={'mode':'LIVE','mediacode':HzDeCOWGrbpsdNXEaASiocftFRlMIu,'stype':'onair',}
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.add_dir(HzDeCOWGrbpsdNXEaASiocftFRlMgV,sublabel=HzDeCOWGrbpsdNXEaASiocftFRlMIU,img='',infoLabels=HzDeCOWGrbpsdNXEaASiocftFRlMIv,isFolder=HzDeCOWGrbpsdNXEaASiocftFRlMPT,params=HzDeCOWGrbpsdNXEaASiocftFRlMgL)
  if HzDeCOWGrbpsdNXEaASiocftFRlMPB(HzDeCOWGrbpsdNXEaASiocftFRlMJw)>0:xbmcplugin.endOfDirectory(HzDeCOWGrbpsdNXEaASiocftFRlMqu._addon_handle,cacheToDisc=HzDeCOWGrbpsdNXEaASiocftFRlMPT)
 def tving_main(HzDeCOWGrbpsdNXEaASiocftFRlMqu):
  HzDeCOWGrbpsdNXEaASiocftFRlMyV=HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params.get('mode',HzDeCOWGrbpsdNXEaASiocftFRlMPV)
  if HzDeCOWGrbpsdNXEaASiocftFRlMyV=='LOGOUT':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.logout()
   return
  HzDeCOWGrbpsdNXEaASiocftFRlMqu.login_main()
  if HzDeCOWGrbpsdNXEaASiocftFRlMyV is HzDeCOWGrbpsdNXEaASiocftFRlMPV:
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_Main_List()
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_Title_Group(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV in['GLOBAL_GROUP']:
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_SubTitle_Group(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='CHANNEL':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_LiveChannel_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV in['LIVE','VOD','MOVIE']:
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.play_VIDEO(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='PROGRAM':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_Program_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='4K_PROGRAM':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_4K_Program_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='ORI_PROGRAM':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_Ori_Program_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='EPISODE':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_Episode_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='MOVIE_SUB':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_Movie_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='4K_MOVIE':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_4K_Movie_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='SEARCH_GROUP':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_Search_Group(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV in['SEARCH','LOCAL_SEARCH']:
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_Search_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='WATCH':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_Watch_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_History_Remove(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='ORDER_BY':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_setEpOrderby(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='SET_BOOKMARK':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_Set_Bookmark(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV in['TOTAL_SEARCH','TOTAL_HISTORY']:
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_Global_Search(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='SEARCH_HISTORY':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_Search_History(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='MENU_BOOKMARK':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_Bookmark_Menu(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  elif HzDeCOWGrbpsdNXEaASiocftFRlMyV=='EURO_GROUP':
   HzDeCOWGrbpsdNXEaASiocftFRlMqu.dp_EuroLive_List(HzDeCOWGrbpsdNXEaASiocftFRlMqu.main_params)
  else:
   HzDeCOWGrbpsdNXEaASiocftFRlMPV
# Created by pyminifier (https://github.com/liftoff/pyminifier)
