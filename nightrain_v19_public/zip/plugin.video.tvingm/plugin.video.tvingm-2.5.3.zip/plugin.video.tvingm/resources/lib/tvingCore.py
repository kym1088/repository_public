__author__="NightRain"
VyLJMTENbukgYcxKnlwFpSIDmjtCiq=print
VyLJMTENbukgYcxKnlwFpSIDmjtCiR=ImportError
VyLJMTENbukgYcxKnlwFpSIDmjtCBa=object
VyLJMTENbukgYcxKnlwFpSIDmjtCBU=None
VyLJMTENbukgYcxKnlwFpSIDmjtCBf=False
VyLJMTENbukgYcxKnlwFpSIDmjtCBW=open
VyLJMTENbukgYcxKnlwFpSIDmjtCBX=True
VyLJMTENbukgYcxKnlwFpSIDmjtCBi=int
VyLJMTENbukgYcxKnlwFpSIDmjtCBz=range
VyLJMTENbukgYcxKnlwFpSIDmjtCBG=Exception
VyLJMTENbukgYcxKnlwFpSIDmjtCBA=len
VyLJMTENbukgYcxKnlwFpSIDmjtCBr=str
VyLJMTENbukgYcxKnlwFpSIDmjtCBs=dict
VyLJMTENbukgYcxKnlwFpSIDmjtCBO=list
VyLJMTENbukgYcxKnlwFpSIDmjtCBh=bytes
VyLJMTENbukgYcxKnlwFpSIDmjtCBv=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 VyLJMTENbukgYcxKnlwFpSIDmjtCiq('Cryptodome')
except VyLJMTENbukgYcxKnlwFpSIDmjtCiR:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 VyLJMTENbukgYcxKnlwFpSIDmjtCiq('Crypto')
VyLJMTENbukgYcxKnlwFpSIDmjtCaf={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
VyLJMTENbukgYcxKnlwFpSIDmjtCaW ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class VyLJMTENbukgYcxKnlwFpSIDmjtCaU(VyLJMTENbukgYcxKnlwFpSIDmjtCBa):
 def __init__(VyLJMTENbukgYcxKnlwFpSIDmjtCaX):
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.NETWORKCODE ='CSND0900'
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.OSCODE ='CSOD0900' 
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TELECODE ='CSCD0900'
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.SCREENCODE ='CSSD0100'
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.SCREENCODE_ATV ='CSSD1300' 
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.LIVE_LIMIT =20 
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.VOD_LIMIT =24 
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.EPISODE_LIMIT =30 
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.SEARCH_LIMIT =30 
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.MOVIE_LIMIT =24 
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN ='https://api.tving.com'
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN ='https://image.tving.com'
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.SEARCH_DOMAIN ='https://search.tving.com'
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.LOGIN_DOMAIN ='https://user.tving.com'
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.URL_DOMAIN ='https://www.tving.com'
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.MOVIE_LITE =['2610061','2610161','261062']
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.DEFAULT_HEADER ={'user-agent':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.USER_AGENT}
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV_SESSION_COOKIES1=''
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV_SESSION_COOKIES2=''
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV_STREAM_FILENAME =''
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV ={}
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.Init_TV_Total()
 def Init_TV_Total(VyLJMTENbukgYcxKnlwFpSIDmjtCaX):
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N','tving_authToken':'',},}
 def callRequestCookies(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,jobtype,VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,redirects=VyLJMTENbukgYcxKnlwFpSIDmjtCBf):
  VyLJMTENbukgYcxKnlwFpSIDmjtCai=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.DEFAULT_HEADER
  if headers:VyLJMTENbukgYcxKnlwFpSIDmjtCai.update(headers)
  if jobtype=='Get':
   VyLJMTENbukgYcxKnlwFpSIDmjtCaB=requests.get(VyLJMTENbukgYcxKnlwFpSIDmjtCUR,params=params,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCai,cookies=cookies,allow_redirects=redirects)
  else:
   VyLJMTENbukgYcxKnlwFpSIDmjtCaB=requests.post(VyLJMTENbukgYcxKnlwFpSIDmjtCUR,data=payload,params=params,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCai,cookies=cookies,allow_redirects=redirects)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCaB
 def JsonFile_Save(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,filename,VyLJMTENbukgYcxKnlwFpSIDmjtCaz):
  if filename=='':return VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  try:
   fp=VyLJMTENbukgYcxKnlwFpSIDmjtCBW(filename,'w',-1,'utf-8')
   json.dump(VyLJMTENbukgYcxKnlwFpSIDmjtCaz,fp,indent=4,ensure_ascii=VyLJMTENbukgYcxKnlwFpSIDmjtCBf)
   fp.close()
  except:
   return VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  return VyLJMTENbukgYcxKnlwFpSIDmjtCBX
 def JsonFile_Load(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,filename):
  if filename=='':return{}
  try:
   fp=VyLJMTENbukgYcxKnlwFpSIDmjtCBW(filename,'r',-1,'utf-8')
   VyLJMTENbukgYcxKnlwFpSIDmjtCaA=json.load(fp)
   fp.close()
  except:
   return{}
  return VyLJMTENbukgYcxKnlwFpSIDmjtCaA
 def TextFile_Save(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,filename,resText):
  if filename=='':return VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  try:
   fp=VyLJMTENbukgYcxKnlwFpSIDmjtCBW(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  return VyLJMTENbukgYcxKnlwFpSIDmjtCBX
 def Save_session_acount(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,VyLJMTENbukgYcxKnlwFpSIDmjtCar,VyLJMTENbukgYcxKnlwFpSIDmjtCas,VyLJMTENbukgYcxKnlwFpSIDmjtCaO,VyLJMTENbukgYcxKnlwFpSIDmjtCah):
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['account']['tvid'] =base64.standard_b64encode(VyLJMTENbukgYcxKnlwFpSIDmjtCar.encode()).decode('utf-8')
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['account']['tvpw'] =base64.standard_b64encode(VyLJMTENbukgYcxKnlwFpSIDmjtCas.encode()).decode('utf-8')
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['account']['tvtype']=VyLJMTENbukgYcxKnlwFpSIDmjtCaO 
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['account']['tvpf'] =VyLJMTENbukgYcxKnlwFpSIDmjtCah 
 def Load_session_acount(VyLJMTENbukgYcxKnlwFpSIDmjtCaX):
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCar =base64.standard_b64decode(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['account']['tvid']).decode('utf-8')
   VyLJMTENbukgYcxKnlwFpSIDmjtCas =base64.standard_b64decode(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['account']['tvpw']).decode('utf-8')
   VyLJMTENbukgYcxKnlwFpSIDmjtCaO=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['account']['tvtype']
   VyLJMTENbukgYcxKnlwFpSIDmjtCah =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return VyLJMTENbukgYcxKnlwFpSIDmjtCar,VyLJMTENbukgYcxKnlwFpSIDmjtCas,VyLJMTENbukgYcxKnlwFpSIDmjtCaO,VyLJMTENbukgYcxKnlwFpSIDmjtCah
 def makeDefaultCookies(VyLJMTENbukgYcxKnlwFpSIDmjtCaX):
  VyLJMTENbukgYcxKnlwFpSIDmjtCav={}
  if VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_token']:VyLJMTENbukgYcxKnlwFpSIDmjtCav['_tving_token']=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_token']
  if VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_userinfo']:VyLJMTENbukgYcxKnlwFpSIDmjtCav['POC_USERINFO']=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_userinfo']
  if VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_maintoken']:VyLJMTENbukgYcxKnlwFpSIDmjtCav[VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GLOBAL_COOKIENM['tv_maintoken']]=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_maintoken']
  if VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_cookiekey']:VyLJMTENbukgYcxKnlwFpSIDmjtCav[VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GLOBAL_COOKIENM['tv_cookiekey']]=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_cookiekey']
  if VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_lockkey']:VyLJMTENbukgYcxKnlwFpSIDmjtCav[VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GLOBAL_COOKIENM['tv_lockkey']]=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_lockkey']
  if VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_authToken']:VyLJMTENbukgYcxKnlwFpSIDmjtCav['authToken']=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_authToken']
  return VyLJMTENbukgYcxKnlwFpSIDmjtCav
 def makeCookiesStr(VyLJMTENbukgYcxKnlwFpSIDmjtCaX):
  return '_tving_token='+VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_token']+';'+ 'POC_USERINFO='+VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_userinfo']+';'+ VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GLOBAL_COOKIENM['tv_maintoken']+'='+VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_maintoken']+';'+ VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GLOBAL_COOKIENM['tv_cookiekey']+'='+VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_cookiekey']+';'+ VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GLOBAL_COOKIENM['tv_lockkey']+'='+VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_lockkey']
 def getDeviceStr(VyLJMTENbukgYcxKnlwFpSIDmjtCaX):
  VyLJMTENbukgYcxKnlwFpSIDmjtCao=[]
  VyLJMTENbukgYcxKnlwFpSIDmjtCao.append('Windows') 
  VyLJMTENbukgYcxKnlwFpSIDmjtCao.append('Chrome') 
  VyLJMTENbukgYcxKnlwFpSIDmjtCao.append('ko-KR') 
  VyLJMTENbukgYcxKnlwFpSIDmjtCao.append('undefined') 
  VyLJMTENbukgYcxKnlwFpSIDmjtCao.append('24') 
  VyLJMTENbukgYcxKnlwFpSIDmjtCao.append(u'한국 표준시')
  VyLJMTENbukgYcxKnlwFpSIDmjtCao.append('undefined') 
  VyLJMTENbukgYcxKnlwFpSIDmjtCao.append('undefined') 
  VyLJMTENbukgYcxKnlwFpSIDmjtCao.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  VyLJMTENbukgYcxKnlwFpSIDmjtCaH=''
  for VyLJMTENbukgYcxKnlwFpSIDmjtCaQ in VyLJMTENbukgYcxKnlwFpSIDmjtCao:
   VyLJMTENbukgYcxKnlwFpSIDmjtCaH+=VyLJMTENbukgYcxKnlwFpSIDmjtCaQ+'|'
  return VyLJMTENbukgYcxKnlwFpSIDmjtCaH
 def GetDefaultParams(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,uhd=VyLJMTENbukgYcxKnlwFpSIDmjtCBf):
  if uhd==VyLJMTENbukgYcxKnlwFpSIDmjtCBf:
   VyLJMTENbukgYcxKnlwFpSIDmjtCad={'apiKey':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.APIKEY,'networkCode':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.NETWORKCODE,'osCode':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.OSCODE,'teleCode':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TELECODE,'screenCode':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.SCREENCODE,}
  else:
   VyLJMTENbukgYcxKnlwFpSIDmjtCad={'apiKey':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.APIKEY_ATV,'networkCode':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.NETWORKCODE,'osCode':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.OSCODE,'teleCode':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TELECODE,'screenCode':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.SCREENCODE_ATV,}
  return VyLJMTENbukgYcxKnlwFpSIDmjtCad
 def GetNoCache(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,timetype=1):
  if timetype==1:
   return VyLJMTENbukgYcxKnlwFpSIDmjtCBi(time.time())
  else:
   return VyLJMTENbukgYcxKnlwFpSIDmjtCBi(time.time()*1000)
 def GetUniqueid(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,hValue=VyLJMTENbukgYcxKnlwFpSIDmjtCBU):
  if hValue:
   import hashlib
   VyLJMTENbukgYcxKnlwFpSIDmjtCaP=hashlib.sha1()
   VyLJMTENbukgYcxKnlwFpSIDmjtCaP.update(hValue.encode())
   VyLJMTENbukgYcxKnlwFpSIDmjtCae=VyLJMTENbukgYcxKnlwFpSIDmjtCaP.hexdigest()[:8]
  else:
   VyLJMTENbukgYcxKnlwFpSIDmjtCaq=[0 for i in VyLJMTENbukgYcxKnlwFpSIDmjtCBz(256)]
   for i in VyLJMTENbukgYcxKnlwFpSIDmjtCBz(256):
    VyLJMTENbukgYcxKnlwFpSIDmjtCaq[i]='%02x'%(i)
   VyLJMTENbukgYcxKnlwFpSIDmjtCaR=VyLJMTENbukgYcxKnlwFpSIDmjtCBi(4294967295*random.random())|0
   VyLJMTENbukgYcxKnlwFpSIDmjtCae=VyLJMTENbukgYcxKnlwFpSIDmjtCaq[255&VyLJMTENbukgYcxKnlwFpSIDmjtCaR]+VyLJMTENbukgYcxKnlwFpSIDmjtCaq[VyLJMTENbukgYcxKnlwFpSIDmjtCaR>>8&255]+VyLJMTENbukgYcxKnlwFpSIDmjtCaq[VyLJMTENbukgYcxKnlwFpSIDmjtCaR>>16&255]+VyLJMTENbukgYcxKnlwFpSIDmjtCaq[VyLJMTENbukgYcxKnlwFpSIDmjtCaR>>24&255]
  return VyLJMTENbukgYcxKnlwFpSIDmjtCae
 def GetCredential(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,user_id,user_pw,login_type,user_pf):
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUa=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   VyLJMTENbukgYcxKnlwFpSIDmjtCUf={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Post',VyLJMTENbukgYcxKnlwFpSIDmjtCUa,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCUf,params=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU)
   for VyLJMTENbukgYcxKnlwFpSIDmjtCUX in VyLJMTENbukgYcxKnlwFpSIDmjtCUW.cookies:
    if VyLJMTENbukgYcxKnlwFpSIDmjtCUX.name=='_tving_token':
     VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_token']=VyLJMTENbukgYcxKnlwFpSIDmjtCUX.value
    elif VyLJMTENbukgYcxKnlwFpSIDmjtCUX.name=='POC_USERINFO':
     VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_userinfo']=VyLJMTENbukgYcxKnlwFpSIDmjtCUX.value
    elif VyLJMTENbukgYcxKnlwFpSIDmjtCUX.name=='authToken':
     VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_authToken']=VyLJMTENbukgYcxKnlwFpSIDmjtCUX.value
   if not VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_token']:
    VyLJMTENbukgYcxKnlwFpSIDmjtCaX.Init_TV_Total()
    return VyLJMTENbukgYcxKnlwFpSIDmjtCBf
   VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_maintoken']=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_token']
   if VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetProfileToken(user_pf)==VyLJMTENbukgYcxKnlwFpSIDmjtCBf:
    VyLJMTENbukgYcxKnlwFpSIDmjtCaX.Init_TV_Total()
    return VyLJMTENbukgYcxKnlwFpSIDmjtCBf
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies'])
   VyLJMTENbukgYcxKnlwFpSIDmjtCUi =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDeviceList()
   if VyLJMTENbukgYcxKnlwFpSIDmjtCUi not in['','-']:
    VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_uuid']=VyLJMTENbukgYcxKnlwFpSIDmjtCUi+'-'+VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetUniqueid(VyLJMTENbukgYcxKnlwFpSIDmjtCUi)
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
   VyLJMTENbukgYcxKnlwFpSIDmjtCaX.Init_TV_Total()
   return VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  return VyLJMTENbukgYcxKnlwFpSIDmjtCBX
 def GetProfileToken(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,user_pf):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUB=[]
  VyLJMTENbukgYcxKnlwFpSIDmjtCUz =''
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   VyLJMTENbukgYcxKnlwFpSIDmjtCav=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.makeDefaultCookies()
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(VyLJMTENbukgYcxKnlwFpSIDmjtCav)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUG,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCav)
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUB =re.findall('data-profile-no="\d+"',VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(VyLJMTENbukgYcxKnlwFpSIDmjtCUB)
   for i in VyLJMTENbukgYcxKnlwFpSIDmjtCBz(VyLJMTENbukgYcxKnlwFpSIDmjtCBA(VyLJMTENbukgYcxKnlwFpSIDmjtCUB)):
    VyLJMTENbukgYcxKnlwFpSIDmjtCUA =VyLJMTENbukgYcxKnlwFpSIDmjtCUB[i].replace('data-profile-no=','').replace('"','')
    VyLJMTENbukgYcxKnlwFpSIDmjtCUB[i]=VyLJMTENbukgYcxKnlwFpSIDmjtCUA
   VyLJMTENbukgYcxKnlwFpSIDmjtCUz=VyLJMTENbukgYcxKnlwFpSIDmjtCUB[user_pf]
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
   VyLJMTENbukgYcxKnlwFpSIDmjtCaX.Init_TV_Total()
   return VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   VyLJMTENbukgYcxKnlwFpSIDmjtCav=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.makeDefaultCookies()
   VyLJMTENbukgYcxKnlwFpSIDmjtCUf={'profileNo':VyLJMTENbukgYcxKnlwFpSIDmjtCUz}
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Post',VyLJMTENbukgYcxKnlwFpSIDmjtCUG,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCUf,params=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCav)
   for VyLJMTENbukgYcxKnlwFpSIDmjtCUX in VyLJMTENbukgYcxKnlwFpSIDmjtCUW.cookies:
    if VyLJMTENbukgYcxKnlwFpSIDmjtCUX.name=='_tving_token':
     VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_token']=VyLJMTENbukgYcxKnlwFpSIDmjtCUX.value
    elif VyLJMTENbukgYcxKnlwFpSIDmjtCUX.name==VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GLOBAL_COOKIENM['tv_cookiekey']:
     VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_cookiekey']=VyLJMTENbukgYcxKnlwFpSIDmjtCUX.value
    elif VyLJMTENbukgYcxKnlwFpSIDmjtCUX.name==VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GLOBAL_COOKIENM['tv_lockkey']:
     VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_lockkey']=VyLJMTENbukgYcxKnlwFpSIDmjtCUX.value
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
   VyLJMTENbukgYcxKnlwFpSIDmjtCaX.Init_TV_Total()
   return VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  return VyLJMTENbukgYcxKnlwFpSIDmjtCBX
 def GetDeviceList(VyLJMTENbukgYcxKnlwFpSIDmjtCaX):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUr=[]
  VyLJMTENbukgYcxKnlwFpSIDmjtCUs='-'
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v1/user/device/list'
   VyLJMTENbukgYcxKnlwFpSIDmjtCUO=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUG
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   VyLJMTENbukgYcxKnlwFpSIDmjtCav=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.makeDefaultCookies()
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUO,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUh,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCav)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUv=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUr=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']
   for VyLJMTENbukgYcxKnlwFpSIDmjtCUo in VyLJMTENbukgYcxKnlwFpSIDmjtCUr:
    if VyLJMTENbukgYcxKnlwFpSIDmjtCUo['model']=='PC' or VyLJMTENbukgYcxKnlwFpSIDmjtCUo['model']=='PC-Chrome':
     VyLJMTENbukgYcxKnlwFpSIDmjtCUs=VyLJMTENbukgYcxKnlwFpSIDmjtCUo['uuid']
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCUs
 def Get_Now_Datetime(VyLJMTENbukgYcxKnlwFpSIDmjtCaX):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,mediacode,sel_quality,stype,pvrmode='-',optUHD=VyLJMTENbukgYcxKnlwFpSIDmjtCBf):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUQ ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','subtitleYn':VyLJMTENbukgYcxKnlwFpSIDmjtCBf,'error_msg':'',}
  VyLJMTENbukgYcxKnlwFpSIDmjtCUs =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_uuid'].split('-')[0] 
  VyLJMTENbukgYcxKnlwFpSIDmjtCUd =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_uuid'] 
  VyLJMTENbukgYcxKnlwFpSIDmjtCUP=VyLJMTENbukgYcxKnlwFpSIDmjtCBf 
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUe=VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetNoCache(1))
   if stype!='tvingtv':
    VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v2/media/stream/info' 
    VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams()
    VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':VyLJMTENbukgYcxKnlwFpSIDmjtCUd,'deviceInfo':'PC','noCache':VyLJMTENbukgYcxKnlwFpSIDmjtCUe,}
    VyLJMTENbukgYcxKnlwFpSIDmjtCUq.update(VyLJMTENbukgYcxKnlwFpSIDmjtCUh)
    VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUG
    VyLJMTENbukgYcxKnlwFpSIDmjtCav=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.makeDefaultCookies()
    VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUq,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCav)
    if VyLJMTENbukgYcxKnlwFpSIDmjtCUW.status_code!=200:
     VyLJMTENbukgYcxKnlwFpSIDmjtCUQ['error_msg']='First Step - {} error'.format(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.status_code)
     return VyLJMTENbukgYcxKnlwFpSIDmjtCUQ
    VyLJMTENbukgYcxKnlwFpSIDmjtCUv=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
    if VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['result']['code']=='060':
     for VyLJMTENbukgYcxKnlwFpSIDmjtCfa,VyLJMTENbukgYcxKnlwFpSIDmjtCWa in VyLJMTENbukgYcxKnlwFpSIDmjtCaf.items():
      if VyLJMTENbukgYcxKnlwFpSIDmjtCWa==sel_quality:
       VyLJMTENbukgYcxKnlwFpSIDmjtCfU=VyLJMTENbukgYcxKnlwFpSIDmjtCfa
    elif VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['result']['code']!='000':
     VyLJMTENbukgYcxKnlwFpSIDmjtCUQ['error_msg']=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['result']['message']
     return VyLJMTENbukgYcxKnlwFpSIDmjtCUQ
    else: 
     if not('stream' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']):return VyLJMTENbukgYcxKnlwFpSIDmjtCUQ
     VyLJMTENbukgYcxKnlwFpSIDmjtCfW=[]
     for VyLJMTENbukgYcxKnlwFpSIDmjtCfa,VyLJMTENbukgYcxKnlwFpSIDmjtCWa in VyLJMTENbukgYcxKnlwFpSIDmjtCaf.items():
      for VyLJMTENbukgYcxKnlwFpSIDmjtCUo in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['stream']['quality']:
       if VyLJMTENbukgYcxKnlwFpSIDmjtCUo['active']=='Y' and VyLJMTENbukgYcxKnlwFpSIDmjtCUo['code']==VyLJMTENbukgYcxKnlwFpSIDmjtCfa:
        VyLJMTENbukgYcxKnlwFpSIDmjtCfW.append({VyLJMTENbukgYcxKnlwFpSIDmjtCaf.get(VyLJMTENbukgYcxKnlwFpSIDmjtCUo['code']):VyLJMTENbukgYcxKnlwFpSIDmjtCUo['code']})
     VyLJMTENbukgYcxKnlwFpSIDmjtCfU=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.CheckQuality(sel_quality,VyLJMTENbukgYcxKnlwFpSIDmjtCfW)
     try:
      if optUHD==VyLJMTENbukgYcxKnlwFpSIDmjtCBX and VyLJMTENbukgYcxKnlwFpSIDmjtCfU=='stream50' and 'stream_support_info' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['content']['info']:
       if VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['content']['info']['stream_support_info']!=VyLJMTENbukgYcxKnlwFpSIDmjtCBU:
        if 'stream70' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['content']['info']['stream_support_info']:
         VyLJMTENbukgYcxKnlwFpSIDmjtCfU='stream70'
         VyLJMTENbukgYcxKnlwFpSIDmjtCUP =VyLJMTENbukgYcxKnlwFpSIDmjtCBX
     except:
      pass
     try:
      if optUHD==VyLJMTENbukgYcxKnlwFpSIDmjtCBX and VyLJMTENbukgYcxKnlwFpSIDmjtCfU=='stream50' and 'stream' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['content']['info']:
       if VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['content']['info']['stream']!=VyLJMTENbukgYcxKnlwFpSIDmjtCBU:
        for VyLJMTENbukgYcxKnlwFpSIDmjtCUo in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['content']['info']['stream']:
         if VyLJMTENbukgYcxKnlwFpSIDmjtCUo['code']=='stream70':
          VyLJMTENbukgYcxKnlwFpSIDmjtCfU='stream70'
          VyLJMTENbukgYcxKnlwFpSIDmjtCUP =VyLJMTENbukgYcxKnlwFpSIDmjtCBX
          break
     except:
      pass
   else:
    VyLJMTENbukgYcxKnlwFpSIDmjtCfU='stream40'
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUQ['error_msg']='First Step - except error'
   return VyLJMTENbukgYcxKnlwFpSIDmjtCUQ
  VyLJMTENbukgYcxKnlwFpSIDmjtCiq(VyLJMTENbukgYcxKnlwFpSIDmjtCfU)
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUe=VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetNoCache(1))
   VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v2a/media/stream/info'
   if VyLJMTENbukgYcxKnlwFpSIDmjtCUP==VyLJMTENbukgYcxKnlwFpSIDmjtCBX:
    VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams(uhd=VyLJMTENbukgYcxKnlwFpSIDmjtCBX)
    VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'mediaCode':mediacode,'noCache':VyLJMTENbukgYcxKnlwFpSIDmjtCUe,'streamType':'hls','streamCode':VyLJMTENbukgYcxKnlwFpSIDmjtCfU,'deviceId':VyLJMTENbukgYcxKnlwFpSIDmjtCUs,'adReq':'none','wm':'Y','ad_device':'','uuid':VyLJMTENbukgYcxKnlwFpSIDmjtCUd,'deviceInfo':'android_tv',}
   else:
    VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams()
    VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':VyLJMTENbukgYcxKnlwFpSIDmjtCfU,'deviceId':VyLJMTENbukgYcxKnlwFpSIDmjtCUs,'uuid':VyLJMTENbukgYcxKnlwFpSIDmjtCUd,'deviceInfo':'PC_Chrome','noCache':VyLJMTENbukgYcxKnlwFpSIDmjtCUe,'wm':'Y'}
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq.update(VyLJMTENbukgYcxKnlwFpSIDmjtCUh)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUG
   VyLJMTENbukgYcxKnlwFpSIDmjtCav=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.makeDefaultCookies()
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUq,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCav,redirects=VyLJMTENbukgYcxKnlwFpSIDmjtCBf)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUv=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   if VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['result']['code']!='000':
    VyLJMTENbukgYcxKnlwFpSIDmjtCUQ['error_msg']=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['result']['message']
    return VyLJMTENbukgYcxKnlwFpSIDmjtCUQ
   VyLJMTENbukgYcxKnlwFpSIDmjtCfX=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['stream']
   if 'drm_license_assertion' in VyLJMTENbukgYcxKnlwFpSIDmjtCfX:
    VyLJMTENbukgYcxKnlwFpSIDmjtCUQ['drm_license']=VyLJMTENbukgYcxKnlwFpSIDmjtCfX['drm_license_assertion']
    if '4k_nondrm_url' in VyLJMTENbukgYcxKnlwFpSIDmjtCfX['broadcast']and VyLJMTENbukgYcxKnlwFpSIDmjtCUP==VyLJMTENbukgYcxKnlwFpSIDmjtCBX:
     VyLJMTENbukgYcxKnlwFpSIDmjtCfi =VyLJMTENbukgYcxKnlwFpSIDmjtCfX['broadcast']['4k_nondrm_url']
     VyLJMTENbukgYcxKnlwFpSIDmjtCUQ['drm_license']=''
    else:
     VyLJMTENbukgYcxKnlwFpSIDmjtCfi =VyLJMTENbukgYcxKnlwFpSIDmjtCfX['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in VyLJMTENbukgYcxKnlwFpSIDmjtCfX['broadcast']):return VyLJMTENbukgYcxKnlwFpSIDmjtCUQ
    VyLJMTENbukgYcxKnlwFpSIDmjtCfi=VyLJMTENbukgYcxKnlwFpSIDmjtCfX['broadcast']['broad_url']
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUQ['error_msg']='Second Step - except error'
   return VyLJMTENbukgYcxKnlwFpSIDmjtCUQ
  VyLJMTENbukgYcxKnlwFpSIDmjtCfB=VyLJMTENbukgYcxKnlwFpSIDmjtCUe
  VyLJMTENbukgYcxKnlwFpSIDmjtCfi=VyLJMTENbukgYcxKnlwFpSIDmjtCfi.split('|')[1]
  VyLJMTENbukgYcxKnlwFpSIDmjtCfi,VyLJMTENbukgYcxKnlwFpSIDmjtCfz,VyLJMTENbukgYcxKnlwFpSIDmjtCfG=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.Decrypt_Url(VyLJMTENbukgYcxKnlwFpSIDmjtCfi,mediacode,VyLJMTENbukgYcxKnlwFpSIDmjtCfB)
  VyLJMTENbukgYcxKnlwFpSIDmjtCUQ['streaming_url']=VyLJMTENbukgYcxKnlwFpSIDmjtCfi
  VyLJMTENbukgYcxKnlwFpSIDmjtCUQ['watermark'] =VyLJMTENbukgYcxKnlwFpSIDmjtCfz
  VyLJMTENbukgYcxKnlwFpSIDmjtCUQ['watermarkKey']=VyLJMTENbukgYcxKnlwFpSIDmjtCfG
  if 'subtitles' in VyLJMTENbukgYcxKnlwFpSIDmjtCfX:
   for VyLJMTENbukgYcxKnlwFpSIDmjtCfA in VyLJMTENbukgYcxKnlwFpSIDmjtCfX.get('subtitles'):
    if VyLJMTENbukgYcxKnlwFpSIDmjtCfA.get('code')in['KO','KO_CC']:
     VyLJMTENbukgYcxKnlwFpSIDmjtCUQ['subtitleYn']=VyLJMTENbukgYcxKnlwFpSIDmjtCBX
     break
  return VyLJMTENbukgYcxKnlwFpSIDmjtCUQ
 def Tving_Parse_mpd(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,stream_url):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUW=requests.get(url=stream_url)
  VyLJMTENbukgYcxKnlwFpSIDmjtCfr=VyLJMTENbukgYcxKnlwFpSIDmjtCUW.content.decode('utf-8')
  VyLJMTENbukgYcxKnlwFpSIDmjtCfs=0
  VyLJMTENbukgYcxKnlwFpSIDmjtCfO =ET.ElementTree(ET.fromstring(VyLJMTENbukgYcxKnlwFpSIDmjtCfr))
  VyLJMTENbukgYcxKnlwFpSIDmjtCfh =VyLJMTENbukgYcxKnlwFpSIDmjtCfO.getroot()
  VyLJMTENbukgYcxKnlwFpSIDmjtCfv=re.match(r'\{.*\}',VyLJMTENbukgYcxKnlwFpSIDmjtCfh.tag)[0]
  VyLJMTENbukgYcxKnlwFpSIDmjtCfo=VyLJMTENbukgYcxKnlwFpSIDmjtCBs([node for _,node in ET.iterparse(io.StringIO(VyLJMTENbukgYcxKnlwFpSIDmjtCfr),events=['start-ns'])])
  for VyLJMTENbukgYcxKnlwFpSIDmjtCfa,value in VyLJMTENbukgYcxKnlwFpSIDmjtCfo.items():
   ET.register_namespace(VyLJMTENbukgYcxKnlwFpSIDmjtCfa,value)
  VyLJMTENbukgYcxKnlwFpSIDmjtCfH=VyLJMTENbukgYcxKnlwFpSIDmjtCfh.find(VyLJMTENbukgYcxKnlwFpSIDmjtCfv+'Period')
  for VyLJMTENbukgYcxKnlwFpSIDmjtCfQ in VyLJMTENbukgYcxKnlwFpSIDmjtCfH.findall(VyLJMTENbukgYcxKnlwFpSIDmjtCfv+'AdaptationSet'):
   if VyLJMTENbukgYcxKnlwFpSIDmjtCfQ.attrib.get('mimeType')=='video/mp4':
    for VyLJMTENbukgYcxKnlwFpSIDmjtCfd in VyLJMTENbukgYcxKnlwFpSIDmjtCfQ.findall(VyLJMTENbukgYcxKnlwFpSIDmjtCfv+'Representation'):
     VyLJMTENbukgYcxKnlwFpSIDmjtCfP=VyLJMTENbukgYcxKnlwFpSIDmjtCBi(VyLJMTENbukgYcxKnlwFpSIDmjtCfd.attrib.get('bandwidth'))
     if VyLJMTENbukgYcxKnlwFpSIDmjtCfs<VyLJMTENbukgYcxKnlwFpSIDmjtCfP:VyLJMTENbukgYcxKnlwFpSIDmjtCfs=VyLJMTENbukgYcxKnlwFpSIDmjtCfP
    for VyLJMTENbukgYcxKnlwFpSIDmjtCfd in VyLJMTENbukgYcxKnlwFpSIDmjtCfQ.findall(VyLJMTENbukgYcxKnlwFpSIDmjtCfv+'Representation'):
     if VyLJMTENbukgYcxKnlwFpSIDmjtCfs>VyLJMTENbukgYcxKnlwFpSIDmjtCBi(VyLJMTENbukgYcxKnlwFpSIDmjtCfd.attrib.get('bandwidth')):
      VyLJMTENbukgYcxKnlwFpSIDmjtCfQ.remove(VyLJMTENbukgYcxKnlwFpSIDmjtCfd)
   else:
    continue
  VyLJMTENbukgYcxKnlwFpSIDmjtCfe=ET.tostring(VyLJMTENbukgYcxKnlwFpSIDmjtCfh).decode('utf-8')
  VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TextFile_Save(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV_STREAM_FILENAME,VyLJMTENbukgYcxKnlwFpSIDmjtCfe)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCBX
 def CheckQuality(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,sel_qt,VyLJMTENbukgYcxKnlwFpSIDmjtCfW):
  for VyLJMTENbukgYcxKnlwFpSIDmjtCfq in VyLJMTENbukgYcxKnlwFpSIDmjtCfW:
   if sel_qt>=VyLJMTENbukgYcxKnlwFpSIDmjtCBO(VyLJMTENbukgYcxKnlwFpSIDmjtCfq)[0]:return VyLJMTENbukgYcxKnlwFpSIDmjtCfq.get(VyLJMTENbukgYcxKnlwFpSIDmjtCBO(VyLJMTENbukgYcxKnlwFpSIDmjtCfq)[0])
   VyLJMTENbukgYcxKnlwFpSIDmjtCfR=VyLJMTENbukgYcxKnlwFpSIDmjtCfq.get(VyLJMTENbukgYcxKnlwFpSIDmjtCBO(VyLJMTENbukgYcxKnlwFpSIDmjtCfq)[0])
  return VyLJMTENbukgYcxKnlwFpSIDmjtCfR
 def makeOocUrl(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,ooc_params):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUR=''
  for VyLJMTENbukgYcxKnlwFpSIDmjtCfa,VyLJMTENbukgYcxKnlwFpSIDmjtCWa in ooc_params.items():
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR+="%s=%s^"%(VyLJMTENbukgYcxKnlwFpSIDmjtCfa,VyLJMTENbukgYcxKnlwFpSIDmjtCWa)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCUR
 def GetLiveChannelList(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,stype,page_int):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUr=[]
  VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v2/media/lives'
   if stype=='onair': 
    VyLJMTENbukgYcxKnlwFpSIDmjtCWf='CPCS0100,CPCS0400'
   else:
    VyLJMTENbukgYcxKnlwFpSIDmjtCWf='CPCS0300'
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams()
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'cacheType':'main','pageNo':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(page_int),'pageSize':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':VyLJMTENbukgYcxKnlwFpSIDmjtCWf,}
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq.update(VyLJMTENbukgYcxKnlwFpSIDmjtCUh)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUG
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUq,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUv=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   if not('result' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']):return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
   VyLJMTENbukgYcxKnlwFpSIDmjtCWX=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['result']
   for VyLJMTENbukgYcxKnlwFpSIDmjtCUo in VyLJMTENbukgYcxKnlwFpSIDmjtCWX:
    VyLJMTENbukgYcxKnlwFpSIDmjtCWi=VyLJMTENbukgYcxKnlwFpSIDmjtCWG=VyLJMTENbukgYcxKnlwFpSIDmjtCWA=''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWB=VyLJMTENbukgYcxKnlwFpSIDmjtCXW=''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWz=VyLJMTENbukgYcxKnlwFpSIDmjtCUo['live_code']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWi =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['channel']['name']['ko']
    if VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['episode']!=VyLJMTENbukgYcxKnlwFpSIDmjtCBU:
     VyLJMTENbukgYcxKnlwFpSIDmjtCWG =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['program']['name']['ko']
     VyLJMTENbukgYcxKnlwFpSIDmjtCWG =VyLJMTENbukgYcxKnlwFpSIDmjtCWG+', '+VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['episode']['frequency'])+'회'
     VyLJMTENbukgYcxKnlwFpSIDmjtCWA=VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['episode']['synopsis']['ko']
    else:
     VyLJMTENbukgYcxKnlwFpSIDmjtCWG =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['program']['name']['ko']
     VyLJMTENbukgYcxKnlwFpSIDmjtCWA=VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['program']['synopsis']['ko']
    try: 
     VyLJMTENbukgYcxKnlwFpSIDmjtCWr =''
     VyLJMTENbukgYcxKnlwFpSIDmjtCWs =''
     VyLJMTENbukgYcxKnlwFpSIDmjtCWO=''
     VyLJMTENbukgYcxKnlwFpSIDmjtCWh =''
     VyLJMTENbukgYcxKnlwFpSIDmjtCWv =''
     VyLJMTENbukgYcxKnlwFpSIDmjtCWo =''
     for VyLJMTENbukgYcxKnlwFpSIDmjtCWH in VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['program']['image']:
      if VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP0900':VyLJMTENbukgYcxKnlwFpSIDmjtCWs =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
      elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP1800':VyLJMTENbukgYcxKnlwFpSIDmjtCWO=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
      elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP2000':VyLJMTENbukgYcxKnlwFpSIDmjtCWh =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
      elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP1900':VyLJMTENbukgYcxKnlwFpSIDmjtCWv =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
      elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP0200':VyLJMTENbukgYcxKnlwFpSIDmjtCWo =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
      elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP0500':VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
      elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP0800':VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     if VyLJMTENbukgYcxKnlwFpSIDmjtCWr=='':
      for VyLJMTENbukgYcxKnlwFpSIDmjtCWH in VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['channel']['image']:
       if VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIC0400':VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
       elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIC1400':VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
       elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIC1900':VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
    except:
     VyLJMTENbukgYcxKnlwFpSIDmjtCBU
    try:
     VyLJMTENbukgYcxKnlwFpSIDmjtCWQ =[]
     VyLJMTENbukgYcxKnlwFpSIDmjtCWd=[]
     VyLJMTENbukgYcxKnlwFpSIDmjtCWP =[]
     VyLJMTENbukgYcxKnlwFpSIDmjtCWe=''
     VyLJMTENbukgYcxKnlwFpSIDmjtCWq=''
     VyLJMTENbukgYcxKnlwFpSIDmjtCWR=''
     for VyLJMTENbukgYcxKnlwFpSIDmjtCXa in VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('schedule').get('program').get('actor'):
      if VyLJMTENbukgYcxKnlwFpSIDmjtCXa!='' and VyLJMTENbukgYcxKnlwFpSIDmjtCXa!=u'없음':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXa)
     for VyLJMTENbukgYcxKnlwFpSIDmjtCXU in VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('schedule').get('program').get('director'):
      if VyLJMTENbukgYcxKnlwFpSIDmjtCXU!='' and VyLJMTENbukgYcxKnlwFpSIDmjtCXU!='-' and VyLJMTENbukgYcxKnlwFpSIDmjtCXU!=u'없음':VyLJMTENbukgYcxKnlwFpSIDmjtCWd.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXU)
     if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('schedule').get('program').get('category1_name').get('ko')!='':
      VyLJMTENbukgYcxKnlwFpSIDmjtCWP.append(VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['program']['category1_name']['ko'])
     if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('schedule').get('program').get('category2_name').get('ko')!='':
      VyLJMTENbukgYcxKnlwFpSIDmjtCWP.append(VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['program']['category2_name']['ko'])
     if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('schedule').get('program').get('product_year'):VyLJMTENbukgYcxKnlwFpSIDmjtCWe=VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['program']['product_year']
     if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('schedule').get('program').get('grade_code') :VyLJMTENbukgYcxKnlwFpSIDmjtCWq= VyLJMTENbukgYcxKnlwFpSIDmjtCaW.get(VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['program']['grade_code'])
     if 'broad_dt' in VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('schedule').get('program'):
      VyLJMTENbukgYcxKnlwFpSIDmjtCXf =VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('schedule').get('program').get('broad_dt')
      VyLJMTENbukgYcxKnlwFpSIDmjtCWR='%s-%s-%s'%(VyLJMTENbukgYcxKnlwFpSIDmjtCXf[:4],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[4:6],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[6:])
    except:
     VyLJMTENbukgYcxKnlwFpSIDmjtCBU
    VyLJMTENbukgYcxKnlwFpSIDmjtCWB=VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['broadcast_start_time'])[8:12]
    VyLJMTENbukgYcxKnlwFpSIDmjtCXW =VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCUo['schedule']['broadcast_end_time'])[8:12]
    VyLJMTENbukgYcxKnlwFpSIDmjtCXi={'channel':VyLJMTENbukgYcxKnlwFpSIDmjtCWi,'title':VyLJMTENbukgYcxKnlwFpSIDmjtCWG,'mediacode':VyLJMTENbukgYcxKnlwFpSIDmjtCWz,'thumbnail':{'poster':VyLJMTENbukgYcxKnlwFpSIDmjtCWs,'thumb':VyLJMTENbukgYcxKnlwFpSIDmjtCWr,'clearlogo':VyLJMTENbukgYcxKnlwFpSIDmjtCWO,'icon':VyLJMTENbukgYcxKnlwFpSIDmjtCWh,'fanart':VyLJMTENbukgYcxKnlwFpSIDmjtCWo},'synopsis':VyLJMTENbukgYcxKnlwFpSIDmjtCWA,'channelepg':' [%s:%s ~ %s:%s]'%(VyLJMTENbukgYcxKnlwFpSIDmjtCWB[0:2],VyLJMTENbukgYcxKnlwFpSIDmjtCWB[2:],VyLJMTENbukgYcxKnlwFpSIDmjtCXW[0:2],VyLJMTENbukgYcxKnlwFpSIDmjtCXW[2:]),'cast':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ,'director':VyLJMTENbukgYcxKnlwFpSIDmjtCWd,'info_genre':VyLJMTENbukgYcxKnlwFpSIDmjtCWP,'year':VyLJMTENbukgYcxKnlwFpSIDmjtCWe,'mpaa':VyLJMTENbukgYcxKnlwFpSIDmjtCWq,'premiered':VyLJMTENbukgYcxKnlwFpSIDmjtCWR}
    VyLJMTENbukgYcxKnlwFpSIDmjtCUr.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXi)
   if VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['has_more']=='Y':
    VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBX
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
 def GetProgramList(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,genre,orderby,page_int,genreCode='all'):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUr=[]
  VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  try:
   if genre=='PARAMOUNT':
    VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v2/media/paramount/episodes'
   else:
    VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v2/media/episodes'
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams()
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'cacheType':'main','pageSize':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(page_int),}
   if genre not in['all','PARAMOUNT']:VyLJMTENbukgYcxKnlwFpSIDmjtCUh['categoryCode']=genre
   if genreCode!='all' :VyLJMTENbukgYcxKnlwFpSIDmjtCUh['genreCode'] =genreCode 
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq.update(VyLJMTENbukgYcxKnlwFpSIDmjtCUh)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUG
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUq,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUv=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   if not('result' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']):return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
   VyLJMTENbukgYcxKnlwFpSIDmjtCWX=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['result']
   for VyLJMTENbukgYcxKnlwFpSIDmjtCUo in VyLJMTENbukgYcxKnlwFpSIDmjtCWX:
    VyLJMTENbukgYcxKnlwFpSIDmjtCXB=VyLJMTENbukgYcxKnlwFpSIDmjtCUo['program']['code']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWG =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['program']['name']['ko']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWq =VyLJMTENbukgYcxKnlwFpSIDmjtCaW.get(VyLJMTENbukgYcxKnlwFpSIDmjtCUo['program'].get('grade_code'))
    VyLJMTENbukgYcxKnlwFpSIDmjtCWs =''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWr =''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWO=''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWh =''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWv =''
    for VyLJMTENbukgYcxKnlwFpSIDmjtCWH in VyLJMTENbukgYcxKnlwFpSIDmjtCUo['program']['image']:
     if VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP0900':VyLJMTENbukgYcxKnlwFpSIDmjtCWs =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP0200':VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP1800':VyLJMTENbukgYcxKnlwFpSIDmjtCWO=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP2000':VyLJMTENbukgYcxKnlwFpSIDmjtCWh =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP1900':VyLJMTENbukgYcxKnlwFpSIDmjtCWv =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWA =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['program']['synopsis']['ko']
    try:
     VyLJMTENbukgYcxKnlwFpSIDmjtCXz=VyLJMTENbukgYcxKnlwFpSIDmjtCUo['channel']['name']['ko']
    except:
     VyLJMTENbukgYcxKnlwFpSIDmjtCXz=''
    try:
     VyLJMTENbukgYcxKnlwFpSIDmjtCWQ =[]
     VyLJMTENbukgYcxKnlwFpSIDmjtCWd=[]
     VyLJMTENbukgYcxKnlwFpSIDmjtCWP =[]
     VyLJMTENbukgYcxKnlwFpSIDmjtCWe =''
     VyLJMTENbukgYcxKnlwFpSIDmjtCWR=''
     for VyLJMTENbukgYcxKnlwFpSIDmjtCXa in VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('program').get('actor'):
      if VyLJMTENbukgYcxKnlwFpSIDmjtCXa!='' and VyLJMTENbukgYcxKnlwFpSIDmjtCXa!='-' and VyLJMTENbukgYcxKnlwFpSIDmjtCXa!=u'없음':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXa)
     for VyLJMTENbukgYcxKnlwFpSIDmjtCXU in VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('program').get('director'):
      if VyLJMTENbukgYcxKnlwFpSIDmjtCXU!='' and VyLJMTENbukgYcxKnlwFpSIDmjtCXU!='-' and VyLJMTENbukgYcxKnlwFpSIDmjtCXU!=u'없음':VyLJMTENbukgYcxKnlwFpSIDmjtCWd.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXU)
     if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('program').get('category1_name').get('ko')!='':
      VyLJMTENbukgYcxKnlwFpSIDmjtCWP.append(VyLJMTENbukgYcxKnlwFpSIDmjtCUo['program']['category1_name']['ko'])
     if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('program').get('category2_name').get('ko')!='':
      VyLJMTENbukgYcxKnlwFpSIDmjtCWP.append(VyLJMTENbukgYcxKnlwFpSIDmjtCUo['program']['category2_name']['ko'])
     if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('program').get('product_year'):VyLJMTENbukgYcxKnlwFpSIDmjtCWe=VyLJMTENbukgYcxKnlwFpSIDmjtCUo['program']['product_year']
     if 'broad_dt' in VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('program'):
      VyLJMTENbukgYcxKnlwFpSIDmjtCXf =VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('program').get('broad_dt')
      VyLJMTENbukgYcxKnlwFpSIDmjtCWR='%s-%s-%s'%(VyLJMTENbukgYcxKnlwFpSIDmjtCXf[:4],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[4:6],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[6:])
    except:
     VyLJMTENbukgYcxKnlwFpSIDmjtCBU
    VyLJMTENbukgYcxKnlwFpSIDmjtCXi={'program':VyLJMTENbukgYcxKnlwFpSIDmjtCXB,'title':VyLJMTENbukgYcxKnlwFpSIDmjtCWG,'thumbnail':{'poster':VyLJMTENbukgYcxKnlwFpSIDmjtCWs,'thumb':VyLJMTENbukgYcxKnlwFpSIDmjtCWr,'clearlogo':VyLJMTENbukgYcxKnlwFpSIDmjtCWO,'icon':VyLJMTENbukgYcxKnlwFpSIDmjtCWh,'banner':VyLJMTENbukgYcxKnlwFpSIDmjtCWv,'fanart':VyLJMTENbukgYcxKnlwFpSIDmjtCWr},'synopsis':VyLJMTENbukgYcxKnlwFpSIDmjtCWA,'channel':VyLJMTENbukgYcxKnlwFpSIDmjtCXz,'cast':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ,'director':VyLJMTENbukgYcxKnlwFpSIDmjtCWd,'info_genre':VyLJMTENbukgYcxKnlwFpSIDmjtCWP,'year':VyLJMTENbukgYcxKnlwFpSIDmjtCWe,'premiered':VyLJMTENbukgYcxKnlwFpSIDmjtCWR,'mpaa':VyLJMTENbukgYcxKnlwFpSIDmjtCWq}
    VyLJMTENbukgYcxKnlwFpSIDmjtCUr.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXi)
   if VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['has_more']=='Y':VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBX
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
 def Get_UHD_ProgramList(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,page_int):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUr=[]
  VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v2/operator/highlights'
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams(uhd=VyLJMTENbukgYcxKnlwFpSIDmjtCBX)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(page_int),'pocType':'APP_X_TVING_4.0.0',}
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq.update(VyLJMTENbukgYcxKnlwFpSIDmjtCUh)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUG
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUq,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUv=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   if not('result' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']):return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
   VyLJMTENbukgYcxKnlwFpSIDmjtCWX=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['result']
   for VyLJMTENbukgYcxKnlwFpSIDmjtCUo in VyLJMTENbukgYcxKnlwFpSIDmjtCWX:
    VyLJMTENbukgYcxKnlwFpSIDmjtCXG=VyLJMTENbukgYcxKnlwFpSIDmjtCUo['content']['program']
    VyLJMTENbukgYcxKnlwFpSIDmjtCXA =VyLJMTENbukgYcxKnlwFpSIDmjtCXG['code']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWG =VyLJMTENbukgYcxKnlwFpSIDmjtCXG['name']['ko'].strip()
    VyLJMTENbukgYcxKnlwFpSIDmjtCWq =VyLJMTENbukgYcxKnlwFpSIDmjtCaW.get(VyLJMTENbukgYcxKnlwFpSIDmjtCXG.get('grade_code'))
    VyLJMTENbukgYcxKnlwFpSIDmjtCWA =VyLJMTENbukgYcxKnlwFpSIDmjtCXG['synopsis']['ko']
    VyLJMTENbukgYcxKnlwFpSIDmjtCXz =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['content']['channel']['name']['ko']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWe =VyLJMTENbukgYcxKnlwFpSIDmjtCXG['product_year']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWs =''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWr =''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWO=''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWh =''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWv =''
    for VyLJMTENbukgYcxKnlwFpSIDmjtCWH in VyLJMTENbukgYcxKnlwFpSIDmjtCXG['image']:
     if VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP0900':VyLJMTENbukgYcxKnlwFpSIDmjtCWs =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP0200':VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP1800':VyLJMTENbukgYcxKnlwFpSIDmjtCWO=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP2000':VyLJMTENbukgYcxKnlwFpSIDmjtCWh =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP1900':VyLJMTENbukgYcxKnlwFpSIDmjtCWv =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWP =[]
    VyLJMTENbukgYcxKnlwFpSIDmjtCWQ =[]
    VyLJMTENbukgYcxKnlwFpSIDmjtCWd=[]
    VyLJMTENbukgYcxKnlwFpSIDmjtCWR =''
    if VyLJMTENbukgYcxKnlwFpSIDmjtCXG.get('category1_name').get('ko')!='':
     VyLJMTENbukgYcxKnlwFpSIDmjtCWP.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXG['category1_name']['ko'])
    if VyLJMTENbukgYcxKnlwFpSIDmjtCXG.get('category2_name').get('ko')!='':
     VyLJMTENbukgYcxKnlwFpSIDmjtCWP.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXG['category2_name']['ko'])
    for VyLJMTENbukgYcxKnlwFpSIDmjtCXa in VyLJMTENbukgYcxKnlwFpSIDmjtCXG.get('actor'):
     if VyLJMTENbukgYcxKnlwFpSIDmjtCXa!='' and VyLJMTENbukgYcxKnlwFpSIDmjtCXa!='-' and VyLJMTENbukgYcxKnlwFpSIDmjtCXa!=u'없음':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXa)
    for VyLJMTENbukgYcxKnlwFpSIDmjtCXU in VyLJMTENbukgYcxKnlwFpSIDmjtCXG.get('director'):
     if VyLJMTENbukgYcxKnlwFpSIDmjtCXU!='' and VyLJMTENbukgYcxKnlwFpSIDmjtCXU!='-' and VyLJMTENbukgYcxKnlwFpSIDmjtCXU!=u'없음':VyLJMTENbukgYcxKnlwFpSIDmjtCWd.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXU)
    if VyLJMTENbukgYcxKnlwFpSIDmjtCXG.get('broad_dt')not in[VyLJMTENbukgYcxKnlwFpSIDmjtCBU,'']:
     VyLJMTENbukgYcxKnlwFpSIDmjtCXf =VyLJMTENbukgYcxKnlwFpSIDmjtCXG.get('broad_dt')
     VyLJMTENbukgYcxKnlwFpSIDmjtCWR='%s-%s-%s'%(VyLJMTENbukgYcxKnlwFpSIDmjtCXf[:4],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[4:6],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[6:])
    VyLJMTENbukgYcxKnlwFpSIDmjtCXi={'program':VyLJMTENbukgYcxKnlwFpSIDmjtCXA,'title':VyLJMTENbukgYcxKnlwFpSIDmjtCWG,'mpaa':VyLJMTENbukgYcxKnlwFpSIDmjtCWq,'thumbnail':{'poster':VyLJMTENbukgYcxKnlwFpSIDmjtCWs,'thumb':VyLJMTENbukgYcxKnlwFpSIDmjtCWr,'clearlogo':VyLJMTENbukgYcxKnlwFpSIDmjtCWO,'icon':VyLJMTENbukgYcxKnlwFpSIDmjtCWh,'banner':VyLJMTENbukgYcxKnlwFpSIDmjtCWv,'fanart':VyLJMTENbukgYcxKnlwFpSIDmjtCWr},'channel':VyLJMTENbukgYcxKnlwFpSIDmjtCXz,'synopsis':VyLJMTENbukgYcxKnlwFpSIDmjtCWA,'year':VyLJMTENbukgYcxKnlwFpSIDmjtCWe,'info_genre':VyLJMTENbukgYcxKnlwFpSIDmjtCWP,'cast':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ,'director':VyLJMTENbukgYcxKnlwFpSIDmjtCWd,'premiered':VyLJMTENbukgYcxKnlwFpSIDmjtCWR,}
    VyLJMTENbukgYcxKnlwFpSIDmjtCUr.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXi)
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
 def Get_Origianl_ProgramList(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,page_int):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUr=[]
  VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v2/media/band/originals'
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams()
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'pageSize':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(page_int),}
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq.update(VyLJMTENbukgYcxKnlwFpSIDmjtCUh)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUG
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUq,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUv=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   if not('contents' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']):return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
   VyLJMTENbukgYcxKnlwFpSIDmjtCWX=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['contents']
   for VyLJMTENbukgYcxKnlwFpSIDmjtCUo in VyLJMTENbukgYcxKnlwFpSIDmjtCWX:
    VyLJMTENbukgYcxKnlwFpSIDmjtCXB=VyLJMTENbukgYcxKnlwFpSIDmjtCUo['vod_code']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWG =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['vod_name']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWs =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUo['image']
    VyLJMTENbukgYcxKnlwFpSIDmjtCXi={'program':VyLJMTENbukgYcxKnlwFpSIDmjtCXB,'title':VyLJMTENbukgYcxKnlwFpSIDmjtCWG,'thumbnail':{'poster':VyLJMTENbukgYcxKnlwFpSIDmjtCWs,'thumb':VyLJMTENbukgYcxKnlwFpSIDmjtCWs}}
    VyLJMTENbukgYcxKnlwFpSIDmjtCUr.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXi)
   if VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['has_more']=='Y':VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBX
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
 def GetEpisodeList(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,program_code,page_int,orderby='desc'):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUr=[]
  VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v2/media/frequency/program/'+program_code
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams()
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq.update(VyLJMTENbukgYcxKnlwFpSIDmjtCUh)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUG
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUq,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUv=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   if not('result' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']):return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
   VyLJMTENbukgYcxKnlwFpSIDmjtCWX=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['result']
   VyLJMTENbukgYcxKnlwFpSIDmjtCXr=VyLJMTENbukgYcxKnlwFpSIDmjtCBi(VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['total_count'])
   VyLJMTENbukgYcxKnlwFpSIDmjtCXs =VyLJMTENbukgYcxKnlwFpSIDmjtCBi(VyLJMTENbukgYcxKnlwFpSIDmjtCXr//(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    VyLJMTENbukgYcxKnlwFpSIDmjtCXO =(VyLJMTENbukgYcxKnlwFpSIDmjtCXr-1)-((page_int-1)*VyLJMTENbukgYcxKnlwFpSIDmjtCaX.EPISODE_LIMIT)
   else:
    VyLJMTENbukgYcxKnlwFpSIDmjtCXO =(page_int-1)*VyLJMTENbukgYcxKnlwFpSIDmjtCaX.EPISODE_LIMIT
   for i in VyLJMTENbukgYcxKnlwFpSIDmjtCBz(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.EPISODE_LIMIT):
    if orderby=='desc':
     VyLJMTENbukgYcxKnlwFpSIDmjtCXh=VyLJMTENbukgYcxKnlwFpSIDmjtCXO-i
     if VyLJMTENbukgYcxKnlwFpSIDmjtCXh<0:break
    else:
     VyLJMTENbukgYcxKnlwFpSIDmjtCXh=VyLJMTENbukgYcxKnlwFpSIDmjtCXO+i
     if VyLJMTENbukgYcxKnlwFpSIDmjtCXh>=VyLJMTENbukgYcxKnlwFpSIDmjtCXr:break
    VyLJMTENbukgYcxKnlwFpSIDmjtCXv=VyLJMTENbukgYcxKnlwFpSIDmjtCWX[VyLJMTENbukgYcxKnlwFpSIDmjtCXh]['episode']['code']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWG =VyLJMTENbukgYcxKnlwFpSIDmjtCWX[VyLJMTENbukgYcxKnlwFpSIDmjtCXh]['vod_name']['ko']
    VyLJMTENbukgYcxKnlwFpSIDmjtCXo =''
    try:
     VyLJMTENbukgYcxKnlwFpSIDmjtCXf=VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCWX[VyLJMTENbukgYcxKnlwFpSIDmjtCXh]['episode']['broadcast_date'])
     VyLJMTENbukgYcxKnlwFpSIDmjtCXo='%s-%s-%s'%(VyLJMTENbukgYcxKnlwFpSIDmjtCXf[:4],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[4:6],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[6:])
    except:
     VyLJMTENbukgYcxKnlwFpSIDmjtCBU
    try:
     if VyLJMTENbukgYcxKnlwFpSIDmjtCWX[VyLJMTENbukgYcxKnlwFpSIDmjtCXh]['episode']['pip_cliptype']=='C012':
      VyLJMTENbukgYcxKnlwFpSIDmjtCXo+=' - Quick VOD'
    except:
     VyLJMTENbukgYcxKnlwFpSIDmjtCBU
    VyLJMTENbukgYcxKnlwFpSIDmjtCWA =VyLJMTENbukgYcxKnlwFpSIDmjtCWX[VyLJMTENbukgYcxKnlwFpSIDmjtCXh]['episode']['synopsis']['ko']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWs =''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWr =''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWO=''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWh =''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWv =''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWo =''
    for VyLJMTENbukgYcxKnlwFpSIDmjtCWH in VyLJMTENbukgYcxKnlwFpSIDmjtCWX[VyLJMTENbukgYcxKnlwFpSIDmjtCXh]['program']['image']:
     if VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP0900':VyLJMTENbukgYcxKnlwFpSIDmjtCWs =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP1800':VyLJMTENbukgYcxKnlwFpSIDmjtCWO=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP2000':VyLJMTENbukgYcxKnlwFpSIDmjtCWh =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP1900':VyLJMTENbukgYcxKnlwFpSIDmjtCWv =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIP0200':VyLJMTENbukgYcxKnlwFpSIDmjtCWo =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
    for VyLJMTENbukgYcxKnlwFpSIDmjtCWH in VyLJMTENbukgYcxKnlwFpSIDmjtCWX[VyLJMTENbukgYcxKnlwFpSIDmjtCXh]['episode']['image']:
     if VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIE0400':VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
    try:
     VyLJMTENbukgYcxKnlwFpSIDmjtCXH=VyLJMTENbukgYcxKnlwFpSIDmjtCXd=VyLJMTENbukgYcxKnlwFpSIDmjtCXP=''
     VyLJMTENbukgYcxKnlwFpSIDmjtCXQ=0
     VyLJMTENbukgYcxKnlwFpSIDmjtCXH =VyLJMTENbukgYcxKnlwFpSIDmjtCWX[VyLJMTENbukgYcxKnlwFpSIDmjtCXh]['program']['name']['ko']
     VyLJMTENbukgYcxKnlwFpSIDmjtCXd =VyLJMTENbukgYcxKnlwFpSIDmjtCXo
     VyLJMTENbukgYcxKnlwFpSIDmjtCXP =VyLJMTENbukgYcxKnlwFpSIDmjtCWX[VyLJMTENbukgYcxKnlwFpSIDmjtCXh]['channel']['name']['ko']
     if 'frequency' in VyLJMTENbukgYcxKnlwFpSIDmjtCWX[VyLJMTENbukgYcxKnlwFpSIDmjtCXh]['episode']:VyLJMTENbukgYcxKnlwFpSIDmjtCXQ=VyLJMTENbukgYcxKnlwFpSIDmjtCWX[VyLJMTENbukgYcxKnlwFpSIDmjtCXh]['episode']['frequency']
    except:
     VyLJMTENbukgYcxKnlwFpSIDmjtCBU
    VyLJMTENbukgYcxKnlwFpSIDmjtCXi={'episode':VyLJMTENbukgYcxKnlwFpSIDmjtCXv,'title':VyLJMTENbukgYcxKnlwFpSIDmjtCWG,'subtitle':VyLJMTENbukgYcxKnlwFpSIDmjtCXo,'thumbnail':{'poster':VyLJMTENbukgYcxKnlwFpSIDmjtCWs,'thumb':VyLJMTENbukgYcxKnlwFpSIDmjtCWr,'clearlogo':VyLJMTENbukgYcxKnlwFpSIDmjtCWO,'icon':VyLJMTENbukgYcxKnlwFpSIDmjtCWh,'banner':VyLJMTENbukgYcxKnlwFpSIDmjtCWv,'fanart':VyLJMTENbukgYcxKnlwFpSIDmjtCWo},'synopsis':VyLJMTENbukgYcxKnlwFpSIDmjtCWA,'info_title':VyLJMTENbukgYcxKnlwFpSIDmjtCXH,'aired':VyLJMTENbukgYcxKnlwFpSIDmjtCXd,'studio':VyLJMTENbukgYcxKnlwFpSIDmjtCXP,'frequency':VyLJMTENbukgYcxKnlwFpSIDmjtCXQ}
    VyLJMTENbukgYcxKnlwFpSIDmjtCUr.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXi)
   if VyLJMTENbukgYcxKnlwFpSIDmjtCXs>page_int:VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBX
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU,VyLJMTENbukgYcxKnlwFpSIDmjtCXs
 def GetMovieList(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,genre,orderby,page_int):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUr=[]
  VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  try:
   if genre=='PARAMOUNT':
    VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v2/media/paramount/movies'
   else:
    VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v2/media/movies'
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams()
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'pageSize':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:VyLJMTENbukgYcxKnlwFpSIDmjtCUh['categoryCode']=genre
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh['productPackageCode']=','.join(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.MOVIE_LITE)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq.update(VyLJMTENbukgYcxKnlwFpSIDmjtCUh)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUG
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUq,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUv=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   if not('result' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']):return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
   VyLJMTENbukgYcxKnlwFpSIDmjtCWX=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['result']
   for VyLJMTENbukgYcxKnlwFpSIDmjtCUo in VyLJMTENbukgYcxKnlwFpSIDmjtCWX:
    if 'release_date' in VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('movie'):
     VyLJMTENbukgYcxKnlwFpSIDmjtCWe=VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('movie').get('release_date'))[:4]
    else:
     VyLJMTENbukgYcxKnlwFpSIDmjtCWe=VyLJMTENbukgYcxKnlwFpSIDmjtCBU
    VyLJMTENbukgYcxKnlwFpSIDmjtCXe =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['movie']['code']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWG =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['movie']['name']['ko'].strip()
    if VyLJMTENbukgYcxKnlwFpSIDmjtCWe not in[VyLJMTENbukgYcxKnlwFpSIDmjtCBU,'0','']:VyLJMTENbukgYcxKnlwFpSIDmjtCWG+=u' (%s)'%(VyLJMTENbukgYcxKnlwFpSIDmjtCWe)
    VyLJMTENbukgYcxKnlwFpSIDmjtCWs=''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWr =''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWO=''
    for VyLJMTENbukgYcxKnlwFpSIDmjtCWH in VyLJMTENbukgYcxKnlwFpSIDmjtCUo['movie']['image']:
     if VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIM2100':VyLJMTENbukgYcxKnlwFpSIDmjtCWs =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIM0400':VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIM1800':VyLJMTENbukgYcxKnlwFpSIDmjtCWO=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWA =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['movie']['story']['ko']
    try:
     VyLJMTENbukgYcxKnlwFpSIDmjtCXH =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['movie']['name']['ko'].strip()
     VyLJMTENbukgYcxKnlwFpSIDmjtCWq =VyLJMTENbukgYcxKnlwFpSIDmjtCaW.get(VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('grade_code'))
     VyLJMTENbukgYcxKnlwFpSIDmjtCWQ=[]
     VyLJMTENbukgYcxKnlwFpSIDmjtCWd=[]
     VyLJMTENbukgYcxKnlwFpSIDmjtCWP=[]
     VyLJMTENbukgYcxKnlwFpSIDmjtCXq=0
     VyLJMTENbukgYcxKnlwFpSIDmjtCWR=''
     VyLJMTENbukgYcxKnlwFpSIDmjtCXP =''
     for VyLJMTENbukgYcxKnlwFpSIDmjtCXa in VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('movie').get('actor'):
      if VyLJMTENbukgYcxKnlwFpSIDmjtCXa!='':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXa)
     for VyLJMTENbukgYcxKnlwFpSIDmjtCXU in VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('movie').get('director'):
      if VyLJMTENbukgYcxKnlwFpSIDmjtCXU!='':VyLJMTENbukgYcxKnlwFpSIDmjtCWd.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXU)
     if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('movie').get('category1_name').get('ko')!='':
      VyLJMTENbukgYcxKnlwFpSIDmjtCWP.append(VyLJMTENbukgYcxKnlwFpSIDmjtCUo['movie']['category1_name']['ko'])
     if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('movie').get('category2_name').get('ko')!='':
      VyLJMTENbukgYcxKnlwFpSIDmjtCWP.append(VyLJMTENbukgYcxKnlwFpSIDmjtCUo['movie']['category2_name']['ko'])
     if 'duration' in VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('movie'):VyLJMTENbukgYcxKnlwFpSIDmjtCXq=VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('movie').get('duration')
     if 'release_date' in VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('movie'):
      VyLJMTENbukgYcxKnlwFpSIDmjtCXf=VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('movie').get('release_date'))
      if VyLJMTENbukgYcxKnlwFpSIDmjtCXf!='0':VyLJMTENbukgYcxKnlwFpSIDmjtCWR='%s-%s-%s'%(VyLJMTENbukgYcxKnlwFpSIDmjtCXf[:4],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[4:6],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[6:])
     if 'production' in VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('movie'):VyLJMTENbukgYcxKnlwFpSIDmjtCXP=VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('movie').get('production')
    except:
     VyLJMTENbukgYcxKnlwFpSIDmjtCBU
    VyLJMTENbukgYcxKnlwFpSIDmjtCXi={'moviecode':VyLJMTENbukgYcxKnlwFpSIDmjtCXe,'title':VyLJMTENbukgYcxKnlwFpSIDmjtCWG,'thumbnail':{'poster':VyLJMTENbukgYcxKnlwFpSIDmjtCWs,'thumb':VyLJMTENbukgYcxKnlwFpSIDmjtCWr,'clearlogo':VyLJMTENbukgYcxKnlwFpSIDmjtCWO,'fanart':VyLJMTENbukgYcxKnlwFpSIDmjtCWr},'synopsis':VyLJMTENbukgYcxKnlwFpSIDmjtCWA,'info_title':VyLJMTENbukgYcxKnlwFpSIDmjtCXH,'year':VyLJMTENbukgYcxKnlwFpSIDmjtCWe,'cast':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ,'director':VyLJMTENbukgYcxKnlwFpSIDmjtCWd,'info_genre':VyLJMTENbukgYcxKnlwFpSIDmjtCWP,'duration':VyLJMTENbukgYcxKnlwFpSIDmjtCXq,'premiered':VyLJMTENbukgYcxKnlwFpSIDmjtCWR,'studio':VyLJMTENbukgYcxKnlwFpSIDmjtCXP,'mpaa':VyLJMTENbukgYcxKnlwFpSIDmjtCWq}
    VyLJMTENbukgYcxKnlwFpSIDmjtCXR=VyLJMTENbukgYcxKnlwFpSIDmjtCBf
    for VyLJMTENbukgYcxKnlwFpSIDmjtCia in VyLJMTENbukgYcxKnlwFpSIDmjtCUo['billing_package_id']:
     if VyLJMTENbukgYcxKnlwFpSIDmjtCia in VyLJMTENbukgYcxKnlwFpSIDmjtCaX.MOVIE_LITE:
      VyLJMTENbukgYcxKnlwFpSIDmjtCXR=VyLJMTENbukgYcxKnlwFpSIDmjtCBX
      break
    if VyLJMTENbukgYcxKnlwFpSIDmjtCXR==VyLJMTENbukgYcxKnlwFpSIDmjtCBf: 
     VyLJMTENbukgYcxKnlwFpSIDmjtCXi['title']=VyLJMTENbukgYcxKnlwFpSIDmjtCXi['title']+' [개별구매]'
    VyLJMTENbukgYcxKnlwFpSIDmjtCUr.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXi)
   if VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['has_more']=='Y':VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBX
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
 def Get_UHD_MovieList(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,page_int):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUr=[]
  VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v2/operator/highlights'
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams(uhd=VyLJMTENbukgYcxKnlwFpSIDmjtCBX)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(page_int),'pocType':'APP_X_TVING_4.0.0',}
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq.update(VyLJMTENbukgYcxKnlwFpSIDmjtCUh)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUG
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUq,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUv=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   if not('result' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']):return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
   VyLJMTENbukgYcxKnlwFpSIDmjtCWX=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['result']
   for VyLJMTENbukgYcxKnlwFpSIDmjtCUo in VyLJMTENbukgYcxKnlwFpSIDmjtCWX:
    VyLJMTENbukgYcxKnlwFpSIDmjtCXG=VyLJMTENbukgYcxKnlwFpSIDmjtCUo['content']['movie']
    VyLJMTENbukgYcxKnlwFpSIDmjtCXA =VyLJMTENbukgYcxKnlwFpSIDmjtCXG['code']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWG =VyLJMTENbukgYcxKnlwFpSIDmjtCXG['name']['ko'].strip()
    VyLJMTENbukgYcxKnlwFpSIDmjtCXH =VyLJMTENbukgYcxKnlwFpSIDmjtCXG['name']['ko'].strip()
    VyLJMTENbukgYcxKnlwFpSIDmjtCWe =VyLJMTENbukgYcxKnlwFpSIDmjtCXG['product_year']
    if VyLJMTENbukgYcxKnlwFpSIDmjtCWe:VyLJMTENbukgYcxKnlwFpSIDmjtCWG+=u' (%s)'%(VyLJMTENbukgYcxKnlwFpSIDmjtCXG['product_year'])
    VyLJMTENbukgYcxKnlwFpSIDmjtCWA =VyLJMTENbukgYcxKnlwFpSIDmjtCXG['story']['ko']
    VyLJMTENbukgYcxKnlwFpSIDmjtCXq =VyLJMTENbukgYcxKnlwFpSIDmjtCXG['duration']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWq =VyLJMTENbukgYcxKnlwFpSIDmjtCaW.get(VyLJMTENbukgYcxKnlwFpSIDmjtCXG.get('grade_code'))
    VyLJMTENbukgYcxKnlwFpSIDmjtCXP =VyLJMTENbukgYcxKnlwFpSIDmjtCXG['production']
    VyLJMTENbukgYcxKnlwFpSIDmjtCWs=''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWr =''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWO=''
    VyLJMTENbukgYcxKnlwFpSIDmjtCWP =[]
    VyLJMTENbukgYcxKnlwFpSIDmjtCWQ =[]
    VyLJMTENbukgYcxKnlwFpSIDmjtCWd=[]
    VyLJMTENbukgYcxKnlwFpSIDmjtCWR =''
    for VyLJMTENbukgYcxKnlwFpSIDmjtCWH in VyLJMTENbukgYcxKnlwFpSIDmjtCXG['image']:
     if VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIM2100':VyLJMTENbukgYcxKnlwFpSIDmjtCWs =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIM0400':VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
     elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH['code']=='CAIM1800':VyLJMTENbukgYcxKnlwFpSIDmjtCWO=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH['url']
    if VyLJMTENbukgYcxKnlwFpSIDmjtCXG['release_date']not in[VyLJMTENbukgYcxKnlwFpSIDmjtCBU,0]:
     VyLJMTENbukgYcxKnlwFpSIDmjtCXf=VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCXG['release_date'])
     if VyLJMTENbukgYcxKnlwFpSIDmjtCXf!='0':VyLJMTENbukgYcxKnlwFpSIDmjtCWR='%s-%s-%s'%(VyLJMTENbukgYcxKnlwFpSIDmjtCXf[:4],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[4:6],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[6:])
    if VyLJMTENbukgYcxKnlwFpSIDmjtCXG.get('category1_name').get('ko')!='':
     VyLJMTENbukgYcxKnlwFpSIDmjtCWP.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXG['category1_name']['ko'])
    if VyLJMTENbukgYcxKnlwFpSIDmjtCXG.get('category2_name').get('ko')!='':
     VyLJMTENbukgYcxKnlwFpSIDmjtCWP.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXG['category2_name']['ko'])
    for VyLJMTENbukgYcxKnlwFpSIDmjtCXa in VyLJMTENbukgYcxKnlwFpSIDmjtCXG.get('actor'):
     if VyLJMTENbukgYcxKnlwFpSIDmjtCXa!='':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXa)
    for VyLJMTENbukgYcxKnlwFpSIDmjtCXU in VyLJMTENbukgYcxKnlwFpSIDmjtCXG.get('director'):
     if VyLJMTENbukgYcxKnlwFpSIDmjtCXU!='':VyLJMTENbukgYcxKnlwFpSIDmjtCWd.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXU)
    VyLJMTENbukgYcxKnlwFpSIDmjtCXi={'moviecode':VyLJMTENbukgYcxKnlwFpSIDmjtCXA,'title':VyLJMTENbukgYcxKnlwFpSIDmjtCWG,'thumbnail':{'poster':VyLJMTENbukgYcxKnlwFpSIDmjtCWs,'thumb':VyLJMTENbukgYcxKnlwFpSIDmjtCWr,'clearlogo':VyLJMTENbukgYcxKnlwFpSIDmjtCWO,'fanart':VyLJMTENbukgYcxKnlwFpSIDmjtCWr},'year':VyLJMTENbukgYcxKnlwFpSIDmjtCWe,'info_title':VyLJMTENbukgYcxKnlwFpSIDmjtCXH,'synopsis':VyLJMTENbukgYcxKnlwFpSIDmjtCWA,'mpaa':VyLJMTENbukgYcxKnlwFpSIDmjtCWq,'duration':VyLJMTENbukgYcxKnlwFpSIDmjtCXq,'premiered':VyLJMTENbukgYcxKnlwFpSIDmjtCWR,'studio':VyLJMTENbukgYcxKnlwFpSIDmjtCXP,'info_genre':VyLJMTENbukgYcxKnlwFpSIDmjtCWP,'cast':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ,'director':VyLJMTENbukgYcxKnlwFpSIDmjtCWd,}
    VyLJMTENbukgYcxKnlwFpSIDmjtCUr.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXi)
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
 def GetMovieGenre(VyLJMTENbukgYcxKnlwFpSIDmjtCaX):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUr=[]
  VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v2/media/movie/curations'
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams()
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq.update(VyLJMTENbukgYcxKnlwFpSIDmjtCUh)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUG
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUq,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUv=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   if not('result' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']):return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
   VyLJMTENbukgYcxKnlwFpSIDmjtCWX=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['result']
   for VyLJMTENbukgYcxKnlwFpSIDmjtCUo in VyLJMTENbukgYcxKnlwFpSIDmjtCWX:
    VyLJMTENbukgYcxKnlwFpSIDmjtCiU =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['curation_code']
    VyLJMTENbukgYcxKnlwFpSIDmjtCif =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['curation_name']
    VyLJMTENbukgYcxKnlwFpSIDmjtCXi={'curation_code':VyLJMTENbukgYcxKnlwFpSIDmjtCiU,'curation_name':VyLJMTENbukgYcxKnlwFpSIDmjtCif}
    VyLJMTENbukgYcxKnlwFpSIDmjtCUr.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXi)
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
 def GetSearchList(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,search_key,page_int,stype):
  VyLJMTENbukgYcxKnlwFpSIDmjtCiW=[]
  VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBf
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/search/getSearch.jsp'
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(page_int),'pageSize':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.SCREENCODE,'os':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.OSCODE,'network':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.SEARCH_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUG
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUh,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUv=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   if stype=='vod':
    if not('programRsb' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv):return VyLJMTENbukgYcxKnlwFpSIDmjtCiW,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
    VyLJMTENbukgYcxKnlwFpSIDmjtCiX=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['programRsb']['dataList']
    VyLJMTENbukgYcxKnlwFpSIDmjtCiB =VyLJMTENbukgYcxKnlwFpSIDmjtCBi(VyLJMTENbukgYcxKnlwFpSIDmjtCUv['programRsb']['count'])
    for VyLJMTENbukgYcxKnlwFpSIDmjtCUo in VyLJMTENbukgYcxKnlwFpSIDmjtCiX:
     VyLJMTENbukgYcxKnlwFpSIDmjtCXB=VyLJMTENbukgYcxKnlwFpSIDmjtCUo['mast_cd']
     VyLJMTENbukgYcxKnlwFpSIDmjtCWG =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['mast_nm']
     VyLJMTENbukgYcxKnlwFpSIDmjtCWs=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUo['web_url4']
     VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUo['web_url']
     try:
      VyLJMTENbukgYcxKnlwFpSIDmjtCWQ =[]
      VyLJMTENbukgYcxKnlwFpSIDmjtCWd=[]
      VyLJMTENbukgYcxKnlwFpSIDmjtCWP =[]
      VyLJMTENbukgYcxKnlwFpSIDmjtCXq =0
      VyLJMTENbukgYcxKnlwFpSIDmjtCWq =''
      VyLJMTENbukgYcxKnlwFpSIDmjtCWe =''
      VyLJMTENbukgYcxKnlwFpSIDmjtCXd =''
      if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('actor') !='' and VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('actor') !='-':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ =VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('actor').split(',')
      if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('director')!='' and VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('director')!='-':VyLJMTENbukgYcxKnlwFpSIDmjtCWd=VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('director').split(',')
      if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('cate_nm')!='' and VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('cate_nm')!='-':VyLJMTENbukgYcxKnlwFpSIDmjtCWP =VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('cate_nm').split('/')
      if 'targetage' in VyLJMTENbukgYcxKnlwFpSIDmjtCUo:VyLJMTENbukgYcxKnlwFpSIDmjtCWq=VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('targetage')
      if 'broad_dt' in VyLJMTENbukgYcxKnlwFpSIDmjtCUo:
       VyLJMTENbukgYcxKnlwFpSIDmjtCXf=VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('broad_dt')
       VyLJMTENbukgYcxKnlwFpSIDmjtCXd='%s-%s-%s'%(VyLJMTENbukgYcxKnlwFpSIDmjtCXf[:4],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[4:6],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[6:])
       VyLJMTENbukgYcxKnlwFpSIDmjtCWe =VyLJMTENbukgYcxKnlwFpSIDmjtCXf[:4]
     except:
      VyLJMTENbukgYcxKnlwFpSIDmjtCBU
     VyLJMTENbukgYcxKnlwFpSIDmjtCXi={'program':VyLJMTENbukgYcxKnlwFpSIDmjtCXB,'title':VyLJMTENbukgYcxKnlwFpSIDmjtCWG,'thumbnail':{'poster':VyLJMTENbukgYcxKnlwFpSIDmjtCWs,'thumb':VyLJMTENbukgYcxKnlwFpSIDmjtCWr,'fanart':VyLJMTENbukgYcxKnlwFpSIDmjtCWr},'synopsis':'','cast':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ,'director':VyLJMTENbukgYcxKnlwFpSIDmjtCWd,'info_genre':VyLJMTENbukgYcxKnlwFpSIDmjtCWP,'duration':VyLJMTENbukgYcxKnlwFpSIDmjtCXq,'mpaa':VyLJMTENbukgYcxKnlwFpSIDmjtCWq,'year':VyLJMTENbukgYcxKnlwFpSIDmjtCWe,'aired':VyLJMTENbukgYcxKnlwFpSIDmjtCXd}
     VyLJMTENbukgYcxKnlwFpSIDmjtCiW.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXi)
   else:
    if not('vodMVRsb' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv):return VyLJMTENbukgYcxKnlwFpSIDmjtCiW,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
    VyLJMTENbukgYcxKnlwFpSIDmjtCiz=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['vodMVRsb']['dataList']
    VyLJMTENbukgYcxKnlwFpSIDmjtCiB =VyLJMTENbukgYcxKnlwFpSIDmjtCBi(VyLJMTENbukgYcxKnlwFpSIDmjtCUv['vodMVRsb']['count'])
    for VyLJMTENbukgYcxKnlwFpSIDmjtCUo in VyLJMTENbukgYcxKnlwFpSIDmjtCiz:
     VyLJMTENbukgYcxKnlwFpSIDmjtCXB=VyLJMTENbukgYcxKnlwFpSIDmjtCUo['mast_cd']
     VyLJMTENbukgYcxKnlwFpSIDmjtCWG =VyLJMTENbukgYcxKnlwFpSIDmjtCUo['mast_nm'].strip()
     VyLJMTENbukgYcxKnlwFpSIDmjtCWs =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUo['web_url']
     VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCWs
     VyLJMTENbukgYcxKnlwFpSIDmjtCWO=''
     try:
      VyLJMTENbukgYcxKnlwFpSIDmjtCWQ =[]
      VyLJMTENbukgYcxKnlwFpSIDmjtCWd=[]
      VyLJMTENbukgYcxKnlwFpSIDmjtCWP =[]
      VyLJMTENbukgYcxKnlwFpSIDmjtCXq =0
      VyLJMTENbukgYcxKnlwFpSIDmjtCWq =''
      VyLJMTENbukgYcxKnlwFpSIDmjtCWe =''
      VyLJMTENbukgYcxKnlwFpSIDmjtCXd =''
      if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('actor') !='' and VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('actor') !='-':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ =VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('actor').split(',')
      if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('director')!='' and VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('director')!='-':VyLJMTENbukgYcxKnlwFpSIDmjtCWd=VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('director').split(',')
      if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('cate_nm')!='' and VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('cate_nm')!='-':VyLJMTENbukgYcxKnlwFpSIDmjtCWP =VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('cate_nm').split('/')
      if VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('runtime_sec')!='':VyLJMTENbukgYcxKnlwFpSIDmjtCXq=VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('runtime_sec')
      if 'grade_nm' in VyLJMTENbukgYcxKnlwFpSIDmjtCUo:VyLJMTENbukgYcxKnlwFpSIDmjtCWq=VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('grade_nm')
      VyLJMTENbukgYcxKnlwFpSIDmjtCXf=VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('broad_dt')
      if data_str!='':
       VyLJMTENbukgYcxKnlwFpSIDmjtCXd='%s-%s-%s'%(VyLJMTENbukgYcxKnlwFpSIDmjtCXf[:4],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[4:6],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[6:])
       VyLJMTENbukgYcxKnlwFpSIDmjtCWe =VyLJMTENbukgYcxKnlwFpSIDmjtCXf[:4]
     except:
      VyLJMTENbukgYcxKnlwFpSIDmjtCBU
     VyLJMTENbukgYcxKnlwFpSIDmjtCXi={'movie':VyLJMTENbukgYcxKnlwFpSIDmjtCXB,'title':VyLJMTENbukgYcxKnlwFpSIDmjtCWG,'thumbnail':{'poster':VyLJMTENbukgYcxKnlwFpSIDmjtCWs,'thumb':VyLJMTENbukgYcxKnlwFpSIDmjtCWr,'fanart':VyLJMTENbukgYcxKnlwFpSIDmjtCWr,'clearlogo':VyLJMTENbukgYcxKnlwFpSIDmjtCWO},'synopsis':'','cast':VyLJMTENbukgYcxKnlwFpSIDmjtCWQ,'director':VyLJMTENbukgYcxKnlwFpSIDmjtCWd,'info_genre':VyLJMTENbukgYcxKnlwFpSIDmjtCWP,'duration':VyLJMTENbukgYcxKnlwFpSIDmjtCXq,'mpaa':VyLJMTENbukgYcxKnlwFpSIDmjtCWq,'year':VyLJMTENbukgYcxKnlwFpSIDmjtCWe,'aired':VyLJMTENbukgYcxKnlwFpSIDmjtCXd}
     VyLJMTENbukgYcxKnlwFpSIDmjtCXR=VyLJMTENbukgYcxKnlwFpSIDmjtCBf
     for VyLJMTENbukgYcxKnlwFpSIDmjtCia in VyLJMTENbukgYcxKnlwFpSIDmjtCUo['bill']:
      if VyLJMTENbukgYcxKnlwFpSIDmjtCia in VyLJMTENbukgYcxKnlwFpSIDmjtCaX.MOVIE_LITE:
       VyLJMTENbukgYcxKnlwFpSIDmjtCXR=VyLJMTENbukgYcxKnlwFpSIDmjtCBX
       break
     if VyLJMTENbukgYcxKnlwFpSIDmjtCXR==VyLJMTENbukgYcxKnlwFpSIDmjtCBf: 
      VyLJMTENbukgYcxKnlwFpSIDmjtCXi['title']=VyLJMTENbukgYcxKnlwFpSIDmjtCXi['title']+' [개별구매]'
     VyLJMTENbukgYcxKnlwFpSIDmjtCiW.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXi)
   if VyLJMTENbukgYcxKnlwFpSIDmjtCiB>(page_int*VyLJMTENbukgYcxKnlwFpSIDmjtCaX.SEARCH_LIMIT):VyLJMTENbukgYcxKnlwFpSIDmjtCWU=VyLJMTENbukgYcxKnlwFpSIDmjtCBX
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCiW,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
 def GetBookmarkInfo(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,videoid,vidtype):
  VyLJMTENbukgYcxKnlwFpSIDmjtCiG={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+'/v2/media/program/'+videoid
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams()
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'pageNo':'1','pageSize':'10','order':'name',}
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq.update(VyLJMTENbukgYcxKnlwFpSIDmjtCUh)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUq,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU)
   VyLJMTENbukgYcxKnlwFpSIDmjtCiA=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   if not('body' in VyLJMTENbukgYcxKnlwFpSIDmjtCiA):return{}
   VyLJMTENbukgYcxKnlwFpSIDmjtCir=VyLJMTENbukgYcxKnlwFpSIDmjtCiA['body']
   VyLJMTENbukgYcxKnlwFpSIDmjtCWG=VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('name').get('ko').strip()
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['title'] =VyLJMTENbukgYcxKnlwFpSIDmjtCWG
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['title']=VyLJMTENbukgYcxKnlwFpSIDmjtCWG
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['mpaa'] =VyLJMTENbukgYcxKnlwFpSIDmjtCaW.get(VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('grade_code'))
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['plot'] =VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('synopsis').get('ko')
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['year'] =VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('product_year')
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['cast'] =VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('actor')
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['director']=VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('director')
   if VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('category1_name').get('ko')!='':
    VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['genre'].append(VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('category1_name').get('ko'))
   if VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('category2_name').get('ko')!='':
    VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['genre'].append(VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('category2_name').get('ko'))
   VyLJMTENbukgYcxKnlwFpSIDmjtCXf=VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('broad_dt'))
   if VyLJMTENbukgYcxKnlwFpSIDmjtCXf!='0':VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(VyLJMTENbukgYcxKnlwFpSIDmjtCXf[:4],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[4:6],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[6:])
   VyLJMTENbukgYcxKnlwFpSIDmjtCWs =''
   VyLJMTENbukgYcxKnlwFpSIDmjtCWr =''
   VyLJMTENbukgYcxKnlwFpSIDmjtCWO=''
   VyLJMTENbukgYcxKnlwFpSIDmjtCWh =''
   VyLJMTENbukgYcxKnlwFpSIDmjtCWv =''
   for VyLJMTENbukgYcxKnlwFpSIDmjtCWH in VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('image'):
    if VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('code')=='CAIP0900':VyLJMTENbukgYcxKnlwFpSIDmjtCWs =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('url')
    elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('code')=='CAIP0200':VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('url')
    elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('code')=='CAIP1800':VyLJMTENbukgYcxKnlwFpSIDmjtCWO=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('url')
    elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('code')=='CAIP2000':VyLJMTENbukgYcxKnlwFpSIDmjtCWh =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('url')
    elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('code')=='CAIP1900':VyLJMTENbukgYcxKnlwFpSIDmjtCWv =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('url')
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['thumbnail']['poster']=VyLJMTENbukgYcxKnlwFpSIDmjtCWs
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['thumbnail']['thumb']=VyLJMTENbukgYcxKnlwFpSIDmjtCWr
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['thumbnail']['clearlogo']=VyLJMTENbukgYcxKnlwFpSIDmjtCWO
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['thumbnail']['icon']=VyLJMTENbukgYcxKnlwFpSIDmjtCWh
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['thumbnail']['banner']=VyLJMTENbukgYcxKnlwFpSIDmjtCWv
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['thumbnail']['fanart']=VyLJMTENbukgYcxKnlwFpSIDmjtCWr
  else:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+'/v2a/media/stream/info'
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams()
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_uuid'].split('-')[0],'uuid':VyLJMTENbukgYcxKnlwFpSIDmjtCaX.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetNoCache(1)),'wm':'Y',}
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq.update(VyLJMTENbukgYcxKnlwFpSIDmjtCUh)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUq,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU)
   VyLJMTENbukgYcxKnlwFpSIDmjtCiA=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   if not('content' in VyLJMTENbukgYcxKnlwFpSIDmjtCiA['body']):return{}
   VyLJMTENbukgYcxKnlwFpSIDmjtCir=VyLJMTENbukgYcxKnlwFpSIDmjtCiA['body']['content']['info']['movie']
   VyLJMTENbukgYcxKnlwFpSIDmjtCWG =VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('name').get('ko').strip()
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['title']=VyLJMTENbukgYcxKnlwFpSIDmjtCWG
   VyLJMTENbukgYcxKnlwFpSIDmjtCWG +=u' (%s)'%(VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('product_year'))
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['title'] =VyLJMTENbukgYcxKnlwFpSIDmjtCWG
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['mpaa'] =VyLJMTENbukgYcxKnlwFpSIDmjtCaW.get(VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('grade_code'))
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['plot'] =VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('story').get('ko')
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['year'] =VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('product_year')
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['studio'] =VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('production')
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['duration']=VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('duration')
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['cast'] =VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('actor')
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['director']=VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('director')
   if VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('category1_name').get('ko')!='':
    VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['genre'].append(VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('category1_name').get('ko'))
   if VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('category2_name').get('ko')!='':
    VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['genre'].append(VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('category2_name').get('ko'))
   VyLJMTENbukgYcxKnlwFpSIDmjtCXf=VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('release_date'))
   if VyLJMTENbukgYcxKnlwFpSIDmjtCXf!='0':VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(VyLJMTENbukgYcxKnlwFpSIDmjtCXf[:4],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[4:6],VyLJMTENbukgYcxKnlwFpSIDmjtCXf[6:])
   VyLJMTENbukgYcxKnlwFpSIDmjtCWs=''
   VyLJMTENbukgYcxKnlwFpSIDmjtCWr =''
   VyLJMTENbukgYcxKnlwFpSIDmjtCWO=''
   for VyLJMTENbukgYcxKnlwFpSIDmjtCWH in VyLJMTENbukgYcxKnlwFpSIDmjtCir.get('image'):
    if VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('code')=='CAIM2100':VyLJMTENbukgYcxKnlwFpSIDmjtCWs =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('url')
    elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('code')=='CAIM0400':VyLJMTENbukgYcxKnlwFpSIDmjtCWr =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('url')
    elif VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('code')=='CAIM1800':VyLJMTENbukgYcxKnlwFpSIDmjtCWO=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.IMG_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCWH.get('url')
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['thumbnail']['poster']=VyLJMTENbukgYcxKnlwFpSIDmjtCWs
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['thumbnail']['thumb']=VyLJMTENbukgYcxKnlwFpSIDmjtCWs 
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['thumbnail']['clearlogo']=VyLJMTENbukgYcxKnlwFpSIDmjtCWO
   VyLJMTENbukgYcxKnlwFpSIDmjtCiG['saveinfo']['thumbnail']['fanart']=VyLJMTENbukgYcxKnlwFpSIDmjtCWr
  return VyLJMTENbukgYcxKnlwFpSIDmjtCiG
 def GetEuroChannelList(VyLJMTENbukgYcxKnlwFpSIDmjtCaX):
  VyLJMTENbukgYcxKnlwFpSIDmjtCUr=[]
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCUG ='/v2/operator/highlights'
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetDefaultParams()
   VyLJMTENbukgYcxKnlwFpSIDmjtCUh={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':VyLJMTENbukgYcxKnlwFpSIDmjtCBr(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.GetNoCache(2))}
   VyLJMTENbukgYcxKnlwFpSIDmjtCUq.update(VyLJMTENbukgYcxKnlwFpSIDmjtCUh)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUR=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.API_DOMAIN+VyLJMTENbukgYcxKnlwFpSIDmjtCUG
   VyLJMTENbukgYcxKnlwFpSIDmjtCUW=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.callRequestCookies('Get',VyLJMTENbukgYcxKnlwFpSIDmjtCUR,payload=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,params=VyLJMTENbukgYcxKnlwFpSIDmjtCUq,headers=VyLJMTENbukgYcxKnlwFpSIDmjtCBU,cookies=VyLJMTENbukgYcxKnlwFpSIDmjtCBU)
   VyLJMTENbukgYcxKnlwFpSIDmjtCUv=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCUW.text)
   if not('result' in VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']):return VyLJMTENbukgYcxKnlwFpSIDmjtCUr,VyLJMTENbukgYcxKnlwFpSIDmjtCWU
   VyLJMTENbukgYcxKnlwFpSIDmjtCWX=VyLJMTENbukgYcxKnlwFpSIDmjtCUv['body']['result']
   VyLJMTENbukgYcxKnlwFpSIDmjtCis =VyLJMTENbukgYcxKnlwFpSIDmjtCaX.Get_Now_Datetime()
   VyLJMTENbukgYcxKnlwFpSIDmjtCiO=VyLJMTENbukgYcxKnlwFpSIDmjtCis+datetime.timedelta(days=-1)
   VyLJMTENbukgYcxKnlwFpSIDmjtCiO=VyLJMTENbukgYcxKnlwFpSIDmjtCBi(VyLJMTENbukgYcxKnlwFpSIDmjtCiO.strftime('%Y%m%d'))
   for VyLJMTENbukgYcxKnlwFpSIDmjtCUo in VyLJMTENbukgYcxKnlwFpSIDmjtCWX:
    VyLJMTENbukgYcxKnlwFpSIDmjtCih=VyLJMTENbukgYcxKnlwFpSIDmjtCBi(VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('content').get('banner_title2')[:8])
    if VyLJMTENbukgYcxKnlwFpSIDmjtCiO<=VyLJMTENbukgYcxKnlwFpSIDmjtCih:
     VyLJMTENbukgYcxKnlwFpSIDmjtCXi={'channel':VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('content').get('banner_sub_title3'),'title':VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('content').get('banner_title'),'subtitle':VyLJMTENbukgYcxKnlwFpSIDmjtCUo.get('content').get('banner_sub_title2'),}
     VyLJMTENbukgYcxKnlwFpSIDmjtCUr.append(VyLJMTENbukgYcxKnlwFpSIDmjtCXi)
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCUr
 def Make_DecryptKey(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,step,mediacode='000',timecode='000'):
  if step=='1':
   VyLJMTENbukgYcxKnlwFpSIDmjtCiv=VyLJMTENbukgYcxKnlwFpSIDmjtCBh('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   VyLJMTENbukgYcxKnlwFpSIDmjtCio=VyLJMTENbukgYcxKnlwFpSIDmjtCBh('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiv=VyLJMTENbukgYcxKnlwFpSIDmjtCBh('kss2lym0kdw1lks3','utf-8')
   VyLJMTENbukgYcxKnlwFpSIDmjtCio=VyLJMTENbukgYcxKnlwFpSIDmjtCBh([VyLJMTENbukgYcxKnlwFpSIDmjtCBv('*'),0x07,VyLJMTENbukgYcxKnlwFpSIDmjtCBv('r'),VyLJMTENbukgYcxKnlwFpSIDmjtCBv(';'),VyLJMTENbukgYcxKnlwFpSIDmjtCBv('7'),0x05,0x1e,0x01,VyLJMTENbukgYcxKnlwFpSIDmjtCBv('n'),VyLJMTENbukgYcxKnlwFpSIDmjtCBv('D'),0x02,VyLJMTENbukgYcxKnlwFpSIDmjtCBv('3'),VyLJMTENbukgYcxKnlwFpSIDmjtCBv('*'),VyLJMTENbukgYcxKnlwFpSIDmjtCBv('a'),VyLJMTENbukgYcxKnlwFpSIDmjtCBv('&'),VyLJMTENbukgYcxKnlwFpSIDmjtCBv('<')])
  return VyLJMTENbukgYcxKnlwFpSIDmjtCiv,VyLJMTENbukgYcxKnlwFpSIDmjtCio
 def DecryptPlaintext(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,ciphertext,encryption_key,init_vector):
  VyLJMTENbukgYcxKnlwFpSIDmjtCiH=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  VyLJMTENbukgYcxKnlwFpSIDmjtCiQ=Padding.unpad(VyLJMTENbukgYcxKnlwFpSIDmjtCiH.decrypt(base64.standard_b64decode(ciphertext)),16)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCiQ.decode('utf-8')
 def Decrypt_Url(VyLJMTENbukgYcxKnlwFpSIDmjtCaX,ciphertext,mediacode,VyLJMTENbukgYcxKnlwFpSIDmjtCfB):
  VyLJMTENbukgYcxKnlwFpSIDmjtCid=''
  VyLJMTENbukgYcxKnlwFpSIDmjtCfz=''
  VyLJMTENbukgYcxKnlwFpSIDmjtCfG=''
  try:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiv,VyLJMTENbukgYcxKnlwFpSIDmjtCio=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.Make_DecryptKey('1',mediacode=mediacode,timecode=VyLJMTENbukgYcxKnlwFpSIDmjtCfB)
   VyLJMTENbukgYcxKnlwFpSIDmjtCiP=json.loads(VyLJMTENbukgYcxKnlwFpSIDmjtCaX.DecryptPlaintext(ciphertext,VyLJMTENbukgYcxKnlwFpSIDmjtCiv,VyLJMTENbukgYcxKnlwFpSIDmjtCio))
   VyLJMTENbukgYcxKnlwFpSIDmjtCie =VyLJMTENbukgYcxKnlwFpSIDmjtCiP.get('broad_url')
   VyLJMTENbukgYcxKnlwFpSIDmjtCfz =VyLJMTENbukgYcxKnlwFpSIDmjtCiP.get('watermark') if 'watermark' in VyLJMTENbukgYcxKnlwFpSIDmjtCiP else ''
   VyLJMTENbukgYcxKnlwFpSIDmjtCfG=VyLJMTENbukgYcxKnlwFpSIDmjtCiP.get('watermarkKey')if 'watermarkKey' in VyLJMTENbukgYcxKnlwFpSIDmjtCiP else ''
   VyLJMTENbukgYcxKnlwFpSIDmjtCiv,VyLJMTENbukgYcxKnlwFpSIDmjtCio=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.Make_DecryptKey('2',mediacode=mediacode,timecode=VyLJMTENbukgYcxKnlwFpSIDmjtCfB)
   VyLJMTENbukgYcxKnlwFpSIDmjtCid=VyLJMTENbukgYcxKnlwFpSIDmjtCaX.DecryptPlaintext(VyLJMTENbukgYcxKnlwFpSIDmjtCie,VyLJMTENbukgYcxKnlwFpSIDmjtCiv,VyLJMTENbukgYcxKnlwFpSIDmjtCio)
  except VyLJMTENbukgYcxKnlwFpSIDmjtCBG as exception:
   VyLJMTENbukgYcxKnlwFpSIDmjtCiq(exception)
  return VyLJMTENbukgYcxKnlwFpSIDmjtCid,VyLJMTENbukgYcxKnlwFpSIDmjtCfz,VyLJMTENbukgYcxKnlwFpSIDmjtCfG
# Created by pyminifier (https://github.com/liftoff/pyminifier)
