__author__="NightRain"
SVTBOFnboxYyhgcfARMXNUIeLlHiPa=object
SVTBOFnboxYyhgcfARMXNUIeLlHiPt=None
SVTBOFnboxYyhgcfARMXNUIeLlHiPG=int
SVTBOFnboxYyhgcfARMXNUIeLlHiPj=False
SVTBOFnboxYyhgcfARMXNUIeLlHiPq=True
SVTBOFnboxYyhgcfARMXNUIeLlHiPz=type
SVTBOFnboxYyhgcfARMXNUIeLlHiPC=dict
SVTBOFnboxYyhgcfARMXNUIeLlHiPD=len
SVTBOFnboxYyhgcfARMXNUIeLlHiKv=str
SVTBOFnboxYyhgcfARMXNUIeLlHiKs=open
SVTBOFnboxYyhgcfARMXNUIeLlHiKd=Exception
SVTBOFnboxYyhgcfARMXNUIeLlHiKr=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
SVTBOFnboxYyhgcfARMXNUIeLlHivd=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'}]
SVTBOFnboxYyhgcfARMXNUIeLlHivr=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
SVTBOFnboxYyhgcfARMXNUIeLlHivE=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
SVTBOFnboxYyhgcfARMXNUIeLlHivP=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
SVTBOFnboxYyhgcfARMXNUIeLlHivK=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
SVTBOFnboxYyhgcfARMXNUIeLlHivk=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
SVTBOFnboxYyhgcfARMXNUIeLlHivJ=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
SVTBOFnboxYyhgcfARMXNUIeLlHivu=xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class SVTBOFnboxYyhgcfARMXNUIeLlHivs(SVTBOFnboxYyhgcfARMXNUIeLlHiPa):
 def __init__(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHivm,SVTBOFnboxYyhgcfARMXNUIeLlHivQ,SVTBOFnboxYyhgcfARMXNUIeLlHivW):
  SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_url =SVTBOFnboxYyhgcfARMXNUIeLlHivm
  SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle=SVTBOFnboxYyhgcfARMXNUIeLlHivQ
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params =SVTBOFnboxYyhgcfARMXNUIeLlHivW
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj =OKCnMkvLteiHqAmWcDQgrhGXwajJfP() 
 def addon_noti(SVTBOFnboxYyhgcfARMXNUIeLlHivp,sting):
  try:
   SVTBOFnboxYyhgcfARMXNUIeLlHiva=xbmcgui.Dialog()
   SVTBOFnboxYyhgcfARMXNUIeLlHiva.notification(__addonname__,sting)
  except:
   SVTBOFnboxYyhgcfARMXNUIeLlHiPt
 def addon_log(SVTBOFnboxYyhgcfARMXNUIeLlHivp,string):
  try:
   SVTBOFnboxYyhgcfARMXNUIeLlHivt=string.encode('utf-8','ignore')
  except:
   SVTBOFnboxYyhgcfARMXNUIeLlHivt='addonException: addon_log'
  SVTBOFnboxYyhgcfARMXNUIeLlHivG=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,SVTBOFnboxYyhgcfARMXNUIeLlHivt),level=SVTBOFnboxYyhgcfARMXNUIeLlHivG)
 def get_keyboard_input(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHisK):
  SVTBOFnboxYyhgcfARMXNUIeLlHivj=SVTBOFnboxYyhgcfARMXNUIeLlHiPt
  kb=xbmc.Keyboard()
  kb.setHeading(SVTBOFnboxYyhgcfARMXNUIeLlHisK)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   SVTBOFnboxYyhgcfARMXNUIeLlHivj=kb.getText()
  return SVTBOFnboxYyhgcfARMXNUIeLlHivj
 def get_settings_login_info(SVTBOFnboxYyhgcfARMXNUIeLlHivp):
  SVTBOFnboxYyhgcfARMXNUIeLlHivq =__addon__.getSetting('id')
  SVTBOFnboxYyhgcfARMXNUIeLlHivz =__addon__.getSetting('pw')
  SVTBOFnboxYyhgcfARMXNUIeLlHivC =__addon__.getSetting('login_type')
  SVTBOFnboxYyhgcfARMXNUIeLlHivD=SVTBOFnboxYyhgcfARMXNUIeLlHiPG(__addon__.getSetting('selected_profile'))
  return(SVTBOFnboxYyhgcfARMXNUIeLlHivq,SVTBOFnboxYyhgcfARMXNUIeLlHivz,SVTBOFnboxYyhgcfARMXNUIeLlHivC,SVTBOFnboxYyhgcfARMXNUIeLlHivD)
 def get_settings_premiumyn(SVTBOFnboxYyhgcfARMXNUIeLlHivp):
  SVTBOFnboxYyhgcfARMXNUIeLlHisv =__addon__.getSetting('premium_movieyn')
  if SVTBOFnboxYyhgcfARMXNUIeLlHisv=='false':
   return SVTBOFnboxYyhgcfARMXNUIeLlHiPj
  else:
   return SVTBOFnboxYyhgcfARMXNUIeLlHiPq
 def get_settings_direct_replay(SVTBOFnboxYyhgcfARMXNUIeLlHivp):
  SVTBOFnboxYyhgcfARMXNUIeLlHisd=SVTBOFnboxYyhgcfARMXNUIeLlHiPG(__addon__.getSetting('direct_replay'))
  if SVTBOFnboxYyhgcfARMXNUIeLlHisd==0:
   return SVTBOFnboxYyhgcfARMXNUIeLlHiPj
  else:
   return SVTBOFnboxYyhgcfARMXNUIeLlHiPq
 def set_winCredential(SVTBOFnboxYyhgcfARMXNUIeLlHivp,credential):
  SVTBOFnboxYyhgcfARMXNUIeLlHisr=xbmcgui.Window(10000)
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_LOGINTIME',SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(SVTBOFnboxYyhgcfARMXNUIeLlHivp):
  SVTBOFnboxYyhgcfARMXNUIeLlHisr=xbmcgui.Window(10000)
  SVTBOFnboxYyhgcfARMXNUIeLlHisE={'tving_token':SVTBOFnboxYyhgcfARMXNUIeLlHisr.getProperty('TVING_M_TOKEN'),'poc_userinfo':SVTBOFnboxYyhgcfARMXNUIeLlHisr.getProperty('TVING_M_USERINFO'),'tving_uuid':SVTBOFnboxYyhgcfARMXNUIeLlHisr.getProperty('TVING_M_UUID'),'tving_maintoken':SVTBOFnboxYyhgcfARMXNUIeLlHisr.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':SVTBOFnboxYyhgcfARMXNUIeLlHisr.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':SVTBOFnboxYyhgcfARMXNUIeLlHisr.getProperty('TVING_M_LOCKKEY')}
  return SVTBOFnboxYyhgcfARMXNUIeLlHisE
 def set_winEpisodeOrderby(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidD):
  SVTBOFnboxYyhgcfARMXNUIeLlHisr=xbmcgui.Window(10000)
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_ORDERBY',SVTBOFnboxYyhgcfARMXNUIeLlHidD)
 def get_winEpisodeOrderby(SVTBOFnboxYyhgcfARMXNUIeLlHivp):
  SVTBOFnboxYyhgcfARMXNUIeLlHisr=xbmcgui.Window(10000)
  return SVTBOFnboxYyhgcfARMXNUIeLlHisr.getProperty('TVING_M_ORDERBY')
 def add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHivp,label,sublabel='',img='',infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHiPt,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPq,params='',ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt):
  SVTBOFnboxYyhgcfARMXNUIeLlHisP='%s?%s'%(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_url,urllib.parse.urlencode(params))
  if sublabel:SVTBOFnboxYyhgcfARMXNUIeLlHisK='%s < %s >'%(label,sublabel)
  else: SVTBOFnboxYyhgcfARMXNUIeLlHisK=label
  if not img:img='DefaultFolder.png'
  SVTBOFnboxYyhgcfARMXNUIeLlHisk=xbmcgui.ListItem(SVTBOFnboxYyhgcfARMXNUIeLlHisK)
  if SVTBOFnboxYyhgcfARMXNUIeLlHiPz(img)==SVTBOFnboxYyhgcfARMXNUIeLlHiPC:
   SVTBOFnboxYyhgcfARMXNUIeLlHisk.setArt(img)
  else:
   SVTBOFnboxYyhgcfARMXNUIeLlHisk.setArt({'thumb':img,'poster':img})
  if infoLabels:SVTBOFnboxYyhgcfARMXNUIeLlHisk.setInfo('Video',infoLabels)
  if not isFolder:SVTBOFnboxYyhgcfARMXNUIeLlHisk.setProperty('IsPlayable','true')
  if ContextMenu:SVTBOFnboxYyhgcfARMXNUIeLlHisk.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle,SVTBOFnboxYyhgcfARMXNUIeLlHisP,SVTBOFnboxYyhgcfARMXNUIeLlHisk,isFolder)
 def get_selQuality(SVTBOFnboxYyhgcfARMXNUIeLlHivp,etype):
  try:
   SVTBOFnboxYyhgcfARMXNUIeLlHisJ='selected_quality'
   SVTBOFnboxYyhgcfARMXNUIeLlHisu=[1080,720,480,360]
   SVTBOFnboxYyhgcfARMXNUIeLlHisp=SVTBOFnboxYyhgcfARMXNUIeLlHiPG(__addon__.getSetting(SVTBOFnboxYyhgcfARMXNUIeLlHisJ))
   return SVTBOFnboxYyhgcfARMXNUIeLlHisu[SVTBOFnboxYyhgcfARMXNUIeLlHisp]
  except:
   SVTBOFnboxYyhgcfARMXNUIeLlHiPt
  return 720 
 def dp_Main_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp):
  for SVTBOFnboxYyhgcfARMXNUIeLlHism in SVTBOFnboxYyhgcfARMXNUIeLlHivd:
   SVTBOFnboxYyhgcfARMXNUIeLlHisK=SVTBOFnboxYyhgcfARMXNUIeLlHism.get('title')
   SVTBOFnboxYyhgcfARMXNUIeLlHisQ=''
   SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':SVTBOFnboxYyhgcfARMXNUIeLlHism.get('mode'),'stype':SVTBOFnboxYyhgcfARMXNUIeLlHism.get('stype'),'orderby':SVTBOFnboxYyhgcfARMXNUIeLlHism.get('orderby'),'ordernm':SVTBOFnboxYyhgcfARMXNUIeLlHism.get('ordernm'),'page':'1'}
   if SVTBOFnboxYyhgcfARMXNUIeLlHism.get('mode')=='XXX':
    SVTBOFnboxYyhgcfARMXNUIeLlHisW['mode']='XXX'
    SVTBOFnboxYyhgcfARMXNUIeLlHisw=SVTBOFnboxYyhgcfARMXNUIeLlHiPj
   else:
    if 'icon' in SVTBOFnboxYyhgcfARMXNUIeLlHism:
     SVTBOFnboxYyhgcfARMXNUIeLlHisQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',SVTBOFnboxYyhgcfARMXNUIeLlHism.get('icon')) 
    SVTBOFnboxYyhgcfARMXNUIeLlHisw=SVTBOFnboxYyhgcfARMXNUIeLlHiPq
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel='',img=SVTBOFnboxYyhgcfARMXNUIeLlHisQ,infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHiPt,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHisw,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHiPD(SVTBOFnboxYyhgcfARMXNUIeLlHivd)>0:xbmcplugin.endOfDirectory(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle)
 def login_main(SVTBOFnboxYyhgcfARMXNUIeLlHivp):
  (SVTBOFnboxYyhgcfARMXNUIeLlHist,SVTBOFnboxYyhgcfARMXNUIeLlHisG,SVTBOFnboxYyhgcfARMXNUIeLlHisj,SVTBOFnboxYyhgcfARMXNUIeLlHisq)=SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_settings_login_info()
  if not(SVTBOFnboxYyhgcfARMXNUIeLlHist and SVTBOFnboxYyhgcfARMXNUIeLlHisG):
   SVTBOFnboxYyhgcfARMXNUIeLlHiva=xbmcgui.Dialog()
   SVTBOFnboxYyhgcfARMXNUIeLlHisz=SVTBOFnboxYyhgcfARMXNUIeLlHiva.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if SVTBOFnboxYyhgcfARMXNUIeLlHisz==SVTBOFnboxYyhgcfARMXNUIeLlHiPq:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_winEpisodeOrderby()=='':
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.set_winEpisodeOrderby('desc')
  if SVTBOFnboxYyhgcfARMXNUIeLlHivp.cookiefile_check():return
  SVTBOFnboxYyhgcfARMXNUIeLlHisC =SVTBOFnboxYyhgcfARMXNUIeLlHiPG(SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  SVTBOFnboxYyhgcfARMXNUIeLlHisD=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if SVTBOFnboxYyhgcfARMXNUIeLlHisD==SVTBOFnboxYyhgcfARMXNUIeLlHiPt or SVTBOFnboxYyhgcfARMXNUIeLlHisD=='':
   SVTBOFnboxYyhgcfARMXNUIeLlHisD=SVTBOFnboxYyhgcfARMXNUIeLlHiPG('19000101')
  else:
   SVTBOFnboxYyhgcfARMXNUIeLlHisD=SVTBOFnboxYyhgcfARMXNUIeLlHiPG(re.sub('-','',SVTBOFnboxYyhgcfARMXNUIeLlHisD))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   SVTBOFnboxYyhgcfARMXNUIeLlHidv=0
   while SVTBOFnboxYyhgcfARMXNUIeLlHiPq:
    SVTBOFnboxYyhgcfARMXNUIeLlHidv+=1
    time.sleep(0.05)
    if SVTBOFnboxYyhgcfARMXNUIeLlHisD>=SVTBOFnboxYyhgcfARMXNUIeLlHisC:return
    if SVTBOFnboxYyhgcfARMXNUIeLlHidv>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if SVTBOFnboxYyhgcfARMXNUIeLlHisD>=SVTBOFnboxYyhgcfARMXNUIeLlHisC:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.GetCredential(SVTBOFnboxYyhgcfARMXNUIeLlHist,SVTBOFnboxYyhgcfARMXNUIeLlHisG,SVTBOFnboxYyhgcfARMXNUIeLlHisj,SVTBOFnboxYyhgcfARMXNUIeLlHisq):
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.set_winCredential(SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.LoadCredential())
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidP):
  SVTBOFnboxYyhgcfARMXNUIeLlHids=SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('stype')
  if SVTBOFnboxYyhgcfARMXNUIeLlHids=='live':
   SVTBOFnboxYyhgcfARMXNUIeLlHidr=SVTBOFnboxYyhgcfARMXNUIeLlHivr
  elif SVTBOFnboxYyhgcfARMXNUIeLlHids=='vod':
   SVTBOFnboxYyhgcfARMXNUIeLlHidr=SVTBOFnboxYyhgcfARMXNUIeLlHivK
  else:
   SVTBOFnboxYyhgcfARMXNUIeLlHidr=SVTBOFnboxYyhgcfARMXNUIeLlHivk
  for SVTBOFnboxYyhgcfARMXNUIeLlHidE in SVTBOFnboxYyhgcfARMXNUIeLlHidr:
   SVTBOFnboxYyhgcfARMXNUIeLlHisK=SVTBOFnboxYyhgcfARMXNUIeLlHidE.get('title')
   if SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('ordernm')!='-':
    SVTBOFnboxYyhgcfARMXNUIeLlHisK+='  ('+SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('ordernm')+')'
   SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':SVTBOFnboxYyhgcfARMXNUIeLlHidE.get('mode'),'stype':SVTBOFnboxYyhgcfARMXNUIeLlHidE.get('stype'),'orderby':SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('orderby'),'ordernm':SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('ordernm'),'page':'1'}
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel='',img='',infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHiPt,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPq,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHiPD(SVTBOFnboxYyhgcfARMXNUIeLlHidr)>0:xbmcplugin.endOfDirectory(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle)
 def dp_SubTitle_Group(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidP): 
  for SVTBOFnboxYyhgcfARMXNUIeLlHidE in SVTBOFnboxYyhgcfARMXNUIeLlHivJ:
   SVTBOFnboxYyhgcfARMXNUIeLlHisK=SVTBOFnboxYyhgcfARMXNUIeLlHidE.get('title')
   if SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('ordernm')!='-':
    SVTBOFnboxYyhgcfARMXNUIeLlHisK+='  ('+SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('ordernm')+')'
   SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':SVTBOFnboxYyhgcfARMXNUIeLlHidE.get('mode'),'genreCode':SVTBOFnboxYyhgcfARMXNUIeLlHidE.get('genreCode'),'stype':SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('stype'),'orderby':SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('orderby'),'page':'1'}
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel='',img='',infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHiPt,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPq,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHiPD(SVTBOFnboxYyhgcfARMXNUIeLlHivJ)>0:xbmcplugin.endOfDirectory(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle)
 def dp_LiveChannel_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidP):
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.SaveCredential(SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_winCredential())
  SVTBOFnboxYyhgcfARMXNUIeLlHids =SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('stype')
  SVTBOFnboxYyhgcfARMXNUIeLlHidK =SVTBOFnboxYyhgcfARMXNUIeLlHiPG(SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('page'))
  SVTBOFnboxYyhgcfARMXNUIeLlHidk,SVTBOFnboxYyhgcfARMXNUIeLlHidJ=SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.GetLiveChannelList(SVTBOFnboxYyhgcfARMXNUIeLlHids,SVTBOFnboxYyhgcfARMXNUIeLlHidK)
  for SVTBOFnboxYyhgcfARMXNUIeLlHidu in SVTBOFnboxYyhgcfARMXNUIeLlHidk:
   SVTBOFnboxYyhgcfARMXNUIeLlHisK =SVTBOFnboxYyhgcfARMXNUIeLlHidu.get('title')
   SVTBOFnboxYyhgcfARMXNUIeLlHisa =SVTBOFnboxYyhgcfARMXNUIeLlHidu.get('channel')
   SVTBOFnboxYyhgcfARMXNUIeLlHidp =SVTBOFnboxYyhgcfARMXNUIeLlHidu.get('thumbnail')
   SVTBOFnboxYyhgcfARMXNUIeLlHidm =SVTBOFnboxYyhgcfARMXNUIeLlHidu.get('synopsis')
   SVTBOFnboxYyhgcfARMXNUIeLlHidQ =SVTBOFnboxYyhgcfARMXNUIeLlHidu.get('channelepg')
   SVTBOFnboxYyhgcfARMXNUIeLlHidW =SVTBOFnboxYyhgcfARMXNUIeLlHidu.get('cast')
   SVTBOFnboxYyhgcfARMXNUIeLlHidw =SVTBOFnboxYyhgcfARMXNUIeLlHidu.get('director')
   SVTBOFnboxYyhgcfARMXNUIeLlHida =SVTBOFnboxYyhgcfARMXNUIeLlHidu.get('info_genre')
   SVTBOFnboxYyhgcfARMXNUIeLlHidt =SVTBOFnboxYyhgcfARMXNUIeLlHidu.get('year')
   SVTBOFnboxYyhgcfARMXNUIeLlHidG =SVTBOFnboxYyhgcfARMXNUIeLlHidu.get('mpaa')
   SVTBOFnboxYyhgcfARMXNUIeLlHidj =SVTBOFnboxYyhgcfARMXNUIeLlHidu.get('premiered')
   SVTBOFnboxYyhgcfARMXNUIeLlHidq={'mediatype':'episode','title':SVTBOFnboxYyhgcfARMXNUIeLlHisK,'studio':SVTBOFnboxYyhgcfARMXNUIeLlHisa,'cast':SVTBOFnboxYyhgcfARMXNUIeLlHidW,'director':SVTBOFnboxYyhgcfARMXNUIeLlHidw,'genre':SVTBOFnboxYyhgcfARMXNUIeLlHida,'plot':'%s\n%s\n%s\n\n%s'%(SVTBOFnboxYyhgcfARMXNUIeLlHisa,SVTBOFnboxYyhgcfARMXNUIeLlHisK,SVTBOFnboxYyhgcfARMXNUIeLlHidQ,SVTBOFnboxYyhgcfARMXNUIeLlHidm),'year':SVTBOFnboxYyhgcfARMXNUIeLlHidt,'mpaa':SVTBOFnboxYyhgcfARMXNUIeLlHidG,'premiered':SVTBOFnboxYyhgcfARMXNUIeLlHidj}
   SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':'LIVE','mediacode':SVTBOFnboxYyhgcfARMXNUIeLlHidu.get('mediacode'),'stype':SVTBOFnboxYyhgcfARMXNUIeLlHids}
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisa,sublabel=SVTBOFnboxYyhgcfARMXNUIeLlHisK,img=SVTBOFnboxYyhgcfARMXNUIeLlHidp,infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHidq,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPj,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHidJ:
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['mode']='CHANNEL' 
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['stype']=SVTBOFnboxYyhgcfARMXNUIeLlHids 
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['page']=SVTBOFnboxYyhgcfARMXNUIeLlHiKv(SVTBOFnboxYyhgcfARMXNUIeLlHidK+1)
   SVTBOFnboxYyhgcfARMXNUIeLlHisK='[B]%s >>[/B]'%'다음 페이지'
   SVTBOFnboxYyhgcfARMXNUIeLlHidz=SVTBOFnboxYyhgcfARMXNUIeLlHiKv(SVTBOFnboxYyhgcfARMXNUIeLlHidK+1)
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel=SVTBOFnboxYyhgcfARMXNUIeLlHidz,img='',infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHiPt,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPq,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHiPD(SVTBOFnboxYyhgcfARMXNUIeLlHidk)>0:xbmcplugin.endOfDirectory(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle,cacheToDisc=SVTBOFnboxYyhgcfARMXNUIeLlHiPj)
 def dp_Program_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidP):
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.SaveCredential(SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_winCredential())
  SVTBOFnboxYyhgcfARMXNUIeLlHidC =SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('stype')
  SVTBOFnboxYyhgcfARMXNUIeLlHidD =SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('orderby')
  SVTBOFnboxYyhgcfARMXNUIeLlHidK =SVTBOFnboxYyhgcfARMXNUIeLlHiPG(SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('page'))
  SVTBOFnboxYyhgcfARMXNUIeLlHirv=SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('genreCode')
  if SVTBOFnboxYyhgcfARMXNUIeLlHirv==SVTBOFnboxYyhgcfARMXNUIeLlHiPt:SVTBOFnboxYyhgcfARMXNUIeLlHirv='all'
  SVTBOFnboxYyhgcfARMXNUIeLlHirs,SVTBOFnboxYyhgcfARMXNUIeLlHidJ=SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.GetProgramList(SVTBOFnboxYyhgcfARMXNUIeLlHidC,SVTBOFnboxYyhgcfARMXNUIeLlHidD,SVTBOFnboxYyhgcfARMXNUIeLlHidK,SVTBOFnboxYyhgcfARMXNUIeLlHirv)
  for SVTBOFnboxYyhgcfARMXNUIeLlHird in SVTBOFnboxYyhgcfARMXNUIeLlHirs:
   SVTBOFnboxYyhgcfARMXNUIeLlHisK =SVTBOFnboxYyhgcfARMXNUIeLlHird.get('title')
   SVTBOFnboxYyhgcfARMXNUIeLlHidp =SVTBOFnboxYyhgcfARMXNUIeLlHird.get('thumbnail')
   SVTBOFnboxYyhgcfARMXNUIeLlHidm =SVTBOFnboxYyhgcfARMXNUIeLlHird.get('synopsis')
   SVTBOFnboxYyhgcfARMXNUIeLlHirE =SVTBOFnboxYyhgcfARMXNUIeLlHird.get('channel')
   SVTBOFnboxYyhgcfARMXNUIeLlHidW =SVTBOFnboxYyhgcfARMXNUIeLlHird.get('cast')
   SVTBOFnboxYyhgcfARMXNUIeLlHidw =SVTBOFnboxYyhgcfARMXNUIeLlHird.get('director')
   SVTBOFnboxYyhgcfARMXNUIeLlHida=SVTBOFnboxYyhgcfARMXNUIeLlHird.get('info_genre')
   SVTBOFnboxYyhgcfARMXNUIeLlHidt =SVTBOFnboxYyhgcfARMXNUIeLlHird.get('year')
   SVTBOFnboxYyhgcfARMXNUIeLlHidj =SVTBOFnboxYyhgcfARMXNUIeLlHird.get('premiered')
   SVTBOFnboxYyhgcfARMXNUIeLlHidG =SVTBOFnboxYyhgcfARMXNUIeLlHird.get('mpaa')
   SVTBOFnboxYyhgcfARMXNUIeLlHidq={'mediatype':'tvshow','title':SVTBOFnboxYyhgcfARMXNUIeLlHisK,'studio':SVTBOFnboxYyhgcfARMXNUIeLlHirE,'cast':SVTBOFnboxYyhgcfARMXNUIeLlHidW,'director':SVTBOFnboxYyhgcfARMXNUIeLlHidw,'genre':SVTBOFnboxYyhgcfARMXNUIeLlHida,'year':SVTBOFnboxYyhgcfARMXNUIeLlHidt,'premiered':SVTBOFnboxYyhgcfARMXNUIeLlHidj,'mpaa':SVTBOFnboxYyhgcfARMXNUIeLlHidG,'plot':'%s <%s>\n\n%s'%(SVTBOFnboxYyhgcfARMXNUIeLlHisK,SVTBOFnboxYyhgcfARMXNUIeLlHirE,SVTBOFnboxYyhgcfARMXNUIeLlHidm)}
   SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':'EPISODE','programcode':SVTBOFnboxYyhgcfARMXNUIeLlHird.get('program'),'page':'1'}
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel=SVTBOFnboxYyhgcfARMXNUIeLlHirE,img=SVTBOFnboxYyhgcfARMXNUIeLlHidp,infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHidq,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPq,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHidJ:
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['mode'] ='PROGRAM' 
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['stype'] =SVTBOFnboxYyhgcfARMXNUIeLlHidC
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['orderby'] =SVTBOFnboxYyhgcfARMXNUIeLlHidD
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['page'] =SVTBOFnboxYyhgcfARMXNUIeLlHiKv(SVTBOFnboxYyhgcfARMXNUIeLlHidK+1)
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['genreCode']=SVTBOFnboxYyhgcfARMXNUIeLlHirv 
   SVTBOFnboxYyhgcfARMXNUIeLlHisK='[B]%s >>[/B]'%'다음 페이지'
   SVTBOFnboxYyhgcfARMXNUIeLlHidz=SVTBOFnboxYyhgcfARMXNUIeLlHiKv(SVTBOFnboxYyhgcfARMXNUIeLlHidK+1)
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel=SVTBOFnboxYyhgcfARMXNUIeLlHidz,img='',infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHiPt,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPq,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHiPD(SVTBOFnboxYyhgcfARMXNUIeLlHirs)>0:xbmcplugin.endOfDirectory(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle,cacheToDisc=SVTBOFnboxYyhgcfARMXNUIeLlHiPj)
 def dp_Episode_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidP):
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.SaveCredential(SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_winCredential())
  SVTBOFnboxYyhgcfARMXNUIeLlHirP=SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('programcode')
  SVTBOFnboxYyhgcfARMXNUIeLlHidK =SVTBOFnboxYyhgcfARMXNUIeLlHiPG(SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('page'))
  SVTBOFnboxYyhgcfARMXNUIeLlHirK,SVTBOFnboxYyhgcfARMXNUIeLlHidJ,SVTBOFnboxYyhgcfARMXNUIeLlHirk=SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.GetEpisodeList(SVTBOFnboxYyhgcfARMXNUIeLlHirP,SVTBOFnboxYyhgcfARMXNUIeLlHidK,orderby=SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_winEpisodeOrderby())
  for SVTBOFnboxYyhgcfARMXNUIeLlHirJ in SVTBOFnboxYyhgcfARMXNUIeLlHirK:
   SVTBOFnboxYyhgcfARMXNUIeLlHisK =SVTBOFnboxYyhgcfARMXNUIeLlHirJ.get('title')
   SVTBOFnboxYyhgcfARMXNUIeLlHidz =SVTBOFnboxYyhgcfARMXNUIeLlHirJ.get('subtitle')
   SVTBOFnboxYyhgcfARMXNUIeLlHidp =SVTBOFnboxYyhgcfARMXNUIeLlHirJ.get('thumbnail')
   SVTBOFnboxYyhgcfARMXNUIeLlHidm =SVTBOFnboxYyhgcfARMXNUIeLlHirJ.get('synopsis')
   SVTBOFnboxYyhgcfARMXNUIeLlHiru=SVTBOFnboxYyhgcfARMXNUIeLlHirJ.get('info_title')
   SVTBOFnboxYyhgcfARMXNUIeLlHirp =SVTBOFnboxYyhgcfARMXNUIeLlHirJ.get('aired')
   SVTBOFnboxYyhgcfARMXNUIeLlHirm =SVTBOFnboxYyhgcfARMXNUIeLlHirJ.get('studio')
   SVTBOFnboxYyhgcfARMXNUIeLlHirQ =SVTBOFnboxYyhgcfARMXNUIeLlHirJ.get('frequency')
   SVTBOFnboxYyhgcfARMXNUIeLlHidq={'mediatype':'episode','title':SVTBOFnboxYyhgcfARMXNUIeLlHiru,'aired':SVTBOFnboxYyhgcfARMXNUIeLlHirp,'studio':SVTBOFnboxYyhgcfARMXNUIeLlHirm,'episode':SVTBOFnboxYyhgcfARMXNUIeLlHirQ,'plot':'%s\n\n%s'%(SVTBOFnboxYyhgcfARMXNUIeLlHisK,SVTBOFnboxYyhgcfARMXNUIeLlHidm)}
   SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':'VOD','mediacode':SVTBOFnboxYyhgcfARMXNUIeLlHirJ.get('episode'),'stype':'vod','programcode':SVTBOFnboxYyhgcfARMXNUIeLlHirP,'title':SVTBOFnboxYyhgcfARMXNUIeLlHisK,'thumbnail':SVTBOFnboxYyhgcfARMXNUIeLlHidp}
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel=SVTBOFnboxYyhgcfARMXNUIeLlHidz,img=SVTBOFnboxYyhgcfARMXNUIeLlHidp,infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHidq,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPj,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHidK==1:
   SVTBOFnboxYyhgcfARMXNUIeLlHidq={'plot':'정렬순서를 변경합니다.'}
   SVTBOFnboxYyhgcfARMXNUIeLlHisW={}
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['mode'] ='ORDER_BY' 
   if SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_winEpisodeOrderby()=='desc':
    SVTBOFnboxYyhgcfARMXNUIeLlHisK='정렬순서변경 : 최신화부터 -> 1회부터'
    SVTBOFnboxYyhgcfARMXNUIeLlHisW['orderby']='asc'
   else:
    SVTBOFnboxYyhgcfARMXNUIeLlHisK='정렬순서변경 : 1회부터 -> 최신화부터'
    SVTBOFnboxYyhgcfARMXNUIeLlHisW['orderby']='desc'
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel='',img='',infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHidq,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPj,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHidJ:
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['mode'] ='EPISODE' 
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['programcode']=SVTBOFnboxYyhgcfARMXNUIeLlHirP
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['page'] =SVTBOFnboxYyhgcfARMXNUIeLlHiKv(SVTBOFnboxYyhgcfARMXNUIeLlHidK+1)
   SVTBOFnboxYyhgcfARMXNUIeLlHisK='[B]%s >>[/B]'%'다음 페이지'
   SVTBOFnboxYyhgcfARMXNUIeLlHidz=SVTBOFnboxYyhgcfARMXNUIeLlHiKv(SVTBOFnboxYyhgcfARMXNUIeLlHidK+1)
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel=SVTBOFnboxYyhgcfARMXNUIeLlHidz,img='',infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHiPt,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPq,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHiPD(SVTBOFnboxYyhgcfARMXNUIeLlHirK)>0:xbmcplugin.endOfDirectory(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle,cacheToDisc=SVTBOFnboxYyhgcfARMXNUIeLlHiPq)
 def dp_setEpOrderby(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidP):
  SVTBOFnboxYyhgcfARMXNUIeLlHidD =SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('orderby')
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.set_winEpisodeOrderby(SVTBOFnboxYyhgcfARMXNUIeLlHidD)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidP):
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.SaveCredential(SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_winCredential())
  SVTBOFnboxYyhgcfARMXNUIeLlHidC =SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('stype')
  SVTBOFnboxYyhgcfARMXNUIeLlHidD =SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('orderby')
  SVTBOFnboxYyhgcfARMXNUIeLlHidK=SVTBOFnboxYyhgcfARMXNUIeLlHiPG(SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('page'))
  SVTBOFnboxYyhgcfARMXNUIeLlHirW,SVTBOFnboxYyhgcfARMXNUIeLlHidJ=SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.GetMovieList(SVTBOFnboxYyhgcfARMXNUIeLlHidC,SVTBOFnboxYyhgcfARMXNUIeLlHidD,SVTBOFnboxYyhgcfARMXNUIeLlHidK)
  for SVTBOFnboxYyhgcfARMXNUIeLlHirw in SVTBOFnboxYyhgcfARMXNUIeLlHirW:
   SVTBOFnboxYyhgcfARMXNUIeLlHisK =SVTBOFnboxYyhgcfARMXNUIeLlHirw.get('title')
   SVTBOFnboxYyhgcfARMXNUIeLlHidp =SVTBOFnboxYyhgcfARMXNUIeLlHirw.get('thumbnail')
   SVTBOFnboxYyhgcfARMXNUIeLlHidm =SVTBOFnboxYyhgcfARMXNUIeLlHirw.get('synopsis')
   SVTBOFnboxYyhgcfARMXNUIeLlHiru =SVTBOFnboxYyhgcfARMXNUIeLlHirw.get('info_title')
   SVTBOFnboxYyhgcfARMXNUIeLlHidt =SVTBOFnboxYyhgcfARMXNUIeLlHirw.get('year')
   SVTBOFnboxYyhgcfARMXNUIeLlHidW =SVTBOFnboxYyhgcfARMXNUIeLlHirw.get('cast')
   SVTBOFnboxYyhgcfARMXNUIeLlHidw =SVTBOFnboxYyhgcfARMXNUIeLlHirw.get('director')
   SVTBOFnboxYyhgcfARMXNUIeLlHida =SVTBOFnboxYyhgcfARMXNUIeLlHirw.get('info_genre')
   SVTBOFnboxYyhgcfARMXNUIeLlHira =SVTBOFnboxYyhgcfARMXNUIeLlHirw.get('duration')
   SVTBOFnboxYyhgcfARMXNUIeLlHidj =SVTBOFnboxYyhgcfARMXNUIeLlHirw.get('premiered')
   SVTBOFnboxYyhgcfARMXNUIeLlHirm =SVTBOFnboxYyhgcfARMXNUIeLlHirw.get('studio')
   SVTBOFnboxYyhgcfARMXNUIeLlHidG =SVTBOFnboxYyhgcfARMXNUIeLlHirw.get('mpaa')
   SVTBOFnboxYyhgcfARMXNUIeLlHidq={'mediatype':'movie','title':SVTBOFnboxYyhgcfARMXNUIeLlHiru,'year':SVTBOFnboxYyhgcfARMXNUIeLlHidt,'cast':SVTBOFnboxYyhgcfARMXNUIeLlHidW,'director':SVTBOFnboxYyhgcfARMXNUIeLlHidw,'genre':SVTBOFnboxYyhgcfARMXNUIeLlHida,'duration':SVTBOFnboxYyhgcfARMXNUIeLlHira,'premiered':SVTBOFnboxYyhgcfARMXNUIeLlHidj,'studio':SVTBOFnboxYyhgcfARMXNUIeLlHirm,'mpaa':SVTBOFnboxYyhgcfARMXNUIeLlHidG,'plot':'%s\n\n%s'%(SVTBOFnboxYyhgcfARMXNUIeLlHisK,SVTBOFnboxYyhgcfARMXNUIeLlHidm)}
   SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':'MOVIE','mediacode':SVTBOFnboxYyhgcfARMXNUIeLlHirw.get('moviecode'),'stype':'movie','title':SVTBOFnboxYyhgcfARMXNUIeLlHisK,'thumbnail':SVTBOFnboxYyhgcfARMXNUIeLlHidp}
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel='',img=SVTBOFnboxYyhgcfARMXNUIeLlHidp,infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHidq,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPj,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHidJ:
   SVTBOFnboxYyhgcfARMXNUIeLlHisW={}
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['mode'] ='MOVIE_SUB' 
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['orderby']=SVTBOFnboxYyhgcfARMXNUIeLlHidD
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['stype'] =SVTBOFnboxYyhgcfARMXNUIeLlHidC
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['page'] =SVTBOFnboxYyhgcfARMXNUIeLlHiKv(SVTBOFnboxYyhgcfARMXNUIeLlHidK+1)
   SVTBOFnboxYyhgcfARMXNUIeLlHisK='[B]%s >>[/B]'%'다음 페이지'
   SVTBOFnboxYyhgcfARMXNUIeLlHidz=SVTBOFnboxYyhgcfARMXNUIeLlHiKv(SVTBOFnboxYyhgcfARMXNUIeLlHidK+1)
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel=SVTBOFnboxYyhgcfARMXNUIeLlHidz,img='',infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHiPt,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPq,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHiPD(SVTBOFnboxYyhgcfARMXNUIeLlHirW)>0:xbmcplugin.endOfDirectory(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle,cacheToDisc=SVTBOFnboxYyhgcfARMXNUIeLlHiPj)
 def dp_Strm_Make(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidP):
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.addon_noti('aa')
 def dp_Search_Group(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidP):
  for SVTBOFnboxYyhgcfARMXNUIeLlHidE in SVTBOFnboxYyhgcfARMXNUIeLlHivP:
   SVTBOFnboxYyhgcfARMXNUIeLlHisK=SVTBOFnboxYyhgcfARMXNUIeLlHidE.get('title')
   SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':SVTBOFnboxYyhgcfARMXNUIeLlHidE.get('mode'),'stype':SVTBOFnboxYyhgcfARMXNUIeLlHidE.get('stype'),'page':'1'}
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel='',img='',infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHiPt,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPq,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHiPD(SVTBOFnboxYyhgcfARMXNUIeLlHivP)>0:xbmcplugin.endOfDirectory(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle)
 def dp_Search_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidP):
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.SaveCredential(SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_winCredential())
  SVTBOFnboxYyhgcfARMXNUIeLlHidK =SVTBOFnboxYyhgcfARMXNUIeLlHiPG(SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('page'))
  SVTBOFnboxYyhgcfARMXNUIeLlHids =SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('stype')
  if 'search_key' in SVTBOFnboxYyhgcfARMXNUIeLlHidP:
   SVTBOFnboxYyhgcfARMXNUIeLlHirt=SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('search_key')
  else:
   SVTBOFnboxYyhgcfARMXNUIeLlHirt=SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not SVTBOFnboxYyhgcfARMXNUIeLlHirt:return
  SVTBOFnboxYyhgcfARMXNUIeLlHirG,SVTBOFnboxYyhgcfARMXNUIeLlHidJ=SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.GetSearchList(SVTBOFnboxYyhgcfARMXNUIeLlHirt,SVTBOFnboxYyhgcfARMXNUIeLlHidK,SVTBOFnboxYyhgcfARMXNUIeLlHids)
  if SVTBOFnboxYyhgcfARMXNUIeLlHiPD(SVTBOFnboxYyhgcfARMXNUIeLlHirG)==0:return
  for SVTBOFnboxYyhgcfARMXNUIeLlHirj in SVTBOFnboxYyhgcfARMXNUIeLlHirG:
   SVTBOFnboxYyhgcfARMXNUIeLlHisK =SVTBOFnboxYyhgcfARMXNUIeLlHirj.get('title')
   SVTBOFnboxYyhgcfARMXNUIeLlHidp =SVTBOFnboxYyhgcfARMXNUIeLlHirj.get('thumbnail')
   SVTBOFnboxYyhgcfARMXNUIeLlHidm =SVTBOFnboxYyhgcfARMXNUIeLlHirj.get('synopsis')
   SVTBOFnboxYyhgcfARMXNUIeLlHirq =SVTBOFnboxYyhgcfARMXNUIeLlHirj.get('program')
   SVTBOFnboxYyhgcfARMXNUIeLlHidW =SVTBOFnboxYyhgcfARMXNUIeLlHirj.get('cast')
   SVTBOFnboxYyhgcfARMXNUIeLlHidw =SVTBOFnboxYyhgcfARMXNUIeLlHirj.get('director')
   SVTBOFnboxYyhgcfARMXNUIeLlHida=SVTBOFnboxYyhgcfARMXNUIeLlHirj.get('info_genre')
   SVTBOFnboxYyhgcfARMXNUIeLlHira =SVTBOFnboxYyhgcfARMXNUIeLlHirj.get('duration')
   SVTBOFnboxYyhgcfARMXNUIeLlHidG =SVTBOFnboxYyhgcfARMXNUIeLlHirj.get('mpaa')
   SVTBOFnboxYyhgcfARMXNUIeLlHidt =SVTBOFnboxYyhgcfARMXNUIeLlHirj.get('year')
   SVTBOFnboxYyhgcfARMXNUIeLlHirp =SVTBOFnboxYyhgcfARMXNUIeLlHirj.get('aired')
   SVTBOFnboxYyhgcfARMXNUIeLlHidq={'mediatype':'tvshow' if SVTBOFnboxYyhgcfARMXNUIeLlHids=='vod' else 'movie','title':SVTBOFnboxYyhgcfARMXNUIeLlHisK,'cast':SVTBOFnboxYyhgcfARMXNUIeLlHidW,'director':SVTBOFnboxYyhgcfARMXNUIeLlHidw,'genre':SVTBOFnboxYyhgcfARMXNUIeLlHida,'duration':SVTBOFnboxYyhgcfARMXNUIeLlHira,'mpaa':SVTBOFnboxYyhgcfARMXNUIeLlHidG,'year':SVTBOFnboxYyhgcfARMXNUIeLlHidt,'aired':SVTBOFnboxYyhgcfARMXNUIeLlHirp,'plot':'%s\n\n%s'%(SVTBOFnboxYyhgcfARMXNUIeLlHisK,SVTBOFnboxYyhgcfARMXNUIeLlHidm)}
   if SVTBOFnboxYyhgcfARMXNUIeLlHids=='vod':
    SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':'EPISODE','programcode':SVTBOFnboxYyhgcfARMXNUIeLlHirj.get('program'),'page':'1'}
    SVTBOFnboxYyhgcfARMXNUIeLlHisw=SVTBOFnboxYyhgcfARMXNUIeLlHiPq
   else:
    SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':'MOVIE','mediacode':SVTBOFnboxYyhgcfARMXNUIeLlHirj.get('movie'),'stype':'movie','title':SVTBOFnboxYyhgcfARMXNUIeLlHisK,'thumbnail':SVTBOFnboxYyhgcfARMXNUIeLlHidp}
    SVTBOFnboxYyhgcfARMXNUIeLlHisw=SVTBOFnboxYyhgcfARMXNUIeLlHiPj
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel='',img=SVTBOFnboxYyhgcfARMXNUIeLlHidp,infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHidq,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHisw,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHidJ:
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['mode'] ='SEARCH' 
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['search_key']=SVTBOFnboxYyhgcfARMXNUIeLlHirt
   SVTBOFnboxYyhgcfARMXNUIeLlHisW['page'] =SVTBOFnboxYyhgcfARMXNUIeLlHiKv(SVTBOFnboxYyhgcfARMXNUIeLlHidK+1)
   SVTBOFnboxYyhgcfARMXNUIeLlHisK='[B]%s >>[/B]'%'다음 페이지'
   SVTBOFnboxYyhgcfARMXNUIeLlHidz=SVTBOFnboxYyhgcfARMXNUIeLlHiKv(SVTBOFnboxYyhgcfARMXNUIeLlHidK+1)
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel=SVTBOFnboxYyhgcfARMXNUIeLlHidz,img='',infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHiPt,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPq,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHiPD(SVTBOFnboxYyhgcfARMXNUIeLlHirG)>0:xbmcplugin.endOfDirectory(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle)
 def Delete_Watched_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHids):
  try:
   SVTBOFnboxYyhgcfARMXNUIeLlHirz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%SVTBOFnboxYyhgcfARMXNUIeLlHids))
   fp=SVTBOFnboxYyhgcfARMXNUIeLlHiKs(SVTBOFnboxYyhgcfARMXNUIeLlHirz,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   SVTBOFnboxYyhgcfARMXNUIeLlHiPt
 def dp_WatchList_Delete(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidP):
  SVTBOFnboxYyhgcfARMXNUIeLlHids=SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('stype')
  SVTBOFnboxYyhgcfARMXNUIeLlHiva=xbmcgui.Dialog()
  SVTBOFnboxYyhgcfARMXNUIeLlHisz=SVTBOFnboxYyhgcfARMXNUIeLlHiva.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if SVTBOFnboxYyhgcfARMXNUIeLlHisz==SVTBOFnboxYyhgcfARMXNUIeLlHiPj:sys.exit()
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.Delete_Watched_List(SVTBOFnboxYyhgcfARMXNUIeLlHids)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHids):
  try:
   SVTBOFnboxYyhgcfARMXNUIeLlHirz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%SVTBOFnboxYyhgcfARMXNUIeLlHids))
   fp=SVTBOFnboxYyhgcfARMXNUIeLlHiKs(SVTBOFnboxYyhgcfARMXNUIeLlHirz,'r',-1,'utf-8')
   SVTBOFnboxYyhgcfARMXNUIeLlHirC=fp.readlines()
   fp.close()
  except:
   SVTBOFnboxYyhgcfARMXNUIeLlHirC=[]
  return SVTBOFnboxYyhgcfARMXNUIeLlHirC
 def Save_Watched_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHids,SVTBOFnboxYyhgcfARMXNUIeLlHivW):
  try:
   SVTBOFnboxYyhgcfARMXNUIeLlHirz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%SVTBOFnboxYyhgcfARMXNUIeLlHids))
   SVTBOFnboxYyhgcfARMXNUIeLlHirD=SVTBOFnboxYyhgcfARMXNUIeLlHivp.Load_Watched_List(SVTBOFnboxYyhgcfARMXNUIeLlHids) 
   fp=SVTBOFnboxYyhgcfARMXNUIeLlHiKs(SVTBOFnboxYyhgcfARMXNUIeLlHirz,'w',-1,'utf-8')
   SVTBOFnboxYyhgcfARMXNUIeLlHiEv=urllib.parse.urlencode(SVTBOFnboxYyhgcfARMXNUIeLlHivW)
   SVTBOFnboxYyhgcfARMXNUIeLlHiEv=SVTBOFnboxYyhgcfARMXNUIeLlHiEv+'\n'
   fp.write(SVTBOFnboxYyhgcfARMXNUIeLlHiEv)
   SVTBOFnboxYyhgcfARMXNUIeLlHiEs=0
   for SVTBOFnboxYyhgcfARMXNUIeLlHiEd in SVTBOFnboxYyhgcfARMXNUIeLlHirD:
    SVTBOFnboxYyhgcfARMXNUIeLlHiEr=SVTBOFnboxYyhgcfARMXNUIeLlHiPC(urllib.parse.parse_qsl(SVTBOFnboxYyhgcfARMXNUIeLlHiEd))
    SVTBOFnboxYyhgcfARMXNUIeLlHiEP=SVTBOFnboxYyhgcfARMXNUIeLlHivW.get('code').strip()
    SVTBOFnboxYyhgcfARMXNUIeLlHiEK=SVTBOFnboxYyhgcfARMXNUIeLlHiEr.get('code').strip()
    if SVTBOFnboxYyhgcfARMXNUIeLlHids=='vod' and SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_settings_direct_replay()==SVTBOFnboxYyhgcfARMXNUIeLlHiPq:
     SVTBOFnboxYyhgcfARMXNUIeLlHiEP=SVTBOFnboxYyhgcfARMXNUIeLlHivW.get('videoid').strip()
     SVTBOFnboxYyhgcfARMXNUIeLlHiEK=SVTBOFnboxYyhgcfARMXNUIeLlHiEr.get('videoid').strip()if SVTBOFnboxYyhgcfARMXNUIeLlHiEK!=SVTBOFnboxYyhgcfARMXNUIeLlHiPt else '-'
    if SVTBOFnboxYyhgcfARMXNUIeLlHiEP!=SVTBOFnboxYyhgcfARMXNUIeLlHiEK:
     fp.write(SVTBOFnboxYyhgcfARMXNUIeLlHiEd)
     SVTBOFnboxYyhgcfARMXNUIeLlHiEs+=1
     if SVTBOFnboxYyhgcfARMXNUIeLlHiEs>=50:break
   fp.close()
  except:
   SVTBOFnboxYyhgcfARMXNUIeLlHiPt
 def dp_Watch_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidP):
  SVTBOFnboxYyhgcfARMXNUIeLlHids =SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('stype')
  SVTBOFnboxYyhgcfARMXNUIeLlHisd=SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_settings_direct_replay()
  if SVTBOFnboxYyhgcfARMXNUIeLlHids=='-':
   for SVTBOFnboxYyhgcfARMXNUIeLlHidE in SVTBOFnboxYyhgcfARMXNUIeLlHivE:
    SVTBOFnboxYyhgcfARMXNUIeLlHisK=SVTBOFnboxYyhgcfARMXNUIeLlHidE.get('title')
    SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':SVTBOFnboxYyhgcfARMXNUIeLlHidE.get('mode'),'stype':SVTBOFnboxYyhgcfARMXNUIeLlHidE.get('stype')}
    SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel='',img='',infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHiPt,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPq,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
   if SVTBOFnboxYyhgcfARMXNUIeLlHiPD(SVTBOFnboxYyhgcfARMXNUIeLlHivE)>0:xbmcplugin.endOfDirectory(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle)
  else:
   SVTBOFnboxYyhgcfARMXNUIeLlHiEk=SVTBOFnboxYyhgcfARMXNUIeLlHivp.Load_Watched_List(SVTBOFnboxYyhgcfARMXNUIeLlHids)
   for SVTBOFnboxYyhgcfARMXNUIeLlHiEJ in SVTBOFnboxYyhgcfARMXNUIeLlHiEk:
    SVTBOFnboxYyhgcfARMXNUIeLlHiEu=SVTBOFnboxYyhgcfARMXNUIeLlHiPC(urllib.parse.parse_qsl(SVTBOFnboxYyhgcfARMXNUIeLlHiEJ))
    SVTBOFnboxYyhgcfARMXNUIeLlHiEp =SVTBOFnboxYyhgcfARMXNUIeLlHiEu.get('code').strip()
    SVTBOFnboxYyhgcfARMXNUIeLlHisK =SVTBOFnboxYyhgcfARMXNUIeLlHiEu.get('title').strip()
    SVTBOFnboxYyhgcfARMXNUIeLlHidp=SVTBOFnboxYyhgcfARMXNUIeLlHiEu.get('img').strip()
    SVTBOFnboxYyhgcfARMXNUIeLlHiEm =SVTBOFnboxYyhgcfARMXNUIeLlHiEu.get('videoid').strip()
    try:
     SVTBOFnboxYyhgcfARMXNUIeLlHidp=SVTBOFnboxYyhgcfARMXNUIeLlHidp.replace('\'','\"')
     SVTBOFnboxYyhgcfARMXNUIeLlHidp=json.loads(SVTBOFnboxYyhgcfARMXNUIeLlHidp)
    except:
     SVTBOFnboxYyhgcfARMXNUIeLlHiPt
    SVTBOFnboxYyhgcfARMXNUIeLlHidq={}
    SVTBOFnboxYyhgcfARMXNUIeLlHidq['plot']=SVTBOFnboxYyhgcfARMXNUIeLlHisK
    if SVTBOFnboxYyhgcfARMXNUIeLlHids=='vod':
     if SVTBOFnboxYyhgcfARMXNUIeLlHisd==SVTBOFnboxYyhgcfARMXNUIeLlHiPj or SVTBOFnboxYyhgcfARMXNUIeLlHiEm==SVTBOFnboxYyhgcfARMXNUIeLlHiPt:
      SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':'EPISODE','programcode':SVTBOFnboxYyhgcfARMXNUIeLlHiEp,'page':'1'}
      SVTBOFnboxYyhgcfARMXNUIeLlHisw=SVTBOFnboxYyhgcfARMXNUIeLlHiPq
     else:
      SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':'VOD','mediacode':SVTBOFnboxYyhgcfARMXNUIeLlHiEm,'stype':'vod','programcode':SVTBOFnboxYyhgcfARMXNUIeLlHiEp,'title':SVTBOFnboxYyhgcfARMXNUIeLlHisK,'thumbnail':SVTBOFnboxYyhgcfARMXNUIeLlHidp}
      SVTBOFnboxYyhgcfARMXNUIeLlHisw=SVTBOFnboxYyhgcfARMXNUIeLlHiPj
    else:
     SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':'MOVIE','mediacode':SVTBOFnboxYyhgcfARMXNUIeLlHiEp,'stype':'movie','title':SVTBOFnboxYyhgcfARMXNUIeLlHisK,'thumbnail':SVTBOFnboxYyhgcfARMXNUIeLlHidp}
     SVTBOFnboxYyhgcfARMXNUIeLlHisw=SVTBOFnboxYyhgcfARMXNUIeLlHiPj
    SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel='',img=SVTBOFnboxYyhgcfARMXNUIeLlHidp,infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHidq,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHisw,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
   SVTBOFnboxYyhgcfARMXNUIeLlHidq={'plot':'시청목록을 삭제합니다.'}
   SVTBOFnboxYyhgcfARMXNUIeLlHisK='*** 시청목록 삭제 ***'
   SVTBOFnboxYyhgcfARMXNUIeLlHisW={'mode':'MYVIEW_REMOVE','stype':SVTBOFnboxYyhgcfARMXNUIeLlHids}
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.add_dir(SVTBOFnboxYyhgcfARMXNUIeLlHisK,sublabel='',img='',infoLabels=SVTBOFnboxYyhgcfARMXNUIeLlHidq,isFolder=SVTBOFnboxYyhgcfARMXNUIeLlHiPj,params=SVTBOFnboxYyhgcfARMXNUIeLlHisW,ContextMenu=SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
   xbmcplugin.endOfDirectory(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle,cacheToDisc=SVTBOFnboxYyhgcfARMXNUIeLlHiPj)
 def play_VIDEO(SVTBOFnboxYyhgcfARMXNUIeLlHivp,SVTBOFnboxYyhgcfARMXNUIeLlHidP):
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.SaveCredential(SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_winCredential())
  SVTBOFnboxYyhgcfARMXNUIeLlHiEW =SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('mediacode')
  SVTBOFnboxYyhgcfARMXNUIeLlHids =SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('stype')
  SVTBOFnboxYyhgcfARMXNUIeLlHiEw =SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('pvrmode')
  SVTBOFnboxYyhgcfARMXNUIeLlHiEa=SVTBOFnboxYyhgcfARMXNUIeLlHivp.get_selQuality(SVTBOFnboxYyhgcfARMXNUIeLlHids)
  SVTBOFnboxYyhgcfARMXNUIeLlHiEt,SVTBOFnboxYyhgcfARMXNUIeLlHiEG=SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.GetBroadURL(SVTBOFnboxYyhgcfARMXNUIeLlHiEW,SVTBOFnboxYyhgcfARMXNUIeLlHiEa,SVTBOFnboxYyhgcfARMXNUIeLlHids,SVTBOFnboxYyhgcfARMXNUIeLlHiEw)
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.addon_log('qt, stype, url : %s - %s - %s'%(SVTBOFnboxYyhgcfARMXNUIeLlHiKv(SVTBOFnboxYyhgcfARMXNUIeLlHiEa),SVTBOFnboxYyhgcfARMXNUIeLlHids,SVTBOFnboxYyhgcfARMXNUIeLlHiEt))
  if SVTBOFnboxYyhgcfARMXNUIeLlHiEt=='':
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.addon_noti(__language__(30908).encode('utf8'))
   return
  SVTBOFnboxYyhgcfARMXNUIeLlHiEj =SVTBOFnboxYyhgcfARMXNUIeLlHiEt.find('Policy=')
  if SVTBOFnboxYyhgcfARMXNUIeLlHiEj!=-1:
   SVTBOFnboxYyhgcfARMXNUIeLlHiEq =SVTBOFnboxYyhgcfARMXNUIeLlHiEt.split('?')[0]
   SVTBOFnboxYyhgcfARMXNUIeLlHiEz=SVTBOFnboxYyhgcfARMXNUIeLlHiPC(urllib.parse.parse_qsl(urllib.parse.urlsplit(SVTBOFnboxYyhgcfARMXNUIeLlHiEt).query))
   SVTBOFnboxYyhgcfARMXNUIeLlHiEz=urllib.parse.urlencode(SVTBOFnboxYyhgcfARMXNUIeLlHiEz)
   SVTBOFnboxYyhgcfARMXNUIeLlHiEz=SVTBOFnboxYyhgcfARMXNUIeLlHiEz.replace('&',';')
   SVTBOFnboxYyhgcfARMXNUIeLlHiEz=SVTBOFnboxYyhgcfARMXNUIeLlHiEz.replace('Policy','CloudFront-Policy')
   SVTBOFnboxYyhgcfARMXNUIeLlHiEz=SVTBOFnboxYyhgcfARMXNUIeLlHiEz.replace('Signature','CloudFront-Signature')
   SVTBOFnboxYyhgcfARMXNUIeLlHiEz=SVTBOFnboxYyhgcfARMXNUIeLlHiEz.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   SVTBOFnboxYyhgcfARMXNUIeLlHiEC='%s|Cookie=%s'%(SVTBOFnboxYyhgcfARMXNUIeLlHiEq,SVTBOFnboxYyhgcfARMXNUIeLlHiEz)
  else:
   SVTBOFnboxYyhgcfARMXNUIeLlHiEC=SVTBOFnboxYyhgcfARMXNUIeLlHiEt
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.addon_log(SVTBOFnboxYyhgcfARMXNUIeLlHiEC)
  SVTBOFnboxYyhgcfARMXNUIeLlHiED=xbmcgui.ListItem(path=SVTBOFnboxYyhgcfARMXNUIeLlHiEC)
  if SVTBOFnboxYyhgcfARMXNUIeLlHiEG!='':
   SVTBOFnboxYyhgcfARMXNUIeLlHiPv=SVTBOFnboxYyhgcfARMXNUIeLlHiEG
   SVTBOFnboxYyhgcfARMXNUIeLlHiPs ='https://cj.drmkeyserver.com/widevine_license'
   SVTBOFnboxYyhgcfARMXNUIeLlHiPd ='mpd'
   SVTBOFnboxYyhgcfARMXNUIeLlHiPr ='com.widevine.alpha'
   SVTBOFnboxYyhgcfARMXNUIeLlHiPE =inputstreamhelper.Helper(SVTBOFnboxYyhgcfARMXNUIeLlHiPd,drm='widevine')
   if SVTBOFnboxYyhgcfARMXNUIeLlHiPE.check_inputstream():
    SVTBOFnboxYyhgcfARMXNUIeLlHiPK={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%SVTBOFnboxYyhgcfARMXNUIeLlHiEW,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.USER_AGENT,'AcquireLicenseAssertion':SVTBOFnboxYyhgcfARMXNUIeLlHiPv,'Host':'cj.drmkeyserver.com'}
    SVTBOFnboxYyhgcfARMXNUIeLlHiPk=SVTBOFnboxYyhgcfARMXNUIeLlHiPs+'|'+urllib.parse.urlencode(SVTBOFnboxYyhgcfARMXNUIeLlHiPK)+'|R{SSM}|'
    SVTBOFnboxYyhgcfARMXNUIeLlHiED.setProperty('inputstream',SVTBOFnboxYyhgcfARMXNUIeLlHiPE.inputstream_addon)
    SVTBOFnboxYyhgcfARMXNUIeLlHiED.setProperty('inputstream.adaptive.manifest_type',SVTBOFnboxYyhgcfARMXNUIeLlHiPd)
    SVTBOFnboxYyhgcfARMXNUIeLlHiED.setProperty('inputstream.adaptive.license_type',SVTBOFnboxYyhgcfARMXNUIeLlHiPr)
    SVTBOFnboxYyhgcfARMXNUIeLlHiED.setProperty('inputstream.adaptive.license_key',SVTBOFnboxYyhgcfARMXNUIeLlHiPk)
    SVTBOFnboxYyhgcfARMXNUIeLlHiED.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.USER_AGENT))
  xbmcplugin.setResolvedUrl(SVTBOFnboxYyhgcfARMXNUIeLlHivp._addon_handle,SVTBOFnboxYyhgcfARMXNUIeLlHiPq,SVTBOFnboxYyhgcfARMXNUIeLlHiED)
  try:
   if SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('mode')in['VOD','MOVIE']and SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('title'):
    SVTBOFnboxYyhgcfARMXNUIeLlHisW={'code':SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('programcode')if SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('mode')=='VOD' else SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('mediacode'),'img':SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('thumbnail'),'title':SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('title'),'videoid':SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('mediacode')}
    SVTBOFnboxYyhgcfARMXNUIeLlHivp.Save_Watched_List(SVTBOFnboxYyhgcfARMXNUIeLlHidP.get('stype'),SVTBOFnboxYyhgcfARMXNUIeLlHisW)
  except:
   SVTBOFnboxYyhgcfARMXNUIeLlHiPt
 def logout(SVTBOFnboxYyhgcfARMXNUIeLlHivp):
  SVTBOFnboxYyhgcfARMXNUIeLlHiva=xbmcgui.Dialog()
  SVTBOFnboxYyhgcfARMXNUIeLlHisz=SVTBOFnboxYyhgcfARMXNUIeLlHiva.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if SVTBOFnboxYyhgcfARMXNUIeLlHisz==SVTBOFnboxYyhgcfARMXNUIeLlHiPj:sys.exit()
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.wininfo_clear()
  if os.path.isfile(SVTBOFnboxYyhgcfARMXNUIeLlHivu):os.remove(SVTBOFnboxYyhgcfARMXNUIeLlHivu)
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(SVTBOFnboxYyhgcfARMXNUIeLlHivp):
  SVTBOFnboxYyhgcfARMXNUIeLlHisr=xbmcgui.Window(10000)
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_TOKEN','')
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_USERINFO','')
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_UUID','')
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_LOGINTIME','')
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_MAINTOKEN','')
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_COOKIEKEY','')
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(SVTBOFnboxYyhgcfARMXNUIeLlHivp):
  SVTBOFnboxYyhgcfARMXNUIeLlHiPJ =SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.Get_Now_Datetime()
  SVTBOFnboxYyhgcfARMXNUIeLlHiPu=SVTBOFnboxYyhgcfARMXNUIeLlHiPJ+datetime.timedelta(days=SVTBOFnboxYyhgcfARMXNUIeLlHiPG(__addon__.getSetting('cache_ttl')))
  SVTBOFnboxYyhgcfARMXNUIeLlHisr=xbmcgui.Window(10000)
  SVTBOFnboxYyhgcfARMXNUIeLlHiPp={'tving_token':SVTBOFnboxYyhgcfARMXNUIeLlHisr.getProperty('TVING_M_TOKEN'),'tving_userinfo':SVTBOFnboxYyhgcfARMXNUIeLlHisr.getProperty('TVING_M_USERINFO'),'tving_uuid':SVTBOFnboxYyhgcfARMXNUIeLlHisr.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':SVTBOFnboxYyhgcfARMXNUIeLlHiPu.strftime('%Y-%m-%d'),'tving_maintoken':SVTBOFnboxYyhgcfARMXNUIeLlHisr.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':SVTBOFnboxYyhgcfARMXNUIeLlHisr.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':SVTBOFnboxYyhgcfARMXNUIeLlHisr.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=SVTBOFnboxYyhgcfARMXNUIeLlHiKs(SVTBOFnboxYyhgcfARMXNUIeLlHivu,'w',-1,'utf-8')
   json.dump(SVTBOFnboxYyhgcfARMXNUIeLlHiPp,fp)
   fp.close()
  except SVTBOFnboxYyhgcfARMXNUIeLlHiKd as exception:
   SVTBOFnboxYyhgcfARMXNUIeLlHiKr(exception)
 def cookiefile_check(SVTBOFnboxYyhgcfARMXNUIeLlHivp):
  SVTBOFnboxYyhgcfARMXNUIeLlHiPp={}
  try: 
   fp=SVTBOFnboxYyhgcfARMXNUIeLlHiKs(SVTBOFnboxYyhgcfARMXNUIeLlHivu,'r',-1,'utf-8')
   SVTBOFnboxYyhgcfARMXNUIeLlHiPp= json.load(fp)
   fp.close()
  except SVTBOFnboxYyhgcfARMXNUIeLlHiKd as exception:
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.wininfo_clear()
   return SVTBOFnboxYyhgcfARMXNUIeLlHiPj
  SVTBOFnboxYyhgcfARMXNUIeLlHist =__addon__.getSetting('id')
  SVTBOFnboxYyhgcfARMXNUIeLlHisG =__addon__.getSetting('pw')
  SVTBOFnboxYyhgcfARMXNUIeLlHiPm=__addon__.getSetting('login_type')
  SVTBOFnboxYyhgcfARMXNUIeLlHiPQ =__addon__.getSetting('selected_profile')
  SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_id']=base64.standard_b64decode(SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_id']).decode('utf-8')
  SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_pw']=base64.standard_b64decode(SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_pw']).decode('utf-8')
  try:
   SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_profile']
  except:
   SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_profile']='0'
  if SVTBOFnboxYyhgcfARMXNUIeLlHist!=SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_id']or SVTBOFnboxYyhgcfARMXNUIeLlHisG!=SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_pw']or SVTBOFnboxYyhgcfARMXNUIeLlHiPm!=SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_logintype']or SVTBOFnboxYyhgcfARMXNUIeLlHiPQ!=SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_profile']:
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.wininfo_clear()
   return SVTBOFnboxYyhgcfARMXNUIeLlHiPj
  SVTBOFnboxYyhgcfARMXNUIeLlHisC =SVTBOFnboxYyhgcfARMXNUIeLlHiPG(SVTBOFnboxYyhgcfARMXNUIeLlHivp.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  SVTBOFnboxYyhgcfARMXNUIeLlHiPW=SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_limitdate']
  SVTBOFnboxYyhgcfARMXNUIeLlHisD =SVTBOFnboxYyhgcfARMXNUIeLlHiPG(re.sub('-','',SVTBOFnboxYyhgcfARMXNUIeLlHiPW))
  if SVTBOFnboxYyhgcfARMXNUIeLlHisD<SVTBOFnboxYyhgcfARMXNUIeLlHisC:
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.wininfo_clear()
   return SVTBOFnboxYyhgcfARMXNUIeLlHiPj
  SVTBOFnboxYyhgcfARMXNUIeLlHisr=xbmcgui.Window(10000)
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_TOKEN',SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_token'])
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_USERINFO',SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_userinfo'])
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_UUID',SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_uuid'])
  SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_LOGINTIME',SVTBOFnboxYyhgcfARMXNUIeLlHiPW)
  try:
   SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_MAINTOKEN',SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_maintoken'])
   SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_COOKIEKEY',SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_cookiekey'])
   SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_LOCKKEY',SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_lockkey'])
  except:
   SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_MAINTOKEN',SVTBOFnboxYyhgcfARMXNUIeLlHiPp['tving_token'])
   SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_COOKIEKEY','Y')
   SVTBOFnboxYyhgcfARMXNUIeLlHisr.setProperty('TVING_M_LOCKKEY','N')
  return SVTBOFnboxYyhgcfARMXNUIeLlHiPq
 def tving_main(SVTBOFnboxYyhgcfARMXNUIeLlHivp):
  SVTBOFnboxYyhgcfARMXNUIeLlHiPw=SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params.get('mode',SVTBOFnboxYyhgcfARMXNUIeLlHiPt)
  if SVTBOFnboxYyhgcfARMXNUIeLlHiPw=='LOGOUT':
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.logout()
   return
  SVTBOFnboxYyhgcfARMXNUIeLlHivp.login_main()
  if SVTBOFnboxYyhgcfARMXNUIeLlHiPw is SVTBOFnboxYyhgcfARMXNUIeLlHiPt:
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.dp_Main_List()
  elif SVTBOFnboxYyhgcfARMXNUIeLlHiPw in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.dp_Title_Group(SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params)
  elif SVTBOFnboxYyhgcfARMXNUIeLlHiPw in['GLOBAL_GROUP']:
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.dp_SubTitle_Group(SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params)
  elif SVTBOFnboxYyhgcfARMXNUIeLlHiPw=='CHANNEL':
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.dp_LiveChannel_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params)
  elif SVTBOFnboxYyhgcfARMXNUIeLlHiPw in['LIVE','VOD','MOVIE']:
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.play_VIDEO(SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params)
  elif SVTBOFnboxYyhgcfARMXNUIeLlHiPw=='PROGRAM':
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.dp_Program_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params)
  elif SVTBOFnboxYyhgcfARMXNUIeLlHiPw=='EPISODE':
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.dp_Episode_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params)
  elif SVTBOFnboxYyhgcfARMXNUIeLlHiPw=='MOVIE_SUB':
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.dp_Movie_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params)
  elif SVTBOFnboxYyhgcfARMXNUIeLlHiPw=='SEARCH_GROUP':
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.dp_Search_Group(SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params)
  elif SVTBOFnboxYyhgcfARMXNUIeLlHiPw=='SEARCH':
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.dp_Search_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params)
  elif SVTBOFnboxYyhgcfARMXNUIeLlHiPw=='WATCH':
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.dp_Watch_List(SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params)
  elif SVTBOFnboxYyhgcfARMXNUIeLlHiPw=='MYVIEW_REMOVE':
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.dp_WatchList_Delete(SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params)
  elif SVTBOFnboxYyhgcfARMXNUIeLlHiPw=='ORDER_BY':
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.dp_setEpOrderby(SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params)
  elif SVTBOFnboxYyhgcfARMXNUIeLlHiPw=='MAKE_STRM':
   SVTBOFnboxYyhgcfARMXNUIeLlHivp.dp_Strm_Make(SVTBOFnboxYyhgcfARMXNUIeLlHivp.main_params)
  else:
   SVTBOFnboxYyhgcfARMXNUIeLlHiPt
# Created by pyminifier (https://github.com/liftoff/pyminifier)
