__author__="NightRain"
OKCnMkvLteiHqAmWcDQgrhGXwajJdx=object
OKCnMkvLteiHqAmWcDQgrhGXwajJdI=None
OKCnMkvLteiHqAmWcDQgrhGXwajJTf=False
OKCnMkvLteiHqAmWcDQgrhGXwajJTP=int
OKCnMkvLteiHqAmWcDQgrhGXwajJTb=range
OKCnMkvLteiHqAmWcDQgrhGXwajJTY=True
OKCnMkvLteiHqAmWcDQgrhGXwajJTd=Exception
OKCnMkvLteiHqAmWcDQgrhGXwajJTs=print
OKCnMkvLteiHqAmWcDQgrhGXwajJTN=str
OKCnMkvLteiHqAmWcDQgrhGXwajJTV=list
OKCnMkvLteiHqAmWcDQgrhGXwajJTS=len
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import random
OKCnMkvLteiHqAmWcDQgrhGXwajJfb={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
OKCnMkvLteiHqAmWcDQgrhGXwajJfY ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class OKCnMkvLteiHqAmWcDQgrhGXwajJfP(OKCnMkvLteiHqAmWcDQgrhGXwajJdx):
 def __init__(OKCnMkvLteiHqAmWcDQgrhGXwajJfd):
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_TOKEN =''
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.POC_USERINFO =''
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_UUID ='-'
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_MAINTOKEN=''
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVIGN_COOKIEKEY=''
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_LOCKKEY =''
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.NETWORKCODE ='CSND0900'
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.OSCODE ='CSOD0900' 
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TELECODE ='CSCD0900'
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.SCREENCODE ='CSSD0100'
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.LIVE_LIMIT =23
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.VOD_LIMIT =20
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.EPISODE_LIMIT =30 
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.SEARCH_LIMIT =30 
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.MOVIE_LIMIT =18
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.API_DOMAIN ='https://api.tving.com'
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN ='https://image.tving.com'
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.SEARCH_DOMAIN ='https://search.tving.com'
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.LOGIN_DOMAIN ='https://user.tving.com'
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.URL_DOMAIN ='https://www.tving.com'
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.MOVIE_LITE =['2610061','2610161','261062']
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36'
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.DEFAULT_HEADER ={'user-agent':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.USER_AGENT}
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,jobtype,OKCnMkvLteiHqAmWcDQgrhGXwajJPR,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,params=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,redirects=OKCnMkvLteiHqAmWcDQgrhGXwajJTf):
  OKCnMkvLteiHqAmWcDQgrhGXwajJfT=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.DEFAULT_HEADER
  if headers:OKCnMkvLteiHqAmWcDQgrhGXwajJfT.update(headers)
  if jobtype=='Get':
   OKCnMkvLteiHqAmWcDQgrhGXwajJfs=requests.get(OKCnMkvLteiHqAmWcDQgrhGXwajJPR,params=params,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJfT,cookies=cookies,allow_redirects=redirects)
  else:
   OKCnMkvLteiHqAmWcDQgrhGXwajJfs=requests.post(OKCnMkvLteiHqAmWcDQgrhGXwajJPR,data=payload,params=params,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJfT,cookies=cookies,allow_redirects=redirects)
  return OKCnMkvLteiHqAmWcDQgrhGXwajJfs
 def makeDefaultCookies(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,vToken=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,vUserinfo=OKCnMkvLteiHqAmWcDQgrhGXwajJdI):
  OKCnMkvLteiHqAmWcDQgrhGXwajJfN={}
  OKCnMkvLteiHqAmWcDQgrhGXwajJfN['_tving_token']=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_TOKEN if vToken==OKCnMkvLteiHqAmWcDQgrhGXwajJdI else vToken
  OKCnMkvLteiHqAmWcDQgrhGXwajJfN['POC_USERINFO']=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.POC_USERINFO if vToken==OKCnMkvLteiHqAmWcDQgrhGXwajJdI else vUserinfo
  if OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_MAINTOKEN!='':OKCnMkvLteiHqAmWcDQgrhGXwajJfN[OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GLOBAL_COOKIENM['tv_maintoken']]=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_MAINTOKEN
  if OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVIGN_COOKIEKEY!='':OKCnMkvLteiHqAmWcDQgrhGXwajJfN[OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GLOBAL_COOKIENM['tv_cookiekey']]=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVIGN_COOKIEKEY
  if OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_LOCKKEY !='':OKCnMkvLteiHqAmWcDQgrhGXwajJfN[OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GLOBAL_COOKIENM['tv_lockkey']] =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_LOCKKEY
  return OKCnMkvLteiHqAmWcDQgrhGXwajJfN
 def getDeviceStr(OKCnMkvLteiHqAmWcDQgrhGXwajJfd):
  OKCnMkvLteiHqAmWcDQgrhGXwajJfV=[]
  OKCnMkvLteiHqAmWcDQgrhGXwajJfV.append('Windows') 
  OKCnMkvLteiHqAmWcDQgrhGXwajJfV.append('Chrome') 
  OKCnMkvLteiHqAmWcDQgrhGXwajJfV.append('ko-KR') 
  OKCnMkvLteiHqAmWcDQgrhGXwajJfV.append('undefined') 
  OKCnMkvLteiHqAmWcDQgrhGXwajJfV.append('24') 
  OKCnMkvLteiHqAmWcDQgrhGXwajJfV.append(u'한국 표준시')
  OKCnMkvLteiHqAmWcDQgrhGXwajJfV.append('undefined') 
  OKCnMkvLteiHqAmWcDQgrhGXwajJfV.append('undefined') 
  OKCnMkvLteiHqAmWcDQgrhGXwajJfV.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  OKCnMkvLteiHqAmWcDQgrhGXwajJfS=''
  for OKCnMkvLteiHqAmWcDQgrhGXwajJfz in OKCnMkvLteiHqAmWcDQgrhGXwajJfV:
   OKCnMkvLteiHqAmWcDQgrhGXwajJfS+=OKCnMkvLteiHqAmWcDQgrhGXwajJfz+'|'
  return OKCnMkvLteiHqAmWcDQgrhGXwajJfS
 def SaveCredential(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,OKCnMkvLteiHqAmWcDQgrhGXwajJfF):
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_TOKEN =OKCnMkvLteiHqAmWcDQgrhGXwajJfF.get('tving_token')
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.POC_USERINFO =OKCnMkvLteiHqAmWcDQgrhGXwajJfF.get('poc_userinfo')
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_UUID =OKCnMkvLteiHqAmWcDQgrhGXwajJfF.get('tving_uuid')
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_MAINTOKEN=OKCnMkvLteiHqAmWcDQgrhGXwajJfF.get('tving_maintoken')
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVIGN_COOKIEKEY=OKCnMkvLteiHqAmWcDQgrhGXwajJfF.get('tving_cookiekey')
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_LOCKKEY =OKCnMkvLteiHqAmWcDQgrhGXwajJfF.get('tving_lockkey')
 def LoadCredential(OKCnMkvLteiHqAmWcDQgrhGXwajJfd):
  OKCnMkvLteiHqAmWcDQgrhGXwajJfF={'tving_token':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_TOKEN,'poc_userinfo':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.POC_USERINFO,'tving_uuid':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_UUID,'tving_maintoken':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_MAINTOKEN,'tving_cookiekey':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVIGN_COOKIEKEY,'tving_lockkey':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_LOCKKEY}
  return OKCnMkvLteiHqAmWcDQgrhGXwajJfF
 def GetDefaultParams(OKCnMkvLteiHqAmWcDQgrhGXwajJfd):
  OKCnMkvLteiHqAmWcDQgrhGXwajJfo={'apiKey':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.APIKEY,'networkCode':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.NETWORKCODE,'osCode':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.OSCODE,'teleCode':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TELECODE,'screenCode':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.SCREENCODE}
  return OKCnMkvLteiHqAmWcDQgrhGXwajJfo
 def GetNoCache(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,timetype=1):
  if timetype==1:
   return OKCnMkvLteiHqAmWcDQgrhGXwajJTP(time.time())
  else:
   return OKCnMkvLteiHqAmWcDQgrhGXwajJTP(time.time()*1000)
 def GetUniqueid(OKCnMkvLteiHqAmWcDQgrhGXwajJfd):
  OKCnMkvLteiHqAmWcDQgrhGXwajJfR=[0 for i in OKCnMkvLteiHqAmWcDQgrhGXwajJTb(256)]
  for i in OKCnMkvLteiHqAmWcDQgrhGXwajJTb(256):
   OKCnMkvLteiHqAmWcDQgrhGXwajJfR[i]='%02x'%(i)
  OKCnMkvLteiHqAmWcDQgrhGXwajJfE=OKCnMkvLteiHqAmWcDQgrhGXwajJTP(4294967295*random.random())|0
  OKCnMkvLteiHqAmWcDQgrhGXwajJfl=OKCnMkvLteiHqAmWcDQgrhGXwajJfR[255&OKCnMkvLteiHqAmWcDQgrhGXwajJfE]+OKCnMkvLteiHqAmWcDQgrhGXwajJfR[OKCnMkvLteiHqAmWcDQgrhGXwajJfE>>8&255]+OKCnMkvLteiHqAmWcDQgrhGXwajJfR[OKCnMkvLteiHqAmWcDQgrhGXwajJfE>>16&255]+OKCnMkvLteiHqAmWcDQgrhGXwajJfR[OKCnMkvLteiHqAmWcDQgrhGXwajJfE>>24&255]
  return OKCnMkvLteiHqAmWcDQgrhGXwajJfl
 def GetCredential(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,user_id,user_pw,login_type,user_pf):
  OKCnMkvLteiHqAmWcDQgrhGXwajJfy=OKCnMkvLteiHqAmWcDQgrhGXwajJTf
  OKCnMkvLteiHqAmWcDQgrhGXwajJfu=OKCnMkvLteiHqAmWcDQgrhGXwajJPf=OKCnMkvLteiHqAmWcDQgrhGXwajJPb=OKCnMkvLteiHqAmWcDQgrhGXwajJPY=OKCnMkvLteiHqAmWcDQgrhGXwajJPd='' 
  OKCnMkvLteiHqAmWcDQgrhGXwajJfp ='-'
  try:
   OKCnMkvLteiHqAmWcDQgrhGXwajJfU=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   OKCnMkvLteiHqAmWcDQgrhGXwajJfB={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   OKCnMkvLteiHqAmWcDQgrhGXwajJfx=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.callRequestCookies('Post',OKCnMkvLteiHqAmWcDQgrhGXwajJfU,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJfB,params=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJdI)
   for OKCnMkvLteiHqAmWcDQgrhGXwajJfI in OKCnMkvLteiHqAmWcDQgrhGXwajJfx.cookies:
    if OKCnMkvLteiHqAmWcDQgrhGXwajJfI.name=='_tving_token':
     OKCnMkvLteiHqAmWcDQgrhGXwajJPf=OKCnMkvLteiHqAmWcDQgrhGXwajJfI.value
    elif OKCnMkvLteiHqAmWcDQgrhGXwajJfI.name=='POC_USERINFO':
     OKCnMkvLteiHqAmWcDQgrhGXwajJPb=OKCnMkvLteiHqAmWcDQgrhGXwajJfI.value
   if OKCnMkvLteiHqAmWcDQgrhGXwajJPf=='':return OKCnMkvLteiHqAmWcDQgrhGXwajJfy
   OKCnMkvLteiHqAmWcDQgrhGXwajJfu=OKCnMkvLteiHqAmWcDQgrhGXwajJPf
   OKCnMkvLteiHqAmWcDQgrhGXwajJPf,OKCnMkvLteiHqAmWcDQgrhGXwajJPY,OKCnMkvLteiHqAmWcDQgrhGXwajJPd=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetProfileToken(OKCnMkvLteiHqAmWcDQgrhGXwajJPf,OKCnMkvLteiHqAmWcDQgrhGXwajJPb,user_pf)
   OKCnMkvLteiHqAmWcDQgrhGXwajJfy=OKCnMkvLteiHqAmWcDQgrhGXwajJTY
   OKCnMkvLteiHqAmWcDQgrhGXwajJfp =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetDeviceList(OKCnMkvLteiHqAmWcDQgrhGXwajJPf,OKCnMkvLteiHqAmWcDQgrhGXwajJPb)
   OKCnMkvLteiHqAmWcDQgrhGXwajJfp =OKCnMkvLteiHqAmWcDQgrhGXwajJfp+'-'+OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetUniqueid()
  except OKCnMkvLteiHqAmWcDQgrhGXwajJTd as exception:
   OKCnMkvLteiHqAmWcDQgrhGXwajJfu=OKCnMkvLteiHqAmWcDQgrhGXwajJPf=OKCnMkvLteiHqAmWcDQgrhGXwajJPb=OKCnMkvLteiHqAmWcDQgrhGXwajJPY=OKCnMkvLteiHqAmWcDQgrhGXwajJPd=''
   OKCnMkvLteiHqAmWcDQgrhGXwajJfp='-'
   OKCnMkvLteiHqAmWcDQgrhGXwajJTs(exception)
  OKCnMkvLteiHqAmWcDQgrhGXwajJfF={'tving_token':OKCnMkvLteiHqAmWcDQgrhGXwajJPf,'poc_userinfo':OKCnMkvLteiHqAmWcDQgrhGXwajJPb,'tving_uuid':OKCnMkvLteiHqAmWcDQgrhGXwajJfp,'tving_maintoken':OKCnMkvLteiHqAmWcDQgrhGXwajJfu,'tving_cookiekey':OKCnMkvLteiHqAmWcDQgrhGXwajJPY,'tving_lockkey':OKCnMkvLteiHqAmWcDQgrhGXwajJPd}
  OKCnMkvLteiHqAmWcDQgrhGXwajJfd.SaveCredential(OKCnMkvLteiHqAmWcDQgrhGXwajJfF)
  return OKCnMkvLteiHqAmWcDQgrhGXwajJfy
 def Get_Now_Datetime(OKCnMkvLteiHqAmWcDQgrhGXwajJfd):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,mediacode,sel_quality,stype,pvrmode='-'):
  OKCnMkvLteiHqAmWcDQgrhGXwajJPs=''
  OKCnMkvLteiHqAmWcDQgrhGXwajJPN=''
  OKCnMkvLteiHqAmWcDQgrhGXwajJPV =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_UUID.split('-')[0] 
  OKCnMkvLteiHqAmWcDQgrhGXwajJPS =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.TVING_UUID 
  if mediacode=='C01345':
   OKCnMkvLteiHqAmWcDQgrhGXwajJPs='http://ocn-mcdn.tving.com/ocn/live5000.smil/playlist.m3u8?Policy=eyJTdGF0ZW1lbnQiOiBbeyJSZXNvdXJjZSI6Imh0dHA6Ly8qIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNjEwODMwODAwfSwiSXBBZGRyZXNzIjp7IkFXUzpTb3VyY2VJcCI6IjAuMC4wLjAvMCJ9fX1dfQ__&Signature=eqJMOA5c~hIlgUVIDOtLCCfKXnNO0XHex3uQVQE87ZfuutuH2hqAgddlijKNWDz2Qrg5ScRkuXuU-7QQoj4QFSPPjyvwJSSrrZtNNVxU8xERXywdUKUwQGfDvl78F4rhS7WP-O1Q86KnLwif9QW0GPRK~n8ceOITlYq22rVLqp~EKwmoGQ3cvw01TMBFRInvobRtXR-zGyMZCx9MDgeHMRay0U9Ibp7nUPb3~T~set~W3so1ovUnF0iLuQpuarXQA3QIBy25O24NVbwalTtzjPoULkpEHeuVsMx-ACom3MTM65kB5TKJNIx19sdlAFQIII7n39FpWgSOO6A8jvu~rA__&Key-Pair-Id=APKAIXCIJCFRGOUEZDWA'
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    OKCnMkvLteiHqAmWcDQgrhGXwajJPz ='/v2a/media/stream/info' 
    OKCnMkvLteiHqAmWcDQgrhGXwajJPF=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetDefaultParams()
    OKCnMkvLteiHqAmWcDQgrhGXwajJPo={'info':'N','mediaCode':mediacode,'noCache':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':OKCnMkvLteiHqAmWcDQgrhGXwajJPV,'uuid':OKCnMkvLteiHqAmWcDQgrhGXwajJPS,'deviceInfo':'PC','wm':'Y'}
    OKCnMkvLteiHqAmWcDQgrhGXwajJPF.update(OKCnMkvLteiHqAmWcDQgrhGXwajJPo)
    OKCnMkvLteiHqAmWcDQgrhGXwajJPR=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.API_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPz
    OKCnMkvLteiHqAmWcDQgrhGXwajJfN=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.makeDefaultCookies()
    OKCnMkvLteiHqAmWcDQgrhGXwajJfx=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.callRequestCookies('Get',OKCnMkvLteiHqAmWcDQgrhGXwajJPR,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,params=OKCnMkvLteiHqAmWcDQgrhGXwajJPF,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJfN)
    OKCnMkvLteiHqAmWcDQgrhGXwajJPE=json.loads(OKCnMkvLteiHqAmWcDQgrhGXwajJfx.text)
    if not('stream' in OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']):return OKCnMkvLteiHqAmWcDQgrhGXwajJPs,OKCnMkvLteiHqAmWcDQgrhGXwajJPN 
    OKCnMkvLteiHqAmWcDQgrhGXwajJPl=OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']['stream']
    OKCnMkvLteiHqAmWcDQgrhGXwajJPy=OKCnMkvLteiHqAmWcDQgrhGXwajJPl['quality']
    OKCnMkvLteiHqAmWcDQgrhGXwajJPu=[]
    for OKCnMkvLteiHqAmWcDQgrhGXwajJPp in OKCnMkvLteiHqAmWcDQgrhGXwajJPy:
     if OKCnMkvLteiHqAmWcDQgrhGXwajJPp['active']=='Y':
      OKCnMkvLteiHqAmWcDQgrhGXwajJPu.append({OKCnMkvLteiHqAmWcDQgrhGXwajJfb.get(OKCnMkvLteiHqAmWcDQgrhGXwajJPp['code']):OKCnMkvLteiHqAmWcDQgrhGXwajJPp['code']})
    OKCnMkvLteiHqAmWcDQgrhGXwajJPU=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.CheckQuality(sel_quality,OKCnMkvLteiHqAmWcDQgrhGXwajJPu)
   else:
    for OKCnMkvLteiHqAmWcDQgrhGXwajJPB,OKCnMkvLteiHqAmWcDQgrhGXwajJbs in OKCnMkvLteiHqAmWcDQgrhGXwajJfb.items():
     if OKCnMkvLteiHqAmWcDQgrhGXwajJbs==sel_quality:
      OKCnMkvLteiHqAmWcDQgrhGXwajJPU=OKCnMkvLteiHqAmWcDQgrhGXwajJPB
  except OKCnMkvLteiHqAmWcDQgrhGXwajJTd as exception:
   OKCnMkvLteiHqAmWcDQgrhGXwajJTs(exception)
   for OKCnMkvLteiHqAmWcDQgrhGXwajJPB,OKCnMkvLteiHqAmWcDQgrhGXwajJbs in OKCnMkvLteiHqAmWcDQgrhGXwajJfb.items():
    if OKCnMkvLteiHqAmWcDQgrhGXwajJbs==sel_quality:
     OKCnMkvLteiHqAmWcDQgrhGXwajJPU=OKCnMkvLteiHqAmWcDQgrhGXwajJPB
   return OKCnMkvLteiHqAmWcDQgrhGXwajJPs,OKCnMkvLteiHqAmWcDQgrhGXwajJPN
  OKCnMkvLteiHqAmWcDQgrhGXwajJTs(OKCnMkvLteiHqAmWcDQgrhGXwajJPU)
  try:
   OKCnMkvLteiHqAmWcDQgrhGXwajJPz ='/streaming/info'
   OKCnMkvLteiHqAmWcDQgrhGXwajJPF=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetDefaultParams()
   if stype=='onair':OKCnMkvLteiHqAmWcDQgrhGXwajJPF['osCode']='CSOD0400' 
   OKCnMkvLteiHqAmWcDQgrhGXwajJPx={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   OKCnMkvLteiHqAmWcDQgrhGXwajJPI=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.makeOocUrl(OKCnMkvLteiHqAmWcDQgrhGXwajJPx)
   OKCnMkvLteiHqAmWcDQgrhGXwajJbf=urllib.parse.quote(OKCnMkvLteiHqAmWcDQgrhGXwajJPI)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPo={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':OKCnMkvLteiHqAmWcDQgrhGXwajJPU,'adReq':'adproxy','ooc':OKCnMkvLteiHqAmWcDQgrhGXwajJPI,'deviceId':OKCnMkvLteiHqAmWcDQgrhGXwajJPV,'uuid':OKCnMkvLteiHqAmWcDQgrhGXwajJPS,'deviceInfo':'PC'}
   OKCnMkvLteiHqAmWcDQgrhGXwajJbP =OKCnMkvLteiHqAmWcDQgrhGXwajJPF
   OKCnMkvLteiHqAmWcDQgrhGXwajJbP.update(OKCnMkvLteiHqAmWcDQgrhGXwajJPo)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPR=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.URL_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPz
   OKCnMkvLteiHqAmWcDQgrhGXwajJbY={'origin':'https://www.tving.com'}
   if stype=='onair':OKCnMkvLteiHqAmWcDQgrhGXwajJbY['Referer']='https://www.tving.com/live/player/'+mediacode
   else: OKCnMkvLteiHqAmWcDQgrhGXwajJbY['Referer']='https://www.tving.com/vod/player/'+mediacode
   OKCnMkvLteiHqAmWcDQgrhGXwajJfN=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.makeDefaultCookies()
   OKCnMkvLteiHqAmWcDQgrhGXwajJfN['onClickEvent2']=OKCnMkvLteiHqAmWcDQgrhGXwajJbf
   OKCnMkvLteiHqAmWcDQgrhGXwajJfx=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.callRequestCookies('Post',OKCnMkvLteiHqAmWcDQgrhGXwajJPR,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJbP,params=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJbY,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJfN,redirects=OKCnMkvLteiHqAmWcDQgrhGXwajJTf)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPE=json.loads(OKCnMkvLteiHqAmWcDQgrhGXwajJfx.text)
   if 'drm_license_assertion' in OKCnMkvLteiHqAmWcDQgrhGXwajJPE['stream']:
    OKCnMkvLteiHqAmWcDQgrhGXwajJPN =OKCnMkvLteiHqAmWcDQgrhGXwajJPE['stream']['drm_license_assertion']
    OKCnMkvLteiHqAmWcDQgrhGXwajJPs=OKCnMkvLteiHqAmWcDQgrhGXwajJPE['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in OKCnMkvLteiHqAmWcDQgrhGXwajJPE['stream']['broadcast']):return OKCnMkvLteiHqAmWcDQgrhGXwajJPs,OKCnMkvLteiHqAmWcDQgrhGXwajJPN
    OKCnMkvLteiHqAmWcDQgrhGXwajJPs=OKCnMkvLteiHqAmWcDQgrhGXwajJPE['stream']['broadcast']['broad_url']
  except OKCnMkvLteiHqAmWcDQgrhGXwajJTd as exception:
   OKCnMkvLteiHqAmWcDQgrhGXwajJTs(exception)
  return OKCnMkvLteiHqAmWcDQgrhGXwajJPs,OKCnMkvLteiHqAmWcDQgrhGXwajJPN
 def CheckQuality(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,sel_qt,OKCnMkvLteiHqAmWcDQgrhGXwajJPu):
  for OKCnMkvLteiHqAmWcDQgrhGXwajJbd in OKCnMkvLteiHqAmWcDQgrhGXwajJPu:
   if sel_qt>=OKCnMkvLteiHqAmWcDQgrhGXwajJTV(OKCnMkvLteiHqAmWcDQgrhGXwajJbd)[0]:return OKCnMkvLteiHqAmWcDQgrhGXwajJbd.get(OKCnMkvLteiHqAmWcDQgrhGXwajJTV(OKCnMkvLteiHqAmWcDQgrhGXwajJbd)[0])
   OKCnMkvLteiHqAmWcDQgrhGXwajJbT=OKCnMkvLteiHqAmWcDQgrhGXwajJbd.get(OKCnMkvLteiHqAmWcDQgrhGXwajJTV(OKCnMkvLteiHqAmWcDQgrhGXwajJbd)[0])
  return OKCnMkvLteiHqAmWcDQgrhGXwajJbT
 def makeOocUrl(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,OKCnMkvLteiHqAmWcDQgrhGXwajJPx):
  OKCnMkvLteiHqAmWcDQgrhGXwajJPR=''
  for OKCnMkvLteiHqAmWcDQgrhGXwajJPB,OKCnMkvLteiHqAmWcDQgrhGXwajJbs in OKCnMkvLteiHqAmWcDQgrhGXwajJPx.items():
   OKCnMkvLteiHqAmWcDQgrhGXwajJPR+="%s=%s^"%(OKCnMkvLteiHqAmWcDQgrhGXwajJPB,OKCnMkvLteiHqAmWcDQgrhGXwajJbs)
  return OKCnMkvLteiHqAmWcDQgrhGXwajJPR
 def GetLiveChannelList(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,stype,page_int):
  OKCnMkvLteiHqAmWcDQgrhGXwajJbN=[]
  OKCnMkvLteiHqAmWcDQgrhGXwajJbV=OKCnMkvLteiHqAmWcDQgrhGXwajJTf
  OKCnMkvLteiHqAmWcDQgrhGXwajJbS=OKCnMkvLteiHqAmWcDQgrhGXwajJTf
  try:
   OKCnMkvLteiHqAmWcDQgrhGXwajJPz ='/v2/media/lives'
   if stype=='onair': 
    OKCnMkvLteiHqAmWcDQgrhGXwajJbz='CPCS0100,CPCS0400'
   else:
    OKCnMkvLteiHqAmWcDQgrhGXwajJbz='CPCS0300'
   OKCnMkvLteiHqAmWcDQgrhGXwajJPF=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetDefaultParams()
   OKCnMkvLteiHqAmWcDQgrhGXwajJPo={'pageNo':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(page_int),'pageSize':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':OKCnMkvLteiHqAmWcDQgrhGXwajJbz,'_':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetNoCache(2))}
   OKCnMkvLteiHqAmWcDQgrhGXwajJPF.update(OKCnMkvLteiHqAmWcDQgrhGXwajJPo)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPR=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.API_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPz
   OKCnMkvLteiHqAmWcDQgrhGXwajJfx=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.callRequestCookies('Get',OKCnMkvLteiHqAmWcDQgrhGXwajJPR,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,params=OKCnMkvLteiHqAmWcDQgrhGXwajJPF,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJdI)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPE=json.loads(OKCnMkvLteiHqAmWcDQgrhGXwajJfx.text)
   if not('result' in OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']):return OKCnMkvLteiHqAmWcDQgrhGXwajJbN,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
   OKCnMkvLteiHqAmWcDQgrhGXwajJbF=OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']['result']
   for OKCnMkvLteiHqAmWcDQgrhGXwajJPp in OKCnMkvLteiHqAmWcDQgrhGXwajJbF:
    OKCnMkvLteiHqAmWcDQgrhGXwajJbo=OKCnMkvLteiHqAmWcDQgrhGXwajJbl=OKCnMkvLteiHqAmWcDQgrhGXwajJby=''
    OKCnMkvLteiHqAmWcDQgrhGXwajJbR=OKCnMkvLteiHqAmWcDQgrhGXwajJYF=''
    OKCnMkvLteiHqAmWcDQgrhGXwajJbE=OKCnMkvLteiHqAmWcDQgrhGXwajJPp['live_code']
    if OKCnMkvLteiHqAmWcDQgrhGXwajJbE=='C01345':OKCnMkvLteiHqAmWcDQgrhGXwajJbS=OKCnMkvLteiHqAmWcDQgrhGXwajJTY 
    OKCnMkvLteiHqAmWcDQgrhGXwajJbo =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['channel']['name']['ko']
    if OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['episode']!=OKCnMkvLteiHqAmWcDQgrhGXwajJdI:
     OKCnMkvLteiHqAmWcDQgrhGXwajJbl =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['program']['name']['ko']
     OKCnMkvLteiHqAmWcDQgrhGXwajJbl =OKCnMkvLteiHqAmWcDQgrhGXwajJbl+', '+OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['episode']['frequency'])+'회'
     OKCnMkvLteiHqAmWcDQgrhGXwajJby=OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['episode']['synopsis']['ko']
    else:
     OKCnMkvLteiHqAmWcDQgrhGXwajJbl =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['program']['name']['ko']
     OKCnMkvLteiHqAmWcDQgrhGXwajJby=OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['program']['synopsis']['ko']
    try: 
     OKCnMkvLteiHqAmWcDQgrhGXwajJbu =''
     OKCnMkvLteiHqAmWcDQgrhGXwajJbp =''
     OKCnMkvLteiHqAmWcDQgrhGXwajJbU=''
     OKCnMkvLteiHqAmWcDQgrhGXwajJbB =''
     OKCnMkvLteiHqAmWcDQgrhGXwajJbx =''
     OKCnMkvLteiHqAmWcDQgrhGXwajJbI =''
     for OKCnMkvLteiHqAmWcDQgrhGXwajJYf in OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['program']['image']:
      if OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP0900':OKCnMkvLteiHqAmWcDQgrhGXwajJbp =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
      elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP1800':OKCnMkvLteiHqAmWcDQgrhGXwajJbU=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
      elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP2000':OKCnMkvLteiHqAmWcDQgrhGXwajJbB =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
      elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP1900':OKCnMkvLteiHqAmWcDQgrhGXwajJbx =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
      elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP0200':OKCnMkvLteiHqAmWcDQgrhGXwajJbI =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
      elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP0500':OKCnMkvLteiHqAmWcDQgrhGXwajJbu =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
      elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP0800':OKCnMkvLteiHqAmWcDQgrhGXwajJbu =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
     if OKCnMkvLteiHqAmWcDQgrhGXwajJbu=='':
      for OKCnMkvLteiHqAmWcDQgrhGXwajJYf in OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['channel']['image']:
       if OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIC0400':OKCnMkvLteiHqAmWcDQgrhGXwajJbu =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
       elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIC1400':OKCnMkvLteiHqAmWcDQgrhGXwajJbu =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
       elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIC1900':OKCnMkvLteiHqAmWcDQgrhGXwajJbu =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
    except:
     OKCnMkvLteiHqAmWcDQgrhGXwajJdI
    try:
     OKCnMkvLteiHqAmWcDQgrhGXwajJYP =[]
     OKCnMkvLteiHqAmWcDQgrhGXwajJYb=[]
     OKCnMkvLteiHqAmWcDQgrhGXwajJYd =[]
     OKCnMkvLteiHqAmWcDQgrhGXwajJYT=''
     OKCnMkvLteiHqAmWcDQgrhGXwajJYs=''
     OKCnMkvLteiHqAmWcDQgrhGXwajJYN=''
     for OKCnMkvLteiHqAmWcDQgrhGXwajJYV in OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('schedule').get('program').get('actor'):
      if OKCnMkvLteiHqAmWcDQgrhGXwajJYV!='' and OKCnMkvLteiHqAmWcDQgrhGXwajJYV!=u'없음':OKCnMkvLteiHqAmWcDQgrhGXwajJYP.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYV)
     for OKCnMkvLteiHqAmWcDQgrhGXwajJYS in OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('schedule').get('program').get('director'):
      if OKCnMkvLteiHqAmWcDQgrhGXwajJYS!='' and OKCnMkvLteiHqAmWcDQgrhGXwajJYS!='-' and OKCnMkvLteiHqAmWcDQgrhGXwajJYS!=u'없음':OKCnMkvLteiHqAmWcDQgrhGXwajJYb.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYS)
     if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('schedule').get('program').get('category1_name').get('ko')!='':
      OKCnMkvLteiHqAmWcDQgrhGXwajJYd.append(OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['program']['category1_name']['ko'])
     if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('schedule').get('program').get('category2_name').get('ko')!='':
      OKCnMkvLteiHqAmWcDQgrhGXwajJYd.append(OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['program']['category2_name']['ko'])
     if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('schedule').get('program').get('product_year'):OKCnMkvLteiHqAmWcDQgrhGXwajJYT=OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['program']['product_year']
     if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('schedule').get('program').get('grade_code') :OKCnMkvLteiHqAmWcDQgrhGXwajJYs= OKCnMkvLteiHqAmWcDQgrhGXwajJfY.get(OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['program']['grade_code'])
     if 'broad_dt' in OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('schedule').get('program'):
      OKCnMkvLteiHqAmWcDQgrhGXwajJYz =OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('schedule').get('program').get('broad_dt')
      OKCnMkvLteiHqAmWcDQgrhGXwajJYN='%s-%s-%s'%(OKCnMkvLteiHqAmWcDQgrhGXwajJYz[:4],OKCnMkvLteiHqAmWcDQgrhGXwajJYz[4:6],OKCnMkvLteiHqAmWcDQgrhGXwajJYz[6:])
    except:
     OKCnMkvLteiHqAmWcDQgrhGXwajJdI
    OKCnMkvLteiHqAmWcDQgrhGXwajJbR=OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['broadcast_start_time'])[8:12]
    OKCnMkvLteiHqAmWcDQgrhGXwajJYF =OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJPp['schedule']['broadcast_end_time'])[8:12]
    OKCnMkvLteiHqAmWcDQgrhGXwajJYo={'channel':OKCnMkvLteiHqAmWcDQgrhGXwajJbo,'title':OKCnMkvLteiHqAmWcDQgrhGXwajJbl,'mediacode':OKCnMkvLteiHqAmWcDQgrhGXwajJbE,'thumbnail':{'poster':OKCnMkvLteiHqAmWcDQgrhGXwajJbp,'thumb':OKCnMkvLteiHqAmWcDQgrhGXwajJbu,'clearlogo':OKCnMkvLteiHqAmWcDQgrhGXwajJbU,'icon':OKCnMkvLteiHqAmWcDQgrhGXwajJbB,'fanart':OKCnMkvLteiHqAmWcDQgrhGXwajJbI},'synopsis':OKCnMkvLteiHqAmWcDQgrhGXwajJby,'channelepg':' [%s:%s ~ %s:%s]'%(OKCnMkvLteiHqAmWcDQgrhGXwajJbR[0:2],OKCnMkvLteiHqAmWcDQgrhGXwajJbR[2:],OKCnMkvLteiHqAmWcDQgrhGXwajJYF[0:2],OKCnMkvLteiHqAmWcDQgrhGXwajJYF[2:]),'cast':OKCnMkvLteiHqAmWcDQgrhGXwajJYP,'director':OKCnMkvLteiHqAmWcDQgrhGXwajJYb,'info_genre':OKCnMkvLteiHqAmWcDQgrhGXwajJYd,'year':OKCnMkvLteiHqAmWcDQgrhGXwajJYT,'mpaa':OKCnMkvLteiHqAmWcDQgrhGXwajJYs,'premiered':OKCnMkvLteiHqAmWcDQgrhGXwajJYN}
    OKCnMkvLteiHqAmWcDQgrhGXwajJbN.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYo)
   if OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']['has_more']=='Y':
    OKCnMkvLteiHqAmWcDQgrhGXwajJbV=OKCnMkvLteiHqAmWcDQgrhGXwajJTY
   else:
    OKCnMkvLteiHqAmWcDQgrhGXwajJYo={'channel':'OCN Original','title':'temp','mediacode':'C01345','thumbnail':'http://image.tving.com/upload/cms/caic/CAIC0400/C01345.png','cast':[],'director':[]}
  except OKCnMkvLteiHqAmWcDQgrhGXwajJTd as exception:
   OKCnMkvLteiHqAmWcDQgrhGXwajJTs(exception)
  return OKCnMkvLteiHqAmWcDQgrhGXwajJbN,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
 def GetProgramList(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,genre,orderby,page_int,genreCode='all'):
  OKCnMkvLteiHqAmWcDQgrhGXwajJbN=[]
  OKCnMkvLteiHqAmWcDQgrhGXwajJbV=OKCnMkvLteiHqAmWcDQgrhGXwajJTf
  try:
   OKCnMkvLteiHqAmWcDQgrhGXwajJPz ='/v2/media/episodes'
   OKCnMkvLteiHqAmWcDQgrhGXwajJPF=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetDefaultParams()
   OKCnMkvLteiHqAmWcDQgrhGXwajJPo={'pageNo':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(page_int),'pageSize':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetNoCache(2))}
   if genre !='all':OKCnMkvLteiHqAmWcDQgrhGXwajJPo['categoryCode']=genre
   if genreCode!='all':OKCnMkvLteiHqAmWcDQgrhGXwajJPo['genreCode'] =genreCode 
   OKCnMkvLteiHqAmWcDQgrhGXwajJPF.update(OKCnMkvLteiHqAmWcDQgrhGXwajJPo)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPR=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.API_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPz
   OKCnMkvLteiHqAmWcDQgrhGXwajJfx=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.callRequestCookies('Get',OKCnMkvLteiHqAmWcDQgrhGXwajJPR,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,params=OKCnMkvLteiHqAmWcDQgrhGXwajJPF,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJdI)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPE=json.loads(OKCnMkvLteiHqAmWcDQgrhGXwajJfx.text)
   if not('result' in OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']):return OKCnMkvLteiHqAmWcDQgrhGXwajJbN,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
   OKCnMkvLteiHqAmWcDQgrhGXwajJbF=OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']['result']
   for OKCnMkvLteiHqAmWcDQgrhGXwajJPp in OKCnMkvLteiHqAmWcDQgrhGXwajJbF:
    OKCnMkvLteiHqAmWcDQgrhGXwajJYR=OKCnMkvLteiHqAmWcDQgrhGXwajJPp['program']['code']
    OKCnMkvLteiHqAmWcDQgrhGXwajJbl =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['program']['name']['ko']
    OKCnMkvLteiHqAmWcDQgrhGXwajJYs =OKCnMkvLteiHqAmWcDQgrhGXwajJfY.get(OKCnMkvLteiHqAmWcDQgrhGXwajJPp['program'].get('grade_code'))
    OKCnMkvLteiHqAmWcDQgrhGXwajJbp =''
    OKCnMkvLteiHqAmWcDQgrhGXwajJbu =''
    OKCnMkvLteiHqAmWcDQgrhGXwajJbU=''
    OKCnMkvLteiHqAmWcDQgrhGXwajJbB =''
    OKCnMkvLteiHqAmWcDQgrhGXwajJbx =''
    for OKCnMkvLteiHqAmWcDQgrhGXwajJYf in OKCnMkvLteiHqAmWcDQgrhGXwajJPp['program']['image']:
     if OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP0900':OKCnMkvLteiHqAmWcDQgrhGXwajJbp =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
     elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP0200':OKCnMkvLteiHqAmWcDQgrhGXwajJbu =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
     elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP1800':OKCnMkvLteiHqAmWcDQgrhGXwajJbU=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
     elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP2000':OKCnMkvLteiHqAmWcDQgrhGXwajJbB =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
     elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP1900':OKCnMkvLteiHqAmWcDQgrhGXwajJbx =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
    OKCnMkvLteiHqAmWcDQgrhGXwajJby =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['program']['synopsis']['ko']
    try:
     OKCnMkvLteiHqAmWcDQgrhGXwajJYE=OKCnMkvLteiHqAmWcDQgrhGXwajJPp['channel']['name']['ko']
    except:
     OKCnMkvLteiHqAmWcDQgrhGXwajJYE=''
    try:
     OKCnMkvLteiHqAmWcDQgrhGXwajJYP =[]
     OKCnMkvLteiHqAmWcDQgrhGXwajJYb=[]
     OKCnMkvLteiHqAmWcDQgrhGXwajJYd =[]
     OKCnMkvLteiHqAmWcDQgrhGXwajJYT =''
     OKCnMkvLteiHqAmWcDQgrhGXwajJYN=''
     for OKCnMkvLteiHqAmWcDQgrhGXwajJYV in OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('program').get('actor'):
      if OKCnMkvLteiHqAmWcDQgrhGXwajJYV!='' and OKCnMkvLteiHqAmWcDQgrhGXwajJYV!='-' and OKCnMkvLteiHqAmWcDQgrhGXwajJYV!=u'없음':OKCnMkvLteiHqAmWcDQgrhGXwajJYP.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYV)
     for OKCnMkvLteiHqAmWcDQgrhGXwajJYS in OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('program').get('director'):
      if OKCnMkvLteiHqAmWcDQgrhGXwajJYS!='' and OKCnMkvLteiHqAmWcDQgrhGXwajJYS!='-' and OKCnMkvLteiHqAmWcDQgrhGXwajJYS!=u'없음':OKCnMkvLteiHqAmWcDQgrhGXwajJYb.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYS)
     if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('program').get('category1_name').get('ko')!='':
      OKCnMkvLteiHqAmWcDQgrhGXwajJYd.append(OKCnMkvLteiHqAmWcDQgrhGXwajJPp['program']['category1_name']['ko'])
     if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('program').get('category2_name').get('ko')!='':
      OKCnMkvLteiHqAmWcDQgrhGXwajJYd.append(OKCnMkvLteiHqAmWcDQgrhGXwajJPp['program']['category2_name']['ko'])
     if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('program').get('product_year'):OKCnMkvLteiHqAmWcDQgrhGXwajJYT=OKCnMkvLteiHqAmWcDQgrhGXwajJPp['program']['product_year']
     if 'broad_dt' in OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('program'):
      OKCnMkvLteiHqAmWcDQgrhGXwajJYz =OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('program').get('broad_dt')
      OKCnMkvLteiHqAmWcDQgrhGXwajJYN='%s-%s-%s'%(OKCnMkvLteiHqAmWcDQgrhGXwajJYz[:4],OKCnMkvLteiHqAmWcDQgrhGXwajJYz[4:6],OKCnMkvLteiHqAmWcDQgrhGXwajJYz[6:])
    except:
     OKCnMkvLteiHqAmWcDQgrhGXwajJdI
    OKCnMkvLteiHqAmWcDQgrhGXwajJYo={'program':OKCnMkvLteiHqAmWcDQgrhGXwajJYR,'title':OKCnMkvLteiHqAmWcDQgrhGXwajJbl,'thumbnail':{'poster':OKCnMkvLteiHqAmWcDQgrhGXwajJbp,'thumb':OKCnMkvLteiHqAmWcDQgrhGXwajJbu,'clearlogo':OKCnMkvLteiHqAmWcDQgrhGXwajJbU,'icon':OKCnMkvLteiHqAmWcDQgrhGXwajJbB,'banner':OKCnMkvLteiHqAmWcDQgrhGXwajJbx,'fanart':OKCnMkvLteiHqAmWcDQgrhGXwajJbu},'synopsis':OKCnMkvLteiHqAmWcDQgrhGXwajJby,'channel':OKCnMkvLteiHqAmWcDQgrhGXwajJYE,'cast':OKCnMkvLteiHqAmWcDQgrhGXwajJYP,'director':OKCnMkvLteiHqAmWcDQgrhGXwajJYb,'info_genre':OKCnMkvLteiHqAmWcDQgrhGXwajJYd,'year':OKCnMkvLteiHqAmWcDQgrhGXwajJYT,'premiered':OKCnMkvLteiHqAmWcDQgrhGXwajJYN,'mpaa':OKCnMkvLteiHqAmWcDQgrhGXwajJYs}
    OKCnMkvLteiHqAmWcDQgrhGXwajJbN.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYo)
   if OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']['has_more']=='Y':OKCnMkvLteiHqAmWcDQgrhGXwajJbV=OKCnMkvLteiHqAmWcDQgrhGXwajJTY
  except OKCnMkvLteiHqAmWcDQgrhGXwajJTd as exception:
   OKCnMkvLteiHqAmWcDQgrhGXwajJTs(exception)
  return OKCnMkvLteiHqAmWcDQgrhGXwajJbN,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
 def GetEpisodeList(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,program_code,page_int,orderby='desc'):
  OKCnMkvLteiHqAmWcDQgrhGXwajJbN=[]
  OKCnMkvLteiHqAmWcDQgrhGXwajJbV=OKCnMkvLteiHqAmWcDQgrhGXwajJTf
  try:
   OKCnMkvLteiHqAmWcDQgrhGXwajJPz ='/v2/media/frequency/program/'+program_code
   OKCnMkvLteiHqAmWcDQgrhGXwajJPF=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetDefaultParams()
   OKCnMkvLteiHqAmWcDQgrhGXwajJPo={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetNoCache(2))}
   OKCnMkvLteiHqAmWcDQgrhGXwajJPF.update(OKCnMkvLteiHqAmWcDQgrhGXwajJPo)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPR=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.API_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPz
   OKCnMkvLteiHqAmWcDQgrhGXwajJfx=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.callRequestCookies('Get',OKCnMkvLteiHqAmWcDQgrhGXwajJPR,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,params=OKCnMkvLteiHqAmWcDQgrhGXwajJPF,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJdI)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPE=json.loads(OKCnMkvLteiHqAmWcDQgrhGXwajJfx.text)
   if not('result' in OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']):return OKCnMkvLteiHqAmWcDQgrhGXwajJbN,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
   OKCnMkvLteiHqAmWcDQgrhGXwajJbF=OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']['result']
   OKCnMkvLteiHqAmWcDQgrhGXwajJYl=OKCnMkvLteiHqAmWcDQgrhGXwajJTP(OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']['total_count'])
   OKCnMkvLteiHqAmWcDQgrhGXwajJYy =OKCnMkvLteiHqAmWcDQgrhGXwajJTP(OKCnMkvLteiHqAmWcDQgrhGXwajJYl//(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    OKCnMkvLteiHqAmWcDQgrhGXwajJYu =(OKCnMkvLteiHqAmWcDQgrhGXwajJYl-1)-((page_int-1)*OKCnMkvLteiHqAmWcDQgrhGXwajJfd.EPISODE_LIMIT)
   else:
    OKCnMkvLteiHqAmWcDQgrhGXwajJYu =(page_int-1)*OKCnMkvLteiHqAmWcDQgrhGXwajJfd.EPISODE_LIMIT
   for i in OKCnMkvLteiHqAmWcDQgrhGXwajJTb(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.EPISODE_LIMIT):
    if orderby=='desc':
     OKCnMkvLteiHqAmWcDQgrhGXwajJYp=OKCnMkvLteiHqAmWcDQgrhGXwajJYu-i
     if OKCnMkvLteiHqAmWcDQgrhGXwajJYp<0:break
    else:
     OKCnMkvLteiHqAmWcDQgrhGXwajJYp=OKCnMkvLteiHqAmWcDQgrhGXwajJYu+i
     if OKCnMkvLteiHqAmWcDQgrhGXwajJYp>=OKCnMkvLteiHqAmWcDQgrhGXwajJYl:break
    OKCnMkvLteiHqAmWcDQgrhGXwajJYU=OKCnMkvLteiHqAmWcDQgrhGXwajJbF[OKCnMkvLteiHqAmWcDQgrhGXwajJYp]['episode']['code']
    OKCnMkvLteiHqAmWcDQgrhGXwajJbl =OKCnMkvLteiHqAmWcDQgrhGXwajJbF[OKCnMkvLteiHqAmWcDQgrhGXwajJYp]['vod_name']['ko']
    OKCnMkvLteiHqAmWcDQgrhGXwajJYB =''
    try:
     OKCnMkvLteiHqAmWcDQgrhGXwajJYz=OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJbF[OKCnMkvLteiHqAmWcDQgrhGXwajJYp]['episode']['broadcast_date'])
     OKCnMkvLteiHqAmWcDQgrhGXwajJYB='%s-%s-%s'%(OKCnMkvLteiHqAmWcDQgrhGXwajJYz[:4],OKCnMkvLteiHqAmWcDQgrhGXwajJYz[4:6],OKCnMkvLteiHqAmWcDQgrhGXwajJYz[6:])
    except:
     OKCnMkvLteiHqAmWcDQgrhGXwajJdI
    OKCnMkvLteiHqAmWcDQgrhGXwajJby =OKCnMkvLteiHqAmWcDQgrhGXwajJbF[OKCnMkvLteiHqAmWcDQgrhGXwajJYp]['episode']['synopsis']['ko']
    OKCnMkvLteiHqAmWcDQgrhGXwajJbp =''
    OKCnMkvLteiHqAmWcDQgrhGXwajJbu =''
    OKCnMkvLteiHqAmWcDQgrhGXwajJbU=''
    OKCnMkvLteiHqAmWcDQgrhGXwajJbB =''
    OKCnMkvLteiHqAmWcDQgrhGXwajJbx =''
    OKCnMkvLteiHqAmWcDQgrhGXwajJbI =''
    for OKCnMkvLteiHqAmWcDQgrhGXwajJYf in OKCnMkvLteiHqAmWcDQgrhGXwajJbF[OKCnMkvLteiHqAmWcDQgrhGXwajJYp]['program']['image']:
     if OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP0900':OKCnMkvLteiHqAmWcDQgrhGXwajJbp =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
     elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP1800':OKCnMkvLteiHqAmWcDQgrhGXwajJbU=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
     elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP2000':OKCnMkvLteiHqAmWcDQgrhGXwajJbB =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
     elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP1900':OKCnMkvLteiHqAmWcDQgrhGXwajJbx =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
     elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIP0200':OKCnMkvLteiHqAmWcDQgrhGXwajJbI =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
    for OKCnMkvLteiHqAmWcDQgrhGXwajJYf in OKCnMkvLteiHqAmWcDQgrhGXwajJbF[OKCnMkvLteiHqAmWcDQgrhGXwajJYp]['episode']['image']:
     if OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIE0400':OKCnMkvLteiHqAmWcDQgrhGXwajJbu =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
    try:
     OKCnMkvLteiHqAmWcDQgrhGXwajJYx=OKCnMkvLteiHqAmWcDQgrhGXwajJdf=OKCnMkvLteiHqAmWcDQgrhGXwajJdP=''
     OKCnMkvLteiHqAmWcDQgrhGXwajJYI=0
     OKCnMkvLteiHqAmWcDQgrhGXwajJYx =OKCnMkvLteiHqAmWcDQgrhGXwajJbF[OKCnMkvLteiHqAmWcDQgrhGXwajJYp]['program']['name']['ko']
     OKCnMkvLteiHqAmWcDQgrhGXwajJdf =OKCnMkvLteiHqAmWcDQgrhGXwajJYB
     OKCnMkvLteiHqAmWcDQgrhGXwajJdP =OKCnMkvLteiHqAmWcDQgrhGXwajJbF[OKCnMkvLteiHqAmWcDQgrhGXwajJYp]['channel']['name']['ko']
     if 'frequency' in OKCnMkvLteiHqAmWcDQgrhGXwajJbF[OKCnMkvLteiHqAmWcDQgrhGXwajJYp]['episode']:OKCnMkvLteiHqAmWcDQgrhGXwajJYI=OKCnMkvLteiHqAmWcDQgrhGXwajJbF[OKCnMkvLteiHqAmWcDQgrhGXwajJYp]['episode']['frequency']
    except:
     OKCnMkvLteiHqAmWcDQgrhGXwajJdI
    OKCnMkvLteiHqAmWcDQgrhGXwajJYo={'episode':OKCnMkvLteiHqAmWcDQgrhGXwajJYU,'title':OKCnMkvLteiHqAmWcDQgrhGXwajJbl,'subtitle':OKCnMkvLteiHqAmWcDQgrhGXwajJYB,'thumbnail':{'poster':OKCnMkvLteiHqAmWcDQgrhGXwajJbp,'thumb':OKCnMkvLteiHqAmWcDQgrhGXwajJbu,'clearlogo':OKCnMkvLteiHqAmWcDQgrhGXwajJbU,'icon':OKCnMkvLteiHqAmWcDQgrhGXwajJbB,'banner':OKCnMkvLteiHqAmWcDQgrhGXwajJbx,'fanart':OKCnMkvLteiHqAmWcDQgrhGXwajJbI},'synopsis':OKCnMkvLteiHqAmWcDQgrhGXwajJby,'info_title':OKCnMkvLteiHqAmWcDQgrhGXwajJYx,'aired':OKCnMkvLteiHqAmWcDQgrhGXwajJdf,'studio':OKCnMkvLteiHqAmWcDQgrhGXwajJdP,'frequency':OKCnMkvLteiHqAmWcDQgrhGXwajJYI}
    OKCnMkvLteiHqAmWcDQgrhGXwajJbN.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYo)
   if OKCnMkvLteiHqAmWcDQgrhGXwajJYy>page_int:OKCnMkvLteiHqAmWcDQgrhGXwajJbV=OKCnMkvLteiHqAmWcDQgrhGXwajJTY
  except OKCnMkvLteiHqAmWcDQgrhGXwajJTd as exception:
   OKCnMkvLteiHqAmWcDQgrhGXwajJTs(exception)
  return OKCnMkvLteiHqAmWcDQgrhGXwajJbN,OKCnMkvLteiHqAmWcDQgrhGXwajJbV,OKCnMkvLteiHqAmWcDQgrhGXwajJYy
 def GetMovieList(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,genre,orderby,page_int):
  OKCnMkvLteiHqAmWcDQgrhGXwajJbN=[]
  OKCnMkvLteiHqAmWcDQgrhGXwajJbV=OKCnMkvLteiHqAmWcDQgrhGXwajJTf
  try:
   OKCnMkvLteiHqAmWcDQgrhGXwajJPz ='/v2/media/movies'
   OKCnMkvLteiHqAmWcDQgrhGXwajJPF=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetDefaultParams()
   OKCnMkvLteiHqAmWcDQgrhGXwajJPo={'pageNo':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(page_int),'pageSize':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetNoCache(2))}
   if genre!='all' :OKCnMkvLteiHqAmWcDQgrhGXwajJPo['multiCategoryCode']=genre
   if orderby=='new':OKCnMkvLteiHqAmWcDQgrhGXwajJPo['productPackageCode']=','.join(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.MOVIE_LITE)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPF.update(OKCnMkvLteiHqAmWcDQgrhGXwajJPo)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPR=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.API_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPz
   OKCnMkvLteiHqAmWcDQgrhGXwajJfx=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.callRequestCookies('Get',OKCnMkvLteiHqAmWcDQgrhGXwajJPR,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,params=OKCnMkvLteiHqAmWcDQgrhGXwajJPF,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJdI)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPE=json.loads(OKCnMkvLteiHqAmWcDQgrhGXwajJfx.text)
   if not('result' in OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']):return OKCnMkvLteiHqAmWcDQgrhGXwajJbN,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
   OKCnMkvLteiHqAmWcDQgrhGXwajJbF=OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']['result']
   for OKCnMkvLteiHqAmWcDQgrhGXwajJPp in OKCnMkvLteiHqAmWcDQgrhGXwajJbF:
    OKCnMkvLteiHqAmWcDQgrhGXwajJdb =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['movie']['code']
    OKCnMkvLteiHqAmWcDQgrhGXwajJbl =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['movie']['name']['ko'].strip()
    OKCnMkvLteiHqAmWcDQgrhGXwajJbl +=u' (%s년)'%(OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('movie').get('product_year'))
    OKCnMkvLteiHqAmWcDQgrhGXwajJbp=''
    OKCnMkvLteiHqAmWcDQgrhGXwajJbu =''
    OKCnMkvLteiHqAmWcDQgrhGXwajJbU=''
    for OKCnMkvLteiHqAmWcDQgrhGXwajJYf in OKCnMkvLteiHqAmWcDQgrhGXwajJPp['movie']['image']:
     if OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIM2100':OKCnMkvLteiHqAmWcDQgrhGXwajJbp =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
     elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIM0400':OKCnMkvLteiHqAmWcDQgrhGXwajJbu =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
     elif OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIM1800':OKCnMkvLteiHqAmWcDQgrhGXwajJbU=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
    OKCnMkvLteiHqAmWcDQgrhGXwajJby =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['movie']['story']['ko']
    try:
     OKCnMkvLteiHqAmWcDQgrhGXwajJYx =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['movie']['name']['ko'].strip()
     OKCnMkvLteiHqAmWcDQgrhGXwajJYT =OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('movie').get('product_year')
     OKCnMkvLteiHqAmWcDQgrhGXwajJYs =OKCnMkvLteiHqAmWcDQgrhGXwajJfY.get(OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('grade_code'))
     OKCnMkvLteiHqAmWcDQgrhGXwajJYP=[]
     OKCnMkvLteiHqAmWcDQgrhGXwajJYb=[]
     OKCnMkvLteiHqAmWcDQgrhGXwajJYd=[]
     OKCnMkvLteiHqAmWcDQgrhGXwajJdY=0
     OKCnMkvLteiHqAmWcDQgrhGXwajJYN=''
     OKCnMkvLteiHqAmWcDQgrhGXwajJdP =''
     for OKCnMkvLteiHqAmWcDQgrhGXwajJYV in OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('movie').get('actor'):
      if OKCnMkvLteiHqAmWcDQgrhGXwajJYV!='':OKCnMkvLteiHqAmWcDQgrhGXwajJYP.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYV)
     for OKCnMkvLteiHqAmWcDQgrhGXwajJYS in OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('movie').get('director'):
      if OKCnMkvLteiHqAmWcDQgrhGXwajJYS!='':OKCnMkvLteiHqAmWcDQgrhGXwajJYb.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYS)
     if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('movie').get('category1_name').get('ko')!='':
      OKCnMkvLteiHqAmWcDQgrhGXwajJYd.append(OKCnMkvLteiHqAmWcDQgrhGXwajJPp['movie']['category1_name']['ko'])
     if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('movie').get('category2_name').get('ko')!='':
      OKCnMkvLteiHqAmWcDQgrhGXwajJYd.append(OKCnMkvLteiHqAmWcDQgrhGXwajJPp['movie']['category2_name']['ko'])
     if 'duration' in OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('movie'):OKCnMkvLteiHqAmWcDQgrhGXwajJdY=OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('movie').get('duration')
     if 'release_date' in OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('movie'):
      OKCnMkvLteiHqAmWcDQgrhGXwajJYz=OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('movie').get('release_date'))
      if OKCnMkvLteiHqAmWcDQgrhGXwajJYz!='0':OKCnMkvLteiHqAmWcDQgrhGXwajJYN='%s-%s-%s'%(OKCnMkvLteiHqAmWcDQgrhGXwajJYz[:4],OKCnMkvLteiHqAmWcDQgrhGXwajJYz[4:6],OKCnMkvLteiHqAmWcDQgrhGXwajJYz[6:])
     if 'production' in OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('movie'):OKCnMkvLteiHqAmWcDQgrhGXwajJdP=OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('movie').get('production')
    except:
     OKCnMkvLteiHqAmWcDQgrhGXwajJdI
    OKCnMkvLteiHqAmWcDQgrhGXwajJYo={'moviecode':OKCnMkvLteiHqAmWcDQgrhGXwajJdb,'title':OKCnMkvLteiHqAmWcDQgrhGXwajJbl,'thumbnail':{'poster':OKCnMkvLteiHqAmWcDQgrhGXwajJbp,'thumb':OKCnMkvLteiHqAmWcDQgrhGXwajJbu,'clearlogo':OKCnMkvLteiHqAmWcDQgrhGXwajJbU,'fanart':OKCnMkvLteiHqAmWcDQgrhGXwajJbu},'synopsis':OKCnMkvLteiHqAmWcDQgrhGXwajJby,'info_title':OKCnMkvLteiHqAmWcDQgrhGXwajJYx,'year':OKCnMkvLteiHqAmWcDQgrhGXwajJYT,'cast':OKCnMkvLteiHqAmWcDQgrhGXwajJYP,'director':OKCnMkvLteiHqAmWcDQgrhGXwajJYb,'info_genre':OKCnMkvLteiHqAmWcDQgrhGXwajJYd,'duration':OKCnMkvLteiHqAmWcDQgrhGXwajJdY,'premiered':OKCnMkvLteiHqAmWcDQgrhGXwajJYN,'studio':OKCnMkvLteiHqAmWcDQgrhGXwajJdP,'mpaa':OKCnMkvLteiHqAmWcDQgrhGXwajJYs}
    OKCnMkvLteiHqAmWcDQgrhGXwajJdT=OKCnMkvLteiHqAmWcDQgrhGXwajJTf
    for OKCnMkvLteiHqAmWcDQgrhGXwajJds in OKCnMkvLteiHqAmWcDQgrhGXwajJPp['billing_package_id']:
     if OKCnMkvLteiHqAmWcDQgrhGXwajJds in OKCnMkvLteiHqAmWcDQgrhGXwajJfd.MOVIE_LITE:
      OKCnMkvLteiHqAmWcDQgrhGXwajJdT=OKCnMkvLteiHqAmWcDQgrhGXwajJTY
      break
    if OKCnMkvLteiHqAmWcDQgrhGXwajJdT==OKCnMkvLteiHqAmWcDQgrhGXwajJTf: 
     OKCnMkvLteiHqAmWcDQgrhGXwajJYo['title']=OKCnMkvLteiHqAmWcDQgrhGXwajJYo['title']+' [개별구매]'
    OKCnMkvLteiHqAmWcDQgrhGXwajJbN.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYo)
   if OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']['has_more']=='Y':OKCnMkvLteiHqAmWcDQgrhGXwajJbV=OKCnMkvLteiHqAmWcDQgrhGXwajJTY
  except OKCnMkvLteiHqAmWcDQgrhGXwajJTd as exception:
   OKCnMkvLteiHqAmWcDQgrhGXwajJTs(exception)
  return OKCnMkvLteiHqAmWcDQgrhGXwajJbN,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
 def GetMovieListGenre(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,genre,page_int):
  OKCnMkvLteiHqAmWcDQgrhGXwajJbN=[]
  OKCnMkvLteiHqAmWcDQgrhGXwajJbV=OKCnMkvLteiHqAmWcDQgrhGXwajJTf
  try:
   OKCnMkvLteiHqAmWcDQgrhGXwajJPz ='/v2/media/movie/curation/'+genre
   OKCnMkvLteiHqAmWcDQgrhGXwajJPF=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetDefaultParams()
   OKCnMkvLteiHqAmWcDQgrhGXwajJPo={'pageNo':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(page_int),'pageSize':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.MOVIE_LIMIT),'_':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetNoCache(2))}
   OKCnMkvLteiHqAmWcDQgrhGXwajJPF.update(OKCnMkvLteiHqAmWcDQgrhGXwajJPo)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPR=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.API_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPz
   OKCnMkvLteiHqAmWcDQgrhGXwajJfx=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.callRequestCookies('Get',OKCnMkvLteiHqAmWcDQgrhGXwajJPR,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,params=OKCnMkvLteiHqAmWcDQgrhGXwajJPF,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJdI)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPE=json.loads(OKCnMkvLteiHqAmWcDQgrhGXwajJfx.text)
   if not('movies' in OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']):return OKCnMkvLteiHqAmWcDQgrhGXwajJbN,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
   OKCnMkvLteiHqAmWcDQgrhGXwajJbF=OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']['movies']
   for OKCnMkvLteiHqAmWcDQgrhGXwajJPp in OKCnMkvLteiHqAmWcDQgrhGXwajJbF:
    OKCnMkvLteiHqAmWcDQgrhGXwajJdb =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['code']
    OKCnMkvLteiHqAmWcDQgrhGXwajJbl =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['name']['ko']
    OKCnMkvLteiHqAmWcDQgrhGXwajJdN =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPp['image'][0]['url']
    for OKCnMkvLteiHqAmWcDQgrhGXwajJYf in OKCnMkvLteiHqAmWcDQgrhGXwajJPp['image']:
     if OKCnMkvLteiHqAmWcDQgrhGXwajJYf['code']=='CAIM2100':
      OKCnMkvLteiHqAmWcDQgrhGXwajJdN =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJYf['url']
    OKCnMkvLteiHqAmWcDQgrhGXwajJby =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['story']['ko']
    OKCnMkvLteiHqAmWcDQgrhGXwajJYo={'moviecode':OKCnMkvLteiHqAmWcDQgrhGXwajJdb,'title':OKCnMkvLteiHqAmWcDQgrhGXwajJbl.strip(),'thumbnail':OKCnMkvLteiHqAmWcDQgrhGXwajJdN,'synopsis':OKCnMkvLteiHqAmWcDQgrhGXwajJby}
    OKCnMkvLteiHqAmWcDQgrhGXwajJbN.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYo)
  except OKCnMkvLteiHqAmWcDQgrhGXwajJTd as exception:
   OKCnMkvLteiHqAmWcDQgrhGXwajJTs(exception)
  return OKCnMkvLteiHqAmWcDQgrhGXwajJbN,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
 def GetMovieGenre(OKCnMkvLteiHqAmWcDQgrhGXwajJfd):
  OKCnMkvLteiHqAmWcDQgrhGXwajJbN=[]
  OKCnMkvLteiHqAmWcDQgrhGXwajJbV=OKCnMkvLteiHqAmWcDQgrhGXwajJTf
  try:
   OKCnMkvLteiHqAmWcDQgrhGXwajJPz ='/v2/media/movie/curations'
   OKCnMkvLteiHqAmWcDQgrhGXwajJPF=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetDefaultParams()
   OKCnMkvLteiHqAmWcDQgrhGXwajJPo={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetNoCache(2))}
   OKCnMkvLteiHqAmWcDQgrhGXwajJPF.update(OKCnMkvLteiHqAmWcDQgrhGXwajJPo)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPR=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.API_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPz
   OKCnMkvLteiHqAmWcDQgrhGXwajJfx=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.callRequestCookies('Get',OKCnMkvLteiHqAmWcDQgrhGXwajJPR,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,params=OKCnMkvLteiHqAmWcDQgrhGXwajJPF,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJdI)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPE=json.loads(OKCnMkvLteiHqAmWcDQgrhGXwajJfx.text)
   if not('result' in OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']):return OKCnMkvLteiHqAmWcDQgrhGXwajJbN,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
   OKCnMkvLteiHqAmWcDQgrhGXwajJbF=OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']['result']
   for OKCnMkvLteiHqAmWcDQgrhGXwajJPp in OKCnMkvLteiHqAmWcDQgrhGXwajJbF:
    OKCnMkvLteiHqAmWcDQgrhGXwajJdV =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['curation_code']
    OKCnMkvLteiHqAmWcDQgrhGXwajJdS =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['curation_name']
    OKCnMkvLteiHqAmWcDQgrhGXwajJYo={'curation_code':OKCnMkvLteiHqAmWcDQgrhGXwajJdV,'curation_name':OKCnMkvLteiHqAmWcDQgrhGXwajJdS}
    OKCnMkvLteiHqAmWcDQgrhGXwajJbN.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYo)
  except OKCnMkvLteiHqAmWcDQgrhGXwajJTd as exception:
   OKCnMkvLteiHqAmWcDQgrhGXwajJTs(exception)
  return OKCnMkvLteiHqAmWcDQgrhGXwajJbN,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
 def GetSearchList(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,search_key,page_int,stype):
  OKCnMkvLteiHqAmWcDQgrhGXwajJdz=[]
  OKCnMkvLteiHqAmWcDQgrhGXwajJbV=OKCnMkvLteiHqAmWcDQgrhGXwajJTf
  try:
   OKCnMkvLteiHqAmWcDQgrhGXwajJPz ='/search/getSearch.jsp'
   OKCnMkvLteiHqAmWcDQgrhGXwajJPo={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(page_int),'pageSize':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.SCREENCODE,'os':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.OSCODE,'network':OKCnMkvLteiHqAmWcDQgrhGXwajJfd.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':OKCnMkvLteiHqAmWcDQgrhGXwajJTN(OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GetNoCache(2))}
   OKCnMkvLteiHqAmWcDQgrhGXwajJPR=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.SEARCH_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPz
   OKCnMkvLteiHqAmWcDQgrhGXwajJfx=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.callRequestCookies('Get',OKCnMkvLteiHqAmWcDQgrhGXwajJPR,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,params=OKCnMkvLteiHqAmWcDQgrhGXwajJPo,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJdI)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPE=json.loads(OKCnMkvLteiHqAmWcDQgrhGXwajJfx.text)
   if stype=='vod':
    if not('programRsb' in OKCnMkvLteiHqAmWcDQgrhGXwajJPE):return OKCnMkvLteiHqAmWcDQgrhGXwajJdz,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
    OKCnMkvLteiHqAmWcDQgrhGXwajJdF=OKCnMkvLteiHqAmWcDQgrhGXwajJPE['programRsb']['dataList']
    OKCnMkvLteiHqAmWcDQgrhGXwajJdo =OKCnMkvLteiHqAmWcDQgrhGXwajJTP(OKCnMkvLteiHqAmWcDQgrhGXwajJPE['programRsb']['count'])
    for OKCnMkvLteiHqAmWcDQgrhGXwajJPp in OKCnMkvLteiHqAmWcDQgrhGXwajJdF:
     OKCnMkvLteiHqAmWcDQgrhGXwajJYR=OKCnMkvLteiHqAmWcDQgrhGXwajJPp['mast_cd']
     OKCnMkvLteiHqAmWcDQgrhGXwajJbl =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['mast_nm']
     OKCnMkvLteiHqAmWcDQgrhGXwajJbp=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPp['web_url4']
     OKCnMkvLteiHqAmWcDQgrhGXwajJbu =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPp['web_url']
     try:
      OKCnMkvLteiHqAmWcDQgrhGXwajJYP =[]
      OKCnMkvLteiHqAmWcDQgrhGXwajJYb=[]
      OKCnMkvLteiHqAmWcDQgrhGXwajJYd =[]
      OKCnMkvLteiHqAmWcDQgrhGXwajJdY =0
      OKCnMkvLteiHqAmWcDQgrhGXwajJYs =''
      OKCnMkvLteiHqAmWcDQgrhGXwajJYT =''
      OKCnMkvLteiHqAmWcDQgrhGXwajJdf =''
      if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('actor') !='' and OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('actor') !='-':OKCnMkvLteiHqAmWcDQgrhGXwajJYP =OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('actor').split(',')
      if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('director')!='' and OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('director')!='-':OKCnMkvLteiHqAmWcDQgrhGXwajJYb=OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('director').split(',')
      if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('cate_nm')!='' and OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('cate_nm')!='-':OKCnMkvLteiHqAmWcDQgrhGXwajJYd =OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('cate_nm').split('/')
      if 'targetage' in OKCnMkvLteiHqAmWcDQgrhGXwajJPp:OKCnMkvLteiHqAmWcDQgrhGXwajJYs=OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('targetage')
      if 'broad_dt' in OKCnMkvLteiHqAmWcDQgrhGXwajJPp:
       OKCnMkvLteiHqAmWcDQgrhGXwajJYz=OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('broad_dt')
       OKCnMkvLteiHqAmWcDQgrhGXwajJdf='%s-%s-%s'%(OKCnMkvLteiHqAmWcDQgrhGXwajJYz[:4],OKCnMkvLteiHqAmWcDQgrhGXwajJYz[4:6],OKCnMkvLteiHqAmWcDQgrhGXwajJYz[6:])
       OKCnMkvLteiHqAmWcDQgrhGXwajJYT =OKCnMkvLteiHqAmWcDQgrhGXwajJYz[:4]
     except:
      OKCnMkvLteiHqAmWcDQgrhGXwajJdI
     OKCnMkvLteiHqAmWcDQgrhGXwajJYo={'program':OKCnMkvLteiHqAmWcDQgrhGXwajJYR,'title':OKCnMkvLteiHqAmWcDQgrhGXwajJbl,'thumbnail':{'poster':OKCnMkvLteiHqAmWcDQgrhGXwajJbp,'thumb':OKCnMkvLteiHqAmWcDQgrhGXwajJbu,'fanart':OKCnMkvLteiHqAmWcDQgrhGXwajJbu},'synopsis':'','cast':OKCnMkvLteiHqAmWcDQgrhGXwajJYP,'director':OKCnMkvLteiHqAmWcDQgrhGXwajJYb,'info_genre':OKCnMkvLteiHqAmWcDQgrhGXwajJYd,'duration':OKCnMkvLteiHqAmWcDQgrhGXwajJdY,'mpaa':OKCnMkvLteiHqAmWcDQgrhGXwajJYs,'year':OKCnMkvLteiHqAmWcDQgrhGXwajJYT,'aired':OKCnMkvLteiHqAmWcDQgrhGXwajJdf}
     OKCnMkvLteiHqAmWcDQgrhGXwajJdz.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYo)
   else:
    if not('vodMVRsb' in OKCnMkvLteiHqAmWcDQgrhGXwajJPE):return OKCnMkvLteiHqAmWcDQgrhGXwajJdz,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
    OKCnMkvLteiHqAmWcDQgrhGXwajJdR=OKCnMkvLteiHqAmWcDQgrhGXwajJPE['vodMVRsb']['dataList']
    OKCnMkvLteiHqAmWcDQgrhGXwajJdo =OKCnMkvLteiHqAmWcDQgrhGXwajJTP(OKCnMkvLteiHqAmWcDQgrhGXwajJPE['vodMVRsb']['count'])
    for OKCnMkvLteiHqAmWcDQgrhGXwajJPp in OKCnMkvLteiHqAmWcDQgrhGXwajJdR:
     OKCnMkvLteiHqAmWcDQgrhGXwajJYR=OKCnMkvLteiHqAmWcDQgrhGXwajJPp['mast_cd']
     OKCnMkvLteiHqAmWcDQgrhGXwajJbl =OKCnMkvLteiHqAmWcDQgrhGXwajJPp['mast_nm'].strip()
     OKCnMkvLteiHqAmWcDQgrhGXwajJbp =OKCnMkvLteiHqAmWcDQgrhGXwajJfd.IMG_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPp['web_url']
     OKCnMkvLteiHqAmWcDQgrhGXwajJbu =OKCnMkvLteiHqAmWcDQgrhGXwajJbp
     OKCnMkvLteiHqAmWcDQgrhGXwajJbU=''
     try:
      OKCnMkvLteiHqAmWcDQgrhGXwajJYP =[]
      OKCnMkvLteiHqAmWcDQgrhGXwajJYb=[]
      OKCnMkvLteiHqAmWcDQgrhGXwajJYd =[]
      OKCnMkvLteiHqAmWcDQgrhGXwajJdY =0
      OKCnMkvLteiHqAmWcDQgrhGXwajJYs =''
      OKCnMkvLteiHqAmWcDQgrhGXwajJYT =''
      OKCnMkvLteiHqAmWcDQgrhGXwajJdf =''
      if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('actor') !='' and OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('actor') !='-':OKCnMkvLteiHqAmWcDQgrhGXwajJYP =OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('actor').split(',')
      if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('director')!='' and OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('director')!='-':OKCnMkvLteiHqAmWcDQgrhGXwajJYb=OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('director').split(',')
      if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('cate_nm')!='' and OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('cate_nm')!='-':OKCnMkvLteiHqAmWcDQgrhGXwajJYd =OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('cate_nm').split('/')
      if OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('runtime_sec')!='':OKCnMkvLteiHqAmWcDQgrhGXwajJdY=OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('runtime_sec')
      if 'grade_nm' in OKCnMkvLteiHqAmWcDQgrhGXwajJPp:OKCnMkvLteiHqAmWcDQgrhGXwajJYs=OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('grade_nm')
      OKCnMkvLteiHqAmWcDQgrhGXwajJYz=OKCnMkvLteiHqAmWcDQgrhGXwajJPp.get('broad_dt')
      if data_str!='':
       OKCnMkvLteiHqAmWcDQgrhGXwajJdf='%s-%s-%s'%(OKCnMkvLteiHqAmWcDQgrhGXwajJYz[:4],OKCnMkvLteiHqAmWcDQgrhGXwajJYz[4:6],OKCnMkvLteiHqAmWcDQgrhGXwajJYz[6:])
       OKCnMkvLteiHqAmWcDQgrhGXwajJYT =OKCnMkvLteiHqAmWcDQgrhGXwajJYz[:4]
     except:
      OKCnMkvLteiHqAmWcDQgrhGXwajJdI
     OKCnMkvLteiHqAmWcDQgrhGXwajJYo={'movie':OKCnMkvLteiHqAmWcDQgrhGXwajJYR,'title':OKCnMkvLteiHqAmWcDQgrhGXwajJbl,'thumbnail':{'poster':OKCnMkvLteiHqAmWcDQgrhGXwajJbp,'thumb':OKCnMkvLteiHqAmWcDQgrhGXwajJbu,'fanart':OKCnMkvLteiHqAmWcDQgrhGXwajJbu,'clearlogo':OKCnMkvLteiHqAmWcDQgrhGXwajJbU},'synopsis':'','cast':OKCnMkvLteiHqAmWcDQgrhGXwajJYP,'director':OKCnMkvLteiHqAmWcDQgrhGXwajJYb,'info_genre':OKCnMkvLteiHqAmWcDQgrhGXwajJYd,'duration':OKCnMkvLteiHqAmWcDQgrhGXwajJdY,'mpaa':OKCnMkvLteiHqAmWcDQgrhGXwajJYs,'year':OKCnMkvLteiHqAmWcDQgrhGXwajJYT,'aired':OKCnMkvLteiHqAmWcDQgrhGXwajJdf}
     OKCnMkvLteiHqAmWcDQgrhGXwajJdT=OKCnMkvLteiHqAmWcDQgrhGXwajJTf
     for OKCnMkvLteiHqAmWcDQgrhGXwajJds in OKCnMkvLteiHqAmWcDQgrhGXwajJPp['bill']:
      if OKCnMkvLteiHqAmWcDQgrhGXwajJds in OKCnMkvLteiHqAmWcDQgrhGXwajJfd.MOVIE_LITE:
       OKCnMkvLteiHqAmWcDQgrhGXwajJdT=OKCnMkvLteiHqAmWcDQgrhGXwajJTY
       break
     if OKCnMkvLteiHqAmWcDQgrhGXwajJdT==OKCnMkvLteiHqAmWcDQgrhGXwajJTf: 
      OKCnMkvLteiHqAmWcDQgrhGXwajJYo['title']=OKCnMkvLteiHqAmWcDQgrhGXwajJYo['title']+' [개별구매]'
     OKCnMkvLteiHqAmWcDQgrhGXwajJdz.append(OKCnMkvLteiHqAmWcDQgrhGXwajJYo)
   if OKCnMkvLteiHqAmWcDQgrhGXwajJdo>(page_int*OKCnMkvLteiHqAmWcDQgrhGXwajJfd.SEARCH_LIMIT):OKCnMkvLteiHqAmWcDQgrhGXwajJbV=OKCnMkvLteiHqAmWcDQgrhGXwajJTY
  except OKCnMkvLteiHqAmWcDQgrhGXwajJTd as exception:
   OKCnMkvLteiHqAmWcDQgrhGXwajJTs(exception)
  return OKCnMkvLteiHqAmWcDQgrhGXwajJdz,OKCnMkvLteiHqAmWcDQgrhGXwajJbV
 def GetDeviceList(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,OKCnMkvLteiHqAmWcDQgrhGXwajJPf,OKCnMkvLteiHqAmWcDQgrhGXwajJPb):
  OKCnMkvLteiHqAmWcDQgrhGXwajJbN=[]
  OKCnMkvLteiHqAmWcDQgrhGXwajJPV='-'
  try:
   OKCnMkvLteiHqAmWcDQgrhGXwajJPz ='/v1/user/device/list'
   OKCnMkvLteiHqAmWcDQgrhGXwajJdE=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.API_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPz
   OKCnMkvLteiHqAmWcDQgrhGXwajJPo={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   OKCnMkvLteiHqAmWcDQgrhGXwajJfN=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.makeDefaultCookies(vToken=OKCnMkvLteiHqAmWcDQgrhGXwajJPf,vUserinfo=OKCnMkvLteiHqAmWcDQgrhGXwajJPb)
   OKCnMkvLteiHqAmWcDQgrhGXwajJfx=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.callRequestCookies('Get',OKCnMkvLteiHqAmWcDQgrhGXwajJdE,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,params=OKCnMkvLteiHqAmWcDQgrhGXwajJPo,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJfN)
   OKCnMkvLteiHqAmWcDQgrhGXwajJPE=json.loads(OKCnMkvLteiHqAmWcDQgrhGXwajJfx.text)
   OKCnMkvLteiHqAmWcDQgrhGXwajJbN=OKCnMkvLteiHqAmWcDQgrhGXwajJPE['body']
   for OKCnMkvLteiHqAmWcDQgrhGXwajJPp in OKCnMkvLteiHqAmWcDQgrhGXwajJbN:
    if OKCnMkvLteiHqAmWcDQgrhGXwajJPp['model']=='PC':
     OKCnMkvLteiHqAmWcDQgrhGXwajJPV=OKCnMkvLteiHqAmWcDQgrhGXwajJPp['uuid']
  except OKCnMkvLteiHqAmWcDQgrhGXwajJTd as exception:
   OKCnMkvLteiHqAmWcDQgrhGXwajJTs(exception)
  return OKCnMkvLteiHqAmWcDQgrhGXwajJPV
 def GetProfileToken(OKCnMkvLteiHqAmWcDQgrhGXwajJfd,OKCnMkvLteiHqAmWcDQgrhGXwajJPf,OKCnMkvLteiHqAmWcDQgrhGXwajJPb,user_pf):
  OKCnMkvLteiHqAmWcDQgrhGXwajJdl=[]
  OKCnMkvLteiHqAmWcDQgrhGXwajJdy =''
  OKCnMkvLteiHqAmWcDQgrhGXwajJdu =''
  OKCnMkvLteiHqAmWcDQgrhGXwajJdp='Y'
  OKCnMkvLteiHqAmWcDQgrhGXwajJdU ='N'
  try:
   OKCnMkvLteiHqAmWcDQgrhGXwajJPz ='/profile/select.do'
   OKCnMkvLteiHqAmWcDQgrhGXwajJdE=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.URL_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPz
   OKCnMkvLteiHqAmWcDQgrhGXwajJfN=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.makeDefaultCookies(vToken=OKCnMkvLteiHqAmWcDQgrhGXwajJPf,vUserinfo=OKCnMkvLteiHqAmWcDQgrhGXwajJPb)
   OKCnMkvLteiHqAmWcDQgrhGXwajJfx=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.callRequestCookies('Get',OKCnMkvLteiHqAmWcDQgrhGXwajJdE,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,params=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJfN)
   OKCnMkvLteiHqAmWcDQgrhGXwajJdl =re.findall('data-profile-no="\d+"',OKCnMkvLteiHqAmWcDQgrhGXwajJfx.text)
   for i in OKCnMkvLteiHqAmWcDQgrhGXwajJTb(OKCnMkvLteiHqAmWcDQgrhGXwajJTS(OKCnMkvLteiHqAmWcDQgrhGXwajJdl)):
    OKCnMkvLteiHqAmWcDQgrhGXwajJdB =OKCnMkvLteiHqAmWcDQgrhGXwajJdl[i].replace('data-profile-no=','').replace('"','')
    OKCnMkvLteiHqAmWcDQgrhGXwajJdl[i]=OKCnMkvLteiHqAmWcDQgrhGXwajJdB
   OKCnMkvLteiHqAmWcDQgrhGXwajJdy=OKCnMkvLteiHqAmWcDQgrhGXwajJdl[user_pf]
  except OKCnMkvLteiHqAmWcDQgrhGXwajJTd as exception:
   OKCnMkvLteiHqAmWcDQgrhGXwajJTs(exception)
   return OKCnMkvLteiHqAmWcDQgrhGXwajJdu,OKCnMkvLteiHqAmWcDQgrhGXwajJdp,OKCnMkvLteiHqAmWcDQgrhGXwajJdU
  try:
   OKCnMkvLteiHqAmWcDQgrhGXwajJPz ='/profile/api/select.do'
   OKCnMkvLteiHqAmWcDQgrhGXwajJdE=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.URL_DOMAIN+OKCnMkvLteiHqAmWcDQgrhGXwajJPz
   OKCnMkvLteiHqAmWcDQgrhGXwajJfN=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.makeDefaultCookies(vToken=OKCnMkvLteiHqAmWcDQgrhGXwajJPf,vUserinfo=OKCnMkvLteiHqAmWcDQgrhGXwajJPb)
   OKCnMkvLteiHqAmWcDQgrhGXwajJfB={'profileNo':OKCnMkvLteiHqAmWcDQgrhGXwajJdy}
   OKCnMkvLteiHqAmWcDQgrhGXwajJfx=OKCnMkvLteiHqAmWcDQgrhGXwajJfd.callRequestCookies('Post',OKCnMkvLteiHqAmWcDQgrhGXwajJdE,payload=OKCnMkvLteiHqAmWcDQgrhGXwajJfB,params=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,headers=OKCnMkvLteiHqAmWcDQgrhGXwajJdI,cookies=OKCnMkvLteiHqAmWcDQgrhGXwajJfN)
   for OKCnMkvLteiHqAmWcDQgrhGXwajJfI in OKCnMkvLteiHqAmWcDQgrhGXwajJfx.cookies:
    if OKCnMkvLteiHqAmWcDQgrhGXwajJfI.name=='_tving_token':
     OKCnMkvLteiHqAmWcDQgrhGXwajJdu=OKCnMkvLteiHqAmWcDQgrhGXwajJfI.value
    elif OKCnMkvLteiHqAmWcDQgrhGXwajJfI.name==OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GLOBAL_COOKIENM['tv_cookiekey']:
     OKCnMkvLteiHqAmWcDQgrhGXwajJdp=OKCnMkvLteiHqAmWcDQgrhGXwajJfI.value
    elif OKCnMkvLteiHqAmWcDQgrhGXwajJfI.name==OKCnMkvLteiHqAmWcDQgrhGXwajJfd.GLOBAL_COOKIENM['tv_lockkey']:
     OKCnMkvLteiHqAmWcDQgrhGXwajJdU=OKCnMkvLteiHqAmWcDQgrhGXwajJfI.value
  except OKCnMkvLteiHqAmWcDQgrhGXwajJTd as exception:
   OKCnMkvLteiHqAmWcDQgrhGXwajJTs(exception)
  return OKCnMkvLteiHqAmWcDQgrhGXwajJdu,OKCnMkvLteiHqAmWcDQgrhGXwajJdp,OKCnMkvLteiHqAmWcDQgrhGXwajJdU
# Created by pyminifier (https://github.com/liftoff/pyminifier)
