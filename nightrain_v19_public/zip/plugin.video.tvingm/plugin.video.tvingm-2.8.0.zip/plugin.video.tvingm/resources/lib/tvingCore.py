_B5='VOD_BASIC_RANKING'
_B4='/_next/data/{}/ko/more/special/SP0071.json'
_B3='https://gw.tving.com'
_B2='genreCode'
_B1='Second Step - except error'
_B0='drm_license_data'
_A_='/v3/media/stream/info'
_Az='mediacode'
_Ay='h264|hevc'
_Ax='6yhlJ4WF9ZIj6I8n'
_Aw='kss2lym0kdw1lks3'
_Av='_tving_token'
_Au='token'
_At='nextApiUrl'
_As='studio'
_Ar='aired'
_Aq='scope'
_Ap='guest'
_Ao='adult'
_An='cacheType'
_Am='url_filename'
_Al='subtitleYn'
_Ak='header'
_Aj='streamType'
_Ai='authType'
_Ah='audioTypes'
_Ag='videoTypes'
_Af='model'
_Ae='networkCode'
_Ad='apiKey'
_Ac='refreshToken'
_Ab='bandType'
_Aa='pages'
_AZ='movie'
_AY='items'
_AX='banner'
_AW='info_genre'
_AV='CAIP0200'
_AU='CAIP1900'
_AT='CAIP2000'
_AS='CAIP1800'
_AR='CAIP0900'
_AQ='frequency'
_AP='access-token'
_AO='HTML5'
_AN='PC_Chrome'
_AM='callingFrom'
_AL='noCache'
_AK='streamCode'
_AJ='deviceInfo'
_AI='uuid'
_AH='mediaCode'
_AG='screenCode'
_AF='osCode'
_AE='user-agent'
_AD='authToken'
_AC='state'
_AB='queries'
_AA='dehydratedState'
_A9='duration'
_A8='vod'
_A7='imageUrl'
_A6='icon'
_A5='premiered'
_A4='grade_code'
_A3='pageNo'
_A2='deviceId'
_A1='bands'
_A0='bandCode'
_z='genre'
_y='desc'
_x='channel'
_w='order'
_v='playback'
_u='drm_header_value'
_t='drm_header_key'
_s='drm_server_url'
_r='error_msg'
_q='clearlogo'
_p='mpaa'
_o='year'
_n='cast'
_m='%s-%s-%s'
_l='product_year'
_k='image'
_j='pageSize'
_i='Y'
_h='broad_dt'
_g='category2_name'
_f='category1_name'
_e='tving_uuid'
_d='account'
_c='accessToken'
_b='fanart'
_a='thumb'
_Z='actor'
_Y='synopsis'
_X='name'
_W='result'
_V='pageProps'
_U='episode'
_T='poster'
_S='cookies'
_R='all'
_Q='0'
_P='director'
_O='streaming_url'
_N='data'
_M='Get'
_L='body'
_K='-'
_J=True
_I='thumbnail'
_H='title'
_G='utf-8'
_F=False
_E='url'
_D='ko'
_C='program'
_B='code'
_A=None
__author__='NightRain'
import urllib,re,json,sys,time,requests,datetime,random,base64,os,xml.etree.ElementTree as ET,xml.dom.minidom,io
'\nimport xbmcplugin, xbmcgui, xbmcaddon, xbmc, xbmcvfs\n__addon__ = xbmcaddon.Addon()\n__language__  = __addon__.getLocalizedString\n__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo(\'profile\'))\n__version__ = __addon__.getAddonInfo(\'version\')\n__addonid__ = __addon__.getAddonInfo(\'id\')\n__addonname__ = __addon__.getAddonInfo(\'name\')\n\n\ndef addon_log( string ):\n\ttry:\n\t\tlog_message = string.encode(\'utf-8\', \'ignore\')\n\texcept:\n\t\tlog_message = \'addonException: addon_log\'\n\tlevel = xbmc.LOGINFO\n\txbmc.log("[%s-%s]: %s" %(__addonid__, __version__, log_message), level=level)\n'
try:from Cryptodome.Cipher import PKCS1_OAEP,AES;from Cryptodome.Util import Padding;print('Cryptodome')
except ImportError:from Crypto.Cipher import PKCS1_OAEP,AES;from Crypto.Util import Padding;print('Crypto')
QUALITY_LIST={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
MPAA_LIST={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
ATTRIBUTE_PATTERN=re.compile('((?:[^,"\']|"[^"]*"|\'[^\']*\')+)')
KEY_LIST=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583',_AD,'cs','TSID',_c,_Ac,_Av,'GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7']
class Tving:
	def __init__(A):A.APIKEY='1e7952d0917d6aab1f0293a063697610';A.NETWORKCODE='CSND0900';A.OSCODE='CSOD0900';A.TELECODE='CSCD0900';A.SCREENCODE='CSSD0100';A.APIKEY_ATV='b6ac9e6384d93d6e533b144b3ef22c42';A.SCREENCODE_ATV='CSSD1300';A.LIVE_LIMIT=20;A.VOD_LIMIT=24;A.EPISODE_LIMIT=30;A.SEARCH_LIMIT=30;A.MOVIE_LIMIT=24;A.PAGE_SIZE=20;A.API_DOMAIN='https://api.tving.com';A.IMG_DOMAIN='https://image.tving.com';A.SEARCH_DOMAIN='https://search-api.tving.com';A.LOGIN_DOMAIN='https://user.tving.com';A.URL_DOMAIN='https://www.tving.com';A.USER_AGENT='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36';A.MODEL='windows_chrome_150.0.0.0';A.MODEL2='"Not;A=Brand";v="8", "Chromium";v="150", "Google Chrome";v="150"';A.DEFAULT_HEADER={_AE:A.USER_AGENT};A.TV_COOKIE_FILENAME='';A.TV_TOKEN_FILENAME='';A.SEARCHED_FILE_NAME='';A.TV_SESSION_COOKIES1='';A.TV_SESSION_COOKIES2='';A.TV_STREAM_FILENAME='';A.TV_SESSION_TEXT1='';A.TV_SESSION_TEXT2='';A.KodiVersion=20;A.TV={};A.TV_TOKEN={};A.Init_TV_Total()
	def Init_TV_Total(A):A.TV={_d:{},_S:{}};A.TV_TOKEN={}
	"\n\tdef callRequestCookies( self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):\n\t\t#HTTP_CLIENT = httpx.Client()  # httpx\n\n\t\tsetHeader = self.DEFAULT_HEADER\n\t\tif headers: setHeader.update( headers )\n\n\t\tif jobtype == 'Get': # Get/Post\n\t\t\tres = httpx.get( url, params=params, headers=setHeader, cookies=cookies )\n\t\telse:\n\t\t\tres = httpx.post( url, json=payload, params=params, headers=setHeader, cookies=cookies )\n\n\t\tprint( str(res.status_code) + ' - ' + str(res.url) )\n\n\t\treturn res\n\t"
	def callRequestCookies(G,jobtype,url,payload=_A,json=_A,params=_A,headers=_A,cookies=_A,redirects=_F):
		F=redirects;E=cookies;D=headers;C=params;B=G.DEFAULT_HEADER
		if D:B.update(D)
		if jobtype==_M:A=requests.get(url,params=C,headers=B,cookies=E,allow_redirects=F)
		else:A=requests.post(url,data=payload,json=json,params=C,headers=B,cookies=E,allow_redirects=F)
		print(str(A.status_code)+' - '+A.url);return A
	def JsonFile_Save(C,filename,dic):
		A=filename
		if A=='':return _F
		try:B=open(A,'w',-1,_G);json.dump(dic,B,indent=4,ensure_ascii=_F);B.close()
		except:return _F
		return _J
	def JsonFile_Load(D,filename):
		A=filename
		if A=='':return{}
		try:B=open(A,'r',-1,_G);C=json.load(B);B.close()
		except:return{}
		return C
	def TextFile_Save(C,filename,resText):
		A=filename
		if A=='':return _F
		try:B=open(A,'w',-1,_G);B.write(resText);B.close()
		except:return _F
		return _J
	def Save_session_acount(A,tvid,tvpw,tvtype,tvpf):A.TV[_d]['tvid']=base64.standard_b64encode(tvid.encode()).decode(_G);A.TV[_d]['tvpw']=base64.standard_b64encode(tvpw.encode()).decode(_G);A.TV[_d]['tvtype']=tvtype;A.TV[_d]['tvpf']=tvpf
	def Load_session_acount(A):
		try:B=base64.standard_b64decode(A.TV[_d]['tvid']).decode(_G);C=base64.standard_b64decode(A.TV[_d]['tvpw']).decode(_G);D=A.TV[_d]['tvtype'];E=A.TV[_d]['tvpf']
		except:return'','',_Q,0
		return B,C,D,E
	def make_stream_header(J,headers,cookies):
		I='{}={}';G=headers;A=cookies;B=''
		if A not in[{},_A,'']:
			H=len(A)
			for(C,D)in A.items():
				B+=I.format(C,D);H+=-1
				if H>0:B+='; '
			G['cookie']=B
		E='';F=0
		for(C,D)in G.items():
			F=F+1
			if F>1:E+='&'
			E+=I.format(C,urllib.parse.quote(D))
		return E
	def makeDefaultCookies(B):
		A={}
		for(C,D)in B.TV[_S].items():A[C]=D
		return A
	def getDeviceStr(E):
		B='undefined';A=[];A.append('Windows');A.append('Chrome');A.append('ko-KR');A.append(B);A.append('24');A.append('한국 표준시');A.append(B);A.append(B);A.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC');C=''
		for D in A:C+=D+'|'
		return C
	def GetDefaultParams(A,uhd=_F):
		C='teleCode'
		if uhd==_F:B={_Ad:A.APIKEY,_Ae:A.NETWORKCODE,_AF:A.OSCODE,C:A.TELECODE,_AG:A.SCREENCODE}
		else:B={_Ad:A.APIKEY_ATV,_Ae:A.NETWORKCODE,_AF:A.OSCODE,C:A.TELECODE,_AG:A.SCREENCODE_ATV}
		return B
	def GetNoCache(A,timetype=1):
		if timetype==1:return int(time.time())
		else:return int(time.time()*1000)
	def GetUniqueid(H,hValue=_A):
		C=hValue
		if C:import hashlib as G;D=G.sha1();D.update(C.encode());E=D.hexdigest()[:8]
		else:
			A=[0 for A in range(256)]
			for F in range(256):A[F]='%02x'%F
			B=int(4294967295*random.random())|0;E=A[255&B]+A[B>>8&255]+A[B>>16&255]+A[B>>24&255]
		return E
	def Web_DecryptKey(C):A=bytes(_Aw,_G);B=bytes(_Ax,_G);return A,B
	def Web_EncryptCiphertext(A,plaintext):B,C=A.Web_DecryptKey();D=AES.new(B,AES.MODE_CBC,C);E=D.encrypt(Padding.pad(plaintext.encode(_G),16));return base64.standard_b64encode(E).decode(_G)
	def Web_DecryptPlaintext(A,ciphertext):B,C=A.Web_DecryptKey();D=AES.new(B,AES.MODE_CBC,C);E=Padding.unpad(D.decrypt(base64.standard_b64decode(ciphertext)),16);return E.decode(_G)
	def WebCookies_Load(A,wc_file):
		try:
			C=open(wc_file,'r',-1,_G);D=C.read();C.close();E=A.Web_DecryptPlaintext(D);A.TV=json.loads(E);B=A.GetDeviceList()
			if B not in['',_K]:A.TV[_S][_e]=B+_K+A.GetUniqueid(B)
		except:return _F
		return _J
	def GetCredential2(B,user_id,user_pw,login_type,user_pf):
		D=user_id
		try:
			if base64.standard_b64encode(D.encode()).decode(_G)in['a3ltOTUxMDg4','a3ltMTA4OA==']:E='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx'
			else:E='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx'
			A={'addon':'tvingm','method':'LOGIN',_N:{'type':login_type,'id':D,'pw':user_pw,'pf':user_pf}};A=json.dumps(A,separators=(',',':'));A=base64.standard_b64encode(A.encode()).decode(_G);G={'proxy-mini':A};F=requests.get(base64.standard_b64decode(E).decode(_G),headers=G)
			if F.status_code!=200:B.Init_TV_Total();return _F
			C=base64.standard_b64decode(F.text).decode(_G);C=json.loads(C);B.TV[_S]=C
		except Exception as H:print(H);B.Init_TV_Total();return _F
		return _J
	def GetCredential_test(A,user_id,user_pw,login_type,user_pf):
		M='{} - {}';L='ko-KR,ko;q=0.9';K='accept-language';J='accept';I='WEB';from curl_cffi import requests as N;E='chrome';F=N.Session()
		try:
			if login_type==_Q:G='https://www.tving.com/account/login/cj-one'
			else:G='https://www.tving.com/account/login/tving'
			O={'returnUrl':'https://www.tving.com/onboarding',_A2:I,'deviceModel':'Windows,none,Chrome','deviceName':A.USER_AGENT,'loginPocType':I};C={J:'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',K:L,_AE:A.USER_AGENT};B=F.get(G,params=O,headers=C,impersonate=E);print(M.format(B.status_code,B.url))
			for H in B.cookies.jar:A.TV[_S][H.name]=H.value
		except Exception as D:print(D);A.Init_TV_Total();return _F
		try:P='https://www.google.com/recaptcha/enterprise/reload?k=6LddMCQqAAAAAF58SSwcjpnOv1c9wWuaaQyiFQIC';C={'x-browser-channel':'stable','x-browser-copyright':'Copyright 2025 Google LLC. All Rights reserved.','x-browser-validation':'UujAs0GAwdnCJ9nvrswZ+O+oco0=','x-browser-year':'2025',_AE:A.USER_AGENT,'content-type':'application/x-protobuffer','origin':'https://www.google.com','referer':'https://www.google.com/recaptcha/enterprise/anchor?ar=1&k=6LddMCQqAAAAAF58SSwcjpnOv1c9wWuaaQyiFQIC&co=aHR0cHM6Ly93d3cudHZpbmcuY29tOjQ0Mw..&hl=ko&v=7gg7H51Q-naNfhmCP3_R47ho&size=invisible&anchor-ms=20000&execute-ms=30000&cb=mb9i1hcvsm1e',J:'*/*',K:L};Q='\n\x187gg7H51Q-naNfhmCP3_R47ho\x12¤\r03AFcWeA7QlpoZ4DOfv2QeXMFJBndjiCpoGkHbxdiRdUkUwS1-uMxF5AIucNffP6voVUzd7eAaGwPxir2l9yY-FLgXty2qUMuoQInziN-bUWT3SnvIEr1A0PQe1GkEq4gx1jFrRUg3OGK67obgqII7-3EGZs306dPx1e0I81cI7JL7TY9k7OaFgBAtvmxTwMpFY9ZYj_C8Wn8WFP72uJ-8A4_aYJzizfqHB2PsHHQ121CiB39h7SRfCFWQF4RukTz1a__PqmsHCQw0eXBcsdYWmZWjE-Amu_Vi_zCigufEsDu7qkAGxm4dWVVjAGGmxXVLUY5cRNR2YRfOTfyxVMftRV31JQho2dPYUOMtYDk7D1bPLROCHm3UMsYx1ZqwovHc5kBypHI7nmyDZVQNurpxnf8BHJdO-bENRFfVEcD4lQqHbseWkfkGmjVaM0pY1XzOBzDmeOL5cgIsbEq-A_NV7Q9X2uQ0Cp4aBu7wWwdkWSRzkXmWQMMhZlS3WSxK0O-fOevhnOFoqYtNtXS9JLcJ2ikEf_4GAy8wRSG4TSexStmWr5AJcBfwbOKEF_7-7oi3-P0veTBJdPmpALZhGvRYJDQWRW_UWp0D3_BoAlVP1z58HhXqRoxiTnvOnfPj_VvMIXScxcV8H7Y-Zy6fWWVXcT9ZRh63PymBu8jAiHsUOHXzTLD5op5LriFZ7C2XbD1nMJ2nvfpxvfeEuOEhgYbTHXXmE-rrgQMiaXq9Ge__kb_0KFaYeAvAtoZU2R_q3JGVv1VFEzJq_00AE4TZgAqQF5akl3weSUS2XikH1ow6zSxX1g2abeNYszN3leb_4MoXKLcXFkWGrRSsHecRchq3EFZsEACLZ91lHfSZMB6fntPUvoW4CZVRPxTBmSc_Kb_9Nzu_4tnx0Ii1kyvMvOWvjPGsd30n37XesUzk15RhkUExbXi1ehzoNjjE3hZkQoN3F44zB4DGkp0Z-71aQQ_T0m1E16ATTFIrXjPRBTmHDWqMzIdEM37NpX3kQTIXZl1fBSrwhXoS2fk8STlsEIbhAXV5gU15ePgDpgN1g_mnMFMjTgA6wpOs5rq1_f4PwuCtnc3_SSfYavCRgm2U9mWeYtVv3t0JwswPglbbyRmt6EZefRX8ZW6lWZkJTauZDxIDZu63gxgjgQuaRD5h_EKbQH-xHVZaJ-IHLdEtCrwFWyAF89IAeUrD8T666dgMWSos7Z1JUiSItl0d-jKr1vE-B3LgJU8SpKY_G0sqMgNjeDFMnzJ51rOSwd0nd2VGH__UT48vTOvuoFXvhh9B5ZygVx_LmziXx0nF-5TzRPwMvdCfz9OtODiAOnBVYo8TBT8jnRYU3N2Q6TpY6MRbZMV-9BElHg6cife5Kiwn2Yw1uLPEn7B4iR-jRADgiwpU7M7imTDmeFHgXCNT9MISqAeQfEm3Ps3v6xPKeqMhPw-WKMoozij_j2KtwHCkez7LMjrbzf9CAt92oG1XQ650J-AKCnXHrG3nVpsPRAkzw8VsUjRdkqzrmlcAPNYh4ioKkeKP-Jo_Zu6Z9a4aVVVXFmLzS2_ABbdg4o0b_3p75TUG9E8r66sbRC1QZ-JhvEdhHDNw8vC2hjtUgFiMVs0d4v_4wOWRnX4I7Oda0tK7BCCFXpXeUjAGNvo5PhqSvpOTsXNTndzRROSA3SLNBHxWSIlbYllwVG8ZsJgRWA"á\x1c!T0mgSUwKAAQeAj8ibQEHewKxYiBr9egqvd-Uqn6k1oUR2hGwD5HCWI_PDIqqgn-QUgbaTEFsh0EkpOUDMOBC6TbH1kpzngk5TF9xUa1y4ZnxTilYIRg-180Di84XbN-W8Rqhth_Kog8Qo_psMH0CzrSwWqsJsE7HeAOWVrHSsib1Xx3DlJgy-MiaCayD_TZZ3MF3TczgXPAjsnBpcAZU14WIgb6nykNJsk11lRr6esfaKT8gTa5JtsMf8lHJQtv-AAksxw1fs1NZZSF8BXdy0tpGuQpjiYJ92BD5Jd6jN_cY6m9pgR8VTBVJs7ZveJU6pGldP3tGPEkJ1YEHFAvXufFlnIY6bBC7wJ2j8IrdZb4noXm1gROlBQ0942z461QHjkBAUzbwKt5Dr5eHf2En29QToBkKZzSD4HYZ2K2g5X-7TcHKGYAEVoSb1Cm7Ja8mIacZe2qvHEjrWQKADO40YQYt9OV0A2_pcdS8rlkTBHDpWO6v4uPuOvARtyNzgZq-lInyfgOePtO3aQvMuNshM_VH3KA7QN1T2Y_h1wG6AChlUeIjoA-7m4Li4anYMr2_kC5K0xZX8Vc9p0qVqq4OJAMjGMQkEhrC0NOPU0jpWp3Gua99nbD0xsWCrzA72rc9KTjTbxyncNwJi8z-fFRup60njPb-jejty5rZ_gDun_Bn8oHU3CWa8eFyrY33z1hWzbszcYFKLRAUgC4GrpAYvGMXKipynF0E6_DBh4DwKNI-R78OPsn4nvXVYUR5PpLRqPlaSFEop1hBGJEaRkp6fhCD0J2LZbIPYjshsjlrIcLPJM7T6fEJVV2QUMQ1xOmtWwayl08mZkJoDuIIPAjFYdJALWWWC6mFfENOeJ1CaxC9q-ralKa1pB_Uhs-MR1gH30ab02d-_Q27M0royzM4nz_wlfRI1_yTNO6qCe_jEVVkPhWcCAKTJjNpXhd66EGBHPHR8drtTxYH_7Ck_mQ_vnTJJ4f8nDW8kP4VUrEWOPeGubm1CI9LCvO9aL911Mm0Ps3bjPWtpeUzhNFf0xJuwfc1op-XLEzVtcXUogcbN6HTfLE3y3AgMGCwxZiSLykZjonxZrATCNPvMAdwhLLtWq0FGDuDbFBF7RfZQ-hCvUG6PcTF9ma9YfKXl8j5gUPDjbkoO-ulFjE5mEereJbkSaQB5WiKlyJih1xSTdbwvt4zBH1kDJnq_zJQBCRc7aKOSVO1A-0wjmlMraVsRAV8dyBJgS7CBBPbE6Fi0njmpkdIokLCCIjVjFk3-4KuMNX8PPKPSePNUfwnnYB-wfebjHUgG-fFquFIHBxgi44jgng3OVbCS18vTp4li2-K0Yh2Z1iHGOli8EuoryizLltxBeohnsTOS-uTTjLgLvk-Hxg8xufzngtLeBL3ElSZOphEpBL3pLxgUI4vs1YhEQkQhopIoI0QPGEHOaPtuQEPbjrzoSv8qpYdhK5AOozbzc_8lFD1oKbJ6AncRxHGLd6YwE9SBlCaHCpIKlHi4okZC14FTN-4qroiM6RqKzH9L1QT0Sn2Z44fNMuPwzI-RXV4kP996fMHUDYVDU6PNlUz58o-bLK-Mqi-2vQu_PDg_CJbjW4MAtlEFM-uusY4mPrV6GgaM9bwYtWGkqRqiGljYV_zez1DPvGUzBNiQ-ktXB47rq2Cx7BlLdRX_ACZPIfCSupIZNJcc-3CK9kf16juEqQu7KlhucqfaE5_7hf3ZY8XBKF-ErucVBvKfTGBA_6jj3JigYJveDr-DH41TlRHWquZljiblx4e_YkY-f85yjRLAHCoi5NvQJhiKILmPkGayZAEfDBZgA--cuT4tfbP5t4qIk0QNdeJ8l_QLm-DJZxdZKG4fH1b9jBasBd7eVczL9OPGNi1A05uJZ0sIUMF4HCm3FjPtpyA-kb8AFAZxsZ5KhDW_fAGmPsWTghNTIxb6rUjf-OfhPxnlNBYn4_DOIo2HGLj5DheHoMIxOLufShix6yaOVy3jbhDBqqKr7TW98qyzaoV6IdMGh2R3RpNFMATWgfvBEmlxDUqHMiQnsg2rKlDW125wnJcu5VcvDwCyaGU2o9CVS9-B5gIAt5x2f9o6n8hlTiX2eP79PZotUbiZYuCmhoSgXWe13hNLPVHJZJ-L74JGfS7Y78AAJDUXZeV6wlX8BY8z-7sotW_K3kDB5kv9Zzm_TVDd75pvF08l52PvmZNLFBsltIB-VdEirSQTk60liURyMAr06OMvZSJfa5VE1IY-5_vhZIaFIa52Dzht-ybIv8NY8700ct7Ifq8Apz_ZRduGXQKN5i3VDg-Dq-eeF2gzuh9hqrLA-gN30VWhsBFdsONdBfWg8-Lcj9DNmvxypF-3_gYR5oKCwUmjaR_SgyfRuWWfJWe69Gp-sa92yuCPKQtXb-K2kOohCqiM-pzjDvVK6oAAK5j_V38fyPtPDYEUCypFkKgbjfae7SP-sQMHXv00H4YZKIIbLZnuMlIMf-F_z2TzJoGLVVsLOoBO0_ctvUmctPQmH-y7lE_Ri2M_Wc20UeYqqf1Z9pbWBFsOTasQO76p4mDgPrs3AnlimT6ouczFG2hAFDeSbI7EYQ0hfCoZQWQcBaZ_KytiNNZqFYwJxo74oe9-qrgGdlWlkgWwKU6SlmJLz0CoZdoXq-LAxOzZ0S0or5HUyJ74rOwFZzcwNQ9n3bWVlm2TU8SJT_XkLo_UPZAwlKTO8ChbgBkF9FRi9A82i80YAZiV5g-yjDbjTYWb5ht5_F4VmA2H7I0ZZcT2-Bxi4SLRosehyWfIG4Dv0QGK3zFKiv2CpgCPj5atV7fZHHlTSS0vzHHWmiIZzQ4_AvYGlmX8pxnAjrifecVQoCCRjrCDtgJ2BsnmLwsR-oMIoSvfuTscYcPT5M6BbEPFkSlJKU-wd_sJI3tyBjz2W0GiSKEwpS0L_8pP1pIjF1-AU7LUKVNDNykkErt6m7sfYv063D6ic0dQF4eZcIYkdM4rlXpdZW6jk7_M-5AiaxxJvCgSToBLgH3D76R5huRS18Wd-W-MIitIOzYr64SmHFFxXntH7tN6OXd39LFH6i68T75mzzpJwNvwtfHlb-V665y6dX2Vi9Yj7vvIdTzzK8lPXI7y9dNWc1MCzExjQlAg5b1XTTA2RCKzi8pbKnlBZUWajZrXQ51rAZ_-HZ-pqsCeJRkd9qN_p2QFk62qvF1DpyF8Z0gsF3ACbh5TYF7DKSIUhoSRq2hdJXlvoXgRIRPAWRrm-oUhdFsv_R_vci8LuQAFM_gam0ReAQjdKcUIkMvbU0vDJfx45Yhi-xUIIcv-c2e_ba3W8H66QRWjOWGcnCn6cuFHCSt31UCLaFa30RctRGVaqaIqvs3OcREZcGekd3zqj9UGZwNQz2a8a4Vu86iyKsLH_FLTKonzbLCKrmYoBmf58F1tBh-gKURZrmEl_O3UvdRdstZEu1oDmxYMRgka_tfMRyhm4z-ycpRZG3ZnFdwkB061AxUoab7KFJPRoP-itIXBvCOtBG3TBT9Okr0UR6LmYBEz9k4ZTZ3Yr_UYyFJ860NzL1NRAdaNg4ZliDkRzObaO-1uJEKF7pnL-_ap4_txmN00uFlS_qXTqOdyEDj7TThxcCok94rYq8OYeaoEGXKBP9fYeA5-yhMQeiQh0ascFICZ2WMFQlCw1rtbPiF4yTmUBH6qTHU*\n-8304418012\x01qB\x05LOGINr(6LddMCQqAAAAAF58SSwcjpnOv1c9wWuaaQyiFQIC\x82\x01×-0RRWH7UOiwWLIHn2cPaP5WHcYftQzUqcZqAQ1gutPqUqwBmWEJYvhQF8AZrwbOttBl_YVthxy0fCR902sy2zSKIemR60DYoEiiN49XP1juRg3xeuS7TGt6HKb-nroFYUMTo0fYOgjdwhhlRtYoxJu5TuvIHa5C1j0VqjpIrzqUKj9iMtkxxhd3ECL-0rEEGTCOUy1VrwScZAxl-1MawxyyCdG502jAiHCKH7d_J0DWbjXeN40k7JTuQ9ujRtB4CyS7WGlJWnrQHvhYZwFaLwWmt1ZmyA5yBhX5hms8WKlFYS0QX37RaIMR9YadMJbs_CEpDBw2T2P6HSkN2rnOYXvY7HrXL5GouUliBF03QB-316EFFGwFFrvVqcVRbUigNAqfQNasSN74its9zWAF3e1RpfcMbzoS6j1i7MluBFQsP2Ovyho8Fd34ESpB2G7JIXeaJYkSuk8shxqsRh1oQpw0y-L5U6vBpLATnQTZ9wEk_xVpN1KyR-c01pkzTOX8VWoEXLLVYMRN9YsmbMcgORAn_dgwRik0mCGJXXoRHICP6X0fb4eiOotjSk0nQNnvh944UGiJVPhB6bzWdjiS68SddMmj-9P0wGPtVSHJzGa_mPDHnXePp4iUN4Eo9Y3oP-L9BCC6SecImWjF4OyG4HgRZ72X78fo9FfhSR05Eyd7minFIHDQ57jXp0MV-I2odokg8w1m_tZvRB52Te963mfPp_Ocq_6V5cAZMcqidtEpAOItkRqCVOmO0WuFHLQL4nyUrA2ZPIYtwJKy_NcwCSA4jegAF3kEqDGZZgSQqsRcMwyhu9PqzNh7xW0C3eR-mDEG3zVPp76grA-ZANH1hdV5kamBTnPC4qqA3ffUpf2d473W7wYfdc7mvNVtQx11zW553WbOobrXMcCZaU7feU2gfd3r0KKzTWw-UbV7VjpM23pQqbseeA4rPhJqCNcoDmS2RyUEECdD5PcN5vlbrX1jOEHkgxCz-mN1xOZwD-65T2N9lrAH37ROpr3fqxNswlohxU72hqFD0rI9mu_FZLYJJAXQeHpUrgZfNItlvhO2giWvFuy-DihB2vCI3zlRaEpV-ULquBlvjiH_Fay6FWjI4r0LYnkVcsnbMVBnd5ImhlXshpc1hmc2VybDGvkParsMZMGjsMpaMpXhOGKuwaHxUqiAUCzDVb8LXsQesQGhegpmctRsSxt5yur-jm4FHneQ2H7W6jvbcwzVeVQpg9f0gRy0k5ZwiaM60ulAmK_IYHXQ6L7hLJAZgV1suJLsRB1ziaP70rTAaIIXr3capAvdeUhfPFUmjVGrxN62TGP8k6xEWzEMI_mcZ8tU_JbxPF0pBOPvhR7-k2vCVq0RIHndpIqcus_buBWwOWI2Seo2yOj3F7ZOXe7OIYMLqzxi9cPjstjxxFeuwR8-zug5HiuN3b-V7__R68bmfwWrfVkz-lovhGr5TrM5VzfQZ7wY77deNNBjc1TsdZalg6XxUal61Kb20SuDGvNJIbkRaD6ZsUbp9VjiSh92zGtClO04EmtEXLRKIzuTasFXsohgQs5x-2M1i53yDGV-1q6DHXWMLnndZs6rA0XgOZGqgdbxCV8CDbE6on3UrwKeJMVQaoOc9Muhe5NpzJg7hSzE1LlHXgCI6v9X6wXcrUTpANF1TNe5FGx5F-P62y6AnPfR5P2WK09nNFRqh1clgOZ2CCd0kCO_EvGQ677TJgmY7g7Xu9YnNdSvRqN7juG6zOsD1f0M2wRb5oiiqgcd9dBkQN2zw1_zy6d-k-vMmXMDoT-ZsP_YbIihBAvzRdawARx50jF2VGcEnXhPKn8S6gkdcc4oPRN0htkqEWn21uc3lTYJKXYLn74U5r9hOcpcupJzxOQ3yGxBU_QKoe9Q4jyR4IHhtQ5g_hMruw3yPNutTdy92vAMlHYJYvrWKvkiegoc9RPpdtuzfVt_U6c-XeoF5fzJKjuRNEbass5gNkrsxlYyDN54WGM8XPdHlTZG24GVqspguRBrMU7lwV63AaF3Dez9GPjQqDULI8RT5Qzd-w5lARgxgVg3E2dCCGmKnTAAmLUOI0hS7EwcLcsjPt0sSaFxDR-EWi7-HDtHIUFOqfjduQNfdYdrhM3yAdn3FiODmXTAJHhS4juQ54gZ7chefYithJ2szVs81m95VfK82zFFrL0PqQacL86rf03q_h02_9f9TSjAVHVC3XHN6YLLbAXZtQjgPxPiRhKviR3A1a783-wMmPrMbYAV7D0mdcxq-RjwDRv5RqlykW4HF7BGZnUZa8RQ-Arb80unglqwxhXwSSIBHG8G2_hHIz5KpsUdqcfkAIetfN-nfpt8C-041CA6U2xDWzEKIblcZ8tU_I8o_5azhuB3EuHxzCW-lGyC3TULrjmdJo5mf4onP5YpRGQzmaBDj-1CGrGVnjzaJAAgq9Tct9ewDFZtk5q3Sed-l3EN4TjGXwZR9wrbNM2ltJVjjCUux6CAzet_lTWB34JT6MBQr36YNUTitRQqgdYoQpu0i2S5U6uB5LATnQTgLYzgMUiuxlwlypv0k1v7HfJE03INXIPR5slXZb_Y8ooguQ_pPxavBSA3zbB732jQrEDUn7nTa8QasIri-RvnStR8GF_An61Noy4MbLxdrETbe4tcsxnrSlM7DiAyFGdHnDfIYvsIqLbUJo3jdUSbtdvxwmT4k-c4FGiBEasI4D3EXreQ6P-Vb4edwIwvuSDyUupFFXGEFLeLn8IaoMHgcEmePY5e_xKsDJs0xeI5GeuBF_qQpzjaaQpT9kgnsITfOJEpAJXwCB4BDLA5oW6To7nSLUSat0aWsMnjOZMngdnv0t5By3MDnj9VZEKWJX4mcgQlxZexvxFrEODDk2z6Hq0SHHgRGzVOZ7-WbAZeNldi_NRsAtqzySy2He5A6YBOMcSXs84kdRLsfR0hu9TtxF4yjOS83elM1nZQqvkfdYYn8BRoPA7yjVc9DJ3Bj-D7FC1DnLQMIzoTKcBbcwjrtxqkC971U19-ku3C2vNRbjvQcUmXuQLbORurQaAzElj_l-P9Fmg-pfXOrnHMJT3WrkLdNMyuOZ0mjmD71yb_YvFA3XBRcX4T9MtaPgcdu9OxzZrzwmSBC2IFn_HQ3i0HYPjRp34YcAfpdNhhwdw2VWs7EXENH6-Hmz7YJ7lYckJbbEagN9CnfVhwENx_yXEGWf2UoYQPqICg7kqjdtCtwFRxRN50xu-EFmxKnjcLbvjSKkfZuolrcxliBp7ugOF81yY0DmdAV66FH3cOMHvfaNCjBBixy-MqiCEAjyI-H7rCaXaJILcTqsfddZUvelnzPBs9kmU6Su8BmWnCVa_I4njQ5oDYr5HdQNiwedr8lGoDGR-AITtSab9GYLXRacFU-0bqc9P0zyY9VC7EiaP5FK0EmD6KLbcZ-dLVtYclSRy3jNQuQ593ivFJFK1EGX5as4jjfRPXfclsxKE6kCfviJ83zqPP6TBNokWZ5wydcRXa89RjvSCsR-BzXCAHEraJHroQrf7QuA-W-AZkRBol_GD1VWG7mWf64zbBXn9RZkcRaEVdvNkoBdPrjeSuEa60ni18IvBRnP_Oa4YjsMdoNQbhOFB1CSN_0-01mbI-3PEUKbiMMkhXLBCeM89oexf5kam9zXCG37j-pXRFZYRS83wYuMIa-RFjx9nqSGj5C-O0myaO6H3VnUWfNIxUN5QtgxrivBIqwZb4F6GHWLIBYKyTHobgdc2VfZcshEw0TeN7AuZC3HHJkWoA2bBFsn7VLsicfFNjh86yumDsVK4Dm2MLZPpSGf1Z80jgqEEX8IdchVDsxx4u0vA-Ui2D5rZGJQTYI8Dbc4Nses5u-iHoUKj_zuDDmzB-2m2SboMJb_te-1TqQgni-VKo_hu-DW8F0PeBna8UrbdWMAxmN5RiA96semDzwyA5yieKEzEJqP-YsgEWMYzl90qjBpKxROXtxVq6y--DHHjIarwN80qVd5Fc-ZYfyB0zhpuyzquDTqpJpjKDp_NRbwSh-wYjAM7nSZczwRg_TjCFnfaLpLHFpPSLo8CbbJKnwomlxpapRqIv0h__F7iFFTBHLYaZtAahsMisehzmPc71QORA2m_Hj2g-165DrUWbb_7mftdvAdY0DB0sg-oBUu5_3-6GqD-WL0GdaoJTecVoxV70TBPsw1wyyCeIU_MUKTaWM3kROIqhPk_kxRjvj6csheZ2XS8FmSwRYzUUKv-e885rwhblBhE0v14-DzCHn-oDZzlGpQTRIoFg8A-p-tjzCpeozij_1J6EFrEN1_TYK_pTcYHVbpRtPFxkSNq0zKE_TiY_F3fRZkBXLsCgNMxbfU_vNdOqxFy2BCN_EfKA1mpGortS5QnUNgGdflEe_FAnjNX8ieV0UCjBJOrMqDlQ58da-wmkuAjff9fvBx3zE-w_S-4_0PdC5kLcccmRakDZsEWhiBXyTRf9VWZ7lXc-Yy4N3YDdtIYT8dRj-FOzQN7ySZrylO3Hn_DLn3RM4v9btwpnbotqBVLjxOHz1F78ErFA1q0JXQEUsLghbQYfdgpfgZRzSRxwxaeDSu78IXLG2ztasnuTZErWedZvxV0k_ZRtA9kDkelJVW1CmXLI6ouh7s4dAE4egh-uyRcq0VzAXPZL46tEGvOKX4eis9Pj-lKu-WEqDxm9CSUGGvTNXXtIoHFX40bjfNJqMcrhehDmCei-jam_nKzBGEFY7ELf7Qskbs6o880pTVLqkSj_WOMK2m1CovRKLXYUbsOYe06idk3xPtu8DmXyFK9JmbDCqMPJ70Aa7syoeVBgiBdtjqT9B296GPTDX_rL4XuS6cNW6UmrOwhwiN64iJu3jCNEjyXPo3KJq_OR5Eofd8rpwJFpS5XxB2ivze1DkHYHnPcHqsbVJMLk-JJsMswkS1iqB6iDkGD3HniMaPeYLriUK43kP5clOxH1TVmzia03kabI4HlFnzeX7ITZtEkgswzsu1xyQWG7U53DWOuDXKsKWrBY4PeXqI8fttRnuCErDNa2SZz9liZL2fLMJXlbJ__grcmbPpjhiKB3TFk1Bmu70yxHVPcF7cVLsUkgLBOrtxNywuLtSho0xp-4nDF_VrPNrvwNrUQWutVp-ddzRyTvwqB7FWkGmjbH6HwU6Eafs05fadBb_1v1SuKqQ1nyyV6KYTEJKDzYZ4ChcH8cfA1eiA-2fV9thKuAlKWAkazCa7LRrbliMojlvQfxSVZvfieuV-r9jmtNpbYNKHNT6EChcI9aN46i_V34Rmd8D-hDVi-GJzyFHnQb9ciitRTkOM9rwpKwxuq2T_G_D_mRYTgIZggX7gRZrkygtUz0jWLsEqezTuX_37GRX7fQYUia9cNl9JOighGui1y9k2dxmDC6YOuHJgGSYrkXNYWY9IwlRk-1ypyu1aVA2-1Doe_HazjPYEKZesGgeZXgxVuxEJu0jKJ1VKlJpLTRa_3L8XrkdoZZclaghmDvf939Ry59D6TGlbeJnkKVdQKhuREkeApldlzoUKo_l18HYPZOFf4XrQTMsAymO5NbM8qjeg9xB-I_0K2InzrBWDbWsLueNY4XLtKmx1X0viTvACayFbILoTjAmXAI37TQLs_l_xZtt5WqT5mzBS81Wa2JJCeOGb0ZswigaADXsEcceKEvDt16iyeHkzeDnjLUpnlPtYdcsMnpQtskfA0zvyK_GK4FzaZ9FeyB4nsOccmkeogoc07oBGNxwSq-CaaCFm9O6ECJ4bKZMPxkvhOrcxagAB9wzCz5jucLGHKIGHyWZMkWqwHZqoTetg1l_dXsxN3yTWU63akRasBYH8ghtw7WugOrfOAuelSthp10y2W9VDaOQ¢\x01²\x05tbMyw1NzcsMTc1MV0sWzEsMjg5LDIyNzRdXSxbWzIsMTA0LDIwOTAuMTk5OTk5ODA5MjY1XSxbMiw1NiwyMTk0LjVdLFsyLDgwLDIyNjEuMTk5OTk5ODA5MjY1XSxbMiwzODIsMjQ2Mi40MDAwMDAwOTUzNjc0XSxbMiwxMzYsMjg1Ni41XSxbMiw5Niw0MzA5LjkwMDAwMDA5NTM2N11dLFtudWxsLG51bGwsbnVsbCxbNTUyLDAuMTA3NDI3NTMzMTIyMDc2NTEsMC4wMDAxMDk0NjU4NTg4MDM3NjExMSwyMF0sWzQxNjEsMC4wOTAzNjI4OTIyNzQ2NDM0MiwwLjAwMDY5NDA4MzcwMTk4MTcyOTEsNl0sNDksMCwwXSxbInd3dy50dmluZy5jb20iLCJzLmdvLW1wdWxzZS5uZXQiLCJvNDUwODIzODI1NTc1MTE2OC5pbmdlc3QudXMuc2VudHJ5LmlvIiwiY2xpZW50LXNkay5oYWNrbGUuaW8iLCJldmVudC5oYWNrbGUuaW8iLCJ3d3cuZ29vZ2xlLmNvbSIsInNyLWNsaWVudC1jZmcuYW1wbGl0dWRlLmNvbSIsImMuZ28tbXB1bHNlLm5ldCIsInd3dy5nc3RhdGljLmNvbSIsImFwaTIuYW1wbGl0dWRlLmNvbSJdLFszLDU1M11d²\x01¤\x1dBDAAYAIAGEcAAUoYIwlDCKAsCLlcgB6AIJtAggoIEEOALSoQRZxSZyAJBDAJCkAJUYhBJESBlKAAIAEgrQBjfABoCBZoQAINGKKCoQGAcMQFGGIBAAIhAhYAT4AFtQiEUjolYQ69EiAXICQeQCCkQgEcQOFRJhQAYJmdAAkAQIIAkTJZocAIAASACBwGMgACCESoELFCFAhQgJCEJcDjQg2VAEAIgABJoEAKEEBgcAQKUIzGcAdAAKgUERAAFUshGKIkkaIoIIAMysQAiWkARQAQATIAFCWGrAFAAhIyZMCxBF4RJQ04JXFwiGMCwmQtCNdSEiwBKgQEDFqNQM8LQEJJPIQWiAIrBtKOAARAygLWQEMCKGRoCIUEBIxsLkRgEgQByFBhFGEzQYqAGGGDbQMQYBAABQAGADIUAMIhiMACwgATNMoRmiCEBVQXEEAIEEwCIrgQTgagwBnpCIpAGybFIDAEAkAgAJLRmRJUigI0m8gBAREUUJgQ0iSJBSEKMB5QQwBAAFQIoBtBAHKJNUAI4EIQrCMhkECAZICqQIMBAAQhQBBCAgQkMEKBQJJDUCqRgUTAAAgAhWgEc0BBUQSigKFEQIAm4BhEByMAISEC4MBkiCOQQah0CIKEAIBAwEAThIOJ+UmRlETAQQkCCCSUQsAQEQRQhEAgcBYGHWAFFIoAMGEhAhAC1EkFBgHgDpgCimRQIA0BAMGQMASOIChiKBDGoCEARiCq7oAIAHYBAIZoAeQQAPAggoAAxACpEggIExgAKCBEKQohCACoF0HSAAJQgAYqbQACYFQhRwSAQLgEqCBACEuDIiICMYAhIBEAJMJgAhTUoaRUBKESfkQE4AUAA5NgKOBCAoRoGCABBkiMACQgAUJxEghoAoFHcApoI8gIARA4rYBmEBhgNBCCD6ZIGGzghAD1AIxEBJCaCgMRCXQj0CAcBtIIAAQJKEAEgMQyauIcyErLIAihUCCECAAikBECQFoADBZScQJ8ABgoBLAGFFpCEIDICggAAQgigCCAlARCmVJDwh64gCQGIrKZQCBhaAlMkoGZAoEQCFRIUgAKAWiQAqARARQFUQgkCZsBI6BNAmoAAg4QCBAOEIJwAGKcKmEADMEQggA4QIoIEgKlSUrC2sDBSQRYr4ACwhECMCwFy2AoIIAWCwSwEiAcRFAIELvJTUSABaIt4NQBwvRFAmUoGRQJLGhRCgAAICVBMgkWEwLwKBCsIOSBAxSIDATIMgyAGMAgoAILBJUyEJBaQDAACKBCxAEwgXAgwaYckAADOGBHyVRUqIwIADYImLMT4kuwSgzAueAmsoaAGumwCDMCLoESaCRgkQEFBGDgBQKc0iCwrCkNEDgAUNAAhIQDsGdDKgSEOUIA3CwWAVmNR2UJD4DozBzIsKQ8eYABB1KANIgSBogAqAhOlEKqvyISQgEAACSCBQWJQBKKEAACmICCiClYAQzhQZBFAA0sNogIBQDFUEQhBEkGBAEQAYCBogEAjWCRIkQEAEAyCSoSCRBwgwAEvaYRaBBkxlhhgYQJDIoAAUkCBhIOQggIoBRDgHBiAQAQGICgQNIiTAGwQARASNSFSkREjJVdKYAopBiABFoAzQImlDKErrACqTIIA0AgSEGiRgEAAgMlDSIiECGYEMWQA5yBBNkBgaQGwOIhJIKUIgACRChC9goAAIBAIAzDTSkgAgQqgpANAA0QIACOhDIZHIUAAQYIEgaAGohFEpAgBqElAECAWDABKSUAQYgJERYIkLIiABBBxAA1EKCYKATxECAAAEgCMgJIDjBAJcBAuUO4iOKoAVgIFAwcLismEEgKAJAlwAw0IA9wEFACQAgNAkYI0BIAggFxAGCJBCRUAVmCJIB4EBaAAOAApBUAZImAEgjkoaQBFHGAEJMjCLAEhFcTKEAgCsAtAYwpICEECACOJBAgADgJIwCEAA4AyGUYCApPJADikhBgwLzAgAQjQiTCQEMgAiqBk1REBAhprWAcIJCAEAQEQghJIIBJrAtCTOGCQkCvQEAUqmnBnBRLAoUAwDQgMICoEQILBhsAAiIABAYBRIhMKQQMgQnoAAAxEhpBJ6BGqJkaAZAO4LsDABR1sgEjAAZgwzp8CBAEhAASQFmQwwFdAJIiAAyjBTvQCBSYBHzQBgDuDQoAYCONIAkijAAQQgImAABEE4MARqmAUhJIAMCwQCoGQzImyN4ICQQIsb3gJAJQcEiA6i2jhITATC3BBBAmMAKCRBkAcAgBCDIOAISsoJLmgCBwIOWRmUBQmgEBLMEQTBiUInCKAMJAhQQBIFRiIgSAVxZCMARQ4AAXAUWChMBCWgAqCCkBABKGAaBZCASYCCFE1CECAdQEcIOkUCCgQMAQYCRkPRBIgIIoRUWUiAMMFMIAEjJABEIxg6JECgIACEoQIBAQMAABkRHDgUIABgAQAEELsCyIUwEQIEtUokAkShRQpFIqbMICAAIAgmckmAEMMVIQQgAEqELmFGCdgEAAVGIDGAOEag0ECBIIQQQyAggYkAaQl4VEDClAVykgSJB2CQAAUJoBkgihEERCAiFnQDIfQIPQgABMIEAAgB8FIIUthUgGxYBAEEQBKSNqSpIQihcbcEBQTIUMHCgYgFswJWhFcjgoABAgZpQgwohWAIxAAGAw0AABA4LAJpLlEIRxAiAIRTWUE0GPlSEQIAcGrwAOxEAJEABCBDAzsIyAhAGIIaQA0gGDMAkQIkBQQAgcCIDZsBQiKKhIQDKEQhihHmQLvNFES4yCFLpAhwjAOQIAQVkARECAAI0IQAGOJGFBAQQ1ESh4QQAGBCCIVkuWBkpqCAFCRaxIDDQlFA4j3DjAIAYwMAOsNAMQpJAEGmNPShASgAEEBAAAMoCupoQGAEocAMABGwjiwCCABDIUAAAgCE2AQBQnBAJABAAEFJDwANDREFkOEMBmRgADCSKBlIgKlSCmSMOBzCQIG6alBQBAFEBRAAgBgIEC4ITLJvA+BgjSIZAxIgoAhGEUmUiEJAEAEIRwgm0IIcYBB0AdAiAJMU4CgAqJYAQYoGAKACSH5CMWqoMAnAAgCCEBYHEUJAUAmqBKQViAg4IkTjABECCeLDCmGRsCQgpBEnDoIAjDKEAQEEkBBHKDABQgAIDI4AgCJEBIxYFB4AsJAwAQAJQIARAaSEhKA4swGCtTggCASgKYhMTEAgIIG/8SRigBAjAJEQYgABATBBDJEUAgQpxYwgARVxCBQnTDUEEAUxAJhREcFJTwgsiRDAAAAgH4LIA5bEZQnxgcJQA2AC0LQfhJwZUQAXUTETAIQCgaEDDAixtAABgyCJ3gAAQxEAENA8BAhEAUKDZgM0AWkAnCDZjAAAhNHJsAzqQQ5CACVAkRAoFFQvCSpSYhkAogIIgQXNFCRUICjYGDgLaiDQQGIEmggABMSCBnCgAiiIlmWBAjtJOEIQJUJEEQAAOcpWgpmBKBgsoRGENITWiKCggiCUIFgSIGB4IwAiGKCn0gngRRSAigIRAAAg3RGOMcE4okWEjJAlKiYAAEAPAIQUhKBkABUIgbhDiGCEMAMgAgEBAIAhQA0QzAgEmAgooJkC0iATgsjgfh0HYARBwQiM0AoLBIC0EwWBogFVXKgpEQUE1NAlkBayAICWRwYiBrRAI4JEElLA4wHozVg5AYhEBaAjoKCreDQgBACIAkhEBRACDAeiNAVBUBNtVAjUkOBQijJlPAhaFUADIqAR2ZSQKgD4CIÊ\x01WW1tbNTAwNiwxMjE2XSxbNjQ2MDcsM10sWzM1ODM3LDNdLFs0NTQ2NCwzXSxbMzE2MTcsNF0sWzM3MTc4LDRdXV0à\x01\xa0\x9c\x01è\x01°ê\x01';B=F.post(P,headers=C,data=Q,impersonate=E);print(M.format(B.status_code,B.url));A.JsonFile_Save(A.TV_SESSION_TEXT1,json.loads(B.text))
		except Exception as D:print(D);A.Init_TV_Total();return _F
		"\n\t\ttry:\n\t\t\tif login_type == '0':\n\t\t\t\t# https://www.tving.com/account/login/cj-one?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding&deviceId=WEB&deviceModel=Windows%2Cnone%2CChrome&deviceName=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F143.0.0.0+Safari%2F537.36&loginPocType=WEB\n\t\t\t\tfirst_url = 'https://www.tving.com/account/login/cj-one'\n\t\t\t# tving\t\t\t\t\n\t\t\telse:\n\t\t\t\t# https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding&deviceId=WEB&deviceModel=Windows%2Cnone%2CChrome&deviceName=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F143.0.0.0+Safari%2F537.36&loginPocType=WEB\n\t\t\t\tfirst_url = 'https://www.tving.com/account/login/tving'\n\n\t\t\tparams = {\n\t\t\t\t\t\t\t'returnUrl'    : 'https://www.tving.com/onboarding',\n\t\t\t\t\t\t\t'deviceId'     : 'WEB',\n\t\t\t\t\t\t\t'deviceModel'  : 'Windows,none,Chrome',\n\t\t\t\t\t\t\t'deviceName'   : self.USER_AGENT,\n\t\t\t\t\t\t\t'loginPocType' : 'WEB',\n\t\t\t}\t\t\n\n\t\t\tpayload = [{\n\t\t\t\t\t\t'captchaCheckboxToken' : None,\n\t\t\t\t\t\t'captchaScoreToken'    : None,\n\t\t\t\t\t\t'deviceId'             : 'ac6a5c9b-700d-4cf5-9282-18587d194f93',\n\t\t\t\t\t\t'deviceModel'          : '',\n\t\t\t\t\t\t'deviceName'           : None,\n\t\t\t\t\t\t'id'                   : 'dfdafdfafd', #user_id,\n\t\t\t\t\t\t'password'             : 'sdddfdfa', #user_pw,\n\t\t\t\t\t\t'isAutoLogin'          : False,\n\t\t\t\t\t\t'loginPocType'         : 'WEB',\n\t\t\t\t\t\t'networkCode'\t\t   : 'CSND0900',\n\t\t\t\t\t\t'osCode'\t\t       : 'CSOD0900',\n\t\t\t\t\t\t'pocType'\t\t\t   : 'PCWEB',\n\t\t\t\t\t\t'returnUrl'            : 'https://www.tving.com/onboarding',\n\t\t\t\t\t\t'screenCode'\t\t   : 'CSSD0100',\n\t\t\t\t\t\t'teleCode'\t\t\t   : 'CSCD0900',\n\t\t\t}]\n\n\t\t\theaders = {\n\t\t\t\t\t\t'user-agent'           : self.USER_AGENT,\n\t\t\t}\n\n\t\t\tresponse = SESSION.post(first_url, params=params, headers=headers, json=payload, impersonate=impersonate )\n\t\t\tprint( '{} - {}'.format( response.status_code, response.url ) )\n\n\t\t\tself.JsonFile_Save( self.TV_SESSION_TEXT1, response.text )\n\t\t\t#self.JsonFile_Save( self.TV_SESSION_COOKIES2, json.loads(response.text) )\n\n\t\texcept Exception as exception:\n\t\t\tprint(exception)\n\t\t\tself.Init_TV_Total()\n\t\t\treturn False\n\t\t";return _J
	def GetDeviceList(B):C=[];A=_K;A=str(B.GetNoCache(timetype=1));return A;"\n\t\ttry:\n\t\t\turl_path   = '/v1/user/device/list'\n\t\t\treq_url = self.API_DOMAIN + url_path\n\n\t\t\t#url_params = { 'apiKey'      : '4263d7d76161f4a19a9efe9ca7903ec4'\n\t\t\t#\t\t\t , 'model'       : 'PC'\n\t\t\t#}\n\t\t\turl_params = self.GetDefaultParams()\n\t\t\tcookies = self.makeDefaultCookies()\n\n\t\t\tresponse = self.callRequestCookies( 'Get', req_url, payload=None, params=url_params, headers=None, cookies=cookies )\n\t\t\treq_json = json.loads( response.text )\n\n\t\t\tsection_list = req_json['body']\n\n\t\t\t#print( req_json )\n\t\t\tfor i_section in section_list:\n\t\t\t\t#if i_section['model'].lower() == 'pc' or i_section['model'].lower() == 'pc-chrome' or i_section['model'].lower() == 'pc-edge':\n\t\t\t\tif i_section['model'].lower().startswith('pc') :\n\t\t\t\t\tdeviceid = i_section['uuid']\n\t\t\t\t\tbreak\n\n\t\t\tif deviceid == '-':\n\t\t\t\tdeviceid = str(self.GetNoCache(timetype=1))\n\t\t\t\t#for i_section in section_list:\n\t\t\t\t#\tdeviceid = i_section['uuid']\n\t\t\t\t#\tbreak\n\n\t\texcept Exception as exception:\n\t\t\tprint(exception)\n\t\t\n\t\treturn deviceid\n\t\t"
	def Get_Now_Datetime(A):return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
	def get_renewal_url(A,mediacode,quality_int=1080,proxyPort=9999):
		C=mediacode;E=A.TV[_S][_e].split(_K)[0];F=A.TV[_S][_e]
		for(G,H)in QUALITY_LIST.items():
			if H==quality_int:I=G
		D=A.GetDefaultParams();J={_AH:C,_A2:E,_AI:F,_AJ:_AN,_AK:I,_AL:str(A.GetNoCache(1)),_AM:_AO,_Af:A.MODEL,_Ag:_Ay,_Ah:'aac',_Ai:_Ak,_Aj:'hls'};D.update(J);B={'addon':'tvingm',_Az:C,'get_url':'https://api.tving.com/v3/media/stream/info','headers':{_AE:A.USER_AGENT,_AP:A.TV_TOKEN[_c]},'params':D,_S:A.makeDefaultCookies()};B=json.dumps(B,separators=(',',':'));B=base64.standard_b64encode(B.encode()).decode(_G);K='http://127.0.0.1:{}/live.mpd?proxy-mini={}'.format(proxyPort,B);return K
	def GetBroadURL(B,mediacode,sel_quality,stype):
		M='subtitles';L='qt_stream';H=mediacode;A={_O:'',_Al:_F,_r:'',_s:'',_t:'',_u:'',_Am:'',L:''};N=B.TV[_S][_e].split(_K)[0];O=B.TV[_S][_e]
		for(P,Q)in QUALITY_LIST.items():
			if Q==sel_quality:F=P
		A[L]=F;print(F)
		try:
			I=str(B.GetNoCache(1));R=_A_;S={_AP:B.TV_TOKEN[_c]};J=B.GetDefaultParams();T={_AH:H,_A2:N,_AI:O,_AJ:_AN,_AL:I,_AM:_AO,_Af:B.MODEL,_Ag:'h264|av1',_Ah:'aac',_Ai:_Ak,'dev.drm':'pr','dev.sl':'SL3000','dev.osn':'windows','dev.osv':'11',_AK:F,_Aj:'hls'};J.update(T);U=B.API_DOMAIN+R;V=B.makeDefaultCookies();W=B.callRequestCookies('Post',U,payload=_A,params=J,headers=S,cookies=V,redirects=_J);G=json.loads(W.text)
			if G[_L][_W][_B]!='000':A[_r]=G[_L][_W]['message'];return A
			C=G[_L]['stream']
			if C['drm_yn']==_i:
				D=C[_v]['drm']['widevine']
				for E in C[_v]['drm']['license'][_B0]:
					if E['drm_type']=='Widevine':A[_s]=E[_s];A[_t]=E[_t];A[_u]=E[_u];break
			else:D=C[_v]['non_drm']
		except Exception as X:print(X);A[_r]=_B1;return A
		Y=I;D=D.split('|')[1];D=B.Decrypt_Url(D,H,Y);A[_O]=D
		if M in C:
			for Z in C.get(M):
				if Z.get(_B)in['KO','KO_CC']:A[_Al]=_J;break
		a=urllib.parse.urlparse(A[_O]);K=a.path.strip('/').split('/');A[_Am]=K[len(K)-1];return A
	def Tving_Parse_mpd(F,stream_url):
		K='bandwidth';J='Representation';L=requests.get(url=stream_url);G=L.content.decode(_G);D=0;M=ET.ElementTree(ET.fromstring(G));E=M.getroot();B=re.match('\\{.*\\}',E.tag)[0];N=dict([A for(B,A)in ET.iterparse(io.StringIO(G),events=['start-ns'])])
		for(H,O)in N.items():
			if H!='ns2':ET.register_namespace(H,O)
		P=E.find(B+'Period')
		for A in P.findall(B+'AdaptationSet'):
			if A.attrib.get('mimeType')=='video/mp4'or A.attrib.get('contentType')=='video':
				for C in A.findall(B+J):
					I=int(C.attrib.get(K))
					if D<I:D=I
				for C in A.findall(B+J):
					if D>int(C.attrib.get(K)):A.remove(C)
			else:continue
		Q=ET.tostring(E).decode(_G);R='<?xml version="1.0" encoding="UTF-8"?>\n';F.TextFile_Save(F.TV_STREAM_FILENAME,R+Q);return _J
	def Tving_Parse_m3u8(C,stream_url):
		H='BANDWIDTH';B='#EXT-X-STREAM-INF'
		try:
			J=requests.get(url=stream_url,headers=_A,stream=_J);D=J.content.decode(_G)
			if'#EXTM3U'not in D:return _F
			if B not in D:return _F
			F=0
			for A in D.splitlines():
				if A.startswith(B):
					E=C.MediaLine_Parse(A,B)
					if F<int(E.get(H)):F=int(E.get(H))
			I=[];G=_F
			for A in D.splitlines():
				if G==_J:G=_F;continue
				if A.startswith(B):
					E=C.MediaLine_Parse(A,B)
					if F!=int(E.get(H)):G=_J;continue
				I.append(A)
		except Exception as K:print(K);return _F
		L='\n'.join(I);C.TextFile_Save(C.TV_STREAM_FILENAME,L);return _J
	def MediaLine_Parse(E,line,prefix):
		A={}
		for B in ATTRIBUTE_PATTERN.split(line.replace(prefix+':',''))[1::2]:C,D=B.split('=',1);A[C.upper()]=D.replace('"','').strip()
		return A
	def CheckQuality(C,sel_qt,qt_list):
		for A in qt_list:
			if sel_qt>=list(A)[0]:return A.get(list(A)[0])
			B=A.get(list(A)[0])
		return B
	def GetLiveChannelList(D,stype,page_int):
		B='schedule';H=[];I=_F
		try:
			c='/v2/media/lives'
			if stype=='onair':Q='CPCS0100,CPCS0400'
			else:Q='CPCS0300'
			R=D.GetDefaultParams();d={_An:'main',_A3:str(page_int),_j:str(D.LIVE_LIMIT),_w:'rating',_Ao:_R,'free':_R,_Ap:_R,_Aq:_R,'channelType':Q};R.update(d);e=D.API_DOMAIN+c;f=D.callRequestCookies(_M,e,payload=_A,params=R,headers=_A,cookies=_A);J=json.loads(f.text)
			if not _W in J[_L]:return H,I
			g=J[_L][_W]
			for A in g:
				S=F=K='';L=M='';h=A['live_code'];S=A[B][_x][_X][_D]
				if A[B][_U]!=_A:F=A[B][_C][_X][_D];F=F+', '+str(A[B][_U][_AQ])+'회';K=A[B][_U][_Y][_D]
				else:F=A[B][_C][_X][_D];K=A[B][_C][_Y][_D]
				try:
					E='';T='';U='';V='';i='';W=''
					for C in A[B][_C][_k]:
						if C[_B]==_AR:T=D.IMG_DOMAIN+C[_E]
						elif C[_B]==_AS:U=D.IMG_DOMAIN+C[_E]
						elif C[_B]==_AT:V=D.IMG_DOMAIN+C[_E]
						elif C[_B]==_AU:i=D.IMG_DOMAIN+C[_E]
						elif C[_B]==_AV:W=D.IMG_DOMAIN+C[_E]
						elif C[_B]=='CAIP0500':E=D.IMG_DOMAIN+C[_E]
						elif C[_B]=='CAIP0800':E=D.IMG_DOMAIN+C[_E]
					if E=='':
						for C in A[B][_x][_k]:
							if C[_B]=='CAIC0400':E=D.IMG_DOMAIN+C[_E]
							elif C[_B]=='CAIC1400':E=D.IMG_DOMAIN+C[_E]
							elif C[_B]=='CAIC1900':E=D.IMG_DOMAIN+C[_E]
				except:_A
				try:
					X=[];Y=[];N=[];Z='';a='';b=''
					for O in A.get(B).get(_C).get(_Z):
						if O!=''and O!='없음':X.append(O)
					for G in A.get(B).get(_C).get(_P):
						if G!=''and G!=_K and G!='없음':Y.append(G)
					if A.get(B).get(_C).get(_f).get(_D)!='':N.append(A[B][_C][_f][_D])
					if A.get(B).get(_C).get(_g).get(_D)!='':N.append(A[B][_C][_g][_D])
					if A.get(B).get(_C).get(_l):Z=A[B][_C][_l]
					if A.get(B).get(_C).get(_A4):a=MPAA_LIST.get(A[B][_C][_A4])
					if _h in A.get(B).get(_C):P=A.get(B).get(_C).get(_h);b=_m%(P[:4],P[4:6],P[6:])
				except:_A
				L=str(A[B]['broadcast_start_time'])[8:12];M=str(A[B]['broadcast_end_time'])[8:12];j={_x:S,_H:F,_Az:h,_I:{_T:T,_a:E,_q:U,_A6:V,_b:W},_Y:K,'channelepg':' [%s:%s ~ %s:%s]'%(L[0:2],L[2:],M[0:2],M[2:]),_n:X,_P:Y,_AW:N,_o:Z,_p:a,_A5:b};H.append(j)
			if J[_L]['has_more']==_i:I=_J
		except Exception as k:print(k)
		return H,I
	def GetProgramList(C,genre,orderby,page_int,genreCode=_R):
		N=genreCode;M=genre;F=[];G=_F
		try:
			Y='/v2/media/episodes';O=C.GetDefaultParams();H={_An:'main',_j:str(C.VOD_LIMIT),_w:orderby,_Ao:_R,'free':_R,_Ap:_R,_Aq:_R,'lastFrequency':'y','personal':'N',_A3:str(page_int)}
			if M not in[_R,'PARAMOUNT']:H['categoryCode']=M
			if N!=_R:H[_B2]=N
			O.update(H);Z=C.API_DOMAIN+Y;a=C.callRequestCookies(_M,Z,payload=_A,params=O,headers=_A,cookies=_A);I=json.loads(a.text)
			if not _W in I[_L]:return F,G
			b=I[_L][_W]
			for A in b:
				c=A[_C][_B];d=A[_C][_X][_D];e=MPAA_LIST.get(A[_C].get(_A4));P='';J='';Q='';R='';S=''
				for B in A[_C][_k]:
					if B[_B]==_AR:P=C.IMG_DOMAIN+B[_E]
					elif B[_B]==_AV:J=C.IMG_DOMAIN+B[_E]
					elif B[_B]==_AS:Q=C.IMG_DOMAIN+B[_E]
					elif B[_B]==_AT:R=C.IMG_DOMAIN+B[_E]
					elif B[_B]==_AU:S=C.IMG_DOMAIN+B[_E]
				f=A[_C][_Y][_D]
				try:T=A[_x][_X][_D]
				except:T=''
				try:
					U=[];V=[];K=[];W='';X=''
					for D in A.get(_C).get(_Z):
						if D!=''and D!=_K and D!='없음':U.append(D)
					for E in A.get(_C).get(_P):
						if E!=''and E!=_K and E!='없음':V.append(E)
					if A.get(_C).get(_f).get(_D)!='':K.append(A[_C][_f][_D])
					if A.get(_C).get(_g).get(_D)!='':K.append(A[_C][_g][_D])
					if A.get(_C).get(_l):W=A[_C][_l]
					if _h in A.get(_C):L=A.get(_C).get(_h);X=_m%(L[:4],L[4:6],L[6:])
				except:_A
				g={_C:c,_H:d,_I:{_T:P,_a:J,_q:Q,_A6:R,_AX:S,_b:J},_Y:f,_x:T,_n:U,_P:V,_AW:K,_o:W,_A5:X,_p:e};F.append(g)
			if I[_L]['has_more']==_i:G=_J
		except Exception as h:print(h)
		return F,G
	def GetEpisodeList(B,program_code,page_int,orderby=_y):
		M=orderby;F=page_int;G=[];H=_F
		try:
			a='/v2/media/frequency/program/'+program_code;N=B.GetDefaultParams();b={_w:'newUpdate',_An:'main',_j:'20',_w:'new',_Ao:_R,'free':_R,_Ap:_R,_Aq:_R};N.update(b);c=B.API_DOMAIN+a;d=B.callRequestCookies(_M,c,payload=_A,params=N,headers=_A,cookies=_A);I=json.loads(d.text)
			if not _W in I[_L]:return G,H
			D=I[_L][_W];J=int(I[_L]['total_count']);O=int(J//(B.EPISODE_LIMIT+1))+1
			if M==_y:K=J-1-(F-1)*B.EPISODE_LIMIT
			else:K=(F-1)*B.EPISODE_LIMIT
			for P in range(B.EPISODE_LIMIT):
				if M==_y:
					A=K-P
					if A<0:break
				else:
					A=K+P
					if A>=J:break
				e=D[A][_U][_B];f=D[A]['vod_name'][_D];E=''
				try:L=str(D[A][_U]['broadcast_date']);E=_m%(L[:4],L[4:6],L[6:])
				except:_A
				try:
					if D[A][_U]['pip_cliptype']=='C012':E+=' - Quick VOD'
				except:_A
				g=D[A][_U][_Y][_D];Q='';R='';S='';T='';U='';V=''
				for C in D[A][_C][_k]:
					if C[_B]==_AR:Q=B.IMG_DOMAIN+C[_E]
					elif C[_B]==_AS:S=B.IMG_DOMAIN+C[_E]
					elif C[_B]==_AT:T=B.IMG_DOMAIN+C[_E]
					elif C[_B]==_AU:U=B.IMG_DOMAIN+C[_E]
					elif C[_B]==_AV:V=B.IMG_DOMAIN+C[_E]
				for C in D[A][_U][_k]:
					if C[_B]=='CAIE0400':R=B.IMG_DOMAIN+C[_E]
				try:
					W=X=Y='';Z=0;W=D[A][_C][_X][_D];X=E;Y=D[A][_x][_X][_D]
					if _AQ in D[A][_U]:Z=D[A][_U][_AQ]
				except:_A
				h={_U:e,_H:f,'subtitle':E,_I:{_T:Q,_a:R,_q:S,_A6:T,_AX:U,_b:V},_Y:g,'info_title':W,_Ar:X,_As:Y,_AQ:Z};G.append(h)
			if O>F:H=_J
		except Exception as i:print(i)
		return G,H,O
	def Gn2_Program_List(B,genre,orderby,page_int):
		C=[];D=_F
		try:
			F=_B3+'/bff/web/v3/content/vod';G={_A3:str(page_int),_j:str(B.PAGE_SIZE),_w:orderby,_B2:genre,_AG:'CSSD0100',_AF:'CSOD0900'};H=B.callRequestCookies(_M,F,payload=_A,params=G,headers=_A,cookies=_A);E=json.loads(H.text);I=E[_N][_AY]
			for A in I:J={_B:A[_B],_H:A[_H],_I:{_T:A[_A7]}};C.append(J)
			if _At in E[_N]:D=_J
		except Exception as K:print(K)
		return C,D
	def GetSearchList(B,search_key,page_int,stype):
		i='grade_nm';h='runtime_sec';g='targetage';f='web_url';e='mast_nm';d='mast_cd';c='count';b='dataList';Z=page_int;Y=search_key;X='vodMVRsb';W='programRsb';V='NO';R='ALL';N=stype;E='cate_nm';F=[];O=_F
		try:
			j='/search/getSearch.jsp';r=B.GetDefaultParams();k={'kwd':Y,'category':'PROGRAM'if N==_A8 else'VODMV','pageNum':str(Z),'notFoundText':Y,'userid':'','siteName':'TVING_WEB',_j:str(B.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':R,'runTime':R,'grade':R,_z:R,'screen':B.SCREENCODE,'os':B.OSCODE,'network':B.NETWORKCODE,'sort1':V,'sort2':V,'sort3':V,'type1':_y,'type2':_y,'type3':_y,'fixedType':_i,'spcMethod':'someword','spcSize':_Q,'schReqCnt':_Q,'vodBCReqCnt':_Q,'programReqCnt':str(B.SEARCH_LIMIT)if N==_A8 else _Q,'vodMVReqCnt':str(B.SEARCH_LIMIT)if N==_AZ else _Q,'aloneReqCnt':_Q,'smrclipReqCnt':_Q,'pickClipReqCnt':_Q,'cSocialClipCnt':_Q,'boardReqCnt':_Q,'talkReqCnt':_Q,'nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'',_Ad:B.APIKEY,_Ae:B.NETWORKCODE,'osCode ':B.OSCODE,'teleCode ':B.TELECODE,'screenCode ':B.SCREENCODE};l=B.SEARCH_DOMAIN+j;m=B.callRequestCookies(_M,l,payload=_A,params=k,headers=_A,cookies=_A);D=json.loads(m.text)
			if N==_A8:
				if not W in D:return F,O
				n=D[W][b];a=int(D[W][c])
				for A in n:
					S=A[d];T=A[e];P=B.IMG_DOMAIN+A['web_url4'];G=B.IMG_DOMAIN+A[f]
					try:
						H=[];I=[];J=[];Q=0;K='';L='';M=''
						if A.get(_Z)!=''and A.get(_Z)!=_K:H=A.get(_Z).split(',')
						if A.get(_P)!=''and A.get(_P)!=_K:I=A.get(_P).split(',')
						if A.get(E)!=''and A.get(E)!=_K:J=A.get(E).split('/')
						if g in A:K=A.get(g)
						if _h in A:C=A.get(_h);M=_m%(C[:4],C[4:6],C[6:]);L=C[:4]
					except:_A
					U={_C:S,_H:T,_I:{_T:P,_a:G,_b:G},_Y:'',_n:H,_P:I,_AW:J,_A9:Q,_p:K,_o:L,_Ar:M};F.append(U)
			else:
				if not X in D:return F,O
				o=D[X][b];a=int(D[X][c])
				for A in o:
					S=A[d];T=A[e].strip();P=B.IMG_DOMAIN+A[f];G=P;p=''
					try:
						H=[];I=[];J=[];Q=0;K='';L='';M=''
						if A.get(_Z)!=''and A.get(_Z)!=_K:H=A.get(_Z).split(',')
						if A.get(_P)!=''and A.get(_P)!=_K:I=A.get(_P).split(',')
						if A.get(E)!=''and A.get(E)!=_K:J=A.get(E).split('/')
						if A.get(h)!='':Q=A.get(h)
						if i in A:K=A.get(i)
						C=A.get(_h)
						if data_str!='':M=_m%(C[:4],C[4:6],C[6:]);L=C[:4]
					except:_A
					U={_AZ:S,_H:T,_I:{_T:P,_a:G,_b:G,_q:p},_Y:'',_n:H,_P:I,_AW:J,_A9:Q,_p:K,_o:L,_Ar:M};F.append(U)
			if a>Z*B.SEARCH_LIMIT:O=_J
		except Exception as q:print(q)
		return F,O
	def Gn2_Search_List(B,search_key,page_int,stype):
		C=stype;D=[];E=_F
		try:
			if C==_A8:F='https://gw.tving.com/bff/search/v2/more/content/series/search';G='AI_SCH_SERIES'
			else:F='https://gw.tving.com/bff/search/v2/more/content/movie/search';G='AI_SCH_MOVIE'
			J={'keyword':search_key,_A3:str(page_int),_j:str(B.PAGE_SIZE),'bandComposeMethod':'MANUAL',_A0:G,_AF:B.OSCODE,_AG:B.SCREENCODE};K=B.callRequestCookies(_M,F,payload=_A,params=J,headers=_A,cookies=_A);H=json.loads(K.text).get(_N).get(_A1)[0]
			for A in H[_AY]:
				if C==_A8:I={_C:A[_B],_H:A[_H],_I:{_T:A[_A7]}}
				else:I={_AZ:A[_B],_H:A[_H],_I:{_T:A[_A7]}}
				D.append(I)
			if _At in H:E=_J
		except Exception as L:print(L)
		return D,E
	def GetBookmarkInfo(E,videoid,vidtype):
		W='content';V='info';S='plot';O=vidtype;N=videoid;D='infoLabels';B='saveinfo';A={'indexinfo':{'ott':'tving','videoid':N,'vidtype':O},B:{_H:'','subtitle':'',_I:{_T:'',_a:'',_q:'',_A6:'',_AX:'',_b:''},D:{'mediatype':O,_H:'',_p:'',S:'',_o:'',_As:'',_A9:0,_n:[],_P:[],_z:[],_A5:'','country':''}}}
		if O=='tvshow':
			P=E.API_DOMAIN+'/v2/media/program/'+N;K=E.GetDefaultParams();Q={_A3:'1',_j:'10',_w:_X};K.update(Q);R=E.callRequestCookies(_M,P,payload=_A,params=K,headers=_A,cookies=_A);L=json.loads(R.text)
			if not _L in L:return{}
			C=L[_L];H=C.get(_X).get(_D).strip();A[B][_H]=H;A[B][D][_H]=H;A[B][D][_p]=MPAA_LIST.get(C.get(_A4));A[B][D][S]=C.get(_Y).get(_D);A[B][D][_o]=C.get(_l);A[B][D][_n]=C.get(_Z);A[B][D][_P]=C.get(_P)
			if C.get(_f).get(_D)!='':A[B][D][_z].append(C.get(_f).get(_D))
			if C.get(_g).get(_D)!='':A[B][D][_z].append(C.get(_g).get(_D))
			G=str(C.get(_h))
			if G!=_Q:A[B][D][_A5]=_m%(G[:4],G[4:6],G[6:])
			I='';J='';M='';T='';U=''
			for F in C.get(_k):
				if F.get(_B)==_AR:I=E.IMG_DOMAIN+F.get(_E)
				elif F.get(_B)==_AV:J=E.IMG_DOMAIN+F.get(_E)
				elif F.get(_B)==_AS:M=E.IMG_DOMAIN+F.get(_E)
				elif F.get(_B)==_AT:T=E.IMG_DOMAIN+F.get(_E)
				elif F.get(_B)==_AU:U=E.IMG_DOMAIN+F.get(_E)
			A[B][_I][_T]=I;A[B][_I][_a]=J;A[B][_I][_q]=M;A[B][_I][_A6]=T;A[B][_I][_AX]=U;A[B][_I][_b]=J
		else:
			P=E.API_DOMAIN+'/v2a/media/stream/info';K=E.GetDefaultParams();Q={_AM:_AO,_AH:N,V:_i,'adReq':'adproxy',_AK:'stream40',_A2:E.TV[_S][_e].split(_K)[0],_AI:E.TV[_S][_e],_AJ:_AN,_AL:str(E.GetNoCache(1)),'wm':_i};K.update(Q);R=E.callRequestCookies(_M,P,payload=_A,params=K,headers=_A,cookies=_A);L=json.loads(R.text)
			if not W in L[_L]:return{}
			C=L[_L][W][V][_AZ];H=C.get(_X).get(_D).strip();A[B][D][_H]=H;H+=' (%s)'%C.get(_l);A[B][_H]=H;A[B][D][_p]=MPAA_LIST.get(C.get(_A4));A[B][D][S]=C.get('story').get(_D);A[B][D][_o]=C.get(_l);A[B][D][_As]=C.get('production');A[B][D][_A9]=C.get(_A9);A[B][D][_n]=C.get(_Z);A[B][D][_P]=C.get(_P)
			if C.get(_f).get(_D)!='':A[B][D][_z].append(C.get(_f).get(_D))
			if C.get(_g).get(_D)!='':A[B][D][_z].append(C.get(_g).get(_D))
			G=str(C.get('release_date'))
			if G!=_Q:A[B][D][_A5]=_m%(G[:4],G[4:6],G[6:])
			I='';J='';M=''
			for F in C.get(_k):
				if F.get(_B)=='CAIM2100':I=E.IMG_DOMAIN+F.get(_E)
				elif F.get(_B)=='CAIM0400':J=E.IMG_DOMAIN+F.get(_E)
				elif F.get(_B)=='CAIM1800':M=E.IMG_DOMAIN+F.get(_E)
			A[B][_I][_T]=I;A[B][_I][_a]=I;A[B][_I][_q]=M;A[B][_I][_b]=J
		return A
	def Make_DecryptKey(C,step,mediacode='000',timecode='000'):
		if step=='1':A=bytes('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),_G);B=bytes(_Ax,_G)
		else:A=bytes(_Aw,_G);B=bytes([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
		return A,B
	def DecryptPlaintext(C,ciphertext,encryption_key,init_vector):A=AES.new(encryption_key,AES.MODE_CBC,init_vector);B=Padding.unpad(A.decrypt(base64.standard_b64decode(ciphertext)),16);return B.decode(_G)
	def Decrypt_Url(A,ciphertext,mediacode,timecode):
		E=timecode;D=mediacode;F=''
		try:B,C=A.Make_DecryptKey('1',mediacode=D,timecode=E);G=json.loads(A.DecryptPlaintext(ciphertext,B,C));H=G.get(_E);B,C=A.Make_DecryptKey('2',mediacode=D,timecode=E);F=A.DecryptPlaintext(H,B,C)
		except Exception as I:print(I)
		return F
	def Get_Apple_buildId(B):
		A=''
		try:C='https://www.tving.com/more/special/SP0071';D=B.callRequestCookies(_M,C,payload=_A,params=_A,headers=_A,cookies=_A);E='"buildId":"(.*?)"';A=re.compile(E,re.DOTALL).findall(D.text)[0]
		except Exception as F:print(F)
		return A
	def Get_AppleGroup_List(A):
		E='bandName';B=[]
		try:
			F=A.Get_Apple_buildId();G=_B4.format(F);H={'key':'SP0071'};I=A.URL_DOMAIN+G;J=A.callRequestCookies(_M,I,payload=_A,params=H,headers=_A,cookies=_A);D=json.loads(J.text)
			if not _V in D:return B
			K=D[_V][_AA][_AB][0][_AC][_N][_Aa][0][_N][_A1]
			for C in K:
				if C[_Ab]not in['VOD_BASIC']:continue
				L=re.findall('/band/\\w+|/curation/\\w+',C['moreUrl'])[0];M={E:C[E],'bandKey':L.split('/')[2]};B.append(M)
		except Exception as N:print(N)
		return B
	def Get_Band_VodList(C,bandKey,nextApiUrl=_K):
		K=nextApiUrl;B=bandKey;D=[];E=''
		try:
			if B.startswith('CR'):L='/curation/{}'.format(B)
			else:L='/band/{}'.format(B)
			if K in[_A,'',_K]:
				M=C.Get_Apple_buildId();N='/_next/data/{}/ko/more{}.json'.format(M,L);O={'key':B};G=C.URL_DOMAIN+N;H=C.callRequestCookies(_M,G,payload=_A,params=O,headers=_A,cookies=_A);A=json.loads(H.text)
				if not _V in A:return D,E
				if B.startswith('CR'):F=A[_V][_AA][_AB][0][_AC][_N][_N][_A1][0]
				else:F=A[_V][_AA][_AB][0][_AC][_N][_Aa][0][_N]['band']
			else:
				G='{}{}{}'.format(_B3,K,'&screenCode=CSSD0100&osCode=CSOD0900');H=C.callRequestCookies(_M,G,payload=_A,params=_A,headers=_A,cookies=_A);A=json.loads(H.text)
				if not _N in A:return D,E
				F=A[_N]
			for I in F[_AY]:J=I[_A7];P={_C:I[_B],_H:I[_H],_I:{_T:J,_a:J,_b:J}};D.append(P)
			E=F.get(_At)or''
		except Exception as Q:print(Q)
		return D,E
	def Get_bandCode_GroupCode(B,GroupCode):
		D=GroupCode;C=''
		try:
			if D=='TVING_APPLE_HOUR':
				G=B.Get_Apple_buildId();H='https://www.tving.com/_next/data/{}/ko/more/special/SP0071.json?key=SP0071'.format(G);E=B.callRequestCookies(_M,H,payload=_A,params=_A,headers=_A,cookies=_A);F=json.loads(E.text)
				if not _V in F:return C
				I=F[_V][_AA][_AB][0][_AC][_N][_Aa][0][_N][_A1]
				for A in I:
					if A[_Ab]!=_B5:continue
					return A[_A0]
			else:
				J={'authorization':'Bearer {}'.format(B.TV_TOKEN[_Au]),_AP:B.TV_TOKEN[_c]};K=['https://gw.tving.com/bff/web/v3/home/main?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/drama?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/entertainment?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/movie?screenCode=CSSD0100&osCode=CSOD0900']
				for L in K:
					E=B.callRequestCookies(_M,L,payload=_A,params=_A,headers=J,cookies=_A);M=json.loads(E.text)
					for A in M[_N][_A1]:
						if D in A[_A0]or D=='TVING_ORIGINAL'and A[_Ab]=='VOD_BASIC_ORIGINAL':
							if':'in A[_A0]:C=A[_A0].split(':')[0]
							else:C=A[_A0]
							return C
		except Exception as N:print(N)
		return C
	def Get_Apple_NowList(A):
		E=[];G=_K
		try:
			H=A.Get_Apple_buildId();I=_B4.format(H);J={'key':'SP0071'};K=A.URL_DOMAIN+I;L=A.callRequestCookies(_M,K,payload=_A,params=J,headers=_A,cookies=_A);B=json.loads(L.text);B=B[_V][_AA][_AB][0][_AC][_N][_Aa][0][_N][_A1]
			for F in B:
				if F[_Ab]==_B5:
					for C in F[_AY]:D=C[_A7];M={_C:C[_B],_H:C[_H],_I:{_T:D,_a:D,_b:D}};E.append(M)
		except Exception as N:print(N)
		return E,G
	def Get_AccessToken(A):
		E='userInfo';D='props'
		try:
			G=A.URL_DOMAIN;F=A.makeDefaultCookies();F.pop(_c);B=A.callRequestCookies(_M,G,payload=_A,params=_A,headers=_A,cookies=F)
			if B.status_code!=200:return _F
			H='<script id="__NEXT_DATA__" type="application/json">\\s*(.*?)\\s*</script>';I=re.compile(H,re.DOTALL).findall(B.text)[0];C=json.loads(I);A.TV_TOKEN[_Au]=C.get(D).get(_V).get(E).get(_Au);A.TV_TOKEN[_AD]=C.get(D).get(_V).get(E).get(_AD);A.TV_TOKEN[_c]=B.cookies[_c];A.TV_TOKEN[_Ac]=C.get(D).get(_V).get(E).get(_Ac);J=A.Get_Now_Datetime();K=J+datetime.timedelta(days=0);A.TV_TOKEN['token_date']=K.strftime('%Y%m%d');A.JsonFile_Save(A.TV_TOKEN_FILENAME,A.TV_TOKEN)
		except Exception as L:print(L);return _F
		return _J
	def GetLiveURL_Test(B,mediacode,sel_quality):
		H=mediacode;A={_O:'',_Al:_F,_r:'',_s:'',_t:'',_u:'',_Am:''};M=B.TV[_S][_e].split(_K)[0];N=B.TV[_S][_e]
		try:
			I=str(B.GetNoCache(1));O=_A_;P={_AP:B.TV_TOKEN[_c]};J=B.GetDefaultParams();Q={_AH:H,_A2:M,_AI:N,_AJ:_AN,_AK:'stream50',_AL:I,_AM:_AO,_Af:B.MODEL,_Ag:_Ay,_Ah:'aac',_Ai:_Ak,_Aj:'hls'};J.update(Q);R=B.API_DOMAIN+O;K=B.makeDefaultCookies();S=B.callRequestCookies('Post',R,payload=_A,params=J,headers=P,cookies=K,redirects=_J);F=json.loads(S.text)
			if F[_L][_W][_B]!='000':A[_r]=F[_L][_W]['message'];return A
			D=F[_L]['stream']
			if D['drm_yn']==_i:
				C=D[_v]['drm']['widevine']
				for E in D[_v]['drm']['license'][_B0]:
					if E['drm_type']=='Widevine':A[_s]=E[_s];A[_t]=E[_t];A[_u]=E[_u];break
			else:C=D[_v]['non_drm']
		except Exception as T:print(T);A[_r]=_B1;return A
		U=I;C=C.split('|')[1];C=B.Decrypt_Url(C,H,U);A[_O]=C;V=A[_O].find('Policy=')
		if V!=-1:Y=A[_O].split('?')[0];G=dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(A[_O]).query));A[_O]='{}&CloudFront-Policy={}'.format(A[_O],G['Policy']);A[_O]='{}&CloudFront-Signature={}'.format(A[_O],G['Signature']);A[_O]='{}&CloudFront-Key-Pair-Id={}'.format(A[_O],G['Key-Pair-Id'])
		W=[_Av,_c,_AD]
		for(L,X)in K.items():
			if L in W:A[_O]='{}&{}={}'.format(A[_O],L,X)
		print(A[_O]);return A