_BH='Dialog.Close(all,true)'
_BG='token_limit'
_BF='inputstream.ffmpegdirect.mime_type'
_BE='inputstream.ffmpegdirect.is_realtime_stream'
_BD='inputstream.ffmpegdirect.open_mode'
_BC='inputstream.ffmpegdirect'
_BB='inputstream.adaptive.license_key'
_BA='inputstream.adaptive.license_type'
_B9='https://www.tving.com/'
_B8='https://www.tving.com'
_B7='gzip, deflate, br, zstd'
_B6='accept-encoding'
_B5='http://127.0.0.1:{}/{}&proxy-mini={}'
_B4='playOption'
_B3='%Y-%m-%d-%H:%M:%S'
_B2='quickvod-mcdn.tving.com'
_B1='delete.png'
_B0='RunPlugin(plugin://plugin.video.tvingm/?%s)'
_A_='Container.Refresh'
_Az='info_title'
_Ay='tving_orderby'
_Ax='search_history.png'
_Aw='search.png'
_Av='APPLE_GROUP'
_Au='-----------------'
_At='TVING_APPLE_HOUR'
_As='LIVE_GROUP'
_Ar='%Y%m%d'
_Aq='drm_header_value'
_Ap='user-agent'
_Ao='MYVIEW_REMOVE'
_An='WATCH_ONE'
_Am='WATCH_ALL'
_Al='SEARCH_ALL'
_Ak='SEARCH_ONE'
_Aj='SEARCH_REMOVE'
_Ai='info_genre'
_Ah='%s?%s'
_Ag='duration'
_Af='aired'
_Ae='LOCAL_SEARCH'
_Ad='onair'
_Ac='SEARCH_HISTORY'
_Ab='MOVIE_GROUP'
_Aa='enter'
_AZ='ENTER_GROUP'
_AY='update'
_AX='drama'
_AW='DRAMA_GROUP'
_AV='application/x-mpegURL'
_AU='inputstream.adaptive.manifest_type'
_AT='inputstream.adaptive'
_AS='com.widevine.alpha'
_AR='error_msg'
_AQ='watchedlist_%s.txt'
_AP='search'
_AO='movies'
_AN='(통합) 찜 영상에 추가'
_AM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'
_AL='program'
_AK='synopsis'
_AJ='nextApiUrl'
_AI='CHANNEL'
_AH='MENU_BOOKMARK'
_AG='TOTAL_HISTORY'
_AF='SEARCH_GROUP'
_AE='WATCH'
_AD='drm_header_key'
_AC='vType'
_AB='delType'
_AA='tvshows'
_A9='vsubtitle'
_A8='vtitle'
_A7='vidtype'
_A6='list'
_A5='int'
_A4='TOTAL_SEARCH'
_A3='inputstream'
_A2='episode'
_A1='XXX'
_A0='BAND_VODLIST'
_z='bandGroup'
_y='skey'
_x='search_key'
_w='EPISODE'
_v='next.png'
_u='다음 페이지'
_t='[B]%s >>[/B]'
_s='director'
_r='cast'
_q='year'
_p='premiered'
_o='mpaa'
_n='mpd'
_m='code'
_l='string'
_k='studio'
_j='drm_server_url'
_i='1'
_h='true'
_g='vod'
_f='bandKey'
_e='icon'
_d='url_filename'
_c='VOD'
_b='videoid'
_a='MOVIE'
_Z='path'
_Y='programcode'
_X='utf-8'
_W='mediatype'
_V='img'
_U='mediacode'
_T='plot'
_S='thumbnail'
_R='streaming_url'
_Q='type'
_P='func'
_O='utf8'
_N='ordernm'
_M='page'
_L='orderby'
_K='movie'
_J=None
_I='-'
_H=True
_G='tvshow'
_F='GN2_LIST'
_E=False
_D='genre'
_C='stype'
_B='title'
_A='mode'
__author__='NightRain'
import os,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs,sys,inputstreamhelper,datetime,time,urllib,base64,json
__addon__=xbmcaddon.Addon()
__language__=__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
MAIN_GROUP=[{_B:'LIVE 채널',_A:_As,_C:'live',_L:_I,_N:_I,_e:'live.png'},{_B:'실시간 인기 드라마',_A:_A0,_f:'HM218820',_z:''},{_B:'실시간 인기 예능',_A:_A0,_f:'HM156521',_z:''},{_B:'Apple TV+ 실시간 인기',_A:_A0,_f:_I,_z:_At},{_B:_Au,_A:_A1,_C:_A1,_L:_I,_N:_I},{_B:'드라마 - 인기순',_A:_AW,_C:_AX,_L:'hit',_N:'인기'},{_B:'드라마 - 업데이트',_A:_AW,_C:_AX,_L:_AY,_N:'업데이트'},{_B:'예능   - 인기순',_A:_AZ,_C:_Aa,_L:'hit',_N:'인기'},{_B:'예능   - 업데이트',_A:_AZ,_C:_Aa,_L:_AY,_N:'업데이트'},{_B:'영화 - 인기순',_A:_Ab,_C:_K,_L:'hit',_N:'인기'},{_B:'영화 - 업데이트',_A:_Ab,_C:_K,_L:_AY,_N:'업데이트'},{_B:'Apple TV+',_A:_Av,_C:_I,_L:_I,_N:_I},{_B:_Au,_A:_A1,_C:_A1,_L:_I,_N:_I},{_B:'Watched (시청목록)',_A:_AE,_C:_I,_L:_I,_N:_I,_e:'history.png'},{_B:'(티빙) 검색',_A:_AF,_C:_I,_L:_I,_N:_I,_e:_Aw},{_B:'(티빙) 검색기록',_A:_Ac,_C:_I,_L:_I,_N:_I,_e:_Ax},{_B:'통합검색 (웨이브,티빙,왓챠,넷플릭스)',_A:_A4,_C:_I,_L:_I,_N:_I,_e:_Aw},{_B:'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록',_A:_AG,_C:_I,_L:_I,_N:_I,_e:_Ax},{_B:'통합 찜 목록 (bookmark mini)',_A:_AH,_C:_I,_L:_I,_N:_I,_e:'bookmark.png'}]
LIVE_GROUP=[{_B:'실시간 TV',_A:_AI,_C:_Ad},{_B:'TVING TV',_A:_AI,_C:'tvingtv'}]
WATCH_GROUP=[{_B:'VOD 시청내역',_A:_AE,_C:_g},{_B:'영화 시청내역',_A:_AE,_C:_K}]
SEARCH_GROUP=[{_B:'VOD 검색',_A:_Ae,_C:_g},{_B:'영화 검색',_A:_Ae,_C:_K}]
DRAMA_GROUP=[{_B:'전체',_A:_F,_D:'PCA',_C:_G},{_B:'로맨스',_A:_F,_D:'PCA007',_C:_G},{_B:'코미디',_A:_F,_D:'PCA020',_C:_G},{_B:'판타지',_A:_F,_D:'PCA023',_C:_G},{_B:'무협',_A:_F,_D:'PCAB',_C:_G},{_B:'공포',_A:_F,_D:'PCAD',_C:_G},{_B:'복수',_A:_F,_D:'PCA030',_C:_G},{_B:'휴먼',_A:_F,_D:'PCA024',_C:_G},{_B:'범죄 스릴러',_A:_F,_D:'PCA015',_C:_G},{_B:'의학',_A:_F,_D:'PCA025',_C:_G},{_B:'웹튠/소설 원작',_A:_F,_D:'PCA028',_C:_G},{_B:'정치/권력',_A:_F,_D:'PCA034',_C:_G},{_B:'법정',_A:_F,_D:'PCA036',_C:_G},{_B:'청춘(성장)',_A:_F,_D:'PCA029',_C:_G},{_B:'오피스 드라마',_A:_F,_D:'PCA040',_C:_G},{_B:'사극/시대극',_A:_F,_D:'PCA017',_C:_G},{_B:'타임슬립',_A:_F,_D:'PCA026',_C:_G},{_B:'단막극',_A:_F,_D:'PCA038',_C:_G},{_B:'해외드라마',_A:_F,_D:'PCPOS',_C:_G},{_B:'미국드라마',_A:_F,_D:'POS007',_C:_G},{_B:'영국드라마',_A:_F,_D:'POS008',_C:_G},{_B:'중국드라마',_A:_F,_D:'POS005',_C:_G},{_B:'일본드라마',_A:_F,_D:'POS006',_C:_G}]
ENTER_GROUP=[{_B:'버라이어티',_A:_F,_D:'PCD005',_C:_G},{_B:'다큐멘터리',_A:_F,_D:'PCT',_C:_G},{_B:'여행',_A:_F,_D:'PCD003',_C:_G},{_B:'쿡방/먹방',_A:_F,_D:'PCD023',_C:_G},{_B:'연애 리얼리티',_A:_F,_D:'PCAB',_C:'PCD010'},{_B:'나영석 예능',_A:_F,_D:'PCD032',_C:_G},{_B:'게임/퀴즈쇼',_A:_F,_D:'PCD029',_C:_G},{_B:'토크쇼',_A:_F,_D:'PCD011',_C:_G},{_B:'서바이벌',_A:_F,_D:'PCD025',_C:_G},{_B:'관찰리얼리티',_A:_F,_D:'PCD024',_C:_G},{_B:'스포츠',_A:_F,_D:'PCD037',_C:_G},{_B:'교육&독서',_A:_F,_D:'PCD038',_C:_G},{_B:'힐링 예능',_A:_F,_D:'PCD034',_C:_G},{_B:'아이돌',_A:_F,_D:'PCD01',_C:_G},{_B:'음악 서바이벌',_A:_F,_D:'PCD027',_C:_G},{_B:'음악예능',_A:_F,_D:'PCD021',_C:_G},{_B:'코미디',_A:_F,_D:'PCD017',_C:_G},{_B:'가족예능',_A:_F,_D:'PCD035',_C:_G},{_B:'뷰티/스타일',_A:_F,_D:'PCD022',_C:_G},{_B:'펫/애니멀',_A:_F,_D:'PCD026',_C:_G},{_B:'콘서트/시상식',_A:_F,_D:'PCD009',_C:_G},{_B:'예능 스페셜',_A:_F,_D:'PCD042',_C:_G}]
MOVIE_GROUP=[{_B:'드라마',_A:_F,_D:'MG100',_C:_K},{_B:'로맨스',_A:_F,_D:'MG130',_C:_K},{_B:'코미디',_A:_F,_D:'MG110',_C:_K},{_B:'애니메이션',_A:_F,_D:'MG240',_C:_K},{_B:'스릴러',_A:_F,_D:'MG140',_C:_K},{_B:'미스터리',_A:_F,_D:'MG150',_C:_K},{_B:'모험',_A:_F,_D:'MG170',_C:_K},{_B:'액션',_A:_F,_D:'MG120',_C:_K},{_B:'판타지',_A:_F,_D:'MG200',_C:_K},{_B:'SF',_A:_F,_D:'MG210',_C:_K},{_B:'공포',_A:_F,_D:'MG160',_C:_K},{_B:'다큐멘터리',_A:_F,_D:'MG250',_C:_K}]
INFO_CONVERT_KEY={_B:{_P:'setTitle',_Q:_l},_T:{_P:'setPlot',_Q:_l},_o:{_P:'setMpaa',_Q:_l},_W:{_P:'setMediaType',_Q:_l},'tvshowtitle':{_P:'setTvShowTitle',_Q:_l},_p:{_P:'setPremiered',_Q:_l},_Af:{_P:'setFirstAired',_Q:_l},_q:{_P:'setYear',_Q:_A5},_Ag:{_P:'setDuration',_Q:_A5},_A2:{_P:'setEpisode',_Q:_A5},'season':{_P:'setSeason',_Q:_A5},_k:{_P:'setStudios',_Q:_A6},_D:{_P:'setGenres',_Q:_A6},'country':{_P:'setCountries',_Q:_A6},_r:{_P:'setCast',_Q:'actor'},_s:{_P:'setDirectors',_Q:_A6}}
from tvingCore import*
class TvingRun:
	def __init__(self,in_addonurl,in_handle,in_params):self._addon_url=in_addonurl;self._addon_handle=in_handle;self.main_params=in_params;self.TvingObj=Tving();self.TvingObj.TV_STREAM_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'));self.TvingObj.TV_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'));self.TvingObj.TV_TOKEN_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'tving_token.json'));self.TvingObj.SEARCHED_FILE_NAME=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
	def addon_noti(self,sting):
		try:dialog=xbmcgui.Dialog();dialog.notification(__addonname__,sting)
		except:_J
	def addon_log(self,string):
		try:log_message=string.encode(_X,'ignore')
		except:log_message='addonException: addon_log'
		level=xbmc.LOGINFO;xbmc.log('[%s-%s]: %s'%(__addonid__,__version__,log_message),level=level)
	def get_keyboard_input(self,title):
		input_text=_J;kb=xbmc.Keyboard();kb.setHeading(title);xbmc.sleep(1000);kb.doModal()
		if kb.isConfirmed():input_text=kb.getText()
		return input_text
	def get_settings_account(self):uid=__addon__.getSetting('id');pwd=__addon__.getSetting('pw');ltype=__addon__.getSetting('login_type');profile=int(__addon__.getSetting('selected_profile'));return uid,pwd,ltype,profile
	def get_settings_uhd(self):return _E
	def get_settings_playback(self):A='active_uhd';playOption={A:_H if __addon__.getSetting(A)==_h else _E,'streamFilename':self.TvingObj.TV_STREAM_FILENAME};return playOption
	def get_settings_proxyport(self):proxyUse=_H if __addon__.getSetting('proxyYn')==_h else _E;proxyPort=int(__addon__.getSetting('proxyPort'));return proxyUse,proxyPort
	def get_settings_totalsearch(self):local_search=_H if __addon__.getSetting('local_search')==_h else _E;local_history=_H if __addon__.getSetting('local_history')==_h else _E;total_search=_H if __addon__.getSetting('total_search')==_h else _E;total_history=_H if __addon__.getSetting('total_history')==_h else _E;menu_bookmark=_H if __addon__.getSetting('menu_bookmark')==_h else _E;return local_search,local_history,total_search,total_history,menu_bookmark
	def get_settings_makebookmark(self):return _H if __addon__.getSetting('make_bookmark')==_h else _E
	def get_settings_direct_replay(self):
		direct_replay=int(__addon__.getSetting('direct_replay'))
		if direct_replay==0:return _E
		else:return _H
	def set_winEpisodeOrderby(self,orderby):__addon__.setSetting(_Ay,orderby);WIN=xbmcgui.Window(10000);WIN.setProperty('TVING_M_ORDERBY',orderby)
	def get_winEpisodeOrderby(self):
		orderby=__addon__.getSetting(_Ay)
		if orderby in['',_J]:orderby='desc'
		return orderby
	def add_dir(self,label,sublabel='',img='',infoLabels=_J,isFolder=_H,params='',isLink=_E,ContextMenu=_J):
		url=_Ah%(self._addon_url,urllib.parse.urlencode(params))
		if sublabel:title='%s < %s >'%(label,sublabel)
		else:title=label
		if not img:img='DefaultFolder.png'
		listitem=xbmcgui.ListItem(title)
		if type(img)==dict:listitem.setArt(img)
		else:listitem.setArt({'thumb':img,'poster':img})
		if self.TvingObj.KodiVersion>=20:
			if infoLabels:self.Set_InfoTag(listitem.getVideoInfoTag(),infoLabels)
		elif infoLabels:listitem.setInfo('Video',infoLabels)
		if not isFolder and not isLink:listitem.setProperty('IsPlayable',_h)
		if ContextMenu:listitem.addContextMenuItems(ContextMenu)
		xbmcplugin.addDirectoryItem(self._addon_handle,url,listitem,isFolder)
	def get_selQuality(self):
		try:quality_type='selected_quality';QT_LIST=[1080,720,480,360];sel_quality_idx=int(__addon__.getSetting(quality_type));return QT_LIST[sel_quality_idx]
		except:_J
		return 720
	def Set_InfoTag(self,video_InfoTag,infoLabels):
		for(key,value)in infoLabels.items():
			if INFO_CONVERT_KEY[key][_Q]==_l:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_P])(value)
			elif INFO_CONVERT_KEY[key][_Q]==_A5:
				if type(value)==int:intValue=int(value)
				else:intValue=0
				getattr(video_InfoTag,INFO_CONVERT_KEY[key][_P])(intValue)
			elif INFO_CONVERT_KEY[key][_Q]=='actor':
				if value!=[]:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_P])([xbmc.Actor(name)for name in value])
			elif INFO_CONVERT_KEY[key][_Q]==_A6:
				if type(value)==list:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_P])(value)
				else:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_P])([value])
	def dp_Main_List(self):
		local_search,local_history,total_search,total_history,menu_bookmark=self.get_settings_totalsearch()
		for main_group in MAIN_GROUP:
			title=main_group.get(_B);icon_img=''
			if main_group.get(_A)==_AF and local_search==_E:continue
			elif main_group.get(_A)==_Ac and local_history==_E:continue
			elif main_group.get(_A)==_A4 and total_search==_E:continue
			elif main_group.get(_A)==_AG and total_history==_E:continue
			elif main_group.get(_A)==_AH and menu_bookmark==_E:continue
			params={_A:main_group.get(_A),_C:main_group.get(_C),_L:main_group.get(_L),_N:main_group.get(_N),_M:_i,_f:main_group.get(_f),_z:main_group.get(_z),_AJ:_I}
			if main_group.get(_A)in[_A1,_A4,_AG,_AH]:isFolder=_E;isLink=_H
			else:isFolder=_H;isLink=_E
			infoLabels={_B:title,_T:title}
			if main_group.get(_A)==_A1:infoLabels=_J
			if _e in main_group:icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_Z),_V,main_group.get(_e))
			self.add_dir(title,sublabel='',img=icon_img,infoLabels=infoLabels,isFolder=isFolder,params=params,isLink=isLink)
		xbmcplugin.endOfDirectory(self._addon_handle)
	def login_main(self):
		tving_id,tving_pw,login_type,tving_pf=self.get_settings_account()
		if not(tving_id and tving_pw):
			dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30901).encode(_O),__language__(30902).encode(_O))
			if ret==_H:__addon__.openSettings();sys.exit()
			else:sys.exit()
		if self.cookiefile_check():return
		if base64.standard_b64encode(tving_id.encode()).decode(_X)in['a3ltOTUxMDg4','a3ltMTA4OA==']:loginResult=self.TvingObj.GetCredential2(tving_id,tving_pw,login_type,tving_pf)
		else:
			dialog=xbmcgui.Dialog();wc_file=dialog.browse(1,__language__(30917).encode(_O),'','.twc',_E,_E,'',_E)
			if wc_file!='':
				tempFile=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'));xbmcvfs.copy(wc_file,tempFile);loginResult=self.TvingObj.WebCookies_Load(tempFile);xbmcvfs.delete(tempFile)
				if loginResult:self.TvingObj.JsonFile_Save(self.TvingObj.TV_COOKIE_FILENAME,self.TvingObj.TV);self.addon_noti(__language__(30918).encode(_O));return
			else:loginResult=_E
		if loginResult==_H:self.cookiefile_save()
		else:self.addon_noti(__language__(30903).encode(_O));sys.exit()
	def dp_Title_Group(self,args):
		stype=args.get(_C)
		if stype=='live':GROUP_LIST=LIVE_GROUP
		elif stype==_AX:GROUP_LIST=DRAMA_GROUP
		elif stype==_Aa:GROUP_LIST=ENTER_GROUP
		else:GROUP_LIST=MOVIE_GROUP
		for i_section in GROUP_LIST:
			title=i_section.get(_B)
			if args.get(_N)!=_I:title+='  ('+args.get(_N)+')'
			params={_A:i_section.get(_A),_C:i_section.get(_C),_D:i_section.get(_D),_L:args.get(_L),_N:args.get(_N),_M:_i};self.add_dir(title,sublabel='',img='',infoLabels=_J,isFolder=_H,params=params)
		if len(GROUP_LIST)>0:xbmcplugin.endOfDirectory(self._addon_handle)
	def dp_LiveChannel_List(self,args):
		stype=args.get(_C);page_int=int(args.get(_M));LIVE_LIST,more_page=self.TvingObj.GetLiveChannelList(stype,page_int)
		for live_list in LIVE_LIST:title=live_list.get(_B);sublabel=live_list.get('channel');thumbnail=live_list.get(_S);synopsis=live_list.get(_AK);channelepg=live_list.get('channelepg');cast=live_list.get(_r);director=live_list.get(_s);info_genre=live_list.get(_Ai);year=live_list.get(_q);mpaa=live_list.get(_o);premiered=live_list.get(_p);info={_W:_A2,_B:title,_k:sublabel,_r:cast,_s:director,_D:info_genre,_T:'%s\n%s\n%s\n\n%s'%(sublabel,title,channelepg,synopsis),_q:year,_o:mpaa,_p:premiered};params={_A:'LIVE',_U:live_list.get(_U),_C:stype};self.add_dir(sublabel,sublabel=title,img=thumbnail,infoLabels=info,isFolder=_E,params=params)
		if more_page:params[_A]=_AI;params[_C]=stype;params[_M]=str(page_int+1);title=_t%_u;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_Z),_V,_v);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		if len(LIVE_LIST)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_E)
	def dp_Program_List(self,args):
		A='genreCode';genre=args.get(_C);orderby=args.get(_L);page_int=int(args.get(_M));genreCode=args.get(A)
		if genreCode==_J:genreCode='all'
		PROGRAM_LIST,more_page=self.TvingObj.GetProgramList(genre,orderby,page_int,genreCode)
		for program_list in PROGRAM_LIST:
			title=program_list.get(_B);thumbnail=program_list.get(_S);synopsis=program_list.get(_AK);channel=program_list.get('channel');cast=program_list.get(_r);director=program_list.get(_s);info_genre=program_list.get(_Ai);year=program_list.get(_q);premiered=program_list.get(_p);mpaa=program_list.get(_o);info={_W:_G,_B:title,_k:channel,_r:cast,_s:director,_D:info_genre,_q:year,_p:premiered,_o:mpaa,_T:synopsis};params={_A:_w,_Y:program_list.get(_AL),_M:_i}
			if self.get_settings_makebookmark():bm_param={_b:program_list.get(_AL),_A7:_G,_A8:title,_A9:channel};bm_param_str=json.dumps(bm_param);bm_param_str=urllib.parse.quote(bm_param_str);bookmark_url=_AM%bm_param_str;ContextMenu=[(_AN,bookmark_url)]
			else:ContextMenu=_J
			self.add_dir(title,sublabel=channel,img=thumbnail,infoLabels=info,isFolder=_H,params=params,ContextMenu=ContextMenu)
		if more_page:params[_A]='PROGRAM';params[_C]=genre;params[_L]=orderby;params[_M]=str(page_int+1);params[A]=genreCode;title=_t%_u;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_Z),_V,_v);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		xbmcplugin.setContent(self._addon_handle,_AA);xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_E)
	def dp_Episode_List(self,args):
		programcode=args.get(_Y);page_int=int(args.get(_M));self.addon_log('programcode : {}'.format(args.get(_Y)));self.addon_log('page        : {}'.format(args.get(_M)));EPISODE_LIST,more_page,total_page=self.TvingObj.GetEpisodeList(programcode,page_int,orderby=self.get_winEpisodeOrderby());self.addon_log('count       : {}'.format(len(EPISODE_LIST)))
		for episode_list in EPISODE_LIST:title=episode_list.get(_B);subtitle=episode_list.get('subtitle');thumbnail=episode_list.get(_S);synopsis=episode_list.get(_AK);info_title=episode_list.get(_Az);aired=episode_list.get(_Af);studio=episode_list.get(_k);frequency=episode_list.get('frequency');info={_W:_A2,_B:info_title,_Af:aired,_k:studio,_A2:frequency,_T:synopsis};params={_A:_c,_U:episode_list.get(_A2),_C:_g,_Y:programcode,_B:title,_S:thumbnail};self.add_dir(title,sublabel=subtitle,img=thumbnail,infoLabels=info,isFolder=_E,params=params)
		if page_int==1:
			info={_T:'정렬순서를 변경합니다.'};params={};params[_A]='ORDER_BY'
			if self.get_winEpisodeOrderby()=='desc':title='정렬순서변경 : 최신화부터 -> 1회부터';params[_L]='asc'
			else:title='정렬순서변경 : 1회부터 -> 최신화부터';params[_L]='desc'
			icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_Z),_V,'sort.png');self.add_dir(title,sublabel='',img=icon_img,infoLabels=info,isFolder=_E,params=params,isLink=_H)
		if more_page:params[_A]=_w;params[_Y]=programcode;params[_M]=str(page_int+1);title=_t%_u;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_Z),_V,_v);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		xbmcplugin.setContent(self._addon_handle,'episodes')
		if len(EPISODE_LIST)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_E)
	def dp_setEpOrderby(self,args):orderby=args.get(_L);self.set_winEpisodeOrderby(orderby);xbmc.executebuiltin(_A_)
	def dp_Movie_List(self,args):
		A='moviecode';genre=args.get(_C);orderby=args.get(_L);page_int=int(args.get(_M));MOVIE_LIST,more_page=self.TvingObj.GetMovieList(genre,orderby,page_int)
		for movie_list in MOVIE_LIST:
			title=movie_list.get(_B);thumbnail=movie_list.get(_S);synopsis=movie_list.get(_AK);info_title=movie_list.get(_Az);year=movie_list.get(_q);cast=movie_list.get(_r);director=movie_list.get(_s);info_genre=movie_list.get(_Ai);duration=movie_list.get(_Ag);premiered=movie_list.get(_p);studio=movie_list.get(_k);mpaa=movie_list.get(_o);info={_W:_K,_B:info_title,_q:year,_r:cast,_s:director,_D:info_genre,_Ag:duration,_p:premiered,_k:studio,_o:mpaa,_T:synopsis};params={_A:_a,_U:movie_list.get(A),_C:_K,_B:title,_S:thumbnail}
			if self.get_settings_makebookmark():bm_param={_b:movie_list.get(A),_A7:_K,_A8:info_title,_A9:''};bm_param_str=json.dumps(bm_param);bm_param_str=urllib.parse.quote(bm_param_str);bookmark_url=_AM%bm_param_str;ContextMenu=[(_AN,bookmark_url)]
			else:ContextMenu=_J
			self.add_dir(title,sublabel='',img=thumbnail,infoLabels=info,isFolder=_E,params=params,ContextMenu=ContextMenu)
		if more_page:params={};params[_A]='MOVIE_SUB';params[_L]=orderby;params[_C]=genre;params[_M]=str(page_int+1);title=_t%_u;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_Z),_V,_v);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		xbmcplugin.setContent(self._addon_handle,_AO);xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_E)
	def dp_Set_Bookmark(self,args):
		A='saveinfo';main_param=urllib.parse.unquote(args.get('bm_param'));main_param=json.loads(main_param);videoid=main_param.get(_b);vidtype=main_param.get(_A7);vtitle=main_param.get(_A8);vsubtitle=main_param.get(_A9);dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30913).encode(_O),vtitle+' \n\n'+__language__(30914))
		if ret==_E:return
		VIDEO_INFO=self.TvingObj.GetBookmarkInfo(videoid,vidtype)
		if vsubtitle!='':
			VIDEO_INFO[A]['subtitle']=vsubtitle
			if vidtype==_G:VIDEO_INFO[A]['infoLabels'][_k]=vsubtitle
		bookmark_param=json.dumps(VIDEO_INFO);bookmark_param=urllib.parse.quote(bookmark_param);bookmark_url='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%bookmark_param;xbmc.executebuiltin(bookmark_url)
	def dp_Search_Group(self,args):
		if _x in args:search_key=args.get(_x)
		else:
			search_key=self.get_keyboard_input(__language__(30906).encode(_X))
			if not search_key:return
		for i_section in SEARCH_GROUP:mode=i_section.get(_A);stype=i_section.get(_C);title=i_section.get(_B);SEARCH_LIST,more_page=self.TvingObj.Gn2_Search_List(search_key,1,stype);infoLabels={_T:'검색어 : '+search_key+'\n\n'+self.Search_FreeList(SEARCH_LIST)};params={_A:mode,_C:stype,_x:search_key,_M:_i};self.add_dir(title,sublabel='',img='',infoLabels=infoLabels,isFolder=_H,params=params)
		if len(SEARCH_GROUP)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_H)
		self.Save_Searched_List(search_key)
	def Search_FreeList(self,search_list):
		resultText='';max_count=7
		try:
			if len(search_list)==0:return'검색결과 없음'
			for i in range(len(search_list)):
				if i>=max_count:resultText=resultText+'...';break
				resultText=resultText+search_list[i][_B]+'\n'
		except:return''
		return resultText
	def dp_Search_History(self,args):
		SEARCH_HISTORY=self.Load_List_File(_AP)
		for search_history in SEARCH_HISTORY:hist_params=dict(urllib.parse.parse_qsl(search_history));skey=hist_params.get(_y).strip();params={_A:_AF,_x:skey};menu_param={_A:_Aj,_AB:_Ak,'sKey':skey,_AC:_I};menu_param_str=urllib.parse.urlencode(menu_param);ContextMenu=[('선택된 검색어 ( %s ) 삭제'%skey,_B0%menu_param_str)];self.add_dir(skey,sublabel='',img=_J,infoLabels=_J,isFolder=_H,params=params,ContextMenu=ContextMenu)
		info={_T:'검색목록 전체를 삭제합니다.'};title='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **';params={_A:_Aj,_AB:_Al,_y:_I,_AC:_I};icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_Z),_V,_B1);self.add_dir(title,sublabel='',img=icon_img,infoLabels=info,isFolder=_E,params=params,isLink=_H);xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_E)
	def dp_Search_List(self,args):
		page_int=int(args.get(_M));stype=args.get(_C)
		if _x in args:search_key=args.get(_x)
		else:
			search_key=self.get_keyboard_input(__language__(30906).encode(_X))
			if not search_key:xbmcplugin.endOfDirectory(self._addon_handle);return
		SEARCH_LIST,more_page=self.TvingObj.Gn2_Search_List(search_key,page_int,stype)
		for search_list in SEARCH_LIST:
			title=search_list.get(_B);thumbnail=search_list.get(_S);info={_W:_G if stype==_g else _K,_B:title,_T:'%s'%title}
			if stype==_g:videoid=search_list.get(_AL);vidtype=_G;params={_A:_w,_Y:videoid,_M:_i};isFolder=_H
			else:videoid=search_list.get(_K);vidtype=_K;params={_A:_a,_U:videoid,_C:_K,_B:title,_S:thumbnail};isFolder=_E
			if self.get_settings_makebookmark():bm_param={_b:videoid,_A7:vidtype,_A8:title,_A9:''};bm_param_str=json.dumps(bm_param);bm_param_str=urllib.parse.quote(bm_param_str);bookmark_url=_AM%bm_param_str;ContextMenu=[(_AN,bookmark_url)]
			else:ContextMenu=_J
			self.add_dir(title,sublabel='',img=thumbnail,infoLabels=info,isFolder=isFolder,params=params,isLink=_E,ContextMenu=ContextMenu)
		if more_page:params[_A]='SEARCH';params[_x]=search_key;params[_M]=str(page_int+1);title=_t%_u;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_Z),_V,_v);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		if stype==_K:xbmcplugin.setContent(self._addon_handle,_AO)
		else:xbmcplugin.setContent(self._addon_handle,_AA)
		xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_E)
	def dp_History_Remove(self,args):
		delType=args.get(_AB);sKey=args.get('sKey');vType=args.get(_AC);dialog=xbmcgui.Dialog()
		if delType==_Al:ret=dialog.yesno(__language__(30911).encode(_O),__language__(30905).encode(_O))
		elif delType==_Ak:ret=dialog.yesno(__language__(30912).encode(_O),__language__(30905).encode(_O))
		elif delType==_Am:ret=dialog.yesno(__language__(30904).encode(_O),__language__(30905).encode(_O))
		elif delType==_An:ret=dialog.yesno(__language__(30916).encode(_O),__language__(30905).encode(_O))
		if ret==_E:sys.exit()
		if delType==_Al:
			if os.path.isfile(self.TvingObj.SEARCHED_FILE_NAME):os.remove(self.TvingObj.SEARCHED_FILE_NAME)
		elif delType==_Ak:
			try:
				filename=self.TvingObj.SEARCHED_FILE_NAME;oldlist=self.Load_List_File(_AP);fp=open(filename,'w',-1,_X)
				for olditem in oldlist:
					old_dic=dict(urllib.parse.parse_qsl(olditem));old_skey=old_dic.get(_y).strip()
					if sKey!=old_skey:fp.write(olditem)
				fp.close()
			except:_J
		elif delType==_Am:
			filename=xbmcvfs.translatePath(os.path.join(__profile__,_AQ%vType))
			if os.path.isfile(filename):os.remove(filename)
		elif delType==_An:
			filename=xbmcvfs.translatePath(os.path.join(__profile__,_AQ%vType))
			try:
				oldlist=self.Load_List_File(vType);fp=open(filename,'w',-1,_X)
				for olditem in oldlist:
					old_dic=dict(urllib.parse.parse_qsl(olditem));old_skey=old_dic.get(_m).strip()
					if sKey!=old_skey:fp.write(olditem)
				fp.close()
			except:_J
		xbmc.executebuiltin(_A_)
	def Load_List_File(self,stype):
		try:
			if stype==_AP:filename=self.TvingObj.SEARCHED_FILE_NAME
			elif stype in[_g,_K]:filename=xbmcvfs.translatePath(os.path.join(__profile__,_AQ%stype))
			else:return[]
			fp=open(filename,'r',-1,_X);result=fp.readlines();fp.close()
		except:result=[]
		return result
	def Save_Watched_List(self,stype,in_params):
		try:
			watchfile=xbmcvfs.translatePath(os.path.join(__profile__,_AQ%stype));oldlist=self.Load_List_File(stype);fp=open(watchfile,'w',-1,_X);newlist=urllib.parse.urlencode(in_params);newlist=newlist+'\n';fp.write(newlist);addcount=0
			for olditem in oldlist:
				old_dic=dict(urllib.parse.parse_qsl(olditem));new_id=in_params.get(_m).strip();old_id=old_dic.get(_m).strip()
				if stype==_g and self.get_settings_direct_replay()==_H:new_id=in_params.get(_b).strip();old_id=old_dic.get(_b).strip()if old_id!=_J else _I
				if new_id!=old_id:
					fp.write(olditem);addcount+=1
					if addcount>=50:break
			fp.close()
		except:_J
	def dp_Watch_List(self,args):
		stype=args.get(_C);direct_replay=self.get_settings_direct_replay()
		if stype==_I:
			for i_section in WATCH_GROUP:title=i_section.get(_B);params={_A:i_section.get(_A),_C:i_section.get(_C)};self.add_dir(title,sublabel='',img='',infoLabels=_J,isFolder=_H,params=params)
			if len(WATCH_GROUP)>0:xbmcplugin.endOfDirectory(self._addon_handle)
		else:
			WATCHLIST=self.Load_List_File(stype)
			for watchlist in WATCHLIST:
				hist_params=dict(urllib.parse.parse_qsl(watchlist));code=hist_params.get(_m).strip();title=hist_params.get(_B).strip();thumbnail=hist_params.get(_V).strip();videoid=hist_params.get(_b).strip()
				try:thumbnail=thumbnail.replace("'",'"');thumbnail=json.loads(thumbnail)
				except:_J
				info={};info[_T]=title
				if stype==_g:
					if direct_replay==_E or videoid==_J:info[_W]=_G;params={_A:_w,_Y:code,_M:_i};isFolder=_H
					else:info[_W]=_A2;params={_A:_c,_U:videoid,_C:_g,_Y:code,_B:title,_S:thumbnail};isFolder=_E
				else:info[_W]=_K;params={_A:_a,_U:code,_C:_K,_B:title,_S:thumbnail};isFolder=_E
				menu_param={_A:_Ao,_AB:_An,'sKey':code,_AC:stype};menu_param_str=urllib.parse.urlencode(menu_param);ContextMenu=[('선택된 시청이력 ( %s ) 삭제'%title,_B0%menu_param_str)];self.add_dir(title,sublabel='',img=thumbnail,infoLabels=info,isFolder=isFolder,params=params,ContextMenu=ContextMenu)
			info={_T:'시청목록을 삭제합니다.'};title='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **';params={_A:_Ao,_AB:_Am,_y:_I,_AC:stype};icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_Z),_V,_B1);self.add_dir(title,sublabel='',img=icon_img,infoLabels=info,isFolder=_E,params=params,isLink=_H)
			if stype==_K:xbmcplugin.setContent(self._addon_handle,_AO)
			else:xbmcplugin.setContent(self._addon_handle,_AA)
			xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_E)
	def Save_Searched_List(self,search_key):
		try:
			searchfile=self.TvingObj.SEARCHED_FILE_NAME;oldlist=self.Load_List_File(_AP);save_params={_y:search_key.strip()};fp=open(searchfile,'w',-1,_X);newlist=urllib.parse.urlencode(save_params);newlist=newlist+'\n';fp.write(newlist);addcount=0
			for olditem in oldlist:
				old_dic=dict(urllib.parse.parse_qsl(olditem));new_id=save_params.get(_y).strip();old_id=old_dic.get(_y).strip()
				if new_id!=old_id:
					fp.write(olditem);addcount+=1
					if addcount>=50:break
			fp.close()
		except:_J
	def play_VIDEO_backup(self,args):
		F='inputstream.adaptive.manifest_headers';E='inputstream.adaptive.stream_headers';D='POST';C='access-control-request-method';B='access-control-request-headers';A='{}|{}';mediacode=args.get(_U);stype=args.get(_C);quality_int=self.get_selQuality();self.addon_log('mediacode, quality_int, stype : %s - %s - %s'%(mediacode,str(quality_int),stype));url_info=self.TvingObj.GetBroadURL(mediacode,quality_int,stype);self.addon_log('qt, stype, url : %s - %s - %s'%(str(quality_int),stype,url_info[_R]))
		if url_info[_R]=='':
			if url_info[_AR]=='':self.addon_noti(__language__(30908).encode(_O))
			else:self.addon_noti(url_info[_AR].encode(_O))
			return
		raw_headers={_Ap:self.TvingObj.USER_AGENT};raw_cookies=self.TvingObj.makeDefaultCookies()
		if url_info[_j]!='':raw_headers[B]=url_info[_AD];raw_headers[C]=D;raw_headers[url_info[_AD]]=url_info[_Aq]
		quick_vod=_E;tmp_pos=url_info[_R].find('Policy=')
		if tmp_pos!=-1:
			tmp_url=url_info[_R].split('?')[0];param_dict=dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(url_info[_R]).query));raw_cookies['CloudFront-Policy']=param_dict['Policy'];raw_cookies['CloudFront-Signature']=param_dict['Signature'];raw_cookies['CloudFront-Key-Pair-Id']=param_dict['Key-Pair-Id'];stream_headers=self.TvingObj.make_stream_header(raw_headers,raw_cookies)
			if _B2 in tmp_url:
				quick_vod=_H;nowTime=self.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1);nowTimeStr=nowTime.strftime(_B3)
				if int(nowTimeStr.replace(_I,'').replace(':',''))<int(param_dict['end'].replace(_I,'').replace(':','')):param_dict['end']=nowTimeStr;self.addon_noti(__language__(30915).encode(_O))
				tmp_url=_Ah%(tmp_url,urllib.parse.urlencode(param_dict,doseq=_H));surl=A.format(tmp_url,stream_headers)
			else:surl=A.format(url_info[_R],stream_headers)
		else:stream_headers=self.TvingObj.make_stream_header(raw_headers,raw_cookies);surl=A.format(url_info[_R],stream_headers);self.addon_log('if tmp_pos == -1')
		proxyUse,proxyPort=self.get_settings_proxyport();playOption=self.get_settings_playback()
		if proxyUse and args.get(_A)in[_c,_a]and quick_vod==_E and(url_info[_j]!=''or url_info[_d].split('.')[1]==_n or url_info[_d].split('.')[1]!=_n and self.TvingObj.KodiVersion>=21 and url_info['qt_stream']=='stream70'):
			if url_info[_d].split('.')[1]==_n:self.TvingObj.Tving_Parse_mpd(url_info[_R])
			else:self.TvingObj.Tving_Parse_m3u8(url_info[_R])
			self.addon_log('xxx '+url_info[_R]);proxyHeader={'addon':'tvingm',_B4:playOption,_d:url_info[_d]};proxyHeader=json.dumps(proxyHeader,separators=(',',':'));proxyHeader=base64.standard_b64encode(proxyHeader.encode()).decode(_X);surl=_B5.format(proxyPort,surl,proxyHeader);raw_headers['proxy-mini']=proxyHeader
		self.addon_log('surl(2) : {}'.format(surl));self.addon_log('drm     : {}'.format(url_info[_j]));stream_headers=self.TvingObj.make_stream_header(raw_headers,raw_cookies);item=xbmcgui.ListItem(path=surl)
		if url_info[_j]!='':
			if stype==_Ad:renew_url=self.TvingObj.get_renewal_url(mediacode,quality_int,proxyPort);item=xbmcgui.ListItem(path=renew_url);self.addon_log('renew_url : {}'.format(renew_url))
			DRMHOST=url_info[_j];PROTOCOL=_n;DRM=_AS;inputstreamhelper.Helper(_n,drm=_AS).check_inputstream();headers={'accept':'*/*',_B6:_B7,url_info[_AD]:url_info[_Aq],'origin':_B8,'referer':_B9,'sec-fetch-mode':'cors','sec-fetch-site':'same-site',_Ap:self.TvingObj.USER_AGENT,B:url_info[_AD],C:D};LICENSE_KEY=DRMHOST+'|'+urllib.parse.urlencode(headers)+'|R{SSM}|';item.setProperty(_A3,_AT)
			if self.TvingObj.KodiVersion<=20:item.setProperty(_AU,PROTOCOL)
			item.setProperty(_BA,DRM);item.setProperty(_BB,LICENSE_KEY);item.setProperty(E,stream_headers);item.setProperty(F,stream_headers)
		elif args.get(_A)in[_c,_a]:
			item.setContentLookup(_E);item.setMimeType(_AV);item.setProperty(_A3,_AT)
			if self.TvingObj.KodiVersion<=20:item.setProperty(_AU,'hls')
			item.setProperty(E,stream_headers);item.setProperty(F,stream_headers)
		elif quick_vod==_H:item.setContentLookup(_E);item.setMimeType(_AV);item.setProperty(_A3,_BC);item.setProperty(_BD,'ffmpeg');item.setProperty(_BE,'false');item.setProperty(_BF,'hls');item.setProperty('ResumeTime','0');item.setProperty('TotalTime','10000')
		xbmcplugin.setResolvedUrl(self._addon_handle,_H,item)
		try:
			if args.get(_A)in[_c,_a]and args.get(_B):params={_m:args.get(_Y)if args.get(_A)==_c else args.get(_U),_V:args.get(_S),_B:args.get(_B),_b:args.get(_U)};self.Save_Watched_List(args.get(_C),params)
		except:_J
	def play_VIDEO(self,args):
		mediacode=args.get(_U);stype=args.get(_C);quality_int=self.get_selQuality();self.addon_log('mediacode, quality_int, stype : {} - {} - {}'.format(mediacode,quality_int,stype));url_info=self.TvingObj.GetBroadURL(mediacode,quality_int,stype);self.addon_log('url(1) : {}'.format(url_info[_R]))
		if url_info[_R]=='':
			if url_info[_AR]=='':self.addon_noti(__language__(30908).encode(_O))
			else:self.addon_noti(url_info[_AR].encode(_O))
			return
		surl=url_info[_R];quick_vod=_E;proxyUse,proxyPort=self.get_settings_proxyport();playOption=self.get_settings_playback()
		if _B2 in surl:
			quick_vod=_H;tmp_url=url_info[_R].split('?')[0];param_dict=dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(url_info[_R]).query));nowTime=self.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1);nowTimeStr=nowTime.strftime(_B3)
			if int(nowTimeStr.replace(_I,'').replace(':',''))<int(param_dict['end'].replace(_I,'').replace(':','')):param_dict['end']=nowTimeStr;self.addon_noti(__language__(30915).encode(_O))
			surl=_Ah%(tmp_url,urllib.parse.urlencode(param_dict,doseq=_H))
		elif proxyUse and args.get(_A)in[_c,_a]and url_info[_j]!='':
			if url_info[_d].split('.')[1]==_n:self.TvingObj.Tving_Parse_mpd(url_info[_R])
			else:self.TvingObj.Tving_Parse_m3u8(url_info[_R])
			self.addon_log('xxx '+url_info[_R]);proxyHeader={'addon':'tvingm',_B4:playOption,_d:url_info[_d]};proxyHeader=json.dumps(proxyHeader,separators=(',',':'));proxyHeader=base64.standard_b64encode(proxyHeader.encode()).decode(_X);surl=_B5.format(proxyPort,surl,proxyHeader)
		self.addon_log('url(2) : {}'.format(surl))
		if url_info[_j]!='':
			self.addon_log('url type : drm   : {}'.format(url_info[_d]));self.addon_log('drm_server_url   : {}'.format(url_info[_j]))
			if stype==_Ad:renew_url=self.TvingObj.get_renewal_url(mediacode,quality_int,proxyPort);surl=renew_url;self.addon_log('onair renew_url : {}'.format(renew_url))
			item=xbmcgui.ListItem(path=surl);DRMHOST=url_info[_j];PROTOCOL=_n;DRM=_AS;inputstreamhelper.Helper(_n,drm=_AS).check_inputstream();headers={'Content-Type':'application/octet-strea','accept':'*/*',_B6:_B7,'accept-language':'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',url_info[_AD]:url_info[_Aq],'origin':_B8,'referer':_B9,_Ap:self.TvingObj.USER_AGENT};LICENSE_KEY=DRMHOST+'|'+urllib.parse.urlencode(headers)+'|R{SSM}|';item.setProperty(_A3,_AT)
			if self.TvingObj.KodiVersion<=20:item.setProperty(_AU,PROTOCOL)
			item.setProperty(_BA,DRM);item.setProperty(_BB,LICENSE_KEY)
		elif quick_vod==_H:item.setContentLookup(_E);item.setMimeType(_AV);item.setProperty(_A3,_BC);item.setProperty(_BD,'ffmpeg');item.setProperty(_BE,'false');item.setProperty(_BF,'hls')
		else:
			self.addon_log('url type : non drm {}'.format(url_info[_d]));item=xbmcgui.ListItem(path=surl);item.setContentLookup(_E);item.setMimeType(_AV);item.setProperty(_A3,_AT)
			if self.TvingObj.KodiVersion<=20:item.setProperty(_AU,'hls')
		xbmcplugin.setResolvedUrl(self._addon_handle,_H,item)
		try:
			if args.get(_A)in[_c,_a]and args.get(_B):params={_m:args.get(_Y)if args.get(_A)==_c else args.get(_U),_V:args.get(_S),_B:args.get(_B),_b:args.get(_U)};self.Save_Watched_List(args.get(_C),params)
		except:_J
	def logout(self):
		dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30910).encode(_O),__language__(30905).encode(_O))
		if ret==_E:sys.exit()
		self.TvingObj.Init_TV_Total()
		if os.path.isfile(self.TvingObj.TV_COOKIE_FILENAME):os.remove(self.TvingObj.TV_COOKIE_FILENAME)
		if os.path.isfile(self.TvingObj.TV_TOKEN_FILENAME):os.remove(self.TvingObj.TV_TOKEN_FILENAME)
		self.addon_noti(__language__(30909).encode(_X))
	def cookiefile_save(self):current=self.TvingObj.Get_Now_Datetime();limit_date=current+datetime.timedelta(days=30);tving_id,tving_pw,login_type,tving_pf=self.get_settings_account();self.TvingObj.Save_session_acount(tving_id,tving_pw,login_type,tving_pf);self.TvingObj.TV['account'][_BG]=limit_date.strftime(_Ar);self.TvingObj.JsonFile_Save(self.TvingObj.TV_COOKIE_FILENAME,self.TvingObj.TV)
	def cookiefile_check(self):
		self.TvingObj.TV=self.TvingObj.JsonFile_Load(self.TvingObj.TV_COOKIE_FILENAME)
		if self.TvingObj.TV=={}:self.TvingObj.Init_TV_Total();return _E
		cf_id,cf_pw,cf_ty,cf_pf=self.get_settings_account();ck_id,ck_pw,ck_ty,ck_pf=self.TvingObj.Load_session_acount()
		if(cf_id!=ck_id or cf_pw!=ck_pw or cf_ty!=ck_ty or cf_pf!=ck_pf)and ck_id!='xxxxx':self.TvingObj.Init_TV_Total();return _E
		if int(self.TvingObj.Get_Now_Datetime().strftime(_Ar))>int(self.TvingObj.TV['account'][_BG]):self.TvingObj.Init_TV_Total();return _E
		return _H
	def tokenfile_check(self):
		self.TvingObj.TV_TOKEN=self.TvingObj.JsonFile_Load(self.TvingObj.TV_TOKEN_FILENAME)
		if self.TvingObj.TV_TOKEN=={}:return _E
		if int(self.TvingObj.Get_Now_Datetime().strftime(_Ar))>int(self.TvingObj.TV_TOKEN['token_date']):self.TvingObj.TV_TOKEN={};return _E
		return _H
	def get_reToken(self):
		if self.tokenfile_check()==_E:self.TvingObj.Get_AccessToken()
	def dp_Global_Search(self,args):
		mode=args.get(_A)
		if mode==_A4:ott_url='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
		else:ott_url='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
		xbmc.executebuiltin(_BH);xbmc.executebuiltin(ott_url)
	def dp_Bookmark_Menu(self,args):ott_url='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)';xbmc.executebuiltin(_BH);xbmc.executebuiltin(ott_url)
	def dp_Apple_Group(self,args):
		BAND_LIST=self.TvingObj.Get_AppleGroup_List()
		for band_list in BAND_LIST:bandName=band_list.get('bandName');bandKey=band_list.get(_f);info={_W:_G,_B:bandName,_T:'%s'%bandKey};params={_A:_A0,_f:bandKey,_M:_i,_AJ:_I};self.add_dir(bandName,sublabel=_J,img='',infoLabels=info,isFolder=_H,params=params)
		if len(BAND_LIST)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_E)
	def dp_Band_VodList(self,args):
		A='M';bandKey=args.get(_f);bandGroup=args.get(_z);nextApiUrl=args.get(_AJ);channelNm='';page_int=int(args.get(_M));self.addon_log('bandKey    : {}'.format(bandKey));self.addon_log('bandGroup  : {}'.format(bandGroup));self.addon_log('nextApiUrl : {}'.format(nextApiUrl))
		if bandGroup==_At:PROGRAM_LIST,nextApiUrl=self.TvingObj.Get_Apple_NowList()
		else:
			if bandGroup not in['',_J]:bandKey=self.TvingObj.Get_bandCode_GroupCode(bandGroup);self.addon_log('new bandKey    : {}'.format(bandKey))
			PROGRAM_LIST,nextApiUrl=self.TvingObj.Get_Band_VodList(bandKey,nextApiUrl)
		for program_list in PROGRAM_LIST:
			title=program_list.get(_B);thumbnail=program_list.get(_S);videoid=program_list.get(_AL);info={_W:_G if not videoid.startswith(A)else _K,_B:title,_T:title+'\n'+_G if not videoid.startswith(A)else _K}
			if not videoid.startswith(A):params={_A:_w,_Y:videoid,_M:_i};isFolder=_H
			else:params={_A:_a,_U:videoid,_C:_K,_B:title,_S:thumbnail};isFolder=_E
			if self.get_settings_makebookmark():bm_param={_b:videoid,_A7:_G,_A8:title,_A9:channelNm};bm_param_str=json.dumps(bm_param);bm_param_str=urllib.parse.quote(bm_param_str);bookmark_url=_AM%bm_param_str;ContextMenu=[(_AN,bookmark_url)]
			else:ContextMenu=_J
			self.add_dir(title,sublabel=channelNm,img=thumbnail,infoLabels=info,isFolder=isFolder,params=params,ContextMenu=ContextMenu)
		if nextApiUrl not in[_J,'',_I]:params[_A]=_A0;params[_f]=bandKey;params[_AJ]=nextApiUrl;params[_M]=str(page_int+1);title=_t%_u;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_Z),_V,_v);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		xbmcplugin.setContent(self._addon_handle,_AA);xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_E)
	def dp_Gn2_Program(self,args):
		genre=args.get(_D);stype=args.get(_C);orderby=args.get(_L);page_int=int(args.get(_M));PROGRAM_LIST,more_page=self.TvingObj.Gn2_Program_List(genre,orderby,page_int)
		for i_list in PROGRAM_LIST:
			title=i_list.get(_B);thumbnail=i_list.get(_S);info={_W:stype,_B:title,_T:title}
			if stype==_K:params={_A:_a,_U:i_list.get(_m),_C:stype,_B:title,_S:thumbnail};isFolder=_E
			else:params={_A:_w,_Y:i_list.get(_m),_C:stype,_B:title,_S:thumbnail,_M:_i};isFolder=_H
			self.add_dir(title,sublabel='',img=thumbnail,infoLabels=info,isFolder=isFolder,params=params,ContextMenu=_J)
		if more_page:params={};params[_A]=_F;params[_L]=orderby;params[_C]=stype;params[_D]=genre;params[_M]=str(page_int+1);title=_t%_u;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_Z),_V,_v);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		if stype==_K:xbmcplugin.setContent(self._addon_handle,_AO)
		else:xbmcplugin.setContent(self._addon_handle,_AA)
		xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_E)
	def tving_main(self):
		self.TvingObj.KodiVersion=int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0]);mode=self.main_params.get(_A,_J)
		if mode=='LOGOUT':self.logout();return
		self.login_main();self.get_reToken()
		if mode is _J:self.dp_Main_List()
		elif mode in[_As,_AW,_AZ,_Ab]:self.dp_Title_Group(self.main_params)
		elif mode==_AI:self.dp_LiveChannel_List(self.main_params)
		elif mode in['LIVE',_c,_a]:self.play_VIDEO(self.main_params)
		elif mode=='PROGRAM':self.dp_Program_List(self.main_params)
		elif mode==_w:self.dp_Episode_List(self.main_params)
		elif mode==_AF:self.dp_Search_Group(self.main_params)
		elif mode in['SEARCH',_Ae]:self.dp_Search_List(self.main_params)
		elif mode==_AE:self.dp_Watch_List(self.main_params)
		elif mode in[_Ao,_Aj]:self.dp_History_Remove(self.main_params)
		elif mode=='ORDER_BY':self.dp_setEpOrderby(self.main_params)
		elif mode=='SET_BOOKMARK':self.dp_Set_Bookmark(self.main_params)
		elif mode in[_A4,_AG]:self.dp_Global_Search(self.main_params)
		elif mode==_Ac:self.dp_Search_History(self.main_params)
		elif mode==_AH:self.dp_Bookmark_Menu(self.main_params)
		elif mode==_Av:self.dp_Apple_Group(self.main_params)
		elif mode==_A0:self.dp_Band_VodList(self.main_params)
		elif mode==_F:self.dp_Gn2_Program(self.main_params)
		else:_J