import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
import requests
import urllib
import json
import base64
import re
import xml.etree.ElementTree as ET
#import io
import os
#import xml.dom.minidom
import time

try:
	from Cryptodome.Cipher    import PKCS1_OAEP, AES
	from Cryptodome.Util      import Padding
except ImportError:
	from Crypto.Cipher    import PKCS1_OAEP, AES
	from Crypto.Util      import Padding


REMOVE_IN_HEADERS  = ['proxy-mini','host','referer','upgrade'] #,'accept-encoding'] #,'content-length']
REMOVE_OUT_HEADERS = ['date','server','set-cookie','keep-alive','connection','transfer-encoding','content-encoding','content-length']

def Addon_Log( string ):
	try:
		import xbmc, xbmcaddon, xbmcvfs
		log_message = string.encode('utf-8', 'ignore')
		level = xbmc.LOGINFO
		xbmc.log( "[%s]: %s" %(xbmcaddon.Addon().getAddonInfo('id'), log_message), level=level )
	except:
		print( string )


class BoriProxyHandler( BaseHTTPRequestHandler ):

	def __init__(self, request, client_address, server):
		self.HTTP_CLIENT = requests.Session()
		self.REQ_INFO    = {}

		try:
		   BaseHTTPRequestHandler.__init__(self, request, client_address, server)
		except (IOError, OSError) as e:
			pass

	def log_message(self, format, *args):
		pass

	def Make_Header( self, header_exceptList=[] ):
		reqHeader = {}
		header_exceptList.extend( REMOVE_IN_HEADERS ) # 소문자

		for key, value in dict(self.headers).items():
			if key.lower() not in header_exceptList:
				reqHeader[key.lower()] = value
				#print ( key.lower() )
				#print (value )
		return reqHeader

	def Make_NewUrl( self, scheme, netloc, path, params='', query='', fragemnt='' ):
		new_url = ( scheme, netloc, path, params, query, fragemnt )
		return urllib.parse.urlunparse( new_url ) 

	def Send_BlankImage( self ):
		self.send_response( 200 )
		self.send_header( 'Content-Type', 'image/x-icon' )
		self.send_header( 'Content-Length', 0 )
		self.end_headers()

	def Send_ErrorPage( self ):
		self.send_response( 200 )
		self.send_header( 'Content-Type', 'text/html; charset=UTF-8' )
		self.end_headers()
		self.wfile.write( 'request error!'.encode('utf-8') )


	def Parse_BaseRequest( self ):
		self.REQ_INFO = {}

		try:
			self.REQ_INFO['url']   = self.path.strip('/') # path 전체

			parseResult = urllib.parse.urlparse( self.REQ_INFO['url'] )  # scheme, netloc, path, params, query, fragment

			self.REQ_INFO['scheme']    = parseResult.scheme
			self.REQ_INFO['netloc']    = parseResult.netloc
			self.REQ_INFO['path']      = parseResult.path.strip('/').split('/')
			self.REQ_INFO['last_path'] = self.REQ_INFO['path'][len(self.REQ_INFO['path'])-1]
			#self.REQ_INFO['params']    = #parseResult.params
			self.REQ_INFO['query']     = dict( urllib.parse.parse_qsl( parseResult.query ) ) 
			#self.REQ_INFO['fragment']  = parseResult.fragment

			lp_type = self.REQ_INFO['last_path'].split('.')
			self.REQ_INFO['last_type'] = lp_type[len(lp_type)-1] #확장자

			length = int(dict(self.headers).get('content-length', 0))
			self.REQ_INFO['postData'] = self.rfile.read(length) if length else None
			#print( self.REQ_INFO )


			# 위아래 순서바꿈
			proxyData = {}
			# header 방법
			if 'proxy-mini' in dict(self.headers):
				proxyData = dict(self.headers).get('proxy-mini')
			# params 방법
			elif 'proxy-mini' in self.REQ_INFO['query']:
				proxyData = self.REQ_INFO['query'].get('proxy-mini')

			if proxyData:
				proxyData = proxyData.replace(' ', '+') # 웹(url) 호출시 오류 복원		
				self.REQ_INFO['addon'] = json.loads( base64.standard_b64decode( proxyData ).decode('utf-8') )
				Addon_Log( 'proxyData 111111' ) #####
			else:
				self.REQ_INFO['addon'] = { 'addon' :  '', 'playOption' : {}, 'url_filename' : '' }


			#print( self.REQ_INFO['addon'] )
			#self.Send_ErrorPage()

		except Exception as e:
			print(Exception)
			self.REQ_INFO['addon'] = { 'addon' :  '', 'playOption' : {}, 'url_filename' : '' }
			return False

		return True


	def Output_Headers( self, response ):
		self.send_response( response.status_code )
		#Addon_Log(  'response.status_code : ' + str( response.status_code ) )

		for resHeader in list(response.headers.items()):
			self.send_header(resHeader[0], resHeader[1])
			#Addon_Log(  str(resHeader[0]) + ' ' + str(resHeader[1]) )

		self.end_headers()


	def Output_Response( self, response, res_data=None, header_exceptList=[], binType=False ):
		# except header
		for resHeader in list(response.headers.items()):
			if resHeader[0].lower() in REMOVE_OUT_HEADERS or resHeader[0].lower() in header_exceptList:
				response.headers.pop(resHeader[0], None)
                
		if res_data and binType == False:
			zipStr = res_data.encode('utf-8')

			response.headers['content-length']   = str(len(zipStr))
			self.Output_Headers( response )
			self.wfile.write( zipStr )
			#self.wfile.write(b'0\r\n\r\n')

		elif res_data and binType == True:
			
			zipStr = res_data

			response.headers['content-length']   = str(len(zipStr))
			self.Output_Headers( response )
			self.wfile.write( zipStr )
			#self.wfile.write(b'0\r\n\r\n')

		else:
			self.Output_Headers( response )
			
			for chunk in response.iter_content(1048576):
				try:
					self.wfile.write(chunk)
				except Exception as e:
					print( e )
					break
			#self.wfile.write(b'0\r\n\r\n')



	def do_HEAD( self ):
		self.send_response(200)


	def do_POST( self ):
		if self.Parse_BaseRequest() == False:
			self.send_response( 404 )
			return 

		# requests URL
		try:
			response = requests.post( url=self.REQ_INFO['url'], headers=self.Make_Header(), data=self.REQ_INFO['postData'], stream=True )
		except Exception as exception:
			print(exception)
			self.Send_ErrorPage()
			return

		self.Output_Response( response, res_data=None, header_exceptList=[] )




	def Make_DecryptKey( self, step, mediacode='000', timecode='000' ):
		if step == '1':
			enckey = bytes( 'cj*tving/{}/{}'.format(mediacode[-3:], timecode[:3]) , 'utf-8')
			#enckey = bytes( 'smart*tv/{}/{}'.format(mediacode[-3:], timecode[:3]) , 'utf-8')
			vector = bytes( '6yhlJ4WF9ZIj6I8n' , 'utf-8')
			#print(vector)

		else:
			enckey = bytes( 'kss2lym0kdw1lks3' , 'utf-8')
			# 아래 3가지 동일값
			#vector = bytes( [ord('*'),0x07,ord('r'),ord(';'),ord('7'),0x05,0x1e,0x01,ord('n'),ord('D'),0x02,ord('3'),ord('*'),ord('a'),ord('&'),ord('<')] )
			#vector = bytes( [0x2a,0x07,0x72,0x3b,0x37,0x05,0x1e,0x01,0x6e,0x44,0x02,0x33,0x2a,0x61,0x26,0x3c] )
			vector = bytes( [42, 7, 114, 59, 55, 5, 30, 1, 110, 68, 2, 51, 42, 97, 38, 60] )
			#print(vector)

		return enckey, vector


	def DecryptPlaintext( self, ciphertext, encryption_key, init_vector ):
		cipher = AES.new(
						encryption_key,
						AES.MODE_CBC,
						init_vector,
		)
		plaintext = Padding.unpad( cipher.decrypt( base64.standard_b64decode( ciphertext ) ) ,16)
		return plaintext.decode('utf-8')


	def Decrypt_Url( self, ciphertext, mediacode, timecode ):
		broad_url = ''

		try:
			# 1차
			enckey, vector = self.Make_DecryptKey( '1', mediacode=mediacode, timecode=timecode )
			encJson = json.loads( self.DecryptPlaintext( ciphertext, enckey, vector ) )
			decText      = encJson.get('url')

			# 2차
			enckey, vector = self.Make_DecryptKey( '2', mediacode=mediacode, timecode=timecode )
			broad_url = self.DecryptPlaintext( decText, enckey, vector )

		except Exception as exception:
			print(exception)

		return broad_url



	# get_renewal_url ****** 관련
	def renew_live_mpd ( self, resText, mediacode ):
		try:
			timecode = str(int(time.time()))
			req_json = json.loads( resText )

			real_mpd_url = req_json['body']['stream']['playback']['drm']['widevine']
			real_mpd_url = real_mpd_url.split('|')[1]
			real_mpd_url = self.Decrypt_Url( real_mpd_url, mediacode, timecode )

			#base_cdn_url     = real_mpd_url.split('manifest.mpd')[0] # 'https://.../019d852dd54f153d786553381d0f2/'
			#cdn_query_string = real_mpd_url.split('?')[1] if '?' in real_mpd_url else '' # 'Policy=...&Signature=...'

			#Addon_Log( 'proxy real_mpd_url : {}'.format(real_mpd_url) )

			response = requests.get( url=real_mpd_url, headers=self.REQ_INFO.get('addon').get('headers') )
			mpd_content = response.text

			#if '<BaseURL>' not in mpd_content:
				# 간단한 문자열 치환으로 <BaseURL> 주입
				#replacement = f'<MPD><BaseURL>{base_cdn_url}?{cdn_query_string}</BaseURL>'
				#mpd_content = mpd_content.replace('<MPD', replacement)

				# asis <MPD id="manifest.mpd" type="dynamic" ..
				# tobe <MPD><BaseURL>https://sogne-live.tving.com/o2/v1/019d8521036e1eb80e796d9bd9cbf/?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE3ODM0Njk4NzYsInJlcyI6Ii9vMi8qIiwic2NjIjoiQ1NTRDAxMDAiLCJvc2MiOiJDU09EMDkwMCIsInZ4ciI6MTA4MCwiZHJtIjp0cnVlLCJ3bWkiOiIiLCJkbXQiOiJzdCIsIm1kbCI6IndpbmRvd3NfY2hyb21lXzE0OS4wLjAuMCIsImlzcCI6IktUIiwic3Z0IjoibGl2ZSJ9.CCSCFrz2t46vL-AtQnIAdkueVHX-VhWC4BySDvcWOM4&sgn.tokver=2&vc=1,2&content_type=LIVE</BaseURL> id="manifest.mpd"
			#print( mpd_content )
			return mpd_content

		except Exception as exception:
			print(exception)
			return ''




	def do_GET( self ):

		if self.Parse_BaseRequest() == False:
			self.send_response( 404 )
			return 

		#print ( self.REQ_INFO )

		if self.REQ_INFO['last_path'].lower() == 'favicon.ico':
			self.Send_BlankImage() # 공백icon
			return 

		#print( self.REQ_INFO.get('url') )


		# get_renewal_url ****** 관련
		if      self.REQ_INFO['last_path'].lower() == 'live.mpd' \
		    and len(self.REQ_INFO['path'])         == 1 \
			and self.REQ_INFO.get('addon').get('addon') == 'tvingm':

			re_url     = self.REQ_INFO.get('addon').get('get_url')
			re_headers = self.REQ_INFO.get('addon').get('headers')
			re_params  = self.REQ_INFO.get('addon').get('params')
			re_cookies = self.REQ_INFO.get('addon').get('cookies')

			response = requests.post( url=re_url, params=re_params, headers=re_headers, cookies=re_cookies)
			
			res_data = self.renew_live_mpd( response.text, self.REQ_INFO.get('addon').get('mediacode')  )

			self.Output_Response( response, res_data, header_exceptList=[], binType=False )
			return
		# get_renewal_url ****** 관련




		if self.REQ_INFO['scheme'].lower() not in ['http','https']:
			self.send_response( 404 )
			return 

		#print ( self.REQ_INFO )
		

		res_data = None
		#print( self.REQ_INFO['addon']['playOption'] )

		try:
			if      self.REQ_INFO['path'][len(self.REQ_INFO['path'])-2].startswith( 'QualityLevels(1000,as=KO)' ) \
				and self.REQ_INFO['path'][len(self.REQ_INFO['path'])-1].startswith( 'Fragments(KO=' ) \
				and self.REQ_INFO.get('addon').get('addon') == 'tvingm':


				# requests URL
				try:
					#response = requests.get( url=self.REQ_INFO['url'], headers=self.Make_Header(), stream=True )
					response = requests.get( url=self.REQ_INFO['url'], headers=self.Make_Header(), stream=False )
				except Exception as exception:
					print(exception)
					Addon_Log( 'do_get reuests call error') #####
					self.Send_ErrorPage()
					return

				if '<p begin="' in response.text:
					Addon_Log( '**  Tving_Parse_subtitle **') #####
					#subtitle = response.content
					subtitle = response.text
					res_data = self.Tving_Parse_subtitle( subtitle )

				#self.Output_Response( response, res_data, header_exceptList=[], binType=True )
				self.Output_Response( response, res_data, header_exceptList=[], binType=False )


			elif self.REQ_INFO['last_type'].lower() in ['mpd'] and self.REQ_INFO.get('addon').get('addon') == 'tvingm':

				# requests URL
				try:
					#response = requests.get( url=self.REQ_INFO['url'], headers=self.Make_Header(), stream=True )
					response = requests.get( url=self.REQ_INFO['url'], headers=self.Make_Header(), stream=False )
				except Exception as exception:
					print(exception)
					Addon_Log( 'do_get reuests call error') #####
					self.Send_ErrorPage()
					return
				
				Addon_Log( 'mpd os.isfile' ) #####
				#Addon_Log( self.REQ_INFO['addon']['playOption']['streamFilename'] ) #####

				if os.path.isfile( self.REQ_INFO['addon']['playOption']['streamFilename']  ):
					try:
						fp = open(self.REQ_INFO['addon']['playOption']['streamFilename'], 'r', -1, 'utf-8')
						res_data = fp.read()
						fp.close()
					except:
						res_data = None
				else:
					#mpd = response.content.decode('utf-8')
					mpd = response.text
					res_data = mpd

				self.Output_Response( response, res_data, header_exceptList=[], binType=False )


			elif (   self.REQ_INFO['last_path'].lower() in self.REQ_INFO.get('addon').get('url_filename')
				#   self.REQ_INFO['last_path'].lower() in ['playlist.m3u8']
				#and self.REQ_INFO['last_type'].lower() in ['m3u8']
				and self.REQ_INFO.get('addon').get('addon') == 'tvingm'
			):

				# requests URL
				try:
					#response = requests.get( url=self.REQ_INFO['url'], headers=self.Make_Header(), stream=True )
					#headers = { 'content-type' : 'application/vnd.apple.mpegurl' }
					response = requests.get( url=self.REQ_INFO['url'], headers=None, stream=True )
				except Exception as exception:
					print(exception)
					Addon_Log( 'do_get reuests call error') #####
					self.Send_ErrorPage()
					return

				#print(  'aaaaaaaaaaaaaaaaaaaaaaaaa' )
				print( self.REQ_INFO['url'] )
				#print( response.text )
				#m3u8     = response.content.decode('utf-8')
				m3u8     = response.text
				res_data = None
				#res_data = m3u8
				#response.headers['content-type'] = 'application/vnd.apple.mpegurl' #####


				if os.path.isfile( self.REQ_INFO['addon']['playOption']['streamFilename'] ):
					Addon_Log( 'do_get : m3u8   os.isfile') #####

					if '#EXTM3U' in m3u8 and '#EXT-X-STREAM-INF' in m3u8 :
						Addon_Log( 'do_get : if m3u8  EXT-X-STREAM-INF') #####
						try:
							fp = open(self.REQ_INFO['addon']['playOption']['streamFilename'], 'r', -1, 'utf-8')
							res_data = fp.read()
							fp.close()
							#Addon_Log( 'do_get : file read end') #####
						except:
							None
					#response.headers['content-type'] = 'application/vnd.apple.mpegurl' #####
					self.Output_Response( response, res_data, header_exceptList=[], binType=False )
				else:
					self.Output_Response( response, res_data, header_exceptList=[], binType=True )

		
			else:
				res_data = None
				
				# requests URL
				try:
					response = requests.get( url=self.REQ_INFO['url'], headers=self.Make_Header(), stream=True )
				except Exception as exception:
					print(exception)
					Addon_Log( 'do_get reuests call error') #####
					self.Send_ErrorPage()
					return
				
				#Addon_Log(  'do_get( else) : ' + response.headers['content-type'] )
				if  (      response.headers['content-type'].lower() in ['video/mp2t', 'binary/octet-stream']
					or 'octet-stream' in response.headers['content-type'].lower()
					or 'binary'       in response.headers['content-type'].lower()
					or 'video'        in response.headers['content-type'].lower()
				):
					#Addon_Log(  'do_get : bintype=True' )
					res_data = response.content
					binType = True
				else:
					#Addon_Log(  'do_get : bintype=False' )
					try:
						res_data = response.content.decode('utf-8')
						binType = False
						#Addon_Log(  'do_get : try' )
					except:
						res_data = response.content
						binType = True
						#Addon_Log(  'do_get : except' )
				self.Output_Response( response, res_data, header_exceptList=[], binType=binType )

		except Exception as exception:
			#print( self.REQ_INFO )
			#print( self.REQ_INFO.get('addon') )
			print(exception)
			return


	def Tving_Parse_subtitle( self, subtitle ):
		split_list    = subtitle.split(b'\n')
		return_array = b''
		pByte = b''
		pTag = False

		for i_line in split_list:
			try:
				decode_str = i_line.decode()
				strYn = True
			except:
				strYn = False

			if pTag == False and return_array != b'':
				return_array += b'\n'

			if strYn == False:
				return_array += i_line
				pTag = False
			
			elif decode_str.strip().startswith( '<p begin=' ) == True and decode_str.strip().endswith( '</p>' ) == True:
				return_array += i_line
				pTag = False

			elif decode_str.strip().startswith( '<p begin=' ) == True:
				pByte = i_line
				pTag = True

			elif decode_str.strip().endswith( '</p>' ) == True:
				pByte += b' ' + i_line
				pTag = False
				return_array += pByte

			elif pTag == True:
				pByte += + b'  ' + i_line

			else:
				return_array += i_line
				pByte = ''

		return return_array


	def indent( self, elem, level=0 ):
		i = "\n" + level*"  "
		if len(elem):
			if not elem.text or not elem.text.strip():
				elem.text = i + "  "
			if not elem.tail or not elem.tail.strip():
				elem.tail = i
			for elem in elem:
				self.indent(elem, level+1)
			if not elem.tail or not elem.tail.strip():
				elem.tail = i
		else:
			if level and (not elem.tail or not elem.tail.strip()):
				elem.tail = i


	def _gzip(self, data=None):
		from io import BytesIO
		from gzip import GzipFile
		out = BytesIO()
		f = GzipFile(fileobj=out, mode='w', compresslevel=5)
		f.write(data)
		f.close()
		return out.getvalue()



class TvingProxy(object):
	def __init__( self ):
		self.started = False
		self.PORT = None

	def start(self):
		if self.started: return

		self._server = HTTPServer( ('0.0.0.0', self.PORT), BoriProxyHandler )
		self._httpd_thread = threading.Thread(target=self._server.serve_forever)
		self._httpd_thread.start()
		self.started = True

	def stop(self):
		if not self.started: return

		self._server.shutdown()
		self._server.server_close()
		self._server.socket.close()
		self._httpd_thread.join()
		self.started = False



if __name__ == "__main__":
	TEST_PORT = 9999
	httpd = HTTPServer( ('0.0.0.0', TEST_PORT), BoriProxyHandler )
	print(f'Server running on port : {TEST_PORT}')
	httpd.serve_forever()
