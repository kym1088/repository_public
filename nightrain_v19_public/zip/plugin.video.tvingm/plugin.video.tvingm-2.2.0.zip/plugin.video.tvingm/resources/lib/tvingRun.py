__author__="NightRain"
zVwTBuLOpixkboadrCnWPjgMIAeSsF=object
zVwTBuLOpixkboadrCnWPjgMIAeSsN=None
zVwTBuLOpixkboadrCnWPjgMIAeSsy=int
zVwTBuLOpixkboadrCnWPjgMIAeSsq=False
zVwTBuLOpixkboadrCnWPjgMIAeSsJ=True
zVwTBuLOpixkboadrCnWPjgMIAeSsf=len
zVwTBuLOpixkboadrCnWPjgMIAeSsh=str
zVwTBuLOpixkboadrCnWPjgMIAeSsD=open
zVwTBuLOpixkboadrCnWPjgMIAeSsU=dict
zVwTBuLOpixkboadrCnWPjgMIAeSsE=Exception
zVwTBuLOpixkboadrCnWPjgMIAeSsv=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
zVwTBuLOpixkboadrCnWPjgMIAeSHt=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
zVwTBuLOpixkboadrCnWPjgMIAeSHF=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
zVwTBuLOpixkboadrCnWPjgMIAeSHN=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
zVwTBuLOpixkboadrCnWPjgMIAeSHs=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
zVwTBuLOpixkboadrCnWPjgMIAeSHy=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'PROGRAM','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
zVwTBuLOpixkboadrCnWPjgMIAeSHq=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
zVwTBuLOpixkboadrCnWPjgMIAeSHJ={'C00551':'tvN','C00544':'중화TV','C00575':'Olive','C00579':'Mnet','C00590':'OGN','C01141':'XtvN','C01142':'ONSTYLE','C01143':'OtvN','C04601':'OCN Movies','C06941':'tooniverse','C07381':'OCN','C07382':'OCN Thrills','C15251':'OGN x LOL','C15252':'OGN x 오버워치','C15042':'티빙라이브','C01581':'TV CHOSUN','C01583':'채널A','C00708':'MBN','C00593':'YTN','C01101':'YTN Life','C15347':'YTN science','C01723':'연합뉴스TV','C15152':'CH.DIA','C01582':'JTBC','C00588':'JTBC Golf','C15741':'JTBC2','C00805':'JTBC3 FOX Sports','C05661':'디즈니채널','C18641':'IHQ','C22041':'JTBC4','C23343':'t.cast','C23441':'E channel','C17341':'히스토리','C00585':'TV CHOSUN2','C17141':'채널A 플러스','C00611':'LIFETIME','C08041':'tvN go','C05901':'채널W','C23442':"D'LIVE",'C27441':'KBS N','C15846':'SBS CNBC','C43241':'Nickelodeon','C43242':'SBS MTV','C43341':'SBS FiL','C43342':'KPOP','C17142':'MBN+'}
zVwTBuLOpixkboadrCnWPjgMIAeSHf=xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class zVwTBuLOpixkboadrCnWPjgMIAeSHY(zVwTBuLOpixkboadrCnWPjgMIAeSsF):
 def __init__(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeSHD,zVwTBuLOpixkboadrCnWPjgMIAeSHU,zVwTBuLOpixkboadrCnWPjgMIAeSHE):
  zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_url =zVwTBuLOpixkboadrCnWPjgMIAeSHD
  zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_handle=zVwTBuLOpixkboadrCnWPjgMIAeSHU
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.main_params =zVwTBuLOpixkboadrCnWPjgMIAeSHE
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj =gHEMoONKPymCbRdrlGxupVWUqanJSI() 
 def addon_noti(zVwTBuLOpixkboadrCnWPjgMIAeSHh,sting):
  try:
   zVwTBuLOpixkboadrCnWPjgMIAeSHl=xbmcgui.Dialog()
   zVwTBuLOpixkboadrCnWPjgMIAeSHl.notification(__addonname__,sting)
  except:
   zVwTBuLOpixkboadrCnWPjgMIAeSsN
 def addon_log(zVwTBuLOpixkboadrCnWPjgMIAeSHh,string):
  try:
   zVwTBuLOpixkboadrCnWPjgMIAeSHc=string.encode('utf-8','ignore')
  except:
   zVwTBuLOpixkboadrCnWPjgMIAeSHc='addonException: addon_log'
  zVwTBuLOpixkboadrCnWPjgMIAeSHm=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,zVwTBuLOpixkboadrCnWPjgMIAeSHc),level=zVwTBuLOpixkboadrCnWPjgMIAeSHm)
 def get_keyboard_input(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeSYq):
  zVwTBuLOpixkboadrCnWPjgMIAeSHX=zVwTBuLOpixkboadrCnWPjgMIAeSsN
  kb=xbmc.Keyboard()
  kb.setHeading(zVwTBuLOpixkboadrCnWPjgMIAeSYq)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   zVwTBuLOpixkboadrCnWPjgMIAeSHX=kb.getText()
  return zVwTBuLOpixkboadrCnWPjgMIAeSHX
 def get_settings_login_info(zVwTBuLOpixkboadrCnWPjgMIAeSHh):
  zVwTBuLOpixkboadrCnWPjgMIAeSHG =__addon__.getSetting('id')
  zVwTBuLOpixkboadrCnWPjgMIAeSHQ =__addon__.getSetting('pw')
  zVwTBuLOpixkboadrCnWPjgMIAeSHK =__addon__.getSetting('login_type')
  zVwTBuLOpixkboadrCnWPjgMIAeSHR=zVwTBuLOpixkboadrCnWPjgMIAeSsy(__addon__.getSetting('selected_profile'))
  return(zVwTBuLOpixkboadrCnWPjgMIAeSHG,zVwTBuLOpixkboadrCnWPjgMIAeSHQ,zVwTBuLOpixkboadrCnWPjgMIAeSHK,zVwTBuLOpixkboadrCnWPjgMIAeSHR)
 def get_settings_premiumyn(zVwTBuLOpixkboadrCnWPjgMIAeSHh):
  zVwTBuLOpixkboadrCnWPjgMIAeSYH =__addon__.getSetting('premium_movieyn')
  if zVwTBuLOpixkboadrCnWPjgMIAeSYH=='false':
   return zVwTBuLOpixkboadrCnWPjgMIAeSsq
  else:
   return zVwTBuLOpixkboadrCnWPjgMIAeSsJ
 def get_settings_direct_replay(zVwTBuLOpixkboadrCnWPjgMIAeSHh):
  zVwTBuLOpixkboadrCnWPjgMIAeSYt=zVwTBuLOpixkboadrCnWPjgMIAeSsy(__addon__.getSetting('direct_replay'))
  if zVwTBuLOpixkboadrCnWPjgMIAeSYt==0:
   return zVwTBuLOpixkboadrCnWPjgMIAeSsq
  else:
   return zVwTBuLOpixkboadrCnWPjgMIAeSsJ
 def get_settings_thumbnail_landyn(zVwTBuLOpixkboadrCnWPjgMIAeSHh):
  zVwTBuLOpixkboadrCnWPjgMIAeSYF =zVwTBuLOpixkboadrCnWPjgMIAeSsy(__addon__.getSetting('thumbnail_way'))
  if zVwTBuLOpixkboadrCnWPjgMIAeSYF==0:
   return zVwTBuLOpixkboadrCnWPjgMIAeSsJ
  else:
   return zVwTBuLOpixkboadrCnWPjgMIAeSsq
 def set_winCredential(zVwTBuLOpixkboadrCnWPjgMIAeSHh,credential):
  zVwTBuLOpixkboadrCnWPjgMIAeSYN=xbmcgui.Window(10000)
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_LOGINTIME',zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(zVwTBuLOpixkboadrCnWPjgMIAeSHh):
  zVwTBuLOpixkboadrCnWPjgMIAeSYN=xbmcgui.Window(10000)
  zVwTBuLOpixkboadrCnWPjgMIAeSYs={'tving_token':zVwTBuLOpixkboadrCnWPjgMIAeSYN.getProperty('TVING_M_TOKEN'),'poc_userinfo':zVwTBuLOpixkboadrCnWPjgMIAeSYN.getProperty('TVING_M_USERINFO'),'tving_uuid':zVwTBuLOpixkboadrCnWPjgMIAeSYN.getProperty('TVING_M_UUID'),'tving_maintoken':zVwTBuLOpixkboadrCnWPjgMIAeSYN.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':zVwTBuLOpixkboadrCnWPjgMIAeSYN.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':zVwTBuLOpixkboadrCnWPjgMIAeSYN.getProperty('TVING_M_LOCKKEY')}
  return zVwTBuLOpixkboadrCnWPjgMIAeSYs
 def set_winEpisodeOrderby(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeStc):
  zVwTBuLOpixkboadrCnWPjgMIAeSYN=xbmcgui.Window(10000)
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_ORDERBY',zVwTBuLOpixkboadrCnWPjgMIAeStc)
 def get_winEpisodeOrderby(zVwTBuLOpixkboadrCnWPjgMIAeSHh):
  zVwTBuLOpixkboadrCnWPjgMIAeSYN=xbmcgui.Window(10000)
  return zVwTBuLOpixkboadrCnWPjgMIAeSYN.getProperty('TVING_M_ORDERBY')
 def add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSHh,label,sublabel='',img='',infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeSsN,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsJ,params=''):
  zVwTBuLOpixkboadrCnWPjgMIAeSYy='%s?%s'%(zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_url,urllib.parse.urlencode(params))
  if sublabel:zVwTBuLOpixkboadrCnWPjgMIAeSYq='%s < %s >'%(label,sublabel)
  else: zVwTBuLOpixkboadrCnWPjgMIAeSYq=label
  if not img:img='DefaultFolder.png'
  zVwTBuLOpixkboadrCnWPjgMIAeSYJ=xbmcgui.ListItem(zVwTBuLOpixkboadrCnWPjgMIAeSYq)
  zVwTBuLOpixkboadrCnWPjgMIAeSYJ.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:zVwTBuLOpixkboadrCnWPjgMIAeSYJ.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:zVwTBuLOpixkboadrCnWPjgMIAeSYJ.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_handle,zVwTBuLOpixkboadrCnWPjgMIAeSYy,zVwTBuLOpixkboadrCnWPjgMIAeSYJ,isFolder)
 def get_selQuality(zVwTBuLOpixkboadrCnWPjgMIAeSHh,etype):
  try:
   zVwTBuLOpixkboadrCnWPjgMIAeSYf='selected_quality'
   zVwTBuLOpixkboadrCnWPjgMIAeSYh=[1080,720,480,360]
   zVwTBuLOpixkboadrCnWPjgMIAeSYD=zVwTBuLOpixkboadrCnWPjgMIAeSsy(__addon__.getSetting(zVwTBuLOpixkboadrCnWPjgMIAeSYf))
   return zVwTBuLOpixkboadrCnWPjgMIAeSYh[zVwTBuLOpixkboadrCnWPjgMIAeSYD]
  except:
   zVwTBuLOpixkboadrCnWPjgMIAeSsN
  return 720 
 def dp_Main_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh):
  for zVwTBuLOpixkboadrCnWPjgMIAeSYU in zVwTBuLOpixkboadrCnWPjgMIAeSHt:
   zVwTBuLOpixkboadrCnWPjgMIAeSYq=zVwTBuLOpixkboadrCnWPjgMIAeSYU.get('title')
   zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':zVwTBuLOpixkboadrCnWPjgMIAeSYU.get('mode'),'stype':zVwTBuLOpixkboadrCnWPjgMIAeSYU.get('stype'),'orderby':zVwTBuLOpixkboadrCnWPjgMIAeSYU.get('orderby'),'ordernm':zVwTBuLOpixkboadrCnWPjgMIAeSYU.get('ordernm'),'page':'1'}
   if zVwTBuLOpixkboadrCnWPjgMIAeSYU.get('mode')=='XXX':
    zVwTBuLOpixkboadrCnWPjgMIAeSYE['mode']='XXX'
    zVwTBuLOpixkboadrCnWPjgMIAeSYv=zVwTBuLOpixkboadrCnWPjgMIAeSsq
   else:
    zVwTBuLOpixkboadrCnWPjgMIAeSYv=zVwTBuLOpixkboadrCnWPjgMIAeSsJ
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel='',img='',infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeSsN,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSYv,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeSsf(zVwTBuLOpixkboadrCnWPjgMIAeSHt)>0:xbmcplugin.endOfDirectory(zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_handle)
 def login_main(zVwTBuLOpixkboadrCnWPjgMIAeSHh):
  (zVwTBuLOpixkboadrCnWPjgMIAeSYc,zVwTBuLOpixkboadrCnWPjgMIAeSYm,zVwTBuLOpixkboadrCnWPjgMIAeSYX,zVwTBuLOpixkboadrCnWPjgMIAeSYG)=zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_settings_login_info()
  if not(zVwTBuLOpixkboadrCnWPjgMIAeSYc and zVwTBuLOpixkboadrCnWPjgMIAeSYm):
   zVwTBuLOpixkboadrCnWPjgMIAeSHl=xbmcgui.Dialog()
   zVwTBuLOpixkboadrCnWPjgMIAeSYQ=zVwTBuLOpixkboadrCnWPjgMIAeSHl.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if zVwTBuLOpixkboadrCnWPjgMIAeSYQ==zVwTBuLOpixkboadrCnWPjgMIAeSsJ:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_winEpisodeOrderby()=='':
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.set_winEpisodeOrderby('desc')
  if zVwTBuLOpixkboadrCnWPjgMIAeSHh.cookiefile_check():return
  zVwTBuLOpixkboadrCnWPjgMIAeSYK =zVwTBuLOpixkboadrCnWPjgMIAeSsy(zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  zVwTBuLOpixkboadrCnWPjgMIAeSYR=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if zVwTBuLOpixkboadrCnWPjgMIAeSYR==zVwTBuLOpixkboadrCnWPjgMIAeSsN or zVwTBuLOpixkboadrCnWPjgMIAeSYR=='':
   zVwTBuLOpixkboadrCnWPjgMIAeSYR=zVwTBuLOpixkboadrCnWPjgMIAeSsy('19000101')
  else:
   zVwTBuLOpixkboadrCnWPjgMIAeSYR=zVwTBuLOpixkboadrCnWPjgMIAeSsy(re.sub('-','',zVwTBuLOpixkboadrCnWPjgMIAeSYR))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   zVwTBuLOpixkboadrCnWPjgMIAeStH=0
   while zVwTBuLOpixkboadrCnWPjgMIAeSsJ:
    zVwTBuLOpixkboadrCnWPjgMIAeStH+=1
    time.sleep(0.05)
    if zVwTBuLOpixkboadrCnWPjgMIAeSYR>=zVwTBuLOpixkboadrCnWPjgMIAeSYK:return
    if zVwTBuLOpixkboadrCnWPjgMIAeStH>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if zVwTBuLOpixkboadrCnWPjgMIAeSYR>=zVwTBuLOpixkboadrCnWPjgMIAeSYK:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.GetCredential(zVwTBuLOpixkboadrCnWPjgMIAeSYc,zVwTBuLOpixkboadrCnWPjgMIAeSYm,zVwTBuLOpixkboadrCnWPjgMIAeSYX,zVwTBuLOpixkboadrCnWPjgMIAeSYG):
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.set_winCredential(zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.LoadCredential())
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeSts):
  zVwTBuLOpixkboadrCnWPjgMIAeStY=zVwTBuLOpixkboadrCnWPjgMIAeSts.get('stype')
  if zVwTBuLOpixkboadrCnWPjgMIAeStY=='live':
   zVwTBuLOpixkboadrCnWPjgMIAeStF=zVwTBuLOpixkboadrCnWPjgMIAeSHF
  elif zVwTBuLOpixkboadrCnWPjgMIAeStY=='vod':
   zVwTBuLOpixkboadrCnWPjgMIAeStF=zVwTBuLOpixkboadrCnWPjgMIAeSHy
  else:
   zVwTBuLOpixkboadrCnWPjgMIAeStF=zVwTBuLOpixkboadrCnWPjgMIAeSHq
  for zVwTBuLOpixkboadrCnWPjgMIAeStN in zVwTBuLOpixkboadrCnWPjgMIAeStF:
   zVwTBuLOpixkboadrCnWPjgMIAeSYq=zVwTBuLOpixkboadrCnWPjgMIAeStN.get('title')
   if zVwTBuLOpixkboadrCnWPjgMIAeSts.get('ordernm')!='-':
    zVwTBuLOpixkboadrCnWPjgMIAeSYq+='  ('+zVwTBuLOpixkboadrCnWPjgMIAeSts.get('ordernm')+')'
   zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':zVwTBuLOpixkboadrCnWPjgMIAeStN.get('mode'),'stype':zVwTBuLOpixkboadrCnWPjgMIAeStN.get('stype'),'orderby':zVwTBuLOpixkboadrCnWPjgMIAeSts.get('orderby'),'page':'1'}
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel='',img='',infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeSsN,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsJ,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeSsf(zVwTBuLOpixkboadrCnWPjgMIAeStF)>0:xbmcplugin.endOfDirectory(zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_handle)
 def dp_LiveChannel_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeSts):
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.SaveCredential(zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_winCredential())
  zVwTBuLOpixkboadrCnWPjgMIAeStY =zVwTBuLOpixkboadrCnWPjgMIAeSts.get('stype')
  zVwTBuLOpixkboadrCnWPjgMIAeSty =zVwTBuLOpixkboadrCnWPjgMIAeSsy(zVwTBuLOpixkboadrCnWPjgMIAeSts.get('page'))
  zVwTBuLOpixkboadrCnWPjgMIAeStq,zVwTBuLOpixkboadrCnWPjgMIAeStJ=zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.GetLiveChannelList(zVwTBuLOpixkboadrCnWPjgMIAeStY,zVwTBuLOpixkboadrCnWPjgMIAeSty)
  for zVwTBuLOpixkboadrCnWPjgMIAeStf in zVwTBuLOpixkboadrCnWPjgMIAeStq:
   zVwTBuLOpixkboadrCnWPjgMIAeSYq =zVwTBuLOpixkboadrCnWPjgMIAeStf.get('title')
   zVwTBuLOpixkboadrCnWPjgMIAeSYl =zVwTBuLOpixkboadrCnWPjgMIAeStf.get('channel')
   zVwTBuLOpixkboadrCnWPjgMIAeSth =zVwTBuLOpixkboadrCnWPjgMIAeStf.get('thumbnail')
   zVwTBuLOpixkboadrCnWPjgMIAeStD =zVwTBuLOpixkboadrCnWPjgMIAeStf.get('synopsis')
   zVwTBuLOpixkboadrCnWPjgMIAeStU=zVwTBuLOpixkboadrCnWPjgMIAeStf.get('channelepg')
   zVwTBuLOpixkboadrCnWPjgMIAeStE=zVwTBuLOpixkboadrCnWPjgMIAeStf.get('info')
   zVwTBuLOpixkboadrCnWPjgMIAeStE['plot']='%s\n%s\n%s\n\n%s'%(zVwTBuLOpixkboadrCnWPjgMIAeSYl,zVwTBuLOpixkboadrCnWPjgMIAeSYq,zVwTBuLOpixkboadrCnWPjgMIAeStU,zVwTBuLOpixkboadrCnWPjgMIAeStD)
   zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':'LIVE','mediacode':zVwTBuLOpixkboadrCnWPjgMIAeStf.get('mediacode'),'stype':zVwTBuLOpixkboadrCnWPjgMIAeStY}
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYl,sublabel=zVwTBuLOpixkboadrCnWPjgMIAeSYq,img=zVwTBuLOpixkboadrCnWPjgMIAeSth,infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeStE,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsq,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeStJ:
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['mode']='CHANNEL' 
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['stype']=zVwTBuLOpixkboadrCnWPjgMIAeStY 
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['page']=zVwTBuLOpixkboadrCnWPjgMIAeSsh(zVwTBuLOpixkboadrCnWPjgMIAeSty+1)
   zVwTBuLOpixkboadrCnWPjgMIAeSYq='[B]%s >>[/B]'%'다음 페이지'
   zVwTBuLOpixkboadrCnWPjgMIAeStv=zVwTBuLOpixkboadrCnWPjgMIAeSsh(zVwTBuLOpixkboadrCnWPjgMIAeSty+1)
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel=zVwTBuLOpixkboadrCnWPjgMIAeStv,img='',infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeSsN,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsJ,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeSsf(zVwTBuLOpixkboadrCnWPjgMIAeStq)>0:xbmcplugin.endOfDirectory(zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_handle,cacheToDisc=zVwTBuLOpixkboadrCnWPjgMIAeSsq)
 def dp_Program_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeSts):
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.SaveCredential(zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_winCredential())
  zVwTBuLOpixkboadrCnWPjgMIAeStl =zVwTBuLOpixkboadrCnWPjgMIAeSts.get('stype')
  zVwTBuLOpixkboadrCnWPjgMIAeStc =zVwTBuLOpixkboadrCnWPjgMIAeSts.get('orderby')
  zVwTBuLOpixkboadrCnWPjgMIAeSty =zVwTBuLOpixkboadrCnWPjgMIAeSsy(zVwTBuLOpixkboadrCnWPjgMIAeSts.get('page'))
  zVwTBuLOpixkboadrCnWPjgMIAeStm,zVwTBuLOpixkboadrCnWPjgMIAeStJ=zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.GetProgramList(zVwTBuLOpixkboadrCnWPjgMIAeStl,zVwTBuLOpixkboadrCnWPjgMIAeStc,zVwTBuLOpixkboadrCnWPjgMIAeSty,landyn=zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_settings_thumbnail_landyn())
  for zVwTBuLOpixkboadrCnWPjgMIAeStX in zVwTBuLOpixkboadrCnWPjgMIAeStm:
   zVwTBuLOpixkboadrCnWPjgMIAeSYq =zVwTBuLOpixkboadrCnWPjgMIAeStX.get('title')
   zVwTBuLOpixkboadrCnWPjgMIAeSth=zVwTBuLOpixkboadrCnWPjgMIAeStX.get('thumbnail')
   zVwTBuLOpixkboadrCnWPjgMIAeStD =zVwTBuLOpixkboadrCnWPjgMIAeStX.get('synopsis')
   zVwTBuLOpixkboadrCnWPjgMIAeStG =zVwTBuLOpixkboadrCnWPjgMIAeSHJ.get(zVwTBuLOpixkboadrCnWPjgMIAeStX.get('channel'))
   zVwTBuLOpixkboadrCnWPjgMIAeStE=zVwTBuLOpixkboadrCnWPjgMIAeStX.get('info')
   zVwTBuLOpixkboadrCnWPjgMIAeStE['studio']=zVwTBuLOpixkboadrCnWPjgMIAeStG
   zVwTBuLOpixkboadrCnWPjgMIAeStE['plot']='%s <%s>\n\n%s'%(zVwTBuLOpixkboadrCnWPjgMIAeSYq,zVwTBuLOpixkboadrCnWPjgMIAeStG,zVwTBuLOpixkboadrCnWPjgMIAeStD)
   zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':'EPISODE','programcode':zVwTBuLOpixkboadrCnWPjgMIAeStX.get('program'),'page':'1'}
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel=zVwTBuLOpixkboadrCnWPjgMIAeStG,img=zVwTBuLOpixkboadrCnWPjgMIAeSth,infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeStE,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsJ,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeStJ:
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['mode'] ='PROGRAM' 
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['stype'] =zVwTBuLOpixkboadrCnWPjgMIAeStl
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['orderby']=zVwTBuLOpixkboadrCnWPjgMIAeStc
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['page'] =zVwTBuLOpixkboadrCnWPjgMIAeSsh(zVwTBuLOpixkboadrCnWPjgMIAeSty+1)
   zVwTBuLOpixkboadrCnWPjgMIAeSYq='[B]%s >>[/B]'%'다음 페이지'
   zVwTBuLOpixkboadrCnWPjgMIAeStv=zVwTBuLOpixkboadrCnWPjgMIAeSsh(zVwTBuLOpixkboadrCnWPjgMIAeSty+1)
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel=zVwTBuLOpixkboadrCnWPjgMIAeStv,img='',infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeSsN,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsJ,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeSsf(zVwTBuLOpixkboadrCnWPjgMIAeStm)>0:xbmcplugin.endOfDirectory(zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_handle,cacheToDisc=zVwTBuLOpixkboadrCnWPjgMIAeSsq)
 def dp_Episode_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeSts):
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.SaveCredential(zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_winCredential())
  zVwTBuLOpixkboadrCnWPjgMIAeStQ=zVwTBuLOpixkboadrCnWPjgMIAeSts.get('programcode')
  zVwTBuLOpixkboadrCnWPjgMIAeSty =zVwTBuLOpixkboadrCnWPjgMIAeSsy(zVwTBuLOpixkboadrCnWPjgMIAeSts.get('page'))
  zVwTBuLOpixkboadrCnWPjgMIAeStK,zVwTBuLOpixkboadrCnWPjgMIAeStJ,zVwTBuLOpixkboadrCnWPjgMIAeStR=zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.GetEpisodoList(zVwTBuLOpixkboadrCnWPjgMIAeStQ,zVwTBuLOpixkboadrCnWPjgMIAeSty,orderby=zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_winEpisodeOrderby())
  for zVwTBuLOpixkboadrCnWPjgMIAeSFH in zVwTBuLOpixkboadrCnWPjgMIAeStK:
   zVwTBuLOpixkboadrCnWPjgMIAeSYq =zVwTBuLOpixkboadrCnWPjgMIAeSFH.get('title')
   zVwTBuLOpixkboadrCnWPjgMIAeStv =zVwTBuLOpixkboadrCnWPjgMIAeSFH.get('subtitle')
   zVwTBuLOpixkboadrCnWPjgMIAeSth=zVwTBuLOpixkboadrCnWPjgMIAeSFH.get('thumbnail')
   zVwTBuLOpixkboadrCnWPjgMIAeStD =zVwTBuLOpixkboadrCnWPjgMIAeSFH.get('synopsis')
   zVwTBuLOpixkboadrCnWPjgMIAeStE=zVwTBuLOpixkboadrCnWPjgMIAeSFH.get('info')
   zVwTBuLOpixkboadrCnWPjgMIAeStE['plot']='%s\n\n%s'%(zVwTBuLOpixkboadrCnWPjgMIAeSYq,zVwTBuLOpixkboadrCnWPjgMIAeStD)
   zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':'VOD','mediacode':zVwTBuLOpixkboadrCnWPjgMIAeSFH.get('episode'),'stype':'vod','programcode':zVwTBuLOpixkboadrCnWPjgMIAeStQ,'title':zVwTBuLOpixkboadrCnWPjgMIAeSYq,'thumbnail':zVwTBuLOpixkboadrCnWPjgMIAeSth}
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel=zVwTBuLOpixkboadrCnWPjgMIAeStv,img=zVwTBuLOpixkboadrCnWPjgMIAeSth,infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeStE,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsq,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeSty==1:
   zVwTBuLOpixkboadrCnWPjgMIAeStE={'plot':'정렬순서를 변경합니다.'}
   zVwTBuLOpixkboadrCnWPjgMIAeSYE={}
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['mode'] ='ORDER_BY' 
   if zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_winEpisodeOrderby()=='desc':
    zVwTBuLOpixkboadrCnWPjgMIAeSYq='정렬순서변경 : 최신화부터 -> 1회부터'
    zVwTBuLOpixkboadrCnWPjgMIAeSYE['orderby']='asc'
   else:
    zVwTBuLOpixkboadrCnWPjgMIAeSYq='정렬순서변경 : 1회부터 -> 최신화부터'
    zVwTBuLOpixkboadrCnWPjgMIAeSYE['orderby']='desc'
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel='',img='',infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeStE,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsq,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeStJ:
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['mode'] ='EPISODE' 
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['programcode']=zVwTBuLOpixkboadrCnWPjgMIAeStQ
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['page'] =zVwTBuLOpixkboadrCnWPjgMIAeSsh(zVwTBuLOpixkboadrCnWPjgMIAeSty+1)
   zVwTBuLOpixkboadrCnWPjgMIAeSYq='[B]%s >>[/B]'%'다음 페이지'
   zVwTBuLOpixkboadrCnWPjgMIAeStv=zVwTBuLOpixkboadrCnWPjgMIAeSsh(zVwTBuLOpixkboadrCnWPjgMIAeSty+1)
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel=zVwTBuLOpixkboadrCnWPjgMIAeStv,img='',infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeSsN,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsJ,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeSsf(zVwTBuLOpixkboadrCnWPjgMIAeStK)>0:xbmcplugin.endOfDirectory(zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_handle,cacheToDisc=zVwTBuLOpixkboadrCnWPjgMIAeSsJ)
 def dp_setEpOrderby(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeSts):
  zVwTBuLOpixkboadrCnWPjgMIAeStc =zVwTBuLOpixkboadrCnWPjgMIAeSts.get('orderby')
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.set_winEpisodeOrderby(zVwTBuLOpixkboadrCnWPjgMIAeStc)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeSts):
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.SaveCredential(zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_winCredential())
  zVwTBuLOpixkboadrCnWPjgMIAeStl =zVwTBuLOpixkboadrCnWPjgMIAeSts.get('stype')
  zVwTBuLOpixkboadrCnWPjgMIAeStc =zVwTBuLOpixkboadrCnWPjgMIAeSts.get('orderby')
  zVwTBuLOpixkboadrCnWPjgMIAeSty=zVwTBuLOpixkboadrCnWPjgMIAeSsy(zVwTBuLOpixkboadrCnWPjgMIAeSts.get('page'))
  zVwTBuLOpixkboadrCnWPjgMIAeSFY,zVwTBuLOpixkboadrCnWPjgMIAeStJ=zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.GetMovieList(zVwTBuLOpixkboadrCnWPjgMIAeStl,zVwTBuLOpixkboadrCnWPjgMIAeStc,zVwTBuLOpixkboadrCnWPjgMIAeSty,landyn=zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_settings_thumbnail_landyn())
  for zVwTBuLOpixkboadrCnWPjgMIAeSFt in zVwTBuLOpixkboadrCnWPjgMIAeSFY:
   zVwTBuLOpixkboadrCnWPjgMIAeSYq =zVwTBuLOpixkboadrCnWPjgMIAeSFt.get('title')
   zVwTBuLOpixkboadrCnWPjgMIAeSth=zVwTBuLOpixkboadrCnWPjgMIAeSFt.get('thumbnail')
   zVwTBuLOpixkboadrCnWPjgMIAeStD =zVwTBuLOpixkboadrCnWPjgMIAeSFt.get('synopsis')
   zVwTBuLOpixkboadrCnWPjgMIAeStE=zVwTBuLOpixkboadrCnWPjgMIAeSFt.get('info')
   zVwTBuLOpixkboadrCnWPjgMIAeStE['plot']='%s\n\n%s'%(zVwTBuLOpixkboadrCnWPjgMIAeSYq,zVwTBuLOpixkboadrCnWPjgMIAeStD)
   zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':'MOVIE','mediacode':zVwTBuLOpixkboadrCnWPjgMIAeSFt.get('moviecode'),'stype':'movie','title':zVwTBuLOpixkboadrCnWPjgMIAeSYq,'thumbnail':zVwTBuLOpixkboadrCnWPjgMIAeSth}
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel='',img=zVwTBuLOpixkboadrCnWPjgMIAeSth,infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeStE,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsq,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeStJ:
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['mode'] ='MOVIE_GROUP' 
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['orderby']=zVwTBuLOpixkboadrCnWPjgMIAeStc
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['page'] =zVwTBuLOpixkboadrCnWPjgMIAeSsh(zVwTBuLOpixkboadrCnWPjgMIAeSty+1)
   zVwTBuLOpixkboadrCnWPjgMIAeSYq='[B]%s >>[/B]'%'다음 페이지'
   zVwTBuLOpixkboadrCnWPjgMIAeStv=zVwTBuLOpixkboadrCnWPjgMIAeSsh(zVwTBuLOpixkboadrCnWPjgMIAeSty+1)
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel=zVwTBuLOpixkboadrCnWPjgMIAeStv,img='',infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeSsN,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsJ,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeSsf(zVwTBuLOpixkboadrCnWPjgMIAeSFY)>0:xbmcplugin.endOfDirectory(zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_handle,cacheToDisc=zVwTBuLOpixkboadrCnWPjgMIAeSsq)
 def dp_Search_Group(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeSts):
  for zVwTBuLOpixkboadrCnWPjgMIAeStN in zVwTBuLOpixkboadrCnWPjgMIAeSHs:
   zVwTBuLOpixkboadrCnWPjgMIAeSYq=zVwTBuLOpixkboadrCnWPjgMIAeStN.get('title')
   zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':zVwTBuLOpixkboadrCnWPjgMIAeStN.get('mode'),'stype':zVwTBuLOpixkboadrCnWPjgMIAeStN.get('stype'),'page':'1'}
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel='',img='',infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeSsN,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsJ,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeSsf(zVwTBuLOpixkboadrCnWPjgMIAeSHs)>0:xbmcplugin.endOfDirectory(zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_handle)
 def dp_Search_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeSts):
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.SaveCredential(zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_winCredential())
  zVwTBuLOpixkboadrCnWPjgMIAeSFN =__addon__.getSetting('id')
  zVwTBuLOpixkboadrCnWPjgMIAeSty =zVwTBuLOpixkboadrCnWPjgMIAeSsy(zVwTBuLOpixkboadrCnWPjgMIAeSts.get('page'))
  zVwTBuLOpixkboadrCnWPjgMIAeStY =zVwTBuLOpixkboadrCnWPjgMIAeSts.get('stype')
  if 'search_key' in zVwTBuLOpixkboadrCnWPjgMIAeSts:
   zVwTBuLOpixkboadrCnWPjgMIAeSFs=zVwTBuLOpixkboadrCnWPjgMIAeSts.get('search_key')
  else:
   zVwTBuLOpixkboadrCnWPjgMIAeSFs=zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not zVwTBuLOpixkboadrCnWPjgMIAeSFs:return
  zVwTBuLOpixkboadrCnWPjgMIAeSFy,zVwTBuLOpixkboadrCnWPjgMIAeStJ=zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.GetSearchList(zVwTBuLOpixkboadrCnWPjgMIAeSFs,zVwTBuLOpixkboadrCnWPjgMIAeSFN,zVwTBuLOpixkboadrCnWPjgMIAeSty,zVwTBuLOpixkboadrCnWPjgMIAeStY,landyn=zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_settings_thumbnail_landyn())
  if zVwTBuLOpixkboadrCnWPjgMIAeSsf(zVwTBuLOpixkboadrCnWPjgMIAeSFy)==0:return
  for zVwTBuLOpixkboadrCnWPjgMIAeSFq in zVwTBuLOpixkboadrCnWPjgMIAeSFy:
   zVwTBuLOpixkboadrCnWPjgMIAeSYq =zVwTBuLOpixkboadrCnWPjgMIAeSFq.get('title')
   zVwTBuLOpixkboadrCnWPjgMIAeSth=zVwTBuLOpixkboadrCnWPjgMIAeSFq.get('thumbnail')
   zVwTBuLOpixkboadrCnWPjgMIAeStD =zVwTBuLOpixkboadrCnWPjgMIAeSFq.get('synopsis')
   zVwTBuLOpixkboadrCnWPjgMIAeSFJ =zVwTBuLOpixkboadrCnWPjgMIAeSFq.get('program')
   zVwTBuLOpixkboadrCnWPjgMIAeStE=zVwTBuLOpixkboadrCnWPjgMIAeSFq.get('info')
   zVwTBuLOpixkboadrCnWPjgMIAeStE['plot']='%s\n\n%s'%(zVwTBuLOpixkboadrCnWPjgMIAeSYq,zVwTBuLOpixkboadrCnWPjgMIAeStD)
   if zVwTBuLOpixkboadrCnWPjgMIAeStY=='vod':
    zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':'EPISODE','programcode':zVwTBuLOpixkboadrCnWPjgMIAeSFq.get('program'),'page':'1'}
    zVwTBuLOpixkboadrCnWPjgMIAeSYv=zVwTBuLOpixkboadrCnWPjgMIAeSsJ
   else:
    zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':'MOVIE','mediacode':zVwTBuLOpixkboadrCnWPjgMIAeSFq.get('movie'),'stype':'movie','title':zVwTBuLOpixkboadrCnWPjgMIAeSYq,'thumbnail':zVwTBuLOpixkboadrCnWPjgMIAeSth}
    zVwTBuLOpixkboadrCnWPjgMIAeSYv=zVwTBuLOpixkboadrCnWPjgMIAeSsq
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel='',img=zVwTBuLOpixkboadrCnWPjgMIAeSth,infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeStE,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSYv,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeStJ:
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['mode'] ='SEARCH' 
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['search_key']=zVwTBuLOpixkboadrCnWPjgMIAeSFs
   zVwTBuLOpixkboadrCnWPjgMIAeSYE['page'] =zVwTBuLOpixkboadrCnWPjgMIAeSsh(zVwTBuLOpixkboadrCnWPjgMIAeSty+1)
   zVwTBuLOpixkboadrCnWPjgMIAeSYq='[B]%s >>[/B]'%'다음 페이지'
   zVwTBuLOpixkboadrCnWPjgMIAeStv=zVwTBuLOpixkboadrCnWPjgMIAeSsh(zVwTBuLOpixkboadrCnWPjgMIAeSty+1)
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel=zVwTBuLOpixkboadrCnWPjgMIAeStv,img='',infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeSsN,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsJ,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  if zVwTBuLOpixkboadrCnWPjgMIAeSsf(zVwTBuLOpixkboadrCnWPjgMIAeSFy)>0:xbmcplugin.endOfDirectory(zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_handle)
 def Delete_Watched_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeStY):
  try:
   zVwTBuLOpixkboadrCnWPjgMIAeSFf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%zVwTBuLOpixkboadrCnWPjgMIAeStY))
   fp=zVwTBuLOpixkboadrCnWPjgMIAeSsD(zVwTBuLOpixkboadrCnWPjgMIAeSFf,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   zVwTBuLOpixkboadrCnWPjgMIAeSsN
 def dp_WatchList_Delete(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeSts):
  zVwTBuLOpixkboadrCnWPjgMIAeStY=zVwTBuLOpixkboadrCnWPjgMIAeSts.get('stype')
  zVwTBuLOpixkboadrCnWPjgMIAeSHl=xbmcgui.Dialog()
  zVwTBuLOpixkboadrCnWPjgMIAeSYQ=zVwTBuLOpixkboadrCnWPjgMIAeSHl.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if zVwTBuLOpixkboadrCnWPjgMIAeSYQ==zVwTBuLOpixkboadrCnWPjgMIAeSsq:sys.exit()
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.Delete_Watched_List(zVwTBuLOpixkboadrCnWPjgMIAeStY)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeStY):
  try:
   zVwTBuLOpixkboadrCnWPjgMIAeSFf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%zVwTBuLOpixkboadrCnWPjgMIAeStY))
   fp=zVwTBuLOpixkboadrCnWPjgMIAeSsD(zVwTBuLOpixkboadrCnWPjgMIAeSFf,'r',-1,'utf-8')
   zVwTBuLOpixkboadrCnWPjgMIAeSFh=fp.readlines()
   fp.close()
  except:
   zVwTBuLOpixkboadrCnWPjgMIAeSFh=[]
  return zVwTBuLOpixkboadrCnWPjgMIAeSFh
 def Save_Watched_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeStY,zVwTBuLOpixkboadrCnWPjgMIAeSHE):
  try:
   zVwTBuLOpixkboadrCnWPjgMIAeSFf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%zVwTBuLOpixkboadrCnWPjgMIAeStY))
   zVwTBuLOpixkboadrCnWPjgMIAeSFD=zVwTBuLOpixkboadrCnWPjgMIAeSHh.Load_Watched_List(zVwTBuLOpixkboadrCnWPjgMIAeStY) 
   fp=zVwTBuLOpixkboadrCnWPjgMIAeSsD(zVwTBuLOpixkboadrCnWPjgMIAeSFf,'w',-1,'utf-8')
   zVwTBuLOpixkboadrCnWPjgMIAeSFU=urllib.parse.urlencode(zVwTBuLOpixkboadrCnWPjgMIAeSHE)
   zVwTBuLOpixkboadrCnWPjgMIAeSFU=zVwTBuLOpixkboadrCnWPjgMIAeSFU+'\n'
   fp.write(zVwTBuLOpixkboadrCnWPjgMIAeSFU)
   zVwTBuLOpixkboadrCnWPjgMIAeSFE=0
   for zVwTBuLOpixkboadrCnWPjgMIAeSFv in zVwTBuLOpixkboadrCnWPjgMIAeSFD:
    zVwTBuLOpixkboadrCnWPjgMIAeSFl=zVwTBuLOpixkboadrCnWPjgMIAeSsU(urllib.parse.parse_qsl(zVwTBuLOpixkboadrCnWPjgMIAeSFv))
    zVwTBuLOpixkboadrCnWPjgMIAeSFc=zVwTBuLOpixkboadrCnWPjgMIAeSHE.get('code').strip()
    zVwTBuLOpixkboadrCnWPjgMIAeSFm=zVwTBuLOpixkboadrCnWPjgMIAeSFl.get('code').strip()
    if zVwTBuLOpixkboadrCnWPjgMIAeStY=='vod' and zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_settings_direct_replay()==zVwTBuLOpixkboadrCnWPjgMIAeSsJ:
     zVwTBuLOpixkboadrCnWPjgMIAeSFc=zVwTBuLOpixkboadrCnWPjgMIAeSHE.get('videoid').strip()
     zVwTBuLOpixkboadrCnWPjgMIAeSFm=zVwTBuLOpixkboadrCnWPjgMIAeSFl.get('videoid').strip()if zVwTBuLOpixkboadrCnWPjgMIAeSFm!=zVwTBuLOpixkboadrCnWPjgMIAeSsN else '-'
    if zVwTBuLOpixkboadrCnWPjgMIAeSFc!=zVwTBuLOpixkboadrCnWPjgMIAeSFm:
     fp.write(zVwTBuLOpixkboadrCnWPjgMIAeSFv)
     zVwTBuLOpixkboadrCnWPjgMIAeSFE+=1
     if zVwTBuLOpixkboadrCnWPjgMIAeSFE>=50:break
   fp.close()
  except:
   zVwTBuLOpixkboadrCnWPjgMIAeSsN
 def dp_Watch_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeSts):
  zVwTBuLOpixkboadrCnWPjgMIAeStY =zVwTBuLOpixkboadrCnWPjgMIAeSts.get('stype')
  zVwTBuLOpixkboadrCnWPjgMIAeSYt=zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_settings_direct_replay()
  if zVwTBuLOpixkboadrCnWPjgMIAeStY=='-':
   for zVwTBuLOpixkboadrCnWPjgMIAeStN in zVwTBuLOpixkboadrCnWPjgMIAeSHN:
    zVwTBuLOpixkboadrCnWPjgMIAeSYq=zVwTBuLOpixkboadrCnWPjgMIAeStN.get('title')
    zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':zVwTBuLOpixkboadrCnWPjgMIAeStN.get('mode'),'stype':zVwTBuLOpixkboadrCnWPjgMIAeStN.get('stype')}
    zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel='',img='',infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeSsN,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsJ,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
   if zVwTBuLOpixkboadrCnWPjgMIAeSsf(zVwTBuLOpixkboadrCnWPjgMIAeSHN)>0:xbmcplugin.endOfDirectory(zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_handle)
  else:
   zVwTBuLOpixkboadrCnWPjgMIAeSFX=zVwTBuLOpixkboadrCnWPjgMIAeSHh.Load_Watched_List(zVwTBuLOpixkboadrCnWPjgMIAeStY)
   for zVwTBuLOpixkboadrCnWPjgMIAeSFG in zVwTBuLOpixkboadrCnWPjgMIAeSFX:
    zVwTBuLOpixkboadrCnWPjgMIAeSFQ=zVwTBuLOpixkboadrCnWPjgMIAeSsU(urllib.parse.parse_qsl(zVwTBuLOpixkboadrCnWPjgMIAeSFG))
    zVwTBuLOpixkboadrCnWPjgMIAeSFK =zVwTBuLOpixkboadrCnWPjgMIAeSFQ.get('code').strip()
    zVwTBuLOpixkboadrCnWPjgMIAeSYq =zVwTBuLOpixkboadrCnWPjgMIAeSFQ.get('title').strip()
    zVwTBuLOpixkboadrCnWPjgMIAeSth=zVwTBuLOpixkboadrCnWPjgMIAeSFQ.get('img').strip()
    zVwTBuLOpixkboadrCnWPjgMIAeSFR =zVwTBuLOpixkboadrCnWPjgMIAeSFQ.get('videoid').strip()
    zVwTBuLOpixkboadrCnWPjgMIAeStE={}
    zVwTBuLOpixkboadrCnWPjgMIAeStE['plot']=zVwTBuLOpixkboadrCnWPjgMIAeSYq
    if zVwTBuLOpixkboadrCnWPjgMIAeStY=='vod':
     if zVwTBuLOpixkboadrCnWPjgMIAeSYt==zVwTBuLOpixkboadrCnWPjgMIAeSsq or zVwTBuLOpixkboadrCnWPjgMIAeSFR==zVwTBuLOpixkboadrCnWPjgMIAeSsN:
      zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':'EPISODE','programcode':zVwTBuLOpixkboadrCnWPjgMIAeSFK,'page':'1'}
      zVwTBuLOpixkboadrCnWPjgMIAeSYv=zVwTBuLOpixkboadrCnWPjgMIAeSsJ
     else:
      zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':'VOD','mediacode':zVwTBuLOpixkboadrCnWPjgMIAeSFR,'stype':'vod','programcode':zVwTBuLOpixkboadrCnWPjgMIAeSFK,'title':zVwTBuLOpixkboadrCnWPjgMIAeSYq,'thumbnail':zVwTBuLOpixkboadrCnWPjgMIAeSth}
      zVwTBuLOpixkboadrCnWPjgMIAeSYv=zVwTBuLOpixkboadrCnWPjgMIAeSsq
    else:
     zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':'MOVIE','mediacode':zVwTBuLOpixkboadrCnWPjgMIAeSFK,'stype':'movie','title':zVwTBuLOpixkboadrCnWPjgMIAeSYq,'thumbnail':zVwTBuLOpixkboadrCnWPjgMIAeSth}
     zVwTBuLOpixkboadrCnWPjgMIAeSYv=zVwTBuLOpixkboadrCnWPjgMIAeSsq
    zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel='',img=zVwTBuLOpixkboadrCnWPjgMIAeSth,infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeStE,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSYv,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
   zVwTBuLOpixkboadrCnWPjgMIAeStE={'plot':'시청목록을 삭제합니다.'}
   zVwTBuLOpixkboadrCnWPjgMIAeSYq='*** 시청목록 삭제 ***'
   zVwTBuLOpixkboadrCnWPjgMIAeSYE={'mode':'MYVIEW_REMOVE','stype':zVwTBuLOpixkboadrCnWPjgMIAeStY}
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.add_dir(zVwTBuLOpixkboadrCnWPjgMIAeSYq,sublabel='',img='',infoLabels=zVwTBuLOpixkboadrCnWPjgMIAeStE,isFolder=zVwTBuLOpixkboadrCnWPjgMIAeSsq,params=zVwTBuLOpixkboadrCnWPjgMIAeSYE)
   xbmcplugin.endOfDirectory(zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_handle,cacheToDisc=zVwTBuLOpixkboadrCnWPjgMIAeSsq)
 def play_VIDEO(zVwTBuLOpixkboadrCnWPjgMIAeSHh,zVwTBuLOpixkboadrCnWPjgMIAeSts):
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.SaveCredential(zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_winCredential())
  zVwTBuLOpixkboadrCnWPjgMIAeSNY =zVwTBuLOpixkboadrCnWPjgMIAeSts.get('mediacode')
  zVwTBuLOpixkboadrCnWPjgMIAeStY =zVwTBuLOpixkboadrCnWPjgMIAeSts.get('stype')
  zVwTBuLOpixkboadrCnWPjgMIAeSNt =zVwTBuLOpixkboadrCnWPjgMIAeSts.get('pvrmode')
  zVwTBuLOpixkboadrCnWPjgMIAeSNF=zVwTBuLOpixkboadrCnWPjgMIAeSHh.get_selQuality(zVwTBuLOpixkboadrCnWPjgMIAeStY)
  zVwTBuLOpixkboadrCnWPjgMIAeSNs,zVwTBuLOpixkboadrCnWPjgMIAeSNy=zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.GetBroadURL(zVwTBuLOpixkboadrCnWPjgMIAeSNY,zVwTBuLOpixkboadrCnWPjgMIAeSNF,zVwTBuLOpixkboadrCnWPjgMIAeStY,zVwTBuLOpixkboadrCnWPjgMIAeSNt)
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.addon_log('qt, stype, url : %s - %s - %s'%(zVwTBuLOpixkboadrCnWPjgMIAeSsh(zVwTBuLOpixkboadrCnWPjgMIAeSNF),zVwTBuLOpixkboadrCnWPjgMIAeStY,zVwTBuLOpixkboadrCnWPjgMIAeSNs))
  if zVwTBuLOpixkboadrCnWPjgMIAeSNs=='':
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.addon_noti(__language__(30908).encode('utf8'))
   return
  zVwTBuLOpixkboadrCnWPjgMIAeSNq =zVwTBuLOpixkboadrCnWPjgMIAeSNs.find('Policy=')
  if zVwTBuLOpixkboadrCnWPjgMIAeSNq!=-1:
   zVwTBuLOpixkboadrCnWPjgMIAeSNJ =zVwTBuLOpixkboadrCnWPjgMIAeSNs.split('?')[0]
   zVwTBuLOpixkboadrCnWPjgMIAeSNf=zVwTBuLOpixkboadrCnWPjgMIAeSsU(urllib.parse.parse_qsl(urllib.parse.urlsplit(zVwTBuLOpixkboadrCnWPjgMIAeSNs).query))
   zVwTBuLOpixkboadrCnWPjgMIAeSNf=urllib.parse.urlencode(zVwTBuLOpixkboadrCnWPjgMIAeSNf)
   zVwTBuLOpixkboadrCnWPjgMIAeSNf=zVwTBuLOpixkboadrCnWPjgMIAeSNf.replace('&',';')
   zVwTBuLOpixkboadrCnWPjgMIAeSNf=zVwTBuLOpixkboadrCnWPjgMIAeSNf.replace('Policy','CloudFront-Policy')
   zVwTBuLOpixkboadrCnWPjgMIAeSNf=zVwTBuLOpixkboadrCnWPjgMIAeSNf.replace('Signature','CloudFront-Signature')
   zVwTBuLOpixkboadrCnWPjgMIAeSNf=zVwTBuLOpixkboadrCnWPjgMIAeSNf.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   zVwTBuLOpixkboadrCnWPjgMIAeSNh='%s|Cookie=%s'%(zVwTBuLOpixkboadrCnWPjgMIAeSNJ,zVwTBuLOpixkboadrCnWPjgMIAeSNf)
  else:
   zVwTBuLOpixkboadrCnWPjgMIAeSNh=zVwTBuLOpixkboadrCnWPjgMIAeSNs
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.addon_log(zVwTBuLOpixkboadrCnWPjgMIAeSNh)
  zVwTBuLOpixkboadrCnWPjgMIAeSND=xbmcgui.ListItem(path=zVwTBuLOpixkboadrCnWPjgMIAeSNh)
  if zVwTBuLOpixkboadrCnWPjgMIAeSNy!='':
   zVwTBuLOpixkboadrCnWPjgMIAeSNU=zVwTBuLOpixkboadrCnWPjgMIAeSNy
   zVwTBuLOpixkboadrCnWPjgMIAeSNE ='https://cj.drmkeyserver.com/widevine_license'
   zVwTBuLOpixkboadrCnWPjgMIAeSNv ='mpd'
   zVwTBuLOpixkboadrCnWPjgMIAeSNl ='com.widevine.alpha'
   zVwTBuLOpixkboadrCnWPjgMIAeSNc =inputstreamhelper.Helper(zVwTBuLOpixkboadrCnWPjgMIAeSNv,drm='widevine')
   if zVwTBuLOpixkboadrCnWPjgMIAeSNc.check_inputstream():
    zVwTBuLOpixkboadrCnWPjgMIAeSNm={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%zVwTBuLOpixkboadrCnWPjgMIAeSNY,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.USER_AGENT,'AcquireLicenseAssertion':zVwTBuLOpixkboadrCnWPjgMIAeSNU,'Host':'cj.drmkeyserver.com'}
    zVwTBuLOpixkboadrCnWPjgMIAeSNX=zVwTBuLOpixkboadrCnWPjgMIAeSNE+'|'+urllib.parse.urlencode(zVwTBuLOpixkboadrCnWPjgMIAeSNm)+'|R{SSM}|'
    zVwTBuLOpixkboadrCnWPjgMIAeSND.setProperty('inputstream',zVwTBuLOpixkboadrCnWPjgMIAeSNc.inputstream_addon)
    zVwTBuLOpixkboadrCnWPjgMIAeSND.setProperty('inputstream.adaptive.manifest_type',zVwTBuLOpixkboadrCnWPjgMIAeSNv)
    zVwTBuLOpixkboadrCnWPjgMIAeSND.setProperty('inputstream.adaptive.license_type',zVwTBuLOpixkboadrCnWPjgMIAeSNl)
    zVwTBuLOpixkboadrCnWPjgMIAeSND.setProperty('inputstream.adaptive.license_key',zVwTBuLOpixkboadrCnWPjgMIAeSNX)
    zVwTBuLOpixkboadrCnWPjgMIAeSND.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.USER_AGENT))
  xbmcplugin.setResolvedUrl(zVwTBuLOpixkboadrCnWPjgMIAeSHh._addon_handle,zVwTBuLOpixkboadrCnWPjgMIAeSsJ,zVwTBuLOpixkboadrCnWPjgMIAeSND)
  try:
   if zVwTBuLOpixkboadrCnWPjgMIAeSts.get('mode')in['VOD','MOVIE']and zVwTBuLOpixkboadrCnWPjgMIAeSts.get('title'):
    zVwTBuLOpixkboadrCnWPjgMIAeSYE={'code':zVwTBuLOpixkboadrCnWPjgMIAeSts.get('programcode')if zVwTBuLOpixkboadrCnWPjgMIAeSts.get('mode')=='VOD' else zVwTBuLOpixkboadrCnWPjgMIAeSts.get('mediacode'),'img':zVwTBuLOpixkboadrCnWPjgMIAeSts.get('thumbnail'),'title':zVwTBuLOpixkboadrCnWPjgMIAeSts.get('title'),'videoid':zVwTBuLOpixkboadrCnWPjgMIAeSts.get('mediacode')}
    zVwTBuLOpixkboadrCnWPjgMIAeSHh.Save_Watched_List(zVwTBuLOpixkboadrCnWPjgMIAeSts.get('stype'),zVwTBuLOpixkboadrCnWPjgMIAeSYE)
  except:
   zVwTBuLOpixkboadrCnWPjgMIAeSsN
 def logout(zVwTBuLOpixkboadrCnWPjgMIAeSHh):
  zVwTBuLOpixkboadrCnWPjgMIAeSHl=xbmcgui.Dialog()
  zVwTBuLOpixkboadrCnWPjgMIAeSYQ=zVwTBuLOpixkboadrCnWPjgMIAeSHl.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if zVwTBuLOpixkboadrCnWPjgMIAeSYQ==zVwTBuLOpixkboadrCnWPjgMIAeSsq:sys.exit()
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.wininfo_clear()
  if os.path.isfile(zVwTBuLOpixkboadrCnWPjgMIAeSHf):os.remove(zVwTBuLOpixkboadrCnWPjgMIAeSHf)
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(zVwTBuLOpixkboadrCnWPjgMIAeSHh):
  zVwTBuLOpixkboadrCnWPjgMIAeSYN=xbmcgui.Window(10000)
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_TOKEN','')
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_USERINFO','')
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_UUID','')
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_LOGINTIME','')
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_MAINTOKEN','')
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_COOKIEKEY','')
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(zVwTBuLOpixkboadrCnWPjgMIAeSHh):
  zVwTBuLOpixkboadrCnWPjgMIAeSNG =zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.Get_Now_Datetime()
  zVwTBuLOpixkboadrCnWPjgMIAeSNQ=zVwTBuLOpixkboadrCnWPjgMIAeSNG+datetime.timedelta(days=zVwTBuLOpixkboadrCnWPjgMIAeSsy(__addon__.getSetting('cache_ttl')))
  zVwTBuLOpixkboadrCnWPjgMIAeSYN=xbmcgui.Window(10000)
  zVwTBuLOpixkboadrCnWPjgMIAeSNK={'tving_token':zVwTBuLOpixkboadrCnWPjgMIAeSYN.getProperty('TVING_M_TOKEN'),'tving_userinfo':zVwTBuLOpixkboadrCnWPjgMIAeSYN.getProperty('TVING_M_USERINFO'),'tving_uuid':zVwTBuLOpixkboadrCnWPjgMIAeSYN.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':zVwTBuLOpixkboadrCnWPjgMIAeSNQ.strftime('%Y-%m-%d'),'tving_maintoken':zVwTBuLOpixkboadrCnWPjgMIAeSYN.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':zVwTBuLOpixkboadrCnWPjgMIAeSYN.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':zVwTBuLOpixkboadrCnWPjgMIAeSYN.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=zVwTBuLOpixkboadrCnWPjgMIAeSsD(zVwTBuLOpixkboadrCnWPjgMIAeSHf,'w',-1,'utf-8')
   json.dump(zVwTBuLOpixkboadrCnWPjgMIAeSNK,fp)
   fp.close()
  except zVwTBuLOpixkboadrCnWPjgMIAeSsE as exception:
   zVwTBuLOpixkboadrCnWPjgMIAeSsv(exception)
 def cookiefile_check(zVwTBuLOpixkboadrCnWPjgMIAeSHh):
  zVwTBuLOpixkboadrCnWPjgMIAeSNK={}
  try: 
   fp=zVwTBuLOpixkboadrCnWPjgMIAeSsD(zVwTBuLOpixkboadrCnWPjgMIAeSHf,'r',-1,'utf-8')
   zVwTBuLOpixkboadrCnWPjgMIAeSNK= json.load(fp)
   fp.close()
  except zVwTBuLOpixkboadrCnWPjgMIAeSsE as exception:
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.wininfo_clear()
   return zVwTBuLOpixkboadrCnWPjgMIAeSsq
  zVwTBuLOpixkboadrCnWPjgMIAeSYc =__addon__.getSetting('id')
  zVwTBuLOpixkboadrCnWPjgMIAeSYm =__addon__.getSetting('pw')
  zVwTBuLOpixkboadrCnWPjgMIAeSNR=__addon__.getSetting('login_type')
  zVwTBuLOpixkboadrCnWPjgMIAeSsH =__addon__.getSetting('selected_profile')
  zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_id']=base64.standard_b64decode(zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_id']).decode('utf-8')
  zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_pw']=base64.standard_b64decode(zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_pw']).decode('utf-8')
  try:
   zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_profile']
  except:
   zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_profile']='0'
  if zVwTBuLOpixkboadrCnWPjgMIAeSYc!=zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_id']or zVwTBuLOpixkboadrCnWPjgMIAeSYm!=zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_pw']or zVwTBuLOpixkboadrCnWPjgMIAeSNR!=zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_logintype']or zVwTBuLOpixkboadrCnWPjgMIAeSsH!=zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_profile']:
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.wininfo_clear()
   return zVwTBuLOpixkboadrCnWPjgMIAeSsq
  zVwTBuLOpixkboadrCnWPjgMIAeSYK =zVwTBuLOpixkboadrCnWPjgMIAeSsy(zVwTBuLOpixkboadrCnWPjgMIAeSHh.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  zVwTBuLOpixkboadrCnWPjgMIAeSsY=zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_limitdate']
  zVwTBuLOpixkboadrCnWPjgMIAeSYR =zVwTBuLOpixkboadrCnWPjgMIAeSsy(re.sub('-','',zVwTBuLOpixkboadrCnWPjgMIAeSsY))
  if zVwTBuLOpixkboadrCnWPjgMIAeSYR<zVwTBuLOpixkboadrCnWPjgMIAeSYK:
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.wininfo_clear()
   return zVwTBuLOpixkboadrCnWPjgMIAeSsq
  zVwTBuLOpixkboadrCnWPjgMIAeSYN=xbmcgui.Window(10000)
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_TOKEN',zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_token'])
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_USERINFO',zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_userinfo'])
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_UUID',zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_uuid'])
  zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_LOGINTIME',zVwTBuLOpixkboadrCnWPjgMIAeSsY)
  try:
   zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_MAINTOKEN',zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_maintoken'])
   zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_COOKIEKEY',zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_cookiekey'])
   zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_LOCKKEY',zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_lockkey'])
  except:
   zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_MAINTOKEN',zVwTBuLOpixkboadrCnWPjgMIAeSNK['tving_token'])
   zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_COOKIEKEY','Y')
   zVwTBuLOpixkboadrCnWPjgMIAeSYN.setProperty('TVING_M_LOCKKEY','N')
  return zVwTBuLOpixkboadrCnWPjgMIAeSsJ
 def tving_main(zVwTBuLOpixkboadrCnWPjgMIAeSHh):
  zVwTBuLOpixkboadrCnWPjgMIAeSst=zVwTBuLOpixkboadrCnWPjgMIAeSHh.main_params.get('mode',zVwTBuLOpixkboadrCnWPjgMIAeSsN)
  if zVwTBuLOpixkboadrCnWPjgMIAeSst=='LOGOUT':
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.logout()
   return
  zVwTBuLOpixkboadrCnWPjgMIAeSHh.login_main()
  if zVwTBuLOpixkboadrCnWPjgMIAeSst is zVwTBuLOpixkboadrCnWPjgMIAeSsN:
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.dp_Main_List()
  elif zVwTBuLOpixkboadrCnWPjgMIAeSst in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.dp_Title_Group(zVwTBuLOpixkboadrCnWPjgMIAeSHh.main_params)
  elif zVwTBuLOpixkboadrCnWPjgMIAeSst=='CHANNEL':
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.dp_LiveChannel_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh.main_params)
  elif zVwTBuLOpixkboadrCnWPjgMIAeSst in['LIVE','VOD','MOVIE']:
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.play_VIDEO(zVwTBuLOpixkboadrCnWPjgMIAeSHh.main_params)
  elif zVwTBuLOpixkboadrCnWPjgMIAeSst=='PROGRAM':
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.dp_Program_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh.main_params)
  elif zVwTBuLOpixkboadrCnWPjgMIAeSst=='EPISODE':
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.dp_Episode_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh.main_params)
  elif zVwTBuLOpixkboadrCnWPjgMIAeSst=='MOVIE_SUB':
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.dp_Movie_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh.main_params)
  elif zVwTBuLOpixkboadrCnWPjgMIAeSst=='SEARCH_GROUP':
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.dp_Search_Group(zVwTBuLOpixkboadrCnWPjgMIAeSHh.main_params)
  elif zVwTBuLOpixkboadrCnWPjgMIAeSst=='SEARCH':
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.dp_Search_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh.main_params)
  elif zVwTBuLOpixkboadrCnWPjgMIAeSst=='WATCH':
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.dp_Watch_List(zVwTBuLOpixkboadrCnWPjgMIAeSHh.main_params)
  elif zVwTBuLOpixkboadrCnWPjgMIAeSst=='MYVIEW_REMOVE':
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.dp_WatchList_Delete(zVwTBuLOpixkboadrCnWPjgMIAeSHh.main_params)
  elif zVwTBuLOpixkboadrCnWPjgMIAeSst=='ORDER_BY':
   zVwTBuLOpixkboadrCnWPjgMIAeSHh.dp_setEpOrderby(zVwTBuLOpixkboadrCnWPjgMIAeSHh.main_params)
  else:
   zVwTBuLOpixkboadrCnWPjgMIAeSsN
# Created by pyminifier (https://github.com/liftoff/pyminifier)
