__author__="NightRain"
gHEMoONKPymCbRdrlGxupVWUqanJTt=object
gHEMoONKPymCbRdrlGxupVWUqanJTs=None
gHEMoONKPymCbRdrlGxupVWUqanJTw=False
gHEMoONKPymCbRdrlGxupVWUqanJTQ=int
gHEMoONKPymCbRdrlGxupVWUqanJTc=range
gHEMoONKPymCbRdrlGxupVWUqanJTj=True
gHEMoONKPymCbRdrlGxupVWUqanJTD=Exception
gHEMoONKPymCbRdrlGxupVWUqanJTY=print
gHEMoONKPymCbRdrlGxupVWUqanJTX=str
gHEMoONKPymCbRdrlGxupVWUqanJTk=list
gHEMoONKPymCbRdrlGxupVWUqanJTi=len
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import random
gHEMoONKPymCbRdrlGxupVWUqanJSL={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
class gHEMoONKPymCbRdrlGxupVWUqanJSI(gHEMoONKPymCbRdrlGxupVWUqanJTt):
 def __init__(gHEMoONKPymCbRdrlGxupVWUqanJSh):
  gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_TOKEN =''
  gHEMoONKPymCbRdrlGxupVWUqanJSh.POC_USERINFO =''
  gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_UUID ='-'
  gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_MAINTOKEN=''
  gHEMoONKPymCbRdrlGxupVWUqanJSh.TVIGN_COOKIEKEY=''
  gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_LOCKKEY =''
  gHEMoONKPymCbRdrlGxupVWUqanJSh.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  gHEMoONKPymCbRdrlGxupVWUqanJSh.NETWORKCODE ='CSND0900'
  gHEMoONKPymCbRdrlGxupVWUqanJSh.OSCODE ='CSOD0900' 
  gHEMoONKPymCbRdrlGxupVWUqanJSh.TELECODE ='CSCD0900'
  gHEMoONKPymCbRdrlGxupVWUqanJSh.SCREENCODE ='CSSD0100'
  gHEMoONKPymCbRdrlGxupVWUqanJSh.LIVE_LIMIT =23
  gHEMoONKPymCbRdrlGxupVWUqanJSh.VOD_LIMIT =20
  gHEMoONKPymCbRdrlGxupVWUqanJSh.EPISODE_LIMIT =30 
  gHEMoONKPymCbRdrlGxupVWUqanJSh.SEARCH_LIMIT =80 
  gHEMoONKPymCbRdrlGxupVWUqanJSh.MOVIE_LIMIT =18
  gHEMoONKPymCbRdrlGxupVWUqanJSh.API_DOMAIN ='https://api.tving.com'
  gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN ='https://image.tving.com'
  gHEMoONKPymCbRdrlGxupVWUqanJSh.SEARCH_DOMAIN ='https://search.tving.com'
  gHEMoONKPymCbRdrlGxupVWUqanJSh.LOGIN_DOMAIN ='https://user.tving.com'
  gHEMoONKPymCbRdrlGxupVWUqanJSh.URL_DOMAIN ='https://www.tving.com'
  gHEMoONKPymCbRdrlGxupVWUqanJSh.MOVIE_LITE =['2610061','2610161','261062']
  gHEMoONKPymCbRdrlGxupVWUqanJSh.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  gHEMoONKPymCbRdrlGxupVWUqanJSh.DEFAULT_HEADER ={'user-agent':gHEMoONKPymCbRdrlGxupVWUqanJSh.USER_AGENT}
  gHEMoONKPymCbRdrlGxupVWUqanJSh.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(gHEMoONKPymCbRdrlGxupVWUqanJSh,jobtype,gHEMoONKPymCbRdrlGxupVWUqanJIj,payload=gHEMoONKPymCbRdrlGxupVWUqanJTs,params=gHEMoONKPymCbRdrlGxupVWUqanJTs,headers=gHEMoONKPymCbRdrlGxupVWUqanJTs,cookies=gHEMoONKPymCbRdrlGxupVWUqanJTs,redirects=gHEMoONKPymCbRdrlGxupVWUqanJTw):
  gHEMoONKPymCbRdrlGxupVWUqanJST=gHEMoONKPymCbRdrlGxupVWUqanJSh.DEFAULT_HEADER
  if headers:gHEMoONKPymCbRdrlGxupVWUqanJST.update(headers)
  if jobtype=='Get':
   gHEMoONKPymCbRdrlGxupVWUqanJSf=requests.get(gHEMoONKPymCbRdrlGxupVWUqanJIj,params=params,headers=gHEMoONKPymCbRdrlGxupVWUqanJST,cookies=cookies,allow_redirects=redirects)
  else:
   gHEMoONKPymCbRdrlGxupVWUqanJSf=requests.post(gHEMoONKPymCbRdrlGxupVWUqanJIj,data=payload,params=params,headers=gHEMoONKPymCbRdrlGxupVWUqanJST,cookies=cookies,allow_redirects=redirects)
  return gHEMoONKPymCbRdrlGxupVWUqanJSf
 def makeDefaultCookies(gHEMoONKPymCbRdrlGxupVWUqanJSh,vToken=gHEMoONKPymCbRdrlGxupVWUqanJTs,vUserinfo=gHEMoONKPymCbRdrlGxupVWUqanJTs):
  gHEMoONKPymCbRdrlGxupVWUqanJSt={}
  gHEMoONKPymCbRdrlGxupVWUqanJSt['_tving_token']=gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_TOKEN if vToken==gHEMoONKPymCbRdrlGxupVWUqanJTs else vToken
  gHEMoONKPymCbRdrlGxupVWUqanJSt['POC_USERINFO']=gHEMoONKPymCbRdrlGxupVWUqanJSh.POC_USERINFO if vToken==gHEMoONKPymCbRdrlGxupVWUqanJTs else vUserinfo
  if gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_MAINTOKEN!='':gHEMoONKPymCbRdrlGxupVWUqanJSt[gHEMoONKPymCbRdrlGxupVWUqanJSh.GLOBAL_COOKIENM['tv_maintoken']]=gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_MAINTOKEN
  if gHEMoONKPymCbRdrlGxupVWUqanJSh.TVIGN_COOKIEKEY!='':gHEMoONKPymCbRdrlGxupVWUqanJSt[gHEMoONKPymCbRdrlGxupVWUqanJSh.GLOBAL_COOKIENM['tv_cookiekey']]=gHEMoONKPymCbRdrlGxupVWUqanJSh.TVIGN_COOKIEKEY
  if gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_LOCKKEY !='':gHEMoONKPymCbRdrlGxupVWUqanJSt[gHEMoONKPymCbRdrlGxupVWUqanJSh.GLOBAL_COOKIENM['tv_lockkey']] =gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_LOCKKEY
  return gHEMoONKPymCbRdrlGxupVWUqanJSt
 def getDeviceStr(gHEMoONKPymCbRdrlGxupVWUqanJSh):
  gHEMoONKPymCbRdrlGxupVWUqanJSs=[]
  gHEMoONKPymCbRdrlGxupVWUqanJSs.append('Windows') 
  gHEMoONKPymCbRdrlGxupVWUqanJSs.append('Chrome') 
  gHEMoONKPymCbRdrlGxupVWUqanJSs.append('ko-KR') 
  gHEMoONKPymCbRdrlGxupVWUqanJSs.append('undefined') 
  gHEMoONKPymCbRdrlGxupVWUqanJSs.append('24') 
  gHEMoONKPymCbRdrlGxupVWUqanJSs.append(u'한국 표준시')
  gHEMoONKPymCbRdrlGxupVWUqanJSs.append('undefined') 
  gHEMoONKPymCbRdrlGxupVWUqanJSs.append('undefined') 
  gHEMoONKPymCbRdrlGxupVWUqanJSs.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  gHEMoONKPymCbRdrlGxupVWUqanJSw=''
  for gHEMoONKPymCbRdrlGxupVWUqanJSQ in gHEMoONKPymCbRdrlGxupVWUqanJSs:
   gHEMoONKPymCbRdrlGxupVWUqanJSw+=gHEMoONKPymCbRdrlGxupVWUqanJSQ+'|'
  return gHEMoONKPymCbRdrlGxupVWUqanJSw
 def SaveCredential(gHEMoONKPymCbRdrlGxupVWUqanJSh,gHEMoONKPymCbRdrlGxupVWUqanJSc):
  gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_TOKEN =gHEMoONKPymCbRdrlGxupVWUqanJSc.get('tving_token')
  gHEMoONKPymCbRdrlGxupVWUqanJSh.POC_USERINFO =gHEMoONKPymCbRdrlGxupVWUqanJSc.get('poc_userinfo')
  gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_UUID =gHEMoONKPymCbRdrlGxupVWUqanJSc.get('tving_uuid')
  gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_MAINTOKEN=gHEMoONKPymCbRdrlGxupVWUqanJSc.get('tving_maintoken')
  gHEMoONKPymCbRdrlGxupVWUqanJSh.TVIGN_COOKIEKEY=gHEMoONKPymCbRdrlGxupVWUqanJSc.get('tving_cookiekey')
  gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_LOCKKEY =gHEMoONKPymCbRdrlGxupVWUqanJSc.get('tving_lockkey')
 def LoadCredential(gHEMoONKPymCbRdrlGxupVWUqanJSh):
  gHEMoONKPymCbRdrlGxupVWUqanJSc={'tving_token':gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_TOKEN,'poc_userinfo':gHEMoONKPymCbRdrlGxupVWUqanJSh.POC_USERINFO,'tving_uuid':gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_UUID,'tving_maintoken':gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_MAINTOKEN,'tving_cookiekey':gHEMoONKPymCbRdrlGxupVWUqanJSh.TVIGN_COOKIEKEY,'tving_lockkey':gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_LOCKKEY}
  return gHEMoONKPymCbRdrlGxupVWUqanJSc
 def GetDefaultParams(gHEMoONKPymCbRdrlGxupVWUqanJSh):
  gHEMoONKPymCbRdrlGxupVWUqanJSj={'apiKey':gHEMoONKPymCbRdrlGxupVWUqanJSh.APIKEY,'networkCode':gHEMoONKPymCbRdrlGxupVWUqanJSh.NETWORKCODE,'osCode':gHEMoONKPymCbRdrlGxupVWUqanJSh.OSCODE,'teleCode':gHEMoONKPymCbRdrlGxupVWUqanJSh.TELECODE,'screenCode':gHEMoONKPymCbRdrlGxupVWUqanJSh.SCREENCODE}
  return gHEMoONKPymCbRdrlGxupVWUqanJSj
 def GetNoCache(gHEMoONKPymCbRdrlGxupVWUqanJSh,timetype=1):
  if timetype==1:
   return gHEMoONKPymCbRdrlGxupVWUqanJTQ(time.time())
  else:
   return gHEMoONKPymCbRdrlGxupVWUqanJTQ(time.time()*1000)
 def GetUniqueid(gHEMoONKPymCbRdrlGxupVWUqanJSh):
  gHEMoONKPymCbRdrlGxupVWUqanJSD=[0 for i in gHEMoONKPymCbRdrlGxupVWUqanJTc(256)]
  for i in gHEMoONKPymCbRdrlGxupVWUqanJTc(256):
   gHEMoONKPymCbRdrlGxupVWUqanJSD[i]='%02x'%(i)
  gHEMoONKPymCbRdrlGxupVWUqanJSY=gHEMoONKPymCbRdrlGxupVWUqanJTQ(4294967295*random.random())|0
  gHEMoONKPymCbRdrlGxupVWUqanJSX=gHEMoONKPymCbRdrlGxupVWUqanJSD[255&gHEMoONKPymCbRdrlGxupVWUqanJSY]+gHEMoONKPymCbRdrlGxupVWUqanJSD[gHEMoONKPymCbRdrlGxupVWUqanJSY>>8&255]+gHEMoONKPymCbRdrlGxupVWUqanJSD[gHEMoONKPymCbRdrlGxupVWUqanJSY>>16&255]+gHEMoONKPymCbRdrlGxupVWUqanJSD[gHEMoONKPymCbRdrlGxupVWUqanJSY>>24&255]
  return gHEMoONKPymCbRdrlGxupVWUqanJSX
 def GetCredential(gHEMoONKPymCbRdrlGxupVWUqanJSh,user_id,user_pw,login_type,user_pf):
  gHEMoONKPymCbRdrlGxupVWUqanJSk=gHEMoONKPymCbRdrlGxupVWUqanJTw
  gHEMoONKPymCbRdrlGxupVWUqanJSi=gHEMoONKPymCbRdrlGxupVWUqanJSe=gHEMoONKPymCbRdrlGxupVWUqanJIS=gHEMoONKPymCbRdrlGxupVWUqanJIL=gHEMoONKPymCbRdrlGxupVWUqanJIh='' 
  gHEMoONKPymCbRdrlGxupVWUqanJSA ='-'
  try:
   gHEMoONKPymCbRdrlGxupVWUqanJSB=gHEMoONKPymCbRdrlGxupVWUqanJSh.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   gHEMoONKPymCbRdrlGxupVWUqanJSz={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   gHEMoONKPymCbRdrlGxupVWUqanJSF=gHEMoONKPymCbRdrlGxupVWUqanJSh.callRequestCookies('Post',gHEMoONKPymCbRdrlGxupVWUqanJSB,payload=gHEMoONKPymCbRdrlGxupVWUqanJSz,params=gHEMoONKPymCbRdrlGxupVWUqanJTs,headers=gHEMoONKPymCbRdrlGxupVWUqanJTs,cookies=gHEMoONKPymCbRdrlGxupVWUqanJTs)
   for gHEMoONKPymCbRdrlGxupVWUqanJSv in gHEMoONKPymCbRdrlGxupVWUqanJSF.cookies:
    if gHEMoONKPymCbRdrlGxupVWUqanJSv.name=='_tving_token':
     gHEMoONKPymCbRdrlGxupVWUqanJSe=gHEMoONKPymCbRdrlGxupVWUqanJSv.value
    elif gHEMoONKPymCbRdrlGxupVWUqanJSv.name=='POC_USERINFO':
     gHEMoONKPymCbRdrlGxupVWUqanJIS=gHEMoONKPymCbRdrlGxupVWUqanJSv.value
   if gHEMoONKPymCbRdrlGxupVWUqanJSe=='':return gHEMoONKPymCbRdrlGxupVWUqanJSk
   gHEMoONKPymCbRdrlGxupVWUqanJSi=gHEMoONKPymCbRdrlGxupVWUqanJSe
   gHEMoONKPymCbRdrlGxupVWUqanJSe,gHEMoONKPymCbRdrlGxupVWUqanJIL,gHEMoONKPymCbRdrlGxupVWUqanJIh=gHEMoONKPymCbRdrlGxupVWUqanJSh.GetProfileToken(gHEMoONKPymCbRdrlGxupVWUqanJSe,gHEMoONKPymCbRdrlGxupVWUqanJIS,user_pf)
   gHEMoONKPymCbRdrlGxupVWUqanJSk=gHEMoONKPymCbRdrlGxupVWUqanJTj
   gHEMoONKPymCbRdrlGxupVWUqanJSA =gHEMoONKPymCbRdrlGxupVWUqanJSh.GetDeviceList(gHEMoONKPymCbRdrlGxupVWUqanJSe,gHEMoONKPymCbRdrlGxupVWUqanJIS)
   gHEMoONKPymCbRdrlGxupVWUqanJSA =gHEMoONKPymCbRdrlGxupVWUqanJSA+'-'+gHEMoONKPymCbRdrlGxupVWUqanJSh.GetUniqueid()
  except gHEMoONKPymCbRdrlGxupVWUqanJTD as exception:
   gHEMoONKPymCbRdrlGxupVWUqanJSi=gHEMoONKPymCbRdrlGxupVWUqanJSe=gHEMoONKPymCbRdrlGxupVWUqanJIS=gHEMoONKPymCbRdrlGxupVWUqanJIL=gHEMoONKPymCbRdrlGxupVWUqanJIh=''
   gHEMoONKPymCbRdrlGxupVWUqanJSA='-'
   gHEMoONKPymCbRdrlGxupVWUqanJTY(exception)
  gHEMoONKPymCbRdrlGxupVWUqanJSc={'tving_token':gHEMoONKPymCbRdrlGxupVWUqanJSe,'poc_userinfo':gHEMoONKPymCbRdrlGxupVWUqanJIS,'tving_uuid':gHEMoONKPymCbRdrlGxupVWUqanJSA,'tving_maintoken':gHEMoONKPymCbRdrlGxupVWUqanJSi,'tving_cookiekey':gHEMoONKPymCbRdrlGxupVWUqanJIL,'tving_lockkey':gHEMoONKPymCbRdrlGxupVWUqanJIh}
  gHEMoONKPymCbRdrlGxupVWUqanJSh.SaveCredential(gHEMoONKPymCbRdrlGxupVWUqanJSc)
  return gHEMoONKPymCbRdrlGxupVWUqanJSk
 def Get_Now_Datetime(gHEMoONKPymCbRdrlGxupVWUqanJSh):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(gHEMoONKPymCbRdrlGxupVWUqanJSh,mediacode,sel_quality,stype,pvrmode='-'):
  gHEMoONKPymCbRdrlGxupVWUqanJIf=''
  gHEMoONKPymCbRdrlGxupVWUqanJIt=''
  gHEMoONKPymCbRdrlGxupVWUqanJIs=gHEMoONKPymCbRdrlGxupVWUqanJSh.TVING_UUID 
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    gHEMoONKPymCbRdrlGxupVWUqanJIw ='/v2a/media/stream/info' 
    gHEMoONKPymCbRdrlGxupVWUqanJIQ=gHEMoONKPymCbRdrlGxupVWUqanJSh.GetDefaultParams()
    gHEMoONKPymCbRdrlGxupVWUqanJIc={'info':'N','mediaCode':mediacode,'noCache':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','uuid':gHEMoONKPymCbRdrlGxupVWUqanJIs,'deviceInfo':'PC','wm':'Y'}
    gHEMoONKPymCbRdrlGxupVWUqanJIQ.update(gHEMoONKPymCbRdrlGxupVWUqanJIc)
    gHEMoONKPymCbRdrlGxupVWUqanJIj=gHEMoONKPymCbRdrlGxupVWUqanJSh.API_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIw
    gHEMoONKPymCbRdrlGxupVWUqanJSt=gHEMoONKPymCbRdrlGxupVWUqanJSh.makeDefaultCookies()
    gHEMoONKPymCbRdrlGxupVWUqanJSF=gHEMoONKPymCbRdrlGxupVWUqanJSh.callRequestCookies('Get',gHEMoONKPymCbRdrlGxupVWUqanJIj,payload=gHEMoONKPymCbRdrlGxupVWUqanJTs,params=gHEMoONKPymCbRdrlGxupVWUqanJIQ,headers=gHEMoONKPymCbRdrlGxupVWUqanJTs,cookies=gHEMoONKPymCbRdrlGxupVWUqanJSt)
    gHEMoONKPymCbRdrlGxupVWUqanJID=json.loads(gHEMoONKPymCbRdrlGxupVWUqanJSF.text)
    if not('stream' in gHEMoONKPymCbRdrlGxupVWUqanJID['body']):return gHEMoONKPymCbRdrlGxupVWUqanJIf,gHEMoONKPymCbRdrlGxupVWUqanJIt 
    gHEMoONKPymCbRdrlGxupVWUqanJIY=gHEMoONKPymCbRdrlGxupVWUqanJID['body']['stream']
    gHEMoONKPymCbRdrlGxupVWUqanJIX=gHEMoONKPymCbRdrlGxupVWUqanJIY['quality']
    gHEMoONKPymCbRdrlGxupVWUqanJIk=[]
    for gHEMoONKPymCbRdrlGxupVWUqanJIi in gHEMoONKPymCbRdrlGxupVWUqanJIX:
     if gHEMoONKPymCbRdrlGxupVWUqanJIi['active']=='Y':
      gHEMoONKPymCbRdrlGxupVWUqanJIk.append({gHEMoONKPymCbRdrlGxupVWUqanJSL.get(gHEMoONKPymCbRdrlGxupVWUqanJIi['code']):gHEMoONKPymCbRdrlGxupVWUqanJIi['code']})
    gHEMoONKPymCbRdrlGxupVWUqanJIA=gHEMoONKPymCbRdrlGxupVWUqanJSh.CheckQuality(sel_quality,gHEMoONKPymCbRdrlGxupVWUqanJIk)
   else:
    for gHEMoONKPymCbRdrlGxupVWUqanJIB,gHEMoONKPymCbRdrlGxupVWUqanJLT in gHEMoONKPymCbRdrlGxupVWUqanJSL.items():
     if gHEMoONKPymCbRdrlGxupVWUqanJLT==sel_quality:
      gHEMoONKPymCbRdrlGxupVWUqanJIA=gHEMoONKPymCbRdrlGxupVWUqanJIB
  except gHEMoONKPymCbRdrlGxupVWUqanJTD as exception:
   gHEMoONKPymCbRdrlGxupVWUqanJTY(exception)
   for gHEMoONKPymCbRdrlGxupVWUqanJIB,gHEMoONKPymCbRdrlGxupVWUqanJLT in gHEMoONKPymCbRdrlGxupVWUqanJSL.items():
    if gHEMoONKPymCbRdrlGxupVWUqanJLT==sel_quality:
     gHEMoONKPymCbRdrlGxupVWUqanJIA=gHEMoONKPymCbRdrlGxupVWUqanJIB
   return gHEMoONKPymCbRdrlGxupVWUqanJIf,gHEMoONKPymCbRdrlGxupVWUqanJIt
  gHEMoONKPymCbRdrlGxupVWUqanJTY(gHEMoONKPymCbRdrlGxupVWUqanJIA)
  try:
   gHEMoONKPymCbRdrlGxupVWUqanJIw ='/streaming/info'
   gHEMoONKPymCbRdrlGxupVWUqanJIQ=gHEMoONKPymCbRdrlGxupVWUqanJSh.GetDefaultParams()
   if stype=='onair':gHEMoONKPymCbRdrlGxupVWUqanJIQ['osCode']='CSOD0400' 
   gHEMoONKPymCbRdrlGxupVWUqanJIz={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   gHEMoONKPymCbRdrlGxupVWUqanJIF=gHEMoONKPymCbRdrlGxupVWUqanJSh.makeOocUrl(gHEMoONKPymCbRdrlGxupVWUqanJIz)
   gHEMoONKPymCbRdrlGxupVWUqanJIv=urllib.parse.quote(gHEMoONKPymCbRdrlGxupVWUqanJIF)
   gHEMoONKPymCbRdrlGxupVWUqanJIc={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':gHEMoONKPymCbRdrlGxupVWUqanJIA,'adReq':'adproxy','ooc':gHEMoONKPymCbRdrlGxupVWUqanJIF,'uuid':gHEMoONKPymCbRdrlGxupVWUqanJIs,'deviceInfo':'PC'}
   gHEMoONKPymCbRdrlGxupVWUqanJIe =gHEMoONKPymCbRdrlGxupVWUqanJIQ
   gHEMoONKPymCbRdrlGxupVWUqanJIe.update(gHEMoONKPymCbRdrlGxupVWUqanJIc)
   gHEMoONKPymCbRdrlGxupVWUqanJIj=gHEMoONKPymCbRdrlGxupVWUqanJSh.URL_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIw
   gHEMoONKPymCbRdrlGxupVWUqanJLS={'origin':'https://www.tving.com'}
   if stype=='onair':gHEMoONKPymCbRdrlGxupVWUqanJLS['Referer']='https://www.tving.com/live/player/'+mediacode
   else: gHEMoONKPymCbRdrlGxupVWUqanJLS['Referer']='https://www.tving.com/vod/player/'+mediacode
   gHEMoONKPymCbRdrlGxupVWUqanJSt=gHEMoONKPymCbRdrlGxupVWUqanJSh.makeDefaultCookies()
   gHEMoONKPymCbRdrlGxupVWUqanJSt['onClickEvent2']=gHEMoONKPymCbRdrlGxupVWUqanJIv
   gHEMoONKPymCbRdrlGxupVWUqanJSF=gHEMoONKPymCbRdrlGxupVWUqanJSh.callRequestCookies('Post',gHEMoONKPymCbRdrlGxupVWUqanJIj,payload=gHEMoONKPymCbRdrlGxupVWUqanJIe,params=gHEMoONKPymCbRdrlGxupVWUqanJTs,headers=gHEMoONKPymCbRdrlGxupVWUqanJLS,cookies=gHEMoONKPymCbRdrlGxupVWUqanJSt,redirects=gHEMoONKPymCbRdrlGxupVWUqanJTw)
   gHEMoONKPymCbRdrlGxupVWUqanJTY(gHEMoONKPymCbRdrlGxupVWUqanJSF.status_code)
   gHEMoONKPymCbRdrlGxupVWUqanJID=json.loads(gHEMoONKPymCbRdrlGxupVWUqanJSF.text)
   if 'drm_license_assertion' in gHEMoONKPymCbRdrlGxupVWUqanJID['stream']:
    gHEMoONKPymCbRdrlGxupVWUqanJIt =gHEMoONKPymCbRdrlGxupVWUqanJID['stream']['drm_license_assertion']
    gHEMoONKPymCbRdrlGxupVWUqanJIf=gHEMoONKPymCbRdrlGxupVWUqanJID['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in gHEMoONKPymCbRdrlGxupVWUqanJID['stream']['broadcast']):return gHEMoONKPymCbRdrlGxupVWUqanJIf,gHEMoONKPymCbRdrlGxupVWUqanJIt
    gHEMoONKPymCbRdrlGxupVWUqanJIf=gHEMoONKPymCbRdrlGxupVWUqanJID['stream']['broadcast']['broad_url']
  except gHEMoONKPymCbRdrlGxupVWUqanJTD as exception:
   gHEMoONKPymCbRdrlGxupVWUqanJTY(exception)
  return gHEMoONKPymCbRdrlGxupVWUqanJIf,gHEMoONKPymCbRdrlGxupVWUqanJIt
 def CheckQuality(gHEMoONKPymCbRdrlGxupVWUqanJSh,sel_qt,gHEMoONKPymCbRdrlGxupVWUqanJIk):
  for gHEMoONKPymCbRdrlGxupVWUqanJLI in gHEMoONKPymCbRdrlGxupVWUqanJIk:
   if sel_qt>=gHEMoONKPymCbRdrlGxupVWUqanJTk(gHEMoONKPymCbRdrlGxupVWUqanJLI)[0]:return gHEMoONKPymCbRdrlGxupVWUqanJLI.get(gHEMoONKPymCbRdrlGxupVWUqanJTk(gHEMoONKPymCbRdrlGxupVWUqanJLI)[0])
   gHEMoONKPymCbRdrlGxupVWUqanJLh=gHEMoONKPymCbRdrlGxupVWUqanJLI.get(gHEMoONKPymCbRdrlGxupVWUqanJTk(gHEMoONKPymCbRdrlGxupVWUqanJLI)[0])
  return gHEMoONKPymCbRdrlGxupVWUqanJLh
 def makeOocUrl(gHEMoONKPymCbRdrlGxupVWUqanJSh,gHEMoONKPymCbRdrlGxupVWUqanJIz):
  gHEMoONKPymCbRdrlGxupVWUqanJIj=''
  for gHEMoONKPymCbRdrlGxupVWUqanJIB,gHEMoONKPymCbRdrlGxupVWUqanJLT in gHEMoONKPymCbRdrlGxupVWUqanJIz.items():
   gHEMoONKPymCbRdrlGxupVWUqanJIj+="%s=%s^"%(gHEMoONKPymCbRdrlGxupVWUqanJIB,gHEMoONKPymCbRdrlGxupVWUqanJLT)
  return gHEMoONKPymCbRdrlGxupVWUqanJIj
 def GetLiveChannelList(gHEMoONKPymCbRdrlGxupVWUqanJSh,stype,page_int):
  gHEMoONKPymCbRdrlGxupVWUqanJLf=[]
  gHEMoONKPymCbRdrlGxupVWUqanJLt=gHEMoONKPymCbRdrlGxupVWUqanJTw
  try:
   gHEMoONKPymCbRdrlGxupVWUqanJIw ='/v2/media/lives'
   if stype=='onair':
    gHEMoONKPymCbRdrlGxupVWUqanJLs='CPCS0100,CPCS0400'
   else:
    gHEMoONKPymCbRdrlGxupVWUqanJLs='CPCS0300'
   gHEMoONKPymCbRdrlGxupVWUqanJIQ=gHEMoONKPymCbRdrlGxupVWUqanJSh.GetDefaultParams()
   gHEMoONKPymCbRdrlGxupVWUqanJIc={'pageNo':gHEMoONKPymCbRdrlGxupVWUqanJTX(page_int),'pageSize':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':gHEMoONKPymCbRdrlGxupVWUqanJLs,'_':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.GetNoCache(2))}
   gHEMoONKPymCbRdrlGxupVWUqanJIQ.update(gHEMoONKPymCbRdrlGxupVWUqanJIc)
   gHEMoONKPymCbRdrlGxupVWUqanJIj=gHEMoONKPymCbRdrlGxupVWUqanJSh.API_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIw
   gHEMoONKPymCbRdrlGxupVWUqanJSt=gHEMoONKPymCbRdrlGxupVWUqanJSh.makeDefaultCookies()
   gHEMoONKPymCbRdrlGxupVWUqanJSF=gHEMoONKPymCbRdrlGxupVWUqanJSh.callRequestCookies('Get',gHEMoONKPymCbRdrlGxupVWUqanJIj,payload=gHEMoONKPymCbRdrlGxupVWUqanJTs,params=gHEMoONKPymCbRdrlGxupVWUqanJIQ,headers=gHEMoONKPymCbRdrlGxupVWUqanJTs,cookies=gHEMoONKPymCbRdrlGxupVWUqanJSt)
   gHEMoONKPymCbRdrlGxupVWUqanJID=json.loads(gHEMoONKPymCbRdrlGxupVWUqanJSF.text)
   if not('result' in gHEMoONKPymCbRdrlGxupVWUqanJID['body']):return gHEMoONKPymCbRdrlGxupVWUqanJLf,gHEMoONKPymCbRdrlGxupVWUqanJLt
   gHEMoONKPymCbRdrlGxupVWUqanJLw=gHEMoONKPymCbRdrlGxupVWUqanJID['body']['result']
   for gHEMoONKPymCbRdrlGxupVWUqanJIi in gHEMoONKPymCbRdrlGxupVWUqanJLw:
    gHEMoONKPymCbRdrlGxupVWUqanJLQ={}
    gHEMoONKPymCbRdrlGxupVWUqanJLQ['mediatype']='video'
    gHEMoONKPymCbRdrlGxupVWUqanJLc=gHEMoONKPymCbRdrlGxupVWUqanJLY=gHEMoONKPymCbRdrlGxupVWUqanJLX=gHEMoONKPymCbRdrlGxupVWUqanJLk=''
    gHEMoONKPymCbRdrlGxupVWUqanJLj=gHEMoONKPymCbRdrlGxupVWUqanJLz=''
    gHEMoONKPymCbRdrlGxupVWUqanJLD=gHEMoONKPymCbRdrlGxupVWUqanJIi['live_code']
    gHEMoONKPymCbRdrlGxupVWUqanJLc =gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['channel']['name']['ko']
    if gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['episode']!=gHEMoONKPymCbRdrlGxupVWUqanJTs:
     gHEMoONKPymCbRdrlGxupVWUqanJLY =gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['program']['name']['ko']
     gHEMoONKPymCbRdrlGxupVWUqanJLY =gHEMoONKPymCbRdrlGxupVWUqanJLY+', '+gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['episode']['frequency'])+'회'
     if gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['episode']['image']!=[]:
      gHEMoONKPymCbRdrlGxupVWUqanJLX=gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['episode']['image'][0]['url']
     gHEMoONKPymCbRdrlGxupVWUqanJLk=gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['episode']['synopsis']['ko']
    else:
     gHEMoONKPymCbRdrlGxupVWUqanJLY =gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['program']['name']['ko']
     if gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['program']['image']!=[]:
      gHEMoONKPymCbRdrlGxupVWUqanJLX=gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['program']['image'][0]['url']
     gHEMoONKPymCbRdrlGxupVWUqanJLk=gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['program']['synopsis']['ko']
    gHEMoONKPymCbRdrlGxupVWUqanJLQ['title'] =gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['program']['name']['ko']
    gHEMoONKPymCbRdrlGxupVWUqanJLQ['studio'] =gHEMoONKPymCbRdrlGxupVWUqanJLc
    try:
     gHEMoONKPymCbRdrlGxupVWUqanJLi=[]
     for gHEMoONKPymCbRdrlGxupVWUqanJLA in gHEMoONKPymCbRdrlGxupVWUqanJIi.get('schedule').get('program').get('actor'):gHEMoONKPymCbRdrlGxupVWUqanJLi.append(gHEMoONKPymCbRdrlGxupVWUqanJLA)
     if gHEMoONKPymCbRdrlGxupVWUqanJLi[0]!='' and gHEMoONKPymCbRdrlGxupVWUqanJLi[0]!=u'없음':gHEMoONKPymCbRdrlGxupVWUqanJLQ['cast']=gHEMoONKPymCbRdrlGxupVWUqanJLi
    except:
     gHEMoONKPymCbRdrlGxupVWUqanJTs
    try:
     gHEMoONKPymCbRdrlGxupVWUqanJLB=[]
     if gHEMoONKPymCbRdrlGxupVWUqanJIi.get('schedule').get('program').get('category1_name').get('ko')!='':
      gHEMoONKPymCbRdrlGxupVWUqanJLB.append(gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['program']['category1_name']['ko'])
     if gHEMoONKPymCbRdrlGxupVWUqanJIi.get('schedule').get('program').get('category2_name').get('ko')!='':
      gHEMoONKPymCbRdrlGxupVWUqanJLB.append(gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['program']['category2_name']['ko'])
     if gHEMoONKPymCbRdrlGxupVWUqanJLB[0]!='':gHEMoONKPymCbRdrlGxupVWUqanJLQ['genre']=gHEMoONKPymCbRdrlGxupVWUqanJLB
    except:
     gHEMoONKPymCbRdrlGxupVWUqanJTs
    if gHEMoONKPymCbRdrlGxupVWUqanJLX=='':
     gHEMoONKPymCbRdrlGxupVWUqanJLX=gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['channel']['image'][0]['url']
    if gHEMoONKPymCbRdrlGxupVWUqanJLX!='':gHEMoONKPymCbRdrlGxupVWUqanJLX=gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJLX
    gHEMoONKPymCbRdrlGxupVWUqanJLj=gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['broadcast_start_time'])[8:12]
    gHEMoONKPymCbRdrlGxupVWUqanJLz =gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJIi['schedule']['broadcast_end_time'])[8:12]
    gHEMoONKPymCbRdrlGxupVWUqanJLF={'channel':gHEMoONKPymCbRdrlGxupVWUqanJLc,'title':gHEMoONKPymCbRdrlGxupVWUqanJLY,'mediacode':gHEMoONKPymCbRdrlGxupVWUqanJLD,'thumbnail':gHEMoONKPymCbRdrlGxupVWUqanJLX,'synopsis':gHEMoONKPymCbRdrlGxupVWUqanJLk,'channelepg':' [%s:%s ~ %s:%s]'%(gHEMoONKPymCbRdrlGxupVWUqanJLj[0:2],gHEMoONKPymCbRdrlGxupVWUqanJLj[2:],gHEMoONKPymCbRdrlGxupVWUqanJLz[0:2],gHEMoONKPymCbRdrlGxupVWUqanJLz[2:]),'info':gHEMoONKPymCbRdrlGxupVWUqanJLQ}
    gHEMoONKPymCbRdrlGxupVWUqanJLf.append(gHEMoONKPymCbRdrlGxupVWUqanJLF)
   if gHEMoONKPymCbRdrlGxupVWUqanJID['body']['has_more']=='Y':gHEMoONKPymCbRdrlGxupVWUqanJLt=gHEMoONKPymCbRdrlGxupVWUqanJTj
  except gHEMoONKPymCbRdrlGxupVWUqanJTD as exception:
   gHEMoONKPymCbRdrlGxupVWUqanJTY(exception)
  return gHEMoONKPymCbRdrlGxupVWUqanJLf,gHEMoONKPymCbRdrlGxupVWUqanJLt
 def GetProgramList(gHEMoONKPymCbRdrlGxupVWUqanJSh,genre,orderby,page_int,landyn=gHEMoONKPymCbRdrlGxupVWUqanJTw):
  gHEMoONKPymCbRdrlGxupVWUqanJLf=[]
  gHEMoONKPymCbRdrlGxupVWUqanJLt=gHEMoONKPymCbRdrlGxupVWUqanJTw
  try:
   gHEMoONKPymCbRdrlGxupVWUqanJIw ='/v2/media/episodes'
   gHEMoONKPymCbRdrlGxupVWUqanJIQ=gHEMoONKPymCbRdrlGxupVWUqanJSh.GetDefaultParams()
   gHEMoONKPymCbRdrlGxupVWUqanJIc={'pageNo':gHEMoONKPymCbRdrlGxupVWUqanJTX(page_int),'pageSize':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.GetNoCache(2))}
   if genre!='all':gHEMoONKPymCbRdrlGxupVWUqanJIc['multiCategoryCode']=genre
   gHEMoONKPymCbRdrlGxupVWUqanJIQ.update(gHEMoONKPymCbRdrlGxupVWUqanJIc)
   gHEMoONKPymCbRdrlGxupVWUqanJIj=gHEMoONKPymCbRdrlGxupVWUqanJSh.API_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIw
   gHEMoONKPymCbRdrlGxupVWUqanJSt=gHEMoONKPymCbRdrlGxupVWUqanJSh.makeDefaultCookies()
   gHEMoONKPymCbRdrlGxupVWUqanJSF=gHEMoONKPymCbRdrlGxupVWUqanJSh.callRequestCookies('Get',gHEMoONKPymCbRdrlGxupVWUqanJIj,payload=gHEMoONKPymCbRdrlGxupVWUqanJTs,params=gHEMoONKPymCbRdrlGxupVWUqanJIQ,headers=gHEMoONKPymCbRdrlGxupVWUqanJTs,cookies=gHEMoONKPymCbRdrlGxupVWUqanJSt)
   gHEMoONKPymCbRdrlGxupVWUqanJID=json.loads(gHEMoONKPymCbRdrlGxupVWUqanJSF.text)
   if not('result' in gHEMoONKPymCbRdrlGxupVWUqanJID['body']):return gHEMoONKPymCbRdrlGxupVWUqanJLf,gHEMoONKPymCbRdrlGxupVWUqanJLt
   gHEMoONKPymCbRdrlGxupVWUqanJLw=gHEMoONKPymCbRdrlGxupVWUqanJID['body']['result']
   for gHEMoONKPymCbRdrlGxupVWUqanJIi in gHEMoONKPymCbRdrlGxupVWUqanJLw:
    gHEMoONKPymCbRdrlGxupVWUqanJLv=gHEMoONKPymCbRdrlGxupVWUqanJIi['program']['code']
    gHEMoONKPymCbRdrlGxupVWUqanJLY =gHEMoONKPymCbRdrlGxupVWUqanJIi['program']['name']['ko']
    gHEMoONKPymCbRdrlGxupVWUqanJLX =gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIi['program']['image'][0]['url']
    gHEMoONKPymCbRdrlGxupVWUqanJLe='CAIP0200' if landyn else 'CAIP0900' 
    for gHEMoONKPymCbRdrlGxupVWUqanJhS in gHEMoONKPymCbRdrlGxupVWUqanJIi['program']['image']:
     if gHEMoONKPymCbRdrlGxupVWUqanJhS['code']==gHEMoONKPymCbRdrlGxupVWUqanJLe:
      gHEMoONKPymCbRdrlGxupVWUqanJLX =gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJhS['url']
      break
    gHEMoONKPymCbRdrlGxupVWUqanJLk =gHEMoONKPymCbRdrlGxupVWUqanJIi['program']['synopsis']['ko']
    gHEMoONKPymCbRdrlGxupVWUqanJhI=gHEMoONKPymCbRdrlGxupVWUqanJIi['program']['channel_code']
    gHEMoONKPymCbRdrlGxupVWUqanJLQ={}
    gHEMoONKPymCbRdrlGxupVWUqanJLQ['title'] =gHEMoONKPymCbRdrlGxupVWUqanJLY 
    gHEMoONKPymCbRdrlGxupVWUqanJLQ['mediatype']='episode' 
    try:
     gHEMoONKPymCbRdrlGxupVWUqanJLi=[]
     for gHEMoONKPymCbRdrlGxupVWUqanJLA in gHEMoONKPymCbRdrlGxupVWUqanJIi.get('program').get('actor'):gHEMoONKPymCbRdrlGxupVWUqanJLi.append(gHEMoONKPymCbRdrlGxupVWUqanJLA)
     if gHEMoONKPymCbRdrlGxupVWUqanJLi[0]!='' and gHEMoONKPymCbRdrlGxupVWUqanJLi[0]!='-':gHEMoONKPymCbRdrlGxupVWUqanJLQ['cast']=gHEMoONKPymCbRdrlGxupVWUqanJLi
    except:
     gHEMoONKPymCbRdrlGxupVWUqanJTs
    try:
     gHEMoONKPymCbRdrlGxupVWUqanJhL=[]
     for gHEMoONKPymCbRdrlGxupVWUqanJhT in gHEMoONKPymCbRdrlGxupVWUqanJIi.get('program').get('director'):gHEMoONKPymCbRdrlGxupVWUqanJhL.append(gHEMoONKPymCbRdrlGxupVWUqanJhT)
     if gHEMoONKPymCbRdrlGxupVWUqanJhL[0]!='' and gHEMoONKPymCbRdrlGxupVWUqanJhL[0]!='-':gHEMoONKPymCbRdrlGxupVWUqanJLQ['director']=gHEMoONKPymCbRdrlGxupVWUqanJhL
    except:
     gHEMoONKPymCbRdrlGxupVWUqanJTs
    gHEMoONKPymCbRdrlGxupVWUqanJLB=[]
    if gHEMoONKPymCbRdrlGxupVWUqanJIi.get('program').get('category1_name').get('ko')!='':
     gHEMoONKPymCbRdrlGxupVWUqanJLB.append(gHEMoONKPymCbRdrlGxupVWUqanJIi['program']['category1_name']['ko'])
    if gHEMoONKPymCbRdrlGxupVWUqanJIi.get('program').get('category2_name').get('ko')!='':
     gHEMoONKPymCbRdrlGxupVWUqanJLB.append(gHEMoONKPymCbRdrlGxupVWUqanJIi['program']['category2_name']['ko'])
    if gHEMoONKPymCbRdrlGxupVWUqanJLB[0]!='':gHEMoONKPymCbRdrlGxupVWUqanJLQ['genre']=gHEMoONKPymCbRdrlGxupVWUqanJLB
    try:
     if gHEMoONKPymCbRdrlGxupVWUqanJIi.get('program').get('product_year'):gHEMoONKPymCbRdrlGxupVWUqanJLQ['year']=gHEMoONKPymCbRdrlGxupVWUqanJIi['program']['product_year']
     if 'broad_dt' in gHEMoONKPymCbRdrlGxupVWUqanJIi.get('program'):
      gHEMoONKPymCbRdrlGxupVWUqanJhf=gHEMoONKPymCbRdrlGxupVWUqanJIi.get('program').get('broad_dt')
      gHEMoONKPymCbRdrlGxupVWUqanJLQ['aired']='%s-%s-%s'%(gHEMoONKPymCbRdrlGxupVWUqanJhf[:4],gHEMoONKPymCbRdrlGxupVWUqanJhf[4:6],gHEMoONKPymCbRdrlGxupVWUqanJhf[6:])
    except:
     gHEMoONKPymCbRdrlGxupVWUqanJTs
    gHEMoONKPymCbRdrlGxupVWUqanJLF={'program':gHEMoONKPymCbRdrlGxupVWUqanJLv,'title':gHEMoONKPymCbRdrlGxupVWUqanJLY,'thumbnail':gHEMoONKPymCbRdrlGxupVWUqanJLX,'synopsis':gHEMoONKPymCbRdrlGxupVWUqanJLk,'channel':gHEMoONKPymCbRdrlGxupVWUqanJhI,'info':gHEMoONKPymCbRdrlGxupVWUqanJLQ}
    gHEMoONKPymCbRdrlGxupVWUqanJLf.append(gHEMoONKPymCbRdrlGxupVWUqanJLF)
   if gHEMoONKPymCbRdrlGxupVWUqanJID['body']['has_more']=='Y':gHEMoONKPymCbRdrlGxupVWUqanJLt=gHEMoONKPymCbRdrlGxupVWUqanJTj
  except gHEMoONKPymCbRdrlGxupVWUqanJTD as exception:
   gHEMoONKPymCbRdrlGxupVWUqanJTY(exception)
  return gHEMoONKPymCbRdrlGxupVWUqanJLf,gHEMoONKPymCbRdrlGxupVWUqanJLt
 def GetEpisodoList(gHEMoONKPymCbRdrlGxupVWUqanJSh,program_code,page_int,orderby='desc'):
  gHEMoONKPymCbRdrlGxupVWUqanJLf=[]
  gHEMoONKPymCbRdrlGxupVWUqanJLt=gHEMoONKPymCbRdrlGxupVWUqanJTw
  try:
   gHEMoONKPymCbRdrlGxupVWUqanJIw ='/v2/media/frequency/program/'+program_code
   gHEMoONKPymCbRdrlGxupVWUqanJIQ=gHEMoONKPymCbRdrlGxupVWUqanJSh.GetDefaultParams()
   gHEMoONKPymCbRdrlGxupVWUqanJIc={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.GetNoCache(2))}
   gHEMoONKPymCbRdrlGxupVWUqanJIQ.update(gHEMoONKPymCbRdrlGxupVWUqanJIc)
   gHEMoONKPymCbRdrlGxupVWUqanJIj=gHEMoONKPymCbRdrlGxupVWUqanJSh.API_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIw
   gHEMoONKPymCbRdrlGxupVWUqanJSt=gHEMoONKPymCbRdrlGxupVWUqanJSh.makeDefaultCookies()
   gHEMoONKPymCbRdrlGxupVWUqanJSF=gHEMoONKPymCbRdrlGxupVWUqanJSh.callRequestCookies('Get',gHEMoONKPymCbRdrlGxupVWUqanJIj,payload=gHEMoONKPymCbRdrlGxupVWUqanJTs,params=gHEMoONKPymCbRdrlGxupVWUqanJIQ,headers=gHEMoONKPymCbRdrlGxupVWUqanJTs,cookies=gHEMoONKPymCbRdrlGxupVWUqanJSt)
   gHEMoONKPymCbRdrlGxupVWUqanJID=json.loads(gHEMoONKPymCbRdrlGxupVWUqanJSF.text)
   if not('result' in gHEMoONKPymCbRdrlGxupVWUqanJID['body']):return gHEMoONKPymCbRdrlGxupVWUqanJLf,gHEMoONKPymCbRdrlGxupVWUqanJLt
   gHEMoONKPymCbRdrlGxupVWUqanJLw=gHEMoONKPymCbRdrlGxupVWUqanJID['body']['result']
   gHEMoONKPymCbRdrlGxupVWUqanJht=gHEMoONKPymCbRdrlGxupVWUqanJTQ(gHEMoONKPymCbRdrlGxupVWUqanJID['body']['total_count'])
   gHEMoONKPymCbRdrlGxupVWUqanJhs =gHEMoONKPymCbRdrlGxupVWUqanJTQ(gHEMoONKPymCbRdrlGxupVWUqanJht//(gHEMoONKPymCbRdrlGxupVWUqanJSh.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    gHEMoONKPymCbRdrlGxupVWUqanJhw =(gHEMoONKPymCbRdrlGxupVWUqanJht-1)-((page_int-1)*gHEMoONKPymCbRdrlGxupVWUqanJSh.EPISODE_LIMIT)
   else:
    gHEMoONKPymCbRdrlGxupVWUqanJhw =(page_int-1)*gHEMoONKPymCbRdrlGxupVWUqanJSh.EPISODE_LIMIT
   for i in gHEMoONKPymCbRdrlGxupVWUqanJTc(gHEMoONKPymCbRdrlGxupVWUqanJSh.EPISODE_LIMIT):
    if orderby=='desc':
     gHEMoONKPymCbRdrlGxupVWUqanJhQ=gHEMoONKPymCbRdrlGxupVWUqanJhw-i
     if gHEMoONKPymCbRdrlGxupVWUqanJhQ<0:break
    else:
     gHEMoONKPymCbRdrlGxupVWUqanJhQ=gHEMoONKPymCbRdrlGxupVWUqanJhw+i
     if gHEMoONKPymCbRdrlGxupVWUqanJhQ>=gHEMoONKPymCbRdrlGxupVWUqanJht:break
    gHEMoONKPymCbRdrlGxupVWUqanJhc=gHEMoONKPymCbRdrlGxupVWUqanJLw[gHEMoONKPymCbRdrlGxupVWUqanJhQ]['episode']['code']
    gHEMoONKPymCbRdrlGxupVWUqanJLY =gHEMoONKPymCbRdrlGxupVWUqanJLw[gHEMoONKPymCbRdrlGxupVWUqanJhQ]['vod_name']['ko']
    gHEMoONKPymCbRdrlGxupVWUqanJhj =''
    try:
     gHEMoONKPymCbRdrlGxupVWUqanJhf=gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJLw[gHEMoONKPymCbRdrlGxupVWUqanJhQ]['episode']['broadcast_date'])
     gHEMoONKPymCbRdrlGxupVWUqanJhj='%s-%s-%s'%(gHEMoONKPymCbRdrlGxupVWUqanJhf[:4],gHEMoONKPymCbRdrlGxupVWUqanJhf[4:6],gHEMoONKPymCbRdrlGxupVWUqanJhf[6:])
    except:
     gHEMoONKPymCbRdrlGxupVWUqanJTs
    if gHEMoONKPymCbRdrlGxupVWUqanJLw[gHEMoONKPymCbRdrlGxupVWUqanJhQ]['episode']['image']!=[]:
     gHEMoONKPymCbRdrlGxupVWUqanJLX=gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJLw[gHEMoONKPymCbRdrlGxupVWUqanJhQ]['episode']['image'][0]['url']
    else:
     gHEMoONKPymCbRdrlGxupVWUqanJLX=gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJLw[gHEMoONKPymCbRdrlGxupVWUqanJhQ]['program']['image'][0]['url']
    gHEMoONKPymCbRdrlGxupVWUqanJLk =gHEMoONKPymCbRdrlGxupVWUqanJLw[gHEMoONKPymCbRdrlGxupVWUqanJhQ]['episode']['synopsis']['ko']
    gHEMoONKPymCbRdrlGxupVWUqanJLQ={}
    gHEMoONKPymCbRdrlGxupVWUqanJLQ['mediatype']='episode' 
    try:
     gHEMoONKPymCbRdrlGxupVWUqanJLQ['title'] =gHEMoONKPymCbRdrlGxupVWUqanJLw[gHEMoONKPymCbRdrlGxupVWUqanJhQ]['program']['name']['ko']
     gHEMoONKPymCbRdrlGxupVWUqanJLQ['aired'] =gHEMoONKPymCbRdrlGxupVWUqanJhj
     gHEMoONKPymCbRdrlGxupVWUqanJLQ['studio'] =gHEMoONKPymCbRdrlGxupVWUqanJLw[gHEMoONKPymCbRdrlGxupVWUqanJhQ]['channel']['name']['ko']
     if 'frequency' in gHEMoONKPymCbRdrlGxupVWUqanJLw[gHEMoONKPymCbRdrlGxupVWUqanJhQ]['episode']:gHEMoONKPymCbRdrlGxupVWUqanJLQ['episode']=gHEMoONKPymCbRdrlGxupVWUqanJLw[gHEMoONKPymCbRdrlGxupVWUqanJhQ]['episode']['frequency']
    except:
     gHEMoONKPymCbRdrlGxupVWUqanJTs
    gHEMoONKPymCbRdrlGxupVWUqanJLF={'episode':gHEMoONKPymCbRdrlGxupVWUqanJhc,'title':gHEMoONKPymCbRdrlGxupVWUqanJLY,'subtitle':gHEMoONKPymCbRdrlGxupVWUqanJhj,'thumbnail':gHEMoONKPymCbRdrlGxupVWUqanJLX,'synopsis':gHEMoONKPymCbRdrlGxupVWUqanJLk,'info':gHEMoONKPymCbRdrlGxupVWUqanJLQ}
    gHEMoONKPymCbRdrlGxupVWUqanJLf.append(gHEMoONKPymCbRdrlGxupVWUqanJLF)
   if gHEMoONKPymCbRdrlGxupVWUqanJhs>page_int:gHEMoONKPymCbRdrlGxupVWUqanJLt=gHEMoONKPymCbRdrlGxupVWUqanJTj
  except gHEMoONKPymCbRdrlGxupVWUqanJTD as exception:
   gHEMoONKPymCbRdrlGxupVWUqanJTY(exception)
  return gHEMoONKPymCbRdrlGxupVWUqanJLf,gHEMoONKPymCbRdrlGxupVWUqanJLt,gHEMoONKPymCbRdrlGxupVWUqanJhs
 def GetMovieList(gHEMoONKPymCbRdrlGxupVWUqanJSh,genre,orderby,page_int,landyn=gHEMoONKPymCbRdrlGxupVWUqanJTw):
  gHEMoONKPymCbRdrlGxupVWUqanJLf=[]
  gHEMoONKPymCbRdrlGxupVWUqanJLt=gHEMoONKPymCbRdrlGxupVWUqanJTw
  try:
   gHEMoONKPymCbRdrlGxupVWUqanJIw ='/v2/media/movies'
   gHEMoONKPymCbRdrlGxupVWUqanJIQ=gHEMoONKPymCbRdrlGxupVWUqanJSh.GetDefaultParams()
   gHEMoONKPymCbRdrlGxupVWUqanJIc={'pageNo':gHEMoONKPymCbRdrlGxupVWUqanJTX(page_int),'pageSize':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.GetNoCache(2))}
   if genre!='all':gHEMoONKPymCbRdrlGxupVWUqanJIc['multiCategoryCode']=genre
   gHEMoONKPymCbRdrlGxupVWUqanJIQ.update(gHEMoONKPymCbRdrlGxupVWUqanJIc)
   gHEMoONKPymCbRdrlGxupVWUqanJIj=gHEMoONKPymCbRdrlGxupVWUqanJSh.API_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIw
   gHEMoONKPymCbRdrlGxupVWUqanJSt=gHEMoONKPymCbRdrlGxupVWUqanJSh.makeDefaultCookies()
   gHEMoONKPymCbRdrlGxupVWUqanJSF=gHEMoONKPymCbRdrlGxupVWUqanJSh.callRequestCookies('Get',gHEMoONKPymCbRdrlGxupVWUqanJIj,payload=gHEMoONKPymCbRdrlGxupVWUqanJTs,params=gHEMoONKPymCbRdrlGxupVWUqanJIQ,headers=gHEMoONKPymCbRdrlGxupVWUqanJTs,cookies=gHEMoONKPymCbRdrlGxupVWUqanJSt)
   gHEMoONKPymCbRdrlGxupVWUqanJID=json.loads(gHEMoONKPymCbRdrlGxupVWUqanJSF.text)
   if not('result' in gHEMoONKPymCbRdrlGxupVWUqanJID['body']):return gHEMoONKPymCbRdrlGxupVWUqanJLf,gHEMoONKPymCbRdrlGxupVWUqanJLt
   gHEMoONKPymCbRdrlGxupVWUqanJLw=gHEMoONKPymCbRdrlGxupVWUqanJID['body']['result']
   for gHEMoONKPymCbRdrlGxupVWUqanJIi in gHEMoONKPymCbRdrlGxupVWUqanJLw:
    gHEMoONKPymCbRdrlGxupVWUqanJhD =gHEMoONKPymCbRdrlGxupVWUqanJIi['movie']['code']
    gHEMoONKPymCbRdrlGxupVWUqanJLY =gHEMoONKPymCbRdrlGxupVWUqanJIi['movie']['name']['ko'].strip()
    gHEMoONKPymCbRdrlGxupVWUqanJLY +=u' (%s년)'%(gHEMoONKPymCbRdrlGxupVWUqanJIi.get('movie').get('product_year'))
    gHEMoONKPymCbRdrlGxupVWUqanJLX =gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIi['movie']['image'][0]['url']
    gHEMoONKPymCbRdrlGxupVWUqanJLe='CAIM0400' if landyn else 'CAIM2100' 
    for gHEMoONKPymCbRdrlGxupVWUqanJhS in gHEMoONKPymCbRdrlGxupVWUqanJIi['movie']['image']:
     if gHEMoONKPymCbRdrlGxupVWUqanJhS['code']==gHEMoONKPymCbRdrlGxupVWUqanJLe:
      gHEMoONKPymCbRdrlGxupVWUqanJLX =gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJhS['url']
      break
    gHEMoONKPymCbRdrlGxupVWUqanJLk =gHEMoONKPymCbRdrlGxupVWUqanJIi['movie']['story']['ko']
    gHEMoONKPymCbRdrlGxupVWUqanJLQ={}
    gHEMoONKPymCbRdrlGxupVWUqanJLQ['mediatype']='movie' 
    gHEMoONKPymCbRdrlGxupVWUqanJLQ['title'] = gHEMoONKPymCbRdrlGxupVWUqanJIi['movie']['name']['ko'].strip()
    gHEMoONKPymCbRdrlGxupVWUqanJLQ['year'] =gHEMoONKPymCbRdrlGxupVWUqanJIi.get('movie').get('product_year')
    try:
     gHEMoONKPymCbRdrlGxupVWUqanJLi=[]
     for gHEMoONKPymCbRdrlGxupVWUqanJLA in gHEMoONKPymCbRdrlGxupVWUqanJIi.get('movie').get('actor'):gHEMoONKPymCbRdrlGxupVWUqanJLi.append(gHEMoONKPymCbRdrlGxupVWUqanJLA)
     if gHEMoONKPymCbRdrlGxupVWUqanJLi[0]!='':gHEMoONKPymCbRdrlGxupVWUqanJLQ['cast']=gHEMoONKPymCbRdrlGxupVWUqanJLi
    except:
     gHEMoONKPymCbRdrlGxupVWUqanJTs
    try:
     gHEMoONKPymCbRdrlGxupVWUqanJhL=[]
     for gHEMoONKPymCbRdrlGxupVWUqanJhT in gHEMoONKPymCbRdrlGxupVWUqanJIi.get('movie').get('director'):gHEMoONKPymCbRdrlGxupVWUqanJhL.append(gHEMoONKPymCbRdrlGxupVWUqanJhT)
     if gHEMoONKPymCbRdrlGxupVWUqanJhL[0]!='':gHEMoONKPymCbRdrlGxupVWUqanJLQ['director']=gHEMoONKPymCbRdrlGxupVWUqanJhL
    except:
     gHEMoONKPymCbRdrlGxupVWUqanJTs
    try:
     gHEMoONKPymCbRdrlGxupVWUqanJLB=[]
     if gHEMoONKPymCbRdrlGxupVWUqanJIi.get('movie').get('category1_name').get('ko')!='':
      gHEMoONKPymCbRdrlGxupVWUqanJLB.append(gHEMoONKPymCbRdrlGxupVWUqanJIi['movie']['category1_name']['ko'])
     if gHEMoONKPymCbRdrlGxupVWUqanJIi.get('movie').get('category2_name').get('ko')!='':
      gHEMoONKPymCbRdrlGxupVWUqanJLB.append(gHEMoONKPymCbRdrlGxupVWUqanJIi['movie']['category2_name']['ko'])
     if gHEMoONKPymCbRdrlGxupVWUqanJLB[0]!='':gHEMoONKPymCbRdrlGxupVWUqanJLQ['genre']=gHEMoONKPymCbRdrlGxupVWUqanJLB
    except:
     gHEMoONKPymCbRdrlGxupVWUqanJTs
    try:
     if 'release_date' in gHEMoONKPymCbRdrlGxupVWUqanJIi.get('movie'):
      gHEMoONKPymCbRdrlGxupVWUqanJhf=gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJIi.get('movie').get('release_date'))
      gHEMoONKPymCbRdrlGxupVWUqanJLQ['aired']='%s-%s-%s'%(gHEMoONKPymCbRdrlGxupVWUqanJhf[:4],gHEMoONKPymCbRdrlGxupVWUqanJhf[4:6],gHEMoONKPymCbRdrlGxupVWUqanJhf[6:])
    except:
     gHEMoONKPymCbRdrlGxupVWUqanJTs
    try:
     if 'duration' in gHEMoONKPymCbRdrlGxupVWUqanJIi.get('movie'):gHEMoONKPymCbRdrlGxupVWUqanJLQ['duration']=gHEMoONKPymCbRdrlGxupVWUqanJIi.get('movie').get('duration')
    except:
     gHEMoONKPymCbRdrlGxupVWUqanJTs
    gHEMoONKPymCbRdrlGxupVWUqanJLF={'moviecode':gHEMoONKPymCbRdrlGxupVWUqanJhD,'title':gHEMoONKPymCbRdrlGxupVWUqanJLY,'thumbnail':gHEMoONKPymCbRdrlGxupVWUqanJLX,'synopsis':gHEMoONKPymCbRdrlGxupVWUqanJLk,'info':gHEMoONKPymCbRdrlGxupVWUqanJLQ}
    gHEMoONKPymCbRdrlGxupVWUqanJhY=gHEMoONKPymCbRdrlGxupVWUqanJTw
    for gHEMoONKPymCbRdrlGxupVWUqanJhX in gHEMoONKPymCbRdrlGxupVWUqanJIi['billing_package_id']:
     if gHEMoONKPymCbRdrlGxupVWUqanJhX in gHEMoONKPymCbRdrlGxupVWUqanJSh.MOVIE_LITE:
      gHEMoONKPymCbRdrlGxupVWUqanJhY=gHEMoONKPymCbRdrlGxupVWUqanJTj
      break
    if gHEMoONKPymCbRdrlGxupVWUqanJhY==gHEMoONKPymCbRdrlGxupVWUqanJTw: 
     gHEMoONKPymCbRdrlGxupVWUqanJLF['title']=gHEMoONKPymCbRdrlGxupVWUqanJLF['title']+' [개별구매]'
    gHEMoONKPymCbRdrlGxupVWUqanJLf.append(gHEMoONKPymCbRdrlGxupVWUqanJLF)
   if gHEMoONKPymCbRdrlGxupVWUqanJID['body']['has_more']=='Y':gHEMoONKPymCbRdrlGxupVWUqanJLt=gHEMoONKPymCbRdrlGxupVWUqanJTj
  except gHEMoONKPymCbRdrlGxupVWUqanJTD as exception:
   gHEMoONKPymCbRdrlGxupVWUqanJTY(exception)
  return gHEMoONKPymCbRdrlGxupVWUqanJLf,gHEMoONKPymCbRdrlGxupVWUqanJLt
 def GetMovieListGenre(gHEMoONKPymCbRdrlGxupVWUqanJSh,genre,page_int):
  gHEMoONKPymCbRdrlGxupVWUqanJLf=[]
  gHEMoONKPymCbRdrlGxupVWUqanJLt=gHEMoONKPymCbRdrlGxupVWUqanJTw
  try:
   gHEMoONKPymCbRdrlGxupVWUqanJIw ='/v2/media/movie/curation/'+genre
   gHEMoONKPymCbRdrlGxupVWUqanJIQ=gHEMoONKPymCbRdrlGxupVWUqanJSh.GetDefaultParams()
   gHEMoONKPymCbRdrlGxupVWUqanJIc={'pageNo':gHEMoONKPymCbRdrlGxupVWUqanJTX(page_int),'pageSize':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.MOVIE_LIMIT),'_':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.GetNoCache(2))}
   gHEMoONKPymCbRdrlGxupVWUqanJIQ.update(gHEMoONKPymCbRdrlGxupVWUqanJIc)
   gHEMoONKPymCbRdrlGxupVWUqanJIj=gHEMoONKPymCbRdrlGxupVWUqanJSh.API_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIw
   gHEMoONKPymCbRdrlGxupVWUqanJSt=gHEMoONKPymCbRdrlGxupVWUqanJSh.makeDefaultCookies()
   gHEMoONKPymCbRdrlGxupVWUqanJSF=gHEMoONKPymCbRdrlGxupVWUqanJSh.callRequestCookies('Get',gHEMoONKPymCbRdrlGxupVWUqanJIj,payload=gHEMoONKPymCbRdrlGxupVWUqanJTs,params=gHEMoONKPymCbRdrlGxupVWUqanJIQ,headers=gHEMoONKPymCbRdrlGxupVWUqanJTs,cookies=gHEMoONKPymCbRdrlGxupVWUqanJSt)
   gHEMoONKPymCbRdrlGxupVWUqanJID=json.loads(gHEMoONKPymCbRdrlGxupVWUqanJSF.text)
   if not('movies' in gHEMoONKPymCbRdrlGxupVWUqanJID['body']):return gHEMoONKPymCbRdrlGxupVWUqanJLf,gHEMoONKPymCbRdrlGxupVWUqanJLt
   gHEMoONKPymCbRdrlGxupVWUqanJLw=gHEMoONKPymCbRdrlGxupVWUqanJID['body']['movies']
   for gHEMoONKPymCbRdrlGxupVWUqanJIi in gHEMoONKPymCbRdrlGxupVWUqanJLw:
    gHEMoONKPymCbRdrlGxupVWUqanJhD =gHEMoONKPymCbRdrlGxupVWUqanJIi['code']
    gHEMoONKPymCbRdrlGxupVWUqanJLY =gHEMoONKPymCbRdrlGxupVWUqanJIi['name']['ko']
    gHEMoONKPymCbRdrlGxupVWUqanJLX =gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIi['image'][0]['url']
    for gHEMoONKPymCbRdrlGxupVWUqanJhS in gHEMoONKPymCbRdrlGxupVWUqanJIi['image']:
     if gHEMoONKPymCbRdrlGxupVWUqanJhS['code']=='CAIM2100':
      gHEMoONKPymCbRdrlGxupVWUqanJLX =gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJhS['url']
    gHEMoONKPymCbRdrlGxupVWUqanJLk =gHEMoONKPymCbRdrlGxupVWUqanJIi['story']['ko']
    gHEMoONKPymCbRdrlGxupVWUqanJLF={'moviecode':gHEMoONKPymCbRdrlGxupVWUqanJhD,'title':gHEMoONKPymCbRdrlGxupVWUqanJLY.strip(),'thumbnail':gHEMoONKPymCbRdrlGxupVWUqanJLX,'synopsis':gHEMoONKPymCbRdrlGxupVWUqanJLk}
    gHEMoONKPymCbRdrlGxupVWUqanJLf.append(gHEMoONKPymCbRdrlGxupVWUqanJLF)
  except gHEMoONKPymCbRdrlGxupVWUqanJTD as exception:
   gHEMoONKPymCbRdrlGxupVWUqanJTY(exception)
  return gHEMoONKPymCbRdrlGxupVWUqanJLf,gHEMoONKPymCbRdrlGxupVWUqanJLt
 def GetMovieGenre(gHEMoONKPymCbRdrlGxupVWUqanJSh):
  gHEMoONKPymCbRdrlGxupVWUqanJLf=[]
  gHEMoONKPymCbRdrlGxupVWUqanJLt=gHEMoONKPymCbRdrlGxupVWUqanJTw
  try:
   gHEMoONKPymCbRdrlGxupVWUqanJIw ='/v2/media/movie/curations'
   gHEMoONKPymCbRdrlGxupVWUqanJIQ=gHEMoONKPymCbRdrlGxupVWUqanJSh.GetDefaultParams()
   gHEMoONKPymCbRdrlGxupVWUqanJIc={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.GetNoCache(2))}
   gHEMoONKPymCbRdrlGxupVWUqanJIQ.update(gHEMoONKPymCbRdrlGxupVWUqanJIc)
   gHEMoONKPymCbRdrlGxupVWUqanJIj=gHEMoONKPymCbRdrlGxupVWUqanJSh.API_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIw
   gHEMoONKPymCbRdrlGxupVWUqanJSt=gHEMoONKPymCbRdrlGxupVWUqanJSh.makeDefaultCookies()
   gHEMoONKPymCbRdrlGxupVWUqanJSF=gHEMoONKPymCbRdrlGxupVWUqanJSh.callRequestCookies('Get',gHEMoONKPymCbRdrlGxupVWUqanJIj,payload=gHEMoONKPymCbRdrlGxupVWUqanJTs,params=gHEMoONKPymCbRdrlGxupVWUqanJIQ,headers=gHEMoONKPymCbRdrlGxupVWUqanJTs,cookies=gHEMoONKPymCbRdrlGxupVWUqanJSt)
   gHEMoONKPymCbRdrlGxupVWUqanJID=json.loads(gHEMoONKPymCbRdrlGxupVWUqanJSF.text)
   if not('result' in gHEMoONKPymCbRdrlGxupVWUqanJID['body']):return gHEMoONKPymCbRdrlGxupVWUqanJLf,gHEMoONKPymCbRdrlGxupVWUqanJLt
   gHEMoONKPymCbRdrlGxupVWUqanJLw=gHEMoONKPymCbRdrlGxupVWUqanJID['body']['result']
   for gHEMoONKPymCbRdrlGxupVWUqanJIi in gHEMoONKPymCbRdrlGxupVWUqanJLw:
    gHEMoONKPymCbRdrlGxupVWUqanJhk =gHEMoONKPymCbRdrlGxupVWUqanJIi['curation_code']
    gHEMoONKPymCbRdrlGxupVWUqanJhi =gHEMoONKPymCbRdrlGxupVWUqanJIi['curation_name']
    gHEMoONKPymCbRdrlGxupVWUqanJLF={'curation_code':gHEMoONKPymCbRdrlGxupVWUqanJhk,'curation_name':gHEMoONKPymCbRdrlGxupVWUqanJhi}
    gHEMoONKPymCbRdrlGxupVWUqanJLf.append(gHEMoONKPymCbRdrlGxupVWUqanJLF)
  except gHEMoONKPymCbRdrlGxupVWUqanJTD as exception:
   gHEMoONKPymCbRdrlGxupVWUqanJTY(exception)
  return gHEMoONKPymCbRdrlGxupVWUqanJLf,gHEMoONKPymCbRdrlGxupVWUqanJLt
 def GetSearchList(gHEMoONKPymCbRdrlGxupVWUqanJSh,search_key,userid,page_int,stype,landyn=gHEMoONKPymCbRdrlGxupVWUqanJTw):
  gHEMoONKPymCbRdrlGxupVWUqanJhA=[]
  gHEMoONKPymCbRdrlGxupVWUqanJLt=gHEMoONKPymCbRdrlGxupVWUqanJTw
  try:
   gHEMoONKPymCbRdrlGxupVWUqanJIw ='/search/getSearch.jsp'
   gHEMoONKPymCbRdrlGxupVWUqanJIc={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':gHEMoONKPymCbRdrlGxupVWUqanJTX(page_int),'pageSize':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':gHEMoONKPymCbRdrlGxupVWUqanJSh.SCREENCODE,'os':gHEMoONKPymCbRdrlGxupVWUqanJSh.OSCODE,'network':gHEMoONKPymCbRdrlGxupVWUqanJSh.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.SEARCH_LIMIT),'vodMVReqCnt':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':gHEMoONKPymCbRdrlGxupVWUqanJTX(gHEMoONKPymCbRdrlGxupVWUqanJSh.GetNoCache(2))}
   gHEMoONKPymCbRdrlGxupVWUqanJIj=gHEMoONKPymCbRdrlGxupVWUqanJSh.SEARCH_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIw
   gHEMoONKPymCbRdrlGxupVWUqanJSt=gHEMoONKPymCbRdrlGxupVWUqanJSh.makeDefaultCookies()
   gHEMoONKPymCbRdrlGxupVWUqanJSF=gHEMoONKPymCbRdrlGxupVWUqanJSh.callRequestCookies('Get',gHEMoONKPymCbRdrlGxupVWUqanJIj,payload=gHEMoONKPymCbRdrlGxupVWUqanJTs,params=gHEMoONKPymCbRdrlGxupVWUqanJIc,headers=gHEMoONKPymCbRdrlGxupVWUqanJTs,cookies=gHEMoONKPymCbRdrlGxupVWUqanJSt)
   gHEMoONKPymCbRdrlGxupVWUqanJID=json.loads(gHEMoONKPymCbRdrlGxupVWUqanJSF.text)
   if stype=='vod':
    if not('programRsb' in gHEMoONKPymCbRdrlGxupVWUqanJID):return gHEMoONKPymCbRdrlGxupVWUqanJhA,gHEMoONKPymCbRdrlGxupVWUqanJLt
    gHEMoONKPymCbRdrlGxupVWUqanJhB=gHEMoONKPymCbRdrlGxupVWUqanJID['programRsb']['dataList']
    gHEMoONKPymCbRdrlGxupVWUqanJhz =gHEMoONKPymCbRdrlGxupVWUqanJTQ(gHEMoONKPymCbRdrlGxupVWUqanJID['programRsb']['count'])
    for gHEMoONKPymCbRdrlGxupVWUqanJIi in gHEMoONKPymCbRdrlGxupVWUqanJhB:
     gHEMoONKPymCbRdrlGxupVWUqanJLv=gHEMoONKPymCbRdrlGxupVWUqanJIi['mast_cd']
     gHEMoONKPymCbRdrlGxupVWUqanJLY =gHEMoONKPymCbRdrlGxupVWUqanJIi['mast_nm']
     gHEMoONKPymCbRdrlGxupVWUqanJLX =gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIi['web_url']
     if landyn==gHEMoONKPymCbRdrlGxupVWUqanJTw:
      gHEMoONKPymCbRdrlGxupVWUqanJLX =gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIi['web_url4']
     gHEMoONKPymCbRdrlGxupVWUqanJLQ={}
     gHEMoONKPymCbRdrlGxupVWUqanJLQ['title']=gHEMoONKPymCbRdrlGxupVWUqanJIi['mast_nm']
     gHEMoONKPymCbRdrlGxupVWUqanJLQ['mediatype']='episode' 
     try:
      if gHEMoONKPymCbRdrlGxupVWUqanJIi.get('actor')!='' and gHEMoONKPymCbRdrlGxupVWUqanJIi.get('actor')!='-':gHEMoONKPymCbRdrlGxupVWUqanJLQ['cast'] =gHEMoONKPymCbRdrlGxupVWUqanJIi.get('actor').split(',')
      if gHEMoONKPymCbRdrlGxupVWUqanJIi.get('director')!='' and gHEMoONKPymCbRdrlGxupVWUqanJIi.get('director')!='-':gHEMoONKPymCbRdrlGxupVWUqanJLQ['director']=gHEMoONKPymCbRdrlGxupVWUqanJIi.get('director').split(',')
      if gHEMoONKPymCbRdrlGxupVWUqanJIi.get('cate_nm')!='':gHEMoONKPymCbRdrlGxupVWUqanJLQ['genre'] =gHEMoONKPymCbRdrlGxupVWUqanJIi.get('cate_nm').split('/')
      if 'targetage' in gHEMoONKPymCbRdrlGxupVWUqanJIi:gHEMoONKPymCbRdrlGxupVWUqanJLQ['mpaa']=gHEMoONKPymCbRdrlGxupVWUqanJIi.get('targetage')
     except:
      gHEMoONKPymCbRdrlGxupVWUqanJTs
     try:
      if 'broad_dt' in gHEMoONKPymCbRdrlGxupVWUqanJIi:
       gHEMoONKPymCbRdrlGxupVWUqanJhf=gHEMoONKPymCbRdrlGxupVWUqanJIi.get('broad_dt')
       gHEMoONKPymCbRdrlGxupVWUqanJLQ['aired']='%s-%s-%s'%(gHEMoONKPymCbRdrlGxupVWUqanJhf[:4],gHEMoONKPymCbRdrlGxupVWUqanJhf[4:6],gHEMoONKPymCbRdrlGxupVWUqanJhf[6:])
     except:
      gHEMoONKPymCbRdrlGxupVWUqanJTs
     gHEMoONKPymCbRdrlGxupVWUqanJLF={'program':gHEMoONKPymCbRdrlGxupVWUqanJLv,'title':gHEMoONKPymCbRdrlGxupVWUqanJLY,'thumbnail':gHEMoONKPymCbRdrlGxupVWUqanJLX,'synopsis':'','info':gHEMoONKPymCbRdrlGxupVWUqanJLQ}
     gHEMoONKPymCbRdrlGxupVWUqanJhA.append(gHEMoONKPymCbRdrlGxupVWUqanJLF)
   else:
    if not('vodMVRsb' in gHEMoONKPymCbRdrlGxupVWUqanJID):return gHEMoONKPymCbRdrlGxupVWUqanJhA,gHEMoONKPymCbRdrlGxupVWUqanJLt
    gHEMoONKPymCbRdrlGxupVWUqanJhF=gHEMoONKPymCbRdrlGxupVWUqanJID['vodMVRsb']['dataList']
    gHEMoONKPymCbRdrlGxupVWUqanJhz =gHEMoONKPymCbRdrlGxupVWUqanJTQ(gHEMoONKPymCbRdrlGxupVWUqanJID['vodMVRsb']['count'])
    for gHEMoONKPymCbRdrlGxupVWUqanJIi in gHEMoONKPymCbRdrlGxupVWUqanJhF:
     gHEMoONKPymCbRdrlGxupVWUqanJLv=gHEMoONKPymCbRdrlGxupVWUqanJIi['mast_cd']
     gHEMoONKPymCbRdrlGxupVWUqanJLY =gHEMoONKPymCbRdrlGxupVWUqanJIi['mast_nm'].strip()
     gHEMoONKPymCbRdrlGxupVWUqanJLX =gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIi['web_url']
     if landyn==gHEMoONKPymCbRdrlGxupVWUqanJTw:
      gHEMoONKPymCbRdrlGxupVWUqanJLX =gHEMoONKPymCbRdrlGxupVWUqanJSh.IMG_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIi['web_url5']
     gHEMoONKPymCbRdrlGxupVWUqanJLQ={}
     gHEMoONKPymCbRdrlGxupVWUqanJLQ['title'] =gHEMoONKPymCbRdrlGxupVWUqanJLY
     gHEMoONKPymCbRdrlGxupVWUqanJLQ['mediatype']='movie' 
     try:
      if gHEMoONKPymCbRdrlGxupVWUqanJIi.get('actor') !='':gHEMoONKPymCbRdrlGxupVWUqanJLQ['cast'] =gHEMoONKPymCbRdrlGxupVWUqanJIi.get('actor').split(',')
      if gHEMoONKPymCbRdrlGxupVWUqanJIi.get('cate_nm')!='':gHEMoONKPymCbRdrlGxupVWUqanJLQ['genre'] =gHEMoONKPymCbRdrlGxupVWUqanJIi.get('cate_nm').split('/')
      if gHEMoONKPymCbRdrlGxupVWUqanJIi.get('runtime_sec')!='':gHEMoONKPymCbRdrlGxupVWUqanJLQ['duration']=gHEMoONKPymCbRdrlGxupVWUqanJIi.get('runtime_sec')
      if 'grade_nm' in gHEMoONKPymCbRdrlGxupVWUqanJIi:gHEMoONKPymCbRdrlGxupVWUqanJLQ['mpaa']=gHEMoONKPymCbRdrlGxupVWUqanJIi.get('grade_nm')
     except:
      gHEMoONKPymCbRdrlGxupVWUqanJTs
     try:
      gHEMoONKPymCbRdrlGxupVWUqanJhf=gHEMoONKPymCbRdrlGxupVWUqanJIi.get('broad_dt')
      if data_str!='':
       gHEMoONKPymCbRdrlGxupVWUqanJLQ['aired']='%s-%s-%s'%(gHEMoONKPymCbRdrlGxupVWUqanJhf[:4],gHEMoONKPymCbRdrlGxupVWUqanJhf[4:6],gHEMoONKPymCbRdrlGxupVWUqanJhf[6:])
       gHEMoONKPymCbRdrlGxupVWUqanJLQ['year']=gHEMoONKPymCbRdrlGxupVWUqanJhf[:4]
     except:
      gHEMoONKPymCbRdrlGxupVWUqanJTs
     gHEMoONKPymCbRdrlGxupVWUqanJLF={'movie':gHEMoONKPymCbRdrlGxupVWUqanJLv,'title':gHEMoONKPymCbRdrlGxupVWUqanJLY,'thumbnail':gHEMoONKPymCbRdrlGxupVWUqanJLX,'synopsis':'','info':gHEMoONKPymCbRdrlGxupVWUqanJLQ}
     gHEMoONKPymCbRdrlGxupVWUqanJhY=gHEMoONKPymCbRdrlGxupVWUqanJTw
     for gHEMoONKPymCbRdrlGxupVWUqanJhX in gHEMoONKPymCbRdrlGxupVWUqanJIi['bill']:
      if gHEMoONKPymCbRdrlGxupVWUqanJhX in gHEMoONKPymCbRdrlGxupVWUqanJSh.MOVIE_LITE:
       gHEMoONKPymCbRdrlGxupVWUqanJhY=gHEMoONKPymCbRdrlGxupVWUqanJTj
       break
     if gHEMoONKPymCbRdrlGxupVWUqanJhY==gHEMoONKPymCbRdrlGxupVWUqanJTw: 
      gHEMoONKPymCbRdrlGxupVWUqanJLF['title']=gHEMoONKPymCbRdrlGxupVWUqanJLF['title']+' [개별구매]'
     gHEMoONKPymCbRdrlGxupVWUqanJhA.append(gHEMoONKPymCbRdrlGxupVWUqanJLF)
  except gHEMoONKPymCbRdrlGxupVWUqanJTD as exception:
   gHEMoONKPymCbRdrlGxupVWUqanJTY(exception)
  return gHEMoONKPymCbRdrlGxupVWUqanJhA,gHEMoONKPymCbRdrlGxupVWUqanJLt
 def GetDeviceList(gHEMoONKPymCbRdrlGxupVWUqanJSh,gHEMoONKPymCbRdrlGxupVWUqanJSe,gHEMoONKPymCbRdrlGxupVWUqanJIS):
  gHEMoONKPymCbRdrlGxupVWUqanJLf=[]
  gHEMoONKPymCbRdrlGxupVWUqanJIs='-'
  try:
   gHEMoONKPymCbRdrlGxupVWUqanJIw ='/v1/user/device/list'
   gHEMoONKPymCbRdrlGxupVWUqanJhv=gHEMoONKPymCbRdrlGxupVWUqanJSh.API_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIw
   gHEMoONKPymCbRdrlGxupVWUqanJIc={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   gHEMoONKPymCbRdrlGxupVWUqanJSt=gHEMoONKPymCbRdrlGxupVWUqanJSh.makeDefaultCookies(vToken=gHEMoONKPymCbRdrlGxupVWUqanJSe,vUserinfo=gHEMoONKPymCbRdrlGxupVWUqanJIS)
   gHEMoONKPymCbRdrlGxupVWUqanJSF=gHEMoONKPymCbRdrlGxupVWUqanJSh.callRequestCookies('Get',gHEMoONKPymCbRdrlGxupVWUqanJhv,payload=gHEMoONKPymCbRdrlGxupVWUqanJTs,params=gHEMoONKPymCbRdrlGxupVWUqanJIc,headers=gHEMoONKPymCbRdrlGxupVWUqanJTs,cookies=gHEMoONKPymCbRdrlGxupVWUqanJSt)
   gHEMoONKPymCbRdrlGxupVWUqanJID=json.loads(gHEMoONKPymCbRdrlGxupVWUqanJSF.text)
   gHEMoONKPymCbRdrlGxupVWUqanJLf=gHEMoONKPymCbRdrlGxupVWUqanJID['body']
   for gHEMoONKPymCbRdrlGxupVWUqanJIi in gHEMoONKPymCbRdrlGxupVWUqanJLf:
    if gHEMoONKPymCbRdrlGxupVWUqanJIi['model']=='PC':
     gHEMoONKPymCbRdrlGxupVWUqanJIs=gHEMoONKPymCbRdrlGxupVWUqanJIi['uuid']
  except gHEMoONKPymCbRdrlGxupVWUqanJTD as exception:
   gHEMoONKPymCbRdrlGxupVWUqanJTY(exception)
  return gHEMoONKPymCbRdrlGxupVWUqanJIs
 def GetProfileToken(gHEMoONKPymCbRdrlGxupVWUqanJSh,gHEMoONKPymCbRdrlGxupVWUqanJSe,gHEMoONKPymCbRdrlGxupVWUqanJIS,user_pf):
  gHEMoONKPymCbRdrlGxupVWUqanJhe=[]
  gHEMoONKPymCbRdrlGxupVWUqanJTS =''
  gHEMoONKPymCbRdrlGxupVWUqanJTI =''
  gHEMoONKPymCbRdrlGxupVWUqanJTL='Y'
  gHEMoONKPymCbRdrlGxupVWUqanJTh ='N'
  try:
   gHEMoONKPymCbRdrlGxupVWUqanJIw ='/profile/select.do'
   gHEMoONKPymCbRdrlGxupVWUqanJhv=gHEMoONKPymCbRdrlGxupVWUqanJSh.URL_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIw
   gHEMoONKPymCbRdrlGxupVWUqanJSt=gHEMoONKPymCbRdrlGxupVWUqanJSh.makeDefaultCookies(vToken=gHEMoONKPymCbRdrlGxupVWUqanJSe,vUserinfo=gHEMoONKPymCbRdrlGxupVWUqanJIS)
   gHEMoONKPymCbRdrlGxupVWUqanJSF=gHEMoONKPymCbRdrlGxupVWUqanJSh.callRequestCookies('Get',gHEMoONKPymCbRdrlGxupVWUqanJhv,payload=gHEMoONKPymCbRdrlGxupVWUqanJTs,params=gHEMoONKPymCbRdrlGxupVWUqanJTs,headers=gHEMoONKPymCbRdrlGxupVWUqanJTs,cookies=gHEMoONKPymCbRdrlGxupVWUqanJSt)
   gHEMoONKPymCbRdrlGxupVWUqanJhe =re.findall('data-profile-no="\d{9}"',gHEMoONKPymCbRdrlGxupVWUqanJSF.text)
   for i in gHEMoONKPymCbRdrlGxupVWUqanJTc(gHEMoONKPymCbRdrlGxupVWUqanJTi(gHEMoONKPymCbRdrlGxupVWUqanJhe)):
    gHEMoONKPymCbRdrlGxupVWUqanJTf =gHEMoONKPymCbRdrlGxupVWUqanJhe[i].replace('data-profile-no=','').replace('"','')
    gHEMoONKPymCbRdrlGxupVWUqanJhe[i]=gHEMoONKPymCbRdrlGxupVWUqanJTf
   gHEMoONKPymCbRdrlGxupVWUqanJTS=gHEMoONKPymCbRdrlGxupVWUqanJhe[user_pf]
  except gHEMoONKPymCbRdrlGxupVWUqanJTD as exception:
   gHEMoONKPymCbRdrlGxupVWUqanJTY(exception)
   return gHEMoONKPymCbRdrlGxupVWUqanJTI,gHEMoONKPymCbRdrlGxupVWUqanJTL,gHEMoONKPymCbRdrlGxupVWUqanJTh
  try:
   gHEMoONKPymCbRdrlGxupVWUqanJIw ='/profile/api/select.do'
   gHEMoONKPymCbRdrlGxupVWUqanJhv=gHEMoONKPymCbRdrlGxupVWUqanJSh.URL_DOMAIN+gHEMoONKPymCbRdrlGxupVWUqanJIw
   gHEMoONKPymCbRdrlGxupVWUqanJSt=gHEMoONKPymCbRdrlGxupVWUqanJSh.makeDefaultCookies(vToken=gHEMoONKPymCbRdrlGxupVWUqanJSe,vUserinfo=gHEMoONKPymCbRdrlGxupVWUqanJIS)
   gHEMoONKPymCbRdrlGxupVWUqanJSz={'profileNo':gHEMoONKPymCbRdrlGxupVWUqanJTS}
   gHEMoONKPymCbRdrlGxupVWUqanJSF=gHEMoONKPymCbRdrlGxupVWUqanJSh.callRequestCookies('Post',gHEMoONKPymCbRdrlGxupVWUqanJhv,payload=gHEMoONKPymCbRdrlGxupVWUqanJSz,params=gHEMoONKPymCbRdrlGxupVWUqanJTs,headers=gHEMoONKPymCbRdrlGxupVWUqanJTs,cookies=gHEMoONKPymCbRdrlGxupVWUqanJSt)
   for gHEMoONKPymCbRdrlGxupVWUqanJSv in gHEMoONKPymCbRdrlGxupVWUqanJSF.cookies:
    if gHEMoONKPymCbRdrlGxupVWUqanJSv.name=='_tving_token':
     gHEMoONKPymCbRdrlGxupVWUqanJTI=gHEMoONKPymCbRdrlGxupVWUqanJSv.value
    elif gHEMoONKPymCbRdrlGxupVWUqanJSv.name==gHEMoONKPymCbRdrlGxupVWUqanJSh.GLOBAL_COOKIENM['tv_cookiekey']:
     gHEMoONKPymCbRdrlGxupVWUqanJTL=gHEMoONKPymCbRdrlGxupVWUqanJSv.value
    elif gHEMoONKPymCbRdrlGxupVWUqanJSv.name==gHEMoONKPymCbRdrlGxupVWUqanJSh.GLOBAL_COOKIENM['tv_lockkey']:
     gHEMoONKPymCbRdrlGxupVWUqanJTh=gHEMoONKPymCbRdrlGxupVWUqanJSv.value
  except gHEMoONKPymCbRdrlGxupVWUqanJTD as exception:
   gHEMoONKPymCbRdrlGxupVWUqanJTY(exception)
  return gHEMoONKPymCbRdrlGxupVWUqanJTI,gHEMoONKPymCbRdrlGxupVWUqanJTL,gHEMoONKPymCbRdrlGxupVWUqanJTh
# Created by pyminifier (https://github.com/liftoff/pyminifier)
