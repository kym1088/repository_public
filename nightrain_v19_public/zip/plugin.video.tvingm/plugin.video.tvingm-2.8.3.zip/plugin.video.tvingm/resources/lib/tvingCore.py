_A_='https://gw.tving.com'
_Az='genreCode'
_Ay='Second Step - except error'
_Ax='drm_license_data'
_Aw='/v3/media/stream/info'
_Av='mediacode'
_Au='h264|hevc'
_At='6yhlJ4WF9ZIj6I8n'
_As='kss2lym0kdw1lks3'
_Ar='user-agent'
_Aq='https://www.tving.com'
_Ap='_tving_token'
_Ao='token'
_An='bands'
_Am='nextApiUrl'
_Al='items'
_Ak='studio'
_Aj='aired'
_Ai='CAIP1900'
_Ah='CAIP2000'
_Ag='CAIP1800'
_Af='CAIP0200'
_Ae='CAIP0900'
_Ad='scope'
_Ac='guest'
_Ab='adult'
_Aa='cacheType'
_AZ='url_filename'
_AY='subtitleYn'
_AX='header'
_AW='streamType'
_AV='authType'
_AU='audioTypes'
_AT='videoTypes'
_AS='model'
_AR='networkCode'
_AQ='apiKey'
_AP='refreshToken'
_AO='movie'
_AN='imageUrl'
_AM='banner'
_AL='icon'
_AK='info_genre'
_AJ='frequency'
_AI='access-token'
_AH='HTML5'
_AG='PC_Chrome'
_AF='callingFrom'
_AE='noCache'
_AD='streamCode'
_AC='deviceInfo'
_AB='uuid'
_AA='deviceId'
_A9='mediaCode'
_A8='screenCode'
_A7='osCode'
_A6='authToken'
_A5='bandCode'
_A4='duration'
_A3='vod'
_A2='premiered'
_A1='grade_code'
_A0='pageNo'
_z='pageProps'
_y='genre'
_x='desc'
_w='clearlogo'
_v='channel'
_u='order'
_t='playback'
_s='drm_header_value'
_r='drm_header_key'
_q='drm_server_url'
_p='error_msg'
_o='mpaa'
_n='year'
_m='cast'
_l='%s-%s-%s'
_k='product_year'
_j='image'
_i='pageSize'
_h='Y'
_g='fanart'
_f='broad_dt'
_e='category2_name'
_d='category1_name'
_c='thumb'
_b='tving_uuid'
_a='account'
_Z='accessToken'
_Y='actor'
_X='synopsis'
_W='name'
_V='result'
_U='poster'
_T='episode'
_S='data'
_R='cookies'
_Q='0'
_P='Get'
_O='all'
_N='director'
_M='streaming_url'
_L='-'
_K='title'
_J='body'
_I=True
_H='thumbnail'
_G='url'
_F='utf-8'
_E=False
_D='code'
_C='ko'
_B='program'
_A=None
__author__='NightRain'
import urllib,re,json,sys,time,requests,datetime,random,base64,os,xml.etree.ElementTree as ET,xml.dom.minidom,io
'\nimport xbmcplugin, xbmcgui, xbmcaddon, xbmc, xbmcvfs\n__addon__ = xbmcaddon.Addon()\n__language__  = __addon__.getLocalizedString\n__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo(\'profile\'))\n__version__ = __addon__.getAddonInfo(\'version\')\n__addonid__ = __addon__.getAddonInfo(\'id\')\n__addonname__ = __addon__.getAddonInfo(\'name\')\n\n\ndef addon_log( string ):\n\ttry:\n\t\tlog_message = string.encode(\'utf-8\', \'ignore\')\n\texcept:\n\t\tlog_message = \'addonException: addon_log\'\n\tlevel = xbmc.LOGINFO\n\txbmc.log("[%s-%s]: %s" %(__addonid__, __version__, log_message), level=level)\n'
try:from Cryptodome.Cipher import PKCS1_OAEP,AES;from Cryptodome.Util import Padding;print('Cryptodome')
except ImportError:from Crypto.Cipher import PKCS1_OAEP,AES;from Crypto.Util import Padding;print('Crypto')
QUALITY_LIST={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
MPAA_LIST={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
ATTRIBUTE_PATTERN=re.compile('((?:[^,"\']|"[^"]*"|\'[^\']*\')+)')
KEY_LIST=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583',_A6,'cs','TSID',_Z,_AP,_Ap,'GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7']
class Tving:
	def __init__(A):A.APIKEY='1e7952d0917d6aab1f0293a063697610';A.NETWORKCODE='CSND0900';A.OSCODE='CSOD0900';A.TELECODE='CSCD0900';A.SCREENCODE='CSSD0100';A.APIKEY_ATV='b6ac9e6384d93d6e533b144b3ef22c42';A.SCREENCODE_ATV='CSSD1300';A.LIVE_LIMIT=20;A.VOD_LIMIT=24;A.EPISODE_LIMIT=30;A.SEARCH_LIMIT=30;A.MOVIE_LIMIT=24;A.PAGE_SIZE=20;A.API_DOMAIN='https://api.tving.com';A.IMG_DOMAIN='https://image.tving.com';A.SEARCH_DOMAIN='https://search-api.tving.com';A.LOGIN_DOMAIN='https://user.tving.com';A.URL_DOMAIN=_Aq;A.USER_AGENT='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36';A.MODEL='windows_chrome_153.0.0.0';A.MODEL2='"Not;A=Brand";v="8", "Chromium";v="153", "Google Chrome";v="153"';A.DEFAULT_HEADER={_Ar:A.USER_AGENT};A.TV_COOKIE_FILENAME='';A.TV_TOKEN_FILENAME='';A.SEARCHED_FILE_NAME='';A.TV_SESSION_COOKIES1='';A.TV_SESSION_COOKIES2='';A.TV_STREAM_FILENAME='';A.TV_SESSION_TEXT1='';A.TV_SESSION_TEXT2='';A.KodiVersion=20;A.TV={};A.TV_TOKEN={};A.Init_TV_Total()
	def Init_TV_Total(A):A.TV={_a:{},_R:{}};A.TV_TOKEN={}
	"\n\tdef callRequestCookies( self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):\n\t\t#HTTP_CLIENT = httpx.Client()  # httpx\n\n\t\tsetHeader = self.DEFAULT_HEADER\n\t\tif headers: setHeader.update( headers )\n\n\t\tif jobtype == 'Get': # Get/Post\n\t\t\tres = httpx.get( url, params=params, headers=setHeader, cookies=cookies )\n\t\telse:\n\t\t\tres = httpx.post( url, json=payload, params=params, headers=setHeader, cookies=cookies )\n\n\t\tprint( str(res.status_code) + ' - ' + str(res.url) )\n\n\t\treturn res\n\t"
	def callRequestCookies(G,jobtype,url,payload=_A,json=_A,params=_A,headers=_A,cookies=_A,redirects=_E):
		F=redirects;E=cookies;D=headers;C=params;B=G.DEFAULT_HEADER
		if D:B.update(D)
		if jobtype==_P:A=requests.get(url,params=C,headers=B,cookies=E,allow_redirects=F)
		else:A=requests.post(url,data=payload,json=json,params=C,headers=B,cookies=E,allow_redirects=F)
		print(str(A.status_code)+' - '+A.url);return A
	def JsonFile_Save(C,filename,dic):
		A=filename
		if A=='':return _E
		try:B=open(A,'w',-1,_F);json.dump(dic,B,indent=4,ensure_ascii=_E);B.close()
		except:return _E
		return _I
	def JsonFile_Load(D,filename):
		A=filename
		if A=='':return{}
		try:B=open(A,'r',-1,_F);C=json.load(B);B.close()
		except:return{}
		return C
	def TextFile_Save(C,filename,resText):
		A=filename
		if A=='':return _E
		try:B=open(A,'w',-1,_F);B.write(resText);B.close()
		except:return _E
		return _I
	def Save_session_acount(A,tvid,tvpw,tvtype,tvpf):A.TV[_a]['tvid']=base64.standard_b64encode(tvid.encode()).decode(_F);A.TV[_a]['tvpw']=base64.standard_b64encode(tvpw.encode()).decode(_F);A.TV[_a]['tvtype']=tvtype;A.TV[_a]['tvpf']=tvpf
	def Load_session_acount(A):
		try:B=base64.standard_b64decode(A.TV[_a]['tvid']).decode(_F);C=base64.standard_b64decode(A.TV[_a]['tvpw']).decode(_F);D=A.TV[_a]['tvtype'];E=A.TV[_a]['tvpf']
		except:return'','',_Q,0
		return B,C,D,E
	def make_stream_header(J,headers,cookies):
		I='{}={}';G=headers;A=cookies;B=''
		if A not in[{},_A,'']:
			H=len(A)
			for(C,D)in A.items():
				B+=I.format(C,D);H+=-1
				if H>0:B+='; '
			G['cookie']=B
		E='';F=0
		for(C,D)in G.items():
			F=F+1
			if F>1:E+='&'
			E+=I.format(C,urllib.parse.quote(D))
		return E
	def makeDefaultCookies(B):
		A={}
		for(C,D)in B.TV[_R].items():A[C]=D
		return A
	def GetDefaultParams(A,uhd=_E):
		C='teleCode'
		if uhd==_E:B={_AQ:A.APIKEY,_AR:A.NETWORKCODE,_A7:A.OSCODE,C:A.TELECODE,_A8:A.SCREENCODE}
		else:B={_AQ:A.APIKEY_ATV,_AR:A.NETWORKCODE,_A7:A.OSCODE,C:A.TELECODE,_A8:A.SCREENCODE_ATV}
		return B
	def GetNoCache(A,timetype=1):
		if timetype==1:return int(time.time())
		else:return int(time.time()*1000)
	def GetUniqueid(H,hValue=_A):
		C=hValue
		if C:import hashlib as G;D=G.sha1();D.update(C.encode());E=D.hexdigest()[:8]
		else:
			A=[0 for A in range(256)]
			for F in range(256):A[F]='%02x'%F
			B=int(4294967295*random.random())|0;E=A[255&B]+A[B>>8&255]+A[B>>16&255]+A[B>>24&255]
		return E
	def Web_DecryptKey(C):A=bytes(_As,_F);B=bytes(_At,_F);return A,B
	def Web_EncryptCiphertext(A,plaintext):B,C=A.Web_DecryptKey();D=AES.new(B,AES.MODE_CBC,C);E=D.encrypt(Padding.pad(plaintext.encode(_F),16));return base64.standard_b64encode(E).decode(_F)
	def Web_DecryptPlaintext(A,ciphertext):B,C=A.Web_DecryptKey();D=AES.new(B,AES.MODE_CBC,C);E=Padding.unpad(D.decrypt(base64.standard_b64decode(ciphertext)),16);return E.decode(_F)
	def WebCookies_Load(A,wc_file):
		try:
			C=open(wc_file,'r',-1,_F);D=C.read();C.close();E=A.Web_DecryptPlaintext(D);A.TV=json.loads(E);B=A.GetDeviceList()
			if B not in['',_L]:A.TV[_R][_b]=B+_L+A.GetUniqueid(B)
		except:return _E
		return _I
	def GetCredential2(B,user_id,user_pw,login_type,user_pf):
		D=user_id
		try:
			if base64.standard_b64encode(D.encode()).decode(_F)in['a3ltOTUxMDg4','a3ltMTA4OA==']:E='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE5MDkwL3R2aW5nbG9naW4='
			else:E='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx'
			A={'addon':'tvingm','method':'LOGIN',_S:{'type':login_type,'id':D,'pw':user_pw,'pf':user_pf}};A=json.dumps(A,separators=(',',':'));A=base64.standard_b64encode(A.encode()).decode(_F);G={'proxy-mini':A};F=requests.get(base64.standard_b64decode(E).decode(_F),headers=G)
			if F.status_code!=200:B.Init_TV_Total();return _E
			C=base64.standard_b64decode(F.text).decode(_F);C=json.loads(C);B.TV[_R]=C
		except Exception as H:print(H);B.Init_TV_Total();return _E
		return _I
	def GetDeviceList(B):C=[];A=_L;A=str(B.GetNoCache(timetype=1));return A
	def Get_Now_Datetime(A):return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
	def get_renewal_url(A,mediacode,quality_int=1080,proxyPort=9999):
		C=mediacode;E=A.TV[_R][_b].split(_L)[0];F=A.TV[_R][_b]
		for(G,H)in QUALITY_LIST.items():
			if H==quality_int:I=G
		D=A.GetDefaultParams();J={_A9:C,_AA:E,_AB:F,_AC:_AG,_AD:I,_AE:str(A.GetNoCache(1)),_AF:_AH,_AS:A.MODEL,_AT:_Au,_AU:'aac',_AV:_AX,_AW:'hls'};D.update(J);B={'addon':'tvingm',_Av:C,'get_url':'https://api.tving.com/v3/media/stream/info','headers':{_Ar:A.USER_AGENT,_AI:A.TV_TOKEN[_Z]},'params':D,_R:A.makeDefaultCookies()};B=json.dumps(B,separators=(',',':'));B=base64.standard_b64encode(B.encode()).decode(_F);K='http://127.0.0.1:{}/live.mpd?proxy-mini={}'.format(proxyPort,B);return K
	def GetBroadURL(B,mediacode,sel_quality,stype):
		M='subtitles';L='qt_stream';H=mediacode;A={_M:'',_AY:_E,_p:'',_q:'',_r:'',_s:'',_AZ:'',L:''};N=B.TV[_R][_b].split(_L)[0];O=B.TV[_R][_b]
		for(P,Q)in QUALITY_LIST.items():
			if Q==sel_quality:F=P
		A[L]=F;print(F)
		try:
			I=str(B.GetNoCache(1));R=_Aw;S={_AI:B.TV_TOKEN[_Z]};J=B.GetDefaultParams();T={_A9:H,_AA:N,_AB:O,_AC:_AG,_AE:I,_AF:_AH,_AS:B.MODEL,_AT:'h264|av1',_AU:'aac',_AV:_AX,'dev.drm':'pr','dev.sl':'SL3000','dev.osn':'windows','dev.osv':'11',_AD:F,_AW:'hls'};J.update(T);U=B.API_DOMAIN+R;V=B.makeDefaultCookies();W=B.callRequestCookies('Post',U,payload=_A,params=J,headers=S,cookies=V,redirects=_I);G=json.loads(W.text)
			if G[_J][_V][_D]!='000':A[_p]=G[_J][_V]['message'];return A
			C=G[_J]['stream']
			if C['drm_yn']==_h:
				D=C[_t]['drm']['widevine']
				for E in C[_t]['drm']['license'][_Ax]:
					if E['drm_type']=='Widevine':A[_q]=E[_q];A[_r]=E[_r];A[_s]=E[_s];break
			else:D=C[_t]['non_drm']
		except Exception as X:print(X);A[_p]=_Ay;return A
		Y=I;D=D.split('|')[1];D=B.Decrypt_Url(D,H,Y);A[_M]=D
		if M in C:
			for Z in C.get(M):
				if Z.get(_D)in['KO','KO_CC']:A[_AY]=_I;break
		a=urllib.parse.urlparse(A[_M]);K=a.path.strip('/').split('/');A[_AZ]=K[len(K)-1];return A
	def Tving_Parse_mpd(F,stream_url):
		K='bandwidth';J='Representation';L=requests.get(url=stream_url);G=L.content.decode(_F);D=0;M=ET.ElementTree(ET.fromstring(G));E=M.getroot();B=re.match('\\{.*\\}',E.tag)[0];N=dict([A for(B,A)in ET.iterparse(io.StringIO(G),events=['start-ns'])])
		for(H,O)in N.items():
			if H!='ns2':ET.register_namespace(H,O)
		P=E.find(B+'Period')
		for A in P.findall(B+'AdaptationSet'):
			if A.attrib.get('mimeType')=='video/mp4'or A.attrib.get('contentType')=='video':
				for C in A.findall(B+J):
					I=int(C.attrib.get(K))
					if D<I:D=I
				for C in A.findall(B+J):
					if D>int(C.attrib.get(K)):A.remove(C)
			else:continue
		Q=ET.tostring(E).decode(_F);R='<?xml version="1.0" encoding="UTF-8"?>\n';F.TextFile_Save(F.TV_STREAM_FILENAME,R+Q);return _I
	def Tving_Parse_m3u8(C,stream_url):
		H='BANDWIDTH';B='#EXT-X-STREAM-INF'
		try:
			J=requests.get(url=stream_url,headers=_A,stream=_I);D=J.content.decode(_F)
			if'#EXTM3U'not in D:return _E
			if B not in D:return _E
			F=0
			for A in D.splitlines():
				if A.startswith(B):
					E=C.MediaLine_Parse(A,B)
					if F<int(E.get(H)):F=int(E.get(H))
			I=[];G=_E
			for A in D.splitlines():
				if G==_I:G=_E;continue
				if A.startswith(B):
					E=C.MediaLine_Parse(A,B)
					if F!=int(E.get(H)):G=_I;continue
				I.append(A)
		except Exception as K:print(K);return _E
		L='\n'.join(I);C.TextFile_Save(C.TV_STREAM_FILENAME,L);return _I
	def MediaLine_Parse(E,line,prefix):
		A={}
		for B in ATTRIBUTE_PATTERN.split(line.replace(prefix+':',''))[1::2]:C,D=B.split('=',1);A[C.upper()]=D.replace('"','').strip()
		return A
	def CheckQuality(C,sel_qt,qt_list):
		for A in qt_list:
			if sel_qt>=list(A)[0]:return A.get(list(A)[0])
			B=A.get(list(A)[0])
		return B
	def GetLiveChannelList(C,stype,page_int):
		B='schedule';H=[];I=_E
		try:
			Y='/v2/media/lives'
			if stype=='onair':Q='CPCS0100,CPCS0400'
			else:Q='CPCS0300'
			R=C.GetDefaultParams();Z={_Aa:'main',_A0:str(page_int),_i:str(C.LIVE_LIMIT),_u:'rating',_Ab:_O,'free':_O,_Ac:_O,_Ad:_O,'channelType':Q};R.update(Z);a=C.API_DOMAIN+Y;b=C.callRequestCookies(_P,a,payload=_A,params=R,headers=_A,cookies=_A);J=json.loads(b.text)
			if not _V in J[_J]:return H,I
			c=J[_J][_V]
			for A in c:
				S=D=K='';L=M='';d=A['live_code'];S=A[B][_v][_W][_C]
				if A[B][_T]!=_A:D=A[B][_B][_W][_C];D=D+', '+str(A[B][_T][_AJ])+'회';K=A[B][_T][_X][_C]
				else:D=A[B][_B][_W][_C];K=A[B][_B][_X][_C]
				try:
					F='';"\n\t\t\t\t\tfor now_img in i_section['schedule']['program']['image']:\n\t\t\t\t\t\tif   now_img['code'] == 'CAIP0900': tmp_poster    = self.IMG_DOMAIN + now_img['url'] #CAIP0900/CAIP2300\n\t\t\t\t\t\telif now_img['code'] == 'CAIP1800':\ttmp_clearlogo = self.IMG_DOMAIN + now_img['url']\n\t\t\t\t\t\telif now_img['code'] == 'CAIP2000':\ttmp_icon      = self.IMG_DOMAIN + now_img['url']\n\t\t\t\t\t\telif now_img['code'] == 'CAIP0200':\ttmp_fanart    = self.IMG_DOMAIN + now_img['url']\n\t\t\t\t\t\telif now_img['code'] == 'CAIP0500':\ttmp_thumb     = self.IMG_DOMAIN + now_img['url'] #CAIP0800/CAIP0500\n\t\t\t\t\t\telif now_img['code'] == 'CAIP0800':\ttmp_thumb     = self.IMG_DOMAIN + now_img['url'] #CAIP0800/CAIP0500\n\n\t\t\t\t\tif tmp_thumb == '':\n\t\t\t\t\t\tfor now_img in i_section['schedule']['channel']['image']:\n\t\t\t\t\t\t\tif now_img['code'] in ['CAIC0400','CAIC1400','CAIC1900','CAIC1500']:\n\t\t\t\t\t\t\t\ttmp_thumb   = self.IMG_DOMAIN + now_img['url']\n\t\t\t\t\t\t\t\tbreak\n\t\t\t\t\t"
					for E in A[B][_v][_j]:
						if E[_D]in['CAIC1500']:F=C.IMG_DOMAIN+E[_G];break
					if F=='':
						for E in A[B][_B][_j]:
							if E[_D]in['CAIP0500']:F=C.IMG_DOMAIN+E[_G];break
				except:_A
				try:
					T=[];U=[];N=[];V='';W='';X=''
					for O in A.get(B).get(_B).get(_Y):
						if O!=''and O!='없음':T.append(O)
					for G in A.get(B).get(_B).get(_N):
						if G!=''and G!=_L and G!='없음':U.append(G)
					if A.get(B).get(_B).get(_d).get(_C)!='':N.append(A[B][_B][_d][_C])
					if A.get(B).get(_B).get(_e).get(_C)!='':N.append(A[B][_B][_e][_C])
					if A.get(B).get(_B).get(_k):V=A[B][_B][_k]
					if A.get(B).get(_B).get(_A1):W=MPAA_LIST.get(A[B][_B][_A1])
					if _f in A.get(B).get(_B):P=A.get(B).get(_B).get(_f);X=_l%(P[:4],P[4:6],P[6:])
				except:_A
				L=str(A[B]['broadcast_start_time'])[8:12];M=str(A[B]['broadcast_end_time'])[8:12];e={_v:S,_K:D,_Av:d,_H:{_c:F},_X:K,'channelepg':' [%s:%s ~ %s:%s]'%(L[0:2],L[2:],M[0:2],M[2:]),_m:T,_N:U,_AK:N,_n:V,_o:W,_A2:X};H.append(e)
			if J[_J]['has_more']==_h:I=_I
		except Exception as f:print(f)
		return H,I
	def GetProgramList(C,genre,orderby,page_int,genreCode=_O):
		N=genreCode;M=genre;F=[];G=_E
		try:
			Y='/v2/media/episodes';O=C.GetDefaultParams();H={_Aa:'main',_i:str(C.VOD_LIMIT),_u:orderby,_Ab:_O,'free':_O,_Ac:_O,_Ad:_O,'lastFrequency':'y','personal':'N',_A0:str(page_int)}
			if M not in[_O,'PARAMOUNT']:H['categoryCode']=M
			if N!=_O:H[_Az]=N
			O.update(H);Z=C.API_DOMAIN+Y;a=C.callRequestCookies(_P,Z,payload=_A,params=O,headers=_A,cookies=_A);I=json.loads(a.text)
			if not _V in I[_J]:return F,G
			b=I[_J][_V]
			for A in b:
				c=A[_B][_D];d=A[_B][_W][_C];e=MPAA_LIST.get(A[_B].get(_A1));P='';J='';Q='';R='';S=''
				for B in A[_B][_j]:
					if B[_D]==_Ae:P=C.IMG_DOMAIN+B[_G]
					elif B[_D]==_Af:J=C.IMG_DOMAIN+B[_G]
					elif B[_D]==_Ag:Q=C.IMG_DOMAIN+B[_G]
					elif B[_D]==_Ah:R=C.IMG_DOMAIN+B[_G]
					elif B[_D]==_Ai:S=C.IMG_DOMAIN+B[_G]
				f=A[_B][_X][_C]
				try:T=A[_v][_W][_C]
				except:T=''
				try:
					U=[];V=[];K=[];W='';X=''
					for D in A.get(_B).get(_Y):
						if D!=''and D!=_L and D!='없음':U.append(D)
					for E in A.get(_B).get(_N):
						if E!=''and E!=_L and E!='없음':V.append(E)
					if A.get(_B).get(_d).get(_C)!='':K.append(A[_B][_d][_C])
					if A.get(_B).get(_e).get(_C)!='':K.append(A[_B][_e][_C])
					if A.get(_B).get(_k):W=A[_B][_k]
					if _f in A.get(_B):L=A.get(_B).get(_f);X=_l%(L[:4],L[4:6],L[6:])
				except:_A
				g={_B:c,_K:d,_H:{_U:P,_c:J,_w:Q,_AL:R,_AM:S,_g:J},_X:f,_v:T,_m:U,_N:V,_AK:K,_n:W,_A2:X,_o:e};F.append(g)
			if I[_J]['has_more']==_h:G=_I
		except Exception as h:print(h)
		return F,G
	def GetEpisodeList(B,program_code,page_int,orderby=_x):
		M=orderby;F=page_int;G=[];H=_E
		try:
			a='/v2/media/frequency/program/'+program_code;N=B.GetDefaultParams();b={_u:'newUpdate',_Aa:'main',_i:'20',_u:'new',_Ab:_O,'free':_O,_Ac:_O,_Ad:_O};N.update(b);c=B.API_DOMAIN+a;d=B.callRequestCookies(_P,c,payload=_A,params=N,headers=_A,cookies=_A);I=json.loads(d.text)
			if not _V in I[_J]:return G,H
			D=I[_J][_V];J=int(I[_J]['total_count']);O=int(J//(B.EPISODE_LIMIT+1))+1
			if M==_x:K=J-1-(F-1)*B.EPISODE_LIMIT
			else:K=(F-1)*B.EPISODE_LIMIT
			for P in range(B.EPISODE_LIMIT):
				if M==_x:
					A=K-P
					if A<0:break
				else:
					A=K+P
					if A>=J:break
				e=D[A][_T][_D];f=D[A]['vod_name'][_C];E=''
				try:L=str(D[A][_T]['broadcast_date']);E=_l%(L[:4],L[4:6],L[6:])
				except:_A
				try:
					if D[A][_T]['pip_cliptype']=='C012':E+=' - Quick VOD'
				except:_A
				g=D[A][_T][_X][_C];Q='';R='';S='';T='';U='';V=''
				for C in D[A][_B][_j]:
					if C[_D]==_Ae:Q=B.IMG_DOMAIN+C[_G]
					elif C[_D]==_Ag:S=B.IMG_DOMAIN+C[_G]
					elif C[_D]==_Ah:T=B.IMG_DOMAIN+C[_G]
					elif C[_D]==_Ai:U=B.IMG_DOMAIN+C[_G]
					elif C[_D]==_Af:V=B.IMG_DOMAIN+C[_G]
				for C in D[A][_T][_j]:
					if C[_D]=='CAIE0400':R=B.IMG_DOMAIN+C[_G]
				try:
					W=X=Y='';Z=0;W=D[A][_B][_W][_C];X=E;Y=D[A][_v][_W][_C]
					if _AJ in D[A][_T]:Z=D[A][_T][_AJ]
				except:_A
				h={_T:e,_K:f,'subtitle':E,_H:{_U:Q,_c:R,_w:S,_AL:T,_AM:U,_g:V},_X:g,'info_title':W,_Aj:X,_Ak:Y,_AJ:Z};G.append(h)
			if O>F:H=_I
		except Exception as i:print(i)
		return G,H,O
	def Gn2_Program_List(B,genre,orderby,page_int):
		C=[];D=_E
		try:
			F=_A_+'/bff/web/v3/content/vod';G={_A0:str(page_int),_i:str(B.PAGE_SIZE),_u:orderby,_Az:genre,_A8:'CSSD0100',_A7:'CSOD0900'};H=B.callRequestCookies(_P,F,payload=_A,params=G,headers=_A,cookies=_A);E=json.loads(H.text);I=E[_S][_Al]
			for A in I:J={_D:A[_D],_K:A[_K],_H:{_U:A[_AN]}};C.append(J)
			if _Am in E[_S]:D=_I
		except Exception as K:print(K)
		return C,D
	def GetSearchList(B,search_key,page_int,stype):
		i='grade_nm';h='runtime_sec';g='targetage';f='web_url';e='mast_nm';d='mast_cd';c='count';b='dataList';Z=page_int;Y=search_key;X='vodMVRsb';W='programRsb';V='NO';R='ALL';N=stype;E='cate_nm';F=[];O=_E
		try:
			j='/search/getSearch.jsp';r=B.GetDefaultParams();k={'kwd':Y,'category':'PROGRAM'if N==_A3 else'VODMV','pageNum':str(Z),'notFoundText':Y,'userid':'','siteName':'TVING_WEB',_i:str(B.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':R,'runTime':R,'grade':R,_y:R,'screen':B.SCREENCODE,'os':B.OSCODE,'network':B.NETWORKCODE,'sort1':V,'sort2':V,'sort3':V,'type1':_x,'type2':_x,'type3':_x,'fixedType':_h,'spcMethod':'someword','spcSize':_Q,'schReqCnt':_Q,'vodBCReqCnt':_Q,'programReqCnt':str(B.SEARCH_LIMIT)if N==_A3 else _Q,'vodMVReqCnt':str(B.SEARCH_LIMIT)if N==_AO else _Q,'aloneReqCnt':_Q,'smrclipReqCnt':_Q,'pickClipReqCnt':_Q,'cSocialClipCnt':_Q,'boardReqCnt':_Q,'talkReqCnt':_Q,'nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'',_AQ:B.APIKEY,_AR:B.NETWORKCODE,'osCode ':B.OSCODE,'teleCode ':B.TELECODE,'screenCode ':B.SCREENCODE};l=B.SEARCH_DOMAIN+j;m=B.callRequestCookies(_P,l,payload=_A,params=k,headers=_A,cookies=_A);D=json.loads(m.text)
			if N==_A3:
				if not W in D:return F,O
				n=D[W][b];a=int(D[W][c])
				for A in n:
					S=A[d];T=A[e];P=B.IMG_DOMAIN+A['web_url4'];G=B.IMG_DOMAIN+A[f]
					try:
						H=[];I=[];J=[];Q=0;K='';L='';M=''
						if A.get(_Y)!=''and A.get(_Y)!=_L:H=A.get(_Y).split(',')
						if A.get(_N)!=''and A.get(_N)!=_L:I=A.get(_N).split(',')
						if A.get(E)!=''and A.get(E)!=_L:J=A.get(E).split('/')
						if g in A:K=A.get(g)
						if _f in A:C=A.get(_f);M=_l%(C[:4],C[4:6],C[6:]);L=C[:4]
					except:_A
					U={_B:S,_K:T,_H:{_U:P,_c:G,_g:G},_X:'',_m:H,_N:I,_AK:J,_A4:Q,_o:K,_n:L,_Aj:M};F.append(U)
			else:
				if not X in D:return F,O
				o=D[X][b];a=int(D[X][c])
				for A in o:
					S=A[d];T=A[e].strip();P=B.IMG_DOMAIN+A[f];G=P;p=''
					try:
						H=[];I=[];J=[];Q=0;K='';L='';M=''
						if A.get(_Y)!=''and A.get(_Y)!=_L:H=A.get(_Y).split(',')
						if A.get(_N)!=''and A.get(_N)!=_L:I=A.get(_N).split(',')
						if A.get(E)!=''and A.get(E)!=_L:J=A.get(E).split('/')
						if A.get(h)!='':Q=A.get(h)
						if i in A:K=A.get(i)
						C=A.get(_f)
						if data_str!='':M=_l%(C[:4],C[4:6],C[6:]);L=C[:4]
					except:_A
					U={_AO:S,_K:T,_H:{_U:P,_c:G,_g:G,_w:p},_X:'',_m:H,_N:I,_AK:J,_A4:Q,_o:K,_n:L,_Aj:M};F.append(U)
			if a>Z*B.SEARCH_LIMIT:O=_I
		except Exception as q:print(q)
		return F,O
	def Gn2_Search_List(B,search_key,page_int,stype):
		C=stype;D=[];E=_E
		try:
			if C==_A3:F='https://gw.tving.com/bff/search/v2/more/content/series/search';G='AI_SCH_SERIES'
			else:F='https://gw.tving.com/bff/search/v2/more/content/movie/search';G='AI_SCH_MOVIE'
			J={'keyword':search_key,_A0:str(page_int),_i:str(B.PAGE_SIZE),'bandComposeMethod':'MANUAL',_A5:G,_A7:B.OSCODE,_A8:B.SCREENCODE};K=B.callRequestCookies(_P,F,payload=_A,params=J,headers=_A,cookies=_A);H=json.loads(K.text).get(_S).get(_An)[0]
			for A in H[_Al]:
				if C==_A3:I={_B:A[_D],_K:A[_K],_H:{_U:A[_AN]}}
				else:I={_AO:A[_D],_K:A[_K],_H:{_U:A[_AN]}}
				D.append(I)
			if _Am in H:E=_I
		except Exception as L:print(L)
		return D,E
	def GetBookmarkInfo(E,videoid,vidtype):
		W='content';V='info';S='plot';O=vidtype;N=videoid;D='infoLabels';B='saveinfo';A={'indexinfo':{'ott':'tving','videoid':N,'vidtype':O},B:{_K:'','subtitle':'',_H:{_U:'',_c:'',_w:'',_AL:'',_AM:'',_g:''},D:{'mediatype':O,_K:'',_o:'',S:'',_n:'',_Ak:'',_A4:0,_m:[],_N:[],_y:[],_A2:'','country':''}}}
		if O=='tvshow':
			P=E.API_DOMAIN+'/v2/media/program/'+N;K=E.GetDefaultParams();Q={_A0:'1',_i:'10',_u:_W};K.update(Q);R=E.callRequestCookies(_P,P,payload=_A,params=K,headers=_A,cookies=_A);L=json.loads(R.text)
			if not _J in L:return{}
			C=L[_J];H=C.get(_W).get(_C).strip();A[B][_K]=H;A[B][D][_K]=H;A[B][D][_o]=MPAA_LIST.get(C.get(_A1));A[B][D][S]=C.get(_X).get(_C);A[B][D][_n]=C.get(_k);A[B][D][_m]=C.get(_Y);A[B][D][_N]=C.get(_N)
			if C.get(_d).get(_C)!='':A[B][D][_y].append(C.get(_d).get(_C))
			if C.get(_e).get(_C)!='':A[B][D][_y].append(C.get(_e).get(_C))
			G=str(C.get(_f))
			if G!=_Q:A[B][D][_A2]=_l%(G[:4],G[4:6],G[6:])
			I='';J='';M='';T='';U=''
			for F in C.get(_j):
				if F.get(_D)==_Ae:I=E.IMG_DOMAIN+F.get(_G)
				elif F.get(_D)==_Af:J=E.IMG_DOMAIN+F.get(_G)
				elif F.get(_D)==_Ag:M=E.IMG_DOMAIN+F.get(_G)
				elif F.get(_D)==_Ah:T=E.IMG_DOMAIN+F.get(_G)
				elif F.get(_D)==_Ai:U=E.IMG_DOMAIN+F.get(_G)
			A[B][_H][_U]=I;A[B][_H][_c]=J;A[B][_H][_w]=M;A[B][_H][_AL]=T;A[B][_H][_AM]=U;A[B][_H][_g]=J
		else:
			P=E.API_DOMAIN+'/v2a/media/stream/info';K=E.GetDefaultParams();Q={_AF:_AH,_A9:N,V:_h,'adReq':'adproxy',_AD:'stream40',_AA:E.TV[_R][_b].split(_L)[0],_AB:E.TV[_R][_b],_AC:_AG,_AE:str(E.GetNoCache(1)),'wm':_h};K.update(Q);R=E.callRequestCookies(_P,P,payload=_A,params=K,headers=_A,cookies=_A);L=json.loads(R.text)
			if not W in L[_J]:return{}
			C=L[_J][W][V][_AO];H=C.get(_W).get(_C).strip();A[B][D][_K]=H;H+=' (%s)'%C.get(_k);A[B][_K]=H;A[B][D][_o]=MPAA_LIST.get(C.get(_A1));A[B][D][S]=C.get('story').get(_C);A[B][D][_n]=C.get(_k);A[B][D][_Ak]=C.get('production');A[B][D][_A4]=C.get(_A4);A[B][D][_m]=C.get(_Y);A[B][D][_N]=C.get(_N)
			if C.get(_d).get(_C)!='':A[B][D][_y].append(C.get(_d).get(_C))
			if C.get(_e).get(_C)!='':A[B][D][_y].append(C.get(_e).get(_C))
			G=str(C.get('release_date'))
			if G!=_Q:A[B][D][_A2]=_l%(G[:4],G[4:6],G[6:])
			I='';J='';M=''
			for F in C.get(_j):
				if F.get(_D)=='CAIM2100':I=E.IMG_DOMAIN+F.get(_G)
				elif F.get(_D)=='CAIM0400':J=E.IMG_DOMAIN+F.get(_G)
				elif F.get(_D)=='CAIM1800':M=E.IMG_DOMAIN+F.get(_G)
			A[B][_H][_U]=I;A[B][_H][_c]=I;A[B][_H][_w]=M;A[B][_H][_g]=J
		return A
	def Make_DecryptKey(C,step,mediacode='000',timecode='000'):
		if step=='1':A=bytes('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),_F);B=bytes(_At,_F)
		else:A=bytes(_As,_F);B=bytes([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
		return A,B
	def DecryptPlaintext(C,ciphertext,encryption_key,init_vector):A=AES.new(encryption_key,AES.MODE_CBC,init_vector);B=Padding.unpad(A.decrypt(base64.standard_b64decode(ciphertext)),16);return B.decode(_F)
	def Decrypt_Url(A,ciphertext,mediacode,timecode):
		E=timecode;D=mediacode;F=''
		try:B,C=A.Make_DecryptKey('1',mediacode=D,timecode=E);G=json.loads(A.DecryptPlaintext(ciphertext,B,C));H=G.get(_G);B,C=A.Make_DecryptKey('2',mediacode=D,timecode=E);F=A.DecryptPlaintext(H,B,C)
		except Exception as I:print(I)
		return F
	def Get_buildId(B):
		A=''
		try:C=_Aq;D=B.callRequestCookies(_P,C,payload=_A,params=_A,headers=_A,cookies=_A);E='"buildId":"(.*?)"';A=re.compile(E,re.DOTALL).findall(D.text)[0]
		except Exception as F:print(F)
		return A
	def Get_Band_VodList(C,bandKey,nextApiUrl=_L):
		O='state';N='queries';M='dehydratedState';K=nextApiUrl;B=bandKey;D=[];E=''
		try:
			if B.startswith('CR'):L='/curation/{}'.format(B)
			else:L='/band/{}'.format(B)
			if K in[_A,'',_L]:
				P=C.Get_buildId();Q='/_next/data/{}/ko/more{}.json'.format(P,L);R={'key':B};G=C.URL_DOMAIN+Q;H=C.callRequestCookies(_P,G,payload=_A,params=R,headers=_A,cookies=_A);A=json.loads(H.text)
				if not _z in A:return D,E
				if B.startswith('CR'):F=A[_z][M][N][0][O][_S][_S][_An][0]
				else:F=A[_z][M][N][0][O][_S]['pages'][0][_S]['band']
			else:
				G='{}{}{}'.format(_A_,K,'&screenCode=CSSD0100&osCode=CSOD0900');H=C.callRequestCookies(_P,G,payload=_A,params=_A,headers=_A,cookies=_A);A=json.loads(H.text)
				if not _S in A:return D,E
				F=A[_S]
			for I in F[_Al]:J=I[_AN];S={_B:I[_D],_K:I[_K],_H:{_U:J,_c:J,_g:J}};D.append(S)
			E=F.get(_Am)or''
		except Exception as T:print(T)
		return D,E
	def Get_bandCode_GroupCode(C,GroupCode):
		D=GroupCode;B=''
		try:
			E={'authorization':'Bearer {}'.format(C.TV_TOKEN[_Ao]),_AI:C.TV_TOKEN[_Z]};F=['https://gw.tving.com/bff/web/v3/home/main?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/drama?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/entertainment?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/movie?screenCode=CSSD0100&osCode=CSOD0900']
			for G in F:
				H=C.callRequestCookies(_P,G,payload=_A,params=_A,headers=E,cookies=_A);I=json.loads(H.text)
				for A in I[_S][_An]:
					if D in A[_A5]or D=='TVING_ORIGINAL'and A['bandType']=='VOD_BASIC_ORIGINAL':
						if':'in A[_A5]:B=A[_A5].split(':')[0]
						else:B=A[_A5]
						return B
		except Exception as J:print(J)
		return B
	def Get_AccessToken(A):
		E='userInfo';D='props'
		try:
			G=A.URL_DOMAIN;F=A.makeDefaultCookies();F.pop(_Z);B=A.callRequestCookies(_P,G,payload=_A,params=_A,headers=_A,cookies=F)
			if B.status_code!=200:return _E
			H='<script id="__NEXT_DATA__" type="application/json">\\s*(.*?)\\s*</script>';I=re.compile(H,re.DOTALL).findall(B.text)[0];C=json.loads(I);A.TV_TOKEN[_Ao]=C.get(D).get(_z).get(E).get(_Ao);A.TV_TOKEN[_A6]=C.get(D).get(_z).get(E).get(_A6);A.TV_TOKEN[_Z]=B.cookies[_Z];A.TV_TOKEN[_AP]=C.get(D).get(_z).get(E).get(_AP);J=A.Get_Now_Datetime();K=J+datetime.timedelta(days=0);A.TV_TOKEN['token_date']=K.strftime('%Y%m%d');A.JsonFile_Save(A.TV_TOKEN_FILENAME,A.TV_TOKEN)
		except Exception as L:print(L);return _E
		return _I
	def GetLiveURL_Test(B,mediacode,sel_quality):
		H=mediacode;A={_M:'',_AY:_E,_p:'',_q:'',_r:'',_s:'',_AZ:''};M=B.TV[_R][_b].split(_L)[0];N=B.TV[_R][_b]
		try:
			I=str(B.GetNoCache(1));O=_Aw;P={_AI:B.TV_TOKEN[_Z]};J=B.GetDefaultParams();Q={_A9:H,_AA:M,_AB:N,_AC:_AG,_AD:'stream50',_AE:I,_AF:_AH,_AS:B.MODEL,_AT:_Au,_AU:'aac',_AV:_AX,_AW:'hls'};J.update(Q);R=B.API_DOMAIN+O;K=B.makeDefaultCookies();S=B.callRequestCookies('Post',R,payload=_A,params=J,headers=P,cookies=K,redirects=_I);F=json.loads(S.text)
			if F[_J][_V][_D]!='000':A[_p]=F[_J][_V]['message'];return A
			D=F[_J]['stream']
			if D['drm_yn']==_h:
				C=D[_t]['drm']['widevine']
				for E in D[_t]['drm']['license'][_Ax]:
					if E['drm_type']=='Widevine':A[_q]=E[_q];A[_r]=E[_r];A[_s]=E[_s];break
			else:C=D[_t]['non_drm']
		except Exception as T:print(T);A[_p]=_Ay;return A
		U=I;C=C.split('|')[1];C=B.Decrypt_Url(C,H,U);A[_M]=C;V=A[_M].find('Policy=')
		if V!=-1:Y=A[_M].split('?')[0];G=dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(A[_M]).query));A[_M]='{}&CloudFront-Policy={}'.format(A[_M],G['Policy']);A[_M]='{}&CloudFront-Signature={}'.format(A[_M],G['Signature']);A[_M]='{}&CloudFront-Key-Pair-Id={}'.format(A[_M],G['Key-Pair-Id'])
		W=[_Ap,_Z,_A6]
		for(L,X)in K.items():
			if L in W:A[_M]='{}&{}={}'.format(A[_M],L,X)
		print(A[_M]);return A