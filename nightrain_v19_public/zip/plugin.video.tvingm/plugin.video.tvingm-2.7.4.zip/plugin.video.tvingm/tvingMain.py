__author__="NightRain"
atmRejVxJOFhvuUqcYdgiypCWKnPAM=int
import os
import sys
import xbmcaddon,xbmcvfs
import urllib
__cwd__=xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
__lib__=os.path.join(__cwd__,'resources','lib')
sys.path.append(__lib__)
atmRejVxJOFhvuUqcYdgiypCWKnPAI =os.path.join(__cwd__,'packages')
sys.path.append(atmRejVxJOFhvuUqcYdgiypCWKnPAI)
from tvingRun import*
def get_params():
 p=urllib.parse.parse_qs(sys.argv[2][1:])
 for i in p.keys():
  p[i]=p[i][0]
 return p
atmRejVxJOFhvuUqcYdgiypCWKnPAL=cCINntvTyarzbmouqShwkXOlWsYExG(sys.argv[0],atmRejVxJOFhvuUqcYdgiypCWKnPAM(sys.argv[1]),get_params()) 
atmRejVxJOFhvuUqcYdgiypCWKnPAL.tving_main()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
