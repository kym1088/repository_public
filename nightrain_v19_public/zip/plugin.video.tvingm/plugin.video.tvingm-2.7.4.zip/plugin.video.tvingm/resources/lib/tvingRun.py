__author__="NightRain"
cCINntvTyarzbmouqShwkXOlWsYEDK=object
cCINntvTyarzbmouqShwkXOlWsYEDd=None
cCINntvTyarzbmouqShwkXOlWsYEDU=int
cCINntvTyarzbmouqShwkXOlWsYEDH=False
cCINntvTyarzbmouqShwkXOlWsYEDQ=True
cCINntvTyarzbmouqShwkXOlWsYEDJ=type
cCINntvTyarzbmouqShwkXOlWsYEDp=dict
cCINntvTyarzbmouqShwkXOlWsYEDi=getattr
cCINntvTyarzbmouqShwkXOlWsYEDg=list
cCINntvTyarzbmouqShwkXOlWsYEDj=len
cCINntvTyarzbmouqShwkXOlWsYEDL=str
cCINntvTyarzbmouqShwkXOlWsYEDM=range
cCINntvTyarzbmouqShwkXOlWsYEDf=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
cCINntvTyarzbmouqShwkXOlWsYExK=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'티빙 오리지날','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'TVING_ORIGINAL'},{'title':'실시간 인기 드라마','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'POP20_DRAMA_HOUR'},{'title':'실시간 인기 예능','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'POP20_UNSCRT_HOUR'},{'title':'실시간 인기 영화','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'POP20_MOVIE_HOUR'},{'title':'Apple TV+ 실시간 인기','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'TVING_APPLE_HOUR'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'Apple TV+','mode':'APPLE_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'},]
cCINntvTyarzbmouqShwkXOlWsYExd=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
cCINntvTyarzbmouqShwkXOlWsYExU=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
cCINntvTyarzbmouqShwkXOlWsYExH=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
cCINntvTyarzbmouqShwkXOlWsYExQ=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
cCINntvTyarzbmouqShwkXOlWsYExJ=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
cCINntvTyarzbmouqShwkXOlWsYExD=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
cCINntvTyarzbmouqShwkXOlWsYExp={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
class cCINntvTyarzbmouqShwkXOlWsYExG(cCINntvTyarzbmouqShwkXOlWsYEDK):
 def __init__(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYExg,cCINntvTyarzbmouqShwkXOlWsYExj,cCINntvTyarzbmouqShwkXOlWsYExL):
  cCINntvTyarzbmouqShwkXOlWsYExi._addon_url =cCINntvTyarzbmouqShwkXOlWsYExg
  cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle=cCINntvTyarzbmouqShwkXOlWsYExj
  cCINntvTyarzbmouqShwkXOlWsYExi.main_params =cCINntvTyarzbmouqShwkXOlWsYExL
  cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj =VyhDbFCJmBnUHKTvkrdoEMaYQSNWij() 
  cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
  cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_COOKIE_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
  cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_TOKEN_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_token.json'))
  cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.SEARCHED_FILE_NAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
 def addon_noti(cCINntvTyarzbmouqShwkXOlWsYExi,sting):
  try:
   cCINntvTyarzbmouqShwkXOlWsYExf=xbmcgui.Dialog()
   cCINntvTyarzbmouqShwkXOlWsYExf.notification(__addonname__,sting)
  except:
   cCINntvTyarzbmouqShwkXOlWsYEDd
 def addon_log(cCINntvTyarzbmouqShwkXOlWsYExi,string):
  try:
   cCINntvTyarzbmouqShwkXOlWsYExA=string.encode('utf-8','ignore')
  except:
   cCINntvTyarzbmouqShwkXOlWsYExA='addonException: addon_log'
  cCINntvTyarzbmouqShwkXOlWsYExP=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,cCINntvTyarzbmouqShwkXOlWsYExA),level=cCINntvTyarzbmouqShwkXOlWsYExP)
 def get_keyboard_input(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEGL):
  cCINntvTyarzbmouqShwkXOlWsYExV=cCINntvTyarzbmouqShwkXOlWsYEDd
  kb=xbmc.Keyboard()
  kb.setHeading(cCINntvTyarzbmouqShwkXOlWsYEGL)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   cCINntvTyarzbmouqShwkXOlWsYExV=kb.getText()
  return cCINntvTyarzbmouqShwkXOlWsYExV
 def get_settings_account(cCINntvTyarzbmouqShwkXOlWsYExi):
  cCINntvTyarzbmouqShwkXOlWsYExB =__addon__.getSetting('id')
  cCINntvTyarzbmouqShwkXOlWsYExe =__addon__.getSetting('pw')
  cCINntvTyarzbmouqShwkXOlWsYExR =__addon__.getSetting('login_type')
  cCINntvTyarzbmouqShwkXOlWsYExF=cCINntvTyarzbmouqShwkXOlWsYEDU(__addon__.getSetting('selected_profile'))
  return(cCINntvTyarzbmouqShwkXOlWsYExB,cCINntvTyarzbmouqShwkXOlWsYExe,cCINntvTyarzbmouqShwkXOlWsYExR,cCINntvTyarzbmouqShwkXOlWsYExF)
 def get_settings_uhd(cCINntvTyarzbmouqShwkXOlWsYExi):
  return cCINntvTyarzbmouqShwkXOlWsYEDH
 def get_settings_playback(cCINntvTyarzbmouqShwkXOlWsYExi):
  cCINntvTyarzbmouqShwkXOlWsYEGx={'active_uhd':cCINntvTyarzbmouqShwkXOlWsYEDQ if __addon__.getSetting('active_uhd')=='true' else cCINntvTyarzbmouqShwkXOlWsYEDH,'streamFilename':cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_STREAM_FILENAME,}
  return cCINntvTyarzbmouqShwkXOlWsYEGx
 def get_settings_proxyport(cCINntvTyarzbmouqShwkXOlWsYExi):
  cCINntvTyarzbmouqShwkXOlWsYEGK =cCINntvTyarzbmouqShwkXOlWsYEDQ if __addon__.getSetting('proxyYn')=='true' else cCINntvTyarzbmouqShwkXOlWsYEDH
  cCINntvTyarzbmouqShwkXOlWsYEGd=cCINntvTyarzbmouqShwkXOlWsYEDU(__addon__.getSetting('proxyPort'))
  return cCINntvTyarzbmouqShwkXOlWsYEGK,cCINntvTyarzbmouqShwkXOlWsYEGd
 def get_settings_totalsearch(cCINntvTyarzbmouqShwkXOlWsYExi):
  cCINntvTyarzbmouqShwkXOlWsYEGU =cCINntvTyarzbmouqShwkXOlWsYEDQ if __addon__.getSetting('local_search')=='true' else cCINntvTyarzbmouqShwkXOlWsYEDH
  cCINntvTyarzbmouqShwkXOlWsYEGH=cCINntvTyarzbmouqShwkXOlWsYEDQ if __addon__.getSetting('local_history')=='true' else cCINntvTyarzbmouqShwkXOlWsYEDH
  cCINntvTyarzbmouqShwkXOlWsYEGQ =cCINntvTyarzbmouqShwkXOlWsYEDQ if __addon__.getSetting('total_search')=='true' else cCINntvTyarzbmouqShwkXOlWsYEDH
  cCINntvTyarzbmouqShwkXOlWsYEGJ=cCINntvTyarzbmouqShwkXOlWsYEDQ if __addon__.getSetting('total_history')=='true' else cCINntvTyarzbmouqShwkXOlWsYEDH
  cCINntvTyarzbmouqShwkXOlWsYEGD=cCINntvTyarzbmouqShwkXOlWsYEDQ if __addon__.getSetting('menu_bookmark')=='true' else cCINntvTyarzbmouqShwkXOlWsYEDH
  return(cCINntvTyarzbmouqShwkXOlWsYEGU,cCINntvTyarzbmouqShwkXOlWsYEGH,cCINntvTyarzbmouqShwkXOlWsYEGQ,cCINntvTyarzbmouqShwkXOlWsYEGJ,cCINntvTyarzbmouqShwkXOlWsYEGD)
 def get_settings_makebookmark(cCINntvTyarzbmouqShwkXOlWsYExi):
  return cCINntvTyarzbmouqShwkXOlWsYEDQ if __addon__.getSetting('make_bookmark')=='true' else cCINntvTyarzbmouqShwkXOlWsYEDH
 def get_settings_direct_replay(cCINntvTyarzbmouqShwkXOlWsYExi):
  cCINntvTyarzbmouqShwkXOlWsYEGp=cCINntvTyarzbmouqShwkXOlWsYEDU(__addon__.getSetting('direct_replay'))
  if cCINntvTyarzbmouqShwkXOlWsYEGp==0:
   return cCINntvTyarzbmouqShwkXOlWsYEDH
  else:
   return cCINntvTyarzbmouqShwkXOlWsYEDQ
 def set_winEpisodeOrderby(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEGg):
  __addon__.setSetting('tving_orderby',cCINntvTyarzbmouqShwkXOlWsYEGg)
  cCINntvTyarzbmouqShwkXOlWsYEGi=xbmcgui.Window(10000)
  cCINntvTyarzbmouqShwkXOlWsYEGi.setProperty('TVING_M_ORDERBY',cCINntvTyarzbmouqShwkXOlWsYEGg)
 def get_winEpisodeOrderby(cCINntvTyarzbmouqShwkXOlWsYExi):
  cCINntvTyarzbmouqShwkXOlWsYEGg=__addon__.getSetting('tving_orderby')
  if cCINntvTyarzbmouqShwkXOlWsYEGg in['',cCINntvTyarzbmouqShwkXOlWsYEDd]:cCINntvTyarzbmouqShwkXOlWsYEGg='desc'
  return cCINntvTyarzbmouqShwkXOlWsYEGg
 def add_dir(cCINntvTyarzbmouqShwkXOlWsYExi,label,sublabel='',img='',infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params='',isLink=cCINntvTyarzbmouqShwkXOlWsYEDH,ContextMenu=cCINntvTyarzbmouqShwkXOlWsYEDd):
  cCINntvTyarzbmouqShwkXOlWsYEGj='%s?%s'%(cCINntvTyarzbmouqShwkXOlWsYExi._addon_url,urllib.parse.urlencode(params))
  if sublabel:cCINntvTyarzbmouqShwkXOlWsYEGL='%s < %s >'%(label,sublabel)
  else: cCINntvTyarzbmouqShwkXOlWsYEGL=label
  if not img:img='DefaultFolder.png'
  cCINntvTyarzbmouqShwkXOlWsYEGM=xbmcgui.ListItem(cCINntvTyarzbmouqShwkXOlWsYEGL)
  if cCINntvTyarzbmouqShwkXOlWsYEDJ(img)==cCINntvTyarzbmouqShwkXOlWsYEDp:
   cCINntvTyarzbmouqShwkXOlWsYEGM.setArt(img)
  else:
   cCINntvTyarzbmouqShwkXOlWsYEGM.setArt({'thumb':img,'poster':img})
  if cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.KodiVersion>=20:
   if infoLabels:cCINntvTyarzbmouqShwkXOlWsYExi.Set_InfoTag(cCINntvTyarzbmouqShwkXOlWsYEGM.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:cCINntvTyarzbmouqShwkXOlWsYEGM.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   cCINntvTyarzbmouqShwkXOlWsYEGM.setProperty('IsPlayable','true')
  if ContextMenu:cCINntvTyarzbmouqShwkXOlWsYEGM.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cCINntvTyarzbmouqShwkXOlWsYEGj,cCINntvTyarzbmouqShwkXOlWsYEGM,isFolder)
 def get_selQuality(cCINntvTyarzbmouqShwkXOlWsYExi,etype):
  try:
   cCINntvTyarzbmouqShwkXOlWsYEGf='selected_quality'
   cCINntvTyarzbmouqShwkXOlWsYEGA=[1080,720,480,360]
   cCINntvTyarzbmouqShwkXOlWsYEGP=cCINntvTyarzbmouqShwkXOlWsYEDU(__addon__.getSetting(cCINntvTyarzbmouqShwkXOlWsYEGf))
   return cCINntvTyarzbmouqShwkXOlWsYEGA[cCINntvTyarzbmouqShwkXOlWsYEGP]
  except:
   cCINntvTyarzbmouqShwkXOlWsYEDd
  return 720 
 def Set_InfoTag(cCINntvTyarzbmouqShwkXOlWsYExi,video_InfoTag:xbmc.InfoTagVideo,cCINntvTyarzbmouqShwkXOlWsYEKd):
  for cCINntvTyarzbmouqShwkXOlWsYEGV,value in cCINntvTyarzbmouqShwkXOlWsYEKd.items():
   if cCINntvTyarzbmouqShwkXOlWsYExp[cCINntvTyarzbmouqShwkXOlWsYEGV]['type']=='string':
    cCINntvTyarzbmouqShwkXOlWsYEDi(video_InfoTag,cCINntvTyarzbmouqShwkXOlWsYExp[cCINntvTyarzbmouqShwkXOlWsYEGV]['func'])(value)
   elif cCINntvTyarzbmouqShwkXOlWsYExp[cCINntvTyarzbmouqShwkXOlWsYEGV]['type']=='int':
    if cCINntvTyarzbmouqShwkXOlWsYEDJ(value)==cCINntvTyarzbmouqShwkXOlWsYEDU:
     cCINntvTyarzbmouqShwkXOlWsYEGB=cCINntvTyarzbmouqShwkXOlWsYEDU(value)
    else:
     cCINntvTyarzbmouqShwkXOlWsYEGB=0
    cCINntvTyarzbmouqShwkXOlWsYEDi(video_InfoTag,cCINntvTyarzbmouqShwkXOlWsYExp[cCINntvTyarzbmouqShwkXOlWsYEGV]['func'])(cCINntvTyarzbmouqShwkXOlWsYEGB)
   elif cCINntvTyarzbmouqShwkXOlWsYExp[cCINntvTyarzbmouqShwkXOlWsYEGV]['type']=='actor':
    if value!=[]:
     cCINntvTyarzbmouqShwkXOlWsYEDi(video_InfoTag,cCINntvTyarzbmouqShwkXOlWsYExp[cCINntvTyarzbmouqShwkXOlWsYEGV]['func'])([xbmc.Actor(name)for name in value])
   elif cCINntvTyarzbmouqShwkXOlWsYExp[cCINntvTyarzbmouqShwkXOlWsYEGV]['type']=='list':
    if cCINntvTyarzbmouqShwkXOlWsYEDJ(value)==cCINntvTyarzbmouqShwkXOlWsYEDg:
     cCINntvTyarzbmouqShwkXOlWsYEDi(video_InfoTag,cCINntvTyarzbmouqShwkXOlWsYExp[cCINntvTyarzbmouqShwkXOlWsYEGV]['func'])(value)
    else:
     cCINntvTyarzbmouqShwkXOlWsYEDi(video_InfoTag,cCINntvTyarzbmouqShwkXOlWsYExp[cCINntvTyarzbmouqShwkXOlWsYEGV]['func'])([value])
 def dp_Main_List(cCINntvTyarzbmouqShwkXOlWsYExi):
  (cCINntvTyarzbmouqShwkXOlWsYEGU,cCINntvTyarzbmouqShwkXOlWsYEGH,cCINntvTyarzbmouqShwkXOlWsYEGQ,cCINntvTyarzbmouqShwkXOlWsYEGJ,cCINntvTyarzbmouqShwkXOlWsYEGD)=cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_totalsearch()
  for cCINntvTyarzbmouqShwkXOlWsYEGe in cCINntvTyarzbmouqShwkXOlWsYExK:
   cCINntvTyarzbmouqShwkXOlWsYEGL=cCINntvTyarzbmouqShwkXOlWsYEGe.get('title')
   cCINntvTyarzbmouqShwkXOlWsYEGR=''
   if cCINntvTyarzbmouqShwkXOlWsYEGe.get('mode')=='SEARCH_GROUP' and cCINntvTyarzbmouqShwkXOlWsYEGU ==cCINntvTyarzbmouqShwkXOlWsYEDH:continue
   elif cCINntvTyarzbmouqShwkXOlWsYEGe.get('mode')=='SEARCH_HISTORY' and cCINntvTyarzbmouqShwkXOlWsYEGH==cCINntvTyarzbmouqShwkXOlWsYEDH:continue
   elif cCINntvTyarzbmouqShwkXOlWsYEGe.get('mode')=='TOTAL_SEARCH' and cCINntvTyarzbmouqShwkXOlWsYEGQ ==cCINntvTyarzbmouqShwkXOlWsYEDH:continue
   elif cCINntvTyarzbmouqShwkXOlWsYEGe.get('mode')=='TOTAL_HISTORY' and cCINntvTyarzbmouqShwkXOlWsYEGJ==cCINntvTyarzbmouqShwkXOlWsYEDH:continue
   elif cCINntvTyarzbmouqShwkXOlWsYEGe.get('mode')=='MENU_BOOKMARK' and cCINntvTyarzbmouqShwkXOlWsYEGD==cCINntvTyarzbmouqShwkXOlWsYEDH:continue
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':cCINntvTyarzbmouqShwkXOlWsYEGe.get('mode'),'stype':cCINntvTyarzbmouqShwkXOlWsYEGe.get('stype'),'orderby':cCINntvTyarzbmouqShwkXOlWsYEGe.get('orderby'),'ordernm':cCINntvTyarzbmouqShwkXOlWsYEGe.get('ordernm'),'page':'1','bandKey':cCINntvTyarzbmouqShwkXOlWsYEGe.get('bandKey'),'bandGroup':cCINntvTyarzbmouqShwkXOlWsYEGe.get('bandGroup'),'nextApiUrl':'-',}
   if cCINntvTyarzbmouqShwkXOlWsYEGe.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    cCINntvTyarzbmouqShwkXOlWsYEKx=cCINntvTyarzbmouqShwkXOlWsYEDH
    cCINntvTyarzbmouqShwkXOlWsYEKG =cCINntvTyarzbmouqShwkXOlWsYEDQ
   else:
    cCINntvTyarzbmouqShwkXOlWsYEKx=cCINntvTyarzbmouqShwkXOlWsYEDQ
    cCINntvTyarzbmouqShwkXOlWsYEKG =cCINntvTyarzbmouqShwkXOlWsYEDH
   cCINntvTyarzbmouqShwkXOlWsYEKd={'title':cCINntvTyarzbmouqShwkXOlWsYEGL,'plot':cCINntvTyarzbmouqShwkXOlWsYEGL}
   if cCINntvTyarzbmouqShwkXOlWsYEGe.get('mode')=='XXX':cCINntvTyarzbmouqShwkXOlWsYEKd=cCINntvTyarzbmouqShwkXOlWsYEDd
   if 'icon' in cCINntvTyarzbmouqShwkXOlWsYEGe:cCINntvTyarzbmouqShwkXOlWsYEGR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',cCINntvTyarzbmouqShwkXOlWsYEGe.get('icon')) 
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel='',img=cCINntvTyarzbmouqShwkXOlWsYEGR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEKd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEKx,params=cCINntvTyarzbmouqShwkXOlWsYEGF,isLink=cCINntvTyarzbmouqShwkXOlWsYEKG)
  xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle)
 def login_main(cCINntvTyarzbmouqShwkXOlWsYExi):
  (cCINntvTyarzbmouqShwkXOlWsYEKH,cCINntvTyarzbmouqShwkXOlWsYEKQ,cCINntvTyarzbmouqShwkXOlWsYEKJ,cCINntvTyarzbmouqShwkXOlWsYEKD)=cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_account()
  if not(cCINntvTyarzbmouqShwkXOlWsYEKH and cCINntvTyarzbmouqShwkXOlWsYEKQ):
   cCINntvTyarzbmouqShwkXOlWsYExf=xbmcgui.Dialog()
   cCINntvTyarzbmouqShwkXOlWsYEKp=cCINntvTyarzbmouqShwkXOlWsYExf.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if cCINntvTyarzbmouqShwkXOlWsYEKp==cCINntvTyarzbmouqShwkXOlWsYEDQ:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if cCINntvTyarzbmouqShwkXOlWsYExi.cookiefile_check():return
  if base64.standard_b64encode(cCINntvTyarzbmouqShwkXOlWsYEKH.encode()).decode('utf-8')=='a3ltOTUxMDg4':
   cCINntvTyarzbmouqShwkXOlWsYEKi=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.GetCredential2(cCINntvTyarzbmouqShwkXOlWsYEKH,cCINntvTyarzbmouqShwkXOlWsYEKQ,cCINntvTyarzbmouqShwkXOlWsYEKJ,cCINntvTyarzbmouqShwkXOlWsYEKD)
  else:
   cCINntvTyarzbmouqShwkXOlWsYExf=xbmcgui.Dialog()
   cCINntvTyarzbmouqShwkXOlWsYEKg=cCINntvTyarzbmouqShwkXOlWsYExf.browse(1,__language__(30917).encode('utf8'),'','.twc',cCINntvTyarzbmouqShwkXOlWsYEDH,cCINntvTyarzbmouqShwkXOlWsYEDH,'',cCINntvTyarzbmouqShwkXOlWsYEDH)
   if cCINntvTyarzbmouqShwkXOlWsYEKg!='':
    cCINntvTyarzbmouqShwkXOlWsYEKj=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'))
    xbmcvfs.copy(cCINntvTyarzbmouqShwkXOlWsYEKg,cCINntvTyarzbmouqShwkXOlWsYEKj)
    cCINntvTyarzbmouqShwkXOlWsYEKi=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.WebCookies_Load(cCINntvTyarzbmouqShwkXOlWsYEKj)
    xbmcvfs.delete(cCINntvTyarzbmouqShwkXOlWsYEKj)
    if cCINntvTyarzbmouqShwkXOlWsYEKi:
     cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.JsonFile_Save(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_COOKIE_FILENAME,cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV)
     cCINntvTyarzbmouqShwkXOlWsYExi.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    cCINntvTyarzbmouqShwkXOlWsYEKi=cCINntvTyarzbmouqShwkXOlWsYEDH
  if cCINntvTyarzbmouqShwkXOlWsYEKi==cCINntvTyarzbmouqShwkXOlWsYEDQ:
   cCINntvTyarzbmouqShwkXOlWsYExi.cookiefile_save()
  else:
   cCINntvTyarzbmouqShwkXOlWsYExi.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEKL=cCINntvTyarzbmouqShwkXOlWsYEKA.get('stype')
  if cCINntvTyarzbmouqShwkXOlWsYEKL=='live':
   cCINntvTyarzbmouqShwkXOlWsYEKM=cCINntvTyarzbmouqShwkXOlWsYExd
  elif cCINntvTyarzbmouqShwkXOlWsYEKL=='vod':
   cCINntvTyarzbmouqShwkXOlWsYEKM=cCINntvTyarzbmouqShwkXOlWsYExQ
  else:
   cCINntvTyarzbmouqShwkXOlWsYEKM=cCINntvTyarzbmouqShwkXOlWsYExJ
  for cCINntvTyarzbmouqShwkXOlWsYEKf in cCINntvTyarzbmouqShwkXOlWsYEKM:
   cCINntvTyarzbmouqShwkXOlWsYEGL=cCINntvTyarzbmouqShwkXOlWsYEKf.get('title')
   if cCINntvTyarzbmouqShwkXOlWsYEKA.get('ordernm')!='-':
    cCINntvTyarzbmouqShwkXOlWsYEGL+='  ('+cCINntvTyarzbmouqShwkXOlWsYEKA.get('ordernm')+')'
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':cCINntvTyarzbmouqShwkXOlWsYEKf.get('mode'),'stype':cCINntvTyarzbmouqShwkXOlWsYEKf.get('stype'),'orderby':cCINntvTyarzbmouqShwkXOlWsYEKA.get('orderby'),'ordernm':cCINntvTyarzbmouqShwkXOlWsYEKA.get('ordernm'),'page':'1'}
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel='',img='',infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  if cCINntvTyarzbmouqShwkXOlWsYEDj(cCINntvTyarzbmouqShwkXOlWsYEKM)>0:xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle)
 def dp_SubTitle_Group(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA): 
  for cCINntvTyarzbmouqShwkXOlWsYEKf in cCINntvTyarzbmouqShwkXOlWsYExD:
   cCINntvTyarzbmouqShwkXOlWsYEGL=cCINntvTyarzbmouqShwkXOlWsYEKf.get('title')
   if cCINntvTyarzbmouqShwkXOlWsYEKA.get('ordernm')!='-':
    cCINntvTyarzbmouqShwkXOlWsYEGL+='  ('+cCINntvTyarzbmouqShwkXOlWsYEKA.get('ordernm')+')'
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':cCINntvTyarzbmouqShwkXOlWsYEKf.get('mode'),'genreCode':cCINntvTyarzbmouqShwkXOlWsYEKf.get('genreCode'),'stype':cCINntvTyarzbmouqShwkXOlWsYEKA.get('stype'),'orderby':cCINntvTyarzbmouqShwkXOlWsYEKA.get('orderby'),'page':'1'}
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel='',img='',infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  if cCINntvTyarzbmouqShwkXOlWsYEDj(cCINntvTyarzbmouqShwkXOlWsYExD)>0:xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle)
 def dp_LiveChannel_List(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEKL =cCINntvTyarzbmouqShwkXOlWsYEKA.get('stype')
  cCINntvTyarzbmouqShwkXOlWsYEKP =cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYEKA.get('page'))
  cCINntvTyarzbmouqShwkXOlWsYEKV,cCINntvTyarzbmouqShwkXOlWsYEKB=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.GetLiveChannelList(cCINntvTyarzbmouqShwkXOlWsYEKL,cCINntvTyarzbmouqShwkXOlWsYEKP)
  for cCINntvTyarzbmouqShwkXOlWsYEKe in cCINntvTyarzbmouqShwkXOlWsYEKV:
   cCINntvTyarzbmouqShwkXOlWsYEGL =cCINntvTyarzbmouqShwkXOlWsYEKe.get('title')
   cCINntvTyarzbmouqShwkXOlWsYEKU =cCINntvTyarzbmouqShwkXOlWsYEKe.get('channel')
   cCINntvTyarzbmouqShwkXOlWsYEKR =cCINntvTyarzbmouqShwkXOlWsYEKe.get('thumbnail')
   cCINntvTyarzbmouqShwkXOlWsYEKF =cCINntvTyarzbmouqShwkXOlWsYEKe.get('synopsis')
   cCINntvTyarzbmouqShwkXOlWsYEdx =cCINntvTyarzbmouqShwkXOlWsYEKe.get('channelepg')
   cCINntvTyarzbmouqShwkXOlWsYEdG =cCINntvTyarzbmouqShwkXOlWsYEKe.get('cast')
   cCINntvTyarzbmouqShwkXOlWsYEdK =cCINntvTyarzbmouqShwkXOlWsYEKe.get('director')
   cCINntvTyarzbmouqShwkXOlWsYEdU =cCINntvTyarzbmouqShwkXOlWsYEKe.get('info_genre')
   cCINntvTyarzbmouqShwkXOlWsYEdH =cCINntvTyarzbmouqShwkXOlWsYEKe.get('year')
   cCINntvTyarzbmouqShwkXOlWsYEdQ =cCINntvTyarzbmouqShwkXOlWsYEKe.get('mpaa')
   cCINntvTyarzbmouqShwkXOlWsYEdJ =cCINntvTyarzbmouqShwkXOlWsYEKe.get('premiered')
   cCINntvTyarzbmouqShwkXOlWsYEdD={'mediatype':'episode','title':cCINntvTyarzbmouqShwkXOlWsYEGL,'studio':cCINntvTyarzbmouqShwkXOlWsYEKU,'cast':cCINntvTyarzbmouqShwkXOlWsYEdG,'director':cCINntvTyarzbmouqShwkXOlWsYEdK,'genre':cCINntvTyarzbmouqShwkXOlWsYEdU,'plot':'%s\n%s\n%s\n\n%s'%(cCINntvTyarzbmouqShwkXOlWsYEKU,cCINntvTyarzbmouqShwkXOlWsYEGL,cCINntvTyarzbmouqShwkXOlWsYEdx,cCINntvTyarzbmouqShwkXOlWsYEKF),'year':cCINntvTyarzbmouqShwkXOlWsYEdH,'mpaa':cCINntvTyarzbmouqShwkXOlWsYEdQ,'premiered':cCINntvTyarzbmouqShwkXOlWsYEdJ}
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'LIVE','mediacode':cCINntvTyarzbmouqShwkXOlWsYEKe.get('mediacode'),'stype':cCINntvTyarzbmouqShwkXOlWsYEKL}
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEKU,sublabel=cCINntvTyarzbmouqShwkXOlWsYEGL,img=cCINntvTyarzbmouqShwkXOlWsYEKR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDH,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  if cCINntvTyarzbmouqShwkXOlWsYEKB:
   cCINntvTyarzbmouqShwkXOlWsYEGF['mode']='CHANNEL' 
   cCINntvTyarzbmouqShwkXOlWsYEGF['stype']=cCINntvTyarzbmouqShwkXOlWsYEKL 
   cCINntvTyarzbmouqShwkXOlWsYEGF['page']=cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGL='[B]%s >>[/B]'%'다음 페이지'
   cCINntvTyarzbmouqShwkXOlWsYEdp=cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEdp,img=cCINntvTyarzbmouqShwkXOlWsYEGR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  if cCINntvTyarzbmouqShwkXOlWsYEDj(cCINntvTyarzbmouqShwkXOlWsYEKV)>0:xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDH)
 def dp_Program_List(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEdi =cCINntvTyarzbmouqShwkXOlWsYEKA.get('stype')
  cCINntvTyarzbmouqShwkXOlWsYEGg =cCINntvTyarzbmouqShwkXOlWsYEKA.get('orderby')
  cCINntvTyarzbmouqShwkXOlWsYEKP =cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYEKA.get('page'))
  cCINntvTyarzbmouqShwkXOlWsYEdg=cCINntvTyarzbmouqShwkXOlWsYEKA.get('genreCode')
  if cCINntvTyarzbmouqShwkXOlWsYEdg==cCINntvTyarzbmouqShwkXOlWsYEDd:cCINntvTyarzbmouqShwkXOlWsYEdg='all'
  cCINntvTyarzbmouqShwkXOlWsYEdj,cCINntvTyarzbmouqShwkXOlWsYEKB=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.GetProgramList(cCINntvTyarzbmouqShwkXOlWsYEdi,cCINntvTyarzbmouqShwkXOlWsYEGg,cCINntvTyarzbmouqShwkXOlWsYEKP,cCINntvTyarzbmouqShwkXOlWsYEdg)
  for cCINntvTyarzbmouqShwkXOlWsYEdL in cCINntvTyarzbmouqShwkXOlWsYEdj:
   cCINntvTyarzbmouqShwkXOlWsYEGL =cCINntvTyarzbmouqShwkXOlWsYEdL.get('title')
   cCINntvTyarzbmouqShwkXOlWsYEKR =cCINntvTyarzbmouqShwkXOlWsYEdL.get('thumbnail')
   cCINntvTyarzbmouqShwkXOlWsYEKF =cCINntvTyarzbmouqShwkXOlWsYEdL.get('synopsis')
   cCINntvTyarzbmouqShwkXOlWsYEdM =cCINntvTyarzbmouqShwkXOlWsYEdL.get('channel')
   cCINntvTyarzbmouqShwkXOlWsYEdG =cCINntvTyarzbmouqShwkXOlWsYEdL.get('cast')
   cCINntvTyarzbmouqShwkXOlWsYEdK =cCINntvTyarzbmouqShwkXOlWsYEdL.get('director')
   cCINntvTyarzbmouqShwkXOlWsYEdU=cCINntvTyarzbmouqShwkXOlWsYEdL.get('info_genre')
   cCINntvTyarzbmouqShwkXOlWsYEdH =cCINntvTyarzbmouqShwkXOlWsYEdL.get('year')
   cCINntvTyarzbmouqShwkXOlWsYEdJ =cCINntvTyarzbmouqShwkXOlWsYEdL.get('premiered')
   cCINntvTyarzbmouqShwkXOlWsYEdQ =cCINntvTyarzbmouqShwkXOlWsYEdL.get('mpaa')
   cCINntvTyarzbmouqShwkXOlWsYEdD={'mediatype':'tvshow','title':cCINntvTyarzbmouqShwkXOlWsYEGL,'studio':cCINntvTyarzbmouqShwkXOlWsYEdM,'cast':cCINntvTyarzbmouqShwkXOlWsYEdG,'director':cCINntvTyarzbmouqShwkXOlWsYEdK,'genre':cCINntvTyarzbmouqShwkXOlWsYEdU,'year':cCINntvTyarzbmouqShwkXOlWsYEdH,'premiered':cCINntvTyarzbmouqShwkXOlWsYEdJ,'mpaa':cCINntvTyarzbmouqShwkXOlWsYEdQ,'plot':cCINntvTyarzbmouqShwkXOlWsYEKF}
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'EPISODE','programcode':cCINntvTyarzbmouqShwkXOlWsYEdL.get('program'),'page':'1'}
   if cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_makebookmark():
    cCINntvTyarzbmouqShwkXOlWsYEdf={'videoid':cCINntvTyarzbmouqShwkXOlWsYEdL.get('program'),'vidtype':'tvshow','vtitle':cCINntvTyarzbmouqShwkXOlWsYEGL,'vsubtitle':cCINntvTyarzbmouqShwkXOlWsYEdM,}
    cCINntvTyarzbmouqShwkXOlWsYEdA=json.dumps(cCINntvTyarzbmouqShwkXOlWsYEdf)
    cCINntvTyarzbmouqShwkXOlWsYEdA=urllib.parse.quote(cCINntvTyarzbmouqShwkXOlWsYEdA)
    cCINntvTyarzbmouqShwkXOlWsYEdP='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(cCINntvTyarzbmouqShwkXOlWsYEdA)
    cCINntvTyarzbmouqShwkXOlWsYEdV=[('(통합) 찜 영상에 추가',cCINntvTyarzbmouqShwkXOlWsYEdP)]
   else:
    cCINntvTyarzbmouqShwkXOlWsYEdV=cCINntvTyarzbmouqShwkXOlWsYEDd
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEdM,img=cCINntvTyarzbmouqShwkXOlWsYEKR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF,ContextMenu=cCINntvTyarzbmouqShwkXOlWsYEdV)
  if cCINntvTyarzbmouqShwkXOlWsYEKB:
   cCINntvTyarzbmouqShwkXOlWsYEGF['mode'] ='PROGRAM' 
   cCINntvTyarzbmouqShwkXOlWsYEGF['stype'] =cCINntvTyarzbmouqShwkXOlWsYEdi
   cCINntvTyarzbmouqShwkXOlWsYEGF['orderby'] =cCINntvTyarzbmouqShwkXOlWsYEGg
   cCINntvTyarzbmouqShwkXOlWsYEGF['page'] =cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGF['genreCode']=cCINntvTyarzbmouqShwkXOlWsYEdg 
   cCINntvTyarzbmouqShwkXOlWsYEGL='[B]%s >>[/B]'%'다음 페이지'
   cCINntvTyarzbmouqShwkXOlWsYEdp=cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEdp,img=cCINntvTyarzbmouqShwkXOlWsYEGR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  xbmcplugin.setContent(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDH)
 def dp_4K_Program_List(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEKP =cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYEKA.get('page'))
  cCINntvTyarzbmouqShwkXOlWsYEdj,cCINntvTyarzbmouqShwkXOlWsYEKB=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Get_UHD_ProgramList(cCINntvTyarzbmouqShwkXOlWsYEKP)
  for cCINntvTyarzbmouqShwkXOlWsYEdL in cCINntvTyarzbmouqShwkXOlWsYEdj:
   cCINntvTyarzbmouqShwkXOlWsYEGL =cCINntvTyarzbmouqShwkXOlWsYEdL.get('title')
   cCINntvTyarzbmouqShwkXOlWsYEKR =cCINntvTyarzbmouqShwkXOlWsYEdL.get('thumbnail')
   cCINntvTyarzbmouqShwkXOlWsYEKF =cCINntvTyarzbmouqShwkXOlWsYEdL.get('synopsis')
   cCINntvTyarzbmouqShwkXOlWsYEdM =cCINntvTyarzbmouqShwkXOlWsYEdL.get('channel')
   cCINntvTyarzbmouqShwkXOlWsYEdG =cCINntvTyarzbmouqShwkXOlWsYEdL.get('cast')
   cCINntvTyarzbmouqShwkXOlWsYEdK =cCINntvTyarzbmouqShwkXOlWsYEdL.get('director')
   cCINntvTyarzbmouqShwkXOlWsYEdU=cCINntvTyarzbmouqShwkXOlWsYEdL.get('info_genre')
   cCINntvTyarzbmouqShwkXOlWsYEdH =cCINntvTyarzbmouqShwkXOlWsYEdL.get('year')
   cCINntvTyarzbmouqShwkXOlWsYEdJ =cCINntvTyarzbmouqShwkXOlWsYEdL.get('premiered')
   cCINntvTyarzbmouqShwkXOlWsYEdQ =cCINntvTyarzbmouqShwkXOlWsYEdL.get('mpaa')
   cCINntvTyarzbmouqShwkXOlWsYEdD={'mediatype':'tvshow','title':cCINntvTyarzbmouqShwkXOlWsYEGL,'studio':cCINntvTyarzbmouqShwkXOlWsYEdM,'cast':cCINntvTyarzbmouqShwkXOlWsYEdG,'director':cCINntvTyarzbmouqShwkXOlWsYEdK,'genre':cCINntvTyarzbmouqShwkXOlWsYEdU,'year':cCINntvTyarzbmouqShwkXOlWsYEdH,'premiered':cCINntvTyarzbmouqShwkXOlWsYEdJ,'mpaa':cCINntvTyarzbmouqShwkXOlWsYEdQ,'plot':cCINntvTyarzbmouqShwkXOlWsYEKF}
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'EPISODE','programcode':cCINntvTyarzbmouqShwkXOlWsYEdL.get('program'),'page':'1'}
   if cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_makebookmark():
    cCINntvTyarzbmouqShwkXOlWsYEdf={'videoid':cCINntvTyarzbmouqShwkXOlWsYEdL.get('program'),'vidtype':'tvshow','vtitle':cCINntvTyarzbmouqShwkXOlWsYEGL,'vsubtitle':cCINntvTyarzbmouqShwkXOlWsYEdM,}
    cCINntvTyarzbmouqShwkXOlWsYEdA=json.dumps(cCINntvTyarzbmouqShwkXOlWsYEdf)
    cCINntvTyarzbmouqShwkXOlWsYEdA=urllib.parse.quote(cCINntvTyarzbmouqShwkXOlWsYEdA)
    cCINntvTyarzbmouqShwkXOlWsYEdP='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(cCINntvTyarzbmouqShwkXOlWsYEdA)
    cCINntvTyarzbmouqShwkXOlWsYEdV=[('(통합) 찜 영상에 추가',cCINntvTyarzbmouqShwkXOlWsYEdP)]
   else:
    cCINntvTyarzbmouqShwkXOlWsYEdV=cCINntvTyarzbmouqShwkXOlWsYEDd
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEdM,img=cCINntvTyarzbmouqShwkXOlWsYEKR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF,ContextMenu=cCINntvTyarzbmouqShwkXOlWsYEdV)
  if cCINntvTyarzbmouqShwkXOlWsYEKB:
   cCINntvTyarzbmouqShwkXOlWsYEGF['mode'] ='4K_PROGRAM' 
   cCINntvTyarzbmouqShwkXOlWsYEGF['page'] =cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGL='[B]%s >>[/B]'%'다음 페이지'
   cCINntvTyarzbmouqShwkXOlWsYEdp=cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEdp,img=cCINntvTyarzbmouqShwkXOlWsYEGR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  xbmcplugin.setContent(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDH)
 def dp_Ori_Program_List(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEKP =cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYEKA.get('page'))
  cCINntvTyarzbmouqShwkXOlWsYEdj,cCINntvTyarzbmouqShwkXOlWsYEKB=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Get_Origianl_ProgramList(cCINntvTyarzbmouqShwkXOlWsYEKP)
  for cCINntvTyarzbmouqShwkXOlWsYEdL in cCINntvTyarzbmouqShwkXOlWsYEdj:
   cCINntvTyarzbmouqShwkXOlWsYEGL =cCINntvTyarzbmouqShwkXOlWsYEdL.get('title')
   cCINntvTyarzbmouqShwkXOlWsYEKR =cCINntvTyarzbmouqShwkXOlWsYEdL.get('thumbnail')
   cCINntvTyarzbmouqShwkXOlWsYEde =cCINntvTyarzbmouqShwkXOlWsYEdL.get('vod_type')
   cCINntvTyarzbmouqShwkXOlWsYEdR =cCINntvTyarzbmouqShwkXOlWsYEdL.get('vod_code')
   if cCINntvTyarzbmouqShwkXOlWsYEde=='vod':
    cCINntvTyarzbmouqShwkXOlWsYEdD={'mediatype':'tvshow','title':cCINntvTyarzbmouqShwkXOlWsYEGL,}
    cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'EPISODE','programcode':cCINntvTyarzbmouqShwkXOlWsYEdR,'page':'1',}
    cCINntvTyarzbmouqShwkXOlWsYEKx=cCINntvTyarzbmouqShwkXOlWsYEDQ
   else:
    cCINntvTyarzbmouqShwkXOlWsYEdD={'mediatype':'movie','title':cCINntvTyarzbmouqShwkXOlWsYEGL,'plot':'movie',}
    cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'MOVIE','mediacode':cCINntvTyarzbmouqShwkXOlWsYEdR,'stype':'movie','title':cCINntvTyarzbmouqShwkXOlWsYEGL,'thumbnail':cCINntvTyarzbmouqShwkXOlWsYEKR,}
    cCINntvTyarzbmouqShwkXOlWsYEKx=cCINntvTyarzbmouqShwkXOlWsYEDH
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEDd,img=cCINntvTyarzbmouqShwkXOlWsYEKR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEKx,params=cCINntvTyarzbmouqShwkXOlWsYEGF,ContextMenu=cCINntvTyarzbmouqShwkXOlWsYEDd)
  if cCINntvTyarzbmouqShwkXOlWsYEKB:
   cCINntvTyarzbmouqShwkXOlWsYEGF['mode'] ='ORI_PROGRAM' 
   cCINntvTyarzbmouqShwkXOlWsYEGF['page'] =cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGL='[B]%s >>[/B]'%'다음 페이지'
   cCINntvTyarzbmouqShwkXOlWsYEdp=cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEdp,img=cCINntvTyarzbmouqShwkXOlWsYEGR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  xbmcplugin.setContent(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDH)
 def dp_Episode_List(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEdF=cCINntvTyarzbmouqShwkXOlWsYEKA.get('programcode')
  cCINntvTyarzbmouqShwkXOlWsYEKP =cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYEKA.get('page'))
  cCINntvTyarzbmouqShwkXOlWsYExi.addon_log('programcode : '+cCINntvTyarzbmouqShwkXOlWsYEdF)
  cCINntvTyarzbmouqShwkXOlWsYEUx,cCINntvTyarzbmouqShwkXOlWsYEKB,cCINntvTyarzbmouqShwkXOlWsYEUG=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.GetEpisodeList(cCINntvTyarzbmouqShwkXOlWsYEdF,cCINntvTyarzbmouqShwkXOlWsYEKP,orderby=cCINntvTyarzbmouqShwkXOlWsYExi.get_winEpisodeOrderby())
  for cCINntvTyarzbmouqShwkXOlWsYEUK in cCINntvTyarzbmouqShwkXOlWsYEUx:
   cCINntvTyarzbmouqShwkXOlWsYEGL =cCINntvTyarzbmouqShwkXOlWsYEUK.get('title')
   cCINntvTyarzbmouqShwkXOlWsYEdp =cCINntvTyarzbmouqShwkXOlWsYEUK.get('subtitle')
   cCINntvTyarzbmouqShwkXOlWsYEKR =cCINntvTyarzbmouqShwkXOlWsYEUK.get('thumbnail')
   cCINntvTyarzbmouqShwkXOlWsYEKF =cCINntvTyarzbmouqShwkXOlWsYEUK.get('synopsis')
   cCINntvTyarzbmouqShwkXOlWsYEUd=cCINntvTyarzbmouqShwkXOlWsYEUK.get('info_title')
   cCINntvTyarzbmouqShwkXOlWsYEUH =cCINntvTyarzbmouqShwkXOlWsYEUK.get('aired')
   cCINntvTyarzbmouqShwkXOlWsYEUQ =cCINntvTyarzbmouqShwkXOlWsYEUK.get('studio')
   cCINntvTyarzbmouqShwkXOlWsYEUJ =cCINntvTyarzbmouqShwkXOlWsYEUK.get('frequency')
   cCINntvTyarzbmouqShwkXOlWsYEdD={'mediatype':'episode','title':cCINntvTyarzbmouqShwkXOlWsYEUd,'aired':cCINntvTyarzbmouqShwkXOlWsYEUH,'studio':cCINntvTyarzbmouqShwkXOlWsYEUQ,'episode':cCINntvTyarzbmouqShwkXOlWsYEUJ,'plot':cCINntvTyarzbmouqShwkXOlWsYEKF}
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'VOD','mediacode':cCINntvTyarzbmouqShwkXOlWsYEUK.get('episode'),'stype':'vod','programcode':cCINntvTyarzbmouqShwkXOlWsYEdF,'title':cCINntvTyarzbmouqShwkXOlWsYEGL,'thumbnail':cCINntvTyarzbmouqShwkXOlWsYEKR}
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEdp,img=cCINntvTyarzbmouqShwkXOlWsYEKR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDH,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  if cCINntvTyarzbmouqShwkXOlWsYEKP==1:
   cCINntvTyarzbmouqShwkXOlWsYEdD={'plot':'정렬순서를 변경합니다.'}
   cCINntvTyarzbmouqShwkXOlWsYEGF={}
   cCINntvTyarzbmouqShwkXOlWsYEGF['mode'] ='ORDER_BY' 
   if cCINntvTyarzbmouqShwkXOlWsYExi.get_winEpisodeOrderby()=='desc':
    cCINntvTyarzbmouqShwkXOlWsYEGL='정렬순서변경 : 최신화부터 -> 1회부터'
    cCINntvTyarzbmouqShwkXOlWsYEGF['orderby']='asc'
   else:
    cCINntvTyarzbmouqShwkXOlWsYEGL='정렬순서변경 : 1회부터 -> 최신화부터'
    cCINntvTyarzbmouqShwkXOlWsYEGF['orderby']='desc'
   cCINntvTyarzbmouqShwkXOlWsYEGR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel='',img=cCINntvTyarzbmouqShwkXOlWsYEGR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDH,params=cCINntvTyarzbmouqShwkXOlWsYEGF,isLink=cCINntvTyarzbmouqShwkXOlWsYEDQ)
  if cCINntvTyarzbmouqShwkXOlWsYEKB:
   cCINntvTyarzbmouqShwkXOlWsYEGF['mode'] ='EPISODE' 
   cCINntvTyarzbmouqShwkXOlWsYEGF['programcode']=cCINntvTyarzbmouqShwkXOlWsYEdF
   cCINntvTyarzbmouqShwkXOlWsYEGF['page'] =cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGL='[B]%s >>[/B]'%'다음 페이지'
   cCINntvTyarzbmouqShwkXOlWsYEdp=cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEdp,img=cCINntvTyarzbmouqShwkXOlWsYEGR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  xbmcplugin.setContent(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,'episodes')
  if cCINntvTyarzbmouqShwkXOlWsYEDj(cCINntvTyarzbmouqShwkXOlWsYEUx)>0:xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDQ)
 def dp_setEpOrderby(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEGg =cCINntvTyarzbmouqShwkXOlWsYEKA.get('orderby')
  cCINntvTyarzbmouqShwkXOlWsYExi.set_winEpisodeOrderby(cCINntvTyarzbmouqShwkXOlWsYEGg)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEdi =cCINntvTyarzbmouqShwkXOlWsYEKA.get('stype')
  cCINntvTyarzbmouqShwkXOlWsYEGg =cCINntvTyarzbmouqShwkXOlWsYEKA.get('orderby')
  cCINntvTyarzbmouqShwkXOlWsYEKP=cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYEKA.get('page'))
  cCINntvTyarzbmouqShwkXOlWsYEUD,cCINntvTyarzbmouqShwkXOlWsYEKB=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.GetMovieList(cCINntvTyarzbmouqShwkXOlWsYEdi,cCINntvTyarzbmouqShwkXOlWsYEGg,cCINntvTyarzbmouqShwkXOlWsYEKP)
  for cCINntvTyarzbmouqShwkXOlWsYEUp in cCINntvTyarzbmouqShwkXOlWsYEUD:
   cCINntvTyarzbmouqShwkXOlWsYEGL =cCINntvTyarzbmouqShwkXOlWsYEUp.get('title')
   cCINntvTyarzbmouqShwkXOlWsYEKR =cCINntvTyarzbmouqShwkXOlWsYEUp.get('thumbnail')
   cCINntvTyarzbmouqShwkXOlWsYEKF =cCINntvTyarzbmouqShwkXOlWsYEUp.get('synopsis')
   cCINntvTyarzbmouqShwkXOlWsYEUd =cCINntvTyarzbmouqShwkXOlWsYEUp.get('info_title')
   cCINntvTyarzbmouqShwkXOlWsYEdH =cCINntvTyarzbmouqShwkXOlWsYEUp.get('year')
   cCINntvTyarzbmouqShwkXOlWsYEdG =cCINntvTyarzbmouqShwkXOlWsYEUp.get('cast')
   cCINntvTyarzbmouqShwkXOlWsYEdK =cCINntvTyarzbmouqShwkXOlWsYEUp.get('director')
   cCINntvTyarzbmouqShwkXOlWsYEdU =cCINntvTyarzbmouqShwkXOlWsYEUp.get('info_genre')
   cCINntvTyarzbmouqShwkXOlWsYEUi =cCINntvTyarzbmouqShwkXOlWsYEUp.get('duration')
   cCINntvTyarzbmouqShwkXOlWsYEdJ =cCINntvTyarzbmouqShwkXOlWsYEUp.get('premiered')
   cCINntvTyarzbmouqShwkXOlWsYEUQ =cCINntvTyarzbmouqShwkXOlWsYEUp.get('studio')
   cCINntvTyarzbmouqShwkXOlWsYEdQ =cCINntvTyarzbmouqShwkXOlWsYEUp.get('mpaa')
   cCINntvTyarzbmouqShwkXOlWsYEdD={'mediatype':'movie','title':cCINntvTyarzbmouqShwkXOlWsYEUd,'year':cCINntvTyarzbmouqShwkXOlWsYEdH,'cast':cCINntvTyarzbmouqShwkXOlWsYEdG,'director':cCINntvTyarzbmouqShwkXOlWsYEdK,'genre':cCINntvTyarzbmouqShwkXOlWsYEdU,'duration':cCINntvTyarzbmouqShwkXOlWsYEUi,'premiered':cCINntvTyarzbmouqShwkXOlWsYEdJ,'studio':cCINntvTyarzbmouqShwkXOlWsYEUQ,'mpaa':cCINntvTyarzbmouqShwkXOlWsYEdQ,'plot':cCINntvTyarzbmouqShwkXOlWsYEKF}
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'MOVIE','mediacode':cCINntvTyarzbmouqShwkXOlWsYEUp.get('moviecode'),'stype':'movie','title':cCINntvTyarzbmouqShwkXOlWsYEGL,'thumbnail':cCINntvTyarzbmouqShwkXOlWsYEKR}
   if cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_makebookmark():
    cCINntvTyarzbmouqShwkXOlWsYEdf={'videoid':cCINntvTyarzbmouqShwkXOlWsYEUp.get('moviecode'),'vidtype':'movie','vtitle':cCINntvTyarzbmouqShwkXOlWsYEUd,'vsubtitle':'',}
    cCINntvTyarzbmouqShwkXOlWsYEdA=json.dumps(cCINntvTyarzbmouqShwkXOlWsYEdf)
    cCINntvTyarzbmouqShwkXOlWsYEdA=urllib.parse.quote(cCINntvTyarzbmouqShwkXOlWsYEdA)
    cCINntvTyarzbmouqShwkXOlWsYEdP='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(cCINntvTyarzbmouqShwkXOlWsYEdA)
    cCINntvTyarzbmouqShwkXOlWsYEdV=[('(통합) 찜 영상에 추가',cCINntvTyarzbmouqShwkXOlWsYEdP)]
   else:
    cCINntvTyarzbmouqShwkXOlWsYEdV=cCINntvTyarzbmouqShwkXOlWsYEDd
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel='',img=cCINntvTyarzbmouqShwkXOlWsYEKR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDH,params=cCINntvTyarzbmouqShwkXOlWsYEGF,ContextMenu=cCINntvTyarzbmouqShwkXOlWsYEdV)
  if cCINntvTyarzbmouqShwkXOlWsYEKB:
   cCINntvTyarzbmouqShwkXOlWsYEGF={}
   cCINntvTyarzbmouqShwkXOlWsYEGF['mode'] ='MOVIE_SUB' 
   cCINntvTyarzbmouqShwkXOlWsYEGF['orderby']=cCINntvTyarzbmouqShwkXOlWsYEGg
   cCINntvTyarzbmouqShwkXOlWsYEGF['stype'] =cCINntvTyarzbmouqShwkXOlWsYEdi
   cCINntvTyarzbmouqShwkXOlWsYEGF['page'] =cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGL='[B]%s >>[/B]'%'다음 페이지'
   cCINntvTyarzbmouqShwkXOlWsYEdp=cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEdp,img=cCINntvTyarzbmouqShwkXOlWsYEGR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  xbmcplugin.setContent(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,'movies')
  xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDH)
 def dp_4K_Movie_List(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEKP=cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYEKA.get('page'))
  cCINntvTyarzbmouqShwkXOlWsYEUD,cCINntvTyarzbmouqShwkXOlWsYEKB=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Get_UHD_MovieList(cCINntvTyarzbmouqShwkXOlWsYEKP)
  for cCINntvTyarzbmouqShwkXOlWsYEUp in cCINntvTyarzbmouqShwkXOlWsYEUD:
   cCINntvTyarzbmouqShwkXOlWsYEGL =cCINntvTyarzbmouqShwkXOlWsYEUp.get('title')
   cCINntvTyarzbmouqShwkXOlWsYEKR =cCINntvTyarzbmouqShwkXOlWsYEUp.get('thumbnail')
   cCINntvTyarzbmouqShwkXOlWsYEKF =cCINntvTyarzbmouqShwkXOlWsYEUp.get('synopsis')
   cCINntvTyarzbmouqShwkXOlWsYEUd =cCINntvTyarzbmouqShwkXOlWsYEUp.get('info_title')
   cCINntvTyarzbmouqShwkXOlWsYEdH =cCINntvTyarzbmouqShwkXOlWsYEUp.get('year')
   cCINntvTyarzbmouqShwkXOlWsYEdG =cCINntvTyarzbmouqShwkXOlWsYEUp.get('cast')
   cCINntvTyarzbmouqShwkXOlWsYEdK =cCINntvTyarzbmouqShwkXOlWsYEUp.get('director')
   cCINntvTyarzbmouqShwkXOlWsYEdU =cCINntvTyarzbmouqShwkXOlWsYEUp.get('info_genre')
   cCINntvTyarzbmouqShwkXOlWsYEUi =cCINntvTyarzbmouqShwkXOlWsYEUp.get('duration')
   cCINntvTyarzbmouqShwkXOlWsYEdJ =cCINntvTyarzbmouqShwkXOlWsYEUp.get('premiered')
   cCINntvTyarzbmouqShwkXOlWsYEUQ =cCINntvTyarzbmouqShwkXOlWsYEUp.get('studio')
   cCINntvTyarzbmouqShwkXOlWsYEdQ =cCINntvTyarzbmouqShwkXOlWsYEUp.get('mpaa')
   cCINntvTyarzbmouqShwkXOlWsYEdD={'mediatype':'movie','title':cCINntvTyarzbmouqShwkXOlWsYEUd,'year':cCINntvTyarzbmouqShwkXOlWsYEdH,'cast':cCINntvTyarzbmouqShwkXOlWsYEdG,'director':cCINntvTyarzbmouqShwkXOlWsYEdK,'genre':cCINntvTyarzbmouqShwkXOlWsYEdU,'duration':cCINntvTyarzbmouqShwkXOlWsYEUi,'premiered':cCINntvTyarzbmouqShwkXOlWsYEdJ,'studio':cCINntvTyarzbmouqShwkXOlWsYEUQ,'mpaa':cCINntvTyarzbmouqShwkXOlWsYEdQ,'plot':cCINntvTyarzbmouqShwkXOlWsYEKF}
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'MOVIE','mediacode':cCINntvTyarzbmouqShwkXOlWsYEUp.get('moviecode'),'stype':'movie','title':cCINntvTyarzbmouqShwkXOlWsYEGL,'thumbnail':cCINntvTyarzbmouqShwkXOlWsYEKR}
   if cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_makebookmark():
    cCINntvTyarzbmouqShwkXOlWsYEdf={'videoid':cCINntvTyarzbmouqShwkXOlWsYEUp.get('moviecode'),'vidtype':'movie','vtitle':cCINntvTyarzbmouqShwkXOlWsYEUd,'vsubtitle':'',}
    cCINntvTyarzbmouqShwkXOlWsYEdA=json.dumps(cCINntvTyarzbmouqShwkXOlWsYEdf)
    cCINntvTyarzbmouqShwkXOlWsYEdA=urllib.parse.quote(cCINntvTyarzbmouqShwkXOlWsYEdA)
    cCINntvTyarzbmouqShwkXOlWsYEdP='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(cCINntvTyarzbmouqShwkXOlWsYEdA)
    cCINntvTyarzbmouqShwkXOlWsYEdV=[('(통합) 찜 영상에 추가',cCINntvTyarzbmouqShwkXOlWsYEdP)]
   else:
    cCINntvTyarzbmouqShwkXOlWsYEdV=cCINntvTyarzbmouqShwkXOlWsYEDd
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel='',img=cCINntvTyarzbmouqShwkXOlWsYEKR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDH,params=cCINntvTyarzbmouqShwkXOlWsYEGF,ContextMenu=cCINntvTyarzbmouqShwkXOlWsYEdV)
  if cCINntvTyarzbmouqShwkXOlWsYEKB:
   cCINntvTyarzbmouqShwkXOlWsYEGF={}
   cCINntvTyarzbmouqShwkXOlWsYEGF['mode'] ='4K_MOVIE' 
   cCINntvTyarzbmouqShwkXOlWsYEGF['page'] =cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGL='[B]%s >>[/B]'%'다음 페이지'
   cCINntvTyarzbmouqShwkXOlWsYEdp=cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEdp,img=cCINntvTyarzbmouqShwkXOlWsYEGR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  xbmcplugin.setContent(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,'movies')
  xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDH)
 def dp_Set_Bookmark(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEUg=urllib.parse.unquote(cCINntvTyarzbmouqShwkXOlWsYEKA.get('bm_param'))
  cCINntvTyarzbmouqShwkXOlWsYEUg=json.loads(cCINntvTyarzbmouqShwkXOlWsYEUg)
  cCINntvTyarzbmouqShwkXOlWsYEUj =cCINntvTyarzbmouqShwkXOlWsYEUg.get('videoid')
  cCINntvTyarzbmouqShwkXOlWsYEUL =cCINntvTyarzbmouqShwkXOlWsYEUg.get('vidtype')
  cCINntvTyarzbmouqShwkXOlWsYEUM =cCINntvTyarzbmouqShwkXOlWsYEUg.get('vtitle')
  cCINntvTyarzbmouqShwkXOlWsYEUf =cCINntvTyarzbmouqShwkXOlWsYEUg.get('vsubtitle')
  cCINntvTyarzbmouqShwkXOlWsYExf=xbmcgui.Dialog()
  cCINntvTyarzbmouqShwkXOlWsYEKp=cCINntvTyarzbmouqShwkXOlWsYExf.yesno(__language__(30913).encode('utf8'),cCINntvTyarzbmouqShwkXOlWsYEUM+' \n\n'+__language__(30914))
  if cCINntvTyarzbmouqShwkXOlWsYEKp==cCINntvTyarzbmouqShwkXOlWsYEDH:return
  cCINntvTyarzbmouqShwkXOlWsYEUA=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.GetBookmarkInfo(cCINntvTyarzbmouqShwkXOlWsYEUj,cCINntvTyarzbmouqShwkXOlWsYEUL)
  if cCINntvTyarzbmouqShwkXOlWsYEUf!='':
   cCINntvTyarzbmouqShwkXOlWsYEUA['saveinfo']['subtitle']=cCINntvTyarzbmouqShwkXOlWsYEUf 
   if cCINntvTyarzbmouqShwkXOlWsYEUL=='tvshow':cCINntvTyarzbmouqShwkXOlWsYEUA['saveinfo']['infoLabels']['studio']=cCINntvTyarzbmouqShwkXOlWsYEUf 
  cCINntvTyarzbmouqShwkXOlWsYEUP=json.dumps(cCINntvTyarzbmouqShwkXOlWsYEUA)
  cCINntvTyarzbmouqShwkXOlWsYEUP=urllib.parse.quote(cCINntvTyarzbmouqShwkXOlWsYEUP)
  cCINntvTyarzbmouqShwkXOlWsYEdP ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(cCINntvTyarzbmouqShwkXOlWsYEUP)
  xbmc.executebuiltin(cCINntvTyarzbmouqShwkXOlWsYEdP)
 def dp_Search_Group(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  if 'search_key' in cCINntvTyarzbmouqShwkXOlWsYEKA:
   cCINntvTyarzbmouqShwkXOlWsYEUV=cCINntvTyarzbmouqShwkXOlWsYEKA.get('search_key')
  else:
   cCINntvTyarzbmouqShwkXOlWsYEUV=cCINntvTyarzbmouqShwkXOlWsYExi.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not cCINntvTyarzbmouqShwkXOlWsYEUV:
    return
  for cCINntvTyarzbmouqShwkXOlWsYEKf in cCINntvTyarzbmouqShwkXOlWsYExH:
   cCINntvTyarzbmouqShwkXOlWsYEUB =cCINntvTyarzbmouqShwkXOlWsYEKf.get('mode')
   cCINntvTyarzbmouqShwkXOlWsYEKL=cCINntvTyarzbmouqShwkXOlWsYEKf.get('stype')
   cCINntvTyarzbmouqShwkXOlWsYEGL=cCINntvTyarzbmouqShwkXOlWsYEKf.get('title')
   (cCINntvTyarzbmouqShwkXOlWsYEUe,cCINntvTyarzbmouqShwkXOlWsYEKB)=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.GetSearchList(cCINntvTyarzbmouqShwkXOlWsYEUV,1,cCINntvTyarzbmouqShwkXOlWsYEKL)
   cCINntvTyarzbmouqShwkXOlWsYEKd={'plot':'검색어 : '+cCINntvTyarzbmouqShwkXOlWsYEUV+'\n\n'+cCINntvTyarzbmouqShwkXOlWsYExi.Search_FreeList(cCINntvTyarzbmouqShwkXOlWsYEUe)}
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':cCINntvTyarzbmouqShwkXOlWsYEUB,'stype':cCINntvTyarzbmouqShwkXOlWsYEKL,'search_key':cCINntvTyarzbmouqShwkXOlWsYEUV,'page':'1',}
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel='',img='',infoLabels=cCINntvTyarzbmouqShwkXOlWsYEKd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  if cCINntvTyarzbmouqShwkXOlWsYEDj(cCINntvTyarzbmouqShwkXOlWsYExH)>0:xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDQ)
  cCINntvTyarzbmouqShwkXOlWsYExi.Save_Searched_List(cCINntvTyarzbmouqShwkXOlWsYEUV)
 def Search_FreeList(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEHJ):
  cCINntvTyarzbmouqShwkXOlWsYEUR=''
  cCINntvTyarzbmouqShwkXOlWsYEUF=7
  try:
   if cCINntvTyarzbmouqShwkXOlWsYEDj(cCINntvTyarzbmouqShwkXOlWsYEHJ)==0:return '검색결과 없음'
   for i in cCINntvTyarzbmouqShwkXOlWsYEDM(cCINntvTyarzbmouqShwkXOlWsYEDj(cCINntvTyarzbmouqShwkXOlWsYEHJ)):
    if i>=cCINntvTyarzbmouqShwkXOlWsYEUF:
     cCINntvTyarzbmouqShwkXOlWsYEUR=cCINntvTyarzbmouqShwkXOlWsYEUR+'...'
     break
    cCINntvTyarzbmouqShwkXOlWsYEUR=cCINntvTyarzbmouqShwkXOlWsYEUR+cCINntvTyarzbmouqShwkXOlWsYEHJ[i]['title']+'\n'
  except:
   return ''
  return cCINntvTyarzbmouqShwkXOlWsYEUR
 def dp_Search_History(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEHx=cCINntvTyarzbmouqShwkXOlWsYExi.Load_List_File('search')
  for cCINntvTyarzbmouqShwkXOlWsYEHG in cCINntvTyarzbmouqShwkXOlWsYEHx:
   cCINntvTyarzbmouqShwkXOlWsYEHK=cCINntvTyarzbmouqShwkXOlWsYEDp(urllib.parse.parse_qsl(cCINntvTyarzbmouqShwkXOlWsYEHG))
   cCINntvTyarzbmouqShwkXOlWsYEHd=cCINntvTyarzbmouqShwkXOlWsYEHK.get('skey').strip()
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'SEARCH_GROUP','search_key':cCINntvTyarzbmouqShwkXOlWsYEHd,}
   cCINntvTyarzbmouqShwkXOlWsYEHU={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':cCINntvTyarzbmouqShwkXOlWsYEHd,'vType':'-',}
   cCINntvTyarzbmouqShwkXOlWsYEHQ=urllib.parse.urlencode(cCINntvTyarzbmouqShwkXOlWsYEHU)
   cCINntvTyarzbmouqShwkXOlWsYEdV=[('선택된 검색어 ( %s ) 삭제'%(cCINntvTyarzbmouqShwkXOlWsYEHd),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(cCINntvTyarzbmouqShwkXOlWsYEHQ))]
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEHd,sublabel='',img=cCINntvTyarzbmouqShwkXOlWsYEDd,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF,ContextMenu=cCINntvTyarzbmouqShwkXOlWsYEdV)
  cCINntvTyarzbmouqShwkXOlWsYEdD={'plot':'검색목록 전체를 삭제합니다.'}
  cCINntvTyarzbmouqShwkXOlWsYEGL='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  cCINntvTyarzbmouqShwkXOlWsYEGR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel='',img=cCINntvTyarzbmouqShwkXOlWsYEGR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDH,params=cCINntvTyarzbmouqShwkXOlWsYEGF,isLink=cCINntvTyarzbmouqShwkXOlWsYEDQ)
  xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDH)
 def dp_Search_List(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEKP =cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYEKA.get('page'))
  cCINntvTyarzbmouqShwkXOlWsYEKL =cCINntvTyarzbmouqShwkXOlWsYEKA.get('stype')
  if 'search_key' in cCINntvTyarzbmouqShwkXOlWsYEKA:
   cCINntvTyarzbmouqShwkXOlWsYEUV=cCINntvTyarzbmouqShwkXOlWsYEKA.get('search_key')
  else:
   cCINntvTyarzbmouqShwkXOlWsYEUV=cCINntvTyarzbmouqShwkXOlWsYExi.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not cCINntvTyarzbmouqShwkXOlWsYEUV:
    xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle)
    return
  cCINntvTyarzbmouqShwkXOlWsYEUe,cCINntvTyarzbmouqShwkXOlWsYEKB=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.GetSearchList(cCINntvTyarzbmouqShwkXOlWsYEUV,cCINntvTyarzbmouqShwkXOlWsYEKP,cCINntvTyarzbmouqShwkXOlWsYEKL)
  for cCINntvTyarzbmouqShwkXOlWsYEHJ in cCINntvTyarzbmouqShwkXOlWsYEUe:
   cCINntvTyarzbmouqShwkXOlWsYEGL =cCINntvTyarzbmouqShwkXOlWsYEHJ.get('title')
   cCINntvTyarzbmouqShwkXOlWsYEKR =cCINntvTyarzbmouqShwkXOlWsYEHJ.get('thumbnail')
   cCINntvTyarzbmouqShwkXOlWsYEKF =cCINntvTyarzbmouqShwkXOlWsYEHJ.get('synopsis')
   cCINntvTyarzbmouqShwkXOlWsYEHD =cCINntvTyarzbmouqShwkXOlWsYEHJ.get('program')
   cCINntvTyarzbmouqShwkXOlWsYEdG =cCINntvTyarzbmouqShwkXOlWsYEHJ.get('cast')
   cCINntvTyarzbmouqShwkXOlWsYEdK =cCINntvTyarzbmouqShwkXOlWsYEHJ.get('director')
   cCINntvTyarzbmouqShwkXOlWsYEdU=cCINntvTyarzbmouqShwkXOlWsYEHJ.get('info_genre')
   cCINntvTyarzbmouqShwkXOlWsYEUi =cCINntvTyarzbmouqShwkXOlWsYEHJ.get('duration')
   cCINntvTyarzbmouqShwkXOlWsYEdQ =cCINntvTyarzbmouqShwkXOlWsYEHJ.get('mpaa')
   cCINntvTyarzbmouqShwkXOlWsYEdH =cCINntvTyarzbmouqShwkXOlWsYEHJ.get('year')
   cCINntvTyarzbmouqShwkXOlWsYEUH =cCINntvTyarzbmouqShwkXOlWsYEHJ.get('aired')
   cCINntvTyarzbmouqShwkXOlWsYEdD={'mediatype':'tvshow' if cCINntvTyarzbmouqShwkXOlWsYEKL=='vod' else 'movie','title':cCINntvTyarzbmouqShwkXOlWsYEGL,'cast':cCINntvTyarzbmouqShwkXOlWsYEdG,'director':cCINntvTyarzbmouqShwkXOlWsYEdK,'genre':cCINntvTyarzbmouqShwkXOlWsYEdU,'duration':cCINntvTyarzbmouqShwkXOlWsYEUi,'mpaa':cCINntvTyarzbmouqShwkXOlWsYEdQ,'year':cCINntvTyarzbmouqShwkXOlWsYEdH,'aired':cCINntvTyarzbmouqShwkXOlWsYEUH,'plot':'%s\n\n%s'%(cCINntvTyarzbmouqShwkXOlWsYEGL,cCINntvTyarzbmouqShwkXOlWsYEKF)}
   if cCINntvTyarzbmouqShwkXOlWsYEKL=='vod':
    cCINntvTyarzbmouqShwkXOlWsYEUj=cCINntvTyarzbmouqShwkXOlWsYEHJ.get('program')
    cCINntvTyarzbmouqShwkXOlWsYEUL='tvshow'
    cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'EPISODE','programcode':cCINntvTyarzbmouqShwkXOlWsYEUj,'page':'1',}
    cCINntvTyarzbmouqShwkXOlWsYEKx=cCINntvTyarzbmouqShwkXOlWsYEDQ
   else:
    cCINntvTyarzbmouqShwkXOlWsYEUj=cCINntvTyarzbmouqShwkXOlWsYEHJ.get('movie')
    cCINntvTyarzbmouqShwkXOlWsYEUL='movie'
    cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'MOVIE','mediacode':cCINntvTyarzbmouqShwkXOlWsYEUj,'stype':'movie','title':cCINntvTyarzbmouqShwkXOlWsYEGL,'thumbnail':cCINntvTyarzbmouqShwkXOlWsYEKR,}
    cCINntvTyarzbmouqShwkXOlWsYEKx=cCINntvTyarzbmouqShwkXOlWsYEDH
   if cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_makebookmark():
    cCINntvTyarzbmouqShwkXOlWsYEdf={'videoid':cCINntvTyarzbmouqShwkXOlWsYEUj,'vidtype':cCINntvTyarzbmouqShwkXOlWsYEUL,'vtitle':cCINntvTyarzbmouqShwkXOlWsYEGL,'vsubtitle':'',}
    cCINntvTyarzbmouqShwkXOlWsYEdA=json.dumps(cCINntvTyarzbmouqShwkXOlWsYEdf)
    cCINntvTyarzbmouqShwkXOlWsYEdA=urllib.parse.quote(cCINntvTyarzbmouqShwkXOlWsYEdA)
    cCINntvTyarzbmouqShwkXOlWsYEdP='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(cCINntvTyarzbmouqShwkXOlWsYEdA)
    cCINntvTyarzbmouqShwkXOlWsYEdV=[('(통합) 찜 영상에 추가',cCINntvTyarzbmouqShwkXOlWsYEdP)]
   else:
    cCINntvTyarzbmouqShwkXOlWsYEdV=cCINntvTyarzbmouqShwkXOlWsYEDd
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel='',img=cCINntvTyarzbmouqShwkXOlWsYEKR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEKx,params=cCINntvTyarzbmouqShwkXOlWsYEGF,isLink=cCINntvTyarzbmouqShwkXOlWsYEDH,ContextMenu=cCINntvTyarzbmouqShwkXOlWsYEdV)
  if cCINntvTyarzbmouqShwkXOlWsYEKB:
   cCINntvTyarzbmouqShwkXOlWsYEGF['mode'] ='SEARCH' 
   cCINntvTyarzbmouqShwkXOlWsYEGF['search_key']=cCINntvTyarzbmouqShwkXOlWsYEUV
   cCINntvTyarzbmouqShwkXOlWsYEGF['page'] =cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGL='[B]%s >>[/B]'%'다음 페이지'
   cCINntvTyarzbmouqShwkXOlWsYEdp=cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEdp,img=cCINntvTyarzbmouqShwkXOlWsYEGR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  if cCINntvTyarzbmouqShwkXOlWsYEKL=='movie':xbmcplugin.setContent(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,'movies')
  else:xbmcplugin.setContent(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDH)
 def dp_History_Remove(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEHp=cCINntvTyarzbmouqShwkXOlWsYEKA.get('delType')
  cCINntvTyarzbmouqShwkXOlWsYEHi =cCINntvTyarzbmouqShwkXOlWsYEKA.get('sKey')
  cCINntvTyarzbmouqShwkXOlWsYEHg =cCINntvTyarzbmouqShwkXOlWsYEKA.get('vType')
  cCINntvTyarzbmouqShwkXOlWsYExf=xbmcgui.Dialog()
  if cCINntvTyarzbmouqShwkXOlWsYEHp=='SEARCH_ALL':
   cCINntvTyarzbmouqShwkXOlWsYEKp=cCINntvTyarzbmouqShwkXOlWsYExf.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif cCINntvTyarzbmouqShwkXOlWsYEHp=='SEARCH_ONE':
   cCINntvTyarzbmouqShwkXOlWsYEKp=cCINntvTyarzbmouqShwkXOlWsYExf.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif cCINntvTyarzbmouqShwkXOlWsYEHp=='WATCH_ALL':
   cCINntvTyarzbmouqShwkXOlWsYEKp=cCINntvTyarzbmouqShwkXOlWsYExf.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif cCINntvTyarzbmouqShwkXOlWsYEHp=='WATCH_ONE':
   cCINntvTyarzbmouqShwkXOlWsYEKp=cCINntvTyarzbmouqShwkXOlWsYExf.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if cCINntvTyarzbmouqShwkXOlWsYEKp==cCINntvTyarzbmouqShwkXOlWsYEDH:sys.exit()
  if cCINntvTyarzbmouqShwkXOlWsYEHp=='SEARCH_ALL':
   if os.path.isfile(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.SEARCHED_FILE_NAME):os.remove(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.SEARCHED_FILE_NAME)
  elif cCINntvTyarzbmouqShwkXOlWsYEHp=='SEARCH_ONE':
   try:
    cCINntvTyarzbmouqShwkXOlWsYEHj=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.SEARCHED_FILE_NAME
    cCINntvTyarzbmouqShwkXOlWsYEHL=cCINntvTyarzbmouqShwkXOlWsYExi.Load_List_File('search') 
    fp=cCINntvTyarzbmouqShwkXOlWsYEDf(cCINntvTyarzbmouqShwkXOlWsYEHj,'w',-1,'utf-8')
    for cCINntvTyarzbmouqShwkXOlWsYEHM in cCINntvTyarzbmouqShwkXOlWsYEHL:
     cCINntvTyarzbmouqShwkXOlWsYEHf=cCINntvTyarzbmouqShwkXOlWsYEDp(urllib.parse.parse_qsl(cCINntvTyarzbmouqShwkXOlWsYEHM))
     cCINntvTyarzbmouqShwkXOlWsYEHA=cCINntvTyarzbmouqShwkXOlWsYEHf.get('skey').strip()
     if cCINntvTyarzbmouqShwkXOlWsYEHi!=cCINntvTyarzbmouqShwkXOlWsYEHA:
      fp.write(cCINntvTyarzbmouqShwkXOlWsYEHM)
    fp.close()
   except:
    cCINntvTyarzbmouqShwkXOlWsYEDd
  elif cCINntvTyarzbmouqShwkXOlWsYEHp=='WATCH_ALL':
   cCINntvTyarzbmouqShwkXOlWsYEHj=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cCINntvTyarzbmouqShwkXOlWsYEHg))
   if os.path.isfile(cCINntvTyarzbmouqShwkXOlWsYEHj):os.remove(cCINntvTyarzbmouqShwkXOlWsYEHj)
  elif cCINntvTyarzbmouqShwkXOlWsYEHp=='WATCH_ONE':
   cCINntvTyarzbmouqShwkXOlWsYEHj=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cCINntvTyarzbmouqShwkXOlWsYEHg))
   try:
    cCINntvTyarzbmouqShwkXOlWsYEHL=cCINntvTyarzbmouqShwkXOlWsYExi.Load_List_File(cCINntvTyarzbmouqShwkXOlWsYEHg) 
    fp=cCINntvTyarzbmouqShwkXOlWsYEDf(cCINntvTyarzbmouqShwkXOlWsYEHj,'w',-1,'utf-8')
    for cCINntvTyarzbmouqShwkXOlWsYEHM in cCINntvTyarzbmouqShwkXOlWsYEHL:
     cCINntvTyarzbmouqShwkXOlWsYEHf=cCINntvTyarzbmouqShwkXOlWsYEDp(urllib.parse.parse_qsl(cCINntvTyarzbmouqShwkXOlWsYEHM))
     cCINntvTyarzbmouqShwkXOlWsYEHA=cCINntvTyarzbmouqShwkXOlWsYEHf.get('code').strip()
     if cCINntvTyarzbmouqShwkXOlWsYEHi!=cCINntvTyarzbmouqShwkXOlWsYEHA:
      fp.write(cCINntvTyarzbmouqShwkXOlWsYEHM)
    fp.close()
   except:
    cCINntvTyarzbmouqShwkXOlWsYEDd
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKL): 
  try:
   if cCINntvTyarzbmouqShwkXOlWsYEKL=='search':
    cCINntvTyarzbmouqShwkXOlWsYEHj=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.SEARCHED_FILE_NAME
   elif cCINntvTyarzbmouqShwkXOlWsYEKL in['vod','movie']:
    cCINntvTyarzbmouqShwkXOlWsYEHj=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cCINntvTyarzbmouqShwkXOlWsYEKL))
   else:
    return[]
   fp=cCINntvTyarzbmouqShwkXOlWsYEDf(cCINntvTyarzbmouqShwkXOlWsYEHj,'r',-1,'utf-8')
   cCINntvTyarzbmouqShwkXOlWsYEHP=fp.readlines()
   fp.close()
  except:
   cCINntvTyarzbmouqShwkXOlWsYEHP=[]
  return cCINntvTyarzbmouqShwkXOlWsYEHP
 def Save_Watched_List(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKL,cCINntvTyarzbmouqShwkXOlWsYExL):
  try:
   cCINntvTyarzbmouqShwkXOlWsYEHV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cCINntvTyarzbmouqShwkXOlWsYEKL))
   cCINntvTyarzbmouqShwkXOlWsYEHL=cCINntvTyarzbmouqShwkXOlWsYExi.Load_List_File(cCINntvTyarzbmouqShwkXOlWsYEKL) 
   fp=cCINntvTyarzbmouqShwkXOlWsYEDf(cCINntvTyarzbmouqShwkXOlWsYEHV,'w',-1,'utf-8')
   cCINntvTyarzbmouqShwkXOlWsYEHB=urllib.parse.urlencode(cCINntvTyarzbmouqShwkXOlWsYExL)
   cCINntvTyarzbmouqShwkXOlWsYEHB=cCINntvTyarzbmouqShwkXOlWsYEHB+'\n'
   fp.write(cCINntvTyarzbmouqShwkXOlWsYEHB)
   cCINntvTyarzbmouqShwkXOlWsYEHe=0
   for cCINntvTyarzbmouqShwkXOlWsYEHM in cCINntvTyarzbmouqShwkXOlWsYEHL:
    cCINntvTyarzbmouqShwkXOlWsYEHf=cCINntvTyarzbmouqShwkXOlWsYEDp(urllib.parse.parse_qsl(cCINntvTyarzbmouqShwkXOlWsYEHM))
    cCINntvTyarzbmouqShwkXOlWsYEHR=cCINntvTyarzbmouqShwkXOlWsYExL.get('code').strip()
    cCINntvTyarzbmouqShwkXOlWsYEHF=cCINntvTyarzbmouqShwkXOlWsYEHf.get('code').strip()
    if cCINntvTyarzbmouqShwkXOlWsYEKL=='vod' and cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_direct_replay()==cCINntvTyarzbmouqShwkXOlWsYEDQ:
     cCINntvTyarzbmouqShwkXOlWsYEHR=cCINntvTyarzbmouqShwkXOlWsYExL.get('videoid').strip()
     cCINntvTyarzbmouqShwkXOlWsYEHF=cCINntvTyarzbmouqShwkXOlWsYEHf.get('videoid').strip()if cCINntvTyarzbmouqShwkXOlWsYEHF!=cCINntvTyarzbmouqShwkXOlWsYEDd else '-'
    if cCINntvTyarzbmouqShwkXOlWsYEHR!=cCINntvTyarzbmouqShwkXOlWsYEHF:
     fp.write(cCINntvTyarzbmouqShwkXOlWsYEHM)
     cCINntvTyarzbmouqShwkXOlWsYEHe+=1
     if cCINntvTyarzbmouqShwkXOlWsYEHe>=50:break
   fp.close()
  except:
   cCINntvTyarzbmouqShwkXOlWsYEDd
 def dp_Watch_List(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEKL =cCINntvTyarzbmouqShwkXOlWsYEKA.get('stype')
  cCINntvTyarzbmouqShwkXOlWsYEGp=cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_direct_replay()
  if cCINntvTyarzbmouqShwkXOlWsYEKL=='-':
   for cCINntvTyarzbmouqShwkXOlWsYEKf in cCINntvTyarzbmouqShwkXOlWsYExU:
    cCINntvTyarzbmouqShwkXOlWsYEGL=cCINntvTyarzbmouqShwkXOlWsYEKf.get('title')
    cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':cCINntvTyarzbmouqShwkXOlWsYEKf.get('mode'),'stype':cCINntvTyarzbmouqShwkXOlWsYEKf.get('stype')}
    cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel='',img='',infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
   if cCINntvTyarzbmouqShwkXOlWsYEDj(cCINntvTyarzbmouqShwkXOlWsYExU)>0:xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle)
  else:
   cCINntvTyarzbmouqShwkXOlWsYEQx=cCINntvTyarzbmouqShwkXOlWsYExi.Load_List_File(cCINntvTyarzbmouqShwkXOlWsYEKL)
   for cCINntvTyarzbmouqShwkXOlWsYEQG in cCINntvTyarzbmouqShwkXOlWsYEQx:
    cCINntvTyarzbmouqShwkXOlWsYEHK=cCINntvTyarzbmouqShwkXOlWsYEDp(urllib.parse.parse_qsl(cCINntvTyarzbmouqShwkXOlWsYEQG))
    cCINntvTyarzbmouqShwkXOlWsYEQK =cCINntvTyarzbmouqShwkXOlWsYEHK.get('code').strip()
    cCINntvTyarzbmouqShwkXOlWsYEGL =cCINntvTyarzbmouqShwkXOlWsYEHK.get('title').strip()
    cCINntvTyarzbmouqShwkXOlWsYEKR=cCINntvTyarzbmouqShwkXOlWsYEHK.get('img').strip()
    cCINntvTyarzbmouqShwkXOlWsYEUj =cCINntvTyarzbmouqShwkXOlWsYEHK.get('videoid').strip()
    try:
     cCINntvTyarzbmouqShwkXOlWsYEKR=cCINntvTyarzbmouqShwkXOlWsYEKR.replace('\'','\"')
     cCINntvTyarzbmouqShwkXOlWsYEKR=json.loads(cCINntvTyarzbmouqShwkXOlWsYEKR)
    except:
     cCINntvTyarzbmouqShwkXOlWsYEDd
    cCINntvTyarzbmouqShwkXOlWsYEdD={}
    cCINntvTyarzbmouqShwkXOlWsYEdD['plot']=cCINntvTyarzbmouqShwkXOlWsYEGL
    if cCINntvTyarzbmouqShwkXOlWsYEKL=='vod':
     if cCINntvTyarzbmouqShwkXOlWsYEGp==cCINntvTyarzbmouqShwkXOlWsYEDH or cCINntvTyarzbmouqShwkXOlWsYEUj==cCINntvTyarzbmouqShwkXOlWsYEDd:
      cCINntvTyarzbmouqShwkXOlWsYEdD['mediatype']='tvshow'
      cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'EPISODE','programcode':cCINntvTyarzbmouqShwkXOlWsYEQK,'page':'1'}
      cCINntvTyarzbmouqShwkXOlWsYEKx=cCINntvTyarzbmouqShwkXOlWsYEDQ
     else:
      cCINntvTyarzbmouqShwkXOlWsYEdD['mediatype']='episode'
      cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'VOD','mediacode':cCINntvTyarzbmouqShwkXOlWsYEUj,'stype':'vod','programcode':cCINntvTyarzbmouqShwkXOlWsYEQK,'title':cCINntvTyarzbmouqShwkXOlWsYEGL,'thumbnail':cCINntvTyarzbmouqShwkXOlWsYEKR}
      cCINntvTyarzbmouqShwkXOlWsYEKx=cCINntvTyarzbmouqShwkXOlWsYEDH
    else:
     cCINntvTyarzbmouqShwkXOlWsYEdD['mediatype']='movie'
     cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'MOVIE','mediacode':cCINntvTyarzbmouqShwkXOlWsYEQK,'stype':'movie','title':cCINntvTyarzbmouqShwkXOlWsYEGL,'thumbnail':cCINntvTyarzbmouqShwkXOlWsYEKR}
     cCINntvTyarzbmouqShwkXOlWsYEKx=cCINntvTyarzbmouqShwkXOlWsYEDH
    cCINntvTyarzbmouqShwkXOlWsYEHU={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':cCINntvTyarzbmouqShwkXOlWsYEQK,'vType':cCINntvTyarzbmouqShwkXOlWsYEKL,}
    cCINntvTyarzbmouqShwkXOlWsYEHQ=urllib.parse.urlencode(cCINntvTyarzbmouqShwkXOlWsYEHU)
    cCINntvTyarzbmouqShwkXOlWsYEdV=[('선택된 시청이력 ( %s ) 삭제'%(cCINntvTyarzbmouqShwkXOlWsYEGL),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(cCINntvTyarzbmouqShwkXOlWsYEHQ))]
    cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel='',img=cCINntvTyarzbmouqShwkXOlWsYEKR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEKx,params=cCINntvTyarzbmouqShwkXOlWsYEGF,ContextMenu=cCINntvTyarzbmouqShwkXOlWsYEdV)
   cCINntvTyarzbmouqShwkXOlWsYEdD={'plot':'시청목록을 삭제합니다.'}
   cCINntvTyarzbmouqShwkXOlWsYEGL='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':cCINntvTyarzbmouqShwkXOlWsYEKL,}
   cCINntvTyarzbmouqShwkXOlWsYEGR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel='',img=cCINntvTyarzbmouqShwkXOlWsYEGR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDH,params=cCINntvTyarzbmouqShwkXOlWsYEGF,isLink=cCINntvTyarzbmouqShwkXOlWsYEDQ)
   if cCINntvTyarzbmouqShwkXOlWsYEKL=='movie':xbmcplugin.setContent(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,'movies')
   else:xbmcplugin.setContent(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDH)
 def Save_Searched_List(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEUV):
  try:
   cCINntvTyarzbmouqShwkXOlWsYEQd=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.SEARCHED_FILE_NAME
   cCINntvTyarzbmouqShwkXOlWsYEHL=cCINntvTyarzbmouqShwkXOlWsYExi.Load_List_File('search') 
   cCINntvTyarzbmouqShwkXOlWsYEQU={'skey':cCINntvTyarzbmouqShwkXOlWsYEUV.strip()}
   fp=cCINntvTyarzbmouqShwkXOlWsYEDf(cCINntvTyarzbmouqShwkXOlWsYEQd,'w',-1,'utf-8')
   cCINntvTyarzbmouqShwkXOlWsYEHB=urllib.parse.urlencode(cCINntvTyarzbmouqShwkXOlWsYEQU)
   cCINntvTyarzbmouqShwkXOlWsYEHB=cCINntvTyarzbmouqShwkXOlWsYEHB+'\n'
   fp.write(cCINntvTyarzbmouqShwkXOlWsYEHB)
   cCINntvTyarzbmouqShwkXOlWsYEHe=0
   for cCINntvTyarzbmouqShwkXOlWsYEHM in cCINntvTyarzbmouqShwkXOlWsYEHL:
    cCINntvTyarzbmouqShwkXOlWsYEHf=cCINntvTyarzbmouqShwkXOlWsYEDp(urllib.parse.parse_qsl(cCINntvTyarzbmouqShwkXOlWsYEHM))
    cCINntvTyarzbmouqShwkXOlWsYEHR=cCINntvTyarzbmouqShwkXOlWsYEQU.get('skey').strip()
    cCINntvTyarzbmouqShwkXOlWsYEHF=cCINntvTyarzbmouqShwkXOlWsYEHf.get('skey').strip()
    if cCINntvTyarzbmouqShwkXOlWsYEHR!=cCINntvTyarzbmouqShwkXOlWsYEHF:
     fp.write(cCINntvTyarzbmouqShwkXOlWsYEHM)
     cCINntvTyarzbmouqShwkXOlWsYEHe+=1
     if cCINntvTyarzbmouqShwkXOlWsYEHe>=50:break
   fp.close()
  except:
   cCINntvTyarzbmouqShwkXOlWsYEDd
 def play_VIDEO(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEQH =cCINntvTyarzbmouqShwkXOlWsYEKA.get('mediacode')
  cCINntvTyarzbmouqShwkXOlWsYEKL =cCINntvTyarzbmouqShwkXOlWsYEKA.get('stype')
  cCINntvTyarzbmouqShwkXOlWsYEQJ =cCINntvTyarzbmouqShwkXOlWsYEKA.get('pvrmode')
  cCINntvTyarzbmouqShwkXOlWsYEQD=cCINntvTyarzbmouqShwkXOlWsYExi.get_selQuality(cCINntvTyarzbmouqShwkXOlWsYEKL)
  cCINntvTyarzbmouqShwkXOlWsYExi.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(cCINntvTyarzbmouqShwkXOlWsYEQH,cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEQD),cCINntvTyarzbmouqShwkXOlWsYEKL,cCINntvTyarzbmouqShwkXOlWsYEQJ))
  cCINntvTyarzbmouqShwkXOlWsYEQp=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.GetBroadURL(cCINntvTyarzbmouqShwkXOlWsYEQH,cCINntvTyarzbmouqShwkXOlWsYEQD,cCINntvTyarzbmouqShwkXOlWsYEKL,cCINntvTyarzbmouqShwkXOlWsYEQJ,optUHD=cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_uhd())
  cCINntvTyarzbmouqShwkXOlWsYExi.addon_log('qt, stype, url : %s - %s - %s'%(cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEQD),cCINntvTyarzbmouqShwkXOlWsYEKL,cCINntvTyarzbmouqShwkXOlWsYEQp['streaming_url']))
  if cCINntvTyarzbmouqShwkXOlWsYEQp['streaming_url']=='':
   if cCINntvTyarzbmouqShwkXOlWsYEQp['error_msg']=='':
    cCINntvTyarzbmouqShwkXOlWsYExi.addon_noti(__language__(30908).encode('utf8'))
   else:
    cCINntvTyarzbmouqShwkXOlWsYExi.addon_noti(cCINntvTyarzbmouqShwkXOlWsYEQp['error_msg'].encode('utf8'))
   return
  if cCINntvTyarzbmouqShwkXOlWsYEQp['qt_stream']=='stream70':
   cCINntvTyarzbmouqShwkXOlWsYEQi={'user-agent':cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.USER_AGENT_ATV}
  else:
   cCINntvTyarzbmouqShwkXOlWsYEQi={'user-agent':cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.USER_AGENT}
  cCINntvTyarzbmouqShwkXOlWsYEQg=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.makeDefaultCookies() 
  if cCINntvTyarzbmouqShwkXOlWsYEQp['watermark'] !='':
   cCINntvTyarzbmouqShwkXOlWsYEQi['x-tving-param1']=cCINntvTyarzbmouqShwkXOlWsYEQp['watermarkKey']
   cCINntvTyarzbmouqShwkXOlWsYEQi['x-tving-param2']=cCINntvTyarzbmouqShwkXOlWsYEQp['watermark'] 
  if cCINntvTyarzbmouqShwkXOlWsYEQp['drm_server_url'] !='':
   cCINntvTyarzbmouqShwkXOlWsYEQi[cCINntvTyarzbmouqShwkXOlWsYEQp['drm_header_key']]=cCINntvTyarzbmouqShwkXOlWsYEQp['drm_header_value']
  cCINntvTyarzbmouqShwkXOlWsYEQj =cCINntvTyarzbmouqShwkXOlWsYEDH
  cCINntvTyarzbmouqShwkXOlWsYEQL =cCINntvTyarzbmouqShwkXOlWsYEQp['streaming_url'].find('Policy=')
  if cCINntvTyarzbmouqShwkXOlWsYEQL!=-1:
   cCINntvTyarzbmouqShwkXOlWsYEQM =cCINntvTyarzbmouqShwkXOlWsYEQp['streaming_url'].split('?')[0]
   cCINntvTyarzbmouqShwkXOlWsYEQf=cCINntvTyarzbmouqShwkXOlWsYEDp(urllib.parse.parse_qsl(urllib.parse.urlsplit(cCINntvTyarzbmouqShwkXOlWsYEQp['streaming_url']).query))
   cCINntvTyarzbmouqShwkXOlWsYEQg['CloudFront-Policy'] =cCINntvTyarzbmouqShwkXOlWsYEQf['Policy'] 
   cCINntvTyarzbmouqShwkXOlWsYEQg['CloudFront-Signature'] =cCINntvTyarzbmouqShwkXOlWsYEQf['Signature'] 
   cCINntvTyarzbmouqShwkXOlWsYEQg['CloudFront-Key-Pair-Id']=cCINntvTyarzbmouqShwkXOlWsYEQf['Key-Pair-Id'] 
   cCINntvTyarzbmouqShwkXOlWsYEQA=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.make_stream_header(cCINntvTyarzbmouqShwkXOlWsYEQi,cCINntvTyarzbmouqShwkXOlWsYEQg)
   if 'quickvod-mcdn.tving.com' in cCINntvTyarzbmouqShwkXOlWsYEQM:
    cCINntvTyarzbmouqShwkXOlWsYEQj=cCINntvTyarzbmouqShwkXOlWsYEDQ
    cCINntvTyarzbmouqShwkXOlWsYEQP =cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    cCINntvTyarzbmouqShwkXOlWsYEQV=cCINntvTyarzbmouqShwkXOlWsYEQP.strftime('%Y-%m-%d-%H:%M:%S')
    if cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYEQV.replace('-','').replace(':',''))<cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYEQf['end'].replace('-','').replace(':','')):
     cCINntvTyarzbmouqShwkXOlWsYEQf['end']=cCINntvTyarzbmouqShwkXOlWsYEQV
     cCINntvTyarzbmouqShwkXOlWsYExi.addon_noti(__language__(30915).encode('utf8'))
    cCINntvTyarzbmouqShwkXOlWsYEQM ='%s?%s'%(cCINntvTyarzbmouqShwkXOlWsYEQM,urllib.parse.urlencode(cCINntvTyarzbmouqShwkXOlWsYEQf,doseq=cCINntvTyarzbmouqShwkXOlWsYEDQ))
    cCINntvTyarzbmouqShwkXOlWsYEQB='{}|{}'.format(cCINntvTyarzbmouqShwkXOlWsYEQM,cCINntvTyarzbmouqShwkXOlWsYEQA)
   else:
    cCINntvTyarzbmouqShwkXOlWsYEQB='{}|{}'.format(cCINntvTyarzbmouqShwkXOlWsYEQp['streaming_url'],cCINntvTyarzbmouqShwkXOlWsYEQA)
  else:
   cCINntvTyarzbmouqShwkXOlWsYEQA=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.make_stream_header(cCINntvTyarzbmouqShwkXOlWsYEQi,cCINntvTyarzbmouqShwkXOlWsYEQg)
   cCINntvTyarzbmouqShwkXOlWsYEQB='{}|{}'.format(cCINntvTyarzbmouqShwkXOlWsYEQp['streaming_url'],cCINntvTyarzbmouqShwkXOlWsYEQA)
   cCINntvTyarzbmouqShwkXOlWsYExi.addon_log('if tmp_pos == -1')
  cCINntvTyarzbmouqShwkXOlWsYEGK,cCINntvTyarzbmouqShwkXOlWsYEGd=cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_proxyport()
  cCINntvTyarzbmouqShwkXOlWsYEGx=cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_playback()
  if(cCINntvTyarzbmouqShwkXOlWsYEGK and cCINntvTyarzbmouqShwkXOlWsYEKA.get('mode')in['VOD','MOVIE']and cCINntvTyarzbmouqShwkXOlWsYEQj==cCINntvTyarzbmouqShwkXOlWsYEDH and(cCINntvTyarzbmouqShwkXOlWsYEQp['drm_server_url']!='' or(cCINntvTyarzbmouqShwkXOlWsYEQp['url_filename'].split('.')[1]=='mpd')or(cCINntvTyarzbmouqShwkXOlWsYEQp['url_filename'].split('.')[1]!='mpd' and cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.KodiVersion>=21 and cCINntvTyarzbmouqShwkXOlWsYEQp['qt_stream']=='stream70'))):
   if cCINntvTyarzbmouqShwkXOlWsYEQp['url_filename'].split('.')[1]=='mpd':
    cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Tving_Parse_mpd(cCINntvTyarzbmouqShwkXOlWsYEQp['streaming_url'],cCINntvTyarzbmouqShwkXOlWsYEQp['watermarkKey'],cCINntvTyarzbmouqShwkXOlWsYEQp['watermark'])
   else:
    cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Tving_Parse_m3u8(cCINntvTyarzbmouqShwkXOlWsYEQp['streaming_url'])
   cCINntvTyarzbmouqShwkXOlWsYExi.addon_log('xxx '+cCINntvTyarzbmouqShwkXOlWsYEQp['streaming_url'])
   cCINntvTyarzbmouqShwkXOlWsYEQe={'addon':'tvingm','playOption':cCINntvTyarzbmouqShwkXOlWsYEGx,'url_filename':cCINntvTyarzbmouqShwkXOlWsYEQp['url_filename'],}
   cCINntvTyarzbmouqShwkXOlWsYEQe=json.dumps(cCINntvTyarzbmouqShwkXOlWsYEQe,separators=(',',':'))
   cCINntvTyarzbmouqShwkXOlWsYEQe=base64.standard_b64encode(cCINntvTyarzbmouqShwkXOlWsYEQe.encode()).decode('utf-8')
   cCINntvTyarzbmouqShwkXOlWsYEQB ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(cCINntvTyarzbmouqShwkXOlWsYEGd,cCINntvTyarzbmouqShwkXOlWsYEQB,cCINntvTyarzbmouqShwkXOlWsYEQe)
   cCINntvTyarzbmouqShwkXOlWsYEQi['proxy-mini']=cCINntvTyarzbmouqShwkXOlWsYEQe 
  cCINntvTyarzbmouqShwkXOlWsYExi.addon_log('surl(2) : {}'.format(cCINntvTyarzbmouqShwkXOlWsYEQB))
  cCINntvTyarzbmouqShwkXOlWsYExi.addon_log('drm     : {}'.format(cCINntvTyarzbmouqShwkXOlWsYEQp['drm_server_url']))
  cCINntvTyarzbmouqShwkXOlWsYEQA=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.make_stream_header(cCINntvTyarzbmouqShwkXOlWsYEQi,cCINntvTyarzbmouqShwkXOlWsYEQg)
  cCINntvTyarzbmouqShwkXOlWsYEQR=xbmcgui.ListItem(path=cCINntvTyarzbmouqShwkXOlWsYEQB)
  if cCINntvTyarzbmouqShwkXOlWsYEQp['drm_server_url']!='':
   cCINntvTyarzbmouqShwkXOlWsYEQF=cCINntvTyarzbmouqShwkXOlWsYEQp['drm_server_url']
   cCINntvTyarzbmouqShwkXOlWsYEJx ='https://license-global.pallycon.com/ri/licenseManager.do' 
   cCINntvTyarzbmouqShwkXOlWsYEJG ='mpd'
   cCINntvTyarzbmouqShwkXOlWsYEJK ='com.widevine.alpha'
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   cCINntvTyarzbmouqShwkXOlWsYEJU={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.USER_AGENT,cCINntvTyarzbmouqShwkXOlWsYEQp['drm_header_key']:cCINntvTyarzbmouqShwkXOlWsYEQp['drm_header_value'],}
   cCINntvTyarzbmouqShwkXOlWsYEJH=cCINntvTyarzbmouqShwkXOlWsYEJx+'|'+urllib.parse.urlencode(cCINntvTyarzbmouqShwkXOlWsYEJU)+'|R{SSM}|'
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream','inputstream.adaptive')
   if cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.KodiVersion<=20:
    cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream.adaptive.manifest_type',cCINntvTyarzbmouqShwkXOlWsYEJG)
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream.adaptive.license_type',cCINntvTyarzbmouqShwkXOlWsYEJK)
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream.adaptive.license_key',cCINntvTyarzbmouqShwkXOlWsYEJH)
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream.adaptive.stream_headers',cCINntvTyarzbmouqShwkXOlWsYEQA)
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream.adaptive.manifest_headers',cCINntvTyarzbmouqShwkXOlWsYEQA)
  elif cCINntvTyarzbmouqShwkXOlWsYEKA.get('mode')in['VOD','MOVIE']:
   cCINntvTyarzbmouqShwkXOlWsYEQR.setContentLookup(cCINntvTyarzbmouqShwkXOlWsYEDH)
   cCINntvTyarzbmouqShwkXOlWsYEQR.setMimeType('application/x-mpegURL')
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream','inputstream.adaptive')
   if cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.KodiVersion<=20:
    cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream.adaptive.manifest_type','hls')
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream.adaptive.stream_headers',cCINntvTyarzbmouqShwkXOlWsYEQA)
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream.adaptive.manifest_headers',cCINntvTyarzbmouqShwkXOlWsYEQA)
  elif cCINntvTyarzbmouqShwkXOlWsYEQj==cCINntvTyarzbmouqShwkXOlWsYEDQ:
   cCINntvTyarzbmouqShwkXOlWsYEQR.setContentLookup(cCINntvTyarzbmouqShwkXOlWsYEDH)
   cCINntvTyarzbmouqShwkXOlWsYEQR.setMimeType('application/x-mpegURL')
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream','inputstream.ffmpegdirect')
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('ResumeTime','0')
   cCINntvTyarzbmouqShwkXOlWsYEQR.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cCINntvTyarzbmouqShwkXOlWsYEDQ,cCINntvTyarzbmouqShwkXOlWsYEQR)
  try:
   if cCINntvTyarzbmouqShwkXOlWsYEKA.get('mode')in['VOD','MOVIE']and cCINntvTyarzbmouqShwkXOlWsYEKA.get('title'):
    cCINntvTyarzbmouqShwkXOlWsYEGF={'code':cCINntvTyarzbmouqShwkXOlWsYEKA.get('programcode')if cCINntvTyarzbmouqShwkXOlWsYEKA.get('mode')=='VOD' else cCINntvTyarzbmouqShwkXOlWsYEKA.get('mediacode'),'img':cCINntvTyarzbmouqShwkXOlWsYEKA.get('thumbnail'),'title':cCINntvTyarzbmouqShwkXOlWsYEKA.get('title'),'videoid':cCINntvTyarzbmouqShwkXOlWsYEKA.get('mediacode')}
    cCINntvTyarzbmouqShwkXOlWsYExi.Save_Watched_List(cCINntvTyarzbmouqShwkXOlWsYEKA.get('stype'),cCINntvTyarzbmouqShwkXOlWsYEGF)
  except:
   cCINntvTyarzbmouqShwkXOlWsYEDd
 def logout(cCINntvTyarzbmouqShwkXOlWsYExi):
  cCINntvTyarzbmouqShwkXOlWsYExf=xbmcgui.Dialog()
  cCINntvTyarzbmouqShwkXOlWsYEKp=cCINntvTyarzbmouqShwkXOlWsYExf.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if cCINntvTyarzbmouqShwkXOlWsYEKp==cCINntvTyarzbmouqShwkXOlWsYEDH:sys.exit()
  cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Init_TV_Total()
  if os.path.isfile(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_COOKIE_FILENAME):os.remove(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_COOKIE_FILENAME)
  if os.path.isfile(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_TOKEN_FILENAME): os.remove(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_TOKEN_FILENAME)
  cCINntvTyarzbmouqShwkXOlWsYExi.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(cCINntvTyarzbmouqShwkXOlWsYExi):
  cCINntvTyarzbmouqShwkXOlWsYEJQ =cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Get_Now_Datetime()
  cCINntvTyarzbmouqShwkXOlWsYEJD=cCINntvTyarzbmouqShwkXOlWsYEJQ+datetime.timedelta(days=30) 
  (cCINntvTyarzbmouqShwkXOlWsYEKH,cCINntvTyarzbmouqShwkXOlWsYEKQ,cCINntvTyarzbmouqShwkXOlWsYEKJ,cCINntvTyarzbmouqShwkXOlWsYEKD)=cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_account()
  cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Save_session_acount(cCINntvTyarzbmouqShwkXOlWsYEKH,cCINntvTyarzbmouqShwkXOlWsYEKQ,cCINntvTyarzbmouqShwkXOlWsYEKJ,cCINntvTyarzbmouqShwkXOlWsYEKD)
  cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV['account']['token_limit']=cCINntvTyarzbmouqShwkXOlWsYEJD.strftime('%Y%m%d')
  cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.JsonFile_Save(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_COOKIE_FILENAME,cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV)
 def cookiefile_check(cCINntvTyarzbmouqShwkXOlWsYExi):
  cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.JsonFile_Load(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_COOKIE_FILENAME)
  if cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV=={}:
   cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Init_TV_Total()
   return cCINntvTyarzbmouqShwkXOlWsYEDH
  (cCINntvTyarzbmouqShwkXOlWsYEJp,cCINntvTyarzbmouqShwkXOlWsYEJi,cCINntvTyarzbmouqShwkXOlWsYEJg,cCINntvTyarzbmouqShwkXOlWsYEJj)=cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_account()
  (cCINntvTyarzbmouqShwkXOlWsYEJL,cCINntvTyarzbmouqShwkXOlWsYEJM,cCINntvTyarzbmouqShwkXOlWsYEJf,cCINntvTyarzbmouqShwkXOlWsYEJA)=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Load_session_acount()
  if(cCINntvTyarzbmouqShwkXOlWsYEJp!=cCINntvTyarzbmouqShwkXOlWsYEJL or cCINntvTyarzbmouqShwkXOlWsYEJi!=cCINntvTyarzbmouqShwkXOlWsYEJM or cCINntvTyarzbmouqShwkXOlWsYEJg!=cCINntvTyarzbmouqShwkXOlWsYEJf or cCINntvTyarzbmouqShwkXOlWsYEJj!=cCINntvTyarzbmouqShwkXOlWsYEJA)and cCINntvTyarzbmouqShwkXOlWsYEJL!='xxxxx':
   cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Init_TV_Total()
   return cCINntvTyarzbmouqShwkXOlWsYEDH
  if cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV['account']['token_limit']):
   cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Init_TV_Total()
   return cCINntvTyarzbmouqShwkXOlWsYEDH
  return cCINntvTyarzbmouqShwkXOlWsYEDQ
 def tokenfile_check(cCINntvTyarzbmouqShwkXOlWsYExi):
  cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_TOKEN=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.JsonFile_Load(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_TOKEN_FILENAME)
  if cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_TOKEN=={}:
   return cCINntvTyarzbmouqShwkXOlWsYEDH
  if cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_TOKEN['token_date']):
   cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.TV_TOKEN={}
   return cCINntvTyarzbmouqShwkXOlWsYEDH
  return cCINntvTyarzbmouqShwkXOlWsYEDQ
 def get_reToken(cCINntvTyarzbmouqShwkXOlWsYExi):
  if cCINntvTyarzbmouqShwkXOlWsYExi.tokenfile_check()==cCINntvTyarzbmouqShwkXOlWsYEDH:
   cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Get_AccessToken()
 def dp_Global_Search(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEUB=cCINntvTyarzbmouqShwkXOlWsYEKA.get('mode')
  if cCINntvTyarzbmouqShwkXOlWsYEUB=='TOTAL_SEARCH':
   cCINntvTyarzbmouqShwkXOlWsYEJP='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   cCINntvTyarzbmouqShwkXOlWsYEJP='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(cCINntvTyarzbmouqShwkXOlWsYEJP)
 def dp_Bookmark_Menu(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEJP='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(cCINntvTyarzbmouqShwkXOlWsYEJP)
 def dp_EuroLive_List(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEKV=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.GetEuroChannelList()
  for cCINntvTyarzbmouqShwkXOlWsYEKe in cCINntvTyarzbmouqShwkXOlWsYEKV:
   cCINntvTyarzbmouqShwkXOlWsYEdM =cCINntvTyarzbmouqShwkXOlWsYEKe.get('channel')
   cCINntvTyarzbmouqShwkXOlWsYEGL =cCINntvTyarzbmouqShwkXOlWsYEKe.get('title')
   cCINntvTyarzbmouqShwkXOlWsYEdp =cCINntvTyarzbmouqShwkXOlWsYEKe.get('subtitle')
   cCINntvTyarzbmouqShwkXOlWsYEdD={'mediatype':'episode','title':cCINntvTyarzbmouqShwkXOlWsYEGL,'plot':'%s\n%s'%(cCINntvTyarzbmouqShwkXOlWsYEGL,cCINntvTyarzbmouqShwkXOlWsYEdp)}
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'LIVE','mediacode':cCINntvTyarzbmouqShwkXOlWsYEdM,'stype':'onair',}
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEdp,img='',infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDH,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  if cCINntvTyarzbmouqShwkXOlWsYEDj(cCINntvTyarzbmouqShwkXOlWsYEKV)>0:xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDH)
 def dp_Apple_Group(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEJV=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Get_AppleGroup_List()
  for cCINntvTyarzbmouqShwkXOlWsYEJB in cCINntvTyarzbmouqShwkXOlWsYEJV:
   cCINntvTyarzbmouqShwkXOlWsYEJe =cCINntvTyarzbmouqShwkXOlWsYEJB.get('bandName')
   cCINntvTyarzbmouqShwkXOlWsYEJR =cCINntvTyarzbmouqShwkXOlWsYEJB.get('bandKey')
   cCINntvTyarzbmouqShwkXOlWsYEdD={'mediatype':'tvshow','title':cCINntvTyarzbmouqShwkXOlWsYEJe,'plot':'%s'%(cCINntvTyarzbmouqShwkXOlWsYEJR),}
   cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'BAND_VODLIST','bandKey':cCINntvTyarzbmouqShwkXOlWsYEJR,'page':'1','nextApiUrl':'-',}
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEJe,sublabel=cCINntvTyarzbmouqShwkXOlWsYEDd,img='',infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  if cCINntvTyarzbmouqShwkXOlWsYEDj(cCINntvTyarzbmouqShwkXOlWsYEJV)>0:xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDH)
 def dp_Band_VodList(cCINntvTyarzbmouqShwkXOlWsYExi,cCINntvTyarzbmouqShwkXOlWsYEKA):
  cCINntvTyarzbmouqShwkXOlWsYEJR =cCINntvTyarzbmouqShwkXOlWsYEKA.get('bandKey') 
  cCINntvTyarzbmouqShwkXOlWsYEJF =cCINntvTyarzbmouqShwkXOlWsYEKA.get('bandGroup') 
  cCINntvTyarzbmouqShwkXOlWsYEDx =cCINntvTyarzbmouqShwkXOlWsYEKA.get('nextApiUrl')
  cCINntvTyarzbmouqShwkXOlWsYEDG =''
  cCINntvTyarzbmouqShwkXOlWsYEKP =cCINntvTyarzbmouqShwkXOlWsYEDU(cCINntvTyarzbmouqShwkXOlWsYEKA.get('page'))
  cCINntvTyarzbmouqShwkXOlWsYExi.addon_log('bandKey    : {}'.format(cCINntvTyarzbmouqShwkXOlWsYEJR))
  cCINntvTyarzbmouqShwkXOlWsYExi.addon_log('bandGroup  : {}'.format(cCINntvTyarzbmouqShwkXOlWsYEJF))
  cCINntvTyarzbmouqShwkXOlWsYExi.addon_log('nextApiUrl : {}'.format(cCINntvTyarzbmouqShwkXOlWsYEDx))
  if cCINntvTyarzbmouqShwkXOlWsYEJF=='TVING_APPLE_HOUR':
   cCINntvTyarzbmouqShwkXOlWsYEdj,cCINntvTyarzbmouqShwkXOlWsYEDx=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Get_Apple_NowList()
  else:
   if cCINntvTyarzbmouqShwkXOlWsYEJF not in['',cCINntvTyarzbmouqShwkXOlWsYEDd]:
    cCINntvTyarzbmouqShwkXOlWsYEJR=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Get_bandCode_GroupCode(cCINntvTyarzbmouqShwkXOlWsYEJF)
    cCINntvTyarzbmouqShwkXOlWsYExi.addon_log('new bandKey    : {}'.format(cCINntvTyarzbmouqShwkXOlWsYEJR))
   cCINntvTyarzbmouqShwkXOlWsYEdj,cCINntvTyarzbmouqShwkXOlWsYEDx=cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.Get_Band_VodList(cCINntvTyarzbmouqShwkXOlWsYEJR,cCINntvTyarzbmouqShwkXOlWsYEDx)
  for cCINntvTyarzbmouqShwkXOlWsYEdL in cCINntvTyarzbmouqShwkXOlWsYEdj:
   cCINntvTyarzbmouqShwkXOlWsYEGL =cCINntvTyarzbmouqShwkXOlWsYEdL.get('title')
   cCINntvTyarzbmouqShwkXOlWsYEKR =cCINntvTyarzbmouqShwkXOlWsYEdL.get('thumbnail')
   cCINntvTyarzbmouqShwkXOlWsYEUj =cCINntvTyarzbmouqShwkXOlWsYEdL.get('program')
   cCINntvTyarzbmouqShwkXOlWsYEdD={'mediatype':'tvshow' if not cCINntvTyarzbmouqShwkXOlWsYEUj.startswith('M')else 'movie','title':cCINntvTyarzbmouqShwkXOlWsYEGL,'plot':cCINntvTyarzbmouqShwkXOlWsYEGL+'\n'+'tvshow' if not cCINntvTyarzbmouqShwkXOlWsYEUj.startswith('M')else 'movie',}
   if not cCINntvTyarzbmouqShwkXOlWsYEUj.startswith('M'):
    cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'EPISODE','programcode':cCINntvTyarzbmouqShwkXOlWsYEUj,'page':'1',}
    cCINntvTyarzbmouqShwkXOlWsYEKx=cCINntvTyarzbmouqShwkXOlWsYEDQ
   else:
    cCINntvTyarzbmouqShwkXOlWsYEGF={'mode':'MOVIE','mediacode':cCINntvTyarzbmouqShwkXOlWsYEUj,'stype':'movie','title':cCINntvTyarzbmouqShwkXOlWsYEGL,'thumbnail':cCINntvTyarzbmouqShwkXOlWsYEKR,}
    cCINntvTyarzbmouqShwkXOlWsYEKx=cCINntvTyarzbmouqShwkXOlWsYEDH
   if cCINntvTyarzbmouqShwkXOlWsYExi.get_settings_makebookmark():
    cCINntvTyarzbmouqShwkXOlWsYEdf={'videoid':cCINntvTyarzbmouqShwkXOlWsYEUj,'vidtype':'tvshow','vtitle':cCINntvTyarzbmouqShwkXOlWsYEGL,'vsubtitle':cCINntvTyarzbmouqShwkXOlWsYEDG,}
    cCINntvTyarzbmouqShwkXOlWsYEdA=json.dumps(cCINntvTyarzbmouqShwkXOlWsYEdf)
    cCINntvTyarzbmouqShwkXOlWsYEdA=urllib.parse.quote(cCINntvTyarzbmouqShwkXOlWsYEdA)
    cCINntvTyarzbmouqShwkXOlWsYEdP='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(cCINntvTyarzbmouqShwkXOlWsYEdA)
    cCINntvTyarzbmouqShwkXOlWsYEdV=[('(통합) 찜 영상에 추가',cCINntvTyarzbmouqShwkXOlWsYEdP)]
   else:
    cCINntvTyarzbmouqShwkXOlWsYEdV=cCINntvTyarzbmouqShwkXOlWsYEDd
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEDG,img=cCINntvTyarzbmouqShwkXOlWsYEKR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEdD,isFolder=cCINntvTyarzbmouqShwkXOlWsYEKx,params=cCINntvTyarzbmouqShwkXOlWsYEGF,ContextMenu=cCINntvTyarzbmouqShwkXOlWsYEdV)
  if cCINntvTyarzbmouqShwkXOlWsYEDx not in[cCINntvTyarzbmouqShwkXOlWsYEDd,'','-']:
   cCINntvTyarzbmouqShwkXOlWsYEGF['mode'] ='BAND_VODLIST' 
   cCINntvTyarzbmouqShwkXOlWsYEGF['bandKey'] =cCINntvTyarzbmouqShwkXOlWsYEJR
   cCINntvTyarzbmouqShwkXOlWsYEGF['nextApiUrl']=cCINntvTyarzbmouqShwkXOlWsYEDx
   cCINntvTyarzbmouqShwkXOlWsYEGF['page'] =cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGL='[B]%s >>[/B]'%'다음 페이지'
   cCINntvTyarzbmouqShwkXOlWsYEdp=cCINntvTyarzbmouqShwkXOlWsYEDL(cCINntvTyarzbmouqShwkXOlWsYEKP+1)
   cCINntvTyarzbmouqShwkXOlWsYEGR=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   cCINntvTyarzbmouqShwkXOlWsYExi.add_dir(cCINntvTyarzbmouqShwkXOlWsYEGL,sublabel=cCINntvTyarzbmouqShwkXOlWsYEdp,img=cCINntvTyarzbmouqShwkXOlWsYEGR,infoLabels=cCINntvTyarzbmouqShwkXOlWsYEDd,isFolder=cCINntvTyarzbmouqShwkXOlWsYEDQ,params=cCINntvTyarzbmouqShwkXOlWsYEGF)
  xbmcplugin.setContent(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(cCINntvTyarzbmouqShwkXOlWsYExi._addon_handle,cacheToDisc=cCINntvTyarzbmouqShwkXOlWsYEDH)
 def tving_main(cCINntvTyarzbmouqShwkXOlWsYExi):
  cCINntvTyarzbmouqShwkXOlWsYExi.TvingObj.KodiVersion=cCINntvTyarzbmouqShwkXOlWsYEDU(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  cCINntvTyarzbmouqShwkXOlWsYEUB=cCINntvTyarzbmouqShwkXOlWsYExi.main_params.get('mode',cCINntvTyarzbmouqShwkXOlWsYEDd)
  if cCINntvTyarzbmouqShwkXOlWsYEUB=='LOGOUT':
   cCINntvTyarzbmouqShwkXOlWsYExi.logout()
   return
  cCINntvTyarzbmouqShwkXOlWsYExi.login_main()
  cCINntvTyarzbmouqShwkXOlWsYExi.get_reToken()
  if cCINntvTyarzbmouqShwkXOlWsYEUB is cCINntvTyarzbmouqShwkXOlWsYEDd:
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Main_List()
  elif cCINntvTyarzbmouqShwkXOlWsYEUB in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Title_Group(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB in['GLOBAL_GROUP']:
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_SubTitle_Group(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='CHANNEL':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_LiveChannel_List(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB in['LIVE','VOD','MOVIE']:
   cCINntvTyarzbmouqShwkXOlWsYExi.play_VIDEO(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='PROGRAM':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Program_List(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='4K_PROGRAM':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_4K_Program_List(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='ORI_PROGRAM':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Ori_Program_List(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='EPISODE':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Episode_List(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='MOVIE_SUB':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Movie_List(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='4K_MOVIE':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_4K_Movie_List(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='SEARCH_GROUP':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Search_Group(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB in['SEARCH','LOCAL_SEARCH']:
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Search_List(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='WATCH':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Watch_List(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_History_Remove(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='ORDER_BY':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_setEpOrderby(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='SET_BOOKMARK':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Set_Bookmark(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB in['TOTAL_SEARCH','TOTAL_HISTORY']:
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Global_Search(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='SEARCH_HISTORY':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Search_History(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='MENU_BOOKMARK':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Bookmark_Menu(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='EURO_GROUP':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_EuroLive_List(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='APPLE_GROUP':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Apple_Group(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  elif cCINntvTyarzbmouqShwkXOlWsYEUB=='BAND_VODLIST':
   cCINntvTyarzbmouqShwkXOlWsYExi.dp_Band_VodList(cCINntvTyarzbmouqShwkXOlWsYExi.main_params)
  else:
   cCINntvTyarzbmouqShwkXOlWsYEDd
# Created by pyminifier (https://github.com/liftoff/pyminifier)
