__author__="NightRain"
VyhDbFCJmBnUHKTvkrdoEMaYQSNWep=print
VyhDbFCJmBnUHKTvkrdoEMaYQSNWeO=ImportError
VyhDbFCJmBnUHKTvkrdoEMaYQSNWeu=object
VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg=None
VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq=False
VyhDbFCJmBnUHKTvkrdoEMaYQSNWex=str
VyhDbFCJmBnUHKTvkrdoEMaYQSNWew=open
VyhDbFCJmBnUHKTvkrdoEMaYQSNWel=True
VyhDbFCJmBnUHKTvkrdoEMaYQSNWeP=len
VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX=int
VyhDbFCJmBnUHKTvkrdoEMaYQSNWec=range
VyhDbFCJmBnUHKTvkrdoEMaYQSNWes=bytes
VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI=Exception
VyhDbFCJmBnUHKTvkrdoEMaYQSNWAi=dict
VyhDbFCJmBnUHKTvkrdoEMaYQSNWAj=list
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 VyhDbFCJmBnUHKTvkrdoEMaYQSNWep('Cryptodome')
except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeO:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 VyhDbFCJmBnUHKTvkrdoEMaYQSNWep('Crypto')
VyhDbFCJmBnUHKTvkrdoEMaYQSNWiz={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
VyhDbFCJmBnUHKTvkrdoEMaYQSNWit ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
VyhDbFCJmBnUHKTvkrdoEMaYQSNWiR =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
VyhDbFCJmBnUHKTvkrdoEMaYQSNWiL=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class VyhDbFCJmBnUHKTvkrdoEMaYQSNWij(VyhDbFCJmBnUHKTvkrdoEMaYQSNWeu):
 def __init__(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.NETWORKCODE ='CSND0900'
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.OSCODE ='CSOD0900' 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TELECODE ='CSCD0900'
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SCREENCODE ='CSSD0100'
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.APIKEY_ATV ='b6ac9e6384d93d6e533b144b3ef22c42' 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SCREENCODE_ATV ='CSSD1300' 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.LIVE_LIMIT =20 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.VOD_LIMIT =24 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.EPISODE_LIMIT =30 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SEARCH_LIMIT =30 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.MOVIE_LIMIT =24 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN ='https://api.tving.com'
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN ='https://image.tving.com'
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SEARCH_DOMAIN ='https://search-api.tving.com'
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.LOGIN_DOMAIN ='https://user.tving.com'
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.URL_DOMAIN ='https://www.tving.com'
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.MOVIE_LITE =['2610061','2610161','261062']
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36'
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.MODEL ='windows_chrome_135.0.0.0' 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.USER_AGENT_ATV ='Mozilla/5.0 (Linux; Android 9; A95X_F3_Air Build/A95X_F3_AIR_M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36'
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.DEFAULT_HEADER ={'user-agent':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.USER_AGENT}
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_COOKIE_FILENAME =''
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN_FILENAME =''
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SEARCHED_FILE_NAME =''
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_SESSION_COOKIES1=''
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_SESSION_COOKIES2=''
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_STREAM_FILENAME =''
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_SESSION_TEXT1 =''
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_SESSION_TEXT2 =''
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.KodiVersion=20
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV ={}
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN ={}
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Init_TV_Total()
 def Init_TV_Total(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV={'account':{},'cookies':{},}
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN={}
 def callRequestCookies(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,jobtype,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,json=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,redirects=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWiG=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.DEFAULT_HEADER
  if headers:VyhDbFCJmBnUHKTvkrdoEMaYQSNWiG.update(headers)
  if jobtype=='Get':
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWie=requests.get(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,params=params,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWiG,cookies=cookies,allow_redirects=redirects)
  else:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWie=requests.post(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,data=payload,json=json,params=params,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWiG,cookies=cookies,allow_redirects=redirects)
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWie.status_code)+' - '+VyhDbFCJmBnUHKTvkrdoEMaYQSNWie.url)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWie
 def JsonFile_Save(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,filename,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiA):
  if filename=='':return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  try:
   fp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWew(filename,'w',-1,'utf-8')
   json.dump(VyhDbFCJmBnUHKTvkrdoEMaYQSNWiA,fp,indent=4,ensure_ascii=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq)
   fp.close()
  except:
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
 def JsonFile_Load(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,filename):
  if filename=='':return{}
  try:
   fp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWew(filename,'r',-1,'utf-8')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWiO=json.load(fp)
   fp.close()
  except:
   return{}
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWiO
 def TextFile_Save(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,filename,resText):
  if filename=='':return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  try:
   fp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWew(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
 def Save_session_acount(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWig,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiq,VyhDbFCJmBnUHKTvkrdoEMaYQSNWix):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['account']['tvid'] =base64.standard_b64encode(VyhDbFCJmBnUHKTvkrdoEMaYQSNWiu.encode()).decode('utf-8')
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['account']['tvpw'] =base64.standard_b64encode(VyhDbFCJmBnUHKTvkrdoEMaYQSNWig.encode()).decode('utf-8')
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['account']['tvtype']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWiq 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['account']['tvpf'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWix 
 def Load_session_acount(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWiu =base64.standard_b64decode(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['account']['tvid']).decode('utf-8')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWig =base64.standard_b64decode(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['account']['tvpw']).decode('utf-8')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWiq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['account']['tvtype']
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWix =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWiu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWig,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiq,VyhDbFCJmBnUHKTvkrdoEMaYQSNWix
 def make_stream_header(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,VyhDbFCJmBnUHKTvkrdoEMaYQSNWic,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWiw=''
  if VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI not in[{},VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,'']:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWil=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeP(VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI)
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX in VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI.items():
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWiw+='{}={}'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX)
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWil+=-1
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWil>0:VyhDbFCJmBnUHKTvkrdoEMaYQSNWiw+='; '
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWic['cookie']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWiw
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWis=''
  i=0
  for VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX in VyhDbFCJmBnUHKTvkrdoEMaYQSNWic.items():
   i=i+1
   if i>1:VyhDbFCJmBnUHKTvkrdoEMaYQSNWis+='&'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWis+='{}={}'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,urllib.parse.quote(VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX))
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWis
 def makeDefaultCookies(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI={}
  for VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX in VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies'].items():
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI[VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP]=VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI
 def getDeviceStr(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWji=[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWji.append('Windows') 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWji.append('Chrome') 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWji.append('ko-KR') 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWji.append('undefined') 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWji.append('24') 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWji.append(u'한국 표준시')
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWji.append('undefined') 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWji.append('undefined') 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWji.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjz=''
  for VyhDbFCJmBnUHKTvkrdoEMaYQSNWjt in VyhDbFCJmBnUHKTvkrdoEMaYQSNWji:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjz+=VyhDbFCJmBnUHKTvkrdoEMaYQSNWjt+'|'
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWjz
 def GetDefaultParams(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,uhd=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq):
  if uhd==VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjR={'apiKey':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.APIKEY,'networkCode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.NETWORKCODE,'osCode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.OSCODE,'teleCode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TELECODE,'screenCode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SCREENCODE,}
  else:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjR={'apiKey':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.APIKEY_ATV,'networkCode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.NETWORKCODE,'osCode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.OSCODE,'teleCode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TELECODE,'screenCode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SCREENCODE_ATV,}
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWjR
 def GetNoCache(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,timetype=1):
  if timetype==1:
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(time.time())
  else:
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(time.time()*1000)
 def GetUniqueid(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,hValue=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg):
  if hValue:
   import hashlib
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjL=hashlib.sha1()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjL.update(hValue.encode())
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjf=VyhDbFCJmBnUHKTvkrdoEMaYQSNWjL.hexdigest()[:8]
  else:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjG=[0 for i in VyhDbFCJmBnUHKTvkrdoEMaYQSNWec(256)]
   for i in VyhDbFCJmBnUHKTvkrdoEMaYQSNWec(256):
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWjG[i]='%02x'%(i)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWje=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(4294967295*random.random())|0
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjf=VyhDbFCJmBnUHKTvkrdoEMaYQSNWjG[255&VyhDbFCJmBnUHKTvkrdoEMaYQSNWje]+VyhDbFCJmBnUHKTvkrdoEMaYQSNWjG[VyhDbFCJmBnUHKTvkrdoEMaYQSNWje>>8&255]+VyhDbFCJmBnUHKTvkrdoEMaYQSNWjG[VyhDbFCJmBnUHKTvkrdoEMaYQSNWje>>16&255]+VyhDbFCJmBnUHKTvkrdoEMaYQSNWjG[VyhDbFCJmBnUHKTvkrdoEMaYQSNWje>>24&255]
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWjf
 def Web_DecryptKey(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjA=VyhDbFCJmBnUHKTvkrdoEMaYQSNWes('kss2lym0kdw1lks3','utf-8')
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWes('6yhlJ4WF9ZIj6I8n','utf-8')
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWjA,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjp
 def Web_EncryptCiphertext(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjx):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjO,VyhDbFCJmBnUHKTvkrdoEMaYQSNWju=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Web_DecryptKey()
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjg=AES.new(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjO,AES.MODE_CBC,VyhDbFCJmBnUHKTvkrdoEMaYQSNWju,)
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWjg.encrypt(Padding.pad(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjx.encode('utf-8'),16))
  return base64.standard_b64encode(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjq).decode('utf-8')
 def Web_DecryptPlaintext(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjq):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjO,VyhDbFCJmBnUHKTvkrdoEMaYQSNWju=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Web_DecryptKey()
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjg=AES.new(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjO,AES.MODE_CBC,VyhDbFCJmBnUHKTvkrdoEMaYQSNWju,)
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjx=Padding.unpad(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjg.decrypt(base64.standard_b64decode(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjq)),16)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWjx.decode('utf-8')
 def WebCookies_Load(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,wc_file):
  try:
   fp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWew(wc_file,'r',-1,'utf-8')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjw=fp.read()
   fp.close()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjl=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Web_DecryptPlaintext(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjw)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjl)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjP =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDeviceList()
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWjP not in['','-']:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies']['tving_uuid']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWjP+'-'+VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetUniqueid(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjP)
  except:
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
 def GetCredential2(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,user_id,user_pw,login_type,user_pf):
  try:
   if base64.standard_b64encode(user_id.encode()).decode('utf-8')=='a3ltOTUxMDg4':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx' 
   else:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx' 
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjc={'addon':'tvingm','method':'LOGIN','data':{'type':login_type,'id':user_id,'pw':user_pw,'pf':user_pf,}}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjc=json.dumps(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjc,separators=(',',':'))
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjc=base64.standard_b64encode(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjc.encode()).decode('utf-8')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWic={'proxy-mini':VyhDbFCJmBnUHKTvkrdoEMaYQSNWjc}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=requests.get(base64.standard_b64decode(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX).decode('utf-8'),headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWic)
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.status_code!=200:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Init_TV_Total()
    return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjI=base64.standard_b64decode(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text).decode('utf-8')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjI=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjI)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWjI
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Init_TV_Total()
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
 def GetCredential(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,user_id,user_pw,login_type,user_pf):
  from curl_cffi import requests
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzi='chrome' 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzj=requests.Session()
  try:
   if login_type=='0':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzt='https://user.tving.com/pc/user/otherLogin.tving?loginType=10&from=pc&csite=&isAuto=false&rtUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   else:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzt='https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWic={'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language':'ko-KR,ko;q=0.9','cache-control':'no-cache','pragma':'no-cache','priority':'u=0, i','referer':'https://www.tving.com/',}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzj.get(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzt,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWic,impersonate=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzi)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep('{} - {}'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.status_code,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.url))
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzR in VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.cookies.jar:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies'][VyhDbFCJmBnUHKTvkrdoEMaYQSNWzR.name]=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzR.value
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Init_TV_Total()
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzL=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzf={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq,'cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWic['referer']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzt
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzj.post(url=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzL,data=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzf,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWic,impersonate=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzi)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep('{} - {}'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.status_code,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.url))
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzR in VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.cookies.jar:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies'][VyhDbFCJmBnUHKTvkrdoEMaYQSNWzR.name]=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzR.value
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Init_TV_Total()
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzG=[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWze =''
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWic['referer']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzL
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzj.get(url=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA,data=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzf,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWic,impersonate=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzi)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep('{} - {}'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.status_code,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.url))
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzR in VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.cookies.jar:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies'][VyhDbFCJmBnUHKTvkrdoEMaYQSNWzR.name]=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzR.value
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzG =re.findall('data-profile-no="\d+"',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   for i in VyhDbFCJmBnUHKTvkrdoEMaYQSNWec(VyhDbFCJmBnUHKTvkrdoEMaYQSNWeP(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzG)):
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzp =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzG[i].replace('data-profile-no=','').replace('"','')
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzG[i]=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzp
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWze=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzG[user_pf]
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Init_TV_Total()
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzO ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWic['referer']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzf={'profileNo':VyhDbFCJmBnUHKTvkrdoEMaYQSNWze}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzj.post(url=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzO,data=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzf,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWic,impersonate=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzi)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep('{} - {}'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.status_code,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.url))
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzR in VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.cookies.jar:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies'][VyhDbFCJmBnUHKTvkrdoEMaYQSNWzR.name]=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzR.value
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Init_TV_Total()
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjP =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDeviceList()
  if VyhDbFCJmBnUHKTvkrdoEMaYQSNWjP not in['','-']:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies']['tving_uuid']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWjP+'-'+VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetUniqueid(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjP)
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.JsonFile_Save(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_COOKIE_FILENAME,VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
 def GetDeviceList(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu=[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzg='-'
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v1/user/device/list'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.makeDefaultCookies()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWzq,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu)
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu:
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['model'].lower().startswith('pc'):
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWzg=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['uuid']
     break
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzg=='-':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzg=VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetNoCache(timetype=1))
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzg
 def Get_Now_Datetime(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,mediacode,sel_quality,stype,pvrmode='-',optUHD=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX ={'streaming_url':'','subtitleYn':VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'','watermark':'','watermarkKey':'','qt_stream':'',}
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzg =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies']['tving_uuid'].split('-')[0] 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies']['tving_uuid'] 
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetNoCache(1))
   if stype!='tvingtv':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v2/media/stream/info'
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzc,'deviceInfo':'PC','noCache':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzs,}
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.makeDefaultCookies()
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI)
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.status_code!=200:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['error_msg']='First Step - {} error'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.status_code)
     return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']['code']=='060':
     for VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX in VyhDbFCJmBnUHKTvkrdoEMaYQSNWiz.items():
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX==sel_quality:
       VyhDbFCJmBnUHKTvkrdoEMaYQSNWti=VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP
    elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']['code']!='000':
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['error_msg']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']['message']
     return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
    else: 
     if not('stream' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWtj=[]
     for VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX in VyhDbFCJmBnUHKTvkrdoEMaYQSNWiz.items():
      for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['stream']['quality']:
       if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['active']=='Y' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['code']==VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP:
        VyhDbFCJmBnUHKTvkrdoEMaYQSNWtj.append({VyhDbFCJmBnUHKTvkrdoEMaYQSNWiz.get(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['code']):VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['code']})
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWti=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.CheckQuality(sel_quality,VyhDbFCJmBnUHKTvkrdoEMaYQSNWtj)
     try:
      if optUHD==VyhDbFCJmBnUHKTvkrdoEMaYQSNWel and VyhDbFCJmBnUHKTvkrdoEMaYQSNWti=='stream50' and 'stream_support_info' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['content']['info']:
       if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['content']['info']['stream_support_info']!=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg:
        if 'stream70' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['content']['info']['stream_support_info']:
         VyhDbFCJmBnUHKTvkrdoEMaYQSNWti='stream70'
         VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['qt_stream']='stream70'
     except:
      pass
     try:
      if optUHD==VyhDbFCJmBnUHKTvkrdoEMaYQSNWel and VyhDbFCJmBnUHKTvkrdoEMaYQSNWti=='stream50' and 'stream' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['content']['info']:
       if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['content']['info']['stream']!=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg:
        for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['content']['info']['stream']:
         if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['code']=='stream70':
          VyhDbFCJmBnUHKTvkrdoEMaYQSNWti='stream70'
          break
     except:
      pass
   else:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWti='stream40'
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['error_msg']='First Step - except error'
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['qt_stream']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWti
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(VyhDbFCJmBnUHKTvkrdoEMaYQSNWti)
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetNoCache(1))
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v3/media/stream/info'
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['qt_stream']=='stream70':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams(uhd=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel)
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'mediaCode':mediacode,'deviceId':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzg,'uuid':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzc,'deviceInfo':'PC_Chrome WebView','streamCode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWti,'noCache':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzs,'callingFrom':'HTML5','model':'android_chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header','streamType':'hls',}
   else:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'mediaCode':mediacode,'deviceId':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzg,'uuid':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzc,'deviceInfo':'PC_Chrome','streamCode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWti,'noCache':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzs,'callingFrom':'HTML5','model':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.makeDefaultCookies()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Post',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI,redirects=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']['code']!='000':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['error_msg']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']['message']
    return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWtz=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['stream']
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWtz['drm_yn']=='Y':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtz['playback']['drm']['widevine']
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWtL in VyhDbFCJmBnUHKTvkrdoEMaYQSNWtz['playback']['drm']['license']['drm_license_data']:
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWtL['drm_type']=='Widevine':
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['drm_server_url'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWtL['drm_server_url']
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['drm_header_key'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWtL['drm_header_key']
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['drm_header_value']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtL['drm_header_value']
      break
   else:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtz['playback']['non_drm']
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['error_msg']='Second Step - except error'
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtf=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzs
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR.split('|')[1]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR,VyhDbFCJmBnUHKTvkrdoEMaYQSNWtG,VyhDbFCJmBnUHKTvkrdoEMaYQSNWte=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Decrypt_Url(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR,mediacode,VyhDbFCJmBnUHKTvkrdoEMaYQSNWtf)
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['watermark'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWtG
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['watermarkKey']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWte
  if 'subtitles' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWtz:
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWtA in VyhDbFCJmBnUHKTvkrdoEMaYQSNWtz.get('subtitles'):
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWtA.get('code')in['KO','KO_CC']:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['subtitleYn']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
     break
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtp=urllib.parse.urlparse(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url'])
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtO =VyhDbFCJmBnUHKTvkrdoEMaYQSNWtp.path.strip('/').split('/')
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['url_filename']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtO[VyhDbFCJmBnUHKTvkrdoEMaYQSNWeP(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtO)-1]
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
 def TestUrl(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWic={}
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,redirects=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel)
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TextFile_Save(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_SESSION_TEXT1,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
 def Tving_Parse_mpd(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,stream_url,watermarkKey=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,watermark=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg):
  if watermarkKey not in['',VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg]:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWic={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=requests.get(url=stream_url,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWic,allow_redirects=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq)
  else:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=requests.get(url=stream_url)
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtu=VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.content.decode('utf-8')
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtg=0
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtq =ET.ElementTree(ET.fromstring(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtu))
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtx =VyhDbFCJmBnUHKTvkrdoEMaYQSNWtq.getroot()
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtw=re.match(r'\{.*\}',VyhDbFCJmBnUHKTvkrdoEMaYQSNWtx.tag)[0] 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtl=VyhDbFCJmBnUHKTvkrdoEMaYQSNWAi([node for _,node in ET.iterparse(io.StringIO(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtu),events=['start-ns'])])
  for VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRO in VyhDbFCJmBnUHKTvkrdoEMaYQSNWtl.items():
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP!='ns2':
    ET.register_namespace(VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRO)
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtP=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtx.find(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtw+'Period')
  for VyhDbFCJmBnUHKTvkrdoEMaYQSNWtX in VyhDbFCJmBnUHKTvkrdoEMaYQSNWtP.findall(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtw+'AdaptationSet'):
   if(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtX.attrib.get('mimeType')=='video/mp4' or VyhDbFCJmBnUHKTvkrdoEMaYQSNWtX.attrib.get('contentType')=='video'):
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWtc in VyhDbFCJmBnUHKTvkrdoEMaYQSNWtX.findall(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtw+'Representation'):
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWts=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtc.attrib.get('bandwidth'))
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWtg<VyhDbFCJmBnUHKTvkrdoEMaYQSNWts:VyhDbFCJmBnUHKTvkrdoEMaYQSNWtg=VyhDbFCJmBnUHKTvkrdoEMaYQSNWts
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWtc in VyhDbFCJmBnUHKTvkrdoEMaYQSNWtX.findall(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtw+'Representation'):
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWtg>VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtc.attrib.get('bandwidth')):
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWtX.remove(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtc)
   else:
    continue
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtI=ET.tostring(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtx).decode('utf-8')
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWRi='<?xml version="1.0" encoding="UTF-8"?>\n'
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TextFile_Save(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_STREAM_FILENAME,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRi+VyhDbFCJmBnUHKTvkrdoEMaYQSNWtI)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
 def Tving_Parse_m3u8(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,stream_url):
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=requests.get(url=stream_url,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,stream=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRj=VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.content.decode('utf-8')
   if '#EXTM3U' not in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRj:
    return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
   if '#EXT-X-STREAM-INF' not in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRj: 
    return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRz=0
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWRt in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRj.splitlines():
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWRt.startswith('#EXT-X-STREAM-INF'):
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRL=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.MediaLine_Parse(VyhDbFCJmBnUHKTvkrdoEMaYQSNWRt,'#EXT-X-STREAM-INF')
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWRz<VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(VyhDbFCJmBnUHKTvkrdoEMaYQSNWRL.get('BANDWIDTH')):
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWRz=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(VyhDbFCJmBnUHKTvkrdoEMaYQSNWRL.get('BANDWIDTH'))
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRf=[]
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRG=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWRt in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRj.splitlines():
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWRG==VyhDbFCJmBnUHKTvkrdoEMaYQSNWel:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRG=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
     continue
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWRt.startswith('#EXT-X-STREAM-INF'):
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRL=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.MediaLine_Parse(VyhDbFCJmBnUHKTvkrdoEMaYQSNWRt,'#EXT-X-STREAM-INF')
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWRz!=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(VyhDbFCJmBnUHKTvkrdoEMaYQSNWRL.get('BANDWIDTH')):
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWRG=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
      continue
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRf.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWRt)
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWRe='\n'.join(VyhDbFCJmBnUHKTvkrdoEMaYQSNWRf)
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TextFile_Save(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_STREAM_FILENAME,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRe)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
 def MediaLine_Parse(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRt,prefix):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWRL={}
  for VyhDbFCJmBnUHKTvkrdoEMaYQSNWRA in VyhDbFCJmBnUHKTvkrdoEMaYQSNWiR.split(VyhDbFCJmBnUHKTvkrdoEMaYQSNWRt.replace(prefix+':',''))[1::2]:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRp,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRO=VyhDbFCJmBnUHKTvkrdoEMaYQSNWRA.split('=',1)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRL[VyhDbFCJmBnUHKTvkrdoEMaYQSNWRp.upper()]=VyhDbFCJmBnUHKTvkrdoEMaYQSNWRO.replace('"','').strip()
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWRL
 def CheckQuality(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,sel_qt,VyhDbFCJmBnUHKTvkrdoEMaYQSNWtj):
  for VyhDbFCJmBnUHKTvkrdoEMaYQSNWRu in VyhDbFCJmBnUHKTvkrdoEMaYQSNWtj:
   if sel_qt>=VyhDbFCJmBnUHKTvkrdoEMaYQSNWAj(VyhDbFCJmBnUHKTvkrdoEMaYQSNWRu)[0]:return VyhDbFCJmBnUHKTvkrdoEMaYQSNWRu.get(VyhDbFCJmBnUHKTvkrdoEMaYQSNWAj(VyhDbFCJmBnUHKTvkrdoEMaYQSNWRu)[0])
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRg=VyhDbFCJmBnUHKTvkrdoEMaYQSNWRu.get(VyhDbFCJmBnUHKTvkrdoEMaYQSNWAj(VyhDbFCJmBnUHKTvkrdoEMaYQSNWRu)[0])
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWRg
 def makeOocUrl(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,ooc_params):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=''
  for VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX in ooc_params.items():
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX+="%s=%s^"%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX
 def GetLiveChannelList(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,stype,page_int):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu=[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v2/media/lives'
   if stype=='onair': 
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRx='CPCS0100,CPCS0400'
   else:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRx='CPCS0300'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'cacheType':'main','pageNo':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(page_int),'pageSize':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRx,}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if not('result' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRl=VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc=VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs=''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRP=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLw=''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['live_code']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRl =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['channel']['name']['ko']
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['episode']!=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['program']['name']['ko']
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc+', '+VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['episode']['frequency'])+'회'
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['episode']['synopsis']['ko']
    else:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['program']['name']['ko']
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['program']['synopsis']['ko']
    try: 
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =''
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =''
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=''
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz =''
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt =''
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLR =''
     for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['program']['image']:
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP0900':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
      elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP1800':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
      elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP2000':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
      elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP1900':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
      elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP0200':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLR =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
      elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP0500':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
      elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP0800':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI=='':
      for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['channel']['image']:
       if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIC0400':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
       elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIC1400':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
       elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIC1900':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
    except:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg
    try:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG =[]
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe=[]
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA =[]
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp=''
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO=''
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu=''
     for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('schedule').get('program').get('actor'):
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg!='' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg!=u'없음':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg)
     for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('schedule').get('program').get('director'):
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq!='' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq!='-' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq!=u'없음':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq)
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('schedule').get('program').get('category1_name').get('ko')!='':
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['program']['category1_name']['ko'])
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('schedule').get('program').get('category2_name').get('ko')!='':
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['program']['category2_name']['ko'])
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('schedule').get('program').get('product_year'):VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['program']['product_year']
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('schedule').get('program').get('grade_code') :VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO= VyhDbFCJmBnUHKTvkrdoEMaYQSNWit.get(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['program']['grade_code'])
     if 'broad_dt' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('schedule').get('program'):
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('schedule').get('program').get('broad_dt')
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu='%s-%s-%s'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[:4],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[4:6],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[6:])
    except:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRP=VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['broadcast_start_time'])[8:12]
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLw =VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['schedule']['broadcast_end_time'])[8:12]
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'channel':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRl,'title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc,'mediacode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRX,'thumbnail':{'poster':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi,'thumb':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI,'clearlogo':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj,'icon':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz,'fanart':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLR},'synopsis':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs,'channelepg':' [%s:%s ~ %s:%s]'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWRP[0:2],VyhDbFCJmBnUHKTvkrdoEMaYQSNWRP[2:],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLw[0:2],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLw[2:]),'cast':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG,'director':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe,'info_genre':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA,'year':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp,'mpaa':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO,'premiered':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu}
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['has_more']=='Y':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
 def GetProgramList(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,genre,orderby,page_int,genreCode='all'):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu=[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v2/media/episodes'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'cacheType':'main','pageSize':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(page_int),}
   if genre not in['all','PARAMOUNT']:VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx['categoryCode']=genre
   if genreCode!='all' :VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx['genreCode'] =genreCode 
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if not('result' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLP=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['program']['code']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['program']['name']['ko']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO =VyhDbFCJmBnUHKTvkrdoEMaYQSNWit.get(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['program'].get('grade_code'))
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz =''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt =''
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['program']['image']:
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP0900':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP0200':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP1800':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP2000':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP1900':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['program']['synopsis']['ko']
    try:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['channel']['name']['ko']
    except:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLX=''
    try:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG =[]
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe=[]
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA =[]
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp =''
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu=''
     for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('program').get('actor'):
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg!='' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg!='-' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg!=u'없음':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg)
     for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('program').get('director'):
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq!='' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq!='-' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq!=u'없음':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq)
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('program').get('category1_name').get('ko')!='':
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['program']['category1_name']['ko'])
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('program').get('category2_name').get('ko')!='':
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['program']['category2_name']['ko'])
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('program').get('product_year'):VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['program']['product_year']
     if 'broad_dt' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('program'):
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('program').get('broad_dt')
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu='%s-%s-%s'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[:4],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[4:6],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[6:])
    except:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'program':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLP,'title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc,'thumbnail':{'poster':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi,'thumb':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI,'clearlogo':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj,'icon':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz,'banner':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt,'fanart':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI},'synopsis':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs,'channel':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLX,'cast':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG,'director':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe,'info_genre':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA,'year':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp,'premiered':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu,'mpaa':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO}
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['has_more']=='Y':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
 def Get_UHD_ProgramList(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,page_int):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu=[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v2/operator/highlights'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams(uhd=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(page_int),'pocType':'APP_X_TVING_4.0.0',}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if not('result' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['content']['program']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLs =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['code']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['name']['ko'].strip()
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO =VyhDbFCJmBnUHKTvkrdoEMaYQSNWit.get(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc.get('grade_code'))
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['synopsis']['ko']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLX =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['content']['channel']['name']['ko']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['product_year']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz =''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt =''
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['image']:
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP0900':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP0200':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP1800':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP2000':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP1900':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA =[]
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG =[]
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe=[]
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu =''
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc.get('category1_name').get('ko')!='':
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['category1_name']['ko'])
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc.get('category2_name').get('ko')!='':
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['category2_name']['ko'])
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc.get('actor'):
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg!='' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg!='-' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg!=u'없음':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg)
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc.get('director'):
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq!='' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq!='-' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq!=u'없음':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq)
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc.get('broad_dt')not in[VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,'']:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc.get('broad_dt')
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu='%s-%s-%s'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[:4],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[4:6],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[6:])
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'program':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLs,'title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc,'mpaa':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO,'thumbnail':{'poster':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi,'thumb':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI,'clearlogo':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj,'icon':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz,'banner':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt,'fanart':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI},'channel':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLX,'synopsis':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs,'year':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp,'info_genre':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA,'cast':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG,'director':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe,'premiered':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu,}
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
 def Get_Origianl_ProgramList(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,page_int):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu=[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v2/media/band/originals'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'pageSize':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(page_int),}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.JsonFile_Save(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_SESSION_COOKIES2,VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI)
   if not('contents' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI['body']):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI['body']['contents']
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfi =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['vod_code']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['vod_name']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['image']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfj ='movie' if VyhDbFCJmBnUHKTvkrdoEMaYQSNWfi.startswith('M')else 'vod'
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'vod_code':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfi,'title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc,'thumbnail':{'poster':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi,'thumb':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi},'vod_type':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfj,}
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI['body']['has_more']=='Y':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
 def GetEpisodeList(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,program_code,page_int,orderby='desc'):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu=[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v2/media/frequency/program/'+program_code
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if not('result' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWfz=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['total_count'])
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWft =VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(VyhDbFCJmBnUHKTvkrdoEMaYQSNWfz//(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfR =(VyhDbFCJmBnUHKTvkrdoEMaYQSNWfz-1)-((page_int-1)*VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.EPISODE_LIMIT)
   else:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfR =(page_int-1)*VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.EPISODE_LIMIT
   for i in VyhDbFCJmBnUHKTvkrdoEMaYQSNWec(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.EPISODE_LIMIT):
    if orderby=='desc':
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL=VyhDbFCJmBnUHKTvkrdoEMaYQSNWfR-i
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL<0:break
    else:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL=VyhDbFCJmBnUHKTvkrdoEMaYQSNWfR+i
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL>=VyhDbFCJmBnUHKTvkrdoEMaYQSNWfz:break
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfG=VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw[VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL]['episode']['code']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw[VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL]['vod_name']['ko']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfe =''
    try:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx=VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw[VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL]['episode']['broadcast_date'])
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWfe='%s-%s-%s'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[:4],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[4:6],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[6:])
    except:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg
    try:
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw[VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL]['episode']['pip_cliptype']=='C012':
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWfe+=' - Quick VOD'
    except:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs =VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw[VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL]['episode']['synopsis']['ko']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz =''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt =''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLR =''
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw[VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL]['program']['image']:
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP0900':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP1800':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP2000':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP1900':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIP0200':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLR =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw[VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL]['episode']['image']:
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIE0400':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
    try:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWfA=VyhDbFCJmBnUHKTvkrdoEMaYQSNWfO=VyhDbFCJmBnUHKTvkrdoEMaYQSNWfu=''
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWfp=0
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWfA =VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw[VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL]['program']['name']['ko']
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWfO =VyhDbFCJmBnUHKTvkrdoEMaYQSNWfe
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWfu =VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw[VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL]['channel']['name']['ko']
     if 'frequency' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw[VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL]['episode']:VyhDbFCJmBnUHKTvkrdoEMaYQSNWfp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw[VyhDbFCJmBnUHKTvkrdoEMaYQSNWfL]['episode']['frequency']
    except:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'episode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfG,'title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc,'subtitle':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfe,'thumbnail':{'poster':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi,'thumb':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI,'clearlogo':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj,'icon':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz,'banner':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt,'fanart':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLR},'synopsis':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs,'info_title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfA,'aired':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfO,'studio':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfu,'frequency':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfp}
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWft>page_int:VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq,VyhDbFCJmBnUHKTvkrdoEMaYQSNWft
 def GetMovieList(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,genre,orderby,page_int):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu=[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v2/media/movies'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'pageSize':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx['categoryCode']=genre
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx['productPackageCode']=','.join(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.MOVIE_LITE)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if not('result' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw:
    if 'release_date' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('movie'):
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('movie').get('release_date'))[:4]
    else:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfg =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['movie']['code']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['movie']['name']['ko'].strip()
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp not in[VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,'0','']:VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc+=u' (%s)'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp)
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi=''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=''
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['movie']['image']:
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIM2100':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIM0400':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIM1800':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['movie']['story']['ko']
    try:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWfA =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['movie']['name']['ko'].strip()
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO =VyhDbFCJmBnUHKTvkrdoEMaYQSNWit.get(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('grade_code'))
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG=[]
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe=[]
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA=[]
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWfq=0
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu=''
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWfu =''
     for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('movie').get('actor'):
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg!='':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg)
     for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('movie').get('director'):
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq!='':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq)
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('movie').get('category1_name').get('ko')!='':
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['movie']['category1_name']['ko'])
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('movie').get('category2_name').get('ko')!='':
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['movie']['category2_name']['ko'])
     if 'duration' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('movie'):VyhDbFCJmBnUHKTvkrdoEMaYQSNWfq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('movie').get('duration')
     if 'release_date' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('movie'):
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx=VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('movie').get('release_date'))
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx!='0':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu='%s-%s-%s'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[:4],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[4:6],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[6:])
     if 'production' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('movie'):VyhDbFCJmBnUHKTvkrdoEMaYQSNWfu=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('movie').get('production')
    except:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'moviecode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfg,'title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc,'thumbnail':{'poster':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi,'thumb':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI,'clearlogo':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj,'fanart':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI},'synopsis':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs,'info_title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfA,'year':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp,'cast':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG,'director':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe,'info_genre':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA,'duration':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfq,'premiered':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu,'studio':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfu,'mpaa':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO}
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfx=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWfw in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['billing_package_id']:
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWfw in VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.MOVIE_LITE:
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWfx=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
      break
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWfx==VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq: 
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl['title']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl['title']+' [개별구매]'
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['has_more']=='Y':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
 def Get_UHD_MovieList(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,page_int):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu=[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v2/operator/highlights'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams(uhd=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(page_int),'pocType':'APP_X_TVING_4.0.0',}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if not('result' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['content']['movie']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLs =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['code']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['name']['ko'].strip()
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfA =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['name']['ko'].strip()
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['product_year']
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp:VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc+=u' (%s)'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['product_year'])
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['story']['ko']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfq =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['duration']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO =VyhDbFCJmBnUHKTvkrdoEMaYQSNWit.get(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc.get('grade_code'))
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfu =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['production']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi=''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=''
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA =[]
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG =[]
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe=[]
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu =''
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['image']:
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIM2100':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIM0400':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
     elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['code']=='CAIM1800':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf['url']
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['release_date']not in[VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,0]:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx=VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['release_date'])
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx!='0':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu='%s-%s-%s'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[:4],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[4:6],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[6:])
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc.get('category1_name').get('ko')!='':
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['category1_name']['ko'])
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc.get('category2_name').get('ko')!='':
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc['category2_name']['ko'])
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc.get('actor'):
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg!='':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLg)
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLc.get('director'):
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq!='':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLq)
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'moviecode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLs,'title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc,'thumbnail':{'poster':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi,'thumb':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI,'clearlogo':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj,'fanart':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI},'year':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp,'info_title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfA,'synopsis':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRs,'mpaa':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO,'duration':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfq,'premiered':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLu,'studio':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfu,'info_genre':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA,'cast':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG,'director':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe,}
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
 def GetMovieGenre(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu=[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v2/media/movie/curations'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if not('result' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfl =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['curation_code']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfP =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['curation_name']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'curation_code':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfl,'curation_name':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfP}
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
 def GetSearchList(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,search_key,page_int,stype):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWfX=[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/search/getSearch.jsp'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SCREENCODE,'os':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.OSCODE,'network':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.APIKEY,'networkCode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.NETWORKCODE,'osCode ':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.OSCODE,'teleCode ':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TELECODE,'screenCode ':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SCREENCODE}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SEARCH_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if stype=='vod':
    if not('programRsb' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWfX,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfc=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['programRsb']['dataList']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfs =VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['programRsb']['count'])
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWfc:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLP=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['mast_cd']
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['mast_nm']
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['web_url4']
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['web_url']
     try:
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG =[]
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe=[]
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA =[]
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWfq =0
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO =''
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp =''
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWfO =''
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('actor') !='' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('actor') !='-':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('actor').split(',')
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('director')!='' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('director')!='-':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('director').split(',')
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('cate_nm')!='' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('cate_nm')!='-':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('cate_nm').split('/')
      if 'targetage' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl:VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('targetage')
      if 'broad_dt' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl:
       VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('broad_dt')
       VyhDbFCJmBnUHKTvkrdoEMaYQSNWfO='%s-%s-%s'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[:4],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[4:6],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[6:])
       VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[:4]
     except:
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'program':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLP,'title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc,'thumbnail':{'poster':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi,'thumb':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI,'fanart':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI},'synopsis':'','cast':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG,'director':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe,'info_genre':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA,'duration':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfq,'mpaa':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO,'year':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp,'aired':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfO}
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWfX.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
   else:
    if not('vodMVRsb' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWfX,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['vodMVRsb']['dataList']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWfs =VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['vodMVRsb']['count'])
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWfI:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLP=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['mast_cd']
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['mast_nm'].strip()
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['web_url']
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=''
     try:
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG =[]
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe=[]
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA =[]
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWfq =0
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO =''
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp =''
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWfO =''
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('actor') !='' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('actor') !='-':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('actor').split(',')
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('director')!='' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('director')!='-':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('director').split(',')
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('cate_nm')!='' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('cate_nm')!='-':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('cate_nm').split('/')
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('runtime_sec')!='':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('runtime_sec')
      if 'grade_nm' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl:VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('grade_nm')
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('broad_dt')
      if data_str!='':
       VyhDbFCJmBnUHKTvkrdoEMaYQSNWfO='%s-%s-%s'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[:4],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[4:6],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[6:])
       VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp =VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[:4]
     except:
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'movie':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLP,'title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc,'thumbnail':{'poster':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi,'thumb':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI,'fanart':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI,'clearlogo':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj},'synopsis':'','cast':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLG,'director':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLe,'info_genre':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLA,'duration':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfq,'mpaa':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLO,'year':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLp,'aired':VyhDbFCJmBnUHKTvkrdoEMaYQSNWfO}
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWfX.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWfs>(page_int*VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.SEARCH_LIMIT):VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWfX,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
 def GetBookmarkInfo(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,videoid,vidtype):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+'/v2/media/program/'+videoid
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'pageNo':'1','pageSize':'10','order':'name',}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if not('body' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI):return{}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI['body']
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc=VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('name').get('ko').strip()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['title'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['title']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['mpaa'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWit.get(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('grade_code'))
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['plot'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('synopsis').get('ko')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['year'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('product_year')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['cast'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('actor')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['director']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('director')
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('category1_name').get('ko')!='':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['genre'].append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('category1_name').get('ko'))
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('category2_name').get('ko')!='':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['genre'].append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('category2_name').get('ko'))
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx=VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('broad_dt'))
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx!='0':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[:4],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[4:6],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[6:])
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =''
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =''
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=''
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz =''
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt =''
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf in VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('image'):
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('code')=='CAIP0900':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('url')
    elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('code')=='CAIP0200':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('url')
    elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('code')=='CAIP1800':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('url')
    elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('code')=='CAIP2000':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('url')
    elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('code')=='CAIP1900':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('url')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['thumbnail']['poster']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['thumbnail']['thumb']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['thumbnail']['clearlogo']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['thumbnail']['icon']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLz
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['thumbnail']['banner']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLt
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['thumbnail']['fanart']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI
  else:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+'/v2a/media/stream/info'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies']['tving_uuid'].split('-')[0],'uuid':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetNoCache(1)),'wm':'Y',}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if not('content' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI['body']):return{}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI['body']['content']['info']['movie']
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('name').get('ko').strip()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['title']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc +=u' (%s)'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('product_year'))
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['title'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWRc
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['mpaa'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWit.get(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('grade_code'))
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['plot'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('story').get('ko')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['year'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('product_year')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['studio'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('production')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['duration']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('duration')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['cast'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('actor')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['director']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('director')
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('category1_name').get('ko')!='':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['genre'].append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('category1_name').get('ko'))
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('category2_name').get('ko')!='':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['genre'].append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('category2_name').get('ko'))
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx=VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('release_date'))
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx!='0':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[:4],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[4:6],VyhDbFCJmBnUHKTvkrdoEMaYQSNWLx[6:])
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi=''
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =''
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=''
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf in VyhDbFCJmBnUHKTvkrdoEMaYQSNWGj.get('image'):
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('code')=='CAIM2100':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('url')
    elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('code')=='CAIM0400':VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('url')
    elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('code')=='CAIM1800':VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.IMG_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWLf.get('url')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['thumbnail']['poster']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['thumbnail']['thumb']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLi 
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['thumbnail']['clearlogo']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLj
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi['saveinfo']['thumbnail']['fanart']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWRI
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGi
 def GetEuroChannelList(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu=[]
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v2/operator/highlights'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetNoCache(2))}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if not('result' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu,VyhDbFCJmBnUHKTvkrdoEMaYQSNWRq
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGz =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Get_Now_Datetime()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGt=VyhDbFCJmBnUHKTvkrdoEMaYQSNWGz+datetime.timedelta(days=-1)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGt=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGt.strftime('%Y%m%d'))
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGR=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeX(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('content').get('banner_title2')[:8])
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWGt<=VyhDbFCJmBnUHKTvkrdoEMaYQSNWGR:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'channel':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('content').get('banner_sub_title3'),'title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('content').get('banner_title'),'subtitle':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl.get('content').get('banner_sub_title2'),}
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzu
 def Make_DecryptKey(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,step,mediacode='000',timecode='000'):
  if step=='1':
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjA=VyhDbFCJmBnUHKTvkrdoEMaYQSNWes('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWes('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjA=VyhDbFCJmBnUHKTvkrdoEMaYQSNWes('kss2lym0kdw1lks3','utf-8')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWes([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWjA,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjp
 def DecryptPlaintext(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjq,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjO,VyhDbFCJmBnUHKTvkrdoEMaYQSNWju):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjg=AES.new(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjO,AES.MODE_CBC,VyhDbFCJmBnUHKTvkrdoEMaYQSNWju,)
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWjx=Padding.unpad(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjg.decrypt(base64.standard_b64decode(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjq)),16)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWjx.decode('utf-8')
 def Decrypt_Url(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjq,mediacode,VyhDbFCJmBnUHKTvkrdoEMaYQSNWtf):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWGL=''
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtG=''
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWte=''
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjA,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Make_DecryptKey('1',mediacode=mediacode,timecode=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtf)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGf=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.DecryptPlaintext(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjq,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjA,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjp))
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGf)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGe =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGf.get('url')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWtG =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGf.get('watermark') if 'watermark' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWGf else ''
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWte=VyhDbFCJmBnUHKTvkrdoEMaYQSNWGf.get('watermark_key')if 'watermark_key' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWGf else ''
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjA,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjp=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Make_DecryptKey('2',mediacode=mediacode,timecode=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtf)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGL=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.DecryptPlaintext(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGe,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjA,VyhDbFCJmBnUHKTvkrdoEMaYQSNWjp)
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGL,VyhDbFCJmBnUHKTvkrdoEMaYQSNWtG,VyhDbFCJmBnUHKTvkrdoEMaYQSNWte
 def Get_Apple_buildId(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWGA=''
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX ='https://www.tving.com/more/special/SP0071'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGp=r'"buildId":"(.*?)"'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGA =re.compile(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGp,re.DOTALL).findall(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)[0]
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGA
 def Get_AppleGroup_List(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWGO=[]
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGA=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Get_Apple_buildId()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/_next/data/{}/ko/more/special/SP0071.json'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGA)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'key':'SP0071'}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.URL_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if not('pageProps' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGO
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWGu in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw:
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWGu['bandType']not in['VOD_BASIC']:continue
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGg =re.findall('/band/\w+|/curation/\w+',VyhDbFCJmBnUHKTvkrdoEMaYQSNWGu['moreUrl'])[0]
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'bandName':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGu['bandName'],'bandKey':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGg.split('/')[2],}
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGO.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGO
 def Get_Band_VodList(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,bandKey,nextApiUrl='-'):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWGq =[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWGx =''
  try:
   if bandKey.startswith('CR'):
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGg='/curation/{}'.format(bandKey)
   else: 
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGg='/band/{}'.format(bandKey)
   if nextApiUrl in[VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,'','-']:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGA=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Get_Apple_buildId()
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/_next/data/{}/ko/more{}.json'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGA,VyhDbFCJmBnUHKTvkrdoEMaYQSNWGg)
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'key':bandKey}
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.URL_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
    if not('pageProps' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGq,VyhDbFCJmBnUHKTvkrdoEMaYQSNWGx
    if bandKey.startswith('CR'):
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI['pageProps']['dehydratedState']['queries'][0]['state']['data']['data']['bands'][0]
    else:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['band']
   else:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX='{}{}{}'.format('https://gw.tving.com',nextApiUrl,'&screenCode=CSSD0100&osCode=CSOD0900')
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
    if not('data' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGq,VyhDbFCJmBnUHKTvkrdoEMaYQSNWGx
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI['data']
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWGu in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw['items']:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWGu['imageUrl']
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'program':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGu['code'],'title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGu['title'],'thumbnail':{'poster':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGw,'thumb':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGw,'fanart':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGw},}
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGq.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGx=VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw.get('nextApiUrl')or ''
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGq,VyhDbFCJmBnUHKTvkrdoEMaYQSNWGx
 def Get_bandCode_RankList(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWGl=[]
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWic={'authorization':'Bearer {}'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN['token']),'access-token':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN['accessToken'],}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGP=['https://gw.tving.com/bff/web/v3/home/main?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/drama?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/entertainment?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/movie?screenCode=CSSD0100&osCode=CSOD0900',]
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWGX in VyhDbFCJmBnUHKTvkrdoEMaYQSNWGP:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWGX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWic,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGc=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs in VyhDbFCJmBnUHKTvkrdoEMaYQSNWGc['data']['bands']:
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs['bandType']not in['VOD_BASIC_RANKING','VOD_BASIC_ORIGINAL']:
      continue
     if ':' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs['bandCode']:
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWGI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs['bandCode'].split(':')[0]
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWei=VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs['bandCode'].split(':')[1]
     else:
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWGI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs['bandCode']
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWei='TVING_ORIGINAL'
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'bandName':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs['bandName'],'bandCode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGI,'bandGroup':VyhDbFCJmBnUHKTvkrdoEMaYQSNWei,}
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWGl.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
   '''
   build_id = self.Get_Apple_buildId() # RawF3i7KTkfJ11pm2SOsS
   url   = 'https://www.tving.com/_next/data/{}/ko/more/special/SP0071.json?key=SP0071'.format(build_id )
   response = self.callRequestCookies('Get', url, payload=None, params=None, headers=None, cookies=None )
   res_json = json.loads(response.text )
   if not ('pageProps' in res_json): return bandCode_List
   info_list = res_json['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
   for iband in info_list:
    if iband['bandType'] != 'VOD_BASIC_RANKING' : continue
    temp_list = {'bandName' : iband['bandName'], 'bandCode' : iband['bandCode'], 'bandGroup' : 'TVING_APPLE_HOUR', }
    bandCode_List.append(temp_list )
   '''   
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGl
 def Get_bandCode_GroupCode(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,GroupCode):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWGI=''
  try:
   if GroupCode=='TVING_APPLE_HOUR':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGA=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Get_Apple_buildId()
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX ='https://www.tving.com/_next/data/{}/ko/more/special/SP0071.json?key=SP0071'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGA)
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
    if not('pageProps' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGI
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs in VyhDbFCJmBnUHKTvkrdoEMaYQSNWRw:
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs['bandType']!='VOD_BASIC_RANKING':continue
     return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs['bandCode']
   else:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWic={'authorization':'Bearer {}'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN['token']),'access-token':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN['accessToken'],}
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWGP=['https://gw.tving.com/bff/web/v3/home/main?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/drama?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/entertainment?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/movie?screenCode=CSSD0100&osCode=CSOD0900',]
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWGX in VyhDbFCJmBnUHKTvkrdoEMaYQSNWGP:
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWGX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWic,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
     VyhDbFCJmBnUHKTvkrdoEMaYQSNWGc=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
     for VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs in VyhDbFCJmBnUHKTvkrdoEMaYQSNWGc['data']['bands']:
      if(GroupCode in VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs['bandCode']or(GroupCode=='TVING_ORIGINAL' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs['bandType']=='VOD_BASIC_ORIGINAL')):
       if ':' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs['bandCode']:
        VyhDbFCJmBnUHKTvkrdoEMaYQSNWGI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs['bandCode'].split(':')[0]
       else:
        VyhDbFCJmBnUHKTvkrdoEMaYQSNWGI =VyhDbFCJmBnUHKTvkrdoEMaYQSNWGs['bandCode']
       return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGI
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGI
 def Get_Apple_NowList(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWGq =[]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWGx ='-'
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGA=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Get_Apple_buildId()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/_next/data/{}/ko/more/special/SP0071.json'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGA)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'key':'SP0071'}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.URL_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
   for VyhDbFCJmBnUHKTvkrdoEMaYQSNWej in VyhDbFCJmBnUHKTvkrdoEMaYQSNWLI:
    if VyhDbFCJmBnUHKTvkrdoEMaYQSNWej['bandType']=='VOD_BASIC_RANKING':
     for VyhDbFCJmBnUHKTvkrdoEMaYQSNWGu in VyhDbFCJmBnUHKTvkrdoEMaYQSNWej['items']:
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWGw=VyhDbFCJmBnUHKTvkrdoEMaYQSNWGu['imageUrl']
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl={'program':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGu['code'],'title':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGu['title'],'thumbnail':{'poster':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGw,'thumb':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGw,'fanart':VyhDbFCJmBnUHKTvkrdoEMaYQSNWGw},}
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWGq.append(VyhDbFCJmBnUHKTvkrdoEMaYQSNWLl)
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWGq,VyhDbFCJmBnUHKTvkrdoEMaYQSNWGx
 def Get_AccessToken(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif):
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.URL_DOMAIN
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.makeDefaultCookies()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI.pop('accessToken')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI)
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.status_code!=200:
    return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGp=r'<script id="__NEXT_DATA__" type="application/json">\s*(.*?)\s*</script>'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWez=re.compile(VyhDbFCJmBnUHKTvkrdoEMaYQSNWGp,re.DOTALL).findall(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)[0]
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWet =json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWez)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN['token'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWet.get('props').get('pageProps').get('userInfo').get('token')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN['authToken'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWet.get('props').get('pageProps').get('userInfo').get('authToken')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN['accessToken']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.cookies['accessToken']
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN['refreshToken']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWet.get('props').get('pageProps').get('userInfo').get('refreshToken')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWGz =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Get_Now_Datetime()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWeR=VyhDbFCJmBnUHKTvkrdoEMaYQSNWGz+datetime.timedelta(days=0)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN['token_date']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeR.strftime('%Y%m%d')
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.JsonFile_Save(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN_FILENAME,VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV_TOKEN)
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWel
 def GetLiveURL_Test(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif,mediacode,sel_quality):
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX ={'streaming_url':'','subtitleYn':VyhDbFCJmBnUHKTvkrdoEMaYQSNWeq,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzg =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies']['tving_uuid'].split('-')[0] 
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzc =VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.TV['cookies']['tving_uuid'] 
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetNoCache(1))
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v2/media/stream/info' 
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzc,'deviceInfo':'PC','noCache':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzs,}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.makeDefaultCookies()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Get',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI)
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.status_code!=200:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['error_msg']='First Step - {} error'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.status_code)
    return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']['code']=='060':
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX in VyhDbFCJmBnUHKTvkrdoEMaYQSNWiz.items():
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX==sel_quality:
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWti=VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP
   elif VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']['code']!='000':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['error_msg']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']['message']
    return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
   else: 
    if not('stream' in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']):return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWtj=[]
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX in VyhDbFCJmBnUHKTvkrdoEMaYQSNWiz.items():
     for VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl in VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['stream']['quality']:
      if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['active']=='Y' and VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['code']==VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP:
       VyhDbFCJmBnUHKTvkrdoEMaYQSNWtj.append({VyhDbFCJmBnUHKTvkrdoEMaYQSNWiz.get(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['code']):VyhDbFCJmBnUHKTvkrdoEMaYQSNWzl['code']})
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWti=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.CheckQuality(sel_quality,VyhDbFCJmBnUHKTvkrdoEMaYQSNWtj)
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['error_msg']='First Step - except error'
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
  try:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWex(VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetNoCache(1))
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA ='/v3/media/stream/info'
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.GetDefaultParams()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx={'mediaCode':mediacode,'deviceId':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzg,'uuid':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzc,'deviceInfo':'PC_Chrome','streamCode':VyhDbFCJmBnUHKTvkrdoEMaYQSNWti,'noCache':VyhDbFCJmBnUHKTvkrdoEMaYQSNWzs,'callingFrom':'HTML5','model':VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI.update(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzx)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.API_DOMAIN+VyhDbFCJmBnUHKTvkrdoEMaYQSNWzA
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.makeDefaultCookies()
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.callRequestCookies('Post',VyhDbFCJmBnUHKTvkrdoEMaYQSNWjX,payload=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,params=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzI,headers=VyhDbFCJmBnUHKTvkrdoEMaYQSNWeg,cookies=VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI,redirects=VyhDbFCJmBnUHKTvkrdoEMaYQSNWel)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw=json.loads(VyhDbFCJmBnUHKTvkrdoEMaYQSNWjs.text)
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']['code']!='000':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['error_msg']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['result']['message']
    return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWtz=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzw['body']['stream']
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWtz['drm_yn']=='Y':
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtz['playback']['drm']['widevine']
    for VyhDbFCJmBnUHKTvkrdoEMaYQSNWtL in VyhDbFCJmBnUHKTvkrdoEMaYQSNWtz['playback']['drm']['license']['drm_license_data']:
     if VyhDbFCJmBnUHKTvkrdoEMaYQSNWtL['drm_type']=='Widevine':
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['drm_server_url'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWtL['drm_server_url']
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['drm_header_key'] =VyhDbFCJmBnUHKTvkrdoEMaYQSNWtL['drm_header_key']
      VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['drm_header_value']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtL['drm_header_value']
      break
   else:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtz['playback']['non_drm']
  except VyhDbFCJmBnUHKTvkrdoEMaYQSNWeI as exception:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(exception)
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['error_msg']='Second Step - except error'
   return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtf=VyhDbFCJmBnUHKTvkrdoEMaYQSNWzs
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR.split('|')[1]
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR,VyhDbFCJmBnUHKTvkrdoEMaYQSNWtG,VyhDbFCJmBnUHKTvkrdoEMaYQSNWte=VyhDbFCJmBnUHKTvkrdoEMaYQSNWif.Decrypt_Url(VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR,mediacode,VyhDbFCJmBnUHKTvkrdoEMaYQSNWtf)
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url']=VyhDbFCJmBnUHKTvkrdoEMaYQSNWtR
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWeL =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url'].find('Policy=')
  if VyhDbFCJmBnUHKTvkrdoEMaYQSNWeL!=-1:
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWef =VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url'].split('?')[0]
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWeG=VyhDbFCJmBnUHKTvkrdoEMaYQSNWAi(urllib.parse.parse_qsl(urllib.parse.urlsplit(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url']).query))
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url']='{}&CloudFront-Policy={}'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url'],VyhDbFCJmBnUHKTvkrdoEMaYQSNWeG['Policy'])
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url']='{}&CloudFront-Signature={}'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url'],VyhDbFCJmBnUHKTvkrdoEMaYQSNWeG['Signature'])
   VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url'],VyhDbFCJmBnUHKTvkrdoEMaYQSNWeG['Key-Pair-Id'])
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWeA=['_tving_token','accessToken','authToken',]
  for VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX in VyhDbFCJmBnUHKTvkrdoEMaYQSNWiI.items():
   if VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP in VyhDbFCJmBnUHKTvkrdoEMaYQSNWeA:
    VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url']='{}&{}={}'.format(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url'],VyhDbFCJmBnUHKTvkrdoEMaYQSNWiP,VyhDbFCJmBnUHKTvkrdoEMaYQSNWiX)
  VyhDbFCJmBnUHKTvkrdoEMaYQSNWep(VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX['streaming_url'])
  return VyhDbFCJmBnUHKTvkrdoEMaYQSNWzX
# Created by pyminifier (https://github.com/liftoff/pyminifier)
