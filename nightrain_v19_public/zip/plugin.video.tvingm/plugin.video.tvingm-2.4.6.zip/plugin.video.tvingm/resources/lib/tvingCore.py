__author__="NightRain"
xeQugEYjypoKCTPmHhGrlqNzkBDVSI=ImportError
xeQugEYjypoKCTPmHhGrlqNzkBDVSO=object
xeQugEYjypoKCTPmHhGrlqNzkBDVSw=None
xeQugEYjypoKCTPmHhGrlqNzkBDVSA=False
xeQugEYjypoKCTPmHhGrlqNzkBDVSa=open
xeQugEYjypoKCTPmHhGrlqNzkBDVSF=True
xeQugEYjypoKCTPmHhGrlqNzkBDVSR=int
xeQugEYjypoKCTPmHhGrlqNzkBDVSv=range
xeQugEYjypoKCTPmHhGrlqNzkBDVSL=Exception
xeQugEYjypoKCTPmHhGrlqNzkBDVSi=print
xeQugEYjypoKCTPmHhGrlqNzkBDVSU=len
xeQugEYjypoKCTPmHhGrlqNzkBDVSf=str
xeQugEYjypoKCTPmHhGrlqNzkBDVSM=list
xeQugEYjypoKCTPmHhGrlqNzkBDVSW=bytes
xeQugEYjypoKCTPmHhGrlqNzkBDVct=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
try:
 from Cryptodome.PublicKey import RSA
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
except xeQugEYjypoKCTPmHhGrlqNzkBDVSI:
 from Crypto.PublicKey import RSA
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
xeQugEYjypoKCTPmHhGrlqNzkBDVts={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
xeQugEYjypoKCTPmHhGrlqNzkBDVtn ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class xeQugEYjypoKCTPmHhGrlqNzkBDVtd(xeQugEYjypoKCTPmHhGrlqNzkBDVSO):
 def __init__(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ):
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.NETWORKCODE ='CSND0900'
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.OSCODE ='CSOD0900' 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TELECODE ='CSCD0900'
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.SCREENCODE ='CSSD0100'
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.APIKEY_ATV ='b6ac9e6384d93d6e533b144b3ef22c42' 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.SCREENCODE_ATV ='CSSD1300' 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.LIVE_LIMIT =20 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.VOD_LIMIT =24 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.EPISODE_LIMIT =30 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.SEARCH_LIMIT =30 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.MOVIE_LIMIT =24 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN ='https://api.tving.com'
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN ='https://image.tving.com'
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.SEARCH_DOMAIN ='https://search.tving.com'
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.LOGIN_DOMAIN ='https://user.tving.com'
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.URL_DOMAIN ='https://www.tving.com'
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.MOVIE_LITE =['2610061','2610161','261062']
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.DEFAULT_HEADER ={'user-agent':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.USER_AGENT}
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV_SESSION_COOKIES1=''
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV_SESSION_COOKIES2=''
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV ={}
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.Init_TV_Total()
 def Init_TV_Total(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ):
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N',},}
 def callRequestCookies(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,jobtype,xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,redirects=xeQugEYjypoKCTPmHhGrlqNzkBDVSA):
  xeQugEYjypoKCTPmHhGrlqNzkBDVtS=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.DEFAULT_HEADER
  if headers:xeQugEYjypoKCTPmHhGrlqNzkBDVtS.update(headers)
  if jobtype=='Get':
   xeQugEYjypoKCTPmHhGrlqNzkBDVtc=requests.get(xeQugEYjypoKCTPmHhGrlqNzkBDVdW,params=params,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVtS,cookies=cookies,allow_redirects=redirects)
  else:
   xeQugEYjypoKCTPmHhGrlqNzkBDVtc=requests.post(xeQugEYjypoKCTPmHhGrlqNzkBDVdW,data=payload,params=params,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVtS,cookies=cookies,allow_redirects=redirects)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVtc
 def JsonFile_Save(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,filename,xeQugEYjypoKCTPmHhGrlqNzkBDVtb):
  if filename=='':return xeQugEYjypoKCTPmHhGrlqNzkBDVSA
  try:
   fp=xeQugEYjypoKCTPmHhGrlqNzkBDVSa(filename,'w',-1,'utf-8')
   json.dump(xeQugEYjypoKCTPmHhGrlqNzkBDVtb,fp,indent=4,ensure_ascii=xeQugEYjypoKCTPmHhGrlqNzkBDVSA)
   fp.close()
  except:
   return xeQugEYjypoKCTPmHhGrlqNzkBDVSA
  return xeQugEYjypoKCTPmHhGrlqNzkBDVSF
 def JsonFile_Load(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,filename):
  if filename=='':return{}
  try:
   fp=xeQugEYjypoKCTPmHhGrlqNzkBDVSa(filename,'r',-1,'utf-8')
   xeQugEYjypoKCTPmHhGrlqNzkBDVtI=json.load(fp)
   fp.close()
  except:
   return{}
  return xeQugEYjypoKCTPmHhGrlqNzkBDVtI
 def Save_session_acount(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,xeQugEYjypoKCTPmHhGrlqNzkBDVtO,xeQugEYjypoKCTPmHhGrlqNzkBDVtw,xeQugEYjypoKCTPmHhGrlqNzkBDVtA,xeQugEYjypoKCTPmHhGrlqNzkBDVta):
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['account']['tvid'] =base64.standard_b64encode(xeQugEYjypoKCTPmHhGrlqNzkBDVtO.encode()).decode('utf-8')
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['account']['tvpw'] =base64.standard_b64encode(xeQugEYjypoKCTPmHhGrlqNzkBDVtw.encode()).decode('utf-8')
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['account']['tvtype']=xeQugEYjypoKCTPmHhGrlqNzkBDVtA 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['account']['tvpf'] =xeQugEYjypoKCTPmHhGrlqNzkBDVta 
 def Load_session_acount(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ):
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVtO =base64.standard_b64decode(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['account']['tvid']).decode('utf-8')
   xeQugEYjypoKCTPmHhGrlqNzkBDVtw =base64.standard_b64decode(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['account']['tvpw']).decode('utf-8')
   xeQugEYjypoKCTPmHhGrlqNzkBDVtA=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['account']['tvtype']
   xeQugEYjypoKCTPmHhGrlqNzkBDVta =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return xeQugEYjypoKCTPmHhGrlqNzkBDVtO,xeQugEYjypoKCTPmHhGrlqNzkBDVtw,xeQugEYjypoKCTPmHhGrlqNzkBDVtA,xeQugEYjypoKCTPmHhGrlqNzkBDVta
 def makeDefaultCookies(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ):
  xeQugEYjypoKCTPmHhGrlqNzkBDVtF={}
  if xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_token']:xeQugEYjypoKCTPmHhGrlqNzkBDVtF['_tving_token']=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_token']
  if xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_userinfo']:xeQugEYjypoKCTPmHhGrlqNzkBDVtF['POC_USERINFO']=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_userinfo']
  if xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_maintoken']:xeQugEYjypoKCTPmHhGrlqNzkBDVtF[xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GLOBAL_COOKIENM['tv_maintoken']]=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_maintoken']
  if xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_cookiekey']:xeQugEYjypoKCTPmHhGrlqNzkBDVtF[xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GLOBAL_COOKIENM['tv_cookiekey']]=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_cookiekey']
  if xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_lockkey']:xeQugEYjypoKCTPmHhGrlqNzkBDVtF[xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GLOBAL_COOKIENM['tv_lockkey']]=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_lockkey']
  return xeQugEYjypoKCTPmHhGrlqNzkBDVtF
 def getDeviceStr(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ):
  xeQugEYjypoKCTPmHhGrlqNzkBDVtR=[]
  xeQugEYjypoKCTPmHhGrlqNzkBDVtR.append('Windows') 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtR.append('Chrome') 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtR.append('ko-KR') 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtR.append('undefined') 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtR.append('24') 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtR.append(u'한국 표준시')
  xeQugEYjypoKCTPmHhGrlqNzkBDVtR.append('undefined') 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtR.append('undefined') 
  xeQugEYjypoKCTPmHhGrlqNzkBDVtR.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  xeQugEYjypoKCTPmHhGrlqNzkBDVtv=''
  for xeQugEYjypoKCTPmHhGrlqNzkBDVtL in xeQugEYjypoKCTPmHhGrlqNzkBDVtR:
   xeQugEYjypoKCTPmHhGrlqNzkBDVtv+=xeQugEYjypoKCTPmHhGrlqNzkBDVtL+'|'
  return xeQugEYjypoKCTPmHhGrlqNzkBDVtv
 def GetDefaultParams(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,uhd=xeQugEYjypoKCTPmHhGrlqNzkBDVSA):
  if uhd==xeQugEYjypoKCTPmHhGrlqNzkBDVSA:
   xeQugEYjypoKCTPmHhGrlqNzkBDVti={'apiKey':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.APIKEY,'networkCode':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.NETWORKCODE,'osCode':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.OSCODE,'teleCode':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TELECODE,'screenCode':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.SCREENCODE,}
  else:
   xeQugEYjypoKCTPmHhGrlqNzkBDVti={'apiKey':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.APIKEY_ATV,'networkCode':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.NETWORKCODE,'osCode':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.OSCODE,'teleCode':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TELECODE,'screenCode':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.SCREENCODE_ATV,}
  return xeQugEYjypoKCTPmHhGrlqNzkBDVti
 def GetNoCache(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,timetype=1):
  if timetype==1:
   return xeQugEYjypoKCTPmHhGrlqNzkBDVSR(time.time())
  else:
   return xeQugEYjypoKCTPmHhGrlqNzkBDVSR(time.time()*1000)
 def GetUniqueid(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,hValue=xeQugEYjypoKCTPmHhGrlqNzkBDVSw):
  if hValue:
   import hashlib
   xeQugEYjypoKCTPmHhGrlqNzkBDVtU=hashlib.sha1()
   xeQugEYjypoKCTPmHhGrlqNzkBDVtU.update(hValue.encode())
   xeQugEYjypoKCTPmHhGrlqNzkBDVtf=xeQugEYjypoKCTPmHhGrlqNzkBDVtU.hexdigest()[:8]
  else:
   xeQugEYjypoKCTPmHhGrlqNzkBDVtM=[0 for i in xeQugEYjypoKCTPmHhGrlqNzkBDVSv(256)]
   for i in xeQugEYjypoKCTPmHhGrlqNzkBDVSv(256):
    xeQugEYjypoKCTPmHhGrlqNzkBDVtM[i]='%02x'%(i)
   xeQugEYjypoKCTPmHhGrlqNzkBDVtW=xeQugEYjypoKCTPmHhGrlqNzkBDVSR(4294967295*random.random())|0
   xeQugEYjypoKCTPmHhGrlqNzkBDVtf=xeQugEYjypoKCTPmHhGrlqNzkBDVtM[255&xeQugEYjypoKCTPmHhGrlqNzkBDVtW]+xeQugEYjypoKCTPmHhGrlqNzkBDVtM[xeQugEYjypoKCTPmHhGrlqNzkBDVtW>>8&255]+xeQugEYjypoKCTPmHhGrlqNzkBDVtM[xeQugEYjypoKCTPmHhGrlqNzkBDVtW>>16&255]+xeQugEYjypoKCTPmHhGrlqNzkBDVtM[xeQugEYjypoKCTPmHhGrlqNzkBDVtW>>24&255]
  return xeQugEYjypoKCTPmHhGrlqNzkBDVtf
 def GetCredential(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,user_id,user_pw,login_type,user_pf):
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdt=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   xeQugEYjypoKCTPmHhGrlqNzkBDVds={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Post',xeQugEYjypoKCTPmHhGrlqNzkBDVdt,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVds,params=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVSw)
   for xeQugEYjypoKCTPmHhGrlqNzkBDVdJ in xeQugEYjypoKCTPmHhGrlqNzkBDVdn.cookies:
    if xeQugEYjypoKCTPmHhGrlqNzkBDVdJ.name=='_tving_token':
     xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_token']=xeQugEYjypoKCTPmHhGrlqNzkBDVdJ.value
    elif xeQugEYjypoKCTPmHhGrlqNzkBDVdJ.name=='POC_USERINFO':
     xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_userinfo']=xeQugEYjypoKCTPmHhGrlqNzkBDVdJ.value
   if not xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_token']:
    xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.Init_TV_Total()
    return xeQugEYjypoKCTPmHhGrlqNzkBDVSA
   xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_maintoken']=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_token']
   if xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetProfileToken(user_pf)==xeQugEYjypoKCTPmHhGrlqNzkBDVSA:
    xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.Init_TV_Total()
    return xeQugEYjypoKCTPmHhGrlqNzkBDVSA
   xeQugEYjypoKCTPmHhGrlqNzkBDVdS =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDeviceList()
   if xeQugEYjypoKCTPmHhGrlqNzkBDVdS not in['','-']:
    xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_uuid']=xeQugEYjypoKCTPmHhGrlqNzkBDVdS+'-'+xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetUniqueid(xeQugEYjypoKCTPmHhGrlqNzkBDVdS)
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
   xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.Init_TV_Total()
   return xeQugEYjypoKCTPmHhGrlqNzkBDVSA
  return xeQugEYjypoKCTPmHhGrlqNzkBDVSF
 def GetProfileToken(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,user_pf):
  xeQugEYjypoKCTPmHhGrlqNzkBDVdc=[]
  xeQugEYjypoKCTPmHhGrlqNzkBDVdb =''
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   xeQugEYjypoKCTPmHhGrlqNzkBDVtF=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.makeDefaultCookies()
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdX,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVtF)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdc =re.findall('data-profile-no="\d+"',xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   for i in xeQugEYjypoKCTPmHhGrlqNzkBDVSv(xeQugEYjypoKCTPmHhGrlqNzkBDVSU(xeQugEYjypoKCTPmHhGrlqNzkBDVdc)):
    xeQugEYjypoKCTPmHhGrlqNzkBDVdI =xeQugEYjypoKCTPmHhGrlqNzkBDVdc[i].replace('data-profile-no=','').replace('"','')
    xeQugEYjypoKCTPmHhGrlqNzkBDVdc[i]=xeQugEYjypoKCTPmHhGrlqNzkBDVdI
   xeQugEYjypoKCTPmHhGrlqNzkBDVdb=xeQugEYjypoKCTPmHhGrlqNzkBDVdc[user_pf]
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
   xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.Init_TV_Total()
   return xeQugEYjypoKCTPmHhGrlqNzkBDVSA
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   xeQugEYjypoKCTPmHhGrlqNzkBDVtF=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.makeDefaultCookies()
   xeQugEYjypoKCTPmHhGrlqNzkBDVds={'profileNo':xeQugEYjypoKCTPmHhGrlqNzkBDVdb}
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Post',xeQugEYjypoKCTPmHhGrlqNzkBDVdX,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVds,params=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVtF)
   for xeQugEYjypoKCTPmHhGrlqNzkBDVdJ in xeQugEYjypoKCTPmHhGrlqNzkBDVdn.cookies:
    if xeQugEYjypoKCTPmHhGrlqNzkBDVdJ.name=='_tving_token':
     xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_token']=xeQugEYjypoKCTPmHhGrlqNzkBDVdJ.value
    elif xeQugEYjypoKCTPmHhGrlqNzkBDVdJ.name==xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GLOBAL_COOKIENM['tv_cookiekey']:
     xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_cookiekey']=xeQugEYjypoKCTPmHhGrlqNzkBDVdJ.value
    elif xeQugEYjypoKCTPmHhGrlqNzkBDVdJ.name==xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GLOBAL_COOKIENM['tv_lockkey']:
     xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_lockkey']=xeQugEYjypoKCTPmHhGrlqNzkBDVdJ.value
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
   xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.Init_TV_Total()
   return xeQugEYjypoKCTPmHhGrlqNzkBDVSA
  return xeQugEYjypoKCTPmHhGrlqNzkBDVSF
 def GetDeviceList(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ):
  xeQugEYjypoKCTPmHhGrlqNzkBDVdO=[]
  xeQugEYjypoKCTPmHhGrlqNzkBDVdw='-'
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='/v1/user/device/list'
   xeQugEYjypoKCTPmHhGrlqNzkBDVdA=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdX
   xeQugEYjypoKCTPmHhGrlqNzkBDVda={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   xeQugEYjypoKCTPmHhGrlqNzkBDVtF=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.makeDefaultCookies()
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdA,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVda,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVtF)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdF=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdO=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']
   for xeQugEYjypoKCTPmHhGrlqNzkBDVdR in xeQugEYjypoKCTPmHhGrlqNzkBDVdO:
    if xeQugEYjypoKCTPmHhGrlqNzkBDVdR['model']=='PC' or xeQugEYjypoKCTPmHhGrlqNzkBDVdR['model']=='PC-Chrome':
     xeQugEYjypoKCTPmHhGrlqNzkBDVdw=xeQugEYjypoKCTPmHhGrlqNzkBDVdR['uuid']
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVdw
 def Get_Now_Datetime(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,mediacode,sel_quality,stype,pvrmode='-',optUHD=xeQugEYjypoKCTPmHhGrlqNzkBDVSA):
  xeQugEYjypoKCTPmHhGrlqNzkBDVdL ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','error_msg':'',}
  xeQugEYjypoKCTPmHhGrlqNzkBDVdw =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_uuid'].split('-')[0] 
  xeQugEYjypoKCTPmHhGrlqNzkBDVdi =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_uuid'] 
  xeQugEYjypoKCTPmHhGrlqNzkBDVdU=xeQugEYjypoKCTPmHhGrlqNzkBDVSA 
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdf=xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetNoCache(1))
   if stype!='tvingtv':
    xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='/v2/media/stream/info' 
    xeQugEYjypoKCTPmHhGrlqNzkBDVdM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDefaultParams()
    xeQugEYjypoKCTPmHhGrlqNzkBDVda={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':xeQugEYjypoKCTPmHhGrlqNzkBDVdi,'deviceInfo':'PC','noCache':xeQugEYjypoKCTPmHhGrlqNzkBDVdf,}
    xeQugEYjypoKCTPmHhGrlqNzkBDVdM.update(xeQugEYjypoKCTPmHhGrlqNzkBDVda)
    xeQugEYjypoKCTPmHhGrlqNzkBDVdW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdX
    xeQugEYjypoKCTPmHhGrlqNzkBDVtF=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.makeDefaultCookies()
    xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVdM,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVtF)
    if xeQugEYjypoKCTPmHhGrlqNzkBDVdn.status_code!=200:
     xeQugEYjypoKCTPmHhGrlqNzkBDVdL['error_msg']='First Step - {} error'.format(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.status_code)
     return xeQugEYjypoKCTPmHhGrlqNzkBDVdL
    xeQugEYjypoKCTPmHhGrlqNzkBDVdF=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
    if xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['result']['code']=='060':
     for xeQugEYjypoKCTPmHhGrlqNzkBDVst,xeQugEYjypoKCTPmHhGrlqNzkBDVsw in xeQugEYjypoKCTPmHhGrlqNzkBDVts.items():
      if xeQugEYjypoKCTPmHhGrlqNzkBDVsw==sel_quality:
       xeQugEYjypoKCTPmHhGrlqNzkBDVsd=xeQugEYjypoKCTPmHhGrlqNzkBDVst
    elif xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['result']['code']!='000':
     xeQugEYjypoKCTPmHhGrlqNzkBDVdL['error_msg']=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['result']['message']
     return xeQugEYjypoKCTPmHhGrlqNzkBDVdL
    else: 
     if not('stream' in xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']):return xeQugEYjypoKCTPmHhGrlqNzkBDVdL
     xeQugEYjypoKCTPmHhGrlqNzkBDVsn=[]
     for xeQugEYjypoKCTPmHhGrlqNzkBDVst,xeQugEYjypoKCTPmHhGrlqNzkBDVsw in xeQugEYjypoKCTPmHhGrlqNzkBDVts.items():
      for xeQugEYjypoKCTPmHhGrlqNzkBDVdR in xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['stream']['quality']:
       if xeQugEYjypoKCTPmHhGrlqNzkBDVdR['active']=='Y' and xeQugEYjypoKCTPmHhGrlqNzkBDVdR['code']==xeQugEYjypoKCTPmHhGrlqNzkBDVst:
        xeQugEYjypoKCTPmHhGrlqNzkBDVsn.append({xeQugEYjypoKCTPmHhGrlqNzkBDVts.get(xeQugEYjypoKCTPmHhGrlqNzkBDVdR['code']):xeQugEYjypoKCTPmHhGrlqNzkBDVdR['code']})
     xeQugEYjypoKCTPmHhGrlqNzkBDVsd=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.CheckQuality(sel_quality,xeQugEYjypoKCTPmHhGrlqNzkBDVsn)
     try:
      if optUHD==xeQugEYjypoKCTPmHhGrlqNzkBDVSF and xeQugEYjypoKCTPmHhGrlqNzkBDVsd=='stream50' and 'stream_support_info' in xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['content']['info']:
       if 'stream70' in xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['content']['info']['stream_support_info']:
        xeQugEYjypoKCTPmHhGrlqNzkBDVsd='stream70'
        xeQugEYjypoKCTPmHhGrlqNzkBDVdU =xeQugEYjypoKCTPmHhGrlqNzkBDVSF
     except:
      pass
   else:
    xeQugEYjypoKCTPmHhGrlqNzkBDVsd='stream40'
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdL['error_msg']='First Step - except error'
   return xeQugEYjypoKCTPmHhGrlqNzkBDVdL
  xeQugEYjypoKCTPmHhGrlqNzkBDVSi(xeQugEYjypoKCTPmHhGrlqNzkBDVsd)
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdf=xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetNoCache(1))
   xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='/v2a/media/stream/info'
   if xeQugEYjypoKCTPmHhGrlqNzkBDVdU==xeQugEYjypoKCTPmHhGrlqNzkBDVSF:
    xeQugEYjypoKCTPmHhGrlqNzkBDVdM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDefaultParams(uhd=xeQugEYjypoKCTPmHhGrlqNzkBDVSF)
    xeQugEYjypoKCTPmHhGrlqNzkBDVda={'mediaCode':mediacode,'noCache':xeQugEYjypoKCTPmHhGrlqNzkBDVdf,'streamType':'hls','streamCode':xeQugEYjypoKCTPmHhGrlqNzkBDVsd,'deviceId':xeQugEYjypoKCTPmHhGrlqNzkBDVdw,'adReq':'none','wm':'Y','ad_device':'','uuid':xeQugEYjypoKCTPmHhGrlqNzkBDVdi,'deviceInfo':'android_tv',}
   else:
    xeQugEYjypoKCTPmHhGrlqNzkBDVdM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDefaultParams()
    xeQugEYjypoKCTPmHhGrlqNzkBDVda={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':xeQugEYjypoKCTPmHhGrlqNzkBDVsd,'deviceId':xeQugEYjypoKCTPmHhGrlqNzkBDVdw,'uuid':xeQugEYjypoKCTPmHhGrlqNzkBDVdi,'deviceInfo':'PC_Chrome','noCache':xeQugEYjypoKCTPmHhGrlqNzkBDVdf,'wm':'Y'}
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM.update(xeQugEYjypoKCTPmHhGrlqNzkBDVda)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdX
   xeQugEYjypoKCTPmHhGrlqNzkBDVtF=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.makeDefaultCookies()
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVdM,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVtF,redirects=xeQugEYjypoKCTPmHhGrlqNzkBDVSA)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdF=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.JsonFile_Save(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV_SESSION_COOKIES1,xeQugEYjypoKCTPmHhGrlqNzkBDVdF)
   if xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['result']['code']!='000':
    xeQugEYjypoKCTPmHhGrlqNzkBDVdL['error_msg']=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['result']['message']
    return xeQugEYjypoKCTPmHhGrlqNzkBDVdL
   xeQugEYjypoKCTPmHhGrlqNzkBDVsJ=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['stream']
   if 'drm_license_assertion' in xeQugEYjypoKCTPmHhGrlqNzkBDVsJ:
    xeQugEYjypoKCTPmHhGrlqNzkBDVdL['drm_license']=xeQugEYjypoKCTPmHhGrlqNzkBDVsJ['drm_license_assertion']
    if '4k_nondrm_url' in xeQugEYjypoKCTPmHhGrlqNzkBDVsJ['broadcast']and xeQugEYjypoKCTPmHhGrlqNzkBDVdU==xeQugEYjypoKCTPmHhGrlqNzkBDVSF:
     xeQugEYjypoKCTPmHhGrlqNzkBDVsS =xeQugEYjypoKCTPmHhGrlqNzkBDVsJ['broadcast']['4k_nondrm_url']
     xeQugEYjypoKCTPmHhGrlqNzkBDVdL['drm_license']=''
    else:
     xeQugEYjypoKCTPmHhGrlqNzkBDVsS =xeQugEYjypoKCTPmHhGrlqNzkBDVsJ['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in xeQugEYjypoKCTPmHhGrlqNzkBDVsJ['broadcast']):return xeQugEYjypoKCTPmHhGrlqNzkBDVdL
    xeQugEYjypoKCTPmHhGrlqNzkBDVsS=xeQugEYjypoKCTPmHhGrlqNzkBDVsJ['broadcast']['broad_url']
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdL['error_msg']='Second Step - except error'
   return xeQugEYjypoKCTPmHhGrlqNzkBDVdL
  xeQugEYjypoKCTPmHhGrlqNzkBDVsc=xeQugEYjypoKCTPmHhGrlqNzkBDVdf
  xeQugEYjypoKCTPmHhGrlqNzkBDVsS=xeQugEYjypoKCTPmHhGrlqNzkBDVsS.split('|')[1]
  xeQugEYjypoKCTPmHhGrlqNzkBDVsS,xeQugEYjypoKCTPmHhGrlqNzkBDVsb,xeQugEYjypoKCTPmHhGrlqNzkBDVsX=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.Decrypt_Url(xeQugEYjypoKCTPmHhGrlqNzkBDVsS,mediacode,xeQugEYjypoKCTPmHhGrlqNzkBDVsc)
  xeQugEYjypoKCTPmHhGrlqNzkBDVdL['streaming_url']=xeQugEYjypoKCTPmHhGrlqNzkBDVsS
  xeQugEYjypoKCTPmHhGrlqNzkBDVdL['watermark'] =xeQugEYjypoKCTPmHhGrlqNzkBDVsb
  xeQugEYjypoKCTPmHhGrlqNzkBDVdL['watermarkKey']=xeQugEYjypoKCTPmHhGrlqNzkBDVsX
  return xeQugEYjypoKCTPmHhGrlqNzkBDVdL
 def CheckQuality(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,sel_qt,xeQugEYjypoKCTPmHhGrlqNzkBDVsn):
  for xeQugEYjypoKCTPmHhGrlqNzkBDVsI in xeQugEYjypoKCTPmHhGrlqNzkBDVsn:
   if sel_qt>=xeQugEYjypoKCTPmHhGrlqNzkBDVSM(xeQugEYjypoKCTPmHhGrlqNzkBDVsI)[0]:return xeQugEYjypoKCTPmHhGrlqNzkBDVsI.get(xeQugEYjypoKCTPmHhGrlqNzkBDVSM(xeQugEYjypoKCTPmHhGrlqNzkBDVsI)[0])
   xeQugEYjypoKCTPmHhGrlqNzkBDVsO=xeQugEYjypoKCTPmHhGrlqNzkBDVsI.get(xeQugEYjypoKCTPmHhGrlqNzkBDVSM(xeQugEYjypoKCTPmHhGrlqNzkBDVsI)[0])
  return xeQugEYjypoKCTPmHhGrlqNzkBDVsO
 def makeOocUrl(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,ooc_params):
  xeQugEYjypoKCTPmHhGrlqNzkBDVdW=''
  for xeQugEYjypoKCTPmHhGrlqNzkBDVst,xeQugEYjypoKCTPmHhGrlqNzkBDVsw in ooc_params.items():
   xeQugEYjypoKCTPmHhGrlqNzkBDVdW+="%s=%s^"%(xeQugEYjypoKCTPmHhGrlqNzkBDVst,xeQugEYjypoKCTPmHhGrlqNzkBDVsw)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVdW
 def GetLiveChannelList(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,stype,page_int):
  xeQugEYjypoKCTPmHhGrlqNzkBDVdO=[]
  xeQugEYjypoKCTPmHhGrlqNzkBDVsA=xeQugEYjypoKCTPmHhGrlqNzkBDVSA
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='/v2/media/lives'
   if stype=='onair': 
    xeQugEYjypoKCTPmHhGrlqNzkBDVsa='CPCS0100,CPCS0400'
   else:
    xeQugEYjypoKCTPmHhGrlqNzkBDVsa='CPCS0300'
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDefaultParams()
   xeQugEYjypoKCTPmHhGrlqNzkBDVda={'cacheType':'main','pageNo':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(page_int),'pageSize':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':xeQugEYjypoKCTPmHhGrlqNzkBDVsa,}
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM.update(xeQugEYjypoKCTPmHhGrlqNzkBDVda)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdX
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVdM,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVSw)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdF=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   if not('result' in xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']):return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
   xeQugEYjypoKCTPmHhGrlqNzkBDVsF=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['result']
   for xeQugEYjypoKCTPmHhGrlqNzkBDVdR in xeQugEYjypoKCTPmHhGrlqNzkBDVsF:
    xeQugEYjypoKCTPmHhGrlqNzkBDVsR=xeQugEYjypoKCTPmHhGrlqNzkBDVsi=xeQugEYjypoKCTPmHhGrlqNzkBDVsU=''
    xeQugEYjypoKCTPmHhGrlqNzkBDVsv=xeQugEYjypoKCTPmHhGrlqNzkBDVnF=''
    xeQugEYjypoKCTPmHhGrlqNzkBDVsL=xeQugEYjypoKCTPmHhGrlqNzkBDVdR['live_code']
    xeQugEYjypoKCTPmHhGrlqNzkBDVsR =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['channel']['name']['ko']
    if xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['episode']!=xeQugEYjypoKCTPmHhGrlqNzkBDVSw:
     xeQugEYjypoKCTPmHhGrlqNzkBDVsi =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['program']['name']['ko']
     xeQugEYjypoKCTPmHhGrlqNzkBDVsi =xeQugEYjypoKCTPmHhGrlqNzkBDVsi+', '+xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['episode']['frequency'])+'회'
     xeQugEYjypoKCTPmHhGrlqNzkBDVsU=xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['episode']['synopsis']['ko']
    else:
     xeQugEYjypoKCTPmHhGrlqNzkBDVsi =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['program']['name']['ko']
     xeQugEYjypoKCTPmHhGrlqNzkBDVsU=xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['program']['synopsis']['ko']
    try: 
     xeQugEYjypoKCTPmHhGrlqNzkBDVsf =''
     xeQugEYjypoKCTPmHhGrlqNzkBDVsM =''
     xeQugEYjypoKCTPmHhGrlqNzkBDVsW=''
     xeQugEYjypoKCTPmHhGrlqNzkBDVnt =''
     xeQugEYjypoKCTPmHhGrlqNzkBDVnd =''
     xeQugEYjypoKCTPmHhGrlqNzkBDVns =''
     for xeQugEYjypoKCTPmHhGrlqNzkBDVnJ in xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['program']['image']:
      if xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP0900':xeQugEYjypoKCTPmHhGrlqNzkBDVsM =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
      elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP1800':xeQugEYjypoKCTPmHhGrlqNzkBDVsW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
      elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP2000':xeQugEYjypoKCTPmHhGrlqNzkBDVnt =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
      elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP1900':xeQugEYjypoKCTPmHhGrlqNzkBDVnd =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
      elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP0200':xeQugEYjypoKCTPmHhGrlqNzkBDVns =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
      elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP0500':xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
      elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP0800':xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     if xeQugEYjypoKCTPmHhGrlqNzkBDVsf=='':
      for xeQugEYjypoKCTPmHhGrlqNzkBDVnJ in xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['channel']['image']:
       if xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIC0400':xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
       elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIC1400':xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
       elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIC1900':xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
    except:
     xeQugEYjypoKCTPmHhGrlqNzkBDVSw
    try:
     xeQugEYjypoKCTPmHhGrlqNzkBDVnS =[]
     xeQugEYjypoKCTPmHhGrlqNzkBDVnc=[]
     xeQugEYjypoKCTPmHhGrlqNzkBDVnb =[]
     xeQugEYjypoKCTPmHhGrlqNzkBDVnX=''
     xeQugEYjypoKCTPmHhGrlqNzkBDVnI=''
     xeQugEYjypoKCTPmHhGrlqNzkBDVnO=''
     for xeQugEYjypoKCTPmHhGrlqNzkBDVnw in xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('schedule').get('program').get('actor'):
      if xeQugEYjypoKCTPmHhGrlqNzkBDVnw!='' and xeQugEYjypoKCTPmHhGrlqNzkBDVnw!=u'없음':xeQugEYjypoKCTPmHhGrlqNzkBDVnS.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnw)
     for xeQugEYjypoKCTPmHhGrlqNzkBDVnA in xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('schedule').get('program').get('director'):
      if xeQugEYjypoKCTPmHhGrlqNzkBDVnA!='' and xeQugEYjypoKCTPmHhGrlqNzkBDVnA!='-' and xeQugEYjypoKCTPmHhGrlqNzkBDVnA!=u'없음':xeQugEYjypoKCTPmHhGrlqNzkBDVnc.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnA)
     if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('schedule').get('program').get('category1_name').get('ko')!='':
      xeQugEYjypoKCTPmHhGrlqNzkBDVnb.append(xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['program']['category1_name']['ko'])
     if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('schedule').get('program').get('category2_name').get('ko')!='':
      xeQugEYjypoKCTPmHhGrlqNzkBDVnb.append(xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['program']['category2_name']['ko'])
     if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('schedule').get('program').get('product_year'):xeQugEYjypoKCTPmHhGrlqNzkBDVnX=xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['program']['product_year']
     if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('schedule').get('program').get('grade_code') :xeQugEYjypoKCTPmHhGrlqNzkBDVnI= xeQugEYjypoKCTPmHhGrlqNzkBDVtn.get(xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['program']['grade_code'])
     if 'broad_dt' in xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('schedule').get('program'):
      xeQugEYjypoKCTPmHhGrlqNzkBDVna =xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('schedule').get('program').get('broad_dt')
      xeQugEYjypoKCTPmHhGrlqNzkBDVnO='%s-%s-%s'%(xeQugEYjypoKCTPmHhGrlqNzkBDVna[:4],xeQugEYjypoKCTPmHhGrlqNzkBDVna[4:6],xeQugEYjypoKCTPmHhGrlqNzkBDVna[6:])
    except:
     xeQugEYjypoKCTPmHhGrlqNzkBDVSw
    xeQugEYjypoKCTPmHhGrlqNzkBDVsv=xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['broadcast_start_time'])[8:12]
    xeQugEYjypoKCTPmHhGrlqNzkBDVnF =xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVdR['schedule']['broadcast_end_time'])[8:12]
    xeQugEYjypoKCTPmHhGrlqNzkBDVnR={'channel':xeQugEYjypoKCTPmHhGrlqNzkBDVsR,'title':xeQugEYjypoKCTPmHhGrlqNzkBDVsi,'mediacode':xeQugEYjypoKCTPmHhGrlqNzkBDVsL,'thumbnail':{'poster':xeQugEYjypoKCTPmHhGrlqNzkBDVsM,'thumb':xeQugEYjypoKCTPmHhGrlqNzkBDVsf,'clearlogo':xeQugEYjypoKCTPmHhGrlqNzkBDVsW,'icon':xeQugEYjypoKCTPmHhGrlqNzkBDVnt,'fanart':xeQugEYjypoKCTPmHhGrlqNzkBDVns},'synopsis':xeQugEYjypoKCTPmHhGrlqNzkBDVsU,'channelepg':' [%s:%s ~ %s:%s]'%(xeQugEYjypoKCTPmHhGrlqNzkBDVsv[0:2],xeQugEYjypoKCTPmHhGrlqNzkBDVsv[2:],xeQugEYjypoKCTPmHhGrlqNzkBDVnF[0:2],xeQugEYjypoKCTPmHhGrlqNzkBDVnF[2:]),'cast':xeQugEYjypoKCTPmHhGrlqNzkBDVnS,'director':xeQugEYjypoKCTPmHhGrlqNzkBDVnc,'info_genre':xeQugEYjypoKCTPmHhGrlqNzkBDVnb,'year':xeQugEYjypoKCTPmHhGrlqNzkBDVnX,'mpaa':xeQugEYjypoKCTPmHhGrlqNzkBDVnI,'premiered':xeQugEYjypoKCTPmHhGrlqNzkBDVnO}
    xeQugEYjypoKCTPmHhGrlqNzkBDVdO.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnR)
   if xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['has_more']=='Y':
    xeQugEYjypoKCTPmHhGrlqNzkBDVsA=xeQugEYjypoKCTPmHhGrlqNzkBDVSF
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
 def GetProgramList(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,genre,orderby,page_int,genreCode='all'):
  xeQugEYjypoKCTPmHhGrlqNzkBDVdO=[]
  xeQugEYjypoKCTPmHhGrlqNzkBDVsA=xeQugEYjypoKCTPmHhGrlqNzkBDVSA
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='/v2/media/episodes'
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDefaultParams()
   xeQugEYjypoKCTPmHhGrlqNzkBDVda={'cacheType':'main','pageSize':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(page_int),}
   if genre !='all':xeQugEYjypoKCTPmHhGrlqNzkBDVda['categoryCode']=genre
   if genreCode!='all':xeQugEYjypoKCTPmHhGrlqNzkBDVda['genreCode'] =genreCode 
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM.update(xeQugEYjypoKCTPmHhGrlqNzkBDVda)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdX
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVdM,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVSw)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdF=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   if not('result' in xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']):return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
   xeQugEYjypoKCTPmHhGrlqNzkBDVsF=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['result']
   for xeQugEYjypoKCTPmHhGrlqNzkBDVdR in xeQugEYjypoKCTPmHhGrlqNzkBDVsF:
    xeQugEYjypoKCTPmHhGrlqNzkBDVnv=xeQugEYjypoKCTPmHhGrlqNzkBDVdR['program']['code']
    xeQugEYjypoKCTPmHhGrlqNzkBDVsi =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['program']['name']['ko']
    xeQugEYjypoKCTPmHhGrlqNzkBDVnI =xeQugEYjypoKCTPmHhGrlqNzkBDVtn.get(xeQugEYjypoKCTPmHhGrlqNzkBDVdR['program'].get('grade_code'))
    xeQugEYjypoKCTPmHhGrlqNzkBDVsM =''
    xeQugEYjypoKCTPmHhGrlqNzkBDVsf =''
    xeQugEYjypoKCTPmHhGrlqNzkBDVsW=''
    xeQugEYjypoKCTPmHhGrlqNzkBDVnt =''
    xeQugEYjypoKCTPmHhGrlqNzkBDVnd =''
    for xeQugEYjypoKCTPmHhGrlqNzkBDVnJ in xeQugEYjypoKCTPmHhGrlqNzkBDVdR['program']['image']:
     if xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP0900':xeQugEYjypoKCTPmHhGrlqNzkBDVsM =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP0200':xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP1800':xeQugEYjypoKCTPmHhGrlqNzkBDVsW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP2000':xeQugEYjypoKCTPmHhGrlqNzkBDVnt =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP1900':xeQugEYjypoKCTPmHhGrlqNzkBDVnd =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
    xeQugEYjypoKCTPmHhGrlqNzkBDVsU =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['program']['synopsis']['ko']
    try:
     xeQugEYjypoKCTPmHhGrlqNzkBDVnL=xeQugEYjypoKCTPmHhGrlqNzkBDVdR['channel']['name']['ko']
    except:
     xeQugEYjypoKCTPmHhGrlqNzkBDVnL=''
    try:
     xeQugEYjypoKCTPmHhGrlqNzkBDVnS =[]
     xeQugEYjypoKCTPmHhGrlqNzkBDVnc=[]
     xeQugEYjypoKCTPmHhGrlqNzkBDVnb =[]
     xeQugEYjypoKCTPmHhGrlqNzkBDVnX =''
     xeQugEYjypoKCTPmHhGrlqNzkBDVnO=''
     for xeQugEYjypoKCTPmHhGrlqNzkBDVnw in xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('program').get('actor'):
      if xeQugEYjypoKCTPmHhGrlqNzkBDVnw!='' and xeQugEYjypoKCTPmHhGrlqNzkBDVnw!='-' and xeQugEYjypoKCTPmHhGrlqNzkBDVnw!=u'없음':xeQugEYjypoKCTPmHhGrlqNzkBDVnS.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnw)
     for xeQugEYjypoKCTPmHhGrlqNzkBDVnA in xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('program').get('director'):
      if xeQugEYjypoKCTPmHhGrlqNzkBDVnA!='' and xeQugEYjypoKCTPmHhGrlqNzkBDVnA!='-' and xeQugEYjypoKCTPmHhGrlqNzkBDVnA!=u'없음':xeQugEYjypoKCTPmHhGrlqNzkBDVnc.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnA)
     if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('program').get('category1_name').get('ko')!='':
      xeQugEYjypoKCTPmHhGrlqNzkBDVnb.append(xeQugEYjypoKCTPmHhGrlqNzkBDVdR['program']['category1_name']['ko'])
     if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('program').get('category2_name').get('ko')!='':
      xeQugEYjypoKCTPmHhGrlqNzkBDVnb.append(xeQugEYjypoKCTPmHhGrlqNzkBDVdR['program']['category2_name']['ko'])
     if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('program').get('product_year'):xeQugEYjypoKCTPmHhGrlqNzkBDVnX=xeQugEYjypoKCTPmHhGrlqNzkBDVdR['program']['product_year']
     if 'broad_dt' in xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('program'):
      xeQugEYjypoKCTPmHhGrlqNzkBDVna =xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('program').get('broad_dt')
      xeQugEYjypoKCTPmHhGrlqNzkBDVnO='%s-%s-%s'%(xeQugEYjypoKCTPmHhGrlqNzkBDVna[:4],xeQugEYjypoKCTPmHhGrlqNzkBDVna[4:6],xeQugEYjypoKCTPmHhGrlqNzkBDVna[6:])
    except:
     xeQugEYjypoKCTPmHhGrlqNzkBDVSw
    xeQugEYjypoKCTPmHhGrlqNzkBDVnR={'program':xeQugEYjypoKCTPmHhGrlqNzkBDVnv,'title':xeQugEYjypoKCTPmHhGrlqNzkBDVsi,'thumbnail':{'poster':xeQugEYjypoKCTPmHhGrlqNzkBDVsM,'thumb':xeQugEYjypoKCTPmHhGrlqNzkBDVsf,'clearlogo':xeQugEYjypoKCTPmHhGrlqNzkBDVsW,'icon':xeQugEYjypoKCTPmHhGrlqNzkBDVnt,'banner':xeQugEYjypoKCTPmHhGrlqNzkBDVnd,'fanart':xeQugEYjypoKCTPmHhGrlqNzkBDVsf},'synopsis':xeQugEYjypoKCTPmHhGrlqNzkBDVsU,'channel':xeQugEYjypoKCTPmHhGrlqNzkBDVnL,'cast':xeQugEYjypoKCTPmHhGrlqNzkBDVnS,'director':xeQugEYjypoKCTPmHhGrlqNzkBDVnc,'info_genre':xeQugEYjypoKCTPmHhGrlqNzkBDVnb,'year':xeQugEYjypoKCTPmHhGrlqNzkBDVnX,'premiered':xeQugEYjypoKCTPmHhGrlqNzkBDVnO,'mpaa':xeQugEYjypoKCTPmHhGrlqNzkBDVnI}
    xeQugEYjypoKCTPmHhGrlqNzkBDVdO.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnR)
   if xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['has_more']=='Y':xeQugEYjypoKCTPmHhGrlqNzkBDVsA=xeQugEYjypoKCTPmHhGrlqNzkBDVSF
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
 def Get_UHD_ProgramList(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,page_int):
  xeQugEYjypoKCTPmHhGrlqNzkBDVdO=[]
  xeQugEYjypoKCTPmHhGrlqNzkBDVsA=xeQugEYjypoKCTPmHhGrlqNzkBDVSA
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='/v2/operator/highlights'
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDefaultParams(uhd=xeQugEYjypoKCTPmHhGrlqNzkBDVSF)
   xeQugEYjypoKCTPmHhGrlqNzkBDVda={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(page_int),'pocType':'APP_X_TVING_4.0.0',}
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM.update(xeQugEYjypoKCTPmHhGrlqNzkBDVda)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdX
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVdM,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVSw)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdF=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   if not('result' in xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']):return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
   xeQugEYjypoKCTPmHhGrlqNzkBDVsF=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['result']
   for xeQugEYjypoKCTPmHhGrlqNzkBDVdR in xeQugEYjypoKCTPmHhGrlqNzkBDVsF:
    xeQugEYjypoKCTPmHhGrlqNzkBDVni=xeQugEYjypoKCTPmHhGrlqNzkBDVdR['content']['program']
    xeQugEYjypoKCTPmHhGrlqNzkBDVnU =xeQugEYjypoKCTPmHhGrlqNzkBDVni['code']
    xeQugEYjypoKCTPmHhGrlqNzkBDVsi =xeQugEYjypoKCTPmHhGrlqNzkBDVni['name']['ko'].strip()
    xeQugEYjypoKCTPmHhGrlqNzkBDVnI =xeQugEYjypoKCTPmHhGrlqNzkBDVtn.get(xeQugEYjypoKCTPmHhGrlqNzkBDVni.get('grade_code'))
    xeQugEYjypoKCTPmHhGrlqNzkBDVsU =xeQugEYjypoKCTPmHhGrlqNzkBDVni['synopsis']['ko']
    xeQugEYjypoKCTPmHhGrlqNzkBDVnL =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['content']['channel']['name']['ko']
    xeQugEYjypoKCTPmHhGrlqNzkBDVnX =xeQugEYjypoKCTPmHhGrlqNzkBDVni['product_year']
    xeQugEYjypoKCTPmHhGrlqNzkBDVsM =''
    xeQugEYjypoKCTPmHhGrlqNzkBDVsf =''
    xeQugEYjypoKCTPmHhGrlqNzkBDVsW=''
    xeQugEYjypoKCTPmHhGrlqNzkBDVnt =''
    xeQugEYjypoKCTPmHhGrlqNzkBDVnd =''
    for xeQugEYjypoKCTPmHhGrlqNzkBDVnJ in xeQugEYjypoKCTPmHhGrlqNzkBDVni['image']:
     if xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP0900':xeQugEYjypoKCTPmHhGrlqNzkBDVsM =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP0200':xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP1800':xeQugEYjypoKCTPmHhGrlqNzkBDVsW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP2000':xeQugEYjypoKCTPmHhGrlqNzkBDVnt =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP1900':xeQugEYjypoKCTPmHhGrlqNzkBDVnd =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
    xeQugEYjypoKCTPmHhGrlqNzkBDVnb =[]
    xeQugEYjypoKCTPmHhGrlqNzkBDVnS =[]
    xeQugEYjypoKCTPmHhGrlqNzkBDVnc=[]
    xeQugEYjypoKCTPmHhGrlqNzkBDVnO =''
    if xeQugEYjypoKCTPmHhGrlqNzkBDVni.get('category1_name').get('ko')!='':
     xeQugEYjypoKCTPmHhGrlqNzkBDVnb.append(xeQugEYjypoKCTPmHhGrlqNzkBDVni['category1_name']['ko'])
    if xeQugEYjypoKCTPmHhGrlqNzkBDVni.get('category2_name').get('ko')!='':
     xeQugEYjypoKCTPmHhGrlqNzkBDVnb.append(xeQugEYjypoKCTPmHhGrlqNzkBDVni['category2_name']['ko'])
    for xeQugEYjypoKCTPmHhGrlqNzkBDVnw in xeQugEYjypoKCTPmHhGrlqNzkBDVni.get('actor'):
     if xeQugEYjypoKCTPmHhGrlqNzkBDVnw!='' and xeQugEYjypoKCTPmHhGrlqNzkBDVnw!='-' and xeQugEYjypoKCTPmHhGrlqNzkBDVnw!=u'없음':xeQugEYjypoKCTPmHhGrlqNzkBDVnS.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnw)
    for xeQugEYjypoKCTPmHhGrlqNzkBDVnA in xeQugEYjypoKCTPmHhGrlqNzkBDVni.get('director'):
     if xeQugEYjypoKCTPmHhGrlqNzkBDVnA!='' and xeQugEYjypoKCTPmHhGrlqNzkBDVnA!='-' and xeQugEYjypoKCTPmHhGrlqNzkBDVnA!=u'없음':xeQugEYjypoKCTPmHhGrlqNzkBDVnc.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnA)
    if xeQugEYjypoKCTPmHhGrlqNzkBDVni.get('broad_dt')not in[xeQugEYjypoKCTPmHhGrlqNzkBDVSw,'']:
     xeQugEYjypoKCTPmHhGrlqNzkBDVna =xeQugEYjypoKCTPmHhGrlqNzkBDVni.get('broad_dt')
     xeQugEYjypoKCTPmHhGrlqNzkBDVnO='%s-%s-%s'%(xeQugEYjypoKCTPmHhGrlqNzkBDVna[:4],xeQugEYjypoKCTPmHhGrlqNzkBDVna[4:6],xeQugEYjypoKCTPmHhGrlqNzkBDVna[6:])
    xeQugEYjypoKCTPmHhGrlqNzkBDVnR={'program':xeQugEYjypoKCTPmHhGrlqNzkBDVnU,'title':xeQugEYjypoKCTPmHhGrlqNzkBDVsi,'mpaa':xeQugEYjypoKCTPmHhGrlqNzkBDVnI,'thumbnail':{'poster':xeQugEYjypoKCTPmHhGrlqNzkBDVsM,'thumb':xeQugEYjypoKCTPmHhGrlqNzkBDVsf,'clearlogo':xeQugEYjypoKCTPmHhGrlqNzkBDVsW,'icon':xeQugEYjypoKCTPmHhGrlqNzkBDVnt,'banner':xeQugEYjypoKCTPmHhGrlqNzkBDVnd,'fanart':xeQugEYjypoKCTPmHhGrlqNzkBDVsf},'channel':xeQugEYjypoKCTPmHhGrlqNzkBDVnL,'synopsis':xeQugEYjypoKCTPmHhGrlqNzkBDVsU,'year':xeQugEYjypoKCTPmHhGrlqNzkBDVnX,'info_genre':xeQugEYjypoKCTPmHhGrlqNzkBDVnb,'cast':xeQugEYjypoKCTPmHhGrlqNzkBDVnS,'director':xeQugEYjypoKCTPmHhGrlqNzkBDVnc,'premiered':xeQugEYjypoKCTPmHhGrlqNzkBDVnO,}
    xeQugEYjypoKCTPmHhGrlqNzkBDVdO.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnR)
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
 def GetEpisodeList(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,program_code,page_int,orderby='desc'):
  xeQugEYjypoKCTPmHhGrlqNzkBDVdO=[]
  xeQugEYjypoKCTPmHhGrlqNzkBDVsA=xeQugEYjypoKCTPmHhGrlqNzkBDVSA
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='/v2/media/frequency/program/'+program_code
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDefaultParams()
   xeQugEYjypoKCTPmHhGrlqNzkBDVda={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM.update(xeQugEYjypoKCTPmHhGrlqNzkBDVda)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdX
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVdM,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVSw)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdF=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   if not('result' in xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']):return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
   xeQugEYjypoKCTPmHhGrlqNzkBDVsF=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['result']
   xeQugEYjypoKCTPmHhGrlqNzkBDVnf=xeQugEYjypoKCTPmHhGrlqNzkBDVSR(xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['total_count'])
   xeQugEYjypoKCTPmHhGrlqNzkBDVnM =xeQugEYjypoKCTPmHhGrlqNzkBDVSR(xeQugEYjypoKCTPmHhGrlqNzkBDVnf//(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    xeQugEYjypoKCTPmHhGrlqNzkBDVnW =(xeQugEYjypoKCTPmHhGrlqNzkBDVnf-1)-((page_int-1)*xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.EPISODE_LIMIT)
   else:
    xeQugEYjypoKCTPmHhGrlqNzkBDVnW =(page_int-1)*xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.EPISODE_LIMIT
   for i in xeQugEYjypoKCTPmHhGrlqNzkBDVSv(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.EPISODE_LIMIT):
    if orderby=='desc':
     xeQugEYjypoKCTPmHhGrlqNzkBDVJt=xeQugEYjypoKCTPmHhGrlqNzkBDVnW-i
     if xeQugEYjypoKCTPmHhGrlqNzkBDVJt<0:break
    else:
     xeQugEYjypoKCTPmHhGrlqNzkBDVJt=xeQugEYjypoKCTPmHhGrlqNzkBDVnW+i
     if xeQugEYjypoKCTPmHhGrlqNzkBDVJt>=xeQugEYjypoKCTPmHhGrlqNzkBDVnf:break
    xeQugEYjypoKCTPmHhGrlqNzkBDVJd=xeQugEYjypoKCTPmHhGrlqNzkBDVsF[xeQugEYjypoKCTPmHhGrlqNzkBDVJt]['episode']['code']
    xeQugEYjypoKCTPmHhGrlqNzkBDVsi =xeQugEYjypoKCTPmHhGrlqNzkBDVsF[xeQugEYjypoKCTPmHhGrlqNzkBDVJt]['vod_name']['ko']
    xeQugEYjypoKCTPmHhGrlqNzkBDVJs =''
    try:
     xeQugEYjypoKCTPmHhGrlqNzkBDVna=xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVsF[xeQugEYjypoKCTPmHhGrlqNzkBDVJt]['episode']['broadcast_date'])
     xeQugEYjypoKCTPmHhGrlqNzkBDVJs='%s-%s-%s'%(xeQugEYjypoKCTPmHhGrlqNzkBDVna[:4],xeQugEYjypoKCTPmHhGrlqNzkBDVna[4:6],xeQugEYjypoKCTPmHhGrlqNzkBDVna[6:])
    except:
     xeQugEYjypoKCTPmHhGrlqNzkBDVSw
    try:
     if xeQugEYjypoKCTPmHhGrlqNzkBDVsF[xeQugEYjypoKCTPmHhGrlqNzkBDVJt]['episode']['pip_cliptype']=='C012':
      xeQugEYjypoKCTPmHhGrlqNzkBDVJs+=' - Quick VOD'
    except:
     xeQugEYjypoKCTPmHhGrlqNzkBDVSw
    xeQugEYjypoKCTPmHhGrlqNzkBDVsU =xeQugEYjypoKCTPmHhGrlqNzkBDVsF[xeQugEYjypoKCTPmHhGrlqNzkBDVJt]['episode']['synopsis']['ko']
    xeQugEYjypoKCTPmHhGrlqNzkBDVsM =''
    xeQugEYjypoKCTPmHhGrlqNzkBDVsf =''
    xeQugEYjypoKCTPmHhGrlqNzkBDVsW=''
    xeQugEYjypoKCTPmHhGrlqNzkBDVnt =''
    xeQugEYjypoKCTPmHhGrlqNzkBDVnd =''
    xeQugEYjypoKCTPmHhGrlqNzkBDVns =''
    for xeQugEYjypoKCTPmHhGrlqNzkBDVnJ in xeQugEYjypoKCTPmHhGrlqNzkBDVsF[xeQugEYjypoKCTPmHhGrlqNzkBDVJt]['program']['image']:
     if xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP0900':xeQugEYjypoKCTPmHhGrlqNzkBDVsM =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP1800':xeQugEYjypoKCTPmHhGrlqNzkBDVsW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP2000':xeQugEYjypoKCTPmHhGrlqNzkBDVnt =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP1900':xeQugEYjypoKCTPmHhGrlqNzkBDVnd =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIP0200':xeQugEYjypoKCTPmHhGrlqNzkBDVns =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
    for xeQugEYjypoKCTPmHhGrlqNzkBDVnJ in xeQugEYjypoKCTPmHhGrlqNzkBDVsF[xeQugEYjypoKCTPmHhGrlqNzkBDVJt]['episode']['image']:
     if xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIE0400':xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
    try:
     xeQugEYjypoKCTPmHhGrlqNzkBDVJn=xeQugEYjypoKCTPmHhGrlqNzkBDVJc=xeQugEYjypoKCTPmHhGrlqNzkBDVJb=''
     xeQugEYjypoKCTPmHhGrlqNzkBDVJS=0
     xeQugEYjypoKCTPmHhGrlqNzkBDVJn =xeQugEYjypoKCTPmHhGrlqNzkBDVsF[xeQugEYjypoKCTPmHhGrlqNzkBDVJt]['program']['name']['ko']
     xeQugEYjypoKCTPmHhGrlqNzkBDVJc =xeQugEYjypoKCTPmHhGrlqNzkBDVJs
     xeQugEYjypoKCTPmHhGrlqNzkBDVJb =xeQugEYjypoKCTPmHhGrlqNzkBDVsF[xeQugEYjypoKCTPmHhGrlqNzkBDVJt]['channel']['name']['ko']
     if 'frequency' in xeQugEYjypoKCTPmHhGrlqNzkBDVsF[xeQugEYjypoKCTPmHhGrlqNzkBDVJt]['episode']:xeQugEYjypoKCTPmHhGrlqNzkBDVJS=xeQugEYjypoKCTPmHhGrlqNzkBDVsF[xeQugEYjypoKCTPmHhGrlqNzkBDVJt]['episode']['frequency']
    except:
     xeQugEYjypoKCTPmHhGrlqNzkBDVSw
    xeQugEYjypoKCTPmHhGrlqNzkBDVnR={'episode':xeQugEYjypoKCTPmHhGrlqNzkBDVJd,'title':xeQugEYjypoKCTPmHhGrlqNzkBDVsi,'subtitle':xeQugEYjypoKCTPmHhGrlqNzkBDVJs,'thumbnail':{'poster':xeQugEYjypoKCTPmHhGrlqNzkBDVsM,'thumb':xeQugEYjypoKCTPmHhGrlqNzkBDVsf,'clearlogo':xeQugEYjypoKCTPmHhGrlqNzkBDVsW,'icon':xeQugEYjypoKCTPmHhGrlqNzkBDVnt,'banner':xeQugEYjypoKCTPmHhGrlqNzkBDVnd,'fanart':xeQugEYjypoKCTPmHhGrlqNzkBDVns},'synopsis':xeQugEYjypoKCTPmHhGrlqNzkBDVsU,'info_title':xeQugEYjypoKCTPmHhGrlqNzkBDVJn,'aired':xeQugEYjypoKCTPmHhGrlqNzkBDVJc,'studio':xeQugEYjypoKCTPmHhGrlqNzkBDVJb,'frequency':xeQugEYjypoKCTPmHhGrlqNzkBDVJS}
    xeQugEYjypoKCTPmHhGrlqNzkBDVdO.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnR)
   if xeQugEYjypoKCTPmHhGrlqNzkBDVnM>page_int:xeQugEYjypoKCTPmHhGrlqNzkBDVsA=xeQugEYjypoKCTPmHhGrlqNzkBDVSF
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA,xeQugEYjypoKCTPmHhGrlqNzkBDVnM
 def GetMovieList(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,genre,orderby,page_int):
  xeQugEYjypoKCTPmHhGrlqNzkBDVdO=[]
  xeQugEYjypoKCTPmHhGrlqNzkBDVsA=xeQugEYjypoKCTPmHhGrlqNzkBDVSA
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='/v2/media/movies'
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDefaultParams()
   xeQugEYjypoKCTPmHhGrlqNzkBDVda={'pageSize':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N','pageNo':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(page_int),}
   if genre!='all' :xeQugEYjypoKCTPmHhGrlqNzkBDVda['categoryCode']=genre
   xeQugEYjypoKCTPmHhGrlqNzkBDVda['productPackageCode']=','.join(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.MOVIE_LITE)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM.update(xeQugEYjypoKCTPmHhGrlqNzkBDVda)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdX
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVdM,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVSw)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdF=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   if not('result' in xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']):return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
   xeQugEYjypoKCTPmHhGrlqNzkBDVsF=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['result']
   for xeQugEYjypoKCTPmHhGrlqNzkBDVdR in xeQugEYjypoKCTPmHhGrlqNzkBDVsF:
    if 'release_date' in xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('movie'):
     xeQugEYjypoKCTPmHhGrlqNzkBDVnX=xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('movie').get('release_date'))[:4]
    else:
     xeQugEYjypoKCTPmHhGrlqNzkBDVnX=xeQugEYjypoKCTPmHhGrlqNzkBDVSw
    xeQugEYjypoKCTPmHhGrlqNzkBDVJX =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['movie']['code']
    xeQugEYjypoKCTPmHhGrlqNzkBDVsi =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['movie']['name']['ko'].strip()
    if xeQugEYjypoKCTPmHhGrlqNzkBDVnX not in[xeQugEYjypoKCTPmHhGrlqNzkBDVSw,'0','']:xeQugEYjypoKCTPmHhGrlqNzkBDVsi+=u' (%s)'%(xeQugEYjypoKCTPmHhGrlqNzkBDVnX)
    xeQugEYjypoKCTPmHhGrlqNzkBDVsM=''
    xeQugEYjypoKCTPmHhGrlqNzkBDVsf =''
    xeQugEYjypoKCTPmHhGrlqNzkBDVsW=''
    for xeQugEYjypoKCTPmHhGrlqNzkBDVnJ in xeQugEYjypoKCTPmHhGrlqNzkBDVdR['movie']['image']:
     if xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIM2100':xeQugEYjypoKCTPmHhGrlqNzkBDVsM =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIM0400':xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIM1800':xeQugEYjypoKCTPmHhGrlqNzkBDVsW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
    xeQugEYjypoKCTPmHhGrlqNzkBDVsU =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['movie']['story']['ko']
    try:
     xeQugEYjypoKCTPmHhGrlqNzkBDVJn =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['movie']['name']['ko'].strip()
     xeQugEYjypoKCTPmHhGrlqNzkBDVnI =xeQugEYjypoKCTPmHhGrlqNzkBDVtn.get(xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('grade_code'))
     xeQugEYjypoKCTPmHhGrlqNzkBDVnS=[]
     xeQugEYjypoKCTPmHhGrlqNzkBDVnc=[]
     xeQugEYjypoKCTPmHhGrlqNzkBDVnb=[]
     xeQugEYjypoKCTPmHhGrlqNzkBDVJI=0
     xeQugEYjypoKCTPmHhGrlqNzkBDVnO=''
     xeQugEYjypoKCTPmHhGrlqNzkBDVJb =''
     for xeQugEYjypoKCTPmHhGrlqNzkBDVnw in xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('movie').get('actor'):
      if xeQugEYjypoKCTPmHhGrlqNzkBDVnw!='':xeQugEYjypoKCTPmHhGrlqNzkBDVnS.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnw)
     for xeQugEYjypoKCTPmHhGrlqNzkBDVnA in xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('movie').get('director'):
      if xeQugEYjypoKCTPmHhGrlqNzkBDVnA!='':xeQugEYjypoKCTPmHhGrlqNzkBDVnc.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnA)
     if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('movie').get('category1_name').get('ko')!='':
      xeQugEYjypoKCTPmHhGrlqNzkBDVnb.append(xeQugEYjypoKCTPmHhGrlqNzkBDVdR['movie']['category1_name']['ko'])
     if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('movie').get('category2_name').get('ko')!='':
      xeQugEYjypoKCTPmHhGrlqNzkBDVnb.append(xeQugEYjypoKCTPmHhGrlqNzkBDVdR['movie']['category2_name']['ko'])
     if 'duration' in xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('movie'):xeQugEYjypoKCTPmHhGrlqNzkBDVJI=xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('movie').get('duration')
     if 'release_date' in xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('movie'):
      xeQugEYjypoKCTPmHhGrlqNzkBDVna=xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('movie').get('release_date'))
      if xeQugEYjypoKCTPmHhGrlqNzkBDVna!='0':xeQugEYjypoKCTPmHhGrlqNzkBDVnO='%s-%s-%s'%(xeQugEYjypoKCTPmHhGrlqNzkBDVna[:4],xeQugEYjypoKCTPmHhGrlqNzkBDVna[4:6],xeQugEYjypoKCTPmHhGrlqNzkBDVna[6:])
     if 'production' in xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('movie'):xeQugEYjypoKCTPmHhGrlqNzkBDVJb=xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('movie').get('production')
    except:
     xeQugEYjypoKCTPmHhGrlqNzkBDVSw
    xeQugEYjypoKCTPmHhGrlqNzkBDVnR={'moviecode':xeQugEYjypoKCTPmHhGrlqNzkBDVJX,'title':xeQugEYjypoKCTPmHhGrlqNzkBDVsi,'thumbnail':{'poster':xeQugEYjypoKCTPmHhGrlqNzkBDVsM,'thumb':xeQugEYjypoKCTPmHhGrlqNzkBDVsf,'clearlogo':xeQugEYjypoKCTPmHhGrlqNzkBDVsW,'fanart':xeQugEYjypoKCTPmHhGrlqNzkBDVsf},'synopsis':xeQugEYjypoKCTPmHhGrlqNzkBDVsU,'info_title':xeQugEYjypoKCTPmHhGrlqNzkBDVJn,'year':xeQugEYjypoKCTPmHhGrlqNzkBDVnX,'cast':xeQugEYjypoKCTPmHhGrlqNzkBDVnS,'director':xeQugEYjypoKCTPmHhGrlqNzkBDVnc,'info_genre':xeQugEYjypoKCTPmHhGrlqNzkBDVnb,'duration':xeQugEYjypoKCTPmHhGrlqNzkBDVJI,'premiered':xeQugEYjypoKCTPmHhGrlqNzkBDVnO,'studio':xeQugEYjypoKCTPmHhGrlqNzkBDVJb,'mpaa':xeQugEYjypoKCTPmHhGrlqNzkBDVnI}
    xeQugEYjypoKCTPmHhGrlqNzkBDVJO=xeQugEYjypoKCTPmHhGrlqNzkBDVSA
    for xeQugEYjypoKCTPmHhGrlqNzkBDVJw in xeQugEYjypoKCTPmHhGrlqNzkBDVdR['billing_package_id']:
     if xeQugEYjypoKCTPmHhGrlqNzkBDVJw in xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.MOVIE_LITE:
      xeQugEYjypoKCTPmHhGrlqNzkBDVJO=xeQugEYjypoKCTPmHhGrlqNzkBDVSF
      break
    if xeQugEYjypoKCTPmHhGrlqNzkBDVJO==xeQugEYjypoKCTPmHhGrlqNzkBDVSA: 
     xeQugEYjypoKCTPmHhGrlqNzkBDVnR['title']=xeQugEYjypoKCTPmHhGrlqNzkBDVnR['title']+' [개별구매]'
    xeQugEYjypoKCTPmHhGrlqNzkBDVdO.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnR)
   if xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['has_more']=='Y':xeQugEYjypoKCTPmHhGrlqNzkBDVsA=xeQugEYjypoKCTPmHhGrlqNzkBDVSF
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
 def Get_UHD_MovieList(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,page_int):
  xeQugEYjypoKCTPmHhGrlqNzkBDVdO=[]
  xeQugEYjypoKCTPmHhGrlqNzkBDVsA=xeQugEYjypoKCTPmHhGrlqNzkBDVSA
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='/v2/operator/highlights'
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDefaultParams(uhd=xeQugEYjypoKCTPmHhGrlqNzkBDVSF)
   xeQugEYjypoKCTPmHhGrlqNzkBDVda={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(page_int),'pocType':'APP_X_TVING_4.0.0',}
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM.update(xeQugEYjypoKCTPmHhGrlqNzkBDVda)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdX
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVdM,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVSw)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdF=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   if not('result' in xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']):return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
   xeQugEYjypoKCTPmHhGrlqNzkBDVsF=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['result']
   for xeQugEYjypoKCTPmHhGrlqNzkBDVdR in xeQugEYjypoKCTPmHhGrlqNzkBDVsF:
    xeQugEYjypoKCTPmHhGrlqNzkBDVni=xeQugEYjypoKCTPmHhGrlqNzkBDVdR['content']['movie']
    xeQugEYjypoKCTPmHhGrlqNzkBDVnU =xeQugEYjypoKCTPmHhGrlqNzkBDVni['code']
    xeQugEYjypoKCTPmHhGrlqNzkBDVsi =xeQugEYjypoKCTPmHhGrlqNzkBDVni['name']['ko'].strip()
    xeQugEYjypoKCTPmHhGrlqNzkBDVJn =xeQugEYjypoKCTPmHhGrlqNzkBDVni['name']['ko'].strip()
    xeQugEYjypoKCTPmHhGrlqNzkBDVnX =xeQugEYjypoKCTPmHhGrlqNzkBDVni['product_year']
    if xeQugEYjypoKCTPmHhGrlqNzkBDVnX:xeQugEYjypoKCTPmHhGrlqNzkBDVsi+=u' (%s)'%(xeQugEYjypoKCTPmHhGrlqNzkBDVni['product_year'])
    xeQugEYjypoKCTPmHhGrlqNzkBDVsU =xeQugEYjypoKCTPmHhGrlqNzkBDVni['story']['ko']
    xeQugEYjypoKCTPmHhGrlqNzkBDVJI =xeQugEYjypoKCTPmHhGrlqNzkBDVni['duration']
    xeQugEYjypoKCTPmHhGrlqNzkBDVnI =xeQugEYjypoKCTPmHhGrlqNzkBDVtn.get(xeQugEYjypoKCTPmHhGrlqNzkBDVni.get('grade_code'))
    xeQugEYjypoKCTPmHhGrlqNzkBDVJb =xeQugEYjypoKCTPmHhGrlqNzkBDVni['production']
    xeQugEYjypoKCTPmHhGrlqNzkBDVsM=''
    xeQugEYjypoKCTPmHhGrlqNzkBDVsf =''
    xeQugEYjypoKCTPmHhGrlqNzkBDVsW=''
    xeQugEYjypoKCTPmHhGrlqNzkBDVnb =[]
    xeQugEYjypoKCTPmHhGrlqNzkBDVnS =[]
    xeQugEYjypoKCTPmHhGrlqNzkBDVnc=[]
    xeQugEYjypoKCTPmHhGrlqNzkBDVnO =''
    for xeQugEYjypoKCTPmHhGrlqNzkBDVnJ in xeQugEYjypoKCTPmHhGrlqNzkBDVni['image']:
     if xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIM2100':xeQugEYjypoKCTPmHhGrlqNzkBDVsM =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIM0400':xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
     elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['code']=='CAIM1800':xeQugEYjypoKCTPmHhGrlqNzkBDVsW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ['url']
    if xeQugEYjypoKCTPmHhGrlqNzkBDVni['release_date']not in[xeQugEYjypoKCTPmHhGrlqNzkBDVSw,0]:
     xeQugEYjypoKCTPmHhGrlqNzkBDVna=xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVni['release_date'])
     if xeQugEYjypoKCTPmHhGrlqNzkBDVna!='0':xeQugEYjypoKCTPmHhGrlqNzkBDVnO='%s-%s-%s'%(xeQugEYjypoKCTPmHhGrlqNzkBDVna[:4],xeQugEYjypoKCTPmHhGrlqNzkBDVna[4:6],xeQugEYjypoKCTPmHhGrlqNzkBDVna[6:])
    if xeQugEYjypoKCTPmHhGrlqNzkBDVni.get('category1_name').get('ko')!='':
     xeQugEYjypoKCTPmHhGrlqNzkBDVnb.append(xeQugEYjypoKCTPmHhGrlqNzkBDVni['category1_name']['ko'])
    if xeQugEYjypoKCTPmHhGrlqNzkBDVni.get('category2_name').get('ko')!='':
     xeQugEYjypoKCTPmHhGrlqNzkBDVnb.append(xeQugEYjypoKCTPmHhGrlqNzkBDVni['category2_name']['ko'])
    for xeQugEYjypoKCTPmHhGrlqNzkBDVnw in xeQugEYjypoKCTPmHhGrlqNzkBDVni.get('actor'):
     if xeQugEYjypoKCTPmHhGrlqNzkBDVnw!='':xeQugEYjypoKCTPmHhGrlqNzkBDVnS.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnw)
    for xeQugEYjypoKCTPmHhGrlqNzkBDVnA in xeQugEYjypoKCTPmHhGrlqNzkBDVni.get('director'):
     if xeQugEYjypoKCTPmHhGrlqNzkBDVnA!='':xeQugEYjypoKCTPmHhGrlqNzkBDVnc.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnA)
    xeQugEYjypoKCTPmHhGrlqNzkBDVnR={'moviecode':xeQugEYjypoKCTPmHhGrlqNzkBDVnU,'title':xeQugEYjypoKCTPmHhGrlqNzkBDVsi,'thumbnail':{'poster':xeQugEYjypoKCTPmHhGrlqNzkBDVsM,'thumb':xeQugEYjypoKCTPmHhGrlqNzkBDVsf,'clearlogo':xeQugEYjypoKCTPmHhGrlqNzkBDVsW,'fanart':xeQugEYjypoKCTPmHhGrlqNzkBDVsf},'year':xeQugEYjypoKCTPmHhGrlqNzkBDVnX,'info_title':xeQugEYjypoKCTPmHhGrlqNzkBDVJn,'synopsis':xeQugEYjypoKCTPmHhGrlqNzkBDVsU,'mpaa':xeQugEYjypoKCTPmHhGrlqNzkBDVnI,'duration':xeQugEYjypoKCTPmHhGrlqNzkBDVJI,'premiered':xeQugEYjypoKCTPmHhGrlqNzkBDVnO,'studio':xeQugEYjypoKCTPmHhGrlqNzkBDVJb,'info_genre':xeQugEYjypoKCTPmHhGrlqNzkBDVnb,'cast':xeQugEYjypoKCTPmHhGrlqNzkBDVnS,'director':xeQugEYjypoKCTPmHhGrlqNzkBDVnc,}
    xeQugEYjypoKCTPmHhGrlqNzkBDVdO.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnR)
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
 def GetMovieGenre(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ):
  xeQugEYjypoKCTPmHhGrlqNzkBDVdO=[]
  xeQugEYjypoKCTPmHhGrlqNzkBDVsA=xeQugEYjypoKCTPmHhGrlqNzkBDVSA
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='/v2/media/movie/curations'
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDefaultParams()
   xeQugEYjypoKCTPmHhGrlqNzkBDVda={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM.update(xeQugEYjypoKCTPmHhGrlqNzkBDVda)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdX
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVdM,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVSw)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdF=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   if not('result' in xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']):return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
   xeQugEYjypoKCTPmHhGrlqNzkBDVsF=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['result']
   for xeQugEYjypoKCTPmHhGrlqNzkBDVdR in xeQugEYjypoKCTPmHhGrlqNzkBDVsF:
    xeQugEYjypoKCTPmHhGrlqNzkBDVJA =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['curation_code']
    xeQugEYjypoKCTPmHhGrlqNzkBDVJa =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['curation_name']
    xeQugEYjypoKCTPmHhGrlqNzkBDVnR={'curation_code':xeQugEYjypoKCTPmHhGrlqNzkBDVJA,'curation_name':xeQugEYjypoKCTPmHhGrlqNzkBDVJa}
    xeQugEYjypoKCTPmHhGrlqNzkBDVdO.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnR)
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
 def GetSearchList(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,search_key,page_int,stype):
  xeQugEYjypoKCTPmHhGrlqNzkBDVJF=[]
  xeQugEYjypoKCTPmHhGrlqNzkBDVsA=xeQugEYjypoKCTPmHhGrlqNzkBDVSA
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='/search/getSearch.jsp'
   xeQugEYjypoKCTPmHhGrlqNzkBDVda={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(page_int),'pageSize':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.SCREENCODE,'os':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.OSCODE,'network':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   xeQugEYjypoKCTPmHhGrlqNzkBDVdW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.SEARCH_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdX
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVda,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVSw)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdF=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   if stype=='vod':
    if not('programRsb' in xeQugEYjypoKCTPmHhGrlqNzkBDVdF):return xeQugEYjypoKCTPmHhGrlqNzkBDVJF,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
    xeQugEYjypoKCTPmHhGrlqNzkBDVJR=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['programRsb']['dataList']
    xeQugEYjypoKCTPmHhGrlqNzkBDVJv =xeQugEYjypoKCTPmHhGrlqNzkBDVSR(xeQugEYjypoKCTPmHhGrlqNzkBDVdF['programRsb']['count'])
    for xeQugEYjypoKCTPmHhGrlqNzkBDVdR in xeQugEYjypoKCTPmHhGrlqNzkBDVJR:
     xeQugEYjypoKCTPmHhGrlqNzkBDVnv=xeQugEYjypoKCTPmHhGrlqNzkBDVdR['mast_cd']
     xeQugEYjypoKCTPmHhGrlqNzkBDVsi =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['mast_nm']
     xeQugEYjypoKCTPmHhGrlqNzkBDVsM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdR['web_url4']
     xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdR['web_url']
     try:
      xeQugEYjypoKCTPmHhGrlqNzkBDVnS =[]
      xeQugEYjypoKCTPmHhGrlqNzkBDVnc=[]
      xeQugEYjypoKCTPmHhGrlqNzkBDVnb =[]
      xeQugEYjypoKCTPmHhGrlqNzkBDVJI =0
      xeQugEYjypoKCTPmHhGrlqNzkBDVnI =''
      xeQugEYjypoKCTPmHhGrlqNzkBDVnX =''
      xeQugEYjypoKCTPmHhGrlqNzkBDVJc =''
      if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('actor') !='' and xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('actor') !='-':xeQugEYjypoKCTPmHhGrlqNzkBDVnS =xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('actor').split(',')
      if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('director')!='' and xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('director')!='-':xeQugEYjypoKCTPmHhGrlqNzkBDVnc=xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('director').split(',')
      if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('cate_nm')!='' and xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('cate_nm')!='-':xeQugEYjypoKCTPmHhGrlqNzkBDVnb =xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('cate_nm').split('/')
      if 'targetage' in xeQugEYjypoKCTPmHhGrlqNzkBDVdR:xeQugEYjypoKCTPmHhGrlqNzkBDVnI=xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('targetage')
      if 'broad_dt' in xeQugEYjypoKCTPmHhGrlqNzkBDVdR:
       xeQugEYjypoKCTPmHhGrlqNzkBDVna=xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('broad_dt')
       xeQugEYjypoKCTPmHhGrlqNzkBDVJc='%s-%s-%s'%(xeQugEYjypoKCTPmHhGrlqNzkBDVna[:4],xeQugEYjypoKCTPmHhGrlqNzkBDVna[4:6],xeQugEYjypoKCTPmHhGrlqNzkBDVna[6:])
       xeQugEYjypoKCTPmHhGrlqNzkBDVnX =xeQugEYjypoKCTPmHhGrlqNzkBDVna[:4]
     except:
      xeQugEYjypoKCTPmHhGrlqNzkBDVSw
     xeQugEYjypoKCTPmHhGrlqNzkBDVnR={'program':xeQugEYjypoKCTPmHhGrlqNzkBDVnv,'title':xeQugEYjypoKCTPmHhGrlqNzkBDVsi,'thumbnail':{'poster':xeQugEYjypoKCTPmHhGrlqNzkBDVsM,'thumb':xeQugEYjypoKCTPmHhGrlqNzkBDVsf,'fanart':xeQugEYjypoKCTPmHhGrlqNzkBDVsf},'synopsis':'','cast':xeQugEYjypoKCTPmHhGrlqNzkBDVnS,'director':xeQugEYjypoKCTPmHhGrlqNzkBDVnc,'info_genre':xeQugEYjypoKCTPmHhGrlqNzkBDVnb,'duration':xeQugEYjypoKCTPmHhGrlqNzkBDVJI,'mpaa':xeQugEYjypoKCTPmHhGrlqNzkBDVnI,'year':xeQugEYjypoKCTPmHhGrlqNzkBDVnX,'aired':xeQugEYjypoKCTPmHhGrlqNzkBDVJc}
     xeQugEYjypoKCTPmHhGrlqNzkBDVJF.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnR)
   else:
    if not('vodMVRsb' in xeQugEYjypoKCTPmHhGrlqNzkBDVdF):return xeQugEYjypoKCTPmHhGrlqNzkBDVJF,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
    xeQugEYjypoKCTPmHhGrlqNzkBDVJL=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['vodMVRsb']['dataList']
    xeQugEYjypoKCTPmHhGrlqNzkBDVJv =xeQugEYjypoKCTPmHhGrlqNzkBDVSR(xeQugEYjypoKCTPmHhGrlqNzkBDVdF['vodMVRsb']['count'])
    for xeQugEYjypoKCTPmHhGrlqNzkBDVdR in xeQugEYjypoKCTPmHhGrlqNzkBDVJL:
     xeQugEYjypoKCTPmHhGrlqNzkBDVnv=xeQugEYjypoKCTPmHhGrlqNzkBDVdR['mast_cd']
     xeQugEYjypoKCTPmHhGrlqNzkBDVsi =xeQugEYjypoKCTPmHhGrlqNzkBDVdR['mast_nm'].strip()
     xeQugEYjypoKCTPmHhGrlqNzkBDVsM =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdR['web_url']
     xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVsM
     xeQugEYjypoKCTPmHhGrlqNzkBDVsW=''
     try:
      xeQugEYjypoKCTPmHhGrlqNzkBDVnS =[]
      xeQugEYjypoKCTPmHhGrlqNzkBDVnc=[]
      xeQugEYjypoKCTPmHhGrlqNzkBDVnb =[]
      xeQugEYjypoKCTPmHhGrlqNzkBDVJI =0
      xeQugEYjypoKCTPmHhGrlqNzkBDVnI =''
      xeQugEYjypoKCTPmHhGrlqNzkBDVnX =''
      xeQugEYjypoKCTPmHhGrlqNzkBDVJc =''
      if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('actor') !='' and xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('actor') !='-':xeQugEYjypoKCTPmHhGrlqNzkBDVnS =xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('actor').split(',')
      if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('director')!='' and xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('director')!='-':xeQugEYjypoKCTPmHhGrlqNzkBDVnc=xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('director').split(',')
      if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('cate_nm')!='' and xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('cate_nm')!='-':xeQugEYjypoKCTPmHhGrlqNzkBDVnb =xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('cate_nm').split('/')
      if xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('runtime_sec')!='':xeQugEYjypoKCTPmHhGrlqNzkBDVJI=xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('runtime_sec')
      if 'grade_nm' in xeQugEYjypoKCTPmHhGrlqNzkBDVdR:xeQugEYjypoKCTPmHhGrlqNzkBDVnI=xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('grade_nm')
      xeQugEYjypoKCTPmHhGrlqNzkBDVna=xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('broad_dt')
      if data_str!='':
       xeQugEYjypoKCTPmHhGrlqNzkBDVJc='%s-%s-%s'%(xeQugEYjypoKCTPmHhGrlqNzkBDVna[:4],xeQugEYjypoKCTPmHhGrlqNzkBDVna[4:6],xeQugEYjypoKCTPmHhGrlqNzkBDVna[6:])
       xeQugEYjypoKCTPmHhGrlqNzkBDVnX =xeQugEYjypoKCTPmHhGrlqNzkBDVna[:4]
     except:
      xeQugEYjypoKCTPmHhGrlqNzkBDVSw
     xeQugEYjypoKCTPmHhGrlqNzkBDVnR={'movie':xeQugEYjypoKCTPmHhGrlqNzkBDVnv,'title':xeQugEYjypoKCTPmHhGrlqNzkBDVsi,'thumbnail':{'poster':xeQugEYjypoKCTPmHhGrlqNzkBDVsM,'thumb':xeQugEYjypoKCTPmHhGrlqNzkBDVsf,'fanart':xeQugEYjypoKCTPmHhGrlqNzkBDVsf,'clearlogo':xeQugEYjypoKCTPmHhGrlqNzkBDVsW},'synopsis':'','cast':xeQugEYjypoKCTPmHhGrlqNzkBDVnS,'director':xeQugEYjypoKCTPmHhGrlqNzkBDVnc,'info_genre':xeQugEYjypoKCTPmHhGrlqNzkBDVnb,'duration':xeQugEYjypoKCTPmHhGrlqNzkBDVJI,'mpaa':xeQugEYjypoKCTPmHhGrlqNzkBDVnI,'year':xeQugEYjypoKCTPmHhGrlqNzkBDVnX,'aired':xeQugEYjypoKCTPmHhGrlqNzkBDVJc}
     xeQugEYjypoKCTPmHhGrlqNzkBDVJO=xeQugEYjypoKCTPmHhGrlqNzkBDVSA
     for xeQugEYjypoKCTPmHhGrlqNzkBDVJw in xeQugEYjypoKCTPmHhGrlqNzkBDVdR['bill']:
      if xeQugEYjypoKCTPmHhGrlqNzkBDVJw in xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.MOVIE_LITE:
       xeQugEYjypoKCTPmHhGrlqNzkBDVJO=xeQugEYjypoKCTPmHhGrlqNzkBDVSF
       break
     if xeQugEYjypoKCTPmHhGrlqNzkBDVJO==xeQugEYjypoKCTPmHhGrlqNzkBDVSA: 
      xeQugEYjypoKCTPmHhGrlqNzkBDVnR['title']=xeQugEYjypoKCTPmHhGrlqNzkBDVnR['title']+' [개별구매]'
     xeQugEYjypoKCTPmHhGrlqNzkBDVJF.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnR)
   if xeQugEYjypoKCTPmHhGrlqNzkBDVJv>(page_int*xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.SEARCH_LIMIT):xeQugEYjypoKCTPmHhGrlqNzkBDVsA=xeQugEYjypoKCTPmHhGrlqNzkBDVSF
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVJF,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
 def GetBookmarkInfo(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,videoid,vidtype):
  xeQugEYjypoKCTPmHhGrlqNzkBDVJi={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   xeQugEYjypoKCTPmHhGrlqNzkBDVdW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN+'/v2/media/program/'+videoid
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDefaultParams()
   xeQugEYjypoKCTPmHhGrlqNzkBDVda={'pageNo':'1','pageSize':'10','order':'name',}
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM.update(xeQugEYjypoKCTPmHhGrlqNzkBDVda)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVdM,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVSw)
   xeQugEYjypoKCTPmHhGrlqNzkBDVJU=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   if not('body' in xeQugEYjypoKCTPmHhGrlqNzkBDVJU):return{}
   xeQugEYjypoKCTPmHhGrlqNzkBDVJf=xeQugEYjypoKCTPmHhGrlqNzkBDVJU['body']
   xeQugEYjypoKCTPmHhGrlqNzkBDVsi=xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('name').get('ko').strip()
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['title'] =xeQugEYjypoKCTPmHhGrlqNzkBDVsi
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['title']=xeQugEYjypoKCTPmHhGrlqNzkBDVsi
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['mpaa'] =xeQugEYjypoKCTPmHhGrlqNzkBDVtn.get(xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('grade_code'))
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['plot'] =xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('synopsis').get('ko')
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['year'] =xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('product_year')
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['cast'] =xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('actor')
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['director']=xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('director')
   if xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('category1_name').get('ko')!='':
    xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['genre'].append(xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('category1_name').get('ko'))
   if xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('category2_name').get('ko')!='':
    xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['genre'].append(xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('category2_name').get('ko'))
   xeQugEYjypoKCTPmHhGrlqNzkBDVna=xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('broad_dt'))
   if xeQugEYjypoKCTPmHhGrlqNzkBDVna!='0':xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(xeQugEYjypoKCTPmHhGrlqNzkBDVna[:4],xeQugEYjypoKCTPmHhGrlqNzkBDVna[4:6],xeQugEYjypoKCTPmHhGrlqNzkBDVna[6:])
   xeQugEYjypoKCTPmHhGrlqNzkBDVsM =''
   xeQugEYjypoKCTPmHhGrlqNzkBDVsf =''
   xeQugEYjypoKCTPmHhGrlqNzkBDVsW=''
   xeQugEYjypoKCTPmHhGrlqNzkBDVnt =''
   xeQugEYjypoKCTPmHhGrlqNzkBDVnd =''
   for xeQugEYjypoKCTPmHhGrlqNzkBDVnJ in xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('image'):
    if xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('code')=='CAIP0900':xeQugEYjypoKCTPmHhGrlqNzkBDVsM =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('url')
    elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('code')=='CAIP0200':xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('url')
    elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('code')=='CAIP1800':xeQugEYjypoKCTPmHhGrlqNzkBDVsW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('url')
    elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('code')=='CAIP2000':xeQugEYjypoKCTPmHhGrlqNzkBDVnt =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('url')
    elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('code')=='CAIP1900':xeQugEYjypoKCTPmHhGrlqNzkBDVnd =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('url')
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['thumbnail']['poster']=xeQugEYjypoKCTPmHhGrlqNzkBDVsM
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['thumbnail']['thumb']=xeQugEYjypoKCTPmHhGrlqNzkBDVsf
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['thumbnail']['clearlogo']=xeQugEYjypoKCTPmHhGrlqNzkBDVsW
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['thumbnail']['icon']=xeQugEYjypoKCTPmHhGrlqNzkBDVnt
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['thumbnail']['banner']=xeQugEYjypoKCTPmHhGrlqNzkBDVnd
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['thumbnail']['fanart']=xeQugEYjypoKCTPmHhGrlqNzkBDVsf
  else:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN+'/v2a/media/stream/info'
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDefaultParams()
   xeQugEYjypoKCTPmHhGrlqNzkBDVda={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_uuid'].split('-')[0],'uuid':xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetNoCache(1)),'wm':'Y',}
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM.update(xeQugEYjypoKCTPmHhGrlqNzkBDVda)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVdM,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVSw)
   xeQugEYjypoKCTPmHhGrlqNzkBDVJU=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   if not('content' in xeQugEYjypoKCTPmHhGrlqNzkBDVJU['body']):return{}
   xeQugEYjypoKCTPmHhGrlqNzkBDVJf=xeQugEYjypoKCTPmHhGrlqNzkBDVJU['body']['content']['info']['movie']
   xeQugEYjypoKCTPmHhGrlqNzkBDVsi =xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('name').get('ko').strip()
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['title']=xeQugEYjypoKCTPmHhGrlqNzkBDVsi
   xeQugEYjypoKCTPmHhGrlqNzkBDVsi +=u' (%s)'%(xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('product_year'))
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['title'] =xeQugEYjypoKCTPmHhGrlqNzkBDVsi
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['mpaa'] =xeQugEYjypoKCTPmHhGrlqNzkBDVtn.get(xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('grade_code'))
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['plot'] =xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('story').get('ko')
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['year'] =xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('product_year')
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['studio'] =xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('production')
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['duration']=xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('duration')
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['cast'] =xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('actor')
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['director']=xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('director')
   if xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('category1_name').get('ko')!='':
    xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['genre'].append(xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('category1_name').get('ko'))
   if xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('category2_name').get('ko')!='':
    xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['genre'].append(xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('category2_name').get('ko'))
   xeQugEYjypoKCTPmHhGrlqNzkBDVna=xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('release_date'))
   if xeQugEYjypoKCTPmHhGrlqNzkBDVna!='0':xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(xeQugEYjypoKCTPmHhGrlqNzkBDVna[:4],xeQugEYjypoKCTPmHhGrlqNzkBDVna[4:6],xeQugEYjypoKCTPmHhGrlqNzkBDVna[6:])
   xeQugEYjypoKCTPmHhGrlqNzkBDVsM=''
   xeQugEYjypoKCTPmHhGrlqNzkBDVsf =''
   xeQugEYjypoKCTPmHhGrlqNzkBDVsW=''
   for xeQugEYjypoKCTPmHhGrlqNzkBDVnJ in xeQugEYjypoKCTPmHhGrlqNzkBDVJf.get('image'):
    if xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('code')=='CAIM2100':xeQugEYjypoKCTPmHhGrlqNzkBDVsM =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('url')
    elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('code')=='CAIM0400':xeQugEYjypoKCTPmHhGrlqNzkBDVsf =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('url')
    elif xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('code')=='CAIM1800':xeQugEYjypoKCTPmHhGrlqNzkBDVsW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.IMG_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVnJ.get('url')
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['thumbnail']['poster']=xeQugEYjypoKCTPmHhGrlqNzkBDVsM
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['thumbnail']['thumb']=xeQugEYjypoKCTPmHhGrlqNzkBDVsM 
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['thumbnail']['clearlogo']=xeQugEYjypoKCTPmHhGrlqNzkBDVsW
   xeQugEYjypoKCTPmHhGrlqNzkBDVJi['saveinfo']['thumbnail']['fanart']=xeQugEYjypoKCTPmHhGrlqNzkBDVsf
  return xeQugEYjypoKCTPmHhGrlqNzkBDVJi
 def GetEuroChannelList(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ):
  xeQugEYjypoKCTPmHhGrlqNzkBDVdO=[]
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVdX ='/v2/operator/highlights'
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetDefaultParams()
   xeQugEYjypoKCTPmHhGrlqNzkBDVda={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':xeQugEYjypoKCTPmHhGrlqNzkBDVSf(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.GetNoCache(2))}
   xeQugEYjypoKCTPmHhGrlqNzkBDVdM.update(xeQugEYjypoKCTPmHhGrlqNzkBDVda)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdW=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.API_DOMAIN+xeQugEYjypoKCTPmHhGrlqNzkBDVdX
   xeQugEYjypoKCTPmHhGrlqNzkBDVdn=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.callRequestCookies('Get',xeQugEYjypoKCTPmHhGrlqNzkBDVdW,payload=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,params=xeQugEYjypoKCTPmHhGrlqNzkBDVdM,headers=xeQugEYjypoKCTPmHhGrlqNzkBDVSw,cookies=xeQugEYjypoKCTPmHhGrlqNzkBDVSw)
   xeQugEYjypoKCTPmHhGrlqNzkBDVdF=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVdn.text)
   if not('result' in xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']):return xeQugEYjypoKCTPmHhGrlqNzkBDVdO,xeQugEYjypoKCTPmHhGrlqNzkBDVsA
   xeQugEYjypoKCTPmHhGrlqNzkBDVsF=xeQugEYjypoKCTPmHhGrlqNzkBDVdF['body']['result']
   xeQugEYjypoKCTPmHhGrlqNzkBDVJM =xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.Get_Now_Datetime()
   xeQugEYjypoKCTPmHhGrlqNzkBDVJW=xeQugEYjypoKCTPmHhGrlqNzkBDVJM+datetime.timedelta(days=-1)
   xeQugEYjypoKCTPmHhGrlqNzkBDVJW=xeQugEYjypoKCTPmHhGrlqNzkBDVSR(xeQugEYjypoKCTPmHhGrlqNzkBDVJW.strftime('%Y%m%d'))
   for xeQugEYjypoKCTPmHhGrlqNzkBDVdR in xeQugEYjypoKCTPmHhGrlqNzkBDVsF:
    xeQugEYjypoKCTPmHhGrlqNzkBDVSt=xeQugEYjypoKCTPmHhGrlqNzkBDVSR(xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('content').get('banner_title2')[:8])
    if xeQugEYjypoKCTPmHhGrlqNzkBDVJW<=xeQugEYjypoKCTPmHhGrlqNzkBDVSt:
     xeQugEYjypoKCTPmHhGrlqNzkBDVnR={'channel':xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('content').get('banner_sub_title3'),'title':xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('content').get('banner_title'),'subtitle':xeQugEYjypoKCTPmHhGrlqNzkBDVdR.get('content').get('banner_sub_title2'),}
     xeQugEYjypoKCTPmHhGrlqNzkBDVdO.append(xeQugEYjypoKCTPmHhGrlqNzkBDVnR)
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVdO
 def Make_DecryptKey(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,step,mediacode='000',timecode='000'):
  if step=='1':
   xeQugEYjypoKCTPmHhGrlqNzkBDVSd=xeQugEYjypoKCTPmHhGrlqNzkBDVSW('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   xeQugEYjypoKCTPmHhGrlqNzkBDVSs=xeQugEYjypoKCTPmHhGrlqNzkBDVSW('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSd=xeQugEYjypoKCTPmHhGrlqNzkBDVSW('kss2lym0kdw1lks3','utf-8')
   xeQugEYjypoKCTPmHhGrlqNzkBDVSs=xeQugEYjypoKCTPmHhGrlqNzkBDVSW([xeQugEYjypoKCTPmHhGrlqNzkBDVct('*'),0x07,xeQugEYjypoKCTPmHhGrlqNzkBDVct('r'),xeQugEYjypoKCTPmHhGrlqNzkBDVct(';'),xeQugEYjypoKCTPmHhGrlqNzkBDVct('7'),0x05,0x1e,0x01,xeQugEYjypoKCTPmHhGrlqNzkBDVct('n'),xeQugEYjypoKCTPmHhGrlqNzkBDVct('D'),0x02,xeQugEYjypoKCTPmHhGrlqNzkBDVct('3'),xeQugEYjypoKCTPmHhGrlqNzkBDVct('*'),xeQugEYjypoKCTPmHhGrlqNzkBDVct('a'),xeQugEYjypoKCTPmHhGrlqNzkBDVct('&'),xeQugEYjypoKCTPmHhGrlqNzkBDVct('<')])
  return xeQugEYjypoKCTPmHhGrlqNzkBDVSd,xeQugEYjypoKCTPmHhGrlqNzkBDVSs
 def DecryptPlaintext(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,ciphertext,encryption_key,init_vector):
  xeQugEYjypoKCTPmHhGrlqNzkBDVSn=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  xeQugEYjypoKCTPmHhGrlqNzkBDVSJ=Padding.unpad(xeQugEYjypoKCTPmHhGrlqNzkBDVSn.decrypt(base64.standard_b64decode(ciphertext)),16)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVSJ.decode('utf-8')
 def Decrypt_Url(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ,ciphertext,mediacode,xeQugEYjypoKCTPmHhGrlqNzkBDVsc):
  xeQugEYjypoKCTPmHhGrlqNzkBDVSc=''
  xeQugEYjypoKCTPmHhGrlqNzkBDVsb=''
  xeQugEYjypoKCTPmHhGrlqNzkBDVsX=''
  try:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSd,xeQugEYjypoKCTPmHhGrlqNzkBDVSs=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.Make_DecryptKey('1',mediacode=mediacode,timecode=xeQugEYjypoKCTPmHhGrlqNzkBDVsc)
   xeQugEYjypoKCTPmHhGrlqNzkBDVSb=json.loads(xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.DecryptPlaintext(ciphertext,xeQugEYjypoKCTPmHhGrlqNzkBDVSd,xeQugEYjypoKCTPmHhGrlqNzkBDVSs))
   xeQugEYjypoKCTPmHhGrlqNzkBDVSX =xeQugEYjypoKCTPmHhGrlqNzkBDVSb.get('broad_url')
   xeQugEYjypoKCTPmHhGrlqNzkBDVsb =xeQugEYjypoKCTPmHhGrlqNzkBDVSb.get('watermark') if 'watermark' in xeQugEYjypoKCTPmHhGrlqNzkBDVSb else ''
   xeQugEYjypoKCTPmHhGrlqNzkBDVsX=xeQugEYjypoKCTPmHhGrlqNzkBDVSb.get('watermarkKey')if 'watermarkKey' in xeQugEYjypoKCTPmHhGrlqNzkBDVSb else ''
   xeQugEYjypoKCTPmHhGrlqNzkBDVSd,xeQugEYjypoKCTPmHhGrlqNzkBDVSs=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.Make_DecryptKey('2',mediacode=mediacode,timecode=xeQugEYjypoKCTPmHhGrlqNzkBDVsc)
   xeQugEYjypoKCTPmHhGrlqNzkBDVSc=xeQugEYjypoKCTPmHhGrlqNzkBDVtJ.DecryptPlaintext(xeQugEYjypoKCTPmHhGrlqNzkBDVSX,xeQugEYjypoKCTPmHhGrlqNzkBDVSd,xeQugEYjypoKCTPmHhGrlqNzkBDVSs)
  except xeQugEYjypoKCTPmHhGrlqNzkBDVSL as exception:
   xeQugEYjypoKCTPmHhGrlqNzkBDVSi(exception)
  return xeQugEYjypoKCTPmHhGrlqNzkBDVSc,xeQugEYjypoKCTPmHhGrlqNzkBDVsb,xeQugEYjypoKCTPmHhGrlqNzkBDVsX
# Created by pyminifier (https://github.com/liftoff/pyminifier)
