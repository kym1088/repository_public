__author__="NightRain"
HYzmqDjBQbxSLEMaNegPRKOdJcuGho=object
HYzmqDjBQbxSLEMaNegPRKOdJcuGhr=None
HYzmqDjBQbxSLEMaNegPRKOdJcuGhf=int
HYzmqDjBQbxSLEMaNegPRKOdJcuGhI=True
HYzmqDjBQbxSLEMaNegPRKOdJcuGhv=False
HYzmqDjBQbxSLEMaNegPRKOdJcuGhC=type
HYzmqDjBQbxSLEMaNegPRKOdJcuGhW=dict
HYzmqDjBQbxSLEMaNegPRKOdJcuGhV=len
HYzmqDjBQbxSLEMaNegPRKOdJcuGht=str
HYzmqDjBQbxSLEMaNegPRKOdJcuGhk=range
HYzmqDjBQbxSLEMaNegPRKOdJcuGhF=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
HYzmqDjBQbxSLEMaNegPRKOdJcuGwX=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
HYzmqDjBQbxSLEMaNegPRKOdJcuGwU=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
HYzmqDjBQbxSLEMaNegPRKOdJcuGwi=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
HYzmqDjBQbxSLEMaNegPRKOdJcuGwp=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
HYzmqDjBQbxSLEMaNegPRKOdJcuGwl=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'공연','mode':'PROGRAM','stype':'PCM'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
HYzmqDjBQbxSLEMaNegPRKOdJcuGwh=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG160,MG140,MG150'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐/클래식','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
HYzmqDjBQbxSLEMaNegPRKOdJcuGwA=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
HYzmqDjBQbxSLEMaNegPRKOdJcuGwo =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
HYzmqDjBQbxSLEMaNegPRKOdJcuGwr=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class HYzmqDjBQbxSLEMaNegPRKOdJcuGwT(HYzmqDjBQbxSLEMaNegPRKOdJcuGho):
 def __init__(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGwI,HYzmqDjBQbxSLEMaNegPRKOdJcuGwv,HYzmqDjBQbxSLEMaNegPRKOdJcuGwC):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_url =HYzmqDjBQbxSLEMaNegPRKOdJcuGwI
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle=HYzmqDjBQbxSLEMaNegPRKOdJcuGwv
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params =HYzmqDjBQbxSLEMaNegPRKOdJcuGwC
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj =xeQugEYjypoKCTPmHhGrlqNzkBDVtd() 
 def addon_noti(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,sting):
  try:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwV=xbmcgui.Dialog()
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwV.notification(__addonname__,sting)
  except:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
 def addon_log(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,string):
  try:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwt=string.encode('utf-8','ignore')
  except:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwt='addonException: addon_log'
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwk=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,HYzmqDjBQbxSLEMaNegPRKOdJcuGwt),level=HYzmqDjBQbxSLEMaNegPRKOdJcuGwk)
 def get_keyboard_input(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGTf):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwF=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
  kb=xbmc.Keyboard()
  kb.setHeading(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwF=kb.getText()
  return HYzmqDjBQbxSLEMaNegPRKOdJcuGwF
 def get_settings_account(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwy =__addon__.getSetting('id')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGws =__addon__.getSetting('pw')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwn =__addon__.getSetting('login_type')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTw=HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(__addon__.getSetting('selected_profile'))
  return(HYzmqDjBQbxSLEMaNegPRKOdJcuGwy,HYzmqDjBQbxSLEMaNegPRKOdJcuGws,HYzmqDjBQbxSLEMaNegPRKOdJcuGwn,HYzmqDjBQbxSLEMaNegPRKOdJcuGTw)
 def get_settings_uhd(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf):
  return HYzmqDjBQbxSLEMaNegPRKOdJcuGhI if __addon__.getSetting('active_uhd')=='true' else HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
 def get_settings_totalsearch(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTX =HYzmqDjBQbxSLEMaNegPRKOdJcuGhI if __addon__.getSetting('local_search')=='true' else HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTU=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI if __addon__.getSetting('local_history')=='true' else HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTi =HYzmqDjBQbxSLEMaNegPRKOdJcuGhI if __addon__.getSetting('total_search')=='true' else HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTp=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI if __addon__.getSetting('total_history')=='true' else HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTl=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI if __addon__.getSetting('menu_bookmark')=='true' else HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
  return(HYzmqDjBQbxSLEMaNegPRKOdJcuGTX,HYzmqDjBQbxSLEMaNegPRKOdJcuGTU,HYzmqDjBQbxSLEMaNegPRKOdJcuGTi,HYzmqDjBQbxSLEMaNegPRKOdJcuGTp,HYzmqDjBQbxSLEMaNegPRKOdJcuGTl)
 def get_settings_makebookmark(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf):
  return HYzmqDjBQbxSLEMaNegPRKOdJcuGhI if __addon__.getSetting('make_bookmark')=='true' else HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
 def get_settings_direct_replay(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTh=HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(__addon__.getSetting('direct_replay'))
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGTh==0:
   return HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
  else:
   return HYzmqDjBQbxSLEMaNegPRKOdJcuGhI
 def set_winEpisodeOrderby(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGTo):
  __addon__.setSetting('tving_orderby',HYzmqDjBQbxSLEMaNegPRKOdJcuGTo)
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTA=xbmcgui.Window(10000)
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTA.setProperty('TVING_M_ORDERBY',HYzmqDjBQbxSLEMaNegPRKOdJcuGTo)
 def get_winEpisodeOrderby(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTo=__addon__.getSetting('tving_orderby')
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGTo in['',HYzmqDjBQbxSLEMaNegPRKOdJcuGhr]:HYzmqDjBQbxSLEMaNegPRKOdJcuGTo='desc'
  return HYzmqDjBQbxSLEMaNegPRKOdJcuGTo
 def add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,label,sublabel='',img='',infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params='',isLink=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv,ContextMenu=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTr='%s?%s'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_url,urllib.parse.urlencode(params))
  if sublabel:HYzmqDjBQbxSLEMaNegPRKOdJcuGTf='%s < %s >'%(label,sublabel)
  else: HYzmqDjBQbxSLEMaNegPRKOdJcuGTf=label
  if not img:img='DefaultFolder.png'
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTI=xbmcgui.ListItem(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGhC(img)==HYzmqDjBQbxSLEMaNegPRKOdJcuGhW:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTI.setArt(img)
  else:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTI.setArt({'thumb':img,'poster':img})
  if infoLabels:HYzmqDjBQbxSLEMaNegPRKOdJcuGTI.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTI.setProperty('IsPlayable','true')
  if ContextMenu:HYzmqDjBQbxSLEMaNegPRKOdJcuGTI.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,HYzmqDjBQbxSLEMaNegPRKOdJcuGTr,HYzmqDjBQbxSLEMaNegPRKOdJcuGTI,isFolder)
 def get_selQuality(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,etype):
  try:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTv='selected_quality'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTC=[1080,720,480,360]
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTW=HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(__addon__.getSetting(HYzmqDjBQbxSLEMaNegPRKOdJcuGTv))
   return HYzmqDjBQbxSLEMaNegPRKOdJcuGTC[HYzmqDjBQbxSLEMaNegPRKOdJcuGTW]
  except:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
  return 720 
 def dp_Main_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf):
  (HYzmqDjBQbxSLEMaNegPRKOdJcuGTX,HYzmqDjBQbxSLEMaNegPRKOdJcuGTU,HYzmqDjBQbxSLEMaNegPRKOdJcuGTi,HYzmqDjBQbxSLEMaNegPRKOdJcuGTp,HYzmqDjBQbxSLEMaNegPRKOdJcuGTl)=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_settings_totalsearch()
  for HYzmqDjBQbxSLEMaNegPRKOdJcuGTV in HYzmqDjBQbxSLEMaNegPRKOdJcuGwX:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf=HYzmqDjBQbxSLEMaNegPRKOdJcuGTV.get('title')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTt=''
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGTV.get('mode')=='SEARCH_GROUP' and HYzmqDjBQbxSLEMaNegPRKOdJcuGTX ==HYzmqDjBQbxSLEMaNegPRKOdJcuGhv:continue
   elif HYzmqDjBQbxSLEMaNegPRKOdJcuGTV.get('mode')=='SEARCH_HISTORY' and HYzmqDjBQbxSLEMaNegPRKOdJcuGTU==HYzmqDjBQbxSLEMaNegPRKOdJcuGhv:continue
   elif HYzmqDjBQbxSLEMaNegPRKOdJcuGTV.get('mode')=='TOTAL_SEARCH' and HYzmqDjBQbxSLEMaNegPRKOdJcuGTi ==HYzmqDjBQbxSLEMaNegPRKOdJcuGhv:continue
   elif HYzmqDjBQbxSLEMaNegPRKOdJcuGTV.get('mode')=='TOTAL_HISTORY' and HYzmqDjBQbxSLEMaNegPRKOdJcuGTp==HYzmqDjBQbxSLEMaNegPRKOdJcuGhv:continue
   elif HYzmqDjBQbxSLEMaNegPRKOdJcuGTV.get('mode')=='MENU_BOOKMARK' and HYzmqDjBQbxSLEMaNegPRKOdJcuGTl==HYzmqDjBQbxSLEMaNegPRKOdJcuGhv:continue
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':HYzmqDjBQbxSLEMaNegPRKOdJcuGTV.get('mode'),'stype':HYzmqDjBQbxSLEMaNegPRKOdJcuGTV.get('stype'),'orderby':HYzmqDjBQbxSLEMaNegPRKOdJcuGTV.get('orderby'),'ordernm':HYzmqDjBQbxSLEMaNegPRKOdJcuGTV.get('ordernm'),'page':'1'}
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGTV.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTF=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTy =HYzmqDjBQbxSLEMaNegPRKOdJcuGhI
   else:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTF=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTy =HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
   if 'icon' in HYzmqDjBQbxSLEMaNegPRKOdJcuGTV:HYzmqDjBQbxSLEMaNegPRKOdJcuGTt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',HYzmqDjBQbxSLEMaNegPRKOdJcuGTV.get('icon')) 
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel='',img=HYzmqDjBQbxSLEMaNegPRKOdJcuGTt,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGTF,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk,isLink=HYzmqDjBQbxSLEMaNegPRKOdJcuGTy)
  xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle)
 def login_main(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf):
  (HYzmqDjBQbxSLEMaNegPRKOdJcuGTn,HYzmqDjBQbxSLEMaNegPRKOdJcuGXw,HYzmqDjBQbxSLEMaNegPRKOdJcuGXT,HYzmqDjBQbxSLEMaNegPRKOdJcuGXU)=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_settings_account()
  if not(HYzmqDjBQbxSLEMaNegPRKOdJcuGTn and HYzmqDjBQbxSLEMaNegPRKOdJcuGXw):
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwV=xbmcgui.Dialog()
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXi=HYzmqDjBQbxSLEMaNegPRKOdJcuGwV.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGXi==HYzmqDjBQbxSLEMaNegPRKOdJcuGhI:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXp=0
   while HYzmqDjBQbxSLEMaNegPRKOdJcuGhI:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGXp+=1
    time.sleep(0.05)
    if HYzmqDjBQbxSLEMaNegPRKOdJcuGXp>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXl=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.GetCredential(HYzmqDjBQbxSLEMaNegPRKOdJcuGTn,HYzmqDjBQbxSLEMaNegPRKOdJcuGXw,HYzmqDjBQbxSLEMaNegPRKOdJcuGXT,HYzmqDjBQbxSLEMaNegPRKOdJcuGXU)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXl:HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXl==HYzmqDjBQbxSLEMaNegPRKOdJcuGhv:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXh=HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('stype')
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXh=='live':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXA=HYzmqDjBQbxSLEMaNegPRKOdJcuGwU
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGXh=='vod':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXA=HYzmqDjBQbxSLEMaNegPRKOdJcuGwl
  else:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXA=HYzmqDjBQbxSLEMaNegPRKOdJcuGwh
  for HYzmqDjBQbxSLEMaNegPRKOdJcuGXo in HYzmqDjBQbxSLEMaNegPRKOdJcuGXA:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf=HYzmqDjBQbxSLEMaNegPRKOdJcuGXo.get('title')
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('ordernm')!='-':
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTf+='  ('+HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('ordernm')+')'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':HYzmqDjBQbxSLEMaNegPRKOdJcuGXo.get('mode'),'stype':HYzmqDjBQbxSLEMaNegPRKOdJcuGXo.get('stype'),'orderby':HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('orderby'),'ordernm':HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('ordernm'),'page':'1'}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel='',img='',infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGhV(HYzmqDjBQbxSLEMaNegPRKOdJcuGXA)>0:xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle)
 def dp_SubTitle_Group(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr): 
  for HYzmqDjBQbxSLEMaNegPRKOdJcuGXo in HYzmqDjBQbxSLEMaNegPRKOdJcuGwA:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf=HYzmqDjBQbxSLEMaNegPRKOdJcuGXo.get('title')
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('ordernm')!='-':
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTf+='  ('+HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('ordernm')+')'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':HYzmqDjBQbxSLEMaNegPRKOdJcuGXo.get('mode'),'genreCode':HYzmqDjBQbxSLEMaNegPRKOdJcuGXo.get('genreCode'),'stype':HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('stype'),'orderby':HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('orderby'),'page':'1'}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel='',img='',infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGhV(HYzmqDjBQbxSLEMaNegPRKOdJcuGwA)>0:xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle)
 def dp_LiveChannel_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXh =HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('stype')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXf =HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('page'))
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXI,HYzmqDjBQbxSLEMaNegPRKOdJcuGXv=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.GetLiveChannelList(HYzmqDjBQbxSLEMaNegPRKOdJcuGXh,HYzmqDjBQbxSLEMaNegPRKOdJcuGXf)
  for HYzmqDjBQbxSLEMaNegPRKOdJcuGXC in HYzmqDjBQbxSLEMaNegPRKOdJcuGXI:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('title')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTs =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('channel')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXW =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('thumbnail')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXV =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('synopsis')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXt =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('channelepg')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXk =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('cast')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXF =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('director')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXy =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('info_genre')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXs =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('year')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXn =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('mpaa')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUw =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('premiered')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUT={'mediatype':'episode','title':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'studio':HYzmqDjBQbxSLEMaNegPRKOdJcuGTs,'cast':HYzmqDjBQbxSLEMaNegPRKOdJcuGXk,'director':HYzmqDjBQbxSLEMaNegPRKOdJcuGXF,'genre':HYzmqDjBQbxSLEMaNegPRKOdJcuGXy,'plot':'%s\n%s\n%s\n\n%s'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGTs,HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXt,HYzmqDjBQbxSLEMaNegPRKOdJcuGXV),'year':HYzmqDjBQbxSLEMaNegPRKOdJcuGXs,'mpaa':HYzmqDjBQbxSLEMaNegPRKOdJcuGXn,'premiered':HYzmqDjBQbxSLEMaNegPRKOdJcuGUw}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'LIVE','mediacode':HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('mediacode'),'stype':HYzmqDjBQbxSLEMaNegPRKOdJcuGXh}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTs,sublabel=HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,img=HYzmqDjBQbxSLEMaNegPRKOdJcuGXW,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGUT,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXv:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['mode']='CHANNEL' 
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['stype']=HYzmqDjBQbxSLEMaNegPRKOdJcuGXh 
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['page']=HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf='[B]%s >>[/B]'%'다음 페이지'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUX=HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel=HYzmqDjBQbxSLEMaNegPRKOdJcuGUX,img=HYzmqDjBQbxSLEMaNegPRKOdJcuGTt,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGhV(HYzmqDjBQbxSLEMaNegPRKOdJcuGXI)>0:xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,cacheToDisc=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv)
 def dp_Program_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGUi =HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('stype')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTo =HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('orderby')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXf =HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('page'))
  HYzmqDjBQbxSLEMaNegPRKOdJcuGUp=HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('genreCode')
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGUp==HYzmqDjBQbxSLEMaNegPRKOdJcuGhr:HYzmqDjBQbxSLEMaNegPRKOdJcuGUp='all'
  HYzmqDjBQbxSLEMaNegPRKOdJcuGUl,HYzmqDjBQbxSLEMaNegPRKOdJcuGXv=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.GetProgramList(HYzmqDjBQbxSLEMaNegPRKOdJcuGUi,HYzmqDjBQbxSLEMaNegPRKOdJcuGTo,HYzmqDjBQbxSLEMaNegPRKOdJcuGXf,HYzmqDjBQbxSLEMaNegPRKOdJcuGUp)
  for HYzmqDjBQbxSLEMaNegPRKOdJcuGUh in HYzmqDjBQbxSLEMaNegPRKOdJcuGUl:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('title')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXW =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('thumbnail')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXV =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('synopsis')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUA =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('channel')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXk =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('cast')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXF =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('director')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXy=HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('info_genre')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXs =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('year')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUw =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('premiered')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXn =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('mpaa')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUT={'mediatype':'tvshow','title':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'studio':HYzmqDjBQbxSLEMaNegPRKOdJcuGUA,'cast':HYzmqDjBQbxSLEMaNegPRKOdJcuGXk,'director':HYzmqDjBQbxSLEMaNegPRKOdJcuGXF,'genre':HYzmqDjBQbxSLEMaNegPRKOdJcuGXy,'year':HYzmqDjBQbxSLEMaNegPRKOdJcuGXs,'premiered':HYzmqDjBQbxSLEMaNegPRKOdJcuGUw,'mpaa':HYzmqDjBQbxSLEMaNegPRKOdJcuGXn,'plot':HYzmqDjBQbxSLEMaNegPRKOdJcuGXV}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'EPISODE','programcode':HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('program'),'page':'1'}
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_settings_makebookmark():
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUo={'videoid':HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('program'),'vidtype':'tvshow','vtitle':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'vsubtitle':HYzmqDjBQbxSLEMaNegPRKOdJcuGUA,}
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUr=json.dumps(HYzmqDjBQbxSLEMaNegPRKOdJcuGUo)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUr=urllib.parse.quote(HYzmqDjBQbxSLEMaNegPRKOdJcuGUr)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUf='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGUr)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUI=[('(통합) 찜 영상에 추가',HYzmqDjBQbxSLEMaNegPRKOdJcuGUf)]
   else:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUI=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel=HYzmqDjBQbxSLEMaNegPRKOdJcuGUA,img=HYzmqDjBQbxSLEMaNegPRKOdJcuGXW,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGUT,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk,ContextMenu=HYzmqDjBQbxSLEMaNegPRKOdJcuGUI)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXv:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['mode'] ='PROGRAM' 
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['stype'] =HYzmqDjBQbxSLEMaNegPRKOdJcuGUi
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['orderby'] =HYzmqDjBQbxSLEMaNegPRKOdJcuGTo
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['page'] =HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['genreCode']=HYzmqDjBQbxSLEMaNegPRKOdJcuGUp 
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf='[B]%s >>[/B]'%'다음 페이지'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUX=HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel=HYzmqDjBQbxSLEMaNegPRKOdJcuGUX,img=HYzmqDjBQbxSLEMaNegPRKOdJcuGTt,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  xbmcplugin.setContent(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,cacheToDisc=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv)
 def dp_4K_Program_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXf =HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('page'))
  HYzmqDjBQbxSLEMaNegPRKOdJcuGUl,HYzmqDjBQbxSLEMaNegPRKOdJcuGXv=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.Get_UHD_ProgramList(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf)
  for HYzmqDjBQbxSLEMaNegPRKOdJcuGUh in HYzmqDjBQbxSLEMaNegPRKOdJcuGUl:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('title')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXW =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('thumbnail')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXV =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('synopsis')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUA =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('channel')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXk =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('cast')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXF =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('director')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXy=HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('info_genre')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXs =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('year')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUw =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('premiered')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXn =HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('mpaa')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUT={'mediatype':'tvshow','title':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'studio':HYzmqDjBQbxSLEMaNegPRKOdJcuGUA,'cast':HYzmqDjBQbxSLEMaNegPRKOdJcuGXk,'director':HYzmqDjBQbxSLEMaNegPRKOdJcuGXF,'genre':HYzmqDjBQbxSLEMaNegPRKOdJcuGXy,'year':HYzmqDjBQbxSLEMaNegPRKOdJcuGXs,'premiered':HYzmqDjBQbxSLEMaNegPRKOdJcuGUw,'mpaa':HYzmqDjBQbxSLEMaNegPRKOdJcuGXn,'plot':HYzmqDjBQbxSLEMaNegPRKOdJcuGXV}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'EPISODE','programcode':HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('program'),'page':'1'}
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_settings_makebookmark():
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUo={'videoid':HYzmqDjBQbxSLEMaNegPRKOdJcuGUh.get('program'),'vidtype':'tvshow','vtitle':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'vsubtitle':HYzmqDjBQbxSLEMaNegPRKOdJcuGUA,}
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUr=json.dumps(HYzmqDjBQbxSLEMaNegPRKOdJcuGUo)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUr=urllib.parse.quote(HYzmqDjBQbxSLEMaNegPRKOdJcuGUr)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUf='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGUr)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUI=[('(통합) 찜 영상에 추가',HYzmqDjBQbxSLEMaNegPRKOdJcuGUf)]
   else:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUI=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel=HYzmqDjBQbxSLEMaNegPRKOdJcuGUA,img=HYzmqDjBQbxSLEMaNegPRKOdJcuGXW,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGUT,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk,ContextMenu=HYzmqDjBQbxSLEMaNegPRKOdJcuGUI)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXv:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['mode'] ='4K_PROGRAM' 
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['page'] =HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf='[B]%s >>[/B]'%'다음 페이지'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUX=HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel=HYzmqDjBQbxSLEMaNegPRKOdJcuGUX,img=HYzmqDjBQbxSLEMaNegPRKOdJcuGTt,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  xbmcplugin.setContent(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,cacheToDisc=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv)
 def dp_Episode_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGUC=HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('programcode')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXf =HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('page'))
  HYzmqDjBQbxSLEMaNegPRKOdJcuGUW,HYzmqDjBQbxSLEMaNegPRKOdJcuGXv,HYzmqDjBQbxSLEMaNegPRKOdJcuGUV=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.GetEpisodeList(HYzmqDjBQbxSLEMaNegPRKOdJcuGUC,HYzmqDjBQbxSLEMaNegPRKOdJcuGXf,orderby=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_winEpisodeOrderby())
  for HYzmqDjBQbxSLEMaNegPRKOdJcuGUt in HYzmqDjBQbxSLEMaNegPRKOdJcuGUW:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf =HYzmqDjBQbxSLEMaNegPRKOdJcuGUt.get('title')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUX =HYzmqDjBQbxSLEMaNegPRKOdJcuGUt.get('subtitle')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXW =HYzmqDjBQbxSLEMaNegPRKOdJcuGUt.get('thumbnail')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXV =HYzmqDjBQbxSLEMaNegPRKOdJcuGUt.get('synopsis')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUk=HYzmqDjBQbxSLEMaNegPRKOdJcuGUt.get('info_title')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUF =HYzmqDjBQbxSLEMaNegPRKOdJcuGUt.get('aired')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUy =HYzmqDjBQbxSLEMaNegPRKOdJcuGUt.get('studio')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUs =HYzmqDjBQbxSLEMaNegPRKOdJcuGUt.get('frequency')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUT={'mediatype':'episode','title':HYzmqDjBQbxSLEMaNegPRKOdJcuGUk,'aired':HYzmqDjBQbxSLEMaNegPRKOdJcuGUF,'studio':HYzmqDjBQbxSLEMaNegPRKOdJcuGUy,'episode':HYzmqDjBQbxSLEMaNegPRKOdJcuGUs,'plot':HYzmqDjBQbxSLEMaNegPRKOdJcuGXV}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'VOD','mediacode':HYzmqDjBQbxSLEMaNegPRKOdJcuGUt.get('episode'),'stype':'vod','programcode':HYzmqDjBQbxSLEMaNegPRKOdJcuGUC,'title':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'thumbnail':HYzmqDjBQbxSLEMaNegPRKOdJcuGXW}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel=HYzmqDjBQbxSLEMaNegPRKOdJcuGUX,img=HYzmqDjBQbxSLEMaNegPRKOdJcuGXW,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGUT,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXf==1:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUT={'plot':'정렬순서를 변경합니다.'}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['mode'] ='ORDER_BY' 
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_winEpisodeOrderby()=='desc':
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTf='정렬순서변경 : 최신화부터 -> 1회부터'
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['orderby']='asc'
   else:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTf='정렬순서변경 : 1회부터 -> 최신화부터'
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['orderby']='desc'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel='',img=HYzmqDjBQbxSLEMaNegPRKOdJcuGTt,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGUT,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk,isLink=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXv:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['mode'] ='EPISODE' 
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['programcode']=HYzmqDjBQbxSLEMaNegPRKOdJcuGUC
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['page'] =HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf='[B]%s >>[/B]'%'다음 페이지'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUX=HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel=HYzmqDjBQbxSLEMaNegPRKOdJcuGUX,img=HYzmqDjBQbxSLEMaNegPRKOdJcuGTt,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  xbmcplugin.setContent(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,'episodes')
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGhV(HYzmqDjBQbxSLEMaNegPRKOdJcuGUW)>0:xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,cacheToDisc=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI)
 def dp_setEpOrderby(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTo =HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('orderby')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.set_winEpisodeOrderby(HYzmqDjBQbxSLEMaNegPRKOdJcuGTo)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGUi =HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('stype')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTo =HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('orderby')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXf=HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('page'))
  HYzmqDjBQbxSLEMaNegPRKOdJcuGUn,HYzmqDjBQbxSLEMaNegPRKOdJcuGXv=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.GetMovieList(HYzmqDjBQbxSLEMaNegPRKOdJcuGUi,HYzmqDjBQbxSLEMaNegPRKOdJcuGTo,HYzmqDjBQbxSLEMaNegPRKOdJcuGXf)
  for HYzmqDjBQbxSLEMaNegPRKOdJcuGiw in HYzmqDjBQbxSLEMaNegPRKOdJcuGUn:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('title')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXW =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('thumbnail')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXV =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('synopsis')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUk =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('info_title')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXs =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('year')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXk =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('cast')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXF =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('director')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXy =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('info_genre')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGiT =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('duration')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUw =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('premiered')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUy =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('studio')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXn =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('mpaa')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUT={'mediatype':'movie','title':HYzmqDjBQbxSLEMaNegPRKOdJcuGUk,'year':HYzmqDjBQbxSLEMaNegPRKOdJcuGXs,'cast':HYzmqDjBQbxSLEMaNegPRKOdJcuGXk,'director':HYzmqDjBQbxSLEMaNegPRKOdJcuGXF,'genre':HYzmqDjBQbxSLEMaNegPRKOdJcuGXy,'duration':HYzmqDjBQbxSLEMaNegPRKOdJcuGiT,'premiered':HYzmqDjBQbxSLEMaNegPRKOdJcuGUw,'studio':HYzmqDjBQbxSLEMaNegPRKOdJcuGUy,'mpaa':HYzmqDjBQbxSLEMaNegPRKOdJcuGXn,'plot':HYzmqDjBQbxSLEMaNegPRKOdJcuGXV}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'MOVIE','mediacode':HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('moviecode'),'stype':'movie','title':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'thumbnail':HYzmqDjBQbxSLEMaNegPRKOdJcuGXW}
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_settings_makebookmark():
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUo={'videoid':HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('moviecode'),'vidtype':'movie','vtitle':HYzmqDjBQbxSLEMaNegPRKOdJcuGUk,'vsubtitle':'',}
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUr=json.dumps(HYzmqDjBQbxSLEMaNegPRKOdJcuGUo)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUr=urllib.parse.quote(HYzmqDjBQbxSLEMaNegPRKOdJcuGUr)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUf='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGUr)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUI=[('(통합) 찜 영상에 추가',HYzmqDjBQbxSLEMaNegPRKOdJcuGUf)]
   else:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUI=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel='',img=HYzmqDjBQbxSLEMaNegPRKOdJcuGXW,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGUT,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk,ContextMenu=HYzmqDjBQbxSLEMaNegPRKOdJcuGUI)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXv:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['mode'] ='MOVIE_SUB' 
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['orderby']=HYzmqDjBQbxSLEMaNegPRKOdJcuGTo
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['stype'] =HYzmqDjBQbxSLEMaNegPRKOdJcuGUi
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['page'] =HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf='[B]%s >>[/B]'%'다음 페이지'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUX=HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel=HYzmqDjBQbxSLEMaNegPRKOdJcuGUX,img=HYzmqDjBQbxSLEMaNegPRKOdJcuGTt,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  xbmcplugin.setContent(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,'movies')
  xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,cacheToDisc=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv)
 def dp_4K_Movie_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXf=HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('page'))
  HYzmqDjBQbxSLEMaNegPRKOdJcuGUn,HYzmqDjBQbxSLEMaNegPRKOdJcuGXv=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.Get_UHD_MovieList(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf)
  for HYzmqDjBQbxSLEMaNegPRKOdJcuGiw in HYzmqDjBQbxSLEMaNegPRKOdJcuGUn:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('title')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXW =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('thumbnail')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXV =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('synopsis')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUk =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('info_title')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXs =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('year')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXk =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('cast')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXF =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('director')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXy =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('info_genre')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGiT =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('duration')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUw =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('premiered')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUy =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('studio')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXn =HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('mpaa')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUT={'mediatype':'movie','title':HYzmqDjBQbxSLEMaNegPRKOdJcuGUk,'year':HYzmqDjBQbxSLEMaNegPRKOdJcuGXs,'cast':HYzmqDjBQbxSLEMaNegPRKOdJcuGXk,'director':HYzmqDjBQbxSLEMaNegPRKOdJcuGXF,'genre':HYzmqDjBQbxSLEMaNegPRKOdJcuGXy,'duration':HYzmqDjBQbxSLEMaNegPRKOdJcuGiT,'premiered':HYzmqDjBQbxSLEMaNegPRKOdJcuGUw,'studio':HYzmqDjBQbxSLEMaNegPRKOdJcuGUy,'mpaa':HYzmqDjBQbxSLEMaNegPRKOdJcuGXn,'plot':HYzmqDjBQbxSLEMaNegPRKOdJcuGXV}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'MOVIE','mediacode':HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('moviecode'),'stype':'movie','title':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'thumbnail':HYzmqDjBQbxSLEMaNegPRKOdJcuGXW}
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_settings_makebookmark():
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUo={'videoid':HYzmqDjBQbxSLEMaNegPRKOdJcuGiw.get('moviecode'),'vidtype':'movie','vtitle':HYzmqDjBQbxSLEMaNegPRKOdJcuGUk,'vsubtitle':'',}
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUr=json.dumps(HYzmqDjBQbxSLEMaNegPRKOdJcuGUo)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUr=urllib.parse.quote(HYzmqDjBQbxSLEMaNegPRKOdJcuGUr)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUf='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGUr)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUI=[('(통합) 찜 영상에 추가',HYzmqDjBQbxSLEMaNegPRKOdJcuGUf)]
   else:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUI=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel='',img=HYzmqDjBQbxSLEMaNegPRKOdJcuGXW,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGUT,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk,ContextMenu=HYzmqDjBQbxSLEMaNegPRKOdJcuGUI)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXv:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['mode'] ='4K_MOVIE' 
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['page'] =HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf='[B]%s >>[/B]'%'다음 페이지'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUX=HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel=HYzmqDjBQbxSLEMaNegPRKOdJcuGUX,img=HYzmqDjBQbxSLEMaNegPRKOdJcuGTt,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  xbmcplugin.setContent(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,'movies')
  xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,cacheToDisc=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv)
 def dp_Set_Bookmark(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGiX=urllib.parse.unquote(HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('bm_param'))
  HYzmqDjBQbxSLEMaNegPRKOdJcuGiX=json.loads(HYzmqDjBQbxSLEMaNegPRKOdJcuGiX)
  HYzmqDjBQbxSLEMaNegPRKOdJcuGiU =HYzmqDjBQbxSLEMaNegPRKOdJcuGiX.get('videoid')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGip =HYzmqDjBQbxSLEMaNegPRKOdJcuGiX.get('vidtype')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGil =HYzmqDjBQbxSLEMaNegPRKOdJcuGiX.get('vtitle')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGih =HYzmqDjBQbxSLEMaNegPRKOdJcuGiX.get('vsubtitle')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwV=xbmcgui.Dialog()
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXi=HYzmqDjBQbxSLEMaNegPRKOdJcuGwV.yesno(__language__(30913).encode('utf8'),HYzmqDjBQbxSLEMaNegPRKOdJcuGil+' \n\n'+__language__(30914))
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXi==HYzmqDjBQbxSLEMaNegPRKOdJcuGhv:return
  HYzmqDjBQbxSLEMaNegPRKOdJcuGiA=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.GetBookmarkInfo(HYzmqDjBQbxSLEMaNegPRKOdJcuGiU,HYzmqDjBQbxSLEMaNegPRKOdJcuGip)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGih!='':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGiA['saveinfo']['subtitle']=HYzmqDjBQbxSLEMaNegPRKOdJcuGih 
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGip=='tvshow':HYzmqDjBQbxSLEMaNegPRKOdJcuGiA['saveinfo']['infoLabels']['studio']=HYzmqDjBQbxSLEMaNegPRKOdJcuGih 
  HYzmqDjBQbxSLEMaNegPRKOdJcuGio=json.dumps(HYzmqDjBQbxSLEMaNegPRKOdJcuGiA)
  HYzmqDjBQbxSLEMaNegPRKOdJcuGio=urllib.parse.quote(HYzmqDjBQbxSLEMaNegPRKOdJcuGio)
  HYzmqDjBQbxSLEMaNegPRKOdJcuGUf ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGio)
  xbmc.executebuiltin(HYzmqDjBQbxSLEMaNegPRKOdJcuGUf)
 def dp_Search_Group(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  if 'search_key' in HYzmqDjBQbxSLEMaNegPRKOdJcuGXr:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGir=HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('search_key')
  else:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGir=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not HYzmqDjBQbxSLEMaNegPRKOdJcuGir:
    return
  for HYzmqDjBQbxSLEMaNegPRKOdJcuGXo in HYzmqDjBQbxSLEMaNegPRKOdJcuGwp:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGif =HYzmqDjBQbxSLEMaNegPRKOdJcuGXo.get('mode')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXh=HYzmqDjBQbxSLEMaNegPRKOdJcuGXo.get('stype')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf=HYzmqDjBQbxSLEMaNegPRKOdJcuGXo.get('title')
   (HYzmqDjBQbxSLEMaNegPRKOdJcuGiI,HYzmqDjBQbxSLEMaNegPRKOdJcuGXv)=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.GetSearchList(HYzmqDjBQbxSLEMaNegPRKOdJcuGir,1,HYzmqDjBQbxSLEMaNegPRKOdJcuGXh)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGiv={'plot':'검색어 : '+HYzmqDjBQbxSLEMaNegPRKOdJcuGir+'\n\n'+HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.Search_FreeList(HYzmqDjBQbxSLEMaNegPRKOdJcuGiI)}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':HYzmqDjBQbxSLEMaNegPRKOdJcuGif,'stype':HYzmqDjBQbxSLEMaNegPRKOdJcuGXh,'search_key':HYzmqDjBQbxSLEMaNegPRKOdJcuGir,'page':'1',}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel='',img='',infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGiv,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGhV(HYzmqDjBQbxSLEMaNegPRKOdJcuGwp)>0:xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,cacheToDisc=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI)
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.Save_Searched_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGir)
 def Search_FreeList(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGin):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGiC=''
  HYzmqDjBQbxSLEMaNegPRKOdJcuGiW=7
  try:
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGhV(HYzmqDjBQbxSLEMaNegPRKOdJcuGin)==0:return '검색결과 없음'
   for i in HYzmqDjBQbxSLEMaNegPRKOdJcuGhk(HYzmqDjBQbxSLEMaNegPRKOdJcuGhV(HYzmqDjBQbxSLEMaNegPRKOdJcuGin)):
    if i>=HYzmqDjBQbxSLEMaNegPRKOdJcuGiW:
     HYzmqDjBQbxSLEMaNegPRKOdJcuGiC=HYzmqDjBQbxSLEMaNegPRKOdJcuGiC+'...'
     break
    HYzmqDjBQbxSLEMaNegPRKOdJcuGiC=HYzmqDjBQbxSLEMaNegPRKOdJcuGiC+HYzmqDjBQbxSLEMaNegPRKOdJcuGin[i]['title']+'\n'
  except:
   return ''
  return HYzmqDjBQbxSLEMaNegPRKOdJcuGiC
 def dp_Search_History(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGiV=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.Load_List_File('search')
  for HYzmqDjBQbxSLEMaNegPRKOdJcuGit in HYzmqDjBQbxSLEMaNegPRKOdJcuGiV:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGik=HYzmqDjBQbxSLEMaNegPRKOdJcuGhW(urllib.parse.parse_qsl(HYzmqDjBQbxSLEMaNegPRKOdJcuGit))
   HYzmqDjBQbxSLEMaNegPRKOdJcuGiF=HYzmqDjBQbxSLEMaNegPRKOdJcuGik.get('skey').strip()
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'SEARCH_GROUP','search_key':HYzmqDjBQbxSLEMaNegPRKOdJcuGiF,}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGiy={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':HYzmqDjBQbxSLEMaNegPRKOdJcuGiF,'vType':'-',}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGis=urllib.parse.urlencode(HYzmqDjBQbxSLEMaNegPRKOdJcuGiy)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUI=[('선택된 검색어 ( %s ) 삭제'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGiF),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGis))]
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGiF,sublabel='',img=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk,ContextMenu=HYzmqDjBQbxSLEMaNegPRKOdJcuGUI)
  HYzmqDjBQbxSLEMaNegPRKOdJcuGUT={'plot':'검색목록 전체를 삭제합니다.'}
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTf='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel='',img=HYzmqDjBQbxSLEMaNegPRKOdJcuGTt,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGUT,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk,isLink=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI)
  xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,cacheToDisc=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv)
 def dp_Search_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXf =HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('page'))
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXh =HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('stype')
  if 'search_key' in HYzmqDjBQbxSLEMaNegPRKOdJcuGXr:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGir=HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('search_key')
  else:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGir=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not HYzmqDjBQbxSLEMaNegPRKOdJcuGir:
    xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle)
    return
  HYzmqDjBQbxSLEMaNegPRKOdJcuGiI,HYzmqDjBQbxSLEMaNegPRKOdJcuGXv=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.GetSearchList(HYzmqDjBQbxSLEMaNegPRKOdJcuGir,HYzmqDjBQbxSLEMaNegPRKOdJcuGXf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXh)
  for HYzmqDjBQbxSLEMaNegPRKOdJcuGin in HYzmqDjBQbxSLEMaNegPRKOdJcuGiI:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf =HYzmqDjBQbxSLEMaNegPRKOdJcuGin.get('title')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXW =HYzmqDjBQbxSLEMaNegPRKOdJcuGin.get('thumbnail')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXV =HYzmqDjBQbxSLEMaNegPRKOdJcuGin.get('synopsis')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpw =HYzmqDjBQbxSLEMaNegPRKOdJcuGin.get('program')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXk =HYzmqDjBQbxSLEMaNegPRKOdJcuGin.get('cast')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXF =HYzmqDjBQbxSLEMaNegPRKOdJcuGin.get('director')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXy=HYzmqDjBQbxSLEMaNegPRKOdJcuGin.get('info_genre')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGiT =HYzmqDjBQbxSLEMaNegPRKOdJcuGin.get('duration')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXn =HYzmqDjBQbxSLEMaNegPRKOdJcuGin.get('mpaa')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXs =HYzmqDjBQbxSLEMaNegPRKOdJcuGin.get('year')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUF =HYzmqDjBQbxSLEMaNegPRKOdJcuGin.get('aired')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUT={'mediatype':'tvshow' if HYzmqDjBQbxSLEMaNegPRKOdJcuGXh=='vod' else 'movie','title':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'cast':HYzmqDjBQbxSLEMaNegPRKOdJcuGXk,'director':HYzmqDjBQbxSLEMaNegPRKOdJcuGXF,'genre':HYzmqDjBQbxSLEMaNegPRKOdJcuGXy,'duration':HYzmqDjBQbxSLEMaNegPRKOdJcuGiT,'mpaa':HYzmqDjBQbxSLEMaNegPRKOdJcuGXn,'year':HYzmqDjBQbxSLEMaNegPRKOdJcuGXs,'aired':HYzmqDjBQbxSLEMaNegPRKOdJcuGUF,'plot':'%s\n\n%s'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXV)}
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGXh=='vod':
    HYzmqDjBQbxSLEMaNegPRKOdJcuGiU=HYzmqDjBQbxSLEMaNegPRKOdJcuGin.get('program')
    HYzmqDjBQbxSLEMaNegPRKOdJcuGip='tvshow'
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'EPISODE','programcode':HYzmqDjBQbxSLEMaNegPRKOdJcuGiU,'page':'1',}
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTF=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI
   else:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGiU=HYzmqDjBQbxSLEMaNegPRKOdJcuGin.get('movie')
    HYzmqDjBQbxSLEMaNegPRKOdJcuGip='movie'
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'MOVIE','mediacode':HYzmqDjBQbxSLEMaNegPRKOdJcuGiU,'stype':'movie','title':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'thumbnail':HYzmqDjBQbxSLEMaNegPRKOdJcuGXW,}
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTF=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_settings_makebookmark():
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUo={'videoid':HYzmqDjBQbxSLEMaNegPRKOdJcuGiU,'vidtype':HYzmqDjBQbxSLEMaNegPRKOdJcuGip,'vtitle':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'vsubtitle':'',}
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUr=json.dumps(HYzmqDjBQbxSLEMaNegPRKOdJcuGUo)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUr=urllib.parse.quote(HYzmqDjBQbxSLEMaNegPRKOdJcuGUr)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUf='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGUr)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUI=[('(통합) 찜 영상에 추가',HYzmqDjBQbxSLEMaNegPRKOdJcuGUf)]
   else:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUI=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel='',img=HYzmqDjBQbxSLEMaNegPRKOdJcuGXW,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGUT,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGTF,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk,isLink=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv,ContextMenu=HYzmqDjBQbxSLEMaNegPRKOdJcuGUI)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXv:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['mode'] ='SEARCH' 
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['search_key']=HYzmqDjBQbxSLEMaNegPRKOdJcuGir
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk['page'] =HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf='[B]%s >>[/B]'%'다음 페이지'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUX=HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGXf+1)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel=HYzmqDjBQbxSLEMaNegPRKOdJcuGUX,img=HYzmqDjBQbxSLEMaNegPRKOdJcuGTt,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXh=='movie':xbmcplugin.setContent(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,'movies')
  else:xbmcplugin.setContent(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,cacheToDisc=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv)
 def dp_History_Remove(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGpT=HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('delType')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGpX =HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('sKey')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGpU =HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('vType')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwV=xbmcgui.Dialog()
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGpT=='SEARCH_ALL':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXi=HYzmqDjBQbxSLEMaNegPRKOdJcuGwV.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGpT=='SEARCH_ONE':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXi=HYzmqDjBQbxSLEMaNegPRKOdJcuGwV.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGpT=='WATCH_ALL':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXi=HYzmqDjBQbxSLEMaNegPRKOdJcuGwV.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGpT=='WATCH_ONE':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGXi=HYzmqDjBQbxSLEMaNegPRKOdJcuGwV.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXi==HYzmqDjBQbxSLEMaNegPRKOdJcuGhv:sys.exit()
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGpT=='SEARCH_ALL':
   if os.path.isfile(HYzmqDjBQbxSLEMaNegPRKOdJcuGwr):os.remove(HYzmqDjBQbxSLEMaNegPRKOdJcuGwr)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGpT=='SEARCH_ONE':
   try:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGpi=HYzmqDjBQbxSLEMaNegPRKOdJcuGwr
    HYzmqDjBQbxSLEMaNegPRKOdJcuGpl=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.Load_List_File('search') 
    fp=HYzmqDjBQbxSLEMaNegPRKOdJcuGhF(HYzmqDjBQbxSLEMaNegPRKOdJcuGpi,'w',-1,'utf-8')
    for HYzmqDjBQbxSLEMaNegPRKOdJcuGph in HYzmqDjBQbxSLEMaNegPRKOdJcuGpl:
     HYzmqDjBQbxSLEMaNegPRKOdJcuGpA=HYzmqDjBQbxSLEMaNegPRKOdJcuGhW(urllib.parse.parse_qsl(HYzmqDjBQbxSLEMaNegPRKOdJcuGph))
     HYzmqDjBQbxSLEMaNegPRKOdJcuGpo=HYzmqDjBQbxSLEMaNegPRKOdJcuGpA.get('skey').strip()
     if HYzmqDjBQbxSLEMaNegPRKOdJcuGpX!=HYzmqDjBQbxSLEMaNegPRKOdJcuGpo:
      fp.write(HYzmqDjBQbxSLEMaNegPRKOdJcuGph)
    fp.close()
   except:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGpT=='WATCH_ALL':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%HYzmqDjBQbxSLEMaNegPRKOdJcuGpU))
   if os.path.isfile(HYzmqDjBQbxSLEMaNegPRKOdJcuGpi):os.remove(HYzmqDjBQbxSLEMaNegPRKOdJcuGpi)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGpT=='WATCH_ONE':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%HYzmqDjBQbxSLEMaNegPRKOdJcuGpU))
   try:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGpl=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.Load_List_File(HYzmqDjBQbxSLEMaNegPRKOdJcuGpU) 
    fp=HYzmqDjBQbxSLEMaNegPRKOdJcuGhF(HYzmqDjBQbxSLEMaNegPRKOdJcuGpi,'w',-1,'utf-8')
    for HYzmqDjBQbxSLEMaNegPRKOdJcuGph in HYzmqDjBQbxSLEMaNegPRKOdJcuGpl:
     HYzmqDjBQbxSLEMaNegPRKOdJcuGpA=HYzmqDjBQbxSLEMaNegPRKOdJcuGhW(urllib.parse.parse_qsl(HYzmqDjBQbxSLEMaNegPRKOdJcuGph))
     HYzmqDjBQbxSLEMaNegPRKOdJcuGpo=HYzmqDjBQbxSLEMaNegPRKOdJcuGpA.get('code').strip()
     if HYzmqDjBQbxSLEMaNegPRKOdJcuGpX!=HYzmqDjBQbxSLEMaNegPRKOdJcuGpo:
      fp.write(HYzmqDjBQbxSLEMaNegPRKOdJcuGph)
    fp.close()
   except:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXh): 
  try:
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGXh=='search':
    HYzmqDjBQbxSLEMaNegPRKOdJcuGpi=HYzmqDjBQbxSLEMaNegPRKOdJcuGwr
   elif HYzmqDjBQbxSLEMaNegPRKOdJcuGXh in['vod','movie']:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGpi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%HYzmqDjBQbxSLEMaNegPRKOdJcuGXh))
   else:
    return[]
   fp=HYzmqDjBQbxSLEMaNegPRKOdJcuGhF(HYzmqDjBQbxSLEMaNegPRKOdJcuGpi,'r',-1,'utf-8')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpr=fp.readlines()
   fp.close()
  except:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpr=[]
  return HYzmqDjBQbxSLEMaNegPRKOdJcuGpr
 def Save_Watched_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXh,HYzmqDjBQbxSLEMaNegPRKOdJcuGwC):
  try:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%HYzmqDjBQbxSLEMaNegPRKOdJcuGXh))
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpl=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.Load_List_File(HYzmqDjBQbxSLEMaNegPRKOdJcuGXh) 
   fp=HYzmqDjBQbxSLEMaNegPRKOdJcuGhF(HYzmqDjBQbxSLEMaNegPRKOdJcuGpf,'w',-1,'utf-8')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpI=urllib.parse.urlencode(HYzmqDjBQbxSLEMaNegPRKOdJcuGwC)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpI=HYzmqDjBQbxSLEMaNegPRKOdJcuGpI+'\n'
   fp.write(HYzmqDjBQbxSLEMaNegPRKOdJcuGpI)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpv=0
   for HYzmqDjBQbxSLEMaNegPRKOdJcuGph in HYzmqDjBQbxSLEMaNegPRKOdJcuGpl:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGpA=HYzmqDjBQbxSLEMaNegPRKOdJcuGhW(urllib.parse.parse_qsl(HYzmqDjBQbxSLEMaNegPRKOdJcuGph))
    HYzmqDjBQbxSLEMaNegPRKOdJcuGpC=HYzmqDjBQbxSLEMaNegPRKOdJcuGwC.get('code').strip()
    HYzmqDjBQbxSLEMaNegPRKOdJcuGpW=HYzmqDjBQbxSLEMaNegPRKOdJcuGpA.get('code').strip()
    if HYzmqDjBQbxSLEMaNegPRKOdJcuGXh=='vod' and HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_settings_direct_replay()==HYzmqDjBQbxSLEMaNegPRKOdJcuGhI:
     HYzmqDjBQbxSLEMaNegPRKOdJcuGpC=HYzmqDjBQbxSLEMaNegPRKOdJcuGwC.get('videoid').strip()
     HYzmqDjBQbxSLEMaNegPRKOdJcuGpW=HYzmqDjBQbxSLEMaNegPRKOdJcuGpA.get('videoid').strip()if HYzmqDjBQbxSLEMaNegPRKOdJcuGpW!=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr else '-'
    if HYzmqDjBQbxSLEMaNegPRKOdJcuGpC!=HYzmqDjBQbxSLEMaNegPRKOdJcuGpW:
     fp.write(HYzmqDjBQbxSLEMaNegPRKOdJcuGph)
     HYzmqDjBQbxSLEMaNegPRKOdJcuGpv+=1
     if HYzmqDjBQbxSLEMaNegPRKOdJcuGpv>=50:break
   fp.close()
  except:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
 def dp_Watch_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXh =HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('stype')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGTh=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_settings_direct_replay()
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXh=='-':
   for HYzmqDjBQbxSLEMaNegPRKOdJcuGXo in HYzmqDjBQbxSLEMaNegPRKOdJcuGwi:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTf=HYzmqDjBQbxSLEMaNegPRKOdJcuGXo.get('title')
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':HYzmqDjBQbxSLEMaNegPRKOdJcuGXo.get('mode'),'stype':HYzmqDjBQbxSLEMaNegPRKOdJcuGXo.get('stype')}
    HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel='',img='',infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGhr,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGhV(HYzmqDjBQbxSLEMaNegPRKOdJcuGwi)>0:xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle)
  else:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpV=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.Load_List_File(HYzmqDjBQbxSLEMaNegPRKOdJcuGXh)
   for HYzmqDjBQbxSLEMaNegPRKOdJcuGpt in HYzmqDjBQbxSLEMaNegPRKOdJcuGpV:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGik=HYzmqDjBQbxSLEMaNegPRKOdJcuGhW(urllib.parse.parse_qsl(HYzmqDjBQbxSLEMaNegPRKOdJcuGpt))
    HYzmqDjBQbxSLEMaNegPRKOdJcuGpk =HYzmqDjBQbxSLEMaNegPRKOdJcuGik.get('code').strip()
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTf =HYzmqDjBQbxSLEMaNegPRKOdJcuGik.get('title').strip()
    HYzmqDjBQbxSLEMaNegPRKOdJcuGXW=HYzmqDjBQbxSLEMaNegPRKOdJcuGik.get('img').strip()
    HYzmqDjBQbxSLEMaNegPRKOdJcuGiU =HYzmqDjBQbxSLEMaNegPRKOdJcuGik.get('videoid').strip()
    try:
     HYzmqDjBQbxSLEMaNegPRKOdJcuGXW=HYzmqDjBQbxSLEMaNegPRKOdJcuGXW.replace('\'','\"')
     HYzmqDjBQbxSLEMaNegPRKOdJcuGXW=json.loads(HYzmqDjBQbxSLEMaNegPRKOdJcuGXW)
    except:
     HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUT={}
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUT['plot']=HYzmqDjBQbxSLEMaNegPRKOdJcuGTf
    if HYzmqDjBQbxSLEMaNegPRKOdJcuGXh=='vod':
     if HYzmqDjBQbxSLEMaNegPRKOdJcuGTh==HYzmqDjBQbxSLEMaNegPRKOdJcuGhv or HYzmqDjBQbxSLEMaNegPRKOdJcuGiU==HYzmqDjBQbxSLEMaNegPRKOdJcuGhr:
      HYzmqDjBQbxSLEMaNegPRKOdJcuGUT['mediatype']='tvshow'
      HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'EPISODE','programcode':HYzmqDjBQbxSLEMaNegPRKOdJcuGpk,'page':'1'}
      HYzmqDjBQbxSLEMaNegPRKOdJcuGTF=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI
     else:
      HYzmqDjBQbxSLEMaNegPRKOdJcuGUT['mediatype']='episode'
      HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'VOD','mediacode':HYzmqDjBQbxSLEMaNegPRKOdJcuGiU,'stype':'vod','programcode':HYzmqDjBQbxSLEMaNegPRKOdJcuGpk,'title':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'thumbnail':HYzmqDjBQbxSLEMaNegPRKOdJcuGXW}
      HYzmqDjBQbxSLEMaNegPRKOdJcuGTF=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
    else:
     HYzmqDjBQbxSLEMaNegPRKOdJcuGUT['mediatype']='movie'
     HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'MOVIE','mediacode':HYzmqDjBQbxSLEMaNegPRKOdJcuGpk,'stype':'movie','title':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'thumbnail':HYzmqDjBQbxSLEMaNegPRKOdJcuGXW}
     HYzmqDjBQbxSLEMaNegPRKOdJcuGTF=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
    HYzmqDjBQbxSLEMaNegPRKOdJcuGiy={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':HYzmqDjBQbxSLEMaNegPRKOdJcuGpk,'vType':HYzmqDjBQbxSLEMaNegPRKOdJcuGXh,}
    HYzmqDjBQbxSLEMaNegPRKOdJcuGis=urllib.parse.urlencode(HYzmqDjBQbxSLEMaNegPRKOdJcuGiy)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGUI=[('선택된 시청이력 ( %s ) 삭제'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGis))]
    HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel='',img=HYzmqDjBQbxSLEMaNegPRKOdJcuGXW,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGUT,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGTF,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk,ContextMenu=HYzmqDjBQbxSLEMaNegPRKOdJcuGUI)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUT={'plot':'시청목록을 삭제합니다.'}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':HYzmqDjBQbxSLEMaNegPRKOdJcuGXh,}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTt=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel='',img=HYzmqDjBQbxSLEMaNegPRKOdJcuGTt,infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGUT,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk,isLink=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI)
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGXh=='movie':xbmcplugin.setContent(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,'movies')
   else:xbmcplugin.setContent(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,cacheToDisc=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv)
 def Save_Searched_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGir):
  try:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpF=HYzmqDjBQbxSLEMaNegPRKOdJcuGwr
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpl=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.Load_List_File('search') 
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpy={'skey':HYzmqDjBQbxSLEMaNegPRKOdJcuGir.strip()}
   fp=HYzmqDjBQbxSLEMaNegPRKOdJcuGhF(HYzmqDjBQbxSLEMaNegPRKOdJcuGpF,'w',-1,'utf-8')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpI=urllib.parse.urlencode(HYzmqDjBQbxSLEMaNegPRKOdJcuGpy)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpI=HYzmqDjBQbxSLEMaNegPRKOdJcuGpI+'\n'
   fp.write(HYzmqDjBQbxSLEMaNegPRKOdJcuGpI)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGpv=0
   for HYzmqDjBQbxSLEMaNegPRKOdJcuGph in HYzmqDjBQbxSLEMaNegPRKOdJcuGpl:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGpA=HYzmqDjBQbxSLEMaNegPRKOdJcuGhW(urllib.parse.parse_qsl(HYzmqDjBQbxSLEMaNegPRKOdJcuGph))
    HYzmqDjBQbxSLEMaNegPRKOdJcuGpC=HYzmqDjBQbxSLEMaNegPRKOdJcuGpy.get('skey').strip()
    HYzmqDjBQbxSLEMaNegPRKOdJcuGpW=HYzmqDjBQbxSLEMaNegPRKOdJcuGpA.get('skey').strip()
    if HYzmqDjBQbxSLEMaNegPRKOdJcuGpC!=HYzmqDjBQbxSLEMaNegPRKOdJcuGpW:
     fp.write(HYzmqDjBQbxSLEMaNegPRKOdJcuGph)
     HYzmqDjBQbxSLEMaNegPRKOdJcuGpv+=1
     if HYzmqDjBQbxSLEMaNegPRKOdJcuGpv>=50:break
   fp.close()
  except:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
 def play_VIDEO(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGps =HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('mediacode')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXh =HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('stype')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGpn =HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('pvrmode')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGlw=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_selQuality(HYzmqDjBQbxSLEMaNegPRKOdJcuGXh)
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGps,HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGlw),HYzmqDjBQbxSLEMaNegPRKOdJcuGXh,HYzmqDjBQbxSLEMaNegPRKOdJcuGpn))
  HYzmqDjBQbxSLEMaNegPRKOdJcuGlT=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.GetBroadURL(HYzmqDjBQbxSLEMaNegPRKOdJcuGps,HYzmqDjBQbxSLEMaNegPRKOdJcuGlw,HYzmqDjBQbxSLEMaNegPRKOdJcuGXh,HYzmqDjBQbxSLEMaNegPRKOdJcuGpn,optUHD=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_settings_uhd())
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.addon_log('qt, stype, url : %s - %s - %s'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGht(HYzmqDjBQbxSLEMaNegPRKOdJcuGlw),HYzmqDjBQbxSLEMaNegPRKOdJcuGXh,HYzmqDjBQbxSLEMaNegPRKOdJcuGlT['streaming_url']))
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGlT['streaming_url']=='':
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGlT['error_msg']=='':
    HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.addon_noti(__language__(30908).encode('utf8'))
   else:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.addon_noti(HYzmqDjBQbxSLEMaNegPRKOdJcuGlT['error_msg'].encode('utf8'))
   return
  HYzmqDjBQbxSLEMaNegPRKOdJcuGlX='user-agent={}'.format(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.USER_AGENT)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGlT['watermark'] !='':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlX='{}&x-tving-param1={}&x-tving-param2={}'.format(HYzmqDjBQbxSLEMaNegPRKOdJcuGlX,HYzmqDjBQbxSLEMaNegPRKOdJcuGlT['watermarkKey'],HYzmqDjBQbxSLEMaNegPRKOdJcuGlT['watermark'])
  HYzmqDjBQbxSLEMaNegPRKOdJcuGlU =HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
  HYzmqDjBQbxSLEMaNegPRKOdJcuGli =HYzmqDjBQbxSLEMaNegPRKOdJcuGlT['streaming_url'].find('Policy=')
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGli!=-1:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlp =HYzmqDjBQbxSLEMaNegPRKOdJcuGlT['streaming_url'].split('?')[0]
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlh=HYzmqDjBQbxSLEMaNegPRKOdJcuGhW(urllib.parse.parse_qsl(urllib.parse.urlsplit(HYzmqDjBQbxSLEMaNegPRKOdJcuGlT['streaming_url']).query))
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlA='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGlh['Policy'],HYzmqDjBQbxSLEMaNegPRKOdJcuGlh['Signature'],HYzmqDjBQbxSLEMaNegPRKOdJcuGlh['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in HYzmqDjBQbxSLEMaNegPRKOdJcuGlp:
    HYzmqDjBQbxSLEMaNegPRKOdJcuGlU=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI
    HYzmqDjBQbxSLEMaNegPRKOdJcuGlo =HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGlr=HYzmqDjBQbxSLEMaNegPRKOdJcuGlo.strftime('%Y-%m-%d-%H:%M:%S')
    if HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(HYzmqDjBQbxSLEMaNegPRKOdJcuGlr.replace('-','').replace(':',''))<HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(HYzmqDjBQbxSLEMaNegPRKOdJcuGlh['end'].replace('-','').replace(':','')):
     HYzmqDjBQbxSLEMaNegPRKOdJcuGlh['end']=HYzmqDjBQbxSLEMaNegPRKOdJcuGlr
     HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.addon_noti(__language__(30915).encode('utf8'))
    HYzmqDjBQbxSLEMaNegPRKOdJcuGlp ='%s?%s'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGlp,urllib.parse.urlencode(HYzmqDjBQbxSLEMaNegPRKOdJcuGlh,doseq=HYzmqDjBQbxSLEMaNegPRKOdJcuGhI))
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlf='{}|{}&Cookie={}'.format(HYzmqDjBQbxSLEMaNegPRKOdJcuGlp,HYzmqDjBQbxSLEMaNegPRKOdJcuGlX,HYzmqDjBQbxSLEMaNegPRKOdJcuGlA)
  else:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlf=HYzmqDjBQbxSLEMaNegPRKOdJcuGlT['streaming_url']+'|'+HYzmqDjBQbxSLEMaNegPRKOdJcuGlX
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.addon_log('if tmp_pos == -1')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.addon_log(HYzmqDjBQbxSLEMaNegPRKOdJcuGlf)
  HYzmqDjBQbxSLEMaNegPRKOdJcuGlI=xbmcgui.ListItem(path=HYzmqDjBQbxSLEMaNegPRKOdJcuGlf)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGlT['drm_license']!='':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlv=HYzmqDjBQbxSLEMaNegPRKOdJcuGlT['drm_license']
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlC ='https://cj.drmkeyserver.com/widevine_license'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlW ='mpd'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlV ='com.widevine.alpha'
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlt =inputstreamhelper.Helper(HYzmqDjBQbxSLEMaNegPRKOdJcuGlW,drm='widevine')
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGlt.check_inputstream():
    HYzmqDjBQbxSLEMaNegPRKOdJcuGlk={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.USER_AGENT,'AcquireLicenseAssertion':HYzmqDjBQbxSLEMaNegPRKOdJcuGlv,'Host':'cj.drmkeyserver.com',}
    HYzmqDjBQbxSLEMaNegPRKOdJcuGlF=HYzmqDjBQbxSLEMaNegPRKOdJcuGlC+'|'+urllib.parse.urlencode(HYzmqDjBQbxSLEMaNegPRKOdJcuGlk)+'|R{SSM}|'
    HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setProperty('inputstream',HYzmqDjBQbxSLEMaNegPRKOdJcuGlt.inputstream_addon)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setProperty('inputstream.adaptive.manifest_type',HYzmqDjBQbxSLEMaNegPRKOdJcuGlW)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setProperty('inputstream.adaptive.license_type',HYzmqDjBQbxSLEMaNegPRKOdJcuGlV)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setProperty('inputstream.adaptive.license_key',HYzmqDjBQbxSLEMaNegPRKOdJcuGlF)
    HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setProperty('inputstream.adaptive.stream_headers',HYzmqDjBQbxSLEMaNegPRKOdJcuGlX)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGlU==HYzmqDjBQbxSLEMaNegPRKOdJcuGhI:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setContentLookup(HYzmqDjBQbxSLEMaNegPRKOdJcuGhv)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setMimeType('application/x-mpegURL')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setProperty('inputstream','inputstream.ffmpegdirect')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setProperty('ResumeTime','0')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setProperty('TotalTime','10000')
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('mode')in['VOD','MOVIE']:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setContentLookup(HYzmqDjBQbxSLEMaNegPRKOdJcuGhv)
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setMimeType('application/x-mpegURL')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setProperty('inputstream','inputstream.adaptive')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGlI.setProperty('inputstream.adaptive.manifest_type','hls')
  xbmcplugin.setResolvedUrl(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,HYzmqDjBQbxSLEMaNegPRKOdJcuGhI,HYzmqDjBQbxSLEMaNegPRKOdJcuGlI)
  try:
   if HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('mode')in['VOD','MOVIE']and HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('title'):
    HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'code':HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('programcode')if HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('mode')=='VOD' else HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('mediacode'),'img':HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('thumbnail'),'title':HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('title'),'videoid':HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('mediacode')}
    HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.Save_Watched_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('stype'),HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  except:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
 def logout(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwV=xbmcgui.Dialog()
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXi=HYzmqDjBQbxSLEMaNegPRKOdJcuGwV.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGXi==HYzmqDjBQbxSLEMaNegPRKOdJcuGhv:sys.exit()
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.Init_TV_Total()
  if os.path.isfile(HYzmqDjBQbxSLEMaNegPRKOdJcuGwo):os.remove(HYzmqDjBQbxSLEMaNegPRKOdJcuGwo)
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGly =HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.Get_Now_Datetime()
  HYzmqDjBQbxSLEMaNegPRKOdJcuGls=HYzmqDjBQbxSLEMaNegPRKOdJcuGly+datetime.timedelta(days=HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(__addon__.getSetting('cache_ttl')))
  (HYzmqDjBQbxSLEMaNegPRKOdJcuGTn,HYzmqDjBQbxSLEMaNegPRKOdJcuGXw,HYzmqDjBQbxSLEMaNegPRKOdJcuGXT,HYzmqDjBQbxSLEMaNegPRKOdJcuGXU)=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_settings_account()
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.Save_session_acount(HYzmqDjBQbxSLEMaNegPRKOdJcuGTn,HYzmqDjBQbxSLEMaNegPRKOdJcuGXw,HYzmqDjBQbxSLEMaNegPRKOdJcuGXT,HYzmqDjBQbxSLEMaNegPRKOdJcuGXU)
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.TV['account']['token_limit']=HYzmqDjBQbxSLEMaNegPRKOdJcuGls.strftime('%Y%m%d')
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.JsonFile_Save(HYzmqDjBQbxSLEMaNegPRKOdJcuGwo,HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.TV)
 def cookiefile_check(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.TV=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.JsonFile_Load(HYzmqDjBQbxSLEMaNegPRKOdJcuGwo)
  if 'account' not in HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.TV:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.Init_TV_Total()
   return HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
  (HYzmqDjBQbxSLEMaNegPRKOdJcuGln,HYzmqDjBQbxSLEMaNegPRKOdJcuGhw,HYzmqDjBQbxSLEMaNegPRKOdJcuGhT,HYzmqDjBQbxSLEMaNegPRKOdJcuGhX)=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.get_settings_account()
  (HYzmqDjBQbxSLEMaNegPRKOdJcuGhU,HYzmqDjBQbxSLEMaNegPRKOdJcuGhi,HYzmqDjBQbxSLEMaNegPRKOdJcuGhp,HYzmqDjBQbxSLEMaNegPRKOdJcuGhl)=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.Load_session_acount()
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGln!=HYzmqDjBQbxSLEMaNegPRKOdJcuGhU or HYzmqDjBQbxSLEMaNegPRKOdJcuGhw!=HYzmqDjBQbxSLEMaNegPRKOdJcuGhi or HYzmqDjBQbxSLEMaNegPRKOdJcuGhT!=HYzmqDjBQbxSLEMaNegPRKOdJcuGhp or HYzmqDjBQbxSLEMaNegPRKOdJcuGhX!=HYzmqDjBQbxSLEMaNegPRKOdJcuGhl:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.Init_TV_Total()
   return HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>HYzmqDjBQbxSLEMaNegPRKOdJcuGhf(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.TV['account']['token_limit']):
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.Init_TV_Total()
   return HYzmqDjBQbxSLEMaNegPRKOdJcuGhv
  return HYzmqDjBQbxSLEMaNegPRKOdJcuGhI
 def dp_Global_Search(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGif=HYzmqDjBQbxSLEMaNegPRKOdJcuGXr.get('mode')
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='TOTAL_SEARCH':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGhA='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGhA='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(HYzmqDjBQbxSLEMaNegPRKOdJcuGhA)
 def dp_Bookmark_Menu(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGhA='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(HYzmqDjBQbxSLEMaNegPRKOdJcuGhA)
 def dp_EuroLive_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf,HYzmqDjBQbxSLEMaNegPRKOdJcuGXr):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGXI=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.TvingObj.GetEuroChannelList()
  for HYzmqDjBQbxSLEMaNegPRKOdJcuGXC in HYzmqDjBQbxSLEMaNegPRKOdJcuGXI:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUA =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('channel')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTf =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('title')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUX =HYzmqDjBQbxSLEMaNegPRKOdJcuGXC.get('subtitle')
   HYzmqDjBQbxSLEMaNegPRKOdJcuGUT={'mediatype':'episode','title':HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,'plot':'%s\n%s'%(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,HYzmqDjBQbxSLEMaNegPRKOdJcuGUX)}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGTk={'mode':'LIVE','mediacode':HYzmqDjBQbxSLEMaNegPRKOdJcuGUA,'stype':'onair',}
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.add_dir(HYzmqDjBQbxSLEMaNegPRKOdJcuGTf,sublabel=HYzmqDjBQbxSLEMaNegPRKOdJcuGUX,img='',infoLabels=HYzmqDjBQbxSLEMaNegPRKOdJcuGUT,isFolder=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv,params=HYzmqDjBQbxSLEMaNegPRKOdJcuGTk)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGhV(HYzmqDjBQbxSLEMaNegPRKOdJcuGXI)>0:xbmcplugin.endOfDirectory(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf._addon_handle,cacheToDisc=HYzmqDjBQbxSLEMaNegPRKOdJcuGhv)
 def tving_main(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf):
  HYzmqDjBQbxSLEMaNegPRKOdJcuGif=HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params.get('mode',HYzmqDjBQbxSLEMaNegPRKOdJcuGhr)
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='LOGOUT':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.logout()
   return
  HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.login_main()
  if HYzmqDjBQbxSLEMaNegPRKOdJcuGif is HYzmqDjBQbxSLEMaNegPRKOdJcuGhr:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_Main_List()
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_Title_Group(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif in['GLOBAL_GROUP']:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_SubTitle_Group(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='CHANNEL':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_LiveChannel_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif in['LIVE','VOD','MOVIE']:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.play_VIDEO(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='PROGRAM':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_Program_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='4K_PROGRAM':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_4K_Program_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='EPISODE':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_Episode_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='MOVIE_SUB':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_Movie_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='4K_MOVIE':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_4K_Movie_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='SEARCH_GROUP':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_Search_Group(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif in['SEARCH','LOCAL_SEARCH']:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_Search_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='WATCH':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_Watch_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_History_Remove(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='ORDER_BY':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_setEpOrderby(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='SET_BOOKMARK':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_Set_Bookmark(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif in['TOTAL_SEARCH','TOTAL_HISTORY']:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_Global_Search(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='SEARCH_HISTORY':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_Search_History(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='MENU_BOOKMARK':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_Bookmark_Menu(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  elif HYzmqDjBQbxSLEMaNegPRKOdJcuGif=='EURO_GROUP':
   HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.dp_EuroLive_List(HYzmqDjBQbxSLEMaNegPRKOdJcuGwf.main_params)
  else:
   HYzmqDjBQbxSLEMaNegPRKOdJcuGhr
# Created by pyminifier (https://github.com/liftoff/pyminifier)
