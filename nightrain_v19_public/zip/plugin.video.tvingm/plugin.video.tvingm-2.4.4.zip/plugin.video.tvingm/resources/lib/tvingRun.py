__author__="NightRain"
WBYARcGvlOtsXjrUoxyeVDKJQkaFfh=object
WBYARcGvlOtsXjrUoxyeVDKJQkaFfb=None
WBYARcGvlOtsXjrUoxyeVDKJQkaFfi=int
WBYARcGvlOtsXjrUoxyeVDKJQkaFfn=True
WBYARcGvlOtsXjrUoxyeVDKJQkaFfP=False
WBYARcGvlOtsXjrUoxyeVDKJQkaFfI=type
WBYARcGvlOtsXjrUoxyeVDKJQkaFfz=dict
WBYARcGvlOtsXjrUoxyeVDKJQkaFfd=len
WBYARcGvlOtsXjrUoxyeVDKJQkaFfN=str
WBYARcGvlOtsXjrUoxyeVDKJQkaFfp=range
WBYARcGvlOtsXjrUoxyeVDKJQkaFfw=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
WBYARcGvlOtsXjrUoxyeVDKJQkaFmL=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
WBYARcGvlOtsXjrUoxyeVDKJQkaFmg=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
WBYARcGvlOtsXjrUoxyeVDKJQkaFmM=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
WBYARcGvlOtsXjrUoxyeVDKJQkaFmS=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
WBYARcGvlOtsXjrUoxyeVDKJQkaFmH=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'공연','mode':'PROGRAM','stype':'PCM'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
WBYARcGvlOtsXjrUoxyeVDKJQkaFmf=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG160,MG140,MG150'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐/클래식','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
WBYARcGvlOtsXjrUoxyeVDKJQkaFmC=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
WBYARcGvlOtsXjrUoxyeVDKJQkaFmh =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
WBYARcGvlOtsXjrUoxyeVDKJQkaFmb=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class WBYARcGvlOtsXjrUoxyeVDKJQkaFmq(WBYARcGvlOtsXjrUoxyeVDKJQkaFfh):
 def __init__(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFmn,WBYARcGvlOtsXjrUoxyeVDKJQkaFmP,WBYARcGvlOtsXjrUoxyeVDKJQkaFmI):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_url =WBYARcGvlOtsXjrUoxyeVDKJQkaFmn
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle=WBYARcGvlOtsXjrUoxyeVDKJQkaFmP
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params =WBYARcGvlOtsXjrUoxyeVDKJQkaFmI
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBe() 
 def addon_noti(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,sting):
  try:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmd=xbmcgui.Dialog()
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmd.notification(__addonname__,sting)
  except:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFfb
 def addon_log(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,string):
  try:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmN=string.encode('utf-8','ignore')
  except:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmN='addonException: addon_log'
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmp=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,WBYARcGvlOtsXjrUoxyeVDKJQkaFmN),level=WBYARcGvlOtsXjrUoxyeVDKJQkaFmp)
 def get_keyboard_input(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFqi):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmw=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb
  kb=xbmc.Keyboard()
  kb.setHeading(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmw=kb.getText()
  return WBYARcGvlOtsXjrUoxyeVDKJQkaFmw
 def get_settings_account(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmT =__addon__.getSetting('id')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmu =__addon__.getSetting('pw')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmE =__addon__.getSetting('login_type')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqm=WBYARcGvlOtsXjrUoxyeVDKJQkaFfi(__addon__.getSetting('selected_profile'))
  return(WBYARcGvlOtsXjrUoxyeVDKJQkaFmT,WBYARcGvlOtsXjrUoxyeVDKJQkaFmu,WBYARcGvlOtsXjrUoxyeVDKJQkaFmE,WBYARcGvlOtsXjrUoxyeVDKJQkaFqm)
 def get_settings_totalsearch(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqL =WBYARcGvlOtsXjrUoxyeVDKJQkaFfn if __addon__.getSetting('local_search')=='true' else WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqg=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn if __addon__.getSetting('local_history')=='true' else WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqM =WBYARcGvlOtsXjrUoxyeVDKJQkaFfn if __addon__.getSetting('total_search')=='true' else WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqS=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn if __addon__.getSetting('total_history')=='true' else WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqH=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn if __addon__.getSetting('menu_bookmark')=='true' else WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
  return(WBYARcGvlOtsXjrUoxyeVDKJQkaFqL,WBYARcGvlOtsXjrUoxyeVDKJQkaFqg,WBYARcGvlOtsXjrUoxyeVDKJQkaFqM,WBYARcGvlOtsXjrUoxyeVDKJQkaFqS,WBYARcGvlOtsXjrUoxyeVDKJQkaFqH)
 def get_settings_makebookmark(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi):
  return WBYARcGvlOtsXjrUoxyeVDKJQkaFfn if __addon__.getSetting('make_bookmark')=='true' else WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
 def get_settings_direct_replay(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqf=WBYARcGvlOtsXjrUoxyeVDKJQkaFfi(__addon__.getSetting('direct_replay'))
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFqf==0:
   return WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
  else:
   return WBYARcGvlOtsXjrUoxyeVDKJQkaFfn
 def set_winEpisodeOrderby(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFqh):
  __addon__.setSetting('tving_orderby',WBYARcGvlOtsXjrUoxyeVDKJQkaFqh)
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqC=xbmcgui.Window(10000)
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqC.setProperty('TVING_M_ORDERBY',WBYARcGvlOtsXjrUoxyeVDKJQkaFqh)
 def get_winEpisodeOrderby(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqh=__addon__.getSetting('tving_orderby')
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFqh in['',WBYARcGvlOtsXjrUoxyeVDKJQkaFfb]:WBYARcGvlOtsXjrUoxyeVDKJQkaFqh='desc'
  return WBYARcGvlOtsXjrUoxyeVDKJQkaFqh
 def add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,label,sublabel='',img='',infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn,params='',isLink=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP,ContextMenu=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqb='%s?%s'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_url,urllib.parse.urlencode(params))
  if sublabel:WBYARcGvlOtsXjrUoxyeVDKJQkaFqi='%s < %s >'%(label,sublabel)
  else: WBYARcGvlOtsXjrUoxyeVDKJQkaFqi=label
  if not img:img='DefaultFolder.png'
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqn=xbmcgui.ListItem(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFfI(img)==WBYARcGvlOtsXjrUoxyeVDKJQkaFfz:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqn.setArt(img)
  else:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqn.setArt({'thumb':img,'poster':img})
  if infoLabels:WBYARcGvlOtsXjrUoxyeVDKJQkaFqn.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqn.setProperty('IsPlayable','true')
  if ContextMenu:WBYARcGvlOtsXjrUoxyeVDKJQkaFqn.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,WBYARcGvlOtsXjrUoxyeVDKJQkaFqb,WBYARcGvlOtsXjrUoxyeVDKJQkaFqn,isFolder)
 def get_selQuality(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,etype):
  try:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqP='selected_quality'
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqI=[1080,720,480,360]
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqz=WBYARcGvlOtsXjrUoxyeVDKJQkaFfi(__addon__.getSetting(WBYARcGvlOtsXjrUoxyeVDKJQkaFqP))
   return WBYARcGvlOtsXjrUoxyeVDKJQkaFqI[WBYARcGvlOtsXjrUoxyeVDKJQkaFqz]
  except:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFfb
  return 720 
 def dp_Main_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi):
  (WBYARcGvlOtsXjrUoxyeVDKJQkaFqL,WBYARcGvlOtsXjrUoxyeVDKJQkaFqg,WBYARcGvlOtsXjrUoxyeVDKJQkaFqM,WBYARcGvlOtsXjrUoxyeVDKJQkaFqS,WBYARcGvlOtsXjrUoxyeVDKJQkaFqH)=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_settings_totalsearch()
  for WBYARcGvlOtsXjrUoxyeVDKJQkaFqd in WBYARcGvlOtsXjrUoxyeVDKJQkaFmL:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi=WBYARcGvlOtsXjrUoxyeVDKJQkaFqd.get('title')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqN=''
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFqd.get('mode')=='SEARCH_GROUP' and WBYARcGvlOtsXjrUoxyeVDKJQkaFqL ==WBYARcGvlOtsXjrUoxyeVDKJQkaFfP:continue
   elif WBYARcGvlOtsXjrUoxyeVDKJQkaFqd.get('mode')=='SEARCH_HISTORY' and WBYARcGvlOtsXjrUoxyeVDKJQkaFqg==WBYARcGvlOtsXjrUoxyeVDKJQkaFfP:continue
   elif WBYARcGvlOtsXjrUoxyeVDKJQkaFqd.get('mode')=='TOTAL_SEARCH' and WBYARcGvlOtsXjrUoxyeVDKJQkaFqM ==WBYARcGvlOtsXjrUoxyeVDKJQkaFfP:continue
   elif WBYARcGvlOtsXjrUoxyeVDKJQkaFqd.get('mode')=='TOTAL_HISTORY' and WBYARcGvlOtsXjrUoxyeVDKJQkaFqS==WBYARcGvlOtsXjrUoxyeVDKJQkaFfP:continue
   elif WBYARcGvlOtsXjrUoxyeVDKJQkaFqd.get('mode')=='MENU_BOOKMARK' and WBYARcGvlOtsXjrUoxyeVDKJQkaFqH==WBYARcGvlOtsXjrUoxyeVDKJQkaFfP:continue
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':WBYARcGvlOtsXjrUoxyeVDKJQkaFqd.get('mode'),'stype':WBYARcGvlOtsXjrUoxyeVDKJQkaFqd.get('stype'),'orderby':WBYARcGvlOtsXjrUoxyeVDKJQkaFqd.get('orderby'),'ordernm':WBYARcGvlOtsXjrUoxyeVDKJQkaFqd.get('ordernm'),'page':'1'}
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFqd.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqw=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqT =WBYARcGvlOtsXjrUoxyeVDKJQkaFfn
   else:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqw=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqT =WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
   if 'icon' in WBYARcGvlOtsXjrUoxyeVDKJQkaFqd:WBYARcGvlOtsXjrUoxyeVDKJQkaFqN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',WBYARcGvlOtsXjrUoxyeVDKJQkaFqd.get('icon')) 
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel='',img=WBYARcGvlOtsXjrUoxyeVDKJQkaFqN,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFqw,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp,isLink=WBYARcGvlOtsXjrUoxyeVDKJQkaFqT)
  xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle)
 def login_main(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi):
  (WBYARcGvlOtsXjrUoxyeVDKJQkaFqE,WBYARcGvlOtsXjrUoxyeVDKJQkaFLm,WBYARcGvlOtsXjrUoxyeVDKJQkaFLq,WBYARcGvlOtsXjrUoxyeVDKJQkaFLg)=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_settings_account()
  if not(WBYARcGvlOtsXjrUoxyeVDKJQkaFqE and WBYARcGvlOtsXjrUoxyeVDKJQkaFLm):
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmd=xbmcgui.Dialog()
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLM=WBYARcGvlOtsXjrUoxyeVDKJQkaFmd.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFLM==WBYARcGvlOtsXjrUoxyeVDKJQkaFfn:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLS=0
   while WBYARcGvlOtsXjrUoxyeVDKJQkaFfn:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFLS+=1
    time.sleep(0.05)
    if WBYARcGvlOtsXjrUoxyeVDKJQkaFLS>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLH=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.GetCredential(WBYARcGvlOtsXjrUoxyeVDKJQkaFqE,WBYARcGvlOtsXjrUoxyeVDKJQkaFLm,WBYARcGvlOtsXjrUoxyeVDKJQkaFLq,WBYARcGvlOtsXjrUoxyeVDKJQkaFLg)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLH:WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLH==WBYARcGvlOtsXjrUoxyeVDKJQkaFfP:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLf=WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('stype')
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLf=='live':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLC=WBYARcGvlOtsXjrUoxyeVDKJQkaFmg
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFLf=='vod':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLC=WBYARcGvlOtsXjrUoxyeVDKJQkaFmH
  else:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLC=WBYARcGvlOtsXjrUoxyeVDKJQkaFmf
  for WBYARcGvlOtsXjrUoxyeVDKJQkaFLh in WBYARcGvlOtsXjrUoxyeVDKJQkaFLC:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi=WBYARcGvlOtsXjrUoxyeVDKJQkaFLh.get('title')
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('ordernm')!='-':
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqi+='  ('+WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('ordernm')+')'
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':WBYARcGvlOtsXjrUoxyeVDKJQkaFLh.get('mode'),'stype':WBYARcGvlOtsXjrUoxyeVDKJQkaFLh.get('stype'),'orderby':WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('orderby'),'ordernm':WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('ordernm'),'page':'1'}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel='',img='',infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFfd(WBYARcGvlOtsXjrUoxyeVDKJQkaFLC)>0:xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle)
 def dp_SubTitle_Group(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb): 
  for WBYARcGvlOtsXjrUoxyeVDKJQkaFLh in WBYARcGvlOtsXjrUoxyeVDKJQkaFmC:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi=WBYARcGvlOtsXjrUoxyeVDKJQkaFLh.get('title')
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('ordernm')!='-':
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqi+='  ('+WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('ordernm')+')'
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':WBYARcGvlOtsXjrUoxyeVDKJQkaFLh.get('mode'),'genreCode':WBYARcGvlOtsXjrUoxyeVDKJQkaFLh.get('genreCode'),'stype':WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('stype'),'orderby':WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('orderby'),'page':'1'}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel='',img='',infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFfd(WBYARcGvlOtsXjrUoxyeVDKJQkaFmC)>0:xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle)
 def dp_LiveChannel_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLf =WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('stype')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLi =WBYARcGvlOtsXjrUoxyeVDKJQkaFfi(WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('page'))
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLn,WBYARcGvlOtsXjrUoxyeVDKJQkaFLP=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.GetLiveChannelList(WBYARcGvlOtsXjrUoxyeVDKJQkaFLf,WBYARcGvlOtsXjrUoxyeVDKJQkaFLi)
  for WBYARcGvlOtsXjrUoxyeVDKJQkaFLI in WBYARcGvlOtsXjrUoxyeVDKJQkaFLn:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('title')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqu =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('channel')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLz =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('thumbnail')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLd =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('synopsis')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLN =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('channelepg')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLp =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('cast')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLw =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('director')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLT =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('info_genre')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLu =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('year')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLE =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('mpaa')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgm =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('premiered')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgq={'mediatype':'episode','title':WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,'studio':WBYARcGvlOtsXjrUoxyeVDKJQkaFqu,'cast':WBYARcGvlOtsXjrUoxyeVDKJQkaFLp,'director':WBYARcGvlOtsXjrUoxyeVDKJQkaFLw,'genre':WBYARcGvlOtsXjrUoxyeVDKJQkaFLT,'plot':'%s\n%s\n%s\n\n%s'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFqu,WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLN,WBYARcGvlOtsXjrUoxyeVDKJQkaFLd),'year':WBYARcGvlOtsXjrUoxyeVDKJQkaFLu,'mpaa':WBYARcGvlOtsXjrUoxyeVDKJQkaFLE,'premiered':WBYARcGvlOtsXjrUoxyeVDKJQkaFgm}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':'LIVE','mediacode':WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('mediacode'),'stype':WBYARcGvlOtsXjrUoxyeVDKJQkaFLf}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqu,sublabel=WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,img=WBYARcGvlOtsXjrUoxyeVDKJQkaFLz,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFgq,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLP:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['mode']='CHANNEL' 
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['stype']=WBYARcGvlOtsXjrUoxyeVDKJQkaFLf 
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['page']=WBYARcGvlOtsXjrUoxyeVDKJQkaFfN(WBYARcGvlOtsXjrUoxyeVDKJQkaFLi+1)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi='[B]%s >>[/B]'%'다음 페이지'
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgL=WBYARcGvlOtsXjrUoxyeVDKJQkaFfN(WBYARcGvlOtsXjrUoxyeVDKJQkaFLi+1)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel=WBYARcGvlOtsXjrUoxyeVDKJQkaFgL,img=WBYARcGvlOtsXjrUoxyeVDKJQkaFqN,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFfd(WBYARcGvlOtsXjrUoxyeVDKJQkaFLn)>0:xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,cacheToDisc=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP)
 def dp_Program_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFgM =WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('stype')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqh =WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('orderby')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLi =WBYARcGvlOtsXjrUoxyeVDKJQkaFfi(WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('page'))
  WBYARcGvlOtsXjrUoxyeVDKJQkaFgS=WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('genreCode')
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFgS==WBYARcGvlOtsXjrUoxyeVDKJQkaFfb:WBYARcGvlOtsXjrUoxyeVDKJQkaFgS='all'
  WBYARcGvlOtsXjrUoxyeVDKJQkaFgH,WBYARcGvlOtsXjrUoxyeVDKJQkaFLP=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.GetProgramList(WBYARcGvlOtsXjrUoxyeVDKJQkaFgM,WBYARcGvlOtsXjrUoxyeVDKJQkaFqh,WBYARcGvlOtsXjrUoxyeVDKJQkaFLi,WBYARcGvlOtsXjrUoxyeVDKJQkaFgS)
  for WBYARcGvlOtsXjrUoxyeVDKJQkaFgf in WBYARcGvlOtsXjrUoxyeVDKJQkaFgH:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi =WBYARcGvlOtsXjrUoxyeVDKJQkaFgf.get('title')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLz =WBYARcGvlOtsXjrUoxyeVDKJQkaFgf.get('thumbnail')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLd =WBYARcGvlOtsXjrUoxyeVDKJQkaFgf.get('synopsis')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgC =WBYARcGvlOtsXjrUoxyeVDKJQkaFgf.get('channel')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLp =WBYARcGvlOtsXjrUoxyeVDKJQkaFgf.get('cast')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLw =WBYARcGvlOtsXjrUoxyeVDKJQkaFgf.get('director')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLT=WBYARcGvlOtsXjrUoxyeVDKJQkaFgf.get('info_genre')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLu =WBYARcGvlOtsXjrUoxyeVDKJQkaFgf.get('year')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgm =WBYARcGvlOtsXjrUoxyeVDKJQkaFgf.get('premiered')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLE =WBYARcGvlOtsXjrUoxyeVDKJQkaFgf.get('mpaa')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgq={'mediatype':'tvshow','title':WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,'studio':WBYARcGvlOtsXjrUoxyeVDKJQkaFgC,'cast':WBYARcGvlOtsXjrUoxyeVDKJQkaFLp,'director':WBYARcGvlOtsXjrUoxyeVDKJQkaFLw,'genre':WBYARcGvlOtsXjrUoxyeVDKJQkaFLT,'year':WBYARcGvlOtsXjrUoxyeVDKJQkaFLu,'premiered':WBYARcGvlOtsXjrUoxyeVDKJQkaFgm,'mpaa':WBYARcGvlOtsXjrUoxyeVDKJQkaFLE,'plot':WBYARcGvlOtsXjrUoxyeVDKJQkaFLd}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':'EPISODE','programcode':WBYARcGvlOtsXjrUoxyeVDKJQkaFgf.get('program'),'page':'1'}
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_settings_makebookmark():
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgh={'videoid':WBYARcGvlOtsXjrUoxyeVDKJQkaFgf.get('program'),'vidtype':'tvshow','vtitle':WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,'vsubtitle':WBYARcGvlOtsXjrUoxyeVDKJQkaFgC,}
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgb=json.dumps(WBYARcGvlOtsXjrUoxyeVDKJQkaFgh)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgb=urllib.parse.quote(WBYARcGvlOtsXjrUoxyeVDKJQkaFgb)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgi='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFgb)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgn=[('(통합) 찜 영상에 추가',WBYARcGvlOtsXjrUoxyeVDKJQkaFgi)]
   else:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgn=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel=WBYARcGvlOtsXjrUoxyeVDKJQkaFgC,img=WBYARcGvlOtsXjrUoxyeVDKJQkaFLz,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFgq,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp,ContextMenu=WBYARcGvlOtsXjrUoxyeVDKJQkaFgn)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLP:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['mode'] ='PROGRAM' 
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['stype'] =WBYARcGvlOtsXjrUoxyeVDKJQkaFgM
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['orderby'] =WBYARcGvlOtsXjrUoxyeVDKJQkaFqh
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['page'] =WBYARcGvlOtsXjrUoxyeVDKJQkaFfN(WBYARcGvlOtsXjrUoxyeVDKJQkaFLi+1)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['genreCode']=WBYARcGvlOtsXjrUoxyeVDKJQkaFgS 
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi='[B]%s >>[/B]'%'다음 페이지'
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgL=WBYARcGvlOtsXjrUoxyeVDKJQkaFfN(WBYARcGvlOtsXjrUoxyeVDKJQkaFLi+1)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel=WBYARcGvlOtsXjrUoxyeVDKJQkaFgL,img=WBYARcGvlOtsXjrUoxyeVDKJQkaFqN,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp)
  xbmcplugin.setContent(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,cacheToDisc=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP)
 def dp_Episode_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFgI=WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('programcode')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLi =WBYARcGvlOtsXjrUoxyeVDKJQkaFfi(WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('page'))
  WBYARcGvlOtsXjrUoxyeVDKJQkaFgz,WBYARcGvlOtsXjrUoxyeVDKJQkaFLP,WBYARcGvlOtsXjrUoxyeVDKJQkaFgd=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.GetEpisodeList(WBYARcGvlOtsXjrUoxyeVDKJQkaFgI,WBYARcGvlOtsXjrUoxyeVDKJQkaFLi,orderby=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_winEpisodeOrderby())
  for WBYARcGvlOtsXjrUoxyeVDKJQkaFgN in WBYARcGvlOtsXjrUoxyeVDKJQkaFgz:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi =WBYARcGvlOtsXjrUoxyeVDKJQkaFgN.get('title')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgL =WBYARcGvlOtsXjrUoxyeVDKJQkaFgN.get('subtitle')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLz =WBYARcGvlOtsXjrUoxyeVDKJQkaFgN.get('thumbnail')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLd =WBYARcGvlOtsXjrUoxyeVDKJQkaFgN.get('synopsis')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgp=WBYARcGvlOtsXjrUoxyeVDKJQkaFgN.get('info_title')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgw =WBYARcGvlOtsXjrUoxyeVDKJQkaFgN.get('aired')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgT =WBYARcGvlOtsXjrUoxyeVDKJQkaFgN.get('studio')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgu =WBYARcGvlOtsXjrUoxyeVDKJQkaFgN.get('frequency')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgq={'mediatype':'episode','title':WBYARcGvlOtsXjrUoxyeVDKJQkaFgp,'aired':WBYARcGvlOtsXjrUoxyeVDKJQkaFgw,'studio':WBYARcGvlOtsXjrUoxyeVDKJQkaFgT,'episode':WBYARcGvlOtsXjrUoxyeVDKJQkaFgu,'plot':WBYARcGvlOtsXjrUoxyeVDKJQkaFLd}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':'VOD','mediacode':WBYARcGvlOtsXjrUoxyeVDKJQkaFgN.get('episode'),'stype':'vod','programcode':WBYARcGvlOtsXjrUoxyeVDKJQkaFgI,'title':WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,'thumbnail':WBYARcGvlOtsXjrUoxyeVDKJQkaFLz}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel=WBYARcGvlOtsXjrUoxyeVDKJQkaFgL,img=WBYARcGvlOtsXjrUoxyeVDKJQkaFLz,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFgq,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLi==1:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgq={'plot':'정렬순서를 변경합니다.'}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['mode'] ='ORDER_BY' 
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_winEpisodeOrderby()=='desc':
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqi='정렬순서변경 : 최신화부터 -> 1회부터'
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['orderby']='asc'
   else:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqi='정렬순서변경 : 1회부터 -> 최신화부터'
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['orderby']='desc'
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel='',img=WBYARcGvlOtsXjrUoxyeVDKJQkaFqN,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFgq,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp,isLink=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLP:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['mode'] ='EPISODE' 
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['programcode']=WBYARcGvlOtsXjrUoxyeVDKJQkaFgI
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['page'] =WBYARcGvlOtsXjrUoxyeVDKJQkaFfN(WBYARcGvlOtsXjrUoxyeVDKJQkaFLi+1)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi='[B]%s >>[/B]'%'다음 페이지'
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgL=WBYARcGvlOtsXjrUoxyeVDKJQkaFfN(WBYARcGvlOtsXjrUoxyeVDKJQkaFLi+1)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel=WBYARcGvlOtsXjrUoxyeVDKJQkaFgL,img=WBYARcGvlOtsXjrUoxyeVDKJQkaFqN,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp)
  xbmcplugin.setContent(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,'episodes')
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFfd(WBYARcGvlOtsXjrUoxyeVDKJQkaFgz)>0:xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,cacheToDisc=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn)
 def dp_setEpOrderby(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqh =WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('orderby')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.set_winEpisodeOrderby(WBYARcGvlOtsXjrUoxyeVDKJQkaFqh)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFgM =WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('stype')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqh =WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('orderby')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLi=WBYARcGvlOtsXjrUoxyeVDKJQkaFfi(WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('page'))
  WBYARcGvlOtsXjrUoxyeVDKJQkaFgE,WBYARcGvlOtsXjrUoxyeVDKJQkaFLP=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.GetMovieList(WBYARcGvlOtsXjrUoxyeVDKJQkaFgM,WBYARcGvlOtsXjrUoxyeVDKJQkaFqh,WBYARcGvlOtsXjrUoxyeVDKJQkaFLi)
  for WBYARcGvlOtsXjrUoxyeVDKJQkaFMm in WBYARcGvlOtsXjrUoxyeVDKJQkaFgE:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi =WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('title')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLz =WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('thumbnail')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLd =WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('synopsis')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgp =WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('info_title')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLu =WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('year')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLp =WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('cast')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLw =WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('director')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLT =WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('info_genre')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFMq =WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('duration')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgm =WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('premiered')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgT =WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('studio')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLE =WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('mpaa')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgq={'mediatype':'movie','title':WBYARcGvlOtsXjrUoxyeVDKJQkaFgp,'year':WBYARcGvlOtsXjrUoxyeVDKJQkaFLu,'cast':WBYARcGvlOtsXjrUoxyeVDKJQkaFLp,'director':WBYARcGvlOtsXjrUoxyeVDKJQkaFLw,'genre':WBYARcGvlOtsXjrUoxyeVDKJQkaFLT,'duration':WBYARcGvlOtsXjrUoxyeVDKJQkaFMq,'premiered':WBYARcGvlOtsXjrUoxyeVDKJQkaFgm,'studio':WBYARcGvlOtsXjrUoxyeVDKJQkaFgT,'mpaa':WBYARcGvlOtsXjrUoxyeVDKJQkaFLE,'plot':WBYARcGvlOtsXjrUoxyeVDKJQkaFLd}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':'MOVIE','mediacode':WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('moviecode'),'stype':'movie','title':WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,'thumbnail':WBYARcGvlOtsXjrUoxyeVDKJQkaFLz}
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_settings_makebookmark():
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgh={'videoid':WBYARcGvlOtsXjrUoxyeVDKJQkaFMm.get('moviecode'),'vidtype':'movie','vtitle':WBYARcGvlOtsXjrUoxyeVDKJQkaFgp,'vsubtitle':'',}
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgb=json.dumps(WBYARcGvlOtsXjrUoxyeVDKJQkaFgh)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgb=urllib.parse.quote(WBYARcGvlOtsXjrUoxyeVDKJQkaFgb)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgi='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFgb)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgn=[('(통합) 찜 영상에 추가',WBYARcGvlOtsXjrUoxyeVDKJQkaFgi)]
   else:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgn=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel='',img=WBYARcGvlOtsXjrUoxyeVDKJQkaFLz,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFgq,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp,ContextMenu=WBYARcGvlOtsXjrUoxyeVDKJQkaFgn)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLP:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['mode'] ='MOVIE_SUB' 
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['orderby']=WBYARcGvlOtsXjrUoxyeVDKJQkaFqh
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['stype'] =WBYARcGvlOtsXjrUoxyeVDKJQkaFgM
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['page'] =WBYARcGvlOtsXjrUoxyeVDKJQkaFfN(WBYARcGvlOtsXjrUoxyeVDKJQkaFLi+1)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi='[B]%s >>[/B]'%'다음 페이지'
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgL=WBYARcGvlOtsXjrUoxyeVDKJQkaFfN(WBYARcGvlOtsXjrUoxyeVDKJQkaFLi+1)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel=WBYARcGvlOtsXjrUoxyeVDKJQkaFgL,img=WBYARcGvlOtsXjrUoxyeVDKJQkaFqN,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp)
  xbmcplugin.setContent(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,'movies')
  xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,cacheToDisc=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP)
 def dp_Set_Bookmark(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFML=urllib.parse.unquote(WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('bm_param'))
  WBYARcGvlOtsXjrUoxyeVDKJQkaFML=json.loads(WBYARcGvlOtsXjrUoxyeVDKJQkaFML)
  WBYARcGvlOtsXjrUoxyeVDKJQkaFMg =WBYARcGvlOtsXjrUoxyeVDKJQkaFML.get('videoid')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFMS =WBYARcGvlOtsXjrUoxyeVDKJQkaFML.get('vidtype')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFMH =WBYARcGvlOtsXjrUoxyeVDKJQkaFML.get('vtitle')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFMf =WBYARcGvlOtsXjrUoxyeVDKJQkaFML.get('vsubtitle')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmd=xbmcgui.Dialog()
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLM=WBYARcGvlOtsXjrUoxyeVDKJQkaFmd.yesno(__language__(30913).encode('utf8'),WBYARcGvlOtsXjrUoxyeVDKJQkaFMH+' \n\n'+__language__(30914))
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLM==WBYARcGvlOtsXjrUoxyeVDKJQkaFfP:return
  WBYARcGvlOtsXjrUoxyeVDKJQkaFMC=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.GetBookmarkInfo(WBYARcGvlOtsXjrUoxyeVDKJQkaFMg,WBYARcGvlOtsXjrUoxyeVDKJQkaFMS)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFMf!='':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFMC['saveinfo']['subtitle']=WBYARcGvlOtsXjrUoxyeVDKJQkaFMf 
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFMS=='tvshow':WBYARcGvlOtsXjrUoxyeVDKJQkaFMC['saveinfo']['infoLabels']['studio']=WBYARcGvlOtsXjrUoxyeVDKJQkaFMf 
  WBYARcGvlOtsXjrUoxyeVDKJQkaFMh=json.dumps(WBYARcGvlOtsXjrUoxyeVDKJQkaFMC)
  WBYARcGvlOtsXjrUoxyeVDKJQkaFMh=urllib.parse.quote(WBYARcGvlOtsXjrUoxyeVDKJQkaFMh)
  WBYARcGvlOtsXjrUoxyeVDKJQkaFgi ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFMh)
  xbmc.executebuiltin(WBYARcGvlOtsXjrUoxyeVDKJQkaFgi)
 def dp_Search_Group(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  if 'search_key' in WBYARcGvlOtsXjrUoxyeVDKJQkaFLb:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFMb=WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('search_key')
  else:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFMb=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not WBYARcGvlOtsXjrUoxyeVDKJQkaFMb:
    return
  for WBYARcGvlOtsXjrUoxyeVDKJQkaFLh in WBYARcGvlOtsXjrUoxyeVDKJQkaFmS:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFMi =WBYARcGvlOtsXjrUoxyeVDKJQkaFLh.get('mode')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLf=WBYARcGvlOtsXjrUoxyeVDKJQkaFLh.get('stype')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi=WBYARcGvlOtsXjrUoxyeVDKJQkaFLh.get('title')
   (WBYARcGvlOtsXjrUoxyeVDKJQkaFMn,WBYARcGvlOtsXjrUoxyeVDKJQkaFLP)=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.GetSearchList(WBYARcGvlOtsXjrUoxyeVDKJQkaFMb,1,WBYARcGvlOtsXjrUoxyeVDKJQkaFLf)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFMP={'plot':'검색어 : '+WBYARcGvlOtsXjrUoxyeVDKJQkaFMb+'\n\n'+WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.Search_FreeList(WBYARcGvlOtsXjrUoxyeVDKJQkaFMn)}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':WBYARcGvlOtsXjrUoxyeVDKJQkaFMi,'stype':WBYARcGvlOtsXjrUoxyeVDKJQkaFLf,'search_key':WBYARcGvlOtsXjrUoxyeVDKJQkaFMb,'page':'1',}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel='',img='',infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFMP,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFfd(WBYARcGvlOtsXjrUoxyeVDKJQkaFmS)>0:xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,cacheToDisc=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn)
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.Save_Searched_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFMb)
 def Search_FreeList(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFME):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFMI=''
  WBYARcGvlOtsXjrUoxyeVDKJQkaFMz=7
  try:
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFfd(WBYARcGvlOtsXjrUoxyeVDKJQkaFME)==0:return '검색결과 없음'
   for i in WBYARcGvlOtsXjrUoxyeVDKJQkaFfp(WBYARcGvlOtsXjrUoxyeVDKJQkaFfd(WBYARcGvlOtsXjrUoxyeVDKJQkaFME)):
    if i>=WBYARcGvlOtsXjrUoxyeVDKJQkaFMz:
     WBYARcGvlOtsXjrUoxyeVDKJQkaFMI=WBYARcGvlOtsXjrUoxyeVDKJQkaFMI+'...'
     break
    WBYARcGvlOtsXjrUoxyeVDKJQkaFMI=WBYARcGvlOtsXjrUoxyeVDKJQkaFMI+WBYARcGvlOtsXjrUoxyeVDKJQkaFME[i]['title']+'\n'
  except:
   return ''
  return WBYARcGvlOtsXjrUoxyeVDKJQkaFMI
 def dp_Search_History(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFMd=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.Load_List_File('search')
  for WBYARcGvlOtsXjrUoxyeVDKJQkaFMN in WBYARcGvlOtsXjrUoxyeVDKJQkaFMd:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFMp=WBYARcGvlOtsXjrUoxyeVDKJQkaFfz(urllib.parse.parse_qsl(WBYARcGvlOtsXjrUoxyeVDKJQkaFMN))
   WBYARcGvlOtsXjrUoxyeVDKJQkaFMw=WBYARcGvlOtsXjrUoxyeVDKJQkaFMp.get('skey').strip()
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':'SEARCH_GROUP','search_key':WBYARcGvlOtsXjrUoxyeVDKJQkaFMw,}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFMT={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':WBYARcGvlOtsXjrUoxyeVDKJQkaFMw,'vType':'-',}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFMu=urllib.parse.urlencode(WBYARcGvlOtsXjrUoxyeVDKJQkaFMT)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgn=[('선택된 검색어 ( %s ) 삭제'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFMw),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFMu))]
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFMw,sublabel='',img=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp,ContextMenu=WBYARcGvlOtsXjrUoxyeVDKJQkaFgn)
  WBYARcGvlOtsXjrUoxyeVDKJQkaFgq={'plot':'검색목록 전체를 삭제합니다.'}
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqi='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel='',img=WBYARcGvlOtsXjrUoxyeVDKJQkaFqN,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFgq,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp,isLink=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn)
  xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,cacheToDisc=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP)
 def dp_Search_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLi =WBYARcGvlOtsXjrUoxyeVDKJQkaFfi(WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('page'))
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLf =WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('stype')
  if 'search_key' in WBYARcGvlOtsXjrUoxyeVDKJQkaFLb:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFMb=WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('search_key')
  else:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFMb=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not WBYARcGvlOtsXjrUoxyeVDKJQkaFMb:
    xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle)
    return
  WBYARcGvlOtsXjrUoxyeVDKJQkaFMn,WBYARcGvlOtsXjrUoxyeVDKJQkaFLP=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.GetSearchList(WBYARcGvlOtsXjrUoxyeVDKJQkaFMb,WBYARcGvlOtsXjrUoxyeVDKJQkaFLi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLf)
  for WBYARcGvlOtsXjrUoxyeVDKJQkaFME in WBYARcGvlOtsXjrUoxyeVDKJQkaFMn:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi =WBYARcGvlOtsXjrUoxyeVDKJQkaFME.get('title')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLz =WBYARcGvlOtsXjrUoxyeVDKJQkaFME.get('thumbnail')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLd =WBYARcGvlOtsXjrUoxyeVDKJQkaFME.get('synopsis')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSm =WBYARcGvlOtsXjrUoxyeVDKJQkaFME.get('program')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLp =WBYARcGvlOtsXjrUoxyeVDKJQkaFME.get('cast')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLw =WBYARcGvlOtsXjrUoxyeVDKJQkaFME.get('director')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLT=WBYARcGvlOtsXjrUoxyeVDKJQkaFME.get('info_genre')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFMq =WBYARcGvlOtsXjrUoxyeVDKJQkaFME.get('duration')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLE =WBYARcGvlOtsXjrUoxyeVDKJQkaFME.get('mpaa')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLu =WBYARcGvlOtsXjrUoxyeVDKJQkaFME.get('year')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgw =WBYARcGvlOtsXjrUoxyeVDKJQkaFME.get('aired')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgq={'mediatype':'tvshow' if WBYARcGvlOtsXjrUoxyeVDKJQkaFLf=='vod' else 'movie','title':WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,'cast':WBYARcGvlOtsXjrUoxyeVDKJQkaFLp,'director':WBYARcGvlOtsXjrUoxyeVDKJQkaFLw,'genre':WBYARcGvlOtsXjrUoxyeVDKJQkaFLT,'duration':WBYARcGvlOtsXjrUoxyeVDKJQkaFMq,'mpaa':WBYARcGvlOtsXjrUoxyeVDKJQkaFLE,'year':WBYARcGvlOtsXjrUoxyeVDKJQkaFLu,'aired':WBYARcGvlOtsXjrUoxyeVDKJQkaFgw,'plot':'%s\n\n%s'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLd)}
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFLf=='vod':
    WBYARcGvlOtsXjrUoxyeVDKJQkaFMg=WBYARcGvlOtsXjrUoxyeVDKJQkaFME.get('program')
    WBYARcGvlOtsXjrUoxyeVDKJQkaFMS='tvshow'
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':'EPISODE','programcode':WBYARcGvlOtsXjrUoxyeVDKJQkaFMg,'page':'1',}
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqw=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn
   else:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFMg=WBYARcGvlOtsXjrUoxyeVDKJQkaFME.get('movie')
    WBYARcGvlOtsXjrUoxyeVDKJQkaFMS='movie'
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':'MOVIE','mediacode':WBYARcGvlOtsXjrUoxyeVDKJQkaFMg,'stype':'movie','title':WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,'thumbnail':WBYARcGvlOtsXjrUoxyeVDKJQkaFLz,}
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqw=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_settings_makebookmark():
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgh={'videoid':WBYARcGvlOtsXjrUoxyeVDKJQkaFMg,'vidtype':WBYARcGvlOtsXjrUoxyeVDKJQkaFMS,'vtitle':WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,'vsubtitle':'',}
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgb=json.dumps(WBYARcGvlOtsXjrUoxyeVDKJQkaFgh)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgb=urllib.parse.quote(WBYARcGvlOtsXjrUoxyeVDKJQkaFgb)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgi='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFgb)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgn=[('(통합) 찜 영상에 추가',WBYARcGvlOtsXjrUoxyeVDKJQkaFgi)]
   else:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgn=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel='',img=WBYARcGvlOtsXjrUoxyeVDKJQkaFLz,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFgq,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFqw,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp,isLink=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP,ContextMenu=WBYARcGvlOtsXjrUoxyeVDKJQkaFgn)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLP:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['mode'] ='SEARCH' 
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['search_key']=WBYARcGvlOtsXjrUoxyeVDKJQkaFMb
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp['page'] =WBYARcGvlOtsXjrUoxyeVDKJQkaFfN(WBYARcGvlOtsXjrUoxyeVDKJQkaFLi+1)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi='[B]%s >>[/B]'%'다음 페이지'
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgL=WBYARcGvlOtsXjrUoxyeVDKJQkaFfN(WBYARcGvlOtsXjrUoxyeVDKJQkaFLi+1)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel=WBYARcGvlOtsXjrUoxyeVDKJQkaFgL,img=WBYARcGvlOtsXjrUoxyeVDKJQkaFqN,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLf=='movie':xbmcplugin.setContent(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,'movies')
  else:xbmcplugin.setContent(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,cacheToDisc=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP)
 def dp_History_Remove(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFSq=WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('delType')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFSL =WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('sKey')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFSg =WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('vType')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmd=xbmcgui.Dialog()
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFSq=='SEARCH_ALL':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLM=WBYARcGvlOtsXjrUoxyeVDKJQkaFmd.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFSq=='SEARCH_ONE':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLM=WBYARcGvlOtsXjrUoxyeVDKJQkaFmd.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFSq=='WATCH_ALL':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLM=WBYARcGvlOtsXjrUoxyeVDKJQkaFmd.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFSq=='WATCH_ONE':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFLM=WBYARcGvlOtsXjrUoxyeVDKJQkaFmd.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLM==WBYARcGvlOtsXjrUoxyeVDKJQkaFfP:sys.exit()
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFSq=='SEARCH_ALL':
   if os.path.isfile(WBYARcGvlOtsXjrUoxyeVDKJQkaFmb):os.remove(WBYARcGvlOtsXjrUoxyeVDKJQkaFmb)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFSq=='SEARCH_ONE':
   try:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFSM=WBYARcGvlOtsXjrUoxyeVDKJQkaFmb
    WBYARcGvlOtsXjrUoxyeVDKJQkaFSH=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.Load_List_File('search') 
    fp=WBYARcGvlOtsXjrUoxyeVDKJQkaFfw(WBYARcGvlOtsXjrUoxyeVDKJQkaFSM,'w',-1,'utf-8')
    for WBYARcGvlOtsXjrUoxyeVDKJQkaFSf in WBYARcGvlOtsXjrUoxyeVDKJQkaFSH:
     WBYARcGvlOtsXjrUoxyeVDKJQkaFSC=WBYARcGvlOtsXjrUoxyeVDKJQkaFfz(urllib.parse.parse_qsl(WBYARcGvlOtsXjrUoxyeVDKJQkaFSf))
     WBYARcGvlOtsXjrUoxyeVDKJQkaFSh=WBYARcGvlOtsXjrUoxyeVDKJQkaFSC.get('skey').strip()
     if WBYARcGvlOtsXjrUoxyeVDKJQkaFSL!=WBYARcGvlOtsXjrUoxyeVDKJQkaFSh:
      fp.write(WBYARcGvlOtsXjrUoxyeVDKJQkaFSf)
    fp.close()
   except:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFfb
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFSq=='WATCH_ALL':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WBYARcGvlOtsXjrUoxyeVDKJQkaFSg))
   if os.path.isfile(WBYARcGvlOtsXjrUoxyeVDKJQkaFSM):os.remove(WBYARcGvlOtsXjrUoxyeVDKJQkaFSM)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFSq=='WATCH_ONE':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WBYARcGvlOtsXjrUoxyeVDKJQkaFSg))
   try:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFSH=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.Load_List_File(WBYARcGvlOtsXjrUoxyeVDKJQkaFSg) 
    fp=WBYARcGvlOtsXjrUoxyeVDKJQkaFfw(WBYARcGvlOtsXjrUoxyeVDKJQkaFSM,'w',-1,'utf-8')
    for WBYARcGvlOtsXjrUoxyeVDKJQkaFSf in WBYARcGvlOtsXjrUoxyeVDKJQkaFSH:
     WBYARcGvlOtsXjrUoxyeVDKJQkaFSC=WBYARcGvlOtsXjrUoxyeVDKJQkaFfz(urllib.parse.parse_qsl(WBYARcGvlOtsXjrUoxyeVDKJQkaFSf))
     WBYARcGvlOtsXjrUoxyeVDKJQkaFSh=WBYARcGvlOtsXjrUoxyeVDKJQkaFSC.get('code').strip()
     if WBYARcGvlOtsXjrUoxyeVDKJQkaFSL!=WBYARcGvlOtsXjrUoxyeVDKJQkaFSh:
      fp.write(WBYARcGvlOtsXjrUoxyeVDKJQkaFSf)
    fp.close()
   except:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFfb
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLf): 
  try:
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFLf=='search':
    WBYARcGvlOtsXjrUoxyeVDKJQkaFSM=WBYARcGvlOtsXjrUoxyeVDKJQkaFmb
   elif WBYARcGvlOtsXjrUoxyeVDKJQkaFLf in['vod','movie']:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFSM=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WBYARcGvlOtsXjrUoxyeVDKJQkaFLf))
   else:
    return[]
   fp=WBYARcGvlOtsXjrUoxyeVDKJQkaFfw(WBYARcGvlOtsXjrUoxyeVDKJQkaFSM,'r',-1,'utf-8')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSb=fp.readlines()
   fp.close()
  except:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSb=[]
  return WBYARcGvlOtsXjrUoxyeVDKJQkaFSb
 def Save_Watched_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLf,WBYARcGvlOtsXjrUoxyeVDKJQkaFmI):
  try:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSi=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WBYARcGvlOtsXjrUoxyeVDKJQkaFLf))
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSH=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.Load_List_File(WBYARcGvlOtsXjrUoxyeVDKJQkaFLf) 
   fp=WBYARcGvlOtsXjrUoxyeVDKJQkaFfw(WBYARcGvlOtsXjrUoxyeVDKJQkaFSi,'w',-1,'utf-8')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSn=urllib.parse.urlencode(WBYARcGvlOtsXjrUoxyeVDKJQkaFmI)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSn=WBYARcGvlOtsXjrUoxyeVDKJQkaFSn+'\n'
   fp.write(WBYARcGvlOtsXjrUoxyeVDKJQkaFSn)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSP=0
   for WBYARcGvlOtsXjrUoxyeVDKJQkaFSf in WBYARcGvlOtsXjrUoxyeVDKJQkaFSH:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFSC=WBYARcGvlOtsXjrUoxyeVDKJQkaFfz(urllib.parse.parse_qsl(WBYARcGvlOtsXjrUoxyeVDKJQkaFSf))
    WBYARcGvlOtsXjrUoxyeVDKJQkaFSI=WBYARcGvlOtsXjrUoxyeVDKJQkaFmI.get('code').strip()
    WBYARcGvlOtsXjrUoxyeVDKJQkaFSz=WBYARcGvlOtsXjrUoxyeVDKJQkaFSC.get('code').strip()
    if WBYARcGvlOtsXjrUoxyeVDKJQkaFLf=='vod' and WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_settings_direct_replay()==WBYARcGvlOtsXjrUoxyeVDKJQkaFfn:
     WBYARcGvlOtsXjrUoxyeVDKJQkaFSI=WBYARcGvlOtsXjrUoxyeVDKJQkaFmI.get('videoid').strip()
     WBYARcGvlOtsXjrUoxyeVDKJQkaFSz=WBYARcGvlOtsXjrUoxyeVDKJQkaFSC.get('videoid').strip()if WBYARcGvlOtsXjrUoxyeVDKJQkaFSz!=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb else '-'
    if WBYARcGvlOtsXjrUoxyeVDKJQkaFSI!=WBYARcGvlOtsXjrUoxyeVDKJQkaFSz:
     fp.write(WBYARcGvlOtsXjrUoxyeVDKJQkaFSf)
     WBYARcGvlOtsXjrUoxyeVDKJQkaFSP+=1
     if WBYARcGvlOtsXjrUoxyeVDKJQkaFSP>=50:break
   fp.close()
  except:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFfb
 def dp_Watch_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLf =WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('stype')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFqf=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_settings_direct_replay()
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLf=='-':
   for WBYARcGvlOtsXjrUoxyeVDKJQkaFLh in WBYARcGvlOtsXjrUoxyeVDKJQkaFmM:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqi=WBYARcGvlOtsXjrUoxyeVDKJQkaFLh.get('title')
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':WBYARcGvlOtsXjrUoxyeVDKJQkaFLh.get('mode'),'stype':WBYARcGvlOtsXjrUoxyeVDKJQkaFLh.get('stype')}
    WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel='',img='',infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFfb,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp)
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFfd(WBYARcGvlOtsXjrUoxyeVDKJQkaFmM)>0:xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle)
  else:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSd=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.Load_List_File(WBYARcGvlOtsXjrUoxyeVDKJQkaFLf)
   for WBYARcGvlOtsXjrUoxyeVDKJQkaFSN in WBYARcGvlOtsXjrUoxyeVDKJQkaFSd:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFMp=WBYARcGvlOtsXjrUoxyeVDKJQkaFfz(urllib.parse.parse_qsl(WBYARcGvlOtsXjrUoxyeVDKJQkaFSN))
    WBYARcGvlOtsXjrUoxyeVDKJQkaFSp =WBYARcGvlOtsXjrUoxyeVDKJQkaFMp.get('code').strip()
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqi =WBYARcGvlOtsXjrUoxyeVDKJQkaFMp.get('title').strip()
    WBYARcGvlOtsXjrUoxyeVDKJQkaFLz=WBYARcGvlOtsXjrUoxyeVDKJQkaFMp.get('img').strip()
    WBYARcGvlOtsXjrUoxyeVDKJQkaFMg =WBYARcGvlOtsXjrUoxyeVDKJQkaFMp.get('videoid').strip()
    try:
     WBYARcGvlOtsXjrUoxyeVDKJQkaFLz=WBYARcGvlOtsXjrUoxyeVDKJQkaFLz.replace('\'','\"')
     WBYARcGvlOtsXjrUoxyeVDKJQkaFLz=json.loads(WBYARcGvlOtsXjrUoxyeVDKJQkaFLz)
    except:
     WBYARcGvlOtsXjrUoxyeVDKJQkaFfb
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgq={}
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgq['plot']=WBYARcGvlOtsXjrUoxyeVDKJQkaFqi
    if WBYARcGvlOtsXjrUoxyeVDKJQkaFLf=='vod':
     if WBYARcGvlOtsXjrUoxyeVDKJQkaFqf==WBYARcGvlOtsXjrUoxyeVDKJQkaFfP or WBYARcGvlOtsXjrUoxyeVDKJQkaFMg==WBYARcGvlOtsXjrUoxyeVDKJQkaFfb:
      WBYARcGvlOtsXjrUoxyeVDKJQkaFgq['mediatype']='tvshow'
      WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':'EPISODE','programcode':WBYARcGvlOtsXjrUoxyeVDKJQkaFSp,'page':'1'}
      WBYARcGvlOtsXjrUoxyeVDKJQkaFqw=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn
     else:
      WBYARcGvlOtsXjrUoxyeVDKJQkaFgq['mediatype']='episode'
      WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':'VOD','mediacode':WBYARcGvlOtsXjrUoxyeVDKJQkaFMg,'stype':'vod','programcode':WBYARcGvlOtsXjrUoxyeVDKJQkaFSp,'title':WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,'thumbnail':WBYARcGvlOtsXjrUoxyeVDKJQkaFLz}
      WBYARcGvlOtsXjrUoxyeVDKJQkaFqw=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
    else:
     WBYARcGvlOtsXjrUoxyeVDKJQkaFgq['mediatype']='movie'
     WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':'MOVIE','mediacode':WBYARcGvlOtsXjrUoxyeVDKJQkaFSp,'stype':'movie','title':WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,'thumbnail':WBYARcGvlOtsXjrUoxyeVDKJQkaFLz}
     WBYARcGvlOtsXjrUoxyeVDKJQkaFqw=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
    WBYARcGvlOtsXjrUoxyeVDKJQkaFMT={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':WBYARcGvlOtsXjrUoxyeVDKJQkaFSp,'vType':WBYARcGvlOtsXjrUoxyeVDKJQkaFLf,}
    WBYARcGvlOtsXjrUoxyeVDKJQkaFMu=urllib.parse.urlencode(WBYARcGvlOtsXjrUoxyeVDKJQkaFMT)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFgn=[('선택된 시청이력 ( %s ) 삭제'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFMu))]
    WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel='',img=WBYARcGvlOtsXjrUoxyeVDKJQkaFLz,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFgq,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFqw,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp,ContextMenu=WBYARcGvlOtsXjrUoxyeVDKJQkaFgn)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgq={'plot':'시청목록을 삭제합니다.'}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':WBYARcGvlOtsXjrUoxyeVDKJQkaFLf,}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqN=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel='',img=WBYARcGvlOtsXjrUoxyeVDKJQkaFqN,infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFgq,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp,isLink=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn)
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFLf=='movie':xbmcplugin.setContent(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,'movies')
   else:xbmcplugin.setContent(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,cacheToDisc=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP)
 def Save_Searched_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFMb):
  try:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSw=WBYARcGvlOtsXjrUoxyeVDKJQkaFmb
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSH=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.Load_List_File('search') 
   WBYARcGvlOtsXjrUoxyeVDKJQkaFST={'skey':WBYARcGvlOtsXjrUoxyeVDKJQkaFMb.strip()}
   fp=WBYARcGvlOtsXjrUoxyeVDKJQkaFfw(WBYARcGvlOtsXjrUoxyeVDKJQkaFSw,'w',-1,'utf-8')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSn=urllib.parse.urlencode(WBYARcGvlOtsXjrUoxyeVDKJQkaFST)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSn=WBYARcGvlOtsXjrUoxyeVDKJQkaFSn+'\n'
   fp.write(WBYARcGvlOtsXjrUoxyeVDKJQkaFSn)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFSP=0
   for WBYARcGvlOtsXjrUoxyeVDKJQkaFSf in WBYARcGvlOtsXjrUoxyeVDKJQkaFSH:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFSC=WBYARcGvlOtsXjrUoxyeVDKJQkaFfz(urllib.parse.parse_qsl(WBYARcGvlOtsXjrUoxyeVDKJQkaFSf))
    WBYARcGvlOtsXjrUoxyeVDKJQkaFSI=WBYARcGvlOtsXjrUoxyeVDKJQkaFST.get('skey').strip()
    WBYARcGvlOtsXjrUoxyeVDKJQkaFSz=WBYARcGvlOtsXjrUoxyeVDKJQkaFSC.get('skey').strip()
    if WBYARcGvlOtsXjrUoxyeVDKJQkaFSI!=WBYARcGvlOtsXjrUoxyeVDKJQkaFSz:
     fp.write(WBYARcGvlOtsXjrUoxyeVDKJQkaFSf)
     WBYARcGvlOtsXjrUoxyeVDKJQkaFSP+=1
     if WBYARcGvlOtsXjrUoxyeVDKJQkaFSP>=50:break
   fp.close()
  except:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFfb
 def play_VIDEO(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFSu =WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('mediacode')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLf =WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('stype')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFSE =WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('pvrmode')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFHm=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_selQuality(WBYARcGvlOtsXjrUoxyeVDKJQkaFLf)
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFSu,WBYARcGvlOtsXjrUoxyeVDKJQkaFfN(WBYARcGvlOtsXjrUoxyeVDKJQkaFHm),WBYARcGvlOtsXjrUoxyeVDKJQkaFLf,WBYARcGvlOtsXjrUoxyeVDKJQkaFSE))
  WBYARcGvlOtsXjrUoxyeVDKJQkaFHq=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.GetBroadURL(WBYARcGvlOtsXjrUoxyeVDKJQkaFSu,WBYARcGvlOtsXjrUoxyeVDKJQkaFHm,WBYARcGvlOtsXjrUoxyeVDKJQkaFLf,WBYARcGvlOtsXjrUoxyeVDKJQkaFSE)
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.addon_log('qt, stype, url : %s - %s - %s'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFfN(WBYARcGvlOtsXjrUoxyeVDKJQkaFHm),WBYARcGvlOtsXjrUoxyeVDKJQkaFLf,WBYARcGvlOtsXjrUoxyeVDKJQkaFHq['streaming_url']))
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFHq['streaming_url']=='':
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFHq['error_msg']=='':
    WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.addon_noti(__language__(30908).encode('utf8'))
   else:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.addon_noti(WBYARcGvlOtsXjrUoxyeVDKJQkaFHq['error_msg'].encode('utf8'))
   return
  WBYARcGvlOtsXjrUoxyeVDKJQkaFHL='user-agent={}'.format(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.USER_AGENT)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFHq['watermark'] !='':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHL='{}&x-tving-param1={}&x-tving-param2={}'.format(WBYARcGvlOtsXjrUoxyeVDKJQkaFHL,WBYARcGvlOtsXjrUoxyeVDKJQkaFHq['watermarkKey'],WBYARcGvlOtsXjrUoxyeVDKJQkaFHq['watermark'])
  WBYARcGvlOtsXjrUoxyeVDKJQkaFHg =WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
  WBYARcGvlOtsXjrUoxyeVDKJQkaFHM =WBYARcGvlOtsXjrUoxyeVDKJQkaFHq['streaming_url'].find('Policy=')
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFHM!=-1:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHS =WBYARcGvlOtsXjrUoxyeVDKJQkaFHq['streaming_url'].split('?')[0]
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHf=WBYARcGvlOtsXjrUoxyeVDKJQkaFfz(urllib.parse.parse_qsl(urllib.parse.urlsplit(WBYARcGvlOtsXjrUoxyeVDKJQkaFHq['streaming_url']).query))
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHC='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFHf['Policy'],WBYARcGvlOtsXjrUoxyeVDKJQkaFHf['Signature'],WBYARcGvlOtsXjrUoxyeVDKJQkaFHf['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in WBYARcGvlOtsXjrUoxyeVDKJQkaFHS:
    WBYARcGvlOtsXjrUoxyeVDKJQkaFHg=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn
    WBYARcGvlOtsXjrUoxyeVDKJQkaFHh =WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFHb=WBYARcGvlOtsXjrUoxyeVDKJQkaFHh.strftime('%Y-%m-%d-%H:%M:%S')
    if WBYARcGvlOtsXjrUoxyeVDKJQkaFfi(WBYARcGvlOtsXjrUoxyeVDKJQkaFHb.replace('-','').replace(':',''))<WBYARcGvlOtsXjrUoxyeVDKJQkaFfi(WBYARcGvlOtsXjrUoxyeVDKJQkaFHf['end'].replace('-','').replace(':','')):
     WBYARcGvlOtsXjrUoxyeVDKJQkaFHf['end']=WBYARcGvlOtsXjrUoxyeVDKJQkaFHb
     WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.addon_noti(__language__(30915).encode('utf8'))
    WBYARcGvlOtsXjrUoxyeVDKJQkaFHS ='%s?%s'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFHS,urllib.parse.urlencode(WBYARcGvlOtsXjrUoxyeVDKJQkaFHf,doseq=WBYARcGvlOtsXjrUoxyeVDKJQkaFfn))
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHi='{}|{}&Cookie={}'.format(WBYARcGvlOtsXjrUoxyeVDKJQkaFHS,WBYARcGvlOtsXjrUoxyeVDKJQkaFHL,WBYARcGvlOtsXjrUoxyeVDKJQkaFHC)
  else:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHi=WBYARcGvlOtsXjrUoxyeVDKJQkaFHq['streaming_url']+'|'+WBYARcGvlOtsXjrUoxyeVDKJQkaFHL
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.addon_log(WBYARcGvlOtsXjrUoxyeVDKJQkaFHi)
  WBYARcGvlOtsXjrUoxyeVDKJQkaFHn=xbmcgui.ListItem(path=WBYARcGvlOtsXjrUoxyeVDKJQkaFHi)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFHq['drm_license']!='':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHP=WBYARcGvlOtsXjrUoxyeVDKJQkaFHq['drm_license']
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHI ='https://cj.drmkeyserver.com/widevine_license'
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHz ='mpd'
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHd ='com.widevine.alpha'
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHN =inputstreamhelper.Helper(WBYARcGvlOtsXjrUoxyeVDKJQkaFHz,drm='widevine')
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFHN.check_inputstream():
    WBYARcGvlOtsXjrUoxyeVDKJQkaFHp={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.USER_AGENT,'AcquireLicenseAssertion':WBYARcGvlOtsXjrUoxyeVDKJQkaFHP,'Host':'cj.drmkeyserver.com',}
    WBYARcGvlOtsXjrUoxyeVDKJQkaFHw=WBYARcGvlOtsXjrUoxyeVDKJQkaFHI+'|'+urllib.parse.urlencode(WBYARcGvlOtsXjrUoxyeVDKJQkaFHp)+'|R{SSM}|'
    WBYARcGvlOtsXjrUoxyeVDKJQkaFHn.setProperty('inputstream',WBYARcGvlOtsXjrUoxyeVDKJQkaFHN.inputstream_addon)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFHn.setProperty('inputstream.adaptive.manifest_type',WBYARcGvlOtsXjrUoxyeVDKJQkaFHz)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFHn.setProperty('inputstream.adaptive.license_type',WBYARcGvlOtsXjrUoxyeVDKJQkaFHd)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFHn.setProperty('inputstream.adaptive.license_key',WBYARcGvlOtsXjrUoxyeVDKJQkaFHw)
    WBYARcGvlOtsXjrUoxyeVDKJQkaFHn.setProperty('inputstream.adaptive.stream_headers',WBYARcGvlOtsXjrUoxyeVDKJQkaFHL)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFHg==WBYARcGvlOtsXjrUoxyeVDKJQkaFfn:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHn.setContentLookup(WBYARcGvlOtsXjrUoxyeVDKJQkaFfP)
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHn.setMimeType('application/x-mpegURL')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHn.setProperty('inputstream','inputstream.ffmpegdirect')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHn.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHn.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHn.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHn.setProperty('ResumeTime','0')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFHn.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,WBYARcGvlOtsXjrUoxyeVDKJQkaFfn,WBYARcGvlOtsXjrUoxyeVDKJQkaFHn)
  try:
   if WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('mode')in['VOD','MOVIE']and WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('title'):
    WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'code':WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('programcode')if WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('mode')=='VOD' else WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('mediacode'),'img':WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('thumbnail'),'title':WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('title'),'videoid':WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('mediacode')}
    WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.Save_Watched_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('stype'),WBYARcGvlOtsXjrUoxyeVDKJQkaFqp)
  except:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFfb
 def logout(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmd=xbmcgui.Dialog()
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLM=WBYARcGvlOtsXjrUoxyeVDKJQkaFmd.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFLM==WBYARcGvlOtsXjrUoxyeVDKJQkaFfP:sys.exit()
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.Init_TV_Total()
  if os.path.isfile(WBYARcGvlOtsXjrUoxyeVDKJQkaFmh):os.remove(WBYARcGvlOtsXjrUoxyeVDKJQkaFmh)
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFHT =WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.Get_Now_Datetime()
  WBYARcGvlOtsXjrUoxyeVDKJQkaFHu=WBYARcGvlOtsXjrUoxyeVDKJQkaFHT+datetime.timedelta(days=WBYARcGvlOtsXjrUoxyeVDKJQkaFfi(__addon__.getSetting('cache_ttl')))
  (WBYARcGvlOtsXjrUoxyeVDKJQkaFqE,WBYARcGvlOtsXjrUoxyeVDKJQkaFLm,WBYARcGvlOtsXjrUoxyeVDKJQkaFLq,WBYARcGvlOtsXjrUoxyeVDKJQkaFLg)=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_settings_account()
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.Save_session_acount(WBYARcGvlOtsXjrUoxyeVDKJQkaFqE,WBYARcGvlOtsXjrUoxyeVDKJQkaFLm,WBYARcGvlOtsXjrUoxyeVDKJQkaFLq,WBYARcGvlOtsXjrUoxyeVDKJQkaFLg)
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.TV['account']['token_limit']=WBYARcGvlOtsXjrUoxyeVDKJQkaFHu.strftime('%Y%m%d')
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.JsonFile_Save(WBYARcGvlOtsXjrUoxyeVDKJQkaFmh,WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.TV)
 def cookiefile_check(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.TV=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.JsonFile_Load(WBYARcGvlOtsXjrUoxyeVDKJQkaFmh)
  if 'account' not in WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.TV:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.Init_TV_Total()
   return WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
  (WBYARcGvlOtsXjrUoxyeVDKJQkaFHE,WBYARcGvlOtsXjrUoxyeVDKJQkaFfm,WBYARcGvlOtsXjrUoxyeVDKJQkaFfq,WBYARcGvlOtsXjrUoxyeVDKJQkaFfL)=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.get_settings_account()
  (WBYARcGvlOtsXjrUoxyeVDKJQkaFfg,WBYARcGvlOtsXjrUoxyeVDKJQkaFfM,WBYARcGvlOtsXjrUoxyeVDKJQkaFfS,WBYARcGvlOtsXjrUoxyeVDKJQkaFfH)=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.Load_session_acount()
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFHE!=WBYARcGvlOtsXjrUoxyeVDKJQkaFfg or WBYARcGvlOtsXjrUoxyeVDKJQkaFfm!=WBYARcGvlOtsXjrUoxyeVDKJQkaFfM or WBYARcGvlOtsXjrUoxyeVDKJQkaFfq!=WBYARcGvlOtsXjrUoxyeVDKJQkaFfS or WBYARcGvlOtsXjrUoxyeVDKJQkaFfL!=WBYARcGvlOtsXjrUoxyeVDKJQkaFfH:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.Init_TV_Total()
   return WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFfi(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>WBYARcGvlOtsXjrUoxyeVDKJQkaFfi(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.TV['account']['token_limit']):
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.Init_TV_Total()
   return WBYARcGvlOtsXjrUoxyeVDKJQkaFfP
  return WBYARcGvlOtsXjrUoxyeVDKJQkaFfn
 def dp_Global_Search(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=WBYARcGvlOtsXjrUoxyeVDKJQkaFLb.get('mode')
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=='TOTAL_SEARCH':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFfC='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFfC='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(WBYARcGvlOtsXjrUoxyeVDKJQkaFfC)
 def dp_Bookmark_Menu(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFfC='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(WBYARcGvlOtsXjrUoxyeVDKJQkaFfC)
 def dp_EuroLive_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi,WBYARcGvlOtsXjrUoxyeVDKJQkaFLb):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFLn=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.TvingObj.GetEuroChannelList()
  for WBYARcGvlOtsXjrUoxyeVDKJQkaFLI in WBYARcGvlOtsXjrUoxyeVDKJQkaFLn:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgC =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('channel')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqi =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('title')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgL =WBYARcGvlOtsXjrUoxyeVDKJQkaFLI.get('subtitle')
   WBYARcGvlOtsXjrUoxyeVDKJQkaFgq={'mediatype':'episode','title':WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,'plot':'%s\n%s'%(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,WBYARcGvlOtsXjrUoxyeVDKJQkaFgL)}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFqp={'mode':'LIVE','mediacode':WBYARcGvlOtsXjrUoxyeVDKJQkaFgC,'stype':'onair',}
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.add_dir(WBYARcGvlOtsXjrUoxyeVDKJQkaFqi,sublabel=WBYARcGvlOtsXjrUoxyeVDKJQkaFgL,img='',infoLabels=WBYARcGvlOtsXjrUoxyeVDKJQkaFgq,isFolder=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP,params=WBYARcGvlOtsXjrUoxyeVDKJQkaFqp)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFfd(WBYARcGvlOtsXjrUoxyeVDKJQkaFLn)>0:xbmcplugin.endOfDirectory(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi._addon_handle,cacheToDisc=WBYARcGvlOtsXjrUoxyeVDKJQkaFfP)
 def tving_main(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi):
  WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params.get('mode',WBYARcGvlOtsXjrUoxyeVDKJQkaFfb)
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=='LOGOUT':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.logout()
   return
  WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.login_main()
  if WBYARcGvlOtsXjrUoxyeVDKJQkaFMi is WBYARcGvlOtsXjrUoxyeVDKJQkaFfb:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_Main_List()
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_Title_Group(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi in['GLOBAL_GROUP']:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_SubTitle_Group(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=='CHANNEL':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_LiveChannel_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi in['LIVE','VOD','MOVIE']:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.play_VIDEO(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=='PROGRAM':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_Program_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=='EPISODE':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_Episode_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=='MOVIE_SUB':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_Movie_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=='SEARCH_GROUP':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_Search_Group(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi in['SEARCH','LOCAL_SEARCH']:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_Search_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=='WATCH':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_Watch_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_History_Remove(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=='ORDER_BY':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_setEpOrderby(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=='SET_BOOKMARK':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_Set_Bookmark(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi in['TOTAL_SEARCH','TOTAL_HISTORY']:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_Global_Search(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=='SEARCH_HISTORY':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_Search_History(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=='MENU_BOOKMARK':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_Bookmark_Menu(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  elif WBYARcGvlOtsXjrUoxyeVDKJQkaFMi=='EURO_GROUP':
   WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.dp_EuroLive_List(WBYARcGvlOtsXjrUoxyeVDKJQkaFmi.main_params)
  else:
   WBYARcGvlOtsXjrUoxyeVDKJQkaFfb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
