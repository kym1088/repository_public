__author__="NightRain"
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSc=ImportError
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSi=object
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh=None
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu=False
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSs=open
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSg=True
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSF=int
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSp=range
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx=print
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO=Exception
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSj=len
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk=str
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSo=list
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSy=bytes
PfmMTbWdHNXtDnIGwlvYJqAVrUaKSC=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
try:
 from Cryptodome.PublicKey import RSA
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSc:
 from Crypto.PublicKey import RSA
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
PfmMTbWdHNXtDnIGwlvYJqAVrUaKBQ={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
PfmMTbWdHNXtDnIGwlvYJqAVrUaKBE ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class PfmMTbWdHNXtDnIGwlvYJqAVrUaKBe(PfmMTbWdHNXtDnIGwlvYJqAVrUaKSi):
 def __init__(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.NETWORKCODE ='CSND0900'
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.OSCODE ='CSOD0900' 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TELECODE ='CSCD0900'
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.SCREENCODE ='CSSD0100'
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.LIVE_LIMIT =20 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.VOD_LIMIT =24 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.EPISODE_LIMIT =30 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.SEARCH_LIMIT =30 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.MOVIE_LIMIT =24 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.API_DOMAIN ='https://api.tving.com'
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN ='https://image.tving.com'
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.SEARCH_DOMAIN ='https://search.tving.com'
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.LOGIN_DOMAIN ='https://user.tving.com'
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.URL_DOMAIN ='https://www.tving.com'
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.MOVIE_LITE =['2610061','2610161','261062']
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.DEFAULT_HEADER ={'user-agent':PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.USER_AGENT}
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV_SESSION_COOKIES1=''
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV_SESSION_COOKIES2=''
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV ={}
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.Init_TV_Total()
 def Init_TV_Total(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N',},}
 def callRequestCookies(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,jobtype,PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,redirects=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBS=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.DEFAULT_HEADER
  if headers:PfmMTbWdHNXtDnIGwlvYJqAVrUaKBS.update(headers)
  if jobtype=='Get':
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBc=requests.get(PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,params=params,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBS,cookies=cookies,allow_redirects=redirects)
  else:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBc=requests.post(PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,data=payload,params=params,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBS,cookies=cookies,allow_redirects=redirects)
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKBc
 def JsonFile_Save(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,filename,PfmMTbWdHNXtDnIGwlvYJqAVrUaKBi):
  if filename=='':return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
  try:
   fp=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSs(filename,'w',-1,'utf-8')
   json.dump(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBi,fp,indent=4,ensure_ascii=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu)
   fp.close()
  except:
   return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSg
 def JsonFile_Load(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,filename):
  if filename=='':return{}
  try:
   fp=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSs(filename,'r',-1,'utf-8')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBu=json.load(fp)
   fp.close()
  except:
   return{}
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKBu
 def Save_session_acount(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,PfmMTbWdHNXtDnIGwlvYJqAVrUaKBs,PfmMTbWdHNXtDnIGwlvYJqAVrUaKBg,PfmMTbWdHNXtDnIGwlvYJqAVrUaKBF,PfmMTbWdHNXtDnIGwlvYJqAVrUaKBp):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['account']['tvid'] =base64.standard_b64encode(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBs.encode()).decode('utf-8')
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['account']['tvpw'] =base64.standard_b64encode(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBg.encode()).decode('utf-8')
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['account']['tvtype']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBF 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['account']['tvpf'] =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBp 
 def Load_session_acount(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL):
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBs =base64.standard_b64decode(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['account']['tvid']).decode('utf-8')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBg =base64.standard_b64decode(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['account']['tvpw']).decode('utf-8')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBF=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['account']['tvtype']
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBp =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKBs,PfmMTbWdHNXtDnIGwlvYJqAVrUaKBg,PfmMTbWdHNXtDnIGwlvYJqAVrUaKBF,PfmMTbWdHNXtDnIGwlvYJqAVrUaKBp
 def makeDefaultCookies(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx={}
  if PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_token']:PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx['_tving_token']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_token']
  if PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_userinfo']:PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx['POC_USERINFO']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_userinfo']
  if PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_maintoken']:PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx[PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GLOBAL_COOKIENM['tv_maintoken']]=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_maintoken']
  if PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_cookiekey']:PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx[PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GLOBAL_COOKIENM['tv_cookiekey']]=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_cookiekey']
  if PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_lockkey']:PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx[PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GLOBAL_COOKIENM['tv_lockkey']]=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_lockkey']
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx
 def getDeviceStr(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBO=[]
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBO.append('Windows') 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBO.append('Chrome') 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBO.append('ko-KR') 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBO.append('undefined') 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBO.append('24') 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBO.append(u'한국 표준시')
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBO.append('undefined') 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBO.append('undefined') 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBO.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBj=''
  for PfmMTbWdHNXtDnIGwlvYJqAVrUaKBk in PfmMTbWdHNXtDnIGwlvYJqAVrUaKBO:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBj+=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBk+'|'
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKBj
 def GetDefaultParams(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKBo={'apiKey':PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.APIKEY,'networkCode':PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.NETWORKCODE,'osCode':PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.OSCODE,'teleCode':PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TELECODE,'screenCode':PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.SCREENCODE}
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKBo
 def GetNoCache(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,timetype=1):
  if timetype==1:
   return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSF(time.time())
  else:
   return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSF(time.time()*1000)
 def GetUniqueid(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,hValue=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh):
  if hValue:
   import hashlib
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBy=hashlib.sha1()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBy.update(hValue.encode())
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBy.hexdigest()[:8]
  else:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBz=[0 for i in PfmMTbWdHNXtDnIGwlvYJqAVrUaKSp(256)]
   for i in PfmMTbWdHNXtDnIGwlvYJqAVrUaKSp(256):
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKBz[i]='%02x'%(i)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBR=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSF(4294967295*random.random())|0
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBz[255&PfmMTbWdHNXtDnIGwlvYJqAVrUaKBR]+PfmMTbWdHNXtDnIGwlvYJqAVrUaKBz[PfmMTbWdHNXtDnIGwlvYJqAVrUaKBR>>8&255]+PfmMTbWdHNXtDnIGwlvYJqAVrUaKBz[PfmMTbWdHNXtDnIGwlvYJqAVrUaKBR>>16&255]+PfmMTbWdHNXtDnIGwlvYJqAVrUaKBz[PfmMTbWdHNXtDnIGwlvYJqAVrUaKBR>>24&255]
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKBC
 def GetCredential(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,user_id,user_pw,login_type,user_pf):
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeB=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeQ={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Post',PfmMTbWdHNXtDnIGwlvYJqAVrUaKeB,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeQ,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh)
   for PfmMTbWdHNXtDnIGwlvYJqAVrUaKeL in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.cookies:
    if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeL.name=='_tving_token':
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_token']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeL.value
    elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKeL.name=='POC_USERINFO':
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_userinfo']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeL.value
   if not PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_token']:
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.Init_TV_Total()
    return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_maintoken']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_token']
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetProfileToken(user_pf)==PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu:
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.Init_TV_Total()
    return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeS =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetDeviceList()
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeS not in['','-']:
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_uuid']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeS+'-'+PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetUniqueid(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeS)
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeS)
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.Init_TV_Total()
   return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSg
 def GetProfileToken(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,user_pf):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKec=[]
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKei =''
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.makeDefaultCookies()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Get',PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKec =re.findall('data-profile-no="\d+"',PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.text)
   for i in PfmMTbWdHNXtDnIGwlvYJqAVrUaKSp(PfmMTbWdHNXtDnIGwlvYJqAVrUaKSj(PfmMTbWdHNXtDnIGwlvYJqAVrUaKec)):
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKeu =PfmMTbWdHNXtDnIGwlvYJqAVrUaKec[i].replace('data-profile-no=','').replace('"','')
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKec[i]=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeu
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKei=PfmMTbWdHNXtDnIGwlvYJqAVrUaKec[user_pf]
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.Init_TV_Total()
   return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.makeDefaultCookies()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeQ={'profileNo':PfmMTbWdHNXtDnIGwlvYJqAVrUaKei}
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Post',PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeQ,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx)
   for PfmMTbWdHNXtDnIGwlvYJqAVrUaKeL in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.cookies:
    if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeL.name=='_tving_token':
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_token']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeL.value
    elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKeL.name==PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GLOBAL_COOKIENM['tv_cookiekey']:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_cookiekey']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeL.value
    elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKeL.name==PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GLOBAL_COOKIENM['tv_lockkey']:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_lockkey']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeL.value
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.Init_TV_Total()
   return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSg
 def GetDeviceList(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKes=[]
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKeg='-'
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh ='/v1/user/device/list'
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeF=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.API_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKep={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.makeDefaultCookies()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Get',PfmMTbWdHNXtDnIGwlvYJqAVrUaKeF,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKep,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKex=json.loads(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.text)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKes=PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']
   for PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO in PfmMTbWdHNXtDnIGwlvYJqAVrUaKes:
    if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['model']=='PC' or PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['model']=='PC-Chrome':
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKeg=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['uuid']
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKeg
 def Get_Now_Datetime(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,mediacode,sel_quality,stype,pvrmode='-'):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKek ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','error_msg':'',}
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKeg =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_uuid'].split('-')[0] 
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKeo =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_uuid'] 
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKey=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetNoCache(1))
   if stype!='tvingtv':
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh ='/v2/media/stream/info' 
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetDefaultParams()
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKep={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':PfmMTbWdHNXtDnIGwlvYJqAVrUaKeo,'deviceInfo':'PC','noCache':PfmMTbWdHNXtDnIGwlvYJqAVrUaKey,}
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC.update(PfmMTbWdHNXtDnIGwlvYJqAVrUaKep)
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKez=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.API_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.makeDefaultCookies()
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Get',PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx)
    if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.status_code!=200:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKek['error_msg']='First Step - {} error'.format(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.status_code)
     return PfmMTbWdHNXtDnIGwlvYJqAVrUaKek
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKex=json.loads(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.text)
    if PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['result']['code']=='060':
     for PfmMTbWdHNXtDnIGwlvYJqAVrUaKeR,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQs in PfmMTbWdHNXtDnIGwlvYJqAVrUaKBQ.items():
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKQs==sel_quality:
       PfmMTbWdHNXtDnIGwlvYJqAVrUaKQB=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeR
    elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['result']['code']!='000':
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKek['error_msg']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['result']['message']
     return PfmMTbWdHNXtDnIGwlvYJqAVrUaKek
    else: 
     if not('stream' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']):return PfmMTbWdHNXtDnIGwlvYJqAVrUaKek
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQe=[]
     for PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO in PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['stream']['quality']:
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['active']=='Y':
       PfmMTbWdHNXtDnIGwlvYJqAVrUaKQe.append({PfmMTbWdHNXtDnIGwlvYJqAVrUaKBQ.get(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['code']):PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['code']})
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQB=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.CheckQuality(sel_quality,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQe)
   else:
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQB='stream40'
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKek['error_msg']='First Step - except error'
   return PfmMTbWdHNXtDnIGwlvYJqAVrUaKek
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(PfmMTbWdHNXtDnIGwlvYJqAVrUaKQB)
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKey=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetNoCache(1))
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh ='/v2a/media/stream/info'
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetDefaultParams()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKep={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQB,'deviceId':PfmMTbWdHNXtDnIGwlvYJqAVrUaKeg,'uuid':PfmMTbWdHNXtDnIGwlvYJqAVrUaKeo,'deviceInfo':'PC_Chrome','noCache':PfmMTbWdHNXtDnIGwlvYJqAVrUaKey,'wm':'Y'}
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC.update(PfmMTbWdHNXtDnIGwlvYJqAVrUaKep)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKez=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.API_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.makeDefaultCookies()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Get',PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBx,redirects=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKex=json.loads(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.text)
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['result']['code']!='000':
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKek['error_msg']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['result']['message']
    return PfmMTbWdHNXtDnIGwlvYJqAVrUaKek
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['stream']
   if 'drm_license_assertion' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKQE:
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKek['drm_license']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQE['drm_license_assertion']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQL =PfmMTbWdHNXtDnIGwlvYJqAVrUaKQE['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKQE['broadcast']):return PfmMTbWdHNXtDnIGwlvYJqAVrUaKek
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQL=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQE['broadcast']['broad_url']
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKek['error_msg']='Second Step - except error'
   return PfmMTbWdHNXtDnIGwlvYJqAVrUaKek
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKQS=PfmMTbWdHNXtDnIGwlvYJqAVrUaKey
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKQL=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQL.split('|')[1]
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKQL,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQc,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQi=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.Decrypt_Url(PfmMTbWdHNXtDnIGwlvYJqAVrUaKQL,mediacode,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQS)
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKek['streaming_url']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQL
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKek['watermark'] =PfmMTbWdHNXtDnIGwlvYJqAVrUaKQc
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKek['watermarkKey']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQi
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKek
 def CheckQuality(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,sel_qt,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQe):
  for PfmMTbWdHNXtDnIGwlvYJqAVrUaKQh in PfmMTbWdHNXtDnIGwlvYJqAVrUaKQe:
   if sel_qt>=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSo(PfmMTbWdHNXtDnIGwlvYJqAVrUaKQh)[0]:return PfmMTbWdHNXtDnIGwlvYJqAVrUaKQh.get(PfmMTbWdHNXtDnIGwlvYJqAVrUaKSo(PfmMTbWdHNXtDnIGwlvYJqAVrUaKQh)[0])
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQu=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQh.get(PfmMTbWdHNXtDnIGwlvYJqAVrUaKSo(PfmMTbWdHNXtDnIGwlvYJqAVrUaKQh)[0])
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKQu
 def makeOocUrl(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,ooc_params):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKez=''
  for PfmMTbWdHNXtDnIGwlvYJqAVrUaKeR,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQs in ooc_params.items():
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKez+="%s=%s^"%(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeR,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQs)
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKez
 def GetLiveChannelList(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,stype,page_int):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKes=[]
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh ='/v2/media/lives'
   if stype=='onair': 
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQF='CPCS0100,CPCS0400'
   else:
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQF='CPCS0300'
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetDefaultParams()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKep={'cacheType':'main','pageNo':PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(page_int),'pageSize':PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQF,}
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC.update(PfmMTbWdHNXtDnIGwlvYJqAVrUaKep)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKez=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.API_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Get',PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKex=json.loads(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.text)
   if not('result' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']):return PfmMTbWdHNXtDnIGwlvYJqAVrUaKes,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp=PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['result']
   for PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO in PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp:
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQx=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQo=''
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQO=PfmMTbWdHNXtDnIGwlvYJqAVrUaKEp=''
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQj=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['live_code']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQx =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['channel']['name']['ko']
    if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['episode']!=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['program']['name']['ko']
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk =PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk+', '+PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['episode']['frequency'])+'회'
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQo=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['episode']['synopsis']['ko']
    else:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['program']['name']['ko']
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQo=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['program']['synopsis']['ko']
    try: 
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =''
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC =''
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz=''
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQR =''
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEB =''
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEe =''
     for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['program']['image']:
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP0900':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
      elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP1800':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
      elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP2000':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQR =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
      elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP1900':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEB =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
      elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP0200':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEe =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
      elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP0500':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
      elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP0800':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy=='':
      for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['channel']['image']:
       if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIC0400':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
       elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIC1400':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
       elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIC1900':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
    except:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh
    try:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL =[]
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKES=[]
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc =[]
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi=''
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEh=''
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEu=''
     for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEs in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('schedule').get('program').get('actor'):
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEs!='' and PfmMTbWdHNXtDnIGwlvYJqAVrUaKEs!=u'없음':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEs)
     for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEg in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('schedule').get('program').get('director'):
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEg!='' and PfmMTbWdHNXtDnIGwlvYJqAVrUaKEg!='-' and PfmMTbWdHNXtDnIGwlvYJqAVrUaKEg!=u'없음':PfmMTbWdHNXtDnIGwlvYJqAVrUaKES.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEg)
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('schedule').get('program').get('category1_name').get('ko')!='':
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['program']['category1_name']['ko'])
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('schedule').get('program').get('category2_name').get('ko')!='':
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['program']['category2_name']['ko'])
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('schedule').get('program').get('product_year'):PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['program']['product_year']
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('schedule').get('program').get('grade_code') :PfmMTbWdHNXtDnIGwlvYJqAVrUaKEh= PfmMTbWdHNXtDnIGwlvYJqAVrUaKBE.get(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['program']['grade_code'])
     if 'broad_dt' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('schedule').get('program'):
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('schedule').get('program').get('broad_dt')
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEu='%s-%s-%s'%(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[:4],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[4:6],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[6:])
    except:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQO=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['broadcast_start_time'])[8:12]
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEp =PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['schedule']['broadcast_end_time'])[8:12]
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx={'channel':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQx,'title':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk,'mediacode':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQj,'thumbnail':{'poster':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC,'thumb':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy,'clearlogo':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz,'icon':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQR,'fanart':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEe},'synopsis':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQo,'channelepg':' [%s:%s ~ %s:%s]'%(PfmMTbWdHNXtDnIGwlvYJqAVrUaKQO[0:2],PfmMTbWdHNXtDnIGwlvYJqAVrUaKQO[2:],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEp[0:2],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEp[2:]),'cast':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL,'director':PfmMTbWdHNXtDnIGwlvYJqAVrUaKES,'info_genre':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc,'year':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi,'mpaa':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEh,'premiered':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEu}
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKes.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx)
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['has_more']=='Y':
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSg
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKes,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg
 def GetProgramList(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,genre,orderby,page_int,genreCode='all'):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKes=[]
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh ='/v2/media/episodes'
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetDefaultParams()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKep={'cacheType':'main','pageSize':PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(page_int),}
   if genre !='all':PfmMTbWdHNXtDnIGwlvYJqAVrUaKep['categoryCode']=genre
   if genreCode!='all':PfmMTbWdHNXtDnIGwlvYJqAVrUaKep['genreCode'] =genreCode 
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC.update(PfmMTbWdHNXtDnIGwlvYJqAVrUaKep)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKez=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.API_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Get',PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKex=json.loads(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.text)
   if not('result' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']):return PfmMTbWdHNXtDnIGwlvYJqAVrUaKes,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp=PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['result']
   for PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO in PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp:
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEO=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['program']['code']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['program']['name']['ko']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEh =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBE.get(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['program'].get('grade_code'))
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC =''
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =''
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz=''
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQR =''
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEB =''
    for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['program']['image']:
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP0900':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
     elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP0200':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
     elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP1800':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
     elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP2000':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQR =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
     elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP1900':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEB =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQo =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['program']['synopsis']['ko']
    try:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEj=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['channel']['name']['ko']
    except:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEj=''
    try:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL =[]
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKES=[]
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc =[]
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi =''
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEu=''
     for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEs in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('program').get('actor'):
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEs!='' and PfmMTbWdHNXtDnIGwlvYJqAVrUaKEs!='-' and PfmMTbWdHNXtDnIGwlvYJqAVrUaKEs!=u'없음':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEs)
     for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEg in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('program').get('director'):
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEg!='' and PfmMTbWdHNXtDnIGwlvYJqAVrUaKEg!='-' and PfmMTbWdHNXtDnIGwlvYJqAVrUaKEg!=u'없음':PfmMTbWdHNXtDnIGwlvYJqAVrUaKES.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEg)
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('program').get('category1_name').get('ko')!='':
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['program']['category1_name']['ko'])
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('program').get('category2_name').get('ko')!='':
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['program']['category2_name']['ko'])
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('program').get('product_year'):PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['program']['product_year']
     if 'broad_dt' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('program'):
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('program').get('broad_dt')
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEu='%s-%s-%s'%(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[:4],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[4:6],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[6:])
    except:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx={'program':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEO,'title':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk,'thumbnail':{'poster':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC,'thumb':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy,'clearlogo':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz,'icon':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQR,'banner':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEB,'fanart':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy},'synopsis':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQo,'channel':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEj,'cast':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL,'director':PfmMTbWdHNXtDnIGwlvYJqAVrUaKES,'info_genre':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc,'year':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi,'premiered':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEu,'mpaa':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEh}
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKes.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx)
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['has_more']=='Y':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSg
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKes,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg
 def GetEpisodeList(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,program_code,page_int,orderby='desc'):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKes=[]
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh ='/v2/media/frequency/program/'+program_code
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetDefaultParams()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKep={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC.update(PfmMTbWdHNXtDnIGwlvYJqAVrUaKep)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKez=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.API_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Get',PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKex=json.loads(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.text)
   if not('result' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']):return PfmMTbWdHNXtDnIGwlvYJqAVrUaKes,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp=PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['result']
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKEk=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSF(PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['total_count'])
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKEo =PfmMTbWdHNXtDnIGwlvYJqAVrUaKSF(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEk//(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEy =(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEk-1)-((page_int-1)*PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.EPISODE_LIMIT)
   else:
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEy =(page_int-1)*PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.EPISODE_LIMIT
   for i in PfmMTbWdHNXtDnIGwlvYJqAVrUaKSp(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.EPISODE_LIMIT):
    if orderby=='desc':
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKEy-i
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC<0:break
    else:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKEy+i
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC>=PfmMTbWdHNXtDnIGwlvYJqAVrUaKEk:break
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEz=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp[PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC]['episode']['code']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk =PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp[PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC]['vod_name']['ko']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKER =''
    try:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp[PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC]['episode']['broadcast_date'])
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKER='%s-%s-%s'%(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[:4],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[4:6],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[6:])
    except:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh
    try:
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp[PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC]['episode']['pip_cliptype']=='C012':
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKER+=' - Quick VOD'
    except:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQo =PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp[PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC]['episode']['synopsis']['ko']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC =''
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =''
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz=''
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQR =''
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEB =''
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEe =''
    for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ in PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp[PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC]['program']['image']:
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP0900':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
     elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP1800':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
     elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP2000':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQR =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
     elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP1900':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEB =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
     elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIP0200':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEe =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
    for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ in PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp[PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC]['episode']['image']:
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIE0400':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
    try:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKLB=PfmMTbWdHNXtDnIGwlvYJqAVrUaKLQ=PfmMTbWdHNXtDnIGwlvYJqAVrUaKLE=''
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKLe=0
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKLB =PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp[PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC]['program']['name']['ko']
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKLQ =PfmMTbWdHNXtDnIGwlvYJqAVrUaKER
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKLE =PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp[PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC]['channel']['name']['ko']
     if 'frequency' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp[PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC]['episode']:PfmMTbWdHNXtDnIGwlvYJqAVrUaKLe=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp[PfmMTbWdHNXtDnIGwlvYJqAVrUaKEC]['episode']['frequency']
    except:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx={'episode':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEz,'title':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk,'subtitle':PfmMTbWdHNXtDnIGwlvYJqAVrUaKER,'thumbnail':{'poster':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC,'thumb':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy,'clearlogo':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz,'icon':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQR,'banner':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEB,'fanart':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEe},'synopsis':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQo,'info_title':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLB,'aired':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLQ,'studio':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLE,'frequency':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLe}
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKes.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx)
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEo>page_int:PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSg
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKes,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg,PfmMTbWdHNXtDnIGwlvYJqAVrUaKEo
 def GetMovieList(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,genre,orderby,page_int):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKes=[]
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh ='/v2/media/movies'
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetDefaultParams()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKep={'pageSize':PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N','pageNo':PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(page_int),}
   if genre!='all' :PfmMTbWdHNXtDnIGwlvYJqAVrUaKep['categoryCode']=genre
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKep['productPackageCode']=','.join(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.MOVIE_LITE)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC.update(PfmMTbWdHNXtDnIGwlvYJqAVrUaKep)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKez=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.API_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Get',PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKex=json.loads(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.text)
   if not('result' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']):return PfmMTbWdHNXtDnIGwlvYJqAVrUaKes,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp=PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['result']
   for PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO in PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp:
    if 'release_date' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('movie'):
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('movie').get('release_date'))[:4]
    else:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKLS =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['movie']['code']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['movie']['name']['ko'].strip()
    if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi not in[PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,'0','']:PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk+=u' (%s)'%(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi)
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC=''
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =''
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz=''
    for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['movie']['image']:
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIM2100':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
     elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIM0400':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
     elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['code']=='CAIM1800':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ['url']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKQo =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['movie']['story']['ko']
    try:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKLB =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['movie']['name']['ko'].strip()
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEh =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBE.get(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('grade_code'))
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL=[]
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKES=[]
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc=[]
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKLc=0
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEu=''
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKLE =''
     for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEs in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('movie').get('actor'):
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEs!='':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEs)
     for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEg in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('movie').get('director'):
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEg!='':PfmMTbWdHNXtDnIGwlvYJqAVrUaKES.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEg)
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('movie').get('category1_name').get('ko')!='':
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['movie']['category1_name']['ko'])
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('movie').get('category2_name').get('ko')!='':
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['movie']['category2_name']['ko'])
     if 'duration' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('movie'):PfmMTbWdHNXtDnIGwlvYJqAVrUaKLc=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('movie').get('duration')
     if 'release_date' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('movie'):
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('movie').get('release_date'))
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF!='0':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEu='%s-%s-%s'%(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[:4],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[4:6],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[6:])
     if 'production' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('movie'):PfmMTbWdHNXtDnIGwlvYJqAVrUaKLE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('movie').get('production')
    except:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx={'moviecode':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLS,'title':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk,'thumbnail':{'poster':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC,'thumb':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy,'clearlogo':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz,'fanart':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy},'synopsis':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQo,'info_title':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLB,'year':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi,'cast':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL,'director':PfmMTbWdHNXtDnIGwlvYJqAVrUaKES,'info_genre':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc,'duration':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLc,'premiered':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEu,'studio':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLE,'mpaa':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEh}
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKLi=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
    for PfmMTbWdHNXtDnIGwlvYJqAVrUaKLh in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['billing_package_id']:
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKLh in PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.MOVIE_LITE:
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKLi=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSg
      break
    if PfmMTbWdHNXtDnIGwlvYJqAVrUaKLi==PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu: 
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx['title']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx['title']+' [개별구매]'
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKes.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx)
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['has_more']=='Y':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSg
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKes,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg
 def GetMovieGenre(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKes=[]
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh ='/v2/media/movie/curations'
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetDefaultParams()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKep={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC.update(PfmMTbWdHNXtDnIGwlvYJqAVrUaKep)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKez=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.API_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Get',PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKex=json.loads(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.text)
   if not('result' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']):return PfmMTbWdHNXtDnIGwlvYJqAVrUaKes,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp=PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['result']
   for PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO in PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp:
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKLu =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['curation_code']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKLs =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['curation_name']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx={'curation_code':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLu,'curation_name':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLs}
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKes.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx)
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKes,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg
 def GetSearchList(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,search_key,page_int,stype):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKLg=[]
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh ='/search/getSearch.jsp'
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKep={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(page_int),'pageSize':PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.SCREENCODE,'os':PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.OSCODE,'network':PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKez=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.SEARCH_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Get',PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKep,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKex=json.loads(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.text)
   if stype=='vod':
    if not('programRsb' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKex):return PfmMTbWdHNXtDnIGwlvYJqAVrUaKLg,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKLF=PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['programRsb']['dataList']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKLp =PfmMTbWdHNXtDnIGwlvYJqAVrUaKSF(PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['programRsb']['count'])
    for PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO in PfmMTbWdHNXtDnIGwlvYJqAVrUaKLF:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEO=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['mast_cd']
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['mast_nm']
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['web_url4']
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['web_url']
     try:
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL =[]
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKES=[]
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc =[]
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKLc =0
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEh =''
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi =''
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKLQ =''
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('actor') !='' and PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('actor') !='-':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('actor').split(',')
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('director')!='' and PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('director')!='-':PfmMTbWdHNXtDnIGwlvYJqAVrUaKES=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('director').split(',')
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('cate_nm')!='' and PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('cate_nm')!='-':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('cate_nm').split('/')
      if 'targetage' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO:PfmMTbWdHNXtDnIGwlvYJqAVrUaKEh=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('targetage')
      if 'broad_dt' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO:
       PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('broad_dt')
       PfmMTbWdHNXtDnIGwlvYJqAVrUaKLQ='%s-%s-%s'%(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[:4],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[4:6],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[6:])
       PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi =PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[:4]
     except:
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx={'program':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEO,'title':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk,'thumbnail':{'poster':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC,'thumb':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy,'fanart':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy},'synopsis':'','cast':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL,'director':PfmMTbWdHNXtDnIGwlvYJqAVrUaKES,'info_genre':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc,'duration':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLc,'mpaa':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEh,'year':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi,'aired':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLQ}
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKLg.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx)
   else:
    if not('vodMVRsb' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKex):return PfmMTbWdHNXtDnIGwlvYJqAVrUaKLg,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKLx=PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['vodMVRsb']['dataList']
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKLp =PfmMTbWdHNXtDnIGwlvYJqAVrUaKSF(PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['vodMVRsb']['count'])
    for PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO in PfmMTbWdHNXtDnIGwlvYJqAVrUaKLx:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEO=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['mast_cd']
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['mast_nm'].strip()
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['web_url']
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz=''
     try:
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL =[]
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKES=[]
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc =[]
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKLc =0
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEh =''
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi =''
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKLQ =''
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('actor') !='' and PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('actor') !='-':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('actor').split(',')
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('director')!='' and PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('director')!='-':PfmMTbWdHNXtDnIGwlvYJqAVrUaKES=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('director').split(',')
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('cate_nm')!='' and PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('cate_nm')!='-':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc =PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('cate_nm').split('/')
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('runtime_sec')!='':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLc=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('runtime_sec')
      if 'grade_nm' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO:PfmMTbWdHNXtDnIGwlvYJqAVrUaKEh=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('grade_nm')
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('broad_dt')
      if data_str!='':
       PfmMTbWdHNXtDnIGwlvYJqAVrUaKLQ='%s-%s-%s'%(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[:4],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[4:6],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[6:])
       PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi =PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[:4]
     except:
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx={'movie':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEO,'title':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk,'thumbnail':{'poster':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC,'thumb':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy,'fanart':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy,'clearlogo':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz},'synopsis':'','cast':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEL,'director':PfmMTbWdHNXtDnIGwlvYJqAVrUaKES,'info_genre':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEc,'duration':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLc,'mpaa':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEh,'year':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEi,'aired':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLQ}
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKLi=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu
     for PfmMTbWdHNXtDnIGwlvYJqAVrUaKLh in PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO['bill']:
      if PfmMTbWdHNXtDnIGwlvYJqAVrUaKLh in PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.MOVIE_LITE:
       PfmMTbWdHNXtDnIGwlvYJqAVrUaKLi=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSg
       break
     if PfmMTbWdHNXtDnIGwlvYJqAVrUaKLi==PfmMTbWdHNXtDnIGwlvYJqAVrUaKSu: 
      PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx['title']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx['title']+' [개별구매]'
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKLg.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx)
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKLp>(page_int*PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.SEARCH_LIMIT):PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSg
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKLg,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg
 def GetBookmarkInfo(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,videoid,vidtype):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKez=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.API_DOMAIN+'/v2/media/program/'+videoid
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetDefaultParams()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKep={'pageNo':'1','pageSize':'10','order':'name',}
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC.update(PfmMTbWdHNXtDnIGwlvYJqAVrUaKep)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Get',PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLj=json.loads(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.text)
   if not('body' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKLj):return{}
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk=PfmMTbWdHNXtDnIGwlvYJqAVrUaKLj['body']
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk=PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('name').get('ko').strip()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['title'] =PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['title']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['mpaa'] =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBE.get(PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('grade_code'))
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['plot'] =PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('synopsis').get('ko')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['year'] =PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('product_year')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['cast'] =PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('actor')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['director']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('director')
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('category1_name').get('ko')!='':
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['genre'].append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('category1_name').get('ko'))
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('category2_name').get('ko')!='':
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['genre'].append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('category2_name').get('ko'))
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('broad_dt'))
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF!='0':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[:4],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[4:6],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[6:])
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC =''
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =''
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz=''
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQR =''
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKEB =''
   for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ in PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('image'):
    if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('code')=='CAIP0900':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('url')
    elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('code')=='CAIP0200':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('url')
    elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('code')=='CAIP1800':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('url')
    elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('code')=='CAIP2000':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQR =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('url')
    elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('code')=='CAIP1900':PfmMTbWdHNXtDnIGwlvYJqAVrUaKEB =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('url')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['thumbnail']['poster']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['thumbnail']['thumb']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['thumbnail']['clearlogo']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['thumbnail']['icon']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQR
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['thumbnail']['banner']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKEB
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['thumbnail']['fanart']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy
  else:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKez=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.API_DOMAIN+'/v2a/media/stream/info'
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetDefaultParams()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKep={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_uuid'].split('-')[0],'uuid':PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetNoCache(1)),'wm':'Y',}
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC.update(PfmMTbWdHNXtDnIGwlvYJqAVrUaKep)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Get',PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLj=json.loads(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.text)
   if not('content' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKLj['body']):return{}
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk=PfmMTbWdHNXtDnIGwlvYJqAVrUaKLj['body']['content']['info']['movie']
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk =PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('name').get('ko').strip()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['title']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk +=u' (%s)'%(PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('product_year'))
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['title'] =PfmMTbWdHNXtDnIGwlvYJqAVrUaKQk
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['mpaa'] =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBE.get(PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('grade_code'))
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['plot'] =PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('story').get('ko')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['year'] =PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('product_year')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['studio'] =PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('production')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['duration']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('duration')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['cast'] =PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('actor')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['director']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('director')
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('category1_name').get('ko')!='':
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['genre'].append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('category1_name').get('ko'))
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('category2_name').get('ko')!='':
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['genre'].append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('category2_name').get('ko'))
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('release_date'))
   if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF!='0':PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[:4],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[4:6],PfmMTbWdHNXtDnIGwlvYJqAVrUaKEF[6:])
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC=''
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =''
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz=''
   for PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ in PfmMTbWdHNXtDnIGwlvYJqAVrUaKLk.get('image'):
    if PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('code')=='CAIM2100':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('url')
    elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('code')=='CAIM0400':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('url')
    elif PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('code')=='CAIM1800':PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.IMG_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKEQ.get('url')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['thumbnail']['poster']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['thumbnail']['thumb']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQC 
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['thumbnail']['clearlogo']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQz
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO['saveinfo']['thumbnail']['fanart']=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQy
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKLO
 def GetEuroChannelList(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKes=[]
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh ='/v2/operator/highlights'
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetDefaultParams()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKep={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':PfmMTbWdHNXtDnIGwlvYJqAVrUaKSk(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.GetNoCache(2))}
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC.update(PfmMTbWdHNXtDnIGwlvYJqAVrUaKep)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKez=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.API_DOMAIN+PfmMTbWdHNXtDnIGwlvYJqAVrUaKeh
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.callRequestCookies('Get',PfmMTbWdHNXtDnIGwlvYJqAVrUaKez,payload=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,params=PfmMTbWdHNXtDnIGwlvYJqAVrUaKeC,headers=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh,cookies=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSh)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKex=json.loads(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeE.text)
   if not('result' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']):return PfmMTbWdHNXtDnIGwlvYJqAVrUaKes,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQg
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp=PfmMTbWdHNXtDnIGwlvYJqAVrUaKex['body']['result']
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLo =PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.Get_Now_Datetime()
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLy=PfmMTbWdHNXtDnIGwlvYJqAVrUaKLo+datetime.timedelta(days=-1)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLy=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSF(PfmMTbWdHNXtDnIGwlvYJqAVrUaKLy.strftime('%Y%m%d'))
   for PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO in PfmMTbWdHNXtDnIGwlvYJqAVrUaKQp:
    PfmMTbWdHNXtDnIGwlvYJqAVrUaKLC=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSF(PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('content').get('banner_title2')[:8])
    if PfmMTbWdHNXtDnIGwlvYJqAVrUaKLy<=PfmMTbWdHNXtDnIGwlvYJqAVrUaKLC:
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx={'channel':PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('content').get('banner_sub_title3'),'title':PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('content').get('banner_title'),'subtitle':PfmMTbWdHNXtDnIGwlvYJqAVrUaKeO.get('content').get('banner_sub_title2'),}
     PfmMTbWdHNXtDnIGwlvYJqAVrUaKes.append(PfmMTbWdHNXtDnIGwlvYJqAVrUaKEx)
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKes
 def Make_DecryptKey(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,step,mediacode='000',timecode='000'):
  if step=='1':
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLz=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSy('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLR=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSy('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLz=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSy('kss2lym0kdw1lks3','utf-8')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLR=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSy([PfmMTbWdHNXtDnIGwlvYJqAVrUaKSC('*'),0x07,PfmMTbWdHNXtDnIGwlvYJqAVrUaKSC('r'),PfmMTbWdHNXtDnIGwlvYJqAVrUaKSC(';'),PfmMTbWdHNXtDnIGwlvYJqAVrUaKSC('7'),0x05,0x1e,0x01,PfmMTbWdHNXtDnIGwlvYJqAVrUaKSC('n'),PfmMTbWdHNXtDnIGwlvYJqAVrUaKSC('D'),0x02,PfmMTbWdHNXtDnIGwlvYJqAVrUaKSC('3'),PfmMTbWdHNXtDnIGwlvYJqAVrUaKSC('*'),PfmMTbWdHNXtDnIGwlvYJqAVrUaKSC('a'),PfmMTbWdHNXtDnIGwlvYJqAVrUaKSC('&'),PfmMTbWdHNXtDnIGwlvYJqAVrUaKSC('<')])
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKLz,PfmMTbWdHNXtDnIGwlvYJqAVrUaKLR
 def DecryptPlaintext(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,ciphertext,encryption_key,init_vector):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKSB=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKSe=Padding.unpad(PfmMTbWdHNXtDnIGwlvYJqAVrUaKSB.decrypt(base64.standard_b64decode(ciphertext)),16)
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSe.decode('utf-8')
 def Decrypt_Url(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL,ciphertext,mediacode,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQS):
  PfmMTbWdHNXtDnIGwlvYJqAVrUaKSQ=''
  try:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLz,PfmMTbWdHNXtDnIGwlvYJqAVrUaKLR=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.Make_DecryptKey('1',mediacode=mediacode,timecode=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQS)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSE=json.loads(PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.DecryptPlaintext(ciphertext,PfmMTbWdHNXtDnIGwlvYJqAVrUaKLz,PfmMTbWdHNXtDnIGwlvYJqAVrUaKLR))
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSL =PfmMTbWdHNXtDnIGwlvYJqAVrUaKSE.get('broad_url')
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQc =PfmMTbWdHNXtDnIGwlvYJqAVrUaKSE.get('watermark') if 'watermark' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKSE else ''
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKQi=PfmMTbWdHNXtDnIGwlvYJqAVrUaKSE.get('watermarkKey')if 'watermarkKey' in PfmMTbWdHNXtDnIGwlvYJqAVrUaKSE else ''
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKLz,PfmMTbWdHNXtDnIGwlvYJqAVrUaKLR=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.Make_DecryptKey('2',mediacode=mediacode,timecode=PfmMTbWdHNXtDnIGwlvYJqAVrUaKQS)
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSQ=PfmMTbWdHNXtDnIGwlvYJqAVrUaKBL.DecryptPlaintext(PfmMTbWdHNXtDnIGwlvYJqAVrUaKSL,PfmMTbWdHNXtDnIGwlvYJqAVrUaKLz,PfmMTbWdHNXtDnIGwlvYJqAVrUaKLR)
  except PfmMTbWdHNXtDnIGwlvYJqAVrUaKSO as exception:
   PfmMTbWdHNXtDnIGwlvYJqAVrUaKSx(exception)
  return PfmMTbWdHNXtDnIGwlvYJqAVrUaKSQ,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQc,PfmMTbWdHNXtDnIGwlvYJqAVrUaKQi
# Created by pyminifier (https://github.com/liftoff/pyminifier)
