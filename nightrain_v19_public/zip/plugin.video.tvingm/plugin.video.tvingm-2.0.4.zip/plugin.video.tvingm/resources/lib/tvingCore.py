__author__="NightRain"
aWsLSYJwhixfIpHNoXqROvGnTcrEjy=object
aWsLSYJwhixfIpHNoXqROvGnTcrEjB=None
aWsLSYJwhixfIpHNoXqROvGnTcrEjV=False
aWsLSYJwhixfIpHNoXqROvGnTcrElM=int
aWsLSYJwhixfIpHNoXqROvGnTcrElK=True
aWsLSYJwhixfIpHNoXqROvGnTcrElg=Exception
aWsLSYJwhixfIpHNoXqROvGnTcrElj=print
aWsLSYJwhixfIpHNoXqROvGnTcrEld=str
aWsLSYJwhixfIpHNoXqROvGnTcrElk=list
aWsLSYJwhixfIpHNoXqROvGnTcrElD=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
aWsLSYJwhixfIpHNoXqROvGnTcrEMg ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
aWsLSYJwhixfIpHNoXqROvGnTcrEMj={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
class aWsLSYJwhixfIpHNoXqROvGnTcrEMK(aWsLSYJwhixfIpHNoXqROvGnTcrEjy):
 def __init__(aWsLSYJwhixfIpHNoXqROvGnTcrEMl):
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.TVING_TOKEN =''
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.POC_USERINFO =''
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.TVING_UUID ='-'
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.NETWORKCODE ='CSND0900'
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.OSCODE ='CSOD0900' 
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.TELECODE ='CSCD0900'
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.SCREENCODE ='CSSD0100'
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.LIVE_LIMIT =23
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.VOD_LIMIT =20
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.EPISODE_LIMIT=30 
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.SEARCH_LIMIT =80 
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.MOVIE_LIMIT =18
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.API_DOMAIN ='https://api.tving.com'
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN ='https://image.tving.com'
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.SEARCH_DOMAIN='https://search.tving.com'
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.LOGIN_DOMAIN ='https://user.tving.com'
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.URL_DOMAIN ='https://www.tving.com'
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.MOVIE_LITE ='338723'
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.MOVIE_PREMIUM='1513561'
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.DEFAULT_HEADER={'user-agent':aWsLSYJwhixfIpHNoXqROvGnTcrEMg}
 def callRequestCookies(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,jobtype,aWsLSYJwhixfIpHNoXqROvGnTcrEMF,payload=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,params=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,cookies=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,redirects=aWsLSYJwhixfIpHNoXqROvGnTcrEjV):
  aWsLSYJwhixfIpHNoXqROvGnTcrEMd=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.DEFAULT_HEADER
  if headers:aWsLSYJwhixfIpHNoXqROvGnTcrEMd.update(headers)
  if jobtype=='Get':
   aWsLSYJwhixfIpHNoXqROvGnTcrEMk=requests.get(aWsLSYJwhixfIpHNoXqROvGnTcrEMF,params=params,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEMd,cookies=cookies,allow_redirects=redirects)
  else:
   aWsLSYJwhixfIpHNoXqROvGnTcrEMk=requests.post(aWsLSYJwhixfIpHNoXqROvGnTcrEMF,data=payload,params=params,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEMd,cookies=cookies,allow_redirects=redirects)
  return aWsLSYJwhixfIpHNoXqROvGnTcrEMk
 def makeDefaultCookies(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,vToken=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,vUserinfo=aWsLSYJwhixfIpHNoXqROvGnTcrEjB):
  aWsLSYJwhixfIpHNoXqROvGnTcrEMD={}
  aWsLSYJwhixfIpHNoXqROvGnTcrEMD['_tving_token']=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.TVING_TOKEN if vToken==aWsLSYJwhixfIpHNoXqROvGnTcrEjB else vToken
  aWsLSYJwhixfIpHNoXqROvGnTcrEMD['POC_USERINFO']=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.POC_USERINFO if vToken==aWsLSYJwhixfIpHNoXqROvGnTcrEjB else vUserinfo
  return aWsLSYJwhixfIpHNoXqROvGnTcrEMD
 def getDeviceStr(aWsLSYJwhixfIpHNoXqROvGnTcrEMl):
  aWsLSYJwhixfIpHNoXqROvGnTcrEMm=[]
  aWsLSYJwhixfIpHNoXqROvGnTcrEMm.append('Windows') 
  aWsLSYJwhixfIpHNoXqROvGnTcrEMm.append('Chrome') 
  aWsLSYJwhixfIpHNoXqROvGnTcrEMm.append('ko-KR') 
  aWsLSYJwhixfIpHNoXqROvGnTcrEMm.append('undefined') 
  aWsLSYJwhixfIpHNoXqROvGnTcrEMm.append('24') 
  aWsLSYJwhixfIpHNoXqROvGnTcrEMm.append(u'한국 표준시')
  aWsLSYJwhixfIpHNoXqROvGnTcrEMm.append('undefined') 
  aWsLSYJwhixfIpHNoXqROvGnTcrEMm.append('undefined') 
  aWsLSYJwhixfIpHNoXqROvGnTcrEMm.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  aWsLSYJwhixfIpHNoXqROvGnTcrEMe=''
  for aWsLSYJwhixfIpHNoXqROvGnTcrEMt in aWsLSYJwhixfIpHNoXqROvGnTcrEMm:
   aWsLSYJwhixfIpHNoXqROvGnTcrEMe+=aWsLSYJwhixfIpHNoXqROvGnTcrEMt+'|'
  return aWsLSYJwhixfIpHNoXqROvGnTcrEMe
 def SaveCredential(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,aWsLSYJwhixfIpHNoXqROvGnTcrEMQ):
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.TVING_TOKEN =aWsLSYJwhixfIpHNoXqROvGnTcrEMQ.get('tving_token')
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.POC_USERINFO=aWsLSYJwhixfIpHNoXqROvGnTcrEMQ.get('poc_userinfo')
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.TVING_UUID =aWsLSYJwhixfIpHNoXqROvGnTcrEMQ.get('tving_uuid')
 def LoadCredential(aWsLSYJwhixfIpHNoXqROvGnTcrEMl):
  aWsLSYJwhixfIpHNoXqROvGnTcrEMQ={'tving_token':aWsLSYJwhixfIpHNoXqROvGnTcrEMl.TVING_TOKEN,'poc_userinfo':aWsLSYJwhixfIpHNoXqROvGnTcrEMl.POC_USERINFO,'tving_uuid':aWsLSYJwhixfIpHNoXqROvGnTcrEMl.TVING_UUID}
  return aWsLSYJwhixfIpHNoXqROvGnTcrEMQ
 def GetDefaultParams(aWsLSYJwhixfIpHNoXqROvGnTcrEMl):
  aWsLSYJwhixfIpHNoXqROvGnTcrEMC={'apiKey':aWsLSYJwhixfIpHNoXqROvGnTcrEMl.APIKEY,'networkCode':aWsLSYJwhixfIpHNoXqROvGnTcrEMl.NETWORKCODE,'osCode':aWsLSYJwhixfIpHNoXqROvGnTcrEMl.OSCODE,'teleCode':aWsLSYJwhixfIpHNoXqROvGnTcrEMl.TELECODE,'screenCode':aWsLSYJwhixfIpHNoXqROvGnTcrEMl.SCREENCODE}
  return aWsLSYJwhixfIpHNoXqROvGnTcrEMC
 def GetNoCache(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,timetype=1):
  if timetype==1:
   return aWsLSYJwhixfIpHNoXqROvGnTcrElM(time.time())
  else:
   return aWsLSYJwhixfIpHNoXqROvGnTcrElM(time.time()*1000)
 def makeurl(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,domain,path,query1=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,query2=aWsLSYJwhixfIpHNoXqROvGnTcrEjB):
  aWsLSYJwhixfIpHNoXqROvGnTcrEMF=domain+path
  if query1:
   aWsLSYJwhixfIpHNoXqROvGnTcrEMF+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   aWsLSYJwhixfIpHNoXqROvGnTcrEMF+='&%s'%urllib.parse.urlencode(query2)
  return aWsLSYJwhixfIpHNoXqROvGnTcrEMF
 def GetCredential(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,user_id,user_pw,login_type):
  aWsLSYJwhixfIpHNoXqROvGnTcrEMP=aWsLSYJwhixfIpHNoXqROvGnTcrEjV
  aWsLSYJwhixfIpHNoXqROvGnTcrEMb=aWsLSYJwhixfIpHNoXqROvGnTcrEKM='' 
  aWsLSYJwhixfIpHNoXqROvGnTcrEMu='-'
  try:
   aWsLSYJwhixfIpHNoXqROvGnTcrEMU=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   aWsLSYJwhixfIpHNoXqROvGnTcrEMy={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'','csite':''}
   aWsLSYJwhixfIpHNoXqROvGnTcrEMB=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.callRequestCookies('Post',aWsLSYJwhixfIpHNoXqROvGnTcrEMU,payload=aWsLSYJwhixfIpHNoXqROvGnTcrEMy,params=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,cookies=aWsLSYJwhixfIpHNoXqROvGnTcrEjB)
   for aWsLSYJwhixfIpHNoXqROvGnTcrEMV in aWsLSYJwhixfIpHNoXqROvGnTcrEMB.cookies:
    if aWsLSYJwhixfIpHNoXqROvGnTcrEMV.name=='_tving_token':
     aWsLSYJwhixfIpHNoXqROvGnTcrEMb=aWsLSYJwhixfIpHNoXqROvGnTcrEMV.value
    elif aWsLSYJwhixfIpHNoXqROvGnTcrEMV.name=='POC_USERINFO':
     aWsLSYJwhixfIpHNoXqROvGnTcrEKM=aWsLSYJwhixfIpHNoXqROvGnTcrEMV.value
   if aWsLSYJwhixfIpHNoXqROvGnTcrEMb:aWsLSYJwhixfIpHNoXqROvGnTcrEMP=aWsLSYJwhixfIpHNoXqROvGnTcrElK
   aWsLSYJwhixfIpHNoXqROvGnTcrEMu=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetDeviceList(aWsLSYJwhixfIpHNoXqROvGnTcrEMb,aWsLSYJwhixfIpHNoXqROvGnTcrEKM)
  except aWsLSYJwhixfIpHNoXqROvGnTcrElg as exception:
   aWsLSYJwhixfIpHNoXqROvGnTcrEMb=aWsLSYJwhixfIpHNoXqROvGnTcrEKM='' 
   aWsLSYJwhixfIpHNoXqROvGnTcrEMu='-'
   aWsLSYJwhixfIpHNoXqROvGnTcrElj(exception)
  aWsLSYJwhixfIpHNoXqROvGnTcrEMQ={'tving_token':aWsLSYJwhixfIpHNoXqROvGnTcrEMb,'poc_userinfo':aWsLSYJwhixfIpHNoXqROvGnTcrEKM,'tving_uuid':aWsLSYJwhixfIpHNoXqROvGnTcrEMu}
  aWsLSYJwhixfIpHNoXqROvGnTcrEMl.SaveCredential(aWsLSYJwhixfIpHNoXqROvGnTcrEMQ)
  return aWsLSYJwhixfIpHNoXqROvGnTcrEMP
 def Get_Now_Datetime(aWsLSYJwhixfIpHNoXqROvGnTcrEMl):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,mediacode,sel_quality,stype):
  aWsLSYJwhixfIpHNoXqROvGnTcrEKj=''
  aWsLSYJwhixfIpHNoXqROvGnTcrEKl=''
  aWsLSYJwhixfIpHNoXqROvGnTcrEKd=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.TVING_UUID 
  try:
   if stype!='tvingtv':
    aWsLSYJwhixfIpHNoXqROvGnTcrEKk ='/v2/media/stream/info'
    aWsLSYJwhixfIpHNoXqROvGnTcrEKD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetDefaultParams()
    aWsLSYJwhixfIpHNoXqROvGnTcrEKm={'info':'Y','mediaCode':mediacode,'noCache':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetNoCache(1)),'callingFrom':'HTML5','adReq':'none','ooc':'','deviceId':aWsLSYJwhixfIpHNoXqROvGnTcrEKd,'wm':'Y'}
    aWsLSYJwhixfIpHNoXqROvGnTcrEKD.update(aWsLSYJwhixfIpHNoXqROvGnTcrEKm)
    aWsLSYJwhixfIpHNoXqROvGnTcrEMF=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeurl(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.API_DOMAIN,aWsLSYJwhixfIpHNoXqROvGnTcrEKk)
    aWsLSYJwhixfIpHNoXqROvGnTcrEMD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeDefaultCookies()
    aWsLSYJwhixfIpHNoXqROvGnTcrEMB=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.callRequestCookies('Get',aWsLSYJwhixfIpHNoXqROvGnTcrEMF,payload=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,params=aWsLSYJwhixfIpHNoXqROvGnTcrEKD,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,cookies=aWsLSYJwhixfIpHNoXqROvGnTcrEMD)
    aWsLSYJwhixfIpHNoXqROvGnTcrEKe=json.loads(aWsLSYJwhixfIpHNoXqROvGnTcrEMB.text)
    if not('stream' in aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']):return aWsLSYJwhixfIpHNoXqROvGnTcrEKj,aWsLSYJwhixfIpHNoXqROvGnTcrEKl 
    aWsLSYJwhixfIpHNoXqROvGnTcrEKt=aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']['stream']
    if 'drm_license_assertion' in aWsLSYJwhixfIpHNoXqROvGnTcrEKt:
     aWsLSYJwhixfIpHNoXqROvGnTcrEKl=aWsLSYJwhixfIpHNoXqROvGnTcrEKt['drm_license_assertion']
    aWsLSYJwhixfIpHNoXqROvGnTcrEKQ=aWsLSYJwhixfIpHNoXqROvGnTcrEKt['quality']
    aWsLSYJwhixfIpHNoXqROvGnTcrEKC=[]
    for aWsLSYJwhixfIpHNoXqROvGnTcrEKF in aWsLSYJwhixfIpHNoXqROvGnTcrEKQ:
     if aWsLSYJwhixfIpHNoXqROvGnTcrEKF['active']=='Y':
      aWsLSYJwhixfIpHNoXqROvGnTcrEKC.append({aWsLSYJwhixfIpHNoXqROvGnTcrEMj.get(aWsLSYJwhixfIpHNoXqROvGnTcrEKF['code']):aWsLSYJwhixfIpHNoXqROvGnTcrEKF['code']})
    aWsLSYJwhixfIpHNoXqROvGnTcrEKz=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.CheckQuality(sel_quality,aWsLSYJwhixfIpHNoXqROvGnTcrEKC)
   else:
    for aWsLSYJwhixfIpHNoXqROvGnTcrEKA,aWsLSYJwhixfIpHNoXqROvGnTcrEgM in aWsLSYJwhixfIpHNoXqROvGnTcrEMj.items():
     if aWsLSYJwhixfIpHNoXqROvGnTcrEgM==sel_quality:
      aWsLSYJwhixfIpHNoXqROvGnTcrEKz=aWsLSYJwhixfIpHNoXqROvGnTcrEKA
  except aWsLSYJwhixfIpHNoXqROvGnTcrElg as exception:
   aWsLSYJwhixfIpHNoXqROvGnTcrElj(exception)
   for aWsLSYJwhixfIpHNoXqROvGnTcrEKA,aWsLSYJwhixfIpHNoXqROvGnTcrEgM in aWsLSYJwhixfIpHNoXqROvGnTcrEMj.items():
    if aWsLSYJwhixfIpHNoXqROvGnTcrEgM==sel_quality:
     aWsLSYJwhixfIpHNoXqROvGnTcrEKz=aWsLSYJwhixfIpHNoXqROvGnTcrEKA
   return aWsLSYJwhixfIpHNoXqROvGnTcrEKj,aWsLSYJwhixfIpHNoXqROvGnTcrEKl
  try:
   aWsLSYJwhixfIpHNoXqROvGnTcrEKk ='/streaming/info'
   aWsLSYJwhixfIpHNoXqROvGnTcrEKD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetDefaultParams()
   if stype=='onair':aWsLSYJwhixfIpHNoXqROvGnTcrEKD['osCode']='CSOD0400' 
   aWsLSYJwhixfIpHNoXqROvGnTcrEKP={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2158.7350000045262','returnValue':'true','cancelBubble':'false'}
   aWsLSYJwhixfIpHNoXqROvGnTcrEKb=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeOocUrl(aWsLSYJwhixfIpHNoXqROvGnTcrEKP)
   aWsLSYJwhixfIpHNoXqROvGnTcrEKu=urllib.parse.quote(aWsLSYJwhixfIpHNoXqROvGnTcrEKb)
   aWsLSYJwhixfIpHNoXqROvGnTcrEKm={'info':'Y','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':aWsLSYJwhixfIpHNoXqROvGnTcrEKz,'adReq':'none','ooc':aWsLSYJwhixfIpHNoXqROvGnTcrEKb,'deviceId':aWsLSYJwhixfIpHNoXqROvGnTcrEKd}
   aWsLSYJwhixfIpHNoXqROvGnTcrEKU =aWsLSYJwhixfIpHNoXqROvGnTcrEKD
   aWsLSYJwhixfIpHNoXqROvGnTcrEKU.update(aWsLSYJwhixfIpHNoXqROvGnTcrEKm)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMF=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.URL_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEKk
   aWsLSYJwhixfIpHNoXqROvGnTcrEKy={'origin':'https://www.tving.com','Referer':'https://www.tving.com/vod/player/'+mediacode}
   aWsLSYJwhixfIpHNoXqROvGnTcrEMD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeDefaultCookies()
   aWsLSYJwhixfIpHNoXqROvGnTcrEMD['onClickEvent2']=aWsLSYJwhixfIpHNoXqROvGnTcrEKu
   aWsLSYJwhixfIpHNoXqROvGnTcrEMB=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.callRequestCookies('Post',aWsLSYJwhixfIpHNoXqROvGnTcrEMF,payload=aWsLSYJwhixfIpHNoXqROvGnTcrEKU,params=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEKy,cookies=aWsLSYJwhixfIpHNoXqROvGnTcrEMD)
   aWsLSYJwhixfIpHNoXqROvGnTcrEKe=json.loads(aWsLSYJwhixfIpHNoXqROvGnTcrEMB.text)
   if aWsLSYJwhixfIpHNoXqROvGnTcrEKl!='':
    aWsLSYJwhixfIpHNoXqROvGnTcrEKl =aWsLSYJwhixfIpHNoXqROvGnTcrEKe['stream']['drm_license_assertion']
    aWsLSYJwhixfIpHNoXqROvGnTcrEKj=aWsLSYJwhixfIpHNoXqROvGnTcrEKe['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in aWsLSYJwhixfIpHNoXqROvGnTcrEKe['stream']['broadcast']):return aWsLSYJwhixfIpHNoXqROvGnTcrEKj,aWsLSYJwhixfIpHNoXqROvGnTcrEKl
    aWsLSYJwhixfIpHNoXqROvGnTcrEKj=aWsLSYJwhixfIpHNoXqROvGnTcrEKe['stream']['broadcast']['broad_url']
  except aWsLSYJwhixfIpHNoXqROvGnTcrElg as exception:
   aWsLSYJwhixfIpHNoXqROvGnTcrElj(exception)
  return aWsLSYJwhixfIpHNoXqROvGnTcrEKj,aWsLSYJwhixfIpHNoXqROvGnTcrEKl
 def CheckQuality(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,sel_qt,aWsLSYJwhixfIpHNoXqROvGnTcrEKC):
  for aWsLSYJwhixfIpHNoXqROvGnTcrEKB in aWsLSYJwhixfIpHNoXqROvGnTcrEKC:
   if sel_qt>=aWsLSYJwhixfIpHNoXqROvGnTcrElk(aWsLSYJwhixfIpHNoXqROvGnTcrEKB)[0]:return aWsLSYJwhixfIpHNoXqROvGnTcrEKB.get(aWsLSYJwhixfIpHNoXqROvGnTcrElk(aWsLSYJwhixfIpHNoXqROvGnTcrEKB)[0])
   aWsLSYJwhixfIpHNoXqROvGnTcrEKV=aWsLSYJwhixfIpHNoXqROvGnTcrEKB.get(aWsLSYJwhixfIpHNoXqROvGnTcrElk(aWsLSYJwhixfIpHNoXqROvGnTcrEKB)[0])
  return aWsLSYJwhixfIpHNoXqROvGnTcrEKV
 def makeOocUrl(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,aWsLSYJwhixfIpHNoXqROvGnTcrEKP):
  aWsLSYJwhixfIpHNoXqROvGnTcrEMF=''
  for aWsLSYJwhixfIpHNoXqROvGnTcrEKA,aWsLSYJwhixfIpHNoXqROvGnTcrEgM in aWsLSYJwhixfIpHNoXqROvGnTcrEKP.items():
   aWsLSYJwhixfIpHNoXqROvGnTcrEMF+="%s=%s^"%(aWsLSYJwhixfIpHNoXqROvGnTcrEKA,aWsLSYJwhixfIpHNoXqROvGnTcrEgM)
  return aWsLSYJwhixfIpHNoXqROvGnTcrEMF
 def GetLiveChannelList(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,stype,page_int):
  aWsLSYJwhixfIpHNoXqROvGnTcrEgK=[]
  aWsLSYJwhixfIpHNoXqROvGnTcrEgj=aWsLSYJwhixfIpHNoXqROvGnTcrEjV
  try:
   aWsLSYJwhixfIpHNoXqROvGnTcrEKk ='/v2/media/lives'
   if stype=='onair':
    aWsLSYJwhixfIpHNoXqROvGnTcrEgl='CPCS0100,CPCS0400'
   else:
    aWsLSYJwhixfIpHNoXqROvGnTcrEgl='CPCS0300'
   aWsLSYJwhixfIpHNoXqROvGnTcrEKD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetDefaultParams()
   aWsLSYJwhixfIpHNoXqROvGnTcrEKm={'pageNo':aWsLSYJwhixfIpHNoXqROvGnTcrEld(page_int),'pageSize':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':aWsLSYJwhixfIpHNoXqROvGnTcrEgl,'_':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetNoCache(2))}
   aWsLSYJwhixfIpHNoXqROvGnTcrEKD.update(aWsLSYJwhixfIpHNoXqROvGnTcrEKm)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMF=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeurl(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.API_DOMAIN,aWsLSYJwhixfIpHNoXqROvGnTcrEKk)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeDefaultCookies()
   aWsLSYJwhixfIpHNoXqROvGnTcrEMB=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.callRequestCookies('Get',aWsLSYJwhixfIpHNoXqROvGnTcrEMF,payload=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,params=aWsLSYJwhixfIpHNoXqROvGnTcrEKD,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,cookies=aWsLSYJwhixfIpHNoXqROvGnTcrEMD)
   aWsLSYJwhixfIpHNoXqROvGnTcrEKe=json.loads(aWsLSYJwhixfIpHNoXqROvGnTcrEMB.text)
   if not('result' in aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']):return aWsLSYJwhixfIpHNoXqROvGnTcrEgK,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
   aWsLSYJwhixfIpHNoXqROvGnTcrEgd=aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']['result']
   for aWsLSYJwhixfIpHNoXqROvGnTcrEKF in aWsLSYJwhixfIpHNoXqROvGnTcrEgd:
    aWsLSYJwhixfIpHNoXqROvGnTcrEgk={}
    aWsLSYJwhixfIpHNoXqROvGnTcrEgk['mediatype']='video'
    aWsLSYJwhixfIpHNoXqROvGnTcrEgD=aWsLSYJwhixfIpHNoXqROvGnTcrEgt=aWsLSYJwhixfIpHNoXqROvGnTcrEgQ=aWsLSYJwhixfIpHNoXqROvGnTcrEgC=''
    aWsLSYJwhixfIpHNoXqROvGnTcrEgm=aWsLSYJwhixfIpHNoXqROvGnTcrEgP=''
    aWsLSYJwhixfIpHNoXqROvGnTcrEge=aWsLSYJwhixfIpHNoXqROvGnTcrEKF['live_code']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgD =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['channel']['name']['ko']
    if aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['episode']!=aWsLSYJwhixfIpHNoXqROvGnTcrEjB:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgt =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['program']['name']['ko']
     aWsLSYJwhixfIpHNoXqROvGnTcrEgt =aWsLSYJwhixfIpHNoXqROvGnTcrEgt+', '+aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['episode']['frequency'])+'회'
     if aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['episode']['image']!=[]:
      aWsLSYJwhixfIpHNoXqROvGnTcrEgQ=aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['episode']['image'][0]['url']
     aWsLSYJwhixfIpHNoXqROvGnTcrEgC=aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['episode']['synopsis']['ko']
    else:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgt =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['program']['name']['ko']
     if aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['program']['image']!=[]:
      aWsLSYJwhixfIpHNoXqROvGnTcrEgQ=aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['program']['image'][0]['url']
     aWsLSYJwhixfIpHNoXqROvGnTcrEgC=aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['program']['synopsis']['ko']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgk['title'] =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['program']['name']['ko']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgk['studio'] =aWsLSYJwhixfIpHNoXqROvGnTcrEgD
    try:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgF=[]
     for aWsLSYJwhixfIpHNoXqROvGnTcrEgz in aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('schedule').get('program').get('actor'):aWsLSYJwhixfIpHNoXqROvGnTcrEgF.append(aWsLSYJwhixfIpHNoXqROvGnTcrEgz)
     if aWsLSYJwhixfIpHNoXqROvGnTcrEgF[0]!='' and aWsLSYJwhixfIpHNoXqROvGnTcrEgF[0]!=u'없음':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['cast']=aWsLSYJwhixfIpHNoXqROvGnTcrEgF
    except:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjB
    try:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgA=[]
     if aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('schedule').get('program').get('category1_name').get('ko')!='':
      aWsLSYJwhixfIpHNoXqROvGnTcrEgA.append(aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['program']['category1_name']['ko'])
     if aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('schedule').get('program').get('category2_name').get('ko')!='':
      aWsLSYJwhixfIpHNoXqROvGnTcrEgA.append(aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['program']['category2_name']['ko'])
     if aWsLSYJwhixfIpHNoXqROvGnTcrEgA[0]!='':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['genre']=aWsLSYJwhixfIpHNoXqROvGnTcrEgA
    except:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjB
    if aWsLSYJwhixfIpHNoXqROvGnTcrEgQ=='':
     aWsLSYJwhixfIpHNoXqROvGnTcrEgQ=aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['channel']['image'][0]['url']
    if aWsLSYJwhixfIpHNoXqROvGnTcrEgQ!='':aWsLSYJwhixfIpHNoXqROvGnTcrEgQ=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEgQ
    aWsLSYJwhixfIpHNoXqROvGnTcrEgm=aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['broadcast_start_time'])[8:12]
    aWsLSYJwhixfIpHNoXqROvGnTcrEgP =aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEKF['schedule']['broadcast_end_time'])[8:12]
    aWsLSYJwhixfIpHNoXqROvGnTcrEgb={'channel':aWsLSYJwhixfIpHNoXqROvGnTcrEgD,'title':aWsLSYJwhixfIpHNoXqROvGnTcrEgt,'mediacode':aWsLSYJwhixfIpHNoXqROvGnTcrEge,'thumbnail':aWsLSYJwhixfIpHNoXqROvGnTcrEgQ,'synopsis':aWsLSYJwhixfIpHNoXqROvGnTcrEgC,'channelepg':' [%s:%s ~ %s:%s]'%(aWsLSYJwhixfIpHNoXqROvGnTcrEgm[0:2],aWsLSYJwhixfIpHNoXqROvGnTcrEgm[2:],aWsLSYJwhixfIpHNoXqROvGnTcrEgP[0:2],aWsLSYJwhixfIpHNoXqROvGnTcrEgP[2:]),'info':aWsLSYJwhixfIpHNoXqROvGnTcrEgk}
    aWsLSYJwhixfIpHNoXqROvGnTcrEgK.append(aWsLSYJwhixfIpHNoXqROvGnTcrEgb)
   if aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']['has_more']=='Y':aWsLSYJwhixfIpHNoXqROvGnTcrEgj=aWsLSYJwhixfIpHNoXqROvGnTcrElK
  except aWsLSYJwhixfIpHNoXqROvGnTcrElg as exception:
   aWsLSYJwhixfIpHNoXqROvGnTcrElj(exception)
  return aWsLSYJwhixfIpHNoXqROvGnTcrEgK,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
 def GetProgramList(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,stype,orderby,page_int,landyn=aWsLSYJwhixfIpHNoXqROvGnTcrEjV):
  aWsLSYJwhixfIpHNoXqROvGnTcrEgK=[]
  aWsLSYJwhixfIpHNoXqROvGnTcrEgj=aWsLSYJwhixfIpHNoXqROvGnTcrEjV
  try:
   aWsLSYJwhixfIpHNoXqROvGnTcrEKk ='/v2/media/episodes'
   aWsLSYJwhixfIpHNoXqROvGnTcrEKD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetDefaultParams()
   aWsLSYJwhixfIpHNoXqROvGnTcrEKm={'pageNo':aWsLSYJwhixfIpHNoXqROvGnTcrEld(page_int),'pageSize':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetNoCache(2))}
   if stype!='all':aWsLSYJwhixfIpHNoXqROvGnTcrEKm['multiCategoryCode']=stype
   aWsLSYJwhixfIpHNoXqROvGnTcrEKD.update(aWsLSYJwhixfIpHNoXqROvGnTcrEKm)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMF=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeurl(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.API_DOMAIN,aWsLSYJwhixfIpHNoXqROvGnTcrEKk)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeDefaultCookies()
   aWsLSYJwhixfIpHNoXqROvGnTcrEMB=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.callRequestCookies('Get',aWsLSYJwhixfIpHNoXqROvGnTcrEMF,payload=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,params=aWsLSYJwhixfIpHNoXqROvGnTcrEKD,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,cookies=aWsLSYJwhixfIpHNoXqROvGnTcrEMD)
   aWsLSYJwhixfIpHNoXqROvGnTcrEKe=json.loads(aWsLSYJwhixfIpHNoXqROvGnTcrEMB.text)
   if not('result' in aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']):return aWsLSYJwhixfIpHNoXqROvGnTcrEgK,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
   aWsLSYJwhixfIpHNoXqROvGnTcrEgd=aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']['result']
   for aWsLSYJwhixfIpHNoXqROvGnTcrEKF in aWsLSYJwhixfIpHNoXqROvGnTcrEgd:
    aWsLSYJwhixfIpHNoXqROvGnTcrEgu=aWsLSYJwhixfIpHNoXqROvGnTcrEKF['program']['code']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgt =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['program']['name']['ko']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgQ =aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEKF['program']['image'][0]['url']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgU='CAIP0200' if landyn else 'CAIP0900' 
    for aWsLSYJwhixfIpHNoXqROvGnTcrEgy in aWsLSYJwhixfIpHNoXqROvGnTcrEKF['program']['image']:
     if aWsLSYJwhixfIpHNoXqROvGnTcrEgy['code']==aWsLSYJwhixfIpHNoXqROvGnTcrEgU:
      aWsLSYJwhixfIpHNoXqROvGnTcrEgQ =aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEgy['url']
      break
    aWsLSYJwhixfIpHNoXqROvGnTcrEgC =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['program']['synopsis']['ko']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgB=aWsLSYJwhixfIpHNoXqROvGnTcrEKF['program']['channel_code']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgk={}
    aWsLSYJwhixfIpHNoXqROvGnTcrEgk['title'] =aWsLSYJwhixfIpHNoXqROvGnTcrEgt 
    aWsLSYJwhixfIpHNoXqROvGnTcrEgk['mediatype']='episode' 
    try:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgF=[]
     for aWsLSYJwhixfIpHNoXqROvGnTcrEgz in aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('program').get('actor'):aWsLSYJwhixfIpHNoXqROvGnTcrEgF.append(aWsLSYJwhixfIpHNoXqROvGnTcrEgz)
     if aWsLSYJwhixfIpHNoXqROvGnTcrEgF[0]!='' and aWsLSYJwhixfIpHNoXqROvGnTcrEgF[0]!='-':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['cast']=aWsLSYJwhixfIpHNoXqROvGnTcrEgF
    except:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjB
    try:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgV=[]
     for aWsLSYJwhixfIpHNoXqROvGnTcrEjM in aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('program').get('director'):aWsLSYJwhixfIpHNoXqROvGnTcrEgV.append(aWsLSYJwhixfIpHNoXqROvGnTcrEjM)
     if aWsLSYJwhixfIpHNoXqROvGnTcrEgV[0]!='' and aWsLSYJwhixfIpHNoXqROvGnTcrEgV[0]!='-':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['director']=aWsLSYJwhixfIpHNoXqROvGnTcrEgV
    except:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjB
    aWsLSYJwhixfIpHNoXqROvGnTcrEgA=[]
    if aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('program').get('category1_name').get('ko')!='':
     aWsLSYJwhixfIpHNoXqROvGnTcrEgA.append(aWsLSYJwhixfIpHNoXqROvGnTcrEKF['program']['category1_name']['ko'])
    if aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('program').get('category2_name').get('ko')!='':
     aWsLSYJwhixfIpHNoXqROvGnTcrEgA.append(aWsLSYJwhixfIpHNoXqROvGnTcrEKF['program']['category2_name']['ko'])
    if aWsLSYJwhixfIpHNoXqROvGnTcrEgA[0]!='':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['genre']=aWsLSYJwhixfIpHNoXqROvGnTcrEgA
    try:
     if aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('program').get('product_year'):aWsLSYJwhixfIpHNoXqROvGnTcrEgk['year']=aWsLSYJwhixfIpHNoXqROvGnTcrEKF['program']['product_year']
     if 'broad_dt' in aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('program'):
      aWsLSYJwhixfIpHNoXqROvGnTcrEjK=aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('program').get('broad_dt')
      aWsLSYJwhixfIpHNoXqROvGnTcrEgk['aired']='%s-%s-%s'%(aWsLSYJwhixfIpHNoXqROvGnTcrEjK[:4],aWsLSYJwhixfIpHNoXqROvGnTcrEjK[4:6],aWsLSYJwhixfIpHNoXqROvGnTcrEjK[6:])
    except:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjB
    aWsLSYJwhixfIpHNoXqROvGnTcrEgb={'program':aWsLSYJwhixfIpHNoXqROvGnTcrEgu,'title':aWsLSYJwhixfIpHNoXqROvGnTcrEgt,'thumbnail':aWsLSYJwhixfIpHNoXqROvGnTcrEgQ,'synopsis':aWsLSYJwhixfIpHNoXqROvGnTcrEgC,'channel':aWsLSYJwhixfIpHNoXqROvGnTcrEgB,'info':aWsLSYJwhixfIpHNoXqROvGnTcrEgk}
    aWsLSYJwhixfIpHNoXqROvGnTcrEgK.append(aWsLSYJwhixfIpHNoXqROvGnTcrEgb)
   if aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']['has_more']=='Y':aWsLSYJwhixfIpHNoXqROvGnTcrEgj=aWsLSYJwhixfIpHNoXqROvGnTcrElK
  except aWsLSYJwhixfIpHNoXqROvGnTcrElg as exception:
   aWsLSYJwhixfIpHNoXqROvGnTcrElj(exception)
  return aWsLSYJwhixfIpHNoXqROvGnTcrEgK,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
 def GetEpisodoList(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,program_code,page_int,orderby='desc'):
  aWsLSYJwhixfIpHNoXqROvGnTcrEgK=[]
  aWsLSYJwhixfIpHNoXqROvGnTcrEgj=aWsLSYJwhixfIpHNoXqROvGnTcrEjV
  try:
   aWsLSYJwhixfIpHNoXqROvGnTcrEKk ='/v2/media/frequency/program/'+program_code
   aWsLSYJwhixfIpHNoXqROvGnTcrEKD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetDefaultParams()
   aWsLSYJwhixfIpHNoXqROvGnTcrEKm={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetNoCache(2))}
   aWsLSYJwhixfIpHNoXqROvGnTcrEKD.update(aWsLSYJwhixfIpHNoXqROvGnTcrEKm)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMF=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeurl(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.API_DOMAIN,aWsLSYJwhixfIpHNoXqROvGnTcrEKk)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeDefaultCookies()
   aWsLSYJwhixfIpHNoXqROvGnTcrEMB=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.callRequestCookies('Get',aWsLSYJwhixfIpHNoXqROvGnTcrEMF,payload=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,params=aWsLSYJwhixfIpHNoXqROvGnTcrEKD,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,cookies=aWsLSYJwhixfIpHNoXqROvGnTcrEMD)
   aWsLSYJwhixfIpHNoXqROvGnTcrEKe=json.loads(aWsLSYJwhixfIpHNoXqROvGnTcrEMB.text)
   if not('result' in aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']):return aWsLSYJwhixfIpHNoXqROvGnTcrEgK,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
   aWsLSYJwhixfIpHNoXqROvGnTcrEgd=aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']['result']
   aWsLSYJwhixfIpHNoXqROvGnTcrEjg=aWsLSYJwhixfIpHNoXqROvGnTcrElM(aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']['total_count'])
   aWsLSYJwhixfIpHNoXqROvGnTcrEjl =aWsLSYJwhixfIpHNoXqROvGnTcrElM(aWsLSYJwhixfIpHNoXqROvGnTcrEjg//(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    aWsLSYJwhixfIpHNoXqROvGnTcrEjd =(aWsLSYJwhixfIpHNoXqROvGnTcrEjg-1)-((page_int-1)*aWsLSYJwhixfIpHNoXqROvGnTcrEMl.EPISODE_LIMIT)
   else:
    aWsLSYJwhixfIpHNoXqROvGnTcrEjd =(page_int-1)*aWsLSYJwhixfIpHNoXqROvGnTcrEMl.EPISODE_LIMIT
   for i in aWsLSYJwhixfIpHNoXqROvGnTcrElD(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.EPISODE_LIMIT):
    if orderby=='desc':
     aWsLSYJwhixfIpHNoXqROvGnTcrEjk=aWsLSYJwhixfIpHNoXqROvGnTcrEjd-i
     if aWsLSYJwhixfIpHNoXqROvGnTcrEjk<0:break
    else:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjk=aWsLSYJwhixfIpHNoXqROvGnTcrEjd+i
     if aWsLSYJwhixfIpHNoXqROvGnTcrEjk>=aWsLSYJwhixfIpHNoXqROvGnTcrEjg:break
    aWsLSYJwhixfIpHNoXqROvGnTcrEjD=aWsLSYJwhixfIpHNoXqROvGnTcrEgd[aWsLSYJwhixfIpHNoXqROvGnTcrEjk]['episode']['code']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgt =aWsLSYJwhixfIpHNoXqROvGnTcrEgd[aWsLSYJwhixfIpHNoXqROvGnTcrEjk]['vod_name']['ko']
    aWsLSYJwhixfIpHNoXqROvGnTcrEjm =''
    try:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjK=aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEgd[aWsLSYJwhixfIpHNoXqROvGnTcrEjk]['episode']['broadcast_date'])
     aWsLSYJwhixfIpHNoXqROvGnTcrEjm='%s-%s-%s'%(aWsLSYJwhixfIpHNoXqROvGnTcrEjK[:4],aWsLSYJwhixfIpHNoXqROvGnTcrEjK[4:6],aWsLSYJwhixfIpHNoXqROvGnTcrEjK[6:])
    except:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjB
    if aWsLSYJwhixfIpHNoXqROvGnTcrEgd[aWsLSYJwhixfIpHNoXqROvGnTcrEjk]['episode']['image']!=[]:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgQ=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEgd[aWsLSYJwhixfIpHNoXqROvGnTcrEjk]['episode']['image'][0]['url']
    else:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgQ=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEgd[aWsLSYJwhixfIpHNoXqROvGnTcrEjk]['program']['image'][0]['url']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgC =aWsLSYJwhixfIpHNoXqROvGnTcrEgd[aWsLSYJwhixfIpHNoXqROvGnTcrEjk]['episode']['synopsis']['ko']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgk={}
    aWsLSYJwhixfIpHNoXqROvGnTcrEgk['mediatype']='episode' 
    try:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgk['title'] =aWsLSYJwhixfIpHNoXqROvGnTcrEgd[aWsLSYJwhixfIpHNoXqROvGnTcrEjk]['program']['name']['ko']
     aWsLSYJwhixfIpHNoXqROvGnTcrEgk['aired'] =aWsLSYJwhixfIpHNoXqROvGnTcrEjm
     aWsLSYJwhixfIpHNoXqROvGnTcrEgk['studio'] =aWsLSYJwhixfIpHNoXqROvGnTcrEgd[aWsLSYJwhixfIpHNoXqROvGnTcrEjk]['channel']['name']['ko']
     if 'frequency' in aWsLSYJwhixfIpHNoXqROvGnTcrEgd[aWsLSYJwhixfIpHNoXqROvGnTcrEjk]['episode']:aWsLSYJwhixfIpHNoXqROvGnTcrEgk['episode']=aWsLSYJwhixfIpHNoXqROvGnTcrEgd[aWsLSYJwhixfIpHNoXqROvGnTcrEjk]['episode']['frequency']
    except:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjB
    aWsLSYJwhixfIpHNoXqROvGnTcrEgb={'episode':aWsLSYJwhixfIpHNoXqROvGnTcrEjD,'title':aWsLSYJwhixfIpHNoXqROvGnTcrEgt,'subtitle':aWsLSYJwhixfIpHNoXqROvGnTcrEjm,'thumbnail':aWsLSYJwhixfIpHNoXqROvGnTcrEgQ,'synopsis':aWsLSYJwhixfIpHNoXqROvGnTcrEgC,'info':aWsLSYJwhixfIpHNoXqROvGnTcrEgk}
    aWsLSYJwhixfIpHNoXqROvGnTcrEgK.append(aWsLSYJwhixfIpHNoXqROvGnTcrEgb)
   if aWsLSYJwhixfIpHNoXqROvGnTcrEjl>page_int:aWsLSYJwhixfIpHNoXqROvGnTcrEgj=aWsLSYJwhixfIpHNoXqROvGnTcrElK
  except aWsLSYJwhixfIpHNoXqROvGnTcrElg as exception:
   aWsLSYJwhixfIpHNoXqROvGnTcrElj(exception)
  return aWsLSYJwhixfIpHNoXqROvGnTcrEgK,aWsLSYJwhixfIpHNoXqROvGnTcrEgj,aWsLSYJwhixfIpHNoXqROvGnTcrEjl
 def GetMovieList(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,orderby,page_int,premiumyn=aWsLSYJwhixfIpHNoXqROvGnTcrEjV,landyn=aWsLSYJwhixfIpHNoXqROvGnTcrEjV):
  aWsLSYJwhixfIpHNoXqROvGnTcrEgK=[]
  aWsLSYJwhixfIpHNoXqROvGnTcrEgj=aWsLSYJwhixfIpHNoXqROvGnTcrEjV
  if premiumyn==aWsLSYJwhixfIpHNoXqROvGnTcrElK:
   aWsLSYJwhixfIpHNoXqROvGnTcrEje=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.MOVIE_LITE+','+aWsLSYJwhixfIpHNoXqROvGnTcrEMl.MOVIE_PREMIUM
  else:
   aWsLSYJwhixfIpHNoXqROvGnTcrEje=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.MOVIE_LITE
  try:
   aWsLSYJwhixfIpHNoXqROvGnTcrEKk ='/v2/media/movies'
   aWsLSYJwhixfIpHNoXqROvGnTcrEKD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetDefaultParams()
   aWsLSYJwhixfIpHNoXqROvGnTcrEKm={'pageNo':aWsLSYJwhixfIpHNoXqROvGnTcrEld(page_int),'pageSize':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','productPackageCode':aWsLSYJwhixfIpHNoXqROvGnTcrEje,'_':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetNoCache(2))}
   aWsLSYJwhixfIpHNoXqROvGnTcrEKD.update(aWsLSYJwhixfIpHNoXqROvGnTcrEKm)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMF=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeurl(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.API_DOMAIN,aWsLSYJwhixfIpHNoXqROvGnTcrEKk)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeDefaultCookies()
   aWsLSYJwhixfIpHNoXqROvGnTcrEMB=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.callRequestCookies('Get',aWsLSYJwhixfIpHNoXqROvGnTcrEMF,payload=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,params=aWsLSYJwhixfIpHNoXqROvGnTcrEKD,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,cookies=aWsLSYJwhixfIpHNoXqROvGnTcrEMD)
   aWsLSYJwhixfIpHNoXqROvGnTcrEKe=json.loads(aWsLSYJwhixfIpHNoXqROvGnTcrEMB.text)
   if not('result' in aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']):return aWsLSYJwhixfIpHNoXqROvGnTcrEgK,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
   aWsLSYJwhixfIpHNoXqROvGnTcrEgd=aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']['result']
   for aWsLSYJwhixfIpHNoXqROvGnTcrEKF in aWsLSYJwhixfIpHNoXqROvGnTcrEgd:
    aWsLSYJwhixfIpHNoXqROvGnTcrEjt =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['movie']['code']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgt =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['movie']['name']['ko'].strip()
    aWsLSYJwhixfIpHNoXqROvGnTcrEgt +=u' (%s년)'%(aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('movie').get('product_year'))
    aWsLSYJwhixfIpHNoXqROvGnTcrEgQ =aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEKF['movie']['image'][0]['url']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgU='CAIM0400' if landyn else 'CAIM2100' 
    for aWsLSYJwhixfIpHNoXqROvGnTcrEgy in aWsLSYJwhixfIpHNoXqROvGnTcrEKF['movie']['image']:
     if aWsLSYJwhixfIpHNoXqROvGnTcrEgy['code']==aWsLSYJwhixfIpHNoXqROvGnTcrEgU:
      aWsLSYJwhixfIpHNoXqROvGnTcrEgQ =aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEgy['url']
      break
    aWsLSYJwhixfIpHNoXqROvGnTcrEgC =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['movie']['story']['ko']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgk={}
    aWsLSYJwhixfIpHNoXqROvGnTcrEgk['mediatype']='movie' 
    aWsLSYJwhixfIpHNoXqROvGnTcrEgk['title'] = aWsLSYJwhixfIpHNoXqROvGnTcrEKF['movie']['name']['ko'].strip()
    aWsLSYJwhixfIpHNoXqROvGnTcrEgk['year'] =aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('movie').get('product_year')
    try:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgF=[]
     for aWsLSYJwhixfIpHNoXqROvGnTcrEgz in aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('movie').get('actor'):aWsLSYJwhixfIpHNoXqROvGnTcrEgF.append(aWsLSYJwhixfIpHNoXqROvGnTcrEgz)
     if aWsLSYJwhixfIpHNoXqROvGnTcrEgF[0]!='':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['cast']=aWsLSYJwhixfIpHNoXqROvGnTcrEgF
    except:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjB
    try:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgV=[]
     for aWsLSYJwhixfIpHNoXqROvGnTcrEjM in aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('movie').get('director'):aWsLSYJwhixfIpHNoXqROvGnTcrEgV.append(aWsLSYJwhixfIpHNoXqROvGnTcrEjM)
     if aWsLSYJwhixfIpHNoXqROvGnTcrEgV[0]!='':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['director']=aWsLSYJwhixfIpHNoXqROvGnTcrEgV
    except:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjB
    try:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgA=[]
     if aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('movie').get('category1_name').get('ko')!='':
      aWsLSYJwhixfIpHNoXqROvGnTcrEgA.append(aWsLSYJwhixfIpHNoXqROvGnTcrEKF['movie']['category1_name']['ko'])
     if aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('movie').get('category2_name').get('ko')!='':
      aWsLSYJwhixfIpHNoXqROvGnTcrEgA.append(aWsLSYJwhixfIpHNoXqROvGnTcrEKF['movie']['category2_name']['ko'])
     if aWsLSYJwhixfIpHNoXqROvGnTcrEgA[0]!='':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['genre']=aWsLSYJwhixfIpHNoXqROvGnTcrEgA
    except:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjB
    try:
     if 'release_date' in aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('movie'):
      aWsLSYJwhixfIpHNoXqROvGnTcrEjK=aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('movie').get('release_date'))
      aWsLSYJwhixfIpHNoXqROvGnTcrEgk['aired']='%s-%s-%s'%(aWsLSYJwhixfIpHNoXqROvGnTcrEjK[:4],aWsLSYJwhixfIpHNoXqROvGnTcrEjK[4:6],aWsLSYJwhixfIpHNoXqROvGnTcrEjK[6:])
    except:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjB
    try:
     if 'duration' in aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('movie'):aWsLSYJwhixfIpHNoXqROvGnTcrEgk['duration']=aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('movie').get('duration')
    except:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjB
    aWsLSYJwhixfIpHNoXqROvGnTcrEgb={'moviecode':aWsLSYJwhixfIpHNoXqROvGnTcrEjt,'title':aWsLSYJwhixfIpHNoXqROvGnTcrEgt,'thumbnail':aWsLSYJwhixfIpHNoXqROvGnTcrEgQ,'synopsis':aWsLSYJwhixfIpHNoXqROvGnTcrEgC,'info':aWsLSYJwhixfIpHNoXqROvGnTcrEgk}
    if premiumyn==aWsLSYJwhixfIpHNoXqROvGnTcrElK:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjQ=aWsLSYJwhixfIpHNoXqROvGnTcrEjV
     for aWsLSYJwhixfIpHNoXqROvGnTcrEjC in aWsLSYJwhixfIpHNoXqROvGnTcrEKF['billing_package_id']:
      if aWsLSYJwhixfIpHNoXqROvGnTcrEjC==aWsLSYJwhixfIpHNoXqROvGnTcrEMl.MOVIE_LITE:
       aWsLSYJwhixfIpHNoXqROvGnTcrEjQ=aWsLSYJwhixfIpHNoXqROvGnTcrElK
       break
     if aWsLSYJwhixfIpHNoXqROvGnTcrEjQ==aWsLSYJwhixfIpHNoXqROvGnTcrEjV:
      aWsLSYJwhixfIpHNoXqROvGnTcrEgb['title']=aWsLSYJwhixfIpHNoXqROvGnTcrEgb['title']+' [Premium]'
    aWsLSYJwhixfIpHNoXqROvGnTcrEgK.append(aWsLSYJwhixfIpHNoXqROvGnTcrEgb)
   if aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']['has_more']=='Y':aWsLSYJwhixfIpHNoXqROvGnTcrEgj=aWsLSYJwhixfIpHNoXqROvGnTcrElK
  except aWsLSYJwhixfIpHNoXqROvGnTcrElg as exception:
   aWsLSYJwhixfIpHNoXqROvGnTcrElj(exception)
  return aWsLSYJwhixfIpHNoXqROvGnTcrEgK,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
 def GetMovieListGenre(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,genre,page_int,premiumyn=aWsLSYJwhixfIpHNoXqROvGnTcrEjV):
  aWsLSYJwhixfIpHNoXqROvGnTcrEgK=[]
  aWsLSYJwhixfIpHNoXqROvGnTcrEgj=aWsLSYJwhixfIpHNoXqROvGnTcrEjV
  if premiumyn==aWsLSYJwhixfIpHNoXqROvGnTcrElK:
   aWsLSYJwhixfIpHNoXqROvGnTcrEje=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.MOVIE_LITE+','+aWsLSYJwhixfIpHNoXqROvGnTcrEMl.MOVIE_PREMIUM
  else:
   aWsLSYJwhixfIpHNoXqROvGnTcrEje=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.MOVIE_LITE
  try:
   aWsLSYJwhixfIpHNoXqROvGnTcrEKk ='/v2/media/movie/curation/'+genre
   aWsLSYJwhixfIpHNoXqROvGnTcrEKD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetDefaultParams()
   aWsLSYJwhixfIpHNoXqROvGnTcrEKm={'pageNo':aWsLSYJwhixfIpHNoXqROvGnTcrEld(page_int),'pageSize':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.MOVIE_LIMIT),'productPackageCode':aWsLSYJwhixfIpHNoXqROvGnTcrEje,'_':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetNoCache(2))}
   aWsLSYJwhixfIpHNoXqROvGnTcrEKD.update(aWsLSYJwhixfIpHNoXqROvGnTcrEKm)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMF=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeurl(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.API_DOMAIN,aWsLSYJwhixfIpHNoXqROvGnTcrEKk)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeDefaultCookies()
   aWsLSYJwhixfIpHNoXqROvGnTcrEMB=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.callRequestCookies('Get',aWsLSYJwhixfIpHNoXqROvGnTcrEMF,payload=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,params=aWsLSYJwhixfIpHNoXqROvGnTcrEKD,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,cookies=aWsLSYJwhixfIpHNoXqROvGnTcrEMD)
   aWsLSYJwhixfIpHNoXqROvGnTcrEKe=json.loads(aWsLSYJwhixfIpHNoXqROvGnTcrEMB.text)
   if not('movies' in aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']):return aWsLSYJwhixfIpHNoXqROvGnTcrEgK,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
   aWsLSYJwhixfIpHNoXqROvGnTcrEgd=aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']['movies']
   for aWsLSYJwhixfIpHNoXqROvGnTcrEKF in aWsLSYJwhixfIpHNoXqROvGnTcrEgd:
    aWsLSYJwhixfIpHNoXqROvGnTcrEjt =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['code']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgt =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['name']['ko']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgQ =aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEKF['image'][0]['url']
    for aWsLSYJwhixfIpHNoXqROvGnTcrEgy in aWsLSYJwhixfIpHNoXqROvGnTcrEKF['image']:
     if aWsLSYJwhixfIpHNoXqROvGnTcrEgy['code']=='CAIM2100':
      aWsLSYJwhixfIpHNoXqROvGnTcrEgQ =aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEgy['url']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgC =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['story']['ko']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgb={'moviecode':aWsLSYJwhixfIpHNoXqROvGnTcrEjt,'title':aWsLSYJwhixfIpHNoXqROvGnTcrEgt.strip(),'thumbnail':aWsLSYJwhixfIpHNoXqROvGnTcrEgQ,'synopsis':aWsLSYJwhixfIpHNoXqROvGnTcrEgC}
    if premiumyn==aWsLSYJwhixfIpHNoXqROvGnTcrElK:
     aWsLSYJwhixfIpHNoXqROvGnTcrEjQ=aWsLSYJwhixfIpHNoXqROvGnTcrEjV
     for aWsLSYJwhixfIpHNoXqROvGnTcrEjC in aWsLSYJwhixfIpHNoXqROvGnTcrEKF['billing_package_id']:
      if aWsLSYJwhixfIpHNoXqROvGnTcrEjC==aWsLSYJwhixfIpHNoXqROvGnTcrEMl.MOVIE_LITE:
       aWsLSYJwhixfIpHNoXqROvGnTcrEjQ=aWsLSYJwhixfIpHNoXqROvGnTcrElK
       break
     if aWsLSYJwhixfIpHNoXqROvGnTcrEjQ==aWsLSYJwhixfIpHNoXqROvGnTcrEjV:
      aWsLSYJwhixfIpHNoXqROvGnTcrEgb['title']=aWsLSYJwhixfIpHNoXqROvGnTcrEgb['title']+' [Premium]'
    aWsLSYJwhixfIpHNoXqROvGnTcrEgK.append(aWsLSYJwhixfIpHNoXqROvGnTcrEgb)
  except aWsLSYJwhixfIpHNoXqROvGnTcrElg as exception:
   aWsLSYJwhixfIpHNoXqROvGnTcrElj(exception)
  return aWsLSYJwhixfIpHNoXqROvGnTcrEgK,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
 def GetMovieGenre(aWsLSYJwhixfIpHNoXqROvGnTcrEMl):
  aWsLSYJwhixfIpHNoXqROvGnTcrEgK=[]
  aWsLSYJwhixfIpHNoXqROvGnTcrEgj=aWsLSYJwhixfIpHNoXqROvGnTcrEjV
  try:
   aWsLSYJwhixfIpHNoXqROvGnTcrEKk ='/v2/media/movie/curations'
   aWsLSYJwhixfIpHNoXqROvGnTcrEKD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetDefaultParams()
   aWsLSYJwhixfIpHNoXqROvGnTcrEKm={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetNoCache(2))}
   aWsLSYJwhixfIpHNoXqROvGnTcrEKD.update(aWsLSYJwhixfIpHNoXqROvGnTcrEKm)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMF=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeurl(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.API_DOMAIN,aWsLSYJwhixfIpHNoXqROvGnTcrEKk)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeDefaultCookies()
   aWsLSYJwhixfIpHNoXqROvGnTcrEMB=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.callRequestCookies('Get',aWsLSYJwhixfIpHNoXqROvGnTcrEMF,payload=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,params=aWsLSYJwhixfIpHNoXqROvGnTcrEKD,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,cookies=aWsLSYJwhixfIpHNoXqROvGnTcrEMD)
   aWsLSYJwhixfIpHNoXqROvGnTcrEKe=json.loads(aWsLSYJwhixfIpHNoXqROvGnTcrEMB.text)
   if not('result' in aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']):return aWsLSYJwhixfIpHNoXqROvGnTcrEgK,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
   aWsLSYJwhixfIpHNoXqROvGnTcrEgd=aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']['result']
   for aWsLSYJwhixfIpHNoXqROvGnTcrEKF in aWsLSYJwhixfIpHNoXqROvGnTcrEgd:
    aWsLSYJwhixfIpHNoXqROvGnTcrEjF =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['curation_code']
    aWsLSYJwhixfIpHNoXqROvGnTcrEjz =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['curation_name']
    aWsLSYJwhixfIpHNoXqROvGnTcrEgb={'curation_code':aWsLSYJwhixfIpHNoXqROvGnTcrEjF,'curation_name':aWsLSYJwhixfIpHNoXqROvGnTcrEjz}
    aWsLSYJwhixfIpHNoXqROvGnTcrEgK.append(aWsLSYJwhixfIpHNoXqROvGnTcrEgb)
  except aWsLSYJwhixfIpHNoXqROvGnTcrElg as exception:
   aWsLSYJwhixfIpHNoXqROvGnTcrElj(exception)
  return aWsLSYJwhixfIpHNoXqROvGnTcrEgK,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
 def GetSearchList(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,search_key,userid,page_int,stype,premiumyn=aWsLSYJwhixfIpHNoXqROvGnTcrEjV,landyn=aWsLSYJwhixfIpHNoXqROvGnTcrEjV):
  aWsLSYJwhixfIpHNoXqROvGnTcrEjA=[]
  aWsLSYJwhixfIpHNoXqROvGnTcrEgj=aWsLSYJwhixfIpHNoXqROvGnTcrEjV
  try:
   aWsLSYJwhixfIpHNoXqROvGnTcrEKk ='/search/getSearch.jsp'
   aWsLSYJwhixfIpHNoXqROvGnTcrEKm={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'TOTAL','pageNum':aWsLSYJwhixfIpHNoXqROvGnTcrEld(page_int),'pageSize':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':aWsLSYJwhixfIpHNoXqROvGnTcrEMl.SCREENCODE,'os':aWsLSYJwhixfIpHNoXqROvGnTcrEMl.OSCODE,'network':aWsLSYJwhixfIpHNoXqROvGnTcrEMl.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.SEARCH_LIMIT),'vodMVReqCnt':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':aWsLSYJwhixfIpHNoXqROvGnTcrEld(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.GetNoCache(2))}
   aWsLSYJwhixfIpHNoXqROvGnTcrEMF=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeurl(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.SEARCH_DOMAIN,aWsLSYJwhixfIpHNoXqROvGnTcrEKk)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeDefaultCookies()
   aWsLSYJwhixfIpHNoXqROvGnTcrEMB=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.callRequestCookies('Get',aWsLSYJwhixfIpHNoXqROvGnTcrEMF,payload=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,params=aWsLSYJwhixfIpHNoXqROvGnTcrEKm,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,cookies=aWsLSYJwhixfIpHNoXqROvGnTcrEMD)
   aWsLSYJwhixfIpHNoXqROvGnTcrEKe=json.loads(aWsLSYJwhixfIpHNoXqROvGnTcrEMB.text)
   if stype=='vod':
    if not('programRsb' in aWsLSYJwhixfIpHNoXqROvGnTcrEKe):return aWsLSYJwhixfIpHNoXqROvGnTcrEjA,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
    aWsLSYJwhixfIpHNoXqROvGnTcrEjP=aWsLSYJwhixfIpHNoXqROvGnTcrEKe['programRsb']['dataList']
    aWsLSYJwhixfIpHNoXqROvGnTcrEjb =aWsLSYJwhixfIpHNoXqROvGnTcrElM(aWsLSYJwhixfIpHNoXqROvGnTcrEKe['programRsb']['count'])
    for aWsLSYJwhixfIpHNoXqROvGnTcrEKF in aWsLSYJwhixfIpHNoXqROvGnTcrEjP:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgu=aWsLSYJwhixfIpHNoXqROvGnTcrEKF['mast_cd']
     aWsLSYJwhixfIpHNoXqROvGnTcrEgt =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['mast_nm']
     aWsLSYJwhixfIpHNoXqROvGnTcrEgQ =aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEKF['web_url']
     if landyn==aWsLSYJwhixfIpHNoXqROvGnTcrEjV:
      aWsLSYJwhixfIpHNoXqROvGnTcrEgQ =aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEKF['web_url4']
     aWsLSYJwhixfIpHNoXqROvGnTcrEgk={}
     aWsLSYJwhixfIpHNoXqROvGnTcrEgk['title']=aWsLSYJwhixfIpHNoXqROvGnTcrEKF['mast_nm']
     aWsLSYJwhixfIpHNoXqROvGnTcrEgk['mediatype']='episode' 
     try:
      if aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('actor')!='' and aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('actor')!='-':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['cast'] =aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('actor').split(',')
      if aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('director')!='' and aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('director')!='-':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['director']=aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('director').split(',')
      if aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('cate_nm')!='':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['genre'] =aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('cate_nm').split('/')
      if 'targetage' in aWsLSYJwhixfIpHNoXqROvGnTcrEKF:aWsLSYJwhixfIpHNoXqROvGnTcrEgk['mpaa']=aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('targetage')
     except:
      aWsLSYJwhixfIpHNoXqROvGnTcrEjB
     try:
      if 'broad_dt' in aWsLSYJwhixfIpHNoXqROvGnTcrEKF:
       aWsLSYJwhixfIpHNoXqROvGnTcrEjK=aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('broad_dt')
       aWsLSYJwhixfIpHNoXqROvGnTcrEgk['aired']='%s-%s-%s'%(aWsLSYJwhixfIpHNoXqROvGnTcrEjK[:4],aWsLSYJwhixfIpHNoXqROvGnTcrEjK[4:6],aWsLSYJwhixfIpHNoXqROvGnTcrEjK[6:])
     except:
      aWsLSYJwhixfIpHNoXqROvGnTcrEjB
     aWsLSYJwhixfIpHNoXqROvGnTcrEgb={'program':aWsLSYJwhixfIpHNoXqROvGnTcrEgu,'title':aWsLSYJwhixfIpHNoXqROvGnTcrEgt,'thumbnail':aWsLSYJwhixfIpHNoXqROvGnTcrEgQ,'synopsis':'','info':aWsLSYJwhixfIpHNoXqROvGnTcrEgk}
     aWsLSYJwhixfIpHNoXqROvGnTcrEjA.append(aWsLSYJwhixfIpHNoXqROvGnTcrEgb)
   else:
    if not('vodMVRsb' in aWsLSYJwhixfIpHNoXqROvGnTcrEKe):return aWsLSYJwhixfIpHNoXqROvGnTcrEjA,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
    aWsLSYJwhixfIpHNoXqROvGnTcrEju=aWsLSYJwhixfIpHNoXqROvGnTcrEKe['vodMVRsb']['dataList']
    aWsLSYJwhixfIpHNoXqROvGnTcrEjb =aWsLSYJwhixfIpHNoXqROvGnTcrElM(aWsLSYJwhixfIpHNoXqROvGnTcrEKe['vodMVRsb']['count'])
    for aWsLSYJwhixfIpHNoXqROvGnTcrEKF in aWsLSYJwhixfIpHNoXqROvGnTcrEju:
     aWsLSYJwhixfIpHNoXqROvGnTcrEgu=aWsLSYJwhixfIpHNoXqROvGnTcrEKF['mast_cd']
     aWsLSYJwhixfIpHNoXqROvGnTcrEgt =aWsLSYJwhixfIpHNoXqROvGnTcrEKF['mast_nm'].strip()
     aWsLSYJwhixfIpHNoXqROvGnTcrEgQ =aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEKF['web_url']
     if landyn==aWsLSYJwhixfIpHNoXqROvGnTcrEjV:
      aWsLSYJwhixfIpHNoXqROvGnTcrEgQ =aWsLSYJwhixfIpHNoXqROvGnTcrEMl.IMG_DOMAIN+aWsLSYJwhixfIpHNoXqROvGnTcrEKF['web_url5']
     aWsLSYJwhixfIpHNoXqROvGnTcrEgk={}
     aWsLSYJwhixfIpHNoXqROvGnTcrEgk['title'] =aWsLSYJwhixfIpHNoXqROvGnTcrEgt
     aWsLSYJwhixfIpHNoXqROvGnTcrEgk['mediatype']='movie' 
     try:
      if aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('actor') !='':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['cast'] =aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('actor').split(',')
      if aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('cate_nm')!='':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['genre'] =aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('cate_nm').split('/')
      if aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('runtime_sec')!='':aWsLSYJwhixfIpHNoXqROvGnTcrEgk['duration']=aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('runtime_sec')
      if 'grade_nm' in aWsLSYJwhixfIpHNoXqROvGnTcrEKF:aWsLSYJwhixfIpHNoXqROvGnTcrEgk['mpaa']=aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('grade_nm')
     except:
      aWsLSYJwhixfIpHNoXqROvGnTcrEjB
     try:
      aWsLSYJwhixfIpHNoXqROvGnTcrEjK=aWsLSYJwhixfIpHNoXqROvGnTcrEKF.get('broad_dt')
      if data_str!='':
       aWsLSYJwhixfIpHNoXqROvGnTcrEgk['aired']='%s-%s-%s'%(aWsLSYJwhixfIpHNoXqROvGnTcrEjK[:4],aWsLSYJwhixfIpHNoXqROvGnTcrEjK[4:6],aWsLSYJwhixfIpHNoXqROvGnTcrEjK[6:])
       aWsLSYJwhixfIpHNoXqROvGnTcrEgk['year']=aWsLSYJwhixfIpHNoXqROvGnTcrEjK[:4]
     except:
      aWsLSYJwhixfIpHNoXqROvGnTcrEjB
     if aWsLSYJwhixfIpHNoXqROvGnTcrElK:
      aWsLSYJwhixfIpHNoXqROvGnTcrEgb={'movie':aWsLSYJwhixfIpHNoXqROvGnTcrEgu,'title':aWsLSYJwhixfIpHNoXqROvGnTcrEgt,'thumbnail':aWsLSYJwhixfIpHNoXqROvGnTcrEgQ,'synopsis':'','info':aWsLSYJwhixfIpHNoXqROvGnTcrEgk}
      aWsLSYJwhixfIpHNoXqROvGnTcrEjA.append(aWsLSYJwhixfIpHNoXqROvGnTcrEgb)
  except aWsLSYJwhixfIpHNoXqROvGnTcrElg as exception:
   aWsLSYJwhixfIpHNoXqROvGnTcrElj(exception)
  return aWsLSYJwhixfIpHNoXqROvGnTcrEjA,aWsLSYJwhixfIpHNoXqROvGnTcrEgj
 def GetDeviceList(aWsLSYJwhixfIpHNoXqROvGnTcrEMl,aWsLSYJwhixfIpHNoXqROvGnTcrEMb,aWsLSYJwhixfIpHNoXqROvGnTcrEKM):
  aWsLSYJwhixfIpHNoXqROvGnTcrEgK=[]
  aWsLSYJwhixfIpHNoXqROvGnTcrEKd='-'
  try:
   aWsLSYJwhixfIpHNoXqROvGnTcrEKk ='/v1/user/device/list'
   aWsLSYJwhixfIpHNoXqROvGnTcrEjU=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeurl(aWsLSYJwhixfIpHNoXqROvGnTcrEMl.API_DOMAIN,aWsLSYJwhixfIpHNoXqROvGnTcrEKk)
   aWsLSYJwhixfIpHNoXqROvGnTcrEKm={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   aWsLSYJwhixfIpHNoXqROvGnTcrEMD=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.makeDefaultCookies(vToken=aWsLSYJwhixfIpHNoXqROvGnTcrEMb,vUserinfo=aWsLSYJwhixfIpHNoXqROvGnTcrEKM)
   aWsLSYJwhixfIpHNoXqROvGnTcrEMB=aWsLSYJwhixfIpHNoXqROvGnTcrEMl.callRequestCookies('Get',aWsLSYJwhixfIpHNoXqROvGnTcrEjU,payload=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,params=aWsLSYJwhixfIpHNoXqROvGnTcrEKm,headers=aWsLSYJwhixfIpHNoXqROvGnTcrEjB,cookies=aWsLSYJwhixfIpHNoXqROvGnTcrEMD)
   aWsLSYJwhixfIpHNoXqROvGnTcrEKe=json.loads(aWsLSYJwhixfIpHNoXqROvGnTcrEMB.text)
   aWsLSYJwhixfIpHNoXqROvGnTcrEgK=aWsLSYJwhixfIpHNoXqROvGnTcrEKe['body']
   for aWsLSYJwhixfIpHNoXqROvGnTcrEKF in aWsLSYJwhixfIpHNoXqROvGnTcrEgK:
    if aWsLSYJwhixfIpHNoXqROvGnTcrEKF['model']=='PC':
     aWsLSYJwhixfIpHNoXqROvGnTcrEKd=aWsLSYJwhixfIpHNoXqROvGnTcrEKF['uuid']
  except aWsLSYJwhixfIpHNoXqROvGnTcrElg as exception:
   aWsLSYJwhixfIpHNoXqROvGnTcrElj(exception)
  return aWsLSYJwhixfIpHNoXqROvGnTcrEKd
# Created by pyminifier (https://github.com/liftoff/pyminifier)
