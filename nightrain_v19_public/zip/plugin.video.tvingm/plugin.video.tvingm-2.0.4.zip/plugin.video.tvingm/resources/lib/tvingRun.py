__author__="NightRain"
cGqbmKUQLluhxgMCtikjpdDrHEIeBv=object
cGqbmKUQLluhxgMCtikjpdDrHEIeBY=None
cGqbmKUQLluhxgMCtikjpdDrHEIeBF=False
cGqbmKUQLluhxgMCtikjpdDrHEIeRO=True
cGqbmKUQLluhxgMCtikjpdDrHEIeRJ=int
cGqbmKUQLluhxgMCtikjpdDrHEIeRo=len
cGqbmKUQLluhxgMCtikjpdDrHEIeRX=str
cGqbmKUQLluhxgMCtikjpdDrHEIeRB=open
cGqbmKUQLluhxgMCtikjpdDrHEIeRS=dict
cGqbmKUQLluhxgMCtikjpdDrHEIeRn=Exception
cGqbmKUQLluhxgMCtikjpdDrHEIeRz=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
cGqbmKUQLluhxgMCtikjpdDrHEIeOo=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 (인기순)','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 (최신순)','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'월정액 영화관 (인기)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'-'},{'title':'월정액 영화관 (최신)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
cGqbmKUQLluhxgMCtikjpdDrHEIeOX=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
cGqbmKUQLluhxgMCtikjpdDrHEIeOB=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
cGqbmKUQLluhxgMCtikjpdDrHEIeOR=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
cGqbmKUQLluhxgMCtikjpdDrHEIeOS=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'PROGRAM','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
cGqbmKUQLluhxgMCtikjpdDrHEIeOn={'C00551':'tvN','C00544':'중화TV','C00575':'Olive','C00579':'Mnet','C00590':'OGN','C01141':'XtvN','C01142':'ONSTYLE','C01143':'OtvN','C04601':'CGV','C06941':'tooniverse','C07381':'OCN','C07382':'SUPER ACTION','C15251':'OGN x LOL','C15252':'OGN x 오버워치','C15042':'티빙라이브','C01581':'TV CHOSUN','C01583':'채널A','C00708':'MBN','C00593':'YTN','C01101':'YTN Life','C15347':'YTN science','C01723':'연합뉴스TV','C15152':'DIA TV','C01582':'JTBC','C00588':'JTBC Golf','C15741':'JTBC2','C00805':'JTBC3 FOX Sports','C05661':'디즈니채널','C18641':'IHQ','C22041':'JTBC4','C23343':'t.cast','C23441':'E channel','C17341':'히스토리','C00585':'TV CHOSUN2','C17141':'채널A 플러스','C00611':'LIFETIME','C08041':'tvN go','C05901':'채널W','C23442':"D'LIVE",'C27441':'KBS N'}
cGqbmKUQLluhxgMCtikjpdDrHEIeOz ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
cGqbmKUQLluhxgMCtikjpdDrHEIeOy=xbmc.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class cGqbmKUQLluhxgMCtikjpdDrHEIeOJ(cGqbmKUQLluhxgMCtikjpdDrHEIeBv):
 def __init__(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeON,cGqbmKUQLluhxgMCtikjpdDrHEIeOP,cGqbmKUQLluhxgMCtikjpdDrHEIeOf):
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_url =cGqbmKUQLluhxgMCtikjpdDrHEIeON
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_handle=cGqbmKUQLluhxgMCtikjpdDrHEIeOP
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.main_params =cGqbmKUQLluhxgMCtikjpdDrHEIeOf
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj =aWsLSYJwhixfIpHNoXqROvGnTcrEMK() 
 def addon_noti(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,sting):
  try:
   cGqbmKUQLluhxgMCtikjpdDrHEIeOW=xbmcgui.Dialog()
   cGqbmKUQLluhxgMCtikjpdDrHEIeOW.notification(__addonname__,sting)
  except:
   cGqbmKUQLluhxgMCtikjpdDrHEIeBY
 def addon_log(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,string):
  try:
   cGqbmKUQLluhxgMCtikjpdDrHEIeOV=string.encode('utf-8','ignore')
  except:
   cGqbmKUQLluhxgMCtikjpdDrHEIeOV='addonException: addon_log'
  cGqbmKUQLluhxgMCtikjpdDrHEIeOT=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,cGqbmKUQLluhxgMCtikjpdDrHEIeOV),level=cGqbmKUQLluhxgMCtikjpdDrHEIeOT)
 def get_keyboard_input(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeJS):
  cGqbmKUQLluhxgMCtikjpdDrHEIeOa=cGqbmKUQLluhxgMCtikjpdDrHEIeBY
  kb=xbmc.Keyboard()
  kb.setHeading(cGqbmKUQLluhxgMCtikjpdDrHEIeJS)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   cGqbmKUQLluhxgMCtikjpdDrHEIeOa=kb.getText()
  return cGqbmKUQLluhxgMCtikjpdDrHEIeOa
 def get_settings_login_info(cGqbmKUQLluhxgMCtikjpdDrHEIeOA):
  cGqbmKUQLluhxgMCtikjpdDrHEIeOw =__addon__.getSetting('id')
  cGqbmKUQLluhxgMCtikjpdDrHEIeOv =__addon__.getSetting('pw')
  cGqbmKUQLluhxgMCtikjpdDrHEIeOY =__addon__.getSetting('login_type')
  return(cGqbmKUQLluhxgMCtikjpdDrHEIeOw,cGqbmKUQLluhxgMCtikjpdDrHEIeOv,cGqbmKUQLluhxgMCtikjpdDrHEIeOY)
 def get_settings_premiumyn(cGqbmKUQLluhxgMCtikjpdDrHEIeOA):
  cGqbmKUQLluhxgMCtikjpdDrHEIeOF =__addon__.getSetting('premium_movieyn')
  if cGqbmKUQLluhxgMCtikjpdDrHEIeOF=='false':
   return cGqbmKUQLluhxgMCtikjpdDrHEIeBF
  else:
   return cGqbmKUQLluhxgMCtikjpdDrHEIeRO
 def get_settings_direct_replay(cGqbmKUQLluhxgMCtikjpdDrHEIeOA):
  cGqbmKUQLluhxgMCtikjpdDrHEIeJO=cGqbmKUQLluhxgMCtikjpdDrHEIeRJ(__addon__.getSetting('direct_replay'))
  if cGqbmKUQLluhxgMCtikjpdDrHEIeJO==0:
   return cGqbmKUQLluhxgMCtikjpdDrHEIeBF
  else:
   return cGqbmKUQLluhxgMCtikjpdDrHEIeRO
 def get_settings_thumbnail_landyn(cGqbmKUQLluhxgMCtikjpdDrHEIeOA):
  cGqbmKUQLluhxgMCtikjpdDrHEIeJo =cGqbmKUQLluhxgMCtikjpdDrHEIeRJ(__addon__.getSetting('thumbnail_way'))
  if cGqbmKUQLluhxgMCtikjpdDrHEIeJo==0:
   return cGqbmKUQLluhxgMCtikjpdDrHEIeRO
  else:
   return cGqbmKUQLluhxgMCtikjpdDrHEIeBF
 def set_winCredential(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,credential):
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX=xbmcgui.Window(10000)
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX.setProperty('TVING_M_LOGINTIME',cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(cGqbmKUQLluhxgMCtikjpdDrHEIeOA):
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX=xbmcgui.Window(10000)
  cGqbmKUQLluhxgMCtikjpdDrHEIeJB={'tving_token':cGqbmKUQLluhxgMCtikjpdDrHEIeJX.getProperty('TVING_M_TOKEN'),'poc_userinfo':cGqbmKUQLluhxgMCtikjpdDrHEIeJX.getProperty('TVING_M_USERINFO'),'tving_uuid':cGqbmKUQLluhxgMCtikjpdDrHEIeJX.getProperty('TVING_M_UUID')}
  return cGqbmKUQLluhxgMCtikjpdDrHEIeJB
 def set_winEpisodeOrderby(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeof):
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX=xbmcgui.Window(10000)
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX.setProperty('TVING_M_ORDERBY',cGqbmKUQLluhxgMCtikjpdDrHEIeof)
 def get_winEpisodeOrderby(cGqbmKUQLluhxgMCtikjpdDrHEIeOA):
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX=xbmcgui.Window(10000)
  return cGqbmKUQLluhxgMCtikjpdDrHEIeJX.getProperty('TVING_M_ORDERBY')
 def add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,label,sublabel='',img='',infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeBY,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeRO,params=''):
  cGqbmKUQLluhxgMCtikjpdDrHEIeJR='%s?%s'%(cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_url,urllib.parse.urlencode(params))
  if sublabel:cGqbmKUQLluhxgMCtikjpdDrHEIeJS='%s < %s >'%(label,sublabel)
  else: cGqbmKUQLluhxgMCtikjpdDrHEIeJS=label
  if not img:img='DefaultFolder.png'
  cGqbmKUQLluhxgMCtikjpdDrHEIeJn=xbmcgui.ListItem(cGqbmKUQLluhxgMCtikjpdDrHEIeJS)
  cGqbmKUQLluhxgMCtikjpdDrHEIeJn.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:cGqbmKUQLluhxgMCtikjpdDrHEIeJn.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:cGqbmKUQLluhxgMCtikjpdDrHEIeJn.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_handle,cGqbmKUQLluhxgMCtikjpdDrHEIeJR,cGqbmKUQLluhxgMCtikjpdDrHEIeJn,isFolder)
 def get_selQuality(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,etype):
  try:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJz='selected_quality'
   cGqbmKUQLluhxgMCtikjpdDrHEIeJy=[1080,720,480,360]
   cGqbmKUQLluhxgMCtikjpdDrHEIeJA=cGqbmKUQLluhxgMCtikjpdDrHEIeRJ(__addon__.getSetting(cGqbmKUQLluhxgMCtikjpdDrHEIeJz))
   return cGqbmKUQLluhxgMCtikjpdDrHEIeJy[cGqbmKUQLluhxgMCtikjpdDrHEIeJA]
  except:
   cGqbmKUQLluhxgMCtikjpdDrHEIeBY
  return 720 
 def dp_Main_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA):
  for cGqbmKUQLluhxgMCtikjpdDrHEIeJN in cGqbmKUQLluhxgMCtikjpdDrHEIeOo:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS=cGqbmKUQLluhxgMCtikjpdDrHEIeJN.get('title')
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':cGqbmKUQLluhxgMCtikjpdDrHEIeJN.get('mode'),'stype':cGqbmKUQLluhxgMCtikjpdDrHEIeJN.get('stype'),'orderby':cGqbmKUQLluhxgMCtikjpdDrHEIeJN.get('orderby'),'ordernm':cGqbmKUQLluhxgMCtikjpdDrHEIeJN.get('ordernm'),'page':'1'}
   if cGqbmKUQLluhxgMCtikjpdDrHEIeJN.get('mode')=='XXX':
    cGqbmKUQLluhxgMCtikjpdDrHEIeJP['mode']='XXX'
    cGqbmKUQLluhxgMCtikjpdDrHEIeJf=cGqbmKUQLluhxgMCtikjpdDrHEIeBF
   else:
    cGqbmKUQLluhxgMCtikjpdDrHEIeJf=cGqbmKUQLluhxgMCtikjpdDrHEIeRO
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel='',img='',infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeBY,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeJf,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeRo(cGqbmKUQLluhxgMCtikjpdDrHEIeOo)>0:xbmcplugin.endOfDirectory(cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_handle)
 def login_main(cGqbmKUQLluhxgMCtikjpdDrHEIeOA):
  (cGqbmKUQLluhxgMCtikjpdDrHEIeJW,cGqbmKUQLluhxgMCtikjpdDrHEIeJV,cGqbmKUQLluhxgMCtikjpdDrHEIeJT)=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_settings_login_info()
  if not(cGqbmKUQLluhxgMCtikjpdDrHEIeJW and cGqbmKUQLluhxgMCtikjpdDrHEIeJV):
   cGqbmKUQLluhxgMCtikjpdDrHEIeOW=xbmcgui.Dialog()
   cGqbmKUQLluhxgMCtikjpdDrHEIeJa=cGqbmKUQLluhxgMCtikjpdDrHEIeOW.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if cGqbmKUQLluhxgMCtikjpdDrHEIeJa==cGqbmKUQLluhxgMCtikjpdDrHEIeRO:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_winEpisodeOrderby()=='':
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.set_winEpisodeOrderby('desc')
  if cGqbmKUQLluhxgMCtikjpdDrHEIeOA.cookiefile_check():return
  cGqbmKUQLluhxgMCtikjpdDrHEIeJw =cGqbmKUQLluhxgMCtikjpdDrHEIeRJ(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  cGqbmKUQLluhxgMCtikjpdDrHEIeJv=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if cGqbmKUQLluhxgMCtikjpdDrHEIeJv==cGqbmKUQLluhxgMCtikjpdDrHEIeBY or cGqbmKUQLluhxgMCtikjpdDrHEIeJv=='':
   cGqbmKUQLluhxgMCtikjpdDrHEIeJv=cGqbmKUQLluhxgMCtikjpdDrHEIeRJ('19000101')
  else:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJv=cGqbmKUQLluhxgMCtikjpdDrHEIeRJ(re.sub('-','',cGqbmKUQLluhxgMCtikjpdDrHEIeJv))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   cGqbmKUQLluhxgMCtikjpdDrHEIeJY=0
   while cGqbmKUQLluhxgMCtikjpdDrHEIeRO:
    cGqbmKUQLluhxgMCtikjpdDrHEIeJY+=1
    time.sleep(0.05)
    if cGqbmKUQLluhxgMCtikjpdDrHEIeJv>=cGqbmKUQLluhxgMCtikjpdDrHEIeJw:return
    if cGqbmKUQLluhxgMCtikjpdDrHEIeJY>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if cGqbmKUQLluhxgMCtikjpdDrHEIeJv>=cGqbmKUQLluhxgMCtikjpdDrHEIeJw:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.GetCredential(cGqbmKUQLluhxgMCtikjpdDrHEIeJW,cGqbmKUQLluhxgMCtikjpdDrHEIeJV,cGqbmKUQLluhxgMCtikjpdDrHEIeJT):
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.set_winCredential(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.LoadCredential())
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeoX):
  cGqbmKUQLluhxgMCtikjpdDrHEIeJF=cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('stype')
  if cGqbmKUQLluhxgMCtikjpdDrHEIeJF=='live':
   cGqbmKUQLluhxgMCtikjpdDrHEIeoO=cGqbmKUQLluhxgMCtikjpdDrHEIeOX
  else:
   cGqbmKUQLluhxgMCtikjpdDrHEIeoO=cGqbmKUQLluhxgMCtikjpdDrHEIeOS
  for cGqbmKUQLluhxgMCtikjpdDrHEIeoJ in cGqbmKUQLluhxgMCtikjpdDrHEIeoO:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS=cGqbmKUQLluhxgMCtikjpdDrHEIeoJ.get('title')
   if cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('ordernm')!='-':
    cGqbmKUQLluhxgMCtikjpdDrHEIeJS+='  ('+cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('ordernm')+')'
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':cGqbmKUQLluhxgMCtikjpdDrHEIeoJ.get('mode'),'stype':cGqbmKUQLluhxgMCtikjpdDrHEIeoJ.get('stype'),'orderby':cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('orderby'),'page':'1'}
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel='',img='',infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeBY,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeRO,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeRo(cGqbmKUQLluhxgMCtikjpdDrHEIeoO)>0:xbmcplugin.endOfDirectory(cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_handle)
 def dp_LiveChannel_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeoX):
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.SaveCredential(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_winCredential())
  cGqbmKUQLluhxgMCtikjpdDrHEIeJF =cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('stype')
  cGqbmKUQLluhxgMCtikjpdDrHEIeoB =cGqbmKUQLluhxgMCtikjpdDrHEIeRJ(cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('page'))
  cGqbmKUQLluhxgMCtikjpdDrHEIeoR,cGqbmKUQLluhxgMCtikjpdDrHEIeoS=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.GetLiveChannelList(cGqbmKUQLluhxgMCtikjpdDrHEIeJF,cGqbmKUQLluhxgMCtikjpdDrHEIeoB)
  for cGqbmKUQLluhxgMCtikjpdDrHEIeon in cGqbmKUQLluhxgMCtikjpdDrHEIeoR:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS =cGqbmKUQLluhxgMCtikjpdDrHEIeon.get('title')
   cGqbmKUQLluhxgMCtikjpdDrHEIeJs =cGqbmKUQLluhxgMCtikjpdDrHEIeon.get('channel')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoz =cGqbmKUQLluhxgMCtikjpdDrHEIeon.get('thumbnail')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoy =cGqbmKUQLluhxgMCtikjpdDrHEIeon.get('synopsis')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoA=cGqbmKUQLluhxgMCtikjpdDrHEIeon.get('channelepg')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoN=cGqbmKUQLluhxgMCtikjpdDrHEIeon.get('info')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoN['plot']='%s\n%s\n%s\n\n%s'%(cGqbmKUQLluhxgMCtikjpdDrHEIeJs,cGqbmKUQLluhxgMCtikjpdDrHEIeJS,cGqbmKUQLluhxgMCtikjpdDrHEIeoA,cGqbmKUQLluhxgMCtikjpdDrHEIeoy)
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':'LIVE','mediacode':cGqbmKUQLluhxgMCtikjpdDrHEIeon.get('mediacode'),'stype':cGqbmKUQLluhxgMCtikjpdDrHEIeJF}
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJs,sublabel=cGqbmKUQLluhxgMCtikjpdDrHEIeJS,img=cGqbmKUQLluhxgMCtikjpdDrHEIeoz,infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeoN,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeBF,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeoS:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['mode']='CHANNEL' 
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['stype']=cGqbmKUQLluhxgMCtikjpdDrHEIeJF 
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['page']=cGqbmKUQLluhxgMCtikjpdDrHEIeRX(cGqbmKUQLluhxgMCtikjpdDrHEIeoB+1)
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS='[B]%s >>[/B]'%'다음 페이지'
   cGqbmKUQLluhxgMCtikjpdDrHEIeoP=cGqbmKUQLluhxgMCtikjpdDrHEIeRX(cGqbmKUQLluhxgMCtikjpdDrHEIeoB+1)
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel=cGqbmKUQLluhxgMCtikjpdDrHEIeoP,img='',infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeBY,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeRO,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeRo(cGqbmKUQLluhxgMCtikjpdDrHEIeoR)>0:xbmcplugin.endOfDirectory(cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_handle,cacheToDisc=cGqbmKUQLluhxgMCtikjpdDrHEIeBF)
 def dp_Program_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeoX):
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.SaveCredential(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_winCredential())
  cGqbmKUQLluhxgMCtikjpdDrHEIeJF =cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('stype')
  cGqbmKUQLluhxgMCtikjpdDrHEIeof =cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('orderby')
  cGqbmKUQLluhxgMCtikjpdDrHEIeoB =cGqbmKUQLluhxgMCtikjpdDrHEIeRJ(cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('page'))
  cGqbmKUQLluhxgMCtikjpdDrHEIeos,cGqbmKUQLluhxgMCtikjpdDrHEIeoS=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.GetProgramList(cGqbmKUQLluhxgMCtikjpdDrHEIeJF,cGqbmKUQLluhxgMCtikjpdDrHEIeof,cGqbmKUQLluhxgMCtikjpdDrHEIeoB,landyn=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_settings_thumbnail_landyn())
  for cGqbmKUQLluhxgMCtikjpdDrHEIeoW in cGqbmKUQLluhxgMCtikjpdDrHEIeos:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS =cGqbmKUQLluhxgMCtikjpdDrHEIeoW.get('title')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoz=cGqbmKUQLluhxgMCtikjpdDrHEIeoW.get('thumbnail')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoy =cGqbmKUQLluhxgMCtikjpdDrHEIeoW.get('synopsis')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoV =cGqbmKUQLluhxgMCtikjpdDrHEIeOn.get(cGqbmKUQLluhxgMCtikjpdDrHEIeoW.get('channel'))
   cGqbmKUQLluhxgMCtikjpdDrHEIeoN=cGqbmKUQLluhxgMCtikjpdDrHEIeoW.get('info')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoN['studio']=cGqbmKUQLluhxgMCtikjpdDrHEIeoV
   cGqbmKUQLluhxgMCtikjpdDrHEIeoN['plot']='%s <%s>\n\n%s'%(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,cGqbmKUQLluhxgMCtikjpdDrHEIeoV,cGqbmKUQLluhxgMCtikjpdDrHEIeoy)
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':'EPISODE','programcode':cGqbmKUQLluhxgMCtikjpdDrHEIeoW.get('program'),'page':'1'}
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel=cGqbmKUQLluhxgMCtikjpdDrHEIeoV,img=cGqbmKUQLluhxgMCtikjpdDrHEIeoz,infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeoN,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeRO,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeoS:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['mode'] ='PROGRAM' 
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['stype'] =cGqbmKUQLluhxgMCtikjpdDrHEIeJF
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['orderby']=cGqbmKUQLluhxgMCtikjpdDrHEIeof
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['page'] =cGqbmKUQLluhxgMCtikjpdDrHEIeRX(cGqbmKUQLluhxgMCtikjpdDrHEIeoB+1)
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS='[B]%s >>[/B]'%'다음 페이지'
   cGqbmKUQLluhxgMCtikjpdDrHEIeoP=cGqbmKUQLluhxgMCtikjpdDrHEIeRX(cGqbmKUQLluhxgMCtikjpdDrHEIeoB+1)
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel=cGqbmKUQLluhxgMCtikjpdDrHEIeoP,img='',infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeBY,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeRO,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeRo(cGqbmKUQLluhxgMCtikjpdDrHEIeos)>0:xbmcplugin.endOfDirectory(cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_handle,cacheToDisc=cGqbmKUQLluhxgMCtikjpdDrHEIeBF)
 def dp_Episode_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeoX):
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.SaveCredential(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_winCredential())
  cGqbmKUQLluhxgMCtikjpdDrHEIeoT=cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('programcode')
  cGqbmKUQLluhxgMCtikjpdDrHEIeoB =cGqbmKUQLluhxgMCtikjpdDrHEIeRJ(cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('page'))
  cGqbmKUQLluhxgMCtikjpdDrHEIeoa,cGqbmKUQLluhxgMCtikjpdDrHEIeoS,cGqbmKUQLluhxgMCtikjpdDrHEIeow=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.GetEpisodoList(cGqbmKUQLluhxgMCtikjpdDrHEIeoT,cGqbmKUQLluhxgMCtikjpdDrHEIeoB,orderby=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_winEpisodeOrderby())
  for cGqbmKUQLluhxgMCtikjpdDrHEIeov in cGqbmKUQLluhxgMCtikjpdDrHEIeoa:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS =cGqbmKUQLluhxgMCtikjpdDrHEIeov.get('title')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoP =cGqbmKUQLluhxgMCtikjpdDrHEIeov.get('subtitle')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoz=cGqbmKUQLluhxgMCtikjpdDrHEIeov.get('thumbnail')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoy =cGqbmKUQLluhxgMCtikjpdDrHEIeov.get('synopsis')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoN=cGqbmKUQLluhxgMCtikjpdDrHEIeov.get('info')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoN['plot']='%s\n\n%s'%(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,cGqbmKUQLluhxgMCtikjpdDrHEIeoy)
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':'VOD','mediacode':cGqbmKUQLluhxgMCtikjpdDrHEIeov.get('episode'),'stype':'vod','programcode':cGqbmKUQLluhxgMCtikjpdDrHEIeoT,'title':cGqbmKUQLluhxgMCtikjpdDrHEIeJS,'thumbnail':cGqbmKUQLluhxgMCtikjpdDrHEIeoz}
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel=cGqbmKUQLluhxgMCtikjpdDrHEIeoP,img=cGqbmKUQLluhxgMCtikjpdDrHEIeoz,infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeoN,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeBF,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeoB==1:
   cGqbmKUQLluhxgMCtikjpdDrHEIeoN={'plot':'정렬순서를 변경합니다.'}
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP={}
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['mode'] ='ORDER_BY' 
   if cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_winEpisodeOrderby()=='desc':
    cGqbmKUQLluhxgMCtikjpdDrHEIeJS='정렬순서변경 : 최신화부터 -> 1회부터'
    cGqbmKUQLluhxgMCtikjpdDrHEIeJP['orderby']='asc'
   else:
    cGqbmKUQLluhxgMCtikjpdDrHEIeJS='정렬순서변경 : 1회부터 -> 최신화부터'
    cGqbmKUQLluhxgMCtikjpdDrHEIeJP['orderby']='desc'
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel='',img='',infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeoN,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeBF,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeoS:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['mode'] ='EPISODE' 
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['programcode']=cGqbmKUQLluhxgMCtikjpdDrHEIeoT
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['page'] =cGqbmKUQLluhxgMCtikjpdDrHEIeRX(cGqbmKUQLluhxgMCtikjpdDrHEIeoB+1)
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS='[B]%s >>[/B]'%'다음 페이지'
   cGqbmKUQLluhxgMCtikjpdDrHEIeoP=cGqbmKUQLluhxgMCtikjpdDrHEIeRX(cGqbmKUQLluhxgMCtikjpdDrHEIeoB+1)
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel=cGqbmKUQLluhxgMCtikjpdDrHEIeoP,img='',infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeBY,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeRO,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeRo(cGqbmKUQLluhxgMCtikjpdDrHEIeoa)>0:xbmcplugin.endOfDirectory(cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_handle,cacheToDisc=cGqbmKUQLluhxgMCtikjpdDrHEIeRO)
 def dp_setEpOrderby(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeoX):
  cGqbmKUQLluhxgMCtikjpdDrHEIeof =cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('orderby')
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.set_winEpisodeOrderby(cGqbmKUQLluhxgMCtikjpdDrHEIeof)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeoX):
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.SaveCredential(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_winCredential())
  cGqbmKUQLluhxgMCtikjpdDrHEIeof =cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('orderby')
  cGqbmKUQLluhxgMCtikjpdDrHEIeoB=cGqbmKUQLluhxgMCtikjpdDrHEIeRJ(cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('page'))
  cGqbmKUQLluhxgMCtikjpdDrHEIeoY,cGqbmKUQLluhxgMCtikjpdDrHEIeoS=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.GetMovieList(cGqbmKUQLluhxgMCtikjpdDrHEIeof,cGqbmKUQLluhxgMCtikjpdDrHEIeoB,premiumyn=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_settings_premiumyn(),landyn=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_settings_thumbnail_landyn())
  for cGqbmKUQLluhxgMCtikjpdDrHEIeoF in cGqbmKUQLluhxgMCtikjpdDrHEIeoY:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS =cGqbmKUQLluhxgMCtikjpdDrHEIeoF.get('title')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoz=cGqbmKUQLluhxgMCtikjpdDrHEIeoF.get('thumbnail')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoy =cGqbmKUQLluhxgMCtikjpdDrHEIeoF.get('synopsis')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoN=cGqbmKUQLluhxgMCtikjpdDrHEIeoF.get('info')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoN['plot']='%s\n\n%s'%(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,cGqbmKUQLluhxgMCtikjpdDrHEIeoy)
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':'MOVIE','mediacode':cGqbmKUQLluhxgMCtikjpdDrHEIeoF.get('moviecode'),'stype':'movie','title':cGqbmKUQLluhxgMCtikjpdDrHEIeJS,'thumbnail':cGqbmKUQLluhxgMCtikjpdDrHEIeoz}
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel='',img=cGqbmKUQLluhxgMCtikjpdDrHEIeoz,infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeoN,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeBF,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeoS:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['mode'] ='MOVIE_GROUP' 
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['orderby']=cGqbmKUQLluhxgMCtikjpdDrHEIeof
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['page'] =cGqbmKUQLluhxgMCtikjpdDrHEIeRX(cGqbmKUQLluhxgMCtikjpdDrHEIeoB+1)
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS='[B]%s >>[/B]'%'다음 페이지'
   cGqbmKUQLluhxgMCtikjpdDrHEIeoP=cGqbmKUQLluhxgMCtikjpdDrHEIeRX(cGqbmKUQLluhxgMCtikjpdDrHEIeoB+1)
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel=cGqbmKUQLluhxgMCtikjpdDrHEIeoP,img='',infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeBY,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeRO,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeRo(cGqbmKUQLluhxgMCtikjpdDrHEIeoY)>0:xbmcplugin.endOfDirectory(cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_handle,cacheToDisc=cGqbmKUQLluhxgMCtikjpdDrHEIeBF)
 def dp_Search_Group(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeoX):
  for cGqbmKUQLluhxgMCtikjpdDrHEIeoJ in cGqbmKUQLluhxgMCtikjpdDrHEIeOR:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS=cGqbmKUQLluhxgMCtikjpdDrHEIeoJ.get('title')
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':cGqbmKUQLluhxgMCtikjpdDrHEIeoJ.get('mode'),'stype':cGqbmKUQLluhxgMCtikjpdDrHEIeoJ.get('stype'),'page':'1'}
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel='',img='',infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeBY,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeRO,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeRo(cGqbmKUQLluhxgMCtikjpdDrHEIeOR)>0:xbmcplugin.endOfDirectory(cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_handle)
 def dp_Search_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeoX):
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.SaveCredential(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_winCredential())
  cGqbmKUQLluhxgMCtikjpdDrHEIeXO =__addon__.getSetting('id')
  cGqbmKUQLluhxgMCtikjpdDrHEIeoB =cGqbmKUQLluhxgMCtikjpdDrHEIeRJ(cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('page'))
  cGqbmKUQLluhxgMCtikjpdDrHEIeJF =cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('stype')
  if 'search_key' in cGqbmKUQLluhxgMCtikjpdDrHEIeoX:
   cGqbmKUQLluhxgMCtikjpdDrHEIeXJ=cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('search_key')
  else:
   cGqbmKUQLluhxgMCtikjpdDrHEIeXJ=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not cGqbmKUQLluhxgMCtikjpdDrHEIeXJ:return
  cGqbmKUQLluhxgMCtikjpdDrHEIeXo,cGqbmKUQLluhxgMCtikjpdDrHEIeoS=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.GetSearchList(cGqbmKUQLluhxgMCtikjpdDrHEIeXJ,cGqbmKUQLluhxgMCtikjpdDrHEIeXO,cGqbmKUQLluhxgMCtikjpdDrHEIeoB,cGqbmKUQLluhxgMCtikjpdDrHEIeJF,premiumyn=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_settings_premiumyn(),landyn=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_settings_thumbnail_landyn())
  if cGqbmKUQLluhxgMCtikjpdDrHEIeRo(cGqbmKUQLluhxgMCtikjpdDrHEIeXo)==0:return
  for cGqbmKUQLluhxgMCtikjpdDrHEIeXB in cGqbmKUQLluhxgMCtikjpdDrHEIeXo:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS =cGqbmKUQLluhxgMCtikjpdDrHEIeXB.get('title')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoz=cGqbmKUQLluhxgMCtikjpdDrHEIeXB.get('thumbnail')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoy =cGqbmKUQLluhxgMCtikjpdDrHEIeXB.get('synopsis')
   cGqbmKUQLluhxgMCtikjpdDrHEIeXR =cGqbmKUQLluhxgMCtikjpdDrHEIeXB.get('program')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoN=cGqbmKUQLluhxgMCtikjpdDrHEIeXB.get('info')
   cGqbmKUQLluhxgMCtikjpdDrHEIeoN['plot']='%s\n\n%s'%(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,cGqbmKUQLluhxgMCtikjpdDrHEIeoy)
   if cGqbmKUQLluhxgMCtikjpdDrHEIeJF=='vod':
    cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':'EPISODE','programcode':cGqbmKUQLluhxgMCtikjpdDrHEIeXB.get('program'),'page':'1'}
    cGqbmKUQLluhxgMCtikjpdDrHEIeJf=cGqbmKUQLluhxgMCtikjpdDrHEIeRO
   else:
    cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':'MOVIE','mediacode':cGqbmKUQLluhxgMCtikjpdDrHEIeXB.get('movie'),'stype':'movie','title':cGqbmKUQLluhxgMCtikjpdDrHEIeJS,'thumbnail':cGqbmKUQLluhxgMCtikjpdDrHEIeoz}
    cGqbmKUQLluhxgMCtikjpdDrHEIeJf=cGqbmKUQLluhxgMCtikjpdDrHEIeBF
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel='',img=cGqbmKUQLluhxgMCtikjpdDrHEIeoz,infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeoN,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeJf,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeoS:
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['mode'] ='SEARCH' 
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['search_key']=cGqbmKUQLluhxgMCtikjpdDrHEIeXJ
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP['page'] =cGqbmKUQLluhxgMCtikjpdDrHEIeRX(cGqbmKUQLluhxgMCtikjpdDrHEIeoB+1)
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS='[B]%s >>[/B]'%'다음 페이지'
   cGqbmKUQLluhxgMCtikjpdDrHEIeoP=cGqbmKUQLluhxgMCtikjpdDrHEIeRX(cGqbmKUQLluhxgMCtikjpdDrHEIeoB+1)
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel=cGqbmKUQLluhxgMCtikjpdDrHEIeoP,img='',infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeBY,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeRO,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeRo(cGqbmKUQLluhxgMCtikjpdDrHEIeXo)>0:xbmcplugin.endOfDirectory(cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_handle)
 def Delete_Watched_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeJF):
  try:
   cGqbmKUQLluhxgMCtikjpdDrHEIeXS=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cGqbmKUQLluhxgMCtikjpdDrHEIeJF))
   fp=cGqbmKUQLluhxgMCtikjpdDrHEIeRB(cGqbmKUQLluhxgMCtikjpdDrHEIeXS,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   cGqbmKUQLluhxgMCtikjpdDrHEIeBY
 def dp_WatchList_Delete(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeoX):
  cGqbmKUQLluhxgMCtikjpdDrHEIeJF=cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('stype')
  cGqbmKUQLluhxgMCtikjpdDrHEIeOW=xbmcgui.Dialog()
  cGqbmKUQLluhxgMCtikjpdDrHEIeJa=cGqbmKUQLluhxgMCtikjpdDrHEIeOW.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if cGqbmKUQLluhxgMCtikjpdDrHEIeJa==cGqbmKUQLluhxgMCtikjpdDrHEIeBF:sys.exit()
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.Delete_Watched_List(cGqbmKUQLluhxgMCtikjpdDrHEIeJF)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeJF):
  try:
   cGqbmKUQLluhxgMCtikjpdDrHEIeXS=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cGqbmKUQLluhxgMCtikjpdDrHEIeJF))
   fp=cGqbmKUQLluhxgMCtikjpdDrHEIeRB(cGqbmKUQLluhxgMCtikjpdDrHEIeXS,'r',-1,'utf-8')
   cGqbmKUQLluhxgMCtikjpdDrHEIeXn=fp.readlines()
   fp.close()
  except:
   cGqbmKUQLluhxgMCtikjpdDrHEIeXn=[]
  return cGqbmKUQLluhxgMCtikjpdDrHEIeXn
 def Save_Watched_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeJF,cGqbmKUQLluhxgMCtikjpdDrHEIeOf):
  try:
   cGqbmKUQLluhxgMCtikjpdDrHEIeXS=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%cGqbmKUQLluhxgMCtikjpdDrHEIeJF))
   cGqbmKUQLluhxgMCtikjpdDrHEIeXz=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.Load_Watched_List(cGqbmKUQLluhxgMCtikjpdDrHEIeJF) 
   fp=cGqbmKUQLluhxgMCtikjpdDrHEIeRB(cGqbmKUQLluhxgMCtikjpdDrHEIeXS,'w',-1,'utf-8')
   cGqbmKUQLluhxgMCtikjpdDrHEIeXy=urllib.parse.urlencode(cGqbmKUQLluhxgMCtikjpdDrHEIeOf)
   cGqbmKUQLluhxgMCtikjpdDrHEIeXy=cGqbmKUQLluhxgMCtikjpdDrHEIeXy+'\n'
   fp.write(cGqbmKUQLluhxgMCtikjpdDrHEIeXy)
   cGqbmKUQLluhxgMCtikjpdDrHEIeXA=0
   for cGqbmKUQLluhxgMCtikjpdDrHEIeXN in cGqbmKUQLluhxgMCtikjpdDrHEIeXz:
    cGqbmKUQLluhxgMCtikjpdDrHEIeXP=cGqbmKUQLluhxgMCtikjpdDrHEIeRS(urllib.parse.parse_qsl(cGqbmKUQLluhxgMCtikjpdDrHEIeXN))
    cGqbmKUQLluhxgMCtikjpdDrHEIeXf=cGqbmKUQLluhxgMCtikjpdDrHEIeOf.get('code')
    cGqbmKUQLluhxgMCtikjpdDrHEIeXs=cGqbmKUQLluhxgMCtikjpdDrHEIeXP.get('code')
    if cGqbmKUQLluhxgMCtikjpdDrHEIeJF=='vod' and cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_settings_direct_replay()==cGqbmKUQLluhxgMCtikjpdDrHEIeRO:
     cGqbmKUQLluhxgMCtikjpdDrHEIeXf=cGqbmKUQLluhxgMCtikjpdDrHEIeOf.get('videoid')
     cGqbmKUQLluhxgMCtikjpdDrHEIeXs=cGqbmKUQLluhxgMCtikjpdDrHEIeXP.get('videoid')if cGqbmKUQLluhxgMCtikjpdDrHEIeXs!=cGqbmKUQLluhxgMCtikjpdDrHEIeBY else '-'
    if cGqbmKUQLluhxgMCtikjpdDrHEIeXf!=cGqbmKUQLluhxgMCtikjpdDrHEIeXs:
     fp.write(cGqbmKUQLluhxgMCtikjpdDrHEIeXN)
     cGqbmKUQLluhxgMCtikjpdDrHEIeXA+=1
     if cGqbmKUQLluhxgMCtikjpdDrHEIeXA>=50:break
   fp.close()
  except:
   cGqbmKUQLluhxgMCtikjpdDrHEIeBY
 def dp_Watch_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeoX):
  cGqbmKUQLluhxgMCtikjpdDrHEIeJF =cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('stype')
  cGqbmKUQLluhxgMCtikjpdDrHEIeJO=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_settings_direct_replay()
  if cGqbmKUQLluhxgMCtikjpdDrHEIeJF=='-':
   for cGqbmKUQLluhxgMCtikjpdDrHEIeoJ in cGqbmKUQLluhxgMCtikjpdDrHEIeOB:
    cGqbmKUQLluhxgMCtikjpdDrHEIeJS=cGqbmKUQLluhxgMCtikjpdDrHEIeoJ.get('title')
    cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':cGqbmKUQLluhxgMCtikjpdDrHEIeoJ.get('mode'),'stype':cGqbmKUQLluhxgMCtikjpdDrHEIeoJ.get('stype')}
    cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel='',img='',infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeBY,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeRO,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
   if cGqbmKUQLluhxgMCtikjpdDrHEIeRo(cGqbmKUQLluhxgMCtikjpdDrHEIeOB)>0:xbmcplugin.endOfDirectory(cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_handle)
  else:
   cGqbmKUQLluhxgMCtikjpdDrHEIeXW=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.Load_Watched_List(cGqbmKUQLluhxgMCtikjpdDrHEIeJF)
   for cGqbmKUQLluhxgMCtikjpdDrHEIeXV in cGqbmKUQLluhxgMCtikjpdDrHEIeXW:
    cGqbmKUQLluhxgMCtikjpdDrHEIeXT=cGqbmKUQLluhxgMCtikjpdDrHEIeRS(urllib.parse.parse_qsl(cGqbmKUQLluhxgMCtikjpdDrHEIeXV))
    cGqbmKUQLluhxgMCtikjpdDrHEIeJS =cGqbmKUQLluhxgMCtikjpdDrHEIeXT.get('title')
    cGqbmKUQLluhxgMCtikjpdDrHEIeoz=cGqbmKUQLluhxgMCtikjpdDrHEIeXT.get('img')
    cGqbmKUQLluhxgMCtikjpdDrHEIeXa =cGqbmKUQLluhxgMCtikjpdDrHEIeXT.get('videoid')
    cGqbmKUQLluhxgMCtikjpdDrHEIeoN={}
    cGqbmKUQLluhxgMCtikjpdDrHEIeoN['plot']=cGqbmKUQLluhxgMCtikjpdDrHEIeJS
    if cGqbmKUQLluhxgMCtikjpdDrHEIeJF=='vod':
     if cGqbmKUQLluhxgMCtikjpdDrHEIeJO==cGqbmKUQLluhxgMCtikjpdDrHEIeBF or cGqbmKUQLluhxgMCtikjpdDrHEIeXa==cGqbmKUQLluhxgMCtikjpdDrHEIeBY:
      cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':'EPISODE','programcode':cGqbmKUQLluhxgMCtikjpdDrHEIeXT.get('code'),'page':'1'}
      cGqbmKUQLluhxgMCtikjpdDrHEIeJf=cGqbmKUQLluhxgMCtikjpdDrHEIeRO
     else:
      cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':'VOD','mediacode':cGqbmKUQLluhxgMCtikjpdDrHEIeXa,'stype':'vod','programcode':cGqbmKUQLluhxgMCtikjpdDrHEIeXT.get('code'),'title':cGqbmKUQLluhxgMCtikjpdDrHEIeJS,'thumbnail':cGqbmKUQLluhxgMCtikjpdDrHEIeoz}
      cGqbmKUQLluhxgMCtikjpdDrHEIeJf=cGqbmKUQLluhxgMCtikjpdDrHEIeBF
    else:
     cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':'MOVIE','mediacode':cGqbmKUQLluhxgMCtikjpdDrHEIeXT.get('code'),'stype':'movie','title':cGqbmKUQLluhxgMCtikjpdDrHEIeJS,'thumbnail':cGqbmKUQLluhxgMCtikjpdDrHEIeoz}
     cGqbmKUQLluhxgMCtikjpdDrHEIeJf=cGqbmKUQLluhxgMCtikjpdDrHEIeBF
    cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel='',img=cGqbmKUQLluhxgMCtikjpdDrHEIeoz,infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeoN,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeJf,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
   cGqbmKUQLluhxgMCtikjpdDrHEIeoN={'plot':'시청목록을 삭제합니다.'}
   cGqbmKUQLluhxgMCtikjpdDrHEIeJS='*** 시청목록 삭제 ***'
   cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'mode':'MYVIEW_REMOVE','stype':cGqbmKUQLluhxgMCtikjpdDrHEIeJF}
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.add_dir(cGqbmKUQLluhxgMCtikjpdDrHEIeJS,sublabel='',img='',infoLabels=cGqbmKUQLluhxgMCtikjpdDrHEIeoN,isFolder=cGqbmKUQLluhxgMCtikjpdDrHEIeBF,params=cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
   xbmcplugin.endOfDirectory(cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_handle,cacheToDisc=cGqbmKUQLluhxgMCtikjpdDrHEIeBF)
 def play_VIDEO(cGqbmKUQLluhxgMCtikjpdDrHEIeOA,cGqbmKUQLluhxgMCtikjpdDrHEIeoX):
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.SaveCredential(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_winCredential())
  cGqbmKUQLluhxgMCtikjpdDrHEIeXv =cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('mediacode')
  cGqbmKUQLluhxgMCtikjpdDrHEIeJF =cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('stype')
  cGqbmKUQLluhxgMCtikjpdDrHEIeXY=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.get_selQuality(cGqbmKUQLluhxgMCtikjpdDrHEIeJF)
  cGqbmKUQLluhxgMCtikjpdDrHEIeXF,cGqbmKUQLluhxgMCtikjpdDrHEIeBO=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.GetBroadURL(cGqbmKUQLluhxgMCtikjpdDrHEIeXv,cGqbmKUQLluhxgMCtikjpdDrHEIeXY,cGqbmKUQLluhxgMCtikjpdDrHEIeJF)
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.addon_log('qt, stype, url : %s - %s - %s'%(cGqbmKUQLluhxgMCtikjpdDrHEIeRX(cGqbmKUQLluhxgMCtikjpdDrHEIeXY),cGqbmKUQLluhxgMCtikjpdDrHEIeJF,cGqbmKUQLluhxgMCtikjpdDrHEIeXF))
  if cGqbmKUQLluhxgMCtikjpdDrHEIeXF=='':
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.addon_noti(__language__(30908).encode('utf8'))
   return
  cGqbmKUQLluhxgMCtikjpdDrHEIeBJ =cGqbmKUQLluhxgMCtikjpdDrHEIeXF.find('Policy=')
  if cGqbmKUQLluhxgMCtikjpdDrHEIeBJ!=-1:
   cGqbmKUQLluhxgMCtikjpdDrHEIeBo =cGqbmKUQLluhxgMCtikjpdDrHEIeXF.split('?')[0]
   cGqbmKUQLluhxgMCtikjpdDrHEIeBX=cGqbmKUQLluhxgMCtikjpdDrHEIeRS(urllib.parse.parse_qsl(urllib.parse.urlsplit(cGqbmKUQLluhxgMCtikjpdDrHEIeXF).query))
   cGqbmKUQLluhxgMCtikjpdDrHEIeBX=urllib.parse.urlencode(cGqbmKUQLluhxgMCtikjpdDrHEIeBX)
   cGqbmKUQLluhxgMCtikjpdDrHEIeBX=cGqbmKUQLluhxgMCtikjpdDrHEIeBX.replace('&',';')
   cGqbmKUQLluhxgMCtikjpdDrHEIeBX=cGqbmKUQLluhxgMCtikjpdDrHEIeBX.replace('Policy','CloudFront-Policy')
   cGqbmKUQLluhxgMCtikjpdDrHEIeBX=cGqbmKUQLluhxgMCtikjpdDrHEIeBX.replace('Signature','CloudFront-Signature')
   cGqbmKUQLluhxgMCtikjpdDrHEIeBX=cGqbmKUQLluhxgMCtikjpdDrHEIeBX.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   cGqbmKUQLluhxgMCtikjpdDrHEIeBR='%s|Cookie=%s'%(cGqbmKUQLluhxgMCtikjpdDrHEIeBo,cGqbmKUQLluhxgMCtikjpdDrHEIeBX)
  else:
   cGqbmKUQLluhxgMCtikjpdDrHEIeBR=cGqbmKUQLluhxgMCtikjpdDrHEIeXF
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.addon_log(cGqbmKUQLluhxgMCtikjpdDrHEIeBR)
  cGqbmKUQLluhxgMCtikjpdDrHEIeBS=xbmcgui.ListItem(path=cGqbmKUQLluhxgMCtikjpdDrHEIeBR)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeBO!='':
   cGqbmKUQLluhxgMCtikjpdDrHEIeBn=cGqbmKUQLluhxgMCtikjpdDrHEIeBO
   cGqbmKUQLluhxgMCtikjpdDrHEIeBz ='https://cj.drmkeyserver.com/widevine_license'
   cGqbmKUQLluhxgMCtikjpdDrHEIeBy ='mpd'
   cGqbmKUQLluhxgMCtikjpdDrHEIeBA ='com.widevine.alpha'
   cGqbmKUQLluhxgMCtikjpdDrHEIeBN =inputstreamhelper.Helper(cGqbmKUQLluhxgMCtikjpdDrHEIeBy,drm='widevine')
   if cGqbmKUQLluhxgMCtikjpdDrHEIeBN.check_inputstream():
    cGqbmKUQLluhxgMCtikjpdDrHEIeBP={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%cGqbmKUQLluhxgMCtikjpdDrHEIeXv,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':cGqbmKUQLluhxgMCtikjpdDrHEIeOz,'AcquireLicenseAssertion':cGqbmKUQLluhxgMCtikjpdDrHEIeBn,'Host':'cj.drmkeyserver.com'}
    cGqbmKUQLluhxgMCtikjpdDrHEIeBf=cGqbmKUQLluhxgMCtikjpdDrHEIeBz+'|'+urllib.parse.urlencode(cGqbmKUQLluhxgMCtikjpdDrHEIeBP)+'|R{SSM}|'
    cGqbmKUQLluhxgMCtikjpdDrHEIeBS.setProperty('inputstream',cGqbmKUQLluhxgMCtikjpdDrHEIeBN.inputstream_addon)
    cGqbmKUQLluhxgMCtikjpdDrHEIeBS.setProperty('inputstream.adaptive.manifest_type',cGqbmKUQLluhxgMCtikjpdDrHEIeBy)
    cGqbmKUQLluhxgMCtikjpdDrHEIeBS.setProperty('inputstream.adaptive.license_type',cGqbmKUQLluhxgMCtikjpdDrHEIeBA)
    cGqbmKUQLluhxgMCtikjpdDrHEIeBS.setProperty('inputstream.adaptive.license_key',cGqbmKUQLluhxgMCtikjpdDrHEIeBf)
    cGqbmKUQLluhxgMCtikjpdDrHEIeBS.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(cGqbmKUQLluhxgMCtikjpdDrHEIeOz))
  xbmcplugin.setResolvedUrl(cGqbmKUQLluhxgMCtikjpdDrHEIeOA._addon_handle,cGqbmKUQLluhxgMCtikjpdDrHEIeRO,cGqbmKUQLluhxgMCtikjpdDrHEIeBS)
  try:
   if cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('mode')in['VOD','MOVIE']and cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('title'):
    cGqbmKUQLluhxgMCtikjpdDrHEIeJP={'code':cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('programcode')if cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('mode')=='VOD' else cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('mediacode'),'img':cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('thumbnail'),'title':cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('title'),'videoid':cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('mediacode')}
    cGqbmKUQLluhxgMCtikjpdDrHEIeOA.Save_Watched_List(cGqbmKUQLluhxgMCtikjpdDrHEIeoX.get('stype'),cGqbmKUQLluhxgMCtikjpdDrHEIeJP)
  except:
   cGqbmKUQLluhxgMCtikjpdDrHEIeBY
 def logout(cGqbmKUQLluhxgMCtikjpdDrHEIeOA):
  cGqbmKUQLluhxgMCtikjpdDrHEIeOW=xbmcgui.Dialog()
  cGqbmKUQLluhxgMCtikjpdDrHEIeJa=cGqbmKUQLluhxgMCtikjpdDrHEIeOW.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if cGqbmKUQLluhxgMCtikjpdDrHEIeJa==cGqbmKUQLluhxgMCtikjpdDrHEIeBF:sys.exit()
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.wininfo_clear()
  if os.path.isfile(cGqbmKUQLluhxgMCtikjpdDrHEIeOy):os.remove(cGqbmKUQLluhxgMCtikjpdDrHEIeOy)
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(cGqbmKUQLluhxgMCtikjpdDrHEIeOA):
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX=xbmcgui.Window(10000)
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX.setProperty('TVING_M_TOKEN','')
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX.setProperty('TVING_M_USERINFO','')
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX.setProperty('TVING_M_UUID','')
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX.setProperty('TVING_M_LOGINTIME','')
 def cookiefile_save(cGqbmKUQLluhxgMCtikjpdDrHEIeOA):
  cGqbmKUQLluhxgMCtikjpdDrHEIeBs =cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.Get_Now_Datetime()
  cGqbmKUQLluhxgMCtikjpdDrHEIeBW=cGqbmKUQLluhxgMCtikjpdDrHEIeBs+datetime.timedelta(days=cGqbmKUQLluhxgMCtikjpdDrHEIeRJ(__addon__.getSetting('cache_ttl')))
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX=xbmcgui.Window(10000)
  cGqbmKUQLluhxgMCtikjpdDrHEIeBV={'tving_token':cGqbmKUQLluhxgMCtikjpdDrHEIeJX.getProperty('TVING_M_TOKEN'),'tving_userinfo':cGqbmKUQLluhxgMCtikjpdDrHEIeJX.getProperty('TVING_M_USERINFO'),'tving_uuid':cGqbmKUQLluhxgMCtikjpdDrHEIeJX.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_limitdate':cGqbmKUQLluhxgMCtikjpdDrHEIeBW.strftime('%Y-%m-%d')}
  try: 
   fp=cGqbmKUQLluhxgMCtikjpdDrHEIeRB(cGqbmKUQLluhxgMCtikjpdDrHEIeOy,'w',-1,'utf-8')
   json.dump(cGqbmKUQLluhxgMCtikjpdDrHEIeBV,fp)
   fp.close()
  except cGqbmKUQLluhxgMCtikjpdDrHEIeRn as exception:
   cGqbmKUQLluhxgMCtikjpdDrHEIeRz(exception)
 def cookiefile_check(cGqbmKUQLluhxgMCtikjpdDrHEIeOA):
  cGqbmKUQLluhxgMCtikjpdDrHEIeBV={}
  try: 
   fp=cGqbmKUQLluhxgMCtikjpdDrHEIeRB(cGqbmKUQLluhxgMCtikjpdDrHEIeOy,'r',-1,'utf-8')
   cGqbmKUQLluhxgMCtikjpdDrHEIeBV= json.load(fp)
   fp.close()
  except cGqbmKUQLluhxgMCtikjpdDrHEIeRn as exception:
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.wininfo_clear()
   return cGqbmKUQLluhxgMCtikjpdDrHEIeBF
  cGqbmKUQLluhxgMCtikjpdDrHEIeJW =__addon__.getSetting('id')
  cGqbmKUQLluhxgMCtikjpdDrHEIeJV =__addon__.getSetting('pw')
  cGqbmKUQLluhxgMCtikjpdDrHEIeBT=__addon__.getSetting('login_type')
  cGqbmKUQLluhxgMCtikjpdDrHEIeBV['tving_id']=base64.standard_b64decode(cGqbmKUQLluhxgMCtikjpdDrHEIeBV['tving_id']).decode('utf-8')
  cGqbmKUQLluhxgMCtikjpdDrHEIeBV['tving_pw']=base64.standard_b64decode(cGqbmKUQLluhxgMCtikjpdDrHEIeBV['tving_pw']).decode('utf-8')
  if cGqbmKUQLluhxgMCtikjpdDrHEIeJW!=cGqbmKUQLluhxgMCtikjpdDrHEIeBV['tving_id']or cGqbmKUQLluhxgMCtikjpdDrHEIeJV!=cGqbmKUQLluhxgMCtikjpdDrHEIeBV['tving_pw']or cGqbmKUQLluhxgMCtikjpdDrHEIeBT!=cGqbmKUQLluhxgMCtikjpdDrHEIeBV['tving_logintype']:
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.wininfo_clear()
   return cGqbmKUQLluhxgMCtikjpdDrHEIeBF
  cGqbmKUQLluhxgMCtikjpdDrHEIeJw =cGqbmKUQLluhxgMCtikjpdDrHEIeRJ(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  cGqbmKUQLluhxgMCtikjpdDrHEIeBa=cGqbmKUQLluhxgMCtikjpdDrHEIeBV['tving_limitdate']
  cGqbmKUQLluhxgMCtikjpdDrHEIeJv =cGqbmKUQLluhxgMCtikjpdDrHEIeRJ(re.sub('-','',cGqbmKUQLluhxgMCtikjpdDrHEIeBa))
  if cGqbmKUQLluhxgMCtikjpdDrHEIeJv<cGqbmKUQLluhxgMCtikjpdDrHEIeJw:
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.wininfo_clear()
   return cGqbmKUQLluhxgMCtikjpdDrHEIeBF
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX=xbmcgui.Window(10000)
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX.setProperty('TVING_M_TOKEN',cGqbmKUQLluhxgMCtikjpdDrHEIeBV['tving_token'])
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX.setProperty('TVING_M_USERINFO',cGqbmKUQLluhxgMCtikjpdDrHEIeBV['tving_userinfo'])
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX.setProperty('TVING_M_UUID',cGqbmKUQLluhxgMCtikjpdDrHEIeBV['tving_uuid'])
  cGqbmKUQLluhxgMCtikjpdDrHEIeJX.setProperty('TVING_M_LOGINTIME',cGqbmKUQLluhxgMCtikjpdDrHEIeBa)
  return cGqbmKUQLluhxgMCtikjpdDrHEIeRO
 def tving_main(cGqbmKUQLluhxgMCtikjpdDrHEIeOA):
  cGqbmKUQLluhxgMCtikjpdDrHEIeBw=cGqbmKUQLluhxgMCtikjpdDrHEIeOA.main_params.get('mode',cGqbmKUQLluhxgMCtikjpdDrHEIeBY)
  if cGqbmKUQLluhxgMCtikjpdDrHEIeBw=='LOGOUT':
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.logout()
   return
  cGqbmKUQLluhxgMCtikjpdDrHEIeOA.login_main()
  if cGqbmKUQLluhxgMCtikjpdDrHEIeBw is cGqbmKUQLluhxgMCtikjpdDrHEIeBY:
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.dp_Main_List()
  elif cGqbmKUQLluhxgMCtikjpdDrHEIeBw in['LIVE_GROUP','VOD_GROUP']:
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.dp_Title_Group(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.main_params)
  elif cGqbmKUQLluhxgMCtikjpdDrHEIeBw=='CHANNEL':
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.dp_LiveChannel_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.main_params)
  elif cGqbmKUQLluhxgMCtikjpdDrHEIeBw in['LIVE','VOD','MOVIE']:
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.play_VIDEO(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.main_params)
  elif cGqbmKUQLluhxgMCtikjpdDrHEIeBw=='PROGRAM':
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.dp_Program_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.main_params)
  elif cGqbmKUQLluhxgMCtikjpdDrHEIeBw=='EPISODE':
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.dp_Episode_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.main_params)
  elif cGqbmKUQLluhxgMCtikjpdDrHEIeBw=='MOVIE_GROUP':
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.dp_Movie_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.main_params)
  elif cGqbmKUQLluhxgMCtikjpdDrHEIeBw=='SEARCH_GROUP':
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.dp_Search_Group(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.main_params)
  elif cGqbmKUQLluhxgMCtikjpdDrHEIeBw=='SEARCH':
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.dp_Search_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.main_params)
  elif cGqbmKUQLluhxgMCtikjpdDrHEIeBw=='WATCH':
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.dp_Watch_List(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.main_params)
  elif cGqbmKUQLluhxgMCtikjpdDrHEIeBw=='MYVIEW_REMOVE':
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.dp_WatchList_Delete(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.main_params)
  elif cGqbmKUQLluhxgMCtikjpdDrHEIeBw=='ORDER_BY':
   cGqbmKUQLluhxgMCtikjpdDrHEIeOA.dp_setEpOrderby(cGqbmKUQLluhxgMCtikjpdDrHEIeOA.main_params)
  else:
   cGqbmKUQLluhxgMCtikjpdDrHEIeBY
# Created by pyminifier (https://github.com/liftoff/pyminifier)
