__author__="NightRain"
wirXyMcWBDKdYCHxJPAqOSgkvLuoTe=object
wirXyMcWBDKdYCHxJPAqOSgkvLuoTz=None
wirXyMcWBDKdYCHxJPAqOSgkvLuoTE=False
wirXyMcWBDKdYCHxJPAqOSgkvLuojV=int
wirXyMcWBDKdYCHxJPAqOSgkvLuojU=True
wirXyMcWBDKdYCHxJPAqOSgkvLuojb=Exception
wirXyMcWBDKdYCHxJPAqOSgkvLuojT=print
wirXyMcWBDKdYCHxJPAqOSgkvLuojs=str
wirXyMcWBDKdYCHxJPAqOSgkvLuojF=list
wirXyMcWBDKdYCHxJPAqOSgkvLuojh=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
wirXyMcWBDKdYCHxJPAqOSgkvLuoVb ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
wirXyMcWBDKdYCHxJPAqOSgkvLuoVT={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
class wirXyMcWBDKdYCHxJPAqOSgkvLuoVU(wirXyMcWBDKdYCHxJPAqOSgkvLuoTe):
 def __init__(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj):
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.TVING_TOKEN =''
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.POC_USERINFO =''
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.TVING_UUID ='-'
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.NETWORKCODE ='CSND0900'
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.OSCODE ='CSOD0900' 
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.TELECODE ='CSCD0900'
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.SCREENCODE ='CSSD0100'
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.LIVE_LIMIT =23
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.VOD_LIMIT =20
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.EPISODE_LIMIT=30 
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.SEARCH_LIMIT =80 
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.MOVIE_LIMIT =18
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.API_DOMAIN ='https://api.tving.com'
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN ='https://image.tving.com'
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.SEARCH_DOMAIN='https://search.tving.com'
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.LOGIN_DOMAIN ='https://user.tving.com'
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.URL_DOMAIN ='https://www.tving.com'
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.MOVIE_LITE ='338723'
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.MOVIE_PREMIUM='1513561'
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.DEFAULT_HEADER={'user-agent':wirXyMcWBDKdYCHxJPAqOSgkvLuoVb}
 def callRequestCookies(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,jobtype,wirXyMcWBDKdYCHxJPAqOSgkvLuoVl,payload=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,params=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,cookies=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,redirects=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE):
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVs=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.DEFAULT_HEADER
  if headers:wirXyMcWBDKdYCHxJPAqOSgkvLuoVs.update(headers)
  if jobtype=='Get':
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVF=requests.get(wirXyMcWBDKdYCHxJPAqOSgkvLuoVl,params=params,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoVs,cookies=cookies,allow_redirects=redirects)
  else:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVF=requests.post(wirXyMcWBDKdYCHxJPAqOSgkvLuoVl,data=payload,params=params,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoVs,cookies=cookies,allow_redirects=redirects)
  return wirXyMcWBDKdYCHxJPAqOSgkvLuoVF
 def makeDefaultCookies(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,vToken=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,vUserinfo=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz):
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVh={}
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVh['_tving_token']=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.TVING_TOKEN if vToken==wirXyMcWBDKdYCHxJPAqOSgkvLuoTz else vToken
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVh['POC_USERINFO']=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.POC_USERINFO if vToken==wirXyMcWBDKdYCHxJPAqOSgkvLuoTz else vUserinfo
  return wirXyMcWBDKdYCHxJPAqOSgkvLuoVh
 def getDeviceStr(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj):
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVn=[]
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVn.append('Windows') 
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVn.append('Chrome') 
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVn.append('ko-KR') 
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVn.append('undefined') 
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVn.append('24') 
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVn.append(u'한국 표준시')
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVn.append('undefined') 
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVn.append('undefined') 
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVn.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVm=''
  for wirXyMcWBDKdYCHxJPAqOSgkvLuoVf in wirXyMcWBDKdYCHxJPAqOSgkvLuoVn:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVm+=wirXyMcWBDKdYCHxJPAqOSgkvLuoVf+'|'
  return wirXyMcWBDKdYCHxJPAqOSgkvLuoVm
 def SaveCredential(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,wirXyMcWBDKdYCHxJPAqOSgkvLuoVp):
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.TVING_TOKEN =wirXyMcWBDKdYCHxJPAqOSgkvLuoVp.get('tving_token')
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.POC_USERINFO=wirXyMcWBDKdYCHxJPAqOSgkvLuoVp.get('poc_userinfo')
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.TVING_UUID =wirXyMcWBDKdYCHxJPAqOSgkvLuoVp.get('tving_uuid')
 def LoadCredential(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj):
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVp={'tving_token':wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.TVING_TOKEN,'poc_userinfo':wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.POC_USERINFO,'tving_uuid':wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.TVING_UUID}
  return wirXyMcWBDKdYCHxJPAqOSgkvLuoVp
 def GetDefaultParams(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj):
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVR={'apiKey':wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.APIKEY,'networkCode':wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.NETWORKCODE,'osCode':wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.OSCODE,'teleCode':wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.TELECODE,'screenCode':wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.SCREENCODE}
  return wirXyMcWBDKdYCHxJPAqOSgkvLuoVR
 def GetNoCache(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,timetype=1):
  if timetype==1:
   return wirXyMcWBDKdYCHxJPAqOSgkvLuojV(time.time())
  else:
   return wirXyMcWBDKdYCHxJPAqOSgkvLuojV(time.time()*1000)
 def makeurl(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,domain,path,query1=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,query2=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz):
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVl=domain+path
  if query1:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVl+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVl+='&%s'%urllib.parse.urlencode(query2)
  return wirXyMcWBDKdYCHxJPAqOSgkvLuoVl
 def GetCredential(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,user_id,user_pw,login_type):
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVI=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVN=wirXyMcWBDKdYCHxJPAqOSgkvLuoUV='' 
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVa='-'
  try:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVG=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVe={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'','csite':''}
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVz=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.callRequestCookies('Post',wirXyMcWBDKdYCHxJPAqOSgkvLuoVG,payload=wirXyMcWBDKdYCHxJPAqOSgkvLuoVe,params=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,cookies=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz)
   for wirXyMcWBDKdYCHxJPAqOSgkvLuoVE in wirXyMcWBDKdYCHxJPAqOSgkvLuoVz.cookies:
    if wirXyMcWBDKdYCHxJPAqOSgkvLuoVE.name=='_tving_token':
     wirXyMcWBDKdYCHxJPAqOSgkvLuoVN=wirXyMcWBDKdYCHxJPAqOSgkvLuoVE.value
    elif wirXyMcWBDKdYCHxJPAqOSgkvLuoVE.name=='POC_USERINFO':
     wirXyMcWBDKdYCHxJPAqOSgkvLuoUV=wirXyMcWBDKdYCHxJPAqOSgkvLuoVE.value
   if wirXyMcWBDKdYCHxJPAqOSgkvLuoVN:wirXyMcWBDKdYCHxJPAqOSgkvLuoVI=wirXyMcWBDKdYCHxJPAqOSgkvLuojU
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVa=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetDeviceList(wirXyMcWBDKdYCHxJPAqOSgkvLuoVN,wirXyMcWBDKdYCHxJPAqOSgkvLuoUV)
  except wirXyMcWBDKdYCHxJPAqOSgkvLuojb as exception:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVN=wirXyMcWBDKdYCHxJPAqOSgkvLuoUV='' 
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVa='-'
   wirXyMcWBDKdYCHxJPAqOSgkvLuojT(exception)
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVp={'tving_token':wirXyMcWBDKdYCHxJPAqOSgkvLuoVN,'poc_userinfo':wirXyMcWBDKdYCHxJPAqOSgkvLuoUV,'tving_uuid':wirXyMcWBDKdYCHxJPAqOSgkvLuoVa}
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.SaveCredential(wirXyMcWBDKdYCHxJPAqOSgkvLuoVp)
  return wirXyMcWBDKdYCHxJPAqOSgkvLuoVI
 def Get_Now_Datetime(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,mediacode,sel_quality,stype):
  wirXyMcWBDKdYCHxJPAqOSgkvLuoUT=''
  wirXyMcWBDKdYCHxJPAqOSgkvLuoUj=''
  wirXyMcWBDKdYCHxJPAqOSgkvLuoUs=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.TVING_UUID 
  try:
   if stype!='tvingtv':
    wirXyMcWBDKdYCHxJPAqOSgkvLuoUF ='/v2/media/stream/info'
    wirXyMcWBDKdYCHxJPAqOSgkvLuoUh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetDefaultParams()
    wirXyMcWBDKdYCHxJPAqOSgkvLuoUn={'info':'Y','mediaCode':mediacode,'noCache':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetNoCache(1)),'callingFrom':'HTML5','adReq':'none','ooc':'','deviceId':wirXyMcWBDKdYCHxJPAqOSgkvLuoUs,'wm':'Y'}
    wirXyMcWBDKdYCHxJPAqOSgkvLuoUh.update(wirXyMcWBDKdYCHxJPAqOSgkvLuoUn)
    wirXyMcWBDKdYCHxJPAqOSgkvLuoVl=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeurl(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.API_DOMAIN,wirXyMcWBDKdYCHxJPAqOSgkvLuoUF)
    wirXyMcWBDKdYCHxJPAqOSgkvLuoVh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeDefaultCookies()
    wirXyMcWBDKdYCHxJPAqOSgkvLuoVz=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.callRequestCookies('Get',wirXyMcWBDKdYCHxJPAqOSgkvLuoVl,payload=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,params=wirXyMcWBDKdYCHxJPAqOSgkvLuoUh,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,cookies=wirXyMcWBDKdYCHxJPAqOSgkvLuoVh)
    wirXyMcWBDKdYCHxJPAqOSgkvLuoUm=json.loads(wirXyMcWBDKdYCHxJPAqOSgkvLuoVz.text)
    if not('stream' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']):return wirXyMcWBDKdYCHxJPAqOSgkvLuoUT,wirXyMcWBDKdYCHxJPAqOSgkvLuoUj 
    wirXyMcWBDKdYCHxJPAqOSgkvLuoUf=wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']['stream']
    if 'drm_license_assertion' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUf:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoUj=wirXyMcWBDKdYCHxJPAqOSgkvLuoUf['drm_license_assertion']
    wirXyMcWBDKdYCHxJPAqOSgkvLuoUp=wirXyMcWBDKdYCHxJPAqOSgkvLuoUf['quality']
    wirXyMcWBDKdYCHxJPAqOSgkvLuoUR=[]
    for wirXyMcWBDKdYCHxJPAqOSgkvLuoUl in wirXyMcWBDKdYCHxJPAqOSgkvLuoUp:
     if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['active']=='Y':
      wirXyMcWBDKdYCHxJPAqOSgkvLuoUR.append({wirXyMcWBDKdYCHxJPAqOSgkvLuoVT.get(wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['code']):wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['code']})
    wirXyMcWBDKdYCHxJPAqOSgkvLuoUt=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.CheckQuality(sel_quality,wirXyMcWBDKdYCHxJPAqOSgkvLuoUR)
   else:
    for wirXyMcWBDKdYCHxJPAqOSgkvLuoUQ,wirXyMcWBDKdYCHxJPAqOSgkvLuobV in wirXyMcWBDKdYCHxJPAqOSgkvLuoVT.items():
     if wirXyMcWBDKdYCHxJPAqOSgkvLuobV==sel_quality:
      wirXyMcWBDKdYCHxJPAqOSgkvLuoUt=wirXyMcWBDKdYCHxJPAqOSgkvLuoUQ
  except wirXyMcWBDKdYCHxJPAqOSgkvLuojb as exception:
   wirXyMcWBDKdYCHxJPAqOSgkvLuojT(exception)
   for wirXyMcWBDKdYCHxJPAqOSgkvLuoUQ,wirXyMcWBDKdYCHxJPAqOSgkvLuobV in wirXyMcWBDKdYCHxJPAqOSgkvLuoVT.items():
    if wirXyMcWBDKdYCHxJPAqOSgkvLuobV==sel_quality:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoUt=wirXyMcWBDKdYCHxJPAqOSgkvLuoUQ
   return wirXyMcWBDKdYCHxJPAqOSgkvLuoUT,wirXyMcWBDKdYCHxJPAqOSgkvLuoUj
  try:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUF ='/streaming/info'
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetDefaultParams()
   if stype=='onair':wirXyMcWBDKdYCHxJPAqOSgkvLuoUh['osCode']='CSOD0400' 
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUI={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2158.7350000045262','returnValue':'true','cancelBubble':'false'}
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUN=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeOocUrl(wirXyMcWBDKdYCHxJPAqOSgkvLuoUI)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUa=urllib.parse.quote(wirXyMcWBDKdYCHxJPAqOSgkvLuoUN)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUn={'info':'Y','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':wirXyMcWBDKdYCHxJPAqOSgkvLuoUt,'adReq':'none','ooc':wirXyMcWBDKdYCHxJPAqOSgkvLuoUN,'deviceId':wirXyMcWBDKdYCHxJPAqOSgkvLuoUs}
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUG =wirXyMcWBDKdYCHxJPAqOSgkvLuoUh
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUG.update(wirXyMcWBDKdYCHxJPAqOSgkvLuoUn)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVl=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.URL_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuoUF
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUe={'origin':'https://www.tving.com','Referer':'https://www.tving.com/vod/player/'+mediacode}
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeDefaultCookies()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVh['onClickEvent2']=wirXyMcWBDKdYCHxJPAqOSgkvLuoUa
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVz=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.callRequestCookies('Post',wirXyMcWBDKdYCHxJPAqOSgkvLuoVl,payload=wirXyMcWBDKdYCHxJPAqOSgkvLuoUG,params=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoUe,cookies=wirXyMcWBDKdYCHxJPAqOSgkvLuoVh)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUm=json.loads(wirXyMcWBDKdYCHxJPAqOSgkvLuoVz.text)
   if wirXyMcWBDKdYCHxJPAqOSgkvLuoUj!='':
    wirXyMcWBDKdYCHxJPAqOSgkvLuoUj =wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['stream']['drm_license_assertion']
    wirXyMcWBDKdYCHxJPAqOSgkvLuoUT=wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['stream']['broadcast']):return wirXyMcWBDKdYCHxJPAqOSgkvLuoUT,wirXyMcWBDKdYCHxJPAqOSgkvLuoUj
    wirXyMcWBDKdYCHxJPAqOSgkvLuoUT=wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['stream']['broadcast']['broad_url']
  except wirXyMcWBDKdYCHxJPAqOSgkvLuojb as exception:
   wirXyMcWBDKdYCHxJPAqOSgkvLuojT(exception)
  return wirXyMcWBDKdYCHxJPAqOSgkvLuoUT,wirXyMcWBDKdYCHxJPAqOSgkvLuoUj
 def CheckQuality(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,sel_qt,wirXyMcWBDKdYCHxJPAqOSgkvLuoUR):
  for wirXyMcWBDKdYCHxJPAqOSgkvLuoUz in wirXyMcWBDKdYCHxJPAqOSgkvLuoUR:
   if sel_qt>=wirXyMcWBDKdYCHxJPAqOSgkvLuojF(wirXyMcWBDKdYCHxJPAqOSgkvLuoUz)[0]:return wirXyMcWBDKdYCHxJPAqOSgkvLuoUz.get(wirXyMcWBDKdYCHxJPAqOSgkvLuojF(wirXyMcWBDKdYCHxJPAqOSgkvLuoUz)[0])
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUE=wirXyMcWBDKdYCHxJPAqOSgkvLuoUz.get(wirXyMcWBDKdYCHxJPAqOSgkvLuojF(wirXyMcWBDKdYCHxJPAqOSgkvLuoUz)[0])
  return wirXyMcWBDKdYCHxJPAqOSgkvLuoUE
 def makeOocUrl(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,wirXyMcWBDKdYCHxJPAqOSgkvLuoUI):
  wirXyMcWBDKdYCHxJPAqOSgkvLuoVl=''
  for wirXyMcWBDKdYCHxJPAqOSgkvLuoUQ,wirXyMcWBDKdYCHxJPAqOSgkvLuobV in wirXyMcWBDKdYCHxJPAqOSgkvLuoUI.items():
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVl+="%s=%s^"%(wirXyMcWBDKdYCHxJPAqOSgkvLuoUQ,wirXyMcWBDKdYCHxJPAqOSgkvLuobV)
  return wirXyMcWBDKdYCHxJPAqOSgkvLuoVl
 def GetLiveChannelList(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,stype,page_int):
  wirXyMcWBDKdYCHxJPAqOSgkvLuobU=[]
  wirXyMcWBDKdYCHxJPAqOSgkvLuobT=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE
  try:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUF ='/v2/media/lives'
   if stype=='onair':
    wirXyMcWBDKdYCHxJPAqOSgkvLuobj='CPCS0100,CPCS0400'
   else:
    wirXyMcWBDKdYCHxJPAqOSgkvLuobj='CPCS0300'
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetDefaultParams()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUn={'pageNo':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(page_int),'pageSize':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':wirXyMcWBDKdYCHxJPAqOSgkvLuobj,'_':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetNoCache(2))}
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUh.update(wirXyMcWBDKdYCHxJPAqOSgkvLuoUn)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVl=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeurl(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.API_DOMAIN,wirXyMcWBDKdYCHxJPAqOSgkvLuoUF)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeDefaultCookies()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVz=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.callRequestCookies('Get',wirXyMcWBDKdYCHxJPAqOSgkvLuoVl,payload=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,params=wirXyMcWBDKdYCHxJPAqOSgkvLuoUh,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,cookies=wirXyMcWBDKdYCHxJPAqOSgkvLuoVh)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUm=json.loads(wirXyMcWBDKdYCHxJPAqOSgkvLuoVz.text)
   if not('result' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']):return wirXyMcWBDKdYCHxJPAqOSgkvLuobU,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
   wirXyMcWBDKdYCHxJPAqOSgkvLuobs=wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']['result']
   for wirXyMcWBDKdYCHxJPAqOSgkvLuoUl in wirXyMcWBDKdYCHxJPAqOSgkvLuobs:
    wirXyMcWBDKdYCHxJPAqOSgkvLuobF={}
    wirXyMcWBDKdYCHxJPAqOSgkvLuobF['mediatype']='video'
    wirXyMcWBDKdYCHxJPAqOSgkvLuobh=wirXyMcWBDKdYCHxJPAqOSgkvLuobf=wirXyMcWBDKdYCHxJPAqOSgkvLuobp=wirXyMcWBDKdYCHxJPAqOSgkvLuobR=''
    wirXyMcWBDKdYCHxJPAqOSgkvLuobn=wirXyMcWBDKdYCHxJPAqOSgkvLuobI=''
    wirXyMcWBDKdYCHxJPAqOSgkvLuobm=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['live_code']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobh =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['channel']['name']['ko']
    if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['episode']!=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz:
     wirXyMcWBDKdYCHxJPAqOSgkvLuobf =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['program']['name']['ko']
     wirXyMcWBDKdYCHxJPAqOSgkvLuobf =wirXyMcWBDKdYCHxJPAqOSgkvLuobf+', '+wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['episode']['frequency'])+'회'
     if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['episode']['image']!=[]:
      wirXyMcWBDKdYCHxJPAqOSgkvLuobp=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['episode']['image'][0]['url']
     wirXyMcWBDKdYCHxJPAqOSgkvLuobR=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['episode']['synopsis']['ko']
    else:
     wirXyMcWBDKdYCHxJPAqOSgkvLuobf =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['program']['name']['ko']
     if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['program']['image']!=[]:
      wirXyMcWBDKdYCHxJPAqOSgkvLuobp=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['program']['image'][0]['url']
     wirXyMcWBDKdYCHxJPAqOSgkvLuobR=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['program']['synopsis']['ko']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobF['title'] =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['program']['name']['ko']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobF['studio'] =wirXyMcWBDKdYCHxJPAqOSgkvLuobh
    try:
     wirXyMcWBDKdYCHxJPAqOSgkvLuobl=[]
     for wirXyMcWBDKdYCHxJPAqOSgkvLuobt in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('schedule').get('program').get('actor'):wirXyMcWBDKdYCHxJPAqOSgkvLuobl.append(wirXyMcWBDKdYCHxJPAqOSgkvLuobt)
     if wirXyMcWBDKdYCHxJPAqOSgkvLuobl[0]!='' and wirXyMcWBDKdYCHxJPAqOSgkvLuobl[0]!=u'없음':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['cast']=wirXyMcWBDKdYCHxJPAqOSgkvLuobl
    except:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
    try:
     wirXyMcWBDKdYCHxJPAqOSgkvLuobQ=[]
     if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('schedule').get('program').get('category1_name').get('ko')!='':
      wirXyMcWBDKdYCHxJPAqOSgkvLuobQ.append(wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['program']['category1_name']['ko'])
     if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('schedule').get('program').get('category2_name').get('ko')!='':
      wirXyMcWBDKdYCHxJPAqOSgkvLuobQ.append(wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['program']['category2_name']['ko'])
     if wirXyMcWBDKdYCHxJPAqOSgkvLuobQ[0]!='':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['genre']=wirXyMcWBDKdYCHxJPAqOSgkvLuobQ
    except:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
    if wirXyMcWBDKdYCHxJPAqOSgkvLuobp=='':
     wirXyMcWBDKdYCHxJPAqOSgkvLuobp=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['channel']['image'][0]['url']
    if wirXyMcWBDKdYCHxJPAqOSgkvLuobp!='':wirXyMcWBDKdYCHxJPAqOSgkvLuobp=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuobp
    wirXyMcWBDKdYCHxJPAqOSgkvLuobn=wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['broadcast_start_time'])[8:12]
    wirXyMcWBDKdYCHxJPAqOSgkvLuobI =wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['schedule']['broadcast_end_time'])[8:12]
    wirXyMcWBDKdYCHxJPAqOSgkvLuobN={'channel':wirXyMcWBDKdYCHxJPAqOSgkvLuobh,'title':wirXyMcWBDKdYCHxJPAqOSgkvLuobf,'mediacode':wirXyMcWBDKdYCHxJPAqOSgkvLuobm,'thumbnail':wirXyMcWBDKdYCHxJPAqOSgkvLuobp,'synopsis':wirXyMcWBDKdYCHxJPAqOSgkvLuobR,'channelepg':' [%s:%s ~ %s:%s]'%(wirXyMcWBDKdYCHxJPAqOSgkvLuobn[0:2],wirXyMcWBDKdYCHxJPAqOSgkvLuobn[2:],wirXyMcWBDKdYCHxJPAqOSgkvLuobI[0:2],wirXyMcWBDKdYCHxJPAqOSgkvLuobI[2:]),'info':wirXyMcWBDKdYCHxJPAqOSgkvLuobF}
    wirXyMcWBDKdYCHxJPAqOSgkvLuobU.append(wirXyMcWBDKdYCHxJPAqOSgkvLuobN)
   if wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']['has_more']=='Y':wirXyMcWBDKdYCHxJPAqOSgkvLuobT=wirXyMcWBDKdYCHxJPAqOSgkvLuojU
  except wirXyMcWBDKdYCHxJPAqOSgkvLuojb as exception:
   wirXyMcWBDKdYCHxJPAqOSgkvLuojT(exception)
  return wirXyMcWBDKdYCHxJPAqOSgkvLuobU,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
 def GetProgramList(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,stype,orderby,page_int,landyn=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE):
  wirXyMcWBDKdYCHxJPAqOSgkvLuobU=[]
  wirXyMcWBDKdYCHxJPAqOSgkvLuobT=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE
  try:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUF ='/v2/media/episodes'
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetDefaultParams()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUn={'pageNo':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(page_int),'pageSize':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetNoCache(2))}
   if stype!='all':wirXyMcWBDKdYCHxJPAqOSgkvLuoUn['multiCategoryCode']=stype
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUh.update(wirXyMcWBDKdYCHxJPAqOSgkvLuoUn)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVl=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeurl(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.API_DOMAIN,wirXyMcWBDKdYCHxJPAqOSgkvLuoUF)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeDefaultCookies()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVz=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.callRequestCookies('Get',wirXyMcWBDKdYCHxJPAqOSgkvLuoVl,payload=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,params=wirXyMcWBDKdYCHxJPAqOSgkvLuoUh,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,cookies=wirXyMcWBDKdYCHxJPAqOSgkvLuoVh)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUm=json.loads(wirXyMcWBDKdYCHxJPAqOSgkvLuoVz.text)
   if not('result' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']):return wirXyMcWBDKdYCHxJPAqOSgkvLuobU,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
   wirXyMcWBDKdYCHxJPAqOSgkvLuobs=wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']['result']
   for wirXyMcWBDKdYCHxJPAqOSgkvLuoUl in wirXyMcWBDKdYCHxJPAqOSgkvLuobs:
    wirXyMcWBDKdYCHxJPAqOSgkvLuoba=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['program']['code']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobf =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['program']['name']['ko']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobp =wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['program']['image'][0]['url']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobG='CAIP0200' if landyn else 'CAIP0900' 
    for wirXyMcWBDKdYCHxJPAqOSgkvLuobe in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['program']['image']:
     if wirXyMcWBDKdYCHxJPAqOSgkvLuobe['code']==wirXyMcWBDKdYCHxJPAqOSgkvLuobG:
      wirXyMcWBDKdYCHxJPAqOSgkvLuobp =wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuobe['url']
      break
    wirXyMcWBDKdYCHxJPAqOSgkvLuobR =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['program']['synopsis']['ko']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobz=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['program']['channel_code']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobF={}
    wirXyMcWBDKdYCHxJPAqOSgkvLuobF['title'] =wirXyMcWBDKdYCHxJPAqOSgkvLuobf 
    wirXyMcWBDKdYCHxJPAqOSgkvLuobF['mediatype']='episode' 
    try:
     wirXyMcWBDKdYCHxJPAqOSgkvLuobl=[]
     for wirXyMcWBDKdYCHxJPAqOSgkvLuobt in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('program').get('actor'):wirXyMcWBDKdYCHxJPAqOSgkvLuobl.append(wirXyMcWBDKdYCHxJPAqOSgkvLuobt)
     if wirXyMcWBDKdYCHxJPAqOSgkvLuobl[0]!='' and wirXyMcWBDKdYCHxJPAqOSgkvLuobl[0]!='-':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['cast']=wirXyMcWBDKdYCHxJPAqOSgkvLuobl
    except:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
    try:
     wirXyMcWBDKdYCHxJPAqOSgkvLuobE=[]
     for wirXyMcWBDKdYCHxJPAqOSgkvLuoTV in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('program').get('director'):wirXyMcWBDKdYCHxJPAqOSgkvLuobE.append(wirXyMcWBDKdYCHxJPAqOSgkvLuoTV)
     if wirXyMcWBDKdYCHxJPAqOSgkvLuobE[0]!='' and wirXyMcWBDKdYCHxJPAqOSgkvLuobE[0]!='-':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['director']=wirXyMcWBDKdYCHxJPAqOSgkvLuobE
    except:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
    wirXyMcWBDKdYCHxJPAqOSgkvLuobQ=[]
    if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('program').get('category1_name').get('ko')!='':
     wirXyMcWBDKdYCHxJPAqOSgkvLuobQ.append(wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['program']['category1_name']['ko'])
    if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('program').get('category2_name').get('ko')!='':
     wirXyMcWBDKdYCHxJPAqOSgkvLuobQ.append(wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['program']['category2_name']['ko'])
    if wirXyMcWBDKdYCHxJPAqOSgkvLuobQ[0]!='':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['genre']=wirXyMcWBDKdYCHxJPAqOSgkvLuobQ
    try:
     if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('program').get('product_year'):wirXyMcWBDKdYCHxJPAqOSgkvLuobF['year']=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['program']['product_year']
     if 'broad_dt' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('program'):
      wirXyMcWBDKdYCHxJPAqOSgkvLuoTU=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('program').get('broad_dt')
      wirXyMcWBDKdYCHxJPAqOSgkvLuobF['aired']='%s-%s-%s'%(wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[:4],wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[4:6],wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[6:])
    except:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
    wirXyMcWBDKdYCHxJPAqOSgkvLuobN={'program':wirXyMcWBDKdYCHxJPAqOSgkvLuoba,'title':wirXyMcWBDKdYCHxJPAqOSgkvLuobf,'thumbnail':wirXyMcWBDKdYCHxJPAqOSgkvLuobp,'synopsis':wirXyMcWBDKdYCHxJPAqOSgkvLuobR,'channel':wirXyMcWBDKdYCHxJPAqOSgkvLuobz,'info':wirXyMcWBDKdYCHxJPAqOSgkvLuobF}
    wirXyMcWBDKdYCHxJPAqOSgkvLuobU.append(wirXyMcWBDKdYCHxJPAqOSgkvLuobN)
   if wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']['has_more']=='Y':wirXyMcWBDKdYCHxJPAqOSgkvLuobT=wirXyMcWBDKdYCHxJPAqOSgkvLuojU
  except wirXyMcWBDKdYCHxJPAqOSgkvLuojb as exception:
   wirXyMcWBDKdYCHxJPAqOSgkvLuojT(exception)
  return wirXyMcWBDKdYCHxJPAqOSgkvLuobU,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
 def GetEpisodoList(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,program_code,page_int,orderby='desc'):
  wirXyMcWBDKdYCHxJPAqOSgkvLuobU=[]
  wirXyMcWBDKdYCHxJPAqOSgkvLuobT=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE
  try:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUF ='/v2/media/frequency/program/'+program_code
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetDefaultParams()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUn={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetNoCache(2))}
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUh.update(wirXyMcWBDKdYCHxJPAqOSgkvLuoUn)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVl=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeurl(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.API_DOMAIN,wirXyMcWBDKdYCHxJPAqOSgkvLuoUF)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeDefaultCookies()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVz=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.callRequestCookies('Get',wirXyMcWBDKdYCHxJPAqOSgkvLuoVl,payload=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,params=wirXyMcWBDKdYCHxJPAqOSgkvLuoUh,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,cookies=wirXyMcWBDKdYCHxJPAqOSgkvLuoVh)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUm=json.loads(wirXyMcWBDKdYCHxJPAqOSgkvLuoVz.text)
   if not('result' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']):return wirXyMcWBDKdYCHxJPAqOSgkvLuobU,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
   wirXyMcWBDKdYCHxJPAqOSgkvLuobs=wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']['result']
   wirXyMcWBDKdYCHxJPAqOSgkvLuoTb=wirXyMcWBDKdYCHxJPAqOSgkvLuojV(wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']['total_count'])
   wirXyMcWBDKdYCHxJPAqOSgkvLuoTj =wirXyMcWBDKdYCHxJPAqOSgkvLuojV(wirXyMcWBDKdYCHxJPAqOSgkvLuoTb//(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    wirXyMcWBDKdYCHxJPAqOSgkvLuoTs =(wirXyMcWBDKdYCHxJPAqOSgkvLuoTb-1)-((page_int-1)*wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.EPISODE_LIMIT)
   else:
    wirXyMcWBDKdYCHxJPAqOSgkvLuoTs =(page_int-1)*wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.EPISODE_LIMIT
   for i in wirXyMcWBDKdYCHxJPAqOSgkvLuojh(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.EPISODE_LIMIT):
    if orderby=='desc':
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTF=wirXyMcWBDKdYCHxJPAqOSgkvLuoTs-i
     if wirXyMcWBDKdYCHxJPAqOSgkvLuoTF<0:break
    else:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTF=wirXyMcWBDKdYCHxJPAqOSgkvLuoTs+i
     if wirXyMcWBDKdYCHxJPAqOSgkvLuoTF>=wirXyMcWBDKdYCHxJPAqOSgkvLuoTb:break
    wirXyMcWBDKdYCHxJPAqOSgkvLuoTh=wirXyMcWBDKdYCHxJPAqOSgkvLuobs[wirXyMcWBDKdYCHxJPAqOSgkvLuoTF]['episode']['code']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobf =wirXyMcWBDKdYCHxJPAqOSgkvLuobs[wirXyMcWBDKdYCHxJPAqOSgkvLuoTF]['vod_name']['ko']
    wirXyMcWBDKdYCHxJPAqOSgkvLuoTn =''
    try:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTU=wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuobs[wirXyMcWBDKdYCHxJPAqOSgkvLuoTF]['episode']['broadcast_date'])
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTn='%s-%s-%s'%(wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[:4],wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[4:6],wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[6:])
    except:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
    if wirXyMcWBDKdYCHxJPAqOSgkvLuobs[wirXyMcWBDKdYCHxJPAqOSgkvLuoTF]['episode']['image']!=[]:
     wirXyMcWBDKdYCHxJPAqOSgkvLuobp=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuobs[wirXyMcWBDKdYCHxJPAqOSgkvLuoTF]['episode']['image'][0]['url']
    else:
     wirXyMcWBDKdYCHxJPAqOSgkvLuobp=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuobs[wirXyMcWBDKdYCHxJPAqOSgkvLuoTF]['program']['image'][0]['url']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobR =wirXyMcWBDKdYCHxJPAqOSgkvLuobs[wirXyMcWBDKdYCHxJPAqOSgkvLuoTF]['episode']['synopsis']['ko']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobF={}
    wirXyMcWBDKdYCHxJPAqOSgkvLuobF['mediatype']='episode' 
    try:
     wirXyMcWBDKdYCHxJPAqOSgkvLuobF['title'] =wirXyMcWBDKdYCHxJPAqOSgkvLuobs[wirXyMcWBDKdYCHxJPAqOSgkvLuoTF]['program']['name']['ko']
     wirXyMcWBDKdYCHxJPAqOSgkvLuobF['aired'] =wirXyMcWBDKdYCHxJPAqOSgkvLuoTn
     wirXyMcWBDKdYCHxJPAqOSgkvLuobF['studio'] =wirXyMcWBDKdYCHxJPAqOSgkvLuobs[wirXyMcWBDKdYCHxJPAqOSgkvLuoTF]['channel']['name']['ko']
     if 'frequency' in wirXyMcWBDKdYCHxJPAqOSgkvLuobs[wirXyMcWBDKdYCHxJPAqOSgkvLuoTF]['episode']:wirXyMcWBDKdYCHxJPAqOSgkvLuobF['episode']=wirXyMcWBDKdYCHxJPAqOSgkvLuobs[wirXyMcWBDKdYCHxJPAqOSgkvLuoTF]['episode']['frequency']
    except:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
    wirXyMcWBDKdYCHxJPAqOSgkvLuobN={'episode':wirXyMcWBDKdYCHxJPAqOSgkvLuoTh,'title':wirXyMcWBDKdYCHxJPAqOSgkvLuobf,'subtitle':wirXyMcWBDKdYCHxJPAqOSgkvLuoTn,'thumbnail':wirXyMcWBDKdYCHxJPAqOSgkvLuobp,'synopsis':wirXyMcWBDKdYCHxJPAqOSgkvLuobR,'info':wirXyMcWBDKdYCHxJPAqOSgkvLuobF}
    wirXyMcWBDKdYCHxJPAqOSgkvLuobU.append(wirXyMcWBDKdYCHxJPAqOSgkvLuobN)
   if wirXyMcWBDKdYCHxJPAqOSgkvLuoTj>page_int:wirXyMcWBDKdYCHxJPAqOSgkvLuobT=wirXyMcWBDKdYCHxJPAqOSgkvLuojU
  except wirXyMcWBDKdYCHxJPAqOSgkvLuojb as exception:
   wirXyMcWBDKdYCHxJPAqOSgkvLuojT(exception)
  return wirXyMcWBDKdYCHxJPAqOSgkvLuobU,wirXyMcWBDKdYCHxJPAqOSgkvLuobT,wirXyMcWBDKdYCHxJPAqOSgkvLuoTj
 def GetMovieList(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,orderby,page_int,premiumyn=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE,landyn=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE):
  wirXyMcWBDKdYCHxJPAqOSgkvLuobU=[]
  wirXyMcWBDKdYCHxJPAqOSgkvLuobT=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE
  if premiumyn==wirXyMcWBDKdYCHxJPAqOSgkvLuojU:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoTm=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.MOVIE_LITE+','+wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.MOVIE_PREMIUM
  else:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoTm=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.MOVIE_LITE
  try:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUF ='/v2/media/movies'
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetDefaultParams()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUn={'pageNo':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(page_int),'pageSize':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','productPackageCode':wirXyMcWBDKdYCHxJPAqOSgkvLuoTm,'_':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetNoCache(2))}
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUh.update(wirXyMcWBDKdYCHxJPAqOSgkvLuoUn)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVl=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeurl(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.API_DOMAIN,wirXyMcWBDKdYCHxJPAqOSgkvLuoUF)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeDefaultCookies()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVz=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.callRequestCookies('Get',wirXyMcWBDKdYCHxJPAqOSgkvLuoVl,payload=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,params=wirXyMcWBDKdYCHxJPAqOSgkvLuoUh,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,cookies=wirXyMcWBDKdYCHxJPAqOSgkvLuoVh)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUm=json.loads(wirXyMcWBDKdYCHxJPAqOSgkvLuoVz.text)
   if not('result' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']):return wirXyMcWBDKdYCHxJPAqOSgkvLuobU,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
   wirXyMcWBDKdYCHxJPAqOSgkvLuobs=wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']['result']
   for wirXyMcWBDKdYCHxJPAqOSgkvLuoUl in wirXyMcWBDKdYCHxJPAqOSgkvLuobs:
    wirXyMcWBDKdYCHxJPAqOSgkvLuoTf =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['movie']['code']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobf =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['movie']['name']['ko'].strip()
    wirXyMcWBDKdYCHxJPAqOSgkvLuobf +=u' (%s년)'%(wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('movie').get('product_year'))
    wirXyMcWBDKdYCHxJPAqOSgkvLuobp =wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['movie']['image'][0]['url']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobG='CAIM0400' if landyn else 'CAIM2100' 
    for wirXyMcWBDKdYCHxJPAqOSgkvLuobe in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['movie']['image']:
     if wirXyMcWBDKdYCHxJPAqOSgkvLuobe['code']==wirXyMcWBDKdYCHxJPAqOSgkvLuobG:
      wirXyMcWBDKdYCHxJPAqOSgkvLuobp =wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuobe['url']
      break
    wirXyMcWBDKdYCHxJPAqOSgkvLuobR =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['movie']['story']['ko']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobF={}
    wirXyMcWBDKdYCHxJPAqOSgkvLuobF['mediatype']='movie' 
    wirXyMcWBDKdYCHxJPAqOSgkvLuobF['title'] = wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['movie']['name']['ko'].strip()
    wirXyMcWBDKdYCHxJPAqOSgkvLuobF['year'] =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('movie').get('product_year')
    try:
     wirXyMcWBDKdYCHxJPAqOSgkvLuobl=[]
     for wirXyMcWBDKdYCHxJPAqOSgkvLuobt in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('movie').get('actor'):wirXyMcWBDKdYCHxJPAqOSgkvLuobl.append(wirXyMcWBDKdYCHxJPAqOSgkvLuobt)
     if wirXyMcWBDKdYCHxJPAqOSgkvLuobl[0]!='':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['cast']=wirXyMcWBDKdYCHxJPAqOSgkvLuobl
    except:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
    try:
     wirXyMcWBDKdYCHxJPAqOSgkvLuobE=[]
     for wirXyMcWBDKdYCHxJPAqOSgkvLuoTV in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('movie').get('director'):wirXyMcWBDKdYCHxJPAqOSgkvLuobE.append(wirXyMcWBDKdYCHxJPAqOSgkvLuoTV)
     if wirXyMcWBDKdYCHxJPAqOSgkvLuobE[0]!='':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['director']=wirXyMcWBDKdYCHxJPAqOSgkvLuobE
    except:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
    try:
     wirXyMcWBDKdYCHxJPAqOSgkvLuobQ=[]
     if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('movie').get('category1_name').get('ko')!='':
      wirXyMcWBDKdYCHxJPAqOSgkvLuobQ.append(wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['movie']['category1_name']['ko'])
     if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('movie').get('category2_name').get('ko')!='':
      wirXyMcWBDKdYCHxJPAqOSgkvLuobQ.append(wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['movie']['category2_name']['ko'])
     if wirXyMcWBDKdYCHxJPAqOSgkvLuobQ[0]!='':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['genre']=wirXyMcWBDKdYCHxJPAqOSgkvLuobQ
    except:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
    try:
     if 'release_date' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('movie'):
      wirXyMcWBDKdYCHxJPAqOSgkvLuoTU=wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('movie').get('release_date'))
      wirXyMcWBDKdYCHxJPAqOSgkvLuobF['aired']='%s-%s-%s'%(wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[:4],wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[4:6],wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[6:])
    except:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
    try:
     if 'duration' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('movie'):wirXyMcWBDKdYCHxJPAqOSgkvLuobF['duration']=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('movie').get('duration')
    except:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
    wirXyMcWBDKdYCHxJPAqOSgkvLuobN={'moviecode':wirXyMcWBDKdYCHxJPAqOSgkvLuoTf,'title':wirXyMcWBDKdYCHxJPAqOSgkvLuobf,'thumbnail':wirXyMcWBDKdYCHxJPAqOSgkvLuobp,'synopsis':wirXyMcWBDKdYCHxJPAqOSgkvLuobR,'info':wirXyMcWBDKdYCHxJPAqOSgkvLuobF}
    if premiumyn==wirXyMcWBDKdYCHxJPAqOSgkvLuojU:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTp=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE
     for wirXyMcWBDKdYCHxJPAqOSgkvLuoTR in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['billing_package_id']:
      if wirXyMcWBDKdYCHxJPAqOSgkvLuoTR==wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.MOVIE_LITE:
       wirXyMcWBDKdYCHxJPAqOSgkvLuoTp=wirXyMcWBDKdYCHxJPAqOSgkvLuojU
       break
     if wirXyMcWBDKdYCHxJPAqOSgkvLuoTp==wirXyMcWBDKdYCHxJPAqOSgkvLuoTE:
      wirXyMcWBDKdYCHxJPAqOSgkvLuobN['title']=wirXyMcWBDKdYCHxJPAqOSgkvLuobN['title']+' [Premium]'
    wirXyMcWBDKdYCHxJPAqOSgkvLuobU.append(wirXyMcWBDKdYCHxJPAqOSgkvLuobN)
   if wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']['has_more']=='Y':wirXyMcWBDKdYCHxJPAqOSgkvLuobT=wirXyMcWBDKdYCHxJPAqOSgkvLuojU
  except wirXyMcWBDKdYCHxJPAqOSgkvLuojb as exception:
   wirXyMcWBDKdYCHxJPAqOSgkvLuojT(exception)
  return wirXyMcWBDKdYCHxJPAqOSgkvLuobU,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
 def GetMovieListGenre(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,genre,page_int,premiumyn=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE):
  wirXyMcWBDKdYCHxJPAqOSgkvLuobU=[]
  wirXyMcWBDKdYCHxJPAqOSgkvLuobT=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE
  if premiumyn==wirXyMcWBDKdYCHxJPAqOSgkvLuojU:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoTm=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.MOVIE_LITE+','+wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.MOVIE_PREMIUM
  else:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoTm=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.MOVIE_LITE
  try:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUF ='/v2/media/movie/curation/'+genre
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetDefaultParams()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUn={'pageNo':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(page_int),'pageSize':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.MOVIE_LIMIT),'productPackageCode':wirXyMcWBDKdYCHxJPAqOSgkvLuoTm,'_':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetNoCache(2))}
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUh.update(wirXyMcWBDKdYCHxJPAqOSgkvLuoUn)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVl=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeurl(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.API_DOMAIN,wirXyMcWBDKdYCHxJPAqOSgkvLuoUF)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeDefaultCookies()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVz=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.callRequestCookies('Get',wirXyMcWBDKdYCHxJPAqOSgkvLuoVl,payload=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,params=wirXyMcWBDKdYCHxJPAqOSgkvLuoUh,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,cookies=wirXyMcWBDKdYCHxJPAqOSgkvLuoVh)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUm=json.loads(wirXyMcWBDKdYCHxJPAqOSgkvLuoVz.text)
   if not('movies' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']):return wirXyMcWBDKdYCHxJPAqOSgkvLuobU,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
   wirXyMcWBDKdYCHxJPAqOSgkvLuobs=wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']['movies']
   for wirXyMcWBDKdYCHxJPAqOSgkvLuoUl in wirXyMcWBDKdYCHxJPAqOSgkvLuobs:
    wirXyMcWBDKdYCHxJPAqOSgkvLuoTf =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['code']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobf =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['name']['ko']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobp =wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['image'][0]['url']
    for wirXyMcWBDKdYCHxJPAqOSgkvLuobe in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['image']:
     if wirXyMcWBDKdYCHxJPAqOSgkvLuobe['code']=='CAIM2100':
      wirXyMcWBDKdYCHxJPAqOSgkvLuobp =wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuobe['url']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobR =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['story']['ko']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobN={'moviecode':wirXyMcWBDKdYCHxJPAqOSgkvLuoTf,'title':wirXyMcWBDKdYCHxJPAqOSgkvLuobf.strip(),'thumbnail':wirXyMcWBDKdYCHxJPAqOSgkvLuobp,'synopsis':wirXyMcWBDKdYCHxJPAqOSgkvLuobR}
    if premiumyn==wirXyMcWBDKdYCHxJPAqOSgkvLuojU:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTp=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE
     for wirXyMcWBDKdYCHxJPAqOSgkvLuoTR in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['billing_package_id']:
      if wirXyMcWBDKdYCHxJPAqOSgkvLuoTR==wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.MOVIE_LITE:
       wirXyMcWBDKdYCHxJPAqOSgkvLuoTp=wirXyMcWBDKdYCHxJPAqOSgkvLuojU
       break
     if wirXyMcWBDKdYCHxJPAqOSgkvLuoTp==wirXyMcWBDKdYCHxJPAqOSgkvLuoTE:
      wirXyMcWBDKdYCHxJPAqOSgkvLuobN['title']=wirXyMcWBDKdYCHxJPAqOSgkvLuobN['title']+' [Premium]'
    wirXyMcWBDKdYCHxJPAqOSgkvLuobU.append(wirXyMcWBDKdYCHxJPAqOSgkvLuobN)
  except wirXyMcWBDKdYCHxJPAqOSgkvLuojb as exception:
   wirXyMcWBDKdYCHxJPAqOSgkvLuojT(exception)
  return wirXyMcWBDKdYCHxJPAqOSgkvLuobU,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
 def GetMovieGenre(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj):
  wirXyMcWBDKdYCHxJPAqOSgkvLuobU=[]
  wirXyMcWBDKdYCHxJPAqOSgkvLuobT=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE
  try:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUF ='/v2/media/movie/curations'
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetDefaultParams()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUn={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetNoCache(2))}
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUh.update(wirXyMcWBDKdYCHxJPAqOSgkvLuoUn)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVl=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeurl(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.API_DOMAIN,wirXyMcWBDKdYCHxJPAqOSgkvLuoUF)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeDefaultCookies()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVz=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.callRequestCookies('Get',wirXyMcWBDKdYCHxJPAqOSgkvLuoVl,payload=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,params=wirXyMcWBDKdYCHxJPAqOSgkvLuoUh,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,cookies=wirXyMcWBDKdYCHxJPAqOSgkvLuoVh)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUm=json.loads(wirXyMcWBDKdYCHxJPAqOSgkvLuoVz.text)
   if not('result' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']):return wirXyMcWBDKdYCHxJPAqOSgkvLuobU,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
   wirXyMcWBDKdYCHxJPAqOSgkvLuobs=wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']['result']
   for wirXyMcWBDKdYCHxJPAqOSgkvLuoUl in wirXyMcWBDKdYCHxJPAqOSgkvLuobs:
    wirXyMcWBDKdYCHxJPAqOSgkvLuoTl =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['curation_code']
    wirXyMcWBDKdYCHxJPAqOSgkvLuoTt =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['curation_name']
    wirXyMcWBDKdYCHxJPAqOSgkvLuobN={'curation_code':wirXyMcWBDKdYCHxJPAqOSgkvLuoTl,'curation_name':wirXyMcWBDKdYCHxJPAqOSgkvLuoTt}
    wirXyMcWBDKdYCHxJPAqOSgkvLuobU.append(wirXyMcWBDKdYCHxJPAqOSgkvLuobN)
  except wirXyMcWBDKdYCHxJPAqOSgkvLuojb as exception:
   wirXyMcWBDKdYCHxJPAqOSgkvLuojT(exception)
  return wirXyMcWBDKdYCHxJPAqOSgkvLuobU,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
 def GetSearchList(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,search_key,userid,page_int,stype,premiumyn=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE,landyn=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE):
  wirXyMcWBDKdYCHxJPAqOSgkvLuoTQ=[]
  wirXyMcWBDKdYCHxJPAqOSgkvLuobT=wirXyMcWBDKdYCHxJPAqOSgkvLuoTE
  try:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUF ='/search/getSearch.jsp'
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUn={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'TOTAL','pageNum':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(page_int),'pageSize':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.SCREENCODE,'os':wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.OSCODE,'network':wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.SEARCH_LIMIT),'vodMVReqCnt':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':wirXyMcWBDKdYCHxJPAqOSgkvLuojs(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.GetNoCache(2))}
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVl=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeurl(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.SEARCH_DOMAIN,wirXyMcWBDKdYCHxJPAqOSgkvLuoUF)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeDefaultCookies()
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVz=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.callRequestCookies('Get',wirXyMcWBDKdYCHxJPAqOSgkvLuoVl,payload=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,params=wirXyMcWBDKdYCHxJPAqOSgkvLuoUn,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,cookies=wirXyMcWBDKdYCHxJPAqOSgkvLuoVh)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUm=json.loads(wirXyMcWBDKdYCHxJPAqOSgkvLuoVz.text)
   if stype=='vod':
    if not('programRsb' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUm):return wirXyMcWBDKdYCHxJPAqOSgkvLuoTQ,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
    wirXyMcWBDKdYCHxJPAqOSgkvLuoTI=wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['programRsb']['dataList']
    wirXyMcWBDKdYCHxJPAqOSgkvLuoTN =wirXyMcWBDKdYCHxJPAqOSgkvLuojV(wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['programRsb']['count'])
    for wirXyMcWBDKdYCHxJPAqOSgkvLuoUl in wirXyMcWBDKdYCHxJPAqOSgkvLuoTI:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoba=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['mast_cd']
     wirXyMcWBDKdYCHxJPAqOSgkvLuobf =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['mast_nm']
     wirXyMcWBDKdYCHxJPAqOSgkvLuobp =wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['web_url']
     if landyn==wirXyMcWBDKdYCHxJPAqOSgkvLuoTE:
      wirXyMcWBDKdYCHxJPAqOSgkvLuobp =wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['web_url4']
     wirXyMcWBDKdYCHxJPAqOSgkvLuobF={}
     wirXyMcWBDKdYCHxJPAqOSgkvLuobF['title']=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['mast_nm']
     wirXyMcWBDKdYCHxJPAqOSgkvLuobF['mediatype']='episode' 
     try:
      if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('actor')!='' and wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('actor')!='-':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['cast'] =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('actor').split(',')
      if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('director')!='' and wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('director')!='-':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['director']=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('director').split(',')
      if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('cate_nm')!='':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['genre'] =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('cate_nm').split('/')
      if 'targetage' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl:wirXyMcWBDKdYCHxJPAqOSgkvLuobF['mpaa']=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('targetage')
     except:
      wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
     try:
      if 'broad_dt' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl:
       wirXyMcWBDKdYCHxJPAqOSgkvLuoTU=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('broad_dt')
       wirXyMcWBDKdYCHxJPAqOSgkvLuobF['aired']='%s-%s-%s'%(wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[:4],wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[4:6],wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[6:])
     except:
      wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
     wirXyMcWBDKdYCHxJPAqOSgkvLuobN={'program':wirXyMcWBDKdYCHxJPAqOSgkvLuoba,'title':wirXyMcWBDKdYCHxJPAqOSgkvLuobf,'thumbnail':wirXyMcWBDKdYCHxJPAqOSgkvLuobp,'synopsis':'','info':wirXyMcWBDKdYCHxJPAqOSgkvLuobF}
     wirXyMcWBDKdYCHxJPAqOSgkvLuoTQ.append(wirXyMcWBDKdYCHxJPAqOSgkvLuobN)
   else:
    if not('vodMVRsb' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUm):return wirXyMcWBDKdYCHxJPAqOSgkvLuoTQ,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
    wirXyMcWBDKdYCHxJPAqOSgkvLuoTa=wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['vodMVRsb']['dataList']
    wirXyMcWBDKdYCHxJPAqOSgkvLuoTN =wirXyMcWBDKdYCHxJPAqOSgkvLuojV(wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['vodMVRsb']['count'])
    for wirXyMcWBDKdYCHxJPAqOSgkvLuoUl in wirXyMcWBDKdYCHxJPAqOSgkvLuoTa:
     wirXyMcWBDKdYCHxJPAqOSgkvLuoba=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['mast_cd']
     wirXyMcWBDKdYCHxJPAqOSgkvLuobf =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['mast_nm'].strip()
     wirXyMcWBDKdYCHxJPAqOSgkvLuobp =wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['web_url']
     if landyn==wirXyMcWBDKdYCHxJPAqOSgkvLuoTE:
      wirXyMcWBDKdYCHxJPAqOSgkvLuobp =wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.IMG_DOMAIN+wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['web_url5']
     wirXyMcWBDKdYCHxJPAqOSgkvLuobF={}
     wirXyMcWBDKdYCHxJPAqOSgkvLuobF['title'] =wirXyMcWBDKdYCHxJPAqOSgkvLuobf
     wirXyMcWBDKdYCHxJPAqOSgkvLuobF['mediatype']='movie' 
     try:
      if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('actor') !='':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['cast'] =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('actor').split(',')
      if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('cate_nm')!='':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['genre'] =wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('cate_nm').split('/')
      if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('runtime_sec')!='':wirXyMcWBDKdYCHxJPAqOSgkvLuobF['duration']=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('runtime_sec')
      if 'grade_nm' in wirXyMcWBDKdYCHxJPAqOSgkvLuoUl:wirXyMcWBDKdYCHxJPAqOSgkvLuobF['mpaa']=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('grade_nm')
     except:
      wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
     try:
      wirXyMcWBDKdYCHxJPAqOSgkvLuoTU=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl.get('broad_dt')
      if data_str!='':
       wirXyMcWBDKdYCHxJPAqOSgkvLuobF['aired']='%s-%s-%s'%(wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[:4],wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[4:6],wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[6:])
       wirXyMcWBDKdYCHxJPAqOSgkvLuobF['year']=wirXyMcWBDKdYCHxJPAqOSgkvLuoTU[:4]
     except:
      wirXyMcWBDKdYCHxJPAqOSgkvLuoTz
     if wirXyMcWBDKdYCHxJPAqOSgkvLuojU:
      wirXyMcWBDKdYCHxJPAqOSgkvLuobN={'movie':wirXyMcWBDKdYCHxJPAqOSgkvLuoba,'title':wirXyMcWBDKdYCHxJPAqOSgkvLuobf,'thumbnail':wirXyMcWBDKdYCHxJPAqOSgkvLuobp,'synopsis':'','info':wirXyMcWBDKdYCHxJPAqOSgkvLuobF}
      wirXyMcWBDKdYCHxJPAqOSgkvLuoTQ.append(wirXyMcWBDKdYCHxJPAqOSgkvLuobN)
  except wirXyMcWBDKdYCHxJPAqOSgkvLuojb as exception:
   wirXyMcWBDKdYCHxJPAqOSgkvLuojT(exception)
  return wirXyMcWBDKdYCHxJPAqOSgkvLuoTQ,wirXyMcWBDKdYCHxJPAqOSgkvLuobT
 def GetDeviceList(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj,wirXyMcWBDKdYCHxJPAqOSgkvLuoVN,wirXyMcWBDKdYCHxJPAqOSgkvLuoUV):
  wirXyMcWBDKdYCHxJPAqOSgkvLuobU=[]
  wirXyMcWBDKdYCHxJPAqOSgkvLuoUs='-'
  try:
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUF ='/v1/user/device/list'
   wirXyMcWBDKdYCHxJPAqOSgkvLuoTG=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeurl(wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.API_DOMAIN,wirXyMcWBDKdYCHxJPAqOSgkvLuoUF)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUn={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVh=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.makeDefaultCookies(vToken=wirXyMcWBDKdYCHxJPAqOSgkvLuoVN,vUserinfo=wirXyMcWBDKdYCHxJPAqOSgkvLuoUV)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoVz=wirXyMcWBDKdYCHxJPAqOSgkvLuoVj.callRequestCookies('Get',wirXyMcWBDKdYCHxJPAqOSgkvLuoTG,payload=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,params=wirXyMcWBDKdYCHxJPAqOSgkvLuoUn,headers=wirXyMcWBDKdYCHxJPAqOSgkvLuoTz,cookies=wirXyMcWBDKdYCHxJPAqOSgkvLuoVh)
   wirXyMcWBDKdYCHxJPAqOSgkvLuoUm=json.loads(wirXyMcWBDKdYCHxJPAqOSgkvLuoVz.text)
   wirXyMcWBDKdYCHxJPAqOSgkvLuobU=wirXyMcWBDKdYCHxJPAqOSgkvLuoUm['body']
   for wirXyMcWBDKdYCHxJPAqOSgkvLuoUl in wirXyMcWBDKdYCHxJPAqOSgkvLuobU:
    if wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['model']=='PC':
     wirXyMcWBDKdYCHxJPAqOSgkvLuoUs=wirXyMcWBDKdYCHxJPAqOSgkvLuoUl['uuid']
  except wirXyMcWBDKdYCHxJPAqOSgkvLuojb as exception:
   wirXyMcWBDKdYCHxJPAqOSgkvLuojT(exception)
  return wirXyMcWBDKdYCHxJPAqOSgkvLuoUs
# Created by pyminifier (https://github.com/liftoff/pyminifier)
