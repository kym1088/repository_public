__author__="NightRain"
qJkPrUMfoIOuQhXCjNDHlpbmzTdBex=object
qJkPrUMfoIOuQhXCjNDHlpbmzTdBew=None
qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA=False
qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg=True
qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR=int
qJkPrUMfoIOuQhXCjNDHlpbmzTdBGc=len
qJkPrUMfoIOuQhXCjNDHlpbmzTdBGe=str
qJkPrUMfoIOuQhXCjNDHlpbmzTdBGt=open
qJkPrUMfoIOuQhXCjNDHlpbmzTdBGs=dict
qJkPrUMfoIOuQhXCjNDHlpbmzTdBGK=Exception
qJkPrUMfoIOuQhXCjNDHlpbmzTdBGv=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
qJkPrUMfoIOuQhXCjNDHlpbmzTdBAR=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 (인기순)','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 (최신순)','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'월정액 영화관 (인기)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'-'},{'title':'월정액 영화관 (최신)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
qJkPrUMfoIOuQhXCjNDHlpbmzTdBAc=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
qJkPrUMfoIOuQhXCjNDHlpbmzTdBAe=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
qJkPrUMfoIOuQhXCjNDHlpbmzTdBAG=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
qJkPrUMfoIOuQhXCjNDHlpbmzTdBAt=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'PROGRAM','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
qJkPrUMfoIOuQhXCjNDHlpbmzTdBAs={'C00551':'tvN','C00544':'중화TV','C00575':'Olive','C00579':'Mnet','C00590':'OGN','C01141':'XtvN','C01142':'ONSTYLE','C01143':'OtvN','C04601':'CGV','C06941':'tooniverse','C07381':'OCN','C07382':'SUPER ACTION','C15251':'OGN x LOL','C15252':'OGN x 오버워치','C15042':'티빙라이브','C01581':'TV CHOSUN','C01583':'채널A','C00708':'MBN','C00593':'YTN','C01101':'YTN Life','C15347':'YTN science','C01723':'연합뉴스TV','C15152':'DIA TV','C01582':'JTBC','C00588':'JTBC Golf','C15741':'JTBC2','C00805':'JTBC3 FOX Sports','C05661':'디즈니채널','C18641':'IHQ','C22041':'JTBC4','C23343':'t.cast','C23441':'E channel','C17341':'히스토리','C00585':'TV CHOSUN2','C17141':'채널A 플러스','C00611':'LIFETIME','C08041':'tvN go','C05901':'채널W','C23442':"D'LIVE",'C27441':'KBS N'}
qJkPrUMfoIOuQhXCjNDHlpbmzTdBAK ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
qJkPrUMfoIOuQhXCjNDHlpbmzTdBAv=xbmc.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class qJkPrUMfoIOuQhXCjNDHlpbmzTdBAg(qJkPrUMfoIOuQhXCjNDHlpbmzTdBex):
 def __init__(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBAY,qJkPrUMfoIOuQhXCjNDHlpbmzTdBAn,qJkPrUMfoIOuQhXCjNDHlpbmzTdBAW):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_url =qJkPrUMfoIOuQhXCjNDHlpbmzTdBAY
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_handle=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAn
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.main_params =qJkPrUMfoIOuQhXCjNDHlpbmzTdBAW
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj =wirXyMcWBDKdYCHxJPAqOSgkvLuoVU() 
 def addon_noti(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,sting):
  try:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAE=xbmcgui.Dialog()
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAE.notification(__addonname__,sting)
  except:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBew
 def addon_log(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,string,isDebug=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA):
  try:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAy=string.encode('utf-8','ignore')
  except:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAy='addonException: addon_log'
  if isDebug:qJkPrUMfoIOuQhXCjNDHlpbmzTdBAa=xbmc.LOGDEBUG
  else:qJkPrUMfoIOuQhXCjNDHlpbmzTdBAa=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,qJkPrUMfoIOuQhXCjNDHlpbmzTdBAy),level=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAa)
 def get_keyboard_input(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAV=qJkPrUMfoIOuQhXCjNDHlpbmzTdBew
  kb=xbmc.Keyboard()
  kb.setHeading(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAV=kb.getText()
  return qJkPrUMfoIOuQhXCjNDHlpbmzTdBAV
 def get_settings_login_info(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAF =__addon__.getSetting('id')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAL =__addon__.getSetting('pw')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAx =__addon__.getSetting('login_type')
  return(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAF,qJkPrUMfoIOuQhXCjNDHlpbmzTdBAL,qJkPrUMfoIOuQhXCjNDHlpbmzTdBAx)
 def get_settings_premiumyn(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAw =__addon__.getSetting('premium_movieyn')
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBAw=='false':
   return qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA
  else:
   return qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg
 def get_settings_direct_replay(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgA=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR(__addon__.getSetting('direct_replay'))
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgA==0:
   return qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA
  else:
   return qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg
 def get_settings_thumbnail_landyn(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgR =qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR(__addon__.getSetting('thumbnail_way'))
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgR==0:
   return qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg
  else:
   return qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA
 def set_winCredential(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,credential):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc=xbmcgui.Window(10000)
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.setProperty('TVING_M_LOGINTIME',qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc=xbmcgui.Window(10000)
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBge={'tving_token':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.getProperty('TVING_M_TOKEN'),'poc_userinfo':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.getProperty('TVING_M_USERINFO'),'tving_uuid':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.getProperty('TVING_M_UUID')}
  return qJkPrUMfoIOuQhXCjNDHlpbmzTdBge
 def set_winEpisodeOrderby(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRW):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc=xbmcgui.Window(10000)
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.setProperty('TVING_M_ORDERBY',qJkPrUMfoIOuQhXCjNDHlpbmzTdBRW)
 def get_winEpisodeOrderby(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc=xbmcgui.Window(10000)
  return qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.getProperty('TVING_M_ORDERBY')
 def add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,label,sublabel='',img='',infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBew,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg,params=''):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgG='%s?%s'%(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_url,urllib.parse.urlencode(params))
  if sublabel:qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt='%s < %s >'%(label,sublabel)
  else: qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt=label
  if not img:img='DefaultFolder.png'
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgs=xbmcgui.ListItem(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt)
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgs.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:qJkPrUMfoIOuQhXCjNDHlpbmzTdBgs.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:qJkPrUMfoIOuQhXCjNDHlpbmzTdBgs.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_handle,qJkPrUMfoIOuQhXCjNDHlpbmzTdBgG,qJkPrUMfoIOuQhXCjNDHlpbmzTdBgs,isFolder)
 def get_selQuality(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,etype):
  try:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgK='selected_quality'
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgv=[1080,720,480,360]
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgi=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR(__addon__.getSetting(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgK))
   return qJkPrUMfoIOuQhXCjNDHlpbmzTdBgv[qJkPrUMfoIOuQhXCjNDHlpbmzTdBgi]
  except:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBew
  return 720 
 def dp_Main_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi):
  for qJkPrUMfoIOuQhXCjNDHlpbmzTdBgY in qJkPrUMfoIOuQhXCjNDHlpbmzTdBAR:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgY.get('title')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgY.get('mode'),'stype':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgY.get('stype'),'orderby':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgY.get('orderby'),'ordernm':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgY.get('ordernm'),'page':'1'}
   if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgY.get('mode')=='XXX':
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['mode']='XXX'
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgW=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA
   else:
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgW=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel='',img='',infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBew,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgW,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBGc(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAR)>0:xbmcplugin.endOfDirectory(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_handle)
 def login_main(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi):
  (qJkPrUMfoIOuQhXCjNDHlpbmzTdBgE,qJkPrUMfoIOuQhXCjNDHlpbmzTdBgy,qJkPrUMfoIOuQhXCjNDHlpbmzTdBga)=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_settings_login_info()
  if not(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgE and qJkPrUMfoIOuQhXCjNDHlpbmzTdBgy):
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAE=xbmcgui.Dialog()
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgV=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAE.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgV==qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_winEpisodeOrderby()=='':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.set_winEpisodeOrderby('desc')
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.cookiefile_check():return
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgF =qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgL=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgL==qJkPrUMfoIOuQhXCjNDHlpbmzTdBew or qJkPrUMfoIOuQhXCjNDHlpbmzTdBgL=='':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgL=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR('19000101')
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgx=0
   while qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg:
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgx+=1
    time.sleep(0.05)
    if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgL>=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgF:return
    if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgx>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgL>=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgF:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.GetCredential(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgE,qJkPrUMfoIOuQhXCjNDHlpbmzTdBgy,qJkPrUMfoIOuQhXCjNDHlpbmzTdBga):
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.set_winCredential(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.LoadCredential())
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('stype')
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw=='live':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRA=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAc
  else:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRA=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAt
  for qJkPrUMfoIOuQhXCjNDHlpbmzTdBRg in qJkPrUMfoIOuQhXCjNDHlpbmzTdBRA:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRg.get('title')
   if qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('ordernm')!='-':
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt+='  ('+qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('ordernm')+')'
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRg.get('mode'),'stype':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRg.get('stype'),'orderby':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('orderby'),'page':'1'}
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel='',img='',infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBew,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBGc(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRA)>0:xbmcplugin.endOfDirectory(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_handle)
 def dp_LiveChannel_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.SaveCredential(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_winCredential())
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('stype')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe =qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('page'))
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBRG,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRt=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.GetLiveChannelList(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe)
  for qJkPrUMfoIOuQhXCjNDHlpbmzTdBRs in qJkPrUMfoIOuQhXCjNDHlpbmzTdBRG:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRs.get('title')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgS =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRs.get('channel')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRs.get('thumbnail')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRv =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRs.get('synopsis')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRi=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRs.get('channelepg')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRs.get('info')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY['plot']='%s\n%s\n%s\n\n%s'%(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgS,qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRv)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':'LIVE','mediacode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRs.get('mediacode'),'stype':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw}
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgS,sublabel=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,img=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK,infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBRt:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['mode']='CHANNEL' 
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['stype']=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw 
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['page']=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGe(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe+1)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt='[B]%s >>[/B]'%'다음 페이지'
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRn=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGe(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe+1)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRn,img='',infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBew,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBGc(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRG)>0:xbmcplugin.endOfDirectory(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_handle,cacheToDisc=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA)
 def dp_Program_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.SaveCredential(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_winCredential())
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('stype')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBRW =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('orderby')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe =qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('page'))
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBRS,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRt=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.GetProgramList(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRW,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe,landyn=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_settings_thumbnail_landyn())
  for qJkPrUMfoIOuQhXCjNDHlpbmzTdBRE in qJkPrUMfoIOuQhXCjNDHlpbmzTdBRS:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRE.get('title')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRE.get('thumbnail')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRv =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRE.get('synopsis')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRy =qJkPrUMfoIOuQhXCjNDHlpbmzTdBAs.get(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRE.get('channel'))
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRE.get('info')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY['studio']=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRy
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY['plot']='%s <%s>\n\n%s'%(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRy,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRv)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':'EPISODE','programcode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRE.get('program'),'page':'1'}
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRy,img=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK,infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBRt:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['mode'] ='PROGRAM' 
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['stype'] =qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['orderby']=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRW
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['page'] =qJkPrUMfoIOuQhXCjNDHlpbmzTdBGe(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe+1)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt='[B]%s >>[/B]'%'다음 페이지'
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRn=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGe(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe+1)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRn,img='',infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBew,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBGc(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRS)>0:xbmcplugin.endOfDirectory(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_handle,cacheToDisc=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA)
 def dp_Episode_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.SaveCredential(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_winCredential())
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBRa=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('programcode')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe =qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('page'))
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBRV,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRt,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRF=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.GetEpisodoList(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRa,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe,orderby=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_winEpisodeOrderby())
  for qJkPrUMfoIOuQhXCjNDHlpbmzTdBRL in qJkPrUMfoIOuQhXCjNDHlpbmzTdBRV:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRL.get('title')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRn =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRL.get('subtitle')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRL.get('thumbnail')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRv =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRL.get('synopsis')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRL.get('info')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY['plot']='%s\n\n%s'%(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRv)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':'VOD','mediacode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRL.get('episode'),'stype':'vod','programcode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRa,'title':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,'thumbnail':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK}
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRn,img=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK,infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe==1:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY={'plot':'정렬순서를 변경합니다.'}
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={}
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['mode'] ='ORDER_BY' 
   if qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_winEpisodeOrderby()=='desc':
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt='정렬순서변경 : 최신화부터 -> 1회부터'
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['orderby']='asc'
   else:
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt='정렬순서변경 : 1회부터 -> 최신화부터'
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['orderby']='desc'
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel='',img='',infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBRt:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['mode'] ='EPISODE' 
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['programcode']=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRa
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['page'] =qJkPrUMfoIOuQhXCjNDHlpbmzTdBGe(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe+1)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt='[B]%s >>[/B]'%'다음 페이지'
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRn=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGe(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe+1)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRn,img='',infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBew,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBGc(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRV)>0:xbmcplugin.endOfDirectory(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_handle,cacheToDisc=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg)
 def dp_setEpOrderby(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBRW =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('orderby')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.set_winEpisodeOrderby(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRW)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.SaveCredential(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_winCredential())
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBRW =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('orderby')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('page'))
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBRx,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRt=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.GetMovieList(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRW,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe,premiumyn=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_settings_premiumyn(),landyn=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_settings_thumbnail_landyn())
  for qJkPrUMfoIOuQhXCjNDHlpbmzTdBRw in qJkPrUMfoIOuQhXCjNDHlpbmzTdBRx:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRw.get('title')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRw.get('thumbnail')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRv =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRw.get('synopsis')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRw.get('info')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY['plot']='%s\n\n%s'%(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRv)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':'MOVIE','mediacode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRw.get('moviecode'),'stype':'movie','title':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,'thumbnail':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK}
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel='',img=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK,infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBRt:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['mode'] ='MOVIE_GROUP' 
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['orderby']=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRW
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['page'] =qJkPrUMfoIOuQhXCjNDHlpbmzTdBGe(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe+1)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt='[B]%s >>[/B]'%'다음 페이지'
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRn=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGe(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe+1)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRn,img='',infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBew,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBGc(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRx)>0:xbmcplugin.endOfDirectory(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_handle,cacheToDisc=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA)
 def dp_Search_Group(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc):
  for qJkPrUMfoIOuQhXCjNDHlpbmzTdBRg in qJkPrUMfoIOuQhXCjNDHlpbmzTdBAG:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRg.get('title')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRg.get('mode'),'stype':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRg.get('stype'),'page':'1'}
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel='',img='',infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBew,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBGc(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAG)>0:xbmcplugin.endOfDirectory(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_handle)
 def dp_Search_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.SaveCredential(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_winCredential())
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBcA =__addon__.getSetting('id')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe =qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('page'))
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('stype')
  if 'search_key' in qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBcg=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('search_key')
  else:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBcg=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not qJkPrUMfoIOuQhXCjNDHlpbmzTdBcg:return
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBcR,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRt=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.GetSearchList(qJkPrUMfoIOuQhXCjNDHlpbmzTdBcg,qJkPrUMfoIOuQhXCjNDHlpbmzTdBcA,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe,qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw,premiumyn=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_settings_premiumyn(),landyn=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_settings_thumbnail_landyn())
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBGc(qJkPrUMfoIOuQhXCjNDHlpbmzTdBcR)==0:return
  for qJkPrUMfoIOuQhXCjNDHlpbmzTdBce in qJkPrUMfoIOuQhXCjNDHlpbmzTdBcR:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt =qJkPrUMfoIOuQhXCjNDHlpbmzTdBce.get('title')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK=qJkPrUMfoIOuQhXCjNDHlpbmzTdBce.get('thumbnail')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRv =qJkPrUMfoIOuQhXCjNDHlpbmzTdBce.get('synopsis')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBcG =qJkPrUMfoIOuQhXCjNDHlpbmzTdBce.get('program')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY=qJkPrUMfoIOuQhXCjNDHlpbmzTdBce.get('info')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY['plot']='%s\n\n%s'%(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRv)
   if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw=='vod':
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':'EPISODE','programcode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBce.get('program'),'page':'1'}
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgW=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg
   else:
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':'MOVIE','mediacode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBce.get('movie'),'stype':'movie','title':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,'thumbnail':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK}
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgW=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel='',img=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK,infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgW,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBRt:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['mode'] ='SEARCH' 
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['search_key']=qJkPrUMfoIOuQhXCjNDHlpbmzTdBcg
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn['page'] =qJkPrUMfoIOuQhXCjNDHlpbmzTdBGe(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe+1)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt='[B]%s >>[/B]'%'다음 페이지'
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRn=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGe(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRe+1)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRn,img='',infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBew,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBGc(qJkPrUMfoIOuQhXCjNDHlpbmzTdBcR)>0:xbmcplugin.endOfDirectory(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_handle)
 def Delete_Watched_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw):
  try:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBct=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw))
   with qJkPrUMfoIOuQhXCjNDHlpbmzTdBGt(qJkPrUMfoIOuQhXCjNDHlpbmzTdBct,'w',-1,'utf-8')as fp:
    fp.write('')
  except:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBew
 def dp_WatchList_Delete(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('stype')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAE=xbmcgui.Dialog()
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgV=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAE.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgV==qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA:sys.exit()
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.Delete_Watched_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw):
  try:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBct=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw))
   with qJkPrUMfoIOuQhXCjNDHlpbmzTdBGt(qJkPrUMfoIOuQhXCjNDHlpbmzTdBct,'r',-1,'utf-8')as fp:
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBcs=fp.readlines()
  except:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBcs=[]
  return qJkPrUMfoIOuQhXCjNDHlpbmzTdBcs
 def Save_Watched_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw,qJkPrUMfoIOuQhXCjNDHlpbmzTdBAW):
  try:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBct=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw))
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBcK=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.Load_Watched_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw) 
   with qJkPrUMfoIOuQhXCjNDHlpbmzTdBGt(qJkPrUMfoIOuQhXCjNDHlpbmzTdBct,'w',-1,'utf-8')as fp:
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBcv=urllib.parse.urlencode(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAW)
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBcv=qJkPrUMfoIOuQhXCjNDHlpbmzTdBcv+'\n'
    fp.write(qJkPrUMfoIOuQhXCjNDHlpbmzTdBcv)
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBci=0
    for qJkPrUMfoIOuQhXCjNDHlpbmzTdBcY in qJkPrUMfoIOuQhXCjNDHlpbmzTdBcK:
     qJkPrUMfoIOuQhXCjNDHlpbmzTdBcn=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGs(urllib.parse.parse_qsl(qJkPrUMfoIOuQhXCjNDHlpbmzTdBcY))
     qJkPrUMfoIOuQhXCjNDHlpbmzTdBcW=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAW.get('code')
     qJkPrUMfoIOuQhXCjNDHlpbmzTdBcS=qJkPrUMfoIOuQhXCjNDHlpbmzTdBcn.get('code')
     if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw=='vod' and qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_settings_direct_replay()==qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg:
      qJkPrUMfoIOuQhXCjNDHlpbmzTdBcW=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAW.get('videoid')
      qJkPrUMfoIOuQhXCjNDHlpbmzTdBcS=qJkPrUMfoIOuQhXCjNDHlpbmzTdBcn.get('videoid')if qJkPrUMfoIOuQhXCjNDHlpbmzTdBcS!=qJkPrUMfoIOuQhXCjNDHlpbmzTdBew else '-'
     if qJkPrUMfoIOuQhXCjNDHlpbmzTdBcW!=qJkPrUMfoIOuQhXCjNDHlpbmzTdBcS:
      fp.write(qJkPrUMfoIOuQhXCjNDHlpbmzTdBcY)
      qJkPrUMfoIOuQhXCjNDHlpbmzTdBci+=1
      if qJkPrUMfoIOuQhXCjNDHlpbmzTdBci>=50:break
  except:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBew
 def dp_Watch_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('stype')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgA=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_settings_direct_replay()
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw=='-':
   for qJkPrUMfoIOuQhXCjNDHlpbmzTdBRg in qJkPrUMfoIOuQhXCjNDHlpbmzTdBAe:
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRg.get('title')
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRg.get('mode'),'stype':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRg.get('stype')}
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel='',img='',infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBew,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
   if qJkPrUMfoIOuQhXCjNDHlpbmzTdBGc(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAe)>0:xbmcplugin.endOfDirectory(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_handle)
  else:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBcE=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.Load_Watched_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw)
   for qJkPrUMfoIOuQhXCjNDHlpbmzTdBcy in qJkPrUMfoIOuQhXCjNDHlpbmzTdBcE:
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBca=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGs(urllib.parse.parse_qsl(qJkPrUMfoIOuQhXCjNDHlpbmzTdBcy))
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt =qJkPrUMfoIOuQhXCjNDHlpbmzTdBca.get('title')
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK=qJkPrUMfoIOuQhXCjNDHlpbmzTdBca.get('img')
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBcV =qJkPrUMfoIOuQhXCjNDHlpbmzTdBca.get('videoid')
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY={}
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY['plot']=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt
    if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw=='vod':
     if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgA==qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA or qJkPrUMfoIOuQhXCjNDHlpbmzTdBcV==qJkPrUMfoIOuQhXCjNDHlpbmzTdBew:
      qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':'EPISODE','programcode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBca.get('code'),'page':'1'}
      qJkPrUMfoIOuQhXCjNDHlpbmzTdBgW=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg
     else:
      qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':'VOD','mediacode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBcV,'stype':'vod','programcode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBca.get('code'),'title':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,'thumbnail':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK}
      qJkPrUMfoIOuQhXCjNDHlpbmzTdBgW=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA
    else:
     qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':'MOVIE','mediacode':qJkPrUMfoIOuQhXCjNDHlpbmzTdBca.get('code'),'stype':'movie','title':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,'thumbnail':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK}
     qJkPrUMfoIOuQhXCjNDHlpbmzTdBgW=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel='',img=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRK,infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgW,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY={'plot':'시청목록을 삭제합니다.'}
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt='*** 시청목록 삭제 ***'
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'mode':'MYVIEW_REMOVE','stype':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw}
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.add_dir(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgt,sublabel='',img='',infoLabels=qJkPrUMfoIOuQhXCjNDHlpbmzTdBRY,isFolder=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA,params=qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
   xbmcplugin.endOfDirectory(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_handle,cacheToDisc=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA)
 def play_VIDEO(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi,qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.SaveCredential(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_winCredential())
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBcL =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('mediacode')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw =qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('stype')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBcx=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.get_selQuality(qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw)
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBcw,qJkPrUMfoIOuQhXCjNDHlpbmzTdBeA=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.GetBroadURL(qJkPrUMfoIOuQhXCjNDHlpbmzTdBcL,qJkPrUMfoIOuQhXCjNDHlpbmzTdBcx,qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw)
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.addon_log('qt, stype, url : %s - %s - %s'%(qJkPrUMfoIOuQhXCjNDHlpbmzTdBGe(qJkPrUMfoIOuQhXCjNDHlpbmzTdBcx),qJkPrUMfoIOuQhXCjNDHlpbmzTdBgw,qJkPrUMfoIOuQhXCjNDHlpbmzTdBcw))
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBcw=='':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.addon_noti(__language__(30908).encode('utf8'))
   return
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBeg =qJkPrUMfoIOuQhXCjNDHlpbmzTdBcw.find('Policy=')
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBeg!=-1:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBeR =qJkPrUMfoIOuQhXCjNDHlpbmzTdBcw.split('?')[0]
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBec=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGs(urllib.parse.parse_qsl(urllib.parse.urlsplit(qJkPrUMfoIOuQhXCjNDHlpbmzTdBcw).query))
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBec=urllib.parse.urlencode(qJkPrUMfoIOuQhXCjNDHlpbmzTdBec)
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBec=qJkPrUMfoIOuQhXCjNDHlpbmzTdBec.replace('&',';')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBec=qJkPrUMfoIOuQhXCjNDHlpbmzTdBec.replace('Policy','CloudFront-Policy')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBec=qJkPrUMfoIOuQhXCjNDHlpbmzTdBec.replace('Signature','CloudFront-Signature')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBec=qJkPrUMfoIOuQhXCjNDHlpbmzTdBec.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBeG='%s|Cookie=%s'%(qJkPrUMfoIOuQhXCjNDHlpbmzTdBeR,qJkPrUMfoIOuQhXCjNDHlpbmzTdBec)
  else:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBeG=qJkPrUMfoIOuQhXCjNDHlpbmzTdBcw
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.addon_log(qJkPrUMfoIOuQhXCjNDHlpbmzTdBeG,qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA)
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBet=xbmcgui.ListItem(path=qJkPrUMfoIOuQhXCjNDHlpbmzTdBeG)
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBeA!='':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBes=qJkPrUMfoIOuQhXCjNDHlpbmzTdBeA
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBeK ='https://cj.drmkeyserver.com/widevine_license'
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBev ='mpd'
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBei ='com.widevine.alpha'
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBeY =inputstreamhelper.Helper(qJkPrUMfoIOuQhXCjNDHlpbmzTdBev,drm='widevine')
   if qJkPrUMfoIOuQhXCjNDHlpbmzTdBeY.check_inputstream():
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBen={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%qJkPrUMfoIOuQhXCjNDHlpbmzTdBcL,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':qJkPrUMfoIOuQhXCjNDHlpbmzTdBAK,'AcquireLicenseAssertion':qJkPrUMfoIOuQhXCjNDHlpbmzTdBes,'Host':'cj.drmkeyserver.com'}
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBeW=qJkPrUMfoIOuQhXCjNDHlpbmzTdBeK+'|'+urllib.parse.urlencode(qJkPrUMfoIOuQhXCjNDHlpbmzTdBen)+'|R{SSM}|'
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBet.setProperty('inputstream',qJkPrUMfoIOuQhXCjNDHlpbmzTdBeY.inputstream_addon)
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBet.setProperty('inputstream.adaptive.manifest_type',qJkPrUMfoIOuQhXCjNDHlpbmzTdBev)
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBet.setProperty('inputstream.adaptive.license_type',qJkPrUMfoIOuQhXCjNDHlpbmzTdBei)
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBet.setProperty('inputstream.adaptive.license_key',qJkPrUMfoIOuQhXCjNDHlpbmzTdBeW)
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBet.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAK))
  xbmcplugin.setResolvedUrl(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi._addon_handle,qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg,qJkPrUMfoIOuQhXCjNDHlpbmzTdBet)
  try:
   if qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('mode')in['VOD','MOVIE']and qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('title'):
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn={'code':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('programcode')if qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('mode')=='VOD' else qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('mediacode'),'img':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('thumbnail'),'title':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('title'),'videoid':qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('mediacode')}
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.Save_Watched_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBRc.get('stype'),qJkPrUMfoIOuQhXCjNDHlpbmzTdBgn)
  except:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBew
 def logout(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAE=xbmcgui.Dialog()
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgV=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAE.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgV==qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA:sys.exit()
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.wininfo_clear()
  if os.path.isfile(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAv):os.remove(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAv)
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc=xbmcgui.Window(10000)
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.setProperty('TVING_M_TOKEN','')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.setProperty('TVING_M_USERINFO','')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.setProperty('TVING_M_UUID','')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.setProperty('TVING_M_LOGINTIME','')
 def cookiefile_save(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBeS =qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.Get_Now_Datetime()
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBeE=qJkPrUMfoIOuQhXCjNDHlpbmzTdBeS+datetime.timedelta(days=qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR(__addon__.getSetting('cache_ttl')))
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc=xbmcgui.Window(10000)
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBey={'tving_token':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.getProperty('TVING_M_TOKEN'),'tving_userinfo':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.getProperty('TVING_M_USERINFO'),'tving_uuid':qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_limitdate':qJkPrUMfoIOuQhXCjNDHlpbmzTdBeE.strftime('%Y-%m-%d')}
  try: 
   with qJkPrUMfoIOuQhXCjNDHlpbmzTdBGt(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAv,'w',-1,'utf-8')as fp:
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBea.dump(qJkPrUMfoIOuQhXCjNDHlpbmzTdBey,fp)
  except qJkPrUMfoIOuQhXCjNDHlpbmzTdBGK as exception:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBGv(exception)
 def cookiefile_check(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBey={}
  try: 
   with qJkPrUMfoIOuQhXCjNDHlpbmzTdBGt(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAv,'r',-1,'utf-8')as fp:
    qJkPrUMfoIOuQhXCjNDHlpbmzTdBey= qJkPrUMfoIOuQhXCjNDHlpbmzTdBea.load(fp)
  except qJkPrUMfoIOuQhXCjNDHlpbmzTdBGK as exception:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.wininfo_clear()
   return qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgE =__addon__.getSetting('id')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgy =__addon__.getSetting('pw')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBeV=__addon__.getSetting('login_type')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBey['tving_id']=base64.standard_b64decode(qJkPrUMfoIOuQhXCjNDHlpbmzTdBey['tving_id']).decode('utf-8')
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBey['tving_pw']=base64.standard_b64decode(qJkPrUMfoIOuQhXCjNDHlpbmzTdBey['tving_pw']).decode('utf-8')
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgE!=qJkPrUMfoIOuQhXCjNDHlpbmzTdBey['tving_id']or qJkPrUMfoIOuQhXCjNDHlpbmzTdBgy!=qJkPrUMfoIOuQhXCjNDHlpbmzTdBey['tving_pw']or qJkPrUMfoIOuQhXCjNDHlpbmzTdBeV!=qJkPrUMfoIOuQhXCjNDHlpbmzTdBey['tving_logintype']:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.wininfo_clear()
   return qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgF =qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBeF=qJkPrUMfoIOuQhXCjNDHlpbmzTdBey['tving_limitdate']
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgL =qJkPrUMfoIOuQhXCjNDHlpbmzTdBGR(re.sub('-','',qJkPrUMfoIOuQhXCjNDHlpbmzTdBeF))
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBgL<qJkPrUMfoIOuQhXCjNDHlpbmzTdBgF:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.wininfo_clear()
   return qJkPrUMfoIOuQhXCjNDHlpbmzTdBGA
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc=xbmcgui.Window(10000)
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.setProperty('TVING_M_TOKEN',qJkPrUMfoIOuQhXCjNDHlpbmzTdBey['tving_token'])
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.setProperty('TVING_M_USERINFO',qJkPrUMfoIOuQhXCjNDHlpbmzTdBey['tving_userinfo'])
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.setProperty('TVING_M_UUID',qJkPrUMfoIOuQhXCjNDHlpbmzTdBey['tving_uuid'])
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBgc.setProperty('TVING_M_LOGINTIME',qJkPrUMfoIOuQhXCjNDHlpbmzTdBeF)
  return qJkPrUMfoIOuQhXCjNDHlpbmzTdBGg
 def tving_main(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi):
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL=qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.main_params.get('mode',qJkPrUMfoIOuQhXCjNDHlpbmzTdBew)
  qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.login_main()
  if qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL is qJkPrUMfoIOuQhXCjNDHlpbmzTdBew:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.dp_Main_List()
  elif qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL in['LIVE_GROUP','VOD_GROUP']:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.dp_Title_Group(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.main_params)
  elif qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL=='CHANNEL':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.dp_LiveChannel_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.main_params)
  elif qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL in['LIVE','VOD','MOVIE']:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.play_VIDEO(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.main_params)
   time.sleep(0.1)
  elif qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL=='PROGRAM':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.dp_Program_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.main_params)
  elif qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL=='EPISODE':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.dp_Episode_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.main_params)
  elif qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL=='MOVIE_GROUP':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.dp_Movie_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.main_params)
  elif qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL=='SEARCH_GROUP':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.dp_Search_Group(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.main_params)
  elif qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL=='SEARCH':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.dp_Search_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.main_params)
  elif qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL=='WATCH':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.dp_Watch_List(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.main_params)
  elif qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL=='MYVIEW_REMOVE':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.dp_WatchList_Delete(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.main_params)
  elif qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL=='ORDER_BY':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.dp_setEpOrderby(qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.main_params)
  elif qJkPrUMfoIOuQhXCjNDHlpbmzTdBeL=='LOGOUT':
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBAi.logout()
  else:
   qJkPrUMfoIOuQhXCjNDHlpbmzTdBew
# Created by pyminifier (https://github.com/liftoff/pyminifier)
