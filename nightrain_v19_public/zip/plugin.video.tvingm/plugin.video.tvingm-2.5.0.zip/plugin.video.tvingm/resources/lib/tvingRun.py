__author__="NightRain"
csoJLSRdkNEtmXwATOKpnYjxVavuGq=object
csoJLSRdkNEtmXwATOKpnYjxVavuGM=None
csoJLSRdkNEtmXwATOKpnYjxVavuGP=int
csoJLSRdkNEtmXwATOKpnYjxVavuGF=True
csoJLSRdkNEtmXwATOKpnYjxVavuGI=False
csoJLSRdkNEtmXwATOKpnYjxVavuGC=type
csoJLSRdkNEtmXwATOKpnYjxVavuGD=dict
csoJLSRdkNEtmXwATOKpnYjxVavugi=len
csoJLSRdkNEtmXwATOKpnYjxVavugh=str
csoJLSRdkNEtmXwATOKpnYjxVavugW=range
csoJLSRdkNEtmXwATOKpnYjxVavugy=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
csoJLSRdkNEtmXwATOKpnYjxVavuiW=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
csoJLSRdkNEtmXwATOKpnYjxVavuiy=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
csoJLSRdkNEtmXwATOKpnYjxVavuil=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
csoJLSRdkNEtmXwATOKpnYjxVavuib=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
csoJLSRdkNEtmXwATOKpnYjxVavuiz=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
csoJLSRdkNEtmXwATOKpnYjxVavuiG=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
csoJLSRdkNEtmXwATOKpnYjxVavuig=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
csoJLSRdkNEtmXwATOKpnYjxVavuiU =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
csoJLSRdkNEtmXwATOKpnYjxVavuiB=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class csoJLSRdkNEtmXwATOKpnYjxVavuih(csoJLSRdkNEtmXwATOKpnYjxVavuGq):
 def __init__(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuie,csoJLSRdkNEtmXwATOKpnYjxVavuir,csoJLSRdkNEtmXwATOKpnYjxVavuiQ):
  csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_url =csoJLSRdkNEtmXwATOKpnYjxVavuie
  csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle=csoJLSRdkNEtmXwATOKpnYjxVavuir
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params =csoJLSRdkNEtmXwATOKpnYjxVavuiQ
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj =sBHvhqkdECVflUAKouLyMGbNOjYwRc() 
 def addon_noti(csoJLSRdkNEtmXwATOKpnYjxVavuiH,sting):
  try:
   csoJLSRdkNEtmXwATOKpnYjxVavuiq=xbmcgui.Dialog()
   csoJLSRdkNEtmXwATOKpnYjxVavuiq.notification(__addonname__,sting)
  except:
   csoJLSRdkNEtmXwATOKpnYjxVavuGM
 def addon_log(csoJLSRdkNEtmXwATOKpnYjxVavuiH,string):
  try:
   csoJLSRdkNEtmXwATOKpnYjxVavuiM=string.encode('utf-8','ignore')
  except:
   csoJLSRdkNEtmXwATOKpnYjxVavuiM='addonException: addon_log'
  csoJLSRdkNEtmXwATOKpnYjxVavuiP=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,csoJLSRdkNEtmXwATOKpnYjxVavuiM),level=csoJLSRdkNEtmXwATOKpnYjxVavuiP)
 def get_keyboard_input(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuhQ):
  csoJLSRdkNEtmXwATOKpnYjxVavuiF=csoJLSRdkNEtmXwATOKpnYjxVavuGM
  kb=xbmc.Keyboard()
  kb.setHeading(csoJLSRdkNEtmXwATOKpnYjxVavuhQ)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   csoJLSRdkNEtmXwATOKpnYjxVavuiF=kb.getText()
  return csoJLSRdkNEtmXwATOKpnYjxVavuiF
 def get_settings_account(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  csoJLSRdkNEtmXwATOKpnYjxVavuiI =__addon__.getSetting('id')
  csoJLSRdkNEtmXwATOKpnYjxVavuiC =__addon__.getSetting('pw')
  csoJLSRdkNEtmXwATOKpnYjxVavuiD =__addon__.getSetting('login_type')
  csoJLSRdkNEtmXwATOKpnYjxVavuhi=csoJLSRdkNEtmXwATOKpnYjxVavuGP(__addon__.getSetting('selected_profile'))
  return(csoJLSRdkNEtmXwATOKpnYjxVavuiI,csoJLSRdkNEtmXwATOKpnYjxVavuiC,csoJLSRdkNEtmXwATOKpnYjxVavuiD,csoJLSRdkNEtmXwATOKpnYjxVavuhi)
 def get_settings_uhd(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  return csoJLSRdkNEtmXwATOKpnYjxVavuGF if __addon__.getSetting('active_uhd')=='true' else csoJLSRdkNEtmXwATOKpnYjxVavuGI
 def get_settings_playback(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  csoJLSRdkNEtmXwATOKpnYjxVavuhW={'active_uhd':csoJLSRdkNEtmXwATOKpnYjxVavuGF if __addon__.getSetting('active_uhd')=='true' else csoJLSRdkNEtmXwATOKpnYjxVavuGI,}
  return csoJLSRdkNEtmXwATOKpnYjxVavuhW
 def get_settings_proxyport(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  csoJLSRdkNEtmXwATOKpnYjxVavuhy =csoJLSRdkNEtmXwATOKpnYjxVavuGF if __addon__.getSetting('proxyYn')=='true' else csoJLSRdkNEtmXwATOKpnYjxVavuGI
  csoJLSRdkNEtmXwATOKpnYjxVavuhl=csoJLSRdkNEtmXwATOKpnYjxVavuGP(__addon__.getSetting('proxyPort'))
  return csoJLSRdkNEtmXwATOKpnYjxVavuhy,csoJLSRdkNEtmXwATOKpnYjxVavuhl
 def get_settings_totalsearch(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  csoJLSRdkNEtmXwATOKpnYjxVavuhb =csoJLSRdkNEtmXwATOKpnYjxVavuGF if __addon__.getSetting('local_search')=='true' else csoJLSRdkNEtmXwATOKpnYjxVavuGI
  csoJLSRdkNEtmXwATOKpnYjxVavuhz=csoJLSRdkNEtmXwATOKpnYjxVavuGF if __addon__.getSetting('local_history')=='true' else csoJLSRdkNEtmXwATOKpnYjxVavuGI
  csoJLSRdkNEtmXwATOKpnYjxVavuhG =csoJLSRdkNEtmXwATOKpnYjxVavuGF if __addon__.getSetting('total_search')=='true' else csoJLSRdkNEtmXwATOKpnYjxVavuGI
  csoJLSRdkNEtmXwATOKpnYjxVavuhg=csoJLSRdkNEtmXwATOKpnYjxVavuGF if __addon__.getSetting('total_history')=='true' else csoJLSRdkNEtmXwATOKpnYjxVavuGI
  csoJLSRdkNEtmXwATOKpnYjxVavuhU=csoJLSRdkNEtmXwATOKpnYjxVavuGF if __addon__.getSetting('menu_bookmark')=='true' else csoJLSRdkNEtmXwATOKpnYjxVavuGI
  return(csoJLSRdkNEtmXwATOKpnYjxVavuhb,csoJLSRdkNEtmXwATOKpnYjxVavuhz,csoJLSRdkNEtmXwATOKpnYjxVavuhG,csoJLSRdkNEtmXwATOKpnYjxVavuhg,csoJLSRdkNEtmXwATOKpnYjxVavuhU)
 def get_settings_makebookmark(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  return csoJLSRdkNEtmXwATOKpnYjxVavuGF if __addon__.getSetting('make_bookmark')=='true' else csoJLSRdkNEtmXwATOKpnYjxVavuGI
 def get_settings_direct_replay(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  csoJLSRdkNEtmXwATOKpnYjxVavuhB=csoJLSRdkNEtmXwATOKpnYjxVavuGP(__addon__.getSetting('direct_replay'))
  if csoJLSRdkNEtmXwATOKpnYjxVavuhB==0:
   return csoJLSRdkNEtmXwATOKpnYjxVavuGI
  else:
   return csoJLSRdkNEtmXwATOKpnYjxVavuGF
 def set_winEpisodeOrderby(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuhe):
  __addon__.setSetting('tving_orderby',csoJLSRdkNEtmXwATOKpnYjxVavuhe)
  csoJLSRdkNEtmXwATOKpnYjxVavuhH=xbmcgui.Window(10000)
  csoJLSRdkNEtmXwATOKpnYjxVavuhH.setProperty('TVING_M_ORDERBY',csoJLSRdkNEtmXwATOKpnYjxVavuhe)
 def get_winEpisodeOrderby(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  csoJLSRdkNEtmXwATOKpnYjxVavuhe=__addon__.getSetting('tving_orderby')
  if csoJLSRdkNEtmXwATOKpnYjxVavuhe in['',csoJLSRdkNEtmXwATOKpnYjxVavuGM]:csoJLSRdkNEtmXwATOKpnYjxVavuhe='desc'
  return csoJLSRdkNEtmXwATOKpnYjxVavuhe
 def add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuiH,label,sublabel='',img='',infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params='',isLink=csoJLSRdkNEtmXwATOKpnYjxVavuGI,ContextMenu=csoJLSRdkNEtmXwATOKpnYjxVavuGM):
  csoJLSRdkNEtmXwATOKpnYjxVavuhr='%s?%s'%(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_url,urllib.parse.urlencode(params))
  if sublabel:csoJLSRdkNEtmXwATOKpnYjxVavuhQ='%s < %s >'%(label,sublabel)
  else: csoJLSRdkNEtmXwATOKpnYjxVavuhQ=label
  if not img:img='DefaultFolder.png'
  csoJLSRdkNEtmXwATOKpnYjxVavuhf=xbmcgui.ListItem(csoJLSRdkNEtmXwATOKpnYjxVavuhQ)
  if csoJLSRdkNEtmXwATOKpnYjxVavuGC(img)==csoJLSRdkNEtmXwATOKpnYjxVavuGD:
   csoJLSRdkNEtmXwATOKpnYjxVavuhf.setArt(img)
  else:
   csoJLSRdkNEtmXwATOKpnYjxVavuhf.setArt({'thumb':img,'poster':img})
  if infoLabels:csoJLSRdkNEtmXwATOKpnYjxVavuhf.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   csoJLSRdkNEtmXwATOKpnYjxVavuhf.setProperty('IsPlayable','true')
  if ContextMenu:csoJLSRdkNEtmXwATOKpnYjxVavuhf.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,csoJLSRdkNEtmXwATOKpnYjxVavuhr,csoJLSRdkNEtmXwATOKpnYjxVavuhf,isFolder)
 def get_selQuality(csoJLSRdkNEtmXwATOKpnYjxVavuiH,etype):
  try:
   csoJLSRdkNEtmXwATOKpnYjxVavuhq='selected_quality'
   csoJLSRdkNEtmXwATOKpnYjxVavuhM=[1080,720,480,360]
   csoJLSRdkNEtmXwATOKpnYjxVavuhP=csoJLSRdkNEtmXwATOKpnYjxVavuGP(__addon__.getSetting(csoJLSRdkNEtmXwATOKpnYjxVavuhq))
   return csoJLSRdkNEtmXwATOKpnYjxVavuhM[csoJLSRdkNEtmXwATOKpnYjxVavuhP]
  except:
   csoJLSRdkNEtmXwATOKpnYjxVavuGM
  return 720 
 def dp_Main_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  (csoJLSRdkNEtmXwATOKpnYjxVavuhb,csoJLSRdkNEtmXwATOKpnYjxVavuhz,csoJLSRdkNEtmXwATOKpnYjxVavuhG,csoJLSRdkNEtmXwATOKpnYjxVavuhg,csoJLSRdkNEtmXwATOKpnYjxVavuhU)=csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_totalsearch()
  for csoJLSRdkNEtmXwATOKpnYjxVavuhF in csoJLSRdkNEtmXwATOKpnYjxVavuiW:
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ=csoJLSRdkNEtmXwATOKpnYjxVavuhF.get('title')
   csoJLSRdkNEtmXwATOKpnYjxVavuhI=''
   if csoJLSRdkNEtmXwATOKpnYjxVavuhF.get('mode')=='SEARCH_GROUP' and csoJLSRdkNEtmXwATOKpnYjxVavuhb ==csoJLSRdkNEtmXwATOKpnYjxVavuGI:continue
   elif csoJLSRdkNEtmXwATOKpnYjxVavuhF.get('mode')=='SEARCH_HISTORY' and csoJLSRdkNEtmXwATOKpnYjxVavuhz==csoJLSRdkNEtmXwATOKpnYjxVavuGI:continue
   elif csoJLSRdkNEtmXwATOKpnYjxVavuhF.get('mode')=='TOTAL_SEARCH' and csoJLSRdkNEtmXwATOKpnYjxVavuhG ==csoJLSRdkNEtmXwATOKpnYjxVavuGI:continue
   elif csoJLSRdkNEtmXwATOKpnYjxVavuhF.get('mode')=='TOTAL_HISTORY' and csoJLSRdkNEtmXwATOKpnYjxVavuhg==csoJLSRdkNEtmXwATOKpnYjxVavuGI:continue
   elif csoJLSRdkNEtmXwATOKpnYjxVavuhF.get('mode')=='MENU_BOOKMARK' and csoJLSRdkNEtmXwATOKpnYjxVavuhU==csoJLSRdkNEtmXwATOKpnYjxVavuGI:continue
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':csoJLSRdkNEtmXwATOKpnYjxVavuhF.get('mode'),'stype':csoJLSRdkNEtmXwATOKpnYjxVavuhF.get('stype'),'orderby':csoJLSRdkNEtmXwATOKpnYjxVavuhF.get('orderby'),'ordernm':csoJLSRdkNEtmXwATOKpnYjxVavuhF.get('ordernm'),'page':'1'}
   if csoJLSRdkNEtmXwATOKpnYjxVavuhF.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    csoJLSRdkNEtmXwATOKpnYjxVavuhD=csoJLSRdkNEtmXwATOKpnYjxVavuGI
    csoJLSRdkNEtmXwATOKpnYjxVavuWi =csoJLSRdkNEtmXwATOKpnYjxVavuGF
   else:
    csoJLSRdkNEtmXwATOKpnYjxVavuhD=csoJLSRdkNEtmXwATOKpnYjxVavuGF
    csoJLSRdkNEtmXwATOKpnYjxVavuWi =csoJLSRdkNEtmXwATOKpnYjxVavuGI
   if 'icon' in csoJLSRdkNEtmXwATOKpnYjxVavuhF:csoJLSRdkNEtmXwATOKpnYjxVavuhI=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',csoJLSRdkNEtmXwATOKpnYjxVavuhF.get('icon')) 
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel='',img=csoJLSRdkNEtmXwATOKpnYjxVavuhI,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuhD,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC,isLink=csoJLSRdkNEtmXwATOKpnYjxVavuWi)
  xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle)
 def login_main(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  (csoJLSRdkNEtmXwATOKpnYjxVavuWy,csoJLSRdkNEtmXwATOKpnYjxVavuWl,csoJLSRdkNEtmXwATOKpnYjxVavuWb,csoJLSRdkNEtmXwATOKpnYjxVavuWz)=csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_account()
  if not(csoJLSRdkNEtmXwATOKpnYjxVavuWy and csoJLSRdkNEtmXwATOKpnYjxVavuWl):
   csoJLSRdkNEtmXwATOKpnYjxVavuiq=xbmcgui.Dialog()
   csoJLSRdkNEtmXwATOKpnYjxVavuWG=csoJLSRdkNEtmXwATOKpnYjxVavuiq.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if csoJLSRdkNEtmXwATOKpnYjxVavuWG==csoJLSRdkNEtmXwATOKpnYjxVavuGF:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if csoJLSRdkNEtmXwATOKpnYjxVavuiH.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   csoJLSRdkNEtmXwATOKpnYjxVavuWg=0
   while csoJLSRdkNEtmXwATOKpnYjxVavuGF:
    csoJLSRdkNEtmXwATOKpnYjxVavuWg+=1
    time.sleep(0.05)
    if csoJLSRdkNEtmXwATOKpnYjxVavuWg>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  csoJLSRdkNEtmXwATOKpnYjxVavuWU=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.GetCredential(csoJLSRdkNEtmXwATOKpnYjxVavuWy,csoJLSRdkNEtmXwATOKpnYjxVavuWl,csoJLSRdkNEtmXwATOKpnYjxVavuWb,csoJLSRdkNEtmXwATOKpnYjxVavuWz)
  if csoJLSRdkNEtmXwATOKpnYjxVavuWU:csoJLSRdkNEtmXwATOKpnYjxVavuiH.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if csoJLSRdkNEtmXwATOKpnYjxVavuWU==csoJLSRdkNEtmXwATOKpnYjxVavuGI:
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuWB=csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('stype')
  if csoJLSRdkNEtmXwATOKpnYjxVavuWB=='live':
   csoJLSRdkNEtmXwATOKpnYjxVavuWH=csoJLSRdkNEtmXwATOKpnYjxVavuiy
  elif csoJLSRdkNEtmXwATOKpnYjxVavuWB=='vod':
   csoJLSRdkNEtmXwATOKpnYjxVavuWH=csoJLSRdkNEtmXwATOKpnYjxVavuiz
  else:
   csoJLSRdkNEtmXwATOKpnYjxVavuWH=csoJLSRdkNEtmXwATOKpnYjxVavuiG
  for csoJLSRdkNEtmXwATOKpnYjxVavuWe in csoJLSRdkNEtmXwATOKpnYjxVavuWH:
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ=csoJLSRdkNEtmXwATOKpnYjxVavuWe.get('title')
   if csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('ordernm')!='-':
    csoJLSRdkNEtmXwATOKpnYjxVavuhQ+='  ('+csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('ordernm')+')'
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':csoJLSRdkNEtmXwATOKpnYjxVavuWe.get('mode'),'stype':csoJLSRdkNEtmXwATOKpnYjxVavuWe.get('stype'),'orderby':csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('orderby'),'ordernm':csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('ordernm'),'page':'1'}
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel='',img='',infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  if csoJLSRdkNEtmXwATOKpnYjxVavugi(csoJLSRdkNEtmXwATOKpnYjxVavuWH)>0:xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle)
 def dp_SubTitle_Group(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr): 
  for csoJLSRdkNEtmXwATOKpnYjxVavuWe in csoJLSRdkNEtmXwATOKpnYjxVavuig:
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ=csoJLSRdkNEtmXwATOKpnYjxVavuWe.get('title')
   if csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('ordernm')!='-':
    csoJLSRdkNEtmXwATOKpnYjxVavuhQ+='  ('+csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('ordernm')+')'
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':csoJLSRdkNEtmXwATOKpnYjxVavuWe.get('mode'),'genreCode':csoJLSRdkNEtmXwATOKpnYjxVavuWe.get('genreCode'),'stype':csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('stype'),'orderby':csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('orderby'),'page':'1'}
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel='',img='',infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  if csoJLSRdkNEtmXwATOKpnYjxVavugi(csoJLSRdkNEtmXwATOKpnYjxVavuig)>0:xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle)
 def dp_LiveChannel_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuWB =csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('stype')
  csoJLSRdkNEtmXwATOKpnYjxVavuWQ =csoJLSRdkNEtmXwATOKpnYjxVavuGP(csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('page'))
  csoJLSRdkNEtmXwATOKpnYjxVavuWf,csoJLSRdkNEtmXwATOKpnYjxVavuWq=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.GetLiveChannelList(csoJLSRdkNEtmXwATOKpnYjxVavuWB,csoJLSRdkNEtmXwATOKpnYjxVavuWQ)
  for csoJLSRdkNEtmXwATOKpnYjxVavuWM in csoJLSRdkNEtmXwATOKpnYjxVavuWf:
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('title')
   csoJLSRdkNEtmXwATOKpnYjxVavuWh =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('channel')
   csoJLSRdkNEtmXwATOKpnYjxVavuWP =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('thumbnail')
   csoJLSRdkNEtmXwATOKpnYjxVavuWF =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('synopsis')
   csoJLSRdkNEtmXwATOKpnYjxVavuWI =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('channelepg')
   csoJLSRdkNEtmXwATOKpnYjxVavuWC =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('cast')
   csoJLSRdkNEtmXwATOKpnYjxVavuWD =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('director')
   csoJLSRdkNEtmXwATOKpnYjxVavuyi =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('info_genre')
   csoJLSRdkNEtmXwATOKpnYjxVavuyh =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('year')
   csoJLSRdkNEtmXwATOKpnYjxVavuyW =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('mpaa')
   csoJLSRdkNEtmXwATOKpnYjxVavuyl =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('premiered')
   csoJLSRdkNEtmXwATOKpnYjxVavuyb={'mediatype':'episode','title':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'studio':csoJLSRdkNEtmXwATOKpnYjxVavuWh,'cast':csoJLSRdkNEtmXwATOKpnYjxVavuWC,'director':csoJLSRdkNEtmXwATOKpnYjxVavuWD,'genre':csoJLSRdkNEtmXwATOKpnYjxVavuyi,'plot':'%s\n%s\n%s\n\n%s'%(csoJLSRdkNEtmXwATOKpnYjxVavuWh,csoJLSRdkNEtmXwATOKpnYjxVavuhQ,csoJLSRdkNEtmXwATOKpnYjxVavuWI,csoJLSRdkNEtmXwATOKpnYjxVavuWF),'year':csoJLSRdkNEtmXwATOKpnYjxVavuyh,'mpaa':csoJLSRdkNEtmXwATOKpnYjxVavuyW,'premiered':csoJLSRdkNEtmXwATOKpnYjxVavuyl}
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'LIVE','mediacode':csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('mediacode'),'stype':csoJLSRdkNEtmXwATOKpnYjxVavuWB}
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuWh,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuhQ,img=csoJLSRdkNEtmXwATOKpnYjxVavuWP,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuyb,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGI,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  if csoJLSRdkNEtmXwATOKpnYjxVavuWq:
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['mode']='CHANNEL' 
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['stype']=csoJLSRdkNEtmXwATOKpnYjxVavuWB 
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['page']=csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ='[B]%s >>[/B]'%'다음 페이지'
   csoJLSRdkNEtmXwATOKpnYjxVavuyz=csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhI=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuyz,img=csoJLSRdkNEtmXwATOKpnYjxVavuhI,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  if csoJLSRdkNEtmXwATOKpnYjxVavugi(csoJLSRdkNEtmXwATOKpnYjxVavuWf)>0:xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,cacheToDisc=csoJLSRdkNEtmXwATOKpnYjxVavuGI)
 def dp_Program_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuyG =csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('stype')
  csoJLSRdkNEtmXwATOKpnYjxVavuhe =csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('orderby')
  csoJLSRdkNEtmXwATOKpnYjxVavuWQ =csoJLSRdkNEtmXwATOKpnYjxVavuGP(csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('page'))
  csoJLSRdkNEtmXwATOKpnYjxVavuyg=csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('genreCode')
  if csoJLSRdkNEtmXwATOKpnYjxVavuyg==csoJLSRdkNEtmXwATOKpnYjxVavuGM:csoJLSRdkNEtmXwATOKpnYjxVavuyg='all'
  csoJLSRdkNEtmXwATOKpnYjxVavuyU,csoJLSRdkNEtmXwATOKpnYjxVavuWq=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.GetProgramList(csoJLSRdkNEtmXwATOKpnYjxVavuyG,csoJLSRdkNEtmXwATOKpnYjxVavuhe,csoJLSRdkNEtmXwATOKpnYjxVavuWQ,csoJLSRdkNEtmXwATOKpnYjxVavuyg)
  for csoJLSRdkNEtmXwATOKpnYjxVavuyB in csoJLSRdkNEtmXwATOKpnYjxVavuyU:
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('title')
   csoJLSRdkNEtmXwATOKpnYjxVavuWP =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('thumbnail')
   csoJLSRdkNEtmXwATOKpnYjxVavuWF =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('synopsis')
   csoJLSRdkNEtmXwATOKpnYjxVavuyH =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('channel')
   csoJLSRdkNEtmXwATOKpnYjxVavuWC =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('cast')
   csoJLSRdkNEtmXwATOKpnYjxVavuWD =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('director')
   csoJLSRdkNEtmXwATOKpnYjxVavuyi=csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('info_genre')
   csoJLSRdkNEtmXwATOKpnYjxVavuyh =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('year')
   csoJLSRdkNEtmXwATOKpnYjxVavuyl =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('premiered')
   csoJLSRdkNEtmXwATOKpnYjxVavuyW =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('mpaa')
   csoJLSRdkNEtmXwATOKpnYjxVavuyb={'mediatype':'tvshow','title':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'studio':csoJLSRdkNEtmXwATOKpnYjxVavuyH,'cast':csoJLSRdkNEtmXwATOKpnYjxVavuWC,'director':csoJLSRdkNEtmXwATOKpnYjxVavuWD,'genre':csoJLSRdkNEtmXwATOKpnYjxVavuyi,'year':csoJLSRdkNEtmXwATOKpnYjxVavuyh,'premiered':csoJLSRdkNEtmXwATOKpnYjxVavuyl,'mpaa':csoJLSRdkNEtmXwATOKpnYjxVavuyW,'plot':csoJLSRdkNEtmXwATOKpnYjxVavuWF}
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'EPISODE','programcode':csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('program'),'page':'1'}
   if csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_makebookmark():
    csoJLSRdkNEtmXwATOKpnYjxVavuye={'videoid':csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('program'),'vidtype':'tvshow','vtitle':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'vsubtitle':csoJLSRdkNEtmXwATOKpnYjxVavuyH,}
    csoJLSRdkNEtmXwATOKpnYjxVavuyr=json.dumps(csoJLSRdkNEtmXwATOKpnYjxVavuye)
    csoJLSRdkNEtmXwATOKpnYjxVavuyr=urllib.parse.quote(csoJLSRdkNEtmXwATOKpnYjxVavuyr)
    csoJLSRdkNEtmXwATOKpnYjxVavuyQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(csoJLSRdkNEtmXwATOKpnYjxVavuyr)
    csoJLSRdkNEtmXwATOKpnYjxVavuyf=[('(통합) 찜 영상에 추가',csoJLSRdkNEtmXwATOKpnYjxVavuyQ)]
   else:
    csoJLSRdkNEtmXwATOKpnYjxVavuyf=csoJLSRdkNEtmXwATOKpnYjxVavuGM
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuyH,img=csoJLSRdkNEtmXwATOKpnYjxVavuWP,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuyb,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC,ContextMenu=csoJLSRdkNEtmXwATOKpnYjxVavuyf)
  if csoJLSRdkNEtmXwATOKpnYjxVavuWq:
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['mode'] ='PROGRAM' 
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['stype'] =csoJLSRdkNEtmXwATOKpnYjxVavuyG
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['orderby'] =csoJLSRdkNEtmXwATOKpnYjxVavuhe
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['page'] =csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['genreCode']=csoJLSRdkNEtmXwATOKpnYjxVavuyg 
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ='[B]%s >>[/B]'%'다음 페이지'
   csoJLSRdkNEtmXwATOKpnYjxVavuyz=csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhI=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuyz,img=csoJLSRdkNEtmXwATOKpnYjxVavuhI,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  xbmcplugin.setContent(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,cacheToDisc=csoJLSRdkNEtmXwATOKpnYjxVavuGI)
 def dp_4K_Program_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuWQ =csoJLSRdkNEtmXwATOKpnYjxVavuGP(csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('page'))
  csoJLSRdkNEtmXwATOKpnYjxVavuyU,csoJLSRdkNEtmXwATOKpnYjxVavuWq=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.Get_UHD_ProgramList(csoJLSRdkNEtmXwATOKpnYjxVavuWQ)
  for csoJLSRdkNEtmXwATOKpnYjxVavuyB in csoJLSRdkNEtmXwATOKpnYjxVavuyU:
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('title')
   csoJLSRdkNEtmXwATOKpnYjxVavuWP =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('thumbnail')
   csoJLSRdkNEtmXwATOKpnYjxVavuWF =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('synopsis')
   csoJLSRdkNEtmXwATOKpnYjxVavuyH =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('channel')
   csoJLSRdkNEtmXwATOKpnYjxVavuWC =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('cast')
   csoJLSRdkNEtmXwATOKpnYjxVavuWD =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('director')
   csoJLSRdkNEtmXwATOKpnYjxVavuyi=csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('info_genre')
   csoJLSRdkNEtmXwATOKpnYjxVavuyh =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('year')
   csoJLSRdkNEtmXwATOKpnYjxVavuyl =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('premiered')
   csoJLSRdkNEtmXwATOKpnYjxVavuyW =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('mpaa')
   csoJLSRdkNEtmXwATOKpnYjxVavuyb={'mediatype':'tvshow','title':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'studio':csoJLSRdkNEtmXwATOKpnYjxVavuyH,'cast':csoJLSRdkNEtmXwATOKpnYjxVavuWC,'director':csoJLSRdkNEtmXwATOKpnYjxVavuWD,'genre':csoJLSRdkNEtmXwATOKpnYjxVavuyi,'year':csoJLSRdkNEtmXwATOKpnYjxVavuyh,'premiered':csoJLSRdkNEtmXwATOKpnYjxVavuyl,'mpaa':csoJLSRdkNEtmXwATOKpnYjxVavuyW,'plot':csoJLSRdkNEtmXwATOKpnYjxVavuWF}
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'EPISODE','programcode':csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('program'),'page':'1'}
   if csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_makebookmark():
    csoJLSRdkNEtmXwATOKpnYjxVavuye={'videoid':csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('program'),'vidtype':'tvshow','vtitle':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'vsubtitle':csoJLSRdkNEtmXwATOKpnYjxVavuyH,}
    csoJLSRdkNEtmXwATOKpnYjxVavuyr=json.dumps(csoJLSRdkNEtmXwATOKpnYjxVavuye)
    csoJLSRdkNEtmXwATOKpnYjxVavuyr=urllib.parse.quote(csoJLSRdkNEtmXwATOKpnYjxVavuyr)
    csoJLSRdkNEtmXwATOKpnYjxVavuyQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(csoJLSRdkNEtmXwATOKpnYjxVavuyr)
    csoJLSRdkNEtmXwATOKpnYjxVavuyf=[('(통합) 찜 영상에 추가',csoJLSRdkNEtmXwATOKpnYjxVavuyQ)]
   else:
    csoJLSRdkNEtmXwATOKpnYjxVavuyf=csoJLSRdkNEtmXwATOKpnYjxVavuGM
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuyH,img=csoJLSRdkNEtmXwATOKpnYjxVavuWP,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuyb,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC,ContextMenu=csoJLSRdkNEtmXwATOKpnYjxVavuyf)
  if csoJLSRdkNEtmXwATOKpnYjxVavuWq:
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['mode'] ='4K_PROGRAM' 
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['page'] =csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ='[B]%s >>[/B]'%'다음 페이지'
   csoJLSRdkNEtmXwATOKpnYjxVavuyz=csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhI=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuyz,img=csoJLSRdkNEtmXwATOKpnYjxVavuhI,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  xbmcplugin.setContent(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,cacheToDisc=csoJLSRdkNEtmXwATOKpnYjxVavuGI)
 def dp_Ori_Program_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuWQ =csoJLSRdkNEtmXwATOKpnYjxVavuGP(csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('page'))
  csoJLSRdkNEtmXwATOKpnYjxVavuyU,csoJLSRdkNEtmXwATOKpnYjxVavuWq=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.Get_Origianl_ProgramList(csoJLSRdkNEtmXwATOKpnYjxVavuWQ)
  for csoJLSRdkNEtmXwATOKpnYjxVavuyB in csoJLSRdkNEtmXwATOKpnYjxVavuyU:
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('title')
   csoJLSRdkNEtmXwATOKpnYjxVavuWP =csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('thumbnail')
   csoJLSRdkNEtmXwATOKpnYjxVavuyb={'mediatype':'tvshow','title':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,}
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'EPISODE','programcode':csoJLSRdkNEtmXwATOKpnYjxVavuyB.get('program'),'page':'1',}
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuGM,img=csoJLSRdkNEtmXwATOKpnYjxVavuWP,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuyb,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC,ContextMenu=csoJLSRdkNEtmXwATOKpnYjxVavuGM)
  if csoJLSRdkNEtmXwATOKpnYjxVavuWq:
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['mode'] ='ORI_PROGRAM' 
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['page'] =csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ='[B]%s >>[/B]'%'다음 페이지'
   csoJLSRdkNEtmXwATOKpnYjxVavuyz=csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhI=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuyz,img=csoJLSRdkNEtmXwATOKpnYjxVavuhI,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  xbmcplugin.setContent(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,cacheToDisc=csoJLSRdkNEtmXwATOKpnYjxVavuGI)
 def dp_Episode_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuyM=csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('programcode')
  csoJLSRdkNEtmXwATOKpnYjxVavuWQ =csoJLSRdkNEtmXwATOKpnYjxVavuGP(csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('page'))
  csoJLSRdkNEtmXwATOKpnYjxVavuyP,csoJLSRdkNEtmXwATOKpnYjxVavuWq,csoJLSRdkNEtmXwATOKpnYjxVavuyF=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.GetEpisodeList(csoJLSRdkNEtmXwATOKpnYjxVavuyM,csoJLSRdkNEtmXwATOKpnYjxVavuWQ,orderby=csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_winEpisodeOrderby())
  for csoJLSRdkNEtmXwATOKpnYjxVavuyI in csoJLSRdkNEtmXwATOKpnYjxVavuyP:
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ =csoJLSRdkNEtmXwATOKpnYjxVavuyI.get('title')
   csoJLSRdkNEtmXwATOKpnYjxVavuyz =csoJLSRdkNEtmXwATOKpnYjxVavuyI.get('subtitle')
   csoJLSRdkNEtmXwATOKpnYjxVavuWP =csoJLSRdkNEtmXwATOKpnYjxVavuyI.get('thumbnail')
   csoJLSRdkNEtmXwATOKpnYjxVavuWF =csoJLSRdkNEtmXwATOKpnYjxVavuyI.get('synopsis')
   csoJLSRdkNEtmXwATOKpnYjxVavuyC=csoJLSRdkNEtmXwATOKpnYjxVavuyI.get('info_title')
   csoJLSRdkNEtmXwATOKpnYjxVavuyD =csoJLSRdkNEtmXwATOKpnYjxVavuyI.get('aired')
   csoJLSRdkNEtmXwATOKpnYjxVavuli =csoJLSRdkNEtmXwATOKpnYjxVavuyI.get('studio')
   csoJLSRdkNEtmXwATOKpnYjxVavulh =csoJLSRdkNEtmXwATOKpnYjxVavuyI.get('frequency')
   csoJLSRdkNEtmXwATOKpnYjxVavuyb={'mediatype':'episode','title':csoJLSRdkNEtmXwATOKpnYjxVavuyC,'aired':csoJLSRdkNEtmXwATOKpnYjxVavuyD,'studio':csoJLSRdkNEtmXwATOKpnYjxVavuli,'episode':csoJLSRdkNEtmXwATOKpnYjxVavulh,'plot':csoJLSRdkNEtmXwATOKpnYjxVavuWF}
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'VOD','mediacode':csoJLSRdkNEtmXwATOKpnYjxVavuyI.get('episode'),'stype':'vod','programcode':csoJLSRdkNEtmXwATOKpnYjxVavuyM,'title':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'thumbnail':csoJLSRdkNEtmXwATOKpnYjxVavuWP}
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuyz,img=csoJLSRdkNEtmXwATOKpnYjxVavuWP,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuyb,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGI,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  if csoJLSRdkNEtmXwATOKpnYjxVavuWQ==1:
   csoJLSRdkNEtmXwATOKpnYjxVavuyb={'plot':'정렬순서를 변경합니다.'}
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={}
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['mode'] ='ORDER_BY' 
   if csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_winEpisodeOrderby()=='desc':
    csoJLSRdkNEtmXwATOKpnYjxVavuhQ='정렬순서변경 : 최신화부터 -> 1회부터'
    csoJLSRdkNEtmXwATOKpnYjxVavuhC['orderby']='asc'
   else:
    csoJLSRdkNEtmXwATOKpnYjxVavuhQ='정렬순서변경 : 1회부터 -> 최신화부터'
    csoJLSRdkNEtmXwATOKpnYjxVavuhC['orderby']='desc'
   csoJLSRdkNEtmXwATOKpnYjxVavuhI=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel='',img=csoJLSRdkNEtmXwATOKpnYjxVavuhI,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuyb,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGI,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC,isLink=csoJLSRdkNEtmXwATOKpnYjxVavuGF)
  if csoJLSRdkNEtmXwATOKpnYjxVavuWq:
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['mode'] ='EPISODE' 
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['programcode']=csoJLSRdkNEtmXwATOKpnYjxVavuyM
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['page'] =csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ='[B]%s >>[/B]'%'다음 페이지'
   csoJLSRdkNEtmXwATOKpnYjxVavuyz=csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhI=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuyz,img=csoJLSRdkNEtmXwATOKpnYjxVavuhI,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  xbmcplugin.setContent(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,'episodes')
  if csoJLSRdkNEtmXwATOKpnYjxVavugi(csoJLSRdkNEtmXwATOKpnYjxVavuyP)>0:xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,cacheToDisc=csoJLSRdkNEtmXwATOKpnYjxVavuGF)
 def dp_setEpOrderby(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuhe =csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('orderby')
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.set_winEpisodeOrderby(csoJLSRdkNEtmXwATOKpnYjxVavuhe)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuyG =csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('stype')
  csoJLSRdkNEtmXwATOKpnYjxVavuhe =csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('orderby')
  csoJLSRdkNEtmXwATOKpnYjxVavuWQ=csoJLSRdkNEtmXwATOKpnYjxVavuGP(csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('page'))
  csoJLSRdkNEtmXwATOKpnYjxVavulW,csoJLSRdkNEtmXwATOKpnYjxVavuWq=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.GetMovieList(csoJLSRdkNEtmXwATOKpnYjxVavuyG,csoJLSRdkNEtmXwATOKpnYjxVavuhe,csoJLSRdkNEtmXwATOKpnYjxVavuWQ)
  for csoJLSRdkNEtmXwATOKpnYjxVavuly in csoJLSRdkNEtmXwATOKpnYjxVavulW:
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('title')
   csoJLSRdkNEtmXwATOKpnYjxVavuWP =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('thumbnail')
   csoJLSRdkNEtmXwATOKpnYjxVavuWF =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('synopsis')
   csoJLSRdkNEtmXwATOKpnYjxVavuyC =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('info_title')
   csoJLSRdkNEtmXwATOKpnYjxVavuyh =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('year')
   csoJLSRdkNEtmXwATOKpnYjxVavuWC =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('cast')
   csoJLSRdkNEtmXwATOKpnYjxVavuWD =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('director')
   csoJLSRdkNEtmXwATOKpnYjxVavuyi =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('info_genre')
   csoJLSRdkNEtmXwATOKpnYjxVavulb =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('duration')
   csoJLSRdkNEtmXwATOKpnYjxVavuyl =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('premiered')
   csoJLSRdkNEtmXwATOKpnYjxVavuli =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('studio')
   csoJLSRdkNEtmXwATOKpnYjxVavuyW =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('mpaa')
   csoJLSRdkNEtmXwATOKpnYjxVavuyb={'mediatype':'movie','title':csoJLSRdkNEtmXwATOKpnYjxVavuyC,'year':csoJLSRdkNEtmXwATOKpnYjxVavuyh,'cast':csoJLSRdkNEtmXwATOKpnYjxVavuWC,'director':csoJLSRdkNEtmXwATOKpnYjxVavuWD,'genre':csoJLSRdkNEtmXwATOKpnYjxVavuyi,'duration':csoJLSRdkNEtmXwATOKpnYjxVavulb,'premiered':csoJLSRdkNEtmXwATOKpnYjxVavuyl,'studio':csoJLSRdkNEtmXwATOKpnYjxVavuli,'mpaa':csoJLSRdkNEtmXwATOKpnYjxVavuyW,'plot':csoJLSRdkNEtmXwATOKpnYjxVavuWF}
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'MOVIE','mediacode':csoJLSRdkNEtmXwATOKpnYjxVavuly.get('moviecode'),'stype':'movie','title':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'thumbnail':csoJLSRdkNEtmXwATOKpnYjxVavuWP}
   if csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_makebookmark():
    csoJLSRdkNEtmXwATOKpnYjxVavuye={'videoid':csoJLSRdkNEtmXwATOKpnYjxVavuly.get('moviecode'),'vidtype':'movie','vtitle':csoJLSRdkNEtmXwATOKpnYjxVavuyC,'vsubtitle':'',}
    csoJLSRdkNEtmXwATOKpnYjxVavuyr=json.dumps(csoJLSRdkNEtmXwATOKpnYjxVavuye)
    csoJLSRdkNEtmXwATOKpnYjxVavuyr=urllib.parse.quote(csoJLSRdkNEtmXwATOKpnYjxVavuyr)
    csoJLSRdkNEtmXwATOKpnYjxVavuyQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(csoJLSRdkNEtmXwATOKpnYjxVavuyr)
    csoJLSRdkNEtmXwATOKpnYjxVavuyf=[('(통합) 찜 영상에 추가',csoJLSRdkNEtmXwATOKpnYjxVavuyQ)]
   else:
    csoJLSRdkNEtmXwATOKpnYjxVavuyf=csoJLSRdkNEtmXwATOKpnYjxVavuGM
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel='',img=csoJLSRdkNEtmXwATOKpnYjxVavuWP,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuyb,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGI,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC,ContextMenu=csoJLSRdkNEtmXwATOKpnYjxVavuyf)
  if csoJLSRdkNEtmXwATOKpnYjxVavuWq:
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={}
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['mode'] ='MOVIE_SUB' 
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['orderby']=csoJLSRdkNEtmXwATOKpnYjxVavuhe
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['stype'] =csoJLSRdkNEtmXwATOKpnYjxVavuyG
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['page'] =csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ='[B]%s >>[/B]'%'다음 페이지'
   csoJLSRdkNEtmXwATOKpnYjxVavuyz=csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhI=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuyz,img=csoJLSRdkNEtmXwATOKpnYjxVavuhI,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  xbmcplugin.setContent(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,'movies')
  xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,cacheToDisc=csoJLSRdkNEtmXwATOKpnYjxVavuGI)
 def dp_4K_Movie_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuWQ=csoJLSRdkNEtmXwATOKpnYjxVavuGP(csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('page'))
  csoJLSRdkNEtmXwATOKpnYjxVavulW,csoJLSRdkNEtmXwATOKpnYjxVavuWq=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.Get_UHD_MovieList(csoJLSRdkNEtmXwATOKpnYjxVavuWQ)
  for csoJLSRdkNEtmXwATOKpnYjxVavuly in csoJLSRdkNEtmXwATOKpnYjxVavulW:
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('title')
   csoJLSRdkNEtmXwATOKpnYjxVavuWP =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('thumbnail')
   csoJLSRdkNEtmXwATOKpnYjxVavuWF =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('synopsis')
   csoJLSRdkNEtmXwATOKpnYjxVavuyC =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('info_title')
   csoJLSRdkNEtmXwATOKpnYjxVavuyh =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('year')
   csoJLSRdkNEtmXwATOKpnYjxVavuWC =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('cast')
   csoJLSRdkNEtmXwATOKpnYjxVavuWD =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('director')
   csoJLSRdkNEtmXwATOKpnYjxVavuyi =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('info_genre')
   csoJLSRdkNEtmXwATOKpnYjxVavulb =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('duration')
   csoJLSRdkNEtmXwATOKpnYjxVavuyl =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('premiered')
   csoJLSRdkNEtmXwATOKpnYjxVavuli =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('studio')
   csoJLSRdkNEtmXwATOKpnYjxVavuyW =csoJLSRdkNEtmXwATOKpnYjxVavuly.get('mpaa')
   csoJLSRdkNEtmXwATOKpnYjxVavuyb={'mediatype':'movie','title':csoJLSRdkNEtmXwATOKpnYjxVavuyC,'year':csoJLSRdkNEtmXwATOKpnYjxVavuyh,'cast':csoJLSRdkNEtmXwATOKpnYjxVavuWC,'director':csoJLSRdkNEtmXwATOKpnYjxVavuWD,'genre':csoJLSRdkNEtmXwATOKpnYjxVavuyi,'duration':csoJLSRdkNEtmXwATOKpnYjxVavulb,'premiered':csoJLSRdkNEtmXwATOKpnYjxVavuyl,'studio':csoJLSRdkNEtmXwATOKpnYjxVavuli,'mpaa':csoJLSRdkNEtmXwATOKpnYjxVavuyW,'plot':csoJLSRdkNEtmXwATOKpnYjxVavuWF}
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'MOVIE','mediacode':csoJLSRdkNEtmXwATOKpnYjxVavuly.get('moviecode'),'stype':'movie','title':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'thumbnail':csoJLSRdkNEtmXwATOKpnYjxVavuWP}
   if csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_makebookmark():
    csoJLSRdkNEtmXwATOKpnYjxVavuye={'videoid':csoJLSRdkNEtmXwATOKpnYjxVavuly.get('moviecode'),'vidtype':'movie','vtitle':csoJLSRdkNEtmXwATOKpnYjxVavuyC,'vsubtitle':'',}
    csoJLSRdkNEtmXwATOKpnYjxVavuyr=json.dumps(csoJLSRdkNEtmXwATOKpnYjxVavuye)
    csoJLSRdkNEtmXwATOKpnYjxVavuyr=urllib.parse.quote(csoJLSRdkNEtmXwATOKpnYjxVavuyr)
    csoJLSRdkNEtmXwATOKpnYjxVavuyQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(csoJLSRdkNEtmXwATOKpnYjxVavuyr)
    csoJLSRdkNEtmXwATOKpnYjxVavuyf=[('(통합) 찜 영상에 추가',csoJLSRdkNEtmXwATOKpnYjxVavuyQ)]
   else:
    csoJLSRdkNEtmXwATOKpnYjxVavuyf=csoJLSRdkNEtmXwATOKpnYjxVavuGM
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel='',img=csoJLSRdkNEtmXwATOKpnYjxVavuWP,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuyb,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGI,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC,ContextMenu=csoJLSRdkNEtmXwATOKpnYjxVavuyf)
  if csoJLSRdkNEtmXwATOKpnYjxVavuWq:
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={}
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['mode'] ='4K_MOVIE' 
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['page'] =csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ='[B]%s >>[/B]'%'다음 페이지'
   csoJLSRdkNEtmXwATOKpnYjxVavuyz=csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhI=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuyz,img=csoJLSRdkNEtmXwATOKpnYjxVavuhI,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  xbmcplugin.setContent(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,'movies')
  xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,cacheToDisc=csoJLSRdkNEtmXwATOKpnYjxVavuGI)
 def dp_Set_Bookmark(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavulz=urllib.parse.unquote(csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('bm_param'))
  csoJLSRdkNEtmXwATOKpnYjxVavulz=json.loads(csoJLSRdkNEtmXwATOKpnYjxVavulz)
  csoJLSRdkNEtmXwATOKpnYjxVavulG =csoJLSRdkNEtmXwATOKpnYjxVavulz.get('videoid')
  csoJLSRdkNEtmXwATOKpnYjxVavulg =csoJLSRdkNEtmXwATOKpnYjxVavulz.get('vidtype')
  csoJLSRdkNEtmXwATOKpnYjxVavulU =csoJLSRdkNEtmXwATOKpnYjxVavulz.get('vtitle')
  csoJLSRdkNEtmXwATOKpnYjxVavulB =csoJLSRdkNEtmXwATOKpnYjxVavulz.get('vsubtitle')
  csoJLSRdkNEtmXwATOKpnYjxVavuiq=xbmcgui.Dialog()
  csoJLSRdkNEtmXwATOKpnYjxVavuWG=csoJLSRdkNEtmXwATOKpnYjxVavuiq.yesno(__language__(30913).encode('utf8'),csoJLSRdkNEtmXwATOKpnYjxVavulU+' \n\n'+__language__(30914))
  if csoJLSRdkNEtmXwATOKpnYjxVavuWG==csoJLSRdkNEtmXwATOKpnYjxVavuGI:return
  csoJLSRdkNEtmXwATOKpnYjxVavulH=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.GetBookmarkInfo(csoJLSRdkNEtmXwATOKpnYjxVavulG,csoJLSRdkNEtmXwATOKpnYjxVavulg)
  if csoJLSRdkNEtmXwATOKpnYjxVavulB!='':
   csoJLSRdkNEtmXwATOKpnYjxVavulH['saveinfo']['subtitle']=csoJLSRdkNEtmXwATOKpnYjxVavulB 
   if csoJLSRdkNEtmXwATOKpnYjxVavulg=='tvshow':csoJLSRdkNEtmXwATOKpnYjxVavulH['saveinfo']['infoLabels']['studio']=csoJLSRdkNEtmXwATOKpnYjxVavulB 
  csoJLSRdkNEtmXwATOKpnYjxVavule=json.dumps(csoJLSRdkNEtmXwATOKpnYjxVavulH)
  csoJLSRdkNEtmXwATOKpnYjxVavule=urllib.parse.quote(csoJLSRdkNEtmXwATOKpnYjxVavule)
  csoJLSRdkNEtmXwATOKpnYjxVavuyQ ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(csoJLSRdkNEtmXwATOKpnYjxVavule)
  xbmc.executebuiltin(csoJLSRdkNEtmXwATOKpnYjxVavuyQ)
 def dp_Search_Group(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  if 'search_key' in csoJLSRdkNEtmXwATOKpnYjxVavuWr:
   csoJLSRdkNEtmXwATOKpnYjxVavulr=csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('search_key')
  else:
   csoJLSRdkNEtmXwATOKpnYjxVavulr=csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not csoJLSRdkNEtmXwATOKpnYjxVavulr:
    return
  for csoJLSRdkNEtmXwATOKpnYjxVavuWe in csoJLSRdkNEtmXwATOKpnYjxVavuib:
   csoJLSRdkNEtmXwATOKpnYjxVavulQ =csoJLSRdkNEtmXwATOKpnYjxVavuWe.get('mode')
   csoJLSRdkNEtmXwATOKpnYjxVavuWB=csoJLSRdkNEtmXwATOKpnYjxVavuWe.get('stype')
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ=csoJLSRdkNEtmXwATOKpnYjxVavuWe.get('title')
   (csoJLSRdkNEtmXwATOKpnYjxVavulf,csoJLSRdkNEtmXwATOKpnYjxVavuWq)=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.GetSearchList(csoJLSRdkNEtmXwATOKpnYjxVavulr,1,csoJLSRdkNEtmXwATOKpnYjxVavuWB)
   csoJLSRdkNEtmXwATOKpnYjxVavulq={'plot':'검색어 : '+csoJLSRdkNEtmXwATOKpnYjxVavulr+'\n\n'+csoJLSRdkNEtmXwATOKpnYjxVavuiH.Search_FreeList(csoJLSRdkNEtmXwATOKpnYjxVavulf)}
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':csoJLSRdkNEtmXwATOKpnYjxVavulQ,'stype':csoJLSRdkNEtmXwATOKpnYjxVavuWB,'search_key':csoJLSRdkNEtmXwATOKpnYjxVavulr,'page':'1',}
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel='',img='',infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavulq,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  if csoJLSRdkNEtmXwATOKpnYjxVavugi(csoJLSRdkNEtmXwATOKpnYjxVavuib)>0:xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,cacheToDisc=csoJLSRdkNEtmXwATOKpnYjxVavuGF)
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.Save_Searched_List(csoJLSRdkNEtmXwATOKpnYjxVavulr)
 def Search_FreeList(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavubW):
  csoJLSRdkNEtmXwATOKpnYjxVavulM=''
  csoJLSRdkNEtmXwATOKpnYjxVavulP=7
  try:
   if csoJLSRdkNEtmXwATOKpnYjxVavugi(csoJLSRdkNEtmXwATOKpnYjxVavubW)==0:return '검색결과 없음'
   for i in csoJLSRdkNEtmXwATOKpnYjxVavugW(csoJLSRdkNEtmXwATOKpnYjxVavugi(csoJLSRdkNEtmXwATOKpnYjxVavubW)):
    if i>=csoJLSRdkNEtmXwATOKpnYjxVavulP:
     csoJLSRdkNEtmXwATOKpnYjxVavulM=csoJLSRdkNEtmXwATOKpnYjxVavulM+'...'
     break
    csoJLSRdkNEtmXwATOKpnYjxVavulM=csoJLSRdkNEtmXwATOKpnYjxVavulM+csoJLSRdkNEtmXwATOKpnYjxVavubW[i]['title']+'\n'
  except:
   return ''
  return csoJLSRdkNEtmXwATOKpnYjxVavulM
 def dp_Search_History(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavulF=csoJLSRdkNEtmXwATOKpnYjxVavuiH.Load_List_File('search')
  for csoJLSRdkNEtmXwATOKpnYjxVavulI in csoJLSRdkNEtmXwATOKpnYjxVavulF:
   csoJLSRdkNEtmXwATOKpnYjxVavulC=csoJLSRdkNEtmXwATOKpnYjxVavuGD(urllib.parse.parse_qsl(csoJLSRdkNEtmXwATOKpnYjxVavulI))
   csoJLSRdkNEtmXwATOKpnYjxVavulD=csoJLSRdkNEtmXwATOKpnYjxVavulC.get('skey').strip()
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'SEARCH_GROUP','search_key':csoJLSRdkNEtmXwATOKpnYjxVavulD,}
   csoJLSRdkNEtmXwATOKpnYjxVavubi={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':csoJLSRdkNEtmXwATOKpnYjxVavulD,'vType':'-',}
   csoJLSRdkNEtmXwATOKpnYjxVavubh=urllib.parse.urlencode(csoJLSRdkNEtmXwATOKpnYjxVavubi)
   csoJLSRdkNEtmXwATOKpnYjxVavuyf=[('선택된 검색어 ( %s ) 삭제'%(csoJLSRdkNEtmXwATOKpnYjxVavulD),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(csoJLSRdkNEtmXwATOKpnYjxVavubh))]
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavulD,sublabel='',img=csoJLSRdkNEtmXwATOKpnYjxVavuGM,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC,ContextMenu=csoJLSRdkNEtmXwATOKpnYjxVavuyf)
  csoJLSRdkNEtmXwATOKpnYjxVavuyb={'plot':'검색목록 전체를 삭제합니다.'}
  csoJLSRdkNEtmXwATOKpnYjxVavuhQ='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  csoJLSRdkNEtmXwATOKpnYjxVavuhI=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel='',img=csoJLSRdkNEtmXwATOKpnYjxVavuhI,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuyb,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGI,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC,isLink=csoJLSRdkNEtmXwATOKpnYjxVavuGF)
  xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,cacheToDisc=csoJLSRdkNEtmXwATOKpnYjxVavuGI)
 def dp_Search_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuWQ =csoJLSRdkNEtmXwATOKpnYjxVavuGP(csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('page'))
  csoJLSRdkNEtmXwATOKpnYjxVavuWB =csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('stype')
  if 'search_key' in csoJLSRdkNEtmXwATOKpnYjxVavuWr:
   csoJLSRdkNEtmXwATOKpnYjxVavulr=csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('search_key')
  else:
   csoJLSRdkNEtmXwATOKpnYjxVavulr=csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not csoJLSRdkNEtmXwATOKpnYjxVavulr:
    xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle)
    return
  csoJLSRdkNEtmXwATOKpnYjxVavulf,csoJLSRdkNEtmXwATOKpnYjxVavuWq=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.GetSearchList(csoJLSRdkNEtmXwATOKpnYjxVavulr,csoJLSRdkNEtmXwATOKpnYjxVavuWQ,csoJLSRdkNEtmXwATOKpnYjxVavuWB)
  for csoJLSRdkNEtmXwATOKpnYjxVavubW in csoJLSRdkNEtmXwATOKpnYjxVavulf:
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ =csoJLSRdkNEtmXwATOKpnYjxVavubW.get('title')
   csoJLSRdkNEtmXwATOKpnYjxVavuWP =csoJLSRdkNEtmXwATOKpnYjxVavubW.get('thumbnail')
   csoJLSRdkNEtmXwATOKpnYjxVavuWF =csoJLSRdkNEtmXwATOKpnYjxVavubW.get('synopsis')
   csoJLSRdkNEtmXwATOKpnYjxVavuby =csoJLSRdkNEtmXwATOKpnYjxVavubW.get('program')
   csoJLSRdkNEtmXwATOKpnYjxVavuWC =csoJLSRdkNEtmXwATOKpnYjxVavubW.get('cast')
   csoJLSRdkNEtmXwATOKpnYjxVavuWD =csoJLSRdkNEtmXwATOKpnYjxVavubW.get('director')
   csoJLSRdkNEtmXwATOKpnYjxVavuyi=csoJLSRdkNEtmXwATOKpnYjxVavubW.get('info_genre')
   csoJLSRdkNEtmXwATOKpnYjxVavulb =csoJLSRdkNEtmXwATOKpnYjxVavubW.get('duration')
   csoJLSRdkNEtmXwATOKpnYjxVavuyW =csoJLSRdkNEtmXwATOKpnYjxVavubW.get('mpaa')
   csoJLSRdkNEtmXwATOKpnYjxVavuyh =csoJLSRdkNEtmXwATOKpnYjxVavubW.get('year')
   csoJLSRdkNEtmXwATOKpnYjxVavuyD =csoJLSRdkNEtmXwATOKpnYjxVavubW.get('aired')
   csoJLSRdkNEtmXwATOKpnYjxVavuyb={'mediatype':'tvshow' if csoJLSRdkNEtmXwATOKpnYjxVavuWB=='vod' else 'movie','title':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'cast':csoJLSRdkNEtmXwATOKpnYjxVavuWC,'director':csoJLSRdkNEtmXwATOKpnYjxVavuWD,'genre':csoJLSRdkNEtmXwATOKpnYjxVavuyi,'duration':csoJLSRdkNEtmXwATOKpnYjxVavulb,'mpaa':csoJLSRdkNEtmXwATOKpnYjxVavuyW,'year':csoJLSRdkNEtmXwATOKpnYjxVavuyh,'aired':csoJLSRdkNEtmXwATOKpnYjxVavuyD,'plot':'%s\n\n%s'%(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,csoJLSRdkNEtmXwATOKpnYjxVavuWF)}
   if csoJLSRdkNEtmXwATOKpnYjxVavuWB=='vod':
    csoJLSRdkNEtmXwATOKpnYjxVavulG=csoJLSRdkNEtmXwATOKpnYjxVavubW.get('program')
    csoJLSRdkNEtmXwATOKpnYjxVavulg='tvshow'
    csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'EPISODE','programcode':csoJLSRdkNEtmXwATOKpnYjxVavulG,'page':'1',}
    csoJLSRdkNEtmXwATOKpnYjxVavuhD=csoJLSRdkNEtmXwATOKpnYjxVavuGF
   else:
    csoJLSRdkNEtmXwATOKpnYjxVavulG=csoJLSRdkNEtmXwATOKpnYjxVavubW.get('movie')
    csoJLSRdkNEtmXwATOKpnYjxVavulg='movie'
    csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'MOVIE','mediacode':csoJLSRdkNEtmXwATOKpnYjxVavulG,'stype':'movie','title':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'thumbnail':csoJLSRdkNEtmXwATOKpnYjxVavuWP,}
    csoJLSRdkNEtmXwATOKpnYjxVavuhD=csoJLSRdkNEtmXwATOKpnYjxVavuGI
   if csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_makebookmark():
    csoJLSRdkNEtmXwATOKpnYjxVavuye={'videoid':csoJLSRdkNEtmXwATOKpnYjxVavulG,'vidtype':csoJLSRdkNEtmXwATOKpnYjxVavulg,'vtitle':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'vsubtitle':'',}
    csoJLSRdkNEtmXwATOKpnYjxVavuyr=json.dumps(csoJLSRdkNEtmXwATOKpnYjxVavuye)
    csoJLSRdkNEtmXwATOKpnYjxVavuyr=urllib.parse.quote(csoJLSRdkNEtmXwATOKpnYjxVavuyr)
    csoJLSRdkNEtmXwATOKpnYjxVavuyQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(csoJLSRdkNEtmXwATOKpnYjxVavuyr)
    csoJLSRdkNEtmXwATOKpnYjxVavuyf=[('(통합) 찜 영상에 추가',csoJLSRdkNEtmXwATOKpnYjxVavuyQ)]
   else:
    csoJLSRdkNEtmXwATOKpnYjxVavuyf=csoJLSRdkNEtmXwATOKpnYjxVavuGM
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel='',img=csoJLSRdkNEtmXwATOKpnYjxVavuWP,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuyb,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuhD,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC,isLink=csoJLSRdkNEtmXwATOKpnYjxVavuGI,ContextMenu=csoJLSRdkNEtmXwATOKpnYjxVavuyf)
  if csoJLSRdkNEtmXwATOKpnYjxVavuWq:
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['mode'] ='SEARCH' 
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['search_key']=csoJLSRdkNEtmXwATOKpnYjxVavulr
   csoJLSRdkNEtmXwATOKpnYjxVavuhC['page'] =csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ='[B]%s >>[/B]'%'다음 페이지'
   csoJLSRdkNEtmXwATOKpnYjxVavuyz=csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuWQ+1)
   csoJLSRdkNEtmXwATOKpnYjxVavuhI=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuyz,img=csoJLSRdkNEtmXwATOKpnYjxVavuhI,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  if csoJLSRdkNEtmXwATOKpnYjxVavuWB=='movie':xbmcplugin.setContent(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,'movies')
  else:xbmcplugin.setContent(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,cacheToDisc=csoJLSRdkNEtmXwATOKpnYjxVavuGI)
 def dp_History_Remove(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavubl=csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('delType')
  csoJLSRdkNEtmXwATOKpnYjxVavubz =csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('sKey')
  csoJLSRdkNEtmXwATOKpnYjxVavubG =csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('vType')
  csoJLSRdkNEtmXwATOKpnYjxVavuiq=xbmcgui.Dialog()
  if csoJLSRdkNEtmXwATOKpnYjxVavubl=='SEARCH_ALL':
   csoJLSRdkNEtmXwATOKpnYjxVavuWG=csoJLSRdkNEtmXwATOKpnYjxVavuiq.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif csoJLSRdkNEtmXwATOKpnYjxVavubl=='SEARCH_ONE':
   csoJLSRdkNEtmXwATOKpnYjxVavuWG=csoJLSRdkNEtmXwATOKpnYjxVavuiq.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif csoJLSRdkNEtmXwATOKpnYjxVavubl=='WATCH_ALL':
   csoJLSRdkNEtmXwATOKpnYjxVavuWG=csoJLSRdkNEtmXwATOKpnYjxVavuiq.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif csoJLSRdkNEtmXwATOKpnYjxVavubl=='WATCH_ONE':
   csoJLSRdkNEtmXwATOKpnYjxVavuWG=csoJLSRdkNEtmXwATOKpnYjxVavuiq.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if csoJLSRdkNEtmXwATOKpnYjxVavuWG==csoJLSRdkNEtmXwATOKpnYjxVavuGI:sys.exit()
  if csoJLSRdkNEtmXwATOKpnYjxVavubl=='SEARCH_ALL':
   if os.path.isfile(csoJLSRdkNEtmXwATOKpnYjxVavuiB):os.remove(csoJLSRdkNEtmXwATOKpnYjxVavuiB)
  elif csoJLSRdkNEtmXwATOKpnYjxVavubl=='SEARCH_ONE':
   try:
    csoJLSRdkNEtmXwATOKpnYjxVavubg=csoJLSRdkNEtmXwATOKpnYjxVavuiB
    csoJLSRdkNEtmXwATOKpnYjxVavubU=csoJLSRdkNEtmXwATOKpnYjxVavuiH.Load_List_File('search') 
    fp=csoJLSRdkNEtmXwATOKpnYjxVavugy(csoJLSRdkNEtmXwATOKpnYjxVavubg,'w',-1,'utf-8')
    for csoJLSRdkNEtmXwATOKpnYjxVavubB in csoJLSRdkNEtmXwATOKpnYjxVavubU:
     csoJLSRdkNEtmXwATOKpnYjxVavubH=csoJLSRdkNEtmXwATOKpnYjxVavuGD(urllib.parse.parse_qsl(csoJLSRdkNEtmXwATOKpnYjxVavubB))
     csoJLSRdkNEtmXwATOKpnYjxVavube=csoJLSRdkNEtmXwATOKpnYjxVavubH.get('skey').strip()
     if csoJLSRdkNEtmXwATOKpnYjxVavubz!=csoJLSRdkNEtmXwATOKpnYjxVavube:
      fp.write(csoJLSRdkNEtmXwATOKpnYjxVavubB)
    fp.close()
   except:
    csoJLSRdkNEtmXwATOKpnYjxVavuGM
  elif csoJLSRdkNEtmXwATOKpnYjxVavubl=='WATCH_ALL':
   csoJLSRdkNEtmXwATOKpnYjxVavubg=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%csoJLSRdkNEtmXwATOKpnYjxVavubG))
   if os.path.isfile(csoJLSRdkNEtmXwATOKpnYjxVavubg):os.remove(csoJLSRdkNEtmXwATOKpnYjxVavubg)
  elif csoJLSRdkNEtmXwATOKpnYjxVavubl=='WATCH_ONE':
   csoJLSRdkNEtmXwATOKpnYjxVavubg=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%csoJLSRdkNEtmXwATOKpnYjxVavubG))
   try:
    csoJLSRdkNEtmXwATOKpnYjxVavubU=csoJLSRdkNEtmXwATOKpnYjxVavuiH.Load_List_File(csoJLSRdkNEtmXwATOKpnYjxVavubG) 
    fp=csoJLSRdkNEtmXwATOKpnYjxVavugy(csoJLSRdkNEtmXwATOKpnYjxVavubg,'w',-1,'utf-8')
    for csoJLSRdkNEtmXwATOKpnYjxVavubB in csoJLSRdkNEtmXwATOKpnYjxVavubU:
     csoJLSRdkNEtmXwATOKpnYjxVavubH=csoJLSRdkNEtmXwATOKpnYjxVavuGD(urllib.parse.parse_qsl(csoJLSRdkNEtmXwATOKpnYjxVavubB))
     csoJLSRdkNEtmXwATOKpnYjxVavube=csoJLSRdkNEtmXwATOKpnYjxVavubH.get('code').strip()
     if csoJLSRdkNEtmXwATOKpnYjxVavubz!=csoJLSRdkNEtmXwATOKpnYjxVavube:
      fp.write(csoJLSRdkNEtmXwATOKpnYjxVavubB)
    fp.close()
   except:
    csoJLSRdkNEtmXwATOKpnYjxVavuGM
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWB): 
  try:
   if csoJLSRdkNEtmXwATOKpnYjxVavuWB=='search':
    csoJLSRdkNEtmXwATOKpnYjxVavubg=csoJLSRdkNEtmXwATOKpnYjxVavuiB
   elif csoJLSRdkNEtmXwATOKpnYjxVavuWB in['vod','movie']:
    csoJLSRdkNEtmXwATOKpnYjxVavubg=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%csoJLSRdkNEtmXwATOKpnYjxVavuWB))
   else:
    return[]
   fp=csoJLSRdkNEtmXwATOKpnYjxVavugy(csoJLSRdkNEtmXwATOKpnYjxVavubg,'r',-1,'utf-8')
   csoJLSRdkNEtmXwATOKpnYjxVavubr=fp.readlines()
   fp.close()
  except:
   csoJLSRdkNEtmXwATOKpnYjxVavubr=[]
  return csoJLSRdkNEtmXwATOKpnYjxVavubr
 def Save_Watched_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWB,csoJLSRdkNEtmXwATOKpnYjxVavuiQ):
  try:
   csoJLSRdkNEtmXwATOKpnYjxVavubQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%csoJLSRdkNEtmXwATOKpnYjxVavuWB))
   csoJLSRdkNEtmXwATOKpnYjxVavubU=csoJLSRdkNEtmXwATOKpnYjxVavuiH.Load_List_File(csoJLSRdkNEtmXwATOKpnYjxVavuWB) 
   fp=csoJLSRdkNEtmXwATOKpnYjxVavugy(csoJLSRdkNEtmXwATOKpnYjxVavubQ,'w',-1,'utf-8')
   csoJLSRdkNEtmXwATOKpnYjxVavubf=urllib.parse.urlencode(csoJLSRdkNEtmXwATOKpnYjxVavuiQ)
   csoJLSRdkNEtmXwATOKpnYjxVavubf=csoJLSRdkNEtmXwATOKpnYjxVavubf+'\n'
   fp.write(csoJLSRdkNEtmXwATOKpnYjxVavubf)
   csoJLSRdkNEtmXwATOKpnYjxVavubq=0
   for csoJLSRdkNEtmXwATOKpnYjxVavubB in csoJLSRdkNEtmXwATOKpnYjxVavubU:
    csoJLSRdkNEtmXwATOKpnYjxVavubH=csoJLSRdkNEtmXwATOKpnYjxVavuGD(urllib.parse.parse_qsl(csoJLSRdkNEtmXwATOKpnYjxVavubB))
    csoJLSRdkNEtmXwATOKpnYjxVavubM=csoJLSRdkNEtmXwATOKpnYjxVavuiQ.get('code').strip()
    csoJLSRdkNEtmXwATOKpnYjxVavubP=csoJLSRdkNEtmXwATOKpnYjxVavubH.get('code').strip()
    if csoJLSRdkNEtmXwATOKpnYjxVavuWB=='vod' and csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_direct_replay()==csoJLSRdkNEtmXwATOKpnYjxVavuGF:
     csoJLSRdkNEtmXwATOKpnYjxVavubM=csoJLSRdkNEtmXwATOKpnYjxVavuiQ.get('videoid').strip()
     csoJLSRdkNEtmXwATOKpnYjxVavubP=csoJLSRdkNEtmXwATOKpnYjxVavubH.get('videoid').strip()if csoJLSRdkNEtmXwATOKpnYjxVavubP!=csoJLSRdkNEtmXwATOKpnYjxVavuGM else '-'
    if csoJLSRdkNEtmXwATOKpnYjxVavubM!=csoJLSRdkNEtmXwATOKpnYjxVavubP:
     fp.write(csoJLSRdkNEtmXwATOKpnYjxVavubB)
     csoJLSRdkNEtmXwATOKpnYjxVavubq+=1
     if csoJLSRdkNEtmXwATOKpnYjxVavubq>=50:break
   fp.close()
  except:
   csoJLSRdkNEtmXwATOKpnYjxVavuGM
 def dp_Watch_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuWB =csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('stype')
  csoJLSRdkNEtmXwATOKpnYjxVavuhB=csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_direct_replay()
  if csoJLSRdkNEtmXwATOKpnYjxVavuWB=='-':
   for csoJLSRdkNEtmXwATOKpnYjxVavuWe in csoJLSRdkNEtmXwATOKpnYjxVavuil:
    csoJLSRdkNEtmXwATOKpnYjxVavuhQ=csoJLSRdkNEtmXwATOKpnYjxVavuWe.get('title')
    csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':csoJLSRdkNEtmXwATOKpnYjxVavuWe.get('mode'),'stype':csoJLSRdkNEtmXwATOKpnYjxVavuWe.get('stype')}
    csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel='',img='',infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuGM,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGF,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
   if csoJLSRdkNEtmXwATOKpnYjxVavugi(csoJLSRdkNEtmXwATOKpnYjxVavuil)>0:xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle)
  else:
   csoJLSRdkNEtmXwATOKpnYjxVavubF=csoJLSRdkNEtmXwATOKpnYjxVavuiH.Load_List_File(csoJLSRdkNEtmXwATOKpnYjxVavuWB)
   for csoJLSRdkNEtmXwATOKpnYjxVavubI in csoJLSRdkNEtmXwATOKpnYjxVavubF:
    csoJLSRdkNEtmXwATOKpnYjxVavulC=csoJLSRdkNEtmXwATOKpnYjxVavuGD(urllib.parse.parse_qsl(csoJLSRdkNEtmXwATOKpnYjxVavubI))
    csoJLSRdkNEtmXwATOKpnYjxVavubC =csoJLSRdkNEtmXwATOKpnYjxVavulC.get('code').strip()
    csoJLSRdkNEtmXwATOKpnYjxVavuhQ =csoJLSRdkNEtmXwATOKpnYjxVavulC.get('title').strip()
    csoJLSRdkNEtmXwATOKpnYjxVavuWP=csoJLSRdkNEtmXwATOKpnYjxVavulC.get('img').strip()
    csoJLSRdkNEtmXwATOKpnYjxVavulG =csoJLSRdkNEtmXwATOKpnYjxVavulC.get('videoid').strip()
    try:
     csoJLSRdkNEtmXwATOKpnYjxVavuWP=csoJLSRdkNEtmXwATOKpnYjxVavuWP.replace('\'','\"')
     csoJLSRdkNEtmXwATOKpnYjxVavuWP=json.loads(csoJLSRdkNEtmXwATOKpnYjxVavuWP)
    except:
     csoJLSRdkNEtmXwATOKpnYjxVavuGM
    csoJLSRdkNEtmXwATOKpnYjxVavuyb={}
    csoJLSRdkNEtmXwATOKpnYjxVavuyb['plot']=csoJLSRdkNEtmXwATOKpnYjxVavuhQ
    if csoJLSRdkNEtmXwATOKpnYjxVavuWB=='vod':
     if csoJLSRdkNEtmXwATOKpnYjxVavuhB==csoJLSRdkNEtmXwATOKpnYjxVavuGI or csoJLSRdkNEtmXwATOKpnYjxVavulG==csoJLSRdkNEtmXwATOKpnYjxVavuGM:
      csoJLSRdkNEtmXwATOKpnYjxVavuyb['mediatype']='tvshow'
      csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'EPISODE','programcode':csoJLSRdkNEtmXwATOKpnYjxVavubC,'page':'1'}
      csoJLSRdkNEtmXwATOKpnYjxVavuhD=csoJLSRdkNEtmXwATOKpnYjxVavuGF
     else:
      csoJLSRdkNEtmXwATOKpnYjxVavuyb['mediatype']='episode'
      csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'VOD','mediacode':csoJLSRdkNEtmXwATOKpnYjxVavulG,'stype':'vod','programcode':csoJLSRdkNEtmXwATOKpnYjxVavubC,'title':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'thumbnail':csoJLSRdkNEtmXwATOKpnYjxVavuWP}
      csoJLSRdkNEtmXwATOKpnYjxVavuhD=csoJLSRdkNEtmXwATOKpnYjxVavuGI
    else:
     csoJLSRdkNEtmXwATOKpnYjxVavuyb['mediatype']='movie'
     csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'MOVIE','mediacode':csoJLSRdkNEtmXwATOKpnYjxVavubC,'stype':'movie','title':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'thumbnail':csoJLSRdkNEtmXwATOKpnYjxVavuWP}
     csoJLSRdkNEtmXwATOKpnYjxVavuhD=csoJLSRdkNEtmXwATOKpnYjxVavuGI
    csoJLSRdkNEtmXwATOKpnYjxVavubi={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':csoJLSRdkNEtmXwATOKpnYjxVavubC,'vType':csoJLSRdkNEtmXwATOKpnYjxVavuWB,}
    csoJLSRdkNEtmXwATOKpnYjxVavubh=urllib.parse.urlencode(csoJLSRdkNEtmXwATOKpnYjxVavubi)
    csoJLSRdkNEtmXwATOKpnYjxVavuyf=[('선택된 시청이력 ( %s ) 삭제'%(csoJLSRdkNEtmXwATOKpnYjxVavuhQ),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(csoJLSRdkNEtmXwATOKpnYjxVavubh))]
    csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel='',img=csoJLSRdkNEtmXwATOKpnYjxVavuWP,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuyb,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuhD,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC,ContextMenu=csoJLSRdkNEtmXwATOKpnYjxVavuyf)
   csoJLSRdkNEtmXwATOKpnYjxVavuyb={'plot':'시청목록을 삭제합니다.'}
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':csoJLSRdkNEtmXwATOKpnYjxVavuWB,}
   csoJLSRdkNEtmXwATOKpnYjxVavuhI=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel='',img=csoJLSRdkNEtmXwATOKpnYjxVavuhI,infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuyb,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGI,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC,isLink=csoJLSRdkNEtmXwATOKpnYjxVavuGF)
   if csoJLSRdkNEtmXwATOKpnYjxVavuWB=='movie':xbmcplugin.setContent(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,'movies')
   else:xbmcplugin.setContent(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,cacheToDisc=csoJLSRdkNEtmXwATOKpnYjxVavuGI)
 def Save_Searched_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavulr):
  try:
   csoJLSRdkNEtmXwATOKpnYjxVavubD=csoJLSRdkNEtmXwATOKpnYjxVavuiB
   csoJLSRdkNEtmXwATOKpnYjxVavubU=csoJLSRdkNEtmXwATOKpnYjxVavuiH.Load_List_File('search') 
   csoJLSRdkNEtmXwATOKpnYjxVavuzi={'skey':csoJLSRdkNEtmXwATOKpnYjxVavulr.strip()}
   fp=csoJLSRdkNEtmXwATOKpnYjxVavugy(csoJLSRdkNEtmXwATOKpnYjxVavubD,'w',-1,'utf-8')
   csoJLSRdkNEtmXwATOKpnYjxVavubf=urllib.parse.urlencode(csoJLSRdkNEtmXwATOKpnYjxVavuzi)
   csoJLSRdkNEtmXwATOKpnYjxVavubf=csoJLSRdkNEtmXwATOKpnYjxVavubf+'\n'
   fp.write(csoJLSRdkNEtmXwATOKpnYjxVavubf)
   csoJLSRdkNEtmXwATOKpnYjxVavubq=0
   for csoJLSRdkNEtmXwATOKpnYjxVavubB in csoJLSRdkNEtmXwATOKpnYjxVavubU:
    csoJLSRdkNEtmXwATOKpnYjxVavubH=csoJLSRdkNEtmXwATOKpnYjxVavuGD(urllib.parse.parse_qsl(csoJLSRdkNEtmXwATOKpnYjxVavubB))
    csoJLSRdkNEtmXwATOKpnYjxVavubM=csoJLSRdkNEtmXwATOKpnYjxVavuzi.get('skey').strip()
    csoJLSRdkNEtmXwATOKpnYjxVavubP=csoJLSRdkNEtmXwATOKpnYjxVavubH.get('skey').strip()
    if csoJLSRdkNEtmXwATOKpnYjxVavubM!=csoJLSRdkNEtmXwATOKpnYjxVavubP:
     fp.write(csoJLSRdkNEtmXwATOKpnYjxVavubB)
     csoJLSRdkNEtmXwATOKpnYjxVavubq+=1
     if csoJLSRdkNEtmXwATOKpnYjxVavubq>=50:break
   fp.close()
  except:
   csoJLSRdkNEtmXwATOKpnYjxVavuGM
 def play_VIDEO(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuzh =csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('mediacode')
  csoJLSRdkNEtmXwATOKpnYjxVavuWB =csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('stype')
  csoJLSRdkNEtmXwATOKpnYjxVavuzW =csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('pvrmode')
  csoJLSRdkNEtmXwATOKpnYjxVavuzy=csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_selQuality(csoJLSRdkNEtmXwATOKpnYjxVavuWB)
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(csoJLSRdkNEtmXwATOKpnYjxVavuzh,csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuzy),csoJLSRdkNEtmXwATOKpnYjxVavuWB,csoJLSRdkNEtmXwATOKpnYjxVavuzW))
  csoJLSRdkNEtmXwATOKpnYjxVavuzl=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.GetBroadURL(csoJLSRdkNEtmXwATOKpnYjxVavuzh,csoJLSRdkNEtmXwATOKpnYjxVavuzy,csoJLSRdkNEtmXwATOKpnYjxVavuWB,csoJLSRdkNEtmXwATOKpnYjxVavuzW,optUHD=csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_uhd())
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.addon_log('qt, stype, url : %s - %s - %s'%(csoJLSRdkNEtmXwATOKpnYjxVavugh(csoJLSRdkNEtmXwATOKpnYjxVavuzy),csoJLSRdkNEtmXwATOKpnYjxVavuWB,csoJLSRdkNEtmXwATOKpnYjxVavuzl['streaming_url']))
  if csoJLSRdkNEtmXwATOKpnYjxVavuzl['streaming_url']=='':
   if csoJLSRdkNEtmXwATOKpnYjxVavuzl['error_msg']=='':
    csoJLSRdkNEtmXwATOKpnYjxVavuiH.addon_noti(__language__(30908).encode('utf8'))
   else:
    csoJLSRdkNEtmXwATOKpnYjxVavuiH.addon_noti(csoJLSRdkNEtmXwATOKpnYjxVavuzl['error_msg'].encode('utf8'))
   return
  csoJLSRdkNEtmXwATOKpnYjxVavuzb='user-agent={}'.format(csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.USER_AGENT)
  if csoJLSRdkNEtmXwATOKpnYjxVavuzl['watermark'] !='':
   csoJLSRdkNEtmXwATOKpnYjxVavuzb='{}&x-tving-param1={}&x-tving-param2={}'.format(csoJLSRdkNEtmXwATOKpnYjxVavuzb,csoJLSRdkNEtmXwATOKpnYjxVavuzl['watermarkKey'],csoJLSRdkNEtmXwATOKpnYjxVavuzl['watermark'])
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.addon_log('streaming_url = {}'.format(csoJLSRdkNEtmXwATOKpnYjxVavuzl['streaming_url']))
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.addon_log('watermark     = {}'.format(csoJLSRdkNEtmXwATOKpnYjxVavuzl['watermark']))
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.addon_log('watermarkKey  = {}'.format(csoJLSRdkNEtmXwATOKpnYjxVavuzl['watermarkKey']))
  csoJLSRdkNEtmXwATOKpnYjxVavuzG =csoJLSRdkNEtmXwATOKpnYjxVavuGI
  csoJLSRdkNEtmXwATOKpnYjxVavuzg =csoJLSRdkNEtmXwATOKpnYjxVavuzl['streaming_url'].find('Policy=')
  if csoJLSRdkNEtmXwATOKpnYjxVavuzg!=-1:
   csoJLSRdkNEtmXwATOKpnYjxVavuzU =csoJLSRdkNEtmXwATOKpnYjxVavuzl['streaming_url'].split('?')[0]
   csoJLSRdkNEtmXwATOKpnYjxVavuzB=csoJLSRdkNEtmXwATOKpnYjxVavuGD(urllib.parse.parse_qsl(urllib.parse.urlsplit(csoJLSRdkNEtmXwATOKpnYjxVavuzl['streaming_url']).query))
   csoJLSRdkNEtmXwATOKpnYjxVavuzH='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(csoJLSRdkNEtmXwATOKpnYjxVavuzB['Policy'],csoJLSRdkNEtmXwATOKpnYjxVavuzB['Signature'],csoJLSRdkNEtmXwATOKpnYjxVavuzB['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in csoJLSRdkNEtmXwATOKpnYjxVavuzU:
    csoJLSRdkNEtmXwATOKpnYjxVavuzG=csoJLSRdkNEtmXwATOKpnYjxVavuGF
    csoJLSRdkNEtmXwATOKpnYjxVavuze =csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    csoJLSRdkNEtmXwATOKpnYjxVavuzr=csoJLSRdkNEtmXwATOKpnYjxVavuze.strftime('%Y-%m-%d-%H:%M:%S')
    if csoJLSRdkNEtmXwATOKpnYjxVavuGP(csoJLSRdkNEtmXwATOKpnYjxVavuzr.replace('-','').replace(':',''))<csoJLSRdkNEtmXwATOKpnYjxVavuGP(csoJLSRdkNEtmXwATOKpnYjxVavuzB['end'].replace('-','').replace(':','')):
     csoJLSRdkNEtmXwATOKpnYjxVavuzB['end']=csoJLSRdkNEtmXwATOKpnYjxVavuzr
     csoJLSRdkNEtmXwATOKpnYjxVavuiH.addon_noti(__language__(30915).encode('utf8'))
    csoJLSRdkNEtmXwATOKpnYjxVavuzU ='%s?%s'%(csoJLSRdkNEtmXwATOKpnYjxVavuzU,urllib.parse.urlencode(csoJLSRdkNEtmXwATOKpnYjxVavuzB,doseq=csoJLSRdkNEtmXwATOKpnYjxVavuGF))
    csoJLSRdkNEtmXwATOKpnYjxVavuzQ='{}|{}&Cookie={}'.format(csoJLSRdkNEtmXwATOKpnYjxVavuzU,csoJLSRdkNEtmXwATOKpnYjxVavuzb,csoJLSRdkNEtmXwATOKpnYjxVavuzH)
   else:
    csoJLSRdkNEtmXwATOKpnYjxVavuzQ='{}|{}&Cookie={}'.format(csoJLSRdkNEtmXwATOKpnYjxVavuzl['streaming_url'],csoJLSRdkNEtmXwATOKpnYjxVavuzb,csoJLSRdkNEtmXwATOKpnYjxVavuzH)
  else:
   csoJLSRdkNEtmXwATOKpnYjxVavuzQ=csoJLSRdkNEtmXwATOKpnYjxVavuzl['streaming_url']+'|'+csoJLSRdkNEtmXwATOKpnYjxVavuzb
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.addon_log('if tmp_pos == -1')
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.addon_log(csoJLSRdkNEtmXwATOKpnYjxVavuzQ)
  csoJLSRdkNEtmXwATOKpnYjxVavuhy,csoJLSRdkNEtmXwATOKpnYjxVavuhl=csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_proxyport()
  csoJLSRdkNEtmXwATOKpnYjxVavuhW=csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_playback()
  if csoJLSRdkNEtmXwATOKpnYjxVavuhy and csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('mode')in['VOD','MOVIE']and csoJLSRdkNEtmXwATOKpnYjxVavuzl['subtitleYn']==csoJLSRdkNEtmXwATOKpnYjxVavuGF and csoJLSRdkNEtmXwATOKpnYjxVavuzl['drm_license']!='':
   try:
    csoJLSRdkNEtmXwATOKpnYjxVavuzf=urllib.parse.urlparse(csoJLSRdkNEtmXwATOKpnYjxVavuzQ)
    csoJLSRdkNEtmXwATOKpnYjxVavuzq=csoJLSRdkNEtmXwATOKpnYjxVavuzf.scheme
    csoJLSRdkNEtmXwATOKpnYjxVavuzM=csoJLSRdkNEtmXwATOKpnYjxVavuzf.netloc
   except:
    csoJLSRdkNEtmXwATOKpnYjxVavuzq=''
    csoJLSRdkNEtmXwATOKpnYjxVavuzM=''
   csoJLSRdkNEtmXwATOKpnYjxVavuzP={'addon':'tvingm','playOption':csoJLSRdkNEtmXwATOKpnYjxVavuhW,'defScheme':csoJLSRdkNEtmXwATOKpnYjxVavuzq,'defNetloc':csoJLSRdkNEtmXwATOKpnYjxVavuzM,}
   csoJLSRdkNEtmXwATOKpnYjxVavuzP=json.dumps(csoJLSRdkNEtmXwATOKpnYjxVavuzP,separators=(',',':'))
   csoJLSRdkNEtmXwATOKpnYjxVavuzP=base64.standard_b64encode(csoJLSRdkNEtmXwATOKpnYjxVavuzP.encode()).decode('utf-8')
   csoJLSRdkNEtmXwATOKpnYjxVavuzQ ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(csoJLSRdkNEtmXwATOKpnYjxVavuhl,csoJLSRdkNEtmXwATOKpnYjxVavuzQ,csoJLSRdkNEtmXwATOKpnYjxVavuzP)
   csoJLSRdkNEtmXwATOKpnYjxVavuzb='{}&proxy-mini={}'.format(csoJLSRdkNEtmXwATOKpnYjxVavuzb,csoJLSRdkNEtmXwATOKpnYjxVavuzP)
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.addon_log(csoJLSRdkNEtmXwATOKpnYjxVavuzQ)
  csoJLSRdkNEtmXwATOKpnYjxVavuzF=xbmcgui.ListItem(path=csoJLSRdkNEtmXwATOKpnYjxVavuzQ)
  if csoJLSRdkNEtmXwATOKpnYjxVavuzl['drm_license']!='':
   csoJLSRdkNEtmXwATOKpnYjxVavuzI=csoJLSRdkNEtmXwATOKpnYjxVavuzl['drm_license']
   csoJLSRdkNEtmXwATOKpnYjxVavuzC ='https://cj.drmkeyserver.com/widevine_license'
   csoJLSRdkNEtmXwATOKpnYjxVavuzD ='mpd'
   csoJLSRdkNEtmXwATOKpnYjxVavuGi ='com.widevine.alpha'
   csoJLSRdkNEtmXwATOKpnYjxVavuGh =inputstreamhelper.Helper(csoJLSRdkNEtmXwATOKpnYjxVavuzD,drm='widevine')
   if csoJLSRdkNEtmXwATOKpnYjxVavuGh.check_inputstream():
    csoJLSRdkNEtmXwATOKpnYjxVavuGW={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.USER_AGENT,'AcquireLicenseAssertion':csoJLSRdkNEtmXwATOKpnYjxVavuzI,'Host':'cj.drmkeyserver.com',}
    csoJLSRdkNEtmXwATOKpnYjxVavuGy=csoJLSRdkNEtmXwATOKpnYjxVavuzC+'|'+urllib.parse.urlencode(csoJLSRdkNEtmXwATOKpnYjxVavuGW)+'|R{SSM}|'
    csoJLSRdkNEtmXwATOKpnYjxVavuzF.setProperty('inputstream',csoJLSRdkNEtmXwATOKpnYjxVavuGh.inputstream_addon)
    csoJLSRdkNEtmXwATOKpnYjxVavuzF.setProperty('inputstream.adaptive.manifest_type',csoJLSRdkNEtmXwATOKpnYjxVavuzD)
    csoJLSRdkNEtmXwATOKpnYjxVavuzF.setProperty('inputstream.adaptive.license_type',csoJLSRdkNEtmXwATOKpnYjxVavuGi)
    csoJLSRdkNEtmXwATOKpnYjxVavuzF.setProperty('inputstream.adaptive.license_key',csoJLSRdkNEtmXwATOKpnYjxVavuGy)
    csoJLSRdkNEtmXwATOKpnYjxVavuzF.setProperty('inputstream.adaptive.stream_headers',csoJLSRdkNEtmXwATOKpnYjxVavuzb)
  elif csoJLSRdkNEtmXwATOKpnYjxVavuzG==csoJLSRdkNEtmXwATOKpnYjxVavuGF:
   csoJLSRdkNEtmXwATOKpnYjxVavuzF.setContentLookup(csoJLSRdkNEtmXwATOKpnYjxVavuGI)
   csoJLSRdkNEtmXwATOKpnYjxVavuzF.setMimeType('application/x-mpegURL')
   csoJLSRdkNEtmXwATOKpnYjxVavuzF.setProperty('inputstream','inputstream.ffmpegdirect')
   csoJLSRdkNEtmXwATOKpnYjxVavuzF.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   csoJLSRdkNEtmXwATOKpnYjxVavuzF.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   csoJLSRdkNEtmXwATOKpnYjxVavuzF.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   csoJLSRdkNEtmXwATOKpnYjxVavuzF.setProperty('ResumeTime','0')
   csoJLSRdkNEtmXwATOKpnYjxVavuzF.setProperty('TotalTime','10000')
  elif csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('mode')in['VOD','MOVIE']:
   csoJLSRdkNEtmXwATOKpnYjxVavuzF.setContentLookup(csoJLSRdkNEtmXwATOKpnYjxVavuGI)
   csoJLSRdkNEtmXwATOKpnYjxVavuzF.setMimeType('application/x-mpegURL')
   csoJLSRdkNEtmXwATOKpnYjxVavuzF.setProperty('inputstream','inputstream.adaptive')
   csoJLSRdkNEtmXwATOKpnYjxVavuzF.setProperty('inputstream.adaptive.manifest_type','hls')
  xbmcplugin.setResolvedUrl(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,csoJLSRdkNEtmXwATOKpnYjxVavuGF,csoJLSRdkNEtmXwATOKpnYjxVavuzF)
  try:
   if csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('mode')in['VOD','MOVIE']and csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('title'):
    csoJLSRdkNEtmXwATOKpnYjxVavuhC={'code':csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('programcode')if csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('mode')=='VOD' else csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('mediacode'),'img':csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('thumbnail'),'title':csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('title'),'videoid':csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('mediacode')}
    csoJLSRdkNEtmXwATOKpnYjxVavuiH.Save_Watched_List(csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('stype'),csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  except:
   csoJLSRdkNEtmXwATOKpnYjxVavuGM
 def logout(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  csoJLSRdkNEtmXwATOKpnYjxVavuiq=xbmcgui.Dialog()
  csoJLSRdkNEtmXwATOKpnYjxVavuWG=csoJLSRdkNEtmXwATOKpnYjxVavuiq.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if csoJLSRdkNEtmXwATOKpnYjxVavuWG==csoJLSRdkNEtmXwATOKpnYjxVavuGI:sys.exit()
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.Init_TV_Total()
  if os.path.isfile(csoJLSRdkNEtmXwATOKpnYjxVavuiU):os.remove(csoJLSRdkNEtmXwATOKpnYjxVavuiU)
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  csoJLSRdkNEtmXwATOKpnYjxVavuGl =csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.Get_Now_Datetime()
  csoJLSRdkNEtmXwATOKpnYjxVavuGb=csoJLSRdkNEtmXwATOKpnYjxVavuGl+datetime.timedelta(days=csoJLSRdkNEtmXwATOKpnYjxVavuGP(__addon__.getSetting('cache_ttl')))
  (csoJLSRdkNEtmXwATOKpnYjxVavuWy,csoJLSRdkNEtmXwATOKpnYjxVavuWl,csoJLSRdkNEtmXwATOKpnYjxVavuWb,csoJLSRdkNEtmXwATOKpnYjxVavuWz)=csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_account()
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.Save_session_acount(csoJLSRdkNEtmXwATOKpnYjxVavuWy,csoJLSRdkNEtmXwATOKpnYjxVavuWl,csoJLSRdkNEtmXwATOKpnYjxVavuWb,csoJLSRdkNEtmXwATOKpnYjxVavuWz)
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.TV['account']['token_limit']=csoJLSRdkNEtmXwATOKpnYjxVavuGb.strftime('%Y%m%d')
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.JsonFile_Save(csoJLSRdkNEtmXwATOKpnYjxVavuiU,csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.TV)
 def cookiefile_check(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.TV=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.JsonFile_Load(csoJLSRdkNEtmXwATOKpnYjxVavuiU)
  if 'account' not in csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.TV:
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.Init_TV_Total()
   return csoJLSRdkNEtmXwATOKpnYjxVavuGI
  (csoJLSRdkNEtmXwATOKpnYjxVavuGz,csoJLSRdkNEtmXwATOKpnYjxVavuGg,csoJLSRdkNEtmXwATOKpnYjxVavuGU,csoJLSRdkNEtmXwATOKpnYjxVavuGB)=csoJLSRdkNEtmXwATOKpnYjxVavuiH.get_settings_account()
  (csoJLSRdkNEtmXwATOKpnYjxVavuGH,csoJLSRdkNEtmXwATOKpnYjxVavuGe,csoJLSRdkNEtmXwATOKpnYjxVavuGr,csoJLSRdkNEtmXwATOKpnYjxVavuGQ)=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.Load_session_acount()
  if csoJLSRdkNEtmXwATOKpnYjxVavuGz!=csoJLSRdkNEtmXwATOKpnYjxVavuGH or csoJLSRdkNEtmXwATOKpnYjxVavuGg!=csoJLSRdkNEtmXwATOKpnYjxVavuGe or csoJLSRdkNEtmXwATOKpnYjxVavuGU!=csoJLSRdkNEtmXwATOKpnYjxVavuGr or csoJLSRdkNEtmXwATOKpnYjxVavuGB!=csoJLSRdkNEtmXwATOKpnYjxVavuGQ:
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.Init_TV_Total()
   return csoJLSRdkNEtmXwATOKpnYjxVavuGI
  if csoJLSRdkNEtmXwATOKpnYjxVavuGP(csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>csoJLSRdkNEtmXwATOKpnYjxVavuGP(csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.TV['account']['token_limit']):
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.Init_TV_Total()
   return csoJLSRdkNEtmXwATOKpnYjxVavuGI
  return csoJLSRdkNEtmXwATOKpnYjxVavuGF
 def dp_Global_Search(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavulQ=csoJLSRdkNEtmXwATOKpnYjxVavuWr.get('mode')
  if csoJLSRdkNEtmXwATOKpnYjxVavulQ=='TOTAL_SEARCH':
   csoJLSRdkNEtmXwATOKpnYjxVavuGf='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   csoJLSRdkNEtmXwATOKpnYjxVavuGf='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(csoJLSRdkNEtmXwATOKpnYjxVavuGf)
 def dp_Bookmark_Menu(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuGf='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(csoJLSRdkNEtmXwATOKpnYjxVavuGf)
 def dp_EuroLive_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH,csoJLSRdkNEtmXwATOKpnYjxVavuWr):
  csoJLSRdkNEtmXwATOKpnYjxVavuWf=csoJLSRdkNEtmXwATOKpnYjxVavuiH.TvingObj.GetEuroChannelList()
  for csoJLSRdkNEtmXwATOKpnYjxVavuWM in csoJLSRdkNEtmXwATOKpnYjxVavuWf:
   csoJLSRdkNEtmXwATOKpnYjxVavuyH =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('channel')
   csoJLSRdkNEtmXwATOKpnYjxVavuhQ =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('title')
   csoJLSRdkNEtmXwATOKpnYjxVavuyz =csoJLSRdkNEtmXwATOKpnYjxVavuWM.get('subtitle')
   csoJLSRdkNEtmXwATOKpnYjxVavuyb={'mediatype':'episode','title':csoJLSRdkNEtmXwATOKpnYjxVavuhQ,'plot':'%s\n%s'%(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,csoJLSRdkNEtmXwATOKpnYjxVavuyz)}
   csoJLSRdkNEtmXwATOKpnYjxVavuhC={'mode':'LIVE','mediacode':csoJLSRdkNEtmXwATOKpnYjxVavuyH,'stype':'onair',}
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.add_dir(csoJLSRdkNEtmXwATOKpnYjxVavuhQ,sublabel=csoJLSRdkNEtmXwATOKpnYjxVavuyz,img='',infoLabels=csoJLSRdkNEtmXwATOKpnYjxVavuyb,isFolder=csoJLSRdkNEtmXwATOKpnYjxVavuGI,params=csoJLSRdkNEtmXwATOKpnYjxVavuhC)
  if csoJLSRdkNEtmXwATOKpnYjxVavugi(csoJLSRdkNEtmXwATOKpnYjxVavuWf)>0:xbmcplugin.endOfDirectory(csoJLSRdkNEtmXwATOKpnYjxVavuiH._addon_handle,cacheToDisc=csoJLSRdkNEtmXwATOKpnYjxVavuGI)
 def tving_main(csoJLSRdkNEtmXwATOKpnYjxVavuiH):
  csoJLSRdkNEtmXwATOKpnYjxVavulQ=csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params.get('mode',csoJLSRdkNEtmXwATOKpnYjxVavuGM)
  if csoJLSRdkNEtmXwATOKpnYjxVavulQ=='LOGOUT':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.logout()
   return
  csoJLSRdkNEtmXwATOKpnYjxVavuiH.login_main()
  if csoJLSRdkNEtmXwATOKpnYjxVavulQ is csoJLSRdkNEtmXwATOKpnYjxVavuGM:
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_Main_List()
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_Title_Group(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ in['GLOBAL_GROUP']:
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_SubTitle_Group(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='CHANNEL':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_LiveChannel_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ in['LIVE','VOD','MOVIE']:
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.play_VIDEO(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='PROGRAM':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_Program_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='4K_PROGRAM':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_4K_Program_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='ORI_PROGRAM':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_Ori_Program_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='EPISODE':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_Episode_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='MOVIE_SUB':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_Movie_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='4K_MOVIE':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_4K_Movie_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='SEARCH_GROUP':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_Search_Group(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ in['SEARCH','LOCAL_SEARCH']:
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_Search_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='WATCH':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_Watch_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_History_Remove(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='ORDER_BY':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_setEpOrderby(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='SET_BOOKMARK':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_Set_Bookmark(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ in['TOTAL_SEARCH','TOTAL_HISTORY']:
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_Global_Search(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='SEARCH_HISTORY':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_Search_History(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='MENU_BOOKMARK':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_Bookmark_Menu(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  elif csoJLSRdkNEtmXwATOKpnYjxVavulQ=='EURO_GROUP':
   csoJLSRdkNEtmXwATOKpnYjxVavuiH.dp_EuroLive_List(csoJLSRdkNEtmXwATOKpnYjxVavuiH.main_params)
  else:
   csoJLSRdkNEtmXwATOKpnYjxVavuGM
# Created by pyminifier (https://github.com/liftoff/pyminifier)
