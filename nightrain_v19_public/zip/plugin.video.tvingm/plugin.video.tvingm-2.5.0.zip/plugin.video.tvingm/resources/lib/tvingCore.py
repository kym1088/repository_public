__author__="NightRain"
sBHvhqkdECVflUAKouLyMGbNOjYwIn=print
sBHvhqkdECVflUAKouLyMGbNOjYwIW=ImportError
sBHvhqkdECVflUAKouLyMGbNOjYwIX=object
sBHvhqkdECVflUAKouLyMGbNOjYwIe=None
sBHvhqkdECVflUAKouLyMGbNOjYwIP=False
sBHvhqkdECVflUAKouLyMGbNOjYwIS=open
sBHvhqkdECVflUAKouLyMGbNOjYwIT=True
sBHvhqkdECVflUAKouLyMGbNOjYwIQ=int
sBHvhqkdECVflUAKouLyMGbNOjYwIm=range
sBHvhqkdECVflUAKouLyMGbNOjYwIp=Exception
sBHvhqkdECVflUAKouLyMGbNOjYwIz=len
sBHvhqkdECVflUAKouLyMGbNOjYwIi=str
sBHvhqkdECVflUAKouLyMGbNOjYwIt=list
sBHvhqkdECVflUAKouLyMGbNOjYwJR=bytes
sBHvhqkdECVflUAKouLyMGbNOjYwJc=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 sBHvhqkdECVflUAKouLyMGbNOjYwIn('Cryptodome')
except sBHvhqkdECVflUAKouLyMGbNOjYwIW:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 sBHvhqkdECVflUAKouLyMGbNOjYwIn('Crypto')
sBHvhqkdECVflUAKouLyMGbNOjYwRx={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
sBHvhqkdECVflUAKouLyMGbNOjYwRg ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class sBHvhqkdECVflUAKouLyMGbNOjYwRc(sBHvhqkdECVflUAKouLyMGbNOjYwIX):
 def __init__(sBHvhqkdECVflUAKouLyMGbNOjYwRF):
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.NETWORKCODE ='CSND0900'
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.OSCODE ='CSOD0900' 
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.TELECODE ='CSCD0900'
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.SCREENCODE ='CSSD0100'
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.SCREENCODE_ATV ='CSSD1300' 
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.LIVE_LIMIT =20 
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.VOD_LIMIT =24 
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.EPISODE_LIMIT =30 
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.SEARCH_LIMIT =30 
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.MOVIE_LIMIT =24 
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN ='https://api.tving.com'
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN ='https://image.tving.com'
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.SEARCH_DOMAIN ='https://search.tving.com'
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.LOGIN_DOMAIN ='https://user.tving.com'
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.URL_DOMAIN ='https://www.tving.com'
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.MOVIE_LITE =['2610061','2610161','261062']
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.DEFAULT_HEADER ={'user-agent':sBHvhqkdECVflUAKouLyMGbNOjYwRF.USER_AGENT}
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV_SESSION_COOKIES1=''
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV_SESSION_COOKIES2=''
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV ={}
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.Init_TV_Total()
 def Init_TV_Total(sBHvhqkdECVflUAKouLyMGbNOjYwRF):
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N',},}
 def callRequestCookies(sBHvhqkdECVflUAKouLyMGbNOjYwRF,jobtype,sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwIe,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe,redirects=sBHvhqkdECVflUAKouLyMGbNOjYwIP):
  sBHvhqkdECVflUAKouLyMGbNOjYwRI=sBHvhqkdECVflUAKouLyMGbNOjYwRF.DEFAULT_HEADER
  if headers:sBHvhqkdECVflUAKouLyMGbNOjYwRI.update(headers)
  if jobtype=='Get':
   sBHvhqkdECVflUAKouLyMGbNOjYwRJ=requests.get(sBHvhqkdECVflUAKouLyMGbNOjYwct,params=params,headers=sBHvhqkdECVflUAKouLyMGbNOjYwRI,cookies=cookies,allow_redirects=redirects)
  else:
   sBHvhqkdECVflUAKouLyMGbNOjYwRJ=requests.post(sBHvhqkdECVflUAKouLyMGbNOjYwct,data=payload,params=params,headers=sBHvhqkdECVflUAKouLyMGbNOjYwRI,cookies=cookies,allow_redirects=redirects)
  return sBHvhqkdECVflUAKouLyMGbNOjYwRJ
 def JsonFile_Save(sBHvhqkdECVflUAKouLyMGbNOjYwRF,filename,sBHvhqkdECVflUAKouLyMGbNOjYwRr):
  if filename=='':return sBHvhqkdECVflUAKouLyMGbNOjYwIP
  try:
   fp=sBHvhqkdECVflUAKouLyMGbNOjYwIS(filename,'w',-1,'utf-8')
   json.dump(sBHvhqkdECVflUAKouLyMGbNOjYwRr,fp,indent=4,ensure_ascii=sBHvhqkdECVflUAKouLyMGbNOjYwIP)
   fp.close()
  except:
   return sBHvhqkdECVflUAKouLyMGbNOjYwIP
  return sBHvhqkdECVflUAKouLyMGbNOjYwIT
 def JsonFile_Load(sBHvhqkdECVflUAKouLyMGbNOjYwRF,filename):
  if filename=='':return{}
  try:
   fp=sBHvhqkdECVflUAKouLyMGbNOjYwIS(filename,'r',-1,'utf-8')
   sBHvhqkdECVflUAKouLyMGbNOjYwRD=json.load(fp)
   fp.close()
  except:
   return{}
  return sBHvhqkdECVflUAKouLyMGbNOjYwRD
 def Save_session_acount(sBHvhqkdECVflUAKouLyMGbNOjYwRF,sBHvhqkdECVflUAKouLyMGbNOjYwRn,sBHvhqkdECVflUAKouLyMGbNOjYwRW,sBHvhqkdECVflUAKouLyMGbNOjYwRX,sBHvhqkdECVflUAKouLyMGbNOjYwRe):
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['account']['tvid'] =base64.standard_b64encode(sBHvhqkdECVflUAKouLyMGbNOjYwRn.encode()).decode('utf-8')
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['account']['tvpw'] =base64.standard_b64encode(sBHvhqkdECVflUAKouLyMGbNOjYwRW.encode()).decode('utf-8')
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['account']['tvtype']=sBHvhqkdECVflUAKouLyMGbNOjYwRX 
  sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['account']['tvpf'] =sBHvhqkdECVflUAKouLyMGbNOjYwRe 
 def Load_session_acount(sBHvhqkdECVflUAKouLyMGbNOjYwRF):
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwRn =base64.standard_b64decode(sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['account']['tvid']).decode('utf-8')
   sBHvhqkdECVflUAKouLyMGbNOjYwRW =base64.standard_b64decode(sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['account']['tvpw']).decode('utf-8')
   sBHvhqkdECVflUAKouLyMGbNOjYwRX=sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['account']['tvtype']
   sBHvhqkdECVflUAKouLyMGbNOjYwRe =sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return sBHvhqkdECVflUAKouLyMGbNOjYwRn,sBHvhqkdECVflUAKouLyMGbNOjYwRW,sBHvhqkdECVflUAKouLyMGbNOjYwRX,sBHvhqkdECVflUAKouLyMGbNOjYwRe
 def makeDefaultCookies(sBHvhqkdECVflUAKouLyMGbNOjYwRF):
  sBHvhqkdECVflUAKouLyMGbNOjYwRP={}
  if sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_token']:sBHvhqkdECVflUAKouLyMGbNOjYwRP['_tving_token']=sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_token']
  if sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_userinfo']:sBHvhqkdECVflUAKouLyMGbNOjYwRP['POC_USERINFO']=sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_userinfo']
  if sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_maintoken']:sBHvhqkdECVflUAKouLyMGbNOjYwRP[sBHvhqkdECVflUAKouLyMGbNOjYwRF.GLOBAL_COOKIENM['tv_maintoken']]=sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_maintoken']
  if sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_cookiekey']:sBHvhqkdECVflUAKouLyMGbNOjYwRP[sBHvhqkdECVflUAKouLyMGbNOjYwRF.GLOBAL_COOKIENM['tv_cookiekey']]=sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_cookiekey']
  if sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_lockkey']:sBHvhqkdECVflUAKouLyMGbNOjYwRP[sBHvhqkdECVflUAKouLyMGbNOjYwRF.GLOBAL_COOKIENM['tv_lockkey']]=sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_lockkey']
  return sBHvhqkdECVflUAKouLyMGbNOjYwRP
 def makeCookiesStr(sBHvhqkdECVflUAKouLyMGbNOjYwRF):
  return '_tving_token='+sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_token']+';'+ 'POC_USERINFO='+sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_userinfo']+';'+ sBHvhqkdECVflUAKouLyMGbNOjYwRF.GLOBAL_COOKIENM['tv_maintoken']+'='+sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_maintoken']+';'+ sBHvhqkdECVflUAKouLyMGbNOjYwRF.GLOBAL_COOKIENM['tv_cookiekey']+'='+sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_cookiekey']+';'+ sBHvhqkdECVflUAKouLyMGbNOjYwRF.GLOBAL_COOKIENM['tv_lockkey']+'='+sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_lockkey']
 def getDeviceStr(sBHvhqkdECVflUAKouLyMGbNOjYwRF):
  sBHvhqkdECVflUAKouLyMGbNOjYwRS=[]
  sBHvhqkdECVflUAKouLyMGbNOjYwRS.append('Windows') 
  sBHvhqkdECVflUAKouLyMGbNOjYwRS.append('Chrome') 
  sBHvhqkdECVflUAKouLyMGbNOjYwRS.append('ko-KR') 
  sBHvhqkdECVflUAKouLyMGbNOjYwRS.append('undefined') 
  sBHvhqkdECVflUAKouLyMGbNOjYwRS.append('24') 
  sBHvhqkdECVflUAKouLyMGbNOjYwRS.append(u'한국 표준시')
  sBHvhqkdECVflUAKouLyMGbNOjYwRS.append('undefined') 
  sBHvhqkdECVflUAKouLyMGbNOjYwRS.append('undefined') 
  sBHvhqkdECVflUAKouLyMGbNOjYwRS.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  sBHvhqkdECVflUAKouLyMGbNOjYwRT=''
  for sBHvhqkdECVflUAKouLyMGbNOjYwRQ in sBHvhqkdECVflUAKouLyMGbNOjYwRS:
   sBHvhqkdECVflUAKouLyMGbNOjYwRT+=sBHvhqkdECVflUAKouLyMGbNOjYwRQ+'|'
  return sBHvhqkdECVflUAKouLyMGbNOjYwRT
 def GetDefaultParams(sBHvhqkdECVflUAKouLyMGbNOjYwRF,uhd=sBHvhqkdECVflUAKouLyMGbNOjYwIP):
  if uhd==sBHvhqkdECVflUAKouLyMGbNOjYwIP:
   sBHvhqkdECVflUAKouLyMGbNOjYwRm={'apiKey':sBHvhqkdECVflUAKouLyMGbNOjYwRF.APIKEY,'networkCode':sBHvhqkdECVflUAKouLyMGbNOjYwRF.NETWORKCODE,'osCode':sBHvhqkdECVflUAKouLyMGbNOjYwRF.OSCODE,'teleCode':sBHvhqkdECVflUAKouLyMGbNOjYwRF.TELECODE,'screenCode':sBHvhqkdECVflUAKouLyMGbNOjYwRF.SCREENCODE,}
  else:
   sBHvhqkdECVflUAKouLyMGbNOjYwRm={'apiKey':sBHvhqkdECVflUAKouLyMGbNOjYwRF.APIKEY_ATV,'networkCode':sBHvhqkdECVflUAKouLyMGbNOjYwRF.NETWORKCODE,'osCode':sBHvhqkdECVflUAKouLyMGbNOjYwRF.OSCODE,'teleCode':sBHvhqkdECVflUAKouLyMGbNOjYwRF.TELECODE,'screenCode':sBHvhqkdECVflUAKouLyMGbNOjYwRF.SCREENCODE_ATV,}
  return sBHvhqkdECVflUAKouLyMGbNOjYwRm
 def GetNoCache(sBHvhqkdECVflUAKouLyMGbNOjYwRF,timetype=1):
  if timetype==1:
   return sBHvhqkdECVflUAKouLyMGbNOjYwIQ(time.time())
  else:
   return sBHvhqkdECVflUAKouLyMGbNOjYwIQ(time.time()*1000)
 def GetUniqueid(sBHvhqkdECVflUAKouLyMGbNOjYwRF,hValue=sBHvhqkdECVflUAKouLyMGbNOjYwIe):
  if hValue:
   import hashlib
   sBHvhqkdECVflUAKouLyMGbNOjYwRp=hashlib.sha1()
   sBHvhqkdECVflUAKouLyMGbNOjYwRp.update(hValue.encode())
   sBHvhqkdECVflUAKouLyMGbNOjYwRz=sBHvhqkdECVflUAKouLyMGbNOjYwRp.hexdigest()[:8]
  else:
   sBHvhqkdECVflUAKouLyMGbNOjYwRi=[0 for i in sBHvhqkdECVflUAKouLyMGbNOjYwIm(256)]
   for i in sBHvhqkdECVflUAKouLyMGbNOjYwIm(256):
    sBHvhqkdECVflUAKouLyMGbNOjYwRi[i]='%02x'%(i)
   sBHvhqkdECVflUAKouLyMGbNOjYwRt=sBHvhqkdECVflUAKouLyMGbNOjYwIQ(4294967295*random.random())|0
   sBHvhqkdECVflUAKouLyMGbNOjYwRz=sBHvhqkdECVflUAKouLyMGbNOjYwRi[255&sBHvhqkdECVflUAKouLyMGbNOjYwRt]+sBHvhqkdECVflUAKouLyMGbNOjYwRi[sBHvhqkdECVflUAKouLyMGbNOjYwRt>>8&255]+sBHvhqkdECVflUAKouLyMGbNOjYwRi[sBHvhqkdECVflUAKouLyMGbNOjYwRt>>16&255]+sBHvhqkdECVflUAKouLyMGbNOjYwRi[sBHvhqkdECVflUAKouLyMGbNOjYwRt>>24&255]
  return sBHvhqkdECVflUAKouLyMGbNOjYwRz
 def GetCredential(sBHvhqkdECVflUAKouLyMGbNOjYwRF,user_id,user_pw,login_type,user_pf):
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwcR=sBHvhqkdECVflUAKouLyMGbNOjYwRF.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   sBHvhqkdECVflUAKouLyMGbNOjYwcx={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Post',sBHvhqkdECVflUAKouLyMGbNOjYwcR,payload=sBHvhqkdECVflUAKouLyMGbNOjYwcx,params=sBHvhqkdECVflUAKouLyMGbNOjYwIe,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe)
   for sBHvhqkdECVflUAKouLyMGbNOjYwcF in sBHvhqkdECVflUAKouLyMGbNOjYwcg.cookies:
    if sBHvhqkdECVflUAKouLyMGbNOjYwcF.name=='_tving_token':
     sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_token']=sBHvhqkdECVflUAKouLyMGbNOjYwcF.value
    elif sBHvhqkdECVflUAKouLyMGbNOjYwcF.name=='POC_USERINFO':
     sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_userinfo']=sBHvhqkdECVflUAKouLyMGbNOjYwcF.value
   if not sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_token']:
    sBHvhqkdECVflUAKouLyMGbNOjYwRF.Init_TV_Total()
    return sBHvhqkdECVflUAKouLyMGbNOjYwIP
   sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_maintoken']=sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_token']
   if sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetProfileToken(user_pf)==sBHvhqkdECVflUAKouLyMGbNOjYwIP:
    sBHvhqkdECVflUAKouLyMGbNOjYwRF.Init_TV_Total()
    return sBHvhqkdECVflUAKouLyMGbNOjYwIP
   sBHvhqkdECVflUAKouLyMGbNOjYwcI =sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDeviceList()
   if sBHvhqkdECVflUAKouLyMGbNOjYwcI not in['','-']:
    sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_uuid']=sBHvhqkdECVflUAKouLyMGbNOjYwcI+'-'+sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetUniqueid(sBHvhqkdECVflUAKouLyMGbNOjYwcI)
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
   sBHvhqkdECVflUAKouLyMGbNOjYwRF.Init_TV_Total()
   return sBHvhqkdECVflUAKouLyMGbNOjYwIP
  return sBHvhqkdECVflUAKouLyMGbNOjYwIT
 def GetProfileToken(sBHvhqkdECVflUAKouLyMGbNOjYwRF,user_pf):
  sBHvhqkdECVflUAKouLyMGbNOjYwcJ=[]
  sBHvhqkdECVflUAKouLyMGbNOjYwcr =''
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwca ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   sBHvhqkdECVflUAKouLyMGbNOjYwRP=sBHvhqkdECVflUAKouLyMGbNOjYwRF.makeDefaultCookies()
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwca,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwIe,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwRP)
   sBHvhqkdECVflUAKouLyMGbNOjYwcJ =re.findall('data-profile-no="\d+"',sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   for i in sBHvhqkdECVflUAKouLyMGbNOjYwIm(sBHvhqkdECVflUAKouLyMGbNOjYwIz(sBHvhqkdECVflUAKouLyMGbNOjYwcJ)):
    sBHvhqkdECVflUAKouLyMGbNOjYwcD =sBHvhqkdECVflUAKouLyMGbNOjYwcJ[i].replace('data-profile-no=','').replace('"','')
    sBHvhqkdECVflUAKouLyMGbNOjYwcJ[i]=sBHvhqkdECVflUAKouLyMGbNOjYwcD
   sBHvhqkdECVflUAKouLyMGbNOjYwcr=sBHvhqkdECVflUAKouLyMGbNOjYwcJ[user_pf]
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
   sBHvhqkdECVflUAKouLyMGbNOjYwRF.Init_TV_Total()
   return sBHvhqkdECVflUAKouLyMGbNOjYwIP
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwca ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   sBHvhqkdECVflUAKouLyMGbNOjYwRP=sBHvhqkdECVflUAKouLyMGbNOjYwRF.makeDefaultCookies()
   sBHvhqkdECVflUAKouLyMGbNOjYwcx={'profileNo':sBHvhqkdECVflUAKouLyMGbNOjYwcr}
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Post',sBHvhqkdECVflUAKouLyMGbNOjYwca,payload=sBHvhqkdECVflUAKouLyMGbNOjYwcx,params=sBHvhqkdECVflUAKouLyMGbNOjYwIe,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwRP)
   for sBHvhqkdECVflUAKouLyMGbNOjYwcF in sBHvhqkdECVflUAKouLyMGbNOjYwcg.cookies:
    if sBHvhqkdECVflUAKouLyMGbNOjYwcF.name=='_tving_token':
     sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_token']=sBHvhqkdECVflUAKouLyMGbNOjYwcF.value
    elif sBHvhqkdECVflUAKouLyMGbNOjYwcF.name==sBHvhqkdECVflUAKouLyMGbNOjYwRF.GLOBAL_COOKIENM['tv_cookiekey']:
     sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_cookiekey']=sBHvhqkdECVflUAKouLyMGbNOjYwcF.value
    elif sBHvhqkdECVflUAKouLyMGbNOjYwcF.name==sBHvhqkdECVflUAKouLyMGbNOjYwRF.GLOBAL_COOKIENM['tv_lockkey']:
     sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_lockkey']=sBHvhqkdECVflUAKouLyMGbNOjYwcF.value
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
   sBHvhqkdECVflUAKouLyMGbNOjYwRF.Init_TV_Total()
   return sBHvhqkdECVflUAKouLyMGbNOjYwIP
  return sBHvhqkdECVflUAKouLyMGbNOjYwIT
 def GetDeviceList(sBHvhqkdECVflUAKouLyMGbNOjYwRF):
  sBHvhqkdECVflUAKouLyMGbNOjYwcn=[]
  sBHvhqkdECVflUAKouLyMGbNOjYwcW='-'
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v1/user/device/list'
   sBHvhqkdECVflUAKouLyMGbNOjYwcX=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwca
   sBHvhqkdECVflUAKouLyMGbNOjYwce={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   sBHvhqkdECVflUAKouLyMGbNOjYwRP=sBHvhqkdECVflUAKouLyMGbNOjYwRF.makeDefaultCookies()
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwcX,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwce,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwRP)
   sBHvhqkdECVflUAKouLyMGbNOjYwcP=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   sBHvhqkdECVflUAKouLyMGbNOjYwcn=sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']
   for sBHvhqkdECVflUAKouLyMGbNOjYwcS in sBHvhqkdECVflUAKouLyMGbNOjYwcn:
    if sBHvhqkdECVflUAKouLyMGbNOjYwcS['model']=='PC' or sBHvhqkdECVflUAKouLyMGbNOjYwcS['model']=='PC-Chrome':
     sBHvhqkdECVflUAKouLyMGbNOjYwcW=sBHvhqkdECVflUAKouLyMGbNOjYwcS['uuid']
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
  return sBHvhqkdECVflUAKouLyMGbNOjYwcW
 def Get_Now_Datetime(sBHvhqkdECVflUAKouLyMGbNOjYwRF):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(sBHvhqkdECVflUAKouLyMGbNOjYwRF,mediacode,sel_quality,stype,pvrmode='-',optUHD=sBHvhqkdECVflUAKouLyMGbNOjYwIP):
  sBHvhqkdECVflUAKouLyMGbNOjYwcQ ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','subtitleYn':sBHvhqkdECVflUAKouLyMGbNOjYwIP,'error_msg':'',}
  sBHvhqkdECVflUAKouLyMGbNOjYwcW =sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_uuid'].split('-')[0] 
  sBHvhqkdECVflUAKouLyMGbNOjYwcm =sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_uuid'] 
  sBHvhqkdECVflUAKouLyMGbNOjYwcp=sBHvhqkdECVflUAKouLyMGbNOjYwIP 
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwcz=sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetNoCache(1))
   if stype!='tvingtv':
    sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v2/media/stream/info' 
    sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams()
    sBHvhqkdECVflUAKouLyMGbNOjYwce={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':sBHvhqkdECVflUAKouLyMGbNOjYwcm,'deviceInfo':'PC','noCache':sBHvhqkdECVflUAKouLyMGbNOjYwcz,}
    sBHvhqkdECVflUAKouLyMGbNOjYwci.update(sBHvhqkdECVflUAKouLyMGbNOjYwce)
    sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwca
    sBHvhqkdECVflUAKouLyMGbNOjYwRP=sBHvhqkdECVflUAKouLyMGbNOjYwRF.makeDefaultCookies()
    sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwci,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwRP)
    if sBHvhqkdECVflUAKouLyMGbNOjYwcg.status_code!=200:
     sBHvhqkdECVflUAKouLyMGbNOjYwcQ['error_msg']='First Step - {} error'.format(sBHvhqkdECVflUAKouLyMGbNOjYwcg.status_code)
     return sBHvhqkdECVflUAKouLyMGbNOjYwcQ
    sBHvhqkdECVflUAKouLyMGbNOjYwcP=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
    if sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['result']['code']=='060':
     for sBHvhqkdECVflUAKouLyMGbNOjYwxR,sBHvhqkdECVflUAKouLyMGbNOjYwxX in sBHvhqkdECVflUAKouLyMGbNOjYwRx.items():
      if sBHvhqkdECVflUAKouLyMGbNOjYwxX==sel_quality:
       sBHvhqkdECVflUAKouLyMGbNOjYwxc=sBHvhqkdECVflUAKouLyMGbNOjYwxR
    elif sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['result']['code']!='000':
     sBHvhqkdECVflUAKouLyMGbNOjYwcQ['error_msg']=sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['result']['message']
     return sBHvhqkdECVflUAKouLyMGbNOjYwcQ
    else: 
     if not('stream' in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']):return sBHvhqkdECVflUAKouLyMGbNOjYwcQ
     sBHvhqkdECVflUAKouLyMGbNOjYwxg=[]
     for sBHvhqkdECVflUAKouLyMGbNOjYwxR,sBHvhqkdECVflUAKouLyMGbNOjYwxX in sBHvhqkdECVflUAKouLyMGbNOjYwRx.items():
      for sBHvhqkdECVflUAKouLyMGbNOjYwcS in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['stream']['quality']:
       if sBHvhqkdECVflUAKouLyMGbNOjYwcS['active']=='Y' and sBHvhqkdECVflUAKouLyMGbNOjYwcS['code']==sBHvhqkdECVflUAKouLyMGbNOjYwxR:
        sBHvhqkdECVflUAKouLyMGbNOjYwxg.append({sBHvhqkdECVflUAKouLyMGbNOjYwRx.get(sBHvhqkdECVflUAKouLyMGbNOjYwcS['code']):sBHvhqkdECVflUAKouLyMGbNOjYwcS['code']})
     sBHvhqkdECVflUAKouLyMGbNOjYwxc=sBHvhqkdECVflUAKouLyMGbNOjYwRF.CheckQuality(sel_quality,sBHvhqkdECVflUAKouLyMGbNOjYwxg)
     try:
      if optUHD==sBHvhqkdECVflUAKouLyMGbNOjYwIT and sBHvhqkdECVflUAKouLyMGbNOjYwxc=='stream50' and 'stream_support_info' in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['content']['info']:
       if sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['content']['info']['stream_support_info']!=sBHvhqkdECVflUAKouLyMGbNOjYwIe:
        if 'stream70' in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['content']['info']['stream_support_info']:
         sBHvhqkdECVflUAKouLyMGbNOjYwxc='stream70'
         sBHvhqkdECVflUAKouLyMGbNOjYwcp =sBHvhqkdECVflUAKouLyMGbNOjYwIT
     except:
      pass
     try:
      if optUHD==sBHvhqkdECVflUAKouLyMGbNOjYwIT and sBHvhqkdECVflUAKouLyMGbNOjYwxc=='stream50' and 'stream' in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['content']['info']:
       if sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['content']['info']['stream']!=sBHvhqkdECVflUAKouLyMGbNOjYwIe:
        for sBHvhqkdECVflUAKouLyMGbNOjYwcS in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['content']['info']['stream']:
         if sBHvhqkdECVflUAKouLyMGbNOjYwcS['code']=='stream70':
          sBHvhqkdECVflUAKouLyMGbNOjYwxc='stream70'
          sBHvhqkdECVflUAKouLyMGbNOjYwcp =sBHvhqkdECVflUAKouLyMGbNOjYwIT
          break
     except:
      pass
   else:
    sBHvhqkdECVflUAKouLyMGbNOjYwxc='stream40'
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
   sBHvhqkdECVflUAKouLyMGbNOjYwcQ['error_msg']='First Step - except error'
   return sBHvhqkdECVflUAKouLyMGbNOjYwcQ
  sBHvhqkdECVflUAKouLyMGbNOjYwIn(sBHvhqkdECVflUAKouLyMGbNOjYwxc)
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwcz=sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetNoCache(1))
   sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v2a/media/stream/info'
   if sBHvhqkdECVflUAKouLyMGbNOjYwcp==sBHvhqkdECVflUAKouLyMGbNOjYwIT:
    sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams(uhd=sBHvhqkdECVflUAKouLyMGbNOjYwIT)
    sBHvhqkdECVflUAKouLyMGbNOjYwce={'mediaCode':mediacode,'noCache':sBHvhqkdECVflUAKouLyMGbNOjYwcz,'streamType':'hls','streamCode':sBHvhqkdECVflUAKouLyMGbNOjYwxc,'deviceId':sBHvhqkdECVflUAKouLyMGbNOjYwcW,'adReq':'none','wm':'Y','ad_device':'','uuid':sBHvhqkdECVflUAKouLyMGbNOjYwcm,'deviceInfo':'android_tv',}
   else:
    sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams()
    sBHvhqkdECVflUAKouLyMGbNOjYwce={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':sBHvhqkdECVflUAKouLyMGbNOjYwxc,'deviceId':sBHvhqkdECVflUAKouLyMGbNOjYwcW,'uuid':sBHvhqkdECVflUAKouLyMGbNOjYwcm,'deviceInfo':'PC_Chrome','noCache':sBHvhqkdECVflUAKouLyMGbNOjYwcz,'wm':'Y'}
   sBHvhqkdECVflUAKouLyMGbNOjYwci.update(sBHvhqkdECVflUAKouLyMGbNOjYwce)
   sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwca
   sBHvhqkdECVflUAKouLyMGbNOjYwRP=sBHvhqkdECVflUAKouLyMGbNOjYwRF.makeDefaultCookies()
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwci,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwRP,redirects=sBHvhqkdECVflUAKouLyMGbNOjYwIP)
   sBHvhqkdECVflUAKouLyMGbNOjYwcP=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   if sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['result']['code']!='000':
    sBHvhqkdECVflUAKouLyMGbNOjYwcQ['error_msg']=sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['result']['message']
    return sBHvhqkdECVflUAKouLyMGbNOjYwcQ
   sBHvhqkdECVflUAKouLyMGbNOjYwxF=sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['stream']
   if 'drm_license_assertion' in sBHvhqkdECVflUAKouLyMGbNOjYwxF:
    sBHvhqkdECVflUAKouLyMGbNOjYwcQ['drm_license']=sBHvhqkdECVflUAKouLyMGbNOjYwxF['drm_license_assertion']
    if '4k_nondrm_url' in sBHvhqkdECVflUAKouLyMGbNOjYwxF['broadcast']and sBHvhqkdECVflUAKouLyMGbNOjYwcp==sBHvhqkdECVflUAKouLyMGbNOjYwIT:
     sBHvhqkdECVflUAKouLyMGbNOjYwxI =sBHvhqkdECVflUAKouLyMGbNOjYwxF['broadcast']['4k_nondrm_url']
     sBHvhqkdECVflUAKouLyMGbNOjYwcQ['drm_license']=''
    else:
     sBHvhqkdECVflUAKouLyMGbNOjYwxI =sBHvhqkdECVflUAKouLyMGbNOjYwxF['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in sBHvhqkdECVflUAKouLyMGbNOjYwxF['broadcast']):return sBHvhqkdECVflUAKouLyMGbNOjYwcQ
    sBHvhqkdECVflUAKouLyMGbNOjYwxI=sBHvhqkdECVflUAKouLyMGbNOjYwxF['broadcast']['broad_url']
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
   sBHvhqkdECVflUAKouLyMGbNOjYwcQ['error_msg']='Second Step - except error'
   return sBHvhqkdECVflUAKouLyMGbNOjYwcQ
  sBHvhqkdECVflUAKouLyMGbNOjYwxJ=sBHvhqkdECVflUAKouLyMGbNOjYwcz
  sBHvhqkdECVflUAKouLyMGbNOjYwxI=sBHvhqkdECVflUAKouLyMGbNOjYwxI.split('|')[1]
  sBHvhqkdECVflUAKouLyMGbNOjYwxI,sBHvhqkdECVflUAKouLyMGbNOjYwxr,sBHvhqkdECVflUAKouLyMGbNOjYwxa=sBHvhqkdECVflUAKouLyMGbNOjYwRF.Decrypt_Url(sBHvhqkdECVflUAKouLyMGbNOjYwxI,mediacode,sBHvhqkdECVflUAKouLyMGbNOjYwxJ)
  sBHvhqkdECVflUAKouLyMGbNOjYwcQ['streaming_url']=sBHvhqkdECVflUAKouLyMGbNOjYwxI
  sBHvhqkdECVflUAKouLyMGbNOjYwcQ['watermark'] =sBHvhqkdECVflUAKouLyMGbNOjYwxr
  sBHvhqkdECVflUAKouLyMGbNOjYwcQ['watermarkKey']=sBHvhqkdECVflUAKouLyMGbNOjYwxa
  for sBHvhqkdECVflUAKouLyMGbNOjYwxD in sBHvhqkdECVflUAKouLyMGbNOjYwxF.get('subtitles'):
   if sBHvhqkdECVflUAKouLyMGbNOjYwxD.get('code')in['KO','KO_CC']:
    sBHvhqkdECVflUAKouLyMGbNOjYwcQ['subtitleYn']=sBHvhqkdECVflUAKouLyMGbNOjYwIT
    break
  return sBHvhqkdECVflUAKouLyMGbNOjYwcQ
 def CheckQuality(sBHvhqkdECVflUAKouLyMGbNOjYwRF,sel_qt,sBHvhqkdECVflUAKouLyMGbNOjYwxg):
  for sBHvhqkdECVflUAKouLyMGbNOjYwxn in sBHvhqkdECVflUAKouLyMGbNOjYwxg:
   if sel_qt>=sBHvhqkdECVflUAKouLyMGbNOjYwIt(sBHvhqkdECVflUAKouLyMGbNOjYwxn)[0]:return sBHvhqkdECVflUAKouLyMGbNOjYwxn.get(sBHvhqkdECVflUAKouLyMGbNOjYwIt(sBHvhqkdECVflUAKouLyMGbNOjYwxn)[0])
   sBHvhqkdECVflUAKouLyMGbNOjYwxW=sBHvhqkdECVflUAKouLyMGbNOjYwxn.get(sBHvhqkdECVflUAKouLyMGbNOjYwIt(sBHvhqkdECVflUAKouLyMGbNOjYwxn)[0])
  return sBHvhqkdECVflUAKouLyMGbNOjYwxW
 def makeOocUrl(sBHvhqkdECVflUAKouLyMGbNOjYwRF,ooc_params):
  sBHvhqkdECVflUAKouLyMGbNOjYwct=''
  for sBHvhqkdECVflUAKouLyMGbNOjYwxR,sBHvhqkdECVflUAKouLyMGbNOjYwxX in ooc_params.items():
   sBHvhqkdECVflUAKouLyMGbNOjYwct+="%s=%s^"%(sBHvhqkdECVflUAKouLyMGbNOjYwxR,sBHvhqkdECVflUAKouLyMGbNOjYwxX)
  return sBHvhqkdECVflUAKouLyMGbNOjYwct
 def GetLiveChannelList(sBHvhqkdECVflUAKouLyMGbNOjYwRF,stype,page_int):
  sBHvhqkdECVflUAKouLyMGbNOjYwcn=[]
  sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIP
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v2/media/lives'
   if stype=='onair': 
    sBHvhqkdECVflUAKouLyMGbNOjYwxP='CPCS0100,CPCS0400'
   else:
    sBHvhqkdECVflUAKouLyMGbNOjYwxP='CPCS0300'
   sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams()
   sBHvhqkdECVflUAKouLyMGbNOjYwce={'cacheType':'main','pageNo':sBHvhqkdECVflUAKouLyMGbNOjYwIi(page_int),'pageSize':sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwRF.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':sBHvhqkdECVflUAKouLyMGbNOjYwxP,}
   sBHvhqkdECVflUAKouLyMGbNOjYwci.update(sBHvhqkdECVflUAKouLyMGbNOjYwce)
   sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwca
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwci,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe)
   sBHvhqkdECVflUAKouLyMGbNOjYwcP=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   if not('result' in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']):return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
   sBHvhqkdECVflUAKouLyMGbNOjYwxS=sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['result']
   for sBHvhqkdECVflUAKouLyMGbNOjYwcS in sBHvhqkdECVflUAKouLyMGbNOjYwxS:
    sBHvhqkdECVflUAKouLyMGbNOjYwxT=sBHvhqkdECVflUAKouLyMGbNOjYwxp=sBHvhqkdECVflUAKouLyMGbNOjYwxz=''
    sBHvhqkdECVflUAKouLyMGbNOjYwxQ=sBHvhqkdECVflUAKouLyMGbNOjYwgS=''
    sBHvhqkdECVflUAKouLyMGbNOjYwxm=sBHvhqkdECVflUAKouLyMGbNOjYwcS['live_code']
    sBHvhqkdECVflUAKouLyMGbNOjYwxT =sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['channel']['name']['ko']
    if sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['episode']!=sBHvhqkdECVflUAKouLyMGbNOjYwIe:
     sBHvhqkdECVflUAKouLyMGbNOjYwxp =sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['program']['name']['ko']
     sBHvhqkdECVflUAKouLyMGbNOjYwxp =sBHvhqkdECVflUAKouLyMGbNOjYwxp+', '+sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['episode']['frequency'])+'회'
     sBHvhqkdECVflUAKouLyMGbNOjYwxz=sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['episode']['synopsis']['ko']
    else:
     sBHvhqkdECVflUAKouLyMGbNOjYwxp =sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['program']['name']['ko']
     sBHvhqkdECVflUAKouLyMGbNOjYwxz=sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['program']['synopsis']['ko']
    try: 
     sBHvhqkdECVflUAKouLyMGbNOjYwxi =''
     sBHvhqkdECVflUAKouLyMGbNOjYwxt =''
     sBHvhqkdECVflUAKouLyMGbNOjYwgR=''
     sBHvhqkdECVflUAKouLyMGbNOjYwgc =''
     sBHvhqkdECVflUAKouLyMGbNOjYwgx =''
     sBHvhqkdECVflUAKouLyMGbNOjYwgF =''
     for sBHvhqkdECVflUAKouLyMGbNOjYwgI in sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['program']['image']:
      if sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP0900':sBHvhqkdECVflUAKouLyMGbNOjYwxt =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
      elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP1800':sBHvhqkdECVflUAKouLyMGbNOjYwgR=sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
      elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP2000':sBHvhqkdECVflUAKouLyMGbNOjYwgc =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
      elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP1900':sBHvhqkdECVflUAKouLyMGbNOjYwgx =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
      elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP0200':sBHvhqkdECVflUAKouLyMGbNOjYwgF =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
      elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP0500':sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
      elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP0800':sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     if sBHvhqkdECVflUAKouLyMGbNOjYwxi=='':
      for sBHvhqkdECVflUAKouLyMGbNOjYwgI in sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['channel']['image']:
       if sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIC0400':sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
       elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIC1400':sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
       elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIC1900':sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
    except:
     sBHvhqkdECVflUAKouLyMGbNOjYwIe
    try:
     sBHvhqkdECVflUAKouLyMGbNOjYwgJ =[]
     sBHvhqkdECVflUAKouLyMGbNOjYwgr=[]
     sBHvhqkdECVflUAKouLyMGbNOjYwga =[]
     sBHvhqkdECVflUAKouLyMGbNOjYwgD=''
     sBHvhqkdECVflUAKouLyMGbNOjYwgn=''
     sBHvhqkdECVflUAKouLyMGbNOjYwgW=''
     for sBHvhqkdECVflUAKouLyMGbNOjYwgX in sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('schedule').get('program').get('actor'):
      if sBHvhqkdECVflUAKouLyMGbNOjYwgX!='' and sBHvhqkdECVflUAKouLyMGbNOjYwgX!=u'없음':sBHvhqkdECVflUAKouLyMGbNOjYwgJ.append(sBHvhqkdECVflUAKouLyMGbNOjYwgX)
     for sBHvhqkdECVflUAKouLyMGbNOjYwge in sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('schedule').get('program').get('director'):
      if sBHvhqkdECVflUAKouLyMGbNOjYwge!='' and sBHvhqkdECVflUAKouLyMGbNOjYwge!='-' and sBHvhqkdECVflUAKouLyMGbNOjYwge!=u'없음':sBHvhqkdECVflUAKouLyMGbNOjYwgr.append(sBHvhqkdECVflUAKouLyMGbNOjYwge)
     if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('schedule').get('program').get('category1_name').get('ko')!='':
      sBHvhqkdECVflUAKouLyMGbNOjYwga.append(sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['program']['category1_name']['ko'])
     if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('schedule').get('program').get('category2_name').get('ko')!='':
      sBHvhqkdECVflUAKouLyMGbNOjYwga.append(sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['program']['category2_name']['ko'])
     if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('schedule').get('program').get('product_year'):sBHvhqkdECVflUAKouLyMGbNOjYwgD=sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['program']['product_year']
     if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('schedule').get('program').get('grade_code') :sBHvhqkdECVflUAKouLyMGbNOjYwgn= sBHvhqkdECVflUAKouLyMGbNOjYwRg.get(sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['program']['grade_code'])
     if 'broad_dt' in sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('schedule').get('program'):
      sBHvhqkdECVflUAKouLyMGbNOjYwgP =sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('schedule').get('program').get('broad_dt')
      sBHvhqkdECVflUAKouLyMGbNOjYwgW='%s-%s-%s'%(sBHvhqkdECVflUAKouLyMGbNOjYwgP[:4],sBHvhqkdECVflUAKouLyMGbNOjYwgP[4:6],sBHvhqkdECVflUAKouLyMGbNOjYwgP[6:])
    except:
     sBHvhqkdECVflUAKouLyMGbNOjYwIe
    sBHvhqkdECVflUAKouLyMGbNOjYwxQ=sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['broadcast_start_time'])[8:12]
    sBHvhqkdECVflUAKouLyMGbNOjYwgS =sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwcS['schedule']['broadcast_end_time'])[8:12]
    sBHvhqkdECVflUAKouLyMGbNOjYwgT={'channel':sBHvhqkdECVflUAKouLyMGbNOjYwxT,'title':sBHvhqkdECVflUAKouLyMGbNOjYwxp,'mediacode':sBHvhqkdECVflUAKouLyMGbNOjYwxm,'thumbnail':{'poster':sBHvhqkdECVflUAKouLyMGbNOjYwxt,'thumb':sBHvhqkdECVflUAKouLyMGbNOjYwxi,'clearlogo':sBHvhqkdECVflUAKouLyMGbNOjYwgR,'icon':sBHvhqkdECVflUAKouLyMGbNOjYwgc,'fanart':sBHvhqkdECVflUAKouLyMGbNOjYwgF},'synopsis':sBHvhqkdECVflUAKouLyMGbNOjYwxz,'channelepg':' [%s:%s ~ %s:%s]'%(sBHvhqkdECVflUAKouLyMGbNOjYwxQ[0:2],sBHvhqkdECVflUAKouLyMGbNOjYwxQ[2:],sBHvhqkdECVflUAKouLyMGbNOjYwgS[0:2],sBHvhqkdECVflUAKouLyMGbNOjYwgS[2:]),'cast':sBHvhqkdECVflUAKouLyMGbNOjYwgJ,'director':sBHvhqkdECVflUAKouLyMGbNOjYwgr,'info_genre':sBHvhqkdECVflUAKouLyMGbNOjYwga,'year':sBHvhqkdECVflUAKouLyMGbNOjYwgD,'mpaa':sBHvhqkdECVflUAKouLyMGbNOjYwgn,'premiered':sBHvhqkdECVflUAKouLyMGbNOjYwgW}
    sBHvhqkdECVflUAKouLyMGbNOjYwcn.append(sBHvhqkdECVflUAKouLyMGbNOjYwgT)
   if sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['has_more']=='Y':
    sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIT
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
  return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
 def GetProgramList(sBHvhqkdECVflUAKouLyMGbNOjYwRF,genre,orderby,page_int,genreCode='all'):
  sBHvhqkdECVflUAKouLyMGbNOjYwcn=[]
  sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIP
  try:
   if genre=='PARAMOUNT':
    sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v2/media/paramount/episodes'
   else:
    sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v2/media/episodes'
   sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams()
   sBHvhqkdECVflUAKouLyMGbNOjYwce={'cacheType':'main','pageSize':sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwRF.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':sBHvhqkdECVflUAKouLyMGbNOjYwIi(page_int),}
   if genre not in['all','PARAMOUNT']:sBHvhqkdECVflUAKouLyMGbNOjYwce['categoryCode']=genre
   if genreCode!='all' :sBHvhqkdECVflUAKouLyMGbNOjYwce['genreCode'] =genreCode 
   sBHvhqkdECVflUAKouLyMGbNOjYwci.update(sBHvhqkdECVflUAKouLyMGbNOjYwce)
   sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwca
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwci,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe)
   sBHvhqkdECVflUAKouLyMGbNOjYwcP=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   if not('result' in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']):return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
   sBHvhqkdECVflUAKouLyMGbNOjYwxS=sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['result']
   for sBHvhqkdECVflUAKouLyMGbNOjYwcS in sBHvhqkdECVflUAKouLyMGbNOjYwxS:
    sBHvhqkdECVflUAKouLyMGbNOjYwgQ=sBHvhqkdECVflUAKouLyMGbNOjYwcS['program']['code']
    sBHvhqkdECVflUAKouLyMGbNOjYwxp =sBHvhqkdECVflUAKouLyMGbNOjYwcS['program']['name']['ko']
    sBHvhqkdECVflUAKouLyMGbNOjYwgn =sBHvhqkdECVflUAKouLyMGbNOjYwRg.get(sBHvhqkdECVflUAKouLyMGbNOjYwcS['program'].get('grade_code'))
    sBHvhqkdECVflUAKouLyMGbNOjYwxt =''
    sBHvhqkdECVflUAKouLyMGbNOjYwxi =''
    sBHvhqkdECVflUAKouLyMGbNOjYwgR=''
    sBHvhqkdECVflUAKouLyMGbNOjYwgc =''
    sBHvhqkdECVflUAKouLyMGbNOjYwgx =''
    for sBHvhqkdECVflUAKouLyMGbNOjYwgI in sBHvhqkdECVflUAKouLyMGbNOjYwcS['program']['image']:
     if sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP0900':sBHvhqkdECVflUAKouLyMGbNOjYwxt =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP0200':sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP1800':sBHvhqkdECVflUAKouLyMGbNOjYwgR=sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP2000':sBHvhqkdECVflUAKouLyMGbNOjYwgc =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP1900':sBHvhqkdECVflUAKouLyMGbNOjYwgx =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
    sBHvhqkdECVflUAKouLyMGbNOjYwxz =sBHvhqkdECVflUAKouLyMGbNOjYwcS['program']['synopsis']['ko']
    try:
     sBHvhqkdECVflUAKouLyMGbNOjYwgm=sBHvhqkdECVflUAKouLyMGbNOjYwcS['channel']['name']['ko']
    except:
     sBHvhqkdECVflUAKouLyMGbNOjYwgm=''
    try:
     sBHvhqkdECVflUAKouLyMGbNOjYwgJ =[]
     sBHvhqkdECVflUAKouLyMGbNOjYwgr=[]
     sBHvhqkdECVflUAKouLyMGbNOjYwga =[]
     sBHvhqkdECVflUAKouLyMGbNOjYwgD =''
     sBHvhqkdECVflUAKouLyMGbNOjYwgW=''
     for sBHvhqkdECVflUAKouLyMGbNOjYwgX in sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('program').get('actor'):
      if sBHvhqkdECVflUAKouLyMGbNOjYwgX!='' and sBHvhqkdECVflUAKouLyMGbNOjYwgX!='-' and sBHvhqkdECVflUAKouLyMGbNOjYwgX!=u'없음':sBHvhqkdECVflUAKouLyMGbNOjYwgJ.append(sBHvhqkdECVflUAKouLyMGbNOjYwgX)
     for sBHvhqkdECVflUAKouLyMGbNOjYwge in sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('program').get('director'):
      if sBHvhqkdECVflUAKouLyMGbNOjYwge!='' and sBHvhqkdECVflUAKouLyMGbNOjYwge!='-' and sBHvhqkdECVflUAKouLyMGbNOjYwge!=u'없음':sBHvhqkdECVflUAKouLyMGbNOjYwgr.append(sBHvhqkdECVflUAKouLyMGbNOjYwge)
     if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('program').get('category1_name').get('ko')!='':
      sBHvhqkdECVflUAKouLyMGbNOjYwga.append(sBHvhqkdECVflUAKouLyMGbNOjYwcS['program']['category1_name']['ko'])
     if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('program').get('category2_name').get('ko')!='':
      sBHvhqkdECVflUAKouLyMGbNOjYwga.append(sBHvhqkdECVflUAKouLyMGbNOjYwcS['program']['category2_name']['ko'])
     if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('program').get('product_year'):sBHvhqkdECVflUAKouLyMGbNOjYwgD=sBHvhqkdECVflUAKouLyMGbNOjYwcS['program']['product_year']
     if 'broad_dt' in sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('program'):
      sBHvhqkdECVflUAKouLyMGbNOjYwgP =sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('program').get('broad_dt')
      sBHvhqkdECVflUAKouLyMGbNOjYwgW='%s-%s-%s'%(sBHvhqkdECVflUAKouLyMGbNOjYwgP[:4],sBHvhqkdECVflUAKouLyMGbNOjYwgP[4:6],sBHvhqkdECVflUAKouLyMGbNOjYwgP[6:])
    except:
     sBHvhqkdECVflUAKouLyMGbNOjYwIe
    sBHvhqkdECVflUAKouLyMGbNOjYwgT={'program':sBHvhqkdECVflUAKouLyMGbNOjYwgQ,'title':sBHvhqkdECVflUAKouLyMGbNOjYwxp,'thumbnail':{'poster':sBHvhqkdECVflUAKouLyMGbNOjYwxt,'thumb':sBHvhqkdECVflUAKouLyMGbNOjYwxi,'clearlogo':sBHvhqkdECVflUAKouLyMGbNOjYwgR,'icon':sBHvhqkdECVflUAKouLyMGbNOjYwgc,'banner':sBHvhqkdECVflUAKouLyMGbNOjYwgx,'fanart':sBHvhqkdECVflUAKouLyMGbNOjYwxi},'synopsis':sBHvhqkdECVflUAKouLyMGbNOjYwxz,'channel':sBHvhqkdECVflUAKouLyMGbNOjYwgm,'cast':sBHvhqkdECVflUAKouLyMGbNOjYwgJ,'director':sBHvhqkdECVflUAKouLyMGbNOjYwgr,'info_genre':sBHvhqkdECVflUAKouLyMGbNOjYwga,'year':sBHvhqkdECVflUAKouLyMGbNOjYwgD,'premiered':sBHvhqkdECVflUAKouLyMGbNOjYwgW,'mpaa':sBHvhqkdECVflUAKouLyMGbNOjYwgn}
    sBHvhqkdECVflUAKouLyMGbNOjYwcn.append(sBHvhqkdECVflUAKouLyMGbNOjYwgT)
   if sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['has_more']=='Y':sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIT
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
  return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
 def Get_UHD_ProgramList(sBHvhqkdECVflUAKouLyMGbNOjYwRF,page_int):
  sBHvhqkdECVflUAKouLyMGbNOjYwcn=[]
  sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIP
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v2/operator/highlights'
   sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams(uhd=sBHvhqkdECVflUAKouLyMGbNOjYwIT)
   sBHvhqkdECVflUAKouLyMGbNOjYwce={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':sBHvhqkdECVflUAKouLyMGbNOjYwIi(page_int),'pocType':'APP_X_TVING_4.0.0',}
   sBHvhqkdECVflUAKouLyMGbNOjYwci.update(sBHvhqkdECVflUAKouLyMGbNOjYwce)
   sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwca
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwci,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe)
   sBHvhqkdECVflUAKouLyMGbNOjYwcP=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   if not('result' in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']):return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
   sBHvhqkdECVflUAKouLyMGbNOjYwxS=sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['result']
   for sBHvhqkdECVflUAKouLyMGbNOjYwcS in sBHvhqkdECVflUAKouLyMGbNOjYwxS:
    sBHvhqkdECVflUAKouLyMGbNOjYwgp=sBHvhqkdECVflUAKouLyMGbNOjYwcS['content']['program']
    sBHvhqkdECVflUAKouLyMGbNOjYwgz =sBHvhqkdECVflUAKouLyMGbNOjYwgp['code']
    sBHvhqkdECVflUAKouLyMGbNOjYwxp =sBHvhqkdECVflUAKouLyMGbNOjYwgp['name']['ko'].strip()
    sBHvhqkdECVflUAKouLyMGbNOjYwgn =sBHvhqkdECVflUAKouLyMGbNOjYwRg.get(sBHvhqkdECVflUAKouLyMGbNOjYwgp.get('grade_code'))
    sBHvhqkdECVflUAKouLyMGbNOjYwxz =sBHvhqkdECVflUAKouLyMGbNOjYwgp['synopsis']['ko']
    sBHvhqkdECVflUAKouLyMGbNOjYwgm =sBHvhqkdECVflUAKouLyMGbNOjYwcS['content']['channel']['name']['ko']
    sBHvhqkdECVflUAKouLyMGbNOjYwgD =sBHvhqkdECVflUAKouLyMGbNOjYwgp['product_year']
    sBHvhqkdECVflUAKouLyMGbNOjYwxt =''
    sBHvhqkdECVflUAKouLyMGbNOjYwxi =''
    sBHvhqkdECVflUAKouLyMGbNOjYwgR=''
    sBHvhqkdECVflUAKouLyMGbNOjYwgc =''
    sBHvhqkdECVflUAKouLyMGbNOjYwgx =''
    for sBHvhqkdECVflUAKouLyMGbNOjYwgI in sBHvhqkdECVflUAKouLyMGbNOjYwgp['image']:
     if sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP0900':sBHvhqkdECVflUAKouLyMGbNOjYwxt =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP0200':sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP1800':sBHvhqkdECVflUAKouLyMGbNOjYwgR=sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP2000':sBHvhqkdECVflUAKouLyMGbNOjYwgc =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP1900':sBHvhqkdECVflUAKouLyMGbNOjYwgx =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
    sBHvhqkdECVflUAKouLyMGbNOjYwga =[]
    sBHvhqkdECVflUAKouLyMGbNOjYwgJ =[]
    sBHvhqkdECVflUAKouLyMGbNOjYwgr=[]
    sBHvhqkdECVflUAKouLyMGbNOjYwgW =''
    if sBHvhqkdECVflUAKouLyMGbNOjYwgp.get('category1_name').get('ko')!='':
     sBHvhqkdECVflUAKouLyMGbNOjYwga.append(sBHvhqkdECVflUAKouLyMGbNOjYwgp['category1_name']['ko'])
    if sBHvhqkdECVflUAKouLyMGbNOjYwgp.get('category2_name').get('ko')!='':
     sBHvhqkdECVflUAKouLyMGbNOjYwga.append(sBHvhqkdECVflUAKouLyMGbNOjYwgp['category2_name']['ko'])
    for sBHvhqkdECVflUAKouLyMGbNOjYwgX in sBHvhqkdECVflUAKouLyMGbNOjYwgp.get('actor'):
     if sBHvhqkdECVflUAKouLyMGbNOjYwgX!='' and sBHvhqkdECVflUAKouLyMGbNOjYwgX!='-' and sBHvhqkdECVflUAKouLyMGbNOjYwgX!=u'없음':sBHvhqkdECVflUAKouLyMGbNOjYwgJ.append(sBHvhqkdECVflUAKouLyMGbNOjYwgX)
    for sBHvhqkdECVflUAKouLyMGbNOjYwge in sBHvhqkdECVflUAKouLyMGbNOjYwgp.get('director'):
     if sBHvhqkdECVflUAKouLyMGbNOjYwge!='' and sBHvhqkdECVflUAKouLyMGbNOjYwge!='-' and sBHvhqkdECVflUAKouLyMGbNOjYwge!=u'없음':sBHvhqkdECVflUAKouLyMGbNOjYwgr.append(sBHvhqkdECVflUAKouLyMGbNOjYwge)
    if sBHvhqkdECVflUAKouLyMGbNOjYwgp.get('broad_dt')not in[sBHvhqkdECVflUAKouLyMGbNOjYwIe,'']:
     sBHvhqkdECVflUAKouLyMGbNOjYwgP =sBHvhqkdECVflUAKouLyMGbNOjYwgp.get('broad_dt')
     sBHvhqkdECVflUAKouLyMGbNOjYwgW='%s-%s-%s'%(sBHvhqkdECVflUAKouLyMGbNOjYwgP[:4],sBHvhqkdECVflUAKouLyMGbNOjYwgP[4:6],sBHvhqkdECVflUAKouLyMGbNOjYwgP[6:])
    sBHvhqkdECVflUAKouLyMGbNOjYwgT={'program':sBHvhqkdECVflUAKouLyMGbNOjYwgz,'title':sBHvhqkdECVflUAKouLyMGbNOjYwxp,'mpaa':sBHvhqkdECVflUAKouLyMGbNOjYwgn,'thumbnail':{'poster':sBHvhqkdECVflUAKouLyMGbNOjYwxt,'thumb':sBHvhqkdECVflUAKouLyMGbNOjYwxi,'clearlogo':sBHvhqkdECVflUAKouLyMGbNOjYwgR,'icon':sBHvhqkdECVflUAKouLyMGbNOjYwgc,'banner':sBHvhqkdECVflUAKouLyMGbNOjYwgx,'fanart':sBHvhqkdECVflUAKouLyMGbNOjYwxi},'channel':sBHvhqkdECVflUAKouLyMGbNOjYwgm,'synopsis':sBHvhqkdECVflUAKouLyMGbNOjYwxz,'year':sBHvhqkdECVflUAKouLyMGbNOjYwgD,'info_genre':sBHvhqkdECVflUAKouLyMGbNOjYwga,'cast':sBHvhqkdECVflUAKouLyMGbNOjYwgJ,'director':sBHvhqkdECVflUAKouLyMGbNOjYwgr,'premiered':sBHvhqkdECVflUAKouLyMGbNOjYwgW,}
    sBHvhqkdECVflUAKouLyMGbNOjYwcn.append(sBHvhqkdECVflUAKouLyMGbNOjYwgT)
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
  return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
 def Get_Origianl_ProgramList(sBHvhqkdECVflUAKouLyMGbNOjYwRF,page_int):
  sBHvhqkdECVflUAKouLyMGbNOjYwcn=[]
  sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIP
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v2/media/band/originals'
   sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams()
   sBHvhqkdECVflUAKouLyMGbNOjYwce={'pageSize':sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwRF.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':sBHvhqkdECVflUAKouLyMGbNOjYwIi(page_int),}
   sBHvhqkdECVflUAKouLyMGbNOjYwci.update(sBHvhqkdECVflUAKouLyMGbNOjYwce)
   sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwca
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwci,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe)
   sBHvhqkdECVflUAKouLyMGbNOjYwcP=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   if not('contents' in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']):return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
   sBHvhqkdECVflUAKouLyMGbNOjYwxS=sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['contents']
   for sBHvhqkdECVflUAKouLyMGbNOjYwcS in sBHvhqkdECVflUAKouLyMGbNOjYwxS:
    sBHvhqkdECVflUAKouLyMGbNOjYwgQ=sBHvhqkdECVflUAKouLyMGbNOjYwcS['vod_code']
    sBHvhqkdECVflUAKouLyMGbNOjYwxp =sBHvhqkdECVflUAKouLyMGbNOjYwcS['vod_name']
    sBHvhqkdECVflUAKouLyMGbNOjYwxt =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwcS['image']
    sBHvhqkdECVflUAKouLyMGbNOjYwgT={'program':sBHvhqkdECVflUAKouLyMGbNOjYwgQ,'title':sBHvhqkdECVflUAKouLyMGbNOjYwxp,'thumbnail':{'poster':sBHvhqkdECVflUAKouLyMGbNOjYwxt,'thumb':sBHvhqkdECVflUAKouLyMGbNOjYwxt}}
    sBHvhqkdECVflUAKouLyMGbNOjYwcn.append(sBHvhqkdECVflUAKouLyMGbNOjYwgT)
   if sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['has_more']=='Y':sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIT
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
  return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
 def GetEpisodeList(sBHvhqkdECVflUAKouLyMGbNOjYwRF,program_code,page_int,orderby='desc'):
  sBHvhqkdECVflUAKouLyMGbNOjYwcn=[]
  sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIP
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v2/media/frequency/program/'+program_code
   sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams()
   sBHvhqkdECVflUAKouLyMGbNOjYwce={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   sBHvhqkdECVflUAKouLyMGbNOjYwci.update(sBHvhqkdECVflUAKouLyMGbNOjYwce)
   sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwca
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwci,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe)
   sBHvhqkdECVflUAKouLyMGbNOjYwcP=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   if not('result' in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']):return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
   sBHvhqkdECVflUAKouLyMGbNOjYwxS=sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['result']
   sBHvhqkdECVflUAKouLyMGbNOjYwgi=sBHvhqkdECVflUAKouLyMGbNOjYwIQ(sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['total_count'])
   sBHvhqkdECVflUAKouLyMGbNOjYwgt =sBHvhqkdECVflUAKouLyMGbNOjYwIQ(sBHvhqkdECVflUAKouLyMGbNOjYwgi//(sBHvhqkdECVflUAKouLyMGbNOjYwRF.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    sBHvhqkdECVflUAKouLyMGbNOjYwFR =(sBHvhqkdECVflUAKouLyMGbNOjYwgi-1)-((page_int-1)*sBHvhqkdECVflUAKouLyMGbNOjYwRF.EPISODE_LIMIT)
   else:
    sBHvhqkdECVflUAKouLyMGbNOjYwFR =(page_int-1)*sBHvhqkdECVflUAKouLyMGbNOjYwRF.EPISODE_LIMIT
   for i in sBHvhqkdECVflUAKouLyMGbNOjYwIm(sBHvhqkdECVflUAKouLyMGbNOjYwRF.EPISODE_LIMIT):
    if orderby=='desc':
     sBHvhqkdECVflUAKouLyMGbNOjYwFc=sBHvhqkdECVflUAKouLyMGbNOjYwFR-i
     if sBHvhqkdECVflUAKouLyMGbNOjYwFc<0:break
    else:
     sBHvhqkdECVflUAKouLyMGbNOjYwFc=sBHvhqkdECVflUAKouLyMGbNOjYwFR+i
     if sBHvhqkdECVflUAKouLyMGbNOjYwFc>=sBHvhqkdECVflUAKouLyMGbNOjYwgi:break
    sBHvhqkdECVflUAKouLyMGbNOjYwFx=sBHvhqkdECVflUAKouLyMGbNOjYwxS[sBHvhqkdECVflUAKouLyMGbNOjYwFc]['episode']['code']
    sBHvhqkdECVflUAKouLyMGbNOjYwxp =sBHvhqkdECVflUAKouLyMGbNOjYwxS[sBHvhqkdECVflUAKouLyMGbNOjYwFc]['vod_name']['ko']
    sBHvhqkdECVflUAKouLyMGbNOjYwFg =''
    try:
     sBHvhqkdECVflUAKouLyMGbNOjYwgP=sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwxS[sBHvhqkdECVflUAKouLyMGbNOjYwFc]['episode']['broadcast_date'])
     sBHvhqkdECVflUAKouLyMGbNOjYwFg='%s-%s-%s'%(sBHvhqkdECVflUAKouLyMGbNOjYwgP[:4],sBHvhqkdECVflUAKouLyMGbNOjYwgP[4:6],sBHvhqkdECVflUAKouLyMGbNOjYwgP[6:])
    except:
     sBHvhqkdECVflUAKouLyMGbNOjYwIe
    try:
     if sBHvhqkdECVflUAKouLyMGbNOjYwxS[sBHvhqkdECVflUAKouLyMGbNOjYwFc]['episode']['pip_cliptype']=='C012':
      sBHvhqkdECVflUAKouLyMGbNOjYwFg+=' - Quick VOD'
    except:
     sBHvhqkdECVflUAKouLyMGbNOjYwIe
    sBHvhqkdECVflUAKouLyMGbNOjYwxz =sBHvhqkdECVflUAKouLyMGbNOjYwxS[sBHvhqkdECVflUAKouLyMGbNOjYwFc]['episode']['synopsis']['ko']
    sBHvhqkdECVflUAKouLyMGbNOjYwxt =''
    sBHvhqkdECVflUAKouLyMGbNOjYwxi =''
    sBHvhqkdECVflUAKouLyMGbNOjYwgR=''
    sBHvhqkdECVflUAKouLyMGbNOjYwgc =''
    sBHvhqkdECVflUAKouLyMGbNOjYwgx =''
    sBHvhqkdECVflUAKouLyMGbNOjYwgF =''
    for sBHvhqkdECVflUAKouLyMGbNOjYwgI in sBHvhqkdECVflUAKouLyMGbNOjYwxS[sBHvhqkdECVflUAKouLyMGbNOjYwFc]['program']['image']:
     if sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP0900':sBHvhqkdECVflUAKouLyMGbNOjYwxt =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP1800':sBHvhqkdECVflUAKouLyMGbNOjYwgR=sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP2000':sBHvhqkdECVflUAKouLyMGbNOjYwgc =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP1900':sBHvhqkdECVflUAKouLyMGbNOjYwgx =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIP0200':sBHvhqkdECVflUAKouLyMGbNOjYwgF =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
    for sBHvhqkdECVflUAKouLyMGbNOjYwgI in sBHvhqkdECVflUAKouLyMGbNOjYwxS[sBHvhqkdECVflUAKouLyMGbNOjYwFc]['episode']['image']:
     if sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIE0400':sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
    try:
     sBHvhqkdECVflUAKouLyMGbNOjYwFI=sBHvhqkdECVflUAKouLyMGbNOjYwFr=sBHvhqkdECVflUAKouLyMGbNOjYwFa=''
     sBHvhqkdECVflUAKouLyMGbNOjYwFJ=0
     sBHvhqkdECVflUAKouLyMGbNOjYwFI =sBHvhqkdECVflUAKouLyMGbNOjYwxS[sBHvhqkdECVflUAKouLyMGbNOjYwFc]['program']['name']['ko']
     sBHvhqkdECVflUAKouLyMGbNOjYwFr =sBHvhqkdECVflUAKouLyMGbNOjYwFg
     sBHvhqkdECVflUAKouLyMGbNOjYwFa =sBHvhqkdECVflUAKouLyMGbNOjYwxS[sBHvhqkdECVflUAKouLyMGbNOjYwFc]['channel']['name']['ko']
     if 'frequency' in sBHvhqkdECVflUAKouLyMGbNOjYwxS[sBHvhqkdECVflUAKouLyMGbNOjYwFc]['episode']:sBHvhqkdECVflUAKouLyMGbNOjYwFJ=sBHvhqkdECVflUAKouLyMGbNOjYwxS[sBHvhqkdECVflUAKouLyMGbNOjYwFc]['episode']['frequency']
    except:
     sBHvhqkdECVflUAKouLyMGbNOjYwIe
    sBHvhqkdECVflUAKouLyMGbNOjYwgT={'episode':sBHvhqkdECVflUAKouLyMGbNOjYwFx,'title':sBHvhqkdECVflUAKouLyMGbNOjYwxp,'subtitle':sBHvhqkdECVflUAKouLyMGbNOjYwFg,'thumbnail':{'poster':sBHvhqkdECVflUAKouLyMGbNOjYwxt,'thumb':sBHvhqkdECVflUAKouLyMGbNOjYwxi,'clearlogo':sBHvhqkdECVflUAKouLyMGbNOjYwgR,'icon':sBHvhqkdECVflUAKouLyMGbNOjYwgc,'banner':sBHvhqkdECVflUAKouLyMGbNOjYwgx,'fanart':sBHvhqkdECVflUAKouLyMGbNOjYwgF},'synopsis':sBHvhqkdECVflUAKouLyMGbNOjYwxz,'info_title':sBHvhqkdECVflUAKouLyMGbNOjYwFI,'aired':sBHvhqkdECVflUAKouLyMGbNOjYwFr,'studio':sBHvhqkdECVflUAKouLyMGbNOjYwFa,'frequency':sBHvhqkdECVflUAKouLyMGbNOjYwFJ}
    sBHvhqkdECVflUAKouLyMGbNOjYwcn.append(sBHvhqkdECVflUAKouLyMGbNOjYwgT)
   if sBHvhqkdECVflUAKouLyMGbNOjYwgt>page_int:sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIT
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
  return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe,sBHvhqkdECVflUAKouLyMGbNOjYwgt
 def GetMovieList(sBHvhqkdECVflUAKouLyMGbNOjYwRF,genre,orderby,page_int):
  sBHvhqkdECVflUAKouLyMGbNOjYwcn=[]
  sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIP
  try:
   if genre=='PARAMOUNT':
    sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v2/media/paramount/movies'
   else:
    sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v2/media/movies'
   sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams()
   sBHvhqkdECVflUAKouLyMGbNOjYwce={'pageSize':sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwRF.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':sBHvhqkdECVflUAKouLyMGbNOjYwIi(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:sBHvhqkdECVflUAKouLyMGbNOjYwce['categoryCode']=genre
   sBHvhqkdECVflUAKouLyMGbNOjYwce['productPackageCode']=','.join(sBHvhqkdECVflUAKouLyMGbNOjYwRF.MOVIE_LITE)
   sBHvhqkdECVflUAKouLyMGbNOjYwci.update(sBHvhqkdECVflUAKouLyMGbNOjYwce)
   sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwca
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwci,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe)
   sBHvhqkdECVflUAKouLyMGbNOjYwcP=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   if not('result' in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']):return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
   sBHvhqkdECVflUAKouLyMGbNOjYwxS=sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['result']
   for sBHvhqkdECVflUAKouLyMGbNOjYwcS in sBHvhqkdECVflUAKouLyMGbNOjYwxS:
    if 'release_date' in sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('movie'):
     sBHvhqkdECVflUAKouLyMGbNOjYwgD=sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('movie').get('release_date'))[:4]
    else:
     sBHvhqkdECVflUAKouLyMGbNOjYwgD=sBHvhqkdECVflUAKouLyMGbNOjYwIe
    sBHvhqkdECVflUAKouLyMGbNOjYwFD =sBHvhqkdECVflUAKouLyMGbNOjYwcS['movie']['code']
    sBHvhqkdECVflUAKouLyMGbNOjYwxp =sBHvhqkdECVflUAKouLyMGbNOjYwcS['movie']['name']['ko'].strip()
    if sBHvhqkdECVflUAKouLyMGbNOjYwgD not in[sBHvhqkdECVflUAKouLyMGbNOjYwIe,'0','']:sBHvhqkdECVflUAKouLyMGbNOjYwxp+=u' (%s)'%(sBHvhqkdECVflUAKouLyMGbNOjYwgD)
    sBHvhqkdECVflUAKouLyMGbNOjYwxt=''
    sBHvhqkdECVflUAKouLyMGbNOjYwxi =''
    sBHvhqkdECVflUAKouLyMGbNOjYwgR=''
    for sBHvhqkdECVflUAKouLyMGbNOjYwgI in sBHvhqkdECVflUAKouLyMGbNOjYwcS['movie']['image']:
     if sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIM2100':sBHvhqkdECVflUAKouLyMGbNOjYwxt =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIM0400':sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIM1800':sBHvhqkdECVflUAKouLyMGbNOjYwgR=sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
    sBHvhqkdECVflUAKouLyMGbNOjYwxz =sBHvhqkdECVflUAKouLyMGbNOjYwcS['movie']['story']['ko']
    try:
     sBHvhqkdECVflUAKouLyMGbNOjYwFI =sBHvhqkdECVflUAKouLyMGbNOjYwcS['movie']['name']['ko'].strip()
     sBHvhqkdECVflUAKouLyMGbNOjYwgn =sBHvhqkdECVflUAKouLyMGbNOjYwRg.get(sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('grade_code'))
     sBHvhqkdECVflUAKouLyMGbNOjYwgJ=[]
     sBHvhqkdECVflUAKouLyMGbNOjYwgr=[]
     sBHvhqkdECVflUAKouLyMGbNOjYwga=[]
     sBHvhqkdECVflUAKouLyMGbNOjYwFn=0
     sBHvhqkdECVflUAKouLyMGbNOjYwgW=''
     sBHvhqkdECVflUAKouLyMGbNOjYwFa =''
     for sBHvhqkdECVflUAKouLyMGbNOjYwgX in sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('movie').get('actor'):
      if sBHvhqkdECVflUAKouLyMGbNOjYwgX!='':sBHvhqkdECVflUAKouLyMGbNOjYwgJ.append(sBHvhqkdECVflUAKouLyMGbNOjYwgX)
     for sBHvhqkdECVflUAKouLyMGbNOjYwge in sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('movie').get('director'):
      if sBHvhqkdECVflUAKouLyMGbNOjYwge!='':sBHvhqkdECVflUAKouLyMGbNOjYwgr.append(sBHvhqkdECVflUAKouLyMGbNOjYwge)
     if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('movie').get('category1_name').get('ko')!='':
      sBHvhqkdECVflUAKouLyMGbNOjYwga.append(sBHvhqkdECVflUAKouLyMGbNOjYwcS['movie']['category1_name']['ko'])
     if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('movie').get('category2_name').get('ko')!='':
      sBHvhqkdECVflUAKouLyMGbNOjYwga.append(sBHvhqkdECVflUAKouLyMGbNOjYwcS['movie']['category2_name']['ko'])
     if 'duration' in sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('movie'):sBHvhqkdECVflUAKouLyMGbNOjYwFn=sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('movie').get('duration')
     if 'release_date' in sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('movie'):
      sBHvhqkdECVflUAKouLyMGbNOjYwgP=sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('movie').get('release_date'))
      if sBHvhqkdECVflUAKouLyMGbNOjYwgP!='0':sBHvhqkdECVflUAKouLyMGbNOjYwgW='%s-%s-%s'%(sBHvhqkdECVflUAKouLyMGbNOjYwgP[:4],sBHvhqkdECVflUAKouLyMGbNOjYwgP[4:6],sBHvhqkdECVflUAKouLyMGbNOjYwgP[6:])
     if 'production' in sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('movie'):sBHvhqkdECVflUAKouLyMGbNOjYwFa=sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('movie').get('production')
    except:
     sBHvhqkdECVflUAKouLyMGbNOjYwIe
    sBHvhqkdECVflUAKouLyMGbNOjYwgT={'moviecode':sBHvhqkdECVflUAKouLyMGbNOjYwFD,'title':sBHvhqkdECVflUAKouLyMGbNOjYwxp,'thumbnail':{'poster':sBHvhqkdECVflUAKouLyMGbNOjYwxt,'thumb':sBHvhqkdECVflUAKouLyMGbNOjYwxi,'clearlogo':sBHvhqkdECVflUAKouLyMGbNOjYwgR,'fanart':sBHvhqkdECVflUAKouLyMGbNOjYwxi},'synopsis':sBHvhqkdECVflUAKouLyMGbNOjYwxz,'info_title':sBHvhqkdECVflUAKouLyMGbNOjYwFI,'year':sBHvhqkdECVflUAKouLyMGbNOjYwgD,'cast':sBHvhqkdECVflUAKouLyMGbNOjYwgJ,'director':sBHvhqkdECVflUAKouLyMGbNOjYwgr,'info_genre':sBHvhqkdECVflUAKouLyMGbNOjYwga,'duration':sBHvhqkdECVflUAKouLyMGbNOjYwFn,'premiered':sBHvhqkdECVflUAKouLyMGbNOjYwgW,'studio':sBHvhqkdECVflUAKouLyMGbNOjYwFa,'mpaa':sBHvhqkdECVflUAKouLyMGbNOjYwgn}
    sBHvhqkdECVflUAKouLyMGbNOjYwFW=sBHvhqkdECVflUAKouLyMGbNOjYwIP
    for sBHvhqkdECVflUAKouLyMGbNOjYwFX in sBHvhqkdECVflUAKouLyMGbNOjYwcS['billing_package_id']:
     if sBHvhqkdECVflUAKouLyMGbNOjYwFX in sBHvhqkdECVflUAKouLyMGbNOjYwRF.MOVIE_LITE:
      sBHvhqkdECVflUAKouLyMGbNOjYwFW=sBHvhqkdECVflUAKouLyMGbNOjYwIT
      break
    if sBHvhqkdECVflUAKouLyMGbNOjYwFW==sBHvhqkdECVflUAKouLyMGbNOjYwIP: 
     sBHvhqkdECVflUAKouLyMGbNOjYwgT['title']=sBHvhqkdECVflUAKouLyMGbNOjYwgT['title']+' [개별구매]'
    sBHvhqkdECVflUAKouLyMGbNOjYwcn.append(sBHvhqkdECVflUAKouLyMGbNOjYwgT)
   if sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['has_more']=='Y':sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIT
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
  return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
 def Get_UHD_MovieList(sBHvhqkdECVflUAKouLyMGbNOjYwRF,page_int):
  sBHvhqkdECVflUAKouLyMGbNOjYwcn=[]
  sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIP
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v2/operator/highlights'
   sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams(uhd=sBHvhqkdECVflUAKouLyMGbNOjYwIT)
   sBHvhqkdECVflUAKouLyMGbNOjYwce={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':sBHvhqkdECVflUAKouLyMGbNOjYwIi(page_int),'pocType':'APP_X_TVING_4.0.0',}
   sBHvhqkdECVflUAKouLyMGbNOjYwci.update(sBHvhqkdECVflUAKouLyMGbNOjYwce)
   sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwca
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwci,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe)
   sBHvhqkdECVflUAKouLyMGbNOjYwcP=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   if not('result' in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']):return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
   sBHvhqkdECVflUAKouLyMGbNOjYwxS=sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['result']
   for sBHvhqkdECVflUAKouLyMGbNOjYwcS in sBHvhqkdECVflUAKouLyMGbNOjYwxS:
    sBHvhqkdECVflUAKouLyMGbNOjYwgp=sBHvhqkdECVflUAKouLyMGbNOjYwcS['content']['movie']
    sBHvhqkdECVflUAKouLyMGbNOjYwgz =sBHvhqkdECVflUAKouLyMGbNOjYwgp['code']
    sBHvhqkdECVflUAKouLyMGbNOjYwxp =sBHvhqkdECVflUAKouLyMGbNOjYwgp['name']['ko'].strip()
    sBHvhqkdECVflUAKouLyMGbNOjYwFI =sBHvhqkdECVflUAKouLyMGbNOjYwgp['name']['ko'].strip()
    sBHvhqkdECVflUAKouLyMGbNOjYwgD =sBHvhqkdECVflUAKouLyMGbNOjYwgp['product_year']
    if sBHvhqkdECVflUAKouLyMGbNOjYwgD:sBHvhqkdECVflUAKouLyMGbNOjYwxp+=u' (%s)'%(sBHvhqkdECVflUAKouLyMGbNOjYwgp['product_year'])
    sBHvhqkdECVflUAKouLyMGbNOjYwxz =sBHvhqkdECVflUAKouLyMGbNOjYwgp['story']['ko']
    sBHvhqkdECVflUAKouLyMGbNOjYwFn =sBHvhqkdECVflUAKouLyMGbNOjYwgp['duration']
    sBHvhqkdECVflUAKouLyMGbNOjYwgn =sBHvhqkdECVflUAKouLyMGbNOjYwRg.get(sBHvhqkdECVflUAKouLyMGbNOjYwgp.get('grade_code'))
    sBHvhqkdECVflUAKouLyMGbNOjYwFa =sBHvhqkdECVflUAKouLyMGbNOjYwgp['production']
    sBHvhqkdECVflUAKouLyMGbNOjYwxt=''
    sBHvhqkdECVflUAKouLyMGbNOjYwxi =''
    sBHvhqkdECVflUAKouLyMGbNOjYwgR=''
    sBHvhqkdECVflUAKouLyMGbNOjYwga =[]
    sBHvhqkdECVflUAKouLyMGbNOjYwgJ =[]
    sBHvhqkdECVflUAKouLyMGbNOjYwgr=[]
    sBHvhqkdECVflUAKouLyMGbNOjYwgW =''
    for sBHvhqkdECVflUAKouLyMGbNOjYwgI in sBHvhqkdECVflUAKouLyMGbNOjYwgp['image']:
     if sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIM2100':sBHvhqkdECVflUAKouLyMGbNOjYwxt =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIM0400':sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
     elif sBHvhqkdECVflUAKouLyMGbNOjYwgI['code']=='CAIM1800':sBHvhqkdECVflUAKouLyMGbNOjYwgR=sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI['url']
    if sBHvhqkdECVflUAKouLyMGbNOjYwgp['release_date']not in[sBHvhqkdECVflUAKouLyMGbNOjYwIe,0]:
     sBHvhqkdECVflUAKouLyMGbNOjYwgP=sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwgp['release_date'])
     if sBHvhqkdECVflUAKouLyMGbNOjYwgP!='0':sBHvhqkdECVflUAKouLyMGbNOjYwgW='%s-%s-%s'%(sBHvhqkdECVflUAKouLyMGbNOjYwgP[:4],sBHvhqkdECVflUAKouLyMGbNOjYwgP[4:6],sBHvhqkdECVflUAKouLyMGbNOjYwgP[6:])
    if sBHvhqkdECVflUAKouLyMGbNOjYwgp.get('category1_name').get('ko')!='':
     sBHvhqkdECVflUAKouLyMGbNOjYwga.append(sBHvhqkdECVflUAKouLyMGbNOjYwgp['category1_name']['ko'])
    if sBHvhqkdECVflUAKouLyMGbNOjYwgp.get('category2_name').get('ko')!='':
     sBHvhqkdECVflUAKouLyMGbNOjYwga.append(sBHvhqkdECVflUAKouLyMGbNOjYwgp['category2_name']['ko'])
    for sBHvhqkdECVflUAKouLyMGbNOjYwgX in sBHvhqkdECVflUAKouLyMGbNOjYwgp.get('actor'):
     if sBHvhqkdECVflUAKouLyMGbNOjYwgX!='':sBHvhqkdECVflUAKouLyMGbNOjYwgJ.append(sBHvhqkdECVflUAKouLyMGbNOjYwgX)
    for sBHvhqkdECVflUAKouLyMGbNOjYwge in sBHvhqkdECVflUAKouLyMGbNOjYwgp.get('director'):
     if sBHvhqkdECVflUAKouLyMGbNOjYwge!='':sBHvhqkdECVflUAKouLyMGbNOjYwgr.append(sBHvhqkdECVflUAKouLyMGbNOjYwge)
    sBHvhqkdECVflUAKouLyMGbNOjYwgT={'moviecode':sBHvhqkdECVflUAKouLyMGbNOjYwgz,'title':sBHvhqkdECVflUAKouLyMGbNOjYwxp,'thumbnail':{'poster':sBHvhqkdECVflUAKouLyMGbNOjYwxt,'thumb':sBHvhqkdECVflUAKouLyMGbNOjYwxi,'clearlogo':sBHvhqkdECVflUAKouLyMGbNOjYwgR,'fanart':sBHvhqkdECVflUAKouLyMGbNOjYwxi},'year':sBHvhqkdECVflUAKouLyMGbNOjYwgD,'info_title':sBHvhqkdECVflUAKouLyMGbNOjYwFI,'synopsis':sBHvhqkdECVflUAKouLyMGbNOjYwxz,'mpaa':sBHvhqkdECVflUAKouLyMGbNOjYwgn,'duration':sBHvhqkdECVflUAKouLyMGbNOjYwFn,'premiered':sBHvhqkdECVflUAKouLyMGbNOjYwgW,'studio':sBHvhqkdECVflUAKouLyMGbNOjYwFa,'info_genre':sBHvhqkdECVflUAKouLyMGbNOjYwga,'cast':sBHvhqkdECVflUAKouLyMGbNOjYwgJ,'director':sBHvhqkdECVflUAKouLyMGbNOjYwgr,}
    sBHvhqkdECVflUAKouLyMGbNOjYwcn.append(sBHvhqkdECVflUAKouLyMGbNOjYwgT)
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
  return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
 def GetMovieGenre(sBHvhqkdECVflUAKouLyMGbNOjYwRF):
  sBHvhqkdECVflUAKouLyMGbNOjYwcn=[]
  sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIP
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v2/media/movie/curations'
   sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams()
   sBHvhqkdECVflUAKouLyMGbNOjYwce={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   sBHvhqkdECVflUAKouLyMGbNOjYwci.update(sBHvhqkdECVflUAKouLyMGbNOjYwce)
   sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwca
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwci,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe)
   sBHvhqkdECVflUAKouLyMGbNOjYwcP=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   if not('result' in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']):return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
   sBHvhqkdECVflUAKouLyMGbNOjYwxS=sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['result']
   for sBHvhqkdECVflUAKouLyMGbNOjYwcS in sBHvhqkdECVflUAKouLyMGbNOjYwxS:
    sBHvhqkdECVflUAKouLyMGbNOjYwFe =sBHvhqkdECVflUAKouLyMGbNOjYwcS['curation_code']
    sBHvhqkdECVflUAKouLyMGbNOjYwFP =sBHvhqkdECVflUAKouLyMGbNOjYwcS['curation_name']
    sBHvhqkdECVflUAKouLyMGbNOjYwgT={'curation_code':sBHvhqkdECVflUAKouLyMGbNOjYwFe,'curation_name':sBHvhqkdECVflUAKouLyMGbNOjYwFP}
    sBHvhqkdECVflUAKouLyMGbNOjYwcn.append(sBHvhqkdECVflUAKouLyMGbNOjYwgT)
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
  return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
 def GetSearchList(sBHvhqkdECVflUAKouLyMGbNOjYwRF,search_key,page_int,stype):
  sBHvhqkdECVflUAKouLyMGbNOjYwFS=[]
  sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIP
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwca ='/search/getSearch.jsp'
   sBHvhqkdECVflUAKouLyMGbNOjYwce={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':sBHvhqkdECVflUAKouLyMGbNOjYwIi(page_int),'pageSize':sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwRF.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':sBHvhqkdECVflUAKouLyMGbNOjYwRF.SCREENCODE,'os':sBHvhqkdECVflUAKouLyMGbNOjYwRF.OSCODE,'network':sBHvhqkdECVflUAKouLyMGbNOjYwRF.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwRF.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwRF.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.SEARCH_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwca
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwce,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe)
   sBHvhqkdECVflUAKouLyMGbNOjYwcP=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   if stype=='vod':
    if not('programRsb' in sBHvhqkdECVflUAKouLyMGbNOjYwcP):return sBHvhqkdECVflUAKouLyMGbNOjYwFS,sBHvhqkdECVflUAKouLyMGbNOjYwxe
    sBHvhqkdECVflUAKouLyMGbNOjYwFT=sBHvhqkdECVflUAKouLyMGbNOjYwcP['programRsb']['dataList']
    sBHvhqkdECVflUAKouLyMGbNOjYwFQ =sBHvhqkdECVflUAKouLyMGbNOjYwIQ(sBHvhqkdECVflUAKouLyMGbNOjYwcP['programRsb']['count'])
    for sBHvhqkdECVflUAKouLyMGbNOjYwcS in sBHvhqkdECVflUAKouLyMGbNOjYwFT:
     sBHvhqkdECVflUAKouLyMGbNOjYwgQ=sBHvhqkdECVflUAKouLyMGbNOjYwcS['mast_cd']
     sBHvhqkdECVflUAKouLyMGbNOjYwxp =sBHvhqkdECVflUAKouLyMGbNOjYwcS['mast_nm']
     sBHvhqkdECVflUAKouLyMGbNOjYwxt=sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwcS['web_url4']
     sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwcS['web_url']
     try:
      sBHvhqkdECVflUAKouLyMGbNOjYwgJ =[]
      sBHvhqkdECVflUAKouLyMGbNOjYwgr=[]
      sBHvhqkdECVflUAKouLyMGbNOjYwga =[]
      sBHvhqkdECVflUAKouLyMGbNOjYwFn =0
      sBHvhqkdECVflUAKouLyMGbNOjYwgn =''
      sBHvhqkdECVflUAKouLyMGbNOjYwgD =''
      sBHvhqkdECVflUAKouLyMGbNOjYwFr =''
      if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('actor') !='' and sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('actor') !='-':sBHvhqkdECVflUAKouLyMGbNOjYwgJ =sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('actor').split(',')
      if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('director')!='' and sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('director')!='-':sBHvhqkdECVflUAKouLyMGbNOjYwgr=sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('director').split(',')
      if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('cate_nm')!='' and sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('cate_nm')!='-':sBHvhqkdECVflUAKouLyMGbNOjYwga =sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('cate_nm').split('/')
      if 'targetage' in sBHvhqkdECVflUAKouLyMGbNOjYwcS:sBHvhqkdECVflUAKouLyMGbNOjYwgn=sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('targetage')
      if 'broad_dt' in sBHvhqkdECVflUAKouLyMGbNOjYwcS:
       sBHvhqkdECVflUAKouLyMGbNOjYwgP=sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('broad_dt')
       sBHvhqkdECVflUAKouLyMGbNOjYwFr='%s-%s-%s'%(sBHvhqkdECVflUAKouLyMGbNOjYwgP[:4],sBHvhqkdECVflUAKouLyMGbNOjYwgP[4:6],sBHvhqkdECVflUAKouLyMGbNOjYwgP[6:])
       sBHvhqkdECVflUAKouLyMGbNOjYwgD =sBHvhqkdECVflUAKouLyMGbNOjYwgP[:4]
     except:
      sBHvhqkdECVflUAKouLyMGbNOjYwIe
     sBHvhqkdECVflUAKouLyMGbNOjYwgT={'program':sBHvhqkdECVflUAKouLyMGbNOjYwgQ,'title':sBHvhqkdECVflUAKouLyMGbNOjYwxp,'thumbnail':{'poster':sBHvhqkdECVflUAKouLyMGbNOjYwxt,'thumb':sBHvhqkdECVflUAKouLyMGbNOjYwxi,'fanart':sBHvhqkdECVflUAKouLyMGbNOjYwxi},'synopsis':'','cast':sBHvhqkdECVflUAKouLyMGbNOjYwgJ,'director':sBHvhqkdECVflUAKouLyMGbNOjYwgr,'info_genre':sBHvhqkdECVflUAKouLyMGbNOjYwga,'duration':sBHvhqkdECVflUAKouLyMGbNOjYwFn,'mpaa':sBHvhqkdECVflUAKouLyMGbNOjYwgn,'year':sBHvhqkdECVflUAKouLyMGbNOjYwgD,'aired':sBHvhqkdECVflUAKouLyMGbNOjYwFr}
     sBHvhqkdECVflUAKouLyMGbNOjYwFS.append(sBHvhqkdECVflUAKouLyMGbNOjYwgT)
   else:
    if not('vodMVRsb' in sBHvhqkdECVflUAKouLyMGbNOjYwcP):return sBHvhqkdECVflUAKouLyMGbNOjYwFS,sBHvhqkdECVflUAKouLyMGbNOjYwxe
    sBHvhqkdECVflUAKouLyMGbNOjYwFm=sBHvhqkdECVflUAKouLyMGbNOjYwcP['vodMVRsb']['dataList']
    sBHvhqkdECVflUAKouLyMGbNOjYwFQ =sBHvhqkdECVflUAKouLyMGbNOjYwIQ(sBHvhqkdECVflUAKouLyMGbNOjYwcP['vodMVRsb']['count'])
    for sBHvhqkdECVflUAKouLyMGbNOjYwcS in sBHvhqkdECVflUAKouLyMGbNOjYwFm:
     sBHvhqkdECVflUAKouLyMGbNOjYwgQ=sBHvhqkdECVflUAKouLyMGbNOjYwcS['mast_cd']
     sBHvhqkdECVflUAKouLyMGbNOjYwxp =sBHvhqkdECVflUAKouLyMGbNOjYwcS['mast_nm'].strip()
     sBHvhqkdECVflUAKouLyMGbNOjYwxt =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwcS['web_url']
     sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwxt
     sBHvhqkdECVflUAKouLyMGbNOjYwgR=''
     try:
      sBHvhqkdECVflUAKouLyMGbNOjYwgJ =[]
      sBHvhqkdECVflUAKouLyMGbNOjYwgr=[]
      sBHvhqkdECVflUAKouLyMGbNOjYwga =[]
      sBHvhqkdECVflUAKouLyMGbNOjYwFn =0
      sBHvhqkdECVflUAKouLyMGbNOjYwgn =''
      sBHvhqkdECVflUAKouLyMGbNOjYwgD =''
      sBHvhqkdECVflUAKouLyMGbNOjYwFr =''
      if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('actor') !='' and sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('actor') !='-':sBHvhqkdECVflUAKouLyMGbNOjYwgJ =sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('actor').split(',')
      if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('director')!='' and sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('director')!='-':sBHvhqkdECVflUAKouLyMGbNOjYwgr=sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('director').split(',')
      if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('cate_nm')!='' and sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('cate_nm')!='-':sBHvhqkdECVflUAKouLyMGbNOjYwga =sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('cate_nm').split('/')
      if sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('runtime_sec')!='':sBHvhqkdECVflUAKouLyMGbNOjYwFn=sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('runtime_sec')
      if 'grade_nm' in sBHvhqkdECVflUAKouLyMGbNOjYwcS:sBHvhqkdECVflUAKouLyMGbNOjYwgn=sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('grade_nm')
      sBHvhqkdECVflUAKouLyMGbNOjYwgP=sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('broad_dt')
      if data_str!='':
       sBHvhqkdECVflUAKouLyMGbNOjYwFr='%s-%s-%s'%(sBHvhqkdECVflUAKouLyMGbNOjYwgP[:4],sBHvhqkdECVflUAKouLyMGbNOjYwgP[4:6],sBHvhqkdECVflUAKouLyMGbNOjYwgP[6:])
       sBHvhqkdECVflUAKouLyMGbNOjYwgD =sBHvhqkdECVflUAKouLyMGbNOjYwgP[:4]
     except:
      sBHvhqkdECVflUAKouLyMGbNOjYwIe
     sBHvhqkdECVflUAKouLyMGbNOjYwgT={'movie':sBHvhqkdECVflUAKouLyMGbNOjYwgQ,'title':sBHvhqkdECVflUAKouLyMGbNOjYwxp,'thumbnail':{'poster':sBHvhqkdECVflUAKouLyMGbNOjYwxt,'thumb':sBHvhqkdECVflUAKouLyMGbNOjYwxi,'fanart':sBHvhqkdECVflUAKouLyMGbNOjYwxi,'clearlogo':sBHvhqkdECVflUAKouLyMGbNOjYwgR},'synopsis':'','cast':sBHvhqkdECVflUAKouLyMGbNOjYwgJ,'director':sBHvhqkdECVflUAKouLyMGbNOjYwgr,'info_genre':sBHvhqkdECVflUAKouLyMGbNOjYwga,'duration':sBHvhqkdECVflUAKouLyMGbNOjYwFn,'mpaa':sBHvhqkdECVflUAKouLyMGbNOjYwgn,'year':sBHvhqkdECVflUAKouLyMGbNOjYwgD,'aired':sBHvhqkdECVflUAKouLyMGbNOjYwFr}
     sBHvhqkdECVflUAKouLyMGbNOjYwFW=sBHvhqkdECVflUAKouLyMGbNOjYwIP
     for sBHvhqkdECVflUAKouLyMGbNOjYwFX in sBHvhqkdECVflUAKouLyMGbNOjYwcS['bill']:
      if sBHvhqkdECVflUAKouLyMGbNOjYwFX in sBHvhqkdECVflUAKouLyMGbNOjYwRF.MOVIE_LITE:
       sBHvhqkdECVflUAKouLyMGbNOjYwFW=sBHvhqkdECVflUAKouLyMGbNOjYwIT
       break
     if sBHvhqkdECVflUAKouLyMGbNOjYwFW==sBHvhqkdECVflUAKouLyMGbNOjYwIP: 
      sBHvhqkdECVflUAKouLyMGbNOjYwgT['title']=sBHvhqkdECVflUAKouLyMGbNOjYwgT['title']+' [개별구매]'
     sBHvhqkdECVflUAKouLyMGbNOjYwFS.append(sBHvhqkdECVflUAKouLyMGbNOjYwgT)
   if sBHvhqkdECVflUAKouLyMGbNOjYwFQ>(page_int*sBHvhqkdECVflUAKouLyMGbNOjYwRF.SEARCH_LIMIT):sBHvhqkdECVflUAKouLyMGbNOjYwxe=sBHvhqkdECVflUAKouLyMGbNOjYwIT
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
  return sBHvhqkdECVflUAKouLyMGbNOjYwFS,sBHvhqkdECVflUAKouLyMGbNOjYwxe
 def GetBookmarkInfo(sBHvhqkdECVflUAKouLyMGbNOjYwRF,videoid,vidtype):
  sBHvhqkdECVflUAKouLyMGbNOjYwFp={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+'/v2/media/program/'+videoid
   sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams()
   sBHvhqkdECVflUAKouLyMGbNOjYwce={'pageNo':'1','pageSize':'10','order':'name',}
   sBHvhqkdECVflUAKouLyMGbNOjYwci.update(sBHvhqkdECVflUAKouLyMGbNOjYwce)
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwci,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe)
   sBHvhqkdECVflUAKouLyMGbNOjYwFz=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   if not('body' in sBHvhqkdECVflUAKouLyMGbNOjYwFz):return{}
   sBHvhqkdECVflUAKouLyMGbNOjYwFi=sBHvhqkdECVflUAKouLyMGbNOjYwFz['body']
   sBHvhqkdECVflUAKouLyMGbNOjYwxp=sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('name').get('ko').strip()
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['title'] =sBHvhqkdECVflUAKouLyMGbNOjYwxp
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['title']=sBHvhqkdECVflUAKouLyMGbNOjYwxp
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['mpaa'] =sBHvhqkdECVflUAKouLyMGbNOjYwRg.get(sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('grade_code'))
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['plot'] =sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('synopsis').get('ko')
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['year'] =sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('product_year')
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['cast'] =sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('actor')
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['director']=sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('director')
   if sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('category1_name').get('ko')!='':
    sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['genre'].append(sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('category1_name').get('ko'))
   if sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('category2_name').get('ko')!='':
    sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['genre'].append(sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('category2_name').get('ko'))
   sBHvhqkdECVflUAKouLyMGbNOjYwgP=sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('broad_dt'))
   if sBHvhqkdECVflUAKouLyMGbNOjYwgP!='0':sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(sBHvhqkdECVflUAKouLyMGbNOjYwgP[:4],sBHvhqkdECVflUAKouLyMGbNOjYwgP[4:6],sBHvhqkdECVflUAKouLyMGbNOjYwgP[6:])
   sBHvhqkdECVflUAKouLyMGbNOjYwxt =''
   sBHvhqkdECVflUAKouLyMGbNOjYwxi =''
   sBHvhqkdECVflUAKouLyMGbNOjYwgR=''
   sBHvhqkdECVflUAKouLyMGbNOjYwgc =''
   sBHvhqkdECVflUAKouLyMGbNOjYwgx =''
   for sBHvhqkdECVflUAKouLyMGbNOjYwgI in sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('image'):
    if sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('code')=='CAIP0900':sBHvhqkdECVflUAKouLyMGbNOjYwxt =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('url')
    elif sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('code')=='CAIP0200':sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('url')
    elif sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('code')=='CAIP1800':sBHvhqkdECVflUAKouLyMGbNOjYwgR=sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('url')
    elif sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('code')=='CAIP2000':sBHvhqkdECVflUAKouLyMGbNOjYwgc =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('url')
    elif sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('code')=='CAIP1900':sBHvhqkdECVflUAKouLyMGbNOjYwgx =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('url')
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['thumbnail']['poster']=sBHvhqkdECVflUAKouLyMGbNOjYwxt
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['thumbnail']['thumb']=sBHvhqkdECVflUAKouLyMGbNOjYwxi
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['thumbnail']['clearlogo']=sBHvhqkdECVflUAKouLyMGbNOjYwgR
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['thumbnail']['icon']=sBHvhqkdECVflUAKouLyMGbNOjYwgc
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['thumbnail']['banner']=sBHvhqkdECVflUAKouLyMGbNOjYwgx
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['thumbnail']['fanart']=sBHvhqkdECVflUAKouLyMGbNOjYwxi
  else:
   sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+'/v2a/media/stream/info'
   sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams()
   sBHvhqkdECVflUAKouLyMGbNOjYwce={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_uuid'].split('-')[0],'uuid':sBHvhqkdECVflUAKouLyMGbNOjYwRF.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetNoCache(1)),'wm':'Y',}
   sBHvhqkdECVflUAKouLyMGbNOjYwci.update(sBHvhqkdECVflUAKouLyMGbNOjYwce)
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwci,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe)
   sBHvhqkdECVflUAKouLyMGbNOjYwFz=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   if not('content' in sBHvhqkdECVflUAKouLyMGbNOjYwFz['body']):return{}
   sBHvhqkdECVflUAKouLyMGbNOjYwFi=sBHvhqkdECVflUAKouLyMGbNOjYwFz['body']['content']['info']['movie']
   sBHvhqkdECVflUAKouLyMGbNOjYwxp =sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('name').get('ko').strip()
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['title']=sBHvhqkdECVflUAKouLyMGbNOjYwxp
   sBHvhqkdECVflUAKouLyMGbNOjYwxp +=u' (%s)'%(sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('product_year'))
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['title'] =sBHvhqkdECVflUAKouLyMGbNOjYwxp
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['mpaa'] =sBHvhqkdECVflUAKouLyMGbNOjYwRg.get(sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('grade_code'))
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['plot'] =sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('story').get('ko')
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['year'] =sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('product_year')
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['studio'] =sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('production')
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['duration']=sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('duration')
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['cast'] =sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('actor')
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['director']=sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('director')
   if sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('category1_name').get('ko')!='':
    sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['genre'].append(sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('category1_name').get('ko'))
   if sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('category2_name').get('ko')!='':
    sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['genre'].append(sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('category2_name').get('ko'))
   sBHvhqkdECVflUAKouLyMGbNOjYwgP=sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('release_date'))
   if sBHvhqkdECVflUAKouLyMGbNOjYwgP!='0':sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(sBHvhqkdECVflUAKouLyMGbNOjYwgP[:4],sBHvhqkdECVflUAKouLyMGbNOjYwgP[4:6],sBHvhqkdECVflUAKouLyMGbNOjYwgP[6:])
   sBHvhqkdECVflUAKouLyMGbNOjYwxt=''
   sBHvhqkdECVflUAKouLyMGbNOjYwxi =''
   sBHvhqkdECVflUAKouLyMGbNOjYwgR=''
   for sBHvhqkdECVflUAKouLyMGbNOjYwgI in sBHvhqkdECVflUAKouLyMGbNOjYwFi.get('image'):
    if sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('code')=='CAIM2100':sBHvhqkdECVflUAKouLyMGbNOjYwxt =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('url')
    elif sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('code')=='CAIM0400':sBHvhqkdECVflUAKouLyMGbNOjYwxi =sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('url')
    elif sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('code')=='CAIM1800':sBHvhqkdECVflUAKouLyMGbNOjYwgR=sBHvhqkdECVflUAKouLyMGbNOjYwRF.IMG_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwgI.get('url')
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['thumbnail']['poster']=sBHvhqkdECVflUAKouLyMGbNOjYwxt
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['thumbnail']['thumb']=sBHvhqkdECVflUAKouLyMGbNOjYwxt 
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['thumbnail']['clearlogo']=sBHvhqkdECVflUAKouLyMGbNOjYwgR
   sBHvhqkdECVflUAKouLyMGbNOjYwFp['saveinfo']['thumbnail']['fanart']=sBHvhqkdECVflUAKouLyMGbNOjYwxi
  return sBHvhqkdECVflUAKouLyMGbNOjYwFp
 def GetEuroChannelList(sBHvhqkdECVflUAKouLyMGbNOjYwRF):
  sBHvhqkdECVflUAKouLyMGbNOjYwcn=[]
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwca ='/v2/operator/highlights'
   sBHvhqkdECVflUAKouLyMGbNOjYwci=sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetDefaultParams()
   sBHvhqkdECVflUAKouLyMGbNOjYwce={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':sBHvhqkdECVflUAKouLyMGbNOjYwIi(sBHvhqkdECVflUAKouLyMGbNOjYwRF.GetNoCache(2))}
   sBHvhqkdECVflUAKouLyMGbNOjYwci.update(sBHvhqkdECVflUAKouLyMGbNOjYwce)
   sBHvhqkdECVflUAKouLyMGbNOjYwct=sBHvhqkdECVflUAKouLyMGbNOjYwRF.API_DOMAIN+sBHvhqkdECVflUAKouLyMGbNOjYwca
   sBHvhqkdECVflUAKouLyMGbNOjYwcg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.callRequestCookies('Get',sBHvhqkdECVflUAKouLyMGbNOjYwct,payload=sBHvhqkdECVflUAKouLyMGbNOjYwIe,params=sBHvhqkdECVflUAKouLyMGbNOjYwci,headers=sBHvhqkdECVflUAKouLyMGbNOjYwIe,cookies=sBHvhqkdECVflUAKouLyMGbNOjYwIe)
   sBHvhqkdECVflUAKouLyMGbNOjYwcP=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwcg.text)
   if not('result' in sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']):return sBHvhqkdECVflUAKouLyMGbNOjYwcn,sBHvhqkdECVflUAKouLyMGbNOjYwxe
   sBHvhqkdECVflUAKouLyMGbNOjYwxS=sBHvhqkdECVflUAKouLyMGbNOjYwcP['body']['result']
   sBHvhqkdECVflUAKouLyMGbNOjYwFt =sBHvhqkdECVflUAKouLyMGbNOjYwRF.Get_Now_Datetime()
   sBHvhqkdECVflUAKouLyMGbNOjYwIR=sBHvhqkdECVflUAKouLyMGbNOjYwFt+datetime.timedelta(days=-1)
   sBHvhqkdECVflUAKouLyMGbNOjYwIR=sBHvhqkdECVflUAKouLyMGbNOjYwIQ(sBHvhqkdECVflUAKouLyMGbNOjYwIR.strftime('%Y%m%d'))
   for sBHvhqkdECVflUAKouLyMGbNOjYwcS in sBHvhqkdECVflUAKouLyMGbNOjYwxS:
    sBHvhqkdECVflUAKouLyMGbNOjYwIc=sBHvhqkdECVflUAKouLyMGbNOjYwIQ(sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('content').get('banner_title2')[:8])
    if sBHvhqkdECVflUAKouLyMGbNOjYwIR<=sBHvhqkdECVflUAKouLyMGbNOjYwIc:
     sBHvhqkdECVflUAKouLyMGbNOjYwgT={'channel':sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('content').get('banner_sub_title3'),'title':sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('content').get('banner_title'),'subtitle':sBHvhqkdECVflUAKouLyMGbNOjYwcS.get('content').get('banner_sub_title2'),}
     sBHvhqkdECVflUAKouLyMGbNOjYwcn.append(sBHvhqkdECVflUAKouLyMGbNOjYwgT)
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
  return sBHvhqkdECVflUAKouLyMGbNOjYwcn
 def Make_DecryptKey(sBHvhqkdECVflUAKouLyMGbNOjYwRF,step,mediacode='000',timecode='000'):
  if step=='1':
   sBHvhqkdECVflUAKouLyMGbNOjYwIx=sBHvhqkdECVflUAKouLyMGbNOjYwJR('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   sBHvhqkdECVflUAKouLyMGbNOjYwIg=sBHvhqkdECVflUAKouLyMGbNOjYwJR('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   sBHvhqkdECVflUAKouLyMGbNOjYwIx=sBHvhqkdECVflUAKouLyMGbNOjYwJR('kss2lym0kdw1lks3','utf-8')
   sBHvhqkdECVflUAKouLyMGbNOjYwIg=sBHvhqkdECVflUAKouLyMGbNOjYwJR([sBHvhqkdECVflUAKouLyMGbNOjYwJc('*'),0x07,sBHvhqkdECVflUAKouLyMGbNOjYwJc('r'),sBHvhqkdECVflUAKouLyMGbNOjYwJc(';'),sBHvhqkdECVflUAKouLyMGbNOjYwJc('7'),0x05,0x1e,0x01,sBHvhqkdECVflUAKouLyMGbNOjYwJc('n'),sBHvhqkdECVflUAKouLyMGbNOjYwJc('D'),0x02,sBHvhqkdECVflUAKouLyMGbNOjYwJc('3'),sBHvhqkdECVflUAKouLyMGbNOjYwJc('*'),sBHvhqkdECVflUAKouLyMGbNOjYwJc('a'),sBHvhqkdECVflUAKouLyMGbNOjYwJc('&'),sBHvhqkdECVflUAKouLyMGbNOjYwJc('<')])
  return sBHvhqkdECVflUAKouLyMGbNOjYwIx,sBHvhqkdECVflUAKouLyMGbNOjYwIg
 def DecryptPlaintext(sBHvhqkdECVflUAKouLyMGbNOjYwRF,ciphertext,encryption_key,init_vector):
  sBHvhqkdECVflUAKouLyMGbNOjYwIF=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  sBHvhqkdECVflUAKouLyMGbNOjYwIJ=Padding.unpad(sBHvhqkdECVflUAKouLyMGbNOjYwIF.decrypt(base64.standard_b64decode(ciphertext)),16)
  return sBHvhqkdECVflUAKouLyMGbNOjYwIJ.decode('utf-8')
 def Decrypt_Url(sBHvhqkdECVflUAKouLyMGbNOjYwRF,ciphertext,mediacode,sBHvhqkdECVflUAKouLyMGbNOjYwxJ):
  sBHvhqkdECVflUAKouLyMGbNOjYwIr=''
  sBHvhqkdECVflUAKouLyMGbNOjYwxr=''
  sBHvhqkdECVflUAKouLyMGbNOjYwxa=''
  try:
   sBHvhqkdECVflUAKouLyMGbNOjYwIx,sBHvhqkdECVflUAKouLyMGbNOjYwIg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.Make_DecryptKey('1',mediacode=mediacode,timecode=sBHvhqkdECVflUAKouLyMGbNOjYwxJ)
   sBHvhqkdECVflUAKouLyMGbNOjYwIa=json.loads(sBHvhqkdECVflUAKouLyMGbNOjYwRF.DecryptPlaintext(ciphertext,sBHvhqkdECVflUAKouLyMGbNOjYwIx,sBHvhqkdECVflUAKouLyMGbNOjYwIg))
   sBHvhqkdECVflUAKouLyMGbNOjYwID =sBHvhqkdECVflUAKouLyMGbNOjYwIa.get('broad_url')
   sBHvhqkdECVflUAKouLyMGbNOjYwxr =sBHvhqkdECVflUAKouLyMGbNOjYwIa.get('watermark') if 'watermark' in sBHvhqkdECVflUAKouLyMGbNOjYwIa else ''
   sBHvhqkdECVflUAKouLyMGbNOjYwxa=sBHvhqkdECVflUAKouLyMGbNOjYwIa.get('watermarkKey')if 'watermarkKey' in sBHvhqkdECVflUAKouLyMGbNOjYwIa else ''
   sBHvhqkdECVflUAKouLyMGbNOjYwIx,sBHvhqkdECVflUAKouLyMGbNOjYwIg=sBHvhqkdECVflUAKouLyMGbNOjYwRF.Make_DecryptKey('2',mediacode=mediacode,timecode=sBHvhqkdECVflUAKouLyMGbNOjYwxJ)
   sBHvhqkdECVflUAKouLyMGbNOjYwIr=sBHvhqkdECVflUAKouLyMGbNOjYwRF.DecryptPlaintext(sBHvhqkdECVflUAKouLyMGbNOjYwID,sBHvhqkdECVflUAKouLyMGbNOjYwIx,sBHvhqkdECVflUAKouLyMGbNOjYwIg)
  except sBHvhqkdECVflUAKouLyMGbNOjYwIp as exception:
   sBHvhqkdECVflUAKouLyMGbNOjYwIn(exception)
  return sBHvhqkdECVflUAKouLyMGbNOjYwIr,sBHvhqkdECVflUAKouLyMGbNOjYwxr,sBHvhqkdECVflUAKouLyMGbNOjYwxa
# Created by pyminifier (https://github.com/liftoff/pyminifier)
