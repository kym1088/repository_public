# tvingM-v19
 티빙 애드온 for Kodi19

###
# kodi19용은 저장소를 통해서만 업데이트 됩니다.
* [Korea OTT Package for Kodi 18 (public)-18.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v18_public.zip)
* [Korea OTT Package for Kodi 19 (public)-19.0.0.zip](https://github.com/kym1088/repository_public/raw/master/repository.nightrain_v19_public.zip)
###


# 공통
- DRM 실시간 채널(ocn, super action 등)이 설정한 화질보다 낮게 재생될때
  InputStream Adaptive 애드온 설정에서
  Ignore Display Resolution 활성화
  또는 스트림수동 선택후 재생화면 옵션에서 수동변경해볼것
- (필수) Tving 홈페이지 기기등록 화면에서 PC로 등록된 기기 필요 (1회)


## Version 2.3.1 (2021.03.12)
- 통합 찜하기 기능 추가

## Version 2.3.0 (2021.03.07)
- contentType, 찜하기

## Version 2.2.8 (2021.02.23)
- 검색방법 변경, 검색기록 추가

## Version 2.2.7 (2021.02.15)
- 통합검색 추가

## Version 2.2.6 (2021.01.30)
- 검색관련 오류 수정

## Version 2.2.5 (2021.01.10)
- info, image 추가

## Version 2.2.4 (2020.12.29)
- 썸네일, 해외시리즈 분류/재생오류

## Version 2.2.3 (2020.12.19)
- 일부계정 로그인 오류 수정

## Version 2.2.2 (2020.12.18)
- 영화(최신순) 개별구매건 제외

## Version 2.2.1 (2020.12.18)
- 영화 다음페이지 오류 수정

## Version 2.2.0 (2020.12.17)
- 사이트 개편 반영

## Version 2.1.0 (2020.11.01)
- 코드 정리

## Version 2.0.5 (2020.10.20)
- kodi update 대응

## Version 2.0.4 (2020.10.08)
- alpha_2 오류 수정

## Version 2.0.3 (2020.09.16)
- 재접속 오류수정

## Version 2.0.2 (2020.09.10)
- timezone

## Version 2.0.1 (2020.09.08)
- 특정스킨 오류 수정

## Version 2.0.0 (2020.08.29)
- python3(kodi 19) 전환
