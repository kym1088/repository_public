__author__="NightRain"
AUQifmCEDzWbavxINLjMSoclOtgqyF=object
AUQifmCEDzWbavxINLjMSoclOtgqhe=None
AUQifmCEDzWbavxINLjMSoclOtgqhB=int
AUQifmCEDzWbavxINLjMSoclOtgqhY=True
AUQifmCEDzWbavxINLjMSoclOtgqhp=False
AUQifmCEDzWbavxINLjMSoclOtgqhn=type
AUQifmCEDzWbavxINLjMSoclOtgqhw=dict
AUQifmCEDzWbavxINLjMSoclOtgqhy=len
AUQifmCEDzWbavxINLjMSoclOtgqhd=str
AUQifmCEDzWbavxINLjMSoclOtgqhs=range
AUQifmCEDzWbavxINLjMSoclOtgqhX=open
AUQifmCEDzWbavxINLjMSoclOtgqhr=Exception
AUQifmCEDzWbavxINLjMSoclOtgqhT=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
AUQifmCEDzWbavxINLjMSoclOtgqeY=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
AUQifmCEDzWbavxINLjMSoclOtgqep=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
AUQifmCEDzWbavxINLjMSoclOtgqen=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
AUQifmCEDzWbavxINLjMSoclOtgqew=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
AUQifmCEDzWbavxINLjMSoclOtgqey=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
AUQifmCEDzWbavxINLjMSoclOtgqeh=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
AUQifmCEDzWbavxINLjMSoclOtgqed=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
AUQifmCEDzWbavxINLjMSoclOtgqes =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
AUQifmCEDzWbavxINLjMSoclOtgqeX=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class AUQifmCEDzWbavxINLjMSoclOtgqeB(AUQifmCEDzWbavxINLjMSoclOtgqyF):
 def __init__(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqeT,AUQifmCEDzWbavxINLjMSoclOtgqeG,AUQifmCEDzWbavxINLjMSoclOtgqeJ):
  AUQifmCEDzWbavxINLjMSoclOtgqer._addon_url =AUQifmCEDzWbavxINLjMSoclOtgqeT
  AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle=AUQifmCEDzWbavxINLjMSoclOtgqeG
  AUQifmCEDzWbavxINLjMSoclOtgqer.main_params =AUQifmCEDzWbavxINLjMSoclOtgqeJ
  AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj =tWlGIcwPXfSEYNrKykqCjmszeJQMgh() 
 def addon_noti(AUQifmCEDzWbavxINLjMSoclOtgqer,sting):
  try:
   AUQifmCEDzWbavxINLjMSoclOtgqek=xbmcgui.Dialog()
   AUQifmCEDzWbavxINLjMSoclOtgqek.notification(__addonname__,sting)
  except:
   AUQifmCEDzWbavxINLjMSoclOtgqhe
 def addon_log(AUQifmCEDzWbavxINLjMSoclOtgqer,string):
  try:
   AUQifmCEDzWbavxINLjMSoclOtgqeV=string.encode('utf-8','ignore')
  except:
   AUQifmCEDzWbavxINLjMSoclOtgqeV='addonException: addon_log'
  AUQifmCEDzWbavxINLjMSoclOtgqeK=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,AUQifmCEDzWbavxINLjMSoclOtgqeV),level=AUQifmCEDzWbavxINLjMSoclOtgqeK)
 def get_keyboard_input(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqBr):
  AUQifmCEDzWbavxINLjMSoclOtgqeH=AUQifmCEDzWbavxINLjMSoclOtgqhe
  kb=xbmc.Keyboard()
  kb.setHeading(AUQifmCEDzWbavxINLjMSoclOtgqBr)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   AUQifmCEDzWbavxINLjMSoclOtgqeH=kb.getText()
  return AUQifmCEDzWbavxINLjMSoclOtgqeH
 def get_settings_login_info(AUQifmCEDzWbavxINLjMSoclOtgqer):
  AUQifmCEDzWbavxINLjMSoclOtgqeP =__addon__.getSetting('id')
  AUQifmCEDzWbavxINLjMSoclOtgqeR =__addon__.getSetting('pw')
  AUQifmCEDzWbavxINLjMSoclOtgqeF =__addon__.getSetting('login_type')
  AUQifmCEDzWbavxINLjMSoclOtgqBe=AUQifmCEDzWbavxINLjMSoclOtgqhB(__addon__.getSetting('selected_profile'))
  return(AUQifmCEDzWbavxINLjMSoclOtgqeP,AUQifmCEDzWbavxINLjMSoclOtgqeR,AUQifmCEDzWbavxINLjMSoclOtgqeF,AUQifmCEDzWbavxINLjMSoclOtgqBe)
 def get_settings_totalsearch(AUQifmCEDzWbavxINLjMSoclOtgqer):
  AUQifmCEDzWbavxINLjMSoclOtgqBY =AUQifmCEDzWbavxINLjMSoclOtgqhY if __addon__.getSetting('local_search')=='true' else AUQifmCEDzWbavxINLjMSoclOtgqhp
  AUQifmCEDzWbavxINLjMSoclOtgqBp=AUQifmCEDzWbavxINLjMSoclOtgqhY if __addon__.getSetting('local_history')=='true' else AUQifmCEDzWbavxINLjMSoclOtgqhp
  AUQifmCEDzWbavxINLjMSoclOtgqBn =AUQifmCEDzWbavxINLjMSoclOtgqhY if __addon__.getSetting('total_search')=='true' else AUQifmCEDzWbavxINLjMSoclOtgqhp
  AUQifmCEDzWbavxINLjMSoclOtgqBw=AUQifmCEDzWbavxINLjMSoclOtgqhY if __addon__.getSetting('total_history')=='true' else AUQifmCEDzWbavxINLjMSoclOtgqhp
  AUQifmCEDzWbavxINLjMSoclOtgqBy=AUQifmCEDzWbavxINLjMSoclOtgqhY if __addon__.getSetting('menu_bookmark')=='true' else AUQifmCEDzWbavxINLjMSoclOtgqhp
  return(AUQifmCEDzWbavxINLjMSoclOtgqBY,AUQifmCEDzWbavxINLjMSoclOtgqBp,AUQifmCEDzWbavxINLjMSoclOtgqBn,AUQifmCEDzWbavxINLjMSoclOtgqBw,AUQifmCEDzWbavxINLjMSoclOtgqBy)
 def get_settings_makebookmark(AUQifmCEDzWbavxINLjMSoclOtgqer):
  return AUQifmCEDzWbavxINLjMSoclOtgqhY if __addon__.getSetting('make_bookmark')=='true' else AUQifmCEDzWbavxINLjMSoclOtgqhp
 def get_settings_direct_replay(AUQifmCEDzWbavxINLjMSoclOtgqer):
  AUQifmCEDzWbavxINLjMSoclOtgqBh=AUQifmCEDzWbavxINLjMSoclOtgqhB(__addon__.getSetting('direct_replay'))
  if AUQifmCEDzWbavxINLjMSoclOtgqBh==0:
   return AUQifmCEDzWbavxINLjMSoclOtgqhp
  else:
   return AUQifmCEDzWbavxINLjMSoclOtgqhY
 def set_winCredential(AUQifmCEDzWbavxINLjMSoclOtgqer,credential):
  AUQifmCEDzWbavxINLjMSoclOtgqBd=xbmcgui.Window(10000)
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_LOGINTIME',AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(AUQifmCEDzWbavxINLjMSoclOtgqer):
  AUQifmCEDzWbavxINLjMSoclOtgqBd=xbmcgui.Window(10000)
  AUQifmCEDzWbavxINLjMSoclOtgqBs={'tving_token':AUQifmCEDzWbavxINLjMSoclOtgqBd.getProperty('TVING_M_TOKEN'),'poc_userinfo':AUQifmCEDzWbavxINLjMSoclOtgqBd.getProperty('TVING_M_USERINFO'),'tving_uuid':AUQifmCEDzWbavxINLjMSoclOtgqBd.getProperty('TVING_M_UUID'),'tving_maintoken':AUQifmCEDzWbavxINLjMSoclOtgqBd.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':AUQifmCEDzWbavxINLjMSoclOtgqBd.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':AUQifmCEDzWbavxINLjMSoclOtgqBd.getProperty('TVING_M_LOCKKEY')}
  return AUQifmCEDzWbavxINLjMSoclOtgqBs
 def set_winEpisodeOrderby(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqpy):
  AUQifmCEDzWbavxINLjMSoclOtgqBd=xbmcgui.Window(10000)
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_ORDERBY',AUQifmCEDzWbavxINLjMSoclOtgqpy)
 def get_winEpisodeOrderby(AUQifmCEDzWbavxINLjMSoclOtgqer):
  AUQifmCEDzWbavxINLjMSoclOtgqBd=xbmcgui.Window(10000)
  return AUQifmCEDzWbavxINLjMSoclOtgqBd.getProperty('TVING_M_ORDERBY')
 def add_dir(AUQifmCEDzWbavxINLjMSoclOtgqer,label,sublabel='',img='',infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqhe,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhY,params='',isLink=AUQifmCEDzWbavxINLjMSoclOtgqhp,ContextMenu=AUQifmCEDzWbavxINLjMSoclOtgqhe):
  AUQifmCEDzWbavxINLjMSoclOtgqBX='%s?%s'%(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_url,urllib.parse.urlencode(params))
  if sublabel:AUQifmCEDzWbavxINLjMSoclOtgqBr='%s < %s >'%(label,sublabel)
  else: AUQifmCEDzWbavxINLjMSoclOtgqBr=label
  if not img:img='DefaultFolder.png'
  AUQifmCEDzWbavxINLjMSoclOtgqBT=xbmcgui.ListItem(AUQifmCEDzWbavxINLjMSoclOtgqBr)
  if AUQifmCEDzWbavxINLjMSoclOtgqhn(img)==AUQifmCEDzWbavxINLjMSoclOtgqhw:
   AUQifmCEDzWbavxINLjMSoclOtgqBT.setArt(img)
  else:
   AUQifmCEDzWbavxINLjMSoclOtgqBT.setArt({'thumb':img,'poster':img})
  if infoLabels:AUQifmCEDzWbavxINLjMSoclOtgqBT.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   AUQifmCEDzWbavxINLjMSoclOtgqBT.setProperty('IsPlayable','true')
  if ContextMenu:AUQifmCEDzWbavxINLjMSoclOtgqBT.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,AUQifmCEDzWbavxINLjMSoclOtgqBX,AUQifmCEDzWbavxINLjMSoclOtgqBT,isFolder)
 def get_selQuality(AUQifmCEDzWbavxINLjMSoclOtgqer,etype):
  try:
   AUQifmCEDzWbavxINLjMSoclOtgqBG='selected_quality'
   AUQifmCEDzWbavxINLjMSoclOtgqBJ=[1080,720,480,360]
   AUQifmCEDzWbavxINLjMSoclOtgqBu=AUQifmCEDzWbavxINLjMSoclOtgqhB(__addon__.getSetting(AUQifmCEDzWbavxINLjMSoclOtgqBG))
   return AUQifmCEDzWbavxINLjMSoclOtgqBJ[AUQifmCEDzWbavxINLjMSoclOtgqBu]
  except:
   AUQifmCEDzWbavxINLjMSoclOtgqhe
  return 720 
 def dp_Main_List(AUQifmCEDzWbavxINLjMSoclOtgqer):
  (AUQifmCEDzWbavxINLjMSoclOtgqBY,AUQifmCEDzWbavxINLjMSoclOtgqBp,AUQifmCEDzWbavxINLjMSoclOtgqBn,AUQifmCEDzWbavxINLjMSoclOtgqBw,AUQifmCEDzWbavxINLjMSoclOtgqBy)=AUQifmCEDzWbavxINLjMSoclOtgqer.get_settings_totalsearch()
  for AUQifmCEDzWbavxINLjMSoclOtgqBk in AUQifmCEDzWbavxINLjMSoclOtgqeY:
   AUQifmCEDzWbavxINLjMSoclOtgqBr=AUQifmCEDzWbavxINLjMSoclOtgqBk.get('title')
   AUQifmCEDzWbavxINLjMSoclOtgqBV=''
   if AUQifmCEDzWbavxINLjMSoclOtgqBk.get('mode')=='SEARCH_GROUP' and AUQifmCEDzWbavxINLjMSoclOtgqBY ==AUQifmCEDzWbavxINLjMSoclOtgqhp:continue
   elif AUQifmCEDzWbavxINLjMSoclOtgqBk.get('mode')=='SEARCH_HISTORY' and AUQifmCEDzWbavxINLjMSoclOtgqBp==AUQifmCEDzWbavxINLjMSoclOtgqhp:continue
   elif AUQifmCEDzWbavxINLjMSoclOtgqBk.get('mode')=='TOTAL_SEARCH' and AUQifmCEDzWbavxINLjMSoclOtgqBn ==AUQifmCEDzWbavxINLjMSoclOtgqhp:continue
   elif AUQifmCEDzWbavxINLjMSoclOtgqBk.get('mode')=='TOTAL_HISTORY' and AUQifmCEDzWbavxINLjMSoclOtgqBw==AUQifmCEDzWbavxINLjMSoclOtgqhp:continue
   elif AUQifmCEDzWbavxINLjMSoclOtgqBk.get('mode')=='MENU_BOOKMARK' and AUQifmCEDzWbavxINLjMSoclOtgqBy==AUQifmCEDzWbavxINLjMSoclOtgqhp:continue
   AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':AUQifmCEDzWbavxINLjMSoclOtgqBk.get('mode'),'stype':AUQifmCEDzWbavxINLjMSoclOtgqBk.get('stype'),'orderby':AUQifmCEDzWbavxINLjMSoclOtgqBk.get('orderby'),'ordernm':AUQifmCEDzWbavxINLjMSoclOtgqBk.get('ordernm'),'page':'1'}
   if AUQifmCEDzWbavxINLjMSoclOtgqBk.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    AUQifmCEDzWbavxINLjMSoclOtgqBH=AUQifmCEDzWbavxINLjMSoclOtgqhp
    AUQifmCEDzWbavxINLjMSoclOtgqBP =AUQifmCEDzWbavxINLjMSoclOtgqhY
   else:
    AUQifmCEDzWbavxINLjMSoclOtgqBH=AUQifmCEDzWbavxINLjMSoclOtgqhY
    AUQifmCEDzWbavxINLjMSoclOtgqBP =AUQifmCEDzWbavxINLjMSoclOtgqhp
   if 'icon' in AUQifmCEDzWbavxINLjMSoclOtgqBk:AUQifmCEDzWbavxINLjMSoclOtgqBV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',AUQifmCEDzWbavxINLjMSoclOtgqBk.get('icon')) 
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel='',img=AUQifmCEDzWbavxINLjMSoclOtgqBV,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqhe,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqBH,params=AUQifmCEDzWbavxINLjMSoclOtgqBK,isLink=AUQifmCEDzWbavxINLjMSoclOtgqBP)
  xbmcplugin.endOfDirectory(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle)
 def login_main(AUQifmCEDzWbavxINLjMSoclOtgqer):
  (AUQifmCEDzWbavxINLjMSoclOtgqBF,AUQifmCEDzWbavxINLjMSoclOtgqYe,AUQifmCEDzWbavxINLjMSoclOtgqYB,AUQifmCEDzWbavxINLjMSoclOtgqYp)=AUQifmCEDzWbavxINLjMSoclOtgqer.get_settings_login_info()
  if not(AUQifmCEDzWbavxINLjMSoclOtgqBF and AUQifmCEDzWbavxINLjMSoclOtgqYe):
   AUQifmCEDzWbavxINLjMSoclOtgqek=xbmcgui.Dialog()
   AUQifmCEDzWbavxINLjMSoclOtgqYn=AUQifmCEDzWbavxINLjMSoclOtgqek.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if AUQifmCEDzWbavxINLjMSoclOtgqYn==AUQifmCEDzWbavxINLjMSoclOtgqhY:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if AUQifmCEDzWbavxINLjMSoclOtgqer.get_winEpisodeOrderby()=='':
   AUQifmCEDzWbavxINLjMSoclOtgqer.set_winEpisodeOrderby('desc')
  if AUQifmCEDzWbavxINLjMSoclOtgqer.cookiefile_check():return
  AUQifmCEDzWbavxINLjMSoclOtgqYw =AUQifmCEDzWbavxINLjMSoclOtgqhB(AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  AUQifmCEDzWbavxINLjMSoclOtgqYy=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if AUQifmCEDzWbavxINLjMSoclOtgqYy==AUQifmCEDzWbavxINLjMSoclOtgqhe or AUQifmCEDzWbavxINLjMSoclOtgqYy=='':
   AUQifmCEDzWbavxINLjMSoclOtgqYy=AUQifmCEDzWbavxINLjMSoclOtgqhB('19000101')
  else:
   AUQifmCEDzWbavxINLjMSoclOtgqYy=AUQifmCEDzWbavxINLjMSoclOtgqhB(re.sub('-','',AUQifmCEDzWbavxINLjMSoclOtgqYy))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   AUQifmCEDzWbavxINLjMSoclOtgqYh=0
   while AUQifmCEDzWbavxINLjMSoclOtgqhY:
    AUQifmCEDzWbavxINLjMSoclOtgqYh+=1
    time.sleep(0.05)
    if AUQifmCEDzWbavxINLjMSoclOtgqYy>=AUQifmCEDzWbavxINLjMSoclOtgqYw:return
    if AUQifmCEDzWbavxINLjMSoclOtgqYh>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if AUQifmCEDzWbavxINLjMSoclOtgqYy>=AUQifmCEDzWbavxINLjMSoclOtgqYw:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.GetCredential(AUQifmCEDzWbavxINLjMSoclOtgqBF,AUQifmCEDzWbavxINLjMSoclOtgqYe,AUQifmCEDzWbavxINLjMSoclOtgqYB,AUQifmCEDzWbavxINLjMSoclOtgqYp):
   AUQifmCEDzWbavxINLjMSoclOtgqer.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  AUQifmCEDzWbavxINLjMSoclOtgqer.set_winCredential(AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.LoadCredential())
  AUQifmCEDzWbavxINLjMSoclOtgqer.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqYd=AUQifmCEDzWbavxINLjMSoclOtgqYr.get('stype')
  if AUQifmCEDzWbavxINLjMSoclOtgqYd=='live':
   AUQifmCEDzWbavxINLjMSoclOtgqYs=AUQifmCEDzWbavxINLjMSoclOtgqep
  elif AUQifmCEDzWbavxINLjMSoclOtgqYd=='vod':
   AUQifmCEDzWbavxINLjMSoclOtgqYs=AUQifmCEDzWbavxINLjMSoclOtgqey
  else:
   AUQifmCEDzWbavxINLjMSoclOtgqYs=AUQifmCEDzWbavxINLjMSoclOtgqeh
  for AUQifmCEDzWbavxINLjMSoclOtgqYX in AUQifmCEDzWbavxINLjMSoclOtgqYs:
   AUQifmCEDzWbavxINLjMSoclOtgqBr=AUQifmCEDzWbavxINLjMSoclOtgqYX.get('title')
   if AUQifmCEDzWbavxINLjMSoclOtgqYr.get('ordernm')!='-':
    AUQifmCEDzWbavxINLjMSoclOtgqBr+='  ('+AUQifmCEDzWbavxINLjMSoclOtgqYr.get('ordernm')+')'
   AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':AUQifmCEDzWbavxINLjMSoclOtgqYX.get('mode'),'stype':AUQifmCEDzWbavxINLjMSoclOtgqYX.get('stype'),'orderby':AUQifmCEDzWbavxINLjMSoclOtgqYr.get('orderby'),'ordernm':AUQifmCEDzWbavxINLjMSoclOtgqYr.get('ordernm'),'page':'1'}
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel='',img='',infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqhe,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhY,params=AUQifmCEDzWbavxINLjMSoclOtgqBK)
  if AUQifmCEDzWbavxINLjMSoclOtgqhy(AUQifmCEDzWbavxINLjMSoclOtgqYs)>0:xbmcplugin.endOfDirectory(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle)
 def dp_SubTitle_Group(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr): 
  for AUQifmCEDzWbavxINLjMSoclOtgqYX in AUQifmCEDzWbavxINLjMSoclOtgqed:
   AUQifmCEDzWbavxINLjMSoclOtgqBr=AUQifmCEDzWbavxINLjMSoclOtgqYX.get('title')
   if AUQifmCEDzWbavxINLjMSoclOtgqYr.get('ordernm')!='-':
    AUQifmCEDzWbavxINLjMSoclOtgqBr+='  ('+AUQifmCEDzWbavxINLjMSoclOtgqYr.get('ordernm')+')'
   AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':AUQifmCEDzWbavxINLjMSoclOtgqYX.get('mode'),'genreCode':AUQifmCEDzWbavxINLjMSoclOtgqYX.get('genreCode'),'stype':AUQifmCEDzWbavxINLjMSoclOtgqYr.get('stype'),'orderby':AUQifmCEDzWbavxINLjMSoclOtgqYr.get('orderby'),'page':'1'}
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel='',img='',infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqhe,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhY,params=AUQifmCEDzWbavxINLjMSoclOtgqBK)
  if AUQifmCEDzWbavxINLjMSoclOtgqhy(AUQifmCEDzWbavxINLjMSoclOtgqed)>0:xbmcplugin.endOfDirectory(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle)
 def dp_LiveChannel_List(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.SaveCredential(AUQifmCEDzWbavxINLjMSoclOtgqer.get_winCredential())
  AUQifmCEDzWbavxINLjMSoclOtgqYd =AUQifmCEDzWbavxINLjMSoclOtgqYr.get('stype')
  AUQifmCEDzWbavxINLjMSoclOtgqYT =AUQifmCEDzWbavxINLjMSoclOtgqhB(AUQifmCEDzWbavxINLjMSoclOtgqYr.get('page'))
  AUQifmCEDzWbavxINLjMSoclOtgqYG,AUQifmCEDzWbavxINLjMSoclOtgqYJ=AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.GetLiveChannelList(AUQifmCEDzWbavxINLjMSoclOtgqYd,AUQifmCEDzWbavxINLjMSoclOtgqYT)
  for AUQifmCEDzWbavxINLjMSoclOtgqYu in AUQifmCEDzWbavxINLjMSoclOtgqYG:
   AUQifmCEDzWbavxINLjMSoclOtgqBr =AUQifmCEDzWbavxINLjMSoclOtgqYu.get('title')
   AUQifmCEDzWbavxINLjMSoclOtgqBR =AUQifmCEDzWbavxINLjMSoclOtgqYu.get('channel')
   AUQifmCEDzWbavxINLjMSoclOtgqYk =AUQifmCEDzWbavxINLjMSoclOtgqYu.get('thumbnail')
   AUQifmCEDzWbavxINLjMSoclOtgqYV =AUQifmCEDzWbavxINLjMSoclOtgqYu.get('synopsis')
   AUQifmCEDzWbavxINLjMSoclOtgqYK =AUQifmCEDzWbavxINLjMSoclOtgqYu.get('channelepg')
   AUQifmCEDzWbavxINLjMSoclOtgqYH =AUQifmCEDzWbavxINLjMSoclOtgqYu.get('cast')
   AUQifmCEDzWbavxINLjMSoclOtgqYP =AUQifmCEDzWbavxINLjMSoclOtgqYu.get('director')
   AUQifmCEDzWbavxINLjMSoclOtgqYR =AUQifmCEDzWbavxINLjMSoclOtgqYu.get('info_genre')
   AUQifmCEDzWbavxINLjMSoclOtgqYF =AUQifmCEDzWbavxINLjMSoclOtgqYu.get('year')
   AUQifmCEDzWbavxINLjMSoclOtgqpe =AUQifmCEDzWbavxINLjMSoclOtgqYu.get('mpaa')
   AUQifmCEDzWbavxINLjMSoclOtgqpB =AUQifmCEDzWbavxINLjMSoclOtgqYu.get('premiered')
   AUQifmCEDzWbavxINLjMSoclOtgqpY={'mediatype':'episode','title':AUQifmCEDzWbavxINLjMSoclOtgqBr,'studio':AUQifmCEDzWbavxINLjMSoclOtgqBR,'cast':AUQifmCEDzWbavxINLjMSoclOtgqYH,'director':AUQifmCEDzWbavxINLjMSoclOtgqYP,'genre':AUQifmCEDzWbavxINLjMSoclOtgqYR,'plot':'%s\n%s\n%s\n\n%s'%(AUQifmCEDzWbavxINLjMSoclOtgqBR,AUQifmCEDzWbavxINLjMSoclOtgqBr,AUQifmCEDzWbavxINLjMSoclOtgqYK,AUQifmCEDzWbavxINLjMSoclOtgqYV),'year':AUQifmCEDzWbavxINLjMSoclOtgqYF,'mpaa':AUQifmCEDzWbavxINLjMSoclOtgqpe,'premiered':AUQifmCEDzWbavxINLjMSoclOtgqpB}
   AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':'LIVE','mediacode':AUQifmCEDzWbavxINLjMSoclOtgqYu.get('mediacode'),'stype':AUQifmCEDzWbavxINLjMSoclOtgqYd}
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBR,sublabel=AUQifmCEDzWbavxINLjMSoclOtgqBr,img=AUQifmCEDzWbavxINLjMSoclOtgqYk,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqpY,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhp,params=AUQifmCEDzWbavxINLjMSoclOtgqBK)
  if AUQifmCEDzWbavxINLjMSoclOtgqYJ:
   AUQifmCEDzWbavxINLjMSoclOtgqBK['mode']='CHANNEL' 
   AUQifmCEDzWbavxINLjMSoclOtgqBK['stype']=AUQifmCEDzWbavxINLjMSoclOtgqYd 
   AUQifmCEDzWbavxINLjMSoclOtgqBK['page']=AUQifmCEDzWbavxINLjMSoclOtgqhd(AUQifmCEDzWbavxINLjMSoclOtgqYT+1)
   AUQifmCEDzWbavxINLjMSoclOtgqBr='[B]%s >>[/B]'%'다음 페이지'
   AUQifmCEDzWbavxINLjMSoclOtgqpn=AUQifmCEDzWbavxINLjMSoclOtgqhd(AUQifmCEDzWbavxINLjMSoclOtgqYT+1)
   AUQifmCEDzWbavxINLjMSoclOtgqBV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel=AUQifmCEDzWbavxINLjMSoclOtgqpn,img=AUQifmCEDzWbavxINLjMSoclOtgqBV,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqhe,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhY,params=AUQifmCEDzWbavxINLjMSoclOtgqBK)
  if AUQifmCEDzWbavxINLjMSoclOtgqhy(AUQifmCEDzWbavxINLjMSoclOtgqYG)>0:xbmcplugin.endOfDirectory(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,cacheToDisc=AUQifmCEDzWbavxINLjMSoclOtgqhp)
 def dp_Program_List(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.SaveCredential(AUQifmCEDzWbavxINLjMSoclOtgqer.get_winCredential())
  AUQifmCEDzWbavxINLjMSoclOtgqpw =AUQifmCEDzWbavxINLjMSoclOtgqYr.get('stype')
  AUQifmCEDzWbavxINLjMSoclOtgqpy =AUQifmCEDzWbavxINLjMSoclOtgqYr.get('orderby')
  AUQifmCEDzWbavxINLjMSoclOtgqYT =AUQifmCEDzWbavxINLjMSoclOtgqhB(AUQifmCEDzWbavxINLjMSoclOtgqYr.get('page'))
  AUQifmCEDzWbavxINLjMSoclOtgqph=AUQifmCEDzWbavxINLjMSoclOtgqYr.get('genreCode')
  if AUQifmCEDzWbavxINLjMSoclOtgqph==AUQifmCEDzWbavxINLjMSoclOtgqhe:AUQifmCEDzWbavxINLjMSoclOtgqph='all'
  AUQifmCEDzWbavxINLjMSoclOtgqpd,AUQifmCEDzWbavxINLjMSoclOtgqYJ=AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.GetProgramList(AUQifmCEDzWbavxINLjMSoclOtgqpw,AUQifmCEDzWbavxINLjMSoclOtgqpy,AUQifmCEDzWbavxINLjMSoclOtgqYT,AUQifmCEDzWbavxINLjMSoclOtgqph)
  for AUQifmCEDzWbavxINLjMSoclOtgqps in AUQifmCEDzWbavxINLjMSoclOtgqpd:
   AUQifmCEDzWbavxINLjMSoclOtgqBr =AUQifmCEDzWbavxINLjMSoclOtgqps.get('title')
   AUQifmCEDzWbavxINLjMSoclOtgqYk =AUQifmCEDzWbavxINLjMSoclOtgqps.get('thumbnail')
   AUQifmCEDzWbavxINLjMSoclOtgqYV =AUQifmCEDzWbavxINLjMSoclOtgqps.get('synopsis')
   AUQifmCEDzWbavxINLjMSoclOtgqpX =AUQifmCEDzWbavxINLjMSoclOtgqps.get('channel')
   AUQifmCEDzWbavxINLjMSoclOtgqYH =AUQifmCEDzWbavxINLjMSoclOtgqps.get('cast')
   AUQifmCEDzWbavxINLjMSoclOtgqYP =AUQifmCEDzWbavxINLjMSoclOtgqps.get('director')
   AUQifmCEDzWbavxINLjMSoclOtgqYR=AUQifmCEDzWbavxINLjMSoclOtgqps.get('info_genre')
   AUQifmCEDzWbavxINLjMSoclOtgqYF =AUQifmCEDzWbavxINLjMSoclOtgqps.get('year')
   AUQifmCEDzWbavxINLjMSoclOtgqpB =AUQifmCEDzWbavxINLjMSoclOtgqps.get('premiered')
   AUQifmCEDzWbavxINLjMSoclOtgqpe =AUQifmCEDzWbavxINLjMSoclOtgqps.get('mpaa')
   AUQifmCEDzWbavxINLjMSoclOtgqpY={'mediatype':'tvshow','title':AUQifmCEDzWbavxINLjMSoclOtgqBr,'studio':AUQifmCEDzWbavxINLjMSoclOtgqpX,'cast':AUQifmCEDzWbavxINLjMSoclOtgqYH,'director':AUQifmCEDzWbavxINLjMSoclOtgqYP,'genre':AUQifmCEDzWbavxINLjMSoclOtgqYR,'year':AUQifmCEDzWbavxINLjMSoclOtgqYF,'premiered':AUQifmCEDzWbavxINLjMSoclOtgqpB,'mpaa':AUQifmCEDzWbavxINLjMSoclOtgqpe,'plot':AUQifmCEDzWbavxINLjMSoclOtgqYV}
   AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':'EPISODE','programcode':AUQifmCEDzWbavxINLjMSoclOtgqps.get('program'),'page':'1'}
   if AUQifmCEDzWbavxINLjMSoclOtgqer.get_settings_makebookmark():
    AUQifmCEDzWbavxINLjMSoclOtgqpr={'videoid':AUQifmCEDzWbavxINLjMSoclOtgqps.get('program'),'vidtype':'tvshow','vtitle':AUQifmCEDzWbavxINLjMSoclOtgqBr,'vsubtitle':AUQifmCEDzWbavxINLjMSoclOtgqpX,}
    AUQifmCEDzWbavxINLjMSoclOtgqpT=json.dumps(AUQifmCEDzWbavxINLjMSoclOtgqpr)
    AUQifmCEDzWbavxINLjMSoclOtgqpT=urllib.parse.quote(AUQifmCEDzWbavxINLjMSoclOtgqpT)
    AUQifmCEDzWbavxINLjMSoclOtgqpG='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(AUQifmCEDzWbavxINLjMSoclOtgqpT)
    AUQifmCEDzWbavxINLjMSoclOtgqpJ=[('(통합) 찜 영상에 추가',AUQifmCEDzWbavxINLjMSoclOtgqpG)]
   else:
    AUQifmCEDzWbavxINLjMSoclOtgqpJ=AUQifmCEDzWbavxINLjMSoclOtgqhe
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel=AUQifmCEDzWbavxINLjMSoclOtgqpX,img=AUQifmCEDzWbavxINLjMSoclOtgqYk,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqpY,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhY,params=AUQifmCEDzWbavxINLjMSoclOtgqBK,ContextMenu=AUQifmCEDzWbavxINLjMSoclOtgqpJ)
  if AUQifmCEDzWbavxINLjMSoclOtgqYJ:
   AUQifmCEDzWbavxINLjMSoclOtgqBK['mode'] ='PROGRAM' 
   AUQifmCEDzWbavxINLjMSoclOtgqBK['stype'] =AUQifmCEDzWbavxINLjMSoclOtgqpw
   AUQifmCEDzWbavxINLjMSoclOtgqBK['orderby'] =AUQifmCEDzWbavxINLjMSoclOtgqpy
   AUQifmCEDzWbavxINLjMSoclOtgqBK['page'] =AUQifmCEDzWbavxINLjMSoclOtgqhd(AUQifmCEDzWbavxINLjMSoclOtgqYT+1)
   AUQifmCEDzWbavxINLjMSoclOtgqBK['genreCode']=AUQifmCEDzWbavxINLjMSoclOtgqph 
   AUQifmCEDzWbavxINLjMSoclOtgqBr='[B]%s >>[/B]'%'다음 페이지'
   AUQifmCEDzWbavxINLjMSoclOtgqpn=AUQifmCEDzWbavxINLjMSoclOtgqhd(AUQifmCEDzWbavxINLjMSoclOtgqYT+1)
   AUQifmCEDzWbavxINLjMSoclOtgqBV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel=AUQifmCEDzWbavxINLjMSoclOtgqpn,img=AUQifmCEDzWbavxINLjMSoclOtgqBV,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqhe,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhY,params=AUQifmCEDzWbavxINLjMSoclOtgqBK)
  xbmcplugin.setContent(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,cacheToDisc=AUQifmCEDzWbavxINLjMSoclOtgqhp)
 def dp_Episode_List(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.SaveCredential(AUQifmCEDzWbavxINLjMSoclOtgqer.get_winCredential())
  AUQifmCEDzWbavxINLjMSoclOtgqpk=AUQifmCEDzWbavxINLjMSoclOtgqYr.get('programcode')
  AUQifmCEDzWbavxINLjMSoclOtgqYT =AUQifmCEDzWbavxINLjMSoclOtgqhB(AUQifmCEDzWbavxINLjMSoclOtgqYr.get('page'))
  AUQifmCEDzWbavxINLjMSoclOtgqpV,AUQifmCEDzWbavxINLjMSoclOtgqYJ,AUQifmCEDzWbavxINLjMSoclOtgqpK=AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.GetEpisodeList(AUQifmCEDzWbavxINLjMSoclOtgqpk,AUQifmCEDzWbavxINLjMSoclOtgqYT,orderby=AUQifmCEDzWbavxINLjMSoclOtgqer.get_winEpisodeOrderby())
  for AUQifmCEDzWbavxINLjMSoclOtgqpH in AUQifmCEDzWbavxINLjMSoclOtgqpV:
   AUQifmCEDzWbavxINLjMSoclOtgqBr =AUQifmCEDzWbavxINLjMSoclOtgqpH.get('title')
   AUQifmCEDzWbavxINLjMSoclOtgqpn =AUQifmCEDzWbavxINLjMSoclOtgqpH.get('subtitle')
   AUQifmCEDzWbavxINLjMSoclOtgqYk =AUQifmCEDzWbavxINLjMSoclOtgqpH.get('thumbnail')
   AUQifmCEDzWbavxINLjMSoclOtgqYV =AUQifmCEDzWbavxINLjMSoclOtgqpH.get('synopsis')
   AUQifmCEDzWbavxINLjMSoclOtgqpP=AUQifmCEDzWbavxINLjMSoclOtgqpH.get('info_title')
   AUQifmCEDzWbavxINLjMSoclOtgqpR =AUQifmCEDzWbavxINLjMSoclOtgqpH.get('aired')
   AUQifmCEDzWbavxINLjMSoclOtgqpF =AUQifmCEDzWbavxINLjMSoclOtgqpH.get('studio')
   AUQifmCEDzWbavxINLjMSoclOtgqne =AUQifmCEDzWbavxINLjMSoclOtgqpH.get('frequency')
   AUQifmCEDzWbavxINLjMSoclOtgqpY={'mediatype':'episode','title':AUQifmCEDzWbavxINLjMSoclOtgqpP,'aired':AUQifmCEDzWbavxINLjMSoclOtgqpR,'studio':AUQifmCEDzWbavxINLjMSoclOtgqpF,'episode':AUQifmCEDzWbavxINLjMSoclOtgqne,'plot':AUQifmCEDzWbavxINLjMSoclOtgqYV}
   AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':'VOD','mediacode':AUQifmCEDzWbavxINLjMSoclOtgqpH.get('episode'),'stype':'vod','programcode':AUQifmCEDzWbavxINLjMSoclOtgqpk,'title':AUQifmCEDzWbavxINLjMSoclOtgqBr,'thumbnail':AUQifmCEDzWbavxINLjMSoclOtgqYk}
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel=AUQifmCEDzWbavxINLjMSoclOtgqpn,img=AUQifmCEDzWbavxINLjMSoclOtgqYk,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqpY,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhp,params=AUQifmCEDzWbavxINLjMSoclOtgqBK)
  if AUQifmCEDzWbavxINLjMSoclOtgqYT==1:
   AUQifmCEDzWbavxINLjMSoclOtgqpY={'plot':'정렬순서를 변경합니다.'}
   AUQifmCEDzWbavxINLjMSoclOtgqBK={}
   AUQifmCEDzWbavxINLjMSoclOtgqBK['mode'] ='ORDER_BY' 
   if AUQifmCEDzWbavxINLjMSoclOtgqer.get_winEpisodeOrderby()=='desc':
    AUQifmCEDzWbavxINLjMSoclOtgqBr='정렬순서변경 : 최신화부터 -> 1회부터'
    AUQifmCEDzWbavxINLjMSoclOtgqBK['orderby']='asc'
   else:
    AUQifmCEDzWbavxINLjMSoclOtgqBr='정렬순서변경 : 1회부터 -> 최신화부터'
    AUQifmCEDzWbavxINLjMSoclOtgqBK['orderby']='desc'
   AUQifmCEDzWbavxINLjMSoclOtgqBV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel='',img=AUQifmCEDzWbavxINLjMSoclOtgqBV,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqpY,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhp,params=AUQifmCEDzWbavxINLjMSoclOtgqBK,isLink=AUQifmCEDzWbavxINLjMSoclOtgqhY)
  if AUQifmCEDzWbavxINLjMSoclOtgqYJ:
   AUQifmCEDzWbavxINLjMSoclOtgqBK['mode'] ='EPISODE' 
   AUQifmCEDzWbavxINLjMSoclOtgqBK['programcode']=AUQifmCEDzWbavxINLjMSoclOtgqpk
   AUQifmCEDzWbavxINLjMSoclOtgqBK['page'] =AUQifmCEDzWbavxINLjMSoclOtgqhd(AUQifmCEDzWbavxINLjMSoclOtgqYT+1)
   AUQifmCEDzWbavxINLjMSoclOtgqBr='[B]%s >>[/B]'%'다음 페이지'
   AUQifmCEDzWbavxINLjMSoclOtgqpn=AUQifmCEDzWbavxINLjMSoclOtgqhd(AUQifmCEDzWbavxINLjMSoclOtgqYT+1)
   AUQifmCEDzWbavxINLjMSoclOtgqBV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel=AUQifmCEDzWbavxINLjMSoclOtgqpn,img=AUQifmCEDzWbavxINLjMSoclOtgqBV,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqhe,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhY,params=AUQifmCEDzWbavxINLjMSoclOtgqBK)
  xbmcplugin.setContent(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,'episodes')
  if AUQifmCEDzWbavxINLjMSoclOtgqhy(AUQifmCEDzWbavxINLjMSoclOtgqpV)>0:xbmcplugin.endOfDirectory(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,cacheToDisc=AUQifmCEDzWbavxINLjMSoclOtgqhY)
 def dp_setEpOrderby(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqpy =AUQifmCEDzWbavxINLjMSoclOtgqYr.get('orderby')
  AUQifmCEDzWbavxINLjMSoclOtgqer.set_winEpisodeOrderby(AUQifmCEDzWbavxINLjMSoclOtgqpy)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.SaveCredential(AUQifmCEDzWbavxINLjMSoclOtgqer.get_winCredential())
  AUQifmCEDzWbavxINLjMSoclOtgqpw =AUQifmCEDzWbavxINLjMSoclOtgqYr.get('stype')
  AUQifmCEDzWbavxINLjMSoclOtgqpy =AUQifmCEDzWbavxINLjMSoclOtgqYr.get('orderby')
  AUQifmCEDzWbavxINLjMSoclOtgqYT=AUQifmCEDzWbavxINLjMSoclOtgqhB(AUQifmCEDzWbavxINLjMSoclOtgqYr.get('page'))
  AUQifmCEDzWbavxINLjMSoclOtgqnB,AUQifmCEDzWbavxINLjMSoclOtgqYJ=AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.GetMovieList(AUQifmCEDzWbavxINLjMSoclOtgqpw,AUQifmCEDzWbavxINLjMSoclOtgqpy,AUQifmCEDzWbavxINLjMSoclOtgqYT)
  for AUQifmCEDzWbavxINLjMSoclOtgqnY in AUQifmCEDzWbavxINLjMSoclOtgqnB:
   AUQifmCEDzWbavxINLjMSoclOtgqBr =AUQifmCEDzWbavxINLjMSoclOtgqnY.get('title')
   AUQifmCEDzWbavxINLjMSoclOtgqYk =AUQifmCEDzWbavxINLjMSoclOtgqnY.get('thumbnail')
   AUQifmCEDzWbavxINLjMSoclOtgqYV =AUQifmCEDzWbavxINLjMSoclOtgqnY.get('synopsis')
   AUQifmCEDzWbavxINLjMSoclOtgqpP =AUQifmCEDzWbavxINLjMSoclOtgqnY.get('info_title')
   AUQifmCEDzWbavxINLjMSoclOtgqYF =AUQifmCEDzWbavxINLjMSoclOtgqnY.get('year')
   AUQifmCEDzWbavxINLjMSoclOtgqYH =AUQifmCEDzWbavxINLjMSoclOtgqnY.get('cast')
   AUQifmCEDzWbavxINLjMSoclOtgqYP =AUQifmCEDzWbavxINLjMSoclOtgqnY.get('director')
   AUQifmCEDzWbavxINLjMSoclOtgqYR =AUQifmCEDzWbavxINLjMSoclOtgqnY.get('info_genre')
   AUQifmCEDzWbavxINLjMSoclOtgqnp =AUQifmCEDzWbavxINLjMSoclOtgqnY.get('duration')
   AUQifmCEDzWbavxINLjMSoclOtgqpB =AUQifmCEDzWbavxINLjMSoclOtgqnY.get('premiered')
   AUQifmCEDzWbavxINLjMSoclOtgqpF =AUQifmCEDzWbavxINLjMSoclOtgqnY.get('studio')
   AUQifmCEDzWbavxINLjMSoclOtgqpe =AUQifmCEDzWbavxINLjMSoclOtgqnY.get('mpaa')
   AUQifmCEDzWbavxINLjMSoclOtgqpY={'mediatype':'movie','title':AUQifmCEDzWbavxINLjMSoclOtgqpP,'year':AUQifmCEDzWbavxINLjMSoclOtgqYF,'cast':AUQifmCEDzWbavxINLjMSoclOtgqYH,'director':AUQifmCEDzWbavxINLjMSoclOtgqYP,'genre':AUQifmCEDzWbavxINLjMSoclOtgqYR,'duration':AUQifmCEDzWbavxINLjMSoclOtgqnp,'premiered':AUQifmCEDzWbavxINLjMSoclOtgqpB,'studio':AUQifmCEDzWbavxINLjMSoclOtgqpF,'mpaa':AUQifmCEDzWbavxINLjMSoclOtgqpe,'plot':AUQifmCEDzWbavxINLjMSoclOtgqYV}
   AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':'MOVIE','mediacode':AUQifmCEDzWbavxINLjMSoclOtgqnY.get('moviecode'),'stype':'movie','title':AUQifmCEDzWbavxINLjMSoclOtgqBr,'thumbnail':AUQifmCEDzWbavxINLjMSoclOtgqYk}
   if AUQifmCEDzWbavxINLjMSoclOtgqer.get_settings_makebookmark():
    AUQifmCEDzWbavxINLjMSoclOtgqpr={'videoid':AUQifmCEDzWbavxINLjMSoclOtgqnY.get('moviecode'),'vidtype':'movie','vtitle':AUQifmCEDzWbavxINLjMSoclOtgqpP,'vsubtitle':'',}
    AUQifmCEDzWbavxINLjMSoclOtgqpT=json.dumps(AUQifmCEDzWbavxINLjMSoclOtgqpr)
    AUQifmCEDzWbavxINLjMSoclOtgqpT=urllib.parse.quote(AUQifmCEDzWbavxINLjMSoclOtgqpT)
    AUQifmCEDzWbavxINLjMSoclOtgqpG='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(AUQifmCEDzWbavxINLjMSoclOtgqpT)
    AUQifmCEDzWbavxINLjMSoclOtgqpJ=[('(통합) 찜 영상에 추가',AUQifmCEDzWbavxINLjMSoclOtgqpG)]
   else:
    AUQifmCEDzWbavxINLjMSoclOtgqpJ=AUQifmCEDzWbavxINLjMSoclOtgqhe
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel='',img=AUQifmCEDzWbavxINLjMSoclOtgqYk,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqpY,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhp,params=AUQifmCEDzWbavxINLjMSoclOtgqBK,ContextMenu=AUQifmCEDzWbavxINLjMSoclOtgqpJ)
  if AUQifmCEDzWbavxINLjMSoclOtgqYJ:
   AUQifmCEDzWbavxINLjMSoclOtgqBK={}
   AUQifmCEDzWbavxINLjMSoclOtgqBK['mode'] ='MOVIE_SUB' 
   AUQifmCEDzWbavxINLjMSoclOtgqBK['orderby']=AUQifmCEDzWbavxINLjMSoclOtgqpy
   AUQifmCEDzWbavxINLjMSoclOtgqBK['stype'] =AUQifmCEDzWbavxINLjMSoclOtgqpw
   AUQifmCEDzWbavxINLjMSoclOtgqBK['page'] =AUQifmCEDzWbavxINLjMSoclOtgqhd(AUQifmCEDzWbavxINLjMSoclOtgqYT+1)
   AUQifmCEDzWbavxINLjMSoclOtgqBr='[B]%s >>[/B]'%'다음 페이지'
   AUQifmCEDzWbavxINLjMSoclOtgqpn=AUQifmCEDzWbavxINLjMSoclOtgqhd(AUQifmCEDzWbavxINLjMSoclOtgqYT+1)
   AUQifmCEDzWbavxINLjMSoclOtgqBV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel=AUQifmCEDzWbavxINLjMSoclOtgqpn,img=AUQifmCEDzWbavxINLjMSoclOtgqBV,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqhe,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhY,params=AUQifmCEDzWbavxINLjMSoclOtgqBK)
  xbmcplugin.setContent(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,'movies')
  xbmcplugin.endOfDirectory(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,cacheToDisc=AUQifmCEDzWbavxINLjMSoclOtgqhp)
 def dp_Set_Bookmark(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqnw=urllib.parse.unquote(AUQifmCEDzWbavxINLjMSoclOtgqYr.get('bm_param'))
  AUQifmCEDzWbavxINLjMSoclOtgqnw=json.loads(AUQifmCEDzWbavxINLjMSoclOtgqnw)
  AUQifmCEDzWbavxINLjMSoclOtgqny =AUQifmCEDzWbavxINLjMSoclOtgqnw.get('videoid')
  AUQifmCEDzWbavxINLjMSoclOtgqnh =AUQifmCEDzWbavxINLjMSoclOtgqnw.get('vidtype')
  AUQifmCEDzWbavxINLjMSoclOtgqnd =AUQifmCEDzWbavxINLjMSoclOtgqnw.get('vtitle')
  AUQifmCEDzWbavxINLjMSoclOtgqns =AUQifmCEDzWbavxINLjMSoclOtgqnw.get('vsubtitle')
  AUQifmCEDzWbavxINLjMSoclOtgqek=xbmcgui.Dialog()
  AUQifmCEDzWbavxINLjMSoclOtgqYn=AUQifmCEDzWbavxINLjMSoclOtgqek.yesno(__language__(30913).encode('utf8'),AUQifmCEDzWbavxINLjMSoclOtgqnd+' \n\n'+__language__(30914))
  if AUQifmCEDzWbavxINLjMSoclOtgqYn==AUQifmCEDzWbavxINLjMSoclOtgqhp:return
  AUQifmCEDzWbavxINLjMSoclOtgqnX=AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.GetBookmarkInfo(AUQifmCEDzWbavxINLjMSoclOtgqny,AUQifmCEDzWbavxINLjMSoclOtgqnh)
  if AUQifmCEDzWbavxINLjMSoclOtgqns!='':
   AUQifmCEDzWbavxINLjMSoclOtgqnX['saveinfo']['subtitle']=AUQifmCEDzWbavxINLjMSoclOtgqns 
   if AUQifmCEDzWbavxINLjMSoclOtgqnh=='tvshow':AUQifmCEDzWbavxINLjMSoclOtgqnX['saveinfo']['infoLabels']['studio']=AUQifmCEDzWbavxINLjMSoclOtgqns 
  AUQifmCEDzWbavxINLjMSoclOtgqnr=json.dumps(AUQifmCEDzWbavxINLjMSoclOtgqnX)
  AUQifmCEDzWbavxINLjMSoclOtgqnr=urllib.parse.quote(AUQifmCEDzWbavxINLjMSoclOtgqnr)
  AUQifmCEDzWbavxINLjMSoclOtgqpG ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(AUQifmCEDzWbavxINLjMSoclOtgqnr)
  xbmc.executebuiltin(AUQifmCEDzWbavxINLjMSoclOtgqpG)
 def dp_Search_Group(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  if 'search_key' in AUQifmCEDzWbavxINLjMSoclOtgqYr:
   AUQifmCEDzWbavxINLjMSoclOtgqnT=AUQifmCEDzWbavxINLjMSoclOtgqYr.get('search_key')
  else:
   AUQifmCEDzWbavxINLjMSoclOtgqnT=AUQifmCEDzWbavxINLjMSoclOtgqer.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not AUQifmCEDzWbavxINLjMSoclOtgqnT:
    return
  for AUQifmCEDzWbavxINLjMSoclOtgqYX in AUQifmCEDzWbavxINLjMSoclOtgqew:
   AUQifmCEDzWbavxINLjMSoclOtgqnG =AUQifmCEDzWbavxINLjMSoclOtgqYX.get('mode')
   AUQifmCEDzWbavxINLjMSoclOtgqYd=AUQifmCEDzWbavxINLjMSoclOtgqYX.get('stype')
   AUQifmCEDzWbavxINLjMSoclOtgqBr=AUQifmCEDzWbavxINLjMSoclOtgqYX.get('title')
   (AUQifmCEDzWbavxINLjMSoclOtgqnJ,AUQifmCEDzWbavxINLjMSoclOtgqYJ)=AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.GetSearchList(AUQifmCEDzWbavxINLjMSoclOtgqnT,1,AUQifmCEDzWbavxINLjMSoclOtgqYd)
   AUQifmCEDzWbavxINLjMSoclOtgqnu={'plot':'검색어 : '+AUQifmCEDzWbavxINLjMSoclOtgqnT+'\n\n'+AUQifmCEDzWbavxINLjMSoclOtgqer.Search_FreeList(AUQifmCEDzWbavxINLjMSoclOtgqnJ)}
   AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':AUQifmCEDzWbavxINLjMSoclOtgqnG,'stype':AUQifmCEDzWbavxINLjMSoclOtgqYd,'search_key':AUQifmCEDzWbavxINLjMSoclOtgqnT,'page':'1',}
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel='',img='',infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqnu,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhY,params=AUQifmCEDzWbavxINLjMSoclOtgqBK)
  if AUQifmCEDzWbavxINLjMSoclOtgqhy(AUQifmCEDzWbavxINLjMSoclOtgqew)>0:xbmcplugin.endOfDirectory(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,cacheToDisc=AUQifmCEDzWbavxINLjMSoclOtgqhY)
  AUQifmCEDzWbavxINLjMSoclOtgqer.Save_Searched_List(AUQifmCEDzWbavxINLjMSoclOtgqnT)
 def Search_FreeList(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqwB):
  AUQifmCEDzWbavxINLjMSoclOtgqnk=''
  AUQifmCEDzWbavxINLjMSoclOtgqnV=7
  try:
   if AUQifmCEDzWbavxINLjMSoclOtgqhy(AUQifmCEDzWbavxINLjMSoclOtgqwB)==0:return '검색결과 없음'
   for i in AUQifmCEDzWbavxINLjMSoclOtgqhs(AUQifmCEDzWbavxINLjMSoclOtgqhy(AUQifmCEDzWbavxINLjMSoclOtgqwB)):
    if i>=AUQifmCEDzWbavxINLjMSoclOtgqnV:
     AUQifmCEDzWbavxINLjMSoclOtgqnk=AUQifmCEDzWbavxINLjMSoclOtgqnk+'...'
     break
    AUQifmCEDzWbavxINLjMSoclOtgqnk=AUQifmCEDzWbavxINLjMSoclOtgqnk+AUQifmCEDzWbavxINLjMSoclOtgqwB[i]['title']+'\n'
  except:
   return ''
  return AUQifmCEDzWbavxINLjMSoclOtgqnk
 def dp_Search_History(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqnK=AUQifmCEDzWbavxINLjMSoclOtgqer.Load_List_File('search')
  for AUQifmCEDzWbavxINLjMSoclOtgqnH in AUQifmCEDzWbavxINLjMSoclOtgqnK:
   AUQifmCEDzWbavxINLjMSoclOtgqnP=AUQifmCEDzWbavxINLjMSoclOtgqhw(urllib.parse.parse_qsl(AUQifmCEDzWbavxINLjMSoclOtgqnH))
   AUQifmCEDzWbavxINLjMSoclOtgqnR=AUQifmCEDzWbavxINLjMSoclOtgqnP.get('skey').strip()
   AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':'SEARCH_GROUP','search_key':AUQifmCEDzWbavxINLjMSoclOtgqnR,}
   AUQifmCEDzWbavxINLjMSoclOtgqnF={'mode':'SEARCH_REMOVE','stype':'ONE','skey':AUQifmCEDzWbavxINLjMSoclOtgqnR,}
   AUQifmCEDzWbavxINLjMSoclOtgqwe=urllib.parse.urlencode(AUQifmCEDzWbavxINLjMSoclOtgqnF)
   AUQifmCEDzWbavxINLjMSoclOtgqpJ=[('선택된 검색어 ( %s ) 삭제'%(AUQifmCEDzWbavxINLjMSoclOtgqnR),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(AUQifmCEDzWbavxINLjMSoclOtgqwe))]
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqnR,sublabel='',img=AUQifmCEDzWbavxINLjMSoclOtgqhe,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqhe,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhY,params=AUQifmCEDzWbavxINLjMSoclOtgqBK,ContextMenu=AUQifmCEDzWbavxINLjMSoclOtgqpJ)
  AUQifmCEDzWbavxINLjMSoclOtgqpY={'plot':'검색목록 전체를 삭제합니다.'}
  AUQifmCEDzWbavxINLjMSoclOtgqBr='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  AUQifmCEDzWbavxINLjMSoclOtgqBV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel='',img=AUQifmCEDzWbavxINLjMSoclOtgqBV,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqpY,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhp,params=AUQifmCEDzWbavxINLjMSoclOtgqBK,isLink=AUQifmCEDzWbavxINLjMSoclOtgqhY)
  xbmcplugin.endOfDirectory(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,cacheToDisc=AUQifmCEDzWbavxINLjMSoclOtgqhp)
 def dp_Search_List(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.SaveCredential(AUQifmCEDzWbavxINLjMSoclOtgqer.get_winCredential())
  AUQifmCEDzWbavxINLjMSoclOtgqYT =AUQifmCEDzWbavxINLjMSoclOtgqhB(AUQifmCEDzWbavxINLjMSoclOtgqYr.get('page'))
  AUQifmCEDzWbavxINLjMSoclOtgqYd =AUQifmCEDzWbavxINLjMSoclOtgqYr.get('stype')
  if 'search_key' in AUQifmCEDzWbavxINLjMSoclOtgqYr:
   AUQifmCEDzWbavxINLjMSoclOtgqnT=AUQifmCEDzWbavxINLjMSoclOtgqYr.get('search_key')
  else:
   AUQifmCEDzWbavxINLjMSoclOtgqnT=AUQifmCEDzWbavxINLjMSoclOtgqer.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not AUQifmCEDzWbavxINLjMSoclOtgqnT:
    xbmcplugin.endOfDirectory(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle)
    return
  AUQifmCEDzWbavxINLjMSoclOtgqnJ,AUQifmCEDzWbavxINLjMSoclOtgqYJ=AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.GetSearchList(AUQifmCEDzWbavxINLjMSoclOtgqnT,AUQifmCEDzWbavxINLjMSoclOtgqYT,AUQifmCEDzWbavxINLjMSoclOtgqYd)
  for AUQifmCEDzWbavxINLjMSoclOtgqwB in AUQifmCEDzWbavxINLjMSoclOtgqnJ:
   AUQifmCEDzWbavxINLjMSoclOtgqBr =AUQifmCEDzWbavxINLjMSoclOtgqwB.get('title')
   AUQifmCEDzWbavxINLjMSoclOtgqYk =AUQifmCEDzWbavxINLjMSoclOtgqwB.get('thumbnail')
   AUQifmCEDzWbavxINLjMSoclOtgqYV =AUQifmCEDzWbavxINLjMSoclOtgqwB.get('synopsis')
   AUQifmCEDzWbavxINLjMSoclOtgqwY =AUQifmCEDzWbavxINLjMSoclOtgqwB.get('program')
   AUQifmCEDzWbavxINLjMSoclOtgqYH =AUQifmCEDzWbavxINLjMSoclOtgqwB.get('cast')
   AUQifmCEDzWbavxINLjMSoclOtgqYP =AUQifmCEDzWbavxINLjMSoclOtgqwB.get('director')
   AUQifmCEDzWbavxINLjMSoclOtgqYR=AUQifmCEDzWbavxINLjMSoclOtgqwB.get('info_genre')
   AUQifmCEDzWbavxINLjMSoclOtgqnp =AUQifmCEDzWbavxINLjMSoclOtgqwB.get('duration')
   AUQifmCEDzWbavxINLjMSoclOtgqpe =AUQifmCEDzWbavxINLjMSoclOtgqwB.get('mpaa')
   AUQifmCEDzWbavxINLjMSoclOtgqYF =AUQifmCEDzWbavxINLjMSoclOtgqwB.get('year')
   AUQifmCEDzWbavxINLjMSoclOtgqpR =AUQifmCEDzWbavxINLjMSoclOtgqwB.get('aired')
   AUQifmCEDzWbavxINLjMSoclOtgqpY={'mediatype':'tvshow' if AUQifmCEDzWbavxINLjMSoclOtgqYd=='vod' else 'movie','title':AUQifmCEDzWbavxINLjMSoclOtgqBr,'cast':AUQifmCEDzWbavxINLjMSoclOtgqYH,'director':AUQifmCEDzWbavxINLjMSoclOtgqYP,'genre':AUQifmCEDzWbavxINLjMSoclOtgqYR,'duration':AUQifmCEDzWbavxINLjMSoclOtgqnp,'mpaa':AUQifmCEDzWbavxINLjMSoclOtgqpe,'year':AUQifmCEDzWbavxINLjMSoclOtgqYF,'aired':AUQifmCEDzWbavxINLjMSoclOtgqpR,'plot':'%s\n\n%s'%(AUQifmCEDzWbavxINLjMSoclOtgqBr,AUQifmCEDzWbavxINLjMSoclOtgqYV)}
   if AUQifmCEDzWbavxINLjMSoclOtgqYd=='vod':
    AUQifmCEDzWbavxINLjMSoclOtgqny=AUQifmCEDzWbavxINLjMSoclOtgqwB.get('program')
    AUQifmCEDzWbavxINLjMSoclOtgqnh='tvshow'
    AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':'EPISODE','programcode':AUQifmCEDzWbavxINLjMSoclOtgqny,'page':'1',}
    AUQifmCEDzWbavxINLjMSoclOtgqBH=AUQifmCEDzWbavxINLjMSoclOtgqhY
   else:
    AUQifmCEDzWbavxINLjMSoclOtgqny=AUQifmCEDzWbavxINLjMSoclOtgqwB.get('movie')
    AUQifmCEDzWbavxINLjMSoclOtgqnh='movie'
    AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':'MOVIE','mediacode':AUQifmCEDzWbavxINLjMSoclOtgqny,'stype':'movie','title':AUQifmCEDzWbavxINLjMSoclOtgqBr,'thumbnail':AUQifmCEDzWbavxINLjMSoclOtgqYk,}
    AUQifmCEDzWbavxINLjMSoclOtgqBH=AUQifmCEDzWbavxINLjMSoclOtgqhp
   if AUQifmCEDzWbavxINLjMSoclOtgqer.get_settings_makebookmark():
    AUQifmCEDzWbavxINLjMSoclOtgqpr={'videoid':AUQifmCEDzWbavxINLjMSoclOtgqny,'vidtype':AUQifmCEDzWbavxINLjMSoclOtgqnh,'vtitle':AUQifmCEDzWbavxINLjMSoclOtgqBr,'vsubtitle':'',}
    AUQifmCEDzWbavxINLjMSoclOtgqpT=json.dumps(AUQifmCEDzWbavxINLjMSoclOtgqpr)
    AUQifmCEDzWbavxINLjMSoclOtgqpT=urllib.parse.quote(AUQifmCEDzWbavxINLjMSoclOtgqpT)
    AUQifmCEDzWbavxINLjMSoclOtgqpG='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(AUQifmCEDzWbavxINLjMSoclOtgqpT)
    AUQifmCEDzWbavxINLjMSoclOtgqpJ=[('(통합) 찜 영상에 추가',AUQifmCEDzWbavxINLjMSoclOtgqpG)]
   else:
    AUQifmCEDzWbavxINLjMSoclOtgqpJ=AUQifmCEDzWbavxINLjMSoclOtgqhe
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel='',img=AUQifmCEDzWbavxINLjMSoclOtgqYk,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqpY,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqBH,params=AUQifmCEDzWbavxINLjMSoclOtgqBK,isLink=AUQifmCEDzWbavxINLjMSoclOtgqhp,ContextMenu=AUQifmCEDzWbavxINLjMSoclOtgqpJ)
  if AUQifmCEDzWbavxINLjMSoclOtgqYJ:
   AUQifmCEDzWbavxINLjMSoclOtgqBK['mode'] ='SEARCH' 
   AUQifmCEDzWbavxINLjMSoclOtgqBK['search_key']=AUQifmCEDzWbavxINLjMSoclOtgqnT
   AUQifmCEDzWbavxINLjMSoclOtgqBK['page'] =AUQifmCEDzWbavxINLjMSoclOtgqhd(AUQifmCEDzWbavxINLjMSoclOtgqYT+1)
   AUQifmCEDzWbavxINLjMSoclOtgqBr='[B]%s >>[/B]'%'다음 페이지'
   AUQifmCEDzWbavxINLjMSoclOtgqpn=AUQifmCEDzWbavxINLjMSoclOtgqhd(AUQifmCEDzWbavxINLjMSoclOtgqYT+1)
   AUQifmCEDzWbavxINLjMSoclOtgqBV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel=AUQifmCEDzWbavxINLjMSoclOtgqpn,img=AUQifmCEDzWbavxINLjMSoclOtgqBV,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqhe,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhY,params=AUQifmCEDzWbavxINLjMSoclOtgqBK)
  if AUQifmCEDzWbavxINLjMSoclOtgqYd=='movie':xbmcplugin.setContent(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,'movies')
  else:xbmcplugin.setContent(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,cacheToDisc=AUQifmCEDzWbavxINLjMSoclOtgqhp)
 def Delete_List_File(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYd,skey='-'):
  if AUQifmCEDzWbavxINLjMSoclOtgqYd=='ALL':
   try:
    AUQifmCEDzWbavxINLjMSoclOtgqwp=AUQifmCEDzWbavxINLjMSoclOtgqeX
    fp=AUQifmCEDzWbavxINLjMSoclOtgqhX(AUQifmCEDzWbavxINLjMSoclOtgqwp,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    AUQifmCEDzWbavxINLjMSoclOtgqhe
  elif AUQifmCEDzWbavxINLjMSoclOtgqYd=='ONE':
   try:
    AUQifmCEDzWbavxINLjMSoclOtgqwp=AUQifmCEDzWbavxINLjMSoclOtgqeX
    AUQifmCEDzWbavxINLjMSoclOtgqwn=AUQifmCEDzWbavxINLjMSoclOtgqer.Load_List_File('search') 
    fp=AUQifmCEDzWbavxINLjMSoclOtgqhX(AUQifmCEDzWbavxINLjMSoclOtgqwp,'w',-1,'utf-8')
    for AUQifmCEDzWbavxINLjMSoclOtgqwy in AUQifmCEDzWbavxINLjMSoclOtgqwn:
     AUQifmCEDzWbavxINLjMSoclOtgqwh=AUQifmCEDzWbavxINLjMSoclOtgqhw(urllib.parse.parse_qsl(AUQifmCEDzWbavxINLjMSoclOtgqwy))
     AUQifmCEDzWbavxINLjMSoclOtgqwd=AUQifmCEDzWbavxINLjMSoclOtgqwh.get('skey').strip()
     if skey!=AUQifmCEDzWbavxINLjMSoclOtgqwd:
      fp.write(AUQifmCEDzWbavxINLjMSoclOtgqwy)
    fp.close()
   except:
    AUQifmCEDzWbavxINLjMSoclOtgqhe
  elif AUQifmCEDzWbavxINLjMSoclOtgqYd in['vod','movie']:
   try:
    AUQifmCEDzWbavxINLjMSoclOtgqwp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AUQifmCEDzWbavxINLjMSoclOtgqYd))
    fp=AUQifmCEDzWbavxINLjMSoclOtgqhX(AUQifmCEDzWbavxINLjMSoclOtgqwp,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    AUQifmCEDzWbavxINLjMSoclOtgqhe
 def dp_Listfile_Delete(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqYd=AUQifmCEDzWbavxINLjMSoclOtgqYr.get('stype')
  AUQifmCEDzWbavxINLjMSoclOtgqnR =AUQifmCEDzWbavxINLjMSoclOtgqYr.get('skey')
  AUQifmCEDzWbavxINLjMSoclOtgqek=xbmcgui.Dialog()
  if AUQifmCEDzWbavxINLjMSoclOtgqYd=='ALL':
   AUQifmCEDzWbavxINLjMSoclOtgqYn=AUQifmCEDzWbavxINLjMSoclOtgqek.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif AUQifmCEDzWbavxINLjMSoclOtgqYd=='ONE':
   AUQifmCEDzWbavxINLjMSoclOtgqYn=AUQifmCEDzWbavxINLjMSoclOtgqek.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif AUQifmCEDzWbavxINLjMSoclOtgqYd in['vod','movie']:
   AUQifmCEDzWbavxINLjMSoclOtgqYn=AUQifmCEDzWbavxINLjMSoclOtgqek.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if AUQifmCEDzWbavxINLjMSoclOtgqYn==AUQifmCEDzWbavxINLjMSoclOtgqhp:sys.exit()
  AUQifmCEDzWbavxINLjMSoclOtgqer.Delete_List_File(AUQifmCEDzWbavxINLjMSoclOtgqYd,skey=AUQifmCEDzWbavxINLjMSoclOtgqnR)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYd): 
  try:
   if AUQifmCEDzWbavxINLjMSoclOtgqYd=='search':
    AUQifmCEDzWbavxINLjMSoclOtgqwp=AUQifmCEDzWbavxINLjMSoclOtgqeX
   elif AUQifmCEDzWbavxINLjMSoclOtgqYd in['vod','movie']:
    AUQifmCEDzWbavxINLjMSoclOtgqwp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AUQifmCEDzWbavxINLjMSoclOtgqYd))
   else:
    return[]
   fp=AUQifmCEDzWbavxINLjMSoclOtgqhX(AUQifmCEDzWbavxINLjMSoclOtgqwp,'r',-1,'utf-8')
   AUQifmCEDzWbavxINLjMSoclOtgqws=fp.readlines()
   fp.close()
  except:
   AUQifmCEDzWbavxINLjMSoclOtgqws=[]
  return AUQifmCEDzWbavxINLjMSoclOtgqws
 def Save_Watched_List(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYd,AUQifmCEDzWbavxINLjMSoclOtgqeJ):
  try:
   AUQifmCEDzWbavxINLjMSoclOtgqwX=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%AUQifmCEDzWbavxINLjMSoclOtgqYd))
   AUQifmCEDzWbavxINLjMSoclOtgqwn=AUQifmCEDzWbavxINLjMSoclOtgqer.Load_List_File(AUQifmCEDzWbavxINLjMSoclOtgqYd) 
   fp=AUQifmCEDzWbavxINLjMSoclOtgqhX(AUQifmCEDzWbavxINLjMSoclOtgqwX,'w',-1,'utf-8')
   AUQifmCEDzWbavxINLjMSoclOtgqwr=urllib.parse.urlencode(AUQifmCEDzWbavxINLjMSoclOtgqeJ)
   AUQifmCEDzWbavxINLjMSoclOtgqwr=AUQifmCEDzWbavxINLjMSoclOtgqwr+'\n'
   fp.write(AUQifmCEDzWbavxINLjMSoclOtgqwr)
   AUQifmCEDzWbavxINLjMSoclOtgqwT=0
   for AUQifmCEDzWbavxINLjMSoclOtgqwy in AUQifmCEDzWbavxINLjMSoclOtgqwn:
    AUQifmCEDzWbavxINLjMSoclOtgqwh=AUQifmCEDzWbavxINLjMSoclOtgqhw(urllib.parse.parse_qsl(AUQifmCEDzWbavxINLjMSoclOtgqwy))
    AUQifmCEDzWbavxINLjMSoclOtgqwG=AUQifmCEDzWbavxINLjMSoclOtgqeJ.get('code').strip()
    AUQifmCEDzWbavxINLjMSoclOtgqwJ=AUQifmCEDzWbavxINLjMSoclOtgqwh.get('code').strip()
    if AUQifmCEDzWbavxINLjMSoclOtgqYd=='vod' and AUQifmCEDzWbavxINLjMSoclOtgqer.get_settings_direct_replay()==AUQifmCEDzWbavxINLjMSoclOtgqhY:
     AUQifmCEDzWbavxINLjMSoclOtgqwG=AUQifmCEDzWbavxINLjMSoclOtgqeJ.get('videoid').strip()
     AUQifmCEDzWbavxINLjMSoclOtgqwJ=AUQifmCEDzWbavxINLjMSoclOtgqwh.get('videoid').strip()if AUQifmCEDzWbavxINLjMSoclOtgqwJ!=AUQifmCEDzWbavxINLjMSoclOtgqhe else '-'
    if AUQifmCEDzWbavxINLjMSoclOtgqwG!=AUQifmCEDzWbavxINLjMSoclOtgqwJ:
     fp.write(AUQifmCEDzWbavxINLjMSoclOtgqwy)
     AUQifmCEDzWbavxINLjMSoclOtgqwT+=1
     if AUQifmCEDzWbavxINLjMSoclOtgqwT>=50:break
   fp.close()
  except:
   AUQifmCEDzWbavxINLjMSoclOtgqhe
 def dp_Watch_List(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqYd =AUQifmCEDzWbavxINLjMSoclOtgqYr.get('stype')
  AUQifmCEDzWbavxINLjMSoclOtgqBh=AUQifmCEDzWbavxINLjMSoclOtgqer.get_settings_direct_replay()
  if AUQifmCEDzWbavxINLjMSoclOtgqYd=='-':
   for AUQifmCEDzWbavxINLjMSoclOtgqYX in AUQifmCEDzWbavxINLjMSoclOtgqen:
    AUQifmCEDzWbavxINLjMSoclOtgqBr=AUQifmCEDzWbavxINLjMSoclOtgqYX.get('title')
    AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':AUQifmCEDzWbavxINLjMSoclOtgqYX.get('mode'),'stype':AUQifmCEDzWbavxINLjMSoclOtgqYX.get('stype')}
    AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel='',img='',infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqhe,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhY,params=AUQifmCEDzWbavxINLjMSoclOtgqBK)
   if AUQifmCEDzWbavxINLjMSoclOtgqhy(AUQifmCEDzWbavxINLjMSoclOtgqen)>0:xbmcplugin.endOfDirectory(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle)
  else:
   AUQifmCEDzWbavxINLjMSoclOtgqwu=AUQifmCEDzWbavxINLjMSoclOtgqer.Load_List_File(AUQifmCEDzWbavxINLjMSoclOtgqYd)
   for AUQifmCEDzWbavxINLjMSoclOtgqwk in AUQifmCEDzWbavxINLjMSoclOtgqwu:
    AUQifmCEDzWbavxINLjMSoclOtgqnP=AUQifmCEDzWbavxINLjMSoclOtgqhw(urllib.parse.parse_qsl(AUQifmCEDzWbavxINLjMSoclOtgqwk))
    AUQifmCEDzWbavxINLjMSoclOtgqwV =AUQifmCEDzWbavxINLjMSoclOtgqnP.get('code').strip()
    AUQifmCEDzWbavxINLjMSoclOtgqBr =AUQifmCEDzWbavxINLjMSoclOtgqnP.get('title').strip()
    AUQifmCEDzWbavxINLjMSoclOtgqYk=AUQifmCEDzWbavxINLjMSoclOtgqnP.get('img').strip()
    AUQifmCEDzWbavxINLjMSoclOtgqny =AUQifmCEDzWbavxINLjMSoclOtgqnP.get('videoid').strip()
    try:
     AUQifmCEDzWbavxINLjMSoclOtgqYk=AUQifmCEDzWbavxINLjMSoclOtgqYk.replace('\'','\"')
     AUQifmCEDzWbavxINLjMSoclOtgqYk=json.loads(AUQifmCEDzWbavxINLjMSoclOtgqYk)
    except:
     AUQifmCEDzWbavxINLjMSoclOtgqhe
    AUQifmCEDzWbavxINLjMSoclOtgqpY={}
    AUQifmCEDzWbavxINLjMSoclOtgqpY['plot']=AUQifmCEDzWbavxINLjMSoclOtgqBr
    if AUQifmCEDzWbavxINLjMSoclOtgqYd=='vod':
     if AUQifmCEDzWbavxINLjMSoclOtgqBh==AUQifmCEDzWbavxINLjMSoclOtgqhp or AUQifmCEDzWbavxINLjMSoclOtgqny==AUQifmCEDzWbavxINLjMSoclOtgqhe:
      AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':'EPISODE','programcode':AUQifmCEDzWbavxINLjMSoclOtgqwV,'page':'1'}
      AUQifmCEDzWbavxINLjMSoclOtgqBH=AUQifmCEDzWbavxINLjMSoclOtgqhY
     else:
      AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':'VOD','mediacode':AUQifmCEDzWbavxINLjMSoclOtgqny,'stype':'vod','programcode':AUQifmCEDzWbavxINLjMSoclOtgqwV,'title':AUQifmCEDzWbavxINLjMSoclOtgqBr,'thumbnail':AUQifmCEDzWbavxINLjMSoclOtgqYk}
      AUQifmCEDzWbavxINLjMSoclOtgqBH=AUQifmCEDzWbavxINLjMSoclOtgqhp
    else:
     AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':'MOVIE','mediacode':AUQifmCEDzWbavxINLjMSoclOtgqwV,'stype':'movie','title':AUQifmCEDzWbavxINLjMSoclOtgqBr,'thumbnail':AUQifmCEDzWbavxINLjMSoclOtgqYk}
     AUQifmCEDzWbavxINLjMSoclOtgqBH=AUQifmCEDzWbavxINLjMSoclOtgqhp
    AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel='',img=AUQifmCEDzWbavxINLjMSoclOtgqYk,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqpY,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqBH,params=AUQifmCEDzWbavxINLjMSoclOtgqBK)
   AUQifmCEDzWbavxINLjMSoclOtgqpY={'plot':'시청목록을 삭제합니다.'}
   AUQifmCEDzWbavxINLjMSoclOtgqBr='*** 시청목록 삭제 ***'
   AUQifmCEDzWbavxINLjMSoclOtgqBK={'mode':'MYVIEW_REMOVE','stype':AUQifmCEDzWbavxINLjMSoclOtgqYd,'skey':'-',}
   AUQifmCEDzWbavxINLjMSoclOtgqBV=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   AUQifmCEDzWbavxINLjMSoclOtgqer.add_dir(AUQifmCEDzWbavxINLjMSoclOtgqBr,sublabel='',img=AUQifmCEDzWbavxINLjMSoclOtgqBV,infoLabels=AUQifmCEDzWbavxINLjMSoclOtgqpY,isFolder=AUQifmCEDzWbavxINLjMSoclOtgqhp,params=AUQifmCEDzWbavxINLjMSoclOtgqBK,isLink=AUQifmCEDzWbavxINLjMSoclOtgqhY)
   if AUQifmCEDzWbavxINLjMSoclOtgqYd=='movie':xbmcplugin.setContent(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,'movies')
   else:xbmcplugin.setContent(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,cacheToDisc=AUQifmCEDzWbavxINLjMSoclOtgqhp)
 def Save_Searched_List(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqnT):
  try:
   AUQifmCEDzWbavxINLjMSoclOtgqwK=AUQifmCEDzWbavxINLjMSoclOtgqeX
   AUQifmCEDzWbavxINLjMSoclOtgqwn=AUQifmCEDzWbavxINLjMSoclOtgqer.Load_List_File('search') 
   AUQifmCEDzWbavxINLjMSoclOtgqwH={'skey':AUQifmCEDzWbavxINLjMSoclOtgqnT.strip()}
   fp=AUQifmCEDzWbavxINLjMSoclOtgqhX(AUQifmCEDzWbavxINLjMSoclOtgqwK,'w',-1,'utf-8')
   AUQifmCEDzWbavxINLjMSoclOtgqwr=urllib.parse.urlencode(AUQifmCEDzWbavxINLjMSoclOtgqwH)
   AUQifmCEDzWbavxINLjMSoclOtgqwr=AUQifmCEDzWbavxINLjMSoclOtgqwr+'\n'
   fp.write(AUQifmCEDzWbavxINLjMSoclOtgqwr)
   AUQifmCEDzWbavxINLjMSoclOtgqwT=0
   for AUQifmCEDzWbavxINLjMSoclOtgqwy in AUQifmCEDzWbavxINLjMSoclOtgqwn:
    AUQifmCEDzWbavxINLjMSoclOtgqwh=AUQifmCEDzWbavxINLjMSoclOtgqhw(urllib.parse.parse_qsl(AUQifmCEDzWbavxINLjMSoclOtgqwy))
    AUQifmCEDzWbavxINLjMSoclOtgqwG=AUQifmCEDzWbavxINLjMSoclOtgqwH.get('skey').strip()
    AUQifmCEDzWbavxINLjMSoclOtgqwJ=AUQifmCEDzWbavxINLjMSoclOtgqwh.get('skey').strip()
    if AUQifmCEDzWbavxINLjMSoclOtgqwG!=AUQifmCEDzWbavxINLjMSoclOtgqwJ:
     fp.write(AUQifmCEDzWbavxINLjMSoclOtgqwy)
     AUQifmCEDzWbavxINLjMSoclOtgqwT+=1
     if AUQifmCEDzWbavxINLjMSoclOtgqwT>=50:break
   fp.close()
  except:
   AUQifmCEDzWbavxINLjMSoclOtgqhe
 def play_VIDEO(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.SaveCredential(AUQifmCEDzWbavxINLjMSoclOtgqer.get_winCredential())
  AUQifmCEDzWbavxINLjMSoclOtgqwP =AUQifmCEDzWbavxINLjMSoclOtgqYr.get('mediacode')
  AUQifmCEDzWbavxINLjMSoclOtgqYd =AUQifmCEDzWbavxINLjMSoclOtgqYr.get('stype')
  AUQifmCEDzWbavxINLjMSoclOtgqwR =AUQifmCEDzWbavxINLjMSoclOtgqYr.get('pvrmode')
  AUQifmCEDzWbavxINLjMSoclOtgqwF=AUQifmCEDzWbavxINLjMSoclOtgqer.get_selQuality(AUQifmCEDzWbavxINLjMSoclOtgqYd)
  AUQifmCEDzWbavxINLjMSoclOtgqye,AUQifmCEDzWbavxINLjMSoclOtgqyB=AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.GetBroadURL(AUQifmCEDzWbavxINLjMSoclOtgqwP,AUQifmCEDzWbavxINLjMSoclOtgqwF,AUQifmCEDzWbavxINLjMSoclOtgqYd,AUQifmCEDzWbavxINLjMSoclOtgqwR)
  AUQifmCEDzWbavxINLjMSoclOtgqer.addon_log('qt, stype, url : %s - %s - %s'%(AUQifmCEDzWbavxINLjMSoclOtgqhd(AUQifmCEDzWbavxINLjMSoclOtgqwF),AUQifmCEDzWbavxINLjMSoclOtgqYd,AUQifmCEDzWbavxINLjMSoclOtgqye))
  if AUQifmCEDzWbavxINLjMSoclOtgqye=='':
   AUQifmCEDzWbavxINLjMSoclOtgqer.addon_noti(__language__(30908).encode('utf8'))
   return
  AUQifmCEDzWbavxINLjMSoclOtgqyY =AUQifmCEDzWbavxINLjMSoclOtgqye.find('Policy=')
  if AUQifmCEDzWbavxINLjMSoclOtgqyY!=-1:
   AUQifmCEDzWbavxINLjMSoclOtgqyp =AUQifmCEDzWbavxINLjMSoclOtgqye.split('?')[0]
   AUQifmCEDzWbavxINLjMSoclOtgqyn=AUQifmCEDzWbavxINLjMSoclOtgqhw(urllib.parse.parse_qsl(urllib.parse.urlsplit(AUQifmCEDzWbavxINLjMSoclOtgqye).query))
   AUQifmCEDzWbavxINLjMSoclOtgqyn=urllib.parse.urlencode(AUQifmCEDzWbavxINLjMSoclOtgqyn)
   AUQifmCEDzWbavxINLjMSoclOtgqyn=AUQifmCEDzWbavxINLjMSoclOtgqyn.replace('&',';')
   AUQifmCEDzWbavxINLjMSoclOtgqyn=AUQifmCEDzWbavxINLjMSoclOtgqyn.replace('Policy','CloudFront-Policy')
   AUQifmCEDzWbavxINLjMSoclOtgqyn=AUQifmCEDzWbavxINLjMSoclOtgqyn.replace('Signature','CloudFront-Signature')
   AUQifmCEDzWbavxINLjMSoclOtgqyn=AUQifmCEDzWbavxINLjMSoclOtgqyn.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   AUQifmCEDzWbavxINLjMSoclOtgqyw='%s|Cookie=%s'%(AUQifmCEDzWbavxINLjMSoclOtgqyp,AUQifmCEDzWbavxINLjMSoclOtgqyn)
  else:
   AUQifmCEDzWbavxINLjMSoclOtgqyw=AUQifmCEDzWbavxINLjMSoclOtgqye
  AUQifmCEDzWbavxINLjMSoclOtgqer.addon_log(AUQifmCEDzWbavxINLjMSoclOtgqyw)
  AUQifmCEDzWbavxINLjMSoclOtgqyh=xbmcgui.ListItem(path=AUQifmCEDzWbavxINLjMSoclOtgqyw)
  if AUQifmCEDzWbavxINLjMSoclOtgqyB!='':
   AUQifmCEDzWbavxINLjMSoclOtgqyd=AUQifmCEDzWbavxINLjMSoclOtgqyB
   AUQifmCEDzWbavxINLjMSoclOtgqys ='https://cj.drmkeyserver.com/widevine_license'
   AUQifmCEDzWbavxINLjMSoclOtgqyX ='mpd'
   AUQifmCEDzWbavxINLjMSoclOtgqyr ='com.widevine.alpha'
   AUQifmCEDzWbavxINLjMSoclOtgqyT =inputstreamhelper.Helper(AUQifmCEDzWbavxINLjMSoclOtgqyX,drm='widevine')
   if AUQifmCEDzWbavxINLjMSoclOtgqyT.check_inputstream():
    AUQifmCEDzWbavxINLjMSoclOtgqyG={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%AUQifmCEDzWbavxINLjMSoclOtgqwP,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.USER_AGENT,'AcquireLicenseAssertion':AUQifmCEDzWbavxINLjMSoclOtgqyd,'Host':'cj.drmkeyserver.com'}
    AUQifmCEDzWbavxINLjMSoclOtgqyJ=AUQifmCEDzWbavxINLjMSoclOtgqys+'|'+urllib.parse.urlencode(AUQifmCEDzWbavxINLjMSoclOtgqyG)+'|R{SSM}|'
    AUQifmCEDzWbavxINLjMSoclOtgqyh.setProperty('inputstream',AUQifmCEDzWbavxINLjMSoclOtgqyT.inputstream_addon)
    AUQifmCEDzWbavxINLjMSoclOtgqyh.setProperty('inputstream.adaptive.manifest_type',AUQifmCEDzWbavxINLjMSoclOtgqyX)
    AUQifmCEDzWbavxINLjMSoclOtgqyh.setProperty('inputstream.adaptive.license_type',AUQifmCEDzWbavxINLjMSoclOtgqyr)
    AUQifmCEDzWbavxINLjMSoclOtgqyh.setProperty('inputstream.adaptive.license_key',AUQifmCEDzWbavxINLjMSoclOtgqyJ)
    AUQifmCEDzWbavxINLjMSoclOtgqyh.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.USER_AGENT))
  xbmcplugin.setResolvedUrl(AUQifmCEDzWbavxINLjMSoclOtgqer._addon_handle,AUQifmCEDzWbavxINLjMSoclOtgqhY,AUQifmCEDzWbavxINLjMSoclOtgqyh)
  try:
   if AUQifmCEDzWbavxINLjMSoclOtgqYr.get('mode')in['VOD','MOVIE']and AUQifmCEDzWbavxINLjMSoclOtgqYr.get('title'):
    AUQifmCEDzWbavxINLjMSoclOtgqBK={'code':AUQifmCEDzWbavxINLjMSoclOtgqYr.get('programcode')if AUQifmCEDzWbavxINLjMSoclOtgqYr.get('mode')=='VOD' else AUQifmCEDzWbavxINLjMSoclOtgqYr.get('mediacode'),'img':AUQifmCEDzWbavxINLjMSoclOtgqYr.get('thumbnail'),'title':AUQifmCEDzWbavxINLjMSoclOtgqYr.get('title'),'videoid':AUQifmCEDzWbavxINLjMSoclOtgqYr.get('mediacode')}
    AUQifmCEDzWbavxINLjMSoclOtgqer.Save_Watched_List(AUQifmCEDzWbavxINLjMSoclOtgqYr.get('stype'),AUQifmCEDzWbavxINLjMSoclOtgqBK)
  except:
   AUQifmCEDzWbavxINLjMSoclOtgqhe
 def logout(AUQifmCEDzWbavxINLjMSoclOtgqer):
  AUQifmCEDzWbavxINLjMSoclOtgqek=xbmcgui.Dialog()
  AUQifmCEDzWbavxINLjMSoclOtgqYn=AUQifmCEDzWbavxINLjMSoclOtgqek.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if AUQifmCEDzWbavxINLjMSoclOtgqYn==AUQifmCEDzWbavxINLjMSoclOtgqhp:sys.exit()
  AUQifmCEDzWbavxINLjMSoclOtgqer.wininfo_clear()
  if os.path.isfile(AUQifmCEDzWbavxINLjMSoclOtgqes):os.remove(AUQifmCEDzWbavxINLjMSoclOtgqes)
  AUQifmCEDzWbavxINLjMSoclOtgqer.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(AUQifmCEDzWbavxINLjMSoclOtgqer):
  AUQifmCEDzWbavxINLjMSoclOtgqBd=xbmcgui.Window(10000)
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_TOKEN','')
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_USERINFO','')
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_UUID','')
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_LOGINTIME','')
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_MAINTOKEN','')
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_COOKIEKEY','')
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(AUQifmCEDzWbavxINLjMSoclOtgqer):
  AUQifmCEDzWbavxINLjMSoclOtgqyu =AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.Get_Now_Datetime()
  AUQifmCEDzWbavxINLjMSoclOtgqyk=AUQifmCEDzWbavxINLjMSoclOtgqyu+datetime.timedelta(days=AUQifmCEDzWbavxINLjMSoclOtgqhB(__addon__.getSetting('cache_ttl')))
  AUQifmCEDzWbavxINLjMSoclOtgqBd=xbmcgui.Window(10000)
  AUQifmCEDzWbavxINLjMSoclOtgqyV={'tving_token':AUQifmCEDzWbavxINLjMSoclOtgqBd.getProperty('TVING_M_TOKEN'),'tving_userinfo':AUQifmCEDzWbavxINLjMSoclOtgqBd.getProperty('TVING_M_USERINFO'),'tving_uuid':AUQifmCEDzWbavxINLjMSoclOtgqBd.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':AUQifmCEDzWbavxINLjMSoclOtgqyk.strftime('%Y-%m-%d'),'tving_maintoken':AUQifmCEDzWbavxINLjMSoclOtgqBd.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':AUQifmCEDzWbavxINLjMSoclOtgqBd.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':AUQifmCEDzWbavxINLjMSoclOtgqBd.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=AUQifmCEDzWbavxINLjMSoclOtgqhX(AUQifmCEDzWbavxINLjMSoclOtgqes,'w',-1,'utf-8')
   json.dump(AUQifmCEDzWbavxINLjMSoclOtgqyV,fp)
   fp.close()
  except AUQifmCEDzWbavxINLjMSoclOtgqhr as exception:
   AUQifmCEDzWbavxINLjMSoclOtgqhT(exception)
 def cookiefile_check(AUQifmCEDzWbavxINLjMSoclOtgqer):
  AUQifmCEDzWbavxINLjMSoclOtgqyV={}
  try: 
   fp=AUQifmCEDzWbavxINLjMSoclOtgqhX(AUQifmCEDzWbavxINLjMSoclOtgqes,'r',-1,'utf-8')
   AUQifmCEDzWbavxINLjMSoclOtgqyV= json.load(fp)
   fp.close()
  except AUQifmCEDzWbavxINLjMSoclOtgqhr as exception:
   AUQifmCEDzWbavxINLjMSoclOtgqer.wininfo_clear()
   return AUQifmCEDzWbavxINLjMSoclOtgqhp
  AUQifmCEDzWbavxINLjMSoclOtgqBF =__addon__.getSetting('id')
  AUQifmCEDzWbavxINLjMSoclOtgqYe =__addon__.getSetting('pw')
  AUQifmCEDzWbavxINLjMSoclOtgqyK=__addon__.getSetting('login_type')
  AUQifmCEDzWbavxINLjMSoclOtgqyH =__addon__.getSetting('selected_profile')
  AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_id']=base64.standard_b64decode(AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_id']).decode('utf-8')
  AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_pw']=base64.standard_b64decode(AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_pw']).decode('utf-8')
  try:
   AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_profile']
  except:
   AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_profile']='0'
  if AUQifmCEDzWbavxINLjMSoclOtgqBF!=AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_id']or AUQifmCEDzWbavxINLjMSoclOtgqYe!=AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_pw']or AUQifmCEDzWbavxINLjMSoclOtgqyK!=AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_logintype']or AUQifmCEDzWbavxINLjMSoclOtgqyH!=AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_profile']:
   AUQifmCEDzWbavxINLjMSoclOtgqer.wininfo_clear()
   return AUQifmCEDzWbavxINLjMSoclOtgqhp
  AUQifmCEDzWbavxINLjMSoclOtgqYw =AUQifmCEDzWbavxINLjMSoclOtgqhB(AUQifmCEDzWbavxINLjMSoclOtgqer.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  AUQifmCEDzWbavxINLjMSoclOtgqyP=AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_limitdate']
  AUQifmCEDzWbavxINLjMSoclOtgqYy =AUQifmCEDzWbavxINLjMSoclOtgqhB(re.sub('-','',AUQifmCEDzWbavxINLjMSoclOtgqyP))
  if AUQifmCEDzWbavxINLjMSoclOtgqYy<AUQifmCEDzWbavxINLjMSoclOtgqYw:
   AUQifmCEDzWbavxINLjMSoclOtgqer.wininfo_clear()
   return AUQifmCEDzWbavxINLjMSoclOtgqhp
  AUQifmCEDzWbavxINLjMSoclOtgqBd=xbmcgui.Window(10000)
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_TOKEN',AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_token'])
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_USERINFO',AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_userinfo'])
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_UUID',AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_uuid'])
  AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_LOGINTIME',AUQifmCEDzWbavxINLjMSoclOtgqyP)
  try:
   AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_MAINTOKEN',AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_maintoken'])
   AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_COOKIEKEY',AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_cookiekey'])
   AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_LOCKKEY',AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_lockkey'])
  except:
   AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_MAINTOKEN',AUQifmCEDzWbavxINLjMSoclOtgqyV['tving_token'])
   AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_COOKIEKEY','Y')
   AUQifmCEDzWbavxINLjMSoclOtgqBd.setProperty('TVING_M_LOCKKEY','N')
  return AUQifmCEDzWbavxINLjMSoclOtgqhY
 def dp_Global_Search(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqnG=AUQifmCEDzWbavxINLjMSoclOtgqYr.get('mode')
  if AUQifmCEDzWbavxINLjMSoclOtgqnG=='TOTAL_SEARCH':
   AUQifmCEDzWbavxINLjMSoclOtgqyR='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   AUQifmCEDzWbavxINLjMSoclOtgqyR='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(AUQifmCEDzWbavxINLjMSoclOtgqyR)
 def dp_Bookmark_Menu(AUQifmCEDzWbavxINLjMSoclOtgqer,AUQifmCEDzWbavxINLjMSoclOtgqYr):
  AUQifmCEDzWbavxINLjMSoclOtgqyR='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(AUQifmCEDzWbavxINLjMSoclOtgqyR)
 def tving_main(AUQifmCEDzWbavxINLjMSoclOtgqer):
  AUQifmCEDzWbavxINLjMSoclOtgqnG=AUQifmCEDzWbavxINLjMSoclOtgqer.main_params.get('mode',AUQifmCEDzWbavxINLjMSoclOtgqhe)
  if AUQifmCEDzWbavxINLjMSoclOtgqnG=='LOGOUT':
   AUQifmCEDzWbavxINLjMSoclOtgqer.logout()
   return
  AUQifmCEDzWbavxINLjMSoclOtgqer.login_main()
  if AUQifmCEDzWbavxINLjMSoclOtgqnG is AUQifmCEDzWbavxINLjMSoclOtgqhe:
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_Main_List()
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_Title_Group(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG in['GLOBAL_GROUP']:
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_SubTitle_Group(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG=='CHANNEL':
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_LiveChannel_List(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG in['LIVE','VOD','MOVIE']:
   AUQifmCEDzWbavxINLjMSoclOtgqer.play_VIDEO(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG=='PROGRAM':
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_Program_List(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG=='EPISODE':
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_Episode_List(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG=='MOVIE_SUB':
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_Movie_List(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG=='SEARCH_GROUP':
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_Search_Group(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG in['SEARCH','LOCAL_SEARCH']:
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_Search_List(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG=='WATCH':
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_Watch_List(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_Listfile_Delete(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG=='ORDER_BY':
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_setEpOrderby(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG=='SET_BOOKMARK':
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_Set_Bookmark(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG in['TOTAL_SEARCH','TOTAL_HISTORY']:
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_Global_Search(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG=='SEARCH_HISTORY':
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_Search_History(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  elif AUQifmCEDzWbavxINLjMSoclOtgqnG=='MENU_BOOKMARK':
   AUQifmCEDzWbavxINLjMSoclOtgqer.dp_Bookmark_Menu(AUQifmCEDzWbavxINLjMSoclOtgqer.main_params)
  else:
   AUQifmCEDzWbavxINLjMSoclOtgqhe
# Created by pyminifier (https://github.com/liftoff/pyminifier)
