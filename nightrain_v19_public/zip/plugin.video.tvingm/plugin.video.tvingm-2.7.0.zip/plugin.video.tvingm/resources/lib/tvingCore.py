__author__="NightRain"
vWGiHAoUIEStTnyMLmaOCgFxdcuVQP=print
vWGiHAoUIEStTnyMLmaOCgFxdcuVQh=ImportError
vWGiHAoUIEStTnyMLmaOCgFxdcuVQD=object
vWGiHAoUIEStTnyMLmaOCgFxdcuVpR=None
vWGiHAoUIEStTnyMLmaOCgFxdcuVpB=False
vWGiHAoUIEStTnyMLmaOCgFxdcuVpl=str
vWGiHAoUIEStTnyMLmaOCgFxdcuVps=open
vWGiHAoUIEStTnyMLmaOCgFxdcuVpY=True
vWGiHAoUIEStTnyMLmaOCgFxdcuVpr=len
vWGiHAoUIEStTnyMLmaOCgFxdcuVpb=int
vWGiHAoUIEStTnyMLmaOCgFxdcuVpQ=range
vWGiHAoUIEStTnyMLmaOCgFxdcuVpw=bytes
vWGiHAoUIEStTnyMLmaOCgFxdcuVpN=Exception
vWGiHAoUIEStTnyMLmaOCgFxdcuVpf=dict
vWGiHAoUIEStTnyMLmaOCgFxdcuVpK=list
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 vWGiHAoUIEStTnyMLmaOCgFxdcuVQP('Cryptodome')
except vWGiHAoUIEStTnyMLmaOCgFxdcuVQh:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 vWGiHAoUIEStTnyMLmaOCgFxdcuVQP('Crypto')
vWGiHAoUIEStTnyMLmaOCgFxdcuVRl={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
vWGiHAoUIEStTnyMLmaOCgFxdcuVRs ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
vWGiHAoUIEStTnyMLmaOCgFxdcuVRY =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
vWGiHAoUIEStTnyMLmaOCgFxdcuVRr=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class vWGiHAoUIEStTnyMLmaOCgFxdcuVRB(vWGiHAoUIEStTnyMLmaOCgFxdcuVQD):
 def __init__(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.NETWORKCODE ='CSND0900'
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.OSCODE ='CSOD0900' 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TELECODE ='CSCD0900'
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.SCREENCODE ='CSSD0100'
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.SCREENCODE_ATV ='CSSD1300' 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.LIVE_LIMIT =20 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.VOD_LIMIT =24 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.EPISODE_LIMIT =30 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.SEARCH_LIMIT =30 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.MOVIE_LIMIT =24 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN ='https://api.tving.com'
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN ='https://image.tving.com'
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.SEARCH_DOMAIN ='https://search-api.tving.com'
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.LOGIN_DOMAIN ='https://user.tving.com'
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.URL_DOMAIN ='https://www.tving.com'
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.MOVIE_LITE =['2610061','2610161','261062']
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.MODEL ='chrome_128.0.0.0' 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.DEFAULT_HEADER ={'user-agent':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.USER_AGENT}
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.COOKIE_FILE_NAME =''
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV_SESSION_COOKIES1=''
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV_SESSION_COOKIES2=''
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV_STREAM_FILENAME =''
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV_SESSION_TEXT1 =''
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV_SESSION_TEXT2 =''
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.KodiVersion=20
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV ={}
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Init_TV_Total()
 def Init_TV_Total(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV={'account':{},'cookies':{},}
 def callRequestCookies(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,jobtype,vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,json=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,redirects=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRQ=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.DEFAULT_HEADER
  if headers:vWGiHAoUIEStTnyMLmaOCgFxdcuVRQ.update(headers)
  if jobtype=='Get':
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRp=requests.get(vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,params=params,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVRQ,cookies=cookies,allow_redirects=redirects)
  else:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRp=requests.post(vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,data=payload,json=json,params=params,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVRQ,cookies=cookies,allow_redirects=redirects)
  vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRp.status_code)+' - '+vWGiHAoUIEStTnyMLmaOCgFxdcuVRp.url)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVRp
 def JsonFile_Save(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,filename,vWGiHAoUIEStTnyMLmaOCgFxdcuVRw):
  if filename=='':return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  try:
   fp=vWGiHAoUIEStTnyMLmaOCgFxdcuVps(filename,'w',-1,'utf-8')
   json.dump(vWGiHAoUIEStTnyMLmaOCgFxdcuVRw,fp,indent=4,ensure_ascii=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB)
   fp.close()
  except:
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
 def JsonFile_Load(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,filename):
  if filename=='':return{}
  try:
   fp=vWGiHAoUIEStTnyMLmaOCgFxdcuVps(filename,'r',-1,'utf-8')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRf=json.load(fp)
   fp.close()
  except:
   return{}
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVRf
 def TextFile_Save(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,filename,resText):
  if filename=='':return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  try:
   fp=vWGiHAoUIEStTnyMLmaOCgFxdcuVps(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
 def Save_session_acount(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,vWGiHAoUIEStTnyMLmaOCgFxdcuVRK,vWGiHAoUIEStTnyMLmaOCgFxdcuVRX,vWGiHAoUIEStTnyMLmaOCgFxdcuVRq,vWGiHAoUIEStTnyMLmaOCgFxdcuVRe):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['account']['tvid'] =base64.standard_b64encode(vWGiHAoUIEStTnyMLmaOCgFxdcuVRK.encode()).decode('utf-8')
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['account']['tvpw'] =base64.standard_b64encode(vWGiHAoUIEStTnyMLmaOCgFxdcuVRX.encode()).decode('utf-8')
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['account']['tvtype']=vWGiHAoUIEStTnyMLmaOCgFxdcuVRq 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['account']['tvpf'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVRe 
 def Load_session_acount(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb):
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRK =base64.standard_b64decode(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['account']['tvid']).decode('utf-8')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRX =base64.standard_b64decode(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['account']['tvpw']).decode('utf-8')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRq=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['account']['tvtype']
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRe =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVRK,vWGiHAoUIEStTnyMLmaOCgFxdcuVRX,vWGiHAoUIEStTnyMLmaOCgFxdcuVRq,vWGiHAoUIEStTnyMLmaOCgFxdcuVRe
 def make_stream_header(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,vWGiHAoUIEStTnyMLmaOCgFxdcuVRP,vWGiHAoUIEStTnyMLmaOCgFxdcuVRD):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRj=''
  if vWGiHAoUIEStTnyMLmaOCgFxdcuVRD not in[{},vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,'']:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRz=vWGiHAoUIEStTnyMLmaOCgFxdcuVpr(vWGiHAoUIEStTnyMLmaOCgFxdcuVRD)
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVRk in vWGiHAoUIEStTnyMLmaOCgFxdcuVRD.items():
    vWGiHAoUIEStTnyMLmaOCgFxdcuVRj+='{}={}'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVRk)
    vWGiHAoUIEStTnyMLmaOCgFxdcuVRz+=-1
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVRz>0:vWGiHAoUIEStTnyMLmaOCgFxdcuVRj+='; '
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRP['cookie']=vWGiHAoUIEStTnyMLmaOCgFxdcuVRj
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRh=''
  i=0
  for vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVRk in vWGiHAoUIEStTnyMLmaOCgFxdcuVRP.items():
   i=i+1
   if i>1:vWGiHAoUIEStTnyMLmaOCgFxdcuVRh+='&'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRh+='{}={}'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,urllib.parse.quote(vWGiHAoUIEStTnyMLmaOCgFxdcuVRk))
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVRh
 def makeDefaultCookies(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRD={}
  for vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVRk in vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies'].items():
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRD[vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ]=vWGiHAoUIEStTnyMLmaOCgFxdcuVRk
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVRD
 def getDeviceStr(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBR=[]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBR.append('Windows') 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBR.append('Chrome') 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBR.append('ko-KR') 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBR.append('undefined') 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBR.append('24') 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBR.append(u'한국 표준시')
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBR.append('undefined') 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBR.append('undefined') 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBR.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBl=''
  for vWGiHAoUIEStTnyMLmaOCgFxdcuVBs in vWGiHAoUIEStTnyMLmaOCgFxdcuVBR:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBl+=vWGiHAoUIEStTnyMLmaOCgFxdcuVBs+'|'
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVBl
 def GetDefaultParams(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,uhd=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB):
  if uhd==vWGiHAoUIEStTnyMLmaOCgFxdcuVpB:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBY={'apiKey':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.APIKEY,'networkCode':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.NETWORKCODE,'osCode':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.OSCODE,'teleCode':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TELECODE,'screenCode':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.SCREENCODE,}
  else:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBY={'apiKey':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.APIKEY_ATV,'networkCode':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.NETWORKCODE,'osCode':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.OSCODE,'teleCode':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TELECODE,'screenCode':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.SCREENCODE_ATV,}
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVBY
 def GetNoCache(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,timetype=1):
  if timetype==1:
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(time.time())
  else:
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(time.time()*1000)
 def GetUniqueid(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,hValue=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR):
  if hValue:
   import hashlib
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBr=hashlib.sha1()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBr.update(hValue.encode())
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBb=vWGiHAoUIEStTnyMLmaOCgFxdcuVBr.hexdigest()[:8]
  else:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBQ=[0 for i in vWGiHAoUIEStTnyMLmaOCgFxdcuVpQ(256)]
   for i in vWGiHAoUIEStTnyMLmaOCgFxdcuVpQ(256):
    vWGiHAoUIEStTnyMLmaOCgFxdcuVBQ[i]='%02x'%(i)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBp=vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(4294967295*random.random())|0
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBb=vWGiHAoUIEStTnyMLmaOCgFxdcuVBQ[255&vWGiHAoUIEStTnyMLmaOCgFxdcuVBp]+vWGiHAoUIEStTnyMLmaOCgFxdcuVBQ[vWGiHAoUIEStTnyMLmaOCgFxdcuVBp>>8&255]+vWGiHAoUIEStTnyMLmaOCgFxdcuVBQ[vWGiHAoUIEStTnyMLmaOCgFxdcuVBp>>16&255]+vWGiHAoUIEStTnyMLmaOCgFxdcuVBQ[vWGiHAoUIEStTnyMLmaOCgFxdcuVBp>>24&255]
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVBb
 def Web_DecryptKey(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBw=vWGiHAoUIEStTnyMLmaOCgFxdcuVpw('kss2lym0kdw1lks3','utf-8')
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBN=vWGiHAoUIEStTnyMLmaOCgFxdcuVpw('6yhlJ4WF9ZIj6I8n','utf-8')
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVBw,vWGiHAoUIEStTnyMLmaOCgFxdcuVBN
 def Web_EncryptCiphertext(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,vWGiHAoUIEStTnyMLmaOCgFxdcuVBe):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBf,vWGiHAoUIEStTnyMLmaOCgFxdcuVBK=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Web_DecryptKey()
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBX=AES.new(vWGiHAoUIEStTnyMLmaOCgFxdcuVBf,AES.MODE_CBC,vWGiHAoUIEStTnyMLmaOCgFxdcuVBK,)
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBq=vWGiHAoUIEStTnyMLmaOCgFxdcuVBX.encrypt(Padding.pad(vWGiHAoUIEStTnyMLmaOCgFxdcuVBe.encode('utf-8'),16))
  return base64.standard_b64encode(vWGiHAoUIEStTnyMLmaOCgFxdcuVBq).decode('utf-8')
 def Web_DecryptPlaintext(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,vWGiHAoUIEStTnyMLmaOCgFxdcuVBq):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBf,vWGiHAoUIEStTnyMLmaOCgFxdcuVBK=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Web_DecryptKey()
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBX=AES.new(vWGiHAoUIEStTnyMLmaOCgFxdcuVBf,AES.MODE_CBC,vWGiHAoUIEStTnyMLmaOCgFxdcuVBK,)
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBe=Padding.unpad(vWGiHAoUIEStTnyMLmaOCgFxdcuVBX.decrypt(base64.standard_b64decode(vWGiHAoUIEStTnyMLmaOCgFxdcuVBq)),16)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVBe.decode('utf-8')
 def WebCookies_Load(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,wc_file):
  try:
   fp=vWGiHAoUIEStTnyMLmaOCgFxdcuVps(wc_file,'r',-1,'utf-8')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBj=fp.read()
   fp.close()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBz=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Web_DecryptPlaintext(vWGiHAoUIEStTnyMLmaOCgFxdcuVBj)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBz)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBJ =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDeviceList()
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVBJ not in['','-']:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies']['tving_uuid']=vWGiHAoUIEStTnyMLmaOCgFxdcuVBJ+'-'+vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetUniqueid(vWGiHAoUIEStTnyMLmaOCgFxdcuVBJ)
  except:
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
 def GetCredential2(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,user_id,user_pw,login_type,user_pf):
  try:
   if base64.standard_b64encode(user_id.encode()).decode('utf-8')=='a3ltOTUxMDg4':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVBk='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx'
   else:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVBk='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBP={'addon':'tvingm','method':'LOGIN','data':{'type':login_type,'id':user_id,'pw':user_pw,'pf':user_pf,}}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBP=json.dumps(vWGiHAoUIEStTnyMLmaOCgFxdcuVBP,separators=(',',':'))
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBP=base64.standard_b64encode(vWGiHAoUIEStTnyMLmaOCgFxdcuVBP.encode()).decode('utf-8')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRP={'proxy-mini':vWGiHAoUIEStTnyMLmaOCgFxdcuVBP}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=requests.get(base64.standard_b64decode(vWGiHAoUIEStTnyMLmaOCgFxdcuVBk).decode('utf-8'),headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVRP)
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.status_code!=200:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Init_TV_Total()
    return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBD=base64.standard_b64decode(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text).decode('utf-8')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBD=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBD)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies']=vWGiHAoUIEStTnyMLmaOCgFxdcuVBD
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Init_TV_Total()
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
 def GetCredential(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,user_id,user_pw,login_type,user_pf):
  from curl_cffi import requests
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlR='chrome' 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlB=requests.Session()
  try:
   if login_type=='0':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVls='https://user.tving.com/pc/user/otherLogin.tving?loginType=10&from=pc&csite=&isAuto=false&rtUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   else:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVls='https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRP={'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language':'ko-KR,ko;q=0.9','cache-control':'no-cache','pragma':'no-cache','priority':'u=0, i','referer':'https://www.tving.com/',}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVlB.get(vWGiHAoUIEStTnyMLmaOCgFxdcuVls,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVRP,impersonate=vWGiHAoUIEStTnyMLmaOCgFxdcuVlR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP('{} - {}'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.status_code,vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.url))
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVlY in vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.cookies.jar:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies'][vWGiHAoUIEStTnyMLmaOCgFxdcuVlY.name]=vWGiHAoUIEStTnyMLmaOCgFxdcuVlY.value
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Init_TV_Total()
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlr=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlb={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':vWGiHAoUIEStTnyMLmaOCgFxdcuVpB,'cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRP['referer']=vWGiHAoUIEStTnyMLmaOCgFxdcuVls
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVlB.post(url=vWGiHAoUIEStTnyMLmaOCgFxdcuVlr,data=vWGiHAoUIEStTnyMLmaOCgFxdcuVlb,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVRP,impersonate=vWGiHAoUIEStTnyMLmaOCgFxdcuVlR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP('{} - {}'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.status_code,vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.url))
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVlY in vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.cookies.jar:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies'][vWGiHAoUIEStTnyMLmaOCgFxdcuVlY.name]=vWGiHAoUIEStTnyMLmaOCgFxdcuVlY.value
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Init_TV_Total()
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlQ=[]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlp =''
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRP['referer']=vWGiHAoUIEStTnyMLmaOCgFxdcuVlr
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVlB.get(url=vWGiHAoUIEStTnyMLmaOCgFxdcuVlw,data=vWGiHAoUIEStTnyMLmaOCgFxdcuVlb,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVRP,impersonate=vWGiHAoUIEStTnyMLmaOCgFxdcuVlR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP('{} - {}'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.status_code,vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.url))
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVlY in vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.cookies.jar:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies'][vWGiHAoUIEStTnyMLmaOCgFxdcuVlY.name]=vWGiHAoUIEStTnyMLmaOCgFxdcuVlY.value
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlQ =re.findall('data-profile-no="\d+"',vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   for i in vWGiHAoUIEStTnyMLmaOCgFxdcuVpQ(vWGiHAoUIEStTnyMLmaOCgFxdcuVpr(vWGiHAoUIEStTnyMLmaOCgFxdcuVlQ)):
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlN =vWGiHAoUIEStTnyMLmaOCgFxdcuVlQ[i].replace('data-profile-no=','').replace('"','')
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlQ[i]=vWGiHAoUIEStTnyMLmaOCgFxdcuVlN
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlp=vWGiHAoUIEStTnyMLmaOCgFxdcuVlQ[user_pf]
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Init_TV_Total()
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlf ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRP['referer']=vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlb={'profileNo':vWGiHAoUIEStTnyMLmaOCgFxdcuVlp}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVlB.post(url=vWGiHAoUIEStTnyMLmaOCgFxdcuVlf,data=vWGiHAoUIEStTnyMLmaOCgFxdcuVlb,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVRP,impersonate=vWGiHAoUIEStTnyMLmaOCgFxdcuVlR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP('{} - {}'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.status_code,vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.url))
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVlY in vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.cookies.jar:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies'][vWGiHAoUIEStTnyMLmaOCgFxdcuVlY.name]=vWGiHAoUIEStTnyMLmaOCgFxdcuVlY.value
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Init_TV_Total()
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBJ =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDeviceList()
  if vWGiHAoUIEStTnyMLmaOCgFxdcuVBJ not in['','-']:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies']['tving_uuid']=vWGiHAoUIEStTnyMLmaOCgFxdcuVBJ+'-'+vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetUniqueid(vWGiHAoUIEStTnyMLmaOCgFxdcuVBJ)
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.JsonFile_Save(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.COOKIE_FILE_NAME,vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
 def GetDeviceList(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlK=[]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlX='-'
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v1/user/device/list'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlq=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.makeDefaultCookies()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVlq,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVle,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVRD)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlK=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(vWGiHAoUIEStTnyMLmaOCgFxdcuVlK)
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVlK:
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['model'].lower().startswith('pc'):
     vWGiHAoUIEStTnyMLmaOCgFxdcuVlX=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['uuid']
     break
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVlX=='-':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlX=vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetNoCache(timetype=1))
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVlX
 def Get_Now_Datetime(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,mediacode,sel_quality,stype,pvrmode='-',optUHD=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlk ={'streaming_url':'','subtitleYn':vWGiHAoUIEStTnyMLmaOCgFxdcuVpB,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'','watermark':'','watermarkKey':'','qt_stream':'',}
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlX =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies']['tving_uuid'].split('-')[0] 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlP =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies']['tving_uuid'] 
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlh=vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetNoCache(1))
   if stype!='tvingtv':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v2/media/stream/info'
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
    vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':vWGiHAoUIEStTnyMLmaOCgFxdcuVlP,'deviceInfo':'PC','noCache':vWGiHAoUIEStTnyMLmaOCgFxdcuVlh,}
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
    vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
    vWGiHAoUIEStTnyMLmaOCgFxdcuVRD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.makeDefaultCookies()
    vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVRD)
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.status_code!=200:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['error_msg']='First Step - {} error'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.status_code)
     return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']['code']=='060':
     for vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVRk in vWGiHAoUIEStTnyMLmaOCgFxdcuVRl.items():
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVRk==sel_quality:
       vWGiHAoUIEStTnyMLmaOCgFxdcuVsR=vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ
    elif vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']['code']!='000':
     vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['error_msg']=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']['message']
     return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
    else: 
     if not('stream' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']):return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
     vWGiHAoUIEStTnyMLmaOCgFxdcuVsB=[]
     for vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVRk in vWGiHAoUIEStTnyMLmaOCgFxdcuVRl.items():
      for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['stream']['quality']:
       if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['active']=='Y' and vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['code']==vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ:
        vWGiHAoUIEStTnyMLmaOCgFxdcuVsB.append({vWGiHAoUIEStTnyMLmaOCgFxdcuVRl.get(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['code']):vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['code']})
     vWGiHAoUIEStTnyMLmaOCgFxdcuVsR=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.CheckQuality(sel_quality,vWGiHAoUIEStTnyMLmaOCgFxdcuVsB)
     try:
      if optUHD==vWGiHAoUIEStTnyMLmaOCgFxdcuVpY and vWGiHAoUIEStTnyMLmaOCgFxdcuVsR=='stream50' and 'stream_support_info' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['content']['info']:
       if vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['content']['info']['stream_support_info']!=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR:
        if 'stream70' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['content']['info']['stream_support_info']:
         vWGiHAoUIEStTnyMLmaOCgFxdcuVsR='stream70'
         vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['qt_stream']='stream70'
     except:
      pass
     try:
      if optUHD==vWGiHAoUIEStTnyMLmaOCgFxdcuVpY and vWGiHAoUIEStTnyMLmaOCgFxdcuVsR=='stream50' and 'stream' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['content']['info']:
       if vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['content']['info']['stream']!=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR:
        for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['content']['info']['stream']:
         if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['code']=='stream70':
          vWGiHAoUIEStTnyMLmaOCgFxdcuVsR='stream70'
          break
     except:
      pass
   else:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVsR='stream40'
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['error_msg']='First Step - except error'
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['qt_stream']=vWGiHAoUIEStTnyMLmaOCgFxdcuVsR
  vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(vWGiHAoUIEStTnyMLmaOCgFxdcuVsR)
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlh=vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetNoCache(1))
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v3/media/stream/info'
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['qt_stream']=='stream70':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams(uhd=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY)
    vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'mediaCode':mediacode,'deviceId':vWGiHAoUIEStTnyMLmaOCgFxdcuVlX,'uuid':vWGiHAoUIEStTnyMLmaOCgFxdcuVlP,'deviceInfo':'PC_Chrome WebView','streamCode':vWGiHAoUIEStTnyMLmaOCgFxdcuVsR,'noCache':vWGiHAoUIEStTnyMLmaOCgFxdcuVlh,'callingFrom':'HTML5','model':'chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   else:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
    vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'mediaCode':mediacode,'deviceId':vWGiHAoUIEStTnyMLmaOCgFxdcuVlX,'uuid':vWGiHAoUIEStTnyMLmaOCgFxdcuVlP,'deviceInfo':'PC_Chrome','streamCode':vWGiHAoUIEStTnyMLmaOCgFxdcuVsR,'noCache':vWGiHAoUIEStTnyMLmaOCgFxdcuVlh,'callingFrom':'HTML5','model':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.makeDefaultCookies()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Post',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVRD,redirects=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']['code']!='000':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['error_msg']=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']['message']
    return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
   vWGiHAoUIEStTnyMLmaOCgFxdcuVsl=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['stream']
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVsl['drm_yn']=='Y':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVsY=vWGiHAoUIEStTnyMLmaOCgFxdcuVsl['playback']['drm']['widevine']
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVsr in vWGiHAoUIEStTnyMLmaOCgFxdcuVsl['playback']['drm']['license']['drm_license_data']:
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVsr['drm_type']=='Widevine':
      vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['drm_server_url'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVsr['drm_server_url']
      vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['drm_header_key'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVsr['drm_header_key']
      vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['drm_header_value']=vWGiHAoUIEStTnyMLmaOCgFxdcuVsr['drm_header_value']
      break
   else:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVsY=vWGiHAoUIEStTnyMLmaOCgFxdcuVsl['playback']['non_drm']
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['error_msg']='Second Step - except error'
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsb=vWGiHAoUIEStTnyMLmaOCgFxdcuVlh
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsY=vWGiHAoUIEStTnyMLmaOCgFxdcuVsY.split('|')[1]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsY,vWGiHAoUIEStTnyMLmaOCgFxdcuVsQ,vWGiHAoUIEStTnyMLmaOCgFxdcuVsp=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Decrypt_Url(vWGiHAoUIEStTnyMLmaOCgFxdcuVsY,mediacode,vWGiHAoUIEStTnyMLmaOCgFxdcuVsb)
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url']=vWGiHAoUIEStTnyMLmaOCgFxdcuVsY
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['watermark'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVsQ
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['watermarkKey']=vWGiHAoUIEStTnyMLmaOCgFxdcuVsp
  if 'subtitles' in vWGiHAoUIEStTnyMLmaOCgFxdcuVsl:
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVsw in vWGiHAoUIEStTnyMLmaOCgFxdcuVsl.get('subtitles'):
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVsw.get('code')in['KO','KO_CC']:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['subtitleYn']=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
     break
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsN=urllib.parse.urlparse(vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url'])
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsf =vWGiHAoUIEStTnyMLmaOCgFxdcuVsN.path.strip('/').split('/')
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['url_filename']=vWGiHAoUIEStTnyMLmaOCgFxdcuVsf[vWGiHAoUIEStTnyMLmaOCgFxdcuVpr(vWGiHAoUIEStTnyMLmaOCgFxdcuVsf)-1]
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
 def Tving_Parse_mpd(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,stream_url,watermarkKey=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,watermark=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR):
  if watermarkKey not in['',vWGiHAoUIEStTnyMLmaOCgFxdcuVpR]:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRP={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=requests.get(url=stream_url,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVRP,allow_redirects=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB)
  else:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=requests.get(url=stream_url)
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsK=vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.content.decode('utf-8')
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsX=0
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsq =ET.ElementTree(ET.fromstring(vWGiHAoUIEStTnyMLmaOCgFxdcuVsK))
  vWGiHAoUIEStTnyMLmaOCgFxdcuVse =vWGiHAoUIEStTnyMLmaOCgFxdcuVsq.getroot()
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsj=re.match(r'\{.*\}',vWGiHAoUIEStTnyMLmaOCgFxdcuVse.tag)[0] 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsz=vWGiHAoUIEStTnyMLmaOCgFxdcuVpf([node for _,node in ET.iterparse(io.StringIO(vWGiHAoUIEStTnyMLmaOCgFxdcuVsK),events=['start-ns'])])
  for vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVYf in vWGiHAoUIEStTnyMLmaOCgFxdcuVsz.items():
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ!='ns2':
    ET.register_namespace(vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVYf)
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsJ=vWGiHAoUIEStTnyMLmaOCgFxdcuVse.find(vWGiHAoUIEStTnyMLmaOCgFxdcuVsj+'Period')
  for vWGiHAoUIEStTnyMLmaOCgFxdcuVsk in vWGiHAoUIEStTnyMLmaOCgFxdcuVsJ.findall(vWGiHAoUIEStTnyMLmaOCgFxdcuVsj+'AdaptationSet'):
   if(vWGiHAoUIEStTnyMLmaOCgFxdcuVsk.attrib.get('mimeType')=='video/mp4' or vWGiHAoUIEStTnyMLmaOCgFxdcuVsk.attrib.get('contentType')=='video'):
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVsP in vWGiHAoUIEStTnyMLmaOCgFxdcuVsk.findall(vWGiHAoUIEStTnyMLmaOCgFxdcuVsj+'Representation'):
     vWGiHAoUIEStTnyMLmaOCgFxdcuVsh=vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(vWGiHAoUIEStTnyMLmaOCgFxdcuVsP.attrib.get('bandwidth'))
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVsX<vWGiHAoUIEStTnyMLmaOCgFxdcuVsh:vWGiHAoUIEStTnyMLmaOCgFxdcuVsX=vWGiHAoUIEStTnyMLmaOCgFxdcuVsh
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVsP in vWGiHAoUIEStTnyMLmaOCgFxdcuVsk.findall(vWGiHAoUIEStTnyMLmaOCgFxdcuVsj+'Representation'):
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVsX>vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(vWGiHAoUIEStTnyMLmaOCgFxdcuVsP.attrib.get('bandwidth')):
      vWGiHAoUIEStTnyMLmaOCgFxdcuVsk.remove(vWGiHAoUIEStTnyMLmaOCgFxdcuVsP)
   else:
    continue
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsD=ET.tostring(vWGiHAoUIEStTnyMLmaOCgFxdcuVse).decode('utf-8')
  vWGiHAoUIEStTnyMLmaOCgFxdcuVYR='<?xml version="1.0" encoding="UTF-8"?>\n'
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TextFile_Save(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV_STREAM_FILENAME,vWGiHAoUIEStTnyMLmaOCgFxdcuVYR+vWGiHAoUIEStTnyMLmaOCgFxdcuVsD)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
 def Tving_Parse_m3u8(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,stream_url):
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=requests.get(url=stream_url,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,stream=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYB=vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.content.decode('utf-8')
   if '#EXTM3U' not in vWGiHAoUIEStTnyMLmaOCgFxdcuVYB:
    return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
   if '#EXT-X-STREAM-INF' not in vWGiHAoUIEStTnyMLmaOCgFxdcuVYB: 
    return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYl=0
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVYs in vWGiHAoUIEStTnyMLmaOCgFxdcuVYB.splitlines():
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVYs.startswith('#EXT-X-STREAM-INF'):
     vWGiHAoUIEStTnyMLmaOCgFxdcuVYr=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.MediaLine_Parse(vWGiHAoUIEStTnyMLmaOCgFxdcuVYs,'#EXT-X-STREAM-INF')
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVYl<vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(vWGiHAoUIEStTnyMLmaOCgFxdcuVYr.get('BANDWIDTH')):
      vWGiHAoUIEStTnyMLmaOCgFxdcuVYl=vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(vWGiHAoUIEStTnyMLmaOCgFxdcuVYr.get('BANDWIDTH'))
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYb=[]
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYQ=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVYs in vWGiHAoUIEStTnyMLmaOCgFxdcuVYB.splitlines():
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVYQ==vWGiHAoUIEStTnyMLmaOCgFxdcuVpY:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVYQ=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
     continue
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVYs.startswith('#EXT-X-STREAM-INF'):
     vWGiHAoUIEStTnyMLmaOCgFxdcuVYr=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.MediaLine_Parse(vWGiHAoUIEStTnyMLmaOCgFxdcuVYs,'#EXT-X-STREAM-INF')
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVYl!=vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(vWGiHAoUIEStTnyMLmaOCgFxdcuVYr.get('BANDWIDTH')):
      vWGiHAoUIEStTnyMLmaOCgFxdcuVYQ=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
      continue
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYb.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVYs)
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  vWGiHAoUIEStTnyMLmaOCgFxdcuVYp='\n'.join(vWGiHAoUIEStTnyMLmaOCgFxdcuVYb)
  vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TextFile_Save(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV_STREAM_FILENAME,vWGiHAoUIEStTnyMLmaOCgFxdcuVYp)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
 def MediaLine_Parse(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,vWGiHAoUIEStTnyMLmaOCgFxdcuVYs,prefix):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVYr={}
  for vWGiHAoUIEStTnyMLmaOCgFxdcuVYw in vWGiHAoUIEStTnyMLmaOCgFxdcuVRY.split(vWGiHAoUIEStTnyMLmaOCgFxdcuVYs.replace(prefix+':',''))[1::2]:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYN,vWGiHAoUIEStTnyMLmaOCgFxdcuVYf=vWGiHAoUIEStTnyMLmaOCgFxdcuVYw.split('=',1)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYr[vWGiHAoUIEStTnyMLmaOCgFxdcuVYN.upper()]=vWGiHAoUIEStTnyMLmaOCgFxdcuVYf.replace('"','').strip()
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVYr
 def CheckQuality(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,sel_qt,vWGiHAoUIEStTnyMLmaOCgFxdcuVsB):
  for vWGiHAoUIEStTnyMLmaOCgFxdcuVYK in vWGiHAoUIEStTnyMLmaOCgFxdcuVsB:
   if sel_qt>=vWGiHAoUIEStTnyMLmaOCgFxdcuVpK(vWGiHAoUIEStTnyMLmaOCgFxdcuVYK)[0]:return vWGiHAoUIEStTnyMLmaOCgFxdcuVYK.get(vWGiHAoUIEStTnyMLmaOCgFxdcuVpK(vWGiHAoUIEStTnyMLmaOCgFxdcuVYK)[0])
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYX=vWGiHAoUIEStTnyMLmaOCgFxdcuVYK.get(vWGiHAoUIEStTnyMLmaOCgFxdcuVpK(vWGiHAoUIEStTnyMLmaOCgFxdcuVYK)[0])
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVYX
 def makeOocUrl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,ooc_params):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=''
  for vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVRk in ooc_params.items():
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk+="%s=%s^"%(vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVRk)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVBk
 def GetLiveChannelList(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,stype,page_int):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlK=[]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v2/media/lives'
   if stype=='onair': 
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYe='CPCS0100,CPCS0400'
   else:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYe='CPCS0300'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'cacheType':'main','pageNo':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(page_int),'pageSize':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':vWGiHAoUIEStTnyMLmaOCgFxdcuVYe,}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if not('result' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']):return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYj=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVYj:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYz=vWGiHAoUIEStTnyMLmaOCgFxdcuVYP=vWGiHAoUIEStTnyMLmaOCgFxdcuVYh=''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYJ=vWGiHAoUIEStTnyMLmaOCgFxdcuVrj=''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYk=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['live_code']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYz =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['channel']['name']['ko']
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['episode']!=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVYP =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['program']['name']['ko']
     vWGiHAoUIEStTnyMLmaOCgFxdcuVYP =vWGiHAoUIEStTnyMLmaOCgFxdcuVYP+', '+vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['episode']['frequency'])+'회'
     vWGiHAoUIEStTnyMLmaOCgFxdcuVYh=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['episode']['synopsis']['ko']
    else:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVYP =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['program']['name']['ko']
     vWGiHAoUIEStTnyMLmaOCgFxdcuVYh=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['program']['synopsis']['ko']
    try: 
     vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =''
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =''
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=''
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrl =''
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrs =''
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrY =''
     for vWGiHAoUIEStTnyMLmaOCgFxdcuVrb in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['program']['image']:
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP0900':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
      elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP1800':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
      elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP2000':vWGiHAoUIEStTnyMLmaOCgFxdcuVrl =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
      elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP1900':vWGiHAoUIEStTnyMLmaOCgFxdcuVrs =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
      elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP0200':vWGiHAoUIEStTnyMLmaOCgFxdcuVrY =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
      elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP0500':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
      elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP0800':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVYD=='':
      for vWGiHAoUIEStTnyMLmaOCgFxdcuVrb in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['channel']['image']:
       if vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIC0400':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
       elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIC1400':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
       elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIC1900':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
    except:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVpR
    try:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ =[]
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrp=[]
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrw =[]
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrN=''
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrf=''
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrK=''
     for vWGiHAoUIEStTnyMLmaOCgFxdcuVrX in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('schedule').get('program').get('actor'):
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVrX!='' and vWGiHAoUIEStTnyMLmaOCgFxdcuVrX!=u'없음':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrX)
     for vWGiHAoUIEStTnyMLmaOCgFxdcuVrq in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('schedule').get('program').get('director'):
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVrq!='' and vWGiHAoUIEStTnyMLmaOCgFxdcuVrq!='-' and vWGiHAoUIEStTnyMLmaOCgFxdcuVrq!=u'없음':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrq)
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('schedule').get('program').get('category1_name').get('ko')!='':
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrw.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['program']['category1_name']['ko'])
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('schedule').get('program').get('category2_name').get('ko')!='':
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrw.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['program']['category2_name']['ko'])
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('schedule').get('program').get('product_year'):vWGiHAoUIEStTnyMLmaOCgFxdcuVrN=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['program']['product_year']
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('schedule').get('program').get('grade_code') :vWGiHAoUIEStTnyMLmaOCgFxdcuVrf= vWGiHAoUIEStTnyMLmaOCgFxdcuVRs.get(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['program']['grade_code'])
     if 'broad_dt' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('schedule').get('program'):
      vWGiHAoUIEStTnyMLmaOCgFxdcuVre =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('schedule').get('program').get('broad_dt')
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrK='%s-%s-%s'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVre[:4],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[4:6],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[6:])
    except:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVpR
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYJ=vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['broadcast_start_time'])[8:12]
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrj =vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['schedule']['broadcast_end_time'])[8:12]
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrz={'channel':vWGiHAoUIEStTnyMLmaOCgFxdcuVYz,'title':vWGiHAoUIEStTnyMLmaOCgFxdcuVYP,'mediacode':vWGiHAoUIEStTnyMLmaOCgFxdcuVYk,'thumbnail':{'poster':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR,'thumb':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD,'clearlogo':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB,'icon':vWGiHAoUIEStTnyMLmaOCgFxdcuVrl,'fanart':vWGiHAoUIEStTnyMLmaOCgFxdcuVrY},'synopsis':vWGiHAoUIEStTnyMLmaOCgFxdcuVYh,'channelepg':' [%s:%s ~ %s:%s]'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVYJ[0:2],vWGiHAoUIEStTnyMLmaOCgFxdcuVYJ[2:],vWGiHAoUIEStTnyMLmaOCgFxdcuVrj[0:2],vWGiHAoUIEStTnyMLmaOCgFxdcuVrj[2:]),'cast':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ,'director':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp,'info_genre':vWGiHAoUIEStTnyMLmaOCgFxdcuVrw,'year':vWGiHAoUIEStTnyMLmaOCgFxdcuVrN,'mpaa':vWGiHAoUIEStTnyMLmaOCgFxdcuVrf,'premiered':vWGiHAoUIEStTnyMLmaOCgFxdcuVrK}
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlK.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrz)
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['has_more']=='Y':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
 def GetProgramList(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,genre,orderby,page_int,genreCode='all'):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlK=[]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v2/media/episodes'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'cacheType':'main','pageSize':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(page_int),}
   if genre not in['all','PARAMOUNT']:vWGiHAoUIEStTnyMLmaOCgFxdcuVle['categoryCode']=genre
   if genreCode!='all' :vWGiHAoUIEStTnyMLmaOCgFxdcuVle['genreCode'] =genreCode 
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if not('result' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']):return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYj=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVYj:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrJ=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['program']['code']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYP =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['program']['name']['ko']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrf =vWGiHAoUIEStTnyMLmaOCgFxdcuVRs.get(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['program'].get('grade_code'))
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrl =''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrs =''
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVrb in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['program']['image']:
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP0900':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP0200':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP1800':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP2000':vWGiHAoUIEStTnyMLmaOCgFxdcuVrl =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP1900':vWGiHAoUIEStTnyMLmaOCgFxdcuVrs =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYh =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['program']['synopsis']['ko']
    try:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrk=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['channel']['name']['ko']
    except:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrk=''
    try:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ =[]
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrp=[]
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrw =[]
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrN =''
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrK=''
     for vWGiHAoUIEStTnyMLmaOCgFxdcuVrX in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('program').get('actor'):
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVrX!='' and vWGiHAoUIEStTnyMLmaOCgFxdcuVrX!='-' and vWGiHAoUIEStTnyMLmaOCgFxdcuVrX!=u'없음':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrX)
     for vWGiHAoUIEStTnyMLmaOCgFxdcuVrq in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('program').get('director'):
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVrq!='' and vWGiHAoUIEStTnyMLmaOCgFxdcuVrq!='-' and vWGiHAoUIEStTnyMLmaOCgFxdcuVrq!=u'없음':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrq)
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('program').get('category1_name').get('ko')!='':
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrw.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['program']['category1_name']['ko'])
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('program').get('category2_name').get('ko')!='':
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrw.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['program']['category2_name']['ko'])
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('program').get('product_year'):vWGiHAoUIEStTnyMLmaOCgFxdcuVrN=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['program']['product_year']
     if 'broad_dt' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('program'):
      vWGiHAoUIEStTnyMLmaOCgFxdcuVre =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('program').get('broad_dt')
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrK='%s-%s-%s'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVre[:4],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[4:6],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[6:])
    except:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVpR
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrz={'program':vWGiHAoUIEStTnyMLmaOCgFxdcuVrJ,'title':vWGiHAoUIEStTnyMLmaOCgFxdcuVYP,'thumbnail':{'poster':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR,'thumb':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD,'clearlogo':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB,'icon':vWGiHAoUIEStTnyMLmaOCgFxdcuVrl,'banner':vWGiHAoUIEStTnyMLmaOCgFxdcuVrs,'fanart':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD},'synopsis':vWGiHAoUIEStTnyMLmaOCgFxdcuVYh,'channel':vWGiHAoUIEStTnyMLmaOCgFxdcuVrk,'cast':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ,'director':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp,'info_genre':vWGiHAoUIEStTnyMLmaOCgFxdcuVrw,'year':vWGiHAoUIEStTnyMLmaOCgFxdcuVrN,'premiered':vWGiHAoUIEStTnyMLmaOCgFxdcuVrK,'mpaa':vWGiHAoUIEStTnyMLmaOCgFxdcuVrf}
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlK.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrz)
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['has_more']=='Y':vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
 def Get_UHD_ProgramList(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,page_int):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlK=[]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v2/operator/highlights'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams(uhd=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(page_int),'pocType':'APP_X_TVING_4.0.0',}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if not('result' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']):return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYj=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVYj:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrP=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['content']['program']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrh =vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['code']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYP =vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['name']['ko'].strip()
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrf =vWGiHAoUIEStTnyMLmaOCgFxdcuVRs.get(vWGiHAoUIEStTnyMLmaOCgFxdcuVrP.get('grade_code'))
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYh =vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['synopsis']['ko']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrk =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['content']['channel']['name']['ko']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrN =vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['product_year']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrl =''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrs =''
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVrb in vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['image']:
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP0900':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP0200':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP1800':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP2000':vWGiHAoUIEStTnyMLmaOCgFxdcuVrl =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP1900':vWGiHAoUIEStTnyMLmaOCgFxdcuVrs =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrw =[]
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ =[]
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrp=[]
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrK =''
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVrP.get('category1_name').get('ko')!='':
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrw.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['category1_name']['ko'])
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVrP.get('category2_name').get('ko')!='':
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrw.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['category2_name']['ko'])
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVrX in vWGiHAoUIEStTnyMLmaOCgFxdcuVrP.get('actor'):
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVrX!='' and vWGiHAoUIEStTnyMLmaOCgFxdcuVrX!='-' and vWGiHAoUIEStTnyMLmaOCgFxdcuVrX!=u'없음':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrX)
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVrq in vWGiHAoUIEStTnyMLmaOCgFxdcuVrP.get('director'):
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVrq!='' and vWGiHAoUIEStTnyMLmaOCgFxdcuVrq!='-' and vWGiHAoUIEStTnyMLmaOCgFxdcuVrq!=u'없음':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrq)
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVrP.get('broad_dt')not in[vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,'']:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVre =vWGiHAoUIEStTnyMLmaOCgFxdcuVrP.get('broad_dt')
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrK='%s-%s-%s'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVre[:4],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[4:6],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[6:])
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrz={'program':vWGiHAoUIEStTnyMLmaOCgFxdcuVrh,'title':vWGiHAoUIEStTnyMLmaOCgFxdcuVYP,'mpaa':vWGiHAoUIEStTnyMLmaOCgFxdcuVrf,'thumbnail':{'poster':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR,'thumb':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD,'clearlogo':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB,'icon':vWGiHAoUIEStTnyMLmaOCgFxdcuVrl,'banner':vWGiHAoUIEStTnyMLmaOCgFxdcuVrs,'fanart':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD},'channel':vWGiHAoUIEStTnyMLmaOCgFxdcuVrk,'synopsis':vWGiHAoUIEStTnyMLmaOCgFxdcuVYh,'year':vWGiHAoUIEStTnyMLmaOCgFxdcuVrN,'info_genre':vWGiHAoUIEStTnyMLmaOCgFxdcuVrw,'cast':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ,'director':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp,'premiered':vWGiHAoUIEStTnyMLmaOCgFxdcuVrK,}
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlK.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrz)
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
 def Get_Origianl_ProgramList(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,page_int):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlK=[]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v2/media/band/originals'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'pageSize':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(page_int),}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVrD=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.JsonFile_Save(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV_SESSION_COOKIES2,vWGiHAoUIEStTnyMLmaOCgFxdcuVrD)
   if not('contents' in vWGiHAoUIEStTnyMLmaOCgFxdcuVrD['body']):return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYj=vWGiHAoUIEStTnyMLmaOCgFxdcuVrD['body']['contents']
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVYj:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbR =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['vod_code']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYP =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['vod_name']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['image']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbB ='movie' if vWGiHAoUIEStTnyMLmaOCgFxdcuVbR.startswith('M')else 'vod'
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrz={'vod_code':vWGiHAoUIEStTnyMLmaOCgFxdcuVbR,'title':vWGiHAoUIEStTnyMLmaOCgFxdcuVYP,'thumbnail':{'poster':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR,'thumb':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR},'vod_type':vWGiHAoUIEStTnyMLmaOCgFxdcuVbB,}
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlK.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrz)
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVrD['body']['has_more']=='Y':vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
 def GetEpisodeList(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,program_code,page_int,orderby='desc'):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlK=[]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v2/media/frequency/program/'+program_code
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if not('result' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']):return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYj=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']
   vWGiHAoUIEStTnyMLmaOCgFxdcuVbl=vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['total_count'])
   vWGiHAoUIEStTnyMLmaOCgFxdcuVbs =vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(vWGiHAoUIEStTnyMLmaOCgFxdcuVbl//(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbY =(vWGiHAoUIEStTnyMLmaOCgFxdcuVbl-1)-((page_int-1)*vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.EPISODE_LIMIT)
   else:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbY =(page_int-1)*vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.EPISODE_LIMIT
   for i in vWGiHAoUIEStTnyMLmaOCgFxdcuVpQ(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.EPISODE_LIMIT):
    if orderby=='desc':
     vWGiHAoUIEStTnyMLmaOCgFxdcuVbr=vWGiHAoUIEStTnyMLmaOCgFxdcuVbY-i
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVbr<0:break
    else:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVbr=vWGiHAoUIEStTnyMLmaOCgFxdcuVbY+i
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVbr>=vWGiHAoUIEStTnyMLmaOCgFxdcuVbl:break
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbQ=vWGiHAoUIEStTnyMLmaOCgFxdcuVYj[vWGiHAoUIEStTnyMLmaOCgFxdcuVbr]['episode']['code']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYP =vWGiHAoUIEStTnyMLmaOCgFxdcuVYj[vWGiHAoUIEStTnyMLmaOCgFxdcuVbr]['vod_name']['ko']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbp =''
    try:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVre=vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVYj[vWGiHAoUIEStTnyMLmaOCgFxdcuVbr]['episode']['broadcast_date'])
     vWGiHAoUIEStTnyMLmaOCgFxdcuVbp='%s-%s-%s'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVre[:4],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[4:6],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[6:])
    except:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVpR
    try:
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVYj[vWGiHAoUIEStTnyMLmaOCgFxdcuVbr]['episode']['pip_cliptype']=='C012':
      vWGiHAoUIEStTnyMLmaOCgFxdcuVbp+=' - Quick VOD'
    except:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVpR
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYh =vWGiHAoUIEStTnyMLmaOCgFxdcuVYj[vWGiHAoUIEStTnyMLmaOCgFxdcuVbr]['episode']['synopsis']['ko']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrl =''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrs =''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrY =''
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVrb in vWGiHAoUIEStTnyMLmaOCgFxdcuVYj[vWGiHAoUIEStTnyMLmaOCgFxdcuVbr]['program']['image']:
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP0900':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP1800':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP2000':vWGiHAoUIEStTnyMLmaOCgFxdcuVrl =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP1900':vWGiHAoUIEStTnyMLmaOCgFxdcuVrs =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIP0200':vWGiHAoUIEStTnyMLmaOCgFxdcuVrY =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVrb in vWGiHAoUIEStTnyMLmaOCgFxdcuVYj[vWGiHAoUIEStTnyMLmaOCgFxdcuVbr]['episode']['image']:
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIE0400':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
    try:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVbw=vWGiHAoUIEStTnyMLmaOCgFxdcuVbf=vWGiHAoUIEStTnyMLmaOCgFxdcuVbK=''
     vWGiHAoUIEStTnyMLmaOCgFxdcuVbN=0
     vWGiHAoUIEStTnyMLmaOCgFxdcuVbw =vWGiHAoUIEStTnyMLmaOCgFxdcuVYj[vWGiHAoUIEStTnyMLmaOCgFxdcuVbr]['program']['name']['ko']
     vWGiHAoUIEStTnyMLmaOCgFxdcuVbf =vWGiHAoUIEStTnyMLmaOCgFxdcuVbp
     vWGiHAoUIEStTnyMLmaOCgFxdcuVbK =vWGiHAoUIEStTnyMLmaOCgFxdcuVYj[vWGiHAoUIEStTnyMLmaOCgFxdcuVbr]['channel']['name']['ko']
     if 'frequency' in vWGiHAoUIEStTnyMLmaOCgFxdcuVYj[vWGiHAoUIEStTnyMLmaOCgFxdcuVbr]['episode']:vWGiHAoUIEStTnyMLmaOCgFxdcuVbN=vWGiHAoUIEStTnyMLmaOCgFxdcuVYj[vWGiHAoUIEStTnyMLmaOCgFxdcuVbr]['episode']['frequency']
    except:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVpR
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrz={'episode':vWGiHAoUIEStTnyMLmaOCgFxdcuVbQ,'title':vWGiHAoUIEStTnyMLmaOCgFxdcuVYP,'subtitle':vWGiHAoUIEStTnyMLmaOCgFxdcuVbp,'thumbnail':{'poster':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR,'thumb':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD,'clearlogo':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB,'icon':vWGiHAoUIEStTnyMLmaOCgFxdcuVrl,'banner':vWGiHAoUIEStTnyMLmaOCgFxdcuVrs,'fanart':vWGiHAoUIEStTnyMLmaOCgFxdcuVrY},'synopsis':vWGiHAoUIEStTnyMLmaOCgFxdcuVYh,'info_title':vWGiHAoUIEStTnyMLmaOCgFxdcuVbw,'aired':vWGiHAoUIEStTnyMLmaOCgFxdcuVbf,'studio':vWGiHAoUIEStTnyMLmaOCgFxdcuVbK,'frequency':vWGiHAoUIEStTnyMLmaOCgFxdcuVbN}
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlK.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrz)
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVbs>page_int:vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq,vWGiHAoUIEStTnyMLmaOCgFxdcuVbs
 def GetMovieList(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,genre,orderby,page_int):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlK=[]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v2/media/movies'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'pageSize':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:vWGiHAoUIEStTnyMLmaOCgFxdcuVle['categoryCode']=genre
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle['productPackageCode']=','.join(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.MOVIE_LITE)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if not('result' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']):return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYj=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVYj:
    if 'release_date' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('movie'):
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrN=vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('movie').get('release_date'))[:4]
    else:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrN=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbX =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['movie']['code']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYP =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['movie']['name']['ko'].strip()
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVrN not in[vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,'0','']:vWGiHAoUIEStTnyMLmaOCgFxdcuVYP+=u' (%s)'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVrN)
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrR=''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=''
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVrb in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['movie']['image']:
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIM2100':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIM0400':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIM1800':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYh =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['movie']['story']['ko']
    try:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVbw =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['movie']['name']['ko'].strip()
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrf =vWGiHAoUIEStTnyMLmaOCgFxdcuVRs.get(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('grade_code'))
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ=[]
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrp=[]
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrw=[]
     vWGiHAoUIEStTnyMLmaOCgFxdcuVbq=0
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrK=''
     vWGiHAoUIEStTnyMLmaOCgFxdcuVbK =''
     for vWGiHAoUIEStTnyMLmaOCgFxdcuVrX in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('movie').get('actor'):
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVrX!='':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrX)
     for vWGiHAoUIEStTnyMLmaOCgFxdcuVrq in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('movie').get('director'):
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVrq!='':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrq)
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('movie').get('category1_name').get('ko')!='':
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrw.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['movie']['category1_name']['ko'])
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('movie').get('category2_name').get('ko')!='':
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrw.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['movie']['category2_name']['ko'])
     if 'duration' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('movie'):vWGiHAoUIEStTnyMLmaOCgFxdcuVbq=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('movie').get('duration')
     if 'release_date' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('movie'):
      vWGiHAoUIEStTnyMLmaOCgFxdcuVre=vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('movie').get('release_date'))
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVre!='0':vWGiHAoUIEStTnyMLmaOCgFxdcuVrK='%s-%s-%s'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVre[:4],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[4:6],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[6:])
     if 'production' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('movie'):vWGiHAoUIEStTnyMLmaOCgFxdcuVbK=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('movie').get('production')
    except:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVpR
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrz={'moviecode':vWGiHAoUIEStTnyMLmaOCgFxdcuVbX,'title':vWGiHAoUIEStTnyMLmaOCgFxdcuVYP,'thumbnail':{'poster':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR,'thumb':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD,'clearlogo':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB,'fanart':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD},'synopsis':vWGiHAoUIEStTnyMLmaOCgFxdcuVYh,'info_title':vWGiHAoUIEStTnyMLmaOCgFxdcuVbw,'year':vWGiHAoUIEStTnyMLmaOCgFxdcuVrN,'cast':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ,'director':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp,'info_genre':vWGiHAoUIEStTnyMLmaOCgFxdcuVrw,'duration':vWGiHAoUIEStTnyMLmaOCgFxdcuVbq,'premiered':vWGiHAoUIEStTnyMLmaOCgFxdcuVrK,'studio':vWGiHAoUIEStTnyMLmaOCgFxdcuVbK,'mpaa':vWGiHAoUIEStTnyMLmaOCgFxdcuVrf}
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbe=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVbj in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['billing_package_id']:
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVbj in vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.MOVIE_LITE:
      vWGiHAoUIEStTnyMLmaOCgFxdcuVbe=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
      break
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVbe==vWGiHAoUIEStTnyMLmaOCgFxdcuVpB: 
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrz['title']=vWGiHAoUIEStTnyMLmaOCgFxdcuVrz['title']+' [개별구매]'
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlK.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrz)
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['has_more']=='Y':vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
 def Get_UHD_MovieList(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,page_int):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlK=[]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v2/operator/highlights'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams(uhd=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(page_int),'pocType':'APP_X_TVING_4.0.0',}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if not('result' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']):return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYj=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVYj:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrP=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['content']['movie']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrh =vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['code']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYP =vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['name']['ko'].strip()
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbw =vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['name']['ko'].strip()
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrN =vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['product_year']
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVrN:vWGiHAoUIEStTnyMLmaOCgFxdcuVYP+=u' (%s)'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['product_year'])
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYh =vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['story']['ko']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbq =vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['duration']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrf =vWGiHAoUIEStTnyMLmaOCgFxdcuVRs.get(vWGiHAoUIEStTnyMLmaOCgFxdcuVrP.get('grade_code'))
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbK =vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['production']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrR=''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=''
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrw =[]
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ =[]
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrp=[]
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrK =''
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVrb in vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['image']:
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIM2100':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIM0400':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
     elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['code']=='CAIM1800':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb['url']
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['release_date']not in[vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,0]:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVre=vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['release_date'])
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVre!='0':vWGiHAoUIEStTnyMLmaOCgFxdcuVrK='%s-%s-%s'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVre[:4],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[4:6],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[6:])
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVrP.get('category1_name').get('ko')!='':
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrw.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['category1_name']['ko'])
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVrP.get('category2_name').get('ko')!='':
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrw.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrP['category2_name']['ko'])
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVrX in vWGiHAoUIEStTnyMLmaOCgFxdcuVrP.get('actor'):
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVrX!='':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrX)
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVrq in vWGiHAoUIEStTnyMLmaOCgFxdcuVrP.get('director'):
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVrq!='':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrq)
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrz={'moviecode':vWGiHAoUIEStTnyMLmaOCgFxdcuVrh,'title':vWGiHAoUIEStTnyMLmaOCgFxdcuVYP,'thumbnail':{'poster':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR,'thumb':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD,'clearlogo':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB,'fanart':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD},'year':vWGiHAoUIEStTnyMLmaOCgFxdcuVrN,'info_title':vWGiHAoUIEStTnyMLmaOCgFxdcuVbw,'synopsis':vWGiHAoUIEStTnyMLmaOCgFxdcuVYh,'mpaa':vWGiHAoUIEStTnyMLmaOCgFxdcuVrf,'duration':vWGiHAoUIEStTnyMLmaOCgFxdcuVbq,'premiered':vWGiHAoUIEStTnyMLmaOCgFxdcuVrK,'studio':vWGiHAoUIEStTnyMLmaOCgFxdcuVbK,'info_genre':vWGiHAoUIEStTnyMLmaOCgFxdcuVrw,'cast':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ,'director':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp,}
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlK.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrz)
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
 def GetMovieGenre(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlK=[]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v2/media/movie/curations'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if not('result' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']):return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYj=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVYj:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbz =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['curation_code']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbJ =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['curation_name']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrz={'curation_code':vWGiHAoUIEStTnyMLmaOCgFxdcuVbz,'curation_name':vWGiHAoUIEStTnyMLmaOCgFxdcuVbJ}
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlK.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrz)
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
 def GetSearchList(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,search_key,page_int,stype):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVbk=[]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpB
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/search/getSearch.jsp'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.SCREENCODE,'os':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.OSCODE,'network':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.APIKEY,'networkCode':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.NETWORKCODE,'osCode ':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.OSCODE,'teleCode ':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TELECODE,'screenCode ':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.SCREENCODE}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.SEARCH_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVle,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if stype=='vod':
    if not('programRsb' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj):return vWGiHAoUIEStTnyMLmaOCgFxdcuVbk,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbP=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['programRsb']['dataList']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbh =vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['programRsb']['count'])
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVbP:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrJ=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['mast_cd']
     vWGiHAoUIEStTnyMLmaOCgFxdcuVYP =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['mast_nm']
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrR=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['web_url4']
     vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['web_url']
     try:
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ =[]
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrp=[]
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrw =[]
      vWGiHAoUIEStTnyMLmaOCgFxdcuVbq =0
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrf =''
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrN =''
      vWGiHAoUIEStTnyMLmaOCgFxdcuVbf =''
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('actor') !='' and vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('actor') !='-':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('actor').split(',')
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('director')!='' and vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('director')!='-':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('director').split(',')
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('cate_nm')!='' and vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('cate_nm')!='-':vWGiHAoUIEStTnyMLmaOCgFxdcuVrw =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('cate_nm').split('/')
      if 'targetage' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz:vWGiHAoUIEStTnyMLmaOCgFxdcuVrf=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('targetage')
      if 'broad_dt' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz:
       vWGiHAoUIEStTnyMLmaOCgFxdcuVre=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('broad_dt')
       vWGiHAoUIEStTnyMLmaOCgFxdcuVbf='%s-%s-%s'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVre[:4],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[4:6],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[6:])
       vWGiHAoUIEStTnyMLmaOCgFxdcuVrN =vWGiHAoUIEStTnyMLmaOCgFxdcuVre[:4]
     except:
      vWGiHAoUIEStTnyMLmaOCgFxdcuVpR
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrz={'program':vWGiHAoUIEStTnyMLmaOCgFxdcuVrJ,'title':vWGiHAoUIEStTnyMLmaOCgFxdcuVYP,'thumbnail':{'poster':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR,'thumb':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD,'fanart':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD},'synopsis':'','cast':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ,'director':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp,'info_genre':vWGiHAoUIEStTnyMLmaOCgFxdcuVrw,'duration':vWGiHAoUIEStTnyMLmaOCgFxdcuVbq,'mpaa':vWGiHAoUIEStTnyMLmaOCgFxdcuVrf,'year':vWGiHAoUIEStTnyMLmaOCgFxdcuVrN,'aired':vWGiHAoUIEStTnyMLmaOCgFxdcuVbf}
     vWGiHAoUIEStTnyMLmaOCgFxdcuVbk.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrz)
   else:
    if not('vodMVRsb' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj):return vWGiHAoUIEStTnyMLmaOCgFxdcuVbk,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbD=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['vodMVRsb']['dataList']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVbh =vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['vodMVRsb']['count'])
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVbD:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrJ=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['mast_cd']
     vWGiHAoUIEStTnyMLmaOCgFxdcuVYP =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['mast_nm'].strip()
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['web_url']
     vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVrR
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=''
     try:
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ =[]
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrp=[]
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrw =[]
      vWGiHAoUIEStTnyMLmaOCgFxdcuVbq =0
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrf =''
      vWGiHAoUIEStTnyMLmaOCgFxdcuVrN =''
      vWGiHAoUIEStTnyMLmaOCgFxdcuVbf =''
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('actor') !='' and vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('actor') !='-':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('actor').split(',')
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('director')!='' and vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('director')!='-':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('director').split(',')
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('cate_nm')!='' and vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('cate_nm')!='-':vWGiHAoUIEStTnyMLmaOCgFxdcuVrw =vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('cate_nm').split('/')
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('runtime_sec')!='':vWGiHAoUIEStTnyMLmaOCgFxdcuVbq=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('runtime_sec')
      if 'grade_nm' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlz:vWGiHAoUIEStTnyMLmaOCgFxdcuVrf=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('grade_nm')
      vWGiHAoUIEStTnyMLmaOCgFxdcuVre=vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('broad_dt')
      if data_str!='':
       vWGiHAoUIEStTnyMLmaOCgFxdcuVbf='%s-%s-%s'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVre[:4],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[4:6],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[6:])
       vWGiHAoUIEStTnyMLmaOCgFxdcuVrN =vWGiHAoUIEStTnyMLmaOCgFxdcuVre[:4]
     except:
      vWGiHAoUIEStTnyMLmaOCgFxdcuVpR
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrz={'movie':vWGiHAoUIEStTnyMLmaOCgFxdcuVrJ,'title':vWGiHAoUIEStTnyMLmaOCgFxdcuVYP,'thumbnail':{'poster':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR,'thumb':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD,'fanart':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD,'clearlogo':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB},'synopsis':'','cast':vWGiHAoUIEStTnyMLmaOCgFxdcuVrQ,'director':vWGiHAoUIEStTnyMLmaOCgFxdcuVrp,'info_genre':vWGiHAoUIEStTnyMLmaOCgFxdcuVrw,'duration':vWGiHAoUIEStTnyMLmaOCgFxdcuVbq,'mpaa':vWGiHAoUIEStTnyMLmaOCgFxdcuVrf,'year':vWGiHAoUIEStTnyMLmaOCgFxdcuVrN,'aired':vWGiHAoUIEStTnyMLmaOCgFxdcuVbf}
     vWGiHAoUIEStTnyMLmaOCgFxdcuVbk.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrz)
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVbh>(page_int*vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.SEARCH_LIMIT):vWGiHAoUIEStTnyMLmaOCgFxdcuVYq=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVbk,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
 def GetBookmarkInfo(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,videoid,vidtype):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVQR={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+'/v2/media/program/'+videoid
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'pageNo':'1','pageSize':'10','order':'name',}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVrD=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if not('body' in vWGiHAoUIEStTnyMLmaOCgFxdcuVrD):return{}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQB=vWGiHAoUIEStTnyMLmaOCgFxdcuVrD['body']
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYP=vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('name').get('ko').strip()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['title'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVYP
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['title']=vWGiHAoUIEStTnyMLmaOCgFxdcuVYP
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['mpaa'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVRs.get(vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('grade_code'))
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['plot'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('synopsis').get('ko')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['year'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('product_year')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['cast'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('actor')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['director']=vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('director')
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('category1_name').get('ko')!='':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['genre'].append(vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('category1_name').get('ko'))
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('category2_name').get('ko')!='':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['genre'].append(vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('category2_name').get('ko'))
   vWGiHAoUIEStTnyMLmaOCgFxdcuVre=vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('broad_dt'))
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVre!='0':vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVre[:4],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[4:6],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[6:])
   vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =''
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =''
   vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=''
   vWGiHAoUIEStTnyMLmaOCgFxdcuVrl =''
   vWGiHAoUIEStTnyMLmaOCgFxdcuVrs =''
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVrb in vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('image'):
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('code')=='CAIP0900':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('url')
    elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('code')=='CAIP0200':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('url')
    elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('code')=='CAIP1800':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('url')
    elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('code')=='CAIP2000':vWGiHAoUIEStTnyMLmaOCgFxdcuVrl =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('url')
    elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('code')=='CAIP1900':vWGiHAoUIEStTnyMLmaOCgFxdcuVrs =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('url')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['thumbnail']['poster']=vWGiHAoUIEStTnyMLmaOCgFxdcuVrR
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['thumbnail']['thumb']=vWGiHAoUIEStTnyMLmaOCgFxdcuVYD
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['thumbnail']['clearlogo']=vWGiHAoUIEStTnyMLmaOCgFxdcuVrB
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['thumbnail']['icon']=vWGiHAoUIEStTnyMLmaOCgFxdcuVrl
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['thumbnail']['banner']=vWGiHAoUIEStTnyMLmaOCgFxdcuVrs
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['thumbnail']['fanart']=vWGiHAoUIEStTnyMLmaOCgFxdcuVYD
  else:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+'/v2a/media/stream/info'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies']['tving_uuid'].split('-')[0],'uuid':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetNoCache(1)),'wm':'Y',}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVrD=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if not('content' in vWGiHAoUIEStTnyMLmaOCgFxdcuVrD['body']):return{}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQB=vWGiHAoUIEStTnyMLmaOCgFxdcuVrD['body']['content']['info']['movie']
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYP =vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('name').get('ko').strip()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['title']=vWGiHAoUIEStTnyMLmaOCgFxdcuVYP
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYP +=u' (%s)'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('product_year'))
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['title'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVYP
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['mpaa'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVRs.get(vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('grade_code'))
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['plot'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('story').get('ko')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['year'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('product_year')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['studio'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('production')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['duration']=vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('duration')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['cast'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('actor')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['director']=vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('director')
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('category1_name').get('ko')!='':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['genre'].append(vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('category1_name').get('ko'))
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('category2_name').get('ko')!='':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['genre'].append(vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('category2_name').get('ko'))
   vWGiHAoUIEStTnyMLmaOCgFxdcuVre=vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('release_date'))
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVre!='0':vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(vWGiHAoUIEStTnyMLmaOCgFxdcuVre[:4],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[4:6],vWGiHAoUIEStTnyMLmaOCgFxdcuVre[6:])
   vWGiHAoUIEStTnyMLmaOCgFxdcuVrR=''
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =''
   vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=''
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVrb in vWGiHAoUIEStTnyMLmaOCgFxdcuVQB.get('image'):
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('code')=='CAIM2100':vWGiHAoUIEStTnyMLmaOCgFxdcuVrR =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('url')
    elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('code')=='CAIM0400':vWGiHAoUIEStTnyMLmaOCgFxdcuVYD =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('url')
    elif vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('code')=='CAIM1800':vWGiHAoUIEStTnyMLmaOCgFxdcuVrB=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.IMG_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVrb.get('url')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['thumbnail']['poster']=vWGiHAoUIEStTnyMLmaOCgFxdcuVrR
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['thumbnail']['thumb']=vWGiHAoUIEStTnyMLmaOCgFxdcuVrR 
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['thumbnail']['clearlogo']=vWGiHAoUIEStTnyMLmaOCgFxdcuVrB
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQR['saveinfo']['thumbnail']['fanart']=vWGiHAoUIEStTnyMLmaOCgFxdcuVYD
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVQR
 def GetEuroChannelList(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlK=[]
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v2/operator/highlights'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetNoCache(2))}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if not('result' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']):return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK,vWGiHAoUIEStTnyMLmaOCgFxdcuVYq
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYj=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQl =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Get_Now_Datetime()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQs=vWGiHAoUIEStTnyMLmaOCgFxdcuVQl+datetime.timedelta(days=-1)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQs=vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(vWGiHAoUIEStTnyMLmaOCgFxdcuVQs.strftime('%Y%m%d'))
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVYj:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVQY=vWGiHAoUIEStTnyMLmaOCgFxdcuVpb(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('content').get('banner_title2')[:8])
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVQs<=vWGiHAoUIEStTnyMLmaOCgFxdcuVQY:
     vWGiHAoUIEStTnyMLmaOCgFxdcuVrz={'channel':vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('content').get('banner_sub_title3'),'title':vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('content').get('banner_title'),'subtitle':vWGiHAoUIEStTnyMLmaOCgFxdcuVlz.get('content').get('banner_sub_title2'),}
     vWGiHAoUIEStTnyMLmaOCgFxdcuVlK.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrz)
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVlK
 def Make_DecryptKey(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,step,mediacode='000',timecode='000'):
  if step=='1':
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBw=vWGiHAoUIEStTnyMLmaOCgFxdcuVpw('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBN=vWGiHAoUIEStTnyMLmaOCgFxdcuVpw('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBw=vWGiHAoUIEStTnyMLmaOCgFxdcuVpw('kss2lym0kdw1lks3','utf-8')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBN=vWGiHAoUIEStTnyMLmaOCgFxdcuVpw([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVBw,vWGiHAoUIEStTnyMLmaOCgFxdcuVBN
 def DecryptPlaintext(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,vWGiHAoUIEStTnyMLmaOCgFxdcuVBq,vWGiHAoUIEStTnyMLmaOCgFxdcuVBf,vWGiHAoUIEStTnyMLmaOCgFxdcuVBK):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBX=AES.new(vWGiHAoUIEStTnyMLmaOCgFxdcuVBf,AES.MODE_CBC,vWGiHAoUIEStTnyMLmaOCgFxdcuVBK,)
  vWGiHAoUIEStTnyMLmaOCgFxdcuVBe=Padding.unpad(vWGiHAoUIEStTnyMLmaOCgFxdcuVBX.decrypt(base64.standard_b64decode(vWGiHAoUIEStTnyMLmaOCgFxdcuVBq)),16)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVBe.decode('utf-8')
 def Decrypt_Url(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,vWGiHAoUIEStTnyMLmaOCgFxdcuVBq,mediacode,vWGiHAoUIEStTnyMLmaOCgFxdcuVsb):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVQr=''
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsQ=''
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsp=''
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBw,vWGiHAoUIEStTnyMLmaOCgFxdcuVBN=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Make_DecryptKey('1',mediacode=mediacode,timecode=vWGiHAoUIEStTnyMLmaOCgFxdcuVsb)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQb=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.DecryptPlaintext(vWGiHAoUIEStTnyMLmaOCgFxdcuVBq,vWGiHAoUIEStTnyMLmaOCgFxdcuVBw,vWGiHAoUIEStTnyMLmaOCgFxdcuVBN))
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(vWGiHAoUIEStTnyMLmaOCgFxdcuVQb)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQp =vWGiHAoUIEStTnyMLmaOCgFxdcuVQb.get('url')
   vWGiHAoUIEStTnyMLmaOCgFxdcuVsQ =vWGiHAoUIEStTnyMLmaOCgFxdcuVQb.get('watermark') if 'watermark' in vWGiHAoUIEStTnyMLmaOCgFxdcuVQb else ''
   vWGiHAoUIEStTnyMLmaOCgFxdcuVsp=vWGiHAoUIEStTnyMLmaOCgFxdcuVQb.get('watermark_key')if 'watermark_key' in vWGiHAoUIEStTnyMLmaOCgFxdcuVQb else ''
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBw,vWGiHAoUIEStTnyMLmaOCgFxdcuVBN=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Make_DecryptKey('2',mediacode=mediacode,timecode=vWGiHAoUIEStTnyMLmaOCgFxdcuVsb)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQr=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.DecryptPlaintext(vWGiHAoUIEStTnyMLmaOCgFxdcuVQp,vWGiHAoUIEStTnyMLmaOCgFxdcuVBw,vWGiHAoUIEStTnyMLmaOCgFxdcuVBN)
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVQr,vWGiHAoUIEStTnyMLmaOCgFxdcuVsQ,vWGiHAoUIEStTnyMLmaOCgFxdcuVsp
 def Get_Apple_buildId(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVQw=''
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk ='https://www.tving.com/more/special/SP0071'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQN=r'"buildId":"(.*?)"'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQw =re.compile(vWGiHAoUIEStTnyMLmaOCgFxdcuVQN,re.DOTALL).findall(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)[0]
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVQw
 def Get_AppleGroup_List(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVQf=[]
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQw=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Get_Apple_buildId()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/_next/data/{}/ko/more/special/SP0071.json'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVQw)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'key':'SP0071'}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.URL_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVle,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVrD=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if not('pageProps' in vWGiHAoUIEStTnyMLmaOCgFxdcuVrD):return vWGiHAoUIEStTnyMLmaOCgFxdcuVQf
   vWGiHAoUIEStTnyMLmaOCgFxdcuVYj=vWGiHAoUIEStTnyMLmaOCgFxdcuVrD['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVQK in vWGiHAoUIEStTnyMLmaOCgFxdcuVYj:
    if vWGiHAoUIEStTnyMLmaOCgFxdcuVQK['bandType']not in['VOD_BASIC']:continue
    vWGiHAoUIEStTnyMLmaOCgFxdcuVQX =re.findall('/band/\w+|/curation/\w+',vWGiHAoUIEStTnyMLmaOCgFxdcuVQK['moreUrl'])[0]
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrz={'bandName':vWGiHAoUIEStTnyMLmaOCgFxdcuVQK['bandName'],'bandKey':vWGiHAoUIEStTnyMLmaOCgFxdcuVQX.split('/')[2],'moreUrl':vWGiHAoUIEStTnyMLmaOCgFxdcuVQX,}
    vWGiHAoUIEStTnyMLmaOCgFxdcuVQf.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrz)
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVQf
 def Get_Band_VodList(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,bandKey,vWGiHAoUIEStTnyMLmaOCgFxdcuVQX):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVQq=[]
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQw=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Get_Apple_buildId()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/_next/data/{}/ko/more{}.json'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVQw,vWGiHAoUIEStTnyMLmaOCgFxdcuVQX)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'key':bandKey}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.URL_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVle,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVrD=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if not('pageProps' in vWGiHAoUIEStTnyMLmaOCgFxdcuVrD):return vWGiHAoUIEStTnyMLmaOCgFxdcuVQq
   if 'band' in vWGiHAoUIEStTnyMLmaOCgFxdcuVQX:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYj=vWGiHAoUIEStTnyMLmaOCgFxdcuVrD['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['band']['items']
   else:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVYj=vWGiHAoUIEStTnyMLmaOCgFxdcuVrD['pageProps']['dehydratedState']['queries'][0]['state']['data']['data']['bands'][0]['items']
   for vWGiHAoUIEStTnyMLmaOCgFxdcuVQK in vWGiHAoUIEStTnyMLmaOCgFxdcuVYj:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVQe=vWGiHAoUIEStTnyMLmaOCgFxdcuVQK['imageUrl']
    vWGiHAoUIEStTnyMLmaOCgFxdcuVrz={'program':vWGiHAoUIEStTnyMLmaOCgFxdcuVQK['code'],'title':vWGiHAoUIEStTnyMLmaOCgFxdcuVQK['title'],'thumbnail':{'poster':vWGiHAoUIEStTnyMLmaOCgFxdcuVQe,'thumb':vWGiHAoUIEStTnyMLmaOCgFxdcuVQe,'fanart':vWGiHAoUIEStTnyMLmaOCgFxdcuVQe},}
    vWGiHAoUIEStTnyMLmaOCgFxdcuVQq.append(vWGiHAoUIEStTnyMLmaOCgFxdcuVrz)
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVQq
 def GetLiveURL_Test(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb,mediacode,sel_quality):
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlk ={'streaming_url':'','subtitleYn':vWGiHAoUIEStTnyMLmaOCgFxdcuVpB,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlX =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies']['tving_uuid'].split('-')[0] 
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlP =vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.TV['cookies']['tving_uuid'] 
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlh=vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetNoCache(1))
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v2/media/stream/info' 
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':vWGiHAoUIEStTnyMLmaOCgFxdcuVlP,'deviceInfo':'PC','noCache':vWGiHAoUIEStTnyMLmaOCgFxdcuVlh,}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.makeDefaultCookies()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Get',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVRD)
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.status_code!=200:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['error_msg']='First Step - {} error'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.status_code)
    return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']['code']=='060':
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVRk in vWGiHAoUIEStTnyMLmaOCgFxdcuVRl.items():
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVRk==sel_quality:
      vWGiHAoUIEStTnyMLmaOCgFxdcuVsR=vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ
   elif vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']['code']!='000':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['error_msg']=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']['message']
    return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
   else: 
    if not('stream' in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']):return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
    vWGiHAoUIEStTnyMLmaOCgFxdcuVsB=[]
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVRk in vWGiHAoUIEStTnyMLmaOCgFxdcuVRl.items():
     for vWGiHAoUIEStTnyMLmaOCgFxdcuVlz in vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['stream']['quality']:
      if vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['active']=='Y' and vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['code']==vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ:
       vWGiHAoUIEStTnyMLmaOCgFxdcuVsB.append({vWGiHAoUIEStTnyMLmaOCgFxdcuVRl.get(vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['code']):vWGiHAoUIEStTnyMLmaOCgFxdcuVlz['code']})
    vWGiHAoUIEStTnyMLmaOCgFxdcuVsR=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.CheckQuality(sel_quality,vWGiHAoUIEStTnyMLmaOCgFxdcuVsB)
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['error_msg']='First Step - except error'
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
  try:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlh=vWGiHAoUIEStTnyMLmaOCgFxdcuVpl(vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetNoCache(1))
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlw ='/v3/media/stream/info'
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.GetDefaultParams()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVle={'mediaCode':mediacode,'deviceId':vWGiHAoUIEStTnyMLmaOCgFxdcuVlX,'uuid':vWGiHAoUIEStTnyMLmaOCgFxdcuVlP,'deviceInfo':'PC_Chrome','streamCode':vWGiHAoUIEStTnyMLmaOCgFxdcuVsR,'noCache':vWGiHAoUIEStTnyMLmaOCgFxdcuVlh,'callingFrom':'HTML5','model':vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlD.update(vWGiHAoUIEStTnyMLmaOCgFxdcuVle)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBk=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.API_DOMAIN+vWGiHAoUIEStTnyMLmaOCgFxdcuVlw
   vWGiHAoUIEStTnyMLmaOCgFxdcuVRD=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.makeDefaultCookies()
   vWGiHAoUIEStTnyMLmaOCgFxdcuVBh=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.callRequestCookies('Post',vWGiHAoUIEStTnyMLmaOCgFxdcuVBk,payload=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,params=vWGiHAoUIEStTnyMLmaOCgFxdcuVlD,headers=vWGiHAoUIEStTnyMLmaOCgFxdcuVpR,cookies=vWGiHAoUIEStTnyMLmaOCgFxdcuVRD,redirects=vWGiHAoUIEStTnyMLmaOCgFxdcuVpY)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlj=json.loads(vWGiHAoUIEStTnyMLmaOCgFxdcuVBh.text)
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']['code']!='000':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['error_msg']=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['result']['message']
    return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
   vWGiHAoUIEStTnyMLmaOCgFxdcuVsl=vWGiHAoUIEStTnyMLmaOCgFxdcuVlj['body']['stream']
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVsl['drm_yn']=='Y':
    vWGiHAoUIEStTnyMLmaOCgFxdcuVsY=vWGiHAoUIEStTnyMLmaOCgFxdcuVsl['playback']['drm']['widevine']
    for vWGiHAoUIEStTnyMLmaOCgFxdcuVsr in vWGiHAoUIEStTnyMLmaOCgFxdcuVsl['playback']['drm']['license']['drm_license_data']:
     if vWGiHAoUIEStTnyMLmaOCgFxdcuVsr['drm_type']=='Widevine':
      vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['drm_server_url'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVsr['drm_server_url']
      vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['drm_header_key'] =vWGiHAoUIEStTnyMLmaOCgFxdcuVsr['drm_header_key']
      vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['drm_header_value']=vWGiHAoUIEStTnyMLmaOCgFxdcuVsr['drm_header_value']
      break
   else:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVsY=vWGiHAoUIEStTnyMLmaOCgFxdcuVsl['playback']['non_drm']
  except vWGiHAoUIEStTnyMLmaOCgFxdcuVpN as exception:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(exception)
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['error_msg']='Second Step - except error'
   return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsb=vWGiHAoUIEStTnyMLmaOCgFxdcuVlh
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsY=vWGiHAoUIEStTnyMLmaOCgFxdcuVsY.split('|')[1]
  vWGiHAoUIEStTnyMLmaOCgFxdcuVsY,vWGiHAoUIEStTnyMLmaOCgFxdcuVsQ,vWGiHAoUIEStTnyMLmaOCgFxdcuVsp=vWGiHAoUIEStTnyMLmaOCgFxdcuVRb.Decrypt_Url(vWGiHAoUIEStTnyMLmaOCgFxdcuVsY,mediacode,vWGiHAoUIEStTnyMLmaOCgFxdcuVsb)
  vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url']=vWGiHAoUIEStTnyMLmaOCgFxdcuVsY
  vWGiHAoUIEStTnyMLmaOCgFxdcuVQj =vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url'].find('Policy=')
  if vWGiHAoUIEStTnyMLmaOCgFxdcuVQj!=-1:
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQz =vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url'].split('?')[0]
   vWGiHAoUIEStTnyMLmaOCgFxdcuVQJ=vWGiHAoUIEStTnyMLmaOCgFxdcuVpf(urllib.parse.parse_qsl(urllib.parse.urlsplit(vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url']).query))
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url']='{}&CloudFront-Policy={}'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url'],vWGiHAoUIEStTnyMLmaOCgFxdcuVQJ['Policy'])
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url']='{}&CloudFront-Signature={}'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url'],vWGiHAoUIEStTnyMLmaOCgFxdcuVQJ['Signature'])
   vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url'],vWGiHAoUIEStTnyMLmaOCgFxdcuVQJ['Key-Pair-Id'])
  vWGiHAoUIEStTnyMLmaOCgFxdcuVQk=['_tving_token','accessToken','authToken',]
  for vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVRk in vWGiHAoUIEStTnyMLmaOCgFxdcuVRD.items():
   if vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ in vWGiHAoUIEStTnyMLmaOCgFxdcuVQk:
    vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url']='{}&{}={}'.format(vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url'],vWGiHAoUIEStTnyMLmaOCgFxdcuVRJ,vWGiHAoUIEStTnyMLmaOCgFxdcuVRk)
  vWGiHAoUIEStTnyMLmaOCgFxdcuVQP(vWGiHAoUIEStTnyMLmaOCgFxdcuVlk['streaming_url'])
  return vWGiHAoUIEStTnyMLmaOCgFxdcuVlk
# Created by pyminifier (https://github.com/liftoff/pyminifier)
