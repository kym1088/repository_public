__author__="NightRain"
rfCIVTOSgGnBFuiHYNAwUxbEstMamX=object
rfCIVTOSgGnBFuiHYNAwUxbEstMamh=None
rfCIVTOSgGnBFuiHYNAwUxbEstMamJ=int
rfCIVTOSgGnBFuiHYNAwUxbEstMamz=True
rfCIVTOSgGnBFuiHYNAwUxbEstMamK=False
rfCIVTOSgGnBFuiHYNAwUxbEstMamD=type
rfCIVTOSgGnBFuiHYNAwUxbEstMamW=dict
rfCIVTOSgGnBFuiHYNAwUxbEstMamL=getattr
rfCIVTOSgGnBFuiHYNAwUxbEstMamR=list
rfCIVTOSgGnBFuiHYNAwUxbEstMamp=len
rfCIVTOSgGnBFuiHYNAwUxbEstMamo=str
rfCIVTOSgGnBFuiHYNAwUxbEstMamk=range
rfCIVTOSgGnBFuiHYNAwUxbEstMamc=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
rfCIVTOSgGnBFuiHYNAwUxbEstMald=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'Apple TV+','mode':'APPLE_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
rfCIVTOSgGnBFuiHYNAwUxbEstMalX=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
rfCIVTOSgGnBFuiHYNAwUxbEstMalh=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
rfCIVTOSgGnBFuiHYNAwUxbEstMalJ=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
rfCIVTOSgGnBFuiHYNAwUxbEstMalz=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
rfCIVTOSgGnBFuiHYNAwUxbEstMalK=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
rfCIVTOSgGnBFuiHYNAwUxbEstMalm=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
rfCIVTOSgGnBFuiHYNAwUxbEstMalD={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
rfCIVTOSgGnBFuiHYNAwUxbEstMalW =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
rfCIVTOSgGnBFuiHYNAwUxbEstMalL=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class rfCIVTOSgGnBFuiHYNAwUxbEstMaly(rfCIVTOSgGnBFuiHYNAwUxbEstMamX):
 def __init__(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMalp,rfCIVTOSgGnBFuiHYNAwUxbEstMalo,rfCIVTOSgGnBFuiHYNAwUxbEstMalk):
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_url =rfCIVTOSgGnBFuiHYNAwUxbEstMalp
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle=rfCIVTOSgGnBFuiHYNAwUxbEstMalo
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params =rfCIVTOSgGnBFuiHYNAwUxbEstMalk
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj =vWGiHAoUIEStTnyMLmaOCgFxdcuVRB() 
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,sting):
  try:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalv=xbmcgui.Dialog()
   rfCIVTOSgGnBFuiHYNAwUxbEstMalv.notification(__addonname__,sting)
  except:
   rfCIVTOSgGnBFuiHYNAwUxbEstMamh
 def addon_log(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,string):
  try:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalq=string.encode('utf-8','ignore')
  except:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalq='addonException: addon_log'
  rfCIVTOSgGnBFuiHYNAwUxbEstMalP=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,rfCIVTOSgGnBFuiHYNAwUxbEstMalq),level=rfCIVTOSgGnBFuiHYNAwUxbEstMalP)
 def get_keyboard_input(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMayk):
  rfCIVTOSgGnBFuiHYNAwUxbEstMale=rfCIVTOSgGnBFuiHYNAwUxbEstMamh
  kb=xbmc.Keyboard()
  kb.setHeading(rfCIVTOSgGnBFuiHYNAwUxbEstMayk)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   rfCIVTOSgGnBFuiHYNAwUxbEstMale=kb.getText()
  return rfCIVTOSgGnBFuiHYNAwUxbEstMale
 def get_settings_account(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  rfCIVTOSgGnBFuiHYNAwUxbEstMalQ =__addon__.getSetting('id')
  rfCIVTOSgGnBFuiHYNAwUxbEstMalj =__addon__.getSetting('pw')
  rfCIVTOSgGnBFuiHYNAwUxbEstMayl =__addon__.getSetting('login_type')
  rfCIVTOSgGnBFuiHYNAwUxbEstMayd=rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(__addon__.getSetting('selected_profile'))
  return(rfCIVTOSgGnBFuiHYNAwUxbEstMalQ,rfCIVTOSgGnBFuiHYNAwUxbEstMalj,rfCIVTOSgGnBFuiHYNAwUxbEstMayl,rfCIVTOSgGnBFuiHYNAwUxbEstMayd)
 def get_settings_uhd(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  return rfCIVTOSgGnBFuiHYNAwUxbEstMamz if __addon__.getSetting('active_uhd')=='true' else rfCIVTOSgGnBFuiHYNAwUxbEstMamK
 def get_settings_playback(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  rfCIVTOSgGnBFuiHYNAwUxbEstMayX={'active_uhd':rfCIVTOSgGnBFuiHYNAwUxbEstMamz if __addon__.getSetting('active_uhd')=='true' else rfCIVTOSgGnBFuiHYNAwUxbEstMamK,'streamFilename':rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.TV_STREAM_FILENAME,}
  return rfCIVTOSgGnBFuiHYNAwUxbEstMayX
 def get_settings_proxyport(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  rfCIVTOSgGnBFuiHYNAwUxbEstMayh =rfCIVTOSgGnBFuiHYNAwUxbEstMamz if __addon__.getSetting('proxyYn')=='true' else rfCIVTOSgGnBFuiHYNAwUxbEstMamK
  rfCIVTOSgGnBFuiHYNAwUxbEstMayJ=rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(__addon__.getSetting('proxyPort'))
  return rfCIVTOSgGnBFuiHYNAwUxbEstMayh,rfCIVTOSgGnBFuiHYNAwUxbEstMayJ
 def get_settings_totalsearch(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  rfCIVTOSgGnBFuiHYNAwUxbEstMayz =rfCIVTOSgGnBFuiHYNAwUxbEstMamz if __addon__.getSetting('local_search')=='true' else rfCIVTOSgGnBFuiHYNAwUxbEstMamK
  rfCIVTOSgGnBFuiHYNAwUxbEstMayK=rfCIVTOSgGnBFuiHYNAwUxbEstMamz if __addon__.getSetting('local_history')=='true' else rfCIVTOSgGnBFuiHYNAwUxbEstMamK
  rfCIVTOSgGnBFuiHYNAwUxbEstMaym =rfCIVTOSgGnBFuiHYNAwUxbEstMamz if __addon__.getSetting('total_search')=='true' else rfCIVTOSgGnBFuiHYNAwUxbEstMamK
  rfCIVTOSgGnBFuiHYNAwUxbEstMayD=rfCIVTOSgGnBFuiHYNAwUxbEstMamz if __addon__.getSetting('total_history')=='true' else rfCIVTOSgGnBFuiHYNAwUxbEstMamK
  rfCIVTOSgGnBFuiHYNAwUxbEstMayW=rfCIVTOSgGnBFuiHYNAwUxbEstMamz if __addon__.getSetting('menu_bookmark')=='true' else rfCIVTOSgGnBFuiHYNAwUxbEstMamK
  return(rfCIVTOSgGnBFuiHYNAwUxbEstMayz,rfCIVTOSgGnBFuiHYNAwUxbEstMayK,rfCIVTOSgGnBFuiHYNAwUxbEstMaym,rfCIVTOSgGnBFuiHYNAwUxbEstMayD,rfCIVTOSgGnBFuiHYNAwUxbEstMayW)
 def get_settings_makebookmark(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  return rfCIVTOSgGnBFuiHYNAwUxbEstMamz if __addon__.getSetting('make_bookmark')=='true' else rfCIVTOSgGnBFuiHYNAwUxbEstMamK
 def get_settings_direct_replay(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  rfCIVTOSgGnBFuiHYNAwUxbEstMayL=rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(__addon__.getSetting('direct_replay'))
  if rfCIVTOSgGnBFuiHYNAwUxbEstMayL==0:
   return rfCIVTOSgGnBFuiHYNAwUxbEstMamK
  else:
   return rfCIVTOSgGnBFuiHYNAwUxbEstMamz
 def set_winEpisodeOrderby(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMayp):
  __addon__.setSetting('tving_orderby',rfCIVTOSgGnBFuiHYNAwUxbEstMayp)
  rfCIVTOSgGnBFuiHYNAwUxbEstMayR=xbmcgui.Window(10000)
  rfCIVTOSgGnBFuiHYNAwUxbEstMayR.setProperty('TVING_M_ORDERBY',rfCIVTOSgGnBFuiHYNAwUxbEstMayp)
 def get_winEpisodeOrderby(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  rfCIVTOSgGnBFuiHYNAwUxbEstMayp=__addon__.getSetting('tving_orderby')
  if rfCIVTOSgGnBFuiHYNAwUxbEstMayp in['',rfCIVTOSgGnBFuiHYNAwUxbEstMamh]:rfCIVTOSgGnBFuiHYNAwUxbEstMayp='desc'
  return rfCIVTOSgGnBFuiHYNAwUxbEstMayp
 def add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,label,sublabel='',img='',infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params='',isLink=rfCIVTOSgGnBFuiHYNAwUxbEstMamK,ContextMenu=rfCIVTOSgGnBFuiHYNAwUxbEstMamh):
  rfCIVTOSgGnBFuiHYNAwUxbEstMayo='%s?%s'%(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_url,urllib.parse.urlencode(params))
  if sublabel:rfCIVTOSgGnBFuiHYNAwUxbEstMayk='%s < %s >'%(label,sublabel)
  else: rfCIVTOSgGnBFuiHYNAwUxbEstMayk=label
  if not img:img='DefaultFolder.png'
  rfCIVTOSgGnBFuiHYNAwUxbEstMayc=xbmcgui.ListItem(rfCIVTOSgGnBFuiHYNAwUxbEstMayk)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMamD(img)==rfCIVTOSgGnBFuiHYNAwUxbEstMamW:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayc.setArt(img)
  else:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayc.setArt({'thumb':img,'poster':img})
  if rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.KodiVersion>=20:
   if infoLabels:rfCIVTOSgGnBFuiHYNAwUxbEstMalR.Set_InfoTag(rfCIVTOSgGnBFuiHYNAwUxbEstMayc.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:rfCIVTOSgGnBFuiHYNAwUxbEstMayc.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayc.setProperty('IsPlayable','true')
  if ContextMenu:rfCIVTOSgGnBFuiHYNAwUxbEstMayc.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,rfCIVTOSgGnBFuiHYNAwUxbEstMayo,rfCIVTOSgGnBFuiHYNAwUxbEstMayc,isFolder)
 def get_selQuality(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,etype):
  try:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayv='selected_quality'
   rfCIVTOSgGnBFuiHYNAwUxbEstMayq=[1080,720,480,360]
   rfCIVTOSgGnBFuiHYNAwUxbEstMayP=rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(__addon__.getSetting(rfCIVTOSgGnBFuiHYNAwUxbEstMayv))
   return rfCIVTOSgGnBFuiHYNAwUxbEstMayq[rfCIVTOSgGnBFuiHYNAwUxbEstMayP]
  except:
   rfCIVTOSgGnBFuiHYNAwUxbEstMamh
  return 720 
 def Set_InfoTag(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,video_InfoTag:xbmc.InfoTagVideo,rfCIVTOSgGnBFuiHYNAwUxbEstMadJ):
  for rfCIVTOSgGnBFuiHYNAwUxbEstMaye,value in rfCIVTOSgGnBFuiHYNAwUxbEstMadJ.items():
   if rfCIVTOSgGnBFuiHYNAwUxbEstMalD[rfCIVTOSgGnBFuiHYNAwUxbEstMaye]['type']=='string':
    rfCIVTOSgGnBFuiHYNAwUxbEstMamL(video_InfoTag,rfCIVTOSgGnBFuiHYNAwUxbEstMalD[rfCIVTOSgGnBFuiHYNAwUxbEstMaye]['func'])(value)
   elif rfCIVTOSgGnBFuiHYNAwUxbEstMalD[rfCIVTOSgGnBFuiHYNAwUxbEstMaye]['type']=='int':
    if rfCIVTOSgGnBFuiHYNAwUxbEstMamD(value)==rfCIVTOSgGnBFuiHYNAwUxbEstMamJ:
     rfCIVTOSgGnBFuiHYNAwUxbEstMayQ=rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(value)
    else:
     rfCIVTOSgGnBFuiHYNAwUxbEstMayQ=0
    rfCIVTOSgGnBFuiHYNAwUxbEstMamL(video_InfoTag,rfCIVTOSgGnBFuiHYNAwUxbEstMalD[rfCIVTOSgGnBFuiHYNAwUxbEstMaye]['func'])(rfCIVTOSgGnBFuiHYNAwUxbEstMayQ)
   elif rfCIVTOSgGnBFuiHYNAwUxbEstMalD[rfCIVTOSgGnBFuiHYNAwUxbEstMaye]['type']=='actor':
    if value!=[]:
     rfCIVTOSgGnBFuiHYNAwUxbEstMamL(video_InfoTag,rfCIVTOSgGnBFuiHYNAwUxbEstMalD[rfCIVTOSgGnBFuiHYNAwUxbEstMaye]['func'])([xbmc.Actor(name)for name in value])
   elif rfCIVTOSgGnBFuiHYNAwUxbEstMalD[rfCIVTOSgGnBFuiHYNAwUxbEstMaye]['type']=='list':
    if rfCIVTOSgGnBFuiHYNAwUxbEstMamD(value)==rfCIVTOSgGnBFuiHYNAwUxbEstMamR:
     rfCIVTOSgGnBFuiHYNAwUxbEstMamL(video_InfoTag,rfCIVTOSgGnBFuiHYNAwUxbEstMalD[rfCIVTOSgGnBFuiHYNAwUxbEstMaye]['func'])(value)
    else:
     rfCIVTOSgGnBFuiHYNAwUxbEstMamL(video_InfoTag,rfCIVTOSgGnBFuiHYNAwUxbEstMalD[rfCIVTOSgGnBFuiHYNAwUxbEstMaye]['func'])([value])
 def dp_Main_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  (rfCIVTOSgGnBFuiHYNAwUxbEstMayz,rfCIVTOSgGnBFuiHYNAwUxbEstMayK,rfCIVTOSgGnBFuiHYNAwUxbEstMaym,rfCIVTOSgGnBFuiHYNAwUxbEstMayD,rfCIVTOSgGnBFuiHYNAwUxbEstMayW)=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_totalsearch()
  for rfCIVTOSgGnBFuiHYNAwUxbEstMayj in rfCIVTOSgGnBFuiHYNAwUxbEstMald:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk=rfCIVTOSgGnBFuiHYNAwUxbEstMayj.get('title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMadl=''
   if rfCIVTOSgGnBFuiHYNAwUxbEstMayj.get('mode')=='SEARCH_GROUP' and rfCIVTOSgGnBFuiHYNAwUxbEstMayz ==rfCIVTOSgGnBFuiHYNAwUxbEstMamK:continue
   elif rfCIVTOSgGnBFuiHYNAwUxbEstMayj.get('mode')=='SEARCH_HISTORY' and rfCIVTOSgGnBFuiHYNAwUxbEstMayK==rfCIVTOSgGnBFuiHYNAwUxbEstMamK:continue
   elif rfCIVTOSgGnBFuiHYNAwUxbEstMayj.get('mode')=='TOTAL_SEARCH' and rfCIVTOSgGnBFuiHYNAwUxbEstMaym ==rfCIVTOSgGnBFuiHYNAwUxbEstMamK:continue
   elif rfCIVTOSgGnBFuiHYNAwUxbEstMayj.get('mode')=='TOTAL_HISTORY' and rfCIVTOSgGnBFuiHYNAwUxbEstMayD==rfCIVTOSgGnBFuiHYNAwUxbEstMamK:continue
   elif rfCIVTOSgGnBFuiHYNAwUxbEstMayj.get('mode')=='MENU_BOOKMARK' and rfCIVTOSgGnBFuiHYNAwUxbEstMayW==rfCIVTOSgGnBFuiHYNAwUxbEstMamK:continue
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':rfCIVTOSgGnBFuiHYNAwUxbEstMayj.get('mode'),'stype':rfCIVTOSgGnBFuiHYNAwUxbEstMayj.get('stype'),'orderby':rfCIVTOSgGnBFuiHYNAwUxbEstMayj.get('orderby'),'ordernm':rfCIVTOSgGnBFuiHYNAwUxbEstMayj.get('ordernm'),'page':'1'}
   if rfCIVTOSgGnBFuiHYNAwUxbEstMayj.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    rfCIVTOSgGnBFuiHYNAwUxbEstMadX=rfCIVTOSgGnBFuiHYNAwUxbEstMamK
    rfCIVTOSgGnBFuiHYNAwUxbEstMadh =rfCIVTOSgGnBFuiHYNAwUxbEstMamz
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMadX=rfCIVTOSgGnBFuiHYNAwUxbEstMamz
    rfCIVTOSgGnBFuiHYNAwUxbEstMadh =rfCIVTOSgGnBFuiHYNAwUxbEstMamK
   rfCIVTOSgGnBFuiHYNAwUxbEstMadJ={'title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'plot':rfCIVTOSgGnBFuiHYNAwUxbEstMayk}
   if rfCIVTOSgGnBFuiHYNAwUxbEstMayj.get('mode')=='XXX':rfCIVTOSgGnBFuiHYNAwUxbEstMadJ=rfCIVTOSgGnBFuiHYNAwUxbEstMamh
   if 'icon' in rfCIVTOSgGnBFuiHYNAwUxbEstMayj:rfCIVTOSgGnBFuiHYNAwUxbEstMadl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',rfCIVTOSgGnBFuiHYNAwUxbEstMayj.get('icon')) 
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel='',img=rfCIVTOSgGnBFuiHYNAwUxbEstMadl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMadJ,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMadX,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady,isLink=rfCIVTOSgGnBFuiHYNAwUxbEstMadh)
  xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle)
 def login_main(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  (rfCIVTOSgGnBFuiHYNAwUxbEstMadK,rfCIVTOSgGnBFuiHYNAwUxbEstMadm,rfCIVTOSgGnBFuiHYNAwUxbEstMadD,rfCIVTOSgGnBFuiHYNAwUxbEstMadW)=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_account()
  if not(rfCIVTOSgGnBFuiHYNAwUxbEstMadK and rfCIVTOSgGnBFuiHYNAwUxbEstMadm):
   rfCIVTOSgGnBFuiHYNAwUxbEstMalv=xbmcgui.Dialog()
   rfCIVTOSgGnBFuiHYNAwUxbEstMadL=rfCIVTOSgGnBFuiHYNAwUxbEstMalv.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if rfCIVTOSgGnBFuiHYNAwUxbEstMadL==rfCIVTOSgGnBFuiHYNAwUxbEstMamz:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if rfCIVTOSgGnBFuiHYNAwUxbEstMalR.cookiefile_check():return
  if base64.standard_b64encode(rfCIVTOSgGnBFuiHYNAwUxbEstMadK.encode()).decode('utf-8')=='a3ltOTUxMDg4':
   rfCIVTOSgGnBFuiHYNAwUxbEstMadR=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.GetCredential2(rfCIVTOSgGnBFuiHYNAwUxbEstMadK,rfCIVTOSgGnBFuiHYNAwUxbEstMadm,rfCIVTOSgGnBFuiHYNAwUxbEstMadD,rfCIVTOSgGnBFuiHYNAwUxbEstMadW)
  else:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalv=xbmcgui.Dialog()
   rfCIVTOSgGnBFuiHYNAwUxbEstMadp=rfCIVTOSgGnBFuiHYNAwUxbEstMalv.browse(1,__language__(30917).encode('utf8'),'','.twc',rfCIVTOSgGnBFuiHYNAwUxbEstMamK,rfCIVTOSgGnBFuiHYNAwUxbEstMamK,'',rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
   if rfCIVTOSgGnBFuiHYNAwUxbEstMadp!='':
    rfCIVTOSgGnBFuiHYNAwUxbEstMado=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'))
    xbmcvfs.copy(rfCIVTOSgGnBFuiHYNAwUxbEstMadp,rfCIVTOSgGnBFuiHYNAwUxbEstMado)
    rfCIVTOSgGnBFuiHYNAwUxbEstMadR=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.WebCookies_Load(rfCIVTOSgGnBFuiHYNAwUxbEstMado)
    xbmcvfs.delete(rfCIVTOSgGnBFuiHYNAwUxbEstMado)
    if rfCIVTOSgGnBFuiHYNAwUxbEstMadR:
     rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.JsonFile_Save(rfCIVTOSgGnBFuiHYNAwUxbEstMalW,rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.TV)
     rfCIVTOSgGnBFuiHYNAwUxbEstMalR.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMadR=rfCIVTOSgGnBFuiHYNAwUxbEstMamK
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadR==rfCIVTOSgGnBFuiHYNAwUxbEstMamz:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.cookiefile_save()
  else:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMadk=rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('stype')
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadk=='live':
   rfCIVTOSgGnBFuiHYNAwUxbEstMadc=rfCIVTOSgGnBFuiHYNAwUxbEstMalX
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMadk=='vod':
   rfCIVTOSgGnBFuiHYNAwUxbEstMadc=rfCIVTOSgGnBFuiHYNAwUxbEstMalz
  else:
   rfCIVTOSgGnBFuiHYNAwUxbEstMadc=rfCIVTOSgGnBFuiHYNAwUxbEstMalK
  for rfCIVTOSgGnBFuiHYNAwUxbEstMadv in rfCIVTOSgGnBFuiHYNAwUxbEstMadc:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk=rfCIVTOSgGnBFuiHYNAwUxbEstMadv.get('title')
   if rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('ordernm')!='-':
    rfCIVTOSgGnBFuiHYNAwUxbEstMayk+='  ('+rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('ordernm')+')'
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':rfCIVTOSgGnBFuiHYNAwUxbEstMadv.get('mode'),'stype':rfCIVTOSgGnBFuiHYNAwUxbEstMadv.get('stype'),'orderby':rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('orderby'),'ordernm':rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('ordernm'),'page':'1'}
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel='',img='',infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMamp(rfCIVTOSgGnBFuiHYNAwUxbEstMadc)>0:xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle)
 def dp_SubTitle_Group(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq): 
  for rfCIVTOSgGnBFuiHYNAwUxbEstMadv in rfCIVTOSgGnBFuiHYNAwUxbEstMalm:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk=rfCIVTOSgGnBFuiHYNAwUxbEstMadv.get('title')
   if rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('ordernm')!='-':
    rfCIVTOSgGnBFuiHYNAwUxbEstMayk+='  ('+rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('ordernm')+')'
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':rfCIVTOSgGnBFuiHYNAwUxbEstMadv.get('mode'),'genreCode':rfCIVTOSgGnBFuiHYNAwUxbEstMadv.get('genreCode'),'stype':rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('stype'),'orderby':rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('orderby'),'page':'1'}
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel='',img='',infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMamp(rfCIVTOSgGnBFuiHYNAwUxbEstMalm)>0:xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle)
 def dp_LiveChannel_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMadk =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('stype')
  rfCIVTOSgGnBFuiHYNAwUxbEstMadP =rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('page'))
  rfCIVTOSgGnBFuiHYNAwUxbEstMade,rfCIVTOSgGnBFuiHYNAwUxbEstMadQ=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.GetLiveChannelList(rfCIVTOSgGnBFuiHYNAwUxbEstMadk,rfCIVTOSgGnBFuiHYNAwUxbEstMadP)
  for rfCIVTOSgGnBFuiHYNAwUxbEstMadj in rfCIVTOSgGnBFuiHYNAwUxbEstMade:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMadz =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('channel')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXl =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('thumbnail')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXy =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('synopsis')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXd =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('channelepg')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXh =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('cast')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXJ =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('director')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXz =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('info_genre')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXK =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('year')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXm =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('mpaa')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXD =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('premiered')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'mediatype':'episode','title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'studio':rfCIVTOSgGnBFuiHYNAwUxbEstMadz,'cast':rfCIVTOSgGnBFuiHYNAwUxbEstMaXh,'director':rfCIVTOSgGnBFuiHYNAwUxbEstMaXJ,'genre':rfCIVTOSgGnBFuiHYNAwUxbEstMaXz,'plot':'%s\n%s\n%s\n\n%s'%(rfCIVTOSgGnBFuiHYNAwUxbEstMadz,rfCIVTOSgGnBFuiHYNAwUxbEstMayk,rfCIVTOSgGnBFuiHYNAwUxbEstMaXd,rfCIVTOSgGnBFuiHYNAwUxbEstMaXy),'year':rfCIVTOSgGnBFuiHYNAwUxbEstMaXK,'mpaa':rfCIVTOSgGnBFuiHYNAwUxbEstMaXm,'premiered':rfCIVTOSgGnBFuiHYNAwUxbEstMaXD}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'LIVE','mediacode':rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('mediacode'),'stype':rfCIVTOSgGnBFuiHYNAwUxbEstMadk}
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMadz,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMayk,img=rfCIVTOSgGnBFuiHYNAwUxbEstMaXl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamK,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadQ:
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['mode']='CHANNEL' 
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['stype']=rfCIVTOSgGnBFuiHYNAwUxbEstMadk 
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['page']=rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk='[B]%s >>[/B]'%'다음 페이지'
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXL=rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMadl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMaXL,img=rfCIVTOSgGnBFuiHYNAwUxbEstMadl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMamp(rfCIVTOSgGnBFuiHYNAwUxbEstMade)>0:xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
 def dp_Program_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMaXR =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('stype')
  rfCIVTOSgGnBFuiHYNAwUxbEstMayp =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('orderby')
  rfCIVTOSgGnBFuiHYNAwUxbEstMadP =rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('page'))
  rfCIVTOSgGnBFuiHYNAwUxbEstMaXp=rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('genreCode')
  if rfCIVTOSgGnBFuiHYNAwUxbEstMaXp==rfCIVTOSgGnBFuiHYNAwUxbEstMamh:rfCIVTOSgGnBFuiHYNAwUxbEstMaXp='all'
  rfCIVTOSgGnBFuiHYNAwUxbEstMaXo,rfCIVTOSgGnBFuiHYNAwUxbEstMadQ=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.GetProgramList(rfCIVTOSgGnBFuiHYNAwUxbEstMaXR,rfCIVTOSgGnBFuiHYNAwUxbEstMayp,rfCIVTOSgGnBFuiHYNAwUxbEstMadP,rfCIVTOSgGnBFuiHYNAwUxbEstMaXp)
  for rfCIVTOSgGnBFuiHYNAwUxbEstMaXk in rfCIVTOSgGnBFuiHYNAwUxbEstMaXo:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXl =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('thumbnail')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXy =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('synopsis')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXc =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('channel')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXh =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('cast')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXJ =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('director')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXz=rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('info_genre')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXK =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('year')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXD =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('premiered')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXm =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('mpaa')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'mediatype':'tvshow','title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'studio':rfCIVTOSgGnBFuiHYNAwUxbEstMaXc,'cast':rfCIVTOSgGnBFuiHYNAwUxbEstMaXh,'director':rfCIVTOSgGnBFuiHYNAwUxbEstMaXJ,'genre':rfCIVTOSgGnBFuiHYNAwUxbEstMaXz,'year':rfCIVTOSgGnBFuiHYNAwUxbEstMaXK,'premiered':rfCIVTOSgGnBFuiHYNAwUxbEstMaXD,'mpaa':rfCIVTOSgGnBFuiHYNAwUxbEstMaXm,'plot':rfCIVTOSgGnBFuiHYNAwUxbEstMaXy}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'EPISODE','programcode':rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('program'),'page':'1'}
   if rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_makebookmark():
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXv={'videoid':rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('program'),'vidtype':'tvshow','vtitle':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'vsubtitle':rfCIVTOSgGnBFuiHYNAwUxbEstMaXc,}
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXq=json.dumps(rfCIVTOSgGnBFuiHYNAwUxbEstMaXv)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXq=urllib.parse.quote(rfCIVTOSgGnBFuiHYNAwUxbEstMaXq)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXP='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(rfCIVTOSgGnBFuiHYNAwUxbEstMaXq)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=[('(통합) 찜 영상에 추가',rfCIVTOSgGnBFuiHYNAwUxbEstMaXP)]
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=rfCIVTOSgGnBFuiHYNAwUxbEstMamh
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMaXc,img=rfCIVTOSgGnBFuiHYNAwUxbEstMaXl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady,ContextMenu=rfCIVTOSgGnBFuiHYNAwUxbEstMaXe)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadQ:
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['mode'] ='PROGRAM' 
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['stype'] =rfCIVTOSgGnBFuiHYNAwUxbEstMaXR
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['orderby'] =rfCIVTOSgGnBFuiHYNAwUxbEstMayp
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['page'] =rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['genreCode']=rfCIVTOSgGnBFuiHYNAwUxbEstMaXp 
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk='[B]%s >>[/B]'%'다음 페이지'
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXL=rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMadl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMaXL,img=rfCIVTOSgGnBFuiHYNAwUxbEstMadl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  xbmcplugin.setContent(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
 def dp_4K_Program_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMadP =rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('page'))
  rfCIVTOSgGnBFuiHYNAwUxbEstMaXo,rfCIVTOSgGnBFuiHYNAwUxbEstMadQ=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Get_UHD_ProgramList(rfCIVTOSgGnBFuiHYNAwUxbEstMadP)
  for rfCIVTOSgGnBFuiHYNAwUxbEstMaXk in rfCIVTOSgGnBFuiHYNAwUxbEstMaXo:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXl =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('thumbnail')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXy =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('synopsis')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXc =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('channel')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXh =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('cast')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXJ =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('director')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXz=rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('info_genre')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXK =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('year')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXD =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('premiered')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXm =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('mpaa')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'mediatype':'tvshow','title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'studio':rfCIVTOSgGnBFuiHYNAwUxbEstMaXc,'cast':rfCIVTOSgGnBFuiHYNAwUxbEstMaXh,'director':rfCIVTOSgGnBFuiHYNAwUxbEstMaXJ,'genre':rfCIVTOSgGnBFuiHYNAwUxbEstMaXz,'year':rfCIVTOSgGnBFuiHYNAwUxbEstMaXK,'premiered':rfCIVTOSgGnBFuiHYNAwUxbEstMaXD,'mpaa':rfCIVTOSgGnBFuiHYNAwUxbEstMaXm,'plot':rfCIVTOSgGnBFuiHYNAwUxbEstMaXy}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'EPISODE','programcode':rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('program'),'page':'1'}
   if rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_makebookmark():
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXv={'videoid':rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('program'),'vidtype':'tvshow','vtitle':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'vsubtitle':rfCIVTOSgGnBFuiHYNAwUxbEstMaXc,}
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXq=json.dumps(rfCIVTOSgGnBFuiHYNAwUxbEstMaXv)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXq=urllib.parse.quote(rfCIVTOSgGnBFuiHYNAwUxbEstMaXq)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXP='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(rfCIVTOSgGnBFuiHYNAwUxbEstMaXq)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=[('(통합) 찜 영상에 추가',rfCIVTOSgGnBFuiHYNAwUxbEstMaXP)]
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=rfCIVTOSgGnBFuiHYNAwUxbEstMamh
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMaXc,img=rfCIVTOSgGnBFuiHYNAwUxbEstMaXl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady,ContextMenu=rfCIVTOSgGnBFuiHYNAwUxbEstMaXe)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadQ:
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['mode'] ='4K_PROGRAM' 
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['page'] =rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk='[B]%s >>[/B]'%'다음 페이지'
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXL=rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMadl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMaXL,img=rfCIVTOSgGnBFuiHYNAwUxbEstMadl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  xbmcplugin.setContent(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
 def dp_Ori_Program_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMadP =rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('page'))
  rfCIVTOSgGnBFuiHYNAwUxbEstMaXo,rfCIVTOSgGnBFuiHYNAwUxbEstMadQ=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Get_Origianl_ProgramList(rfCIVTOSgGnBFuiHYNAwUxbEstMadP)
  for rfCIVTOSgGnBFuiHYNAwUxbEstMaXk in rfCIVTOSgGnBFuiHYNAwUxbEstMaXo:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXl =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('thumbnail')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXj =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('vod_type')
   rfCIVTOSgGnBFuiHYNAwUxbEstMahl =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('vod_code')
   if rfCIVTOSgGnBFuiHYNAwUxbEstMaXj=='vod':
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'mediatype':'tvshow','title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,}
    rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'EPISODE','programcode':rfCIVTOSgGnBFuiHYNAwUxbEstMahl,'page':'1',}
    rfCIVTOSgGnBFuiHYNAwUxbEstMadX=rfCIVTOSgGnBFuiHYNAwUxbEstMamz
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'mediatype':'movie','title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'plot':'movie',}
    rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'MOVIE','mediacode':rfCIVTOSgGnBFuiHYNAwUxbEstMahl,'stype':'movie','title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'thumbnail':rfCIVTOSgGnBFuiHYNAwUxbEstMaXl,}
    rfCIVTOSgGnBFuiHYNAwUxbEstMadX=rfCIVTOSgGnBFuiHYNAwUxbEstMamK
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,img=rfCIVTOSgGnBFuiHYNAwUxbEstMaXl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMadX,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady,ContextMenu=rfCIVTOSgGnBFuiHYNAwUxbEstMamh)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadQ:
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['mode'] ='ORI_PROGRAM' 
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['page'] =rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk='[B]%s >>[/B]'%'다음 페이지'
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXL=rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMadl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMaXL,img=rfCIVTOSgGnBFuiHYNAwUxbEstMadl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  xbmcplugin.setContent(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
 def dp_Episode_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMahy=rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('programcode')
  rfCIVTOSgGnBFuiHYNAwUxbEstMadP =rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('page'))
  rfCIVTOSgGnBFuiHYNAwUxbEstMahd,rfCIVTOSgGnBFuiHYNAwUxbEstMadQ,rfCIVTOSgGnBFuiHYNAwUxbEstMahX=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.GetEpisodeList(rfCIVTOSgGnBFuiHYNAwUxbEstMahy,rfCIVTOSgGnBFuiHYNAwUxbEstMadP,orderby=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_winEpisodeOrderby())
  for rfCIVTOSgGnBFuiHYNAwUxbEstMahJ in rfCIVTOSgGnBFuiHYNAwUxbEstMahd:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk =rfCIVTOSgGnBFuiHYNAwUxbEstMahJ.get('title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXL =rfCIVTOSgGnBFuiHYNAwUxbEstMahJ.get('subtitle')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXl =rfCIVTOSgGnBFuiHYNAwUxbEstMahJ.get('thumbnail')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXy =rfCIVTOSgGnBFuiHYNAwUxbEstMahJ.get('synopsis')
   rfCIVTOSgGnBFuiHYNAwUxbEstMahz=rfCIVTOSgGnBFuiHYNAwUxbEstMahJ.get('info_title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMahK =rfCIVTOSgGnBFuiHYNAwUxbEstMahJ.get('aired')
   rfCIVTOSgGnBFuiHYNAwUxbEstMahm =rfCIVTOSgGnBFuiHYNAwUxbEstMahJ.get('studio')
   rfCIVTOSgGnBFuiHYNAwUxbEstMahD =rfCIVTOSgGnBFuiHYNAwUxbEstMahJ.get('frequency')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'mediatype':'episode','title':rfCIVTOSgGnBFuiHYNAwUxbEstMahz,'aired':rfCIVTOSgGnBFuiHYNAwUxbEstMahK,'studio':rfCIVTOSgGnBFuiHYNAwUxbEstMahm,'episode':rfCIVTOSgGnBFuiHYNAwUxbEstMahD,'plot':rfCIVTOSgGnBFuiHYNAwUxbEstMaXy}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'VOD','mediacode':rfCIVTOSgGnBFuiHYNAwUxbEstMahJ.get('episode'),'stype':'vod','programcode':rfCIVTOSgGnBFuiHYNAwUxbEstMahy,'title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'thumbnail':rfCIVTOSgGnBFuiHYNAwUxbEstMaXl}
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMaXL,img=rfCIVTOSgGnBFuiHYNAwUxbEstMaXl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamK,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadP==1:
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'plot':'정렬순서를 변경합니다.'}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['mode'] ='ORDER_BY' 
   if rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_winEpisodeOrderby()=='desc':
    rfCIVTOSgGnBFuiHYNAwUxbEstMayk='정렬순서변경 : 최신화부터 -> 1회부터'
    rfCIVTOSgGnBFuiHYNAwUxbEstMady['orderby']='asc'
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMayk='정렬순서변경 : 1회부터 -> 최신화부터'
    rfCIVTOSgGnBFuiHYNAwUxbEstMady['orderby']='desc'
   rfCIVTOSgGnBFuiHYNAwUxbEstMadl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel='',img=rfCIVTOSgGnBFuiHYNAwUxbEstMadl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamK,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady,isLink=rfCIVTOSgGnBFuiHYNAwUxbEstMamz)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadQ:
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['mode'] ='EPISODE' 
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['programcode']=rfCIVTOSgGnBFuiHYNAwUxbEstMahy
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['page'] =rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk='[B]%s >>[/B]'%'다음 페이지'
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXL=rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMadl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMaXL,img=rfCIVTOSgGnBFuiHYNAwUxbEstMadl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  xbmcplugin.setContent(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,'episodes')
  if rfCIVTOSgGnBFuiHYNAwUxbEstMamp(rfCIVTOSgGnBFuiHYNAwUxbEstMahd)>0:xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamz)
 def dp_setEpOrderby(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMayp =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('orderby')
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.set_winEpisodeOrderby(rfCIVTOSgGnBFuiHYNAwUxbEstMayp)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMaXR =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('stype')
  rfCIVTOSgGnBFuiHYNAwUxbEstMayp =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('orderby')
  rfCIVTOSgGnBFuiHYNAwUxbEstMadP=rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('page'))
  rfCIVTOSgGnBFuiHYNAwUxbEstMahW,rfCIVTOSgGnBFuiHYNAwUxbEstMadQ=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.GetMovieList(rfCIVTOSgGnBFuiHYNAwUxbEstMaXR,rfCIVTOSgGnBFuiHYNAwUxbEstMayp,rfCIVTOSgGnBFuiHYNAwUxbEstMadP)
  for rfCIVTOSgGnBFuiHYNAwUxbEstMahL in rfCIVTOSgGnBFuiHYNAwUxbEstMahW:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXl =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('thumbnail')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXy =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('synopsis')
   rfCIVTOSgGnBFuiHYNAwUxbEstMahz =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('info_title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXK =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('year')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXh =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('cast')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXJ =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('director')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXz =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('info_genre')
   rfCIVTOSgGnBFuiHYNAwUxbEstMahR =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('duration')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXD =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('premiered')
   rfCIVTOSgGnBFuiHYNAwUxbEstMahm =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('studio')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXm =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('mpaa')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'mediatype':'movie','title':rfCIVTOSgGnBFuiHYNAwUxbEstMahz,'year':rfCIVTOSgGnBFuiHYNAwUxbEstMaXK,'cast':rfCIVTOSgGnBFuiHYNAwUxbEstMaXh,'director':rfCIVTOSgGnBFuiHYNAwUxbEstMaXJ,'genre':rfCIVTOSgGnBFuiHYNAwUxbEstMaXz,'duration':rfCIVTOSgGnBFuiHYNAwUxbEstMahR,'premiered':rfCIVTOSgGnBFuiHYNAwUxbEstMaXD,'studio':rfCIVTOSgGnBFuiHYNAwUxbEstMahm,'mpaa':rfCIVTOSgGnBFuiHYNAwUxbEstMaXm,'plot':rfCIVTOSgGnBFuiHYNAwUxbEstMaXy}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'MOVIE','mediacode':rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('moviecode'),'stype':'movie','title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'thumbnail':rfCIVTOSgGnBFuiHYNAwUxbEstMaXl}
   if rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_makebookmark():
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXv={'videoid':rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('moviecode'),'vidtype':'movie','vtitle':rfCIVTOSgGnBFuiHYNAwUxbEstMahz,'vsubtitle':'',}
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXq=json.dumps(rfCIVTOSgGnBFuiHYNAwUxbEstMaXv)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXq=urllib.parse.quote(rfCIVTOSgGnBFuiHYNAwUxbEstMaXq)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXP='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(rfCIVTOSgGnBFuiHYNAwUxbEstMaXq)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=[('(통합) 찜 영상에 추가',rfCIVTOSgGnBFuiHYNAwUxbEstMaXP)]
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=rfCIVTOSgGnBFuiHYNAwUxbEstMamh
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel='',img=rfCIVTOSgGnBFuiHYNAwUxbEstMaXl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamK,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady,ContextMenu=rfCIVTOSgGnBFuiHYNAwUxbEstMaXe)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadQ:
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['mode'] ='MOVIE_SUB' 
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['orderby']=rfCIVTOSgGnBFuiHYNAwUxbEstMayp
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['stype'] =rfCIVTOSgGnBFuiHYNAwUxbEstMaXR
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['page'] =rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk='[B]%s >>[/B]'%'다음 페이지'
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXL=rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMadl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMaXL,img=rfCIVTOSgGnBFuiHYNAwUxbEstMadl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  xbmcplugin.setContent(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,'movies')
  xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
 def dp_4K_Movie_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMadP=rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('page'))
  rfCIVTOSgGnBFuiHYNAwUxbEstMahW,rfCIVTOSgGnBFuiHYNAwUxbEstMadQ=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Get_UHD_MovieList(rfCIVTOSgGnBFuiHYNAwUxbEstMadP)
  for rfCIVTOSgGnBFuiHYNAwUxbEstMahL in rfCIVTOSgGnBFuiHYNAwUxbEstMahW:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXl =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('thumbnail')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXy =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('synopsis')
   rfCIVTOSgGnBFuiHYNAwUxbEstMahz =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('info_title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXK =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('year')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXh =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('cast')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXJ =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('director')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXz =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('info_genre')
   rfCIVTOSgGnBFuiHYNAwUxbEstMahR =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('duration')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXD =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('premiered')
   rfCIVTOSgGnBFuiHYNAwUxbEstMahm =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('studio')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXm =rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('mpaa')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'mediatype':'movie','title':rfCIVTOSgGnBFuiHYNAwUxbEstMahz,'year':rfCIVTOSgGnBFuiHYNAwUxbEstMaXK,'cast':rfCIVTOSgGnBFuiHYNAwUxbEstMaXh,'director':rfCIVTOSgGnBFuiHYNAwUxbEstMaXJ,'genre':rfCIVTOSgGnBFuiHYNAwUxbEstMaXz,'duration':rfCIVTOSgGnBFuiHYNAwUxbEstMahR,'premiered':rfCIVTOSgGnBFuiHYNAwUxbEstMaXD,'studio':rfCIVTOSgGnBFuiHYNAwUxbEstMahm,'mpaa':rfCIVTOSgGnBFuiHYNAwUxbEstMaXm,'plot':rfCIVTOSgGnBFuiHYNAwUxbEstMaXy}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'MOVIE','mediacode':rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('moviecode'),'stype':'movie','title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'thumbnail':rfCIVTOSgGnBFuiHYNAwUxbEstMaXl}
   if rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_makebookmark():
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXv={'videoid':rfCIVTOSgGnBFuiHYNAwUxbEstMahL.get('moviecode'),'vidtype':'movie','vtitle':rfCIVTOSgGnBFuiHYNAwUxbEstMahz,'vsubtitle':'',}
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXq=json.dumps(rfCIVTOSgGnBFuiHYNAwUxbEstMaXv)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXq=urllib.parse.quote(rfCIVTOSgGnBFuiHYNAwUxbEstMaXq)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXP='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(rfCIVTOSgGnBFuiHYNAwUxbEstMaXq)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=[('(통합) 찜 영상에 추가',rfCIVTOSgGnBFuiHYNAwUxbEstMaXP)]
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=rfCIVTOSgGnBFuiHYNAwUxbEstMamh
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel='',img=rfCIVTOSgGnBFuiHYNAwUxbEstMaXl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamK,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady,ContextMenu=rfCIVTOSgGnBFuiHYNAwUxbEstMaXe)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadQ:
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['mode'] ='4K_MOVIE' 
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['page'] =rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk='[B]%s >>[/B]'%'다음 페이지'
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXL=rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMadl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMaXL,img=rfCIVTOSgGnBFuiHYNAwUxbEstMadl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  xbmcplugin.setContent(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,'movies')
  xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
 def dp_Set_Bookmark(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMahp=urllib.parse.unquote(rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('bm_param'))
  rfCIVTOSgGnBFuiHYNAwUxbEstMahp=json.loads(rfCIVTOSgGnBFuiHYNAwUxbEstMahp)
  rfCIVTOSgGnBFuiHYNAwUxbEstMaho =rfCIVTOSgGnBFuiHYNAwUxbEstMahp.get('videoid')
  rfCIVTOSgGnBFuiHYNAwUxbEstMahk =rfCIVTOSgGnBFuiHYNAwUxbEstMahp.get('vidtype')
  rfCIVTOSgGnBFuiHYNAwUxbEstMahc =rfCIVTOSgGnBFuiHYNAwUxbEstMahp.get('vtitle')
  rfCIVTOSgGnBFuiHYNAwUxbEstMahv =rfCIVTOSgGnBFuiHYNAwUxbEstMahp.get('vsubtitle')
  rfCIVTOSgGnBFuiHYNAwUxbEstMalv=xbmcgui.Dialog()
  rfCIVTOSgGnBFuiHYNAwUxbEstMadL=rfCIVTOSgGnBFuiHYNAwUxbEstMalv.yesno(__language__(30913).encode('utf8'),rfCIVTOSgGnBFuiHYNAwUxbEstMahc+' \n\n'+__language__(30914))
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadL==rfCIVTOSgGnBFuiHYNAwUxbEstMamK:return
  rfCIVTOSgGnBFuiHYNAwUxbEstMahq=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.GetBookmarkInfo(rfCIVTOSgGnBFuiHYNAwUxbEstMaho,rfCIVTOSgGnBFuiHYNAwUxbEstMahk)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMahv!='':
   rfCIVTOSgGnBFuiHYNAwUxbEstMahq['saveinfo']['subtitle']=rfCIVTOSgGnBFuiHYNAwUxbEstMahv 
   if rfCIVTOSgGnBFuiHYNAwUxbEstMahk=='tvshow':rfCIVTOSgGnBFuiHYNAwUxbEstMahq['saveinfo']['infoLabels']['studio']=rfCIVTOSgGnBFuiHYNAwUxbEstMahv 
  rfCIVTOSgGnBFuiHYNAwUxbEstMahP=json.dumps(rfCIVTOSgGnBFuiHYNAwUxbEstMahq)
  rfCIVTOSgGnBFuiHYNAwUxbEstMahP=urllib.parse.quote(rfCIVTOSgGnBFuiHYNAwUxbEstMahP)
  rfCIVTOSgGnBFuiHYNAwUxbEstMaXP ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(rfCIVTOSgGnBFuiHYNAwUxbEstMahP)
  xbmc.executebuiltin(rfCIVTOSgGnBFuiHYNAwUxbEstMaXP)
 def dp_Search_Group(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  if 'search_key' in rfCIVTOSgGnBFuiHYNAwUxbEstMadq:
   rfCIVTOSgGnBFuiHYNAwUxbEstMahe=rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('search_key')
  else:
   rfCIVTOSgGnBFuiHYNAwUxbEstMahe=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not rfCIVTOSgGnBFuiHYNAwUxbEstMahe:
    return
  for rfCIVTOSgGnBFuiHYNAwUxbEstMadv in rfCIVTOSgGnBFuiHYNAwUxbEstMalJ:
   rfCIVTOSgGnBFuiHYNAwUxbEstMahQ =rfCIVTOSgGnBFuiHYNAwUxbEstMadv.get('mode')
   rfCIVTOSgGnBFuiHYNAwUxbEstMadk=rfCIVTOSgGnBFuiHYNAwUxbEstMadv.get('stype')
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk=rfCIVTOSgGnBFuiHYNAwUxbEstMadv.get('title')
   (rfCIVTOSgGnBFuiHYNAwUxbEstMahj,rfCIVTOSgGnBFuiHYNAwUxbEstMadQ)=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.GetSearchList(rfCIVTOSgGnBFuiHYNAwUxbEstMahe,1,rfCIVTOSgGnBFuiHYNAwUxbEstMadk)
   rfCIVTOSgGnBFuiHYNAwUxbEstMadJ={'plot':'검색어 : '+rfCIVTOSgGnBFuiHYNAwUxbEstMahe+'\n\n'+rfCIVTOSgGnBFuiHYNAwUxbEstMalR.Search_FreeList(rfCIVTOSgGnBFuiHYNAwUxbEstMahj)}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':rfCIVTOSgGnBFuiHYNAwUxbEstMahQ,'stype':rfCIVTOSgGnBFuiHYNAwUxbEstMadk,'search_key':rfCIVTOSgGnBFuiHYNAwUxbEstMahe,'page':'1',}
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel='',img='',infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMadJ,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMamp(rfCIVTOSgGnBFuiHYNAwUxbEstMalJ)>0:xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamz)
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.Save_Searched_List(rfCIVTOSgGnBFuiHYNAwUxbEstMahe)
 def Search_FreeList(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMaJD):
  rfCIVTOSgGnBFuiHYNAwUxbEstMaJl=''
  rfCIVTOSgGnBFuiHYNAwUxbEstMaJy=7
  try:
   if rfCIVTOSgGnBFuiHYNAwUxbEstMamp(rfCIVTOSgGnBFuiHYNAwUxbEstMaJD)==0:return '검색결과 없음'
   for i in rfCIVTOSgGnBFuiHYNAwUxbEstMamk(rfCIVTOSgGnBFuiHYNAwUxbEstMamp(rfCIVTOSgGnBFuiHYNAwUxbEstMaJD)):
    if i>=rfCIVTOSgGnBFuiHYNAwUxbEstMaJy:
     rfCIVTOSgGnBFuiHYNAwUxbEstMaJl=rfCIVTOSgGnBFuiHYNAwUxbEstMaJl+'...'
     break
    rfCIVTOSgGnBFuiHYNAwUxbEstMaJl=rfCIVTOSgGnBFuiHYNAwUxbEstMaJl+rfCIVTOSgGnBFuiHYNAwUxbEstMaJD[i]['title']+'\n'
  except:
   return ''
  return rfCIVTOSgGnBFuiHYNAwUxbEstMaJl
 def dp_Search_History(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMaJd=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.Load_List_File('search')
  for rfCIVTOSgGnBFuiHYNAwUxbEstMaJX in rfCIVTOSgGnBFuiHYNAwUxbEstMaJd:
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJh=rfCIVTOSgGnBFuiHYNAwUxbEstMamW(urllib.parse.parse_qsl(rfCIVTOSgGnBFuiHYNAwUxbEstMaJX))
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJz=rfCIVTOSgGnBFuiHYNAwUxbEstMaJh.get('skey').strip()
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'SEARCH_GROUP','search_key':rfCIVTOSgGnBFuiHYNAwUxbEstMaJz,}
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJK={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':rfCIVTOSgGnBFuiHYNAwUxbEstMaJz,'vType':'-',}
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJm=urllib.parse.urlencode(rfCIVTOSgGnBFuiHYNAwUxbEstMaJK)
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=[('선택된 검색어 ( %s ) 삭제'%(rfCIVTOSgGnBFuiHYNAwUxbEstMaJz),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(rfCIVTOSgGnBFuiHYNAwUxbEstMaJm))]
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMaJz,sublabel='',img=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady,ContextMenu=rfCIVTOSgGnBFuiHYNAwUxbEstMaXe)
  rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'plot':'검색목록 전체를 삭제합니다.'}
  rfCIVTOSgGnBFuiHYNAwUxbEstMayk='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  rfCIVTOSgGnBFuiHYNAwUxbEstMadl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel='',img=rfCIVTOSgGnBFuiHYNAwUxbEstMadl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamK,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady,isLink=rfCIVTOSgGnBFuiHYNAwUxbEstMamz)
  xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
 def dp_Search_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMadP =rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('page'))
  rfCIVTOSgGnBFuiHYNAwUxbEstMadk =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('stype')
  if 'search_key' in rfCIVTOSgGnBFuiHYNAwUxbEstMadq:
   rfCIVTOSgGnBFuiHYNAwUxbEstMahe=rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('search_key')
  else:
   rfCIVTOSgGnBFuiHYNAwUxbEstMahe=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not rfCIVTOSgGnBFuiHYNAwUxbEstMahe:
    xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle)
    return
  rfCIVTOSgGnBFuiHYNAwUxbEstMahj,rfCIVTOSgGnBFuiHYNAwUxbEstMadQ=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.GetSearchList(rfCIVTOSgGnBFuiHYNAwUxbEstMahe,rfCIVTOSgGnBFuiHYNAwUxbEstMadP,rfCIVTOSgGnBFuiHYNAwUxbEstMadk)
  for rfCIVTOSgGnBFuiHYNAwUxbEstMaJD in rfCIVTOSgGnBFuiHYNAwUxbEstMahj:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk =rfCIVTOSgGnBFuiHYNAwUxbEstMaJD.get('title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXl =rfCIVTOSgGnBFuiHYNAwUxbEstMaJD.get('thumbnail')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXy =rfCIVTOSgGnBFuiHYNAwUxbEstMaJD.get('synopsis')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJW =rfCIVTOSgGnBFuiHYNAwUxbEstMaJD.get('program')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXh =rfCIVTOSgGnBFuiHYNAwUxbEstMaJD.get('cast')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXJ =rfCIVTOSgGnBFuiHYNAwUxbEstMaJD.get('director')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXz=rfCIVTOSgGnBFuiHYNAwUxbEstMaJD.get('info_genre')
   rfCIVTOSgGnBFuiHYNAwUxbEstMahR =rfCIVTOSgGnBFuiHYNAwUxbEstMaJD.get('duration')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXm =rfCIVTOSgGnBFuiHYNAwUxbEstMaJD.get('mpaa')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXK =rfCIVTOSgGnBFuiHYNAwUxbEstMaJD.get('year')
   rfCIVTOSgGnBFuiHYNAwUxbEstMahK =rfCIVTOSgGnBFuiHYNAwUxbEstMaJD.get('aired')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'mediatype':'tvshow' if rfCIVTOSgGnBFuiHYNAwUxbEstMadk=='vod' else 'movie','title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'cast':rfCIVTOSgGnBFuiHYNAwUxbEstMaXh,'director':rfCIVTOSgGnBFuiHYNAwUxbEstMaXJ,'genre':rfCIVTOSgGnBFuiHYNAwUxbEstMaXz,'duration':rfCIVTOSgGnBFuiHYNAwUxbEstMahR,'mpaa':rfCIVTOSgGnBFuiHYNAwUxbEstMaXm,'year':rfCIVTOSgGnBFuiHYNAwUxbEstMaXK,'aired':rfCIVTOSgGnBFuiHYNAwUxbEstMahK,'plot':'%s\n\n%s'%(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,rfCIVTOSgGnBFuiHYNAwUxbEstMaXy)}
   if rfCIVTOSgGnBFuiHYNAwUxbEstMadk=='vod':
    rfCIVTOSgGnBFuiHYNAwUxbEstMaho=rfCIVTOSgGnBFuiHYNAwUxbEstMaJD.get('program')
    rfCIVTOSgGnBFuiHYNAwUxbEstMahk='tvshow'
    rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'EPISODE','programcode':rfCIVTOSgGnBFuiHYNAwUxbEstMaho,'page':'1',}
    rfCIVTOSgGnBFuiHYNAwUxbEstMadX=rfCIVTOSgGnBFuiHYNAwUxbEstMamz
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaho=rfCIVTOSgGnBFuiHYNAwUxbEstMaJD.get('movie')
    rfCIVTOSgGnBFuiHYNAwUxbEstMahk='movie'
    rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'MOVIE','mediacode':rfCIVTOSgGnBFuiHYNAwUxbEstMaho,'stype':'movie','title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'thumbnail':rfCIVTOSgGnBFuiHYNAwUxbEstMaXl,}
    rfCIVTOSgGnBFuiHYNAwUxbEstMadX=rfCIVTOSgGnBFuiHYNAwUxbEstMamK
   if rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_makebookmark():
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXv={'videoid':rfCIVTOSgGnBFuiHYNAwUxbEstMaho,'vidtype':rfCIVTOSgGnBFuiHYNAwUxbEstMahk,'vtitle':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'vsubtitle':'',}
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXq=json.dumps(rfCIVTOSgGnBFuiHYNAwUxbEstMaXv)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXq=urllib.parse.quote(rfCIVTOSgGnBFuiHYNAwUxbEstMaXq)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXP='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(rfCIVTOSgGnBFuiHYNAwUxbEstMaXq)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=[('(통합) 찜 영상에 추가',rfCIVTOSgGnBFuiHYNAwUxbEstMaXP)]
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=rfCIVTOSgGnBFuiHYNAwUxbEstMamh
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel='',img=rfCIVTOSgGnBFuiHYNAwUxbEstMaXl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMadX,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady,isLink=rfCIVTOSgGnBFuiHYNAwUxbEstMamK,ContextMenu=rfCIVTOSgGnBFuiHYNAwUxbEstMaXe)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadQ:
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['mode'] ='SEARCH' 
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['search_key']=rfCIVTOSgGnBFuiHYNAwUxbEstMahe
   rfCIVTOSgGnBFuiHYNAwUxbEstMady['page'] =rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk='[B]%s >>[/B]'%'다음 페이지'
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXL=rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMadP+1)
   rfCIVTOSgGnBFuiHYNAwUxbEstMadl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMaXL,img=rfCIVTOSgGnBFuiHYNAwUxbEstMadl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadk=='movie':xbmcplugin.setContent(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,'movies')
  else:xbmcplugin.setContent(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
 def dp_History_Remove(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMaJL=rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('delType')
  rfCIVTOSgGnBFuiHYNAwUxbEstMaJR =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('sKey')
  rfCIVTOSgGnBFuiHYNAwUxbEstMaJp =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('vType')
  rfCIVTOSgGnBFuiHYNAwUxbEstMalv=xbmcgui.Dialog()
  if rfCIVTOSgGnBFuiHYNAwUxbEstMaJL=='SEARCH_ALL':
   rfCIVTOSgGnBFuiHYNAwUxbEstMadL=rfCIVTOSgGnBFuiHYNAwUxbEstMalv.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMaJL=='SEARCH_ONE':
   rfCIVTOSgGnBFuiHYNAwUxbEstMadL=rfCIVTOSgGnBFuiHYNAwUxbEstMalv.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMaJL=='WATCH_ALL':
   rfCIVTOSgGnBFuiHYNAwUxbEstMadL=rfCIVTOSgGnBFuiHYNAwUxbEstMalv.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMaJL=='WATCH_ONE':
   rfCIVTOSgGnBFuiHYNAwUxbEstMadL=rfCIVTOSgGnBFuiHYNAwUxbEstMalv.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadL==rfCIVTOSgGnBFuiHYNAwUxbEstMamK:sys.exit()
  if rfCIVTOSgGnBFuiHYNAwUxbEstMaJL=='SEARCH_ALL':
   if os.path.isfile(rfCIVTOSgGnBFuiHYNAwUxbEstMalL):os.remove(rfCIVTOSgGnBFuiHYNAwUxbEstMalL)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMaJL=='SEARCH_ONE':
   try:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaJo=rfCIVTOSgGnBFuiHYNAwUxbEstMalL
    rfCIVTOSgGnBFuiHYNAwUxbEstMaJk=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.Load_List_File('search') 
    fp=rfCIVTOSgGnBFuiHYNAwUxbEstMamc(rfCIVTOSgGnBFuiHYNAwUxbEstMaJo,'w',-1,'utf-8')
    for rfCIVTOSgGnBFuiHYNAwUxbEstMaJc in rfCIVTOSgGnBFuiHYNAwUxbEstMaJk:
     rfCIVTOSgGnBFuiHYNAwUxbEstMaJv=rfCIVTOSgGnBFuiHYNAwUxbEstMamW(urllib.parse.parse_qsl(rfCIVTOSgGnBFuiHYNAwUxbEstMaJc))
     rfCIVTOSgGnBFuiHYNAwUxbEstMaJq=rfCIVTOSgGnBFuiHYNAwUxbEstMaJv.get('skey').strip()
     if rfCIVTOSgGnBFuiHYNAwUxbEstMaJR!=rfCIVTOSgGnBFuiHYNAwUxbEstMaJq:
      fp.write(rfCIVTOSgGnBFuiHYNAwUxbEstMaJc)
    fp.close()
   except:
    rfCIVTOSgGnBFuiHYNAwUxbEstMamh
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMaJL=='WATCH_ALL':
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rfCIVTOSgGnBFuiHYNAwUxbEstMaJp))
   if os.path.isfile(rfCIVTOSgGnBFuiHYNAwUxbEstMaJo):os.remove(rfCIVTOSgGnBFuiHYNAwUxbEstMaJo)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMaJL=='WATCH_ONE':
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rfCIVTOSgGnBFuiHYNAwUxbEstMaJp))
   try:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaJk=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.Load_List_File(rfCIVTOSgGnBFuiHYNAwUxbEstMaJp) 
    fp=rfCIVTOSgGnBFuiHYNAwUxbEstMamc(rfCIVTOSgGnBFuiHYNAwUxbEstMaJo,'w',-1,'utf-8')
    for rfCIVTOSgGnBFuiHYNAwUxbEstMaJc in rfCIVTOSgGnBFuiHYNAwUxbEstMaJk:
     rfCIVTOSgGnBFuiHYNAwUxbEstMaJv=rfCIVTOSgGnBFuiHYNAwUxbEstMamW(urllib.parse.parse_qsl(rfCIVTOSgGnBFuiHYNAwUxbEstMaJc))
     rfCIVTOSgGnBFuiHYNAwUxbEstMaJq=rfCIVTOSgGnBFuiHYNAwUxbEstMaJv.get('code').strip()
     if rfCIVTOSgGnBFuiHYNAwUxbEstMaJR!=rfCIVTOSgGnBFuiHYNAwUxbEstMaJq:
      fp.write(rfCIVTOSgGnBFuiHYNAwUxbEstMaJc)
    fp.close()
   except:
    rfCIVTOSgGnBFuiHYNAwUxbEstMamh
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadk): 
  try:
   if rfCIVTOSgGnBFuiHYNAwUxbEstMadk=='search':
    rfCIVTOSgGnBFuiHYNAwUxbEstMaJo=rfCIVTOSgGnBFuiHYNAwUxbEstMalL
   elif rfCIVTOSgGnBFuiHYNAwUxbEstMadk in['vod','movie']:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaJo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rfCIVTOSgGnBFuiHYNAwUxbEstMadk))
   else:
    return[]
   fp=rfCIVTOSgGnBFuiHYNAwUxbEstMamc(rfCIVTOSgGnBFuiHYNAwUxbEstMaJo,'r',-1,'utf-8')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJP=fp.readlines()
   fp.close()
  except:
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJP=[]
  return rfCIVTOSgGnBFuiHYNAwUxbEstMaJP
 def Save_Watched_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadk,rfCIVTOSgGnBFuiHYNAwUxbEstMalk):
  try:
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJe=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rfCIVTOSgGnBFuiHYNAwUxbEstMadk))
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJk=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.Load_List_File(rfCIVTOSgGnBFuiHYNAwUxbEstMadk) 
   fp=rfCIVTOSgGnBFuiHYNAwUxbEstMamc(rfCIVTOSgGnBFuiHYNAwUxbEstMaJe,'w',-1,'utf-8')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJQ=urllib.parse.urlencode(rfCIVTOSgGnBFuiHYNAwUxbEstMalk)
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJQ=rfCIVTOSgGnBFuiHYNAwUxbEstMaJQ+'\n'
   fp.write(rfCIVTOSgGnBFuiHYNAwUxbEstMaJQ)
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJj=0
   for rfCIVTOSgGnBFuiHYNAwUxbEstMaJc in rfCIVTOSgGnBFuiHYNAwUxbEstMaJk:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaJv=rfCIVTOSgGnBFuiHYNAwUxbEstMamW(urllib.parse.parse_qsl(rfCIVTOSgGnBFuiHYNAwUxbEstMaJc))
    rfCIVTOSgGnBFuiHYNAwUxbEstMazl=rfCIVTOSgGnBFuiHYNAwUxbEstMalk.get('code').strip()
    rfCIVTOSgGnBFuiHYNAwUxbEstMazy=rfCIVTOSgGnBFuiHYNAwUxbEstMaJv.get('code').strip()
    if rfCIVTOSgGnBFuiHYNAwUxbEstMadk=='vod' and rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_direct_replay()==rfCIVTOSgGnBFuiHYNAwUxbEstMamz:
     rfCIVTOSgGnBFuiHYNAwUxbEstMazl=rfCIVTOSgGnBFuiHYNAwUxbEstMalk.get('videoid').strip()
     rfCIVTOSgGnBFuiHYNAwUxbEstMazy=rfCIVTOSgGnBFuiHYNAwUxbEstMaJv.get('videoid').strip()if rfCIVTOSgGnBFuiHYNAwUxbEstMazy!=rfCIVTOSgGnBFuiHYNAwUxbEstMamh else '-'
    if rfCIVTOSgGnBFuiHYNAwUxbEstMazl!=rfCIVTOSgGnBFuiHYNAwUxbEstMazy:
     fp.write(rfCIVTOSgGnBFuiHYNAwUxbEstMaJc)
     rfCIVTOSgGnBFuiHYNAwUxbEstMaJj+=1
     if rfCIVTOSgGnBFuiHYNAwUxbEstMaJj>=50:break
   fp.close()
  except:
   rfCIVTOSgGnBFuiHYNAwUxbEstMamh
 def dp_Watch_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMadk =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('stype')
  rfCIVTOSgGnBFuiHYNAwUxbEstMayL=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_direct_replay()
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadk=='-':
   for rfCIVTOSgGnBFuiHYNAwUxbEstMadv in rfCIVTOSgGnBFuiHYNAwUxbEstMalh:
    rfCIVTOSgGnBFuiHYNAwUxbEstMayk=rfCIVTOSgGnBFuiHYNAwUxbEstMadv.get('title')
    rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':rfCIVTOSgGnBFuiHYNAwUxbEstMadv.get('mode'),'stype':rfCIVTOSgGnBFuiHYNAwUxbEstMadv.get('stype')}
    rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel='',img='',infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
   if rfCIVTOSgGnBFuiHYNAwUxbEstMamp(rfCIVTOSgGnBFuiHYNAwUxbEstMalh)>0:xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle)
  else:
   rfCIVTOSgGnBFuiHYNAwUxbEstMazd=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.Load_List_File(rfCIVTOSgGnBFuiHYNAwUxbEstMadk)
   for rfCIVTOSgGnBFuiHYNAwUxbEstMazX in rfCIVTOSgGnBFuiHYNAwUxbEstMazd:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaJh=rfCIVTOSgGnBFuiHYNAwUxbEstMamW(urllib.parse.parse_qsl(rfCIVTOSgGnBFuiHYNAwUxbEstMazX))
    rfCIVTOSgGnBFuiHYNAwUxbEstMazh =rfCIVTOSgGnBFuiHYNAwUxbEstMaJh.get('code').strip()
    rfCIVTOSgGnBFuiHYNAwUxbEstMayk =rfCIVTOSgGnBFuiHYNAwUxbEstMaJh.get('title').strip()
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXl=rfCIVTOSgGnBFuiHYNAwUxbEstMaJh.get('img').strip()
    rfCIVTOSgGnBFuiHYNAwUxbEstMaho =rfCIVTOSgGnBFuiHYNAwUxbEstMaJh.get('videoid').strip()
    try:
     rfCIVTOSgGnBFuiHYNAwUxbEstMaXl=rfCIVTOSgGnBFuiHYNAwUxbEstMaXl.replace('\'','\"')
     rfCIVTOSgGnBFuiHYNAwUxbEstMaXl=json.loads(rfCIVTOSgGnBFuiHYNAwUxbEstMaXl)
    except:
     rfCIVTOSgGnBFuiHYNAwUxbEstMamh
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={}
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXW['plot']=rfCIVTOSgGnBFuiHYNAwUxbEstMayk
    if rfCIVTOSgGnBFuiHYNAwUxbEstMadk=='vod':
     if rfCIVTOSgGnBFuiHYNAwUxbEstMayL==rfCIVTOSgGnBFuiHYNAwUxbEstMamK or rfCIVTOSgGnBFuiHYNAwUxbEstMaho==rfCIVTOSgGnBFuiHYNAwUxbEstMamh:
      rfCIVTOSgGnBFuiHYNAwUxbEstMaXW['mediatype']='tvshow'
      rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'EPISODE','programcode':rfCIVTOSgGnBFuiHYNAwUxbEstMazh,'page':'1'}
      rfCIVTOSgGnBFuiHYNAwUxbEstMadX=rfCIVTOSgGnBFuiHYNAwUxbEstMamz
     else:
      rfCIVTOSgGnBFuiHYNAwUxbEstMaXW['mediatype']='episode'
      rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'VOD','mediacode':rfCIVTOSgGnBFuiHYNAwUxbEstMaho,'stype':'vod','programcode':rfCIVTOSgGnBFuiHYNAwUxbEstMazh,'title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'thumbnail':rfCIVTOSgGnBFuiHYNAwUxbEstMaXl}
      rfCIVTOSgGnBFuiHYNAwUxbEstMadX=rfCIVTOSgGnBFuiHYNAwUxbEstMamK
    else:
     rfCIVTOSgGnBFuiHYNAwUxbEstMaXW['mediatype']='movie'
     rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'MOVIE','mediacode':rfCIVTOSgGnBFuiHYNAwUxbEstMazh,'stype':'movie','title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'thumbnail':rfCIVTOSgGnBFuiHYNAwUxbEstMaXl}
     rfCIVTOSgGnBFuiHYNAwUxbEstMadX=rfCIVTOSgGnBFuiHYNAwUxbEstMamK
    rfCIVTOSgGnBFuiHYNAwUxbEstMaJK={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':rfCIVTOSgGnBFuiHYNAwUxbEstMazh,'vType':rfCIVTOSgGnBFuiHYNAwUxbEstMadk,}
    rfCIVTOSgGnBFuiHYNAwUxbEstMaJm=urllib.parse.urlencode(rfCIVTOSgGnBFuiHYNAwUxbEstMaJK)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=[('선택된 시청이력 ( %s ) 삭제'%(rfCIVTOSgGnBFuiHYNAwUxbEstMayk),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(rfCIVTOSgGnBFuiHYNAwUxbEstMaJm))]
    rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel='',img=rfCIVTOSgGnBFuiHYNAwUxbEstMaXl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMadX,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady,ContextMenu=rfCIVTOSgGnBFuiHYNAwUxbEstMaXe)
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'plot':'시청목록을 삭제합니다.'}
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':rfCIVTOSgGnBFuiHYNAwUxbEstMadk,}
   rfCIVTOSgGnBFuiHYNAwUxbEstMadl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel='',img=rfCIVTOSgGnBFuiHYNAwUxbEstMadl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamK,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady,isLink=rfCIVTOSgGnBFuiHYNAwUxbEstMamz)
   if rfCIVTOSgGnBFuiHYNAwUxbEstMadk=='movie':xbmcplugin.setContent(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,'movies')
   else:xbmcplugin.setContent(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
 def Save_Searched_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMahe):
  try:
   rfCIVTOSgGnBFuiHYNAwUxbEstMazJ=rfCIVTOSgGnBFuiHYNAwUxbEstMalL
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJk=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.Load_List_File('search') 
   rfCIVTOSgGnBFuiHYNAwUxbEstMazK={'skey':rfCIVTOSgGnBFuiHYNAwUxbEstMahe.strip()}
   fp=rfCIVTOSgGnBFuiHYNAwUxbEstMamc(rfCIVTOSgGnBFuiHYNAwUxbEstMazJ,'w',-1,'utf-8')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJQ=urllib.parse.urlencode(rfCIVTOSgGnBFuiHYNAwUxbEstMazK)
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJQ=rfCIVTOSgGnBFuiHYNAwUxbEstMaJQ+'\n'
   fp.write(rfCIVTOSgGnBFuiHYNAwUxbEstMaJQ)
   rfCIVTOSgGnBFuiHYNAwUxbEstMaJj=0
   for rfCIVTOSgGnBFuiHYNAwUxbEstMaJc in rfCIVTOSgGnBFuiHYNAwUxbEstMaJk:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaJv=rfCIVTOSgGnBFuiHYNAwUxbEstMamW(urllib.parse.parse_qsl(rfCIVTOSgGnBFuiHYNAwUxbEstMaJc))
    rfCIVTOSgGnBFuiHYNAwUxbEstMazl=rfCIVTOSgGnBFuiHYNAwUxbEstMazK.get('skey').strip()
    rfCIVTOSgGnBFuiHYNAwUxbEstMazy=rfCIVTOSgGnBFuiHYNAwUxbEstMaJv.get('skey').strip()
    if rfCIVTOSgGnBFuiHYNAwUxbEstMazl!=rfCIVTOSgGnBFuiHYNAwUxbEstMazy:
     fp.write(rfCIVTOSgGnBFuiHYNAwUxbEstMaJc)
     rfCIVTOSgGnBFuiHYNAwUxbEstMaJj+=1
     if rfCIVTOSgGnBFuiHYNAwUxbEstMaJj>=50:break
   fp.close()
  except:
   rfCIVTOSgGnBFuiHYNAwUxbEstMamh
 def play_VIDEO(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMazm =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('mediacode')
  rfCIVTOSgGnBFuiHYNAwUxbEstMadk =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('stype')
  rfCIVTOSgGnBFuiHYNAwUxbEstMazD =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('pvrmode')
  rfCIVTOSgGnBFuiHYNAwUxbEstMazW=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_selQuality(rfCIVTOSgGnBFuiHYNAwUxbEstMadk)
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(rfCIVTOSgGnBFuiHYNAwUxbEstMazm,rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMazW),rfCIVTOSgGnBFuiHYNAwUxbEstMadk,rfCIVTOSgGnBFuiHYNAwUxbEstMazD))
  rfCIVTOSgGnBFuiHYNAwUxbEstMazL=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.GetBroadURL(rfCIVTOSgGnBFuiHYNAwUxbEstMazm,rfCIVTOSgGnBFuiHYNAwUxbEstMazW,rfCIVTOSgGnBFuiHYNAwUxbEstMadk,rfCIVTOSgGnBFuiHYNAwUxbEstMazD,optUHD=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_uhd())
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.addon_log('qt, stype, url : %s - %s - %s'%(rfCIVTOSgGnBFuiHYNAwUxbEstMamo(rfCIVTOSgGnBFuiHYNAwUxbEstMazW),rfCIVTOSgGnBFuiHYNAwUxbEstMadk,rfCIVTOSgGnBFuiHYNAwUxbEstMazL['streaming_url']))
  if rfCIVTOSgGnBFuiHYNAwUxbEstMazL['streaming_url']=='':
   if rfCIVTOSgGnBFuiHYNAwUxbEstMazL['error_msg']=='':
    rfCIVTOSgGnBFuiHYNAwUxbEstMalR.addon_noti(__language__(30908).encode('utf8'))
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMalR.addon_noti(rfCIVTOSgGnBFuiHYNAwUxbEstMazL['error_msg'].encode('utf8'))
   return
  rfCIVTOSgGnBFuiHYNAwUxbEstMazR={'user-agent':rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.USER_AGENT}
  rfCIVTOSgGnBFuiHYNAwUxbEstMazp=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.makeDefaultCookies() 
  if rfCIVTOSgGnBFuiHYNAwUxbEstMazL['watermark'] !='':
   rfCIVTOSgGnBFuiHYNAwUxbEstMazR['x-tving-param1']=rfCIVTOSgGnBFuiHYNAwUxbEstMazL['watermarkKey']
   rfCIVTOSgGnBFuiHYNAwUxbEstMazR['x-tving-param2']=rfCIVTOSgGnBFuiHYNAwUxbEstMazL['watermark'] 
  if rfCIVTOSgGnBFuiHYNAwUxbEstMazL['drm_server_url'] !='':
   rfCIVTOSgGnBFuiHYNAwUxbEstMazR[rfCIVTOSgGnBFuiHYNAwUxbEstMazL['drm_header_key']]=rfCIVTOSgGnBFuiHYNAwUxbEstMazL['drm_header_value']
  rfCIVTOSgGnBFuiHYNAwUxbEstMazo =rfCIVTOSgGnBFuiHYNAwUxbEstMamK
  rfCIVTOSgGnBFuiHYNAwUxbEstMazk =rfCIVTOSgGnBFuiHYNAwUxbEstMazL['streaming_url'].find('Policy=')
  if rfCIVTOSgGnBFuiHYNAwUxbEstMazk!=-1:
   rfCIVTOSgGnBFuiHYNAwUxbEstMazc =rfCIVTOSgGnBFuiHYNAwUxbEstMazL['streaming_url'].split('?')[0]
   rfCIVTOSgGnBFuiHYNAwUxbEstMazv=rfCIVTOSgGnBFuiHYNAwUxbEstMamW(urllib.parse.parse_qsl(urllib.parse.urlsplit(rfCIVTOSgGnBFuiHYNAwUxbEstMazL['streaming_url']).query))
   rfCIVTOSgGnBFuiHYNAwUxbEstMazp['CloudFront-Policy'] =rfCIVTOSgGnBFuiHYNAwUxbEstMazv['Policy'] 
   rfCIVTOSgGnBFuiHYNAwUxbEstMazp['CloudFront-Signature'] =rfCIVTOSgGnBFuiHYNAwUxbEstMazv['Signature'] 
   rfCIVTOSgGnBFuiHYNAwUxbEstMazp['CloudFront-Key-Pair-Id']=rfCIVTOSgGnBFuiHYNAwUxbEstMazv['Key-Pair-Id'] 
   rfCIVTOSgGnBFuiHYNAwUxbEstMazq=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.make_stream_header(rfCIVTOSgGnBFuiHYNAwUxbEstMazR,rfCIVTOSgGnBFuiHYNAwUxbEstMazp)
   if 'quickvod-mcdn.tving.com' in rfCIVTOSgGnBFuiHYNAwUxbEstMazc:
    rfCIVTOSgGnBFuiHYNAwUxbEstMazo=rfCIVTOSgGnBFuiHYNAwUxbEstMamz
    rfCIVTOSgGnBFuiHYNAwUxbEstMazP =rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaze=rfCIVTOSgGnBFuiHYNAwUxbEstMazP.strftime('%Y-%m-%d-%H:%M:%S')
    if rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(rfCIVTOSgGnBFuiHYNAwUxbEstMaze.replace('-','').replace(':',''))<rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(rfCIVTOSgGnBFuiHYNAwUxbEstMazv['end'].replace('-','').replace(':','')):
     rfCIVTOSgGnBFuiHYNAwUxbEstMazv['end']=rfCIVTOSgGnBFuiHYNAwUxbEstMaze
     rfCIVTOSgGnBFuiHYNAwUxbEstMalR.addon_noti(__language__(30915).encode('utf8'))
    rfCIVTOSgGnBFuiHYNAwUxbEstMazc ='%s?%s'%(rfCIVTOSgGnBFuiHYNAwUxbEstMazc,urllib.parse.urlencode(rfCIVTOSgGnBFuiHYNAwUxbEstMazv,doseq=rfCIVTOSgGnBFuiHYNAwUxbEstMamz))
    rfCIVTOSgGnBFuiHYNAwUxbEstMazQ='{}|{}'.format(rfCIVTOSgGnBFuiHYNAwUxbEstMazc,rfCIVTOSgGnBFuiHYNAwUxbEstMazq)
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMazQ='{}|{}'.format(rfCIVTOSgGnBFuiHYNAwUxbEstMazL['streaming_url'],rfCIVTOSgGnBFuiHYNAwUxbEstMazq)
  else:
   rfCIVTOSgGnBFuiHYNAwUxbEstMazq=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.make_stream_header(rfCIVTOSgGnBFuiHYNAwUxbEstMazR,rfCIVTOSgGnBFuiHYNAwUxbEstMazp)
   rfCIVTOSgGnBFuiHYNAwUxbEstMazQ='{}|{}'.format(rfCIVTOSgGnBFuiHYNAwUxbEstMazL['streaming_url'],rfCIVTOSgGnBFuiHYNAwUxbEstMazq)
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.addon_log('if tmp_pos == -1')
  rfCIVTOSgGnBFuiHYNAwUxbEstMayh,rfCIVTOSgGnBFuiHYNAwUxbEstMayJ=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_proxyport()
  rfCIVTOSgGnBFuiHYNAwUxbEstMayX=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_playback()
  if(rfCIVTOSgGnBFuiHYNAwUxbEstMayh and rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('mode')in['VOD','MOVIE']and rfCIVTOSgGnBFuiHYNAwUxbEstMazo==rfCIVTOSgGnBFuiHYNAwUxbEstMamK and(rfCIVTOSgGnBFuiHYNAwUxbEstMazL['drm_server_url']!='' or(rfCIVTOSgGnBFuiHYNAwUxbEstMazL['url_filename'].split('.')[1]=='mpd')or(rfCIVTOSgGnBFuiHYNAwUxbEstMazL['url_filename'].split('.')[1]!='mpd' and rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.KodiVersion>=21 and rfCIVTOSgGnBFuiHYNAwUxbEstMazL['qt_stream']=='stream70'))):
   if rfCIVTOSgGnBFuiHYNAwUxbEstMazL['url_filename'].split('.')[1]=='mpd':
    rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Tving_Parse_mpd(rfCIVTOSgGnBFuiHYNAwUxbEstMazL['streaming_url'],rfCIVTOSgGnBFuiHYNAwUxbEstMazL['watermarkKey'],rfCIVTOSgGnBFuiHYNAwUxbEstMazL['watermark'])
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Tving_Parse_m3u8(rfCIVTOSgGnBFuiHYNAwUxbEstMazL['streaming_url'])
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.addon_log('xxx '+rfCIVTOSgGnBFuiHYNAwUxbEstMazL['streaming_url'])
   rfCIVTOSgGnBFuiHYNAwUxbEstMazj={'addon':'tvingm','playOption':rfCIVTOSgGnBFuiHYNAwUxbEstMayX,'url_filename':rfCIVTOSgGnBFuiHYNAwUxbEstMazL['url_filename'],}
   rfCIVTOSgGnBFuiHYNAwUxbEstMazj=json.dumps(rfCIVTOSgGnBFuiHYNAwUxbEstMazj,separators=(',',':'))
   rfCIVTOSgGnBFuiHYNAwUxbEstMazj=base64.standard_b64encode(rfCIVTOSgGnBFuiHYNAwUxbEstMazj.encode()).decode('utf-8')
   rfCIVTOSgGnBFuiHYNAwUxbEstMazQ ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(rfCIVTOSgGnBFuiHYNAwUxbEstMayJ,rfCIVTOSgGnBFuiHYNAwUxbEstMazQ,rfCIVTOSgGnBFuiHYNAwUxbEstMazj)
   rfCIVTOSgGnBFuiHYNAwUxbEstMazR['proxy-mini']=rfCIVTOSgGnBFuiHYNAwUxbEstMazj 
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.addon_log('surl(2) : {}'.format(rfCIVTOSgGnBFuiHYNAwUxbEstMazQ))
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.addon_log('drm     : {}'.format(rfCIVTOSgGnBFuiHYNAwUxbEstMazL['drm_server_url']))
  rfCIVTOSgGnBFuiHYNAwUxbEstMazq=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.make_stream_header(rfCIVTOSgGnBFuiHYNAwUxbEstMazR,rfCIVTOSgGnBFuiHYNAwUxbEstMazp)
  rfCIVTOSgGnBFuiHYNAwUxbEstMaKl=xbmcgui.ListItem(path=rfCIVTOSgGnBFuiHYNAwUxbEstMazQ)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMazL['drm_server_url']!='':
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKy=rfCIVTOSgGnBFuiHYNAwUxbEstMazL['drm_server_url']
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKd ='https://license-global.pallycon.com/ri/licenseManager.do' 
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKX ='mpd'
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKh ='com.widevine.alpha'
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKz={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.USER_AGENT,rfCIVTOSgGnBFuiHYNAwUxbEstMazL['drm_header_key']:rfCIVTOSgGnBFuiHYNAwUxbEstMazL['drm_header_value'],}
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKm=rfCIVTOSgGnBFuiHYNAwUxbEstMaKd+'|'+urllib.parse.urlencode(rfCIVTOSgGnBFuiHYNAwUxbEstMaKz)+'|R{SSM}|'
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream','inputstream.adaptive')
   if rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.KodiVersion<=20:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream.adaptive.manifest_type',rfCIVTOSgGnBFuiHYNAwUxbEstMaKX)
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream.adaptive.license_type',rfCIVTOSgGnBFuiHYNAwUxbEstMaKh)
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream.adaptive.license_key',rfCIVTOSgGnBFuiHYNAwUxbEstMaKm)
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream.adaptive.stream_headers',rfCIVTOSgGnBFuiHYNAwUxbEstMazq)
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream.adaptive.manifest_headers',rfCIVTOSgGnBFuiHYNAwUxbEstMazq)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('mode')in['VOD','MOVIE']:
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setContentLookup(rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setMimeType('application/x-mpegURL')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream','inputstream.adaptive')
   if rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.KodiVersion<=20:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream.adaptive.manifest_type','hls')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream.adaptive.stream_headers',rfCIVTOSgGnBFuiHYNAwUxbEstMazq)
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream.adaptive.manifest_headers',rfCIVTOSgGnBFuiHYNAwUxbEstMazq)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMazo==rfCIVTOSgGnBFuiHYNAwUxbEstMamz:
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setContentLookup(rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setMimeType('application/x-mpegURL')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream','inputstream.ffmpegdirect')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('ResumeTime','0')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKl.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,rfCIVTOSgGnBFuiHYNAwUxbEstMamz,rfCIVTOSgGnBFuiHYNAwUxbEstMaKl)
  try:
   if rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('mode')in['VOD','MOVIE']and rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('title'):
    rfCIVTOSgGnBFuiHYNAwUxbEstMady={'code':rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('programcode')if rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('mode')=='VOD' else rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('mediacode'),'img':rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('thumbnail'),'title':rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('title'),'videoid':rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('mediacode')}
    rfCIVTOSgGnBFuiHYNAwUxbEstMalR.Save_Watched_List(rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('stype'),rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  except:
   rfCIVTOSgGnBFuiHYNAwUxbEstMamh
 def logout(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  rfCIVTOSgGnBFuiHYNAwUxbEstMalv=xbmcgui.Dialog()
  rfCIVTOSgGnBFuiHYNAwUxbEstMadL=rfCIVTOSgGnBFuiHYNAwUxbEstMalv.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if rfCIVTOSgGnBFuiHYNAwUxbEstMadL==rfCIVTOSgGnBFuiHYNAwUxbEstMamK:sys.exit()
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Init_TV_Total()
  if os.path.isfile(rfCIVTOSgGnBFuiHYNAwUxbEstMalW):os.remove(rfCIVTOSgGnBFuiHYNAwUxbEstMalW)
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  rfCIVTOSgGnBFuiHYNAwUxbEstMaKD =rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Get_Now_Datetime()
  rfCIVTOSgGnBFuiHYNAwUxbEstMaKW=rfCIVTOSgGnBFuiHYNAwUxbEstMaKD+datetime.timedelta(days=30) 
  (rfCIVTOSgGnBFuiHYNAwUxbEstMadK,rfCIVTOSgGnBFuiHYNAwUxbEstMadm,rfCIVTOSgGnBFuiHYNAwUxbEstMadD,rfCIVTOSgGnBFuiHYNAwUxbEstMadW)=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_account()
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Save_session_acount(rfCIVTOSgGnBFuiHYNAwUxbEstMadK,rfCIVTOSgGnBFuiHYNAwUxbEstMadm,rfCIVTOSgGnBFuiHYNAwUxbEstMadD,rfCIVTOSgGnBFuiHYNAwUxbEstMadW)
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.TV['account']['token_limit']=rfCIVTOSgGnBFuiHYNAwUxbEstMaKW.strftime('%Y%m%d')
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.JsonFile_Save(rfCIVTOSgGnBFuiHYNAwUxbEstMalW,rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.TV)
 def cookiefile_check(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.TV=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.JsonFile_Load(rfCIVTOSgGnBFuiHYNAwUxbEstMalW)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.TV=={}:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Init_TV_Total()
   return rfCIVTOSgGnBFuiHYNAwUxbEstMamK
  (rfCIVTOSgGnBFuiHYNAwUxbEstMaKL,rfCIVTOSgGnBFuiHYNAwUxbEstMaKR,rfCIVTOSgGnBFuiHYNAwUxbEstMaKp,rfCIVTOSgGnBFuiHYNAwUxbEstMaKo)=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_account()
  (rfCIVTOSgGnBFuiHYNAwUxbEstMaKk,rfCIVTOSgGnBFuiHYNAwUxbEstMaKc,rfCIVTOSgGnBFuiHYNAwUxbEstMaKv,rfCIVTOSgGnBFuiHYNAwUxbEstMaKq)=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Load_session_acount()
  if(rfCIVTOSgGnBFuiHYNAwUxbEstMaKL!=rfCIVTOSgGnBFuiHYNAwUxbEstMaKk or rfCIVTOSgGnBFuiHYNAwUxbEstMaKR!=rfCIVTOSgGnBFuiHYNAwUxbEstMaKc or rfCIVTOSgGnBFuiHYNAwUxbEstMaKp!=rfCIVTOSgGnBFuiHYNAwUxbEstMaKv or rfCIVTOSgGnBFuiHYNAwUxbEstMaKo!=rfCIVTOSgGnBFuiHYNAwUxbEstMaKq)and rfCIVTOSgGnBFuiHYNAwUxbEstMaKk!='xxxxx':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Init_TV_Total()
   return rfCIVTOSgGnBFuiHYNAwUxbEstMamK
  if rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.TV['account']['token_limit']):
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Init_TV_Total()
   return rfCIVTOSgGnBFuiHYNAwUxbEstMamK
  return rfCIVTOSgGnBFuiHYNAwUxbEstMamz
 def dp_Global_Search(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('mode')
  if rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='TOTAL_SEARCH':
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKP='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKP='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(rfCIVTOSgGnBFuiHYNAwUxbEstMaKP)
 def dp_Bookmark_Menu(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMaKP='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(rfCIVTOSgGnBFuiHYNAwUxbEstMaKP)
 def dp_EuroLive_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMade=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.GetEuroChannelList()
  for rfCIVTOSgGnBFuiHYNAwUxbEstMadj in rfCIVTOSgGnBFuiHYNAwUxbEstMade:
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXc =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('channel')
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXL =rfCIVTOSgGnBFuiHYNAwUxbEstMadj.get('subtitle')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'mediatype':'episode','title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'plot':'%s\n%s'%(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,rfCIVTOSgGnBFuiHYNAwUxbEstMaXL)}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'LIVE','mediacode':rfCIVTOSgGnBFuiHYNAwUxbEstMaXc,'stype':'onair',}
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMaXL,img='',infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamK,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMamp(rfCIVTOSgGnBFuiHYNAwUxbEstMade)>0:xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
 def dp_Apple_Group(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMaKe=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Get_AppleGroup_List()
  for rfCIVTOSgGnBFuiHYNAwUxbEstMaKQ in rfCIVTOSgGnBFuiHYNAwUxbEstMaKe:
   rfCIVTOSgGnBFuiHYNAwUxbEstMaKj =rfCIVTOSgGnBFuiHYNAwUxbEstMaKQ.get('bandName')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaml =rfCIVTOSgGnBFuiHYNAwUxbEstMaKQ.get('bandKey')
   rfCIVTOSgGnBFuiHYNAwUxbEstMamy =rfCIVTOSgGnBFuiHYNAwUxbEstMaKQ.get('moreUrl')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'mediatype':'tvshow','title':rfCIVTOSgGnBFuiHYNAwUxbEstMaKj,'plot':'%s'%(rfCIVTOSgGnBFuiHYNAwUxbEstMaml),}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'BAND_VODLIST','bandKey':rfCIVTOSgGnBFuiHYNAwUxbEstMaml,'moreUrl':rfCIVTOSgGnBFuiHYNAwUxbEstMamy,}
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMaKj,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMamh,img='',infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMamp(rfCIVTOSgGnBFuiHYNAwUxbEstMaKe)>0:xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
 def dp_Band_VodList(rfCIVTOSgGnBFuiHYNAwUxbEstMalR,rfCIVTOSgGnBFuiHYNAwUxbEstMadq):
  rfCIVTOSgGnBFuiHYNAwUxbEstMaml =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('bandKey')
  rfCIVTOSgGnBFuiHYNAwUxbEstMamy =rfCIVTOSgGnBFuiHYNAwUxbEstMadq.get('moreUrl')
  rfCIVTOSgGnBFuiHYNAwUxbEstMamd ='Apple TV+'
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.addon_log('bandCode : '+rfCIVTOSgGnBFuiHYNAwUxbEstMaml)
  rfCIVTOSgGnBFuiHYNAwUxbEstMaXo=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.Get_Band_VodList(rfCIVTOSgGnBFuiHYNAwUxbEstMaml,rfCIVTOSgGnBFuiHYNAwUxbEstMamy)
  for rfCIVTOSgGnBFuiHYNAwUxbEstMaXk in rfCIVTOSgGnBFuiHYNAwUxbEstMaXo:
   rfCIVTOSgGnBFuiHYNAwUxbEstMayk =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('title')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXl =rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('thumbnail')
   rfCIVTOSgGnBFuiHYNAwUxbEstMaXW={'mediatype':'tvshow','title':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'plot':rfCIVTOSgGnBFuiHYNAwUxbEstMayk}
   rfCIVTOSgGnBFuiHYNAwUxbEstMady={'mode':'EPISODE','programcode':rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('program'),'page':'1'}
   if rfCIVTOSgGnBFuiHYNAwUxbEstMalR.get_settings_makebookmark():
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXv={'videoid':rfCIVTOSgGnBFuiHYNAwUxbEstMaXk.get('program'),'vidtype':'tvshow','vtitle':rfCIVTOSgGnBFuiHYNAwUxbEstMayk,'vsubtitle':rfCIVTOSgGnBFuiHYNAwUxbEstMamd,}
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXq=json.dumps(rfCIVTOSgGnBFuiHYNAwUxbEstMaXv)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXq=urllib.parse.quote(rfCIVTOSgGnBFuiHYNAwUxbEstMaXq)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXP='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(rfCIVTOSgGnBFuiHYNAwUxbEstMaXq)
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=[('(통합) 찜 영상에 추가',rfCIVTOSgGnBFuiHYNAwUxbEstMaXP)]
   else:
    rfCIVTOSgGnBFuiHYNAwUxbEstMaXe=rfCIVTOSgGnBFuiHYNAwUxbEstMamh
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.add_dir(rfCIVTOSgGnBFuiHYNAwUxbEstMayk,sublabel=rfCIVTOSgGnBFuiHYNAwUxbEstMamd,img=rfCIVTOSgGnBFuiHYNAwUxbEstMaXl,infoLabels=rfCIVTOSgGnBFuiHYNAwUxbEstMaXW,isFolder=rfCIVTOSgGnBFuiHYNAwUxbEstMamz,params=rfCIVTOSgGnBFuiHYNAwUxbEstMady,ContextMenu=rfCIVTOSgGnBFuiHYNAwUxbEstMaXe)
  xbmcplugin.setContent(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(rfCIVTOSgGnBFuiHYNAwUxbEstMalR._addon_handle,cacheToDisc=rfCIVTOSgGnBFuiHYNAwUxbEstMamK)
 def tving_main(rfCIVTOSgGnBFuiHYNAwUxbEstMalR):
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.TvingObj.KodiVersion=rfCIVTOSgGnBFuiHYNAwUxbEstMamJ(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params.get('mode',rfCIVTOSgGnBFuiHYNAwUxbEstMamh)
  if rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='LOGOUT':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.logout()
   return
  rfCIVTOSgGnBFuiHYNAwUxbEstMalR.login_main()
  if rfCIVTOSgGnBFuiHYNAwUxbEstMahQ is rfCIVTOSgGnBFuiHYNAwUxbEstMamh:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Main_List()
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Title_Group(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ in['GLOBAL_GROUP']:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_SubTitle_Group(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='CHANNEL':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_LiveChannel_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ in['LIVE','VOD','MOVIE']:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.play_VIDEO(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='PROGRAM':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Program_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='4K_PROGRAM':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_4K_Program_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='ORI_PROGRAM':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Ori_Program_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='EPISODE':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Episode_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='MOVIE_SUB':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Movie_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='4K_MOVIE':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_4K_Movie_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='SEARCH_GROUP':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Search_Group(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ in['SEARCH','LOCAL_SEARCH']:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Search_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='WATCH':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Watch_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_History_Remove(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='ORDER_BY':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_setEpOrderby(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='SET_BOOKMARK':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Set_Bookmark(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ in['TOTAL_SEARCH','TOTAL_HISTORY']:
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Global_Search(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='SEARCH_HISTORY':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Search_History(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='MENU_BOOKMARK':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Bookmark_Menu(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='EURO_GROUP':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_EuroLive_List(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='APPLE_GROUP':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Apple_Group(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  elif rfCIVTOSgGnBFuiHYNAwUxbEstMahQ=='BAND_VODLIST':
   rfCIVTOSgGnBFuiHYNAwUxbEstMalR.dp_Band_VodList(rfCIVTOSgGnBFuiHYNAwUxbEstMalR.main_params)
  else:
   rfCIVTOSgGnBFuiHYNAwUxbEstMamh
# Created by pyminifier (https://github.com/liftoff/pyminifier)
