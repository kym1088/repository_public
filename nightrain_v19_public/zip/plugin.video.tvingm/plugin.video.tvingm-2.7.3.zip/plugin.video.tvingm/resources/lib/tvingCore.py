__author__="NightRain"
qoYgUbjfruFzMaQnlhpiGPwNOkDIcB=print
qoYgUbjfruFzMaQnlhpiGPwNOkDIXd=ImportError
qoYgUbjfruFzMaQnlhpiGPwNOkDIXy=object
qoYgUbjfruFzMaQnlhpiGPwNOkDIXC=None
qoYgUbjfruFzMaQnlhpiGPwNOkDIXm=False
qoYgUbjfruFzMaQnlhpiGPwNOkDIXV=str
qoYgUbjfruFzMaQnlhpiGPwNOkDIXK=open
qoYgUbjfruFzMaQnlhpiGPwNOkDIXA=True
qoYgUbjfruFzMaQnlhpiGPwNOkDIXc=len
qoYgUbjfruFzMaQnlhpiGPwNOkDIXT=int
qoYgUbjfruFzMaQnlhpiGPwNOkDIXs=range
qoYgUbjfruFzMaQnlhpiGPwNOkDIXJ=bytes
qoYgUbjfruFzMaQnlhpiGPwNOkDIXx=Exception
qoYgUbjfruFzMaQnlhpiGPwNOkDIXt=dict
qoYgUbjfruFzMaQnlhpiGPwNOkDIXR=list
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 qoYgUbjfruFzMaQnlhpiGPwNOkDIcB('Cryptodome')
except qoYgUbjfruFzMaQnlhpiGPwNOkDIXd:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 qoYgUbjfruFzMaQnlhpiGPwNOkDIcB('Crypto')
qoYgUbjfruFzMaQnlhpiGPwNOkDIdC={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
qoYgUbjfruFzMaQnlhpiGPwNOkDIdm ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
qoYgUbjfruFzMaQnlhpiGPwNOkDIdV =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
qoYgUbjfruFzMaQnlhpiGPwNOkDIdK=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class qoYgUbjfruFzMaQnlhpiGPwNOkDIdy(qoYgUbjfruFzMaQnlhpiGPwNOkDIXy):
 def __init__(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.NETWORKCODE ='CSND0900'
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.OSCODE ='CSOD0900' 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TELECODE ='CSCD0900'
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.SCREENCODE ='CSSD0100'
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.APIKEY_ATV ='b6ac9e6384d93d6e533b144b3ef22c42' 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.SCREENCODE_ATV ='CSSD1300' 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.LIVE_LIMIT =20 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.VOD_LIMIT =24 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.EPISODE_LIMIT =30 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.SEARCH_LIMIT =30 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.MOVIE_LIMIT =24 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN ='https://api.tving.com'
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN ='https://image.tving.com'
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.SEARCH_DOMAIN ='https://search-api.tving.com'
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.LOGIN_DOMAIN ='https://user.tving.com'
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.URL_DOMAIN ='https://www.tving.com'
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.MOVIE_LITE =['2610061','2610161','261062']
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36'
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.MODEL ='windows_chrome_135.0.0.0' 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.USER_AGENT_ATV ='Mozilla/5.0 (Linux; Android 9; A95X_F3_Air Build/A95X_F3_AIR_M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36'
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.DEFAULT_HEADER ={'user-agent':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.USER_AGENT}
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.COOKIE_FILE_NAME =''
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV_SESSION_COOKIES1=''
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV_SESSION_COOKIES2=''
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV_STREAM_FILENAME =''
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV_SESSION_TEXT1 =''
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV_SESSION_TEXT2 =''
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.KodiVersion=20
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV ={}
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Init_TV_Total()
 def Init_TV_Total(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV={'account':{},'cookies':{},}
 def callRequestCookies(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,jobtype,qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,json=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,redirects=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdc=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.DEFAULT_HEADER
  if headers:qoYgUbjfruFzMaQnlhpiGPwNOkDIdc.update(headers)
  if jobtype=='Get':
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdX=requests.get(qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,params=params,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIdc,cookies=cookies,allow_redirects=redirects)
  else:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdX=requests.post(qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,data=payload,json=json,params=params,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIdc,cookies=cookies,allow_redirects=redirects)
  qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdX.status_code)+' - '+qoYgUbjfruFzMaQnlhpiGPwNOkDIdX.url)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIdX
 def JsonFile_Save(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,filename,qoYgUbjfruFzMaQnlhpiGPwNOkDIdT):
  if filename=='':return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  try:
   fp=qoYgUbjfruFzMaQnlhpiGPwNOkDIXK(filename,'w',-1,'utf-8')
   json.dump(qoYgUbjfruFzMaQnlhpiGPwNOkDIdT,fp,indent=4,ensure_ascii=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm)
   fp.close()
  except:
   return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
 def JsonFile_Load(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,filename):
  if filename=='':return{}
  try:
   fp=qoYgUbjfruFzMaQnlhpiGPwNOkDIXK(filename,'r',-1,'utf-8')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdJ=json.load(fp)
   fp.close()
  except:
   return{}
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIdJ
 def TextFile_Save(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,filename,resText):
  if filename=='':return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  try:
   fp=qoYgUbjfruFzMaQnlhpiGPwNOkDIXK(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
 def Save_session_acount(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,qoYgUbjfruFzMaQnlhpiGPwNOkDIdx,qoYgUbjfruFzMaQnlhpiGPwNOkDIdt,qoYgUbjfruFzMaQnlhpiGPwNOkDIdR,qoYgUbjfruFzMaQnlhpiGPwNOkDIdL):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['account']['tvid'] =base64.standard_b64encode(qoYgUbjfruFzMaQnlhpiGPwNOkDIdx.encode()).decode('utf-8')
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['account']['tvpw'] =base64.standard_b64encode(qoYgUbjfruFzMaQnlhpiGPwNOkDIdt.encode()).decode('utf-8')
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['account']['tvtype']=qoYgUbjfruFzMaQnlhpiGPwNOkDIdR 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['account']['tvpf'] =qoYgUbjfruFzMaQnlhpiGPwNOkDIdL 
 def Load_session_acount(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA):
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdx =base64.standard_b64decode(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['account']['tvid']).decode('utf-8')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdt =base64.standard_b64decode(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['account']['tvpw']).decode('utf-8')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdR=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['account']['tvtype']
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdL =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIdx,qoYgUbjfruFzMaQnlhpiGPwNOkDIdt,qoYgUbjfruFzMaQnlhpiGPwNOkDIdR,qoYgUbjfruFzMaQnlhpiGPwNOkDIdL
 def make_stream_header(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,qoYgUbjfruFzMaQnlhpiGPwNOkDIde,qoYgUbjfruFzMaQnlhpiGPwNOkDIdB):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdH=''
  if qoYgUbjfruFzMaQnlhpiGPwNOkDIdB not in[{},qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,'']:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdS=qoYgUbjfruFzMaQnlhpiGPwNOkDIXc(qoYgUbjfruFzMaQnlhpiGPwNOkDIdB)
   for qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIdW in qoYgUbjfruFzMaQnlhpiGPwNOkDIdB.items():
    qoYgUbjfruFzMaQnlhpiGPwNOkDIdH+='{}={}'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIdW)
    qoYgUbjfruFzMaQnlhpiGPwNOkDIdS+=-1
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIdS>0:qoYgUbjfruFzMaQnlhpiGPwNOkDIdH+='; '
   qoYgUbjfruFzMaQnlhpiGPwNOkDIde['cookie']=qoYgUbjfruFzMaQnlhpiGPwNOkDIdH
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdv=''
  i=0
  for qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIdW in qoYgUbjfruFzMaQnlhpiGPwNOkDIde.items():
   i=i+1
   if i>1:qoYgUbjfruFzMaQnlhpiGPwNOkDIdv+='&'
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdv+='{}={}'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,urllib.parse.quote(qoYgUbjfruFzMaQnlhpiGPwNOkDIdW))
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIdv
 def makeDefaultCookies(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdB={}
  for qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIdW in qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies'].items():
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdB[qoYgUbjfruFzMaQnlhpiGPwNOkDIdE]=qoYgUbjfruFzMaQnlhpiGPwNOkDIdW
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIdB
 def getDeviceStr(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyd=[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyd.append('Windows') 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyd.append('Chrome') 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyd.append('ko-KR') 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyd.append('undefined') 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyd.append('24') 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyd.append(u'한국 표준시')
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyd.append('undefined') 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyd.append('undefined') 
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyd.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyC=''
  for qoYgUbjfruFzMaQnlhpiGPwNOkDIym in qoYgUbjfruFzMaQnlhpiGPwNOkDIyd:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyC+=qoYgUbjfruFzMaQnlhpiGPwNOkDIym+'|'
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIyC
 def GetDefaultParams(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,uhd=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm):
  if uhd==qoYgUbjfruFzMaQnlhpiGPwNOkDIXm:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyV={'apiKey':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.APIKEY,'networkCode':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.NETWORKCODE,'osCode':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.OSCODE,'teleCode':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TELECODE,'screenCode':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.SCREENCODE,}
  else:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyV={'apiKey':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.APIKEY_ATV,'networkCode':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.NETWORKCODE,'osCode':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.OSCODE,'teleCode':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TELECODE,'screenCode':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.SCREENCODE_ATV,}
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIyV
 def GetNoCache(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,timetype=1):
  if timetype==1:
   return qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(time.time())
  else:
   return qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(time.time()*1000)
 def GetUniqueid(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,hValue=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC):
  if hValue:
   import hashlib
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyK=hashlib.sha1()
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyK.update(hValue.encode())
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyA=qoYgUbjfruFzMaQnlhpiGPwNOkDIyK.hexdigest()[:8]
  else:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyc=[0 for i in qoYgUbjfruFzMaQnlhpiGPwNOkDIXs(256)]
   for i in qoYgUbjfruFzMaQnlhpiGPwNOkDIXs(256):
    qoYgUbjfruFzMaQnlhpiGPwNOkDIyc[i]='%02x'%(i)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyX=qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(4294967295*random.random())|0
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyA=qoYgUbjfruFzMaQnlhpiGPwNOkDIyc[255&qoYgUbjfruFzMaQnlhpiGPwNOkDIyX]+qoYgUbjfruFzMaQnlhpiGPwNOkDIyc[qoYgUbjfruFzMaQnlhpiGPwNOkDIyX>>8&255]+qoYgUbjfruFzMaQnlhpiGPwNOkDIyc[qoYgUbjfruFzMaQnlhpiGPwNOkDIyX>>16&255]+qoYgUbjfruFzMaQnlhpiGPwNOkDIyc[qoYgUbjfruFzMaQnlhpiGPwNOkDIyX>>24&255]
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIyA
 def Web_DecryptKey(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyT=qoYgUbjfruFzMaQnlhpiGPwNOkDIXJ('kss2lym0kdw1lks3','utf-8')
  qoYgUbjfruFzMaQnlhpiGPwNOkDIys=qoYgUbjfruFzMaQnlhpiGPwNOkDIXJ('6yhlJ4WF9ZIj6I8n','utf-8')
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIyT,qoYgUbjfruFzMaQnlhpiGPwNOkDIys
 def Web_EncryptCiphertext(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,qoYgUbjfruFzMaQnlhpiGPwNOkDIyL):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyJ,qoYgUbjfruFzMaQnlhpiGPwNOkDIyx=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Web_DecryptKey()
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyt=AES.new(qoYgUbjfruFzMaQnlhpiGPwNOkDIyJ,AES.MODE_CBC,qoYgUbjfruFzMaQnlhpiGPwNOkDIyx,)
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyR=qoYgUbjfruFzMaQnlhpiGPwNOkDIyt.encrypt(Padding.pad(qoYgUbjfruFzMaQnlhpiGPwNOkDIyL.encode('utf-8'),16))
  return base64.standard_b64encode(qoYgUbjfruFzMaQnlhpiGPwNOkDIyR).decode('utf-8')
 def Web_DecryptPlaintext(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,qoYgUbjfruFzMaQnlhpiGPwNOkDIyR):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyJ,qoYgUbjfruFzMaQnlhpiGPwNOkDIyx=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Web_DecryptKey()
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyt=AES.new(qoYgUbjfruFzMaQnlhpiGPwNOkDIyJ,AES.MODE_CBC,qoYgUbjfruFzMaQnlhpiGPwNOkDIyx,)
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyL=Padding.unpad(qoYgUbjfruFzMaQnlhpiGPwNOkDIyt.decrypt(base64.standard_b64decode(qoYgUbjfruFzMaQnlhpiGPwNOkDIyR)),16)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIyL.decode('utf-8')
 def WebCookies_Load(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,wc_file):
  try:
   fp=qoYgUbjfruFzMaQnlhpiGPwNOkDIXK(wc_file,'r',-1,'utf-8')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyH=fp.read()
   fp.close()
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyS=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Web_DecryptPlaintext(qoYgUbjfruFzMaQnlhpiGPwNOkDIyH)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyS)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyE =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDeviceList()
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIyE not in['','-']:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies']['tving_uuid']=qoYgUbjfruFzMaQnlhpiGPwNOkDIyE+'-'+qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetUniqueid(qoYgUbjfruFzMaQnlhpiGPwNOkDIyE)
  except:
   return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
 def GetCredential2(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,user_id,user_pw,login_type,user_pf):
  try:
   if base64.standard_b64encode(user_id.encode()).decode('utf-8')=='a3ltOTUxMDg4':
    qoYgUbjfruFzMaQnlhpiGPwNOkDIyW='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx'
   else:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIyW='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx'
   qoYgUbjfruFzMaQnlhpiGPwNOkDIye={'addon':'tvingm','method':'LOGIN','data':{'type':login_type,'id':user_id,'pw':user_pw,'pf':user_pf,}}
   qoYgUbjfruFzMaQnlhpiGPwNOkDIye=json.dumps(qoYgUbjfruFzMaQnlhpiGPwNOkDIye,separators=(',',':'))
   qoYgUbjfruFzMaQnlhpiGPwNOkDIye=base64.standard_b64encode(qoYgUbjfruFzMaQnlhpiGPwNOkDIye.encode()).decode('utf-8')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIde={'proxy-mini':qoYgUbjfruFzMaQnlhpiGPwNOkDIye}
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=requests.get(base64.standard_b64decode(qoYgUbjfruFzMaQnlhpiGPwNOkDIyW).decode('utf-8'),headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIde)
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.status_code!=200:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Init_TV_Total()
    return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyB=base64.standard_b64decode(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text).decode('utf-8')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyB=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyB)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies']=qoYgUbjfruFzMaQnlhpiGPwNOkDIyB
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Init_TV_Total()
   return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
 def GetCredential(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,user_id,user_pw,login_type,user_pf):
  from curl_cffi import requests
  qoYgUbjfruFzMaQnlhpiGPwNOkDICd='chrome' 
  qoYgUbjfruFzMaQnlhpiGPwNOkDICy=requests.Session()
  try:
   if login_type=='0':
    qoYgUbjfruFzMaQnlhpiGPwNOkDICm='https://user.tving.com/pc/user/otherLogin.tving?loginType=10&from=pc&csite=&isAuto=false&rtUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   else:
    qoYgUbjfruFzMaQnlhpiGPwNOkDICm='https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   qoYgUbjfruFzMaQnlhpiGPwNOkDIde={'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language':'ko-KR,ko;q=0.9','cache-control':'no-cache','pragma':'no-cache','priority':'u=0, i','referer':'https://www.tving.com/',}
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDICy.get(qoYgUbjfruFzMaQnlhpiGPwNOkDICm,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIde,impersonate=qoYgUbjfruFzMaQnlhpiGPwNOkDICd)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB('{} - {}'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.status_code,qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.url))
   for qoYgUbjfruFzMaQnlhpiGPwNOkDICV in qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.cookies.jar:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies'][qoYgUbjfruFzMaQnlhpiGPwNOkDICV.name]=qoYgUbjfruFzMaQnlhpiGPwNOkDICV.value
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Init_TV_Total()
   return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICK=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   qoYgUbjfruFzMaQnlhpiGPwNOkDICA={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':qoYgUbjfruFzMaQnlhpiGPwNOkDIXm,'cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   qoYgUbjfruFzMaQnlhpiGPwNOkDIde['referer']=qoYgUbjfruFzMaQnlhpiGPwNOkDICm
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDICy.post(url=qoYgUbjfruFzMaQnlhpiGPwNOkDICK,data=qoYgUbjfruFzMaQnlhpiGPwNOkDICA,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIde,impersonate=qoYgUbjfruFzMaQnlhpiGPwNOkDICd)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB('{} - {}'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.status_code,qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.url))
   for qoYgUbjfruFzMaQnlhpiGPwNOkDICV in qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.cookies.jar:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies'][qoYgUbjfruFzMaQnlhpiGPwNOkDICV.name]=qoYgUbjfruFzMaQnlhpiGPwNOkDICV.value
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Init_TV_Total()
   return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  qoYgUbjfruFzMaQnlhpiGPwNOkDICc=[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDICX =''
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   qoYgUbjfruFzMaQnlhpiGPwNOkDIde['referer']=qoYgUbjfruFzMaQnlhpiGPwNOkDICK
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDICy.get(url=qoYgUbjfruFzMaQnlhpiGPwNOkDICT,data=qoYgUbjfruFzMaQnlhpiGPwNOkDICA,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIde,impersonate=qoYgUbjfruFzMaQnlhpiGPwNOkDICd)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB('{} - {}'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.status_code,qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.url))
   for qoYgUbjfruFzMaQnlhpiGPwNOkDICV in qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.cookies.jar:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies'][qoYgUbjfruFzMaQnlhpiGPwNOkDICV.name]=qoYgUbjfruFzMaQnlhpiGPwNOkDICV.value
   qoYgUbjfruFzMaQnlhpiGPwNOkDICc =re.findall('data-profile-no="\d+"',qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   for i in qoYgUbjfruFzMaQnlhpiGPwNOkDIXs(qoYgUbjfruFzMaQnlhpiGPwNOkDIXc(qoYgUbjfruFzMaQnlhpiGPwNOkDICc)):
    qoYgUbjfruFzMaQnlhpiGPwNOkDICs =qoYgUbjfruFzMaQnlhpiGPwNOkDICc[i].replace('data-profile-no=','').replace('"','')
    qoYgUbjfruFzMaQnlhpiGPwNOkDICc[i]=qoYgUbjfruFzMaQnlhpiGPwNOkDICs
   qoYgUbjfruFzMaQnlhpiGPwNOkDICX=qoYgUbjfruFzMaQnlhpiGPwNOkDICc[user_pf]
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Init_TV_Total()
   return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICJ ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   qoYgUbjfruFzMaQnlhpiGPwNOkDIde['referer']=qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDICA={'profileNo':qoYgUbjfruFzMaQnlhpiGPwNOkDICX}
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDICy.post(url=qoYgUbjfruFzMaQnlhpiGPwNOkDICJ,data=qoYgUbjfruFzMaQnlhpiGPwNOkDICA,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIde,impersonate=qoYgUbjfruFzMaQnlhpiGPwNOkDICd)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB('{} - {}'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.status_code,qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.url))
   for qoYgUbjfruFzMaQnlhpiGPwNOkDICV in qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.cookies.jar:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies'][qoYgUbjfruFzMaQnlhpiGPwNOkDICV.name]=qoYgUbjfruFzMaQnlhpiGPwNOkDICV.value
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Init_TV_Total()
   return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyE =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDeviceList()
  if qoYgUbjfruFzMaQnlhpiGPwNOkDIyE not in['','-']:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies']['tving_uuid']=qoYgUbjfruFzMaQnlhpiGPwNOkDIyE+'-'+qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetUniqueid(qoYgUbjfruFzMaQnlhpiGPwNOkDIyE)
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.JsonFile_Save(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.COOKIE_FILE_NAME,qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
 def GetDeviceList(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA):
  qoYgUbjfruFzMaQnlhpiGPwNOkDICx=[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDICt='-'
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v1/user/device/list'
   qoYgUbjfruFzMaQnlhpiGPwNOkDICR=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.makeDefaultCookies()
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDICR,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICL,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIdB)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICx=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(qoYgUbjfruFzMaQnlhpiGPwNOkDICx)
   for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDICx:
    if qoYgUbjfruFzMaQnlhpiGPwNOkDICS['model'].lower().startswith('pc'):
     qoYgUbjfruFzMaQnlhpiGPwNOkDICt=qoYgUbjfruFzMaQnlhpiGPwNOkDICS['uuid']
     break
   if qoYgUbjfruFzMaQnlhpiGPwNOkDICt=='-':
    qoYgUbjfruFzMaQnlhpiGPwNOkDICt=qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetNoCache(timetype=1))
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDICt
 def Get_Now_Datetime(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,mediacode,sel_quality,stype,pvrmode='-',optUHD=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm):
  qoYgUbjfruFzMaQnlhpiGPwNOkDICW ={'streaming_url':'','subtitleYn':qoYgUbjfruFzMaQnlhpiGPwNOkDIXm,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'','watermark':'','watermarkKey':'','qt_stream':'',}
  qoYgUbjfruFzMaQnlhpiGPwNOkDICt =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies']['tving_uuid'].split('-')[0] 
  qoYgUbjfruFzMaQnlhpiGPwNOkDICe =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies']['tving_uuid'] 
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICv=qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetNoCache(1))
   if stype!='tvingtv':
    qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v2/media/stream/info'
    qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
    qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':qoYgUbjfruFzMaQnlhpiGPwNOkDICe,'deviceInfo':'PC','noCache':qoYgUbjfruFzMaQnlhpiGPwNOkDICv,}
    qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
    qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
    qoYgUbjfruFzMaQnlhpiGPwNOkDIdB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.makeDefaultCookies()
    qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIdB)
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.status_code!=200:
     qoYgUbjfruFzMaQnlhpiGPwNOkDICW['error_msg']='First Step - {} error'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.status_code)
     return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
    qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
    if qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']['code']=='060':
     for qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIdW in qoYgUbjfruFzMaQnlhpiGPwNOkDIdC.items():
      if qoYgUbjfruFzMaQnlhpiGPwNOkDIdW==sel_quality:
       qoYgUbjfruFzMaQnlhpiGPwNOkDImd=qoYgUbjfruFzMaQnlhpiGPwNOkDIdE
    elif qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']['code']!='000':
     qoYgUbjfruFzMaQnlhpiGPwNOkDICW['error_msg']=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']['message']
     return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
    else: 
     if not('stream' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']):return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
     qoYgUbjfruFzMaQnlhpiGPwNOkDImy=[]
     for qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIdW in qoYgUbjfruFzMaQnlhpiGPwNOkDIdC.items():
      for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['stream']['quality']:
       if qoYgUbjfruFzMaQnlhpiGPwNOkDICS['active']=='Y' and qoYgUbjfruFzMaQnlhpiGPwNOkDICS['code']==qoYgUbjfruFzMaQnlhpiGPwNOkDIdE:
        qoYgUbjfruFzMaQnlhpiGPwNOkDImy.append({qoYgUbjfruFzMaQnlhpiGPwNOkDIdC.get(qoYgUbjfruFzMaQnlhpiGPwNOkDICS['code']):qoYgUbjfruFzMaQnlhpiGPwNOkDICS['code']})
     qoYgUbjfruFzMaQnlhpiGPwNOkDImd=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.CheckQuality(sel_quality,qoYgUbjfruFzMaQnlhpiGPwNOkDImy)
     try:
      if optUHD==qoYgUbjfruFzMaQnlhpiGPwNOkDIXA and qoYgUbjfruFzMaQnlhpiGPwNOkDImd=='stream50' and 'stream_support_info' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['content']['info']:
       if qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['content']['info']['stream_support_info']!=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC:
        if 'stream70' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['content']['info']['stream_support_info']:
         qoYgUbjfruFzMaQnlhpiGPwNOkDImd='stream70'
         qoYgUbjfruFzMaQnlhpiGPwNOkDICW['qt_stream']='stream70'
     except:
      pass
     try:
      if optUHD==qoYgUbjfruFzMaQnlhpiGPwNOkDIXA and qoYgUbjfruFzMaQnlhpiGPwNOkDImd=='stream50' and 'stream' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['content']['info']:
       if qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['content']['info']['stream']!=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC:
        for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['content']['info']['stream']:
         if qoYgUbjfruFzMaQnlhpiGPwNOkDICS['code']=='stream70':
          qoYgUbjfruFzMaQnlhpiGPwNOkDImd='stream70'
          break
     except:
      pass
   else:
    qoYgUbjfruFzMaQnlhpiGPwNOkDImd='stream40'
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICW['error_msg']='First Step - except error'
   return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
  qoYgUbjfruFzMaQnlhpiGPwNOkDICW['qt_stream']=qoYgUbjfruFzMaQnlhpiGPwNOkDImd
  qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(qoYgUbjfruFzMaQnlhpiGPwNOkDImd)
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICv=qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetNoCache(1))
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v3/media/stream/info'
   if qoYgUbjfruFzMaQnlhpiGPwNOkDICW['qt_stream']=='stream70':
    qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams(uhd=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA)
    qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'mediaCode':mediacode,'deviceId':qoYgUbjfruFzMaQnlhpiGPwNOkDICt,'uuid':qoYgUbjfruFzMaQnlhpiGPwNOkDICe,'deviceInfo':'PC_Chrome WebView','streamCode':qoYgUbjfruFzMaQnlhpiGPwNOkDImd,'noCache':qoYgUbjfruFzMaQnlhpiGPwNOkDICv,'callingFrom':'HTML5','model':'android_chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header','streamType':'hls',}
   else:
    qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
    qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'mediaCode':mediacode,'deviceId':qoYgUbjfruFzMaQnlhpiGPwNOkDICt,'uuid':qoYgUbjfruFzMaQnlhpiGPwNOkDICe,'deviceInfo':'PC_Chrome','streamCode':qoYgUbjfruFzMaQnlhpiGPwNOkDImd,'noCache':qoYgUbjfruFzMaQnlhpiGPwNOkDICv,'callingFrom':'HTML5','model':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.makeDefaultCookies()
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Post',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIdB,redirects=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']['code']!='000':
    qoYgUbjfruFzMaQnlhpiGPwNOkDICW['error_msg']=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']['message']
    return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
   qoYgUbjfruFzMaQnlhpiGPwNOkDImC=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['stream']
   if qoYgUbjfruFzMaQnlhpiGPwNOkDImC['drm_yn']=='Y':
    qoYgUbjfruFzMaQnlhpiGPwNOkDImV=qoYgUbjfruFzMaQnlhpiGPwNOkDImC['playback']['drm']['widevine']
    for qoYgUbjfruFzMaQnlhpiGPwNOkDImK in qoYgUbjfruFzMaQnlhpiGPwNOkDImC['playback']['drm']['license']['drm_license_data']:
     if qoYgUbjfruFzMaQnlhpiGPwNOkDImK['drm_type']=='Widevine':
      qoYgUbjfruFzMaQnlhpiGPwNOkDICW['drm_server_url'] =qoYgUbjfruFzMaQnlhpiGPwNOkDImK['drm_server_url']
      qoYgUbjfruFzMaQnlhpiGPwNOkDICW['drm_header_key'] =qoYgUbjfruFzMaQnlhpiGPwNOkDImK['drm_header_key']
      qoYgUbjfruFzMaQnlhpiGPwNOkDICW['drm_header_value']=qoYgUbjfruFzMaQnlhpiGPwNOkDImK['drm_header_value']
      break
   else:
    qoYgUbjfruFzMaQnlhpiGPwNOkDImV=qoYgUbjfruFzMaQnlhpiGPwNOkDImC['playback']['non_drm']
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICW['error_msg']='Second Step - except error'
   return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
  qoYgUbjfruFzMaQnlhpiGPwNOkDImA=qoYgUbjfruFzMaQnlhpiGPwNOkDICv
  qoYgUbjfruFzMaQnlhpiGPwNOkDImV=qoYgUbjfruFzMaQnlhpiGPwNOkDImV.split('|')[1]
  qoYgUbjfruFzMaQnlhpiGPwNOkDImV,qoYgUbjfruFzMaQnlhpiGPwNOkDImc,qoYgUbjfruFzMaQnlhpiGPwNOkDImX=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Decrypt_Url(qoYgUbjfruFzMaQnlhpiGPwNOkDImV,mediacode,qoYgUbjfruFzMaQnlhpiGPwNOkDImA)
  qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url']=qoYgUbjfruFzMaQnlhpiGPwNOkDImV
  qoYgUbjfruFzMaQnlhpiGPwNOkDICW['watermark'] =qoYgUbjfruFzMaQnlhpiGPwNOkDImc
  qoYgUbjfruFzMaQnlhpiGPwNOkDICW['watermarkKey']=qoYgUbjfruFzMaQnlhpiGPwNOkDImX
  if 'subtitles' in qoYgUbjfruFzMaQnlhpiGPwNOkDImC:
   for qoYgUbjfruFzMaQnlhpiGPwNOkDImT in qoYgUbjfruFzMaQnlhpiGPwNOkDImC.get('subtitles'):
    if qoYgUbjfruFzMaQnlhpiGPwNOkDImT.get('code')in['KO','KO_CC']:
     qoYgUbjfruFzMaQnlhpiGPwNOkDICW['subtitleYn']=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
     break
  qoYgUbjfruFzMaQnlhpiGPwNOkDIms=urllib.parse.urlparse(qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url'])
  qoYgUbjfruFzMaQnlhpiGPwNOkDImJ =qoYgUbjfruFzMaQnlhpiGPwNOkDIms.path.strip('/').split('/')
  qoYgUbjfruFzMaQnlhpiGPwNOkDICW['url_filename']=qoYgUbjfruFzMaQnlhpiGPwNOkDImJ[qoYgUbjfruFzMaQnlhpiGPwNOkDIXc(qoYgUbjfruFzMaQnlhpiGPwNOkDImJ)-1]
  return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
 def TestUrl(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,qoYgUbjfruFzMaQnlhpiGPwNOkDIyW):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIde={}
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,redirects=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA)
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TextFile_Save(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV_SESSION_TEXT1,qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
 def Tving_Parse_mpd(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,stream_url,watermarkKey=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,watermark=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC):
  if watermarkKey not in['',qoYgUbjfruFzMaQnlhpiGPwNOkDIXC]:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIde={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,}
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=requests.get(url=stream_url,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIde,allow_redirects=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm)
  else:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=requests.get(url=stream_url)
  qoYgUbjfruFzMaQnlhpiGPwNOkDImx=qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.content.decode('utf-8')
  qoYgUbjfruFzMaQnlhpiGPwNOkDImt=0
  qoYgUbjfruFzMaQnlhpiGPwNOkDImR =ET.ElementTree(ET.fromstring(qoYgUbjfruFzMaQnlhpiGPwNOkDImx))
  qoYgUbjfruFzMaQnlhpiGPwNOkDImL =qoYgUbjfruFzMaQnlhpiGPwNOkDImR.getroot()
  qoYgUbjfruFzMaQnlhpiGPwNOkDImH=re.match(r'\{.*\}',qoYgUbjfruFzMaQnlhpiGPwNOkDImL.tag)[0] 
  qoYgUbjfruFzMaQnlhpiGPwNOkDImS=qoYgUbjfruFzMaQnlhpiGPwNOkDIXt([node for _,node in ET.iterparse(io.StringIO(qoYgUbjfruFzMaQnlhpiGPwNOkDImx),events=['start-ns'])])
  for qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIVJ in qoYgUbjfruFzMaQnlhpiGPwNOkDImS.items():
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIdE!='ns2':
    ET.register_namespace(qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIVJ)
  qoYgUbjfruFzMaQnlhpiGPwNOkDImE=qoYgUbjfruFzMaQnlhpiGPwNOkDImL.find(qoYgUbjfruFzMaQnlhpiGPwNOkDImH+'Period')
  for qoYgUbjfruFzMaQnlhpiGPwNOkDImW in qoYgUbjfruFzMaQnlhpiGPwNOkDImE.findall(qoYgUbjfruFzMaQnlhpiGPwNOkDImH+'AdaptationSet'):
   if(qoYgUbjfruFzMaQnlhpiGPwNOkDImW.attrib.get('mimeType')=='video/mp4' or qoYgUbjfruFzMaQnlhpiGPwNOkDImW.attrib.get('contentType')=='video'):
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIme in qoYgUbjfruFzMaQnlhpiGPwNOkDImW.findall(qoYgUbjfruFzMaQnlhpiGPwNOkDImH+'Representation'):
     qoYgUbjfruFzMaQnlhpiGPwNOkDImv=qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(qoYgUbjfruFzMaQnlhpiGPwNOkDIme.attrib.get('bandwidth'))
     if qoYgUbjfruFzMaQnlhpiGPwNOkDImt<qoYgUbjfruFzMaQnlhpiGPwNOkDImv:qoYgUbjfruFzMaQnlhpiGPwNOkDImt=qoYgUbjfruFzMaQnlhpiGPwNOkDImv
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIme in qoYgUbjfruFzMaQnlhpiGPwNOkDImW.findall(qoYgUbjfruFzMaQnlhpiGPwNOkDImH+'Representation'):
     if qoYgUbjfruFzMaQnlhpiGPwNOkDImt>qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(qoYgUbjfruFzMaQnlhpiGPwNOkDIme.attrib.get('bandwidth')):
      qoYgUbjfruFzMaQnlhpiGPwNOkDImW.remove(qoYgUbjfruFzMaQnlhpiGPwNOkDIme)
   else:
    continue
  qoYgUbjfruFzMaQnlhpiGPwNOkDImB=ET.tostring(qoYgUbjfruFzMaQnlhpiGPwNOkDImL).decode('utf-8')
  qoYgUbjfruFzMaQnlhpiGPwNOkDIVd='<?xml version="1.0" encoding="UTF-8"?>\n'
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TextFile_Save(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV_STREAM_FILENAME,qoYgUbjfruFzMaQnlhpiGPwNOkDIVd+qoYgUbjfruFzMaQnlhpiGPwNOkDImB)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
 def Tving_Parse_m3u8(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,stream_url):
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=requests.get(url=stream_url,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,stream=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVy=qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.content.decode('utf-8')
   if '#EXTM3U' not in qoYgUbjfruFzMaQnlhpiGPwNOkDIVy:
    return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
   if '#EXT-X-STREAM-INF' not in qoYgUbjfruFzMaQnlhpiGPwNOkDIVy: 
    return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVC=0
   for qoYgUbjfruFzMaQnlhpiGPwNOkDIVm in qoYgUbjfruFzMaQnlhpiGPwNOkDIVy.splitlines():
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIVm.startswith('#EXT-X-STREAM-INF'):
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVK=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.MediaLine_Parse(qoYgUbjfruFzMaQnlhpiGPwNOkDIVm,'#EXT-X-STREAM-INF')
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIVC<qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(qoYgUbjfruFzMaQnlhpiGPwNOkDIVK.get('BANDWIDTH')):
      qoYgUbjfruFzMaQnlhpiGPwNOkDIVC=qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(qoYgUbjfruFzMaQnlhpiGPwNOkDIVK.get('BANDWIDTH'))
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVA=[]
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVc=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
   for qoYgUbjfruFzMaQnlhpiGPwNOkDIVm in qoYgUbjfruFzMaQnlhpiGPwNOkDIVy.splitlines():
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIVc==qoYgUbjfruFzMaQnlhpiGPwNOkDIXA:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVc=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
     continue
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIVm.startswith('#EXT-X-STREAM-INF'):
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVK=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.MediaLine_Parse(qoYgUbjfruFzMaQnlhpiGPwNOkDIVm,'#EXT-X-STREAM-INF')
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIVC!=qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(qoYgUbjfruFzMaQnlhpiGPwNOkDIVK.get('BANDWIDTH')):
      qoYgUbjfruFzMaQnlhpiGPwNOkDIVc=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
      continue
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVA.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIVm)
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
   return qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  qoYgUbjfruFzMaQnlhpiGPwNOkDIVX='\n'.join(qoYgUbjfruFzMaQnlhpiGPwNOkDIVA)
  qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TextFile_Save(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV_STREAM_FILENAME,qoYgUbjfruFzMaQnlhpiGPwNOkDIVX)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
 def MediaLine_Parse(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,qoYgUbjfruFzMaQnlhpiGPwNOkDIVm,prefix):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIVK={}
  for qoYgUbjfruFzMaQnlhpiGPwNOkDIVT in qoYgUbjfruFzMaQnlhpiGPwNOkDIdV.split(qoYgUbjfruFzMaQnlhpiGPwNOkDIVm.replace(prefix+':',''))[1::2]:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVs,qoYgUbjfruFzMaQnlhpiGPwNOkDIVJ=qoYgUbjfruFzMaQnlhpiGPwNOkDIVT.split('=',1)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVK[qoYgUbjfruFzMaQnlhpiGPwNOkDIVs.upper()]=qoYgUbjfruFzMaQnlhpiGPwNOkDIVJ.replace('"','').strip()
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIVK
 def CheckQuality(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,sel_qt,qoYgUbjfruFzMaQnlhpiGPwNOkDImy):
  for qoYgUbjfruFzMaQnlhpiGPwNOkDIVx in qoYgUbjfruFzMaQnlhpiGPwNOkDImy:
   if sel_qt>=qoYgUbjfruFzMaQnlhpiGPwNOkDIXR(qoYgUbjfruFzMaQnlhpiGPwNOkDIVx)[0]:return qoYgUbjfruFzMaQnlhpiGPwNOkDIVx.get(qoYgUbjfruFzMaQnlhpiGPwNOkDIXR(qoYgUbjfruFzMaQnlhpiGPwNOkDIVx)[0])
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVt=qoYgUbjfruFzMaQnlhpiGPwNOkDIVx.get(qoYgUbjfruFzMaQnlhpiGPwNOkDIXR(qoYgUbjfruFzMaQnlhpiGPwNOkDIVx)[0])
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIVt
 def makeOocUrl(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,ooc_params):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=''
  for qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIdW in ooc_params.items():
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW+="%s=%s^"%(qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIdW)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIyW
 def GetLiveChannelList(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,stype,page_int):
  qoYgUbjfruFzMaQnlhpiGPwNOkDICx=[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v2/media/lives'
   if stype=='onair': 
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVL='CPCS0100,CPCS0400'
   else:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVL='CPCS0300'
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'cacheType':'main','pageNo':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(page_int),'pageSize':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':qoYgUbjfruFzMaQnlhpiGPwNOkDIVL,}
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if not('result' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']):return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVH=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']
   for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDIVH:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVS=qoYgUbjfruFzMaQnlhpiGPwNOkDIVe=qoYgUbjfruFzMaQnlhpiGPwNOkDIVv=''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVE=qoYgUbjfruFzMaQnlhpiGPwNOkDIKH=''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVW=qoYgUbjfruFzMaQnlhpiGPwNOkDICS['live_code']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVS =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['channel']['name']['ko']
    if qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['episode']!=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVe =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['program']['name']['ko']
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVe =qoYgUbjfruFzMaQnlhpiGPwNOkDIVe+', '+qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['episode']['frequency'])+'회'
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVv=qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['episode']['synopsis']['ko']
    else:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVe =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['program']['name']['ko']
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVv=qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['program']['synopsis']['ko']
    try: 
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =''
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =''
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=''
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKC =''
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKm =''
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKV =''
     for qoYgUbjfruFzMaQnlhpiGPwNOkDIKA in qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['program']['image']:
      if qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP0900':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
      elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP1800':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
      elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP2000':qoYgUbjfruFzMaQnlhpiGPwNOkDIKC =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
      elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP1900':qoYgUbjfruFzMaQnlhpiGPwNOkDIKm =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
      elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP0200':qoYgUbjfruFzMaQnlhpiGPwNOkDIKV =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
      elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP0500':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
      elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP0800':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIVB=='':
      for qoYgUbjfruFzMaQnlhpiGPwNOkDIKA in qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['channel']['image']:
       if qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIC0400':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
       elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIC1400':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
       elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIC1900':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
    except:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIXC
    try:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKc =[]
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKX=[]
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKT =[]
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKs=''
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ=''
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKx=''
     for qoYgUbjfruFzMaQnlhpiGPwNOkDIKt in qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('schedule').get('program').get('actor'):
      if qoYgUbjfruFzMaQnlhpiGPwNOkDIKt!='' and qoYgUbjfruFzMaQnlhpiGPwNOkDIKt!=u'없음':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKt)
     for qoYgUbjfruFzMaQnlhpiGPwNOkDIKR in qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('schedule').get('program').get('director'):
      if qoYgUbjfruFzMaQnlhpiGPwNOkDIKR!='' and qoYgUbjfruFzMaQnlhpiGPwNOkDIKR!='-' and qoYgUbjfruFzMaQnlhpiGPwNOkDIKR!=u'없음':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKR)
     if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('schedule').get('program').get('category1_name').get('ko')!='':
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKT.append(qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['program']['category1_name']['ko'])
     if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('schedule').get('program').get('category2_name').get('ko')!='':
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKT.append(qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['program']['category2_name']['ko'])
     if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('schedule').get('program').get('product_year'):qoYgUbjfruFzMaQnlhpiGPwNOkDIKs=qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['program']['product_year']
     if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('schedule').get('program').get('grade_code') :qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ= qoYgUbjfruFzMaQnlhpiGPwNOkDIdm.get(qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['program']['grade_code'])
     if 'broad_dt' in qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('schedule').get('program'):
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKL =qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('schedule').get('program').get('broad_dt')
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKx='%s-%s-%s'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[:4],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[4:6],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[6:])
    except:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIXC
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVE=qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['broadcast_start_time'])[8:12]
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKH =qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDICS['schedule']['broadcast_end_time'])[8:12]
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'channel':qoYgUbjfruFzMaQnlhpiGPwNOkDIVS,'title':qoYgUbjfruFzMaQnlhpiGPwNOkDIVe,'mediacode':qoYgUbjfruFzMaQnlhpiGPwNOkDIVW,'thumbnail':{'poster':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd,'thumb':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB,'clearlogo':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy,'icon':qoYgUbjfruFzMaQnlhpiGPwNOkDIKC,'fanart':qoYgUbjfruFzMaQnlhpiGPwNOkDIKV},'synopsis':qoYgUbjfruFzMaQnlhpiGPwNOkDIVv,'channelepg':' [%s:%s ~ %s:%s]'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIVE[0:2],qoYgUbjfruFzMaQnlhpiGPwNOkDIVE[2:],qoYgUbjfruFzMaQnlhpiGPwNOkDIKH[0:2],qoYgUbjfruFzMaQnlhpiGPwNOkDIKH[2:]),'cast':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc,'director':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX,'info_genre':qoYgUbjfruFzMaQnlhpiGPwNOkDIKT,'year':qoYgUbjfruFzMaQnlhpiGPwNOkDIKs,'mpaa':qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ,'premiered':qoYgUbjfruFzMaQnlhpiGPwNOkDIKx}
    qoYgUbjfruFzMaQnlhpiGPwNOkDICx.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
   if qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['has_more']=='Y':
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
 def GetProgramList(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,genre,orderby,page_int,genreCode='all'):
  qoYgUbjfruFzMaQnlhpiGPwNOkDICx=[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v2/media/episodes'
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'cacheType':'main','pageSize':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(page_int),}
   if genre not in['all','PARAMOUNT']:qoYgUbjfruFzMaQnlhpiGPwNOkDICL['categoryCode']=genre
   if genreCode!='all' :qoYgUbjfruFzMaQnlhpiGPwNOkDICL['genreCode'] =genreCode 
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if not('result' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']):return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVH=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']
   for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDIVH:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKE=qoYgUbjfruFzMaQnlhpiGPwNOkDICS['program']['code']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVe =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['program']['name']['ko']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ =qoYgUbjfruFzMaQnlhpiGPwNOkDIdm.get(qoYgUbjfruFzMaQnlhpiGPwNOkDICS['program'].get('grade_code'))
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKC =''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKm =''
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIKA in qoYgUbjfruFzMaQnlhpiGPwNOkDICS['program']['image']:
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP0900':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP0200':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP1800':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP2000':qoYgUbjfruFzMaQnlhpiGPwNOkDIKC =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP1900':qoYgUbjfruFzMaQnlhpiGPwNOkDIKm =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVv =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['program']['synopsis']['ko']
    try:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKW=qoYgUbjfruFzMaQnlhpiGPwNOkDICS['channel']['name']['ko']
    except:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKW=''
    try:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKc =[]
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKX=[]
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKT =[]
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKs =''
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKx=''
     for qoYgUbjfruFzMaQnlhpiGPwNOkDIKt in qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('program').get('actor'):
      if qoYgUbjfruFzMaQnlhpiGPwNOkDIKt!='' and qoYgUbjfruFzMaQnlhpiGPwNOkDIKt!='-' and qoYgUbjfruFzMaQnlhpiGPwNOkDIKt!=u'없음':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKt)
     for qoYgUbjfruFzMaQnlhpiGPwNOkDIKR in qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('program').get('director'):
      if qoYgUbjfruFzMaQnlhpiGPwNOkDIKR!='' and qoYgUbjfruFzMaQnlhpiGPwNOkDIKR!='-' and qoYgUbjfruFzMaQnlhpiGPwNOkDIKR!=u'없음':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKR)
     if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('program').get('category1_name').get('ko')!='':
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKT.append(qoYgUbjfruFzMaQnlhpiGPwNOkDICS['program']['category1_name']['ko'])
     if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('program').get('category2_name').get('ko')!='':
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKT.append(qoYgUbjfruFzMaQnlhpiGPwNOkDICS['program']['category2_name']['ko'])
     if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('program').get('product_year'):qoYgUbjfruFzMaQnlhpiGPwNOkDIKs=qoYgUbjfruFzMaQnlhpiGPwNOkDICS['program']['product_year']
     if 'broad_dt' in qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('program'):
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKL =qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('program').get('broad_dt')
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKx='%s-%s-%s'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[:4],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[4:6],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[6:])
    except:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIXC
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'program':qoYgUbjfruFzMaQnlhpiGPwNOkDIKE,'title':qoYgUbjfruFzMaQnlhpiGPwNOkDIVe,'thumbnail':{'poster':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd,'thumb':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB,'clearlogo':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy,'icon':qoYgUbjfruFzMaQnlhpiGPwNOkDIKC,'banner':qoYgUbjfruFzMaQnlhpiGPwNOkDIKm,'fanart':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB},'synopsis':qoYgUbjfruFzMaQnlhpiGPwNOkDIVv,'channel':qoYgUbjfruFzMaQnlhpiGPwNOkDIKW,'cast':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc,'director':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX,'info_genre':qoYgUbjfruFzMaQnlhpiGPwNOkDIKT,'year':qoYgUbjfruFzMaQnlhpiGPwNOkDIKs,'premiered':qoYgUbjfruFzMaQnlhpiGPwNOkDIKx,'mpaa':qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ}
    qoYgUbjfruFzMaQnlhpiGPwNOkDICx.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
   if qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['has_more']=='Y':qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
 def Get_UHD_ProgramList(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,page_int):
  qoYgUbjfruFzMaQnlhpiGPwNOkDICx=[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v2/operator/highlights'
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams(uhd=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(page_int),'pocType':'APP_X_TVING_4.0.0',}
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if not('result' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']):return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVH=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']
   for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDIVH:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKe=qoYgUbjfruFzMaQnlhpiGPwNOkDICS['content']['program']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKv =qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['code']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVe =qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['name']['ko'].strip()
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ =qoYgUbjfruFzMaQnlhpiGPwNOkDIdm.get(qoYgUbjfruFzMaQnlhpiGPwNOkDIKe.get('grade_code'))
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVv =qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['synopsis']['ko']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKW =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['content']['channel']['name']['ko']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKs =qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['product_year']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKC =''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKm =''
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIKA in qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['image']:
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP0900':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP0200':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP1800':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP2000':qoYgUbjfruFzMaQnlhpiGPwNOkDIKC =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP1900':qoYgUbjfruFzMaQnlhpiGPwNOkDIKm =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKT =[]
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKc =[]
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKX=[]
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKx =''
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIKe.get('category1_name').get('ko')!='':
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKT.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['category1_name']['ko'])
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIKe.get('category2_name').get('ko')!='':
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKT.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['category2_name']['ko'])
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIKt in qoYgUbjfruFzMaQnlhpiGPwNOkDIKe.get('actor'):
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIKt!='' and qoYgUbjfruFzMaQnlhpiGPwNOkDIKt!='-' and qoYgUbjfruFzMaQnlhpiGPwNOkDIKt!=u'없음':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKt)
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIKR in qoYgUbjfruFzMaQnlhpiGPwNOkDIKe.get('director'):
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIKR!='' and qoYgUbjfruFzMaQnlhpiGPwNOkDIKR!='-' and qoYgUbjfruFzMaQnlhpiGPwNOkDIKR!=u'없음':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKR)
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIKe.get('broad_dt')not in[qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,'']:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKL =qoYgUbjfruFzMaQnlhpiGPwNOkDIKe.get('broad_dt')
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKx='%s-%s-%s'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[:4],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[4:6],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[6:])
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'program':qoYgUbjfruFzMaQnlhpiGPwNOkDIKv,'title':qoYgUbjfruFzMaQnlhpiGPwNOkDIVe,'mpaa':qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ,'thumbnail':{'poster':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd,'thumb':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB,'clearlogo':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy,'icon':qoYgUbjfruFzMaQnlhpiGPwNOkDIKC,'banner':qoYgUbjfruFzMaQnlhpiGPwNOkDIKm,'fanart':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB},'channel':qoYgUbjfruFzMaQnlhpiGPwNOkDIKW,'synopsis':qoYgUbjfruFzMaQnlhpiGPwNOkDIVv,'year':qoYgUbjfruFzMaQnlhpiGPwNOkDIKs,'info_genre':qoYgUbjfruFzMaQnlhpiGPwNOkDIKT,'cast':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc,'director':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX,'premiered':qoYgUbjfruFzMaQnlhpiGPwNOkDIKx,}
    qoYgUbjfruFzMaQnlhpiGPwNOkDICx.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
 def Get_Origianl_ProgramList(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,page_int):
  qoYgUbjfruFzMaQnlhpiGPwNOkDICx=[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v2/media/band/originals'
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'pageSize':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(page_int),}
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKB=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.JsonFile_Save(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV_SESSION_COOKIES2,qoYgUbjfruFzMaQnlhpiGPwNOkDIKB)
   if not('contents' in qoYgUbjfruFzMaQnlhpiGPwNOkDIKB['body']):return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVH=qoYgUbjfruFzMaQnlhpiGPwNOkDIKB['body']['contents']
   for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDIVH:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAd =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['vod_code']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVe =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['vod_name']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICS['image']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAy ='movie' if qoYgUbjfruFzMaQnlhpiGPwNOkDIAd.startswith('M')else 'vod'
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'vod_code':qoYgUbjfruFzMaQnlhpiGPwNOkDIAd,'title':qoYgUbjfruFzMaQnlhpiGPwNOkDIVe,'thumbnail':{'poster':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd,'thumb':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd},'vod_type':qoYgUbjfruFzMaQnlhpiGPwNOkDIAy,}
    qoYgUbjfruFzMaQnlhpiGPwNOkDICx.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIKB['body']['has_more']=='Y':qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
 def GetEpisodeList(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,program_code,page_int,orderby='desc'):
  qoYgUbjfruFzMaQnlhpiGPwNOkDICx=[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v2/media/frequency/program/'+program_code
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if not('result' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']):return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVH=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']
   qoYgUbjfruFzMaQnlhpiGPwNOkDIAC=qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['total_count'])
   qoYgUbjfruFzMaQnlhpiGPwNOkDIAm =qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(qoYgUbjfruFzMaQnlhpiGPwNOkDIAC//(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAV =(qoYgUbjfruFzMaQnlhpiGPwNOkDIAC-1)-((page_int-1)*qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.EPISODE_LIMIT)
   else:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAV =(page_int-1)*qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.EPISODE_LIMIT
   for i in qoYgUbjfruFzMaQnlhpiGPwNOkDIXs(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.EPISODE_LIMIT):
    if orderby=='desc':
     qoYgUbjfruFzMaQnlhpiGPwNOkDIAK=qoYgUbjfruFzMaQnlhpiGPwNOkDIAV-i
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIAK<0:break
    else:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIAK=qoYgUbjfruFzMaQnlhpiGPwNOkDIAV+i
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIAK>=qoYgUbjfruFzMaQnlhpiGPwNOkDIAC:break
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAc=qoYgUbjfruFzMaQnlhpiGPwNOkDIVH[qoYgUbjfruFzMaQnlhpiGPwNOkDIAK]['episode']['code']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVe =qoYgUbjfruFzMaQnlhpiGPwNOkDIVH[qoYgUbjfruFzMaQnlhpiGPwNOkDIAK]['vod_name']['ko']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAX =''
    try:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKL=qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIVH[qoYgUbjfruFzMaQnlhpiGPwNOkDIAK]['episode']['broadcast_date'])
     qoYgUbjfruFzMaQnlhpiGPwNOkDIAX='%s-%s-%s'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[:4],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[4:6],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[6:])
    except:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIXC
    try:
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIVH[qoYgUbjfruFzMaQnlhpiGPwNOkDIAK]['episode']['pip_cliptype']=='C012':
      qoYgUbjfruFzMaQnlhpiGPwNOkDIAX+=' - Quick VOD'
    except:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIXC
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVv =qoYgUbjfruFzMaQnlhpiGPwNOkDIVH[qoYgUbjfruFzMaQnlhpiGPwNOkDIAK]['episode']['synopsis']['ko']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKC =''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKm =''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKV =''
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIKA in qoYgUbjfruFzMaQnlhpiGPwNOkDIVH[qoYgUbjfruFzMaQnlhpiGPwNOkDIAK]['program']['image']:
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP0900':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP1800':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP2000':qoYgUbjfruFzMaQnlhpiGPwNOkDIKC =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP1900':qoYgUbjfruFzMaQnlhpiGPwNOkDIKm =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIP0200':qoYgUbjfruFzMaQnlhpiGPwNOkDIKV =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIKA in qoYgUbjfruFzMaQnlhpiGPwNOkDIVH[qoYgUbjfruFzMaQnlhpiGPwNOkDIAK]['episode']['image']:
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIE0400':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
    try:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIAT=qoYgUbjfruFzMaQnlhpiGPwNOkDIAJ=qoYgUbjfruFzMaQnlhpiGPwNOkDIAx=''
     qoYgUbjfruFzMaQnlhpiGPwNOkDIAs=0
     qoYgUbjfruFzMaQnlhpiGPwNOkDIAT =qoYgUbjfruFzMaQnlhpiGPwNOkDIVH[qoYgUbjfruFzMaQnlhpiGPwNOkDIAK]['program']['name']['ko']
     qoYgUbjfruFzMaQnlhpiGPwNOkDIAJ =qoYgUbjfruFzMaQnlhpiGPwNOkDIAX
     qoYgUbjfruFzMaQnlhpiGPwNOkDIAx =qoYgUbjfruFzMaQnlhpiGPwNOkDIVH[qoYgUbjfruFzMaQnlhpiGPwNOkDIAK]['channel']['name']['ko']
     if 'frequency' in qoYgUbjfruFzMaQnlhpiGPwNOkDIVH[qoYgUbjfruFzMaQnlhpiGPwNOkDIAK]['episode']:qoYgUbjfruFzMaQnlhpiGPwNOkDIAs=qoYgUbjfruFzMaQnlhpiGPwNOkDIVH[qoYgUbjfruFzMaQnlhpiGPwNOkDIAK]['episode']['frequency']
    except:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIXC
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'episode':qoYgUbjfruFzMaQnlhpiGPwNOkDIAc,'title':qoYgUbjfruFzMaQnlhpiGPwNOkDIVe,'subtitle':qoYgUbjfruFzMaQnlhpiGPwNOkDIAX,'thumbnail':{'poster':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd,'thumb':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB,'clearlogo':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy,'icon':qoYgUbjfruFzMaQnlhpiGPwNOkDIKC,'banner':qoYgUbjfruFzMaQnlhpiGPwNOkDIKm,'fanart':qoYgUbjfruFzMaQnlhpiGPwNOkDIKV},'synopsis':qoYgUbjfruFzMaQnlhpiGPwNOkDIVv,'info_title':qoYgUbjfruFzMaQnlhpiGPwNOkDIAT,'aired':qoYgUbjfruFzMaQnlhpiGPwNOkDIAJ,'studio':qoYgUbjfruFzMaQnlhpiGPwNOkDIAx,'frequency':qoYgUbjfruFzMaQnlhpiGPwNOkDIAs}
    qoYgUbjfruFzMaQnlhpiGPwNOkDICx.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIAm>page_int:qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR,qoYgUbjfruFzMaQnlhpiGPwNOkDIAm
 def GetMovieList(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,genre,orderby,page_int):
  qoYgUbjfruFzMaQnlhpiGPwNOkDICx=[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v2/media/movies'
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'pageSize':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:qoYgUbjfruFzMaQnlhpiGPwNOkDICL['categoryCode']=genre
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL['productPackageCode']=','.join(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.MOVIE_LITE)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if not('result' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']):return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVH=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']
   for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDIVH:
    if 'release_date' in qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('movie'):
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKs=qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('movie').get('release_date'))[:4]
    else:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKs=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAt =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['movie']['code']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVe =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['movie']['name']['ko'].strip()
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIKs not in[qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,'0','']:qoYgUbjfruFzMaQnlhpiGPwNOkDIVe+=u' (%s)'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIKs)
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKd=''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=''
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIKA in qoYgUbjfruFzMaQnlhpiGPwNOkDICS['movie']['image']:
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIM2100':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIM0400':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIM1800':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVv =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['movie']['story']['ko']
    try:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIAT =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['movie']['name']['ko'].strip()
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ =qoYgUbjfruFzMaQnlhpiGPwNOkDIdm.get(qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('grade_code'))
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKc=[]
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKX=[]
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKT=[]
     qoYgUbjfruFzMaQnlhpiGPwNOkDIAR=0
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKx=''
     qoYgUbjfruFzMaQnlhpiGPwNOkDIAx =''
     for qoYgUbjfruFzMaQnlhpiGPwNOkDIKt in qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('movie').get('actor'):
      if qoYgUbjfruFzMaQnlhpiGPwNOkDIKt!='':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKt)
     for qoYgUbjfruFzMaQnlhpiGPwNOkDIKR in qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('movie').get('director'):
      if qoYgUbjfruFzMaQnlhpiGPwNOkDIKR!='':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKR)
     if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('movie').get('category1_name').get('ko')!='':
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKT.append(qoYgUbjfruFzMaQnlhpiGPwNOkDICS['movie']['category1_name']['ko'])
     if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('movie').get('category2_name').get('ko')!='':
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKT.append(qoYgUbjfruFzMaQnlhpiGPwNOkDICS['movie']['category2_name']['ko'])
     if 'duration' in qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('movie'):qoYgUbjfruFzMaQnlhpiGPwNOkDIAR=qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('movie').get('duration')
     if 'release_date' in qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('movie'):
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKL=qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('movie').get('release_date'))
      if qoYgUbjfruFzMaQnlhpiGPwNOkDIKL!='0':qoYgUbjfruFzMaQnlhpiGPwNOkDIKx='%s-%s-%s'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[:4],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[4:6],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[6:])
     if 'production' in qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('movie'):qoYgUbjfruFzMaQnlhpiGPwNOkDIAx=qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('movie').get('production')
    except:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIXC
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'moviecode':qoYgUbjfruFzMaQnlhpiGPwNOkDIAt,'title':qoYgUbjfruFzMaQnlhpiGPwNOkDIVe,'thumbnail':{'poster':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd,'thumb':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB,'clearlogo':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy,'fanart':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB},'synopsis':qoYgUbjfruFzMaQnlhpiGPwNOkDIVv,'info_title':qoYgUbjfruFzMaQnlhpiGPwNOkDIAT,'year':qoYgUbjfruFzMaQnlhpiGPwNOkDIKs,'cast':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc,'director':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX,'info_genre':qoYgUbjfruFzMaQnlhpiGPwNOkDIKT,'duration':qoYgUbjfruFzMaQnlhpiGPwNOkDIAR,'premiered':qoYgUbjfruFzMaQnlhpiGPwNOkDIKx,'studio':qoYgUbjfruFzMaQnlhpiGPwNOkDIAx,'mpaa':qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ}
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAL=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIAH in qoYgUbjfruFzMaQnlhpiGPwNOkDICS['billing_package_id']:
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIAH in qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.MOVIE_LITE:
      qoYgUbjfruFzMaQnlhpiGPwNOkDIAL=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
      break
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIAL==qoYgUbjfruFzMaQnlhpiGPwNOkDIXm: 
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKS['title']=qoYgUbjfruFzMaQnlhpiGPwNOkDIKS['title']+' [개별구매]'
    qoYgUbjfruFzMaQnlhpiGPwNOkDICx.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
   if qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['has_more']=='Y':qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
 def Get_UHD_MovieList(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,page_int):
  qoYgUbjfruFzMaQnlhpiGPwNOkDICx=[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v2/operator/highlights'
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams(uhd=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(page_int),'pocType':'APP_X_TVING_4.0.0',}
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if not('result' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']):return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVH=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']
   for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDIVH:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKe=qoYgUbjfruFzMaQnlhpiGPwNOkDICS['content']['movie']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKv =qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['code']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVe =qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['name']['ko'].strip()
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAT =qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['name']['ko'].strip()
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKs =qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['product_year']
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIKs:qoYgUbjfruFzMaQnlhpiGPwNOkDIVe+=u' (%s)'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['product_year'])
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVv =qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['story']['ko']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAR =qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['duration']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ =qoYgUbjfruFzMaQnlhpiGPwNOkDIdm.get(qoYgUbjfruFzMaQnlhpiGPwNOkDIKe.get('grade_code'))
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAx =qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['production']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKd=''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=''
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKT =[]
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKc =[]
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKX=[]
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKx =''
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIKA in qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['image']:
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIM2100':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIM0400':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
     elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['code']=='CAIM1800':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA['url']
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['release_date']not in[qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,0]:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKL=qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['release_date'])
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIKL!='0':qoYgUbjfruFzMaQnlhpiGPwNOkDIKx='%s-%s-%s'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[:4],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[4:6],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[6:])
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIKe.get('category1_name').get('ko')!='':
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKT.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['category1_name']['ko'])
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIKe.get('category2_name').get('ko')!='':
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKT.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKe['category2_name']['ko'])
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIKt in qoYgUbjfruFzMaQnlhpiGPwNOkDIKe.get('actor'):
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIKt!='':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKt)
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIKR in qoYgUbjfruFzMaQnlhpiGPwNOkDIKe.get('director'):
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIKR!='':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKR)
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'moviecode':qoYgUbjfruFzMaQnlhpiGPwNOkDIKv,'title':qoYgUbjfruFzMaQnlhpiGPwNOkDIVe,'thumbnail':{'poster':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd,'thumb':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB,'clearlogo':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy,'fanart':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB},'year':qoYgUbjfruFzMaQnlhpiGPwNOkDIKs,'info_title':qoYgUbjfruFzMaQnlhpiGPwNOkDIAT,'synopsis':qoYgUbjfruFzMaQnlhpiGPwNOkDIVv,'mpaa':qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ,'duration':qoYgUbjfruFzMaQnlhpiGPwNOkDIAR,'premiered':qoYgUbjfruFzMaQnlhpiGPwNOkDIKx,'studio':qoYgUbjfruFzMaQnlhpiGPwNOkDIAx,'info_genre':qoYgUbjfruFzMaQnlhpiGPwNOkDIKT,'cast':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc,'director':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX,}
    qoYgUbjfruFzMaQnlhpiGPwNOkDICx.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
 def GetMovieGenre(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA):
  qoYgUbjfruFzMaQnlhpiGPwNOkDICx=[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v2/media/movie/curations'
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if not('result' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']):return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVH=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']
   for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDIVH:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAS =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['curation_code']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAE =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['curation_name']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'curation_code':qoYgUbjfruFzMaQnlhpiGPwNOkDIAS,'curation_name':qoYgUbjfruFzMaQnlhpiGPwNOkDIAE}
    qoYgUbjfruFzMaQnlhpiGPwNOkDICx.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
 def GetSearchList(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,search_key,page_int,stype):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIAW=[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXm
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/search/getSearch.jsp'
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.SCREENCODE,'os':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.OSCODE,'network':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.APIKEY,'networkCode':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.NETWORKCODE,'osCode ':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.OSCODE,'teleCode ':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TELECODE,'screenCode ':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.SCREENCODE}
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.SEARCH_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICL,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if stype=='vod':
    if not('programRsb' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH):return qoYgUbjfruFzMaQnlhpiGPwNOkDIAW,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAe=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['programRsb']['dataList']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAv =qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(qoYgUbjfruFzMaQnlhpiGPwNOkDICH['programRsb']['count'])
    for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDIAe:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKE=qoYgUbjfruFzMaQnlhpiGPwNOkDICS['mast_cd']
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVe =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['mast_nm']
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKd=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICS['web_url4']
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICS['web_url']
     try:
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKc =[]
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKX=[]
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKT =[]
      qoYgUbjfruFzMaQnlhpiGPwNOkDIAR =0
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ =''
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKs =''
      qoYgUbjfruFzMaQnlhpiGPwNOkDIAJ =''
      if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('actor') !='' and qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('actor') !='-':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc =qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('actor').split(',')
      if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('director')!='' and qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('director')!='-':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX=qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('director').split(',')
      if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('cate_nm')!='' and qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('cate_nm')!='-':qoYgUbjfruFzMaQnlhpiGPwNOkDIKT =qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('cate_nm').split('/')
      if 'targetage' in qoYgUbjfruFzMaQnlhpiGPwNOkDICS:qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ=qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('targetage')
      if 'broad_dt' in qoYgUbjfruFzMaQnlhpiGPwNOkDICS:
       qoYgUbjfruFzMaQnlhpiGPwNOkDIKL=qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('broad_dt')
       qoYgUbjfruFzMaQnlhpiGPwNOkDIAJ='%s-%s-%s'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[:4],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[4:6],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[6:])
       qoYgUbjfruFzMaQnlhpiGPwNOkDIKs =qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[:4]
     except:
      qoYgUbjfruFzMaQnlhpiGPwNOkDIXC
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'program':qoYgUbjfruFzMaQnlhpiGPwNOkDIKE,'title':qoYgUbjfruFzMaQnlhpiGPwNOkDIVe,'thumbnail':{'poster':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd,'thumb':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB,'fanart':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB},'synopsis':'','cast':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc,'director':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX,'info_genre':qoYgUbjfruFzMaQnlhpiGPwNOkDIKT,'duration':qoYgUbjfruFzMaQnlhpiGPwNOkDIAR,'mpaa':qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ,'year':qoYgUbjfruFzMaQnlhpiGPwNOkDIKs,'aired':qoYgUbjfruFzMaQnlhpiGPwNOkDIAJ}
     qoYgUbjfruFzMaQnlhpiGPwNOkDIAW.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
   else:
    if not('vodMVRsb' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH):return qoYgUbjfruFzMaQnlhpiGPwNOkDIAW,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAB=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['vodMVRsb']['dataList']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIAv =qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(qoYgUbjfruFzMaQnlhpiGPwNOkDICH['vodMVRsb']['count'])
    for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDIAB:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKE=qoYgUbjfruFzMaQnlhpiGPwNOkDICS['mast_cd']
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVe =qoYgUbjfruFzMaQnlhpiGPwNOkDICS['mast_nm'].strip()
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICS['web_url']
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIKd
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=''
     try:
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKc =[]
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKX=[]
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKT =[]
      qoYgUbjfruFzMaQnlhpiGPwNOkDIAR =0
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ =''
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKs =''
      qoYgUbjfruFzMaQnlhpiGPwNOkDIAJ =''
      if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('actor') !='' and qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('actor') !='-':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc =qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('actor').split(',')
      if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('director')!='' and qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('director')!='-':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX=qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('director').split(',')
      if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('cate_nm')!='' and qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('cate_nm')!='-':qoYgUbjfruFzMaQnlhpiGPwNOkDIKT =qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('cate_nm').split('/')
      if qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('runtime_sec')!='':qoYgUbjfruFzMaQnlhpiGPwNOkDIAR=qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('runtime_sec')
      if 'grade_nm' in qoYgUbjfruFzMaQnlhpiGPwNOkDICS:qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ=qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('grade_nm')
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKL=qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('broad_dt')
      if data_str!='':
       qoYgUbjfruFzMaQnlhpiGPwNOkDIAJ='%s-%s-%s'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[:4],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[4:6],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[6:])
       qoYgUbjfruFzMaQnlhpiGPwNOkDIKs =qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[:4]
     except:
      qoYgUbjfruFzMaQnlhpiGPwNOkDIXC
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'movie':qoYgUbjfruFzMaQnlhpiGPwNOkDIKE,'title':qoYgUbjfruFzMaQnlhpiGPwNOkDIVe,'thumbnail':{'poster':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd,'thumb':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB,'fanart':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB,'clearlogo':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy},'synopsis':'','cast':qoYgUbjfruFzMaQnlhpiGPwNOkDIKc,'director':qoYgUbjfruFzMaQnlhpiGPwNOkDIKX,'info_genre':qoYgUbjfruFzMaQnlhpiGPwNOkDIKT,'duration':qoYgUbjfruFzMaQnlhpiGPwNOkDIAR,'mpaa':qoYgUbjfruFzMaQnlhpiGPwNOkDIKJ,'year':qoYgUbjfruFzMaQnlhpiGPwNOkDIKs,'aired':qoYgUbjfruFzMaQnlhpiGPwNOkDIAJ}
     qoYgUbjfruFzMaQnlhpiGPwNOkDIAW.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIAv>(page_int*qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.SEARCH_LIMIT):qoYgUbjfruFzMaQnlhpiGPwNOkDIVR=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIAW,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
 def GetBookmarkInfo(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,videoid,vidtype):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIcd={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+'/v2/media/program/'+videoid
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'pageNo':'1','pageSize':'10','order':'name',}
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKB=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if not('body' in qoYgUbjfruFzMaQnlhpiGPwNOkDIKB):return{}
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcy=qoYgUbjfruFzMaQnlhpiGPwNOkDIKB['body']
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVe=qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('name').get('ko').strip()
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['title'] =qoYgUbjfruFzMaQnlhpiGPwNOkDIVe
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['title']=qoYgUbjfruFzMaQnlhpiGPwNOkDIVe
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['mpaa'] =qoYgUbjfruFzMaQnlhpiGPwNOkDIdm.get(qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('grade_code'))
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['plot'] =qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('synopsis').get('ko')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['year'] =qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('product_year')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['cast'] =qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('actor')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['director']=qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('director')
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('category1_name').get('ko')!='':
    qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['genre'].append(qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('category1_name').get('ko'))
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('category2_name').get('ko')!='':
    qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['genre'].append(qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('category2_name').get('ko'))
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKL=qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('broad_dt'))
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIKL!='0':qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[:4],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[4:6],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[6:])
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =''
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =''
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=''
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKC =''
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKm =''
   for qoYgUbjfruFzMaQnlhpiGPwNOkDIKA in qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('image'):
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('code')=='CAIP0900':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('url')
    elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('code')=='CAIP0200':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('url')
    elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('code')=='CAIP1800':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('url')
    elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('code')=='CAIP2000':qoYgUbjfruFzMaQnlhpiGPwNOkDIKC =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('url')
    elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('code')=='CAIP1900':qoYgUbjfruFzMaQnlhpiGPwNOkDIKm =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('url')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['thumbnail']['poster']=qoYgUbjfruFzMaQnlhpiGPwNOkDIKd
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['thumbnail']['thumb']=qoYgUbjfruFzMaQnlhpiGPwNOkDIVB
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['thumbnail']['clearlogo']=qoYgUbjfruFzMaQnlhpiGPwNOkDIKy
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['thumbnail']['icon']=qoYgUbjfruFzMaQnlhpiGPwNOkDIKC
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['thumbnail']['banner']=qoYgUbjfruFzMaQnlhpiGPwNOkDIKm
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['thumbnail']['fanart']=qoYgUbjfruFzMaQnlhpiGPwNOkDIVB
  else:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+'/v2a/media/stream/info'
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies']['tving_uuid'].split('-')[0],'uuid':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetNoCache(1)),'wm':'Y',}
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKB=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if not('content' in qoYgUbjfruFzMaQnlhpiGPwNOkDIKB['body']):return{}
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcy=qoYgUbjfruFzMaQnlhpiGPwNOkDIKB['body']['content']['info']['movie']
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVe =qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('name').get('ko').strip()
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['title']=qoYgUbjfruFzMaQnlhpiGPwNOkDIVe
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVe +=u' (%s)'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('product_year'))
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['title'] =qoYgUbjfruFzMaQnlhpiGPwNOkDIVe
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['mpaa'] =qoYgUbjfruFzMaQnlhpiGPwNOkDIdm.get(qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('grade_code'))
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['plot'] =qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('story').get('ko')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['year'] =qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('product_year')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['studio'] =qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('production')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['duration']=qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('duration')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['cast'] =qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('actor')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['director']=qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('director')
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('category1_name').get('ko')!='':
    qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['genre'].append(qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('category1_name').get('ko'))
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('category2_name').get('ko')!='':
    qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['genre'].append(qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('category2_name').get('ko'))
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKL=qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('release_date'))
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIKL!='0':qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[:4],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[4:6],qoYgUbjfruFzMaQnlhpiGPwNOkDIKL[6:])
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKd=''
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =''
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=''
   for qoYgUbjfruFzMaQnlhpiGPwNOkDIKA in qoYgUbjfruFzMaQnlhpiGPwNOkDIcy.get('image'):
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('code')=='CAIM2100':qoYgUbjfruFzMaQnlhpiGPwNOkDIKd =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('url')
    elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('code')=='CAIM0400':qoYgUbjfruFzMaQnlhpiGPwNOkDIVB =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('url')
    elif qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('code')=='CAIM1800':qoYgUbjfruFzMaQnlhpiGPwNOkDIKy=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.IMG_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDIKA.get('url')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['thumbnail']['poster']=qoYgUbjfruFzMaQnlhpiGPwNOkDIKd
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['thumbnail']['thumb']=qoYgUbjfruFzMaQnlhpiGPwNOkDIKd 
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['thumbnail']['clearlogo']=qoYgUbjfruFzMaQnlhpiGPwNOkDIKy
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcd['saveinfo']['thumbnail']['fanart']=qoYgUbjfruFzMaQnlhpiGPwNOkDIVB
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIcd
 def GetEuroChannelList(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA):
  qoYgUbjfruFzMaQnlhpiGPwNOkDICx=[]
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v2/operator/highlights'
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetNoCache(2))}
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if not('result' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']):return qoYgUbjfruFzMaQnlhpiGPwNOkDICx,qoYgUbjfruFzMaQnlhpiGPwNOkDIVR
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVH=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcC =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Get_Now_Datetime()
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcm=qoYgUbjfruFzMaQnlhpiGPwNOkDIcC+datetime.timedelta(days=-1)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcm=qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(qoYgUbjfruFzMaQnlhpiGPwNOkDIcm.strftime('%Y%m%d'))
   for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDIVH:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIcV=qoYgUbjfruFzMaQnlhpiGPwNOkDIXT(qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('content').get('banner_title2')[:8])
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIcm<=qoYgUbjfruFzMaQnlhpiGPwNOkDIcV:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'channel':qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('content').get('banner_sub_title3'),'title':qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('content').get('banner_title'),'subtitle':qoYgUbjfruFzMaQnlhpiGPwNOkDICS.get('content').get('banner_sub_title2'),}
     qoYgUbjfruFzMaQnlhpiGPwNOkDICx.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDICx
 def Make_DecryptKey(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,step,mediacode='000',timecode='000'):
  if step=='1':
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyT=qoYgUbjfruFzMaQnlhpiGPwNOkDIXJ('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIys=qoYgUbjfruFzMaQnlhpiGPwNOkDIXJ('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyT=qoYgUbjfruFzMaQnlhpiGPwNOkDIXJ('kss2lym0kdw1lks3','utf-8')
   qoYgUbjfruFzMaQnlhpiGPwNOkDIys=qoYgUbjfruFzMaQnlhpiGPwNOkDIXJ([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIyT,qoYgUbjfruFzMaQnlhpiGPwNOkDIys
 def DecryptPlaintext(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,qoYgUbjfruFzMaQnlhpiGPwNOkDIyR,qoYgUbjfruFzMaQnlhpiGPwNOkDIyJ,qoYgUbjfruFzMaQnlhpiGPwNOkDIyx):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyt=AES.new(qoYgUbjfruFzMaQnlhpiGPwNOkDIyJ,AES.MODE_CBC,qoYgUbjfruFzMaQnlhpiGPwNOkDIyx,)
  qoYgUbjfruFzMaQnlhpiGPwNOkDIyL=Padding.unpad(qoYgUbjfruFzMaQnlhpiGPwNOkDIyt.decrypt(base64.standard_b64decode(qoYgUbjfruFzMaQnlhpiGPwNOkDIyR)),16)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIyL.decode('utf-8')
 def Decrypt_Url(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,qoYgUbjfruFzMaQnlhpiGPwNOkDIyR,mediacode,qoYgUbjfruFzMaQnlhpiGPwNOkDImA):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIcK=''
  qoYgUbjfruFzMaQnlhpiGPwNOkDImc=''
  qoYgUbjfruFzMaQnlhpiGPwNOkDImX=''
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyT,qoYgUbjfruFzMaQnlhpiGPwNOkDIys=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Make_DecryptKey('1',mediacode=mediacode,timecode=qoYgUbjfruFzMaQnlhpiGPwNOkDImA)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcA=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.DecryptPlaintext(qoYgUbjfruFzMaQnlhpiGPwNOkDIyR,qoYgUbjfruFzMaQnlhpiGPwNOkDIyT,qoYgUbjfruFzMaQnlhpiGPwNOkDIys))
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(qoYgUbjfruFzMaQnlhpiGPwNOkDIcA)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcX =qoYgUbjfruFzMaQnlhpiGPwNOkDIcA.get('url')
   qoYgUbjfruFzMaQnlhpiGPwNOkDImc =qoYgUbjfruFzMaQnlhpiGPwNOkDIcA.get('watermark') if 'watermark' in qoYgUbjfruFzMaQnlhpiGPwNOkDIcA else ''
   qoYgUbjfruFzMaQnlhpiGPwNOkDImX=qoYgUbjfruFzMaQnlhpiGPwNOkDIcA.get('watermark_key')if 'watermark_key' in qoYgUbjfruFzMaQnlhpiGPwNOkDIcA else ''
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyT,qoYgUbjfruFzMaQnlhpiGPwNOkDIys=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Make_DecryptKey('2',mediacode=mediacode,timecode=qoYgUbjfruFzMaQnlhpiGPwNOkDImA)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcK=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.DecryptPlaintext(qoYgUbjfruFzMaQnlhpiGPwNOkDIcX,qoYgUbjfruFzMaQnlhpiGPwNOkDIyT,qoYgUbjfruFzMaQnlhpiGPwNOkDIys)
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIcK,qoYgUbjfruFzMaQnlhpiGPwNOkDImc,qoYgUbjfruFzMaQnlhpiGPwNOkDImX
 def Get_Apple_buildId(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIcT=''
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW ='https://www.tving.com/more/special/SP0071'
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcs=r'"buildId":"(.*?)"'
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcT =re.compile(qoYgUbjfruFzMaQnlhpiGPwNOkDIcs,re.DOTALL).findall(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)[0]
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIcT
 def Get_AppleGroup_List(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIcJ=[]
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcT=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Get_Apple_buildId()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/_next/data/{}/ko/more/special/SP0071.json'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDIcT)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'key':'SP0071'}
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.URL_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICL,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKB=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if not('pageProps' in qoYgUbjfruFzMaQnlhpiGPwNOkDIKB):return qoYgUbjfruFzMaQnlhpiGPwNOkDIcJ
   qoYgUbjfruFzMaQnlhpiGPwNOkDIVH=qoYgUbjfruFzMaQnlhpiGPwNOkDIKB['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
   for qoYgUbjfruFzMaQnlhpiGPwNOkDIcx in qoYgUbjfruFzMaQnlhpiGPwNOkDIVH:
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIcx['bandType']not in['VOD_BASIC']:continue
    qoYgUbjfruFzMaQnlhpiGPwNOkDIct =re.findall('/band/\w+|/curation/\w+',qoYgUbjfruFzMaQnlhpiGPwNOkDIcx['moreUrl'])[0]
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'bandName':qoYgUbjfruFzMaQnlhpiGPwNOkDIcx['bandName'],'bandKey':qoYgUbjfruFzMaQnlhpiGPwNOkDIct.split('/')[2],'moreUrl':qoYgUbjfruFzMaQnlhpiGPwNOkDIct,}
    qoYgUbjfruFzMaQnlhpiGPwNOkDIcJ.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIcJ
 def Get_Band_VodList(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,bandKey,qoYgUbjfruFzMaQnlhpiGPwNOkDIct,nextApiUrl='-'):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIcR =[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDIcL =''
  try:
   if nextApiUrl in[qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,'','-']:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIcT=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Get_Apple_buildId()
    qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/_next/data/{}/ko/more{}.json'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDIcT,qoYgUbjfruFzMaQnlhpiGPwNOkDIct)
    qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'key':bandKey}
    qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.URL_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
    qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICL,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKB=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
    if not('pageProps' in qoYgUbjfruFzMaQnlhpiGPwNOkDIKB):return qoYgUbjfruFzMaQnlhpiGPwNOkDIcR,qoYgUbjfruFzMaQnlhpiGPwNOkDIcL
    if 'band' in qoYgUbjfruFzMaQnlhpiGPwNOkDIct:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVH=qoYgUbjfruFzMaQnlhpiGPwNOkDIKB['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['band']
    else:
     qoYgUbjfruFzMaQnlhpiGPwNOkDIVH=qoYgUbjfruFzMaQnlhpiGPwNOkDIKB['pageProps']['dehydratedState']['queries'][0]['state']['data']['data']['bands'][0]
   else:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIyW='{}{}{}'.format('https://gw.tving.com',nextApiUrl,'&screenCode=CSSD0100&osCode=CSOD0900')
    qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKB=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
    if not('data' in qoYgUbjfruFzMaQnlhpiGPwNOkDIKB):return qoYgUbjfruFzMaQnlhpiGPwNOkDIcR,qoYgUbjfruFzMaQnlhpiGPwNOkDIcL
    qoYgUbjfruFzMaQnlhpiGPwNOkDIVH=qoYgUbjfruFzMaQnlhpiGPwNOkDIKB['data']
   for qoYgUbjfruFzMaQnlhpiGPwNOkDIcx in qoYgUbjfruFzMaQnlhpiGPwNOkDIVH['items']:
    qoYgUbjfruFzMaQnlhpiGPwNOkDIcH=qoYgUbjfruFzMaQnlhpiGPwNOkDIcx['imageUrl']
    qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'program':qoYgUbjfruFzMaQnlhpiGPwNOkDIcx['code'],'title':qoYgUbjfruFzMaQnlhpiGPwNOkDIcx['title'],'thumbnail':{'poster':qoYgUbjfruFzMaQnlhpiGPwNOkDIcH,'thumb':qoYgUbjfruFzMaQnlhpiGPwNOkDIcH,'fanart':qoYgUbjfruFzMaQnlhpiGPwNOkDIcH},}
    qoYgUbjfruFzMaQnlhpiGPwNOkDIcR.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcL=qoYgUbjfruFzMaQnlhpiGPwNOkDIVH.get('nextApiUrl')or ''
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIcR,qoYgUbjfruFzMaQnlhpiGPwNOkDIcL
 def Get_Apple_NowList(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA):
  qoYgUbjfruFzMaQnlhpiGPwNOkDIcR =[]
  qoYgUbjfruFzMaQnlhpiGPwNOkDIcL ='-'
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcT=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Get_Apple_buildId()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/_next/data/{}/ko/more/special/SP0071.json'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDIcT)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'key':'SP0071'}
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.URL_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICL,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKB=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIKB=qoYgUbjfruFzMaQnlhpiGPwNOkDIKB['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
   for qoYgUbjfruFzMaQnlhpiGPwNOkDIcS in qoYgUbjfruFzMaQnlhpiGPwNOkDIKB:
    if qoYgUbjfruFzMaQnlhpiGPwNOkDIcS['bandType']=='VOD_BASIC_RANKING':
     for qoYgUbjfruFzMaQnlhpiGPwNOkDIcx in qoYgUbjfruFzMaQnlhpiGPwNOkDIcS['items']:
      qoYgUbjfruFzMaQnlhpiGPwNOkDIcH=qoYgUbjfruFzMaQnlhpiGPwNOkDIcx['imageUrl']
      qoYgUbjfruFzMaQnlhpiGPwNOkDIKS={'program':qoYgUbjfruFzMaQnlhpiGPwNOkDIcx['code'],'title':qoYgUbjfruFzMaQnlhpiGPwNOkDIcx['title'],'thumbnail':{'poster':qoYgUbjfruFzMaQnlhpiGPwNOkDIcH,'thumb':qoYgUbjfruFzMaQnlhpiGPwNOkDIcH,'fanart':qoYgUbjfruFzMaQnlhpiGPwNOkDIcH},}
      qoYgUbjfruFzMaQnlhpiGPwNOkDIcR.append(qoYgUbjfruFzMaQnlhpiGPwNOkDIKS)
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
  return qoYgUbjfruFzMaQnlhpiGPwNOkDIcR,qoYgUbjfruFzMaQnlhpiGPwNOkDIcL
 def GetLiveURL_Test(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA,mediacode,sel_quality):
  qoYgUbjfruFzMaQnlhpiGPwNOkDICW ={'streaming_url':'','subtitleYn':qoYgUbjfruFzMaQnlhpiGPwNOkDIXm,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  qoYgUbjfruFzMaQnlhpiGPwNOkDICt =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies']['tving_uuid'].split('-')[0] 
  qoYgUbjfruFzMaQnlhpiGPwNOkDICe =qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.TV['cookies']['tving_uuid'] 
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICv=qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetNoCache(1))
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v2/media/stream/info' 
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':qoYgUbjfruFzMaQnlhpiGPwNOkDICe,'deviceInfo':'PC','noCache':qoYgUbjfruFzMaQnlhpiGPwNOkDICv,}
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.makeDefaultCookies()
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Get',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIdB)
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.status_code!=200:
    qoYgUbjfruFzMaQnlhpiGPwNOkDICW['error_msg']='First Step - {} error'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.status_code)
    return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
   qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']['code']=='060':
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIdW in qoYgUbjfruFzMaQnlhpiGPwNOkDIdC.items():
     if qoYgUbjfruFzMaQnlhpiGPwNOkDIdW==sel_quality:
      qoYgUbjfruFzMaQnlhpiGPwNOkDImd=qoYgUbjfruFzMaQnlhpiGPwNOkDIdE
   elif qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']['code']!='000':
    qoYgUbjfruFzMaQnlhpiGPwNOkDICW['error_msg']=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']['message']
    return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
   else: 
    if not('stream' in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']):return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
    qoYgUbjfruFzMaQnlhpiGPwNOkDImy=[]
    for qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIdW in qoYgUbjfruFzMaQnlhpiGPwNOkDIdC.items():
     for qoYgUbjfruFzMaQnlhpiGPwNOkDICS in qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['stream']['quality']:
      if qoYgUbjfruFzMaQnlhpiGPwNOkDICS['active']=='Y' and qoYgUbjfruFzMaQnlhpiGPwNOkDICS['code']==qoYgUbjfruFzMaQnlhpiGPwNOkDIdE:
       qoYgUbjfruFzMaQnlhpiGPwNOkDImy.append({qoYgUbjfruFzMaQnlhpiGPwNOkDIdC.get(qoYgUbjfruFzMaQnlhpiGPwNOkDICS['code']):qoYgUbjfruFzMaQnlhpiGPwNOkDICS['code']})
    qoYgUbjfruFzMaQnlhpiGPwNOkDImd=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.CheckQuality(sel_quality,qoYgUbjfruFzMaQnlhpiGPwNOkDImy)
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICW['error_msg']='First Step - except error'
   return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
  try:
   qoYgUbjfruFzMaQnlhpiGPwNOkDICv=qoYgUbjfruFzMaQnlhpiGPwNOkDIXV(qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetNoCache(1))
   qoYgUbjfruFzMaQnlhpiGPwNOkDICT ='/v3/media/stream/info'
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.GetDefaultParams()
   qoYgUbjfruFzMaQnlhpiGPwNOkDICL={'mediaCode':mediacode,'deviceId':qoYgUbjfruFzMaQnlhpiGPwNOkDICt,'uuid':qoYgUbjfruFzMaQnlhpiGPwNOkDICe,'deviceInfo':'PC_Chrome','streamCode':qoYgUbjfruFzMaQnlhpiGPwNOkDImd,'noCache':qoYgUbjfruFzMaQnlhpiGPwNOkDICv,'callingFrom':'HTML5','model':qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   qoYgUbjfruFzMaQnlhpiGPwNOkDICB.update(qoYgUbjfruFzMaQnlhpiGPwNOkDICL)
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyW=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.API_DOMAIN+qoYgUbjfruFzMaQnlhpiGPwNOkDICT
   qoYgUbjfruFzMaQnlhpiGPwNOkDIdB=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.makeDefaultCookies()
   qoYgUbjfruFzMaQnlhpiGPwNOkDIyv=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.callRequestCookies('Post',qoYgUbjfruFzMaQnlhpiGPwNOkDIyW,payload=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,params=qoYgUbjfruFzMaQnlhpiGPwNOkDICB,headers=qoYgUbjfruFzMaQnlhpiGPwNOkDIXC,cookies=qoYgUbjfruFzMaQnlhpiGPwNOkDIdB,redirects=qoYgUbjfruFzMaQnlhpiGPwNOkDIXA)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICH=json.loads(qoYgUbjfruFzMaQnlhpiGPwNOkDIyv.text)
   if qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']['code']!='000':
    qoYgUbjfruFzMaQnlhpiGPwNOkDICW['error_msg']=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['result']['message']
    return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
   qoYgUbjfruFzMaQnlhpiGPwNOkDImC=qoYgUbjfruFzMaQnlhpiGPwNOkDICH['body']['stream']
   if qoYgUbjfruFzMaQnlhpiGPwNOkDImC['drm_yn']=='Y':
    qoYgUbjfruFzMaQnlhpiGPwNOkDImV=qoYgUbjfruFzMaQnlhpiGPwNOkDImC['playback']['drm']['widevine']
    for qoYgUbjfruFzMaQnlhpiGPwNOkDImK in qoYgUbjfruFzMaQnlhpiGPwNOkDImC['playback']['drm']['license']['drm_license_data']:
     if qoYgUbjfruFzMaQnlhpiGPwNOkDImK['drm_type']=='Widevine':
      qoYgUbjfruFzMaQnlhpiGPwNOkDICW['drm_server_url'] =qoYgUbjfruFzMaQnlhpiGPwNOkDImK['drm_server_url']
      qoYgUbjfruFzMaQnlhpiGPwNOkDICW['drm_header_key'] =qoYgUbjfruFzMaQnlhpiGPwNOkDImK['drm_header_key']
      qoYgUbjfruFzMaQnlhpiGPwNOkDICW['drm_header_value']=qoYgUbjfruFzMaQnlhpiGPwNOkDImK['drm_header_value']
      break
   else:
    qoYgUbjfruFzMaQnlhpiGPwNOkDImV=qoYgUbjfruFzMaQnlhpiGPwNOkDImC['playback']['non_drm']
  except qoYgUbjfruFzMaQnlhpiGPwNOkDIXx as exception:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(exception)
   qoYgUbjfruFzMaQnlhpiGPwNOkDICW['error_msg']='Second Step - except error'
   return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
  qoYgUbjfruFzMaQnlhpiGPwNOkDImA=qoYgUbjfruFzMaQnlhpiGPwNOkDICv
  qoYgUbjfruFzMaQnlhpiGPwNOkDImV=qoYgUbjfruFzMaQnlhpiGPwNOkDImV.split('|')[1]
  qoYgUbjfruFzMaQnlhpiGPwNOkDImV,qoYgUbjfruFzMaQnlhpiGPwNOkDImc,qoYgUbjfruFzMaQnlhpiGPwNOkDImX=qoYgUbjfruFzMaQnlhpiGPwNOkDIdA.Decrypt_Url(qoYgUbjfruFzMaQnlhpiGPwNOkDImV,mediacode,qoYgUbjfruFzMaQnlhpiGPwNOkDImA)
  qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url']=qoYgUbjfruFzMaQnlhpiGPwNOkDImV
  qoYgUbjfruFzMaQnlhpiGPwNOkDIcE =qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url'].find('Policy=')
  if qoYgUbjfruFzMaQnlhpiGPwNOkDIcE!=-1:
   qoYgUbjfruFzMaQnlhpiGPwNOkDIcW =qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url'].split('?')[0]
   qoYgUbjfruFzMaQnlhpiGPwNOkDIce=qoYgUbjfruFzMaQnlhpiGPwNOkDIXt(urllib.parse.parse_qsl(urllib.parse.urlsplit(qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url']).query))
   qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url']='{}&CloudFront-Policy={}'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url'],qoYgUbjfruFzMaQnlhpiGPwNOkDIce['Policy'])
   qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url']='{}&CloudFront-Signature={}'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url'],qoYgUbjfruFzMaQnlhpiGPwNOkDIce['Signature'])
   qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url'],qoYgUbjfruFzMaQnlhpiGPwNOkDIce['Key-Pair-Id'])
  qoYgUbjfruFzMaQnlhpiGPwNOkDIcv=['_tving_token','accessToken','authToken',]
  for qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIdW in qoYgUbjfruFzMaQnlhpiGPwNOkDIdB.items():
   if qoYgUbjfruFzMaQnlhpiGPwNOkDIdE in qoYgUbjfruFzMaQnlhpiGPwNOkDIcv:
    qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url']='{}&{}={}'.format(qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url'],qoYgUbjfruFzMaQnlhpiGPwNOkDIdE,qoYgUbjfruFzMaQnlhpiGPwNOkDIdW)
  qoYgUbjfruFzMaQnlhpiGPwNOkDIcB(qoYgUbjfruFzMaQnlhpiGPwNOkDICW['streaming_url'])
  return qoYgUbjfruFzMaQnlhpiGPwNOkDICW
# Created by pyminifier (https://github.com/liftoff/pyminifier)
