__author__="NightRain"
GdceyHwJKozPBYXiApuVNmMOLsfjtQ=object
GdceyHwJKozPBYXiApuVNmMOLsfjtF=None
GdceyHwJKozPBYXiApuVNmMOLsfjtg=int
GdceyHwJKozPBYXiApuVNmMOLsfjtE=False
GdceyHwJKozPBYXiApuVNmMOLsfjtW=True
GdceyHwJKozPBYXiApuVNmMOLsfjtn=type
GdceyHwJKozPBYXiApuVNmMOLsfjtI=dict
GdceyHwJKozPBYXiApuVNmMOLsfjtR=getattr
GdceyHwJKozPBYXiApuVNmMOLsfjth=list
GdceyHwJKozPBYXiApuVNmMOLsfjtx=len
GdceyHwJKozPBYXiApuVNmMOLsfjtC=str
GdceyHwJKozPBYXiApuVNmMOLsfjtl=range
GdceyHwJKozPBYXiApuVNmMOLsfjtk=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
GdceyHwJKozPBYXiApuVNmMOLsfjDb=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'티빙 오리지날','mode':'BAND_VODLIST','bandKey':'HM200935','moreUrl':'/band/HM200935'},{'title':'실시간 인기 드라마','mode':'BAND_VODLIST','bandKey':'HM165416','moreUrl':'/band/HM165416'},{'title':'실시간 인기 예능','mode':'BAND_VODLIST','bandKey':'HM156521','moreUrl':'/band/HM156521'},{'title':'실시간 인기 영화','mode':'BAND_VODLIST','bandKey':'HM200932','moreUrl':'/band/HM200932'},{'title':'Apple TV+ 실시간 인기','mode':'BAND_VODLIST','bandKey':'HM192222','moreUrl':'/band/HM192222'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'Apple TV+','mode':'APPLE_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'},]
GdceyHwJKozPBYXiApuVNmMOLsfjDT=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
GdceyHwJKozPBYXiApuVNmMOLsfjDQ=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
GdceyHwJKozPBYXiApuVNmMOLsfjDF=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
GdceyHwJKozPBYXiApuVNmMOLsfjDg=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
GdceyHwJKozPBYXiApuVNmMOLsfjDE=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
GdceyHwJKozPBYXiApuVNmMOLsfjDt=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
GdceyHwJKozPBYXiApuVNmMOLsfjDW={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
GdceyHwJKozPBYXiApuVNmMOLsfjDn =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
GdceyHwJKozPBYXiApuVNmMOLsfjDI=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class GdceyHwJKozPBYXiApuVNmMOLsfjDv(GdceyHwJKozPBYXiApuVNmMOLsfjtQ):
 def __init__(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjDh,GdceyHwJKozPBYXiApuVNmMOLsfjDx,GdceyHwJKozPBYXiApuVNmMOLsfjDC):
  GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_url =GdceyHwJKozPBYXiApuVNmMOLsfjDh
  GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle=GdceyHwJKozPBYXiApuVNmMOLsfjDx
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params =GdceyHwJKozPBYXiApuVNmMOLsfjDC
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj =qoYgUbjfruFzMaQnlhpiGPwNOkDIdy() 
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(GdceyHwJKozPBYXiApuVNmMOLsfjDR,sting):
  try:
   GdceyHwJKozPBYXiApuVNmMOLsfjDk=xbmcgui.Dialog()
   GdceyHwJKozPBYXiApuVNmMOLsfjDk.notification(__addonname__,sting)
  except:
   GdceyHwJKozPBYXiApuVNmMOLsfjtF
 def addon_log(GdceyHwJKozPBYXiApuVNmMOLsfjDR,string):
  try:
   GdceyHwJKozPBYXiApuVNmMOLsfjDq=string.encode('utf-8','ignore')
  except:
   GdceyHwJKozPBYXiApuVNmMOLsfjDq='addonException: addon_log'
  GdceyHwJKozPBYXiApuVNmMOLsfjDS=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,GdceyHwJKozPBYXiApuVNmMOLsfjDq),level=GdceyHwJKozPBYXiApuVNmMOLsfjDS)
 def get_keyboard_input(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjvC):
  GdceyHwJKozPBYXiApuVNmMOLsfjDa=GdceyHwJKozPBYXiApuVNmMOLsfjtF
  kb=xbmc.Keyboard()
  kb.setHeading(GdceyHwJKozPBYXiApuVNmMOLsfjvC)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   GdceyHwJKozPBYXiApuVNmMOLsfjDa=kb.getText()
  return GdceyHwJKozPBYXiApuVNmMOLsfjDa
 def get_settings_account(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  GdceyHwJKozPBYXiApuVNmMOLsfjDU =__addon__.getSetting('id')
  GdceyHwJKozPBYXiApuVNmMOLsfjDr =__addon__.getSetting('pw')
  GdceyHwJKozPBYXiApuVNmMOLsfjvD =__addon__.getSetting('login_type')
  GdceyHwJKozPBYXiApuVNmMOLsfjvb=GdceyHwJKozPBYXiApuVNmMOLsfjtg(__addon__.getSetting('selected_profile'))
  return(GdceyHwJKozPBYXiApuVNmMOLsfjDU,GdceyHwJKozPBYXiApuVNmMOLsfjDr,GdceyHwJKozPBYXiApuVNmMOLsfjvD,GdceyHwJKozPBYXiApuVNmMOLsfjvb)
 def get_settings_uhd(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  return GdceyHwJKozPBYXiApuVNmMOLsfjtE
 def get_settings_playback(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  GdceyHwJKozPBYXiApuVNmMOLsfjvT={'active_uhd':GdceyHwJKozPBYXiApuVNmMOLsfjtW if __addon__.getSetting('active_uhd')=='true' else GdceyHwJKozPBYXiApuVNmMOLsfjtE,'streamFilename':GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.TV_STREAM_FILENAME,}
  return GdceyHwJKozPBYXiApuVNmMOLsfjvT
 def get_settings_proxyport(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  GdceyHwJKozPBYXiApuVNmMOLsfjvQ =GdceyHwJKozPBYXiApuVNmMOLsfjtW if __addon__.getSetting('proxyYn')=='true' else GdceyHwJKozPBYXiApuVNmMOLsfjtE
  GdceyHwJKozPBYXiApuVNmMOLsfjvF=GdceyHwJKozPBYXiApuVNmMOLsfjtg(__addon__.getSetting('proxyPort'))
  return GdceyHwJKozPBYXiApuVNmMOLsfjvQ,GdceyHwJKozPBYXiApuVNmMOLsfjvF
 def get_settings_totalsearch(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  GdceyHwJKozPBYXiApuVNmMOLsfjvg =GdceyHwJKozPBYXiApuVNmMOLsfjtW if __addon__.getSetting('local_search')=='true' else GdceyHwJKozPBYXiApuVNmMOLsfjtE
  GdceyHwJKozPBYXiApuVNmMOLsfjvE=GdceyHwJKozPBYXiApuVNmMOLsfjtW if __addon__.getSetting('local_history')=='true' else GdceyHwJKozPBYXiApuVNmMOLsfjtE
  GdceyHwJKozPBYXiApuVNmMOLsfjvt =GdceyHwJKozPBYXiApuVNmMOLsfjtW if __addon__.getSetting('total_search')=='true' else GdceyHwJKozPBYXiApuVNmMOLsfjtE
  GdceyHwJKozPBYXiApuVNmMOLsfjvW=GdceyHwJKozPBYXiApuVNmMOLsfjtW if __addon__.getSetting('total_history')=='true' else GdceyHwJKozPBYXiApuVNmMOLsfjtE
  GdceyHwJKozPBYXiApuVNmMOLsfjvn=GdceyHwJKozPBYXiApuVNmMOLsfjtW if __addon__.getSetting('menu_bookmark')=='true' else GdceyHwJKozPBYXiApuVNmMOLsfjtE
  return(GdceyHwJKozPBYXiApuVNmMOLsfjvg,GdceyHwJKozPBYXiApuVNmMOLsfjvE,GdceyHwJKozPBYXiApuVNmMOLsfjvt,GdceyHwJKozPBYXiApuVNmMOLsfjvW,GdceyHwJKozPBYXiApuVNmMOLsfjvn)
 def get_settings_makebookmark(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  return GdceyHwJKozPBYXiApuVNmMOLsfjtW if __addon__.getSetting('make_bookmark')=='true' else GdceyHwJKozPBYXiApuVNmMOLsfjtE
 def get_settings_direct_replay(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  GdceyHwJKozPBYXiApuVNmMOLsfjvI=GdceyHwJKozPBYXiApuVNmMOLsfjtg(__addon__.getSetting('direct_replay'))
  if GdceyHwJKozPBYXiApuVNmMOLsfjvI==0:
   return GdceyHwJKozPBYXiApuVNmMOLsfjtE
  else:
   return GdceyHwJKozPBYXiApuVNmMOLsfjtW
 def set_winEpisodeOrderby(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjvh):
  __addon__.setSetting('tving_orderby',GdceyHwJKozPBYXiApuVNmMOLsfjvh)
  GdceyHwJKozPBYXiApuVNmMOLsfjvR=xbmcgui.Window(10000)
  GdceyHwJKozPBYXiApuVNmMOLsfjvR.setProperty('TVING_M_ORDERBY',GdceyHwJKozPBYXiApuVNmMOLsfjvh)
 def get_winEpisodeOrderby(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  GdceyHwJKozPBYXiApuVNmMOLsfjvh=__addon__.getSetting('tving_orderby')
  if GdceyHwJKozPBYXiApuVNmMOLsfjvh in['',GdceyHwJKozPBYXiApuVNmMOLsfjtF]:GdceyHwJKozPBYXiApuVNmMOLsfjvh='desc'
  return GdceyHwJKozPBYXiApuVNmMOLsfjvh
 def add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjDR,label,sublabel='',img='',infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params='',isLink=GdceyHwJKozPBYXiApuVNmMOLsfjtE,ContextMenu=GdceyHwJKozPBYXiApuVNmMOLsfjtF):
  GdceyHwJKozPBYXiApuVNmMOLsfjvx='%s?%s'%(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_url,urllib.parse.urlencode(params))
  if sublabel:GdceyHwJKozPBYXiApuVNmMOLsfjvC='%s < %s >'%(label,sublabel)
  else: GdceyHwJKozPBYXiApuVNmMOLsfjvC=label
  if not img:img='DefaultFolder.png'
  GdceyHwJKozPBYXiApuVNmMOLsfjvl=xbmcgui.ListItem(GdceyHwJKozPBYXiApuVNmMOLsfjvC)
  if GdceyHwJKozPBYXiApuVNmMOLsfjtn(img)==GdceyHwJKozPBYXiApuVNmMOLsfjtI:
   GdceyHwJKozPBYXiApuVNmMOLsfjvl.setArt(img)
  else:
   GdceyHwJKozPBYXiApuVNmMOLsfjvl.setArt({'thumb':img,'poster':img})
  if GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.KodiVersion>=20:
   if infoLabels:GdceyHwJKozPBYXiApuVNmMOLsfjDR.Set_InfoTag(GdceyHwJKozPBYXiApuVNmMOLsfjvl.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:GdceyHwJKozPBYXiApuVNmMOLsfjvl.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   GdceyHwJKozPBYXiApuVNmMOLsfjvl.setProperty('IsPlayable','true')
  if ContextMenu:GdceyHwJKozPBYXiApuVNmMOLsfjvl.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,GdceyHwJKozPBYXiApuVNmMOLsfjvx,GdceyHwJKozPBYXiApuVNmMOLsfjvl,isFolder)
 def get_selQuality(GdceyHwJKozPBYXiApuVNmMOLsfjDR,etype):
  try:
   GdceyHwJKozPBYXiApuVNmMOLsfjvk='selected_quality'
   GdceyHwJKozPBYXiApuVNmMOLsfjvq=[1080,720,480,360]
   GdceyHwJKozPBYXiApuVNmMOLsfjvS=GdceyHwJKozPBYXiApuVNmMOLsfjtg(__addon__.getSetting(GdceyHwJKozPBYXiApuVNmMOLsfjvk))
   return GdceyHwJKozPBYXiApuVNmMOLsfjvq[GdceyHwJKozPBYXiApuVNmMOLsfjvS]
  except:
   GdceyHwJKozPBYXiApuVNmMOLsfjtF
  return 720 
 def Set_InfoTag(GdceyHwJKozPBYXiApuVNmMOLsfjDR,video_InfoTag:xbmc.InfoTagVideo,GdceyHwJKozPBYXiApuVNmMOLsfjbF):
  for GdceyHwJKozPBYXiApuVNmMOLsfjva,value in GdceyHwJKozPBYXiApuVNmMOLsfjbF.items():
   if GdceyHwJKozPBYXiApuVNmMOLsfjDW[GdceyHwJKozPBYXiApuVNmMOLsfjva]['type']=='string':
    GdceyHwJKozPBYXiApuVNmMOLsfjtR(video_InfoTag,GdceyHwJKozPBYXiApuVNmMOLsfjDW[GdceyHwJKozPBYXiApuVNmMOLsfjva]['func'])(value)
   elif GdceyHwJKozPBYXiApuVNmMOLsfjDW[GdceyHwJKozPBYXiApuVNmMOLsfjva]['type']=='int':
    if GdceyHwJKozPBYXiApuVNmMOLsfjtn(value)==GdceyHwJKozPBYXiApuVNmMOLsfjtg:
     GdceyHwJKozPBYXiApuVNmMOLsfjvU=GdceyHwJKozPBYXiApuVNmMOLsfjtg(value)
    else:
     GdceyHwJKozPBYXiApuVNmMOLsfjvU=0
    GdceyHwJKozPBYXiApuVNmMOLsfjtR(video_InfoTag,GdceyHwJKozPBYXiApuVNmMOLsfjDW[GdceyHwJKozPBYXiApuVNmMOLsfjva]['func'])(GdceyHwJKozPBYXiApuVNmMOLsfjvU)
   elif GdceyHwJKozPBYXiApuVNmMOLsfjDW[GdceyHwJKozPBYXiApuVNmMOLsfjva]['type']=='actor':
    if value!=[]:
     GdceyHwJKozPBYXiApuVNmMOLsfjtR(video_InfoTag,GdceyHwJKozPBYXiApuVNmMOLsfjDW[GdceyHwJKozPBYXiApuVNmMOLsfjva]['func'])([xbmc.Actor(name)for name in value])
   elif GdceyHwJKozPBYXiApuVNmMOLsfjDW[GdceyHwJKozPBYXiApuVNmMOLsfjva]['type']=='list':
    if GdceyHwJKozPBYXiApuVNmMOLsfjtn(value)==GdceyHwJKozPBYXiApuVNmMOLsfjth:
     GdceyHwJKozPBYXiApuVNmMOLsfjtR(video_InfoTag,GdceyHwJKozPBYXiApuVNmMOLsfjDW[GdceyHwJKozPBYXiApuVNmMOLsfjva]['func'])(value)
    else:
     GdceyHwJKozPBYXiApuVNmMOLsfjtR(video_InfoTag,GdceyHwJKozPBYXiApuVNmMOLsfjDW[GdceyHwJKozPBYXiApuVNmMOLsfjva]['func'])([value])
 def dp_Main_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  (GdceyHwJKozPBYXiApuVNmMOLsfjvg,GdceyHwJKozPBYXiApuVNmMOLsfjvE,GdceyHwJKozPBYXiApuVNmMOLsfjvt,GdceyHwJKozPBYXiApuVNmMOLsfjvW,GdceyHwJKozPBYXiApuVNmMOLsfjvn)=GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_totalsearch()
  for GdceyHwJKozPBYXiApuVNmMOLsfjvr in GdceyHwJKozPBYXiApuVNmMOLsfjDb:
   GdceyHwJKozPBYXiApuVNmMOLsfjvC=GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('title')
   GdceyHwJKozPBYXiApuVNmMOLsfjbD=''
   if GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('mode')=='SEARCH_GROUP' and GdceyHwJKozPBYXiApuVNmMOLsfjvg ==GdceyHwJKozPBYXiApuVNmMOLsfjtE:continue
   elif GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('mode')=='SEARCH_HISTORY' and GdceyHwJKozPBYXiApuVNmMOLsfjvE==GdceyHwJKozPBYXiApuVNmMOLsfjtE:continue
   elif GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('mode')=='TOTAL_SEARCH' and GdceyHwJKozPBYXiApuVNmMOLsfjvt ==GdceyHwJKozPBYXiApuVNmMOLsfjtE:continue
   elif GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('mode')=='TOTAL_HISTORY' and GdceyHwJKozPBYXiApuVNmMOLsfjvW==GdceyHwJKozPBYXiApuVNmMOLsfjtE:continue
   elif GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('mode')=='MENU_BOOKMARK' and GdceyHwJKozPBYXiApuVNmMOLsfjvn==GdceyHwJKozPBYXiApuVNmMOLsfjtE:continue
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('mode'),'stype':GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('stype'),'orderby':GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('orderby'),'ordernm':GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('ordernm'),'page':'1','bandKey':GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('bandKey'),'moreUrl':GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('moreUrl'),'nextApiUrl':'-',}
   if GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    GdceyHwJKozPBYXiApuVNmMOLsfjbT=GdceyHwJKozPBYXiApuVNmMOLsfjtE
    GdceyHwJKozPBYXiApuVNmMOLsfjbQ =GdceyHwJKozPBYXiApuVNmMOLsfjtW
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjbT=GdceyHwJKozPBYXiApuVNmMOLsfjtW
    GdceyHwJKozPBYXiApuVNmMOLsfjbQ =GdceyHwJKozPBYXiApuVNmMOLsfjtE
   GdceyHwJKozPBYXiApuVNmMOLsfjbF={'title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'plot':GdceyHwJKozPBYXiApuVNmMOLsfjvC}
   if GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('mode')=='XXX':GdceyHwJKozPBYXiApuVNmMOLsfjbF=GdceyHwJKozPBYXiApuVNmMOLsfjtF
   if 'icon' in GdceyHwJKozPBYXiApuVNmMOLsfjvr:GdceyHwJKozPBYXiApuVNmMOLsfjbD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',GdceyHwJKozPBYXiApuVNmMOLsfjvr.get('icon')) 
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel='',img=GdceyHwJKozPBYXiApuVNmMOLsfjbD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjbF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjbT,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv,isLink=GdceyHwJKozPBYXiApuVNmMOLsfjbQ)
  xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle)
 def login_main(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  (GdceyHwJKozPBYXiApuVNmMOLsfjbE,GdceyHwJKozPBYXiApuVNmMOLsfjbt,GdceyHwJKozPBYXiApuVNmMOLsfjbW,GdceyHwJKozPBYXiApuVNmMOLsfjbn)=GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_account()
  if not(GdceyHwJKozPBYXiApuVNmMOLsfjbE and GdceyHwJKozPBYXiApuVNmMOLsfjbt):
   GdceyHwJKozPBYXiApuVNmMOLsfjDk=xbmcgui.Dialog()
   GdceyHwJKozPBYXiApuVNmMOLsfjbI=GdceyHwJKozPBYXiApuVNmMOLsfjDk.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if GdceyHwJKozPBYXiApuVNmMOLsfjbI==GdceyHwJKozPBYXiApuVNmMOLsfjtW:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if GdceyHwJKozPBYXiApuVNmMOLsfjDR.cookiefile_check():return
  if base64.standard_b64encode(GdceyHwJKozPBYXiApuVNmMOLsfjbE.encode()).decode('utf-8')=='a3ltOTUxMDg4':
   GdceyHwJKozPBYXiApuVNmMOLsfjbR=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.GetCredential2(GdceyHwJKozPBYXiApuVNmMOLsfjbE,GdceyHwJKozPBYXiApuVNmMOLsfjbt,GdceyHwJKozPBYXiApuVNmMOLsfjbW,GdceyHwJKozPBYXiApuVNmMOLsfjbn)
  else:
   GdceyHwJKozPBYXiApuVNmMOLsfjDk=xbmcgui.Dialog()
   GdceyHwJKozPBYXiApuVNmMOLsfjbh=GdceyHwJKozPBYXiApuVNmMOLsfjDk.browse(1,__language__(30917).encode('utf8'),'','.twc',GdceyHwJKozPBYXiApuVNmMOLsfjtE,GdceyHwJKozPBYXiApuVNmMOLsfjtE,'',GdceyHwJKozPBYXiApuVNmMOLsfjtE)
   if GdceyHwJKozPBYXiApuVNmMOLsfjbh!='':
    GdceyHwJKozPBYXiApuVNmMOLsfjbx=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'))
    xbmcvfs.copy(GdceyHwJKozPBYXiApuVNmMOLsfjbh,GdceyHwJKozPBYXiApuVNmMOLsfjbx)
    GdceyHwJKozPBYXiApuVNmMOLsfjbR=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.WebCookies_Load(GdceyHwJKozPBYXiApuVNmMOLsfjbx)
    xbmcvfs.delete(GdceyHwJKozPBYXiApuVNmMOLsfjbx)
    if GdceyHwJKozPBYXiApuVNmMOLsfjbR:
     GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.JsonFile_Save(GdceyHwJKozPBYXiApuVNmMOLsfjDn,GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.TV)
     GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjbR=GdceyHwJKozPBYXiApuVNmMOLsfjtE
  if GdceyHwJKozPBYXiApuVNmMOLsfjbR==GdceyHwJKozPBYXiApuVNmMOLsfjtW:
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.cookiefile_save()
  else:
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjbC=GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('stype')
  if GdceyHwJKozPBYXiApuVNmMOLsfjbC=='live':
   GdceyHwJKozPBYXiApuVNmMOLsfjbl=GdceyHwJKozPBYXiApuVNmMOLsfjDT
  elif GdceyHwJKozPBYXiApuVNmMOLsfjbC=='vod':
   GdceyHwJKozPBYXiApuVNmMOLsfjbl=GdceyHwJKozPBYXiApuVNmMOLsfjDg
  else:
   GdceyHwJKozPBYXiApuVNmMOLsfjbl=GdceyHwJKozPBYXiApuVNmMOLsfjDE
  for GdceyHwJKozPBYXiApuVNmMOLsfjbk in GdceyHwJKozPBYXiApuVNmMOLsfjbl:
   GdceyHwJKozPBYXiApuVNmMOLsfjvC=GdceyHwJKozPBYXiApuVNmMOLsfjbk.get('title')
   if GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('ordernm')!='-':
    GdceyHwJKozPBYXiApuVNmMOLsfjvC+='  ('+GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('ordernm')+')'
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':GdceyHwJKozPBYXiApuVNmMOLsfjbk.get('mode'),'stype':GdceyHwJKozPBYXiApuVNmMOLsfjbk.get('stype'),'orderby':GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('orderby'),'ordernm':GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('ordernm'),'page':'1'}
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel='',img='',infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  if GdceyHwJKozPBYXiApuVNmMOLsfjtx(GdceyHwJKozPBYXiApuVNmMOLsfjbl)>0:xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle)
 def dp_SubTitle_Group(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq): 
  for GdceyHwJKozPBYXiApuVNmMOLsfjbk in GdceyHwJKozPBYXiApuVNmMOLsfjDt:
   GdceyHwJKozPBYXiApuVNmMOLsfjvC=GdceyHwJKozPBYXiApuVNmMOLsfjbk.get('title')
   if GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('ordernm')!='-':
    GdceyHwJKozPBYXiApuVNmMOLsfjvC+='  ('+GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('ordernm')+')'
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':GdceyHwJKozPBYXiApuVNmMOLsfjbk.get('mode'),'genreCode':GdceyHwJKozPBYXiApuVNmMOLsfjbk.get('genreCode'),'stype':GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('stype'),'orderby':GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('orderby'),'page':'1'}
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel='',img='',infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  if GdceyHwJKozPBYXiApuVNmMOLsfjtx(GdceyHwJKozPBYXiApuVNmMOLsfjDt)>0:xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle)
 def dp_LiveChannel_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjbC =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('stype')
  GdceyHwJKozPBYXiApuVNmMOLsfjbS =GdceyHwJKozPBYXiApuVNmMOLsfjtg(GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('page'))
  GdceyHwJKozPBYXiApuVNmMOLsfjba,GdceyHwJKozPBYXiApuVNmMOLsfjbU=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.GetLiveChannelList(GdceyHwJKozPBYXiApuVNmMOLsfjbC,GdceyHwJKozPBYXiApuVNmMOLsfjbS)
  for GdceyHwJKozPBYXiApuVNmMOLsfjbr in GdceyHwJKozPBYXiApuVNmMOLsfjba:
   GdceyHwJKozPBYXiApuVNmMOLsfjvC =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('title')
   GdceyHwJKozPBYXiApuVNmMOLsfjbg =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('channel')
   GdceyHwJKozPBYXiApuVNmMOLsfjTD =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('thumbnail')
   GdceyHwJKozPBYXiApuVNmMOLsfjTv =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('synopsis')
   GdceyHwJKozPBYXiApuVNmMOLsfjTb =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('channelepg')
   GdceyHwJKozPBYXiApuVNmMOLsfjTQ =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('cast')
   GdceyHwJKozPBYXiApuVNmMOLsfjTF =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('director')
   GdceyHwJKozPBYXiApuVNmMOLsfjTg =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('info_genre')
   GdceyHwJKozPBYXiApuVNmMOLsfjTE =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('year')
   GdceyHwJKozPBYXiApuVNmMOLsfjTt =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('mpaa')
   GdceyHwJKozPBYXiApuVNmMOLsfjTW =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('premiered')
   GdceyHwJKozPBYXiApuVNmMOLsfjTn={'mediatype':'episode','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'studio':GdceyHwJKozPBYXiApuVNmMOLsfjbg,'cast':GdceyHwJKozPBYXiApuVNmMOLsfjTQ,'director':GdceyHwJKozPBYXiApuVNmMOLsfjTF,'genre':GdceyHwJKozPBYXiApuVNmMOLsfjTg,'plot':'%s\n%s\n%s\n\n%s'%(GdceyHwJKozPBYXiApuVNmMOLsfjbg,GdceyHwJKozPBYXiApuVNmMOLsfjvC,GdceyHwJKozPBYXiApuVNmMOLsfjTb,GdceyHwJKozPBYXiApuVNmMOLsfjTv),'year':GdceyHwJKozPBYXiApuVNmMOLsfjTE,'mpaa':GdceyHwJKozPBYXiApuVNmMOLsfjTt,'premiered':GdceyHwJKozPBYXiApuVNmMOLsfjTW}
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'LIVE','mediacode':GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('mediacode'),'stype':GdceyHwJKozPBYXiApuVNmMOLsfjbC}
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjbg,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjvC,img=GdceyHwJKozPBYXiApuVNmMOLsfjTD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtE,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  if GdceyHwJKozPBYXiApuVNmMOLsfjbU:
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['mode']='CHANNEL' 
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['stype']=GdceyHwJKozPBYXiApuVNmMOLsfjbC 
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['page']=GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjvC='[B]%s >>[/B]'%'다음 페이지'
   GdceyHwJKozPBYXiApuVNmMOLsfjTI=GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjbD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjTI,img=GdceyHwJKozPBYXiApuVNmMOLsfjbD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  if GdceyHwJKozPBYXiApuVNmMOLsfjtx(GdceyHwJKozPBYXiApuVNmMOLsfjba)>0:xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtE)
 def dp_Program_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjTR =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('stype')
  GdceyHwJKozPBYXiApuVNmMOLsfjvh =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('orderby')
  GdceyHwJKozPBYXiApuVNmMOLsfjbS =GdceyHwJKozPBYXiApuVNmMOLsfjtg(GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('page'))
  GdceyHwJKozPBYXiApuVNmMOLsfjTh=GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('genreCode')
  if GdceyHwJKozPBYXiApuVNmMOLsfjTh==GdceyHwJKozPBYXiApuVNmMOLsfjtF:GdceyHwJKozPBYXiApuVNmMOLsfjTh='all'
  GdceyHwJKozPBYXiApuVNmMOLsfjTx,GdceyHwJKozPBYXiApuVNmMOLsfjbU=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.GetProgramList(GdceyHwJKozPBYXiApuVNmMOLsfjTR,GdceyHwJKozPBYXiApuVNmMOLsfjvh,GdceyHwJKozPBYXiApuVNmMOLsfjbS,GdceyHwJKozPBYXiApuVNmMOLsfjTh)
  for GdceyHwJKozPBYXiApuVNmMOLsfjTC in GdceyHwJKozPBYXiApuVNmMOLsfjTx:
   GdceyHwJKozPBYXiApuVNmMOLsfjvC =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('title')
   GdceyHwJKozPBYXiApuVNmMOLsfjTD =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('thumbnail')
   GdceyHwJKozPBYXiApuVNmMOLsfjTv =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('synopsis')
   GdceyHwJKozPBYXiApuVNmMOLsfjTl =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('channel')
   GdceyHwJKozPBYXiApuVNmMOLsfjTQ =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('cast')
   GdceyHwJKozPBYXiApuVNmMOLsfjTF =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('director')
   GdceyHwJKozPBYXiApuVNmMOLsfjTg=GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('info_genre')
   GdceyHwJKozPBYXiApuVNmMOLsfjTE =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('year')
   GdceyHwJKozPBYXiApuVNmMOLsfjTW =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('premiered')
   GdceyHwJKozPBYXiApuVNmMOLsfjTt =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('mpaa')
   GdceyHwJKozPBYXiApuVNmMOLsfjTn={'mediatype':'tvshow','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'studio':GdceyHwJKozPBYXiApuVNmMOLsfjTl,'cast':GdceyHwJKozPBYXiApuVNmMOLsfjTQ,'director':GdceyHwJKozPBYXiApuVNmMOLsfjTF,'genre':GdceyHwJKozPBYXiApuVNmMOLsfjTg,'year':GdceyHwJKozPBYXiApuVNmMOLsfjTE,'premiered':GdceyHwJKozPBYXiApuVNmMOLsfjTW,'mpaa':GdceyHwJKozPBYXiApuVNmMOLsfjTt,'plot':GdceyHwJKozPBYXiApuVNmMOLsfjTv}
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'EPISODE','programcode':GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('program'),'page':'1'}
   if GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_makebookmark():
    GdceyHwJKozPBYXiApuVNmMOLsfjTk={'videoid':GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('program'),'vidtype':'tvshow','vtitle':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'vsubtitle':GdceyHwJKozPBYXiApuVNmMOLsfjTl,}
    GdceyHwJKozPBYXiApuVNmMOLsfjTq=json.dumps(GdceyHwJKozPBYXiApuVNmMOLsfjTk)
    GdceyHwJKozPBYXiApuVNmMOLsfjTq=urllib.parse.quote(GdceyHwJKozPBYXiApuVNmMOLsfjTq)
    GdceyHwJKozPBYXiApuVNmMOLsfjTS='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(GdceyHwJKozPBYXiApuVNmMOLsfjTq)
    GdceyHwJKozPBYXiApuVNmMOLsfjTa=[('(통합) 찜 영상에 추가',GdceyHwJKozPBYXiApuVNmMOLsfjTS)]
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjTa=GdceyHwJKozPBYXiApuVNmMOLsfjtF
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjTl,img=GdceyHwJKozPBYXiApuVNmMOLsfjTD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv,ContextMenu=GdceyHwJKozPBYXiApuVNmMOLsfjTa)
  if GdceyHwJKozPBYXiApuVNmMOLsfjbU:
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['mode'] ='PROGRAM' 
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['stype'] =GdceyHwJKozPBYXiApuVNmMOLsfjTR
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['orderby'] =GdceyHwJKozPBYXiApuVNmMOLsfjvh
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['page'] =GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['genreCode']=GdceyHwJKozPBYXiApuVNmMOLsfjTh 
   GdceyHwJKozPBYXiApuVNmMOLsfjvC='[B]%s >>[/B]'%'다음 페이지'
   GdceyHwJKozPBYXiApuVNmMOLsfjTI=GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjbD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjTI,img=GdceyHwJKozPBYXiApuVNmMOLsfjbD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  xbmcplugin.setContent(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtE)
 def dp_4K_Program_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjbS =GdceyHwJKozPBYXiApuVNmMOLsfjtg(GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('page'))
  GdceyHwJKozPBYXiApuVNmMOLsfjTx,GdceyHwJKozPBYXiApuVNmMOLsfjbU=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Get_UHD_ProgramList(GdceyHwJKozPBYXiApuVNmMOLsfjbS)
  for GdceyHwJKozPBYXiApuVNmMOLsfjTC in GdceyHwJKozPBYXiApuVNmMOLsfjTx:
   GdceyHwJKozPBYXiApuVNmMOLsfjvC =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('title')
   GdceyHwJKozPBYXiApuVNmMOLsfjTD =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('thumbnail')
   GdceyHwJKozPBYXiApuVNmMOLsfjTv =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('synopsis')
   GdceyHwJKozPBYXiApuVNmMOLsfjTl =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('channel')
   GdceyHwJKozPBYXiApuVNmMOLsfjTQ =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('cast')
   GdceyHwJKozPBYXiApuVNmMOLsfjTF =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('director')
   GdceyHwJKozPBYXiApuVNmMOLsfjTg=GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('info_genre')
   GdceyHwJKozPBYXiApuVNmMOLsfjTE =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('year')
   GdceyHwJKozPBYXiApuVNmMOLsfjTW =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('premiered')
   GdceyHwJKozPBYXiApuVNmMOLsfjTt =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('mpaa')
   GdceyHwJKozPBYXiApuVNmMOLsfjTn={'mediatype':'tvshow','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'studio':GdceyHwJKozPBYXiApuVNmMOLsfjTl,'cast':GdceyHwJKozPBYXiApuVNmMOLsfjTQ,'director':GdceyHwJKozPBYXiApuVNmMOLsfjTF,'genre':GdceyHwJKozPBYXiApuVNmMOLsfjTg,'year':GdceyHwJKozPBYXiApuVNmMOLsfjTE,'premiered':GdceyHwJKozPBYXiApuVNmMOLsfjTW,'mpaa':GdceyHwJKozPBYXiApuVNmMOLsfjTt,'plot':GdceyHwJKozPBYXiApuVNmMOLsfjTv}
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'EPISODE','programcode':GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('program'),'page':'1'}
   if GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_makebookmark():
    GdceyHwJKozPBYXiApuVNmMOLsfjTk={'videoid':GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('program'),'vidtype':'tvshow','vtitle':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'vsubtitle':GdceyHwJKozPBYXiApuVNmMOLsfjTl,}
    GdceyHwJKozPBYXiApuVNmMOLsfjTq=json.dumps(GdceyHwJKozPBYXiApuVNmMOLsfjTk)
    GdceyHwJKozPBYXiApuVNmMOLsfjTq=urllib.parse.quote(GdceyHwJKozPBYXiApuVNmMOLsfjTq)
    GdceyHwJKozPBYXiApuVNmMOLsfjTS='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(GdceyHwJKozPBYXiApuVNmMOLsfjTq)
    GdceyHwJKozPBYXiApuVNmMOLsfjTa=[('(통합) 찜 영상에 추가',GdceyHwJKozPBYXiApuVNmMOLsfjTS)]
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjTa=GdceyHwJKozPBYXiApuVNmMOLsfjtF
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjTl,img=GdceyHwJKozPBYXiApuVNmMOLsfjTD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv,ContextMenu=GdceyHwJKozPBYXiApuVNmMOLsfjTa)
  if GdceyHwJKozPBYXiApuVNmMOLsfjbU:
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['mode'] ='4K_PROGRAM' 
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['page'] =GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjvC='[B]%s >>[/B]'%'다음 페이지'
   GdceyHwJKozPBYXiApuVNmMOLsfjTI=GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjbD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjTI,img=GdceyHwJKozPBYXiApuVNmMOLsfjbD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  xbmcplugin.setContent(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtE)
 def dp_Ori_Program_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjbS =GdceyHwJKozPBYXiApuVNmMOLsfjtg(GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('page'))
  GdceyHwJKozPBYXiApuVNmMOLsfjTx,GdceyHwJKozPBYXiApuVNmMOLsfjbU=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Get_Origianl_ProgramList(GdceyHwJKozPBYXiApuVNmMOLsfjbS)
  for GdceyHwJKozPBYXiApuVNmMOLsfjTC in GdceyHwJKozPBYXiApuVNmMOLsfjTx:
   GdceyHwJKozPBYXiApuVNmMOLsfjvC =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('title')
   GdceyHwJKozPBYXiApuVNmMOLsfjTD =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('thumbnail')
   GdceyHwJKozPBYXiApuVNmMOLsfjTr =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('vod_type')
   GdceyHwJKozPBYXiApuVNmMOLsfjQD =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('vod_code')
   if GdceyHwJKozPBYXiApuVNmMOLsfjTr=='vod':
    GdceyHwJKozPBYXiApuVNmMOLsfjTn={'mediatype':'tvshow','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,}
    GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'EPISODE','programcode':GdceyHwJKozPBYXiApuVNmMOLsfjQD,'page':'1',}
    GdceyHwJKozPBYXiApuVNmMOLsfjbT=GdceyHwJKozPBYXiApuVNmMOLsfjtW
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjTn={'mediatype':'movie','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'plot':'movie',}
    GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'MOVIE','mediacode':GdceyHwJKozPBYXiApuVNmMOLsfjQD,'stype':'movie','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'thumbnail':GdceyHwJKozPBYXiApuVNmMOLsfjTD,}
    GdceyHwJKozPBYXiApuVNmMOLsfjbT=GdceyHwJKozPBYXiApuVNmMOLsfjtE
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjtF,img=GdceyHwJKozPBYXiApuVNmMOLsfjTD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjbT,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv,ContextMenu=GdceyHwJKozPBYXiApuVNmMOLsfjtF)
  if GdceyHwJKozPBYXiApuVNmMOLsfjbU:
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['mode'] ='ORI_PROGRAM' 
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['page'] =GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjvC='[B]%s >>[/B]'%'다음 페이지'
   GdceyHwJKozPBYXiApuVNmMOLsfjTI=GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjbD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjTI,img=GdceyHwJKozPBYXiApuVNmMOLsfjbD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  xbmcplugin.setContent(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtE)
 def dp_Episode_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjQv=GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('programcode')
  GdceyHwJKozPBYXiApuVNmMOLsfjbS =GdceyHwJKozPBYXiApuVNmMOLsfjtg(GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('page'))
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_log('programcode : '+GdceyHwJKozPBYXiApuVNmMOLsfjQv)
  GdceyHwJKozPBYXiApuVNmMOLsfjQb,GdceyHwJKozPBYXiApuVNmMOLsfjbU,GdceyHwJKozPBYXiApuVNmMOLsfjQT=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.GetEpisodeList(GdceyHwJKozPBYXiApuVNmMOLsfjQv,GdceyHwJKozPBYXiApuVNmMOLsfjbS,orderby=GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_winEpisodeOrderby())
  for GdceyHwJKozPBYXiApuVNmMOLsfjQF in GdceyHwJKozPBYXiApuVNmMOLsfjQb:
   GdceyHwJKozPBYXiApuVNmMOLsfjvC =GdceyHwJKozPBYXiApuVNmMOLsfjQF.get('title')
   GdceyHwJKozPBYXiApuVNmMOLsfjTI =GdceyHwJKozPBYXiApuVNmMOLsfjQF.get('subtitle')
   GdceyHwJKozPBYXiApuVNmMOLsfjTD =GdceyHwJKozPBYXiApuVNmMOLsfjQF.get('thumbnail')
   GdceyHwJKozPBYXiApuVNmMOLsfjTv =GdceyHwJKozPBYXiApuVNmMOLsfjQF.get('synopsis')
   GdceyHwJKozPBYXiApuVNmMOLsfjQg=GdceyHwJKozPBYXiApuVNmMOLsfjQF.get('info_title')
   GdceyHwJKozPBYXiApuVNmMOLsfjQE =GdceyHwJKozPBYXiApuVNmMOLsfjQF.get('aired')
   GdceyHwJKozPBYXiApuVNmMOLsfjQt =GdceyHwJKozPBYXiApuVNmMOLsfjQF.get('studio')
   GdceyHwJKozPBYXiApuVNmMOLsfjQW =GdceyHwJKozPBYXiApuVNmMOLsfjQF.get('frequency')
   GdceyHwJKozPBYXiApuVNmMOLsfjTn={'mediatype':'episode','title':GdceyHwJKozPBYXiApuVNmMOLsfjQg,'aired':GdceyHwJKozPBYXiApuVNmMOLsfjQE,'studio':GdceyHwJKozPBYXiApuVNmMOLsfjQt,'episode':GdceyHwJKozPBYXiApuVNmMOLsfjQW,'plot':GdceyHwJKozPBYXiApuVNmMOLsfjTv}
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'VOD','mediacode':GdceyHwJKozPBYXiApuVNmMOLsfjQF.get('episode'),'stype':'vod','programcode':GdceyHwJKozPBYXiApuVNmMOLsfjQv,'title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'thumbnail':GdceyHwJKozPBYXiApuVNmMOLsfjTD}
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjTI,img=GdceyHwJKozPBYXiApuVNmMOLsfjTD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtE,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  if GdceyHwJKozPBYXiApuVNmMOLsfjbS==1:
   GdceyHwJKozPBYXiApuVNmMOLsfjTn={'plot':'정렬순서를 변경합니다.'}
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={}
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['mode'] ='ORDER_BY' 
   if GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_winEpisodeOrderby()=='desc':
    GdceyHwJKozPBYXiApuVNmMOLsfjvC='정렬순서변경 : 최신화부터 -> 1회부터'
    GdceyHwJKozPBYXiApuVNmMOLsfjbv['orderby']='asc'
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjvC='정렬순서변경 : 1회부터 -> 최신화부터'
    GdceyHwJKozPBYXiApuVNmMOLsfjbv['orderby']='desc'
   GdceyHwJKozPBYXiApuVNmMOLsfjbD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel='',img=GdceyHwJKozPBYXiApuVNmMOLsfjbD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtE,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv,isLink=GdceyHwJKozPBYXiApuVNmMOLsfjtW)
  if GdceyHwJKozPBYXiApuVNmMOLsfjbU:
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['mode'] ='EPISODE' 
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['programcode']=GdceyHwJKozPBYXiApuVNmMOLsfjQv
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['page'] =GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjvC='[B]%s >>[/B]'%'다음 페이지'
   GdceyHwJKozPBYXiApuVNmMOLsfjTI=GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjbD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjTI,img=GdceyHwJKozPBYXiApuVNmMOLsfjbD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  xbmcplugin.setContent(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,'episodes')
  if GdceyHwJKozPBYXiApuVNmMOLsfjtx(GdceyHwJKozPBYXiApuVNmMOLsfjQb)>0:xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtW)
 def dp_setEpOrderby(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjvh =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('orderby')
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.set_winEpisodeOrderby(GdceyHwJKozPBYXiApuVNmMOLsfjvh)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjTR =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('stype')
  GdceyHwJKozPBYXiApuVNmMOLsfjvh =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('orderby')
  GdceyHwJKozPBYXiApuVNmMOLsfjbS=GdceyHwJKozPBYXiApuVNmMOLsfjtg(GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('page'))
  GdceyHwJKozPBYXiApuVNmMOLsfjQn,GdceyHwJKozPBYXiApuVNmMOLsfjbU=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.GetMovieList(GdceyHwJKozPBYXiApuVNmMOLsfjTR,GdceyHwJKozPBYXiApuVNmMOLsfjvh,GdceyHwJKozPBYXiApuVNmMOLsfjbS)
  for GdceyHwJKozPBYXiApuVNmMOLsfjQI in GdceyHwJKozPBYXiApuVNmMOLsfjQn:
   GdceyHwJKozPBYXiApuVNmMOLsfjvC =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('title')
   GdceyHwJKozPBYXiApuVNmMOLsfjTD =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('thumbnail')
   GdceyHwJKozPBYXiApuVNmMOLsfjTv =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('synopsis')
   GdceyHwJKozPBYXiApuVNmMOLsfjQg =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('info_title')
   GdceyHwJKozPBYXiApuVNmMOLsfjTE =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('year')
   GdceyHwJKozPBYXiApuVNmMOLsfjTQ =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('cast')
   GdceyHwJKozPBYXiApuVNmMOLsfjTF =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('director')
   GdceyHwJKozPBYXiApuVNmMOLsfjTg =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('info_genre')
   GdceyHwJKozPBYXiApuVNmMOLsfjQR =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('duration')
   GdceyHwJKozPBYXiApuVNmMOLsfjTW =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('premiered')
   GdceyHwJKozPBYXiApuVNmMOLsfjQt =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('studio')
   GdceyHwJKozPBYXiApuVNmMOLsfjTt =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('mpaa')
   GdceyHwJKozPBYXiApuVNmMOLsfjTn={'mediatype':'movie','title':GdceyHwJKozPBYXiApuVNmMOLsfjQg,'year':GdceyHwJKozPBYXiApuVNmMOLsfjTE,'cast':GdceyHwJKozPBYXiApuVNmMOLsfjTQ,'director':GdceyHwJKozPBYXiApuVNmMOLsfjTF,'genre':GdceyHwJKozPBYXiApuVNmMOLsfjTg,'duration':GdceyHwJKozPBYXiApuVNmMOLsfjQR,'premiered':GdceyHwJKozPBYXiApuVNmMOLsfjTW,'studio':GdceyHwJKozPBYXiApuVNmMOLsfjQt,'mpaa':GdceyHwJKozPBYXiApuVNmMOLsfjTt,'plot':GdceyHwJKozPBYXiApuVNmMOLsfjTv}
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'MOVIE','mediacode':GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('moviecode'),'stype':'movie','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'thumbnail':GdceyHwJKozPBYXiApuVNmMOLsfjTD}
   if GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_makebookmark():
    GdceyHwJKozPBYXiApuVNmMOLsfjTk={'videoid':GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('moviecode'),'vidtype':'movie','vtitle':GdceyHwJKozPBYXiApuVNmMOLsfjQg,'vsubtitle':'',}
    GdceyHwJKozPBYXiApuVNmMOLsfjTq=json.dumps(GdceyHwJKozPBYXiApuVNmMOLsfjTk)
    GdceyHwJKozPBYXiApuVNmMOLsfjTq=urllib.parse.quote(GdceyHwJKozPBYXiApuVNmMOLsfjTq)
    GdceyHwJKozPBYXiApuVNmMOLsfjTS='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(GdceyHwJKozPBYXiApuVNmMOLsfjTq)
    GdceyHwJKozPBYXiApuVNmMOLsfjTa=[('(통합) 찜 영상에 추가',GdceyHwJKozPBYXiApuVNmMOLsfjTS)]
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjTa=GdceyHwJKozPBYXiApuVNmMOLsfjtF
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel='',img=GdceyHwJKozPBYXiApuVNmMOLsfjTD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtE,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv,ContextMenu=GdceyHwJKozPBYXiApuVNmMOLsfjTa)
  if GdceyHwJKozPBYXiApuVNmMOLsfjbU:
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={}
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['mode'] ='MOVIE_SUB' 
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['orderby']=GdceyHwJKozPBYXiApuVNmMOLsfjvh
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['stype'] =GdceyHwJKozPBYXiApuVNmMOLsfjTR
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['page'] =GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjvC='[B]%s >>[/B]'%'다음 페이지'
   GdceyHwJKozPBYXiApuVNmMOLsfjTI=GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjbD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjTI,img=GdceyHwJKozPBYXiApuVNmMOLsfjbD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  xbmcplugin.setContent(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,'movies')
  xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtE)
 def dp_4K_Movie_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjbS=GdceyHwJKozPBYXiApuVNmMOLsfjtg(GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('page'))
  GdceyHwJKozPBYXiApuVNmMOLsfjQn,GdceyHwJKozPBYXiApuVNmMOLsfjbU=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Get_UHD_MovieList(GdceyHwJKozPBYXiApuVNmMOLsfjbS)
  for GdceyHwJKozPBYXiApuVNmMOLsfjQI in GdceyHwJKozPBYXiApuVNmMOLsfjQn:
   GdceyHwJKozPBYXiApuVNmMOLsfjvC =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('title')
   GdceyHwJKozPBYXiApuVNmMOLsfjTD =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('thumbnail')
   GdceyHwJKozPBYXiApuVNmMOLsfjTv =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('synopsis')
   GdceyHwJKozPBYXiApuVNmMOLsfjQg =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('info_title')
   GdceyHwJKozPBYXiApuVNmMOLsfjTE =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('year')
   GdceyHwJKozPBYXiApuVNmMOLsfjTQ =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('cast')
   GdceyHwJKozPBYXiApuVNmMOLsfjTF =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('director')
   GdceyHwJKozPBYXiApuVNmMOLsfjTg =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('info_genre')
   GdceyHwJKozPBYXiApuVNmMOLsfjQR =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('duration')
   GdceyHwJKozPBYXiApuVNmMOLsfjTW =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('premiered')
   GdceyHwJKozPBYXiApuVNmMOLsfjQt =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('studio')
   GdceyHwJKozPBYXiApuVNmMOLsfjTt =GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('mpaa')
   GdceyHwJKozPBYXiApuVNmMOLsfjTn={'mediatype':'movie','title':GdceyHwJKozPBYXiApuVNmMOLsfjQg,'year':GdceyHwJKozPBYXiApuVNmMOLsfjTE,'cast':GdceyHwJKozPBYXiApuVNmMOLsfjTQ,'director':GdceyHwJKozPBYXiApuVNmMOLsfjTF,'genre':GdceyHwJKozPBYXiApuVNmMOLsfjTg,'duration':GdceyHwJKozPBYXiApuVNmMOLsfjQR,'premiered':GdceyHwJKozPBYXiApuVNmMOLsfjTW,'studio':GdceyHwJKozPBYXiApuVNmMOLsfjQt,'mpaa':GdceyHwJKozPBYXiApuVNmMOLsfjTt,'plot':GdceyHwJKozPBYXiApuVNmMOLsfjTv}
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'MOVIE','mediacode':GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('moviecode'),'stype':'movie','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'thumbnail':GdceyHwJKozPBYXiApuVNmMOLsfjTD}
   if GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_makebookmark():
    GdceyHwJKozPBYXiApuVNmMOLsfjTk={'videoid':GdceyHwJKozPBYXiApuVNmMOLsfjQI.get('moviecode'),'vidtype':'movie','vtitle':GdceyHwJKozPBYXiApuVNmMOLsfjQg,'vsubtitle':'',}
    GdceyHwJKozPBYXiApuVNmMOLsfjTq=json.dumps(GdceyHwJKozPBYXiApuVNmMOLsfjTk)
    GdceyHwJKozPBYXiApuVNmMOLsfjTq=urllib.parse.quote(GdceyHwJKozPBYXiApuVNmMOLsfjTq)
    GdceyHwJKozPBYXiApuVNmMOLsfjTS='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(GdceyHwJKozPBYXiApuVNmMOLsfjTq)
    GdceyHwJKozPBYXiApuVNmMOLsfjTa=[('(통합) 찜 영상에 추가',GdceyHwJKozPBYXiApuVNmMOLsfjTS)]
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjTa=GdceyHwJKozPBYXiApuVNmMOLsfjtF
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel='',img=GdceyHwJKozPBYXiApuVNmMOLsfjTD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtE,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv,ContextMenu=GdceyHwJKozPBYXiApuVNmMOLsfjTa)
  if GdceyHwJKozPBYXiApuVNmMOLsfjbU:
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={}
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['mode'] ='4K_MOVIE' 
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['page'] =GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjvC='[B]%s >>[/B]'%'다음 페이지'
   GdceyHwJKozPBYXiApuVNmMOLsfjTI=GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjbD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjTI,img=GdceyHwJKozPBYXiApuVNmMOLsfjbD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  xbmcplugin.setContent(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,'movies')
  xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtE)
 def dp_Set_Bookmark(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjQh=urllib.parse.unquote(GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('bm_param'))
  GdceyHwJKozPBYXiApuVNmMOLsfjQh=json.loads(GdceyHwJKozPBYXiApuVNmMOLsfjQh)
  GdceyHwJKozPBYXiApuVNmMOLsfjQx =GdceyHwJKozPBYXiApuVNmMOLsfjQh.get('videoid')
  GdceyHwJKozPBYXiApuVNmMOLsfjQC =GdceyHwJKozPBYXiApuVNmMOLsfjQh.get('vidtype')
  GdceyHwJKozPBYXiApuVNmMOLsfjQl =GdceyHwJKozPBYXiApuVNmMOLsfjQh.get('vtitle')
  GdceyHwJKozPBYXiApuVNmMOLsfjQk =GdceyHwJKozPBYXiApuVNmMOLsfjQh.get('vsubtitle')
  GdceyHwJKozPBYXiApuVNmMOLsfjDk=xbmcgui.Dialog()
  GdceyHwJKozPBYXiApuVNmMOLsfjbI=GdceyHwJKozPBYXiApuVNmMOLsfjDk.yesno(__language__(30913).encode('utf8'),GdceyHwJKozPBYXiApuVNmMOLsfjQl+' \n\n'+__language__(30914))
  if GdceyHwJKozPBYXiApuVNmMOLsfjbI==GdceyHwJKozPBYXiApuVNmMOLsfjtE:return
  GdceyHwJKozPBYXiApuVNmMOLsfjQq=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.GetBookmarkInfo(GdceyHwJKozPBYXiApuVNmMOLsfjQx,GdceyHwJKozPBYXiApuVNmMOLsfjQC)
  if GdceyHwJKozPBYXiApuVNmMOLsfjQk!='':
   GdceyHwJKozPBYXiApuVNmMOLsfjQq['saveinfo']['subtitle']=GdceyHwJKozPBYXiApuVNmMOLsfjQk 
   if GdceyHwJKozPBYXiApuVNmMOLsfjQC=='tvshow':GdceyHwJKozPBYXiApuVNmMOLsfjQq['saveinfo']['infoLabels']['studio']=GdceyHwJKozPBYXiApuVNmMOLsfjQk 
  GdceyHwJKozPBYXiApuVNmMOLsfjQS=json.dumps(GdceyHwJKozPBYXiApuVNmMOLsfjQq)
  GdceyHwJKozPBYXiApuVNmMOLsfjQS=urllib.parse.quote(GdceyHwJKozPBYXiApuVNmMOLsfjQS)
  GdceyHwJKozPBYXiApuVNmMOLsfjTS ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(GdceyHwJKozPBYXiApuVNmMOLsfjQS)
  xbmc.executebuiltin(GdceyHwJKozPBYXiApuVNmMOLsfjTS)
 def dp_Search_Group(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  if 'search_key' in GdceyHwJKozPBYXiApuVNmMOLsfjbq:
   GdceyHwJKozPBYXiApuVNmMOLsfjQa=GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('search_key')
  else:
   GdceyHwJKozPBYXiApuVNmMOLsfjQa=GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not GdceyHwJKozPBYXiApuVNmMOLsfjQa:
    return
  for GdceyHwJKozPBYXiApuVNmMOLsfjbk in GdceyHwJKozPBYXiApuVNmMOLsfjDF:
   GdceyHwJKozPBYXiApuVNmMOLsfjQU =GdceyHwJKozPBYXiApuVNmMOLsfjbk.get('mode')
   GdceyHwJKozPBYXiApuVNmMOLsfjbC=GdceyHwJKozPBYXiApuVNmMOLsfjbk.get('stype')
   GdceyHwJKozPBYXiApuVNmMOLsfjvC=GdceyHwJKozPBYXiApuVNmMOLsfjbk.get('title')
   (GdceyHwJKozPBYXiApuVNmMOLsfjQr,GdceyHwJKozPBYXiApuVNmMOLsfjbU)=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.GetSearchList(GdceyHwJKozPBYXiApuVNmMOLsfjQa,1,GdceyHwJKozPBYXiApuVNmMOLsfjbC)
   GdceyHwJKozPBYXiApuVNmMOLsfjbF={'plot':'검색어 : '+GdceyHwJKozPBYXiApuVNmMOLsfjQa+'\n\n'+GdceyHwJKozPBYXiApuVNmMOLsfjDR.Search_FreeList(GdceyHwJKozPBYXiApuVNmMOLsfjQr)}
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':GdceyHwJKozPBYXiApuVNmMOLsfjQU,'stype':GdceyHwJKozPBYXiApuVNmMOLsfjbC,'search_key':GdceyHwJKozPBYXiApuVNmMOLsfjQa,'page':'1',}
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel='',img='',infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjbF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  if GdceyHwJKozPBYXiApuVNmMOLsfjtx(GdceyHwJKozPBYXiApuVNmMOLsfjDF)>0:xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtW)
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.Save_Searched_List(GdceyHwJKozPBYXiApuVNmMOLsfjQa)
 def Search_FreeList(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjFW):
  GdceyHwJKozPBYXiApuVNmMOLsfjFD=''
  GdceyHwJKozPBYXiApuVNmMOLsfjFv=7
  try:
   if GdceyHwJKozPBYXiApuVNmMOLsfjtx(GdceyHwJKozPBYXiApuVNmMOLsfjFW)==0:return '검색결과 없음'
   for i in GdceyHwJKozPBYXiApuVNmMOLsfjtl(GdceyHwJKozPBYXiApuVNmMOLsfjtx(GdceyHwJKozPBYXiApuVNmMOLsfjFW)):
    if i>=GdceyHwJKozPBYXiApuVNmMOLsfjFv:
     GdceyHwJKozPBYXiApuVNmMOLsfjFD=GdceyHwJKozPBYXiApuVNmMOLsfjFD+'...'
     break
    GdceyHwJKozPBYXiApuVNmMOLsfjFD=GdceyHwJKozPBYXiApuVNmMOLsfjFD+GdceyHwJKozPBYXiApuVNmMOLsfjFW[i]['title']+'\n'
  except:
   return ''
  return GdceyHwJKozPBYXiApuVNmMOLsfjFD
 def dp_Search_History(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjFb=GdceyHwJKozPBYXiApuVNmMOLsfjDR.Load_List_File('search')
  for GdceyHwJKozPBYXiApuVNmMOLsfjFT in GdceyHwJKozPBYXiApuVNmMOLsfjFb:
   GdceyHwJKozPBYXiApuVNmMOLsfjFQ=GdceyHwJKozPBYXiApuVNmMOLsfjtI(urllib.parse.parse_qsl(GdceyHwJKozPBYXiApuVNmMOLsfjFT))
   GdceyHwJKozPBYXiApuVNmMOLsfjFg=GdceyHwJKozPBYXiApuVNmMOLsfjFQ.get('skey').strip()
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'SEARCH_GROUP','search_key':GdceyHwJKozPBYXiApuVNmMOLsfjFg,}
   GdceyHwJKozPBYXiApuVNmMOLsfjFE={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':GdceyHwJKozPBYXiApuVNmMOLsfjFg,'vType':'-',}
   GdceyHwJKozPBYXiApuVNmMOLsfjFt=urllib.parse.urlencode(GdceyHwJKozPBYXiApuVNmMOLsfjFE)
   GdceyHwJKozPBYXiApuVNmMOLsfjTa=[('선택된 검색어 ( %s ) 삭제'%(GdceyHwJKozPBYXiApuVNmMOLsfjFg),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(GdceyHwJKozPBYXiApuVNmMOLsfjFt))]
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjFg,sublabel='',img=GdceyHwJKozPBYXiApuVNmMOLsfjtF,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv,ContextMenu=GdceyHwJKozPBYXiApuVNmMOLsfjTa)
  GdceyHwJKozPBYXiApuVNmMOLsfjTn={'plot':'검색목록 전체를 삭제합니다.'}
  GdceyHwJKozPBYXiApuVNmMOLsfjvC='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  GdceyHwJKozPBYXiApuVNmMOLsfjbD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel='',img=GdceyHwJKozPBYXiApuVNmMOLsfjbD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtE,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv,isLink=GdceyHwJKozPBYXiApuVNmMOLsfjtW)
  xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtE)
 def dp_Search_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjbS =GdceyHwJKozPBYXiApuVNmMOLsfjtg(GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('page'))
  GdceyHwJKozPBYXiApuVNmMOLsfjbC =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('stype')
  if 'search_key' in GdceyHwJKozPBYXiApuVNmMOLsfjbq:
   GdceyHwJKozPBYXiApuVNmMOLsfjQa=GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('search_key')
  else:
   GdceyHwJKozPBYXiApuVNmMOLsfjQa=GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not GdceyHwJKozPBYXiApuVNmMOLsfjQa:
    xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle)
    return
  GdceyHwJKozPBYXiApuVNmMOLsfjQr,GdceyHwJKozPBYXiApuVNmMOLsfjbU=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.GetSearchList(GdceyHwJKozPBYXiApuVNmMOLsfjQa,GdceyHwJKozPBYXiApuVNmMOLsfjbS,GdceyHwJKozPBYXiApuVNmMOLsfjbC)
  for GdceyHwJKozPBYXiApuVNmMOLsfjFW in GdceyHwJKozPBYXiApuVNmMOLsfjQr:
   GdceyHwJKozPBYXiApuVNmMOLsfjvC =GdceyHwJKozPBYXiApuVNmMOLsfjFW.get('title')
   GdceyHwJKozPBYXiApuVNmMOLsfjTD =GdceyHwJKozPBYXiApuVNmMOLsfjFW.get('thumbnail')
   GdceyHwJKozPBYXiApuVNmMOLsfjTv =GdceyHwJKozPBYXiApuVNmMOLsfjFW.get('synopsis')
   GdceyHwJKozPBYXiApuVNmMOLsfjFn =GdceyHwJKozPBYXiApuVNmMOLsfjFW.get('program')
   GdceyHwJKozPBYXiApuVNmMOLsfjTQ =GdceyHwJKozPBYXiApuVNmMOLsfjFW.get('cast')
   GdceyHwJKozPBYXiApuVNmMOLsfjTF =GdceyHwJKozPBYXiApuVNmMOLsfjFW.get('director')
   GdceyHwJKozPBYXiApuVNmMOLsfjTg=GdceyHwJKozPBYXiApuVNmMOLsfjFW.get('info_genre')
   GdceyHwJKozPBYXiApuVNmMOLsfjQR =GdceyHwJKozPBYXiApuVNmMOLsfjFW.get('duration')
   GdceyHwJKozPBYXiApuVNmMOLsfjTt =GdceyHwJKozPBYXiApuVNmMOLsfjFW.get('mpaa')
   GdceyHwJKozPBYXiApuVNmMOLsfjTE =GdceyHwJKozPBYXiApuVNmMOLsfjFW.get('year')
   GdceyHwJKozPBYXiApuVNmMOLsfjQE =GdceyHwJKozPBYXiApuVNmMOLsfjFW.get('aired')
   GdceyHwJKozPBYXiApuVNmMOLsfjTn={'mediatype':'tvshow' if GdceyHwJKozPBYXiApuVNmMOLsfjbC=='vod' else 'movie','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'cast':GdceyHwJKozPBYXiApuVNmMOLsfjTQ,'director':GdceyHwJKozPBYXiApuVNmMOLsfjTF,'genre':GdceyHwJKozPBYXiApuVNmMOLsfjTg,'duration':GdceyHwJKozPBYXiApuVNmMOLsfjQR,'mpaa':GdceyHwJKozPBYXiApuVNmMOLsfjTt,'year':GdceyHwJKozPBYXiApuVNmMOLsfjTE,'aired':GdceyHwJKozPBYXiApuVNmMOLsfjQE,'plot':'%s\n\n%s'%(GdceyHwJKozPBYXiApuVNmMOLsfjvC,GdceyHwJKozPBYXiApuVNmMOLsfjTv)}
   if GdceyHwJKozPBYXiApuVNmMOLsfjbC=='vod':
    GdceyHwJKozPBYXiApuVNmMOLsfjQx=GdceyHwJKozPBYXiApuVNmMOLsfjFW.get('program')
    GdceyHwJKozPBYXiApuVNmMOLsfjQC='tvshow'
    GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'EPISODE','programcode':GdceyHwJKozPBYXiApuVNmMOLsfjQx,'page':'1',}
    GdceyHwJKozPBYXiApuVNmMOLsfjbT=GdceyHwJKozPBYXiApuVNmMOLsfjtW
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjQx=GdceyHwJKozPBYXiApuVNmMOLsfjFW.get('movie')
    GdceyHwJKozPBYXiApuVNmMOLsfjQC='movie'
    GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'MOVIE','mediacode':GdceyHwJKozPBYXiApuVNmMOLsfjQx,'stype':'movie','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'thumbnail':GdceyHwJKozPBYXiApuVNmMOLsfjTD,}
    GdceyHwJKozPBYXiApuVNmMOLsfjbT=GdceyHwJKozPBYXiApuVNmMOLsfjtE
   if GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_makebookmark():
    GdceyHwJKozPBYXiApuVNmMOLsfjTk={'videoid':GdceyHwJKozPBYXiApuVNmMOLsfjQx,'vidtype':GdceyHwJKozPBYXiApuVNmMOLsfjQC,'vtitle':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'vsubtitle':'',}
    GdceyHwJKozPBYXiApuVNmMOLsfjTq=json.dumps(GdceyHwJKozPBYXiApuVNmMOLsfjTk)
    GdceyHwJKozPBYXiApuVNmMOLsfjTq=urllib.parse.quote(GdceyHwJKozPBYXiApuVNmMOLsfjTq)
    GdceyHwJKozPBYXiApuVNmMOLsfjTS='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(GdceyHwJKozPBYXiApuVNmMOLsfjTq)
    GdceyHwJKozPBYXiApuVNmMOLsfjTa=[('(통합) 찜 영상에 추가',GdceyHwJKozPBYXiApuVNmMOLsfjTS)]
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjTa=GdceyHwJKozPBYXiApuVNmMOLsfjtF
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel='',img=GdceyHwJKozPBYXiApuVNmMOLsfjTD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjbT,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv,isLink=GdceyHwJKozPBYXiApuVNmMOLsfjtE,ContextMenu=GdceyHwJKozPBYXiApuVNmMOLsfjTa)
  if GdceyHwJKozPBYXiApuVNmMOLsfjbU:
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['mode'] ='SEARCH' 
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['search_key']=GdceyHwJKozPBYXiApuVNmMOLsfjQa
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['page'] =GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjvC='[B]%s >>[/B]'%'다음 페이지'
   GdceyHwJKozPBYXiApuVNmMOLsfjTI=GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjbD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjTI,img=GdceyHwJKozPBYXiApuVNmMOLsfjbD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  if GdceyHwJKozPBYXiApuVNmMOLsfjbC=='movie':xbmcplugin.setContent(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,'movies')
  else:xbmcplugin.setContent(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtE)
 def dp_History_Remove(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjFI=GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('delType')
  GdceyHwJKozPBYXiApuVNmMOLsfjFR =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('sKey')
  GdceyHwJKozPBYXiApuVNmMOLsfjFh =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('vType')
  GdceyHwJKozPBYXiApuVNmMOLsfjDk=xbmcgui.Dialog()
  if GdceyHwJKozPBYXiApuVNmMOLsfjFI=='SEARCH_ALL':
   GdceyHwJKozPBYXiApuVNmMOLsfjbI=GdceyHwJKozPBYXiApuVNmMOLsfjDk.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif GdceyHwJKozPBYXiApuVNmMOLsfjFI=='SEARCH_ONE':
   GdceyHwJKozPBYXiApuVNmMOLsfjbI=GdceyHwJKozPBYXiApuVNmMOLsfjDk.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif GdceyHwJKozPBYXiApuVNmMOLsfjFI=='WATCH_ALL':
   GdceyHwJKozPBYXiApuVNmMOLsfjbI=GdceyHwJKozPBYXiApuVNmMOLsfjDk.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif GdceyHwJKozPBYXiApuVNmMOLsfjFI=='WATCH_ONE':
   GdceyHwJKozPBYXiApuVNmMOLsfjbI=GdceyHwJKozPBYXiApuVNmMOLsfjDk.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if GdceyHwJKozPBYXiApuVNmMOLsfjbI==GdceyHwJKozPBYXiApuVNmMOLsfjtE:sys.exit()
  if GdceyHwJKozPBYXiApuVNmMOLsfjFI=='SEARCH_ALL':
   if os.path.isfile(GdceyHwJKozPBYXiApuVNmMOLsfjDI):os.remove(GdceyHwJKozPBYXiApuVNmMOLsfjDI)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjFI=='SEARCH_ONE':
   try:
    GdceyHwJKozPBYXiApuVNmMOLsfjFx=GdceyHwJKozPBYXiApuVNmMOLsfjDI
    GdceyHwJKozPBYXiApuVNmMOLsfjFC=GdceyHwJKozPBYXiApuVNmMOLsfjDR.Load_List_File('search') 
    fp=GdceyHwJKozPBYXiApuVNmMOLsfjtk(GdceyHwJKozPBYXiApuVNmMOLsfjFx,'w',-1,'utf-8')
    for GdceyHwJKozPBYXiApuVNmMOLsfjFl in GdceyHwJKozPBYXiApuVNmMOLsfjFC:
     GdceyHwJKozPBYXiApuVNmMOLsfjFk=GdceyHwJKozPBYXiApuVNmMOLsfjtI(urllib.parse.parse_qsl(GdceyHwJKozPBYXiApuVNmMOLsfjFl))
     GdceyHwJKozPBYXiApuVNmMOLsfjFq=GdceyHwJKozPBYXiApuVNmMOLsfjFk.get('skey').strip()
     if GdceyHwJKozPBYXiApuVNmMOLsfjFR!=GdceyHwJKozPBYXiApuVNmMOLsfjFq:
      fp.write(GdceyHwJKozPBYXiApuVNmMOLsfjFl)
    fp.close()
   except:
    GdceyHwJKozPBYXiApuVNmMOLsfjtF
  elif GdceyHwJKozPBYXiApuVNmMOLsfjFI=='WATCH_ALL':
   GdceyHwJKozPBYXiApuVNmMOLsfjFx=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GdceyHwJKozPBYXiApuVNmMOLsfjFh))
   if os.path.isfile(GdceyHwJKozPBYXiApuVNmMOLsfjFx):os.remove(GdceyHwJKozPBYXiApuVNmMOLsfjFx)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjFI=='WATCH_ONE':
   GdceyHwJKozPBYXiApuVNmMOLsfjFx=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GdceyHwJKozPBYXiApuVNmMOLsfjFh))
   try:
    GdceyHwJKozPBYXiApuVNmMOLsfjFC=GdceyHwJKozPBYXiApuVNmMOLsfjDR.Load_List_File(GdceyHwJKozPBYXiApuVNmMOLsfjFh) 
    fp=GdceyHwJKozPBYXiApuVNmMOLsfjtk(GdceyHwJKozPBYXiApuVNmMOLsfjFx,'w',-1,'utf-8')
    for GdceyHwJKozPBYXiApuVNmMOLsfjFl in GdceyHwJKozPBYXiApuVNmMOLsfjFC:
     GdceyHwJKozPBYXiApuVNmMOLsfjFk=GdceyHwJKozPBYXiApuVNmMOLsfjtI(urllib.parse.parse_qsl(GdceyHwJKozPBYXiApuVNmMOLsfjFl))
     GdceyHwJKozPBYXiApuVNmMOLsfjFq=GdceyHwJKozPBYXiApuVNmMOLsfjFk.get('code').strip()
     if GdceyHwJKozPBYXiApuVNmMOLsfjFR!=GdceyHwJKozPBYXiApuVNmMOLsfjFq:
      fp.write(GdceyHwJKozPBYXiApuVNmMOLsfjFl)
    fp.close()
   except:
    GdceyHwJKozPBYXiApuVNmMOLsfjtF
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbC): 
  try:
   if GdceyHwJKozPBYXiApuVNmMOLsfjbC=='search':
    GdceyHwJKozPBYXiApuVNmMOLsfjFx=GdceyHwJKozPBYXiApuVNmMOLsfjDI
   elif GdceyHwJKozPBYXiApuVNmMOLsfjbC in['vod','movie']:
    GdceyHwJKozPBYXiApuVNmMOLsfjFx=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GdceyHwJKozPBYXiApuVNmMOLsfjbC))
   else:
    return[]
   fp=GdceyHwJKozPBYXiApuVNmMOLsfjtk(GdceyHwJKozPBYXiApuVNmMOLsfjFx,'r',-1,'utf-8')
   GdceyHwJKozPBYXiApuVNmMOLsfjFS=fp.readlines()
   fp.close()
  except:
   GdceyHwJKozPBYXiApuVNmMOLsfjFS=[]
  return GdceyHwJKozPBYXiApuVNmMOLsfjFS
 def Save_Watched_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbC,GdceyHwJKozPBYXiApuVNmMOLsfjDC):
  try:
   GdceyHwJKozPBYXiApuVNmMOLsfjFa=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%GdceyHwJKozPBYXiApuVNmMOLsfjbC))
   GdceyHwJKozPBYXiApuVNmMOLsfjFC=GdceyHwJKozPBYXiApuVNmMOLsfjDR.Load_List_File(GdceyHwJKozPBYXiApuVNmMOLsfjbC) 
   fp=GdceyHwJKozPBYXiApuVNmMOLsfjtk(GdceyHwJKozPBYXiApuVNmMOLsfjFa,'w',-1,'utf-8')
   GdceyHwJKozPBYXiApuVNmMOLsfjFU=urllib.parse.urlencode(GdceyHwJKozPBYXiApuVNmMOLsfjDC)
   GdceyHwJKozPBYXiApuVNmMOLsfjFU=GdceyHwJKozPBYXiApuVNmMOLsfjFU+'\n'
   fp.write(GdceyHwJKozPBYXiApuVNmMOLsfjFU)
   GdceyHwJKozPBYXiApuVNmMOLsfjFr=0
   for GdceyHwJKozPBYXiApuVNmMOLsfjFl in GdceyHwJKozPBYXiApuVNmMOLsfjFC:
    GdceyHwJKozPBYXiApuVNmMOLsfjFk=GdceyHwJKozPBYXiApuVNmMOLsfjtI(urllib.parse.parse_qsl(GdceyHwJKozPBYXiApuVNmMOLsfjFl))
    GdceyHwJKozPBYXiApuVNmMOLsfjgD=GdceyHwJKozPBYXiApuVNmMOLsfjDC.get('code').strip()
    GdceyHwJKozPBYXiApuVNmMOLsfjgv=GdceyHwJKozPBYXiApuVNmMOLsfjFk.get('code').strip()
    if GdceyHwJKozPBYXiApuVNmMOLsfjbC=='vod' and GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_direct_replay()==GdceyHwJKozPBYXiApuVNmMOLsfjtW:
     GdceyHwJKozPBYXiApuVNmMOLsfjgD=GdceyHwJKozPBYXiApuVNmMOLsfjDC.get('videoid').strip()
     GdceyHwJKozPBYXiApuVNmMOLsfjgv=GdceyHwJKozPBYXiApuVNmMOLsfjFk.get('videoid').strip()if GdceyHwJKozPBYXiApuVNmMOLsfjgv!=GdceyHwJKozPBYXiApuVNmMOLsfjtF else '-'
    if GdceyHwJKozPBYXiApuVNmMOLsfjgD!=GdceyHwJKozPBYXiApuVNmMOLsfjgv:
     fp.write(GdceyHwJKozPBYXiApuVNmMOLsfjFl)
     GdceyHwJKozPBYXiApuVNmMOLsfjFr+=1
     if GdceyHwJKozPBYXiApuVNmMOLsfjFr>=50:break
   fp.close()
  except:
   GdceyHwJKozPBYXiApuVNmMOLsfjtF
 def dp_Watch_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjbC =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('stype')
  GdceyHwJKozPBYXiApuVNmMOLsfjvI=GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_direct_replay()
  if GdceyHwJKozPBYXiApuVNmMOLsfjbC=='-':
   for GdceyHwJKozPBYXiApuVNmMOLsfjbk in GdceyHwJKozPBYXiApuVNmMOLsfjDQ:
    GdceyHwJKozPBYXiApuVNmMOLsfjvC=GdceyHwJKozPBYXiApuVNmMOLsfjbk.get('title')
    GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':GdceyHwJKozPBYXiApuVNmMOLsfjbk.get('mode'),'stype':GdceyHwJKozPBYXiApuVNmMOLsfjbk.get('stype')}
    GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel='',img='',infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
   if GdceyHwJKozPBYXiApuVNmMOLsfjtx(GdceyHwJKozPBYXiApuVNmMOLsfjDQ)>0:xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle)
  else:
   GdceyHwJKozPBYXiApuVNmMOLsfjgb=GdceyHwJKozPBYXiApuVNmMOLsfjDR.Load_List_File(GdceyHwJKozPBYXiApuVNmMOLsfjbC)
   for GdceyHwJKozPBYXiApuVNmMOLsfjgT in GdceyHwJKozPBYXiApuVNmMOLsfjgb:
    GdceyHwJKozPBYXiApuVNmMOLsfjFQ=GdceyHwJKozPBYXiApuVNmMOLsfjtI(urllib.parse.parse_qsl(GdceyHwJKozPBYXiApuVNmMOLsfjgT))
    GdceyHwJKozPBYXiApuVNmMOLsfjgQ =GdceyHwJKozPBYXiApuVNmMOLsfjFQ.get('code').strip()
    GdceyHwJKozPBYXiApuVNmMOLsfjvC =GdceyHwJKozPBYXiApuVNmMOLsfjFQ.get('title').strip()
    GdceyHwJKozPBYXiApuVNmMOLsfjTD=GdceyHwJKozPBYXiApuVNmMOLsfjFQ.get('img').strip()
    GdceyHwJKozPBYXiApuVNmMOLsfjQx =GdceyHwJKozPBYXiApuVNmMOLsfjFQ.get('videoid').strip()
    try:
     GdceyHwJKozPBYXiApuVNmMOLsfjTD=GdceyHwJKozPBYXiApuVNmMOLsfjTD.replace('\'','\"')
     GdceyHwJKozPBYXiApuVNmMOLsfjTD=json.loads(GdceyHwJKozPBYXiApuVNmMOLsfjTD)
    except:
     GdceyHwJKozPBYXiApuVNmMOLsfjtF
    GdceyHwJKozPBYXiApuVNmMOLsfjTn={}
    GdceyHwJKozPBYXiApuVNmMOLsfjTn['plot']=GdceyHwJKozPBYXiApuVNmMOLsfjvC
    if GdceyHwJKozPBYXiApuVNmMOLsfjbC=='vod':
     if GdceyHwJKozPBYXiApuVNmMOLsfjvI==GdceyHwJKozPBYXiApuVNmMOLsfjtE or GdceyHwJKozPBYXiApuVNmMOLsfjQx==GdceyHwJKozPBYXiApuVNmMOLsfjtF:
      GdceyHwJKozPBYXiApuVNmMOLsfjTn['mediatype']='tvshow'
      GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'EPISODE','programcode':GdceyHwJKozPBYXiApuVNmMOLsfjgQ,'page':'1'}
      GdceyHwJKozPBYXiApuVNmMOLsfjbT=GdceyHwJKozPBYXiApuVNmMOLsfjtW
     else:
      GdceyHwJKozPBYXiApuVNmMOLsfjTn['mediatype']='episode'
      GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'VOD','mediacode':GdceyHwJKozPBYXiApuVNmMOLsfjQx,'stype':'vod','programcode':GdceyHwJKozPBYXiApuVNmMOLsfjgQ,'title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'thumbnail':GdceyHwJKozPBYXiApuVNmMOLsfjTD}
      GdceyHwJKozPBYXiApuVNmMOLsfjbT=GdceyHwJKozPBYXiApuVNmMOLsfjtE
    else:
     GdceyHwJKozPBYXiApuVNmMOLsfjTn['mediatype']='movie'
     GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'MOVIE','mediacode':GdceyHwJKozPBYXiApuVNmMOLsfjgQ,'stype':'movie','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'thumbnail':GdceyHwJKozPBYXiApuVNmMOLsfjTD}
     GdceyHwJKozPBYXiApuVNmMOLsfjbT=GdceyHwJKozPBYXiApuVNmMOLsfjtE
    GdceyHwJKozPBYXiApuVNmMOLsfjFE={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':GdceyHwJKozPBYXiApuVNmMOLsfjgQ,'vType':GdceyHwJKozPBYXiApuVNmMOLsfjbC,}
    GdceyHwJKozPBYXiApuVNmMOLsfjFt=urllib.parse.urlencode(GdceyHwJKozPBYXiApuVNmMOLsfjFE)
    GdceyHwJKozPBYXiApuVNmMOLsfjTa=[('선택된 시청이력 ( %s ) 삭제'%(GdceyHwJKozPBYXiApuVNmMOLsfjvC),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(GdceyHwJKozPBYXiApuVNmMOLsfjFt))]
    GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel='',img=GdceyHwJKozPBYXiApuVNmMOLsfjTD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjbT,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv,ContextMenu=GdceyHwJKozPBYXiApuVNmMOLsfjTa)
   GdceyHwJKozPBYXiApuVNmMOLsfjTn={'plot':'시청목록을 삭제합니다.'}
   GdceyHwJKozPBYXiApuVNmMOLsfjvC='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':GdceyHwJKozPBYXiApuVNmMOLsfjbC,}
   GdceyHwJKozPBYXiApuVNmMOLsfjbD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel='',img=GdceyHwJKozPBYXiApuVNmMOLsfjbD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtE,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv,isLink=GdceyHwJKozPBYXiApuVNmMOLsfjtW)
   if GdceyHwJKozPBYXiApuVNmMOLsfjbC=='movie':xbmcplugin.setContent(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,'movies')
   else:xbmcplugin.setContent(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtE)
 def Save_Searched_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjQa):
  try:
   GdceyHwJKozPBYXiApuVNmMOLsfjgF=GdceyHwJKozPBYXiApuVNmMOLsfjDI
   GdceyHwJKozPBYXiApuVNmMOLsfjFC=GdceyHwJKozPBYXiApuVNmMOLsfjDR.Load_List_File('search') 
   GdceyHwJKozPBYXiApuVNmMOLsfjgE={'skey':GdceyHwJKozPBYXiApuVNmMOLsfjQa.strip()}
   fp=GdceyHwJKozPBYXiApuVNmMOLsfjtk(GdceyHwJKozPBYXiApuVNmMOLsfjgF,'w',-1,'utf-8')
   GdceyHwJKozPBYXiApuVNmMOLsfjFU=urllib.parse.urlencode(GdceyHwJKozPBYXiApuVNmMOLsfjgE)
   GdceyHwJKozPBYXiApuVNmMOLsfjFU=GdceyHwJKozPBYXiApuVNmMOLsfjFU+'\n'
   fp.write(GdceyHwJKozPBYXiApuVNmMOLsfjFU)
   GdceyHwJKozPBYXiApuVNmMOLsfjFr=0
   for GdceyHwJKozPBYXiApuVNmMOLsfjFl in GdceyHwJKozPBYXiApuVNmMOLsfjFC:
    GdceyHwJKozPBYXiApuVNmMOLsfjFk=GdceyHwJKozPBYXiApuVNmMOLsfjtI(urllib.parse.parse_qsl(GdceyHwJKozPBYXiApuVNmMOLsfjFl))
    GdceyHwJKozPBYXiApuVNmMOLsfjgD=GdceyHwJKozPBYXiApuVNmMOLsfjgE.get('skey').strip()
    GdceyHwJKozPBYXiApuVNmMOLsfjgv=GdceyHwJKozPBYXiApuVNmMOLsfjFk.get('skey').strip()
    if GdceyHwJKozPBYXiApuVNmMOLsfjgD!=GdceyHwJKozPBYXiApuVNmMOLsfjgv:
     fp.write(GdceyHwJKozPBYXiApuVNmMOLsfjFl)
     GdceyHwJKozPBYXiApuVNmMOLsfjFr+=1
     if GdceyHwJKozPBYXiApuVNmMOLsfjFr>=50:break
   fp.close()
  except:
   GdceyHwJKozPBYXiApuVNmMOLsfjtF
 def play_VIDEO(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjgt =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('mediacode')
  GdceyHwJKozPBYXiApuVNmMOLsfjbC =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('stype')
  GdceyHwJKozPBYXiApuVNmMOLsfjgW =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('pvrmode')
  GdceyHwJKozPBYXiApuVNmMOLsfjgn=GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_selQuality(GdceyHwJKozPBYXiApuVNmMOLsfjbC)
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(GdceyHwJKozPBYXiApuVNmMOLsfjgt,GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjgn),GdceyHwJKozPBYXiApuVNmMOLsfjbC,GdceyHwJKozPBYXiApuVNmMOLsfjgW))
  GdceyHwJKozPBYXiApuVNmMOLsfjgI=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.GetBroadURL(GdceyHwJKozPBYXiApuVNmMOLsfjgt,GdceyHwJKozPBYXiApuVNmMOLsfjgn,GdceyHwJKozPBYXiApuVNmMOLsfjbC,GdceyHwJKozPBYXiApuVNmMOLsfjgW,optUHD=GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_uhd())
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_log('qt, stype, url : %s - %s - %s'%(GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjgn),GdceyHwJKozPBYXiApuVNmMOLsfjbC,GdceyHwJKozPBYXiApuVNmMOLsfjgI['streaming_url']))
  if GdceyHwJKozPBYXiApuVNmMOLsfjgI['streaming_url']=='':
   if GdceyHwJKozPBYXiApuVNmMOLsfjgI['error_msg']=='':
    GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_noti(__language__(30908).encode('utf8'))
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_noti(GdceyHwJKozPBYXiApuVNmMOLsfjgI['error_msg'].encode('utf8'))
   return
  if GdceyHwJKozPBYXiApuVNmMOLsfjgI['qt_stream']=='stream70':
   GdceyHwJKozPBYXiApuVNmMOLsfjgR={'user-agent':GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.USER_AGENT_ATV}
  else:
   GdceyHwJKozPBYXiApuVNmMOLsfjgR={'user-agent':GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.USER_AGENT}
  GdceyHwJKozPBYXiApuVNmMOLsfjgh=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.makeDefaultCookies() 
  if GdceyHwJKozPBYXiApuVNmMOLsfjgI['watermark'] !='':
   GdceyHwJKozPBYXiApuVNmMOLsfjgR['x-tving-param1']=GdceyHwJKozPBYXiApuVNmMOLsfjgI['watermarkKey']
   GdceyHwJKozPBYXiApuVNmMOLsfjgR['x-tving-param2']=GdceyHwJKozPBYXiApuVNmMOLsfjgI['watermark'] 
  if GdceyHwJKozPBYXiApuVNmMOLsfjgI['drm_server_url'] !='':
   GdceyHwJKozPBYXiApuVNmMOLsfjgR[GdceyHwJKozPBYXiApuVNmMOLsfjgI['drm_header_key']]=GdceyHwJKozPBYXiApuVNmMOLsfjgI['drm_header_value']
  GdceyHwJKozPBYXiApuVNmMOLsfjgx =GdceyHwJKozPBYXiApuVNmMOLsfjtE
  GdceyHwJKozPBYXiApuVNmMOLsfjgC =GdceyHwJKozPBYXiApuVNmMOLsfjgI['streaming_url'].find('Policy=')
  if GdceyHwJKozPBYXiApuVNmMOLsfjgC!=-1:
   GdceyHwJKozPBYXiApuVNmMOLsfjgl =GdceyHwJKozPBYXiApuVNmMOLsfjgI['streaming_url'].split('?')[0]
   GdceyHwJKozPBYXiApuVNmMOLsfjgk=GdceyHwJKozPBYXiApuVNmMOLsfjtI(urllib.parse.parse_qsl(urllib.parse.urlsplit(GdceyHwJKozPBYXiApuVNmMOLsfjgI['streaming_url']).query))
   GdceyHwJKozPBYXiApuVNmMOLsfjgh['CloudFront-Policy'] =GdceyHwJKozPBYXiApuVNmMOLsfjgk['Policy'] 
   GdceyHwJKozPBYXiApuVNmMOLsfjgh['CloudFront-Signature'] =GdceyHwJKozPBYXiApuVNmMOLsfjgk['Signature'] 
   GdceyHwJKozPBYXiApuVNmMOLsfjgh['CloudFront-Key-Pair-Id']=GdceyHwJKozPBYXiApuVNmMOLsfjgk['Key-Pair-Id'] 
   GdceyHwJKozPBYXiApuVNmMOLsfjgq=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.make_stream_header(GdceyHwJKozPBYXiApuVNmMOLsfjgR,GdceyHwJKozPBYXiApuVNmMOLsfjgh)
   if 'quickvod-mcdn.tving.com' in GdceyHwJKozPBYXiApuVNmMOLsfjgl:
    GdceyHwJKozPBYXiApuVNmMOLsfjgx=GdceyHwJKozPBYXiApuVNmMOLsfjtW
    GdceyHwJKozPBYXiApuVNmMOLsfjgS =GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    GdceyHwJKozPBYXiApuVNmMOLsfjga=GdceyHwJKozPBYXiApuVNmMOLsfjgS.strftime('%Y-%m-%d-%H:%M:%S')
    if GdceyHwJKozPBYXiApuVNmMOLsfjtg(GdceyHwJKozPBYXiApuVNmMOLsfjga.replace('-','').replace(':',''))<GdceyHwJKozPBYXiApuVNmMOLsfjtg(GdceyHwJKozPBYXiApuVNmMOLsfjgk['end'].replace('-','').replace(':','')):
     GdceyHwJKozPBYXiApuVNmMOLsfjgk['end']=GdceyHwJKozPBYXiApuVNmMOLsfjga
     GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_noti(__language__(30915).encode('utf8'))
    GdceyHwJKozPBYXiApuVNmMOLsfjgl ='%s?%s'%(GdceyHwJKozPBYXiApuVNmMOLsfjgl,urllib.parse.urlencode(GdceyHwJKozPBYXiApuVNmMOLsfjgk,doseq=GdceyHwJKozPBYXiApuVNmMOLsfjtW))
    GdceyHwJKozPBYXiApuVNmMOLsfjgU='{}|{}'.format(GdceyHwJKozPBYXiApuVNmMOLsfjgl,GdceyHwJKozPBYXiApuVNmMOLsfjgq)
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjgU='{}|{}'.format(GdceyHwJKozPBYXiApuVNmMOLsfjgI['streaming_url'],GdceyHwJKozPBYXiApuVNmMOLsfjgq)
  else:
   GdceyHwJKozPBYXiApuVNmMOLsfjgq=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.make_stream_header(GdceyHwJKozPBYXiApuVNmMOLsfjgR,GdceyHwJKozPBYXiApuVNmMOLsfjgh)
   GdceyHwJKozPBYXiApuVNmMOLsfjgU='{}|{}'.format(GdceyHwJKozPBYXiApuVNmMOLsfjgI['streaming_url'],GdceyHwJKozPBYXiApuVNmMOLsfjgq)
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_log('if tmp_pos == -1')
  GdceyHwJKozPBYXiApuVNmMOLsfjvQ,GdceyHwJKozPBYXiApuVNmMOLsfjvF=GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_proxyport()
  GdceyHwJKozPBYXiApuVNmMOLsfjvT=GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_playback()
  if(GdceyHwJKozPBYXiApuVNmMOLsfjvQ and GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('mode')in['VOD','MOVIE']and GdceyHwJKozPBYXiApuVNmMOLsfjgx==GdceyHwJKozPBYXiApuVNmMOLsfjtE and(GdceyHwJKozPBYXiApuVNmMOLsfjgI['drm_server_url']!='' or(GdceyHwJKozPBYXiApuVNmMOLsfjgI['url_filename'].split('.')[1]=='mpd')or(GdceyHwJKozPBYXiApuVNmMOLsfjgI['url_filename'].split('.')[1]!='mpd' and GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.KodiVersion>=21 and GdceyHwJKozPBYXiApuVNmMOLsfjgI['qt_stream']=='stream70'))):
   if GdceyHwJKozPBYXiApuVNmMOLsfjgI['url_filename'].split('.')[1]=='mpd':
    GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Tving_Parse_mpd(GdceyHwJKozPBYXiApuVNmMOLsfjgI['streaming_url'],GdceyHwJKozPBYXiApuVNmMOLsfjgI['watermarkKey'],GdceyHwJKozPBYXiApuVNmMOLsfjgI['watermark'])
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Tving_Parse_m3u8(GdceyHwJKozPBYXiApuVNmMOLsfjgI['streaming_url'])
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_log('xxx '+GdceyHwJKozPBYXiApuVNmMOLsfjgI['streaming_url'])
   GdceyHwJKozPBYXiApuVNmMOLsfjgr={'addon':'tvingm','playOption':GdceyHwJKozPBYXiApuVNmMOLsfjvT,'url_filename':GdceyHwJKozPBYXiApuVNmMOLsfjgI['url_filename'],}
   GdceyHwJKozPBYXiApuVNmMOLsfjgr=json.dumps(GdceyHwJKozPBYXiApuVNmMOLsfjgr,separators=(',',':'))
   GdceyHwJKozPBYXiApuVNmMOLsfjgr=base64.standard_b64encode(GdceyHwJKozPBYXiApuVNmMOLsfjgr.encode()).decode('utf-8')
   GdceyHwJKozPBYXiApuVNmMOLsfjgU ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(GdceyHwJKozPBYXiApuVNmMOLsfjvF,GdceyHwJKozPBYXiApuVNmMOLsfjgU,GdceyHwJKozPBYXiApuVNmMOLsfjgr)
   GdceyHwJKozPBYXiApuVNmMOLsfjgR['proxy-mini']=GdceyHwJKozPBYXiApuVNmMOLsfjgr 
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_log('surl(2) : {}'.format(GdceyHwJKozPBYXiApuVNmMOLsfjgU))
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_log('drm     : {}'.format(GdceyHwJKozPBYXiApuVNmMOLsfjgI['drm_server_url']))
  GdceyHwJKozPBYXiApuVNmMOLsfjgq=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.make_stream_header(GdceyHwJKozPBYXiApuVNmMOLsfjgR,GdceyHwJKozPBYXiApuVNmMOLsfjgh)
  GdceyHwJKozPBYXiApuVNmMOLsfjED=xbmcgui.ListItem(path=GdceyHwJKozPBYXiApuVNmMOLsfjgU)
  if GdceyHwJKozPBYXiApuVNmMOLsfjgI['drm_server_url']!='':
   GdceyHwJKozPBYXiApuVNmMOLsfjEv=GdceyHwJKozPBYXiApuVNmMOLsfjgI['drm_server_url']
   GdceyHwJKozPBYXiApuVNmMOLsfjEb ='https://license-global.pallycon.com/ri/licenseManager.do' 
   GdceyHwJKozPBYXiApuVNmMOLsfjET ='mpd'
   GdceyHwJKozPBYXiApuVNmMOLsfjEQ ='com.widevine.alpha'
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   GdceyHwJKozPBYXiApuVNmMOLsfjEg={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.USER_AGENT,GdceyHwJKozPBYXiApuVNmMOLsfjgI['drm_header_key']:GdceyHwJKozPBYXiApuVNmMOLsfjgI['drm_header_value'],}
   GdceyHwJKozPBYXiApuVNmMOLsfjEt=GdceyHwJKozPBYXiApuVNmMOLsfjEb+'|'+urllib.parse.urlencode(GdceyHwJKozPBYXiApuVNmMOLsfjEg)+'|R{SSM}|'
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream','inputstream.adaptive')
   if GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.KodiVersion<=20:
    GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream.adaptive.manifest_type',GdceyHwJKozPBYXiApuVNmMOLsfjET)
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream.adaptive.license_type',GdceyHwJKozPBYXiApuVNmMOLsfjEQ)
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream.adaptive.license_key',GdceyHwJKozPBYXiApuVNmMOLsfjEt)
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream.adaptive.stream_headers',GdceyHwJKozPBYXiApuVNmMOLsfjgq)
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream.adaptive.manifest_headers',GdceyHwJKozPBYXiApuVNmMOLsfjgq)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('mode')in['VOD','MOVIE']:
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setContentLookup(GdceyHwJKozPBYXiApuVNmMOLsfjtE)
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setMimeType('application/x-mpegURL')
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream','inputstream.adaptive')
   if GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.KodiVersion<=20:
    GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream.adaptive.manifest_type','hls')
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream.adaptive.stream_headers',GdceyHwJKozPBYXiApuVNmMOLsfjgq)
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream.adaptive.manifest_headers',GdceyHwJKozPBYXiApuVNmMOLsfjgq)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjgx==GdceyHwJKozPBYXiApuVNmMOLsfjtW:
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setContentLookup(GdceyHwJKozPBYXiApuVNmMOLsfjtE)
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setMimeType('application/x-mpegURL')
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream','inputstream.ffmpegdirect')
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('ResumeTime','0')
   GdceyHwJKozPBYXiApuVNmMOLsfjED.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,GdceyHwJKozPBYXiApuVNmMOLsfjtW,GdceyHwJKozPBYXiApuVNmMOLsfjED)
  try:
   if GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('mode')in['VOD','MOVIE']and GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('title'):
    GdceyHwJKozPBYXiApuVNmMOLsfjbv={'code':GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('programcode')if GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('mode')=='VOD' else GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('mediacode'),'img':GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('thumbnail'),'title':GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('title'),'videoid':GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('mediacode')}
    GdceyHwJKozPBYXiApuVNmMOLsfjDR.Save_Watched_List(GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('stype'),GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  except:
   GdceyHwJKozPBYXiApuVNmMOLsfjtF
 def logout(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  GdceyHwJKozPBYXiApuVNmMOLsfjDk=xbmcgui.Dialog()
  GdceyHwJKozPBYXiApuVNmMOLsfjbI=GdceyHwJKozPBYXiApuVNmMOLsfjDk.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if GdceyHwJKozPBYXiApuVNmMOLsfjbI==GdceyHwJKozPBYXiApuVNmMOLsfjtE:sys.exit()
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Init_TV_Total()
  if os.path.isfile(GdceyHwJKozPBYXiApuVNmMOLsfjDn):os.remove(GdceyHwJKozPBYXiApuVNmMOLsfjDn)
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  GdceyHwJKozPBYXiApuVNmMOLsfjEW =GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Get_Now_Datetime()
  GdceyHwJKozPBYXiApuVNmMOLsfjEn=GdceyHwJKozPBYXiApuVNmMOLsfjEW+datetime.timedelta(days=30) 
  (GdceyHwJKozPBYXiApuVNmMOLsfjbE,GdceyHwJKozPBYXiApuVNmMOLsfjbt,GdceyHwJKozPBYXiApuVNmMOLsfjbW,GdceyHwJKozPBYXiApuVNmMOLsfjbn)=GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_account()
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Save_session_acount(GdceyHwJKozPBYXiApuVNmMOLsfjbE,GdceyHwJKozPBYXiApuVNmMOLsfjbt,GdceyHwJKozPBYXiApuVNmMOLsfjbW,GdceyHwJKozPBYXiApuVNmMOLsfjbn)
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.TV['account']['token_limit']=GdceyHwJKozPBYXiApuVNmMOLsfjEn.strftime('%Y%m%d')
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.JsonFile_Save(GdceyHwJKozPBYXiApuVNmMOLsfjDn,GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.TV)
 def cookiefile_check(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.TV=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.JsonFile_Load(GdceyHwJKozPBYXiApuVNmMOLsfjDn)
  if GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.TV=={}:
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Init_TV_Total()
   return GdceyHwJKozPBYXiApuVNmMOLsfjtE
  (GdceyHwJKozPBYXiApuVNmMOLsfjEI,GdceyHwJKozPBYXiApuVNmMOLsfjER,GdceyHwJKozPBYXiApuVNmMOLsfjEh,GdceyHwJKozPBYXiApuVNmMOLsfjEx)=GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_account()
  (GdceyHwJKozPBYXiApuVNmMOLsfjEC,GdceyHwJKozPBYXiApuVNmMOLsfjEl,GdceyHwJKozPBYXiApuVNmMOLsfjEk,GdceyHwJKozPBYXiApuVNmMOLsfjEq)=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Load_session_acount()
  if(GdceyHwJKozPBYXiApuVNmMOLsfjEI!=GdceyHwJKozPBYXiApuVNmMOLsfjEC or GdceyHwJKozPBYXiApuVNmMOLsfjER!=GdceyHwJKozPBYXiApuVNmMOLsfjEl or GdceyHwJKozPBYXiApuVNmMOLsfjEh!=GdceyHwJKozPBYXiApuVNmMOLsfjEk or GdceyHwJKozPBYXiApuVNmMOLsfjEx!=GdceyHwJKozPBYXiApuVNmMOLsfjEq)and GdceyHwJKozPBYXiApuVNmMOLsfjEC!='xxxxx':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Init_TV_Total()
   return GdceyHwJKozPBYXiApuVNmMOLsfjtE
  if GdceyHwJKozPBYXiApuVNmMOLsfjtg(GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>GdceyHwJKozPBYXiApuVNmMOLsfjtg(GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.TV['account']['token_limit']):
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Init_TV_Total()
   return GdceyHwJKozPBYXiApuVNmMOLsfjtE
  return GdceyHwJKozPBYXiApuVNmMOLsfjtW
 def dp_Global_Search(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjQU=GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('mode')
  if GdceyHwJKozPBYXiApuVNmMOLsfjQU=='TOTAL_SEARCH':
   GdceyHwJKozPBYXiApuVNmMOLsfjES='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   GdceyHwJKozPBYXiApuVNmMOLsfjES='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(GdceyHwJKozPBYXiApuVNmMOLsfjES)
 def dp_Bookmark_Menu(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjES='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(GdceyHwJKozPBYXiApuVNmMOLsfjES)
 def dp_EuroLive_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjba=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.GetEuroChannelList()
  for GdceyHwJKozPBYXiApuVNmMOLsfjbr in GdceyHwJKozPBYXiApuVNmMOLsfjba:
   GdceyHwJKozPBYXiApuVNmMOLsfjTl =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('channel')
   GdceyHwJKozPBYXiApuVNmMOLsfjvC =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('title')
   GdceyHwJKozPBYXiApuVNmMOLsfjTI =GdceyHwJKozPBYXiApuVNmMOLsfjbr.get('subtitle')
   GdceyHwJKozPBYXiApuVNmMOLsfjTn={'mediatype':'episode','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'plot':'%s\n%s'%(GdceyHwJKozPBYXiApuVNmMOLsfjvC,GdceyHwJKozPBYXiApuVNmMOLsfjTI)}
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'LIVE','mediacode':GdceyHwJKozPBYXiApuVNmMOLsfjTl,'stype':'onair',}
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjTI,img='',infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtE,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  if GdceyHwJKozPBYXiApuVNmMOLsfjtx(GdceyHwJKozPBYXiApuVNmMOLsfjba)>0:xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtE)
 def dp_Apple_Group(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjEa=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Get_AppleGroup_List()
  for GdceyHwJKozPBYXiApuVNmMOLsfjEU in GdceyHwJKozPBYXiApuVNmMOLsfjEa:
   GdceyHwJKozPBYXiApuVNmMOLsfjEr =GdceyHwJKozPBYXiApuVNmMOLsfjEU.get('bandName')
   GdceyHwJKozPBYXiApuVNmMOLsfjtD =GdceyHwJKozPBYXiApuVNmMOLsfjEU.get('bandKey')
   GdceyHwJKozPBYXiApuVNmMOLsfjtv =GdceyHwJKozPBYXiApuVNmMOLsfjEU.get('moreUrl')
   GdceyHwJKozPBYXiApuVNmMOLsfjTn={'mediatype':'tvshow','title':GdceyHwJKozPBYXiApuVNmMOLsfjEr,'plot':'%s'%(GdceyHwJKozPBYXiApuVNmMOLsfjtD),}
   GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'BAND_VODLIST','bandKey':GdceyHwJKozPBYXiApuVNmMOLsfjtD,'moreUrl':GdceyHwJKozPBYXiApuVNmMOLsfjtv,'page':'1','nextApiUrl':'-',}
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjEr,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjtF,img='',infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  if GdceyHwJKozPBYXiApuVNmMOLsfjtx(GdceyHwJKozPBYXiApuVNmMOLsfjEa)>0:xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtE)
 def dp_Band_VodList(GdceyHwJKozPBYXiApuVNmMOLsfjDR,GdceyHwJKozPBYXiApuVNmMOLsfjbq):
  GdceyHwJKozPBYXiApuVNmMOLsfjtD =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('bandKey') 
  GdceyHwJKozPBYXiApuVNmMOLsfjtv =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('moreUrl') 
  GdceyHwJKozPBYXiApuVNmMOLsfjtb =GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('nextApiUrl')
  GdceyHwJKozPBYXiApuVNmMOLsfjtT =''
  GdceyHwJKozPBYXiApuVNmMOLsfjbS =GdceyHwJKozPBYXiApuVNmMOLsfjtg(GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('page'))
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_log('bandKey    : {}'.format(GdceyHwJKozPBYXiApuVNmMOLsfjtD))
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_log('moreUrl    : {}'.format(GdceyHwJKozPBYXiApuVNmMOLsfjtv))
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_log('nextApiUrl : {}'.format(GdceyHwJKozPBYXiApuVNmMOLsfjtb))
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.addon_log('page       : {}'.format(GdceyHwJKozPBYXiApuVNmMOLsfjbq.get('page')))
  if GdceyHwJKozPBYXiApuVNmMOLsfjtD=='HM192222':
   GdceyHwJKozPBYXiApuVNmMOLsfjTx,GdceyHwJKozPBYXiApuVNmMOLsfjtb=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Get_Apple_NowList()
  else:
   GdceyHwJKozPBYXiApuVNmMOLsfjTx,GdceyHwJKozPBYXiApuVNmMOLsfjtb=GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.Get_Band_VodList(GdceyHwJKozPBYXiApuVNmMOLsfjtD,GdceyHwJKozPBYXiApuVNmMOLsfjtv,GdceyHwJKozPBYXiApuVNmMOLsfjtb)
  for GdceyHwJKozPBYXiApuVNmMOLsfjTC in GdceyHwJKozPBYXiApuVNmMOLsfjTx:
   GdceyHwJKozPBYXiApuVNmMOLsfjvC =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('title')
   GdceyHwJKozPBYXiApuVNmMOLsfjTD =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('thumbnail')
   GdceyHwJKozPBYXiApuVNmMOLsfjQx =GdceyHwJKozPBYXiApuVNmMOLsfjTC.get('program')
   GdceyHwJKozPBYXiApuVNmMOLsfjTn={'mediatype':'tvshow' if not GdceyHwJKozPBYXiApuVNmMOLsfjQx.startswith('M')else 'movie','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'plot':GdceyHwJKozPBYXiApuVNmMOLsfjvC+'\n'+'tvshow' if not GdceyHwJKozPBYXiApuVNmMOLsfjQx.startswith('M')else 'movie',}
   if not GdceyHwJKozPBYXiApuVNmMOLsfjQx.startswith('M'):
    GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'EPISODE','programcode':GdceyHwJKozPBYXiApuVNmMOLsfjQx,'page':'1',}
    GdceyHwJKozPBYXiApuVNmMOLsfjbT=GdceyHwJKozPBYXiApuVNmMOLsfjtW
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjbv={'mode':'MOVIE','mediacode':GdceyHwJKozPBYXiApuVNmMOLsfjQx,'stype':'movie','title':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'thumbnail':GdceyHwJKozPBYXiApuVNmMOLsfjTD,}
    GdceyHwJKozPBYXiApuVNmMOLsfjbT=GdceyHwJKozPBYXiApuVNmMOLsfjtE
   if GdceyHwJKozPBYXiApuVNmMOLsfjDR.get_settings_makebookmark():
    GdceyHwJKozPBYXiApuVNmMOLsfjTk={'videoid':GdceyHwJKozPBYXiApuVNmMOLsfjQx,'vidtype':'tvshow','vtitle':GdceyHwJKozPBYXiApuVNmMOLsfjvC,'vsubtitle':GdceyHwJKozPBYXiApuVNmMOLsfjtT,}
    GdceyHwJKozPBYXiApuVNmMOLsfjTq=json.dumps(GdceyHwJKozPBYXiApuVNmMOLsfjTk)
    GdceyHwJKozPBYXiApuVNmMOLsfjTq=urllib.parse.quote(GdceyHwJKozPBYXiApuVNmMOLsfjTq)
    GdceyHwJKozPBYXiApuVNmMOLsfjTS='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(GdceyHwJKozPBYXiApuVNmMOLsfjTq)
    GdceyHwJKozPBYXiApuVNmMOLsfjTa=[('(통합) 찜 영상에 추가',GdceyHwJKozPBYXiApuVNmMOLsfjTS)]
   else:
    GdceyHwJKozPBYXiApuVNmMOLsfjTa=GdceyHwJKozPBYXiApuVNmMOLsfjtF
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjtT,img=GdceyHwJKozPBYXiApuVNmMOLsfjTD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjTn,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjbT,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv,ContextMenu=GdceyHwJKozPBYXiApuVNmMOLsfjTa)
  if GdceyHwJKozPBYXiApuVNmMOLsfjtb not in[GdceyHwJKozPBYXiApuVNmMOLsfjtF,'','-']:
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['mode'] ='BAND_VODLIST' 
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['bandKey'] =GdceyHwJKozPBYXiApuVNmMOLsfjtD
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['moreUrl'] =GdceyHwJKozPBYXiApuVNmMOLsfjtv
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['nextApiUrl']=GdceyHwJKozPBYXiApuVNmMOLsfjtb
   GdceyHwJKozPBYXiApuVNmMOLsfjbv['page'] =GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjvC='[B]%s >>[/B]'%'다음 페이지'
   GdceyHwJKozPBYXiApuVNmMOLsfjTI=GdceyHwJKozPBYXiApuVNmMOLsfjtC(GdceyHwJKozPBYXiApuVNmMOLsfjbS+1)
   GdceyHwJKozPBYXiApuVNmMOLsfjbD=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.add_dir(GdceyHwJKozPBYXiApuVNmMOLsfjvC,sublabel=GdceyHwJKozPBYXiApuVNmMOLsfjTI,img=GdceyHwJKozPBYXiApuVNmMOLsfjbD,infoLabels=GdceyHwJKozPBYXiApuVNmMOLsfjtF,isFolder=GdceyHwJKozPBYXiApuVNmMOLsfjtW,params=GdceyHwJKozPBYXiApuVNmMOLsfjbv)
  xbmcplugin.setContent(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(GdceyHwJKozPBYXiApuVNmMOLsfjDR._addon_handle,cacheToDisc=GdceyHwJKozPBYXiApuVNmMOLsfjtE)
 def tving_main(GdceyHwJKozPBYXiApuVNmMOLsfjDR):
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.TvingObj.KodiVersion=GdceyHwJKozPBYXiApuVNmMOLsfjtg(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  GdceyHwJKozPBYXiApuVNmMOLsfjQU=GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params.get('mode',GdceyHwJKozPBYXiApuVNmMOLsfjtF)
  if GdceyHwJKozPBYXiApuVNmMOLsfjQU=='LOGOUT':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.logout()
   return
  GdceyHwJKozPBYXiApuVNmMOLsfjDR.login_main()
  if GdceyHwJKozPBYXiApuVNmMOLsfjQU is GdceyHwJKozPBYXiApuVNmMOLsfjtF:
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Main_List()
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Title_Group(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU in['GLOBAL_GROUP']:
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_SubTitle_Group(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='CHANNEL':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_LiveChannel_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU in['LIVE','VOD','MOVIE']:
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.play_VIDEO(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='PROGRAM':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Program_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='4K_PROGRAM':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_4K_Program_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='ORI_PROGRAM':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Ori_Program_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='EPISODE':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Episode_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='MOVIE_SUB':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Movie_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='4K_MOVIE':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_4K_Movie_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='SEARCH_GROUP':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Search_Group(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU in['SEARCH','LOCAL_SEARCH']:
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Search_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='WATCH':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Watch_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_History_Remove(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='ORDER_BY':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_setEpOrderby(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='SET_BOOKMARK':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Set_Bookmark(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU in['TOTAL_SEARCH','TOTAL_HISTORY']:
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Global_Search(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='SEARCH_HISTORY':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Search_History(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='MENU_BOOKMARK':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Bookmark_Menu(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='EURO_GROUP':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_EuroLive_List(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='APPLE_GROUP':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Apple_Group(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  elif GdceyHwJKozPBYXiApuVNmMOLsfjQU=='BAND_VODLIST':
   GdceyHwJKozPBYXiApuVNmMOLsfjDR.dp_Band_VodList(GdceyHwJKozPBYXiApuVNmMOLsfjDR.main_params)
  else:
   GdceyHwJKozPBYXiApuVNmMOLsfjtF
# Created by pyminifier (https://github.com/liftoff/pyminifier)
