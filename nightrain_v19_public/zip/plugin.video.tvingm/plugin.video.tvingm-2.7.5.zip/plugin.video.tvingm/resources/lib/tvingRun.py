__author__="NightRain"
DSXrTjqnJiLOcyWaUkVYMPQECdsmph=object
DSXrTjqnJiLOcyWaUkVYMPQECdsmpf=None
DSXrTjqnJiLOcyWaUkVYMPQECdsmpz=int
DSXrTjqnJiLOcyWaUkVYMPQECdsmpt=False
DSXrTjqnJiLOcyWaUkVYMPQECdsmpB=True
DSXrTjqnJiLOcyWaUkVYMPQECdsmpb=type
DSXrTjqnJiLOcyWaUkVYMPQECdsmpv=dict
DSXrTjqnJiLOcyWaUkVYMPQECdsmpg=getattr
DSXrTjqnJiLOcyWaUkVYMPQECdsmpK=list
DSXrTjqnJiLOcyWaUkVYMPQECdsmpN=len
DSXrTjqnJiLOcyWaUkVYMPQECdsmpF=str
DSXrTjqnJiLOcyWaUkVYMPQECdsmpA=range
DSXrTjqnJiLOcyWaUkVYMPQECdsmpx=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
DSXrTjqnJiLOcyWaUkVYMPQECdsmwh=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'티빙 오리지날','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'TVING_ORIGINAL'},{'title':'실시간 인기 드라마','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'POP20_DRAMA_HOUR'},{'title':'실시간 인기 예능','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'POP20_UNSCRT_HOUR'},{'title':'Apple TV+ 실시간 인기','mode':'BAND_VODLIST','bandKey':'-','bandGroup':'TVING_APPLE_HOUR'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'Apple TV+','mode':'APPLE_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'},]
DSXrTjqnJiLOcyWaUkVYMPQECdsmwf=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
DSXrTjqnJiLOcyWaUkVYMPQECdsmwz=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
DSXrTjqnJiLOcyWaUkVYMPQECdsmwt=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
DSXrTjqnJiLOcyWaUkVYMPQECdsmwB=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
DSXrTjqnJiLOcyWaUkVYMPQECdsmwb=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
DSXrTjqnJiLOcyWaUkVYMPQECdsmwp=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
DSXrTjqnJiLOcyWaUkVYMPQECdsmwv={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
class DSXrTjqnJiLOcyWaUkVYMPQECdsmwI(DSXrTjqnJiLOcyWaUkVYMPQECdsmph):
 def __init__(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmwK,DSXrTjqnJiLOcyWaUkVYMPQECdsmwN,DSXrTjqnJiLOcyWaUkVYMPQECdsmwF):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_url =DSXrTjqnJiLOcyWaUkVYMPQECdsmwK
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle=DSXrTjqnJiLOcyWaUkVYMPQECdsmwN
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params =DSXrTjqnJiLOcyWaUkVYMPQECdsmwF
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj =nYPfjeUXxLJrqFmMShEoQBOwCvTaIc() 
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_COOKIE_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_TOKEN_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_token.json'))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.SEARCHED_FILE_NAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
 def addon_noti(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,sting):
  try:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwx=xbmcgui.Dialog()
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwx.notification(__addonname__,sting)
  except:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
 def addon_log(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,string):
  try:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwe=string.encode('utf-8','ignore')
  except:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwe='addonException: addon_log'
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwR=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,DSXrTjqnJiLOcyWaUkVYMPQECdsmwe),level=DSXrTjqnJiLOcyWaUkVYMPQECdsmwR)
 def get_keyboard_input(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmIF):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwG=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
  kb=xbmc.Keyboard()
  kb.setHeading(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwG=kb.getText()
  return DSXrTjqnJiLOcyWaUkVYMPQECdsmwG
 def get_settings_account(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwu =__addon__.getSetting('id')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwl =__addon__.getSetting('pw')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwo =__addon__.getSetting('login_type')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwH=DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(__addon__.getSetting('selected_profile'))
  return(DSXrTjqnJiLOcyWaUkVYMPQECdsmwu,DSXrTjqnJiLOcyWaUkVYMPQECdsmwl,DSXrTjqnJiLOcyWaUkVYMPQECdsmwo,DSXrTjqnJiLOcyWaUkVYMPQECdsmwH)
 def get_settings_uhd(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  return DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
 def get_settings_playback(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIw={'active_uhd':DSXrTjqnJiLOcyWaUkVYMPQECdsmpB if __addon__.getSetting('active_uhd')=='true' else DSXrTjqnJiLOcyWaUkVYMPQECdsmpt,'streamFilename':DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_STREAM_FILENAME,}
  return DSXrTjqnJiLOcyWaUkVYMPQECdsmIw
 def get_settings_proxyport(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIh =DSXrTjqnJiLOcyWaUkVYMPQECdsmpB if __addon__.getSetting('proxyYn')=='true' else DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIf=DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(__addon__.getSetting('proxyPort'))
  return DSXrTjqnJiLOcyWaUkVYMPQECdsmIh,DSXrTjqnJiLOcyWaUkVYMPQECdsmIf
 def get_settings_totalsearch(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIz =DSXrTjqnJiLOcyWaUkVYMPQECdsmpB if __addon__.getSetting('local_search')=='true' else DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIt=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB if __addon__.getSetting('local_history')=='true' else DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIB =DSXrTjqnJiLOcyWaUkVYMPQECdsmpB if __addon__.getSetting('total_search')=='true' else DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIb=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB if __addon__.getSetting('total_history')=='true' else DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIp=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB if __addon__.getSetting('menu_bookmark')=='true' else DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  return(DSXrTjqnJiLOcyWaUkVYMPQECdsmIz,DSXrTjqnJiLOcyWaUkVYMPQECdsmIt,DSXrTjqnJiLOcyWaUkVYMPQECdsmIB,DSXrTjqnJiLOcyWaUkVYMPQECdsmIb,DSXrTjqnJiLOcyWaUkVYMPQECdsmIp)
 def get_settings_makebookmark(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  return DSXrTjqnJiLOcyWaUkVYMPQECdsmpB if __addon__.getSetting('make_bookmark')=='true' else DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
 def get_settings_direct_replay(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIv=DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(__addon__.getSetting('direct_replay'))
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmIv==0:
   return DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  else:
   return DSXrTjqnJiLOcyWaUkVYMPQECdsmpB
 def set_winEpisodeOrderby(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmIK):
  __addon__.setSetting('tving_orderby',DSXrTjqnJiLOcyWaUkVYMPQECdsmIK)
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIg=xbmcgui.Window(10000)
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIg.setProperty('TVING_M_ORDERBY',DSXrTjqnJiLOcyWaUkVYMPQECdsmIK)
 def get_winEpisodeOrderby(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIK=__addon__.getSetting('tving_orderby')
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmIK in['',DSXrTjqnJiLOcyWaUkVYMPQECdsmpf]:DSXrTjqnJiLOcyWaUkVYMPQECdsmIK='desc'
  return DSXrTjqnJiLOcyWaUkVYMPQECdsmIK
 def add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,label,sublabel='',img='',infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params='',isLink=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt,ContextMenu=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIN='%s?%s'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_url,urllib.parse.urlencode(params))
  if sublabel:DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='%s < %s >'%(label,sublabel)
  else: DSXrTjqnJiLOcyWaUkVYMPQECdsmIF=label
  if not img:img='DefaultFolder.png'
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIA=xbmcgui.ListItem(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmpb(img)==DSXrTjqnJiLOcyWaUkVYMPQECdsmpv:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIA.setArt(img)
  else:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIA.setArt({'thumb':img,'poster':img})
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.KodiVersion>=20:
   if infoLabels:DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.Set_InfoTag(DSXrTjqnJiLOcyWaUkVYMPQECdsmIA.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:DSXrTjqnJiLOcyWaUkVYMPQECdsmIA.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIA.setProperty('IsPlayable','true')
  if ContextMenu:DSXrTjqnJiLOcyWaUkVYMPQECdsmIA.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,DSXrTjqnJiLOcyWaUkVYMPQECdsmIN,DSXrTjqnJiLOcyWaUkVYMPQECdsmIA,isFolder)
 def get_selQuality(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,etype):
  try:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIx='selected_quality'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIe=[1080,720,480,360]
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIR=DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(__addon__.getSetting(DSXrTjqnJiLOcyWaUkVYMPQECdsmIx))
   return DSXrTjqnJiLOcyWaUkVYMPQECdsmIe[DSXrTjqnJiLOcyWaUkVYMPQECdsmIR]
  except:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
  return 720 
 def Set_InfoTag(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,video_InfoTag:xbmc.InfoTagVideo,DSXrTjqnJiLOcyWaUkVYMPQECdsmhf):
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmIG,value in DSXrTjqnJiLOcyWaUkVYMPQECdsmhf.items():
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmwv[DSXrTjqnJiLOcyWaUkVYMPQECdsmIG]['type']=='string':
    DSXrTjqnJiLOcyWaUkVYMPQECdsmpg(video_InfoTag,DSXrTjqnJiLOcyWaUkVYMPQECdsmwv[DSXrTjqnJiLOcyWaUkVYMPQECdsmIG]['func'])(value)
   elif DSXrTjqnJiLOcyWaUkVYMPQECdsmwv[DSXrTjqnJiLOcyWaUkVYMPQECdsmIG]['type']=='int':
    if DSXrTjqnJiLOcyWaUkVYMPQECdsmpb(value)==DSXrTjqnJiLOcyWaUkVYMPQECdsmpz:
     DSXrTjqnJiLOcyWaUkVYMPQECdsmIu=DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(value)
    else:
     DSXrTjqnJiLOcyWaUkVYMPQECdsmIu=0
    DSXrTjqnJiLOcyWaUkVYMPQECdsmpg(video_InfoTag,DSXrTjqnJiLOcyWaUkVYMPQECdsmwv[DSXrTjqnJiLOcyWaUkVYMPQECdsmIG]['func'])(DSXrTjqnJiLOcyWaUkVYMPQECdsmIu)
   elif DSXrTjqnJiLOcyWaUkVYMPQECdsmwv[DSXrTjqnJiLOcyWaUkVYMPQECdsmIG]['type']=='actor':
    if value!=[]:
     DSXrTjqnJiLOcyWaUkVYMPQECdsmpg(video_InfoTag,DSXrTjqnJiLOcyWaUkVYMPQECdsmwv[DSXrTjqnJiLOcyWaUkVYMPQECdsmIG]['func'])([xbmc.Actor(name)for name in value])
   elif DSXrTjqnJiLOcyWaUkVYMPQECdsmwv[DSXrTjqnJiLOcyWaUkVYMPQECdsmIG]['type']=='list':
    if DSXrTjqnJiLOcyWaUkVYMPQECdsmpb(value)==DSXrTjqnJiLOcyWaUkVYMPQECdsmpK:
     DSXrTjqnJiLOcyWaUkVYMPQECdsmpg(video_InfoTag,DSXrTjqnJiLOcyWaUkVYMPQECdsmwv[DSXrTjqnJiLOcyWaUkVYMPQECdsmIG]['func'])(value)
    else:
     DSXrTjqnJiLOcyWaUkVYMPQECdsmpg(video_InfoTag,DSXrTjqnJiLOcyWaUkVYMPQECdsmwv[DSXrTjqnJiLOcyWaUkVYMPQECdsmIG]['func'])([value])
 def dp_Main_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  (DSXrTjqnJiLOcyWaUkVYMPQECdsmIz,DSXrTjqnJiLOcyWaUkVYMPQECdsmIt,DSXrTjqnJiLOcyWaUkVYMPQECdsmIB,DSXrTjqnJiLOcyWaUkVYMPQECdsmIb,DSXrTjqnJiLOcyWaUkVYMPQECdsmIp)=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_totalsearch()
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmIl in DSXrTjqnJiLOcyWaUkVYMPQECdsmwh:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF=DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=''
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('mode')=='SEARCH_GROUP' and DSXrTjqnJiLOcyWaUkVYMPQECdsmIz ==DSXrTjqnJiLOcyWaUkVYMPQECdsmpt:continue
   elif DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('mode')=='SEARCH_HISTORY' and DSXrTjqnJiLOcyWaUkVYMPQECdsmIt==DSXrTjqnJiLOcyWaUkVYMPQECdsmpt:continue
   elif DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('mode')=='TOTAL_SEARCH' and DSXrTjqnJiLOcyWaUkVYMPQECdsmIB ==DSXrTjqnJiLOcyWaUkVYMPQECdsmpt:continue
   elif DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('mode')=='TOTAL_HISTORY' and DSXrTjqnJiLOcyWaUkVYMPQECdsmIb==DSXrTjqnJiLOcyWaUkVYMPQECdsmpt:continue
   elif DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('mode')=='MENU_BOOKMARK' and DSXrTjqnJiLOcyWaUkVYMPQECdsmIp==DSXrTjqnJiLOcyWaUkVYMPQECdsmpt:continue
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('mode'),'stype':DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('stype'),'orderby':DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('orderby'),'ordernm':DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('ordernm'),'page':'1','bandKey':DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('bandKey'),'bandGroup':DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('bandGroup'),'nextApiUrl':'-',}
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmhw=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
    DSXrTjqnJiLOcyWaUkVYMPQECdsmhI =DSXrTjqnJiLOcyWaUkVYMPQECdsmpB
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmhw=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB
    DSXrTjqnJiLOcyWaUkVYMPQECdsmhI =DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhf={'title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'plot':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF}
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('mode')=='XXX':DSXrTjqnJiLOcyWaUkVYMPQECdsmhf=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
   if 'icon' in DSXrTjqnJiLOcyWaUkVYMPQECdsmIl:DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',DSXrTjqnJiLOcyWaUkVYMPQECdsmIl.get('icon')) 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel='',img=DSXrTjqnJiLOcyWaUkVYMPQECdsmIo,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmhf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmhw,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH,isLink=DSXrTjqnJiLOcyWaUkVYMPQECdsmhI)
  xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle)
 def login_main(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  (DSXrTjqnJiLOcyWaUkVYMPQECdsmht,DSXrTjqnJiLOcyWaUkVYMPQECdsmhB,DSXrTjqnJiLOcyWaUkVYMPQECdsmhb,DSXrTjqnJiLOcyWaUkVYMPQECdsmhp)=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_account()
  if not(DSXrTjqnJiLOcyWaUkVYMPQECdsmht and DSXrTjqnJiLOcyWaUkVYMPQECdsmhB):
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwx=xbmcgui.Dialog()
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhv=DSXrTjqnJiLOcyWaUkVYMPQECdsmwx.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmhv==DSXrTjqnJiLOcyWaUkVYMPQECdsmpB:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.cookiefile_check():return
  if base64.standard_b64encode(DSXrTjqnJiLOcyWaUkVYMPQECdsmht.encode()).decode('utf-8')in['a3ltOTUxMDg4','a3ltMTA4OA==']:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhg=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.GetCredential2(DSXrTjqnJiLOcyWaUkVYMPQECdsmht,DSXrTjqnJiLOcyWaUkVYMPQECdsmhB,DSXrTjqnJiLOcyWaUkVYMPQECdsmhb,DSXrTjqnJiLOcyWaUkVYMPQECdsmhp)
  else:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwx=xbmcgui.Dialog()
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhK=DSXrTjqnJiLOcyWaUkVYMPQECdsmwx.browse(1,__language__(30917).encode('utf8'),'','.twc',DSXrTjqnJiLOcyWaUkVYMPQECdsmpt,DSXrTjqnJiLOcyWaUkVYMPQECdsmpt,'',DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmhK!='':
    DSXrTjqnJiLOcyWaUkVYMPQECdsmhN=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'))
    xbmcvfs.copy(DSXrTjqnJiLOcyWaUkVYMPQECdsmhK,DSXrTjqnJiLOcyWaUkVYMPQECdsmhN)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmhg=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.WebCookies_Load(DSXrTjqnJiLOcyWaUkVYMPQECdsmhN)
    xbmcvfs.delete(DSXrTjqnJiLOcyWaUkVYMPQECdsmhN)
    if DSXrTjqnJiLOcyWaUkVYMPQECdsmhg:
     DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.JsonFile_Save(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_COOKIE_FILENAME,DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV)
     DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmhg=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhg==DSXrTjqnJiLOcyWaUkVYMPQECdsmpB:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.cookiefile_save()
  else:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhF=DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('stype')
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhF=='live':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhA=DSXrTjqnJiLOcyWaUkVYMPQECdsmwf
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmhF=='vod':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhA=DSXrTjqnJiLOcyWaUkVYMPQECdsmwB
  else:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhA=DSXrTjqnJiLOcyWaUkVYMPQECdsmwb
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmhx in DSXrTjqnJiLOcyWaUkVYMPQECdsmhA:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF=DSXrTjqnJiLOcyWaUkVYMPQECdsmhx.get('title')
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('ordernm')!='-':
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIF+='  ('+DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('ordernm')+')'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':DSXrTjqnJiLOcyWaUkVYMPQECdsmhx.get('mode'),'stype':DSXrTjqnJiLOcyWaUkVYMPQECdsmhx.get('stype'),'orderby':DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('orderby'),'ordernm':DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('ordernm'),'page':'1'}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel='',img='',infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmpN(DSXrTjqnJiLOcyWaUkVYMPQECdsmhA)>0:xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle)
 def dp_SubTitle_Group(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe): 
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmhx in DSXrTjqnJiLOcyWaUkVYMPQECdsmwp:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF=DSXrTjqnJiLOcyWaUkVYMPQECdsmhx.get('title')
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('ordernm')!='-':
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIF+='  ('+DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('ordernm')+')'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':DSXrTjqnJiLOcyWaUkVYMPQECdsmhx.get('mode'),'genreCode':DSXrTjqnJiLOcyWaUkVYMPQECdsmhx.get('genreCode'),'stype':DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('stype'),'orderby':DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('orderby'),'page':'1'}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel='',img='',infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmpN(DSXrTjqnJiLOcyWaUkVYMPQECdsmwp)>0:xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle)
 def dp_LiveChannel_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhF =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('stype')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhR =DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('page'))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhG,DSXrTjqnJiLOcyWaUkVYMPQECdsmhu=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.GetLiveChannelList(DSXrTjqnJiLOcyWaUkVYMPQECdsmhF,DSXrTjqnJiLOcyWaUkVYMPQECdsmhR)
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmhl in DSXrTjqnJiLOcyWaUkVYMPQECdsmhG:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhz =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('channel')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmho =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('thumbnail')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhH =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('synopsis')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfw =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('channelepg')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfI =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('cast')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfh =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('director')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfz =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('info_genre')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmft =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('year')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfB =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('mpaa')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfb =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('premiered')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'mediatype':'episode','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'studio':DSXrTjqnJiLOcyWaUkVYMPQECdsmhz,'cast':DSXrTjqnJiLOcyWaUkVYMPQECdsmfI,'director':DSXrTjqnJiLOcyWaUkVYMPQECdsmfh,'genre':DSXrTjqnJiLOcyWaUkVYMPQECdsmfz,'plot':'%s\n%s\n%s\n\n%s'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmhz,DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,DSXrTjqnJiLOcyWaUkVYMPQECdsmfw,DSXrTjqnJiLOcyWaUkVYMPQECdsmhH),'year':DSXrTjqnJiLOcyWaUkVYMPQECdsmft,'mpaa':DSXrTjqnJiLOcyWaUkVYMPQECdsmfB,'premiered':DSXrTjqnJiLOcyWaUkVYMPQECdsmfb}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'LIVE','mediacode':DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('mediacode'),'stype':DSXrTjqnJiLOcyWaUkVYMPQECdsmhF}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmhz,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmho,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhu:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['mode']='CHANNEL' 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['stype']=DSXrTjqnJiLOcyWaUkVYMPQECdsmhF 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['page']=DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='[B]%s >>[/B]'%'다음 페이지'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfv=DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmfv,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmIo,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmpN(DSXrTjqnJiLOcyWaUkVYMPQECdsmhG)>0:xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
 def dp_Program_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmfg =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('stype')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIK =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('orderby')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhR =DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('page'))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmfK=DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('genreCode')
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmfK==DSXrTjqnJiLOcyWaUkVYMPQECdsmpf:DSXrTjqnJiLOcyWaUkVYMPQECdsmfK='all'
  DSXrTjqnJiLOcyWaUkVYMPQECdsmfN,DSXrTjqnJiLOcyWaUkVYMPQECdsmhu=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.GetProgramList(DSXrTjqnJiLOcyWaUkVYMPQECdsmfg,DSXrTjqnJiLOcyWaUkVYMPQECdsmIK,DSXrTjqnJiLOcyWaUkVYMPQECdsmhR,DSXrTjqnJiLOcyWaUkVYMPQECdsmfK)
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmfF in DSXrTjqnJiLOcyWaUkVYMPQECdsmfN:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmho =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('thumbnail')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhH =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('synopsis')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfA =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('channel')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfI =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('cast')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfh =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('director')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfz=DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('info_genre')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmft =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('year')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfb =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('premiered')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfB =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('mpaa')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'mediatype':'tvshow','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'studio':DSXrTjqnJiLOcyWaUkVYMPQECdsmfA,'cast':DSXrTjqnJiLOcyWaUkVYMPQECdsmfI,'director':DSXrTjqnJiLOcyWaUkVYMPQECdsmfh,'genre':DSXrTjqnJiLOcyWaUkVYMPQECdsmfz,'year':DSXrTjqnJiLOcyWaUkVYMPQECdsmft,'premiered':DSXrTjqnJiLOcyWaUkVYMPQECdsmfb,'mpaa':DSXrTjqnJiLOcyWaUkVYMPQECdsmfB,'plot':DSXrTjqnJiLOcyWaUkVYMPQECdsmhH}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'EPISODE','programcode':DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('program'),'page':'1'}
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_makebookmark():
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfx={'videoid':DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('program'),'vidtype':'tvshow','vtitle':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'vsubtitle':DSXrTjqnJiLOcyWaUkVYMPQECdsmfA,}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfe=json.dumps(DSXrTjqnJiLOcyWaUkVYMPQECdsmfx)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfe=urllib.parse.quote(DSXrTjqnJiLOcyWaUkVYMPQECdsmfe)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfR='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmfe)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=[('(통합) 찜 영상에 추가',DSXrTjqnJiLOcyWaUkVYMPQECdsmfR)]
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmfA,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmho,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH,ContextMenu=DSXrTjqnJiLOcyWaUkVYMPQECdsmfG)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhu:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['mode'] ='PROGRAM' 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['stype'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmfg
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['orderby'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmIK
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['page'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['genreCode']=DSXrTjqnJiLOcyWaUkVYMPQECdsmfK 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='[B]%s >>[/B]'%'다음 페이지'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfv=DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmfv,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmIo,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  xbmcplugin.setContent(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
 def dp_4K_Program_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhR =DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('page'))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmfN,DSXrTjqnJiLOcyWaUkVYMPQECdsmhu=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Get_UHD_ProgramList(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR)
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmfF in DSXrTjqnJiLOcyWaUkVYMPQECdsmfN:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmho =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('thumbnail')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhH =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('synopsis')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfA =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('channel')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfI =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('cast')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfh =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('director')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfz=DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('info_genre')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmft =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('year')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfb =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('premiered')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfB =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('mpaa')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'mediatype':'tvshow','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'studio':DSXrTjqnJiLOcyWaUkVYMPQECdsmfA,'cast':DSXrTjqnJiLOcyWaUkVYMPQECdsmfI,'director':DSXrTjqnJiLOcyWaUkVYMPQECdsmfh,'genre':DSXrTjqnJiLOcyWaUkVYMPQECdsmfz,'year':DSXrTjqnJiLOcyWaUkVYMPQECdsmft,'premiered':DSXrTjqnJiLOcyWaUkVYMPQECdsmfb,'mpaa':DSXrTjqnJiLOcyWaUkVYMPQECdsmfB,'plot':DSXrTjqnJiLOcyWaUkVYMPQECdsmhH}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'EPISODE','programcode':DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('program'),'page':'1'}
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_makebookmark():
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfx={'videoid':DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('program'),'vidtype':'tvshow','vtitle':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'vsubtitle':DSXrTjqnJiLOcyWaUkVYMPQECdsmfA,}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfe=json.dumps(DSXrTjqnJiLOcyWaUkVYMPQECdsmfx)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfe=urllib.parse.quote(DSXrTjqnJiLOcyWaUkVYMPQECdsmfe)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfR='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmfe)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=[('(통합) 찜 영상에 추가',DSXrTjqnJiLOcyWaUkVYMPQECdsmfR)]
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmfA,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmho,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH,ContextMenu=DSXrTjqnJiLOcyWaUkVYMPQECdsmfG)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhu:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['mode'] ='4K_PROGRAM' 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['page'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='[B]%s >>[/B]'%'다음 페이지'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfv=DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmfv,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmIo,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  xbmcplugin.setContent(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
 def dp_Ori_Program_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhR =DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('page'))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmfN,DSXrTjqnJiLOcyWaUkVYMPQECdsmhu=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Get_Origianl_ProgramList(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR)
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmfF in DSXrTjqnJiLOcyWaUkVYMPQECdsmfN:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmho =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('thumbnail')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfl =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('vod_type')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfo =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('vod_code')
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmfl=='vod':
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'mediatype':'tvshow','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'EPISODE','programcode':DSXrTjqnJiLOcyWaUkVYMPQECdsmfo,'page':'1',}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmhw=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'mediatype':'movie','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'plot':'movie',}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'MOVIE','mediacode':DSXrTjqnJiLOcyWaUkVYMPQECdsmfo,'stype':'movie','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'thumbnail':DSXrTjqnJiLOcyWaUkVYMPQECdsmho,}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmhw=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmho,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmhw,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH,ContextMenu=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhu:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['mode'] ='ORI_PROGRAM' 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['page'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='[B]%s >>[/B]'%'다음 페이지'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfv=DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmfv,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmIo,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  xbmcplugin.setContent(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
 def dp_Episode_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmfH=DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('programcode')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhR =DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('page'))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_log('programcode : '+DSXrTjqnJiLOcyWaUkVYMPQECdsmfH)
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzw,DSXrTjqnJiLOcyWaUkVYMPQECdsmhu,DSXrTjqnJiLOcyWaUkVYMPQECdsmzI=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.GetEpisodeList(DSXrTjqnJiLOcyWaUkVYMPQECdsmfH,DSXrTjqnJiLOcyWaUkVYMPQECdsmhR,orderby=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_winEpisodeOrderby())
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmzh in DSXrTjqnJiLOcyWaUkVYMPQECdsmzw:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF =DSXrTjqnJiLOcyWaUkVYMPQECdsmzh.get('title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfv =DSXrTjqnJiLOcyWaUkVYMPQECdsmzh.get('subtitle')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmho =DSXrTjqnJiLOcyWaUkVYMPQECdsmzh.get('thumbnail')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhH =DSXrTjqnJiLOcyWaUkVYMPQECdsmzh.get('synopsis')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzf=DSXrTjqnJiLOcyWaUkVYMPQECdsmzh.get('info_title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzt =DSXrTjqnJiLOcyWaUkVYMPQECdsmzh.get('aired')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzB =DSXrTjqnJiLOcyWaUkVYMPQECdsmzh.get('studio')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzb =DSXrTjqnJiLOcyWaUkVYMPQECdsmzh.get('frequency')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'mediatype':'episode','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmzf,'aired':DSXrTjqnJiLOcyWaUkVYMPQECdsmzt,'studio':DSXrTjqnJiLOcyWaUkVYMPQECdsmzB,'episode':DSXrTjqnJiLOcyWaUkVYMPQECdsmzb,'plot':DSXrTjqnJiLOcyWaUkVYMPQECdsmhH}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'VOD','mediacode':DSXrTjqnJiLOcyWaUkVYMPQECdsmzh.get('episode'),'stype':'vod','programcode':DSXrTjqnJiLOcyWaUkVYMPQECdsmfH,'title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'thumbnail':DSXrTjqnJiLOcyWaUkVYMPQECdsmho}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmfv,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmho,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhR==1:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'plot':'정렬순서를 변경합니다.'}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['mode'] ='ORDER_BY' 
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_winEpisodeOrderby()=='desc':
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='정렬순서변경 : 최신화부터 -> 1회부터'
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['orderby']='asc'
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='정렬순서변경 : 1회부터 -> 최신화부터'
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['orderby']='desc'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel='',img=DSXrTjqnJiLOcyWaUkVYMPQECdsmIo,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH,isLink=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhu:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['mode'] ='EPISODE' 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['programcode']=DSXrTjqnJiLOcyWaUkVYMPQECdsmfH
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['page'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='[B]%s >>[/B]'%'다음 페이지'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfv=DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmfv,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmIo,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  xbmcplugin.setContent(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,'episodes')
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmpN(DSXrTjqnJiLOcyWaUkVYMPQECdsmzw)>0:xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB)
 def dp_setEpOrderby(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIK =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('orderby')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.set_winEpisodeOrderby(DSXrTjqnJiLOcyWaUkVYMPQECdsmIK)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmfg =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('stype')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIK =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('orderby')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhR=DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('page'))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzp,DSXrTjqnJiLOcyWaUkVYMPQECdsmhu=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.GetMovieList(DSXrTjqnJiLOcyWaUkVYMPQECdsmfg,DSXrTjqnJiLOcyWaUkVYMPQECdsmIK,DSXrTjqnJiLOcyWaUkVYMPQECdsmhR)
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmzv in DSXrTjqnJiLOcyWaUkVYMPQECdsmzp:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmho =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('thumbnail')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhH =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('synopsis')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzf =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('info_title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmft =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('year')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfI =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('cast')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfh =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('director')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfz =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('info_genre')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzg =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('duration')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfb =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('premiered')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzB =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('studio')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfB =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('mpaa')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'mediatype':'movie','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmzf,'year':DSXrTjqnJiLOcyWaUkVYMPQECdsmft,'cast':DSXrTjqnJiLOcyWaUkVYMPQECdsmfI,'director':DSXrTjqnJiLOcyWaUkVYMPQECdsmfh,'genre':DSXrTjqnJiLOcyWaUkVYMPQECdsmfz,'duration':DSXrTjqnJiLOcyWaUkVYMPQECdsmzg,'premiered':DSXrTjqnJiLOcyWaUkVYMPQECdsmfb,'studio':DSXrTjqnJiLOcyWaUkVYMPQECdsmzB,'mpaa':DSXrTjqnJiLOcyWaUkVYMPQECdsmfB,'plot':DSXrTjqnJiLOcyWaUkVYMPQECdsmhH}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'MOVIE','mediacode':DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('moviecode'),'stype':'movie','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'thumbnail':DSXrTjqnJiLOcyWaUkVYMPQECdsmho}
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_makebookmark():
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfx={'videoid':DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('moviecode'),'vidtype':'movie','vtitle':DSXrTjqnJiLOcyWaUkVYMPQECdsmzf,'vsubtitle':'',}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfe=json.dumps(DSXrTjqnJiLOcyWaUkVYMPQECdsmfx)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfe=urllib.parse.quote(DSXrTjqnJiLOcyWaUkVYMPQECdsmfe)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfR='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmfe)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=[('(통합) 찜 영상에 추가',DSXrTjqnJiLOcyWaUkVYMPQECdsmfR)]
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel='',img=DSXrTjqnJiLOcyWaUkVYMPQECdsmho,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH,ContextMenu=DSXrTjqnJiLOcyWaUkVYMPQECdsmfG)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhu:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['mode'] ='MOVIE_SUB' 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['orderby']=DSXrTjqnJiLOcyWaUkVYMPQECdsmIK
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['stype'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmfg
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['page'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='[B]%s >>[/B]'%'다음 페이지'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfv=DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmfv,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmIo,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  xbmcplugin.setContent(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,'movies')
  xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
 def dp_4K_Movie_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhR=DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('page'))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzp,DSXrTjqnJiLOcyWaUkVYMPQECdsmhu=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Get_UHD_MovieList(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR)
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmzv in DSXrTjqnJiLOcyWaUkVYMPQECdsmzp:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmho =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('thumbnail')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhH =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('synopsis')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzf =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('info_title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmft =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('year')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfI =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('cast')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfh =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('director')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfz =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('info_genre')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzg =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('duration')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfb =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('premiered')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzB =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('studio')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfB =DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('mpaa')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'mediatype':'movie','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmzf,'year':DSXrTjqnJiLOcyWaUkVYMPQECdsmft,'cast':DSXrTjqnJiLOcyWaUkVYMPQECdsmfI,'director':DSXrTjqnJiLOcyWaUkVYMPQECdsmfh,'genre':DSXrTjqnJiLOcyWaUkVYMPQECdsmfz,'duration':DSXrTjqnJiLOcyWaUkVYMPQECdsmzg,'premiered':DSXrTjqnJiLOcyWaUkVYMPQECdsmfb,'studio':DSXrTjqnJiLOcyWaUkVYMPQECdsmzB,'mpaa':DSXrTjqnJiLOcyWaUkVYMPQECdsmfB,'plot':DSXrTjqnJiLOcyWaUkVYMPQECdsmhH}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'MOVIE','mediacode':DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('moviecode'),'stype':'movie','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'thumbnail':DSXrTjqnJiLOcyWaUkVYMPQECdsmho}
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_makebookmark():
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfx={'videoid':DSXrTjqnJiLOcyWaUkVYMPQECdsmzv.get('moviecode'),'vidtype':'movie','vtitle':DSXrTjqnJiLOcyWaUkVYMPQECdsmzf,'vsubtitle':'',}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfe=json.dumps(DSXrTjqnJiLOcyWaUkVYMPQECdsmfx)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfe=urllib.parse.quote(DSXrTjqnJiLOcyWaUkVYMPQECdsmfe)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfR='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmfe)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=[('(통합) 찜 영상에 추가',DSXrTjqnJiLOcyWaUkVYMPQECdsmfR)]
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel='',img=DSXrTjqnJiLOcyWaUkVYMPQECdsmho,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH,ContextMenu=DSXrTjqnJiLOcyWaUkVYMPQECdsmfG)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhu:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['mode'] ='4K_MOVIE' 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['page'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='[B]%s >>[/B]'%'다음 페이지'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfv=DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmfv,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmIo,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  xbmcplugin.setContent(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,'movies')
  xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
 def dp_Set_Bookmark(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzK=urllib.parse.unquote(DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('bm_param'))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzK=json.loads(DSXrTjqnJiLOcyWaUkVYMPQECdsmzK)
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzN =DSXrTjqnJiLOcyWaUkVYMPQECdsmzK.get('videoid')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzF =DSXrTjqnJiLOcyWaUkVYMPQECdsmzK.get('vidtype')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzA =DSXrTjqnJiLOcyWaUkVYMPQECdsmzK.get('vtitle')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzx =DSXrTjqnJiLOcyWaUkVYMPQECdsmzK.get('vsubtitle')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwx=xbmcgui.Dialog()
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhv=DSXrTjqnJiLOcyWaUkVYMPQECdsmwx.yesno(__language__(30913).encode('utf8'),DSXrTjqnJiLOcyWaUkVYMPQECdsmzA+' \n\n'+__language__(30914))
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhv==DSXrTjqnJiLOcyWaUkVYMPQECdsmpt:return
  DSXrTjqnJiLOcyWaUkVYMPQECdsmze=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.GetBookmarkInfo(DSXrTjqnJiLOcyWaUkVYMPQECdsmzN,DSXrTjqnJiLOcyWaUkVYMPQECdsmzF)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmzx!='':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmze['saveinfo']['subtitle']=DSXrTjqnJiLOcyWaUkVYMPQECdsmzx 
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmzF=='tvshow':DSXrTjqnJiLOcyWaUkVYMPQECdsmze['saveinfo']['infoLabels']['studio']=DSXrTjqnJiLOcyWaUkVYMPQECdsmzx 
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzR=json.dumps(DSXrTjqnJiLOcyWaUkVYMPQECdsmze)
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzR=urllib.parse.quote(DSXrTjqnJiLOcyWaUkVYMPQECdsmzR)
  DSXrTjqnJiLOcyWaUkVYMPQECdsmfR ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmzR)
  xbmc.executebuiltin(DSXrTjqnJiLOcyWaUkVYMPQECdsmfR)
 def dp_Search_Group(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  if 'search_key' in DSXrTjqnJiLOcyWaUkVYMPQECdsmhe:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzG=DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('search_key')
  else:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzG=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not DSXrTjqnJiLOcyWaUkVYMPQECdsmzG:
    return
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmhx in DSXrTjqnJiLOcyWaUkVYMPQECdsmwt:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzu =DSXrTjqnJiLOcyWaUkVYMPQECdsmhx.get('mode')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhF=DSXrTjqnJiLOcyWaUkVYMPQECdsmhx.get('stype')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF=DSXrTjqnJiLOcyWaUkVYMPQECdsmhx.get('title')
   (DSXrTjqnJiLOcyWaUkVYMPQECdsmzl,DSXrTjqnJiLOcyWaUkVYMPQECdsmhu)=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.GetSearchList(DSXrTjqnJiLOcyWaUkVYMPQECdsmzG,1,DSXrTjqnJiLOcyWaUkVYMPQECdsmhF)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhf={'plot':'검색어 : '+DSXrTjqnJiLOcyWaUkVYMPQECdsmzG+'\n\n'+DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.Search_FreeList(DSXrTjqnJiLOcyWaUkVYMPQECdsmzl)}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':DSXrTjqnJiLOcyWaUkVYMPQECdsmzu,'stype':DSXrTjqnJiLOcyWaUkVYMPQECdsmhF,'search_key':DSXrTjqnJiLOcyWaUkVYMPQECdsmzG,'page':'1',}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel='',img='',infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmhf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmpN(DSXrTjqnJiLOcyWaUkVYMPQECdsmwt)>0:xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB)
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.Save_Searched_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmzG)
 def Search_FreeList(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmtb):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzo=''
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzH=7
  try:
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmpN(DSXrTjqnJiLOcyWaUkVYMPQECdsmtb)==0:return '검색결과 없음'
   for i in DSXrTjqnJiLOcyWaUkVYMPQECdsmpA(DSXrTjqnJiLOcyWaUkVYMPQECdsmpN(DSXrTjqnJiLOcyWaUkVYMPQECdsmtb)):
    if i>=DSXrTjqnJiLOcyWaUkVYMPQECdsmzH:
     DSXrTjqnJiLOcyWaUkVYMPQECdsmzo=DSXrTjqnJiLOcyWaUkVYMPQECdsmzo+'...'
     break
    DSXrTjqnJiLOcyWaUkVYMPQECdsmzo=DSXrTjqnJiLOcyWaUkVYMPQECdsmzo+DSXrTjqnJiLOcyWaUkVYMPQECdsmtb[i]['title']+'\n'
  except:
   return ''
  return DSXrTjqnJiLOcyWaUkVYMPQECdsmzo
 def dp_Search_History(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmtw=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.Load_List_File('search')
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmtI in DSXrTjqnJiLOcyWaUkVYMPQECdsmtw:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmth=DSXrTjqnJiLOcyWaUkVYMPQECdsmpv(urllib.parse.parse_qsl(DSXrTjqnJiLOcyWaUkVYMPQECdsmtI))
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtf=DSXrTjqnJiLOcyWaUkVYMPQECdsmth.get('skey').strip()
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'SEARCH_GROUP','search_key':DSXrTjqnJiLOcyWaUkVYMPQECdsmtf,}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtz={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':DSXrTjqnJiLOcyWaUkVYMPQECdsmtf,'vType':'-',}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtB=urllib.parse.urlencode(DSXrTjqnJiLOcyWaUkVYMPQECdsmtz)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=[('선택된 검색어 ( %s ) 삭제'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmtf),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmtB))]
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmtf,sublabel='',img=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH,ContextMenu=DSXrTjqnJiLOcyWaUkVYMPQECdsmfG)
  DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'plot':'검색목록 전체를 삭제합니다.'}
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel='',img=DSXrTjqnJiLOcyWaUkVYMPQECdsmIo,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH,isLink=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB)
  xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
 def dp_Search_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhR =DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('page'))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhF =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('stype')
  if 'search_key' in DSXrTjqnJiLOcyWaUkVYMPQECdsmhe:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzG=DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('search_key')
  else:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzG=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not DSXrTjqnJiLOcyWaUkVYMPQECdsmzG:
    xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle)
    return
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzl,DSXrTjqnJiLOcyWaUkVYMPQECdsmhu=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.GetSearchList(DSXrTjqnJiLOcyWaUkVYMPQECdsmzG,DSXrTjqnJiLOcyWaUkVYMPQECdsmhR,DSXrTjqnJiLOcyWaUkVYMPQECdsmhF)
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmtb in DSXrTjqnJiLOcyWaUkVYMPQECdsmzl:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF =DSXrTjqnJiLOcyWaUkVYMPQECdsmtb.get('title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmho =DSXrTjqnJiLOcyWaUkVYMPQECdsmtb.get('thumbnail')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhH =DSXrTjqnJiLOcyWaUkVYMPQECdsmtb.get('synopsis')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtp =DSXrTjqnJiLOcyWaUkVYMPQECdsmtb.get('program')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfI =DSXrTjqnJiLOcyWaUkVYMPQECdsmtb.get('cast')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfh =DSXrTjqnJiLOcyWaUkVYMPQECdsmtb.get('director')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfz=DSXrTjqnJiLOcyWaUkVYMPQECdsmtb.get('info_genre')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzg =DSXrTjqnJiLOcyWaUkVYMPQECdsmtb.get('duration')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfB =DSXrTjqnJiLOcyWaUkVYMPQECdsmtb.get('mpaa')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmft =DSXrTjqnJiLOcyWaUkVYMPQECdsmtb.get('year')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzt =DSXrTjqnJiLOcyWaUkVYMPQECdsmtb.get('aired')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'mediatype':'tvshow' if DSXrTjqnJiLOcyWaUkVYMPQECdsmhF=='vod' else 'movie','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'cast':DSXrTjqnJiLOcyWaUkVYMPQECdsmfI,'director':DSXrTjqnJiLOcyWaUkVYMPQECdsmfh,'genre':DSXrTjqnJiLOcyWaUkVYMPQECdsmfz,'duration':DSXrTjqnJiLOcyWaUkVYMPQECdsmzg,'mpaa':DSXrTjqnJiLOcyWaUkVYMPQECdsmfB,'year':DSXrTjqnJiLOcyWaUkVYMPQECdsmft,'aired':DSXrTjqnJiLOcyWaUkVYMPQECdsmzt,'plot':'%s\n\n%s'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,DSXrTjqnJiLOcyWaUkVYMPQECdsmhH)}
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmhF=='vod':
    DSXrTjqnJiLOcyWaUkVYMPQECdsmzN=DSXrTjqnJiLOcyWaUkVYMPQECdsmtb.get('program')
    DSXrTjqnJiLOcyWaUkVYMPQECdsmzF='tvshow'
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'EPISODE','programcode':DSXrTjqnJiLOcyWaUkVYMPQECdsmzN,'page':'1',}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmhw=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmzN=DSXrTjqnJiLOcyWaUkVYMPQECdsmtb.get('movie')
    DSXrTjqnJiLOcyWaUkVYMPQECdsmzF='movie'
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'MOVIE','mediacode':DSXrTjqnJiLOcyWaUkVYMPQECdsmzN,'stype':'movie','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'thumbnail':DSXrTjqnJiLOcyWaUkVYMPQECdsmho,}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmhw=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_makebookmark():
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfx={'videoid':DSXrTjqnJiLOcyWaUkVYMPQECdsmzN,'vidtype':DSXrTjqnJiLOcyWaUkVYMPQECdsmzF,'vtitle':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'vsubtitle':'',}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfe=json.dumps(DSXrTjqnJiLOcyWaUkVYMPQECdsmfx)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfe=urllib.parse.quote(DSXrTjqnJiLOcyWaUkVYMPQECdsmfe)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfR='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmfe)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=[('(통합) 찜 영상에 추가',DSXrTjqnJiLOcyWaUkVYMPQECdsmfR)]
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel='',img=DSXrTjqnJiLOcyWaUkVYMPQECdsmho,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmhw,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH,isLink=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt,ContextMenu=DSXrTjqnJiLOcyWaUkVYMPQECdsmfG)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhu:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['mode'] ='SEARCH' 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['search_key']=DSXrTjqnJiLOcyWaUkVYMPQECdsmzG
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['page'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='[B]%s >>[/B]'%'다음 페이지'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfv=DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmfv,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmIo,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhF=='movie':xbmcplugin.setContent(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,'movies')
  else:xbmcplugin.setContent(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
 def dp_History_Remove(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmtv=DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('delType')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmtg =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('sKey')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmtK =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('vType')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwx=xbmcgui.Dialog()
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmtv=='SEARCH_ALL':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhv=DSXrTjqnJiLOcyWaUkVYMPQECdsmwx.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmtv=='SEARCH_ONE':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhv=DSXrTjqnJiLOcyWaUkVYMPQECdsmwx.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmtv=='WATCH_ALL':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhv=DSXrTjqnJiLOcyWaUkVYMPQECdsmwx.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmtv=='WATCH_ONE':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmhv=DSXrTjqnJiLOcyWaUkVYMPQECdsmwx.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhv==DSXrTjqnJiLOcyWaUkVYMPQECdsmpt:sys.exit()
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmtv=='SEARCH_ALL':
   if os.path.isfile(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.SEARCHED_FILE_NAME):os.remove(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.SEARCHED_FILE_NAME)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmtv=='SEARCH_ONE':
   try:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmtN=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.SEARCHED_FILE_NAME
    DSXrTjqnJiLOcyWaUkVYMPQECdsmtF=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.Load_List_File('search') 
    fp=DSXrTjqnJiLOcyWaUkVYMPQECdsmpx(DSXrTjqnJiLOcyWaUkVYMPQECdsmtN,'w',-1,'utf-8')
    for DSXrTjqnJiLOcyWaUkVYMPQECdsmtA in DSXrTjqnJiLOcyWaUkVYMPQECdsmtF:
     DSXrTjqnJiLOcyWaUkVYMPQECdsmtx=DSXrTjqnJiLOcyWaUkVYMPQECdsmpv(urllib.parse.parse_qsl(DSXrTjqnJiLOcyWaUkVYMPQECdsmtA))
     DSXrTjqnJiLOcyWaUkVYMPQECdsmte=DSXrTjqnJiLOcyWaUkVYMPQECdsmtx.get('skey').strip()
     if DSXrTjqnJiLOcyWaUkVYMPQECdsmtg!=DSXrTjqnJiLOcyWaUkVYMPQECdsmte:
      fp.write(DSXrTjqnJiLOcyWaUkVYMPQECdsmtA)
    fp.close()
   except:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmtv=='WATCH_ALL':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%DSXrTjqnJiLOcyWaUkVYMPQECdsmtK))
   if os.path.isfile(DSXrTjqnJiLOcyWaUkVYMPQECdsmtN):os.remove(DSXrTjqnJiLOcyWaUkVYMPQECdsmtN)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmtv=='WATCH_ONE':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%DSXrTjqnJiLOcyWaUkVYMPQECdsmtK))
   try:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmtF=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.Load_List_File(DSXrTjqnJiLOcyWaUkVYMPQECdsmtK) 
    fp=DSXrTjqnJiLOcyWaUkVYMPQECdsmpx(DSXrTjqnJiLOcyWaUkVYMPQECdsmtN,'w',-1,'utf-8')
    for DSXrTjqnJiLOcyWaUkVYMPQECdsmtA in DSXrTjqnJiLOcyWaUkVYMPQECdsmtF:
     DSXrTjqnJiLOcyWaUkVYMPQECdsmtx=DSXrTjqnJiLOcyWaUkVYMPQECdsmpv(urllib.parse.parse_qsl(DSXrTjqnJiLOcyWaUkVYMPQECdsmtA))
     DSXrTjqnJiLOcyWaUkVYMPQECdsmte=DSXrTjqnJiLOcyWaUkVYMPQECdsmtx.get('code').strip()
     if DSXrTjqnJiLOcyWaUkVYMPQECdsmtg!=DSXrTjqnJiLOcyWaUkVYMPQECdsmte:
      fp.write(DSXrTjqnJiLOcyWaUkVYMPQECdsmtA)
    fp.close()
   except:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhF): 
  try:
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmhF=='search':
    DSXrTjqnJiLOcyWaUkVYMPQECdsmtN=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.SEARCHED_FILE_NAME
   elif DSXrTjqnJiLOcyWaUkVYMPQECdsmhF in['vod','movie']:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmtN=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%DSXrTjqnJiLOcyWaUkVYMPQECdsmhF))
   else:
    return[]
   fp=DSXrTjqnJiLOcyWaUkVYMPQECdsmpx(DSXrTjqnJiLOcyWaUkVYMPQECdsmtN,'r',-1,'utf-8')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtR=fp.readlines()
   fp.close()
  except:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtR=[]
  return DSXrTjqnJiLOcyWaUkVYMPQECdsmtR
 def Save_Watched_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhF,DSXrTjqnJiLOcyWaUkVYMPQECdsmwF):
  try:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtG=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%DSXrTjqnJiLOcyWaUkVYMPQECdsmhF))
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtF=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.Load_List_File(DSXrTjqnJiLOcyWaUkVYMPQECdsmhF) 
   fp=DSXrTjqnJiLOcyWaUkVYMPQECdsmpx(DSXrTjqnJiLOcyWaUkVYMPQECdsmtG,'w',-1,'utf-8')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtu=urllib.parse.urlencode(DSXrTjqnJiLOcyWaUkVYMPQECdsmwF)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtu=DSXrTjqnJiLOcyWaUkVYMPQECdsmtu+'\n'
   fp.write(DSXrTjqnJiLOcyWaUkVYMPQECdsmtu)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtl=0
   for DSXrTjqnJiLOcyWaUkVYMPQECdsmtA in DSXrTjqnJiLOcyWaUkVYMPQECdsmtF:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmtx=DSXrTjqnJiLOcyWaUkVYMPQECdsmpv(urllib.parse.parse_qsl(DSXrTjqnJiLOcyWaUkVYMPQECdsmtA))
    DSXrTjqnJiLOcyWaUkVYMPQECdsmto=DSXrTjqnJiLOcyWaUkVYMPQECdsmwF.get('code').strip()
    DSXrTjqnJiLOcyWaUkVYMPQECdsmtH=DSXrTjqnJiLOcyWaUkVYMPQECdsmtx.get('code').strip()
    if DSXrTjqnJiLOcyWaUkVYMPQECdsmhF=='vod' and DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_direct_replay()==DSXrTjqnJiLOcyWaUkVYMPQECdsmpB:
     DSXrTjqnJiLOcyWaUkVYMPQECdsmto=DSXrTjqnJiLOcyWaUkVYMPQECdsmwF.get('videoid').strip()
     DSXrTjqnJiLOcyWaUkVYMPQECdsmtH=DSXrTjqnJiLOcyWaUkVYMPQECdsmtx.get('videoid').strip()if DSXrTjqnJiLOcyWaUkVYMPQECdsmtH!=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf else '-'
    if DSXrTjqnJiLOcyWaUkVYMPQECdsmto!=DSXrTjqnJiLOcyWaUkVYMPQECdsmtH:
     fp.write(DSXrTjqnJiLOcyWaUkVYMPQECdsmtA)
     DSXrTjqnJiLOcyWaUkVYMPQECdsmtl+=1
     if DSXrTjqnJiLOcyWaUkVYMPQECdsmtl>=50:break
   fp.close()
  except:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
 def dp_Watch_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhF =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('stype')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIv=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_direct_replay()
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhF=='-':
   for DSXrTjqnJiLOcyWaUkVYMPQECdsmhx in DSXrTjqnJiLOcyWaUkVYMPQECdsmwz:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIF=DSXrTjqnJiLOcyWaUkVYMPQECdsmhx.get('title')
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':DSXrTjqnJiLOcyWaUkVYMPQECdsmhx.get('mode'),'stype':DSXrTjqnJiLOcyWaUkVYMPQECdsmhx.get('stype')}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel='',img='',infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmpN(DSXrTjqnJiLOcyWaUkVYMPQECdsmwz)>0:xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle)
  else:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBw=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.Load_List_File(DSXrTjqnJiLOcyWaUkVYMPQECdsmhF)
   for DSXrTjqnJiLOcyWaUkVYMPQECdsmBI in DSXrTjqnJiLOcyWaUkVYMPQECdsmBw:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmth=DSXrTjqnJiLOcyWaUkVYMPQECdsmpv(urllib.parse.parse_qsl(DSXrTjqnJiLOcyWaUkVYMPQECdsmBI))
    DSXrTjqnJiLOcyWaUkVYMPQECdsmBh =DSXrTjqnJiLOcyWaUkVYMPQECdsmth.get('code').strip()
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIF =DSXrTjqnJiLOcyWaUkVYMPQECdsmth.get('title').strip()
    DSXrTjqnJiLOcyWaUkVYMPQECdsmho=DSXrTjqnJiLOcyWaUkVYMPQECdsmth.get('img').strip()
    DSXrTjqnJiLOcyWaUkVYMPQECdsmzN =DSXrTjqnJiLOcyWaUkVYMPQECdsmth.get('videoid').strip()
    try:
     DSXrTjqnJiLOcyWaUkVYMPQECdsmho=DSXrTjqnJiLOcyWaUkVYMPQECdsmho.replace('\'','\"')
     DSXrTjqnJiLOcyWaUkVYMPQECdsmho=json.loads(DSXrTjqnJiLOcyWaUkVYMPQECdsmho)
    except:
     DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfp['plot']=DSXrTjqnJiLOcyWaUkVYMPQECdsmIF
    if DSXrTjqnJiLOcyWaUkVYMPQECdsmhF=='vod':
     if DSXrTjqnJiLOcyWaUkVYMPQECdsmIv==DSXrTjqnJiLOcyWaUkVYMPQECdsmpt or DSXrTjqnJiLOcyWaUkVYMPQECdsmzN==DSXrTjqnJiLOcyWaUkVYMPQECdsmpf:
      DSXrTjqnJiLOcyWaUkVYMPQECdsmfp['mediatype']='tvshow'
      DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'EPISODE','programcode':DSXrTjqnJiLOcyWaUkVYMPQECdsmBh,'page':'1'}
      DSXrTjqnJiLOcyWaUkVYMPQECdsmhw=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB
     else:
      DSXrTjqnJiLOcyWaUkVYMPQECdsmfp['mediatype']='episode'
      DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'VOD','mediacode':DSXrTjqnJiLOcyWaUkVYMPQECdsmzN,'stype':'vod','programcode':DSXrTjqnJiLOcyWaUkVYMPQECdsmBh,'title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'thumbnail':DSXrTjqnJiLOcyWaUkVYMPQECdsmho}
      DSXrTjqnJiLOcyWaUkVYMPQECdsmhw=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
    else:
     DSXrTjqnJiLOcyWaUkVYMPQECdsmfp['mediatype']='movie'
     DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'MOVIE','mediacode':DSXrTjqnJiLOcyWaUkVYMPQECdsmBh,'stype':'movie','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'thumbnail':DSXrTjqnJiLOcyWaUkVYMPQECdsmho}
     DSXrTjqnJiLOcyWaUkVYMPQECdsmhw=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
    DSXrTjqnJiLOcyWaUkVYMPQECdsmtz={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':DSXrTjqnJiLOcyWaUkVYMPQECdsmBh,'vType':DSXrTjqnJiLOcyWaUkVYMPQECdsmhF,}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmtB=urllib.parse.urlencode(DSXrTjqnJiLOcyWaUkVYMPQECdsmtz)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=[('선택된 시청이력 ( %s ) 삭제'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmtB))]
    DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel='',img=DSXrTjqnJiLOcyWaUkVYMPQECdsmho,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmhw,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH,ContextMenu=DSXrTjqnJiLOcyWaUkVYMPQECdsmfG)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'plot':'시청목록을 삭제합니다.'}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':DSXrTjqnJiLOcyWaUkVYMPQECdsmhF,}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel='',img=DSXrTjqnJiLOcyWaUkVYMPQECdsmIo,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH,isLink=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB)
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmhF=='movie':xbmcplugin.setContent(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,'movies')
   else:xbmcplugin.setContent(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
 def Save_Searched_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmzG):
  try:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBf=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.SEARCHED_FILE_NAME
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtF=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.Load_List_File('search') 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBz={'skey':DSXrTjqnJiLOcyWaUkVYMPQECdsmzG.strip()}
   fp=DSXrTjqnJiLOcyWaUkVYMPQECdsmpx(DSXrTjqnJiLOcyWaUkVYMPQECdsmBf,'w',-1,'utf-8')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtu=urllib.parse.urlencode(DSXrTjqnJiLOcyWaUkVYMPQECdsmBz)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtu=DSXrTjqnJiLOcyWaUkVYMPQECdsmtu+'\n'
   fp.write(DSXrTjqnJiLOcyWaUkVYMPQECdsmtu)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmtl=0
   for DSXrTjqnJiLOcyWaUkVYMPQECdsmtA in DSXrTjqnJiLOcyWaUkVYMPQECdsmtF:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmtx=DSXrTjqnJiLOcyWaUkVYMPQECdsmpv(urllib.parse.parse_qsl(DSXrTjqnJiLOcyWaUkVYMPQECdsmtA))
    DSXrTjqnJiLOcyWaUkVYMPQECdsmto=DSXrTjqnJiLOcyWaUkVYMPQECdsmBz.get('skey').strip()
    DSXrTjqnJiLOcyWaUkVYMPQECdsmtH=DSXrTjqnJiLOcyWaUkVYMPQECdsmtx.get('skey').strip()
    if DSXrTjqnJiLOcyWaUkVYMPQECdsmto!=DSXrTjqnJiLOcyWaUkVYMPQECdsmtH:
     fp.write(DSXrTjqnJiLOcyWaUkVYMPQECdsmtA)
     DSXrTjqnJiLOcyWaUkVYMPQECdsmtl+=1
     if DSXrTjqnJiLOcyWaUkVYMPQECdsmtl>=50:break
   fp.close()
  except:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
 def play_VIDEO(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmBt =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('mediacode')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhF =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('stype')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmBb =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('pvrmode')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmBp=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_selQuality(DSXrTjqnJiLOcyWaUkVYMPQECdsmhF)
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmBt,DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmBp),DSXrTjqnJiLOcyWaUkVYMPQECdsmhF,DSXrTjqnJiLOcyWaUkVYMPQECdsmBb))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmBv=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.GetBroadURL(DSXrTjqnJiLOcyWaUkVYMPQECdsmBt,DSXrTjqnJiLOcyWaUkVYMPQECdsmBp,DSXrTjqnJiLOcyWaUkVYMPQECdsmhF,DSXrTjqnJiLOcyWaUkVYMPQECdsmBb,optUHD=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_uhd())
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_log('qt, stype, url : %s - %s - %s'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmBp),DSXrTjqnJiLOcyWaUkVYMPQECdsmhF,DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['streaming_url']))
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['streaming_url']=='':
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['error_msg']=='':
    DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_noti(__language__(30908).encode('utf8'))
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_noti(DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['error_msg'].encode('utf8'))
   return
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['qt_stream']=='stream70':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBg={'user-agent':DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.USER_AGENT_ATV}
  else:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBg={'user-agent':DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.USER_AGENT}
  DSXrTjqnJiLOcyWaUkVYMPQECdsmBK=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.makeDefaultCookies() 
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['watermark'] !='':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBg['x-tving-param1']=DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['watermarkKey']
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBg['x-tving-param2']=DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['watermark'] 
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['drm_server_url'] !='':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBg[DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['drm_header_key']]=DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['drm_header_value']
  DSXrTjqnJiLOcyWaUkVYMPQECdsmBN =DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  DSXrTjqnJiLOcyWaUkVYMPQECdsmBF =DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['streaming_url'].find('Policy=')
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmBF!=-1:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBA =DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['streaming_url'].split('?')[0]
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBx=DSXrTjqnJiLOcyWaUkVYMPQECdsmpv(urllib.parse.parse_qsl(urllib.parse.urlsplit(DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['streaming_url']).query))
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBK['CloudFront-Policy'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmBx['Policy'] 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBK['CloudFront-Signature'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmBx['Signature'] 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBK['CloudFront-Key-Pair-Id']=DSXrTjqnJiLOcyWaUkVYMPQECdsmBx['Key-Pair-Id'] 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBe=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.make_stream_header(DSXrTjqnJiLOcyWaUkVYMPQECdsmBg,DSXrTjqnJiLOcyWaUkVYMPQECdsmBK)
   if 'quickvod-mcdn.tving.com' in DSXrTjqnJiLOcyWaUkVYMPQECdsmBA:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmBN=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB
    DSXrTjqnJiLOcyWaUkVYMPQECdsmBR =DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmBG=DSXrTjqnJiLOcyWaUkVYMPQECdsmBR.strftime('%Y-%m-%d-%H:%M:%S')
    if DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmBG.replace('-','').replace(':',''))<DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmBx['end'].replace('-','').replace(':','')):
     DSXrTjqnJiLOcyWaUkVYMPQECdsmBx['end']=DSXrTjqnJiLOcyWaUkVYMPQECdsmBG
     DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_noti(__language__(30915).encode('utf8'))
    DSXrTjqnJiLOcyWaUkVYMPQECdsmBA ='%s?%s'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmBA,urllib.parse.urlencode(DSXrTjqnJiLOcyWaUkVYMPQECdsmBx,doseq=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB))
    DSXrTjqnJiLOcyWaUkVYMPQECdsmBu='{}|{}'.format(DSXrTjqnJiLOcyWaUkVYMPQECdsmBA,DSXrTjqnJiLOcyWaUkVYMPQECdsmBe)
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmBu='{}|{}'.format(DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['streaming_url'],DSXrTjqnJiLOcyWaUkVYMPQECdsmBe)
  else:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBe=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.make_stream_header(DSXrTjqnJiLOcyWaUkVYMPQECdsmBg,DSXrTjqnJiLOcyWaUkVYMPQECdsmBK)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBu='{}|{}'.format(DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['streaming_url'],DSXrTjqnJiLOcyWaUkVYMPQECdsmBe)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_log('if tmp_pos == -1')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIh,DSXrTjqnJiLOcyWaUkVYMPQECdsmIf=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_proxyport()
  DSXrTjqnJiLOcyWaUkVYMPQECdsmIw=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_playback()
  if(DSXrTjqnJiLOcyWaUkVYMPQECdsmIh and DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('mode')in['VOD','MOVIE']and DSXrTjqnJiLOcyWaUkVYMPQECdsmBN==DSXrTjqnJiLOcyWaUkVYMPQECdsmpt and(DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['drm_server_url']!='' or(DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['url_filename'].split('.')[1]=='mpd')or(DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['url_filename'].split('.')[1]!='mpd' and DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.KodiVersion>=21 and DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['qt_stream']=='stream70'))):
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['url_filename'].split('.')[1]=='mpd':
    DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Tving_Parse_mpd(DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['streaming_url'],DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['watermarkKey'],DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['watermark'])
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Tving_Parse_m3u8(DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['streaming_url'])
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_log('xxx '+DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['streaming_url'])
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBl={'addon':'tvingm','playOption':DSXrTjqnJiLOcyWaUkVYMPQECdsmIw,'url_filename':DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['url_filename'],}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBl=json.dumps(DSXrTjqnJiLOcyWaUkVYMPQECdsmBl,separators=(',',':'))
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBl=base64.standard_b64encode(DSXrTjqnJiLOcyWaUkVYMPQECdsmBl.encode()).decode('utf-8')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBu ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(DSXrTjqnJiLOcyWaUkVYMPQECdsmIf,DSXrTjqnJiLOcyWaUkVYMPQECdsmBu,DSXrTjqnJiLOcyWaUkVYMPQECdsmBl)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBg['proxy-mini']=DSXrTjqnJiLOcyWaUkVYMPQECdsmBl 
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_log('surl(2) : {}'.format(DSXrTjqnJiLOcyWaUkVYMPQECdsmBu))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_log('drm     : {}'.format(DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['drm_server_url']))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmBe=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.make_stream_header(DSXrTjqnJiLOcyWaUkVYMPQECdsmBg,DSXrTjqnJiLOcyWaUkVYMPQECdsmBK)
  DSXrTjqnJiLOcyWaUkVYMPQECdsmBo=xbmcgui.ListItem(path=DSXrTjqnJiLOcyWaUkVYMPQECdsmBu)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['drm_server_url']!='':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBH=DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['drm_server_url']
   DSXrTjqnJiLOcyWaUkVYMPQECdsmbw ='https://license-global.pallycon.com/ri/licenseManager.do' 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmbI ='mpd'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmbh ='com.widevine.alpha'
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   DSXrTjqnJiLOcyWaUkVYMPQECdsmbz={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.USER_AGENT,DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['drm_header_key']:DSXrTjqnJiLOcyWaUkVYMPQECdsmBv['drm_header_value'],}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmbt=DSXrTjqnJiLOcyWaUkVYMPQECdsmbw+'|'+urllib.parse.urlencode(DSXrTjqnJiLOcyWaUkVYMPQECdsmbz)+'|R{SSM}|'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream','inputstream.adaptive')
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.KodiVersion<=20:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream.adaptive.manifest_type',DSXrTjqnJiLOcyWaUkVYMPQECdsmbI)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream.adaptive.license_type',DSXrTjqnJiLOcyWaUkVYMPQECdsmbh)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream.adaptive.license_key',DSXrTjqnJiLOcyWaUkVYMPQECdsmbt)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream.adaptive.stream_headers',DSXrTjqnJiLOcyWaUkVYMPQECdsmBe)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream.adaptive.manifest_headers',DSXrTjqnJiLOcyWaUkVYMPQECdsmBe)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('mode')in['VOD','MOVIE']:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setContentLookup(DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setMimeType('application/x-mpegURL')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream','inputstream.adaptive')
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.KodiVersion<=20:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream.adaptive.manifest_type','hls')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream.adaptive.stream_headers',DSXrTjqnJiLOcyWaUkVYMPQECdsmBe)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream.adaptive.manifest_headers',DSXrTjqnJiLOcyWaUkVYMPQECdsmBe)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmBN==DSXrTjqnJiLOcyWaUkVYMPQECdsmpB:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setContentLookup(DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setMimeType('application/x-mpegURL')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream','inputstream.ffmpegdirect')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('ResumeTime','0')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmBo.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,DSXrTjqnJiLOcyWaUkVYMPQECdsmBo)
  try:
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('mode')in['VOD','MOVIE']and DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('title'):
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'code':DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('programcode')if DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('mode')=='VOD' else DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('mediacode'),'img':DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('thumbnail'),'title':DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('title'),'videoid':DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('mediacode')}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.Save_Watched_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('stype'),DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  except:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
 def logout(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwx=xbmcgui.Dialog()
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhv=DSXrTjqnJiLOcyWaUkVYMPQECdsmwx.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmhv==DSXrTjqnJiLOcyWaUkVYMPQECdsmpt:sys.exit()
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Init_TV_Total()
  if os.path.isfile(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_COOKIE_FILENAME):os.remove(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_COOKIE_FILENAME)
  if os.path.isfile(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_TOKEN_FILENAME): os.remove(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_TOKEN_FILENAME)
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmbB =DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Get_Now_Datetime()
  DSXrTjqnJiLOcyWaUkVYMPQECdsmbp=DSXrTjqnJiLOcyWaUkVYMPQECdsmbB+datetime.timedelta(days=30) 
  (DSXrTjqnJiLOcyWaUkVYMPQECdsmht,DSXrTjqnJiLOcyWaUkVYMPQECdsmhB,DSXrTjqnJiLOcyWaUkVYMPQECdsmhb,DSXrTjqnJiLOcyWaUkVYMPQECdsmhp)=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_account()
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Save_session_acount(DSXrTjqnJiLOcyWaUkVYMPQECdsmht,DSXrTjqnJiLOcyWaUkVYMPQECdsmhB,DSXrTjqnJiLOcyWaUkVYMPQECdsmhb,DSXrTjqnJiLOcyWaUkVYMPQECdsmhp)
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV['account']['token_limit']=DSXrTjqnJiLOcyWaUkVYMPQECdsmbp.strftime('%Y%m%d')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.JsonFile_Save(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_COOKIE_FILENAME,DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV)
 def cookiefile_check(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.JsonFile_Load(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_COOKIE_FILENAME)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV=={}:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Init_TV_Total()
   return DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  (DSXrTjqnJiLOcyWaUkVYMPQECdsmbv,DSXrTjqnJiLOcyWaUkVYMPQECdsmbg,DSXrTjqnJiLOcyWaUkVYMPQECdsmbK,DSXrTjqnJiLOcyWaUkVYMPQECdsmbN)=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_account()
  (DSXrTjqnJiLOcyWaUkVYMPQECdsmbF,DSXrTjqnJiLOcyWaUkVYMPQECdsmbA,DSXrTjqnJiLOcyWaUkVYMPQECdsmbx,DSXrTjqnJiLOcyWaUkVYMPQECdsmbe)=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Load_session_acount()
  if(DSXrTjqnJiLOcyWaUkVYMPQECdsmbv!=DSXrTjqnJiLOcyWaUkVYMPQECdsmbF or DSXrTjqnJiLOcyWaUkVYMPQECdsmbg!=DSXrTjqnJiLOcyWaUkVYMPQECdsmbA or DSXrTjqnJiLOcyWaUkVYMPQECdsmbK!=DSXrTjqnJiLOcyWaUkVYMPQECdsmbx or DSXrTjqnJiLOcyWaUkVYMPQECdsmbN!=DSXrTjqnJiLOcyWaUkVYMPQECdsmbe)and DSXrTjqnJiLOcyWaUkVYMPQECdsmbF!='xxxxx':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Init_TV_Total()
   return DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV['account']['token_limit']):
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Init_TV_Total()
   return DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  return DSXrTjqnJiLOcyWaUkVYMPQECdsmpB
 def tokenfile_check(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_TOKEN=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.JsonFile_Load(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_TOKEN_FILENAME)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_TOKEN=={}:
   return DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_TOKEN['token_date']):
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.TV_TOKEN={}
   return DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
  return DSXrTjqnJiLOcyWaUkVYMPQECdsmpB
 def get_reToken(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.tokenfile_check()==DSXrTjqnJiLOcyWaUkVYMPQECdsmpt:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Get_AccessToken()
 def dp_Global_Search(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('mode')
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='TOTAL_SEARCH':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmbR='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmbR='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(DSXrTjqnJiLOcyWaUkVYMPQECdsmbR)
 def dp_Bookmark_Menu(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmbR='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(DSXrTjqnJiLOcyWaUkVYMPQECdsmbR)
 def dp_EuroLive_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhG=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.GetEuroChannelList()
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmhl in DSXrTjqnJiLOcyWaUkVYMPQECdsmhG:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfA =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('channel')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfv =DSXrTjqnJiLOcyWaUkVYMPQECdsmhl.get('subtitle')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'mediatype':'episode','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'plot':'%s\n%s'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,DSXrTjqnJiLOcyWaUkVYMPQECdsmfv)}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'LIVE','mediacode':DSXrTjqnJiLOcyWaUkVYMPQECdsmfA,'stype':'onair',}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmfv,img='',infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmpN(DSXrTjqnJiLOcyWaUkVYMPQECdsmhG)>0:xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
 def dp_Apple_Group(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmbG=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Get_AppleGroup_List()
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmbu in DSXrTjqnJiLOcyWaUkVYMPQECdsmbG:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmbl =DSXrTjqnJiLOcyWaUkVYMPQECdsmbu.get('bandName')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmbo =DSXrTjqnJiLOcyWaUkVYMPQECdsmbu.get('bandKey')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'mediatype':'tvshow','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmbl,'plot':'%s'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmbo),}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'BAND_VODLIST','bandKey':DSXrTjqnJiLOcyWaUkVYMPQECdsmbo,'page':'1','nextApiUrl':'-',}
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmbl,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,img='',infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmpN(DSXrTjqnJiLOcyWaUkVYMPQECdsmbG)>0:xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
 def dp_Band_VodList(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg,DSXrTjqnJiLOcyWaUkVYMPQECdsmhe):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmbo =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('bandKey') 
  DSXrTjqnJiLOcyWaUkVYMPQECdsmbH =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('bandGroup') 
  DSXrTjqnJiLOcyWaUkVYMPQECdsmpw =DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('nextApiUrl')
  DSXrTjqnJiLOcyWaUkVYMPQECdsmpI =''
  DSXrTjqnJiLOcyWaUkVYMPQECdsmhR =DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(DSXrTjqnJiLOcyWaUkVYMPQECdsmhe.get('page'))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_log('bandKey    : {}'.format(DSXrTjqnJiLOcyWaUkVYMPQECdsmbo))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_log('bandGroup  : {}'.format(DSXrTjqnJiLOcyWaUkVYMPQECdsmbH))
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_log('nextApiUrl : {}'.format(DSXrTjqnJiLOcyWaUkVYMPQECdsmpw))
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmbH=='TVING_APPLE_HOUR':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfN,DSXrTjqnJiLOcyWaUkVYMPQECdsmpw=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Get_Apple_NowList()
  else:
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmbH not in['',DSXrTjqnJiLOcyWaUkVYMPQECdsmpf]:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmbo=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Get_bandCode_GroupCode(DSXrTjqnJiLOcyWaUkVYMPQECdsmbH)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.addon_log('new bandKey    : {}'.format(DSXrTjqnJiLOcyWaUkVYMPQECdsmbo))
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfN,DSXrTjqnJiLOcyWaUkVYMPQECdsmpw=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.Get_Band_VodList(DSXrTjqnJiLOcyWaUkVYMPQECdsmbo,DSXrTjqnJiLOcyWaUkVYMPQECdsmpw)
  for DSXrTjqnJiLOcyWaUkVYMPQECdsmfF in DSXrTjqnJiLOcyWaUkVYMPQECdsmfN:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('title')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmho =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('thumbnail')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmzN =DSXrTjqnJiLOcyWaUkVYMPQECdsmfF.get('program')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfp={'mediatype':'tvshow' if not DSXrTjqnJiLOcyWaUkVYMPQECdsmzN.startswith('M')else 'movie','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'plot':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF+'\n'+'tvshow' if not DSXrTjqnJiLOcyWaUkVYMPQECdsmzN.startswith('M')else 'movie',}
   if not DSXrTjqnJiLOcyWaUkVYMPQECdsmzN.startswith('M'):
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'EPISODE','programcode':DSXrTjqnJiLOcyWaUkVYMPQECdsmzN,'page':'1',}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmhw=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmIH={'mode':'MOVIE','mediacode':DSXrTjqnJiLOcyWaUkVYMPQECdsmzN,'stype':'movie','title':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'thumbnail':DSXrTjqnJiLOcyWaUkVYMPQECdsmho,}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmhw=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt
   if DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_settings_makebookmark():
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfx={'videoid':DSXrTjqnJiLOcyWaUkVYMPQECdsmzN,'vidtype':'tvshow','vtitle':DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,'vsubtitle':DSXrTjqnJiLOcyWaUkVYMPQECdsmpI,}
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfe=json.dumps(DSXrTjqnJiLOcyWaUkVYMPQECdsmfx)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfe=urllib.parse.quote(DSXrTjqnJiLOcyWaUkVYMPQECdsmfe)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfR='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(DSXrTjqnJiLOcyWaUkVYMPQECdsmfe)
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=[('(통합) 찜 영상에 추가',DSXrTjqnJiLOcyWaUkVYMPQECdsmfR)]
   else:
    DSXrTjqnJiLOcyWaUkVYMPQECdsmfG=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmpI,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmho,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmfp,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmhw,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH,ContextMenu=DSXrTjqnJiLOcyWaUkVYMPQECdsmfG)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmpw not in[DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,'','-']:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['mode'] ='BAND_VODLIST' 
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['bandKey'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmbo
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['nextApiUrl']=DSXrTjqnJiLOcyWaUkVYMPQECdsmpw
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIH['page'] =DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIF='[B]%s >>[/B]'%'다음 페이지'
   DSXrTjqnJiLOcyWaUkVYMPQECdsmfv=DSXrTjqnJiLOcyWaUkVYMPQECdsmpF(DSXrTjqnJiLOcyWaUkVYMPQECdsmhR+1)
   DSXrTjqnJiLOcyWaUkVYMPQECdsmIo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.add_dir(DSXrTjqnJiLOcyWaUkVYMPQECdsmIF,sublabel=DSXrTjqnJiLOcyWaUkVYMPQECdsmfv,img=DSXrTjqnJiLOcyWaUkVYMPQECdsmIo,infoLabels=DSXrTjqnJiLOcyWaUkVYMPQECdsmpf,isFolder=DSXrTjqnJiLOcyWaUkVYMPQECdsmpB,params=DSXrTjqnJiLOcyWaUkVYMPQECdsmIH)
  xbmcplugin.setContent(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg._addon_handle,cacheToDisc=DSXrTjqnJiLOcyWaUkVYMPQECdsmpt)
 def tving_main(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg):
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.TvingObj.KodiVersion=DSXrTjqnJiLOcyWaUkVYMPQECdsmpz(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params.get('mode',DSXrTjqnJiLOcyWaUkVYMPQECdsmpf)
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='LOGOUT':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.logout()
   return
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.login_main()
  DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.get_reToken()
  if DSXrTjqnJiLOcyWaUkVYMPQECdsmzu is DSXrTjqnJiLOcyWaUkVYMPQECdsmpf:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Main_List()
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Title_Group(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu in['GLOBAL_GROUP']:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_SubTitle_Group(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='CHANNEL':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_LiveChannel_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu in['LIVE','VOD','MOVIE']:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.play_VIDEO(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='PROGRAM':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Program_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='4K_PROGRAM':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_4K_Program_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='ORI_PROGRAM':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Ori_Program_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='EPISODE':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Episode_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='MOVIE_SUB':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Movie_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='4K_MOVIE':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_4K_Movie_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='SEARCH_GROUP':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Search_Group(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu in['SEARCH','LOCAL_SEARCH']:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Search_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='WATCH':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Watch_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_History_Remove(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='ORDER_BY':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_setEpOrderby(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='SET_BOOKMARK':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Set_Bookmark(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu in['TOTAL_SEARCH','TOTAL_HISTORY']:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Global_Search(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='SEARCH_HISTORY':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Search_History(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='MENU_BOOKMARK':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Bookmark_Menu(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='EURO_GROUP':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_EuroLive_List(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='APPLE_GROUP':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Apple_Group(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  elif DSXrTjqnJiLOcyWaUkVYMPQECdsmzu=='BAND_VODLIST':
   DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.dp_Band_VodList(DSXrTjqnJiLOcyWaUkVYMPQECdsmwg.main_params)
  else:
   DSXrTjqnJiLOcyWaUkVYMPQECdsmpf
# Created by pyminifier (https://github.com/liftoff/pyminifier)
