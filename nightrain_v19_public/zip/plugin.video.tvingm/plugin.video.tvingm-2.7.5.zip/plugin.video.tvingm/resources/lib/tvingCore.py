__author__="NightRain"
nYPfjeUXxLJrqFmMShEoQBOwCvTauN=print
nYPfjeUXxLJrqFmMShEoQBOwCvTaug=ImportError
nYPfjeUXxLJrqFmMShEoQBOwCvTauG=object
nYPfjeUXxLJrqFmMShEoQBOwCvTaud=None
nYPfjeUXxLJrqFmMShEoQBOwCvTaup=False
nYPfjeUXxLJrqFmMShEoQBOwCvTaus=str
nYPfjeUXxLJrqFmMShEoQBOwCvTauK=open
nYPfjeUXxLJrqFmMShEoQBOwCvTauH=True
nYPfjeUXxLJrqFmMShEoQBOwCvTauy=len
nYPfjeUXxLJrqFmMShEoQBOwCvTaub=int
nYPfjeUXxLJrqFmMShEoQBOwCvTauW=range
nYPfjeUXxLJrqFmMShEoQBOwCvTauz=bytes
nYPfjeUXxLJrqFmMShEoQBOwCvTauV=Exception
nYPfjeUXxLJrqFmMShEoQBOwCvTaRI=dict
nYPfjeUXxLJrqFmMShEoQBOwCvTaRc=list
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 nYPfjeUXxLJrqFmMShEoQBOwCvTauN('Cryptodome')
except nYPfjeUXxLJrqFmMShEoQBOwCvTaug:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 nYPfjeUXxLJrqFmMShEoQBOwCvTauN('Crypto')
nYPfjeUXxLJrqFmMShEoQBOwCvTaIk={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
nYPfjeUXxLJrqFmMShEoQBOwCvTaIt ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
nYPfjeUXxLJrqFmMShEoQBOwCvTaIi =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
nYPfjeUXxLJrqFmMShEoQBOwCvTaID=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class nYPfjeUXxLJrqFmMShEoQBOwCvTaIc(nYPfjeUXxLJrqFmMShEoQBOwCvTauG):
 def __init__(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.NETWORKCODE ='CSND0900'
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.OSCODE ='CSOD0900' 
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TELECODE ='CSCD0900'
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SCREENCODE ='CSSD0100'
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.APIKEY_ATV ='b6ac9e6384d93d6e533b144b3ef22c42' 
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SCREENCODE_ATV ='CSSD1300' 
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.LIVE_LIMIT =20 
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.VOD_LIMIT =24 
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.EPISODE_LIMIT =30 
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SEARCH_LIMIT =30 
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.MOVIE_LIMIT =24 
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN ='https://api.tving.com'
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN ='https://image.tving.com'
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SEARCH_DOMAIN ='https://search-api.tving.com'
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.LOGIN_DOMAIN ='https://user.tving.com'
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.URL_DOMAIN ='https://www.tving.com'
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.MOVIE_LITE =['2610061','2610161','261062']
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36'
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.MODEL ='windows_chrome_135.0.0.0' 
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.USER_AGENT_ATV ='Mozilla/5.0 (Linux; Android 9; A95X_F3_Air Build/A95X_F3_AIR_M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36'
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.DEFAULT_HEADER ={'user-agent':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.USER_AGENT}
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_COOKIE_FILENAME =''
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN_FILENAME =''
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SEARCHED_FILE_NAME =''
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_SESSION_COOKIES1=''
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_SESSION_COOKIES2=''
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_STREAM_FILENAME =''
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_SESSION_TEXT1 =''
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_SESSION_TEXT2 =''
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.KodiVersion=20
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV ={}
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN ={}
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Init_TV_Total()
 def Init_TV_Total(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV={'account':{},'cookies':{},}
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN={}
 def callRequestCookies(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,jobtype,nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,json=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,redirects=nYPfjeUXxLJrqFmMShEoQBOwCvTaup):
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIl=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.DEFAULT_HEADER
  if headers:nYPfjeUXxLJrqFmMShEoQBOwCvTaIl.update(headers)
  if jobtype=='Get':
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIu=requests.get(nYPfjeUXxLJrqFmMShEoQBOwCvTacb,params=params,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaIl,cookies=cookies,allow_redirects=redirects)
  else:
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIu=requests.post(nYPfjeUXxLJrqFmMShEoQBOwCvTacb,data=payload,json=json,params=params,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaIl,cookies=cookies,allow_redirects=redirects)
  nYPfjeUXxLJrqFmMShEoQBOwCvTauN(nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIu.status_code)+' - '+nYPfjeUXxLJrqFmMShEoQBOwCvTaIu.url)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTaIu
 def JsonFile_Save(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,filename,nYPfjeUXxLJrqFmMShEoQBOwCvTaIR):
  if filename=='':return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  try:
   fp=nYPfjeUXxLJrqFmMShEoQBOwCvTauK(filename,'w',-1,'utf-8')
   json.dump(nYPfjeUXxLJrqFmMShEoQBOwCvTaIR,fp,indent=4,ensure_ascii=nYPfjeUXxLJrqFmMShEoQBOwCvTaup)
   fp.close()
  except:
   return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  return nYPfjeUXxLJrqFmMShEoQBOwCvTauH
 def JsonFile_Load(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,filename):
  if filename=='':return{}
  try:
   fp=nYPfjeUXxLJrqFmMShEoQBOwCvTauK(filename,'r',-1,'utf-8')
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIg=json.load(fp)
   fp.close()
  except:
   return{}
  return nYPfjeUXxLJrqFmMShEoQBOwCvTaIg
 def TextFile_Save(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,filename,resText):
  if filename=='':return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  try:
   fp=nYPfjeUXxLJrqFmMShEoQBOwCvTauK(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  return nYPfjeUXxLJrqFmMShEoQBOwCvTauH
 def Save_session_acount(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,nYPfjeUXxLJrqFmMShEoQBOwCvTaIG,nYPfjeUXxLJrqFmMShEoQBOwCvTaId,nYPfjeUXxLJrqFmMShEoQBOwCvTaIp,nYPfjeUXxLJrqFmMShEoQBOwCvTaIs):
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['account']['tvid'] =base64.standard_b64encode(nYPfjeUXxLJrqFmMShEoQBOwCvTaIG.encode()).decode('utf-8')
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['account']['tvpw'] =base64.standard_b64encode(nYPfjeUXxLJrqFmMShEoQBOwCvTaId.encode()).decode('utf-8')
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['account']['tvtype']=nYPfjeUXxLJrqFmMShEoQBOwCvTaIp 
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['account']['tvpf'] =nYPfjeUXxLJrqFmMShEoQBOwCvTaIs 
 def Load_session_acount(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIG =base64.standard_b64decode(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['account']['tvid']).decode('utf-8')
   nYPfjeUXxLJrqFmMShEoQBOwCvTaId =base64.standard_b64decode(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['account']['tvpw']).decode('utf-8')
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIp=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['account']['tvtype']
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIs =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return nYPfjeUXxLJrqFmMShEoQBOwCvTaIG,nYPfjeUXxLJrqFmMShEoQBOwCvTaId,nYPfjeUXxLJrqFmMShEoQBOwCvTaIp,nYPfjeUXxLJrqFmMShEoQBOwCvTaIs
 def make_stream_header(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,nYPfjeUXxLJrqFmMShEoQBOwCvTaIW,nYPfjeUXxLJrqFmMShEoQBOwCvTaIV):
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIK=''
  if nYPfjeUXxLJrqFmMShEoQBOwCvTaIV not in[{},nYPfjeUXxLJrqFmMShEoQBOwCvTaud,'']:
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIH=nYPfjeUXxLJrqFmMShEoQBOwCvTauy(nYPfjeUXxLJrqFmMShEoQBOwCvTaIV)
   for nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaIb in nYPfjeUXxLJrqFmMShEoQBOwCvTaIV.items():
    nYPfjeUXxLJrqFmMShEoQBOwCvTaIK+='{}={}'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaIb)
    nYPfjeUXxLJrqFmMShEoQBOwCvTaIH+=-1
    if nYPfjeUXxLJrqFmMShEoQBOwCvTaIH>0:nYPfjeUXxLJrqFmMShEoQBOwCvTaIK+='; '
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIW['cookie']=nYPfjeUXxLJrqFmMShEoQBOwCvTaIK
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIz=''
  i=0
  for nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaIb in nYPfjeUXxLJrqFmMShEoQBOwCvTaIW.items():
   i=i+1
   if i>1:nYPfjeUXxLJrqFmMShEoQBOwCvTaIz+='&'
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIz+='{}={}'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,urllib.parse.quote(nYPfjeUXxLJrqFmMShEoQBOwCvTaIb))
  return nYPfjeUXxLJrqFmMShEoQBOwCvTaIz
 def makeDefaultCookies(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIV={}
  for nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaIb in nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies'].items():
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIV[nYPfjeUXxLJrqFmMShEoQBOwCvTaIy]=nYPfjeUXxLJrqFmMShEoQBOwCvTaIb
  return nYPfjeUXxLJrqFmMShEoQBOwCvTaIV
 def getDeviceStr(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  nYPfjeUXxLJrqFmMShEoQBOwCvTacI=[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTacI.append('Windows') 
  nYPfjeUXxLJrqFmMShEoQBOwCvTacI.append('Chrome') 
  nYPfjeUXxLJrqFmMShEoQBOwCvTacI.append('ko-KR') 
  nYPfjeUXxLJrqFmMShEoQBOwCvTacI.append('undefined') 
  nYPfjeUXxLJrqFmMShEoQBOwCvTacI.append('24') 
  nYPfjeUXxLJrqFmMShEoQBOwCvTacI.append(u'한국 표준시')
  nYPfjeUXxLJrqFmMShEoQBOwCvTacI.append('undefined') 
  nYPfjeUXxLJrqFmMShEoQBOwCvTacI.append('undefined') 
  nYPfjeUXxLJrqFmMShEoQBOwCvTacI.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  nYPfjeUXxLJrqFmMShEoQBOwCvTack=''
  for nYPfjeUXxLJrqFmMShEoQBOwCvTact in nYPfjeUXxLJrqFmMShEoQBOwCvTacI:
   nYPfjeUXxLJrqFmMShEoQBOwCvTack+=nYPfjeUXxLJrqFmMShEoQBOwCvTact+'|'
  return nYPfjeUXxLJrqFmMShEoQBOwCvTack
 def GetDefaultParams(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,uhd=nYPfjeUXxLJrqFmMShEoQBOwCvTaup):
  if uhd==nYPfjeUXxLJrqFmMShEoQBOwCvTaup:
   nYPfjeUXxLJrqFmMShEoQBOwCvTaci={'apiKey':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.APIKEY,'networkCode':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.NETWORKCODE,'osCode':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.OSCODE,'teleCode':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TELECODE,'screenCode':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SCREENCODE,}
  else:
   nYPfjeUXxLJrqFmMShEoQBOwCvTaci={'apiKey':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.APIKEY_ATV,'networkCode':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.NETWORKCODE,'osCode':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.OSCODE,'teleCode':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TELECODE,'screenCode':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SCREENCODE_ATV,}
  return nYPfjeUXxLJrqFmMShEoQBOwCvTaci
 def GetNoCache(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,timetype=1):
  if timetype==1:
   return nYPfjeUXxLJrqFmMShEoQBOwCvTaub(time.time())
  else:
   return nYPfjeUXxLJrqFmMShEoQBOwCvTaub(time.time()*1000)
 def GetUniqueid(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,hValue=nYPfjeUXxLJrqFmMShEoQBOwCvTaud):
  if hValue:
   import hashlib
   nYPfjeUXxLJrqFmMShEoQBOwCvTacD=hashlib.sha1()
   nYPfjeUXxLJrqFmMShEoQBOwCvTacD.update(hValue.encode())
   nYPfjeUXxLJrqFmMShEoQBOwCvTacA=nYPfjeUXxLJrqFmMShEoQBOwCvTacD.hexdigest()[:8]
  else:
   nYPfjeUXxLJrqFmMShEoQBOwCvTacl=[0 for i in nYPfjeUXxLJrqFmMShEoQBOwCvTauW(256)]
   for i in nYPfjeUXxLJrqFmMShEoQBOwCvTauW(256):
    nYPfjeUXxLJrqFmMShEoQBOwCvTacl[i]='%02x'%(i)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacu=nYPfjeUXxLJrqFmMShEoQBOwCvTaub(4294967295*random.random())|0
   nYPfjeUXxLJrqFmMShEoQBOwCvTacA=nYPfjeUXxLJrqFmMShEoQBOwCvTacl[255&nYPfjeUXxLJrqFmMShEoQBOwCvTacu]+nYPfjeUXxLJrqFmMShEoQBOwCvTacl[nYPfjeUXxLJrqFmMShEoQBOwCvTacu>>8&255]+nYPfjeUXxLJrqFmMShEoQBOwCvTacl[nYPfjeUXxLJrqFmMShEoQBOwCvTacu>>16&255]+nYPfjeUXxLJrqFmMShEoQBOwCvTacl[nYPfjeUXxLJrqFmMShEoQBOwCvTacu>>24&255]
  return nYPfjeUXxLJrqFmMShEoQBOwCvTacA
 def Web_DecryptKey(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  nYPfjeUXxLJrqFmMShEoQBOwCvTacR=nYPfjeUXxLJrqFmMShEoQBOwCvTauz('kss2lym0kdw1lks3','utf-8')
  nYPfjeUXxLJrqFmMShEoQBOwCvTacN=nYPfjeUXxLJrqFmMShEoQBOwCvTauz('6yhlJ4WF9ZIj6I8n','utf-8')
  return nYPfjeUXxLJrqFmMShEoQBOwCvTacR,nYPfjeUXxLJrqFmMShEoQBOwCvTacN
 def Web_EncryptCiphertext(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,nYPfjeUXxLJrqFmMShEoQBOwCvTacs):
  nYPfjeUXxLJrqFmMShEoQBOwCvTacg,nYPfjeUXxLJrqFmMShEoQBOwCvTacG=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Web_DecryptKey()
  nYPfjeUXxLJrqFmMShEoQBOwCvTacd=AES.new(nYPfjeUXxLJrqFmMShEoQBOwCvTacg,AES.MODE_CBC,nYPfjeUXxLJrqFmMShEoQBOwCvTacG,)
  nYPfjeUXxLJrqFmMShEoQBOwCvTacp=nYPfjeUXxLJrqFmMShEoQBOwCvTacd.encrypt(Padding.pad(nYPfjeUXxLJrqFmMShEoQBOwCvTacs.encode('utf-8'),16))
  return base64.standard_b64encode(nYPfjeUXxLJrqFmMShEoQBOwCvTacp).decode('utf-8')
 def Web_DecryptPlaintext(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,nYPfjeUXxLJrqFmMShEoQBOwCvTacp):
  nYPfjeUXxLJrqFmMShEoQBOwCvTacg,nYPfjeUXxLJrqFmMShEoQBOwCvTacG=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Web_DecryptKey()
  nYPfjeUXxLJrqFmMShEoQBOwCvTacd=AES.new(nYPfjeUXxLJrqFmMShEoQBOwCvTacg,AES.MODE_CBC,nYPfjeUXxLJrqFmMShEoQBOwCvTacG,)
  nYPfjeUXxLJrqFmMShEoQBOwCvTacs=Padding.unpad(nYPfjeUXxLJrqFmMShEoQBOwCvTacd.decrypt(base64.standard_b64decode(nYPfjeUXxLJrqFmMShEoQBOwCvTacp)),16)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTacs.decode('utf-8')
 def WebCookies_Load(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,wc_file):
  try:
   fp=nYPfjeUXxLJrqFmMShEoQBOwCvTauK(wc_file,'r',-1,'utf-8')
   nYPfjeUXxLJrqFmMShEoQBOwCvTacK=fp.read()
   fp.close()
   nYPfjeUXxLJrqFmMShEoQBOwCvTacH=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Web_DecryptPlaintext(nYPfjeUXxLJrqFmMShEoQBOwCvTacK)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacH)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacy =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDeviceList()
   if nYPfjeUXxLJrqFmMShEoQBOwCvTacy not in['','-']:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies']['tving_uuid']=nYPfjeUXxLJrqFmMShEoQBOwCvTacy+'-'+nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetUniqueid(nYPfjeUXxLJrqFmMShEoQBOwCvTacy)
  except:
   return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  return nYPfjeUXxLJrqFmMShEoQBOwCvTauH
 def GetCredential2(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,user_id,user_pw,login_type,user_pf):
  try:
   if base64.standard_b64encode(user_id.encode()).decode('utf-8')in['a3ltOTUxMDg4','a3ltMTA4OA==']:
    nYPfjeUXxLJrqFmMShEoQBOwCvTacb='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx' 
   else:
    nYPfjeUXxLJrqFmMShEoQBOwCvTacb='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx' 
   nYPfjeUXxLJrqFmMShEoQBOwCvTacW={'addon':'tvingm','method':'LOGIN','data':{'type':login_type,'id':user_id,'pw':user_pw,'pf':user_pf,}}
   nYPfjeUXxLJrqFmMShEoQBOwCvTacW=json.dumps(nYPfjeUXxLJrqFmMShEoQBOwCvTacW,separators=(',',':'))
   nYPfjeUXxLJrqFmMShEoQBOwCvTacW=base64.standard_b64encode(nYPfjeUXxLJrqFmMShEoQBOwCvTacW.encode()).decode('utf-8')
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIW={'proxy-mini':nYPfjeUXxLJrqFmMShEoQBOwCvTacW}
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=requests.get(base64.standard_b64decode(nYPfjeUXxLJrqFmMShEoQBOwCvTacb).decode('utf-8'),headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaIW)
   if nYPfjeUXxLJrqFmMShEoQBOwCvTacz.status_code!=200:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Init_TV_Total()
    return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
   nYPfjeUXxLJrqFmMShEoQBOwCvTacV=base64.standard_b64decode(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text).decode('utf-8')
   nYPfjeUXxLJrqFmMShEoQBOwCvTacV=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacV)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies']=nYPfjeUXxLJrqFmMShEoQBOwCvTacV
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Init_TV_Total()
   return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  return nYPfjeUXxLJrqFmMShEoQBOwCvTauH
 def GetCredential(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,user_id,user_pw,login_type,user_pf):
  from curl_cffi import requests
  nYPfjeUXxLJrqFmMShEoQBOwCvTakI='chrome' 
  nYPfjeUXxLJrqFmMShEoQBOwCvTakc=requests.Session()
  try:
   if login_type=='0':
    nYPfjeUXxLJrqFmMShEoQBOwCvTakt='https://user.tving.com/pc/user/otherLogin.tving?loginType=10&from=pc&csite=&isAuto=false&rtUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   else:
    nYPfjeUXxLJrqFmMShEoQBOwCvTakt='https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIW={'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language':'ko-KR,ko;q=0.9','cache-control':'no-cache','pragma':'no-cache','priority':'u=0, i','referer':'https://www.tving.com/',}
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTakc.get(nYPfjeUXxLJrqFmMShEoQBOwCvTakt,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaIW,impersonate=nYPfjeUXxLJrqFmMShEoQBOwCvTakI)
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN('{} - {}'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.status_code,nYPfjeUXxLJrqFmMShEoQBOwCvTacz.url))
   for nYPfjeUXxLJrqFmMShEoQBOwCvTaki in nYPfjeUXxLJrqFmMShEoQBOwCvTacz.cookies.jar:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies'][nYPfjeUXxLJrqFmMShEoQBOwCvTaki.name]=nYPfjeUXxLJrqFmMShEoQBOwCvTaki.value
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Init_TV_Total()
   return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakD=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   nYPfjeUXxLJrqFmMShEoQBOwCvTakA={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':nYPfjeUXxLJrqFmMShEoQBOwCvTaup,'cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIW['referer']=nYPfjeUXxLJrqFmMShEoQBOwCvTakt
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTakc.post(url=nYPfjeUXxLJrqFmMShEoQBOwCvTakD,data=nYPfjeUXxLJrqFmMShEoQBOwCvTakA,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaIW,impersonate=nYPfjeUXxLJrqFmMShEoQBOwCvTakI)
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN('{} - {}'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.status_code,nYPfjeUXxLJrqFmMShEoQBOwCvTacz.url))
   for nYPfjeUXxLJrqFmMShEoQBOwCvTaki in nYPfjeUXxLJrqFmMShEoQBOwCvTacz.cookies.jar:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies'][nYPfjeUXxLJrqFmMShEoQBOwCvTaki.name]=nYPfjeUXxLJrqFmMShEoQBOwCvTaki.value
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Init_TV_Total()
   return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  nYPfjeUXxLJrqFmMShEoQBOwCvTakl=[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTaku =''
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIW['referer']=nYPfjeUXxLJrqFmMShEoQBOwCvTakD
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTakc.get(url=nYPfjeUXxLJrqFmMShEoQBOwCvTakR,data=nYPfjeUXxLJrqFmMShEoQBOwCvTakA,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaIW,impersonate=nYPfjeUXxLJrqFmMShEoQBOwCvTakI)
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN('{} - {}'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.status_code,nYPfjeUXxLJrqFmMShEoQBOwCvTacz.url))
   for nYPfjeUXxLJrqFmMShEoQBOwCvTaki in nYPfjeUXxLJrqFmMShEoQBOwCvTacz.cookies.jar:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies'][nYPfjeUXxLJrqFmMShEoQBOwCvTaki.name]=nYPfjeUXxLJrqFmMShEoQBOwCvTaki.value
   nYPfjeUXxLJrqFmMShEoQBOwCvTakl =re.findall('data-profile-no="\d+"',nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   for i in nYPfjeUXxLJrqFmMShEoQBOwCvTauW(nYPfjeUXxLJrqFmMShEoQBOwCvTauy(nYPfjeUXxLJrqFmMShEoQBOwCvTakl)):
    nYPfjeUXxLJrqFmMShEoQBOwCvTakN =nYPfjeUXxLJrqFmMShEoQBOwCvTakl[i].replace('data-profile-no=','').replace('"','')
    nYPfjeUXxLJrqFmMShEoQBOwCvTakl[i]=nYPfjeUXxLJrqFmMShEoQBOwCvTakN
   nYPfjeUXxLJrqFmMShEoQBOwCvTaku=nYPfjeUXxLJrqFmMShEoQBOwCvTakl[user_pf]
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Init_TV_Total()
   return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakg ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIW['referer']=nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTakA={'profileNo':nYPfjeUXxLJrqFmMShEoQBOwCvTaku}
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTakc.post(url=nYPfjeUXxLJrqFmMShEoQBOwCvTakg,data=nYPfjeUXxLJrqFmMShEoQBOwCvTakA,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaIW,impersonate=nYPfjeUXxLJrqFmMShEoQBOwCvTakI)
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN('{} - {}'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.status_code,nYPfjeUXxLJrqFmMShEoQBOwCvTacz.url))
   for nYPfjeUXxLJrqFmMShEoQBOwCvTaki in nYPfjeUXxLJrqFmMShEoQBOwCvTacz.cookies.jar:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies'][nYPfjeUXxLJrqFmMShEoQBOwCvTaki.name]=nYPfjeUXxLJrqFmMShEoQBOwCvTaki.value
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Init_TV_Total()
   return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  nYPfjeUXxLJrqFmMShEoQBOwCvTacy =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDeviceList()
  if nYPfjeUXxLJrqFmMShEoQBOwCvTacy not in['','-']:
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies']['tving_uuid']=nYPfjeUXxLJrqFmMShEoQBOwCvTacy+'-'+nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetUniqueid(nYPfjeUXxLJrqFmMShEoQBOwCvTacy)
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.JsonFile_Save(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_COOKIE_FILENAME,nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTauH
 def GetDeviceList(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  nYPfjeUXxLJrqFmMShEoQBOwCvTakG=[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTakd='-'
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v1/user/device/list'
   nYPfjeUXxLJrqFmMShEoQBOwCvTakp=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.makeDefaultCookies()
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTakp,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTaks,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaIV)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakG=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(nYPfjeUXxLJrqFmMShEoQBOwCvTakG)
   for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTakG:
    if nYPfjeUXxLJrqFmMShEoQBOwCvTakH['model'].lower().startswith('pc'):
     nYPfjeUXxLJrqFmMShEoQBOwCvTakd=nYPfjeUXxLJrqFmMShEoQBOwCvTakH['uuid']
     break
   if nYPfjeUXxLJrqFmMShEoQBOwCvTakd=='-':
    nYPfjeUXxLJrqFmMShEoQBOwCvTakd=nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetNoCache(timetype=1))
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTakd
 def Get_Now_Datetime(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,mediacode,sel_quality,stype,pvrmode='-',optUHD=nYPfjeUXxLJrqFmMShEoQBOwCvTaup):
  nYPfjeUXxLJrqFmMShEoQBOwCvTakb ={'streaming_url':'','subtitleYn':nYPfjeUXxLJrqFmMShEoQBOwCvTaup,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'','watermark':'','watermarkKey':'','qt_stream':'',}
  nYPfjeUXxLJrqFmMShEoQBOwCvTakd =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies']['tving_uuid'].split('-')[0] 
  nYPfjeUXxLJrqFmMShEoQBOwCvTakW =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies']['tving_uuid'] 
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakz=nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetNoCache(1))
   if stype!='tvingtv':
    nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v2/media/stream/info'
    nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
    nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':nYPfjeUXxLJrqFmMShEoQBOwCvTakW,'deviceInfo':'PC','noCache':nYPfjeUXxLJrqFmMShEoQBOwCvTakz,}
    nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
    nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
    nYPfjeUXxLJrqFmMShEoQBOwCvTaIV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.makeDefaultCookies()
    nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaIV)
    if nYPfjeUXxLJrqFmMShEoQBOwCvTacz.status_code!=200:
     nYPfjeUXxLJrqFmMShEoQBOwCvTakb['error_msg']='First Step - {} error'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.status_code)
     return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
    nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
    if nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']['code']=='060':
     for nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaIb in nYPfjeUXxLJrqFmMShEoQBOwCvTaIk.items():
      if nYPfjeUXxLJrqFmMShEoQBOwCvTaIb==sel_quality:
       nYPfjeUXxLJrqFmMShEoQBOwCvTatI=nYPfjeUXxLJrqFmMShEoQBOwCvTaIy
    elif nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']['code']!='000':
     nYPfjeUXxLJrqFmMShEoQBOwCvTakb['error_msg']=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']['message']
     return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
    else: 
     if not('stream' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']):return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
     nYPfjeUXxLJrqFmMShEoQBOwCvTatc=[]
     for nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaIb in nYPfjeUXxLJrqFmMShEoQBOwCvTaIk.items():
      for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['stream']['quality']:
       if nYPfjeUXxLJrqFmMShEoQBOwCvTakH['active']=='Y' and nYPfjeUXxLJrqFmMShEoQBOwCvTakH['code']==nYPfjeUXxLJrqFmMShEoQBOwCvTaIy:
        nYPfjeUXxLJrqFmMShEoQBOwCvTatc.append({nYPfjeUXxLJrqFmMShEoQBOwCvTaIk.get(nYPfjeUXxLJrqFmMShEoQBOwCvTakH['code']):nYPfjeUXxLJrqFmMShEoQBOwCvTakH['code']})
     nYPfjeUXxLJrqFmMShEoQBOwCvTatI=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.CheckQuality(sel_quality,nYPfjeUXxLJrqFmMShEoQBOwCvTatc)
     try:
      if optUHD==nYPfjeUXxLJrqFmMShEoQBOwCvTauH and nYPfjeUXxLJrqFmMShEoQBOwCvTatI=='stream50' and 'stream_support_info' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['content']['info']:
       if nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['content']['info']['stream_support_info']!=nYPfjeUXxLJrqFmMShEoQBOwCvTaud:
        if 'stream70' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['content']['info']['stream_support_info']:
         nYPfjeUXxLJrqFmMShEoQBOwCvTatI='stream70'
         nYPfjeUXxLJrqFmMShEoQBOwCvTakb['qt_stream']='stream70'
     except:
      pass
     try:
      if optUHD==nYPfjeUXxLJrqFmMShEoQBOwCvTauH and nYPfjeUXxLJrqFmMShEoQBOwCvTatI=='stream50' and 'stream' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['content']['info']:
       if nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['content']['info']['stream']!=nYPfjeUXxLJrqFmMShEoQBOwCvTaud:
        for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['content']['info']['stream']:
         if nYPfjeUXxLJrqFmMShEoQBOwCvTakH['code']=='stream70':
          nYPfjeUXxLJrqFmMShEoQBOwCvTatI='stream70'
          break
     except:
      pass
   else:
    nYPfjeUXxLJrqFmMShEoQBOwCvTatI='stream40'
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakb['error_msg']='First Step - except error'
   return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
  nYPfjeUXxLJrqFmMShEoQBOwCvTakb['qt_stream']=nYPfjeUXxLJrqFmMShEoQBOwCvTatI
  nYPfjeUXxLJrqFmMShEoQBOwCvTauN(nYPfjeUXxLJrqFmMShEoQBOwCvTatI)
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakz=nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetNoCache(1))
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v3/media/stream/info'
   if nYPfjeUXxLJrqFmMShEoQBOwCvTakb['qt_stream']=='stream70':
    nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams(uhd=nYPfjeUXxLJrqFmMShEoQBOwCvTauH)
    nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'mediaCode':mediacode,'deviceId':nYPfjeUXxLJrqFmMShEoQBOwCvTakd,'uuid':nYPfjeUXxLJrqFmMShEoQBOwCvTakW,'deviceInfo':'PC_Chrome WebView','streamCode':nYPfjeUXxLJrqFmMShEoQBOwCvTatI,'noCache':nYPfjeUXxLJrqFmMShEoQBOwCvTakz,'callingFrom':'HTML5','model':'android_chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header','streamType':'hls',}
   else:
    nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
    nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'mediaCode':mediacode,'deviceId':nYPfjeUXxLJrqFmMShEoQBOwCvTakd,'uuid':nYPfjeUXxLJrqFmMShEoQBOwCvTakW,'deviceInfo':'PC_Chrome','streamCode':nYPfjeUXxLJrqFmMShEoQBOwCvTatI,'noCache':nYPfjeUXxLJrqFmMShEoQBOwCvTakz,'callingFrom':'HTML5','model':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.makeDefaultCookies()
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Post',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaIV,redirects=nYPfjeUXxLJrqFmMShEoQBOwCvTauH)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']['code']!='000':
    nYPfjeUXxLJrqFmMShEoQBOwCvTakb['error_msg']=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']['message']
    return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
   nYPfjeUXxLJrqFmMShEoQBOwCvTatk=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['stream']
   if nYPfjeUXxLJrqFmMShEoQBOwCvTatk['drm_yn']=='Y':
    nYPfjeUXxLJrqFmMShEoQBOwCvTati=nYPfjeUXxLJrqFmMShEoQBOwCvTatk['playback']['drm']['widevine']
    for nYPfjeUXxLJrqFmMShEoQBOwCvTatD in nYPfjeUXxLJrqFmMShEoQBOwCvTatk['playback']['drm']['license']['drm_license_data']:
     if nYPfjeUXxLJrqFmMShEoQBOwCvTatD['drm_type']=='Widevine':
      nYPfjeUXxLJrqFmMShEoQBOwCvTakb['drm_server_url'] =nYPfjeUXxLJrqFmMShEoQBOwCvTatD['drm_server_url']
      nYPfjeUXxLJrqFmMShEoQBOwCvTakb['drm_header_key'] =nYPfjeUXxLJrqFmMShEoQBOwCvTatD['drm_header_key']
      nYPfjeUXxLJrqFmMShEoQBOwCvTakb['drm_header_value']=nYPfjeUXxLJrqFmMShEoQBOwCvTatD['drm_header_value']
      break
   else:
    nYPfjeUXxLJrqFmMShEoQBOwCvTati=nYPfjeUXxLJrqFmMShEoQBOwCvTatk['playback']['non_drm']
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakb['error_msg']='Second Step - except error'
   return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
  nYPfjeUXxLJrqFmMShEoQBOwCvTatA=nYPfjeUXxLJrqFmMShEoQBOwCvTakz
  nYPfjeUXxLJrqFmMShEoQBOwCvTati=nYPfjeUXxLJrqFmMShEoQBOwCvTati.split('|')[1]
  nYPfjeUXxLJrqFmMShEoQBOwCvTati,nYPfjeUXxLJrqFmMShEoQBOwCvTatl,nYPfjeUXxLJrqFmMShEoQBOwCvTatu=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Decrypt_Url(nYPfjeUXxLJrqFmMShEoQBOwCvTati,mediacode,nYPfjeUXxLJrqFmMShEoQBOwCvTatA)
  nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url']=nYPfjeUXxLJrqFmMShEoQBOwCvTati
  nYPfjeUXxLJrqFmMShEoQBOwCvTakb['watermark'] =nYPfjeUXxLJrqFmMShEoQBOwCvTatl
  nYPfjeUXxLJrqFmMShEoQBOwCvTakb['watermarkKey']=nYPfjeUXxLJrqFmMShEoQBOwCvTatu
  if 'subtitles' in nYPfjeUXxLJrqFmMShEoQBOwCvTatk:
   for nYPfjeUXxLJrqFmMShEoQBOwCvTatR in nYPfjeUXxLJrqFmMShEoQBOwCvTatk.get('subtitles'):
    if nYPfjeUXxLJrqFmMShEoQBOwCvTatR.get('code')in['KO','KO_CC']:
     nYPfjeUXxLJrqFmMShEoQBOwCvTakb['subtitleYn']=nYPfjeUXxLJrqFmMShEoQBOwCvTauH
     break
  nYPfjeUXxLJrqFmMShEoQBOwCvTatN=urllib.parse.urlparse(nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url'])
  nYPfjeUXxLJrqFmMShEoQBOwCvTatg =nYPfjeUXxLJrqFmMShEoQBOwCvTatN.path.strip('/').split('/')
  nYPfjeUXxLJrqFmMShEoQBOwCvTakb['url_filename']=nYPfjeUXxLJrqFmMShEoQBOwCvTatg[nYPfjeUXxLJrqFmMShEoQBOwCvTauy(nYPfjeUXxLJrqFmMShEoQBOwCvTatg)-1]
  return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
 def TestUrl(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,nYPfjeUXxLJrqFmMShEoQBOwCvTacb):
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIW={}
  nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,redirects=nYPfjeUXxLJrqFmMShEoQBOwCvTauH)
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TextFile_Save(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_SESSION_TEXT1,nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
 def Tving_Parse_mpd(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,stream_url,watermarkKey=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,watermark=nYPfjeUXxLJrqFmMShEoQBOwCvTaud):
  if watermarkKey not in['',nYPfjeUXxLJrqFmMShEoQBOwCvTaud]:
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIW={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,}
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=requests.get(url=stream_url,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaIW,allow_redirects=nYPfjeUXxLJrqFmMShEoQBOwCvTaup)
  else:
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=requests.get(url=stream_url)
  nYPfjeUXxLJrqFmMShEoQBOwCvTatG=nYPfjeUXxLJrqFmMShEoQBOwCvTacz.content.decode('utf-8')
  nYPfjeUXxLJrqFmMShEoQBOwCvTatd=0
  nYPfjeUXxLJrqFmMShEoQBOwCvTatp =ET.ElementTree(ET.fromstring(nYPfjeUXxLJrqFmMShEoQBOwCvTatG))
  nYPfjeUXxLJrqFmMShEoQBOwCvTats =nYPfjeUXxLJrqFmMShEoQBOwCvTatp.getroot()
  nYPfjeUXxLJrqFmMShEoQBOwCvTatK=re.match(r'\{.*\}',nYPfjeUXxLJrqFmMShEoQBOwCvTats.tag)[0] 
  nYPfjeUXxLJrqFmMShEoQBOwCvTatH=nYPfjeUXxLJrqFmMShEoQBOwCvTaRI([node for _,node in ET.iterparse(io.StringIO(nYPfjeUXxLJrqFmMShEoQBOwCvTatG),events=['start-ns'])])
  for nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaig in nYPfjeUXxLJrqFmMShEoQBOwCvTatH.items():
   if nYPfjeUXxLJrqFmMShEoQBOwCvTaIy!='ns2':
    ET.register_namespace(nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaig)
  nYPfjeUXxLJrqFmMShEoQBOwCvTaty=nYPfjeUXxLJrqFmMShEoQBOwCvTats.find(nYPfjeUXxLJrqFmMShEoQBOwCvTatK+'Period')
  for nYPfjeUXxLJrqFmMShEoQBOwCvTatb in nYPfjeUXxLJrqFmMShEoQBOwCvTaty.findall(nYPfjeUXxLJrqFmMShEoQBOwCvTatK+'AdaptationSet'):
   if(nYPfjeUXxLJrqFmMShEoQBOwCvTatb.attrib.get('mimeType')=='video/mp4' or nYPfjeUXxLJrqFmMShEoQBOwCvTatb.attrib.get('contentType')=='video'):
    for nYPfjeUXxLJrqFmMShEoQBOwCvTatW in nYPfjeUXxLJrqFmMShEoQBOwCvTatb.findall(nYPfjeUXxLJrqFmMShEoQBOwCvTatK+'Representation'):
     nYPfjeUXxLJrqFmMShEoQBOwCvTatz=nYPfjeUXxLJrqFmMShEoQBOwCvTaub(nYPfjeUXxLJrqFmMShEoQBOwCvTatW.attrib.get('bandwidth'))
     if nYPfjeUXxLJrqFmMShEoQBOwCvTatd<nYPfjeUXxLJrqFmMShEoQBOwCvTatz:nYPfjeUXxLJrqFmMShEoQBOwCvTatd=nYPfjeUXxLJrqFmMShEoQBOwCvTatz
    for nYPfjeUXxLJrqFmMShEoQBOwCvTatW in nYPfjeUXxLJrqFmMShEoQBOwCvTatb.findall(nYPfjeUXxLJrqFmMShEoQBOwCvTatK+'Representation'):
     if nYPfjeUXxLJrqFmMShEoQBOwCvTatd>nYPfjeUXxLJrqFmMShEoQBOwCvTaub(nYPfjeUXxLJrqFmMShEoQBOwCvTatW.attrib.get('bandwidth')):
      nYPfjeUXxLJrqFmMShEoQBOwCvTatb.remove(nYPfjeUXxLJrqFmMShEoQBOwCvTatW)
   else:
    continue
  nYPfjeUXxLJrqFmMShEoQBOwCvTatV=ET.tostring(nYPfjeUXxLJrqFmMShEoQBOwCvTats).decode('utf-8')
  nYPfjeUXxLJrqFmMShEoQBOwCvTaiI='<?xml version="1.0" encoding="UTF-8"?>\n'
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TextFile_Save(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_STREAM_FILENAME,nYPfjeUXxLJrqFmMShEoQBOwCvTaiI+nYPfjeUXxLJrqFmMShEoQBOwCvTatV)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTauH
 def Tving_Parse_m3u8(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,stream_url):
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=requests.get(url=stream_url,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,stream=nYPfjeUXxLJrqFmMShEoQBOwCvTauH)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaic=nYPfjeUXxLJrqFmMShEoQBOwCvTacz.content.decode('utf-8')
   if '#EXTM3U' not in nYPfjeUXxLJrqFmMShEoQBOwCvTaic:
    return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
   if '#EXT-X-STREAM-INF' not in nYPfjeUXxLJrqFmMShEoQBOwCvTaic: 
    return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
   nYPfjeUXxLJrqFmMShEoQBOwCvTaik=0
   for nYPfjeUXxLJrqFmMShEoQBOwCvTait in nYPfjeUXxLJrqFmMShEoQBOwCvTaic.splitlines():
    if nYPfjeUXxLJrqFmMShEoQBOwCvTait.startswith('#EXT-X-STREAM-INF'):
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiD=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.MediaLine_Parse(nYPfjeUXxLJrqFmMShEoQBOwCvTait,'#EXT-X-STREAM-INF')
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaik<nYPfjeUXxLJrqFmMShEoQBOwCvTaub(nYPfjeUXxLJrqFmMShEoQBOwCvTaiD.get('BANDWIDTH')):
      nYPfjeUXxLJrqFmMShEoQBOwCvTaik=nYPfjeUXxLJrqFmMShEoQBOwCvTaub(nYPfjeUXxLJrqFmMShEoQBOwCvTaiD.get('BANDWIDTH'))
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiA=[]
   nYPfjeUXxLJrqFmMShEoQBOwCvTail=nYPfjeUXxLJrqFmMShEoQBOwCvTaup
   for nYPfjeUXxLJrqFmMShEoQBOwCvTait in nYPfjeUXxLJrqFmMShEoQBOwCvTaic.splitlines():
    if nYPfjeUXxLJrqFmMShEoQBOwCvTail==nYPfjeUXxLJrqFmMShEoQBOwCvTauH:
     nYPfjeUXxLJrqFmMShEoQBOwCvTail=nYPfjeUXxLJrqFmMShEoQBOwCvTaup
     continue
    if nYPfjeUXxLJrqFmMShEoQBOwCvTait.startswith('#EXT-X-STREAM-INF'):
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiD=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.MediaLine_Parse(nYPfjeUXxLJrqFmMShEoQBOwCvTait,'#EXT-X-STREAM-INF')
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaik!=nYPfjeUXxLJrqFmMShEoQBOwCvTaub(nYPfjeUXxLJrqFmMShEoQBOwCvTaiD.get('BANDWIDTH')):
      nYPfjeUXxLJrqFmMShEoQBOwCvTail=nYPfjeUXxLJrqFmMShEoQBOwCvTauH
      continue
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiA.append(nYPfjeUXxLJrqFmMShEoQBOwCvTait)
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
   return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  nYPfjeUXxLJrqFmMShEoQBOwCvTaiu='\n'.join(nYPfjeUXxLJrqFmMShEoQBOwCvTaiA)
  nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TextFile_Save(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_STREAM_FILENAME,nYPfjeUXxLJrqFmMShEoQBOwCvTaiu)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTauH
 def MediaLine_Parse(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,nYPfjeUXxLJrqFmMShEoQBOwCvTait,prefix):
  nYPfjeUXxLJrqFmMShEoQBOwCvTaiD={}
  for nYPfjeUXxLJrqFmMShEoQBOwCvTaiR in nYPfjeUXxLJrqFmMShEoQBOwCvTaIi.split(nYPfjeUXxLJrqFmMShEoQBOwCvTait.replace(prefix+':',''))[1::2]:
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiN,nYPfjeUXxLJrqFmMShEoQBOwCvTaig=nYPfjeUXxLJrqFmMShEoQBOwCvTaiR.split('=',1)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiD[nYPfjeUXxLJrqFmMShEoQBOwCvTaiN.upper()]=nYPfjeUXxLJrqFmMShEoQBOwCvTaig.replace('"','').strip()
  return nYPfjeUXxLJrqFmMShEoQBOwCvTaiD
 def CheckQuality(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,sel_qt,nYPfjeUXxLJrqFmMShEoQBOwCvTatc):
  for nYPfjeUXxLJrqFmMShEoQBOwCvTaiG in nYPfjeUXxLJrqFmMShEoQBOwCvTatc:
   if sel_qt>=nYPfjeUXxLJrqFmMShEoQBOwCvTaRc(nYPfjeUXxLJrqFmMShEoQBOwCvTaiG)[0]:return nYPfjeUXxLJrqFmMShEoQBOwCvTaiG.get(nYPfjeUXxLJrqFmMShEoQBOwCvTaRc(nYPfjeUXxLJrqFmMShEoQBOwCvTaiG)[0])
   nYPfjeUXxLJrqFmMShEoQBOwCvTaid=nYPfjeUXxLJrqFmMShEoQBOwCvTaiG.get(nYPfjeUXxLJrqFmMShEoQBOwCvTaRc(nYPfjeUXxLJrqFmMShEoQBOwCvTaiG)[0])
  return nYPfjeUXxLJrqFmMShEoQBOwCvTaid
 def makeOocUrl(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,ooc_params):
  nYPfjeUXxLJrqFmMShEoQBOwCvTacb=''
  for nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaIb in ooc_params.items():
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb+="%s=%s^"%(nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaIb)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTacb
 def GetLiveChannelList(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,stype,page_int):
  nYPfjeUXxLJrqFmMShEoQBOwCvTakG=[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v2/media/lives'
   if stype=='onair': 
    nYPfjeUXxLJrqFmMShEoQBOwCvTais='CPCS0100,CPCS0400'
   else:
    nYPfjeUXxLJrqFmMShEoQBOwCvTais='CPCS0300'
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'cacheType':'main','pageNo':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(page_int),'pageSize':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':nYPfjeUXxLJrqFmMShEoQBOwCvTais,}
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if not('result' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']):return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']
   for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiH=nYPfjeUXxLJrqFmMShEoQBOwCvTaiW=nYPfjeUXxLJrqFmMShEoQBOwCvTaiz=''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiy=nYPfjeUXxLJrqFmMShEoQBOwCvTaDK=''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaib=nYPfjeUXxLJrqFmMShEoQBOwCvTakH['live_code']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiH =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['channel']['name']['ko']
    if nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['episode']!=nYPfjeUXxLJrqFmMShEoQBOwCvTaud:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiW =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['program']['name']['ko']
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiW =nYPfjeUXxLJrqFmMShEoQBOwCvTaiW+', '+nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['episode']['frequency'])+'회'
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiz=nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['episode']['synopsis']['ko']
    else:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiW =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['program']['name']['ko']
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiz=nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['program']['synopsis']['ko']
    try: 
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =''
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =''
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=''
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDk =''
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDt =''
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDi =''
     for nYPfjeUXxLJrqFmMShEoQBOwCvTaDA in nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['program']['image']:
      if nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP0900':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
      elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP1800':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
      elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP2000':nYPfjeUXxLJrqFmMShEoQBOwCvTaDk =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
      elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP1900':nYPfjeUXxLJrqFmMShEoQBOwCvTaDt =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
      elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP0200':nYPfjeUXxLJrqFmMShEoQBOwCvTaDi =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
      elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP0500':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
      elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP0800':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaiV=='':
      for nYPfjeUXxLJrqFmMShEoQBOwCvTaDA in nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['channel']['image']:
       if nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIC0400':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
       elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIC1400':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
       elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIC1900':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
    except:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaud
    try:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDl =[]
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDu=[]
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDR =[]
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDN=''
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDg=''
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDG=''
     for nYPfjeUXxLJrqFmMShEoQBOwCvTaDd in nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('schedule').get('program').get('actor'):
      if nYPfjeUXxLJrqFmMShEoQBOwCvTaDd!='' and nYPfjeUXxLJrqFmMShEoQBOwCvTaDd!=u'없음':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDd)
     for nYPfjeUXxLJrqFmMShEoQBOwCvTaDp in nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('schedule').get('program').get('director'):
      if nYPfjeUXxLJrqFmMShEoQBOwCvTaDp!='' and nYPfjeUXxLJrqFmMShEoQBOwCvTaDp!='-' and nYPfjeUXxLJrqFmMShEoQBOwCvTaDp!=u'없음':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDp)
     if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('schedule').get('program').get('category1_name').get('ko')!='':
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDR.append(nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['program']['category1_name']['ko'])
     if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('schedule').get('program').get('category2_name').get('ko')!='':
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDR.append(nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['program']['category2_name']['ko'])
     if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('schedule').get('program').get('product_year'):nYPfjeUXxLJrqFmMShEoQBOwCvTaDN=nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['program']['product_year']
     if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('schedule').get('program').get('grade_code') :nYPfjeUXxLJrqFmMShEoQBOwCvTaDg= nYPfjeUXxLJrqFmMShEoQBOwCvTaIt.get(nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['program']['grade_code'])
     if 'broad_dt' in nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('schedule').get('program'):
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDs =nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('schedule').get('program').get('broad_dt')
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDG='%s-%s-%s'%(nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[:4],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[4:6],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[6:])
    except:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaud
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiy=nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['broadcast_start_time'])[8:12]
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDK =nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTakH['schedule']['broadcast_end_time'])[8:12]
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'channel':nYPfjeUXxLJrqFmMShEoQBOwCvTaiH,'title':nYPfjeUXxLJrqFmMShEoQBOwCvTaiW,'mediacode':nYPfjeUXxLJrqFmMShEoQBOwCvTaib,'thumbnail':{'poster':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI,'thumb':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV,'clearlogo':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc,'icon':nYPfjeUXxLJrqFmMShEoQBOwCvTaDk,'fanart':nYPfjeUXxLJrqFmMShEoQBOwCvTaDi},'synopsis':nYPfjeUXxLJrqFmMShEoQBOwCvTaiz,'channelepg':' [%s:%s ~ %s:%s]'%(nYPfjeUXxLJrqFmMShEoQBOwCvTaiy[0:2],nYPfjeUXxLJrqFmMShEoQBOwCvTaiy[2:],nYPfjeUXxLJrqFmMShEoQBOwCvTaDK[0:2],nYPfjeUXxLJrqFmMShEoQBOwCvTaDK[2:]),'cast':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl,'director':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu,'info_genre':nYPfjeUXxLJrqFmMShEoQBOwCvTaDR,'year':nYPfjeUXxLJrqFmMShEoQBOwCvTaDN,'mpaa':nYPfjeUXxLJrqFmMShEoQBOwCvTaDg,'premiered':nYPfjeUXxLJrqFmMShEoQBOwCvTaDG}
    nYPfjeUXxLJrqFmMShEoQBOwCvTakG.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
   if nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['has_more']=='Y':
    nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTauH
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
 def GetProgramList(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,genre,orderby,page_int,genreCode='all'):
  nYPfjeUXxLJrqFmMShEoQBOwCvTakG=[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v2/media/episodes'
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'cacheType':'main','pageSize':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(page_int),}
   if genre not in['all','PARAMOUNT']:nYPfjeUXxLJrqFmMShEoQBOwCvTaks['categoryCode']=genre
   if genreCode!='all' :nYPfjeUXxLJrqFmMShEoQBOwCvTaks['genreCode'] =genreCode 
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if not('result' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']):return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']
   for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDy=nYPfjeUXxLJrqFmMShEoQBOwCvTakH['program']['code']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiW =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['program']['name']['ko']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDg =nYPfjeUXxLJrqFmMShEoQBOwCvTaIt.get(nYPfjeUXxLJrqFmMShEoQBOwCvTakH['program'].get('grade_code'))
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDk =''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDt =''
    for nYPfjeUXxLJrqFmMShEoQBOwCvTaDA in nYPfjeUXxLJrqFmMShEoQBOwCvTakH['program']['image']:
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP0900':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP0200':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP1800':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP2000':nYPfjeUXxLJrqFmMShEoQBOwCvTaDk =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP1900':nYPfjeUXxLJrqFmMShEoQBOwCvTaDt =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiz =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['program']['synopsis']['ko']
    try:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDb=nYPfjeUXxLJrqFmMShEoQBOwCvTakH['channel']['name']['ko']
    except:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDb=''
    try:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDl =[]
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDu=[]
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDR =[]
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDN =''
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDG=''
     for nYPfjeUXxLJrqFmMShEoQBOwCvTaDd in nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('program').get('actor'):
      if nYPfjeUXxLJrqFmMShEoQBOwCvTaDd!='' and nYPfjeUXxLJrqFmMShEoQBOwCvTaDd!='-' and nYPfjeUXxLJrqFmMShEoQBOwCvTaDd!=u'없음':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDd)
     for nYPfjeUXxLJrqFmMShEoQBOwCvTaDp in nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('program').get('director'):
      if nYPfjeUXxLJrqFmMShEoQBOwCvTaDp!='' and nYPfjeUXxLJrqFmMShEoQBOwCvTaDp!='-' and nYPfjeUXxLJrqFmMShEoQBOwCvTaDp!=u'없음':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDp)
     if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('program').get('category1_name').get('ko')!='':
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDR.append(nYPfjeUXxLJrqFmMShEoQBOwCvTakH['program']['category1_name']['ko'])
     if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('program').get('category2_name').get('ko')!='':
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDR.append(nYPfjeUXxLJrqFmMShEoQBOwCvTakH['program']['category2_name']['ko'])
     if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('program').get('product_year'):nYPfjeUXxLJrqFmMShEoQBOwCvTaDN=nYPfjeUXxLJrqFmMShEoQBOwCvTakH['program']['product_year']
     if 'broad_dt' in nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('program'):
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDs =nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('program').get('broad_dt')
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDG='%s-%s-%s'%(nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[:4],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[4:6],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[6:])
    except:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaud
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'program':nYPfjeUXxLJrqFmMShEoQBOwCvTaDy,'title':nYPfjeUXxLJrqFmMShEoQBOwCvTaiW,'thumbnail':{'poster':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI,'thumb':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV,'clearlogo':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc,'icon':nYPfjeUXxLJrqFmMShEoQBOwCvTaDk,'banner':nYPfjeUXxLJrqFmMShEoQBOwCvTaDt,'fanart':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV},'synopsis':nYPfjeUXxLJrqFmMShEoQBOwCvTaiz,'channel':nYPfjeUXxLJrqFmMShEoQBOwCvTaDb,'cast':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl,'director':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu,'info_genre':nYPfjeUXxLJrqFmMShEoQBOwCvTaDR,'year':nYPfjeUXxLJrqFmMShEoQBOwCvTaDN,'premiered':nYPfjeUXxLJrqFmMShEoQBOwCvTaDG,'mpaa':nYPfjeUXxLJrqFmMShEoQBOwCvTaDg}
    nYPfjeUXxLJrqFmMShEoQBOwCvTakG.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
   if nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['has_more']=='Y':nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTauH
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
 def Get_UHD_ProgramList(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,page_int):
  nYPfjeUXxLJrqFmMShEoQBOwCvTakG=[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v2/operator/highlights'
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams(uhd=nYPfjeUXxLJrqFmMShEoQBOwCvTauH)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(page_int),'pocType':'APP_X_TVING_4.0.0',}
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if not('result' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']):return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']
   for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDW=nYPfjeUXxLJrqFmMShEoQBOwCvTakH['content']['program']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDz =nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['code']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiW =nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['name']['ko'].strip()
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDg =nYPfjeUXxLJrqFmMShEoQBOwCvTaIt.get(nYPfjeUXxLJrqFmMShEoQBOwCvTaDW.get('grade_code'))
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiz =nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['synopsis']['ko']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDb =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['content']['channel']['name']['ko']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDN =nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['product_year']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDk =''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDt =''
    for nYPfjeUXxLJrqFmMShEoQBOwCvTaDA in nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['image']:
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP0900':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP0200':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP1800':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP2000':nYPfjeUXxLJrqFmMShEoQBOwCvTaDk =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP1900':nYPfjeUXxLJrqFmMShEoQBOwCvTaDt =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDR =[]
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDl =[]
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDu=[]
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDG =''
    if nYPfjeUXxLJrqFmMShEoQBOwCvTaDW.get('category1_name').get('ko')!='':
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDR.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['category1_name']['ko'])
    if nYPfjeUXxLJrqFmMShEoQBOwCvTaDW.get('category2_name').get('ko')!='':
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDR.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['category2_name']['ko'])
    for nYPfjeUXxLJrqFmMShEoQBOwCvTaDd in nYPfjeUXxLJrqFmMShEoQBOwCvTaDW.get('actor'):
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaDd!='' and nYPfjeUXxLJrqFmMShEoQBOwCvTaDd!='-' and nYPfjeUXxLJrqFmMShEoQBOwCvTaDd!=u'없음':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDd)
    for nYPfjeUXxLJrqFmMShEoQBOwCvTaDp in nYPfjeUXxLJrqFmMShEoQBOwCvTaDW.get('director'):
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaDp!='' and nYPfjeUXxLJrqFmMShEoQBOwCvTaDp!='-' and nYPfjeUXxLJrqFmMShEoQBOwCvTaDp!=u'없음':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDp)
    if nYPfjeUXxLJrqFmMShEoQBOwCvTaDW.get('broad_dt')not in[nYPfjeUXxLJrqFmMShEoQBOwCvTaud,'']:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDs =nYPfjeUXxLJrqFmMShEoQBOwCvTaDW.get('broad_dt')
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDG='%s-%s-%s'%(nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[:4],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[4:6],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[6:])
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'program':nYPfjeUXxLJrqFmMShEoQBOwCvTaDz,'title':nYPfjeUXxLJrqFmMShEoQBOwCvTaiW,'mpaa':nYPfjeUXxLJrqFmMShEoQBOwCvTaDg,'thumbnail':{'poster':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI,'thumb':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV,'clearlogo':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc,'icon':nYPfjeUXxLJrqFmMShEoQBOwCvTaDk,'banner':nYPfjeUXxLJrqFmMShEoQBOwCvTaDt,'fanart':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV},'channel':nYPfjeUXxLJrqFmMShEoQBOwCvTaDb,'synopsis':nYPfjeUXxLJrqFmMShEoQBOwCvTaiz,'year':nYPfjeUXxLJrqFmMShEoQBOwCvTaDN,'info_genre':nYPfjeUXxLJrqFmMShEoQBOwCvTaDR,'cast':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl,'director':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu,'premiered':nYPfjeUXxLJrqFmMShEoQBOwCvTaDG,}
    nYPfjeUXxLJrqFmMShEoQBOwCvTakG.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
 def Get_Origianl_ProgramList(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,page_int):
  nYPfjeUXxLJrqFmMShEoQBOwCvTakG=[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v2/media/band/originals'
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'pageSize':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(page_int),}
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDV=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.JsonFile_Save(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_SESSION_COOKIES2,nYPfjeUXxLJrqFmMShEoQBOwCvTaDV)
   if not('contents' in nYPfjeUXxLJrqFmMShEoQBOwCvTaDV['body']):return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTaDV['body']['contents']
   for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAI =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['vod_code']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiW =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['vod_name']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakH['image']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAc ='movie' if nYPfjeUXxLJrqFmMShEoQBOwCvTaAI.startswith('M')else 'vod'
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'vod_code':nYPfjeUXxLJrqFmMShEoQBOwCvTaAI,'title':nYPfjeUXxLJrqFmMShEoQBOwCvTaiW,'thumbnail':{'poster':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI,'thumb':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI},'vod_type':nYPfjeUXxLJrqFmMShEoQBOwCvTaAc,}
    nYPfjeUXxLJrqFmMShEoQBOwCvTakG.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
   if nYPfjeUXxLJrqFmMShEoQBOwCvTaDV['body']['has_more']=='Y':nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTauH
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
 def GetEpisodeList(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,program_code,page_int,orderby='desc'):
  nYPfjeUXxLJrqFmMShEoQBOwCvTakG=[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v2/media/frequency/program/'+program_code
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if not('result' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']):return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']
   nYPfjeUXxLJrqFmMShEoQBOwCvTaAk=nYPfjeUXxLJrqFmMShEoQBOwCvTaub(nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['total_count'])
   nYPfjeUXxLJrqFmMShEoQBOwCvTaAt =nYPfjeUXxLJrqFmMShEoQBOwCvTaub(nYPfjeUXxLJrqFmMShEoQBOwCvTaAk//(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAi =(nYPfjeUXxLJrqFmMShEoQBOwCvTaAk-1)-((page_int-1)*nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.EPISODE_LIMIT)
   else:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAi =(page_int-1)*nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.EPISODE_LIMIT
   for i in nYPfjeUXxLJrqFmMShEoQBOwCvTauW(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.EPISODE_LIMIT):
    if orderby=='desc':
     nYPfjeUXxLJrqFmMShEoQBOwCvTaAD=nYPfjeUXxLJrqFmMShEoQBOwCvTaAi-i
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaAD<0:break
    else:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaAD=nYPfjeUXxLJrqFmMShEoQBOwCvTaAi+i
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaAD>=nYPfjeUXxLJrqFmMShEoQBOwCvTaAk:break
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAl=nYPfjeUXxLJrqFmMShEoQBOwCvTaiK[nYPfjeUXxLJrqFmMShEoQBOwCvTaAD]['episode']['code']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiW =nYPfjeUXxLJrqFmMShEoQBOwCvTaiK[nYPfjeUXxLJrqFmMShEoQBOwCvTaAD]['vod_name']['ko']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAu =''
    try:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDs=nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaiK[nYPfjeUXxLJrqFmMShEoQBOwCvTaAD]['episode']['broadcast_date'])
     nYPfjeUXxLJrqFmMShEoQBOwCvTaAu='%s-%s-%s'%(nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[:4],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[4:6],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[6:])
    except:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaud
    try:
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaiK[nYPfjeUXxLJrqFmMShEoQBOwCvTaAD]['episode']['pip_cliptype']=='C012':
      nYPfjeUXxLJrqFmMShEoQBOwCvTaAu+=' - Quick VOD'
    except:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaud
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiz =nYPfjeUXxLJrqFmMShEoQBOwCvTaiK[nYPfjeUXxLJrqFmMShEoQBOwCvTaAD]['episode']['synopsis']['ko']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDk =''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDt =''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDi =''
    for nYPfjeUXxLJrqFmMShEoQBOwCvTaDA in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK[nYPfjeUXxLJrqFmMShEoQBOwCvTaAD]['program']['image']:
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP0900':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP1800':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP2000':nYPfjeUXxLJrqFmMShEoQBOwCvTaDk =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP1900':nYPfjeUXxLJrqFmMShEoQBOwCvTaDt =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIP0200':nYPfjeUXxLJrqFmMShEoQBOwCvTaDi =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
    for nYPfjeUXxLJrqFmMShEoQBOwCvTaDA in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK[nYPfjeUXxLJrqFmMShEoQBOwCvTaAD]['episode']['image']:
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIE0400':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
    try:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaAR=nYPfjeUXxLJrqFmMShEoQBOwCvTaAg=nYPfjeUXxLJrqFmMShEoQBOwCvTaAG=''
     nYPfjeUXxLJrqFmMShEoQBOwCvTaAN=0
     nYPfjeUXxLJrqFmMShEoQBOwCvTaAR =nYPfjeUXxLJrqFmMShEoQBOwCvTaiK[nYPfjeUXxLJrqFmMShEoQBOwCvTaAD]['program']['name']['ko']
     nYPfjeUXxLJrqFmMShEoQBOwCvTaAg =nYPfjeUXxLJrqFmMShEoQBOwCvTaAu
     nYPfjeUXxLJrqFmMShEoQBOwCvTaAG =nYPfjeUXxLJrqFmMShEoQBOwCvTaiK[nYPfjeUXxLJrqFmMShEoQBOwCvTaAD]['channel']['name']['ko']
     if 'frequency' in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK[nYPfjeUXxLJrqFmMShEoQBOwCvTaAD]['episode']:nYPfjeUXxLJrqFmMShEoQBOwCvTaAN=nYPfjeUXxLJrqFmMShEoQBOwCvTaiK[nYPfjeUXxLJrqFmMShEoQBOwCvTaAD]['episode']['frequency']
    except:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaud
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'episode':nYPfjeUXxLJrqFmMShEoQBOwCvTaAl,'title':nYPfjeUXxLJrqFmMShEoQBOwCvTaiW,'subtitle':nYPfjeUXxLJrqFmMShEoQBOwCvTaAu,'thumbnail':{'poster':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI,'thumb':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV,'clearlogo':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc,'icon':nYPfjeUXxLJrqFmMShEoQBOwCvTaDk,'banner':nYPfjeUXxLJrqFmMShEoQBOwCvTaDt,'fanart':nYPfjeUXxLJrqFmMShEoQBOwCvTaDi},'synopsis':nYPfjeUXxLJrqFmMShEoQBOwCvTaiz,'info_title':nYPfjeUXxLJrqFmMShEoQBOwCvTaAR,'aired':nYPfjeUXxLJrqFmMShEoQBOwCvTaAg,'studio':nYPfjeUXxLJrqFmMShEoQBOwCvTaAG,'frequency':nYPfjeUXxLJrqFmMShEoQBOwCvTaAN}
    nYPfjeUXxLJrqFmMShEoQBOwCvTakG.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
   if nYPfjeUXxLJrqFmMShEoQBOwCvTaAt>page_int:nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTauH
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip,nYPfjeUXxLJrqFmMShEoQBOwCvTaAt
 def GetMovieList(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,genre,orderby,page_int):
  nYPfjeUXxLJrqFmMShEoQBOwCvTakG=[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v2/media/movies'
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'pageSize':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:nYPfjeUXxLJrqFmMShEoQBOwCvTaks['categoryCode']=genre
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks['productPackageCode']=','.join(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.MOVIE_LITE)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if not('result' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']):return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']
   for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK:
    if 'release_date' in nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('movie'):
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDN=nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('movie').get('release_date'))[:4]
    else:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDN=nYPfjeUXxLJrqFmMShEoQBOwCvTaud
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAd =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['movie']['code']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiW =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['movie']['name']['ko'].strip()
    if nYPfjeUXxLJrqFmMShEoQBOwCvTaDN not in[nYPfjeUXxLJrqFmMShEoQBOwCvTaud,'0','']:nYPfjeUXxLJrqFmMShEoQBOwCvTaiW+=u' (%s)'%(nYPfjeUXxLJrqFmMShEoQBOwCvTaDN)
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDI=''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=''
    for nYPfjeUXxLJrqFmMShEoQBOwCvTaDA in nYPfjeUXxLJrqFmMShEoQBOwCvTakH['movie']['image']:
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIM2100':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIM0400':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIM1800':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiz =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['movie']['story']['ko']
    try:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaAR =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['movie']['name']['ko'].strip()
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDg =nYPfjeUXxLJrqFmMShEoQBOwCvTaIt.get(nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('grade_code'))
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDl=[]
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDu=[]
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDR=[]
     nYPfjeUXxLJrqFmMShEoQBOwCvTaAp=0
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDG=''
     nYPfjeUXxLJrqFmMShEoQBOwCvTaAG =''
     for nYPfjeUXxLJrqFmMShEoQBOwCvTaDd in nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('movie').get('actor'):
      if nYPfjeUXxLJrqFmMShEoQBOwCvTaDd!='':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDd)
     for nYPfjeUXxLJrqFmMShEoQBOwCvTaDp in nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('movie').get('director'):
      if nYPfjeUXxLJrqFmMShEoQBOwCvTaDp!='':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDp)
     if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('movie').get('category1_name').get('ko')!='':
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDR.append(nYPfjeUXxLJrqFmMShEoQBOwCvTakH['movie']['category1_name']['ko'])
     if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('movie').get('category2_name').get('ko')!='':
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDR.append(nYPfjeUXxLJrqFmMShEoQBOwCvTakH['movie']['category2_name']['ko'])
     if 'duration' in nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('movie'):nYPfjeUXxLJrqFmMShEoQBOwCvTaAp=nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('movie').get('duration')
     if 'release_date' in nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('movie'):
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDs=nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('movie').get('release_date'))
      if nYPfjeUXxLJrqFmMShEoQBOwCvTaDs!='0':nYPfjeUXxLJrqFmMShEoQBOwCvTaDG='%s-%s-%s'%(nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[:4],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[4:6],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[6:])
     if 'production' in nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('movie'):nYPfjeUXxLJrqFmMShEoQBOwCvTaAG=nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('movie').get('production')
    except:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaud
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'moviecode':nYPfjeUXxLJrqFmMShEoQBOwCvTaAd,'title':nYPfjeUXxLJrqFmMShEoQBOwCvTaiW,'thumbnail':{'poster':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI,'thumb':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV,'clearlogo':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc,'fanart':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV},'synopsis':nYPfjeUXxLJrqFmMShEoQBOwCvTaiz,'info_title':nYPfjeUXxLJrqFmMShEoQBOwCvTaAR,'year':nYPfjeUXxLJrqFmMShEoQBOwCvTaDN,'cast':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl,'director':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu,'info_genre':nYPfjeUXxLJrqFmMShEoQBOwCvTaDR,'duration':nYPfjeUXxLJrqFmMShEoQBOwCvTaAp,'premiered':nYPfjeUXxLJrqFmMShEoQBOwCvTaDG,'studio':nYPfjeUXxLJrqFmMShEoQBOwCvTaAG,'mpaa':nYPfjeUXxLJrqFmMShEoQBOwCvTaDg}
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAs=nYPfjeUXxLJrqFmMShEoQBOwCvTaup
    for nYPfjeUXxLJrqFmMShEoQBOwCvTaAK in nYPfjeUXxLJrqFmMShEoQBOwCvTakH['billing_package_id']:
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaAK in nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.MOVIE_LITE:
      nYPfjeUXxLJrqFmMShEoQBOwCvTaAs=nYPfjeUXxLJrqFmMShEoQBOwCvTauH
      break
    if nYPfjeUXxLJrqFmMShEoQBOwCvTaAs==nYPfjeUXxLJrqFmMShEoQBOwCvTaup: 
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDH['title']=nYPfjeUXxLJrqFmMShEoQBOwCvTaDH['title']+' [개별구매]'
    nYPfjeUXxLJrqFmMShEoQBOwCvTakG.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
   if nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['has_more']=='Y':nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTauH
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
 def Get_UHD_MovieList(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,page_int):
  nYPfjeUXxLJrqFmMShEoQBOwCvTakG=[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v2/operator/highlights'
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams(uhd=nYPfjeUXxLJrqFmMShEoQBOwCvTauH)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(page_int),'pocType':'APP_X_TVING_4.0.0',}
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if not('result' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']):return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']
   for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDW=nYPfjeUXxLJrqFmMShEoQBOwCvTakH['content']['movie']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDz =nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['code']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiW =nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['name']['ko'].strip()
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAR =nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['name']['ko'].strip()
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDN =nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['product_year']
    if nYPfjeUXxLJrqFmMShEoQBOwCvTaDN:nYPfjeUXxLJrqFmMShEoQBOwCvTaiW+=u' (%s)'%(nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['product_year'])
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiz =nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['story']['ko']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAp =nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['duration']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDg =nYPfjeUXxLJrqFmMShEoQBOwCvTaIt.get(nYPfjeUXxLJrqFmMShEoQBOwCvTaDW.get('grade_code'))
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAG =nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['production']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDI=''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=''
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDR =[]
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDl =[]
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDu=[]
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDG =''
    for nYPfjeUXxLJrqFmMShEoQBOwCvTaDA in nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['image']:
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIM2100':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIM0400':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
     elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['code']=='CAIM1800':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA['url']
    if nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['release_date']not in[nYPfjeUXxLJrqFmMShEoQBOwCvTaud,0]:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDs=nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['release_date'])
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaDs!='0':nYPfjeUXxLJrqFmMShEoQBOwCvTaDG='%s-%s-%s'%(nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[:4],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[4:6],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[6:])
    if nYPfjeUXxLJrqFmMShEoQBOwCvTaDW.get('category1_name').get('ko')!='':
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDR.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['category1_name']['ko'])
    if nYPfjeUXxLJrqFmMShEoQBOwCvTaDW.get('category2_name').get('ko')!='':
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDR.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDW['category2_name']['ko'])
    for nYPfjeUXxLJrqFmMShEoQBOwCvTaDd in nYPfjeUXxLJrqFmMShEoQBOwCvTaDW.get('actor'):
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaDd!='':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDd)
    for nYPfjeUXxLJrqFmMShEoQBOwCvTaDp in nYPfjeUXxLJrqFmMShEoQBOwCvTaDW.get('director'):
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaDp!='':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDp)
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'moviecode':nYPfjeUXxLJrqFmMShEoQBOwCvTaDz,'title':nYPfjeUXxLJrqFmMShEoQBOwCvTaiW,'thumbnail':{'poster':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI,'thumb':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV,'clearlogo':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc,'fanart':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV},'year':nYPfjeUXxLJrqFmMShEoQBOwCvTaDN,'info_title':nYPfjeUXxLJrqFmMShEoQBOwCvTaAR,'synopsis':nYPfjeUXxLJrqFmMShEoQBOwCvTaiz,'mpaa':nYPfjeUXxLJrqFmMShEoQBOwCvTaDg,'duration':nYPfjeUXxLJrqFmMShEoQBOwCvTaAp,'premiered':nYPfjeUXxLJrqFmMShEoQBOwCvTaDG,'studio':nYPfjeUXxLJrqFmMShEoQBOwCvTaAG,'info_genre':nYPfjeUXxLJrqFmMShEoQBOwCvTaDR,'cast':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl,'director':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu,}
    nYPfjeUXxLJrqFmMShEoQBOwCvTakG.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
 def GetMovieGenre(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  nYPfjeUXxLJrqFmMShEoQBOwCvTakG=[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v2/media/movie/curations'
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if not('result' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']):return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']
   for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAH =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['curation_code']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAy =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['curation_name']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'curation_code':nYPfjeUXxLJrqFmMShEoQBOwCvTaAH,'curation_name':nYPfjeUXxLJrqFmMShEoQBOwCvTaAy}
    nYPfjeUXxLJrqFmMShEoQBOwCvTakG.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
 def GetSearchList(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,search_key,page_int,stype):
  nYPfjeUXxLJrqFmMShEoQBOwCvTaAb=[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/search/getSearch.jsp'
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SCREENCODE,'os':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.OSCODE,'network':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.APIKEY,'networkCode':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.NETWORKCODE,'osCode ':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.OSCODE,'teleCode ':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TELECODE,'screenCode ':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SCREENCODE}
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SEARCH_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTaks,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if stype=='vod':
    if not('programRsb' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK):return nYPfjeUXxLJrqFmMShEoQBOwCvTaAb,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAW=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['programRsb']['dataList']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAz =nYPfjeUXxLJrqFmMShEoQBOwCvTaub(nYPfjeUXxLJrqFmMShEoQBOwCvTakK['programRsb']['count'])
    for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTaAW:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDy=nYPfjeUXxLJrqFmMShEoQBOwCvTakH['mast_cd']
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiW =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['mast_nm']
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDI=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakH['web_url4']
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakH['web_url']
     try:
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDl =[]
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDu=[]
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDR =[]
      nYPfjeUXxLJrqFmMShEoQBOwCvTaAp =0
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDg =''
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDN =''
      nYPfjeUXxLJrqFmMShEoQBOwCvTaAg =''
      if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('actor') !='' and nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('actor') !='-':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl =nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('actor').split(',')
      if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('director')!='' and nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('director')!='-':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu=nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('director').split(',')
      if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('cate_nm')!='' and nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('cate_nm')!='-':nYPfjeUXxLJrqFmMShEoQBOwCvTaDR =nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('cate_nm').split('/')
      if 'targetage' in nYPfjeUXxLJrqFmMShEoQBOwCvTakH:nYPfjeUXxLJrqFmMShEoQBOwCvTaDg=nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('targetage')
      if 'broad_dt' in nYPfjeUXxLJrqFmMShEoQBOwCvTakH:
       nYPfjeUXxLJrqFmMShEoQBOwCvTaDs=nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('broad_dt')
       nYPfjeUXxLJrqFmMShEoQBOwCvTaAg='%s-%s-%s'%(nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[:4],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[4:6],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[6:])
       nYPfjeUXxLJrqFmMShEoQBOwCvTaDN =nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[:4]
     except:
      nYPfjeUXxLJrqFmMShEoQBOwCvTaud
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'program':nYPfjeUXxLJrqFmMShEoQBOwCvTaDy,'title':nYPfjeUXxLJrqFmMShEoQBOwCvTaiW,'thumbnail':{'poster':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI,'thumb':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV,'fanart':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV},'synopsis':'','cast':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl,'director':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu,'info_genre':nYPfjeUXxLJrqFmMShEoQBOwCvTaDR,'duration':nYPfjeUXxLJrqFmMShEoQBOwCvTaAp,'mpaa':nYPfjeUXxLJrqFmMShEoQBOwCvTaDg,'year':nYPfjeUXxLJrqFmMShEoQBOwCvTaDN,'aired':nYPfjeUXxLJrqFmMShEoQBOwCvTaAg}
     nYPfjeUXxLJrqFmMShEoQBOwCvTaAb.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
   else:
    if not('vodMVRsb' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK):return nYPfjeUXxLJrqFmMShEoQBOwCvTaAb,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAV=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['vodMVRsb']['dataList']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaAz =nYPfjeUXxLJrqFmMShEoQBOwCvTaub(nYPfjeUXxLJrqFmMShEoQBOwCvTakK['vodMVRsb']['count'])
    for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTaAV:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDy=nYPfjeUXxLJrqFmMShEoQBOwCvTakH['mast_cd']
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiW =nYPfjeUXxLJrqFmMShEoQBOwCvTakH['mast_nm'].strip()
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakH['web_url']
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaDI
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=''
     try:
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDl =[]
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDu=[]
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDR =[]
      nYPfjeUXxLJrqFmMShEoQBOwCvTaAp =0
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDg =''
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDN =''
      nYPfjeUXxLJrqFmMShEoQBOwCvTaAg =''
      if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('actor') !='' and nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('actor') !='-':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl =nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('actor').split(',')
      if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('director')!='' and nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('director')!='-':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu=nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('director').split(',')
      if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('cate_nm')!='' and nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('cate_nm')!='-':nYPfjeUXxLJrqFmMShEoQBOwCvTaDR =nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('cate_nm').split('/')
      if nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('runtime_sec')!='':nYPfjeUXxLJrqFmMShEoQBOwCvTaAp=nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('runtime_sec')
      if 'grade_nm' in nYPfjeUXxLJrqFmMShEoQBOwCvTakH:nYPfjeUXxLJrqFmMShEoQBOwCvTaDg=nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('grade_nm')
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDs=nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('broad_dt')
      if data_str!='':
       nYPfjeUXxLJrqFmMShEoQBOwCvTaAg='%s-%s-%s'%(nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[:4],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[4:6],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[6:])
       nYPfjeUXxLJrqFmMShEoQBOwCvTaDN =nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[:4]
     except:
      nYPfjeUXxLJrqFmMShEoQBOwCvTaud
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'movie':nYPfjeUXxLJrqFmMShEoQBOwCvTaDy,'title':nYPfjeUXxLJrqFmMShEoQBOwCvTaiW,'thumbnail':{'poster':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI,'thumb':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV,'fanart':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV,'clearlogo':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc},'synopsis':'','cast':nYPfjeUXxLJrqFmMShEoQBOwCvTaDl,'director':nYPfjeUXxLJrqFmMShEoQBOwCvTaDu,'info_genre':nYPfjeUXxLJrqFmMShEoQBOwCvTaDR,'duration':nYPfjeUXxLJrqFmMShEoQBOwCvTaAp,'mpaa':nYPfjeUXxLJrqFmMShEoQBOwCvTaDg,'year':nYPfjeUXxLJrqFmMShEoQBOwCvTaDN,'aired':nYPfjeUXxLJrqFmMShEoQBOwCvTaAg}
     nYPfjeUXxLJrqFmMShEoQBOwCvTaAb.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
   if nYPfjeUXxLJrqFmMShEoQBOwCvTaAz>(page_int*nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.SEARCH_LIMIT):nYPfjeUXxLJrqFmMShEoQBOwCvTaip=nYPfjeUXxLJrqFmMShEoQBOwCvTauH
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTaAb,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
 def GetBookmarkInfo(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,videoid,vidtype):
  nYPfjeUXxLJrqFmMShEoQBOwCvTalI={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+'/v2/media/program/'+videoid
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'pageNo':'1','pageSize':'10','order':'name',}
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDV=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if not('body' in nYPfjeUXxLJrqFmMShEoQBOwCvTaDV):return{}
   nYPfjeUXxLJrqFmMShEoQBOwCvTalc=nYPfjeUXxLJrqFmMShEoQBOwCvTaDV['body']
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiW=nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('name').get('ko').strip()
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['title'] =nYPfjeUXxLJrqFmMShEoQBOwCvTaiW
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['title']=nYPfjeUXxLJrqFmMShEoQBOwCvTaiW
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['mpaa'] =nYPfjeUXxLJrqFmMShEoQBOwCvTaIt.get(nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('grade_code'))
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['plot'] =nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('synopsis').get('ko')
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['year'] =nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('product_year')
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['cast'] =nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('actor')
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['director']=nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('director')
   if nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('category1_name').get('ko')!='':
    nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['genre'].append(nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('category1_name').get('ko'))
   if nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('category2_name').get('ko')!='':
    nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['genre'].append(nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('category2_name').get('ko'))
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDs=nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('broad_dt'))
   if nYPfjeUXxLJrqFmMShEoQBOwCvTaDs!='0':nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[:4],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[4:6],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[6:])
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =''
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =''
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=''
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDk =''
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDt =''
   for nYPfjeUXxLJrqFmMShEoQBOwCvTaDA in nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('image'):
    if nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('code')=='CAIP0900':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('url')
    elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('code')=='CAIP0200':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('url')
    elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('code')=='CAIP1800':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('url')
    elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('code')=='CAIP2000':nYPfjeUXxLJrqFmMShEoQBOwCvTaDk =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('url')
    elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('code')=='CAIP1900':nYPfjeUXxLJrqFmMShEoQBOwCvTaDt =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('url')
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['thumbnail']['poster']=nYPfjeUXxLJrqFmMShEoQBOwCvTaDI
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['thumbnail']['thumb']=nYPfjeUXxLJrqFmMShEoQBOwCvTaiV
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['thumbnail']['clearlogo']=nYPfjeUXxLJrqFmMShEoQBOwCvTaDc
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['thumbnail']['icon']=nYPfjeUXxLJrqFmMShEoQBOwCvTaDk
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['thumbnail']['banner']=nYPfjeUXxLJrqFmMShEoQBOwCvTaDt
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['thumbnail']['fanart']=nYPfjeUXxLJrqFmMShEoQBOwCvTaiV
  else:
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+'/v2a/media/stream/info'
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies']['tving_uuid'].split('-')[0],'uuid':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetNoCache(1)),'wm':'Y',}
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDV=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if not('content' in nYPfjeUXxLJrqFmMShEoQBOwCvTaDV['body']):return{}
   nYPfjeUXxLJrqFmMShEoQBOwCvTalc=nYPfjeUXxLJrqFmMShEoQBOwCvTaDV['body']['content']['info']['movie']
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiW =nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('name').get('ko').strip()
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['title']=nYPfjeUXxLJrqFmMShEoQBOwCvTaiW
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiW +=u' (%s)'%(nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('product_year'))
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['title'] =nYPfjeUXxLJrqFmMShEoQBOwCvTaiW
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['mpaa'] =nYPfjeUXxLJrqFmMShEoQBOwCvTaIt.get(nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('grade_code'))
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['plot'] =nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('story').get('ko')
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['year'] =nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('product_year')
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['studio'] =nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('production')
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['duration']=nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('duration')
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['cast'] =nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('actor')
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['director']=nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('director')
   if nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('category1_name').get('ko')!='':
    nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['genre'].append(nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('category1_name').get('ko'))
   if nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('category2_name').get('ko')!='':
    nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['genre'].append(nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('category2_name').get('ko'))
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDs=nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('release_date'))
   if nYPfjeUXxLJrqFmMShEoQBOwCvTaDs!='0':nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[:4],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[4:6],nYPfjeUXxLJrqFmMShEoQBOwCvTaDs[6:])
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDI=''
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =''
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=''
   for nYPfjeUXxLJrqFmMShEoQBOwCvTaDA in nYPfjeUXxLJrqFmMShEoQBOwCvTalc.get('image'):
    if nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('code')=='CAIM2100':nYPfjeUXxLJrqFmMShEoQBOwCvTaDI =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('url')
    elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('code')=='CAIM0400':nYPfjeUXxLJrqFmMShEoQBOwCvTaiV =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('url')
    elif nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('code')=='CAIM1800':nYPfjeUXxLJrqFmMShEoQBOwCvTaDc=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.IMG_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTaDA.get('url')
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['thumbnail']['poster']=nYPfjeUXxLJrqFmMShEoQBOwCvTaDI
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['thumbnail']['thumb']=nYPfjeUXxLJrqFmMShEoQBOwCvTaDI 
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['thumbnail']['clearlogo']=nYPfjeUXxLJrqFmMShEoQBOwCvTaDc
   nYPfjeUXxLJrqFmMShEoQBOwCvTalI['saveinfo']['thumbnail']['fanart']=nYPfjeUXxLJrqFmMShEoQBOwCvTaiV
  return nYPfjeUXxLJrqFmMShEoQBOwCvTalI
 def GetEuroChannelList(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  nYPfjeUXxLJrqFmMShEoQBOwCvTakG=[]
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v2/operator/highlights'
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetNoCache(2))}
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if not('result' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']):return nYPfjeUXxLJrqFmMShEoQBOwCvTakG,nYPfjeUXxLJrqFmMShEoQBOwCvTaip
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']
   nYPfjeUXxLJrqFmMShEoQBOwCvTalk =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Get_Now_Datetime()
   nYPfjeUXxLJrqFmMShEoQBOwCvTalt=nYPfjeUXxLJrqFmMShEoQBOwCvTalk+datetime.timedelta(days=-1)
   nYPfjeUXxLJrqFmMShEoQBOwCvTalt=nYPfjeUXxLJrqFmMShEoQBOwCvTaub(nYPfjeUXxLJrqFmMShEoQBOwCvTalt.strftime('%Y%m%d'))
   for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK:
    nYPfjeUXxLJrqFmMShEoQBOwCvTali=nYPfjeUXxLJrqFmMShEoQBOwCvTaub(nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('content').get('banner_title2')[:8])
    if nYPfjeUXxLJrqFmMShEoQBOwCvTalt<=nYPfjeUXxLJrqFmMShEoQBOwCvTali:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'channel':nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('content').get('banner_sub_title3'),'title':nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('content').get('banner_title'),'subtitle':nYPfjeUXxLJrqFmMShEoQBOwCvTakH.get('content').get('banner_sub_title2'),}
     nYPfjeUXxLJrqFmMShEoQBOwCvTakG.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTakG
 def Make_DecryptKey(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,step,mediacode='000',timecode='000'):
  if step=='1':
   nYPfjeUXxLJrqFmMShEoQBOwCvTacR=nYPfjeUXxLJrqFmMShEoQBOwCvTauz('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   nYPfjeUXxLJrqFmMShEoQBOwCvTacN=nYPfjeUXxLJrqFmMShEoQBOwCvTauz('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   nYPfjeUXxLJrqFmMShEoQBOwCvTacR=nYPfjeUXxLJrqFmMShEoQBOwCvTauz('kss2lym0kdw1lks3','utf-8')
   nYPfjeUXxLJrqFmMShEoQBOwCvTacN=nYPfjeUXxLJrqFmMShEoQBOwCvTauz([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return nYPfjeUXxLJrqFmMShEoQBOwCvTacR,nYPfjeUXxLJrqFmMShEoQBOwCvTacN
 def DecryptPlaintext(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,nYPfjeUXxLJrqFmMShEoQBOwCvTacp,nYPfjeUXxLJrqFmMShEoQBOwCvTacg,nYPfjeUXxLJrqFmMShEoQBOwCvTacG):
  nYPfjeUXxLJrqFmMShEoQBOwCvTacd=AES.new(nYPfjeUXxLJrqFmMShEoQBOwCvTacg,AES.MODE_CBC,nYPfjeUXxLJrqFmMShEoQBOwCvTacG,)
  nYPfjeUXxLJrqFmMShEoQBOwCvTacs=Padding.unpad(nYPfjeUXxLJrqFmMShEoQBOwCvTacd.decrypt(base64.standard_b64decode(nYPfjeUXxLJrqFmMShEoQBOwCvTacp)),16)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTacs.decode('utf-8')
 def Decrypt_Url(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,nYPfjeUXxLJrqFmMShEoQBOwCvTacp,mediacode,nYPfjeUXxLJrqFmMShEoQBOwCvTatA):
  nYPfjeUXxLJrqFmMShEoQBOwCvTalD=''
  nYPfjeUXxLJrqFmMShEoQBOwCvTatl=''
  nYPfjeUXxLJrqFmMShEoQBOwCvTatu=''
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTacR,nYPfjeUXxLJrqFmMShEoQBOwCvTacN=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Make_DecryptKey('1',mediacode=mediacode,timecode=nYPfjeUXxLJrqFmMShEoQBOwCvTatA)
   nYPfjeUXxLJrqFmMShEoQBOwCvTalA=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.DecryptPlaintext(nYPfjeUXxLJrqFmMShEoQBOwCvTacp,nYPfjeUXxLJrqFmMShEoQBOwCvTacR,nYPfjeUXxLJrqFmMShEoQBOwCvTacN))
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(nYPfjeUXxLJrqFmMShEoQBOwCvTalA)
   nYPfjeUXxLJrqFmMShEoQBOwCvTalu =nYPfjeUXxLJrqFmMShEoQBOwCvTalA.get('url')
   nYPfjeUXxLJrqFmMShEoQBOwCvTatl =nYPfjeUXxLJrqFmMShEoQBOwCvTalA.get('watermark') if 'watermark' in nYPfjeUXxLJrqFmMShEoQBOwCvTalA else ''
   nYPfjeUXxLJrqFmMShEoQBOwCvTatu=nYPfjeUXxLJrqFmMShEoQBOwCvTalA.get('watermark_key')if 'watermark_key' in nYPfjeUXxLJrqFmMShEoQBOwCvTalA else ''
   nYPfjeUXxLJrqFmMShEoQBOwCvTacR,nYPfjeUXxLJrqFmMShEoQBOwCvTacN=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Make_DecryptKey('2',mediacode=mediacode,timecode=nYPfjeUXxLJrqFmMShEoQBOwCvTatA)
   nYPfjeUXxLJrqFmMShEoQBOwCvTalD=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.DecryptPlaintext(nYPfjeUXxLJrqFmMShEoQBOwCvTalu,nYPfjeUXxLJrqFmMShEoQBOwCvTacR,nYPfjeUXxLJrqFmMShEoQBOwCvTacN)
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTalD,nYPfjeUXxLJrqFmMShEoQBOwCvTatl,nYPfjeUXxLJrqFmMShEoQBOwCvTatu
 def Get_Apple_buildId(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  nYPfjeUXxLJrqFmMShEoQBOwCvTalR=''
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb ='https://www.tving.com/more/special/SP0071'
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTalN=r'"buildId":"(.*?)"'
   nYPfjeUXxLJrqFmMShEoQBOwCvTalR =re.compile(nYPfjeUXxLJrqFmMShEoQBOwCvTalN,re.DOTALL).findall(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)[0]
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTalR
 def Get_AppleGroup_List(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  nYPfjeUXxLJrqFmMShEoQBOwCvTalg=[]
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTalR=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Get_Apple_buildId()
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/_next/data/{}/ko/more/special/SP0071.json'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTalR)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'key':'SP0071'}
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.URL_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTaks,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDV=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if not('pageProps' in nYPfjeUXxLJrqFmMShEoQBOwCvTaDV):return nYPfjeUXxLJrqFmMShEoQBOwCvTalg
   nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTaDV['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
   for nYPfjeUXxLJrqFmMShEoQBOwCvTalG in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK:
    if nYPfjeUXxLJrqFmMShEoQBOwCvTalG['bandType']not in['VOD_BASIC']:continue
    nYPfjeUXxLJrqFmMShEoQBOwCvTald =re.findall('/band/\w+|/curation/\w+',nYPfjeUXxLJrqFmMShEoQBOwCvTalG['moreUrl'])[0]
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'bandName':nYPfjeUXxLJrqFmMShEoQBOwCvTalG['bandName'],'bandKey':nYPfjeUXxLJrqFmMShEoQBOwCvTald.split('/')[2],}
    nYPfjeUXxLJrqFmMShEoQBOwCvTalg.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTalg
 def Get_Band_VodList(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,bandKey,nextApiUrl='-'):
  nYPfjeUXxLJrqFmMShEoQBOwCvTalp =[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTals =''
  try:
   if bandKey.startswith('CR'):
    nYPfjeUXxLJrqFmMShEoQBOwCvTald='/curation/{}'.format(bandKey)
   else: 
    nYPfjeUXxLJrqFmMShEoQBOwCvTald='/band/{}'.format(bandKey)
   if nextApiUrl in[nYPfjeUXxLJrqFmMShEoQBOwCvTaud,'','-']:
    nYPfjeUXxLJrqFmMShEoQBOwCvTalR=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Get_Apple_buildId()
    nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/_next/data/{}/ko/more{}.json'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTalR,nYPfjeUXxLJrqFmMShEoQBOwCvTald)
    nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'key':bandKey}
    nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.URL_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
    nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTaks,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDV=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
    if not('pageProps' in nYPfjeUXxLJrqFmMShEoQBOwCvTaDV):return nYPfjeUXxLJrqFmMShEoQBOwCvTalp,nYPfjeUXxLJrqFmMShEoQBOwCvTals
    if bandKey.startswith('CR'):
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTaDV['pageProps']['dehydratedState']['queries'][0]['state']['data']['data']['bands'][0]
    else:
     nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTaDV['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['band']
   else:
    nYPfjeUXxLJrqFmMShEoQBOwCvTacb='{}{}{}'.format('https://gw.tving.com',nextApiUrl,'&screenCode=CSSD0100&osCode=CSOD0900')
    nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDV=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
    if not('data' in nYPfjeUXxLJrqFmMShEoQBOwCvTaDV):return nYPfjeUXxLJrqFmMShEoQBOwCvTalp,nYPfjeUXxLJrqFmMShEoQBOwCvTals
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTaDV['data']
   for nYPfjeUXxLJrqFmMShEoQBOwCvTalG in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK['items']:
    nYPfjeUXxLJrqFmMShEoQBOwCvTalK=nYPfjeUXxLJrqFmMShEoQBOwCvTalG['imageUrl']
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'program':nYPfjeUXxLJrqFmMShEoQBOwCvTalG['code'],'title':nYPfjeUXxLJrqFmMShEoQBOwCvTalG['title'],'thumbnail':{'poster':nYPfjeUXxLJrqFmMShEoQBOwCvTalK,'thumb':nYPfjeUXxLJrqFmMShEoQBOwCvTalK,'fanart':nYPfjeUXxLJrqFmMShEoQBOwCvTalK},}
    nYPfjeUXxLJrqFmMShEoQBOwCvTalp.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
   nYPfjeUXxLJrqFmMShEoQBOwCvTals=nYPfjeUXxLJrqFmMShEoQBOwCvTaiK.get('nextApiUrl')or ''
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTalp,nYPfjeUXxLJrqFmMShEoQBOwCvTals
 def Get_bandCode_RankList(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  nYPfjeUXxLJrqFmMShEoQBOwCvTalH=[]
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIW={'authorization':'Bearer {}'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN['token']),'access-token':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN['accessToken'],}
   nYPfjeUXxLJrqFmMShEoQBOwCvTaly=['https://gw.tving.com/bff/web/v3/home/main?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/drama?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/entertainment?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/movie?screenCode=CSSD0100&osCode=CSOD0900',]
   for nYPfjeUXxLJrqFmMShEoQBOwCvTalb in nYPfjeUXxLJrqFmMShEoQBOwCvTaly:
    nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTalb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaIW,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
    nYPfjeUXxLJrqFmMShEoQBOwCvTalW=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
    for nYPfjeUXxLJrqFmMShEoQBOwCvTalz in nYPfjeUXxLJrqFmMShEoQBOwCvTalW['data']['bands']:
     if nYPfjeUXxLJrqFmMShEoQBOwCvTalz['bandType']not in['VOD_BASIC_RANKING','VOD_BASIC_ORIGINAL']:
      continue
     if ':' in nYPfjeUXxLJrqFmMShEoQBOwCvTalz['bandCode']:
      nYPfjeUXxLJrqFmMShEoQBOwCvTalV =nYPfjeUXxLJrqFmMShEoQBOwCvTalz['bandCode'].split(':')[0]
      nYPfjeUXxLJrqFmMShEoQBOwCvTauI=nYPfjeUXxLJrqFmMShEoQBOwCvTalz['bandCode'].split(':')[1]
     else:
      nYPfjeUXxLJrqFmMShEoQBOwCvTalV =nYPfjeUXxLJrqFmMShEoQBOwCvTalz['bandCode']
      nYPfjeUXxLJrqFmMShEoQBOwCvTauI='TVING_ORIGINAL'
     nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'bandName':nYPfjeUXxLJrqFmMShEoQBOwCvTalz['bandName'],'bandCode':nYPfjeUXxLJrqFmMShEoQBOwCvTalV,'bandGroup':nYPfjeUXxLJrqFmMShEoQBOwCvTauI,}
     nYPfjeUXxLJrqFmMShEoQBOwCvTalH.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
   '''
   build_id = self.Get_Apple_buildId() # RawF3i7KTkfJ11pm2SOsS
   url   = 'https://www.tving.com/_next/data/{}/ko/more/special/SP0071.json?key=SP0071'.format(build_id )
   response = self.callRequestCookies('Get', url, payload=None, params=None, headers=None, cookies=None )
   res_json = json.loads(response.text )
   if not ('pageProps' in res_json): return bandCode_List
   info_list = res_json['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
   for iband in info_list:
    if iband['bandType'] != 'VOD_BASIC_RANKING' : continue
    temp_list = {'bandName' : iband['bandName'], 'bandCode' : iband['bandCode'], 'bandGroup' : 'TVING_APPLE_HOUR', }
    bandCode_List.append(temp_list )
   '''   
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTalH
 def Get_bandCode_GroupCode(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,GroupCode):
  nYPfjeUXxLJrqFmMShEoQBOwCvTalV=''
  try:
   if GroupCode=='TVING_APPLE_HOUR':
    nYPfjeUXxLJrqFmMShEoQBOwCvTalR=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Get_Apple_buildId()
    nYPfjeUXxLJrqFmMShEoQBOwCvTacb ='https://www.tving.com/_next/data/{}/ko/more/special/SP0071.json?key=SP0071'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTalR)
    nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
    nYPfjeUXxLJrqFmMShEoQBOwCvTaDV=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
    if not('pageProps' in nYPfjeUXxLJrqFmMShEoQBOwCvTaDV):return nYPfjeUXxLJrqFmMShEoQBOwCvTalV
    nYPfjeUXxLJrqFmMShEoQBOwCvTaiK=nYPfjeUXxLJrqFmMShEoQBOwCvTaDV['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
    for nYPfjeUXxLJrqFmMShEoQBOwCvTalz in nYPfjeUXxLJrqFmMShEoQBOwCvTaiK:
     if nYPfjeUXxLJrqFmMShEoQBOwCvTalz['bandType']!='VOD_BASIC_RANKING':continue
     return nYPfjeUXxLJrqFmMShEoQBOwCvTalz['bandCode']
   else:
    nYPfjeUXxLJrqFmMShEoQBOwCvTaIW={'authorization':'Bearer {}'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN['token']),'access-token':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN['accessToken'],}
    nYPfjeUXxLJrqFmMShEoQBOwCvTaly=['https://gw.tving.com/bff/web/v3/home/main?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/drama?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/entertainment?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/movie?screenCode=CSSD0100&osCode=CSOD0900',]
    for nYPfjeUXxLJrqFmMShEoQBOwCvTalb in nYPfjeUXxLJrqFmMShEoQBOwCvTaly:
     nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTalb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaIW,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
     nYPfjeUXxLJrqFmMShEoQBOwCvTalW=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
     for nYPfjeUXxLJrqFmMShEoQBOwCvTalz in nYPfjeUXxLJrqFmMShEoQBOwCvTalW['data']['bands']:
      if(GroupCode in nYPfjeUXxLJrqFmMShEoQBOwCvTalz['bandCode']or(GroupCode=='TVING_ORIGINAL' and nYPfjeUXxLJrqFmMShEoQBOwCvTalz['bandType']=='VOD_BASIC_ORIGINAL')):
       if ':' in nYPfjeUXxLJrqFmMShEoQBOwCvTalz['bandCode']:
        nYPfjeUXxLJrqFmMShEoQBOwCvTalV =nYPfjeUXxLJrqFmMShEoQBOwCvTalz['bandCode'].split(':')[0]
       else:
        nYPfjeUXxLJrqFmMShEoQBOwCvTalV =nYPfjeUXxLJrqFmMShEoQBOwCvTalz['bandCode']
       return nYPfjeUXxLJrqFmMShEoQBOwCvTalV
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTalV
 def Get_Apple_NowList(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  nYPfjeUXxLJrqFmMShEoQBOwCvTalp =[]
  nYPfjeUXxLJrqFmMShEoQBOwCvTals ='-'
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTalR=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Get_Apple_buildId()
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/_next/data/{}/ko/more/special/SP0071.json'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTalR)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'key':'SP0071'}
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.URL_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTaks,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaud)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDV=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaDV=nYPfjeUXxLJrqFmMShEoQBOwCvTaDV['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
   for nYPfjeUXxLJrqFmMShEoQBOwCvTauc in nYPfjeUXxLJrqFmMShEoQBOwCvTaDV:
    if nYPfjeUXxLJrqFmMShEoQBOwCvTauc['bandType']=='VOD_BASIC_RANKING':
     for nYPfjeUXxLJrqFmMShEoQBOwCvTalG in nYPfjeUXxLJrqFmMShEoQBOwCvTauc['items']:
      nYPfjeUXxLJrqFmMShEoQBOwCvTalK=nYPfjeUXxLJrqFmMShEoQBOwCvTalG['imageUrl']
      nYPfjeUXxLJrqFmMShEoQBOwCvTaDH={'program':nYPfjeUXxLJrqFmMShEoQBOwCvTalG['code'],'title':nYPfjeUXxLJrqFmMShEoQBOwCvTalG['title'],'thumbnail':{'poster':nYPfjeUXxLJrqFmMShEoQBOwCvTalK,'thumb':nYPfjeUXxLJrqFmMShEoQBOwCvTalK,'fanart':nYPfjeUXxLJrqFmMShEoQBOwCvTalK},}
      nYPfjeUXxLJrqFmMShEoQBOwCvTalp.append(nYPfjeUXxLJrqFmMShEoQBOwCvTaDH)
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
  return nYPfjeUXxLJrqFmMShEoQBOwCvTalp,nYPfjeUXxLJrqFmMShEoQBOwCvTals
 def Get_AccessToken(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA):
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.URL_DOMAIN
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.makeDefaultCookies()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIV.pop('accessToken')
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaIV)
   if nYPfjeUXxLJrqFmMShEoQBOwCvTacz.status_code!=200:
    return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
   nYPfjeUXxLJrqFmMShEoQBOwCvTalN=r'<script id="__NEXT_DATA__" type="application/json">\s*(.*?)\s*</script>'
   nYPfjeUXxLJrqFmMShEoQBOwCvTauk=re.compile(nYPfjeUXxLJrqFmMShEoQBOwCvTalN,re.DOTALL).findall(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)[0]
   nYPfjeUXxLJrqFmMShEoQBOwCvTaut =json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTauk)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN['token'] =nYPfjeUXxLJrqFmMShEoQBOwCvTaut.get('props').get('pageProps').get('userInfo').get('token')
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN['authToken'] =nYPfjeUXxLJrqFmMShEoQBOwCvTaut.get('props').get('pageProps').get('userInfo').get('authToken')
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN['accessToken']=nYPfjeUXxLJrqFmMShEoQBOwCvTacz.cookies['accessToken']
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN['refreshToken']=nYPfjeUXxLJrqFmMShEoQBOwCvTaut.get('props').get('pageProps').get('userInfo').get('refreshToken')
   nYPfjeUXxLJrqFmMShEoQBOwCvTalk =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Get_Now_Datetime()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaui=nYPfjeUXxLJrqFmMShEoQBOwCvTalk+datetime.timedelta(days=0)
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN['token_date']=nYPfjeUXxLJrqFmMShEoQBOwCvTaui.strftime('%Y%m%d')
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.JsonFile_Save(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN_FILENAME,nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV_TOKEN)
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
   return nYPfjeUXxLJrqFmMShEoQBOwCvTaup
  return nYPfjeUXxLJrqFmMShEoQBOwCvTauH
 def GetLiveURL_Test(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA,mediacode,sel_quality):
  nYPfjeUXxLJrqFmMShEoQBOwCvTakb ={'streaming_url':'','subtitleYn':nYPfjeUXxLJrqFmMShEoQBOwCvTaup,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  nYPfjeUXxLJrqFmMShEoQBOwCvTakd =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies']['tving_uuid'].split('-')[0] 
  nYPfjeUXxLJrqFmMShEoQBOwCvTakW =nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.TV['cookies']['tving_uuid'] 
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakz=nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetNoCache(1))
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v2/media/stream/info' 
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':nYPfjeUXxLJrqFmMShEoQBOwCvTakW,'deviceInfo':'PC','noCache':nYPfjeUXxLJrqFmMShEoQBOwCvTakz,}
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.makeDefaultCookies()
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Get',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaIV)
   if nYPfjeUXxLJrqFmMShEoQBOwCvTacz.status_code!=200:
    nYPfjeUXxLJrqFmMShEoQBOwCvTakb['error_msg']='First Step - {} error'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.status_code)
    return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
   nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']['code']=='060':
    for nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaIb in nYPfjeUXxLJrqFmMShEoQBOwCvTaIk.items():
     if nYPfjeUXxLJrqFmMShEoQBOwCvTaIb==sel_quality:
      nYPfjeUXxLJrqFmMShEoQBOwCvTatI=nYPfjeUXxLJrqFmMShEoQBOwCvTaIy
   elif nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']['code']!='000':
    nYPfjeUXxLJrqFmMShEoQBOwCvTakb['error_msg']=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']['message']
    return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
   else: 
    if not('stream' in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']):return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
    nYPfjeUXxLJrqFmMShEoQBOwCvTatc=[]
    for nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaIb in nYPfjeUXxLJrqFmMShEoQBOwCvTaIk.items():
     for nYPfjeUXxLJrqFmMShEoQBOwCvTakH in nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['stream']['quality']:
      if nYPfjeUXxLJrqFmMShEoQBOwCvTakH['active']=='Y' and nYPfjeUXxLJrqFmMShEoQBOwCvTakH['code']==nYPfjeUXxLJrqFmMShEoQBOwCvTaIy:
       nYPfjeUXxLJrqFmMShEoQBOwCvTatc.append({nYPfjeUXxLJrqFmMShEoQBOwCvTaIk.get(nYPfjeUXxLJrqFmMShEoQBOwCvTakH['code']):nYPfjeUXxLJrqFmMShEoQBOwCvTakH['code']})
    nYPfjeUXxLJrqFmMShEoQBOwCvTatI=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.CheckQuality(sel_quality,nYPfjeUXxLJrqFmMShEoQBOwCvTatc)
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakb['error_msg']='First Step - except error'
   return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
  try:
   nYPfjeUXxLJrqFmMShEoQBOwCvTakz=nYPfjeUXxLJrqFmMShEoQBOwCvTaus(nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetNoCache(1))
   nYPfjeUXxLJrqFmMShEoQBOwCvTakR ='/v3/media/stream/info'
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.GetDefaultParams()
   nYPfjeUXxLJrqFmMShEoQBOwCvTaks={'mediaCode':mediacode,'deviceId':nYPfjeUXxLJrqFmMShEoQBOwCvTakd,'uuid':nYPfjeUXxLJrqFmMShEoQBOwCvTakW,'deviceInfo':'PC_Chrome','streamCode':nYPfjeUXxLJrqFmMShEoQBOwCvTatI,'noCache':nYPfjeUXxLJrqFmMShEoQBOwCvTakz,'callingFrom':'HTML5','model':nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   nYPfjeUXxLJrqFmMShEoQBOwCvTakV.update(nYPfjeUXxLJrqFmMShEoQBOwCvTaks)
   nYPfjeUXxLJrqFmMShEoQBOwCvTacb=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.API_DOMAIN+nYPfjeUXxLJrqFmMShEoQBOwCvTakR
   nYPfjeUXxLJrqFmMShEoQBOwCvTaIV=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.makeDefaultCookies()
   nYPfjeUXxLJrqFmMShEoQBOwCvTacz=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.callRequestCookies('Post',nYPfjeUXxLJrqFmMShEoQBOwCvTacb,payload=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,params=nYPfjeUXxLJrqFmMShEoQBOwCvTakV,headers=nYPfjeUXxLJrqFmMShEoQBOwCvTaud,cookies=nYPfjeUXxLJrqFmMShEoQBOwCvTaIV,redirects=nYPfjeUXxLJrqFmMShEoQBOwCvTauH)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakK=json.loads(nYPfjeUXxLJrqFmMShEoQBOwCvTacz.text)
   if nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']['code']!='000':
    nYPfjeUXxLJrqFmMShEoQBOwCvTakb['error_msg']=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['result']['message']
    return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
   nYPfjeUXxLJrqFmMShEoQBOwCvTatk=nYPfjeUXxLJrqFmMShEoQBOwCvTakK['body']['stream']
   if nYPfjeUXxLJrqFmMShEoQBOwCvTatk['drm_yn']=='Y':
    nYPfjeUXxLJrqFmMShEoQBOwCvTati=nYPfjeUXxLJrqFmMShEoQBOwCvTatk['playback']['drm']['widevine']
    for nYPfjeUXxLJrqFmMShEoQBOwCvTatD in nYPfjeUXxLJrqFmMShEoQBOwCvTatk['playback']['drm']['license']['drm_license_data']:
     if nYPfjeUXxLJrqFmMShEoQBOwCvTatD['drm_type']=='Widevine':
      nYPfjeUXxLJrqFmMShEoQBOwCvTakb['drm_server_url'] =nYPfjeUXxLJrqFmMShEoQBOwCvTatD['drm_server_url']
      nYPfjeUXxLJrqFmMShEoQBOwCvTakb['drm_header_key'] =nYPfjeUXxLJrqFmMShEoQBOwCvTatD['drm_header_key']
      nYPfjeUXxLJrqFmMShEoQBOwCvTakb['drm_header_value']=nYPfjeUXxLJrqFmMShEoQBOwCvTatD['drm_header_value']
      break
   else:
    nYPfjeUXxLJrqFmMShEoQBOwCvTati=nYPfjeUXxLJrqFmMShEoQBOwCvTatk['playback']['non_drm']
  except nYPfjeUXxLJrqFmMShEoQBOwCvTauV as exception:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauN(exception)
   nYPfjeUXxLJrqFmMShEoQBOwCvTakb['error_msg']='Second Step - except error'
   return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
  nYPfjeUXxLJrqFmMShEoQBOwCvTatA=nYPfjeUXxLJrqFmMShEoQBOwCvTakz
  nYPfjeUXxLJrqFmMShEoQBOwCvTati=nYPfjeUXxLJrqFmMShEoQBOwCvTati.split('|')[1]
  nYPfjeUXxLJrqFmMShEoQBOwCvTati,nYPfjeUXxLJrqFmMShEoQBOwCvTatl,nYPfjeUXxLJrqFmMShEoQBOwCvTatu=nYPfjeUXxLJrqFmMShEoQBOwCvTaIA.Decrypt_Url(nYPfjeUXxLJrqFmMShEoQBOwCvTati,mediacode,nYPfjeUXxLJrqFmMShEoQBOwCvTatA)
  nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url']=nYPfjeUXxLJrqFmMShEoQBOwCvTati
  nYPfjeUXxLJrqFmMShEoQBOwCvTauD =nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url'].find('Policy=')
  if nYPfjeUXxLJrqFmMShEoQBOwCvTauD!=-1:
   nYPfjeUXxLJrqFmMShEoQBOwCvTauA =nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url'].split('?')[0]
   nYPfjeUXxLJrqFmMShEoQBOwCvTaul=nYPfjeUXxLJrqFmMShEoQBOwCvTaRI(urllib.parse.parse_qsl(urllib.parse.urlsplit(nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url']).query))
   nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url']='{}&CloudFront-Policy={}'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url'],nYPfjeUXxLJrqFmMShEoQBOwCvTaul['Policy'])
   nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url']='{}&CloudFront-Signature={}'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url'],nYPfjeUXxLJrqFmMShEoQBOwCvTaul['Signature'])
   nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url'],nYPfjeUXxLJrqFmMShEoQBOwCvTaul['Key-Pair-Id'])
  nYPfjeUXxLJrqFmMShEoQBOwCvTauR=['_tving_token','accessToken','authToken',]
  for nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaIb in nYPfjeUXxLJrqFmMShEoQBOwCvTaIV.items():
   if nYPfjeUXxLJrqFmMShEoQBOwCvTaIy in nYPfjeUXxLJrqFmMShEoQBOwCvTauR:
    nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url']='{}&{}={}'.format(nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url'],nYPfjeUXxLJrqFmMShEoQBOwCvTaIy,nYPfjeUXxLJrqFmMShEoQBOwCvTaIb)
  nYPfjeUXxLJrqFmMShEoQBOwCvTauN(nYPfjeUXxLJrqFmMShEoQBOwCvTakb['streaming_url'])
  return nYPfjeUXxLJrqFmMShEoQBOwCvTakb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
