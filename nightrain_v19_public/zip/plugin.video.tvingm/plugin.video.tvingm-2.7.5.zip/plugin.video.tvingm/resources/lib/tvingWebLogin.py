# -*- coding: utf-8 -*-
import base64
import json
import os
import datetime
import sys

from selenium import webdriver
#from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from Crypto.Cipher    import PKCS1_OAEP, AES
from Crypto.Util      import Padding


class SeleLogin( object ):
	HttpDriver = None
	USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'

	def __init__( self ):

		chrome_options = webdriver.ChromeOptions()
		#chrome_options.add_experimental_option('androidPackage', 'com.android.chrome')
		chrome_options.add_argument( 'user_agent=' + self.USER_AGENT )
		chrome_options.add_argument( '--incognito' )        # 시크릿모드
		chrome_options.add_argument( '--start-maximized' )  # 브라우저 최대화상태 실행
		#chrome_options.add_argument( '--blink-settings=imagesEnabled=false' )  # 이미지로딩x

		#chrome_options.add_argument( '--window-size=1920,1024' )
		#chrome_options.add_argument( '--no-sandbox' )
		#chrome_options.add_argument( '--headless' )         # 브라우저 창 미표시  ######

		# 업그레이드 필요 (pip install selenium --upgrade)
		self.HttpDriver = webdriver.Chrome( options=chrome_options )
		self.HttpDriver.implicitly_wait(8) # 한번만


	def driver_close( self ):
		self.HttpDriver.close()
		

	def Load_LoginPage( self ):
		url_login = 'https://www.tving.com/account/login?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'

		self.HttpDriver.get(url_login)
		print( self.HttpDriver.title ) ###
		#return True

		try:
			# 마이메뉴 기다리기
			WebDriverWait(self.HttpDriver, 120).until( EC.presence_of_element_located ( ( By.CSS_SELECTOR, '#__next > header > aside > div > div.menu_my > div > picture > img' ) ) )
			print( self.HttpDriver.title ) ###
		except:
			return False

		return True


	def get_SeleniumCookies( self ):
		cookies = {}

		for i_cookie in self.HttpDriver.get_cookies():
			if 'expiry' not in i_cookie  or i_cookie.get('httpOnly') == True:
				cookies[ i_cookie['name'] ] = i_cookie['value']
	
		if 'authToken' not in cookies:
			for i_cookie in self.HttpDriver.get_cookies():
				if i_cookie['value'] not in ['', None]:
					cookies[ i_cookie['name'] ] = i_cookie['value']


		#print( cookies )
		return cookies


	def save_cookiesFile( self ):
		login_info = {}
		try:
			id = base64.standard_b64encode( 'xxxxx'.encode() ).decode('utf-8')
			login_info = {
							'account' : {
										'tvid'        : id,  # xxxxx eHh4eHg=
										'tvpw'        : id,  # xxxxx eHh4eHg=
										'tvtype'      : '0',
										'tvpf'        : 0,
										'token_limit' : self.Get_Now_Datetime(365).strftime('%Y%m%d'), #"20241006"
							},
							'cookies' : self.get_SeleniumCookies(),
			}
		except:
			return {}

		return login_info

	def Make_DecryptKey( self ):
		enckey = bytes( 'kss2lym0kdw1lks3' , 'utf-8')
		vector = bytes( '6yhlJ4WF9ZIj6I8n' , 'utf-8')
		return enckey, vector


	def EncryptCiphertext( self, plaintext ):
		encryption_key, init_vector = self.Make_DecryptKey()
		cipher = AES.new(
						encryption_key,
						AES.MODE_CBC,
						init_vector,
		)
		ciphertext = cipher.encrypt( Padding.pad(plaintext.encode('utf-8'), 16) ) 
		return base64.standard_b64encode( ciphertext ).decode('utf-8')


	def DecryptPlaintext( self, ciphertext ):
		encryption_key, init_vector = self.Make_DecryptKey()
		cipher = AES.new(
						encryption_key,
						AES.MODE_CBC,
						init_vector,
		)
		plaintext = Padding.unpad( cipher.decrypt( base64.standard_b64decode( ciphertext ) ) ,16)
		return plaintext.decode('utf-8')


	def TextFile_Save( self, filename, resText ):
		if filename == '': return False

		print( filename )
		fp = open(filename, 'w', -1, 'utf-8')
		fp.write(resText)
		fp.close()


	def Get_Now_Datetime( self, delta=0 ):
		nowTime  = datetime.datetime.now( datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul') )
		if delta != 0:
			nowTime = nowTime + datetime.timedelta( days=delta )
		return nowTime

	def cookies_save( self, cookies ):
		json_text = json.dumps(cookies, separators=(',', ':'))
		json_text = loginObj.EncryptCiphertext(json_text)

		nowTime    = self.Get_Now_Datetime()
		nowTimeStr = nowTime.strftime('%Y%m%d-%H%M%S')			

		if getattr(sys, 'frozen', False):
			bundle_dir = os.getcwd()
		else:
			bundle_dir = os.path.dirname(os.path.abspath(__file__))


		filename = '{}\\tvinginfo-{}.twc'.format( bundle_dir , nowTimeStr)
		loginObj.TextFile_Save( filename, json_text )



if __name__ == "__main__":
	##############
	sMode = True
	##############

	##############
	if sMode :
		# 드라이버 loading
		loginObj = SeleLogin()
	##############

	login_result = loginObj.Load_LoginPage()

	#time.sleep(20)

	if login_result:
		#print( loginObj.get_SeleniumCookies() )
		login_info = loginObj.save_cookiesFile()

		if login_info != {} :
			print( login_info )
			loginObj.cookies_save( login_info )

			print( 'Ok~' )
		else:
			print( 'save error !!' )

	else:
		print( 'login error !!' )

	##############
	if sMode :
		loginObj.driver_close()
	##############

	# 단일파일(.exe) 생성
	#pyinstaller -F tvingWebLogin.py