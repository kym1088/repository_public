__author__="NightRain"
axpYhbyCRQjBMPtWKfeEwnDTrilUSs=print
axpYhbyCRQjBMPtWKfeEwnDTrilUSJ=ImportError
axpYhbyCRQjBMPtWKfeEwnDTrilUSN=object
axpYhbyCRQjBMPtWKfeEwnDTrilUSk=None
axpYhbyCRQjBMPtWKfeEwnDTrilUSO=False
axpYhbyCRQjBMPtWKfeEwnDTrilUSo=open
axpYhbyCRQjBMPtWKfeEwnDTrilUSV=True
axpYhbyCRQjBMPtWKfeEwnDTrilUSq=int
axpYhbyCRQjBMPtWKfeEwnDTrilUSc=range
axpYhbyCRQjBMPtWKfeEwnDTrilUSG=Exception
axpYhbyCRQjBMPtWKfeEwnDTrilUSX=len
axpYhbyCRQjBMPtWKfeEwnDTrilUSI=str
axpYhbyCRQjBMPtWKfeEwnDTrilUSz=list
axpYhbyCRQjBMPtWKfeEwnDTrilUHA=bytes
axpYhbyCRQjBMPtWKfeEwnDTrilUHm=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 axpYhbyCRQjBMPtWKfeEwnDTrilUSs('Cryptodome')
except axpYhbyCRQjBMPtWKfeEwnDTrilUSJ:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 axpYhbyCRQjBMPtWKfeEwnDTrilUSs('Crypto')
axpYhbyCRQjBMPtWKfeEwnDTrilUAg={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
axpYhbyCRQjBMPtWKfeEwnDTrilUAd ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class axpYhbyCRQjBMPtWKfeEwnDTrilUAm(axpYhbyCRQjBMPtWKfeEwnDTrilUSN):
 def __init__(axpYhbyCRQjBMPtWKfeEwnDTrilUAL):
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.NETWORKCODE ='CSND0900'
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.OSCODE ='CSOD0900' 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TELECODE ='CSCD0900'
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.SCREENCODE ='CSSD0100'
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.SCREENCODE_ATV ='CSSD1300' 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.LIVE_LIMIT =20 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.VOD_LIMIT =24 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.EPISODE_LIMIT =30 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.SEARCH_LIMIT =30 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.MOVIE_LIMIT =24 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN ='https://api.tving.com'
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN ='https://image.tving.com'
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.SEARCH_DOMAIN ='https://search.tving.com'
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.LOGIN_DOMAIN ='https://user.tving.com'
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.URL_DOMAIN ='https://www.tving.com'
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.MOVIE_LITE =['2610061','2610161','261062']
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.DEFAULT_HEADER ={'user-agent':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.USER_AGENT}
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV_SESSION_COOKIES1=''
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV_SESSION_COOKIES2=''
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV ={}
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.Init_TV_Total()
 def Init_TV_Total(axpYhbyCRQjBMPtWKfeEwnDTrilUAL):
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N',},}
 def callRequestCookies(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,jobtype,axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,redirects=axpYhbyCRQjBMPtWKfeEwnDTrilUSO):
  axpYhbyCRQjBMPtWKfeEwnDTrilUAS=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.DEFAULT_HEADER
  if headers:axpYhbyCRQjBMPtWKfeEwnDTrilUAS.update(headers)
  if jobtype=='Get':
   axpYhbyCRQjBMPtWKfeEwnDTrilUAH=requests.get(axpYhbyCRQjBMPtWKfeEwnDTrilUmz,params=params,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUAS,cookies=cookies,allow_redirects=redirects)
  else:
   axpYhbyCRQjBMPtWKfeEwnDTrilUAH=requests.post(axpYhbyCRQjBMPtWKfeEwnDTrilUmz,data=payload,params=params,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUAS,cookies=cookies,allow_redirects=redirects)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUAH
 def JsonFile_Save(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,filename,axpYhbyCRQjBMPtWKfeEwnDTrilUAu):
  if filename=='':return axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  try:
   fp=axpYhbyCRQjBMPtWKfeEwnDTrilUSo(filename,'w',-1,'utf-8')
   json.dump(axpYhbyCRQjBMPtWKfeEwnDTrilUAu,fp,indent=4,ensure_ascii=axpYhbyCRQjBMPtWKfeEwnDTrilUSO)
   fp.close()
  except:
   return axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  return axpYhbyCRQjBMPtWKfeEwnDTrilUSV
 def JsonFile_Load(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,filename):
  if filename=='':return{}
  try:
   fp=axpYhbyCRQjBMPtWKfeEwnDTrilUSo(filename,'r',-1,'utf-8')
   axpYhbyCRQjBMPtWKfeEwnDTrilUAv=json.load(fp)
   fp.close()
  except:
   return{}
  return axpYhbyCRQjBMPtWKfeEwnDTrilUAv
 def Save_session_acount(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,axpYhbyCRQjBMPtWKfeEwnDTrilUAs,axpYhbyCRQjBMPtWKfeEwnDTrilUAJ,axpYhbyCRQjBMPtWKfeEwnDTrilUAN,axpYhbyCRQjBMPtWKfeEwnDTrilUAk):
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['account']['tvid'] =base64.standard_b64encode(axpYhbyCRQjBMPtWKfeEwnDTrilUAs.encode()).decode('utf-8')
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['account']['tvpw'] =base64.standard_b64encode(axpYhbyCRQjBMPtWKfeEwnDTrilUAJ.encode()).decode('utf-8')
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['account']['tvtype']=axpYhbyCRQjBMPtWKfeEwnDTrilUAN 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['account']['tvpf'] =axpYhbyCRQjBMPtWKfeEwnDTrilUAk 
 def Load_session_acount(axpYhbyCRQjBMPtWKfeEwnDTrilUAL):
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUAs =base64.standard_b64decode(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['account']['tvid']).decode('utf-8')
   axpYhbyCRQjBMPtWKfeEwnDTrilUAJ =base64.standard_b64decode(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['account']['tvpw']).decode('utf-8')
   axpYhbyCRQjBMPtWKfeEwnDTrilUAN=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['account']['tvtype']
   axpYhbyCRQjBMPtWKfeEwnDTrilUAk =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return axpYhbyCRQjBMPtWKfeEwnDTrilUAs,axpYhbyCRQjBMPtWKfeEwnDTrilUAJ,axpYhbyCRQjBMPtWKfeEwnDTrilUAN,axpYhbyCRQjBMPtWKfeEwnDTrilUAk
 def makeDefaultCookies(axpYhbyCRQjBMPtWKfeEwnDTrilUAL):
  axpYhbyCRQjBMPtWKfeEwnDTrilUAO={}
  if axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_token']:axpYhbyCRQjBMPtWKfeEwnDTrilUAO['_tving_token']=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_token']
  if axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_userinfo']:axpYhbyCRQjBMPtWKfeEwnDTrilUAO['POC_USERINFO']=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_userinfo']
  if axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_maintoken']:axpYhbyCRQjBMPtWKfeEwnDTrilUAO[axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GLOBAL_COOKIENM['tv_maintoken']]=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_maintoken']
  if axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_cookiekey']:axpYhbyCRQjBMPtWKfeEwnDTrilUAO[axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GLOBAL_COOKIENM['tv_cookiekey']]=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_cookiekey']
  if axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_lockkey']:axpYhbyCRQjBMPtWKfeEwnDTrilUAO[axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GLOBAL_COOKIENM['tv_lockkey']]=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_lockkey']
  return axpYhbyCRQjBMPtWKfeEwnDTrilUAO
 def makeCookiesStr(axpYhbyCRQjBMPtWKfeEwnDTrilUAL):
  return '_tving_token='+axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_token']+';'+ 'POC_USERINFO='+axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_userinfo']+';'+ axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GLOBAL_COOKIENM['tv_maintoken']+'='+axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_maintoken']+';'+ axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GLOBAL_COOKIENM['tv_cookiekey']+'='+axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_cookiekey']+';'+ axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GLOBAL_COOKIENM['tv_lockkey']+'='+axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_lockkey']
 def getDeviceStr(axpYhbyCRQjBMPtWKfeEwnDTrilUAL):
  axpYhbyCRQjBMPtWKfeEwnDTrilUAo=[]
  axpYhbyCRQjBMPtWKfeEwnDTrilUAo.append('Windows') 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAo.append('Chrome') 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAo.append('ko-KR') 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAo.append('undefined') 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAo.append('24') 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAo.append(u'한국 표준시')
  axpYhbyCRQjBMPtWKfeEwnDTrilUAo.append('undefined') 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAo.append('undefined') 
  axpYhbyCRQjBMPtWKfeEwnDTrilUAo.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  axpYhbyCRQjBMPtWKfeEwnDTrilUAV=''
  for axpYhbyCRQjBMPtWKfeEwnDTrilUAq in axpYhbyCRQjBMPtWKfeEwnDTrilUAo:
   axpYhbyCRQjBMPtWKfeEwnDTrilUAV+=axpYhbyCRQjBMPtWKfeEwnDTrilUAq+'|'
  return axpYhbyCRQjBMPtWKfeEwnDTrilUAV
 def GetDefaultParams(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,uhd=axpYhbyCRQjBMPtWKfeEwnDTrilUSO):
  if uhd==axpYhbyCRQjBMPtWKfeEwnDTrilUSO:
   axpYhbyCRQjBMPtWKfeEwnDTrilUAc={'apiKey':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.APIKEY,'networkCode':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.NETWORKCODE,'osCode':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.OSCODE,'teleCode':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TELECODE,'screenCode':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.SCREENCODE,}
  else:
   axpYhbyCRQjBMPtWKfeEwnDTrilUAc={'apiKey':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.APIKEY_ATV,'networkCode':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.NETWORKCODE,'osCode':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.OSCODE,'teleCode':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TELECODE,'screenCode':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.SCREENCODE_ATV,}
  return axpYhbyCRQjBMPtWKfeEwnDTrilUAc
 def GetNoCache(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,timetype=1):
  if timetype==1:
   return axpYhbyCRQjBMPtWKfeEwnDTrilUSq(time.time())
  else:
   return axpYhbyCRQjBMPtWKfeEwnDTrilUSq(time.time()*1000)
 def GetUniqueid(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,hValue=axpYhbyCRQjBMPtWKfeEwnDTrilUSk):
  if hValue:
   import hashlib
   axpYhbyCRQjBMPtWKfeEwnDTrilUAG=hashlib.sha1()
   axpYhbyCRQjBMPtWKfeEwnDTrilUAG.update(hValue.encode())
   axpYhbyCRQjBMPtWKfeEwnDTrilUAX=axpYhbyCRQjBMPtWKfeEwnDTrilUAG.hexdigest()[:8]
  else:
   axpYhbyCRQjBMPtWKfeEwnDTrilUAI=[0 for i in axpYhbyCRQjBMPtWKfeEwnDTrilUSc(256)]
   for i in axpYhbyCRQjBMPtWKfeEwnDTrilUSc(256):
    axpYhbyCRQjBMPtWKfeEwnDTrilUAI[i]='%02x'%(i)
   axpYhbyCRQjBMPtWKfeEwnDTrilUAz=axpYhbyCRQjBMPtWKfeEwnDTrilUSq(4294967295*random.random())|0
   axpYhbyCRQjBMPtWKfeEwnDTrilUAX=axpYhbyCRQjBMPtWKfeEwnDTrilUAI[255&axpYhbyCRQjBMPtWKfeEwnDTrilUAz]+axpYhbyCRQjBMPtWKfeEwnDTrilUAI[axpYhbyCRQjBMPtWKfeEwnDTrilUAz>>8&255]+axpYhbyCRQjBMPtWKfeEwnDTrilUAI[axpYhbyCRQjBMPtWKfeEwnDTrilUAz>>16&255]+axpYhbyCRQjBMPtWKfeEwnDTrilUAI[axpYhbyCRQjBMPtWKfeEwnDTrilUAz>>24&255]
  return axpYhbyCRQjBMPtWKfeEwnDTrilUAX
 def GetCredential(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,user_id,user_pw,login_type,user_pf):
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmA=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   axpYhbyCRQjBMPtWKfeEwnDTrilUmg={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Post',axpYhbyCRQjBMPtWKfeEwnDTrilUmA,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUmg,params=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk)
   for axpYhbyCRQjBMPtWKfeEwnDTrilUmL in axpYhbyCRQjBMPtWKfeEwnDTrilUmd.cookies:
    if axpYhbyCRQjBMPtWKfeEwnDTrilUmL.name=='_tving_token':
     axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_token']=axpYhbyCRQjBMPtWKfeEwnDTrilUmL.value
    elif axpYhbyCRQjBMPtWKfeEwnDTrilUmL.name=='POC_USERINFO':
     axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_userinfo']=axpYhbyCRQjBMPtWKfeEwnDTrilUmL.value
   if not axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_token']:
    axpYhbyCRQjBMPtWKfeEwnDTrilUAL.Init_TV_Total()
    return axpYhbyCRQjBMPtWKfeEwnDTrilUSO
   axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_maintoken']=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_token']
   if axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetProfileToken(user_pf)==axpYhbyCRQjBMPtWKfeEwnDTrilUSO:
    axpYhbyCRQjBMPtWKfeEwnDTrilUAL.Init_TV_Total()
    return axpYhbyCRQjBMPtWKfeEwnDTrilUSO
   axpYhbyCRQjBMPtWKfeEwnDTrilUmS =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDeviceList()
   if axpYhbyCRQjBMPtWKfeEwnDTrilUmS not in['','-']:
    axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_uuid']=axpYhbyCRQjBMPtWKfeEwnDTrilUmS+'-'+axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetUniqueid(axpYhbyCRQjBMPtWKfeEwnDTrilUmS)
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
   axpYhbyCRQjBMPtWKfeEwnDTrilUAL.Init_TV_Total()
   return axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  return axpYhbyCRQjBMPtWKfeEwnDTrilUSV
 def GetProfileToken(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,user_pf):
  axpYhbyCRQjBMPtWKfeEwnDTrilUmH=[]
  axpYhbyCRQjBMPtWKfeEwnDTrilUmu =''
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   axpYhbyCRQjBMPtWKfeEwnDTrilUAO=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.makeDefaultCookies()
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmF,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUAO)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmH =re.findall('data-profile-no="\d+"',axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   for i in axpYhbyCRQjBMPtWKfeEwnDTrilUSc(axpYhbyCRQjBMPtWKfeEwnDTrilUSX(axpYhbyCRQjBMPtWKfeEwnDTrilUmH)):
    axpYhbyCRQjBMPtWKfeEwnDTrilUmv =axpYhbyCRQjBMPtWKfeEwnDTrilUmH[i].replace('data-profile-no=','').replace('"','')
    axpYhbyCRQjBMPtWKfeEwnDTrilUmH[i]=axpYhbyCRQjBMPtWKfeEwnDTrilUmv
   axpYhbyCRQjBMPtWKfeEwnDTrilUmu=axpYhbyCRQjBMPtWKfeEwnDTrilUmH[user_pf]
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
   axpYhbyCRQjBMPtWKfeEwnDTrilUAL.Init_TV_Total()
   return axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   axpYhbyCRQjBMPtWKfeEwnDTrilUAO=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.makeDefaultCookies()
   axpYhbyCRQjBMPtWKfeEwnDTrilUmg={'profileNo':axpYhbyCRQjBMPtWKfeEwnDTrilUmu}
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Post',axpYhbyCRQjBMPtWKfeEwnDTrilUmF,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUmg,params=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUAO)
   for axpYhbyCRQjBMPtWKfeEwnDTrilUmL in axpYhbyCRQjBMPtWKfeEwnDTrilUmd.cookies:
    if axpYhbyCRQjBMPtWKfeEwnDTrilUmL.name=='_tving_token':
     axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_token']=axpYhbyCRQjBMPtWKfeEwnDTrilUmL.value
    elif axpYhbyCRQjBMPtWKfeEwnDTrilUmL.name==axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GLOBAL_COOKIENM['tv_cookiekey']:
     axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_cookiekey']=axpYhbyCRQjBMPtWKfeEwnDTrilUmL.value
    elif axpYhbyCRQjBMPtWKfeEwnDTrilUmL.name==axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GLOBAL_COOKIENM['tv_lockkey']:
     axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_lockkey']=axpYhbyCRQjBMPtWKfeEwnDTrilUmL.value
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
   axpYhbyCRQjBMPtWKfeEwnDTrilUAL.Init_TV_Total()
   return axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  return axpYhbyCRQjBMPtWKfeEwnDTrilUSV
 def GetDeviceList(axpYhbyCRQjBMPtWKfeEwnDTrilUAL):
  axpYhbyCRQjBMPtWKfeEwnDTrilUms=[]
  axpYhbyCRQjBMPtWKfeEwnDTrilUmJ='-'
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v1/user/device/list'
   axpYhbyCRQjBMPtWKfeEwnDTrilUmN=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmF
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   axpYhbyCRQjBMPtWKfeEwnDTrilUAO=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.makeDefaultCookies()
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmN,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmk,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUAO)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmO=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   axpYhbyCRQjBMPtWKfeEwnDTrilUms=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']
   for axpYhbyCRQjBMPtWKfeEwnDTrilUmo in axpYhbyCRQjBMPtWKfeEwnDTrilUms:
    if axpYhbyCRQjBMPtWKfeEwnDTrilUmo['model']=='PC' or axpYhbyCRQjBMPtWKfeEwnDTrilUmo['model']=='PC-Chrome':
     axpYhbyCRQjBMPtWKfeEwnDTrilUmJ=axpYhbyCRQjBMPtWKfeEwnDTrilUmo['uuid']
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUmJ
 def Get_Now_Datetime(axpYhbyCRQjBMPtWKfeEwnDTrilUAL):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,mediacode,sel_quality,stype,pvrmode='-',optUHD=axpYhbyCRQjBMPtWKfeEwnDTrilUSO):
  axpYhbyCRQjBMPtWKfeEwnDTrilUmq ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','subtitleYn':axpYhbyCRQjBMPtWKfeEwnDTrilUSO,'error_msg':'',}
  axpYhbyCRQjBMPtWKfeEwnDTrilUmJ =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_uuid'].split('-')[0] 
  axpYhbyCRQjBMPtWKfeEwnDTrilUmc =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_uuid'] 
  axpYhbyCRQjBMPtWKfeEwnDTrilUmG=axpYhbyCRQjBMPtWKfeEwnDTrilUSO 
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmX=axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetNoCache(1))
   if stype!='tvingtv':
    axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v2/media/stream/info' 
    axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams()
    axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':axpYhbyCRQjBMPtWKfeEwnDTrilUmc,'deviceInfo':'PC','noCache':axpYhbyCRQjBMPtWKfeEwnDTrilUmX,}
    axpYhbyCRQjBMPtWKfeEwnDTrilUmI.update(axpYhbyCRQjBMPtWKfeEwnDTrilUmk)
    axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmF
    axpYhbyCRQjBMPtWKfeEwnDTrilUAO=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.makeDefaultCookies()
    axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmI,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUAO)
    if axpYhbyCRQjBMPtWKfeEwnDTrilUmd.status_code!=200:
     axpYhbyCRQjBMPtWKfeEwnDTrilUmq['error_msg']='First Step - {} error'.format(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.status_code)
     return axpYhbyCRQjBMPtWKfeEwnDTrilUmq
    axpYhbyCRQjBMPtWKfeEwnDTrilUmO=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
    if axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['result']['code']=='060':
     for axpYhbyCRQjBMPtWKfeEwnDTrilUgA,axpYhbyCRQjBMPtWKfeEwnDTrilUgN in axpYhbyCRQjBMPtWKfeEwnDTrilUAg.items():
      if axpYhbyCRQjBMPtWKfeEwnDTrilUgN==sel_quality:
       axpYhbyCRQjBMPtWKfeEwnDTrilUgm=axpYhbyCRQjBMPtWKfeEwnDTrilUgA
    elif axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['result']['code']!='000':
     axpYhbyCRQjBMPtWKfeEwnDTrilUmq['error_msg']=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['result']['message']
     return axpYhbyCRQjBMPtWKfeEwnDTrilUmq
    else: 
     if not('stream' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']):return axpYhbyCRQjBMPtWKfeEwnDTrilUmq
     axpYhbyCRQjBMPtWKfeEwnDTrilUgd=[]
     for axpYhbyCRQjBMPtWKfeEwnDTrilUgA,axpYhbyCRQjBMPtWKfeEwnDTrilUgN in axpYhbyCRQjBMPtWKfeEwnDTrilUAg.items():
      for axpYhbyCRQjBMPtWKfeEwnDTrilUmo in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['stream']['quality']:
       if axpYhbyCRQjBMPtWKfeEwnDTrilUmo['active']=='Y' and axpYhbyCRQjBMPtWKfeEwnDTrilUmo['code']==axpYhbyCRQjBMPtWKfeEwnDTrilUgA:
        axpYhbyCRQjBMPtWKfeEwnDTrilUgd.append({axpYhbyCRQjBMPtWKfeEwnDTrilUAg.get(axpYhbyCRQjBMPtWKfeEwnDTrilUmo['code']):axpYhbyCRQjBMPtWKfeEwnDTrilUmo['code']})
     axpYhbyCRQjBMPtWKfeEwnDTrilUgm=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.CheckQuality(sel_quality,axpYhbyCRQjBMPtWKfeEwnDTrilUgd)
     try:
      if optUHD==axpYhbyCRQjBMPtWKfeEwnDTrilUSV and axpYhbyCRQjBMPtWKfeEwnDTrilUgm=='stream50' and 'stream_support_info' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['content']['info']:
       if axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['content']['info']['stream_support_info']!=axpYhbyCRQjBMPtWKfeEwnDTrilUSk:
        if 'stream70' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['content']['info']['stream_support_info']:
         axpYhbyCRQjBMPtWKfeEwnDTrilUgm='stream70'
         axpYhbyCRQjBMPtWKfeEwnDTrilUmG =axpYhbyCRQjBMPtWKfeEwnDTrilUSV
     except:
      pass
     try:
      if optUHD==axpYhbyCRQjBMPtWKfeEwnDTrilUSV and axpYhbyCRQjBMPtWKfeEwnDTrilUgm=='stream50' and 'stream' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['content']['info']:
       if axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['content']['info']['stream']!=axpYhbyCRQjBMPtWKfeEwnDTrilUSk:
        for axpYhbyCRQjBMPtWKfeEwnDTrilUmo in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['content']['info']['stream']:
         if axpYhbyCRQjBMPtWKfeEwnDTrilUmo['code']=='stream70':
          axpYhbyCRQjBMPtWKfeEwnDTrilUgm='stream70'
          axpYhbyCRQjBMPtWKfeEwnDTrilUmG =axpYhbyCRQjBMPtWKfeEwnDTrilUSV
          break
     except:
      pass
   else:
    axpYhbyCRQjBMPtWKfeEwnDTrilUgm='stream40'
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmq['error_msg']='First Step - except error'
   return axpYhbyCRQjBMPtWKfeEwnDTrilUmq
  axpYhbyCRQjBMPtWKfeEwnDTrilUSs(axpYhbyCRQjBMPtWKfeEwnDTrilUgm)
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmX=axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetNoCache(1))
   axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v2a/media/stream/info'
   if axpYhbyCRQjBMPtWKfeEwnDTrilUmG==axpYhbyCRQjBMPtWKfeEwnDTrilUSV:
    axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams(uhd=axpYhbyCRQjBMPtWKfeEwnDTrilUSV)
    axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'mediaCode':mediacode,'noCache':axpYhbyCRQjBMPtWKfeEwnDTrilUmX,'streamType':'hls','streamCode':axpYhbyCRQjBMPtWKfeEwnDTrilUgm,'deviceId':axpYhbyCRQjBMPtWKfeEwnDTrilUmJ,'adReq':'none','wm':'Y','ad_device':'','uuid':axpYhbyCRQjBMPtWKfeEwnDTrilUmc,'deviceInfo':'android_tv',}
   else:
    axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams()
    axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':axpYhbyCRQjBMPtWKfeEwnDTrilUgm,'deviceId':axpYhbyCRQjBMPtWKfeEwnDTrilUmJ,'uuid':axpYhbyCRQjBMPtWKfeEwnDTrilUmc,'deviceInfo':'PC_Chrome','noCache':axpYhbyCRQjBMPtWKfeEwnDTrilUmX,'wm':'Y'}
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI.update(axpYhbyCRQjBMPtWKfeEwnDTrilUmk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmF
   axpYhbyCRQjBMPtWKfeEwnDTrilUAO=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.makeDefaultCookies()
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmI,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUAO,redirects=axpYhbyCRQjBMPtWKfeEwnDTrilUSO)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmO=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   if axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['result']['code']!='000':
    axpYhbyCRQjBMPtWKfeEwnDTrilUmq['error_msg']=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['result']['message']
    return axpYhbyCRQjBMPtWKfeEwnDTrilUmq
   axpYhbyCRQjBMPtWKfeEwnDTrilUgL=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['stream']
   if 'drm_license_assertion' in axpYhbyCRQjBMPtWKfeEwnDTrilUgL:
    axpYhbyCRQjBMPtWKfeEwnDTrilUmq['drm_license']=axpYhbyCRQjBMPtWKfeEwnDTrilUgL['drm_license_assertion']
    if '4k_nondrm_url' in axpYhbyCRQjBMPtWKfeEwnDTrilUgL['broadcast']and axpYhbyCRQjBMPtWKfeEwnDTrilUmG==axpYhbyCRQjBMPtWKfeEwnDTrilUSV:
     axpYhbyCRQjBMPtWKfeEwnDTrilUgS =axpYhbyCRQjBMPtWKfeEwnDTrilUgL['broadcast']['4k_nondrm_url']
     axpYhbyCRQjBMPtWKfeEwnDTrilUmq['drm_license']=''
    else:
     axpYhbyCRQjBMPtWKfeEwnDTrilUgS =axpYhbyCRQjBMPtWKfeEwnDTrilUgL['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in axpYhbyCRQjBMPtWKfeEwnDTrilUgL['broadcast']):return axpYhbyCRQjBMPtWKfeEwnDTrilUmq
    axpYhbyCRQjBMPtWKfeEwnDTrilUgS=axpYhbyCRQjBMPtWKfeEwnDTrilUgL['broadcast']['broad_url']
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmq['error_msg']='Second Step - except error'
   return axpYhbyCRQjBMPtWKfeEwnDTrilUmq
  axpYhbyCRQjBMPtWKfeEwnDTrilUgH=axpYhbyCRQjBMPtWKfeEwnDTrilUmX
  axpYhbyCRQjBMPtWKfeEwnDTrilUgS=axpYhbyCRQjBMPtWKfeEwnDTrilUgS.split('|')[1]
  axpYhbyCRQjBMPtWKfeEwnDTrilUgS,axpYhbyCRQjBMPtWKfeEwnDTrilUgu,axpYhbyCRQjBMPtWKfeEwnDTrilUgF=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.Decrypt_Url(axpYhbyCRQjBMPtWKfeEwnDTrilUgS,mediacode,axpYhbyCRQjBMPtWKfeEwnDTrilUgH)
  axpYhbyCRQjBMPtWKfeEwnDTrilUmq['streaming_url']=axpYhbyCRQjBMPtWKfeEwnDTrilUgS
  axpYhbyCRQjBMPtWKfeEwnDTrilUmq['watermark'] =axpYhbyCRQjBMPtWKfeEwnDTrilUgu
  axpYhbyCRQjBMPtWKfeEwnDTrilUmq['watermarkKey']=axpYhbyCRQjBMPtWKfeEwnDTrilUgF
  if 'subtitles' in axpYhbyCRQjBMPtWKfeEwnDTrilUgL:
   for axpYhbyCRQjBMPtWKfeEwnDTrilUgv in axpYhbyCRQjBMPtWKfeEwnDTrilUgL.get('subtitles'):
    if axpYhbyCRQjBMPtWKfeEwnDTrilUgv.get('code')in['KO','KO_CC']:
     axpYhbyCRQjBMPtWKfeEwnDTrilUmq['subtitleYn']=axpYhbyCRQjBMPtWKfeEwnDTrilUSV
     break
  return axpYhbyCRQjBMPtWKfeEwnDTrilUmq
 def CheckQuality(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,sel_qt,axpYhbyCRQjBMPtWKfeEwnDTrilUgd):
  for axpYhbyCRQjBMPtWKfeEwnDTrilUgs in axpYhbyCRQjBMPtWKfeEwnDTrilUgd:
   if sel_qt>=axpYhbyCRQjBMPtWKfeEwnDTrilUSz(axpYhbyCRQjBMPtWKfeEwnDTrilUgs)[0]:return axpYhbyCRQjBMPtWKfeEwnDTrilUgs.get(axpYhbyCRQjBMPtWKfeEwnDTrilUSz(axpYhbyCRQjBMPtWKfeEwnDTrilUgs)[0])
   axpYhbyCRQjBMPtWKfeEwnDTrilUgJ=axpYhbyCRQjBMPtWKfeEwnDTrilUgs.get(axpYhbyCRQjBMPtWKfeEwnDTrilUSz(axpYhbyCRQjBMPtWKfeEwnDTrilUgs)[0])
  return axpYhbyCRQjBMPtWKfeEwnDTrilUgJ
 def makeOocUrl(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,ooc_params):
  axpYhbyCRQjBMPtWKfeEwnDTrilUmz=''
  for axpYhbyCRQjBMPtWKfeEwnDTrilUgA,axpYhbyCRQjBMPtWKfeEwnDTrilUgN in ooc_params.items():
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz+="%s=%s^"%(axpYhbyCRQjBMPtWKfeEwnDTrilUgA,axpYhbyCRQjBMPtWKfeEwnDTrilUgN)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUmz
 def GetLiveChannelList(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,stype,page_int):
  axpYhbyCRQjBMPtWKfeEwnDTrilUms=[]
  axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v2/media/lives'
   if stype=='onair': 
    axpYhbyCRQjBMPtWKfeEwnDTrilUgO='CPCS0100,CPCS0400'
   else:
    axpYhbyCRQjBMPtWKfeEwnDTrilUgO='CPCS0300'
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams()
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'cacheType':'main','pageNo':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(page_int),'pageSize':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':axpYhbyCRQjBMPtWKfeEwnDTrilUgO,}
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI.update(axpYhbyCRQjBMPtWKfeEwnDTrilUmk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmF
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmI,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmO=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   if not('result' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']):return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
   axpYhbyCRQjBMPtWKfeEwnDTrilUgo=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['result']
   for axpYhbyCRQjBMPtWKfeEwnDTrilUmo in axpYhbyCRQjBMPtWKfeEwnDTrilUgo:
    axpYhbyCRQjBMPtWKfeEwnDTrilUgV=axpYhbyCRQjBMPtWKfeEwnDTrilUgG=axpYhbyCRQjBMPtWKfeEwnDTrilUgX=''
    axpYhbyCRQjBMPtWKfeEwnDTrilUgq=axpYhbyCRQjBMPtWKfeEwnDTrilUdo=''
    axpYhbyCRQjBMPtWKfeEwnDTrilUgc=axpYhbyCRQjBMPtWKfeEwnDTrilUmo['live_code']
    axpYhbyCRQjBMPtWKfeEwnDTrilUgV =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['channel']['name']['ko']
    if axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['episode']!=axpYhbyCRQjBMPtWKfeEwnDTrilUSk:
     axpYhbyCRQjBMPtWKfeEwnDTrilUgG =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['program']['name']['ko']
     axpYhbyCRQjBMPtWKfeEwnDTrilUgG =axpYhbyCRQjBMPtWKfeEwnDTrilUgG+', '+axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['episode']['frequency'])+'회'
     axpYhbyCRQjBMPtWKfeEwnDTrilUgX=axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['episode']['synopsis']['ko']
    else:
     axpYhbyCRQjBMPtWKfeEwnDTrilUgG =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['program']['name']['ko']
     axpYhbyCRQjBMPtWKfeEwnDTrilUgX=axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['program']['synopsis']['ko']
    try: 
     axpYhbyCRQjBMPtWKfeEwnDTrilUgI =''
     axpYhbyCRQjBMPtWKfeEwnDTrilUgz =''
     axpYhbyCRQjBMPtWKfeEwnDTrilUdA=''
     axpYhbyCRQjBMPtWKfeEwnDTrilUdm =''
     axpYhbyCRQjBMPtWKfeEwnDTrilUdg =''
     axpYhbyCRQjBMPtWKfeEwnDTrilUdL =''
     for axpYhbyCRQjBMPtWKfeEwnDTrilUdS in axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['program']['image']:
      if axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP0900':axpYhbyCRQjBMPtWKfeEwnDTrilUgz =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
      elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP1800':axpYhbyCRQjBMPtWKfeEwnDTrilUdA=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
      elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP2000':axpYhbyCRQjBMPtWKfeEwnDTrilUdm =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
      elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP1900':axpYhbyCRQjBMPtWKfeEwnDTrilUdg =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
      elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP0200':axpYhbyCRQjBMPtWKfeEwnDTrilUdL =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
      elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP0500':axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
      elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP0800':axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     if axpYhbyCRQjBMPtWKfeEwnDTrilUgI=='':
      for axpYhbyCRQjBMPtWKfeEwnDTrilUdS in axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['channel']['image']:
       if axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIC0400':axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
       elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIC1400':axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
       elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIC1900':axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
    except:
     axpYhbyCRQjBMPtWKfeEwnDTrilUSk
    try:
     axpYhbyCRQjBMPtWKfeEwnDTrilUdH =[]
     axpYhbyCRQjBMPtWKfeEwnDTrilUdu=[]
     axpYhbyCRQjBMPtWKfeEwnDTrilUdF =[]
     axpYhbyCRQjBMPtWKfeEwnDTrilUdv=''
     axpYhbyCRQjBMPtWKfeEwnDTrilUds=''
     axpYhbyCRQjBMPtWKfeEwnDTrilUdJ=''
     for axpYhbyCRQjBMPtWKfeEwnDTrilUdN in axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('schedule').get('program').get('actor'):
      if axpYhbyCRQjBMPtWKfeEwnDTrilUdN!='' and axpYhbyCRQjBMPtWKfeEwnDTrilUdN!=u'없음':axpYhbyCRQjBMPtWKfeEwnDTrilUdH.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdN)
     for axpYhbyCRQjBMPtWKfeEwnDTrilUdk in axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('schedule').get('program').get('director'):
      if axpYhbyCRQjBMPtWKfeEwnDTrilUdk!='' and axpYhbyCRQjBMPtWKfeEwnDTrilUdk!='-' and axpYhbyCRQjBMPtWKfeEwnDTrilUdk!=u'없음':axpYhbyCRQjBMPtWKfeEwnDTrilUdu.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdk)
     if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('schedule').get('program').get('category1_name').get('ko')!='':
      axpYhbyCRQjBMPtWKfeEwnDTrilUdF.append(axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['program']['category1_name']['ko'])
     if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('schedule').get('program').get('category2_name').get('ko')!='':
      axpYhbyCRQjBMPtWKfeEwnDTrilUdF.append(axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['program']['category2_name']['ko'])
     if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('schedule').get('program').get('product_year'):axpYhbyCRQjBMPtWKfeEwnDTrilUdv=axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['program']['product_year']
     if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('schedule').get('program').get('grade_code') :axpYhbyCRQjBMPtWKfeEwnDTrilUds= axpYhbyCRQjBMPtWKfeEwnDTrilUAd.get(axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['program']['grade_code'])
     if 'broad_dt' in axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('schedule').get('program'):
      axpYhbyCRQjBMPtWKfeEwnDTrilUdO =axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('schedule').get('program').get('broad_dt')
      axpYhbyCRQjBMPtWKfeEwnDTrilUdJ='%s-%s-%s'%(axpYhbyCRQjBMPtWKfeEwnDTrilUdO[:4],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[4:6],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[6:])
    except:
     axpYhbyCRQjBMPtWKfeEwnDTrilUSk
    axpYhbyCRQjBMPtWKfeEwnDTrilUgq=axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['broadcast_start_time'])[8:12]
    axpYhbyCRQjBMPtWKfeEwnDTrilUdo =axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUmo['schedule']['broadcast_end_time'])[8:12]
    axpYhbyCRQjBMPtWKfeEwnDTrilUdV={'channel':axpYhbyCRQjBMPtWKfeEwnDTrilUgV,'title':axpYhbyCRQjBMPtWKfeEwnDTrilUgG,'mediacode':axpYhbyCRQjBMPtWKfeEwnDTrilUgc,'thumbnail':{'poster':axpYhbyCRQjBMPtWKfeEwnDTrilUgz,'thumb':axpYhbyCRQjBMPtWKfeEwnDTrilUgI,'clearlogo':axpYhbyCRQjBMPtWKfeEwnDTrilUdA,'icon':axpYhbyCRQjBMPtWKfeEwnDTrilUdm,'fanart':axpYhbyCRQjBMPtWKfeEwnDTrilUdL},'synopsis':axpYhbyCRQjBMPtWKfeEwnDTrilUgX,'channelepg':' [%s:%s ~ %s:%s]'%(axpYhbyCRQjBMPtWKfeEwnDTrilUgq[0:2],axpYhbyCRQjBMPtWKfeEwnDTrilUgq[2:],axpYhbyCRQjBMPtWKfeEwnDTrilUdo[0:2],axpYhbyCRQjBMPtWKfeEwnDTrilUdo[2:]),'cast':axpYhbyCRQjBMPtWKfeEwnDTrilUdH,'director':axpYhbyCRQjBMPtWKfeEwnDTrilUdu,'info_genre':axpYhbyCRQjBMPtWKfeEwnDTrilUdF,'year':axpYhbyCRQjBMPtWKfeEwnDTrilUdv,'mpaa':axpYhbyCRQjBMPtWKfeEwnDTrilUds,'premiered':axpYhbyCRQjBMPtWKfeEwnDTrilUdJ}
    axpYhbyCRQjBMPtWKfeEwnDTrilUms.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdV)
   if axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['has_more']=='Y':
    axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSV
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
 def GetProgramList(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,genre,orderby,page_int,genreCode='all'):
  axpYhbyCRQjBMPtWKfeEwnDTrilUms=[]
  axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  try:
   if genre=='PARAMOUNT':
    axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v2/media/paramount/episodes'
   else:
    axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v2/media/episodes'
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams()
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'cacheType':'main','pageSize':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(page_int),}
   if genre not in['all','PARAMOUNT']:axpYhbyCRQjBMPtWKfeEwnDTrilUmk['categoryCode']=genre
   if genreCode!='all' :axpYhbyCRQjBMPtWKfeEwnDTrilUmk['genreCode'] =genreCode 
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI.update(axpYhbyCRQjBMPtWKfeEwnDTrilUmk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmF
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmI,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmO=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   if not('result' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']):return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
   axpYhbyCRQjBMPtWKfeEwnDTrilUgo=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['result']
   for axpYhbyCRQjBMPtWKfeEwnDTrilUmo in axpYhbyCRQjBMPtWKfeEwnDTrilUgo:
    axpYhbyCRQjBMPtWKfeEwnDTrilUdq=axpYhbyCRQjBMPtWKfeEwnDTrilUmo['program']['code']
    axpYhbyCRQjBMPtWKfeEwnDTrilUgG =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['program']['name']['ko']
    axpYhbyCRQjBMPtWKfeEwnDTrilUds =axpYhbyCRQjBMPtWKfeEwnDTrilUAd.get(axpYhbyCRQjBMPtWKfeEwnDTrilUmo['program'].get('grade_code'))
    axpYhbyCRQjBMPtWKfeEwnDTrilUgz =''
    axpYhbyCRQjBMPtWKfeEwnDTrilUgI =''
    axpYhbyCRQjBMPtWKfeEwnDTrilUdA=''
    axpYhbyCRQjBMPtWKfeEwnDTrilUdm =''
    axpYhbyCRQjBMPtWKfeEwnDTrilUdg =''
    for axpYhbyCRQjBMPtWKfeEwnDTrilUdS in axpYhbyCRQjBMPtWKfeEwnDTrilUmo['program']['image']:
     if axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP0900':axpYhbyCRQjBMPtWKfeEwnDTrilUgz =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP0200':axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP1800':axpYhbyCRQjBMPtWKfeEwnDTrilUdA=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP2000':axpYhbyCRQjBMPtWKfeEwnDTrilUdm =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP1900':axpYhbyCRQjBMPtWKfeEwnDTrilUdg =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
    axpYhbyCRQjBMPtWKfeEwnDTrilUgX =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['program']['synopsis']['ko']
    try:
     axpYhbyCRQjBMPtWKfeEwnDTrilUdc=axpYhbyCRQjBMPtWKfeEwnDTrilUmo['channel']['name']['ko']
    except:
     axpYhbyCRQjBMPtWKfeEwnDTrilUdc=''
    try:
     axpYhbyCRQjBMPtWKfeEwnDTrilUdH =[]
     axpYhbyCRQjBMPtWKfeEwnDTrilUdu=[]
     axpYhbyCRQjBMPtWKfeEwnDTrilUdF =[]
     axpYhbyCRQjBMPtWKfeEwnDTrilUdv =''
     axpYhbyCRQjBMPtWKfeEwnDTrilUdJ=''
     for axpYhbyCRQjBMPtWKfeEwnDTrilUdN in axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('program').get('actor'):
      if axpYhbyCRQjBMPtWKfeEwnDTrilUdN!='' and axpYhbyCRQjBMPtWKfeEwnDTrilUdN!='-' and axpYhbyCRQjBMPtWKfeEwnDTrilUdN!=u'없음':axpYhbyCRQjBMPtWKfeEwnDTrilUdH.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdN)
     for axpYhbyCRQjBMPtWKfeEwnDTrilUdk in axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('program').get('director'):
      if axpYhbyCRQjBMPtWKfeEwnDTrilUdk!='' and axpYhbyCRQjBMPtWKfeEwnDTrilUdk!='-' and axpYhbyCRQjBMPtWKfeEwnDTrilUdk!=u'없음':axpYhbyCRQjBMPtWKfeEwnDTrilUdu.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdk)
     if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('program').get('category1_name').get('ko')!='':
      axpYhbyCRQjBMPtWKfeEwnDTrilUdF.append(axpYhbyCRQjBMPtWKfeEwnDTrilUmo['program']['category1_name']['ko'])
     if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('program').get('category2_name').get('ko')!='':
      axpYhbyCRQjBMPtWKfeEwnDTrilUdF.append(axpYhbyCRQjBMPtWKfeEwnDTrilUmo['program']['category2_name']['ko'])
     if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('program').get('product_year'):axpYhbyCRQjBMPtWKfeEwnDTrilUdv=axpYhbyCRQjBMPtWKfeEwnDTrilUmo['program']['product_year']
     if 'broad_dt' in axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('program'):
      axpYhbyCRQjBMPtWKfeEwnDTrilUdO =axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('program').get('broad_dt')
      axpYhbyCRQjBMPtWKfeEwnDTrilUdJ='%s-%s-%s'%(axpYhbyCRQjBMPtWKfeEwnDTrilUdO[:4],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[4:6],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[6:])
    except:
     axpYhbyCRQjBMPtWKfeEwnDTrilUSk
    axpYhbyCRQjBMPtWKfeEwnDTrilUdV={'program':axpYhbyCRQjBMPtWKfeEwnDTrilUdq,'title':axpYhbyCRQjBMPtWKfeEwnDTrilUgG,'thumbnail':{'poster':axpYhbyCRQjBMPtWKfeEwnDTrilUgz,'thumb':axpYhbyCRQjBMPtWKfeEwnDTrilUgI,'clearlogo':axpYhbyCRQjBMPtWKfeEwnDTrilUdA,'icon':axpYhbyCRQjBMPtWKfeEwnDTrilUdm,'banner':axpYhbyCRQjBMPtWKfeEwnDTrilUdg,'fanart':axpYhbyCRQjBMPtWKfeEwnDTrilUgI},'synopsis':axpYhbyCRQjBMPtWKfeEwnDTrilUgX,'channel':axpYhbyCRQjBMPtWKfeEwnDTrilUdc,'cast':axpYhbyCRQjBMPtWKfeEwnDTrilUdH,'director':axpYhbyCRQjBMPtWKfeEwnDTrilUdu,'info_genre':axpYhbyCRQjBMPtWKfeEwnDTrilUdF,'year':axpYhbyCRQjBMPtWKfeEwnDTrilUdv,'premiered':axpYhbyCRQjBMPtWKfeEwnDTrilUdJ,'mpaa':axpYhbyCRQjBMPtWKfeEwnDTrilUds}
    axpYhbyCRQjBMPtWKfeEwnDTrilUms.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdV)
   if axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['has_more']=='Y':axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSV
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
 def Get_UHD_ProgramList(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,page_int):
  axpYhbyCRQjBMPtWKfeEwnDTrilUms=[]
  axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v2/operator/highlights'
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams(uhd=axpYhbyCRQjBMPtWKfeEwnDTrilUSV)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(page_int),'pocType':'APP_X_TVING_4.0.0',}
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI.update(axpYhbyCRQjBMPtWKfeEwnDTrilUmk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmF
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmI,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmO=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   if not('result' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']):return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
   axpYhbyCRQjBMPtWKfeEwnDTrilUgo=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['result']
   for axpYhbyCRQjBMPtWKfeEwnDTrilUmo in axpYhbyCRQjBMPtWKfeEwnDTrilUgo:
    axpYhbyCRQjBMPtWKfeEwnDTrilUdG=axpYhbyCRQjBMPtWKfeEwnDTrilUmo['content']['program']
    axpYhbyCRQjBMPtWKfeEwnDTrilUdX =axpYhbyCRQjBMPtWKfeEwnDTrilUdG['code']
    axpYhbyCRQjBMPtWKfeEwnDTrilUgG =axpYhbyCRQjBMPtWKfeEwnDTrilUdG['name']['ko'].strip()
    axpYhbyCRQjBMPtWKfeEwnDTrilUds =axpYhbyCRQjBMPtWKfeEwnDTrilUAd.get(axpYhbyCRQjBMPtWKfeEwnDTrilUdG.get('grade_code'))
    axpYhbyCRQjBMPtWKfeEwnDTrilUgX =axpYhbyCRQjBMPtWKfeEwnDTrilUdG['synopsis']['ko']
    axpYhbyCRQjBMPtWKfeEwnDTrilUdc =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['content']['channel']['name']['ko']
    axpYhbyCRQjBMPtWKfeEwnDTrilUdv =axpYhbyCRQjBMPtWKfeEwnDTrilUdG['product_year']
    axpYhbyCRQjBMPtWKfeEwnDTrilUgz =''
    axpYhbyCRQjBMPtWKfeEwnDTrilUgI =''
    axpYhbyCRQjBMPtWKfeEwnDTrilUdA=''
    axpYhbyCRQjBMPtWKfeEwnDTrilUdm =''
    axpYhbyCRQjBMPtWKfeEwnDTrilUdg =''
    for axpYhbyCRQjBMPtWKfeEwnDTrilUdS in axpYhbyCRQjBMPtWKfeEwnDTrilUdG['image']:
     if axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP0900':axpYhbyCRQjBMPtWKfeEwnDTrilUgz =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP0200':axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP1800':axpYhbyCRQjBMPtWKfeEwnDTrilUdA=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP2000':axpYhbyCRQjBMPtWKfeEwnDTrilUdm =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP1900':axpYhbyCRQjBMPtWKfeEwnDTrilUdg =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
    axpYhbyCRQjBMPtWKfeEwnDTrilUdF =[]
    axpYhbyCRQjBMPtWKfeEwnDTrilUdH =[]
    axpYhbyCRQjBMPtWKfeEwnDTrilUdu=[]
    axpYhbyCRQjBMPtWKfeEwnDTrilUdJ =''
    if axpYhbyCRQjBMPtWKfeEwnDTrilUdG.get('category1_name').get('ko')!='':
     axpYhbyCRQjBMPtWKfeEwnDTrilUdF.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdG['category1_name']['ko'])
    if axpYhbyCRQjBMPtWKfeEwnDTrilUdG.get('category2_name').get('ko')!='':
     axpYhbyCRQjBMPtWKfeEwnDTrilUdF.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdG['category2_name']['ko'])
    for axpYhbyCRQjBMPtWKfeEwnDTrilUdN in axpYhbyCRQjBMPtWKfeEwnDTrilUdG.get('actor'):
     if axpYhbyCRQjBMPtWKfeEwnDTrilUdN!='' and axpYhbyCRQjBMPtWKfeEwnDTrilUdN!='-' and axpYhbyCRQjBMPtWKfeEwnDTrilUdN!=u'없음':axpYhbyCRQjBMPtWKfeEwnDTrilUdH.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdN)
    for axpYhbyCRQjBMPtWKfeEwnDTrilUdk in axpYhbyCRQjBMPtWKfeEwnDTrilUdG.get('director'):
     if axpYhbyCRQjBMPtWKfeEwnDTrilUdk!='' and axpYhbyCRQjBMPtWKfeEwnDTrilUdk!='-' and axpYhbyCRQjBMPtWKfeEwnDTrilUdk!=u'없음':axpYhbyCRQjBMPtWKfeEwnDTrilUdu.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdk)
    if axpYhbyCRQjBMPtWKfeEwnDTrilUdG.get('broad_dt')not in[axpYhbyCRQjBMPtWKfeEwnDTrilUSk,'']:
     axpYhbyCRQjBMPtWKfeEwnDTrilUdO =axpYhbyCRQjBMPtWKfeEwnDTrilUdG.get('broad_dt')
     axpYhbyCRQjBMPtWKfeEwnDTrilUdJ='%s-%s-%s'%(axpYhbyCRQjBMPtWKfeEwnDTrilUdO[:4],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[4:6],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[6:])
    axpYhbyCRQjBMPtWKfeEwnDTrilUdV={'program':axpYhbyCRQjBMPtWKfeEwnDTrilUdX,'title':axpYhbyCRQjBMPtWKfeEwnDTrilUgG,'mpaa':axpYhbyCRQjBMPtWKfeEwnDTrilUds,'thumbnail':{'poster':axpYhbyCRQjBMPtWKfeEwnDTrilUgz,'thumb':axpYhbyCRQjBMPtWKfeEwnDTrilUgI,'clearlogo':axpYhbyCRQjBMPtWKfeEwnDTrilUdA,'icon':axpYhbyCRQjBMPtWKfeEwnDTrilUdm,'banner':axpYhbyCRQjBMPtWKfeEwnDTrilUdg,'fanart':axpYhbyCRQjBMPtWKfeEwnDTrilUgI},'channel':axpYhbyCRQjBMPtWKfeEwnDTrilUdc,'synopsis':axpYhbyCRQjBMPtWKfeEwnDTrilUgX,'year':axpYhbyCRQjBMPtWKfeEwnDTrilUdv,'info_genre':axpYhbyCRQjBMPtWKfeEwnDTrilUdF,'cast':axpYhbyCRQjBMPtWKfeEwnDTrilUdH,'director':axpYhbyCRQjBMPtWKfeEwnDTrilUdu,'premiered':axpYhbyCRQjBMPtWKfeEwnDTrilUdJ,}
    axpYhbyCRQjBMPtWKfeEwnDTrilUms.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdV)
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
 def Get_Origianl_ProgramList(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,page_int):
  axpYhbyCRQjBMPtWKfeEwnDTrilUms=[]
  axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v2/media/band/originals'
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams()
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'pageSize':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(page_int),}
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI.update(axpYhbyCRQjBMPtWKfeEwnDTrilUmk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmF
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmI,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmO=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   if not('contents' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']):return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
   axpYhbyCRQjBMPtWKfeEwnDTrilUgo=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['contents']
   for axpYhbyCRQjBMPtWKfeEwnDTrilUmo in axpYhbyCRQjBMPtWKfeEwnDTrilUgo:
    axpYhbyCRQjBMPtWKfeEwnDTrilUdq=axpYhbyCRQjBMPtWKfeEwnDTrilUmo['vod_code']
    axpYhbyCRQjBMPtWKfeEwnDTrilUgG =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['vod_name']
    axpYhbyCRQjBMPtWKfeEwnDTrilUgz =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmo['image']
    axpYhbyCRQjBMPtWKfeEwnDTrilUdV={'program':axpYhbyCRQjBMPtWKfeEwnDTrilUdq,'title':axpYhbyCRQjBMPtWKfeEwnDTrilUgG,'thumbnail':{'poster':axpYhbyCRQjBMPtWKfeEwnDTrilUgz,'thumb':axpYhbyCRQjBMPtWKfeEwnDTrilUgz}}
    axpYhbyCRQjBMPtWKfeEwnDTrilUms.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdV)
   if axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['has_more']=='Y':axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSV
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
 def GetEpisodeList(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,program_code,page_int,orderby='desc'):
  axpYhbyCRQjBMPtWKfeEwnDTrilUms=[]
  axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v2/media/frequency/program/'+program_code
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams()
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI.update(axpYhbyCRQjBMPtWKfeEwnDTrilUmk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmF
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmI,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmO=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   if not('result' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']):return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
   axpYhbyCRQjBMPtWKfeEwnDTrilUgo=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['result']
   axpYhbyCRQjBMPtWKfeEwnDTrilUdI=axpYhbyCRQjBMPtWKfeEwnDTrilUSq(axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['total_count'])
   axpYhbyCRQjBMPtWKfeEwnDTrilUdz =axpYhbyCRQjBMPtWKfeEwnDTrilUSq(axpYhbyCRQjBMPtWKfeEwnDTrilUdI//(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    axpYhbyCRQjBMPtWKfeEwnDTrilULA =(axpYhbyCRQjBMPtWKfeEwnDTrilUdI-1)-((page_int-1)*axpYhbyCRQjBMPtWKfeEwnDTrilUAL.EPISODE_LIMIT)
   else:
    axpYhbyCRQjBMPtWKfeEwnDTrilULA =(page_int-1)*axpYhbyCRQjBMPtWKfeEwnDTrilUAL.EPISODE_LIMIT
   for i in axpYhbyCRQjBMPtWKfeEwnDTrilUSc(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.EPISODE_LIMIT):
    if orderby=='desc':
     axpYhbyCRQjBMPtWKfeEwnDTrilULm=axpYhbyCRQjBMPtWKfeEwnDTrilULA-i
     if axpYhbyCRQjBMPtWKfeEwnDTrilULm<0:break
    else:
     axpYhbyCRQjBMPtWKfeEwnDTrilULm=axpYhbyCRQjBMPtWKfeEwnDTrilULA+i
     if axpYhbyCRQjBMPtWKfeEwnDTrilULm>=axpYhbyCRQjBMPtWKfeEwnDTrilUdI:break
    axpYhbyCRQjBMPtWKfeEwnDTrilULg=axpYhbyCRQjBMPtWKfeEwnDTrilUgo[axpYhbyCRQjBMPtWKfeEwnDTrilULm]['episode']['code']
    axpYhbyCRQjBMPtWKfeEwnDTrilUgG =axpYhbyCRQjBMPtWKfeEwnDTrilUgo[axpYhbyCRQjBMPtWKfeEwnDTrilULm]['vod_name']['ko']
    axpYhbyCRQjBMPtWKfeEwnDTrilULd =''
    try:
     axpYhbyCRQjBMPtWKfeEwnDTrilUdO=axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUgo[axpYhbyCRQjBMPtWKfeEwnDTrilULm]['episode']['broadcast_date'])
     axpYhbyCRQjBMPtWKfeEwnDTrilULd='%s-%s-%s'%(axpYhbyCRQjBMPtWKfeEwnDTrilUdO[:4],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[4:6],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[6:])
    except:
     axpYhbyCRQjBMPtWKfeEwnDTrilUSk
    try:
     if axpYhbyCRQjBMPtWKfeEwnDTrilUgo[axpYhbyCRQjBMPtWKfeEwnDTrilULm]['episode']['pip_cliptype']=='C012':
      axpYhbyCRQjBMPtWKfeEwnDTrilULd+=' - Quick VOD'
    except:
     axpYhbyCRQjBMPtWKfeEwnDTrilUSk
    axpYhbyCRQjBMPtWKfeEwnDTrilUgX =axpYhbyCRQjBMPtWKfeEwnDTrilUgo[axpYhbyCRQjBMPtWKfeEwnDTrilULm]['episode']['synopsis']['ko']
    axpYhbyCRQjBMPtWKfeEwnDTrilUgz =''
    axpYhbyCRQjBMPtWKfeEwnDTrilUgI =''
    axpYhbyCRQjBMPtWKfeEwnDTrilUdA=''
    axpYhbyCRQjBMPtWKfeEwnDTrilUdm =''
    axpYhbyCRQjBMPtWKfeEwnDTrilUdg =''
    axpYhbyCRQjBMPtWKfeEwnDTrilUdL =''
    for axpYhbyCRQjBMPtWKfeEwnDTrilUdS in axpYhbyCRQjBMPtWKfeEwnDTrilUgo[axpYhbyCRQjBMPtWKfeEwnDTrilULm]['program']['image']:
     if axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP0900':axpYhbyCRQjBMPtWKfeEwnDTrilUgz =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP1800':axpYhbyCRQjBMPtWKfeEwnDTrilUdA=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP2000':axpYhbyCRQjBMPtWKfeEwnDTrilUdm =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP1900':axpYhbyCRQjBMPtWKfeEwnDTrilUdg =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIP0200':axpYhbyCRQjBMPtWKfeEwnDTrilUdL =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
    for axpYhbyCRQjBMPtWKfeEwnDTrilUdS in axpYhbyCRQjBMPtWKfeEwnDTrilUgo[axpYhbyCRQjBMPtWKfeEwnDTrilULm]['episode']['image']:
     if axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIE0400':axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
    try:
     axpYhbyCRQjBMPtWKfeEwnDTrilULS=axpYhbyCRQjBMPtWKfeEwnDTrilULu=axpYhbyCRQjBMPtWKfeEwnDTrilULF=''
     axpYhbyCRQjBMPtWKfeEwnDTrilULH=0
     axpYhbyCRQjBMPtWKfeEwnDTrilULS =axpYhbyCRQjBMPtWKfeEwnDTrilUgo[axpYhbyCRQjBMPtWKfeEwnDTrilULm]['program']['name']['ko']
     axpYhbyCRQjBMPtWKfeEwnDTrilULu =axpYhbyCRQjBMPtWKfeEwnDTrilULd
     axpYhbyCRQjBMPtWKfeEwnDTrilULF =axpYhbyCRQjBMPtWKfeEwnDTrilUgo[axpYhbyCRQjBMPtWKfeEwnDTrilULm]['channel']['name']['ko']
     if 'frequency' in axpYhbyCRQjBMPtWKfeEwnDTrilUgo[axpYhbyCRQjBMPtWKfeEwnDTrilULm]['episode']:axpYhbyCRQjBMPtWKfeEwnDTrilULH=axpYhbyCRQjBMPtWKfeEwnDTrilUgo[axpYhbyCRQjBMPtWKfeEwnDTrilULm]['episode']['frequency']
    except:
     axpYhbyCRQjBMPtWKfeEwnDTrilUSk
    axpYhbyCRQjBMPtWKfeEwnDTrilUdV={'episode':axpYhbyCRQjBMPtWKfeEwnDTrilULg,'title':axpYhbyCRQjBMPtWKfeEwnDTrilUgG,'subtitle':axpYhbyCRQjBMPtWKfeEwnDTrilULd,'thumbnail':{'poster':axpYhbyCRQjBMPtWKfeEwnDTrilUgz,'thumb':axpYhbyCRQjBMPtWKfeEwnDTrilUgI,'clearlogo':axpYhbyCRQjBMPtWKfeEwnDTrilUdA,'icon':axpYhbyCRQjBMPtWKfeEwnDTrilUdm,'banner':axpYhbyCRQjBMPtWKfeEwnDTrilUdg,'fanart':axpYhbyCRQjBMPtWKfeEwnDTrilUdL},'synopsis':axpYhbyCRQjBMPtWKfeEwnDTrilUgX,'info_title':axpYhbyCRQjBMPtWKfeEwnDTrilULS,'aired':axpYhbyCRQjBMPtWKfeEwnDTrilULu,'studio':axpYhbyCRQjBMPtWKfeEwnDTrilULF,'frequency':axpYhbyCRQjBMPtWKfeEwnDTrilULH}
    axpYhbyCRQjBMPtWKfeEwnDTrilUms.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdV)
   if axpYhbyCRQjBMPtWKfeEwnDTrilUdz>page_int:axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSV
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk,axpYhbyCRQjBMPtWKfeEwnDTrilUdz
 def GetMovieList(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,genre,orderby,page_int):
  axpYhbyCRQjBMPtWKfeEwnDTrilUms=[]
  axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  try:
   if genre=='PARAMOUNT':
    axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v2/media/paramount/movies'
   else:
    axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v2/media/movies'
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams()
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'pageSize':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:axpYhbyCRQjBMPtWKfeEwnDTrilUmk['categoryCode']=genre
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk['productPackageCode']=','.join(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.MOVIE_LITE)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI.update(axpYhbyCRQjBMPtWKfeEwnDTrilUmk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmF
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmI,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmO=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   if not('result' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']):return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
   axpYhbyCRQjBMPtWKfeEwnDTrilUgo=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['result']
   for axpYhbyCRQjBMPtWKfeEwnDTrilUmo in axpYhbyCRQjBMPtWKfeEwnDTrilUgo:
    if 'release_date' in axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('movie'):
     axpYhbyCRQjBMPtWKfeEwnDTrilUdv=axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('movie').get('release_date'))[:4]
    else:
     axpYhbyCRQjBMPtWKfeEwnDTrilUdv=axpYhbyCRQjBMPtWKfeEwnDTrilUSk
    axpYhbyCRQjBMPtWKfeEwnDTrilULv =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['movie']['code']
    axpYhbyCRQjBMPtWKfeEwnDTrilUgG =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['movie']['name']['ko'].strip()
    if axpYhbyCRQjBMPtWKfeEwnDTrilUdv not in[axpYhbyCRQjBMPtWKfeEwnDTrilUSk,'0','']:axpYhbyCRQjBMPtWKfeEwnDTrilUgG+=u' (%s)'%(axpYhbyCRQjBMPtWKfeEwnDTrilUdv)
    axpYhbyCRQjBMPtWKfeEwnDTrilUgz=''
    axpYhbyCRQjBMPtWKfeEwnDTrilUgI =''
    axpYhbyCRQjBMPtWKfeEwnDTrilUdA=''
    for axpYhbyCRQjBMPtWKfeEwnDTrilUdS in axpYhbyCRQjBMPtWKfeEwnDTrilUmo['movie']['image']:
     if axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIM2100':axpYhbyCRQjBMPtWKfeEwnDTrilUgz =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIM0400':axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIM1800':axpYhbyCRQjBMPtWKfeEwnDTrilUdA=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
    axpYhbyCRQjBMPtWKfeEwnDTrilUgX =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['movie']['story']['ko']
    try:
     axpYhbyCRQjBMPtWKfeEwnDTrilULS =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['movie']['name']['ko'].strip()
     axpYhbyCRQjBMPtWKfeEwnDTrilUds =axpYhbyCRQjBMPtWKfeEwnDTrilUAd.get(axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('grade_code'))
     axpYhbyCRQjBMPtWKfeEwnDTrilUdH=[]
     axpYhbyCRQjBMPtWKfeEwnDTrilUdu=[]
     axpYhbyCRQjBMPtWKfeEwnDTrilUdF=[]
     axpYhbyCRQjBMPtWKfeEwnDTrilULs=0
     axpYhbyCRQjBMPtWKfeEwnDTrilUdJ=''
     axpYhbyCRQjBMPtWKfeEwnDTrilULF =''
     for axpYhbyCRQjBMPtWKfeEwnDTrilUdN in axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('movie').get('actor'):
      if axpYhbyCRQjBMPtWKfeEwnDTrilUdN!='':axpYhbyCRQjBMPtWKfeEwnDTrilUdH.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdN)
     for axpYhbyCRQjBMPtWKfeEwnDTrilUdk in axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('movie').get('director'):
      if axpYhbyCRQjBMPtWKfeEwnDTrilUdk!='':axpYhbyCRQjBMPtWKfeEwnDTrilUdu.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdk)
     if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('movie').get('category1_name').get('ko')!='':
      axpYhbyCRQjBMPtWKfeEwnDTrilUdF.append(axpYhbyCRQjBMPtWKfeEwnDTrilUmo['movie']['category1_name']['ko'])
     if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('movie').get('category2_name').get('ko')!='':
      axpYhbyCRQjBMPtWKfeEwnDTrilUdF.append(axpYhbyCRQjBMPtWKfeEwnDTrilUmo['movie']['category2_name']['ko'])
     if 'duration' in axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('movie'):axpYhbyCRQjBMPtWKfeEwnDTrilULs=axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('movie').get('duration')
     if 'release_date' in axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('movie'):
      axpYhbyCRQjBMPtWKfeEwnDTrilUdO=axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('movie').get('release_date'))
      if axpYhbyCRQjBMPtWKfeEwnDTrilUdO!='0':axpYhbyCRQjBMPtWKfeEwnDTrilUdJ='%s-%s-%s'%(axpYhbyCRQjBMPtWKfeEwnDTrilUdO[:4],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[4:6],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[6:])
     if 'production' in axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('movie'):axpYhbyCRQjBMPtWKfeEwnDTrilULF=axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('movie').get('production')
    except:
     axpYhbyCRQjBMPtWKfeEwnDTrilUSk
    axpYhbyCRQjBMPtWKfeEwnDTrilUdV={'moviecode':axpYhbyCRQjBMPtWKfeEwnDTrilULv,'title':axpYhbyCRQjBMPtWKfeEwnDTrilUgG,'thumbnail':{'poster':axpYhbyCRQjBMPtWKfeEwnDTrilUgz,'thumb':axpYhbyCRQjBMPtWKfeEwnDTrilUgI,'clearlogo':axpYhbyCRQjBMPtWKfeEwnDTrilUdA,'fanart':axpYhbyCRQjBMPtWKfeEwnDTrilUgI},'synopsis':axpYhbyCRQjBMPtWKfeEwnDTrilUgX,'info_title':axpYhbyCRQjBMPtWKfeEwnDTrilULS,'year':axpYhbyCRQjBMPtWKfeEwnDTrilUdv,'cast':axpYhbyCRQjBMPtWKfeEwnDTrilUdH,'director':axpYhbyCRQjBMPtWKfeEwnDTrilUdu,'info_genre':axpYhbyCRQjBMPtWKfeEwnDTrilUdF,'duration':axpYhbyCRQjBMPtWKfeEwnDTrilULs,'premiered':axpYhbyCRQjBMPtWKfeEwnDTrilUdJ,'studio':axpYhbyCRQjBMPtWKfeEwnDTrilULF,'mpaa':axpYhbyCRQjBMPtWKfeEwnDTrilUds}
    axpYhbyCRQjBMPtWKfeEwnDTrilULJ=axpYhbyCRQjBMPtWKfeEwnDTrilUSO
    for axpYhbyCRQjBMPtWKfeEwnDTrilULN in axpYhbyCRQjBMPtWKfeEwnDTrilUmo['billing_package_id']:
     if axpYhbyCRQjBMPtWKfeEwnDTrilULN in axpYhbyCRQjBMPtWKfeEwnDTrilUAL.MOVIE_LITE:
      axpYhbyCRQjBMPtWKfeEwnDTrilULJ=axpYhbyCRQjBMPtWKfeEwnDTrilUSV
      break
    if axpYhbyCRQjBMPtWKfeEwnDTrilULJ==axpYhbyCRQjBMPtWKfeEwnDTrilUSO: 
     axpYhbyCRQjBMPtWKfeEwnDTrilUdV['title']=axpYhbyCRQjBMPtWKfeEwnDTrilUdV['title']+' [개별구매]'
    axpYhbyCRQjBMPtWKfeEwnDTrilUms.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdV)
   if axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['has_more']=='Y':axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSV
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
 def Get_UHD_MovieList(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,page_int):
  axpYhbyCRQjBMPtWKfeEwnDTrilUms=[]
  axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v2/operator/highlights'
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams(uhd=axpYhbyCRQjBMPtWKfeEwnDTrilUSV)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(page_int),'pocType':'APP_X_TVING_4.0.0',}
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI.update(axpYhbyCRQjBMPtWKfeEwnDTrilUmk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmF
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmI,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmO=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   if not('result' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']):return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
   axpYhbyCRQjBMPtWKfeEwnDTrilUgo=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['result']
   for axpYhbyCRQjBMPtWKfeEwnDTrilUmo in axpYhbyCRQjBMPtWKfeEwnDTrilUgo:
    axpYhbyCRQjBMPtWKfeEwnDTrilUdG=axpYhbyCRQjBMPtWKfeEwnDTrilUmo['content']['movie']
    axpYhbyCRQjBMPtWKfeEwnDTrilUdX =axpYhbyCRQjBMPtWKfeEwnDTrilUdG['code']
    axpYhbyCRQjBMPtWKfeEwnDTrilUgG =axpYhbyCRQjBMPtWKfeEwnDTrilUdG['name']['ko'].strip()
    axpYhbyCRQjBMPtWKfeEwnDTrilULS =axpYhbyCRQjBMPtWKfeEwnDTrilUdG['name']['ko'].strip()
    axpYhbyCRQjBMPtWKfeEwnDTrilUdv =axpYhbyCRQjBMPtWKfeEwnDTrilUdG['product_year']
    if axpYhbyCRQjBMPtWKfeEwnDTrilUdv:axpYhbyCRQjBMPtWKfeEwnDTrilUgG+=u' (%s)'%(axpYhbyCRQjBMPtWKfeEwnDTrilUdG['product_year'])
    axpYhbyCRQjBMPtWKfeEwnDTrilUgX =axpYhbyCRQjBMPtWKfeEwnDTrilUdG['story']['ko']
    axpYhbyCRQjBMPtWKfeEwnDTrilULs =axpYhbyCRQjBMPtWKfeEwnDTrilUdG['duration']
    axpYhbyCRQjBMPtWKfeEwnDTrilUds =axpYhbyCRQjBMPtWKfeEwnDTrilUAd.get(axpYhbyCRQjBMPtWKfeEwnDTrilUdG.get('grade_code'))
    axpYhbyCRQjBMPtWKfeEwnDTrilULF =axpYhbyCRQjBMPtWKfeEwnDTrilUdG['production']
    axpYhbyCRQjBMPtWKfeEwnDTrilUgz=''
    axpYhbyCRQjBMPtWKfeEwnDTrilUgI =''
    axpYhbyCRQjBMPtWKfeEwnDTrilUdA=''
    axpYhbyCRQjBMPtWKfeEwnDTrilUdF =[]
    axpYhbyCRQjBMPtWKfeEwnDTrilUdH =[]
    axpYhbyCRQjBMPtWKfeEwnDTrilUdu=[]
    axpYhbyCRQjBMPtWKfeEwnDTrilUdJ =''
    for axpYhbyCRQjBMPtWKfeEwnDTrilUdS in axpYhbyCRQjBMPtWKfeEwnDTrilUdG['image']:
     if axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIM2100':axpYhbyCRQjBMPtWKfeEwnDTrilUgz =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIM0400':axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
     elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS['code']=='CAIM1800':axpYhbyCRQjBMPtWKfeEwnDTrilUdA=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS['url']
    if axpYhbyCRQjBMPtWKfeEwnDTrilUdG['release_date']not in[axpYhbyCRQjBMPtWKfeEwnDTrilUSk,0]:
     axpYhbyCRQjBMPtWKfeEwnDTrilUdO=axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUdG['release_date'])
     if axpYhbyCRQjBMPtWKfeEwnDTrilUdO!='0':axpYhbyCRQjBMPtWKfeEwnDTrilUdJ='%s-%s-%s'%(axpYhbyCRQjBMPtWKfeEwnDTrilUdO[:4],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[4:6],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[6:])
    if axpYhbyCRQjBMPtWKfeEwnDTrilUdG.get('category1_name').get('ko')!='':
     axpYhbyCRQjBMPtWKfeEwnDTrilUdF.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdG['category1_name']['ko'])
    if axpYhbyCRQjBMPtWKfeEwnDTrilUdG.get('category2_name').get('ko')!='':
     axpYhbyCRQjBMPtWKfeEwnDTrilUdF.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdG['category2_name']['ko'])
    for axpYhbyCRQjBMPtWKfeEwnDTrilUdN in axpYhbyCRQjBMPtWKfeEwnDTrilUdG.get('actor'):
     if axpYhbyCRQjBMPtWKfeEwnDTrilUdN!='':axpYhbyCRQjBMPtWKfeEwnDTrilUdH.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdN)
    for axpYhbyCRQjBMPtWKfeEwnDTrilUdk in axpYhbyCRQjBMPtWKfeEwnDTrilUdG.get('director'):
     if axpYhbyCRQjBMPtWKfeEwnDTrilUdk!='':axpYhbyCRQjBMPtWKfeEwnDTrilUdu.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdk)
    axpYhbyCRQjBMPtWKfeEwnDTrilUdV={'moviecode':axpYhbyCRQjBMPtWKfeEwnDTrilUdX,'title':axpYhbyCRQjBMPtWKfeEwnDTrilUgG,'thumbnail':{'poster':axpYhbyCRQjBMPtWKfeEwnDTrilUgz,'thumb':axpYhbyCRQjBMPtWKfeEwnDTrilUgI,'clearlogo':axpYhbyCRQjBMPtWKfeEwnDTrilUdA,'fanart':axpYhbyCRQjBMPtWKfeEwnDTrilUgI},'year':axpYhbyCRQjBMPtWKfeEwnDTrilUdv,'info_title':axpYhbyCRQjBMPtWKfeEwnDTrilULS,'synopsis':axpYhbyCRQjBMPtWKfeEwnDTrilUgX,'mpaa':axpYhbyCRQjBMPtWKfeEwnDTrilUds,'duration':axpYhbyCRQjBMPtWKfeEwnDTrilULs,'premiered':axpYhbyCRQjBMPtWKfeEwnDTrilUdJ,'studio':axpYhbyCRQjBMPtWKfeEwnDTrilULF,'info_genre':axpYhbyCRQjBMPtWKfeEwnDTrilUdF,'cast':axpYhbyCRQjBMPtWKfeEwnDTrilUdH,'director':axpYhbyCRQjBMPtWKfeEwnDTrilUdu,}
    axpYhbyCRQjBMPtWKfeEwnDTrilUms.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdV)
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
 def GetMovieGenre(axpYhbyCRQjBMPtWKfeEwnDTrilUAL):
  axpYhbyCRQjBMPtWKfeEwnDTrilUms=[]
  axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v2/media/movie/curations'
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams()
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI.update(axpYhbyCRQjBMPtWKfeEwnDTrilUmk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmF
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmI,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmO=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   if not('result' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']):return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
   axpYhbyCRQjBMPtWKfeEwnDTrilUgo=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['result']
   for axpYhbyCRQjBMPtWKfeEwnDTrilUmo in axpYhbyCRQjBMPtWKfeEwnDTrilUgo:
    axpYhbyCRQjBMPtWKfeEwnDTrilULk =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['curation_code']
    axpYhbyCRQjBMPtWKfeEwnDTrilULO =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['curation_name']
    axpYhbyCRQjBMPtWKfeEwnDTrilUdV={'curation_code':axpYhbyCRQjBMPtWKfeEwnDTrilULk,'curation_name':axpYhbyCRQjBMPtWKfeEwnDTrilULO}
    axpYhbyCRQjBMPtWKfeEwnDTrilUms.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdV)
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
 def GetSearchList(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,search_key,page_int,stype):
  axpYhbyCRQjBMPtWKfeEwnDTrilULo=[]
  axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSO
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/search/getSearch.jsp'
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(page_int),'pageSize':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.SCREENCODE,'os':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.OSCODE,'network':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.SEARCH_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmF
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmk,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmO=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   if stype=='vod':
    if not('programRsb' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO):return axpYhbyCRQjBMPtWKfeEwnDTrilULo,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
    axpYhbyCRQjBMPtWKfeEwnDTrilULV=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['programRsb']['dataList']
    axpYhbyCRQjBMPtWKfeEwnDTrilULq =axpYhbyCRQjBMPtWKfeEwnDTrilUSq(axpYhbyCRQjBMPtWKfeEwnDTrilUmO['programRsb']['count'])
    for axpYhbyCRQjBMPtWKfeEwnDTrilUmo in axpYhbyCRQjBMPtWKfeEwnDTrilULV:
     axpYhbyCRQjBMPtWKfeEwnDTrilUdq=axpYhbyCRQjBMPtWKfeEwnDTrilUmo['mast_cd']
     axpYhbyCRQjBMPtWKfeEwnDTrilUgG =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['mast_nm']
     axpYhbyCRQjBMPtWKfeEwnDTrilUgz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmo['web_url4']
     axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmo['web_url']
     try:
      axpYhbyCRQjBMPtWKfeEwnDTrilUdH =[]
      axpYhbyCRQjBMPtWKfeEwnDTrilUdu=[]
      axpYhbyCRQjBMPtWKfeEwnDTrilUdF =[]
      axpYhbyCRQjBMPtWKfeEwnDTrilULs =0
      axpYhbyCRQjBMPtWKfeEwnDTrilUds =''
      axpYhbyCRQjBMPtWKfeEwnDTrilUdv =''
      axpYhbyCRQjBMPtWKfeEwnDTrilULu =''
      if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('actor') !='' and axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('actor') !='-':axpYhbyCRQjBMPtWKfeEwnDTrilUdH =axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('actor').split(',')
      if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('director')!='' and axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('director')!='-':axpYhbyCRQjBMPtWKfeEwnDTrilUdu=axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('director').split(',')
      if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('cate_nm')!='' and axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('cate_nm')!='-':axpYhbyCRQjBMPtWKfeEwnDTrilUdF =axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('cate_nm').split('/')
      if 'targetage' in axpYhbyCRQjBMPtWKfeEwnDTrilUmo:axpYhbyCRQjBMPtWKfeEwnDTrilUds=axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('targetage')
      if 'broad_dt' in axpYhbyCRQjBMPtWKfeEwnDTrilUmo:
       axpYhbyCRQjBMPtWKfeEwnDTrilUdO=axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('broad_dt')
       axpYhbyCRQjBMPtWKfeEwnDTrilULu='%s-%s-%s'%(axpYhbyCRQjBMPtWKfeEwnDTrilUdO[:4],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[4:6],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[6:])
       axpYhbyCRQjBMPtWKfeEwnDTrilUdv =axpYhbyCRQjBMPtWKfeEwnDTrilUdO[:4]
     except:
      axpYhbyCRQjBMPtWKfeEwnDTrilUSk
     axpYhbyCRQjBMPtWKfeEwnDTrilUdV={'program':axpYhbyCRQjBMPtWKfeEwnDTrilUdq,'title':axpYhbyCRQjBMPtWKfeEwnDTrilUgG,'thumbnail':{'poster':axpYhbyCRQjBMPtWKfeEwnDTrilUgz,'thumb':axpYhbyCRQjBMPtWKfeEwnDTrilUgI,'fanart':axpYhbyCRQjBMPtWKfeEwnDTrilUgI},'synopsis':'','cast':axpYhbyCRQjBMPtWKfeEwnDTrilUdH,'director':axpYhbyCRQjBMPtWKfeEwnDTrilUdu,'info_genre':axpYhbyCRQjBMPtWKfeEwnDTrilUdF,'duration':axpYhbyCRQjBMPtWKfeEwnDTrilULs,'mpaa':axpYhbyCRQjBMPtWKfeEwnDTrilUds,'year':axpYhbyCRQjBMPtWKfeEwnDTrilUdv,'aired':axpYhbyCRQjBMPtWKfeEwnDTrilULu}
     axpYhbyCRQjBMPtWKfeEwnDTrilULo.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdV)
   else:
    if not('vodMVRsb' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO):return axpYhbyCRQjBMPtWKfeEwnDTrilULo,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
    axpYhbyCRQjBMPtWKfeEwnDTrilULc=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['vodMVRsb']['dataList']
    axpYhbyCRQjBMPtWKfeEwnDTrilULq =axpYhbyCRQjBMPtWKfeEwnDTrilUSq(axpYhbyCRQjBMPtWKfeEwnDTrilUmO['vodMVRsb']['count'])
    for axpYhbyCRQjBMPtWKfeEwnDTrilUmo in axpYhbyCRQjBMPtWKfeEwnDTrilULc:
     axpYhbyCRQjBMPtWKfeEwnDTrilUdq=axpYhbyCRQjBMPtWKfeEwnDTrilUmo['mast_cd']
     axpYhbyCRQjBMPtWKfeEwnDTrilUgG =axpYhbyCRQjBMPtWKfeEwnDTrilUmo['mast_nm'].strip()
     axpYhbyCRQjBMPtWKfeEwnDTrilUgz =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmo['web_url']
     axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUgz
     axpYhbyCRQjBMPtWKfeEwnDTrilUdA=''
     try:
      axpYhbyCRQjBMPtWKfeEwnDTrilUdH =[]
      axpYhbyCRQjBMPtWKfeEwnDTrilUdu=[]
      axpYhbyCRQjBMPtWKfeEwnDTrilUdF =[]
      axpYhbyCRQjBMPtWKfeEwnDTrilULs =0
      axpYhbyCRQjBMPtWKfeEwnDTrilUds =''
      axpYhbyCRQjBMPtWKfeEwnDTrilUdv =''
      axpYhbyCRQjBMPtWKfeEwnDTrilULu =''
      if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('actor') !='' and axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('actor') !='-':axpYhbyCRQjBMPtWKfeEwnDTrilUdH =axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('actor').split(',')
      if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('director')!='' and axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('director')!='-':axpYhbyCRQjBMPtWKfeEwnDTrilUdu=axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('director').split(',')
      if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('cate_nm')!='' and axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('cate_nm')!='-':axpYhbyCRQjBMPtWKfeEwnDTrilUdF =axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('cate_nm').split('/')
      if axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('runtime_sec')!='':axpYhbyCRQjBMPtWKfeEwnDTrilULs=axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('runtime_sec')
      if 'grade_nm' in axpYhbyCRQjBMPtWKfeEwnDTrilUmo:axpYhbyCRQjBMPtWKfeEwnDTrilUds=axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('grade_nm')
      axpYhbyCRQjBMPtWKfeEwnDTrilUdO=axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('broad_dt')
      if data_str!='':
       axpYhbyCRQjBMPtWKfeEwnDTrilULu='%s-%s-%s'%(axpYhbyCRQjBMPtWKfeEwnDTrilUdO[:4],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[4:6],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[6:])
       axpYhbyCRQjBMPtWKfeEwnDTrilUdv =axpYhbyCRQjBMPtWKfeEwnDTrilUdO[:4]
     except:
      axpYhbyCRQjBMPtWKfeEwnDTrilUSk
     axpYhbyCRQjBMPtWKfeEwnDTrilUdV={'movie':axpYhbyCRQjBMPtWKfeEwnDTrilUdq,'title':axpYhbyCRQjBMPtWKfeEwnDTrilUgG,'thumbnail':{'poster':axpYhbyCRQjBMPtWKfeEwnDTrilUgz,'thumb':axpYhbyCRQjBMPtWKfeEwnDTrilUgI,'fanart':axpYhbyCRQjBMPtWKfeEwnDTrilUgI,'clearlogo':axpYhbyCRQjBMPtWKfeEwnDTrilUdA},'synopsis':'','cast':axpYhbyCRQjBMPtWKfeEwnDTrilUdH,'director':axpYhbyCRQjBMPtWKfeEwnDTrilUdu,'info_genre':axpYhbyCRQjBMPtWKfeEwnDTrilUdF,'duration':axpYhbyCRQjBMPtWKfeEwnDTrilULs,'mpaa':axpYhbyCRQjBMPtWKfeEwnDTrilUds,'year':axpYhbyCRQjBMPtWKfeEwnDTrilUdv,'aired':axpYhbyCRQjBMPtWKfeEwnDTrilULu}
     axpYhbyCRQjBMPtWKfeEwnDTrilULJ=axpYhbyCRQjBMPtWKfeEwnDTrilUSO
     for axpYhbyCRQjBMPtWKfeEwnDTrilULN in axpYhbyCRQjBMPtWKfeEwnDTrilUmo['bill']:
      if axpYhbyCRQjBMPtWKfeEwnDTrilULN in axpYhbyCRQjBMPtWKfeEwnDTrilUAL.MOVIE_LITE:
       axpYhbyCRQjBMPtWKfeEwnDTrilULJ=axpYhbyCRQjBMPtWKfeEwnDTrilUSV
       break
     if axpYhbyCRQjBMPtWKfeEwnDTrilULJ==axpYhbyCRQjBMPtWKfeEwnDTrilUSO: 
      axpYhbyCRQjBMPtWKfeEwnDTrilUdV['title']=axpYhbyCRQjBMPtWKfeEwnDTrilUdV['title']+' [개별구매]'
     axpYhbyCRQjBMPtWKfeEwnDTrilULo.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdV)
   if axpYhbyCRQjBMPtWKfeEwnDTrilULq>(page_int*axpYhbyCRQjBMPtWKfeEwnDTrilUAL.SEARCH_LIMIT):axpYhbyCRQjBMPtWKfeEwnDTrilUgk=axpYhbyCRQjBMPtWKfeEwnDTrilUSV
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
  return axpYhbyCRQjBMPtWKfeEwnDTrilULo,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
 def GetBookmarkInfo(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,videoid,vidtype):
  axpYhbyCRQjBMPtWKfeEwnDTrilULG={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+'/v2/media/program/'+videoid
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams()
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'pageNo':'1','pageSize':'10','order':'name',}
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI.update(axpYhbyCRQjBMPtWKfeEwnDTrilUmk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmI,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk)
   axpYhbyCRQjBMPtWKfeEwnDTrilULX=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   if not('body' in axpYhbyCRQjBMPtWKfeEwnDTrilULX):return{}
   axpYhbyCRQjBMPtWKfeEwnDTrilULI=axpYhbyCRQjBMPtWKfeEwnDTrilULX['body']
   axpYhbyCRQjBMPtWKfeEwnDTrilUgG=axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('name').get('ko').strip()
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['title'] =axpYhbyCRQjBMPtWKfeEwnDTrilUgG
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['title']=axpYhbyCRQjBMPtWKfeEwnDTrilUgG
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['mpaa'] =axpYhbyCRQjBMPtWKfeEwnDTrilUAd.get(axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('grade_code'))
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['plot'] =axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('synopsis').get('ko')
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['year'] =axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('product_year')
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['cast'] =axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('actor')
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['director']=axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('director')
   if axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('category1_name').get('ko')!='':
    axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['genre'].append(axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('category1_name').get('ko'))
   if axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('category2_name').get('ko')!='':
    axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['genre'].append(axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('category2_name').get('ko'))
   axpYhbyCRQjBMPtWKfeEwnDTrilUdO=axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('broad_dt'))
   if axpYhbyCRQjBMPtWKfeEwnDTrilUdO!='0':axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(axpYhbyCRQjBMPtWKfeEwnDTrilUdO[:4],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[4:6],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[6:])
   axpYhbyCRQjBMPtWKfeEwnDTrilUgz =''
   axpYhbyCRQjBMPtWKfeEwnDTrilUgI =''
   axpYhbyCRQjBMPtWKfeEwnDTrilUdA=''
   axpYhbyCRQjBMPtWKfeEwnDTrilUdm =''
   axpYhbyCRQjBMPtWKfeEwnDTrilUdg =''
   for axpYhbyCRQjBMPtWKfeEwnDTrilUdS in axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('image'):
    if axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('code')=='CAIP0900':axpYhbyCRQjBMPtWKfeEwnDTrilUgz =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('url')
    elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('code')=='CAIP0200':axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('url')
    elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('code')=='CAIP1800':axpYhbyCRQjBMPtWKfeEwnDTrilUdA=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('url')
    elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('code')=='CAIP2000':axpYhbyCRQjBMPtWKfeEwnDTrilUdm =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('url')
    elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('code')=='CAIP1900':axpYhbyCRQjBMPtWKfeEwnDTrilUdg =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('url')
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['thumbnail']['poster']=axpYhbyCRQjBMPtWKfeEwnDTrilUgz
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['thumbnail']['thumb']=axpYhbyCRQjBMPtWKfeEwnDTrilUgI
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['thumbnail']['clearlogo']=axpYhbyCRQjBMPtWKfeEwnDTrilUdA
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['thumbnail']['icon']=axpYhbyCRQjBMPtWKfeEwnDTrilUdm
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['thumbnail']['banner']=axpYhbyCRQjBMPtWKfeEwnDTrilUdg
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['thumbnail']['fanart']=axpYhbyCRQjBMPtWKfeEwnDTrilUgI
  else:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+'/v2a/media/stream/info'
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams()
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_uuid'].split('-')[0],'uuid':axpYhbyCRQjBMPtWKfeEwnDTrilUAL.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetNoCache(1)),'wm':'Y',}
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI.update(axpYhbyCRQjBMPtWKfeEwnDTrilUmk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmI,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk)
   axpYhbyCRQjBMPtWKfeEwnDTrilULX=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   if not('content' in axpYhbyCRQjBMPtWKfeEwnDTrilULX['body']):return{}
   axpYhbyCRQjBMPtWKfeEwnDTrilULI=axpYhbyCRQjBMPtWKfeEwnDTrilULX['body']['content']['info']['movie']
   axpYhbyCRQjBMPtWKfeEwnDTrilUgG =axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('name').get('ko').strip()
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['title']=axpYhbyCRQjBMPtWKfeEwnDTrilUgG
   axpYhbyCRQjBMPtWKfeEwnDTrilUgG +=u' (%s)'%(axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('product_year'))
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['title'] =axpYhbyCRQjBMPtWKfeEwnDTrilUgG
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['mpaa'] =axpYhbyCRQjBMPtWKfeEwnDTrilUAd.get(axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('grade_code'))
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['plot'] =axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('story').get('ko')
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['year'] =axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('product_year')
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['studio'] =axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('production')
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['duration']=axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('duration')
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['cast'] =axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('actor')
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['director']=axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('director')
   if axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('category1_name').get('ko')!='':
    axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['genre'].append(axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('category1_name').get('ko'))
   if axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('category2_name').get('ko')!='':
    axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['genre'].append(axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('category2_name').get('ko'))
   axpYhbyCRQjBMPtWKfeEwnDTrilUdO=axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('release_date'))
   if axpYhbyCRQjBMPtWKfeEwnDTrilUdO!='0':axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(axpYhbyCRQjBMPtWKfeEwnDTrilUdO[:4],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[4:6],axpYhbyCRQjBMPtWKfeEwnDTrilUdO[6:])
   axpYhbyCRQjBMPtWKfeEwnDTrilUgz=''
   axpYhbyCRQjBMPtWKfeEwnDTrilUgI =''
   axpYhbyCRQjBMPtWKfeEwnDTrilUdA=''
   for axpYhbyCRQjBMPtWKfeEwnDTrilUdS in axpYhbyCRQjBMPtWKfeEwnDTrilULI.get('image'):
    if axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('code')=='CAIM2100':axpYhbyCRQjBMPtWKfeEwnDTrilUgz =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('url')
    elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('code')=='CAIM0400':axpYhbyCRQjBMPtWKfeEwnDTrilUgI =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('url')
    elif axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('code')=='CAIM1800':axpYhbyCRQjBMPtWKfeEwnDTrilUdA=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.IMG_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUdS.get('url')
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['thumbnail']['poster']=axpYhbyCRQjBMPtWKfeEwnDTrilUgz
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['thumbnail']['thumb']=axpYhbyCRQjBMPtWKfeEwnDTrilUgz 
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['thumbnail']['clearlogo']=axpYhbyCRQjBMPtWKfeEwnDTrilUdA
   axpYhbyCRQjBMPtWKfeEwnDTrilULG['saveinfo']['thumbnail']['fanart']=axpYhbyCRQjBMPtWKfeEwnDTrilUgI
  return axpYhbyCRQjBMPtWKfeEwnDTrilULG
 def GetEuroChannelList(axpYhbyCRQjBMPtWKfeEwnDTrilUAL):
  axpYhbyCRQjBMPtWKfeEwnDTrilUms=[]
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUmF ='/v2/operator/highlights'
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetDefaultParams()
   axpYhbyCRQjBMPtWKfeEwnDTrilUmk={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':axpYhbyCRQjBMPtWKfeEwnDTrilUSI(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.GetNoCache(2))}
   axpYhbyCRQjBMPtWKfeEwnDTrilUmI.update(axpYhbyCRQjBMPtWKfeEwnDTrilUmk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmz=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.API_DOMAIN+axpYhbyCRQjBMPtWKfeEwnDTrilUmF
   axpYhbyCRQjBMPtWKfeEwnDTrilUmd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.callRequestCookies('Get',axpYhbyCRQjBMPtWKfeEwnDTrilUmz,payload=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,params=axpYhbyCRQjBMPtWKfeEwnDTrilUmI,headers=axpYhbyCRQjBMPtWKfeEwnDTrilUSk,cookies=axpYhbyCRQjBMPtWKfeEwnDTrilUSk)
   axpYhbyCRQjBMPtWKfeEwnDTrilUmO=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUmd.text)
   if not('result' in axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']):return axpYhbyCRQjBMPtWKfeEwnDTrilUms,axpYhbyCRQjBMPtWKfeEwnDTrilUgk
   axpYhbyCRQjBMPtWKfeEwnDTrilUgo=axpYhbyCRQjBMPtWKfeEwnDTrilUmO['body']['result']
   axpYhbyCRQjBMPtWKfeEwnDTrilULz =axpYhbyCRQjBMPtWKfeEwnDTrilUAL.Get_Now_Datetime()
   axpYhbyCRQjBMPtWKfeEwnDTrilUSA=axpYhbyCRQjBMPtWKfeEwnDTrilULz+datetime.timedelta(days=-1)
   axpYhbyCRQjBMPtWKfeEwnDTrilUSA=axpYhbyCRQjBMPtWKfeEwnDTrilUSq(axpYhbyCRQjBMPtWKfeEwnDTrilUSA.strftime('%Y%m%d'))
   for axpYhbyCRQjBMPtWKfeEwnDTrilUmo in axpYhbyCRQjBMPtWKfeEwnDTrilUgo:
    axpYhbyCRQjBMPtWKfeEwnDTrilUSm=axpYhbyCRQjBMPtWKfeEwnDTrilUSq(axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('content').get('banner_title2')[:8])
    if axpYhbyCRQjBMPtWKfeEwnDTrilUSA<=axpYhbyCRQjBMPtWKfeEwnDTrilUSm:
     axpYhbyCRQjBMPtWKfeEwnDTrilUdV={'channel':axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('content').get('banner_sub_title3'),'title':axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('content').get('banner_title'),'subtitle':axpYhbyCRQjBMPtWKfeEwnDTrilUmo.get('content').get('banner_sub_title2'),}
     axpYhbyCRQjBMPtWKfeEwnDTrilUms.append(axpYhbyCRQjBMPtWKfeEwnDTrilUdV)
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUms
 def Make_DecryptKey(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,step,mediacode='000',timecode='000'):
  if step=='1':
   axpYhbyCRQjBMPtWKfeEwnDTrilUSg=axpYhbyCRQjBMPtWKfeEwnDTrilUHA('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   axpYhbyCRQjBMPtWKfeEwnDTrilUSd=axpYhbyCRQjBMPtWKfeEwnDTrilUHA('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSg=axpYhbyCRQjBMPtWKfeEwnDTrilUHA('kss2lym0kdw1lks3','utf-8')
   axpYhbyCRQjBMPtWKfeEwnDTrilUSd=axpYhbyCRQjBMPtWKfeEwnDTrilUHA([axpYhbyCRQjBMPtWKfeEwnDTrilUHm('*'),0x07,axpYhbyCRQjBMPtWKfeEwnDTrilUHm('r'),axpYhbyCRQjBMPtWKfeEwnDTrilUHm(';'),axpYhbyCRQjBMPtWKfeEwnDTrilUHm('7'),0x05,0x1e,0x01,axpYhbyCRQjBMPtWKfeEwnDTrilUHm('n'),axpYhbyCRQjBMPtWKfeEwnDTrilUHm('D'),0x02,axpYhbyCRQjBMPtWKfeEwnDTrilUHm('3'),axpYhbyCRQjBMPtWKfeEwnDTrilUHm('*'),axpYhbyCRQjBMPtWKfeEwnDTrilUHm('a'),axpYhbyCRQjBMPtWKfeEwnDTrilUHm('&'),axpYhbyCRQjBMPtWKfeEwnDTrilUHm('<')])
  return axpYhbyCRQjBMPtWKfeEwnDTrilUSg,axpYhbyCRQjBMPtWKfeEwnDTrilUSd
 def DecryptPlaintext(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,ciphertext,encryption_key,init_vector):
  axpYhbyCRQjBMPtWKfeEwnDTrilUSL=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  axpYhbyCRQjBMPtWKfeEwnDTrilUSH=Padding.unpad(axpYhbyCRQjBMPtWKfeEwnDTrilUSL.decrypt(base64.standard_b64decode(ciphertext)),16)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUSH.decode('utf-8')
 def Decrypt_Url(axpYhbyCRQjBMPtWKfeEwnDTrilUAL,ciphertext,mediacode,axpYhbyCRQjBMPtWKfeEwnDTrilUgH):
  axpYhbyCRQjBMPtWKfeEwnDTrilUSu=''
  axpYhbyCRQjBMPtWKfeEwnDTrilUgu=''
  axpYhbyCRQjBMPtWKfeEwnDTrilUgF=''
  try:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSg,axpYhbyCRQjBMPtWKfeEwnDTrilUSd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.Make_DecryptKey('1',mediacode=mediacode,timecode=axpYhbyCRQjBMPtWKfeEwnDTrilUgH)
   axpYhbyCRQjBMPtWKfeEwnDTrilUSF=json.loads(axpYhbyCRQjBMPtWKfeEwnDTrilUAL.DecryptPlaintext(ciphertext,axpYhbyCRQjBMPtWKfeEwnDTrilUSg,axpYhbyCRQjBMPtWKfeEwnDTrilUSd))
   axpYhbyCRQjBMPtWKfeEwnDTrilUSv =axpYhbyCRQjBMPtWKfeEwnDTrilUSF.get('broad_url')
   axpYhbyCRQjBMPtWKfeEwnDTrilUgu =axpYhbyCRQjBMPtWKfeEwnDTrilUSF.get('watermark') if 'watermark' in axpYhbyCRQjBMPtWKfeEwnDTrilUSF else ''
   axpYhbyCRQjBMPtWKfeEwnDTrilUgF=axpYhbyCRQjBMPtWKfeEwnDTrilUSF.get('watermarkKey')if 'watermarkKey' in axpYhbyCRQjBMPtWKfeEwnDTrilUSF else ''
   axpYhbyCRQjBMPtWKfeEwnDTrilUSg,axpYhbyCRQjBMPtWKfeEwnDTrilUSd=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.Make_DecryptKey('2',mediacode=mediacode,timecode=axpYhbyCRQjBMPtWKfeEwnDTrilUgH)
   axpYhbyCRQjBMPtWKfeEwnDTrilUSu=axpYhbyCRQjBMPtWKfeEwnDTrilUAL.DecryptPlaintext(axpYhbyCRQjBMPtWKfeEwnDTrilUSv,axpYhbyCRQjBMPtWKfeEwnDTrilUSg,axpYhbyCRQjBMPtWKfeEwnDTrilUSd)
  except axpYhbyCRQjBMPtWKfeEwnDTrilUSG as exception:
   axpYhbyCRQjBMPtWKfeEwnDTrilUSs(exception)
  return axpYhbyCRQjBMPtWKfeEwnDTrilUSu,axpYhbyCRQjBMPtWKfeEwnDTrilUgu,axpYhbyCRQjBMPtWKfeEwnDTrilUgF
# Created by pyminifier (https://github.com/liftoff/pyminifier)
