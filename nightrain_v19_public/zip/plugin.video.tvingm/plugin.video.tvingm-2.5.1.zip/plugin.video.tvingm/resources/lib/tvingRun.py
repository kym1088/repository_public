__author__="NightRain"
xlfPKQoEvBDumgRHYsyGedLVcXtOTa=object
xlfPKQoEvBDumgRHYsyGedLVcXtOTj=None
xlfPKQoEvBDumgRHYsyGedLVcXtOTw=int
xlfPKQoEvBDumgRHYsyGedLVcXtOTS=True
xlfPKQoEvBDumgRHYsyGedLVcXtOTr=False
xlfPKQoEvBDumgRHYsyGedLVcXtOTI=type
xlfPKQoEvBDumgRHYsyGedLVcXtOTk=dict
xlfPKQoEvBDumgRHYsyGedLVcXtOpU=len
xlfPKQoEvBDumgRHYsyGedLVcXtOpF=str
xlfPKQoEvBDumgRHYsyGedLVcXtOpA=range
xlfPKQoEvBDumgRHYsyGedLVcXtOpM=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
xlfPKQoEvBDumgRHYsyGedLVcXtOUA=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
xlfPKQoEvBDumgRHYsyGedLVcXtOUM=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
xlfPKQoEvBDumgRHYsyGedLVcXtOUC=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
xlfPKQoEvBDumgRHYsyGedLVcXtOUn=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
xlfPKQoEvBDumgRHYsyGedLVcXtOUi=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
xlfPKQoEvBDumgRHYsyGedLVcXtOUT=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
xlfPKQoEvBDumgRHYsyGedLVcXtOUp=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
xlfPKQoEvBDumgRHYsyGedLVcXtOUq =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
xlfPKQoEvBDumgRHYsyGedLVcXtOUh=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class xlfPKQoEvBDumgRHYsyGedLVcXtOUF(xlfPKQoEvBDumgRHYsyGedLVcXtOTa):
 def __init__(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOUJ,xlfPKQoEvBDumgRHYsyGedLVcXtOUW,xlfPKQoEvBDumgRHYsyGedLVcXtOUz):
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_url =xlfPKQoEvBDumgRHYsyGedLVcXtOUJ
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle=xlfPKQoEvBDumgRHYsyGedLVcXtOUW
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params =xlfPKQoEvBDumgRHYsyGedLVcXtOUz
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj =axpYhbyCRQjBMPtWKfeEwnDTrilUAm() 
 def addon_noti(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,sting):
  try:
   xlfPKQoEvBDumgRHYsyGedLVcXtOUa=xbmcgui.Dialog()
   xlfPKQoEvBDumgRHYsyGedLVcXtOUa.notification(__addonname__,sting)
  except:
   xlfPKQoEvBDumgRHYsyGedLVcXtOTj
 def addon_log(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,string):
  try:
   xlfPKQoEvBDumgRHYsyGedLVcXtOUj=string.encode('utf-8','ignore')
  except:
   xlfPKQoEvBDumgRHYsyGedLVcXtOUj='addonException: addon_log'
  xlfPKQoEvBDumgRHYsyGedLVcXtOUw=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,xlfPKQoEvBDumgRHYsyGedLVcXtOUj),level=xlfPKQoEvBDumgRHYsyGedLVcXtOUw)
 def get_keyboard_input(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOFz):
  xlfPKQoEvBDumgRHYsyGedLVcXtOUS=xlfPKQoEvBDumgRHYsyGedLVcXtOTj
  kb=xbmc.Keyboard()
  kb.setHeading(xlfPKQoEvBDumgRHYsyGedLVcXtOFz)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   xlfPKQoEvBDumgRHYsyGedLVcXtOUS=kb.getText()
  return xlfPKQoEvBDumgRHYsyGedLVcXtOUS
 def get_settings_account(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  xlfPKQoEvBDumgRHYsyGedLVcXtOUr =__addon__.getSetting('id')
  xlfPKQoEvBDumgRHYsyGedLVcXtOUI =__addon__.getSetting('pw')
  xlfPKQoEvBDumgRHYsyGedLVcXtOUk =__addon__.getSetting('login_type')
  xlfPKQoEvBDumgRHYsyGedLVcXtOFU=xlfPKQoEvBDumgRHYsyGedLVcXtOTw(__addon__.getSetting('selected_profile'))
  return(xlfPKQoEvBDumgRHYsyGedLVcXtOUr,xlfPKQoEvBDumgRHYsyGedLVcXtOUI,xlfPKQoEvBDumgRHYsyGedLVcXtOUk,xlfPKQoEvBDumgRHYsyGedLVcXtOFU)
 def get_settings_uhd(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  return xlfPKQoEvBDumgRHYsyGedLVcXtOTS if __addon__.getSetting('active_uhd')=='true' else xlfPKQoEvBDumgRHYsyGedLVcXtOTr
 def get_settings_playback(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  xlfPKQoEvBDumgRHYsyGedLVcXtOFA={'active_uhd':xlfPKQoEvBDumgRHYsyGedLVcXtOTS if __addon__.getSetting('active_uhd')=='true' else xlfPKQoEvBDumgRHYsyGedLVcXtOTr,}
  return xlfPKQoEvBDumgRHYsyGedLVcXtOFA
 def get_settings_proxyport(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  xlfPKQoEvBDumgRHYsyGedLVcXtOFM =xlfPKQoEvBDumgRHYsyGedLVcXtOTS if __addon__.getSetting('proxyYn')=='true' else xlfPKQoEvBDumgRHYsyGedLVcXtOTr
  xlfPKQoEvBDumgRHYsyGedLVcXtOFC=xlfPKQoEvBDumgRHYsyGedLVcXtOTw(__addon__.getSetting('proxyPort'))
  return xlfPKQoEvBDumgRHYsyGedLVcXtOFM,xlfPKQoEvBDumgRHYsyGedLVcXtOFC
 def get_settings_totalsearch(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  xlfPKQoEvBDumgRHYsyGedLVcXtOFn =xlfPKQoEvBDumgRHYsyGedLVcXtOTS if __addon__.getSetting('local_search')=='true' else xlfPKQoEvBDumgRHYsyGedLVcXtOTr
  xlfPKQoEvBDumgRHYsyGedLVcXtOFi=xlfPKQoEvBDumgRHYsyGedLVcXtOTS if __addon__.getSetting('local_history')=='true' else xlfPKQoEvBDumgRHYsyGedLVcXtOTr
  xlfPKQoEvBDumgRHYsyGedLVcXtOFT =xlfPKQoEvBDumgRHYsyGedLVcXtOTS if __addon__.getSetting('total_search')=='true' else xlfPKQoEvBDumgRHYsyGedLVcXtOTr
  xlfPKQoEvBDumgRHYsyGedLVcXtOFp=xlfPKQoEvBDumgRHYsyGedLVcXtOTS if __addon__.getSetting('total_history')=='true' else xlfPKQoEvBDumgRHYsyGedLVcXtOTr
  xlfPKQoEvBDumgRHYsyGedLVcXtOFq=xlfPKQoEvBDumgRHYsyGedLVcXtOTS if __addon__.getSetting('menu_bookmark')=='true' else xlfPKQoEvBDumgRHYsyGedLVcXtOTr
  return(xlfPKQoEvBDumgRHYsyGedLVcXtOFn,xlfPKQoEvBDumgRHYsyGedLVcXtOFi,xlfPKQoEvBDumgRHYsyGedLVcXtOFT,xlfPKQoEvBDumgRHYsyGedLVcXtOFp,xlfPKQoEvBDumgRHYsyGedLVcXtOFq)
 def get_settings_makebookmark(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  return xlfPKQoEvBDumgRHYsyGedLVcXtOTS if __addon__.getSetting('make_bookmark')=='true' else xlfPKQoEvBDumgRHYsyGedLVcXtOTr
 def get_settings_direct_replay(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  xlfPKQoEvBDumgRHYsyGedLVcXtOFh=xlfPKQoEvBDumgRHYsyGedLVcXtOTw(__addon__.getSetting('direct_replay'))
  if xlfPKQoEvBDumgRHYsyGedLVcXtOFh==0:
   return xlfPKQoEvBDumgRHYsyGedLVcXtOTr
  else:
   return xlfPKQoEvBDumgRHYsyGedLVcXtOTS
 def set_winEpisodeOrderby(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOFJ):
  __addon__.setSetting('tving_orderby',xlfPKQoEvBDumgRHYsyGedLVcXtOFJ)
  xlfPKQoEvBDumgRHYsyGedLVcXtOFN=xbmcgui.Window(10000)
  xlfPKQoEvBDumgRHYsyGedLVcXtOFN.setProperty('TVING_M_ORDERBY',xlfPKQoEvBDumgRHYsyGedLVcXtOFJ)
 def get_winEpisodeOrderby(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  xlfPKQoEvBDumgRHYsyGedLVcXtOFJ=__addon__.getSetting('tving_orderby')
  if xlfPKQoEvBDumgRHYsyGedLVcXtOFJ in['',xlfPKQoEvBDumgRHYsyGedLVcXtOTj]:xlfPKQoEvBDumgRHYsyGedLVcXtOFJ='desc'
  return xlfPKQoEvBDumgRHYsyGedLVcXtOFJ
 def add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,label,sublabel='',img='',infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params='',isLink=xlfPKQoEvBDumgRHYsyGedLVcXtOTr,ContextMenu=xlfPKQoEvBDumgRHYsyGedLVcXtOTj):
  xlfPKQoEvBDumgRHYsyGedLVcXtOFW='%s?%s'%(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_url,urllib.parse.urlencode(params))
  if sublabel:xlfPKQoEvBDumgRHYsyGedLVcXtOFz='%s < %s >'%(label,sublabel)
  else: xlfPKQoEvBDumgRHYsyGedLVcXtOFz=label
  if not img:img='DefaultFolder.png'
  xlfPKQoEvBDumgRHYsyGedLVcXtOFb=xbmcgui.ListItem(xlfPKQoEvBDumgRHYsyGedLVcXtOFz)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOTI(img)==xlfPKQoEvBDumgRHYsyGedLVcXtOTk:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFb.setArt(img)
  else:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFb.setArt({'thumb':img,'poster':img})
  if infoLabels:xlfPKQoEvBDumgRHYsyGedLVcXtOFb.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFb.setProperty('IsPlayable','true')
  if ContextMenu:xlfPKQoEvBDumgRHYsyGedLVcXtOFb.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,xlfPKQoEvBDumgRHYsyGedLVcXtOFW,xlfPKQoEvBDumgRHYsyGedLVcXtOFb,isFolder)
 def get_selQuality(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,etype):
  try:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFa='selected_quality'
   xlfPKQoEvBDumgRHYsyGedLVcXtOFj=[1080,720,480,360]
   xlfPKQoEvBDumgRHYsyGedLVcXtOFw=xlfPKQoEvBDumgRHYsyGedLVcXtOTw(__addon__.getSetting(xlfPKQoEvBDumgRHYsyGedLVcXtOFa))
   return xlfPKQoEvBDumgRHYsyGedLVcXtOFj[xlfPKQoEvBDumgRHYsyGedLVcXtOFw]
  except:
   xlfPKQoEvBDumgRHYsyGedLVcXtOTj
  return 720 
 def dp_Main_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  (xlfPKQoEvBDumgRHYsyGedLVcXtOFn,xlfPKQoEvBDumgRHYsyGedLVcXtOFi,xlfPKQoEvBDumgRHYsyGedLVcXtOFT,xlfPKQoEvBDumgRHYsyGedLVcXtOFp,xlfPKQoEvBDumgRHYsyGedLVcXtOFq)=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_totalsearch()
  for xlfPKQoEvBDumgRHYsyGedLVcXtOFS in xlfPKQoEvBDumgRHYsyGedLVcXtOUA:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz=xlfPKQoEvBDumgRHYsyGedLVcXtOFS.get('title')
   xlfPKQoEvBDumgRHYsyGedLVcXtOFr=''
   if xlfPKQoEvBDumgRHYsyGedLVcXtOFS.get('mode')=='SEARCH_GROUP' and xlfPKQoEvBDumgRHYsyGedLVcXtOFn ==xlfPKQoEvBDumgRHYsyGedLVcXtOTr:continue
   elif xlfPKQoEvBDumgRHYsyGedLVcXtOFS.get('mode')=='SEARCH_HISTORY' and xlfPKQoEvBDumgRHYsyGedLVcXtOFi==xlfPKQoEvBDumgRHYsyGedLVcXtOTr:continue
   elif xlfPKQoEvBDumgRHYsyGedLVcXtOFS.get('mode')=='TOTAL_SEARCH' and xlfPKQoEvBDumgRHYsyGedLVcXtOFT ==xlfPKQoEvBDumgRHYsyGedLVcXtOTr:continue
   elif xlfPKQoEvBDumgRHYsyGedLVcXtOFS.get('mode')=='TOTAL_HISTORY' and xlfPKQoEvBDumgRHYsyGedLVcXtOFp==xlfPKQoEvBDumgRHYsyGedLVcXtOTr:continue
   elif xlfPKQoEvBDumgRHYsyGedLVcXtOFS.get('mode')=='MENU_BOOKMARK' and xlfPKQoEvBDumgRHYsyGedLVcXtOFq==xlfPKQoEvBDumgRHYsyGedLVcXtOTr:continue
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':xlfPKQoEvBDumgRHYsyGedLVcXtOFS.get('mode'),'stype':xlfPKQoEvBDumgRHYsyGedLVcXtOFS.get('stype'),'orderby':xlfPKQoEvBDumgRHYsyGedLVcXtOFS.get('orderby'),'ordernm':xlfPKQoEvBDumgRHYsyGedLVcXtOFS.get('ordernm'),'page':'1'}
   if xlfPKQoEvBDumgRHYsyGedLVcXtOFS.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    xlfPKQoEvBDumgRHYsyGedLVcXtOFk=xlfPKQoEvBDumgRHYsyGedLVcXtOTr
    xlfPKQoEvBDumgRHYsyGedLVcXtOAU =xlfPKQoEvBDumgRHYsyGedLVcXtOTS
   else:
    xlfPKQoEvBDumgRHYsyGedLVcXtOFk=xlfPKQoEvBDumgRHYsyGedLVcXtOTS
    xlfPKQoEvBDumgRHYsyGedLVcXtOAU =xlfPKQoEvBDumgRHYsyGedLVcXtOTr
   if 'icon' in xlfPKQoEvBDumgRHYsyGedLVcXtOFS:xlfPKQoEvBDumgRHYsyGedLVcXtOFr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',xlfPKQoEvBDumgRHYsyGedLVcXtOFS.get('icon')) 
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel='',img=xlfPKQoEvBDumgRHYsyGedLVcXtOFr,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOFk,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI,isLink=xlfPKQoEvBDumgRHYsyGedLVcXtOAU)
  xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle)
 def login_main(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  (xlfPKQoEvBDumgRHYsyGedLVcXtOAM,xlfPKQoEvBDumgRHYsyGedLVcXtOAC,xlfPKQoEvBDumgRHYsyGedLVcXtOAn,xlfPKQoEvBDumgRHYsyGedLVcXtOAi)=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_account()
  if not(xlfPKQoEvBDumgRHYsyGedLVcXtOAM and xlfPKQoEvBDumgRHYsyGedLVcXtOAC):
   xlfPKQoEvBDumgRHYsyGedLVcXtOUa=xbmcgui.Dialog()
   xlfPKQoEvBDumgRHYsyGedLVcXtOAT=xlfPKQoEvBDumgRHYsyGedLVcXtOUa.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if xlfPKQoEvBDumgRHYsyGedLVcXtOAT==xlfPKQoEvBDumgRHYsyGedLVcXtOTS:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if xlfPKQoEvBDumgRHYsyGedLVcXtOUN.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   xlfPKQoEvBDumgRHYsyGedLVcXtOAp=0
   while xlfPKQoEvBDumgRHYsyGedLVcXtOTS:
    xlfPKQoEvBDumgRHYsyGedLVcXtOAp+=1
    time.sleep(0.05)
    if xlfPKQoEvBDumgRHYsyGedLVcXtOAp>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  xlfPKQoEvBDumgRHYsyGedLVcXtOAq=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.GetCredential(xlfPKQoEvBDumgRHYsyGedLVcXtOAM,xlfPKQoEvBDumgRHYsyGedLVcXtOAC,xlfPKQoEvBDumgRHYsyGedLVcXtOAn,xlfPKQoEvBDumgRHYsyGedLVcXtOAi)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAq:xlfPKQoEvBDumgRHYsyGedLVcXtOUN.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAq==xlfPKQoEvBDumgRHYsyGedLVcXtOTr:
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOAh=xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('stype')
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAh=='live':
   xlfPKQoEvBDumgRHYsyGedLVcXtOAN=xlfPKQoEvBDumgRHYsyGedLVcXtOUM
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOAh=='vod':
   xlfPKQoEvBDumgRHYsyGedLVcXtOAN=xlfPKQoEvBDumgRHYsyGedLVcXtOUi
  else:
   xlfPKQoEvBDumgRHYsyGedLVcXtOAN=xlfPKQoEvBDumgRHYsyGedLVcXtOUT
  for xlfPKQoEvBDumgRHYsyGedLVcXtOAJ in xlfPKQoEvBDumgRHYsyGedLVcXtOAN:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz=xlfPKQoEvBDumgRHYsyGedLVcXtOAJ.get('title')
   if xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('ordernm')!='-':
    xlfPKQoEvBDumgRHYsyGedLVcXtOFz+='  ('+xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('ordernm')+')'
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':xlfPKQoEvBDumgRHYsyGedLVcXtOAJ.get('mode'),'stype':xlfPKQoEvBDumgRHYsyGedLVcXtOAJ.get('stype'),'orderby':xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('orderby'),'ordernm':xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('ordernm'),'page':'1'}
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel='',img='',infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOpU(xlfPKQoEvBDumgRHYsyGedLVcXtOAN)>0:xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle)
 def dp_SubTitle_Group(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW): 
  for xlfPKQoEvBDumgRHYsyGedLVcXtOAJ in xlfPKQoEvBDumgRHYsyGedLVcXtOUp:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz=xlfPKQoEvBDumgRHYsyGedLVcXtOAJ.get('title')
   if xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('ordernm')!='-':
    xlfPKQoEvBDumgRHYsyGedLVcXtOFz+='  ('+xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('ordernm')+')'
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':xlfPKQoEvBDumgRHYsyGedLVcXtOAJ.get('mode'),'genreCode':xlfPKQoEvBDumgRHYsyGedLVcXtOAJ.get('genreCode'),'stype':xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('stype'),'orderby':xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('orderby'),'page':'1'}
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel='',img='',infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOpU(xlfPKQoEvBDumgRHYsyGedLVcXtOUp)>0:xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle)
 def dp_LiveChannel_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOAh =xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('stype')
  xlfPKQoEvBDumgRHYsyGedLVcXtOAz =xlfPKQoEvBDumgRHYsyGedLVcXtOTw(xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('page'))
  xlfPKQoEvBDumgRHYsyGedLVcXtOAb,xlfPKQoEvBDumgRHYsyGedLVcXtOAa=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.GetLiveChannelList(xlfPKQoEvBDumgRHYsyGedLVcXtOAh,xlfPKQoEvBDumgRHYsyGedLVcXtOAz)
  for xlfPKQoEvBDumgRHYsyGedLVcXtOAj in xlfPKQoEvBDumgRHYsyGedLVcXtOAb:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('title')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAF =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('channel')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAw =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('thumbnail')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAS =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('synopsis')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAr =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('channelepg')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAI =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('cast')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAk =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('director')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMU =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('info_genre')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMF =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('year')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMA =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('mpaa')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMC =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('premiered')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMn={'mediatype':'episode','title':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'studio':xlfPKQoEvBDumgRHYsyGedLVcXtOAF,'cast':xlfPKQoEvBDumgRHYsyGedLVcXtOAI,'director':xlfPKQoEvBDumgRHYsyGedLVcXtOAk,'genre':xlfPKQoEvBDumgRHYsyGedLVcXtOMU,'plot':'%s\n%s\n%s\n\n%s'%(xlfPKQoEvBDumgRHYsyGedLVcXtOAF,xlfPKQoEvBDumgRHYsyGedLVcXtOFz,xlfPKQoEvBDumgRHYsyGedLVcXtOAr,xlfPKQoEvBDumgRHYsyGedLVcXtOAS),'year':xlfPKQoEvBDumgRHYsyGedLVcXtOMF,'mpaa':xlfPKQoEvBDumgRHYsyGedLVcXtOMA,'premiered':xlfPKQoEvBDumgRHYsyGedLVcXtOMC}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'LIVE','mediacode':xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('mediacode'),'stype':xlfPKQoEvBDumgRHYsyGedLVcXtOAh}
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOAF,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOFz,img=xlfPKQoEvBDumgRHYsyGedLVcXtOAw,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOMn,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTr,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAa:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['mode']='CHANNEL' 
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['stype']=xlfPKQoEvBDumgRHYsyGedLVcXtOAh 
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['page']=xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz='[B]%s >>[/B]'%'다음 페이지'
   xlfPKQoEvBDumgRHYsyGedLVcXtOMi=xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOMi,img=xlfPKQoEvBDumgRHYsyGedLVcXtOFr,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOpU(xlfPKQoEvBDumgRHYsyGedLVcXtOAb)>0:xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,cacheToDisc=xlfPKQoEvBDumgRHYsyGedLVcXtOTr)
 def dp_Program_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOMT =xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('stype')
  xlfPKQoEvBDumgRHYsyGedLVcXtOFJ =xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('orderby')
  xlfPKQoEvBDumgRHYsyGedLVcXtOAz =xlfPKQoEvBDumgRHYsyGedLVcXtOTw(xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('page'))
  xlfPKQoEvBDumgRHYsyGedLVcXtOMp=xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('genreCode')
  if xlfPKQoEvBDumgRHYsyGedLVcXtOMp==xlfPKQoEvBDumgRHYsyGedLVcXtOTj:xlfPKQoEvBDumgRHYsyGedLVcXtOMp='all'
  xlfPKQoEvBDumgRHYsyGedLVcXtOMq,xlfPKQoEvBDumgRHYsyGedLVcXtOAa=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.GetProgramList(xlfPKQoEvBDumgRHYsyGedLVcXtOMT,xlfPKQoEvBDumgRHYsyGedLVcXtOFJ,xlfPKQoEvBDumgRHYsyGedLVcXtOAz,xlfPKQoEvBDumgRHYsyGedLVcXtOMp)
  for xlfPKQoEvBDumgRHYsyGedLVcXtOMh in xlfPKQoEvBDumgRHYsyGedLVcXtOMq:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('title')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAw =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('thumbnail')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAS =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('synopsis')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMN =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('channel')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAI =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('cast')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAk =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('director')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMU=xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('info_genre')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMF =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('year')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMC =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('premiered')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMA =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('mpaa')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMn={'mediatype':'tvshow','title':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'studio':xlfPKQoEvBDumgRHYsyGedLVcXtOMN,'cast':xlfPKQoEvBDumgRHYsyGedLVcXtOAI,'director':xlfPKQoEvBDumgRHYsyGedLVcXtOAk,'genre':xlfPKQoEvBDumgRHYsyGedLVcXtOMU,'year':xlfPKQoEvBDumgRHYsyGedLVcXtOMF,'premiered':xlfPKQoEvBDumgRHYsyGedLVcXtOMC,'mpaa':xlfPKQoEvBDumgRHYsyGedLVcXtOMA,'plot':xlfPKQoEvBDumgRHYsyGedLVcXtOAS}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'EPISODE','programcode':xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('program'),'page':'1'}
   if xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_makebookmark():
    xlfPKQoEvBDumgRHYsyGedLVcXtOMJ={'videoid':xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('program'),'vidtype':'tvshow','vtitle':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'vsubtitle':xlfPKQoEvBDumgRHYsyGedLVcXtOMN,}
    xlfPKQoEvBDumgRHYsyGedLVcXtOMW=json.dumps(xlfPKQoEvBDumgRHYsyGedLVcXtOMJ)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMW=urllib.parse.quote(xlfPKQoEvBDumgRHYsyGedLVcXtOMW)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMz='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(xlfPKQoEvBDumgRHYsyGedLVcXtOMW)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMb=[('(통합) 찜 영상에 추가',xlfPKQoEvBDumgRHYsyGedLVcXtOMz)]
   else:
    xlfPKQoEvBDumgRHYsyGedLVcXtOMb=xlfPKQoEvBDumgRHYsyGedLVcXtOTj
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOMN,img=xlfPKQoEvBDumgRHYsyGedLVcXtOAw,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOMn,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI,ContextMenu=xlfPKQoEvBDumgRHYsyGedLVcXtOMb)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAa:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['mode'] ='PROGRAM' 
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['stype'] =xlfPKQoEvBDumgRHYsyGedLVcXtOMT
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['orderby'] =xlfPKQoEvBDumgRHYsyGedLVcXtOFJ
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['page'] =xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['genreCode']=xlfPKQoEvBDumgRHYsyGedLVcXtOMp 
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz='[B]%s >>[/B]'%'다음 페이지'
   xlfPKQoEvBDumgRHYsyGedLVcXtOMi=xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOMi,img=xlfPKQoEvBDumgRHYsyGedLVcXtOFr,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  xbmcplugin.setContent(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,cacheToDisc=xlfPKQoEvBDumgRHYsyGedLVcXtOTr)
 def dp_4K_Program_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOAz =xlfPKQoEvBDumgRHYsyGedLVcXtOTw(xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('page'))
  xlfPKQoEvBDumgRHYsyGedLVcXtOMq,xlfPKQoEvBDumgRHYsyGedLVcXtOAa=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.Get_UHD_ProgramList(xlfPKQoEvBDumgRHYsyGedLVcXtOAz)
  for xlfPKQoEvBDumgRHYsyGedLVcXtOMh in xlfPKQoEvBDumgRHYsyGedLVcXtOMq:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('title')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAw =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('thumbnail')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAS =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('synopsis')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMN =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('channel')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAI =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('cast')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAk =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('director')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMU=xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('info_genre')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMF =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('year')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMC =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('premiered')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMA =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('mpaa')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMn={'mediatype':'tvshow','title':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'studio':xlfPKQoEvBDumgRHYsyGedLVcXtOMN,'cast':xlfPKQoEvBDumgRHYsyGedLVcXtOAI,'director':xlfPKQoEvBDumgRHYsyGedLVcXtOAk,'genre':xlfPKQoEvBDumgRHYsyGedLVcXtOMU,'year':xlfPKQoEvBDumgRHYsyGedLVcXtOMF,'premiered':xlfPKQoEvBDumgRHYsyGedLVcXtOMC,'mpaa':xlfPKQoEvBDumgRHYsyGedLVcXtOMA,'plot':xlfPKQoEvBDumgRHYsyGedLVcXtOAS}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'EPISODE','programcode':xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('program'),'page':'1'}
   if xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_makebookmark():
    xlfPKQoEvBDumgRHYsyGedLVcXtOMJ={'videoid':xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('program'),'vidtype':'tvshow','vtitle':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'vsubtitle':xlfPKQoEvBDumgRHYsyGedLVcXtOMN,}
    xlfPKQoEvBDumgRHYsyGedLVcXtOMW=json.dumps(xlfPKQoEvBDumgRHYsyGedLVcXtOMJ)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMW=urllib.parse.quote(xlfPKQoEvBDumgRHYsyGedLVcXtOMW)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMz='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(xlfPKQoEvBDumgRHYsyGedLVcXtOMW)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMb=[('(통합) 찜 영상에 추가',xlfPKQoEvBDumgRHYsyGedLVcXtOMz)]
   else:
    xlfPKQoEvBDumgRHYsyGedLVcXtOMb=xlfPKQoEvBDumgRHYsyGedLVcXtOTj
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOMN,img=xlfPKQoEvBDumgRHYsyGedLVcXtOAw,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOMn,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI,ContextMenu=xlfPKQoEvBDumgRHYsyGedLVcXtOMb)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAa:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['mode'] ='4K_PROGRAM' 
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['page'] =xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz='[B]%s >>[/B]'%'다음 페이지'
   xlfPKQoEvBDumgRHYsyGedLVcXtOMi=xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOMi,img=xlfPKQoEvBDumgRHYsyGedLVcXtOFr,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  xbmcplugin.setContent(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,cacheToDisc=xlfPKQoEvBDumgRHYsyGedLVcXtOTr)
 def dp_Ori_Program_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOAz =xlfPKQoEvBDumgRHYsyGedLVcXtOTw(xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('page'))
  xlfPKQoEvBDumgRHYsyGedLVcXtOMq,xlfPKQoEvBDumgRHYsyGedLVcXtOAa=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.Get_Origianl_ProgramList(xlfPKQoEvBDumgRHYsyGedLVcXtOAz)
  for xlfPKQoEvBDumgRHYsyGedLVcXtOMh in xlfPKQoEvBDumgRHYsyGedLVcXtOMq:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('title')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAw =xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('thumbnail')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMn={'mediatype':'tvshow','title':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'EPISODE','programcode':xlfPKQoEvBDumgRHYsyGedLVcXtOMh.get('program'),'page':'1',}
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,img=xlfPKQoEvBDumgRHYsyGedLVcXtOAw,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOMn,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI,ContextMenu=xlfPKQoEvBDumgRHYsyGedLVcXtOTj)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAa:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['mode'] ='ORI_PROGRAM' 
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['page'] =xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz='[B]%s >>[/B]'%'다음 페이지'
   xlfPKQoEvBDumgRHYsyGedLVcXtOMi=xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOMi,img=xlfPKQoEvBDumgRHYsyGedLVcXtOFr,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  xbmcplugin.setContent(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,cacheToDisc=xlfPKQoEvBDumgRHYsyGedLVcXtOTr)
 def dp_Episode_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOMj=xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('programcode')
  xlfPKQoEvBDumgRHYsyGedLVcXtOAz =xlfPKQoEvBDumgRHYsyGedLVcXtOTw(xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('page'))
  xlfPKQoEvBDumgRHYsyGedLVcXtOMw,xlfPKQoEvBDumgRHYsyGedLVcXtOAa,xlfPKQoEvBDumgRHYsyGedLVcXtOMS=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.GetEpisodeList(xlfPKQoEvBDumgRHYsyGedLVcXtOMj,xlfPKQoEvBDumgRHYsyGedLVcXtOAz,orderby=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_winEpisodeOrderby())
  for xlfPKQoEvBDumgRHYsyGedLVcXtOMr in xlfPKQoEvBDumgRHYsyGedLVcXtOMw:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz =xlfPKQoEvBDumgRHYsyGedLVcXtOMr.get('title')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMi =xlfPKQoEvBDumgRHYsyGedLVcXtOMr.get('subtitle')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAw =xlfPKQoEvBDumgRHYsyGedLVcXtOMr.get('thumbnail')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAS =xlfPKQoEvBDumgRHYsyGedLVcXtOMr.get('synopsis')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMI=xlfPKQoEvBDumgRHYsyGedLVcXtOMr.get('info_title')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMk =xlfPKQoEvBDumgRHYsyGedLVcXtOMr.get('aired')
   xlfPKQoEvBDumgRHYsyGedLVcXtOCU =xlfPKQoEvBDumgRHYsyGedLVcXtOMr.get('studio')
   xlfPKQoEvBDumgRHYsyGedLVcXtOCF =xlfPKQoEvBDumgRHYsyGedLVcXtOMr.get('frequency')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMn={'mediatype':'episode','title':xlfPKQoEvBDumgRHYsyGedLVcXtOMI,'aired':xlfPKQoEvBDumgRHYsyGedLVcXtOMk,'studio':xlfPKQoEvBDumgRHYsyGedLVcXtOCU,'episode':xlfPKQoEvBDumgRHYsyGedLVcXtOCF,'plot':xlfPKQoEvBDumgRHYsyGedLVcXtOAS}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'VOD','mediacode':xlfPKQoEvBDumgRHYsyGedLVcXtOMr.get('episode'),'stype':'vod','programcode':xlfPKQoEvBDumgRHYsyGedLVcXtOMj,'title':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'thumbnail':xlfPKQoEvBDumgRHYsyGedLVcXtOAw}
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOMi,img=xlfPKQoEvBDumgRHYsyGedLVcXtOAw,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOMn,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTr,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAz==1:
   xlfPKQoEvBDumgRHYsyGedLVcXtOMn={'plot':'정렬순서를 변경합니다.'}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['mode'] ='ORDER_BY' 
   if xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_winEpisodeOrderby()=='desc':
    xlfPKQoEvBDumgRHYsyGedLVcXtOFz='정렬순서변경 : 최신화부터 -> 1회부터'
    xlfPKQoEvBDumgRHYsyGedLVcXtOFI['orderby']='asc'
   else:
    xlfPKQoEvBDumgRHYsyGedLVcXtOFz='정렬순서변경 : 1회부터 -> 최신화부터'
    xlfPKQoEvBDumgRHYsyGedLVcXtOFI['orderby']='desc'
   xlfPKQoEvBDumgRHYsyGedLVcXtOFr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel='',img=xlfPKQoEvBDumgRHYsyGedLVcXtOFr,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOMn,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTr,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI,isLink=xlfPKQoEvBDumgRHYsyGedLVcXtOTS)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAa:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['mode'] ='EPISODE' 
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['programcode']=xlfPKQoEvBDumgRHYsyGedLVcXtOMj
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['page'] =xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz='[B]%s >>[/B]'%'다음 페이지'
   xlfPKQoEvBDumgRHYsyGedLVcXtOMi=xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOMi,img=xlfPKQoEvBDumgRHYsyGedLVcXtOFr,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  xbmcplugin.setContent(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,'episodes')
  if xlfPKQoEvBDumgRHYsyGedLVcXtOpU(xlfPKQoEvBDumgRHYsyGedLVcXtOMw)>0:xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,cacheToDisc=xlfPKQoEvBDumgRHYsyGedLVcXtOTS)
 def dp_setEpOrderby(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOFJ =xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('orderby')
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.set_winEpisodeOrderby(xlfPKQoEvBDumgRHYsyGedLVcXtOFJ)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOMT =xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('stype')
  xlfPKQoEvBDumgRHYsyGedLVcXtOFJ =xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('orderby')
  xlfPKQoEvBDumgRHYsyGedLVcXtOAz=xlfPKQoEvBDumgRHYsyGedLVcXtOTw(xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('page'))
  xlfPKQoEvBDumgRHYsyGedLVcXtOCA,xlfPKQoEvBDumgRHYsyGedLVcXtOAa=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.GetMovieList(xlfPKQoEvBDumgRHYsyGedLVcXtOMT,xlfPKQoEvBDumgRHYsyGedLVcXtOFJ,xlfPKQoEvBDumgRHYsyGedLVcXtOAz)
  for xlfPKQoEvBDumgRHYsyGedLVcXtOCM in xlfPKQoEvBDumgRHYsyGedLVcXtOCA:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('title')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAw =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('thumbnail')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAS =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('synopsis')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMI =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('info_title')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMF =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('year')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAI =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('cast')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAk =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('director')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMU =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('info_genre')
   xlfPKQoEvBDumgRHYsyGedLVcXtOCn =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('duration')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMC =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('premiered')
   xlfPKQoEvBDumgRHYsyGedLVcXtOCU =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('studio')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMA =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('mpaa')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMn={'mediatype':'movie','title':xlfPKQoEvBDumgRHYsyGedLVcXtOMI,'year':xlfPKQoEvBDumgRHYsyGedLVcXtOMF,'cast':xlfPKQoEvBDumgRHYsyGedLVcXtOAI,'director':xlfPKQoEvBDumgRHYsyGedLVcXtOAk,'genre':xlfPKQoEvBDumgRHYsyGedLVcXtOMU,'duration':xlfPKQoEvBDumgRHYsyGedLVcXtOCn,'premiered':xlfPKQoEvBDumgRHYsyGedLVcXtOMC,'studio':xlfPKQoEvBDumgRHYsyGedLVcXtOCU,'mpaa':xlfPKQoEvBDumgRHYsyGedLVcXtOMA,'plot':xlfPKQoEvBDumgRHYsyGedLVcXtOAS}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'MOVIE','mediacode':xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('moviecode'),'stype':'movie','title':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'thumbnail':xlfPKQoEvBDumgRHYsyGedLVcXtOAw}
   if xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_makebookmark():
    xlfPKQoEvBDumgRHYsyGedLVcXtOMJ={'videoid':xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('moviecode'),'vidtype':'movie','vtitle':xlfPKQoEvBDumgRHYsyGedLVcXtOMI,'vsubtitle':'',}
    xlfPKQoEvBDumgRHYsyGedLVcXtOMW=json.dumps(xlfPKQoEvBDumgRHYsyGedLVcXtOMJ)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMW=urllib.parse.quote(xlfPKQoEvBDumgRHYsyGedLVcXtOMW)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMz='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(xlfPKQoEvBDumgRHYsyGedLVcXtOMW)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMb=[('(통합) 찜 영상에 추가',xlfPKQoEvBDumgRHYsyGedLVcXtOMz)]
   else:
    xlfPKQoEvBDumgRHYsyGedLVcXtOMb=xlfPKQoEvBDumgRHYsyGedLVcXtOTj
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel='',img=xlfPKQoEvBDumgRHYsyGedLVcXtOAw,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOMn,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTr,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI,ContextMenu=xlfPKQoEvBDumgRHYsyGedLVcXtOMb)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAa:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['mode'] ='MOVIE_SUB' 
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['orderby']=xlfPKQoEvBDumgRHYsyGedLVcXtOFJ
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['stype'] =xlfPKQoEvBDumgRHYsyGedLVcXtOMT
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['page'] =xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz='[B]%s >>[/B]'%'다음 페이지'
   xlfPKQoEvBDumgRHYsyGedLVcXtOMi=xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOMi,img=xlfPKQoEvBDumgRHYsyGedLVcXtOFr,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  xbmcplugin.setContent(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,'movies')
  xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,cacheToDisc=xlfPKQoEvBDumgRHYsyGedLVcXtOTr)
 def dp_4K_Movie_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOAz=xlfPKQoEvBDumgRHYsyGedLVcXtOTw(xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('page'))
  xlfPKQoEvBDumgRHYsyGedLVcXtOCA,xlfPKQoEvBDumgRHYsyGedLVcXtOAa=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.Get_UHD_MovieList(xlfPKQoEvBDumgRHYsyGedLVcXtOAz)
  for xlfPKQoEvBDumgRHYsyGedLVcXtOCM in xlfPKQoEvBDumgRHYsyGedLVcXtOCA:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('title')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAw =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('thumbnail')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAS =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('synopsis')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMI =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('info_title')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMF =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('year')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAI =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('cast')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAk =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('director')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMU =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('info_genre')
   xlfPKQoEvBDumgRHYsyGedLVcXtOCn =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('duration')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMC =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('premiered')
   xlfPKQoEvBDumgRHYsyGedLVcXtOCU =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('studio')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMA =xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('mpaa')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMn={'mediatype':'movie','title':xlfPKQoEvBDumgRHYsyGedLVcXtOMI,'year':xlfPKQoEvBDumgRHYsyGedLVcXtOMF,'cast':xlfPKQoEvBDumgRHYsyGedLVcXtOAI,'director':xlfPKQoEvBDumgRHYsyGedLVcXtOAk,'genre':xlfPKQoEvBDumgRHYsyGedLVcXtOMU,'duration':xlfPKQoEvBDumgRHYsyGedLVcXtOCn,'premiered':xlfPKQoEvBDumgRHYsyGedLVcXtOMC,'studio':xlfPKQoEvBDumgRHYsyGedLVcXtOCU,'mpaa':xlfPKQoEvBDumgRHYsyGedLVcXtOMA,'plot':xlfPKQoEvBDumgRHYsyGedLVcXtOAS}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'MOVIE','mediacode':xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('moviecode'),'stype':'movie','title':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'thumbnail':xlfPKQoEvBDumgRHYsyGedLVcXtOAw}
   if xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_makebookmark():
    xlfPKQoEvBDumgRHYsyGedLVcXtOMJ={'videoid':xlfPKQoEvBDumgRHYsyGedLVcXtOCM.get('moviecode'),'vidtype':'movie','vtitle':xlfPKQoEvBDumgRHYsyGedLVcXtOMI,'vsubtitle':'',}
    xlfPKQoEvBDumgRHYsyGedLVcXtOMW=json.dumps(xlfPKQoEvBDumgRHYsyGedLVcXtOMJ)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMW=urllib.parse.quote(xlfPKQoEvBDumgRHYsyGedLVcXtOMW)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMz='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(xlfPKQoEvBDumgRHYsyGedLVcXtOMW)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMb=[('(통합) 찜 영상에 추가',xlfPKQoEvBDumgRHYsyGedLVcXtOMz)]
   else:
    xlfPKQoEvBDumgRHYsyGedLVcXtOMb=xlfPKQoEvBDumgRHYsyGedLVcXtOTj
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel='',img=xlfPKQoEvBDumgRHYsyGedLVcXtOAw,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOMn,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTr,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI,ContextMenu=xlfPKQoEvBDumgRHYsyGedLVcXtOMb)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAa:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['mode'] ='4K_MOVIE' 
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['page'] =xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz='[B]%s >>[/B]'%'다음 페이지'
   xlfPKQoEvBDumgRHYsyGedLVcXtOMi=xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOMi,img=xlfPKQoEvBDumgRHYsyGedLVcXtOFr,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  xbmcplugin.setContent(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,'movies')
  xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,cacheToDisc=xlfPKQoEvBDumgRHYsyGedLVcXtOTr)
 def dp_Set_Bookmark(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOCi=urllib.parse.unquote(xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('bm_param'))
  xlfPKQoEvBDumgRHYsyGedLVcXtOCi=json.loads(xlfPKQoEvBDumgRHYsyGedLVcXtOCi)
  xlfPKQoEvBDumgRHYsyGedLVcXtOCT =xlfPKQoEvBDumgRHYsyGedLVcXtOCi.get('videoid')
  xlfPKQoEvBDumgRHYsyGedLVcXtOCp =xlfPKQoEvBDumgRHYsyGedLVcXtOCi.get('vidtype')
  xlfPKQoEvBDumgRHYsyGedLVcXtOCq =xlfPKQoEvBDumgRHYsyGedLVcXtOCi.get('vtitle')
  xlfPKQoEvBDumgRHYsyGedLVcXtOCh =xlfPKQoEvBDumgRHYsyGedLVcXtOCi.get('vsubtitle')
  xlfPKQoEvBDumgRHYsyGedLVcXtOUa=xbmcgui.Dialog()
  xlfPKQoEvBDumgRHYsyGedLVcXtOAT=xlfPKQoEvBDumgRHYsyGedLVcXtOUa.yesno(__language__(30913).encode('utf8'),xlfPKQoEvBDumgRHYsyGedLVcXtOCq+' \n\n'+__language__(30914))
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAT==xlfPKQoEvBDumgRHYsyGedLVcXtOTr:return
  xlfPKQoEvBDumgRHYsyGedLVcXtOCN=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.GetBookmarkInfo(xlfPKQoEvBDumgRHYsyGedLVcXtOCT,xlfPKQoEvBDumgRHYsyGedLVcXtOCp)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOCh!='':
   xlfPKQoEvBDumgRHYsyGedLVcXtOCN['saveinfo']['subtitle']=xlfPKQoEvBDumgRHYsyGedLVcXtOCh 
   if xlfPKQoEvBDumgRHYsyGedLVcXtOCp=='tvshow':xlfPKQoEvBDumgRHYsyGedLVcXtOCN['saveinfo']['infoLabels']['studio']=xlfPKQoEvBDumgRHYsyGedLVcXtOCh 
  xlfPKQoEvBDumgRHYsyGedLVcXtOCJ=json.dumps(xlfPKQoEvBDumgRHYsyGedLVcXtOCN)
  xlfPKQoEvBDumgRHYsyGedLVcXtOCJ=urllib.parse.quote(xlfPKQoEvBDumgRHYsyGedLVcXtOCJ)
  xlfPKQoEvBDumgRHYsyGedLVcXtOMz ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(xlfPKQoEvBDumgRHYsyGedLVcXtOCJ)
  xbmc.executebuiltin(xlfPKQoEvBDumgRHYsyGedLVcXtOMz)
 def dp_Search_Group(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  if 'search_key' in xlfPKQoEvBDumgRHYsyGedLVcXtOAW:
   xlfPKQoEvBDumgRHYsyGedLVcXtOCW=xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('search_key')
  else:
   xlfPKQoEvBDumgRHYsyGedLVcXtOCW=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not xlfPKQoEvBDumgRHYsyGedLVcXtOCW:
    return
  for xlfPKQoEvBDumgRHYsyGedLVcXtOAJ in xlfPKQoEvBDumgRHYsyGedLVcXtOUn:
   xlfPKQoEvBDumgRHYsyGedLVcXtOCz =xlfPKQoEvBDumgRHYsyGedLVcXtOAJ.get('mode')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAh=xlfPKQoEvBDumgRHYsyGedLVcXtOAJ.get('stype')
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz=xlfPKQoEvBDumgRHYsyGedLVcXtOAJ.get('title')
   (xlfPKQoEvBDumgRHYsyGedLVcXtOCb,xlfPKQoEvBDumgRHYsyGedLVcXtOAa)=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.GetSearchList(xlfPKQoEvBDumgRHYsyGedLVcXtOCW,1,xlfPKQoEvBDumgRHYsyGedLVcXtOAh)
   xlfPKQoEvBDumgRHYsyGedLVcXtOCa={'plot':'검색어 : '+xlfPKQoEvBDumgRHYsyGedLVcXtOCW+'\n\n'+xlfPKQoEvBDumgRHYsyGedLVcXtOUN.Search_FreeList(xlfPKQoEvBDumgRHYsyGedLVcXtOCb)}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':xlfPKQoEvBDumgRHYsyGedLVcXtOCz,'stype':xlfPKQoEvBDumgRHYsyGedLVcXtOAh,'search_key':xlfPKQoEvBDumgRHYsyGedLVcXtOCW,'page':'1',}
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel='',img='',infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOCa,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOpU(xlfPKQoEvBDumgRHYsyGedLVcXtOUn)>0:xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,cacheToDisc=xlfPKQoEvBDumgRHYsyGedLVcXtOTS)
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.Save_Searched_List(xlfPKQoEvBDumgRHYsyGedLVcXtOCW)
 def Search_FreeList(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOnA):
  xlfPKQoEvBDumgRHYsyGedLVcXtOCj=''
  xlfPKQoEvBDumgRHYsyGedLVcXtOCw=7
  try:
   if xlfPKQoEvBDumgRHYsyGedLVcXtOpU(xlfPKQoEvBDumgRHYsyGedLVcXtOnA)==0:return '검색결과 없음'
   for i in xlfPKQoEvBDumgRHYsyGedLVcXtOpA(xlfPKQoEvBDumgRHYsyGedLVcXtOpU(xlfPKQoEvBDumgRHYsyGedLVcXtOnA)):
    if i>=xlfPKQoEvBDumgRHYsyGedLVcXtOCw:
     xlfPKQoEvBDumgRHYsyGedLVcXtOCj=xlfPKQoEvBDumgRHYsyGedLVcXtOCj+'...'
     break
    xlfPKQoEvBDumgRHYsyGedLVcXtOCj=xlfPKQoEvBDumgRHYsyGedLVcXtOCj+xlfPKQoEvBDumgRHYsyGedLVcXtOnA[i]['title']+'\n'
  except:
   return ''
  return xlfPKQoEvBDumgRHYsyGedLVcXtOCj
 def dp_Search_History(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOCS=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.Load_List_File('search')
  for xlfPKQoEvBDumgRHYsyGedLVcXtOCr in xlfPKQoEvBDumgRHYsyGedLVcXtOCS:
   xlfPKQoEvBDumgRHYsyGedLVcXtOCI=xlfPKQoEvBDumgRHYsyGedLVcXtOTk(urllib.parse.parse_qsl(xlfPKQoEvBDumgRHYsyGedLVcXtOCr))
   xlfPKQoEvBDumgRHYsyGedLVcXtOCk=xlfPKQoEvBDumgRHYsyGedLVcXtOCI.get('skey').strip()
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'SEARCH_GROUP','search_key':xlfPKQoEvBDumgRHYsyGedLVcXtOCk,}
   xlfPKQoEvBDumgRHYsyGedLVcXtOnU={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':xlfPKQoEvBDumgRHYsyGedLVcXtOCk,'vType':'-',}
   xlfPKQoEvBDumgRHYsyGedLVcXtOnF=urllib.parse.urlencode(xlfPKQoEvBDumgRHYsyGedLVcXtOnU)
   xlfPKQoEvBDumgRHYsyGedLVcXtOMb=[('선택된 검색어 ( %s ) 삭제'%(xlfPKQoEvBDumgRHYsyGedLVcXtOCk),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(xlfPKQoEvBDumgRHYsyGedLVcXtOnF))]
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOCk,sublabel='',img=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI,ContextMenu=xlfPKQoEvBDumgRHYsyGedLVcXtOMb)
  xlfPKQoEvBDumgRHYsyGedLVcXtOMn={'plot':'검색목록 전체를 삭제합니다.'}
  xlfPKQoEvBDumgRHYsyGedLVcXtOFz='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  xlfPKQoEvBDumgRHYsyGedLVcXtOFr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel='',img=xlfPKQoEvBDumgRHYsyGedLVcXtOFr,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOMn,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTr,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI,isLink=xlfPKQoEvBDumgRHYsyGedLVcXtOTS)
  xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,cacheToDisc=xlfPKQoEvBDumgRHYsyGedLVcXtOTr)
 def dp_Search_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOAz =xlfPKQoEvBDumgRHYsyGedLVcXtOTw(xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('page'))
  xlfPKQoEvBDumgRHYsyGedLVcXtOAh =xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('stype')
  if 'search_key' in xlfPKQoEvBDumgRHYsyGedLVcXtOAW:
   xlfPKQoEvBDumgRHYsyGedLVcXtOCW=xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('search_key')
  else:
   xlfPKQoEvBDumgRHYsyGedLVcXtOCW=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not xlfPKQoEvBDumgRHYsyGedLVcXtOCW:
    xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle)
    return
  xlfPKQoEvBDumgRHYsyGedLVcXtOCb,xlfPKQoEvBDumgRHYsyGedLVcXtOAa=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.GetSearchList(xlfPKQoEvBDumgRHYsyGedLVcXtOCW,xlfPKQoEvBDumgRHYsyGedLVcXtOAz,xlfPKQoEvBDumgRHYsyGedLVcXtOAh)
  for xlfPKQoEvBDumgRHYsyGedLVcXtOnA in xlfPKQoEvBDumgRHYsyGedLVcXtOCb:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz =xlfPKQoEvBDumgRHYsyGedLVcXtOnA.get('title')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAw =xlfPKQoEvBDumgRHYsyGedLVcXtOnA.get('thumbnail')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAS =xlfPKQoEvBDumgRHYsyGedLVcXtOnA.get('synopsis')
   xlfPKQoEvBDumgRHYsyGedLVcXtOnM =xlfPKQoEvBDumgRHYsyGedLVcXtOnA.get('program')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAI =xlfPKQoEvBDumgRHYsyGedLVcXtOnA.get('cast')
   xlfPKQoEvBDumgRHYsyGedLVcXtOAk =xlfPKQoEvBDumgRHYsyGedLVcXtOnA.get('director')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMU=xlfPKQoEvBDumgRHYsyGedLVcXtOnA.get('info_genre')
   xlfPKQoEvBDumgRHYsyGedLVcXtOCn =xlfPKQoEvBDumgRHYsyGedLVcXtOnA.get('duration')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMA =xlfPKQoEvBDumgRHYsyGedLVcXtOnA.get('mpaa')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMF =xlfPKQoEvBDumgRHYsyGedLVcXtOnA.get('year')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMk =xlfPKQoEvBDumgRHYsyGedLVcXtOnA.get('aired')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMn={'mediatype':'tvshow' if xlfPKQoEvBDumgRHYsyGedLVcXtOAh=='vod' else 'movie','title':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'cast':xlfPKQoEvBDumgRHYsyGedLVcXtOAI,'director':xlfPKQoEvBDumgRHYsyGedLVcXtOAk,'genre':xlfPKQoEvBDumgRHYsyGedLVcXtOMU,'duration':xlfPKQoEvBDumgRHYsyGedLVcXtOCn,'mpaa':xlfPKQoEvBDumgRHYsyGedLVcXtOMA,'year':xlfPKQoEvBDumgRHYsyGedLVcXtOMF,'aired':xlfPKQoEvBDumgRHYsyGedLVcXtOMk,'plot':'%s\n\n%s'%(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,xlfPKQoEvBDumgRHYsyGedLVcXtOAS)}
   if xlfPKQoEvBDumgRHYsyGedLVcXtOAh=='vod':
    xlfPKQoEvBDumgRHYsyGedLVcXtOCT=xlfPKQoEvBDumgRHYsyGedLVcXtOnA.get('program')
    xlfPKQoEvBDumgRHYsyGedLVcXtOCp='tvshow'
    xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'EPISODE','programcode':xlfPKQoEvBDumgRHYsyGedLVcXtOCT,'page':'1',}
    xlfPKQoEvBDumgRHYsyGedLVcXtOFk=xlfPKQoEvBDumgRHYsyGedLVcXtOTS
   else:
    xlfPKQoEvBDumgRHYsyGedLVcXtOCT=xlfPKQoEvBDumgRHYsyGedLVcXtOnA.get('movie')
    xlfPKQoEvBDumgRHYsyGedLVcXtOCp='movie'
    xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'MOVIE','mediacode':xlfPKQoEvBDumgRHYsyGedLVcXtOCT,'stype':'movie','title':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'thumbnail':xlfPKQoEvBDumgRHYsyGedLVcXtOAw,}
    xlfPKQoEvBDumgRHYsyGedLVcXtOFk=xlfPKQoEvBDumgRHYsyGedLVcXtOTr
   if xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_makebookmark():
    xlfPKQoEvBDumgRHYsyGedLVcXtOMJ={'videoid':xlfPKQoEvBDumgRHYsyGedLVcXtOCT,'vidtype':xlfPKQoEvBDumgRHYsyGedLVcXtOCp,'vtitle':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'vsubtitle':'',}
    xlfPKQoEvBDumgRHYsyGedLVcXtOMW=json.dumps(xlfPKQoEvBDumgRHYsyGedLVcXtOMJ)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMW=urllib.parse.quote(xlfPKQoEvBDumgRHYsyGedLVcXtOMW)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMz='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(xlfPKQoEvBDumgRHYsyGedLVcXtOMW)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMb=[('(통합) 찜 영상에 추가',xlfPKQoEvBDumgRHYsyGedLVcXtOMz)]
   else:
    xlfPKQoEvBDumgRHYsyGedLVcXtOMb=xlfPKQoEvBDumgRHYsyGedLVcXtOTj
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel='',img=xlfPKQoEvBDumgRHYsyGedLVcXtOAw,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOMn,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOFk,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI,isLink=xlfPKQoEvBDumgRHYsyGedLVcXtOTr,ContextMenu=xlfPKQoEvBDumgRHYsyGedLVcXtOMb)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAa:
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['mode'] ='SEARCH' 
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['search_key']=xlfPKQoEvBDumgRHYsyGedLVcXtOCW
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI['page'] =xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz='[B]%s >>[/B]'%'다음 페이지'
   xlfPKQoEvBDumgRHYsyGedLVcXtOMi=xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOAz+1)
   xlfPKQoEvBDumgRHYsyGedLVcXtOFr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOMi,img=xlfPKQoEvBDumgRHYsyGedLVcXtOFr,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAh=='movie':xbmcplugin.setContent(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,'movies')
  else:xbmcplugin.setContent(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,cacheToDisc=xlfPKQoEvBDumgRHYsyGedLVcXtOTr)
 def dp_History_Remove(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOnC=xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('delType')
  xlfPKQoEvBDumgRHYsyGedLVcXtOni =xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('sKey')
  xlfPKQoEvBDumgRHYsyGedLVcXtOnT =xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('vType')
  xlfPKQoEvBDumgRHYsyGedLVcXtOUa=xbmcgui.Dialog()
  if xlfPKQoEvBDumgRHYsyGedLVcXtOnC=='SEARCH_ALL':
   xlfPKQoEvBDumgRHYsyGedLVcXtOAT=xlfPKQoEvBDumgRHYsyGedLVcXtOUa.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOnC=='SEARCH_ONE':
   xlfPKQoEvBDumgRHYsyGedLVcXtOAT=xlfPKQoEvBDumgRHYsyGedLVcXtOUa.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOnC=='WATCH_ALL':
   xlfPKQoEvBDumgRHYsyGedLVcXtOAT=xlfPKQoEvBDumgRHYsyGedLVcXtOUa.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOnC=='WATCH_ONE':
   xlfPKQoEvBDumgRHYsyGedLVcXtOAT=xlfPKQoEvBDumgRHYsyGedLVcXtOUa.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAT==xlfPKQoEvBDumgRHYsyGedLVcXtOTr:sys.exit()
  if xlfPKQoEvBDumgRHYsyGedLVcXtOnC=='SEARCH_ALL':
   if os.path.isfile(xlfPKQoEvBDumgRHYsyGedLVcXtOUh):os.remove(xlfPKQoEvBDumgRHYsyGedLVcXtOUh)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOnC=='SEARCH_ONE':
   try:
    xlfPKQoEvBDumgRHYsyGedLVcXtOnp=xlfPKQoEvBDumgRHYsyGedLVcXtOUh
    xlfPKQoEvBDumgRHYsyGedLVcXtOnq=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.Load_List_File('search') 
    fp=xlfPKQoEvBDumgRHYsyGedLVcXtOpM(xlfPKQoEvBDumgRHYsyGedLVcXtOnp,'w',-1,'utf-8')
    for xlfPKQoEvBDumgRHYsyGedLVcXtOnh in xlfPKQoEvBDumgRHYsyGedLVcXtOnq:
     xlfPKQoEvBDumgRHYsyGedLVcXtOnN=xlfPKQoEvBDumgRHYsyGedLVcXtOTk(urllib.parse.parse_qsl(xlfPKQoEvBDumgRHYsyGedLVcXtOnh))
     xlfPKQoEvBDumgRHYsyGedLVcXtOnJ=xlfPKQoEvBDumgRHYsyGedLVcXtOnN.get('skey').strip()
     if xlfPKQoEvBDumgRHYsyGedLVcXtOni!=xlfPKQoEvBDumgRHYsyGedLVcXtOnJ:
      fp.write(xlfPKQoEvBDumgRHYsyGedLVcXtOnh)
    fp.close()
   except:
    xlfPKQoEvBDumgRHYsyGedLVcXtOTj
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOnC=='WATCH_ALL':
   xlfPKQoEvBDumgRHYsyGedLVcXtOnp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%xlfPKQoEvBDumgRHYsyGedLVcXtOnT))
   if os.path.isfile(xlfPKQoEvBDumgRHYsyGedLVcXtOnp):os.remove(xlfPKQoEvBDumgRHYsyGedLVcXtOnp)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOnC=='WATCH_ONE':
   xlfPKQoEvBDumgRHYsyGedLVcXtOnp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%xlfPKQoEvBDumgRHYsyGedLVcXtOnT))
   try:
    xlfPKQoEvBDumgRHYsyGedLVcXtOnq=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.Load_List_File(xlfPKQoEvBDumgRHYsyGedLVcXtOnT) 
    fp=xlfPKQoEvBDumgRHYsyGedLVcXtOpM(xlfPKQoEvBDumgRHYsyGedLVcXtOnp,'w',-1,'utf-8')
    for xlfPKQoEvBDumgRHYsyGedLVcXtOnh in xlfPKQoEvBDumgRHYsyGedLVcXtOnq:
     xlfPKQoEvBDumgRHYsyGedLVcXtOnN=xlfPKQoEvBDumgRHYsyGedLVcXtOTk(urllib.parse.parse_qsl(xlfPKQoEvBDumgRHYsyGedLVcXtOnh))
     xlfPKQoEvBDumgRHYsyGedLVcXtOnJ=xlfPKQoEvBDumgRHYsyGedLVcXtOnN.get('code').strip()
     if xlfPKQoEvBDumgRHYsyGedLVcXtOni!=xlfPKQoEvBDumgRHYsyGedLVcXtOnJ:
      fp.write(xlfPKQoEvBDumgRHYsyGedLVcXtOnh)
    fp.close()
   except:
    xlfPKQoEvBDumgRHYsyGedLVcXtOTj
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAh): 
  try:
   if xlfPKQoEvBDumgRHYsyGedLVcXtOAh=='search':
    xlfPKQoEvBDumgRHYsyGedLVcXtOnp=xlfPKQoEvBDumgRHYsyGedLVcXtOUh
   elif xlfPKQoEvBDumgRHYsyGedLVcXtOAh in['vod','movie']:
    xlfPKQoEvBDumgRHYsyGedLVcXtOnp=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%xlfPKQoEvBDumgRHYsyGedLVcXtOAh))
   else:
    return[]
   fp=xlfPKQoEvBDumgRHYsyGedLVcXtOpM(xlfPKQoEvBDumgRHYsyGedLVcXtOnp,'r',-1,'utf-8')
   xlfPKQoEvBDumgRHYsyGedLVcXtOnW=fp.readlines()
   fp.close()
  except:
   xlfPKQoEvBDumgRHYsyGedLVcXtOnW=[]
  return xlfPKQoEvBDumgRHYsyGedLVcXtOnW
 def Save_Watched_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAh,xlfPKQoEvBDumgRHYsyGedLVcXtOUz):
  try:
   xlfPKQoEvBDumgRHYsyGedLVcXtOnz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%xlfPKQoEvBDumgRHYsyGedLVcXtOAh))
   xlfPKQoEvBDumgRHYsyGedLVcXtOnq=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.Load_List_File(xlfPKQoEvBDumgRHYsyGedLVcXtOAh) 
   fp=xlfPKQoEvBDumgRHYsyGedLVcXtOpM(xlfPKQoEvBDumgRHYsyGedLVcXtOnz,'w',-1,'utf-8')
   xlfPKQoEvBDumgRHYsyGedLVcXtOnb=urllib.parse.urlencode(xlfPKQoEvBDumgRHYsyGedLVcXtOUz)
   xlfPKQoEvBDumgRHYsyGedLVcXtOnb=xlfPKQoEvBDumgRHYsyGedLVcXtOnb+'\n'
   fp.write(xlfPKQoEvBDumgRHYsyGedLVcXtOnb)
   xlfPKQoEvBDumgRHYsyGedLVcXtOna=0
   for xlfPKQoEvBDumgRHYsyGedLVcXtOnh in xlfPKQoEvBDumgRHYsyGedLVcXtOnq:
    xlfPKQoEvBDumgRHYsyGedLVcXtOnN=xlfPKQoEvBDumgRHYsyGedLVcXtOTk(urllib.parse.parse_qsl(xlfPKQoEvBDumgRHYsyGedLVcXtOnh))
    xlfPKQoEvBDumgRHYsyGedLVcXtOnj=xlfPKQoEvBDumgRHYsyGedLVcXtOUz.get('code').strip()
    xlfPKQoEvBDumgRHYsyGedLVcXtOnw=xlfPKQoEvBDumgRHYsyGedLVcXtOnN.get('code').strip()
    if xlfPKQoEvBDumgRHYsyGedLVcXtOAh=='vod' and xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_direct_replay()==xlfPKQoEvBDumgRHYsyGedLVcXtOTS:
     xlfPKQoEvBDumgRHYsyGedLVcXtOnj=xlfPKQoEvBDumgRHYsyGedLVcXtOUz.get('videoid').strip()
     xlfPKQoEvBDumgRHYsyGedLVcXtOnw=xlfPKQoEvBDumgRHYsyGedLVcXtOnN.get('videoid').strip()if xlfPKQoEvBDumgRHYsyGedLVcXtOnw!=xlfPKQoEvBDumgRHYsyGedLVcXtOTj else '-'
    if xlfPKQoEvBDumgRHYsyGedLVcXtOnj!=xlfPKQoEvBDumgRHYsyGedLVcXtOnw:
     fp.write(xlfPKQoEvBDumgRHYsyGedLVcXtOnh)
     xlfPKQoEvBDumgRHYsyGedLVcXtOna+=1
     if xlfPKQoEvBDumgRHYsyGedLVcXtOna>=50:break
   fp.close()
  except:
   xlfPKQoEvBDumgRHYsyGedLVcXtOTj
 def dp_Watch_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOAh =xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('stype')
  xlfPKQoEvBDumgRHYsyGedLVcXtOFh=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_direct_replay()
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAh=='-':
   for xlfPKQoEvBDumgRHYsyGedLVcXtOAJ in xlfPKQoEvBDumgRHYsyGedLVcXtOUC:
    xlfPKQoEvBDumgRHYsyGedLVcXtOFz=xlfPKQoEvBDumgRHYsyGedLVcXtOAJ.get('title')
    xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':xlfPKQoEvBDumgRHYsyGedLVcXtOAJ.get('mode'),'stype':xlfPKQoEvBDumgRHYsyGedLVcXtOAJ.get('stype')}
    xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel='',img='',infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOTj,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTS,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
   if xlfPKQoEvBDumgRHYsyGedLVcXtOpU(xlfPKQoEvBDumgRHYsyGedLVcXtOUC)>0:xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle)
  else:
   xlfPKQoEvBDumgRHYsyGedLVcXtOnS=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.Load_List_File(xlfPKQoEvBDumgRHYsyGedLVcXtOAh)
   for xlfPKQoEvBDumgRHYsyGedLVcXtOnr in xlfPKQoEvBDumgRHYsyGedLVcXtOnS:
    xlfPKQoEvBDumgRHYsyGedLVcXtOCI=xlfPKQoEvBDumgRHYsyGedLVcXtOTk(urllib.parse.parse_qsl(xlfPKQoEvBDumgRHYsyGedLVcXtOnr))
    xlfPKQoEvBDumgRHYsyGedLVcXtOnI =xlfPKQoEvBDumgRHYsyGedLVcXtOCI.get('code').strip()
    xlfPKQoEvBDumgRHYsyGedLVcXtOFz =xlfPKQoEvBDumgRHYsyGedLVcXtOCI.get('title').strip()
    xlfPKQoEvBDumgRHYsyGedLVcXtOAw=xlfPKQoEvBDumgRHYsyGedLVcXtOCI.get('img').strip()
    xlfPKQoEvBDumgRHYsyGedLVcXtOCT =xlfPKQoEvBDumgRHYsyGedLVcXtOCI.get('videoid').strip()
    try:
     xlfPKQoEvBDumgRHYsyGedLVcXtOAw=xlfPKQoEvBDumgRHYsyGedLVcXtOAw.replace('\'','\"')
     xlfPKQoEvBDumgRHYsyGedLVcXtOAw=json.loads(xlfPKQoEvBDumgRHYsyGedLVcXtOAw)
    except:
     xlfPKQoEvBDumgRHYsyGedLVcXtOTj
    xlfPKQoEvBDumgRHYsyGedLVcXtOMn={}
    xlfPKQoEvBDumgRHYsyGedLVcXtOMn['plot']=xlfPKQoEvBDumgRHYsyGedLVcXtOFz
    if xlfPKQoEvBDumgRHYsyGedLVcXtOAh=='vod':
     if xlfPKQoEvBDumgRHYsyGedLVcXtOFh==xlfPKQoEvBDumgRHYsyGedLVcXtOTr or xlfPKQoEvBDumgRHYsyGedLVcXtOCT==xlfPKQoEvBDumgRHYsyGedLVcXtOTj:
      xlfPKQoEvBDumgRHYsyGedLVcXtOMn['mediatype']='tvshow'
      xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'EPISODE','programcode':xlfPKQoEvBDumgRHYsyGedLVcXtOnI,'page':'1'}
      xlfPKQoEvBDumgRHYsyGedLVcXtOFk=xlfPKQoEvBDumgRHYsyGedLVcXtOTS
     else:
      xlfPKQoEvBDumgRHYsyGedLVcXtOMn['mediatype']='episode'
      xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'VOD','mediacode':xlfPKQoEvBDumgRHYsyGedLVcXtOCT,'stype':'vod','programcode':xlfPKQoEvBDumgRHYsyGedLVcXtOnI,'title':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'thumbnail':xlfPKQoEvBDumgRHYsyGedLVcXtOAw}
      xlfPKQoEvBDumgRHYsyGedLVcXtOFk=xlfPKQoEvBDumgRHYsyGedLVcXtOTr
    else:
     xlfPKQoEvBDumgRHYsyGedLVcXtOMn['mediatype']='movie'
     xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'MOVIE','mediacode':xlfPKQoEvBDumgRHYsyGedLVcXtOnI,'stype':'movie','title':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'thumbnail':xlfPKQoEvBDumgRHYsyGedLVcXtOAw}
     xlfPKQoEvBDumgRHYsyGedLVcXtOFk=xlfPKQoEvBDumgRHYsyGedLVcXtOTr
    xlfPKQoEvBDumgRHYsyGedLVcXtOnU={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':xlfPKQoEvBDumgRHYsyGedLVcXtOnI,'vType':xlfPKQoEvBDumgRHYsyGedLVcXtOAh,}
    xlfPKQoEvBDumgRHYsyGedLVcXtOnF=urllib.parse.urlencode(xlfPKQoEvBDumgRHYsyGedLVcXtOnU)
    xlfPKQoEvBDumgRHYsyGedLVcXtOMb=[('선택된 시청이력 ( %s ) 삭제'%(xlfPKQoEvBDumgRHYsyGedLVcXtOFz),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(xlfPKQoEvBDumgRHYsyGedLVcXtOnF))]
    xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel='',img=xlfPKQoEvBDumgRHYsyGedLVcXtOAw,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOMn,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOFk,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI,ContextMenu=xlfPKQoEvBDumgRHYsyGedLVcXtOMb)
   xlfPKQoEvBDumgRHYsyGedLVcXtOMn={'plot':'시청목록을 삭제합니다.'}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':xlfPKQoEvBDumgRHYsyGedLVcXtOAh,}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFr=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel='',img=xlfPKQoEvBDumgRHYsyGedLVcXtOFr,infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOMn,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTr,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI,isLink=xlfPKQoEvBDumgRHYsyGedLVcXtOTS)
   if xlfPKQoEvBDumgRHYsyGedLVcXtOAh=='movie':xbmcplugin.setContent(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,'movies')
   else:xbmcplugin.setContent(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,cacheToDisc=xlfPKQoEvBDumgRHYsyGedLVcXtOTr)
 def Save_Searched_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOCW):
  try:
   xlfPKQoEvBDumgRHYsyGedLVcXtOnk=xlfPKQoEvBDumgRHYsyGedLVcXtOUh
   xlfPKQoEvBDumgRHYsyGedLVcXtOnq=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.Load_List_File('search') 
   xlfPKQoEvBDumgRHYsyGedLVcXtOiU={'skey':xlfPKQoEvBDumgRHYsyGedLVcXtOCW.strip()}
   fp=xlfPKQoEvBDumgRHYsyGedLVcXtOpM(xlfPKQoEvBDumgRHYsyGedLVcXtOnk,'w',-1,'utf-8')
   xlfPKQoEvBDumgRHYsyGedLVcXtOnb=urllib.parse.urlencode(xlfPKQoEvBDumgRHYsyGedLVcXtOiU)
   xlfPKQoEvBDumgRHYsyGedLVcXtOnb=xlfPKQoEvBDumgRHYsyGedLVcXtOnb+'\n'
   fp.write(xlfPKQoEvBDumgRHYsyGedLVcXtOnb)
   xlfPKQoEvBDumgRHYsyGedLVcXtOna=0
   for xlfPKQoEvBDumgRHYsyGedLVcXtOnh in xlfPKQoEvBDumgRHYsyGedLVcXtOnq:
    xlfPKQoEvBDumgRHYsyGedLVcXtOnN=xlfPKQoEvBDumgRHYsyGedLVcXtOTk(urllib.parse.parse_qsl(xlfPKQoEvBDumgRHYsyGedLVcXtOnh))
    xlfPKQoEvBDumgRHYsyGedLVcXtOnj=xlfPKQoEvBDumgRHYsyGedLVcXtOiU.get('skey').strip()
    xlfPKQoEvBDumgRHYsyGedLVcXtOnw=xlfPKQoEvBDumgRHYsyGedLVcXtOnN.get('skey').strip()
    if xlfPKQoEvBDumgRHYsyGedLVcXtOnj!=xlfPKQoEvBDumgRHYsyGedLVcXtOnw:
     fp.write(xlfPKQoEvBDumgRHYsyGedLVcXtOnh)
     xlfPKQoEvBDumgRHYsyGedLVcXtOna+=1
     if xlfPKQoEvBDumgRHYsyGedLVcXtOna>=50:break
   fp.close()
  except:
   xlfPKQoEvBDumgRHYsyGedLVcXtOTj
 def play_VIDEO(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOiF =xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('mediacode')
  xlfPKQoEvBDumgRHYsyGedLVcXtOAh =xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('stype')
  xlfPKQoEvBDumgRHYsyGedLVcXtOiA =xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('pvrmode')
  xlfPKQoEvBDumgRHYsyGedLVcXtOiM=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_selQuality(xlfPKQoEvBDumgRHYsyGedLVcXtOAh)
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(xlfPKQoEvBDumgRHYsyGedLVcXtOiF,xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOiM),xlfPKQoEvBDumgRHYsyGedLVcXtOAh,xlfPKQoEvBDumgRHYsyGedLVcXtOiA))
  xlfPKQoEvBDumgRHYsyGedLVcXtOiC=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.GetBroadURL(xlfPKQoEvBDumgRHYsyGedLVcXtOiF,xlfPKQoEvBDumgRHYsyGedLVcXtOiM,xlfPKQoEvBDumgRHYsyGedLVcXtOAh,xlfPKQoEvBDumgRHYsyGedLVcXtOiA,optUHD=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_uhd())
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.addon_log('qt, stype, url : %s - %s - %s'%(xlfPKQoEvBDumgRHYsyGedLVcXtOpF(xlfPKQoEvBDumgRHYsyGedLVcXtOiM),xlfPKQoEvBDumgRHYsyGedLVcXtOAh,xlfPKQoEvBDumgRHYsyGedLVcXtOiC['streaming_url']))
  if xlfPKQoEvBDumgRHYsyGedLVcXtOiC['streaming_url']=='':
   if xlfPKQoEvBDumgRHYsyGedLVcXtOiC['error_msg']=='':
    xlfPKQoEvBDumgRHYsyGedLVcXtOUN.addon_noti(__language__(30908).encode('utf8'))
   else:
    xlfPKQoEvBDumgRHYsyGedLVcXtOUN.addon_noti(xlfPKQoEvBDumgRHYsyGedLVcXtOiC['error_msg'].encode('utf8'))
   return
  xlfPKQoEvBDumgRHYsyGedLVcXtOin='user-agent={}'.format(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.USER_AGENT)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOiC['watermark'] !='':
   xlfPKQoEvBDumgRHYsyGedLVcXtOin='{}&x-tving-param1={}&x-tving-param2={}'.format(xlfPKQoEvBDumgRHYsyGedLVcXtOin,xlfPKQoEvBDumgRHYsyGedLVcXtOiC['watermarkKey'],xlfPKQoEvBDumgRHYsyGedLVcXtOiC['watermark'])
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.addon_log('streaming_url = {}'.format(xlfPKQoEvBDumgRHYsyGedLVcXtOiC['streaming_url']))
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.addon_log('watermark     = {}'.format(xlfPKQoEvBDumgRHYsyGedLVcXtOiC['watermark']))
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.addon_log('watermarkKey  = {}'.format(xlfPKQoEvBDumgRHYsyGedLVcXtOiC['watermarkKey']))
  xlfPKQoEvBDumgRHYsyGedLVcXtOiT =xlfPKQoEvBDumgRHYsyGedLVcXtOTr
  xlfPKQoEvBDumgRHYsyGedLVcXtOip =xlfPKQoEvBDumgRHYsyGedLVcXtOiC['streaming_url'].find('Policy=')
  if xlfPKQoEvBDumgRHYsyGedLVcXtOip!=-1:
   xlfPKQoEvBDumgRHYsyGedLVcXtOiq =xlfPKQoEvBDumgRHYsyGedLVcXtOiC['streaming_url'].split('?')[0]
   xlfPKQoEvBDumgRHYsyGedLVcXtOih=xlfPKQoEvBDumgRHYsyGedLVcXtOTk(urllib.parse.parse_qsl(urllib.parse.urlsplit(xlfPKQoEvBDumgRHYsyGedLVcXtOiC['streaming_url']).query))
   xlfPKQoEvBDumgRHYsyGedLVcXtOiN='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(xlfPKQoEvBDumgRHYsyGedLVcXtOih['Policy'],xlfPKQoEvBDumgRHYsyGedLVcXtOih['Signature'],xlfPKQoEvBDumgRHYsyGedLVcXtOih['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in xlfPKQoEvBDumgRHYsyGedLVcXtOiq:
    xlfPKQoEvBDumgRHYsyGedLVcXtOiT=xlfPKQoEvBDumgRHYsyGedLVcXtOTS
    xlfPKQoEvBDumgRHYsyGedLVcXtOiJ =xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    xlfPKQoEvBDumgRHYsyGedLVcXtOiW=xlfPKQoEvBDumgRHYsyGedLVcXtOiJ.strftime('%Y-%m-%d-%H:%M:%S')
    if xlfPKQoEvBDumgRHYsyGedLVcXtOTw(xlfPKQoEvBDumgRHYsyGedLVcXtOiW.replace('-','').replace(':',''))<xlfPKQoEvBDumgRHYsyGedLVcXtOTw(xlfPKQoEvBDumgRHYsyGedLVcXtOih['end'].replace('-','').replace(':','')):
     xlfPKQoEvBDumgRHYsyGedLVcXtOih['end']=xlfPKQoEvBDumgRHYsyGedLVcXtOiW
     xlfPKQoEvBDumgRHYsyGedLVcXtOUN.addon_noti(__language__(30915).encode('utf8'))
    xlfPKQoEvBDumgRHYsyGedLVcXtOiq ='%s?%s'%(xlfPKQoEvBDumgRHYsyGedLVcXtOiq,urllib.parse.urlencode(xlfPKQoEvBDumgRHYsyGedLVcXtOih,doseq=xlfPKQoEvBDumgRHYsyGedLVcXtOTS))
    xlfPKQoEvBDumgRHYsyGedLVcXtOiz='{}|{}&Cookie={}'.format(xlfPKQoEvBDumgRHYsyGedLVcXtOiq,xlfPKQoEvBDumgRHYsyGedLVcXtOin,xlfPKQoEvBDumgRHYsyGedLVcXtOiN)
   else:
    xlfPKQoEvBDumgRHYsyGedLVcXtOiz='{}|{}&Cookie={}'.format(xlfPKQoEvBDumgRHYsyGedLVcXtOiC['streaming_url'],xlfPKQoEvBDumgRHYsyGedLVcXtOin,xlfPKQoEvBDumgRHYsyGedLVcXtOiN)
  else:
   xlfPKQoEvBDumgRHYsyGedLVcXtOiz=xlfPKQoEvBDumgRHYsyGedLVcXtOiC['streaming_url']+'|'+xlfPKQoEvBDumgRHYsyGedLVcXtOin
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.addon_log('if tmp_pos == -1')
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.addon_log(xlfPKQoEvBDumgRHYsyGedLVcXtOiz)
  xlfPKQoEvBDumgRHYsyGedLVcXtOFM,xlfPKQoEvBDumgRHYsyGedLVcXtOFC=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_proxyport()
  xlfPKQoEvBDumgRHYsyGedLVcXtOFA=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_playback()
  if xlfPKQoEvBDumgRHYsyGedLVcXtOFM and xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('mode')in['VOD','MOVIE']and xlfPKQoEvBDumgRHYsyGedLVcXtOiC['subtitleYn']==xlfPKQoEvBDumgRHYsyGedLVcXtOTS and xlfPKQoEvBDumgRHYsyGedLVcXtOiC['drm_license']!='':
   try:
    xlfPKQoEvBDumgRHYsyGedLVcXtOib=urllib.parse.urlparse(xlfPKQoEvBDumgRHYsyGedLVcXtOiz)
    xlfPKQoEvBDumgRHYsyGedLVcXtOia=xlfPKQoEvBDumgRHYsyGedLVcXtOib.scheme
    xlfPKQoEvBDumgRHYsyGedLVcXtOij=xlfPKQoEvBDumgRHYsyGedLVcXtOib.netloc
   except:
    xlfPKQoEvBDumgRHYsyGedLVcXtOia=''
    xlfPKQoEvBDumgRHYsyGedLVcXtOij=''
   xlfPKQoEvBDumgRHYsyGedLVcXtOiw={'addon':'tvingm','playOption':xlfPKQoEvBDumgRHYsyGedLVcXtOFA,'defScheme':xlfPKQoEvBDumgRHYsyGedLVcXtOia,'defNetloc':xlfPKQoEvBDumgRHYsyGedLVcXtOij,}
   xlfPKQoEvBDumgRHYsyGedLVcXtOiw=json.dumps(xlfPKQoEvBDumgRHYsyGedLVcXtOiw,separators=(',',':'))
   xlfPKQoEvBDumgRHYsyGedLVcXtOiw=base64.standard_b64encode(xlfPKQoEvBDumgRHYsyGedLVcXtOiw.encode()).decode('utf-8')
   xlfPKQoEvBDumgRHYsyGedLVcXtOiz ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(xlfPKQoEvBDumgRHYsyGedLVcXtOFC,xlfPKQoEvBDumgRHYsyGedLVcXtOiz,xlfPKQoEvBDumgRHYsyGedLVcXtOiw)
   xlfPKQoEvBDumgRHYsyGedLVcXtOin='{}&proxy-mini={}'.format(xlfPKQoEvBDumgRHYsyGedLVcXtOin,xlfPKQoEvBDumgRHYsyGedLVcXtOiw)
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.addon_log(xlfPKQoEvBDumgRHYsyGedLVcXtOiz)
  xlfPKQoEvBDumgRHYsyGedLVcXtOiS=xbmcgui.ListItem(path=xlfPKQoEvBDumgRHYsyGedLVcXtOiz)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOiC['drm_license']!='':
   xlfPKQoEvBDumgRHYsyGedLVcXtOir=xlfPKQoEvBDumgRHYsyGedLVcXtOiC['drm_license']
   xlfPKQoEvBDumgRHYsyGedLVcXtOiI ='https://cj.drmkeyserver.com/widevine_license'
   xlfPKQoEvBDumgRHYsyGedLVcXtOik ='mpd'
   xlfPKQoEvBDumgRHYsyGedLVcXtOTU ='com.widevine.alpha'
   xlfPKQoEvBDumgRHYsyGedLVcXtOTF =inputstreamhelper.Helper(xlfPKQoEvBDumgRHYsyGedLVcXtOik,drm='widevine')
   if xlfPKQoEvBDumgRHYsyGedLVcXtOTF.check_inputstream():
    xlfPKQoEvBDumgRHYsyGedLVcXtOTA={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.USER_AGENT,'AcquireLicenseAssertion':xlfPKQoEvBDumgRHYsyGedLVcXtOir,'Host':'cj.drmkeyserver.com',}
    xlfPKQoEvBDumgRHYsyGedLVcXtOTM=xlfPKQoEvBDumgRHYsyGedLVcXtOiI+'|'+urllib.parse.urlencode(xlfPKQoEvBDumgRHYsyGedLVcXtOTA)+'|R{SSM}|'
    xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setProperty('inputstream',xlfPKQoEvBDumgRHYsyGedLVcXtOTF.inputstream_addon)
    xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setProperty('inputstream.adaptive.manifest_type',xlfPKQoEvBDumgRHYsyGedLVcXtOik)
    xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setProperty('inputstream.adaptive.license_type',xlfPKQoEvBDumgRHYsyGedLVcXtOTU)
    xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setProperty('inputstream.adaptive.license_key',xlfPKQoEvBDumgRHYsyGedLVcXtOTM)
    xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setProperty('inputstream.adaptive.stream_headers',xlfPKQoEvBDumgRHYsyGedLVcXtOin)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOiT==xlfPKQoEvBDumgRHYsyGedLVcXtOTS:
   xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setContentLookup(xlfPKQoEvBDumgRHYsyGedLVcXtOTr)
   xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setMimeType('application/x-mpegURL')
   xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setProperty('inputstream','inputstream.ffmpegdirect')
   xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setProperty('ResumeTime','0')
   xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setProperty('TotalTime','10000')
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('mode')in['VOD','MOVIE']:
   xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setContentLookup(xlfPKQoEvBDumgRHYsyGedLVcXtOTr)
   xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setMimeType('application/x-mpegURL')
   xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setProperty('inputstream','inputstream.adaptive')
   xlfPKQoEvBDumgRHYsyGedLVcXtOiS.setProperty('inputstream.adaptive.manifest_type','hls')
  xbmcplugin.setResolvedUrl(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,xlfPKQoEvBDumgRHYsyGedLVcXtOTS,xlfPKQoEvBDumgRHYsyGedLVcXtOiS)
  try:
   if xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('mode')in['VOD','MOVIE']and xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('title'):
    xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'code':xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('programcode')if xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('mode')=='VOD' else xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('mediacode'),'img':xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('thumbnail'),'title':xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('title'),'videoid':xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('mediacode')}
    xlfPKQoEvBDumgRHYsyGedLVcXtOUN.Save_Watched_List(xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('stype'),xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  except:
   xlfPKQoEvBDumgRHYsyGedLVcXtOTj
 def logout(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  xlfPKQoEvBDumgRHYsyGedLVcXtOUa=xbmcgui.Dialog()
  xlfPKQoEvBDumgRHYsyGedLVcXtOAT=xlfPKQoEvBDumgRHYsyGedLVcXtOUa.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if xlfPKQoEvBDumgRHYsyGedLVcXtOAT==xlfPKQoEvBDumgRHYsyGedLVcXtOTr:sys.exit()
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.Init_TV_Total()
  if os.path.isfile(xlfPKQoEvBDumgRHYsyGedLVcXtOUq):os.remove(xlfPKQoEvBDumgRHYsyGedLVcXtOUq)
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  xlfPKQoEvBDumgRHYsyGedLVcXtOTC =xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.Get_Now_Datetime()
  xlfPKQoEvBDumgRHYsyGedLVcXtOTn=xlfPKQoEvBDumgRHYsyGedLVcXtOTC+datetime.timedelta(days=xlfPKQoEvBDumgRHYsyGedLVcXtOTw(__addon__.getSetting('cache_ttl')))
  (xlfPKQoEvBDumgRHYsyGedLVcXtOAM,xlfPKQoEvBDumgRHYsyGedLVcXtOAC,xlfPKQoEvBDumgRHYsyGedLVcXtOAn,xlfPKQoEvBDumgRHYsyGedLVcXtOAi)=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_account()
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.Save_session_acount(xlfPKQoEvBDumgRHYsyGedLVcXtOAM,xlfPKQoEvBDumgRHYsyGedLVcXtOAC,xlfPKQoEvBDumgRHYsyGedLVcXtOAn,xlfPKQoEvBDumgRHYsyGedLVcXtOAi)
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.TV['account']['token_limit']=xlfPKQoEvBDumgRHYsyGedLVcXtOTn.strftime('%Y%m%d')
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.JsonFile_Save(xlfPKQoEvBDumgRHYsyGedLVcXtOUq,xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.TV)
 def cookiefile_check(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.TV=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.JsonFile_Load(xlfPKQoEvBDumgRHYsyGedLVcXtOUq)
  if 'account' not in xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.TV:
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.Init_TV_Total()
   return xlfPKQoEvBDumgRHYsyGedLVcXtOTr
  (xlfPKQoEvBDumgRHYsyGedLVcXtOTi,xlfPKQoEvBDumgRHYsyGedLVcXtOTp,xlfPKQoEvBDumgRHYsyGedLVcXtOTq,xlfPKQoEvBDumgRHYsyGedLVcXtOTh)=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.get_settings_account()
  (xlfPKQoEvBDumgRHYsyGedLVcXtOTN,xlfPKQoEvBDumgRHYsyGedLVcXtOTJ,xlfPKQoEvBDumgRHYsyGedLVcXtOTW,xlfPKQoEvBDumgRHYsyGedLVcXtOTz)=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.Load_session_acount()
  if xlfPKQoEvBDumgRHYsyGedLVcXtOTi!=xlfPKQoEvBDumgRHYsyGedLVcXtOTN or xlfPKQoEvBDumgRHYsyGedLVcXtOTp!=xlfPKQoEvBDumgRHYsyGedLVcXtOTJ or xlfPKQoEvBDumgRHYsyGedLVcXtOTq!=xlfPKQoEvBDumgRHYsyGedLVcXtOTW or xlfPKQoEvBDumgRHYsyGedLVcXtOTh!=xlfPKQoEvBDumgRHYsyGedLVcXtOTz:
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.Init_TV_Total()
   return xlfPKQoEvBDumgRHYsyGedLVcXtOTr
  if xlfPKQoEvBDumgRHYsyGedLVcXtOTw(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>xlfPKQoEvBDumgRHYsyGedLVcXtOTw(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.TV['account']['token_limit']):
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.Init_TV_Total()
   return xlfPKQoEvBDumgRHYsyGedLVcXtOTr
  return xlfPKQoEvBDumgRHYsyGedLVcXtOTS
 def dp_Global_Search(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOCz=xlfPKQoEvBDumgRHYsyGedLVcXtOAW.get('mode')
  if xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='TOTAL_SEARCH':
   xlfPKQoEvBDumgRHYsyGedLVcXtOTb='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   xlfPKQoEvBDumgRHYsyGedLVcXtOTb='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(xlfPKQoEvBDumgRHYsyGedLVcXtOTb)
 def dp_Bookmark_Menu(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOTb='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(xlfPKQoEvBDumgRHYsyGedLVcXtOTb)
 def dp_EuroLive_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN,xlfPKQoEvBDumgRHYsyGedLVcXtOAW):
  xlfPKQoEvBDumgRHYsyGedLVcXtOAb=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.TvingObj.GetEuroChannelList()
  for xlfPKQoEvBDumgRHYsyGedLVcXtOAj in xlfPKQoEvBDumgRHYsyGedLVcXtOAb:
   xlfPKQoEvBDumgRHYsyGedLVcXtOMN =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('channel')
   xlfPKQoEvBDumgRHYsyGedLVcXtOFz =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('title')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMi =xlfPKQoEvBDumgRHYsyGedLVcXtOAj.get('subtitle')
   xlfPKQoEvBDumgRHYsyGedLVcXtOMn={'mediatype':'episode','title':xlfPKQoEvBDumgRHYsyGedLVcXtOFz,'plot':'%s\n%s'%(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,xlfPKQoEvBDumgRHYsyGedLVcXtOMi)}
   xlfPKQoEvBDumgRHYsyGedLVcXtOFI={'mode':'LIVE','mediacode':xlfPKQoEvBDumgRHYsyGedLVcXtOMN,'stype':'onair',}
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.add_dir(xlfPKQoEvBDumgRHYsyGedLVcXtOFz,sublabel=xlfPKQoEvBDumgRHYsyGedLVcXtOMi,img='',infoLabels=xlfPKQoEvBDumgRHYsyGedLVcXtOMn,isFolder=xlfPKQoEvBDumgRHYsyGedLVcXtOTr,params=xlfPKQoEvBDumgRHYsyGedLVcXtOFI)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOpU(xlfPKQoEvBDumgRHYsyGedLVcXtOAb)>0:xbmcplugin.endOfDirectory(xlfPKQoEvBDumgRHYsyGedLVcXtOUN._addon_handle,cacheToDisc=xlfPKQoEvBDumgRHYsyGedLVcXtOTr)
 def tving_main(xlfPKQoEvBDumgRHYsyGedLVcXtOUN):
  xlfPKQoEvBDumgRHYsyGedLVcXtOCz=xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params.get('mode',xlfPKQoEvBDumgRHYsyGedLVcXtOTj)
  if xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='LOGOUT':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.logout()
   return
  xlfPKQoEvBDumgRHYsyGedLVcXtOUN.login_main()
  if xlfPKQoEvBDumgRHYsyGedLVcXtOCz is xlfPKQoEvBDumgRHYsyGedLVcXtOTj:
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_Main_List()
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_Title_Group(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz in['GLOBAL_GROUP']:
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_SubTitle_Group(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='CHANNEL':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_LiveChannel_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz in['LIVE','VOD','MOVIE']:
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.play_VIDEO(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='PROGRAM':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_Program_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='4K_PROGRAM':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_4K_Program_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='ORI_PROGRAM':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_Ori_Program_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='EPISODE':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_Episode_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='MOVIE_SUB':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_Movie_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='4K_MOVIE':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_4K_Movie_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='SEARCH_GROUP':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_Search_Group(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz in['SEARCH','LOCAL_SEARCH']:
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_Search_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='WATCH':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_Watch_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_History_Remove(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='ORDER_BY':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_setEpOrderby(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='SET_BOOKMARK':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_Set_Bookmark(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz in['TOTAL_SEARCH','TOTAL_HISTORY']:
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_Global_Search(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='SEARCH_HISTORY':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_Search_History(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='MENU_BOOKMARK':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_Bookmark_Menu(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  elif xlfPKQoEvBDumgRHYsyGedLVcXtOCz=='EURO_GROUP':
   xlfPKQoEvBDumgRHYsyGedLVcXtOUN.dp_EuroLive_List(xlfPKQoEvBDumgRHYsyGedLVcXtOUN.main_params)
  else:
   xlfPKQoEvBDumgRHYsyGedLVcXtOTj
# Created by pyminifier (https://github.com/liftoff/pyminifier)
