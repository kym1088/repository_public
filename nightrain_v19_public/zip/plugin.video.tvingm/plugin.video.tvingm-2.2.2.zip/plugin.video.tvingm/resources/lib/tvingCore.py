__author__="NightRain"
TFRfexWmQBlcHGLoNzvDVhPqUdYySn=object
TFRfexWmQBlcHGLoNzvDVhPqUdYySs=None
TFRfexWmQBlcHGLoNzvDVhPqUdYySt=False
TFRfexWmQBlcHGLoNzvDVhPqUdYySX=int
TFRfexWmQBlcHGLoNzvDVhPqUdYySA=range
TFRfexWmQBlcHGLoNzvDVhPqUdYySK=True
TFRfexWmQBlcHGLoNzvDVhPqUdYySM=Exception
TFRfexWmQBlcHGLoNzvDVhPqUdYySE=print
TFRfexWmQBlcHGLoNzvDVhPqUdYySk=str
TFRfexWmQBlcHGLoNzvDVhPqUdYySj=list
TFRfexWmQBlcHGLoNzvDVhPqUdYySa=len
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
import random
TFRfexWmQBlcHGLoNzvDVhPqUdYybJ={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
class TFRfexWmQBlcHGLoNzvDVhPqUdYybO(TFRfexWmQBlcHGLoNzvDVhPqUdYySn):
 def __init__(TFRfexWmQBlcHGLoNzvDVhPqUdYybw):
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_TOKEN =''
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.POC_USERINFO =''
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_UUID ='-'
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_MAINTOKEN=''
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVIGN_COOKIEKEY=''
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_LOCKKEY =''
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.NETWORKCODE ='CSND0900'
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.OSCODE ='CSOD0900' 
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TELECODE ='CSCD0900'
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.SCREENCODE ='CSSD0100'
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.LIVE_LIMIT =23
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.VOD_LIMIT =20
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.EPISODE_LIMIT =30 
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.SEARCH_LIMIT =80 
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.MOVIE_LIMIT =18
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.API_DOMAIN ='https://api.tving.com'
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN ='https://image.tving.com'
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.SEARCH_DOMAIN ='https://search.tving.com'
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.LOGIN_DOMAIN ='https://user.tving.com'
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.URL_DOMAIN ='https://www.tving.com'
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.MOVIE_LITE =['2610061','2610161','261062']
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.DEFAULT_HEADER ={'user-agent':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.USER_AGENT}
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,jobtype,TFRfexWmQBlcHGLoNzvDVhPqUdYyOK,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,params=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,redirects=TFRfexWmQBlcHGLoNzvDVhPqUdYySt):
  TFRfexWmQBlcHGLoNzvDVhPqUdYybS=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.DEFAULT_HEADER
  if headers:TFRfexWmQBlcHGLoNzvDVhPqUdYybS.update(headers)
  if jobtype=='Get':
   TFRfexWmQBlcHGLoNzvDVhPqUdYybr=requests.get(TFRfexWmQBlcHGLoNzvDVhPqUdYyOK,params=params,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYybS,cookies=cookies,allow_redirects=redirects)
  else:
   TFRfexWmQBlcHGLoNzvDVhPqUdYybr=requests.post(TFRfexWmQBlcHGLoNzvDVhPqUdYyOK,data=payload,params=params,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYybS,cookies=cookies,allow_redirects=redirects)
  return TFRfexWmQBlcHGLoNzvDVhPqUdYybr
 def makeDefaultCookies(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,vToken=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,vUserinfo=TFRfexWmQBlcHGLoNzvDVhPqUdYySs):
  TFRfexWmQBlcHGLoNzvDVhPqUdYybn={}
  TFRfexWmQBlcHGLoNzvDVhPqUdYybn['_tving_token']=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_TOKEN if vToken==TFRfexWmQBlcHGLoNzvDVhPqUdYySs else vToken
  TFRfexWmQBlcHGLoNzvDVhPqUdYybn['POC_USERINFO']=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.POC_USERINFO if vToken==TFRfexWmQBlcHGLoNzvDVhPqUdYySs else vUserinfo
  if TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_MAINTOKEN!='':TFRfexWmQBlcHGLoNzvDVhPqUdYybn[TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GLOBAL_COOKIENM['tv_maintoken']]=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_MAINTOKEN
  if TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVIGN_COOKIEKEY!='':TFRfexWmQBlcHGLoNzvDVhPqUdYybn[TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GLOBAL_COOKIENM['tv_cookiekey']]=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVIGN_COOKIEKEY
  if TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_LOCKKEY !='':TFRfexWmQBlcHGLoNzvDVhPqUdYybn[TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GLOBAL_COOKIENM['tv_lockkey']] =TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_LOCKKEY
  return TFRfexWmQBlcHGLoNzvDVhPqUdYybn
 def getDeviceStr(TFRfexWmQBlcHGLoNzvDVhPqUdYybw):
  TFRfexWmQBlcHGLoNzvDVhPqUdYybs=[]
  TFRfexWmQBlcHGLoNzvDVhPqUdYybs.append('Windows') 
  TFRfexWmQBlcHGLoNzvDVhPqUdYybs.append('Chrome') 
  TFRfexWmQBlcHGLoNzvDVhPqUdYybs.append('ko-KR') 
  TFRfexWmQBlcHGLoNzvDVhPqUdYybs.append('undefined') 
  TFRfexWmQBlcHGLoNzvDVhPqUdYybs.append('24') 
  TFRfexWmQBlcHGLoNzvDVhPqUdYybs.append(u'한국 표준시')
  TFRfexWmQBlcHGLoNzvDVhPqUdYybs.append('undefined') 
  TFRfexWmQBlcHGLoNzvDVhPqUdYybs.append('undefined') 
  TFRfexWmQBlcHGLoNzvDVhPqUdYybs.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  TFRfexWmQBlcHGLoNzvDVhPqUdYybt=''
  for TFRfexWmQBlcHGLoNzvDVhPqUdYybX in TFRfexWmQBlcHGLoNzvDVhPqUdYybs:
   TFRfexWmQBlcHGLoNzvDVhPqUdYybt+=TFRfexWmQBlcHGLoNzvDVhPqUdYybX+'|'
  return TFRfexWmQBlcHGLoNzvDVhPqUdYybt
 def SaveCredential(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,TFRfexWmQBlcHGLoNzvDVhPqUdYybA):
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_TOKEN =TFRfexWmQBlcHGLoNzvDVhPqUdYybA.get('tving_token')
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.POC_USERINFO =TFRfexWmQBlcHGLoNzvDVhPqUdYybA.get('poc_userinfo')
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_UUID =TFRfexWmQBlcHGLoNzvDVhPqUdYybA.get('tving_uuid')
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_MAINTOKEN=TFRfexWmQBlcHGLoNzvDVhPqUdYybA.get('tving_maintoken')
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVIGN_COOKIEKEY=TFRfexWmQBlcHGLoNzvDVhPqUdYybA.get('tving_cookiekey')
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_LOCKKEY =TFRfexWmQBlcHGLoNzvDVhPqUdYybA.get('tving_lockkey')
 def LoadCredential(TFRfexWmQBlcHGLoNzvDVhPqUdYybw):
  TFRfexWmQBlcHGLoNzvDVhPqUdYybA={'tving_token':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_TOKEN,'poc_userinfo':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.POC_USERINFO,'tving_uuid':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_UUID,'tving_maintoken':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_MAINTOKEN,'tving_cookiekey':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVIGN_COOKIEKEY,'tving_lockkey':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_LOCKKEY}
  return TFRfexWmQBlcHGLoNzvDVhPqUdYybA
 def GetDefaultParams(TFRfexWmQBlcHGLoNzvDVhPqUdYybw):
  TFRfexWmQBlcHGLoNzvDVhPqUdYybK={'apiKey':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.APIKEY,'networkCode':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.NETWORKCODE,'osCode':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.OSCODE,'teleCode':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TELECODE,'screenCode':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.SCREENCODE}
  return TFRfexWmQBlcHGLoNzvDVhPqUdYybK
 def GetNoCache(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,timetype=1):
  if timetype==1:
   return TFRfexWmQBlcHGLoNzvDVhPqUdYySX(time.time())
  else:
   return TFRfexWmQBlcHGLoNzvDVhPqUdYySX(time.time()*1000)
 def GetUniqueid(TFRfexWmQBlcHGLoNzvDVhPqUdYybw):
  TFRfexWmQBlcHGLoNzvDVhPqUdYybM=[0 for i in TFRfexWmQBlcHGLoNzvDVhPqUdYySA(256)]
  for i in TFRfexWmQBlcHGLoNzvDVhPqUdYySA(256):
   TFRfexWmQBlcHGLoNzvDVhPqUdYybM[i]='%02x'%(i)
  TFRfexWmQBlcHGLoNzvDVhPqUdYybE=TFRfexWmQBlcHGLoNzvDVhPqUdYySX(4294967295*random.random())|0
  TFRfexWmQBlcHGLoNzvDVhPqUdYybk=TFRfexWmQBlcHGLoNzvDVhPqUdYybM[255&TFRfexWmQBlcHGLoNzvDVhPqUdYybE]+TFRfexWmQBlcHGLoNzvDVhPqUdYybM[TFRfexWmQBlcHGLoNzvDVhPqUdYybE>>8&255]+TFRfexWmQBlcHGLoNzvDVhPqUdYybM[TFRfexWmQBlcHGLoNzvDVhPqUdYybE>>16&255]+TFRfexWmQBlcHGLoNzvDVhPqUdYybM[TFRfexWmQBlcHGLoNzvDVhPqUdYybE>>24&255]
  return TFRfexWmQBlcHGLoNzvDVhPqUdYybk
 def GetCredential(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,user_id,user_pw,login_type,user_pf):
  TFRfexWmQBlcHGLoNzvDVhPqUdYybj=TFRfexWmQBlcHGLoNzvDVhPqUdYySt
  TFRfexWmQBlcHGLoNzvDVhPqUdYyba=TFRfexWmQBlcHGLoNzvDVhPqUdYybg=TFRfexWmQBlcHGLoNzvDVhPqUdYyOb=TFRfexWmQBlcHGLoNzvDVhPqUdYyOJ=TFRfexWmQBlcHGLoNzvDVhPqUdYyOw='' 
  TFRfexWmQBlcHGLoNzvDVhPqUdYybu ='-'
  try:
   TFRfexWmQBlcHGLoNzvDVhPqUdYybp=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   TFRfexWmQBlcHGLoNzvDVhPqUdYybI={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   TFRfexWmQBlcHGLoNzvDVhPqUdYybC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.callRequestCookies('Post',TFRfexWmQBlcHGLoNzvDVhPqUdYybp,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYybI,params=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYySs)
   for TFRfexWmQBlcHGLoNzvDVhPqUdYybi in TFRfexWmQBlcHGLoNzvDVhPqUdYybC.cookies:
    if TFRfexWmQBlcHGLoNzvDVhPqUdYybi.name=='_tving_token':
     TFRfexWmQBlcHGLoNzvDVhPqUdYybg=TFRfexWmQBlcHGLoNzvDVhPqUdYybi.value
    elif TFRfexWmQBlcHGLoNzvDVhPqUdYybi.name=='POC_USERINFO':
     TFRfexWmQBlcHGLoNzvDVhPqUdYyOb=TFRfexWmQBlcHGLoNzvDVhPqUdYybi.value
   if TFRfexWmQBlcHGLoNzvDVhPqUdYybg=='':return TFRfexWmQBlcHGLoNzvDVhPqUdYybj
   TFRfexWmQBlcHGLoNzvDVhPqUdYyba=TFRfexWmQBlcHGLoNzvDVhPqUdYybg
   TFRfexWmQBlcHGLoNzvDVhPqUdYybg,TFRfexWmQBlcHGLoNzvDVhPqUdYyOJ,TFRfexWmQBlcHGLoNzvDVhPqUdYyOw=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetProfileToken(TFRfexWmQBlcHGLoNzvDVhPqUdYybg,TFRfexWmQBlcHGLoNzvDVhPqUdYyOb,user_pf)
   TFRfexWmQBlcHGLoNzvDVhPqUdYybj=TFRfexWmQBlcHGLoNzvDVhPqUdYySK
   TFRfexWmQBlcHGLoNzvDVhPqUdYybu =TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetDeviceList(TFRfexWmQBlcHGLoNzvDVhPqUdYybg,TFRfexWmQBlcHGLoNzvDVhPqUdYyOb)
   TFRfexWmQBlcHGLoNzvDVhPqUdYybu =TFRfexWmQBlcHGLoNzvDVhPqUdYybu+'-'+TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetUniqueid()
  except TFRfexWmQBlcHGLoNzvDVhPqUdYySM as exception:
   TFRfexWmQBlcHGLoNzvDVhPqUdYyba=TFRfexWmQBlcHGLoNzvDVhPqUdYybg=TFRfexWmQBlcHGLoNzvDVhPqUdYyOb=TFRfexWmQBlcHGLoNzvDVhPqUdYyOJ=TFRfexWmQBlcHGLoNzvDVhPqUdYyOw=''
   TFRfexWmQBlcHGLoNzvDVhPqUdYybu='-'
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(exception)
  TFRfexWmQBlcHGLoNzvDVhPqUdYybA={'tving_token':TFRfexWmQBlcHGLoNzvDVhPqUdYybg,'poc_userinfo':TFRfexWmQBlcHGLoNzvDVhPqUdYyOb,'tving_uuid':TFRfexWmQBlcHGLoNzvDVhPqUdYybu,'tving_maintoken':TFRfexWmQBlcHGLoNzvDVhPqUdYyba,'tving_cookiekey':TFRfexWmQBlcHGLoNzvDVhPqUdYyOJ,'tving_lockkey':TFRfexWmQBlcHGLoNzvDVhPqUdYyOw}
  TFRfexWmQBlcHGLoNzvDVhPqUdYybw.SaveCredential(TFRfexWmQBlcHGLoNzvDVhPqUdYybA)
  return TFRfexWmQBlcHGLoNzvDVhPqUdYybj
 def Get_Now_Datetime(TFRfexWmQBlcHGLoNzvDVhPqUdYybw):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,mediacode,sel_quality,stype,pvrmode='-'):
  TFRfexWmQBlcHGLoNzvDVhPqUdYyOr=''
  TFRfexWmQBlcHGLoNzvDVhPqUdYyOn=''
  TFRfexWmQBlcHGLoNzvDVhPqUdYyOs=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.TVING_UUID 
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    TFRfexWmQBlcHGLoNzvDVhPqUdYyOt ='/v2a/media/stream/info' 
    TFRfexWmQBlcHGLoNzvDVhPqUdYyOX=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetDefaultParams()
    TFRfexWmQBlcHGLoNzvDVhPqUdYyOA={'info':'N','mediaCode':mediacode,'noCache':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','uuid':TFRfexWmQBlcHGLoNzvDVhPqUdYyOs,'deviceInfo':'PC','wm':'Y'}
    TFRfexWmQBlcHGLoNzvDVhPqUdYyOX.update(TFRfexWmQBlcHGLoNzvDVhPqUdYyOA)
    TFRfexWmQBlcHGLoNzvDVhPqUdYyOK=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.API_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOt
    TFRfexWmQBlcHGLoNzvDVhPqUdYybn=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.makeDefaultCookies()
    TFRfexWmQBlcHGLoNzvDVhPqUdYybC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.callRequestCookies('Get',TFRfexWmQBlcHGLoNzvDVhPqUdYyOK,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,params=TFRfexWmQBlcHGLoNzvDVhPqUdYyOX,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYybn)
    TFRfexWmQBlcHGLoNzvDVhPqUdYyOM=json.loads(TFRfexWmQBlcHGLoNzvDVhPqUdYybC.text)
    if not('stream' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']):return TFRfexWmQBlcHGLoNzvDVhPqUdYyOr,TFRfexWmQBlcHGLoNzvDVhPqUdYyOn 
    TFRfexWmQBlcHGLoNzvDVhPqUdYyOE=TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']['stream']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyOk=TFRfexWmQBlcHGLoNzvDVhPqUdYyOE['quality']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyOj=[]
    for TFRfexWmQBlcHGLoNzvDVhPqUdYyOa in TFRfexWmQBlcHGLoNzvDVhPqUdYyOk:
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['active']=='Y':
      TFRfexWmQBlcHGLoNzvDVhPqUdYyOj.append({TFRfexWmQBlcHGLoNzvDVhPqUdYybJ.get(TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['code']):TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['code']})
    TFRfexWmQBlcHGLoNzvDVhPqUdYyOu=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.CheckQuality(sel_quality,TFRfexWmQBlcHGLoNzvDVhPqUdYyOj)
   else:
    for TFRfexWmQBlcHGLoNzvDVhPqUdYyOp,TFRfexWmQBlcHGLoNzvDVhPqUdYyJS in TFRfexWmQBlcHGLoNzvDVhPqUdYybJ.items():
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyJS==sel_quality:
      TFRfexWmQBlcHGLoNzvDVhPqUdYyOu=TFRfexWmQBlcHGLoNzvDVhPqUdYyOp
  except TFRfexWmQBlcHGLoNzvDVhPqUdYySM as exception:
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(exception)
   for TFRfexWmQBlcHGLoNzvDVhPqUdYyOp,TFRfexWmQBlcHGLoNzvDVhPqUdYyJS in TFRfexWmQBlcHGLoNzvDVhPqUdYybJ.items():
    if TFRfexWmQBlcHGLoNzvDVhPqUdYyJS==sel_quality:
     TFRfexWmQBlcHGLoNzvDVhPqUdYyOu=TFRfexWmQBlcHGLoNzvDVhPqUdYyOp
   return TFRfexWmQBlcHGLoNzvDVhPqUdYyOr,TFRfexWmQBlcHGLoNzvDVhPqUdYyOn
  TFRfexWmQBlcHGLoNzvDVhPqUdYySE(TFRfexWmQBlcHGLoNzvDVhPqUdYyOu)
  try:
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOt ='/streaming/info'
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOX=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetDefaultParams()
   if stype=='onair':TFRfexWmQBlcHGLoNzvDVhPqUdYyOX['osCode']='CSOD0400' 
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOI={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.makeOocUrl(TFRfexWmQBlcHGLoNzvDVhPqUdYyOI)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOi=urllib.parse.quote(TFRfexWmQBlcHGLoNzvDVhPqUdYyOC)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOA={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':TFRfexWmQBlcHGLoNzvDVhPqUdYyOu,'adReq':'adproxy','ooc':TFRfexWmQBlcHGLoNzvDVhPqUdYyOC,'uuid':TFRfexWmQBlcHGLoNzvDVhPqUdYyOs,'deviceInfo':'PC'}
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOg =TFRfexWmQBlcHGLoNzvDVhPqUdYyOX
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOg.update(TFRfexWmQBlcHGLoNzvDVhPqUdYyOA)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOK=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.URL_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOt
   TFRfexWmQBlcHGLoNzvDVhPqUdYyJb={'origin':'https://www.tving.com'}
   if stype=='onair':TFRfexWmQBlcHGLoNzvDVhPqUdYyJb['Referer']='https://www.tving.com/live/player/'+mediacode
   else: TFRfexWmQBlcHGLoNzvDVhPqUdYyJb['Referer']='https://www.tving.com/vod/player/'+mediacode
   TFRfexWmQBlcHGLoNzvDVhPqUdYybn=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.makeDefaultCookies()
   TFRfexWmQBlcHGLoNzvDVhPqUdYybn['onClickEvent2']=TFRfexWmQBlcHGLoNzvDVhPqUdYyOi
   TFRfexWmQBlcHGLoNzvDVhPqUdYybC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.callRequestCookies('Post',TFRfexWmQBlcHGLoNzvDVhPqUdYyOK,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYyOg,params=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYyJb,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYybn,redirects=TFRfexWmQBlcHGLoNzvDVhPqUdYySt)
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(TFRfexWmQBlcHGLoNzvDVhPqUdYybC.status_code)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOM=json.loads(TFRfexWmQBlcHGLoNzvDVhPqUdYybC.text)
   if 'drm_license_assertion' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['stream']:
    TFRfexWmQBlcHGLoNzvDVhPqUdYyOn =TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['stream']['drm_license_assertion']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyOr=TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['stream']['broadcast']):return TFRfexWmQBlcHGLoNzvDVhPqUdYyOr,TFRfexWmQBlcHGLoNzvDVhPqUdYyOn
    TFRfexWmQBlcHGLoNzvDVhPqUdYyOr=TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['stream']['broadcast']['broad_url']
  except TFRfexWmQBlcHGLoNzvDVhPqUdYySM as exception:
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(exception)
  return TFRfexWmQBlcHGLoNzvDVhPqUdYyOr,TFRfexWmQBlcHGLoNzvDVhPqUdYyOn
 def CheckQuality(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,sel_qt,TFRfexWmQBlcHGLoNzvDVhPqUdYyOj):
  for TFRfexWmQBlcHGLoNzvDVhPqUdYyJO in TFRfexWmQBlcHGLoNzvDVhPqUdYyOj:
   if sel_qt>=TFRfexWmQBlcHGLoNzvDVhPqUdYySj(TFRfexWmQBlcHGLoNzvDVhPqUdYyJO)[0]:return TFRfexWmQBlcHGLoNzvDVhPqUdYyJO.get(TFRfexWmQBlcHGLoNzvDVhPqUdYySj(TFRfexWmQBlcHGLoNzvDVhPqUdYyJO)[0])
   TFRfexWmQBlcHGLoNzvDVhPqUdYyJw=TFRfexWmQBlcHGLoNzvDVhPqUdYyJO.get(TFRfexWmQBlcHGLoNzvDVhPqUdYySj(TFRfexWmQBlcHGLoNzvDVhPqUdYyJO)[0])
  return TFRfexWmQBlcHGLoNzvDVhPqUdYyJw
 def makeOocUrl(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,TFRfexWmQBlcHGLoNzvDVhPqUdYyOI):
  TFRfexWmQBlcHGLoNzvDVhPqUdYyOK=''
  for TFRfexWmQBlcHGLoNzvDVhPqUdYyOp,TFRfexWmQBlcHGLoNzvDVhPqUdYyJS in TFRfexWmQBlcHGLoNzvDVhPqUdYyOI.items():
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOK+="%s=%s^"%(TFRfexWmQBlcHGLoNzvDVhPqUdYyOp,TFRfexWmQBlcHGLoNzvDVhPqUdYyJS)
  return TFRfexWmQBlcHGLoNzvDVhPqUdYyOK
 def GetLiveChannelList(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,stype,page_int):
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJr=[]
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJn=TFRfexWmQBlcHGLoNzvDVhPqUdYySt
  try:
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOt ='/v2/media/lives'
   if stype=='onair':
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJs='CPCS0100,CPCS0400'
   else:
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJs='CPCS0300'
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOX=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetDefaultParams()
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOA={'pageNo':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(page_int),'pageSize':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':TFRfexWmQBlcHGLoNzvDVhPqUdYyJs,'_':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetNoCache(2))}
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOX.update(TFRfexWmQBlcHGLoNzvDVhPqUdYyOA)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOK=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.API_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOt
   TFRfexWmQBlcHGLoNzvDVhPqUdYybn=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.makeDefaultCookies()
   TFRfexWmQBlcHGLoNzvDVhPqUdYybC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.callRequestCookies('Get',TFRfexWmQBlcHGLoNzvDVhPqUdYyOK,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,params=TFRfexWmQBlcHGLoNzvDVhPqUdYyOX,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYybn)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOM=json.loads(TFRfexWmQBlcHGLoNzvDVhPqUdYybC.text)
   if not('result' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']):return TFRfexWmQBlcHGLoNzvDVhPqUdYyJr,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
   TFRfexWmQBlcHGLoNzvDVhPqUdYyJt=TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']['result']
   for TFRfexWmQBlcHGLoNzvDVhPqUdYyOa in TFRfexWmQBlcHGLoNzvDVhPqUdYyJt:
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJX={}
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['mediatype']='video'
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJA=TFRfexWmQBlcHGLoNzvDVhPqUdYyJE=TFRfexWmQBlcHGLoNzvDVhPqUdYyJk=TFRfexWmQBlcHGLoNzvDVhPqUdYyJj=''
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJK=TFRfexWmQBlcHGLoNzvDVhPqUdYyJI=''
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJM=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['live_code']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJA =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['channel']['name']['ko']
    if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['episode']!=TFRfexWmQBlcHGLoNzvDVhPqUdYySs:
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJE =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['program']['name']['ko']
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJE =TFRfexWmQBlcHGLoNzvDVhPqUdYyJE+', '+TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['episode']['frequency'])+'회'
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['episode']['image']!=[]:
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJk=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['episode']['image'][0]['url']
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJj=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['episode']['synopsis']['ko']
    else:
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJE =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['program']['name']['ko']
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['program']['image']!=[]:
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJk=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['program']['image'][0]['url']
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJj=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['program']['synopsis']['ko']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['title'] =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['program']['name']['ko']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['studio'] =TFRfexWmQBlcHGLoNzvDVhPqUdYyJA
    try:
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJa=[]
     for TFRfexWmQBlcHGLoNzvDVhPqUdYyJu in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('schedule').get('program').get('actor'):TFRfexWmQBlcHGLoNzvDVhPqUdYyJa.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyJu)
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyJa[0]!='' and TFRfexWmQBlcHGLoNzvDVhPqUdYyJa[0]!=u'없음':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['cast']=TFRfexWmQBlcHGLoNzvDVhPqUdYyJa
    except:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySs
    try:
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJp=[]
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('schedule').get('program').get('category1_name').get('ko')!='':
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJp.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['program']['category1_name']['ko'])
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('schedule').get('program').get('category2_name').get('ko')!='':
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJp.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['program']['category2_name']['ko'])
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyJp[0]!='':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['genre']=TFRfexWmQBlcHGLoNzvDVhPqUdYyJp
    except:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySs
    if TFRfexWmQBlcHGLoNzvDVhPqUdYyJk=='':
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJk=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['channel']['image'][0]['url']
    if TFRfexWmQBlcHGLoNzvDVhPqUdYyJk!='':TFRfexWmQBlcHGLoNzvDVhPqUdYyJk=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyJk
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJK=TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['broadcast_start_time'])[8:12]
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJI =TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['schedule']['broadcast_end_time'])[8:12]
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJC={'channel':TFRfexWmQBlcHGLoNzvDVhPqUdYyJA,'title':TFRfexWmQBlcHGLoNzvDVhPqUdYyJE,'mediacode':TFRfexWmQBlcHGLoNzvDVhPqUdYyJM,'thumbnail':TFRfexWmQBlcHGLoNzvDVhPqUdYyJk,'synopsis':TFRfexWmQBlcHGLoNzvDVhPqUdYyJj,'channelepg':' [%s:%s ~ %s:%s]'%(TFRfexWmQBlcHGLoNzvDVhPqUdYyJK[0:2],TFRfexWmQBlcHGLoNzvDVhPqUdYyJK[2:],TFRfexWmQBlcHGLoNzvDVhPqUdYyJI[0:2],TFRfexWmQBlcHGLoNzvDVhPqUdYyJI[2:]),'info':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX}
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJr.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyJC)
   if TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']['has_more']=='Y':TFRfexWmQBlcHGLoNzvDVhPqUdYyJn=TFRfexWmQBlcHGLoNzvDVhPqUdYySK
  except TFRfexWmQBlcHGLoNzvDVhPqUdYySM as exception:
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(exception)
  return TFRfexWmQBlcHGLoNzvDVhPqUdYyJr,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
 def GetProgramList(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,genre,orderby,page_int,landyn=TFRfexWmQBlcHGLoNzvDVhPqUdYySt):
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJr=[]
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJn=TFRfexWmQBlcHGLoNzvDVhPqUdYySt
  try:
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOt ='/v2/media/episodes'
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOX=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetDefaultParams()
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOA={'pageNo':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(page_int),'pageSize':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetNoCache(2))}
   if genre!='all':TFRfexWmQBlcHGLoNzvDVhPqUdYyOA['multiCategoryCode']=genre
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOX.update(TFRfexWmQBlcHGLoNzvDVhPqUdYyOA)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOK=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.API_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOt
   TFRfexWmQBlcHGLoNzvDVhPqUdYybn=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.makeDefaultCookies()
   TFRfexWmQBlcHGLoNzvDVhPqUdYybC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.callRequestCookies('Get',TFRfexWmQBlcHGLoNzvDVhPqUdYyOK,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,params=TFRfexWmQBlcHGLoNzvDVhPqUdYyOX,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYybn)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOM=json.loads(TFRfexWmQBlcHGLoNzvDVhPqUdYybC.text)
   if not('result' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']):return TFRfexWmQBlcHGLoNzvDVhPqUdYyJr,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
   TFRfexWmQBlcHGLoNzvDVhPqUdYyJt=TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']['result']
   for TFRfexWmQBlcHGLoNzvDVhPqUdYyOa in TFRfexWmQBlcHGLoNzvDVhPqUdYyJt:
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJi=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['program']['code']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJE =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['program']['name']['ko']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJk =TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['program']['image'][0]['url']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJg='CAIP0200' if landyn else 'CAIP0900' 
    for TFRfexWmQBlcHGLoNzvDVhPqUdYywb in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['program']['image']:
     if TFRfexWmQBlcHGLoNzvDVhPqUdYywb['code']==TFRfexWmQBlcHGLoNzvDVhPqUdYyJg:
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJk =TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYywb['url']
      break
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJj =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['program']['synopsis']['ko']
    TFRfexWmQBlcHGLoNzvDVhPqUdYywO=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['program']['channel_code']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJX={}
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['title'] =TFRfexWmQBlcHGLoNzvDVhPqUdYyJE 
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['mediatype']='episode' 
    try:
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJa=[]
     for TFRfexWmQBlcHGLoNzvDVhPqUdYyJu in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('program').get('actor'):TFRfexWmQBlcHGLoNzvDVhPqUdYyJa.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyJu)
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyJa[0]!='' and TFRfexWmQBlcHGLoNzvDVhPqUdYyJa[0]!='-':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['cast']=TFRfexWmQBlcHGLoNzvDVhPqUdYyJa
    except:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySs
    try:
     TFRfexWmQBlcHGLoNzvDVhPqUdYywJ=[]
     for TFRfexWmQBlcHGLoNzvDVhPqUdYywS in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('program').get('director'):TFRfexWmQBlcHGLoNzvDVhPqUdYywJ.append(TFRfexWmQBlcHGLoNzvDVhPqUdYywS)
     if TFRfexWmQBlcHGLoNzvDVhPqUdYywJ[0]!='' and TFRfexWmQBlcHGLoNzvDVhPqUdYywJ[0]!='-':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['director']=TFRfexWmQBlcHGLoNzvDVhPqUdYywJ
    except:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySs
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJp=[]
    if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('program').get('category1_name').get('ko')!='':
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJp.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['program']['category1_name']['ko'])
    if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('program').get('category2_name').get('ko')!='':
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJp.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['program']['category2_name']['ko'])
    if TFRfexWmQBlcHGLoNzvDVhPqUdYyJp[0]!='':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['genre']=TFRfexWmQBlcHGLoNzvDVhPqUdYyJp
    try:
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('program').get('product_year'):TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['year']=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['program']['product_year']
     if 'broad_dt' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('program'):
      TFRfexWmQBlcHGLoNzvDVhPqUdYywr=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('program').get('broad_dt')
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['aired']='%s-%s-%s'%(TFRfexWmQBlcHGLoNzvDVhPqUdYywr[:4],TFRfexWmQBlcHGLoNzvDVhPqUdYywr[4:6],TFRfexWmQBlcHGLoNzvDVhPqUdYywr[6:])
    except:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySs
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJC={'program':TFRfexWmQBlcHGLoNzvDVhPqUdYyJi,'title':TFRfexWmQBlcHGLoNzvDVhPqUdYyJE,'thumbnail':TFRfexWmQBlcHGLoNzvDVhPqUdYyJk,'synopsis':TFRfexWmQBlcHGLoNzvDVhPqUdYyJj,'channel':TFRfexWmQBlcHGLoNzvDVhPqUdYywO,'info':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX}
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJr.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyJC)
   if TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']['has_more']=='Y':TFRfexWmQBlcHGLoNzvDVhPqUdYyJn=TFRfexWmQBlcHGLoNzvDVhPqUdYySK
  except TFRfexWmQBlcHGLoNzvDVhPqUdYySM as exception:
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(exception)
  return TFRfexWmQBlcHGLoNzvDVhPqUdYyJr,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
 def GetEpisodoList(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,program_code,page_int,orderby='desc'):
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJr=[]
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJn=TFRfexWmQBlcHGLoNzvDVhPqUdYySt
  try:
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOt ='/v2/media/frequency/program/'+program_code
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOX=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetDefaultParams()
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOA={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetNoCache(2))}
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOX.update(TFRfexWmQBlcHGLoNzvDVhPqUdYyOA)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOK=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.API_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOt
   TFRfexWmQBlcHGLoNzvDVhPqUdYybn=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.makeDefaultCookies()
   TFRfexWmQBlcHGLoNzvDVhPqUdYybC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.callRequestCookies('Get',TFRfexWmQBlcHGLoNzvDVhPqUdYyOK,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,params=TFRfexWmQBlcHGLoNzvDVhPqUdYyOX,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYybn)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOM=json.loads(TFRfexWmQBlcHGLoNzvDVhPqUdYybC.text)
   if not('result' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']):return TFRfexWmQBlcHGLoNzvDVhPqUdYyJr,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
   TFRfexWmQBlcHGLoNzvDVhPqUdYyJt=TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']['result']
   TFRfexWmQBlcHGLoNzvDVhPqUdYywn=TFRfexWmQBlcHGLoNzvDVhPqUdYySX(TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']['total_count'])
   TFRfexWmQBlcHGLoNzvDVhPqUdYyws =TFRfexWmQBlcHGLoNzvDVhPqUdYySX(TFRfexWmQBlcHGLoNzvDVhPqUdYywn//(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    TFRfexWmQBlcHGLoNzvDVhPqUdYywt =(TFRfexWmQBlcHGLoNzvDVhPqUdYywn-1)-((page_int-1)*TFRfexWmQBlcHGLoNzvDVhPqUdYybw.EPISODE_LIMIT)
   else:
    TFRfexWmQBlcHGLoNzvDVhPqUdYywt =(page_int-1)*TFRfexWmQBlcHGLoNzvDVhPqUdYybw.EPISODE_LIMIT
   for i in TFRfexWmQBlcHGLoNzvDVhPqUdYySA(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.EPISODE_LIMIT):
    if orderby=='desc':
     TFRfexWmQBlcHGLoNzvDVhPqUdYywX=TFRfexWmQBlcHGLoNzvDVhPqUdYywt-i
     if TFRfexWmQBlcHGLoNzvDVhPqUdYywX<0:break
    else:
     TFRfexWmQBlcHGLoNzvDVhPqUdYywX=TFRfexWmQBlcHGLoNzvDVhPqUdYywt+i
     if TFRfexWmQBlcHGLoNzvDVhPqUdYywX>=TFRfexWmQBlcHGLoNzvDVhPqUdYywn:break
    TFRfexWmQBlcHGLoNzvDVhPqUdYywA=TFRfexWmQBlcHGLoNzvDVhPqUdYyJt[TFRfexWmQBlcHGLoNzvDVhPqUdYywX]['episode']['code']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJE =TFRfexWmQBlcHGLoNzvDVhPqUdYyJt[TFRfexWmQBlcHGLoNzvDVhPqUdYywX]['vod_name']['ko']
    TFRfexWmQBlcHGLoNzvDVhPqUdYywK =''
    try:
     TFRfexWmQBlcHGLoNzvDVhPqUdYywr=TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYyJt[TFRfexWmQBlcHGLoNzvDVhPqUdYywX]['episode']['broadcast_date'])
     TFRfexWmQBlcHGLoNzvDVhPqUdYywK='%s-%s-%s'%(TFRfexWmQBlcHGLoNzvDVhPqUdYywr[:4],TFRfexWmQBlcHGLoNzvDVhPqUdYywr[4:6],TFRfexWmQBlcHGLoNzvDVhPqUdYywr[6:])
    except:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySs
    if TFRfexWmQBlcHGLoNzvDVhPqUdYyJt[TFRfexWmQBlcHGLoNzvDVhPqUdYywX]['episode']['image']!=[]:
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJk=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyJt[TFRfexWmQBlcHGLoNzvDVhPqUdYywX]['episode']['image'][0]['url']
    else:
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJk=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyJt[TFRfexWmQBlcHGLoNzvDVhPqUdYywX]['program']['image'][0]['url']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJj =TFRfexWmQBlcHGLoNzvDVhPqUdYyJt[TFRfexWmQBlcHGLoNzvDVhPqUdYywX]['episode']['synopsis']['ko']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJX={}
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['mediatype']='episode' 
    try:
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['title'] =TFRfexWmQBlcHGLoNzvDVhPqUdYyJt[TFRfexWmQBlcHGLoNzvDVhPqUdYywX]['program']['name']['ko']
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['aired'] =TFRfexWmQBlcHGLoNzvDVhPqUdYywK
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['studio'] =TFRfexWmQBlcHGLoNzvDVhPqUdYyJt[TFRfexWmQBlcHGLoNzvDVhPqUdYywX]['channel']['name']['ko']
     if 'frequency' in TFRfexWmQBlcHGLoNzvDVhPqUdYyJt[TFRfexWmQBlcHGLoNzvDVhPqUdYywX]['episode']:TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['episode']=TFRfexWmQBlcHGLoNzvDVhPqUdYyJt[TFRfexWmQBlcHGLoNzvDVhPqUdYywX]['episode']['frequency']
    except:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySs
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJC={'episode':TFRfexWmQBlcHGLoNzvDVhPqUdYywA,'title':TFRfexWmQBlcHGLoNzvDVhPqUdYyJE,'subtitle':TFRfexWmQBlcHGLoNzvDVhPqUdYywK,'thumbnail':TFRfexWmQBlcHGLoNzvDVhPqUdYyJk,'synopsis':TFRfexWmQBlcHGLoNzvDVhPqUdYyJj,'info':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX}
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJr.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyJC)
   if TFRfexWmQBlcHGLoNzvDVhPqUdYyws>page_int:TFRfexWmQBlcHGLoNzvDVhPqUdYyJn=TFRfexWmQBlcHGLoNzvDVhPqUdYySK
  except TFRfexWmQBlcHGLoNzvDVhPqUdYySM as exception:
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(exception)
  return TFRfexWmQBlcHGLoNzvDVhPqUdYyJr,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn,TFRfexWmQBlcHGLoNzvDVhPqUdYyws
 def GetMovieList(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,genre,orderby,page_int,landyn=TFRfexWmQBlcHGLoNzvDVhPqUdYySt):
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJr=[]
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJn=TFRfexWmQBlcHGLoNzvDVhPqUdYySt
  try:
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOt ='/v2/media/movies'
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOX=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetDefaultParams()
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOA={'pageNo':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(page_int),'pageSize':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetNoCache(2))}
   if genre!='all' :TFRfexWmQBlcHGLoNzvDVhPqUdYyOA['multiCategoryCode']=genre
   if orderby=='new':TFRfexWmQBlcHGLoNzvDVhPqUdYyOA['productPackageCode']=','.join(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.MOVIE_LITE)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOX.update(TFRfexWmQBlcHGLoNzvDVhPqUdYyOA)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOK=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.API_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOt
   TFRfexWmQBlcHGLoNzvDVhPqUdYybn=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.makeDefaultCookies()
   TFRfexWmQBlcHGLoNzvDVhPqUdYybC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.callRequestCookies('Get',TFRfexWmQBlcHGLoNzvDVhPqUdYyOK,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,params=TFRfexWmQBlcHGLoNzvDVhPqUdYyOX,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYybn)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOM=json.loads(TFRfexWmQBlcHGLoNzvDVhPqUdYybC.text)
   if not('result' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']):return TFRfexWmQBlcHGLoNzvDVhPqUdYyJr,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
   TFRfexWmQBlcHGLoNzvDVhPqUdYyJt=TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']['result']
   for TFRfexWmQBlcHGLoNzvDVhPqUdYyOa in TFRfexWmQBlcHGLoNzvDVhPqUdYyJt:
    TFRfexWmQBlcHGLoNzvDVhPqUdYywM =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['movie']['code']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJE =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['movie']['name']['ko'].strip()
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJE +=u' (%s년)'%(TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('movie').get('product_year'))
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJk =TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['movie']['image'][0]['url']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJg='CAIM0400' if landyn else 'CAIM2100' 
    for TFRfexWmQBlcHGLoNzvDVhPqUdYywb in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['movie']['image']:
     if TFRfexWmQBlcHGLoNzvDVhPqUdYywb['code']==TFRfexWmQBlcHGLoNzvDVhPqUdYyJg:
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJk =TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYywb['url']
      break
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJj =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['movie']['story']['ko']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJX={}
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['mediatype']='movie' 
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['title'] = TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['movie']['name']['ko'].strip()
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['year'] =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('movie').get('product_year')
    try:
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJa=[]
     for TFRfexWmQBlcHGLoNzvDVhPqUdYyJu in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('movie').get('actor'):TFRfexWmQBlcHGLoNzvDVhPqUdYyJa.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyJu)
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyJa[0]!='':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['cast']=TFRfexWmQBlcHGLoNzvDVhPqUdYyJa
    except:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySs
    try:
     TFRfexWmQBlcHGLoNzvDVhPqUdYywJ=[]
     for TFRfexWmQBlcHGLoNzvDVhPqUdYywS in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('movie').get('director'):TFRfexWmQBlcHGLoNzvDVhPqUdYywJ.append(TFRfexWmQBlcHGLoNzvDVhPqUdYywS)
     if TFRfexWmQBlcHGLoNzvDVhPqUdYywJ[0]!='':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['director']=TFRfexWmQBlcHGLoNzvDVhPqUdYywJ
    except:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySs
    try:
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJp=[]
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('movie').get('category1_name').get('ko')!='':
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJp.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['movie']['category1_name']['ko'])
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('movie').get('category2_name').get('ko')!='':
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJp.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['movie']['category2_name']['ko'])
     if TFRfexWmQBlcHGLoNzvDVhPqUdYyJp[0]!='':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['genre']=TFRfexWmQBlcHGLoNzvDVhPqUdYyJp
    except:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySs
    try:
     if 'release_date' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('movie'):
      TFRfexWmQBlcHGLoNzvDVhPqUdYywr=TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('movie').get('release_date'))
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['aired']='%s-%s-%s'%(TFRfexWmQBlcHGLoNzvDVhPqUdYywr[:4],TFRfexWmQBlcHGLoNzvDVhPqUdYywr[4:6],TFRfexWmQBlcHGLoNzvDVhPqUdYywr[6:])
    except:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySs
    try:
     if 'duration' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('movie'):TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['duration']=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('movie').get('duration')
    except:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySs
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJC={'moviecode':TFRfexWmQBlcHGLoNzvDVhPqUdYywM,'title':TFRfexWmQBlcHGLoNzvDVhPqUdYyJE,'thumbnail':TFRfexWmQBlcHGLoNzvDVhPqUdYyJk,'synopsis':TFRfexWmQBlcHGLoNzvDVhPqUdYyJj,'info':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX}
    TFRfexWmQBlcHGLoNzvDVhPqUdYywE=TFRfexWmQBlcHGLoNzvDVhPqUdYySt
    for TFRfexWmQBlcHGLoNzvDVhPqUdYywk in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['billing_package_id']:
     if TFRfexWmQBlcHGLoNzvDVhPqUdYywk in TFRfexWmQBlcHGLoNzvDVhPqUdYybw.MOVIE_LITE:
      TFRfexWmQBlcHGLoNzvDVhPqUdYywE=TFRfexWmQBlcHGLoNzvDVhPqUdYySK
      break
    if TFRfexWmQBlcHGLoNzvDVhPqUdYywE==TFRfexWmQBlcHGLoNzvDVhPqUdYySt: 
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJC['title']=TFRfexWmQBlcHGLoNzvDVhPqUdYyJC['title']+' [개별구매]'
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJr.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyJC)
   if TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']['has_more']=='Y':TFRfexWmQBlcHGLoNzvDVhPqUdYyJn=TFRfexWmQBlcHGLoNzvDVhPqUdYySK
  except TFRfexWmQBlcHGLoNzvDVhPqUdYySM as exception:
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(exception)
  return TFRfexWmQBlcHGLoNzvDVhPqUdYyJr,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
 def GetMovieListGenre(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,genre,page_int):
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJr=[]
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJn=TFRfexWmQBlcHGLoNzvDVhPqUdYySt
  try:
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOt ='/v2/media/movie/curation/'+genre
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOX=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetDefaultParams()
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOA={'pageNo':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(page_int),'pageSize':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.MOVIE_LIMIT),'_':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetNoCache(2))}
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOX.update(TFRfexWmQBlcHGLoNzvDVhPqUdYyOA)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOK=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.API_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOt
   TFRfexWmQBlcHGLoNzvDVhPqUdYybn=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.makeDefaultCookies()
   TFRfexWmQBlcHGLoNzvDVhPqUdYybC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.callRequestCookies('Get',TFRfexWmQBlcHGLoNzvDVhPqUdYyOK,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,params=TFRfexWmQBlcHGLoNzvDVhPqUdYyOX,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYybn)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOM=json.loads(TFRfexWmQBlcHGLoNzvDVhPqUdYybC.text)
   if not('movies' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']):return TFRfexWmQBlcHGLoNzvDVhPqUdYyJr,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
   TFRfexWmQBlcHGLoNzvDVhPqUdYyJt=TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']['movies']
   for TFRfexWmQBlcHGLoNzvDVhPqUdYyOa in TFRfexWmQBlcHGLoNzvDVhPqUdYyJt:
    TFRfexWmQBlcHGLoNzvDVhPqUdYywM =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['code']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJE =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['name']['ko']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJk =TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['image'][0]['url']
    for TFRfexWmQBlcHGLoNzvDVhPqUdYywb in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['image']:
     if TFRfexWmQBlcHGLoNzvDVhPqUdYywb['code']=='CAIM2100':
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJk =TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYywb['url']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJj =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['story']['ko']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJC={'moviecode':TFRfexWmQBlcHGLoNzvDVhPqUdYywM,'title':TFRfexWmQBlcHGLoNzvDVhPqUdYyJE.strip(),'thumbnail':TFRfexWmQBlcHGLoNzvDVhPqUdYyJk,'synopsis':TFRfexWmQBlcHGLoNzvDVhPqUdYyJj}
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJr.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyJC)
  except TFRfexWmQBlcHGLoNzvDVhPqUdYySM as exception:
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(exception)
  return TFRfexWmQBlcHGLoNzvDVhPqUdYyJr,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
 def GetMovieGenre(TFRfexWmQBlcHGLoNzvDVhPqUdYybw):
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJr=[]
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJn=TFRfexWmQBlcHGLoNzvDVhPqUdYySt
  try:
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOt ='/v2/media/movie/curations'
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOX=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetDefaultParams()
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOA={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetNoCache(2))}
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOX.update(TFRfexWmQBlcHGLoNzvDVhPqUdYyOA)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOK=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.API_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOt
   TFRfexWmQBlcHGLoNzvDVhPqUdYybn=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.makeDefaultCookies()
   TFRfexWmQBlcHGLoNzvDVhPqUdYybC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.callRequestCookies('Get',TFRfexWmQBlcHGLoNzvDVhPqUdYyOK,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,params=TFRfexWmQBlcHGLoNzvDVhPqUdYyOX,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYybn)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOM=json.loads(TFRfexWmQBlcHGLoNzvDVhPqUdYybC.text)
   if not('result' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']):return TFRfexWmQBlcHGLoNzvDVhPqUdYyJr,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
   TFRfexWmQBlcHGLoNzvDVhPqUdYyJt=TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']['result']
   for TFRfexWmQBlcHGLoNzvDVhPqUdYyOa in TFRfexWmQBlcHGLoNzvDVhPqUdYyJt:
    TFRfexWmQBlcHGLoNzvDVhPqUdYywj =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['curation_code']
    TFRfexWmQBlcHGLoNzvDVhPqUdYywa =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['curation_name']
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJC={'curation_code':TFRfexWmQBlcHGLoNzvDVhPqUdYywj,'curation_name':TFRfexWmQBlcHGLoNzvDVhPqUdYywa}
    TFRfexWmQBlcHGLoNzvDVhPqUdYyJr.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyJC)
  except TFRfexWmQBlcHGLoNzvDVhPqUdYySM as exception:
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(exception)
  return TFRfexWmQBlcHGLoNzvDVhPqUdYyJr,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
 def GetSearchList(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,search_key,userid,page_int,stype,landyn=TFRfexWmQBlcHGLoNzvDVhPqUdYySt):
  TFRfexWmQBlcHGLoNzvDVhPqUdYywu=[]
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJn=TFRfexWmQBlcHGLoNzvDVhPqUdYySt
  try:
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOt ='/search/getSearch.jsp'
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOA={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(page_int),'pageSize':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.SCREENCODE,'os':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.OSCODE,'network':TFRfexWmQBlcHGLoNzvDVhPqUdYybw.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.SEARCH_LIMIT),'vodMVReqCnt':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':TFRfexWmQBlcHGLoNzvDVhPqUdYySk(TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GetNoCache(2))}
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOK=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.SEARCH_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOt
   TFRfexWmQBlcHGLoNzvDVhPqUdYybn=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.makeDefaultCookies()
   TFRfexWmQBlcHGLoNzvDVhPqUdYybC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.callRequestCookies('Get',TFRfexWmQBlcHGLoNzvDVhPqUdYyOK,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,params=TFRfexWmQBlcHGLoNzvDVhPqUdYyOA,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYybn)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOM=json.loads(TFRfexWmQBlcHGLoNzvDVhPqUdYybC.text)
   if stype=='vod':
    if not('programRsb' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOM):return TFRfexWmQBlcHGLoNzvDVhPqUdYywu,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
    TFRfexWmQBlcHGLoNzvDVhPqUdYywp=TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['programRsb']['dataList']
    TFRfexWmQBlcHGLoNzvDVhPqUdYywI =TFRfexWmQBlcHGLoNzvDVhPqUdYySX(TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['programRsb']['count'])
    for TFRfexWmQBlcHGLoNzvDVhPqUdYyOa in TFRfexWmQBlcHGLoNzvDVhPqUdYywp:
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJi=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['mast_cd']
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJE =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['mast_nm']
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJk =TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['web_url']
     if landyn==TFRfexWmQBlcHGLoNzvDVhPqUdYySt:
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJk =TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['web_url4']
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJX={}
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['title']=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['mast_nm']
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['mediatype']='episode' 
     try:
      if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('actor')!='' and TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('actor')!='-':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['cast'] =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('actor').split(',')
      if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('director')!='' and TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('director')!='-':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['director']=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('director').split(',')
      if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('cate_nm')!='':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['genre'] =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('cate_nm').split('/')
      if 'targetage' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa:TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['mpaa']=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('targetage')
     except:
      TFRfexWmQBlcHGLoNzvDVhPqUdYySs
     try:
      if 'broad_dt' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa:
       TFRfexWmQBlcHGLoNzvDVhPqUdYywr=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('broad_dt')
       TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['aired']='%s-%s-%s'%(TFRfexWmQBlcHGLoNzvDVhPqUdYywr[:4],TFRfexWmQBlcHGLoNzvDVhPqUdYywr[4:6],TFRfexWmQBlcHGLoNzvDVhPqUdYywr[6:])
     except:
      TFRfexWmQBlcHGLoNzvDVhPqUdYySs
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJC={'program':TFRfexWmQBlcHGLoNzvDVhPqUdYyJi,'title':TFRfexWmQBlcHGLoNzvDVhPqUdYyJE,'thumbnail':TFRfexWmQBlcHGLoNzvDVhPqUdYyJk,'synopsis':'','info':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX}
     TFRfexWmQBlcHGLoNzvDVhPqUdYywu.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyJC)
   else:
    if not('vodMVRsb' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOM):return TFRfexWmQBlcHGLoNzvDVhPqUdYywu,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
    TFRfexWmQBlcHGLoNzvDVhPqUdYywC=TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['vodMVRsb']['dataList']
    TFRfexWmQBlcHGLoNzvDVhPqUdYywI =TFRfexWmQBlcHGLoNzvDVhPqUdYySX(TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['vodMVRsb']['count'])
    for TFRfexWmQBlcHGLoNzvDVhPqUdYyOa in TFRfexWmQBlcHGLoNzvDVhPqUdYywC:
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJi=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['mast_cd']
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJE =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['mast_nm'].strip()
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJk =TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['web_url']
     if landyn==TFRfexWmQBlcHGLoNzvDVhPqUdYySt:
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJk =TFRfexWmQBlcHGLoNzvDVhPqUdYybw.IMG_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['web_url5']
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJX={}
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['title'] =TFRfexWmQBlcHGLoNzvDVhPqUdYyJE
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['mediatype']='movie' 
     try:
      if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('actor') !='':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['cast'] =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('actor').split(',')
      if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('cate_nm')!='':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['genre'] =TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('cate_nm').split('/')
      if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('runtime_sec')!='':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['duration']=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('runtime_sec')
      if 'grade_nm' in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa:TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['mpaa']=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('grade_nm')
     except:
      TFRfexWmQBlcHGLoNzvDVhPqUdYySs
     try:
      TFRfexWmQBlcHGLoNzvDVhPqUdYywr=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa.get('broad_dt')
      if data_str!='':
       TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['aired']='%s-%s-%s'%(TFRfexWmQBlcHGLoNzvDVhPqUdYywr[:4],TFRfexWmQBlcHGLoNzvDVhPqUdYywr[4:6],TFRfexWmQBlcHGLoNzvDVhPqUdYywr[6:])
       TFRfexWmQBlcHGLoNzvDVhPqUdYyJX['year']=TFRfexWmQBlcHGLoNzvDVhPqUdYywr[:4]
     except:
      TFRfexWmQBlcHGLoNzvDVhPqUdYySs
     TFRfexWmQBlcHGLoNzvDVhPqUdYyJC={'movie':TFRfexWmQBlcHGLoNzvDVhPqUdYyJi,'title':TFRfexWmQBlcHGLoNzvDVhPqUdYyJE,'thumbnail':TFRfexWmQBlcHGLoNzvDVhPqUdYyJk,'synopsis':'','info':TFRfexWmQBlcHGLoNzvDVhPqUdYyJX}
     TFRfexWmQBlcHGLoNzvDVhPqUdYywE=TFRfexWmQBlcHGLoNzvDVhPqUdYySt
     for TFRfexWmQBlcHGLoNzvDVhPqUdYywk in TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['bill']:
      if TFRfexWmQBlcHGLoNzvDVhPqUdYywk in TFRfexWmQBlcHGLoNzvDVhPqUdYybw.MOVIE_LITE:
       TFRfexWmQBlcHGLoNzvDVhPqUdYywE=TFRfexWmQBlcHGLoNzvDVhPqUdYySK
       break
     if TFRfexWmQBlcHGLoNzvDVhPqUdYywE==TFRfexWmQBlcHGLoNzvDVhPqUdYySt: 
      TFRfexWmQBlcHGLoNzvDVhPqUdYyJC['title']=TFRfexWmQBlcHGLoNzvDVhPqUdYyJC['title']+' [개별구매]'
     TFRfexWmQBlcHGLoNzvDVhPqUdYywu.append(TFRfexWmQBlcHGLoNzvDVhPqUdYyJC)
  except TFRfexWmQBlcHGLoNzvDVhPqUdYySM as exception:
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(exception)
  return TFRfexWmQBlcHGLoNzvDVhPqUdYywu,TFRfexWmQBlcHGLoNzvDVhPqUdYyJn
 def GetDeviceList(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,TFRfexWmQBlcHGLoNzvDVhPqUdYybg,TFRfexWmQBlcHGLoNzvDVhPqUdYyOb):
  TFRfexWmQBlcHGLoNzvDVhPqUdYyJr=[]
  TFRfexWmQBlcHGLoNzvDVhPqUdYyOs='-'
  try:
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOt ='/v1/user/device/list'
   TFRfexWmQBlcHGLoNzvDVhPqUdYywi=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.API_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOt
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOA={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   TFRfexWmQBlcHGLoNzvDVhPqUdYybn=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.makeDefaultCookies(vToken=TFRfexWmQBlcHGLoNzvDVhPqUdYybg,vUserinfo=TFRfexWmQBlcHGLoNzvDVhPqUdYyOb)
   TFRfexWmQBlcHGLoNzvDVhPqUdYybC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.callRequestCookies('Get',TFRfexWmQBlcHGLoNzvDVhPqUdYywi,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,params=TFRfexWmQBlcHGLoNzvDVhPqUdYyOA,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYybn)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOM=json.loads(TFRfexWmQBlcHGLoNzvDVhPqUdYybC.text)
   TFRfexWmQBlcHGLoNzvDVhPqUdYyJr=TFRfexWmQBlcHGLoNzvDVhPqUdYyOM['body']
   for TFRfexWmQBlcHGLoNzvDVhPqUdYyOa in TFRfexWmQBlcHGLoNzvDVhPqUdYyJr:
    if TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['model']=='PC':
     TFRfexWmQBlcHGLoNzvDVhPqUdYyOs=TFRfexWmQBlcHGLoNzvDVhPqUdYyOa['uuid']
  except TFRfexWmQBlcHGLoNzvDVhPqUdYySM as exception:
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(exception)
  return TFRfexWmQBlcHGLoNzvDVhPqUdYyOs
 def GetProfileToken(TFRfexWmQBlcHGLoNzvDVhPqUdYybw,TFRfexWmQBlcHGLoNzvDVhPqUdYybg,TFRfexWmQBlcHGLoNzvDVhPqUdYyOb,user_pf):
  TFRfexWmQBlcHGLoNzvDVhPqUdYywg=[]
  TFRfexWmQBlcHGLoNzvDVhPqUdYySb =''
  TFRfexWmQBlcHGLoNzvDVhPqUdYySO =''
  TFRfexWmQBlcHGLoNzvDVhPqUdYySJ='Y'
  TFRfexWmQBlcHGLoNzvDVhPqUdYySw ='N'
  try:
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOt ='/profile/select.do'
   TFRfexWmQBlcHGLoNzvDVhPqUdYywi=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.URL_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOt
   TFRfexWmQBlcHGLoNzvDVhPqUdYybn=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.makeDefaultCookies(vToken=TFRfexWmQBlcHGLoNzvDVhPqUdYybg,vUserinfo=TFRfexWmQBlcHGLoNzvDVhPqUdYyOb)
   TFRfexWmQBlcHGLoNzvDVhPqUdYybC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.callRequestCookies('Get',TFRfexWmQBlcHGLoNzvDVhPqUdYywi,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,params=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYybn)
   TFRfexWmQBlcHGLoNzvDVhPqUdYywg =re.findall('data-profile-no="\d{9}"',TFRfexWmQBlcHGLoNzvDVhPqUdYybC.text)
   for i in TFRfexWmQBlcHGLoNzvDVhPqUdYySA(TFRfexWmQBlcHGLoNzvDVhPqUdYySa(TFRfexWmQBlcHGLoNzvDVhPqUdYywg)):
    TFRfexWmQBlcHGLoNzvDVhPqUdYySr =TFRfexWmQBlcHGLoNzvDVhPqUdYywg[i].replace('data-profile-no=','').replace('"','')
    TFRfexWmQBlcHGLoNzvDVhPqUdYywg[i]=TFRfexWmQBlcHGLoNzvDVhPqUdYySr
   TFRfexWmQBlcHGLoNzvDVhPqUdYySb=TFRfexWmQBlcHGLoNzvDVhPqUdYywg[user_pf]
  except TFRfexWmQBlcHGLoNzvDVhPqUdYySM as exception:
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(exception)
   return TFRfexWmQBlcHGLoNzvDVhPqUdYySO,TFRfexWmQBlcHGLoNzvDVhPqUdYySJ,TFRfexWmQBlcHGLoNzvDVhPqUdYySw
  try:
   TFRfexWmQBlcHGLoNzvDVhPqUdYyOt ='/profile/api/select.do'
   TFRfexWmQBlcHGLoNzvDVhPqUdYywi=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.URL_DOMAIN+TFRfexWmQBlcHGLoNzvDVhPqUdYyOt
   TFRfexWmQBlcHGLoNzvDVhPqUdYybn=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.makeDefaultCookies(vToken=TFRfexWmQBlcHGLoNzvDVhPqUdYybg,vUserinfo=TFRfexWmQBlcHGLoNzvDVhPqUdYyOb)
   TFRfexWmQBlcHGLoNzvDVhPqUdYybI={'profileNo':TFRfexWmQBlcHGLoNzvDVhPqUdYySb}
   TFRfexWmQBlcHGLoNzvDVhPqUdYybC=TFRfexWmQBlcHGLoNzvDVhPqUdYybw.callRequestCookies('Post',TFRfexWmQBlcHGLoNzvDVhPqUdYywi,payload=TFRfexWmQBlcHGLoNzvDVhPqUdYybI,params=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,headers=TFRfexWmQBlcHGLoNzvDVhPqUdYySs,cookies=TFRfexWmQBlcHGLoNzvDVhPqUdYybn)
   for TFRfexWmQBlcHGLoNzvDVhPqUdYybi in TFRfexWmQBlcHGLoNzvDVhPqUdYybC.cookies:
    if TFRfexWmQBlcHGLoNzvDVhPqUdYybi.name=='_tving_token':
     TFRfexWmQBlcHGLoNzvDVhPqUdYySO=TFRfexWmQBlcHGLoNzvDVhPqUdYybi.value
    elif TFRfexWmQBlcHGLoNzvDVhPqUdYybi.name==TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GLOBAL_COOKIENM['tv_cookiekey']:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySJ=TFRfexWmQBlcHGLoNzvDVhPqUdYybi.value
    elif TFRfexWmQBlcHGLoNzvDVhPqUdYybi.name==TFRfexWmQBlcHGLoNzvDVhPqUdYybw.GLOBAL_COOKIENM['tv_lockkey']:
     TFRfexWmQBlcHGLoNzvDVhPqUdYySw=TFRfexWmQBlcHGLoNzvDVhPqUdYybi.value
  except TFRfexWmQBlcHGLoNzvDVhPqUdYySM as exception:
   TFRfexWmQBlcHGLoNzvDVhPqUdYySE(exception)
  return TFRfexWmQBlcHGLoNzvDVhPqUdYySO,TFRfexWmQBlcHGLoNzvDVhPqUdYySJ,TFRfexWmQBlcHGLoNzvDVhPqUdYySw
# Created by pyminifier (https://github.com/liftoff/pyminifier)
