__author__="NightRain"
PKMLJFkyoNbcDAYwtCzUdISfpsHvmG=object
PKMLJFkyoNbcDAYwtCzUdISfpsHvmu=None
PKMLJFkyoNbcDAYwtCzUdISfpsHvml=int
PKMLJFkyoNbcDAYwtCzUdISfpsHvmT=False
PKMLJFkyoNbcDAYwtCzUdISfpsHvmV=True
PKMLJFkyoNbcDAYwtCzUdISfpsHvmE=len
PKMLJFkyoNbcDAYwtCzUdISfpsHvmQ=str
PKMLJFkyoNbcDAYwtCzUdISfpsHvmO=open
PKMLJFkyoNbcDAYwtCzUdISfpsHvmn=dict
PKMLJFkyoNbcDAYwtCzUdISfpsHvmh=Exception
PKMLJFkyoNbcDAYwtCzUdISfpsHvma=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
PKMLJFkyoNbcDAYwtCzUdISfpsHvRj=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
PKMLJFkyoNbcDAYwtCzUdISfpsHvRG=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
PKMLJFkyoNbcDAYwtCzUdISfpsHvRu=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
PKMLJFkyoNbcDAYwtCzUdISfpsHvRm=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
PKMLJFkyoNbcDAYwtCzUdISfpsHvRl=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'PROGRAM','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
PKMLJFkyoNbcDAYwtCzUdISfpsHvRT=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
PKMLJFkyoNbcDAYwtCzUdISfpsHvRV={'C00551':'tvN','C00544':'중화TV','C00575':'Olive','C00579':'Mnet','C00590':'OGN','C01141':'XtvN','C01142':'ONSTYLE','C01143':'OtvN','C04601':'OCN Movies','C06941':'tooniverse','C07381':'OCN','C07382':'OCN Thrills','C15251':'OGN x LOL','C15252':'OGN x 오버워치','C15042':'티빙라이브','C01581':'TV CHOSUN','C01583':'채널A','C00708':'MBN','C00593':'YTN','C01101':'YTN Life','C15347':'YTN science','C01723':'연합뉴스TV','C15152':'CH.DIA','C01582':'JTBC','C00588':'JTBC Golf','C15741':'JTBC2','C00805':'JTBC3 FOX Sports','C05661':'디즈니채널','C18641':'IHQ','C22041':'JTBC4','C23343':'t.cast','C23441':'E channel','C17341':'히스토리','C00585':'TV CHOSUN2','C17141':'채널A 플러스','C00611':'LIFETIME','C08041':'tvN go','C05901':'채널W','C23442':"D'LIVE",'C27441':'KBS N','C15846':'SBS CNBC','C43241':'Nickelodeon','C43242':'SBS MTV','C43341':'SBS FiL','C43342':'KPOP','C17142':'MBN+'}
PKMLJFkyoNbcDAYwtCzUdISfpsHvRE=xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class PKMLJFkyoNbcDAYwtCzUdISfpsHvRg(PKMLJFkyoNbcDAYwtCzUdISfpsHvmG):
 def __init__(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvRO,PKMLJFkyoNbcDAYwtCzUdISfpsHvRn,PKMLJFkyoNbcDAYwtCzUdISfpsHvRh):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_url =PKMLJFkyoNbcDAYwtCzUdISfpsHvRO
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_handle=PKMLJFkyoNbcDAYwtCzUdISfpsHvRn
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.main_params =PKMLJFkyoNbcDAYwtCzUdISfpsHvRh
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj =TFRfexWmQBlcHGLoNzvDVhPqUdYybO() 
 def addon_noti(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,sting):
  try:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRi=xbmcgui.Dialog()
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRi.notification(__addonname__,sting)
  except:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvmu
 def addon_log(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,string):
  try:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRe=string.encode('utf-8','ignore')
  except:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRe='addonException: addon_log'
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRq=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,PKMLJFkyoNbcDAYwtCzUdISfpsHvRe),level=PKMLJFkyoNbcDAYwtCzUdISfpsHvRq)
 def get_keyboard_input(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvgT):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRW=PKMLJFkyoNbcDAYwtCzUdISfpsHvmu
  kb=xbmc.Keyboard()
  kb.setHeading(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRW=kb.getText()
  return PKMLJFkyoNbcDAYwtCzUdISfpsHvRW
 def get_settings_login_info(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRx =__addon__.getSetting('id')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRB =__addon__.getSetting('pw')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRX =__addon__.getSetting('login_type')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRr=PKMLJFkyoNbcDAYwtCzUdISfpsHvml(__addon__.getSetting('selected_profile'))
  return(PKMLJFkyoNbcDAYwtCzUdISfpsHvRx,PKMLJFkyoNbcDAYwtCzUdISfpsHvRB,PKMLJFkyoNbcDAYwtCzUdISfpsHvRX,PKMLJFkyoNbcDAYwtCzUdISfpsHvRr)
 def get_settings_premiumyn(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgR =__addon__.getSetting('premium_movieyn')
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvgR=='false':
   return PKMLJFkyoNbcDAYwtCzUdISfpsHvmT
  else:
   return PKMLJFkyoNbcDAYwtCzUdISfpsHvmV
 def get_settings_direct_replay(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgj=PKMLJFkyoNbcDAYwtCzUdISfpsHvml(__addon__.getSetting('direct_replay'))
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvgj==0:
   return PKMLJFkyoNbcDAYwtCzUdISfpsHvmT
  else:
   return PKMLJFkyoNbcDAYwtCzUdISfpsHvmV
 def get_settings_thumbnail_landyn(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgG =PKMLJFkyoNbcDAYwtCzUdISfpsHvml(__addon__.getSetting('thumbnail_way'))
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvgG==0:
   return PKMLJFkyoNbcDAYwtCzUdISfpsHvmV
  else:
   return PKMLJFkyoNbcDAYwtCzUdISfpsHvmT
 def set_winCredential(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,credential):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu=xbmcgui.Window(10000)
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_LOGINTIME',PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu=xbmcgui.Window(10000)
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgm={'tving_token':PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.getProperty('TVING_M_TOKEN'),'poc_userinfo':PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.getProperty('TVING_M_USERINFO'),'tving_uuid':PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.getProperty('TVING_M_UUID'),'tving_maintoken':PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.getProperty('TVING_M_LOCKKEY')}
  return PKMLJFkyoNbcDAYwtCzUdISfpsHvgm
 def set_winEpisodeOrderby(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvje):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu=xbmcgui.Window(10000)
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_ORDERBY',PKMLJFkyoNbcDAYwtCzUdISfpsHvje)
 def get_winEpisodeOrderby(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu=xbmcgui.Window(10000)
  return PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.getProperty('TVING_M_ORDERBY')
 def add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,label,sublabel='',img='',infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvmu,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV,params=''):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgl='%s?%s'%(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_url,urllib.parse.urlencode(params))
  if sublabel:PKMLJFkyoNbcDAYwtCzUdISfpsHvgT='%s < %s >'%(label,sublabel)
  else: PKMLJFkyoNbcDAYwtCzUdISfpsHvgT=label
  if not img:img='DefaultFolder.png'
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgV=xbmcgui.ListItem(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT)
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgV.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:PKMLJFkyoNbcDAYwtCzUdISfpsHvgV.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:PKMLJFkyoNbcDAYwtCzUdISfpsHvgV.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_handle,PKMLJFkyoNbcDAYwtCzUdISfpsHvgl,PKMLJFkyoNbcDAYwtCzUdISfpsHvgV,isFolder)
 def get_selQuality(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,etype):
  try:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgE='selected_quality'
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgQ=[1080,720,480,360]
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgO=PKMLJFkyoNbcDAYwtCzUdISfpsHvml(__addon__.getSetting(PKMLJFkyoNbcDAYwtCzUdISfpsHvgE))
   return PKMLJFkyoNbcDAYwtCzUdISfpsHvgQ[PKMLJFkyoNbcDAYwtCzUdISfpsHvgO]
  except:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvmu
  return 720 
 def dp_Main_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ):
  for PKMLJFkyoNbcDAYwtCzUdISfpsHvgn in PKMLJFkyoNbcDAYwtCzUdISfpsHvRj:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT=PKMLJFkyoNbcDAYwtCzUdISfpsHvgn.get('title')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':PKMLJFkyoNbcDAYwtCzUdISfpsHvgn.get('mode'),'stype':PKMLJFkyoNbcDAYwtCzUdISfpsHvgn.get('stype'),'orderby':PKMLJFkyoNbcDAYwtCzUdISfpsHvgn.get('orderby'),'ordernm':PKMLJFkyoNbcDAYwtCzUdISfpsHvgn.get('ordernm'),'page':'1'}
   if PKMLJFkyoNbcDAYwtCzUdISfpsHvgn.get('mode')=='XXX':
    PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['mode']='XXX'
    PKMLJFkyoNbcDAYwtCzUdISfpsHvga=PKMLJFkyoNbcDAYwtCzUdISfpsHvmT
   else:
    PKMLJFkyoNbcDAYwtCzUdISfpsHvga=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel='',img='',infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvmu,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvga,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvmE(PKMLJFkyoNbcDAYwtCzUdISfpsHvRj)>0:xbmcplugin.endOfDirectory(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_handle)
 def login_main(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ):
  (PKMLJFkyoNbcDAYwtCzUdISfpsHvge,PKMLJFkyoNbcDAYwtCzUdISfpsHvgq,PKMLJFkyoNbcDAYwtCzUdISfpsHvgW,PKMLJFkyoNbcDAYwtCzUdISfpsHvgx)=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_settings_login_info()
  if not(PKMLJFkyoNbcDAYwtCzUdISfpsHvge and PKMLJFkyoNbcDAYwtCzUdISfpsHvgq):
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRi=xbmcgui.Dialog()
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgB=PKMLJFkyoNbcDAYwtCzUdISfpsHvRi.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if PKMLJFkyoNbcDAYwtCzUdISfpsHvgB==PKMLJFkyoNbcDAYwtCzUdISfpsHvmV:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_winEpisodeOrderby()=='':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.set_winEpisodeOrderby('desc')
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.cookiefile_check():return
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgX =PKMLJFkyoNbcDAYwtCzUdISfpsHvml(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgr=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvgr==PKMLJFkyoNbcDAYwtCzUdISfpsHvmu or PKMLJFkyoNbcDAYwtCzUdISfpsHvgr=='':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgr=PKMLJFkyoNbcDAYwtCzUdISfpsHvml('19000101')
  else:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgr=PKMLJFkyoNbcDAYwtCzUdISfpsHvml(re.sub('-','',PKMLJFkyoNbcDAYwtCzUdISfpsHvgr))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjR=0
   while PKMLJFkyoNbcDAYwtCzUdISfpsHvmV:
    PKMLJFkyoNbcDAYwtCzUdISfpsHvjR+=1
    time.sleep(0.05)
    if PKMLJFkyoNbcDAYwtCzUdISfpsHvgr>=PKMLJFkyoNbcDAYwtCzUdISfpsHvgX:return
    if PKMLJFkyoNbcDAYwtCzUdISfpsHvjR>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvgr>=PKMLJFkyoNbcDAYwtCzUdISfpsHvgX:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.GetCredential(PKMLJFkyoNbcDAYwtCzUdISfpsHvge,PKMLJFkyoNbcDAYwtCzUdISfpsHvgq,PKMLJFkyoNbcDAYwtCzUdISfpsHvgW,PKMLJFkyoNbcDAYwtCzUdISfpsHvgx):
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.set_winCredential(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.LoadCredential())
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjm):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjg=PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('stype')
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvjg=='live':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjG=PKMLJFkyoNbcDAYwtCzUdISfpsHvRG
  elif PKMLJFkyoNbcDAYwtCzUdISfpsHvjg=='vod':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjG=PKMLJFkyoNbcDAYwtCzUdISfpsHvRl
  else:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjG=PKMLJFkyoNbcDAYwtCzUdISfpsHvRT
  for PKMLJFkyoNbcDAYwtCzUdISfpsHvju in PKMLJFkyoNbcDAYwtCzUdISfpsHvjG:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT=PKMLJFkyoNbcDAYwtCzUdISfpsHvju.get('title')
   if PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('ordernm')!='-':
    PKMLJFkyoNbcDAYwtCzUdISfpsHvgT+='  ('+PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('ordernm')+')'
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':PKMLJFkyoNbcDAYwtCzUdISfpsHvju.get('mode'),'stype':PKMLJFkyoNbcDAYwtCzUdISfpsHvju.get('stype'),'orderby':PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('orderby'),'page':'1'}
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel='',img='',infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvmu,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvmE(PKMLJFkyoNbcDAYwtCzUdISfpsHvjG)>0:xbmcplugin.endOfDirectory(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_handle)
 def dp_LiveChannel_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjm):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.SaveCredential(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_winCredential())
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjg =PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('stype')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjl =PKMLJFkyoNbcDAYwtCzUdISfpsHvml(PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('page'))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjT,PKMLJFkyoNbcDAYwtCzUdISfpsHvjV=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.GetLiveChannelList(PKMLJFkyoNbcDAYwtCzUdISfpsHvjg,PKMLJFkyoNbcDAYwtCzUdISfpsHvjl)
  for PKMLJFkyoNbcDAYwtCzUdISfpsHvjE in PKMLJFkyoNbcDAYwtCzUdISfpsHvjT:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT =PKMLJFkyoNbcDAYwtCzUdISfpsHvjE.get('title')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgi =PKMLJFkyoNbcDAYwtCzUdISfpsHvjE.get('channel')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ =PKMLJFkyoNbcDAYwtCzUdISfpsHvjE.get('thumbnail')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjO =PKMLJFkyoNbcDAYwtCzUdISfpsHvjE.get('synopsis')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjn=PKMLJFkyoNbcDAYwtCzUdISfpsHvjE.get('channelepg')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjh=PKMLJFkyoNbcDAYwtCzUdISfpsHvjE.get('info')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjh['plot']='%s\n%s\n%s\n\n%s'%(PKMLJFkyoNbcDAYwtCzUdISfpsHvgi,PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,PKMLJFkyoNbcDAYwtCzUdISfpsHvjn,PKMLJFkyoNbcDAYwtCzUdISfpsHvjO)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':'LIVE','mediacode':PKMLJFkyoNbcDAYwtCzUdISfpsHvjE.get('mediacode'),'stype':PKMLJFkyoNbcDAYwtCzUdISfpsHvjg}
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgi,sublabel=PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,img=PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ,infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvjh,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmT,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvjV:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['mode']='CHANNEL' 
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['stype']=PKMLJFkyoNbcDAYwtCzUdISfpsHvjg 
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['page']=PKMLJFkyoNbcDAYwtCzUdISfpsHvmQ(PKMLJFkyoNbcDAYwtCzUdISfpsHvjl+1)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT='[B]%s >>[/B]'%'다음 페이지'
   PKMLJFkyoNbcDAYwtCzUdISfpsHvja=PKMLJFkyoNbcDAYwtCzUdISfpsHvmQ(PKMLJFkyoNbcDAYwtCzUdISfpsHvjl+1)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel=PKMLJFkyoNbcDAYwtCzUdISfpsHvja,img='',infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvmu,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvmE(PKMLJFkyoNbcDAYwtCzUdISfpsHvjT)>0:xbmcplugin.endOfDirectory(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_handle,cacheToDisc=PKMLJFkyoNbcDAYwtCzUdISfpsHvmT)
 def dp_Program_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjm):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.SaveCredential(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_winCredential())
  PKMLJFkyoNbcDAYwtCzUdISfpsHvji =PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('stype')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvje =PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('orderby')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjl =PKMLJFkyoNbcDAYwtCzUdISfpsHvml(PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('page'))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjq,PKMLJFkyoNbcDAYwtCzUdISfpsHvjV=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.GetProgramList(PKMLJFkyoNbcDAYwtCzUdISfpsHvji,PKMLJFkyoNbcDAYwtCzUdISfpsHvje,PKMLJFkyoNbcDAYwtCzUdISfpsHvjl,landyn=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_settings_thumbnail_landyn())
  for PKMLJFkyoNbcDAYwtCzUdISfpsHvjW in PKMLJFkyoNbcDAYwtCzUdISfpsHvjq:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT =PKMLJFkyoNbcDAYwtCzUdISfpsHvjW.get('title')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ=PKMLJFkyoNbcDAYwtCzUdISfpsHvjW.get('thumbnail')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjO =PKMLJFkyoNbcDAYwtCzUdISfpsHvjW.get('synopsis')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjx =PKMLJFkyoNbcDAYwtCzUdISfpsHvRV.get(PKMLJFkyoNbcDAYwtCzUdISfpsHvjW.get('channel'))
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjh=PKMLJFkyoNbcDAYwtCzUdISfpsHvjW.get('info')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjh['studio']=PKMLJFkyoNbcDAYwtCzUdISfpsHvjx
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjh['plot']='%s <%s>\n\n%s'%(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,PKMLJFkyoNbcDAYwtCzUdISfpsHvjx,PKMLJFkyoNbcDAYwtCzUdISfpsHvjO)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':'EPISODE','programcode':PKMLJFkyoNbcDAYwtCzUdISfpsHvjW.get('program'),'page':'1'}
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel=PKMLJFkyoNbcDAYwtCzUdISfpsHvjx,img=PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ,infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvjh,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvjV:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['mode'] ='PROGRAM' 
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['stype'] =PKMLJFkyoNbcDAYwtCzUdISfpsHvji
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['orderby']=PKMLJFkyoNbcDAYwtCzUdISfpsHvje
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['page'] =PKMLJFkyoNbcDAYwtCzUdISfpsHvmQ(PKMLJFkyoNbcDAYwtCzUdISfpsHvjl+1)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT='[B]%s >>[/B]'%'다음 페이지'
   PKMLJFkyoNbcDAYwtCzUdISfpsHvja=PKMLJFkyoNbcDAYwtCzUdISfpsHvmQ(PKMLJFkyoNbcDAYwtCzUdISfpsHvjl+1)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel=PKMLJFkyoNbcDAYwtCzUdISfpsHvja,img='',infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvmu,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvmE(PKMLJFkyoNbcDAYwtCzUdISfpsHvjq)>0:xbmcplugin.endOfDirectory(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_handle,cacheToDisc=PKMLJFkyoNbcDAYwtCzUdISfpsHvmT)
 def dp_Episode_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjm):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.SaveCredential(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_winCredential())
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjB=PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('programcode')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjl =PKMLJFkyoNbcDAYwtCzUdISfpsHvml(PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('page'))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjX,PKMLJFkyoNbcDAYwtCzUdISfpsHvjV,PKMLJFkyoNbcDAYwtCzUdISfpsHvjr=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.GetEpisodoList(PKMLJFkyoNbcDAYwtCzUdISfpsHvjB,PKMLJFkyoNbcDAYwtCzUdISfpsHvjl,orderby=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_winEpisodeOrderby())
  for PKMLJFkyoNbcDAYwtCzUdISfpsHvGR in PKMLJFkyoNbcDAYwtCzUdISfpsHvjX:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT =PKMLJFkyoNbcDAYwtCzUdISfpsHvGR.get('title')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvja =PKMLJFkyoNbcDAYwtCzUdISfpsHvGR.get('subtitle')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ=PKMLJFkyoNbcDAYwtCzUdISfpsHvGR.get('thumbnail')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjO =PKMLJFkyoNbcDAYwtCzUdISfpsHvGR.get('synopsis')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjh=PKMLJFkyoNbcDAYwtCzUdISfpsHvGR.get('info')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjh['plot']='%s\n\n%s'%(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,PKMLJFkyoNbcDAYwtCzUdISfpsHvjO)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':'VOD','mediacode':PKMLJFkyoNbcDAYwtCzUdISfpsHvGR.get('episode'),'stype':'vod','programcode':PKMLJFkyoNbcDAYwtCzUdISfpsHvjB,'title':PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,'thumbnail':PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ}
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel=PKMLJFkyoNbcDAYwtCzUdISfpsHvja,img=PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ,infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvjh,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmT,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvjl==1:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjh={'plot':'정렬순서를 변경합니다.'}
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={}
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['mode'] ='ORDER_BY' 
   if PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_winEpisodeOrderby()=='desc':
    PKMLJFkyoNbcDAYwtCzUdISfpsHvgT='정렬순서변경 : 최신화부터 -> 1회부터'
    PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['orderby']='asc'
   else:
    PKMLJFkyoNbcDAYwtCzUdISfpsHvgT='정렬순서변경 : 1회부터 -> 최신화부터'
    PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['orderby']='desc'
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel='',img='',infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvjh,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmT,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvjV:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['mode'] ='EPISODE' 
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['programcode']=PKMLJFkyoNbcDAYwtCzUdISfpsHvjB
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['page'] =PKMLJFkyoNbcDAYwtCzUdISfpsHvmQ(PKMLJFkyoNbcDAYwtCzUdISfpsHvjl+1)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT='[B]%s >>[/B]'%'다음 페이지'
   PKMLJFkyoNbcDAYwtCzUdISfpsHvja=PKMLJFkyoNbcDAYwtCzUdISfpsHvmQ(PKMLJFkyoNbcDAYwtCzUdISfpsHvjl+1)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel=PKMLJFkyoNbcDAYwtCzUdISfpsHvja,img='',infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvmu,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvmE(PKMLJFkyoNbcDAYwtCzUdISfpsHvjX)>0:xbmcplugin.endOfDirectory(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_handle,cacheToDisc=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV)
 def dp_setEpOrderby(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjm):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvje =PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('orderby')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.set_winEpisodeOrderby(PKMLJFkyoNbcDAYwtCzUdISfpsHvje)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjm):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.SaveCredential(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_winCredential())
  PKMLJFkyoNbcDAYwtCzUdISfpsHvji =PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('stype')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvje =PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('orderby')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjl=PKMLJFkyoNbcDAYwtCzUdISfpsHvml(PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('page'))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvGg,PKMLJFkyoNbcDAYwtCzUdISfpsHvjV=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.GetMovieList(PKMLJFkyoNbcDAYwtCzUdISfpsHvji,PKMLJFkyoNbcDAYwtCzUdISfpsHvje,PKMLJFkyoNbcDAYwtCzUdISfpsHvjl,landyn=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_settings_thumbnail_landyn())
  for PKMLJFkyoNbcDAYwtCzUdISfpsHvGj in PKMLJFkyoNbcDAYwtCzUdISfpsHvGg:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT =PKMLJFkyoNbcDAYwtCzUdISfpsHvGj.get('title')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ=PKMLJFkyoNbcDAYwtCzUdISfpsHvGj.get('thumbnail')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjO =PKMLJFkyoNbcDAYwtCzUdISfpsHvGj.get('synopsis')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjh=PKMLJFkyoNbcDAYwtCzUdISfpsHvGj.get('info')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjh['plot']='%s\n\n%s'%(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,PKMLJFkyoNbcDAYwtCzUdISfpsHvjO)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':'MOVIE','mediacode':PKMLJFkyoNbcDAYwtCzUdISfpsHvGj.get('moviecode'),'stype':'movie','title':PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,'thumbnail':PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ}
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel='',img=PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ,infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvjh,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmT,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvjV:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={}
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['mode'] ='MOVIE_SUB' 
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['orderby']=PKMLJFkyoNbcDAYwtCzUdISfpsHvje
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['stype'] =PKMLJFkyoNbcDAYwtCzUdISfpsHvji
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['page'] =PKMLJFkyoNbcDAYwtCzUdISfpsHvmQ(PKMLJFkyoNbcDAYwtCzUdISfpsHvjl+1)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT='[B]%s >>[/B]'%'다음 페이지'
   PKMLJFkyoNbcDAYwtCzUdISfpsHvja=PKMLJFkyoNbcDAYwtCzUdISfpsHvmQ(PKMLJFkyoNbcDAYwtCzUdISfpsHvjl+1)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel=PKMLJFkyoNbcDAYwtCzUdISfpsHvja,img='',infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvmu,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvmE(PKMLJFkyoNbcDAYwtCzUdISfpsHvGg)>0:xbmcplugin.endOfDirectory(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_handle,cacheToDisc=PKMLJFkyoNbcDAYwtCzUdISfpsHvmT)
 def dp_Search_Group(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjm):
  for PKMLJFkyoNbcDAYwtCzUdISfpsHvju in PKMLJFkyoNbcDAYwtCzUdISfpsHvRm:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT=PKMLJFkyoNbcDAYwtCzUdISfpsHvju.get('title')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':PKMLJFkyoNbcDAYwtCzUdISfpsHvju.get('mode'),'stype':PKMLJFkyoNbcDAYwtCzUdISfpsHvju.get('stype'),'page':'1'}
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel='',img='',infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvmu,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvmE(PKMLJFkyoNbcDAYwtCzUdISfpsHvRm)>0:xbmcplugin.endOfDirectory(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_handle)
 def dp_Search_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjm):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.SaveCredential(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_winCredential())
  PKMLJFkyoNbcDAYwtCzUdISfpsHvGu =__addon__.getSetting('id')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjl =PKMLJFkyoNbcDAYwtCzUdISfpsHvml(PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('page'))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjg =PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('stype')
  if 'search_key' in PKMLJFkyoNbcDAYwtCzUdISfpsHvjm:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvGm=PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('search_key')
  else:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvGm=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not PKMLJFkyoNbcDAYwtCzUdISfpsHvGm:return
  PKMLJFkyoNbcDAYwtCzUdISfpsHvGl,PKMLJFkyoNbcDAYwtCzUdISfpsHvjV=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.GetSearchList(PKMLJFkyoNbcDAYwtCzUdISfpsHvGm,PKMLJFkyoNbcDAYwtCzUdISfpsHvGu,PKMLJFkyoNbcDAYwtCzUdISfpsHvjl,PKMLJFkyoNbcDAYwtCzUdISfpsHvjg,landyn=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_settings_thumbnail_landyn())
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvmE(PKMLJFkyoNbcDAYwtCzUdISfpsHvGl)==0:return
  for PKMLJFkyoNbcDAYwtCzUdISfpsHvGT in PKMLJFkyoNbcDAYwtCzUdISfpsHvGl:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT =PKMLJFkyoNbcDAYwtCzUdISfpsHvGT.get('title')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ=PKMLJFkyoNbcDAYwtCzUdISfpsHvGT.get('thumbnail')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjO =PKMLJFkyoNbcDAYwtCzUdISfpsHvGT.get('synopsis')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvGV =PKMLJFkyoNbcDAYwtCzUdISfpsHvGT.get('program')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjh=PKMLJFkyoNbcDAYwtCzUdISfpsHvGT.get('info')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjh['plot']='%s\n\n%s'%(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,PKMLJFkyoNbcDAYwtCzUdISfpsHvjO)
   if PKMLJFkyoNbcDAYwtCzUdISfpsHvjg=='vod':
    PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':'EPISODE','programcode':PKMLJFkyoNbcDAYwtCzUdISfpsHvGT.get('program'),'page':'1'}
    PKMLJFkyoNbcDAYwtCzUdISfpsHvga=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV
   else:
    PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':'MOVIE','mediacode':PKMLJFkyoNbcDAYwtCzUdISfpsHvGT.get('movie'),'stype':'movie','title':PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,'thumbnail':PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ}
    PKMLJFkyoNbcDAYwtCzUdISfpsHvga=PKMLJFkyoNbcDAYwtCzUdISfpsHvmT
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel='',img=PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ,infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvjh,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvga,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvjV:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['mode'] ='SEARCH' 
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['search_key']=PKMLJFkyoNbcDAYwtCzUdISfpsHvGm
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh['page'] =PKMLJFkyoNbcDAYwtCzUdISfpsHvmQ(PKMLJFkyoNbcDAYwtCzUdISfpsHvjl+1)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT='[B]%s >>[/B]'%'다음 페이지'
   PKMLJFkyoNbcDAYwtCzUdISfpsHvja=PKMLJFkyoNbcDAYwtCzUdISfpsHvmQ(PKMLJFkyoNbcDAYwtCzUdISfpsHvjl+1)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel=PKMLJFkyoNbcDAYwtCzUdISfpsHvja,img='',infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvmu,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvmE(PKMLJFkyoNbcDAYwtCzUdISfpsHvGl)>0:xbmcplugin.endOfDirectory(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_handle)
 def Delete_Watched_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjg):
  try:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvGE=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PKMLJFkyoNbcDAYwtCzUdISfpsHvjg))
   fp=PKMLJFkyoNbcDAYwtCzUdISfpsHvmO(PKMLJFkyoNbcDAYwtCzUdISfpsHvGE,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvmu
 def dp_WatchList_Delete(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjm):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjg=PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('stype')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRi=xbmcgui.Dialog()
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgB=PKMLJFkyoNbcDAYwtCzUdISfpsHvRi.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvgB==PKMLJFkyoNbcDAYwtCzUdISfpsHvmT:sys.exit()
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.Delete_Watched_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvjg)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjg):
  try:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvGE=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PKMLJFkyoNbcDAYwtCzUdISfpsHvjg))
   fp=PKMLJFkyoNbcDAYwtCzUdISfpsHvmO(PKMLJFkyoNbcDAYwtCzUdISfpsHvGE,'r',-1,'utf-8')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvGQ=fp.readlines()
   fp.close()
  except:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvGQ=[]
  return PKMLJFkyoNbcDAYwtCzUdISfpsHvGQ
 def Save_Watched_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjg,PKMLJFkyoNbcDAYwtCzUdISfpsHvRh):
  try:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvGE=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PKMLJFkyoNbcDAYwtCzUdISfpsHvjg))
   PKMLJFkyoNbcDAYwtCzUdISfpsHvGO=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.Load_Watched_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvjg) 
   fp=PKMLJFkyoNbcDAYwtCzUdISfpsHvmO(PKMLJFkyoNbcDAYwtCzUdISfpsHvGE,'w',-1,'utf-8')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvGn=urllib.parse.urlencode(PKMLJFkyoNbcDAYwtCzUdISfpsHvRh)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvGn=PKMLJFkyoNbcDAYwtCzUdISfpsHvGn+'\n'
   fp.write(PKMLJFkyoNbcDAYwtCzUdISfpsHvGn)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvGh=0
   for PKMLJFkyoNbcDAYwtCzUdISfpsHvGa in PKMLJFkyoNbcDAYwtCzUdISfpsHvGO:
    PKMLJFkyoNbcDAYwtCzUdISfpsHvGi=PKMLJFkyoNbcDAYwtCzUdISfpsHvmn(urllib.parse.parse_qsl(PKMLJFkyoNbcDAYwtCzUdISfpsHvGa))
    PKMLJFkyoNbcDAYwtCzUdISfpsHvGe=PKMLJFkyoNbcDAYwtCzUdISfpsHvRh.get('code').strip()
    PKMLJFkyoNbcDAYwtCzUdISfpsHvGq=PKMLJFkyoNbcDAYwtCzUdISfpsHvGi.get('code').strip()
    if PKMLJFkyoNbcDAYwtCzUdISfpsHvjg=='vod' and PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_settings_direct_replay()==PKMLJFkyoNbcDAYwtCzUdISfpsHvmV:
     PKMLJFkyoNbcDAYwtCzUdISfpsHvGe=PKMLJFkyoNbcDAYwtCzUdISfpsHvRh.get('videoid').strip()
     PKMLJFkyoNbcDAYwtCzUdISfpsHvGq=PKMLJFkyoNbcDAYwtCzUdISfpsHvGi.get('videoid').strip()if PKMLJFkyoNbcDAYwtCzUdISfpsHvGq!=PKMLJFkyoNbcDAYwtCzUdISfpsHvmu else '-'
    if PKMLJFkyoNbcDAYwtCzUdISfpsHvGe!=PKMLJFkyoNbcDAYwtCzUdISfpsHvGq:
     fp.write(PKMLJFkyoNbcDAYwtCzUdISfpsHvGa)
     PKMLJFkyoNbcDAYwtCzUdISfpsHvGh+=1
     if PKMLJFkyoNbcDAYwtCzUdISfpsHvGh>=50:break
   fp.close()
  except:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvmu
 def dp_Watch_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjm):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjg =PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('stype')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgj=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_settings_direct_replay()
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvjg=='-':
   for PKMLJFkyoNbcDAYwtCzUdISfpsHvju in PKMLJFkyoNbcDAYwtCzUdISfpsHvRu:
    PKMLJFkyoNbcDAYwtCzUdISfpsHvgT=PKMLJFkyoNbcDAYwtCzUdISfpsHvju.get('title')
    PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':PKMLJFkyoNbcDAYwtCzUdISfpsHvju.get('mode'),'stype':PKMLJFkyoNbcDAYwtCzUdISfpsHvju.get('stype')}
    PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel='',img='',infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvmu,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
   if PKMLJFkyoNbcDAYwtCzUdISfpsHvmE(PKMLJFkyoNbcDAYwtCzUdISfpsHvRu)>0:xbmcplugin.endOfDirectory(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_handle)
  else:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvGW=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.Load_Watched_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvjg)
   for PKMLJFkyoNbcDAYwtCzUdISfpsHvGx in PKMLJFkyoNbcDAYwtCzUdISfpsHvGW:
    PKMLJFkyoNbcDAYwtCzUdISfpsHvGB=PKMLJFkyoNbcDAYwtCzUdISfpsHvmn(urllib.parse.parse_qsl(PKMLJFkyoNbcDAYwtCzUdISfpsHvGx))
    PKMLJFkyoNbcDAYwtCzUdISfpsHvGX =PKMLJFkyoNbcDAYwtCzUdISfpsHvGB.get('code').strip()
    PKMLJFkyoNbcDAYwtCzUdISfpsHvgT =PKMLJFkyoNbcDAYwtCzUdISfpsHvGB.get('title').strip()
    PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ=PKMLJFkyoNbcDAYwtCzUdISfpsHvGB.get('img').strip()
    PKMLJFkyoNbcDAYwtCzUdISfpsHvGr =PKMLJFkyoNbcDAYwtCzUdISfpsHvGB.get('videoid').strip()
    PKMLJFkyoNbcDAYwtCzUdISfpsHvjh={}
    PKMLJFkyoNbcDAYwtCzUdISfpsHvjh['plot']=PKMLJFkyoNbcDAYwtCzUdISfpsHvgT
    if PKMLJFkyoNbcDAYwtCzUdISfpsHvjg=='vod':
     if PKMLJFkyoNbcDAYwtCzUdISfpsHvgj==PKMLJFkyoNbcDAYwtCzUdISfpsHvmT or PKMLJFkyoNbcDAYwtCzUdISfpsHvGr==PKMLJFkyoNbcDAYwtCzUdISfpsHvmu:
      PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':'EPISODE','programcode':PKMLJFkyoNbcDAYwtCzUdISfpsHvGX,'page':'1'}
      PKMLJFkyoNbcDAYwtCzUdISfpsHvga=PKMLJFkyoNbcDAYwtCzUdISfpsHvmV
     else:
      PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':'VOD','mediacode':PKMLJFkyoNbcDAYwtCzUdISfpsHvGr,'stype':'vod','programcode':PKMLJFkyoNbcDAYwtCzUdISfpsHvGX,'title':PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,'thumbnail':PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ}
      PKMLJFkyoNbcDAYwtCzUdISfpsHvga=PKMLJFkyoNbcDAYwtCzUdISfpsHvmT
    else:
     PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':'MOVIE','mediacode':PKMLJFkyoNbcDAYwtCzUdISfpsHvGX,'stype':'movie','title':PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,'thumbnail':PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ}
     PKMLJFkyoNbcDAYwtCzUdISfpsHvga=PKMLJFkyoNbcDAYwtCzUdISfpsHvmT
    PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel='',img=PKMLJFkyoNbcDAYwtCzUdISfpsHvjQ,infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvjh,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvga,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvjh={'plot':'시청목록을 삭제합니다.'}
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgT='*** 시청목록 삭제 ***'
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'mode':'MYVIEW_REMOVE','stype':PKMLJFkyoNbcDAYwtCzUdISfpsHvjg}
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.add_dir(PKMLJFkyoNbcDAYwtCzUdISfpsHvgT,sublabel='',img='',infoLabels=PKMLJFkyoNbcDAYwtCzUdISfpsHvjh,isFolder=PKMLJFkyoNbcDAYwtCzUdISfpsHvmT,params=PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
   xbmcplugin.endOfDirectory(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_handle,cacheToDisc=PKMLJFkyoNbcDAYwtCzUdISfpsHvmT)
 def play_VIDEO(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ,PKMLJFkyoNbcDAYwtCzUdISfpsHvjm):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.SaveCredential(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_winCredential())
  PKMLJFkyoNbcDAYwtCzUdISfpsHvug =PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('mediacode')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvjg =PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('stype')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvuj =PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('pvrmode')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvuG=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.get_selQuality(PKMLJFkyoNbcDAYwtCzUdISfpsHvjg)
  PKMLJFkyoNbcDAYwtCzUdISfpsHvum,PKMLJFkyoNbcDAYwtCzUdISfpsHvul=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.GetBroadURL(PKMLJFkyoNbcDAYwtCzUdISfpsHvug,PKMLJFkyoNbcDAYwtCzUdISfpsHvuG,PKMLJFkyoNbcDAYwtCzUdISfpsHvjg,PKMLJFkyoNbcDAYwtCzUdISfpsHvuj)
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.addon_log('qt, stype, url : %s - %s - %s'%(PKMLJFkyoNbcDAYwtCzUdISfpsHvmQ(PKMLJFkyoNbcDAYwtCzUdISfpsHvuG),PKMLJFkyoNbcDAYwtCzUdISfpsHvjg,PKMLJFkyoNbcDAYwtCzUdISfpsHvum))
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvum=='':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.addon_noti(__language__(30908).encode('utf8'))
   return
  PKMLJFkyoNbcDAYwtCzUdISfpsHvuT =PKMLJFkyoNbcDAYwtCzUdISfpsHvum.find('Policy=')
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvuT!=-1:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvuV =PKMLJFkyoNbcDAYwtCzUdISfpsHvum.split('?')[0]
   PKMLJFkyoNbcDAYwtCzUdISfpsHvuE=PKMLJFkyoNbcDAYwtCzUdISfpsHvmn(urllib.parse.parse_qsl(urllib.parse.urlsplit(PKMLJFkyoNbcDAYwtCzUdISfpsHvum).query))
   PKMLJFkyoNbcDAYwtCzUdISfpsHvuE=urllib.parse.urlencode(PKMLJFkyoNbcDAYwtCzUdISfpsHvuE)
   PKMLJFkyoNbcDAYwtCzUdISfpsHvuE=PKMLJFkyoNbcDAYwtCzUdISfpsHvuE.replace('&',';')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvuE=PKMLJFkyoNbcDAYwtCzUdISfpsHvuE.replace('Policy','CloudFront-Policy')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvuE=PKMLJFkyoNbcDAYwtCzUdISfpsHvuE.replace('Signature','CloudFront-Signature')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvuE=PKMLJFkyoNbcDAYwtCzUdISfpsHvuE.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvuQ='%s|Cookie=%s'%(PKMLJFkyoNbcDAYwtCzUdISfpsHvuV,PKMLJFkyoNbcDAYwtCzUdISfpsHvuE)
  else:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvuQ=PKMLJFkyoNbcDAYwtCzUdISfpsHvum
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.addon_log(PKMLJFkyoNbcDAYwtCzUdISfpsHvuQ)
  PKMLJFkyoNbcDAYwtCzUdISfpsHvuO=xbmcgui.ListItem(path=PKMLJFkyoNbcDAYwtCzUdISfpsHvuQ)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvul!='':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvun=PKMLJFkyoNbcDAYwtCzUdISfpsHvul
   PKMLJFkyoNbcDAYwtCzUdISfpsHvuh ='https://cj.drmkeyserver.com/widevine_license'
   PKMLJFkyoNbcDAYwtCzUdISfpsHvua ='mpd'
   PKMLJFkyoNbcDAYwtCzUdISfpsHvui ='com.widevine.alpha'
   PKMLJFkyoNbcDAYwtCzUdISfpsHvue =inputstreamhelper.Helper(PKMLJFkyoNbcDAYwtCzUdISfpsHvua,drm='widevine')
   if PKMLJFkyoNbcDAYwtCzUdISfpsHvue.check_inputstream():
    PKMLJFkyoNbcDAYwtCzUdISfpsHvuq={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%PKMLJFkyoNbcDAYwtCzUdISfpsHvug,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.USER_AGENT,'AcquireLicenseAssertion':PKMLJFkyoNbcDAYwtCzUdISfpsHvun,'Host':'cj.drmkeyserver.com'}
    PKMLJFkyoNbcDAYwtCzUdISfpsHvuW=PKMLJFkyoNbcDAYwtCzUdISfpsHvuh+'|'+urllib.parse.urlencode(PKMLJFkyoNbcDAYwtCzUdISfpsHvuq)+'|R{SSM}|'
    PKMLJFkyoNbcDAYwtCzUdISfpsHvuO.setProperty('inputstream',PKMLJFkyoNbcDAYwtCzUdISfpsHvue.inputstream_addon)
    PKMLJFkyoNbcDAYwtCzUdISfpsHvuO.setProperty('inputstream.adaptive.manifest_type',PKMLJFkyoNbcDAYwtCzUdISfpsHvua)
    PKMLJFkyoNbcDAYwtCzUdISfpsHvuO.setProperty('inputstream.adaptive.license_type',PKMLJFkyoNbcDAYwtCzUdISfpsHvui)
    PKMLJFkyoNbcDAYwtCzUdISfpsHvuO.setProperty('inputstream.adaptive.license_key',PKMLJFkyoNbcDAYwtCzUdISfpsHvuW)
    PKMLJFkyoNbcDAYwtCzUdISfpsHvuO.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.USER_AGENT))
  xbmcplugin.setResolvedUrl(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ._addon_handle,PKMLJFkyoNbcDAYwtCzUdISfpsHvmV,PKMLJFkyoNbcDAYwtCzUdISfpsHvuO)
  try:
   if PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('mode')in['VOD','MOVIE']and PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('title'):
    PKMLJFkyoNbcDAYwtCzUdISfpsHvgh={'code':PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('programcode')if PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('mode')=='VOD' else PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('mediacode'),'img':PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('thumbnail'),'title':PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('title'),'videoid':PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('mediacode')}
    PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.Save_Watched_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvjm.get('stype'),PKMLJFkyoNbcDAYwtCzUdISfpsHvgh)
  except:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvmu
 def logout(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRi=xbmcgui.Dialog()
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgB=PKMLJFkyoNbcDAYwtCzUdISfpsHvRi.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvgB==PKMLJFkyoNbcDAYwtCzUdISfpsHvmT:sys.exit()
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.wininfo_clear()
  if os.path.isfile(PKMLJFkyoNbcDAYwtCzUdISfpsHvRE):os.remove(PKMLJFkyoNbcDAYwtCzUdISfpsHvRE)
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu=xbmcgui.Window(10000)
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_TOKEN','')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_USERINFO','')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_UUID','')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_LOGINTIME','')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_MAINTOKEN','')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_COOKIEKEY','')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvux =PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.Get_Now_Datetime()
  PKMLJFkyoNbcDAYwtCzUdISfpsHvuB=PKMLJFkyoNbcDAYwtCzUdISfpsHvux+datetime.timedelta(days=PKMLJFkyoNbcDAYwtCzUdISfpsHvml(__addon__.getSetting('cache_ttl')))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu=xbmcgui.Window(10000)
  PKMLJFkyoNbcDAYwtCzUdISfpsHvuX={'tving_token':PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.getProperty('TVING_M_TOKEN'),'tving_userinfo':PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.getProperty('TVING_M_USERINFO'),'tving_uuid':PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':PKMLJFkyoNbcDAYwtCzUdISfpsHvuB.strftime('%Y-%m-%d'),'tving_maintoken':PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=PKMLJFkyoNbcDAYwtCzUdISfpsHvmO(PKMLJFkyoNbcDAYwtCzUdISfpsHvRE,'w',-1,'utf-8')
   json.dump(PKMLJFkyoNbcDAYwtCzUdISfpsHvuX,fp)
   fp.close()
  except PKMLJFkyoNbcDAYwtCzUdISfpsHvmh as exception:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvma(exception)
 def cookiefile_check(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvuX={}
  try: 
   fp=PKMLJFkyoNbcDAYwtCzUdISfpsHvmO(PKMLJFkyoNbcDAYwtCzUdISfpsHvRE,'r',-1,'utf-8')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvuX= json.load(fp)
   fp.close()
  except PKMLJFkyoNbcDAYwtCzUdISfpsHvmh as exception:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.wininfo_clear()
   return PKMLJFkyoNbcDAYwtCzUdISfpsHvmT
  PKMLJFkyoNbcDAYwtCzUdISfpsHvge =__addon__.getSetting('id')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgq =__addon__.getSetting('pw')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvur=__addon__.getSetting('login_type')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvmR =__addon__.getSetting('selected_profile')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_id']=base64.standard_b64decode(PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_id']).decode('utf-8')
  PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_pw']=base64.standard_b64decode(PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_pw']).decode('utf-8')
  try:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_profile']
  except:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_profile']='0'
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvge!=PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_id']or PKMLJFkyoNbcDAYwtCzUdISfpsHvgq!=PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_pw']or PKMLJFkyoNbcDAYwtCzUdISfpsHvur!=PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_logintype']or PKMLJFkyoNbcDAYwtCzUdISfpsHvmR!=PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_profile']:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.wininfo_clear()
   return PKMLJFkyoNbcDAYwtCzUdISfpsHvmT
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgX =PKMLJFkyoNbcDAYwtCzUdISfpsHvml(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  PKMLJFkyoNbcDAYwtCzUdISfpsHvmg=PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_limitdate']
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgr =PKMLJFkyoNbcDAYwtCzUdISfpsHvml(re.sub('-','',PKMLJFkyoNbcDAYwtCzUdISfpsHvmg))
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvgr<PKMLJFkyoNbcDAYwtCzUdISfpsHvgX:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.wininfo_clear()
   return PKMLJFkyoNbcDAYwtCzUdISfpsHvmT
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu=xbmcgui.Window(10000)
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_TOKEN',PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_token'])
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_USERINFO',PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_userinfo'])
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_UUID',PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_uuid'])
  PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_LOGINTIME',PKMLJFkyoNbcDAYwtCzUdISfpsHvmg)
  try:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_MAINTOKEN',PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_maintoken'])
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_COOKIEKEY',PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_cookiekey'])
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_LOCKKEY',PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_lockkey'])
  except:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_MAINTOKEN',PKMLJFkyoNbcDAYwtCzUdISfpsHvuX['tving_token'])
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_COOKIEKEY','Y')
   PKMLJFkyoNbcDAYwtCzUdISfpsHvgu.setProperty('TVING_M_LOCKKEY','N')
  return PKMLJFkyoNbcDAYwtCzUdISfpsHvmV
 def tving_main(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ):
  PKMLJFkyoNbcDAYwtCzUdISfpsHvmj=PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.main_params.get('mode',PKMLJFkyoNbcDAYwtCzUdISfpsHvmu)
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvmj=='LOGOUT':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.logout()
   return
  PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.login_main()
  if PKMLJFkyoNbcDAYwtCzUdISfpsHvmj is PKMLJFkyoNbcDAYwtCzUdISfpsHvmu:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.dp_Main_List()
  elif PKMLJFkyoNbcDAYwtCzUdISfpsHvmj in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.dp_Title_Group(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.main_params)
  elif PKMLJFkyoNbcDAYwtCzUdISfpsHvmj=='CHANNEL':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.dp_LiveChannel_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.main_params)
  elif PKMLJFkyoNbcDAYwtCzUdISfpsHvmj in['LIVE','VOD','MOVIE']:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.play_VIDEO(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.main_params)
  elif PKMLJFkyoNbcDAYwtCzUdISfpsHvmj=='PROGRAM':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.dp_Program_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.main_params)
  elif PKMLJFkyoNbcDAYwtCzUdISfpsHvmj=='EPISODE':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.dp_Episode_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.main_params)
  elif PKMLJFkyoNbcDAYwtCzUdISfpsHvmj=='MOVIE_SUB':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.dp_Movie_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.main_params)
  elif PKMLJFkyoNbcDAYwtCzUdISfpsHvmj=='SEARCH_GROUP':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.dp_Search_Group(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.main_params)
  elif PKMLJFkyoNbcDAYwtCzUdISfpsHvmj=='SEARCH':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.dp_Search_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.main_params)
  elif PKMLJFkyoNbcDAYwtCzUdISfpsHvmj=='WATCH':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.dp_Watch_List(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.main_params)
  elif PKMLJFkyoNbcDAYwtCzUdISfpsHvmj=='MYVIEW_REMOVE':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.dp_WatchList_Delete(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.main_params)
  elif PKMLJFkyoNbcDAYwtCzUdISfpsHvmj=='ORDER_BY':
   PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.dp_setEpOrderby(PKMLJFkyoNbcDAYwtCzUdISfpsHvRQ.main_params)
  else:
   PKMLJFkyoNbcDAYwtCzUdISfpsHvmu
# Created by pyminifier (https://github.com/liftoff/pyminifier)
