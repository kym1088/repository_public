__author__="NightRain"
CLWSiEQInmHhlbBJeOqRxcdstwDfYG=object
CLWSiEQInmHhlbBJeOqRxcdstwDfYK=None
CLWSiEQInmHhlbBJeOqRxcdstwDfTM=False
CLWSiEQInmHhlbBJeOqRxcdstwDfTj=int
CLWSiEQInmHhlbBJeOqRxcdstwDfTo=range
CLWSiEQInmHhlbBJeOqRxcdstwDfTV=True
CLWSiEQInmHhlbBJeOqRxcdstwDfTY=Exception
CLWSiEQInmHhlbBJeOqRxcdstwDfTv=print
CLWSiEQInmHhlbBJeOqRxcdstwDfTA=str
CLWSiEQInmHhlbBJeOqRxcdstwDfTy=list
CLWSiEQInmHhlbBJeOqRxcdstwDfTp=len
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
CLWSiEQInmHhlbBJeOqRxcdstwDfMo={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
CLWSiEQInmHhlbBJeOqRxcdstwDfMV ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class CLWSiEQInmHhlbBJeOqRxcdstwDfMj(CLWSiEQInmHhlbBJeOqRxcdstwDfYG):
 def __init__(CLWSiEQInmHhlbBJeOqRxcdstwDfMY):
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_TOKEN =''
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.POC_USERINFO =''
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_UUID ='-'
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_MAINTOKEN=''
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVIGN_COOKIEKEY=''
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_LOCKKEY =''
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.NETWORKCODE ='CSND0900'
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.OSCODE ='CSOD0900' 
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TELECODE ='CSCD0900'
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.SCREENCODE ='CSSD0100'
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.LIVE_LIMIT =23
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.VOD_LIMIT =20
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.EPISODE_LIMIT =30 
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.SEARCH_LIMIT =30 
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.MOVIE_LIMIT =18
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.API_DOMAIN ='https://api.tving.com'
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN ='https://image.tving.com'
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.SEARCH_DOMAIN ='https://search.tving.com'
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.LOGIN_DOMAIN ='https://user.tving.com'
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.URL_DOMAIN ='https://www.tving.com'
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.MOVIE_LITE =['2610061','2610161','261062']
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.DEFAULT_HEADER ={'user-agent':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.USER_AGENT}
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,jobtype,CLWSiEQInmHhlbBJeOqRxcdstwDfjr,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,params=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,redirects=CLWSiEQInmHhlbBJeOqRxcdstwDfTM):
  CLWSiEQInmHhlbBJeOqRxcdstwDfMT=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.DEFAULT_HEADER
  if headers:CLWSiEQInmHhlbBJeOqRxcdstwDfMT.update(headers)
  if jobtype=='Get':
   CLWSiEQInmHhlbBJeOqRxcdstwDfMv=requests.get(CLWSiEQInmHhlbBJeOqRxcdstwDfjr,params=params,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfMT,cookies=cookies,allow_redirects=redirects)
  else:
   CLWSiEQInmHhlbBJeOqRxcdstwDfMv=requests.post(CLWSiEQInmHhlbBJeOqRxcdstwDfjr,data=payload,params=params,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfMT,cookies=cookies,allow_redirects=redirects)
  return CLWSiEQInmHhlbBJeOqRxcdstwDfMv
 def makeDefaultCookies(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,vToken=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,vUserinfo=CLWSiEQInmHhlbBJeOqRxcdstwDfYK):
  CLWSiEQInmHhlbBJeOqRxcdstwDfMA={}
  CLWSiEQInmHhlbBJeOqRxcdstwDfMA['_tving_token']=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_TOKEN if vToken==CLWSiEQInmHhlbBJeOqRxcdstwDfYK else vToken
  CLWSiEQInmHhlbBJeOqRxcdstwDfMA['POC_USERINFO']=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.POC_USERINFO if vToken==CLWSiEQInmHhlbBJeOqRxcdstwDfYK else vUserinfo
  if CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_MAINTOKEN!='':CLWSiEQInmHhlbBJeOqRxcdstwDfMA[CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GLOBAL_COOKIENM['tv_maintoken']]=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_MAINTOKEN
  if CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVIGN_COOKIEKEY!='':CLWSiEQInmHhlbBJeOqRxcdstwDfMA[CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GLOBAL_COOKIENM['tv_cookiekey']]=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVIGN_COOKIEKEY
  if CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_LOCKKEY !='':CLWSiEQInmHhlbBJeOqRxcdstwDfMA[CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GLOBAL_COOKIENM['tv_lockkey']] =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_LOCKKEY
  return CLWSiEQInmHhlbBJeOqRxcdstwDfMA
 def getDeviceStr(CLWSiEQInmHhlbBJeOqRxcdstwDfMY):
  CLWSiEQInmHhlbBJeOqRxcdstwDfMy=[]
  CLWSiEQInmHhlbBJeOqRxcdstwDfMy.append('Windows') 
  CLWSiEQInmHhlbBJeOqRxcdstwDfMy.append('Chrome') 
  CLWSiEQInmHhlbBJeOqRxcdstwDfMy.append('ko-KR') 
  CLWSiEQInmHhlbBJeOqRxcdstwDfMy.append('undefined') 
  CLWSiEQInmHhlbBJeOqRxcdstwDfMy.append('24') 
  CLWSiEQInmHhlbBJeOqRxcdstwDfMy.append(u'한국 표준시')
  CLWSiEQInmHhlbBJeOqRxcdstwDfMy.append('undefined') 
  CLWSiEQInmHhlbBJeOqRxcdstwDfMy.append('undefined') 
  CLWSiEQInmHhlbBJeOqRxcdstwDfMy.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  CLWSiEQInmHhlbBJeOqRxcdstwDfMp=''
  for CLWSiEQInmHhlbBJeOqRxcdstwDfMa in CLWSiEQInmHhlbBJeOqRxcdstwDfMy:
   CLWSiEQInmHhlbBJeOqRxcdstwDfMp+=CLWSiEQInmHhlbBJeOqRxcdstwDfMa+'|'
  return CLWSiEQInmHhlbBJeOqRxcdstwDfMp
 def SaveCredential(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,CLWSiEQInmHhlbBJeOqRxcdstwDfMP):
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_TOKEN =CLWSiEQInmHhlbBJeOqRxcdstwDfMP.get('tving_token')
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.POC_USERINFO =CLWSiEQInmHhlbBJeOqRxcdstwDfMP.get('poc_userinfo')
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_UUID =CLWSiEQInmHhlbBJeOqRxcdstwDfMP.get('tving_uuid')
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_MAINTOKEN=CLWSiEQInmHhlbBJeOqRxcdstwDfMP.get('tving_maintoken')
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVIGN_COOKIEKEY=CLWSiEQInmHhlbBJeOqRxcdstwDfMP.get('tving_cookiekey')
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_LOCKKEY =CLWSiEQInmHhlbBJeOqRxcdstwDfMP.get('tving_lockkey')
 def LoadCredential(CLWSiEQInmHhlbBJeOqRxcdstwDfMY):
  CLWSiEQInmHhlbBJeOqRxcdstwDfMP={'tving_token':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_TOKEN,'poc_userinfo':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.POC_USERINFO,'tving_uuid':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_UUID,'tving_maintoken':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_MAINTOKEN,'tving_cookiekey':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVIGN_COOKIEKEY,'tving_lockkey':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_LOCKKEY}
  return CLWSiEQInmHhlbBJeOqRxcdstwDfMP
 def GetDefaultParams(CLWSiEQInmHhlbBJeOqRxcdstwDfMY):
  CLWSiEQInmHhlbBJeOqRxcdstwDfMz={'apiKey':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.APIKEY,'networkCode':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.NETWORKCODE,'osCode':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.OSCODE,'teleCode':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TELECODE,'screenCode':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.SCREENCODE}
  return CLWSiEQInmHhlbBJeOqRxcdstwDfMz
 def GetNoCache(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,timetype=1):
  if timetype==1:
   return CLWSiEQInmHhlbBJeOqRxcdstwDfTj(time.time())
  else:
   return CLWSiEQInmHhlbBJeOqRxcdstwDfTj(time.time()*1000)
 def GetUniqueid(CLWSiEQInmHhlbBJeOqRxcdstwDfMY):
  CLWSiEQInmHhlbBJeOqRxcdstwDfMr=[0 for i in CLWSiEQInmHhlbBJeOqRxcdstwDfTo(256)]
  for i in CLWSiEQInmHhlbBJeOqRxcdstwDfTo(256):
   CLWSiEQInmHhlbBJeOqRxcdstwDfMr[i]='%02x'%(i)
  CLWSiEQInmHhlbBJeOqRxcdstwDfMF=CLWSiEQInmHhlbBJeOqRxcdstwDfTj(4294967295*random.random())|0
  CLWSiEQInmHhlbBJeOqRxcdstwDfMU=CLWSiEQInmHhlbBJeOqRxcdstwDfMr[255&CLWSiEQInmHhlbBJeOqRxcdstwDfMF]+CLWSiEQInmHhlbBJeOqRxcdstwDfMr[CLWSiEQInmHhlbBJeOqRxcdstwDfMF>>8&255]+CLWSiEQInmHhlbBJeOqRxcdstwDfMr[CLWSiEQInmHhlbBJeOqRxcdstwDfMF>>16&255]+CLWSiEQInmHhlbBJeOqRxcdstwDfMr[CLWSiEQInmHhlbBJeOqRxcdstwDfMF>>24&255]
  return CLWSiEQInmHhlbBJeOqRxcdstwDfMU
 def GetCredential(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,user_id,user_pw,login_type,user_pf):
  CLWSiEQInmHhlbBJeOqRxcdstwDfMk=CLWSiEQInmHhlbBJeOqRxcdstwDfTM
  CLWSiEQInmHhlbBJeOqRxcdstwDfMg=CLWSiEQInmHhlbBJeOqRxcdstwDfjM=CLWSiEQInmHhlbBJeOqRxcdstwDfjo=CLWSiEQInmHhlbBJeOqRxcdstwDfjV=CLWSiEQInmHhlbBJeOqRxcdstwDfjY='' 
  CLWSiEQInmHhlbBJeOqRxcdstwDfMu ='-'
  try:
   CLWSiEQInmHhlbBJeOqRxcdstwDfMN=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   CLWSiEQInmHhlbBJeOqRxcdstwDfMX={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   CLWSiEQInmHhlbBJeOqRxcdstwDfMG=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.callRequestCookies('Post',CLWSiEQInmHhlbBJeOqRxcdstwDfMN,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfMX,params=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfYK)
   for CLWSiEQInmHhlbBJeOqRxcdstwDfMK in CLWSiEQInmHhlbBJeOqRxcdstwDfMG.cookies:
    if CLWSiEQInmHhlbBJeOqRxcdstwDfMK.name=='_tving_token':
     CLWSiEQInmHhlbBJeOqRxcdstwDfjM=CLWSiEQInmHhlbBJeOqRxcdstwDfMK.value
    elif CLWSiEQInmHhlbBJeOqRxcdstwDfMK.name=='POC_USERINFO':
     CLWSiEQInmHhlbBJeOqRxcdstwDfjo=CLWSiEQInmHhlbBJeOqRxcdstwDfMK.value
   if CLWSiEQInmHhlbBJeOqRxcdstwDfjM=='':return CLWSiEQInmHhlbBJeOqRxcdstwDfMk
   CLWSiEQInmHhlbBJeOqRxcdstwDfMg=CLWSiEQInmHhlbBJeOqRxcdstwDfjM
   CLWSiEQInmHhlbBJeOqRxcdstwDfjM,CLWSiEQInmHhlbBJeOqRxcdstwDfjV,CLWSiEQInmHhlbBJeOqRxcdstwDfjY=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetProfileToken(CLWSiEQInmHhlbBJeOqRxcdstwDfjM,CLWSiEQInmHhlbBJeOqRxcdstwDfjo,user_pf)
   CLWSiEQInmHhlbBJeOqRxcdstwDfMk=CLWSiEQInmHhlbBJeOqRxcdstwDfTV
   CLWSiEQInmHhlbBJeOqRxcdstwDfMu =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetDeviceList(CLWSiEQInmHhlbBJeOqRxcdstwDfjM,CLWSiEQInmHhlbBJeOqRxcdstwDfjo)
   CLWSiEQInmHhlbBJeOqRxcdstwDfMu =CLWSiEQInmHhlbBJeOqRxcdstwDfMu+'-'+CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetUniqueid()
  except CLWSiEQInmHhlbBJeOqRxcdstwDfTY as exception:
   CLWSiEQInmHhlbBJeOqRxcdstwDfMg=CLWSiEQInmHhlbBJeOqRxcdstwDfjM=CLWSiEQInmHhlbBJeOqRxcdstwDfjo=CLWSiEQInmHhlbBJeOqRxcdstwDfjV=CLWSiEQInmHhlbBJeOqRxcdstwDfjY=''
   CLWSiEQInmHhlbBJeOqRxcdstwDfMu='-'
   CLWSiEQInmHhlbBJeOqRxcdstwDfTv(exception)
  CLWSiEQInmHhlbBJeOqRxcdstwDfMP={'tving_token':CLWSiEQInmHhlbBJeOqRxcdstwDfjM,'poc_userinfo':CLWSiEQInmHhlbBJeOqRxcdstwDfjo,'tving_uuid':CLWSiEQInmHhlbBJeOqRxcdstwDfMu,'tving_maintoken':CLWSiEQInmHhlbBJeOqRxcdstwDfMg,'tving_cookiekey':CLWSiEQInmHhlbBJeOqRxcdstwDfjV,'tving_lockkey':CLWSiEQInmHhlbBJeOqRxcdstwDfjY}
  CLWSiEQInmHhlbBJeOqRxcdstwDfMY.SaveCredential(CLWSiEQInmHhlbBJeOqRxcdstwDfMP)
  return CLWSiEQInmHhlbBJeOqRxcdstwDfMk
 def Get_Now_Datetime(CLWSiEQInmHhlbBJeOqRxcdstwDfMY):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,mediacode,sel_quality,stype,pvrmode='-'):
  CLWSiEQInmHhlbBJeOqRxcdstwDfjv=''
  CLWSiEQInmHhlbBJeOqRxcdstwDfjA=''
  CLWSiEQInmHhlbBJeOqRxcdstwDfjy =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_UUID.split('-')[0] 
  CLWSiEQInmHhlbBJeOqRxcdstwDfjp =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.TVING_UUID 
  if mediacode=='C01345':
   CLWSiEQInmHhlbBJeOqRxcdstwDfjv='http://ocn-mcdn.tving.com/ocn/live5000.smil/playlist.m3u8?Policy=eyJTdGF0ZW1lbnQiOiBbeyJSZXNvdXJjZSI6Imh0dHA6Ly8qIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNjEwODMwODAwfSwiSXBBZGRyZXNzIjp7IkFXUzpTb3VyY2VJcCI6IjAuMC4wLjAvMCJ9fX1dfQ__&Signature=eqJMOA5c~hIlgUVIDOtLCCfKXnNO0XHex3uQVQE87ZfuutuH2hqAgddlijKNWDz2Qrg5ScRkuXuU-7QQoj4QFSPPjyvwJSSrrZtNNVxU8xERXywdUKUwQGfDvl78F4rhS7WP-O1Q86KnLwif9QW0GPRK~n8ceOITlYq22rVLqp~EKwmoGQ3cvw01TMBFRInvobRtXR-zGyMZCx9MDgeHMRay0U9Ibp7nUPb3~T~set~W3so1ovUnF0iLuQpuarXQA3QIBy25O24NVbwalTtzjPoULkpEHeuVsMx-ACom3MTM65kB5TKJNIx19sdlAFQIII7n39FpWgSOO6A8jvu~rA__&Key-Pair-Id=APKAIXCIJCFRGOUEZDWA'
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    CLWSiEQInmHhlbBJeOqRxcdstwDfja ='/v2a/media/stream/info' 
    CLWSiEQInmHhlbBJeOqRxcdstwDfjP=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetDefaultParams()
    CLWSiEQInmHhlbBJeOqRxcdstwDfjz={'info':'N','mediaCode':mediacode,'noCache':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':CLWSiEQInmHhlbBJeOqRxcdstwDfjy,'uuid':CLWSiEQInmHhlbBJeOqRxcdstwDfjp,'deviceInfo':'PC','wm':'Y'}
    CLWSiEQInmHhlbBJeOqRxcdstwDfjP.update(CLWSiEQInmHhlbBJeOqRxcdstwDfjz)
    CLWSiEQInmHhlbBJeOqRxcdstwDfjr=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.API_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfja
    CLWSiEQInmHhlbBJeOqRxcdstwDfMA=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.makeDefaultCookies()
    CLWSiEQInmHhlbBJeOqRxcdstwDfMG=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.callRequestCookies('Get',CLWSiEQInmHhlbBJeOqRxcdstwDfjr,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,params=CLWSiEQInmHhlbBJeOqRxcdstwDfjP,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfMA)
    CLWSiEQInmHhlbBJeOqRxcdstwDfjF=json.loads(CLWSiEQInmHhlbBJeOqRxcdstwDfMG.text)
    if not('stream' in CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']):return CLWSiEQInmHhlbBJeOqRxcdstwDfjv,CLWSiEQInmHhlbBJeOqRxcdstwDfjA 
    CLWSiEQInmHhlbBJeOqRxcdstwDfjU=CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']['stream']
    CLWSiEQInmHhlbBJeOqRxcdstwDfjk=CLWSiEQInmHhlbBJeOqRxcdstwDfjU['quality']
    CLWSiEQInmHhlbBJeOqRxcdstwDfjg=[]
    for CLWSiEQInmHhlbBJeOqRxcdstwDfju in CLWSiEQInmHhlbBJeOqRxcdstwDfjk:
     if CLWSiEQInmHhlbBJeOqRxcdstwDfju['active']=='Y':
      CLWSiEQInmHhlbBJeOqRxcdstwDfjg.append({CLWSiEQInmHhlbBJeOqRxcdstwDfMo.get(CLWSiEQInmHhlbBJeOqRxcdstwDfju['code']):CLWSiEQInmHhlbBJeOqRxcdstwDfju['code']})
    CLWSiEQInmHhlbBJeOqRxcdstwDfjN=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.CheckQuality(sel_quality,CLWSiEQInmHhlbBJeOqRxcdstwDfjg)
   else:
    for CLWSiEQInmHhlbBJeOqRxcdstwDfjX,CLWSiEQInmHhlbBJeOqRxcdstwDfov in CLWSiEQInmHhlbBJeOqRxcdstwDfMo.items():
     if CLWSiEQInmHhlbBJeOqRxcdstwDfov==sel_quality:
      CLWSiEQInmHhlbBJeOqRxcdstwDfjN=CLWSiEQInmHhlbBJeOqRxcdstwDfjX
  except CLWSiEQInmHhlbBJeOqRxcdstwDfTY as exception:
   CLWSiEQInmHhlbBJeOqRxcdstwDfTv(exception)
   for CLWSiEQInmHhlbBJeOqRxcdstwDfjX,CLWSiEQInmHhlbBJeOqRxcdstwDfov in CLWSiEQInmHhlbBJeOqRxcdstwDfMo.items():
    if CLWSiEQInmHhlbBJeOqRxcdstwDfov==sel_quality:
     CLWSiEQInmHhlbBJeOqRxcdstwDfjN=CLWSiEQInmHhlbBJeOqRxcdstwDfjX
   return CLWSiEQInmHhlbBJeOqRxcdstwDfjv,CLWSiEQInmHhlbBJeOqRxcdstwDfjA
  CLWSiEQInmHhlbBJeOqRxcdstwDfTv(CLWSiEQInmHhlbBJeOqRxcdstwDfjN)
  try:
   CLWSiEQInmHhlbBJeOqRxcdstwDfja ='/streaming/info'
   CLWSiEQInmHhlbBJeOqRxcdstwDfjP=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetDefaultParams()
   if stype=='onair':CLWSiEQInmHhlbBJeOqRxcdstwDfjP['osCode']='CSOD0400' 
   CLWSiEQInmHhlbBJeOqRxcdstwDfjG={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   CLWSiEQInmHhlbBJeOqRxcdstwDfjK=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.makeOocUrl(CLWSiEQInmHhlbBJeOqRxcdstwDfjG)
   CLWSiEQInmHhlbBJeOqRxcdstwDfoM=urllib.parse.quote(CLWSiEQInmHhlbBJeOqRxcdstwDfjK)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjz={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':CLWSiEQInmHhlbBJeOqRxcdstwDfjN,'adReq':'adproxy','ooc':CLWSiEQInmHhlbBJeOqRxcdstwDfjK,'deviceId':CLWSiEQInmHhlbBJeOqRxcdstwDfjy,'uuid':CLWSiEQInmHhlbBJeOqRxcdstwDfjp,'deviceInfo':'PC'}
   CLWSiEQInmHhlbBJeOqRxcdstwDfoj =CLWSiEQInmHhlbBJeOqRxcdstwDfjP
   CLWSiEQInmHhlbBJeOqRxcdstwDfoj.update(CLWSiEQInmHhlbBJeOqRxcdstwDfjz)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjr=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.URL_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfja
   CLWSiEQInmHhlbBJeOqRxcdstwDfoV={'origin':'https://www.tving.com'}
   if stype=='onair':CLWSiEQInmHhlbBJeOqRxcdstwDfoV['Referer']='https://www.tving.com/live/player/'+mediacode
   else: CLWSiEQInmHhlbBJeOqRxcdstwDfoV['Referer']='https://www.tving.com/vod/player/'+mediacode
   CLWSiEQInmHhlbBJeOqRxcdstwDfMA=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.makeDefaultCookies()
   CLWSiEQInmHhlbBJeOqRxcdstwDfMA['onClickEvent2']=CLWSiEQInmHhlbBJeOqRxcdstwDfoM
   CLWSiEQInmHhlbBJeOqRxcdstwDfMG=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.callRequestCookies('Post',CLWSiEQInmHhlbBJeOqRxcdstwDfjr,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfoj,params=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfoV,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfMA,redirects=CLWSiEQInmHhlbBJeOqRxcdstwDfTM)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjF=json.loads(CLWSiEQInmHhlbBJeOqRxcdstwDfMG.text)
   if 'drm_license_assertion' in CLWSiEQInmHhlbBJeOqRxcdstwDfjF['stream']:
    CLWSiEQInmHhlbBJeOqRxcdstwDfjA =CLWSiEQInmHhlbBJeOqRxcdstwDfjF['stream']['drm_license_assertion']
    CLWSiEQInmHhlbBJeOqRxcdstwDfjv=CLWSiEQInmHhlbBJeOqRxcdstwDfjF['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in CLWSiEQInmHhlbBJeOqRxcdstwDfjF['stream']['broadcast']):return CLWSiEQInmHhlbBJeOqRxcdstwDfjv,CLWSiEQInmHhlbBJeOqRxcdstwDfjA
    CLWSiEQInmHhlbBJeOqRxcdstwDfjv=CLWSiEQInmHhlbBJeOqRxcdstwDfjF['stream']['broadcast']['broad_url']
  except CLWSiEQInmHhlbBJeOqRxcdstwDfTY as exception:
   CLWSiEQInmHhlbBJeOqRxcdstwDfTv(exception)
  return CLWSiEQInmHhlbBJeOqRxcdstwDfjv,CLWSiEQInmHhlbBJeOqRxcdstwDfjA
 def CheckQuality(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,sel_qt,CLWSiEQInmHhlbBJeOqRxcdstwDfjg):
  for CLWSiEQInmHhlbBJeOqRxcdstwDfoY in CLWSiEQInmHhlbBJeOqRxcdstwDfjg:
   if sel_qt>=CLWSiEQInmHhlbBJeOqRxcdstwDfTy(CLWSiEQInmHhlbBJeOqRxcdstwDfoY)[0]:return CLWSiEQInmHhlbBJeOqRxcdstwDfoY.get(CLWSiEQInmHhlbBJeOqRxcdstwDfTy(CLWSiEQInmHhlbBJeOqRxcdstwDfoY)[0])
   CLWSiEQInmHhlbBJeOqRxcdstwDfoT=CLWSiEQInmHhlbBJeOqRxcdstwDfoY.get(CLWSiEQInmHhlbBJeOqRxcdstwDfTy(CLWSiEQInmHhlbBJeOqRxcdstwDfoY)[0])
  return CLWSiEQInmHhlbBJeOqRxcdstwDfoT
 def makeOocUrl(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,CLWSiEQInmHhlbBJeOqRxcdstwDfjG):
  CLWSiEQInmHhlbBJeOqRxcdstwDfjr=''
  for CLWSiEQInmHhlbBJeOqRxcdstwDfjX,CLWSiEQInmHhlbBJeOqRxcdstwDfov in CLWSiEQInmHhlbBJeOqRxcdstwDfjG.items():
   CLWSiEQInmHhlbBJeOqRxcdstwDfjr+="%s=%s^"%(CLWSiEQInmHhlbBJeOqRxcdstwDfjX,CLWSiEQInmHhlbBJeOqRxcdstwDfov)
  return CLWSiEQInmHhlbBJeOqRxcdstwDfjr
 def GetLiveChannelList(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,stype,page_int):
  CLWSiEQInmHhlbBJeOqRxcdstwDfoA=[]
  CLWSiEQInmHhlbBJeOqRxcdstwDfoy=CLWSiEQInmHhlbBJeOqRxcdstwDfTM
  CLWSiEQInmHhlbBJeOqRxcdstwDfop=CLWSiEQInmHhlbBJeOqRxcdstwDfTM
  try:
   CLWSiEQInmHhlbBJeOqRxcdstwDfja ='/v2/media/lives'
   if stype=='onair': 
    CLWSiEQInmHhlbBJeOqRxcdstwDfoa='CPCS0100,CPCS0400'
   else:
    CLWSiEQInmHhlbBJeOqRxcdstwDfoa='CPCS0300'
   CLWSiEQInmHhlbBJeOqRxcdstwDfjP=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetDefaultParams()
   CLWSiEQInmHhlbBJeOqRxcdstwDfjz={'pageNo':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(page_int),'pageSize':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':CLWSiEQInmHhlbBJeOqRxcdstwDfoa,'_':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetNoCache(2))}
   CLWSiEQInmHhlbBJeOqRxcdstwDfjP.update(CLWSiEQInmHhlbBJeOqRxcdstwDfjz)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjr=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.API_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfja
   CLWSiEQInmHhlbBJeOqRxcdstwDfMG=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.callRequestCookies('Get',CLWSiEQInmHhlbBJeOqRxcdstwDfjr,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,params=CLWSiEQInmHhlbBJeOqRxcdstwDfjP,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfYK)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjF=json.loads(CLWSiEQInmHhlbBJeOqRxcdstwDfMG.text)
   if not('result' in CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']):return CLWSiEQInmHhlbBJeOqRxcdstwDfoA,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
   CLWSiEQInmHhlbBJeOqRxcdstwDfoP=CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']['result']
   for CLWSiEQInmHhlbBJeOqRxcdstwDfju in CLWSiEQInmHhlbBJeOqRxcdstwDfoP:
    CLWSiEQInmHhlbBJeOqRxcdstwDfoz=CLWSiEQInmHhlbBJeOqRxcdstwDfoU=CLWSiEQInmHhlbBJeOqRxcdstwDfok=''
    CLWSiEQInmHhlbBJeOqRxcdstwDfor=CLWSiEQInmHhlbBJeOqRxcdstwDfVP=''
    CLWSiEQInmHhlbBJeOqRxcdstwDfoF=CLWSiEQInmHhlbBJeOqRxcdstwDfju['live_code']
    if CLWSiEQInmHhlbBJeOqRxcdstwDfoF=='C01345':CLWSiEQInmHhlbBJeOqRxcdstwDfop=CLWSiEQInmHhlbBJeOqRxcdstwDfTV 
    CLWSiEQInmHhlbBJeOqRxcdstwDfoz =CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['channel']['name']['ko']
    if CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['episode']!=CLWSiEQInmHhlbBJeOqRxcdstwDfYK:
     CLWSiEQInmHhlbBJeOqRxcdstwDfoU =CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['program']['name']['ko']
     CLWSiEQInmHhlbBJeOqRxcdstwDfoU =CLWSiEQInmHhlbBJeOqRxcdstwDfoU+', '+CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['episode']['frequency'])+'회'
     CLWSiEQInmHhlbBJeOqRxcdstwDfok=CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['episode']['synopsis']['ko']
    else:
     CLWSiEQInmHhlbBJeOqRxcdstwDfoU =CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['program']['name']['ko']
     CLWSiEQInmHhlbBJeOqRxcdstwDfok=CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['program']['synopsis']['ko']
    try: 
     CLWSiEQInmHhlbBJeOqRxcdstwDfog =''
     CLWSiEQInmHhlbBJeOqRxcdstwDfou =''
     CLWSiEQInmHhlbBJeOqRxcdstwDfoN=''
     CLWSiEQInmHhlbBJeOqRxcdstwDfoX =''
     CLWSiEQInmHhlbBJeOqRxcdstwDfoG =''
     CLWSiEQInmHhlbBJeOqRxcdstwDfoK =''
     for CLWSiEQInmHhlbBJeOqRxcdstwDfVM in CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['program']['image']:
      if CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP0900':CLWSiEQInmHhlbBJeOqRxcdstwDfou =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
      elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP1800':CLWSiEQInmHhlbBJeOqRxcdstwDfoN=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
      elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP2000':CLWSiEQInmHhlbBJeOqRxcdstwDfoX =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
      elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP1900':CLWSiEQInmHhlbBJeOqRxcdstwDfoG =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
      elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP0200':CLWSiEQInmHhlbBJeOqRxcdstwDfoK =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
      elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP0500':CLWSiEQInmHhlbBJeOqRxcdstwDfog =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
      elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP0800':CLWSiEQInmHhlbBJeOqRxcdstwDfog =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
     if CLWSiEQInmHhlbBJeOqRxcdstwDfog=='':
      for CLWSiEQInmHhlbBJeOqRxcdstwDfVM in CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['channel']['image']:
       if CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIC0400':CLWSiEQInmHhlbBJeOqRxcdstwDfog =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
       elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIC1400':CLWSiEQInmHhlbBJeOqRxcdstwDfog =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
       elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIC1900':CLWSiEQInmHhlbBJeOqRxcdstwDfog =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
    except:
     CLWSiEQInmHhlbBJeOqRxcdstwDfYK
    try:
     CLWSiEQInmHhlbBJeOqRxcdstwDfVj =[]
     CLWSiEQInmHhlbBJeOqRxcdstwDfVo=[]
     CLWSiEQInmHhlbBJeOqRxcdstwDfVY =[]
     CLWSiEQInmHhlbBJeOqRxcdstwDfVT=''
     CLWSiEQInmHhlbBJeOqRxcdstwDfVv=''
     CLWSiEQInmHhlbBJeOqRxcdstwDfVA=''
     for CLWSiEQInmHhlbBJeOqRxcdstwDfVy in CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('schedule').get('program').get('actor'):
      if CLWSiEQInmHhlbBJeOqRxcdstwDfVy!='' and CLWSiEQInmHhlbBJeOqRxcdstwDfVy!=u'없음':CLWSiEQInmHhlbBJeOqRxcdstwDfVj.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVy)
     for CLWSiEQInmHhlbBJeOqRxcdstwDfVp in CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('schedule').get('program').get('director'):
      if CLWSiEQInmHhlbBJeOqRxcdstwDfVp!='' and CLWSiEQInmHhlbBJeOqRxcdstwDfVp!='-' and CLWSiEQInmHhlbBJeOqRxcdstwDfVp!=u'없음':CLWSiEQInmHhlbBJeOqRxcdstwDfVo.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVp)
     if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('schedule').get('program').get('category1_name').get('ko')!='':
      CLWSiEQInmHhlbBJeOqRxcdstwDfVY.append(CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['program']['category1_name']['ko'])
     if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('schedule').get('program').get('category2_name').get('ko')!='':
      CLWSiEQInmHhlbBJeOqRxcdstwDfVY.append(CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['program']['category2_name']['ko'])
     if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('schedule').get('program').get('product_year'):CLWSiEQInmHhlbBJeOqRxcdstwDfVT=CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['program']['product_year']
     if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('schedule').get('program').get('grade_code') :CLWSiEQInmHhlbBJeOqRxcdstwDfVv= CLWSiEQInmHhlbBJeOqRxcdstwDfMV.get(CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['program']['grade_code'])
     if 'broad_dt' in CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('schedule').get('program'):
      CLWSiEQInmHhlbBJeOqRxcdstwDfVa =CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('schedule').get('program').get('broad_dt')
      CLWSiEQInmHhlbBJeOqRxcdstwDfVA='%s-%s-%s'%(CLWSiEQInmHhlbBJeOqRxcdstwDfVa[:4],CLWSiEQInmHhlbBJeOqRxcdstwDfVa[4:6],CLWSiEQInmHhlbBJeOqRxcdstwDfVa[6:])
    except:
     CLWSiEQInmHhlbBJeOqRxcdstwDfYK
    CLWSiEQInmHhlbBJeOqRxcdstwDfor=CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['broadcast_start_time'])[8:12]
    CLWSiEQInmHhlbBJeOqRxcdstwDfVP =CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfju['schedule']['broadcast_end_time'])[8:12]
    CLWSiEQInmHhlbBJeOqRxcdstwDfVz={'channel':CLWSiEQInmHhlbBJeOqRxcdstwDfoz,'title':CLWSiEQInmHhlbBJeOqRxcdstwDfoU,'mediacode':CLWSiEQInmHhlbBJeOqRxcdstwDfoF,'thumbnail':{'poster':CLWSiEQInmHhlbBJeOqRxcdstwDfou,'thumb':CLWSiEQInmHhlbBJeOqRxcdstwDfog,'clearlogo':CLWSiEQInmHhlbBJeOqRxcdstwDfoN,'icon':CLWSiEQInmHhlbBJeOqRxcdstwDfoX,'fanart':CLWSiEQInmHhlbBJeOqRxcdstwDfoK},'synopsis':CLWSiEQInmHhlbBJeOqRxcdstwDfok,'channelepg':' [%s:%s ~ %s:%s]'%(CLWSiEQInmHhlbBJeOqRxcdstwDfor[0:2],CLWSiEQInmHhlbBJeOqRxcdstwDfor[2:],CLWSiEQInmHhlbBJeOqRxcdstwDfVP[0:2],CLWSiEQInmHhlbBJeOqRxcdstwDfVP[2:]),'cast':CLWSiEQInmHhlbBJeOqRxcdstwDfVj,'director':CLWSiEQInmHhlbBJeOqRxcdstwDfVo,'info_genre':CLWSiEQInmHhlbBJeOqRxcdstwDfVY,'year':CLWSiEQInmHhlbBJeOqRxcdstwDfVT,'mpaa':CLWSiEQInmHhlbBJeOqRxcdstwDfVv,'premiered':CLWSiEQInmHhlbBJeOqRxcdstwDfVA}
    CLWSiEQInmHhlbBJeOqRxcdstwDfoA.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVz)
   if CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']['has_more']=='Y':
    CLWSiEQInmHhlbBJeOqRxcdstwDfoy=CLWSiEQInmHhlbBJeOqRxcdstwDfTV
   else:
    CLWSiEQInmHhlbBJeOqRxcdstwDfVz={'channel':'OCN Original','title':'temp','mediacode':'C01345','thumbnail':'http://image.tving.com/upload/cms/caic/CAIC0400/C01345.png','cast':[],'director':[]}
  except CLWSiEQInmHhlbBJeOqRxcdstwDfTY as exception:
   CLWSiEQInmHhlbBJeOqRxcdstwDfTv(exception)
  return CLWSiEQInmHhlbBJeOqRxcdstwDfoA,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
 def GetProgramList(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,genre,orderby,page_int,genreCode='all'):
  CLWSiEQInmHhlbBJeOqRxcdstwDfoA=[]
  CLWSiEQInmHhlbBJeOqRxcdstwDfoy=CLWSiEQInmHhlbBJeOqRxcdstwDfTM
  try:
   CLWSiEQInmHhlbBJeOqRxcdstwDfja ='/v2/media/episodes'
   CLWSiEQInmHhlbBJeOqRxcdstwDfjP=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetDefaultParams()
   CLWSiEQInmHhlbBJeOqRxcdstwDfjz={'pageNo':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(page_int),'pageSize':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetNoCache(2))}
   if genre !='all':CLWSiEQInmHhlbBJeOqRxcdstwDfjz['categoryCode']=genre
   if genreCode!='all':CLWSiEQInmHhlbBJeOqRxcdstwDfjz['genreCode'] =genreCode 
   CLWSiEQInmHhlbBJeOqRxcdstwDfjP.update(CLWSiEQInmHhlbBJeOqRxcdstwDfjz)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjr=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.API_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfja
   CLWSiEQInmHhlbBJeOqRxcdstwDfMG=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.callRequestCookies('Get',CLWSiEQInmHhlbBJeOqRxcdstwDfjr,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,params=CLWSiEQInmHhlbBJeOqRxcdstwDfjP,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfYK)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjF=json.loads(CLWSiEQInmHhlbBJeOqRxcdstwDfMG.text)
   if not('result' in CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']):return CLWSiEQInmHhlbBJeOqRxcdstwDfoA,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
   CLWSiEQInmHhlbBJeOqRxcdstwDfoP=CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']['result']
   for CLWSiEQInmHhlbBJeOqRxcdstwDfju in CLWSiEQInmHhlbBJeOqRxcdstwDfoP:
    CLWSiEQInmHhlbBJeOqRxcdstwDfVr=CLWSiEQInmHhlbBJeOqRxcdstwDfju['program']['code']
    CLWSiEQInmHhlbBJeOqRxcdstwDfoU =CLWSiEQInmHhlbBJeOqRxcdstwDfju['program']['name']['ko']
    CLWSiEQInmHhlbBJeOqRxcdstwDfVv =CLWSiEQInmHhlbBJeOqRxcdstwDfMV.get(CLWSiEQInmHhlbBJeOqRxcdstwDfju['program'].get('grade_code'))
    CLWSiEQInmHhlbBJeOqRxcdstwDfou =''
    CLWSiEQInmHhlbBJeOqRxcdstwDfog =''
    CLWSiEQInmHhlbBJeOqRxcdstwDfoN=''
    CLWSiEQInmHhlbBJeOqRxcdstwDfoX =''
    CLWSiEQInmHhlbBJeOqRxcdstwDfoG =''
    for CLWSiEQInmHhlbBJeOqRxcdstwDfVM in CLWSiEQInmHhlbBJeOqRxcdstwDfju['program']['image']:
     if CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP0900':CLWSiEQInmHhlbBJeOqRxcdstwDfou =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
     elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP0200':CLWSiEQInmHhlbBJeOqRxcdstwDfog =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
     elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP1800':CLWSiEQInmHhlbBJeOqRxcdstwDfoN=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
     elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP2000':CLWSiEQInmHhlbBJeOqRxcdstwDfoX =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
     elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP1900':CLWSiEQInmHhlbBJeOqRxcdstwDfoG =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
    CLWSiEQInmHhlbBJeOqRxcdstwDfok =CLWSiEQInmHhlbBJeOqRxcdstwDfju['program']['synopsis']['ko']
    try:
     CLWSiEQInmHhlbBJeOqRxcdstwDfVF=CLWSiEQInmHhlbBJeOqRxcdstwDfju['channel']['name']['ko']
    except:
     CLWSiEQInmHhlbBJeOqRxcdstwDfVF=''
    try:
     CLWSiEQInmHhlbBJeOqRxcdstwDfVj =[]
     CLWSiEQInmHhlbBJeOqRxcdstwDfVo=[]
     CLWSiEQInmHhlbBJeOqRxcdstwDfVY =[]
     CLWSiEQInmHhlbBJeOqRxcdstwDfVT =''
     CLWSiEQInmHhlbBJeOqRxcdstwDfVA=''
     for CLWSiEQInmHhlbBJeOqRxcdstwDfVy in CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('program').get('actor'):
      if CLWSiEQInmHhlbBJeOqRxcdstwDfVy!='' and CLWSiEQInmHhlbBJeOqRxcdstwDfVy!='-' and CLWSiEQInmHhlbBJeOqRxcdstwDfVy!=u'없음':CLWSiEQInmHhlbBJeOqRxcdstwDfVj.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVy)
     for CLWSiEQInmHhlbBJeOqRxcdstwDfVp in CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('program').get('director'):
      if CLWSiEQInmHhlbBJeOqRxcdstwDfVp!='' and CLWSiEQInmHhlbBJeOqRxcdstwDfVp!='-' and CLWSiEQInmHhlbBJeOqRxcdstwDfVp!=u'없음':CLWSiEQInmHhlbBJeOqRxcdstwDfVo.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVp)
     if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('program').get('category1_name').get('ko')!='':
      CLWSiEQInmHhlbBJeOqRxcdstwDfVY.append(CLWSiEQInmHhlbBJeOqRxcdstwDfju['program']['category1_name']['ko'])
     if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('program').get('category2_name').get('ko')!='':
      CLWSiEQInmHhlbBJeOqRxcdstwDfVY.append(CLWSiEQInmHhlbBJeOqRxcdstwDfju['program']['category2_name']['ko'])
     if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('program').get('product_year'):CLWSiEQInmHhlbBJeOqRxcdstwDfVT=CLWSiEQInmHhlbBJeOqRxcdstwDfju['program']['product_year']
     if 'broad_dt' in CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('program'):
      CLWSiEQInmHhlbBJeOqRxcdstwDfVa =CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('program').get('broad_dt')
      CLWSiEQInmHhlbBJeOqRxcdstwDfVA='%s-%s-%s'%(CLWSiEQInmHhlbBJeOqRxcdstwDfVa[:4],CLWSiEQInmHhlbBJeOqRxcdstwDfVa[4:6],CLWSiEQInmHhlbBJeOqRxcdstwDfVa[6:])
    except:
     CLWSiEQInmHhlbBJeOqRxcdstwDfYK
    CLWSiEQInmHhlbBJeOqRxcdstwDfVz={'program':CLWSiEQInmHhlbBJeOqRxcdstwDfVr,'title':CLWSiEQInmHhlbBJeOqRxcdstwDfoU,'thumbnail':{'poster':CLWSiEQInmHhlbBJeOqRxcdstwDfou,'thumb':CLWSiEQInmHhlbBJeOqRxcdstwDfog,'clearlogo':CLWSiEQInmHhlbBJeOqRxcdstwDfoN,'icon':CLWSiEQInmHhlbBJeOqRxcdstwDfoX,'banner':CLWSiEQInmHhlbBJeOqRxcdstwDfoG,'fanart':CLWSiEQInmHhlbBJeOqRxcdstwDfog},'synopsis':CLWSiEQInmHhlbBJeOqRxcdstwDfok,'channel':CLWSiEQInmHhlbBJeOqRxcdstwDfVF,'cast':CLWSiEQInmHhlbBJeOqRxcdstwDfVj,'director':CLWSiEQInmHhlbBJeOqRxcdstwDfVo,'info_genre':CLWSiEQInmHhlbBJeOqRxcdstwDfVY,'year':CLWSiEQInmHhlbBJeOqRxcdstwDfVT,'premiered':CLWSiEQInmHhlbBJeOqRxcdstwDfVA,'mpaa':CLWSiEQInmHhlbBJeOqRxcdstwDfVv}
    CLWSiEQInmHhlbBJeOqRxcdstwDfoA.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVz)
   if CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']['has_more']=='Y':CLWSiEQInmHhlbBJeOqRxcdstwDfoy=CLWSiEQInmHhlbBJeOqRxcdstwDfTV
  except CLWSiEQInmHhlbBJeOqRxcdstwDfTY as exception:
   CLWSiEQInmHhlbBJeOqRxcdstwDfTv(exception)
  return CLWSiEQInmHhlbBJeOqRxcdstwDfoA,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
 def GetEpisodeList(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,program_code,page_int,orderby='desc'):
  CLWSiEQInmHhlbBJeOqRxcdstwDfoA=[]
  CLWSiEQInmHhlbBJeOqRxcdstwDfoy=CLWSiEQInmHhlbBJeOqRxcdstwDfTM
  try:
   CLWSiEQInmHhlbBJeOqRxcdstwDfja ='/v2/media/frequency/program/'+program_code
   CLWSiEQInmHhlbBJeOqRxcdstwDfjP=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetDefaultParams()
   CLWSiEQInmHhlbBJeOqRxcdstwDfjz={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetNoCache(2))}
   CLWSiEQInmHhlbBJeOqRxcdstwDfjP.update(CLWSiEQInmHhlbBJeOqRxcdstwDfjz)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjr=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.API_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfja
   CLWSiEQInmHhlbBJeOqRxcdstwDfMG=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.callRequestCookies('Get',CLWSiEQInmHhlbBJeOqRxcdstwDfjr,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,params=CLWSiEQInmHhlbBJeOqRxcdstwDfjP,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfYK)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjF=json.loads(CLWSiEQInmHhlbBJeOqRxcdstwDfMG.text)
   if not('result' in CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']):return CLWSiEQInmHhlbBJeOqRxcdstwDfoA,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
   CLWSiEQInmHhlbBJeOqRxcdstwDfoP=CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']['result']
   CLWSiEQInmHhlbBJeOqRxcdstwDfVU=CLWSiEQInmHhlbBJeOqRxcdstwDfTj(CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']['total_count'])
   CLWSiEQInmHhlbBJeOqRxcdstwDfVk =CLWSiEQInmHhlbBJeOqRxcdstwDfTj(CLWSiEQInmHhlbBJeOqRxcdstwDfVU//(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    CLWSiEQInmHhlbBJeOqRxcdstwDfVg =(CLWSiEQInmHhlbBJeOqRxcdstwDfVU-1)-((page_int-1)*CLWSiEQInmHhlbBJeOqRxcdstwDfMY.EPISODE_LIMIT)
   else:
    CLWSiEQInmHhlbBJeOqRxcdstwDfVg =(page_int-1)*CLWSiEQInmHhlbBJeOqRxcdstwDfMY.EPISODE_LIMIT
   for i in CLWSiEQInmHhlbBJeOqRxcdstwDfTo(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.EPISODE_LIMIT):
    if orderby=='desc':
     CLWSiEQInmHhlbBJeOqRxcdstwDfVu=CLWSiEQInmHhlbBJeOqRxcdstwDfVg-i
     if CLWSiEQInmHhlbBJeOqRxcdstwDfVu<0:break
    else:
     CLWSiEQInmHhlbBJeOqRxcdstwDfVu=CLWSiEQInmHhlbBJeOqRxcdstwDfVg+i
     if CLWSiEQInmHhlbBJeOqRxcdstwDfVu>=CLWSiEQInmHhlbBJeOqRxcdstwDfVU:break
    CLWSiEQInmHhlbBJeOqRxcdstwDfVN=CLWSiEQInmHhlbBJeOqRxcdstwDfoP[CLWSiEQInmHhlbBJeOqRxcdstwDfVu]['episode']['code']
    CLWSiEQInmHhlbBJeOqRxcdstwDfoU =CLWSiEQInmHhlbBJeOqRxcdstwDfoP[CLWSiEQInmHhlbBJeOqRxcdstwDfVu]['vod_name']['ko']
    CLWSiEQInmHhlbBJeOqRxcdstwDfVX =''
    try:
     CLWSiEQInmHhlbBJeOqRxcdstwDfVa=CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfoP[CLWSiEQInmHhlbBJeOqRxcdstwDfVu]['episode']['broadcast_date'])
     CLWSiEQInmHhlbBJeOqRxcdstwDfVX='%s-%s-%s'%(CLWSiEQInmHhlbBJeOqRxcdstwDfVa[:4],CLWSiEQInmHhlbBJeOqRxcdstwDfVa[4:6],CLWSiEQInmHhlbBJeOqRxcdstwDfVa[6:])
    except:
     CLWSiEQInmHhlbBJeOqRxcdstwDfYK
    CLWSiEQInmHhlbBJeOqRxcdstwDfok =CLWSiEQInmHhlbBJeOqRxcdstwDfoP[CLWSiEQInmHhlbBJeOqRxcdstwDfVu]['episode']['synopsis']['ko']
    CLWSiEQInmHhlbBJeOqRxcdstwDfou =''
    CLWSiEQInmHhlbBJeOqRxcdstwDfog =''
    CLWSiEQInmHhlbBJeOqRxcdstwDfoN=''
    CLWSiEQInmHhlbBJeOqRxcdstwDfoX =''
    CLWSiEQInmHhlbBJeOqRxcdstwDfoG =''
    CLWSiEQInmHhlbBJeOqRxcdstwDfoK =''
    for CLWSiEQInmHhlbBJeOqRxcdstwDfVM in CLWSiEQInmHhlbBJeOqRxcdstwDfoP[CLWSiEQInmHhlbBJeOqRxcdstwDfVu]['program']['image']:
     if CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP0900':CLWSiEQInmHhlbBJeOqRxcdstwDfou =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
     elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP1800':CLWSiEQInmHhlbBJeOqRxcdstwDfoN=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
     elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP2000':CLWSiEQInmHhlbBJeOqRxcdstwDfoX =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
     elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP1900':CLWSiEQInmHhlbBJeOqRxcdstwDfoG =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
     elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIP0200':CLWSiEQInmHhlbBJeOqRxcdstwDfoK =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
    for CLWSiEQInmHhlbBJeOqRxcdstwDfVM in CLWSiEQInmHhlbBJeOqRxcdstwDfoP[CLWSiEQInmHhlbBJeOqRxcdstwDfVu]['episode']['image']:
     if CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIE0400':CLWSiEQInmHhlbBJeOqRxcdstwDfog =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
    try:
     CLWSiEQInmHhlbBJeOqRxcdstwDfVG=CLWSiEQInmHhlbBJeOqRxcdstwDfYM=CLWSiEQInmHhlbBJeOqRxcdstwDfYj=''
     CLWSiEQInmHhlbBJeOqRxcdstwDfVK=0
     CLWSiEQInmHhlbBJeOqRxcdstwDfVG =CLWSiEQInmHhlbBJeOqRxcdstwDfoP[CLWSiEQInmHhlbBJeOqRxcdstwDfVu]['program']['name']['ko']
     CLWSiEQInmHhlbBJeOqRxcdstwDfYM =CLWSiEQInmHhlbBJeOqRxcdstwDfVX
     CLWSiEQInmHhlbBJeOqRxcdstwDfYj =CLWSiEQInmHhlbBJeOqRxcdstwDfoP[CLWSiEQInmHhlbBJeOqRxcdstwDfVu]['channel']['name']['ko']
     if 'frequency' in CLWSiEQInmHhlbBJeOqRxcdstwDfoP[CLWSiEQInmHhlbBJeOqRxcdstwDfVu]['episode']:CLWSiEQInmHhlbBJeOqRxcdstwDfVK=CLWSiEQInmHhlbBJeOqRxcdstwDfoP[CLWSiEQInmHhlbBJeOqRxcdstwDfVu]['episode']['frequency']
    except:
     CLWSiEQInmHhlbBJeOqRxcdstwDfYK
    CLWSiEQInmHhlbBJeOqRxcdstwDfVz={'episode':CLWSiEQInmHhlbBJeOqRxcdstwDfVN,'title':CLWSiEQInmHhlbBJeOqRxcdstwDfoU,'subtitle':CLWSiEQInmHhlbBJeOqRxcdstwDfVX,'thumbnail':{'poster':CLWSiEQInmHhlbBJeOqRxcdstwDfou,'thumb':CLWSiEQInmHhlbBJeOqRxcdstwDfog,'clearlogo':CLWSiEQInmHhlbBJeOqRxcdstwDfoN,'icon':CLWSiEQInmHhlbBJeOqRxcdstwDfoX,'banner':CLWSiEQInmHhlbBJeOqRxcdstwDfoG,'fanart':CLWSiEQInmHhlbBJeOqRxcdstwDfoK},'synopsis':CLWSiEQInmHhlbBJeOqRxcdstwDfok,'info_title':CLWSiEQInmHhlbBJeOqRxcdstwDfVG,'aired':CLWSiEQInmHhlbBJeOqRxcdstwDfYM,'studio':CLWSiEQInmHhlbBJeOqRxcdstwDfYj,'frequency':CLWSiEQInmHhlbBJeOqRxcdstwDfVK}
    CLWSiEQInmHhlbBJeOqRxcdstwDfoA.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVz)
   if CLWSiEQInmHhlbBJeOqRxcdstwDfVk>page_int:CLWSiEQInmHhlbBJeOqRxcdstwDfoy=CLWSiEQInmHhlbBJeOqRxcdstwDfTV
  except CLWSiEQInmHhlbBJeOqRxcdstwDfTY as exception:
   CLWSiEQInmHhlbBJeOqRxcdstwDfTv(exception)
  return CLWSiEQInmHhlbBJeOqRxcdstwDfoA,CLWSiEQInmHhlbBJeOqRxcdstwDfoy,CLWSiEQInmHhlbBJeOqRxcdstwDfVk
 def GetMovieList(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,genre,orderby,page_int):
  CLWSiEQInmHhlbBJeOqRxcdstwDfoA=[]
  CLWSiEQInmHhlbBJeOqRxcdstwDfoy=CLWSiEQInmHhlbBJeOqRxcdstwDfTM
  try:
   CLWSiEQInmHhlbBJeOqRxcdstwDfja ='/v2/media/movies'
   CLWSiEQInmHhlbBJeOqRxcdstwDfjP=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetDefaultParams()
   CLWSiEQInmHhlbBJeOqRxcdstwDfjz={'pageNo':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(page_int),'pageSize':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetNoCache(2))}
   if genre!='all' :CLWSiEQInmHhlbBJeOqRxcdstwDfjz['multiCategoryCode']=genre
   CLWSiEQInmHhlbBJeOqRxcdstwDfjz['productPackageCode']=','.join(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.MOVIE_LITE)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjP.update(CLWSiEQInmHhlbBJeOqRxcdstwDfjz)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjr=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.API_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfja
   CLWSiEQInmHhlbBJeOqRxcdstwDfMG=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.callRequestCookies('Get',CLWSiEQInmHhlbBJeOqRxcdstwDfjr,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,params=CLWSiEQInmHhlbBJeOqRxcdstwDfjP,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfYK)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjF=json.loads(CLWSiEQInmHhlbBJeOqRxcdstwDfMG.text)
   if not('result' in CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']):return CLWSiEQInmHhlbBJeOqRxcdstwDfoA,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
   CLWSiEQInmHhlbBJeOqRxcdstwDfoP=CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']['result']
   for CLWSiEQInmHhlbBJeOqRxcdstwDfju in CLWSiEQInmHhlbBJeOqRxcdstwDfoP:
    CLWSiEQInmHhlbBJeOqRxcdstwDfYo =CLWSiEQInmHhlbBJeOqRxcdstwDfju['movie']['code']
    CLWSiEQInmHhlbBJeOqRxcdstwDfoU =CLWSiEQInmHhlbBJeOqRxcdstwDfju['movie']['name']['ko'].strip()
    CLWSiEQInmHhlbBJeOqRxcdstwDfoU +=u' (%s년)'%(CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('movie').get('product_year'))
    CLWSiEQInmHhlbBJeOqRxcdstwDfou=''
    CLWSiEQInmHhlbBJeOqRxcdstwDfog =''
    CLWSiEQInmHhlbBJeOqRxcdstwDfoN=''
    for CLWSiEQInmHhlbBJeOqRxcdstwDfVM in CLWSiEQInmHhlbBJeOqRxcdstwDfju['movie']['image']:
     if CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIM2100':CLWSiEQInmHhlbBJeOqRxcdstwDfou =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
     elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIM0400':CLWSiEQInmHhlbBJeOqRxcdstwDfog =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
     elif CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIM1800':CLWSiEQInmHhlbBJeOqRxcdstwDfoN=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
    CLWSiEQInmHhlbBJeOqRxcdstwDfok =CLWSiEQInmHhlbBJeOqRxcdstwDfju['movie']['story']['ko']
    try:
     CLWSiEQInmHhlbBJeOqRxcdstwDfVG =CLWSiEQInmHhlbBJeOqRxcdstwDfju['movie']['name']['ko'].strip()
     CLWSiEQInmHhlbBJeOqRxcdstwDfVT =CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('movie').get('product_year')
     CLWSiEQInmHhlbBJeOqRxcdstwDfVv =CLWSiEQInmHhlbBJeOqRxcdstwDfMV.get(CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('grade_code'))
     CLWSiEQInmHhlbBJeOqRxcdstwDfVj=[]
     CLWSiEQInmHhlbBJeOqRxcdstwDfVo=[]
     CLWSiEQInmHhlbBJeOqRxcdstwDfVY=[]
     CLWSiEQInmHhlbBJeOqRxcdstwDfYV=0
     CLWSiEQInmHhlbBJeOqRxcdstwDfVA=''
     CLWSiEQInmHhlbBJeOqRxcdstwDfYj =''
     for CLWSiEQInmHhlbBJeOqRxcdstwDfVy in CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('movie').get('actor'):
      if CLWSiEQInmHhlbBJeOqRxcdstwDfVy!='':CLWSiEQInmHhlbBJeOqRxcdstwDfVj.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVy)
     for CLWSiEQInmHhlbBJeOqRxcdstwDfVp in CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('movie').get('director'):
      if CLWSiEQInmHhlbBJeOqRxcdstwDfVp!='':CLWSiEQInmHhlbBJeOqRxcdstwDfVo.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVp)
     if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('movie').get('category1_name').get('ko')!='':
      CLWSiEQInmHhlbBJeOqRxcdstwDfVY.append(CLWSiEQInmHhlbBJeOqRxcdstwDfju['movie']['category1_name']['ko'])
     if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('movie').get('category2_name').get('ko')!='':
      CLWSiEQInmHhlbBJeOqRxcdstwDfVY.append(CLWSiEQInmHhlbBJeOqRxcdstwDfju['movie']['category2_name']['ko'])
     if 'duration' in CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('movie'):CLWSiEQInmHhlbBJeOqRxcdstwDfYV=CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('movie').get('duration')
     if 'release_date' in CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('movie'):
      CLWSiEQInmHhlbBJeOqRxcdstwDfVa=CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('movie').get('release_date'))
      if CLWSiEQInmHhlbBJeOqRxcdstwDfVa!='0':CLWSiEQInmHhlbBJeOqRxcdstwDfVA='%s-%s-%s'%(CLWSiEQInmHhlbBJeOqRxcdstwDfVa[:4],CLWSiEQInmHhlbBJeOqRxcdstwDfVa[4:6],CLWSiEQInmHhlbBJeOqRxcdstwDfVa[6:])
     if 'production' in CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('movie'):CLWSiEQInmHhlbBJeOqRxcdstwDfYj=CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('movie').get('production')
    except:
     CLWSiEQInmHhlbBJeOqRxcdstwDfYK
    CLWSiEQInmHhlbBJeOqRxcdstwDfVz={'moviecode':CLWSiEQInmHhlbBJeOqRxcdstwDfYo,'title':CLWSiEQInmHhlbBJeOqRxcdstwDfoU,'thumbnail':{'poster':CLWSiEQInmHhlbBJeOqRxcdstwDfou,'thumb':CLWSiEQInmHhlbBJeOqRxcdstwDfog,'clearlogo':CLWSiEQInmHhlbBJeOqRxcdstwDfoN,'fanart':CLWSiEQInmHhlbBJeOqRxcdstwDfog},'synopsis':CLWSiEQInmHhlbBJeOqRxcdstwDfok,'info_title':CLWSiEQInmHhlbBJeOqRxcdstwDfVG,'year':CLWSiEQInmHhlbBJeOqRxcdstwDfVT,'cast':CLWSiEQInmHhlbBJeOqRxcdstwDfVj,'director':CLWSiEQInmHhlbBJeOqRxcdstwDfVo,'info_genre':CLWSiEQInmHhlbBJeOqRxcdstwDfVY,'duration':CLWSiEQInmHhlbBJeOqRxcdstwDfYV,'premiered':CLWSiEQInmHhlbBJeOqRxcdstwDfVA,'studio':CLWSiEQInmHhlbBJeOqRxcdstwDfYj,'mpaa':CLWSiEQInmHhlbBJeOqRxcdstwDfVv}
    CLWSiEQInmHhlbBJeOqRxcdstwDfYT=CLWSiEQInmHhlbBJeOqRxcdstwDfTM
    for CLWSiEQInmHhlbBJeOqRxcdstwDfYv in CLWSiEQInmHhlbBJeOqRxcdstwDfju['billing_package_id']:
     if CLWSiEQInmHhlbBJeOqRxcdstwDfYv in CLWSiEQInmHhlbBJeOqRxcdstwDfMY.MOVIE_LITE:
      CLWSiEQInmHhlbBJeOqRxcdstwDfYT=CLWSiEQInmHhlbBJeOqRxcdstwDfTV
      break
    if CLWSiEQInmHhlbBJeOqRxcdstwDfYT==CLWSiEQInmHhlbBJeOqRxcdstwDfTM: 
     CLWSiEQInmHhlbBJeOqRxcdstwDfVz['title']=CLWSiEQInmHhlbBJeOqRxcdstwDfVz['title']+' [개별구매]'
    CLWSiEQInmHhlbBJeOqRxcdstwDfoA.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVz)
   if CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']['has_more']=='Y':CLWSiEQInmHhlbBJeOqRxcdstwDfoy=CLWSiEQInmHhlbBJeOqRxcdstwDfTV
  except CLWSiEQInmHhlbBJeOqRxcdstwDfTY as exception:
   CLWSiEQInmHhlbBJeOqRxcdstwDfTv(exception)
  return CLWSiEQInmHhlbBJeOqRxcdstwDfoA,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
 def GetMovieListGenre(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,genre,page_int):
  CLWSiEQInmHhlbBJeOqRxcdstwDfoA=[]
  CLWSiEQInmHhlbBJeOqRxcdstwDfoy=CLWSiEQInmHhlbBJeOqRxcdstwDfTM
  try:
   CLWSiEQInmHhlbBJeOqRxcdstwDfja ='/v2/media/movie/curation/'+genre
   CLWSiEQInmHhlbBJeOqRxcdstwDfjP=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetDefaultParams()
   CLWSiEQInmHhlbBJeOqRxcdstwDfjz={'pageNo':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(page_int),'pageSize':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.MOVIE_LIMIT),'_':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetNoCache(2))}
   CLWSiEQInmHhlbBJeOqRxcdstwDfjP.update(CLWSiEQInmHhlbBJeOqRxcdstwDfjz)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjr=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.API_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfja
   CLWSiEQInmHhlbBJeOqRxcdstwDfMG=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.callRequestCookies('Get',CLWSiEQInmHhlbBJeOqRxcdstwDfjr,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,params=CLWSiEQInmHhlbBJeOqRxcdstwDfjP,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfYK)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjF=json.loads(CLWSiEQInmHhlbBJeOqRxcdstwDfMG.text)
   if not('movies' in CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']):return CLWSiEQInmHhlbBJeOqRxcdstwDfoA,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
   CLWSiEQInmHhlbBJeOqRxcdstwDfoP=CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']['movies']
   for CLWSiEQInmHhlbBJeOqRxcdstwDfju in CLWSiEQInmHhlbBJeOqRxcdstwDfoP:
    CLWSiEQInmHhlbBJeOqRxcdstwDfYo =CLWSiEQInmHhlbBJeOqRxcdstwDfju['code']
    CLWSiEQInmHhlbBJeOqRxcdstwDfoU =CLWSiEQInmHhlbBJeOqRxcdstwDfju['name']['ko']
    CLWSiEQInmHhlbBJeOqRxcdstwDfYA =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfju['image'][0]['url']
    for CLWSiEQInmHhlbBJeOqRxcdstwDfVM in CLWSiEQInmHhlbBJeOqRxcdstwDfju['image']:
     if CLWSiEQInmHhlbBJeOqRxcdstwDfVM['code']=='CAIM2100':
      CLWSiEQInmHhlbBJeOqRxcdstwDfYA =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfVM['url']
    CLWSiEQInmHhlbBJeOqRxcdstwDfok =CLWSiEQInmHhlbBJeOqRxcdstwDfju['story']['ko']
    CLWSiEQInmHhlbBJeOqRxcdstwDfVz={'moviecode':CLWSiEQInmHhlbBJeOqRxcdstwDfYo,'title':CLWSiEQInmHhlbBJeOqRxcdstwDfoU.strip(),'thumbnail':CLWSiEQInmHhlbBJeOqRxcdstwDfYA,'synopsis':CLWSiEQInmHhlbBJeOqRxcdstwDfok}
    CLWSiEQInmHhlbBJeOqRxcdstwDfoA.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVz)
  except CLWSiEQInmHhlbBJeOqRxcdstwDfTY as exception:
   CLWSiEQInmHhlbBJeOqRxcdstwDfTv(exception)
  return CLWSiEQInmHhlbBJeOqRxcdstwDfoA,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
 def GetMovieGenre(CLWSiEQInmHhlbBJeOqRxcdstwDfMY):
  CLWSiEQInmHhlbBJeOqRxcdstwDfoA=[]
  CLWSiEQInmHhlbBJeOqRxcdstwDfoy=CLWSiEQInmHhlbBJeOqRxcdstwDfTM
  try:
   CLWSiEQInmHhlbBJeOqRxcdstwDfja ='/v2/media/movie/curations'
   CLWSiEQInmHhlbBJeOqRxcdstwDfjP=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetDefaultParams()
   CLWSiEQInmHhlbBJeOqRxcdstwDfjz={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetNoCache(2))}
   CLWSiEQInmHhlbBJeOqRxcdstwDfjP.update(CLWSiEQInmHhlbBJeOqRxcdstwDfjz)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjr=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.API_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfja
   CLWSiEQInmHhlbBJeOqRxcdstwDfMG=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.callRequestCookies('Get',CLWSiEQInmHhlbBJeOqRxcdstwDfjr,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,params=CLWSiEQInmHhlbBJeOqRxcdstwDfjP,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfYK)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjF=json.loads(CLWSiEQInmHhlbBJeOqRxcdstwDfMG.text)
   if not('result' in CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']):return CLWSiEQInmHhlbBJeOqRxcdstwDfoA,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
   CLWSiEQInmHhlbBJeOqRxcdstwDfoP=CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']['result']
   for CLWSiEQInmHhlbBJeOqRxcdstwDfju in CLWSiEQInmHhlbBJeOqRxcdstwDfoP:
    CLWSiEQInmHhlbBJeOqRxcdstwDfYy =CLWSiEQInmHhlbBJeOqRxcdstwDfju['curation_code']
    CLWSiEQInmHhlbBJeOqRxcdstwDfYp =CLWSiEQInmHhlbBJeOqRxcdstwDfju['curation_name']
    CLWSiEQInmHhlbBJeOqRxcdstwDfVz={'curation_code':CLWSiEQInmHhlbBJeOqRxcdstwDfYy,'curation_name':CLWSiEQInmHhlbBJeOqRxcdstwDfYp}
    CLWSiEQInmHhlbBJeOqRxcdstwDfoA.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVz)
  except CLWSiEQInmHhlbBJeOqRxcdstwDfTY as exception:
   CLWSiEQInmHhlbBJeOqRxcdstwDfTv(exception)
  return CLWSiEQInmHhlbBJeOqRxcdstwDfoA,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
 def GetSearchList(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,search_key,page_int,stype):
  CLWSiEQInmHhlbBJeOqRxcdstwDfYa=[]
  CLWSiEQInmHhlbBJeOqRxcdstwDfoy=CLWSiEQInmHhlbBJeOqRxcdstwDfTM
  try:
   CLWSiEQInmHhlbBJeOqRxcdstwDfja ='/search/getSearch.jsp'
   CLWSiEQInmHhlbBJeOqRxcdstwDfjz={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(page_int),'pageSize':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.SCREENCODE,'os':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.OSCODE,'network':CLWSiEQInmHhlbBJeOqRxcdstwDfMY.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':CLWSiEQInmHhlbBJeOqRxcdstwDfTA(CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GetNoCache(2))}
   CLWSiEQInmHhlbBJeOqRxcdstwDfjr=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.SEARCH_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfja
   CLWSiEQInmHhlbBJeOqRxcdstwDfMG=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.callRequestCookies('Get',CLWSiEQInmHhlbBJeOqRxcdstwDfjr,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,params=CLWSiEQInmHhlbBJeOqRxcdstwDfjz,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfYK)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjF=json.loads(CLWSiEQInmHhlbBJeOqRxcdstwDfMG.text)
   if stype=='vod':
    if not('programRsb' in CLWSiEQInmHhlbBJeOqRxcdstwDfjF):return CLWSiEQInmHhlbBJeOqRxcdstwDfYa,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
    CLWSiEQInmHhlbBJeOqRxcdstwDfYP=CLWSiEQInmHhlbBJeOqRxcdstwDfjF['programRsb']['dataList']
    CLWSiEQInmHhlbBJeOqRxcdstwDfYz =CLWSiEQInmHhlbBJeOqRxcdstwDfTj(CLWSiEQInmHhlbBJeOqRxcdstwDfjF['programRsb']['count'])
    for CLWSiEQInmHhlbBJeOqRxcdstwDfju in CLWSiEQInmHhlbBJeOqRxcdstwDfYP:
     CLWSiEQInmHhlbBJeOqRxcdstwDfVr=CLWSiEQInmHhlbBJeOqRxcdstwDfju['mast_cd']
     CLWSiEQInmHhlbBJeOqRxcdstwDfoU =CLWSiEQInmHhlbBJeOqRxcdstwDfju['mast_nm']
     CLWSiEQInmHhlbBJeOqRxcdstwDfou=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfju['web_url4']
     CLWSiEQInmHhlbBJeOqRxcdstwDfog =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfju['web_url']
     try:
      CLWSiEQInmHhlbBJeOqRxcdstwDfVj =[]
      CLWSiEQInmHhlbBJeOqRxcdstwDfVo=[]
      CLWSiEQInmHhlbBJeOqRxcdstwDfVY =[]
      CLWSiEQInmHhlbBJeOqRxcdstwDfYV =0
      CLWSiEQInmHhlbBJeOqRxcdstwDfVv =''
      CLWSiEQInmHhlbBJeOqRxcdstwDfVT =''
      CLWSiEQInmHhlbBJeOqRxcdstwDfYM =''
      if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('actor') !='' and CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('actor') !='-':CLWSiEQInmHhlbBJeOqRxcdstwDfVj =CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('actor').split(',')
      if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('director')!='' and CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('director')!='-':CLWSiEQInmHhlbBJeOqRxcdstwDfVo=CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('director').split(',')
      if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('cate_nm')!='' and CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('cate_nm')!='-':CLWSiEQInmHhlbBJeOqRxcdstwDfVY =CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('cate_nm').split('/')
      if 'targetage' in CLWSiEQInmHhlbBJeOqRxcdstwDfju:CLWSiEQInmHhlbBJeOqRxcdstwDfVv=CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('targetage')
      if 'broad_dt' in CLWSiEQInmHhlbBJeOqRxcdstwDfju:
       CLWSiEQInmHhlbBJeOqRxcdstwDfVa=CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('broad_dt')
       CLWSiEQInmHhlbBJeOqRxcdstwDfYM='%s-%s-%s'%(CLWSiEQInmHhlbBJeOqRxcdstwDfVa[:4],CLWSiEQInmHhlbBJeOqRxcdstwDfVa[4:6],CLWSiEQInmHhlbBJeOqRxcdstwDfVa[6:])
       CLWSiEQInmHhlbBJeOqRxcdstwDfVT =CLWSiEQInmHhlbBJeOqRxcdstwDfVa[:4]
     except:
      CLWSiEQInmHhlbBJeOqRxcdstwDfYK
     CLWSiEQInmHhlbBJeOqRxcdstwDfVz={'program':CLWSiEQInmHhlbBJeOqRxcdstwDfVr,'title':CLWSiEQInmHhlbBJeOqRxcdstwDfoU,'thumbnail':{'poster':CLWSiEQInmHhlbBJeOqRxcdstwDfou,'thumb':CLWSiEQInmHhlbBJeOqRxcdstwDfog,'fanart':CLWSiEQInmHhlbBJeOqRxcdstwDfog},'synopsis':'','cast':CLWSiEQInmHhlbBJeOqRxcdstwDfVj,'director':CLWSiEQInmHhlbBJeOqRxcdstwDfVo,'info_genre':CLWSiEQInmHhlbBJeOqRxcdstwDfVY,'duration':CLWSiEQInmHhlbBJeOqRxcdstwDfYV,'mpaa':CLWSiEQInmHhlbBJeOqRxcdstwDfVv,'year':CLWSiEQInmHhlbBJeOqRxcdstwDfVT,'aired':CLWSiEQInmHhlbBJeOqRxcdstwDfYM}
     CLWSiEQInmHhlbBJeOqRxcdstwDfYa.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVz)
   else:
    if not('vodMVRsb' in CLWSiEQInmHhlbBJeOqRxcdstwDfjF):return CLWSiEQInmHhlbBJeOqRxcdstwDfYa,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
    CLWSiEQInmHhlbBJeOqRxcdstwDfYr=CLWSiEQInmHhlbBJeOqRxcdstwDfjF['vodMVRsb']['dataList']
    CLWSiEQInmHhlbBJeOqRxcdstwDfYz =CLWSiEQInmHhlbBJeOqRxcdstwDfTj(CLWSiEQInmHhlbBJeOqRxcdstwDfjF['vodMVRsb']['count'])
    for CLWSiEQInmHhlbBJeOqRxcdstwDfju in CLWSiEQInmHhlbBJeOqRxcdstwDfYr:
     CLWSiEQInmHhlbBJeOqRxcdstwDfVr=CLWSiEQInmHhlbBJeOqRxcdstwDfju['mast_cd']
     CLWSiEQInmHhlbBJeOqRxcdstwDfoU =CLWSiEQInmHhlbBJeOqRxcdstwDfju['mast_nm'].strip()
     CLWSiEQInmHhlbBJeOqRxcdstwDfou =CLWSiEQInmHhlbBJeOqRxcdstwDfMY.IMG_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfju['web_url']
     CLWSiEQInmHhlbBJeOqRxcdstwDfog =CLWSiEQInmHhlbBJeOqRxcdstwDfou
     CLWSiEQInmHhlbBJeOqRxcdstwDfoN=''
     try:
      CLWSiEQInmHhlbBJeOqRxcdstwDfVj =[]
      CLWSiEQInmHhlbBJeOqRxcdstwDfVo=[]
      CLWSiEQInmHhlbBJeOqRxcdstwDfVY =[]
      CLWSiEQInmHhlbBJeOqRxcdstwDfYV =0
      CLWSiEQInmHhlbBJeOqRxcdstwDfVv =''
      CLWSiEQInmHhlbBJeOqRxcdstwDfVT =''
      CLWSiEQInmHhlbBJeOqRxcdstwDfYM =''
      if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('actor') !='' and CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('actor') !='-':CLWSiEQInmHhlbBJeOqRxcdstwDfVj =CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('actor').split(',')
      if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('director')!='' and CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('director')!='-':CLWSiEQInmHhlbBJeOqRxcdstwDfVo=CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('director').split(',')
      if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('cate_nm')!='' and CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('cate_nm')!='-':CLWSiEQInmHhlbBJeOqRxcdstwDfVY =CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('cate_nm').split('/')
      if CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('runtime_sec')!='':CLWSiEQInmHhlbBJeOqRxcdstwDfYV=CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('runtime_sec')
      if 'grade_nm' in CLWSiEQInmHhlbBJeOqRxcdstwDfju:CLWSiEQInmHhlbBJeOqRxcdstwDfVv=CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('grade_nm')
      CLWSiEQInmHhlbBJeOqRxcdstwDfVa=CLWSiEQInmHhlbBJeOqRxcdstwDfju.get('broad_dt')
      if data_str!='':
       CLWSiEQInmHhlbBJeOqRxcdstwDfYM='%s-%s-%s'%(CLWSiEQInmHhlbBJeOqRxcdstwDfVa[:4],CLWSiEQInmHhlbBJeOqRxcdstwDfVa[4:6],CLWSiEQInmHhlbBJeOqRxcdstwDfVa[6:])
       CLWSiEQInmHhlbBJeOqRxcdstwDfVT =CLWSiEQInmHhlbBJeOqRxcdstwDfVa[:4]
     except:
      CLWSiEQInmHhlbBJeOqRxcdstwDfYK
     CLWSiEQInmHhlbBJeOqRxcdstwDfVz={'movie':CLWSiEQInmHhlbBJeOqRxcdstwDfVr,'title':CLWSiEQInmHhlbBJeOqRxcdstwDfoU,'thumbnail':{'poster':CLWSiEQInmHhlbBJeOqRxcdstwDfou,'thumb':CLWSiEQInmHhlbBJeOqRxcdstwDfog,'fanart':CLWSiEQInmHhlbBJeOqRxcdstwDfog,'clearlogo':CLWSiEQInmHhlbBJeOqRxcdstwDfoN},'synopsis':'','cast':CLWSiEQInmHhlbBJeOqRxcdstwDfVj,'director':CLWSiEQInmHhlbBJeOqRxcdstwDfVo,'info_genre':CLWSiEQInmHhlbBJeOqRxcdstwDfVY,'duration':CLWSiEQInmHhlbBJeOqRxcdstwDfYV,'mpaa':CLWSiEQInmHhlbBJeOqRxcdstwDfVv,'year':CLWSiEQInmHhlbBJeOqRxcdstwDfVT,'aired':CLWSiEQInmHhlbBJeOqRxcdstwDfYM}
     CLWSiEQInmHhlbBJeOqRxcdstwDfYT=CLWSiEQInmHhlbBJeOqRxcdstwDfTM
     for CLWSiEQInmHhlbBJeOqRxcdstwDfYv in CLWSiEQInmHhlbBJeOqRxcdstwDfju['bill']:
      if CLWSiEQInmHhlbBJeOqRxcdstwDfYv in CLWSiEQInmHhlbBJeOqRxcdstwDfMY.MOVIE_LITE:
       CLWSiEQInmHhlbBJeOqRxcdstwDfYT=CLWSiEQInmHhlbBJeOqRxcdstwDfTV
       break
     if CLWSiEQInmHhlbBJeOqRxcdstwDfYT==CLWSiEQInmHhlbBJeOqRxcdstwDfTM: 
      CLWSiEQInmHhlbBJeOqRxcdstwDfVz['title']=CLWSiEQInmHhlbBJeOqRxcdstwDfVz['title']+' [개별구매]'
     CLWSiEQInmHhlbBJeOqRxcdstwDfYa.append(CLWSiEQInmHhlbBJeOqRxcdstwDfVz)
   if CLWSiEQInmHhlbBJeOqRxcdstwDfYz>(page_int*CLWSiEQInmHhlbBJeOqRxcdstwDfMY.SEARCH_LIMIT):CLWSiEQInmHhlbBJeOqRxcdstwDfoy=CLWSiEQInmHhlbBJeOqRxcdstwDfTV
  except CLWSiEQInmHhlbBJeOqRxcdstwDfTY as exception:
   CLWSiEQInmHhlbBJeOqRxcdstwDfTv(exception)
  return CLWSiEQInmHhlbBJeOqRxcdstwDfYa,CLWSiEQInmHhlbBJeOqRxcdstwDfoy
 def GetDeviceList(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,CLWSiEQInmHhlbBJeOqRxcdstwDfjM,CLWSiEQInmHhlbBJeOqRxcdstwDfjo):
  CLWSiEQInmHhlbBJeOqRxcdstwDfoA=[]
  CLWSiEQInmHhlbBJeOqRxcdstwDfjy='-'
  try:
   CLWSiEQInmHhlbBJeOqRxcdstwDfja ='/v1/user/device/list'
   CLWSiEQInmHhlbBJeOqRxcdstwDfYF=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.API_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfja
   CLWSiEQInmHhlbBJeOqRxcdstwDfjz={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   CLWSiEQInmHhlbBJeOqRxcdstwDfMA=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.makeDefaultCookies(vToken=CLWSiEQInmHhlbBJeOqRxcdstwDfjM,vUserinfo=CLWSiEQInmHhlbBJeOqRxcdstwDfjo)
   CLWSiEQInmHhlbBJeOqRxcdstwDfMG=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.callRequestCookies('Get',CLWSiEQInmHhlbBJeOqRxcdstwDfYF,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,params=CLWSiEQInmHhlbBJeOqRxcdstwDfjz,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfMA)
   CLWSiEQInmHhlbBJeOqRxcdstwDfjF=json.loads(CLWSiEQInmHhlbBJeOqRxcdstwDfMG.text)
   CLWSiEQInmHhlbBJeOqRxcdstwDfoA=CLWSiEQInmHhlbBJeOqRxcdstwDfjF['body']
   for CLWSiEQInmHhlbBJeOqRxcdstwDfju in CLWSiEQInmHhlbBJeOqRxcdstwDfoA:
    if CLWSiEQInmHhlbBJeOqRxcdstwDfju['model']=='PC':
     CLWSiEQInmHhlbBJeOqRxcdstwDfjy=CLWSiEQInmHhlbBJeOqRxcdstwDfju['uuid']
  except CLWSiEQInmHhlbBJeOqRxcdstwDfTY as exception:
   CLWSiEQInmHhlbBJeOqRxcdstwDfTv(exception)
  return CLWSiEQInmHhlbBJeOqRxcdstwDfjy
 def GetProfileToken(CLWSiEQInmHhlbBJeOqRxcdstwDfMY,CLWSiEQInmHhlbBJeOqRxcdstwDfjM,CLWSiEQInmHhlbBJeOqRxcdstwDfjo,user_pf):
  CLWSiEQInmHhlbBJeOqRxcdstwDfYU=[]
  CLWSiEQInmHhlbBJeOqRxcdstwDfYk =''
  CLWSiEQInmHhlbBJeOqRxcdstwDfYg =''
  CLWSiEQInmHhlbBJeOqRxcdstwDfYu='Y'
  CLWSiEQInmHhlbBJeOqRxcdstwDfYN ='N'
  try:
   CLWSiEQInmHhlbBJeOqRxcdstwDfja ='/profile/select.do'
   CLWSiEQInmHhlbBJeOqRxcdstwDfYF=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.URL_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfja
   CLWSiEQInmHhlbBJeOqRxcdstwDfMA=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.makeDefaultCookies(vToken=CLWSiEQInmHhlbBJeOqRxcdstwDfjM,vUserinfo=CLWSiEQInmHhlbBJeOqRxcdstwDfjo)
   CLWSiEQInmHhlbBJeOqRxcdstwDfMG=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.callRequestCookies('Get',CLWSiEQInmHhlbBJeOqRxcdstwDfYF,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,params=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfMA)
   CLWSiEQInmHhlbBJeOqRxcdstwDfYU =re.findall('data-profile-no="\d+"',CLWSiEQInmHhlbBJeOqRxcdstwDfMG.text)
   for i in CLWSiEQInmHhlbBJeOqRxcdstwDfTo(CLWSiEQInmHhlbBJeOqRxcdstwDfTp(CLWSiEQInmHhlbBJeOqRxcdstwDfYU)):
    CLWSiEQInmHhlbBJeOqRxcdstwDfYX =CLWSiEQInmHhlbBJeOqRxcdstwDfYU[i].replace('data-profile-no=','').replace('"','')
    CLWSiEQInmHhlbBJeOqRxcdstwDfYU[i]=CLWSiEQInmHhlbBJeOqRxcdstwDfYX
   CLWSiEQInmHhlbBJeOqRxcdstwDfYk=CLWSiEQInmHhlbBJeOqRxcdstwDfYU[user_pf]
  except CLWSiEQInmHhlbBJeOqRxcdstwDfTY as exception:
   CLWSiEQInmHhlbBJeOqRxcdstwDfTv(exception)
   return CLWSiEQInmHhlbBJeOqRxcdstwDfYg,CLWSiEQInmHhlbBJeOqRxcdstwDfYu,CLWSiEQInmHhlbBJeOqRxcdstwDfYN
  try:
   CLWSiEQInmHhlbBJeOqRxcdstwDfja ='/profile/api/select.do'
   CLWSiEQInmHhlbBJeOqRxcdstwDfYF=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.URL_DOMAIN+CLWSiEQInmHhlbBJeOqRxcdstwDfja
   CLWSiEQInmHhlbBJeOqRxcdstwDfMA=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.makeDefaultCookies(vToken=CLWSiEQInmHhlbBJeOqRxcdstwDfjM,vUserinfo=CLWSiEQInmHhlbBJeOqRxcdstwDfjo)
   CLWSiEQInmHhlbBJeOqRxcdstwDfMX={'profileNo':CLWSiEQInmHhlbBJeOqRxcdstwDfYk}
   CLWSiEQInmHhlbBJeOqRxcdstwDfMG=CLWSiEQInmHhlbBJeOqRxcdstwDfMY.callRequestCookies('Post',CLWSiEQInmHhlbBJeOqRxcdstwDfYF,payload=CLWSiEQInmHhlbBJeOqRxcdstwDfMX,params=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,headers=CLWSiEQInmHhlbBJeOqRxcdstwDfYK,cookies=CLWSiEQInmHhlbBJeOqRxcdstwDfMA)
   for CLWSiEQInmHhlbBJeOqRxcdstwDfMK in CLWSiEQInmHhlbBJeOqRxcdstwDfMG.cookies:
    if CLWSiEQInmHhlbBJeOqRxcdstwDfMK.name=='_tving_token':
     CLWSiEQInmHhlbBJeOqRxcdstwDfYg=CLWSiEQInmHhlbBJeOqRxcdstwDfMK.value
    elif CLWSiEQInmHhlbBJeOqRxcdstwDfMK.name==CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GLOBAL_COOKIENM['tv_cookiekey']:
     CLWSiEQInmHhlbBJeOqRxcdstwDfYu=CLWSiEQInmHhlbBJeOqRxcdstwDfMK.value
    elif CLWSiEQInmHhlbBJeOqRxcdstwDfMK.name==CLWSiEQInmHhlbBJeOqRxcdstwDfMY.GLOBAL_COOKIENM['tv_lockkey']:
     CLWSiEQInmHhlbBJeOqRxcdstwDfYN=CLWSiEQInmHhlbBJeOqRxcdstwDfMK.value
  except CLWSiEQInmHhlbBJeOqRxcdstwDfTY as exception:
   CLWSiEQInmHhlbBJeOqRxcdstwDfTv(exception)
  return CLWSiEQInmHhlbBJeOqRxcdstwDfYg,CLWSiEQInmHhlbBJeOqRxcdstwDfYu,CLWSiEQInmHhlbBJeOqRxcdstwDfYN
# Created by pyminifier (https://github.com/liftoff/pyminifier)
