__author__="NightRain"
fsaWieyBQvXwJbuEdINPpgzVRFMxcC=object
fsaWieyBQvXwJbuEdINPpgzVRFMxcO=None
fsaWieyBQvXwJbuEdINPpgzVRFMxcr=int
fsaWieyBQvXwJbuEdINPpgzVRFMxck=True
fsaWieyBQvXwJbuEdINPpgzVRFMxYl=False
fsaWieyBQvXwJbuEdINPpgzVRFMxYS=type
fsaWieyBQvXwJbuEdINPpgzVRFMxYH=dict
fsaWieyBQvXwJbuEdINPpgzVRFMxYq=len
fsaWieyBQvXwJbuEdINPpgzVRFMxYK=str
fsaWieyBQvXwJbuEdINPpgzVRFMxYc=open
fsaWieyBQvXwJbuEdINPpgzVRFMxYG=Exception
fsaWieyBQvXwJbuEdINPpgzVRFMxYt=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
fsaWieyBQvXwJbuEdINPpgzVRFMxlH=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'검색 (티빙)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 이력','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'}]
fsaWieyBQvXwJbuEdINPpgzVRFMxlq=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
fsaWieyBQvXwJbuEdINPpgzVRFMxlK=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
fsaWieyBQvXwJbuEdINPpgzVRFMxlc=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
fsaWieyBQvXwJbuEdINPpgzVRFMxlY=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
fsaWieyBQvXwJbuEdINPpgzVRFMxlG=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
fsaWieyBQvXwJbuEdINPpgzVRFMxlt=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
fsaWieyBQvXwJbuEdINPpgzVRFMxlA=xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class fsaWieyBQvXwJbuEdINPpgzVRFMxlS(fsaWieyBQvXwJbuEdINPpgzVRFMxcC):
 def __init__(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxlo,fsaWieyBQvXwJbuEdINPpgzVRFMxlh,fsaWieyBQvXwJbuEdINPpgzVRFMxlL):
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_url =fsaWieyBQvXwJbuEdINPpgzVRFMxlo
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle=fsaWieyBQvXwJbuEdINPpgzVRFMxlh
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params =fsaWieyBQvXwJbuEdINPpgzVRFMxlL
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj =CLWSiEQInmHhlbBJeOqRxcdstwDfMj() 
 def addon_noti(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,sting):
  try:
   fsaWieyBQvXwJbuEdINPpgzVRFMxlD=xbmcgui.Dialog()
   fsaWieyBQvXwJbuEdINPpgzVRFMxlD.notification(__addonname__,sting)
  except:
   fsaWieyBQvXwJbuEdINPpgzVRFMxcO
 def addon_log(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,string):
  try:
   fsaWieyBQvXwJbuEdINPpgzVRFMxlU=string.encode('utf-8','ignore')
  except:
   fsaWieyBQvXwJbuEdINPpgzVRFMxlU='addonException: addon_log'
  fsaWieyBQvXwJbuEdINPpgzVRFMxlj=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,fsaWieyBQvXwJbuEdINPpgzVRFMxlU),level=fsaWieyBQvXwJbuEdINPpgzVRFMxlj)
 def get_keyboard_input(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxSt):
  fsaWieyBQvXwJbuEdINPpgzVRFMxln=fsaWieyBQvXwJbuEdINPpgzVRFMxcO
  kb=xbmc.Keyboard()
  kb.setHeading(fsaWieyBQvXwJbuEdINPpgzVRFMxSt)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   fsaWieyBQvXwJbuEdINPpgzVRFMxln=kb.getText()
  return fsaWieyBQvXwJbuEdINPpgzVRFMxln
 def get_settings_login_info(fsaWieyBQvXwJbuEdINPpgzVRFMxlT):
  fsaWieyBQvXwJbuEdINPpgzVRFMxlC =__addon__.getSetting('id')
  fsaWieyBQvXwJbuEdINPpgzVRFMxlO =__addon__.getSetting('pw')
  fsaWieyBQvXwJbuEdINPpgzVRFMxlr =__addon__.getSetting('login_type')
  fsaWieyBQvXwJbuEdINPpgzVRFMxlk=fsaWieyBQvXwJbuEdINPpgzVRFMxcr(__addon__.getSetting('selected_profile'))
  return(fsaWieyBQvXwJbuEdINPpgzVRFMxlC,fsaWieyBQvXwJbuEdINPpgzVRFMxlO,fsaWieyBQvXwJbuEdINPpgzVRFMxlr,fsaWieyBQvXwJbuEdINPpgzVRFMxlk)
 def get_settings_totalsearch(fsaWieyBQvXwJbuEdINPpgzVRFMxlT):
  fsaWieyBQvXwJbuEdINPpgzVRFMxSl =fsaWieyBQvXwJbuEdINPpgzVRFMxck if __addon__.getSetting('local_search')=='true' else fsaWieyBQvXwJbuEdINPpgzVRFMxYl
  fsaWieyBQvXwJbuEdINPpgzVRFMxSH =fsaWieyBQvXwJbuEdINPpgzVRFMxck if __addon__.getSetting('total_search')=='true' else fsaWieyBQvXwJbuEdINPpgzVRFMxYl
  fsaWieyBQvXwJbuEdINPpgzVRFMxSq=fsaWieyBQvXwJbuEdINPpgzVRFMxck if __addon__.getSetting('total_history')=='true' else fsaWieyBQvXwJbuEdINPpgzVRFMxYl
  return(fsaWieyBQvXwJbuEdINPpgzVRFMxSl,fsaWieyBQvXwJbuEdINPpgzVRFMxSH,fsaWieyBQvXwJbuEdINPpgzVRFMxSq)
 def get_settings_direct_replay(fsaWieyBQvXwJbuEdINPpgzVRFMxlT):
  fsaWieyBQvXwJbuEdINPpgzVRFMxSK=fsaWieyBQvXwJbuEdINPpgzVRFMxcr(__addon__.getSetting('direct_replay'))
  if fsaWieyBQvXwJbuEdINPpgzVRFMxSK==0:
   return fsaWieyBQvXwJbuEdINPpgzVRFMxYl
  else:
   return fsaWieyBQvXwJbuEdINPpgzVRFMxck
 def set_winCredential(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,credential):
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc=xbmcgui.Window(10000)
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_LOGINTIME',fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(fsaWieyBQvXwJbuEdINPpgzVRFMxlT):
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc=xbmcgui.Window(10000)
  fsaWieyBQvXwJbuEdINPpgzVRFMxSY={'tving_token':fsaWieyBQvXwJbuEdINPpgzVRFMxSc.getProperty('TVING_M_TOKEN'),'poc_userinfo':fsaWieyBQvXwJbuEdINPpgzVRFMxSc.getProperty('TVING_M_USERINFO'),'tving_uuid':fsaWieyBQvXwJbuEdINPpgzVRFMxSc.getProperty('TVING_M_UUID'),'tving_maintoken':fsaWieyBQvXwJbuEdINPpgzVRFMxSc.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':fsaWieyBQvXwJbuEdINPpgzVRFMxSc.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':fsaWieyBQvXwJbuEdINPpgzVRFMxSc.getProperty('TVING_M_LOCKKEY')}
  return fsaWieyBQvXwJbuEdINPpgzVRFMxSY
 def set_winEpisodeOrderby(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxqH):
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc=xbmcgui.Window(10000)
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_ORDERBY',fsaWieyBQvXwJbuEdINPpgzVRFMxqH)
 def get_winEpisodeOrderby(fsaWieyBQvXwJbuEdINPpgzVRFMxlT):
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc=xbmcgui.Window(10000)
  return fsaWieyBQvXwJbuEdINPpgzVRFMxSc.getProperty('TVING_M_ORDERBY')
 def add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,label,sublabel='',img='',infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxcO,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxck,params='',isLink=fsaWieyBQvXwJbuEdINPpgzVRFMxYl,ContextMenu=fsaWieyBQvXwJbuEdINPpgzVRFMxcO):
  fsaWieyBQvXwJbuEdINPpgzVRFMxSG='%s?%s'%(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_url,urllib.parse.urlencode(params))
  if sublabel:fsaWieyBQvXwJbuEdINPpgzVRFMxSt='%s < %s >'%(label,sublabel)
  else: fsaWieyBQvXwJbuEdINPpgzVRFMxSt=label
  if not img:img='DefaultFolder.png'
  fsaWieyBQvXwJbuEdINPpgzVRFMxSA=xbmcgui.ListItem(fsaWieyBQvXwJbuEdINPpgzVRFMxSt)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxYS(img)==fsaWieyBQvXwJbuEdINPpgzVRFMxYH:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSA.setArt(img)
  else:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSA.setArt({'thumb':img,'poster':img})
  if infoLabels:fsaWieyBQvXwJbuEdINPpgzVRFMxSA.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSA.setProperty('IsPlayable','true')
  if ContextMenu:fsaWieyBQvXwJbuEdINPpgzVRFMxSA.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle,fsaWieyBQvXwJbuEdINPpgzVRFMxSG,fsaWieyBQvXwJbuEdINPpgzVRFMxSA,isFolder)
 def get_selQuality(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,etype):
  try:
   fsaWieyBQvXwJbuEdINPpgzVRFMxST='selected_quality'
   fsaWieyBQvXwJbuEdINPpgzVRFMxSo=[1080,720,480,360]
   fsaWieyBQvXwJbuEdINPpgzVRFMxSh=fsaWieyBQvXwJbuEdINPpgzVRFMxcr(__addon__.getSetting(fsaWieyBQvXwJbuEdINPpgzVRFMxST))
   return fsaWieyBQvXwJbuEdINPpgzVRFMxSo[fsaWieyBQvXwJbuEdINPpgzVRFMxSh]
  except:
   fsaWieyBQvXwJbuEdINPpgzVRFMxcO
  return 720 
 def dp_Main_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT):
  (fsaWieyBQvXwJbuEdINPpgzVRFMxSl,fsaWieyBQvXwJbuEdINPpgzVRFMxSH,fsaWieyBQvXwJbuEdINPpgzVRFMxSq)=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_settings_totalsearch()
  for fsaWieyBQvXwJbuEdINPpgzVRFMxSL in fsaWieyBQvXwJbuEdINPpgzVRFMxlH:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt=fsaWieyBQvXwJbuEdINPpgzVRFMxSL.get('title')
   fsaWieyBQvXwJbuEdINPpgzVRFMxSm=''
   if fsaWieyBQvXwJbuEdINPpgzVRFMxSL.get('mode')=='SEARCH_GROUP' and fsaWieyBQvXwJbuEdINPpgzVRFMxSl ==fsaWieyBQvXwJbuEdINPpgzVRFMxYl:continue
   elif fsaWieyBQvXwJbuEdINPpgzVRFMxSL.get('mode')=='TOTAL_SEARCH' and fsaWieyBQvXwJbuEdINPpgzVRFMxSH ==fsaWieyBQvXwJbuEdINPpgzVRFMxYl:continue
   elif fsaWieyBQvXwJbuEdINPpgzVRFMxSL.get('mode')=='TOTAL_HISTORY' and fsaWieyBQvXwJbuEdINPpgzVRFMxSq==fsaWieyBQvXwJbuEdINPpgzVRFMxYl:continue
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':fsaWieyBQvXwJbuEdINPpgzVRFMxSL.get('mode'),'stype':fsaWieyBQvXwJbuEdINPpgzVRFMxSL.get('stype'),'orderby':fsaWieyBQvXwJbuEdINPpgzVRFMxSL.get('orderby'),'ordernm':fsaWieyBQvXwJbuEdINPpgzVRFMxSL.get('ordernm'),'page':'1'}
   if fsaWieyBQvXwJbuEdINPpgzVRFMxSL.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY']:
    fsaWieyBQvXwJbuEdINPpgzVRFMxSU=fsaWieyBQvXwJbuEdINPpgzVRFMxYl
    fsaWieyBQvXwJbuEdINPpgzVRFMxSj =fsaWieyBQvXwJbuEdINPpgzVRFMxck
   else:
    fsaWieyBQvXwJbuEdINPpgzVRFMxSU=fsaWieyBQvXwJbuEdINPpgzVRFMxck
    fsaWieyBQvXwJbuEdINPpgzVRFMxSj =fsaWieyBQvXwJbuEdINPpgzVRFMxYl
   if 'icon' in fsaWieyBQvXwJbuEdINPpgzVRFMxSL:fsaWieyBQvXwJbuEdINPpgzVRFMxSm=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',fsaWieyBQvXwJbuEdINPpgzVRFMxSL.get('icon')) 
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel='',img=fsaWieyBQvXwJbuEdINPpgzVRFMxSm,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxcO,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxSU,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD,isLink=fsaWieyBQvXwJbuEdINPpgzVRFMxSj)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxYq(fsaWieyBQvXwJbuEdINPpgzVRFMxlH)>0:xbmcplugin.endOfDirectory(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle)
 def login_main(fsaWieyBQvXwJbuEdINPpgzVRFMxlT):
  (fsaWieyBQvXwJbuEdINPpgzVRFMxSC,fsaWieyBQvXwJbuEdINPpgzVRFMxSO,fsaWieyBQvXwJbuEdINPpgzVRFMxSr,fsaWieyBQvXwJbuEdINPpgzVRFMxSk)=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_settings_login_info()
  if not(fsaWieyBQvXwJbuEdINPpgzVRFMxSC and fsaWieyBQvXwJbuEdINPpgzVRFMxSO):
   fsaWieyBQvXwJbuEdINPpgzVRFMxlD=xbmcgui.Dialog()
   fsaWieyBQvXwJbuEdINPpgzVRFMxHl=fsaWieyBQvXwJbuEdINPpgzVRFMxlD.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if fsaWieyBQvXwJbuEdINPpgzVRFMxHl==fsaWieyBQvXwJbuEdINPpgzVRFMxck:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_winEpisodeOrderby()=='':
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.set_winEpisodeOrderby('desc')
  if fsaWieyBQvXwJbuEdINPpgzVRFMxlT.cookiefile_check():return
  fsaWieyBQvXwJbuEdINPpgzVRFMxHS =fsaWieyBQvXwJbuEdINPpgzVRFMxcr(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  fsaWieyBQvXwJbuEdINPpgzVRFMxHq=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if fsaWieyBQvXwJbuEdINPpgzVRFMxHq==fsaWieyBQvXwJbuEdINPpgzVRFMxcO or fsaWieyBQvXwJbuEdINPpgzVRFMxHq=='':
   fsaWieyBQvXwJbuEdINPpgzVRFMxHq=fsaWieyBQvXwJbuEdINPpgzVRFMxcr('19000101')
  else:
   fsaWieyBQvXwJbuEdINPpgzVRFMxHq=fsaWieyBQvXwJbuEdINPpgzVRFMxcr(re.sub('-','',fsaWieyBQvXwJbuEdINPpgzVRFMxHq))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   fsaWieyBQvXwJbuEdINPpgzVRFMxHK=0
   while fsaWieyBQvXwJbuEdINPpgzVRFMxck:
    fsaWieyBQvXwJbuEdINPpgzVRFMxHK+=1
    time.sleep(0.05)
    if fsaWieyBQvXwJbuEdINPpgzVRFMxHq>=fsaWieyBQvXwJbuEdINPpgzVRFMxHS:return
    if fsaWieyBQvXwJbuEdINPpgzVRFMxHK>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if fsaWieyBQvXwJbuEdINPpgzVRFMxHq>=fsaWieyBQvXwJbuEdINPpgzVRFMxHS:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.GetCredential(fsaWieyBQvXwJbuEdINPpgzVRFMxSC,fsaWieyBQvXwJbuEdINPpgzVRFMxSO,fsaWieyBQvXwJbuEdINPpgzVRFMxSr,fsaWieyBQvXwJbuEdINPpgzVRFMxSk):
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.set_winCredential(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.LoadCredential())
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt):
  fsaWieyBQvXwJbuEdINPpgzVRFMxHc=fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('stype')
  if fsaWieyBQvXwJbuEdINPpgzVRFMxHc=='live':
   fsaWieyBQvXwJbuEdINPpgzVRFMxHY=fsaWieyBQvXwJbuEdINPpgzVRFMxlq
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxHc=='vod':
   fsaWieyBQvXwJbuEdINPpgzVRFMxHY=fsaWieyBQvXwJbuEdINPpgzVRFMxlY
  else:
   fsaWieyBQvXwJbuEdINPpgzVRFMxHY=fsaWieyBQvXwJbuEdINPpgzVRFMxlG
  for fsaWieyBQvXwJbuEdINPpgzVRFMxHG in fsaWieyBQvXwJbuEdINPpgzVRFMxHY:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt=fsaWieyBQvXwJbuEdINPpgzVRFMxHG.get('title')
   if fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('ordernm')!='-':
    fsaWieyBQvXwJbuEdINPpgzVRFMxSt+='  ('+fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('ordernm')+')'
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':fsaWieyBQvXwJbuEdINPpgzVRFMxHG.get('mode'),'stype':fsaWieyBQvXwJbuEdINPpgzVRFMxHG.get('stype'),'orderby':fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('orderby'),'ordernm':fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('ordernm'),'page':'1'}
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel='',img='',infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxcO,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxck,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxYq(fsaWieyBQvXwJbuEdINPpgzVRFMxHY)>0:xbmcplugin.endOfDirectory(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle)
 def dp_SubTitle_Group(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt): 
  for fsaWieyBQvXwJbuEdINPpgzVRFMxHG in fsaWieyBQvXwJbuEdINPpgzVRFMxlt:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt=fsaWieyBQvXwJbuEdINPpgzVRFMxHG.get('title')
   if fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('ordernm')!='-':
    fsaWieyBQvXwJbuEdINPpgzVRFMxSt+='  ('+fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('ordernm')+')'
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':fsaWieyBQvXwJbuEdINPpgzVRFMxHG.get('mode'),'genreCode':fsaWieyBQvXwJbuEdINPpgzVRFMxHG.get('genreCode'),'stype':fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('stype'),'orderby':fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('orderby'),'page':'1'}
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel='',img='',infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxcO,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxck,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxYq(fsaWieyBQvXwJbuEdINPpgzVRFMxlt)>0:xbmcplugin.endOfDirectory(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle)
 def dp_LiveChannel_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt):
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.SaveCredential(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_winCredential())
  fsaWieyBQvXwJbuEdINPpgzVRFMxHc =fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('stype')
  fsaWieyBQvXwJbuEdINPpgzVRFMxHA =fsaWieyBQvXwJbuEdINPpgzVRFMxcr(fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('page'))
  fsaWieyBQvXwJbuEdINPpgzVRFMxHT,fsaWieyBQvXwJbuEdINPpgzVRFMxHo=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.GetLiveChannelList(fsaWieyBQvXwJbuEdINPpgzVRFMxHc,fsaWieyBQvXwJbuEdINPpgzVRFMxHA)
  for fsaWieyBQvXwJbuEdINPpgzVRFMxHh in fsaWieyBQvXwJbuEdINPpgzVRFMxHT:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt =fsaWieyBQvXwJbuEdINPpgzVRFMxHh.get('title')
   fsaWieyBQvXwJbuEdINPpgzVRFMxSn =fsaWieyBQvXwJbuEdINPpgzVRFMxHh.get('channel')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHL =fsaWieyBQvXwJbuEdINPpgzVRFMxHh.get('thumbnail')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHm =fsaWieyBQvXwJbuEdINPpgzVRFMxHh.get('synopsis')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHD =fsaWieyBQvXwJbuEdINPpgzVRFMxHh.get('channelepg')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHU =fsaWieyBQvXwJbuEdINPpgzVRFMxHh.get('cast')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHj =fsaWieyBQvXwJbuEdINPpgzVRFMxHh.get('director')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHn =fsaWieyBQvXwJbuEdINPpgzVRFMxHh.get('info_genre')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHC =fsaWieyBQvXwJbuEdINPpgzVRFMxHh.get('year')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHO =fsaWieyBQvXwJbuEdINPpgzVRFMxHh.get('mpaa')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHr =fsaWieyBQvXwJbuEdINPpgzVRFMxHh.get('premiered')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHk={'mediatype':'episode','title':fsaWieyBQvXwJbuEdINPpgzVRFMxSt,'studio':fsaWieyBQvXwJbuEdINPpgzVRFMxSn,'cast':fsaWieyBQvXwJbuEdINPpgzVRFMxHU,'director':fsaWieyBQvXwJbuEdINPpgzVRFMxHj,'genre':fsaWieyBQvXwJbuEdINPpgzVRFMxHn,'plot':'%s\n%s\n%s\n\n%s'%(fsaWieyBQvXwJbuEdINPpgzVRFMxSn,fsaWieyBQvXwJbuEdINPpgzVRFMxSt,fsaWieyBQvXwJbuEdINPpgzVRFMxHD,fsaWieyBQvXwJbuEdINPpgzVRFMxHm),'year':fsaWieyBQvXwJbuEdINPpgzVRFMxHC,'mpaa':fsaWieyBQvXwJbuEdINPpgzVRFMxHO,'premiered':fsaWieyBQvXwJbuEdINPpgzVRFMxHr}
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':'LIVE','mediacode':fsaWieyBQvXwJbuEdINPpgzVRFMxHh.get('mediacode'),'stype':fsaWieyBQvXwJbuEdINPpgzVRFMxHc}
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSn,sublabel=fsaWieyBQvXwJbuEdINPpgzVRFMxSt,img=fsaWieyBQvXwJbuEdINPpgzVRFMxHL,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxHk,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxYl,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxHo:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['mode']='CHANNEL' 
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['stype']=fsaWieyBQvXwJbuEdINPpgzVRFMxHc 
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['page']=fsaWieyBQvXwJbuEdINPpgzVRFMxYK(fsaWieyBQvXwJbuEdINPpgzVRFMxHA+1)
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt='[B]%s >>[/B]'%'다음 페이지'
   fsaWieyBQvXwJbuEdINPpgzVRFMxql=fsaWieyBQvXwJbuEdINPpgzVRFMxYK(fsaWieyBQvXwJbuEdINPpgzVRFMxHA+1)
   fsaWieyBQvXwJbuEdINPpgzVRFMxSm=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel=fsaWieyBQvXwJbuEdINPpgzVRFMxql,img=fsaWieyBQvXwJbuEdINPpgzVRFMxSm,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxcO,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxck,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxYq(fsaWieyBQvXwJbuEdINPpgzVRFMxHT)>0:xbmcplugin.endOfDirectory(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle,cacheToDisc=fsaWieyBQvXwJbuEdINPpgzVRFMxYl)
 def dp_Program_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt):
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.SaveCredential(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_winCredential())
  fsaWieyBQvXwJbuEdINPpgzVRFMxqS =fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('stype')
  fsaWieyBQvXwJbuEdINPpgzVRFMxqH =fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('orderby')
  fsaWieyBQvXwJbuEdINPpgzVRFMxHA =fsaWieyBQvXwJbuEdINPpgzVRFMxcr(fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('page'))
  fsaWieyBQvXwJbuEdINPpgzVRFMxqK=fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('genreCode')
  if fsaWieyBQvXwJbuEdINPpgzVRFMxqK==fsaWieyBQvXwJbuEdINPpgzVRFMxcO:fsaWieyBQvXwJbuEdINPpgzVRFMxqK='all'
  fsaWieyBQvXwJbuEdINPpgzVRFMxqc,fsaWieyBQvXwJbuEdINPpgzVRFMxHo=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.GetProgramList(fsaWieyBQvXwJbuEdINPpgzVRFMxqS,fsaWieyBQvXwJbuEdINPpgzVRFMxqH,fsaWieyBQvXwJbuEdINPpgzVRFMxHA,fsaWieyBQvXwJbuEdINPpgzVRFMxqK)
  for fsaWieyBQvXwJbuEdINPpgzVRFMxqY in fsaWieyBQvXwJbuEdINPpgzVRFMxqc:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt =fsaWieyBQvXwJbuEdINPpgzVRFMxqY.get('title')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHL =fsaWieyBQvXwJbuEdINPpgzVRFMxqY.get('thumbnail')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHm =fsaWieyBQvXwJbuEdINPpgzVRFMxqY.get('synopsis')
   fsaWieyBQvXwJbuEdINPpgzVRFMxqG =fsaWieyBQvXwJbuEdINPpgzVRFMxqY.get('channel')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHU =fsaWieyBQvXwJbuEdINPpgzVRFMxqY.get('cast')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHj =fsaWieyBQvXwJbuEdINPpgzVRFMxqY.get('director')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHn=fsaWieyBQvXwJbuEdINPpgzVRFMxqY.get('info_genre')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHC =fsaWieyBQvXwJbuEdINPpgzVRFMxqY.get('year')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHr =fsaWieyBQvXwJbuEdINPpgzVRFMxqY.get('premiered')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHO =fsaWieyBQvXwJbuEdINPpgzVRFMxqY.get('mpaa')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHk={'mediatype':'tvshow','title':fsaWieyBQvXwJbuEdINPpgzVRFMxSt,'studio':fsaWieyBQvXwJbuEdINPpgzVRFMxqG,'cast':fsaWieyBQvXwJbuEdINPpgzVRFMxHU,'director':fsaWieyBQvXwJbuEdINPpgzVRFMxHj,'genre':fsaWieyBQvXwJbuEdINPpgzVRFMxHn,'year':fsaWieyBQvXwJbuEdINPpgzVRFMxHC,'premiered':fsaWieyBQvXwJbuEdINPpgzVRFMxHr,'mpaa':fsaWieyBQvXwJbuEdINPpgzVRFMxHO,'plot':fsaWieyBQvXwJbuEdINPpgzVRFMxHm}
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':'EPISODE','programcode':fsaWieyBQvXwJbuEdINPpgzVRFMxqY.get('program'),'page':'1'}
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel=fsaWieyBQvXwJbuEdINPpgzVRFMxqG,img=fsaWieyBQvXwJbuEdINPpgzVRFMxHL,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxHk,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxck,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxHo:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['mode'] ='PROGRAM' 
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['stype'] =fsaWieyBQvXwJbuEdINPpgzVRFMxqS
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['orderby'] =fsaWieyBQvXwJbuEdINPpgzVRFMxqH
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['page'] =fsaWieyBQvXwJbuEdINPpgzVRFMxYK(fsaWieyBQvXwJbuEdINPpgzVRFMxHA+1)
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['genreCode']=fsaWieyBQvXwJbuEdINPpgzVRFMxqK 
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt='[B]%s >>[/B]'%'다음 페이지'
   fsaWieyBQvXwJbuEdINPpgzVRFMxql=fsaWieyBQvXwJbuEdINPpgzVRFMxYK(fsaWieyBQvXwJbuEdINPpgzVRFMxHA+1)
   fsaWieyBQvXwJbuEdINPpgzVRFMxSm=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel=fsaWieyBQvXwJbuEdINPpgzVRFMxql,img=fsaWieyBQvXwJbuEdINPpgzVRFMxSm,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxcO,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxck,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxYq(fsaWieyBQvXwJbuEdINPpgzVRFMxqc)>0:xbmcplugin.endOfDirectory(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle,cacheToDisc=fsaWieyBQvXwJbuEdINPpgzVRFMxYl)
 def dp_Episode_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt):
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.SaveCredential(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_winCredential())
  fsaWieyBQvXwJbuEdINPpgzVRFMxqt=fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('programcode')
  fsaWieyBQvXwJbuEdINPpgzVRFMxHA =fsaWieyBQvXwJbuEdINPpgzVRFMxcr(fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('page'))
  fsaWieyBQvXwJbuEdINPpgzVRFMxqA,fsaWieyBQvXwJbuEdINPpgzVRFMxHo,fsaWieyBQvXwJbuEdINPpgzVRFMxqT=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.GetEpisodeList(fsaWieyBQvXwJbuEdINPpgzVRFMxqt,fsaWieyBQvXwJbuEdINPpgzVRFMxHA,orderby=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_winEpisodeOrderby())
  for fsaWieyBQvXwJbuEdINPpgzVRFMxqo in fsaWieyBQvXwJbuEdINPpgzVRFMxqA:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt =fsaWieyBQvXwJbuEdINPpgzVRFMxqo.get('title')
   fsaWieyBQvXwJbuEdINPpgzVRFMxql =fsaWieyBQvXwJbuEdINPpgzVRFMxqo.get('subtitle')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHL =fsaWieyBQvXwJbuEdINPpgzVRFMxqo.get('thumbnail')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHm =fsaWieyBQvXwJbuEdINPpgzVRFMxqo.get('synopsis')
   fsaWieyBQvXwJbuEdINPpgzVRFMxqh=fsaWieyBQvXwJbuEdINPpgzVRFMxqo.get('info_title')
   fsaWieyBQvXwJbuEdINPpgzVRFMxqL =fsaWieyBQvXwJbuEdINPpgzVRFMxqo.get('aired')
   fsaWieyBQvXwJbuEdINPpgzVRFMxqm =fsaWieyBQvXwJbuEdINPpgzVRFMxqo.get('studio')
   fsaWieyBQvXwJbuEdINPpgzVRFMxqD =fsaWieyBQvXwJbuEdINPpgzVRFMxqo.get('frequency')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHk={'mediatype':'episode','title':fsaWieyBQvXwJbuEdINPpgzVRFMxqh,'aired':fsaWieyBQvXwJbuEdINPpgzVRFMxqL,'studio':fsaWieyBQvXwJbuEdINPpgzVRFMxqm,'episode':fsaWieyBQvXwJbuEdINPpgzVRFMxqD,'plot':fsaWieyBQvXwJbuEdINPpgzVRFMxHm}
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':'VOD','mediacode':fsaWieyBQvXwJbuEdINPpgzVRFMxqo.get('episode'),'stype':'vod','programcode':fsaWieyBQvXwJbuEdINPpgzVRFMxqt,'title':fsaWieyBQvXwJbuEdINPpgzVRFMxSt,'thumbnail':fsaWieyBQvXwJbuEdINPpgzVRFMxHL}
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel=fsaWieyBQvXwJbuEdINPpgzVRFMxql,img=fsaWieyBQvXwJbuEdINPpgzVRFMxHL,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxHk,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxYl,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxHA==1:
   fsaWieyBQvXwJbuEdINPpgzVRFMxHk={'plot':'정렬순서를 변경합니다.'}
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD={}
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['mode'] ='ORDER_BY' 
   if fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_winEpisodeOrderby()=='desc':
    fsaWieyBQvXwJbuEdINPpgzVRFMxSt='정렬순서변경 : 최신화부터 -> 1회부터'
    fsaWieyBQvXwJbuEdINPpgzVRFMxSD['orderby']='asc'
   else:
    fsaWieyBQvXwJbuEdINPpgzVRFMxSt='정렬순서변경 : 1회부터 -> 최신화부터'
    fsaWieyBQvXwJbuEdINPpgzVRFMxSD['orderby']='desc'
   fsaWieyBQvXwJbuEdINPpgzVRFMxSm=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel='',img=fsaWieyBQvXwJbuEdINPpgzVRFMxSm,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxHk,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxYl,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD,isLink=fsaWieyBQvXwJbuEdINPpgzVRFMxck)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxHo:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['mode'] ='EPISODE' 
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['programcode']=fsaWieyBQvXwJbuEdINPpgzVRFMxqt
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['page'] =fsaWieyBQvXwJbuEdINPpgzVRFMxYK(fsaWieyBQvXwJbuEdINPpgzVRFMxHA+1)
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt='[B]%s >>[/B]'%'다음 페이지'
   fsaWieyBQvXwJbuEdINPpgzVRFMxql=fsaWieyBQvXwJbuEdINPpgzVRFMxYK(fsaWieyBQvXwJbuEdINPpgzVRFMxHA+1)
   fsaWieyBQvXwJbuEdINPpgzVRFMxSm=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel=fsaWieyBQvXwJbuEdINPpgzVRFMxql,img=fsaWieyBQvXwJbuEdINPpgzVRFMxSm,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxcO,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxck,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxYq(fsaWieyBQvXwJbuEdINPpgzVRFMxqA)>0:xbmcplugin.endOfDirectory(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle,cacheToDisc=fsaWieyBQvXwJbuEdINPpgzVRFMxck)
 def dp_setEpOrderby(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt):
  fsaWieyBQvXwJbuEdINPpgzVRFMxqH =fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('orderby')
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.set_winEpisodeOrderby(fsaWieyBQvXwJbuEdINPpgzVRFMxqH)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt):
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.SaveCredential(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_winCredential())
  fsaWieyBQvXwJbuEdINPpgzVRFMxqS =fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('stype')
  fsaWieyBQvXwJbuEdINPpgzVRFMxqH =fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('orderby')
  fsaWieyBQvXwJbuEdINPpgzVRFMxHA=fsaWieyBQvXwJbuEdINPpgzVRFMxcr(fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('page'))
  fsaWieyBQvXwJbuEdINPpgzVRFMxqU,fsaWieyBQvXwJbuEdINPpgzVRFMxHo=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.GetMovieList(fsaWieyBQvXwJbuEdINPpgzVRFMxqS,fsaWieyBQvXwJbuEdINPpgzVRFMxqH,fsaWieyBQvXwJbuEdINPpgzVRFMxHA)
  for fsaWieyBQvXwJbuEdINPpgzVRFMxqj in fsaWieyBQvXwJbuEdINPpgzVRFMxqU:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt =fsaWieyBQvXwJbuEdINPpgzVRFMxqj.get('title')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHL =fsaWieyBQvXwJbuEdINPpgzVRFMxqj.get('thumbnail')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHm =fsaWieyBQvXwJbuEdINPpgzVRFMxqj.get('synopsis')
   fsaWieyBQvXwJbuEdINPpgzVRFMxqh =fsaWieyBQvXwJbuEdINPpgzVRFMxqj.get('info_title')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHC =fsaWieyBQvXwJbuEdINPpgzVRFMxqj.get('year')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHU =fsaWieyBQvXwJbuEdINPpgzVRFMxqj.get('cast')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHj =fsaWieyBQvXwJbuEdINPpgzVRFMxqj.get('director')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHn =fsaWieyBQvXwJbuEdINPpgzVRFMxqj.get('info_genre')
   fsaWieyBQvXwJbuEdINPpgzVRFMxqn =fsaWieyBQvXwJbuEdINPpgzVRFMxqj.get('duration')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHr =fsaWieyBQvXwJbuEdINPpgzVRFMxqj.get('premiered')
   fsaWieyBQvXwJbuEdINPpgzVRFMxqm =fsaWieyBQvXwJbuEdINPpgzVRFMxqj.get('studio')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHO =fsaWieyBQvXwJbuEdINPpgzVRFMxqj.get('mpaa')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHk={'mediatype':'movie','title':fsaWieyBQvXwJbuEdINPpgzVRFMxqh,'year':fsaWieyBQvXwJbuEdINPpgzVRFMxHC,'cast':fsaWieyBQvXwJbuEdINPpgzVRFMxHU,'director':fsaWieyBQvXwJbuEdINPpgzVRFMxHj,'genre':fsaWieyBQvXwJbuEdINPpgzVRFMxHn,'duration':fsaWieyBQvXwJbuEdINPpgzVRFMxqn,'premiered':fsaWieyBQvXwJbuEdINPpgzVRFMxHr,'studio':fsaWieyBQvXwJbuEdINPpgzVRFMxqm,'mpaa':fsaWieyBQvXwJbuEdINPpgzVRFMxHO,'plot':fsaWieyBQvXwJbuEdINPpgzVRFMxHm}
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':'MOVIE','mediacode':fsaWieyBQvXwJbuEdINPpgzVRFMxqj.get('moviecode'),'stype':'movie','title':fsaWieyBQvXwJbuEdINPpgzVRFMxSt,'thumbnail':fsaWieyBQvXwJbuEdINPpgzVRFMxHL}
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel='',img=fsaWieyBQvXwJbuEdINPpgzVRFMxHL,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxHk,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxYl,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxHo:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD={}
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['mode'] ='MOVIE_SUB' 
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['orderby']=fsaWieyBQvXwJbuEdINPpgzVRFMxqH
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['stype'] =fsaWieyBQvXwJbuEdINPpgzVRFMxqS
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['page'] =fsaWieyBQvXwJbuEdINPpgzVRFMxYK(fsaWieyBQvXwJbuEdINPpgzVRFMxHA+1)
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt='[B]%s >>[/B]'%'다음 페이지'
   fsaWieyBQvXwJbuEdINPpgzVRFMxql=fsaWieyBQvXwJbuEdINPpgzVRFMxYK(fsaWieyBQvXwJbuEdINPpgzVRFMxHA+1)
   fsaWieyBQvXwJbuEdINPpgzVRFMxSm=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel=fsaWieyBQvXwJbuEdINPpgzVRFMxql,img=fsaWieyBQvXwJbuEdINPpgzVRFMxSm,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxcO,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxck,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxYq(fsaWieyBQvXwJbuEdINPpgzVRFMxqU)>0:xbmcplugin.endOfDirectory(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle,cacheToDisc=fsaWieyBQvXwJbuEdINPpgzVRFMxYl)
 def dp_Strm_Make(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt):
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.addon_noti('aa')
 def dp_Search_Group(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt):
  for fsaWieyBQvXwJbuEdINPpgzVRFMxHG in fsaWieyBQvXwJbuEdINPpgzVRFMxlc:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt=fsaWieyBQvXwJbuEdINPpgzVRFMxHG.get('title')
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':fsaWieyBQvXwJbuEdINPpgzVRFMxHG.get('mode'),'stype':fsaWieyBQvXwJbuEdINPpgzVRFMxHG.get('stype'),'page':'1'}
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel='',img='',infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxcO,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxck,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxYq(fsaWieyBQvXwJbuEdINPpgzVRFMxlc)>0:xbmcplugin.endOfDirectory(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle)
 def dp_Search_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt):
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.SaveCredential(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_winCredential())
  fsaWieyBQvXwJbuEdINPpgzVRFMxHA =fsaWieyBQvXwJbuEdINPpgzVRFMxcr(fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('page'))
  fsaWieyBQvXwJbuEdINPpgzVRFMxHc =fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('stype')
  if 'search_key' in fsaWieyBQvXwJbuEdINPpgzVRFMxHt:
   fsaWieyBQvXwJbuEdINPpgzVRFMxqC=fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('search_key')
  else:
   fsaWieyBQvXwJbuEdINPpgzVRFMxqC=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not fsaWieyBQvXwJbuEdINPpgzVRFMxqC:
    xbmcplugin.endOfDirectory(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle)
    return
  fsaWieyBQvXwJbuEdINPpgzVRFMxqO,fsaWieyBQvXwJbuEdINPpgzVRFMxHo=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.GetSearchList(fsaWieyBQvXwJbuEdINPpgzVRFMxqC,fsaWieyBQvXwJbuEdINPpgzVRFMxHA,fsaWieyBQvXwJbuEdINPpgzVRFMxHc)
  for fsaWieyBQvXwJbuEdINPpgzVRFMxqr in fsaWieyBQvXwJbuEdINPpgzVRFMxqO:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt =fsaWieyBQvXwJbuEdINPpgzVRFMxqr.get('title')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHL =fsaWieyBQvXwJbuEdINPpgzVRFMxqr.get('thumbnail')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHm =fsaWieyBQvXwJbuEdINPpgzVRFMxqr.get('synopsis')
   fsaWieyBQvXwJbuEdINPpgzVRFMxqk =fsaWieyBQvXwJbuEdINPpgzVRFMxqr.get('program')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHU =fsaWieyBQvXwJbuEdINPpgzVRFMxqr.get('cast')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHj =fsaWieyBQvXwJbuEdINPpgzVRFMxqr.get('director')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHn=fsaWieyBQvXwJbuEdINPpgzVRFMxqr.get('info_genre')
   fsaWieyBQvXwJbuEdINPpgzVRFMxqn =fsaWieyBQvXwJbuEdINPpgzVRFMxqr.get('duration')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHO =fsaWieyBQvXwJbuEdINPpgzVRFMxqr.get('mpaa')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHC =fsaWieyBQvXwJbuEdINPpgzVRFMxqr.get('year')
   fsaWieyBQvXwJbuEdINPpgzVRFMxqL =fsaWieyBQvXwJbuEdINPpgzVRFMxqr.get('aired')
   fsaWieyBQvXwJbuEdINPpgzVRFMxHk={'mediatype':'tvshow' if fsaWieyBQvXwJbuEdINPpgzVRFMxHc=='vod' else 'movie','title':fsaWieyBQvXwJbuEdINPpgzVRFMxSt,'cast':fsaWieyBQvXwJbuEdINPpgzVRFMxHU,'director':fsaWieyBQvXwJbuEdINPpgzVRFMxHj,'genre':fsaWieyBQvXwJbuEdINPpgzVRFMxHn,'duration':fsaWieyBQvXwJbuEdINPpgzVRFMxqn,'mpaa':fsaWieyBQvXwJbuEdINPpgzVRFMxHO,'year':fsaWieyBQvXwJbuEdINPpgzVRFMxHC,'aired':fsaWieyBQvXwJbuEdINPpgzVRFMxqL,'plot':'%s\n\n%s'%(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,fsaWieyBQvXwJbuEdINPpgzVRFMxHm)}
   if fsaWieyBQvXwJbuEdINPpgzVRFMxHc=='vod':
    fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':'EPISODE','programcode':fsaWieyBQvXwJbuEdINPpgzVRFMxqr.get('program'),'page':'1'}
    fsaWieyBQvXwJbuEdINPpgzVRFMxSU=fsaWieyBQvXwJbuEdINPpgzVRFMxck
   else:
    fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':'MOVIE','mediacode':fsaWieyBQvXwJbuEdINPpgzVRFMxqr.get('movie'),'stype':'movie','title':fsaWieyBQvXwJbuEdINPpgzVRFMxSt,'thumbnail':fsaWieyBQvXwJbuEdINPpgzVRFMxHL}
    fsaWieyBQvXwJbuEdINPpgzVRFMxSU=fsaWieyBQvXwJbuEdINPpgzVRFMxYl
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel='',img=fsaWieyBQvXwJbuEdINPpgzVRFMxHL,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxHk,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxSU,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxHo:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['mode'] ='SEARCH' 
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['search_key']=fsaWieyBQvXwJbuEdINPpgzVRFMxqC
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD['page'] =fsaWieyBQvXwJbuEdINPpgzVRFMxYK(fsaWieyBQvXwJbuEdINPpgzVRFMxHA+1)
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt='[B]%s >>[/B]'%'다음 페이지'
   fsaWieyBQvXwJbuEdINPpgzVRFMxql=fsaWieyBQvXwJbuEdINPpgzVRFMxYK(fsaWieyBQvXwJbuEdINPpgzVRFMxHA+1)
   fsaWieyBQvXwJbuEdINPpgzVRFMxSm=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel=fsaWieyBQvXwJbuEdINPpgzVRFMxql,img=fsaWieyBQvXwJbuEdINPpgzVRFMxSm,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxcO,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxck,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  xbmcplugin.endOfDirectory(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle,cacheToDisc=fsaWieyBQvXwJbuEdINPpgzVRFMxYl)
 def Delete_Watched_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHc):
  try:
   fsaWieyBQvXwJbuEdINPpgzVRFMxKS=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fsaWieyBQvXwJbuEdINPpgzVRFMxHc))
   fp=fsaWieyBQvXwJbuEdINPpgzVRFMxYc(fsaWieyBQvXwJbuEdINPpgzVRFMxKS,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   fsaWieyBQvXwJbuEdINPpgzVRFMxcO
 def dp_WatchList_Delete(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt):
  fsaWieyBQvXwJbuEdINPpgzVRFMxHc=fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('stype')
  fsaWieyBQvXwJbuEdINPpgzVRFMxlD=xbmcgui.Dialog()
  fsaWieyBQvXwJbuEdINPpgzVRFMxHl=fsaWieyBQvXwJbuEdINPpgzVRFMxlD.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if fsaWieyBQvXwJbuEdINPpgzVRFMxHl==fsaWieyBQvXwJbuEdINPpgzVRFMxYl:sys.exit()
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.Delete_Watched_List(fsaWieyBQvXwJbuEdINPpgzVRFMxHc)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHc):
  try:
   fsaWieyBQvXwJbuEdINPpgzVRFMxKS=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fsaWieyBQvXwJbuEdINPpgzVRFMxHc))
   fp=fsaWieyBQvXwJbuEdINPpgzVRFMxYc(fsaWieyBQvXwJbuEdINPpgzVRFMxKS,'r',-1,'utf-8')
   fsaWieyBQvXwJbuEdINPpgzVRFMxKH=fp.readlines()
   fp.close()
  except:
   fsaWieyBQvXwJbuEdINPpgzVRFMxKH=[]
  return fsaWieyBQvXwJbuEdINPpgzVRFMxKH
 def Save_Watched_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHc,fsaWieyBQvXwJbuEdINPpgzVRFMxlL):
  try:
   fsaWieyBQvXwJbuEdINPpgzVRFMxKS=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%fsaWieyBQvXwJbuEdINPpgzVRFMxHc))
   fsaWieyBQvXwJbuEdINPpgzVRFMxKq=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.Load_Watched_List(fsaWieyBQvXwJbuEdINPpgzVRFMxHc) 
   fp=fsaWieyBQvXwJbuEdINPpgzVRFMxYc(fsaWieyBQvXwJbuEdINPpgzVRFMxKS,'w',-1,'utf-8')
   fsaWieyBQvXwJbuEdINPpgzVRFMxKc=urllib.parse.urlencode(fsaWieyBQvXwJbuEdINPpgzVRFMxlL)
   fsaWieyBQvXwJbuEdINPpgzVRFMxKc=fsaWieyBQvXwJbuEdINPpgzVRFMxKc+'\n'
   fp.write(fsaWieyBQvXwJbuEdINPpgzVRFMxKc)
   fsaWieyBQvXwJbuEdINPpgzVRFMxKY=0
   for fsaWieyBQvXwJbuEdINPpgzVRFMxKG in fsaWieyBQvXwJbuEdINPpgzVRFMxKq:
    fsaWieyBQvXwJbuEdINPpgzVRFMxKt=fsaWieyBQvXwJbuEdINPpgzVRFMxYH(urllib.parse.parse_qsl(fsaWieyBQvXwJbuEdINPpgzVRFMxKG))
    fsaWieyBQvXwJbuEdINPpgzVRFMxKA=fsaWieyBQvXwJbuEdINPpgzVRFMxlL.get('code').strip()
    fsaWieyBQvXwJbuEdINPpgzVRFMxKT=fsaWieyBQvXwJbuEdINPpgzVRFMxKt.get('code').strip()
    if fsaWieyBQvXwJbuEdINPpgzVRFMxHc=='vod' and fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_settings_direct_replay()==fsaWieyBQvXwJbuEdINPpgzVRFMxck:
     fsaWieyBQvXwJbuEdINPpgzVRFMxKA=fsaWieyBQvXwJbuEdINPpgzVRFMxlL.get('videoid').strip()
     fsaWieyBQvXwJbuEdINPpgzVRFMxKT=fsaWieyBQvXwJbuEdINPpgzVRFMxKt.get('videoid').strip()if fsaWieyBQvXwJbuEdINPpgzVRFMxKT!=fsaWieyBQvXwJbuEdINPpgzVRFMxcO else '-'
    if fsaWieyBQvXwJbuEdINPpgzVRFMxKA!=fsaWieyBQvXwJbuEdINPpgzVRFMxKT:
     fp.write(fsaWieyBQvXwJbuEdINPpgzVRFMxKG)
     fsaWieyBQvXwJbuEdINPpgzVRFMxKY+=1
     if fsaWieyBQvXwJbuEdINPpgzVRFMxKY>=50:break
   fp.close()
  except:
   fsaWieyBQvXwJbuEdINPpgzVRFMxcO
 def dp_Watch_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt):
  fsaWieyBQvXwJbuEdINPpgzVRFMxHc =fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('stype')
  fsaWieyBQvXwJbuEdINPpgzVRFMxSK=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_settings_direct_replay()
  if fsaWieyBQvXwJbuEdINPpgzVRFMxHc=='-':
   for fsaWieyBQvXwJbuEdINPpgzVRFMxHG in fsaWieyBQvXwJbuEdINPpgzVRFMxlK:
    fsaWieyBQvXwJbuEdINPpgzVRFMxSt=fsaWieyBQvXwJbuEdINPpgzVRFMxHG.get('title')
    fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':fsaWieyBQvXwJbuEdINPpgzVRFMxHG.get('mode'),'stype':fsaWieyBQvXwJbuEdINPpgzVRFMxHG.get('stype')}
    fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel='',img='',infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxcO,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxck,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
   if fsaWieyBQvXwJbuEdINPpgzVRFMxYq(fsaWieyBQvXwJbuEdINPpgzVRFMxlK)>0:xbmcplugin.endOfDirectory(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle)
  else:
   fsaWieyBQvXwJbuEdINPpgzVRFMxKo=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.Load_Watched_List(fsaWieyBQvXwJbuEdINPpgzVRFMxHc)
   for fsaWieyBQvXwJbuEdINPpgzVRFMxKh in fsaWieyBQvXwJbuEdINPpgzVRFMxKo:
    fsaWieyBQvXwJbuEdINPpgzVRFMxKL=fsaWieyBQvXwJbuEdINPpgzVRFMxYH(urllib.parse.parse_qsl(fsaWieyBQvXwJbuEdINPpgzVRFMxKh))
    fsaWieyBQvXwJbuEdINPpgzVRFMxKm =fsaWieyBQvXwJbuEdINPpgzVRFMxKL.get('code').strip()
    fsaWieyBQvXwJbuEdINPpgzVRFMxSt =fsaWieyBQvXwJbuEdINPpgzVRFMxKL.get('title').strip()
    fsaWieyBQvXwJbuEdINPpgzVRFMxHL=fsaWieyBQvXwJbuEdINPpgzVRFMxKL.get('img').strip()
    fsaWieyBQvXwJbuEdINPpgzVRFMxKD =fsaWieyBQvXwJbuEdINPpgzVRFMxKL.get('videoid').strip()
    try:
     fsaWieyBQvXwJbuEdINPpgzVRFMxHL=fsaWieyBQvXwJbuEdINPpgzVRFMxHL.replace('\'','\"')
     fsaWieyBQvXwJbuEdINPpgzVRFMxHL=json.loads(fsaWieyBQvXwJbuEdINPpgzVRFMxHL)
    except:
     fsaWieyBQvXwJbuEdINPpgzVRFMxcO
    fsaWieyBQvXwJbuEdINPpgzVRFMxHk={}
    fsaWieyBQvXwJbuEdINPpgzVRFMxHk['plot']=fsaWieyBQvXwJbuEdINPpgzVRFMxSt
    if fsaWieyBQvXwJbuEdINPpgzVRFMxHc=='vod':
     if fsaWieyBQvXwJbuEdINPpgzVRFMxSK==fsaWieyBQvXwJbuEdINPpgzVRFMxYl or fsaWieyBQvXwJbuEdINPpgzVRFMxKD==fsaWieyBQvXwJbuEdINPpgzVRFMxcO:
      fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':'EPISODE','programcode':fsaWieyBQvXwJbuEdINPpgzVRFMxKm,'page':'1'}
      fsaWieyBQvXwJbuEdINPpgzVRFMxSU=fsaWieyBQvXwJbuEdINPpgzVRFMxck
     else:
      fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':'VOD','mediacode':fsaWieyBQvXwJbuEdINPpgzVRFMxKD,'stype':'vod','programcode':fsaWieyBQvXwJbuEdINPpgzVRFMxKm,'title':fsaWieyBQvXwJbuEdINPpgzVRFMxSt,'thumbnail':fsaWieyBQvXwJbuEdINPpgzVRFMxHL}
      fsaWieyBQvXwJbuEdINPpgzVRFMxSU=fsaWieyBQvXwJbuEdINPpgzVRFMxYl
    else:
     fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':'MOVIE','mediacode':fsaWieyBQvXwJbuEdINPpgzVRFMxKm,'stype':'movie','title':fsaWieyBQvXwJbuEdINPpgzVRFMxSt,'thumbnail':fsaWieyBQvXwJbuEdINPpgzVRFMxHL}
     fsaWieyBQvXwJbuEdINPpgzVRFMxSU=fsaWieyBQvXwJbuEdINPpgzVRFMxYl
    fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel='',img=fsaWieyBQvXwJbuEdINPpgzVRFMxHL,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxHk,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxSU,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
   fsaWieyBQvXwJbuEdINPpgzVRFMxHk={'plot':'시청목록을 삭제합니다.'}
   fsaWieyBQvXwJbuEdINPpgzVRFMxSt='*** 시청목록 삭제 ***'
   fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'mode':'MYVIEW_REMOVE','stype':fsaWieyBQvXwJbuEdINPpgzVRFMxHc}
   fsaWieyBQvXwJbuEdINPpgzVRFMxSm=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.add_dir(fsaWieyBQvXwJbuEdINPpgzVRFMxSt,sublabel='',img=fsaWieyBQvXwJbuEdINPpgzVRFMxSm,infoLabels=fsaWieyBQvXwJbuEdINPpgzVRFMxHk,isFolder=fsaWieyBQvXwJbuEdINPpgzVRFMxYl,params=fsaWieyBQvXwJbuEdINPpgzVRFMxSD,isLink=fsaWieyBQvXwJbuEdINPpgzVRFMxck)
   xbmcplugin.endOfDirectory(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle,cacheToDisc=fsaWieyBQvXwJbuEdINPpgzVRFMxYl)
 def play_VIDEO(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt):
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.SaveCredential(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_winCredential())
  fsaWieyBQvXwJbuEdINPpgzVRFMxKU =fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('mediacode')
  fsaWieyBQvXwJbuEdINPpgzVRFMxHc =fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('stype')
  fsaWieyBQvXwJbuEdINPpgzVRFMxKj =fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('pvrmode')
  fsaWieyBQvXwJbuEdINPpgzVRFMxKn=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.get_selQuality(fsaWieyBQvXwJbuEdINPpgzVRFMxHc)
  fsaWieyBQvXwJbuEdINPpgzVRFMxKC,fsaWieyBQvXwJbuEdINPpgzVRFMxKO=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.GetBroadURL(fsaWieyBQvXwJbuEdINPpgzVRFMxKU,fsaWieyBQvXwJbuEdINPpgzVRFMxKn,fsaWieyBQvXwJbuEdINPpgzVRFMxHc,fsaWieyBQvXwJbuEdINPpgzVRFMxKj)
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.addon_log('qt, stype, url : %s - %s - %s'%(fsaWieyBQvXwJbuEdINPpgzVRFMxYK(fsaWieyBQvXwJbuEdINPpgzVRFMxKn),fsaWieyBQvXwJbuEdINPpgzVRFMxHc,fsaWieyBQvXwJbuEdINPpgzVRFMxKC))
  if fsaWieyBQvXwJbuEdINPpgzVRFMxKC=='':
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.addon_noti(__language__(30908).encode('utf8'))
   return
  fsaWieyBQvXwJbuEdINPpgzVRFMxKr =fsaWieyBQvXwJbuEdINPpgzVRFMxKC.find('Policy=')
  if fsaWieyBQvXwJbuEdINPpgzVRFMxKr!=-1:
   fsaWieyBQvXwJbuEdINPpgzVRFMxKk =fsaWieyBQvXwJbuEdINPpgzVRFMxKC.split('?')[0]
   fsaWieyBQvXwJbuEdINPpgzVRFMxcl=fsaWieyBQvXwJbuEdINPpgzVRFMxYH(urllib.parse.parse_qsl(urllib.parse.urlsplit(fsaWieyBQvXwJbuEdINPpgzVRFMxKC).query))
   fsaWieyBQvXwJbuEdINPpgzVRFMxcl=urllib.parse.urlencode(fsaWieyBQvXwJbuEdINPpgzVRFMxcl)
   fsaWieyBQvXwJbuEdINPpgzVRFMxcl=fsaWieyBQvXwJbuEdINPpgzVRFMxcl.replace('&',';')
   fsaWieyBQvXwJbuEdINPpgzVRFMxcl=fsaWieyBQvXwJbuEdINPpgzVRFMxcl.replace('Policy','CloudFront-Policy')
   fsaWieyBQvXwJbuEdINPpgzVRFMxcl=fsaWieyBQvXwJbuEdINPpgzVRFMxcl.replace('Signature','CloudFront-Signature')
   fsaWieyBQvXwJbuEdINPpgzVRFMxcl=fsaWieyBQvXwJbuEdINPpgzVRFMxcl.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   fsaWieyBQvXwJbuEdINPpgzVRFMxcS='%s|Cookie=%s'%(fsaWieyBQvXwJbuEdINPpgzVRFMxKk,fsaWieyBQvXwJbuEdINPpgzVRFMxcl)
  else:
   fsaWieyBQvXwJbuEdINPpgzVRFMxcS=fsaWieyBQvXwJbuEdINPpgzVRFMxKC
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.addon_log(fsaWieyBQvXwJbuEdINPpgzVRFMxcS)
  fsaWieyBQvXwJbuEdINPpgzVRFMxcH=xbmcgui.ListItem(path=fsaWieyBQvXwJbuEdINPpgzVRFMxcS)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxKO!='':
   fsaWieyBQvXwJbuEdINPpgzVRFMxcq=fsaWieyBQvXwJbuEdINPpgzVRFMxKO
   fsaWieyBQvXwJbuEdINPpgzVRFMxcK ='https://cj.drmkeyserver.com/widevine_license'
   fsaWieyBQvXwJbuEdINPpgzVRFMxcY ='mpd'
   fsaWieyBQvXwJbuEdINPpgzVRFMxcG ='com.widevine.alpha'
   fsaWieyBQvXwJbuEdINPpgzVRFMxct =inputstreamhelper.Helper(fsaWieyBQvXwJbuEdINPpgzVRFMxcY,drm='widevine')
   if fsaWieyBQvXwJbuEdINPpgzVRFMxct.check_inputstream():
    fsaWieyBQvXwJbuEdINPpgzVRFMxcA={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%fsaWieyBQvXwJbuEdINPpgzVRFMxKU,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.USER_AGENT,'AcquireLicenseAssertion':fsaWieyBQvXwJbuEdINPpgzVRFMxcq,'Host':'cj.drmkeyserver.com'}
    fsaWieyBQvXwJbuEdINPpgzVRFMxcT=fsaWieyBQvXwJbuEdINPpgzVRFMxcK+'|'+urllib.parse.urlencode(fsaWieyBQvXwJbuEdINPpgzVRFMxcA)+'|R{SSM}|'
    fsaWieyBQvXwJbuEdINPpgzVRFMxcH.setProperty('inputstream',fsaWieyBQvXwJbuEdINPpgzVRFMxct.inputstream_addon)
    fsaWieyBQvXwJbuEdINPpgzVRFMxcH.setProperty('inputstream.adaptive.manifest_type',fsaWieyBQvXwJbuEdINPpgzVRFMxcY)
    fsaWieyBQvXwJbuEdINPpgzVRFMxcH.setProperty('inputstream.adaptive.license_type',fsaWieyBQvXwJbuEdINPpgzVRFMxcG)
    fsaWieyBQvXwJbuEdINPpgzVRFMxcH.setProperty('inputstream.adaptive.license_key',fsaWieyBQvXwJbuEdINPpgzVRFMxcT)
    fsaWieyBQvXwJbuEdINPpgzVRFMxcH.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.USER_AGENT))
  xbmcplugin.setResolvedUrl(fsaWieyBQvXwJbuEdINPpgzVRFMxlT._addon_handle,fsaWieyBQvXwJbuEdINPpgzVRFMxck,fsaWieyBQvXwJbuEdINPpgzVRFMxcH)
  try:
   if fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('mode')in['VOD','MOVIE']and fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('title'):
    fsaWieyBQvXwJbuEdINPpgzVRFMxSD={'code':fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('programcode')if fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('mode')=='VOD' else fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('mediacode'),'img':fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('thumbnail'),'title':fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('title'),'videoid':fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('mediacode')}
    fsaWieyBQvXwJbuEdINPpgzVRFMxlT.Save_Watched_List(fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('stype'),fsaWieyBQvXwJbuEdINPpgzVRFMxSD)
  except:
   fsaWieyBQvXwJbuEdINPpgzVRFMxcO
 def logout(fsaWieyBQvXwJbuEdINPpgzVRFMxlT):
  fsaWieyBQvXwJbuEdINPpgzVRFMxlD=xbmcgui.Dialog()
  fsaWieyBQvXwJbuEdINPpgzVRFMxHl=fsaWieyBQvXwJbuEdINPpgzVRFMxlD.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if fsaWieyBQvXwJbuEdINPpgzVRFMxHl==fsaWieyBQvXwJbuEdINPpgzVRFMxYl:sys.exit()
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.wininfo_clear()
  if os.path.isfile(fsaWieyBQvXwJbuEdINPpgzVRFMxlA):os.remove(fsaWieyBQvXwJbuEdINPpgzVRFMxlA)
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(fsaWieyBQvXwJbuEdINPpgzVRFMxlT):
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc=xbmcgui.Window(10000)
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_TOKEN','')
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_USERINFO','')
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_UUID','')
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_LOGINTIME','')
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_MAINTOKEN','')
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_COOKIEKEY','')
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(fsaWieyBQvXwJbuEdINPpgzVRFMxlT):
  fsaWieyBQvXwJbuEdINPpgzVRFMxco =fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.Get_Now_Datetime()
  fsaWieyBQvXwJbuEdINPpgzVRFMxch=fsaWieyBQvXwJbuEdINPpgzVRFMxco+datetime.timedelta(days=fsaWieyBQvXwJbuEdINPpgzVRFMxcr(__addon__.getSetting('cache_ttl')))
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc=xbmcgui.Window(10000)
  fsaWieyBQvXwJbuEdINPpgzVRFMxcL={'tving_token':fsaWieyBQvXwJbuEdINPpgzVRFMxSc.getProperty('TVING_M_TOKEN'),'tving_userinfo':fsaWieyBQvXwJbuEdINPpgzVRFMxSc.getProperty('TVING_M_USERINFO'),'tving_uuid':fsaWieyBQvXwJbuEdINPpgzVRFMxSc.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':fsaWieyBQvXwJbuEdINPpgzVRFMxch.strftime('%Y-%m-%d'),'tving_maintoken':fsaWieyBQvXwJbuEdINPpgzVRFMxSc.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':fsaWieyBQvXwJbuEdINPpgzVRFMxSc.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':fsaWieyBQvXwJbuEdINPpgzVRFMxSc.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=fsaWieyBQvXwJbuEdINPpgzVRFMxYc(fsaWieyBQvXwJbuEdINPpgzVRFMxlA,'w',-1,'utf-8')
   json.dump(fsaWieyBQvXwJbuEdINPpgzVRFMxcL,fp)
   fp.close()
  except fsaWieyBQvXwJbuEdINPpgzVRFMxYG as exception:
   fsaWieyBQvXwJbuEdINPpgzVRFMxYt(exception)
 def cookiefile_check(fsaWieyBQvXwJbuEdINPpgzVRFMxlT):
  fsaWieyBQvXwJbuEdINPpgzVRFMxcL={}
  try: 
   fp=fsaWieyBQvXwJbuEdINPpgzVRFMxYc(fsaWieyBQvXwJbuEdINPpgzVRFMxlA,'r',-1,'utf-8')
   fsaWieyBQvXwJbuEdINPpgzVRFMxcL= json.load(fp)
   fp.close()
  except fsaWieyBQvXwJbuEdINPpgzVRFMxYG as exception:
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.wininfo_clear()
   return fsaWieyBQvXwJbuEdINPpgzVRFMxYl
  fsaWieyBQvXwJbuEdINPpgzVRFMxSC =__addon__.getSetting('id')
  fsaWieyBQvXwJbuEdINPpgzVRFMxSO =__addon__.getSetting('pw')
  fsaWieyBQvXwJbuEdINPpgzVRFMxcm=__addon__.getSetting('login_type')
  fsaWieyBQvXwJbuEdINPpgzVRFMxcD =__addon__.getSetting('selected_profile')
  fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_id']=base64.standard_b64decode(fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_id']).decode('utf-8')
  fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_pw']=base64.standard_b64decode(fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_pw']).decode('utf-8')
  try:
   fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_profile']
  except:
   fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_profile']='0'
  if fsaWieyBQvXwJbuEdINPpgzVRFMxSC!=fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_id']or fsaWieyBQvXwJbuEdINPpgzVRFMxSO!=fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_pw']or fsaWieyBQvXwJbuEdINPpgzVRFMxcm!=fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_logintype']or fsaWieyBQvXwJbuEdINPpgzVRFMxcD!=fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_profile']:
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.wininfo_clear()
   return fsaWieyBQvXwJbuEdINPpgzVRFMxYl
  fsaWieyBQvXwJbuEdINPpgzVRFMxHS =fsaWieyBQvXwJbuEdINPpgzVRFMxcr(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  fsaWieyBQvXwJbuEdINPpgzVRFMxcU=fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_limitdate']
  fsaWieyBQvXwJbuEdINPpgzVRFMxHq =fsaWieyBQvXwJbuEdINPpgzVRFMxcr(re.sub('-','',fsaWieyBQvXwJbuEdINPpgzVRFMxcU))
  if fsaWieyBQvXwJbuEdINPpgzVRFMxHq<fsaWieyBQvXwJbuEdINPpgzVRFMxHS:
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.wininfo_clear()
   return fsaWieyBQvXwJbuEdINPpgzVRFMxYl
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc=xbmcgui.Window(10000)
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_TOKEN',fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_token'])
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_USERINFO',fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_userinfo'])
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_UUID',fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_uuid'])
  fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_LOGINTIME',fsaWieyBQvXwJbuEdINPpgzVRFMxcU)
  try:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_MAINTOKEN',fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_maintoken'])
   fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_COOKIEKEY',fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_cookiekey'])
   fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_LOCKKEY',fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_lockkey'])
  except:
   fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_MAINTOKEN',fsaWieyBQvXwJbuEdINPpgzVRFMxcL['tving_token'])
   fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_COOKIEKEY','Y')
   fsaWieyBQvXwJbuEdINPpgzVRFMxSc.setProperty('TVING_M_LOCKKEY','N')
  return fsaWieyBQvXwJbuEdINPpgzVRFMxck
 def dp_Global_Search(fsaWieyBQvXwJbuEdINPpgzVRFMxlT,fsaWieyBQvXwJbuEdINPpgzVRFMxHt):
  fsaWieyBQvXwJbuEdINPpgzVRFMxcj=fsaWieyBQvXwJbuEdINPpgzVRFMxHt.get('mode')
  if fsaWieyBQvXwJbuEdINPpgzVRFMxcj=='TOTAL_SEARCH':
   fsaWieyBQvXwJbuEdINPpgzVRFMxcn='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   fsaWieyBQvXwJbuEdINPpgzVRFMxcn='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(fsaWieyBQvXwJbuEdINPpgzVRFMxcn)
 def tving_main(fsaWieyBQvXwJbuEdINPpgzVRFMxlT):
  fsaWieyBQvXwJbuEdINPpgzVRFMxcj=fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params.get('mode',fsaWieyBQvXwJbuEdINPpgzVRFMxcO)
  if fsaWieyBQvXwJbuEdINPpgzVRFMxcj=='LOGOUT':
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.logout()
   return
  fsaWieyBQvXwJbuEdINPpgzVRFMxlT.login_main()
  if fsaWieyBQvXwJbuEdINPpgzVRFMxcj is fsaWieyBQvXwJbuEdINPpgzVRFMxcO:
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_Main_List()
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_Title_Group(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj in['GLOBAL_GROUP']:
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_SubTitle_Group(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj=='CHANNEL':
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_LiveChannel_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj in['LIVE','VOD','MOVIE']:
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.play_VIDEO(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj=='PROGRAM':
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_Program_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj=='EPISODE':
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_Episode_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj=='MOVIE_SUB':
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_Movie_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj=='SEARCH_GROUP':
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_Search_Group(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj in['SEARCH','LOCAL_SEARCH']:
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_Search_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj=='WATCH':
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_Watch_List(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj=='MYVIEW_REMOVE':
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_WatchList_Delete(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj=='ORDER_BY':
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_setEpOrderby(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj=='MAKE_STRM':
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_Strm_Make(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  elif fsaWieyBQvXwJbuEdINPpgzVRFMxcj in['TOTAL_SEARCH','TOTAL_HISTORY']:
   fsaWieyBQvXwJbuEdINPpgzVRFMxlT.dp_Global_Search(fsaWieyBQvXwJbuEdINPpgzVRFMxlT.main_params)
  else:
   fsaWieyBQvXwJbuEdINPpgzVRFMxcO
# Created by pyminifier (https://github.com/liftoff/pyminifier)
