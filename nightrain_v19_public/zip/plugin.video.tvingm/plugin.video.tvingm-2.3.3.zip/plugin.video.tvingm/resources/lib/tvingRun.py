__author__="NightRain"
vEWUhwDtHSBkTrIqzNQFiGoeVjOfnR=object
vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa=None
vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM=int
vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm=True
vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu=False
vEWUhwDtHSBkTrIqzNQFiGoeVjOfAP=type
vEWUhwDtHSBkTrIqzNQFiGoeVjOfAy=dict
vEWUhwDtHSBkTrIqzNQFiGoeVjOfAn=len
vEWUhwDtHSBkTrIqzNQFiGoeVjOfAg=str
vEWUhwDtHSBkTrIqzNQFiGoeVjOfAs=range
vEWUhwDtHSBkTrIqzNQFiGoeVjOfAL=open
vEWUhwDtHSBkTrIqzNQFiGoeVjOfAc=Exception
vEWUhwDtHSBkTrIqzNQFiGoeVjOfAb=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
vEWUhwDtHSBkTrIqzNQFiGoeVjOfam=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'Euro 2020','mode':'EURO_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
vEWUhwDtHSBkTrIqzNQFiGoeVjOfau=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
vEWUhwDtHSBkTrIqzNQFiGoeVjOfaP=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
vEWUhwDtHSBkTrIqzNQFiGoeVjOfay=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
vEWUhwDtHSBkTrIqzNQFiGoeVjOfan=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
vEWUhwDtHSBkTrIqzNQFiGoeVjOfaA=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
vEWUhwDtHSBkTrIqzNQFiGoeVjOfag=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
vEWUhwDtHSBkTrIqzNQFiGoeVjOfas =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
vEWUhwDtHSBkTrIqzNQFiGoeVjOfaL=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class vEWUhwDtHSBkTrIqzNQFiGoeVjOfaM(vEWUhwDtHSBkTrIqzNQFiGoeVjOfnR):
 def __init__(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfab,vEWUhwDtHSBkTrIqzNQFiGoeVjOfap,vEWUhwDtHSBkTrIqzNQFiGoeVjOfaX):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_url =vEWUhwDtHSBkTrIqzNQFiGoeVjOfab
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle=vEWUhwDtHSBkTrIqzNQFiGoeVjOfap
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params =vEWUhwDtHSBkTrIqzNQFiGoeVjOfaX
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj =xTbejgBGWJSKoMOhQkEHztYvnlisVy() 
 def addon_noti(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,sting):
  try:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfaY=xbmcgui.Dialog()
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfaY.notification(__addonname__,sting)
  except:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
 def addon_log(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,string):
  try:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfal=string.encode('utf-8','ignore')
  except:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfal='addonException: addon_log'
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfaK=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,vEWUhwDtHSBkTrIqzNQFiGoeVjOfal),level=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaK)
 def get_keyboard_input(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfax=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
  kb=xbmc.Keyboard()
  kb.setHeading(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfax=kb.getText()
  return vEWUhwDtHSBkTrIqzNQFiGoeVjOfax
 def get_settings_login_info(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfad =__addon__.getSetting('id')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfaC =__addon__.getSetting('pw')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfaR =__addon__.getSetting('login_type')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMa=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM(__addon__.getSetting('selected_profile'))
  return(vEWUhwDtHSBkTrIqzNQFiGoeVjOfad,vEWUhwDtHSBkTrIqzNQFiGoeVjOfaC,vEWUhwDtHSBkTrIqzNQFiGoeVjOfaR,vEWUhwDtHSBkTrIqzNQFiGoeVjOfMa)
 def get_settings_totalsearch(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMm =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm if __addon__.getSetting('local_search')=='true' else vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMu=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm if __addon__.getSetting('local_history')=='true' else vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMP =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm if __addon__.getSetting('total_search')=='true' else vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMy=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm if __addon__.getSetting('total_history')=='true' else vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMn=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm if __addon__.getSetting('menu_bookmark')=='true' else vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
  return(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMm,vEWUhwDtHSBkTrIqzNQFiGoeVjOfMu,vEWUhwDtHSBkTrIqzNQFiGoeVjOfMP,vEWUhwDtHSBkTrIqzNQFiGoeVjOfMy,vEWUhwDtHSBkTrIqzNQFiGoeVjOfMn)
 def get_settings_makebookmark(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac):
  return vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm if __addon__.getSetting('make_bookmark')=='true' else vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
 def get_settings_direct_replay(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMA=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM(__addon__.getSetting('direct_replay'))
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfMA==0:
   return vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
  else:
   return vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm
 def set_winCredential(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,credential):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg=xbmcgui.Window(10000)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_LOGINTIME',vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg=xbmcgui.Window(10000)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMs={'tving_token':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_TOKEN'),'poc_userinfo':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_USERINFO'),'tving_uuid':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_UUID'),'tving_maintoken':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_LOCKKEY')}
  return vEWUhwDtHSBkTrIqzNQFiGoeVjOfMs
 def set_winEpisodeOrderby(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfun):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg=xbmcgui.Window(10000)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_ORDERBY',vEWUhwDtHSBkTrIqzNQFiGoeVjOfun)
 def get_winEpisodeOrderby(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg=xbmcgui.Window(10000)
  return vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_ORDERBY')
 def add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,label,sublabel='',img='',infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm,params='',isLink=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu,ContextMenu=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfML='%s?%s'%(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_url,urllib.parse.urlencode(params))
  if sublabel:vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc='%s < %s >'%(label,sublabel)
  else: vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc=label
  if not img:img='DefaultFolder.png'
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMb=xbmcgui.ListItem(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfAP(img)==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAy:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMb.setArt(img)
  else:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMb.setArt({'thumb':img,'poster':img})
  if infoLabels:vEWUhwDtHSBkTrIqzNQFiGoeVjOfMb.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMb.setProperty('IsPlayable','true')
  if ContextMenu:vEWUhwDtHSBkTrIqzNQFiGoeVjOfMb.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,vEWUhwDtHSBkTrIqzNQFiGoeVjOfML,vEWUhwDtHSBkTrIqzNQFiGoeVjOfMb,isFolder)
 def get_selQuality(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,etype):
  try:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMp='selected_quality'
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMX=[1080,720,480,360]
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMJ=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM(__addon__.getSetting(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMp))
   return vEWUhwDtHSBkTrIqzNQFiGoeVjOfMX[vEWUhwDtHSBkTrIqzNQFiGoeVjOfMJ]
  except:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
  return 720 
 def dp_Main_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac):
  (vEWUhwDtHSBkTrIqzNQFiGoeVjOfMm,vEWUhwDtHSBkTrIqzNQFiGoeVjOfMu,vEWUhwDtHSBkTrIqzNQFiGoeVjOfMP,vEWUhwDtHSBkTrIqzNQFiGoeVjOfMy,vEWUhwDtHSBkTrIqzNQFiGoeVjOfMn)=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_settings_totalsearch()
  for vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY in vEWUhwDtHSBkTrIqzNQFiGoeVjOfam:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY.get('title')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl=''
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY.get('mode')=='SEARCH_GROUP' and vEWUhwDtHSBkTrIqzNQFiGoeVjOfMm ==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu:continue
   elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY.get('mode')=='SEARCH_HISTORY' and vEWUhwDtHSBkTrIqzNQFiGoeVjOfMu==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu:continue
   elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY.get('mode')=='TOTAL_SEARCH' and vEWUhwDtHSBkTrIqzNQFiGoeVjOfMP ==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu:continue
   elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY.get('mode')=='TOTAL_HISTORY' and vEWUhwDtHSBkTrIqzNQFiGoeVjOfMy==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu:continue
   elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY.get('mode')=='MENU_BOOKMARK' and vEWUhwDtHSBkTrIqzNQFiGoeVjOfMn==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu:continue
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY.get('mode'),'stype':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY.get('stype'),'orderby':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY.get('orderby'),'ordernm':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY.get('ordernm'),'page':'1'}
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMx=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMd =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm
   else:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMx=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMd =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
   if 'icon' in vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY:vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',vEWUhwDtHSBkTrIqzNQFiGoeVjOfMY.get('icon')) 
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel='',img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMx,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK,isLink=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMd)
  xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle)
 def login_main(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac):
  (vEWUhwDtHSBkTrIqzNQFiGoeVjOfMR,vEWUhwDtHSBkTrIqzNQFiGoeVjOfma,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmM,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmu)=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_settings_login_info()
  if not(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMR and vEWUhwDtHSBkTrIqzNQFiGoeVjOfma):
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfaY=xbmcgui.Dialog()
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaY.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmP==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_winEpisodeOrderby()=='':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.set_winEpisodeOrderby('desc')
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.cookiefile_check():return
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmy =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmn=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmn==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa or vEWUhwDtHSBkTrIqzNQFiGoeVjOfmn=='':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmn=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM('19000101')
  else:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmn=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM(re.sub('-','',vEWUhwDtHSBkTrIqzNQFiGoeVjOfmn))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmA=0
   while vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfmA+=1
    time.sleep(0.05)
    if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmn>=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmy:return
    if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmA>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmn>=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmy:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.GetCredential(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMR,vEWUhwDtHSBkTrIqzNQFiGoeVjOfma,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmM,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmu):
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.set_winCredential(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.LoadCredential())
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('stype')
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='live':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfms=vEWUhwDtHSBkTrIqzNQFiGoeVjOfau
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='vod':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfms=vEWUhwDtHSBkTrIqzNQFiGoeVjOfan
  else:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfms=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaA
  for vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL in vEWUhwDtHSBkTrIqzNQFiGoeVjOfms:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL.get('title')
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('ordernm')!='-':
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc+='  ('+vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('ordernm')+')'
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL.get('mode'),'stype':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL.get('stype'),'orderby':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('orderby'),'ordernm':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('ordernm'),'page':'1'}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel='',img='',infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfAn(vEWUhwDtHSBkTrIqzNQFiGoeVjOfms)>0:xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle)
 def dp_SubTitle_Group(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc): 
  for vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL in vEWUhwDtHSBkTrIqzNQFiGoeVjOfag:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL.get('title')
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('ordernm')!='-':
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc+='  ('+vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('ordernm')+')'
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL.get('mode'),'genreCode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL.get('genreCode'),'stype':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('stype'),'orderby':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('orderby'),'page':'1'}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel='',img='',infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfAn(vEWUhwDtHSBkTrIqzNQFiGoeVjOfag)>0:xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle)
 def dp_LiveChannel_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.SaveCredential(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_winCredential())
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('stype')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('page'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmp,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmX=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.GetLiveChannelList(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb)
  for vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ in vEWUhwDtHSBkTrIqzNQFiGoeVjOfmp:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('title')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMC =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('channel')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('thumbnail')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfml =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('synopsis')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmK =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('channelepg')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmx =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('cast')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmd =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('director')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmC =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('info_genre')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmR =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('year')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfua =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('mpaa')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuM =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('premiered')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfum={'mediatype':'episode','title':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,'studio':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMC,'cast':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmx,'director':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmd,'genre':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmC,'plot':'%s\n%s\n%s\n\n%s'%(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMC,vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmK,vEWUhwDtHSBkTrIqzNQFiGoeVjOfml),'year':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmR,'mpaa':vEWUhwDtHSBkTrIqzNQFiGoeVjOfua,'premiered':vEWUhwDtHSBkTrIqzNQFiGoeVjOfuM}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':'LIVE','mediacode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('mediacode'),'stype':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMC,sublabel=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfum,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmX:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['mode']='CHANNEL' 
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['stype']=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg 
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['page']=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAg(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb+1)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc='[B]%s >>[/B]'%'다음 페이지'
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAg(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb+1)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP,img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfAn(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmp)>0:xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,cacheToDisc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu)
 def dp_Program_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.SaveCredential(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_winCredential())
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfuy =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('stype')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfun =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('orderby')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('page'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfuA=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('genreCode')
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfuA==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa:vEWUhwDtHSBkTrIqzNQFiGoeVjOfuA='all'
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfug,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmX=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.GetProgramList(vEWUhwDtHSBkTrIqzNQFiGoeVjOfuy,vEWUhwDtHSBkTrIqzNQFiGoeVjOfun,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb,vEWUhwDtHSBkTrIqzNQFiGoeVjOfuA)
  for vEWUhwDtHSBkTrIqzNQFiGoeVjOfus in vEWUhwDtHSBkTrIqzNQFiGoeVjOfug:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc =vEWUhwDtHSBkTrIqzNQFiGoeVjOfus.get('title')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY =vEWUhwDtHSBkTrIqzNQFiGoeVjOfus.get('thumbnail')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfml =vEWUhwDtHSBkTrIqzNQFiGoeVjOfus.get('synopsis')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuL =vEWUhwDtHSBkTrIqzNQFiGoeVjOfus.get('channel')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmx =vEWUhwDtHSBkTrIqzNQFiGoeVjOfus.get('cast')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmd =vEWUhwDtHSBkTrIqzNQFiGoeVjOfus.get('director')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmC=vEWUhwDtHSBkTrIqzNQFiGoeVjOfus.get('info_genre')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmR =vEWUhwDtHSBkTrIqzNQFiGoeVjOfus.get('year')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuM =vEWUhwDtHSBkTrIqzNQFiGoeVjOfus.get('premiered')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfua =vEWUhwDtHSBkTrIqzNQFiGoeVjOfus.get('mpaa')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfum={'mediatype':'tvshow','title':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,'studio':vEWUhwDtHSBkTrIqzNQFiGoeVjOfuL,'cast':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmx,'director':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmd,'genre':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmC,'year':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmR,'premiered':vEWUhwDtHSBkTrIqzNQFiGoeVjOfuM,'mpaa':vEWUhwDtHSBkTrIqzNQFiGoeVjOfua,'plot':vEWUhwDtHSBkTrIqzNQFiGoeVjOfml}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':'EPISODE','programcode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfus.get('program'),'page':'1'}
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_settings_makebookmark():
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfuc={'videoid':vEWUhwDtHSBkTrIqzNQFiGoeVjOfus.get('program'),'vidtype':'tvshow','vtitle':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,'vsubtitle':vEWUhwDtHSBkTrIqzNQFiGoeVjOfuL,}
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfub=json.dumps(vEWUhwDtHSBkTrIqzNQFiGoeVjOfuc)
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfub=urllib.parse.quote(vEWUhwDtHSBkTrIqzNQFiGoeVjOfub)
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfup='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(vEWUhwDtHSBkTrIqzNQFiGoeVjOfub)
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfuX=[('(통합) 찜 영상에 추가',vEWUhwDtHSBkTrIqzNQFiGoeVjOfup)]
   else:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfuX=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuL,img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfum,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK,ContextMenu=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuX)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmX:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['mode'] ='PROGRAM' 
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['stype'] =vEWUhwDtHSBkTrIqzNQFiGoeVjOfuy
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['orderby'] =vEWUhwDtHSBkTrIqzNQFiGoeVjOfun
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['page'] =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAg(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb+1)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['genreCode']=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuA 
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc='[B]%s >>[/B]'%'다음 페이지'
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAg(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb+1)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP,img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
  xbmcplugin.setContent(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,cacheToDisc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu)
 def dp_Episode_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.SaveCredential(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_winCredential())
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfuY=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('programcode')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('page'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOful,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmX,vEWUhwDtHSBkTrIqzNQFiGoeVjOfuK=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.GetEpisodeList(vEWUhwDtHSBkTrIqzNQFiGoeVjOfuY,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb,orderby=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_winEpisodeOrderby())
  for vEWUhwDtHSBkTrIqzNQFiGoeVjOfux in vEWUhwDtHSBkTrIqzNQFiGoeVjOful:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc =vEWUhwDtHSBkTrIqzNQFiGoeVjOfux.get('title')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP =vEWUhwDtHSBkTrIqzNQFiGoeVjOfux.get('subtitle')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY =vEWUhwDtHSBkTrIqzNQFiGoeVjOfux.get('thumbnail')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfml =vEWUhwDtHSBkTrIqzNQFiGoeVjOfux.get('synopsis')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfud=vEWUhwDtHSBkTrIqzNQFiGoeVjOfux.get('info_title')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuC =vEWUhwDtHSBkTrIqzNQFiGoeVjOfux.get('aired')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuR =vEWUhwDtHSBkTrIqzNQFiGoeVjOfux.get('studio')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfPa =vEWUhwDtHSBkTrIqzNQFiGoeVjOfux.get('frequency')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfum={'mediatype':'episode','title':vEWUhwDtHSBkTrIqzNQFiGoeVjOfud,'aired':vEWUhwDtHSBkTrIqzNQFiGoeVjOfuC,'studio':vEWUhwDtHSBkTrIqzNQFiGoeVjOfuR,'episode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPa,'plot':vEWUhwDtHSBkTrIqzNQFiGoeVjOfml}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':'VOD','mediacode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfux.get('episode'),'stype':'vod','programcode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfuY,'title':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,'thumbnail':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP,img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfum,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb==1:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfum={'plot':'정렬순서를 변경합니다.'}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['mode'] ='ORDER_BY' 
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_winEpisodeOrderby()=='desc':
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc='정렬순서변경 : 최신화부터 -> 1회부터'
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['orderby']='asc'
   else:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc='정렬순서변경 : 1회부터 -> 최신화부터'
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['orderby']='desc'
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel='',img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfum,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK,isLink=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmX:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['mode'] ='EPISODE' 
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['programcode']=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuY
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['page'] =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAg(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb+1)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc='[B]%s >>[/B]'%'다음 페이지'
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAg(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb+1)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP,img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
  xbmcplugin.setContent(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,'episodes')
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfAn(vEWUhwDtHSBkTrIqzNQFiGoeVjOful)>0:xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,cacheToDisc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm)
 def dp_setEpOrderby(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfun =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('orderby')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.set_winEpisodeOrderby(vEWUhwDtHSBkTrIqzNQFiGoeVjOfun)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.SaveCredential(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_winCredential())
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfuy =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('stype')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfun =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('orderby')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('page'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPM,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmX=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.GetMovieList(vEWUhwDtHSBkTrIqzNQFiGoeVjOfuy,vEWUhwDtHSBkTrIqzNQFiGoeVjOfun,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb)
  for vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm in vEWUhwDtHSBkTrIqzNQFiGoeVjOfPM:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('title')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('thumbnail')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfml =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('synopsis')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfud =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('info_title')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmR =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('year')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmx =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('cast')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmd =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('director')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmC =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('info_genre')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfPu =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('duration')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuM =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('premiered')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuR =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('studio')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfua =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('mpaa')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfum={'mediatype':'movie','title':vEWUhwDtHSBkTrIqzNQFiGoeVjOfud,'year':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmR,'cast':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmx,'director':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmd,'genre':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmC,'duration':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPu,'premiered':vEWUhwDtHSBkTrIqzNQFiGoeVjOfuM,'studio':vEWUhwDtHSBkTrIqzNQFiGoeVjOfuR,'mpaa':vEWUhwDtHSBkTrIqzNQFiGoeVjOfua,'plot':vEWUhwDtHSBkTrIqzNQFiGoeVjOfml}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':'MOVIE','mediacode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('moviecode'),'stype':'movie','title':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,'thumbnail':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY}
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_settings_makebookmark():
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfuc={'videoid':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPm.get('moviecode'),'vidtype':'movie','vtitle':vEWUhwDtHSBkTrIqzNQFiGoeVjOfud,'vsubtitle':'',}
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfub=json.dumps(vEWUhwDtHSBkTrIqzNQFiGoeVjOfuc)
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfub=urllib.parse.quote(vEWUhwDtHSBkTrIqzNQFiGoeVjOfub)
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfup='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(vEWUhwDtHSBkTrIqzNQFiGoeVjOfub)
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfuX=[('(통합) 찜 영상에 추가',vEWUhwDtHSBkTrIqzNQFiGoeVjOfup)]
   else:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfuX=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel='',img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfum,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK,ContextMenu=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuX)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmX:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['mode'] ='MOVIE_SUB' 
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['orderby']=vEWUhwDtHSBkTrIqzNQFiGoeVjOfun
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['stype'] =vEWUhwDtHSBkTrIqzNQFiGoeVjOfuy
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['page'] =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAg(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb+1)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc='[B]%s >>[/B]'%'다음 페이지'
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAg(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb+1)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP,img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
  xbmcplugin.setContent(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,'movies')
  xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,cacheToDisc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu)
 def dp_Set_Bookmark(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPy=urllib.parse.unquote(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('bm_param'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPy=json.loads(vEWUhwDtHSBkTrIqzNQFiGoeVjOfPy)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPn =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPy.get('videoid')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPA =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPy.get('vidtype')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPg =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPy.get('vtitle')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPs =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPy.get('vsubtitle')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfaY=xbmcgui.Dialog()
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaY.yesno(__language__(30913).encode('utf8'),vEWUhwDtHSBkTrIqzNQFiGoeVjOfPg+' \n\n'+__language__(30914))
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmP==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu:return
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPL=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.GetBookmarkInfo(vEWUhwDtHSBkTrIqzNQFiGoeVjOfPn,vEWUhwDtHSBkTrIqzNQFiGoeVjOfPA)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfPs!='':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfPL['saveinfo']['subtitle']=vEWUhwDtHSBkTrIqzNQFiGoeVjOfPs 
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfPA=='tvshow':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPL['saveinfo']['infoLabels']['studio']=vEWUhwDtHSBkTrIqzNQFiGoeVjOfPs 
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPc=json.dumps(vEWUhwDtHSBkTrIqzNQFiGoeVjOfPL)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPc=urllib.parse.quote(vEWUhwDtHSBkTrIqzNQFiGoeVjOfPc)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfup ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(vEWUhwDtHSBkTrIqzNQFiGoeVjOfPc)
  xbmc.executebuiltin(vEWUhwDtHSBkTrIqzNQFiGoeVjOfup)
 def dp_Search_Group(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  if 'search_key' in vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('search_key')
  else:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb:
    return
  for vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL in vEWUhwDtHSBkTrIqzNQFiGoeVjOfay:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL.get('mode')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL.get('stype')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL.get('title')
   (vEWUhwDtHSBkTrIqzNQFiGoeVjOfPX,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmX)=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.GetSearchList(vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb,1,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfPJ={'plot':'검색어 : '+vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb+'\n\n'+vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.Search_FreeList(vEWUhwDtHSBkTrIqzNQFiGoeVjOfPX)}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp,'stype':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg,'search_key':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb,'page':'1',}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel='',img='',infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfPJ,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfAn(vEWUhwDtHSBkTrIqzNQFiGoeVjOfay)>0:xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,cacheToDisc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.Save_Searched_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb)
 def Search_FreeList(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPY=''
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPl=7
  try:
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfAn(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM)==0:return '검색결과 없음'
   for i in vEWUhwDtHSBkTrIqzNQFiGoeVjOfAs(vEWUhwDtHSBkTrIqzNQFiGoeVjOfAn(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM)):
    if i>=vEWUhwDtHSBkTrIqzNQFiGoeVjOfPl:
     vEWUhwDtHSBkTrIqzNQFiGoeVjOfPY=vEWUhwDtHSBkTrIqzNQFiGoeVjOfPY+'...'
     break
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfPY=vEWUhwDtHSBkTrIqzNQFiGoeVjOfPY+vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM[i]['title']+'\n'
  except:
   return ''
  return vEWUhwDtHSBkTrIqzNQFiGoeVjOfPY
 def dp_Search_History(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPK=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.Load_List_File('search')
  for vEWUhwDtHSBkTrIqzNQFiGoeVjOfPx in vEWUhwDtHSBkTrIqzNQFiGoeVjOfPK:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfPd=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAy(urllib.parse.parse_qsl(vEWUhwDtHSBkTrIqzNQFiGoeVjOfPx))
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfPC=vEWUhwDtHSBkTrIqzNQFiGoeVjOfPd.get('skey').strip()
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':'SEARCH_GROUP','search_key':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPC,}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfPR={'mode':'SEARCH_REMOVE','stype':'ONE','skey':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPC,}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfya=urllib.parse.urlencode(vEWUhwDtHSBkTrIqzNQFiGoeVjOfPR)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuX=[('선택된 검색어 ( %s ) 삭제'%(vEWUhwDtHSBkTrIqzNQFiGoeVjOfPC),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(vEWUhwDtHSBkTrIqzNQFiGoeVjOfya))]
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfPC,sublabel='',img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK,ContextMenu=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuX)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfum={'plot':'검색목록 전체를 삭제합니다.'}
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel='',img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfum,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK,isLink=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm)
  xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,cacheToDisc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu)
 def dp_Search_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.SaveCredential(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_winCredential())
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('page'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('stype')
  if 'search_key' in vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('search_key')
  else:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb:
    xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle)
    return
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPX,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmX=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.GetSearchList(vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg)
  for vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM in vEWUhwDtHSBkTrIqzNQFiGoeVjOfPX:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc =vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM.get('title')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY =vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM.get('thumbnail')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfml =vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM.get('synopsis')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfym =vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM.get('program')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmx =vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM.get('cast')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmd =vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM.get('director')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmC=vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM.get('info_genre')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfPu =vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM.get('duration')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfua =vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM.get('mpaa')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmR =vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM.get('year')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuC =vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM.get('aired')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfum={'mediatype':'tvshow' if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='vod' else 'movie','title':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,'cast':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmx,'director':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmd,'genre':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmC,'duration':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPu,'mpaa':vEWUhwDtHSBkTrIqzNQFiGoeVjOfua,'year':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmR,'aired':vEWUhwDtHSBkTrIqzNQFiGoeVjOfuC,'plot':'%s\n\n%s'%(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,vEWUhwDtHSBkTrIqzNQFiGoeVjOfml)}
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='vod':
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfPn=vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM.get('program')
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfPA='tvshow'
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':'EPISODE','programcode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPn,'page':'1',}
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMx=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm
   else:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfPn=vEWUhwDtHSBkTrIqzNQFiGoeVjOfyM.get('movie')
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfPA='movie'
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':'MOVIE','mediacode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPn,'stype':'movie','title':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,'thumbnail':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY,}
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMx=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_settings_makebookmark():
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfuc={'videoid':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPn,'vidtype':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPA,'vtitle':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,'vsubtitle':'',}
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfub=json.dumps(vEWUhwDtHSBkTrIqzNQFiGoeVjOfuc)
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfub=urllib.parse.quote(vEWUhwDtHSBkTrIqzNQFiGoeVjOfub)
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfup='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(vEWUhwDtHSBkTrIqzNQFiGoeVjOfub)
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfuX=[('(통합) 찜 영상에 추가',vEWUhwDtHSBkTrIqzNQFiGoeVjOfup)]
   else:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfuX=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel='',img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfum,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMx,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK,isLink=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu,ContextMenu=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuX)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmX:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['mode'] ='SEARCH' 
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['search_key']=vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK['page'] =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAg(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb+1)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc='[B]%s >>[/B]'%'다음 페이지'
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAg(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmb+1)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP,img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='movie':xbmcplugin.setContent(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,'movies')
  else:xbmcplugin.setContent(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,cacheToDisc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu)
 def Delete_List_File(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg,skey='-'):
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='ALL':
   try:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfyu=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaL
    fp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAL(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyu,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='ONE':
   try:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfyu=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaL
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfyP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.Load_List_File('search') 
    fp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAL(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyu,'w',-1,'utf-8')
    for vEWUhwDtHSBkTrIqzNQFiGoeVjOfyn in vEWUhwDtHSBkTrIqzNQFiGoeVjOfyP:
     vEWUhwDtHSBkTrIqzNQFiGoeVjOfyA=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAy(urllib.parse.parse_qsl(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyn))
     vEWUhwDtHSBkTrIqzNQFiGoeVjOfyg=vEWUhwDtHSBkTrIqzNQFiGoeVjOfyA.get('skey').strip()
     if skey!=vEWUhwDtHSBkTrIqzNQFiGoeVjOfyg:
      fp.write(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyn)
    fp.close()
   except:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg in['vod','movie']:
   try:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfyu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg))
    fp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAL(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyu,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
 def dp_Listfile_Delete(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('stype')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPC =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('skey')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfaY=xbmcgui.Dialog()
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='ALL':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaY.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='ONE':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaY.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg in['vod','movie']:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfmP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaY.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmP==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu:sys.exit()
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.Delete_List_File(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg,skey=vEWUhwDtHSBkTrIqzNQFiGoeVjOfPC)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg): 
  try:
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='search':
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfyu=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaL
   elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg in['vod','movie']:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfyu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg))
   else:
    return[]
   fp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAL(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyu,'r',-1,'utf-8')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfys=fp.readlines()
   fp.close()
  except:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfys=[]
  return vEWUhwDtHSBkTrIqzNQFiGoeVjOfys
 def Save_Watched_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg,vEWUhwDtHSBkTrIqzNQFiGoeVjOfaX):
  try:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfyL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg))
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfyP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.Load_List_File(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg) 
   fp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAL(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyL,'w',-1,'utf-8')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfyc=urllib.parse.urlencode(vEWUhwDtHSBkTrIqzNQFiGoeVjOfaX)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfyc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfyc+'\n'
   fp.write(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyc)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfyb=0
   for vEWUhwDtHSBkTrIqzNQFiGoeVjOfyn in vEWUhwDtHSBkTrIqzNQFiGoeVjOfyP:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfyA=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAy(urllib.parse.parse_qsl(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyn))
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfyp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaX.get('code').strip()
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfyX=vEWUhwDtHSBkTrIqzNQFiGoeVjOfyA.get('code').strip()
    if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='vod' and vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_settings_direct_replay()==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm:
     vEWUhwDtHSBkTrIqzNQFiGoeVjOfyp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaX.get('videoid').strip()
     vEWUhwDtHSBkTrIqzNQFiGoeVjOfyX=vEWUhwDtHSBkTrIqzNQFiGoeVjOfyA.get('videoid').strip()if vEWUhwDtHSBkTrIqzNQFiGoeVjOfyX!=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa else '-'
    if vEWUhwDtHSBkTrIqzNQFiGoeVjOfyp!=vEWUhwDtHSBkTrIqzNQFiGoeVjOfyX:
     fp.write(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyn)
     vEWUhwDtHSBkTrIqzNQFiGoeVjOfyb+=1
     if vEWUhwDtHSBkTrIqzNQFiGoeVjOfyb>=50:break
   fp.close()
  except:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
 def dp_Watch_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('stype')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMA=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_settings_direct_replay()
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='-':
   for vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL in vEWUhwDtHSBkTrIqzNQFiGoeVjOfaP:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL.get('title')
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL.get('mode'),'stype':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmL.get('stype')}
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel='',img='',infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfAn(vEWUhwDtHSBkTrIqzNQFiGoeVjOfaP)>0:xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle)
  else:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfyJ=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.Load_List_File(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg)
   for vEWUhwDtHSBkTrIqzNQFiGoeVjOfyY in vEWUhwDtHSBkTrIqzNQFiGoeVjOfyJ:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfPd=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAy(urllib.parse.parse_qsl(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyY))
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfyl =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPd.get('code').strip()
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPd.get('title').strip()
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY=vEWUhwDtHSBkTrIqzNQFiGoeVjOfPd.get('img').strip()
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfPn =vEWUhwDtHSBkTrIqzNQFiGoeVjOfPd.get('videoid').strip()
    try:
     vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY.replace('\'','\"')
     vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY=json.loads(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY)
    except:
     vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfum={}
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfum['plot']=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc
    if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='vod':
     if vEWUhwDtHSBkTrIqzNQFiGoeVjOfMA==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu or vEWUhwDtHSBkTrIqzNQFiGoeVjOfPn==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa:
      vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':'EPISODE','programcode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfyl,'page':'1'}
      vEWUhwDtHSBkTrIqzNQFiGoeVjOfMx=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm
     else:
      vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':'VOD','mediacode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPn,'stype':'vod','programcode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfyl,'title':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,'thumbnail':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY}
      vEWUhwDtHSBkTrIqzNQFiGoeVjOfMx=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
    else:
     vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':'MOVIE','mediacode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfyl,'stype':'movie','title':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,'thumbnail':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY}
     vEWUhwDtHSBkTrIqzNQFiGoeVjOfMx=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel='',img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmY,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfum,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMx,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfum={'plot':'시청목록을 삭제합니다.'}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc='*** 시청목록 삭제 ***'
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':'MYVIEW_REMOVE','stype':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg,'skey':'-',}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel='',img=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMl,infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfum,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK,isLink=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm)
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg=='movie':xbmcplugin.setContent(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,'movies')
   else:xbmcplugin.setContent(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,cacheToDisc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu)
 def Save_Searched_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb):
  try:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfyK=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaL
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfyP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.Load_List_File('search') 
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfyx={'skey':vEWUhwDtHSBkTrIqzNQFiGoeVjOfPb.strip()}
   fp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAL(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyK,'w',-1,'utf-8')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfyc=urllib.parse.urlencode(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyx)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfyc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfyc+'\n'
   fp.write(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyc)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfyb=0
   for vEWUhwDtHSBkTrIqzNQFiGoeVjOfyn in vEWUhwDtHSBkTrIqzNQFiGoeVjOfyP:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfyA=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAy(urllib.parse.parse_qsl(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyn))
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfyp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfyx.get('skey').strip()
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfyX=vEWUhwDtHSBkTrIqzNQFiGoeVjOfyA.get('skey').strip()
    if vEWUhwDtHSBkTrIqzNQFiGoeVjOfyp!=vEWUhwDtHSBkTrIqzNQFiGoeVjOfyX:
     fp.write(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyn)
     vEWUhwDtHSBkTrIqzNQFiGoeVjOfyb+=1
     if vEWUhwDtHSBkTrIqzNQFiGoeVjOfyb>=50:break
   fp.close()
  except:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
 def play_VIDEO(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.SaveCredential(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_winCredential())
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfyd =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('mediacode')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('stype')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfyC =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('pvrmode')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfyR=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_selQuality(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfna,vEWUhwDtHSBkTrIqzNQFiGoeVjOfnM=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.GetBroadURL(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyd,vEWUhwDtHSBkTrIqzNQFiGoeVjOfyR,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg,vEWUhwDtHSBkTrIqzNQFiGoeVjOfyC)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.addon_log('qt, stype, url : %s - %s - %s'%(vEWUhwDtHSBkTrIqzNQFiGoeVjOfAg(vEWUhwDtHSBkTrIqzNQFiGoeVjOfyR),vEWUhwDtHSBkTrIqzNQFiGoeVjOfmg,vEWUhwDtHSBkTrIqzNQFiGoeVjOfna))
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfna=='':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.addon_noti(__language__(30908).encode('utf8'))
   return
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfnm =vEWUhwDtHSBkTrIqzNQFiGoeVjOfna.find('Policy=')
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfnm!=-1:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnu =vEWUhwDtHSBkTrIqzNQFiGoeVjOfna.split('?')[0]
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAy(urllib.parse.parse_qsl(urllib.parse.urlsplit(vEWUhwDtHSBkTrIqzNQFiGoeVjOfna).query))
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnP=urllib.parse.urlencode(vEWUhwDtHSBkTrIqzNQFiGoeVjOfnP)
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfnP.replace('&',';')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfnP.replace('Policy','CloudFront-Policy')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfnP.replace('Signature','CloudFront-Signature')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfnP.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfny='%s|Cookie=%s'%(vEWUhwDtHSBkTrIqzNQFiGoeVjOfnu,vEWUhwDtHSBkTrIqzNQFiGoeVjOfnP)
  else:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfny=vEWUhwDtHSBkTrIqzNQFiGoeVjOfna
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.addon_log(vEWUhwDtHSBkTrIqzNQFiGoeVjOfny)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfnA=xbmcgui.ListItem(path=vEWUhwDtHSBkTrIqzNQFiGoeVjOfny)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfnM!='':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfng=vEWUhwDtHSBkTrIqzNQFiGoeVjOfnM
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfns ='https://cj.drmkeyserver.com/widevine_license'
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnL ='mpd'
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnc ='com.widevine.alpha'
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnb =inputstreamhelper.Helper(vEWUhwDtHSBkTrIqzNQFiGoeVjOfnL,drm='widevine')
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfnb.check_inputstream():
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfnp={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%vEWUhwDtHSBkTrIqzNQFiGoeVjOfyd,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.USER_AGENT,'AcquireLicenseAssertion':vEWUhwDtHSBkTrIqzNQFiGoeVjOfng,'Host':'cj.drmkeyserver.com'}
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfnX=vEWUhwDtHSBkTrIqzNQFiGoeVjOfns+'|'+urllib.parse.urlencode(vEWUhwDtHSBkTrIqzNQFiGoeVjOfnp)+'|R{SSM}|'
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfnA.setProperty('inputstream',vEWUhwDtHSBkTrIqzNQFiGoeVjOfnb.inputstream_addon)
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfnA.setProperty('inputstream.adaptive.manifest_type',vEWUhwDtHSBkTrIqzNQFiGoeVjOfnL)
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfnA.setProperty('inputstream.adaptive.license_type',vEWUhwDtHSBkTrIqzNQFiGoeVjOfnc)
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfnA.setProperty('inputstream.adaptive.license_key',vEWUhwDtHSBkTrIqzNQFiGoeVjOfnX)
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfnA.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.USER_AGENT))
  xbmcplugin.setResolvedUrl(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm,vEWUhwDtHSBkTrIqzNQFiGoeVjOfnA)
  try:
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('mode')in['VOD','MOVIE']and vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('title'):
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'code':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('programcode')if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('mode')=='VOD' else vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('mediacode'),'img':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('thumbnail'),'title':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('title'),'videoid':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('mediacode')}
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.Save_Watched_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('stype'),vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
  except:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
 def logout(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfaY=xbmcgui.Dialog()
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmP=vEWUhwDtHSBkTrIqzNQFiGoeVjOfaY.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmP==vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu:sys.exit()
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.wininfo_clear()
  if os.path.isfile(vEWUhwDtHSBkTrIqzNQFiGoeVjOfas):os.remove(vEWUhwDtHSBkTrIqzNQFiGoeVjOfas)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg=xbmcgui.Window(10000)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_TOKEN','')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_USERINFO','')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_UUID','')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_LOGINTIME','')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_MAINTOKEN','')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_COOKIEKEY','')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfnJ =vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.Get_Now_Datetime()
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfnY=vEWUhwDtHSBkTrIqzNQFiGoeVjOfnJ+datetime.timedelta(days=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM(__addon__.getSetting('cache_ttl')))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg=xbmcgui.Window(10000)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl={'tving_token':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_TOKEN'),'tving_userinfo':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_USERINFO'),'tving_uuid':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':vEWUhwDtHSBkTrIqzNQFiGoeVjOfnY.strftime('%Y-%m-%d'),'tving_maintoken':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAL(vEWUhwDtHSBkTrIqzNQFiGoeVjOfas,'w',-1,'utf-8')
   json.dump(vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl,fp)
   fp.close()
  except vEWUhwDtHSBkTrIqzNQFiGoeVjOfAc as exception:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfAb(exception)
 def cookiefile_check(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl={}
  try: 
   fp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAL(vEWUhwDtHSBkTrIqzNQFiGoeVjOfas,'r',-1,'utf-8')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl= json.load(fp)
   fp.close()
  except vEWUhwDtHSBkTrIqzNQFiGoeVjOfAc as exception:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.wininfo_clear()
   return vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMR =__addon__.getSetting('id')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfma =__addon__.getSetting('pw')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfnK=__addon__.getSetting('login_type')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfnx =__addon__.getSetting('selected_profile')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_id']=base64.standard_b64decode(vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_id']).decode('utf-8')
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_pw']=base64.standard_b64decode(vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_pw']).decode('utf-8')
  try:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_profile']
  except:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_profile']='0'
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfMR!=vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_id']or vEWUhwDtHSBkTrIqzNQFiGoeVjOfma!=vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_pw']or vEWUhwDtHSBkTrIqzNQFiGoeVjOfnK!=vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_logintype']or vEWUhwDtHSBkTrIqzNQFiGoeVjOfnx!=vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_profile']:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.wininfo_clear()
   return vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmy =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfnd=vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_limitdate']
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmn =vEWUhwDtHSBkTrIqzNQFiGoeVjOfAM(re.sub('-','',vEWUhwDtHSBkTrIqzNQFiGoeVjOfnd))
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfmn<vEWUhwDtHSBkTrIqzNQFiGoeVjOfmy:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.wininfo_clear()
   return vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg=xbmcgui.Window(10000)
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_TOKEN',vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_token'])
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_USERINFO',vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_userinfo'])
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_UUID',vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_uuid'])
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_LOGINTIME',vEWUhwDtHSBkTrIqzNQFiGoeVjOfnd)
  try:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_MAINTOKEN',vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_maintoken'])
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_COOKIEKEY',vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_cookiekey'])
   if vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.getProperty('TVING_M_LOCKKEY')in['',vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa]:
    vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_LOCKKEY',vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.GetProfileLockYN(vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_token'],vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_userinfo']))
  except:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_MAINTOKEN',vEWUhwDtHSBkTrIqzNQFiGoeVjOfnl['tving_token'])
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_COOKIEKEY','Y')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMg.setProperty('TVING_M_LOCKKEY','N')
  return vEWUhwDtHSBkTrIqzNQFiGoeVjOfAm
 def dp_Global_Search(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc.get('mode')
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=='TOTAL_SEARCH':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnC='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfnC='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(vEWUhwDtHSBkTrIqzNQFiGoeVjOfnC)
 def dp_Bookmark_Menu(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfnC='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(vEWUhwDtHSBkTrIqzNQFiGoeVjOfnC)
 def dp_EuroLive_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac,vEWUhwDtHSBkTrIqzNQFiGoeVjOfmc):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.SaveCredential(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.get_winCredential())
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfmp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.TvingObj.GetEuroChannelList()
  for vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ in vEWUhwDtHSBkTrIqzNQFiGoeVjOfmp:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuL =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('channel')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('title')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP =vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('subtitle')
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfum={'mediatype':'episode','title':vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,'plot':'%s\n%s'%(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP)}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK={'mode':'LIVE','mediacode':vEWUhwDtHSBkTrIqzNQFiGoeVjOfmJ.get('channel'),'stype':'onair',}
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.add_dir(vEWUhwDtHSBkTrIqzNQFiGoeVjOfMc,sublabel=vEWUhwDtHSBkTrIqzNQFiGoeVjOfuP,img='',infoLabels=vEWUhwDtHSBkTrIqzNQFiGoeVjOfum,isFolder=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu,params=vEWUhwDtHSBkTrIqzNQFiGoeVjOfMK)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfAn(vEWUhwDtHSBkTrIqzNQFiGoeVjOfmp)>0:xbmcplugin.endOfDirectory(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac._addon_handle,cacheToDisc=vEWUhwDtHSBkTrIqzNQFiGoeVjOfAu)
 def tving_main(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac):
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params.get('mode',vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa)
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=='LOGOUT':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.logout()
   return
  vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.login_main()
  if vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp is vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_Main_List()
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_Title_Group(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp in['GLOBAL_GROUP']:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_SubTitle_Group(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=='CHANNEL':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_LiveChannel_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp in['LIVE','VOD','MOVIE']:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.play_VIDEO(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=='PROGRAM':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_Program_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=='EPISODE':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_Episode_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=='MOVIE_SUB':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_Movie_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=='SEARCH_GROUP':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_Search_Group(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp in['SEARCH','LOCAL_SEARCH']:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_Search_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=='WATCH':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_Watch_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_Listfile_Delete(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=='ORDER_BY':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_setEpOrderby(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=='SET_BOOKMARK':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_Set_Bookmark(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp in['TOTAL_SEARCH','TOTAL_HISTORY']:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_Global_Search(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=='SEARCH_HISTORY':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_Search_History(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=='MENU_BOOKMARK':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_Bookmark_Menu(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  elif vEWUhwDtHSBkTrIqzNQFiGoeVjOfPp=='EURO_GROUP':
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.dp_EuroLive_List(vEWUhwDtHSBkTrIqzNQFiGoeVjOfac.main_params)
  else:
   vEWUhwDtHSBkTrIqzNQFiGoeVjOfAa
# Created by pyminifier (https://github.com/liftoff/pyminifier)
