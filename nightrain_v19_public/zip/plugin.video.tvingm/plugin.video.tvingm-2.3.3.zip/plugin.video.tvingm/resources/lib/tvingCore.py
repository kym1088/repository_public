__author__="NightRain"
xTbejgBGWJSKoMOhQkEHztYvnlisDc=object
xTbejgBGWJSKoMOhQkEHztYvnlisDR=None
xTbejgBGWJSKoMOhQkEHztYvnlisDI=False
xTbejgBGWJSKoMOhQkEHztYvnlisDa=int
xTbejgBGWJSKoMOhQkEHztYvnlisDF=range
xTbejgBGWJSKoMOhQkEHztYvnlisDu=True
xTbejgBGWJSKoMOhQkEHztYvnlisDA=Exception
xTbejgBGWJSKoMOhQkEHztYvnlisDU=print
xTbejgBGWJSKoMOhQkEHztYvnlisDq=str
xTbejgBGWJSKoMOhQkEHztYvnlisDm=list
xTbejgBGWJSKoMOhQkEHztYvnlisDP=len
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
xTbejgBGWJSKoMOhQkEHztYvnlisVC={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
xTbejgBGWJSKoMOhQkEHztYvnlisVf ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class xTbejgBGWJSKoMOhQkEHztYvnlisVy(xTbejgBGWJSKoMOhQkEHztYvnlisDc):
 def __init__(xTbejgBGWJSKoMOhQkEHztYvnlisVX):
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_TOKEN =''
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.POC_USERINFO =''
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_UUID ='-'
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_MAINTOKEN=''
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVIGN_COOKIEKEY=''
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_LOCKKEY =''
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.NETWORKCODE ='CSND0900'
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.OSCODE ='CSOD0900' 
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.TELECODE ='CSCD0900'
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.SCREENCODE ='CSSD0100'
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.LIVE_LIMIT =23
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.VOD_LIMIT =20
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.EPISODE_LIMIT =30 
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.SEARCH_LIMIT =30 
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.MOVIE_LIMIT =18
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.API_DOMAIN ='https://api.tving.com'
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN ='https://image.tving.com'
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.SEARCH_DOMAIN ='https://search.tving.com'
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.LOGIN_DOMAIN ='https://user.tving.com'
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.URL_DOMAIN ='https://www.tving.com'
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.MOVIE_LITE =['2610061','2610161','261062']
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.DEFAULT_HEADER ={'user-agent':xTbejgBGWJSKoMOhQkEHztYvnlisVX.USER_AGENT}
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(xTbejgBGWJSKoMOhQkEHztYvnlisVX,jobtype,xTbejgBGWJSKoMOhQkEHztYvnlisyA,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisDR,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisDR,redirects=xTbejgBGWJSKoMOhQkEHztYvnlisDI):
  xTbejgBGWJSKoMOhQkEHztYvnlisVD=xTbejgBGWJSKoMOhQkEHztYvnlisVX.DEFAULT_HEADER
  if headers:xTbejgBGWJSKoMOhQkEHztYvnlisVD.update(headers)
  if jobtype=='Get':
   xTbejgBGWJSKoMOhQkEHztYvnlisVp=requests.get(xTbejgBGWJSKoMOhQkEHztYvnlisyA,params=params,headers=xTbejgBGWJSKoMOhQkEHztYvnlisVD,cookies=cookies,allow_redirects=redirects)
  else:
   xTbejgBGWJSKoMOhQkEHztYvnlisVp=requests.post(xTbejgBGWJSKoMOhQkEHztYvnlisyA,data=payload,params=params,headers=xTbejgBGWJSKoMOhQkEHztYvnlisVD,cookies=cookies,allow_redirects=redirects)
  return xTbejgBGWJSKoMOhQkEHztYvnlisVp
 def makeDefaultCookies(xTbejgBGWJSKoMOhQkEHztYvnlisVX,vToken=xTbejgBGWJSKoMOhQkEHztYvnlisDR,vUserinfo=xTbejgBGWJSKoMOhQkEHztYvnlisDR):
  xTbejgBGWJSKoMOhQkEHztYvnlisVc={}
  xTbejgBGWJSKoMOhQkEHztYvnlisVc['_tving_token']=xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_TOKEN if vToken==xTbejgBGWJSKoMOhQkEHztYvnlisDR else vToken
  xTbejgBGWJSKoMOhQkEHztYvnlisVc['POC_USERINFO']=xTbejgBGWJSKoMOhQkEHztYvnlisVX.POC_USERINFO if vToken==xTbejgBGWJSKoMOhQkEHztYvnlisDR else vUserinfo
  if xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_MAINTOKEN!='':xTbejgBGWJSKoMOhQkEHztYvnlisVc[xTbejgBGWJSKoMOhQkEHztYvnlisVX.GLOBAL_COOKIENM['tv_maintoken']]=xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_MAINTOKEN
  if xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVIGN_COOKIEKEY!='':xTbejgBGWJSKoMOhQkEHztYvnlisVc[xTbejgBGWJSKoMOhQkEHztYvnlisVX.GLOBAL_COOKIENM['tv_cookiekey']]=xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVIGN_COOKIEKEY
  if xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_LOCKKEY !='':xTbejgBGWJSKoMOhQkEHztYvnlisVc[xTbejgBGWJSKoMOhQkEHztYvnlisVX.GLOBAL_COOKIENM['tv_lockkey']] =xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_LOCKKEY
  return xTbejgBGWJSKoMOhQkEHztYvnlisVc
 def getDeviceStr(xTbejgBGWJSKoMOhQkEHztYvnlisVX):
  xTbejgBGWJSKoMOhQkEHztYvnlisVR=[]
  xTbejgBGWJSKoMOhQkEHztYvnlisVR.append('Windows') 
  xTbejgBGWJSKoMOhQkEHztYvnlisVR.append('Chrome') 
  xTbejgBGWJSKoMOhQkEHztYvnlisVR.append('ko-KR') 
  xTbejgBGWJSKoMOhQkEHztYvnlisVR.append('undefined') 
  xTbejgBGWJSKoMOhQkEHztYvnlisVR.append('24') 
  xTbejgBGWJSKoMOhQkEHztYvnlisVR.append(u'한국 표준시')
  xTbejgBGWJSKoMOhQkEHztYvnlisVR.append('undefined') 
  xTbejgBGWJSKoMOhQkEHztYvnlisVR.append('undefined') 
  xTbejgBGWJSKoMOhQkEHztYvnlisVR.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  xTbejgBGWJSKoMOhQkEHztYvnlisVI=''
  for xTbejgBGWJSKoMOhQkEHztYvnlisVa in xTbejgBGWJSKoMOhQkEHztYvnlisVR:
   xTbejgBGWJSKoMOhQkEHztYvnlisVI+=xTbejgBGWJSKoMOhQkEHztYvnlisVa+'|'
  return xTbejgBGWJSKoMOhQkEHztYvnlisVI
 def SaveCredential(xTbejgBGWJSKoMOhQkEHztYvnlisVX,xTbejgBGWJSKoMOhQkEHztYvnlisVF):
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_TOKEN =xTbejgBGWJSKoMOhQkEHztYvnlisVF.get('tving_token')
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.POC_USERINFO =xTbejgBGWJSKoMOhQkEHztYvnlisVF.get('poc_userinfo')
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_UUID =xTbejgBGWJSKoMOhQkEHztYvnlisVF.get('tving_uuid')
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_MAINTOKEN=xTbejgBGWJSKoMOhQkEHztYvnlisVF.get('tving_maintoken')
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVIGN_COOKIEKEY=xTbejgBGWJSKoMOhQkEHztYvnlisVF.get('tving_cookiekey')
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_LOCKKEY =xTbejgBGWJSKoMOhQkEHztYvnlisVF.get('tving_lockkey')
 def LoadCredential(xTbejgBGWJSKoMOhQkEHztYvnlisVX):
  xTbejgBGWJSKoMOhQkEHztYvnlisVF={'tving_token':xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_TOKEN,'poc_userinfo':xTbejgBGWJSKoMOhQkEHztYvnlisVX.POC_USERINFO,'tving_uuid':xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_UUID,'tving_maintoken':xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_MAINTOKEN,'tving_cookiekey':xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVIGN_COOKIEKEY,'tving_lockkey':xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_LOCKKEY}
  return xTbejgBGWJSKoMOhQkEHztYvnlisVF
 def GetDefaultParams(xTbejgBGWJSKoMOhQkEHztYvnlisVX):
  xTbejgBGWJSKoMOhQkEHztYvnlisVu={'apiKey':xTbejgBGWJSKoMOhQkEHztYvnlisVX.APIKEY,'networkCode':xTbejgBGWJSKoMOhQkEHztYvnlisVX.NETWORKCODE,'osCode':xTbejgBGWJSKoMOhQkEHztYvnlisVX.OSCODE,'teleCode':xTbejgBGWJSKoMOhQkEHztYvnlisVX.TELECODE,'screenCode':xTbejgBGWJSKoMOhQkEHztYvnlisVX.SCREENCODE}
  return xTbejgBGWJSKoMOhQkEHztYvnlisVu
 def GetNoCache(xTbejgBGWJSKoMOhQkEHztYvnlisVX,timetype=1):
  if timetype==1:
   return xTbejgBGWJSKoMOhQkEHztYvnlisDa(time.time())
  else:
   return xTbejgBGWJSKoMOhQkEHztYvnlisDa(time.time()*1000)
 def GetUniqueid(xTbejgBGWJSKoMOhQkEHztYvnlisVX):
  xTbejgBGWJSKoMOhQkEHztYvnlisVA=[0 for i in xTbejgBGWJSKoMOhQkEHztYvnlisDF(256)]
  for i in xTbejgBGWJSKoMOhQkEHztYvnlisDF(256):
   xTbejgBGWJSKoMOhQkEHztYvnlisVA[i]='%02x'%(i)
  xTbejgBGWJSKoMOhQkEHztYvnlisVU=xTbejgBGWJSKoMOhQkEHztYvnlisDa(4294967295*random.random())|0
  xTbejgBGWJSKoMOhQkEHztYvnlisVq=xTbejgBGWJSKoMOhQkEHztYvnlisVA[255&xTbejgBGWJSKoMOhQkEHztYvnlisVU]+xTbejgBGWJSKoMOhQkEHztYvnlisVA[xTbejgBGWJSKoMOhQkEHztYvnlisVU>>8&255]+xTbejgBGWJSKoMOhQkEHztYvnlisVA[xTbejgBGWJSKoMOhQkEHztYvnlisVU>>16&255]+xTbejgBGWJSKoMOhQkEHztYvnlisVA[xTbejgBGWJSKoMOhQkEHztYvnlisVU>>24&255]
  return xTbejgBGWJSKoMOhQkEHztYvnlisVq
 def GetCredential(xTbejgBGWJSKoMOhQkEHztYvnlisVX,user_id,user_pw,login_type,user_pf):
  xTbejgBGWJSKoMOhQkEHztYvnlisVm=xTbejgBGWJSKoMOhQkEHztYvnlisDI
  xTbejgBGWJSKoMOhQkEHztYvnlisVP=xTbejgBGWJSKoMOhQkEHztYvnlisyV=xTbejgBGWJSKoMOhQkEHztYvnlisyC=xTbejgBGWJSKoMOhQkEHztYvnlisyf=xTbejgBGWJSKoMOhQkEHztYvnlisyX='' 
  xTbejgBGWJSKoMOhQkEHztYvnlisVN ='-'
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisVr=xTbejgBGWJSKoMOhQkEHztYvnlisVX.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   xTbejgBGWJSKoMOhQkEHztYvnlisVw={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Post',xTbejgBGWJSKoMOhQkEHztYvnlisVr,payload=xTbejgBGWJSKoMOhQkEHztYvnlisVw,params=xTbejgBGWJSKoMOhQkEHztYvnlisDR,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisDR)
   for xTbejgBGWJSKoMOhQkEHztYvnlisVd in xTbejgBGWJSKoMOhQkEHztYvnlisVL.cookies:
    if xTbejgBGWJSKoMOhQkEHztYvnlisVd.name=='_tving_token':
     xTbejgBGWJSKoMOhQkEHztYvnlisyV=xTbejgBGWJSKoMOhQkEHztYvnlisVd.value
    elif xTbejgBGWJSKoMOhQkEHztYvnlisVd.name=='POC_USERINFO':
     xTbejgBGWJSKoMOhQkEHztYvnlisyC=xTbejgBGWJSKoMOhQkEHztYvnlisVd.value
   if xTbejgBGWJSKoMOhQkEHztYvnlisyV=='':return xTbejgBGWJSKoMOhQkEHztYvnlisVm
   xTbejgBGWJSKoMOhQkEHztYvnlisVP=xTbejgBGWJSKoMOhQkEHztYvnlisyV
   xTbejgBGWJSKoMOhQkEHztYvnlisyV,xTbejgBGWJSKoMOhQkEHztYvnlisyf,xTbejgBGWJSKoMOhQkEHztYvnlisyX=xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetProfileToken(xTbejgBGWJSKoMOhQkEHztYvnlisyV,xTbejgBGWJSKoMOhQkEHztYvnlisyC,user_pf)
   xTbejgBGWJSKoMOhQkEHztYvnlisVm=xTbejgBGWJSKoMOhQkEHztYvnlisDu
   xTbejgBGWJSKoMOhQkEHztYvnlisVN =xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetDeviceList(xTbejgBGWJSKoMOhQkEHztYvnlisyV,xTbejgBGWJSKoMOhQkEHztYvnlisyC)
   xTbejgBGWJSKoMOhQkEHztYvnlisVN =xTbejgBGWJSKoMOhQkEHztYvnlisVN+'-'+xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetUniqueid()
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisVP=xTbejgBGWJSKoMOhQkEHztYvnlisyV=xTbejgBGWJSKoMOhQkEHztYvnlisyC=xTbejgBGWJSKoMOhQkEHztYvnlisyf=xTbejgBGWJSKoMOhQkEHztYvnlisyX=''
   xTbejgBGWJSKoMOhQkEHztYvnlisVN='-'
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
  xTbejgBGWJSKoMOhQkEHztYvnlisVF={'tving_token':xTbejgBGWJSKoMOhQkEHztYvnlisyV,'poc_userinfo':xTbejgBGWJSKoMOhQkEHztYvnlisyC,'tving_uuid':xTbejgBGWJSKoMOhQkEHztYvnlisVN,'tving_maintoken':xTbejgBGWJSKoMOhQkEHztYvnlisVP,'tving_cookiekey':xTbejgBGWJSKoMOhQkEHztYvnlisyf,'tving_lockkey':xTbejgBGWJSKoMOhQkEHztYvnlisyX}
  xTbejgBGWJSKoMOhQkEHztYvnlisVX.SaveCredential(xTbejgBGWJSKoMOhQkEHztYvnlisVF)
  return xTbejgBGWJSKoMOhQkEHztYvnlisVm
 def Get_Now_Datetime(xTbejgBGWJSKoMOhQkEHztYvnlisVX):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(xTbejgBGWJSKoMOhQkEHztYvnlisVX,mediacode,sel_quality,stype,pvrmode='-'):
  xTbejgBGWJSKoMOhQkEHztYvnlisyp=''
  xTbejgBGWJSKoMOhQkEHztYvnlisyc=''
  xTbejgBGWJSKoMOhQkEHztYvnlisyR =xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_UUID.split('-')[0] 
  xTbejgBGWJSKoMOhQkEHztYvnlisyI =xTbejgBGWJSKoMOhQkEHztYvnlisVX.TVING_UUID 
  if mediacode=='C01345':
   xTbejgBGWJSKoMOhQkEHztYvnlisyp='http://ocn-mcdn.tving.com/ocn/live5000.smil/playlist.m3u8?Policy=eyJTdGF0ZW1lbnQiOiBbeyJSZXNvdXJjZSI6Imh0dHA6Ly8qIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNjEwODMwODAwfSwiSXBBZGRyZXNzIjp7IkFXUzpTb3VyY2VJcCI6IjAuMC4wLjAvMCJ9fX1dfQ__&Signature=eqJMOA5c~hIlgUVIDOtLCCfKXnNO0XHex3uQVQE87ZfuutuH2hqAgddlijKNWDz2Qrg5ScRkuXuU-7QQoj4QFSPPjyvwJSSrrZtNNVxU8xERXywdUKUwQGfDvl78F4rhS7WP-O1Q86KnLwif9QW0GPRK~n8ceOITlYq22rVLqp~EKwmoGQ3cvw01TMBFRInvobRtXR-zGyMZCx9MDgeHMRay0U9Ibp7nUPb3~T~set~W3so1ovUnF0iLuQpuarXQA3QIBy25O24NVbwalTtzjPoULkpEHeuVsMx-ACom3MTM65kB5TKJNIx19sdlAFQIII7n39FpWgSOO6A8jvu~rA__&Key-Pair-Id=APKAIXCIJCFRGOUEZDWA'
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    xTbejgBGWJSKoMOhQkEHztYvnlisya ='/v2a/media/stream/info' 
    xTbejgBGWJSKoMOhQkEHztYvnlisyF=xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetDefaultParams()
    xTbejgBGWJSKoMOhQkEHztYvnlisyu={'info':'N','mediaCode':mediacode,'noCache':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':xTbejgBGWJSKoMOhQkEHztYvnlisyR,'uuid':xTbejgBGWJSKoMOhQkEHztYvnlisyI,'deviceInfo':'PC','wm':'Y'}
    xTbejgBGWJSKoMOhQkEHztYvnlisyF.update(xTbejgBGWJSKoMOhQkEHztYvnlisyu)
    xTbejgBGWJSKoMOhQkEHztYvnlisyA=xTbejgBGWJSKoMOhQkEHztYvnlisVX.API_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
    xTbejgBGWJSKoMOhQkEHztYvnlisVc=xTbejgBGWJSKoMOhQkEHztYvnlisVX.makeDefaultCookies()
    xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisyA,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisyF,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisVc)
    xTbejgBGWJSKoMOhQkEHztYvnlisyU=json.loads(xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
    if not('stream' in xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']):return xTbejgBGWJSKoMOhQkEHztYvnlisyp,xTbejgBGWJSKoMOhQkEHztYvnlisyc 
    xTbejgBGWJSKoMOhQkEHztYvnlisyq=xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']['stream']
    xTbejgBGWJSKoMOhQkEHztYvnlisym=xTbejgBGWJSKoMOhQkEHztYvnlisyq['quality']
    xTbejgBGWJSKoMOhQkEHztYvnlisyP=[]
    for xTbejgBGWJSKoMOhQkEHztYvnlisyN in xTbejgBGWJSKoMOhQkEHztYvnlisym:
     if xTbejgBGWJSKoMOhQkEHztYvnlisyN['active']=='Y':
      xTbejgBGWJSKoMOhQkEHztYvnlisyP.append({xTbejgBGWJSKoMOhQkEHztYvnlisVC.get(xTbejgBGWJSKoMOhQkEHztYvnlisyN['code']):xTbejgBGWJSKoMOhQkEHztYvnlisyN['code']})
    xTbejgBGWJSKoMOhQkEHztYvnlisyr=xTbejgBGWJSKoMOhQkEHztYvnlisVX.CheckQuality(sel_quality,xTbejgBGWJSKoMOhQkEHztYvnlisyP)
   else:
    for xTbejgBGWJSKoMOhQkEHztYvnlisyw,xTbejgBGWJSKoMOhQkEHztYvnlisCp in xTbejgBGWJSKoMOhQkEHztYvnlisVC.items():
     if xTbejgBGWJSKoMOhQkEHztYvnlisCp==sel_quality:
      xTbejgBGWJSKoMOhQkEHztYvnlisyr=xTbejgBGWJSKoMOhQkEHztYvnlisyw
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
   for xTbejgBGWJSKoMOhQkEHztYvnlisyw,xTbejgBGWJSKoMOhQkEHztYvnlisCp in xTbejgBGWJSKoMOhQkEHztYvnlisVC.items():
    if xTbejgBGWJSKoMOhQkEHztYvnlisCp==sel_quality:
     xTbejgBGWJSKoMOhQkEHztYvnlisyr=xTbejgBGWJSKoMOhQkEHztYvnlisyw
   return xTbejgBGWJSKoMOhQkEHztYvnlisyp,xTbejgBGWJSKoMOhQkEHztYvnlisyc
  xTbejgBGWJSKoMOhQkEHztYvnlisDU(xTbejgBGWJSKoMOhQkEHztYvnlisyr)
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/streaming/info'
   xTbejgBGWJSKoMOhQkEHztYvnlisyF=xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetDefaultParams()
   if stype=='onair':xTbejgBGWJSKoMOhQkEHztYvnlisyF['osCode']='CSOD0400' 
   xTbejgBGWJSKoMOhQkEHztYvnlisyL={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   xTbejgBGWJSKoMOhQkEHztYvnlisyd=xTbejgBGWJSKoMOhQkEHztYvnlisVX.makeOocUrl(xTbejgBGWJSKoMOhQkEHztYvnlisyL)
   xTbejgBGWJSKoMOhQkEHztYvnlisCV=urllib.parse.quote(xTbejgBGWJSKoMOhQkEHztYvnlisyd)
   xTbejgBGWJSKoMOhQkEHztYvnlisyu={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':xTbejgBGWJSKoMOhQkEHztYvnlisyr,'adReq':'adproxy','ooc':xTbejgBGWJSKoMOhQkEHztYvnlisyd,'deviceId':xTbejgBGWJSKoMOhQkEHztYvnlisyR,'uuid':xTbejgBGWJSKoMOhQkEHztYvnlisyI,'deviceInfo':'PC'}
   xTbejgBGWJSKoMOhQkEHztYvnlisCy =xTbejgBGWJSKoMOhQkEHztYvnlisyF
   xTbejgBGWJSKoMOhQkEHztYvnlisCy.update(xTbejgBGWJSKoMOhQkEHztYvnlisyu)
   xTbejgBGWJSKoMOhQkEHztYvnlisyA=xTbejgBGWJSKoMOhQkEHztYvnlisVX.URL_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisCf={'origin':'https://www.tving.com'}
   if stype=='onair':xTbejgBGWJSKoMOhQkEHztYvnlisCf['Referer']='https://www.tving.com/live/player/'+mediacode
   else: xTbejgBGWJSKoMOhQkEHztYvnlisCf['Referer']='https://www.tving.com/vod/player/'+mediacode
   xTbejgBGWJSKoMOhQkEHztYvnlisVc=xTbejgBGWJSKoMOhQkEHztYvnlisVX.makeDefaultCookies()
   xTbejgBGWJSKoMOhQkEHztYvnlisVc['onClickEvent2']=xTbejgBGWJSKoMOhQkEHztYvnlisCV
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Post',xTbejgBGWJSKoMOhQkEHztYvnlisyA,payload=xTbejgBGWJSKoMOhQkEHztYvnlisCy,params=xTbejgBGWJSKoMOhQkEHztYvnlisDR,headers=xTbejgBGWJSKoMOhQkEHztYvnlisCf,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisVc,redirects=xTbejgBGWJSKoMOhQkEHztYvnlisDI)
   xTbejgBGWJSKoMOhQkEHztYvnlisyU=json.loads(xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   if 'drm_license_assertion' in xTbejgBGWJSKoMOhQkEHztYvnlisyU['stream']:
    xTbejgBGWJSKoMOhQkEHztYvnlisyc =xTbejgBGWJSKoMOhQkEHztYvnlisyU['stream']['drm_license_assertion']
    xTbejgBGWJSKoMOhQkEHztYvnlisyp=xTbejgBGWJSKoMOhQkEHztYvnlisyU['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in xTbejgBGWJSKoMOhQkEHztYvnlisyU['stream']['broadcast']):return xTbejgBGWJSKoMOhQkEHztYvnlisyp,xTbejgBGWJSKoMOhQkEHztYvnlisyc
    xTbejgBGWJSKoMOhQkEHztYvnlisyp=xTbejgBGWJSKoMOhQkEHztYvnlisyU['stream']['broadcast']['broad_url']
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
  return xTbejgBGWJSKoMOhQkEHztYvnlisyp,xTbejgBGWJSKoMOhQkEHztYvnlisyc
 def CheckQuality(xTbejgBGWJSKoMOhQkEHztYvnlisVX,sel_qt,xTbejgBGWJSKoMOhQkEHztYvnlisyP):
  for xTbejgBGWJSKoMOhQkEHztYvnlisCX in xTbejgBGWJSKoMOhQkEHztYvnlisyP:
   if sel_qt>=xTbejgBGWJSKoMOhQkEHztYvnlisDm(xTbejgBGWJSKoMOhQkEHztYvnlisCX)[0]:return xTbejgBGWJSKoMOhQkEHztYvnlisCX.get(xTbejgBGWJSKoMOhQkEHztYvnlisDm(xTbejgBGWJSKoMOhQkEHztYvnlisCX)[0])
   xTbejgBGWJSKoMOhQkEHztYvnlisCD=xTbejgBGWJSKoMOhQkEHztYvnlisCX.get(xTbejgBGWJSKoMOhQkEHztYvnlisDm(xTbejgBGWJSKoMOhQkEHztYvnlisCX)[0])
  return xTbejgBGWJSKoMOhQkEHztYvnlisCD
 def makeOocUrl(xTbejgBGWJSKoMOhQkEHztYvnlisVX,xTbejgBGWJSKoMOhQkEHztYvnlisyL):
  xTbejgBGWJSKoMOhQkEHztYvnlisyA=''
  for xTbejgBGWJSKoMOhQkEHztYvnlisyw,xTbejgBGWJSKoMOhQkEHztYvnlisCp in xTbejgBGWJSKoMOhQkEHztYvnlisyL.items():
   xTbejgBGWJSKoMOhQkEHztYvnlisyA+="%s=%s^"%(xTbejgBGWJSKoMOhQkEHztYvnlisyw,xTbejgBGWJSKoMOhQkEHztYvnlisCp)
  return xTbejgBGWJSKoMOhQkEHztYvnlisyA
 def GetLiveChannelList(xTbejgBGWJSKoMOhQkEHztYvnlisVX,stype,page_int):
  xTbejgBGWJSKoMOhQkEHztYvnlisCc=[]
  xTbejgBGWJSKoMOhQkEHztYvnlisCR=xTbejgBGWJSKoMOhQkEHztYvnlisDI
  xTbejgBGWJSKoMOhQkEHztYvnlisCI=xTbejgBGWJSKoMOhQkEHztYvnlisDI
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/v2/media/lives'
   if stype=='onair': 
    xTbejgBGWJSKoMOhQkEHztYvnlisCa='CPCS0100,CPCS0400'
   else:
    xTbejgBGWJSKoMOhQkEHztYvnlisCa='CPCS0300'
   xTbejgBGWJSKoMOhQkEHztYvnlisyF=xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetDefaultParams()
   xTbejgBGWJSKoMOhQkEHztYvnlisyu={'pageNo':xTbejgBGWJSKoMOhQkEHztYvnlisDq(page_int),'pageSize':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':xTbejgBGWJSKoMOhQkEHztYvnlisCa,'_':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetNoCache(2))}
   xTbejgBGWJSKoMOhQkEHztYvnlisyF.update(xTbejgBGWJSKoMOhQkEHztYvnlisyu)
   xTbejgBGWJSKoMOhQkEHztYvnlisyA=xTbejgBGWJSKoMOhQkEHztYvnlisVX.API_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisyA,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisyF,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisDR)
   xTbejgBGWJSKoMOhQkEHztYvnlisyU=json.loads(xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   if not('result' in xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']):return xTbejgBGWJSKoMOhQkEHztYvnlisCc,xTbejgBGWJSKoMOhQkEHztYvnlisCR
   xTbejgBGWJSKoMOhQkEHztYvnlisCF=xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']['result']
   for xTbejgBGWJSKoMOhQkEHztYvnlisyN in xTbejgBGWJSKoMOhQkEHztYvnlisCF:
    xTbejgBGWJSKoMOhQkEHztYvnlisCu=xTbejgBGWJSKoMOhQkEHztYvnlisCq=xTbejgBGWJSKoMOhQkEHztYvnlisCm=''
    xTbejgBGWJSKoMOhQkEHztYvnlisCA=xTbejgBGWJSKoMOhQkEHztYvnlisfF=''
    xTbejgBGWJSKoMOhQkEHztYvnlisCU=xTbejgBGWJSKoMOhQkEHztYvnlisyN['live_code']
    if xTbejgBGWJSKoMOhQkEHztYvnlisCU=='C01345':xTbejgBGWJSKoMOhQkEHztYvnlisCI=xTbejgBGWJSKoMOhQkEHztYvnlisDu 
    xTbejgBGWJSKoMOhQkEHztYvnlisCu =xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['channel']['name']['ko']
    if xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['episode']!=xTbejgBGWJSKoMOhQkEHztYvnlisDR:
     xTbejgBGWJSKoMOhQkEHztYvnlisCq =xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['program']['name']['ko']
     xTbejgBGWJSKoMOhQkEHztYvnlisCq =xTbejgBGWJSKoMOhQkEHztYvnlisCq+', '+xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['episode']['frequency'])+'회'
     xTbejgBGWJSKoMOhQkEHztYvnlisCm=xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['episode']['synopsis']['ko']
    else:
     xTbejgBGWJSKoMOhQkEHztYvnlisCq =xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['program']['name']['ko']
     xTbejgBGWJSKoMOhQkEHztYvnlisCm=xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['program']['synopsis']['ko']
    try: 
     xTbejgBGWJSKoMOhQkEHztYvnlisCP =''
     xTbejgBGWJSKoMOhQkEHztYvnlisCN =''
     xTbejgBGWJSKoMOhQkEHztYvnlisCr=''
     xTbejgBGWJSKoMOhQkEHztYvnlisCw =''
     xTbejgBGWJSKoMOhQkEHztYvnlisCL =''
     xTbejgBGWJSKoMOhQkEHztYvnlisCd =''
     for xTbejgBGWJSKoMOhQkEHztYvnlisfV in xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['program']['image']:
      if xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP0900':xTbejgBGWJSKoMOhQkEHztYvnlisCN =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
      elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP1800':xTbejgBGWJSKoMOhQkEHztYvnlisCr=xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
      elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP2000':xTbejgBGWJSKoMOhQkEHztYvnlisCw =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
      elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP1900':xTbejgBGWJSKoMOhQkEHztYvnlisCL =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
      elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP0200':xTbejgBGWJSKoMOhQkEHztYvnlisCd =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
      elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP0500':xTbejgBGWJSKoMOhQkEHztYvnlisCP =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
      elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP0800':xTbejgBGWJSKoMOhQkEHztYvnlisCP =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
     if xTbejgBGWJSKoMOhQkEHztYvnlisCP=='':
      for xTbejgBGWJSKoMOhQkEHztYvnlisfV in xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['channel']['image']:
       if xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIC0400':xTbejgBGWJSKoMOhQkEHztYvnlisCP =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
       elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIC1400':xTbejgBGWJSKoMOhQkEHztYvnlisCP =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
       elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIC1900':xTbejgBGWJSKoMOhQkEHztYvnlisCP =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
    except:
     xTbejgBGWJSKoMOhQkEHztYvnlisDR
    try:
     xTbejgBGWJSKoMOhQkEHztYvnlisfy =[]
     xTbejgBGWJSKoMOhQkEHztYvnlisfC=[]
     xTbejgBGWJSKoMOhQkEHztYvnlisfX =[]
     xTbejgBGWJSKoMOhQkEHztYvnlisfD=''
     xTbejgBGWJSKoMOhQkEHztYvnlisfp=''
     xTbejgBGWJSKoMOhQkEHztYvnlisfc=''
     for xTbejgBGWJSKoMOhQkEHztYvnlisfR in xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('schedule').get('program').get('actor'):
      if xTbejgBGWJSKoMOhQkEHztYvnlisfR!='' and xTbejgBGWJSKoMOhQkEHztYvnlisfR!=u'없음':xTbejgBGWJSKoMOhQkEHztYvnlisfy.append(xTbejgBGWJSKoMOhQkEHztYvnlisfR)
     for xTbejgBGWJSKoMOhQkEHztYvnlisfI in xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('schedule').get('program').get('director'):
      if xTbejgBGWJSKoMOhQkEHztYvnlisfI!='' and xTbejgBGWJSKoMOhQkEHztYvnlisfI!='-' and xTbejgBGWJSKoMOhQkEHztYvnlisfI!=u'없음':xTbejgBGWJSKoMOhQkEHztYvnlisfC.append(xTbejgBGWJSKoMOhQkEHztYvnlisfI)
     if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('schedule').get('program').get('category1_name').get('ko')!='':
      xTbejgBGWJSKoMOhQkEHztYvnlisfX.append(xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['program']['category1_name']['ko'])
     if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('schedule').get('program').get('category2_name').get('ko')!='':
      xTbejgBGWJSKoMOhQkEHztYvnlisfX.append(xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['program']['category2_name']['ko'])
     if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('schedule').get('program').get('product_year'):xTbejgBGWJSKoMOhQkEHztYvnlisfD=xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['program']['product_year']
     if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('schedule').get('program').get('grade_code') :xTbejgBGWJSKoMOhQkEHztYvnlisfp= xTbejgBGWJSKoMOhQkEHztYvnlisVf.get(xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['program']['grade_code'])
     if 'broad_dt' in xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('schedule').get('program'):
      xTbejgBGWJSKoMOhQkEHztYvnlisfa =xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('schedule').get('program').get('broad_dt')
      xTbejgBGWJSKoMOhQkEHztYvnlisfc='%s-%s-%s'%(xTbejgBGWJSKoMOhQkEHztYvnlisfa[:4],xTbejgBGWJSKoMOhQkEHztYvnlisfa[4:6],xTbejgBGWJSKoMOhQkEHztYvnlisfa[6:])
    except:
     xTbejgBGWJSKoMOhQkEHztYvnlisDR
    xTbejgBGWJSKoMOhQkEHztYvnlisCA=xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['broadcast_start_time'])[8:12]
    xTbejgBGWJSKoMOhQkEHztYvnlisfF =xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisyN['schedule']['broadcast_end_time'])[8:12]
    xTbejgBGWJSKoMOhQkEHztYvnlisfu={'channel':xTbejgBGWJSKoMOhQkEHztYvnlisCu,'title':xTbejgBGWJSKoMOhQkEHztYvnlisCq,'mediacode':xTbejgBGWJSKoMOhQkEHztYvnlisCU,'thumbnail':{'poster':xTbejgBGWJSKoMOhQkEHztYvnlisCN,'thumb':xTbejgBGWJSKoMOhQkEHztYvnlisCP,'clearlogo':xTbejgBGWJSKoMOhQkEHztYvnlisCr,'icon':xTbejgBGWJSKoMOhQkEHztYvnlisCw,'fanart':xTbejgBGWJSKoMOhQkEHztYvnlisCd},'synopsis':xTbejgBGWJSKoMOhQkEHztYvnlisCm,'channelepg':' [%s:%s ~ %s:%s]'%(xTbejgBGWJSKoMOhQkEHztYvnlisCA[0:2],xTbejgBGWJSKoMOhQkEHztYvnlisCA[2:],xTbejgBGWJSKoMOhQkEHztYvnlisfF[0:2],xTbejgBGWJSKoMOhQkEHztYvnlisfF[2:]),'cast':xTbejgBGWJSKoMOhQkEHztYvnlisfy,'director':xTbejgBGWJSKoMOhQkEHztYvnlisfC,'info_genre':xTbejgBGWJSKoMOhQkEHztYvnlisfX,'year':xTbejgBGWJSKoMOhQkEHztYvnlisfD,'mpaa':xTbejgBGWJSKoMOhQkEHztYvnlisfp,'premiered':xTbejgBGWJSKoMOhQkEHztYvnlisfc}
    xTbejgBGWJSKoMOhQkEHztYvnlisCc.append(xTbejgBGWJSKoMOhQkEHztYvnlisfu)
   if xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']['has_more']=='Y':
    xTbejgBGWJSKoMOhQkEHztYvnlisCR=xTbejgBGWJSKoMOhQkEHztYvnlisDu
   else:
    xTbejgBGWJSKoMOhQkEHztYvnlisfu={'channel':'OCN Original','title':'temp','mediacode':'C01345','thumbnail':'http://image.tving.com/upload/cms/caic/CAIC0400/C01345.png','cast':[],'director':[]}
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
  return xTbejgBGWJSKoMOhQkEHztYvnlisCc,xTbejgBGWJSKoMOhQkEHztYvnlisCR
 def GetProgramList(xTbejgBGWJSKoMOhQkEHztYvnlisVX,genre,orderby,page_int,genreCode='all'):
  xTbejgBGWJSKoMOhQkEHztYvnlisCc=[]
  xTbejgBGWJSKoMOhQkEHztYvnlisCR=xTbejgBGWJSKoMOhQkEHztYvnlisDI
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/v2/media/episodes'
   xTbejgBGWJSKoMOhQkEHztYvnlisyF=xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetDefaultParams()
   xTbejgBGWJSKoMOhQkEHztYvnlisyu={'pageNo':xTbejgBGWJSKoMOhQkEHztYvnlisDq(page_int),'pageSize':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetNoCache(2))}
   if genre !='all':xTbejgBGWJSKoMOhQkEHztYvnlisyu['categoryCode']=genre
   if genreCode!='all':xTbejgBGWJSKoMOhQkEHztYvnlisyu['genreCode'] =genreCode 
   xTbejgBGWJSKoMOhQkEHztYvnlisyF.update(xTbejgBGWJSKoMOhQkEHztYvnlisyu)
   xTbejgBGWJSKoMOhQkEHztYvnlisyA=xTbejgBGWJSKoMOhQkEHztYvnlisVX.API_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisyA,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisyF,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisDR)
   xTbejgBGWJSKoMOhQkEHztYvnlisyU=json.loads(xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   if not('result' in xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']):return xTbejgBGWJSKoMOhQkEHztYvnlisCc,xTbejgBGWJSKoMOhQkEHztYvnlisCR
   xTbejgBGWJSKoMOhQkEHztYvnlisCF=xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']['result']
   for xTbejgBGWJSKoMOhQkEHztYvnlisyN in xTbejgBGWJSKoMOhQkEHztYvnlisCF:
    xTbejgBGWJSKoMOhQkEHztYvnlisfA=xTbejgBGWJSKoMOhQkEHztYvnlisyN['program']['code']
    xTbejgBGWJSKoMOhQkEHztYvnlisCq =xTbejgBGWJSKoMOhQkEHztYvnlisyN['program']['name']['ko']
    xTbejgBGWJSKoMOhQkEHztYvnlisfp =xTbejgBGWJSKoMOhQkEHztYvnlisVf.get(xTbejgBGWJSKoMOhQkEHztYvnlisyN['program'].get('grade_code'))
    xTbejgBGWJSKoMOhQkEHztYvnlisCN =''
    xTbejgBGWJSKoMOhQkEHztYvnlisCP =''
    xTbejgBGWJSKoMOhQkEHztYvnlisCr=''
    xTbejgBGWJSKoMOhQkEHztYvnlisCw =''
    xTbejgBGWJSKoMOhQkEHztYvnlisCL =''
    for xTbejgBGWJSKoMOhQkEHztYvnlisfV in xTbejgBGWJSKoMOhQkEHztYvnlisyN['program']['image']:
     if xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP0900':xTbejgBGWJSKoMOhQkEHztYvnlisCN =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
     elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP0200':xTbejgBGWJSKoMOhQkEHztYvnlisCP =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
     elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP1800':xTbejgBGWJSKoMOhQkEHztYvnlisCr=xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
     elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP2000':xTbejgBGWJSKoMOhQkEHztYvnlisCw =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
     elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP1900':xTbejgBGWJSKoMOhQkEHztYvnlisCL =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
    xTbejgBGWJSKoMOhQkEHztYvnlisCm =xTbejgBGWJSKoMOhQkEHztYvnlisyN['program']['synopsis']['ko']
    try:
     xTbejgBGWJSKoMOhQkEHztYvnlisfU=xTbejgBGWJSKoMOhQkEHztYvnlisyN['channel']['name']['ko']
    except:
     xTbejgBGWJSKoMOhQkEHztYvnlisfU=''
    try:
     xTbejgBGWJSKoMOhQkEHztYvnlisfy =[]
     xTbejgBGWJSKoMOhQkEHztYvnlisfC=[]
     xTbejgBGWJSKoMOhQkEHztYvnlisfX =[]
     xTbejgBGWJSKoMOhQkEHztYvnlisfD =''
     xTbejgBGWJSKoMOhQkEHztYvnlisfc=''
     for xTbejgBGWJSKoMOhQkEHztYvnlisfR in xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('program').get('actor'):
      if xTbejgBGWJSKoMOhQkEHztYvnlisfR!='' and xTbejgBGWJSKoMOhQkEHztYvnlisfR!='-' and xTbejgBGWJSKoMOhQkEHztYvnlisfR!=u'없음':xTbejgBGWJSKoMOhQkEHztYvnlisfy.append(xTbejgBGWJSKoMOhQkEHztYvnlisfR)
     for xTbejgBGWJSKoMOhQkEHztYvnlisfI in xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('program').get('director'):
      if xTbejgBGWJSKoMOhQkEHztYvnlisfI!='' and xTbejgBGWJSKoMOhQkEHztYvnlisfI!='-' and xTbejgBGWJSKoMOhQkEHztYvnlisfI!=u'없음':xTbejgBGWJSKoMOhQkEHztYvnlisfC.append(xTbejgBGWJSKoMOhQkEHztYvnlisfI)
     if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('program').get('category1_name').get('ko')!='':
      xTbejgBGWJSKoMOhQkEHztYvnlisfX.append(xTbejgBGWJSKoMOhQkEHztYvnlisyN['program']['category1_name']['ko'])
     if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('program').get('category2_name').get('ko')!='':
      xTbejgBGWJSKoMOhQkEHztYvnlisfX.append(xTbejgBGWJSKoMOhQkEHztYvnlisyN['program']['category2_name']['ko'])
     if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('program').get('product_year'):xTbejgBGWJSKoMOhQkEHztYvnlisfD=xTbejgBGWJSKoMOhQkEHztYvnlisyN['program']['product_year']
     if 'broad_dt' in xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('program'):
      xTbejgBGWJSKoMOhQkEHztYvnlisfa =xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('program').get('broad_dt')
      xTbejgBGWJSKoMOhQkEHztYvnlisfc='%s-%s-%s'%(xTbejgBGWJSKoMOhQkEHztYvnlisfa[:4],xTbejgBGWJSKoMOhQkEHztYvnlisfa[4:6],xTbejgBGWJSKoMOhQkEHztYvnlisfa[6:])
    except:
     xTbejgBGWJSKoMOhQkEHztYvnlisDR
    xTbejgBGWJSKoMOhQkEHztYvnlisfu={'program':xTbejgBGWJSKoMOhQkEHztYvnlisfA,'title':xTbejgBGWJSKoMOhQkEHztYvnlisCq,'thumbnail':{'poster':xTbejgBGWJSKoMOhQkEHztYvnlisCN,'thumb':xTbejgBGWJSKoMOhQkEHztYvnlisCP,'clearlogo':xTbejgBGWJSKoMOhQkEHztYvnlisCr,'icon':xTbejgBGWJSKoMOhQkEHztYvnlisCw,'banner':xTbejgBGWJSKoMOhQkEHztYvnlisCL,'fanart':xTbejgBGWJSKoMOhQkEHztYvnlisCP},'synopsis':xTbejgBGWJSKoMOhQkEHztYvnlisCm,'channel':xTbejgBGWJSKoMOhQkEHztYvnlisfU,'cast':xTbejgBGWJSKoMOhQkEHztYvnlisfy,'director':xTbejgBGWJSKoMOhQkEHztYvnlisfC,'info_genre':xTbejgBGWJSKoMOhQkEHztYvnlisfX,'year':xTbejgBGWJSKoMOhQkEHztYvnlisfD,'premiered':xTbejgBGWJSKoMOhQkEHztYvnlisfc,'mpaa':xTbejgBGWJSKoMOhQkEHztYvnlisfp}
    xTbejgBGWJSKoMOhQkEHztYvnlisCc.append(xTbejgBGWJSKoMOhQkEHztYvnlisfu)
   if xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']['has_more']=='Y':xTbejgBGWJSKoMOhQkEHztYvnlisCR=xTbejgBGWJSKoMOhQkEHztYvnlisDu
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
  return xTbejgBGWJSKoMOhQkEHztYvnlisCc,xTbejgBGWJSKoMOhQkEHztYvnlisCR
 def GetEpisodeList(xTbejgBGWJSKoMOhQkEHztYvnlisVX,program_code,page_int,orderby='desc'):
  xTbejgBGWJSKoMOhQkEHztYvnlisCc=[]
  xTbejgBGWJSKoMOhQkEHztYvnlisCR=xTbejgBGWJSKoMOhQkEHztYvnlisDI
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/v2/media/frequency/program/'+program_code
   xTbejgBGWJSKoMOhQkEHztYvnlisyF=xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetDefaultParams()
   xTbejgBGWJSKoMOhQkEHztYvnlisyu={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetNoCache(2))}
   xTbejgBGWJSKoMOhQkEHztYvnlisyF.update(xTbejgBGWJSKoMOhQkEHztYvnlisyu)
   xTbejgBGWJSKoMOhQkEHztYvnlisyA=xTbejgBGWJSKoMOhQkEHztYvnlisVX.API_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisyA,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisyF,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisDR)
   xTbejgBGWJSKoMOhQkEHztYvnlisyU=json.loads(xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   if not('result' in xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']):return xTbejgBGWJSKoMOhQkEHztYvnlisCc,xTbejgBGWJSKoMOhQkEHztYvnlisCR
   xTbejgBGWJSKoMOhQkEHztYvnlisCF=xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']['result']
   xTbejgBGWJSKoMOhQkEHztYvnlisfq=xTbejgBGWJSKoMOhQkEHztYvnlisDa(xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']['total_count'])
   xTbejgBGWJSKoMOhQkEHztYvnlisfm =xTbejgBGWJSKoMOhQkEHztYvnlisDa(xTbejgBGWJSKoMOhQkEHztYvnlisfq//(xTbejgBGWJSKoMOhQkEHztYvnlisVX.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    xTbejgBGWJSKoMOhQkEHztYvnlisfP =(xTbejgBGWJSKoMOhQkEHztYvnlisfq-1)-((page_int-1)*xTbejgBGWJSKoMOhQkEHztYvnlisVX.EPISODE_LIMIT)
   else:
    xTbejgBGWJSKoMOhQkEHztYvnlisfP =(page_int-1)*xTbejgBGWJSKoMOhQkEHztYvnlisVX.EPISODE_LIMIT
   for i in xTbejgBGWJSKoMOhQkEHztYvnlisDF(xTbejgBGWJSKoMOhQkEHztYvnlisVX.EPISODE_LIMIT):
    if orderby=='desc':
     xTbejgBGWJSKoMOhQkEHztYvnlisfN=xTbejgBGWJSKoMOhQkEHztYvnlisfP-i
     if xTbejgBGWJSKoMOhQkEHztYvnlisfN<0:break
    else:
     xTbejgBGWJSKoMOhQkEHztYvnlisfN=xTbejgBGWJSKoMOhQkEHztYvnlisfP+i
     if xTbejgBGWJSKoMOhQkEHztYvnlisfN>=xTbejgBGWJSKoMOhQkEHztYvnlisfq:break
    xTbejgBGWJSKoMOhQkEHztYvnlisfr=xTbejgBGWJSKoMOhQkEHztYvnlisCF[xTbejgBGWJSKoMOhQkEHztYvnlisfN]['episode']['code']
    xTbejgBGWJSKoMOhQkEHztYvnlisCq =xTbejgBGWJSKoMOhQkEHztYvnlisCF[xTbejgBGWJSKoMOhQkEHztYvnlisfN]['vod_name']['ko']
    xTbejgBGWJSKoMOhQkEHztYvnlisfw =''
    try:
     xTbejgBGWJSKoMOhQkEHztYvnlisfa=xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisCF[xTbejgBGWJSKoMOhQkEHztYvnlisfN]['episode']['broadcast_date'])
     xTbejgBGWJSKoMOhQkEHztYvnlisfw='%s-%s-%s'%(xTbejgBGWJSKoMOhQkEHztYvnlisfa[:4],xTbejgBGWJSKoMOhQkEHztYvnlisfa[4:6],xTbejgBGWJSKoMOhQkEHztYvnlisfa[6:])
    except:
     xTbejgBGWJSKoMOhQkEHztYvnlisDR
    xTbejgBGWJSKoMOhQkEHztYvnlisCm =xTbejgBGWJSKoMOhQkEHztYvnlisCF[xTbejgBGWJSKoMOhQkEHztYvnlisfN]['episode']['synopsis']['ko']
    xTbejgBGWJSKoMOhQkEHztYvnlisCN =''
    xTbejgBGWJSKoMOhQkEHztYvnlisCP =''
    xTbejgBGWJSKoMOhQkEHztYvnlisCr=''
    xTbejgBGWJSKoMOhQkEHztYvnlisCw =''
    xTbejgBGWJSKoMOhQkEHztYvnlisCL =''
    xTbejgBGWJSKoMOhQkEHztYvnlisCd =''
    for xTbejgBGWJSKoMOhQkEHztYvnlisfV in xTbejgBGWJSKoMOhQkEHztYvnlisCF[xTbejgBGWJSKoMOhQkEHztYvnlisfN]['program']['image']:
     if xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP0900':xTbejgBGWJSKoMOhQkEHztYvnlisCN =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
     elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP1800':xTbejgBGWJSKoMOhQkEHztYvnlisCr=xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
     elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP2000':xTbejgBGWJSKoMOhQkEHztYvnlisCw =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
     elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP1900':xTbejgBGWJSKoMOhQkEHztYvnlisCL =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
     elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIP0200':xTbejgBGWJSKoMOhQkEHztYvnlisCd =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
    for xTbejgBGWJSKoMOhQkEHztYvnlisfV in xTbejgBGWJSKoMOhQkEHztYvnlisCF[xTbejgBGWJSKoMOhQkEHztYvnlisfN]['episode']['image']:
     if xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIE0400':xTbejgBGWJSKoMOhQkEHztYvnlisCP =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
    try:
     xTbejgBGWJSKoMOhQkEHztYvnlisfL=xTbejgBGWJSKoMOhQkEHztYvnlisXV=xTbejgBGWJSKoMOhQkEHztYvnlisXy=''
     xTbejgBGWJSKoMOhQkEHztYvnlisfd=0
     xTbejgBGWJSKoMOhQkEHztYvnlisfL =xTbejgBGWJSKoMOhQkEHztYvnlisCF[xTbejgBGWJSKoMOhQkEHztYvnlisfN]['program']['name']['ko']
     xTbejgBGWJSKoMOhQkEHztYvnlisXV =xTbejgBGWJSKoMOhQkEHztYvnlisfw
     xTbejgBGWJSKoMOhQkEHztYvnlisXy =xTbejgBGWJSKoMOhQkEHztYvnlisCF[xTbejgBGWJSKoMOhQkEHztYvnlisfN]['channel']['name']['ko']
     if 'frequency' in xTbejgBGWJSKoMOhQkEHztYvnlisCF[xTbejgBGWJSKoMOhQkEHztYvnlisfN]['episode']:xTbejgBGWJSKoMOhQkEHztYvnlisfd=xTbejgBGWJSKoMOhQkEHztYvnlisCF[xTbejgBGWJSKoMOhQkEHztYvnlisfN]['episode']['frequency']
    except:
     xTbejgBGWJSKoMOhQkEHztYvnlisDR
    xTbejgBGWJSKoMOhQkEHztYvnlisfu={'episode':xTbejgBGWJSKoMOhQkEHztYvnlisfr,'title':xTbejgBGWJSKoMOhQkEHztYvnlisCq,'subtitle':xTbejgBGWJSKoMOhQkEHztYvnlisfw,'thumbnail':{'poster':xTbejgBGWJSKoMOhQkEHztYvnlisCN,'thumb':xTbejgBGWJSKoMOhQkEHztYvnlisCP,'clearlogo':xTbejgBGWJSKoMOhQkEHztYvnlisCr,'icon':xTbejgBGWJSKoMOhQkEHztYvnlisCw,'banner':xTbejgBGWJSKoMOhQkEHztYvnlisCL,'fanart':xTbejgBGWJSKoMOhQkEHztYvnlisCd},'synopsis':xTbejgBGWJSKoMOhQkEHztYvnlisCm,'info_title':xTbejgBGWJSKoMOhQkEHztYvnlisfL,'aired':xTbejgBGWJSKoMOhQkEHztYvnlisXV,'studio':xTbejgBGWJSKoMOhQkEHztYvnlisXy,'frequency':xTbejgBGWJSKoMOhQkEHztYvnlisfd}
    xTbejgBGWJSKoMOhQkEHztYvnlisCc.append(xTbejgBGWJSKoMOhQkEHztYvnlisfu)
   if xTbejgBGWJSKoMOhQkEHztYvnlisfm>page_int:xTbejgBGWJSKoMOhQkEHztYvnlisCR=xTbejgBGWJSKoMOhQkEHztYvnlisDu
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
  return xTbejgBGWJSKoMOhQkEHztYvnlisCc,xTbejgBGWJSKoMOhQkEHztYvnlisCR,xTbejgBGWJSKoMOhQkEHztYvnlisfm
 def GetMovieList(xTbejgBGWJSKoMOhQkEHztYvnlisVX,genre,orderby,page_int):
  xTbejgBGWJSKoMOhQkEHztYvnlisCc=[]
  xTbejgBGWJSKoMOhQkEHztYvnlisCR=xTbejgBGWJSKoMOhQkEHztYvnlisDI
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/v2/media/movies'
   xTbejgBGWJSKoMOhQkEHztYvnlisyF=xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetDefaultParams()
   xTbejgBGWJSKoMOhQkEHztYvnlisyu={'pageNo':xTbejgBGWJSKoMOhQkEHztYvnlisDq(page_int),'pageSize':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetNoCache(2))}
   if genre!='all' :xTbejgBGWJSKoMOhQkEHztYvnlisyu['multiCategoryCode']=genre
   xTbejgBGWJSKoMOhQkEHztYvnlisyu['productPackageCode']=','.join(xTbejgBGWJSKoMOhQkEHztYvnlisVX.MOVIE_LITE)
   xTbejgBGWJSKoMOhQkEHztYvnlisyF.update(xTbejgBGWJSKoMOhQkEHztYvnlisyu)
   xTbejgBGWJSKoMOhQkEHztYvnlisyA=xTbejgBGWJSKoMOhQkEHztYvnlisVX.API_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisyA,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisyF,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisDR)
   xTbejgBGWJSKoMOhQkEHztYvnlisyU=json.loads(xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   if not('result' in xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']):return xTbejgBGWJSKoMOhQkEHztYvnlisCc,xTbejgBGWJSKoMOhQkEHztYvnlisCR
   xTbejgBGWJSKoMOhQkEHztYvnlisCF=xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']['result']
   for xTbejgBGWJSKoMOhQkEHztYvnlisyN in xTbejgBGWJSKoMOhQkEHztYvnlisCF:
    xTbejgBGWJSKoMOhQkEHztYvnlisXC =xTbejgBGWJSKoMOhQkEHztYvnlisyN['movie']['code']
    xTbejgBGWJSKoMOhQkEHztYvnlisCq =xTbejgBGWJSKoMOhQkEHztYvnlisyN['movie']['name']['ko'].strip()
    xTbejgBGWJSKoMOhQkEHztYvnlisCq +=u' (%s)'%(xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('movie').get('product_year'))
    xTbejgBGWJSKoMOhQkEHztYvnlisCN=''
    xTbejgBGWJSKoMOhQkEHztYvnlisCP =''
    xTbejgBGWJSKoMOhQkEHztYvnlisCr=''
    for xTbejgBGWJSKoMOhQkEHztYvnlisfV in xTbejgBGWJSKoMOhQkEHztYvnlisyN['movie']['image']:
     if xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIM2100':xTbejgBGWJSKoMOhQkEHztYvnlisCN =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
     elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIM0400':xTbejgBGWJSKoMOhQkEHztYvnlisCP =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
     elif xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIM1800':xTbejgBGWJSKoMOhQkEHztYvnlisCr=xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
    xTbejgBGWJSKoMOhQkEHztYvnlisCm =xTbejgBGWJSKoMOhQkEHztYvnlisyN['movie']['story']['ko']
    try:
     xTbejgBGWJSKoMOhQkEHztYvnlisfL =xTbejgBGWJSKoMOhQkEHztYvnlisyN['movie']['name']['ko'].strip()
     xTbejgBGWJSKoMOhQkEHztYvnlisfD =xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('movie').get('product_year')
     xTbejgBGWJSKoMOhQkEHztYvnlisfp =xTbejgBGWJSKoMOhQkEHztYvnlisVf.get(xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('grade_code'))
     xTbejgBGWJSKoMOhQkEHztYvnlisfy=[]
     xTbejgBGWJSKoMOhQkEHztYvnlisfC=[]
     xTbejgBGWJSKoMOhQkEHztYvnlisfX=[]
     xTbejgBGWJSKoMOhQkEHztYvnlisXf=0
     xTbejgBGWJSKoMOhQkEHztYvnlisfc=''
     xTbejgBGWJSKoMOhQkEHztYvnlisXy =''
     for xTbejgBGWJSKoMOhQkEHztYvnlisfR in xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('movie').get('actor'):
      if xTbejgBGWJSKoMOhQkEHztYvnlisfR!='':xTbejgBGWJSKoMOhQkEHztYvnlisfy.append(xTbejgBGWJSKoMOhQkEHztYvnlisfR)
     for xTbejgBGWJSKoMOhQkEHztYvnlisfI in xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('movie').get('director'):
      if xTbejgBGWJSKoMOhQkEHztYvnlisfI!='':xTbejgBGWJSKoMOhQkEHztYvnlisfC.append(xTbejgBGWJSKoMOhQkEHztYvnlisfI)
     if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('movie').get('category1_name').get('ko')!='':
      xTbejgBGWJSKoMOhQkEHztYvnlisfX.append(xTbejgBGWJSKoMOhQkEHztYvnlisyN['movie']['category1_name']['ko'])
     if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('movie').get('category2_name').get('ko')!='':
      xTbejgBGWJSKoMOhQkEHztYvnlisfX.append(xTbejgBGWJSKoMOhQkEHztYvnlisyN['movie']['category2_name']['ko'])
     if 'duration' in xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('movie'):xTbejgBGWJSKoMOhQkEHztYvnlisXf=xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('movie').get('duration')
     if 'release_date' in xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('movie'):
      xTbejgBGWJSKoMOhQkEHztYvnlisfa=xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('movie').get('release_date'))
      if xTbejgBGWJSKoMOhQkEHztYvnlisfa!='0':xTbejgBGWJSKoMOhQkEHztYvnlisfc='%s-%s-%s'%(xTbejgBGWJSKoMOhQkEHztYvnlisfa[:4],xTbejgBGWJSKoMOhQkEHztYvnlisfa[4:6],xTbejgBGWJSKoMOhQkEHztYvnlisfa[6:])
     if 'production' in xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('movie'):xTbejgBGWJSKoMOhQkEHztYvnlisXy=xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('movie').get('production')
    except:
     xTbejgBGWJSKoMOhQkEHztYvnlisDR
    xTbejgBGWJSKoMOhQkEHztYvnlisfu={'moviecode':xTbejgBGWJSKoMOhQkEHztYvnlisXC,'title':xTbejgBGWJSKoMOhQkEHztYvnlisCq,'thumbnail':{'poster':xTbejgBGWJSKoMOhQkEHztYvnlisCN,'thumb':xTbejgBGWJSKoMOhQkEHztYvnlisCP,'clearlogo':xTbejgBGWJSKoMOhQkEHztYvnlisCr,'fanart':xTbejgBGWJSKoMOhQkEHztYvnlisCP},'synopsis':xTbejgBGWJSKoMOhQkEHztYvnlisCm,'info_title':xTbejgBGWJSKoMOhQkEHztYvnlisfL,'year':xTbejgBGWJSKoMOhQkEHztYvnlisfD,'cast':xTbejgBGWJSKoMOhQkEHztYvnlisfy,'director':xTbejgBGWJSKoMOhQkEHztYvnlisfC,'info_genre':xTbejgBGWJSKoMOhQkEHztYvnlisfX,'duration':xTbejgBGWJSKoMOhQkEHztYvnlisXf,'premiered':xTbejgBGWJSKoMOhQkEHztYvnlisfc,'studio':xTbejgBGWJSKoMOhQkEHztYvnlisXy,'mpaa':xTbejgBGWJSKoMOhQkEHztYvnlisfp}
    xTbejgBGWJSKoMOhQkEHztYvnlisXD=xTbejgBGWJSKoMOhQkEHztYvnlisDI
    for xTbejgBGWJSKoMOhQkEHztYvnlisXp in xTbejgBGWJSKoMOhQkEHztYvnlisyN['billing_package_id']:
     if xTbejgBGWJSKoMOhQkEHztYvnlisXp in xTbejgBGWJSKoMOhQkEHztYvnlisVX.MOVIE_LITE:
      xTbejgBGWJSKoMOhQkEHztYvnlisXD=xTbejgBGWJSKoMOhQkEHztYvnlisDu
      break
    if xTbejgBGWJSKoMOhQkEHztYvnlisXD==xTbejgBGWJSKoMOhQkEHztYvnlisDI: 
     xTbejgBGWJSKoMOhQkEHztYvnlisfu['title']=xTbejgBGWJSKoMOhQkEHztYvnlisfu['title']+' [개별구매]'
    xTbejgBGWJSKoMOhQkEHztYvnlisCc.append(xTbejgBGWJSKoMOhQkEHztYvnlisfu)
   if xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']['has_more']=='Y':xTbejgBGWJSKoMOhQkEHztYvnlisCR=xTbejgBGWJSKoMOhQkEHztYvnlisDu
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
  return xTbejgBGWJSKoMOhQkEHztYvnlisCc,xTbejgBGWJSKoMOhQkEHztYvnlisCR
 def GetMovieListGenre(xTbejgBGWJSKoMOhQkEHztYvnlisVX,genre,page_int):
  xTbejgBGWJSKoMOhQkEHztYvnlisCc=[]
  xTbejgBGWJSKoMOhQkEHztYvnlisCR=xTbejgBGWJSKoMOhQkEHztYvnlisDI
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/v2/media/movie/curation/'+genre
   xTbejgBGWJSKoMOhQkEHztYvnlisyF=xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetDefaultParams()
   xTbejgBGWJSKoMOhQkEHztYvnlisyu={'pageNo':xTbejgBGWJSKoMOhQkEHztYvnlisDq(page_int),'pageSize':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.MOVIE_LIMIT),'_':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetNoCache(2))}
   xTbejgBGWJSKoMOhQkEHztYvnlisyF.update(xTbejgBGWJSKoMOhQkEHztYvnlisyu)
   xTbejgBGWJSKoMOhQkEHztYvnlisyA=xTbejgBGWJSKoMOhQkEHztYvnlisVX.API_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisyA,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisyF,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisDR)
   xTbejgBGWJSKoMOhQkEHztYvnlisyU=json.loads(xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   if not('movies' in xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']):return xTbejgBGWJSKoMOhQkEHztYvnlisCc,xTbejgBGWJSKoMOhQkEHztYvnlisCR
   xTbejgBGWJSKoMOhQkEHztYvnlisCF=xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']['movies']
   for xTbejgBGWJSKoMOhQkEHztYvnlisyN in xTbejgBGWJSKoMOhQkEHztYvnlisCF:
    xTbejgBGWJSKoMOhQkEHztYvnlisXC =xTbejgBGWJSKoMOhQkEHztYvnlisyN['code']
    xTbejgBGWJSKoMOhQkEHztYvnlisCq =xTbejgBGWJSKoMOhQkEHztYvnlisyN['name']['ko']
    xTbejgBGWJSKoMOhQkEHztYvnlisXc =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisyN['image'][0]['url']
    for xTbejgBGWJSKoMOhQkEHztYvnlisfV in xTbejgBGWJSKoMOhQkEHztYvnlisyN['image']:
     if xTbejgBGWJSKoMOhQkEHztYvnlisfV['code']=='CAIM2100':
      xTbejgBGWJSKoMOhQkEHztYvnlisXc =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV['url']
    xTbejgBGWJSKoMOhQkEHztYvnlisCm =xTbejgBGWJSKoMOhQkEHztYvnlisyN['story']['ko']
    xTbejgBGWJSKoMOhQkEHztYvnlisfu={'moviecode':xTbejgBGWJSKoMOhQkEHztYvnlisXC,'title':xTbejgBGWJSKoMOhQkEHztYvnlisCq.strip(),'thumbnail':xTbejgBGWJSKoMOhQkEHztYvnlisXc,'synopsis':xTbejgBGWJSKoMOhQkEHztYvnlisCm}
    xTbejgBGWJSKoMOhQkEHztYvnlisCc.append(xTbejgBGWJSKoMOhQkEHztYvnlisfu)
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
  return xTbejgBGWJSKoMOhQkEHztYvnlisCc,xTbejgBGWJSKoMOhQkEHztYvnlisCR
 def GetMovieGenre(xTbejgBGWJSKoMOhQkEHztYvnlisVX):
  xTbejgBGWJSKoMOhQkEHztYvnlisCc=[]
  xTbejgBGWJSKoMOhQkEHztYvnlisCR=xTbejgBGWJSKoMOhQkEHztYvnlisDI
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/v2/media/movie/curations'
   xTbejgBGWJSKoMOhQkEHztYvnlisyF=xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetDefaultParams()
   xTbejgBGWJSKoMOhQkEHztYvnlisyu={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetNoCache(2))}
   xTbejgBGWJSKoMOhQkEHztYvnlisyF.update(xTbejgBGWJSKoMOhQkEHztYvnlisyu)
   xTbejgBGWJSKoMOhQkEHztYvnlisyA=xTbejgBGWJSKoMOhQkEHztYvnlisVX.API_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisyA,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisyF,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisDR)
   xTbejgBGWJSKoMOhQkEHztYvnlisyU=json.loads(xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   if not('result' in xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']):return xTbejgBGWJSKoMOhQkEHztYvnlisCc,xTbejgBGWJSKoMOhQkEHztYvnlisCR
   xTbejgBGWJSKoMOhQkEHztYvnlisCF=xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']['result']
   for xTbejgBGWJSKoMOhQkEHztYvnlisyN in xTbejgBGWJSKoMOhQkEHztYvnlisCF:
    xTbejgBGWJSKoMOhQkEHztYvnlisXR =xTbejgBGWJSKoMOhQkEHztYvnlisyN['curation_code']
    xTbejgBGWJSKoMOhQkEHztYvnlisXI =xTbejgBGWJSKoMOhQkEHztYvnlisyN['curation_name']
    xTbejgBGWJSKoMOhQkEHztYvnlisfu={'curation_code':xTbejgBGWJSKoMOhQkEHztYvnlisXR,'curation_name':xTbejgBGWJSKoMOhQkEHztYvnlisXI}
    xTbejgBGWJSKoMOhQkEHztYvnlisCc.append(xTbejgBGWJSKoMOhQkEHztYvnlisfu)
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
  return xTbejgBGWJSKoMOhQkEHztYvnlisCc,xTbejgBGWJSKoMOhQkEHztYvnlisCR
 def GetSearchList(xTbejgBGWJSKoMOhQkEHztYvnlisVX,search_key,page_int,stype):
  xTbejgBGWJSKoMOhQkEHztYvnlisXa=[]
  xTbejgBGWJSKoMOhQkEHztYvnlisCR=xTbejgBGWJSKoMOhQkEHztYvnlisDI
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/search/getSearch.jsp'
   xTbejgBGWJSKoMOhQkEHztYvnlisyu={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':xTbejgBGWJSKoMOhQkEHztYvnlisDq(page_int),'pageSize':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':xTbejgBGWJSKoMOhQkEHztYvnlisVX.SCREENCODE,'os':xTbejgBGWJSKoMOhQkEHztYvnlisVX.OSCODE,'network':xTbejgBGWJSKoMOhQkEHztYvnlisVX.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetNoCache(2))}
   xTbejgBGWJSKoMOhQkEHztYvnlisyA=xTbejgBGWJSKoMOhQkEHztYvnlisVX.SEARCH_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisyA,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisyu,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisDR)
   xTbejgBGWJSKoMOhQkEHztYvnlisyU=json.loads(xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   if stype=='vod':
    if not('programRsb' in xTbejgBGWJSKoMOhQkEHztYvnlisyU):return xTbejgBGWJSKoMOhQkEHztYvnlisXa,xTbejgBGWJSKoMOhQkEHztYvnlisCR
    xTbejgBGWJSKoMOhQkEHztYvnlisXF=xTbejgBGWJSKoMOhQkEHztYvnlisyU['programRsb']['dataList']
    xTbejgBGWJSKoMOhQkEHztYvnlisXu =xTbejgBGWJSKoMOhQkEHztYvnlisDa(xTbejgBGWJSKoMOhQkEHztYvnlisyU['programRsb']['count'])
    for xTbejgBGWJSKoMOhQkEHztYvnlisyN in xTbejgBGWJSKoMOhQkEHztYvnlisXF:
     xTbejgBGWJSKoMOhQkEHztYvnlisfA=xTbejgBGWJSKoMOhQkEHztYvnlisyN['mast_cd']
     xTbejgBGWJSKoMOhQkEHztYvnlisCq =xTbejgBGWJSKoMOhQkEHztYvnlisyN['mast_nm']
     xTbejgBGWJSKoMOhQkEHztYvnlisCN=xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisyN['web_url4']
     xTbejgBGWJSKoMOhQkEHztYvnlisCP =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisyN['web_url']
     try:
      xTbejgBGWJSKoMOhQkEHztYvnlisfy =[]
      xTbejgBGWJSKoMOhQkEHztYvnlisfC=[]
      xTbejgBGWJSKoMOhQkEHztYvnlisfX =[]
      xTbejgBGWJSKoMOhQkEHztYvnlisXf =0
      xTbejgBGWJSKoMOhQkEHztYvnlisfp =''
      xTbejgBGWJSKoMOhQkEHztYvnlisfD =''
      xTbejgBGWJSKoMOhQkEHztYvnlisXV =''
      if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('actor') !='' and xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('actor') !='-':xTbejgBGWJSKoMOhQkEHztYvnlisfy =xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('actor').split(',')
      if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('director')!='' and xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('director')!='-':xTbejgBGWJSKoMOhQkEHztYvnlisfC=xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('director').split(',')
      if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('cate_nm')!='' and xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('cate_nm')!='-':xTbejgBGWJSKoMOhQkEHztYvnlisfX =xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('cate_nm').split('/')
      if 'targetage' in xTbejgBGWJSKoMOhQkEHztYvnlisyN:xTbejgBGWJSKoMOhQkEHztYvnlisfp=xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('targetage')
      if 'broad_dt' in xTbejgBGWJSKoMOhQkEHztYvnlisyN:
       xTbejgBGWJSKoMOhQkEHztYvnlisfa=xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('broad_dt')
       xTbejgBGWJSKoMOhQkEHztYvnlisXV='%s-%s-%s'%(xTbejgBGWJSKoMOhQkEHztYvnlisfa[:4],xTbejgBGWJSKoMOhQkEHztYvnlisfa[4:6],xTbejgBGWJSKoMOhQkEHztYvnlisfa[6:])
       xTbejgBGWJSKoMOhQkEHztYvnlisfD =xTbejgBGWJSKoMOhQkEHztYvnlisfa[:4]
     except:
      xTbejgBGWJSKoMOhQkEHztYvnlisDR
     xTbejgBGWJSKoMOhQkEHztYvnlisfu={'program':xTbejgBGWJSKoMOhQkEHztYvnlisfA,'title':xTbejgBGWJSKoMOhQkEHztYvnlisCq,'thumbnail':{'poster':xTbejgBGWJSKoMOhQkEHztYvnlisCN,'thumb':xTbejgBGWJSKoMOhQkEHztYvnlisCP,'fanart':xTbejgBGWJSKoMOhQkEHztYvnlisCP},'synopsis':'','cast':xTbejgBGWJSKoMOhQkEHztYvnlisfy,'director':xTbejgBGWJSKoMOhQkEHztYvnlisfC,'info_genre':xTbejgBGWJSKoMOhQkEHztYvnlisfX,'duration':xTbejgBGWJSKoMOhQkEHztYvnlisXf,'mpaa':xTbejgBGWJSKoMOhQkEHztYvnlisfp,'year':xTbejgBGWJSKoMOhQkEHztYvnlisfD,'aired':xTbejgBGWJSKoMOhQkEHztYvnlisXV}
     xTbejgBGWJSKoMOhQkEHztYvnlisXa.append(xTbejgBGWJSKoMOhQkEHztYvnlisfu)
   else:
    if not('vodMVRsb' in xTbejgBGWJSKoMOhQkEHztYvnlisyU):return xTbejgBGWJSKoMOhQkEHztYvnlisXa,xTbejgBGWJSKoMOhQkEHztYvnlisCR
    xTbejgBGWJSKoMOhQkEHztYvnlisXA=xTbejgBGWJSKoMOhQkEHztYvnlisyU['vodMVRsb']['dataList']
    xTbejgBGWJSKoMOhQkEHztYvnlisXu =xTbejgBGWJSKoMOhQkEHztYvnlisDa(xTbejgBGWJSKoMOhQkEHztYvnlisyU['vodMVRsb']['count'])
    for xTbejgBGWJSKoMOhQkEHztYvnlisyN in xTbejgBGWJSKoMOhQkEHztYvnlisXA:
     xTbejgBGWJSKoMOhQkEHztYvnlisfA=xTbejgBGWJSKoMOhQkEHztYvnlisyN['mast_cd']
     xTbejgBGWJSKoMOhQkEHztYvnlisCq =xTbejgBGWJSKoMOhQkEHztYvnlisyN['mast_nm'].strip()
     xTbejgBGWJSKoMOhQkEHztYvnlisCN =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisyN['web_url']
     xTbejgBGWJSKoMOhQkEHztYvnlisCP =xTbejgBGWJSKoMOhQkEHztYvnlisCN
     xTbejgBGWJSKoMOhQkEHztYvnlisCr=''
     try:
      xTbejgBGWJSKoMOhQkEHztYvnlisfy =[]
      xTbejgBGWJSKoMOhQkEHztYvnlisfC=[]
      xTbejgBGWJSKoMOhQkEHztYvnlisfX =[]
      xTbejgBGWJSKoMOhQkEHztYvnlisXf =0
      xTbejgBGWJSKoMOhQkEHztYvnlisfp =''
      xTbejgBGWJSKoMOhQkEHztYvnlisfD =''
      xTbejgBGWJSKoMOhQkEHztYvnlisXV =''
      if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('actor') !='' and xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('actor') !='-':xTbejgBGWJSKoMOhQkEHztYvnlisfy =xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('actor').split(',')
      if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('director')!='' and xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('director')!='-':xTbejgBGWJSKoMOhQkEHztYvnlisfC=xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('director').split(',')
      if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('cate_nm')!='' and xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('cate_nm')!='-':xTbejgBGWJSKoMOhQkEHztYvnlisfX =xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('cate_nm').split('/')
      if xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('runtime_sec')!='':xTbejgBGWJSKoMOhQkEHztYvnlisXf=xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('runtime_sec')
      if 'grade_nm' in xTbejgBGWJSKoMOhQkEHztYvnlisyN:xTbejgBGWJSKoMOhQkEHztYvnlisfp=xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('grade_nm')
      xTbejgBGWJSKoMOhQkEHztYvnlisfa=xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('broad_dt')
      if data_str!='':
       xTbejgBGWJSKoMOhQkEHztYvnlisXV='%s-%s-%s'%(xTbejgBGWJSKoMOhQkEHztYvnlisfa[:4],xTbejgBGWJSKoMOhQkEHztYvnlisfa[4:6],xTbejgBGWJSKoMOhQkEHztYvnlisfa[6:])
       xTbejgBGWJSKoMOhQkEHztYvnlisfD =xTbejgBGWJSKoMOhQkEHztYvnlisfa[:4]
     except:
      xTbejgBGWJSKoMOhQkEHztYvnlisDR
     xTbejgBGWJSKoMOhQkEHztYvnlisfu={'movie':xTbejgBGWJSKoMOhQkEHztYvnlisfA,'title':xTbejgBGWJSKoMOhQkEHztYvnlisCq,'thumbnail':{'poster':xTbejgBGWJSKoMOhQkEHztYvnlisCN,'thumb':xTbejgBGWJSKoMOhQkEHztYvnlisCP,'fanart':xTbejgBGWJSKoMOhQkEHztYvnlisCP,'clearlogo':xTbejgBGWJSKoMOhQkEHztYvnlisCr},'synopsis':'','cast':xTbejgBGWJSKoMOhQkEHztYvnlisfy,'director':xTbejgBGWJSKoMOhQkEHztYvnlisfC,'info_genre':xTbejgBGWJSKoMOhQkEHztYvnlisfX,'duration':xTbejgBGWJSKoMOhQkEHztYvnlisXf,'mpaa':xTbejgBGWJSKoMOhQkEHztYvnlisfp,'year':xTbejgBGWJSKoMOhQkEHztYvnlisfD,'aired':xTbejgBGWJSKoMOhQkEHztYvnlisXV}
     xTbejgBGWJSKoMOhQkEHztYvnlisXD=xTbejgBGWJSKoMOhQkEHztYvnlisDI
     for xTbejgBGWJSKoMOhQkEHztYvnlisXp in xTbejgBGWJSKoMOhQkEHztYvnlisyN['bill']:
      if xTbejgBGWJSKoMOhQkEHztYvnlisXp in xTbejgBGWJSKoMOhQkEHztYvnlisVX.MOVIE_LITE:
       xTbejgBGWJSKoMOhQkEHztYvnlisXD=xTbejgBGWJSKoMOhQkEHztYvnlisDu
       break
     if xTbejgBGWJSKoMOhQkEHztYvnlisXD==xTbejgBGWJSKoMOhQkEHztYvnlisDI: 
      xTbejgBGWJSKoMOhQkEHztYvnlisfu['title']=xTbejgBGWJSKoMOhQkEHztYvnlisfu['title']+' [개별구매]'
     xTbejgBGWJSKoMOhQkEHztYvnlisXa.append(xTbejgBGWJSKoMOhQkEHztYvnlisfu)
   if xTbejgBGWJSKoMOhQkEHztYvnlisXu>(page_int*xTbejgBGWJSKoMOhQkEHztYvnlisVX.SEARCH_LIMIT):xTbejgBGWJSKoMOhQkEHztYvnlisCR=xTbejgBGWJSKoMOhQkEHztYvnlisDu
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
  return xTbejgBGWJSKoMOhQkEHztYvnlisXa,xTbejgBGWJSKoMOhQkEHztYvnlisCR
 def GetDeviceList(xTbejgBGWJSKoMOhQkEHztYvnlisVX,xTbejgBGWJSKoMOhQkEHztYvnlisyV,xTbejgBGWJSKoMOhQkEHztYvnlisyC):
  xTbejgBGWJSKoMOhQkEHztYvnlisCc=[]
  xTbejgBGWJSKoMOhQkEHztYvnlisyR='-'
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/v1/user/device/list'
   xTbejgBGWJSKoMOhQkEHztYvnlisXU=xTbejgBGWJSKoMOhQkEHztYvnlisVX.API_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisyu={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   xTbejgBGWJSKoMOhQkEHztYvnlisVc=xTbejgBGWJSKoMOhQkEHztYvnlisVX.makeDefaultCookies(vToken=xTbejgBGWJSKoMOhQkEHztYvnlisyV,vUserinfo=xTbejgBGWJSKoMOhQkEHztYvnlisyC)
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisXU,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisyu,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisVc)
   xTbejgBGWJSKoMOhQkEHztYvnlisyU=json.loads(xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   xTbejgBGWJSKoMOhQkEHztYvnlisCc=xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']
   for xTbejgBGWJSKoMOhQkEHztYvnlisyN in xTbejgBGWJSKoMOhQkEHztYvnlisCc:
    if xTbejgBGWJSKoMOhQkEHztYvnlisyN['model']=='PC':
     xTbejgBGWJSKoMOhQkEHztYvnlisyR=xTbejgBGWJSKoMOhQkEHztYvnlisyN['uuid']
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
  return xTbejgBGWJSKoMOhQkEHztYvnlisyR
 def GetProfileToken(xTbejgBGWJSKoMOhQkEHztYvnlisVX,xTbejgBGWJSKoMOhQkEHztYvnlisyV,xTbejgBGWJSKoMOhQkEHztYvnlisyC,user_pf):
  xTbejgBGWJSKoMOhQkEHztYvnlisXq=[]
  xTbejgBGWJSKoMOhQkEHztYvnlisXm =''
  xTbejgBGWJSKoMOhQkEHztYvnlisXP =''
  xTbejgBGWJSKoMOhQkEHztYvnlisXN='Y'
  xTbejgBGWJSKoMOhQkEHztYvnlisXr ='N'
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/profile/select.do'
   xTbejgBGWJSKoMOhQkEHztYvnlisXU=xTbejgBGWJSKoMOhQkEHztYvnlisVX.URL_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisVc=xTbejgBGWJSKoMOhQkEHztYvnlisVX.makeDefaultCookies(vToken=xTbejgBGWJSKoMOhQkEHztYvnlisyV,vUserinfo=xTbejgBGWJSKoMOhQkEHztYvnlisyC)
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisXU,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisDR,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisVc)
   xTbejgBGWJSKoMOhQkEHztYvnlisXq =re.findall('data-profile-no="\d+"',xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   for i in xTbejgBGWJSKoMOhQkEHztYvnlisDF(xTbejgBGWJSKoMOhQkEHztYvnlisDP(xTbejgBGWJSKoMOhQkEHztYvnlisXq)):
    xTbejgBGWJSKoMOhQkEHztYvnlisXw =xTbejgBGWJSKoMOhQkEHztYvnlisXq[i].replace('data-profile-no=','').replace('"','')
    xTbejgBGWJSKoMOhQkEHztYvnlisXq[i]=xTbejgBGWJSKoMOhQkEHztYvnlisXw
   xTbejgBGWJSKoMOhQkEHztYvnlisXm=xTbejgBGWJSKoMOhQkEHztYvnlisXq[user_pf]
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
   return xTbejgBGWJSKoMOhQkEHztYvnlisXP,xTbejgBGWJSKoMOhQkEHztYvnlisXN,xTbejgBGWJSKoMOhQkEHztYvnlisXr
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/profile/api/select.do'
   xTbejgBGWJSKoMOhQkEHztYvnlisXU=xTbejgBGWJSKoMOhQkEHztYvnlisVX.URL_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisVc=xTbejgBGWJSKoMOhQkEHztYvnlisVX.makeDefaultCookies(vToken=xTbejgBGWJSKoMOhQkEHztYvnlisyV,vUserinfo=xTbejgBGWJSKoMOhQkEHztYvnlisyC)
   xTbejgBGWJSKoMOhQkEHztYvnlisVw={'profileNo':xTbejgBGWJSKoMOhQkEHztYvnlisXm}
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Post',xTbejgBGWJSKoMOhQkEHztYvnlisXU,payload=xTbejgBGWJSKoMOhQkEHztYvnlisVw,params=xTbejgBGWJSKoMOhQkEHztYvnlisDR,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisVc)
   for xTbejgBGWJSKoMOhQkEHztYvnlisVd in xTbejgBGWJSKoMOhQkEHztYvnlisVL.cookies:
    if xTbejgBGWJSKoMOhQkEHztYvnlisVd.name=='_tving_token':
     xTbejgBGWJSKoMOhQkEHztYvnlisXP=xTbejgBGWJSKoMOhQkEHztYvnlisVd.value
    elif xTbejgBGWJSKoMOhQkEHztYvnlisVd.name==xTbejgBGWJSKoMOhQkEHztYvnlisVX.GLOBAL_COOKIENM['tv_cookiekey']:
     xTbejgBGWJSKoMOhQkEHztYvnlisXN=xTbejgBGWJSKoMOhQkEHztYvnlisVd.value
    elif xTbejgBGWJSKoMOhQkEHztYvnlisVd.name==xTbejgBGWJSKoMOhQkEHztYvnlisVX.GLOBAL_COOKIENM['tv_lockkey']:
     xTbejgBGWJSKoMOhQkEHztYvnlisXr=xTbejgBGWJSKoMOhQkEHztYvnlisVd.value
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
  return xTbejgBGWJSKoMOhQkEHztYvnlisXP,xTbejgBGWJSKoMOhQkEHztYvnlisXN,xTbejgBGWJSKoMOhQkEHztYvnlisXr
 def GetProfileLockYN(xTbejgBGWJSKoMOhQkEHztYvnlisVX,xTbejgBGWJSKoMOhQkEHztYvnlisyV,xTbejgBGWJSKoMOhQkEHztYvnlisyC):
  xTbejgBGWJSKoMOhQkEHztYvnlisXq=[]
  xTbejgBGWJSKoMOhQkEHztYvnlisXr ='N'
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/profile/select.do'
   xTbejgBGWJSKoMOhQkEHztYvnlisXU=xTbejgBGWJSKoMOhQkEHztYvnlisVX.URL_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisVc=xTbejgBGWJSKoMOhQkEHztYvnlisVX.makeDefaultCookies(vToken=xTbejgBGWJSKoMOhQkEHztYvnlisyV,vUserinfo=xTbejgBGWJSKoMOhQkEHztYvnlisyC)
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisXU,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisDR,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisVc)
   xTbejgBGWJSKoMOhQkEHztYvnlisXq =re.findall('data-profile-no="\d+"',xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   for i in xTbejgBGWJSKoMOhQkEHztYvnlisDF(xTbejgBGWJSKoMOhQkEHztYvnlisDP(xTbejgBGWJSKoMOhQkEHztYvnlisXq)):
    xTbejgBGWJSKoMOhQkEHztYvnlisXw =xTbejgBGWJSKoMOhQkEHztYvnlisXq[i].replace('data-profile-no=','').replace('"','')
    xTbejgBGWJSKoMOhQkEHztYvnlisXq[i]=xTbejgBGWJSKoMOhQkEHztYvnlisXw
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
   return xTbejgBGWJSKoMOhQkEHztYvnlisXr
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/profile/api/select.do'
   xTbejgBGWJSKoMOhQkEHztYvnlisXU=xTbejgBGWJSKoMOhQkEHztYvnlisVX.URL_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisVc=xTbejgBGWJSKoMOhQkEHztYvnlisVX.makeDefaultCookies(vToken=xTbejgBGWJSKoMOhQkEHztYvnlisyV,vUserinfo=xTbejgBGWJSKoMOhQkEHztYvnlisyC)
   for i in xTbejgBGWJSKoMOhQkEHztYvnlisDF(xTbejgBGWJSKoMOhQkEHztYvnlisDP(xTbejgBGWJSKoMOhQkEHztYvnlisXq)):
    xTbejgBGWJSKoMOhQkEHztYvnlisVw={'profileNo':xTbejgBGWJSKoMOhQkEHztYvnlisXq[i]}
    xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Post',xTbejgBGWJSKoMOhQkEHztYvnlisXU,payload=xTbejgBGWJSKoMOhQkEHztYvnlisVw,params=xTbejgBGWJSKoMOhQkEHztYvnlisDR,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisVc)
    for xTbejgBGWJSKoMOhQkEHztYvnlisVd in xTbejgBGWJSKoMOhQkEHztYvnlisVL.cookies:
     if xTbejgBGWJSKoMOhQkEHztYvnlisVd.name=='_tving_token':
      xTbejgBGWJSKoMOhQkEHztYvnlisXL=xTbejgBGWJSKoMOhQkEHztYvnlisVd.value
     elif xTbejgBGWJSKoMOhQkEHztYvnlisVd.name==xTbejgBGWJSKoMOhQkEHztYvnlisVX.GLOBAL_COOKIENM['tv_lockkey']:
      xTbejgBGWJSKoMOhQkEHztYvnlisXd=xTbejgBGWJSKoMOhQkEHztYvnlisVd.value
    if xTbejgBGWJSKoMOhQkEHztYvnlisXL==xTbejgBGWJSKoMOhQkEHztYvnlisyV:
     xTbejgBGWJSKoMOhQkEHztYvnlisXr=xTbejgBGWJSKoMOhQkEHztYvnlisXd
     xTbejgBGWJSKoMOhQkEHztYvnlisDU(xTbejgBGWJSKoMOhQkEHztYvnlisyV)
     break
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
  return xTbejgBGWJSKoMOhQkEHztYvnlisXr
 def GetBookmarkInfo(xTbejgBGWJSKoMOhQkEHztYvnlisVX,videoid,vidtype):
  xTbejgBGWJSKoMOhQkEHztYvnlisDV={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   xTbejgBGWJSKoMOhQkEHztYvnlisyA=xTbejgBGWJSKoMOhQkEHztYvnlisVX.API_DOMAIN+'/v2/media/program/'+videoid
   xTbejgBGWJSKoMOhQkEHztYvnlisyF=xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetDefaultParams()
   xTbejgBGWJSKoMOhQkEHztYvnlisyu={'pageNo':'1','pageSize':'10','order':'name',}
   xTbejgBGWJSKoMOhQkEHztYvnlisyF.update(xTbejgBGWJSKoMOhQkEHztYvnlisyu)
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisyA,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisyF,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisDR)
   xTbejgBGWJSKoMOhQkEHztYvnlisDy=json.loads(xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   if not('body' in xTbejgBGWJSKoMOhQkEHztYvnlisDy):return{}
   xTbejgBGWJSKoMOhQkEHztYvnlisDC=xTbejgBGWJSKoMOhQkEHztYvnlisDy['body']
   xTbejgBGWJSKoMOhQkEHztYvnlisCq=xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('name').get('ko').strip()
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['title'] =xTbejgBGWJSKoMOhQkEHztYvnlisCq
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['title']=xTbejgBGWJSKoMOhQkEHztYvnlisCq
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['mpaa'] =xTbejgBGWJSKoMOhQkEHztYvnlisVf.get(xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('grade_code'))
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['plot'] =xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('synopsis').get('ko')
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['year'] =xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('product_year')
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['cast'] =xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('actor')
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['director']=xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('director')
   if xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('category1_name').get('ko')!='':
    xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['genre'].append(xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('category1_name').get('ko'))
   if xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('category2_name').get('ko')!='':
    xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['genre'].append(xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('category2_name').get('ko'))
   xTbejgBGWJSKoMOhQkEHztYvnlisfa=xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('broad_dt'))
   if xTbejgBGWJSKoMOhQkEHztYvnlisfa!='0':xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(xTbejgBGWJSKoMOhQkEHztYvnlisfa[:4],xTbejgBGWJSKoMOhQkEHztYvnlisfa[4:6],xTbejgBGWJSKoMOhQkEHztYvnlisfa[6:])
   xTbejgBGWJSKoMOhQkEHztYvnlisCN =''
   xTbejgBGWJSKoMOhQkEHztYvnlisCP =''
   xTbejgBGWJSKoMOhQkEHztYvnlisCr=''
   xTbejgBGWJSKoMOhQkEHztYvnlisCw =''
   xTbejgBGWJSKoMOhQkEHztYvnlisCL =''
   for xTbejgBGWJSKoMOhQkEHztYvnlisfV in xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('image'):
    if xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('code')=='CAIP0900':xTbejgBGWJSKoMOhQkEHztYvnlisCN =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('url')
    elif xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('code')=='CAIP0200':xTbejgBGWJSKoMOhQkEHztYvnlisCP =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('url')
    elif xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('code')=='CAIP1800':xTbejgBGWJSKoMOhQkEHztYvnlisCr=xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('url')
    elif xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('code')=='CAIP2000':xTbejgBGWJSKoMOhQkEHztYvnlisCw =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('url')
    elif xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('code')=='CAIP1900':xTbejgBGWJSKoMOhQkEHztYvnlisCL =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('url')
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['thumbnail']['poster']=xTbejgBGWJSKoMOhQkEHztYvnlisCN
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['thumbnail']['thumb']=xTbejgBGWJSKoMOhQkEHztYvnlisCP
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['thumbnail']['clearlogo']=xTbejgBGWJSKoMOhQkEHztYvnlisCr
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['thumbnail']['icon']=xTbejgBGWJSKoMOhQkEHztYvnlisCw
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['thumbnail']['banner']=xTbejgBGWJSKoMOhQkEHztYvnlisCL
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['thumbnail']['fanart']=xTbejgBGWJSKoMOhQkEHztYvnlisCP
  else:
   xTbejgBGWJSKoMOhQkEHztYvnlisyA=xTbejgBGWJSKoMOhQkEHztYvnlisVX.API_DOMAIN+'/v2a/media/stream/info'
   xTbejgBGWJSKoMOhQkEHztYvnlisyF=xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetDefaultParams()
   xTbejgBGWJSKoMOhQkEHztYvnlisyu={'info':'Y','mediaCode':videoid,'noCache':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':'','uuid':'','deviceInfo':'PC','wm':'Y',}
   xTbejgBGWJSKoMOhQkEHztYvnlisyF.update(xTbejgBGWJSKoMOhQkEHztYvnlisyu)
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisyA,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisyF,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisDR)
   xTbejgBGWJSKoMOhQkEHztYvnlisDy=json.loads(xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   if not('content' in xTbejgBGWJSKoMOhQkEHztYvnlisDy['body']):return{}
   xTbejgBGWJSKoMOhQkEHztYvnlisDC=xTbejgBGWJSKoMOhQkEHztYvnlisDy['body']['content']['info']['movie']
   xTbejgBGWJSKoMOhQkEHztYvnlisCq =xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('name').get('ko').strip()
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['title']=xTbejgBGWJSKoMOhQkEHztYvnlisCq
   xTbejgBGWJSKoMOhQkEHztYvnlisCq +=u' (%s)'%(xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('product_year'))
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['title'] =xTbejgBGWJSKoMOhQkEHztYvnlisCq
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['mpaa'] =xTbejgBGWJSKoMOhQkEHztYvnlisVf.get(xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('grade_code'))
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['plot'] =xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('story').get('ko')
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['year'] =xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('product_year')
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['studio'] =xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('production')
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['duration']=xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('duration')
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['cast'] =xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('actor')
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['director']=xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('director')
   if xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('category1_name').get('ko')!='':
    xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['genre'].append(xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('category1_name').get('ko'))
   if xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('category2_name').get('ko')!='':
    xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['genre'].append(xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('category2_name').get('ko'))
   xTbejgBGWJSKoMOhQkEHztYvnlisfa=xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('release_date'))
   if xTbejgBGWJSKoMOhQkEHztYvnlisfa!='0':xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(xTbejgBGWJSKoMOhQkEHztYvnlisfa[:4],xTbejgBGWJSKoMOhQkEHztYvnlisfa[4:6],xTbejgBGWJSKoMOhQkEHztYvnlisfa[6:])
   xTbejgBGWJSKoMOhQkEHztYvnlisCN=''
   xTbejgBGWJSKoMOhQkEHztYvnlisCP =''
   xTbejgBGWJSKoMOhQkEHztYvnlisCr=''
   for xTbejgBGWJSKoMOhQkEHztYvnlisfV in xTbejgBGWJSKoMOhQkEHztYvnlisDC.get('image'):
    if xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('code')=='CAIM2100':xTbejgBGWJSKoMOhQkEHztYvnlisCN =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('url')
    elif xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('code')=='CAIM0400':xTbejgBGWJSKoMOhQkEHztYvnlisCP =xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('url')
    elif xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('code')=='CAIM1800':xTbejgBGWJSKoMOhQkEHztYvnlisCr=xTbejgBGWJSKoMOhQkEHztYvnlisVX.IMG_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisfV.get('url')
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['thumbnail']['poster']=xTbejgBGWJSKoMOhQkEHztYvnlisCN
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['thumbnail']['thumb']=xTbejgBGWJSKoMOhQkEHztYvnlisCN 
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['thumbnail']['clearlogo']=xTbejgBGWJSKoMOhQkEHztYvnlisCr
   xTbejgBGWJSKoMOhQkEHztYvnlisDV['saveinfo']['thumbnail']['fanart']=xTbejgBGWJSKoMOhQkEHztYvnlisCP
  return xTbejgBGWJSKoMOhQkEHztYvnlisDV
 def GetEuroChannelList(xTbejgBGWJSKoMOhQkEHztYvnlisVX):
  xTbejgBGWJSKoMOhQkEHztYvnlisCc=[]
  try:
   xTbejgBGWJSKoMOhQkEHztYvnlisya ='/v2/operator/highlights'
   xTbejgBGWJSKoMOhQkEHztYvnlisyF=xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetDefaultParams()
   xTbejgBGWJSKoMOhQkEHztYvnlisyu={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':xTbejgBGWJSKoMOhQkEHztYvnlisDq(xTbejgBGWJSKoMOhQkEHztYvnlisVX.GetNoCache(2))}
   xTbejgBGWJSKoMOhQkEHztYvnlisyF.update(xTbejgBGWJSKoMOhQkEHztYvnlisyu)
   xTbejgBGWJSKoMOhQkEHztYvnlisyA=xTbejgBGWJSKoMOhQkEHztYvnlisVX.API_DOMAIN+xTbejgBGWJSKoMOhQkEHztYvnlisya
   xTbejgBGWJSKoMOhQkEHztYvnlisVL=xTbejgBGWJSKoMOhQkEHztYvnlisVX.callRequestCookies('Get',xTbejgBGWJSKoMOhQkEHztYvnlisyA,payload=xTbejgBGWJSKoMOhQkEHztYvnlisDR,params=xTbejgBGWJSKoMOhQkEHztYvnlisyF,headers=xTbejgBGWJSKoMOhQkEHztYvnlisDR,cookies=xTbejgBGWJSKoMOhQkEHztYvnlisDR)
   xTbejgBGWJSKoMOhQkEHztYvnlisyU=json.loads(xTbejgBGWJSKoMOhQkEHztYvnlisVL.text)
   if not('result' in xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']):return xTbejgBGWJSKoMOhQkEHztYvnlisCc,xTbejgBGWJSKoMOhQkEHztYvnlisCR
   xTbejgBGWJSKoMOhQkEHztYvnlisCF=xTbejgBGWJSKoMOhQkEHztYvnlisyU['body']['result']
   xTbejgBGWJSKoMOhQkEHztYvnlisDf =xTbejgBGWJSKoMOhQkEHztYvnlisVX.Get_Now_Datetime()
   xTbejgBGWJSKoMOhQkEHztYvnlisDX=xTbejgBGWJSKoMOhQkEHztYvnlisDf+datetime.timedelta(days=-1)
   xTbejgBGWJSKoMOhQkEHztYvnlisDX=xTbejgBGWJSKoMOhQkEHztYvnlisDa(xTbejgBGWJSKoMOhQkEHztYvnlisDX.strftime('%Y%m%d'))
   for xTbejgBGWJSKoMOhQkEHztYvnlisyN in xTbejgBGWJSKoMOhQkEHztYvnlisCF:
    xTbejgBGWJSKoMOhQkEHztYvnlisDp=xTbejgBGWJSKoMOhQkEHztYvnlisDa(xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('content').get('banner_title2')[:8])
    if xTbejgBGWJSKoMOhQkEHztYvnlisDX<=xTbejgBGWJSKoMOhQkEHztYvnlisDp:
     xTbejgBGWJSKoMOhQkEHztYvnlisfu={'channel':xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('content').get('banner_sub_title3'),'title':xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('content').get('banner_title'),'subtitle':xTbejgBGWJSKoMOhQkEHztYvnlisyN.get('content').get('banner_sub_title2'),}
     xTbejgBGWJSKoMOhQkEHztYvnlisCc.append(xTbejgBGWJSKoMOhQkEHztYvnlisfu)
  except xTbejgBGWJSKoMOhQkEHztYvnlisDA as exception:
   xTbejgBGWJSKoMOhQkEHztYvnlisDU(exception)
  return xTbejgBGWJSKoMOhQkEHztYvnlisCc
# Created by pyminifier (https://github.com/liftoff/pyminifier)
