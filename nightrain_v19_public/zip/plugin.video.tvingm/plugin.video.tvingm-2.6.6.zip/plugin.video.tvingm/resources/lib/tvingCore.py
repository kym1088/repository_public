__author__="NightRain"
wfXdoPGuxgmQsqcvLAWFrbCJDyRElt=print
wfXdoPGuxgmQsqcvLAWFrbCJDyRElU=ImportError
wfXdoPGuxgmQsqcvLAWFrbCJDyRElV=object
wfXdoPGuxgmQsqcvLAWFrbCJDyRElB=None
wfXdoPGuxgmQsqcvLAWFrbCJDyRElj=False
wfXdoPGuxgmQsqcvLAWFrbCJDyRElM=str
wfXdoPGuxgmQsqcvLAWFrbCJDyRElS=open
wfXdoPGuxgmQsqcvLAWFrbCJDyRElh=True
wfXdoPGuxgmQsqcvLAWFrbCJDyRElT=len
wfXdoPGuxgmQsqcvLAWFrbCJDyREla=int
wfXdoPGuxgmQsqcvLAWFrbCJDyRElY=range
wfXdoPGuxgmQsqcvLAWFrbCJDyREkn=bytes
wfXdoPGuxgmQsqcvLAWFrbCJDyREkz=Exception
wfXdoPGuxgmQsqcvLAWFrbCJDyREkp=dict
wfXdoPGuxgmQsqcvLAWFrbCJDyREkK=list
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 wfXdoPGuxgmQsqcvLAWFrbCJDyRElt('Cryptodome')
except wfXdoPGuxgmQsqcvLAWFrbCJDyRElU:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 wfXdoPGuxgmQsqcvLAWFrbCJDyRElt('Crypto')
wfXdoPGuxgmQsqcvLAWFrbCJDyREnp={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
wfXdoPGuxgmQsqcvLAWFrbCJDyREnK ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
wfXdoPGuxgmQsqcvLAWFrbCJDyREnH =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
wfXdoPGuxgmQsqcvLAWFrbCJDyREne=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class wfXdoPGuxgmQsqcvLAWFrbCJDyREnz(wfXdoPGuxgmQsqcvLAWFrbCJDyRElV):
 def __init__(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.NETWORKCODE ='CSND0900'
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.OSCODE ='CSOD0900' 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TELECODE ='CSCD0900'
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.SCREENCODE ='CSSD0100'
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.SCREENCODE_ATV ='CSSD1300' 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.LIVE_LIMIT =20 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.VOD_LIMIT =24 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.EPISODE_LIMIT =30 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.SEARCH_LIMIT =30 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.MOVIE_LIMIT =24 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN ='https://api.tving.com'
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN ='https://image.tving.com'
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.SEARCH_DOMAIN ='https://search-api.tving.com'
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.LOGIN_DOMAIN ='https://user.tving.com'
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.URL_DOMAIN ='https://www.tving.com'
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.MOVIE_LITE =['2610061','2610161','261062']
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.MODEL ='chrome_128.0.0.0' 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.DEFAULT_HEADER ={'user-agent':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.USER_AGENT}
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.COOKIE_FILE_NAME =''
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV_SESSION_COOKIES1=''
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV_SESSION_COOKIES2=''
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV_STREAM_FILENAME =''
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV_SESSION_TEXT1 =''
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV_SESSION_TEXT2 =''
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.KodiVersion=20
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV ={}
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Init_TV_Total()
 def Init_TV_Total(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV={'account':{},'cookies':{},}
 def callRequestCookies(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,jobtype,wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,json=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,redirects=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnl=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.DEFAULT_HEADER
  if headers:wfXdoPGuxgmQsqcvLAWFrbCJDyREnl.update(headers)
  if jobtype=='Get':
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnk=requests.get(wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,params=params,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyREnl,cookies=cookies,allow_redirects=redirects)
  else:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnk=requests.post(wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,data=payload,json=json,params=params,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyREnl,cookies=cookies,allow_redirects=redirects)
  wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnk.status_code)+' - '+wfXdoPGuxgmQsqcvLAWFrbCJDyREnk.url)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREnk
 def JsonFile_Save(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,filename,wfXdoPGuxgmQsqcvLAWFrbCJDyREnO):
  if filename=='':return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  try:
   fp=wfXdoPGuxgmQsqcvLAWFrbCJDyRElS(filename,'w',-1,'utf-8')
   json.dump(wfXdoPGuxgmQsqcvLAWFrbCJDyREnO,fp,indent=4,ensure_ascii=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj)
   fp.close()
  except:
   return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  return wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
 def JsonFile_Load(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,filename):
  if filename=='':return{}
  try:
   fp=wfXdoPGuxgmQsqcvLAWFrbCJDyRElS(filename,'r',-1,'utf-8')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREni=json.load(fp)
   fp.close()
  except:
   return{}
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREni
 def TextFile_Save(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,filename,resText):
  if filename=='':return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  try:
   fp=wfXdoPGuxgmQsqcvLAWFrbCJDyRElS(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  return wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
 def Save_session_acount(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,wfXdoPGuxgmQsqcvLAWFrbCJDyREnt,wfXdoPGuxgmQsqcvLAWFrbCJDyREnU,wfXdoPGuxgmQsqcvLAWFrbCJDyREnV,wfXdoPGuxgmQsqcvLAWFrbCJDyREnB):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['account']['tvid'] =base64.standard_b64encode(wfXdoPGuxgmQsqcvLAWFrbCJDyREnt.encode()).decode('utf-8')
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['account']['tvpw'] =base64.standard_b64encode(wfXdoPGuxgmQsqcvLAWFrbCJDyREnU.encode()).decode('utf-8')
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['account']['tvtype']=wfXdoPGuxgmQsqcvLAWFrbCJDyREnV 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['account']['tvpf'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREnB 
 def Load_session_acount(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI):
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnt =base64.standard_b64decode(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['account']['tvid']).decode('utf-8')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnU =base64.standard_b64decode(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['account']['tvpw']).decode('utf-8')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnV=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['account']['tvtype']
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnB =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREnt,wfXdoPGuxgmQsqcvLAWFrbCJDyREnU,wfXdoPGuxgmQsqcvLAWFrbCJDyREnV,wfXdoPGuxgmQsqcvLAWFrbCJDyREnB
 def make_stream_header(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,wfXdoPGuxgmQsqcvLAWFrbCJDyREnT,wfXdoPGuxgmQsqcvLAWFrbCJDyREnY):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnj=''
  if wfXdoPGuxgmQsqcvLAWFrbCJDyREnY not in[{},wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,'']:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnM=wfXdoPGuxgmQsqcvLAWFrbCJDyRElT(wfXdoPGuxgmQsqcvLAWFrbCJDyREnY)
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREnh in wfXdoPGuxgmQsqcvLAWFrbCJDyREnY.items():
    wfXdoPGuxgmQsqcvLAWFrbCJDyREnj+='{}={}'.format(wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREnh)
    wfXdoPGuxgmQsqcvLAWFrbCJDyREnM+=-1
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREnM>0:wfXdoPGuxgmQsqcvLAWFrbCJDyREnj+='; '
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnT['cookie']=wfXdoPGuxgmQsqcvLAWFrbCJDyREnj
  wfXdoPGuxgmQsqcvLAWFrbCJDyREna=''
  i=0
  for wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREnh in wfXdoPGuxgmQsqcvLAWFrbCJDyREnT.items():
   i=i+1
   if i>1:wfXdoPGuxgmQsqcvLAWFrbCJDyREna+='&'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREna+='{}={}'.format(wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,urllib.parse.quote(wfXdoPGuxgmQsqcvLAWFrbCJDyREnh))
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREna
 def makeDefaultCookies(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnY={}
  for wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREnh in wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies'].items():
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnY[wfXdoPGuxgmQsqcvLAWFrbCJDyREnS]=wfXdoPGuxgmQsqcvLAWFrbCJDyREnh
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREnY
 def getDeviceStr(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzn=[]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzn.append('Windows') 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzn.append('Chrome') 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzn.append('ko-KR') 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzn.append('undefined') 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzn.append('24') 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzn.append(u'한국 표준시')
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzn.append('undefined') 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzn.append('undefined') 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzn.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzp=''
  for wfXdoPGuxgmQsqcvLAWFrbCJDyREzK in wfXdoPGuxgmQsqcvLAWFrbCJDyREzn:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzp+=wfXdoPGuxgmQsqcvLAWFrbCJDyREzK+'|'
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREzp
 def GetDefaultParams(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,uhd=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj):
  if uhd==wfXdoPGuxgmQsqcvLAWFrbCJDyRElj:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzH={'apiKey':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.APIKEY,'networkCode':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.NETWORKCODE,'osCode':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.OSCODE,'teleCode':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TELECODE,'screenCode':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.SCREENCODE,}
  else:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzH={'apiKey':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.APIKEY_ATV,'networkCode':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.NETWORKCODE,'osCode':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.OSCODE,'teleCode':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TELECODE,'screenCode':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.SCREENCODE_ATV,}
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREzH
 def GetNoCache(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,timetype=1):
  if timetype==1:
   return wfXdoPGuxgmQsqcvLAWFrbCJDyREla(time.time())
  else:
   return wfXdoPGuxgmQsqcvLAWFrbCJDyREla(time.time()*1000)
 def GetUniqueid(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,hValue=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB):
  if hValue:
   import hashlib
   wfXdoPGuxgmQsqcvLAWFrbCJDyREze=hashlib.sha1()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREze.update(hValue.encode())
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzI=wfXdoPGuxgmQsqcvLAWFrbCJDyREze.hexdigest()[:8]
  else:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzl=[0 for i in wfXdoPGuxgmQsqcvLAWFrbCJDyRElY(256)]
   for i in wfXdoPGuxgmQsqcvLAWFrbCJDyRElY(256):
    wfXdoPGuxgmQsqcvLAWFrbCJDyREzl[i]='%02x'%(i)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzk=wfXdoPGuxgmQsqcvLAWFrbCJDyREla(4294967295*random.random())|0
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzI=wfXdoPGuxgmQsqcvLAWFrbCJDyREzl[255&wfXdoPGuxgmQsqcvLAWFrbCJDyREzk]+wfXdoPGuxgmQsqcvLAWFrbCJDyREzl[wfXdoPGuxgmQsqcvLAWFrbCJDyREzk>>8&255]+wfXdoPGuxgmQsqcvLAWFrbCJDyREzl[wfXdoPGuxgmQsqcvLAWFrbCJDyREzk>>16&255]+wfXdoPGuxgmQsqcvLAWFrbCJDyREzl[wfXdoPGuxgmQsqcvLAWFrbCJDyREzk>>24&255]
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREzI
 def Web_DecryptKey(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzO=wfXdoPGuxgmQsqcvLAWFrbCJDyREkn('kss2lym0kdw1lks3','utf-8')
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzN=wfXdoPGuxgmQsqcvLAWFrbCJDyREkn('6yhlJ4WF9ZIj6I8n','utf-8')
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREzO,wfXdoPGuxgmQsqcvLAWFrbCJDyREzN
 def Web_EncryptCiphertext(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,wfXdoPGuxgmQsqcvLAWFrbCJDyREzB):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzi,wfXdoPGuxgmQsqcvLAWFrbCJDyREzt=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Web_DecryptKey()
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzU=AES.new(wfXdoPGuxgmQsqcvLAWFrbCJDyREzi,AES.MODE_CBC,wfXdoPGuxgmQsqcvLAWFrbCJDyREzt,)
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzV=wfXdoPGuxgmQsqcvLAWFrbCJDyREzU.encrypt(Padding.pad(wfXdoPGuxgmQsqcvLAWFrbCJDyREzB.encode('utf-8'),16))
  return base64.standard_b64encode(wfXdoPGuxgmQsqcvLAWFrbCJDyREzV).decode('utf-8')
 def Web_DecryptPlaintext(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,wfXdoPGuxgmQsqcvLAWFrbCJDyREzV):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzi,wfXdoPGuxgmQsqcvLAWFrbCJDyREzt=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Web_DecryptKey()
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzU=AES.new(wfXdoPGuxgmQsqcvLAWFrbCJDyREzi,AES.MODE_CBC,wfXdoPGuxgmQsqcvLAWFrbCJDyREzt,)
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzB=Padding.unpad(wfXdoPGuxgmQsqcvLAWFrbCJDyREzU.decrypt(base64.standard_b64decode(wfXdoPGuxgmQsqcvLAWFrbCJDyREzV)),16)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREzB.decode('utf-8')
 def WebCookies_Load(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,wc_file):
  try:
   fp=wfXdoPGuxgmQsqcvLAWFrbCJDyRElS(wc_file,'r',-1,'utf-8')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzj=fp.read()
   fp.close()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzM=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Web_DecryptPlaintext(wfXdoPGuxgmQsqcvLAWFrbCJDyREzj)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREzM)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzS =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDeviceList()
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREzS not in['','-']:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies']['tving_uuid']=wfXdoPGuxgmQsqcvLAWFrbCJDyREzS+'-'+wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetUniqueid(wfXdoPGuxgmQsqcvLAWFrbCJDyREzS)
  except:
   return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  return wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
 def GetCredential2(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,user_id,user_pw,login_type,user_pf):
  try:
   if base64.standard_b64encode(user_id.encode()).decode('utf-8')=='a3ltOTUxMDg4':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREzh='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx'
   else:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREzh='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzT={'addon':'tvingm','method':'LOGIN','data':{'type':login_type,'id':user_id,'pw':user_pw,'pf':user_pf,}}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzT=json.dumps(wfXdoPGuxgmQsqcvLAWFrbCJDyREzT,separators=(',',':'))
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzT=base64.standard_b64encode(wfXdoPGuxgmQsqcvLAWFrbCJDyREzT.encode()).decode('utf-8')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnT={'proxy-mini':wfXdoPGuxgmQsqcvLAWFrbCJDyREzT}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=requests.get(base64.standard_b64decode(wfXdoPGuxgmQsqcvLAWFrbCJDyREzh).decode('utf-8'),headers=wfXdoPGuxgmQsqcvLAWFrbCJDyREnT)
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREza.status_code!=200:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Init_TV_Total()
    return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzY=base64.standard_b64decode(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text).decode('utf-8')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzY=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREzY)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies']=wfXdoPGuxgmQsqcvLAWFrbCJDyREzY
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Init_TV_Total()
   return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  return wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
 def GetCredential(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,user_id,user_pw,login_type,user_pf):
  from curl_cffi import requests
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpn='chrome' 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpz=requests.Session()
  try:
   if login_type=='0':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpK='https://user.tving.com/pc/user/otherLogin.tving?loginType=10&from=pc&csite=&isAuto=false&rtUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   else:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpK='https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnT={'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language':'ko-KR,ko;q=0.9','cache-control':'no-cache','pragma':'no-cache','priority':'u=0, i','referer':'https://www.tving.com/',}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREpz.get(wfXdoPGuxgmQsqcvLAWFrbCJDyREpK,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyREnT,impersonate=wfXdoPGuxgmQsqcvLAWFrbCJDyREpn)
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt('{} - {}'.format(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.status_code,wfXdoPGuxgmQsqcvLAWFrbCJDyREza.url))
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREpH in wfXdoPGuxgmQsqcvLAWFrbCJDyREza.cookies.jar:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies'][wfXdoPGuxgmQsqcvLAWFrbCJDyREpH.name]=wfXdoPGuxgmQsqcvLAWFrbCJDyREpH.value
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Init_TV_Total()
   return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpe=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpI={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':wfXdoPGuxgmQsqcvLAWFrbCJDyRElj,'cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnT['referer']=wfXdoPGuxgmQsqcvLAWFrbCJDyREpK
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREpz.post(url=wfXdoPGuxgmQsqcvLAWFrbCJDyREpe,data=wfXdoPGuxgmQsqcvLAWFrbCJDyREpI,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyREnT,impersonate=wfXdoPGuxgmQsqcvLAWFrbCJDyREpn)
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt('{} - {}'.format(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.status_code,wfXdoPGuxgmQsqcvLAWFrbCJDyREza.url))
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREpH in wfXdoPGuxgmQsqcvLAWFrbCJDyREza.cookies.jar:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies'][wfXdoPGuxgmQsqcvLAWFrbCJDyREpH.name]=wfXdoPGuxgmQsqcvLAWFrbCJDyREpH.value
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Init_TV_Total()
   return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpl=[]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpk =''
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnT['referer']=wfXdoPGuxgmQsqcvLAWFrbCJDyREpe
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREpz.get(url=wfXdoPGuxgmQsqcvLAWFrbCJDyREpO,data=wfXdoPGuxgmQsqcvLAWFrbCJDyREpI,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyREnT,impersonate=wfXdoPGuxgmQsqcvLAWFrbCJDyREpn)
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt('{} - {}'.format(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.status_code,wfXdoPGuxgmQsqcvLAWFrbCJDyREza.url))
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREpH in wfXdoPGuxgmQsqcvLAWFrbCJDyREza.cookies.jar:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies'][wfXdoPGuxgmQsqcvLAWFrbCJDyREpH.name]=wfXdoPGuxgmQsqcvLAWFrbCJDyREpH.value
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpl =re.findall('data-profile-no="\d+"',wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   for i in wfXdoPGuxgmQsqcvLAWFrbCJDyRElY(wfXdoPGuxgmQsqcvLAWFrbCJDyRElT(wfXdoPGuxgmQsqcvLAWFrbCJDyREpl)):
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpN =wfXdoPGuxgmQsqcvLAWFrbCJDyREpl[i].replace('data-profile-no=','').replace('"','')
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpl[i]=wfXdoPGuxgmQsqcvLAWFrbCJDyREpN
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpk=wfXdoPGuxgmQsqcvLAWFrbCJDyREpl[user_pf]
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Init_TV_Total()
   return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpi ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnT['referer']=wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpI={'profileNo':wfXdoPGuxgmQsqcvLAWFrbCJDyREpk}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREpz.post(url=wfXdoPGuxgmQsqcvLAWFrbCJDyREpi,data=wfXdoPGuxgmQsqcvLAWFrbCJDyREpI,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyREnT,impersonate=wfXdoPGuxgmQsqcvLAWFrbCJDyREpn)
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt('{} - {}'.format(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.status_code,wfXdoPGuxgmQsqcvLAWFrbCJDyREza.url))
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREpH in wfXdoPGuxgmQsqcvLAWFrbCJDyREza.cookies.jar:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies'][wfXdoPGuxgmQsqcvLAWFrbCJDyREpH.name]=wfXdoPGuxgmQsqcvLAWFrbCJDyREpH.value
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Init_TV_Total()
   return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzS =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDeviceList()
  if wfXdoPGuxgmQsqcvLAWFrbCJDyREzS not in['','-']:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies']['tving_uuid']=wfXdoPGuxgmQsqcvLAWFrbCJDyREzS+'-'+wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetUniqueid(wfXdoPGuxgmQsqcvLAWFrbCJDyREzS)
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.JsonFile_Save(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.COOKIE_FILE_NAME,wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
 def GetDeviceList(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpt=[]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpU='-'
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v1/user/device/list'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpV=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnY=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.makeDefaultCookies()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREpV,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREpB,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyREnY)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpt=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREpt:
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['model'].lower().startswith('pc'):
     wfXdoPGuxgmQsqcvLAWFrbCJDyREpU=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['uuid']
     break
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREpU=='-':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetNoCache(timetype=1))
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREpU
 def Get_Now_Datetime(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,mediacode,sel_quality,stype,pvrmode='-',optUHD=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREph ={'streaming_url':'','subtitleYn':wfXdoPGuxgmQsqcvLAWFrbCJDyRElj,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpU =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies']['tving_uuid'].split('-')[0] 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpT =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies']['tving_uuid'] 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpa=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj 
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpY=wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetNoCache(1))
   if stype!='tvingtv':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v2/media/stream/info'
    wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':wfXdoPGuxgmQsqcvLAWFrbCJDyREpT,'deviceInfo':'PC','noCache':wfXdoPGuxgmQsqcvLAWFrbCJDyREpY,}
    wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
    wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
    wfXdoPGuxgmQsqcvLAWFrbCJDyREnY=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.makeDefaultCookies()
    wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyREnY)
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREza.status_code!=200:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREph['error_msg']='First Step - {} error'.format(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.status_code)
     return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']['code']=='060':
     for wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREnh in wfXdoPGuxgmQsqcvLAWFrbCJDyREnp.items():
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREnh==sel_quality:
       wfXdoPGuxgmQsqcvLAWFrbCJDyREKz=wfXdoPGuxgmQsqcvLAWFrbCJDyREnS
    elif wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']['code']!='000':
     wfXdoPGuxgmQsqcvLAWFrbCJDyREph['error_msg']=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']['message']
     return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
    else: 
     if not('stream' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']):return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
     wfXdoPGuxgmQsqcvLAWFrbCJDyREKp=[]
     for wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREnh in wfXdoPGuxgmQsqcvLAWFrbCJDyREnp.items():
      for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['stream']['quality']:
       if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['active']=='Y' and wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['code']==wfXdoPGuxgmQsqcvLAWFrbCJDyREnS:
        wfXdoPGuxgmQsqcvLAWFrbCJDyREKp.append({wfXdoPGuxgmQsqcvLAWFrbCJDyREnp.get(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['code']):wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['code']})
     wfXdoPGuxgmQsqcvLAWFrbCJDyREKz=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.CheckQuality(sel_quality,wfXdoPGuxgmQsqcvLAWFrbCJDyREKp)
     try:
      if optUHD==wfXdoPGuxgmQsqcvLAWFrbCJDyRElh and wfXdoPGuxgmQsqcvLAWFrbCJDyREKz=='stream50' and 'stream_support_info' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['content']['info']:
       if wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['content']['info']['stream_support_info']!=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB:
        if 'stream70' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['content']['info']['stream_support_info']:
         wfXdoPGuxgmQsqcvLAWFrbCJDyREKz='stream70'
         wfXdoPGuxgmQsqcvLAWFrbCJDyREpa =wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
     except:
      pass
     try:
      if optUHD==wfXdoPGuxgmQsqcvLAWFrbCJDyRElh and wfXdoPGuxgmQsqcvLAWFrbCJDyREKz=='stream50' and 'stream' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['content']['info']:
       if wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['content']['info']['stream']!=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB:
        for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['content']['info']['stream']:
         if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['code']=='stream70':
          wfXdoPGuxgmQsqcvLAWFrbCJDyREKz='stream70'
          wfXdoPGuxgmQsqcvLAWFrbCJDyREpa =wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
          break
     except:
      pass
   else:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREKz='stream40'
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREph['error_msg']='First Step - except error'
   return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
  wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(wfXdoPGuxgmQsqcvLAWFrbCJDyREKz)
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpY=wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetNoCache(1))
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v3/media/stream/info'
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREpa==wfXdoPGuxgmQsqcvLAWFrbCJDyRElh:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams(uhd=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh)
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'mediaCode':mediacode,'deviceId':wfXdoPGuxgmQsqcvLAWFrbCJDyREpU,'uuid':wfXdoPGuxgmQsqcvLAWFrbCJDyREpT,'deviceInfo':'PC_Chrome WebView','streamCode':wfXdoPGuxgmQsqcvLAWFrbCJDyREKz,'noCache':wfXdoPGuxgmQsqcvLAWFrbCJDyREpY,'callingFrom':'HTML5','model':'chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   else:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'mediaCode':mediacode,'deviceId':wfXdoPGuxgmQsqcvLAWFrbCJDyREpU,'uuid':wfXdoPGuxgmQsqcvLAWFrbCJDyREpT,'deviceInfo':'PC_Chrome','streamCode':wfXdoPGuxgmQsqcvLAWFrbCJDyREKz,'noCache':wfXdoPGuxgmQsqcvLAWFrbCJDyREpY,'callingFrom':'HTML5','model':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnY=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.makeDefaultCookies()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Post',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyREnY,redirects=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']['code']!='000':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREph['error_msg']=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']['message']
    return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKH=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['stream']
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREKH['drm_yn']=='Y':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREKe=wfXdoPGuxgmQsqcvLAWFrbCJDyREKH['playback']['drm']['widevine']
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREKI in wfXdoPGuxgmQsqcvLAWFrbCJDyREKH['playback']['drm']['license']['drm_license_data']:
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREKI['drm_type']=='Widevine':
      wfXdoPGuxgmQsqcvLAWFrbCJDyREph['drm_server_url'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREKI['drm_server_url']
      wfXdoPGuxgmQsqcvLAWFrbCJDyREph['drm_header_key'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREKI['drm_header_key']
      wfXdoPGuxgmQsqcvLAWFrbCJDyREph['drm_header_value']=wfXdoPGuxgmQsqcvLAWFrbCJDyREKI['drm_header_value']
      break
   else:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREKe=wfXdoPGuxgmQsqcvLAWFrbCJDyREKH['playback']['non_drm']
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREph['error_msg']='Second Step - except error'
   return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKl=wfXdoPGuxgmQsqcvLAWFrbCJDyREpY
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKe=wfXdoPGuxgmQsqcvLAWFrbCJDyREKe.split('|')[1]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKe=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Decrypt_Url(wfXdoPGuxgmQsqcvLAWFrbCJDyREKe,mediacode,wfXdoPGuxgmQsqcvLAWFrbCJDyREKl)
  wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url']=wfXdoPGuxgmQsqcvLAWFrbCJDyREKe
  if 'subtitles' in wfXdoPGuxgmQsqcvLAWFrbCJDyREKH:
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREKk in wfXdoPGuxgmQsqcvLAWFrbCJDyREKH.get('subtitles'):
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREKk.get('code')in['KO','KO_CC']:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREph['subtitleYn']=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
     break
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKO=urllib.parse.urlparse(wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url'])
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKN =wfXdoPGuxgmQsqcvLAWFrbCJDyREKO.path.strip('/').split('/')
  wfXdoPGuxgmQsqcvLAWFrbCJDyREph['url_filename']=wfXdoPGuxgmQsqcvLAWFrbCJDyREKN[wfXdoPGuxgmQsqcvLAWFrbCJDyRElT(wfXdoPGuxgmQsqcvLAWFrbCJDyREKN)-1]
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
 def Tving_Parse_mpd(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,stream_url):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREza=requests.get(url=stream_url)
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKi=wfXdoPGuxgmQsqcvLAWFrbCJDyREza.content.decode('utf-8')
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKt=0
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKU =ET.ElementTree(ET.fromstring(wfXdoPGuxgmQsqcvLAWFrbCJDyREKi))
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKV =wfXdoPGuxgmQsqcvLAWFrbCJDyREKU.getroot()
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKB=re.match(r'\{.*\}',wfXdoPGuxgmQsqcvLAWFrbCJDyREKV.tag)[0] 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKj=wfXdoPGuxgmQsqcvLAWFrbCJDyREkp([node for _,node in ET.iterparse(io.StringIO(wfXdoPGuxgmQsqcvLAWFrbCJDyREKi),events=['start-ns'])])
  for wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREHN in wfXdoPGuxgmQsqcvLAWFrbCJDyREKj.items():
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREnS!='ns2':
    ET.register_namespace(wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREHN)
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKM=wfXdoPGuxgmQsqcvLAWFrbCJDyREKV.find(wfXdoPGuxgmQsqcvLAWFrbCJDyREKB+'Period')
  for wfXdoPGuxgmQsqcvLAWFrbCJDyREKS in wfXdoPGuxgmQsqcvLAWFrbCJDyREKM.findall(wfXdoPGuxgmQsqcvLAWFrbCJDyREKB+'AdaptationSet'):
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREKS.attrib.get('mimeType')=='video/mp4':
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREKh in wfXdoPGuxgmQsqcvLAWFrbCJDyREKS.findall(wfXdoPGuxgmQsqcvLAWFrbCJDyREKB+'Representation'):
     wfXdoPGuxgmQsqcvLAWFrbCJDyREKT=wfXdoPGuxgmQsqcvLAWFrbCJDyREla(wfXdoPGuxgmQsqcvLAWFrbCJDyREKh.attrib.get('bandwidth'))
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREKt<wfXdoPGuxgmQsqcvLAWFrbCJDyREKT:wfXdoPGuxgmQsqcvLAWFrbCJDyREKt=wfXdoPGuxgmQsqcvLAWFrbCJDyREKT
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREKh in wfXdoPGuxgmQsqcvLAWFrbCJDyREKS.findall(wfXdoPGuxgmQsqcvLAWFrbCJDyREKB+'Representation'):
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREKt>wfXdoPGuxgmQsqcvLAWFrbCJDyREla(wfXdoPGuxgmQsqcvLAWFrbCJDyREKh.attrib.get('bandwidth')):
      wfXdoPGuxgmQsqcvLAWFrbCJDyREKS.remove(wfXdoPGuxgmQsqcvLAWFrbCJDyREKh)
   else:
    continue
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKa=ET.tostring(wfXdoPGuxgmQsqcvLAWFrbCJDyREKV).decode('utf-8')
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKY='<?xml version="1.0" encoding="UTF-8"?>\n'
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TextFile_Save(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV_STREAM_FILENAME,wfXdoPGuxgmQsqcvLAWFrbCJDyREKY+wfXdoPGuxgmQsqcvLAWFrbCJDyREKa)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
 def Tving_Parse_m3u8(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,stream_url):
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=requests.get(url=stream_url,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,stream=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHn=wfXdoPGuxgmQsqcvLAWFrbCJDyREza.content.decode('utf-8')
   if '#EXTM3U' not in wfXdoPGuxgmQsqcvLAWFrbCJDyREHn:
    return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
   if '#EXT-X-STREAM-INF' not in wfXdoPGuxgmQsqcvLAWFrbCJDyREHn: 
    return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHz=0
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREHp in wfXdoPGuxgmQsqcvLAWFrbCJDyREHn.splitlines():
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREHp.startswith('#EXT-X-STREAM-INF'):
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHK=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.MediaLine_Parse(wfXdoPGuxgmQsqcvLAWFrbCJDyREHp,'#EXT-X-STREAM-INF')
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREHz<wfXdoPGuxgmQsqcvLAWFrbCJDyREla(wfXdoPGuxgmQsqcvLAWFrbCJDyREHK.get('BANDWIDTH')):
      wfXdoPGuxgmQsqcvLAWFrbCJDyREHz=wfXdoPGuxgmQsqcvLAWFrbCJDyREla(wfXdoPGuxgmQsqcvLAWFrbCJDyREHK.get('BANDWIDTH'))
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHe=[]
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHI=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREHp in wfXdoPGuxgmQsqcvLAWFrbCJDyREHn.splitlines():
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREHI==wfXdoPGuxgmQsqcvLAWFrbCJDyRElh:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHI=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
     continue
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREHp.startswith('#EXT-X-STREAM-INF'):
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHK=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.MediaLine_Parse(wfXdoPGuxgmQsqcvLAWFrbCJDyREHp,'#EXT-X-STREAM-INF')
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREHz!=wfXdoPGuxgmQsqcvLAWFrbCJDyREla(wfXdoPGuxgmQsqcvLAWFrbCJDyREHK.get('BANDWIDTH')):
      wfXdoPGuxgmQsqcvLAWFrbCJDyREHI=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
      continue
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHe.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREHp)
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
   return wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  wfXdoPGuxgmQsqcvLAWFrbCJDyREHl='\n'.join(wfXdoPGuxgmQsqcvLAWFrbCJDyREHe)
  wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TextFile_Save(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV_STREAM_FILENAME,wfXdoPGuxgmQsqcvLAWFrbCJDyREHl)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
 def MediaLine_Parse(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,wfXdoPGuxgmQsqcvLAWFrbCJDyREHp,prefix):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREHK={}
  for wfXdoPGuxgmQsqcvLAWFrbCJDyREHk in wfXdoPGuxgmQsqcvLAWFrbCJDyREnH.split(wfXdoPGuxgmQsqcvLAWFrbCJDyREHp.replace(prefix+':',''))[1::2]:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHO,wfXdoPGuxgmQsqcvLAWFrbCJDyREHN=wfXdoPGuxgmQsqcvLAWFrbCJDyREHk.split('=',1)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHK[wfXdoPGuxgmQsqcvLAWFrbCJDyREHO.upper()]=wfXdoPGuxgmQsqcvLAWFrbCJDyREHN.replace('"','').strip()
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREHK
 def CheckQuality(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,sel_qt,wfXdoPGuxgmQsqcvLAWFrbCJDyREKp):
  for wfXdoPGuxgmQsqcvLAWFrbCJDyREHi in wfXdoPGuxgmQsqcvLAWFrbCJDyREKp:
   if sel_qt>=wfXdoPGuxgmQsqcvLAWFrbCJDyREkK(wfXdoPGuxgmQsqcvLAWFrbCJDyREHi)[0]:return wfXdoPGuxgmQsqcvLAWFrbCJDyREHi.get(wfXdoPGuxgmQsqcvLAWFrbCJDyREkK(wfXdoPGuxgmQsqcvLAWFrbCJDyREHi)[0])
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHt=wfXdoPGuxgmQsqcvLAWFrbCJDyREHi.get(wfXdoPGuxgmQsqcvLAWFrbCJDyREkK(wfXdoPGuxgmQsqcvLAWFrbCJDyREHi)[0])
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREHt
 def makeOocUrl(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,ooc_params):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=''
  for wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREnh in ooc_params.items():
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh+="%s=%s^"%(wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREnh)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREzh
 def GetLiveChannelList(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,stype,page_int):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpt=[]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v2/media/lives'
   if stype=='onair': 
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHV='CPCS0100,CPCS0400'
   else:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHV='CPCS0300'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'cacheType':'main','pageNo':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(page_int),'pageSize':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':wfXdoPGuxgmQsqcvLAWFrbCJDyREHV,}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if not('result' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']):return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHB=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREHB:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHj=wfXdoPGuxgmQsqcvLAWFrbCJDyREHh=wfXdoPGuxgmQsqcvLAWFrbCJDyREHT=''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHM=wfXdoPGuxgmQsqcvLAWFrbCJDyREeB=''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHS=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['live_code']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHj =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['channel']['name']['ko']
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['episode']!=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHh =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['program']['name']['ko']
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHh =wfXdoPGuxgmQsqcvLAWFrbCJDyREHh+', '+wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['episode']['frequency'])+'회'
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHT=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['episode']['synopsis']['ko']
    else:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHh =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['program']['name']['ko']
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHT=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['program']['synopsis']['ko']
    try: 
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =''
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =''
     wfXdoPGuxgmQsqcvLAWFrbCJDyREen=''
     wfXdoPGuxgmQsqcvLAWFrbCJDyREez =''
     wfXdoPGuxgmQsqcvLAWFrbCJDyREep =''
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeK =''
     for wfXdoPGuxgmQsqcvLAWFrbCJDyREeH in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['program']['image']:
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP0900':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
      elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP1800':wfXdoPGuxgmQsqcvLAWFrbCJDyREen=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
      elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP2000':wfXdoPGuxgmQsqcvLAWFrbCJDyREez =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
      elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP1900':wfXdoPGuxgmQsqcvLAWFrbCJDyREep =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
      elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP0200':wfXdoPGuxgmQsqcvLAWFrbCJDyREeK =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
      elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP0500':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
      elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP0800':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREHa=='':
      for wfXdoPGuxgmQsqcvLAWFrbCJDyREeH in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['channel']['image']:
       if wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIC0400':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
       elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIC1400':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
       elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIC1900':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
    except:
     wfXdoPGuxgmQsqcvLAWFrbCJDyRElB
    try:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeI =[]
     wfXdoPGuxgmQsqcvLAWFrbCJDyREel=[]
     wfXdoPGuxgmQsqcvLAWFrbCJDyREek =[]
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeO=''
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeN=''
     wfXdoPGuxgmQsqcvLAWFrbCJDyREei=''
     for wfXdoPGuxgmQsqcvLAWFrbCJDyREet in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('schedule').get('program').get('actor'):
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREet!='' and wfXdoPGuxgmQsqcvLAWFrbCJDyREet!=u'없음':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREet)
     for wfXdoPGuxgmQsqcvLAWFrbCJDyREeU in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('schedule').get('program').get('director'):
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREeU!='' and wfXdoPGuxgmQsqcvLAWFrbCJDyREeU!='-' and wfXdoPGuxgmQsqcvLAWFrbCJDyREeU!=u'없음':wfXdoPGuxgmQsqcvLAWFrbCJDyREel.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREeU)
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('schedule').get('program').get('category1_name').get('ko')!='':
      wfXdoPGuxgmQsqcvLAWFrbCJDyREek.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['program']['category1_name']['ko'])
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('schedule').get('program').get('category2_name').get('ko')!='':
      wfXdoPGuxgmQsqcvLAWFrbCJDyREek.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['program']['category2_name']['ko'])
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('schedule').get('program').get('product_year'):wfXdoPGuxgmQsqcvLAWFrbCJDyREeO=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['program']['product_year']
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('schedule').get('program').get('grade_code') :wfXdoPGuxgmQsqcvLAWFrbCJDyREeN= wfXdoPGuxgmQsqcvLAWFrbCJDyREnK.get(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['program']['grade_code'])
     if 'broad_dt' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('schedule').get('program'):
      wfXdoPGuxgmQsqcvLAWFrbCJDyREeV =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('schedule').get('program').get('broad_dt')
      wfXdoPGuxgmQsqcvLAWFrbCJDyREei='%s-%s-%s'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[:4],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[4:6],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[6:])
    except:
     wfXdoPGuxgmQsqcvLAWFrbCJDyRElB
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHM=wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['broadcast_start_time'])[8:12]
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeB =wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['schedule']['broadcast_end_time'])[8:12]
    wfXdoPGuxgmQsqcvLAWFrbCJDyREej={'channel':wfXdoPGuxgmQsqcvLAWFrbCJDyREHj,'title':wfXdoPGuxgmQsqcvLAWFrbCJDyREHh,'mediacode':wfXdoPGuxgmQsqcvLAWFrbCJDyREHS,'thumbnail':{'poster':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY,'thumb':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa,'clearlogo':wfXdoPGuxgmQsqcvLAWFrbCJDyREen,'icon':wfXdoPGuxgmQsqcvLAWFrbCJDyREez,'fanart':wfXdoPGuxgmQsqcvLAWFrbCJDyREeK},'synopsis':wfXdoPGuxgmQsqcvLAWFrbCJDyREHT,'channelepg':' [%s:%s ~ %s:%s]'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREHM[0:2],wfXdoPGuxgmQsqcvLAWFrbCJDyREHM[2:],wfXdoPGuxgmQsqcvLAWFrbCJDyREeB[0:2],wfXdoPGuxgmQsqcvLAWFrbCJDyREeB[2:]),'cast':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI,'director':wfXdoPGuxgmQsqcvLAWFrbCJDyREel,'info_genre':wfXdoPGuxgmQsqcvLAWFrbCJDyREek,'year':wfXdoPGuxgmQsqcvLAWFrbCJDyREeO,'mpaa':wfXdoPGuxgmQsqcvLAWFrbCJDyREeN,'premiered':wfXdoPGuxgmQsqcvLAWFrbCJDyREei}
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpt.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREej)
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['has_more']=='Y':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
 def GetProgramList(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,genre,orderby,page_int,genreCode='all'):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpt=[]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  try:
   if genre=='PARAMOUNT':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v2/media/paramount/episodes'
   else:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v2/media/episodes'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'cacheType':'main','pageSize':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(page_int),}
   if genre not in['all','PARAMOUNT']:wfXdoPGuxgmQsqcvLAWFrbCJDyREpB['categoryCode']=genre
   if genreCode!='all' :wfXdoPGuxgmQsqcvLAWFrbCJDyREpB['genreCode'] =genreCode 
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if not('result' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']):return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHB=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREHB:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeM=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['program']['code']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHh =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['program']['name']['ko']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeN =wfXdoPGuxgmQsqcvLAWFrbCJDyREnK.get(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['program'].get('grade_code'))
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREen=''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREez =''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREep =''
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREeH in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['program']['image']:
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP0900':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP0200':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP1800':wfXdoPGuxgmQsqcvLAWFrbCJDyREen=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP2000':wfXdoPGuxgmQsqcvLAWFrbCJDyREez =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP1900':wfXdoPGuxgmQsqcvLAWFrbCJDyREep =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHT =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['program']['synopsis']['ko']
    try:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeS=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['channel']['name']['ko']
    except:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeS=''
    try:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeI =[]
     wfXdoPGuxgmQsqcvLAWFrbCJDyREel=[]
     wfXdoPGuxgmQsqcvLAWFrbCJDyREek =[]
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeO =''
     wfXdoPGuxgmQsqcvLAWFrbCJDyREei=''
     for wfXdoPGuxgmQsqcvLAWFrbCJDyREet in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('program').get('actor'):
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREet!='' and wfXdoPGuxgmQsqcvLAWFrbCJDyREet!='-' and wfXdoPGuxgmQsqcvLAWFrbCJDyREet!=u'없음':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREet)
     for wfXdoPGuxgmQsqcvLAWFrbCJDyREeU in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('program').get('director'):
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREeU!='' and wfXdoPGuxgmQsqcvLAWFrbCJDyREeU!='-' and wfXdoPGuxgmQsqcvLAWFrbCJDyREeU!=u'없음':wfXdoPGuxgmQsqcvLAWFrbCJDyREel.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREeU)
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('program').get('category1_name').get('ko')!='':
      wfXdoPGuxgmQsqcvLAWFrbCJDyREek.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['program']['category1_name']['ko'])
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('program').get('category2_name').get('ko')!='':
      wfXdoPGuxgmQsqcvLAWFrbCJDyREek.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['program']['category2_name']['ko'])
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('program').get('product_year'):wfXdoPGuxgmQsqcvLAWFrbCJDyREeO=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['program']['product_year']
     if 'broad_dt' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('program'):
      wfXdoPGuxgmQsqcvLAWFrbCJDyREeV =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('program').get('broad_dt')
      wfXdoPGuxgmQsqcvLAWFrbCJDyREei='%s-%s-%s'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[:4],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[4:6],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[6:])
    except:
     wfXdoPGuxgmQsqcvLAWFrbCJDyRElB
    wfXdoPGuxgmQsqcvLAWFrbCJDyREej={'program':wfXdoPGuxgmQsqcvLAWFrbCJDyREeM,'title':wfXdoPGuxgmQsqcvLAWFrbCJDyREHh,'thumbnail':{'poster':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY,'thumb':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa,'clearlogo':wfXdoPGuxgmQsqcvLAWFrbCJDyREen,'icon':wfXdoPGuxgmQsqcvLAWFrbCJDyREez,'banner':wfXdoPGuxgmQsqcvLAWFrbCJDyREep,'fanart':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa},'synopsis':wfXdoPGuxgmQsqcvLAWFrbCJDyREHT,'channel':wfXdoPGuxgmQsqcvLAWFrbCJDyREeS,'cast':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI,'director':wfXdoPGuxgmQsqcvLAWFrbCJDyREel,'info_genre':wfXdoPGuxgmQsqcvLAWFrbCJDyREek,'year':wfXdoPGuxgmQsqcvLAWFrbCJDyREeO,'premiered':wfXdoPGuxgmQsqcvLAWFrbCJDyREei,'mpaa':wfXdoPGuxgmQsqcvLAWFrbCJDyREeN}
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpt.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREej)
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['has_more']=='Y':wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
 def Get_UHD_ProgramList(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,page_int):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpt=[]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v2/operator/highlights'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams(uhd=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(page_int),'pocType':'APP_X_TVING_4.0.0',}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if not('result' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']):return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHB=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREHB:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeh=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['content']['program']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeT =wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['code']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHh =wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['name']['ko'].strip()
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeN =wfXdoPGuxgmQsqcvLAWFrbCJDyREnK.get(wfXdoPGuxgmQsqcvLAWFrbCJDyREeh.get('grade_code'))
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHT =wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['synopsis']['ko']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeS =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['content']['channel']['name']['ko']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeO =wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['product_year']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREen=''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREez =''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREep =''
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREeH in wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['image']:
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP0900':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP0200':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP1800':wfXdoPGuxgmQsqcvLAWFrbCJDyREen=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP2000':wfXdoPGuxgmQsqcvLAWFrbCJDyREez =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP1900':wfXdoPGuxgmQsqcvLAWFrbCJDyREep =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREek =[]
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeI =[]
    wfXdoPGuxgmQsqcvLAWFrbCJDyREel=[]
    wfXdoPGuxgmQsqcvLAWFrbCJDyREei =''
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREeh.get('category1_name').get('ko')!='':
     wfXdoPGuxgmQsqcvLAWFrbCJDyREek.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['category1_name']['ko'])
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREeh.get('category2_name').get('ko')!='':
     wfXdoPGuxgmQsqcvLAWFrbCJDyREek.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['category2_name']['ko'])
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREet in wfXdoPGuxgmQsqcvLAWFrbCJDyREeh.get('actor'):
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREet!='' and wfXdoPGuxgmQsqcvLAWFrbCJDyREet!='-' and wfXdoPGuxgmQsqcvLAWFrbCJDyREet!=u'없음':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREet)
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREeU in wfXdoPGuxgmQsqcvLAWFrbCJDyREeh.get('director'):
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREeU!='' and wfXdoPGuxgmQsqcvLAWFrbCJDyREeU!='-' and wfXdoPGuxgmQsqcvLAWFrbCJDyREeU!=u'없음':wfXdoPGuxgmQsqcvLAWFrbCJDyREel.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREeU)
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREeh.get('broad_dt')not in[wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,'']:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeV =wfXdoPGuxgmQsqcvLAWFrbCJDyREeh.get('broad_dt')
     wfXdoPGuxgmQsqcvLAWFrbCJDyREei='%s-%s-%s'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[:4],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[4:6],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[6:])
    wfXdoPGuxgmQsqcvLAWFrbCJDyREej={'program':wfXdoPGuxgmQsqcvLAWFrbCJDyREeT,'title':wfXdoPGuxgmQsqcvLAWFrbCJDyREHh,'mpaa':wfXdoPGuxgmQsqcvLAWFrbCJDyREeN,'thumbnail':{'poster':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY,'thumb':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa,'clearlogo':wfXdoPGuxgmQsqcvLAWFrbCJDyREen,'icon':wfXdoPGuxgmQsqcvLAWFrbCJDyREez,'banner':wfXdoPGuxgmQsqcvLAWFrbCJDyREep,'fanart':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa},'channel':wfXdoPGuxgmQsqcvLAWFrbCJDyREeS,'synopsis':wfXdoPGuxgmQsqcvLAWFrbCJDyREHT,'year':wfXdoPGuxgmQsqcvLAWFrbCJDyREeO,'info_genre':wfXdoPGuxgmQsqcvLAWFrbCJDyREek,'cast':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI,'director':wfXdoPGuxgmQsqcvLAWFrbCJDyREel,'premiered':wfXdoPGuxgmQsqcvLAWFrbCJDyREei,}
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpt.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREej)
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
 def Get_Origianl_ProgramList(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,page_int):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpt=[]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v2/media/band/originals'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'pageSize':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(page_int),}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREea=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.JsonFile_Save(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV_SESSION_COOKIES2,wfXdoPGuxgmQsqcvLAWFrbCJDyREea)
   if not('contents' in wfXdoPGuxgmQsqcvLAWFrbCJDyREea['body']):return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHB=wfXdoPGuxgmQsqcvLAWFrbCJDyREea['body']['contents']
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREHB:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeY =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['vod_code']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHh =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['vod_name']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['image']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIn ='movie' if wfXdoPGuxgmQsqcvLAWFrbCJDyREeY.startswith('M')else 'vod'
    wfXdoPGuxgmQsqcvLAWFrbCJDyREej={'vod_code':wfXdoPGuxgmQsqcvLAWFrbCJDyREeY,'title':wfXdoPGuxgmQsqcvLAWFrbCJDyREHh,'thumbnail':{'poster':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY,'thumb':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY},'vod_type':wfXdoPGuxgmQsqcvLAWFrbCJDyREIn,}
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpt.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREej)
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREea['body']['has_more']=='Y':wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
 def GetEpisodeList(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,program_code,page_int,orderby='desc'):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpt=[]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v2/media/frequency/program/'+program_code
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if not('result' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']):return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHB=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIz=wfXdoPGuxgmQsqcvLAWFrbCJDyREla(wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['total_count'])
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIp =wfXdoPGuxgmQsqcvLAWFrbCJDyREla(wfXdoPGuxgmQsqcvLAWFrbCJDyREIz//(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIK =(wfXdoPGuxgmQsqcvLAWFrbCJDyREIz-1)-((page_int-1)*wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.EPISODE_LIMIT)
   else:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIK =(page_int-1)*wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.EPISODE_LIMIT
   for i in wfXdoPGuxgmQsqcvLAWFrbCJDyRElY(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.EPISODE_LIMIT):
    if orderby=='desc':
     wfXdoPGuxgmQsqcvLAWFrbCJDyREIH=wfXdoPGuxgmQsqcvLAWFrbCJDyREIK-i
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREIH<0:break
    else:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREIH=wfXdoPGuxgmQsqcvLAWFrbCJDyREIK+i
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREIH>=wfXdoPGuxgmQsqcvLAWFrbCJDyREIz:break
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIe=wfXdoPGuxgmQsqcvLAWFrbCJDyREHB[wfXdoPGuxgmQsqcvLAWFrbCJDyREIH]['episode']['code']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHh =wfXdoPGuxgmQsqcvLAWFrbCJDyREHB[wfXdoPGuxgmQsqcvLAWFrbCJDyREIH]['vod_name']['ko']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIl =''
    try:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeV=wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREHB[wfXdoPGuxgmQsqcvLAWFrbCJDyREIH]['episode']['broadcast_date'])
     wfXdoPGuxgmQsqcvLAWFrbCJDyREIl='%s-%s-%s'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[:4],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[4:6],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[6:])
    except:
     wfXdoPGuxgmQsqcvLAWFrbCJDyRElB
    try:
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREHB[wfXdoPGuxgmQsqcvLAWFrbCJDyREIH]['episode']['pip_cliptype']=='C012':
      wfXdoPGuxgmQsqcvLAWFrbCJDyREIl+=' - Quick VOD'
    except:
     wfXdoPGuxgmQsqcvLAWFrbCJDyRElB
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHT =wfXdoPGuxgmQsqcvLAWFrbCJDyREHB[wfXdoPGuxgmQsqcvLAWFrbCJDyREIH]['episode']['synopsis']['ko']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREen=''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREez =''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREep =''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeK =''
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREeH in wfXdoPGuxgmQsqcvLAWFrbCJDyREHB[wfXdoPGuxgmQsqcvLAWFrbCJDyREIH]['program']['image']:
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP0900':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP1800':wfXdoPGuxgmQsqcvLAWFrbCJDyREen=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP2000':wfXdoPGuxgmQsqcvLAWFrbCJDyREez =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP1900':wfXdoPGuxgmQsqcvLAWFrbCJDyREep =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIP0200':wfXdoPGuxgmQsqcvLAWFrbCJDyREeK =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREeH in wfXdoPGuxgmQsqcvLAWFrbCJDyREHB[wfXdoPGuxgmQsqcvLAWFrbCJDyREIH]['episode']['image']:
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIE0400':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
    try:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREIk=wfXdoPGuxgmQsqcvLAWFrbCJDyREIN=wfXdoPGuxgmQsqcvLAWFrbCJDyREIi=''
     wfXdoPGuxgmQsqcvLAWFrbCJDyREIO=0
     wfXdoPGuxgmQsqcvLAWFrbCJDyREIk =wfXdoPGuxgmQsqcvLAWFrbCJDyREHB[wfXdoPGuxgmQsqcvLAWFrbCJDyREIH]['program']['name']['ko']
     wfXdoPGuxgmQsqcvLAWFrbCJDyREIN =wfXdoPGuxgmQsqcvLAWFrbCJDyREIl
     wfXdoPGuxgmQsqcvLAWFrbCJDyREIi =wfXdoPGuxgmQsqcvLAWFrbCJDyREHB[wfXdoPGuxgmQsqcvLAWFrbCJDyREIH]['channel']['name']['ko']
     if 'frequency' in wfXdoPGuxgmQsqcvLAWFrbCJDyREHB[wfXdoPGuxgmQsqcvLAWFrbCJDyREIH]['episode']:wfXdoPGuxgmQsqcvLAWFrbCJDyREIO=wfXdoPGuxgmQsqcvLAWFrbCJDyREHB[wfXdoPGuxgmQsqcvLAWFrbCJDyREIH]['episode']['frequency']
    except:
     wfXdoPGuxgmQsqcvLAWFrbCJDyRElB
    wfXdoPGuxgmQsqcvLAWFrbCJDyREej={'episode':wfXdoPGuxgmQsqcvLAWFrbCJDyREIe,'title':wfXdoPGuxgmQsqcvLAWFrbCJDyREHh,'subtitle':wfXdoPGuxgmQsqcvLAWFrbCJDyREIl,'thumbnail':{'poster':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY,'thumb':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa,'clearlogo':wfXdoPGuxgmQsqcvLAWFrbCJDyREen,'icon':wfXdoPGuxgmQsqcvLAWFrbCJDyREez,'banner':wfXdoPGuxgmQsqcvLAWFrbCJDyREep,'fanart':wfXdoPGuxgmQsqcvLAWFrbCJDyREeK},'synopsis':wfXdoPGuxgmQsqcvLAWFrbCJDyREHT,'info_title':wfXdoPGuxgmQsqcvLAWFrbCJDyREIk,'aired':wfXdoPGuxgmQsqcvLAWFrbCJDyREIN,'studio':wfXdoPGuxgmQsqcvLAWFrbCJDyREIi,'frequency':wfXdoPGuxgmQsqcvLAWFrbCJDyREIO}
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpt.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREej)
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREIp>page_int:wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU,wfXdoPGuxgmQsqcvLAWFrbCJDyREIp
 def GetMovieList(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,genre,orderby,page_int):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpt=[]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  try:
   if genre=='PARAMOUNT':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v2/media/paramount/movies'
   else:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v2/media/movies'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'pageSize':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:wfXdoPGuxgmQsqcvLAWFrbCJDyREpB['categoryCode']=genre
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB['productPackageCode']=','.join(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.MOVIE_LITE)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if not('result' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']):return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHB=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREHB:
    if 'release_date' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('movie'):
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeO=wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('movie').get('release_date'))[:4]
    else:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeO=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIt =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['movie']['code']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHh =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['movie']['name']['ko'].strip()
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREeO not in[wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,'0','']:wfXdoPGuxgmQsqcvLAWFrbCJDyREHh+=u' (%s)'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREeO)
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHY=''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREen=''
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREeH in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['movie']['image']:
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIM2100':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIM0400':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIM1800':wfXdoPGuxgmQsqcvLAWFrbCJDyREen=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHT =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['movie']['story']['ko']
    try:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREIk =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['movie']['name']['ko'].strip()
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeN =wfXdoPGuxgmQsqcvLAWFrbCJDyREnK.get(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('grade_code'))
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeI=[]
     wfXdoPGuxgmQsqcvLAWFrbCJDyREel=[]
     wfXdoPGuxgmQsqcvLAWFrbCJDyREek=[]
     wfXdoPGuxgmQsqcvLAWFrbCJDyREIU=0
     wfXdoPGuxgmQsqcvLAWFrbCJDyREei=''
     wfXdoPGuxgmQsqcvLAWFrbCJDyREIi =''
     for wfXdoPGuxgmQsqcvLAWFrbCJDyREet in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('movie').get('actor'):
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREet!='':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREet)
     for wfXdoPGuxgmQsqcvLAWFrbCJDyREeU in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('movie').get('director'):
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREeU!='':wfXdoPGuxgmQsqcvLAWFrbCJDyREel.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREeU)
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('movie').get('category1_name').get('ko')!='':
      wfXdoPGuxgmQsqcvLAWFrbCJDyREek.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['movie']['category1_name']['ko'])
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('movie').get('category2_name').get('ko')!='':
      wfXdoPGuxgmQsqcvLAWFrbCJDyREek.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['movie']['category2_name']['ko'])
     if 'duration' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('movie'):wfXdoPGuxgmQsqcvLAWFrbCJDyREIU=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('movie').get('duration')
     if 'release_date' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('movie'):
      wfXdoPGuxgmQsqcvLAWFrbCJDyREeV=wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('movie').get('release_date'))
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREeV!='0':wfXdoPGuxgmQsqcvLAWFrbCJDyREei='%s-%s-%s'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[:4],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[4:6],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[6:])
     if 'production' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('movie'):wfXdoPGuxgmQsqcvLAWFrbCJDyREIi=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('movie').get('production')
    except:
     wfXdoPGuxgmQsqcvLAWFrbCJDyRElB
    wfXdoPGuxgmQsqcvLAWFrbCJDyREej={'moviecode':wfXdoPGuxgmQsqcvLAWFrbCJDyREIt,'title':wfXdoPGuxgmQsqcvLAWFrbCJDyREHh,'thumbnail':{'poster':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY,'thumb':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa,'clearlogo':wfXdoPGuxgmQsqcvLAWFrbCJDyREen,'fanart':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa},'synopsis':wfXdoPGuxgmQsqcvLAWFrbCJDyREHT,'info_title':wfXdoPGuxgmQsqcvLAWFrbCJDyREIk,'year':wfXdoPGuxgmQsqcvLAWFrbCJDyREeO,'cast':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI,'director':wfXdoPGuxgmQsqcvLAWFrbCJDyREel,'info_genre':wfXdoPGuxgmQsqcvLAWFrbCJDyREek,'duration':wfXdoPGuxgmQsqcvLAWFrbCJDyREIU,'premiered':wfXdoPGuxgmQsqcvLAWFrbCJDyREei,'studio':wfXdoPGuxgmQsqcvLAWFrbCJDyREIi,'mpaa':wfXdoPGuxgmQsqcvLAWFrbCJDyREeN}
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIV=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREIB in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['billing_package_id']:
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREIB in wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.MOVIE_LITE:
      wfXdoPGuxgmQsqcvLAWFrbCJDyREIV=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
      break
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREIV==wfXdoPGuxgmQsqcvLAWFrbCJDyRElj: 
     wfXdoPGuxgmQsqcvLAWFrbCJDyREej['title']=wfXdoPGuxgmQsqcvLAWFrbCJDyREej['title']+' [개별구매]'
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpt.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREej)
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['has_more']=='Y':wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
 def Get_UHD_MovieList(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,page_int):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpt=[]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v2/operator/highlights'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams(uhd=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(page_int),'pocType':'APP_X_TVING_4.0.0',}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if not('result' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']):return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHB=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREHB:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeh=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['content']['movie']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeT =wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['code']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHh =wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['name']['ko'].strip()
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIk =wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['name']['ko'].strip()
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeO =wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['product_year']
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREeO:wfXdoPGuxgmQsqcvLAWFrbCJDyREHh+=u' (%s)'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['product_year'])
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHT =wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['story']['ko']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIU =wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['duration']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeN =wfXdoPGuxgmQsqcvLAWFrbCJDyREnK.get(wfXdoPGuxgmQsqcvLAWFrbCJDyREeh.get('grade_code'))
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIi =wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['production']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHY=''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREen=''
    wfXdoPGuxgmQsqcvLAWFrbCJDyREek =[]
    wfXdoPGuxgmQsqcvLAWFrbCJDyREeI =[]
    wfXdoPGuxgmQsqcvLAWFrbCJDyREel=[]
    wfXdoPGuxgmQsqcvLAWFrbCJDyREei =''
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREeH in wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['image']:
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIM2100':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIM0400':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
     elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['code']=='CAIM1800':wfXdoPGuxgmQsqcvLAWFrbCJDyREen=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH['url']
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['release_date']not in[wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,0]:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeV=wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['release_date'])
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREeV!='0':wfXdoPGuxgmQsqcvLAWFrbCJDyREei='%s-%s-%s'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[:4],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[4:6],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[6:])
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREeh.get('category1_name').get('ko')!='':
     wfXdoPGuxgmQsqcvLAWFrbCJDyREek.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['category1_name']['ko'])
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREeh.get('category2_name').get('ko')!='':
     wfXdoPGuxgmQsqcvLAWFrbCJDyREek.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREeh['category2_name']['ko'])
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREet in wfXdoPGuxgmQsqcvLAWFrbCJDyREeh.get('actor'):
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREet!='':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREet)
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREeU in wfXdoPGuxgmQsqcvLAWFrbCJDyREeh.get('director'):
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREeU!='':wfXdoPGuxgmQsqcvLAWFrbCJDyREel.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREeU)
    wfXdoPGuxgmQsqcvLAWFrbCJDyREej={'moviecode':wfXdoPGuxgmQsqcvLAWFrbCJDyREeT,'title':wfXdoPGuxgmQsqcvLAWFrbCJDyREHh,'thumbnail':{'poster':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY,'thumb':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa,'clearlogo':wfXdoPGuxgmQsqcvLAWFrbCJDyREen,'fanart':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa},'year':wfXdoPGuxgmQsqcvLAWFrbCJDyREeO,'info_title':wfXdoPGuxgmQsqcvLAWFrbCJDyREIk,'synopsis':wfXdoPGuxgmQsqcvLAWFrbCJDyREHT,'mpaa':wfXdoPGuxgmQsqcvLAWFrbCJDyREeN,'duration':wfXdoPGuxgmQsqcvLAWFrbCJDyREIU,'premiered':wfXdoPGuxgmQsqcvLAWFrbCJDyREei,'studio':wfXdoPGuxgmQsqcvLAWFrbCJDyREIi,'info_genre':wfXdoPGuxgmQsqcvLAWFrbCJDyREek,'cast':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI,'director':wfXdoPGuxgmQsqcvLAWFrbCJDyREel,}
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpt.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREej)
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
 def GetMovieGenre(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpt=[]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v2/media/movie/curations'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if not('result' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']):return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHB=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREHB:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIj =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['curation_code']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIM =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['curation_name']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREej={'curation_code':wfXdoPGuxgmQsqcvLAWFrbCJDyREIj,'curation_name':wfXdoPGuxgmQsqcvLAWFrbCJDyREIM}
    wfXdoPGuxgmQsqcvLAWFrbCJDyREpt.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREej)
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
 def GetSearchList(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,search_key,page_int,stype):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREIS=[]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElj
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/search/getSearch.jsp'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.SCREENCODE,'os':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.OSCODE,'network':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.APIKEY,'networkCode':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.NETWORKCODE,'osCode ':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.OSCODE,'teleCode ':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TELECODE,'screenCode ':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.SCREENCODE}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.SEARCH_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREpB,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if stype=='vod':
    if not('programRsb' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj):return wfXdoPGuxgmQsqcvLAWFrbCJDyREIS,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIh=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['programRsb']['dataList']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIT =wfXdoPGuxgmQsqcvLAWFrbCJDyREla(wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['programRsb']['count'])
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREIh:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeM=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['mast_cd']
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHh =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['mast_nm']
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHY=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['web_url4']
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['web_url']
     try:
      wfXdoPGuxgmQsqcvLAWFrbCJDyREeI =[]
      wfXdoPGuxgmQsqcvLAWFrbCJDyREel=[]
      wfXdoPGuxgmQsqcvLAWFrbCJDyREek =[]
      wfXdoPGuxgmQsqcvLAWFrbCJDyREIU =0
      wfXdoPGuxgmQsqcvLAWFrbCJDyREeN =''
      wfXdoPGuxgmQsqcvLAWFrbCJDyREeO =''
      wfXdoPGuxgmQsqcvLAWFrbCJDyREIN =''
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('actor') !='' and wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('actor') !='-':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('actor').split(',')
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('director')!='' and wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('director')!='-':wfXdoPGuxgmQsqcvLAWFrbCJDyREel=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('director').split(',')
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('cate_nm')!='' and wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('cate_nm')!='-':wfXdoPGuxgmQsqcvLAWFrbCJDyREek =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('cate_nm').split('/')
      if 'targetage' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM:wfXdoPGuxgmQsqcvLAWFrbCJDyREeN=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('targetage')
      if 'broad_dt' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM:
       wfXdoPGuxgmQsqcvLAWFrbCJDyREeV=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('broad_dt')
       wfXdoPGuxgmQsqcvLAWFrbCJDyREIN='%s-%s-%s'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[:4],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[4:6],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[6:])
       wfXdoPGuxgmQsqcvLAWFrbCJDyREeO =wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[:4]
     except:
      wfXdoPGuxgmQsqcvLAWFrbCJDyRElB
     wfXdoPGuxgmQsqcvLAWFrbCJDyREej={'program':wfXdoPGuxgmQsqcvLAWFrbCJDyREeM,'title':wfXdoPGuxgmQsqcvLAWFrbCJDyREHh,'thumbnail':{'poster':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY,'thumb':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa,'fanart':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa},'synopsis':'','cast':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI,'director':wfXdoPGuxgmQsqcvLAWFrbCJDyREel,'info_genre':wfXdoPGuxgmQsqcvLAWFrbCJDyREek,'duration':wfXdoPGuxgmQsqcvLAWFrbCJDyREIU,'mpaa':wfXdoPGuxgmQsqcvLAWFrbCJDyREeN,'year':wfXdoPGuxgmQsqcvLAWFrbCJDyREeO,'aired':wfXdoPGuxgmQsqcvLAWFrbCJDyREIN}
     wfXdoPGuxgmQsqcvLAWFrbCJDyREIS.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREej)
   else:
    if not('vodMVRsb' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj):return wfXdoPGuxgmQsqcvLAWFrbCJDyREIS,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIa=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['vodMVRsb']['dataList']
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIT =wfXdoPGuxgmQsqcvLAWFrbCJDyREla(wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['vodMVRsb']['count'])
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREIa:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREeM=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['mast_cd']
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHh =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['mast_nm'].strip()
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['web_url']
     wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREHY
     wfXdoPGuxgmQsqcvLAWFrbCJDyREen=''
     try:
      wfXdoPGuxgmQsqcvLAWFrbCJDyREeI =[]
      wfXdoPGuxgmQsqcvLAWFrbCJDyREel=[]
      wfXdoPGuxgmQsqcvLAWFrbCJDyREek =[]
      wfXdoPGuxgmQsqcvLAWFrbCJDyREIU =0
      wfXdoPGuxgmQsqcvLAWFrbCJDyREeN =''
      wfXdoPGuxgmQsqcvLAWFrbCJDyREeO =''
      wfXdoPGuxgmQsqcvLAWFrbCJDyREIN =''
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('actor') !='' and wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('actor') !='-':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('actor').split(',')
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('director')!='' and wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('director')!='-':wfXdoPGuxgmQsqcvLAWFrbCJDyREel=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('director').split(',')
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('cate_nm')!='' and wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('cate_nm')!='-':wfXdoPGuxgmQsqcvLAWFrbCJDyREek =wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('cate_nm').split('/')
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('runtime_sec')!='':wfXdoPGuxgmQsqcvLAWFrbCJDyREIU=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('runtime_sec')
      if 'grade_nm' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpM:wfXdoPGuxgmQsqcvLAWFrbCJDyREeN=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('grade_nm')
      wfXdoPGuxgmQsqcvLAWFrbCJDyREeV=wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('broad_dt')
      if data_str!='':
       wfXdoPGuxgmQsqcvLAWFrbCJDyREIN='%s-%s-%s'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[:4],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[4:6],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[6:])
       wfXdoPGuxgmQsqcvLAWFrbCJDyREeO =wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[:4]
     except:
      wfXdoPGuxgmQsqcvLAWFrbCJDyRElB
     wfXdoPGuxgmQsqcvLAWFrbCJDyREej={'movie':wfXdoPGuxgmQsqcvLAWFrbCJDyREeM,'title':wfXdoPGuxgmQsqcvLAWFrbCJDyREHh,'thumbnail':{'poster':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY,'thumb':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa,'fanart':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa,'clearlogo':wfXdoPGuxgmQsqcvLAWFrbCJDyREen},'synopsis':'','cast':wfXdoPGuxgmQsqcvLAWFrbCJDyREeI,'director':wfXdoPGuxgmQsqcvLAWFrbCJDyREel,'info_genre':wfXdoPGuxgmQsqcvLAWFrbCJDyREek,'duration':wfXdoPGuxgmQsqcvLAWFrbCJDyREIU,'mpaa':wfXdoPGuxgmQsqcvLAWFrbCJDyREeN,'year':wfXdoPGuxgmQsqcvLAWFrbCJDyREeO,'aired':wfXdoPGuxgmQsqcvLAWFrbCJDyREIN}
     wfXdoPGuxgmQsqcvLAWFrbCJDyREIS.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREej)
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREIT>(page_int*wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.SEARCH_LIMIT):wfXdoPGuxgmQsqcvLAWFrbCJDyREHU=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREIS,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
 def GetBookmarkInfo(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,videoid,vidtype):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREIY={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+'/v2/media/program/'+videoid
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'pageNo':'1','pageSize':'10','order':'name',}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREea=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if not('body' in wfXdoPGuxgmQsqcvLAWFrbCJDyREea):return{}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREln=wfXdoPGuxgmQsqcvLAWFrbCJDyREea['body']
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHh=wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('name').get('ko').strip()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['title'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREHh
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['title']=wfXdoPGuxgmQsqcvLAWFrbCJDyREHh
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['mpaa'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREnK.get(wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('grade_code'))
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['plot'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('synopsis').get('ko')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['year'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('product_year')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['cast'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('actor')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['director']=wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('director')
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('category1_name').get('ko')!='':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['genre'].append(wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('category1_name').get('ko'))
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('category2_name').get('ko')!='':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['genre'].append(wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('category2_name').get('ko'))
   wfXdoPGuxgmQsqcvLAWFrbCJDyREeV=wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('broad_dt'))
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREeV!='0':wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[:4],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[4:6],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[6:])
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =''
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =''
   wfXdoPGuxgmQsqcvLAWFrbCJDyREen=''
   wfXdoPGuxgmQsqcvLAWFrbCJDyREez =''
   wfXdoPGuxgmQsqcvLAWFrbCJDyREep =''
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREeH in wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('image'):
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('code')=='CAIP0900':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('url')
    elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('code')=='CAIP0200':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('url')
    elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('code')=='CAIP1800':wfXdoPGuxgmQsqcvLAWFrbCJDyREen=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('url')
    elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('code')=='CAIP2000':wfXdoPGuxgmQsqcvLAWFrbCJDyREez =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('url')
    elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('code')=='CAIP1900':wfXdoPGuxgmQsqcvLAWFrbCJDyREep =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('url')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['thumbnail']['poster']=wfXdoPGuxgmQsqcvLAWFrbCJDyREHY
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['thumbnail']['thumb']=wfXdoPGuxgmQsqcvLAWFrbCJDyREHa
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['thumbnail']['clearlogo']=wfXdoPGuxgmQsqcvLAWFrbCJDyREen
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['thumbnail']['icon']=wfXdoPGuxgmQsqcvLAWFrbCJDyREez
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['thumbnail']['banner']=wfXdoPGuxgmQsqcvLAWFrbCJDyREep
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['thumbnail']['fanart']=wfXdoPGuxgmQsqcvLAWFrbCJDyREHa
  else:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+'/v2a/media/stream/info'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies']['tving_uuid'].split('-')[0],'uuid':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetNoCache(1)),'wm':'Y',}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREea=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if not('content' in wfXdoPGuxgmQsqcvLAWFrbCJDyREea['body']):return{}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREln=wfXdoPGuxgmQsqcvLAWFrbCJDyREea['body']['content']['info']['movie']
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHh =wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('name').get('ko').strip()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['title']=wfXdoPGuxgmQsqcvLAWFrbCJDyREHh
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHh +=u' (%s)'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('product_year'))
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['title'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREHh
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['mpaa'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREnK.get(wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('grade_code'))
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['plot'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('story').get('ko')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['year'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('product_year')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['studio'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('production')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['duration']=wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('duration')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['cast'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('actor')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['director']=wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('director')
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('category1_name').get('ko')!='':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['genre'].append(wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('category1_name').get('ko'))
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('category2_name').get('ko')!='':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['genre'].append(wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('category2_name').get('ko'))
   wfXdoPGuxgmQsqcvLAWFrbCJDyREeV=wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('release_date'))
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREeV!='0':wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[:4],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[4:6],wfXdoPGuxgmQsqcvLAWFrbCJDyREeV[6:])
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHY=''
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =''
   wfXdoPGuxgmQsqcvLAWFrbCJDyREen=''
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREeH in wfXdoPGuxgmQsqcvLAWFrbCJDyREln.get('image'):
    if wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('code')=='CAIM2100':wfXdoPGuxgmQsqcvLAWFrbCJDyREHY =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('url')
    elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('code')=='CAIM0400':wfXdoPGuxgmQsqcvLAWFrbCJDyREHa =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('url')
    elif wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('code')=='CAIM1800':wfXdoPGuxgmQsqcvLAWFrbCJDyREen=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.IMG_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREeH.get('url')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['thumbnail']['poster']=wfXdoPGuxgmQsqcvLAWFrbCJDyREHY
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['thumbnail']['thumb']=wfXdoPGuxgmQsqcvLAWFrbCJDyREHY 
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['thumbnail']['clearlogo']=wfXdoPGuxgmQsqcvLAWFrbCJDyREen
   wfXdoPGuxgmQsqcvLAWFrbCJDyREIY['saveinfo']['thumbnail']['fanart']=wfXdoPGuxgmQsqcvLAWFrbCJDyREHa
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREIY
 def GetEuroChannelList(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpt=[]
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v2/operator/highlights'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetNoCache(2))}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if not('result' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']):return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt,wfXdoPGuxgmQsqcvLAWFrbCJDyREHU
   wfXdoPGuxgmQsqcvLAWFrbCJDyREHB=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElz =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Get_Now_Datetime()
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElp=wfXdoPGuxgmQsqcvLAWFrbCJDyRElz+datetime.timedelta(days=-1)
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElp=wfXdoPGuxgmQsqcvLAWFrbCJDyREla(wfXdoPGuxgmQsqcvLAWFrbCJDyRElp.strftime('%Y%m%d'))
   for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREHB:
    wfXdoPGuxgmQsqcvLAWFrbCJDyRElK=wfXdoPGuxgmQsqcvLAWFrbCJDyREla(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('content').get('banner_title2')[:8])
    if wfXdoPGuxgmQsqcvLAWFrbCJDyRElp<=wfXdoPGuxgmQsqcvLAWFrbCJDyRElK:
     wfXdoPGuxgmQsqcvLAWFrbCJDyREej={'channel':wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('content').get('banner_sub_title3'),'title':wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('content').get('banner_title'),'subtitle':wfXdoPGuxgmQsqcvLAWFrbCJDyREpM.get('content').get('banner_sub_title2'),}
     wfXdoPGuxgmQsqcvLAWFrbCJDyREpt.append(wfXdoPGuxgmQsqcvLAWFrbCJDyREej)
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREpt
 def Make_DecryptKey(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,step,mediacode='000',timecode='000'):
  if step=='1':
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzO=wfXdoPGuxgmQsqcvLAWFrbCJDyREkn('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzN=wfXdoPGuxgmQsqcvLAWFrbCJDyREkn('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzO=wfXdoPGuxgmQsqcvLAWFrbCJDyREkn('kss2lym0kdw1lks3','utf-8')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzN=wfXdoPGuxgmQsqcvLAWFrbCJDyREkn([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREzO,wfXdoPGuxgmQsqcvLAWFrbCJDyREzN
 def DecryptPlaintext(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,wfXdoPGuxgmQsqcvLAWFrbCJDyREzV,wfXdoPGuxgmQsqcvLAWFrbCJDyREzi,wfXdoPGuxgmQsqcvLAWFrbCJDyREzt):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzU=AES.new(wfXdoPGuxgmQsqcvLAWFrbCJDyREzi,AES.MODE_CBC,wfXdoPGuxgmQsqcvLAWFrbCJDyREzt,)
  wfXdoPGuxgmQsqcvLAWFrbCJDyREzB=Padding.unpad(wfXdoPGuxgmQsqcvLAWFrbCJDyREzU.decrypt(base64.standard_b64decode(wfXdoPGuxgmQsqcvLAWFrbCJDyREzV)),16)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREzB.decode('utf-8')
 def Decrypt_Url(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,wfXdoPGuxgmQsqcvLAWFrbCJDyREzV,mediacode,wfXdoPGuxgmQsqcvLAWFrbCJDyREKl):
  wfXdoPGuxgmQsqcvLAWFrbCJDyRElH=''
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzO,wfXdoPGuxgmQsqcvLAWFrbCJDyREzN=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Make_DecryptKey('1',mediacode=mediacode,timecode=wfXdoPGuxgmQsqcvLAWFrbCJDyREKl)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREle=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.DecryptPlaintext(wfXdoPGuxgmQsqcvLAWFrbCJDyREzV,wfXdoPGuxgmQsqcvLAWFrbCJDyREzO,wfXdoPGuxgmQsqcvLAWFrbCJDyREzN))
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElI =wfXdoPGuxgmQsqcvLAWFrbCJDyREle.get('url')
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzO,wfXdoPGuxgmQsqcvLAWFrbCJDyREzN=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Make_DecryptKey('2',mediacode=mediacode,timecode=wfXdoPGuxgmQsqcvLAWFrbCJDyREKl)
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElH=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.DecryptPlaintext(wfXdoPGuxgmQsqcvLAWFrbCJDyRElI,wfXdoPGuxgmQsqcvLAWFrbCJDyREzO,wfXdoPGuxgmQsqcvLAWFrbCJDyREzN)
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
  return wfXdoPGuxgmQsqcvLAWFrbCJDyRElH
 def GetLiveURL_Test(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI,mediacode,sel_quality):
  wfXdoPGuxgmQsqcvLAWFrbCJDyREph ={'streaming_url':'','subtitleYn':wfXdoPGuxgmQsqcvLAWFrbCJDyRElj,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpU =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies']['tving_uuid'].split('-')[0] 
  wfXdoPGuxgmQsqcvLAWFrbCJDyREpT =wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.TV['cookies']['tving_uuid'] 
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpY=wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetNoCache(1))
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v2/media/stream/info' 
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':wfXdoPGuxgmQsqcvLAWFrbCJDyREpT,'deviceInfo':'PC','noCache':wfXdoPGuxgmQsqcvLAWFrbCJDyREpY,}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnY=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.makeDefaultCookies()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Get',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyREnY)
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREza.status_code!=200:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREph['error_msg']='First Step - {} error'.format(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.status_code)
    return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']['code']=='060':
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREnh in wfXdoPGuxgmQsqcvLAWFrbCJDyREnp.items():
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREnh==sel_quality:
      wfXdoPGuxgmQsqcvLAWFrbCJDyREKz=wfXdoPGuxgmQsqcvLAWFrbCJDyREnS
   elif wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']['code']!='000':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREph['error_msg']=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']['message']
    return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
   else: 
    if not('stream' in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']):return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
    wfXdoPGuxgmQsqcvLAWFrbCJDyREKp=[]
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREnh in wfXdoPGuxgmQsqcvLAWFrbCJDyREnp.items():
     for wfXdoPGuxgmQsqcvLAWFrbCJDyREpM in wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['stream']['quality']:
      if wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['active']=='Y' and wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['code']==wfXdoPGuxgmQsqcvLAWFrbCJDyREnS:
       wfXdoPGuxgmQsqcvLAWFrbCJDyREKp.append({wfXdoPGuxgmQsqcvLAWFrbCJDyREnp.get(wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['code']):wfXdoPGuxgmQsqcvLAWFrbCJDyREpM['code']})
    wfXdoPGuxgmQsqcvLAWFrbCJDyREKz=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.CheckQuality(sel_quality,wfXdoPGuxgmQsqcvLAWFrbCJDyREKp)
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREph['error_msg']='First Step - except error'
   return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
  try:
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpY=wfXdoPGuxgmQsqcvLAWFrbCJDyRElM(wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetNoCache(1))
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpO ='/v3/media/stream/info'
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.GetDefaultParams()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpB={'mediaCode':mediacode,'deviceId':wfXdoPGuxgmQsqcvLAWFrbCJDyREpU,'uuid':wfXdoPGuxgmQsqcvLAWFrbCJDyREpT,'deviceInfo':'PC_Chrome','streamCode':wfXdoPGuxgmQsqcvLAWFrbCJDyREKz,'noCache':wfXdoPGuxgmQsqcvLAWFrbCJDyREpY,'callingFrom':'HTML5','model':wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKn.update(wfXdoPGuxgmQsqcvLAWFrbCJDyREpB)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREzh=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.API_DOMAIN+wfXdoPGuxgmQsqcvLAWFrbCJDyREpO
   wfXdoPGuxgmQsqcvLAWFrbCJDyREnY=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.makeDefaultCookies()
   wfXdoPGuxgmQsqcvLAWFrbCJDyREza=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.callRequestCookies('Post',wfXdoPGuxgmQsqcvLAWFrbCJDyREzh,payload=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,params=wfXdoPGuxgmQsqcvLAWFrbCJDyREKn,headers=wfXdoPGuxgmQsqcvLAWFrbCJDyRElB,cookies=wfXdoPGuxgmQsqcvLAWFrbCJDyREnY,redirects=wfXdoPGuxgmQsqcvLAWFrbCJDyRElh)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREpj=json.loads(wfXdoPGuxgmQsqcvLAWFrbCJDyREza.text)
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']['code']!='000':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREph['error_msg']=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['result']['message']
    return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
   wfXdoPGuxgmQsqcvLAWFrbCJDyREKH=wfXdoPGuxgmQsqcvLAWFrbCJDyREpj['body']['stream']
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREKH['drm_yn']=='Y':
    wfXdoPGuxgmQsqcvLAWFrbCJDyREKe=wfXdoPGuxgmQsqcvLAWFrbCJDyREKH['playback']['drm']['widevine']
    for wfXdoPGuxgmQsqcvLAWFrbCJDyREKI in wfXdoPGuxgmQsqcvLAWFrbCJDyREKH['playback']['drm']['license']['drm_license_data']:
     if wfXdoPGuxgmQsqcvLAWFrbCJDyREKI['drm_type']=='Widevine':
      wfXdoPGuxgmQsqcvLAWFrbCJDyREph['drm_server_url'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREKI['drm_server_url']
      wfXdoPGuxgmQsqcvLAWFrbCJDyREph['drm_header_key'] =wfXdoPGuxgmQsqcvLAWFrbCJDyREKI['drm_header_key']
      wfXdoPGuxgmQsqcvLAWFrbCJDyREph['drm_header_value']=wfXdoPGuxgmQsqcvLAWFrbCJDyREKI['drm_header_value']
      break
   else:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREKe=wfXdoPGuxgmQsqcvLAWFrbCJDyREKH['playback']['non_drm']
  except wfXdoPGuxgmQsqcvLAWFrbCJDyREkz as exception:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(exception)
   wfXdoPGuxgmQsqcvLAWFrbCJDyREph['error_msg']='Second Step - except error'
   return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKl=wfXdoPGuxgmQsqcvLAWFrbCJDyREpY
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKe=wfXdoPGuxgmQsqcvLAWFrbCJDyREKe.split('|')[1]
  wfXdoPGuxgmQsqcvLAWFrbCJDyREKe=wfXdoPGuxgmQsqcvLAWFrbCJDyREnI.Decrypt_Url(wfXdoPGuxgmQsqcvLAWFrbCJDyREKe,mediacode,wfXdoPGuxgmQsqcvLAWFrbCJDyREKl)
  wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url']=wfXdoPGuxgmQsqcvLAWFrbCJDyREKe
  wfXdoPGuxgmQsqcvLAWFrbCJDyRElk =wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url'].find('Policy=')
  if wfXdoPGuxgmQsqcvLAWFrbCJDyRElk!=-1:
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElO =wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url'].split('?')[0]
   wfXdoPGuxgmQsqcvLAWFrbCJDyRElN=wfXdoPGuxgmQsqcvLAWFrbCJDyREkp(urllib.parse.parse_qsl(urllib.parse.urlsplit(wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url']).query))
   wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url']='{}&CloudFront-Policy={}'.format(wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url'],wfXdoPGuxgmQsqcvLAWFrbCJDyRElN['Policy'])
   wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url']='{}&CloudFront-Signature={}'.format(wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url'],wfXdoPGuxgmQsqcvLAWFrbCJDyRElN['Signature'])
   wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url'],wfXdoPGuxgmQsqcvLAWFrbCJDyRElN['Key-Pair-Id'])
  wfXdoPGuxgmQsqcvLAWFrbCJDyREli=['_tving_token','accessToken','authToken',]
  for wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREnh in wfXdoPGuxgmQsqcvLAWFrbCJDyREnY.items():
   if wfXdoPGuxgmQsqcvLAWFrbCJDyREnS in wfXdoPGuxgmQsqcvLAWFrbCJDyREli:
    wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url']='{}&{}={}'.format(wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url'],wfXdoPGuxgmQsqcvLAWFrbCJDyREnS,wfXdoPGuxgmQsqcvLAWFrbCJDyREnh)
  wfXdoPGuxgmQsqcvLAWFrbCJDyRElt(wfXdoPGuxgmQsqcvLAWFrbCJDyREph['streaming_url'])
  return wfXdoPGuxgmQsqcvLAWFrbCJDyREph
# Created by pyminifier (https://github.com/liftoff/pyminifier)
