__author__="NightRain"
kJheUjmoRbBWAdfDNuTCzrMQyOnPIg=object
kJheUjmoRbBWAdfDNuTCzrMQyOnPIq=None
kJheUjmoRbBWAdfDNuTCzrMQyOnPIL=int
kJheUjmoRbBWAdfDNuTCzrMQyOnPIp=True
kJheUjmoRbBWAdfDNuTCzrMQyOnPEX=False
kJheUjmoRbBWAdfDNuTCzrMQyOnPEa=type
kJheUjmoRbBWAdfDNuTCzrMQyOnPEx=dict
kJheUjmoRbBWAdfDNuTCzrMQyOnPEF=getattr
kJheUjmoRbBWAdfDNuTCzrMQyOnPEs=list
kJheUjmoRbBWAdfDNuTCzrMQyOnPEV=len
kJheUjmoRbBWAdfDNuTCzrMQyOnPEv=str
kJheUjmoRbBWAdfDNuTCzrMQyOnPEI=range
kJheUjmoRbBWAdfDNuTCzrMQyOnPEi=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
kJheUjmoRbBWAdfDNuTCzrMQyOnPXx=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
kJheUjmoRbBWAdfDNuTCzrMQyOnPXF=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
kJheUjmoRbBWAdfDNuTCzrMQyOnPXs=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
kJheUjmoRbBWAdfDNuTCzrMQyOnPXV=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
kJheUjmoRbBWAdfDNuTCzrMQyOnPXv=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
kJheUjmoRbBWAdfDNuTCzrMQyOnPXI=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
kJheUjmoRbBWAdfDNuTCzrMQyOnPXE=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
kJheUjmoRbBWAdfDNuTCzrMQyOnPXi={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
kJheUjmoRbBWAdfDNuTCzrMQyOnPXw =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
kJheUjmoRbBWAdfDNuTCzrMQyOnPXt=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class kJheUjmoRbBWAdfDNuTCzrMQyOnPXa(kJheUjmoRbBWAdfDNuTCzrMQyOnPIg):
 def __init__(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPXS,kJheUjmoRbBWAdfDNuTCzrMQyOnPXl,kJheUjmoRbBWAdfDNuTCzrMQyOnPXY):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_url =kJheUjmoRbBWAdfDNuTCzrMQyOnPXS
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle=kJheUjmoRbBWAdfDNuTCzrMQyOnPXl
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params =kJheUjmoRbBWAdfDNuTCzrMQyOnPXY
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj =wfXdoPGuxgmQsqcvLAWFrbCJDyREnz() 
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,sting):
  try:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXG=xbmcgui.Dialog()
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXG.notification(__addonname__,sting)
  except:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
 def addon_log(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,string):
  try:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXH=string.encode('utf-8','ignore')
  except:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXH='addonException: addon_log'
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXg=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,kJheUjmoRbBWAdfDNuTCzrMQyOnPXH),level=kJheUjmoRbBWAdfDNuTCzrMQyOnPXg)
 def get_keyboard_input(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPaY):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXq=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
  kb=xbmc.Keyboard()
  kb.setHeading(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXq=kb.getText()
  return kJheUjmoRbBWAdfDNuTCzrMQyOnPXq
 def get_settings_account(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXL =__addon__.getSetting('id')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXp =__addon__.getSetting('pw')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaX =__addon__.getSetting('login_type')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPax=kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(__addon__.getSetting('selected_profile'))
  return(kJheUjmoRbBWAdfDNuTCzrMQyOnPXL,kJheUjmoRbBWAdfDNuTCzrMQyOnPXp,kJheUjmoRbBWAdfDNuTCzrMQyOnPaX,kJheUjmoRbBWAdfDNuTCzrMQyOnPax)
 def get_settings_uhd(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  return kJheUjmoRbBWAdfDNuTCzrMQyOnPIp if __addon__.getSetting('active_uhd')=='true' else kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
 def get_settings_playback(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaF={'active_uhd':kJheUjmoRbBWAdfDNuTCzrMQyOnPIp if __addon__.getSetting('active_uhd')=='true' else kJheUjmoRbBWAdfDNuTCzrMQyOnPEX,'streamFilename':kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.TV_STREAM_FILENAME,}
  return kJheUjmoRbBWAdfDNuTCzrMQyOnPaF
 def get_settings_proxyport(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPas =kJheUjmoRbBWAdfDNuTCzrMQyOnPIp if __addon__.getSetting('proxyYn')=='true' else kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaV=kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(__addon__.getSetting('proxyPort'))
  return kJheUjmoRbBWAdfDNuTCzrMQyOnPas,kJheUjmoRbBWAdfDNuTCzrMQyOnPaV
 def get_settings_totalsearch(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPav =kJheUjmoRbBWAdfDNuTCzrMQyOnPIp if __addon__.getSetting('local_search')=='true' else kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaI=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp if __addon__.getSetting('local_history')=='true' else kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaE =kJheUjmoRbBWAdfDNuTCzrMQyOnPIp if __addon__.getSetting('total_search')=='true' else kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
  kJheUjmoRbBWAdfDNuTCzrMQyOnPai=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp if __addon__.getSetting('total_history')=='true' else kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaw=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp if __addon__.getSetting('menu_bookmark')=='true' else kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
  return(kJheUjmoRbBWAdfDNuTCzrMQyOnPav,kJheUjmoRbBWAdfDNuTCzrMQyOnPaI,kJheUjmoRbBWAdfDNuTCzrMQyOnPaE,kJheUjmoRbBWAdfDNuTCzrMQyOnPai,kJheUjmoRbBWAdfDNuTCzrMQyOnPaw)
 def get_settings_makebookmark(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  return kJheUjmoRbBWAdfDNuTCzrMQyOnPIp if __addon__.getSetting('make_bookmark')=='true' else kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
 def get_settings_direct_replay(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPat=kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(__addon__.getSetting('direct_replay'))
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPat==0:
   return kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
  else:
   return kJheUjmoRbBWAdfDNuTCzrMQyOnPIp
 def set_winEpisodeOrderby(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPaS):
  __addon__.setSetting('tving_orderby',kJheUjmoRbBWAdfDNuTCzrMQyOnPaS)
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaK=xbmcgui.Window(10000)
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaK.setProperty('TVING_M_ORDERBY',kJheUjmoRbBWAdfDNuTCzrMQyOnPaS)
 def get_winEpisodeOrderby(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaS=__addon__.getSetting('tving_orderby')
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPaS in['',kJheUjmoRbBWAdfDNuTCzrMQyOnPIq]:kJheUjmoRbBWAdfDNuTCzrMQyOnPaS='desc'
  return kJheUjmoRbBWAdfDNuTCzrMQyOnPaS
 def add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,label,sublabel='',img='',infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params='',isLink=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX,ContextMenu=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPal='%s?%s'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_url,urllib.parse.urlencode(params))
  if sublabel:kJheUjmoRbBWAdfDNuTCzrMQyOnPaY='%s < %s >'%(label,sublabel)
  else: kJheUjmoRbBWAdfDNuTCzrMQyOnPaY=label
  if not img:img='DefaultFolder.png'
  kJheUjmoRbBWAdfDNuTCzrMQyOnPac=xbmcgui.ListItem(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPEa(img)==kJheUjmoRbBWAdfDNuTCzrMQyOnPEx:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPac.setArt(img)
  else:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPac.setArt({'thumb':img,'poster':img})
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.KodiVersion>=20:
   if infoLabels:kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.Set_InfoTag(kJheUjmoRbBWAdfDNuTCzrMQyOnPac.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:kJheUjmoRbBWAdfDNuTCzrMQyOnPac.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPac.setProperty('IsPlayable','true')
  if ContextMenu:kJheUjmoRbBWAdfDNuTCzrMQyOnPac.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,kJheUjmoRbBWAdfDNuTCzrMQyOnPal,kJheUjmoRbBWAdfDNuTCzrMQyOnPac,isFolder)
 def get_selQuality(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,etype):
  try:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaG='selected_quality'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaH=[1080,720,480,360]
   kJheUjmoRbBWAdfDNuTCzrMQyOnPag=kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(__addon__.getSetting(kJheUjmoRbBWAdfDNuTCzrMQyOnPaG))
   return kJheUjmoRbBWAdfDNuTCzrMQyOnPaH[kJheUjmoRbBWAdfDNuTCzrMQyOnPag]
  except:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
  return 720 
 def Set_InfoTag(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,video_InfoTag:xbmc.InfoTagVideo,kJheUjmoRbBWAdfDNuTCzrMQyOnPxV):
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPaq,value in kJheUjmoRbBWAdfDNuTCzrMQyOnPxV.items():
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPXi[kJheUjmoRbBWAdfDNuTCzrMQyOnPaq]['type']=='string':
    kJheUjmoRbBWAdfDNuTCzrMQyOnPEF(video_InfoTag,kJheUjmoRbBWAdfDNuTCzrMQyOnPXi[kJheUjmoRbBWAdfDNuTCzrMQyOnPaq]['func'])(value)
   elif kJheUjmoRbBWAdfDNuTCzrMQyOnPXi[kJheUjmoRbBWAdfDNuTCzrMQyOnPaq]['type']=='int':
    if kJheUjmoRbBWAdfDNuTCzrMQyOnPEa(value)==kJheUjmoRbBWAdfDNuTCzrMQyOnPIL:
     kJheUjmoRbBWAdfDNuTCzrMQyOnPaL=kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(value)
    else:
     kJheUjmoRbBWAdfDNuTCzrMQyOnPaL=0
    kJheUjmoRbBWAdfDNuTCzrMQyOnPEF(video_InfoTag,kJheUjmoRbBWAdfDNuTCzrMQyOnPXi[kJheUjmoRbBWAdfDNuTCzrMQyOnPaq]['func'])(kJheUjmoRbBWAdfDNuTCzrMQyOnPaL)
   elif kJheUjmoRbBWAdfDNuTCzrMQyOnPXi[kJheUjmoRbBWAdfDNuTCzrMQyOnPaq]['type']=='actor':
    if value!=[]:
     kJheUjmoRbBWAdfDNuTCzrMQyOnPEF(video_InfoTag,kJheUjmoRbBWAdfDNuTCzrMQyOnPXi[kJheUjmoRbBWAdfDNuTCzrMQyOnPaq]['func'])([xbmc.Actor(name)for name in value])
   elif kJheUjmoRbBWAdfDNuTCzrMQyOnPXi[kJheUjmoRbBWAdfDNuTCzrMQyOnPaq]['type']=='list':
    if kJheUjmoRbBWAdfDNuTCzrMQyOnPEa(value)==kJheUjmoRbBWAdfDNuTCzrMQyOnPEs:
     kJheUjmoRbBWAdfDNuTCzrMQyOnPEF(video_InfoTag,kJheUjmoRbBWAdfDNuTCzrMQyOnPXi[kJheUjmoRbBWAdfDNuTCzrMQyOnPaq]['func'])(value)
    else:
     kJheUjmoRbBWAdfDNuTCzrMQyOnPEF(video_InfoTag,kJheUjmoRbBWAdfDNuTCzrMQyOnPXi[kJheUjmoRbBWAdfDNuTCzrMQyOnPaq]['func'])([value])
 def dp_Main_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  (kJheUjmoRbBWAdfDNuTCzrMQyOnPav,kJheUjmoRbBWAdfDNuTCzrMQyOnPaI,kJheUjmoRbBWAdfDNuTCzrMQyOnPaE,kJheUjmoRbBWAdfDNuTCzrMQyOnPai,kJheUjmoRbBWAdfDNuTCzrMQyOnPaw)=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_totalsearch()
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPap in kJheUjmoRbBWAdfDNuTCzrMQyOnPXx:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY=kJheUjmoRbBWAdfDNuTCzrMQyOnPap.get('title')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxX=''
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPap.get('mode')=='SEARCH_GROUP' and kJheUjmoRbBWAdfDNuTCzrMQyOnPav ==kJheUjmoRbBWAdfDNuTCzrMQyOnPEX:continue
   elif kJheUjmoRbBWAdfDNuTCzrMQyOnPap.get('mode')=='SEARCH_HISTORY' and kJheUjmoRbBWAdfDNuTCzrMQyOnPaI==kJheUjmoRbBWAdfDNuTCzrMQyOnPEX:continue
   elif kJheUjmoRbBWAdfDNuTCzrMQyOnPap.get('mode')=='TOTAL_SEARCH' and kJheUjmoRbBWAdfDNuTCzrMQyOnPaE ==kJheUjmoRbBWAdfDNuTCzrMQyOnPEX:continue
   elif kJheUjmoRbBWAdfDNuTCzrMQyOnPap.get('mode')=='TOTAL_HISTORY' and kJheUjmoRbBWAdfDNuTCzrMQyOnPai==kJheUjmoRbBWAdfDNuTCzrMQyOnPEX:continue
   elif kJheUjmoRbBWAdfDNuTCzrMQyOnPap.get('mode')=='MENU_BOOKMARK' and kJheUjmoRbBWAdfDNuTCzrMQyOnPaw==kJheUjmoRbBWAdfDNuTCzrMQyOnPEX:continue
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':kJheUjmoRbBWAdfDNuTCzrMQyOnPap.get('mode'),'stype':kJheUjmoRbBWAdfDNuTCzrMQyOnPap.get('stype'),'orderby':kJheUjmoRbBWAdfDNuTCzrMQyOnPap.get('orderby'),'ordernm':kJheUjmoRbBWAdfDNuTCzrMQyOnPap.get('ordernm'),'page':'1'}
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPap.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxF=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxs =kJheUjmoRbBWAdfDNuTCzrMQyOnPIp
   else:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxF=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxs =kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxV={'title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'plot':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY}
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPap.get('mode')=='XXX':kJheUjmoRbBWAdfDNuTCzrMQyOnPxV=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
   if 'icon' in kJheUjmoRbBWAdfDNuTCzrMQyOnPap:kJheUjmoRbBWAdfDNuTCzrMQyOnPxX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',kJheUjmoRbBWAdfDNuTCzrMQyOnPap.get('icon')) 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel='',img=kJheUjmoRbBWAdfDNuTCzrMQyOnPxX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPxV,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPxF,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa,isLink=kJheUjmoRbBWAdfDNuTCzrMQyOnPxs)
  xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle)
 def login_main(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  (kJheUjmoRbBWAdfDNuTCzrMQyOnPxI,kJheUjmoRbBWAdfDNuTCzrMQyOnPxE,kJheUjmoRbBWAdfDNuTCzrMQyOnPxi,kJheUjmoRbBWAdfDNuTCzrMQyOnPxw)=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_account()
  if not(kJheUjmoRbBWAdfDNuTCzrMQyOnPxI and kJheUjmoRbBWAdfDNuTCzrMQyOnPxE):
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXG=xbmcgui.Dialog()
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxt=kJheUjmoRbBWAdfDNuTCzrMQyOnPXG.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPxt==kJheUjmoRbBWAdfDNuTCzrMQyOnPIp:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.cookiefile_check():return
  if base64.standard_b64encode(kJheUjmoRbBWAdfDNuTCzrMQyOnPxI.encode()).decode('utf-8')=='a3ltOTUxMDg4':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxK=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.GetCredential2(kJheUjmoRbBWAdfDNuTCzrMQyOnPxI,kJheUjmoRbBWAdfDNuTCzrMQyOnPxE,kJheUjmoRbBWAdfDNuTCzrMQyOnPxi,kJheUjmoRbBWAdfDNuTCzrMQyOnPxw)
  else:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXG=xbmcgui.Dialog()
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxS=kJheUjmoRbBWAdfDNuTCzrMQyOnPXG.browse(1,__language__(30917).encode('utf8'),'','.twc',kJheUjmoRbBWAdfDNuTCzrMQyOnPEX,kJheUjmoRbBWAdfDNuTCzrMQyOnPEX,'',kJheUjmoRbBWAdfDNuTCzrMQyOnPEX)
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPxS!='':
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxl=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'))
    xbmcvfs.copy(kJheUjmoRbBWAdfDNuTCzrMQyOnPxS,kJheUjmoRbBWAdfDNuTCzrMQyOnPxl)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxK=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.WebCookies_Load(kJheUjmoRbBWAdfDNuTCzrMQyOnPxl)
    xbmcvfs.delete(kJheUjmoRbBWAdfDNuTCzrMQyOnPxl)
    if kJheUjmoRbBWAdfDNuTCzrMQyOnPxK:
     kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.JsonFile_Save(kJheUjmoRbBWAdfDNuTCzrMQyOnPXw,kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.TV)
     kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxK=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxK==kJheUjmoRbBWAdfDNuTCzrMQyOnPIp:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.cookiefile_save()
  else:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxY=kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('stype')
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxY=='live':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxc=kJheUjmoRbBWAdfDNuTCzrMQyOnPXF
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPxY=='vod':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxc=kJheUjmoRbBWAdfDNuTCzrMQyOnPXv
  else:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxc=kJheUjmoRbBWAdfDNuTCzrMQyOnPXI
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPxG in kJheUjmoRbBWAdfDNuTCzrMQyOnPxc:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY=kJheUjmoRbBWAdfDNuTCzrMQyOnPxG.get('title')
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('ordernm')!='-':
    kJheUjmoRbBWAdfDNuTCzrMQyOnPaY+='  ('+kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('ordernm')+')'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':kJheUjmoRbBWAdfDNuTCzrMQyOnPxG.get('mode'),'stype':kJheUjmoRbBWAdfDNuTCzrMQyOnPxG.get('stype'),'orderby':kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('orderby'),'ordernm':kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('ordernm'),'page':'1'}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel='',img='',infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPEV(kJheUjmoRbBWAdfDNuTCzrMQyOnPxc)>0:xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle)
 def dp_SubTitle_Group(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH): 
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPxG in kJheUjmoRbBWAdfDNuTCzrMQyOnPXE:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY=kJheUjmoRbBWAdfDNuTCzrMQyOnPxG.get('title')
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('ordernm')!='-':
    kJheUjmoRbBWAdfDNuTCzrMQyOnPaY+='  ('+kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('ordernm')+')'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':kJheUjmoRbBWAdfDNuTCzrMQyOnPxG.get('mode'),'genreCode':kJheUjmoRbBWAdfDNuTCzrMQyOnPxG.get('genreCode'),'stype':kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('stype'),'orderby':kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('orderby'),'page':'1'}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel='',img='',infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPEV(kJheUjmoRbBWAdfDNuTCzrMQyOnPXE)>0:xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle)
 def dp_LiveChannel_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxY =kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('stype')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxg =kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('page'))
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxq,kJheUjmoRbBWAdfDNuTCzrMQyOnPxL=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.GetLiveChannelList(kJheUjmoRbBWAdfDNuTCzrMQyOnPxY,kJheUjmoRbBWAdfDNuTCzrMQyOnPxg)
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPxp in kJheUjmoRbBWAdfDNuTCzrMQyOnPxq:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('title')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxv =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('channel')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFX =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('thumbnail')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFa =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('synopsis')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFx =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('channelepg')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFs =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('cast')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFV =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('director')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFv =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('info_genre')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFI =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('year')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFE =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('mpaa')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFi =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('premiered')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={'mediatype':'episode','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'studio':kJheUjmoRbBWAdfDNuTCzrMQyOnPxv,'cast':kJheUjmoRbBWAdfDNuTCzrMQyOnPFs,'director':kJheUjmoRbBWAdfDNuTCzrMQyOnPFV,'genre':kJheUjmoRbBWAdfDNuTCzrMQyOnPFv,'plot':'%s\n%s\n%s\n\n%s'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPxv,kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,kJheUjmoRbBWAdfDNuTCzrMQyOnPFx,kJheUjmoRbBWAdfDNuTCzrMQyOnPFa),'year':kJheUjmoRbBWAdfDNuTCzrMQyOnPFI,'mpaa':kJheUjmoRbBWAdfDNuTCzrMQyOnPFE,'premiered':kJheUjmoRbBWAdfDNuTCzrMQyOnPFi}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'LIVE','mediacode':kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('mediacode'),'stype':kJheUjmoRbBWAdfDNuTCzrMQyOnPxY}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPxv,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,img=kJheUjmoRbBWAdfDNuTCzrMQyOnPFX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPFw,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxL:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['mode']='CHANNEL' 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['stype']=kJheUjmoRbBWAdfDNuTCzrMQyOnPxY 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['page']=kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY='[B]%s >>[/B]'%'다음 페이지'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFt=kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPFt,img=kJheUjmoRbBWAdfDNuTCzrMQyOnPxX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPEV(kJheUjmoRbBWAdfDNuTCzrMQyOnPxq)>0:xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,cacheToDisc=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX)
 def dp_Program_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPFK =kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('stype')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaS =kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('orderby')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxg =kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('page'))
  kJheUjmoRbBWAdfDNuTCzrMQyOnPFS=kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('genreCode')
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPFS==kJheUjmoRbBWAdfDNuTCzrMQyOnPIq:kJheUjmoRbBWAdfDNuTCzrMQyOnPFS='all'
  kJheUjmoRbBWAdfDNuTCzrMQyOnPFl,kJheUjmoRbBWAdfDNuTCzrMQyOnPxL=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.GetProgramList(kJheUjmoRbBWAdfDNuTCzrMQyOnPFK,kJheUjmoRbBWAdfDNuTCzrMQyOnPaS,kJheUjmoRbBWAdfDNuTCzrMQyOnPxg,kJheUjmoRbBWAdfDNuTCzrMQyOnPFS)
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPFY in kJheUjmoRbBWAdfDNuTCzrMQyOnPFl:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('title')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFX =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('thumbnail')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFa =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('synopsis')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFc =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('channel')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFs =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('cast')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFV =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('director')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFv=kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('info_genre')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFI =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('year')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFi =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('premiered')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFE =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('mpaa')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={'mediatype':'tvshow','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'studio':kJheUjmoRbBWAdfDNuTCzrMQyOnPFc,'cast':kJheUjmoRbBWAdfDNuTCzrMQyOnPFs,'director':kJheUjmoRbBWAdfDNuTCzrMQyOnPFV,'genre':kJheUjmoRbBWAdfDNuTCzrMQyOnPFv,'year':kJheUjmoRbBWAdfDNuTCzrMQyOnPFI,'premiered':kJheUjmoRbBWAdfDNuTCzrMQyOnPFi,'mpaa':kJheUjmoRbBWAdfDNuTCzrMQyOnPFE,'plot':kJheUjmoRbBWAdfDNuTCzrMQyOnPFa}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'EPISODE','programcode':kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('program'),'page':'1'}
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_makebookmark():
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFG={'videoid':kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('program'),'vidtype':'tvshow','vtitle':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'vsubtitle':kJheUjmoRbBWAdfDNuTCzrMQyOnPFc,}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFH=json.dumps(kJheUjmoRbBWAdfDNuTCzrMQyOnPFG)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFH=urllib.parse.quote(kJheUjmoRbBWAdfDNuTCzrMQyOnPFH)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFg='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPFH)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFq=[('(통합) 찜 영상에 추가',kJheUjmoRbBWAdfDNuTCzrMQyOnPFg)]
   else:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFq=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPFc,img=kJheUjmoRbBWAdfDNuTCzrMQyOnPFX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPFw,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa,ContextMenu=kJheUjmoRbBWAdfDNuTCzrMQyOnPFq)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxL:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['mode'] ='PROGRAM' 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['stype'] =kJheUjmoRbBWAdfDNuTCzrMQyOnPFK
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['orderby'] =kJheUjmoRbBWAdfDNuTCzrMQyOnPaS
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['page'] =kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['genreCode']=kJheUjmoRbBWAdfDNuTCzrMQyOnPFS 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY='[B]%s >>[/B]'%'다음 페이지'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFt=kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPFt,img=kJheUjmoRbBWAdfDNuTCzrMQyOnPxX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  xbmcplugin.setContent(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,cacheToDisc=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX)
 def dp_4K_Program_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxg =kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('page'))
  kJheUjmoRbBWAdfDNuTCzrMQyOnPFl,kJheUjmoRbBWAdfDNuTCzrMQyOnPxL=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Get_UHD_ProgramList(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg)
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPFY in kJheUjmoRbBWAdfDNuTCzrMQyOnPFl:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('title')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFX =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('thumbnail')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFa =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('synopsis')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFc =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('channel')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFs =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('cast')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFV =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('director')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFv=kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('info_genre')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFI =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('year')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFi =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('premiered')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFE =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('mpaa')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={'mediatype':'tvshow','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'studio':kJheUjmoRbBWAdfDNuTCzrMQyOnPFc,'cast':kJheUjmoRbBWAdfDNuTCzrMQyOnPFs,'director':kJheUjmoRbBWAdfDNuTCzrMQyOnPFV,'genre':kJheUjmoRbBWAdfDNuTCzrMQyOnPFv,'year':kJheUjmoRbBWAdfDNuTCzrMQyOnPFI,'premiered':kJheUjmoRbBWAdfDNuTCzrMQyOnPFi,'mpaa':kJheUjmoRbBWAdfDNuTCzrMQyOnPFE,'plot':kJheUjmoRbBWAdfDNuTCzrMQyOnPFa}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'EPISODE','programcode':kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('program'),'page':'1'}
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_makebookmark():
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFG={'videoid':kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('program'),'vidtype':'tvshow','vtitle':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'vsubtitle':kJheUjmoRbBWAdfDNuTCzrMQyOnPFc,}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFH=json.dumps(kJheUjmoRbBWAdfDNuTCzrMQyOnPFG)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFH=urllib.parse.quote(kJheUjmoRbBWAdfDNuTCzrMQyOnPFH)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFg='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPFH)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFq=[('(통합) 찜 영상에 추가',kJheUjmoRbBWAdfDNuTCzrMQyOnPFg)]
   else:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFq=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPFc,img=kJheUjmoRbBWAdfDNuTCzrMQyOnPFX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPFw,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa,ContextMenu=kJheUjmoRbBWAdfDNuTCzrMQyOnPFq)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxL:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['mode'] ='4K_PROGRAM' 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['page'] =kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY='[B]%s >>[/B]'%'다음 페이지'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFt=kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPFt,img=kJheUjmoRbBWAdfDNuTCzrMQyOnPxX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  xbmcplugin.setContent(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,cacheToDisc=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX)
 def dp_Ori_Program_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxg =kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('page'))
  kJheUjmoRbBWAdfDNuTCzrMQyOnPFl,kJheUjmoRbBWAdfDNuTCzrMQyOnPxL=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Get_Origianl_ProgramList(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg)
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPFY in kJheUjmoRbBWAdfDNuTCzrMQyOnPFl:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('title')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFX =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('thumbnail')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFp =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('vod_type')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsX =kJheUjmoRbBWAdfDNuTCzrMQyOnPFY.get('vod_code')
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPFp=='vod':
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={'mediatype':'tvshow','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'EPISODE','programcode':kJheUjmoRbBWAdfDNuTCzrMQyOnPsX,'page':'1',}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxF=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp
   else:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={'mediatype':'movie','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'plot':'movie',}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'MOVIE','mediacode':kJheUjmoRbBWAdfDNuTCzrMQyOnPsX,'stype':'movie','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'thumbnail':kJheUjmoRbBWAdfDNuTCzrMQyOnPFX,}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxF=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,img=kJheUjmoRbBWAdfDNuTCzrMQyOnPFX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPFw,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPxF,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa,ContextMenu=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxL:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['mode'] ='ORI_PROGRAM' 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['page'] =kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY='[B]%s >>[/B]'%'다음 페이지'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFt=kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPFt,img=kJheUjmoRbBWAdfDNuTCzrMQyOnPxX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  xbmcplugin.setContent(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,cacheToDisc=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX)
 def dp_Episode_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsa=kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('programcode')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxg =kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('page'))
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsx,kJheUjmoRbBWAdfDNuTCzrMQyOnPxL,kJheUjmoRbBWAdfDNuTCzrMQyOnPsF=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.GetEpisodeList(kJheUjmoRbBWAdfDNuTCzrMQyOnPsa,kJheUjmoRbBWAdfDNuTCzrMQyOnPxg,orderby=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_winEpisodeOrderby())
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPsV in kJheUjmoRbBWAdfDNuTCzrMQyOnPsx:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY =kJheUjmoRbBWAdfDNuTCzrMQyOnPsV.get('title')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFt =kJheUjmoRbBWAdfDNuTCzrMQyOnPsV.get('subtitle')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFX =kJheUjmoRbBWAdfDNuTCzrMQyOnPsV.get('thumbnail')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFa =kJheUjmoRbBWAdfDNuTCzrMQyOnPsV.get('synopsis')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsv=kJheUjmoRbBWAdfDNuTCzrMQyOnPsV.get('info_title')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsI =kJheUjmoRbBWAdfDNuTCzrMQyOnPsV.get('aired')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsE =kJheUjmoRbBWAdfDNuTCzrMQyOnPsV.get('studio')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsi =kJheUjmoRbBWAdfDNuTCzrMQyOnPsV.get('frequency')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={'mediatype':'episode','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPsv,'aired':kJheUjmoRbBWAdfDNuTCzrMQyOnPsI,'studio':kJheUjmoRbBWAdfDNuTCzrMQyOnPsE,'episode':kJheUjmoRbBWAdfDNuTCzrMQyOnPsi,'plot':kJheUjmoRbBWAdfDNuTCzrMQyOnPFa}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'VOD','mediacode':kJheUjmoRbBWAdfDNuTCzrMQyOnPsV.get('episode'),'stype':'vod','programcode':kJheUjmoRbBWAdfDNuTCzrMQyOnPsa,'title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'thumbnail':kJheUjmoRbBWAdfDNuTCzrMQyOnPFX}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPFt,img=kJheUjmoRbBWAdfDNuTCzrMQyOnPFX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPFw,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxg==1:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={'plot':'정렬순서를 변경합니다.'}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['mode'] ='ORDER_BY' 
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_winEpisodeOrderby()=='desc':
    kJheUjmoRbBWAdfDNuTCzrMQyOnPaY='정렬순서변경 : 최신화부터 -> 1회부터'
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['orderby']='asc'
   else:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPaY='정렬순서변경 : 1회부터 -> 최신화부터'
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['orderby']='desc'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel='',img=kJheUjmoRbBWAdfDNuTCzrMQyOnPxX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPFw,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa,isLink=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxL:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['mode'] ='EPISODE' 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['programcode']=kJheUjmoRbBWAdfDNuTCzrMQyOnPsa
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['page'] =kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY='[B]%s >>[/B]'%'다음 페이지'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFt=kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPFt,img=kJheUjmoRbBWAdfDNuTCzrMQyOnPxX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  xbmcplugin.setContent(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,'episodes')
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPEV(kJheUjmoRbBWAdfDNuTCzrMQyOnPsx)>0:xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,cacheToDisc=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp)
 def dp_setEpOrderby(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaS =kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('orderby')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.set_winEpisodeOrderby(kJheUjmoRbBWAdfDNuTCzrMQyOnPaS)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPFK =kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('stype')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaS =kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('orderby')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxg=kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('page'))
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsw,kJheUjmoRbBWAdfDNuTCzrMQyOnPxL=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.GetMovieList(kJheUjmoRbBWAdfDNuTCzrMQyOnPFK,kJheUjmoRbBWAdfDNuTCzrMQyOnPaS,kJheUjmoRbBWAdfDNuTCzrMQyOnPxg)
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPst in kJheUjmoRbBWAdfDNuTCzrMQyOnPsw:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('title')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFX =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('thumbnail')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFa =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('synopsis')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsv =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('info_title')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFI =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('year')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFs =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('cast')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFV =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('director')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFv =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('info_genre')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsK =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('duration')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFi =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('premiered')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsE =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('studio')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFE =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('mpaa')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={'mediatype':'movie','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPsv,'year':kJheUjmoRbBWAdfDNuTCzrMQyOnPFI,'cast':kJheUjmoRbBWAdfDNuTCzrMQyOnPFs,'director':kJheUjmoRbBWAdfDNuTCzrMQyOnPFV,'genre':kJheUjmoRbBWAdfDNuTCzrMQyOnPFv,'duration':kJheUjmoRbBWAdfDNuTCzrMQyOnPsK,'premiered':kJheUjmoRbBWAdfDNuTCzrMQyOnPFi,'studio':kJheUjmoRbBWAdfDNuTCzrMQyOnPsE,'mpaa':kJheUjmoRbBWAdfDNuTCzrMQyOnPFE,'plot':kJheUjmoRbBWAdfDNuTCzrMQyOnPFa}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'MOVIE','mediacode':kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('moviecode'),'stype':'movie','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'thumbnail':kJheUjmoRbBWAdfDNuTCzrMQyOnPFX}
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_makebookmark():
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFG={'videoid':kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('moviecode'),'vidtype':'movie','vtitle':kJheUjmoRbBWAdfDNuTCzrMQyOnPsv,'vsubtitle':'',}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFH=json.dumps(kJheUjmoRbBWAdfDNuTCzrMQyOnPFG)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFH=urllib.parse.quote(kJheUjmoRbBWAdfDNuTCzrMQyOnPFH)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFg='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPFH)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFq=[('(통합) 찜 영상에 추가',kJheUjmoRbBWAdfDNuTCzrMQyOnPFg)]
   else:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFq=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel='',img=kJheUjmoRbBWAdfDNuTCzrMQyOnPFX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPFw,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa,ContextMenu=kJheUjmoRbBWAdfDNuTCzrMQyOnPFq)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxL:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['mode'] ='MOVIE_SUB' 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['orderby']=kJheUjmoRbBWAdfDNuTCzrMQyOnPaS
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['stype'] =kJheUjmoRbBWAdfDNuTCzrMQyOnPFK
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['page'] =kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY='[B]%s >>[/B]'%'다음 페이지'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFt=kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPFt,img=kJheUjmoRbBWAdfDNuTCzrMQyOnPxX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  xbmcplugin.setContent(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,'movies')
  xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,cacheToDisc=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX)
 def dp_4K_Movie_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxg=kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('page'))
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsw,kJheUjmoRbBWAdfDNuTCzrMQyOnPxL=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Get_UHD_MovieList(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg)
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPst in kJheUjmoRbBWAdfDNuTCzrMQyOnPsw:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('title')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFX =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('thumbnail')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFa =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('synopsis')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsv =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('info_title')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFI =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('year')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFs =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('cast')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFV =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('director')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFv =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('info_genre')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsK =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('duration')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFi =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('premiered')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsE =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('studio')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFE =kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('mpaa')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={'mediatype':'movie','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPsv,'year':kJheUjmoRbBWAdfDNuTCzrMQyOnPFI,'cast':kJheUjmoRbBWAdfDNuTCzrMQyOnPFs,'director':kJheUjmoRbBWAdfDNuTCzrMQyOnPFV,'genre':kJheUjmoRbBWAdfDNuTCzrMQyOnPFv,'duration':kJheUjmoRbBWAdfDNuTCzrMQyOnPsK,'premiered':kJheUjmoRbBWAdfDNuTCzrMQyOnPFi,'studio':kJheUjmoRbBWAdfDNuTCzrMQyOnPsE,'mpaa':kJheUjmoRbBWAdfDNuTCzrMQyOnPFE,'plot':kJheUjmoRbBWAdfDNuTCzrMQyOnPFa}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'MOVIE','mediacode':kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('moviecode'),'stype':'movie','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'thumbnail':kJheUjmoRbBWAdfDNuTCzrMQyOnPFX}
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_makebookmark():
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFG={'videoid':kJheUjmoRbBWAdfDNuTCzrMQyOnPst.get('moviecode'),'vidtype':'movie','vtitle':kJheUjmoRbBWAdfDNuTCzrMQyOnPsv,'vsubtitle':'',}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFH=json.dumps(kJheUjmoRbBWAdfDNuTCzrMQyOnPFG)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFH=urllib.parse.quote(kJheUjmoRbBWAdfDNuTCzrMQyOnPFH)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFg='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPFH)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFq=[('(통합) 찜 영상에 추가',kJheUjmoRbBWAdfDNuTCzrMQyOnPFg)]
   else:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFq=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel='',img=kJheUjmoRbBWAdfDNuTCzrMQyOnPFX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPFw,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa,ContextMenu=kJheUjmoRbBWAdfDNuTCzrMQyOnPFq)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxL:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['mode'] ='4K_MOVIE' 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['page'] =kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY='[B]%s >>[/B]'%'다음 페이지'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFt=kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPFt,img=kJheUjmoRbBWAdfDNuTCzrMQyOnPxX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  xbmcplugin.setContent(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,'movies')
  xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,cacheToDisc=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX)
 def dp_Set_Bookmark(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsS=urllib.parse.unquote(kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('bm_param'))
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsS=json.loads(kJheUjmoRbBWAdfDNuTCzrMQyOnPsS)
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsl =kJheUjmoRbBWAdfDNuTCzrMQyOnPsS.get('videoid')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsY =kJheUjmoRbBWAdfDNuTCzrMQyOnPsS.get('vidtype')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsc =kJheUjmoRbBWAdfDNuTCzrMQyOnPsS.get('vtitle')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsG =kJheUjmoRbBWAdfDNuTCzrMQyOnPsS.get('vsubtitle')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXG=xbmcgui.Dialog()
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxt=kJheUjmoRbBWAdfDNuTCzrMQyOnPXG.yesno(__language__(30913).encode('utf8'),kJheUjmoRbBWAdfDNuTCzrMQyOnPsc+' \n\n'+__language__(30914))
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxt==kJheUjmoRbBWAdfDNuTCzrMQyOnPEX:return
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsH=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.GetBookmarkInfo(kJheUjmoRbBWAdfDNuTCzrMQyOnPsl,kJheUjmoRbBWAdfDNuTCzrMQyOnPsY)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPsG!='':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsH['saveinfo']['subtitle']=kJheUjmoRbBWAdfDNuTCzrMQyOnPsG 
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPsY=='tvshow':kJheUjmoRbBWAdfDNuTCzrMQyOnPsH['saveinfo']['infoLabels']['studio']=kJheUjmoRbBWAdfDNuTCzrMQyOnPsG 
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsg=json.dumps(kJheUjmoRbBWAdfDNuTCzrMQyOnPsH)
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsg=urllib.parse.quote(kJheUjmoRbBWAdfDNuTCzrMQyOnPsg)
  kJheUjmoRbBWAdfDNuTCzrMQyOnPFg ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPsg)
  xbmc.executebuiltin(kJheUjmoRbBWAdfDNuTCzrMQyOnPFg)
 def dp_Search_Group(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  if 'search_key' in kJheUjmoRbBWAdfDNuTCzrMQyOnPxH:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsq=kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('search_key')
  else:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsq=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not kJheUjmoRbBWAdfDNuTCzrMQyOnPsq:
    return
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPxG in kJheUjmoRbBWAdfDNuTCzrMQyOnPXV:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsL =kJheUjmoRbBWAdfDNuTCzrMQyOnPxG.get('mode')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxY=kJheUjmoRbBWAdfDNuTCzrMQyOnPxG.get('stype')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY=kJheUjmoRbBWAdfDNuTCzrMQyOnPxG.get('title')
   (kJheUjmoRbBWAdfDNuTCzrMQyOnPsp,kJheUjmoRbBWAdfDNuTCzrMQyOnPxL)=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.GetSearchList(kJheUjmoRbBWAdfDNuTCzrMQyOnPsq,1,kJheUjmoRbBWAdfDNuTCzrMQyOnPxY)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxV={'plot':'검색어 : '+kJheUjmoRbBWAdfDNuTCzrMQyOnPsq+'\n\n'+kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.Search_FreeList(kJheUjmoRbBWAdfDNuTCzrMQyOnPsp)}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':kJheUjmoRbBWAdfDNuTCzrMQyOnPsL,'stype':kJheUjmoRbBWAdfDNuTCzrMQyOnPxY,'search_key':kJheUjmoRbBWAdfDNuTCzrMQyOnPsq,'page':'1',}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel='',img='',infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPxV,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPEV(kJheUjmoRbBWAdfDNuTCzrMQyOnPXV)>0:xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,cacheToDisc=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp)
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.Save_Searched_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPsq)
 def Search_FreeList(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPVi):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPVX=''
  kJheUjmoRbBWAdfDNuTCzrMQyOnPVa=7
  try:
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPEV(kJheUjmoRbBWAdfDNuTCzrMQyOnPVi)==0:return '검색결과 없음'
   for i in kJheUjmoRbBWAdfDNuTCzrMQyOnPEI(kJheUjmoRbBWAdfDNuTCzrMQyOnPEV(kJheUjmoRbBWAdfDNuTCzrMQyOnPVi)):
    if i>=kJheUjmoRbBWAdfDNuTCzrMQyOnPVa:
     kJheUjmoRbBWAdfDNuTCzrMQyOnPVX=kJheUjmoRbBWAdfDNuTCzrMQyOnPVX+'...'
     break
    kJheUjmoRbBWAdfDNuTCzrMQyOnPVX=kJheUjmoRbBWAdfDNuTCzrMQyOnPVX+kJheUjmoRbBWAdfDNuTCzrMQyOnPVi[i]['title']+'\n'
  except:
   return ''
  return kJheUjmoRbBWAdfDNuTCzrMQyOnPVX
 def dp_Search_History(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPVx=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.Load_List_File('search')
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPVF in kJheUjmoRbBWAdfDNuTCzrMQyOnPVx:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVs=kJheUjmoRbBWAdfDNuTCzrMQyOnPEx(urllib.parse.parse_qsl(kJheUjmoRbBWAdfDNuTCzrMQyOnPVF))
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVv=kJheUjmoRbBWAdfDNuTCzrMQyOnPVs.get('skey').strip()
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'SEARCH_GROUP','search_key':kJheUjmoRbBWAdfDNuTCzrMQyOnPVv,}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVI={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':kJheUjmoRbBWAdfDNuTCzrMQyOnPVv,'vType':'-',}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVE=urllib.parse.urlencode(kJheUjmoRbBWAdfDNuTCzrMQyOnPVI)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFq=[('선택된 검색어 ( %s ) 삭제'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPVv),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPVE))]
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPVv,sublabel='',img=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa,ContextMenu=kJheUjmoRbBWAdfDNuTCzrMQyOnPFq)
  kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={'plot':'검색목록 전체를 삭제합니다.'}
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaY='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel='',img=kJheUjmoRbBWAdfDNuTCzrMQyOnPxX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPFw,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa,isLink=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp)
  xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,cacheToDisc=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX)
 def dp_Search_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxg =kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('page'))
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxY =kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('stype')
  if 'search_key' in kJheUjmoRbBWAdfDNuTCzrMQyOnPxH:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsq=kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('search_key')
  else:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsq=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not kJheUjmoRbBWAdfDNuTCzrMQyOnPsq:
    xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle)
    return
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsp,kJheUjmoRbBWAdfDNuTCzrMQyOnPxL=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.GetSearchList(kJheUjmoRbBWAdfDNuTCzrMQyOnPsq,kJheUjmoRbBWAdfDNuTCzrMQyOnPxg,kJheUjmoRbBWAdfDNuTCzrMQyOnPxY)
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPVi in kJheUjmoRbBWAdfDNuTCzrMQyOnPsp:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY =kJheUjmoRbBWAdfDNuTCzrMQyOnPVi.get('title')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFX =kJheUjmoRbBWAdfDNuTCzrMQyOnPVi.get('thumbnail')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFa =kJheUjmoRbBWAdfDNuTCzrMQyOnPVi.get('synopsis')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVw =kJheUjmoRbBWAdfDNuTCzrMQyOnPVi.get('program')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFs =kJheUjmoRbBWAdfDNuTCzrMQyOnPVi.get('cast')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFV =kJheUjmoRbBWAdfDNuTCzrMQyOnPVi.get('director')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFv=kJheUjmoRbBWAdfDNuTCzrMQyOnPVi.get('info_genre')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsK =kJheUjmoRbBWAdfDNuTCzrMQyOnPVi.get('duration')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFE =kJheUjmoRbBWAdfDNuTCzrMQyOnPVi.get('mpaa')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFI =kJheUjmoRbBWAdfDNuTCzrMQyOnPVi.get('year')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPsI =kJheUjmoRbBWAdfDNuTCzrMQyOnPVi.get('aired')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={'mediatype':'tvshow' if kJheUjmoRbBWAdfDNuTCzrMQyOnPxY=='vod' else 'movie','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'cast':kJheUjmoRbBWAdfDNuTCzrMQyOnPFs,'director':kJheUjmoRbBWAdfDNuTCzrMQyOnPFV,'genre':kJheUjmoRbBWAdfDNuTCzrMQyOnPFv,'duration':kJheUjmoRbBWAdfDNuTCzrMQyOnPsK,'mpaa':kJheUjmoRbBWAdfDNuTCzrMQyOnPFE,'year':kJheUjmoRbBWAdfDNuTCzrMQyOnPFI,'aired':kJheUjmoRbBWAdfDNuTCzrMQyOnPsI,'plot':'%s\n\n%s'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,kJheUjmoRbBWAdfDNuTCzrMQyOnPFa)}
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPxY=='vod':
    kJheUjmoRbBWAdfDNuTCzrMQyOnPsl=kJheUjmoRbBWAdfDNuTCzrMQyOnPVi.get('program')
    kJheUjmoRbBWAdfDNuTCzrMQyOnPsY='tvshow'
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'EPISODE','programcode':kJheUjmoRbBWAdfDNuTCzrMQyOnPsl,'page':'1',}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxF=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp
   else:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPsl=kJheUjmoRbBWAdfDNuTCzrMQyOnPVi.get('movie')
    kJheUjmoRbBWAdfDNuTCzrMQyOnPsY='movie'
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'MOVIE','mediacode':kJheUjmoRbBWAdfDNuTCzrMQyOnPsl,'stype':'movie','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'thumbnail':kJheUjmoRbBWAdfDNuTCzrMQyOnPFX,}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxF=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_makebookmark():
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFG={'videoid':kJheUjmoRbBWAdfDNuTCzrMQyOnPsl,'vidtype':kJheUjmoRbBWAdfDNuTCzrMQyOnPsY,'vtitle':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'vsubtitle':'',}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFH=json.dumps(kJheUjmoRbBWAdfDNuTCzrMQyOnPFG)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFH=urllib.parse.quote(kJheUjmoRbBWAdfDNuTCzrMQyOnPFH)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFg='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPFH)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFq=[('(통합) 찜 영상에 추가',kJheUjmoRbBWAdfDNuTCzrMQyOnPFg)]
   else:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFq=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel='',img=kJheUjmoRbBWAdfDNuTCzrMQyOnPFX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPFw,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPxF,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa,isLink=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX,ContextMenu=kJheUjmoRbBWAdfDNuTCzrMQyOnPFq)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxL:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['mode'] ='SEARCH' 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['search_key']=kJheUjmoRbBWAdfDNuTCzrMQyOnPsq
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa['page'] =kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY='[B]%s >>[/B]'%'다음 페이지'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFt=kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPxg+1)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPFt,img=kJheUjmoRbBWAdfDNuTCzrMQyOnPxX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxY=='movie':xbmcplugin.setContent(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,'movies')
  else:xbmcplugin.setContent(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,cacheToDisc=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX)
 def dp_History_Remove(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPVt=kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('delType')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPVK =kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('sKey')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPVS =kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('vType')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXG=xbmcgui.Dialog()
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPVt=='SEARCH_ALL':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxt=kJheUjmoRbBWAdfDNuTCzrMQyOnPXG.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPVt=='SEARCH_ONE':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxt=kJheUjmoRbBWAdfDNuTCzrMQyOnPXG.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPVt=='WATCH_ALL':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxt=kJheUjmoRbBWAdfDNuTCzrMQyOnPXG.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPVt=='WATCH_ONE':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxt=kJheUjmoRbBWAdfDNuTCzrMQyOnPXG.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxt==kJheUjmoRbBWAdfDNuTCzrMQyOnPEX:sys.exit()
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPVt=='SEARCH_ALL':
   if os.path.isfile(kJheUjmoRbBWAdfDNuTCzrMQyOnPXt):os.remove(kJheUjmoRbBWAdfDNuTCzrMQyOnPXt)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPVt=='SEARCH_ONE':
   try:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPVl=kJheUjmoRbBWAdfDNuTCzrMQyOnPXt
    kJheUjmoRbBWAdfDNuTCzrMQyOnPVY=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.Load_List_File('search') 
    fp=kJheUjmoRbBWAdfDNuTCzrMQyOnPEi(kJheUjmoRbBWAdfDNuTCzrMQyOnPVl,'w',-1,'utf-8')
    for kJheUjmoRbBWAdfDNuTCzrMQyOnPVc in kJheUjmoRbBWAdfDNuTCzrMQyOnPVY:
     kJheUjmoRbBWAdfDNuTCzrMQyOnPVG=kJheUjmoRbBWAdfDNuTCzrMQyOnPEx(urllib.parse.parse_qsl(kJheUjmoRbBWAdfDNuTCzrMQyOnPVc))
     kJheUjmoRbBWAdfDNuTCzrMQyOnPVH=kJheUjmoRbBWAdfDNuTCzrMQyOnPVG.get('skey').strip()
     if kJheUjmoRbBWAdfDNuTCzrMQyOnPVK!=kJheUjmoRbBWAdfDNuTCzrMQyOnPVH:
      fp.write(kJheUjmoRbBWAdfDNuTCzrMQyOnPVc)
    fp.close()
   except:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPVt=='WATCH_ALL':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%kJheUjmoRbBWAdfDNuTCzrMQyOnPVS))
   if os.path.isfile(kJheUjmoRbBWAdfDNuTCzrMQyOnPVl):os.remove(kJheUjmoRbBWAdfDNuTCzrMQyOnPVl)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPVt=='WATCH_ONE':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%kJheUjmoRbBWAdfDNuTCzrMQyOnPVS))
   try:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPVY=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.Load_List_File(kJheUjmoRbBWAdfDNuTCzrMQyOnPVS) 
    fp=kJheUjmoRbBWAdfDNuTCzrMQyOnPEi(kJheUjmoRbBWAdfDNuTCzrMQyOnPVl,'w',-1,'utf-8')
    for kJheUjmoRbBWAdfDNuTCzrMQyOnPVc in kJheUjmoRbBWAdfDNuTCzrMQyOnPVY:
     kJheUjmoRbBWAdfDNuTCzrMQyOnPVG=kJheUjmoRbBWAdfDNuTCzrMQyOnPEx(urllib.parse.parse_qsl(kJheUjmoRbBWAdfDNuTCzrMQyOnPVc))
     kJheUjmoRbBWAdfDNuTCzrMQyOnPVH=kJheUjmoRbBWAdfDNuTCzrMQyOnPVG.get('code').strip()
     if kJheUjmoRbBWAdfDNuTCzrMQyOnPVK!=kJheUjmoRbBWAdfDNuTCzrMQyOnPVH:
      fp.write(kJheUjmoRbBWAdfDNuTCzrMQyOnPVc)
    fp.close()
   except:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxY): 
  try:
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPxY=='search':
    kJheUjmoRbBWAdfDNuTCzrMQyOnPVl=kJheUjmoRbBWAdfDNuTCzrMQyOnPXt
   elif kJheUjmoRbBWAdfDNuTCzrMQyOnPxY in['vod','movie']:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPVl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%kJheUjmoRbBWAdfDNuTCzrMQyOnPxY))
   else:
    return[]
   fp=kJheUjmoRbBWAdfDNuTCzrMQyOnPEi(kJheUjmoRbBWAdfDNuTCzrMQyOnPVl,'r',-1,'utf-8')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVg=fp.readlines()
   fp.close()
  except:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVg=[]
  return kJheUjmoRbBWAdfDNuTCzrMQyOnPVg
 def Save_Watched_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxY,kJheUjmoRbBWAdfDNuTCzrMQyOnPXY):
  try:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVq=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%kJheUjmoRbBWAdfDNuTCzrMQyOnPxY))
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVY=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.Load_List_File(kJheUjmoRbBWAdfDNuTCzrMQyOnPxY) 
   fp=kJheUjmoRbBWAdfDNuTCzrMQyOnPEi(kJheUjmoRbBWAdfDNuTCzrMQyOnPVq,'w',-1,'utf-8')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVL=urllib.parse.urlencode(kJheUjmoRbBWAdfDNuTCzrMQyOnPXY)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVL=kJheUjmoRbBWAdfDNuTCzrMQyOnPVL+'\n'
   fp.write(kJheUjmoRbBWAdfDNuTCzrMQyOnPVL)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVp=0
   for kJheUjmoRbBWAdfDNuTCzrMQyOnPVc in kJheUjmoRbBWAdfDNuTCzrMQyOnPVY:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPVG=kJheUjmoRbBWAdfDNuTCzrMQyOnPEx(urllib.parse.parse_qsl(kJheUjmoRbBWAdfDNuTCzrMQyOnPVc))
    kJheUjmoRbBWAdfDNuTCzrMQyOnPvX=kJheUjmoRbBWAdfDNuTCzrMQyOnPXY.get('code').strip()
    kJheUjmoRbBWAdfDNuTCzrMQyOnPva=kJheUjmoRbBWAdfDNuTCzrMQyOnPVG.get('code').strip()
    if kJheUjmoRbBWAdfDNuTCzrMQyOnPxY=='vod' and kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_direct_replay()==kJheUjmoRbBWAdfDNuTCzrMQyOnPIp:
     kJheUjmoRbBWAdfDNuTCzrMQyOnPvX=kJheUjmoRbBWAdfDNuTCzrMQyOnPXY.get('videoid').strip()
     kJheUjmoRbBWAdfDNuTCzrMQyOnPva=kJheUjmoRbBWAdfDNuTCzrMQyOnPVG.get('videoid').strip()if kJheUjmoRbBWAdfDNuTCzrMQyOnPva!=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq else '-'
    if kJheUjmoRbBWAdfDNuTCzrMQyOnPvX!=kJheUjmoRbBWAdfDNuTCzrMQyOnPva:
     fp.write(kJheUjmoRbBWAdfDNuTCzrMQyOnPVc)
     kJheUjmoRbBWAdfDNuTCzrMQyOnPVp+=1
     if kJheUjmoRbBWAdfDNuTCzrMQyOnPVp>=50:break
   fp.close()
  except:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
 def dp_Watch_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxY =kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('stype')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPat=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_direct_replay()
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxY=='-':
   for kJheUjmoRbBWAdfDNuTCzrMQyOnPxG in kJheUjmoRbBWAdfDNuTCzrMQyOnPXs:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPaY=kJheUjmoRbBWAdfDNuTCzrMQyOnPxG.get('title')
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':kJheUjmoRbBWAdfDNuTCzrMQyOnPxG.get('mode'),'stype':kJheUjmoRbBWAdfDNuTCzrMQyOnPxG.get('stype')}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel='',img='',infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPIq,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPEV(kJheUjmoRbBWAdfDNuTCzrMQyOnPXs)>0:xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle)
  else:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvx=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.Load_List_File(kJheUjmoRbBWAdfDNuTCzrMQyOnPxY)
   for kJheUjmoRbBWAdfDNuTCzrMQyOnPvF in kJheUjmoRbBWAdfDNuTCzrMQyOnPvx:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPVs=kJheUjmoRbBWAdfDNuTCzrMQyOnPEx(urllib.parse.parse_qsl(kJheUjmoRbBWAdfDNuTCzrMQyOnPvF))
    kJheUjmoRbBWAdfDNuTCzrMQyOnPvs =kJheUjmoRbBWAdfDNuTCzrMQyOnPVs.get('code').strip()
    kJheUjmoRbBWAdfDNuTCzrMQyOnPaY =kJheUjmoRbBWAdfDNuTCzrMQyOnPVs.get('title').strip()
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFX=kJheUjmoRbBWAdfDNuTCzrMQyOnPVs.get('img').strip()
    kJheUjmoRbBWAdfDNuTCzrMQyOnPsl =kJheUjmoRbBWAdfDNuTCzrMQyOnPVs.get('videoid').strip()
    try:
     kJheUjmoRbBWAdfDNuTCzrMQyOnPFX=kJheUjmoRbBWAdfDNuTCzrMQyOnPFX.replace('\'','\"')
     kJheUjmoRbBWAdfDNuTCzrMQyOnPFX=json.loads(kJheUjmoRbBWAdfDNuTCzrMQyOnPFX)
    except:
     kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFw['plot']=kJheUjmoRbBWAdfDNuTCzrMQyOnPaY
    if kJheUjmoRbBWAdfDNuTCzrMQyOnPxY=='vod':
     if kJheUjmoRbBWAdfDNuTCzrMQyOnPat==kJheUjmoRbBWAdfDNuTCzrMQyOnPEX or kJheUjmoRbBWAdfDNuTCzrMQyOnPsl==kJheUjmoRbBWAdfDNuTCzrMQyOnPIq:
      kJheUjmoRbBWAdfDNuTCzrMQyOnPFw['mediatype']='tvshow'
      kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'EPISODE','programcode':kJheUjmoRbBWAdfDNuTCzrMQyOnPvs,'page':'1'}
      kJheUjmoRbBWAdfDNuTCzrMQyOnPxF=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp
     else:
      kJheUjmoRbBWAdfDNuTCzrMQyOnPFw['mediatype']='episode'
      kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'VOD','mediacode':kJheUjmoRbBWAdfDNuTCzrMQyOnPsl,'stype':'vod','programcode':kJheUjmoRbBWAdfDNuTCzrMQyOnPvs,'title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'thumbnail':kJheUjmoRbBWAdfDNuTCzrMQyOnPFX}
      kJheUjmoRbBWAdfDNuTCzrMQyOnPxF=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
    else:
     kJheUjmoRbBWAdfDNuTCzrMQyOnPFw['mediatype']='movie'
     kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'MOVIE','mediacode':kJheUjmoRbBWAdfDNuTCzrMQyOnPvs,'stype':'movie','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'thumbnail':kJheUjmoRbBWAdfDNuTCzrMQyOnPFX}
     kJheUjmoRbBWAdfDNuTCzrMQyOnPxF=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
    kJheUjmoRbBWAdfDNuTCzrMQyOnPVI={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':kJheUjmoRbBWAdfDNuTCzrMQyOnPvs,'vType':kJheUjmoRbBWAdfDNuTCzrMQyOnPxY,}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPVE=urllib.parse.urlencode(kJheUjmoRbBWAdfDNuTCzrMQyOnPVI)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPFq=[('선택된 시청이력 ( %s ) 삭제'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPVE))]
    kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel='',img=kJheUjmoRbBWAdfDNuTCzrMQyOnPFX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPFw,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPxF,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa,ContextMenu=kJheUjmoRbBWAdfDNuTCzrMQyOnPFq)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={'plot':'시청목록을 삭제합니다.'}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':kJheUjmoRbBWAdfDNuTCzrMQyOnPxY,}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxX=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel='',img=kJheUjmoRbBWAdfDNuTCzrMQyOnPxX,infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPFw,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa,isLink=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp)
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPxY=='movie':xbmcplugin.setContent(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,'movies')
   else:xbmcplugin.setContent(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,cacheToDisc=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX)
 def Save_Searched_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPsq):
  try:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvV=kJheUjmoRbBWAdfDNuTCzrMQyOnPXt
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVY=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.Load_List_File('search') 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvI={'skey':kJheUjmoRbBWAdfDNuTCzrMQyOnPsq.strip()}
   fp=kJheUjmoRbBWAdfDNuTCzrMQyOnPEi(kJheUjmoRbBWAdfDNuTCzrMQyOnPvV,'w',-1,'utf-8')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVL=urllib.parse.urlencode(kJheUjmoRbBWAdfDNuTCzrMQyOnPvI)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVL=kJheUjmoRbBWAdfDNuTCzrMQyOnPVL+'\n'
   fp.write(kJheUjmoRbBWAdfDNuTCzrMQyOnPVL)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPVp=0
   for kJheUjmoRbBWAdfDNuTCzrMQyOnPVc in kJheUjmoRbBWAdfDNuTCzrMQyOnPVY:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPVG=kJheUjmoRbBWAdfDNuTCzrMQyOnPEx(urllib.parse.parse_qsl(kJheUjmoRbBWAdfDNuTCzrMQyOnPVc))
    kJheUjmoRbBWAdfDNuTCzrMQyOnPvX=kJheUjmoRbBWAdfDNuTCzrMQyOnPvI.get('skey').strip()
    kJheUjmoRbBWAdfDNuTCzrMQyOnPva=kJheUjmoRbBWAdfDNuTCzrMQyOnPVG.get('skey').strip()
    if kJheUjmoRbBWAdfDNuTCzrMQyOnPvX!=kJheUjmoRbBWAdfDNuTCzrMQyOnPva:
     fp.write(kJheUjmoRbBWAdfDNuTCzrMQyOnPVc)
     kJheUjmoRbBWAdfDNuTCzrMQyOnPVp+=1
     if kJheUjmoRbBWAdfDNuTCzrMQyOnPVp>=50:break
   fp.close()
  except:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
 def play_VIDEO(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPvE =kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('mediacode')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxY =kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('stype')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPvi =kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('pvrmode')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPvw=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_selQuality(kJheUjmoRbBWAdfDNuTCzrMQyOnPxY)
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPvE,kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPvw),kJheUjmoRbBWAdfDNuTCzrMQyOnPxY,kJheUjmoRbBWAdfDNuTCzrMQyOnPvi))
  kJheUjmoRbBWAdfDNuTCzrMQyOnPvt=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.GetBroadURL(kJheUjmoRbBWAdfDNuTCzrMQyOnPvE,kJheUjmoRbBWAdfDNuTCzrMQyOnPvw,kJheUjmoRbBWAdfDNuTCzrMQyOnPxY,kJheUjmoRbBWAdfDNuTCzrMQyOnPvi,optUHD=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_uhd())
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.addon_log('qt, stype, url : %s - %s - %s'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPEv(kJheUjmoRbBWAdfDNuTCzrMQyOnPvw),kJheUjmoRbBWAdfDNuTCzrMQyOnPxY,kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['streaming_url']))
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['streaming_url']=='':
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['error_msg']=='':
    kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.addon_noti(__language__(30908).encode('utf8'))
   else:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.addon_noti(kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['error_msg'].encode('utf8'))
   return
  kJheUjmoRbBWAdfDNuTCzrMQyOnPvK={'user-agent':kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.USER_AGENT}
  kJheUjmoRbBWAdfDNuTCzrMQyOnPvS=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.makeDefaultCookies() 
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['drm_server_url'] !='':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvK[kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['drm_header_key']]=kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['drm_header_value']
  kJheUjmoRbBWAdfDNuTCzrMQyOnPvl =kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
  kJheUjmoRbBWAdfDNuTCzrMQyOnPvY =kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['streaming_url'].find('Policy=')
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPvY!=-1:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvc =kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['streaming_url'].split('?')[0]
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvG=kJheUjmoRbBWAdfDNuTCzrMQyOnPEx(urllib.parse.parse_qsl(urllib.parse.urlsplit(kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['streaming_url']).query))
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvS['CloudFront-Policy'] =kJheUjmoRbBWAdfDNuTCzrMQyOnPvG['Policy'] 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvS['CloudFront-Signature'] =kJheUjmoRbBWAdfDNuTCzrMQyOnPvG['Signature'] 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvS['CloudFront-Key-Pair-Id']=kJheUjmoRbBWAdfDNuTCzrMQyOnPvG['Key-Pair-Id'] 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvH=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.make_stream_header(kJheUjmoRbBWAdfDNuTCzrMQyOnPvK,kJheUjmoRbBWAdfDNuTCzrMQyOnPvS)
   if 'quickvod-mcdn.tving.com' in kJheUjmoRbBWAdfDNuTCzrMQyOnPvc:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPvl=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp
    kJheUjmoRbBWAdfDNuTCzrMQyOnPvg =kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    kJheUjmoRbBWAdfDNuTCzrMQyOnPvq=kJheUjmoRbBWAdfDNuTCzrMQyOnPvg.strftime('%Y-%m-%d-%H:%M:%S')
    if kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(kJheUjmoRbBWAdfDNuTCzrMQyOnPvq.replace('-','').replace(':',''))<kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(kJheUjmoRbBWAdfDNuTCzrMQyOnPvG['end'].replace('-','').replace(':','')):
     kJheUjmoRbBWAdfDNuTCzrMQyOnPvG['end']=kJheUjmoRbBWAdfDNuTCzrMQyOnPvq
     kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.addon_noti(__language__(30915).encode('utf8'))
    kJheUjmoRbBWAdfDNuTCzrMQyOnPvc ='%s?%s'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPvc,urllib.parse.urlencode(kJheUjmoRbBWAdfDNuTCzrMQyOnPvG,doseq=kJheUjmoRbBWAdfDNuTCzrMQyOnPIp))
    kJheUjmoRbBWAdfDNuTCzrMQyOnPvL='{}|{}'.format(kJheUjmoRbBWAdfDNuTCzrMQyOnPvc,kJheUjmoRbBWAdfDNuTCzrMQyOnPvH)
   else:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPvL='{}|{}'.format(kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['streaming_url'],kJheUjmoRbBWAdfDNuTCzrMQyOnPvH)
  else:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvH=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.make_stream_header(kJheUjmoRbBWAdfDNuTCzrMQyOnPvK,kJheUjmoRbBWAdfDNuTCzrMQyOnPvS)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvL='{}|{}'.format(kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['streaming_url'],kJheUjmoRbBWAdfDNuTCzrMQyOnPvH)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.addon_log('if tmp_pos == -1')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPas,kJheUjmoRbBWAdfDNuTCzrMQyOnPaV=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_proxyport()
  kJheUjmoRbBWAdfDNuTCzrMQyOnPaF=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_playback()
  if(kJheUjmoRbBWAdfDNuTCzrMQyOnPas and kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('mode')in['VOD','MOVIE']and kJheUjmoRbBWAdfDNuTCzrMQyOnPvl==kJheUjmoRbBWAdfDNuTCzrMQyOnPEX and(kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['drm_server_url']!='' or kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.KodiVersion>=21)):
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['url_filename'].split('.')[1]=='mpd':
    kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Tving_Parse_mpd(kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['streaming_url'])
   else:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Tving_Parse_m3u8(kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['streaming_url'])
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.addon_log('xxx '+kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['streaming_url'])
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvp={'addon':'tvingm','playOption':kJheUjmoRbBWAdfDNuTCzrMQyOnPaF,'url_filename':kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['url_filename'],}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvp=json.dumps(kJheUjmoRbBWAdfDNuTCzrMQyOnPvp,separators=(',',':'))
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvp=base64.standard_b64encode(kJheUjmoRbBWAdfDNuTCzrMQyOnPvp.encode()).decode('utf-8')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvL ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(kJheUjmoRbBWAdfDNuTCzrMQyOnPaV,kJheUjmoRbBWAdfDNuTCzrMQyOnPvL,kJheUjmoRbBWAdfDNuTCzrMQyOnPvp)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPvK['proxy-mini']=kJheUjmoRbBWAdfDNuTCzrMQyOnPvp 
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.addon_log('surl(2) : {}'.format(kJheUjmoRbBWAdfDNuTCzrMQyOnPvL))
  kJheUjmoRbBWAdfDNuTCzrMQyOnPvH=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.make_stream_header(kJheUjmoRbBWAdfDNuTCzrMQyOnPvK,kJheUjmoRbBWAdfDNuTCzrMQyOnPvS)
  kJheUjmoRbBWAdfDNuTCzrMQyOnPIX=xbmcgui.ListItem(path=kJheUjmoRbBWAdfDNuTCzrMQyOnPvL)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['drm_server_url']!='':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIa=kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['drm_server_url']
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIx ='https://license-global.pallycon.com/ri/licenseManager.do' 
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIF ='mpd'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIs ='com.widevine.alpha'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIV={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.USER_AGENT,kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['drm_header_key']:kJheUjmoRbBWAdfDNuTCzrMQyOnPvt['drm_header_value'],}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIv=kJheUjmoRbBWAdfDNuTCzrMQyOnPIx+'|'+urllib.parse.urlencode(kJheUjmoRbBWAdfDNuTCzrMQyOnPIV)+'|R{SSM}|'
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream','inputstream.adaptive')
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.KodiVersion<=20:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream.adaptive.manifest_type',kJheUjmoRbBWAdfDNuTCzrMQyOnPIF)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream.adaptive.license_type',kJheUjmoRbBWAdfDNuTCzrMQyOnPIs)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream.adaptive.license_key',kJheUjmoRbBWAdfDNuTCzrMQyOnPIv)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream.adaptive.stream_headers',kJheUjmoRbBWAdfDNuTCzrMQyOnPvH)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream.adaptive.manifest_headers',kJheUjmoRbBWAdfDNuTCzrMQyOnPvH)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('mode')in['VOD','MOVIE']:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setContentLookup(kJheUjmoRbBWAdfDNuTCzrMQyOnPEX)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setMimeType('application/x-mpegURL')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream','inputstream.adaptive')
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.KodiVersion<=20:
    kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream.adaptive.manifest_type','hls')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream.adaptive.stream_headers',kJheUjmoRbBWAdfDNuTCzrMQyOnPvH)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream.adaptive.manifest_headers',kJheUjmoRbBWAdfDNuTCzrMQyOnPvH)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPvl==kJheUjmoRbBWAdfDNuTCzrMQyOnPIp:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setContentLookup(kJheUjmoRbBWAdfDNuTCzrMQyOnPEX)
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setMimeType('application/x-mpegURL')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream','inputstream.ffmpegdirect')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('ResumeTime','0')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIX.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,kJheUjmoRbBWAdfDNuTCzrMQyOnPIp,kJheUjmoRbBWAdfDNuTCzrMQyOnPIX)
  try:
   if kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('mode')in['VOD','MOVIE']and kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('title'):
    kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'code':kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('programcode')if kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('mode')=='VOD' else kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('mediacode'),'img':kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('thumbnail'),'title':kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('title'),'videoid':kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('mediacode')}
    kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.Save_Watched_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('stype'),kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  except:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
 def logout(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXG=xbmcgui.Dialog()
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxt=kJheUjmoRbBWAdfDNuTCzrMQyOnPXG.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPxt==kJheUjmoRbBWAdfDNuTCzrMQyOnPEX:sys.exit()
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Init_TV_Total()
  if os.path.isfile(kJheUjmoRbBWAdfDNuTCzrMQyOnPXw):os.remove(kJheUjmoRbBWAdfDNuTCzrMQyOnPXw)
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPIE =kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Get_Now_Datetime()
  kJheUjmoRbBWAdfDNuTCzrMQyOnPIi=kJheUjmoRbBWAdfDNuTCzrMQyOnPIE+datetime.timedelta(days=30) 
  (kJheUjmoRbBWAdfDNuTCzrMQyOnPxI,kJheUjmoRbBWAdfDNuTCzrMQyOnPxE,kJheUjmoRbBWAdfDNuTCzrMQyOnPxi,kJheUjmoRbBWAdfDNuTCzrMQyOnPxw)=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_account()
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Save_session_acount(kJheUjmoRbBWAdfDNuTCzrMQyOnPxI,kJheUjmoRbBWAdfDNuTCzrMQyOnPxE,kJheUjmoRbBWAdfDNuTCzrMQyOnPxi,kJheUjmoRbBWAdfDNuTCzrMQyOnPxw)
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.TV['account']['token_limit']=kJheUjmoRbBWAdfDNuTCzrMQyOnPIi.strftime('%Y%m%d')
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.JsonFile_Save(kJheUjmoRbBWAdfDNuTCzrMQyOnPXw,kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.TV)
 def cookiefile_check(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.TV=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.JsonFile_Load(kJheUjmoRbBWAdfDNuTCzrMQyOnPXw)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.TV=={}:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Init_TV_Total()
   return kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
  (kJheUjmoRbBWAdfDNuTCzrMQyOnPIw,kJheUjmoRbBWAdfDNuTCzrMQyOnPIt,kJheUjmoRbBWAdfDNuTCzrMQyOnPIK,kJheUjmoRbBWAdfDNuTCzrMQyOnPIS)=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.get_settings_account()
  (kJheUjmoRbBWAdfDNuTCzrMQyOnPIl,kJheUjmoRbBWAdfDNuTCzrMQyOnPIY,kJheUjmoRbBWAdfDNuTCzrMQyOnPIc,kJheUjmoRbBWAdfDNuTCzrMQyOnPIG)=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Load_session_acount()
  if(kJheUjmoRbBWAdfDNuTCzrMQyOnPIw!=kJheUjmoRbBWAdfDNuTCzrMQyOnPIl or kJheUjmoRbBWAdfDNuTCzrMQyOnPIt!=kJheUjmoRbBWAdfDNuTCzrMQyOnPIY or kJheUjmoRbBWAdfDNuTCzrMQyOnPIK!=kJheUjmoRbBWAdfDNuTCzrMQyOnPIc or kJheUjmoRbBWAdfDNuTCzrMQyOnPIS!=kJheUjmoRbBWAdfDNuTCzrMQyOnPIG)and kJheUjmoRbBWAdfDNuTCzrMQyOnPIl!='xxxxx':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Init_TV_Total()
   return kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.TV['account']['token_limit']):
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.Init_TV_Total()
   return kJheUjmoRbBWAdfDNuTCzrMQyOnPEX
  return kJheUjmoRbBWAdfDNuTCzrMQyOnPIp
 def dp_Global_Search(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=kJheUjmoRbBWAdfDNuTCzrMQyOnPxH.get('mode')
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='TOTAL_SEARCH':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIH='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIH='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(kJheUjmoRbBWAdfDNuTCzrMQyOnPIH)
 def dp_Bookmark_Menu(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPIH='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(kJheUjmoRbBWAdfDNuTCzrMQyOnPIH)
 def dp_EuroLive_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK,kJheUjmoRbBWAdfDNuTCzrMQyOnPxH):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPxq=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.GetEuroChannelList()
  for kJheUjmoRbBWAdfDNuTCzrMQyOnPxp in kJheUjmoRbBWAdfDNuTCzrMQyOnPxq:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFc =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('channel')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPaY =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('title')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFt =kJheUjmoRbBWAdfDNuTCzrMQyOnPxp.get('subtitle')
   kJheUjmoRbBWAdfDNuTCzrMQyOnPFw={'mediatype':'episode','title':kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,'plot':'%s\n%s'%(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,kJheUjmoRbBWAdfDNuTCzrMQyOnPFt)}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPxa={'mode':'LIVE','mediacode':kJheUjmoRbBWAdfDNuTCzrMQyOnPFc,'stype':'onair',}
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.add_dir(kJheUjmoRbBWAdfDNuTCzrMQyOnPaY,sublabel=kJheUjmoRbBWAdfDNuTCzrMQyOnPFt,img='',infoLabels=kJheUjmoRbBWAdfDNuTCzrMQyOnPFw,isFolder=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX,params=kJheUjmoRbBWAdfDNuTCzrMQyOnPxa)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPEV(kJheUjmoRbBWAdfDNuTCzrMQyOnPxq)>0:xbmcplugin.endOfDirectory(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK._addon_handle,cacheToDisc=kJheUjmoRbBWAdfDNuTCzrMQyOnPEX)
 def tving_main(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK):
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.TvingObj.KodiVersion=kJheUjmoRbBWAdfDNuTCzrMQyOnPIL(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params.get('mode',kJheUjmoRbBWAdfDNuTCzrMQyOnPIq)
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='LOGOUT':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.logout()
   return
  kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.login_main()
  if kJheUjmoRbBWAdfDNuTCzrMQyOnPsL is kJheUjmoRbBWAdfDNuTCzrMQyOnPIq:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_Main_List()
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_Title_Group(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL in['GLOBAL_GROUP']:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_SubTitle_Group(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='CHANNEL':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_LiveChannel_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL in['LIVE','VOD','MOVIE']:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.play_VIDEO(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='PROGRAM':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_Program_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='4K_PROGRAM':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_4K_Program_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='ORI_PROGRAM':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_Ori_Program_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='EPISODE':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_Episode_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='MOVIE_SUB':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_Movie_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='4K_MOVIE':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_4K_Movie_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='SEARCH_GROUP':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_Search_Group(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL in['SEARCH','LOCAL_SEARCH']:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_Search_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='WATCH':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_Watch_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_History_Remove(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='ORDER_BY':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_setEpOrderby(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='SET_BOOKMARK':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_Set_Bookmark(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL in['TOTAL_SEARCH','TOTAL_HISTORY']:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_Global_Search(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='SEARCH_HISTORY':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_Search_History(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='MENU_BOOKMARK':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_Bookmark_Menu(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  elif kJheUjmoRbBWAdfDNuTCzrMQyOnPsL=='EURO_GROUP':
   kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.dp_EuroLive_List(kJheUjmoRbBWAdfDNuTCzrMQyOnPXK.main_params)
  else:
   kJheUjmoRbBWAdfDNuTCzrMQyOnPIq
# Created by pyminifier (https://github.com/liftoff/pyminifier)
