__author__="NightRain"
ugUNxqatGsKWHeEzwcmijCQlIYXSOJ=print
ugUNxqatGsKWHeEzwcmijCQlIYXSOn=ImportError
ugUNxqatGsKWHeEzwcmijCQlIYXSOk=object
ugUNxqatGsKWHeEzwcmijCQlIYXSOM=None
ugUNxqatGsKWHeEzwcmijCQlIYXSOv=False
ugUNxqatGsKWHeEzwcmijCQlIYXSOF=open
ugUNxqatGsKWHeEzwcmijCQlIYXSOy=True
ugUNxqatGsKWHeEzwcmijCQlIYXSOB=len
ugUNxqatGsKWHeEzwcmijCQlIYXSOA=int
ugUNxqatGsKWHeEzwcmijCQlIYXSOV=range
ugUNxqatGsKWHeEzwcmijCQlIYXSOo=Exception
ugUNxqatGsKWHeEzwcmijCQlIYXSOh=str
ugUNxqatGsKWHeEzwcmijCQlIYXSOL=dict
ugUNxqatGsKWHeEzwcmijCQlIYXSOT=list
ugUNxqatGsKWHeEzwcmijCQlIYXSOr=bytes
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 ugUNxqatGsKWHeEzwcmijCQlIYXSOJ('Cryptodome')
except ugUNxqatGsKWHeEzwcmijCQlIYXSOn:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 ugUNxqatGsKWHeEzwcmijCQlIYXSOJ('Crypto')
ugUNxqatGsKWHeEzwcmijCQlIYXSJk={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
ugUNxqatGsKWHeEzwcmijCQlIYXSJM ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
ugUNxqatGsKWHeEzwcmijCQlIYXSJv =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
ugUNxqatGsKWHeEzwcmijCQlIYXSJF=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class ugUNxqatGsKWHeEzwcmijCQlIYXSJn(ugUNxqatGsKWHeEzwcmijCQlIYXSOk):
 def __init__(ugUNxqatGsKWHeEzwcmijCQlIYXSJy):
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.NETWORKCODE ='CSND0900'
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.OSCODE ='CSOD0900' 
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TELECODE ='CSCD0900'
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.SCREENCODE ='CSSD0100'
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.SCREENCODE_ATV ='CSSD1300' 
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.LIVE_LIMIT =20 
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.VOD_LIMIT =24 
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.EPISODE_LIMIT =30 
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.SEARCH_LIMIT =30 
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.MOVIE_LIMIT =24 
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN ='https://api.tving.com'
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN ='https://image.tving.com'
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.SEARCH_DOMAIN ='https://search-api.tving.com'
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.LOGIN_DOMAIN ='https://user.tving.com'
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.URL_DOMAIN ='https://www.tving.com'
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.MOVIE_LITE =['2610061','2610161','261062']
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.MODEL ='chrome_126.0.0.0' 
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.DEFAULT_HEADER ={'user-agent':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.USER_AGENT}
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.COOKIE_FILE_NAME =''
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV_SESSION_COOKIES1=''
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV_SESSION_COOKIES2=''
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV_STREAM_FILENAME =''
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV_SESSION_TEXT1 =''
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV_SESSION_TEXT2 =''
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.KodiVersion=20
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV ={}
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Init_TV_Total()
 def Init_TV_Total(ugUNxqatGsKWHeEzwcmijCQlIYXSJy):
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV={'account':{},'cookies':{},}
 def callRequestCookies(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,jobtype,ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,redirects=ugUNxqatGsKWHeEzwcmijCQlIYXSOv):
  ugUNxqatGsKWHeEzwcmijCQlIYXSJO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.DEFAULT_HEADER
  if headers:ugUNxqatGsKWHeEzwcmijCQlIYXSJO.update(headers)
  if jobtype=='Get':
   ugUNxqatGsKWHeEzwcmijCQlIYXSJB=requests.get(ugUNxqatGsKWHeEzwcmijCQlIYXSkB,params=params,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSJO,cookies=cookies,allow_redirects=redirects)
  else:
   ugUNxqatGsKWHeEzwcmijCQlIYXSJB=requests.post(ugUNxqatGsKWHeEzwcmijCQlIYXSkB,data=payload,params=params,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSJO,cookies=cookies,allow_redirects=redirects)
  ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(ugUNxqatGsKWHeEzwcmijCQlIYXSJB.url)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSJB
 def JsonFile_Save(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,filename,ugUNxqatGsKWHeEzwcmijCQlIYXSJA):
  if filename=='':return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  try:
   fp=ugUNxqatGsKWHeEzwcmijCQlIYXSOF(filename,'w',-1,'utf-8')
   json.dump(ugUNxqatGsKWHeEzwcmijCQlIYXSJA,fp,indent=4,ensure_ascii=ugUNxqatGsKWHeEzwcmijCQlIYXSOv)
   fp.close()
  except:
   return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  return ugUNxqatGsKWHeEzwcmijCQlIYXSOy
 def JsonFile_Load(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,filename):
  if filename=='':return{}
  try:
   fp=ugUNxqatGsKWHeEzwcmijCQlIYXSOF(filename,'r',-1,'utf-8')
   ugUNxqatGsKWHeEzwcmijCQlIYXSJo=json.load(fp)
   fp.close()
  except:
   return{}
  return ugUNxqatGsKWHeEzwcmijCQlIYXSJo
 def TextFile_Save(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,filename,resText):
  if filename=='':return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  try:
   fp=ugUNxqatGsKWHeEzwcmijCQlIYXSOF(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  return ugUNxqatGsKWHeEzwcmijCQlIYXSOy
 def Save_session_acount(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,ugUNxqatGsKWHeEzwcmijCQlIYXSJh,ugUNxqatGsKWHeEzwcmijCQlIYXSJL,ugUNxqatGsKWHeEzwcmijCQlIYXSJT,ugUNxqatGsKWHeEzwcmijCQlIYXSJr):
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['account']['tvid'] =base64.standard_b64encode(ugUNxqatGsKWHeEzwcmijCQlIYXSJh.encode()).decode('utf-8')
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['account']['tvpw'] =base64.standard_b64encode(ugUNxqatGsKWHeEzwcmijCQlIYXSJL.encode()).decode('utf-8')
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['account']['tvtype']=ugUNxqatGsKWHeEzwcmijCQlIYXSJT 
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['account']['tvpf'] =ugUNxqatGsKWHeEzwcmijCQlIYXSJr 
 def Load_session_acount(ugUNxqatGsKWHeEzwcmijCQlIYXSJy):
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSJh =base64.standard_b64decode(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['account']['tvid']).decode('utf-8')
   ugUNxqatGsKWHeEzwcmijCQlIYXSJL =base64.standard_b64decode(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['account']['tvpw']).decode('utf-8')
   ugUNxqatGsKWHeEzwcmijCQlIYXSJT=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['account']['tvtype']
   ugUNxqatGsKWHeEzwcmijCQlIYXSJr =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return ugUNxqatGsKWHeEzwcmijCQlIYXSJh,ugUNxqatGsKWHeEzwcmijCQlIYXSJL,ugUNxqatGsKWHeEzwcmijCQlIYXSJT,ugUNxqatGsKWHeEzwcmijCQlIYXSJr
 def make_stream_header(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,ugUNxqatGsKWHeEzwcmijCQlIYXSJb,ugUNxqatGsKWHeEzwcmijCQlIYXSJR):
  ugUNxqatGsKWHeEzwcmijCQlIYXSJd=''
  if ugUNxqatGsKWHeEzwcmijCQlIYXSJR not in[{},ugUNxqatGsKWHeEzwcmijCQlIYXSOM,'']:
   ugUNxqatGsKWHeEzwcmijCQlIYXSJP=ugUNxqatGsKWHeEzwcmijCQlIYXSOB(ugUNxqatGsKWHeEzwcmijCQlIYXSJR)
   for ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSJD in ugUNxqatGsKWHeEzwcmijCQlIYXSJR.items():
    ugUNxqatGsKWHeEzwcmijCQlIYXSJd+='{}={}'.format(ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSJD)
    ugUNxqatGsKWHeEzwcmijCQlIYXSJP+=-1
    if ugUNxqatGsKWHeEzwcmijCQlIYXSJP>0:ugUNxqatGsKWHeEzwcmijCQlIYXSJd+='; '
   ugUNxqatGsKWHeEzwcmijCQlIYXSJb['cookie']=ugUNxqatGsKWHeEzwcmijCQlIYXSJd
  ugUNxqatGsKWHeEzwcmijCQlIYXSJf=''
  i=0
  for ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSJD in ugUNxqatGsKWHeEzwcmijCQlIYXSJb.items():
   i=i+1
   if i>1:ugUNxqatGsKWHeEzwcmijCQlIYXSJf+='&'
   ugUNxqatGsKWHeEzwcmijCQlIYXSJf+='{}={}'.format(ugUNxqatGsKWHeEzwcmijCQlIYXSJp,urllib.parse.quote(ugUNxqatGsKWHeEzwcmijCQlIYXSJD))
  return ugUNxqatGsKWHeEzwcmijCQlIYXSJf
 def makeDefaultCookies(ugUNxqatGsKWHeEzwcmijCQlIYXSJy):
  ugUNxqatGsKWHeEzwcmijCQlIYXSJR={}
  for ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSJD in ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies'].items():
   ugUNxqatGsKWHeEzwcmijCQlIYXSJR[ugUNxqatGsKWHeEzwcmijCQlIYXSJp]=ugUNxqatGsKWHeEzwcmijCQlIYXSJD
  return ugUNxqatGsKWHeEzwcmijCQlIYXSJR
 def getDeviceStr(ugUNxqatGsKWHeEzwcmijCQlIYXSJy):
  ugUNxqatGsKWHeEzwcmijCQlIYXSnJ=[]
  ugUNxqatGsKWHeEzwcmijCQlIYXSnJ.append('Windows') 
  ugUNxqatGsKWHeEzwcmijCQlIYXSnJ.append('Chrome') 
  ugUNxqatGsKWHeEzwcmijCQlIYXSnJ.append('ko-KR') 
  ugUNxqatGsKWHeEzwcmijCQlIYXSnJ.append('undefined') 
  ugUNxqatGsKWHeEzwcmijCQlIYXSnJ.append('24') 
  ugUNxqatGsKWHeEzwcmijCQlIYXSnJ.append(u'한국 표준시')
  ugUNxqatGsKWHeEzwcmijCQlIYXSnJ.append('undefined') 
  ugUNxqatGsKWHeEzwcmijCQlIYXSnJ.append('undefined') 
  ugUNxqatGsKWHeEzwcmijCQlIYXSnJ.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  ugUNxqatGsKWHeEzwcmijCQlIYXSnk=''
  for ugUNxqatGsKWHeEzwcmijCQlIYXSnM in ugUNxqatGsKWHeEzwcmijCQlIYXSnJ:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnk+=ugUNxqatGsKWHeEzwcmijCQlIYXSnM+'|'
  return ugUNxqatGsKWHeEzwcmijCQlIYXSnk
 def GetDefaultParams(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,uhd=ugUNxqatGsKWHeEzwcmijCQlIYXSOv):
  if uhd==ugUNxqatGsKWHeEzwcmijCQlIYXSOv:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnv={'apiKey':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.APIKEY,'networkCode':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.NETWORKCODE,'osCode':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.OSCODE,'teleCode':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TELECODE,'screenCode':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.SCREENCODE,}
  else:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnv={'apiKey':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.APIKEY_ATV,'networkCode':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.NETWORKCODE,'osCode':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.OSCODE,'teleCode':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TELECODE,'screenCode':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.SCREENCODE_ATV,}
  return ugUNxqatGsKWHeEzwcmijCQlIYXSnv
 def GetNoCache(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,timetype=1):
  if timetype==1:
   return ugUNxqatGsKWHeEzwcmijCQlIYXSOA(time.time())
  else:
   return ugUNxqatGsKWHeEzwcmijCQlIYXSOA(time.time()*1000)
 def GetUniqueid(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,hValue=ugUNxqatGsKWHeEzwcmijCQlIYXSOM):
  if hValue:
   import hashlib
   ugUNxqatGsKWHeEzwcmijCQlIYXSnF=hashlib.sha1()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnF.update(hValue.encode())
   ugUNxqatGsKWHeEzwcmijCQlIYXSny=ugUNxqatGsKWHeEzwcmijCQlIYXSnF.hexdigest()[:8]
  else:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnO=[0 for i in ugUNxqatGsKWHeEzwcmijCQlIYXSOV(256)]
   for i in ugUNxqatGsKWHeEzwcmijCQlIYXSOV(256):
    ugUNxqatGsKWHeEzwcmijCQlIYXSnO[i]='%02x'%(i)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnB=ugUNxqatGsKWHeEzwcmijCQlIYXSOA(4294967295*random.random())|0
   ugUNxqatGsKWHeEzwcmijCQlIYXSny=ugUNxqatGsKWHeEzwcmijCQlIYXSnO[255&ugUNxqatGsKWHeEzwcmijCQlIYXSnB]+ugUNxqatGsKWHeEzwcmijCQlIYXSnO[ugUNxqatGsKWHeEzwcmijCQlIYXSnB>>8&255]+ugUNxqatGsKWHeEzwcmijCQlIYXSnO[ugUNxqatGsKWHeEzwcmijCQlIYXSnB>>16&255]+ugUNxqatGsKWHeEzwcmijCQlIYXSnO[ugUNxqatGsKWHeEzwcmijCQlIYXSnB>>24&255]
  return ugUNxqatGsKWHeEzwcmijCQlIYXSny
 def GetCredential(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,user_id,user_pw,login_type,user_pf):
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnA=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   ugUNxqatGsKWHeEzwcmijCQlIYXSnV={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Post',ugUNxqatGsKWHeEzwcmijCQlIYXSnA,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSnV,params=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   for ugUNxqatGsKWHeEzwcmijCQlIYXSnh in ugUNxqatGsKWHeEzwcmijCQlIYXSno.cookies:
    ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies'][ugUNxqatGsKWHeEzwcmijCQlIYXSnh.name]=ugUNxqatGsKWHeEzwcmijCQlIYXSnh.value
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
   ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Init_TV_Total()
   return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  ugUNxqatGsKWHeEzwcmijCQlIYXSnL=[]
  ugUNxqatGsKWHeEzwcmijCQlIYXSnT =''
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   ugUNxqatGsKWHeEzwcmijCQlIYXSJR=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.makeDefaultCookies()
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSnr,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSJR)
   for ugUNxqatGsKWHeEzwcmijCQlIYXSnh in ugUNxqatGsKWHeEzwcmijCQlIYXSno.cookies:
    ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies'][ugUNxqatGsKWHeEzwcmijCQlIYXSnh.name]=ugUNxqatGsKWHeEzwcmijCQlIYXSnh.value
   ugUNxqatGsKWHeEzwcmijCQlIYXSnL =re.findall('data-profile-no="\d+"',ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   for i in ugUNxqatGsKWHeEzwcmijCQlIYXSOV(ugUNxqatGsKWHeEzwcmijCQlIYXSOB(ugUNxqatGsKWHeEzwcmijCQlIYXSnL)):
    ugUNxqatGsKWHeEzwcmijCQlIYXSnd =ugUNxqatGsKWHeEzwcmijCQlIYXSnL[i].replace('data-profile-no=','').replace('"','')
    ugUNxqatGsKWHeEzwcmijCQlIYXSnL[i]=ugUNxqatGsKWHeEzwcmijCQlIYXSnd
   ugUNxqatGsKWHeEzwcmijCQlIYXSnT=ugUNxqatGsKWHeEzwcmijCQlIYXSnL[user_pf]
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
   ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Init_TV_Total()
   return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   ugUNxqatGsKWHeEzwcmijCQlIYXSJR=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.makeDefaultCookies()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnV={'profileNo':ugUNxqatGsKWHeEzwcmijCQlIYXSnT}
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Post',ugUNxqatGsKWHeEzwcmijCQlIYXSnr,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSnV,params=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSJR)
   for ugUNxqatGsKWHeEzwcmijCQlIYXSnh in ugUNxqatGsKWHeEzwcmijCQlIYXSno.cookies:
    ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies'][ugUNxqatGsKWHeEzwcmijCQlIYXSnh.name]=ugUNxqatGsKWHeEzwcmijCQlIYXSnh.value
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
   ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Init_TV_Total()
   return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  ugUNxqatGsKWHeEzwcmijCQlIYXSnP =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDeviceList()
  if ugUNxqatGsKWHeEzwcmijCQlIYXSnP not in['','-']:
   ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_uuid']=ugUNxqatGsKWHeEzwcmijCQlIYXSnP+'-'+ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetUniqueid(ugUNxqatGsKWHeEzwcmijCQlIYXSnP)
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.JsonFile_Save(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.COOKIE_FILE_NAME,ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSOy
 def GetCredential_old(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,user_id,user_pw,login_type,user_pf):
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnA=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   ugUNxqatGsKWHeEzwcmijCQlIYXSnV={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Post',ugUNxqatGsKWHeEzwcmijCQlIYXSnA,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSnV,params=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   for ugUNxqatGsKWHeEzwcmijCQlIYXSnh in ugUNxqatGsKWHeEzwcmijCQlIYXSno.cookies:
    if ugUNxqatGsKWHeEzwcmijCQlIYXSnh.name=='_tving_token':
     ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_token']=ugUNxqatGsKWHeEzwcmijCQlIYXSnh.value
    elif ugUNxqatGsKWHeEzwcmijCQlIYXSnh.name=='POC_USERINFO':
     ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_userinfo']=ugUNxqatGsKWHeEzwcmijCQlIYXSnh.value
    elif ugUNxqatGsKWHeEzwcmijCQlIYXSnh.name=='authToken':
     ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_authToken']=ugUNxqatGsKWHeEzwcmijCQlIYXSnh.value
   if not ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_token']:
    ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Init_TV_Total()
    return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
   ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_maintoken']=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_token']
   if ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetProfileToken(user_pf)==ugUNxqatGsKWHeEzwcmijCQlIYXSOv:
    ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Init_TV_Total()
    return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies'])
   ugUNxqatGsKWHeEzwcmijCQlIYXSnP =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDeviceList()
   if ugUNxqatGsKWHeEzwcmijCQlIYXSnP not in['','-']:
    ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_uuid']=ugUNxqatGsKWHeEzwcmijCQlIYXSnP+'-'+ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetUniqueid(ugUNxqatGsKWHeEzwcmijCQlIYXSnP)
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
   ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Init_TV_Total()
   return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  return ugUNxqatGsKWHeEzwcmijCQlIYXSOy
 def GetProfileToken(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,user_pf):
  ugUNxqatGsKWHeEzwcmijCQlIYXSnL=[]
  ugUNxqatGsKWHeEzwcmijCQlIYXSnT =''
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   ugUNxqatGsKWHeEzwcmijCQlIYXSJR=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.makeDefaultCookies()
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSnr,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSJR)
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnL =re.findall('data-profile-no="\d+"',ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(ugUNxqatGsKWHeEzwcmijCQlIYXSnL)
   for i in ugUNxqatGsKWHeEzwcmijCQlIYXSOV(ugUNxqatGsKWHeEzwcmijCQlIYXSOB(ugUNxqatGsKWHeEzwcmijCQlIYXSnL)):
    ugUNxqatGsKWHeEzwcmijCQlIYXSnd =ugUNxqatGsKWHeEzwcmijCQlIYXSnL[i].replace('data-profile-no=','').replace('"','')
    ugUNxqatGsKWHeEzwcmijCQlIYXSnL[i]=ugUNxqatGsKWHeEzwcmijCQlIYXSnd
   ugUNxqatGsKWHeEzwcmijCQlIYXSnT=ugUNxqatGsKWHeEzwcmijCQlIYXSnL[user_pf]
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
   ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Init_TV_Total()
   return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   ugUNxqatGsKWHeEzwcmijCQlIYXSJR=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.makeDefaultCookies()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnV={'profileNo':ugUNxqatGsKWHeEzwcmijCQlIYXSnT}
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Post',ugUNxqatGsKWHeEzwcmijCQlIYXSnr,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSnV,params=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSJR)
   for ugUNxqatGsKWHeEzwcmijCQlIYXSnh in ugUNxqatGsKWHeEzwcmijCQlIYXSno.cookies:
    if ugUNxqatGsKWHeEzwcmijCQlIYXSnh.name=='_tving_token':
     ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_token']=ugUNxqatGsKWHeEzwcmijCQlIYXSnh.value
    elif ugUNxqatGsKWHeEzwcmijCQlIYXSnh.name==ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GLOBAL_COOKIENM['tv_cookiekey']:
     ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_cookiekey']=ugUNxqatGsKWHeEzwcmijCQlIYXSnh.value
    elif ugUNxqatGsKWHeEzwcmijCQlIYXSnh.name==ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GLOBAL_COOKIENM['tv_lockkey']:
     ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_lockkey']=ugUNxqatGsKWHeEzwcmijCQlIYXSnh.value
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
   ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Init_TV_Total()
   return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  return ugUNxqatGsKWHeEzwcmijCQlIYXSOy
 def GetDeviceList(ugUNxqatGsKWHeEzwcmijCQlIYXSJy):
  ugUNxqatGsKWHeEzwcmijCQlIYXSnp=[]
  ugUNxqatGsKWHeEzwcmijCQlIYXSnD='-'
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v1/user/device/list'
   ugUNxqatGsKWHeEzwcmijCQlIYXSnb=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
   ugUNxqatGsKWHeEzwcmijCQlIYXSJR=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.makeDefaultCookies()
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSnb,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSnf,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSJR)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnp=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']
   for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSnp:
    if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['model'].lower().startswith('pc'):
     ugUNxqatGsKWHeEzwcmijCQlIYXSnD=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['uuid']
     break
   if ugUNxqatGsKWHeEzwcmijCQlIYXSnD=='-':
    ugUNxqatGsKWHeEzwcmijCQlIYXSnD=ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetNoCache(timetype=1))
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSnD
 def Get_Now_Datetime(ugUNxqatGsKWHeEzwcmijCQlIYXSJy):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,mediacode,sel_quality,stype,pvrmode='-',optUHD=ugUNxqatGsKWHeEzwcmijCQlIYXSOv):
  ugUNxqatGsKWHeEzwcmijCQlIYXSkM ={'streaming_url':'','subtitleYn':ugUNxqatGsKWHeEzwcmijCQlIYXSOv,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  ugUNxqatGsKWHeEzwcmijCQlIYXSnD =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_uuid'].split('-')[0] 
  ugUNxqatGsKWHeEzwcmijCQlIYXSkv =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_uuid'] 
  ugUNxqatGsKWHeEzwcmijCQlIYXSkF=ugUNxqatGsKWHeEzwcmijCQlIYXSOv 
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSky=ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetNoCache(1))
   if stype!='tvingtv':
    ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v2/media/stream/info'
    ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
    ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':ugUNxqatGsKWHeEzwcmijCQlIYXSkv,'deviceInfo':'PC','noCache':ugUNxqatGsKWHeEzwcmijCQlIYXSky,}
    ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
    ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
    ugUNxqatGsKWHeEzwcmijCQlIYXSJR=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.makeDefaultCookies()
    ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSJR)
    if ugUNxqatGsKWHeEzwcmijCQlIYXSno.status_code!=200:
     ugUNxqatGsKWHeEzwcmijCQlIYXSkM['error_msg']='First Step - {} error'.format(ugUNxqatGsKWHeEzwcmijCQlIYXSno.status_code)
     return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
    ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
    if ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']['code']=='060':
     for ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSJD in ugUNxqatGsKWHeEzwcmijCQlIYXSJk.items():
      if ugUNxqatGsKWHeEzwcmijCQlIYXSJD==sel_quality:
       ugUNxqatGsKWHeEzwcmijCQlIYXSkA=ugUNxqatGsKWHeEzwcmijCQlIYXSJp
    elif ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']['code']!='000':
     ugUNxqatGsKWHeEzwcmijCQlIYXSkM['error_msg']=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']['message']
     return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
    else: 
     if not('stream' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']):return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
     ugUNxqatGsKWHeEzwcmijCQlIYXSkV=[]
     for ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSJD in ugUNxqatGsKWHeEzwcmijCQlIYXSJk.items():
      for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['stream']['quality']:
       if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['active']=='Y' and ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['code']==ugUNxqatGsKWHeEzwcmijCQlIYXSJp:
        ugUNxqatGsKWHeEzwcmijCQlIYXSkV.append({ugUNxqatGsKWHeEzwcmijCQlIYXSJk.get(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['code']):ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['code']})
     ugUNxqatGsKWHeEzwcmijCQlIYXSkA=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.CheckQuality(sel_quality,ugUNxqatGsKWHeEzwcmijCQlIYXSkV)
     try:
      if optUHD==ugUNxqatGsKWHeEzwcmijCQlIYXSOy and ugUNxqatGsKWHeEzwcmijCQlIYXSkA=='stream50' and 'stream_support_info' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['content']['info']:
       if ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['content']['info']['stream_support_info']!=ugUNxqatGsKWHeEzwcmijCQlIYXSOM:
        if 'stream70' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['content']['info']['stream_support_info']:
         ugUNxqatGsKWHeEzwcmijCQlIYXSkA='stream70'
         ugUNxqatGsKWHeEzwcmijCQlIYXSkF =ugUNxqatGsKWHeEzwcmijCQlIYXSOy
     except:
      pass
     try:
      if optUHD==ugUNxqatGsKWHeEzwcmijCQlIYXSOy and ugUNxqatGsKWHeEzwcmijCQlIYXSkA=='stream50' and 'stream' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['content']['info']:
       if ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['content']['info']['stream']!=ugUNxqatGsKWHeEzwcmijCQlIYXSOM:
        for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['content']['info']['stream']:
         if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['code']=='stream70':
          ugUNxqatGsKWHeEzwcmijCQlIYXSkA='stream70'
          ugUNxqatGsKWHeEzwcmijCQlIYXSkF =ugUNxqatGsKWHeEzwcmijCQlIYXSOy
          break
     except:
      pass
   else:
    ugUNxqatGsKWHeEzwcmijCQlIYXSkA='stream40'
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkM['error_msg']='First Step - except error'
   return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
  ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(ugUNxqatGsKWHeEzwcmijCQlIYXSkA)
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSky=ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetNoCache(1))
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v3/media/stream/info'
   if ugUNxqatGsKWHeEzwcmijCQlIYXSkF==ugUNxqatGsKWHeEzwcmijCQlIYXSOy:
    ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams(uhd=ugUNxqatGsKWHeEzwcmijCQlIYXSOy)
    ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'mediaCode':mediacode,'deviceId':ugUNxqatGsKWHeEzwcmijCQlIYXSnD,'uuid':ugUNxqatGsKWHeEzwcmijCQlIYXSkv,'deviceInfo':'PC_Chrome WebView','streamCode':ugUNxqatGsKWHeEzwcmijCQlIYXSkA,'noCache':ugUNxqatGsKWHeEzwcmijCQlIYXSky,'callingFrom':'HTML5','model':'chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   else:
    ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
    ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'mediaCode':mediacode,'deviceId':ugUNxqatGsKWHeEzwcmijCQlIYXSnD,'uuid':ugUNxqatGsKWHeEzwcmijCQlIYXSkv,'deviceInfo':'PC_Chrome','streamCode':ugUNxqatGsKWHeEzwcmijCQlIYXSkA,'noCache':ugUNxqatGsKWHeEzwcmijCQlIYXSky,'callingFrom':'HTML5','model':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSJR=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.makeDefaultCookies()
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Post',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSJR,redirects=ugUNxqatGsKWHeEzwcmijCQlIYXSOy)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']['code']!='000':
    ugUNxqatGsKWHeEzwcmijCQlIYXSkM['error_msg']=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']['message']
    return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
   ugUNxqatGsKWHeEzwcmijCQlIYXSko=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['stream']
   if ugUNxqatGsKWHeEzwcmijCQlIYXSko['drm_yn']=='Y':
    ugUNxqatGsKWHeEzwcmijCQlIYXSkh=ugUNxqatGsKWHeEzwcmijCQlIYXSko['playback']['drm']['widevine']
    for ugUNxqatGsKWHeEzwcmijCQlIYXSkL in ugUNxqatGsKWHeEzwcmijCQlIYXSko['playback']['drm']['license']['drm_license_data']:
     if ugUNxqatGsKWHeEzwcmijCQlIYXSkL['drm_type']=='Widevine':
      ugUNxqatGsKWHeEzwcmijCQlIYXSkM['drm_server_url'] =ugUNxqatGsKWHeEzwcmijCQlIYXSkL['drm_server_url']
      ugUNxqatGsKWHeEzwcmijCQlIYXSkM['drm_header_key'] =ugUNxqatGsKWHeEzwcmijCQlIYXSkL['drm_header_key']
      ugUNxqatGsKWHeEzwcmijCQlIYXSkM['drm_header_value']=ugUNxqatGsKWHeEzwcmijCQlIYXSkL['drm_header_value']
      break
   else:
    ugUNxqatGsKWHeEzwcmijCQlIYXSkh=ugUNxqatGsKWHeEzwcmijCQlIYXSko['playback']['non_drm']
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkM['error_msg']='Second Step - except error'
   return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
  ugUNxqatGsKWHeEzwcmijCQlIYXSkT=ugUNxqatGsKWHeEzwcmijCQlIYXSky
  ugUNxqatGsKWHeEzwcmijCQlIYXSkh=ugUNxqatGsKWHeEzwcmijCQlIYXSkh.split('|')[1]
  ugUNxqatGsKWHeEzwcmijCQlIYXSkh=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Decrypt_Url(ugUNxqatGsKWHeEzwcmijCQlIYXSkh,mediacode,ugUNxqatGsKWHeEzwcmijCQlIYXSkT)
  ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url']=ugUNxqatGsKWHeEzwcmijCQlIYXSkh
  if 'subtitles' in ugUNxqatGsKWHeEzwcmijCQlIYXSko:
   for ugUNxqatGsKWHeEzwcmijCQlIYXSkr in ugUNxqatGsKWHeEzwcmijCQlIYXSko.get('subtitles'):
    if ugUNxqatGsKWHeEzwcmijCQlIYXSkr.get('code')in['KO','KO_CC']:
     ugUNxqatGsKWHeEzwcmijCQlIYXSkM['subtitleYn']=ugUNxqatGsKWHeEzwcmijCQlIYXSOy
     break
  ugUNxqatGsKWHeEzwcmijCQlIYXSkd=urllib.parse.urlparse(ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url'])
  ugUNxqatGsKWHeEzwcmijCQlIYXSkP =ugUNxqatGsKWHeEzwcmijCQlIYXSkd.path.strip('/').split('/')
  ugUNxqatGsKWHeEzwcmijCQlIYXSkM['url_filename']=ugUNxqatGsKWHeEzwcmijCQlIYXSkP[ugUNxqatGsKWHeEzwcmijCQlIYXSOB(ugUNxqatGsKWHeEzwcmijCQlIYXSkP)-1]
  return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
 def Tving_Parse_mpd(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,stream_url):
  ugUNxqatGsKWHeEzwcmijCQlIYXSno=requests.get(url=stream_url)
  ugUNxqatGsKWHeEzwcmijCQlIYXSkp=ugUNxqatGsKWHeEzwcmijCQlIYXSno.content.decode('utf-8')
  ugUNxqatGsKWHeEzwcmijCQlIYXSkD=0
  ugUNxqatGsKWHeEzwcmijCQlIYXSkb =ET.ElementTree(ET.fromstring(ugUNxqatGsKWHeEzwcmijCQlIYXSkp))
  ugUNxqatGsKWHeEzwcmijCQlIYXSkf =ugUNxqatGsKWHeEzwcmijCQlIYXSkb.getroot()
  ugUNxqatGsKWHeEzwcmijCQlIYXSkR=re.match(r'\{.*\}',ugUNxqatGsKWHeEzwcmijCQlIYXSkf.tag)[0] 
  ugUNxqatGsKWHeEzwcmijCQlIYXSMJ=ugUNxqatGsKWHeEzwcmijCQlIYXSOL([node for _,node in ET.iterparse(io.StringIO(ugUNxqatGsKWHeEzwcmijCQlIYXSkp),events=['start-ns'])])
  for ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSMP in ugUNxqatGsKWHeEzwcmijCQlIYXSMJ.items():
   if ugUNxqatGsKWHeEzwcmijCQlIYXSJp!='ns2':
    ET.register_namespace(ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSMP)
  ugUNxqatGsKWHeEzwcmijCQlIYXSMn=ugUNxqatGsKWHeEzwcmijCQlIYXSkf.find(ugUNxqatGsKWHeEzwcmijCQlIYXSkR+'Period')
  for ugUNxqatGsKWHeEzwcmijCQlIYXSMk in ugUNxqatGsKWHeEzwcmijCQlIYXSMn.findall(ugUNxqatGsKWHeEzwcmijCQlIYXSkR+'AdaptationSet'):
   if ugUNxqatGsKWHeEzwcmijCQlIYXSMk.attrib.get('mimeType')=='video/mp4':
    for ugUNxqatGsKWHeEzwcmijCQlIYXSMv in ugUNxqatGsKWHeEzwcmijCQlIYXSMk.findall(ugUNxqatGsKWHeEzwcmijCQlIYXSkR+'Representation'):
     ugUNxqatGsKWHeEzwcmijCQlIYXSMF=ugUNxqatGsKWHeEzwcmijCQlIYXSOA(ugUNxqatGsKWHeEzwcmijCQlIYXSMv.attrib.get('bandwidth'))
     if ugUNxqatGsKWHeEzwcmijCQlIYXSkD<ugUNxqatGsKWHeEzwcmijCQlIYXSMF:ugUNxqatGsKWHeEzwcmijCQlIYXSkD=ugUNxqatGsKWHeEzwcmijCQlIYXSMF
    for ugUNxqatGsKWHeEzwcmijCQlIYXSMv in ugUNxqatGsKWHeEzwcmijCQlIYXSMk.findall(ugUNxqatGsKWHeEzwcmijCQlIYXSkR+'Representation'):
     if ugUNxqatGsKWHeEzwcmijCQlIYXSkD>ugUNxqatGsKWHeEzwcmijCQlIYXSOA(ugUNxqatGsKWHeEzwcmijCQlIYXSMv.attrib.get('bandwidth')):
      ugUNxqatGsKWHeEzwcmijCQlIYXSMk.remove(ugUNxqatGsKWHeEzwcmijCQlIYXSMv)
   else:
    continue
  ugUNxqatGsKWHeEzwcmijCQlIYXSMy=ET.tostring(ugUNxqatGsKWHeEzwcmijCQlIYXSkf).decode('utf-8')
  ugUNxqatGsKWHeEzwcmijCQlIYXSMO='<?xml version="1.0" encoding="UTF-8"?>\n'
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TextFile_Save(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV_STREAM_FILENAME,ugUNxqatGsKWHeEzwcmijCQlIYXSMO+ugUNxqatGsKWHeEzwcmijCQlIYXSMy)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSOy
 def Tving_Parse_m3u8(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,stream_url):
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=requests.get(url=stream_url,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,stream=ugUNxqatGsKWHeEzwcmijCQlIYXSOy)
   ugUNxqatGsKWHeEzwcmijCQlIYXSMB=ugUNxqatGsKWHeEzwcmijCQlIYXSno.content.decode('utf-8')
   if '#EXTM3U' not in ugUNxqatGsKWHeEzwcmijCQlIYXSMB:
    return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
   if '#EXT-X-STREAM-INF' not in ugUNxqatGsKWHeEzwcmijCQlIYXSMB: 
    return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
   ugUNxqatGsKWHeEzwcmijCQlIYXSMA=0
   for ugUNxqatGsKWHeEzwcmijCQlIYXSMV in ugUNxqatGsKWHeEzwcmijCQlIYXSMB.splitlines():
    if ugUNxqatGsKWHeEzwcmijCQlIYXSMV.startswith('#EXT-X-STREAM-INF'):
     ugUNxqatGsKWHeEzwcmijCQlIYXSMo=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.MediaLine_Parse(ugUNxqatGsKWHeEzwcmijCQlIYXSMV,'#EXT-X-STREAM-INF')
     if ugUNxqatGsKWHeEzwcmijCQlIYXSMA<ugUNxqatGsKWHeEzwcmijCQlIYXSOA(ugUNxqatGsKWHeEzwcmijCQlIYXSMo.get('BANDWIDTH')):
      ugUNxqatGsKWHeEzwcmijCQlIYXSMA=ugUNxqatGsKWHeEzwcmijCQlIYXSOA(ugUNxqatGsKWHeEzwcmijCQlIYXSMo.get('BANDWIDTH'))
   ugUNxqatGsKWHeEzwcmijCQlIYXSMh=[]
   ugUNxqatGsKWHeEzwcmijCQlIYXSML=ugUNxqatGsKWHeEzwcmijCQlIYXSOv
   for ugUNxqatGsKWHeEzwcmijCQlIYXSMV in ugUNxqatGsKWHeEzwcmijCQlIYXSMB.splitlines():
    if ugUNxqatGsKWHeEzwcmijCQlIYXSML==ugUNxqatGsKWHeEzwcmijCQlIYXSOy:
     ugUNxqatGsKWHeEzwcmijCQlIYXSML=ugUNxqatGsKWHeEzwcmijCQlIYXSOv
     continue
    if ugUNxqatGsKWHeEzwcmijCQlIYXSMV.startswith('#EXT-X-STREAM-INF'):
     ugUNxqatGsKWHeEzwcmijCQlIYXSMo=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.MediaLine_Parse(ugUNxqatGsKWHeEzwcmijCQlIYXSMV,'#EXT-X-STREAM-INF')
     if ugUNxqatGsKWHeEzwcmijCQlIYXSMA!=ugUNxqatGsKWHeEzwcmijCQlIYXSOA(ugUNxqatGsKWHeEzwcmijCQlIYXSMo.get('BANDWIDTH')):
      ugUNxqatGsKWHeEzwcmijCQlIYXSML=ugUNxqatGsKWHeEzwcmijCQlIYXSOy
      continue
    ugUNxqatGsKWHeEzwcmijCQlIYXSMh.append(ugUNxqatGsKWHeEzwcmijCQlIYXSMV)
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
   return ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  ugUNxqatGsKWHeEzwcmijCQlIYXSMT='\n'.join(ugUNxqatGsKWHeEzwcmijCQlIYXSMh)
  ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TextFile_Save(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV_STREAM_FILENAME,ugUNxqatGsKWHeEzwcmijCQlIYXSMT)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSOy
 def MediaLine_Parse(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,ugUNxqatGsKWHeEzwcmijCQlIYXSMV,prefix):
  ugUNxqatGsKWHeEzwcmijCQlIYXSMo={}
  for ugUNxqatGsKWHeEzwcmijCQlIYXSMr in ugUNxqatGsKWHeEzwcmijCQlIYXSJv.split(ugUNxqatGsKWHeEzwcmijCQlIYXSMV.replace(prefix+':',''))[1::2]:
   ugUNxqatGsKWHeEzwcmijCQlIYXSMd,ugUNxqatGsKWHeEzwcmijCQlIYXSMP=ugUNxqatGsKWHeEzwcmijCQlIYXSMr.split('=',1)
   ugUNxqatGsKWHeEzwcmijCQlIYXSMo[ugUNxqatGsKWHeEzwcmijCQlIYXSMd.upper()]=ugUNxqatGsKWHeEzwcmijCQlIYXSMP.replace('"','').strip()
  return ugUNxqatGsKWHeEzwcmijCQlIYXSMo
 def CheckQuality(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,sel_qt,ugUNxqatGsKWHeEzwcmijCQlIYXSkV):
  for ugUNxqatGsKWHeEzwcmijCQlIYXSMp in ugUNxqatGsKWHeEzwcmijCQlIYXSkV:
   if sel_qt>=ugUNxqatGsKWHeEzwcmijCQlIYXSOT(ugUNxqatGsKWHeEzwcmijCQlIYXSMp)[0]:return ugUNxqatGsKWHeEzwcmijCQlIYXSMp.get(ugUNxqatGsKWHeEzwcmijCQlIYXSOT(ugUNxqatGsKWHeEzwcmijCQlIYXSMp)[0])
   ugUNxqatGsKWHeEzwcmijCQlIYXSMD=ugUNxqatGsKWHeEzwcmijCQlIYXSMp.get(ugUNxqatGsKWHeEzwcmijCQlIYXSOT(ugUNxqatGsKWHeEzwcmijCQlIYXSMp)[0])
  return ugUNxqatGsKWHeEzwcmijCQlIYXSMD
 def makeOocUrl(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,ooc_params):
  ugUNxqatGsKWHeEzwcmijCQlIYXSkB=''
  for ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSJD in ooc_params.items():
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB+="%s=%s^"%(ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSJD)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSkB
 def GetLiveChannelList(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,stype,page_int):
  ugUNxqatGsKWHeEzwcmijCQlIYXSnp=[]
  ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v2/media/lives'
   if stype=='onair': 
    ugUNxqatGsKWHeEzwcmijCQlIYXSMf='CPCS0100,CPCS0400'
   else:
    ugUNxqatGsKWHeEzwcmijCQlIYXSMf='CPCS0300'
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'cacheType':'main','pageNo':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(page_int),'pageSize':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':ugUNxqatGsKWHeEzwcmijCQlIYXSMf,}
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if not('result' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']):return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
   ugUNxqatGsKWHeEzwcmijCQlIYXSMR=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']
   for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSMR:
    ugUNxqatGsKWHeEzwcmijCQlIYXSvJ=ugUNxqatGsKWHeEzwcmijCQlIYXSvM=ugUNxqatGsKWHeEzwcmijCQlIYXSvF=''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvn=ugUNxqatGsKWHeEzwcmijCQlIYXSvR=''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvk=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['live_code']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvJ =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['channel']['name']['ko']
    if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['episode']!=ugUNxqatGsKWHeEzwcmijCQlIYXSOM:
     ugUNxqatGsKWHeEzwcmijCQlIYXSvM =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['program']['name']['ko']
     ugUNxqatGsKWHeEzwcmijCQlIYXSvM =ugUNxqatGsKWHeEzwcmijCQlIYXSvM+', '+ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['episode']['frequency'])+'회'
     ugUNxqatGsKWHeEzwcmijCQlIYXSvF=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['episode']['synopsis']['ko']
    else:
     ugUNxqatGsKWHeEzwcmijCQlIYXSvM =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['program']['name']['ko']
     ugUNxqatGsKWHeEzwcmijCQlIYXSvF=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['program']['synopsis']['ko']
    try: 
     ugUNxqatGsKWHeEzwcmijCQlIYXSvy =''
     ugUNxqatGsKWHeEzwcmijCQlIYXSvO =''
     ugUNxqatGsKWHeEzwcmijCQlIYXSvB=''
     ugUNxqatGsKWHeEzwcmijCQlIYXSvA =''
     ugUNxqatGsKWHeEzwcmijCQlIYXSvV =''
     ugUNxqatGsKWHeEzwcmijCQlIYXSvo =''
     for ugUNxqatGsKWHeEzwcmijCQlIYXSvh in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['program']['image']:
      if ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP0900':ugUNxqatGsKWHeEzwcmijCQlIYXSvO =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
      elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP1800':ugUNxqatGsKWHeEzwcmijCQlIYXSvB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
      elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP2000':ugUNxqatGsKWHeEzwcmijCQlIYXSvA =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
      elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP1900':ugUNxqatGsKWHeEzwcmijCQlIYXSvV =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
      elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP0200':ugUNxqatGsKWHeEzwcmijCQlIYXSvo =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
      elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP0500':ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
      elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP0800':ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     if ugUNxqatGsKWHeEzwcmijCQlIYXSvy=='':
      for ugUNxqatGsKWHeEzwcmijCQlIYXSvh in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['channel']['image']:
       if ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIC0400':ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
       elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIC1400':ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
       elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIC1900':ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
    except:
     ugUNxqatGsKWHeEzwcmijCQlIYXSOM
    try:
     ugUNxqatGsKWHeEzwcmijCQlIYXSvL =[]
     ugUNxqatGsKWHeEzwcmijCQlIYXSvT=[]
     ugUNxqatGsKWHeEzwcmijCQlIYXSvr =[]
     ugUNxqatGsKWHeEzwcmijCQlIYXSvd=''
     ugUNxqatGsKWHeEzwcmijCQlIYXSvP=''
     ugUNxqatGsKWHeEzwcmijCQlIYXSvp=''
     for ugUNxqatGsKWHeEzwcmijCQlIYXSvD in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('schedule').get('program').get('actor'):
      if ugUNxqatGsKWHeEzwcmijCQlIYXSvD!='' and ugUNxqatGsKWHeEzwcmijCQlIYXSvD!=u'없음':ugUNxqatGsKWHeEzwcmijCQlIYXSvL.append(ugUNxqatGsKWHeEzwcmijCQlIYXSvD)
     for ugUNxqatGsKWHeEzwcmijCQlIYXSvb in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('schedule').get('program').get('director'):
      if ugUNxqatGsKWHeEzwcmijCQlIYXSvb!='' and ugUNxqatGsKWHeEzwcmijCQlIYXSvb!='-' and ugUNxqatGsKWHeEzwcmijCQlIYXSvb!=u'없음':ugUNxqatGsKWHeEzwcmijCQlIYXSvT.append(ugUNxqatGsKWHeEzwcmijCQlIYXSvb)
     if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('schedule').get('program').get('category1_name').get('ko')!='':
      ugUNxqatGsKWHeEzwcmijCQlIYXSvr.append(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['program']['category1_name']['ko'])
     if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('schedule').get('program').get('category2_name').get('ko')!='':
      ugUNxqatGsKWHeEzwcmijCQlIYXSvr.append(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['program']['category2_name']['ko'])
     if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('schedule').get('program').get('product_year'):ugUNxqatGsKWHeEzwcmijCQlIYXSvd=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['program']['product_year']
     if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('schedule').get('program').get('grade_code') :ugUNxqatGsKWHeEzwcmijCQlIYXSvP= ugUNxqatGsKWHeEzwcmijCQlIYXSJM.get(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['program']['grade_code'])
     if 'broad_dt' in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('schedule').get('program'):
      ugUNxqatGsKWHeEzwcmijCQlIYXSvf =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('schedule').get('program').get('broad_dt')
      ugUNxqatGsKWHeEzwcmijCQlIYXSvp='%s-%s-%s'%(ugUNxqatGsKWHeEzwcmijCQlIYXSvf[:4],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[4:6],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[6:])
    except:
     ugUNxqatGsKWHeEzwcmijCQlIYXSOM
    ugUNxqatGsKWHeEzwcmijCQlIYXSvn=ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['broadcast_start_time'])[8:12]
    ugUNxqatGsKWHeEzwcmijCQlIYXSvR =ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['schedule']['broadcast_end_time'])[8:12]
    ugUNxqatGsKWHeEzwcmijCQlIYXSFJ={'channel':ugUNxqatGsKWHeEzwcmijCQlIYXSvJ,'title':ugUNxqatGsKWHeEzwcmijCQlIYXSvM,'mediacode':ugUNxqatGsKWHeEzwcmijCQlIYXSvk,'thumbnail':{'poster':ugUNxqatGsKWHeEzwcmijCQlIYXSvO,'thumb':ugUNxqatGsKWHeEzwcmijCQlIYXSvy,'clearlogo':ugUNxqatGsKWHeEzwcmijCQlIYXSvB,'icon':ugUNxqatGsKWHeEzwcmijCQlIYXSvA,'fanart':ugUNxqatGsKWHeEzwcmijCQlIYXSvo},'synopsis':ugUNxqatGsKWHeEzwcmijCQlIYXSvF,'channelepg':' [%s:%s ~ %s:%s]'%(ugUNxqatGsKWHeEzwcmijCQlIYXSvn[0:2],ugUNxqatGsKWHeEzwcmijCQlIYXSvn[2:],ugUNxqatGsKWHeEzwcmijCQlIYXSvR[0:2],ugUNxqatGsKWHeEzwcmijCQlIYXSvR[2:]),'cast':ugUNxqatGsKWHeEzwcmijCQlIYXSvL,'director':ugUNxqatGsKWHeEzwcmijCQlIYXSvT,'info_genre':ugUNxqatGsKWHeEzwcmijCQlIYXSvr,'year':ugUNxqatGsKWHeEzwcmijCQlIYXSvd,'mpaa':ugUNxqatGsKWHeEzwcmijCQlIYXSvP,'premiered':ugUNxqatGsKWHeEzwcmijCQlIYXSvp}
    ugUNxqatGsKWHeEzwcmijCQlIYXSnp.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFJ)
   if ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['has_more']=='Y':
    ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOy
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
 def GetProgramList(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,genre,orderby,page_int,genreCode='all'):
  ugUNxqatGsKWHeEzwcmijCQlIYXSnp=[]
  ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  try:
   if genre=='PARAMOUNT':
    ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v2/media/paramount/episodes'
   else:
    ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v2/media/episodes'
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'cacheType':'main','pageSize':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(page_int),}
   if genre not in['all','PARAMOUNT']:ugUNxqatGsKWHeEzwcmijCQlIYXSnf['categoryCode']=genre
   if genreCode!='all' :ugUNxqatGsKWHeEzwcmijCQlIYXSnf['genreCode'] =genreCode 
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if not('result' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']):return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
   ugUNxqatGsKWHeEzwcmijCQlIYXSMR=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']
   for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSMR:
    ugUNxqatGsKWHeEzwcmijCQlIYXSFn=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['program']['code']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvM =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['program']['name']['ko']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvP =ugUNxqatGsKWHeEzwcmijCQlIYXSJM.get(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['program'].get('grade_code'))
    ugUNxqatGsKWHeEzwcmijCQlIYXSvO =''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvy =''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvB=''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvA =''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvV =''
    for ugUNxqatGsKWHeEzwcmijCQlIYXSvh in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['program']['image']:
     if ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP0900':ugUNxqatGsKWHeEzwcmijCQlIYXSvO =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP0200':ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP1800':ugUNxqatGsKWHeEzwcmijCQlIYXSvB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP2000':ugUNxqatGsKWHeEzwcmijCQlIYXSvA =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP1900':ugUNxqatGsKWHeEzwcmijCQlIYXSvV =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvF =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['program']['synopsis']['ko']
    try:
     ugUNxqatGsKWHeEzwcmijCQlIYXSFk=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['channel']['name']['ko']
    except:
     ugUNxqatGsKWHeEzwcmijCQlIYXSFk=''
    try:
     ugUNxqatGsKWHeEzwcmijCQlIYXSvL =[]
     ugUNxqatGsKWHeEzwcmijCQlIYXSvT=[]
     ugUNxqatGsKWHeEzwcmijCQlIYXSvr =[]
     ugUNxqatGsKWHeEzwcmijCQlIYXSvd =''
     ugUNxqatGsKWHeEzwcmijCQlIYXSvp=''
     for ugUNxqatGsKWHeEzwcmijCQlIYXSvD in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('program').get('actor'):
      if ugUNxqatGsKWHeEzwcmijCQlIYXSvD!='' and ugUNxqatGsKWHeEzwcmijCQlIYXSvD!='-' and ugUNxqatGsKWHeEzwcmijCQlIYXSvD!=u'없음':ugUNxqatGsKWHeEzwcmijCQlIYXSvL.append(ugUNxqatGsKWHeEzwcmijCQlIYXSvD)
     for ugUNxqatGsKWHeEzwcmijCQlIYXSvb in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('program').get('director'):
      if ugUNxqatGsKWHeEzwcmijCQlIYXSvb!='' and ugUNxqatGsKWHeEzwcmijCQlIYXSvb!='-' and ugUNxqatGsKWHeEzwcmijCQlIYXSvb!=u'없음':ugUNxqatGsKWHeEzwcmijCQlIYXSvT.append(ugUNxqatGsKWHeEzwcmijCQlIYXSvb)
     if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('program').get('category1_name').get('ko')!='':
      ugUNxqatGsKWHeEzwcmijCQlIYXSvr.append(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['program']['category1_name']['ko'])
     if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('program').get('category2_name').get('ko')!='':
      ugUNxqatGsKWHeEzwcmijCQlIYXSvr.append(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['program']['category2_name']['ko'])
     if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('program').get('product_year'):ugUNxqatGsKWHeEzwcmijCQlIYXSvd=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['program']['product_year']
     if 'broad_dt' in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('program'):
      ugUNxqatGsKWHeEzwcmijCQlIYXSvf =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('program').get('broad_dt')
      ugUNxqatGsKWHeEzwcmijCQlIYXSvp='%s-%s-%s'%(ugUNxqatGsKWHeEzwcmijCQlIYXSvf[:4],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[4:6],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[6:])
    except:
     ugUNxqatGsKWHeEzwcmijCQlIYXSOM
    ugUNxqatGsKWHeEzwcmijCQlIYXSFJ={'program':ugUNxqatGsKWHeEzwcmijCQlIYXSFn,'title':ugUNxqatGsKWHeEzwcmijCQlIYXSvM,'thumbnail':{'poster':ugUNxqatGsKWHeEzwcmijCQlIYXSvO,'thumb':ugUNxqatGsKWHeEzwcmijCQlIYXSvy,'clearlogo':ugUNxqatGsKWHeEzwcmijCQlIYXSvB,'icon':ugUNxqatGsKWHeEzwcmijCQlIYXSvA,'banner':ugUNxqatGsKWHeEzwcmijCQlIYXSvV,'fanart':ugUNxqatGsKWHeEzwcmijCQlIYXSvy},'synopsis':ugUNxqatGsKWHeEzwcmijCQlIYXSvF,'channel':ugUNxqatGsKWHeEzwcmijCQlIYXSFk,'cast':ugUNxqatGsKWHeEzwcmijCQlIYXSvL,'director':ugUNxqatGsKWHeEzwcmijCQlIYXSvT,'info_genre':ugUNxqatGsKWHeEzwcmijCQlIYXSvr,'year':ugUNxqatGsKWHeEzwcmijCQlIYXSvd,'premiered':ugUNxqatGsKWHeEzwcmijCQlIYXSvp,'mpaa':ugUNxqatGsKWHeEzwcmijCQlIYXSvP}
    ugUNxqatGsKWHeEzwcmijCQlIYXSnp.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFJ)
   if ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['has_more']=='Y':ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOy
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
 def Get_UHD_ProgramList(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,page_int):
  ugUNxqatGsKWHeEzwcmijCQlIYXSnp=[]
  ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v2/operator/highlights'
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams(uhd=ugUNxqatGsKWHeEzwcmijCQlIYXSOy)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(page_int),'pocType':'APP_X_TVING_4.0.0',}
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if not('result' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']):return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
   ugUNxqatGsKWHeEzwcmijCQlIYXSMR=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']
   for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSMR:
    ugUNxqatGsKWHeEzwcmijCQlIYXSFM=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['content']['program']
    ugUNxqatGsKWHeEzwcmijCQlIYXSFv =ugUNxqatGsKWHeEzwcmijCQlIYXSFM['code']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvM =ugUNxqatGsKWHeEzwcmijCQlIYXSFM['name']['ko'].strip()
    ugUNxqatGsKWHeEzwcmijCQlIYXSvP =ugUNxqatGsKWHeEzwcmijCQlIYXSJM.get(ugUNxqatGsKWHeEzwcmijCQlIYXSFM.get('grade_code'))
    ugUNxqatGsKWHeEzwcmijCQlIYXSvF =ugUNxqatGsKWHeEzwcmijCQlIYXSFM['synopsis']['ko']
    ugUNxqatGsKWHeEzwcmijCQlIYXSFk =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['content']['channel']['name']['ko']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvd =ugUNxqatGsKWHeEzwcmijCQlIYXSFM['product_year']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvO =''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvy =''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvB=''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvA =''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvV =''
    for ugUNxqatGsKWHeEzwcmijCQlIYXSvh in ugUNxqatGsKWHeEzwcmijCQlIYXSFM['image']:
     if ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP0900':ugUNxqatGsKWHeEzwcmijCQlIYXSvO =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP0200':ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP1800':ugUNxqatGsKWHeEzwcmijCQlIYXSvB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP2000':ugUNxqatGsKWHeEzwcmijCQlIYXSvA =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP1900':ugUNxqatGsKWHeEzwcmijCQlIYXSvV =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvr =[]
    ugUNxqatGsKWHeEzwcmijCQlIYXSvL =[]
    ugUNxqatGsKWHeEzwcmijCQlIYXSvT=[]
    ugUNxqatGsKWHeEzwcmijCQlIYXSvp =''
    if ugUNxqatGsKWHeEzwcmijCQlIYXSFM.get('category1_name').get('ko')!='':
     ugUNxqatGsKWHeEzwcmijCQlIYXSvr.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFM['category1_name']['ko'])
    if ugUNxqatGsKWHeEzwcmijCQlIYXSFM.get('category2_name').get('ko')!='':
     ugUNxqatGsKWHeEzwcmijCQlIYXSvr.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFM['category2_name']['ko'])
    for ugUNxqatGsKWHeEzwcmijCQlIYXSvD in ugUNxqatGsKWHeEzwcmijCQlIYXSFM.get('actor'):
     if ugUNxqatGsKWHeEzwcmijCQlIYXSvD!='' and ugUNxqatGsKWHeEzwcmijCQlIYXSvD!='-' and ugUNxqatGsKWHeEzwcmijCQlIYXSvD!=u'없음':ugUNxqatGsKWHeEzwcmijCQlIYXSvL.append(ugUNxqatGsKWHeEzwcmijCQlIYXSvD)
    for ugUNxqatGsKWHeEzwcmijCQlIYXSvb in ugUNxqatGsKWHeEzwcmijCQlIYXSFM.get('director'):
     if ugUNxqatGsKWHeEzwcmijCQlIYXSvb!='' and ugUNxqatGsKWHeEzwcmijCQlIYXSvb!='-' and ugUNxqatGsKWHeEzwcmijCQlIYXSvb!=u'없음':ugUNxqatGsKWHeEzwcmijCQlIYXSvT.append(ugUNxqatGsKWHeEzwcmijCQlIYXSvb)
    if ugUNxqatGsKWHeEzwcmijCQlIYXSFM.get('broad_dt')not in[ugUNxqatGsKWHeEzwcmijCQlIYXSOM,'']:
     ugUNxqatGsKWHeEzwcmijCQlIYXSvf =ugUNxqatGsKWHeEzwcmijCQlIYXSFM.get('broad_dt')
     ugUNxqatGsKWHeEzwcmijCQlIYXSvp='%s-%s-%s'%(ugUNxqatGsKWHeEzwcmijCQlIYXSvf[:4],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[4:6],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[6:])
    ugUNxqatGsKWHeEzwcmijCQlIYXSFJ={'program':ugUNxqatGsKWHeEzwcmijCQlIYXSFv,'title':ugUNxqatGsKWHeEzwcmijCQlIYXSvM,'mpaa':ugUNxqatGsKWHeEzwcmijCQlIYXSvP,'thumbnail':{'poster':ugUNxqatGsKWHeEzwcmijCQlIYXSvO,'thumb':ugUNxqatGsKWHeEzwcmijCQlIYXSvy,'clearlogo':ugUNxqatGsKWHeEzwcmijCQlIYXSvB,'icon':ugUNxqatGsKWHeEzwcmijCQlIYXSvA,'banner':ugUNxqatGsKWHeEzwcmijCQlIYXSvV,'fanart':ugUNxqatGsKWHeEzwcmijCQlIYXSvy},'channel':ugUNxqatGsKWHeEzwcmijCQlIYXSFk,'synopsis':ugUNxqatGsKWHeEzwcmijCQlIYXSvF,'year':ugUNxqatGsKWHeEzwcmijCQlIYXSvd,'info_genre':ugUNxqatGsKWHeEzwcmijCQlIYXSvr,'cast':ugUNxqatGsKWHeEzwcmijCQlIYXSvL,'director':ugUNxqatGsKWHeEzwcmijCQlIYXSvT,'premiered':ugUNxqatGsKWHeEzwcmijCQlIYXSvp,}
    ugUNxqatGsKWHeEzwcmijCQlIYXSnp.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFJ)
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
 def Get_Origianl_ProgramList(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,page_int):
  ugUNxqatGsKWHeEzwcmijCQlIYXSnp=[]
  ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v2/media/band/originals'
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'pageSize':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(page_int),}
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   ugUNxqatGsKWHeEzwcmijCQlIYXSFy=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   ugUNxqatGsKWHeEzwcmijCQlIYXSJy.JsonFile_Save(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV_SESSION_COOKIES2,ugUNxqatGsKWHeEzwcmijCQlIYXSFy)
   if not('contents' in ugUNxqatGsKWHeEzwcmijCQlIYXSFy['body']):return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
   ugUNxqatGsKWHeEzwcmijCQlIYXSMR=ugUNxqatGsKWHeEzwcmijCQlIYXSFy['body']['contents']
   for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSMR:
    ugUNxqatGsKWHeEzwcmijCQlIYXSFO =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['vod_code']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvM =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['vod_name']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvO =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['image']
    ugUNxqatGsKWHeEzwcmijCQlIYXSFB ='movie' if ugUNxqatGsKWHeEzwcmijCQlIYXSFO.startswith('M')else 'vod'
    ugUNxqatGsKWHeEzwcmijCQlIYXSFJ={'vod_code':ugUNxqatGsKWHeEzwcmijCQlIYXSFO,'title':ugUNxqatGsKWHeEzwcmijCQlIYXSvM,'thumbnail':{'poster':ugUNxqatGsKWHeEzwcmijCQlIYXSvO,'thumb':ugUNxqatGsKWHeEzwcmijCQlIYXSvO},'vod_type':ugUNxqatGsKWHeEzwcmijCQlIYXSFB,}
    ugUNxqatGsKWHeEzwcmijCQlIYXSnp.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFJ)
   if ugUNxqatGsKWHeEzwcmijCQlIYXSFy['body']['has_more']=='Y':ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOy
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
 def GetEpisodeList(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,program_code,page_int,orderby='desc'):
  ugUNxqatGsKWHeEzwcmijCQlIYXSnp=[]
  ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v2/media/frequency/program/'+program_code
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if not('result' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']):return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
   ugUNxqatGsKWHeEzwcmijCQlIYXSMR=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']
   ugUNxqatGsKWHeEzwcmijCQlIYXSFA=ugUNxqatGsKWHeEzwcmijCQlIYXSOA(ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['total_count'])
   ugUNxqatGsKWHeEzwcmijCQlIYXSFV =ugUNxqatGsKWHeEzwcmijCQlIYXSOA(ugUNxqatGsKWHeEzwcmijCQlIYXSFA//(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    ugUNxqatGsKWHeEzwcmijCQlIYXSFo =(ugUNxqatGsKWHeEzwcmijCQlIYXSFA-1)-((page_int-1)*ugUNxqatGsKWHeEzwcmijCQlIYXSJy.EPISODE_LIMIT)
   else:
    ugUNxqatGsKWHeEzwcmijCQlIYXSFo =(page_int-1)*ugUNxqatGsKWHeEzwcmijCQlIYXSJy.EPISODE_LIMIT
   for i in ugUNxqatGsKWHeEzwcmijCQlIYXSOV(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.EPISODE_LIMIT):
    if orderby=='desc':
     ugUNxqatGsKWHeEzwcmijCQlIYXSFh=ugUNxqatGsKWHeEzwcmijCQlIYXSFo-i
     if ugUNxqatGsKWHeEzwcmijCQlIYXSFh<0:break
    else:
     ugUNxqatGsKWHeEzwcmijCQlIYXSFh=ugUNxqatGsKWHeEzwcmijCQlIYXSFo+i
     if ugUNxqatGsKWHeEzwcmijCQlIYXSFh>=ugUNxqatGsKWHeEzwcmijCQlIYXSFA:break
    ugUNxqatGsKWHeEzwcmijCQlIYXSFL=ugUNxqatGsKWHeEzwcmijCQlIYXSMR[ugUNxqatGsKWHeEzwcmijCQlIYXSFh]['episode']['code']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvM =ugUNxqatGsKWHeEzwcmijCQlIYXSMR[ugUNxqatGsKWHeEzwcmijCQlIYXSFh]['vod_name']['ko']
    ugUNxqatGsKWHeEzwcmijCQlIYXSFT =''
    try:
     ugUNxqatGsKWHeEzwcmijCQlIYXSvf=ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSMR[ugUNxqatGsKWHeEzwcmijCQlIYXSFh]['episode']['broadcast_date'])
     ugUNxqatGsKWHeEzwcmijCQlIYXSFT='%s-%s-%s'%(ugUNxqatGsKWHeEzwcmijCQlIYXSvf[:4],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[4:6],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[6:])
    except:
     ugUNxqatGsKWHeEzwcmijCQlIYXSOM
    try:
     if ugUNxqatGsKWHeEzwcmijCQlIYXSMR[ugUNxqatGsKWHeEzwcmijCQlIYXSFh]['episode']['pip_cliptype']=='C012':
      ugUNxqatGsKWHeEzwcmijCQlIYXSFT+=' - Quick VOD'
    except:
     ugUNxqatGsKWHeEzwcmijCQlIYXSOM
    ugUNxqatGsKWHeEzwcmijCQlIYXSvF =ugUNxqatGsKWHeEzwcmijCQlIYXSMR[ugUNxqatGsKWHeEzwcmijCQlIYXSFh]['episode']['synopsis']['ko']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvO =''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvy =''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvB=''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvA =''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvV =''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvo =''
    for ugUNxqatGsKWHeEzwcmijCQlIYXSvh in ugUNxqatGsKWHeEzwcmijCQlIYXSMR[ugUNxqatGsKWHeEzwcmijCQlIYXSFh]['program']['image']:
     if ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP0900':ugUNxqatGsKWHeEzwcmijCQlIYXSvO =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP1800':ugUNxqatGsKWHeEzwcmijCQlIYXSvB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP2000':ugUNxqatGsKWHeEzwcmijCQlIYXSvA =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP1900':ugUNxqatGsKWHeEzwcmijCQlIYXSvV =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIP0200':ugUNxqatGsKWHeEzwcmijCQlIYXSvo =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
    for ugUNxqatGsKWHeEzwcmijCQlIYXSvh in ugUNxqatGsKWHeEzwcmijCQlIYXSMR[ugUNxqatGsKWHeEzwcmijCQlIYXSFh]['episode']['image']:
     if ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIE0400':ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
    try:
     ugUNxqatGsKWHeEzwcmijCQlIYXSFr=ugUNxqatGsKWHeEzwcmijCQlIYXSFP=ugUNxqatGsKWHeEzwcmijCQlIYXSFp=''
     ugUNxqatGsKWHeEzwcmijCQlIYXSFd=0
     ugUNxqatGsKWHeEzwcmijCQlIYXSFr =ugUNxqatGsKWHeEzwcmijCQlIYXSMR[ugUNxqatGsKWHeEzwcmijCQlIYXSFh]['program']['name']['ko']
     ugUNxqatGsKWHeEzwcmijCQlIYXSFP =ugUNxqatGsKWHeEzwcmijCQlIYXSFT
     ugUNxqatGsKWHeEzwcmijCQlIYXSFp =ugUNxqatGsKWHeEzwcmijCQlIYXSMR[ugUNxqatGsKWHeEzwcmijCQlIYXSFh]['channel']['name']['ko']
     if 'frequency' in ugUNxqatGsKWHeEzwcmijCQlIYXSMR[ugUNxqatGsKWHeEzwcmijCQlIYXSFh]['episode']:ugUNxqatGsKWHeEzwcmijCQlIYXSFd=ugUNxqatGsKWHeEzwcmijCQlIYXSMR[ugUNxqatGsKWHeEzwcmijCQlIYXSFh]['episode']['frequency']
    except:
     ugUNxqatGsKWHeEzwcmijCQlIYXSOM
    ugUNxqatGsKWHeEzwcmijCQlIYXSFJ={'episode':ugUNxqatGsKWHeEzwcmijCQlIYXSFL,'title':ugUNxqatGsKWHeEzwcmijCQlIYXSvM,'subtitle':ugUNxqatGsKWHeEzwcmijCQlIYXSFT,'thumbnail':{'poster':ugUNxqatGsKWHeEzwcmijCQlIYXSvO,'thumb':ugUNxqatGsKWHeEzwcmijCQlIYXSvy,'clearlogo':ugUNxqatGsKWHeEzwcmijCQlIYXSvB,'icon':ugUNxqatGsKWHeEzwcmijCQlIYXSvA,'banner':ugUNxqatGsKWHeEzwcmijCQlIYXSvV,'fanart':ugUNxqatGsKWHeEzwcmijCQlIYXSvo},'synopsis':ugUNxqatGsKWHeEzwcmijCQlIYXSvF,'info_title':ugUNxqatGsKWHeEzwcmijCQlIYXSFr,'aired':ugUNxqatGsKWHeEzwcmijCQlIYXSFP,'studio':ugUNxqatGsKWHeEzwcmijCQlIYXSFp,'frequency':ugUNxqatGsKWHeEzwcmijCQlIYXSFd}
    ugUNxqatGsKWHeEzwcmijCQlIYXSnp.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFJ)
   if ugUNxqatGsKWHeEzwcmijCQlIYXSFV>page_int:ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOy
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb,ugUNxqatGsKWHeEzwcmijCQlIYXSFV
 def GetMovieList(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,genre,orderby,page_int):
  ugUNxqatGsKWHeEzwcmijCQlIYXSnp=[]
  ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  try:
   if genre=='PARAMOUNT':
    ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v2/media/paramount/movies'
   else:
    ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v2/media/movies'
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'pageSize':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:ugUNxqatGsKWHeEzwcmijCQlIYXSnf['categoryCode']=genre
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf['productPackageCode']=','.join(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.MOVIE_LITE)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if not('result' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']):return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
   ugUNxqatGsKWHeEzwcmijCQlIYXSMR=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']
   for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSMR:
    if 'release_date' in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('movie'):
     ugUNxqatGsKWHeEzwcmijCQlIYXSvd=ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('movie').get('release_date'))[:4]
    else:
     ugUNxqatGsKWHeEzwcmijCQlIYXSvd=ugUNxqatGsKWHeEzwcmijCQlIYXSOM
    ugUNxqatGsKWHeEzwcmijCQlIYXSFD =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['movie']['code']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvM =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['movie']['name']['ko'].strip()
    if ugUNxqatGsKWHeEzwcmijCQlIYXSvd not in[ugUNxqatGsKWHeEzwcmijCQlIYXSOM,'0','']:ugUNxqatGsKWHeEzwcmijCQlIYXSvM+=u' (%s)'%(ugUNxqatGsKWHeEzwcmijCQlIYXSvd)
    ugUNxqatGsKWHeEzwcmijCQlIYXSvO=''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvy =''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvB=''
    for ugUNxqatGsKWHeEzwcmijCQlIYXSvh in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['movie']['image']:
     if ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIM2100':ugUNxqatGsKWHeEzwcmijCQlIYXSvO =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIM0400':ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIM1800':ugUNxqatGsKWHeEzwcmijCQlIYXSvB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvF =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['movie']['story']['ko']
    try:
     ugUNxqatGsKWHeEzwcmijCQlIYXSFr =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['movie']['name']['ko'].strip()
     ugUNxqatGsKWHeEzwcmijCQlIYXSvP =ugUNxqatGsKWHeEzwcmijCQlIYXSJM.get(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('grade_code'))
     ugUNxqatGsKWHeEzwcmijCQlIYXSvL=[]
     ugUNxqatGsKWHeEzwcmijCQlIYXSvT=[]
     ugUNxqatGsKWHeEzwcmijCQlIYXSvr=[]
     ugUNxqatGsKWHeEzwcmijCQlIYXSFb=0
     ugUNxqatGsKWHeEzwcmijCQlIYXSvp=''
     ugUNxqatGsKWHeEzwcmijCQlIYXSFp =''
     for ugUNxqatGsKWHeEzwcmijCQlIYXSvD in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('movie').get('actor'):
      if ugUNxqatGsKWHeEzwcmijCQlIYXSvD!='':ugUNxqatGsKWHeEzwcmijCQlIYXSvL.append(ugUNxqatGsKWHeEzwcmijCQlIYXSvD)
     for ugUNxqatGsKWHeEzwcmijCQlIYXSvb in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('movie').get('director'):
      if ugUNxqatGsKWHeEzwcmijCQlIYXSvb!='':ugUNxqatGsKWHeEzwcmijCQlIYXSvT.append(ugUNxqatGsKWHeEzwcmijCQlIYXSvb)
     if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('movie').get('category1_name').get('ko')!='':
      ugUNxqatGsKWHeEzwcmijCQlIYXSvr.append(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['movie']['category1_name']['ko'])
     if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('movie').get('category2_name').get('ko')!='':
      ugUNxqatGsKWHeEzwcmijCQlIYXSvr.append(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['movie']['category2_name']['ko'])
     if 'duration' in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('movie'):ugUNxqatGsKWHeEzwcmijCQlIYXSFb=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('movie').get('duration')
     if 'release_date' in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('movie'):
      ugUNxqatGsKWHeEzwcmijCQlIYXSvf=ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('movie').get('release_date'))
      if ugUNxqatGsKWHeEzwcmijCQlIYXSvf!='0':ugUNxqatGsKWHeEzwcmijCQlIYXSvp='%s-%s-%s'%(ugUNxqatGsKWHeEzwcmijCQlIYXSvf[:4],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[4:6],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[6:])
     if 'production' in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('movie'):ugUNxqatGsKWHeEzwcmijCQlIYXSFp=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('movie').get('production')
    except:
     ugUNxqatGsKWHeEzwcmijCQlIYXSOM
    ugUNxqatGsKWHeEzwcmijCQlIYXSFJ={'moviecode':ugUNxqatGsKWHeEzwcmijCQlIYXSFD,'title':ugUNxqatGsKWHeEzwcmijCQlIYXSvM,'thumbnail':{'poster':ugUNxqatGsKWHeEzwcmijCQlIYXSvO,'thumb':ugUNxqatGsKWHeEzwcmijCQlIYXSvy,'clearlogo':ugUNxqatGsKWHeEzwcmijCQlIYXSvB,'fanart':ugUNxqatGsKWHeEzwcmijCQlIYXSvy},'synopsis':ugUNxqatGsKWHeEzwcmijCQlIYXSvF,'info_title':ugUNxqatGsKWHeEzwcmijCQlIYXSFr,'year':ugUNxqatGsKWHeEzwcmijCQlIYXSvd,'cast':ugUNxqatGsKWHeEzwcmijCQlIYXSvL,'director':ugUNxqatGsKWHeEzwcmijCQlIYXSvT,'info_genre':ugUNxqatGsKWHeEzwcmijCQlIYXSvr,'duration':ugUNxqatGsKWHeEzwcmijCQlIYXSFb,'premiered':ugUNxqatGsKWHeEzwcmijCQlIYXSvp,'studio':ugUNxqatGsKWHeEzwcmijCQlIYXSFp,'mpaa':ugUNxqatGsKWHeEzwcmijCQlIYXSvP}
    ugUNxqatGsKWHeEzwcmijCQlIYXSFf=ugUNxqatGsKWHeEzwcmijCQlIYXSOv
    for ugUNxqatGsKWHeEzwcmijCQlIYXSFR in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['billing_package_id']:
     if ugUNxqatGsKWHeEzwcmijCQlIYXSFR in ugUNxqatGsKWHeEzwcmijCQlIYXSJy.MOVIE_LITE:
      ugUNxqatGsKWHeEzwcmijCQlIYXSFf=ugUNxqatGsKWHeEzwcmijCQlIYXSOy
      break
    if ugUNxqatGsKWHeEzwcmijCQlIYXSFf==ugUNxqatGsKWHeEzwcmijCQlIYXSOv: 
     ugUNxqatGsKWHeEzwcmijCQlIYXSFJ['title']=ugUNxqatGsKWHeEzwcmijCQlIYXSFJ['title']+' [개별구매]'
    ugUNxqatGsKWHeEzwcmijCQlIYXSnp.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFJ)
   if ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['has_more']=='Y':ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOy
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
 def Get_UHD_MovieList(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,page_int):
  ugUNxqatGsKWHeEzwcmijCQlIYXSnp=[]
  ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v2/operator/highlights'
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams(uhd=ugUNxqatGsKWHeEzwcmijCQlIYXSOy)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(page_int),'pocType':'APP_X_TVING_4.0.0',}
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if not('result' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']):return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
   ugUNxqatGsKWHeEzwcmijCQlIYXSMR=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']
   for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSMR:
    ugUNxqatGsKWHeEzwcmijCQlIYXSFM=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['content']['movie']
    ugUNxqatGsKWHeEzwcmijCQlIYXSFv =ugUNxqatGsKWHeEzwcmijCQlIYXSFM['code']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvM =ugUNxqatGsKWHeEzwcmijCQlIYXSFM['name']['ko'].strip()
    ugUNxqatGsKWHeEzwcmijCQlIYXSFr =ugUNxqatGsKWHeEzwcmijCQlIYXSFM['name']['ko'].strip()
    ugUNxqatGsKWHeEzwcmijCQlIYXSvd =ugUNxqatGsKWHeEzwcmijCQlIYXSFM['product_year']
    if ugUNxqatGsKWHeEzwcmijCQlIYXSvd:ugUNxqatGsKWHeEzwcmijCQlIYXSvM+=u' (%s)'%(ugUNxqatGsKWHeEzwcmijCQlIYXSFM['product_year'])
    ugUNxqatGsKWHeEzwcmijCQlIYXSvF =ugUNxqatGsKWHeEzwcmijCQlIYXSFM['story']['ko']
    ugUNxqatGsKWHeEzwcmijCQlIYXSFb =ugUNxqatGsKWHeEzwcmijCQlIYXSFM['duration']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvP =ugUNxqatGsKWHeEzwcmijCQlIYXSJM.get(ugUNxqatGsKWHeEzwcmijCQlIYXSFM.get('grade_code'))
    ugUNxqatGsKWHeEzwcmijCQlIYXSFp =ugUNxqatGsKWHeEzwcmijCQlIYXSFM['production']
    ugUNxqatGsKWHeEzwcmijCQlIYXSvO=''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvy =''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvB=''
    ugUNxqatGsKWHeEzwcmijCQlIYXSvr =[]
    ugUNxqatGsKWHeEzwcmijCQlIYXSvL =[]
    ugUNxqatGsKWHeEzwcmijCQlIYXSvT=[]
    ugUNxqatGsKWHeEzwcmijCQlIYXSvp =''
    for ugUNxqatGsKWHeEzwcmijCQlIYXSvh in ugUNxqatGsKWHeEzwcmijCQlIYXSFM['image']:
     if ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIM2100':ugUNxqatGsKWHeEzwcmijCQlIYXSvO =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIM0400':ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
     elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh['code']=='CAIM1800':ugUNxqatGsKWHeEzwcmijCQlIYXSvB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh['url']
    if ugUNxqatGsKWHeEzwcmijCQlIYXSFM['release_date']not in[ugUNxqatGsKWHeEzwcmijCQlIYXSOM,0]:
     ugUNxqatGsKWHeEzwcmijCQlIYXSvf=ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSFM['release_date'])
     if ugUNxqatGsKWHeEzwcmijCQlIYXSvf!='0':ugUNxqatGsKWHeEzwcmijCQlIYXSvp='%s-%s-%s'%(ugUNxqatGsKWHeEzwcmijCQlIYXSvf[:4],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[4:6],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[6:])
    if ugUNxqatGsKWHeEzwcmijCQlIYXSFM.get('category1_name').get('ko')!='':
     ugUNxqatGsKWHeEzwcmijCQlIYXSvr.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFM['category1_name']['ko'])
    if ugUNxqatGsKWHeEzwcmijCQlIYXSFM.get('category2_name').get('ko')!='':
     ugUNxqatGsKWHeEzwcmijCQlIYXSvr.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFM['category2_name']['ko'])
    for ugUNxqatGsKWHeEzwcmijCQlIYXSvD in ugUNxqatGsKWHeEzwcmijCQlIYXSFM.get('actor'):
     if ugUNxqatGsKWHeEzwcmijCQlIYXSvD!='':ugUNxqatGsKWHeEzwcmijCQlIYXSvL.append(ugUNxqatGsKWHeEzwcmijCQlIYXSvD)
    for ugUNxqatGsKWHeEzwcmijCQlIYXSvb in ugUNxqatGsKWHeEzwcmijCQlIYXSFM.get('director'):
     if ugUNxqatGsKWHeEzwcmijCQlIYXSvb!='':ugUNxqatGsKWHeEzwcmijCQlIYXSvT.append(ugUNxqatGsKWHeEzwcmijCQlIYXSvb)
    ugUNxqatGsKWHeEzwcmijCQlIYXSFJ={'moviecode':ugUNxqatGsKWHeEzwcmijCQlIYXSFv,'title':ugUNxqatGsKWHeEzwcmijCQlIYXSvM,'thumbnail':{'poster':ugUNxqatGsKWHeEzwcmijCQlIYXSvO,'thumb':ugUNxqatGsKWHeEzwcmijCQlIYXSvy,'clearlogo':ugUNxqatGsKWHeEzwcmijCQlIYXSvB,'fanart':ugUNxqatGsKWHeEzwcmijCQlIYXSvy},'year':ugUNxqatGsKWHeEzwcmijCQlIYXSvd,'info_title':ugUNxqatGsKWHeEzwcmijCQlIYXSFr,'synopsis':ugUNxqatGsKWHeEzwcmijCQlIYXSvF,'mpaa':ugUNxqatGsKWHeEzwcmijCQlIYXSvP,'duration':ugUNxqatGsKWHeEzwcmijCQlIYXSFb,'premiered':ugUNxqatGsKWHeEzwcmijCQlIYXSvp,'studio':ugUNxqatGsKWHeEzwcmijCQlIYXSFp,'info_genre':ugUNxqatGsKWHeEzwcmijCQlIYXSvr,'cast':ugUNxqatGsKWHeEzwcmijCQlIYXSvL,'director':ugUNxqatGsKWHeEzwcmijCQlIYXSvT,}
    ugUNxqatGsKWHeEzwcmijCQlIYXSnp.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFJ)
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
 def GetMovieGenre(ugUNxqatGsKWHeEzwcmijCQlIYXSJy):
  ugUNxqatGsKWHeEzwcmijCQlIYXSnp=[]
  ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v2/media/movie/curations'
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if not('result' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']):return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
   ugUNxqatGsKWHeEzwcmijCQlIYXSMR=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']
   for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSMR:
    ugUNxqatGsKWHeEzwcmijCQlIYXSyJ =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['curation_code']
    ugUNxqatGsKWHeEzwcmijCQlIYXSyn =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['curation_name']
    ugUNxqatGsKWHeEzwcmijCQlIYXSFJ={'curation_code':ugUNxqatGsKWHeEzwcmijCQlIYXSyJ,'curation_name':ugUNxqatGsKWHeEzwcmijCQlIYXSyn}
    ugUNxqatGsKWHeEzwcmijCQlIYXSnp.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFJ)
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
 def GetSearchList(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,search_key,page_int,stype):
  ugUNxqatGsKWHeEzwcmijCQlIYXSyk=[]
  ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOv
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/search/getSearch.jsp'
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.SCREENCODE,'os':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.OSCODE,'network':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.APIKEY,'networkCode':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.NETWORKCODE,'osCode ':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.OSCODE,'teleCode ':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TELECODE,'screenCode ':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.SCREENCODE}
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.SEARCH_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSnf,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if stype=='vod':
    if not('programRsb' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR):return ugUNxqatGsKWHeEzwcmijCQlIYXSyk,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
    ugUNxqatGsKWHeEzwcmijCQlIYXSyM=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['programRsb']['dataList']
    ugUNxqatGsKWHeEzwcmijCQlIYXSyv =ugUNxqatGsKWHeEzwcmijCQlIYXSOA(ugUNxqatGsKWHeEzwcmijCQlIYXSnR['programRsb']['count'])
    for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSyM:
     ugUNxqatGsKWHeEzwcmijCQlIYXSFn=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['mast_cd']
     ugUNxqatGsKWHeEzwcmijCQlIYXSvM =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['mast_nm']
     ugUNxqatGsKWHeEzwcmijCQlIYXSvO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['web_url4']
     ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['web_url']
     try:
      ugUNxqatGsKWHeEzwcmijCQlIYXSvL =[]
      ugUNxqatGsKWHeEzwcmijCQlIYXSvT=[]
      ugUNxqatGsKWHeEzwcmijCQlIYXSvr =[]
      ugUNxqatGsKWHeEzwcmijCQlIYXSFb =0
      ugUNxqatGsKWHeEzwcmijCQlIYXSvP =''
      ugUNxqatGsKWHeEzwcmijCQlIYXSvd =''
      ugUNxqatGsKWHeEzwcmijCQlIYXSFP =''
      if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('actor') !='' and ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('actor') !='-':ugUNxqatGsKWHeEzwcmijCQlIYXSvL =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('actor').split(',')
      if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('director')!='' and ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('director')!='-':ugUNxqatGsKWHeEzwcmijCQlIYXSvT=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('director').split(',')
      if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('cate_nm')!='' and ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('cate_nm')!='-':ugUNxqatGsKWHeEzwcmijCQlIYXSvr =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('cate_nm').split('/')
      if 'targetage' in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ:ugUNxqatGsKWHeEzwcmijCQlIYXSvP=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('targetage')
      if 'broad_dt' in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ:
       ugUNxqatGsKWHeEzwcmijCQlIYXSvf=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('broad_dt')
       ugUNxqatGsKWHeEzwcmijCQlIYXSFP='%s-%s-%s'%(ugUNxqatGsKWHeEzwcmijCQlIYXSvf[:4],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[4:6],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[6:])
       ugUNxqatGsKWHeEzwcmijCQlIYXSvd =ugUNxqatGsKWHeEzwcmijCQlIYXSvf[:4]
     except:
      ugUNxqatGsKWHeEzwcmijCQlIYXSOM
     ugUNxqatGsKWHeEzwcmijCQlIYXSFJ={'program':ugUNxqatGsKWHeEzwcmijCQlIYXSFn,'title':ugUNxqatGsKWHeEzwcmijCQlIYXSvM,'thumbnail':{'poster':ugUNxqatGsKWHeEzwcmijCQlIYXSvO,'thumb':ugUNxqatGsKWHeEzwcmijCQlIYXSvy,'fanart':ugUNxqatGsKWHeEzwcmijCQlIYXSvy},'synopsis':'','cast':ugUNxqatGsKWHeEzwcmijCQlIYXSvL,'director':ugUNxqatGsKWHeEzwcmijCQlIYXSvT,'info_genre':ugUNxqatGsKWHeEzwcmijCQlIYXSvr,'duration':ugUNxqatGsKWHeEzwcmijCQlIYXSFb,'mpaa':ugUNxqatGsKWHeEzwcmijCQlIYXSvP,'year':ugUNxqatGsKWHeEzwcmijCQlIYXSvd,'aired':ugUNxqatGsKWHeEzwcmijCQlIYXSFP}
     ugUNxqatGsKWHeEzwcmijCQlIYXSyk.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFJ)
   else:
    if not('vodMVRsb' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR):return ugUNxqatGsKWHeEzwcmijCQlIYXSyk,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
    ugUNxqatGsKWHeEzwcmijCQlIYXSyF=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['vodMVRsb']['dataList']
    ugUNxqatGsKWHeEzwcmijCQlIYXSyv =ugUNxqatGsKWHeEzwcmijCQlIYXSOA(ugUNxqatGsKWHeEzwcmijCQlIYXSnR['vodMVRsb']['count'])
    for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSyF:
     ugUNxqatGsKWHeEzwcmijCQlIYXSFn=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['mast_cd']
     ugUNxqatGsKWHeEzwcmijCQlIYXSvM =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['mast_nm'].strip()
     ugUNxqatGsKWHeEzwcmijCQlIYXSvO =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['web_url']
     ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSvO
     ugUNxqatGsKWHeEzwcmijCQlIYXSvB=''
     try:
      ugUNxqatGsKWHeEzwcmijCQlIYXSvL =[]
      ugUNxqatGsKWHeEzwcmijCQlIYXSvT=[]
      ugUNxqatGsKWHeEzwcmijCQlIYXSvr =[]
      ugUNxqatGsKWHeEzwcmijCQlIYXSFb =0
      ugUNxqatGsKWHeEzwcmijCQlIYXSvP =''
      ugUNxqatGsKWHeEzwcmijCQlIYXSvd =''
      ugUNxqatGsKWHeEzwcmijCQlIYXSFP =''
      if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('actor') !='' and ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('actor') !='-':ugUNxqatGsKWHeEzwcmijCQlIYXSvL =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('actor').split(',')
      if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('director')!='' and ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('director')!='-':ugUNxqatGsKWHeEzwcmijCQlIYXSvT=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('director').split(',')
      if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('cate_nm')!='' and ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('cate_nm')!='-':ugUNxqatGsKWHeEzwcmijCQlIYXSvr =ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('cate_nm').split('/')
      if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('runtime_sec')!='':ugUNxqatGsKWHeEzwcmijCQlIYXSFb=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('runtime_sec')
      if 'grade_nm' in ugUNxqatGsKWHeEzwcmijCQlIYXSkJ:ugUNxqatGsKWHeEzwcmijCQlIYXSvP=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('grade_nm')
      ugUNxqatGsKWHeEzwcmijCQlIYXSvf=ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('broad_dt')
      if data_str!='':
       ugUNxqatGsKWHeEzwcmijCQlIYXSFP='%s-%s-%s'%(ugUNxqatGsKWHeEzwcmijCQlIYXSvf[:4],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[4:6],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[6:])
       ugUNxqatGsKWHeEzwcmijCQlIYXSvd =ugUNxqatGsKWHeEzwcmijCQlIYXSvf[:4]
     except:
      ugUNxqatGsKWHeEzwcmijCQlIYXSOM
     ugUNxqatGsKWHeEzwcmijCQlIYXSFJ={'movie':ugUNxqatGsKWHeEzwcmijCQlIYXSFn,'title':ugUNxqatGsKWHeEzwcmijCQlIYXSvM,'thumbnail':{'poster':ugUNxqatGsKWHeEzwcmijCQlIYXSvO,'thumb':ugUNxqatGsKWHeEzwcmijCQlIYXSvy,'fanart':ugUNxqatGsKWHeEzwcmijCQlIYXSvy,'clearlogo':ugUNxqatGsKWHeEzwcmijCQlIYXSvB},'synopsis':'','cast':ugUNxqatGsKWHeEzwcmijCQlIYXSvL,'director':ugUNxqatGsKWHeEzwcmijCQlIYXSvT,'info_genre':ugUNxqatGsKWHeEzwcmijCQlIYXSvr,'duration':ugUNxqatGsKWHeEzwcmijCQlIYXSFb,'mpaa':ugUNxqatGsKWHeEzwcmijCQlIYXSvP,'year':ugUNxqatGsKWHeEzwcmijCQlIYXSvd,'aired':ugUNxqatGsKWHeEzwcmijCQlIYXSFP}
     ugUNxqatGsKWHeEzwcmijCQlIYXSyk.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFJ)
   if ugUNxqatGsKWHeEzwcmijCQlIYXSyv>(page_int*ugUNxqatGsKWHeEzwcmijCQlIYXSJy.SEARCH_LIMIT):ugUNxqatGsKWHeEzwcmijCQlIYXSMb=ugUNxqatGsKWHeEzwcmijCQlIYXSOy
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSyk,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
 def GetBookmarkInfo(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,videoid,vidtype):
  ugUNxqatGsKWHeEzwcmijCQlIYXSyO={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+'/v2/media/program/'+videoid
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'pageNo':'1','pageSize':'10','order':'name',}
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   ugUNxqatGsKWHeEzwcmijCQlIYXSFy=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if not('body' in ugUNxqatGsKWHeEzwcmijCQlIYXSFy):return{}
   ugUNxqatGsKWHeEzwcmijCQlIYXSyB=ugUNxqatGsKWHeEzwcmijCQlIYXSFy['body']
   ugUNxqatGsKWHeEzwcmijCQlIYXSvM=ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('name').get('ko').strip()
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['title'] =ugUNxqatGsKWHeEzwcmijCQlIYXSvM
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['title']=ugUNxqatGsKWHeEzwcmijCQlIYXSvM
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['mpaa'] =ugUNxqatGsKWHeEzwcmijCQlIYXSJM.get(ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('grade_code'))
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['plot'] =ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('synopsis').get('ko')
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['year'] =ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('product_year')
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['cast'] =ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('actor')
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['director']=ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('director')
   if ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('category1_name').get('ko')!='':
    ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['genre'].append(ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('category1_name').get('ko'))
   if ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('category2_name').get('ko')!='':
    ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['genre'].append(ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('category2_name').get('ko'))
   ugUNxqatGsKWHeEzwcmijCQlIYXSvf=ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('broad_dt'))
   if ugUNxqatGsKWHeEzwcmijCQlIYXSvf!='0':ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(ugUNxqatGsKWHeEzwcmijCQlIYXSvf[:4],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[4:6],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[6:])
   ugUNxqatGsKWHeEzwcmijCQlIYXSvO =''
   ugUNxqatGsKWHeEzwcmijCQlIYXSvy =''
   ugUNxqatGsKWHeEzwcmijCQlIYXSvB=''
   ugUNxqatGsKWHeEzwcmijCQlIYXSvA =''
   ugUNxqatGsKWHeEzwcmijCQlIYXSvV =''
   for ugUNxqatGsKWHeEzwcmijCQlIYXSvh in ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('image'):
    if ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('code')=='CAIP0900':ugUNxqatGsKWHeEzwcmijCQlIYXSvO =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('url')
    elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('code')=='CAIP0200':ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('url')
    elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('code')=='CAIP1800':ugUNxqatGsKWHeEzwcmijCQlIYXSvB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('url')
    elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('code')=='CAIP2000':ugUNxqatGsKWHeEzwcmijCQlIYXSvA =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('url')
    elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('code')=='CAIP1900':ugUNxqatGsKWHeEzwcmijCQlIYXSvV =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('url')
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['thumbnail']['poster']=ugUNxqatGsKWHeEzwcmijCQlIYXSvO
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['thumbnail']['thumb']=ugUNxqatGsKWHeEzwcmijCQlIYXSvy
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['thumbnail']['clearlogo']=ugUNxqatGsKWHeEzwcmijCQlIYXSvB
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['thumbnail']['icon']=ugUNxqatGsKWHeEzwcmijCQlIYXSvA
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['thumbnail']['banner']=ugUNxqatGsKWHeEzwcmijCQlIYXSvV
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['thumbnail']['fanart']=ugUNxqatGsKWHeEzwcmijCQlIYXSvy
  else:
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+'/v2a/media/stream/info'
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_uuid'].split('-')[0],'uuid':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetNoCache(1)),'wm':'Y',}
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   ugUNxqatGsKWHeEzwcmijCQlIYXSFy=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if not('content' in ugUNxqatGsKWHeEzwcmijCQlIYXSFy['body']):return{}
   ugUNxqatGsKWHeEzwcmijCQlIYXSyB=ugUNxqatGsKWHeEzwcmijCQlIYXSFy['body']['content']['info']['movie']
   ugUNxqatGsKWHeEzwcmijCQlIYXSvM =ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('name').get('ko').strip()
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['title']=ugUNxqatGsKWHeEzwcmijCQlIYXSvM
   ugUNxqatGsKWHeEzwcmijCQlIYXSvM +=u' (%s)'%(ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('product_year'))
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['title'] =ugUNxqatGsKWHeEzwcmijCQlIYXSvM
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['mpaa'] =ugUNxqatGsKWHeEzwcmijCQlIYXSJM.get(ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('grade_code'))
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['plot'] =ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('story').get('ko')
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['year'] =ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('product_year')
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['studio'] =ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('production')
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['duration']=ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('duration')
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['cast'] =ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('actor')
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['director']=ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('director')
   if ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('category1_name').get('ko')!='':
    ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['genre'].append(ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('category1_name').get('ko'))
   if ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('category2_name').get('ko')!='':
    ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['genre'].append(ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('category2_name').get('ko'))
   ugUNxqatGsKWHeEzwcmijCQlIYXSvf=ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('release_date'))
   if ugUNxqatGsKWHeEzwcmijCQlIYXSvf!='0':ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(ugUNxqatGsKWHeEzwcmijCQlIYXSvf[:4],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[4:6],ugUNxqatGsKWHeEzwcmijCQlIYXSvf[6:])
   ugUNxqatGsKWHeEzwcmijCQlIYXSvO=''
   ugUNxqatGsKWHeEzwcmijCQlIYXSvy =''
   ugUNxqatGsKWHeEzwcmijCQlIYXSvB=''
   for ugUNxqatGsKWHeEzwcmijCQlIYXSvh in ugUNxqatGsKWHeEzwcmijCQlIYXSyB.get('image'):
    if ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('code')=='CAIM2100':ugUNxqatGsKWHeEzwcmijCQlIYXSvO =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('url')
    elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('code')=='CAIM0400':ugUNxqatGsKWHeEzwcmijCQlIYXSvy =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('url')
    elif ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('code')=='CAIM1800':ugUNxqatGsKWHeEzwcmijCQlIYXSvB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.IMG_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSvh.get('url')
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['thumbnail']['poster']=ugUNxqatGsKWHeEzwcmijCQlIYXSvO
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['thumbnail']['thumb']=ugUNxqatGsKWHeEzwcmijCQlIYXSvO 
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['thumbnail']['clearlogo']=ugUNxqatGsKWHeEzwcmijCQlIYXSvB
   ugUNxqatGsKWHeEzwcmijCQlIYXSyO['saveinfo']['thumbnail']['fanart']=ugUNxqatGsKWHeEzwcmijCQlIYXSvy
  return ugUNxqatGsKWHeEzwcmijCQlIYXSyO
 def GetEuroChannelList(ugUNxqatGsKWHeEzwcmijCQlIYXSJy):
  ugUNxqatGsKWHeEzwcmijCQlIYXSnp=[]
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v2/operator/highlights'
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetNoCache(2))}
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSOM)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if not('result' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']):return ugUNxqatGsKWHeEzwcmijCQlIYXSnp,ugUNxqatGsKWHeEzwcmijCQlIYXSMb
   ugUNxqatGsKWHeEzwcmijCQlIYXSMR=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']
   ugUNxqatGsKWHeEzwcmijCQlIYXSyA =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Get_Now_Datetime()
   ugUNxqatGsKWHeEzwcmijCQlIYXSyV=ugUNxqatGsKWHeEzwcmijCQlIYXSyA+datetime.timedelta(days=-1)
   ugUNxqatGsKWHeEzwcmijCQlIYXSyV=ugUNxqatGsKWHeEzwcmijCQlIYXSOA(ugUNxqatGsKWHeEzwcmijCQlIYXSyV.strftime('%Y%m%d'))
   for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSMR:
    ugUNxqatGsKWHeEzwcmijCQlIYXSyo=ugUNxqatGsKWHeEzwcmijCQlIYXSOA(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('content').get('banner_title2')[:8])
    if ugUNxqatGsKWHeEzwcmijCQlIYXSyV<=ugUNxqatGsKWHeEzwcmijCQlIYXSyo:
     ugUNxqatGsKWHeEzwcmijCQlIYXSFJ={'channel':ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('content').get('banner_sub_title3'),'title':ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('content').get('banner_title'),'subtitle':ugUNxqatGsKWHeEzwcmijCQlIYXSkJ.get('content').get('banner_sub_title2'),}
     ugUNxqatGsKWHeEzwcmijCQlIYXSnp.append(ugUNxqatGsKWHeEzwcmijCQlIYXSFJ)
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSnp
 def Make_DecryptKey(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,step,mediacode='000',timecode='000'):
  if step=='1':
   ugUNxqatGsKWHeEzwcmijCQlIYXSyh=ugUNxqatGsKWHeEzwcmijCQlIYXSOr('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   ugUNxqatGsKWHeEzwcmijCQlIYXSyL=ugUNxqatGsKWHeEzwcmijCQlIYXSOr('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   ugUNxqatGsKWHeEzwcmijCQlIYXSyh=ugUNxqatGsKWHeEzwcmijCQlIYXSOr('kss2lym0kdw1lks3','utf-8')
   ugUNxqatGsKWHeEzwcmijCQlIYXSyL=ugUNxqatGsKWHeEzwcmijCQlIYXSOr([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return ugUNxqatGsKWHeEzwcmijCQlIYXSyh,ugUNxqatGsKWHeEzwcmijCQlIYXSyL
 def DecryptPlaintext(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,ciphertext,encryption_key,init_vector):
  ugUNxqatGsKWHeEzwcmijCQlIYXSyT=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  ugUNxqatGsKWHeEzwcmijCQlIYXSyr=Padding.unpad(ugUNxqatGsKWHeEzwcmijCQlIYXSyT.decrypt(base64.standard_b64decode(ciphertext)),16)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSyr.decode('utf-8')
 def Decrypt_Url(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,ciphertext,mediacode,ugUNxqatGsKWHeEzwcmijCQlIYXSkT):
  ugUNxqatGsKWHeEzwcmijCQlIYXSyd=''
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSyh,ugUNxqatGsKWHeEzwcmijCQlIYXSyL=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Make_DecryptKey('1',mediacode=mediacode,timecode=ugUNxqatGsKWHeEzwcmijCQlIYXSkT)
   ugUNxqatGsKWHeEzwcmijCQlIYXSyP=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.DecryptPlaintext(ciphertext,ugUNxqatGsKWHeEzwcmijCQlIYXSyh,ugUNxqatGsKWHeEzwcmijCQlIYXSyL))
   ugUNxqatGsKWHeEzwcmijCQlIYXSyp =ugUNxqatGsKWHeEzwcmijCQlIYXSyP.get('url')
   ugUNxqatGsKWHeEzwcmijCQlIYXSyh,ugUNxqatGsKWHeEzwcmijCQlIYXSyL=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Make_DecryptKey('2',mediacode=mediacode,timecode=ugUNxqatGsKWHeEzwcmijCQlIYXSkT)
   ugUNxqatGsKWHeEzwcmijCQlIYXSyd=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.DecryptPlaintext(ugUNxqatGsKWHeEzwcmijCQlIYXSyp,ugUNxqatGsKWHeEzwcmijCQlIYXSyh,ugUNxqatGsKWHeEzwcmijCQlIYXSyL)
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
  return ugUNxqatGsKWHeEzwcmijCQlIYXSyd
 def GetLiveURL_Test(ugUNxqatGsKWHeEzwcmijCQlIYXSJy,mediacode,sel_quality):
  ugUNxqatGsKWHeEzwcmijCQlIYXSkM ={'streaming_url':'','subtitleYn':ugUNxqatGsKWHeEzwcmijCQlIYXSOv,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  ugUNxqatGsKWHeEzwcmijCQlIYXSnD =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_uuid'].split('-')[0] 
  ugUNxqatGsKWHeEzwcmijCQlIYXSkv =ugUNxqatGsKWHeEzwcmijCQlIYXSJy.TV['cookies']['tving_uuid'] 
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSky=ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetNoCache(1))
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v2/media/stream/info' 
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':ugUNxqatGsKWHeEzwcmijCQlIYXSkv,'deviceInfo':'PC','noCache':ugUNxqatGsKWHeEzwcmijCQlIYXSky,}
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSJR=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.makeDefaultCookies()
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Get',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSJR)
   if ugUNxqatGsKWHeEzwcmijCQlIYXSno.status_code!=200:
    ugUNxqatGsKWHeEzwcmijCQlIYXSkM['error_msg']='First Step - {} error'.format(ugUNxqatGsKWHeEzwcmijCQlIYXSno.status_code)
    return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
   ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']['code']=='060':
    for ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSJD in ugUNxqatGsKWHeEzwcmijCQlIYXSJk.items():
     if ugUNxqatGsKWHeEzwcmijCQlIYXSJD==sel_quality:
      ugUNxqatGsKWHeEzwcmijCQlIYXSkA=ugUNxqatGsKWHeEzwcmijCQlIYXSJp
   elif ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']['code']!='000':
    ugUNxqatGsKWHeEzwcmijCQlIYXSkM['error_msg']=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']['message']
    return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
   else: 
    if not('stream' in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']):return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
    ugUNxqatGsKWHeEzwcmijCQlIYXSkV=[]
    for ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSJD in ugUNxqatGsKWHeEzwcmijCQlIYXSJk.items():
     for ugUNxqatGsKWHeEzwcmijCQlIYXSkJ in ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['stream']['quality']:
      if ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['active']=='Y' and ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['code']==ugUNxqatGsKWHeEzwcmijCQlIYXSJp:
       ugUNxqatGsKWHeEzwcmijCQlIYXSkV.append({ugUNxqatGsKWHeEzwcmijCQlIYXSJk.get(ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['code']):ugUNxqatGsKWHeEzwcmijCQlIYXSkJ['code']})
    ugUNxqatGsKWHeEzwcmijCQlIYXSkA=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.CheckQuality(sel_quality,ugUNxqatGsKWHeEzwcmijCQlIYXSkV)
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkM['error_msg']='First Step - except error'
   return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
  try:
   ugUNxqatGsKWHeEzwcmijCQlIYXSky=ugUNxqatGsKWHeEzwcmijCQlIYXSOh(ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetNoCache(1))
   ugUNxqatGsKWHeEzwcmijCQlIYXSnr ='/v3/media/stream/info'
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.GetDefaultParams()
   ugUNxqatGsKWHeEzwcmijCQlIYXSnf={'mediaCode':mediacode,'deviceId':ugUNxqatGsKWHeEzwcmijCQlIYXSnD,'uuid':ugUNxqatGsKWHeEzwcmijCQlIYXSkv,'deviceInfo':'PC_Chrome','streamCode':ugUNxqatGsKWHeEzwcmijCQlIYXSkA,'noCache':ugUNxqatGsKWHeEzwcmijCQlIYXSky,'callingFrom':'HTML5','model':ugUNxqatGsKWHeEzwcmijCQlIYXSJy.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   ugUNxqatGsKWHeEzwcmijCQlIYXSkO.update(ugUNxqatGsKWHeEzwcmijCQlIYXSnf)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkB=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.API_DOMAIN+ugUNxqatGsKWHeEzwcmijCQlIYXSnr
   ugUNxqatGsKWHeEzwcmijCQlIYXSJR=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.makeDefaultCookies()
   ugUNxqatGsKWHeEzwcmijCQlIYXSno=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.callRequestCookies('Post',ugUNxqatGsKWHeEzwcmijCQlIYXSkB,payload=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,params=ugUNxqatGsKWHeEzwcmijCQlIYXSkO,headers=ugUNxqatGsKWHeEzwcmijCQlIYXSOM,cookies=ugUNxqatGsKWHeEzwcmijCQlIYXSJR,redirects=ugUNxqatGsKWHeEzwcmijCQlIYXSOy)
   ugUNxqatGsKWHeEzwcmijCQlIYXSnR=json.loads(ugUNxqatGsKWHeEzwcmijCQlIYXSno.text)
   if ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']['code']!='000':
    ugUNxqatGsKWHeEzwcmijCQlIYXSkM['error_msg']=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['result']['message']
    return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
   ugUNxqatGsKWHeEzwcmijCQlIYXSko=ugUNxqatGsKWHeEzwcmijCQlIYXSnR['body']['stream']
   if ugUNxqatGsKWHeEzwcmijCQlIYXSko['drm_yn']=='Y':
    ugUNxqatGsKWHeEzwcmijCQlIYXSkh=ugUNxqatGsKWHeEzwcmijCQlIYXSko['playback']['drm']['widevine']
    for ugUNxqatGsKWHeEzwcmijCQlIYXSkL in ugUNxqatGsKWHeEzwcmijCQlIYXSko['playback']['drm']['license']['drm_license_data']:
     if ugUNxqatGsKWHeEzwcmijCQlIYXSkL['drm_type']=='Widevine':
      ugUNxqatGsKWHeEzwcmijCQlIYXSkM['drm_server_url'] =ugUNxqatGsKWHeEzwcmijCQlIYXSkL['drm_server_url']
      ugUNxqatGsKWHeEzwcmijCQlIYXSkM['drm_header_key'] =ugUNxqatGsKWHeEzwcmijCQlIYXSkL['drm_header_key']
      ugUNxqatGsKWHeEzwcmijCQlIYXSkM['drm_header_value']=ugUNxqatGsKWHeEzwcmijCQlIYXSkL['drm_header_value']
      break
   else:
    ugUNxqatGsKWHeEzwcmijCQlIYXSkh=ugUNxqatGsKWHeEzwcmijCQlIYXSko['playback']['non_drm']
  except ugUNxqatGsKWHeEzwcmijCQlIYXSOo as exception:
   ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(exception)
   ugUNxqatGsKWHeEzwcmijCQlIYXSkM['error_msg']='Second Step - except error'
   return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
  ugUNxqatGsKWHeEzwcmijCQlIYXSkT=ugUNxqatGsKWHeEzwcmijCQlIYXSky
  ugUNxqatGsKWHeEzwcmijCQlIYXSkh=ugUNxqatGsKWHeEzwcmijCQlIYXSkh.split('|')[1]
  ugUNxqatGsKWHeEzwcmijCQlIYXSkh=ugUNxqatGsKWHeEzwcmijCQlIYXSJy.Decrypt_Url(ugUNxqatGsKWHeEzwcmijCQlIYXSkh,mediacode,ugUNxqatGsKWHeEzwcmijCQlIYXSkT)
  ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url']=ugUNxqatGsKWHeEzwcmijCQlIYXSkh
  ugUNxqatGsKWHeEzwcmijCQlIYXSyD =ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url'].find('Policy=')
  if ugUNxqatGsKWHeEzwcmijCQlIYXSyD!=-1:
   ugUNxqatGsKWHeEzwcmijCQlIYXSyb =ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url'].split('?')[0]
   ugUNxqatGsKWHeEzwcmijCQlIYXSyf=ugUNxqatGsKWHeEzwcmijCQlIYXSOL(urllib.parse.parse_qsl(urllib.parse.urlsplit(ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url']).query))
   ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url']='{}&CloudFront-Policy={}'.format(ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url'],ugUNxqatGsKWHeEzwcmijCQlIYXSyf['Policy'])
   ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url']='{}&CloudFront-Signature={}'.format(ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url'],ugUNxqatGsKWHeEzwcmijCQlIYXSyf['Signature'])
   ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url'],ugUNxqatGsKWHeEzwcmijCQlIYXSyf['Key-Pair-Id'])
  ugUNxqatGsKWHeEzwcmijCQlIYXSyR=['_tving_token','accessToken','authToken',]
  for ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSJD in ugUNxqatGsKWHeEzwcmijCQlIYXSJR.items():
   if ugUNxqatGsKWHeEzwcmijCQlIYXSJp in ugUNxqatGsKWHeEzwcmijCQlIYXSyR:
    ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url']='{}&{}={}'.format(ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url'],ugUNxqatGsKWHeEzwcmijCQlIYXSJp,ugUNxqatGsKWHeEzwcmijCQlIYXSJD)
  ugUNxqatGsKWHeEzwcmijCQlIYXSOJ(ugUNxqatGsKWHeEzwcmijCQlIYXSkM['streaming_url'])
  return ugUNxqatGsKWHeEzwcmijCQlIYXSkM
# Created by pyminifier (https://github.com/liftoff/pyminifier)
