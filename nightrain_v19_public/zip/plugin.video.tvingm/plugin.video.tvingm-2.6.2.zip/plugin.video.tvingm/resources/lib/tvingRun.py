__author__="NightRain"
qVXMoWkeiuIScEJUGhwasOgArKQmCT=object
qVXMoWkeiuIScEJUGhwasOgArKQmCF=None
qVXMoWkeiuIScEJUGhwasOgArKQmCd=int
qVXMoWkeiuIScEJUGhwasOgArKQmCb=True
qVXMoWkeiuIScEJUGhwasOgArKQmCl=False
qVXMoWkeiuIScEJUGhwasOgArKQmDH=type
qVXMoWkeiuIScEJUGhwasOgArKQmDp=dict
qVXMoWkeiuIScEJUGhwasOgArKQmDt=getattr
qVXMoWkeiuIScEJUGhwasOgArKQmDY=list
qVXMoWkeiuIScEJUGhwasOgArKQmDP=len
qVXMoWkeiuIScEJUGhwasOgArKQmDB=str
qVXMoWkeiuIScEJUGhwasOgArKQmDn=range
qVXMoWkeiuIScEJUGhwasOgArKQmDC=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
qVXMoWkeiuIScEJUGhwasOgArKQmHt=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
qVXMoWkeiuIScEJUGhwasOgArKQmHY=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
qVXMoWkeiuIScEJUGhwasOgArKQmHP=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
qVXMoWkeiuIScEJUGhwasOgArKQmHB=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
qVXMoWkeiuIScEJUGhwasOgArKQmHn=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
qVXMoWkeiuIScEJUGhwasOgArKQmHC=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
qVXMoWkeiuIScEJUGhwasOgArKQmHD=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
qVXMoWkeiuIScEJUGhwasOgArKQmHy={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
qVXMoWkeiuIScEJUGhwasOgArKQmHv =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
qVXMoWkeiuIScEJUGhwasOgArKQmHf=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class qVXMoWkeiuIScEJUGhwasOgArKQmHp(qVXMoWkeiuIScEJUGhwasOgArKQmCT):
 def __init__(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmHx,qVXMoWkeiuIScEJUGhwasOgArKQmHz,qVXMoWkeiuIScEJUGhwasOgArKQmHN):
  qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_url =qVXMoWkeiuIScEJUGhwasOgArKQmHx
  qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle=qVXMoWkeiuIScEJUGhwasOgArKQmHz
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params =qVXMoWkeiuIScEJUGhwasOgArKQmHN
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj =ugUNxqatGsKWHeEzwcmijCQlIYXSJn() 
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(qVXMoWkeiuIScEJUGhwasOgArKQmHj,sting):
  try:
   qVXMoWkeiuIScEJUGhwasOgArKQmHL=xbmcgui.Dialog()
   qVXMoWkeiuIScEJUGhwasOgArKQmHL.notification(__addonname__,sting)
  except:
   qVXMoWkeiuIScEJUGhwasOgArKQmCF
 def addon_log(qVXMoWkeiuIScEJUGhwasOgArKQmHj,string):
  try:
   qVXMoWkeiuIScEJUGhwasOgArKQmHT=string.encode('utf-8','ignore')
  except:
   qVXMoWkeiuIScEJUGhwasOgArKQmHT='addonException: addon_log'
  qVXMoWkeiuIScEJUGhwasOgArKQmHF=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,qVXMoWkeiuIScEJUGhwasOgArKQmHT),level=qVXMoWkeiuIScEJUGhwasOgArKQmHF)
 def get_keyboard_input(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmpN):
  qVXMoWkeiuIScEJUGhwasOgArKQmHd=qVXMoWkeiuIScEJUGhwasOgArKQmCF
  kb=xbmc.Keyboard()
  kb.setHeading(qVXMoWkeiuIScEJUGhwasOgArKQmpN)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   qVXMoWkeiuIScEJUGhwasOgArKQmHd=kb.getText()
  return qVXMoWkeiuIScEJUGhwasOgArKQmHd
 def get_settings_account(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  qVXMoWkeiuIScEJUGhwasOgArKQmHb =__addon__.getSetting('id')
  qVXMoWkeiuIScEJUGhwasOgArKQmHl =__addon__.getSetting('pw')
  qVXMoWkeiuIScEJUGhwasOgArKQmpH =__addon__.getSetting('login_type')
  qVXMoWkeiuIScEJUGhwasOgArKQmpt=qVXMoWkeiuIScEJUGhwasOgArKQmCd(__addon__.getSetting('selected_profile'))
  return(qVXMoWkeiuIScEJUGhwasOgArKQmHb,qVXMoWkeiuIScEJUGhwasOgArKQmHl,qVXMoWkeiuIScEJUGhwasOgArKQmpH,qVXMoWkeiuIScEJUGhwasOgArKQmpt)
 def get_settings_uhd(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  return qVXMoWkeiuIScEJUGhwasOgArKQmCb if __addon__.getSetting('active_uhd')=='true' else qVXMoWkeiuIScEJUGhwasOgArKQmCl
 def get_settings_playback(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  qVXMoWkeiuIScEJUGhwasOgArKQmpY={'active_uhd':qVXMoWkeiuIScEJUGhwasOgArKQmCb if __addon__.getSetting('active_uhd')=='true' else qVXMoWkeiuIScEJUGhwasOgArKQmCl,'streamFilename':qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.TV_STREAM_FILENAME,}
  return qVXMoWkeiuIScEJUGhwasOgArKQmpY
 def get_settings_proxyport(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  qVXMoWkeiuIScEJUGhwasOgArKQmpP =qVXMoWkeiuIScEJUGhwasOgArKQmCb if __addon__.getSetting('proxyYn')=='true' else qVXMoWkeiuIScEJUGhwasOgArKQmCl
  qVXMoWkeiuIScEJUGhwasOgArKQmpB=qVXMoWkeiuIScEJUGhwasOgArKQmCd(__addon__.getSetting('proxyPort'))
  return qVXMoWkeiuIScEJUGhwasOgArKQmpP,qVXMoWkeiuIScEJUGhwasOgArKQmpB
 def get_settings_totalsearch(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  qVXMoWkeiuIScEJUGhwasOgArKQmpn =qVXMoWkeiuIScEJUGhwasOgArKQmCb if __addon__.getSetting('local_search')=='true' else qVXMoWkeiuIScEJUGhwasOgArKQmCl
  qVXMoWkeiuIScEJUGhwasOgArKQmpC=qVXMoWkeiuIScEJUGhwasOgArKQmCb if __addon__.getSetting('local_history')=='true' else qVXMoWkeiuIScEJUGhwasOgArKQmCl
  qVXMoWkeiuIScEJUGhwasOgArKQmpD =qVXMoWkeiuIScEJUGhwasOgArKQmCb if __addon__.getSetting('total_search')=='true' else qVXMoWkeiuIScEJUGhwasOgArKQmCl
  qVXMoWkeiuIScEJUGhwasOgArKQmpy=qVXMoWkeiuIScEJUGhwasOgArKQmCb if __addon__.getSetting('total_history')=='true' else qVXMoWkeiuIScEJUGhwasOgArKQmCl
  qVXMoWkeiuIScEJUGhwasOgArKQmpv=qVXMoWkeiuIScEJUGhwasOgArKQmCb if __addon__.getSetting('menu_bookmark')=='true' else qVXMoWkeiuIScEJUGhwasOgArKQmCl
  return(qVXMoWkeiuIScEJUGhwasOgArKQmpn,qVXMoWkeiuIScEJUGhwasOgArKQmpC,qVXMoWkeiuIScEJUGhwasOgArKQmpD,qVXMoWkeiuIScEJUGhwasOgArKQmpy,qVXMoWkeiuIScEJUGhwasOgArKQmpv)
 def get_settings_makebookmark(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  return qVXMoWkeiuIScEJUGhwasOgArKQmCb if __addon__.getSetting('make_bookmark')=='true' else qVXMoWkeiuIScEJUGhwasOgArKQmCl
 def get_settings_direct_replay(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  qVXMoWkeiuIScEJUGhwasOgArKQmpf=qVXMoWkeiuIScEJUGhwasOgArKQmCd(__addon__.getSetting('direct_replay'))
  if qVXMoWkeiuIScEJUGhwasOgArKQmpf==0:
   return qVXMoWkeiuIScEJUGhwasOgArKQmCl
  else:
   return qVXMoWkeiuIScEJUGhwasOgArKQmCb
 def set_winEpisodeOrderby(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmpx):
  __addon__.setSetting('tving_orderby',qVXMoWkeiuIScEJUGhwasOgArKQmpx)
  qVXMoWkeiuIScEJUGhwasOgArKQmpj=xbmcgui.Window(10000)
  qVXMoWkeiuIScEJUGhwasOgArKQmpj.setProperty('TVING_M_ORDERBY',qVXMoWkeiuIScEJUGhwasOgArKQmpx)
 def get_winEpisodeOrderby(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  qVXMoWkeiuIScEJUGhwasOgArKQmpx=__addon__.getSetting('tving_orderby')
  if qVXMoWkeiuIScEJUGhwasOgArKQmpx in['',qVXMoWkeiuIScEJUGhwasOgArKQmCF]:qVXMoWkeiuIScEJUGhwasOgArKQmpx='desc'
  return qVXMoWkeiuIScEJUGhwasOgArKQmpx
 def add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmHj,label,sublabel='',img='',infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmCF,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params='',isLink=qVXMoWkeiuIScEJUGhwasOgArKQmCl,ContextMenu=qVXMoWkeiuIScEJUGhwasOgArKQmCF):
  qVXMoWkeiuIScEJUGhwasOgArKQmpz='%s?%s'%(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_url,urllib.parse.urlencode(params))
  if sublabel:qVXMoWkeiuIScEJUGhwasOgArKQmpN='%s < %s >'%(label,sublabel)
  else: qVXMoWkeiuIScEJUGhwasOgArKQmpN=label
  if not img:img='DefaultFolder.png'
  qVXMoWkeiuIScEJUGhwasOgArKQmpR=xbmcgui.ListItem(qVXMoWkeiuIScEJUGhwasOgArKQmpN)
  if qVXMoWkeiuIScEJUGhwasOgArKQmDH(img)==qVXMoWkeiuIScEJUGhwasOgArKQmDp:
   qVXMoWkeiuIScEJUGhwasOgArKQmpR.setArt(img)
  else:
   qVXMoWkeiuIScEJUGhwasOgArKQmpR.setArt({'thumb':img,'poster':img})
  if qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.KodiVersion>=20:
   if infoLabels:qVXMoWkeiuIScEJUGhwasOgArKQmHj.Set_InfoTag(qVXMoWkeiuIScEJUGhwasOgArKQmpR.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:qVXMoWkeiuIScEJUGhwasOgArKQmpR.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   qVXMoWkeiuIScEJUGhwasOgArKQmpR.setProperty('IsPlayable','true')
  if ContextMenu:qVXMoWkeiuIScEJUGhwasOgArKQmpR.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,qVXMoWkeiuIScEJUGhwasOgArKQmpz,qVXMoWkeiuIScEJUGhwasOgArKQmpR,isFolder)
 def get_selQuality(qVXMoWkeiuIScEJUGhwasOgArKQmHj,etype):
  try:
   qVXMoWkeiuIScEJUGhwasOgArKQmpL='selected_quality'
   qVXMoWkeiuIScEJUGhwasOgArKQmpT=[1080,720,480,360]
   qVXMoWkeiuIScEJUGhwasOgArKQmpF=qVXMoWkeiuIScEJUGhwasOgArKQmCd(__addon__.getSetting(qVXMoWkeiuIScEJUGhwasOgArKQmpL))
   return qVXMoWkeiuIScEJUGhwasOgArKQmpT[qVXMoWkeiuIScEJUGhwasOgArKQmpF]
  except:
   qVXMoWkeiuIScEJUGhwasOgArKQmCF
  return 720 
 def Set_InfoTag(qVXMoWkeiuIScEJUGhwasOgArKQmHj,video_InfoTag:xbmc.InfoTagVideo,qVXMoWkeiuIScEJUGhwasOgArKQmtB):
  for qVXMoWkeiuIScEJUGhwasOgArKQmpd,value in qVXMoWkeiuIScEJUGhwasOgArKQmtB.items():
   if qVXMoWkeiuIScEJUGhwasOgArKQmHy[qVXMoWkeiuIScEJUGhwasOgArKQmpd]['type']=='string':
    qVXMoWkeiuIScEJUGhwasOgArKQmDt(video_InfoTag,qVXMoWkeiuIScEJUGhwasOgArKQmHy[qVXMoWkeiuIScEJUGhwasOgArKQmpd]['func'])(value)
   elif qVXMoWkeiuIScEJUGhwasOgArKQmHy[qVXMoWkeiuIScEJUGhwasOgArKQmpd]['type']=='int':
    if qVXMoWkeiuIScEJUGhwasOgArKQmDH(value)==qVXMoWkeiuIScEJUGhwasOgArKQmCd:
     qVXMoWkeiuIScEJUGhwasOgArKQmpb=qVXMoWkeiuIScEJUGhwasOgArKQmCd(value)
    else:
     qVXMoWkeiuIScEJUGhwasOgArKQmpb=0
    qVXMoWkeiuIScEJUGhwasOgArKQmDt(video_InfoTag,qVXMoWkeiuIScEJUGhwasOgArKQmHy[qVXMoWkeiuIScEJUGhwasOgArKQmpd]['func'])(qVXMoWkeiuIScEJUGhwasOgArKQmpb)
   elif qVXMoWkeiuIScEJUGhwasOgArKQmHy[qVXMoWkeiuIScEJUGhwasOgArKQmpd]['type']=='actor':
    if value!=[]:
     qVXMoWkeiuIScEJUGhwasOgArKQmDt(video_InfoTag,qVXMoWkeiuIScEJUGhwasOgArKQmHy[qVXMoWkeiuIScEJUGhwasOgArKQmpd]['func'])([xbmc.Actor(name)for name in value])
   elif qVXMoWkeiuIScEJUGhwasOgArKQmHy[qVXMoWkeiuIScEJUGhwasOgArKQmpd]['type']=='list':
    if qVXMoWkeiuIScEJUGhwasOgArKQmDH(value)==qVXMoWkeiuIScEJUGhwasOgArKQmDY:
     qVXMoWkeiuIScEJUGhwasOgArKQmDt(video_InfoTag,qVXMoWkeiuIScEJUGhwasOgArKQmHy[qVXMoWkeiuIScEJUGhwasOgArKQmpd]['func'])(value)
    else:
     qVXMoWkeiuIScEJUGhwasOgArKQmDt(video_InfoTag,qVXMoWkeiuIScEJUGhwasOgArKQmHy[qVXMoWkeiuIScEJUGhwasOgArKQmpd]['func'])([value])
 def dp_Main_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  (qVXMoWkeiuIScEJUGhwasOgArKQmpn,qVXMoWkeiuIScEJUGhwasOgArKQmpC,qVXMoWkeiuIScEJUGhwasOgArKQmpD,qVXMoWkeiuIScEJUGhwasOgArKQmpy,qVXMoWkeiuIScEJUGhwasOgArKQmpv)=qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_totalsearch()
  for qVXMoWkeiuIScEJUGhwasOgArKQmpl in qVXMoWkeiuIScEJUGhwasOgArKQmHt:
   qVXMoWkeiuIScEJUGhwasOgArKQmpN=qVXMoWkeiuIScEJUGhwasOgArKQmpl.get('title')
   qVXMoWkeiuIScEJUGhwasOgArKQmtH=''
   if qVXMoWkeiuIScEJUGhwasOgArKQmpl.get('mode')=='SEARCH_GROUP' and qVXMoWkeiuIScEJUGhwasOgArKQmpn ==qVXMoWkeiuIScEJUGhwasOgArKQmCl:continue
   elif qVXMoWkeiuIScEJUGhwasOgArKQmpl.get('mode')=='SEARCH_HISTORY' and qVXMoWkeiuIScEJUGhwasOgArKQmpC==qVXMoWkeiuIScEJUGhwasOgArKQmCl:continue
   elif qVXMoWkeiuIScEJUGhwasOgArKQmpl.get('mode')=='TOTAL_SEARCH' and qVXMoWkeiuIScEJUGhwasOgArKQmpD ==qVXMoWkeiuIScEJUGhwasOgArKQmCl:continue
   elif qVXMoWkeiuIScEJUGhwasOgArKQmpl.get('mode')=='TOTAL_HISTORY' and qVXMoWkeiuIScEJUGhwasOgArKQmpy==qVXMoWkeiuIScEJUGhwasOgArKQmCl:continue
   elif qVXMoWkeiuIScEJUGhwasOgArKQmpl.get('mode')=='MENU_BOOKMARK' and qVXMoWkeiuIScEJUGhwasOgArKQmpv==qVXMoWkeiuIScEJUGhwasOgArKQmCl:continue
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':qVXMoWkeiuIScEJUGhwasOgArKQmpl.get('mode'),'stype':qVXMoWkeiuIScEJUGhwasOgArKQmpl.get('stype'),'orderby':qVXMoWkeiuIScEJUGhwasOgArKQmpl.get('orderby'),'ordernm':qVXMoWkeiuIScEJUGhwasOgArKQmpl.get('ordernm'),'page':'1'}
   if qVXMoWkeiuIScEJUGhwasOgArKQmpl.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    qVXMoWkeiuIScEJUGhwasOgArKQmtY=qVXMoWkeiuIScEJUGhwasOgArKQmCl
    qVXMoWkeiuIScEJUGhwasOgArKQmtP =qVXMoWkeiuIScEJUGhwasOgArKQmCb
   else:
    qVXMoWkeiuIScEJUGhwasOgArKQmtY=qVXMoWkeiuIScEJUGhwasOgArKQmCb
    qVXMoWkeiuIScEJUGhwasOgArKQmtP =qVXMoWkeiuIScEJUGhwasOgArKQmCl
   qVXMoWkeiuIScEJUGhwasOgArKQmtB={'title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'plot':qVXMoWkeiuIScEJUGhwasOgArKQmpN}
   if qVXMoWkeiuIScEJUGhwasOgArKQmpl.get('mode')=='XXX':qVXMoWkeiuIScEJUGhwasOgArKQmtB=qVXMoWkeiuIScEJUGhwasOgArKQmCF
   if 'icon' in qVXMoWkeiuIScEJUGhwasOgArKQmpl:qVXMoWkeiuIScEJUGhwasOgArKQmtH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',qVXMoWkeiuIScEJUGhwasOgArKQmpl.get('icon')) 
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel='',img=qVXMoWkeiuIScEJUGhwasOgArKQmtH,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmtB,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmtY,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp,isLink=qVXMoWkeiuIScEJUGhwasOgArKQmtP)
  xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle)
 def login_main(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  (qVXMoWkeiuIScEJUGhwasOgArKQmtC,qVXMoWkeiuIScEJUGhwasOgArKQmtD,qVXMoWkeiuIScEJUGhwasOgArKQmty,qVXMoWkeiuIScEJUGhwasOgArKQmtv)=qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_account()
  if not(qVXMoWkeiuIScEJUGhwasOgArKQmtC and qVXMoWkeiuIScEJUGhwasOgArKQmtD):
   qVXMoWkeiuIScEJUGhwasOgArKQmHL=xbmcgui.Dialog()
   qVXMoWkeiuIScEJUGhwasOgArKQmtf=qVXMoWkeiuIScEJUGhwasOgArKQmHL.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if qVXMoWkeiuIScEJUGhwasOgArKQmtf==qVXMoWkeiuIScEJUGhwasOgArKQmCb:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if qVXMoWkeiuIScEJUGhwasOgArKQmHj.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   qVXMoWkeiuIScEJUGhwasOgArKQmtj=0
   while qVXMoWkeiuIScEJUGhwasOgArKQmCb:
    qVXMoWkeiuIScEJUGhwasOgArKQmtj+=1
    time.sleep(0.05)
    if qVXMoWkeiuIScEJUGhwasOgArKQmtj>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  qVXMoWkeiuIScEJUGhwasOgArKQmtx=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.GetCredential(qVXMoWkeiuIScEJUGhwasOgArKQmtC,qVXMoWkeiuIScEJUGhwasOgArKQmtD,qVXMoWkeiuIScEJUGhwasOgArKQmty,qVXMoWkeiuIScEJUGhwasOgArKQmtv)
  if qVXMoWkeiuIScEJUGhwasOgArKQmtx:qVXMoWkeiuIScEJUGhwasOgArKQmHj.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if qVXMoWkeiuIScEJUGhwasOgArKQmtx==qVXMoWkeiuIScEJUGhwasOgArKQmCl:
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmtz=qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('stype')
  if qVXMoWkeiuIScEJUGhwasOgArKQmtz=='live':
   qVXMoWkeiuIScEJUGhwasOgArKQmtN=qVXMoWkeiuIScEJUGhwasOgArKQmHY
  elif qVXMoWkeiuIScEJUGhwasOgArKQmtz=='vod':
   qVXMoWkeiuIScEJUGhwasOgArKQmtN=qVXMoWkeiuIScEJUGhwasOgArKQmHn
  else:
   qVXMoWkeiuIScEJUGhwasOgArKQmtN=qVXMoWkeiuIScEJUGhwasOgArKQmHC
  for qVXMoWkeiuIScEJUGhwasOgArKQmtR in qVXMoWkeiuIScEJUGhwasOgArKQmtN:
   qVXMoWkeiuIScEJUGhwasOgArKQmpN=qVXMoWkeiuIScEJUGhwasOgArKQmtR.get('title')
   if qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('ordernm')!='-':
    qVXMoWkeiuIScEJUGhwasOgArKQmpN+='  ('+qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('ordernm')+')'
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':qVXMoWkeiuIScEJUGhwasOgArKQmtR.get('mode'),'stype':qVXMoWkeiuIScEJUGhwasOgArKQmtR.get('stype'),'orderby':qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('orderby'),'ordernm':qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('ordernm'),'page':'1'}
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel='',img='',infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmCF,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  if qVXMoWkeiuIScEJUGhwasOgArKQmDP(qVXMoWkeiuIScEJUGhwasOgArKQmtN)>0:xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle)
 def dp_SubTitle_Group(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL): 
  for qVXMoWkeiuIScEJUGhwasOgArKQmtR in qVXMoWkeiuIScEJUGhwasOgArKQmHD:
   qVXMoWkeiuIScEJUGhwasOgArKQmpN=qVXMoWkeiuIScEJUGhwasOgArKQmtR.get('title')
   if qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('ordernm')!='-':
    qVXMoWkeiuIScEJUGhwasOgArKQmpN+='  ('+qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('ordernm')+')'
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':qVXMoWkeiuIScEJUGhwasOgArKQmtR.get('mode'),'genreCode':qVXMoWkeiuIScEJUGhwasOgArKQmtR.get('genreCode'),'stype':qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('stype'),'orderby':qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('orderby'),'page':'1'}
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel='',img='',infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmCF,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  if qVXMoWkeiuIScEJUGhwasOgArKQmDP(qVXMoWkeiuIScEJUGhwasOgArKQmHD)>0:xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle)
 def dp_LiveChannel_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmtz =qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('stype')
  qVXMoWkeiuIScEJUGhwasOgArKQmtT =qVXMoWkeiuIScEJUGhwasOgArKQmCd(qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('page'))
  qVXMoWkeiuIScEJUGhwasOgArKQmtF,qVXMoWkeiuIScEJUGhwasOgArKQmtd=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.GetLiveChannelList(qVXMoWkeiuIScEJUGhwasOgArKQmtz,qVXMoWkeiuIScEJUGhwasOgArKQmtT)
  for qVXMoWkeiuIScEJUGhwasOgArKQmtb in qVXMoWkeiuIScEJUGhwasOgArKQmtF:
   qVXMoWkeiuIScEJUGhwasOgArKQmpN =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('title')
   qVXMoWkeiuIScEJUGhwasOgArKQmtn =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('channel')
   qVXMoWkeiuIScEJUGhwasOgArKQmtl =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('thumbnail')
   qVXMoWkeiuIScEJUGhwasOgArKQmYH =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('synopsis')
   qVXMoWkeiuIScEJUGhwasOgArKQmYp =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('channelepg')
   qVXMoWkeiuIScEJUGhwasOgArKQmYt =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('cast')
   qVXMoWkeiuIScEJUGhwasOgArKQmYP =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('director')
   qVXMoWkeiuIScEJUGhwasOgArKQmYB =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('info_genre')
   qVXMoWkeiuIScEJUGhwasOgArKQmYn =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('year')
   qVXMoWkeiuIScEJUGhwasOgArKQmYC =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('mpaa')
   qVXMoWkeiuIScEJUGhwasOgArKQmYD =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('premiered')
   qVXMoWkeiuIScEJUGhwasOgArKQmYy={'mediatype':'episode','title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'studio':qVXMoWkeiuIScEJUGhwasOgArKQmtn,'cast':qVXMoWkeiuIScEJUGhwasOgArKQmYt,'director':qVXMoWkeiuIScEJUGhwasOgArKQmYP,'genre':qVXMoWkeiuIScEJUGhwasOgArKQmYB,'plot':'%s\n%s\n%s\n\n%s'%(qVXMoWkeiuIScEJUGhwasOgArKQmtn,qVXMoWkeiuIScEJUGhwasOgArKQmpN,qVXMoWkeiuIScEJUGhwasOgArKQmYp,qVXMoWkeiuIScEJUGhwasOgArKQmYH),'year':qVXMoWkeiuIScEJUGhwasOgArKQmYn,'mpaa':qVXMoWkeiuIScEJUGhwasOgArKQmYC,'premiered':qVXMoWkeiuIScEJUGhwasOgArKQmYD}
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'LIVE','mediacode':qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('mediacode'),'stype':qVXMoWkeiuIScEJUGhwasOgArKQmtz}
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmtn,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmpN,img=qVXMoWkeiuIScEJUGhwasOgArKQmtl,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmYy,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCl,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  if qVXMoWkeiuIScEJUGhwasOgArKQmtd:
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['mode']='CHANNEL' 
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['stype']=qVXMoWkeiuIScEJUGhwasOgArKQmtz 
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['page']=qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmpN='[B]%s >>[/B]'%'다음 페이지'
   qVXMoWkeiuIScEJUGhwasOgArKQmYv=qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmtH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmYv,img=qVXMoWkeiuIScEJUGhwasOgArKQmtH,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmCF,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  if qVXMoWkeiuIScEJUGhwasOgArKQmDP(qVXMoWkeiuIScEJUGhwasOgArKQmtF)>0:xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,cacheToDisc=qVXMoWkeiuIScEJUGhwasOgArKQmCl)
 def dp_Program_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmYf =qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('stype')
  qVXMoWkeiuIScEJUGhwasOgArKQmpx =qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('orderby')
  qVXMoWkeiuIScEJUGhwasOgArKQmtT =qVXMoWkeiuIScEJUGhwasOgArKQmCd(qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('page'))
  qVXMoWkeiuIScEJUGhwasOgArKQmYj=qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('genreCode')
  if qVXMoWkeiuIScEJUGhwasOgArKQmYj==qVXMoWkeiuIScEJUGhwasOgArKQmCF:qVXMoWkeiuIScEJUGhwasOgArKQmYj='all'
  qVXMoWkeiuIScEJUGhwasOgArKQmYx,qVXMoWkeiuIScEJUGhwasOgArKQmtd=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.GetProgramList(qVXMoWkeiuIScEJUGhwasOgArKQmYf,qVXMoWkeiuIScEJUGhwasOgArKQmpx,qVXMoWkeiuIScEJUGhwasOgArKQmtT,qVXMoWkeiuIScEJUGhwasOgArKQmYj)
  for qVXMoWkeiuIScEJUGhwasOgArKQmYz in qVXMoWkeiuIScEJUGhwasOgArKQmYx:
   qVXMoWkeiuIScEJUGhwasOgArKQmpN =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('title')
   qVXMoWkeiuIScEJUGhwasOgArKQmtl =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('thumbnail')
   qVXMoWkeiuIScEJUGhwasOgArKQmYH =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('synopsis')
   qVXMoWkeiuIScEJUGhwasOgArKQmYN =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('channel')
   qVXMoWkeiuIScEJUGhwasOgArKQmYt =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('cast')
   qVXMoWkeiuIScEJUGhwasOgArKQmYP =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('director')
   qVXMoWkeiuIScEJUGhwasOgArKQmYB=qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('info_genre')
   qVXMoWkeiuIScEJUGhwasOgArKQmYn =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('year')
   qVXMoWkeiuIScEJUGhwasOgArKQmYD =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('premiered')
   qVXMoWkeiuIScEJUGhwasOgArKQmYC =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('mpaa')
   qVXMoWkeiuIScEJUGhwasOgArKQmYy={'mediatype':'tvshow','title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'studio':qVXMoWkeiuIScEJUGhwasOgArKQmYN,'cast':qVXMoWkeiuIScEJUGhwasOgArKQmYt,'director':qVXMoWkeiuIScEJUGhwasOgArKQmYP,'genre':qVXMoWkeiuIScEJUGhwasOgArKQmYB,'year':qVXMoWkeiuIScEJUGhwasOgArKQmYn,'premiered':qVXMoWkeiuIScEJUGhwasOgArKQmYD,'mpaa':qVXMoWkeiuIScEJUGhwasOgArKQmYC,'plot':qVXMoWkeiuIScEJUGhwasOgArKQmYH}
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'EPISODE','programcode':qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('program'),'page':'1'}
   if qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_makebookmark():
    qVXMoWkeiuIScEJUGhwasOgArKQmYR={'videoid':qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('program'),'vidtype':'tvshow','vtitle':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'vsubtitle':qVXMoWkeiuIScEJUGhwasOgArKQmYN,}
    qVXMoWkeiuIScEJUGhwasOgArKQmYL=json.dumps(qVXMoWkeiuIScEJUGhwasOgArKQmYR)
    qVXMoWkeiuIScEJUGhwasOgArKQmYL=urllib.parse.quote(qVXMoWkeiuIScEJUGhwasOgArKQmYL)
    qVXMoWkeiuIScEJUGhwasOgArKQmYT='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(qVXMoWkeiuIScEJUGhwasOgArKQmYL)
    qVXMoWkeiuIScEJUGhwasOgArKQmYF=[('(통합) 찜 영상에 추가',qVXMoWkeiuIScEJUGhwasOgArKQmYT)]
   else:
    qVXMoWkeiuIScEJUGhwasOgArKQmYF=qVXMoWkeiuIScEJUGhwasOgArKQmCF
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmYN,img=qVXMoWkeiuIScEJUGhwasOgArKQmtl,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmYy,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp,ContextMenu=qVXMoWkeiuIScEJUGhwasOgArKQmYF)
  if qVXMoWkeiuIScEJUGhwasOgArKQmtd:
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['mode'] ='PROGRAM' 
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['stype'] =qVXMoWkeiuIScEJUGhwasOgArKQmYf
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['orderby'] =qVXMoWkeiuIScEJUGhwasOgArKQmpx
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['page'] =qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['genreCode']=qVXMoWkeiuIScEJUGhwasOgArKQmYj 
   qVXMoWkeiuIScEJUGhwasOgArKQmpN='[B]%s >>[/B]'%'다음 페이지'
   qVXMoWkeiuIScEJUGhwasOgArKQmYv=qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmtH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmYv,img=qVXMoWkeiuIScEJUGhwasOgArKQmtH,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmCF,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  xbmcplugin.setContent(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,cacheToDisc=qVXMoWkeiuIScEJUGhwasOgArKQmCl)
 def dp_4K_Program_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmtT =qVXMoWkeiuIScEJUGhwasOgArKQmCd(qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('page'))
  qVXMoWkeiuIScEJUGhwasOgArKQmYx,qVXMoWkeiuIScEJUGhwasOgArKQmtd=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Get_UHD_ProgramList(qVXMoWkeiuIScEJUGhwasOgArKQmtT)
  for qVXMoWkeiuIScEJUGhwasOgArKQmYz in qVXMoWkeiuIScEJUGhwasOgArKQmYx:
   qVXMoWkeiuIScEJUGhwasOgArKQmpN =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('title')
   qVXMoWkeiuIScEJUGhwasOgArKQmtl =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('thumbnail')
   qVXMoWkeiuIScEJUGhwasOgArKQmYH =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('synopsis')
   qVXMoWkeiuIScEJUGhwasOgArKQmYN =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('channel')
   qVXMoWkeiuIScEJUGhwasOgArKQmYt =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('cast')
   qVXMoWkeiuIScEJUGhwasOgArKQmYP =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('director')
   qVXMoWkeiuIScEJUGhwasOgArKQmYB=qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('info_genre')
   qVXMoWkeiuIScEJUGhwasOgArKQmYn =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('year')
   qVXMoWkeiuIScEJUGhwasOgArKQmYD =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('premiered')
   qVXMoWkeiuIScEJUGhwasOgArKQmYC =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('mpaa')
   qVXMoWkeiuIScEJUGhwasOgArKQmYy={'mediatype':'tvshow','title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'studio':qVXMoWkeiuIScEJUGhwasOgArKQmYN,'cast':qVXMoWkeiuIScEJUGhwasOgArKQmYt,'director':qVXMoWkeiuIScEJUGhwasOgArKQmYP,'genre':qVXMoWkeiuIScEJUGhwasOgArKQmYB,'year':qVXMoWkeiuIScEJUGhwasOgArKQmYn,'premiered':qVXMoWkeiuIScEJUGhwasOgArKQmYD,'mpaa':qVXMoWkeiuIScEJUGhwasOgArKQmYC,'plot':qVXMoWkeiuIScEJUGhwasOgArKQmYH}
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'EPISODE','programcode':qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('program'),'page':'1'}
   if qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_makebookmark():
    qVXMoWkeiuIScEJUGhwasOgArKQmYR={'videoid':qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('program'),'vidtype':'tvshow','vtitle':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'vsubtitle':qVXMoWkeiuIScEJUGhwasOgArKQmYN,}
    qVXMoWkeiuIScEJUGhwasOgArKQmYL=json.dumps(qVXMoWkeiuIScEJUGhwasOgArKQmYR)
    qVXMoWkeiuIScEJUGhwasOgArKQmYL=urllib.parse.quote(qVXMoWkeiuIScEJUGhwasOgArKQmYL)
    qVXMoWkeiuIScEJUGhwasOgArKQmYT='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(qVXMoWkeiuIScEJUGhwasOgArKQmYL)
    qVXMoWkeiuIScEJUGhwasOgArKQmYF=[('(통합) 찜 영상에 추가',qVXMoWkeiuIScEJUGhwasOgArKQmYT)]
   else:
    qVXMoWkeiuIScEJUGhwasOgArKQmYF=qVXMoWkeiuIScEJUGhwasOgArKQmCF
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmYN,img=qVXMoWkeiuIScEJUGhwasOgArKQmtl,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmYy,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp,ContextMenu=qVXMoWkeiuIScEJUGhwasOgArKQmYF)
  if qVXMoWkeiuIScEJUGhwasOgArKQmtd:
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['mode'] ='4K_PROGRAM' 
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['page'] =qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmpN='[B]%s >>[/B]'%'다음 페이지'
   qVXMoWkeiuIScEJUGhwasOgArKQmYv=qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmtH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmYv,img=qVXMoWkeiuIScEJUGhwasOgArKQmtH,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmCF,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  xbmcplugin.setContent(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,cacheToDisc=qVXMoWkeiuIScEJUGhwasOgArKQmCl)
 def dp_Ori_Program_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmtT =qVXMoWkeiuIScEJUGhwasOgArKQmCd(qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('page'))
  qVXMoWkeiuIScEJUGhwasOgArKQmYx,qVXMoWkeiuIScEJUGhwasOgArKQmtd=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Get_Origianl_ProgramList(qVXMoWkeiuIScEJUGhwasOgArKQmtT)
  for qVXMoWkeiuIScEJUGhwasOgArKQmYz in qVXMoWkeiuIScEJUGhwasOgArKQmYx:
   qVXMoWkeiuIScEJUGhwasOgArKQmpN =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('title')
   qVXMoWkeiuIScEJUGhwasOgArKQmtl =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('thumbnail')
   qVXMoWkeiuIScEJUGhwasOgArKQmYb =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('vod_type')
   qVXMoWkeiuIScEJUGhwasOgArKQmYl =qVXMoWkeiuIScEJUGhwasOgArKQmYz.get('vod_code')
   if qVXMoWkeiuIScEJUGhwasOgArKQmYb=='vod':
    qVXMoWkeiuIScEJUGhwasOgArKQmYy={'mediatype':'tvshow','title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,}
    qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'EPISODE','programcode':qVXMoWkeiuIScEJUGhwasOgArKQmYl,'page':'1',}
    qVXMoWkeiuIScEJUGhwasOgArKQmtY=qVXMoWkeiuIScEJUGhwasOgArKQmCb
   else:
    qVXMoWkeiuIScEJUGhwasOgArKQmYy={'mediatype':'movie','title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'plot':'movie',}
    qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'MOVIE','mediacode':qVXMoWkeiuIScEJUGhwasOgArKQmYl,'stype':'movie','title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'thumbnail':qVXMoWkeiuIScEJUGhwasOgArKQmtl,}
    qVXMoWkeiuIScEJUGhwasOgArKQmtY=qVXMoWkeiuIScEJUGhwasOgArKQmCl
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmCF,img=qVXMoWkeiuIScEJUGhwasOgArKQmtl,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmYy,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmtY,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp,ContextMenu=qVXMoWkeiuIScEJUGhwasOgArKQmCF)
  if qVXMoWkeiuIScEJUGhwasOgArKQmtd:
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['mode'] ='ORI_PROGRAM' 
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['page'] =qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmpN='[B]%s >>[/B]'%'다음 페이지'
   qVXMoWkeiuIScEJUGhwasOgArKQmYv=qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmtH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmYv,img=qVXMoWkeiuIScEJUGhwasOgArKQmtH,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmCF,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  xbmcplugin.setContent(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,cacheToDisc=qVXMoWkeiuIScEJUGhwasOgArKQmCl)
 def dp_Episode_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmPH=qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('programcode')
  qVXMoWkeiuIScEJUGhwasOgArKQmtT =qVXMoWkeiuIScEJUGhwasOgArKQmCd(qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('page'))
  qVXMoWkeiuIScEJUGhwasOgArKQmPp,qVXMoWkeiuIScEJUGhwasOgArKQmtd,qVXMoWkeiuIScEJUGhwasOgArKQmPt=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.GetEpisodeList(qVXMoWkeiuIScEJUGhwasOgArKQmPH,qVXMoWkeiuIScEJUGhwasOgArKQmtT,orderby=qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_winEpisodeOrderby())
  for qVXMoWkeiuIScEJUGhwasOgArKQmPY in qVXMoWkeiuIScEJUGhwasOgArKQmPp:
   qVXMoWkeiuIScEJUGhwasOgArKQmpN =qVXMoWkeiuIScEJUGhwasOgArKQmPY.get('title')
   qVXMoWkeiuIScEJUGhwasOgArKQmYv =qVXMoWkeiuIScEJUGhwasOgArKQmPY.get('subtitle')
   qVXMoWkeiuIScEJUGhwasOgArKQmtl =qVXMoWkeiuIScEJUGhwasOgArKQmPY.get('thumbnail')
   qVXMoWkeiuIScEJUGhwasOgArKQmYH =qVXMoWkeiuIScEJUGhwasOgArKQmPY.get('synopsis')
   qVXMoWkeiuIScEJUGhwasOgArKQmPB=qVXMoWkeiuIScEJUGhwasOgArKQmPY.get('info_title')
   qVXMoWkeiuIScEJUGhwasOgArKQmPn =qVXMoWkeiuIScEJUGhwasOgArKQmPY.get('aired')
   qVXMoWkeiuIScEJUGhwasOgArKQmPC =qVXMoWkeiuIScEJUGhwasOgArKQmPY.get('studio')
   qVXMoWkeiuIScEJUGhwasOgArKQmPD =qVXMoWkeiuIScEJUGhwasOgArKQmPY.get('frequency')
   qVXMoWkeiuIScEJUGhwasOgArKQmYy={'mediatype':'episode','title':qVXMoWkeiuIScEJUGhwasOgArKQmPB,'aired':qVXMoWkeiuIScEJUGhwasOgArKQmPn,'studio':qVXMoWkeiuIScEJUGhwasOgArKQmPC,'episode':qVXMoWkeiuIScEJUGhwasOgArKQmPD,'plot':qVXMoWkeiuIScEJUGhwasOgArKQmYH}
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'VOD','mediacode':qVXMoWkeiuIScEJUGhwasOgArKQmPY.get('episode'),'stype':'vod','programcode':qVXMoWkeiuIScEJUGhwasOgArKQmPH,'title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'thumbnail':qVXMoWkeiuIScEJUGhwasOgArKQmtl}
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmYv,img=qVXMoWkeiuIScEJUGhwasOgArKQmtl,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmYy,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCl,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  if qVXMoWkeiuIScEJUGhwasOgArKQmtT==1:
   qVXMoWkeiuIScEJUGhwasOgArKQmYy={'plot':'정렬순서를 변경합니다.'}
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={}
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['mode'] ='ORDER_BY' 
   if qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_winEpisodeOrderby()=='desc':
    qVXMoWkeiuIScEJUGhwasOgArKQmpN='정렬순서변경 : 최신화부터 -> 1회부터'
    qVXMoWkeiuIScEJUGhwasOgArKQmtp['orderby']='asc'
   else:
    qVXMoWkeiuIScEJUGhwasOgArKQmpN='정렬순서변경 : 1회부터 -> 최신화부터'
    qVXMoWkeiuIScEJUGhwasOgArKQmtp['orderby']='desc'
   qVXMoWkeiuIScEJUGhwasOgArKQmtH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel='',img=qVXMoWkeiuIScEJUGhwasOgArKQmtH,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmYy,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCl,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp,isLink=qVXMoWkeiuIScEJUGhwasOgArKQmCb)
  if qVXMoWkeiuIScEJUGhwasOgArKQmtd:
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['mode'] ='EPISODE' 
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['programcode']=qVXMoWkeiuIScEJUGhwasOgArKQmPH
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['page'] =qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmpN='[B]%s >>[/B]'%'다음 페이지'
   qVXMoWkeiuIScEJUGhwasOgArKQmYv=qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmtH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmYv,img=qVXMoWkeiuIScEJUGhwasOgArKQmtH,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmCF,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  xbmcplugin.setContent(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,'episodes')
  if qVXMoWkeiuIScEJUGhwasOgArKQmDP(qVXMoWkeiuIScEJUGhwasOgArKQmPp)>0:xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,cacheToDisc=qVXMoWkeiuIScEJUGhwasOgArKQmCb)
 def dp_setEpOrderby(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmpx =qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('orderby')
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.set_winEpisodeOrderby(qVXMoWkeiuIScEJUGhwasOgArKQmpx)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmYf =qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('stype')
  qVXMoWkeiuIScEJUGhwasOgArKQmpx =qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('orderby')
  qVXMoWkeiuIScEJUGhwasOgArKQmtT=qVXMoWkeiuIScEJUGhwasOgArKQmCd(qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('page'))
  qVXMoWkeiuIScEJUGhwasOgArKQmPy,qVXMoWkeiuIScEJUGhwasOgArKQmtd=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.GetMovieList(qVXMoWkeiuIScEJUGhwasOgArKQmYf,qVXMoWkeiuIScEJUGhwasOgArKQmpx,qVXMoWkeiuIScEJUGhwasOgArKQmtT)
  for qVXMoWkeiuIScEJUGhwasOgArKQmPv in qVXMoWkeiuIScEJUGhwasOgArKQmPy:
   qVXMoWkeiuIScEJUGhwasOgArKQmpN =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('title')
   qVXMoWkeiuIScEJUGhwasOgArKQmtl =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('thumbnail')
   qVXMoWkeiuIScEJUGhwasOgArKQmYH =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('synopsis')
   qVXMoWkeiuIScEJUGhwasOgArKQmPB =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('info_title')
   qVXMoWkeiuIScEJUGhwasOgArKQmYn =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('year')
   qVXMoWkeiuIScEJUGhwasOgArKQmYt =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('cast')
   qVXMoWkeiuIScEJUGhwasOgArKQmYP =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('director')
   qVXMoWkeiuIScEJUGhwasOgArKQmYB =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('info_genre')
   qVXMoWkeiuIScEJUGhwasOgArKQmPf =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('duration')
   qVXMoWkeiuIScEJUGhwasOgArKQmYD =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('premiered')
   qVXMoWkeiuIScEJUGhwasOgArKQmPC =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('studio')
   qVXMoWkeiuIScEJUGhwasOgArKQmYC =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('mpaa')
   qVXMoWkeiuIScEJUGhwasOgArKQmYy={'mediatype':'movie','title':qVXMoWkeiuIScEJUGhwasOgArKQmPB,'year':qVXMoWkeiuIScEJUGhwasOgArKQmYn,'cast':qVXMoWkeiuIScEJUGhwasOgArKQmYt,'director':qVXMoWkeiuIScEJUGhwasOgArKQmYP,'genre':qVXMoWkeiuIScEJUGhwasOgArKQmYB,'duration':qVXMoWkeiuIScEJUGhwasOgArKQmPf,'premiered':qVXMoWkeiuIScEJUGhwasOgArKQmYD,'studio':qVXMoWkeiuIScEJUGhwasOgArKQmPC,'mpaa':qVXMoWkeiuIScEJUGhwasOgArKQmYC,'plot':qVXMoWkeiuIScEJUGhwasOgArKQmYH}
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'MOVIE','mediacode':qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('moviecode'),'stype':'movie','title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'thumbnail':qVXMoWkeiuIScEJUGhwasOgArKQmtl}
   if qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_makebookmark():
    qVXMoWkeiuIScEJUGhwasOgArKQmYR={'videoid':qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('moviecode'),'vidtype':'movie','vtitle':qVXMoWkeiuIScEJUGhwasOgArKQmPB,'vsubtitle':'',}
    qVXMoWkeiuIScEJUGhwasOgArKQmYL=json.dumps(qVXMoWkeiuIScEJUGhwasOgArKQmYR)
    qVXMoWkeiuIScEJUGhwasOgArKQmYL=urllib.parse.quote(qVXMoWkeiuIScEJUGhwasOgArKQmYL)
    qVXMoWkeiuIScEJUGhwasOgArKQmYT='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(qVXMoWkeiuIScEJUGhwasOgArKQmYL)
    qVXMoWkeiuIScEJUGhwasOgArKQmYF=[('(통합) 찜 영상에 추가',qVXMoWkeiuIScEJUGhwasOgArKQmYT)]
   else:
    qVXMoWkeiuIScEJUGhwasOgArKQmYF=qVXMoWkeiuIScEJUGhwasOgArKQmCF
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel='',img=qVXMoWkeiuIScEJUGhwasOgArKQmtl,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmYy,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCl,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp,ContextMenu=qVXMoWkeiuIScEJUGhwasOgArKQmYF)
  if qVXMoWkeiuIScEJUGhwasOgArKQmtd:
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={}
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['mode'] ='MOVIE_SUB' 
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['orderby']=qVXMoWkeiuIScEJUGhwasOgArKQmpx
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['stype'] =qVXMoWkeiuIScEJUGhwasOgArKQmYf
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['page'] =qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmpN='[B]%s >>[/B]'%'다음 페이지'
   qVXMoWkeiuIScEJUGhwasOgArKQmYv=qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmtH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmYv,img=qVXMoWkeiuIScEJUGhwasOgArKQmtH,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmCF,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  xbmcplugin.setContent(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,'movies')
  xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,cacheToDisc=qVXMoWkeiuIScEJUGhwasOgArKQmCl)
 def dp_4K_Movie_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmtT=qVXMoWkeiuIScEJUGhwasOgArKQmCd(qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('page'))
  qVXMoWkeiuIScEJUGhwasOgArKQmPy,qVXMoWkeiuIScEJUGhwasOgArKQmtd=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Get_UHD_MovieList(qVXMoWkeiuIScEJUGhwasOgArKQmtT)
  for qVXMoWkeiuIScEJUGhwasOgArKQmPv in qVXMoWkeiuIScEJUGhwasOgArKQmPy:
   qVXMoWkeiuIScEJUGhwasOgArKQmpN =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('title')
   qVXMoWkeiuIScEJUGhwasOgArKQmtl =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('thumbnail')
   qVXMoWkeiuIScEJUGhwasOgArKQmYH =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('synopsis')
   qVXMoWkeiuIScEJUGhwasOgArKQmPB =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('info_title')
   qVXMoWkeiuIScEJUGhwasOgArKQmYn =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('year')
   qVXMoWkeiuIScEJUGhwasOgArKQmYt =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('cast')
   qVXMoWkeiuIScEJUGhwasOgArKQmYP =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('director')
   qVXMoWkeiuIScEJUGhwasOgArKQmYB =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('info_genre')
   qVXMoWkeiuIScEJUGhwasOgArKQmPf =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('duration')
   qVXMoWkeiuIScEJUGhwasOgArKQmYD =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('premiered')
   qVXMoWkeiuIScEJUGhwasOgArKQmPC =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('studio')
   qVXMoWkeiuIScEJUGhwasOgArKQmYC =qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('mpaa')
   qVXMoWkeiuIScEJUGhwasOgArKQmYy={'mediatype':'movie','title':qVXMoWkeiuIScEJUGhwasOgArKQmPB,'year':qVXMoWkeiuIScEJUGhwasOgArKQmYn,'cast':qVXMoWkeiuIScEJUGhwasOgArKQmYt,'director':qVXMoWkeiuIScEJUGhwasOgArKQmYP,'genre':qVXMoWkeiuIScEJUGhwasOgArKQmYB,'duration':qVXMoWkeiuIScEJUGhwasOgArKQmPf,'premiered':qVXMoWkeiuIScEJUGhwasOgArKQmYD,'studio':qVXMoWkeiuIScEJUGhwasOgArKQmPC,'mpaa':qVXMoWkeiuIScEJUGhwasOgArKQmYC,'plot':qVXMoWkeiuIScEJUGhwasOgArKQmYH}
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'MOVIE','mediacode':qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('moviecode'),'stype':'movie','title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'thumbnail':qVXMoWkeiuIScEJUGhwasOgArKQmtl}
   if qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_makebookmark():
    qVXMoWkeiuIScEJUGhwasOgArKQmYR={'videoid':qVXMoWkeiuIScEJUGhwasOgArKQmPv.get('moviecode'),'vidtype':'movie','vtitle':qVXMoWkeiuIScEJUGhwasOgArKQmPB,'vsubtitle':'',}
    qVXMoWkeiuIScEJUGhwasOgArKQmYL=json.dumps(qVXMoWkeiuIScEJUGhwasOgArKQmYR)
    qVXMoWkeiuIScEJUGhwasOgArKQmYL=urllib.parse.quote(qVXMoWkeiuIScEJUGhwasOgArKQmYL)
    qVXMoWkeiuIScEJUGhwasOgArKQmYT='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(qVXMoWkeiuIScEJUGhwasOgArKQmYL)
    qVXMoWkeiuIScEJUGhwasOgArKQmYF=[('(통합) 찜 영상에 추가',qVXMoWkeiuIScEJUGhwasOgArKQmYT)]
   else:
    qVXMoWkeiuIScEJUGhwasOgArKQmYF=qVXMoWkeiuIScEJUGhwasOgArKQmCF
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel='',img=qVXMoWkeiuIScEJUGhwasOgArKQmtl,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmYy,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCl,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp,ContextMenu=qVXMoWkeiuIScEJUGhwasOgArKQmYF)
  if qVXMoWkeiuIScEJUGhwasOgArKQmtd:
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={}
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['mode'] ='4K_MOVIE' 
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['page'] =qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmpN='[B]%s >>[/B]'%'다음 페이지'
   qVXMoWkeiuIScEJUGhwasOgArKQmYv=qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmtH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmYv,img=qVXMoWkeiuIScEJUGhwasOgArKQmtH,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmCF,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  xbmcplugin.setContent(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,'movies')
  xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,cacheToDisc=qVXMoWkeiuIScEJUGhwasOgArKQmCl)
 def dp_Set_Bookmark(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmPj=urllib.parse.unquote(qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('bm_param'))
  qVXMoWkeiuIScEJUGhwasOgArKQmPj=json.loads(qVXMoWkeiuIScEJUGhwasOgArKQmPj)
  qVXMoWkeiuIScEJUGhwasOgArKQmPx =qVXMoWkeiuIScEJUGhwasOgArKQmPj.get('videoid')
  qVXMoWkeiuIScEJUGhwasOgArKQmPz =qVXMoWkeiuIScEJUGhwasOgArKQmPj.get('vidtype')
  qVXMoWkeiuIScEJUGhwasOgArKQmPN =qVXMoWkeiuIScEJUGhwasOgArKQmPj.get('vtitle')
  qVXMoWkeiuIScEJUGhwasOgArKQmPR =qVXMoWkeiuIScEJUGhwasOgArKQmPj.get('vsubtitle')
  qVXMoWkeiuIScEJUGhwasOgArKQmHL=xbmcgui.Dialog()
  qVXMoWkeiuIScEJUGhwasOgArKQmtf=qVXMoWkeiuIScEJUGhwasOgArKQmHL.yesno(__language__(30913).encode('utf8'),qVXMoWkeiuIScEJUGhwasOgArKQmPN+' \n\n'+__language__(30914))
  if qVXMoWkeiuIScEJUGhwasOgArKQmtf==qVXMoWkeiuIScEJUGhwasOgArKQmCl:return
  qVXMoWkeiuIScEJUGhwasOgArKQmPL=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.GetBookmarkInfo(qVXMoWkeiuIScEJUGhwasOgArKQmPx,qVXMoWkeiuIScEJUGhwasOgArKQmPz)
  if qVXMoWkeiuIScEJUGhwasOgArKQmPR!='':
   qVXMoWkeiuIScEJUGhwasOgArKQmPL['saveinfo']['subtitle']=qVXMoWkeiuIScEJUGhwasOgArKQmPR 
   if qVXMoWkeiuIScEJUGhwasOgArKQmPz=='tvshow':qVXMoWkeiuIScEJUGhwasOgArKQmPL['saveinfo']['infoLabels']['studio']=qVXMoWkeiuIScEJUGhwasOgArKQmPR 
  qVXMoWkeiuIScEJUGhwasOgArKQmPT=json.dumps(qVXMoWkeiuIScEJUGhwasOgArKQmPL)
  qVXMoWkeiuIScEJUGhwasOgArKQmPT=urllib.parse.quote(qVXMoWkeiuIScEJUGhwasOgArKQmPT)
  qVXMoWkeiuIScEJUGhwasOgArKQmYT ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(qVXMoWkeiuIScEJUGhwasOgArKQmPT)
  xbmc.executebuiltin(qVXMoWkeiuIScEJUGhwasOgArKQmYT)
 def dp_Search_Group(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  if 'search_key' in qVXMoWkeiuIScEJUGhwasOgArKQmtL:
   qVXMoWkeiuIScEJUGhwasOgArKQmPF=qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('search_key')
  else:
   qVXMoWkeiuIScEJUGhwasOgArKQmPF=qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not qVXMoWkeiuIScEJUGhwasOgArKQmPF:
    return
  for qVXMoWkeiuIScEJUGhwasOgArKQmtR in qVXMoWkeiuIScEJUGhwasOgArKQmHB:
   qVXMoWkeiuIScEJUGhwasOgArKQmPd =qVXMoWkeiuIScEJUGhwasOgArKQmtR.get('mode')
   qVXMoWkeiuIScEJUGhwasOgArKQmtz=qVXMoWkeiuIScEJUGhwasOgArKQmtR.get('stype')
   qVXMoWkeiuIScEJUGhwasOgArKQmpN=qVXMoWkeiuIScEJUGhwasOgArKQmtR.get('title')
   (qVXMoWkeiuIScEJUGhwasOgArKQmPb,qVXMoWkeiuIScEJUGhwasOgArKQmtd)=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.GetSearchList(qVXMoWkeiuIScEJUGhwasOgArKQmPF,1,qVXMoWkeiuIScEJUGhwasOgArKQmtz)
   qVXMoWkeiuIScEJUGhwasOgArKQmtB={'plot':'검색어 : '+qVXMoWkeiuIScEJUGhwasOgArKQmPF+'\n\n'+qVXMoWkeiuIScEJUGhwasOgArKQmHj.Search_FreeList(qVXMoWkeiuIScEJUGhwasOgArKQmPb)}
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':qVXMoWkeiuIScEJUGhwasOgArKQmPd,'stype':qVXMoWkeiuIScEJUGhwasOgArKQmtz,'search_key':qVXMoWkeiuIScEJUGhwasOgArKQmPF,'page':'1',}
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel='',img='',infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmtB,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  if qVXMoWkeiuIScEJUGhwasOgArKQmDP(qVXMoWkeiuIScEJUGhwasOgArKQmHB)>0:xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,cacheToDisc=qVXMoWkeiuIScEJUGhwasOgArKQmCb)
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.Save_Searched_List(qVXMoWkeiuIScEJUGhwasOgArKQmPF)
 def Search_FreeList(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmBD):
  qVXMoWkeiuIScEJUGhwasOgArKQmPl=''
  qVXMoWkeiuIScEJUGhwasOgArKQmBH=7
  try:
   if qVXMoWkeiuIScEJUGhwasOgArKQmDP(qVXMoWkeiuIScEJUGhwasOgArKQmBD)==0:return '검색결과 없음'
   for i in qVXMoWkeiuIScEJUGhwasOgArKQmDn(qVXMoWkeiuIScEJUGhwasOgArKQmDP(qVXMoWkeiuIScEJUGhwasOgArKQmBD)):
    if i>=qVXMoWkeiuIScEJUGhwasOgArKQmBH:
     qVXMoWkeiuIScEJUGhwasOgArKQmPl=qVXMoWkeiuIScEJUGhwasOgArKQmPl+'...'
     break
    qVXMoWkeiuIScEJUGhwasOgArKQmPl=qVXMoWkeiuIScEJUGhwasOgArKQmPl+qVXMoWkeiuIScEJUGhwasOgArKQmBD[i]['title']+'\n'
  except:
   return ''
  return qVXMoWkeiuIScEJUGhwasOgArKQmPl
 def dp_Search_History(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmBp=qVXMoWkeiuIScEJUGhwasOgArKQmHj.Load_List_File('search')
  for qVXMoWkeiuIScEJUGhwasOgArKQmBt in qVXMoWkeiuIScEJUGhwasOgArKQmBp:
   qVXMoWkeiuIScEJUGhwasOgArKQmBY=qVXMoWkeiuIScEJUGhwasOgArKQmDp(urllib.parse.parse_qsl(qVXMoWkeiuIScEJUGhwasOgArKQmBt))
   qVXMoWkeiuIScEJUGhwasOgArKQmBP=qVXMoWkeiuIScEJUGhwasOgArKQmBY.get('skey').strip()
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'SEARCH_GROUP','search_key':qVXMoWkeiuIScEJUGhwasOgArKQmBP,}
   qVXMoWkeiuIScEJUGhwasOgArKQmBn={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':qVXMoWkeiuIScEJUGhwasOgArKQmBP,'vType':'-',}
   qVXMoWkeiuIScEJUGhwasOgArKQmBC=urllib.parse.urlencode(qVXMoWkeiuIScEJUGhwasOgArKQmBn)
   qVXMoWkeiuIScEJUGhwasOgArKQmYF=[('선택된 검색어 ( %s ) 삭제'%(qVXMoWkeiuIScEJUGhwasOgArKQmBP),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(qVXMoWkeiuIScEJUGhwasOgArKQmBC))]
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmBP,sublabel='',img=qVXMoWkeiuIScEJUGhwasOgArKQmCF,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmCF,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp,ContextMenu=qVXMoWkeiuIScEJUGhwasOgArKQmYF)
  qVXMoWkeiuIScEJUGhwasOgArKQmYy={'plot':'검색목록 전체를 삭제합니다.'}
  qVXMoWkeiuIScEJUGhwasOgArKQmpN='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  qVXMoWkeiuIScEJUGhwasOgArKQmtH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel='',img=qVXMoWkeiuIScEJUGhwasOgArKQmtH,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmYy,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCl,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp,isLink=qVXMoWkeiuIScEJUGhwasOgArKQmCb)
  xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,cacheToDisc=qVXMoWkeiuIScEJUGhwasOgArKQmCl)
 def dp_Search_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmtT =qVXMoWkeiuIScEJUGhwasOgArKQmCd(qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('page'))
  qVXMoWkeiuIScEJUGhwasOgArKQmtz =qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('stype')
  if 'search_key' in qVXMoWkeiuIScEJUGhwasOgArKQmtL:
   qVXMoWkeiuIScEJUGhwasOgArKQmPF=qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('search_key')
  else:
   qVXMoWkeiuIScEJUGhwasOgArKQmPF=qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not qVXMoWkeiuIScEJUGhwasOgArKQmPF:
    xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle)
    return
  qVXMoWkeiuIScEJUGhwasOgArKQmPb,qVXMoWkeiuIScEJUGhwasOgArKQmtd=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.GetSearchList(qVXMoWkeiuIScEJUGhwasOgArKQmPF,qVXMoWkeiuIScEJUGhwasOgArKQmtT,qVXMoWkeiuIScEJUGhwasOgArKQmtz)
  for qVXMoWkeiuIScEJUGhwasOgArKQmBD in qVXMoWkeiuIScEJUGhwasOgArKQmPb:
   qVXMoWkeiuIScEJUGhwasOgArKQmpN =qVXMoWkeiuIScEJUGhwasOgArKQmBD.get('title')
   qVXMoWkeiuIScEJUGhwasOgArKQmtl =qVXMoWkeiuIScEJUGhwasOgArKQmBD.get('thumbnail')
   qVXMoWkeiuIScEJUGhwasOgArKQmYH =qVXMoWkeiuIScEJUGhwasOgArKQmBD.get('synopsis')
   qVXMoWkeiuIScEJUGhwasOgArKQmBy =qVXMoWkeiuIScEJUGhwasOgArKQmBD.get('program')
   qVXMoWkeiuIScEJUGhwasOgArKQmYt =qVXMoWkeiuIScEJUGhwasOgArKQmBD.get('cast')
   qVXMoWkeiuIScEJUGhwasOgArKQmYP =qVXMoWkeiuIScEJUGhwasOgArKQmBD.get('director')
   qVXMoWkeiuIScEJUGhwasOgArKQmYB=qVXMoWkeiuIScEJUGhwasOgArKQmBD.get('info_genre')
   qVXMoWkeiuIScEJUGhwasOgArKQmPf =qVXMoWkeiuIScEJUGhwasOgArKQmBD.get('duration')
   qVXMoWkeiuIScEJUGhwasOgArKQmYC =qVXMoWkeiuIScEJUGhwasOgArKQmBD.get('mpaa')
   qVXMoWkeiuIScEJUGhwasOgArKQmYn =qVXMoWkeiuIScEJUGhwasOgArKQmBD.get('year')
   qVXMoWkeiuIScEJUGhwasOgArKQmPn =qVXMoWkeiuIScEJUGhwasOgArKQmBD.get('aired')
   qVXMoWkeiuIScEJUGhwasOgArKQmYy={'mediatype':'tvshow' if qVXMoWkeiuIScEJUGhwasOgArKQmtz=='vod' else 'movie','title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'cast':qVXMoWkeiuIScEJUGhwasOgArKQmYt,'director':qVXMoWkeiuIScEJUGhwasOgArKQmYP,'genre':qVXMoWkeiuIScEJUGhwasOgArKQmYB,'duration':qVXMoWkeiuIScEJUGhwasOgArKQmPf,'mpaa':qVXMoWkeiuIScEJUGhwasOgArKQmYC,'year':qVXMoWkeiuIScEJUGhwasOgArKQmYn,'aired':qVXMoWkeiuIScEJUGhwasOgArKQmPn,'plot':'%s\n\n%s'%(qVXMoWkeiuIScEJUGhwasOgArKQmpN,qVXMoWkeiuIScEJUGhwasOgArKQmYH)}
   if qVXMoWkeiuIScEJUGhwasOgArKQmtz=='vod':
    qVXMoWkeiuIScEJUGhwasOgArKQmPx=qVXMoWkeiuIScEJUGhwasOgArKQmBD.get('program')
    qVXMoWkeiuIScEJUGhwasOgArKQmPz='tvshow'
    qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'EPISODE','programcode':qVXMoWkeiuIScEJUGhwasOgArKQmPx,'page':'1',}
    qVXMoWkeiuIScEJUGhwasOgArKQmtY=qVXMoWkeiuIScEJUGhwasOgArKQmCb
   else:
    qVXMoWkeiuIScEJUGhwasOgArKQmPx=qVXMoWkeiuIScEJUGhwasOgArKQmBD.get('movie')
    qVXMoWkeiuIScEJUGhwasOgArKQmPz='movie'
    qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'MOVIE','mediacode':qVXMoWkeiuIScEJUGhwasOgArKQmPx,'stype':'movie','title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'thumbnail':qVXMoWkeiuIScEJUGhwasOgArKQmtl,}
    qVXMoWkeiuIScEJUGhwasOgArKQmtY=qVXMoWkeiuIScEJUGhwasOgArKQmCl
   if qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_makebookmark():
    qVXMoWkeiuIScEJUGhwasOgArKQmYR={'videoid':qVXMoWkeiuIScEJUGhwasOgArKQmPx,'vidtype':qVXMoWkeiuIScEJUGhwasOgArKQmPz,'vtitle':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'vsubtitle':'',}
    qVXMoWkeiuIScEJUGhwasOgArKQmYL=json.dumps(qVXMoWkeiuIScEJUGhwasOgArKQmYR)
    qVXMoWkeiuIScEJUGhwasOgArKQmYL=urllib.parse.quote(qVXMoWkeiuIScEJUGhwasOgArKQmYL)
    qVXMoWkeiuIScEJUGhwasOgArKQmYT='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(qVXMoWkeiuIScEJUGhwasOgArKQmYL)
    qVXMoWkeiuIScEJUGhwasOgArKQmYF=[('(통합) 찜 영상에 추가',qVXMoWkeiuIScEJUGhwasOgArKQmYT)]
   else:
    qVXMoWkeiuIScEJUGhwasOgArKQmYF=qVXMoWkeiuIScEJUGhwasOgArKQmCF
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel='',img=qVXMoWkeiuIScEJUGhwasOgArKQmtl,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmYy,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmtY,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp,isLink=qVXMoWkeiuIScEJUGhwasOgArKQmCl,ContextMenu=qVXMoWkeiuIScEJUGhwasOgArKQmYF)
  if qVXMoWkeiuIScEJUGhwasOgArKQmtd:
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['mode'] ='SEARCH' 
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['search_key']=qVXMoWkeiuIScEJUGhwasOgArKQmPF
   qVXMoWkeiuIScEJUGhwasOgArKQmtp['page'] =qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmpN='[B]%s >>[/B]'%'다음 페이지'
   qVXMoWkeiuIScEJUGhwasOgArKQmYv=qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmtT+1)
   qVXMoWkeiuIScEJUGhwasOgArKQmtH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmYv,img=qVXMoWkeiuIScEJUGhwasOgArKQmtH,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmCF,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  if qVXMoWkeiuIScEJUGhwasOgArKQmtz=='movie':xbmcplugin.setContent(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,'movies')
  else:xbmcplugin.setContent(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,cacheToDisc=qVXMoWkeiuIScEJUGhwasOgArKQmCl)
 def dp_History_Remove(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmBv=qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('delType')
  qVXMoWkeiuIScEJUGhwasOgArKQmBf =qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('sKey')
  qVXMoWkeiuIScEJUGhwasOgArKQmBj =qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('vType')
  qVXMoWkeiuIScEJUGhwasOgArKQmHL=xbmcgui.Dialog()
  if qVXMoWkeiuIScEJUGhwasOgArKQmBv=='SEARCH_ALL':
   qVXMoWkeiuIScEJUGhwasOgArKQmtf=qVXMoWkeiuIScEJUGhwasOgArKQmHL.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif qVXMoWkeiuIScEJUGhwasOgArKQmBv=='SEARCH_ONE':
   qVXMoWkeiuIScEJUGhwasOgArKQmtf=qVXMoWkeiuIScEJUGhwasOgArKQmHL.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif qVXMoWkeiuIScEJUGhwasOgArKQmBv=='WATCH_ALL':
   qVXMoWkeiuIScEJUGhwasOgArKQmtf=qVXMoWkeiuIScEJUGhwasOgArKQmHL.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif qVXMoWkeiuIScEJUGhwasOgArKQmBv=='WATCH_ONE':
   qVXMoWkeiuIScEJUGhwasOgArKQmtf=qVXMoWkeiuIScEJUGhwasOgArKQmHL.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if qVXMoWkeiuIScEJUGhwasOgArKQmtf==qVXMoWkeiuIScEJUGhwasOgArKQmCl:sys.exit()
  if qVXMoWkeiuIScEJUGhwasOgArKQmBv=='SEARCH_ALL':
   if os.path.isfile(qVXMoWkeiuIScEJUGhwasOgArKQmHf):os.remove(qVXMoWkeiuIScEJUGhwasOgArKQmHf)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmBv=='SEARCH_ONE':
   try:
    qVXMoWkeiuIScEJUGhwasOgArKQmBx=qVXMoWkeiuIScEJUGhwasOgArKQmHf
    qVXMoWkeiuIScEJUGhwasOgArKQmBz=qVXMoWkeiuIScEJUGhwasOgArKQmHj.Load_List_File('search') 
    fp=qVXMoWkeiuIScEJUGhwasOgArKQmDC(qVXMoWkeiuIScEJUGhwasOgArKQmBx,'w',-1,'utf-8')
    for qVXMoWkeiuIScEJUGhwasOgArKQmBN in qVXMoWkeiuIScEJUGhwasOgArKQmBz:
     qVXMoWkeiuIScEJUGhwasOgArKQmBR=qVXMoWkeiuIScEJUGhwasOgArKQmDp(urllib.parse.parse_qsl(qVXMoWkeiuIScEJUGhwasOgArKQmBN))
     qVXMoWkeiuIScEJUGhwasOgArKQmBL=qVXMoWkeiuIScEJUGhwasOgArKQmBR.get('skey').strip()
     if qVXMoWkeiuIScEJUGhwasOgArKQmBf!=qVXMoWkeiuIScEJUGhwasOgArKQmBL:
      fp.write(qVXMoWkeiuIScEJUGhwasOgArKQmBN)
    fp.close()
   except:
    qVXMoWkeiuIScEJUGhwasOgArKQmCF
  elif qVXMoWkeiuIScEJUGhwasOgArKQmBv=='WATCH_ALL':
   qVXMoWkeiuIScEJUGhwasOgArKQmBx=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qVXMoWkeiuIScEJUGhwasOgArKQmBj))
   if os.path.isfile(qVXMoWkeiuIScEJUGhwasOgArKQmBx):os.remove(qVXMoWkeiuIScEJUGhwasOgArKQmBx)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmBv=='WATCH_ONE':
   qVXMoWkeiuIScEJUGhwasOgArKQmBx=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qVXMoWkeiuIScEJUGhwasOgArKQmBj))
   try:
    qVXMoWkeiuIScEJUGhwasOgArKQmBz=qVXMoWkeiuIScEJUGhwasOgArKQmHj.Load_List_File(qVXMoWkeiuIScEJUGhwasOgArKQmBj) 
    fp=qVXMoWkeiuIScEJUGhwasOgArKQmDC(qVXMoWkeiuIScEJUGhwasOgArKQmBx,'w',-1,'utf-8')
    for qVXMoWkeiuIScEJUGhwasOgArKQmBN in qVXMoWkeiuIScEJUGhwasOgArKQmBz:
     qVXMoWkeiuIScEJUGhwasOgArKQmBR=qVXMoWkeiuIScEJUGhwasOgArKQmDp(urllib.parse.parse_qsl(qVXMoWkeiuIScEJUGhwasOgArKQmBN))
     qVXMoWkeiuIScEJUGhwasOgArKQmBL=qVXMoWkeiuIScEJUGhwasOgArKQmBR.get('code').strip()
     if qVXMoWkeiuIScEJUGhwasOgArKQmBf!=qVXMoWkeiuIScEJUGhwasOgArKQmBL:
      fp.write(qVXMoWkeiuIScEJUGhwasOgArKQmBN)
    fp.close()
   except:
    qVXMoWkeiuIScEJUGhwasOgArKQmCF
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtz): 
  try:
   if qVXMoWkeiuIScEJUGhwasOgArKQmtz=='search':
    qVXMoWkeiuIScEJUGhwasOgArKQmBx=qVXMoWkeiuIScEJUGhwasOgArKQmHf
   elif qVXMoWkeiuIScEJUGhwasOgArKQmtz in['vod','movie']:
    qVXMoWkeiuIScEJUGhwasOgArKQmBx=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qVXMoWkeiuIScEJUGhwasOgArKQmtz))
   else:
    return[]
   fp=qVXMoWkeiuIScEJUGhwasOgArKQmDC(qVXMoWkeiuIScEJUGhwasOgArKQmBx,'r',-1,'utf-8')
   qVXMoWkeiuIScEJUGhwasOgArKQmBT=fp.readlines()
   fp.close()
  except:
   qVXMoWkeiuIScEJUGhwasOgArKQmBT=[]
  return qVXMoWkeiuIScEJUGhwasOgArKQmBT
 def Save_Watched_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtz,qVXMoWkeiuIScEJUGhwasOgArKQmHN):
  try:
   qVXMoWkeiuIScEJUGhwasOgArKQmBF=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%qVXMoWkeiuIScEJUGhwasOgArKQmtz))
   qVXMoWkeiuIScEJUGhwasOgArKQmBz=qVXMoWkeiuIScEJUGhwasOgArKQmHj.Load_List_File(qVXMoWkeiuIScEJUGhwasOgArKQmtz) 
   fp=qVXMoWkeiuIScEJUGhwasOgArKQmDC(qVXMoWkeiuIScEJUGhwasOgArKQmBF,'w',-1,'utf-8')
   qVXMoWkeiuIScEJUGhwasOgArKQmBd=urllib.parse.urlencode(qVXMoWkeiuIScEJUGhwasOgArKQmHN)
   qVXMoWkeiuIScEJUGhwasOgArKQmBd=qVXMoWkeiuIScEJUGhwasOgArKQmBd+'\n'
   fp.write(qVXMoWkeiuIScEJUGhwasOgArKQmBd)
   qVXMoWkeiuIScEJUGhwasOgArKQmBb=0
   for qVXMoWkeiuIScEJUGhwasOgArKQmBN in qVXMoWkeiuIScEJUGhwasOgArKQmBz:
    qVXMoWkeiuIScEJUGhwasOgArKQmBR=qVXMoWkeiuIScEJUGhwasOgArKQmDp(urllib.parse.parse_qsl(qVXMoWkeiuIScEJUGhwasOgArKQmBN))
    qVXMoWkeiuIScEJUGhwasOgArKQmBl=qVXMoWkeiuIScEJUGhwasOgArKQmHN.get('code').strip()
    qVXMoWkeiuIScEJUGhwasOgArKQmnH=qVXMoWkeiuIScEJUGhwasOgArKQmBR.get('code').strip()
    if qVXMoWkeiuIScEJUGhwasOgArKQmtz=='vod' and qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_direct_replay()==qVXMoWkeiuIScEJUGhwasOgArKQmCb:
     qVXMoWkeiuIScEJUGhwasOgArKQmBl=qVXMoWkeiuIScEJUGhwasOgArKQmHN.get('videoid').strip()
     qVXMoWkeiuIScEJUGhwasOgArKQmnH=qVXMoWkeiuIScEJUGhwasOgArKQmBR.get('videoid').strip()if qVXMoWkeiuIScEJUGhwasOgArKQmnH!=qVXMoWkeiuIScEJUGhwasOgArKQmCF else '-'
    if qVXMoWkeiuIScEJUGhwasOgArKQmBl!=qVXMoWkeiuIScEJUGhwasOgArKQmnH:
     fp.write(qVXMoWkeiuIScEJUGhwasOgArKQmBN)
     qVXMoWkeiuIScEJUGhwasOgArKQmBb+=1
     if qVXMoWkeiuIScEJUGhwasOgArKQmBb>=50:break
   fp.close()
  except:
   qVXMoWkeiuIScEJUGhwasOgArKQmCF
 def dp_Watch_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmtz =qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('stype')
  qVXMoWkeiuIScEJUGhwasOgArKQmpf=qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_direct_replay()
  if qVXMoWkeiuIScEJUGhwasOgArKQmtz=='-':
   for qVXMoWkeiuIScEJUGhwasOgArKQmtR in qVXMoWkeiuIScEJUGhwasOgArKQmHP:
    qVXMoWkeiuIScEJUGhwasOgArKQmpN=qVXMoWkeiuIScEJUGhwasOgArKQmtR.get('title')
    qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':qVXMoWkeiuIScEJUGhwasOgArKQmtR.get('mode'),'stype':qVXMoWkeiuIScEJUGhwasOgArKQmtR.get('stype')}
    qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel='',img='',infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmCF,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCb,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
   if qVXMoWkeiuIScEJUGhwasOgArKQmDP(qVXMoWkeiuIScEJUGhwasOgArKQmHP)>0:xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle)
  else:
   qVXMoWkeiuIScEJUGhwasOgArKQmnp=qVXMoWkeiuIScEJUGhwasOgArKQmHj.Load_List_File(qVXMoWkeiuIScEJUGhwasOgArKQmtz)
   for qVXMoWkeiuIScEJUGhwasOgArKQmnt in qVXMoWkeiuIScEJUGhwasOgArKQmnp:
    qVXMoWkeiuIScEJUGhwasOgArKQmBY=qVXMoWkeiuIScEJUGhwasOgArKQmDp(urllib.parse.parse_qsl(qVXMoWkeiuIScEJUGhwasOgArKQmnt))
    qVXMoWkeiuIScEJUGhwasOgArKQmnY =qVXMoWkeiuIScEJUGhwasOgArKQmBY.get('code').strip()
    qVXMoWkeiuIScEJUGhwasOgArKQmpN =qVXMoWkeiuIScEJUGhwasOgArKQmBY.get('title').strip()
    qVXMoWkeiuIScEJUGhwasOgArKQmtl=qVXMoWkeiuIScEJUGhwasOgArKQmBY.get('img').strip()
    qVXMoWkeiuIScEJUGhwasOgArKQmPx =qVXMoWkeiuIScEJUGhwasOgArKQmBY.get('videoid').strip()
    try:
     qVXMoWkeiuIScEJUGhwasOgArKQmtl=qVXMoWkeiuIScEJUGhwasOgArKQmtl.replace('\'','\"')
     qVXMoWkeiuIScEJUGhwasOgArKQmtl=json.loads(qVXMoWkeiuIScEJUGhwasOgArKQmtl)
    except:
     qVXMoWkeiuIScEJUGhwasOgArKQmCF
    qVXMoWkeiuIScEJUGhwasOgArKQmYy={}
    qVXMoWkeiuIScEJUGhwasOgArKQmYy['plot']=qVXMoWkeiuIScEJUGhwasOgArKQmpN
    if qVXMoWkeiuIScEJUGhwasOgArKQmtz=='vod':
     if qVXMoWkeiuIScEJUGhwasOgArKQmpf==qVXMoWkeiuIScEJUGhwasOgArKQmCl or qVXMoWkeiuIScEJUGhwasOgArKQmPx==qVXMoWkeiuIScEJUGhwasOgArKQmCF:
      qVXMoWkeiuIScEJUGhwasOgArKQmYy['mediatype']='tvshow'
      qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'EPISODE','programcode':qVXMoWkeiuIScEJUGhwasOgArKQmnY,'page':'1'}
      qVXMoWkeiuIScEJUGhwasOgArKQmtY=qVXMoWkeiuIScEJUGhwasOgArKQmCb
     else:
      qVXMoWkeiuIScEJUGhwasOgArKQmYy['mediatype']='episode'
      qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'VOD','mediacode':qVXMoWkeiuIScEJUGhwasOgArKQmPx,'stype':'vod','programcode':qVXMoWkeiuIScEJUGhwasOgArKQmnY,'title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'thumbnail':qVXMoWkeiuIScEJUGhwasOgArKQmtl}
      qVXMoWkeiuIScEJUGhwasOgArKQmtY=qVXMoWkeiuIScEJUGhwasOgArKQmCl
    else:
     qVXMoWkeiuIScEJUGhwasOgArKQmYy['mediatype']='movie'
     qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'MOVIE','mediacode':qVXMoWkeiuIScEJUGhwasOgArKQmnY,'stype':'movie','title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'thumbnail':qVXMoWkeiuIScEJUGhwasOgArKQmtl}
     qVXMoWkeiuIScEJUGhwasOgArKQmtY=qVXMoWkeiuIScEJUGhwasOgArKQmCl
    qVXMoWkeiuIScEJUGhwasOgArKQmBn={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':qVXMoWkeiuIScEJUGhwasOgArKQmnY,'vType':qVXMoWkeiuIScEJUGhwasOgArKQmtz,}
    qVXMoWkeiuIScEJUGhwasOgArKQmBC=urllib.parse.urlencode(qVXMoWkeiuIScEJUGhwasOgArKQmBn)
    qVXMoWkeiuIScEJUGhwasOgArKQmYF=[('선택된 시청이력 ( %s ) 삭제'%(qVXMoWkeiuIScEJUGhwasOgArKQmpN),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(qVXMoWkeiuIScEJUGhwasOgArKQmBC))]
    qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel='',img=qVXMoWkeiuIScEJUGhwasOgArKQmtl,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmYy,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmtY,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp,ContextMenu=qVXMoWkeiuIScEJUGhwasOgArKQmYF)
   qVXMoWkeiuIScEJUGhwasOgArKQmYy={'plot':'시청목록을 삭제합니다.'}
   qVXMoWkeiuIScEJUGhwasOgArKQmpN='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':qVXMoWkeiuIScEJUGhwasOgArKQmtz,}
   qVXMoWkeiuIScEJUGhwasOgArKQmtH=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel='',img=qVXMoWkeiuIScEJUGhwasOgArKQmtH,infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmYy,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCl,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp,isLink=qVXMoWkeiuIScEJUGhwasOgArKQmCb)
   if qVXMoWkeiuIScEJUGhwasOgArKQmtz=='movie':xbmcplugin.setContent(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,'movies')
   else:xbmcplugin.setContent(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,cacheToDisc=qVXMoWkeiuIScEJUGhwasOgArKQmCl)
 def Save_Searched_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmPF):
  try:
   qVXMoWkeiuIScEJUGhwasOgArKQmnP=qVXMoWkeiuIScEJUGhwasOgArKQmHf
   qVXMoWkeiuIScEJUGhwasOgArKQmBz=qVXMoWkeiuIScEJUGhwasOgArKQmHj.Load_List_File('search') 
   qVXMoWkeiuIScEJUGhwasOgArKQmnB={'skey':qVXMoWkeiuIScEJUGhwasOgArKQmPF.strip()}
   fp=qVXMoWkeiuIScEJUGhwasOgArKQmDC(qVXMoWkeiuIScEJUGhwasOgArKQmnP,'w',-1,'utf-8')
   qVXMoWkeiuIScEJUGhwasOgArKQmBd=urllib.parse.urlencode(qVXMoWkeiuIScEJUGhwasOgArKQmnB)
   qVXMoWkeiuIScEJUGhwasOgArKQmBd=qVXMoWkeiuIScEJUGhwasOgArKQmBd+'\n'
   fp.write(qVXMoWkeiuIScEJUGhwasOgArKQmBd)
   qVXMoWkeiuIScEJUGhwasOgArKQmBb=0
   for qVXMoWkeiuIScEJUGhwasOgArKQmBN in qVXMoWkeiuIScEJUGhwasOgArKQmBz:
    qVXMoWkeiuIScEJUGhwasOgArKQmBR=qVXMoWkeiuIScEJUGhwasOgArKQmDp(urllib.parse.parse_qsl(qVXMoWkeiuIScEJUGhwasOgArKQmBN))
    qVXMoWkeiuIScEJUGhwasOgArKQmBl=qVXMoWkeiuIScEJUGhwasOgArKQmnB.get('skey').strip()
    qVXMoWkeiuIScEJUGhwasOgArKQmnH=qVXMoWkeiuIScEJUGhwasOgArKQmBR.get('skey').strip()
    if qVXMoWkeiuIScEJUGhwasOgArKQmBl!=qVXMoWkeiuIScEJUGhwasOgArKQmnH:
     fp.write(qVXMoWkeiuIScEJUGhwasOgArKQmBN)
     qVXMoWkeiuIScEJUGhwasOgArKQmBb+=1
     if qVXMoWkeiuIScEJUGhwasOgArKQmBb>=50:break
   fp.close()
  except:
   qVXMoWkeiuIScEJUGhwasOgArKQmCF
 def play_VIDEO(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmnC =qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('mediacode')
  qVXMoWkeiuIScEJUGhwasOgArKQmtz =qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('stype')
  qVXMoWkeiuIScEJUGhwasOgArKQmnD =qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('pvrmode')
  qVXMoWkeiuIScEJUGhwasOgArKQmny=qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_selQuality(qVXMoWkeiuIScEJUGhwasOgArKQmtz)
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(qVXMoWkeiuIScEJUGhwasOgArKQmnC,qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmny),qVXMoWkeiuIScEJUGhwasOgArKQmtz,qVXMoWkeiuIScEJUGhwasOgArKQmnD))
  qVXMoWkeiuIScEJUGhwasOgArKQmnv=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.GetBroadURL(qVXMoWkeiuIScEJUGhwasOgArKQmnC,qVXMoWkeiuIScEJUGhwasOgArKQmny,qVXMoWkeiuIScEJUGhwasOgArKQmtz,qVXMoWkeiuIScEJUGhwasOgArKQmnD,optUHD=qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_uhd())
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.addon_log('qt, stype, url : %s - %s - %s'%(qVXMoWkeiuIScEJUGhwasOgArKQmDB(qVXMoWkeiuIScEJUGhwasOgArKQmny),qVXMoWkeiuIScEJUGhwasOgArKQmtz,qVXMoWkeiuIScEJUGhwasOgArKQmnv['streaming_url']))
  if qVXMoWkeiuIScEJUGhwasOgArKQmnv['streaming_url']=='':
   if qVXMoWkeiuIScEJUGhwasOgArKQmnv['error_msg']=='':
    qVXMoWkeiuIScEJUGhwasOgArKQmHj.addon_noti(__language__(30908).encode('utf8'))
   else:
    qVXMoWkeiuIScEJUGhwasOgArKQmHj.addon_noti(qVXMoWkeiuIScEJUGhwasOgArKQmnv['error_msg'].encode('utf8'))
   return
  qVXMoWkeiuIScEJUGhwasOgArKQmnf={'user-agent':qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.USER_AGENT}
  qVXMoWkeiuIScEJUGhwasOgArKQmnj=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.makeDefaultCookies() 
  if qVXMoWkeiuIScEJUGhwasOgArKQmnv['drm_server_url'] !='':
   qVXMoWkeiuIScEJUGhwasOgArKQmnf[qVXMoWkeiuIScEJUGhwasOgArKQmnv['drm_header_key']]=qVXMoWkeiuIScEJUGhwasOgArKQmnv['drm_header_value']
  qVXMoWkeiuIScEJUGhwasOgArKQmnx =qVXMoWkeiuIScEJUGhwasOgArKQmCl
  qVXMoWkeiuIScEJUGhwasOgArKQmnz =qVXMoWkeiuIScEJUGhwasOgArKQmnv['streaming_url'].find('Policy=')
  if qVXMoWkeiuIScEJUGhwasOgArKQmnz!=-1:
   qVXMoWkeiuIScEJUGhwasOgArKQmnN =qVXMoWkeiuIScEJUGhwasOgArKQmnv['streaming_url'].split('?')[0]
   qVXMoWkeiuIScEJUGhwasOgArKQmnR=qVXMoWkeiuIScEJUGhwasOgArKQmDp(urllib.parse.parse_qsl(urllib.parse.urlsplit(qVXMoWkeiuIScEJUGhwasOgArKQmnv['streaming_url']).query))
   qVXMoWkeiuIScEJUGhwasOgArKQmnj['CloudFront-Policy'] =qVXMoWkeiuIScEJUGhwasOgArKQmnR['Policy'] 
   qVXMoWkeiuIScEJUGhwasOgArKQmnj['CloudFront-Signature'] =qVXMoWkeiuIScEJUGhwasOgArKQmnR['Signature'] 
   qVXMoWkeiuIScEJUGhwasOgArKQmnj['CloudFront-Key-Pair-Id']=qVXMoWkeiuIScEJUGhwasOgArKQmnR['Key-Pair-Id'] 
   qVXMoWkeiuIScEJUGhwasOgArKQmnL=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.make_stream_header(qVXMoWkeiuIScEJUGhwasOgArKQmnf,qVXMoWkeiuIScEJUGhwasOgArKQmnj)
   if 'quickvod-mcdn.tving.com' in qVXMoWkeiuIScEJUGhwasOgArKQmnN:
    qVXMoWkeiuIScEJUGhwasOgArKQmnx=qVXMoWkeiuIScEJUGhwasOgArKQmCb
    qVXMoWkeiuIScEJUGhwasOgArKQmnT =qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    qVXMoWkeiuIScEJUGhwasOgArKQmnF=qVXMoWkeiuIScEJUGhwasOgArKQmnT.strftime('%Y-%m-%d-%H:%M:%S')
    if qVXMoWkeiuIScEJUGhwasOgArKQmCd(qVXMoWkeiuIScEJUGhwasOgArKQmnF.replace('-','').replace(':',''))<qVXMoWkeiuIScEJUGhwasOgArKQmCd(qVXMoWkeiuIScEJUGhwasOgArKQmnR['end'].replace('-','').replace(':','')):
     qVXMoWkeiuIScEJUGhwasOgArKQmnR['end']=qVXMoWkeiuIScEJUGhwasOgArKQmnF
     qVXMoWkeiuIScEJUGhwasOgArKQmHj.addon_noti(__language__(30915).encode('utf8'))
    qVXMoWkeiuIScEJUGhwasOgArKQmnN ='%s?%s'%(qVXMoWkeiuIScEJUGhwasOgArKQmnN,urllib.parse.urlencode(qVXMoWkeiuIScEJUGhwasOgArKQmnR,doseq=qVXMoWkeiuIScEJUGhwasOgArKQmCb))
    qVXMoWkeiuIScEJUGhwasOgArKQmnd='{}|{}'.format(qVXMoWkeiuIScEJUGhwasOgArKQmnN,qVXMoWkeiuIScEJUGhwasOgArKQmnL)
   else:
    qVXMoWkeiuIScEJUGhwasOgArKQmnd='{}|{}'.format(qVXMoWkeiuIScEJUGhwasOgArKQmnv['streaming_url'],qVXMoWkeiuIScEJUGhwasOgArKQmnL)
  else:
   qVXMoWkeiuIScEJUGhwasOgArKQmnL=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.make_stream_header(qVXMoWkeiuIScEJUGhwasOgArKQmnf,qVXMoWkeiuIScEJUGhwasOgArKQmnj)
   qVXMoWkeiuIScEJUGhwasOgArKQmnd='{}|{}'.format(qVXMoWkeiuIScEJUGhwasOgArKQmnv['streaming_url'],qVXMoWkeiuIScEJUGhwasOgArKQmnL)
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.addon_log('if tmp_pos == -1')
  qVXMoWkeiuIScEJUGhwasOgArKQmpP,qVXMoWkeiuIScEJUGhwasOgArKQmpB=qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_proxyport()
  qVXMoWkeiuIScEJUGhwasOgArKQmpY=qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_playback()
  if(qVXMoWkeiuIScEJUGhwasOgArKQmpP and qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('mode')in['VOD','MOVIE']and qVXMoWkeiuIScEJUGhwasOgArKQmnx==qVXMoWkeiuIScEJUGhwasOgArKQmCl and(qVXMoWkeiuIScEJUGhwasOgArKQmnv['drm_server_url']!='' or qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.KodiVersion>=21)):
   if qVXMoWkeiuIScEJUGhwasOgArKQmnv['url_filename'].split('.')[1]=='mpd':
    qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Tving_Parse_mpd(qVXMoWkeiuIScEJUGhwasOgArKQmnv['streaming_url'])
   else:
    qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Tving_Parse_m3u8(qVXMoWkeiuIScEJUGhwasOgArKQmnv['streaming_url'])
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.addon_log('xxx '+qVXMoWkeiuIScEJUGhwasOgArKQmnv['streaming_url'])
   qVXMoWkeiuIScEJUGhwasOgArKQmpY['url_filename']=qVXMoWkeiuIScEJUGhwasOgArKQmnv['url_filename'],
   qVXMoWkeiuIScEJUGhwasOgArKQmnb={'addon':'tvingm','playOption':qVXMoWkeiuIScEJUGhwasOgArKQmpY,}
   qVXMoWkeiuIScEJUGhwasOgArKQmnb=json.dumps(qVXMoWkeiuIScEJUGhwasOgArKQmnb,separators=(',',':'))
   qVXMoWkeiuIScEJUGhwasOgArKQmnb=base64.standard_b64encode(qVXMoWkeiuIScEJUGhwasOgArKQmnb.encode()).decode('utf-8')
   qVXMoWkeiuIScEJUGhwasOgArKQmnd ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(qVXMoWkeiuIScEJUGhwasOgArKQmpB,qVXMoWkeiuIScEJUGhwasOgArKQmnd,qVXMoWkeiuIScEJUGhwasOgArKQmnb)
   qVXMoWkeiuIScEJUGhwasOgArKQmnf['proxy-mini']=qVXMoWkeiuIScEJUGhwasOgArKQmnb 
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.addon_log('surl(2) : {}'.format(qVXMoWkeiuIScEJUGhwasOgArKQmnd))
  qVXMoWkeiuIScEJUGhwasOgArKQmnL=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.make_stream_header(qVXMoWkeiuIScEJUGhwasOgArKQmnf,qVXMoWkeiuIScEJUGhwasOgArKQmnj)
  qVXMoWkeiuIScEJUGhwasOgArKQmnl=xbmcgui.ListItem(path=qVXMoWkeiuIScEJUGhwasOgArKQmnd)
  if qVXMoWkeiuIScEJUGhwasOgArKQmnv['drm_server_url']!='':
   qVXMoWkeiuIScEJUGhwasOgArKQmCH=qVXMoWkeiuIScEJUGhwasOgArKQmnv['drm_server_url']
   qVXMoWkeiuIScEJUGhwasOgArKQmCp ='https://license-global.pallycon.com/ri/licenseManager.do' 
   qVXMoWkeiuIScEJUGhwasOgArKQmCt ='mpd'
   qVXMoWkeiuIScEJUGhwasOgArKQmCY ='com.widevine.alpha'
   qVXMoWkeiuIScEJUGhwasOgArKQmCP={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.USER_AGENT,qVXMoWkeiuIScEJUGhwasOgArKQmnv['drm_header_key']:qVXMoWkeiuIScEJUGhwasOgArKQmnv['drm_header_value'],}
   qVXMoWkeiuIScEJUGhwasOgArKQmCB=qVXMoWkeiuIScEJUGhwasOgArKQmCp+'|'+urllib.parse.urlencode(qVXMoWkeiuIScEJUGhwasOgArKQmCP)+'|R{SSM}|'
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream','inputstream.adaptive')
   if qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.KodiVersion<=20:
    qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream.adaptive.manifest_type',qVXMoWkeiuIScEJUGhwasOgArKQmCt)
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream.adaptive.license_type',qVXMoWkeiuIScEJUGhwasOgArKQmCY)
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream.adaptive.license_key',qVXMoWkeiuIScEJUGhwasOgArKQmCB)
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream.adaptive.stream_headers',qVXMoWkeiuIScEJUGhwasOgArKQmnL)
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream.adaptive.manifest_headers',qVXMoWkeiuIScEJUGhwasOgArKQmnL)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('mode')in['VOD','MOVIE']:
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setContentLookup(qVXMoWkeiuIScEJUGhwasOgArKQmCl)
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setMimeType('application/x-mpegURL')
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream','inputstream.adaptive')
   if qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.KodiVersion<=20:
    qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream.adaptive.manifest_type','hls')
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream.adaptive.stream_headers',qVXMoWkeiuIScEJUGhwasOgArKQmnL)
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream.adaptive.manifest_headers',qVXMoWkeiuIScEJUGhwasOgArKQmnL)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmnx==qVXMoWkeiuIScEJUGhwasOgArKQmCb:
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setContentLookup(qVXMoWkeiuIScEJUGhwasOgArKQmCl)
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setMimeType('application/x-mpegURL')
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream','inputstream.ffmpegdirect')
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('ResumeTime','0')
   qVXMoWkeiuIScEJUGhwasOgArKQmnl.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,qVXMoWkeiuIScEJUGhwasOgArKQmCb,qVXMoWkeiuIScEJUGhwasOgArKQmnl)
  try:
   if qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('mode')in['VOD','MOVIE']and qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('title'):
    qVXMoWkeiuIScEJUGhwasOgArKQmtp={'code':qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('programcode')if qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('mode')=='VOD' else qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('mediacode'),'img':qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('thumbnail'),'title':qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('title'),'videoid':qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('mediacode')}
    qVXMoWkeiuIScEJUGhwasOgArKQmHj.Save_Watched_List(qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('stype'),qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  except:
   qVXMoWkeiuIScEJUGhwasOgArKQmCF
 def logout(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  qVXMoWkeiuIScEJUGhwasOgArKQmHL=xbmcgui.Dialog()
  qVXMoWkeiuIScEJUGhwasOgArKQmtf=qVXMoWkeiuIScEJUGhwasOgArKQmHL.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if qVXMoWkeiuIScEJUGhwasOgArKQmtf==qVXMoWkeiuIScEJUGhwasOgArKQmCl:sys.exit()
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Init_TV_Total()
  if os.path.isfile(qVXMoWkeiuIScEJUGhwasOgArKQmHv):os.remove(qVXMoWkeiuIScEJUGhwasOgArKQmHv)
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  qVXMoWkeiuIScEJUGhwasOgArKQmCn =qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Get_Now_Datetime()
  qVXMoWkeiuIScEJUGhwasOgArKQmCD=qVXMoWkeiuIScEJUGhwasOgArKQmCn+datetime.timedelta(days=qVXMoWkeiuIScEJUGhwasOgArKQmCd(__addon__.getSetting('cache_ttl')))
  (qVXMoWkeiuIScEJUGhwasOgArKQmtC,qVXMoWkeiuIScEJUGhwasOgArKQmtD,qVXMoWkeiuIScEJUGhwasOgArKQmty,qVXMoWkeiuIScEJUGhwasOgArKQmtv)=qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_account()
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Save_session_acount(qVXMoWkeiuIScEJUGhwasOgArKQmtC,qVXMoWkeiuIScEJUGhwasOgArKQmtD,qVXMoWkeiuIScEJUGhwasOgArKQmty,qVXMoWkeiuIScEJUGhwasOgArKQmtv)
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.TV['account']['token_limit']=qVXMoWkeiuIScEJUGhwasOgArKQmCD.strftime('%Y%m%d')
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.JsonFile_Save(qVXMoWkeiuIScEJUGhwasOgArKQmHv,qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.TV)
 def cookiefile_check(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.TV=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.JsonFile_Load(qVXMoWkeiuIScEJUGhwasOgArKQmHv)
  if qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.TV=={}:
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Init_TV_Total()
   return qVXMoWkeiuIScEJUGhwasOgArKQmCl
  if '_tving_token' not in qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.TV.get('cookies'):
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Init_TV_Total()
   return qVXMoWkeiuIScEJUGhwasOgArKQmCl
  (qVXMoWkeiuIScEJUGhwasOgArKQmCy,qVXMoWkeiuIScEJUGhwasOgArKQmCv,qVXMoWkeiuIScEJUGhwasOgArKQmCf,qVXMoWkeiuIScEJUGhwasOgArKQmCj)=qVXMoWkeiuIScEJUGhwasOgArKQmHj.get_settings_account()
  (qVXMoWkeiuIScEJUGhwasOgArKQmCx,qVXMoWkeiuIScEJUGhwasOgArKQmCz,qVXMoWkeiuIScEJUGhwasOgArKQmCN,qVXMoWkeiuIScEJUGhwasOgArKQmCR)=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Load_session_acount()
  if qVXMoWkeiuIScEJUGhwasOgArKQmCy!=qVXMoWkeiuIScEJUGhwasOgArKQmCx or qVXMoWkeiuIScEJUGhwasOgArKQmCv!=qVXMoWkeiuIScEJUGhwasOgArKQmCz or qVXMoWkeiuIScEJUGhwasOgArKQmCf!=qVXMoWkeiuIScEJUGhwasOgArKQmCN or qVXMoWkeiuIScEJUGhwasOgArKQmCj!=qVXMoWkeiuIScEJUGhwasOgArKQmCR:
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Init_TV_Total()
   return qVXMoWkeiuIScEJUGhwasOgArKQmCl
  if qVXMoWkeiuIScEJUGhwasOgArKQmCd(qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>qVXMoWkeiuIScEJUGhwasOgArKQmCd(qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.TV['account']['token_limit']):
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.Init_TV_Total()
   return qVXMoWkeiuIScEJUGhwasOgArKQmCl
  return qVXMoWkeiuIScEJUGhwasOgArKQmCb
 def dp_Global_Search(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmPd=qVXMoWkeiuIScEJUGhwasOgArKQmtL.get('mode')
  if qVXMoWkeiuIScEJUGhwasOgArKQmPd=='TOTAL_SEARCH':
   qVXMoWkeiuIScEJUGhwasOgArKQmCL='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   qVXMoWkeiuIScEJUGhwasOgArKQmCL='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(qVXMoWkeiuIScEJUGhwasOgArKQmCL)
 def dp_Bookmark_Menu(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmCL='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(qVXMoWkeiuIScEJUGhwasOgArKQmCL)
 def dp_EuroLive_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj,qVXMoWkeiuIScEJUGhwasOgArKQmtL):
  qVXMoWkeiuIScEJUGhwasOgArKQmtF=qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.GetEuroChannelList()
  for qVXMoWkeiuIScEJUGhwasOgArKQmtb in qVXMoWkeiuIScEJUGhwasOgArKQmtF:
   qVXMoWkeiuIScEJUGhwasOgArKQmYN =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('channel')
   qVXMoWkeiuIScEJUGhwasOgArKQmpN =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('title')
   qVXMoWkeiuIScEJUGhwasOgArKQmYv =qVXMoWkeiuIScEJUGhwasOgArKQmtb.get('subtitle')
   qVXMoWkeiuIScEJUGhwasOgArKQmYy={'mediatype':'episode','title':qVXMoWkeiuIScEJUGhwasOgArKQmpN,'plot':'%s\n%s'%(qVXMoWkeiuIScEJUGhwasOgArKQmpN,qVXMoWkeiuIScEJUGhwasOgArKQmYv)}
   qVXMoWkeiuIScEJUGhwasOgArKQmtp={'mode':'LIVE','mediacode':qVXMoWkeiuIScEJUGhwasOgArKQmYN,'stype':'onair',}
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.add_dir(qVXMoWkeiuIScEJUGhwasOgArKQmpN,sublabel=qVXMoWkeiuIScEJUGhwasOgArKQmYv,img='',infoLabels=qVXMoWkeiuIScEJUGhwasOgArKQmYy,isFolder=qVXMoWkeiuIScEJUGhwasOgArKQmCl,params=qVXMoWkeiuIScEJUGhwasOgArKQmtp)
  if qVXMoWkeiuIScEJUGhwasOgArKQmDP(qVXMoWkeiuIScEJUGhwasOgArKQmtF)>0:xbmcplugin.endOfDirectory(qVXMoWkeiuIScEJUGhwasOgArKQmHj._addon_handle,cacheToDisc=qVXMoWkeiuIScEJUGhwasOgArKQmCl)
 def tving_main(qVXMoWkeiuIScEJUGhwasOgArKQmHj):
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.TvingObj.KodiVersion=qVXMoWkeiuIScEJUGhwasOgArKQmCd(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  qVXMoWkeiuIScEJUGhwasOgArKQmPd=qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params.get('mode',qVXMoWkeiuIScEJUGhwasOgArKQmCF)
  if qVXMoWkeiuIScEJUGhwasOgArKQmPd=='LOGOUT':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.logout()
   return
  qVXMoWkeiuIScEJUGhwasOgArKQmHj.login_main()
  if qVXMoWkeiuIScEJUGhwasOgArKQmPd is qVXMoWkeiuIScEJUGhwasOgArKQmCF:
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_Main_List()
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_Title_Group(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd in['GLOBAL_GROUP']:
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_SubTitle_Group(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='CHANNEL':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_LiveChannel_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd in['LIVE','VOD','MOVIE']:
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.play_VIDEO(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='PROGRAM':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_Program_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='4K_PROGRAM':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_4K_Program_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='ORI_PROGRAM':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_Ori_Program_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='EPISODE':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_Episode_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='MOVIE_SUB':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_Movie_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='4K_MOVIE':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_4K_Movie_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='SEARCH_GROUP':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_Search_Group(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd in['SEARCH','LOCAL_SEARCH']:
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_Search_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='WATCH':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_Watch_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_History_Remove(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='ORDER_BY':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_setEpOrderby(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='SET_BOOKMARK':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_Set_Bookmark(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd in['TOTAL_SEARCH','TOTAL_HISTORY']:
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_Global_Search(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='SEARCH_HISTORY':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_Search_History(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='MENU_BOOKMARK':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_Bookmark_Menu(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  elif qVXMoWkeiuIScEJUGhwasOgArKQmPd=='EURO_GROUP':
   qVXMoWkeiuIScEJUGhwasOgArKQmHj.dp_EuroLive_List(qVXMoWkeiuIScEJUGhwasOgArKQmHj.main_params)
  else:
   qVXMoWkeiuIScEJUGhwasOgArKQmCF
# Created by pyminifier (https://github.com/liftoff/pyminifier)
