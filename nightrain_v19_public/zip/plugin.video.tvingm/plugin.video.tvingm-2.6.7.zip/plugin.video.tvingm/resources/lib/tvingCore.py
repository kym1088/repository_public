__author__="NightRain"
YHLKBXdRfTGvUakFocAhpIgQDjWStz=print
YHLKBXdRfTGvUakFocAhpIgQDjWStO=ImportError
YHLKBXdRfTGvUakFocAhpIgQDjWStu=object
YHLKBXdRfTGvUakFocAhpIgQDjWStM=None
YHLKBXdRfTGvUakFocAhpIgQDjWStN=False
YHLKBXdRfTGvUakFocAhpIgQDjWStP=str
YHLKBXdRfTGvUakFocAhpIgQDjWStq=open
YHLKBXdRfTGvUakFocAhpIgQDjWStV=True
YHLKBXdRfTGvUakFocAhpIgQDjWStr=len
YHLKBXdRfTGvUakFocAhpIgQDjWSty=int
YHLKBXdRfTGvUakFocAhpIgQDjWStl=range
YHLKBXdRfTGvUakFocAhpIgQDjWSbn=bytes
YHLKBXdRfTGvUakFocAhpIgQDjWSbC=Exception
YHLKBXdRfTGvUakFocAhpIgQDjWSbw=dict
YHLKBXdRfTGvUakFocAhpIgQDjWSbm=list
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 YHLKBXdRfTGvUakFocAhpIgQDjWStz('Cryptodome')
except YHLKBXdRfTGvUakFocAhpIgQDjWStO:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 YHLKBXdRfTGvUakFocAhpIgQDjWStz('Crypto')
YHLKBXdRfTGvUakFocAhpIgQDjWSnw={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
YHLKBXdRfTGvUakFocAhpIgQDjWSnm ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
YHLKBXdRfTGvUakFocAhpIgQDjWSnJ =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
YHLKBXdRfTGvUakFocAhpIgQDjWSni=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class YHLKBXdRfTGvUakFocAhpIgQDjWSnC(YHLKBXdRfTGvUakFocAhpIgQDjWStu):
 def __init__(YHLKBXdRfTGvUakFocAhpIgQDjWSnx):
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.NETWORKCODE ='CSND0900'
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.OSCODE ='CSOD0900' 
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TELECODE ='CSCD0900'
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.SCREENCODE ='CSSD0100'
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.SCREENCODE_ATV ='CSSD1300' 
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.LIVE_LIMIT =20 
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.VOD_LIMIT =24 
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.EPISODE_LIMIT =30 
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.SEARCH_LIMIT =30 
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.MOVIE_LIMIT =24 
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN ='https://api.tving.com'
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN ='https://image.tving.com'
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.SEARCH_DOMAIN ='https://search-api.tving.com'
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.LOGIN_DOMAIN ='https://user.tving.com'
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.URL_DOMAIN ='https://www.tving.com'
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.MOVIE_LITE =['2610061','2610161','261062']
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.MODEL ='chrome_128.0.0.0' 
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.DEFAULT_HEADER ={'user-agent':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.USER_AGENT}
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.COOKIE_FILE_NAME =''
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV_SESSION_COOKIES1=''
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV_SESSION_COOKIES2=''
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV_STREAM_FILENAME =''
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV_SESSION_TEXT1 =''
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV_SESSION_TEXT2 =''
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.KodiVersion=20
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV ={}
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Init_TV_Total()
 def Init_TV_Total(YHLKBXdRfTGvUakFocAhpIgQDjWSnx):
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV={'account':{},'cookies':{},}
 def callRequestCookies(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,jobtype,YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,json=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWStM,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWStM,redirects=YHLKBXdRfTGvUakFocAhpIgQDjWStN):
  YHLKBXdRfTGvUakFocAhpIgQDjWSnt=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.DEFAULT_HEADER
  if headers:YHLKBXdRfTGvUakFocAhpIgQDjWSnt.update(headers)
  if jobtype=='Get':
   YHLKBXdRfTGvUakFocAhpIgQDjWSnb=requests.get(YHLKBXdRfTGvUakFocAhpIgQDjWSCV,params=params,headers=YHLKBXdRfTGvUakFocAhpIgQDjWSnt,cookies=cookies,allow_redirects=redirects)
  else:
   YHLKBXdRfTGvUakFocAhpIgQDjWSnb=requests.post(YHLKBXdRfTGvUakFocAhpIgQDjWSCV,data=payload,json=json,params=params,headers=YHLKBXdRfTGvUakFocAhpIgQDjWSnt,cookies=cookies,allow_redirects=redirects)
  YHLKBXdRfTGvUakFocAhpIgQDjWStz(YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnb.status_code)+' - '+YHLKBXdRfTGvUakFocAhpIgQDjWSnb.url)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSnb
 def JsonFile_Save(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,filename,YHLKBXdRfTGvUakFocAhpIgQDjWSns):
  if filename=='':return YHLKBXdRfTGvUakFocAhpIgQDjWStN
  try:
   fp=YHLKBXdRfTGvUakFocAhpIgQDjWStq(filename,'w',-1,'utf-8')
   json.dump(YHLKBXdRfTGvUakFocAhpIgQDjWSns,fp,indent=4,ensure_ascii=YHLKBXdRfTGvUakFocAhpIgQDjWStN)
   fp.close()
  except:
   return YHLKBXdRfTGvUakFocAhpIgQDjWStN
  return YHLKBXdRfTGvUakFocAhpIgQDjWStV
 def JsonFile_Load(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,filename):
  if filename=='':return{}
  try:
   fp=YHLKBXdRfTGvUakFocAhpIgQDjWStq(filename,'r',-1,'utf-8')
   YHLKBXdRfTGvUakFocAhpIgQDjWSnE=json.load(fp)
   fp.close()
  except:
   return{}
  return YHLKBXdRfTGvUakFocAhpIgQDjWSnE
 def TextFile_Save(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,filename,resText):
  if filename=='':return YHLKBXdRfTGvUakFocAhpIgQDjWStN
  try:
   fp=YHLKBXdRfTGvUakFocAhpIgQDjWStq(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return YHLKBXdRfTGvUakFocAhpIgQDjWStN
  return YHLKBXdRfTGvUakFocAhpIgQDjWStV
 def Save_session_acount(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,YHLKBXdRfTGvUakFocAhpIgQDjWSnz,YHLKBXdRfTGvUakFocAhpIgQDjWSnO,YHLKBXdRfTGvUakFocAhpIgQDjWSnu,YHLKBXdRfTGvUakFocAhpIgQDjWSnM):
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['account']['tvid'] =base64.standard_b64encode(YHLKBXdRfTGvUakFocAhpIgQDjWSnz.encode()).decode('utf-8')
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['account']['tvpw'] =base64.standard_b64encode(YHLKBXdRfTGvUakFocAhpIgQDjWSnO.encode()).decode('utf-8')
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['account']['tvtype']=YHLKBXdRfTGvUakFocAhpIgQDjWSnu 
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['account']['tvpf'] =YHLKBXdRfTGvUakFocAhpIgQDjWSnM 
 def Load_session_acount(YHLKBXdRfTGvUakFocAhpIgQDjWSnx):
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSnz =base64.standard_b64decode(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['account']['tvid']).decode('utf-8')
   YHLKBXdRfTGvUakFocAhpIgQDjWSnO =base64.standard_b64decode(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['account']['tvpw']).decode('utf-8')
   YHLKBXdRfTGvUakFocAhpIgQDjWSnu=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['account']['tvtype']
   YHLKBXdRfTGvUakFocAhpIgQDjWSnM =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return YHLKBXdRfTGvUakFocAhpIgQDjWSnz,YHLKBXdRfTGvUakFocAhpIgQDjWSnO,YHLKBXdRfTGvUakFocAhpIgQDjWSnu,YHLKBXdRfTGvUakFocAhpIgQDjWSnM
 def make_stream_header(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,YHLKBXdRfTGvUakFocAhpIgQDjWSnr,YHLKBXdRfTGvUakFocAhpIgQDjWSnl):
  YHLKBXdRfTGvUakFocAhpIgQDjWSnN=''
  if YHLKBXdRfTGvUakFocAhpIgQDjWSnl not in[{},YHLKBXdRfTGvUakFocAhpIgQDjWStM,'']:
   YHLKBXdRfTGvUakFocAhpIgQDjWSnP=YHLKBXdRfTGvUakFocAhpIgQDjWStr(YHLKBXdRfTGvUakFocAhpIgQDjWSnl)
   for YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSnV in YHLKBXdRfTGvUakFocAhpIgQDjWSnl.items():
    YHLKBXdRfTGvUakFocAhpIgQDjWSnN+='{}={}'.format(YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSnV)
    YHLKBXdRfTGvUakFocAhpIgQDjWSnP+=-1
    if YHLKBXdRfTGvUakFocAhpIgQDjWSnP>0:YHLKBXdRfTGvUakFocAhpIgQDjWSnN+='; '
   YHLKBXdRfTGvUakFocAhpIgQDjWSnr['cookie']=YHLKBXdRfTGvUakFocAhpIgQDjWSnN
  YHLKBXdRfTGvUakFocAhpIgQDjWSny=''
  i=0
  for YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSnV in YHLKBXdRfTGvUakFocAhpIgQDjWSnr.items():
   i=i+1
   if i>1:YHLKBXdRfTGvUakFocAhpIgQDjWSny+='&'
   YHLKBXdRfTGvUakFocAhpIgQDjWSny+='{}={}'.format(YHLKBXdRfTGvUakFocAhpIgQDjWSnq,urllib.parse.quote(YHLKBXdRfTGvUakFocAhpIgQDjWSnV))
  return YHLKBXdRfTGvUakFocAhpIgQDjWSny
 def makeDefaultCookies(YHLKBXdRfTGvUakFocAhpIgQDjWSnx):
  YHLKBXdRfTGvUakFocAhpIgQDjWSnl={}
  for YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSnV in YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies'].items():
   YHLKBXdRfTGvUakFocAhpIgQDjWSnl[YHLKBXdRfTGvUakFocAhpIgQDjWSnq]=YHLKBXdRfTGvUakFocAhpIgQDjWSnV
  return YHLKBXdRfTGvUakFocAhpIgQDjWSnl
 def getDeviceStr(YHLKBXdRfTGvUakFocAhpIgQDjWSnx):
  YHLKBXdRfTGvUakFocAhpIgQDjWSCn=[]
  YHLKBXdRfTGvUakFocAhpIgQDjWSCn.append('Windows') 
  YHLKBXdRfTGvUakFocAhpIgQDjWSCn.append('Chrome') 
  YHLKBXdRfTGvUakFocAhpIgQDjWSCn.append('ko-KR') 
  YHLKBXdRfTGvUakFocAhpIgQDjWSCn.append('undefined') 
  YHLKBXdRfTGvUakFocAhpIgQDjWSCn.append('24') 
  YHLKBXdRfTGvUakFocAhpIgQDjWSCn.append(u'한국 표준시')
  YHLKBXdRfTGvUakFocAhpIgQDjWSCn.append('undefined') 
  YHLKBXdRfTGvUakFocAhpIgQDjWSCn.append('undefined') 
  YHLKBXdRfTGvUakFocAhpIgQDjWSCn.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  YHLKBXdRfTGvUakFocAhpIgQDjWSCw=''
  for YHLKBXdRfTGvUakFocAhpIgQDjWSCm in YHLKBXdRfTGvUakFocAhpIgQDjWSCn:
   YHLKBXdRfTGvUakFocAhpIgQDjWSCw+=YHLKBXdRfTGvUakFocAhpIgQDjWSCm+'|'
  return YHLKBXdRfTGvUakFocAhpIgQDjWSCw
 def GetDefaultParams(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,uhd=YHLKBXdRfTGvUakFocAhpIgQDjWStN):
  if uhd==YHLKBXdRfTGvUakFocAhpIgQDjWStN:
   YHLKBXdRfTGvUakFocAhpIgQDjWSCJ={'apiKey':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.APIKEY,'networkCode':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.NETWORKCODE,'osCode':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.OSCODE,'teleCode':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TELECODE,'screenCode':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.SCREENCODE,}
  else:
   YHLKBXdRfTGvUakFocAhpIgQDjWSCJ={'apiKey':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.APIKEY_ATV,'networkCode':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.NETWORKCODE,'osCode':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.OSCODE,'teleCode':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TELECODE,'screenCode':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.SCREENCODE_ATV,}
  return YHLKBXdRfTGvUakFocAhpIgQDjWSCJ
 def GetNoCache(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,timetype=1):
  if timetype==1:
   return YHLKBXdRfTGvUakFocAhpIgQDjWSty(time.time())
  else:
   return YHLKBXdRfTGvUakFocAhpIgQDjWSty(time.time()*1000)
 def GetUniqueid(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,hValue=YHLKBXdRfTGvUakFocAhpIgQDjWStM):
  if hValue:
   import hashlib
   YHLKBXdRfTGvUakFocAhpIgQDjWSCi=hashlib.sha1()
   YHLKBXdRfTGvUakFocAhpIgQDjWSCi.update(hValue.encode())
   YHLKBXdRfTGvUakFocAhpIgQDjWSCx=YHLKBXdRfTGvUakFocAhpIgQDjWSCi.hexdigest()[:8]
  else:
   YHLKBXdRfTGvUakFocAhpIgQDjWSCt=[0 for i in YHLKBXdRfTGvUakFocAhpIgQDjWStl(256)]
   for i in YHLKBXdRfTGvUakFocAhpIgQDjWStl(256):
    YHLKBXdRfTGvUakFocAhpIgQDjWSCt[i]='%02x'%(i)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCb=YHLKBXdRfTGvUakFocAhpIgQDjWSty(4294967295*random.random())|0
   YHLKBXdRfTGvUakFocAhpIgQDjWSCx=YHLKBXdRfTGvUakFocAhpIgQDjWSCt[255&YHLKBXdRfTGvUakFocAhpIgQDjWSCb]+YHLKBXdRfTGvUakFocAhpIgQDjWSCt[YHLKBXdRfTGvUakFocAhpIgQDjWSCb>>8&255]+YHLKBXdRfTGvUakFocAhpIgQDjWSCt[YHLKBXdRfTGvUakFocAhpIgQDjWSCb>>16&255]+YHLKBXdRfTGvUakFocAhpIgQDjWSCt[YHLKBXdRfTGvUakFocAhpIgQDjWSCb>>24&255]
  return YHLKBXdRfTGvUakFocAhpIgQDjWSCx
 def Web_DecryptKey(YHLKBXdRfTGvUakFocAhpIgQDjWSnx):
  YHLKBXdRfTGvUakFocAhpIgQDjWSCs=YHLKBXdRfTGvUakFocAhpIgQDjWSbn('kss2lym0kdw1lks3','utf-8')
  YHLKBXdRfTGvUakFocAhpIgQDjWSCe=YHLKBXdRfTGvUakFocAhpIgQDjWSbn('6yhlJ4WF9ZIj6I8n','utf-8')
  return YHLKBXdRfTGvUakFocAhpIgQDjWSCs,YHLKBXdRfTGvUakFocAhpIgQDjWSCe
 def Web_EncryptCiphertext(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,YHLKBXdRfTGvUakFocAhpIgQDjWSCM):
  YHLKBXdRfTGvUakFocAhpIgQDjWSCE,YHLKBXdRfTGvUakFocAhpIgQDjWSCz=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Web_DecryptKey()
  YHLKBXdRfTGvUakFocAhpIgQDjWSCO=AES.new(YHLKBXdRfTGvUakFocAhpIgQDjWSCE,AES.MODE_CBC,YHLKBXdRfTGvUakFocAhpIgQDjWSCz,)
  YHLKBXdRfTGvUakFocAhpIgQDjWSCu=YHLKBXdRfTGvUakFocAhpIgQDjWSCO.encrypt(Padding.pad(YHLKBXdRfTGvUakFocAhpIgQDjWSCM.encode('utf-8'),16))
  return base64.standard_b64encode(YHLKBXdRfTGvUakFocAhpIgQDjWSCu).decode('utf-8')
 def Web_DecryptPlaintext(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,YHLKBXdRfTGvUakFocAhpIgQDjWSCu):
  YHLKBXdRfTGvUakFocAhpIgQDjWSCE,YHLKBXdRfTGvUakFocAhpIgQDjWSCz=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Web_DecryptKey()
  YHLKBXdRfTGvUakFocAhpIgQDjWSCO=AES.new(YHLKBXdRfTGvUakFocAhpIgQDjWSCE,AES.MODE_CBC,YHLKBXdRfTGvUakFocAhpIgQDjWSCz,)
  YHLKBXdRfTGvUakFocAhpIgQDjWSCM=Padding.unpad(YHLKBXdRfTGvUakFocAhpIgQDjWSCO.decrypt(base64.standard_b64decode(YHLKBXdRfTGvUakFocAhpIgQDjWSCu)),16)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSCM.decode('utf-8')
 def WebCookies_Load(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,wc_file):
  try:
   fp=YHLKBXdRfTGvUakFocAhpIgQDjWStq(wc_file,'r',-1,'utf-8')
   YHLKBXdRfTGvUakFocAhpIgQDjWSCN=fp.read()
   fp.close()
   YHLKBXdRfTGvUakFocAhpIgQDjWSCP=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Web_DecryptPlaintext(YHLKBXdRfTGvUakFocAhpIgQDjWSCN)
   YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCP)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCq =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDeviceList()
   if YHLKBXdRfTGvUakFocAhpIgQDjWSCq not in['','-']:
    YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies']['tving_uuid']=YHLKBXdRfTGvUakFocAhpIgQDjWSCq+'-'+YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetUniqueid(YHLKBXdRfTGvUakFocAhpIgQDjWSCq)
  except:
   return YHLKBXdRfTGvUakFocAhpIgQDjWStN
  return YHLKBXdRfTGvUakFocAhpIgQDjWStV
 def GetCredential2(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,user_id,user_pw,login_type,user_pf):
  try:
   if base64.standard_b64encode(user_id.encode()).decode('utf-8')=='a3ltOTUxMDg4':
    YHLKBXdRfTGvUakFocAhpIgQDjWSCV='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx'
   else:
    YHLKBXdRfTGvUakFocAhpIgQDjWSCV='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx'
   YHLKBXdRfTGvUakFocAhpIgQDjWSCr={'addon':'tvingm','method':'LOGIN','data':{'type':login_type,'id':user_id,'pw':user_pw,'pf':user_pf,}}
   YHLKBXdRfTGvUakFocAhpIgQDjWSCr=json.dumps(YHLKBXdRfTGvUakFocAhpIgQDjWSCr,separators=(',',':'))
   YHLKBXdRfTGvUakFocAhpIgQDjWSCr=base64.standard_b64encode(YHLKBXdRfTGvUakFocAhpIgQDjWSCr.encode()).decode('utf-8')
   YHLKBXdRfTGvUakFocAhpIgQDjWSnr={'proxy-mini':YHLKBXdRfTGvUakFocAhpIgQDjWSCr}
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=requests.get(base64.standard_b64decode(YHLKBXdRfTGvUakFocAhpIgQDjWSCV).decode('utf-8'),headers=YHLKBXdRfTGvUakFocAhpIgQDjWSnr)
   if YHLKBXdRfTGvUakFocAhpIgQDjWSCy.status_code!=200:
    YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Init_TV_Total()
    return YHLKBXdRfTGvUakFocAhpIgQDjWStN
   YHLKBXdRfTGvUakFocAhpIgQDjWSCl=base64.standard_b64decode(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text).decode('utf-8')
   YHLKBXdRfTGvUakFocAhpIgQDjWSCl=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCl)
   YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies']=YHLKBXdRfTGvUakFocAhpIgQDjWSCl
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
   YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Init_TV_Total()
   return YHLKBXdRfTGvUakFocAhpIgQDjWStN
  return YHLKBXdRfTGvUakFocAhpIgQDjWStV
 def GetCredential(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,user_id,user_pw,login_type,user_pf):
  from curl_cffi import requests
  YHLKBXdRfTGvUakFocAhpIgQDjWSwn='chrome' 
  YHLKBXdRfTGvUakFocAhpIgQDjWSwC=requests.Session()
  try:
   if login_type=='0':
    YHLKBXdRfTGvUakFocAhpIgQDjWSwm='https://user.tving.com/pc/user/otherLogin.tving?loginType=10&from=pc&csite=&isAuto=false&rtUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   else:
    YHLKBXdRfTGvUakFocAhpIgQDjWSwm='https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   YHLKBXdRfTGvUakFocAhpIgQDjWSnr={'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language':'ko-KR,ko;q=0.9','cache-control':'no-cache','pragma':'no-cache','priority':'u=0, i','referer':'https://www.tving.com/',}
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSwC.get(YHLKBXdRfTGvUakFocAhpIgQDjWSwm,headers=YHLKBXdRfTGvUakFocAhpIgQDjWSnr,impersonate=YHLKBXdRfTGvUakFocAhpIgQDjWSwn)
   YHLKBXdRfTGvUakFocAhpIgQDjWStz('{} - {}'.format(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.status_code,YHLKBXdRfTGvUakFocAhpIgQDjWSCy.url))
   for YHLKBXdRfTGvUakFocAhpIgQDjWSwJ in YHLKBXdRfTGvUakFocAhpIgQDjWSCy.cookies.jar:
    YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies'][YHLKBXdRfTGvUakFocAhpIgQDjWSwJ.name]=YHLKBXdRfTGvUakFocAhpIgQDjWSwJ.value
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
   YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Init_TV_Total()
   return YHLKBXdRfTGvUakFocAhpIgQDjWStN
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSwi=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   YHLKBXdRfTGvUakFocAhpIgQDjWSwx={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':YHLKBXdRfTGvUakFocAhpIgQDjWStN,'cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   YHLKBXdRfTGvUakFocAhpIgQDjWSnr['referer']=YHLKBXdRfTGvUakFocAhpIgQDjWSwm
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSwC.post(url=YHLKBXdRfTGvUakFocAhpIgQDjWSwi,data=YHLKBXdRfTGvUakFocAhpIgQDjWSwx,headers=YHLKBXdRfTGvUakFocAhpIgQDjWSnr,impersonate=YHLKBXdRfTGvUakFocAhpIgQDjWSwn)
   YHLKBXdRfTGvUakFocAhpIgQDjWStz('{} - {}'.format(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.status_code,YHLKBXdRfTGvUakFocAhpIgQDjWSCy.url))
   for YHLKBXdRfTGvUakFocAhpIgQDjWSwJ in YHLKBXdRfTGvUakFocAhpIgQDjWSCy.cookies.jar:
    YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies'][YHLKBXdRfTGvUakFocAhpIgQDjWSwJ.name]=YHLKBXdRfTGvUakFocAhpIgQDjWSwJ.value
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
   YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Init_TV_Total()
   return YHLKBXdRfTGvUakFocAhpIgQDjWStN
  YHLKBXdRfTGvUakFocAhpIgQDjWSwt=[]
  YHLKBXdRfTGvUakFocAhpIgQDjWSwb =''
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSws ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   YHLKBXdRfTGvUakFocAhpIgQDjWSnr['referer']=YHLKBXdRfTGvUakFocAhpIgQDjWSwi
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSwC.get(url=YHLKBXdRfTGvUakFocAhpIgQDjWSws,data=YHLKBXdRfTGvUakFocAhpIgQDjWSwx,headers=YHLKBXdRfTGvUakFocAhpIgQDjWSnr,impersonate=YHLKBXdRfTGvUakFocAhpIgQDjWSwn)
   YHLKBXdRfTGvUakFocAhpIgQDjWStz('{} - {}'.format(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.status_code,YHLKBXdRfTGvUakFocAhpIgQDjWSCy.url))
   for YHLKBXdRfTGvUakFocAhpIgQDjWSwJ in YHLKBXdRfTGvUakFocAhpIgQDjWSCy.cookies.jar:
    YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies'][YHLKBXdRfTGvUakFocAhpIgQDjWSwJ.name]=YHLKBXdRfTGvUakFocAhpIgQDjWSwJ.value
   YHLKBXdRfTGvUakFocAhpIgQDjWSwt =re.findall('data-profile-no="\d+"',YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   for i in YHLKBXdRfTGvUakFocAhpIgQDjWStl(YHLKBXdRfTGvUakFocAhpIgQDjWStr(YHLKBXdRfTGvUakFocAhpIgQDjWSwt)):
    YHLKBXdRfTGvUakFocAhpIgQDjWSwe =YHLKBXdRfTGvUakFocAhpIgQDjWSwt[i].replace('data-profile-no=','').replace('"','')
    YHLKBXdRfTGvUakFocAhpIgQDjWSwt[i]=YHLKBXdRfTGvUakFocAhpIgQDjWSwe
   YHLKBXdRfTGvUakFocAhpIgQDjWSwb=YHLKBXdRfTGvUakFocAhpIgQDjWSwt[user_pf]
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
   YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Init_TV_Total()
   return YHLKBXdRfTGvUakFocAhpIgQDjWStN
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSwE ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   YHLKBXdRfTGvUakFocAhpIgQDjWSnr['referer']=YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSwx={'profileNo':YHLKBXdRfTGvUakFocAhpIgQDjWSwb}
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSwC.post(url=YHLKBXdRfTGvUakFocAhpIgQDjWSwE,data=YHLKBXdRfTGvUakFocAhpIgQDjWSwx,headers=YHLKBXdRfTGvUakFocAhpIgQDjWSnr,impersonate=YHLKBXdRfTGvUakFocAhpIgQDjWSwn)
   YHLKBXdRfTGvUakFocAhpIgQDjWStz('{} - {}'.format(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.status_code,YHLKBXdRfTGvUakFocAhpIgQDjWSCy.url))
   for YHLKBXdRfTGvUakFocAhpIgQDjWSwJ in YHLKBXdRfTGvUakFocAhpIgQDjWSCy.cookies.jar:
    YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies'][YHLKBXdRfTGvUakFocAhpIgQDjWSwJ.name]=YHLKBXdRfTGvUakFocAhpIgQDjWSwJ.value
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
   YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Init_TV_Total()
   return YHLKBXdRfTGvUakFocAhpIgQDjWStN
  YHLKBXdRfTGvUakFocAhpIgQDjWSCq =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDeviceList()
  if YHLKBXdRfTGvUakFocAhpIgQDjWSCq not in['','-']:
   YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies']['tving_uuid']=YHLKBXdRfTGvUakFocAhpIgQDjWSCq+'-'+YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetUniqueid(YHLKBXdRfTGvUakFocAhpIgQDjWSCq)
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.JsonFile_Save(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.COOKIE_FILE_NAME,YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV)
  return YHLKBXdRfTGvUakFocAhpIgQDjWStV
 def GetDeviceList(YHLKBXdRfTGvUakFocAhpIgQDjWSnx):
  YHLKBXdRfTGvUakFocAhpIgQDjWSwz=[]
  YHLKBXdRfTGvUakFocAhpIgQDjWSwO='-'
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v1/user/device/list'
   YHLKBXdRfTGvUakFocAhpIgQDjWSwu=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
   YHLKBXdRfTGvUakFocAhpIgQDjWSnl=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.makeDefaultCookies()
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSwu,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSwM,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWSnl)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwz=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(YHLKBXdRfTGvUakFocAhpIgQDjWSwz)
   for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSwz:
    if YHLKBXdRfTGvUakFocAhpIgQDjWSwP['model'].lower().startswith('pc'):
     YHLKBXdRfTGvUakFocAhpIgQDjWSwO=YHLKBXdRfTGvUakFocAhpIgQDjWSwP['uuid']
     break
   if YHLKBXdRfTGvUakFocAhpIgQDjWSwO=='-':
    YHLKBXdRfTGvUakFocAhpIgQDjWSwO=YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetNoCache(timetype=1))
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSwO
 def Get_Now_Datetime(YHLKBXdRfTGvUakFocAhpIgQDjWSnx):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,mediacode,sel_quality,stype,pvrmode='-',optUHD=YHLKBXdRfTGvUakFocAhpIgQDjWStN):
  YHLKBXdRfTGvUakFocAhpIgQDjWSwV ={'streaming_url':'','subtitleYn':YHLKBXdRfTGvUakFocAhpIgQDjWStN,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  YHLKBXdRfTGvUakFocAhpIgQDjWSwO =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies']['tving_uuid'].split('-')[0] 
  YHLKBXdRfTGvUakFocAhpIgQDjWSwr =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies']['tving_uuid'] 
  YHLKBXdRfTGvUakFocAhpIgQDjWSwy=YHLKBXdRfTGvUakFocAhpIgQDjWStN 
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSwl=YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetNoCache(1))
   if stype!='tvingtv':
    YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v2/media/stream/info'
    YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
    YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':YHLKBXdRfTGvUakFocAhpIgQDjWSwr,'deviceInfo':'PC','noCache':YHLKBXdRfTGvUakFocAhpIgQDjWSwl,}
    YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
    YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
    YHLKBXdRfTGvUakFocAhpIgQDjWSnl=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.makeDefaultCookies()
    YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWSnl)
    if YHLKBXdRfTGvUakFocAhpIgQDjWSCy.status_code!=200:
     YHLKBXdRfTGvUakFocAhpIgQDjWSwV['error_msg']='First Step - {} error'.format(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.status_code)
     return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
    YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
    if YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']['code']=='060':
     for YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSnV in YHLKBXdRfTGvUakFocAhpIgQDjWSnw.items():
      if YHLKBXdRfTGvUakFocAhpIgQDjWSnV==sel_quality:
       YHLKBXdRfTGvUakFocAhpIgQDjWSmC=YHLKBXdRfTGvUakFocAhpIgQDjWSnq
    elif YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']['code']!='000':
     YHLKBXdRfTGvUakFocAhpIgQDjWSwV['error_msg']=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']['message']
     return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
    else: 
     if not('stream' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']):return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
     YHLKBXdRfTGvUakFocAhpIgQDjWSmw=[]
     for YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSnV in YHLKBXdRfTGvUakFocAhpIgQDjWSnw.items():
      for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['stream']['quality']:
       if YHLKBXdRfTGvUakFocAhpIgQDjWSwP['active']=='Y' and YHLKBXdRfTGvUakFocAhpIgQDjWSwP['code']==YHLKBXdRfTGvUakFocAhpIgQDjWSnq:
        YHLKBXdRfTGvUakFocAhpIgQDjWSmw.append({YHLKBXdRfTGvUakFocAhpIgQDjWSnw.get(YHLKBXdRfTGvUakFocAhpIgQDjWSwP['code']):YHLKBXdRfTGvUakFocAhpIgQDjWSwP['code']})
     YHLKBXdRfTGvUakFocAhpIgQDjWSmC=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.CheckQuality(sel_quality,YHLKBXdRfTGvUakFocAhpIgQDjWSmw)
     try:
      if optUHD==YHLKBXdRfTGvUakFocAhpIgQDjWStV and YHLKBXdRfTGvUakFocAhpIgQDjWSmC=='stream50' and 'stream_support_info' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['content']['info']:
       if YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['content']['info']['stream_support_info']!=YHLKBXdRfTGvUakFocAhpIgQDjWStM:
        if 'stream70' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['content']['info']['stream_support_info']:
         YHLKBXdRfTGvUakFocAhpIgQDjWSmC='stream70'
         YHLKBXdRfTGvUakFocAhpIgQDjWSwy =YHLKBXdRfTGvUakFocAhpIgQDjWStV
     except:
      pass
     try:
      if optUHD==YHLKBXdRfTGvUakFocAhpIgQDjWStV and YHLKBXdRfTGvUakFocAhpIgQDjWSmC=='stream50' and 'stream' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['content']['info']:
       if YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['content']['info']['stream']!=YHLKBXdRfTGvUakFocAhpIgQDjWStM:
        for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['content']['info']['stream']:
         if YHLKBXdRfTGvUakFocAhpIgQDjWSwP['code']=='stream70':
          YHLKBXdRfTGvUakFocAhpIgQDjWSmC='stream70'
          YHLKBXdRfTGvUakFocAhpIgQDjWSwy =YHLKBXdRfTGvUakFocAhpIgQDjWStV
          break
     except:
      pass
   else:
    YHLKBXdRfTGvUakFocAhpIgQDjWSmC='stream40'
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwV['error_msg']='First Step - except error'
   return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
  YHLKBXdRfTGvUakFocAhpIgQDjWStz(YHLKBXdRfTGvUakFocAhpIgQDjWSmC)
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSwl=YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetNoCache(1))
   YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v3/media/stream/info'
   if YHLKBXdRfTGvUakFocAhpIgQDjWSwy==YHLKBXdRfTGvUakFocAhpIgQDjWStV:
    YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams(uhd=YHLKBXdRfTGvUakFocAhpIgQDjWStV)
    YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'mediaCode':mediacode,'deviceId':YHLKBXdRfTGvUakFocAhpIgQDjWSwO,'uuid':YHLKBXdRfTGvUakFocAhpIgQDjWSwr,'deviceInfo':'PC_Chrome WebView','streamCode':YHLKBXdRfTGvUakFocAhpIgQDjWSmC,'noCache':YHLKBXdRfTGvUakFocAhpIgQDjWSwl,'callingFrom':'HTML5','model':'chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   else:
    YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
    YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'mediaCode':mediacode,'deviceId':YHLKBXdRfTGvUakFocAhpIgQDjWSwO,'uuid':YHLKBXdRfTGvUakFocAhpIgQDjWSwr,'deviceInfo':'PC_Chrome','streamCode':YHLKBXdRfTGvUakFocAhpIgQDjWSmC,'noCache':YHLKBXdRfTGvUakFocAhpIgQDjWSwl,'callingFrom':'HTML5','model':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSnl=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.makeDefaultCookies()
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Post',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWSnl,redirects=YHLKBXdRfTGvUakFocAhpIgQDjWStV)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']['code']!='000':
    YHLKBXdRfTGvUakFocAhpIgQDjWSwV['error_msg']=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']['message']
    return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
   YHLKBXdRfTGvUakFocAhpIgQDjWSmJ=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['stream']
   if YHLKBXdRfTGvUakFocAhpIgQDjWSmJ['drm_yn']=='Y':
    YHLKBXdRfTGvUakFocAhpIgQDjWSmi=YHLKBXdRfTGvUakFocAhpIgQDjWSmJ['playback']['drm']['widevine']
    for YHLKBXdRfTGvUakFocAhpIgQDjWSmx in YHLKBXdRfTGvUakFocAhpIgQDjWSmJ['playback']['drm']['license']['drm_license_data']:
     if YHLKBXdRfTGvUakFocAhpIgQDjWSmx['drm_type']=='Widevine':
      YHLKBXdRfTGvUakFocAhpIgQDjWSwV['drm_server_url'] =YHLKBXdRfTGvUakFocAhpIgQDjWSmx['drm_server_url']
      YHLKBXdRfTGvUakFocAhpIgQDjWSwV['drm_header_key'] =YHLKBXdRfTGvUakFocAhpIgQDjWSmx['drm_header_key']
      YHLKBXdRfTGvUakFocAhpIgQDjWSwV['drm_header_value']=YHLKBXdRfTGvUakFocAhpIgQDjWSmx['drm_header_value']
      break
   else:
    YHLKBXdRfTGvUakFocAhpIgQDjWSmi=YHLKBXdRfTGvUakFocAhpIgQDjWSmJ['playback']['non_drm']
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwV['error_msg']='Second Step - except error'
   return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
  YHLKBXdRfTGvUakFocAhpIgQDjWSmt=YHLKBXdRfTGvUakFocAhpIgQDjWSwl
  YHLKBXdRfTGvUakFocAhpIgQDjWSmi=YHLKBXdRfTGvUakFocAhpIgQDjWSmi.split('|')[1]
  YHLKBXdRfTGvUakFocAhpIgQDjWSmi=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Decrypt_Url(YHLKBXdRfTGvUakFocAhpIgQDjWSmi,mediacode,YHLKBXdRfTGvUakFocAhpIgQDjWSmt)
  YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url']=YHLKBXdRfTGvUakFocAhpIgQDjWSmi
  if 'subtitles' in YHLKBXdRfTGvUakFocAhpIgQDjWSmJ:
   for YHLKBXdRfTGvUakFocAhpIgQDjWSmb in YHLKBXdRfTGvUakFocAhpIgQDjWSmJ.get('subtitles'):
    if YHLKBXdRfTGvUakFocAhpIgQDjWSmb.get('code')in['KO','KO_CC']:
     YHLKBXdRfTGvUakFocAhpIgQDjWSwV['subtitleYn']=YHLKBXdRfTGvUakFocAhpIgQDjWStV
     break
  YHLKBXdRfTGvUakFocAhpIgQDjWSms=urllib.parse.urlparse(YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url'])
  YHLKBXdRfTGvUakFocAhpIgQDjWSme =YHLKBXdRfTGvUakFocAhpIgQDjWSms.path.strip('/').split('/')
  YHLKBXdRfTGvUakFocAhpIgQDjWSwV['url_filename']=YHLKBXdRfTGvUakFocAhpIgQDjWSme[YHLKBXdRfTGvUakFocAhpIgQDjWStr(YHLKBXdRfTGvUakFocAhpIgQDjWSme)-1]
  return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
 def Tving_Parse_mpd(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,stream_url):
  YHLKBXdRfTGvUakFocAhpIgQDjWSCy=requests.get(url=stream_url)
  YHLKBXdRfTGvUakFocAhpIgQDjWSmE=YHLKBXdRfTGvUakFocAhpIgQDjWSCy.content.decode('utf-8')
  YHLKBXdRfTGvUakFocAhpIgQDjWSmz=0
  YHLKBXdRfTGvUakFocAhpIgQDjWSmO =ET.ElementTree(ET.fromstring(YHLKBXdRfTGvUakFocAhpIgQDjWSmE))
  YHLKBXdRfTGvUakFocAhpIgQDjWSmu =YHLKBXdRfTGvUakFocAhpIgQDjWSmO.getroot()
  YHLKBXdRfTGvUakFocAhpIgQDjWSmM=re.match(r'\{.*\}',YHLKBXdRfTGvUakFocAhpIgQDjWSmu.tag)[0] 
  YHLKBXdRfTGvUakFocAhpIgQDjWSmN=YHLKBXdRfTGvUakFocAhpIgQDjWSbw([node for _,node in ET.iterparse(io.StringIO(YHLKBXdRfTGvUakFocAhpIgQDjWSmE),events=['start-ns'])])
  for YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSJe in YHLKBXdRfTGvUakFocAhpIgQDjWSmN.items():
   if YHLKBXdRfTGvUakFocAhpIgQDjWSnq!='ns2':
    ET.register_namespace(YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSJe)
  YHLKBXdRfTGvUakFocAhpIgQDjWSmP=YHLKBXdRfTGvUakFocAhpIgQDjWSmu.find(YHLKBXdRfTGvUakFocAhpIgQDjWSmM+'Period')
  for YHLKBXdRfTGvUakFocAhpIgQDjWSmq in YHLKBXdRfTGvUakFocAhpIgQDjWSmP.findall(YHLKBXdRfTGvUakFocAhpIgQDjWSmM+'AdaptationSet'):
   if YHLKBXdRfTGvUakFocAhpIgQDjWSmq.attrib.get('mimeType')=='video/mp4':
    for YHLKBXdRfTGvUakFocAhpIgQDjWSmV in YHLKBXdRfTGvUakFocAhpIgQDjWSmq.findall(YHLKBXdRfTGvUakFocAhpIgQDjWSmM+'Representation'):
     YHLKBXdRfTGvUakFocAhpIgQDjWSmr=YHLKBXdRfTGvUakFocAhpIgQDjWSty(YHLKBXdRfTGvUakFocAhpIgQDjWSmV.attrib.get('bandwidth'))
     if YHLKBXdRfTGvUakFocAhpIgQDjWSmz<YHLKBXdRfTGvUakFocAhpIgQDjWSmr:YHLKBXdRfTGvUakFocAhpIgQDjWSmz=YHLKBXdRfTGvUakFocAhpIgQDjWSmr
    for YHLKBXdRfTGvUakFocAhpIgQDjWSmV in YHLKBXdRfTGvUakFocAhpIgQDjWSmq.findall(YHLKBXdRfTGvUakFocAhpIgQDjWSmM+'Representation'):
     if YHLKBXdRfTGvUakFocAhpIgQDjWSmz>YHLKBXdRfTGvUakFocAhpIgQDjWSty(YHLKBXdRfTGvUakFocAhpIgQDjWSmV.attrib.get('bandwidth')):
      YHLKBXdRfTGvUakFocAhpIgQDjWSmq.remove(YHLKBXdRfTGvUakFocAhpIgQDjWSmV)
   else:
    continue
  YHLKBXdRfTGvUakFocAhpIgQDjWSmy=ET.tostring(YHLKBXdRfTGvUakFocAhpIgQDjWSmu).decode('utf-8')
  YHLKBXdRfTGvUakFocAhpIgQDjWSml='<?xml version="1.0" encoding="UTF-8"?>\n'
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TextFile_Save(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV_STREAM_FILENAME,YHLKBXdRfTGvUakFocAhpIgQDjWSml+YHLKBXdRfTGvUakFocAhpIgQDjWSmy)
  return YHLKBXdRfTGvUakFocAhpIgQDjWStV
 def Tving_Parse_m3u8(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,stream_url):
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=requests.get(url=stream_url,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,stream=YHLKBXdRfTGvUakFocAhpIgQDjWStV)
   YHLKBXdRfTGvUakFocAhpIgQDjWSJn=YHLKBXdRfTGvUakFocAhpIgQDjWSCy.content.decode('utf-8')
   if '#EXTM3U' not in YHLKBXdRfTGvUakFocAhpIgQDjWSJn:
    return YHLKBXdRfTGvUakFocAhpIgQDjWStN
   if '#EXT-X-STREAM-INF' not in YHLKBXdRfTGvUakFocAhpIgQDjWSJn: 
    return YHLKBXdRfTGvUakFocAhpIgQDjWStN
   YHLKBXdRfTGvUakFocAhpIgQDjWSJC=0
   for YHLKBXdRfTGvUakFocAhpIgQDjWSJw in YHLKBXdRfTGvUakFocAhpIgQDjWSJn.splitlines():
    if YHLKBXdRfTGvUakFocAhpIgQDjWSJw.startswith('#EXT-X-STREAM-INF'):
     YHLKBXdRfTGvUakFocAhpIgQDjWSJm=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.MediaLine_Parse(YHLKBXdRfTGvUakFocAhpIgQDjWSJw,'#EXT-X-STREAM-INF')
     if YHLKBXdRfTGvUakFocAhpIgQDjWSJC<YHLKBXdRfTGvUakFocAhpIgQDjWSty(YHLKBXdRfTGvUakFocAhpIgQDjWSJm.get('BANDWIDTH')):
      YHLKBXdRfTGvUakFocAhpIgQDjWSJC=YHLKBXdRfTGvUakFocAhpIgQDjWSty(YHLKBXdRfTGvUakFocAhpIgQDjWSJm.get('BANDWIDTH'))
   YHLKBXdRfTGvUakFocAhpIgQDjWSJi=[]
   YHLKBXdRfTGvUakFocAhpIgQDjWSJx=YHLKBXdRfTGvUakFocAhpIgQDjWStN
   for YHLKBXdRfTGvUakFocAhpIgQDjWSJw in YHLKBXdRfTGvUakFocAhpIgQDjWSJn.splitlines():
    if YHLKBXdRfTGvUakFocAhpIgQDjWSJx==YHLKBXdRfTGvUakFocAhpIgQDjWStV:
     YHLKBXdRfTGvUakFocAhpIgQDjWSJx=YHLKBXdRfTGvUakFocAhpIgQDjWStN
     continue
    if YHLKBXdRfTGvUakFocAhpIgQDjWSJw.startswith('#EXT-X-STREAM-INF'):
     YHLKBXdRfTGvUakFocAhpIgQDjWSJm=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.MediaLine_Parse(YHLKBXdRfTGvUakFocAhpIgQDjWSJw,'#EXT-X-STREAM-INF')
     if YHLKBXdRfTGvUakFocAhpIgQDjWSJC!=YHLKBXdRfTGvUakFocAhpIgQDjWSty(YHLKBXdRfTGvUakFocAhpIgQDjWSJm.get('BANDWIDTH')):
      YHLKBXdRfTGvUakFocAhpIgQDjWSJx=YHLKBXdRfTGvUakFocAhpIgQDjWStV
      continue
    YHLKBXdRfTGvUakFocAhpIgQDjWSJi.append(YHLKBXdRfTGvUakFocAhpIgQDjWSJw)
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
   return YHLKBXdRfTGvUakFocAhpIgQDjWStN
  YHLKBXdRfTGvUakFocAhpIgQDjWSJt='\n'.join(YHLKBXdRfTGvUakFocAhpIgQDjWSJi)
  YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TextFile_Save(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV_STREAM_FILENAME,YHLKBXdRfTGvUakFocAhpIgQDjWSJt)
  return YHLKBXdRfTGvUakFocAhpIgQDjWStV
 def MediaLine_Parse(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,YHLKBXdRfTGvUakFocAhpIgQDjWSJw,prefix):
  YHLKBXdRfTGvUakFocAhpIgQDjWSJm={}
  for YHLKBXdRfTGvUakFocAhpIgQDjWSJb in YHLKBXdRfTGvUakFocAhpIgQDjWSnJ.split(YHLKBXdRfTGvUakFocAhpIgQDjWSJw.replace(prefix+':',''))[1::2]:
   YHLKBXdRfTGvUakFocAhpIgQDjWSJs,YHLKBXdRfTGvUakFocAhpIgQDjWSJe=YHLKBXdRfTGvUakFocAhpIgQDjWSJb.split('=',1)
   YHLKBXdRfTGvUakFocAhpIgQDjWSJm[YHLKBXdRfTGvUakFocAhpIgQDjWSJs.upper()]=YHLKBXdRfTGvUakFocAhpIgQDjWSJe.replace('"','').strip()
  return YHLKBXdRfTGvUakFocAhpIgQDjWSJm
 def CheckQuality(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,sel_qt,YHLKBXdRfTGvUakFocAhpIgQDjWSmw):
  for YHLKBXdRfTGvUakFocAhpIgQDjWSJE in YHLKBXdRfTGvUakFocAhpIgQDjWSmw:
   if sel_qt>=YHLKBXdRfTGvUakFocAhpIgQDjWSbm(YHLKBXdRfTGvUakFocAhpIgQDjWSJE)[0]:return YHLKBXdRfTGvUakFocAhpIgQDjWSJE.get(YHLKBXdRfTGvUakFocAhpIgQDjWSbm(YHLKBXdRfTGvUakFocAhpIgQDjWSJE)[0])
   YHLKBXdRfTGvUakFocAhpIgQDjWSJz=YHLKBXdRfTGvUakFocAhpIgQDjWSJE.get(YHLKBXdRfTGvUakFocAhpIgQDjWSbm(YHLKBXdRfTGvUakFocAhpIgQDjWSJE)[0])
  return YHLKBXdRfTGvUakFocAhpIgQDjWSJz
 def makeOocUrl(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,ooc_params):
  YHLKBXdRfTGvUakFocAhpIgQDjWSCV=''
  for YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSnV in ooc_params.items():
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV+="%s=%s^"%(YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSnV)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSCV
 def GetLiveChannelList(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,stype,page_int):
  YHLKBXdRfTGvUakFocAhpIgQDjWSwz=[]
  YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStN
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v2/media/lives'
   if stype=='onair': 
    YHLKBXdRfTGvUakFocAhpIgQDjWSJu='CPCS0100,CPCS0400'
   else:
    YHLKBXdRfTGvUakFocAhpIgQDjWSJu='CPCS0300'
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'cacheType':'main','pageNo':YHLKBXdRfTGvUakFocAhpIgQDjWStP(page_int),'pageSize':YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':YHLKBXdRfTGvUakFocAhpIgQDjWSJu,}
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWStM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if not('result' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']):return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
   YHLKBXdRfTGvUakFocAhpIgQDjWSJM=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']
   for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSJM:
    YHLKBXdRfTGvUakFocAhpIgQDjWSJN=YHLKBXdRfTGvUakFocAhpIgQDjWSJV=YHLKBXdRfTGvUakFocAhpIgQDjWSJr=''
    YHLKBXdRfTGvUakFocAhpIgQDjWSJP=YHLKBXdRfTGvUakFocAhpIgQDjWSiM=''
    YHLKBXdRfTGvUakFocAhpIgQDjWSJq=YHLKBXdRfTGvUakFocAhpIgQDjWSwP['live_code']
    YHLKBXdRfTGvUakFocAhpIgQDjWSJN =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['channel']['name']['ko']
    if YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['episode']!=YHLKBXdRfTGvUakFocAhpIgQDjWStM:
     YHLKBXdRfTGvUakFocAhpIgQDjWSJV =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['program']['name']['ko']
     YHLKBXdRfTGvUakFocAhpIgQDjWSJV =YHLKBXdRfTGvUakFocAhpIgQDjWSJV+', '+YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['episode']['frequency'])+'회'
     YHLKBXdRfTGvUakFocAhpIgQDjWSJr=YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['episode']['synopsis']['ko']
    else:
     YHLKBXdRfTGvUakFocAhpIgQDjWSJV =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['program']['name']['ko']
     YHLKBXdRfTGvUakFocAhpIgQDjWSJr=YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['program']['synopsis']['ko']
    try: 
     YHLKBXdRfTGvUakFocAhpIgQDjWSJy =''
     YHLKBXdRfTGvUakFocAhpIgQDjWSJl =''
     YHLKBXdRfTGvUakFocAhpIgQDjWSin=''
     YHLKBXdRfTGvUakFocAhpIgQDjWSiC =''
     YHLKBXdRfTGvUakFocAhpIgQDjWSiw =''
     YHLKBXdRfTGvUakFocAhpIgQDjWSim =''
     for YHLKBXdRfTGvUakFocAhpIgQDjWSiJ in YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['program']['image']:
      if YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP0900':YHLKBXdRfTGvUakFocAhpIgQDjWSJl =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
      elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP1800':YHLKBXdRfTGvUakFocAhpIgQDjWSin=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
      elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP2000':YHLKBXdRfTGvUakFocAhpIgQDjWSiC =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
      elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP1900':YHLKBXdRfTGvUakFocAhpIgQDjWSiw =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
      elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP0200':YHLKBXdRfTGvUakFocAhpIgQDjWSim =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
      elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP0500':YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
      elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP0800':YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     if YHLKBXdRfTGvUakFocAhpIgQDjWSJy=='':
      for YHLKBXdRfTGvUakFocAhpIgQDjWSiJ in YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['channel']['image']:
       if YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIC0400':YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
       elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIC1400':YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
       elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIC1900':YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
    except:
     YHLKBXdRfTGvUakFocAhpIgQDjWStM
    try:
     YHLKBXdRfTGvUakFocAhpIgQDjWSix =[]
     YHLKBXdRfTGvUakFocAhpIgQDjWSit=[]
     YHLKBXdRfTGvUakFocAhpIgQDjWSib =[]
     YHLKBXdRfTGvUakFocAhpIgQDjWSis=''
     YHLKBXdRfTGvUakFocAhpIgQDjWSie=''
     YHLKBXdRfTGvUakFocAhpIgQDjWSiE=''
     for YHLKBXdRfTGvUakFocAhpIgQDjWSiz in YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('schedule').get('program').get('actor'):
      if YHLKBXdRfTGvUakFocAhpIgQDjWSiz!='' and YHLKBXdRfTGvUakFocAhpIgQDjWSiz!=u'없음':YHLKBXdRfTGvUakFocAhpIgQDjWSix.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiz)
     for YHLKBXdRfTGvUakFocAhpIgQDjWSiO in YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('schedule').get('program').get('director'):
      if YHLKBXdRfTGvUakFocAhpIgQDjWSiO!='' and YHLKBXdRfTGvUakFocAhpIgQDjWSiO!='-' and YHLKBXdRfTGvUakFocAhpIgQDjWSiO!=u'없음':YHLKBXdRfTGvUakFocAhpIgQDjWSit.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiO)
     if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('schedule').get('program').get('category1_name').get('ko')!='':
      YHLKBXdRfTGvUakFocAhpIgQDjWSib.append(YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['program']['category1_name']['ko'])
     if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('schedule').get('program').get('category2_name').get('ko')!='':
      YHLKBXdRfTGvUakFocAhpIgQDjWSib.append(YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['program']['category2_name']['ko'])
     if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('schedule').get('program').get('product_year'):YHLKBXdRfTGvUakFocAhpIgQDjWSis=YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['program']['product_year']
     if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('schedule').get('program').get('grade_code') :YHLKBXdRfTGvUakFocAhpIgQDjWSie= YHLKBXdRfTGvUakFocAhpIgQDjWSnm.get(YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['program']['grade_code'])
     if 'broad_dt' in YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('schedule').get('program'):
      YHLKBXdRfTGvUakFocAhpIgQDjWSiu =YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('schedule').get('program').get('broad_dt')
      YHLKBXdRfTGvUakFocAhpIgQDjWSiE='%s-%s-%s'%(YHLKBXdRfTGvUakFocAhpIgQDjWSiu[:4],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[4:6],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[6:])
    except:
     YHLKBXdRfTGvUakFocAhpIgQDjWStM
    YHLKBXdRfTGvUakFocAhpIgQDjWSJP=YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['broadcast_start_time'])[8:12]
    YHLKBXdRfTGvUakFocAhpIgQDjWSiM =YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSwP['schedule']['broadcast_end_time'])[8:12]
    YHLKBXdRfTGvUakFocAhpIgQDjWSiN={'channel':YHLKBXdRfTGvUakFocAhpIgQDjWSJN,'title':YHLKBXdRfTGvUakFocAhpIgQDjWSJV,'mediacode':YHLKBXdRfTGvUakFocAhpIgQDjWSJq,'thumbnail':{'poster':YHLKBXdRfTGvUakFocAhpIgQDjWSJl,'thumb':YHLKBXdRfTGvUakFocAhpIgQDjWSJy,'clearlogo':YHLKBXdRfTGvUakFocAhpIgQDjWSin,'icon':YHLKBXdRfTGvUakFocAhpIgQDjWSiC,'fanart':YHLKBXdRfTGvUakFocAhpIgQDjWSim},'synopsis':YHLKBXdRfTGvUakFocAhpIgQDjWSJr,'channelepg':' [%s:%s ~ %s:%s]'%(YHLKBXdRfTGvUakFocAhpIgQDjWSJP[0:2],YHLKBXdRfTGvUakFocAhpIgQDjWSJP[2:],YHLKBXdRfTGvUakFocAhpIgQDjWSiM[0:2],YHLKBXdRfTGvUakFocAhpIgQDjWSiM[2:]),'cast':YHLKBXdRfTGvUakFocAhpIgQDjWSix,'director':YHLKBXdRfTGvUakFocAhpIgQDjWSit,'info_genre':YHLKBXdRfTGvUakFocAhpIgQDjWSib,'year':YHLKBXdRfTGvUakFocAhpIgQDjWSis,'mpaa':YHLKBXdRfTGvUakFocAhpIgQDjWSie,'premiered':YHLKBXdRfTGvUakFocAhpIgQDjWSiE}
    YHLKBXdRfTGvUakFocAhpIgQDjWSwz.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiN)
   if YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['has_more']=='Y':
    YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStV
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
 def GetProgramList(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,genre,orderby,page_int,genreCode='all'):
  YHLKBXdRfTGvUakFocAhpIgQDjWSwz=[]
  YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStN
  try:
   if genre=='PARAMOUNT':
    YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v2/media/paramount/episodes'
   else:
    YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v2/media/episodes'
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'cacheType':'main','pageSize':YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':YHLKBXdRfTGvUakFocAhpIgQDjWStP(page_int),}
   if genre not in['all','PARAMOUNT']:YHLKBXdRfTGvUakFocAhpIgQDjWSwM['categoryCode']=genre
   if genreCode!='all' :YHLKBXdRfTGvUakFocAhpIgQDjWSwM['genreCode'] =genreCode 
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWStM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if not('result' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']):return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
   YHLKBXdRfTGvUakFocAhpIgQDjWSJM=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']
   for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSJM:
    YHLKBXdRfTGvUakFocAhpIgQDjWSiP=YHLKBXdRfTGvUakFocAhpIgQDjWSwP['program']['code']
    YHLKBXdRfTGvUakFocAhpIgQDjWSJV =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['program']['name']['ko']
    YHLKBXdRfTGvUakFocAhpIgQDjWSie =YHLKBXdRfTGvUakFocAhpIgQDjWSnm.get(YHLKBXdRfTGvUakFocAhpIgQDjWSwP['program'].get('grade_code'))
    YHLKBXdRfTGvUakFocAhpIgQDjWSJl =''
    YHLKBXdRfTGvUakFocAhpIgQDjWSJy =''
    YHLKBXdRfTGvUakFocAhpIgQDjWSin=''
    YHLKBXdRfTGvUakFocAhpIgQDjWSiC =''
    YHLKBXdRfTGvUakFocAhpIgQDjWSiw =''
    for YHLKBXdRfTGvUakFocAhpIgQDjWSiJ in YHLKBXdRfTGvUakFocAhpIgQDjWSwP['program']['image']:
     if YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP0900':YHLKBXdRfTGvUakFocAhpIgQDjWSJl =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP0200':YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP1800':YHLKBXdRfTGvUakFocAhpIgQDjWSin=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP2000':YHLKBXdRfTGvUakFocAhpIgQDjWSiC =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP1900':YHLKBXdRfTGvUakFocAhpIgQDjWSiw =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
    YHLKBXdRfTGvUakFocAhpIgQDjWSJr =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['program']['synopsis']['ko']
    try:
     YHLKBXdRfTGvUakFocAhpIgQDjWSiq=YHLKBXdRfTGvUakFocAhpIgQDjWSwP['channel']['name']['ko']
    except:
     YHLKBXdRfTGvUakFocAhpIgQDjWSiq=''
    try:
     YHLKBXdRfTGvUakFocAhpIgQDjWSix =[]
     YHLKBXdRfTGvUakFocAhpIgQDjWSit=[]
     YHLKBXdRfTGvUakFocAhpIgQDjWSib =[]
     YHLKBXdRfTGvUakFocAhpIgQDjWSis =''
     YHLKBXdRfTGvUakFocAhpIgQDjWSiE=''
     for YHLKBXdRfTGvUakFocAhpIgQDjWSiz in YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('program').get('actor'):
      if YHLKBXdRfTGvUakFocAhpIgQDjWSiz!='' and YHLKBXdRfTGvUakFocAhpIgQDjWSiz!='-' and YHLKBXdRfTGvUakFocAhpIgQDjWSiz!=u'없음':YHLKBXdRfTGvUakFocAhpIgQDjWSix.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiz)
     for YHLKBXdRfTGvUakFocAhpIgQDjWSiO in YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('program').get('director'):
      if YHLKBXdRfTGvUakFocAhpIgQDjWSiO!='' and YHLKBXdRfTGvUakFocAhpIgQDjWSiO!='-' and YHLKBXdRfTGvUakFocAhpIgQDjWSiO!=u'없음':YHLKBXdRfTGvUakFocAhpIgQDjWSit.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiO)
     if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('program').get('category1_name').get('ko')!='':
      YHLKBXdRfTGvUakFocAhpIgQDjWSib.append(YHLKBXdRfTGvUakFocAhpIgQDjWSwP['program']['category1_name']['ko'])
     if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('program').get('category2_name').get('ko')!='':
      YHLKBXdRfTGvUakFocAhpIgQDjWSib.append(YHLKBXdRfTGvUakFocAhpIgQDjWSwP['program']['category2_name']['ko'])
     if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('program').get('product_year'):YHLKBXdRfTGvUakFocAhpIgQDjWSis=YHLKBXdRfTGvUakFocAhpIgQDjWSwP['program']['product_year']
     if 'broad_dt' in YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('program'):
      YHLKBXdRfTGvUakFocAhpIgQDjWSiu =YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('program').get('broad_dt')
      YHLKBXdRfTGvUakFocAhpIgQDjWSiE='%s-%s-%s'%(YHLKBXdRfTGvUakFocAhpIgQDjWSiu[:4],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[4:6],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[6:])
    except:
     YHLKBXdRfTGvUakFocAhpIgQDjWStM
    YHLKBXdRfTGvUakFocAhpIgQDjWSiN={'program':YHLKBXdRfTGvUakFocAhpIgQDjWSiP,'title':YHLKBXdRfTGvUakFocAhpIgQDjWSJV,'thumbnail':{'poster':YHLKBXdRfTGvUakFocAhpIgQDjWSJl,'thumb':YHLKBXdRfTGvUakFocAhpIgQDjWSJy,'clearlogo':YHLKBXdRfTGvUakFocAhpIgQDjWSin,'icon':YHLKBXdRfTGvUakFocAhpIgQDjWSiC,'banner':YHLKBXdRfTGvUakFocAhpIgQDjWSiw,'fanart':YHLKBXdRfTGvUakFocAhpIgQDjWSJy},'synopsis':YHLKBXdRfTGvUakFocAhpIgQDjWSJr,'channel':YHLKBXdRfTGvUakFocAhpIgQDjWSiq,'cast':YHLKBXdRfTGvUakFocAhpIgQDjWSix,'director':YHLKBXdRfTGvUakFocAhpIgQDjWSit,'info_genre':YHLKBXdRfTGvUakFocAhpIgQDjWSib,'year':YHLKBXdRfTGvUakFocAhpIgQDjWSis,'premiered':YHLKBXdRfTGvUakFocAhpIgQDjWSiE,'mpaa':YHLKBXdRfTGvUakFocAhpIgQDjWSie}
    YHLKBXdRfTGvUakFocAhpIgQDjWSwz.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiN)
   if YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['has_more']=='Y':YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStV
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
 def Get_UHD_ProgramList(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,page_int):
  YHLKBXdRfTGvUakFocAhpIgQDjWSwz=[]
  YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStN
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v2/operator/highlights'
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams(uhd=YHLKBXdRfTGvUakFocAhpIgQDjWStV)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':YHLKBXdRfTGvUakFocAhpIgQDjWStP(page_int),'pocType':'APP_X_TVING_4.0.0',}
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWStM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if not('result' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']):return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
   YHLKBXdRfTGvUakFocAhpIgQDjWSJM=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']
   for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSJM:
    YHLKBXdRfTGvUakFocAhpIgQDjWSiV=YHLKBXdRfTGvUakFocAhpIgQDjWSwP['content']['program']
    YHLKBXdRfTGvUakFocAhpIgQDjWSir =YHLKBXdRfTGvUakFocAhpIgQDjWSiV['code']
    YHLKBXdRfTGvUakFocAhpIgQDjWSJV =YHLKBXdRfTGvUakFocAhpIgQDjWSiV['name']['ko'].strip()
    YHLKBXdRfTGvUakFocAhpIgQDjWSie =YHLKBXdRfTGvUakFocAhpIgQDjWSnm.get(YHLKBXdRfTGvUakFocAhpIgQDjWSiV.get('grade_code'))
    YHLKBXdRfTGvUakFocAhpIgQDjWSJr =YHLKBXdRfTGvUakFocAhpIgQDjWSiV['synopsis']['ko']
    YHLKBXdRfTGvUakFocAhpIgQDjWSiq =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['content']['channel']['name']['ko']
    YHLKBXdRfTGvUakFocAhpIgQDjWSis =YHLKBXdRfTGvUakFocAhpIgQDjWSiV['product_year']
    YHLKBXdRfTGvUakFocAhpIgQDjWSJl =''
    YHLKBXdRfTGvUakFocAhpIgQDjWSJy =''
    YHLKBXdRfTGvUakFocAhpIgQDjWSin=''
    YHLKBXdRfTGvUakFocAhpIgQDjWSiC =''
    YHLKBXdRfTGvUakFocAhpIgQDjWSiw =''
    for YHLKBXdRfTGvUakFocAhpIgQDjWSiJ in YHLKBXdRfTGvUakFocAhpIgQDjWSiV['image']:
     if YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP0900':YHLKBXdRfTGvUakFocAhpIgQDjWSJl =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP0200':YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP1800':YHLKBXdRfTGvUakFocAhpIgQDjWSin=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP2000':YHLKBXdRfTGvUakFocAhpIgQDjWSiC =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP1900':YHLKBXdRfTGvUakFocAhpIgQDjWSiw =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
    YHLKBXdRfTGvUakFocAhpIgQDjWSib =[]
    YHLKBXdRfTGvUakFocAhpIgQDjWSix =[]
    YHLKBXdRfTGvUakFocAhpIgQDjWSit=[]
    YHLKBXdRfTGvUakFocAhpIgQDjWSiE =''
    if YHLKBXdRfTGvUakFocAhpIgQDjWSiV.get('category1_name').get('ko')!='':
     YHLKBXdRfTGvUakFocAhpIgQDjWSib.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiV['category1_name']['ko'])
    if YHLKBXdRfTGvUakFocAhpIgQDjWSiV.get('category2_name').get('ko')!='':
     YHLKBXdRfTGvUakFocAhpIgQDjWSib.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiV['category2_name']['ko'])
    for YHLKBXdRfTGvUakFocAhpIgQDjWSiz in YHLKBXdRfTGvUakFocAhpIgQDjWSiV.get('actor'):
     if YHLKBXdRfTGvUakFocAhpIgQDjWSiz!='' and YHLKBXdRfTGvUakFocAhpIgQDjWSiz!='-' and YHLKBXdRfTGvUakFocAhpIgQDjWSiz!=u'없음':YHLKBXdRfTGvUakFocAhpIgQDjWSix.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiz)
    for YHLKBXdRfTGvUakFocAhpIgQDjWSiO in YHLKBXdRfTGvUakFocAhpIgQDjWSiV.get('director'):
     if YHLKBXdRfTGvUakFocAhpIgQDjWSiO!='' and YHLKBXdRfTGvUakFocAhpIgQDjWSiO!='-' and YHLKBXdRfTGvUakFocAhpIgQDjWSiO!=u'없음':YHLKBXdRfTGvUakFocAhpIgQDjWSit.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiO)
    if YHLKBXdRfTGvUakFocAhpIgQDjWSiV.get('broad_dt')not in[YHLKBXdRfTGvUakFocAhpIgQDjWStM,'']:
     YHLKBXdRfTGvUakFocAhpIgQDjWSiu =YHLKBXdRfTGvUakFocAhpIgQDjWSiV.get('broad_dt')
     YHLKBXdRfTGvUakFocAhpIgQDjWSiE='%s-%s-%s'%(YHLKBXdRfTGvUakFocAhpIgQDjWSiu[:4],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[4:6],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[6:])
    YHLKBXdRfTGvUakFocAhpIgQDjWSiN={'program':YHLKBXdRfTGvUakFocAhpIgQDjWSir,'title':YHLKBXdRfTGvUakFocAhpIgQDjWSJV,'mpaa':YHLKBXdRfTGvUakFocAhpIgQDjWSie,'thumbnail':{'poster':YHLKBXdRfTGvUakFocAhpIgQDjWSJl,'thumb':YHLKBXdRfTGvUakFocAhpIgQDjWSJy,'clearlogo':YHLKBXdRfTGvUakFocAhpIgQDjWSin,'icon':YHLKBXdRfTGvUakFocAhpIgQDjWSiC,'banner':YHLKBXdRfTGvUakFocAhpIgQDjWSiw,'fanart':YHLKBXdRfTGvUakFocAhpIgQDjWSJy},'channel':YHLKBXdRfTGvUakFocAhpIgQDjWSiq,'synopsis':YHLKBXdRfTGvUakFocAhpIgQDjWSJr,'year':YHLKBXdRfTGvUakFocAhpIgQDjWSis,'info_genre':YHLKBXdRfTGvUakFocAhpIgQDjWSib,'cast':YHLKBXdRfTGvUakFocAhpIgQDjWSix,'director':YHLKBXdRfTGvUakFocAhpIgQDjWSit,'premiered':YHLKBXdRfTGvUakFocAhpIgQDjWSiE,}
    YHLKBXdRfTGvUakFocAhpIgQDjWSwz.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiN)
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
 def Get_Origianl_ProgramList(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,page_int):
  YHLKBXdRfTGvUakFocAhpIgQDjWSwz=[]
  YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStN
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v2/media/band/originals'
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'pageSize':YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':YHLKBXdRfTGvUakFocAhpIgQDjWStP(page_int),}
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWStM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSiy=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   YHLKBXdRfTGvUakFocAhpIgQDjWSnx.JsonFile_Save(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV_SESSION_COOKIES2,YHLKBXdRfTGvUakFocAhpIgQDjWSiy)
   if not('contents' in YHLKBXdRfTGvUakFocAhpIgQDjWSiy['body']):return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
   YHLKBXdRfTGvUakFocAhpIgQDjWSJM=YHLKBXdRfTGvUakFocAhpIgQDjWSiy['body']['contents']
   for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSJM:
    YHLKBXdRfTGvUakFocAhpIgQDjWSil =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['vod_code']
    YHLKBXdRfTGvUakFocAhpIgQDjWSJV =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['vod_name']
    YHLKBXdRfTGvUakFocAhpIgQDjWSJl =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSwP['image']
    YHLKBXdRfTGvUakFocAhpIgQDjWSxn ='movie' if YHLKBXdRfTGvUakFocAhpIgQDjWSil.startswith('M')else 'vod'
    YHLKBXdRfTGvUakFocAhpIgQDjWSiN={'vod_code':YHLKBXdRfTGvUakFocAhpIgQDjWSil,'title':YHLKBXdRfTGvUakFocAhpIgQDjWSJV,'thumbnail':{'poster':YHLKBXdRfTGvUakFocAhpIgQDjWSJl,'thumb':YHLKBXdRfTGvUakFocAhpIgQDjWSJl},'vod_type':YHLKBXdRfTGvUakFocAhpIgQDjWSxn,}
    YHLKBXdRfTGvUakFocAhpIgQDjWSwz.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiN)
   if YHLKBXdRfTGvUakFocAhpIgQDjWSiy['body']['has_more']=='Y':YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStV
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
 def GetEpisodeList(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,program_code,page_int,orderby='desc'):
  YHLKBXdRfTGvUakFocAhpIgQDjWSwz=[]
  YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStN
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v2/media/frequency/program/'+program_code
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWStM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if not('result' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']):return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
   YHLKBXdRfTGvUakFocAhpIgQDjWSJM=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']
   YHLKBXdRfTGvUakFocAhpIgQDjWSxC=YHLKBXdRfTGvUakFocAhpIgQDjWSty(YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['total_count'])
   YHLKBXdRfTGvUakFocAhpIgQDjWSxw =YHLKBXdRfTGvUakFocAhpIgQDjWSty(YHLKBXdRfTGvUakFocAhpIgQDjWSxC//(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    YHLKBXdRfTGvUakFocAhpIgQDjWSxm =(YHLKBXdRfTGvUakFocAhpIgQDjWSxC-1)-((page_int-1)*YHLKBXdRfTGvUakFocAhpIgQDjWSnx.EPISODE_LIMIT)
   else:
    YHLKBXdRfTGvUakFocAhpIgQDjWSxm =(page_int-1)*YHLKBXdRfTGvUakFocAhpIgQDjWSnx.EPISODE_LIMIT
   for i in YHLKBXdRfTGvUakFocAhpIgQDjWStl(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.EPISODE_LIMIT):
    if orderby=='desc':
     YHLKBXdRfTGvUakFocAhpIgQDjWSxJ=YHLKBXdRfTGvUakFocAhpIgQDjWSxm-i
     if YHLKBXdRfTGvUakFocAhpIgQDjWSxJ<0:break
    else:
     YHLKBXdRfTGvUakFocAhpIgQDjWSxJ=YHLKBXdRfTGvUakFocAhpIgQDjWSxm+i
     if YHLKBXdRfTGvUakFocAhpIgQDjWSxJ>=YHLKBXdRfTGvUakFocAhpIgQDjWSxC:break
    YHLKBXdRfTGvUakFocAhpIgQDjWSxi=YHLKBXdRfTGvUakFocAhpIgQDjWSJM[YHLKBXdRfTGvUakFocAhpIgQDjWSxJ]['episode']['code']
    YHLKBXdRfTGvUakFocAhpIgQDjWSJV =YHLKBXdRfTGvUakFocAhpIgQDjWSJM[YHLKBXdRfTGvUakFocAhpIgQDjWSxJ]['vod_name']['ko']
    YHLKBXdRfTGvUakFocAhpIgQDjWSxt =''
    try:
     YHLKBXdRfTGvUakFocAhpIgQDjWSiu=YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSJM[YHLKBXdRfTGvUakFocAhpIgQDjWSxJ]['episode']['broadcast_date'])
     YHLKBXdRfTGvUakFocAhpIgQDjWSxt='%s-%s-%s'%(YHLKBXdRfTGvUakFocAhpIgQDjWSiu[:4],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[4:6],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[6:])
    except:
     YHLKBXdRfTGvUakFocAhpIgQDjWStM
    try:
     if YHLKBXdRfTGvUakFocAhpIgQDjWSJM[YHLKBXdRfTGvUakFocAhpIgQDjWSxJ]['episode']['pip_cliptype']=='C012':
      YHLKBXdRfTGvUakFocAhpIgQDjWSxt+=' - Quick VOD'
    except:
     YHLKBXdRfTGvUakFocAhpIgQDjWStM
    YHLKBXdRfTGvUakFocAhpIgQDjWSJr =YHLKBXdRfTGvUakFocAhpIgQDjWSJM[YHLKBXdRfTGvUakFocAhpIgQDjWSxJ]['episode']['synopsis']['ko']
    YHLKBXdRfTGvUakFocAhpIgQDjWSJl =''
    YHLKBXdRfTGvUakFocAhpIgQDjWSJy =''
    YHLKBXdRfTGvUakFocAhpIgQDjWSin=''
    YHLKBXdRfTGvUakFocAhpIgQDjWSiC =''
    YHLKBXdRfTGvUakFocAhpIgQDjWSiw =''
    YHLKBXdRfTGvUakFocAhpIgQDjWSim =''
    for YHLKBXdRfTGvUakFocAhpIgQDjWSiJ in YHLKBXdRfTGvUakFocAhpIgQDjWSJM[YHLKBXdRfTGvUakFocAhpIgQDjWSxJ]['program']['image']:
     if YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP0900':YHLKBXdRfTGvUakFocAhpIgQDjWSJl =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP1800':YHLKBXdRfTGvUakFocAhpIgQDjWSin=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP2000':YHLKBXdRfTGvUakFocAhpIgQDjWSiC =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP1900':YHLKBXdRfTGvUakFocAhpIgQDjWSiw =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIP0200':YHLKBXdRfTGvUakFocAhpIgQDjWSim =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
    for YHLKBXdRfTGvUakFocAhpIgQDjWSiJ in YHLKBXdRfTGvUakFocAhpIgQDjWSJM[YHLKBXdRfTGvUakFocAhpIgQDjWSxJ]['episode']['image']:
     if YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIE0400':YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
    try:
     YHLKBXdRfTGvUakFocAhpIgQDjWSxb=YHLKBXdRfTGvUakFocAhpIgQDjWSxe=YHLKBXdRfTGvUakFocAhpIgQDjWSxE=''
     YHLKBXdRfTGvUakFocAhpIgQDjWSxs=0
     YHLKBXdRfTGvUakFocAhpIgQDjWSxb =YHLKBXdRfTGvUakFocAhpIgQDjWSJM[YHLKBXdRfTGvUakFocAhpIgQDjWSxJ]['program']['name']['ko']
     YHLKBXdRfTGvUakFocAhpIgQDjWSxe =YHLKBXdRfTGvUakFocAhpIgQDjWSxt
     YHLKBXdRfTGvUakFocAhpIgQDjWSxE =YHLKBXdRfTGvUakFocAhpIgQDjWSJM[YHLKBXdRfTGvUakFocAhpIgQDjWSxJ]['channel']['name']['ko']
     if 'frequency' in YHLKBXdRfTGvUakFocAhpIgQDjWSJM[YHLKBXdRfTGvUakFocAhpIgQDjWSxJ]['episode']:YHLKBXdRfTGvUakFocAhpIgQDjWSxs=YHLKBXdRfTGvUakFocAhpIgQDjWSJM[YHLKBXdRfTGvUakFocAhpIgQDjWSxJ]['episode']['frequency']
    except:
     YHLKBXdRfTGvUakFocAhpIgQDjWStM
    YHLKBXdRfTGvUakFocAhpIgQDjWSiN={'episode':YHLKBXdRfTGvUakFocAhpIgQDjWSxi,'title':YHLKBXdRfTGvUakFocAhpIgQDjWSJV,'subtitle':YHLKBXdRfTGvUakFocAhpIgQDjWSxt,'thumbnail':{'poster':YHLKBXdRfTGvUakFocAhpIgQDjWSJl,'thumb':YHLKBXdRfTGvUakFocAhpIgQDjWSJy,'clearlogo':YHLKBXdRfTGvUakFocAhpIgQDjWSin,'icon':YHLKBXdRfTGvUakFocAhpIgQDjWSiC,'banner':YHLKBXdRfTGvUakFocAhpIgQDjWSiw,'fanart':YHLKBXdRfTGvUakFocAhpIgQDjWSim},'synopsis':YHLKBXdRfTGvUakFocAhpIgQDjWSJr,'info_title':YHLKBXdRfTGvUakFocAhpIgQDjWSxb,'aired':YHLKBXdRfTGvUakFocAhpIgQDjWSxe,'studio':YHLKBXdRfTGvUakFocAhpIgQDjWSxE,'frequency':YHLKBXdRfTGvUakFocAhpIgQDjWSxs}
    YHLKBXdRfTGvUakFocAhpIgQDjWSwz.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiN)
   if YHLKBXdRfTGvUakFocAhpIgQDjWSxw>page_int:YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStV
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO,YHLKBXdRfTGvUakFocAhpIgQDjWSxw
 def GetMovieList(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,genre,orderby,page_int):
  YHLKBXdRfTGvUakFocAhpIgQDjWSwz=[]
  YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStN
  try:
   if genre=='PARAMOUNT':
    YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v2/media/paramount/movies'
   else:
    YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v2/media/movies'
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'pageSize':YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':YHLKBXdRfTGvUakFocAhpIgQDjWStP(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:YHLKBXdRfTGvUakFocAhpIgQDjWSwM['categoryCode']=genre
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM['productPackageCode']=','.join(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.MOVIE_LITE)
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWStM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if not('result' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']):return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
   YHLKBXdRfTGvUakFocAhpIgQDjWSJM=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']
   for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSJM:
    if 'release_date' in YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('movie'):
     YHLKBXdRfTGvUakFocAhpIgQDjWSis=YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('movie').get('release_date'))[:4]
    else:
     YHLKBXdRfTGvUakFocAhpIgQDjWSis=YHLKBXdRfTGvUakFocAhpIgQDjWStM
    YHLKBXdRfTGvUakFocAhpIgQDjWSxz =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['movie']['code']
    YHLKBXdRfTGvUakFocAhpIgQDjWSJV =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['movie']['name']['ko'].strip()
    if YHLKBXdRfTGvUakFocAhpIgQDjWSis not in[YHLKBXdRfTGvUakFocAhpIgQDjWStM,'0','']:YHLKBXdRfTGvUakFocAhpIgQDjWSJV+=u' (%s)'%(YHLKBXdRfTGvUakFocAhpIgQDjWSis)
    YHLKBXdRfTGvUakFocAhpIgQDjWSJl=''
    YHLKBXdRfTGvUakFocAhpIgQDjWSJy =''
    YHLKBXdRfTGvUakFocAhpIgQDjWSin=''
    for YHLKBXdRfTGvUakFocAhpIgQDjWSiJ in YHLKBXdRfTGvUakFocAhpIgQDjWSwP['movie']['image']:
     if YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIM2100':YHLKBXdRfTGvUakFocAhpIgQDjWSJl =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIM0400':YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIM1800':YHLKBXdRfTGvUakFocAhpIgQDjWSin=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
    YHLKBXdRfTGvUakFocAhpIgQDjWSJr =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['movie']['story']['ko']
    try:
     YHLKBXdRfTGvUakFocAhpIgQDjWSxb =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['movie']['name']['ko'].strip()
     YHLKBXdRfTGvUakFocAhpIgQDjWSie =YHLKBXdRfTGvUakFocAhpIgQDjWSnm.get(YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('grade_code'))
     YHLKBXdRfTGvUakFocAhpIgQDjWSix=[]
     YHLKBXdRfTGvUakFocAhpIgQDjWSit=[]
     YHLKBXdRfTGvUakFocAhpIgQDjWSib=[]
     YHLKBXdRfTGvUakFocAhpIgQDjWSxO=0
     YHLKBXdRfTGvUakFocAhpIgQDjWSiE=''
     YHLKBXdRfTGvUakFocAhpIgQDjWSxE =''
     for YHLKBXdRfTGvUakFocAhpIgQDjWSiz in YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('movie').get('actor'):
      if YHLKBXdRfTGvUakFocAhpIgQDjWSiz!='':YHLKBXdRfTGvUakFocAhpIgQDjWSix.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiz)
     for YHLKBXdRfTGvUakFocAhpIgQDjWSiO in YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('movie').get('director'):
      if YHLKBXdRfTGvUakFocAhpIgQDjWSiO!='':YHLKBXdRfTGvUakFocAhpIgQDjWSit.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiO)
     if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('movie').get('category1_name').get('ko')!='':
      YHLKBXdRfTGvUakFocAhpIgQDjWSib.append(YHLKBXdRfTGvUakFocAhpIgQDjWSwP['movie']['category1_name']['ko'])
     if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('movie').get('category2_name').get('ko')!='':
      YHLKBXdRfTGvUakFocAhpIgQDjWSib.append(YHLKBXdRfTGvUakFocAhpIgQDjWSwP['movie']['category2_name']['ko'])
     if 'duration' in YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('movie'):YHLKBXdRfTGvUakFocAhpIgQDjWSxO=YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('movie').get('duration')
     if 'release_date' in YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('movie'):
      YHLKBXdRfTGvUakFocAhpIgQDjWSiu=YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('movie').get('release_date'))
      if YHLKBXdRfTGvUakFocAhpIgQDjWSiu!='0':YHLKBXdRfTGvUakFocAhpIgQDjWSiE='%s-%s-%s'%(YHLKBXdRfTGvUakFocAhpIgQDjWSiu[:4],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[4:6],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[6:])
     if 'production' in YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('movie'):YHLKBXdRfTGvUakFocAhpIgQDjWSxE=YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('movie').get('production')
    except:
     YHLKBXdRfTGvUakFocAhpIgQDjWStM
    YHLKBXdRfTGvUakFocAhpIgQDjWSiN={'moviecode':YHLKBXdRfTGvUakFocAhpIgQDjWSxz,'title':YHLKBXdRfTGvUakFocAhpIgQDjWSJV,'thumbnail':{'poster':YHLKBXdRfTGvUakFocAhpIgQDjWSJl,'thumb':YHLKBXdRfTGvUakFocAhpIgQDjWSJy,'clearlogo':YHLKBXdRfTGvUakFocAhpIgQDjWSin,'fanart':YHLKBXdRfTGvUakFocAhpIgQDjWSJy},'synopsis':YHLKBXdRfTGvUakFocAhpIgQDjWSJr,'info_title':YHLKBXdRfTGvUakFocAhpIgQDjWSxb,'year':YHLKBXdRfTGvUakFocAhpIgQDjWSis,'cast':YHLKBXdRfTGvUakFocAhpIgQDjWSix,'director':YHLKBXdRfTGvUakFocAhpIgQDjWSit,'info_genre':YHLKBXdRfTGvUakFocAhpIgQDjWSib,'duration':YHLKBXdRfTGvUakFocAhpIgQDjWSxO,'premiered':YHLKBXdRfTGvUakFocAhpIgQDjWSiE,'studio':YHLKBXdRfTGvUakFocAhpIgQDjWSxE,'mpaa':YHLKBXdRfTGvUakFocAhpIgQDjWSie}
    YHLKBXdRfTGvUakFocAhpIgQDjWSxu=YHLKBXdRfTGvUakFocAhpIgQDjWStN
    for YHLKBXdRfTGvUakFocAhpIgQDjWSxM in YHLKBXdRfTGvUakFocAhpIgQDjWSwP['billing_package_id']:
     if YHLKBXdRfTGvUakFocAhpIgQDjWSxM in YHLKBXdRfTGvUakFocAhpIgQDjWSnx.MOVIE_LITE:
      YHLKBXdRfTGvUakFocAhpIgQDjWSxu=YHLKBXdRfTGvUakFocAhpIgQDjWStV
      break
    if YHLKBXdRfTGvUakFocAhpIgQDjWSxu==YHLKBXdRfTGvUakFocAhpIgQDjWStN: 
     YHLKBXdRfTGvUakFocAhpIgQDjWSiN['title']=YHLKBXdRfTGvUakFocAhpIgQDjWSiN['title']+' [개별구매]'
    YHLKBXdRfTGvUakFocAhpIgQDjWSwz.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiN)
   if YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['has_more']=='Y':YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStV
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
 def Get_UHD_MovieList(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,page_int):
  YHLKBXdRfTGvUakFocAhpIgQDjWSwz=[]
  YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStN
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v2/operator/highlights'
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams(uhd=YHLKBXdRfTGvUakFocAhpIgQDjWStV)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':YHLKBXdRfTGvUakFocAhpIgQDjWStP(page_int),'pocType':'APP_X_TVING_4.0.0',}
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWStM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if not('result' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']):return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
   YHLKBXdRfTGvUakFocAhpIgQDjWSJM=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']
   for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSJM:
    YHLKBXdRfTGvUakFocAhpIgQDjWSiV=YHLKBXdRfTGvUakFocAhpIgQDjWSwP['content']['movie']
    YHLKBXdRfTGvUakFocAhpIgQDjWSir =YHLKBXdRfTGvUakFocAhpIgQDjWSiV['code']
    YHLKBXdRfTGvUakFocAhpIgQDjWSJV =YHLKBXdRfTGvUakFocAhpIgQDjWSiV['name']['ko'].strip()
    YHLKBXdRfTGvUakFocAhpIgQDjWSxb =YHLKBXdRfTGvUakFocAhpIgQDjWSiV['name']['ko'].strip()
    YHLKBXdRfTGvUakFocAhpIgQDjWSis =YHLKBXdRfTGvUakFocAhpIgQDjWSiV['product_year']
    if YHLKBXdRfTGvUakFocAhpIgQDjWSis:YHLKBXdRfTGvUakFocAhpIgQDjWSJV+=u' (%s)'%(YHLKBXdRfTGvUakFocAhpIgQDjWSiV['product_year'])
    YHLKBXdRfTGvUakFocAhpIgQDjWSJr =YHLKBXdRfTGvUakFocAhpIgQDjWSiV['story']['ko']
    YHLKBXdRfTGvUakFocAhpIgQDjWSxO =YHLKBXdRfTGvUakFocAhpIgQDjWSiV['duration']
    YHLKBXdRfTGvUakFocAhpIgQDjWSie =YHLKBXdRfTGvUakFocAhpIgQDjWSnm.get(YHLKBXdRfTGvUakFocAhpIgQDjWSiV.get('grade_code'))
    YHLKBXdRfTGvUakFocAhpIgQDjWSxE =YHLKBXdRfTGvUakFocAhpIgQDjWSiV['production']
    YHLKBXdRfTGvUakFocAhpIgQDjWSJl=''
    YHLKBXdRfTGvUakFocAhpIgQDjWSJy =''
    YHLKBXdRfTGvUakFocAhpIgQDjWSin=''
    YHLKBXdRfTGvUakFocAhpIgQDjWSib =[]
    YHLKBXdRfTGvUakFocAhpIgQDjWSix =[]
    YHLKBXdRfTGvUakFocAhpIgQDjWSit=[]
    YHLKBXdRfTGvUakFocAhpIgQDjWSiE =''
    for YHLKBXdRfTGvUakFocAhpIgQDjWSiJ in YHLKBXdRfTGvUakFocAhpIgQDjWSiV['image']:
     if YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIM2100':YHLKBXdRfTGvUakFocAhpIgQDjWSJl =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIM0400':YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
     elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['code']=='CAIM1800':YHLKBXdRfTGvUakFocAhpIgQDjWSin=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ['url']
    if YHLKBXdRfTGvUakFocAhpIgQDjWSiV['release_date']not in[YHLKBXdRfTGvUakFocAhpIgQDjWStM,0]:
     YHLKBXdRfTGvUakFocAhpIgQDjWSiu=YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSiV['release_date'])
     if YHLKBXdRfTGvUakFocAhpIgQDjWSiu!='0':YHLKBXdRfTGvUakFocAhpIgQDjWSiE='%s-%s-%s'%(YHLKBXdRfTGvUakFocAhpIgQDjWSiu[:4],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[4:6],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[6:])
    if YHLKBXdRfTGvUakFocAhpIgQDjWSiV.get('category1_name').get('ko')!='':
     YHLKBXdRfTGvUakFocAhpIgQDjWSib.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiV['category1_name']['ko'])
    if YHLKBXdRfTGvUakFocAhpIgQDjWSiV.get('category2_name').get('ko')!='':
     YHLKBXdRfTGvUakFocAhpIgQDjWSib.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiV['category2_name']['ko'])
    for YHLKBXdRfTGvUakFocAhpIgQDjWSiz in YHLKBXdRfTGvUakFocAhpIgQDjWSiV.get('actor'):
     if YHLKBXdRfTGvUakFocAhpIgQDjWSiz!='':YHLKBXdRfTGvUakFocAhpIgQDjWSix.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiz)
    for YHLKBXdRfTGvUakFocAhpIgQDjWSiO in YHLKBXdRfTGvUakFocAhpIgQDjWSiV.get('director'):
     if YHLKBXdRfTGvUakFocAhpIgQDjWSiO!='':YHLKBXdRfTGvUakFocAhpIgQDjWSit.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiO)
    YHLKBXdRfTGvUakFocAhpIgQDjWSiN={'moviecode':YHLKBXdRfTGvUakFocAhpIgQDjWSir,'title':YHLKBXdRfTGvUakFocAhpIgQDjWSJV,'thumbnail':{'poster':YHLKBXdRfTGvUakFocAhpIgQDjWSJl,'thumb':YHLKBXdRfTGvUakFocAhpIgQDjWSJy,'clearlogo':YHLKBXdRfTGvUakFocAhpIgQDjWSin,'fanart':YHLKBXdRfTGvUakFocAhpIgQDjWSJy},'year':YHLKBXdRfTGvUakFocAhpIgQDjWSis,'info_title':YHLKBXdRfTGvUakFocAhpIgQDjWSxb,'synopsis':YHLKBXdRfTGvUakFocAhpIgQDjWSJr,'mpaa':YHLKBXdRfTGvUakFocAhpIgQDjWSie,'duration':YHLKBXdRfTGvUakFocAhpIgQDjWSxO,'premiered':YHLKBXdRfTGvUakFocAhpIgQDjWSiE,'studio':YHLKBXdRfTGvUakFocAhpIgQDjWSxE,'info_genre':YHLKBXdRfTGvUakFocAhpIgQDjWSib,'cast':YHLKBXdRfTGvUakFocAhpIgQDjWSix,'director':YHLKBXdRfTGvUakFocAhpIgQDjWSit,}
    YHLKBXdRfTGvUakFocAhpIgQDjWSwz.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiN)
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
 def GetMovieGenre(YHLKBXdRfTGvUakFocAhpIgQDjWSnx):
  YHLKBXdRfTGvUakFocAhpIgQDjWSwz=[]
  YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStN
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v2/media/movie/curations'
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWStM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if not('result' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']):return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
   YHLKBXdRfTGvUakFocAhpIgQDjWSJM=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']
   for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSJM:
    YHLKBXdRfTGvUakFocAhpIgQDjWSxN =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['curation_code']
    YHLKBXdRfTGvUakFocAhpIgQDjWSxP =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['curation_name']
    YHLKBXdRfTGvUakFocAhpIgQDjWSiN={'curation_code':YHLKBXdRfTGvUakFocAhpIgQDjWSxN,'curation_name':YHLKBXdRfTGvUakFocAhpIgQDjWSxP}
    YHLKBXdRfTGvUakFocAhpIgQDjWSwz.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiN)
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
 def GetSearchList(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,search_key,page_int,stype):
  YHLKBXdRfTGvUakFocAhpIgQDjWSxq=[]
  YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStN
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/search/getSearch.jsp'
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':YHLKBXdRfTGvUakFocAhpIgQDjWStP(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.SCREENCODE,'os':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.OSCODE,'network':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.APIKEY,'networkCode':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.NETWORKCODE,'osCode ':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.OSCODE,'teleCode ':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TELECODE,'screenCode ':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.SCREENCODE}
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.SEARCH_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSwM,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWStM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if stype=='vod':
    if not('programRsb' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN):return YHLKBXdRfTGvUakFocAhpIgQDjWSxq,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
    YHLKBXdRfTGvUakFocAhpIgQDjWSxV=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['programRsb']['dataList']
    YHLKBXdRfTGvUakFocAhpIgQDjWSxr =YHLKBXdRfTGvUakFocAhpIgQDjWSty(YHLKBXdRfTGvUakFocAhpIgQDjWSwN['programRsb']['count'])
    for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSxV:
     YHLKBXdRfTGvUakFocAhpIgQDjWSiP=YHLKBXdRfTGvUakFocAhpIgQDjWSwP['mast_cd']
     YHLKBXdRfTGvUakFocAhpIgQDjWSJV =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['mast_nm']
     YHLKBXdRfTGvUakFocAhpIgQDjWSJl=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSwP['web_url4']
     YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSwP['web_url']
     try:
      YHLKBXdRfTGvUakFocAhpIgQDjWSix =[]
      YHLKBXdRfTGvUakFocAhpIgQDjWSit=[]
      YHLKBXdRfTGvUakFocAhpIgQDjWSib =[]
      YHLKBXdRfTGvUakFocAhpIgQDjWSxO =0
      YHLKBXdRfTGvUakFocAhpIgQDjWSie =''
      YHLKBXdRfTGvUakFocAhpIgQDjWSis =''
      YHLKBXdRfTGvUakFocAhpIgQDjWSxe =''
      if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('actor') !='' and YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('actor') !='-':YHLKBXdRfTGvUakFocAhpIgQDjWSix =YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('actor').split(',')
      if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('director')!='' and YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('director')!='-':YHLKBXdRfTGvUakFocAhpIgQDjWSit=YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('director').split(',')
      if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('cate_nm')!='' and YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('cate_nm')!='-':YHLKBXdRfTGvUakFocAhpIgQDjWSib =YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('cate_nm').split('/')
      if 'targetage' in YHLKBXdRfTGvUakFocAhpIgQDjWSwP:YHLKBXdRfTGvUakFocAhpIgQDjWSie=YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('targetage')
      if 'broad_dt' in YHLKBXdRfTGvUakFocAhpIgQDjWSwP:
       YHLKBXdRfTGvUakFocAhpIgQDjWSiu=YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('broad_dt')
       YHLKBXdRfTGvUakFocAhpIgQDjWSxe='%s-%s-%s'%(YHLKBXdRfTGvUakFocAhpIgQDjWSiu[:4],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[4:6],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[6:])
       YHLKBXdRfTGvUakFocAhpIgQDjWSis =YHLKBXdRfTGvUakFocAhpIgQDjWSiu[:4]
     except:
      YHLKBXdRfTGvUakFocAhpIgQDjWStM
     YHLKBXdRfTGvUakFocAhpIgQDjWSiN={'program':YHLKBXdRfTGvUakFocAhpIgQDjWSiP,'title':YHLKBXdRfTGvUakFocAhpIgQDjWSJV,'thumbnail':{'poster':YHLKBXdRfTGvUakFocAhpIgQDjWSJl,'thumb':YHLKBXdRfTGvUakFocAhpIgQDjWSJy,'fanart':YHLKBXdRfTGvUakFocAhpIgQDjWSJy},'synopsis':'','cast':YHLKBXdRfTGvUakFocAhpIgQDjWSix,'director':YHLKBXdRfTGvUakFocAhpIgQDjWSit,'info_genre':YHLKBXdRfTGvUakFocAhpIgQDjWSib,'duration':YHLKBXdRfTGvUakFocAhpIgQDjWSxO,'mpaa':YHLKBXdRfTGvUakFocAhpIgQDjWSie,'year':YHLKBXdRfTGvUakFocAhpIgQDjWSis,'aired':YHLKBXdRfTGvUakFocAhpIgQDjWSxe}
     YHLKBXdRfTGvUakFocAhpIgQDjWSxq.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiN)
   else:
    if not('vodMVRsb' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN):return YHLKBXdRfTGvUakFocAhpIgQDjWSxq,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
    YHLKBXdRfTGvUakFocAhpIgQDjWSxy=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['vodMVRsb']['dataList']
    YHLKBXdRfTGvUakFocAhpIgQDjWSxr =YHLKBXdRfTGvUakFocAhpIgQDjWSty(YHLKBXdRfTGvUakFocAhpIgQDjWSwN['vodMVRsb']['count'])
    for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSxy:
     YHLKBXdRfTGvUakFocAhpIgQDjWSiP=YHLKBXdRfTGvUakFocAhpIgQDjWSwP['mast_cd']
     YHLKBXdRfTGvUakFocAhpIgQDjWSJV =YHLKBXdRfTGvUakFocAhpIgQDjWSwP['mast_nm'].strip()
     YHLKBXdRfTGvUakFocAhpIgQDjWSJl =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSwP['web_url']
     YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSJl
     YHLKBXdRfTGvUakFocAhpIgQDjWSin=''
     try:
      YHLKBXdRfTGvUakFocAhpIgQDjWSix =[]
      YHLKBXdRfTGvUakFocAhpIgQDjWSit=[]
      YHLKBXdRfTGvUakFocAhpIgQDjWSib =[]
      YHLKBXdRfTGvUakFocAhpIgQDjWSxO =0
      YHLKBXdRfTGvUakFocAhpIgQDjWSie =''
      YHLKBXdRfTGvUakFocAhpIgQDjWSis =''
      YHLKBXdRfTGvUakFocAhpIgQDjWSxe =''
      if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('actor') !='' and YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('actor') !='-':YHLKBXdRfTGvUakFocAhpIgQDjWSix =YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('actor').split(',')
      if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('director')!='' and YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('director')!='-':YHLKBXdRfTGvUakFocAhpIgQDjWSit=YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('director').split(',')
      if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('cate_nm')!='' and YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('cate_nm')!='-':YHLKBXdRfTGvUakFocAhpIgQDjWSib =YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('cate_nm').split('/')
      if YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('runtime_sec')!='':YHLKBXdRfTGvUakFocAhpIgQDjWSxO=YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('runtime_sec')
      if 'grade_nm' in YHLKBXdRfTGvUakFocAhpIgQDjWSwP:YHLKBXdRfTGvUakFocAhpIgQDjWSie=YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('grade_nm')
      YHLKBXdRfTGvUakFocAhpIgQDjWSiu=YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('broad_dt')
      if data_str!='':
       YHLKBXdRfTGvUakFocAhpIgQDjWSxe='%s-%s-%s'%(YHLKBXdRfTGvUakFocAhpIgQDjWSiu[:4],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[4:6],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[6:])
       YHLKBXdRfTGvUakFocAhpIgQDjWSis =YHLKBXdRfTGvUakFocAhpIgQDjWSiu[:4]
     except:
      YHLKBXdRfTGvUakFocAhpIgQDjWStM
     YHLKBXdRfTGvUakFocAhpIgQDjWSiN={'movie':YHLKBXdRfTGvUakFocAhpIgQDjWSiP,'title':YHLKBXdRfTGvUakFocAhpIgQDjWSJV,'thumbnail':{'poster':YHLKBXdRfTGvUakFocAhpIgQDjWSJl,'thumb':YHLKBXdRfTGvUakFocAhpIgQDjWSJy,'fanart':YHLKBXdRfTGvUakFocAhpIgQDjWSJy,'clearlogo':YHLKBXdRfTGvUakFocAhpIgQDjWSin},'synopsis':'','cast':YHLKBXdRfTGvUakFocAhpIgQDjWSix,'director':YHLKBXdRfTGvUakFocAhpIgQDjWSit,'info_genre':YHLKBXdRfTGvUakFocAhpIgQDjWSib,'duration':YHLKBXdRfTGvUakFocAhpIgQDjWSxO,'mpaa':YHLKBXdRfTGvUakFocAhpIgQDjWSie,'year':YHLKBXdRfTGvUakFocAhpIgQDjWSis,'aired':YHLKBXdRfTGvUakFocAhpIgQDjWSxe}
     YHLKBXdRfTGvUakFocAhpIgQDjWSxq.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiN)
   if YHLKBXdRfTGvUakFocAhpIgQDjWSxr>(page_int*YHLKBXdRfTGvUakFocAhpIgQDjWSnx.SEARCH_LIMIT):YHLKBXdRfTGvUakFocAhpIgQDjWSJO=YHLKBXdRfTGvUakFocAhpIgQDjWStV
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSxq,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
 def GetBookmarkInfo(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,videoid,vidtype):
  YHLKBXdRfTGvUakFocAhpIgQDjWSxl={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+'/v2/media/program/'+videoid
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'pageNo':'1','pageSize':'10','order':'name',}
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWStM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSiy=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if not('body' in YHLKBXdRfTGvUakFocAhpIgQDjWSiy):return{}
   YHLKBXdRfTGvUakFocAhpIgQDjWStn=YHLKBXdRfTGvUakFocAhpIgQDjWSiy['body']
   YHLKBXdRfTGvUakFocAhpIgQDjWSJV=YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('name').get('ko').strip()
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['title'] =YHLKBXdRfTGvUakFocAhpIgQDjWSJV
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['title']=YHLKBXdRfTGvUakFocAhpIgQDjWSJV
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['mpaa'] =YHLKBXdRfTGvUakFocAhpIgQDjWSnm.get(YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('grade_code'))
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['plot'] =YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('synopsis').get('ko')
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['year'] =YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('product_year')
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['cast'] =YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('actor')
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['director']=YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('director')
   if YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('category1_name').get('ko')!='':
    YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['genre'].append(YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('category1_name').get('ko'))
   if YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('category2_name').get('ko')!='':
    YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['genre'].append(YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('category2_name').get('ko'))
   YHLKBXdRfTGvUakFocAhpIgQDjWSiu=YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('broad_dt'))
   if YHLKBXdRfTGvUakFocAhpIgQDjWSiu!='0':YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(YHLKBXdRfTGvUakFocAhpIgQDjWSiu[:4],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[4:6],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[6:])
   YHLKBXdRfTGvUakFocAhpIgQDjWSJl =''
   YHLKBXdRfTGvUakFocAhpIgQDjWSJy =''
   YHLKBXdRfTGvUakFocAhpIgQDjWSin=''
   YHLKBXdRfTGvUakFocAhpIgQDjWSiC =''
   YHLKBXdRfTGvUakFocAhpIgQDjWSiw =''
   for YHLKBXdRfTGvUakFocAhpIgQDjWSiJ in YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('image'):
    if YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('code')=='CAIP0900':YHLKBXdRfTGvUakFocAhpIgQDjWSJl =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('url')
    elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('code')=='CAIP0200':YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('url')
    elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('code')=='CAIP1800':YHLKBXdRfTGvUakFocAhpIgQDjWSin=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('url')
    elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('code')=='CAIP2000':YHLKBXdRfTGvUakFocAhpIgQDjWSiC =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('url')
    elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('code')=='CAIP1900':YHLKBXdRfTGvUakFocAhpIgQDjWSiw =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('url')
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['thumbnail']['poster']=YHLKBXdRfTGvUakFocAhpIgQDjWSJl
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['thumbnail']['thumb']=YHLKBXdRfTGvUakFocAhpIgQDjWSJy
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['thumbnail']['clearlogo']=YHLKBXdRfTGvUakFocAhpIgQDjWSin
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['thumbnail']['icon']=YHLKBXdRfTGvUakFocAhpIgQDjWSiC
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['thumbnail']['banner']=YHLKBXdRfTGvUakFocAhpIgQDjWSiw
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['thumbnail']['fanart']=YHLKBXdRfTGvUakFocAhpIgQDjWSJy
  else:
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+'/v2a/media/stream/info'
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies']['tving_uuid'].split('-')[0],'uuid':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetNoCache(1)),'wm':'Y',}
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWStM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSiy=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if not('content' in YHLKBXdRfTGvUakFocAhpIgQDjWSiy['body']):return{}
   YHLKBXdRfTGvUakFocAhpIgQDjWStn=YHLKBXdRfTGvUakFocAhpIgQDjWSiy['body']['content']['info']['movie']
   YHLKBXdRfTGvUakFocAhpIgQDjWSJV =YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('name').get('ko').strip()
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['title']=YHLKBXdRfTGvUakFocAhpIgQDjWSJV
   YHLKBXdRfTGvUakFocAhpIgQDjWSJV +=u' (%s)'%(YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('product_year'))
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['title'] =YHLKBXdRfTGvUakFocAhpIgQDjWSJV
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['mpaa'] =YHLKBXdRfTGvUakFocAhpIgQDjWSnm.get(YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('grade_code'))
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['plot'] =YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('story').get('ko')
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['year'] =YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('product_year')
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['studio'] =YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('production')
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['duration']=YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('duration')
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['cast'] =YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('actor')
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['director']=YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('director')
   if YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('category1_name').get('ko')!='':
    YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['genre'].append(YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('category1_name').get('ko'))
   if YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('category2_name').get('ko')!='':
    YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['genre'].append(YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('category2_name').get('ko'))
   YHLKBXdRfTGvUakFocAhpIgQDjWSiu=YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('release_date'))
   if YHLKBXdRfTGvUakFocAhpIgQDjWSiu!='0':YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(YHLKBXdRfTGvUakFocAhpIgQDjWSiu[:4],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[4:6],YHLKBXdRfTGvUakFocAhpIgQDjWSiu[6:])
   YHLKBXdRfTGvUakFocAhpIgQDjWSJl=''
   YHLKBXdRfTGvUakFocAhpIgQDjWSJy =''
   YHLKBXdRfTGvUakFocAhpIgQDjWSin=''
   for YHLKBXdRfTGvUakFocAhpIgQDjWSiJ in YHLKBXdRfTGvUakFocAhpIgQDjWStn.get('image'):
    if YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('code')=='CAIM2100':YHLKBXdRfTGvUakFocAhpIgQDjWSJl =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('url')
    elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('code')=='CAIM0400':YHLKBXdRfTGvUakFocAhpIgQDjWSJy =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('url')
    elif YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('code')=='CAIM1800':YHLKBXdRfTGvUakFocAhpIgQDjWSin=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.IMG_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSiJ.get('url')
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['thumbnail']['poster']=YHLKBXdRfTGvUakFocAhpIgQDjWSJl
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['thumbnail']['thumb']=YHLKBXdRfTGvUakFocAhpIgQDjWSJl 
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['thumbnail']['clearlogo']=YHLKBXdRfTGvUakFocAhpIgQDjWSin
   YHLKBXdRfTGvUakFocAhpIgQDjWSxl['saveinfo']['thumbnail']['fanart']=YHLKBXdRfTGvUakFocAhpIgQDjWSJy
  return YHLKBXdRfTGvUakFocAhpIgQDjWSxl
 def GetEuroChannelList(YHLKBXdRfTGvUakFocAhpIgQDjWSnx):
  YHLKBXdRfTGvUakFocAhpIgQDjWSwz=[]
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v2/operator/highlights'
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetNoCache(2))}
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWStM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if not('result' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']):return YHLKBXdRfTGvUakFocAhpIgQDjWSwz,YHLKBXdRfTGvUakFocAhpIgQDjWSJO
   YHLKBXdRfTGvUakFocAhpIgQDjWSJM=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']
   YHLKBXdRfTGvUakFocAhpIgQDjWStC =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Get_Now_Datetime()
   YHLKBXdRfTGvUakFocAhpIgQDjWStw=YHLKBXdRfTGvUakFocAhpIgQDjWStC+datetime.timedelta(days=-1)
   YHLKBXdRfTGvUakFocAhpIgQDjWStw=YHLKBXdRfTGvUakFocAhpIgQDjWSty(YHLKBXdRfTGvUakFocAhpIgQDjWStw.strftime('%Y%m%d'))
   for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSJM:
    YHLKBXdRfTGvUakFocAhpIgQDjWStm=YHLKBXdRfTGvUakFocAhpIgQDjWSty(YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('content').get('banner_title2')[:8])
    if YHLKBXdRfTGvUakFocAhpIgQDjWStw<=YHLKBXdRfTGvUakFocAhpIgQDjWStm:
     YHLKBXdRfTGvUakFocAhpIgQDjWSiN={'channel':YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('content').get('banner_sub_title3'),'title':YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('content').get('banner_title'),'subtitle':YHLKBXdRfTGvUakFocAhpIgQDjWSwP.get('content').get('banner_sub_title2'),}
     YHLKBXdRfTGvUakFocAhpIgQDjWSwz.append(YHLKBXdRfTGvUakFocAhpIgQDjWSiN)
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSwz
 def Make_DecryptKey(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,step,mediacode='000',timecode='000'):
  if step=='1':
   YHLKBXdRfTGvUakFocAhpIgQDjWSCs=YHLKBXdRfTGvUakFocAhpIgQDjWSbn('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   YHLKBXdRfTGvUakFocAhpIgQDjWSCe=YHLKBXdRfTGvUakFocAhpIgQDjWSbn('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   YHLKBXdRfTGvUakFocAhpIgQDjWSCs=YHLKBXdRfTGvUakFocAhpIgQDjWSbn('kss2lym0kdw1lks3','utf-8')
   YHLKBXdRfTGvUakFocAhpIgQDjWSCe=YHLKBXdRfTGvUakFocAhpIgQDjWSbn([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return YHLKBXdRfTGvUakFocAhpIgQDjWSCs,YHLKBXdRfTGvUakFocAhpIgQDjWSCe
 def DecryptPlaintext(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,YHLKBXdRfTGvUakFocAhpIgQDjWSCu,YHLKBXdRfTGvUakFocAhpIgQDjWSCE,YHLKBXdRfTGvUakFocAhpIgQDjWSCz):
  YHLKBXdRfTGvUakFocAhpIgQDjWSCO=AES.new(YHLKBXdRfTGvUakFocAhpIgQDjWSCE,AES.MODE_CBC,YHLKBXdRfTGvUakFocAhpIgQDjWSCz,)
  YHLKBXdRfTGvUakFocAhpIgQDjWSCM=Padding.unpad(YHLKBXdRfTGvUakFocAhpIgQDjWSCO.decrypt(base64.standard_b64decode(YHLKBXdRfTGvUakFocAhpIgQDjWSCu)),16)
  return YHLKBXdRfTGvUakFocAhpIgQDjWSCM.decode('utf-8')
 def Decrypt_Url(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,YHLKBXdRfTGvUakFocAhpIgQDjWSCu,mediacode,YHLKBXdRfTGvUakFocAhpIgQDjWSmt):
  YHLKBXdRfTGvUakFocAhpIgQDjWStJ=''
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSCs,YHLKBXdRfTGvUakFocAhpIgQDjWSCe=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Make_DecryptKey('1',mediacode=mediacode,timecode=YHLKBXdRfTGvUakFocAhpIgQDjWSmt)
   YHLKBXdRfTGvUakFocAhpIgQDjWSti=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.DecryptPlaintext(YHLKBXdRfTGvUakFocAhpIgQDjWSCu,YHLKBXdRfTGvUakFocAhpIgQDjWSCs,YHLKBXdRfTGvUakFocAhpIgQDjWSCe))
   YHLKBXdRfTGvUakFocAhpIgQDjWStx =YHLKBXdRfTGvUakFocAhpIgQDjWSti.get('url')
   YHLKBXdRfTGvUakFocAhpIgQDjWSCs,YHLKBXdRfTGvUakFocAhpIgQDjWSCe=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Make_DecryptKey('2',mediacode=mediacode,timecode=YHLKBXdRfTGvUakFocAhpIgQDjWSmt)
   YHLKBXdRfTGvUakFocAhpIgQDjWStJ=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.DecryptPlaintext(YHLKBXdRfTGvUakFocAhpIgQDjWStx,YHLKBXdRfTGvUakFocAhpIgQDjWSCs,YHLKBXdRfTGvUakFocAhpIgQDjWSCe)
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
  return YHLKBXdRfTGvUakFocAhpIgQDjWStJ
 def GetLiveURL_Test(YHLKBXdRfTGvUakFocAhpIgQDjWSnx,mediacode,sel_quality):
  YHLKBXdRfTGvUakFocAhpIgQDjWSwV ={'streaming_url':'','subtitleYn':YHLKBXdRfTGvUakFocAhpIgQDjWStN,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  YHLKBXdRfTGvUakFocAhpIgQDjWSwO =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies']['tving_uuid'].split('-')[0] 
  YHLKBXdRfTGvUakFocAhpIgQDjWSwr =YHLKBXdRfTGvUakFocAhpIgQDjWSnx.TV['cookies']['tving_uuid'] 
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSwl=YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetNoCache(1))
   YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v2/media/stream/info' 
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':YHLKBXdRfTGvUakFocAhpIgQDjWSwr,'deviceInfo':'PC','noCache':YHLKBXdRfTGvUakFocAhpIgQDjWSwl,}
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSnl=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.makeDefaultCookies()
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Get',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWSnl)
   if YHLKBXdRfTGvUakFocAhpIgQDjWSCy.status_code!=200:
    YHLKBXdRfTGvUakFocAhpIgQDjWSwV['error_msg']='First Step - {} error'.format(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.status_code)
    return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
   YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']['code']=='060':
    for YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSnV in YHLKBXdRfTGvUakFocAhpIgQDjWSnw.items():
     if YHLKBXdRfTGvUakFocAhpIgQDjWSnV==sel_quality:
      YHLKBXdRfTGvUakFocAhpIgQDjWSmC=YHLKBXdRfTGvUakFocAhpIgQDjWSnq
   elif YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']['code']!='000':
    YHLKBXdRfTGvUakFocAhpIgQDjWSwV['error_msg']=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']['message']
    return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
   else: 
    if not('stream' in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']):return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
    YHLKBXdRfTGvUakFocAhpIgQDjWSmw=[]
    for YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSnV in YHLKBXdRfTGvUakFocAhpIgQDjWSnw.items():
     for YHLKBXdRfTGvUakFocAhpIgQDjWSwP in YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['stream']['quality']:
      if YHLKBXdRfTGvUakFocAhpIgQDjWSwP['active']=='Y' and YHLKBXdRfTGvUakFocAhpIgQDjWSwP['code']==YHLKBXdRfTGvUakFocAhpIgQDjWSnq:
       YHLKBXdRfTGvUakFocAhpIgQDjWSmw.append({YHLKBXdRfTGvUakFocAhpIgQDjWSnw.get(YHLKBXdRfTGvUakFocAhpIgQDjWSwP['code']):YHLKBXdRfTGvUakFocAhpIgQDjWSwP['code']})
    YHLKBXdRfTGvUakFocAhpIgQDjWSmC=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.CheckQuality(sel_quality,YHLKBXdRfTGvUakFocAhpIgQDjWSmw)
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwV['error_msg']='First Step - except error'
   return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
  try:
   YHLKBXdRfTGvUakFocAhpIgQDjWSwl=YHLKBXdRfTGvUakFocAhpIgQDjWStP(YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetNoCache(1))
   YHLKBXdRfTGvUakFocAhpIgQDjWSws ='/v3/media/stream/info'
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.GetDefaultParams()
   YHLKBXdRfTGvUakFocAhpIgQDjWSwM={'mediaCode':mediacode,'deviceId':YHLKBXdRfTGvUakFocAhpIgQDjWSwO,'uuid':YHLKBXdRfTGvUakFocAhpIgQDjWSwr,'deviceInfo':'PC_Chrome','streamCode':YHLKBXdRfTGvUakFocAhpIgQDjWSmC,'noCache':YHLKBXdRfTGvUakFocAhpIgQDjWSwl,'callingFrom':'HTML5','model':YHLKBXdRfTGvUakFocAhpIgQDjWSnx.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   YHLKBXdRfTGvUakFocAhpIgQDjWSmn.update(YHLKBXdRfTGvUakFocAhpIgQDjWSwM)
   YHLKBXdRfTGvUakFocAhpIgQDjWSCV=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.API_DOMAIN+YHLKBXdRfTGvUakFocAhpIgQDjWSws
   YHLKBXdRfTGvUakFocAhpIgQDjWSnl=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.makeDefaultCookies()
   YHLKBXdRfTGvUakFocAhpIgQDjWSCy=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.callRequestCookies('Post',YHLKBXdRfTGvUakFocAhpIgQDjWSCV,payload=YHLKBXdRfTGvUakFocAhpIgQDjWStM,params=YHLKBXdRfTGvUakFocAhpIgQDjWSmn,headers=YHLKBXdRfTGvUakFocAhpIgQDjWStM,cookies=YHLKBXdRfTGvUakFocAhpIgQDjWSnl,redirects=YHLKBXdRfTGvUakFocAhpIgQDjWStV)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwN=json.loads(YHLKBXdRfTGvUakFocAhpIgQDjWSCy.text)
   if YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']['code']!='000':
    YHLKBXdRfTGvUakFocAhpIgQDjWSwV['error_msg']=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['result']['message']
    return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
   YHLKBXdRfTGvUakFocAhpIgQDjWSmJ=YHLKBXdRfTGvUakFocAhpIgQDjWSwN['body']['stream']
   if YHLKBXdRfTGvUakFocAhpIgQDjWSmJ['drm_yn']=='Y':
    YHLKBXdRfTGvUakFocAhpIgQDjWSmi=YHLKBXdRfTGvUakFocAhpIgQDjWSmJ['playback']['drm']['widevine']
    for YHLKBXdRfTGvUakFocAhpIgQDjWSmx in YHLKBXdRfTGvUakFocAhpIgQDjWSmJ['playback']['drm']['license']['drm_license_data']:
     if YHLKBXdRfTGvUakFocAhpIgQDjWSmx['drm_type']=='Widevine':
      YHLKBXdRfTGvUakFocAhpIgQDjWSwV['drm_server_url'] =YHLKBXdRfTGvUakFocAhpIgQDjWSmx['drm_server_url']
      YHLKBXdRfTGvUakFocAhpIgQDjWSwV['drm_header_key'] =YHLKBXdRfTGvUakFocAhpIgQDjWSmx['drm_header_key']
      YHLKBXdRfTGvUakFocAhpIgQDjWSwV['drm_header_value']=YHLKBXdRfTGvUakFocAhpIgQDjWSmx['drm_header_value']
      break
   else:
    YHLKBXdRfTGvUakFocAhpIgQDjWSmi=YHLKBXdRfTGvUakFocAhpIgQDjWSmJ['playback']['non_drm']
  except YHLKBXdRfTGvUakFocAhpIgQDjWSbC as exception:
   YHLKBXdRfTGvUakFocAhpIgQDjWStz(exception)
   YHLKBXdRfTGvUakFocAhpIgQDjWSwV['error_msg']='Second Step - except error'
   return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
  YHLKBXdRfTGvUakFocAhpIgQDjWSmt=YHLKBXdRfTGvUakFocAhpIgQDjWSwl
  YHLKBXdRfTGvUakFocAhpIgQDjWSmi=YHLKBXdRfTGvUakFocAhpIgQDjWSmi.split('|')[1]
  YHLKBXdRfTGvUakFocAhpIgQDjWSmi=YHLKBXdRfTGvUakFocAhpIgQDjWSnx.Decrypt_Url(YHLKBXdRfTGvUakFocAhpIgQDjWSmi,mediacode,YHLKBXdRfTGvUakFocAhpIgQDjWSmt)
  YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url']=YHLKBXdRfTGvUakFocAhpIgQDjWSmi
  YHLKBXdRfTGvUakFocAhpIgQDjWStb =YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url'].find('Policy=')
  if YHLKBXdRfTGvUakFocAhpIgQDjWStb!=-1:
   YHLKBXdRfTGvUakFocAhpIgQDjWSts =YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url'].split('?')[0]
   YHLKBXdRfTGvUakFocAhpIgQDjWSte=YHLKBXdRfTGvUakFocAhpIgQDjWSbw(urllib.parse.parse_qsl(urllib.parse.urlsplit(YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url']).query))
   YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url']='{}&CloudFront-Policy={}'.format(YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url'],YHLKBXdRfTGvUakFocAhpIgQDjWSte['Policy'])
   YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url']='{}&CloudFront-Signature={}'.format(YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url'],YHLKBXdRfTGvUakFocAhpIgQDjWSte['Signature'])
   YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url'],YHLKBXdRfTGvUakFocAhpIgQDjWSte['Key-Pair-Id'])
  YHLKBXdRfTGvUakFocAhpIgQDjWStE=['_tving_token','accessToken','authToken',]
  for YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSnV in YHLKBXdRfTGvUakFocAhpIgQDjWSnl.items():
   if YHLKBXdRfTGvUakFocAhpIgQDjWSnq in YHLKBXdRfTGvUakFocAhpIgQDjWStE:
    YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url']='{}&{}={}'.format(YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url'],YHLKBXdRfTGvUakFocAhpIgQDjWSnq,YHLKBXdRfTGvUakFocAhpIgQDjWSnV)
  YHLKBXdRfTGvUakFocAhpIgQDjWStz(YHLKBXdRfTGvUakFocAhpIgQDjWSwV['streaming_url'])
  return YHLKBXdRfTGvUakFocAhpIgQDjWSwV
# Created by pyminifier (https://github.com/liftoff/pyminifier)
