__author__="NightRain"
EtajdVcNGXQBqsOkSFAlpPDirbfHzm=object
EtajdVcNGXQBqsOkSFAlpPDirbfHze=None
EtajdVcNGXQBqsOkSFAlpPDirbfHzv=int
EtajdVcNGXQBqsOkSFAlpPDirbfHwL=True
EtajdVcNGXQBqsOkSFAlpPDirbfHwT=False
EtajdVcNGXQBqsOkSFAlpPDirbfHwY=type
EtajdVcNGXQBqsOkSFAlpPDirbfHwM=dict
EtajdVcNGXQBqsOkSFAlpPDirbfHwo=getattr
EtajdVcNGXQBqsOkSFAlpPDirbfHwW=list
EtajdVcNGXQBqsOkSFAlpPDirbfHwg=len
EtajdVcNGXQBqsOkSFAlpPDirbfHwz=str
EtajdVcNGXQBqsOkSFAlpPDirbfHwK=range
EtajdVcNGXQBqsOkSFAlpPDirbfHwx=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
EtajdVcNGXQBqsOkSFAlpPDirbfHLY=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
EtajdVcNGXQBqsOkSFAlpPDirbfHLM=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
EtajdVcNGXQBqsOkSFAlpPDirbfHLo=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
EtajdVcNGXQBqsOkSFAlpPDirbfHLW=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
EtajdVcNGXQBqsOkSFAlpPDirbfHLg=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
EtajdVcNGXQBqsOkSFAlpPDirbfHLz=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
EtajdVcNGXQBqsOkSFAlpPDirbfHLw=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
EtajdVcNGXQBqsOkSFAlpPDirbfHLK={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
EtajdVcNGXQBqsOkSFAlpPDirbfHLx =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
EtajdVcNGXQBqsOkSFAlpPDirbfHLU=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class EtajdVcNGXQBqsOkSFAlpPDirbfHLT(EtajdVcNGXQBqsOkSFAlpPDirbfHzm):
 def __init__(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHLC,EtajdVcNGXQBqsOkSFAlpPDirbfHLu,EtajdVcNGXQBqsOkSFAlpPDirbfHLR):
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_url =EtajdVcNGXQBqsOkSFAlpPDirbfHLC
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle=EtajdVcNGXQBqsOkSFAlpPDirbfHLu
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params =EtajdVcNGXQBqsOkSFAlpPDirbfHLR
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj =YHLKBXdRfTGvUakFocAhpIgQDjWSnC() 
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,sting):
  try:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLy=xbmcgui.Dialog()
   EtajdVcNGXQBqsOkSFAlpPDirbfHLy.notification(__addonname__,sting)
  except:
   EtajdVcNGXQBqsOkSFAlpPDirbfHze
 def addon_log(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,string):
  try:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLh=string.encode('utf-8','ignore')
  except:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLh='addonException: addon_log'
  EtajdVcNGXQBqsOkSFAlpPDirbfHLn=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,EtajdVcNGXQBqsOkSFAlpPDirbfHLh),level=EtajdVcNGXQBqsOkSFAlpPDirbfHLn)
 def get_keyboard_input(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHTR):
  EtajdVcNGXQBqsOkSFAlpPDirbfHLm=EtajdVcNGXQBqsOkSFAlpPDirbfHze
  kb=xbmc.Keyboard()
  kb.setHeading(EtajdVcNGXQBqsOkSFAlpPDirbfHTR)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   EtajdVcNGXQBqsOkSFAlpPDirbfHLm=kb.getText()
  return EtajdVcNGXQBqsOkSFAlpPDirbfHLm
 def get_settings_account(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  EtajdVcNGXQBqsOkSFAlpPDirbfHLe =__addon__.getSetting('id')
  EtajdVcNGXQBqsOkSFAlpPDirbfHLv =__addon__.getSetting('pw')
  EtajdVcNGXQBqsOkSFAlpPDirbfHTL =__addon__.getSetting('login_type')
  EtajdVcNGXQBqsOkSFAlpPDirbfHTY=EtajdVcNGXQBqsOkSFAlpPDirbfHzv(__addon__.getSetting('selected_profile'))
  return(EtajdVcNGXQBqsOkSFAlpPDirbfHLe,EtajdVcNGXQBqsOkSFAlpPDirbfHLv,EtajdVcNGXQBqsOkSFAlpPDirbfHTL,EtajdVcNGXQBqsOkSFAlpPDirbfHTY)
 def get_settings_uhd(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  return EtajdVcNGXQBqsOkSFAlpPDirbfHwL if __addon__.getSetting('active_uhd')=='true' else EtajdVcNGXQBqsOkSFAlpPDirbfHwT
 def get_settings_playback(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  EtajdVcNGXQBqsOkSFAlpPDirbfHTM={'active_uhd':EtajdVcNGXQBqsOkSFAlpPDirbfHwL if __addon__.getSetting('active_uhd')=='true' else EtajdVcNGXQBqsOkSFAlpPDirbfHwT,'streamFilename':EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.TV_STREAM_FILENAME,}
  return EtajdVcNGXQBqsOkSFAlpPDirbfHTM
 def get_settings_proxyport(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  EtajdVcNGXQBqsOkSFAlpPDirbfHTo =EtajdVcNGXQBqsOkSFAlpPDirbfHwL if __addon__.getSetting('proxyYn')=='true' else EtajdVcNGXQBqsOkSFAlpPDirbfHwT
  EtajdVcNGXQBqsOkSFAlpPDirbfHTW=EtajdVcNGXQBqsOkSFAlpPDirbfHzv(__addon__.getSetting('proxyPort'))
  return EtajdVcNGXQBqsOkSFAlpPDirbfHTo,EtajdVcNGXQBqsOkSFAlpPDirbfHTW
 def get_settings_totalsearch(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  EtajdVcNGXQBqsOkSFAlpPDirbfHTg =EtajdVcNGXQBqsOkSFAlpPDirbfHwL if __addon__.getSetting('local_search')=='true' else EtajdVcNGXQBqsOkSFAlpPDirbfHwT
  EtajdVcNGXQBqsOkSFAlpPDirbfHTz=EtajdVcNGXQBqsOkSFAlpPDirbfHwL if __addon__.getSetting('local_history')=='true' else EtajdVcNGXQBqsOkSFAlpPDirbfHwT
  EtajdVcNGXQBqsOkSFAlpPDirbfHTw =EtajdVcNGXQBqsOkSFAlpPDirbfHwL if __addon__.getSetting('total_search')=='true' else EtajdVcNGXQBqsOkSFAlpPDirbfHwT
  EtajdVcNGXQBqsOkSFAlpPDirbfHTK=EtajdVcNGXQBqsOkSFAlpPDirbfHwL if __addon__.getSetting('total_history')=='true' else EtajdVcNGXQBqsOkSFAlpPDirbfHwT
  EtajdVcNGXQBqsOkSFAlpPDirbfHTx=EtajdVcNGXQBqsOkSFAlpPDirbfHwL if __addon__.getSetting('menu_bookmark')=='true' else EtajdVcNGXQBqsOkSFAlpPDirbfHwT
  return(EtajdVcNGXQBqsOkSFAlpPDirbfHTg,EtajdVcNGXQBqsOkSFAlpPDirbfHTz,EtajdVcNGXQBqsOkSFAlpPDirbfHTw,EtajdVcNGXQBqsOkSFAlpPDirbfHTK,EtajdVcNGXQBqsOkSFAlpPDirbfHTx)
 def get_settings_makebookmark(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  return EtajdVcNGXQBqsOkSFAlpPDirbfHwL if __addon__.getSetting('make_bookmark')=='true' else EtajdVcNGXQBqsOkSFAlpPDirbfHwT
 def get_settings_direct_replay(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  EtajdVcNGXQBqsOkSFAlpPDirbfHTU=EtajdVcNGXQBqsOkSFAlpPDirbfHzv(__addon__.getSetting('direct_replay'))
  if EtajdVcNGXQBqsOkSFAlpPDirbfHTU==0:
   return EtajdVcNGXQBqsOkSFAlpPDirbfHwT
  else:
   return EtajdVcNGXQBqsOkSFAlpPDirbfHwL
 def set_winEpisodeOrderby(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHTC):
  __addon__.setSetting('tving_orderby',EtajdVcNGXQBqsOkSFAlpPDirbfHTC)
  EtajdVcNGXQBqsOkSFAlpPDirbfHTJ=xbmcgui.Window(10000)
  EtajdVcNGXQBqsOkSFAlpPDirbfHTJ.setProperty('TVING_M_ORDERBY',EtajdVcNGXQBqsOkSFAlpPDirbfHTC)
 def get_winEpisodeOrderby(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  EtajdVcNGXQBqsOkSFAlpPDirbfHTC=__addon__.getSetting('tving_orderby')
  if EtajdVcNGXQBqsOkSFAlpPDirbfHTC in['',EtajdVcNGXQBqsOkSFAlpPDirbfHze]:EtajdVcNGXQBqsOkSFAlpPDirbfHTC='desc'
  return EtajdVcNGXQBqsOkSFAlpPDirbfHTC
 def add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,label,sublabel='',img='',infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHze,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params='',isLink=EtajdVcNGXQBqsOkSFAlpPDirbfHwT,ContextMenu=EtajdVcNGXQBqsOkSFAlpPDirbfHze):
  EtajdVcNGXQBqsOkSFAlpPDirbfHTu='%s?%s'%(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_url,urllib.parse.urlencode(params))
  if sublabel:EtajdVcNGXQBqsOkSFAlpPDirbfHTR='%s < %s >'%(label,sublabel)
  else: EtajdVcNGXQBqsOkSFAlpPDirbfHTR=label
  if not img:img='DefaultFolder.png'
  EtajdVcNGXQBqsOkSFAlpPDirbfHTI=xbmcgui.ListItem(EtajdVcNGXQBqsOkSFAlpPDirbfHTR)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHwY(img)==EtajdVcNGXQBqsOkSFAlpPDirbfHwM:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTI.setArt(img)
  else:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTI.setArt({'thumb':img,'poster':img})
  if EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.KodiVersion>=20:
   if infoLabels:EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.Set_InfoTag(EtajdVcNGXQBqsOkSFAlpPDirbfHTI.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:EtajdVcNGXQBqsOkSFAlpPDirbfHTI.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTI.setProperty('IsPlayable','true')
  if ContextMenu:EtajdVcNGXQBqsOkSFAlpPDirbfHTI.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,EtajdVcNGXQBqsOkSFAlpPDirbfHTu,EtajdVcNGXQBqsOkSFAlpPDirbfHTI,isFolder)
 def get_selQuality(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,etype):
  try:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTy='selected_quality'
   EtajdVcNGXQBqsOkSFAlpPDirbfHTh=[1080,720,480,360]
   EtajdVcNGXQBqsOkSFAlpPDirbfHTn=EtajdVcNGXQBqsOkSFAlpPDirbfHzv(__addon__.getSetting(EtajdVcNGXQBqsOkSFAlpPDirbfHTy))
   return EtajdVcNGXQBqsOkSFAlpPDirbfHTh[EtajdVcNGXQBqsOkSFAlpPDirbfHTn]
  except:
   EtajdVcNGXQBqsOkSFAlpPDirbfHze
  return 720 
 def Set_InfoTag(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,video_InfoTag:xbmc.InfoTagVideo,EtajdVcNGXQBqsOkSFAlpPDirbfHYW):
  for EtajdVcNGXQBqsOkSFAlpPDirbfHTm,value in EtajdVcNGXQBqsOkSFAlpPDirbfHYW.items():
   if EtajdVcNGXQBqsOkSFAlpPDirbfHLK[EtajdVcNGXQBqsOkSFAlpPDirbfHTm]['type']=='string':
    EtajdVcNGXQBqsOkSFAlpPDirbfHwo(video_InfoTag,EtajdVcNGXQBqsOkSFAlpPDirbfHLK[EtajdVcNGXQBqsOkSFAlpPDirbfHTm]['func'])(value)
   elif EtajdVcNGXQBqsOkSFAlpPDirbfHLK[EtajdVcNGXQBqsOkSFAlpPDirbfHTm]['type']=='int':
    if EtajdVcNGXQBqsOkSFAlpPDirbfHwY(value)==EtajdVcNGXQBqsOkSFAlpPDirbfHzv:
     EtajdVcNGXQBqsOkSFAlpPDirbfHTe=EtajdVcNGXQBqsOkSFAlpPDirbfHzv(value)
    else:
     EtajdVcNGXQBqsOkSFAlpPDirbfHTe=0
    EtajdVcNGXQBqsOkSFAlpPDirbfHwo(video_InfoTag,EtajdVcNGXQBqsOkSFAlpPDirbfHLK[EtajdVcNGXQBqsOkSFAlpPDirbfHTm]['func'])(EtajdVcNGXQBqsOkSFAlpPDirbfHTe)
   elif EtajdVcNGXQBqsOkSFAlpPDirbfHLK[EtajdVcNGXQBqsOkSFAlpPDirbfHTm]['type']=='actor':
    if value!=[]:
     EtajdVcNGXQBqsOkSFAlpPDirbfHwo(video_InfoTag,EtajdVcNGXQBqsOkSFAlpPDirbfHLK[EtajdVcNGXQBqsOkSFAlpPDirbfHTm]['func'])([xbmc.Actor(name)for name in value])
   elif EtajdVcNGXQBqsOkSFAlpPDirbfHLK[EtajdVcNGXQBqsOkSFAlpPDirbfHTm]['type']=='list':
    if EtajdVcNGXQBqsOkSFAlpPDirbfHwY(value)==EtajdVcNGXQBqsOkSFAlpPDirbfHwW:
     EtajdVcNGXQBqsOkSFAlpPDirbfHwo(video_InfoTag,EtajdVcNGXQBqsOkSFAlpPDirbfHLK[EtajdVcNGXQBqsOkSFAlpPDirbfHTm]['func'])(value)
    else:
     EtajdVcNGXQBqsOkSFAlpPDirbfHwo(video_InfoTag,EtajdVcNGXQBqsOkSFAlpPDirbfHLK[EtajdVcNGXQBqsOkSFAlpPDirbfHTm]['func'])([value])
 def dp_Main_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  (EtajdVcNGXQBqsOkSFAlpPDirbfHTg,EtajdVcNGXQBqsOkSFAlpPDirbfHTz,EtajdVcNGXQBqsOkSFAlpPDirbfHTw,EtajdVcNGXQBqsOkSFAlpPDirbfHTK,EtajdVcNGXQBqsOkSFAlpPDirbfHTx)=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_totalsearch()
  for EtajdVcNGXQBqsOkSFAlpPDirbfHTv in EtajdVcNGXQBqsOkSFAlpPDirbfHLY:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR=EtajdVcNGXQBqsOkSFAlpPDirbfHTv.get('title')
   EtajdVcNGXQBqsOkSFAlpPDirbfHYL=''
   if EtajdVcNGXQBqsOkSFAlpPDirbfHTv.get('mode')=='SEARCH_GROUP' and EtajdVcNGXQBqsOkSFAlpPDirbfHTg ==EtajdVcNGXQBqsOkSFAlpPDirbfHwT:continue
   elif EtajdVcNGXQBqsOkSFAlpPDirbfHTv.get('mode')=='SEARCH_HISTORY' and EtajdVcNGXQBqsOkSFAlpPDirbfHTz==EtajdVcNGXQBqsOkSFAlpPDirbfHwT:continue
   elif EtajdVcNGXQBqsOkSFAlpPDirbfHTv.get('mode')=='TOTAL_SEARCH' and EtajdVcNGXQBqsOkSFAlpPDirbfHTw ==EtajdVcNGXQBqsOkSFAlpPDirbfHwT:continue
   elif EtajdVcNGXQBqsOkSFAlpPDirbfHTv.get('mode')=='TOTAL_HISTORY' and EtajdVcNGXQBqsOkSFAlpPDirbfHTK==EtajdVcNGXQBqsOkSFAlpPDirbfHwT:continue
   elif EtajdVcNGXQBqsOkSFAlpPDirbfHTv.get('mode')=='MENU_BOOKMARK' and EtajdVcNGXQBqsOkSFAlpPDirbfHTx==EtajdVcNGXQBqsOkSFAlpPDirbfHwT:continue
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':EtajdVcNGXQBqsOkSFAlpPDirbfHTv.get('mode'),'stype':EtajdVcNGXQBqsOkSFAlpPDirbfHTv.get('stype'),'orderby':EtajdVcNGXQBqsOkSFAlpPDirbfHTv.get('orderby'),'ordernm':EtajdVcNGXQBqsOkSFAlpPDirbfHTv.get('ordernm'),'page':'1'}
   if EtajdVcNGXQBqsOkSFAlpPDirbfHTv.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    EtajdVcNGXQBqsOkSFAlpPDirbfHYM=EtajdVcNGXQBqsOkSFAlpPDirbfHwT
    EtajdVcNGXQBqsOkSFAlpPDirbfHYo =EtajdVcNGXQBqsOkSFAlpPDirbfHwL
   else:
    EtajdVcNGXQBqsOkSFAlpPDirbfHYM=EtajdVcNGXQBqsOkSFAlpPDirbfHwL
    EtajdVcNGXQBqsOkSFAlpPDirbfHYo =EtajdVcNGXQBqsOkSFAlpPDirbfHwT
   EtajdVcNGXQBqsOkSFAlpPDirbfHYW={'title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'plot':EtajdVcNGXQBqsOkSFAlpPDirbfHTR}
   if EtajdVcNGXQBqsOkSFAlpPDirbfHTv.get('mode')=='XXX':EtajdVcNGXQBqsOkSFAlpPDirbfHYW=EtajdVcNGXQBqsOkSFAlpPDirbfHze
   if 'icon' in EtajdVcNGXQBqsOkSFAlpPDirbfHTv:EtajdVcNGXQBqsOkSFAlpPDirbfHYL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',EtajdVcNGXQBqsOkSFAlpPDirbfHTv.get('icon')) 
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel='',img=EtajdVcNGXQBqsOkSFAlpPDirbfHYL,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHYW,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHYM,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT,isLink=EtajdVcNGXQBqsOkSFAlpPDirbfHYo)
  xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle)
 def login_main(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  (EtajdVcNGXQBqsOkSFAlpPDirbfHYz,EtajdVcNGXQBqsOkSFAlpPDirbfHYw,EtajdVcNGXQBqsOkSFAlpPDirbfHYK,EtajdVcNGXQBqsOkSFAlpPDirbfHYx)=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_account()
  if not(EtajdVcNGXQBqsOkSFAlpPDirbfHYz and EtajdVcNGXQBqsOkSFAlpPDirbfHYw):
   EtajdVcNGXQBqsOkSFAlpPDirbfHLy=xbmcgui.Dialog()
   EtajdVcNGXQBqsOkSFAlpPDirbfHYU=EtajdVcNGXQBqsOkSFAlpPDirbfHLy.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if EtajdVcNGXQBqsOkSFAlpPDirbfHYU==EtajdVcNGXQBqsOkSFAlpPDirbfHwL:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.cookiefile_check():return
  if base64.standard_b64encode(EtajdVcNGXQBqsOkSFAlpPDirbfHYz.encode()).decode('utf-8')=='a3ltOTUxMDg4':
   EtajdVcNGXQBqsOkSFAlpPDirbfHYJ=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.GetCredential2(EtajdVcNGXQBqsOkSFAlpPDirbfHYz,EtajdVcNGXQBqsOkSFAlpPDirbfHYw,EtajdVcNGXQBqsOkSFAlpPDirbfHYK,EtajdVcNGXQBqsOkSFAlpPDirbfHYx)
  else:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLy=xbmcgui.Dialog()
   EtajdVcNGXQBqsOkSFAlpPDirbfHYC=EtajdVcNGXQBqsOkSFAlpPDirbfHLy.browse(1,__language__(30917).encode('utf8'),'','.twc',EtajdVcNGXQBqsOkSFAlpPDirbfHwT,EtajdVcNGXQBqsOkSFAlpPDirbfHwT,'',EtajdVcNGXQBqsOkSFAlpPDirbfHwT)
   if EtajdVcNGXQBqsOkSFAlpPDirbfHYC!='':
    EtajdVcNGXQBqsOkSFAlpPDirbfHYu=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'))
    xbmcvfs.copy(EtajdVcNGXQBqsOkSFAlpPDirbfHYC,EtajdVcNGXQBqsOkSFAlpPDirbfHYu)
    EtajdVcNGXQBqsOkSFAlpPDirbfHYJ=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.WebCookies_Load(EtajdVcNGXQBqsOkSFAlpPDirbfHYu)
    xbmcvfs.delete(EtajdVcNGXQBqsOkSFAlpPDirbfHYu)
    if EtajdVcNGXQBqsOkSFAlpPDirbfHYJ:
     EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.JsonFile_Save(EtajdVcNGXQBqsOkSFAlpPDirbfHLx,EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.TV)
     EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    EtajdVcNGXQBqsOkSFAlpPDirbfHYJ=EtajdVcNGXQBqsOkSFAlpPDirbfHwT
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYJ==EtajdVcNGXQBqsOkSFAlpPDirbfHwL:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.cookiefile_save()
  else:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHYR=EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('stype')
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYR=='live':
   EtajdVcNGXQBqsOkSFAlpPDirbfHYI=EtajdVcNGXQBqsOkSFAlpPDirbfHLM
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHYR=='vod':
   EtajdVcNGXQBqsOkSFAlpPDirbfHYI=EtajdVcNGXQBqsOkSFAlpPDirbfHLg
  else:
   EtajdVcNGXQBqsOkSFAlpPDirbfHYI=EtajdVcNGXQBqsOkSFAlpPDirbfHLz
  for EtajdVcNGXQBqsOkSFAlpPDirbfHYy in EtajdVcNGXQBqsOkSFAlpPDirbfHYI:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR=EtajdVcNGXQBqsOkSFAlpPDirbfHYy.get('title')
   if EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('ordernm')!='-':
    EtajdVcNGXQBqsOkSFAlpPDirbfHTR+='  ('+EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('ordernm')+')'
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':EtajdVcNGXQBqsOkSFAlpPDirbfHYy.get('mode'),'stype':EtajdVcNGXQBqsOkSFAlpPDirbfHYy.get('stype'),'orderby':EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('orderby'),'ordernm':EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('ordernm'),'page':'1'}
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel='',img='',infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHze,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHwg(EtajdVcNGXQBqsOkSFAlpPDirbfHYI)>0:xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle)
 def dp_SubTitle_Group(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh): 
  for EtajdVcNGXQBqsOkSFAlpPDirbfHYy in EtajdVcNGXQBqsOkSFAlpPDirbfHLw:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR=EtajdVcNGXQBqsOkSFAlpPDirbfHYy.get('title')
   if EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('ordernm')!='-':
    EtajdVcNGXQBqsOkSFAlpPDirbfHTR+='  ('+EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('ordernm')+')'
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':EtajdVcNGXQBqsOkSFAlpPDirbfHYy.get('mode'),'genreCode':EtajdVcNGXQBqsOkSFAlpPDirbfHYy.get('genreCode'),'stype':EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('stype'),'orderby':EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('orderby'),'page':'1'}
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel='',img='',infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHze,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHwg(EtajdVcNGXQBqsOkSFAlpPDirbfHLw)>0:xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle)
 def dp_LiveChannel_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHYR =EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('stype')
  EtajdVcNGXQBqsOkSFAlpPDirbfHYn =EtajdVcNGXQBqsOkSFAlpPDirbfHzv(EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('page'))
  EtajdVcNGXQBqsOkSFAlpPDirbfHYm,EtajdVcNGXQBqsOkSFAlpPDirbfHYe=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.GetLiveChannelList(EtajdVcNGXQBqsOkSFAlpPDirbfHYR,EtajdVcNGXQBqsOkSFAlpPDirbfHYn)
  for EtajdVcNGXQBqsOkSFAlpPDirbfHYv in EtajdVcNGXQBqsOkSFAlpPDirbfHYm:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('title')
   EtajdVcNGXQBqsOkSFAlpPDirbfHYg =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('channel')
   EtajdVcNGXQBqsOkSFAlpPDirbfHML =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('thumbnail')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMT =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('synopsis')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMY =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('channelepg')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMo =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('cast')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMW =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('director')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMg =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('info_genre')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMz =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('year')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMw =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('mpaa')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMK =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('premiered')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMx={'mediatype':'episode','title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'studio':EtajdVcNGXQBqsOkSFAlpPDirbfHYg,'cast':EtajdVcNGXQBqsOkSFAlpPDirbfHMo,'director':EtajdVcNGXQBqsOkSFAlpPDirbfHMW,'genre':EtajdVcNGXQBqsOkSFAlpPDirbfHMg,'plot':'%s\n%s\n%s\n\n%s'%(EtajdVcNGXQBqsOkSFAlpPDirbfHYg,EtajdVcNGXQBqsOkSFAlpPDirbfHTR,EtajdVcNGXQBqsOkSFAlpPDirbfHMY,EtajdVcNGXQBqsOkSFAlpPDirbfHMT),'year':EtajdVcNGXQBqsOkSFAlpPDirbfHMz,'mpaa':EtajdVcNGXQBqsOkSFAlpPDirbfHMw,'premiered':EtajdVcNGXQBqsOkSFAlpPDirbfHMK}
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'LIVE','mediacode':EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('mediacode'),'stype':EtajdVcNGXQBqsOkSFAlpPDirbfHYR}
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHYg,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHTR,img=EtajdVcNGXQBqsOkSFAlpPDirbfHML,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHMx,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwT,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYe:
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['mode']='CHANNEL' 
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['stype']=EtajdVcNGXQBqsOkSFAlpPDirbfHYR 
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['page']=EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR='[B]%s >>[/B]'%'다음 페이지'
   EtajdVcNGXQBqsOkSFAlpPDirbfHMU=EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHYL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHMU,img=EtajdVcNGXQBqsOkSFAlpPDirbfHYL,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHze,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHwg(EtajdVcNGXQBqsOkSFAlpPDirbfHYm)>0:xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,cacheToDisc=EtajdVcNGXQBqsOkSFAlpPDirbfHwT)
 def dp_Program_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHMJ =EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('stype')
  EtajdVcNGXQBqsOkSFAlpPDirbfHTC =EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('orderby')
  EtajdVcNGXQBqsOkSFAlpPDirbfHYn =EtajdVcNGXQBqsOkSFAlpPDirbfHzv(EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('page'))
  EtajdVcNGXQBqsOkSFAlpPDirbfHMC=EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('genreCode')
  if EtajdVcNGXQBqsOkSFAlpPDirbfHMC==EtajdVcNGXQBqsOkSFAlpPDirbfHze:EtajdVcNGXQBqsOkSFAlpPDirbfHMC='all'
  EtajdVcNGXQBqsOkSFAlpPDirbfHMu,EtajdVcNGXQBqsOkSFAlpPDirbfHYe=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.GetProgramList(EtajdVcNGXQBqsOkSFAlpPDirbfHMJ,EtajdVcNGXQBqsOkSFAlpPDirbfHTC,EtajdVcNGXQBqsOkSFAlpPDirbfHYn,EtajdVcNGXQBqsOkSFAlpPDirbfHMC)
  for EtajdVcNGXQBqsOkSFAlpPDirbfHMR in EtajdVcNGXQBqsOkSFAlpPDirbfHMu:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('title')
   EtajdVcNGXQBqsOkSFAlpPDirbfHML =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('thumbnail')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMT =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('synopsis')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMI =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('channel')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMo =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('cast')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMW =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('director')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMg=EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('info_genre')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMz =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('year')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMK =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('premiered')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMw =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('mpaa')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMx={'mediatype':'tvshow','title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'studio':EtajdVcNGXQBqsOkSFAlpPDirbfHMI,'cast':EtajdVcNGXQBqsOkSFAlpPDirbfHMo,'director':EtajdVcNGXQBqsOkSFAlpPDirbfHMW,'genre':EtajdVcNGXQBqsOkSFAlpPDirbfHMg,'year':EtajdVcNGXQBqsOkSFAlpPDirbfHMz,'premiered':EtajdVcNGXQBqsOkSFAlpPDirbfHMK,'mpaa':EtajdVcNGXQBqsOkSFAlpPDirbfHMw,'plot':EtajdVcNGXQBqsOkSFAlpPDirbfHMT}
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'EPISODE','programcode':EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('program'),'page':'1'}
   if EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_makebookmark():
    EtajdVcNGXQBqsOkSFAlpPDirbfHMy={'videoid':EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('program'),'vidtype':'tvshow','vtitle':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'vsubtitle':EtajdVcNGXQBqsOkSFAlpPDirbfHMI,}
    EtajdVcNGXQBqsOkSFAlpPDirbfHMh=json.dumps(EtajdVcNGXQBqsOkSFAlpPDirbfHMy)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMh=urllib.parse.quote(EtajdVcNGXQBqsOkSFAlpPDirbfHMh)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMn='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(EtajdVcNGXQBqsOkSFAlpPDirbfHMh)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMm=[('(통합) 찜 영상에 추가',EtajdVcNGXQBqsOkSFAlpPDirbfHMn)]
   else:
    EtajdVcNGXQBqsOkSFAlpPDirbfHMm=EtajdVcNGXQBqsOkSFAlpPDirbfHze
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHMI,img=EtajdVcNGXQBqsOkSFAlpPDirbfHML,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHMx,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT,ContextMenu=EtajdVcNGXQBqsOkSFAlpPDirbfHMm)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYe:
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['mode'] ='PROGRAM' 
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['stype'] =EtajdVcNGXQBqsOkSFAlpPDirbfHMJ
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['orderby'] =EtajdVcNGXQBqsOkSFAlpPDirbfHTC
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['page'] =EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['genreCode']=EtajdVcNGXQBqsOkSFAlpPDirbfHMC 
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR='[B]%s >>[/B]'%'다음 페이지'
   EtajdVcNGXQBqsOkSFAlpPDirbfHMU=EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHYL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHMU,img=EtajdVcNGXQBqsOkSFAlpPDirbfHYL,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHze,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  xbmcplugin.setContent(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,cacheToDisc=EtajdVcNGXQBqsOkSFAlpPDirbfHwT)
 def dp_4K_Program_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHYn =EtajdVcNGXQBqsOkSFAlpPDirbfHzv(EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('page'))
  EtajdVcNGXQBqsOkSFAlpPDirbfHMu,EtajdVcNGXQBqsOkSFAlpPDirbfHYe=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Get_UHD_ProgramList(EtajdVcNGXQBqsOkSFAlpPDirbfHYn)
  for EtajdVcNGXQBqsOkSFAlpPDirbfHMR in EtajdVcNGXQBqsOkSFAlpPDirbfHMu:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('title')
   EtajdVcNGXQBqsOkSFAlpPDirbfHML =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('thumbnail')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMT =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('synopsis')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMI =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('channel')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMo =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('cast')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMW =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('director')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMg=EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('info_genre')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMz =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('year')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMK =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('premiered')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMw =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('mpaa')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMx={'mediatype':'tvshow','title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'studio':EtajdVcNGXQBqsOkSFAlpPDirbfHMI,'cast':EtajdVcNGXQBqsOkSFAlpPDirbfHMo,'director':EtajdVcNGXQBqsOkSFAlpPDirbfHMW,'genre':EtajdVcNGXQBqsOkSFAlpPDirbfHMg,'year':EtajdVcNGXQBqsOkSFAlpPDirbfHMz,'premiered':EtajdVcNGXQBqsOkSFAlpPDirbfHMK,'mpaa':EtajdVcNGXQBqsOkSFAlpPDirbfHMw,'plot':EtajdVcNGXQBqsOkSFAlpPDirbfHMT}
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'EPISODE','programcode':EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('program'),'page':'1'}
   if EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_makebookmark():
    EtajdVcNGXQBqsOkSFAlpPDirbfHMy={'videoid':EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('program'),'vidtype':'tvshow','vtitle':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'vsubtitle':EtajdVcNGXQBqsOkSFAlpPDirbfHMI,}
    EtajdVcNGXQBqsOkSFAlpPDirbfHMh=json.dumps(EtajdVcNGXQBqsOkSFAlpPDirbfHMy)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMh=urllib.parse.quote(EtajdVcNGXQBqsOkSFAlpPDirbfHMh)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMn='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(EtajdVcNGXQBqsOkSFAlpPDirbfHMh)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMm=[('(통합) 찜 영상에 추가',EtajdVcNGXQBqsOkSFAlpPDirbfHMn)]
   else:
    EtajdVcNGXQBqsOkSFAlpPDirbfHMm=EtajdVcNGXQBqsOkSFAlpPDirbfHze
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHMI,img=EtajdVcNGXQBqsOkSFAlpPDirbfHML,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHMx,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT,ContextMenu=EtajdVcNGXQBqsOkSFAlpPDirbfHMm)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYe:
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['mode'] ='4K_PROGRAM' 
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['page'] =EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR='[B]%s >>[/B]'%'다음 페이지'
   EtajdVcNGXQBqsOkSFAlpPDirbfHMU=EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHYL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHMU,img=EtajdVcNGXQBqsOkSFAlpPDirbfHYL,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHze,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  xbmcplugin.setContent(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,cacheToDisc=EtajdVcNGXQBqsOkSFAlpPDirbfHwT)
 def dp_Ori_Program_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHYn =EtajdVcNGXQBqsOkSFAlpPDirbfHzv(EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('page'))
  EtajdVcNGXQBqsOkSFAlpPDirbfHMu,EtajdVcNGXQBqsOkSFAlpPDirbfHYe=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Get_Origianl_ProgramList(EtajdVcNGXQBqsOkSFAlpPDirbfHYn)
  for EtajdVcNGXQBqsOkSFAlpPDirbfHMR in EtajdVcNGXQBqsOkSFAlpPDirbfHMu:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('title')
   EtajdVcNGXQBqsOkSFAlpPDirbfHML =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('thumbnail')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMv =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('vod_type')
   EtajdVcNGXQBqsOkSFAlpPDirbfHoL =EtajdVcNGXQBqsOkSFAlpPDirbfHMR.get('vod_code')
   if EtajdVcNGXQBqsOkSFAlpPDirbfHMv=='vod':
    EtajdVcNGXQBqsOkSFAlpPDirbfHMx={'mediatype':'tvshow','title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,}
    EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'EPISODE','programcode':EtajdVcNGXQBqsOkSFAlpPDirbfHoL,'page':'1',}
    EtajdVcNGXQBqsOkSFAlpPDirbfHYM=EtajdVcNGXQBqsOkSFAlpPDirbfHwL
   else:
    EtajdVcNGXQBqsOkSFAlpPDirbfHMx={'mediatype':'movie','title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'plot':'movie',}
    EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'MOVIE','mediacode':EtajdVcNGXQBqsOkSFAlpPDirbfHoL,'stype':'movie','title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'thumbnail':EtajdVcNGXQBqsOkSFAlpPDirbfHML,}
    EtajdVcNGXQBqsOkSFAlpPDirbfHYM=EtajdVcNGXQBqsOkSFAlpPDirbfHwT
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHze,img=EtajdVcNGXQBqsOkSFAlpPDirbfHML,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHMx,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHYM,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT,ContextMenu=EtajdVcNGXQBqsOkSFAlpPDirbfHze)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYe:
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['mode'] ='ORI_PROGRAM' 
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['page'] =EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR='[B]%s >>[/B]'%'다음 페이지'
   EtajdVcNGXQBqsOkSFAlpPDirbfHMU=EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHYL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHMU,img=EtajdVcNGXQBqsOkSFAlpPDirbfHYL,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHze,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  xbmcplugin.setContent(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,cacheToDisc=EtajdVcNGXQBqsOkSFAlpPDirbfHwT)
 def dp_Episode_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHoT=EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('programcode')
  EtajdVcNGXQBqsOkSFAlpPDirbfHYn =EtajdVcNGXQBqsOkSFAlpPDirbfHzv(EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('page'))
  EtajdVcNGXQBqsOkSFAlpPDirbfHoY,EtajdVcNGXQBqsOkSFAlpPDirbfHYe,EtajdVcNGXQBqsOkSFAlpPDirbfHoM=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.GetEpisodeList(EtajdVcNGXQBqsOkSFAlpPDirbfHoT,EtajdVcNGXQBqsOkSFAlpPDirbfHYn,orderby=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_winEpisodeOrderby())
  for EtajdVcNGXQBqsOkSFAlpPDirbfHoW in EtajdVcNGXQBqsOkSFAlpPDirbfHoY:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR =EtajdVcNGXQBqsOkSFAlpPDirbfHoW.get('title')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMU =EtajdVcNGXQBqsOkSFAlpPDirbfHoW.get('subtitle')
   EtajdVcNGXQBqsOkSFAlpPDirbfHML =EtajdVcNGXQBqsOkSFAlpPDirbfHoW.get('thumbnail')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMT =EtajdVcNGXQBqsOkSFAlpPDirbfHoW.get('synopsis')
   EtajdVcNGXQBqsOkSFAlpPDirbfHog=EtajdVcNGXQBqsOkSFAlpPDirbfHoW.get('info_title')
   EtajdVcNGXQBqsOkSFAlpPDirbfHoz =EtajdVcNGXQBqsOkSFAlpPDirbfHoW.get('aired')
   EtajdVcNGXQBqsOkSFAlpPDirbfHow =EtajdVcNGXQBqsOkSFAlpPDirbfHoW.get('studio')
   EtajdVcNGXQBqsOkSFAlpPDirbfHoK =EtajdVcNGXQBqsOkSFAlpPDirbfHoW.get('frequency')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMx={'mediatype':'episode','title':EtajdVcNGXQBqsOkSFAlpPDirbfHog,'aired':EtajdVcNGXQBqsOkSFAlpPDirbfHoz,'studio':EtajdVcNGXQBqsOkSFAlpPDirbfHow,'episode':EtajdVcNGXQBqsOkSFAlpPDirbfHoK,'plot':EtajdVcNGXQBqsOkSFAlpPDirbfHMT}
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'VOD','mediacode':EtajdVcNGXQBqsOkSFAlpPDirbfHoW.get('episode'),'stype':'vod','programcode':EtajdVcNGXQBqsOkSFAlpPDirbfHoT,'title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'thumbnail':EtajdVcNGXQBqsOkSFAlpPDirbfHML}
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHMU,img=EtajdVcNGXQBqsOkSFAlpPDirbfHML,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHMx,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwT,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYn==1:
   EtajdVcNGXQBqsOkSFAlpPDirbfHMx={'plot':'정렬순서를 변경합니다.'}
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={}
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['mode'] ='ORDER_BY' 
   if EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_winEpisodeOrderby()=='desc':
    EtajdVcNGXQBqsOkSFAlpPDirbfHTR='정렬순서변경 : 최신화부터 -> 1회부터'
    EtajdVcNGXQBqsOkSFAlpPDirbfHYT['orderby']='asc'
   else:
    EtajdVcNGXQBqsOkSFAlpPDirbfHTR='정렬순서변경 : 1회부터 -> 최신화부터'
    EtajdVcNGXQBqsOkSFAlpPDirbfHYT['orderby']='desc'
   EtajdVcNGXQBqsOkSFAlpPDirbfHYL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel='',img=EtajdVcNGXQBqsOkSFAlpPDirbfHYL,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHMx,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwT,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT,isLink=EtajdVcNGXQBqsOkSFAlpPDirbfHwL)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYe:
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['mode'] ='EPISODE' 
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['programcode']=EtajdVcNGXQBqsOkSFAlpPDirbfHoT
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['page'] =EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR='[B]%s >>[/B]'%'다음 페이지'
   EtajdVcNGXQBqsOkSFAlpPDirbfHMU=EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHYL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHMU,img=EtajdVcNGXQBqsOkSFAlpPDirbfHYL,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHze,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  xbmcplugin.setContent(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,'episodes')
  if EtajdVcNGXQBqsOkSFAlpPDirbfHwg(EtajdVcNGXQBqsOkSFAlpPDirbfHoY)>0:xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,cacheToDisc=EtajdVcNGXQBqsOkSFAlpPDirbfHwL)
 def dp_setEpOrderby(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHTC =EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('orderby')
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.set_winEpisodeOrderby(EtajdVcNGXQBqsOkSFAlpPDirbfHTC)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHMJ =EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('stype')
  EtajdVcNGXQBqsOkSFAlpPDirbfHTC =EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('orderby')
  EtajdVcNGXQBqsOkSFAlpPDirbfHYn=EtajdVcNGXQBqsOkSFAlpPDirbfHzv(EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('page'))
  EtajdVcNGXQBqsOkSFAlpPDirbfHox,EtajdVcNGXQBqsOkSFAlpPDirbfHYe=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.GetMovieList(EtajdVcNGXQBqsOkSFAlpPDirbfHMJ,EtajdVcNGXQBqsOkSFAlpPDirbfHTC,EtajdVcNGXQBqsOkSFAlpPDirbfHYn)
  for EtajdVcNGXQBqsOkSFAlpPDirbfHoU in EtajdVcNGXQBqsOkSFAlpPDirbfHox:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('title')
   EtajdVcNGXQBqsOkSFAlpPDirbfHML =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('thumbnail')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMT =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('synopsis')
   EtajdVcNGXQBqsOkSFAlpPDirbfHog =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('info_title')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMz =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('year')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMo =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('cast')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMW =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('director')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMg =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('info_genre')
   EtajdVcNGXQBqsOkSFAlpPDirbfHoJ =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('duration')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMK =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('premiered')
   EtajdVcNGXQBqsOkSFAlpPDirbfHow =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('studio')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMw =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('mpaa')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMx={'mediatype':'movie','title':EtajdVcNGXQBqsOkSFAlpPDirbfHog,'year':EtajdVcNGXQBqsOkSFAlpPDirbfHMz,'cast':EtajdVcNGXQBqsOkSFAlpPDirbfHMo,'director':EtajdVcNGXQBqsOkSFAlpPDirbfHMW,'genre':EtajdVcNGXQBqsOkSFAlpPDirbfHMg,'duration':EtajdVcNGXQBqsOkSFAlpPDirbfHoJ,'premiered':EtajdVcNGXQBqsOkSFAlpPDirbfHMK,'studio':EtajdVcNGXQBqsOkSFAlpPDirbfHow,'mpaa':EtajdVcNGXQBqsOkSFAlpPDirbfHMw,'plot':EtajdVcNGXQBqsOkSFAlpPDirbfHMT}
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'MOVIE','mediacode':EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('moviecode'),'stype':'movie','title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'thumbnail':EtajdVcNGXQBqsOkSFAlpPDirbfHML}
   if EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_makebookmark():
    EtajdVcNGXQBqsOkSFAlpPDirbfHMy={'videoid':EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('moviecode'),'vidtype':'movie','vtitle':EtajdVcNGXQBqsOkSFAlpPDirbfHog,'vsubtitle':'',}
    EtajdVcNGXQBqsOkSFAlpPDirbfHMh=json.dumps(EtajdVcNGXQBqsOkSFAlpPDirbfHMy)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMh=urllib.parse.quote(EtajdVcNGXQBqsOkSFAlpPDirbfHMh)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMn='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(EtajdVcNGXQBqsOkSFAlpPDirbfHMh)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMm=[('(통합) 찜 영상에 추가',EtajdVcNGXQBqsOkSFAlpPDirbfHMn)]
   else:
    EtajdVcNGXQBqsOkSFAlpPDirbfHMm=EtajdVcNGXQBqsOkSFAlpPDirbfHze
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel='',img=EtajdVcNGXQBqsOkSFAlpPDirbfHML,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHMx,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwT,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT,ContextMenu=EtajdVcNGXQBqsOkSFAlpPDirbfHMm)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYe:
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={}
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['mode'] ='MOVIE_SUB' 
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['orderby']=EtajdVcNGXQBqsOkSFAlpPDirbfHTC
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['stype'] =EtajdVcNGXQBqsOkSFAlpPDirbfHMJ
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['page'] =EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR='[B]%s >>[/B]'%'다음 페이지'
   EtajdVcNGXQBqsOkSFAlpPDirbfHMU=EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHYL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHMU,img=EtajdVcNGXQBqsOkSFAlpPDirbfHYL,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHze,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  xbmcplugin.setContent(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,'movies')
  xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,cacheToDisc=EtajdVcNGXQBqsOkSFAlpPDirbfHwT)
 def dp_4K_Movie_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHYn=EtajdVcNGXQBqsOkSFAlpPDirbfHzv(EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('page'))
  EtajdVcNGXQBqsOkSFAlpPDirbfHox,EtajdVcNGXQBqsOkSFAlpPDirbfHYe=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Get_UHD_MovieList(EtajdVcNGXQBqsOkSFAlpPDirbfHYn)
  for EtajdVcNGXQBqsOkSFAlpPDirbfHoU in EtajdVcNGXQBqsOkSFAlpPDirbfHox:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('title')
   EtajdVcNGXQBqsOkSFAlpPDirbfHML =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('thumbnail')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMT =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('synopsis')
   EtajdVcNGXQBqsOkSFAlpPDirbfHog =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('info_title')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMz =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('year')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMo =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('cast')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMW =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('director')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMg =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('info_genre')
   EtajdVcNGXQBqsOkSFAlpPDirbfHoJ =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('duration')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMK =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('premiered')
   EtajdVcNGXQBqsOkSFAlpPDirbfHow =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('studio')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMw =EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('mpaa')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMx={'mediatype':'movie','title':EtajdVcNGXQBqsOkSFAlpPDirbfHog,'year':EtajdVcNGXQBqsOkSFAlpPDirbfHMz,'cast':EtajdVcNGXQBqsOkSFAlpPDirbfHMo,'director':EtajdVcNGXQBqsOkSFAlpPDirbfHMW,'genre':EtajdVcNGXQBqsOkSFAlpPDirbfHMg,'duration':EtajdVcNGXQBqsOkSFAlpPDirbfHoJ,'premiered':EtajdVcNGXQBqsOkSFAlpPDirbfHMK,'studio':EtajdVcNGXQBqsOkSFAlpPDirbfHow,'mpaa':EtajdVcNGXQBqsOkSFAlpPDirbfHMw,'plot':EtajdVcNGXQBqsOkSFAlpPDirbfHMT}
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'MOVIE','mediacode':EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('moviecode'),'stype':'movie','title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'thumbnail':EtajdVcNGXQBqsOkSFAlpPDirbfHML}
   if EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_makebookmark():
    EtajdVcNGXQBqsOkSFAlpPDirbfHMy={'videoid':EtajdVcNGXQBqsOkSFAlpPDirbfHoU.get('moviecode'),'vidtype':'movie','vtitle':EtajdVcNGXQBqsOkSFAlpPDirbfHog,'vsubtitle':'',}
    EtajdVcNGXQBqsOkSFAlpPDirbfHMh=json.dumps(EtajdVcNGXQBqsOkSFAlpPDirbfHMy)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMh=urllib.parse.quote(EtajdVcNGXQBqsOkSFAlpPDirbfHMh)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMn='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(EtajdVcNGXQBqsOkSFAlpPDirbfHMh)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMm=[('(통합) 찜 영상에 추가',EtajdVcNGXQBqsOkSFAlpPDirbfHMn)]
   else:
    EtajdVcNGXQBqsOkSFAlpPDirbfHMm=EtajdVcNGXQBqsOkSFAlpPDirbfHze
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel='',img=EtajdVcNGXQBqsOkSFAlpPDirbfHML,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHMx,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwT,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT,ContextMenu=EtajdVcNGXQBqsOkSFAlpPDirbfHMm)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYe:
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={}
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['mode'] ='4K_MOVIE' 
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['page'] =EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR='[B]%s >>[/B]'%'다음 페이지'
   EtajdVcNGXQBqsOkSFAlpPDirbfHMU=EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHYL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHMU,img=EtajdVcNGXQBqsOkSFAlpPDirbfHYL,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHze,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  xbmcplugin.setContent(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,'movies')
  xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,cacheToDisc=EtajdVcNGXQBqsOkSFAlpPDirbfHwT)
 def dp_Set_Bookmark(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHoC=urllib.parse.unquote(EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('bm_param'))
  EtajdVcNGXQBqsOkSFAlpPDirbfHoC=json.loads(EtajdVcNGXQBqsOkSFAlpPDirbfHoC)
  EtajdVcNGXQBqsOkSFAlpPDirbfHou =EtajdVcNGXQBqsOkSFAlpPDirbfHoC.get('videoid')
  EtajdVcNGXQBqsOkSFAlpPDirbfHoR =EtajdVcNGXQBqsOkSFAlpPDirbfHoC.get('vidtype')
  EtajdVcNGXQBqsOkSFAlpPDirbfHoI =EtajdVcNGXQBqsOkSFAlpPDirbfHoC.get('vtitle')
  EtajdVcNGXQBqsOkSFAlpPDirbfHoy =EtajdVcNGXQBqsOkSFAlpPDirbfHoC.get('vsubtitle')
  EtajdVcNGXQBqsOkSFAlpPDirbfHLy=xbmcgui.Dialog()
  EtajdVcNGXQBqsOkSFAlpPDirbfHYU=EtajdVcNGXQBqsOkSFAlpPDirbfHLy.yesno(__language__(30913).encode('utf8'),EtajdVcNGXQBqsOkSFAlpPDirbfHoI+' \n\n'+__language__(30914))
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYU==EtajdVcNGXQBqsOkSFAlpPDirbfHwT:return
  EtajdVcNGXQBqsOkSFAlpPDirbfHoh=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.GetBookmarkInfo(EtajdVcNGXQBqsOkSFAlpPDirbfHou,EtajdVcNGXQBqsOkSFAlpPDirbfHoR)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHoy!='':
   EtajdVcNGXQBqsOkSFAlpPDirbfHoh['saveinfo']['subtitle']=EtajdVcNGXQBqsOkSFAlpPDirbfHoy 
   if EtajdVcNGXQBqsOkSFAlpPDirbfHoR=='tvshow':EtajdVcNGXQBqsOkSFAlpPDirbfHoh['saveinfo']['infoLabels']['studio']=EtajdVcNGXQBqsOkSFAlpPDirbfHoy 
  EtajdVcNGXQBqsOkSFAlpPDirbfHon=json.dumps(EtajdVcNGXQBqsOkSFAlpPDirbfHoh)
  EtajdVcNGXQBqsOkSFAlpPDirbfHon=urllib.parse.quote(EtajdVcNGXQBqsOkSFAlpPDirbfHon)
  EtajdVcNGXQBqsOkSFAlpPDirbfHMn ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(EtajdVcNGXQBqsOkSFAlpPDirbfHon)
  xbmc.executebuiltin(EtajdVcNGXQBqsOkSFAlpPDirbfHMn)
 def dp_Search_Group(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  if 'search_key' in EtajdVcNGXQBqsOkSFAlpPDirbfHYh:
   EtajdVcNGXQBqsOkSFAlpPDirbfHom=EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('search_key')
  else:
   EtajdVcNGXQBqsOkSFAlpPDirbfHom=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not EtajdVcNGXQBqsOkSFAlpPDirbfHom:
    return
  for EtajdVcNGXQBqsOkSFAlpPDirbfHYy in EtajdVcNGXQBqsOkSFAlpPDirbfHLW:
   EtajdVcNGXQBqsOkSFAlpPDirbfHoe =EtajdVcNGXQBqsOkSFAlpPDirbfHYy.get('mode')
   EtajdVcNGXQBqsOkSFAlpPDirbfHYR=EtajdVcNGXQBqsOkSFAlpPDirbfHYy.get('stype')
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR=EtajdVcNGXQBqsOkSFAlpPDirbfHYy.get('title')
   (EtajdVcNGXQBqsOkSFAlpPDirbfHov,EtajdVcNGXQBqsOkSFAlpPDirbfHYe)=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.GetSearchList(EtajdVcNGXQBqsOkSFAlpPDirbfHom,1,EtajdVcNGXQBqsOkSFAlpPDirbfHYR)
   EtajdVcNGXQBqsOkSFAlpPDirbfHYW={'plot':'검색어 : '+EtajdVcNGXQBqsOkSFAlpPDirbfHom+'\n\n'+EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.Search_FreeList(EtajdVcNGXQBqsOkSFAlpPDirbfHov)}
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':EtajdVcNGXQBqsOkSFAlpPDirbfHoe,'stype':EtajdVcNGXQBqsOkSFAlpPDirbfHYR,'search_key':EtajdVcNGXQBqsOkSFAlpPDirbfHom,'page':'1',}
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel='',img='',infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHYW,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHwg(EtajdVcNGXQBqsOkSFAlpPDirbfHLW)>0:xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,cacheToDisc=EtajdVcNGXQBqsOkSFAlpPDirbfHwL)
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.Save_Searched_List(EtajdVcNGXQBqsOkSFAlpPDirbfHom)
 def Search_FreeList(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHWK):
  EtajdVcNGXQBqsOkSFAlpPDirbfHWL=''
  EtajdVcNGXQBqsOkSFAlpPDirbfHWT=7
  try:
   if EtajdVcNGXQBqsOkSFAlpPDirbfHwg(EtajdVcNGXQBqsOkSFAlpPDirbfHWK)==0:return '검색결과 없음'
   for i in EtajdVcNGXQBqsOkSFAlpPDirbfHwK(EtajdVcNGXQBqsOkSFAlpPDirbfHwg(EtajdVcNGXQBqsOkSFAlpPDirbfHWK)):
    if i>=EtajdVcNGXQBqsOkSFAlpPDirbfHWT:
     EtajdVcNGXQBqsOkSFAlpPDirbfHWL=EtajdVcNGXQBqsOkSFAlpPDirbfHWL+'...'
     break
    EtajdVcNGXQBqsOkSFAlpPDirbfHWL=EtajdVcNGXQBqsOkSFAlpPDirbfHWL+EtajdVcNGXQBqsOkSFAlpPDirbfHWK[i]['title']+'\n'
  except:
   return ''
  return EtajdVcNGXQBqsOkSFAlpPDirbfHWL
 def dp_Search_History(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHWY=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.Load_List_File('search')
  for EtajdVcNGXQBqsOkSFAlpPDirbfHWM in EtajdVcNGXQBqsOkSFAlpPDirbfHWY:
   EtajdVcNGXQBqsOkSFAlpPDirbfHWo=EtajdVcNGXQBqsOkSFAlpPDirbfHwM(urllib.parse.parse_qsl(EtajdVcNGXQBqsOkSFAlpPDirbfHWM))
   EtajdVcNGXQBqsOkSFAlpPDirbfHWg=EtajdVcNGXQBqsOkSFAlpPDirbfHWo.get('skey').strip()
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'SEARCH_GROUP','search_key':EtajdVcNGXQBqsOkSFAlpPDirbfHWg,}
   EtajdVcNGXQBqsOkSFAlpPDirbfHWz={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':EtajdVcNGXQBqsOkSFAlpPDirbfHWg,'vType':'-',}
   EtajdVcNGXQBqsOkSFAlpPDirbfHWw=urllib.parse.urlencode(EtajdVcNGXQBqsOkSFAlpPDirbfHWz)
   EtajdVcNGXQBqsOkSFAlpPDirbfHMm=[('선택된 검색어 ( %s ) 삭제'%(EtajdVcNGXQBqsOkSFAlpPDirbfHWg),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(EtajdVcNGXQBqsOkSFAlpPDirbfHWw))]
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHWg,sublabel='',img=EtajdVcNGXQBqsOkSFAlpPDirbfHze,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHze,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT,ContextMenu=EtajdVcNGXQBqsOkSFAlpPDirbfHMm)
  EtajdVcNGXQBqsOkSFAlpPDirbfHMx={'plot':'검색목록 전체를 삭제합니다.'}
  EtajdVcNGXQBqsOkSFAlpPDirbfHTR='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  EtajdVcNGXQBqsOkSFAlpPDirbfHYL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel='',img=EtajdVcNGXQBqsOkSFAlpPDirbfHYL,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHMx,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwT,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT,isLink=EtajdVcNGXQBqsOkSFAlpPDirbfHwL)
  xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,cacheToDisc=EtajdVcNGXQBqsOkSFAlpPDirbfHwT)
 def dp_Search_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHYn =EtajdVcNGXQBqsOkSFAlpPDirbfHzv(EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('page'))
  EtajdVcNGXQBqsOkSFAlpPDirbfHYR =EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('stype')
  if 'search_key' in EtajdVcNGXQBqsOkSFAlpPDirbfHYh:
   EtajdVcNGXQBqsOkSFAlpPDirbfHom=EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('search_key')
  else:
   EtajdVcNGXQBqsOkSFAlpPDirbfHom=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not EtajdVcNGXQBqsOkSFAlpPDirbfHom:
    xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle)
    return
  EtajdVcNGXQBqsOkSFAlpPDirbfHov,EtajdVcNGXQBqsOkSFAlpPDirbfHYe=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.GetSearchList(EtajdVcNGXQBqsOkSFAlpPDirbfHom,EtajdVcNGXQBqsOkSFAlpPDirbfHYn,EtajdVcNGXQBqsOkSFAlpPDirbfHYR)
  for EtajdVcNGXQBqsOkSFAlpPDirbfHWK in EtajdVcNGXQBqsOkSFAlpPDirbfHov:
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR =EtajdVcNGXQBqsOkSFAlpPDirbfHWK.get('title')
   EtajdVcNGXQBqsOkSFAlpPDirbfHML =EtajdVcNGXQBqsOkSFAlpPDirbfHWK.get('thumbnail')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMT =EtajdVcNGXQBqsOkSFAlpPDirbfHWK.get('synopsis')
   EtajdVcNGXQBqsOkSFAlpPDirbfHWx =EtajdVcNGXQBqsOkSFAlpPDirbfHWK.get('program')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMo =EtajdVcNGXQBqsOkSFAlpPDirbfHWK.get('cast')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMW =EtajdVcNGXQBqsOkSFAlpPDirbfHWK.get('director')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMg=EtajdVcNGXQBqsOkSFAlpPDirbfHWK.get('info_genre')
   EtajdVcNGXQBqsOkSFAlpPDirbfHoJ =EtajdVcNGXQBqsOkSFAlpPDirbfHWK.get('duration')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMw =EtajdVcNGXQBqsOkSFAlpPDirbfHWK.get('mpaa')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMz =EtajdVcNGXQBqsOkSFAlpPDirbfHWK.get('year')
   EtajdVcNGXQBqsOkSFAlpPDirbfHoz =EtajdVcNGXQBqsOkSFAlpPDirbfHWK.get('aired')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMx={'mediatype':'tvshow' if EtajdVcNGXQBqsOkSFAlpPDirbfHYR=='vod' else 'movie','title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'cast':EtajdVcNGXQBqsOkSFAlpPDirbfHMo,'director':EtajdVcNGXQBqsOkSFAlpPDirbfHMW,'genre':EtajdVcNGXQBqsOkSFAlpPDirbfHMg,'duration':EtajdVcNGXQBqsOkSFAlpPDirbfHoJ,'mpaa':EtajdVcNGXQBqsOkSFAlpPDirbfHMw,'year':EtajdVcNGXQBqsOkSFAlpPDirbfHMz,'aired':EtajdVcNGXQBqsOkSFAlpPDirbfHoz,'plot':'%s\n\n%s'%(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,EtajdVcNGXQBqsOkSFAlpPDirbfHMT)}
   if EtajdVcNGXQBqsOkSFAlpPDirbfHYR=='vod':
    EtajdVcNGXQBqsOkSFAlpPDirbfHou=EtajdVcNGXQBqsOkSFAlpPDirbfHWK.get('program')
    EtajdVcNGXQBqsOkSFAlpPDirbfHoR='tvshow'
    EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'EPISODE','programcode':EtajdVcNGXQBqsOkSFAlpPDirbfHou,'page':'1',}
    EtajdVcNGXQBqsOkSFAlpPDirbfHYM=EtajdVcNGXQBqsOkSFAlpPDirbfHwL
   else:
    EtajdVcNGXQBqsOkSFAlpPDirbfHou=EtajdVcNGXQBqsOkSFAlpPDirbfHWK.get('movie')
    EtajdVcNGXQBqsOkSFAlpPDirbfHoR='movie'
    EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'MOVIE','mediacode':EtajdVcNGXQBqsOkSFAlpPDirbfHou,'stype':'movie','title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'thumbnail':EtajdVcNGXQBqsOkSFAlpPDirbfHML,}
    EtajdVcNGXQBqsOkSFAlpPDirbfHYM=EtajdVcNGXQBqsOkSFAlpPDirbfHwT
   if EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_makebookmark():
    EtajdVcNGXQBqsOkSFAlpPDirbfHMy={'videoid':EtajdVcNGXQBqsOkSFAlpPDirbfHou,'vidtype':EtajdVcNGXQBqsOkSFAlpPDirbfHoR,'vtitle':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'vsubtitle':'',}
    EtajdVcNGXQBqsOkSFAlpPDirbfHMh=json.dumps(EtajdVcNGXQBqsOkSFAlpPDirbfHMy)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMh=urllib.parse.quote(EtajdVcNGXQBqsOkSFAlpPDirbfHMh)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMn='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(EtajdVcNGXQBqsOkSFAlpPDirbfHMh)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMm=[('(통합) 찜 영상에 추가',EtajdVcNGXQBqsOkSFAlpPDirbfHMn)]
   else:
    EtajdVcNGXQBqsOkSFAlpPDirbfHMm=EtajdVcNGXQBqsOkSFAlpPDirbfHze
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel='',img=EtajdVcNGXQBqsOkSFAlpPDirbfHML,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHMx,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHYM,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT,isLink=EtajdVcNGXQBqsOkSFAlpPDirbfHwT,ContextMenu=EtajdVcNGXQBqsOkSFAlpPDirbfHMm)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYe:
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['mode'] ='SEARCH' 
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['search_key']=EtajdVcNGXQBqsOkSFAlpPDirbfHom
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT['page'] =EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR='[B]%s >>[/B]'%'다음 페이지'
   EtajdVcNGXQBqsOkSFAlpPDirbfHMU=EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHYn+1)
   EtajdVcNGXQBqsOkSFAlpPDirbfHYL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHMU,img=EtajdVcNGXQBqsOkSFAlpPDirbfHYL,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHze,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYR=='movie':xbmcplugin.setContent(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,'movies')
  else:xbmcplugin.setContent(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,cacheToDisc=EtajdVcNGXQBqsOkSFAlpPDirbfHwT)
 def dp_History_Remove(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHWU=EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('delType')
  EtajdVcNGXQBqsOkSFAlpPDirbfHWJ =EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('sKey')
  EtajdVcNGXQBqsOkSFAlpPDirbfHWC =EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('vType')
  EtajdVcNGXQBqsOkSFAlpPDirbfHLy=xbmcgui.Dialog()
  if EtajdVcNGXQBqsOkSFAlpPDirbfHWU=='SEARCH_ALL':
   EtajdVcNGXQBqsOkSFAlpPDirbfHYU=EtajdVcNGXQBqsOkSFAlpPDirbfHLy.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHWU=='SEARCH_ONE':
   EtajdVcNGXQBqsOkSFAlpPDirbfHYU=EtajdVcNGXQBqsOkSFAlpPDirbfHLy.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHWU=='WATCH_ALL':
   EtajdVcNGXQBqsOkSFAlpPDirbfHYU=EtajdVcNGXQBqsOkSFAlpPDirbfHLy.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHWU=='WATCH_ONE':
   EtajdVcNGXQBqsOkSFAlpPDirbfHYU=EtajdVcNGXQBqsOkSFAlpPDirbfHLy.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYU==EtajdVcNGXQBqsOkSFAlpPDirbfHwT:sys.exit()
  if EtajdVcNGXQBqsOkSFAlpPDirbfHWU=='SEARCH_ALL':
   if os.path.isfile(EtajdVcNGXQBqsOkSFAlpPDirbfHLU):os.remove(EtajdVcNGXQBqsOkSFAlpPDirbfHLU)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHWU=='SEARCH_ONE':
   try:
    EtajdVcNGXQBqsOkSFAlpPDirbfHWu=EtajdVcNGXQBqsOkSFAlpPDirbfHLU
    EtajdVcNGXQBqsOkSFAlpPDirbfHWR=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.Load_List_File('search') 
    fp=EtajdVcNGXQBqsOkSFAlpPDirbfHwx(EtajdVcNGXQBqsOkSFAlpPDirbfHWu,'w',-1,'utf-8')
    for EtajdVcNGXQBqsOkSFAlpPDirbfHWI in EtajdVcNGXQBqsOkSFAlpPDirbfHWR:
     EtajdVcNGXQBqsOkSFAlpPDirbfHWy=EtajdVcNGXQBqsOkSFAlpPDirbfHwM(urllib.parse.parse_qsl(EtajdVcNGXQBqsOkSFAlpPDirbfHWI))
     EtajdVcNGXQBqsOkSFAlpPDirbfHWh=EtajdVcNGXQBqsOkSFAlpPDirbfHWy.get('skey').strip()
     if EtajdVcNGXQBqsOkSFAlpPDirbfHWJ!=EtajdVcNGXQBqsOkSFAlpPDirbfHWh:
      fp.write(EtajdVcNGXQBqsOkSFAlpPDirbfHWI)
    fp.close()
   except:
    EtajdVcNGXQBqsOkSFAlpPDirbfHze
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHWU=='WATCH_ALL':
   EtajdVcNGXQBqsOkSFAlpPDirbfHWu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EtajdVcNGXQBqsOkSFAlpPDirbfHWC))
   if os.path.isfile(EtajdVcNGXQBqsOkSFAlpPDirbfHWu):os.remove(EtajdVcNGXQBqsOkSFAlpPDirbfHWu)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHWU=='WATCH_ONE':
   EtajdVcNGXQBqsOkSFAlpPDirbfHWu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EtajdVcNGXQBqsOkSFAlpPDirbfHWC))
   try:
    EtajdVcNGXQBqsOkSFAlpPDirbfHWR=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.Load_List_File(EtajdVcNGXQBqsOkSFAlpPDirbfHWC) 
    fp=EtajdVcNGXQBqsOkSFAlpPDirbfHwx(EtajdVcNGXQBqsOkSFAlpPDirbfHWu,'w',-1,'utf-8')
    for EtajdVcNGXQBqsOkSFAlpPDirbfHWI in EtajdVcNGXQBqsOkSFAlpPDirbfHWR:
     EtajdVcNGXQBqsOkSFAlpPDirbfHWy=EtajdVcNGXQBqsOkSFAlpPDirbfHwM(urllib.parse.parse_qsl(EtajdVcNGXQBqsOkSFAlpPDirbfHWI))
     EtajdVcNGXQBqsOkSFAlpPDirbfHWh=EtajdVcNGXQBqsOkSFAlpPDirbfHWy.get('code').strip()
     if EtajdVcNGXQBqsOkSFAlpPDirbfHWJ!=EtajdVcNGXQBqsOkSFAlpPDirbfHWh:
      fp.write(EtajdVcNGXQBqsOkSFAlpPDirbfHWI)
    fp.close()
   except:
    EtajdVcNGXQBqsOkSFAlpPDirbfHze
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYR): 
  try:
   if EtajdVcNGXQBqsOkSFAlpPDirbfHYR=='search':
    EtajdVcNGXQBqsOkSFAlpPDirbfHWu=EtajdVcNGXQBqsOkSFAlpPDirbfHLU
   elif EtajdVcNGXQBqsOkSFAlpPDirbfHYR in['vod','movie']:
    EtajdVcNGXQBqsOkSFAlpPDirbfHWu=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EtajdVcNGXQBqsOkSFAlpPDirbfHYR))
   else:
    return[]
   fp=EtajdVcNGXQBqsOkSFAlpPDirbfHwx(EtajdVcNGXQBqsOkSFAlpPDirbfHWu,'r',-1,'utf-8')
   EtajdVcNGXQBqsOkSFAlpPDirbfHWn=fp.readlines()
   fp.close()
  except:
   EtajdVcNGXQBqsOkSFAlpPDirbfHWn=[]
  return EtajdVcNGXQBqsOkSFAlpPDirbfHWn
 def Save_Watched_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYR,EtajdVcNGXQBqsOkSFAlpPDirbfHLR):
  try:
   EtajdVcNGXQBqsOkSFAlpPDirbfHWm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%EtajdVcNGXQBqsOkSFAlpPDirbfHYR))
   EtajdVcNGXQBqsOkSFAlpPDirbfHWR=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.Load_List_File(EtajdVcNGXQBqsOkSFAlpPDirbfHYR) 
   fp=EtajdVcNGXQBqsOkSFAlpPDirbfHwx(EtajdVcNGXQBqsOkSFAlpPDirbfHWm,'w',-1,'utf-8')
   EtajdVcNGXQBqsOkSFAlpPDirbfHWe=urllib.parse.urlencode(EtajdVcNGXQBqsOkSFAlpPDirbfHLR)
   EtajdVcNGXQBqsOkSFAlpPDirbfHWe=EtajdVcNGXQBqsOkSFAlpPDirbfHWe+'\n'
   fp.write(EtajdVcNGXQBqsOkSFAlpPDirbfHWe)
   EtajdVcNGXQBqsOkSFAlpPDirbfHWv=0
   for EtajdVcNGXQBqsOkSFAlpPDirbfHWI in EtajdVcNGXQBqsOkSFAlpPDirbfHWR:
    EtajdVcNGXQBqsOkSFAlpPDirbfHWy=EtajdVcNGXQBqsOkSFAlpPDirbfHwM(urllib.parse.parse_qsl(EtajdVcNGXQBqsOkSFAlpPDirbfHWI))
    EtajdVcNGXQBqsOkSFAlpPDirbfHgL=EtajdVcNGXQBqsOkSFAlpPDirbfHLR.get('code').strip()
    EtajdVcNGXQBqsOkSFAlpPDirbfHgT=EtajdVcNGXQBqsOkSFAlpPDirbfHWy.get('code').strip()
    if EtajdVcNGXQBqsOkSFAlpPDirbfHYR=='vod' and EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_direct_replay()==EtajdVcNGXQBqsOkSFAlpPDirbfHwL:
     EtajdVcNGXQBqsOkSFAlpPDirbfHgL=EtajdVcNGXQBqsOkSFAlpPDirbfHLR.get('videoid').strip()
     EtajdVcNGXQBqsOkSFAlpPDirbfHgT=EtajdVcNGXQBqsOkSFAlpPDirbfHWy.get('videoid').strip()if EtajdVcNGXQBqsOkSFAlpPDirbfHgT!=EtajdVcNGXQBqsOkSFAlpPDirbfHze else '-'
    if EtajdVcNGXQBqsOkSFAlpPDirbfHgL!=EtajdVcNGXQBqsOkSFAlpPDirbfHgT:
     fp.write(EtajdVcNGXQBqsOkSFAlpPDirbfHWI)
     EtajdVcNGXQBqsOkSFAlpPDirbfHWv+=1
     if EtajdVcNGXQBqsOkSFAlpPDirbfHWv>=50:break
   fp.close()
  except:
   EtajdVcNGXQBqsOkSFAlpPDirbfHze
 def dp_Watch_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHYR =EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('stype')
  EtajdVcNGXQBqsOkSFAlpPDirbfHTU=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_direct_replay()
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYR=='-':
   for EtajdVcNGXQBqsOkSFAlpPDirbfHYy in EtajdVcNGXQBqsOkSFAlpPDirbfHLo:
    EtajdVcNGXQBqsOkSFAlpPDirbfHTR=EtajdVcNGXQBqsOkSFAlpPDirbfHYy.get('title')
    EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':EtajdVcNGXQBqsOkSFAlpPDirbfHYy.get('mode'),'stype':EtajdVcNGXQBqsOkSFAlpPDirbfHYy.get('stype')}
    EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel='',img='',infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHze,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwL,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
   if EtajdVcNGXQBqsOkSFAlpPDirbfHwg(EtajdVcNGXQBqsOkSFAlpPDirbfHLo)>0:xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle)
  else:
   EtajdVcNGXQBqsOkSFAlpPDirbfHgY=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.Load_List_File(EtajdVcNGXQBqsOkSFAlpPDirbfHYR)
   for EtajdVcNGXQBqsOkSFAlpPDirbfHgM in EtajdVcNGXQBqsOkSFAlpPDirbfHgY:
    EtajdVcNGXQBqsOkSFAlpPDirbfHWo=EtajdVcNGXQBqsOkSFAlpPDirbfHwM(urllib.parse.parse_qsl(EtajdVcNGXQBqsOkSFAlpPDirbfHgM))
    EtajdVcNGXQBqsOkSFAlpPDirbfHgo =EtajdVcNGXQBqsOkSFAlpPDirbfHWo.get('code').strip()
    EtajdVcNGXQBqsOkSFAlpPDirbfHTR =EtajdVcNGXQBqsOkSFAlpPDirbfHWo.get('title').strip()
    EtajdVcNGXQBqsOkSFAlpPDirbfHML=EtajdVcNGXQBqsOkSFAlpPDirbfHWo.get('img').strip()
    EtajdVcNGXQBqsOkSFAlpPDirbfHou =EtajdVcNGXQBqsOkSFAlpPDirbfHWo.get('videoid').strip()
    try:
     EtajdVcNGXQBqsOkSFAlpPDirbfHML=EtajdVcNGXQBqsOkSFAlpPDirbfHML.replace('\'','\"')
     EtajdVcNGXQBqsOkSFAlpPDirbfHML=json.loads(EtajdVcNGXQBqsOkSFAlpPDirbfHML)
    except:
     EtajdVcNGXQBqsOkSFAlpPDirbfHze
    EtajdVcNGXQBqsOkSFAlpPDirbfHMx={}
    EtajdVcNGXQBqsOkSFAlpPDirbfHMx['plot']=EtajdVcNGXQBqsOkSFAlpPDirbfHTR
    if EtajdVcNGXQBqsOkSFAlpPDirbfHYR=='vod':
     if EtajdVcNGXQBqsOkSFAlpPDirbfHTU==EtajdVcNGXQBqsOkSFAlpPDirbfHwT or EtajdVcNGXQBqsOkSFAlpPDirbfHou==EtajdVcNGXQBqsOkSFAlpPDirbfHze:
      EtajdVcNGXQBqsOkSFAlpPDirbfHMx['mediatype']='tvshow'
      EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'EPISODE','programcode':EtajdVcNGXQBqsOkSFAlpPDirbfHgo,'page':'1'}
      EtajdVcNGXQBqsOkSFAlpPDirbfHYM=EtajdVcNGXQBqsOkSFAlpPDirbfHwL
     else:
      EtajdVcNGXQBqsOkSFAlpPDirbfHMx['mediatype']='episode'
      EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'VOD','mediacode':EtajdVcNGXQBqsOkSFAlpPDirbfHou,'stype':'vod','programcode':EtajdVcNGXQBqsOkSFAlpPDirbfHgo,'title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'thumbnail':EtajdVcNGXQBqsOkSFAlpPDirbfHML}
      EtajdVcNGXQBqsOkSFAlpPDirbfHYM=EtajdVcNGXQBqsOkSFAlpPDirbfHwT
    else:
     EtajdVcNGXQBqsOkSFAlpPDirbfHMx['mediatype']='movie'
     EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'MOVIE','mediacode':EtajdVcNGXQBqsOkSFAlpPDirbfHgo,'stype':'movie','title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'thumbnail':EtajdVcNGXQBqsOkSFAlpPDirbfHML}
     EtajdVcNGXQBqsOkSFAlpPDirbfHYM=EtajdVcNGXQBqsOkSFAlpPDirbfHwT
    EtajdVcNGXQBqsOkSFAlpPDirbfHWz={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':EtajdVcNGXQBqsOkSFAlpPDirbfHgo,'vType':EtajdVcNGXQBqsOkSFAlpPDirbfHYR,}
    EtajdVcNGXQBqsOkSFAlpPDirbfHWw=urllib.parse.urlencode(EtajdVcNGXQBqsOkSFAlpPDirbfHWz)
    EtajdVcNGXQBqsOkSFAlpPDirbfHMm=[('선택된 시청이력 ( %s ) 삭제'%(EtajdVcNGXQBqsOkSFAlpPDirbfHTR),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(EtajdVcNGXQBqsOkSFAlpPDirbfHWw))]
    EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel='',img=EtajdVcNGXQBqsOkSFAlpPDirbfHML,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHMx,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHYM,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT,ContextMenu=EtajdVcNGXQBqsOkSFAlpPDirbfHMm)
   EtajdVcNGXQBqsOkSFAlpPDirbfHMx={'plot':'시청목록을 삭제합니다.'}
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':EtajdVcNGXQBqsOkSFAlpPDirbfHYR,}
   EtajdVcNGXQBqsOkSFAlpPDirbfHYL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel='',img=EtajdVcNGXQBqsOkSFAlpPDirbfHYL,infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHMx,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwT,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT,isLink=EtajdVcNGXQBqsOkSFAlpPDirbfHwL)
   if EtajdVcNGXQBqsOkSFAlpPDirbfHYR=='movie':xbmcplugin.setContent(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,'movies')
   else:xbmcplugin.setContent(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,cacheToDisc=EtajdVcNGXQBqsOkSFAlpPDirbfHwT)
 def Save_Searched_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHom):
  try:
   EtajdVcNGXQBqsOkSFAlpPDirbfHgW=EtajdVcNGXQBqsOkSFAlpPDirbfHLU
   EtajdVcNGXQBqsOkSFAlpPDirbfHWR=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.Load_List_File('search') 
   EtajdVcNGXQBqsOkSFAlpPDirbfHgz={'skey':EtajdVcNGXQBqsOkSFAlpPDirbfHom.strip()}
   fp=EtajdVcNGXQBqsOkSFAlpPDirbfHwx(EtajdVcNGXQBqsOkSFAlpPDirbfHgW,'w',-1,'utf-8')
   EtajdVcNGXQBqsOkSFAlpPDirbfHWe=urllib.parse.urlencode(EtajdVcNGXQBqsOkSFAlpPDirbfHgz)
   EtajdVcNGXQBqsOkSFAlpPDirbfHWe=EtajdVcNGXQBqsOkSFAlpPDirbfHWe+'\n'
   fp.write(EtajdVcNGXQBqsOkSFAlpPDirbfHWe)
   EtajdVcNGXQBqsOkSFAlpPDirbfHWv=0
   for EtajdVcNGXQBqsOkSFAlpPDirbfHWI in EtajdVcNGXQBqsOkSFAlpPDirbfHWR:
    EtajdVcNGXQBqsOkSFAlpPDirbfHWy=EtajdVcNGXQBqsOkSFAlpPDirbfHwM(urllib.parse.parse_qsl(EtajdVcNGXQBqsOkSFAlpPDirbfHWI))
    EtajdVcNGXQBqsOkSFAlpPDirbfHgL=EtajdVcNGXQBqsOkSFAlpPDirbfHgz.get('skey').strip()
    EtajdVcNGXQBqsOkSFAlpPDirbfHgT=EtajdVcNGXQBqsOkSFAlpPDirbfHWy.get('skey').strip()
    if EtajdVcNGXQBqsOkSFAlpPDirbfHgL!=EtajdVcNGXQBqsOkSFAlpPDirbfHgT:
     fp.write(EtajdVcNGXQBqsOkSFAlpPDirbfHWI)
     EtajdVcNGXQBqsOkSFAlpPDirbfHWv+=1
     if EtajdVcNGXQBqsOkSFAlpPDirbfHWv>=50:break
   fp.close()
  except:
   EtajdVcNGXQBqsOkSFAlpPDirbfHze
 def play_VIDEO(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHgw =EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('mediacode')
  EtajdVcNGXQBqsOkSFAlpPDirbfHYR =EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('stype')
  EtajdVcNGXQBqsOkSFAlpPDirbfHgK =EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('pvrmode')
  EtajdVcNGXQBqsOkSFAlpPDirbfHgx=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_selQuality(EtajdVcNGXQBqsOkSFAlpPDirbfHYR)
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(EtajdVcNGXQBqsOkSFAlpPDirbfHgw,EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHgx),EtajdVcNGXQBqsOkSFAlpPDirbfHYR,EtajdVcNGXQBqsOkSFAlpPDirbfHgK))
  EtajdVcNGXQBqsOkSFAlpPDirbfHgU=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.GetBroadURL(EtajdVcNGXQBqsOkSFAlpPDirbfHgw,EtajdVcNGXQBqsOkSFAlpPDirbfHgx,EtajdVcNGXQBqsOkSFAlpPDirbfHYR,EtajdVcNGXQBqsOkSFAlpPDirbfHgK,optUHD=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_uhd())
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.addon_log('qt, stype, url : %s - %s - %s'%(EtajdVcNGXQBqsOkSFAlpPDirbfHwz(EtajdVcNGXQBqsOkSFAlpPDirbfHgx),EtajdVcNGXQBqsOkSFAlpPDirbfHYR,EtajdVcNGXQBqsOkSFAlpPDirbfHgU['streaming_url']))
  if EtajdVcNGXQBqsOkSFAlpPDirbfHgU['streaming_url']=='':
   if EtajdVcNGXQBqsOkSFAlpPDirbfHgU['error_msg']=='':
    EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.addon_noti(__language__(30908).encode('utf8'))
   else:
    EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.addon_noti(EtajdVcNGXQBqsOkSFAlpPDirbfHgU['error_msg'].encode('utf8'))
   return
  EtajdVcNGXQBqsOkSFAlpPDirbfHgJ={'user-agent':EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.USER_AGENT}
  EtajdVcNGXQBqsOkSFAlpPDirbfHgC=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.makeDefaultCookies() 
  if EtajdVcNGXQBqsOkSFAlpPDirbfHgU['drm_server_url'] !='':
   EtajdVcNGXQBqsOkSFAlpPDirbfHgJ[EtajdVcNGXQBqsOkSFAlpPDirbfHgU['drm_header_key']]=EtajdVcNGXQBqsOkSFAlpPDirbfHgU['drm_header_value']
  EtajdVcNGXQBqsOkSFAlpPDirbfHgu =EtajdVcNGXQBqsOkSFAlpPDirbfHwT
  EtajdVcNGXQBqsOkSFAlpPDirbfHgR =EtajdVcNGXQBqsOkSFAlpPDirbfHgU['streaming_url'].find('Policy=')
  if EtajdVcNGXQBqsOkSFAlpPDirbfHgR!=-1:
   EtajdVcNGXQBqsOkSFAlpPDirbfHgI =EtajdVcNGXQBqsOkSFAlpPDirbfHgU['streaming_url'].split('?')[0]
   EtajdVcNGXQBqsOkSFAlpPDirbfHgy=EtajdVcNGXQBqsOkSFAlpPDirbfHwM(urllib.parse.parse_qsl(urllib.parse.urlsplit(EtajdVcNGXQBqsOkSFAlpPDirbfHgU['streaming_url']).query))
   EtajdVcNGXQBqsOkSFAlpPDirbfHgC['CloudFront-Policy'] =EtajdVcNGXQBqsOkSFAlpPDirbfHgy['Policy'] 
   EtajdVcNGXQBqsOkSFAlpPDirbfHgC['CloudFront-Signature'] =EtajdVcNGXQBqsOkSFAlpPDirbfHgy['Signature'] 
   EtajdVcNGXQBqsOkSFAlpPDirbfHgC['CloudFront-Key-Pair-Id']=EtajdVcNGXQBqsOkSFAlpPDirbfHgy['Key-Pair-Id'] 
   EtajdVcNGXQBqsOkSFAlpPDirbfHgh=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.make_stream_header(EtajdVcNGXQBqsOkSFAlpPDirbfHgJ,EtajdVcNGXQBqsOkSFAlpPDirbfHgC)
   if 'quickvod-mcdn.tving.com' in EtajdVcNGXQBqsOkSFAlpPDirbfHgI:
    EtajdVcNGXQBqsOkSFAlpPDirbfHgu=EtajdVcNGXQBqsOkSFAlpPDirbfHwL
    EtajdVcNGXQBqsOkSFAlpPDirbfHgn =EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    EtajdVcNGXQBqsOkSFAlpPDirbfHgm=EtajdVcNGXQBqsOkSFAlpPDirbfHgn.strftime('%Y-%m-%d-%H:%M:%S')
    if EtajdVcNGXQBqsOkSFAlpPDirbfHzv(EtajdVcNGXQBqsOkSFAlpPDirbfHgm.replace('-','').replace(':',''))<EtajdVcNGXQBqsOkSFAlpPDirbfHzv(EtajdVcNGXQBqsOkSFAlpPDirbfHgy['end'].replace('-','').replace(':','')):
     EtajdVcNGXQBqsOkSFAlpPDirbfHgy['end']=EtajdVcNGXQBqsOkSFAlpPDirbfHgm
     EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.addon_noti(__language__(30915).encode('utf8'))
    EtajdVcNGXQBqsOkSFAlpPDirbfHgI ='%s?%s'%(EtajdVcNGXQBqsOkSFAlpPDirbfHgI,urllib.parse.urlencode(EtajdVcNGXQBqsOkSFAlpPDirbfHgy,doseq=EtajdVcNGXQBqsOkSFAlpPDirbfHwL))
    EtajdVcNGXQBqsOkSFAlpPDirbfHge='{}|{}'.format(EtajdVcNGXQBqsOkSFAlpPDirbfHgI,EtajdVcNGXQBqsOkSFAlpPDirbfHgh)
   else:
    EtajdVcNGXQBqsOkSFAlpPDirbfHge='{}|{}'.format(EtajdVcNGXQBqsOkSFAlpPDirbfHgU['streaming_url'],EtajdVcNGXQBqsOkSFAlpPDirbfHgh)
  else:
   EtajdVcNGXQBqsOkSFAlpPDirbfHgh=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.make_stream_header(EtajdVcNGXQBqsOkSFAlpPDirbfHgJ,EtajdVcNGXQBqsOkSFAlpPDirbfHgC)
   EtajdVcNGXQBqsOkSFAlpPDirbfHge='{}|{}'.format(EtajdVcNGXQBqsOkSFAlpPDirbfHgU['streaming_url'],EtajdVcNGXQBqsOkSFAlpPDirbfHgh)
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.addon_log('if tmp_pos == -1')
  EtajdVcNGXQBqsOkSFAlpPDirbfHTo,EtajdVcNGXQBqsOkSFAlpPDirbfHTW=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_proxyport()
  EtajdVcNGXQBqsOkSFAlpPDirbfHTM=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_playback()
  if(EtajdVcNGXQBqsOkSFAlpPDirbfHTo and EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('mode')in['VOD','MOVIE']and EtajdVcNGXQBqsOkSFAlpPDirbfHgu==EtajdVcNGXQBqsOkSFAlpPDirbfHwT and(EtajdVcNGXQBqsOkSFAlpPDirbfHgU['drm_server_url']!='' or EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.KodiVersion>=21)):
   if EtajdVcNGXQBqsOkSFAlpPDirbfHgU['url_filename'].split('.')[1]=='mpd':
    EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Tving_Parse_mpd(EtajdVcNGXQBqsOkSFAlpPDirbfHgU['streaming_url'])
   else:
    EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Tving_Parse_m3u8(EtajdVcNGXQBqsOkSFAlpPDirbfHgU['streaming_url'])
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.addon_log('xxx '+EtajdVcNGXQBqsOkSFAlpPDirbfHgU['streaming_url'])
   EtajdVcNGXQBqsOkSFAlpPDirbfHgv={'addon':'tvingm','playOption':EtajdVcNGXQBqsOkSFAlpPDirbfHTM,'url_filename':EtajdVcNGXQBqsOkSFAlpPDirbfHgU['url_filename'],}
   EtajdVcNGXQBqsOkSFAlpPDirbfHgv=json.dumps(EtajdVcNGXQBqsOkSFAlpPDirbfHgv,separators=(',',':'))
   EtajdVcNGXQBqsOkSFAlpPDirbfHgv=base64.standard_b64encode(EtajdVcNGXQBqsOkSFAlpPDirbfHgv.encode()).decode('utf-8')
   EtajdVcNGXQBqsOkSFAlpPDirbfHge ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(EtajdVcNGXQBqsOkSFAlpPDirbfHTW,EtajdVcNGXQBqsOkSFAlpPDirbfHge,EtajdVcNGXQBqsOkSFAlpPDirbfHgv)
   EtajdVcNGXQBqsOkSFAlpPDirbfHgJ['proxy-mini']=EtajdVcNGXQBqsOkSFAlpPDirbfHgv 
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.addon_log('surl(2) : {}'.format(EtajdVcNGXQBqsOkSFAlpPDirbfHge))
  EtajdVcNGXQBqsOkSFAlpPDirbfHgh=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.make_stream_header(EtajdVcNGXQBqsOkSFAlpPDirbfHgJ,EtajdVcNGXQBqsOkSFAlpPDirbfHgC)
  EtajdVcNGXQBqsOkSFAlpPDirbfHzL=xbmcgui.ListItem(path=EtajdVcNGXQBqsOkSFAlpPDirbfHge)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHgU['drm_server_url']!='':
   EtajdVcNGXQBqsOkSFAlpPDirbfHzT=EtajdVcNGXQBqsOkSFAlpPDirbfHgU['drm_server_url']
   EtajdVcNGXQBqsOkSFAlpPDirbfHzY ='https://license-global.pallycon.com/ri/licenseManager.do' 
   EtajdVcNGXQBqsOkSFAlpPDirbfHzM ='mpd'
   EtajdVcNGXQBqsOkSFAlpPDirbfHzo ='com.widevine.alpha'
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   EtajdVcNGXQBqsOkSFAlpPDirbfHzg={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.USER_AGENT,EtajdVcNGXQBqsOkSFAlpPDirbfHgU['drm_header_key']:EtajdVcNGXQBqsOkSFAlpPDirbfHgU['drm_header_value'],}
   EtajdVcNGXQBqsOkSFAlpPDirbfHzw=EtajdVcNGXQBqsOkSFAlpPDirbfHzY+'|'+urllib.parse.urlencode(EtajdVcNGXQBqsOkSFAlpPDirbfHzg)+'|R{SSM}|'
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream','inputstream.adaptive')
   if EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.KodiVersion<=20:
    EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream.adaptive.manifest_type',EtajdVcNGXQBqsOkSFAlpPDirbfHzM)
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream.adaptive.license_type',EtajdVcNGXQBqsOkSFAlpPDirbfHzo)
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream.adaptive.license_key',EtajdVcNGXQBqsOkSFAlpPDirbfHzw)
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream.adaptive.stream_headers',EtajdVcNGXQBqsOkSFAlpPDirbfHgh)
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream.adaptive.manifest_headers',EtajdVcNGXQBqsOkSFAlpPDirbfHgh)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('mode')in['VOD','MOVIE']:
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setContentLookup(EtajdVcNGXQBqsOkSFAlpPDirbfHwT)
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setMimeType('application/x-mpegURL')
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream','inputstream.adaptive')
   if EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.KodiVersion<=20:
    EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream.adaptive.manifest_type','hls')
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream.adaptive.stream_headers',EtajdVcNGXQBqsOkSFAlpPDirbfHgh)
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream.adaptive.manifest_headers',EtajdVcNGXQBqsOkSFAlpPDirbfHgh)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHgu==EtajdVcNGXQBqsOkSFAlpPDirbfHwL:
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setContentLookup(EtajdVcNGXQBqsOkSFAlpPDirbfHwT)
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setMimeType('application/x-mpegURL')
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream','inputstream.ffmpegdirect')
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('ResumeTime','0')
   EtajdVcNGXQBqsOkSFAlpPDirbfHzL.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,EtajdVcNGXQBqsOkSFAlpPDirbfHwL,EtajdVcNGXQBqsOkSFAlpPDirbfHzL)
  try:
   if EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('mode')in['VOD','MOVIE']and EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('title'):
    EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'code':EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('programcode')if EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('mode')=='VOD' else EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('mediacode'),'img':EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('thumbnail'),'title':EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('title'),'videoid':EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('mediacode')}
    EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.Save_Watched_List(EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('stype'),EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  except:
   EtajdVcNGXQBqsOkSFAlpPDirbfHze
 def logout(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  EtajdVcNGXQBqsOkSFAlpPDirbfHLy=xbmcgui.Dialog()
  EtajdVcNGXQBqsOkSFAlpPDirbfHYU=EtajdVcNGXQBqsOkSFAlpPDirbfHLy.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if EtajdVcNGXQBqsOkSFAlpPDirbfHYU==EtajdVcNGXQBqsOkSFAlpPDirbfHwT:sys.exit()
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Init_TV_Total()
  if os.path.isfile(EtajdVcNGXQBqsOkSFAlpPDirbfHLx):os.remove(EtajdVcNGXQBqsOkSFAlpPDirbfHLx)
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  EtajdVcNGXQBqsOkSFAlpPDirbfHzK =EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Get_Now_Datetime()
  EtajdVcNGXQBqsOkSFAlpPDirbfHzx=EtajdVcNGXQBqsOkSFAlpPDirbfHzK+datetime.timedelta(days=30) 
  (EtajdVcNGXQBqsOkSFAlpPDirbfHYz,EtajdVcNGXQBqsOkSFAlpPDirbfHYw,EtajdVcNGXQBqsOkSFAlpPDirbfHYK,EtajdVcNGXQBqsOkSFAlpPDirbfHYx)=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_account()
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Save_session_acount(EtajdVcNGXQBqsOkSFAlpPDirbfHYz,EtajdVcNGXQBqsOkSFAlpPDirbfHYw,EtajdVcNGXQBqsOkSFAlpPDirbfHYK,EtajdVcNGXQBqsOkSFAlpPDirbfHYx)
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.TV['account']['token_limit']=EtajdVcNGXQBqsOkSFAlpPDirbfHzx.strftime('%Y%m%d')
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.JsonFile_Save(EtajdVcNGXQBqsOkSFAlpPDirbfHLx,EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.TV)
 def cookiefile_check(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.TV=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.JsonFile_Load(EtajdVcNGXQBqsOkSFAlpPDirbfHLx)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.TV=={}:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Init_TV_Total()
   return EtajdVcNGXQBqsOkSFAlpPDirbfHwT
  (EtajdVcNGXQBqsOkSFAlpPDirbfHzU,EtajdVcNGXQBqsOkSFAlpPDirbfHzJ,EtajdVcNGXQBqsOkSFAlpPDirbfHzC,EtajdVcNGXQBqsOkSFAlpPDirbfHzu)=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.get_settings_account()
  (EtajdVcNGXQBqsOkSFAlpPDirbfHzR,EtajdVcNGXQBqsOkSFAlpPDirbfHzI,EtajdVcNGXQBqsOkSFAlpPDirbfHzy,EtajdVcNGXQBqsOkSFAlpPDirbfHzh)=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Load_session_acount()
  if(EtajdVcNGXQBqsOkSFAlpPDirbfHzU!=EtajdVcNGXQBqsOkSFAlpPDirbfHzR or EtajdVcNGXQBqsOkSFAlpPDirbfHzJ!=EtajdVcNGXQBqsOkSFAlpPDirbfHzI or EtajdVcNGXQBqsOkSFAlpPDirbfHzC!=EtajdVcNGXQBqsOkSFAlpPDirbfHzy or EtajdVcNGXQBqsOkSFAlpPDirbfHzu!=EtajdVcNGXQBqsOkSFAlpPDirbfHzh)and EtajdVcNGXQBqsOkSFAlpPDirbfHzR!='xxxxx':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Init_TV_Total()
   return EtajdVcNGXQBqsOkSFAlpPDirbfHwT
  if EtajdVcNGXQBqsOkSFAlpPDirbfHzv(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>EtajdVcNGXQBqsOkSFAlpPDirbfHzv(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.TV['account']['token_limit']):
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.Init_TV_Total()
   return EtajdVcNGXQBqsOkSFAlpPDirbfHwT
  return EtajdVcNGXQBqsOkSFAlpPDirbfHwL
 def dp_Global_Search(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHoe=EtajdVcNGXQBqsOkSFAlpPDirbfHYh.get('mode')
  if EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='TOTAL_SEARCH':
   EtajdVcNGXQBqsOkSFAlpPDirbfHzn='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   EtajdVcNGXQBqsOkSFAlpPDirbfHzn='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(EtajdVcNGXQBqsOkSFAlpPDirbfHzn)
 def dp_Bookmark_Menu(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHzn='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(EtajdVcNGXQBqsOkSFAlpPDirbfHzn)
 def dp_EuroLive_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ,EtajdVcNGXQBqsOkSFAlpPDirbfHYh):
  EtajdVcNGXQBqsOkSFAlpPDirbfHYm=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.GetEuroChannelList()
  for EtajdVcNGXQBqsOkSFAlpPDirbfHYv in EtajdVcNGXQBqsOkSFAlpPDirbfHYm:
   EtajdVcNGXQBqsOkSFAlpPDirbfHMI =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('channel')
   EtajdVcNGXQBqsOkSFAlpPDirbfHTR =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('title')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMU =EtajdVcNGXQBqsOkSFAlpPDirbfHYv.get('subtitle')
   EtajdVcNGXQBqsOkSFAlpPDirbfHMx={'mediatype':'episode','title':EtajdVcNGXQBqsOkSFAlpPDirbfHTR,'plot':'%s\n%s'%(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,EtajdVcNGXQBqsOkSFAlpPDirbfHMU)}
   EtajdVcNGXQBqsOkSFAlpPDirbfHYT={'mode':'LIVE','mediacode':EtajdVcNGXQBqsOkSFAlpPDirbfHMI,'stype':'onair',}
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.add_dir(EtajdVcNGXQBqsOkSFAlpPDirbfHTR,sublabel=EtajdVcNGXQBqsOkSFAlpPDirbfHMU,img='',infoLabels=EtajdVcNGXQBqsOkSFAlpPDirbfHMx,isFolder=EtajdVcNGXQBqsOkSFAlpPDirbfHwT,params=EtajdVcNGXQBqsOkSFAlpPDirbfHYT)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHwg(EtajdVcNGXQBqsOkSFAlpPDirbfHYm)>0:xbmcplugin.endOfDirectory(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ._addon_handle,cacheToDisc=EtajdVcNGXQBqsOkSFAlpPDirbfHwT)
 def tving_main(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ):
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.TvingObj.KodiVersion=EtajdVcNGXQBqsOkSFAlpPDirbfHzv(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  EtajdVcNGXQBqsOkSFAlpPDirbfHoe=EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params.get('mode',EtajdVcNGXQBqsOkSFAlpPDirbfHze)
  if EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='LOGOUT':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.logout()
   return
  EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.login_main()
  if EtajdVcNGXQBqsOkSFAlpPDirbfHoe is EtajdVcNGXQBqsOkSFAlpPDirbfHze:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_Main_List()
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_Title_Group(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe in['GLOBAL_GROUP']:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_SubTitle_Group(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='CHANNEL':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_LiveChannel_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe in['LIVE','VOD','MOVIE']:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.play_VIDEO(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='PROGRAM':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_Program_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='4K_PROGRAM':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_4K_Program_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='ORI_PROGRAM':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_Ori_Program_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='EPISODE':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_Episode_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='MOVIE_SUB':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_Movie_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='4K_MOVIE':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_4K_Movie_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='SEARCH_GROUP':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_Search_Group(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe in['SEARCH','LOCAL_SEARCH']:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_Search_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='WATCH':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_Watch_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_History_Remove(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='ORDER_BY':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_setEpOrderby(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='SET_BOOKMARK':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_Set_Bookmark(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe in['TOTAL_SEARCH','TOTAL_HISTORY']:
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_Global_Search(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='SEARCH_HISTORY':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_Search_History(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='MENU_BOOKMARK':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_Bookmark_Menu(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  elif EtajdVcNGXQBqsOkSFAlpPDirbfHoe=='EURO_GROUP':
   EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.dp_EuroLive_List(EtajdVcNGXQBqsOkSFAlpPDirbfHLJ.main_params)
  else:
   EtajdVcNGXQBqsOkSFAlpPDirbfHze
# Created by pyminifier (https://github.com/liftoff/pyminifier)
