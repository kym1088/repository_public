__author__="NightRain"
YngQWasBwxyUTJlIKvNVLMezXbmSEc=object
YngQWasBwxyUTJlIKvNVLMezXbmSEq=None
YngQWasBwxyUTJlIKvNVLMezXbmSEA=int
YngQWasBwxyUTJlIKvNVLMezXbmSEp=True
YngQWasBwxyUTJlIKvNVLMezXbmSEH=False
YngQWasBwxyUTJlIKvNVLMezXbmSEk=type
YngQWasBwxyUTJlIKvNVLMezXbmSEj=dict
YngQWasBwxyUTJlIKvNVLMezXbmSEt=len
YngQWasBwxyUTJlIKvNVLMezXbmSEu=str
YngQWasBwxyUTJlIKvNVLMezXbmSER=range
YngQWasBwxyUTJlIKvNVLMezXbmSEG=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
YngQWasBwxyUTJlIKvNVLMezXbmSoi=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
YngQWasBwxyUTJlIKvNVLMezXbmSoD=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
YngQWasBwxyUTJlIKvNVLMezXbmSor=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
YngQWasBwxyUTJlIKvNVLMezXbmSoh=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
YngQWasBwxyUTJlIKvNVLMezXbmSof=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
YngQWasBwxyUTJlIKvNVLMezXbmSoE=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
YngQWasBwxyUTJlIKvNVLMezXbmSoO=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
YngQWasBwxyUTJlIKvNVLMezXbmSoc =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
YngQWasBwxyUTJlIKvNVLMezXbmSoq=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class YngQWasBwxyUTJlIKvNVLMezXbmSoP(YngQWasBwxyUTJlIKvNVLMezXbmSEc):
 def __init__(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSop,YngQWasBwxyUTJlIKvNVLMezXbmSoH,YngQWasBwxyUTJlIKvNVLMezXbmSok):
  YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_url =YngQWasBwxyUTJlIKvNVLMezXbmSop
  YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle=YngQWasBwxyUTJlIKvNVLMezXbmSoH
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params =YngQWasBwxyUTJlIKvNVLMezXbmSok
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj =elgFhPaAOJiLKuGEYxQcCpNfIVnRwv() 
 def addon_noti(YngQWasBwxyUTJlIKvNVLMezXbmSoA,sting):
  try:
   YngQWasBwxyUTJlIKvNVLMezXbmSot=xbmcgui.Dialog()
   YngQWasBwxyUTJlIKvNVLMezXbmSot.notification(__addonname__,sting)
  except:
   YngQWasBwxyUTJlIKvNVLMezXbmSEq
 def addon_log(YngQWasBwxyUTJlIKvNVLMezXbmSoA,string):
  try:
   YngQWasBwxyUTJlIKvNVLMezXbmSou=string.encode('utf-8','ignore')
  except:
   YngQWasBwxyUTJlIKvNVLMezXbmSou='addonException: addon_log'
  YngQWasBwxyUTJlIKvNVLMezXbmSoR=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,YngQWasBwxyUTJlIKvNVLMezXbmSou),level=YngQWasBwxyUTJlIKvNVLMezXbmSoR)
 def get_keyboard_input(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSPA):
  YngQWasBwxyUTJlIKvNVLMezXbmSoG=YngQWasBwxyUTJlIKvNVLMezXbmSEq
  kb=xbmc.Keyboard()
  kb.setHeading(YngQWasBwxyUTJlIKvNVLMezXbmSPA)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   YngQWasBwxyUTJlIKvNVLMezXbmSoG=kb.getText()
  return YngQWasBwxyUTJlIKvNVLMezXbmSoG
 def get_settings_account(YngQWasBwxyUTJlIKvNVLMezXbmSoA):
  YngQWasBwxyUTJlIKvNVLMezXbmSoF =__addon__.getSetting('id')
  YngQWasBwxyUTJlIKvNVLMezXbmSod =__addon__.getSetting('pw')
  YngQWasBwxyUTJlIKvNVLMezXbmSoC =__addon__.getSetting('login_type')
  YngQWasBwxyUTJlIKvNVLMezXbmSPo=YngQWasBwxyUTJlIKvNVLMezXbmSEA(__addon__.getSetting('selected_profile'))
  return(YngQWasBwxyUTJlIKvNVLMezXbmSoF,YngQWasBwxyUTJlIKvNVLMezXbmSod,YngQWasBwxyUTJlIKvNVLMezXbmSoC,YngQWasBwxyUTJlIKvNVLMezXbmSPo)
 def get_settings_uhd(YngQWasBwxyUTJlIKvNVLMezXbmSoA):
  return YngQWasBwxyUTJlIKvNVLMezXbmSEp if __addon__.getSetting('active_uhd')=='true' else YngQWasBwxyUTJlIKvNVLMezXbmSEH
 def get_settings_totalsearch(YngQWasBwxyUTJlIKvNVLMezXbmSoA):
  YngQWasBwxyUTJlIKvNVLMezXbmSPi =YngQWasBwxyUTJlIKvNVLMezXbmSEp if __addon__.getSetting('local_search')=='true' else YngQWasBwxyUTJlIKvNVLMezXbmSEH
  YngQWasBwxyUTJlIKvNVLMezXbmSPD=YngQWasBwxyUTJlIKvNVLMezXbmSEp if __addon__.getSetting('local_history')=='true' else YngQWasBwxyUTJlIKvNVLMezXbmSEH
  YngQWasBwxyUTJlIKvNVLMezXbmSPr =YngQWasBwxyUTJlIKvNVLMezXbmSEp if __addon__.getSetting('total_search')=='true' else YngQWasBwxyUTJlIKvNVLMezXbmSEH
  YngQWasBwxyUTJlIKvNVLMezXbmSPh=YngQWasBwxyUTJlIKvNVLMezXbmSEp if __addon__.getSetting('total_history')=='true' else YngQWasBwxyUTJlIKvNVLMezXbmSEH
  YngQWasBwxyUTJlIKvNVLMezXbmSPf=YngQWasBwxyUTJlIKvNVLMezXbmSEp if __addon__.getSetting('menu_bookmark')=='true' else YngQWasBwxyUTJlIKvNVLMezXbmSEH
  return(YngQWasBwxyUTJlIKvNVLMezXbmSPi,YngQWasBwxyUTJlIKvNVLMezXbmSPD,YngQWasBwxyUTJlIKvNVLMezXbmSPr,YngQWasBwxyUTJlIKvNVLMezXbmSPh,YngQWasBwxyUTJlIKvNVLMezXbmSPf)
 def get_settings_makebookmark(YngQWasBwxyUTJlIKvNVLMezXbmSoA):
  return YngQWasBwxyUTJlIKvNVLMezXbmSEp if __addon__.getSetting('make_bookmark')=='true' else YngQWasBwxyUTJlIKvNVLMezXbmSEH
 def get_settings_direct_replay(YngQWasBwxyUTJlIKvNVLMezXbmSoA):
  YngQWasBwxyUTJlIKvNVLMezXbmSPE=YngQWasBwxyUTJlIKvNVLMezXbmSEA(__addon__.getSetting('direct_replay'))
  if YngQWasBwxyUTJlIKvNVLMezXbmSPE==0:
   return YngQWasBwxyUTJlIKvNVLMezXbmSEH
  else:
   return YngQWasBwxyUTJlIKvNVLMezXbmSEp
 def set_winEpisodeOrderby(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSPc):
  __addon__.setSetting('tving_orderby',YngQWasBwxyUTJlIKvNVLMezXbmSPc)
  YngQWasBwxyUTJlIKvNVLMezXbmSPO=xbmcgui.Window(10000)
  YngQWasBwxyUTJlIKvNVLMezXbmSPO.setProperty('TVING_M_ORDERBY',YngQWasBwxyUTJlIKvNVLMezXbmSPc)
 def get_winEpisodeOrderby(YngQWasBwxyUTJlIKvNVLMezXbmSoA):
  YngQWasBwxyUTJlIKvNVLMezXbmSPc=__addon__.getSetting('tving_orderby')
  if YngQWasBwxyUTJlIKvNVLMezXbmSPc in['',YngQWasBwxyUTJlIKvNVLMezXbmSEq]:YngQWasBwxyUTJlIKvNVLMezXbmSPc='desc'
  return YngQWasBwxyUTJlIKvNVLMezXbmSPc
 def add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSoA,label,sublabel='',img='',infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params='',isLink=YngQWasBwxyUTJlIKvNVLMezXbmSEH,ContextMenu=YngQWasBwxyUTJlIKvNVLMezXbmSEq):
  YngQWasBwxyUTJlIKvNVLMezXbmSPq='%s?%s'%(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_url,urllib.parse.urlencode(params))
  if sublabel:YngQWasBwxyUTJlIKvNVLMezXbmSPA='%s < %s >'%(label,sublabel)
  else: YngQWasBwxyUTJlIKvNVLMezXbmSPA=label
  if not img:img='DefaultFolder.png'
  YngQWasBwxyUTJlIKvNVLMezXbmSPp=xbmcgui.ListItem(YngQWasBwxyUTJlIKvNVLMezXbmSPA)
  if YngQWasBwxyUTJlIKvNVLMezXbmSEk(img)==YngQWasBwxyUTJlIKvNVLMezXbmSEj:
   YngQWasBwxyUTJlIKvNVLMezXbmSPp.setArt(img)
  else:
   YngQWasBwxyUTJlIKvNVLMezXbmSPp.setArt({'thumb':img,'poster':img})
  if infoLabels:YngQWasBwxyUTJlIKvNVLMezXbmSPp.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   YngQWasBwxyUTJlIKvNVLMezXbmSPp.setProperty('IsPlayable','true')
  if ContextMenu:YngQWasBwxyUTJlIKvNVLMezXbmSPp.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,YngQWasBwxyUTJlIKvNVLMezXbmSPq,YngQWasBwxyUTJlIKvNVLMezXbmSPp,isFolder)
 def get_selQuality(YngQWasBwxyUTJlIKvNVLMezXbmSoA,etype):
  try:
   YngQWasBwxyUTJlIKvNVLMezXbmSPH='selected_quality'
   YngQWasBwxyUTJlIKvNVLMezXbmSPk=[1080,720,480,360]
   YngQWasBwxyUTJlIKvNVLMezXbmSPj=YngQWasBwxyUTJlIKvNVLMezXbmSEA(__addon__.getSetting(YngQWasBwxyUTJlIKvNVLMezXbmSPH))
   return YngQWasBwxyUTJlIKvNVLMezXbmSPk[YngQWasBwxyUTJlIKvNVLMezXbmSPj]
  except:
   YngQWasBwxyUTJlIKvNVLMezXbmSEq
  return 720 
 def dp_Main_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA):
  (YngQWasBwxyUTJlIKvNVLMezXbmSPi,YngQWasBwxyUTJlIKvNVLMezXbmSPD,YngQWasBwxyUTJlIKvNVLMezXbmSPr,YngQWasBwxyUTJlIKvNVLMezXbmSPh,YngQWasBwxyUTJlIKvNVLMezXbmSPf)=YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_settings_totalsearch()
  for YngQWasBwxyUTJlIKvNVLMezXbmSPt in YngQWasBwxyUTJlIKvNVLMezXbmSoi:
   YngQWasBwxyUTJlIKvNVLMezXbmSPA=YngQWasBwxyUTJlIKvNVLMezXbmSPt.get('title')
   YngQWasBwxyUTJlIKvNVLMezXbmSPu=''
   if YngQWasBwxyUTJlIKvNVLMezXbmSPt.get('mode')=='SEARCH_GROUP' and YngQWasBwxyUTJlIKvNVLMezXbmSPi ==YngQWasBwxyUTJlIKvNVLMezXbmSEH:continue
   elif YngQWasBwxyUTJlIKvNVLMezXbmSPt.get('mode')=='SEARCH_HISTORY' and YngQWasBwxyUTJlIKvNVLMezXbmSPD==YngQWasBwxyUTJlIKvNVLMezXbmSEH:continue
   elif YngQWasBwxyUTJlIKvNVLMezXbmSPt.get('mode')=='TOTAL_SEARCH' and YngQWasBwxyUTJlIKvNVLMezXbmSPr ==YngQWasBwxyUTJlIKvNVLMezXbmSEH:continue
   elif YngQWasBwxyUTJlIKvNVLMezXbmSPt.get('mode')=='TOTAL_HISTORY' and YngQWasBwxyUTJlIKvNVLMezXbmSPh==YngQWasBwxyUTJlIKvNVLMezXbmSEH:continue
   elif YngQWasBwxyUTJlIKvNVLMezXbmSPt.get('mode')=='MENU_BOOKMARK' and YngQWasBwxyUTJlIKvNVLMezXbmSPf==YngQWasBwxyUTJlIKvNVLMezXbmSEH:continue
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':YngQWasBwxyUTJlIKvNVLMezXbmSPt.get('mode'),'stype':YngQWasBwxyUTJlIKvNVLMezXbmSPt.get('stype'),'orderby':YngQWasBwxyUTJlIKvNVLMezXbmSPt.get('orderby'),'ordernm':YngQWasBwxyUTJlIKvNVLMezXbmSPt.get('ordernm'),'page':'1'}
   if YngQWasBwxyUTJlIKvNVLMezXbmSPt.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    YngQWasBwxyUTJlIKvNVLMezXbmSPG=YngQWasBwxyUTJlIKvNVLMezXbmSEH
    YngQWasBwxyUTJlIKvNVLMezXbmSPF =YngQWasBwxyUTJlIKvNVLMezXbmSEp
   else:
    YngQWasBwxyUTJlIKvNVLMezXbmSPG=YngQWasBwxyUTJlIKvNVLMezXbmSEp
    YngQWasBwxyUTJlIKvNVLMezXbmSPF =YngQWasBwxyUTJlIKvNVLMezXbmSEH
   if 'icon' in YngQWasBwxyUTJlIKvNVLMezXbmSPt:YngQWasBwxyUTJlIKvNVLMezXbmSPu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',YngQWasBwxyUTJlIKvNVLMezXbmSPt.get('icon')) 
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel='',img=YngQWasBwxyUTJlIKvNVLMezXbmSPu,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSPG,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR,isLink=YngQWasBwxyUTJlIKvNVLMezXbmSPF)
  xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle)
 def login_main(YngQWasBwxyUTJlIKvNVLMezXbmSoA):
  (YngQWasBwxyUTJlIKvNVLMezXbmSPC,YngQWasBwxyUTJlIKvNVLMezXbmSio,YngQWasBwxyUTJlIKvNVLMezXbmSiP,YngQWasBwxyUTJlIKvNVLMezXbmSiD)=YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_settings_account()
  if not(YngQWasBwxyUTJlIKvNVLMezXbmSPC and YngQWasBwxyUTJlIKvNVLMezXbmSio):
   YngQWasBwxyUTJlIKvNVLMezXbmSot=xbmcgui.Dialog()
   YngQWasBwxyUTJlIKvNVLMezXbmSir=YngQWasBwxyUTJlIKvNVLMezXbmSot.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if YngQWasBwxyUTJlIKvNVLMezXbmSir==YngQWasBwxyUTJlIKvNVLMezXbmSEp:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if YngQWasBwxyUTJlIKvNVLMezXbmSoA.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   YngQWasBwxyUTJlIKvNVLMezXbmSih=0
   while YngQWasBwxyUTJlIKvNVLMezXbmSEp:
    YngQWasBwxyUTJlIKvNVLMezXbmSih+=1
    time.sleep(0.05)
    if YngQWasBwxyUTJlIKvNVLMezXbmSih>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  YngQWasBwxyUTJlIKvNVLMezXbmSif=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.GetCredential(YngQWasBwxyUTJlIKvNVLMezXbmSPC,YngQWasBwxyUTJlIKvNVLMezXbmSio,YngQWasBwxyUTJlIKvNVLMezXbmSiP,YngQWasBwxyUTJlIKvNVLMezXbmSiD)
  if YngQWasBwxyUTJlIKvNVLMezXbmSif:YngQWasBwxyUTJlIKvNVLMezXbmSoA.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if YngQWasBwxyUTJlIKvNVLMezXbmSif==YngQWasBwxyUTJlIKvNVLMezXbmSEH:
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSiE=YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('stype')
  if YngQWasBwxyUTJlIKvNVLMezXbmSiE=='live':
   YngQWasBwxyUTJlIKvNVLMezXbmSiO=YngQWasBwxyUTJlIKvNVLMezXbmSoD
  elif YngQWasBwxyUTJlIKvNVLMezXbmSiE=='vod':
   YngQWasBwxyUTJlIKvNVLMezXbmSiO=YngQWasBwxyUTJlIKvNVLMezXbmSof
  else:
   YngQWasBwxyUTJlIKvNVLMezXbmSiO=YngQWasBwxyUTJlIKvNVLMezXbmSoE
  for YngQWasBwxyUTJlIKvNVLMezXbmSic in YngQWasBwxyUTJlIKvNVLMezXbmSiO:
   YngQWasBwxyUTJlIKvNVLMezXbmSPA=YngQWasBwxyUTJlIKvNVLMezXbmSic.get('title')
   if YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('ordernm')!='-':
    YngQWasBwxyUTJlIKvNVLMezXbmSPA+='  ('+YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('ordernm')+')'
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':YngQWasBwxyUTJlIKvNVLMezXbmSic.get('mode'),'stype':YngQWasBwxyUTJlIKvNVLMezXbmSic.get('stype'),'orderby':YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('orderby'),'ordernm':YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('ordernm'),'page':'1'}
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel='',img='',infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  if YngQWasBwxyUTJlIKvNVLMezXbmSEt(YngQWasBwxyUTJlIKvNVLMezXbmSiO)>0:xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle)
 def dp_SubTitle_Group(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq): 
  for YngQWasBwxyUTJlIKvNVLMezXbmSic in YngQWasBwxyUTJlIKvNVLMezXbmSoO:
   YngQWasBwxyUTJlIKvNVLMezXbmSPA=YngQWasBwxyUTJlIKvNVLMezXbmSic.get('title')
   if YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('ordernm')!='-':
    YngQWasBwxyUTJlIKvNVLMezXbmSPA+='  ('+YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('ordernm')+')'
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':YngQWasBwxyUTJlIKvNVLMezXbmSic.get('mode'),'genreCode':YngQWasBwxyUTJlIKvNVLMezXbmSic.get('genreCode'),'stype':YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('stype'),'orderby':YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('orderby'),'page':'1'}
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel='',img='',infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  if YngQWasBwxyUTJlIKvNVLMezXbmSEt(YngQWasBwxyUTJlIKvNVLMezXbmSoO)>0:xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle)
 def dp_LiveChannel_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSiE =YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('stype')
  YngQWasBwxyUTJlIKvNVLMezXbmSiA =YngQWasBwxyUTJlIKvNVLMezXbmSEA(YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('page'))
  YngQWasBwxyUTJlIKvNVLMezXbmSip,YngQWasBwxyUTJlIKvNVLMezXbmSiH=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.GetLiveChannelList(YngQWasBwxyUTJlIKvNVLMezXbmSiE,YngQWasBwxyUTJlIKvNVLMezXbmSiA)
  for YngQWasBwxyUTJlIKvNVLMezXbmSik in YngQWasBwxyUTJlIKvNVLMezXbmSip:
   YngQWasBwxyUTJlIKvNVLMezXbmSPA =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('title')
   YngQWasBwxyUTJlIKvNVLMezXbmSPd =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('channel')
   YngQWasBwxyUTJlIKvNVLMezXbmSij =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('thumbnail')
   YngQWasBwxyUTJlIKvNVLMezXbmSit =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('synopsis')
   YngQWasBwxyUTJlIKvNVLMezXbmSiu =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('channelepg')
   YngQWasBwxyUTJlIKvNVLMezXbmSiR =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('cast')
   YngQWasBwxyUTJlIKvNVLMezXbmSiG =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('director')
   YngQWasBwxyUTJlIKvNVLMezXbmSiF =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('info_genre')
   YngQWasBwxyUTJlIKvNVLMezXbmSid =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('year')
   YngQWasBwxyUTJlIKvNVLMezXbmSiC =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('mpaa')
   YngQWasBwxyUTJlIKvNVLMezXbmSDo =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('premiered')
   YngQWasBwxyUTJlIKvNVLMezXbmSDP={'mediatype':'episode','title':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'studio':YngQWasBwxyUTJlIKvNVLMezXbmSPd,'cast':YngQWasBwxyUTJlIKvNVLMezXbmSiR,'director':YngQWasBwxyUTJlIKvNVLMezXbmSiG,'genre':YngQWasBwxyUTJlIKvNVLMezXbmSiF,'plot':'%s\n%s\n%s\n\n%s'%(YngQWasBwxyUTJlIKvNVLMezXbmSPd,YngQWasBwxyUTJlIKvNVLMezXbmSPA,YngQWasBwxyUTJlIKvNVLMezXbmSiu,YngQWasBwxyUTJlIKvNVLMezXbmSit),'year':YngQWasBwxyUTJlIKvNVLMezXbmSid,'mpaa':YngQWasBwxyUTJlIKvNVLMezXbmSiC,'premiered':YngQWasBwxyUTJlIKvNVLMezXbmSDo}
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'LIVE','mediacode':YngQWasBwxyUTJlIKvNVLMezXbmSik.get('mediacode'),'stype':YngQWasBwxyUTJlIKvNVLMezXbmSiE}
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPd,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSPA,img=YngQWasBwxyUTJlIKvNVLMezXbmSij,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSDP,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEH,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  if YngQWasBwxyUTJlIKvNVLMezXbmSiH:
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['mode']='CHANNEL' 
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['stype']=YngQWasBwxyUTJlIKvNVLMezXbmSiE 
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['page']=YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPA='[B]%s >>[/B]'%'다음 페이지'
   YngQWasBwxyUTJlIKvNVLMezXbmSDi=YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSDi,img=YngQWasBwxyUTJlIKvNVLMezXbmSPu,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  if YngQWasBwxyUTJlIKvNVLMezXbmSEt(YngQWasBwxyUTJlIKvNVLMezXbmSip)>0:xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,cacheToDisc=YngQWasBwxyUTJlIKvNVLMezXbmSEH)
 def dp_Program_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSDr =YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('stype')
  YngQWasBwxyUTJlIKvNVLMezXbmSPc =YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('orderby')
  YngQWasBwxyUTJlIKvNVLMezXbmSiA =YngQWasBwxyUTJlIKvNVLMezXbmSEA(YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('page'))
  YngQWasBwxyUTJlIKvNVLMezXbmSDh=YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('genreCode')
  if YngQWasBwxyUTJlIKvNVLMezXbmSDh==YngQWasBwxyUTJlIKvNVLMezXbmSEq:YngQWasBwxyUTJlIKvNVLMezXbmSDh='all'
  YngQWasBwxyUTJlIKvNVLMezXbmSDf,YngQWasBwxyUTJlIKvNVLMezXbmSiH=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.GetProgramList(YngQWasBwxyUTJlIKvNVLMezXbmSDr,YngQWasBwxyUTJlIKvNVLMezXbmSPc,YngQWasBwxyUTJlIKvNVLMezXbmSiA,YngQWasBwxyUTJlIKvNVLMezXbmSDh)
  for YngQWasBwxyUTJlIKvNVLMezXbmSDE in YngQWasBwxyUTJlIKvNVLMezXbmSDf:
   YngQWasBwxyUTJlIKvNVLMezXbmSPA =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('title')
   YngQWasBwxyUTJlIKvNVLMezXbmSij =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('thumbnail')
   YngQWasBwxyUTJlIKvNVLMezXbmSit =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('synopsis')
   YngQWasBwxyUTJlIKvNVLMezXbmSDO =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('channel')
   YngQWasBwxyUTJlIKvNVLMezXbmSiR =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('cast')
   YngQWasBwxyUTJlIKvNVLMezXbmSiG =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('director')
   YngQWasBwxyUTJlIKvNVLMezXbmSiF=YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('info_genre')
   YngQWasBwxyUTJlIKvNVLMezXbmSid =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('year')
   YngQWasBwxyUTJlIKvNVLMezXbmSDo =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('premiered')
   YngQWasBwxyUTJlIKvNVLMezXbmSiC =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('mpaa')
   YngQWasBwxyUTJlIKvNVLMezXbmSDP={'mediatype':'tvshow','title':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'studio':YngQWasBwxyUTJlIKvNVLMezXbmSDO,'cast':YngQWasBwxyUTJlIKvNVLMezXbmSiR,'director':YngQWasBwxyUTJlIKvNVLMezXbmSiG,'genre':YngQWasBwxyUTJlIKvNVLMezXbmSiF,'year':YngQWasBwxyUTJlIKvNVLMezXbmSid,'premiered':YngQWasBwxyUTJlIKvNVLMezXbmSDo,'mpaa':YngQWasBwxyUTJlIKvNVLMezXbmSiC,'plot':YngQWasBwxyUTJlIKvNVLMezXbmSit}
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'EPISODE','programcode':YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('program'),'page':'1'}
   if YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_settings_makebookmark():
    YngQWasBwxyUTJlIKvNVLMezXbmSDc={'videoid':YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('program'),'vidtype':'tvshow','vtitle':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'vsubtitle':YngQWasBwxyUTJlIKvNVLMezXbmSDO,}
    YngQWasBwxyUTJlIKvNVLMezXbmSDq=json.dumps(YngQWasBwxyUTJlIKvNVLMezXbmSDc)
    YngQWasBwxyUTJlIKvNVLMezXbmSDq=urllib.parse.quote(YngQWasBwxyUTJlIKvNVLMezXbmSDq)
    YngQWasBwxyUTJlIKvNVLMezXbmSDA='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(YngQWasBwxyUTJlIKvNVLMezXbmSDq)
    YngQWasBwxyUTJlIKvNVLMezXbmSDp=[('(통합) 찜 영상에 추가',YngQWasBwxyUTJlIKvNVLMezXbmSDA)]
   else:
    YngQWasBwxyUTJlIKvNVLMezXbmSDp=YngQWasBwxyUTJlIKvNVLMezXbmSEq
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSDO,img=YngQWasBwxyUTJlIKvNVLMezXbmSij,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSDP,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR,ContextMenu=YngQWasBwxyUTJlIKvNVLMezXbmSDp)
  if YngQWasBwxyUTJlIKvNVLMezXbmSiH:
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['mode'] ='PROGRAM' 
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['stype'] =YngQWasBwxyUTJlIKvNVLMezXbmSDr
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['orderby'] =YngQWasBwxyUTJlIKvNVLMezXbmSPc
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['page'] =YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['genreCode']=YngQWasBwxyUTJlIKvNVLMezXbmSDh 
   YngQWasBwxyUTJlIKvNVLMezXbmSPA='[B]%s >>[/B]'%'다음 페이지'
   YngQWasBwxyUTJlIKvNVLMezXbmSDi=YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSDi,img=YngQWasBwxyUTJlIKvNVLMezXbmSPu,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  xbmcplugin.setContent(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,cacheToDisc=YngQWasBwxyUTJlIKvNVLMezXbmSEH)
 def dp_4K_Program_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSiA =YngQWasBwxyUTJlIKvNVLMezXbmSEA(YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('page'))
  YngQWasBwxyUTJlIKvNVLMezXbmSDf,YngQWasBwxyUTJlIKvNVLMezXbmSiH=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.Get_UHD_ProgramList(YngQWasBwxyUTJlIKvNVLMezXbmSiA)
  for YngQWasBwxyUTJlIKvNVLMezXbmSDE in YngQWasBwxyUTJlIKvNVLMezXbmSDf:
   YngQWasBwxyUTJlIKvNVLMezXbmSPA =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('title')
   YngQWasBwxyUTJlIKvNVLMezXbmSij =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('thumbnail')
   YngQWasBwxyUTJlIKvNVLMezXbmSit =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('synopsis')
   YngQWasBwxyUTJlIKvNVLMezXbmSDO =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('channel')
   YngQWasBwxyUTJlIKvNVLMezXbmSiR =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('cast')
   YngQWasBwxyUTJlIKvNVLMezXbmSiG =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('director')
   YngQWasBwxyUTJlIKvNVLMezXbmSiF=YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('info_genre')
   YngQWasBwxyUTJlIKvNVLMezXbmSid =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('year')
   YngQWasBwxyUTJlIKvNVLMezXbmSDo =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('premiered')
   YngQWasBwxyUTJlIKvNVLMezXbmSiC =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('mpaa')
   YngQWasBwxyUTJlIKvNVLMezXbmSDP={'mediatype':'tvshow','title':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'studio':YngQWasBwxyUTJlIKvNVLMezXbmSDO,'cast':YngQWasBwxyUTJlIKvNVLMezXbmSiR,'director':YngQWasBwxyUTJlIKvNVLMezXbmSiG,'genre':YngQWasBwxyUTJlIKvNVLMezXbmSiF,'year':YngQWasBwxyUTJlIKvNVLMezXbmSid,'premiered':YngQWasBwxyUTJlIKvNVLMezXbmSDo,'mpaa':YngQWasBwxyUTJlIKvNVLMezXbmSiC,'plot':YngQWasBwxyUTJlIKvNVLMezXbmSit}
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'EPISODE','programcode':YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('program'),'page':'1'}
   if YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_settings_makebookmark():
    YngQWasBwxyUTJlIKvNVLMezXbmSDc={'videoid':YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('program'),'vidtype':'tvshow','vtitle':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'vsubtitle':YngQWasBwxyUTJlIKvNVLMezXbmSDO,}
    YngQWasBwxyUTJlIKvNVLMezXbmSDq=json.dumps(YngQWasBwxyUTJlIKvNVLMezXbmSDc)
    YngQWasBwxyUTJlIKvNVLMezXbmSDq=urllib.parse.quote(YngQWasBwxyUTJlIKvNVLMezXbmSDq)
    YngQWasBwxyUTJlIKvNVLMezXbmSDA='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(YngQWasBwxyUTJlIKvNVLMezXbmSDq)
    YngQWasBwxyUTJlIKvNVLMezXbmSDp=[('(통합) 찜 영상에 추가',YngQWasBwxyUTJlIKvNVLMezXbmSDA)]
   else:
    YngQWasBwxyUTJlIKvNVLMezXbmSDp=YngQWasBwxyUTJlIKvNVLMezXbmSEq
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSDO,img=YngQWasBwxyUTJlIKvNVLMezXbmSij,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSDP,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR,ContextMenu=YngQWasBwxyUTJlIKvNVLMezXbmSDp)
  if YngQWasBwxyUTJlIKvNVLMezXbmSiH:
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['mode'] ='4K_PROGRAM' 
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['page'] =YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPA='[B]%s >>[/B]'%'다음 페이지'
   YngQWasBwxyUTJlIKvNVLMezXbmSDi=YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSDi,img=YngQWasBwxyUTJlIKvNVLMezXbmSPu,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  xbmcplugin.setContent(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,cacheToDisc=YngQWasBwxyUTJlIKvNVLMezXbmSEH)
 def dp_Ori_Program_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSiA =YngQWasBwxyUTJlIKvNVLMezXbmSEA(YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('page'))
  YngQWasBwxyUTJlIKvNVLMezXbmSDf,YngQWasBwxyUTJlIKvNVLMezXbmSiH=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.Get_Origianl_ProgramList(YngQWasBwxyUTJlIKvNVLMezXbmSiA)
  for YngQWasBwxyUTJlIKvNVLMezXbmSDE in YngQWasBwxyUTJlIKvNVLMezXbmSDf:
   YngQWasBwxyUTJlIKvNVLMezXbmSPA =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('title')
   YngQWasBwxyUTJlIKvNVLMezXbmSij =YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('thumbnail')
   YngQWasBwxyUTJlIKvNVLMezXbmSDP={'mediatype':'tvshow','title':YngQWasBwxyUTJlIKvNVLMezXbmSPA,}
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'EPISODE','programcode':YngQWasBwxyUTJlIKvNVLMezXbmSDE.get('program'),'page':'1',}
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSEq,img=YngQWasBwxyUTJlIKvNVLMezXbmSij,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSDP,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR,ContextMenu=YngQWasBwxyUTJlIKvNVLMezXbmSEq)
  if YngQWasBwxyUTJlIKvNVLMezXbmSiH:
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['mode'] ='ORI_PROGRAM' 
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['page'] =YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPA='[B]%s >>[/B]'%'다음 페이지'
   YngQWasBwxyUTJlIKvNVLMezXbmSDi=YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSDi,img=YngQWasBwxyUTJlIKvNVLMezXbmSPu,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  xbmcplugin.setContent(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,cacheToDisc=YngQWasBwxyUTJlIKvNVLMezXbmSEH)
 def dp_Episode_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSDk=YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('programcode')
  YngQWasBwxyUTJlIKvNVLMezXbmSiA =YngQWasBwxyUTJlIKvNVLMezXbmSEA(YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('page'))
  YngQWasBwxyUTJlIKvNVLMezXbmSDj,YngQWasBwxyUTJlIKvNVLMezXbmSiH,YngQWasBwxyUTJlIKvNVLMezXbmSDt=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.GetEpisodeList(YngQWasBwxyUTJlIKvNVLMezXbmSDk,YngQWasBwxyUTJlIKvNVLMezXbmSiA,orderby=YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_winEpisodeOrderby())
  for YngQWasBwxyUTJlIKvNVLMezXbmSDu in YngQWasBwxyUTJlIKvNVLMezXbmSDj:
   YngQWasBwxyUTJlIKvNVLMezXbmSPA =YngQWasBwxyUTJlIKvNVLMezXbmSDu.get('title')
   YngQWasBwxyUTJlIKvNVLMezXbmSDi =YngQWasBwxyUTJlIKvNVLMezXbmSDu.get('subtitle')
   YngQWasBwxyUTJlIKvNVLMezXbmSij =YngQWasBwxyUTJlIKvNVLMezXbmSDu.get('thumbnail')
   YngQWasBwxyUTJlIKvNVLMezXbmSit =YngQWasBwxyUTJlIKvNVLMezXbmSDu.get('synopsis')
   YngQWasBwxyUTJlIKvNVLMezXbmSDR=YngQWasBwxyUTJlIKvNVLMezXbmSDu.get('info_title')
   YngQWasBwxyUTJlIKvNVLMezXbmSDG =YngQWasBwxyUTJlIKvNVLMezXbmSDu.get('aired')
   YngQWasBwxyUTJlIKvNVLMezXbmSDF =YngQWasBwxyUTJlIKvNVLMezXbmSDu.get('studio')
   YngQWasBwxyUTJlIKvNVLMezXbmSDd =YngQWasBwxyUTJlIKvNVLMezXbmSDu.get('frequency')
   YngQWasBwxyUTJlIKvNVLMezXbmSDP={'mediatype':'episode','title':YngQWasBwxyUTJlIKvNVLMezXbmSDR,'aired':YngQWasBwxyUTJlIKvNVLMezXbmSDG,'studio':YngQWasBwxyUTJlIKvNVLMezXbmSDF,'episode':YngQWasBwxyUTJlIKvNVLMezXbmSDd,'plot':YngQWasBwxyUTJlIKvNVLMezXbmSit}
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'VOD','mediacode':YngQWasBwxyUTJlIKvNVLMezXbmSDu.get('episode'),'stype':'vod','programcode':YngQWasBwxyUTJlIKvNVLMezXbmSDk,'title':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'thumbnail':YngQWasBwxyUTJlIKvNVLMezXbmSij}
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSDi,img=YngQWasBwxyUTJlIKvNVLMezXbmSij,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSDP,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEH,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  if YngQWasBwxyUTJlIKvNVLMezXbmSiA==1:
   YngQWasBwxyUTJlIKvNVLMezXbmSDP={'plot':'정렬순서를 변경합니다.'}
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={}
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['mode'] ='ORDER_BY' 
   if YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_winEpisodeOrderby()=='desc':
    YngQWasBwxyUTJlIKvNVLMezXbmSPA='정렬순서변경 : 최신화부터 -> 1회부터'
    YngQWasBwxyUTJlIKvNVLMezXbmSPR['orderby']='asc'
   else:
    YngQWasBwxyUTJlIKvNVLMezXbmSPA='정렬순서변경 : 1회부터 -> 최신화부터'
    YngQWasBwxyUTJlIKvNVLMezXbmSPR['orderby']='desc'
   YngQWasBwxyUTJlIKvNVLMezXbmSPu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel='',img=YngQWasBwxyUTJlIKvNVLMezXbmSPu,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSDP,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEH,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR,isLink=YngQWasBwxyUTJlIKvNVLMezXbmSEp)
  if YngQWasBwxyUTJlIKvNVLMezXbmSiH:
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['mode'] ='EPISODE' 
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['programcode']=YngQWasBwxyUTJlIKvNVLMezXbmSDk
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['page'] =YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPA='[B]%s >>[/B]'%'다음 페이지'
   YngQWasBwxyUTJlIKvNVLMezXbmSDi=YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSDi,img=YngQWasBwxyUTJlIKvNVLMezXbmSPu,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  xbmcplugin.setContent(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,'episodes')
  if YngQWasBwxyUTJlIKvNVLMezXbmSEt(YngQWasBwxyUTJlIKvNVLMezXbmSDj)>0:xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,cacheToDisc=YngQWasBwxyUTJlIKvNVLMezXbmSEp)
 def dp_setEpOrderby(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSPc =YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('orderby')
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.set_winEpisodeOrderby(YngQWasBwxyUTJlIKvNVLMezXbmSPc)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSDr =YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('stype')
  YngQWasBwxyUTJlIKvNVLMezXbmSPc =YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('orderby')
  YngQWasBwxyUTJlIKvNVLMezXbmSiA=YngQWasBwxyUTJlIKvNVLMezXbmSEA(YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('page'))
  YngQWasBwxyUTJlIKvNVLMezXbmSDC,YngQWasBwxyUTJlIKvNVLMezXbmSiH=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.GetMovieList(YngQWasBwxyUTJlIKvNVLMezXbmSDr,YngQWasBwxyUTJlIKvNVLMezXbmSPc,YngQWasBwxyUTJlIKvNVLMezXbmSiA)
  for YngQWasBwxyUTJlIKvNVLMezXbmSro in YngQWasBwxyUTJlIKvNVLMezXbmSDC:
   YngQWasBwxyUTJlIKvNVLMezXbmSPA =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('title')
   YngQWasBwxyUTJlIKvNVLMezXbmSij =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('thumbnail')
   YngQWasBwxyUTJlIKvNVLMezXbmSit =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('synopsis')
   YngQWasBwxyUTJlIKvNVLMezXbmSDR =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('info_title')
   YngQWasBwxyUTJlIKvNVLMezXbmSid =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('year')
   YngQWasBwxyUTJlIKvNVLMezXbmSiR =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('cast')
   YngQWasBwxyUTJlIKvNVLMezXbmSiG =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('director')
   YngQWasBwxyUTJlIKvNVLMezXbmSiF =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('info_genre')
   YngQWasBwxyUTJlIKvNVLMezXbmSrP =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('duration')
   YngQWasBwxyUTJlIKvNVLMezXbmSDo =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('premiered')
   YngQWasBwxyUTJlIKvNVLMezXbmSDF =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('studio')
   YngQWasBwxyUTJlIKvNVLMezXbmSiC =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('mpaa')
   YngQWasBwxyUTJlIKvNVLMezXbmSDP={'mediatype':'movie','title':YngQWasBwxyUTJlIKvNVLMezXbmSDR,'year':YngQWasBwxyUTJlIKvNVLMezXbmSid,'cast':YngQWasBwxyUTJlIKvNVLMezXbmSiR,'director':YngQWasBwxyUTJlIKvNVLMezXbmSiG,'genre':YngQWasBwxyUTJlIKvNVLMezXbmSiF,'duration':YngQWasBwxyUTJlIKvNVLMezXbmSrP,'premiered':YngQWasBwxyUTJlIKvNVLMezXbmSDo,'studio':YngQWasBwxyUTJlIKvNVLMezXbmSDF,'mpaa':YngQWasBwxyUTJlIKvNVLMezXbmSiC,'plot':YngQWasBwxyUTJlIKvNVLMezXbmSit}
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'MOVIE','mediacode':YngQWasBwxyUTJlIKvNVLMezXbmSro.get('moviecode'),'stype':'movie','title':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'thumbnail':YngQWasBwxyUTJlIKvNVLMezXbmSij}
   if YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_settings_makebookmark():
    YngQWasBwxyUTJlIKvNVLMezXbmSDc={'videoid':YngQWasBwxyUTJlIKvNVLMezXbmSro.get('moviecode'),'vidtype':'movie','vtitle':YngQWasBwxyUTJlIKvNVLMezXbmSDR,'vsubtitle':'',}
    YngQWasBwxyUTJlIKvNVLMezXbmSDq=json.dumps(YngQWasBwxyUTJlIKvNVLMezXbmSDc)
    YngQWasBwxyUTJlIKvNVLMezXbmSDq=urllib.parse.quote(YngQWasBwxyUTJlIKvNVLMezXbmSDq)
    YngQWasBwxyUTJlIKvNVLMezXbmSDA='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(YngQWasBwxyUTJlIKvNVLMezXbmSDq)
    YngQWasBwxyUTJlIKvNVLMezXbmSDp=[('(통합) 찜 영상에 추가',YngQWasBwxyUTJlIKvNVLMezXbmSDA)]
   else:
    YngQWasBwxyUTJlIKvNVLMezXbmSDp=YngQWasBwxyUTJlIKvNVLMezXbmSEq
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel='',img=YngQWasBwxyUTJlIKvNVLMezXbmSij,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSDP,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEH,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR,ContextMenu=YngQWasBwxyUTJlIKvNVLMezXbmSDp)
  if YngQWasBwxyUTJlIKvNVLMezXbmSiH:
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={}
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['mode'] ='MOVIE_SUB' 
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['orderby']=YngQWasBwxyUTJlIKvNVLMezXbmSPc
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['stype'] =YngQWasBwxyUTJlIKvNVLMezXbmSDr
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['page'] =YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPA='[B]%s >>[/B]'%'다음 페이지'
   YngQWasBwxyUTJlIKvNVLMezXbmSDi=YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSDi,img=YngQWasBwxyUTJlIKvNVLMezXbmSPu,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  xbmcplugin.setContent(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,'movies')
  xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,cacheToDisc=YngQWasBwxyUTJlIKvNVLMezXbmSEH)
 def dp_4K_Movie_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSiA=YngQWasBwxyUTJlIKvNVLMezXbmSEA(YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('page'))
  YngQWasBwxyUTJlIKvNVLMezXbmSDC,YngQWasBwxyUTJlIKvNVLMezXbmSiH=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.Get_UHD_MovieList(YngQWasBwxyUTJlIKvNVLMezXbmSiA)
  for YngQWasBwxyUTJlIKvNVLMezXbmSro in YngQWasBwxyUTJlIKvNVLMezXbmSDC:
   YngQWasBwxyUTJlIKvNVLMezXbmSPA =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('title')
   YngQWasBwxyUTJlIKvNVLMezXbmSij =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('thumbnail')
   YngQWasBwxyUTJlIKvNVLMezXbmSit =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('synopsis')
   YngQWasBwxyUTJlIKvNVLMezXbmSDR =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('info_title')
   YngQWasBwxyUTJlIKvNVLMezXbmSid =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('year')
   YngQWasBwxyUTJlIKvNVLMezXbmSiR =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('cast')
   YngQWasBwxyUTJlIKvNVLMezXbmSiG =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('director')
   YngQWasBwxyUTJlIKvNVLMezXbmSiF =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('info_genre')
   YngQWasBwxyUTJlIKvNVLMezXbmSrP =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('duration')
   YngQWasBwxyUTJlIKvNVLMezXbmSDo =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('premiered')
   YngQWasBwxyUTJlIKvNVLMezXbmSDF =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('studio')
   YngQWasBwxyUTJlIKvNVLMezXbmSiC =YngQWasBwxyUTJlIKvNVLMezXbmSro.get('mpaa')
   YngQWasBwxyUTJlIKvNVLMezXbmSDP={'mediatype':'movie','title':YngQWasBwxyUTJlIKvNVLMezXbmSDR,'year':YngQWasBwxyUTJlIKvNVLMezXbmSid,'cast':YngQWasBwxyUTJlIKvNVLMezXbmSiR,'director':YngQWasBwxyUTJlIKvNVLMezXbmSiG,'genre':YngQWasBwxyUTJlIKvNVLMezXbmSiF,'duration':YngQWasBwxyUTJlIKvNVLMezXbmSrP,'premiered':YngQWasBwxyUTJlIKvNVLMezXbmSDo,'studio':YngQWasBwxyUTJlIKvNVLMezXbmSDF,'mpaa':YngQWasBwxyUTJlIKvNVLMezXbmSiC,'plot':YngQWasBwxyUTJlIKvNVLMezXbmSit}
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'MOVIE','mediacode':YngQWasBwxyUTJlIKvNVLMezXbmSro.get('moviecode'),'stype':'movie','title':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'thumbnail':YngQWasBwxyUTJlIKvNVLMezXbmSij}
   if YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_settings_makebookmark():
    YngQWasBwxyUTJlIKvNVLMezXbmSDc={'videoid':YngQWasBwxyUTJlIKvNVLMezXbmSro.get('moviecode'),'vidtype':'movie','vtitle':YngQWasBwxyUTJlIKvNVLMezXbmSDR,'vsubtitle':'',}
    YngQWasBwxyUTJlIKvNVLMezXbmSDq=json.dumps(YngQWasBwxyUTJlIKvNVLMezXbmSDc)
    YngQWasBwxyUTJlIKvNVLMezXbmSDq=urllib.parse.quote(YngQWasBwxyUTJlIKvNVLMezXbmSDq)
    YngQWasBwxyUTJlIKvNVLMezXbmSDA='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(YngQWasBwxyUTJlIKvNVLMezXbmSDq)
    YngQWasBwxyUTJlIKvNVLMezXbmSDp=[('(통합) 찜 영상에 추가',YngQWasBwxyUTJlIKvNVLMezXbmSDA)]
   else:
    YngQWasBwxyUTJlIKvNVLMezXbmSDp=YngQWasBwxyUTJlIKvNVLMezXbmSEq
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel='',img=YngQWasBwxyUTJlIKvNVLMezXbmSij,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSDP,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEH,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR,ContextMenu=YngQWasBwxyUTJlIKvNVLMezXbmSDp)
  if YngQWasBwxyUTJlIKvNVLMezXbmSiH:
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={}
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['mode'] ='4K_MOVIE' 
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['page'] =YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPA='[B]%s >>[/B]'%'다음 페이지'
   YngQWasBwxyUTJlIKvNVLMezXbmSDi=YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSDi,img=YngQWasBwxyUTJlIKvNVLMezXbmSPu,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  xbmcplugin.setContent(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,'movies')
  xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,cacheToDisc=YngQWasBwxyUTJlIKvNVLMezXbmSEH)
 def dp_Set_Bookmark(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSri=urllib.parse.unquote(YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('bm_param'))
  YngQWasBwxyUTJlIKvNVLMezXbmSri=json.loads(YngQWasBwxyUTJlIKvNVLMezXbmSri)
  YngQWasBwxyUTJlIKvNVLMezXbmSrD =YngQWasBwxyUTJlIKvNVLMezXbmSri.get('videoid')
  YngQWasBwxyUTJlIKvNVLMezXbmSrh =YngQWasBwxyUTJlIKvNVLMezXbmSri.get('vidtype')
  YngQWasBwxyUTJlIKvNVLMezXbmSrf =YngQWasBwxyUTJlIKvNVLMezXbmSri.get('vtitle')
  YngQWasBwxyUTJlIKvNVLMezXbmSrE =YngQWasBwxyUTJlIKvNVLMezXbmSri.get('vsubtitle')
  YngQWasBwxyUTJlIKvNVLMezXbmSot=xbmcgui.Dialog()
  YngQWasBwxyUTJlIKvNVLMezXbmSir=YngQWasBwxyUTJlIKvNVLMezXbmSot.yesno(__language__(30913).encode('utf8'),YngQWasBwxyUTJlIKvNVLMezXbmSrf+' \n\n'+__language__(30914))
  if YngQWasBwxyUTJlIKvNVLMezXbmSir==YngQWasBwxyUTJlIKvNVLMezXbmSEH:return
  YngQWasBwxyUTJlIKvNVLMezXbmSrO=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.GetBookmarkInfo(YngQWasBwxyUTJlIKvNVLMezXbmSrD,YngQWasBwxyUTJlIKvNVLMezXbmSrh)
  if YngQWasBwxyUTJlIKvNVLMezXbmSrE!='':
   YngQWasBwxyUTJlIKvNVLMezXbmSrO['saveinfo']['subtitle']=YngQWasBwxyUTJlIKvNVLMezXbmSrE 
   if YngQWasBwxyUTJlIKvNVLMezXbmSrh=='tvshow':YngQWasBwxyUTJlIKvNVLMezXbmSrO['saveinfo']['infoLabels']['studio']=YngQWasBwxyUTJlIKvNVLMezXbmSrE 
  YngQWasBwxyUTJlIKvNVLMezXbmSrc=json.dumps(YngQWasBwxyUTJlIKvNVLMezXbmSrO)
  YngQWasBwxyUTJlIKvNVLMezXbmSrc=urllib.parse.quote(YngQWasBwxyUTJlIKvNVLMezXbmSrc)
  YngQWasBwxyUTJlIKvNVLMezXbmSDA ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(YngQWasBwxyUTJlIKvNVLMezXbmSrc)
  xbmc.executebuiltin(YngQWasBwxyUTJlIKvNVLMezXbmSDA)
 def dp_Search_Group(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  if 'search_key' in YngQWasBwxyUTJlIKvNVLMezXbmSiq:
   YngQWasBwxyUTJlIKvNVLMezXbmSrq=YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('search_key')
  else:
   YngQWasBwxyUTJlIKvNVLMezXbmSrq=YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not YngQWasBwxyUTJlIKvNVLMezXbmSrq:
    return
  for YngQWasBwxyUTJlIKvNVLMezXbmSic in YngQWasBwxyUTJlIKvNVLMezXbmSoh:
   YngQWasBwxyUTJlIKvNVLMezXbmSrA =YngQWasBwxyUTJlIKvNVLMezXbmSic.get('mode')
   YngQWasBwxyUTJlIKvNVLMezXbmSiE=YngQWasBwxyUTJlIKvNVLMezXbmSic.get('stype')
   YngQWasBwxyUTJlIKvNVLMezXbmSPA=YngQWasBwxyUTJlIKvNVLMezXbmSic.get('title')
   (YngQWasBwxyUTJlIKvNVLMezXbmSrp,YngQWasBwxyUTJlIKvNVLMezXbmSiH)=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.GetSearchList(YngQWasBwxyUTJlIKvNVLMezXbmSrq,1,YngQWasBwxyUTJlIKvNVLMezXbmSiE)
   YngQWasBwxyUTJlIKvNVLMezXbmSrH={'plot':'검색어 : '+YngQWasBwxyUTJlIKvNVLMezXbmSrq+'\n\n'+YngQWasBwxyUTJlIKvNVLMezXbmSoA.Search_FreeList(YngQWasBwxyUTJlIKvNVLMezXbmSrp)}
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':YngQWasBwxyUTJlIKvNVLMezXbmSrA,'stype':YngQWasBwxyUTJlIKvNVLMezXbmSiE,'search_key':YngQWasBwxyUTJlIKvNVLMezXbmSrq,'page':'1',}
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel='',img='',infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSrH,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  if YngQWasBwxyUTJlIKvNVLMezXbmSEt(YngQWasBwxyUTJlIKvNVLMezXbmSoh)>0:xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,cacheToDisc=YngQWasBwxyUTJlIKvNVLMezXbmSEp)
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.Save_Searched_List(YngQWasBwxyUTJlIKvNVLMezXbmSrq)
 def Search_FreeList(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSrC):
  YngQWasBwxyUTJlIKvNVLMezXbmSrk=''
  YngQWasBwxyUTJlIKvNVLMezXbmSrj=7
  try:
   if YngQWasBwxyUTJlIKvNVLMezXbmSEt(YngQWasBwxyUTJlIKvNVLMezXbmSrC)==0:return '검색결과 없음'
   for i in YngQWasBwxyUTJlIKvNVLMezXbmSER(YngQWasBwxyUTJlIKvNVLMezXbmSEt(YngQWasBwxyUTJlIKvNVLMezXbmSrC)):
    if i>=YngQWasBwxyUTJlIKvNVLMezXbmSrj:
     YngQWasBwxyUTJlIKvNVLMezXbmSrk=YngQWasBwxyUTJlIKvNVLMezXbmSrk+'...'
     break
    YngQWasBwxyUTJlIKvNVLMezXbmSrk=YngQWasBwxyUTJlIKvNVLMezXbmSrk+YngQWasBwxyUTJlIKvNVLMezXbmSrC[i]['title']+'\n'
  except:
   return ''
  return YngQWasBwxyUTJlIKvNVLMezXbmSrk
 def dp_Search_History(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSrt=YngQWasBwxyUTJlIKvNVLMezXbmSoA.Load_List_File('search')
  for YngQWasBwxyUTJlIKvNVLMezXbmSru in YngQWasBwxyUTJlIKvNVLMezXbmSrt:
   YngQWasBwxyUTJlIKvNVLMezXbmSrR=YngQWasBwxyUTJlIKvNVLMezXbmSEj(urllib.parse.parse_qsl(YngQWasBwxyUTJlIKvNVLMezXbmSru))
   YngQWasBwxyUTJlIKvNVLMezXbmSrG=YngQWasBwxyUTJlIKvNVLMezXbmSrR.get('skey').strip()
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'SEARCH_GROUP','search_key':YngQWasBwxyUTJlIKvNVLMezXbmSrG,}
   YngQWasBwxyUTJlIKvNVLMezXbmSrF={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':YngQWasBwxyUTJlIKvNVLMezXbmSrG,'vType':'-',}
   YngQWasBwxyUTJlIKvNVLMezXbmSrd=urllib.parse.urlencode(YngQWasBwxyUTJlIKvNVLMezXbmSrF)
   YngQWasBwxyUTJlIKvNVLMezXbmSDp=[('선택된 검색어 ( %s ) 삭제'%(YngQWasBwxyUTJlIKvNVLMezXbmSrG),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(YngQWasBwxyUTJlIKvNVLMezXbmSrd))]
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSrG,sublabel='',img=YngQWasBwxyUTJlIKvNVLMezXbmSEq,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR,ContextMenu=YngQWasBwxyUTJlIKvNVLMezXbmSDp)
  YngQWasBwxyUTJlIKvNVLMezXbmSDP={'plot':'검색목록 전체를 삭제합니다.'}
  YngQWasBwxyUTJlIKvNVLMezXbmSPA='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  YngQWasBwxyUTJlIKvNVLMezXbmSPu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel='',img=YngQWasBwxyUTJlIKvNVLMezXbmSPu,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSDP,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEH,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR,isLink=YngQWasBwxyUTJlIKvNVLMezXbmSEp)
  xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,cacheToDisc=YngQWasBwxyUTJlIKvNVLMezXbmSEH)
 def dp_Search_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSiA =YngQWasBwxyUTJlIKvNVLMezXbmSEA(YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('page'))
  YngQWasBwxyUTJlIKvNVLMezXbmSiE =YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('stype')
  if 'search_key' in YngQWasBwxyUTJlIKvNVLMezXbmSiq:
   YngQWasBwxyUTJlIKvNVLMezXbmSrq=YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('search_key')
  else:
   YngQWasBwxyUTJlIKvNVLMezXbmSrq=YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not YngQWasBwxyUTJlIKvNVLMezXbmSrq:
    xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle)
    return
  YngQWasBwxyUTJlIKvNVLMezXbmSrp,YngQWasBwxyUTJlIKvNVLMezXbmSiH=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.GetSearchList(YngQWasBwxyUTJlIKvNVLMezXbmSrq,YngQWasBwxyUTJlIKvNVLMezXbmSiA,YngQWasBwxyUTJlIKvNVLMezXbmSiE)
  for YngQWasBwxyUTJlIKvNVLMezXbmSrC in YngQWasBwxyUTJlIKvNVLMezXbmSrp:
   YngQWasBwxyUTJlIKvNVLMezXbmSPA =YngQWasBwxyUTJlIKvNVLMezXbmSrC.get('title')
   YngQWasBwxyUTJlIKvNVLMezXbmSij =YngQWasBwxyUTJlIKvNVLMezXbmSrC.get('thumbnail')
   YngQWasBwxyUTJlIKvNVLMezXbmSit =YngQWasBwxyUTJlIKvNVLMezXbmSrC.get('synopsis')
   YngQWasBwxyUTJlIKvNVLMezXbmSho =YngQWasBwxyUTJlIKvNVLMezXbmSrC.get('program')
   YngQWasBwxyUTJlIKvNVLMezXbmSiR =YngQWasBwxyUTJlIKvNVLMezXbmSrC.get('cast')
   YngQWasBwxyUTJlIKvNVLMezXbmSiG =YngQWasBwxyUTJlIKvNVLMezXbmSrC.get('director')
   YngQWasBwxyUTJlIKvNVLMezXbmSiF=YngQWasBwxyUTJlIKvNVLMezXbmSrC.get('info_genre')
   YngQWasBwxyUTJlIKvNVLMezXbmSrP =YngQWasBwxyUTJlIKvNVLMezXbmSrC.get('duration')
   YngQWasBwxyUTJlIKvNVLMezXbmSiC =YngQWasBwxyUTJlIKvNVLMezXbmSrC.get('mpaa')
   YngQWasBwxyUTJlIKvNVLMezXbmSid =YngQWasBwxyUTJlIKvNVLMezXbmSrC.get('year')
   YngQWasBwxyUTJlIKvNVLMezXbmSDG =YngQWasBwxyUTJlIKvNVLMezXbmSrC.get('aired')
   YngQWasBwxyUTJlIKvNVLMezXbmSDP={'mediatype':'tvshow' if YngQWasBwxyUTJlIKvNVLMezXbmSiE=='vod' else 'movie','title':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'cast':YngQWasBwxyUTJlIKvNVLMezXbmSiR,'director':YngQWasBwxyUTJlIKvNVLMezXbmSiG,'genre':YngQWasBwxyUTJlIKvNVLMezXbmSiF,'duration':YngQWasBwxyUTJlIKvNVLMezXbmSrP,'mpaa':YngQWasBwxyUTJlIKvNVLMezXbmSiC,'year':YngQWasBwxyUTJlIKvNVLMezXbmSid,'aired':YngQWasBwxyUTJlIKvNVLMezXbmSDG,'plot':'%s\n\n%s'%(YngQWasBwxyUTJlIKvNVLMezXbmSPA,YngQWasBwxyUTJlIKvNVLMezXbmSit)}
   if YngQWasBwxyUTJlIKvNVLMezXbmSiE=='vod':
    YngQWasBwxyUTJlIKvNVLMezXbmSrD=YngQWasBwxyUTJlIKvNVLMezXbmSrC.get('program')
    YngQWasBwxyUTJlIKvNVLMezXbmSrh='tvshow'
    YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'EPISODE','programcode':YngQWasBwxyUTJlIKvNVLMezXbmSrD,'page':'1',}
    YngQWasBwxyUTJlIKvNVLMezXbmSPG=YngQWasBwxyUTJlIKvNVLMezXbmSEp
   else:
    YngQWasBwxyUTJlIKvNVLMezXbmSrD=YngQWasBwxyUTJlIKvNVLMezXbmSrC.get('movie')
    YngQWasBwxyUTJlIKvNVLMezXbmSrh='movie'
    YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'MOVIE','mediacode':YngQWasBwxyUTJlIKvNVLMezXbmSrD,'stype':'movie','title':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'thumbnail':YngQWasBwxyUTJlIKvNVLMezXbmSij,}
    YngQWasBwxyUTJlIKvNVLMezXbmSPG=YngQWasBwxyUTJlIKvNVLMezXbmSEH
   if YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_settings_makebookmark():
    YngQWasBwxyUTJlIKvNVLMezXbmSDc={'videoid':YngQWasBwxyUTJlIKvNVLMezXbmSrD,'vidtype':YngQWasBwxyUTJlIKvNVLMezXbmSrh,'vtitle':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'vsubtitle':'',}
    YngQWasBwxyUTJlIKvNVLMezXbmSDq=json.dumps(YngQWasBwxyUTJlIKvNVLMezXbmSDc)
    YngQWasBwxyUTJlIKvNVLMezXbmSDq=urllib.parse.quote(YngQWasBwxyUTJlIKvNVLMezXbmSDq)
    YngQWasBwxyUTJlIKvNVLMezXbmSDA='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(YngQWasBwxyUTJlIKvNVLMezXbmSDq)
    YngQWasBwxyUTJlIKvNVLMezXbmSDp=[('(통합) 찜 영상에 추가',YngQWasBwxyUTJlIKvNVLMezXbmSDA)]
   else:
    YngQWasBwxyUTJlIKvNVLMezXbmSDp=YngQWasBwxyUTJlIKvNVLMezXbmSEq
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel='',img=YngQWasBwxyUTJlIKvNVLMezXbmSij,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSDP,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSPG,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR,isLink=YngQWasBwxyUTJlIKvNVLMezXbmSEH,ContextMenu=YngQWasBwxyUTJlIKvNVLMezXbmSDp)
  if YngQWasBwxyUTJlIKvNVLMezXbmSiH:
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['mode'] ='SEARCH' 
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['search_key']=YngQWasBwxyUTJlIKvNVLMezXbmSrq
   YngQWasBwxyUTJlIKvNVLMezXbmSPR['page'] =YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPA='[B]%s >>[/B]'%'다음 페이지'
   YngQWasBwxyUTJlIKvNVLMezXbmSDi=YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSiA+1)
   YngQWasBwxyUTJlIKvNVLMezXbmSPu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSDi,img=YngQWasBwxyUTJlIKvNVLMezXbmSPu,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  if YngQWasBwxyUTJlIKvNVLMezXbmSiE=='movie':xbmcplugin.setContent(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,'movies')
  else:xbmcplugin.setContent(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,cacheToDisc=YngQWasBwxyUTJlIKvNVLMezXbmSEH)
 def dp_History_Remove(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmShP=YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('delType')
  YngQWasBwxyUTJlIKvNVLMezXbmShi =YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('sKey')
  YngQWasBwxyUTJlIKvNVLMezXbmShD =YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('vType')
  YngQWasBwxyUTJlIKvNVLMezXbmSot=xbmcgui.Dialog()
  if YngQWasBwxyUTJlIKvNVLMezXbmShP=='SEARCH_ALL':
   YngQWasBwxyUTJlIKvNVLMezXbmSir=YngQWasBwxyUTJlIKvNVLMezXbmSot.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif YngQWasBwxyUTJlIKvNVLMezXbmShP=='SEARCH_ONE':
   YngQWasBwxyUTJlIKvNVLMezXbmSir=YngQWasBwxyUTJlIKvNVLMezXbmSot.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif YngQWasBwxyUTJlIKvNVLMezXbmShP=='WATCH_ALL':
   YngQWasBwxyUTJlIKvNVLMezXbmSir=YngQWasBwxyUTJlIKvNVLMezXbmSot.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif YngQWasBwxyUTJlIKvNVLMezXbmShP=='WATCH_ONE':
   YngQWasBwxyUTJlIKvNVLMezXbmSir=YngQWasBwxyUTJlIKvNVLMezXbmSot.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if YngQWasBwxyUTJlIKvNVLMezXbmSir==YngQWasBwxyUTJlIKvNVLMezXbmSEH:sys.exit()
  if YngQWasBwxyUTJlIKvNVLMezXbmShP=='SEARCH_ALL':
   if os.path.isfile(YngQWasBwxyUTJlIKvNVLMezXbmSoq):os.remove(YngQWasBwxyUTJlIKvNVLMezXbmSoq)
  elif YngQWasBwxyUTJlIKvNVLMezXbmShP=='SEARCH_ONE':
   try:
    YngQWasBwxyUTJlIKvNVLMezXbmShr=YngQWasBwxyUTJlIKvNVLMezXbmSoq
    YngQWasBwxyUTJlIKvNVLMezXbmShf=YngQWasBwxyUTJlIKvNVLMezXbmSoA.Load_List_File('search') 
    fp=YngQWasBwxyUTJlIKvNVLMezXbmSEG(YngQWasBwxyUTJlIKvNVLMezXbmShr,'w',-1,'utf-8')
    for YngQWasBwxyUTJlIKvNVLMezXbmShE in YngQWasBwxyUTJlIKvNVLMezXbmShf:
     YngQWasBwxyUTJlIKvNVLMezXbmShO=YngQWasBwxyUTJlIKvNVLMezXbmSEj(urllib.parse.parse_qsl(YngQWasBwxyUTJlIKvNVLMezXbmShE))
     YngQWasBwxyUTJlIKvNVLMezXbmShc=YngQWasBwxyUTJlIKvNVLMezXbmShO.get('skey').strip()
     if YngQWasBwxyUTJlIKvNVLMezXbmShi!=YngQWasBwxyUTJlIKvNVLMezXbmShc:
      fp.write(YngQWasBwxyUTJlIKvNVLMezXbmShE)
    fp.close()
   except:
    YngQWasBwxyUTJlIKvNVLMezXbmSEq
  elif YngQWasBwxyUTJlIKvNVLMezXbmShP=='WATCH_ALL':
   YngQWasBwxyUTJlIKvNVLMezXbmShr=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%YngQWasBwxyUTJlIKvNVLMezXbmShD))
   if os.path.isfile(YngQWasBwxyUTJlIKvNVLMezXbmShr):os.remove(YngQWasBwxyUTJlIKvNVLMezXbmShr)
  elif YngQWasBwxyUTJlIKvNVLMezXbmShP=='WATCH_ONE':
   YngQWasBwxyUTJlIKvNVLMezXbmShr=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%YngQWasBwxyUTJlIKvNVLMezXbmShD))
   try:
    YngQWasBwxyUTJlIKvNVLMezXbmShf=YngQWasBwxyUTJlIKvNVLMezXbmSoA.Load_List_File(YngQWasBwxyUTJlIKvNVLMezXbmShD) 
    fp=YngQWasBwxyUTJlIKvNVLMezXbmSEG(YngQWasBwxyUTJlIKvNVLMezXbmShr,'w',-1,'utf-8')
    for YngQWasBwxyUTJlIKvNVLMezXbmShE in YngQWasBwxyUTJlIKvNVLMezXbmShf:
     YngQWasBwxyUTJlIKvNVLMezXbmShO=YngQWasBwxyUTJlIKvNVLMezXbmSEj(urllib.parse.parse_qsl(YngQWasBwxyUTJlIKvNVLMezXbmShE))
     YngQWasBwxyUTJlIKvNVLMezXbmShc=YngQWasBwxyUTJlIKvNVLMezXbmShO.get('code').strip()
     if YngQWasBwxyUTJlIKvNVLMezXbmShi!=YngQWasBwxyUTJlIKvNVLMezXbmShc:
      fp.write(YngQWasBwxyUTJlIKvNVLMezXbmShE)
    fp.close()
   except:
    YngQWasBwxyUTJlIKvNVLMezXbmSEq
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiE): 
  try:
   if YngQWasBwxyUTJlIKvNVLMezXbmSiE=='search':
    YngQWasBwxyUTJlIKvNVLMezXbmShr=YngQWasBwxyUTJlIKvNVLMezXbmSoq
   elif YngQWasBwxyUTJlIKvNVLMezXbmSiE in['vod','movie']:
    YngQWasBwxyUTJlIKvNVLMezXbmShr=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%YngQWasBwxyUTJlIKvNVLMezXbmSiE))
   else:
    return[]
   fp=YngQWasBwxyUTJlIKvNVLMezXbmSEG(YngQWasBwxyUTJlIKvNVLMezXbmShr,'r',-1,'utf-8')
   YngQWasBwxyUTJlIKvNVLMezXbmShq=fp.readlines()
   fp.close()
  except:
   YngQWasBwxyUTJlIKvNVLMezXbmShq=[]
  return YngQWasBwxyUTJlIKvNVLMezXbmShq
 def Save_Watched_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiE,YngQWasBwxyUTJlIKvNVLMezXbmSok):
  try:
   YngQWasBwxyUTJlIKvNVLMezXbmShA=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%YngQWasBwxyUTJlIKvNVLMezXbmSiE))
   YngQWasBwxyUTJlIKvNVLMezXbmShf=YngQWasBwxyUTJlIKvNVLMezXbmSoA.Load_List_File(YngQWasBwxyUTJlIKvNVLMezXbmSiE) 
   fp=YngQWasBwxyUTJlIKvNVLMezXbmSEG(YngQWasBwxyUTJlIKvNVLMezXbmShA,'w',-1,'utf-8')
   YngQWasBwxyUTJlIKvNVLMezXbmShp=urllib.parse.urlencode(YngQWasBwxyUTJlIKvNVLMezXbmSok)
   YngQWasBwxyUTJlIKvNVLMezXbmShp=YngQWasBwxyUTJlIKvNVLMezXbmShp+'\n'
   fp.write(YngQWasBwxyUTJlIKvNVLMezXbmShp)
   YngQWasBwxyUTJlIKvNVLMezXbmShH=0
   for YngQWasBwxyUTJlIKvNVLMezXbmShE in YngQWasBwxyUTJlIKvNVLMezXbmShf:
    YngQWasBwxyUTJlIKvNVLMezXbmShO=YngQWasBwxyUTJlIKvNVLMezXbmSEj(urllib.parse.parse_qsl(YngQWasBwxyUTJlIKvNVLMezXbmShE))
    YngQWasBwxyUTJlIKvNVLMezXbmShk=YngQWasBwxyUTJlIKvNVLMezXbmSok.get('code').strip()
    YngQWasBwxyUTJlIKvNVLMezXbmShj=YngQWasBwxyUTJlIKvNVLMezXbmShO.get('code').strip()
    if YngQWasBwxyUTJlIKvNVLMezXbmSiE=='vod' and YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_settings_direct_replay()==YngQWasBwxyUTJlIKvNVLMezXbmSEp:
     YngQWasBwxyUTJlIKvNVLMezXbmShk=YngQWasBwxyUTJlIKvNVLMezXbmSok.get('videoid').strip()
     YngQWasBwxyUTJlIKvNVLMezXbmShj=YngQWasBwxyUTJlIKvNVLMezXbmShO.get('videoid').strip()if YngQWasBwxyUTJlIKvNVLMezXbmShj!=YngQWasBwxyUTJlIKvNVLMezXbmSEq else '-'
    if YngQWasBwxyUTJlIKvNVLMezXbmShk!=YngQWasBwxyUTJlIKvNVLMezXbmShj:
     fp.write(YngQWasBwxyUTJlIKvNVLMezXbmShE)
     YngQWasBwxyUTJlIKvNVLMezXbmShH+=1
     if YngQWasBwxyUTJlIKvNVLMezXbmShH>=50:break
   fp.close()
  except:
   YngQWasBwxyUTJlIKvNVLMezXbmSEq
 def dp_Watch_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSiE =YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('stype')
  YngQWasBwxyUTJlIKvNVLMezXbmSPE=YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_settings_direct_replay()
  if YngQWasBwxyUTJlIKvNVLMezXbmSiE=='-':
   for YngQWasBwxyUTJlIKvNVLMezXbmSic in YngQWasBwxyUTJlIKvNVLMezXbmSor:
    YngQWasBwxyUTJlIKvNVLMezXbmSPA=YngQWasBwxyUTJlIKvNVLMezXbmSic.get('title')
    YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':YngQWasBwxyUTJlIKvNVLMezXbmSic.get('mode'),'stype':YngQWasBwxyUTJlIKvNVLMezXbmSic.get('stype')}
    YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel='',img='',infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSEq,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEp,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
   if YngQWasBwxyUTJlIKvNVLMezXbmSEt(YngQWasBwxyUTJlIKvNVLMezXbmSor)>0:xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle)
  else:
   YngQWasBwxyUTJlIKvNVLMezXbmSht=YngQWasBwxyUTJlIKvNVLMezXbmSoA.Load_List_File(YngQWasBwxyUTJlIKvNVLMezXbmSiE)
   for YngQWasBwxyUTJlIKvNVLMezXbmShu in YngQWasBwxyUTJlIKvNVLMezXbmSht:
    YngQWasBwxyUTJlIKvNVLMezXbmSrR=YngQWasBwxyUTJlIKvNVLMezXbmSEj(urllib.parse.parse_qsl(YngQWasBwxyUTJlIKvNVLMezXbmShu))
    YngQWasBwxyUTJlIKvNVLMezXbmShR =YngQWasBwxyUTJlIKvNVLMezXbmSrR.get('code').strip()
    YngQWasBwxyUTJlIKvNVLMezXbmSPA =YngQWasBwxyUTJlIKvNVLMezXbmSrR.get('title').strip()
    YngQWasBwxyUTJlIKvNVLMezXbmSij=YngQWasBwxyUTJlIKvNVLMezXbmSrR.get('img').strip()
    YngQWasBwxyUTJlIKvNVLMezXbmSrD =YngQWasBwxyUTJlIKvNVLMezXbmSrR.get('videoid').strip()
    try:
     YngQWasBwxyUTJlIKvNVLMezXbmSij=YngQWasBwxyUTJlIKvNVLMezXbmSij.replace('\'','\"')
     YngQWasBwxyUTJlIKvNVLMezXbmSij=json.loads(YngQWasBwxyUTJlIKvNVLMezXbmSij)
    except:
     YngQWasBwxyUTJlIKvNVLMezXbmSEq
    YngQWasBwxyUTJlIKvNVLMezXbmSDP={}
    YngQWasBwxyUTJlIKvNVLMezXbmSDP['plot']=YngQWasBwxyUTJlIKvNVLMezXbmSPA
    if YngQWasBwxyUTJlIKvNVLMezXbmSiE=='vod':
     if YngQWasBwxyUTJlIKvNVLMezXbmSPE==YngQWasBwxyUTJlIKvNVLMezXbmSEH or YngQWasBwxyUTJlIKvNVLMezXbmSrD==YngQWasBwxyUTJlIKvNVLMezXbmSEq:
      YngQWasBwxyUTJlIKvNVLMezXbmSDP['mediatype']='tvshow'
      YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'EPISODE','programcode':YngQWasBwxyUTJlIKvNVLMezXbmShR,'page':'1'}
      YngQWasBwxyUTJlIKvNVLMezXbmSPG=YngQWasBwxyUTJlIKvNVLMezXbmSEp
     else:
      YngQWasBwxyUTJlIKvNVLMezXbmSDP['mediatype']='episode'
      YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'VOD','mediacode':YngQWasBwxyUTJlIKvNVLMezXbmSrD,'stype':'vod','programcode':YngQWasBwxyUTJlIKvNVLMezXbmShR,'title':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'thumbnail':YngQWasBwxyUTJlIKvNVLMezXbmSij}
      YngQWasBwxyUTJlIKvNVLMezXbmSPG=YngQWasBwxyUTJlIKvNVLMezXbmSEH
    else:
     YngQWasBwxyUTJlIKvNVLMezXbmSDP['mediatype']='movie'
     YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'MOVIE','mediacode':YngQWasBwxyUTJlIKvNVLMezXbmShR,'stype':'movie','title':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'thumbnail':YngQWasBwxyUTJlIKvNVLMezXbmSij}
     YngQWasBwxyUTJlIKvNVLMezXbmSPG=YngQWasBwxyUTJlIKvNVLMezXbmSEH
    YngQWasBwxyUTJlIKvNVLMezXbmSrF={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':YngQWasBwxyUTJlIKvNVLMezXbmShR,'vType':YngQWasBwxyUTJlIKvNVLMezXbmSiE,}
    YngQWasBwxyUTJlIKvNVLMezXbmSrd=urllib.parse.urlencode(YngQWasBwxyUTJlIKvNVLMezXbmSrF)
    YngQWasBwxyUTJlIKvNVLMezXbmSDp=[('선택된 시청이력 ( %s ) 삭제'%(YngQWasBwxyUTJlIKvNVLMezXbmSPA),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(YngQWasBwxyUTJlIKvNVLMezXbmSrd))]
    YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel='',img=YngQWasBwxyUTJlIKvNVLMezXbmSij,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSDP,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSPG,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR,ContextMenu=YngQWasBwxyUTJlIKvNVLMezXbmSDp)
   YngQWasBwxyUTJlIKvNVLMezXbmSDP={'plot':'시청목록을 삭제합니다.'}
   YngQWasBwxyUTJlIKvNVLMezXbmSPA='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':YngQWasBwxyUTJlIKvNVLMezXbmSiE,}
   YngQWasBwxyUTJlIKvNVLMezXbmSPu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel='',img=YngQWasBwxyUTJlIKvNVLMezXbmSPu,infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSDP,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEH,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR,isLink=YngQWasBwxyUTJlIKvNVLMezXbmSEp)
   if YngQWasBwxyUTJlIKvNVLMezXbmSiE=='movie':xbmcplugin.setContent(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,'movies')
   else:xbmcplugin.setContent(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,cacheToDisc=YngQWasBwxyUTJlIKvNVLMezXbmSEH)
 def Save_Searched_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSrq):
  try:
   YngQWasBwxyUTJlIKvNVLMezXbmShG=YngQWasBwxyUTJlIKvNVLMezXbmSoq
   YngQWasBwxyUTJlIKvNVLMezXbmShf=YngQWasBwxyUTJlIKvNVLMezXbmSoA.Load_List_File('search') 
   YngQWasBwxyUTJlIKvNVLMezXbmShF={'skey':YngQWasBwxyUTJlIKvNVLMezXbmSrq.strip()}
   fp=YngQWasBwxyUTJlIKvNVLMezXbmSEG(YngQWasBwxyUTJlIKvNVLMezXbmShG,'w',-1,'utf-8')
   YngQWasBwxyUTJlIKvNVLMezXbmShp=urllib.parse.urlencode(YngQWasBwxyUTJlIKvNVLMezXbmShF)
   YngQWasBwxyUTJlIKvNVLMezXbmShp=YngQWasBwxyUTJlIKvNVLMezXbmShp+'\n'
   fp.write(YngQWasBwxyUTJlIKvNVLMezXbmShp)
   YngQWasBwxyUTJlIKvNVLMezXbmShH=0
   for YngQWasBwxyUTJlIKvNVLMezXbmShE in YngQWasBwxyUTJlIKvNVLMezXbmShf:
    YngQWasBwxyUTJlIKvNVLMezXbmShO=YngQWasBwxyUTJlIKvNVLMezXbmSEj(urllib.parse.parse_qsl(YngQWasBwxyUTJlIKvNVLMezXbmShE))
    YngQWasBwxyUTJlIKvNVLMezXbmShk=YngQWasBwxyUTJlIKvNVLMezXbmShF.get('skey').strip()
    YngQWasBwxyUTJlIKvNVLMezXbmShj=YngQWasBwxyUTJlIKvNVLMezXbmShO.get('skey').strip()
    if YngQWasBwxyUTJlIKvNVLMezXbmShk!=YngQWasBwxyUTJlIKvNVLMezXbmShj:
     fp.write(YngQWasBwxyUTJlIKvNVLMezXbmShE)
     YngQWasBwxyUTJlIKvNVLMezXbmShH+=1
     if YngQWasBwxyUTJlIKvNVLMezXbmShH>=50:break
   fp.close()
  except:
   YngQWasBwxyUTJlIKvNVLMezXbmSEq
 def play_VIDEO(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmShd =YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('mediacode')
  YngQWasBwxyUTJlIKvNVLMezXbmSiE =YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('stype')
  YngQWasBwxyUTJlIKvNVLMezXbmShC =YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('pvrmode')
  YngQWasBwxyUTJlIKvNVLMezXbmSfo=YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_selQuality(YngQWasBwxyUTJlIKvNVLMezXbmSiE)
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(YngQWasBwxyUTJlIKvNVLMezXbmShd,YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSfo),YngQWasBwxyUTJlIKvNVLMezXbmSiE,YngQWasBwxyUTJlIKvNVLMezXbmShC))
  YngQWasBwxyUTJlIKvNVLMezXbmSfP=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.GetBroadURL(YngQWasBwxyUTJlIKvNVLMezXbmShd,YngQWasBwxyUTJlIKvNVLMezXbmSfo,YngQWasBwxyUTJlIKvNVLMezXbmSiE,YngQWasBwxyUTJlIKvNVLMezXbmShC,optUHD=YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_settings_uhd())
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.addon_log('qt, stype, url : %s - %s - %s'%(YngQWasBwxyUTJlIKvNVLMezXbmSEu(YngQWasBwxyUTJlIKvNVLMezXbmSfo),YngQWasBwxyUTJlIKvNVLMezXbmSiE,YngQWasBwxyUTJlIKvNVLMezXbmSfP['streaming_url']))
  if YngQWasBwxyUTJlIKvNVLMezXbmSfP['streaming_url']=='':
   if YngQWasBwxyUTJlIKvNVLMezXbmSfP['error_msg']=='':
    YngQWasBwxyUTJlIKvNVLMezXbmSoA.addon_noti(__language__(30908).encode('utf8'))
   else:
    YngQWasBwxyUTJlIKvNVLMezXbmSoA.addon_noti(YngQWasBwxyUTJlIKvNVLMezXbmSfP['error_msg'].encode('utf8'))
   return
  YngQWasBwxyUTJlIKvNVLMezXbmSfi='user-agent={}'.format(YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.USER_AGENT)
  if YngQWasBwxyUTJlIKvNVLMezXbmSfP['watermark'] !='':
   YngQWasBwxyUTJlIKvNVLMezXbmSfi='{}&x-tving-param1={}&x-tving-param2={}'.format(YngQWasBwxyUTJlIKvNVLMezXbmSfi,YngQWasBwxyUTJlIKvNVLMezXbmSfP['watermarkKey'],YngQWasBwxyUTJlIKvNVLMezXbmSfP['watermark'])
  YngQWasBwxyUTJlIKvNVLMezXbmSfD =YngQWasBwxyUTJlIKvNVLMezXbmSEH
  YngQWasBwxyUTJlIKvNVLMezXbmSfr =YngQWasBwxyUTJlIKvNVLMezXbmSfP['streaming_url'].find('Policy=')
  if YngQWasBwxyUTJlIKvNVLMezXbmSfr!=-1:
   YngQWasBwxyUTJlIKvNVLMezXbmSfh =YngQWasBwxyUTJlIKvNVLMezXbmSfP['streaming_url'].split('?')[0]
   YngQWasBwxyUTJlIKvNVLMezXbmSfE=YngQWasBwxyUTJlIKvNVLMezXbmSEj(urllib.parse.parse_qsl(urllib.parse.urlsplit(YngQWasBwxyUTJlIKvNVLMezXbmSfP['streaming_url']).query))
   YngQWasBwxyUTJlIKvNVLMezXbmSfO='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(YngQWasBwxyUTJlIKvNVLMezXbmSfE['Policy'],YngQWasBwxyUTJlIKvNVLMezXbmSfE['Signature'],YngQWasBwxyUTJlIKvNVLMezXbmSfE['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in YngQWasBwxyUTJlIKvNVLMezXbmSfh:
    YngQWasBwxyUTJlIKvNVLMezXbmSfD=YngQWasBwxyUTJlIKvNVLMezXbmSEp
    YngQWasBwxyUTJlIKvNVLMezXbmSfc =YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    YngQWasBwxyUTJlIKvNVLMezXbmSfq=YngQWasBwxyUTJlIKvNVLMezXbmSfc.strftime('%Y-%m-%d-%H:%M:%S')
    if YngQWasBwxyUTJlIKvNVLMezXbmSEA(YngQWasBwxyUTJlIKvNVLMezXbmSfq.replace('-','').replace(':',''))<YngQWasBwxyUTJlIKvNVLMezXbmSEA(YngQWasBwxyUTJlIKvNVLMezXbmSfE['end'].replace('-','').replace(':','')):
     YngQWasBwxyUTJlIKvNVLMezXbmSfE['end']=YngQWasBwxyUTJlIKvNVLMezXbmSfq
     YngQWasBwxyUTJlIKvNVLMezXbmSoA.addon_noti(__language__(30915).encode('utf8'))
    YngQWasBwxyUTJlIKvNVLMezXbmSfh ='%s?%s'%(YngQWasBwxyUTJlIKvNVLMezXbmSfh,urllib.parse.urlencode(YngQWasBwxyUTJlIKvNVLMezXbmSfE,doseq=YngQWasBwxyUTJlIKvNVLMezXbmSEp))
   YngQWasBwxyUTJlIKvNVLMezXbmSfA='{}|{}&Cookie={}'.format(YngQWasBwxyUTJlIKvNVLMezXbmSfh,YngQWasBwxyUTJlIKvNVLMezXbmSfi,YngQWasBwxyUTJlIKvNVLMezXbmSfO)
  else:
   YngQWasBwxyUTJlIKvNVLMezXbmSfA=YngQWasBwxyUTJlIKvNVLMezXbmSfP['streaming_url']+'|'+YngQWasBwxyUTJlIKvNVLMezXbmSfi
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.addon_log('if tmp_pos == -1')
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.addon_log(YngQWasBwxyUTJlIKvNVLMezXbmSfA)
  YngQWasBwxyUTJlIKvNVLMezXbmSfp=xbmcgui.ListItem(path=YngQWasBwxyUTJlIKvNVLMezXbmSfA)
  if YngQWasBwxyUTJlIKvNVLMezXbmSfP['drm_license']!='':
   YngQWasBwxyUTJlIKvNVLMezXbmSfH=YngQWasBwxyUTJlIKvNVLMezXbmSfP['drm_license']
   YngQWasBwxyUTJlIKvNVLMezXbmSfk ='https://cj.drmkeyserver.com/widevine_license'
   YngQWasBwxyUTJlIKvNVLMezXbmSfj ='mpd'
   YngQWasBwxyUTJlIKvNVLMezXbmSft ='com.widevine.alpha'
   YngQWasBwxyUTJlIKvNVLMezXbmSfu =inputstreamhelper.Helper(YngQWasBwxyUTJlIKvNVLMezXbmSfj,drm='widevine')
   if YngQWasBwxyUTJlIKvNVLMezXbmSfu.check_inputstream():
    YngQWasBwxyUTJlIKvNVLMezXbmSfR={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.USER_AGENT,'AcquireLicenseAssertion':YngQWasBwxyUTJlIKvNVLMezXbmSfH,'Host':'cj.drmkeyserver.com',}
    YngQWasBwxyUTJlIKvNVLMezXbmSfG=YngQWasBwxyUTJlIKvNVLMezXbmSfk+'|'+urllib.parse.urlencode(YngQWasBwxyUTJlIKvNVLMezXbmSfR)+'|R{SSM}|'
    YngQWasBwxyUTJlIKvNVLMezXbmSfp.setProperty('inputstream',YngQWasBwxyUTJlIKvNVLMezXbmSfu.inputstream_addon)
    YngQWasBwxyUTJlIKvNVLMezXbmSfp.setProperty('inputstream.adaptive.manifest_type',YngQWasBwxyUTJlIKvNVLMezXbmSfj)
    YngQWasBwxyUTJlIKvNVLMezXbmSfp.setProperty('inputstream.adaptive.license_type',YngQWasBwxyUTJlIKvNVLMezXbmSft)
    YngQWasBwxyUTJlIKvNVLMezXbmSfp.setProperty('inputstream.adaptive.license_key',YngQWasBwxyUTJlIKvNVLMezXbmSfG)
    YngQWasBwxyUTJlIKvNVLMezXbmSfp.setProperty('inputstream.adaptive.stream_headers',YngQWasBwxyUTJlIKvNVLMezXbmSfi)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSfD==YngQWasBwxyUTJlIKvNVLMezXbmSEp:
   YngQWasBwxyUTJlIKvNVLMezXbmSfp.setContentLookup(YngQWasBwxyUTJlIKvNVLMezXbmSEH)
   YngQWasBwxyUTJlIKvNVLMezXbmSfp.setMimeType('application/x-mpegURL')
   YngQWasBwxyUTJlIKvNVLMezXbmSfp.setProperty('inputstream','inputstream.ffmpegdirect')
   YngQWasBwxyUTJlIKvNVLMezXbmSfp.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   YngQWasBwxyUTJlIKvNVLMezXbmSfp.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   YngQWasBwxyUTJlIKvNVLMezXbmSfp.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   YngQWasBwxyUTJlIKvNVLMezXbmSfp.setProperty('ResumeTime','0')
   YngQWasBwxyUTJlIKvNVLMezXbmSfp.setProperty('TotalTime','10000')
  elif YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('mode')in['VOD','MOVIE']:
   YngQWasBwxyUTJlIKvNVLMezXbmSfp.setContentLookup(YngQWasBwxyUTJlIKvNVLMezXbmSEH)
   YngQWasBwxyUTJlIKvNVLMezXbmSfp.setMimeType('application/x-mpegURL')
   YngQWasBwxyUTJlIKvNVLMezXbmSfp.setProperty('inputstream','inputstream.adaptive')
   YngQWasBwxyUTJlIKvNVLMezXbmSfp.setProperty('inputstream.adaptive.manifest_type','hls')
  xbmcplugin.setResolvedUrl(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,YngQWasBwxyUTJlIKvNVLMezXbmSEp,YngQWasBwxyUTJlIKvNVLMezXbmSfp)
  try:
   if YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('mode')in['VOD','MOVIE']and YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('title'):
    YngQWasBwxyUTJlIKvNVLMezXbmSPR={'code':YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('programcode')if YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('mode')=='VOD' else YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('mediacode'),'img':YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('thumbnail'),'title':YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('title'),'videoid':YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('mediacode')}
    YngQWasBwxyUTJlIKvNVLMezXbmSoA.Save_Watched_List(YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('stype'),YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  except:
   YngQWasBwxyUTJlIKvNVLMezXbmSEq
 def logout(YngQWasBwxyUTJlIKvNVLMezXbmSoA):
  YngQWasBwxyUTJlIKvNVLMezXbmSot=xbmcgui.Dialog()
  YngQWasBwxyUTJlIKvNVLMezXbmSir=YngQWasBwxyUTJlIKvNVLMezXbmSot.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if YngQWasBwxyUTJlIKvNVLMezXbmSir==YngQWasBwxyUTJlIKvNVLMezXbmSEH:sys.exit()
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.Init_TV_Total()
  if os.path.isfile(YngQWasBwxyUTJlIKvNVLMezXbmSoc):os.remove(YngQWasBwxyUTJlIKvNVLMezXbmSoc)
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(YngQWasBwxyUTJlIKvNVLMezXbmSoA):
  YngQWasBwxyUTJlIKvNVLMezXbmSfF =YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.Get_Now_Datetime()
  YngQWasBwxyUTJlIKvNVLMezXbmSfd=YngQWasBwxyUTJlIKvNVLMezXbmSfF+datetime.timedelta(days=YngQWasBwxyUTJlIKvNVLMezXbmSEA(__addon__.getSetting('cache_ttl')))
  (YngQWasBwxyUTJlIKvNVLMezXbmSPC,YngQWasBwxyUTJlIKvNVLMezXbmSio,YngQWasBwxyUTJlIKvNVLMezXbmSiP,YngQWasBwxyUTJlIKvNVLMezXbmSiD)=YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_settings_account()
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.Save_session_acount(YngQWasBwxyUTJlIKvNVLMezXbmSPC,YngQWasBwxyUTJlIKvNVLMezXbmSio,YngQWasBwxyUTJlIKvNVLMezXbmSiP,YngQWasBwxyUTJlIKvNVLMezXbmSiD)
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.TV['account']['token_limit']=YngQWasBwxyUTJlIKvNVLMezXbmSfd.strftime('%Y%m%d')
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.JsonFile_Save(YngQWasBwxyUTJlIKvNVLMezXbmSoc,YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.TV)
 def cookiefile_check(YngQWasBwxyUTJlIKvNVLMezXbmSoA):
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.TV=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.JsonFile_Load(YngQWasBwxyUTJlIKvNVLMezXbmSoc)
  if 'account' not in YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.TV:
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.Init_TV_Total()
   return YngQWasBwxyUTJlIKvNVLMezXbmSEH
  (YngQWasBwxyUTJlIKvNVLMezXbmSfC,YngQWasBwxyUTJlIKvNVLMezXbmSEo,YngQWasBwxyUTJlIKvNVLMezXbmSEP,YngQWasBwxyUTJlIKvNVLMezXbmSEi)=YngQWasBwxyUTJlIKvNVLMezXbmSoA.get_settings_account()
  (YngQWasBwxyUTJlIKvNVLMezXbmSED,YngQWasBwxyUTJlIKvNVLMezXbmSEr,YngQWasBwxyUTJlIKvNVLMezXbmSEh,YngQWasBwxyUTJlIKvNVLMezXbmSEf)=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.Load_session_acount()
  if YngQWasBwxyUTJlIKvNVLMezXbmSfC!=YngQWasBwxyUTJlIKvNVLMezXbmSED or YngQWasBwxyUTJlIKvNVLMezXbmSEo!=YngQWasBwxyUTJlIKvNVLMezXbmSEr or YngQWasBwxyUTJlIKvNVLMezXbmSEP!=YngQWasBwxyUTJlIKvNVLMezXbmSEh or YngQWasBwxyUTJlIKvNVLMezXbmSEi!=YngQWasBwxyUTJlIKvNVLMezXbmSEf:
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.Init_TV_Total()
   return YngQWasBwxyUTJlIKvNVLMezXbmSEH
  if YngQWasBwxyUTJlIKvNVLMezXbmSEA(YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>YngQWasBwxyUTJlIKvNVLMezXbmSEA(YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.TV['account']['token_limit']):
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.Init_TV_Total()
   return YngQWasBwxyUTJlIKvNVLMezXbmSEH
  return YngQWasBwxyUTJlIKvNVLMezXbmSEp
 def dp_Global_Search(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSrA=YngQWasBwxyUTJlIKvNVLMezXbmSiq.get('mode')
  if YngQWasBwxyUTJlIKvNVLMezXbmSrA=='TOTAL_SEARCH':
   YngQWasBwxyUTJlIKvNVLMezXbmSEO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   YngQWasBwxyUTJlIKvNVLMezXbmSEO='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(YngQWasBwxyUTJlIKvNVLMezXbmSEO)
 def dp_Bookmark_Menu(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSEO='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(YngQWasBwxyUTJlIKvNVLMezXbmSEO)
 def dp_EuroLive_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA,YngQWasBwxyUTJlIKvNVLMezXbmSiq):
  YngQWasBwxyUTJlIKvNVLMezXbmSip=YngQWasBwxyUTJlIKvNVLMezXbmSoA.TvingObj.GetEuroChannelList()
  for YngQWasBwxyUTJlIKvNVLMezXbmSik in YngQWasBwxyUTJlIKvNVLMezXbmSip:
   YngQWasBwxyUTJlIKvNVLMezXbmSDO =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('channel')
   YngQWasBwxyUTJlIKvNVLMezXbmSPA =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('title')
   YngQWasBwxyUTJlIKvNVLMezXbmSDi =YngQWasBwxyUTJlIKvNVLMezXbmSik.get('subtitle')
   YngQWasBwxyUTJlIKvNVLMezXbmSDP={'mediatype':'episode','title':YngQWasBwxyUTJlIKvNVLMezXbmSPA,'plot':'%s\n%s'%(YngQWasBwxyUTJlIKvNVLMezXbmSPA,YngQWasBwxyUTJlIKvNVLMezXbmSDi)}
   YngQWasBwxyUTJlIKvNVLMezXbmSPR={'mode':'LIVE','mediacode':YngQWasBwxyUTJlIKvNVLMezXbmSDO,'stype':'onair',}
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.add_dir(YngQWasBwxyUTJlIKvNVLMezXbmSPA,sublabel=YngQWasBwxyUTJlIKvNVLMezXbmSDi,img='',infoLabels=YngQWasBwxyUTJlIKvNVLMezXbmSDP,isFolder=YngQWasBwxyUTJlIKvNVLMezXbmSEH,params=YngQWasBwxyUTJlIKvNVLMezXbmSPR)
  if YngQWasBwxyUTJlIKvNVLMezXbmSEt(YngQWasBwxyUTJlIKvNVLMezXbmSip)>0:xbmcplugin.endOfDirectory(YngQWasBwxyUTJlIKvNVLMezXbmSoA._addon_handle,cacheToDisc=YngQWasBwxyUTJlIKvNVLMezXbmSEH)
 def tving_main(YngQWasBwxyUTJlIKvNVLMezXbmSoA):
  YngQWasBwxyUTJlIKvNVLMezXbmSrA=YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params.get('mode',YngQWasBwxyUTJlIKvNVLMezXbmSEq)
  if YngQWasBwxyUTJlIKvNVLMezXbmSrA=='LOGOUT':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.logout()
   return
  YngQWasBwxyUTJlIKvNVLMezXbmSoA.login_main()
  if YngQWasBwxyUTJlIKvNVLMezXbmSrA is YngQWasBwxyUTJlIKvNVLMezXbmSEq:
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_Main_List()
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_Title_Group(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA in['GLOBAL_GROUP']:
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_SubTitle_Group(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='CHANNEL':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_LiveChannel_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA in['LIVE','VOD','MOVIE']:
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.play_VIDEO(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='PROGRAM':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_Program_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='4K_PROGRAM':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_4K_Program_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='ORI_PROGRAM':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_Ori_Program_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='EPISODE':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_Episode_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='MOVIE_SUB':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_Movie_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='4K_MOVIE':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_4K_Movie_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='SEARCH_GROUP':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_Search_Group(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA in['SEARCH','LOCAL_SEARCH']:
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_Search_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='WATCH':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_Watch_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_History_Remove(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='ORDER_BY':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_setEpOrderby(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='SET_BOOKMARK':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_Set_Bookmark(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA in['TOTAL_SEARCH','TOTAL_HISTORY']:
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_Global_Search(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='SEARCH_HISTORY':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_Search_History(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='MENU_BOOKMARK':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_Bookmark_Menu(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  elif YngQWasBwxyUTJlIKvNVLMezXbmSrA=='EURO_GROUP':
   YngQWasBwxyUTJlIKvNVLMezXbmSoA.dp_EuroLive_List(YngQWasBwxyUTJlIKvNVLMezXbmSoA.main_params)
  else:
   YngQWasBwxyUTJlIKvNVLMezXbmSEq
# Created by pyminifier (https://github.com/liftoff/pyminifier)
