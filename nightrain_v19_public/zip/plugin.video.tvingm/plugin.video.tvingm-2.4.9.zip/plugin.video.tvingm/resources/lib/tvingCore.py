__author__="NightRain"
elgFhPaAOJiLKuGEYxQcCpNfIVnRUk=print
elgFhPaAOJiLKuGEYxQcCpNfIVnRUs=ImportError
elgFhPaAOJiLKuGEYxQcCpNfIVnRUy=object
elgFhPaAOJiLKuGEYxQcCpNfIVnRUX=None
elgFhPaAOJiLKuGEYxQcCpNfIVnRUD=False
elgFhPaAOJiLKuGEYxQcCpNfIVnRUt=open
elgFhPaAOJiLKuGEYxQcCpNfIVnRUT=True
elgFhPaAOJiLKuGEYxQcCpNfIVnRUm=int
elgFhPaAOJiLKuGEYxQcCpNfIVnRUr=range
elgFhPaAOJiLKuGEYxQcCpNfIVnRUH=Exception
elgFhPaAOJiLKuGEYxQcCpNfIVnRUb=len
elgFhPaAOJiLKuGEYxQcCpNfIVnRUo=str
elgFhPaAOJiLKuGEYxQcCpNfIVnRUd=list
elgFhPaAOJiLKuGEYxQcCpNfIVnRUq=bytes
elgFhPaAOJiLKuGEYxQcCpNfIVnRWw=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 elgFhPaAOJiLKuGEYxQcCpNfIVnRUk('Cryptodome')
except elgFhPaAOJiLKuGEYxQcCpNfIVnRUs:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 elgFhPaAOJiLKuGEYxQcCpNfIVnRUk('Crypto')
elgFhPaAOJiLKuGEYxQcCpNfIVnRwB={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
elgFhPaAOJiLKuGEYxQcCpNfIVnRwM ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class elgFhPaAOJiLKuGEYxQcCpNfIVnRwv(elgFhPaAOJiLKuGEYxQcCpNfIVnRUy):
 def __init__(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.NETWORKCODE ='CSND0900'
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.OSCODE ='CSOD0900' 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TELECODE ='CSCD0900'
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.SCREENCODE ='CSSD0100'
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.SCREENCODE_ATV ='CSSD1300' 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.LIVE_LIMIT =20 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.VOD_LIMIT =24 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.EPISODE_LIMIT =30 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.SEARCH_LIMIT =30 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.MOVIE_LIMIT =24 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN ='https://api.tving.com'
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN ='https://image.tving.com'
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.SEARCH_DOMAIN ='https://search.tving.com'
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.LOGIN_DOMAIN ='https://user.tving.com'
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.URL_DOMAIN ='https://www.tving.com'
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.MOVIE_LITE =['2610061','2610161','261062']
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.DEFAULT_HEADER ={'user-agent':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.USER_AGENT}
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV_SESSION_COOKIES1=''
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV_SESSION_COOKIES2=''
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV ={}
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.Init_TV_Total()
 def Init_TV_Total(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N',},}
 def callRequestCookies(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,jobtype,elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,redirects=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwU=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.DEFAULT_HEADER
  if headers:elgFhPaAOJiLKuGEYxQcCpNfIVnRwU.update(headers)
  if jobtype=='Get':
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwW=requests.get(elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,params=params,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRwU,cookies=cookies,allow_redirects=redirects)
  else:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwW=requests.post(elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,data=payload,params=params,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRwU,cookies=cookies,allow_redirects=redirects)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRwW
 def JsonFile_Save(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,filename,elgFhPaAOJiLKuGEYxQcCpNfIVnRwS):
  if filename=='':return elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  try:
   fp=elgFhPaAOJiLKuGEYxQcCpNfIVnRUt(filename,'w',-1,'utf-8')
   json.dump(elgFhPaAOJiLKuGEYxQcCpNfIVnRwS,fp,indent=4,ensure_ascii=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD)
   fp.close()
  except:
   return elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRUT
 def JsonFile_Load(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,filename):
  if filename=='':return{}
  try:
   fp=elgFhPaAOJiLKuGEYxQcCpNfIVnRUt(filename,'r',-1,'utf-8')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwk=json.load(fp)
   fp.close()
  except:
   return{}
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRwk
 def Save_session_acount(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,elgFhPaAOJiLKuGEYxQcCpNfIVnRws,elgFhPaAOJiLKuGEYxQcCpNfIVnRwy,elgFhPaAOJiLKuGEYxQcCpNfIVnRwX,elgFhPaAOJiLKuGEYxQcCpNfIVnRwD):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['account']['tvid'] =base64.standard_b64encode(elgFhPaAOJiLKuGEYxQcCpNfIVnRws.encode()).decode('utf-8')
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['account']['tvpw'] =base64.standard_b64encode(elgFhPaAOJiLKuGEYxQcCpNfIVnRwy.encode()).decode('utf-8')
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['account']['tvtype']=elgFhPaAOJiLKuGEYxQcCpNfIVnRwX 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['account']['tvpf'] =elgFhPaAOJiLKuGEYxQcCpNfIVnRwD 
 def Load_session_acount(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj):
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRws =base64.standard_b64decode(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['account']['tvid']).decode('utf-8')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwy =base64.standard_b64decode(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['account']['tvpw']).decode('utf-8')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwX=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['account']['tvtype']
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwD =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRws,elgFhPaAOJiLKuGEYxQcCpNfIVnRwy,elgFhPaAOJiLKuGEYxQcCpNfIVnRwX,elgFhPaAOJiLKuGEYxQcCpNfIVnRwD
 def makeDefaultCookies(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwt={}
  if elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_token']:elgFhPaAOJiLKuGEYxQcCpNfIVnRwt['_tving_token']=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_token']
  if elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_userinfo']:elgFhPaAOJiLKuGEYxQcCpNfIVnRwt['POC_USERINFO']=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_userinfo']
  if elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_maintoken']:elgFhPaAOJiLKuGEYxQcCpNfIVnRwt[elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GLOBAL_COOKIENM['tv_maintoken']]=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_maintoken']
  if elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_cookiekey']:elgFhPaAOJiLKuGEYxQcCpNfIVnRwt[elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GLOBAL_COOKIENM['tv_cookiekey']]=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_cookiekey']
  if elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_lockkey']:elgFhPaAOJiLKuGEYxQcCpNfIVnRwt[elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GLOBAL_COOKIENM['tv_lockkey']]=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_lockkey']
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRwt
 def getDeviceStr(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwT=[]
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwT.append('Windows') 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwT.append('Chrome') 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwT.append('ko-KR') 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwT.append('undefined') 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwT.append('24') 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwT.append(u'한국 표준시')
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwT.append('undefined') 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwT.append('undefined') 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwT.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  elgFhPaAOJiLKuGEYxQcCpNfIVnRwm=''
  for elgFhPaAOJiLKuGEYxQcCpNfIVnRwr in elgFhPaAOJiLKuGEYxQcCpNfIVnRwT:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwm+=elgFhPaAOJiLKuGEYxQcCpNfIVnRwr+'|'
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRwm
 def GetDefaultParams(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,uhd=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD):
  if uhd==elgFhPaAOJiLKuGEYxQcCpNfIVnRUD:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwH={'apiKey':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.APIKEY,'networkCode':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.NETWORKCODE,'osCode':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.OSCODE,'teleCode':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TELECODE,'screenCode':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.SCREENCODE,}
  else:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwH={'apiKey':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.APIKEY_ATV,'networkCode':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.NETWORKCODE,'osCode':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.OSCODE,'teleCode':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TELECODE,'screenCode':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.SCREENCODE_ATV,}
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRwH
 def GetNoCache(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,timetype=1):
  if timetype==1:
   return elgFhPaAOJiLKuGEYxQcCpNfIVnRUm(time.time())
  else:
   return elgFhPaAOJiLKuGEYxQcCpNfIVnRUm(time.time()*1000)
 def GetUniqueid(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,hValue=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX):
  if hValue:
   import hashlib
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwb=hashlib.sha1()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwb.update(hValue.encode())
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwo=elgFhPaAOJiLKuGEYxQcCpNfIVnRwb.hexdigest()[:8]
  else:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwd=[0 for i in elgFhPaAOJiLKuGEYxQcCpNfIVnRUr(256)]
   for i in elgFhPaAOJiLKuGEYxQcCpNfIVnRUr(256):
    elgFhPaAOJiLKuGEYxQcCpNfIVnRwd[i]='%02x'%(i)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwq=elgFhPaAOJiLKuGEYxQcCpNfIVnRUm(4294967295*random.random())|0
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwo=elgFhPaAOJiLKuGEYxQcCpNfIVnRwd[255&elgFhPaAOJiLKuGEYxQcCpNfIVnRwq]+elgFhPaAOJiLKuGEYxQcCpNfIVnRwd[elgFhPaAOJiLKuGEYxQcCpNfIVnRwq>>8&255]+elgFhPaAOJiLKuGEYxQcCpNfIVnRwd[elgFhPaAOJiLKuGEYxQcCpNfIVnRwq>>16&255]+elgFhPaAOJiLKuGEYxQcCpNfIVnRwd[elgFhPaAOJiLKuGEYxQcCpNfIVnRwq>>24&255]
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRwo
 def GetCredential(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,user_id,user_pw,login_type,user_pf):
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvw=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvB={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Post',elgFhPaAOJiLKuGEYxQcCpNfIVnRvw,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRvB,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX)
   for elgFhPaAOJiLKuGEYxQcCpNfIVnRvj in elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.cookies:
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRvj.name=='_tving_token':
     elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_token']=elgFhPaAOJiLKuGEYxQcCpNfIVnRvj.value
    elif elgFhPaAOJiLKuGEYxQcCpNfIVnRvj.name=='POC_USERINFO':
     elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_userinfo']=elgFhPaAOJiLKuGEYxQcCpNfIVnRvj.value
   if not elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_token']:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.Init_TV_Total()
    return elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_maintoken']=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_token']
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetProfileToken(user_pf)==elgFhPaAOJiLKuGEYxQcCpNfIVnRUD:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.Init_TV_Total()
    return elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvU =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDeviceList()
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRvU not in['','-']:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_uuid']=elgFhPaAOJiLKuGEYxQcCpNfIVnRvU+'-'+elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetUniqueid(elgFhPaAOJiLKuGEYxQcCpNfIVnRvU)
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.Init_TV_Total()
   return elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRUT
 def GetProfileToken(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,user_pf):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvW=[]
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvS =''
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwt=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.makeDefaultCookies()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvz,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRwt)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvW =re.findall('data-profile-no="\d+"',elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   for i in elgFhPaAOJiLKuGEYxQcCpNfIVnRUr(elgFhPaAOJiLKuGEYxQcCpNfIVnRUb(elgFhPaAOJiLKuGEYxQcCpNfIVnRvW)):
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvk =elgFhPaAOJiLKuGEYxQcCpNfIVnRvW[i].replace('data-profile-no=','').replace('"','')
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvW[i]=elgFhPaAOJiLKuGEYxQcCpNfIVnRvk
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvS=elgFhPaAOJiLKuGEYxQcCpNfIVnRvW[user_pf]
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.Init_TV_Total()
   return elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwt=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.makeDefaultCookies()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvB={'profileNo':elgFhPaAOJiLKuGEYxQcCpNfIVnRvS}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Post',elgFhPaAOJiLKuGEYxQcCpNfIVnRvz,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRvB,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRwt)
   for elgFhPaAOJiLKuGEYxQcCpNfIVnRvj in elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.cookies:
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRvj.name=='_tving_token':
     elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_token']=elgFhPaAOJiLKuGEYxQcCpNfIVnRvj.value
    elif elgFhPaAOJiLKuGEYxQcCpNfIVnRvj.name==elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GLOBAL_COOKIENM['tv_cookiekey']:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_cookiekey']=elgFhPaAOJiLKuGEYxQcCpNfIVnRvj.value
    elif elgFhPaAOJiLKuGEYxQcCpNfIVnRvj.name==elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GLOBAL_COOKIENM['tv_lockkey']:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_lockkey']=elgFhPaAOJiLKuGEYxQcCpNfIVnRvj.value
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.Init_TV_Total()
   return elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRUT
 def GetDeviceList(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvs=[]
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvy='-'
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v1/user/device/list'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvX=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvz
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwt=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.makeDefaultCookies()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvX,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvD,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRwt)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvt=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvs=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']
   for elgFhPaAOJiLKuGEYxQcCpNfIVnRvT in elgFhPaAOJiLKuGEYxQcCpNfIVnRvs:
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['model']=='PC' or elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['model']=='PC-Chrome':
     elgFhPaAOJiLKuGEYxQcCpNfIVnRvy=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['uuid']
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRvy
 def Get_Now_Datetime(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,mediacode,sel_quality,stype,pvrmode='-',optUHD=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvr ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','error_msg':'',}
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvy =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_uuid'].split('-')[0] 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvH =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_uuid'] 
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvb=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD 
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvo=elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetNoCache(1))
   if stype!='tvingtv':
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v2/media/stream/info' 
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams()
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':elgFhPaAOJiLKuGEYxQcCpNfIVnRvH,'deviceInfo':'PC','noCache':elgFhPaAOJiLKuGEYxQcCpNfIVnRvo,}
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvd.update(elgFhPaAOJiLKuGEYxQcCpNfIVnRvD)
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvz
    elgFhPaAOJiLKuGEYxQcCpNfIVnRwt=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.makeDefaultCookies()
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvd,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRwt)
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.status_code!=200:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRvr['error_msg']='First Step - {} error'.format(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.status_code)
     return elgFhPaAOJiLKuGEYxQcCpNfIVnRvr
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvt=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['result']['code']=='060':
     for elgFhPaAOJiLKuGEYxQcCpNfIVnRBw,elgFhPaAOJiLKuGEYxQcCpNfIVnRBy in elgFhPaAOJiLKuGEYxQcCpNfIVnRwB.items():
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRBy==sel_quality:
       elgFhPaAOJiLKuGEYxQcCpNfIVnRBv=elgFhPaAOJiLKuGEYxQcCpNfIVnRBw
    elif elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['result']['code']!='000':
     elgFhPaAOJiLKuGEYxQcCpNfIVnRvr['error_msg']=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['result']['message']
     return elgFhPaAOJiLKuGEYxQcCpNfIVnRvr
    else: 
     if not('stream' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']):return elgFhPaAOJiLKuGEYxQcCpNfIVnRvr
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBM=[]
     for elgFhPaAOJiLKuGEYxQcCpNfIVnRBw,elgFhPaAOJiLKuGEYxQcCpNfIVnRBy in elgFhPaAOJiLKuGEYxQcCpNfIVnRwB.items():
      for elgFhPaAOJiLKuGEYxQcCpNfIVnRvT in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['stream']['quality']:
       if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['active']=='Y' and elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['code']==elgFhPaAOJiLKuGEYxQcCpNfIVnRBw:
        elgFhPaAOJiLKuGEYxQcCpNfIVnRBM.append({elgFhPaAOJiLKuGEYxQcCpNfIVnRwB.get(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['code']):elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['code']})
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBv=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.CheckQuality(sel_quality,elgFhPaAOJiLKuGEYxQcCpNfIVnRBM)
     try:
      if optUHD==elgFhPaAOJiLKuGEYxQcCpNfIVnRUT and elgFhPaAOJiLKuGEYxQcCpNfIVnRBv=='stream50' and 'stream_support_info' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['content']['info']:
       if elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['content']['info']['stream_support_info']!=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX:
        if 'stream70' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['content']['info']['stream_support_info']:
         elgFhPaAOJiLKuGEYxQcCpNfIVnRBv='stream70'
         elgFhPaAOJiLKuGEYxQcCpNfIVnRvb =elgFhPaAOJiLKuGEYxQcCpNfIVnRUT
     except:
      pass
     try:
      if optUHD==elgFhPaAOJiLKuGEYxQcCpNfIVnRUT and elgFhPaAOJiLKuGEYxQcCpNfIVnRBv=='stream50' and 'stream' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['content']['info']:
       if elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['content']['info']['stream']!=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX:
        for elgFhPaAOJiLKuGEYxQcCpNfIVnRvT in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['content']['info']['stream']:
         if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['code']=='stream70':
          elgFhPaAOJiLKuGEYxQcCpNfIVnRBv='stream70'
          elgFhPaAOJiLKuGEYxQcCpNfIVnRvb =elgFhPaAOJiLKuGEYxQcCpNfIVnRUT
          break
     except:
      pass
   else:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBv='stream40'
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvr['error_msg']='First Step - except error'
   return elgFhPaAOJiLKuGEYxQcCpNfIVnRvr
  elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(elgFhPaAOJiLKuGEYxQcCpNfIVnRBv)
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvo=elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetNoCache(1))
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v2a/media/stream/info'
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRvb==elgFhPaAOJiLKuGEYxQcCpNfIVnRUT:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams(uhd=elgFhPaAOJiLKuGEYxQcCpNfIVnRUT)
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'mediaCode':mediacode,'noCache':elgFhPaAOJiLKuGEYxQcCpNfIVnRvo,'streamType':'hls','streamCode':elgFhPaAOJiLKuGEYxQcCpNfIVnRBv,'deviceId':elgFhPaAOJiLKuGEYxQcCpNfIVnRvy,'adReq':'none','wm':'Y','ad_device':'','uuid':elgFhPaAOJiLKuGEYxQcCpNfIVnRvH,'deviceInfo':'android_tv',}
   else:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams()
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':elgFhPaAOJiLKuGEYxQcCpNfIVnRBv,'deviceId':elgFhPaAOJiLKuGEYxQcCpNfIVnRvy,'uuid':elgFhPaAOJiLKuGEYxQcCpNfIVnRvH,'deviceInfo':'PC_Chrome','noCache':elgFhPaAOJiLKuGEYxQcCpNfIVnRvo,'wm':'Y'}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd.update(elgFhPaAOJiLKuGEYxQcCpNfIVnRvD)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvz
   elgFhPaAOJiLKuGEYxQcCpNfIVnRwt=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.makeDefaultCookies()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvd,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRwt,redirects=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvt=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['result']['code']!='000':
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvr['error_msg']=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['result']['message']
    return elgFhPaAOJiLKuGEYxQcCpNfIVnRvr
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBj=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['stream']
   if 'drm_license_assertion' in elgFhPaAOJiLKuGEYxQcCpNfIVnRBj:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvr['drm_license']=elgFhPaAOJiLKuGEYxQcCpNfIVnRBj['drm_license_assertion']
    if '4k_nondrm_url' in elgFhPaAOJiLKuGEYxQcCpNfIVnRBj['broadcast']and elgFhPaAOJiLKuGEYxQcCpNfIVnRvb==elgFhPaAOJiLKuGEYxQcCpNfIVnRUT:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBU =elgFhPaAOJiLKuGEYxQcCpNfIVnRBj['broadcast']['4k_nondrm_url']
     elgFhPaAOJiLKuGEYxQcCpNfIVnRvr['drm_license']=''
    else:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBU =elgFhPaAOJiLKuGEYxQcCpNfIVnRBj['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in elgFhPaAOJiLKuGEYxQcCpNfIVnRBj['broadcast']):return elgFhPaAOJiLKuGEYxQcCpNfIVnRvr
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBU=elgFhPaAOJiLKuGEYxQcCpNfIVnRBj['broadcast']['broad_url']
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(elgFhPaAOJiLKuGEYxQcCpNfIVnRBU)
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvr['error_msg']='Second Step - except error'
   return elgFhPaAOJiLKuGEYxQcCpNfIVnRvr
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBW=elgFhPaAOJiLKuGEYxQcCpNfIVnRvo
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBU=elgFhPaAOJiLKuGEYxQcCpNfIVnRBU.split('|')[1]
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBU,elgFhPaAOJiLKuGEYxQcCpNfIVnRBS,elgFhPaAOJiLKuGEYxQcCpNfIVnRBz=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.Decrypt_Url(elgFhPaAOJiLKuGEYxQcCpNfIVnRBU,mediacode,elgFhPaAOJiLKuGEYxQcCpNfIVnRBW)
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvr['streaming_url']=elgFhPaAOJiLKuGEYxQcCpNfIVnRBU
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvr['watermark'] =elgFhPaAOJiLKuGEYxQcCpNfIVnRBS
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvr['watermarkKey']=elgFhPaAOJiLKuGEYxQcCpNfIVnRBz
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRvr
 def CheckQuality(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,sel_qt,elgFhPaAOJiLKuGEYxQcCpNfIVnRBM):
  for elgFhPaAOJiLKuGEYxQcCpNfIVnRBk in elgFhPaAOJiLKuGEYxQcCpNfIVnRBM:
   if sel_qt>=elgFhPaAOJiLKuGEYxQcCpNfIVnRUd(elgFhPaAOJiLKuGEYxQcCpNfIVnRBk)[0]:return elgFhPaAOJiLKuGEYxQcCpNfIVnRBk.get(elgFhPaAOJiLKuGEYxQcCpNfIVnRUd(elgFhPaAOJiLKuGEYxQcCpNfIVnRBk)[0])
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBs=elgFhPaAOJiLKuGEYxQcCpNfIVnRBk.get(elgFhPaAOJiLKuGEYxQcCpNfIVnRUd(elgFhPaAOJiLKuGEYxQcCpNfIVnRBk)[0])
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRBs
 def makeOocUrl(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,ooc_params):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=''
  for elgFhPaAOJiLKuGEYxQcCpNfIVnRBw,elgFhPaAOJiLKuGEYxQcCpNfIVnRBy in ooc_params.items():
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq+="%s=%s^"%(elgFhPaAOJiLKuGEYxQcCpNfIVnRBw,elgFhPaAOJiLKuGEYxQcCpNfIVnRBy)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRvq
 def GetLiveChannelList(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,stype,page_int):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvs=[]
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v2/media/lives'
   if stype=='onair': 
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBD='CPCS0100,CPCS0400'
   else:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBD='CPCS0300'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'cacheType':'main','pageNo':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(page_int),'pageSize':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':elgFhPaAOJiLKuGEYxQcCpNfIVnRBD,}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd.update(elgFhPaAOJiLKuGEYxQcCpNfIVnRvD)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvz
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvd,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvt=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   if not('result' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']):return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBt=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['result']
   for elgFhPaAOJiLKuGEYxQcCpNfIVnRvT in elgFhPaAOJiLKuGEYxQcCpNfIVnRBt:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBT=elgFhPaAOJiLKuGEYxQcCpNfIVnRBH=elgFhPaAOJiLKuGEYxQcCpNfIVnRBb=''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBm=elgFhPaAOJiLKuGEYxQcCpNfIVnRMt=''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBr=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['live_code']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBT =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['channel']['name']['ko']
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['episode']!=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBH =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['program']['name']['ko']
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBH =elgFhPaAOJiLKuGEYxQcCpNfIVnRBH+', '+elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['episode']['frequency'])+'회'
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBb=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['episode']['synopsis']['ko']
    else:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBH =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['program']['name']['ko']
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBb=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['program']['synopsis']['ko']
    try: 
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =''
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =''
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=''
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMw =''
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMv =''
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMB =''
     for elgFhPaAOJiLKuGEYxQcCpNfIVnRMj in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['program']['image']:
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP0900':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
      elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP1800':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
      elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP2000':elgFhPaAOJiLKuGEYxQcCpNfIVnRMw =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
      elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP1900':elgFhPaAOJiLKuGEYxQcCpNfIVnRMv =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
      elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP0200':elgFhPaAOJiLKuGEYxQcCpNfIVnRMB =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
      elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP0500':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
      elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP0800':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRBo=='':
      for elgFhPaAOJiLKuGEYxQcCpNfIVnRMj in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['channel']['image']:
       if elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIC0400':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
       elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIC1400':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
       elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIC1900':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
    except:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRUX
    try:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMU =[]
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMW=[]
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMS =[]
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMz=''
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMk=''
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMs=''
     for elgFhPaAOJiLKuGEYxQcCpNfIVnRMy in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('schedule').get('program').get('actor'):
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRMy!='' and elgFhPaAOJiLKuGEYxQcCpNfIVnRMy!=u'없음':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMy)
     for elgFhPaAOJiLKuGEYxQcCpNfIVnRMX in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('schedule').get('program').get('director'):
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRMX!='' and elgFhPaAOJiLKuGEYxQcCpNfIVnRMX!='-' and elgFhPaAOJiLKuGEYxQcCpNfIVnRMX!=u'없음':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMX)
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('schedule').get('program').get('category1_name').get('ko')!='':
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMS.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['program']['category1_name']['ko'])
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('schedule').get('program').get('category2_name').get('ko')!='':
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMS.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['program']['category2_name']['ko'])
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('schedule').get('program').get('product_year'):elgFhPaAOJiLKuGEYxQcCpNfIVnRMz=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['program']['product_year']
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('schedule').get('program').get('grade_code') :elgFhPaAOJiLKuGEYxQcCpNfIVnRMk= elgFhPaAOJiLKuGEYxQcCpNfIVnRwM.get(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['program']['grade_code'])
     if 'broad_dt' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('schedule').get('program'):
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMD =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('schedule').get('program').get('broad_dt')
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMs='%s-%s-%s'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[:4],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[4:6],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[6:])
    except:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRUX
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBm=elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['broadcast_start_time'])[8:12]
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMt =elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['schedule']['broadcast_end_time'])[8:12]
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMT={'channel':elgFhPaAOJiLKuGEYxQcCpNfIVnRBT,'title':elgFhPaAOJiLKuGEYxQcCpNfIVnRBH,'mediacode':elgFhPaAOJiLKuGEYxQcCpNfIVnRBr,'thumbnail':{'poster':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd,'thumb':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo,'clearlogo':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq,'icon':elgFhPaAOJiLKuGEYxQcCpNfIVnRMw,'fanart':elgFhPaAOJiLKuGEYxQcCpNfIVnRMB},'synopsis':elgFhPaAOJiLKuGEYxQcCpNfIVnRBb,'channelepg':' [%s:%s ~ %s:%s]'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRBm[0:2],elgFhPaAOJiLKuGEYxQcCpNfIVnRBm[2:],elgFhPaAOJiLKuGEYxQcCpNfIVnRMt[0:2],elgFhPaAOJiLKuGEYxQcCpNfIVnRMt[2:]),'cast':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU,'director':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW,'info_genre':elgFhPaAOJiLKuGEYxQcCpNfIVnRMS,'year':elgFhPaAOJiLKuGEYxQcCpNfIVnRMz,'mpaa':elgFhPaAOJiLKuGEYxQcCpNfIVnRMk,'premiered':elgFhPaAOJiLKuGEYxQcCpNfIVnRMs}
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvs.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMT)
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['has_more']=='Y':
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUT
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
 def GetProgramList(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,genre,orderby,page_int,genreCode='all'):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvs=[]
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  try:
   if genre=='PARAMOUNT':
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v2/media/paramount/episodes'
   else:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v2/media/episodes'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'cacheType':'main','pageSize':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(page_int),}
   if genre not in['all','PARAMOUNT']:elgFhPaAOJiLKuGEYxQcCpNfIVnRvD['categoryCode']=genre
   if genreCode!='all' :elgFhPaAOJiLKuGEYxQcCpNfIVnRvD['genreCode'] =genreCode 
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd.update(elgFhPaAOJiLKuGEYxQcCpNfIVnRvD)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvz
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvd,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvt=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   if not('result' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']):return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBt=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['result']
   for elgFhPaAOJiLKuGEYxQcCpNfIVnRvT in elgFhPaAOJiLKuGEYxQcCpNfIVnRBt:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMm=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['program']['code']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBH =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['program']['name']['ko']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMk =elgFhPaAOJiLKuGEYxQcCpNfIVnRwM.get(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['program'].get('grade_code'))
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMw =''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMv =''
    for elgFhPaAOJiLKuGEYxQcCpNfIVnRMj in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['program']['image']:
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP0900':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP0200':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP1800':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP2000':elgFhPaAOJiLKuGEYxQcCpNfIVnRMw =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP1900':elgFhPaAOJiLKuGEYxQcCpNfIVnRMv =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBb =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['program']['synopsis']['ko']
    try:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMr=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['channel']['name']['ko']
    except:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMr=''
    try:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMU =[]
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMW=[]
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMS =[]
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMz =''
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMs=''
     for elgFhPaAOJiLKuGEYxQcCpNfIVnRMy in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('program').get('actor'):
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRMy!='' and elgFhPaAOJiLKuGEYxQcCpNfIVnRMy!='-' and elgFhPaAOJiLKuGEYxQcCpNfIVnRMy!=u'없음':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMy)
     for elgFhPaAOJiLKuGEYxQcCpNfIVnRMX in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('program').get('director'):
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRMX!='' and elgFhPaAOJiLKuGEYxQcCpNfIVnRMX!='-' and elgFhPaAOJiLKuGEYxQcCpNfIVnRMX!=u'없음':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMX)
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('program').get('category1_name').get('ko')!='':
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMS.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['program']['category1_name']['ko'])
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('program').get('category2_name').get('ko')!='':
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMS.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['program']['category2_name']['ko'])
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('program').get('product_year'):elgFhPaAOJiLKuGEYxQcCpNfIVnRMz=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['program']['product_year']
     if 'broad_dt' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('program'):
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMD =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('program').get('broad_dt')
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMs='%s-%s-%s'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[:4],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[4:6],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[6:])
    except:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRUX
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMT={'program':elgFhPaAOJiLKuGEYxQcCpNfIVnRMm,'title':elgFhPaAOJiLKuGEYxQcCpNfIVnRBH,'thumbnail':{'poster':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd,'thumb':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo,'clearlogo':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq,'icon':elgFhPaAOJiLKuGEYxQcCpNfIVnRMw,'banner':elgFhPaAOJiLKuGEYxQcCpNfIVnRMv,'fanart':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo},'synopsis':elgFhPaAOJiLKuGEYxQcCpNfIVnRBb,'channel':elgFhPaAOJiLKuGEYxQcCpNfIVnRMr,'cast':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU,'director':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW,'info_genre':elgFhPaAOJiLKuGEYxQcCpNfIVnRMS,'year':elgFhPaAOJiLKuGEYxQcCpNfIVnRMz,'premiered':elgFhPaAOJiLKuGEYxQcCpNfIVnRMs,'mpaa':elgFhPaAOJiLKuGEYxQcCpNfIVnRMk}
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvs.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMT)
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['has_more']=='Y':elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUT
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
 def Get_UHD_ProgramList(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,page_int):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvs=[]
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v2/operator/highlights'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams(uhd=elgFhPaAOJiLKuGEYxQcCpNfIVnRUT)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(page_int),'pocType':'APP_X_TVING_4.0.0',}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd.update(elgFhPaAOJiLKuGEYxQcCpNfIVnRvD)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvz
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvd,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvt=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   if not('result' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']):return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBt=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['result']
   for elgFhPaAOJiLKuGEYxQcCpNfIVnRvT in elgFhPaAOJiLKuGEYxQcCpNfIVnRBt:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMH=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['content']['program']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMb =elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['code']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBH =elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['name']['ko'].strip()
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMk =elgFhPaAOJiLKuGEYxQcCpNfIVnRwM.get(elgFhPaAOJiLKuGEYxQcCpNfIVnRMH.get('grade_code'))
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBb =elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['synopsis']['ko']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMr =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['content']['channel']['name']['ko']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMz =elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['product_year']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMw =''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMv =''
    for elgFhPaAOJiLKuGEYxQcCpNfIVnRMj in elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['image']:
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP0900':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP0200':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP1800':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP2000':elgFhPaAOJiLKuGEYxQcCpNfIVnRMw =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP1900':elgFhPaAOJiLKuGEYxQcCpNfIVnRMv =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMS =[]
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMU =[]
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMW=[]
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMs =''
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRMH.get('category1_name').get('ko')!='':
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMS.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['category1_name']['ko'])
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRMH.get('category2_name').get('ko')!='':
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMS.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['category2_name']['ko'])
    for elgFhPaAOJiLKuGEYxQcCpNfIVnRMy in elgFhPaAOJiLKuGEYxQcCpNfIVnRMH.get('actor'):
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRMy!='' and elgFhPaAOJiLKuGEYxQcCpNfIVnRMy!='-' and elgFhPaAOJiLKuGEYxQcCpNfIVnRMy!=u'없음':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMy)
    for elgFhPaAOJiLKuGEYxQcCpNfIVnRMX in elgFhPaAOJiLKuGEYxQcCpNfIVnRMH.get('director'):
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRMX!='' and elgFhPaAOJiLKuGEYxQcCpNfIVnRMX!='-' and elgFhPaAOJiLKuGEYxQcCpNfIVnRMX!=u'없음':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMX)
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRMH.get('broad_dt')not in[elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,'']:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMD =elgFhPaAOJiLKuGEYxQcCpNfIVnRMH.get('broad_dt')
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMs='%s-%s-%s'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[:4],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[4:6],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[6:])
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMT={'program':elgFhPaAOJiLKuGEYxQcCpNfIVnRMb,'title':elgFhPaAOJiLKuGEYxQcCpNfIVnRBH,'mpaa':elgFhPaAOJiLKuGEYxQcCpNfIVnRMk,'thumbnail':{'poster':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd,'thumb':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo,'clearlogo':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq,'icon':elgFhPaAOJiLKuGEYxQcCpNfIVnRMw,'banner':elgFhPaAOJiLKuGEYxQcCpNfIVnRMv,'fanart':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo},'channel':elgFhPaAOJiLKuGEYxQcCpNfIVnRMr,'synopsis':elgFhPaAOJiLKuGEYxQcCpNfIVnRBb,'year':elgFhPaAOJiLKuGEYxQcCpNfIVnRMz,'info_genre':elgFhPaAOJiLKuGEYxQcCpNfIVnRMS,'cast':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU,'director':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW,'premiered':elgFhPaAOJiLKuGEYxQcCpNfIVnRMs,}
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvs.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMT)
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
 def Get_Origianl_ProgramList(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,page_int):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvs=[]
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v2/media/band/originals'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'pageSize':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(page_int),}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd.update(elgFhPaAOJiLKuGEYxQcCpNfIVnRvD)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvz
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvd,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvt=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   if not('contents' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']):return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBt=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['contents']
   for elgFhPaAOJiLKuGEYxQcCpNfIVnRvT in elgFhPaAOJiLKuGEYxQcCpNfIVnRBt:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMm=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['vod_code']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBH =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['vod_name']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['image']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMT={'program':elgFhPaAOJiLKuGEYxQcCpNfIVnRMm,'title':elgFhPaAOJiLKuGEYxQcCpNfIVnRBH,'thumbnail':{'poster':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd,'thumb':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd}}
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvs.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMT)
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['has_more']=='Y':elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUT
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
 def GetEpisodeList(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,program_code,page_int,orderby='desc'):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvs=[]
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v2/media/frequency/program/'+program_code
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd.update(elgFhPaAOJiLKuGEYxQcCpNfIVnRvD)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvz
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvd,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvt=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   if not('result' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']):return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBt=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['result']
   elgFhPaAOJiLKuGEYxQcCpNfIVnRMo=elgFhPaAOJiLKuGEYxQcCpNfIVnRUm(elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['total_count'])
   elgFhPaAOJiLKuGEYxQcCpNfIVnRMd =elgFhPaAOJiLKuGEYxQcCpNfIVnRUm(elgFhPaAOJiLKuGEYxQcCpNfIVnRMo//(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMq =(elgFhPaAOJiLKuGEYxQcCpNfIVnRMo-1)-((page_int-1)*elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.EPISODE_LIMIT)
   else:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMq =(page_int-1)*elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.EPISODE_LIMIT
   for i in elgFhPaAOJiLKuGEYxQcCpNfIVnRUr(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.EPISODE_LIMIT):
    if orderby=='desc':
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjw=elgFhPaAOJiLKuGEYxQcCpNfIVnRMq-i
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRjw<0:break
    else:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjw=elgFhPaAOJiLKuGEYxQcCpNfIVnRMq+i
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRjw>=elgFhPaAOJiLKuGEYxQcCpNfIVnRMo:break
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjv=elgFhPaAOJiLKuGEYxQcCpNfIVnRBt[elgFhPaAOJiLKuGEYxQcCpNfIVnRjw]['episode']['code']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBH =elgFhPaAOJiLKuGEYxQcCpNfIVnRBt[elgFhPaAOJiLKuGEYxQcCpNfIVnRjw]['vod_name']['ko']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjB =''
    try:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMD=elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRBt[elgFhPaAOJiLKuGEYxQcCpNfIVnRjw]['episode']['broadcast_date'])
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjB='%s-%s-%s'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[:4],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[4:6],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[6:])
    except:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRUX
    try:
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRBt[elgFhPaAOJiLKuGEYxQcCpNfIVnRjw]['episode']['pip_cliptype']=='C012':
      elgFhPaAOJiLKuGEYxQcCpNfIVnRjB+=' - Quick VOD'
    except:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRUX
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBb =elgFhPaAOJiLKuGEYxQcCpNfIVnRBt[elgFhPaAOJiLKuGEYxQcCpNfIVnRjw]['episode']['synopsis']['ko']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMw =''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMv =''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMB =''
    for elgFhPaAOJiLKuGEYxQcCpNfIVnRMj in elgFhPaAOJiLKuGEYxQcCpNfIVnRBt[elgFhPaAOJiLKuGEYxQcCpNfIVnRjw]['program']['image']:
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP0900':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP1800':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP2000':elgFhPaAOJiLKuGEYxQcCpNfIVnRMw =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP1900':elgFhPaAOJiLKuGEYxQcCpNfIVnRMv =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIP0200':elgFhPaAOJiLKuGEYxQcCpNfIVnRMB =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
    for elgFhPaAOJiLKuGEYxQcCpNfIVnRMj in elgFhPaAOJiLKuGEYxQcCpNfIVnRBt[elgFhPaAOJiLKuGEYxQcCpNfIVnRjw]['episode']['image']:
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIE0400':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
    try:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjM=elgFhPaAOJiLKuGEYxQcCpNfIVnRjW=elgFhPaAOJiLKuGEYxQcCpNfIVnRjS=''
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjU=0
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjM =elgFhPaAOJiLKuGEYxQcCpNfIVnRBt[elgFhPaAOJiLKuGEYxQcCpNfIVnRjw]['program']['name']['ko']
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjW =elgFhPaAOJiLKuGEYxQcCpNfIVnRjB
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjS =elgFhPaAOJiLKuGEYxQcCpNfIVnRBt[elgFhPaAOJiLKuGEYxQcCpNfIVnRjw]['channel']['name']['ko']
     if 'frequency' in elgFhPaAOJiLKuGEYxQcCpNfIVnRBt[elgFhPaAOJiLKuGEYxQcCpNfIVnRjw]['episode']:elgFhPaAOJiLKuGEYxQcCpNfIVnRjU=elgFhPaAOJiLKuGEYxQcCpNfIVnRBt[elgFhPaAOJiLKuGEYxQcCpNfIVnRjw]['episode']['frequency']
    except:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRUX
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMT={'episode':elgFhPaAOJiLKuGEYxQcCpNfIVnRjv,'title':elgFhPaAOJiLKuGEYxQcCpNfIVnRBH,'subtitle':elgFhPaAOJiLKuGEYxQcCpNfIVnRjB,'thumbnail':{'poster':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd,'thumb':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo,'clearlogo':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq,'icon':elgFhPaAOJiLKuGEYxQcCpNfIVnRMw,'banner':elgFhPaAOJiLKuGEYxQcCpNfIVnRMv,'fanart':elgFhPaAOJiLKuGEYxQcCpNfIVnRMB},'synopsis':elgFhPaAOJiLKuGEYxQcCpNfIVnRBb,'info_title':elgFhPaAOJiLKuGEYxQcCpNfIVnRjM,'aired':elgFhPaAOJiLKuGEYxQcCpNfIVnRjW,'studio':elgFhPaAOJiLKuGEYxQcCpNfIVnRjS,'frequency':elgFhPaAOJiLKuGEYxQcCpNfIVnRjU}
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvs.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMT)
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRMd>page_int:elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUT
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX,elgFhPaAOJiLKuGEYxQcCpNfIVnRMd
 def GetMovieList(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,genre,orderby,page_int):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvs=[]
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  try:
   if genre=='PARAMOUNT':
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v2/media/paramount/movies'
   else:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v2/media/movies'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'pageSize':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:elgFhPaAOJiLKuGEYxQcCpNfIVnRvD['categoryCode']=genre
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD['productPackageCode']=','.join(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.MOVIE_LITE)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd.update(elgFhPaAOJiLKuGEYxQcCpNfIVnRvD)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvz
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvd,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvt=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   if not('result' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']):return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBt=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['result']
   for elgFhPaAOJiLKuGEYxQcCpNfIVnRvT in elgFhPaAOJiLKuGEYxQcCpNfIVnRBt:
    if 'release_date' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('movie'):
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMz=elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('movie').get('release_date'))[:4]
    else:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMz=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjz =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['movie']['code']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBH =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['movie']['name']['ko'].strip()
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRMz not in[elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,'0','']:elgFhPaAOJiLKuGEYxQcCpNfIVnRBH+=u' (%s)'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRMz)
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBd=''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=''
    for elgFhPaAOJiLKuGEYxQcCpNfIVnRMj in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['movie']['image']:
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIM2100':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIM0400':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIM1800':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBb =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['movie']['story']['ko']
    try:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjM =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['movie']['name']['ko'].strip()
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMk =elgFhPaAOJiLKuGEYxQcCpNfIVnRwM.get(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('grade_code'))
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMU=[]
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMW=[]
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMS=[]
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjk=0
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMs=''
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjS =''
     for elgFhPaAOJiLKuGEYxQcCpNfIVnRMy in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('movie').get('actor'):
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRMy!='':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMy)
     for elgFhPaAOJiLKuGEYxQcCpNfIVnRMX in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('movie').get('director'):
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRMX!='':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMX)
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('movie').get('category1_name').get('ko')!='':
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMS.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['movie']['category1_name']['ko'])
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('movie').get('category2_name').get('ko')!='':
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMS.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['movie']['category2_name']['ko'])
     if 'duration' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('movie'):elgFhPaAOJiLKuGEYxQcCpNfIVnRjk=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('movie').get('duration')
     if 'release_date' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('movie'):
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMD=elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('movie').get('release_date'))
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRMD!='0':elgFhPaAOJiLKuGEYxQcCpNfIVnRMs='%s-%s-%s'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[:4],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[4:6],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[6:])
     if 'production' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('movie'):elgFhPaAOJiLKuGEYxQcCpNfIVnRjS=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('movie').get('production')
    except:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRUX
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMT={'moviecode':elgFhPaAOJiLKuGEYxQcCpNfIVnRjz,'title':elgFhPaAOJiLKuGEYxQcCpNfIVnRBH,'thumbnail':{'poster':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd,'thumb':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo,'clearlogo':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq,'fanart':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo},'synopsis':elgFhPaAOJiLKuGEYxQcCpNfIVnRBb,'info_title':elgFhPaAOJiLKuGEYxQcCpNfIVnRjM,'year':elgFhPaAOJiLKuGEYxQcCpNfIVnRMz,'cast':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU,'director':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW,'info_genre':elgFhPaAOJiLKuGEYxQcCpNfIVnRMS,'duration':elgFhPaAOJiLKuGEYxQcCpNfIVnRjk,'premiered':elgFhPaAOJiLKuGEYxQcCpNfIVnRMs,'studio':elgFhPaAOJiLKuGEYxQcCpNfIVnRjS,'mpaa':elgFhPaAOJiLKuGEYxQcCpNfIVnRMk}
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjs=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
    for elgFhPaAOJiLKuGEYxQcCpNfIVnRjy in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['billing_package_id']:
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRjy in elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.MOVIE_LITE:
      elgFhPaAOJiLKuGEYxQcCpNfIVnRjs=elgFhPaAOJiLKuGEYxQcCpNfIVnRUT
      break
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRjs==elgFhPaAOJiLKuGEYxQcCpNfIVnRUD: 
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMT['title']=elgFhPaAOJiLKuGEYxQcCpNfIVnRMT['title']+' [개별구매]'
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvs.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMT)
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['has_more']=='Y':elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUT
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
 def Get_UHD_MovieList(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,page_int):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvs=[]
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v2/operator/highlights'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams(uhd=elgFhPaAOJiLKuGEYxQcCpNfIVnRUT)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(page_int),'pocType':'APP_X_TVING_4.0.0',}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd.update(elgFhPaAOJiLKuGEYxQcCpNfIVnRvD)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvz
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvd,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvt=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   if not('result' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']):return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBt=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['result']
   for elgFhPaAOJiLKuGEYxQcCpNfIVnRvT in elgFhPaAOJiLKuGEYxQcCpNfIVnRBt:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMH=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['content']['movie']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMb =elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['code']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBH =elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['name']['ko'].strip()
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjM =elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['name']['ko'].strip()
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMz =elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['product_year']
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRMz:elgFhPaAOJiLKuGEYxQcCpNfIVnRBH+=u' (%s)'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['product_year'])
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBb =elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['story']['ko']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjk =elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['duration']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMk =elgFhPaAOJiLKuGEYxQcCpNfIVnRwM.get(elgFhPaAOJiLKuGEYxQcCpNfIVnRMH.get('grade_code'))
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjS =elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['production']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBd=''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=''
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMS =[]
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMU =[]
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMW=[]
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMs =''
    for elgFhPaAOJiLKuGEYxQcCpNfIVnRMj in elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['image']:
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIM2100':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIM0400':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
     elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['code']=='CAIM1800':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj['url']
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['release_date']not in[elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,0]:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMD=elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['release_date'])
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRMD!='0':elgFhPaAOJiLKuGEYxQcCpNfIVnRMs='%s-%s-%s'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[:4],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[4:6],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[6:])
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRMH.get('category1_name').get('ko')!='':
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMS.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['category1_name']['ko'])
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRMH.get('category2_name').get('ko')!='':
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMS.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMH['category2_name']['ko'])
    for elgFhPaAOJiLKuGEYxQcCpNfIVnRMy in elgFhPaAOJiLKuGEYxQcCpNfIVnRMH.get('actor'):
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRMy!='':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMy)
    for elgFhPaAOJiLKuGEYxQcCpNfIVnRMX in elgFhPaAOJiLKuGEYxQcCpNfIVnRMH.get('director'):
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRMX!='':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMX)
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMT={'moviecode':elgFhPaAOJiLKuGEYxQcCpNfIVnRMb,'title':elgFhPaAOJiLKuGEYxQcCpNfIVnRBH,'thumbnail':{'poster':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd,'thumb':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo,'clearlogo':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq,'fanart':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo},'year':elgFhPaAOJiLKuGEYxQcCpNfIVnRMz,'info_title':elgFhPaAOJiLKuGEYxQcCpNfIVnRjM,'synopsis':elgFhPaAOJiLKuGEYxQcCpNfIVnRBb,'mpaa':elgFhPaAOJiLKuGEYxQcCpNfIVnRMk,'duration':elgFhPaAOJiLKuGEYxQcCpNfIVnRjk,'premiered':elgFhPaAOJiLKuGEYxQcCpNfIVnRMs,'studio':elgFhPaAOJiLKuGEYxQcCpNfIVnRjS,'info_genre':elgFhPaAOJiLKuGEYxQcCpNfIVnRMS,'cast':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU,'director':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW,}
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvs.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMT)
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
 def GetMovieGenre(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvs=[]
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v2/media/movie/curations'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd.update(elgFhPaAOJiLKuGEYxQcCpNfIVnRvD)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvz
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvd,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvt=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   if not('result' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']):return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBt=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['result']
   for elgFhPaAOJiLKuGEYxQcCpNfIVnRvT in elgFhPaAOJiLKuGEYxQcCpNfIVnRBt:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjX =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['curation_code']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjD =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['curation_name']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRMT={'curation_code':elgFhPaAOJiLKuGEYxQcCpNfIVnRjX,'curation_name':elgFhPaAOJiLKuGEYxQcCpNfIVnRjD}
    elgFhPaAOJiLKuGEYxQcCpNfIVnRvs.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMT)
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
 def GetSearchList(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,search_key,page_int,stype):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRjt=[]
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/search/getSearch.jsp'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(page_int),'pageSize':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.SCREENCODE,'os':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.OSCODE,'network':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.SEARCH_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvz
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvD,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvt=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   if stype=='vod':
    if not('programRsb' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt):return elgFhPaAOJiLKuGEYxQcCpNfIVnRjt,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjT=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['programRsb']['dataList']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjm =elgFhPaAOJiLKuGEYxQcCpNfIVnRUm(elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['programRsb']['count'])
    for elgFhPaAOJiLKuGEYxQcCpNfIVnRvT in elgFhPaAOJiLKuGEYxQcCpNfIVnRjT:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMm=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['mast_cd']
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBH =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['mast_nm']
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['web_url4']
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['web_url']
     try:
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMU =[]
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMW=[]
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMS =[]
      elgFhPaAOJiLKuGEYxQcCpNfIVnRjk =0
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMk =''
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMz =''
      elgFhPaAOJiLKuGEYxQcCpNfIVnRjW =''
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('actor') !='' and elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('actor') !='-':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('actor').split(',')
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('director')!='' and elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('director')!='-':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('director').split(',')
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('cate_nm')!='' and elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('cate_nm')!='-':elgFhPaAOJiLKuGEYxQcCpNfIVnRMS =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('cate_nm').split('/')
      if 'targetage' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT:elgFhPaAOJiLKuGEYxQcCpNfIVnRMk=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('targetage')
      if 'broad_dt' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT:
       elgFhPaAOJiLKuGEYxQcCpNfIVnRMD=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('broad_dt')
       elgFhPaAOJiLKuGEYxQcCpNfIVnRjW='%s-%s-%s'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[:4],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[4:6],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[6:])
       elgFhPaAOJiLKuGEYxQcCpNfIVnRMz =elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[:4]
     except:
      elgFhPaAOJiLKuGEYxQcCpNfIVnRUX
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMT={'program':elgFhPaAOJiLKuGEYxQcCpNfIVnRMm,'title':elgFhPaAOJiLKuGEYxQcCpNfIVnRBH,'thumbnail':{'poster':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd,'thumb':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo,'fanart':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo},'synopsis':'','cast':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU,'director':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW,'info_genre':elgFhPaAOJiLKuGEYxQcCpNfIVnRMS,'duration':elgFhPaAOJiLKuGEYxQcCpNfIVnRjk,'mpaa':elgFhPaAOJiLKuGEYxQcCpNfIVnRMk,'year':elgFhPaAOJiLKuGEYxQcCpNfIVnRMz,'aired':elgFhPaAOJiLKuGEYxQcCpNfIVnRjW}
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjt.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMT)
   else:
    if not('vodMVRsb' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt):return elgFhPaAOJiLKuGEYxQcCpNfIVnRjt,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjr=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['vodMVRsb']['dataList']
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjm =elgFhPaAOJiLKuGEYxQcCpNfIVnRUm(elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['vodMVRsb']['count'])
    for elgFhPaAOJiLKuGEYxQcCpNfIVnRvT in elgFhPaAOJiLKuGEYxQcCpNfIVnRjr:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMm=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['mast_cd']
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBH =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['mast_nm'].strip()
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['web_url']
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRBd
     elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=''
     try:
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMU =[]
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMW=[]
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMS =[]
      elgFhPaAOJiLKuGEYxQcCpNfIVnRjk =0
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMk =''
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMz =''
      elgFhPaAOJiLKuGEYxQcCpNfIVnRjW =''
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('actor') !='' and elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('actor') !='-':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('actor').split(',')
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('director')!='' and elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('director')!='-':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('director').split(',')
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('cate_nm')!='' and elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('cate_nm')!='-':elgFhPaAOJiLKuGEYxQcCpNfIVnRMS =elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('cate_nm').split('/')
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('runtime_sec')!='':elgFhPaAOJiLKuGEYxQcCpNfIVnRjk=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('runtime_sec')
      if 'grade_nm' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT:elgFhPaAOJiLKuGEYxQcCpNfIVnRMk=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('grade_nm')
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMD=elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('broad_dt')
      if data_str!='':
       elgFhPaAOJiLKuGEYxQcCpNfIVnRjW='%s-%s-%s'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[:4],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[4:6],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[6:])
       elgFhPaAOJiLKuGEYxQcCpNfIVnRMz =elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[:4]
     except:
      elgFhPaAOJiLKuGEYxQcCpNfIVnRUX
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMT={'movie':elgFhPaAOJiLKuGEYxQcCpNfIVnRMm,'title':elgFhPaAOJiLKuGEYxQcCpNfIVnRBH,'thumbnail':{'poster':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd,'thumb':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo,'fanart':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo,'clearlogo':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq},'synopsis':'','cast':elgFhPaAOJiLKuGEYxQcCpNfIVnRMU,'director':elgFhPaAOJiLKuGEYxQcCpNfIVnRMW,'info_genre':elgFhPaAOJiLKuGEYxQcCpNfIVnRMS,'duration':elgFhPaAOJiLKuGEYxQcCpNfIVnRjk,'mpaa':elgFhPaAOJiLKuGEYxQcCpNfIVnRMk,'year':elgFhPaAOJiLKuGEYxQcCpNfIVnRMz,'aired':elgFhPaAOJiLKuGEYxQcCpNfIVnRjW}
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjs=elgFhPaAOJiLKuGEYxQcCpNfIVnRUD
     for elgFhPaAOJiLKuGEYxQcCpNfIVnRjy in elgFhPaAOJiLKuGEYxQcCpNfIVnRvT['bill']:
      if elgFhPaAOJiLKuGEYxQcCpNfIVnRjy in elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.MOVIE_LITE:
       elgFhPaAOJiLKuGEYxQcCpNfIVnRjs=elgFhPaAOJiLKuGEYxQcCpNfIVnRUT
       break
     if elgFhPaAOJiLKuGEYxQcCpNfIVnRjs==elgFhPaAOJiLKuGEYxQcCpNfIVnRUD: 
      elgFhPaAOJiLKuGEYxQcCpNfIVnRMT['title']=elgFhPaAOJiLKuGEYxQcCpNfIVnRMT['title']+' [개별구매]'
     elgFhPaAOJiLKuGEYxQcCpNfIVnRjt.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMT)
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRjm>(page_int*elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.SEARCH_LIMIT):elgFhPaAOJiLKuGEYxQcCpNfIVnRBX=elgFhPaAOJiLKuGEYxQcCpNfIVnRUT
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRjt,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
 def GetBookmarkInfo(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,videoid,vidtype):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRjH={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+'/v2/media/program/'+videoid
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'pageNo':'1','pageSize':'10','order':'name',}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd.update(elgFhPaAOJiLKuGEYxQcCpNfIVnRvD)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvd,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjb=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   if not('body' in elgFhPaAOJiLKuGEYxQcCpNfIVnRjb):return{}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjo=elgFhPaAOJiLKuGEYxQcCpNfIVnRjb['body']
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBH=elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('name').get('ko').strip()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['title'] =elgFhPaAOJiLKuGEYxQcCpNfIVnRBH
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['title']=elgFhPaAOJiLKuGEYxQcCpNfIVnRBH
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['mpaa'] =elgFhPaAOJiLKuGEYxQcCpNfIVnRwM.get(elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('grade_code'))
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['plot'] =elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('synopsis').get('ko')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['year'] =elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('product_year')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['cast'] =elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('actor')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['director']=elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('director')
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('category1_name').get('ko')!='':
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['genre'].append(elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('category1_name').get('ko'))
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('category2_name').get('ko')!='':
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['genre'].append(elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('category2_name').get('ko'))
   elgFhPaAOJiLKuGEYxQcCpNfIVnRMD=elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('broad_dt'))
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRMD!='0':elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[:4],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[4:6],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[6:])
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =''
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =''
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=''
   elgFhPaAOJiLKuGEYxQcCpNfIVnRMw =''
   elgFhPaAOJiLKuGEYxQcCpNfIVnRMv =''
   for elgFhPaAOJiLKuGEYxQcCpNfIVnRMj in elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('image'):
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('code')=='CAIP0900':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('url')
    elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('code')=='CAIP0200':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('url')
    elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('code')=='CAIP1800':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('url')
    elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('code')=='CAIP2000':elgFhPaAOJiLKuGEYxQcCpNfIVnRMw =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('url')
    elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('code')=='CAIP1900':elgFhPaAOJiLKuGEYxQcCpNfIVnRMv =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('url')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['thumbnail']['poster']=elgFhPaAOJiLKuGEYxQcCpNfIVnRBd
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['thumbnail']['thumb']=elgFhPaAOJiLKuGEYxQcCpNfIVnRBo
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['thumbnail']['clearlogo']=elgFhPaAOJiLKuGEYxQcCpNfIVnRBq
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['thumbnail']['icon']=elgFhPaAOJiLKuGEYxQcCpNfIVnRMw
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['thumbnail']['banner']=elgFhPaAOJiLKuGEYxQcCpNfIVnRMv
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['thumbnail']['fanart']=elgFhPaAOJiLKuGEYxQcCpNfIVnRBo
  else:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+'/v2a/media/stream/info'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_uuid'].split('-')[0],'uuid':elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetNoCache(1)),'wm':'Y',}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd.update(elgFhPaAOJiLKuGEYxQcCpNfIVnRvD)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvd,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjb=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   if not('content' in elgFhPaAOJiLKuGEYxQcCpNfIVnRjb['body']):return{}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjo=elgFhPaAOJiLKuGEYxQcCpNfIVnRjb['body']['content']['info']['movie']
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBH =elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('name').get('ko').strip()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['title']=elgFhPaAOJiLKuGEYxQcCpNfIVnRBH
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBH +=u' (%s)'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('product_year'))
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['title'] =elgFhPaAOJiLKuGEYxQcCpNfIVnRBH
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['mpaa'] =elgFhPaAOJiLKuGEYxQcCpNfIVnRwM.get(elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('grade_code'))
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['plot'] =elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('story').get('ko')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['year'] =elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('product_year')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['studio'] =elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('production')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['duration']=elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('duration')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['cast'] =elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('actor')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['director']=elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('director')
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('category1_name').get('ko')!='':
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['genre'].append(elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('category1_name').get('ko'))
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('category2_name').get('ko')!='':
    elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['genre'].append(elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('category2_name').get('ko'))
   elgFhPaAOJiLKuGEYxQcCpNfIVnRMD=elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('release_date'))
   if elgFhPaAOJiLKuGEYxQcCpNfIVnRMD!='0':elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[:4],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[4:6],elgFhPaAOJiLKuGEYxQcCpNfIVnRMD[6:])
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBd=''
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =''
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=''
   for elgFhPaAOJiLKuGEYxQcCpNfIVnRMj in elgFhPaAOJiLKuGEYxQcCpNfIVnRjo.get('image'):
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('code')=='CAIM2100':elgFhPaAOJiLKuGEYxQcCpNfIVnRBd =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('url')
    elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('code')=='CAIM0400':elgFhPaAOJiLKuGEYxQcCpNfIVnRBo =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('url')
    elif elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('code')=='CAIM1800':elgFhPaAOJiLKuGEYxQcCpNfIVnRBq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.IMG_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRMj.get('url')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['thumbnail']['poster']=elgFhPaAOJiLKuGEYxQcCpNfIVnRBd
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['thumbnail']['thumb']=elgFhPaAOJiLKuGEYxQcCpNfIVnRBd 
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['thumbnail']['clearlogo']=elgFhPaAOJiLKuGEYxQcCpNfIVnRBq
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjH['saveinfo']['thumbnail']['fanart']=elgFhPaAOJiLKuGEYxQcCpNfIVnRBo
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRjH
 def GetEuroChannelList(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRvs=[]
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvz ='/v2/operator/highlights'
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetDefaultParams()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvD={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':elgFhPaAOJiLKuGEYxQcCpNfIVnRUo(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.GetNoCache(2))}
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvd.update(elgFhPaAOJiLKuGEYxQcCpNfIVnRvD)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvq=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.API_DOMAIN+elgFhPaAOJiLKuGEYxQcCpNfIVnRvz
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvM=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.callRequestCookies('Get',elgFhPaAOJiLKuGEYxQcCpNfIVnRvq,payload=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,params=elgFhPaAOJiLKuGEYxQcCpNfIVnRvd,headers=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX,cookies=elgFhPaAOJiLKuGEYxQcCpNfIVnRUX)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRvt=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRvM.text)
   if not('result' in elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']):return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs,elgFhPaAOJiLKuGEYxQcCpNfIVnRBX
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBt=elgFhPaAOJiLKuGEYxQcCpNfIVnRvt['body']['result']
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjd =elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.Get_Now_Datetime()
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjq=elgFhPaAOJiLKuGEYxQcCpNfIVnRjd+datetime.timedelta(days=-1)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRjq=elgFhPaAOJiLKuGEYxQcCpNfIVnRUm(elgFhPaAOJiLKuGEYxQcCpNfIVnRjq.strftime('%Y%m%d'))
   for elgFhPaAOJiLKuGEYxQcCpNfIVnRvT in elgFhPaAOJiLKuGEYxQcCpNfIVnRBt:
    elgFhPaAOJiLKuGEYxQcCpNfIVnRUw=elgFhPaAOJiLKuGEYxQcCpNfIVnRUm(elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('content').get('banner_title2')[:8])
    if elgFhPaAOJiLKuGEYxQcCpNfIVnRjq<=elgFhPaAOJiLKuGEYxQcCpNfIVnRUw:
     elgFhPaAOJiLKuGEYxQcCpNfIVnRMT={'channel':elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('content').get('banner_sub_title3'),'title':elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('content').get('banner_title'),'subtitle':elgFhPaAOJiLKuGEYxQcCpNfIVnRvT.get('content').get('banner_sub_title2'),}
     elgFhPaAOJiLKuGEYxQcCpNfIVnRvs.append(elgFhPaAOJiLKuGEYxQcCpNfIVnRMT)
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRvs
 def Make_DecryptKey(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,step,mediacode='000',timecode='000'):
  if step=='1':
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUv=elgFhPaAOJiLKuGEYxQcCpNfIVnRUq('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUB=elgFhPaAOJiLKuGEYxQcCpNfIVnRUq('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUv=elgFhPaAOJiLKuGEYxQcCpNfIVnRUq('kss2lym0kdw1lks3','utf-8')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUB=elgFhPaAOJiLKuGEYxQcCpNfIVnRUq([elgFhPaAOJiLKuGEYxQcCpNfIVnRWw('*'),0x07,elgFhPaAOJiLKuGEYxQcCpNfIVnRWw('r'),elgFhPaAOJiLKuGEYxQcCpNfIVnRWw(';'),elgFhPaAOJiLKuGEYxQcCpNfIVnRWw('7'),0x05,0x1e,0x01,elgFhPaAOJiLKuGEYxQcCpNfIVnRWw('n'),elgFhPaAOJiLKuGEYxQcCpNfIVnRWw('D'),0x02,elgFhPaAOJiLKuGEYxQcCpNfIVnRWw('3'),elgFhPaAOJiLKuGEYxQcCpNfIVnRWw('*'),elgFhPaAOJiLKuGEYxQcCpNfIVnRWw('a'),elgFhPaAOJiLKuGEYxQcCpNfIVnRWw('&'),elgFhPaAOJiLKuGEYxQcCpNfIVnRWw('<')])
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRUv,elgFhPaAOJiLKuGEYxQcCpNfIVnRUB
 def DecryptPlaintext(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,ciphertext,encryption_key,init_vector):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRUM=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  elgFhPaAOJiLKuGEYxQcCpNfIVnRUj=Padding.unpad(elgFhPaAOJiLKuGEYxQcCpNfIVnRUM.decrypt(base64.standard_b64decode(ciphertext)),16)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRUj.decode('utf-8')
 def Decrypt_Url(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj,ciphertext,mediacode,elgFhPaAOJiLKuGEYxQcCpNfIVnRBW):
  elgFhPaAOJiLKuGEYxQcCpNfIVnRUW=''
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBS=''
  elgFhPaAOJiLKuGEYxQcCpNfIVnRBz=''
  try:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUv,elgFhPaAOJiLKuGEYxQcCpNfIVnRUB=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.Make_DecryptKey('1',mediacode=mediacode,timecode=elgFhPaAOJiLKuGEYxQcCpNfIVnRBW)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUS=json.loads(elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.DecryptPlaintext(ciphertext,elgFhPaAOJiLKuGEYxQcCpNfIVnRUv,elgFhPaAOJiLKuGEYxQcCpNfIVnRUB))
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUz =elgFhPaAOJiLKuGEYxQcCpNfIVnRUS.get('broad_url')
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBS =elgFhPaAOJiLKuGEYxQcCpNfIVnRUS.get('watermark') if 'watermark' in elgFhPaAOJiLKuGEYxQcCpNfIVnRUS else ''
   elgFhPaAOJiLKuGEYxQcCpNfIVnRBz=elgFhPaAOJiLKuGEYxQcCpNfIVnRUS.get('watermarkKey')if 'watermarkKey' in elgFhPaAOJiLKuGEYxQcCpNfIVnRUS else ''
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUv,elgFhPaAOJiLKuGEYxQcCpNfIVnRUB=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.Make_DecryptKey('2',mediacode=mediacode,timecode=elgFhPaAOJiLKuGEYxQcCpNfIVnRBW)
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUW=elgFhPaAOJiLKuGEYxQcCpNfIVnRwj.DecryptPlaintext(elgFhPaAOJiLKuGEYxQcCpNfIVnRUz,elgFhPaAOJiLKuGEYxQcCpNfIVnRUv,elgFhPaAOJiLKuGEYxQcCpNfIVnRUB)
  except elgFhPaAOJiLKuGEYxQcCpNfIVnRUH as exception:
   elgFhPaAOJiLKuGEYxQcCpNfIVnRUk(exception)
  return elgFhPaAOJiLKuGEYxQcCpNfIVnRUW,elgFhPaAOJiLKuGEYxQcCpNfIVnRBS,elgFhPaAOJiLKuGEYxQcCpNfIVnRBz
# Created by pyminifier (https://github.com/liftoff/pyminifier)
