__author__="NightRain"
vdQJDPfwCAmnxYMBIETjtoUkNLebqX=object
vdQJDPfwCAmnxYMBIETjtoUkNLebqh=None
vdQJDPfwCAmnxYMBIETjtoUkNLebqF=int
vdQJDPfwCAmnxYMBIETjtoUkNLebqK=False
vdQJDPfwCAmnxYMBIETjtoUkNLebql=True
vdQJDPfwCAmnxYMBIETjtoUkNLebqg=type
vdQJDPfwCAmnxYMBIETjtoUkNLebqs=dict
vdQJDPfwCAmnxYMBIETjtoUkNLebqy=getattr
vdQJDPfwCAmnxYMBIETjtoUkNLebqS=list
vdQJDPfwCAmnxYMBIETjtoUkNLebqO=len
vdQJDPfwCAmnxYMBIETjtoUkNLebqz=str
vdQJDPfwCAmnxYMBIETjtoUkNLebqp=range
vdQJDPfwCAmnxYMBIETjtoUkNLebqr=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
vdQJDPfwCAmnxYMBIETjtoUkNLebuR=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'티빙 오리지날','mode':'BAND_VODLIST','bandKey':'HM200935','moreUrl':'/band/HM200935'},{'title':'실시간 인기 드라마','mode':'BAND_VODLIST','bandKey':'HM165416','moreUrl':'/band/HM165416'},{'title':'실시간 인기 예능','mode':'BAND_VODLIST','bandKey':'HM156521','moreUrl':'/band/HM156521'},{'title':'실시간 인기 영화','mode':'BAND_VODLIST','bandKey':'HM200932','moreUrl':'/band/HM200932'},{'title':'Apple TV+ 실시간 인기','mode':'BAND_VODLIST','bandKey':'HM192222','moreUrl':'/band/HM192222'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'Apple TV+','mode':'APPLE_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'},]
vdQJDPfwCAmnxYMBIETjtoUkNLebuW=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
vdQJDPfwCAmnxYMBIETjtoUkNLebuX=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
vdQJDPfwCAmnxYMBIETjtoUkNLebuh=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
vdQJDPfwCAmnxYMBIETjtoUkNLebuF=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
vdQJDPfwCAmnxYMBIETjtoUkNLebuK=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
vdQJDPfwCAmnxYMBIETjtoUkNLebuq=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
vdQJDPfwCAmnxYMBIETjtoUkNLebul={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
vdQJDPfwCAmnxYMBIETjtoUkNLebug =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
vdQJDPfwCAmnxYMBIETjtoUkNLebus=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class vdQJDPfwCAmnxYMBIETjtoUkNLebua(vdQJDPfwCAmnxYMBIETjtoUkNLebqX):
 def __init__(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebuS,vdQJDPfwCAmnxYMBIETjtoUkNLebuO,vdQJDPfwCAmnxYMBIETjtoUkNLebuz):
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_url =vdQJDPfwCAmnxYMBIETjtoUkNLebuS
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle=vdQJDPfwCAmnxYMBIETjtoUkNLebuO
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params =vdQJDPfwCAmnxYMBIETjtoUkNLebuz
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj =kJndetKVMsoFRWYSyrPxcpCBGaTjEi() 
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,sting):
  try:
   vdQJDPfwCAmnxYMBIETjtoUkNLebur=xbmcgui.Dialog()
   vdQJDPfwCAmnxYMBIETjtoUkNLebur.notification(__addonname__,sting)
  except:
   vdQJDPfwCAmnxYMBIETjtoUkNLebqh
 def addon_log(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,string):
  try:
   vdQJDPfwCAmnxYMBIETjtoUkNLebuG=string.encode('utf-8','ignore')
  except:
   vdQJDPfwCAmnxYMBIETjtoUkNLebuG='addonException: addon_log'
  vdQJDPfwCAmnxYMBIETjtoUkNLebuc=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,vdQJDPfwCAmnxYMBIETjtoUkNLebuG),level=vdQJDPfwCAmnxYMBIETjtoUkNLebuc)
 def get_keyboard_input(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebaz):
  vdQJDPfwCAmnxYMBIETjtoUkNLebuV=vdQJDPfwCAmnxYMBIETjtoUkNLebqh
  kb=xbmc.Keyboard()
  kb.setHeading(vdQJDPfwCAmnxYMBIETjtoUkNLebaz)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   vdQJDPfwCAmnxYMBIETjtoUkNLebuV=kb.getText()
  return vdQJDPfwCAmnxYMBIETjtoUkNLebuV
 def get_settings_account(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  vdQJDPfwCAmnxYMBIETjtoUkNLebuH =__addon__.getSetting('id')
  vdQJDPfwCAmnxYMBIETjtoUkNLebui =__addon__.getSetting('pw')
  vdQJDPfwCAmnxYMBIETjtoUkNLebau =__addon__.getSetting('login_type')
  vdQJDPfwCAmnxYMBIETjtoUkNLebaR=vdQJDPfwCAmnxYMBIETjtoUkNLebqF(__addon__.getSetting('selected_profile'))
  return(vdQJDPfwCAmnxYMBIETjtoUkNLebuH,vdQJDPfwCAmnxYMBIETjtoUkNLebui,vdQJDPfwCAmnxYMBIETjtoUkNLebau,vdQJDPfwCAmnxYMBIETjtoUkNLebaR)
 def get_settings_uhd(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  return vdQJDPfwCAmnxYMBIETjtoUkNLebqK
 def get_settings_playback(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  vdQJDPfwCAmnxYMBIETjtoUkNLebaW={'active_uhd':vdQJDPfwCAmnxYMBIETjtoUkNLebql if __addon__.getSetting('active_uhd')=='true' else vdQJDPfwCAmnxYMBIETjtoUkNLebqK,'streamFilename':vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.TV_STREAM_FILENAME,}
  return vdQJDPfwCAmnxYMBIETjtoUkNLebaW
 def get_settings_proxyport(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  vdQJDPfwCAmnxYMBIETjtoUkNLebaX =vdQJDPfwCAmnxYMBIETjtoUkNLebql if __addon__.getSetting('proxyYn')=='true' else vdQJDPfwCAmnxYMBIETjtoUkNLebqK
  vdQJDPfwCAmnxYMBIETjtoUkNLebah=vdQJDPfwCAmnxYMBIETjtoUkNLebqF(__addon__.getSetting('proxyPort'))
  return vdQJDPfwCAmnxYMBIETjtoUkNLebaX,vdQJDPfwCAmnxYMBIETjtoUkNLebah
 def get_settings_totalsearch(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  vdQJDPfwCAmnxYMBIETjtoUkNLebaF =vdQJDPfwCAmnxYMBIETjtoUkNLebql if __addon__.getSetting('local_search')=='true' else vdQJDPfwCAmnxYMBIETjtoUkNLebqK
  vdQJDPfwCAmnxYMBIETjtoUkNLebaK=vdQJDPfwCAmnxYMBIETjtoUkNLebql if __addon__.getSetting('local_history')=='true' else vdQJDPfwCAmnxYMBIETjtoUkNLebqK
  vdQJDPfwCAmnxYMBIETjtoUkNLebaq =vdQJDPfwCAmnxYMBIETjtoUkNLebql if __addon__.getSetting('total_search')=='true' else vdQJDPfwCAmnxYMBIETjtoUkNLebqK
  vdQJDPfwCAmnxYMBIETjtoUkNLebal=vdQJDPfwCAmnxYMBIETjtoUkNLebql if __addon__.getSetting('total_history')=='true' else vdQJDPfwCAmnxYMBIETjtoUkNLebqK
  vdQJDPfwCAmnxYMBIETjtoUkNLebag=vdQJDPfwCAmnxYMBIETjtoUkNLebql if __addon__.getSetting('menu_bookmark')=='true' else vdQJDPfwCAmnxYMBIETjtoUkNLebqK
  return(vdQJDPfwCAmnxYMBIETjtoUkNLebaF,vdQJDPfwCAmnxYMBIETjtoUkNLebaK,vdQJDPfwCAmnxYMBIETjtoUkNLebaq,vdQJDPfwCAmnxYMBIETjtoUkNLebal,vdQJDPfwCAmnxYMBIETjtoUkNLebag)
 def get_settings_makebookmark(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  return vdQJDPfwCAmnxYMBIETjtoUkNLebql if __addon__.getSetting('make_bookmark')=='true' else vdQJDPfwCAmnxYMBIETjtoUkNLebqK
 def get_settings_direct_replay(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  vdQJDPfwCAmnxYMBIETjtoUkNLebas=vdQJDPfwCAmnxYMBIETjtoUkNLebqF(__addon__.getSetting('direct_replay'))
  if vdQJDPfwCAmnxYMBIETjtoUkNLebas==0:
   return vdQJDPfwCAmnxYMBIETjtoUkNLebqK
  else:
   return vdQJDPfwCAmnxYMBIETjtoUkNLebql
 def set_winEpisodeOrderby(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebaS):
  __addon__.setSetting('tving_orderby',vdQJDPfwCAmnxYMBIETjtoUkNLebaS)
  vdQJDPfwCAmnxYMBIETjtoUkNLebay=xbmcgui.Window(10000)
  vdQJDPfwCAmnxYMBIETjtoUkNLebay.setProperty('TVING_M_ORDERBY',vdQJDPfwCAmnxYMBIETjtoUkNLebaS)
 def get_winEpisodeOrderby(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  vdQJDPfwCAmnxYMBIETjtoUkNLebaS=__addon__.getSetting('tving_orderby')
  if vdQJDPfwCAmnxYMBIETjtoUkNLebaS in['',vdQJDPfwCAmnxYMBIETjtoUkNLebqh]:vdQJDPfwCAmnxYMBIETjtoUkNLebaS='desc'
  return vdQJDPfwCAmnxYMBIETjtoUkNLebaS
 def add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,label,sublabel='',img='',infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params='',isLink=vdQJDPfwCAmnxYMBIETjtoUkNLebqK,ContextMenu=vdQJDPfwCAmnxYMBIETjtoUkNLebqh):
  vdQJDPfwCAmnxYMBIETjtoUkNLebaO='%s?%s'%(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_url,urllib.parse.urlencode(params))
  if sublabel:vdQJDPfwCAmnxYMBIETjtoUkNLebaz='%s < %s >'%(label,sublabel)
  else: vdQJDPfwCAmnxYMBIETjtoUkNLebaz=label
  if not img:img='DefaultFolder.png'
  vdQJDPfwCAmnxYMBIETjtoUkNLebap=xbmcgui.ListItem(vdQJDPfwCAmnxYMBIETjtoUkNLebaz)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebqg(img)==vdQJDPfwCAmnxYMBIETjtoUkNLebqs:
   vdQJDPfwCAmnxYMBIETjtoUkNLebap.setArt(img)
  else:
   vdQJDPfwCAmnxYMBIETjtoUkNLebap.setArt({'thumb':img,'poster':img})
  if vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.KodiVersion>=20:
   if infoLabels:vdQJDPfwCAmnxYMBIETjtoUkNLebuy.Set_InfoTag(vdQJDPfwCAmnxYMBIETjtoUkNLebap.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:vdQJDPfwCAmnxYMBIETjtoUkNLebap.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   vdQJDPfwCAmnxYMBIETjtoUkNLebap.setProperty('IsPlayable','true')
  if ContextMenu:vdQJDPfwCAmnxYMBIETjtoUkNLebap.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,vdQJDPfwCAmnxYMBIETjtoUkNLebaO,vdQJDPfwCAmnxYMBIETjtoUkNLebap,isFolder)
 def get_selQuality(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,etype):
  try:
   vdQJDPfwCAmnxYMBIETjtoUkNLebar='selected_quality'
   vdQJDPfwCAmnxYMBIETjtoUkNLebaG=[1080,720,480,360]
   vdQJDPfwCAmnxYMBIETjtoUkNLebac=vdQJDPfwCAmnxYMBIETjtoUkNLebqF(__addon__.getSetting(vdQJDPfwCAmnxYMBIETjtoUkNLebar))
   return vdQJDPfwCAmnxYMBIETjtoUkNLebaG[vdQJDPfwCAmnxYMBIETjtoUkNLebac]
  except:
   vdQJDPfwCAmnxYMBIETjtoUkNLebqh
  return 720 
 def Set_InfoTag(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,video_InfoTag:xbmc.InfoTagVideo,vdQJDPfwCAmnxYMBIETjtoUkNLebRh):
  for vdQJDPfwCAmnxYMBIETjtoUkNLebaV,value in vdQJDPfwCAmnxYMBIETjtoUkNLebRh.items():
   if vdQJDPfwCAmnxYMBIETjtoUkNLebul[vdQJDPfwCAmnxYMBIETjtoUkNLebaV]['type']=='string':
    vdQJDPfwCAmnxYMBIETjtoUkNLebqy(video_InfoTag,vdQJDPfwCAmnxYMBIETjtoUkNLebul[vdQJDPfwCAmnxYMBIETjtoUkNLebaV]['func'])(value)
   elif vdQJDPfwCAmnxYMBIETjtoUkNLebul[vdQJDPfwCAmnxYMBIETjtoUkNLebaV]['type']=='int':
    if vdQJDPfwCAmnxYMBIETjtoUkNLebqg(value)==vdQJDPfwCAmnxYMBIETjtoUkNLebqF:
     vdQJDPfwCAmnxYMBIETjtoUkNLebaH=vdQJDPfwCAmnxYMBIETjtoUkNLebqF(value)
    else:
     vdQJDPfwCAmnxYMBIETjtoUkNLebaH=0
    vdQJDPfwCAmnxYMBIETjtoUkNLebqy(video_InfoTag,vdQJDPfwCAmnxYMBIETjtoUkNLebul[vdQJDPfwCAmnxYMBIETjtoUkNLebaV]['func'])(vdQJDPfwCAmnxYMBIETjtoUkNLebaH)
   elif vdQJDPfwCAmnxYMBIETjtoUkNLebul[vdQJDPfwCAmnxYMBIETjtoUkNLebaV]['type']=='actor':
    if value!=[]:
     vdQJDPfwCAmnxYMBIETjtoUkNLebqy(video_InfoTag,vdQJDPfwCAmnxYMBIETjtoUkNLebul[vdQJDPfwCAmnxYMBIETjtoUkNLebaV]['func'])([xbmc.Actor(name)for name in value])
   elif vdQJDPfwCAmnxYMBIETjtoUkNLebul[vdQJDPfwCAmnxYMBIETjtoUkNLebaV]['type']=='list':
    if vdQJDPfwCAmnxYMBIETjtoUkNLebqg(value)==vdQJDPfwCAmnxYMBIETjtoUkNLebqS:
     vdQJDPfwCAmnxYMBIETjtoUkNLebqy(video_InfoTag,vdQJDPfwCAmnxYMBIETjtoUkNLebul[vdQJDPfwCAmnxYMBIETjtoUkNLebaV]['func'])(value)
    else:
     vdQJDPfwCAmnxYMBIETjtoUkNLebqy(video_InfoTag,vdQJDPfwCAmnxYMBIETjtoUkNLebul[vdQJDPfwCAmnxYMBIETjtoUkNLebaV]['func'])([value])
 def dp_Main_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  (vdQJDPfwCAmnxYMBIETjtoUkNLebaF,vdQJDPfwCAmnxYMBIETjtoUkNLebaK,vdQJDPfwCAmnxYMBIETjtoUkNLebaq,vdQJDPfwCAmnxYMBIETjtoUkNLebal,vdQJDPfwCAmnxYMBIETjtoUkNLebag)=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_totalsearch()
  for vdQJDPfwCAmnxYMBIETjtoUkNLebai in vdQJDPfwCAmnxYMBIETjtoUkNLebuR:
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz=vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebRu=''
   if vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('mode')=='SEARCH_GROUP' and vdQJDPfwCAmnxYMBIETjtoUkNLebaF ==vdQJDPfwCAmnxYMBIETjtoUkNLebqK:continue
   elif vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('mode')=='SEARCH_HISTORY' and vdQJDPfwCAmnxYMBIETjtoUkNLebaK==vdQJDPfwCAmnxYMBIETjtoUkNLebqK:continue
   elif vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('mode')=='TOTAL_SEARCH' and vdQJDPfwCAmnxYMBIETjtoUkNLebaq ==vdQJDPfwCAmnxYMBIETjtoUkNLebqK:continue
   elif vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('mode')=='TOTAL_HISTORY' and vdQJDPfwCAmnxYMBIETjtoUkNLebal==vdQJDPfwCAmnxYMBIETjtoUkNLebqK:continue
   elif vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('mode')=='MENU_BOOKMARK' and vdQJDPfwCAmnxYMBIETjtoUkNLebag==vdQJDPfwCAmnxYMBIETjtoUkNLebqK:continue
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('mode'),'stype':vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('stype'),'orderby':vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('orderby'),'ordernm':vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('ordernm'),'page':'1','bandKey':vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('bandKey'),'moreUrl':vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('moreUrl'),'nextApiUrl':'-',}
   if vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    vdQJDPfwCAmnxYMBIETjtoUkNLebRW=vdQJDPfwCAmnxYMBIETjtoUkNLebqK
    vdQJDPfwCAmnxYMBIETjtoUkNLebRX =vdQJDPfwCAmnxYMBIETjtoUkNLebql
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebRW=vdQJDPfwCAmnxYMBIETjtoUkNLebql
    vdQJDPfwCAmnxYMBIETjtoUkNLebRX =vdQJDPfwCAmnxYMBIETjtoUkNLebqK
   vdQJDPfwCAmnxYMBIETjtoUkNLebRh={'title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'plot':vdQJDPfwCAmnxYMBIETjtoUkNLebaz}
   if vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('mode')=='XXX':vdQJDPfwCAmnxYMBIETjtoUkNLebRh=vdQJDPfwCAmnxYMBIETjtoUkNLebqh
   if 'icon' in vdQJDPfwCAmnxYMBIETjtoUkNLebai:vdQJDPfwCAmnxYMBIETjtoUkNLebRu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',vdQJDPfwCAmnxYMBIETjtoUkNLebai.get('icon')) 
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel='',img=vdQJDPfwCAmnxYMBIETjtoUkNLebRu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebRh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebRW,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa,isLink=vdQJDPfwCAmnxYMBIETjtoUkNLebRX)
  xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle)
 def login_main(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  (vdQJDPfwCAmnxYMBIETjtoUkNLebRK,vdQJDPfwCAmnxYMBIETjtoUkNLebRq,vdQJDPfwCAmnxYMBIETjtoUkNLebRl,vdQJDPfwCAmnxYMBIETjtoUkNLebRg)=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_account()
  if not(vdQJDPfwCAmnxYMBIETjtoUkNLebRK and vdQJDPfwCAmnxYMBIETjtoUkNLebRq):
   vdQJDPfwCAmnxYMBIETjtoUkNLebur=xbmcgui.Dialog()
   vdQJDPfwCAmnxYMBIETjtoUkNLebRs=vdQJDPfwCAmnxYMBIETjtoUkNLebur.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if vdQJDPfwCAmnxYMBIETjtoUkNLebRs==vdQJDPfwCAmnxYMBIETjtoUkNLebql:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if vdQJDPfwCAmnxYMBIETjtoUkNLebuy.cookiefile_check():return
  if base64.standard_b64encode(vdQJDPfwCAmnxYMBIETjtoUkNLebRK.encode()).decode('utf-8')=='a3ltOTUxMDg4':
   vdQJDPfwCAmnxYMBIETjtoUkNLebRy=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.GetCredential2(vdQJDPfwCAmnxYMBIETjtoUkNLebRK,vdQJDPfwCAmnxYMBIETjtoUkNLebRq,vdQJDPfwCAmnxYMBIETjtoUkNLebRl,vdQJDPfwCAmnxYMBIETjtoUkNLebRg)
  else:
   vdQJDPfwCAmnxYMBIETjtoUkNLebur=xbmcgui.Dialog()
   vdQJDPfwCAmnxYMBIETjtoUkNLebRS=vdQJDPfwCAmnxYMBIETjtoUkNLebur.browse(1,__language__(30917).encode('utf8'),'','.twc',vdQJDPfwCAmnxYMBIETjtoUkNLebqK,vdQJDPfwCAmnxYMBIETjtoUkNLebqK,'',vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
   if vdQJDPfwCAmnxYMBIETjtoUkNLebRS!='':
    vdQJDPfwCAmnxYMBIETjtoUkNLebRO=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'))
    xbmcvfs.copy(vdQJDPfwCAmnxYMBIETjtoUkNLebRS,vdQJDPfwCAmnxYMBIETjtoUkNLebRO)
    vdQJDPfwCAmnxYMBIETjtoUkNLebRy=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.WebCookies_Load(vdQJDPfwCAmnxYMBIETjtoUkNLebRO)
    xbmcvfs.delete(vdQJDPfwCAmnxYMBIETjtoUkNLebRO)
    if vdQJDPfwCAmnxYMBIETjtoUkNLebRy:
     vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.JsonFile_Save(vdQJDPfwCAmnxYMBIETjtoUkNLebug,vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.TV)
     vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_noti(__language__(30918).encode('utf8'))
     return
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebRy=vdQJDPfwCAmnxYMBIETjtoUkNLebqK
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRy==vdQJDPfwCAmnxYMBIETjtoUkNLebql:
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.cookiefile_save()
  else:
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebRz=vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('stype')
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRz=='live':
   vdQJDPfwCAmnxYMBIETjtoUkNLebRp=vdQJDPfwCAmnxYMBIETjtoUkNLebuW
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebRz=='vod':
   vdQJDPfwCAmnxYMBIETjtoUkNLebRp=vdQJDPfwCAmnxYMBIETjtoUkNLebuF
  else:
   vdQJDPfwCAmnxYMBIETjtoUkNLebRp=vdQJDPfwCAmnxYMBIETjtoUkNLebuK
  for vdQJDPfwCAmnxYMBIETjtoUkNLebRr in vdQJDPfwCAmnxYMBIETjtoUkNLebRp:
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz=vdQJDPfwCAmnxYMBIETjtoUkNLebRr.get('title')
   if vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('ordernm')!='-':
    vdQJDPfwCAmnxYMBIETjtoUkNLebaz+='  ('+vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('ordernm')+')'
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':vdQJDPfwCAmnxYMBIETjtoUkNLebRr.get('mode'),'stype':vdQJDPfwCAmnxYMBIETjtoUkNLebRr.get('stype'),'orderby':vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('orderby'),'ordernm':vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('ordernm'),'page':'1'}
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel='',img='',infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebqO(vdQJDPfwCAmnxYMBIETjtoUkNLebRp)>0:xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle)
 def dp_SubTitle_Group(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG): 
  for vdQJDPfwCAmnxYMBIETjtoUkNLebRr in vdQJDPfwCAmnxYMBIETjtoUkNLebuq:
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz=vdQJDPfwCAmnxYMBIETjtoUkNLebRr.get('title')
   if vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('ordernm')!='-':
    vdQJDPfwCAmnxYMBIETjtoUkNLebaz+='  ('+vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('ordernm')+')'
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':vdQJDPfwCAmnxYMBIETjtoUkNLebRr.get('mode'),'genreCode':vdQJDPfwCAmnxYMBIETjtoUkNLebRr.get('genreCode'),'stype':vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('stype'),'orderby':vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('orderby'),'page':'1'}
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel='',img='',infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebqO(vdQJDPfwCAmnxYMBIETjtoUkNLebuq)>0:xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle)
 def dp_LiveChannel_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebRz =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('stype')
  vdQJDPfwCAmnxYMBIETjtoUkNLebRc =vdQJDPfwCAmnxYMBIETjtoUkNLebqF(vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('page'))
  vdQJDPfwCAmnxYMBIETjtoUkNLebRV,vdQJDPfwCAmnxYMBIETjtoUkNLebRH=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.GetLiveChannelList(vdQJDPfwCAmnxYMBIETjtoUkNLebRz,vdQJDPfwCAmnxYMBIETjtoUkNLebRc)
  for vdQJDPfwCAmnxYMBIETjtoUkNLebRi in vdQJDPfwCAmnxYMBIETjtoUkNLebRV:
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebRF =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('channel')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWu =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('thumbnail')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWa =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('synopsis')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWR =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('channelepg')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWX =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('cast')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWh =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('director')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWF =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('info_genre')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWK =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('year')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWq =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('mpaa')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWl =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('premiered')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'mediatype':'episode','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'studio':vdQJDPfwCAmnxYMBIETjtoUkNLebRF,'cast':vdQJDPfwCAmnxYMBIETjtoUkNLebWX,'director':vdQJDPfwCAmnxYMBIETjtoUkNLebWh,'genre':vdQJDPfwCAmnxYMBIETjtoUkNLebWF,'plot':'%s\n%s\n%s\n\n%s'%(vdQJDPfwCAmnxYMBIETjtoUkNLebRF,vdQJDPfwCAmnxYMBIETjtoUkNLebaz,vdQJDPfwCAmnxYMBIETjtoUkNLebWR,vdQJDPfwCAmnxYMBIETjtoUkNLebWa),'year':vdQJDPfwCAmnxYMBIETjtoUkNLebWK,'mpaa':vdQJDPfwCAmnxYMBIETjtoUkNLebWq,'premiered':vdQJDPfwCAmnxYMBIETjtoUkNLebWl}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'LIVE','mediacode':vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('mediacode'),'stype':vdQJDPfwCAmnxYMBIETjtoUkNLebRz}
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebRF,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebaz,img=vdQJDPfwCAmnxYMBIETjtoUkNLebWu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebqK,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRH:
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['mode']='CHANNEL' 
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['stype']=vdQJDPfwCAmnxYMBIETjtoUkNLebRz 
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['page']=vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz='[B]%s >>[/B]'%'다음 페이지'
   vdQJDPfwCAmnxYMBIETjtoUkNLebWs=vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebRu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebWs,img=vdQJDPfwCAmnxYMBIETjtoUkNLebRu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebqO(vdQJDPfwCAmnxYMBIETjtoUkNLebRV)>0:xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
 def dp_Program_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebWy =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('stype')
  vdQJDPfwCAmnxYMBIETjtoUkNLebaS =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('orderby')
  vdQJDPfwCAmnxYMBIETjtoUkNLebRc =vdQJDPfwCAmnxYMBIETjtoUkNLebqF(vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('page'))
  vdQJDPfwCAmnxYMBIETjtoUkNLebWS=vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('genreCode')
  if vdQJDPfwCAmnxYMBIETjtoUkNLebWS==vdQJDPfwCAmnxYMBIETjtoUkNLebqh:vdQJDPfwCAmnxYMBIETjtoUkNLebWS='all'
  vdQJDPfwCAmnxYMBIETjtoUkNLebWO,vdQJDPfwCAmnxYMBIETjtoUkNLebRH=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.GetProgramList(vdQJDPfwCAmnxYMBIETjtoUkNLebWy,vdQJDPfwCAmnxYMBIETjtoUkNLebaS,vdQJDPfwCAmnxYMBIETjtoUkNLebRc,vdQJDPfwCAmnxYMBIETjtoUkNLebWS)
  for vdQJDPfwCAmnxYMBIETjtoUkNLebWz in vdQJDPfwCAmnxYMBIETjtoUkNLebWO:
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWu =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('thumbnail')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWa =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('synopsis')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWp =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('channel')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWX =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('cast')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWh =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('director')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWF=vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('info_genre')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWK =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('year')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWl =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('premiered')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWq =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('mpaa')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'mediatype':'tvshow','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'studio':vdQJDPfwCAmnxYMBIETjtoUkNLebWp,'cast':vdQJDPfwCAmnxYMBIETjtoUkNLebWX,'director':vdQJDPfwCAmnxYMBIETjtoUkNLebWh,'genre':vdQJDPfwCAmnxYMBIETjtoUkNLebWF,'year':vdQJDPfwCAmnxYMBIETjtoUkNLebWK,'premiered':vdQJDPfwCAmnxYMBIETjtoUkNLebWl,'mpaa':vdQJDPfwCAmnxYMBIETjtoUkNLebWq,'plot':vdQJDPfwCAmnxYMBIETjtoUkNLebWa}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'EPISODE','programcode':vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('program'),'page':'1'}
   if vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_makebookmark():
    vdQJDPfwCAmnxYMBIETjtoUkNLebWr={'videoid':vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('program'),'vidtype':'tvshow','vtitle':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'vsubtitle':vdQJDPfwCAmnxYMBIETjtoUkNLebWp,}
    vdQJDPfwCAmnxYMBIETjtoUkNLebWG=json.dumps(vdQJDPfwCAmnxYMBIETjtoUkNLebWr)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWG=urllib.parse.quote(vdQJDPfwCAmnxYMBIETjtoUkNLebWG)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWc='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(vdQJDPfwCAmnxYMBIETjtoUkNLebWG)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWV=[('(통합) 찜 영상에 추가',vdQJDPfwCAmnxYMBIETjtoUkNLebWc)]
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebWV=vdQJDPfwCAmnxYMBIETjtoUkNLebqh
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebWp,img=vdQJDPfwCAmnxYMBIETjtoUkNLebWu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa,ContextMenu=vdQJDPfwCAmnxYMBIETjtoUkNLebWV)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRH:
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['mode'] ='PROGRAM' 
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['stype'] =vdQJDPfwCAmnxYMBIETjtoUkNLebWy
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['orderby'] =vdQJDPfwCAmnxYMBIETjtoUkNLebaS
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['page'] =vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['genreCode']=vdQJDPfwCAmnxYMBIETjtoUkNLebWS 
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz='[B]%s >>[/B]'%'다음 페이지'
   vdQJDPfwCAmnxYMBIETjtoUkNLebWs=vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebRu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebWs,img=vdQJDPfwCAmnxYMBIETjtoUkNLebRu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  xbmcplugin.setContent(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
 def dp_4K_Program_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebRc =vdQJDPfwCAmnxYMBIETjtoUkNLebqF(vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('page'))
  vdQJDPfwCAmnxYMBIETjtoUkNLebWO,vdQJDPfwCAmnxYMBIETjtoUkNLebRH=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Get_UHD_ProgramList(vdQJDPfwCAmnxYMBIETjtoUkNLebRc)
  for vdQJDPfwCAmnxYMBIETjtoUkNLebWz in vdQJDPfwCAmnxYMBIETjtoUkNLebWO:
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWu =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('thumbnail')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWa =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('synopsis')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWp =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('channel')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWX =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('cast')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWh =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('director')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWF=vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('info_genre')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWK =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('year')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWl =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('premiered')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWq =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('mpaa')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'mediatype':'tvshow','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'studio':vdQJDPfwCAmnxYMBIETjtoUkNLebWp,'cast':vdQJDPfwCAmnxYMBIETjtoUkNLebWX,'director':vdQJDPfwCAmnxYMBIETjtoUkNLebWh,'genre':vdQJDPfwCAmnxYMBIETjtoUkNLebWF,'year':vdQJDPfwCAmnxYMBIETjtoUkNLebWK,'premiered':vdQJDPfwCAmnxYMBIETjtoUkNLebWl,'mpaa':vdQJDPfwCAmnxYMBIETjtoUkNLebWq,'plot':vdQJDPfwCAmnxYMBIETjtoUkNLebWa}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'EPISODE','programcode':vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('program'),'page':'1'}
   if vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_makebookmark():
    vdQJDPfwCAmnxYMBIETjtoUkNLebWr={'videoid':vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('program'),'vidtype':'tvshow','vtitle':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'vsubtitle':vdQJDPfwCAmnxYMBIETjtoUkNLebWp,}
    vdQJDPfwCAmnxYMBIETjtoUkNLebWG=json.dumps(vdQJDPfwCAmnxYMBIETjtoUkNLebWr)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWG=urllib.parse.quote(vdQJDPfwCAmnxYMBIETjtoUkNLebWG)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWc='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(vdQJDPfwCAmnxYMBIETjtoUkNLebWG)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWV=[('(통합) 찜 영상에 추가',vdQJDPfwCAmnxYMBIETjtoUkNLebWc)]
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebWV=vdQJDPfwCAmnxYMBIETjtoUkNLebqh
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebWp,img=vdQJDPfwCAmnxYMBIETjtoUkNLebWu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa,ContextMenu=vdQJDPfwCAmnxYMBIETjtoUkNLebWV)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRH:
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['mode'] ='4K_PROGRAM' 
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['page'] =vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz='[B]%s >>[/B]'%'다음 페이지'
   vdQJDPfwCAmnxYMBIETjtoUkNLebWs=vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebRu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebWs,img=vdQJDPfwCAmnxYMBIETjtoUkNLebRu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  xbmcplugin.setContent(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
 def dp_Ori_Program_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebRc =vdQJDPfwCAmnxYMBIETjtoUkNLebqF(vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('page'))
  vdQJDPfwCAmnxYMBIETjtoUkNLebWO,vdQJDPfwCAmnxYMBIETjtoUkNLebRH=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Get_Origianl_ProgramList(vdQJDPfwCAmnxYMBIETjtoUkNLebRc)
  for vdQJDPfwCAmnxYMBIETjtoUkNLebWz in vdQJDPfwCAmnxYMBIETjtoUkNLebWO:
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWu =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('thumbnail')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWi =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('vod_type')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXu =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('vod_code')
   if vdQJDPfwCAmnxYMBIETjtoUkNLebWi=='vod':
    vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'mediatype':'tvshow','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,}
    vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'EPISODE','programcode':vdQJDPfwCAmnxYMBIETjtoUkNLebXu,'page':'1',}
    vdQJDPfwCAmnxYMBIETjtoUkNLebRW=vdQJDPfwCAmnxYMBIETjtoUkNLebql
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'mediatype':'movie','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'plot':'movie',}
    vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'MOVIE','mediacode':vdQJDPfwCAmnxYMBIETjtoUkNLebXu,'stype':'movie','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'thumbnail':vdQJDPfwCAmnxYMBIETjtoUkNLebWu,}
    vdQJDPfwCAmnxYMBIETjtoUkNLebRW=vdQJDPfwCAmnxYMBIETjtoUkNLebqK
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,img=vdQJDPfwCAmnxYMBIETjtoUkNLebWu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebRW,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa,ContextMenu=vdQJDPfwCAmnxYMBIETjtoUkNLebqh)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRH:
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['mode'] ='ORI_PROGRAM' 
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['page'] =vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz='[B]%s >>[/B]'%'다음 페이지'
   vdQJDPfwCAmnxYMBIETjtoUkNLebWs=vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebRu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebWs,img=vdQJDPfwCAmnxYMBIETjtoUkNLebRu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  xbmcplugin.setContent(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
 def dp_Episode_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebXa=vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('programcode')
  vdQJDPfwCAmnxYMBIETjtoUkNLebRc =vdQJDPfwCAmnxYMBIETjtoUkNLebqF(vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('page'))
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_log('programcode : '+vdQJDPfwCAmnxYMBIETjtoUkNLebXa)
  vdQJDPfwCAmnxYMBIETjtoUkNLebXR,vdQJDPfwCAmnxYMBIETjtoUkNLebRH,vdQJDPfwCAmnxYMBIETjtoUkNLebXW=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.GetEpisodeList(vdQJDPfwCAmnxYMBIETjtoUkNLebXa,vdQJDPfwCAmnxYMBIETjtoUkNLebRc,orderby=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_winEpisodeOrderby())
  for vdQJDPfwCAmnxYMBIETjtoUkNLebXh in vdQJDPfwCAmnxYMBIETjtoUkNLebXR:
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz =vdQJDPfwCAmnxYMBIETjtoUkNLebXh.get('title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWs =vdQJDPfwCAmnxYMBIETjtoUkNLebXh.get('subtitle')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWu =vdQJDPfwCAmnxYMBIETjtoUkNLebXh.get('thumbnail')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWa =vdQJDPfwCAmnxYMBIETjtoUkNLebXh.get('synopsis')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXF=vdQJDPfwCAmnxYMBIETjtoUkNLebXh.get('info_title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXK =vdQJDPfwCAmnxYMBIETjtoUkNLebXh.get('aired')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXq =vdQJDPfwCAmnxYMBIETjtoUkNLebXh.get('studio')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXl =vdQJDPfwCAmnxYMBIETjtoUkNLebXh.get('frequency')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'mediatype':'episode','title':vdQJDPfwCAmnxYMBIETjtoUkNLebXF,'aired':vdQJDPfwCAmnxYMBIETjtoUkNLebXK,'studio':vdQJDPfwCAmnxYMBIETjtoUkNLebXq,'episode':vdQJDPfwCAmnxYMBIETjtoUkNLebXl,'plot':vdQJDPfwCAmnxYMBIETjtoUkNLebWa}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'VOD','mediacode':vdQJDPfwCAmnxYMBIETjtoUkNLebXh.get('episode'),'stype':'vod','programcode':vdQJDPfwCAmnxYMBIETjtoUkNLebXa,'title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'thumbnail':vdQJDPfwCAmnxYMBIETjtoUkNLebWu}
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebWs,img=vdQJDPfwCAmnxYMBIETjtoUkNLebWu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebqK,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRc==1:
   vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'plot':'정렬순서를 변경합니다.'}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['mode'] ='ORDER_BY' 
   if vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_winEpisodeOrderby()=='desc':
    vdQJDPfwCAmnxYMBIETjtoUkNLebaz='정렬순서변경 : 최신화부터 -> 1회부터'
    vdQJDPfwCAmnxYMBIETjtoUkNLebRa['orderby']='asc'
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebaz='정렬순서변경 : 1회부터 -> 최신화부터'
    vdQJDPfwCAmnxYMBIETjtoUkNLebRa['orderby']='desc'
   vdQJDPfwCAmnxYMBIETjtoUkNLebRu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel='',img=vdQJDPfwCAmnxYMBIETjtoUkNLebRu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebqK,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa,isLink=vdQJDPfwCAmnxYMBIETjtoUkNLebql)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRH:
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['mode'] ='EPISODE' 
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['programcode']=vdQJDPfwCAmnxYMBIETjtoUkNLebXa
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['page'] =vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz='[B]%s >>[/B]'%'다음 페이지'
   vdQJDPfwCAmnxYMBIETjtoUkNLebWs=vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebRu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebWs,img=vdQJDPfwCAmnxYMBIETjtoUkNLebRu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  xbmcplugin.setContent(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,'episodes')
  if vdQJDPfwCAmnxYMBIETjtoUkNLebqO(vdQJDPfwCAmnxYMBIETjtoUkNLebXR)>0:xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebql)
 def dp_setEpOrderby(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebaS =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('orderby')
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.set_winEpisodeOrderby(vdQJDPfwCAmnxYMBIETjtoUkNLebaS)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebWy =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('stype')
  vdQJDPfwCAmnxYMBIETjtoUkNLebaS =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('orderby')
  vdQJDPfwCAmnxYMBIETjtoUkNLebRc=vdQJDPfwCAmnxYMBIETjtoUkNLebqF(vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('page'))
  vdQJDPfwCAmnxYMBIETjtoUkNLebXg,vdQJDPfwCAmnxYMBIETjtoUkNLebRH=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.GetMovieList(vdQJDPfwCAmnxYMBIETjtoUkNLebWy,vdQJDPfwCAmnxYMBIETjtoUkNLebaS,vdQJDPfwCAmnxYMBIETjtoUkNLebRc)
  for vdQJDPfwCAmnxYMBIETjtoUkNLebXs in vdQJDPfwCAmnxYMBIETjtoUkNLebXg:
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWu =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('thumbnail')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWa =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('synopsis')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXF =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('info_title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWK =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('year')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWX =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('cast')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWh =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('director')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWF =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('info_genre')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXy =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('duration')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWl =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('premiered')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXq =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('studio')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWq =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('mpaa')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'mediatype':'movie','title':vdQJDPfwCAmnxYMBIETjtoUkNLebXF,'year':vdQJDPfwCAmnxYMBIETjtoUkNLebWK,'cast':vdQJDPfwCAmnxYMBIETjtoUkNLebWX,'director':vdQJDPfwCAmnxYMBIETjtoUkNLebWh,'genre':vdQJDPfwCAmnxYMBIETjtoUkNLebWF,'duration':vdQJDPfwCAmnxYMBIETjtoUkNLebXy,'premiered':vdQJDPfwCAmnxYMBIETjtoUkNLebWl,'studio':vdQJDPfwCAmnxYMBIETjtoUkNLebXq,'mpaa':vdQJDPfwCAmnxYMBIETjtoUkNLebWq,'plot':vdQJDPfwCAmnxYMBIETjtoUkNLebWa}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'MOVIE','mediacode':vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('moviecode'),'stype':'movie','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'thumbnail':vdQJDPfwCAmnxYMBIETjtoUkNLebWu}
   if vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_makebookmark():
    vdQJDPfwCAmnxYMBIETjtoUkNLebWr={'videoid':vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('moviecode'),'vidtype':'movie','vtitle':vdQJDPfwCAmnxYMBIETjtoUkNLebXF,'vsubtitle':'',}
    vdQJDPfwCAmnxYMBIETjtoUkNLebWG=json.dumps(vdQJDPfwCAmnxYMBIETjtoUkNLebWr)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWG=urllib.parse.quote(vdQJDPfwCAmnxYMBIETjtoUkNLebWG)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWc='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(vdQJDPfwCAmnxYMBIETjtoUkNLebWG)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWV=[('(통합) 찜 영상에 추가',vdQJDPfwCAmnxYMBIETjtoUkNLebWc)]
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebWV=vdQJDPfwCAmnxYMBIETjtoUkNLebqh
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel='',img=vdQJDPfwCAmnxYMBIETjtoUkNLebWu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebqK,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa,ContextMenu=vdQJDPfwCAmnxYMBIETjtoUkNLebWV)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRH:
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['mode'] ='MOVIE_SUB' 
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['orderby']=vdQJDPfwCAmnxYMBIETjtoUkNLebaS
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['stype'] =vdQJDPfwCAmnxYMBIETjtoUkNLebWy
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['page'] =vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz='[B]%s >>[/B]'%'다음 페이지'
   vdQJDPfwCAmnxYMBIETjtoUkNLebWs=vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebRu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebWs,img=vdQJDPfwCAmnxYMBIETjtoUkNLebRu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  xbmcplugin.setContent(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,'movies')
  xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
 def dp_4K_Movie_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebRc=vdQJDPfwCAmnxYMBIETjtoUkNLebqF(vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('page'))
  vdQJDPfwCAmnxYMBIETjtoUkNLebXg,vdQJDPfwCAmnxYMBIETjtoUkNLebRH=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Get_UHD_MovieList(vdQJDPfwCAmnxYMBIETjtoUkNLebRc)
  for vdQJDPfwCAmnxYMBIETjtoUkNLebXs in vdQJDPfwCAmnxYMBIETjtoUkNLebXg:
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWu =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('thumbnail')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWa =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('synopsis')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXF =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('info_title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWK =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('year')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWX =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('cast')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWh =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('director')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWF =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('info_genre')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXy =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('duration')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWl =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('premiered')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXq =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('studio')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWq =vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('mpaa')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'mediatype':'movie','title':vdQJDPfwCAmnxYMBIETjtoUkNLebXF,'year':vdQJDPfwCAmnxYMBIETjtoUkNLebWK,'cast':vdQJDPfwCAmnxYMBIETjtoUkNLebWX,'director':vdQJDPfwCAmnxYMBIETjtoUkNLebWh,'genre':vdQJDPfwCAmnxYMBIETjtoUkNLebWF,'duration':vdQJDPfwCAmnxYMBIETjtoUkNLebXy,'premiered':vdQJDPfwCAmnxYMBIETjtoUkNLebWl,'studio':vdQJDPfwCAmnxYMBIETjtoUkNLebXq,'mpaa':vdQJDPfwCAmnxYMBIETjtoUkNLebWq,'plot':vdQJDPfwCAmnxYMBIETjtoUkNLebWa}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'MOVIE','mediacode':vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('moviecode'),'stype':'movie','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'thumbnail':vdQJDPfwCAmnxYMBIETjtoUkNLebWu}
   if vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_makebookmark():
    vdQJDPfwCAmnxYMBIETjtoUkNLebWr={'videoid':vdQJDPfwCAmnxYMBIETjtoUkNLebXs.get('moviecode'),'vidtype':'movie','vtitle':vdQJDPfwCAmnxYMBIETjtoUkNLebXF,'vsubtitle':'',}
    vdQJDPfwCAmnxYMBIETjtoUkNLebWG=json.dumps(vdQJDPfwCAmnxYMBIETjtoUkNLebWr)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWG=urllib.parse.quote(vdQJDPfwCAmnxYMBIETjtoUkNLebWG)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWc='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(vdQJDPfwCAmnxYMBIETjtoUkNLebWG)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWV=[('(통합) 찜 영상에 추가',vdQJDPfwCAmnxYMBIETjtoUkNLebWc)]
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebWV=vdQJDPfwCAmnxYMBIETjtoUkNLebqh
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel='',img=vdQJDPfwCAmnxYMBIETjtoUkNLebWu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebqK,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa,ContextMenu=vdQJDPfwCAmnxYMBIETjtoUkNLebWV)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRH:
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['mode'] ='4K_MOVIE' 
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['page'] =vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz='[B]%s >>[/B]'%'다음 페이지'
   vdQJDPfwCAmnxYMBIETjtoUkNLebWs=vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebRu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebWs,img=vdQJDPfwCAmnxYMBIETjtoUkNLebRu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  xbmcplugin.setContent(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,'movies')
  xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
 def dp_Set_Bookmark(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebXS=urllib.parse.unquote(vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('bm_param'))
  vdQJDPfwCAmnxYMBIETjtoUkNLebXS=json.loads(vdQJDPfwCAmnxYMBIETjtoUkNLebXS)
  vdQJDPfwCAmnxYMBIETjtoUkNLebXO =vdQJDPfwCAmnxYMBIETjtoUkNLebXS.get('videoid')
  vdQJDPfwCAmnxYMBIETjtoUkNLebXz =vdQJDPfwCAmnxYMBIETjtoUkNLebXS.get('vidtype')
  vdQJDPfwCAmnxYMBIETjtoUkNLebXp =vdQJDPfwCAmnxYMBIETjtoUkNLebXS.get('vtitle')
  vdQJDPfwCAmnxYMBIETjtoUkNLebXr =vdQJDPfwCAmnxYMBIETjtoUkNLebXS.get('vsubtitle')
  vdQJDPfwCAmnxYMBIETjtoUkNLebur=xbmcgui.Dialog()
  vdQJDPfwCAmnxYMBIETjtoUkNLebRs=vdQJDPfwCAmnxYMBIETjtoUkNLebur.yesno(__language__(30913).encode('utf8'),vdQJDPfwCAmnxYMBIETjtoUkNLebXp+' \n\n'+__language__(30914))
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRs==vdQJDPfwCAmnxYMBIETjtoUkNLebqK:return
  vdQJDPfwCAmnxYMBIETjtoUkNLebXG=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.GetBookmarkInfo(vdQJDPfwCAmnxYMBIETjtoUkNLebXO,vdQJDPfwCAmnxYMBIETjtoUkNLebXz)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebXr!='':
   vdQJDPfwCAmnxYMBIETjtoUkNLebXG['saveinfo']['subtitle']=vdQJDPfwCAmnxYMBIETjtoUkNLebXr 
   if vdQJDPfwCAmnxYMBIETjtoUkNLebXz=='tvshow':vdQJDPfwCAmnxYMBIETjtoUkNLebXG['saveinfo']['infoLabels']['studio']=vdQJDPfwCAmnxYMBIETjtoUkNLebXr 
  vdQJDPfwCAmnxYMBIETjtoUkNLebXc=json.dumps(vdQJDPfwCAmnxYMBIETjtoUkNLebXG)
  vdQJDPfwCAmnxYMBIETjtoUkNLebXc=urllib.parse.quote(vdQJDPfwCAmnxYMBIETjtoUkNLebXc)
  vdQJDPfwCAmnxYMBIETjtoUkNLebWc ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(vdQJDPfwCAmnxYMBIETjtoUkNLebXc)
  xbmc.executebuiltin(vdQJDPfwCAmnxYMBIETjtoUkNLebWc)
 def dp_Search_Group(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  if 'search_key' in vdQJDPfwCAmnxYMBIETjtoUkNLebRG:
   vdQJDPfwCAmnxYMBIETjtoUkNLebXV=vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('search_key')
  else:
   vdQJDPfwCAmnxYMBIETjtoUkNLebXV=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not vdQJDPfwCAmnxYMBIETjtoUkNLebXV:
    return
  for vdQJDPfwCAmnxYMBIETjtoUkNLebRr in vdQJDPfwCAmnxYMBIETjtoUkNLebuh:
   vdQJDPfwCAmnxYMBIETjtoUkNLebXH =vdQJDPfwCAmnxYMBIETjtoUkNLebRr.get('mode')
   vdQJDPfwCAmnxYMBIETjtoUkNLebRz=vdQJDPfwCAmnxYMBIETjtoUkNLebRr.get('stype')
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz=vdQJDPfwCAmnxYMBIETjtoUkNLebRr.get('title')
   (vdQJDPfwCAmnxYMBIETjtoUkNLebXi,vdQJDPfwCAmnxYMBIETjtoUkNLebRH)=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.GetSearchList(vdQJDPfwCAmnxYMBIETjtoUkNLebXV,1,vdQJDPfwCAmnxYMBIETjtoUkNLebRz)
   vdQJDPfwCAmnxYMBIETjtoUkNLebRh={'plot':'검색어 : '+vdQJDPfwCAmnxYMBIETjtoUkNLebXV+'\n\n'+vdQJDPfwCAmnxYMBIETjtoUkNLebuy.Search_FreeList(vdQJDPfwCAmnxYMBIETjtoUkNLebXi)}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':vdQJDPfwCAmnxYMBIETjtoUkNLebXH,'stype':vdQJDPfwCAmnxYMBIETjtoUkNLebRz,'search_key':vdQJDPfwCAmnxYMBIETjtoUkNLebXV,'page':'1',}
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel='',img='',infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebRh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebqO(vdQJDPfwCAmnxYMBIETjtoUkNLebuh)>0:xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebql)
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.Save_Searched_List(vdQJDPfwCAmnxYMBIETjtoUkNLebXV)
 def Search_FreeList(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebhl):
  vdQJDPfwCAmnxYMBIETjtoUkNLebhu=''
  vdQJDPfwCAmnxYMBIETjtoUkNLebha=7
  try:
   if vdQJDPfwCAmnxYMBIETjtoUkNLebqO(vdQJDPfwCAmnxYMBIETjtoUkNLebhl)==0:return '검색결과 없음'
   for i in vdQJDPfwCAmnxYMBIETjtoUkNLebqp(vdQJDPfwCAmnxYMBIETjtoUkNLebqO(vdQJDPfwCAmnxYMBIETjtoUkNLebhl)):
    if i>=vdQJDPfwCAmnxYMBIETjtoUkNLebha:
     vdQJDPfwCAmnxYMBIETjtoUkNLebhu=vdQJDPfwCAmnxYMBIETjtoUkNLebhu+'...'
     break
    vdQJDPfwCAmnxYMBIETjtoUkNLebhu=vdQJDPfwCAmnxYMBIETjtoUkNLebhu+vdQJDPfwCAmnxYMBIETjtoUkNLebhl[i]['title']+'\n'
  except:
   return ''
  return vdQJDPfwCAmnxYMBIETjtoUkNLebhu
 def dp_Search_History(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebhR=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.Load_List_File('search')
  for vdQJDPfwCAmnxYMBIETjtoUkNLebhW in vdQJDPfwCAmnxYMBIETjtoUkNLebhR:
   vdQJDPfwCAmnxYMBIETjtoUkNLebhX=vdQJDPfwCAmnxYMBIETjtoUkNLebqs(urllib.parse.parse_qsl(vdQJDPfwCAmnxYMBIETjtoUkNLebhW))
   vdQJDPfwCAmnxYMBIETjtoUkNLebhF=vdQJDPfwCAmnxYMBIETjtoUkNLebhX.get('skey').strip()
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'SEARCH_GROUP','search_key':vdQJDPfwCAmnxYMBIETjtoUkNLebhF,}
   vdQJDPfwCAmnxYMBIETjtoUkNLebhK={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':vdQJDPfwCAmnxYMBIETjtoUkNLebhF,'vType':'-',}
   vdQJDPfwCAmnxYMBIETjtoUkNLebhq=urllib.parse.urlencode(vdQJDPfwCAmnxYMBIETjtoUkNLebhK)
   vdQJDPfwCAmnxYMBIETjtoUkNLebWV=[('선택된 검색어 ( %s ) 삭제'%(vdQJDPfwCAmnxYMBIETjtoUkNLebhF),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(vdQJDPfwCAmnxYMBIETjtoUkNLebhq))]
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebhF,sublabel='',img=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa,ContextMenu=vdQJDPfwCAmnxYMBIETjtoUkNLebWV)
  vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'plot':'검색목록 전체를 삭제합니다.'}
  vdQJDPfwCAmnxYMBIETjtoUkNLebaz='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  vdQJDPfwCAmnxYMBIETjtoUkNLebRu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel='',img=vdQJDPfwCAmnxYMBIETjtoUkNLebRu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebqK,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa,isLink=vdQJDPfwCAmnxYMBIETjtoUkNLebql)
  xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
 def dp_Search_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebRc =vdQJDPfwCAmnxYMBIETjtoUkNLebqF(vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('page'))
  vdQJDPfwCAmnxYMBIETjtoUkNLebRz =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('stype')
  if 'search_key' in vdQJDPfwCAmnxYMBIETjtoUkNLebRG:
   vdQJDPfwCAmnxYMBIETjtoUkNLebXV=vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('search_key')
  else:
   vdQJDPfwCAmnxYMBIETjtoUkNLebXV=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not vdQJDPfwCAmnxYMBIETjtoUkNLebXV:
    xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle)
    return
  vdQJDPfwCAmnxYMBIETjtoUkNLebXi,vdQJDPfwCAmnxYMBIETjtoUkNLebRH=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.GetSearchList(vdQJDPfwCAmnxYMBIETjtoUkNLebXV,vdQJDPfwCAmnxYMBIETjtoUkNLebRc,vdQJDPfwCAmnxYMBIETjtoUkNLebRz)
  for vdQJDPfwCAmnxYMBIETjtoUkNLebhl in vdQJDPfwCAmnxYMBIETjtoUkNLebXi:
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz =vdQJDPfwCAmnxYMBIETjtoUkNLebhl.get('title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWu =vdQJDPfwCAmnxYMBIETjtoUkNLebhl.get('thumbnail')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWa =vdQJDPfwCAmnxYMBIETjtoUkNLebhl.get('synopsis')
   vdQJDPfwCAmnxYMBIETjtoUkNLebhg =vdQJDPfwCAmnxYMBIETjtoUkNLebhl.get('program')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWX =vdQJDPfwCAmnxYMBIETjtoUkNLebhl.get('cast')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWh =vdQJDPfwCAmnxYMBIETjtoUkNLebhl.get('director')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWF=vdQJDPfwCAmnxYMBIETjtoUkNLebhl.get('info_genre')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXy =vdQJDPfwCAmnxYMBIETjtoUkNLebhl.get('duration')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWq =vdQJDPfwCAmnxYMBIETjtoUkNLebhl.get('mpaa')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWK =vdQJDPfwCAmnxYMBIETjtoUkNLebhl.get('year')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXK =vdQJDPfwCAmnxYMBIETjtoUkNLebhl.get('aired')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'mediatype':'tvshow' if vdQJDPfwCAmnxYMBIETjtoUkNLebRz=='vod' else 'movie','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'cast':vdQJDPfwCAmnxYMBIETjtoUkNLebWX,'director':vdQJDPfwCAmnxYMBIETjtoUkNLebWh,'genre':vdQJDPfwCAmnxYMBIETjtoUkNLebWF,'duration':vdQJDPfwCAmnxYMBIETjtoUkNLebXy,'mpaa':vdQJDPfwCAmnxYMBIETjtoUkNLebWq,'year':vdQJDPfwCAmnxYMBIETjtoUkNLebWK,'aired':vdQJDPfwCAmnxYMBIETjtoUkNLebXK,'plot':'%s\n\n%s'%(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,vdQJDPfwCAmnxYMBIETjtoUkNLebWa)}
   if vdQJDPfwCAmnxYMBIETjtoUkNLebRz=='vod':
    vdQJDPfwCAmnxYMBIETjtoUkNLebXO=vdQJDPfwCAmnxYMBIETjtoUkNLebhl.get('program')
    vdQJDPfwCAmnxYMBIETjtoUkNLebXz='tvshow'
    vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'EPISODE','programcode':vdQJDPfwCAmnxYMBIETjtoUkNLebXO,'page':'1',}
    vdQJDPfwCAmnxYMBIETjtoUkNLebRW=vdQJDPfwCAmnxYMBIETjtoUkNLebql
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebXO=vdQJDPfwCAmnxYMBIETjtoUkNLebhl.get('movie')
    vdQJDPfwCAmnxYMBIETjtoUkNLebXz='movie'
    vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'MOVIE','mediacode':vdQJDPfwCAmnxYMBIETjtoUkNLebXO,'stype':'movie','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'thumbnail':vdQJDPfwCAmnxYMBIETjtoUkNLebWu,}
    vdQJDPfwCAmnxYMBIETjtoUkNLebRW=vdQJDPfwCAmnxYMBIETjtoUkNLebqK
   if vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_makebookmark():
    vdQJDPfwCAmnxYMBIETjtoUkNLebWr={'videoid':vdQJDPfwCAmnxYMBIETjtoUkNLebXO,'vidtype':vdQJDPfwCAmnxYMBIETjtoUkNLebXz,'vtitle':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'vsubtitle':'',}
    vdQJDPfwCAmnxYMBIETjtoUkNLebWG=json.dumps(vdQJDPfwCAmnxYMBIETjtoUkNLebWr)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWG=urllib.parse.quote(vdQJDPfwCAmnxYMBIETjtoUkNLebWG)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWc='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(vdQJDPfwCAmnxYMBIETjtoUkNLebWG)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWV=[('(통합) 찜 영상에 추가',vdQJDPfwCAmnxYMBIETjtoUkNLebWc)]
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebWV=vdQJDPfwCAmnxYMBIETjtoUkNLebqh
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel='',img=vdQJDPfwCAmnxYMBIETjtoUkNLebWu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebRW,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa,isLink=vdQJDPfwCAmnxYMBIETjtoUkNLebqK,ContextMenu=vdQJDPfwCAmnxYMBIETjtoUkNLebWV)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRH:
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['mode'] ='SEARCH' 
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['search_key']=vdQJDPfwCAmnxYMBIETjtoUkNLebXV
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['page'] =vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz='[B]%s >>[/B]'%'다음 페이지'
   vdQJDPfwCAmnxYMBIETjtoUkNLebWs=vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebRu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebWs,img=vdQJDPfwCAmnxYMBIETjtoUkNLebRu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRz=='movie':xbmcplugin.setContent(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,'movies')
  else:xbmcplugin.setContent(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
 def dp_History_Remove(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebhs=vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('delType')
  vdQJDPfwCAmnxYMBIETjtoUkNLebhy =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('sKey')
  vdQJDPfwCAmnxYMBIETjtoUkNLebhS =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('vType')
  vdQJDPfwCAmnxYMBIETjtoUkNLebur=xbmcgui.Dialog()
  if vdQJDPfwCAmnxYMBIETjtoUkNLebhs=='SEARCH_ALL':
   vdQJDPfwCAmnxYMBIETjtoUkNLebRs=vdQJDPfwCAmnxYMBIETjtoUkNLebur.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebhs=='SEARCH_ONE':
   vdQJDPfwCAmnxYMBIETjtoUkNLebRs=vdQJDPfwCAmnxYMBIETjtoUkNLebur.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebhs=='WATCH_ALL':
   vdQJDPfwCAmnxYMBIETjtoUkNLebRs=vdQJDPfwCAmnxYMBIETjtoUkNLebur.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebhs=='WATCH_ONE':
   vdQJDPfwCAmnxYMBIETjtoUkNLebRs=vdQJDPfwCAmnxYMBIETjtoUkNLebur.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRs==vdQJDPfwCAmnxYMBIETjtoUkNLebqK:sys.exit()
  if vdQJDPfwCAmnxYMBIETjtoUkNLebhs=='SEARCH_ALL':
   if os.path.isfile(vdQJDPfwCAmnxYMBIETjtoUkNLebus):os.remove(vdQJDPfwCAmnxYMBIETjtoUkNLebus)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebhs=='SEARCH_ONE':
   try:
    vdQJDPfwCAmnxYMBIETjtoUkNLebhO=vdQJDPfwCAmnxYMBIETjtoUkNLebus
    vdQJDPfwCAmnxYMBIETjtoUkNLebhz=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.Load_List_File('search') 
    fp=vdQJDPfwCAmnxYMBIETjtoUkNLebqr(vdQJDPfwCAmnxYMBIETjtoUkNLebhO,'w',-1,'utf-8')
    for vdQJDPfwCAmnxYMBIETjtoUkNLebhp in vdQJDPfwCAmnxYMBIETjtoUkNLebhz:
     vdQJDPfwCAmnxYMBIETjtoUkNLebhr=vdQJDPfwCAmnxYMBIETjtoUkNLebqs(urllib.parse.parse_qsl(vdQJDPfwCAmnxYMBIETjtoUkNLebhp))
     vdQJDPfwCAmnxYMBIETjtoUkNLebhG=vdQJDPfwCAmnxYMBIETjtoUkNLebhr.get('skey').strip()
     if vdQJDPfwCAmnxYMBIETjtoUkNLebhy!=vdQJDPfwCAmnxYMBIETjtoUkNLebhG:
      fp.write(vdQJDPfwCAmnxYMBIETjtoUkNLebhp)
    fp.close()
   except:
    vdQJDPfwCAmnxYMBIETjtoUkNLebqh
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebhs=='WATCH_ALL':
   vdQJDPfwCAmnxYMBIETjtoUkNLebhO=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%vdQJDPfwCAmnxYMBIETjtoUkNLebhS))
   if os.path.isfile(vdQJDPfwCAmnxYMBIETjtoUkNLebhO):os.remove(vdQJDPfwCAmnxYMBIETjtoUkNLebhO)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebhs=='WATCH_ONE':
   vdQJDPfwCAmnxYMBIETjtoUkNLebhO=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%vdQJDPfwCAmnxYMBIETjtoUkNLebhS))
   try:
    vdQJDPfwCAmnxYMBIETjtoUkNLebhz=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.Load_List_File(vdQJDPfwCAmnxYMBIETjtoUkNLebhS) 
    fp=vdQJDPfwCAmnxYMBIETjtoUkNLebqr(vdQJDPfwCAmnxYMBIETjtoUkNLebhO,'w',-1,'utf-8')
    for vdQJDPfwCAmnxYMBIETjtoUkNLebhp in vdQJDPfwCAmnxYMBIETjtoUkNLebhz:
     vdQJDPfwCAmnxYMBIETjtoUkNLebhr=vdQJDPfwCAmnxYMBIETjtoUkNLebqs(urllib.parse.parse_qsl(vdQJDPfwCAmnxYMBIETjtoUkNLebhp))
     vdQJDPfwCAmnxYMBIETjtoUkNLebhG=vdQJDPfwCAmnxYMBIETjtoUkNLebhr.get('code').strip()
     if vdQJDPfwCAmnxYMBIETjtoUkNLebhy!=vdQJDPfwCAmnxYMBIETjtoUkNLebhG:
      fp.write(vdQJDPfwCAmnxYMBIETjtoUkNLebhp)
    fp.close()
   except:
    vdQJDPfwCAmnxYMBIETjtoUkNLebqh
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRz): 
  try:
   if vdQJDPfwCAmnxYMBIETjtoUkNLebRz=='search':
    vdQJDPfwCAmnxYMBIETjtoUkNLebhO=vdQJDPfwCAmnxYMBIETjtoUkNLebus
   elif vdQJDPfwCAmnxYMBIETjtoUkNLebRz in['vod','movie']:
    vdQJDPfwCAmnxYMBIETjtoUkNLebhO=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%vdQJDPfwCAmnxYMBIETjtoUkNLebRz))
   else:
    return[]
   fp=vdQJDPfwCAmnxYMBIETjtoUkNLebqr(vdQJDPfwCAmnxYMBIETjtoUkNLebhO,'r',-1,'utf-8')
   vdQJDPfwCAmnxYMBIETjtoUkNLebhc=fp.readlines()
   fp.close()
  except:
   vdQJDPfwCAmnxYMBIETjtoUkNLebhc=[]
  return vdQJDPfwCAmnxYMBIETjtoUkNLebhc
 def Save_Watched_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRz,vdQJDPfwCAmnxYMBIETjtoUkNLebuz):
  try:
   vdQJDPfwCAmnxYMBIETjtoUkNLebhV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%vdQJDPfwCAmnxYMBIETjtoUkNLebRz))
   vdQJDPfwCAmnxYMBIETjtoUkNLebhz=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.Load_List_File(vdQJDPfwCAmnxYMBIETjtoUkNLebRz) 
   fp=vdQJDPfwCAmnxYMBIETjtoUkNLebqr(vdQJDPfwCAmnxYMBIETjtoUkNLebhV,'w',-1,'utf-8')
   vdQJDPfwCAmnxYMBIETjtoUkNLebhH=urllib.parse.urlencode(vdQJDPfwCAmnxYMBIETjtoUkNLebuz)
   vdQJDPfwCAmnxYMBIETjtoUkNLebhH=vdQJDPfwCAmnxYMBIETjtoUkNLebhH+'\n'
   fp.write(vdQJDPfwCAmnxYMBIETjtoUkNLebhH)
   vdQJDPfwCAmnxYMBIETjtoUkNLebhi=0
   for vdQJDPfwCAmnxYMBIETjtoUkNLebhp in vdQJDPfwCAmnxYMBIETjtoUkNLebhz:
    vdQJDPfwCAmnxYMBIETjtoUkNLebhr=vdQJDPfwCAmnxYMBIETjtoUkNLebqs(urllib.parse.parse_qsl(vdQJDPfwCAmnxYMBIETjtoUkNLebhp))
    vdQJDPfwCAmnxYMBIETjtoUkNLebFu=vdQJDPfwCAmnxYMBIETjtoUkNLebuz.get('code').strip()
    vdQJDPfwCAmnxYMBIETjtoUkNLebFa=vdQJDPfwCAmnxYMBIETjtoUkNLebhr.get('code').strip()
    if vdQJDPfwCAmnxYMBIETjtoUkNLebRz=='vod' and vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_direct_replay()==vdQJDPfwCAmnxYMBIETjtoUkNLebql:
     vdQJDPfwCAmnxYMBIETjtoUkNLebFu=vdQJDPfwCAmnxYMBIETjtoUkNLebuz.get('videoid').strip()
     vdQJDPfwCAmnxYMBIETjtoUkNLebFa=vdQJDPfwCAmnxYMBIETjtoUkNLebhr.get('videoid').strip()if vdQJDPfwCAmnxYMBIETjtoUkNLebFa!=vdQJDPfwCAmnxYMBIETjtoUkNLebqh else '-'
    if vdQJDPfwCAmnxYMBIETjtoUkNLebFu!=vdQJDPfwCAmnxYMBIETjtoUkNLebFa:
     fp.write(vdQJDPfwCAmnxYMBIETjtoUkNLebhp)
     vdQJDPfwCAmnxYMBIETjtoUkNLebhi+=1
     if vdQJDPfwCAmnxYMBIETjtoUkNLebhi>=50:break
   fp.close()
  except:
   vdQJDPfwCAmnxYMBIETjtoUkNLebqh
 def dp_Watch_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebRz =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('stype')
  vdQJDPfwCAmnxYMBIETjtoUkNLebas=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_direct_replay()
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRz=='-':
   for vdQJDPfwCAmnxYMBIETjtoUkNLebRr in vdQJDPfwCAmnxYMBIETjtoUkNLebuX:
    vdQJDPfwCAmnxYMBIETjtoUkNLebaz=vdQJDPfwCAmnxYMBIETjtoUkNLebRr.get('title')
    vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':vdQJDPfwCAmnxYMBIETjtoUkNLebRr.get('mode'),'stype':vdQJDPfwCAmnxYMBIETjtoUkNLebRr.get('stype')}
    vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel='',img='',infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
   if vdQJDPfwCAmnxYMBIETjtoUkNLebqO(vdQJDPfwCAmnxYMBIETjtoUkNLebuX)>0:xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle)
  else:
   vdQJDPfwCAmnxYMBIETjtoUkNLebFR=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.Load_List_File(vdQJDPfwCAmnxYMBIETjtoUkNLebRz)
   for vdQJDPfwCAmnxYMBIETjtoUkNLebFW in vdQJDPfwCAmnxYMBIETjtoUkNLebFR:
    vdQJDPfwCAmnxYMBIETjtoUkNLebhX=vdQJDPfwCAmnxYMBIETjtoUkNLebqs(urllib.parse.parse_qsl(vdQJDPfwCAmnxYMBIETjtoUkNLebFW))
    vdQJDPfwCAmnxYMBIETjtoUkNLebFX =vdQJDPfwCAmnxYMBIETjtoUkNLebhX.get('code').strip()
    vdQJDPfwCAmnxYMBIETjtoUkNLebaz =vdQJDPfwCAmnxYMBIETjtoUkNLebhX.get('title').strip()
    vdQJDPfwCAmnxYMBIETjtoUkNLebWu=vdQJDPfwCAmnxYMBIETjtoUkNLebhX.get('img').strip()
    vdQJDPfwCAmnxYMBIETjtoUkNLebXO =vdQJDPfwCAmnxYMBIETjtoUkNLebhX.get('videoid').strip()
    try:
     vdQJDPfwCAmnxYMBIETjtoUkNLebWu=vdQJDPfwCAmnxYMBIETjtoUkNLebWu.replace('\'','\"')
     vdQJDPfwCAmnxYMBIETjtoUkNLebWu=json.loads(vdQJDPfwCAmnxYMBIETjtoUkNLebWu)
    except:
     vdQJDPfwCAmnxYMBIETjtoUkNLebqh
    vdQJDPfwCAmnxYMBIETjtoUkNLebWg={}
    vdQJDPfwCAmnxYMBIETjtoUkNLebWg['plot']=vdQJDPfwCAmnxYMBIETjtoUkNLebaz
    if vdQJDPfwCAmnxYMBIETjtoUkNLebRz=='vod':
     if vdQJDPfwCAmnxYMBIETjtoUkNLebas==vdQJDPfwCAmnxYMBIETjtoUkNLebqK or vdQJDPfwCAmnxYMBIETjtoUkNLebXO==vdQJDPfwCAmnxYMBIETjtoUkNLebqh:
      vdQJDPfwCAmnxYMBIETjtoUkNLebWg['mediatype']='tvshow'
      vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'EPISODE','programcode':vdQJDPfwCAmnxYMBIETjtoUkNLebFX,'page':'1'}
      vdQJDPfwCAmnxYMBIETjtoUkNLebRW=vdQJDPfwCAmnxYMBIETjtoUkNLebql
     else:
      vdQJDPfwCAmnxYMBIETjtoUkNLebWg['mediatype']='episode'
      vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'VOD','mediacode':vdQJDPfwCAmnxYMBIETjtoUkNLebXO,'stype':'vod','programcode':vdQJDPfwCAmnxYMBIETjtoUkNLebFX,'title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'thumbnail':vdQJDPfwCAmnxYMBIETjtoUkNLebWu}
      vdQJDPfwCAmnxYMBIETjtoUkNLebRW=vdQJDPfwCAmnxYMBIETjtoUkNLebqK
    else:
     vdQJDPfwCAmnxYMBIETjtoUkNLebWg['mediatype']='movie'
     vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'MOVIE','mediacode':vdQJDPfwCAmnxYMBIETjtoUkNLebFX,'stype':'movie','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'thumbnail':vdQJDPfwCAmnxYMBIETjtoUkNLebWu}
     vdQJDPfwCAmnxYMBIETjtoUkNLebRW=vdQJDPfwCAmnxYMBIETjtoUkNLebqK
    vdQJDPfwCAmnxYMBIETjtoUkNLebhK={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':vdQJDPfwCAmnxYMBIETjtoUkNLebFX,'vType':vdQJDPfwCAmnxYMBIETjtoUkNLebRz,}
    vdQJDPfwCAmnxYMBIETjtoUkNLebhq=urllib.parse.urlencode(vdQJDPfwCAmnxYMBIETjtoUkNLebhK)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWV=[('선택된 시청이력 ( %s ) 삭제'%(vdQJDPfwCAmnxYMBIETjtoUkNLebaz),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(vdQJDPfwCAmnxYMBIETjtoUkNLebhq))]
    vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel='',img=vdQJDPfwCAmnxYMBIETjtoUkNLebWu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebRW,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa,ContextMenu=vdQJDPfwCAmnxYMBIETjtoUkNLebWV)
   vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'plot':'시청목록을 삭제합니다.'}
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':vdQJDPfwCAmnxYMBIETjtoUkNLebRz,}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel='',img=vdQJDPfwCAmnxYMBIETjtoUkNLebRu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebqK,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa,isLink=vdQJDPfwCAmnxYMBIETjtoUkNLebql)
   if vdQJDPfwCAmnxYMBIETjtoUkNLebRz=='movie':xbmcplugin.setContent(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,'movies')
   else:xbmcplugin.setContent(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
 def Save_Searched_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebXV):
  try:
   vdQJDPfwCAmnxYMBIETjtoUkNLebFh=vdQJDPfwCAmnxYMBIETjtoUkNLebus
   vdQJDPfwCAmnxYMBIETjtoUkNLebhz=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.Load_List_File('search') 
   vdQJDPfwCAmnxYMBIETjtoUkNLebFK={'skey':vdQJDPfwCAmnxYMBIETjtoUkNLebXV.strip()}
   fp=vdQJDPfwCAmnxYMBIETjtoUkNLebqr(vdQJDPfwCAmnxYMBIETjtoUkNLebFh,'w',-1,'utf-8')
   vdQJDPfwCAmnxYMBIETjtoUkNLebhH=urllib.parse.urlencode(vdQJDPfwCAmnxYMBIETjtoUkNLebFK)
   vdQJDPfwCAmnxYMBIETjtoUkNLebhH=vdQJDPfwCAmnxYMBIETjtoUkNLebhH+'\n'
   fp.write(vdQJDPfwCAmnxYMBIETjtoUkNLebhH)
   vdQJDPfwCAmnxYMBIETjtoUkNLebhi=0
   for vdQJDPfwCAmnxYMBIETjtoUkNLebhp in vdQJDPfwCAmnxYMBIETjtoUkNLebhz:
    vdQJDPfwCAmnxYMBIETjtoUkNLebhr=vdQJDPfwCAmnxYMBIETjtoUkNLebqs(urllib.parse.parse_qsl(vdQJDPfwCAmnxYMBIETjtoUkNLebhp))
    vdQJDPfwCAmnxYMBIETjtoUkNLebFu=vdQJDPfwCAmnxYMBIETjtoUkNLebFK.get('skey').strip()
    vdQJDPfwCAmnxYMBIETjtoUkNLebFa=vdQJDPfwCAmnxYMBIETjtoUkNLebhr.get('skey').strip()
    if vdQJDPfwCAmnxYMBIETjtoUkNLebFu!=vdQJDPfwCAmnxYMBIETjtoUkNLebFa:
     fp.write(vdQJDPfwCAmnxYMBIETjtoUkNLebhp)
     vdQJDPfwCAmnxYMBIETjtoUkNLebhi+=1
     if vdQJDPfwCAmnxYMBIETjtoUkNLebhi>=50:break
   fp.close()
  except:
   vdQJDPfwCAmnxYMBIETjtoUkNLebqh
 def play_VIDEO(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebFq =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('mediacode')
  vdQJDPfwCAmnxYMBIETjtoUkNLebRz =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('stype')
  vdQJDPfwCAmnxYMBIETjtoUkNLebFl =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('pvrmode')
  vdQJDPfwCAmnxYMBIETjtoUkNLebFg=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_selQuality(vdQJDPfwCAmnxYMBIETjtoUkNLebRz)
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(vdQJDPfwCAmnxYMBIETjtoUkNLebFq,vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebFg),vdQJDPfwCAmnxYMBIETjtoUkNLebRz,vdQJDPfwCAmnxYMBIETjtoUkNLebFl))
  vdQJDPfwCAmnxYMBIETjtoUkNLebFs=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.GetBroadURL(vdQJDPfwCAmnxYMBIETjtoUkNLebFq,vdQJDPfwCAmnxYMBIETjtoUkNLebFg,vdQJDPfwCAmnxYMBIETjtoUkNLebRz,vdQJDPfwCAmnxYMBIETjtoUkNLebFl,optUHD=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_uhd())
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_log('qt, stype, url : %s - %s - %s'%(vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebFg),vdQJDPfwCAmnxYMBIETjtoUkNLebRz,vdQJDPfwCAmnxYMBIETjtoUkNLebFs['streaming_url']))
  if vdQJDPfwCAmnxYMBIETjtoUkNLebFs['streaming_url']=='':
   if vdQJDPfwCAmnxYMBIETjtoUkNLebFs['error_msg']=='':
    vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_noti(__language__(30908).encode('utf8'))
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_noti(vdQJDPfwCAmnxYMBIETjtoUkNLebFs['error_msg'].encode('utf8'))
   return
  if vdQJDPfwCAmnxYMBIETjtoUkNLebFs['qt_stream']=='stream70':
   vdQJDPfwCAmnxYMBIETjtoUkNLebFy={'user-agent':vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.USER_AGENT_ATV}
  else:
   vdQJDPfwCAmnxYMBIETjtoUkNLebFy={'user-agent':vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.USER_AGENT}
  vdQJDPfwCAmnxYMBIETjtoUkNLebFS=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.makeDefaultCookies() 
  if vdQJDPfwCAmnxYMBIETjtoUkNLebFs['watermark'] !='':
   vdQJDPfwCAmnxYMBIETjtoUkNLebFy['x-tving-param1']=vdQJDPfwCAmnxYMBIETjtoUkNLebFs['watermarkKey']
   vdQJDPfwCAmnxYMBIETjtoUkNLebFy['x-tving-param2']=vdQJDPfwCAmnxYMBIETjtoUkNLebFs['watermark'] 
  if vdQJDPfwCAmnxYMBIETjtoUkNLebFs['drm_server_url'] !='':
   vdQJDPfwCAmnxYMBIETjtoUkNLebFy[vdQJDPfwCAmnxYMBIETjtoUkNLebFs['drm_header_key']]=vdQJDPfwCAmnxYMBIETjtoUkNLebFs['drm_header_value']
  vdQJDPfwCAmnxYMBIETjtoUkNLebFO =vdQJDPfwCAmnxYMBIETjtoUkNLebqK
  vdQJDPfwCAmnxYMBIETjtoUkNLebFz =vdQJDPfwCAmnxYMBIETjtoUkNLebFs['streaming_url'].find('Policy=')
  if vdQJDPfwCAmnxYMBIETjtoUkNLebFz!=-1:
   vdQJDPfwCAmnxYMBIETjtoUkNLebFp =vdQJDPfwCAmnxYMBIETjtoUkNLebFs['streaming_url'].split('?')[0]
   vdQJDPfwCAmnxYMBIETjtoUkNLebFr=vdQJDPfwCAmnxYMBIETjtoUkNLebqs(urllib.parse.parse_qsl(urllib.parse.urlsplit(vdQJDPfwCAmnxYMBIETjtoUkNLebFs['streaming_url']).query))
   vdQJDPfwCAmnxYMBIETjtoUkNLebFS['CloudFront-Policy'] =vdQJDPfwCAmnxYMBIETjtoUkNLebFr['Policy'] 
   vdQJDPfwCAmnxYMBIETjtoUkNLebFS['CloudFront-Signature'] =vdQJDPfwCAmnxYMBIETjtoUkNLebFr['Signature'] 
   vdQJDPfwCAmnxYMBIETjtoUkNLebFS['CloudFront-Key-Pair-Id']=vdQJDPfwCAmnxYMBIETjtoUkNLebFr['Key-Pair-Id'] 
   vdQJDPfwCAmnxYMBIETjtoUkNLebFG=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.make_stream_header(vdQJDPfwCAmnxYMBIETjtoUkNLebFy,vdQJDPfwCAmnxYMBIETjtoUkNLebFS)
   if 'quickvod-mcdn.tving.com' in vdQJDPfwCAmnxYMBIETjtoUkNLebFp:
    vdQJDPfwCAmnxYMBIETjtoUkNLebFO=vdQJDPfwCAmnxYMBIETjtoUkNLebql
    vdQJDPfwCAmnxYMBIETjtoUkNLebFc =vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    vdQJDPfwCAmnxYMBIETjtoUkNLebFV=vdQJDPfwCAmnxYMBIETjtoUkNLebFc.strftime('%Y-%m-%d-%H:%M:%S')
    if vdQJDPfwCAmnxYMBIETjtoUkNLebqF(vdQJDPfwCAmnxYMBIETjtoUkNLebFV.replace('-','').replace(':',''))<vdQJDPfwCAmnxYMBIETjtoUkNLebqF(vdQJDPfwCAmnxYMBIETjtoUkNLebFr['end'].replace('-','').replace(':','')):
     vdQJDPfwCAmnxYMBIETjtoUkNLebFr['end']=vdQJDPfwCAmnxYMBIETjtoUkNLebFV
     vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_noti(__language__(30915).encode('utf8'))
    vdQJDPfwCAmnxYMBIETjtoUkNLebFp ='%s?%s'%(vdQJDPfwCAmnxYMBIETjtoUkNLebFp,urllib.parse.urlencode(vdQJDPfwCAmnxYMBIETjtoUkNLebFr,doseq=vdQJDPfwCAmnxYMBIETjtoUkNLebql))
    vdQJDPfwCAmnxYMBIETjtoUkNLebFH='{}|{}'.format(vdQJDPfwCAmnxYMBIETjtoUkNLebFp,vdQJDPfwCAmnxYMBIETjtoUkNLebFG)
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebFH='{}|{}'.format(vdQJDPfwCAmnxYMBIETjtoUkNLebFs['streaming_url'],vdQJDPfwCAmnxYMBIETjtoUkNLebFG)
  else:
   vdQJDPfwCAmnxYMBIETjtoUkNLebFG=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.make_stream_header(vdQJDPfwCAmnxYMBIETjtoUkNLebFy,vdQJDPfwCAmnxYMBIETjtoUkNLebFS)
   vdQJDPfwCAmnxYMBIETjtoUkNLebFH='{}|{}'.format(vdQJDPfwCAmnxYMBIETjtoUkNLebFs['streaming_url'],vdQJDPfwCAmnxYMBIETjtoUkNLebFG)
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_log('if tmp_pos == -1')
  vdQJDPfwCAmnxYMBIETjtoUkNLebaX,vdQJDPfwCAmnxYMBIETjtoUkNLebah=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_proxyport()
  vdQJDPfwCAmnxYMBIETjtoUkNLebaW=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_playback()
  if(vdQJDPfwCAmnxYMBIETjtoUkNLebaX and vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('mode')in['VOD','MOVIE']and vdQJDPfwCAmnxYMBIETjtoUkNLebFO==vdQJDPfwCAmnxYMBIETjtoUkNLebqK and(vdQJDPfwCAmnxYMBIETjtoUkNLebFs['drm_server_url']!='' or(vdQJDPfwCAmnxYMBIETjtoUkNLebFs['url_filename'].split('.')[1]=='mpd')or(vdQJDPfwCAmnxYMBIETjtoUkNLebFs['url_filename'].split('.')[1]!='mpd' and vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.KodiVersion>=21 and vdQJDPfwCAmnxYMBIETjtoUkNLebFs['qt_stream']=='stream70'))):
   if vdQJDPfwCAmnxYMBIETjtoUkNLebFs['url_filename'].split('.')[1]=='mpd':
    vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Tving_Parse_mpd(vdQJDPfwCAmnxYMBIETjtoUkNLebFs['streaming_url'],vdQJDPfwCAmnxYMBIETjtoUkNLebFs['watermarkKey'],vdQJDPfwCAmnxYMBIETjtoUkNLebFs['watermark'])
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Tving_Parse_m3u8(vdQJDPfwCAmnxYMBIETjtoUkNLebFs['streaming_url'])
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_log('xxx '+vdQJDPfwCAmnxYMBIETjtoUkNLebFs['streaming_url'])
   vdQJDPfwCAmnxYMBIETjtoUkNLebFi={'addon':'tvingm','playOption':vdQJDPfwCAmnxYMBIETjtoUkNLebaW,'url_filename':vdQJDPfwCAmnxYMBIETjtoUkNLebFs['url_filename'],}
   vdQJDPfwCAmnxYMBIETjtoUkNLebFi=json.dumps(vdQJDPfwCAmnxYMBIETjtoUkNLebFi,separators=(',',':'))
   vdQJDPfwCAmnxYMBIETjtoUkNLebFi=base64.standard_b64encode(vdQJDPfwCAmnxYMBIETjtoUkNLebFi.encode()).decode('utf-8')
   vdQJDPfwCAmnxYMBIETjtoUkNLebFH ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(vdQJDPfwCAmnxYMBIETjtoUkNLebah,vdQJDPfwCAmnxYMBIETjtoUkNLebFH,vdQJDPfwCAmnxYMBIETjtoUkNLebFi)
   vdQJDPfwCAmnxYMBIETjtoUkNLebFy['proxy-mini']=vdQJDPfwCAmnxYMBIETjtoUkNLebFi 
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_log('surl(2) : {}'.format(vdQJDPfwCAmnxYMBIETjtoUkNLebFH))
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_log('drm     : {}'.format(vdQJDPfwCAmnxYMBIETjtoUkNLebFs['drm_server_url']))
  vdQJDPfwCAmnxYMBIETjtoUkNLebFG=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.make_stream_header(vdQJDPfwCAmnxYMBIETjtoUkNLebFy,vdQJDPfwCAmnxYMBIETjtoUkNLebFS)
  vdQJDPfwCAmnxYMBIETjtoUkNLebKu=xbmcgui.ListItem(path=vdQJDPfwCAmnxYMBIETjtoUkNLebFH)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebFs['drm_server_url']!='':
   vdQJDPfwCAmnxYMBIETjtoUkNLebKa=vdQJDPfwCAmnxYMBIETjtoUkNLebFs['drm_server_url']
   vdQJDPfwCAmnxYMBIETjtoUkNLebKR ='https://license-global.pallycon.com/ri/licenseManager.do' 
   vdQJDPfwCAmnxYMBIETjtoUkNLebKW ='mpd'
   vdQJDPfwCAmnxYMBIETjtoUkNLebKX ='com.widevine.alpha'
   inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream()
   vdQJDPfwCAmnxYMBIETjtoUkNLebKF={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.USER_AGENT,vdQJDPfwCAmnxYMBIETjtoUkNLebFs['drm_header_key']:vdQJDPfwCAmnxYMBIETjtoUkNLebFs['drm_header_value'],}
   vdQJDPfwCAmnxYMBIETjtoUkNLebKq=vdQJDPfwCAmnxYMBIETjtoUkNLebKR+'|'+urllib.parse.urlencode(vdQJDPfwCAmnxYMBIETjtoUkNLebKF)+'|R{SSM}|'
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream','inputstream.adaptive')
   if vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.KodiVersion<=20:
    vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream.adaptive.manifest_type',vdQJDPfwCAmnxYMBIETjtoUkNLebKW)
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream.adaptive.license_type',vdQJDPfwCAmnxYMBIETjtoUkNLebKX)
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream.adaptive.license_key',vdQJDPfwCAmnxYMBIETjtoUkNLebKq)
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream.adaptive.stream_headers',vdQJDPfwCAmnxYMBIETjtoUkNLebFG)
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream.adaptive.manifest_headers',vdQJDPfwCAmnxYMBIETjtoUkNLebFG)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('mode')in['VOD','MOVIE']:
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setContentLookup(vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setMimeType('application/x-mpegURL')
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream','inputstream.adaptive')
   if vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.KodiVersion<=20:
    vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream.adaptive.manifest_type','hls')
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream.adaptive.stream_headers',vdQJDPfwCAmnxYMBIETjtoUkNLebFG)
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream.adaptive.manifest_headers',vdQJDPfwCAmnxYMBIETjtoUkNLebFG)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebFO==vdQJDPfwCAmnxYMBIETjtoUkNLebql:
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setContentLookup(vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setMimeType('application/x-mpegURL')
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream','inputstream.ffmpegdirect')
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('ResumeTime','0')
   vdQJDPfwCAmnxYMBIETjtoUkNLebKu.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,vdQJDPfwCAmnxYMBIETjtoUkNLebql,vdQJDPfwCAmnxYMBIETjtoUkNLebKu)
  try:
   if vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('mode')in['VOD','MOVIE']and vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('title'):
    vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'code':vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('programcode')if vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('mode')=='VOD' else vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('mediacode'),'img':vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('thumbnail'),'title':vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('title'),'videoid':vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('mediacode')}
    vdQJDPfwCAmnxYMBIETjtoUkNLebuy.Save_Watched_List(vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('stype'),vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  except:
   vdQJDPfwCAmnxYMBIETjtoUkNLebqh
 def logout(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  vdQJDPfwCAmnxYMBIETjtoUkNLebur=xbmcgui.Dialog()
  vdQJDPfwCAmnxYMBIETjtoUkNLebRs=vdQJDPfwCAmnxYMBIETjtoUkNLebur.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if vdQJDPfwCAmnxYMBIETjtoUkNLebRs==vdQJDPfwCAmnxYMBIETjtoUkNLebqK:sys.exit()
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Init_TV_Total()
  if os.path.isfile(vdQJDPfwCAmnxYMBIETjtoUkNLebug):os.remove(vdQJDPfwCAmnxYMBIETjtoUkNLebug)
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  vdQJDPfwCAmnxYMBIETjtoUkNLebKl =vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Get_Now_Datetime()
  vdQJDPfwCAmnxYMBIETjtoUkNLebKg=vdQJDPfwCAmnxYMBIETjtoUkNLebKl+datetime.timedelta(days=30) 
  (vdQJDPfwCAmnxYMBIETjtoUkNLebRK,vdQJDPfwCAmnxYMBIETjtoUkNLebRq,vdQJDPfwCAmnxYMBIETjtoUkNLebRl,vdQJDPfwCAmnxYMBIETjtoUkNLebRg)=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_account()
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Save_session_acount(vdQJDPfwCAmnxYMBIETjtoUkNLebRK,vdQJDPfwCAmnxYMBIETjtoUkNLebRq,vdQJDPfwCAmnxYMBIETjtoUkNLebRl,vdQJDPfwCAmnxYMBIETjtoUkNLebRg)
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.TV['account']['token_limit']=vdQJDPfwCAmnxYMBIETjtoUkNLebKg.strftime('%Y%m%d')
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.JsonFile_Save(vdQJDPfwCAmnxYMBIETjtoUkNLebug,vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.TV)
 def cookiefile_check(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.TV=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.JsonFile_Load(vdQJDPfwCAmnxYMBIETjtoUkNLebug)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.TV=={}:
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Init_TV_Total()
   return vdQJDPfwCAmnxYMBIETjtoUkNLebqK
  (vdQJDPfwCAmnxYMBIETjtoUkNLebKs,vdQJDPfwCAmnxYMBIETjtoUkNLebKy,vdQJDPfwCAmnxYMBIETjtoUkNLebKS,vdQJDPfwCAmnxYMBIETjtoUkNLebKO)=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_account()
  (vdQJDPfwCAmnxYMBIETjtoUkNLebKz,vdQJDPfwCAmnxYMBIETjtoUkNLebKp,vdQJDPfwCAmnxYMBIETjtoUkNLebKr,vdQJDPfwCAmnxYMBIETjtoUkNLebKG)=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Load_session_acount()
  if(vdQJDPfwCAmnxYMBIETjtoUkNLebKs!=vdQJDPfwCAmnxYMBIETjtoUkNLebKz or vdQJDPfwCAmnxYMBIETjtoUkNLebKy!=vdQJDPfwCAmnxYMBIETjtoUkNLebKp or vdQJDPfwCAmnxYMBIETjtoUkNLebKS!=vdQJDPfwCAmnxYMBIETjtoUkNLebKr or vdQJDPfwCAmnxYMBIETjtoUkNLebKO!=vdQJDPfwCAmnxYMBIETjtoUkNLebKG)and vdQJDPfwCAmnxYMBIETjtoUkNLebKz!='xxxxx':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Init_TV_Total()
   return vdQJDPfwCAmnxYMBIETjtoUkNLebqK
  if vdQJDPfwCAmnxYMBIETjtoUkNLebqF(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>vdQJDPfwCAmnxYMBIETjtoUkNLebqF(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.TV['account']['token_limit']):
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Init_TV_Total()
   return vdQJDPfwCAmnxYMBIETjtoUkNLebqK
  return vdQJDPfwCAmnxYMBIETjtoUkNLebql
 def dp_Global_Search(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebXH=vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('mode')
  if vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='TOTAL_SEARCH':
   vdQJDPfwCAmnxYMBIETjtoUkNLebKc='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   vdQJDPfwCAmnxYMBIETjtoUkNLebKc='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(vdQJDPfwCAmnxYMBIETjtoUkNLebKc)
 def dp_Bookmark_Menu(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebKc='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(vdQJDPfwCAmnxYMBIETjtoUkNLebKc)
 def dp_EuroLive_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebRV=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.GetEuroChannelList()
  for vdQJDPfwCAmnxYMBIETjtoUkNLebRi in vdQJDPfwCAmnxYMBIETjtoUkNLebRV:
   vdQJDPfwCAmnxYMBIETjtoUkNLebWp =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('channel')
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWs =vdQJDPfwCAmnxYMBIETjtoUkNLebRi.get('subtitle')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'mediatype':'episode','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'plot':'%s\n%s'%(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,vdQJDPfwCAmnxYMBIETjtoUkNLebWs)}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'LIVE','mediacode':vdQJDPfwCAmnxYMBIETjtoUkNLebWp,'stype':'onair',}
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebWs,img='',infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebqK,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebqO(vdQJDPfwCAmnxYMBIETjtoUkNLebRV)>0:xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
 def dp_Apple_Group(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebKV=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Get_AppleGroup_List()
  for vdQJDPfwCAmnxYMBIETjtoUkNLebKH in vdQJDPfwCAmnxYMBIETjtoUkNLebKV:
   vdQJDPfwCAmnxYMBIETjtoUkNLebKi =vdQJDPfwCAmnxYMBIETjtoUkNLebKH.get('bandName')
   vdQJDPfwCAmnxYMBIETjtoUkNLebqu =vdQJDPfwCAmnxYMBIETjtoUkNLebKH.get('bandKey')
   vdQJDPfwCAmnxYMBIETjtoUkNLebqa =vdQJDPfwCAmnxYMBIETjtoUkNLebKH.get('moreUrl')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'mediatype':'tvshow','title':vdQJDPfwCAmnxYMBIETjtoUkNLebKi,'plot':'%s'%(vdQJDPfwCAmnxYMBIETjtoUkNLebqu),}
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'BAND_VODLIST','bandKey':vdQJDPfwCAmnxYMBIETjtoUkNLebqu,'moreUrl':vdQJDPfwCAmnxYMBIETjtoUkNLebqa,'page':'1','nextApiUrl':'-',}
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebKi,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,img='',infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebqO(vdQJDPfwCAmnxYMBIETjtoUkNLebKV)>0:xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
 def dp_Band_VodList(vdQJDPfwCAmnxYMBIETjtoUkNLebuy,vdQJDPfwCAmnxYMBIETjtoUkNLebRG):
  vdQJDPfwCAmnxYMBIETjtoUkNLebqu =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('bandKey') 
  vdQJDPfwCAmnxYMBIETjtoUkNLebqa =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('moreUrl') 
  vdQJDPfwCAmnxYMBIETjtoUkNLebqR =vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('nextApiUrl')
  vdQJDPfwCAmnxYMBIETjtoUkNLebqW =''
  vdQJDPfwCAmnxYMBIETjtoUkNLebRc =vdQJDPfwCAmnxYMBIETjtoUkNLebqF(vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('page'))
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_log('bandKey    : {}'.format(vdQJDPfwCAmnxYMBIETjtoUkNLebqu))
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_log('moreUrl    : {}'.format(vdQJDPfwCAmnxYMBIETjtoUkNLebqa))
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_log('nextApiUrl : {}'.format(vdQJDPfwCAmnxYMBIETjtoUkNLebqR))
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.addon_log('page       : {}'.format(vdQJDPfwCAmnxYMBIETjtoUkNLebRG.get('page')))
  if vdQJDPfwCAmnxYMBIETjtoUkNLebqu=='HM192222':
   vdQJDPfwCAmnxYMBIETjtoUkNLebWO,vdQJDPfwCAmnxYMBIETjtoUkNLebqR=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Get_Apple_NowList()
  else:
   vdQJDPfwCAmnxYMBIETjtoUkNLebWO,vdQJDPfwCAmnxYMBIETjtoUkNLebqR=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.Get_Band_VodList(vdQJDPfwCAmnxYMBIETjtoUkNLebqu,vdQJDPfwCAmnxYMBIETjtoUkNLebqa,vdQJDPfwCAmnxYMBIETjtoUkNLebqR)
  for vdQJDPfwCAmnxYMBIETjtoUkNLebWz in vdQJDPfwCAmnxYMBIETjtoUkNLebWO:
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('title')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWu =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('thumbnail')
   vdQJDPfwCAmnxYMBIETjtoUkNLebXO =vdQJDPfwCAmnxYMBIETjtoUkNLebWz.get('program')
   vdQJDPfwCAmnxYMBIETjtoUkNLebWg={'mediatype':'tvshow' if not vdQJDPfwCAmnxYMBIETjtoUkNLebXO.startswith('M')else 'movie','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'plot':vdQJDPfwCAmnxYMBIETjtoUkNLebaz+'\n'+'tvshow' if not vdQJDPfwCAmnxYMBIETjtoUkNLebXO.startswith('M')else 'movie',}
   if not vdQJDPfwCAmnxYMBIETjtoUkNLebXO.startswith('M'):
    vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'EPISODE','programcode':vdQJDPfwCAmnxYMBIETjtoUkNLebXO,'page':'1',}
    vdQJDPfwCAmnxYMBIETjtoUkNLebRW=vdQJDPfwCAmnxYMBIETjtoUkNLebql
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebRa={'mode':'MOVIE','mediacode':vdQJDPfwCAmnxYMBIETjtoUkNLebXO,'stype':'movie','title':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'thumbnail':vdQJDPfwCAmnxYMBIETjtoUkNLebWu,}
    vdQJDPfwCAmnxYMBIETjtoUkNLebRW=vdQJDPfwCAmnxYMBIETjtoUkNLebqK
   if vdQJDPfwCAmnxYMBIETjtoUkNLebuy.get_settings_makebookmark():
    vdQJDPfwCAmnxYMBIETjtoUkNLebWr={'videoid':vdQJDPfwCAmnxYMBIETjtoUkNLebXO,'vidtype':'tvshow','vtitle':vdQJDPfwCAmnxYMBIETjtoUkNLebaz,'vsubtitle':vdQJDPfwCAmnxYMBIETjtoUkNLebqW,}
    vdQJDPfwCAmnxYMBIETjtoUkNLebWG=json.dumps(vdQJDPfwCAmnxYMBIETjtoUkNLebWr)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWG=urllib.parse.quote(vdQJDPfwCAmnxYMBIETjtoUkNLebWG)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWc='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(vdQJDPfwCAmnxYMBIETjtoUkNLebWG)
    vdQJDPfwCAmnxYMBIETjtoUkNLebWV=[('(통합) 찜 영상에 추가',vdQJDPfwCAmnxYMBIETjtoUkNLebWc)]
   else:
    vdQJDPfwCAmnxYMBIETjtoUkNLebWV=vdQJDPfwCAmnxYMBIETjtoUkNLebqh
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebqW,img=vdQJDPfwCAmnxYMBIETjtoUkNLebWu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebWg,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebRW,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa,ContextMenu=vdQJDPfwCAmnxYMBIETjtoUkNLebWV)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebqR not in[vdQJDPfwCAmnxYMBIETjtoUkNLebqh,'','-']:
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['mode'] ='BAND_VODLIST' 
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['bandKey'] =vdQJDPfwCAmnxYMBIETjtoUkNLebqu
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['moreUrl'] =vdQJDPfwCAmnxYMBIETjtoUkNLebqa
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['nextApiUrl']=vdQJDPfwCAmnxYMBIETjtoUkNLebqR
   vdQJDPfwCAmnxYMBIETjtoUkNLebRa['page'] =vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebaz='[B]%s >>[/B]'%'다음 페이지'
   vdQJDPfwCAmnxYMBIETjtoUkNLebWs=vdQJDPfwCAmnxYMBIETjtoUkNLebqz(vdQJDPfwCAmnxYMBIETjtoUkNLebRc+1)
   vdQJDPfwCAmnxYMBIETjtoUkNLebRu=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.add_dir(vdQJDPfwCAmnxYMBIETjtoUkNLebaz,sublabel=vdQJDPfwCAmnxYMBIETjtoUkNLebWs,img=vdQJDPfwCAmnxYMBIETjtoUkNLebRu,infoLabels=vdQJDPfwCAmnxYMBIETjtoUkNLebqh,isFolder=vdQJDPfwCAmnxYMBIETjtoUkNLebql,params=vdQJDPfwCAmnxYMBIETjtoUkNLebRa)
  xbmcplugin.setContent(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(vdQJDPfwCAmnxYMBIETjtoUkNLebuy._addon_handle,cacheToDisc=vdQJDPfwCAmnxYMBIETjtoUkNLebqK)
 def tving_main(vdQJDPfwCAmnxYMBIETjtoUkNLebuy):
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.TvingObj.KodiVersion=vdQJDPfwCAmnxYMBIETjtoUkNLebqF(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  vdQJDPfwCAmnxYMBIETjtoUkNLebXH=vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params.get('mode',vdQJDPfwCAmnxYMBIETjtoUkNLebqh)
  if vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='LOGOUT':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.logout()
   return
  vdQJDPfwCAmnxYMBIETjtoUkNLebuy.login_main()
  if vdQJDPfwCAmnxYMBIETjtoUkNLebXH is vdQJDPfwCAmnxYMBIETjtoUkNLebqh:
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Main_List()
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Title_Group(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH in['GLOBAL_GROUP']:
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_SubTitle_Group(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='CHANNEL':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_LiveChannel_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH in['LIVE','VOD','MOVIE']:
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.play_VIDEO(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='PROGRAM':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Program_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='4K_PROGRAM':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_4K_Program_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='ORI_PROGRAM':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Ori_Program_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='EPISODE':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Episode_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='MOVIE_SUB':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Movie_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='4K_MOVIE':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_4K_Movie_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='SEARCH_GROUP':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Search_Group(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH in['SEARCH','LOCAL_SEARCH']:
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Search_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='WATCH':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Watch_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_History_Remove(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='ORDER_BY':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_setEpOrderby(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='SET_BOOKMARK':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Set_Bookmark(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH in['TOTAL_SEARCH','TOTAL_HISTORY']:
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Global_Search(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='SEARCH_HISTORY':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Search_History(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='MENU_BOOKMARK':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Bookmark_Menu(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='EURO_GROUP':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_EuroLive_List(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='APPLE_GROUP':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Apple_Group(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  elif vdQJDPfwCAmnxYMBIETjtoUkNLebXH=='BAND_VODLIST':
   vdQJDPfwCAmnxYMBIETjtoUkNLebuy.dp_Band_VodList(vdQJDPfwCAmnxYMBIETjtoUkNLebuy.main_params)
  else:
   vdQJDPfwCAmnxYMBIETjtoUkNLebqh
# Created by pyminifier (https://github.com/liftoff/pyminifier)
