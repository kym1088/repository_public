__author__="NightRain"
kJndetKVMsoFRWYSyrPxcpCBGaTjhq=print
kJndetKVMsoFRWYSyrPxcpCBGaTjOE=ImportError
kJndetKVMsoFRWYSyrPxcpCBGaTjOi=object
kJndetKVMsoFRWYSyrPxcpCBGaTjOu=None
kJndetKVMsoFRWYSyrPxcpCBGaTjOQ=False
kJndetKVMsoFRWYSyrPxcpCBGaTjOm=str
kJndetKVMsoFRWYSyrPxcpCBGaTjOv=open
kJndetKVMsoFRWYSyrPxcpCBGaTjOw=True
kJndetKVMsoFRWYSyrPxcpCBGaTjOh=len
kJndetKVMsoFRWYSyrPxcpCBGaTjOz=int
kJndetKVMsoFRWYSyrPxcpCBGaTjOD=range
kJndetKVMsoFRWYSyrPxcpCBGaTjOH=bytes
kJndetKVMsoFRWYSyrPxcpCBGaTjON=Exception
kJndetKVMsoFRWYSyrPxcpCBGaTjOI=dict
kJndetKVMsoFRWYSyrPxcpCBGaTjOf=list
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 kJndetKVMsoFRWYSyrPxcpCBGaTjhq('Cryptodome')
except kJndetKVMsoFRWYSyrPxcpCBGaTjOE:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 kJndetKVMsoFRWYSyrPxcpCBGaTjhq('Crypto')
kJndetKVMsoFRWYSyrPxcpCBGaTjEu={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
kJndetKVMsoFRWYSyrPxcpCBGaTjEQ ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
kJndetKVMsoFRWYSyrPxcpCBGaTjEm =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
kJndetKVMsoFRWYSyrPxcpCBGaTjEv=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class kJndetKVMsoFRWYSyrPxcpCBGaTjEi(kJndetKVMsoFRWYSyrPxcpCBGaTjOi):
 def __init__(kJndetKVMsoFRWYSyrPxcpCBGaTjEw):
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.NETWORKCODE ='CSND0900'
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.OSCODE ='CSOD0900' 
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TELECODE ='CSCD0900'
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.SCREENCODE ='CSSD0100'
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.APIKEY_ATV ='b6ac9e6384d93d6e533b144b3ef22c42' 
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.SCREENCODE_ATV ='CSSD1300' 
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.LIVE_LIMIT =20 
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.VOD_LIMIT =24 
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.EPISODE_LIMIT =30 
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.SEARCH_LIMIT =30 
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.MOVIE_LIMIT =24 
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN ='https://api.tving.com'
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN ='https://image.tving.com'
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.SEARCH_DOMAIN ='https://search-api.tving.com'
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.LOGIN_DOMAIN ='https://user.tving.com'
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.URL_DOMAIN ='https://www.tving.com'
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.MOVIE_LITE =['2610061','2610161','261062']
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36'
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.MODEL ='windows_chrome_135.0.0.0' 
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.USER_AGENT_ATV ='Mozilla/5.0 (Linux; Android 9; A95X_F3_Air Build/A95X_F3_AIR_M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36'
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.DEFAULT_HEADER ={'user-agent':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.USER_AGENT}
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.COOKIE_FILE_NAME =''
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV_SESSION_COOKIES1=''
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV_SESSION_COOKIES2=''
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV_STREAM_FILENAME =''
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV_SESSION_TEXT1 =''
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV_SESSION_TEXT2 =''
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.KodiVersion=20
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV ={}
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Init_TV_Total()
 def Init_TV_Total(kJndetKVMsoFRWYSyrPxcpCBGaTjEw):
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV={'account':{},'cookies':{},}
 def callRequestCookies(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,jobtype,kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,json=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,redirects=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ):
  kJndetKVMsoFRWYSyrPxcpCBGaTjEh=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.DEFAULT_HEADER
  if headers:kJndetKVMsoFRWYSyrPxcpCBGaTjEh.update(headers)
  if jobtype=='Get':
   kJndetKVMsoFRWYSyrPxcpCBGaTjEO=requests.get(kJndetKVMsoFRWYSyrPxcpCBGaTjil,params=params,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjEh,cookies=cookies,allow_redirects=redirects)
  else:
   kJndetKVMsoFRWYSyrPxcpCBGaTjEO=requests.post(kJndetKVMsoFRWYSyrPxcpCBGaTjil,data=payload,json=json,params=params,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjEh,cookies=cookies,allow_redirects=redirects)
  kJndetKVMsoFRWYSyrPxcpCBGaTjhq(kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEO.status_code)+' - '+kJndetKVMsoFRWYSyrPxcpCBGaTjEO.url)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjEO
 def JsonFile_Save(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,filename,kJndetKVMsoFRWYSyrPxcpCBGaTjEz):
  if filename=='':return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  try:
   fp=kJndetKVMsoFRWYSyrPxcpCBGaTjOv(filename,'w',-1,'utf-8')
   json.dump(kJndetKVMsoFRWYSyrPxcpCBGaTjEz,fp,indent=4,ensure_ascii=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ)
   fp.close()
  except:
   return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  return kJndetKVMsoFRWYSyrPxcpCBGaTjOw
 def JsonFile_Load(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,filename):
  if filename=='':return{}
  try:
   fp=kJndetKVMsoFRWYSyrPxcpCBGaTjOv(filename,'r',-1,'utf-8')
   kJndetKVMsoFRWYSyrPxcpCBGaTjEH=json.load(fp)
   fp.close()
  except:
   return{}
  return kJndetKVMsoFRWYSyrPxcpCBGaTjEH
 def TextFile_Save(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,filename,resText):
  if filename=='':return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  try:
   fp=kJndetKVMsoFRWYSyrPxcpCBGaTjOv(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  return kJndetKVMsoFRWYSyrPxcpCBGaTjOw
 def Save_session_acount(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,kJndetKVMsoFRWYSyrPxcpCBGaTjEN,kJndetKVMsoFRWYSyrPxcpCBGaTjEI,kJndetKVMsoFRWYSyrPxcpCBGaTjEf,kJndetKVMsoFRWYSyrPxcpCBGaTjEb):
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['account']['tvid'] =base64.standard_b64encode(kJndetKVMsoFRWYSyrPxcpCBGaTjEN.encode()).decode('utf-8')
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['account']['tvpw'] =base64.standard_b64encode(kJndetKVMsoFRWYSyrPxcpCBGaTjEI.encode()).decode('utf-8')
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['account']['tvtype']=kJndetKVMsoFRWYSyrPxcpCBGaTjEf 
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['account']['tvpf'] =kJndetKVMsoFRWYSyrPxcpCBGaTjEb 
 def Load_session_acount(kJndetKVMsoFRWYSyrPxcpCBGaTjEw):
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjEN =base64.standard_b64decode(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['account']['tvid']).decode('utf-8')
   kJndetKVMsoFRWYSyrPxcpCBGaTjEI =base64.standard_b64decode(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['account']['tvpw']).decode('utf-8')
   kJndetKVMsoFRWYSyrPxcpCBGaTjEf=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['account']['tvtype']
   kJndetKVMsoFRWYSyrPxcpCBGaTjEb =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return kJndetKVMsoFRWYSyrPxcpCBGaTjEN,kJndetKVMsoFRWYSyrPxcpCBGaTjEI,kJndetKVMsoFRWYSyrPxcpCBGaTjEf,kJndetKVMsoFRWYSyrPxcpCBGaTjEb
 def make_stream_header(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,kJndetKVMsoFRWYSyrPxcpCBGaTjEX,kJndetKVMsoFRWYSyrPxcpCBGaTjEq):
  kJndetKVMsoFRWYSyrPxcpCBGaTjEL=''
  if kJndetKVMsoFRWYSyrPxcpCBGaTjEq not in[{},kJndetKVMsoFRWYSyrPxcpCBGaTjOu,'']:
   kJndetKVMsoFRWYSyrPxcpCBGaTjEU=kJndetKVMsoFRWYSyrPxcpCBGaTjOh(kJndetKVMsoFRWYSyrPxcpCBGaTjEq)
   for kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjEl in kJndetKVMsoFRWYSyrPxcpCBGaTjEq.items():
    kJndetKVMsoFRWYSyrPxcpCBGaTjEL+='{}={}'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjEl)
    kJndetKVMsoFRWYSyrPxcpCBGaTjEU+=-1
    if kJndetKVMsoFRWYSyrPxcpCBGaTjEU>0:kJndetKVMsoFRWYSyrPxcpCBGaTjEL+='; '
   kJndetKVMsoFRWYSyrPxcpCBGaTjEX['cookie']=kJndetKVMsoFRWYSyrPxcpCBGaTjEL
  kJndetKVMsoFRWYSyrPxcpCBGaTjEg=''
  i=0
  for kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjEl in kJndetKVMsoFRWYSyrPxcpCBGaTjEX.items():
   i=i+1
   if i>1:kJndetKVMsoFRWYSyrPxcpCBGaTjEg+='&'
   kJndetKVMsoFRWYSyrPxcpCBGaTjEg+='{}={}'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjEA,urllib.parse.quote(kJndetKVMsoFRWYSyrPxcpCBGaTjEl))
  return kJndetKVMsoFRWYSyrPxcpCBGaTjEg
 def makeDefaultCookies(kJndetKVMsoFRWYSyrPxcpCBGaTjEw):
  kJndetKVMsoFRWYSyrPxcpCBGaTjEq={}
  for kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjEl in kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies'].items():
   kJndetKVMsoFRWYSyrPxcpCBGaTjEq[kJndetKVMsoFRWYSyrPxcpCBGaTjEA]=kJndetKVMsoFRWYSyrPxcpCBGaTjEl
  return kJndetKVMsoFRWYSyrPxcpCBGaTjEq
 def getDeviceStr(kJndetKVMsoFRWYSyrPxcpCBGaTjEw):
  kJndetKVMsoFRWYSyrPxcpCBGaTjiE=[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjiE.append('Windows') 
  kJndetKVMsoFRWYSyrPxcpCBGaTjiE.append('Chrome') 
  kJndetKVMsoFRWYSyrPxcpCBGaTjiE.append('ko-KR') 
  kJndetKVMsoFRWYSyrPxcpCBGaTjiE.append('undefined') 
  kJndetKVMsoFRWYSyrPxcpCBGaTjiE.append('24') 
  kJndetKVMsoFRWYSyrPxcpCBGaTjiE.append(u'한국 표준시')
  kJndetKVMsoFRWYSyrPxcpCBGaTjiE.append('undefined') 
  kJndetKVMsoFRWYSyrPxcpCBGaTjiE.append('undefined') 
  kJndetKVMsoFRWYSyrPxcpCBGaTjiE.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  kJndetKVMsoFRWYSyrPxcpCBGaTjiu=''
  for kJndetKVMsoFRWYSyrPxcpCBGaTjiQ in kJndetKVMsoFRWYSyrPxcpCBGaTjiE:
   kJndetKVMsoFRWYSyrPxcpCBGaTjiu+=kJndetKVMsoFRWYSyrPxcpCBGaTjiQ+'|'
  return kJndetKVMsoFRWYSyrPxcpCBGaTjiu
 def GetDefaultParams(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,uhd=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ):
  if uhd==kJndetKVMsoFRWYSyrPxcpCBGaTjOQ:
   kJndetKVMsoFRWYSyrPxcpCBGaTjim={'apiKey':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.APIKEY,'networkCode':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.NETWORKCODE,'osCode':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.OSCODE,'teleCode':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TELECODE,'screenCode':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.SCREENCODE,}
  else:
   kJndetKVMsoFRWYSyrPxcpCBGaTjim={'apiKey':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.APIKEY_ATV,'networkCode':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.NETWORKCODE,'osCode':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.OSCODE,'teleCode':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TELECODE,'screenCode':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.SCREENCODE_ATV,}
  return kJndetKVMsoFRWYSyrPxcpCBGaTjim
 def GetNoCache(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,timetype=1):
  if timetype==1:
   return kJndetKVMsoFRWYSyrPxcpCBGaTjOz(time.time())
  else:
   return kJndetKVMsoFRWYSyrPxcpCBGaTjOz(time.time()*1000)
 def GetUniqueid(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,hValue=kJndetKVMsoFRWYSyrPxcpCBGaTjOu):
  if hValue:
   import hashlib
   kJndetKVMsoFRWYSyrPxcpCBGaTjiv=hashlib.sha1()
   kJndetKVMsoFRWYSyrPxcpCBGaTjiv.update(hValue.encode())
   kJndetKVMsoFRWYSyrPxcpCBGaTjiw=kJndetKVMsoFRWYSyrPxcpCBGaTjiv.hexdigest()[:8]
  else:
   kJndetKVMsoFRWYSyrPxcpCBGaTjih=[0 for i in kJndetKVMsoFRWYSyrPxcpCBGaTjOD(256)]
   for i in kJndetKVMsoFRWYSyrPxcpCBGaTjOD(256):
    kJndetKVMsoFRWYSyrPxcpCBGaTjih[i]='%02x'%(i)
   kJndetKVMsoFRWYSyrPxcpCBGaTjiO=kJndetKVMsoFRWYSyrPxcpCBGaTjOz(4294967295*random.random())|0
   kJndetKVMsoFRWYSyrPxcpCBGaTjiw=kJndetKVMsoFRWYSyrPxcpCBGaTjih[255&kJndetKVMsoFRWYSyrPxcpCBGaTjiO]+kJndetKVMsoFRWYSyrPxcpCBGaTjih[kJndetKVMsoFRWYSyrPxcpCBGaTjiO>>8&255]+kJndetKVMsoFRWYSyrPxcpCBGaTjih[kJndetKVMsoFRWYSyrPxcpCBGaTjiO>>16&255]+kJndetKVMsoFRWYSyrPxcpCBGaTjih[kJndetKVMsoFRWYSyrPxcpCBGaTjiO>>24&255]
  return kJndetKVMsoFRWYSyrPxcpCBGaTjiw
 def Web_DecryptKey(kJndetKVMsoFRWYSyrPxcpCBGaTjEw):
  kJndetKVMsoFRWYSyrPxcpCBGaTjiz=kJndetKVMsoFRWYSyrPxcpCBGaTjOH('kss2lym0kdw1lks3','utf-8')
  kJndetKVMsoFRWYSyrPxcpCBGaTjiD=kJndetKVMsoFRWYSyrPxcpCBGaTjOH('6yhlJ4WF9ZIj6I8n','utf-8')
  return kJndetKVMsoFRWYSyrPxcpCBGaTjiz,kJndetKVMsoFRWYSyrPxcpCBGaTjiD
 def Web_EncryptCiphertext(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,kJndetKVMsoFRWYSyrPxcpCBGaTjib):
  kJndetKVMsoFRWYSyrPxcpCBGaTjiH,kJndetKVMsoFRWYSyrPxcpCBGaTjiN=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Web_DecryptKey()
  kJndetKVMsoFRWYSyrPxcpCBGaTjiI=AES.new(kJndetKVMsoFRWYSyrPxcpCBGaTjiH,AES.MODE_CBC,kJndetKVMsoFRWYSyrPxcpCBGaTjiN,)
  kJndetKVMsoFRWYSyrPxcpCBGaTjif=kJndetKVMsoFRWYSyrPxcpCBGaTjiI.encrypt(Padding.pad(kJndetKVMsoFRWYSyrPxcpCBGaTjib.encode('utf-8'),16))
  return base64.standard_b64encode(kJndetKVMsoFRWYSyrPxcpCBGaTjif).decode('utf-8')
 def Web_DecryptPlaintext(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,kJndetKVMsoFRWYSyrPxcpCBGaTjif):
  kJndetKVMsoFRWYSyrPxcpCBGaTjiH,kJndetKVMsoFRWYSyrPxcpCBGaTjiN=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Web_DecryptKey()
  kJndetKVMsoFRWYSyrPxcpCBGaTjiI=AES.new(kJndetKVMsoFRWYSyrPxcpCBGaTjiH,AES.MODE_CBC,kJndetKVMsoFRWYSyrPxcpCBGaTjiN,)
  kJndetKVMsoFRWYSyrPxcpCBGaTjib=Padding.unpad(kJndetKVMsoFRWYSyrPxcpCBGaTjiI.decrypt(base64.standard_b64decode(kJndetKVMsoFRWYSyrPxcpCBGaTjif)),16)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjib.decode('utf-8')
 def WebCookies_Load(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,wc_file):
  try:
   fp=kJndetKVMsoFRWYSyrPxcpCBGaTjOv(wc_file,'r',-1,'utf-8')
   kJndetKVMsoFRWYSyrPxcpCBGaTjiL=fp.read()
   fp.close()
   kJndetKVMsoFRWYSyrPxcpCBGaTjiU=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Web_DecryptPlaintext(kJndetKVMsoFRWYSyrPxcpCBGaTjiL)
   kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjiU)
   kJndetKVMsoFRWYSyrPxcpCBGaTjiA =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDeviceList()
   if kJndetKVMsoFRWYSyrPxcpCBGaTjiA not in['','-']:
    kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies']['tving_uuid']=kJndetKVMsoFRWYSyrPxcpCBGaTjiA+'-'+kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetUniqueid(kJndetKVMsoFRWYSyrPxcpCBGaTjiA)
  except:
   return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  return kJndetKVMsoFRWYSyrPxcpCBGaTjOw
 def GetCredential2(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,user_id,user_pw,login_type,user_pf):
  try:
   if base64.standard_b64encode(user_id.encode()).decode('utf-8')=='a3ltOTUxMDg4':
    kJndetKVMsoFRWYSyrPxcpCBGaTjil='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx'
   else:
    kJndetKVMsoFRWYSyrPxcpCBGaTjil='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx'
   kJndetKVMsoFRWYSyrPxcpCBGaTjiX={'addon':'tvingm','method':'LOGIN','data':{'type':login_type,'id':user_id,'pw':user_pw,'pf':user_pf,}}
   kJndetKVMsoFRWYSyrPxcpCBGaTjiX=json.dumps(kJndetKVMsoFRWYSyrPxcpCBGaTjiX,separators=(',',':'))
   kJndetKVMsoFRWYSyrPxcpCBGaTjiX=base64.standard_b64encode(kJndetKVMsoFRWYSyrPxcpCBGaTjiX.encode()).decode('utf-8')
   kJndetKVMsoFRWYSyrPxcpCBGaTjEX={'proxy-mini':kJndetKVMsoFRWYSyrPxcpCBGaTjiX}
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=requests.get(base64.standard_b64decode(kJndetKVMsoFRWYSyrPxcpCBGaTjil).decode('utf-8'),headers=kJndetKVMsoFRWYSyrPxcpCBGaTjEX)
   if kJndetKVMsoFRWYSyrPxcpCBGaTjig.status_code!=200:
    kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Init_TV_Total()
    return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
   kJndetKVMsoFRWYSyrPxcpCBGaTjiq=base64.standard_b64decode(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text).decode('utf-8')
   kJndetKVMsoFRWYSyrPxcpCBGaTjiq=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjiq)
   kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies']=kJndetKVMsoFRWYSyrPxcpCBGaTjiq
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
   kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Init_TV_Total()
   return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  return kJndetKVMsoFRWYSyrPxcpCBGaTjOw
 def GetCredential(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,user_id,user_pw,login_type,user_pf):
  from curl_cffi import requests
  kJndetKVMsoFRWYSyrPxcpCBGaTjuE='chrome' 
  kJndetKVMsoFRWYSyrPxcpCBGaTjui=requests.Session()
  try:
   if login_type=='0':
    kJndetKVMsoFRWYSyrPxcpCBGaTjuQ='https://user.tving.com/pc/user/otherLogin.tving?loginType=10&from=pc&csite=&isAuto=false&rtUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   else:
    kJndetKVMsoFRWYSyrPxcpCBGaTjuQ='https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   kJndetKVMsoFRWYSyrPxcpCBGaTjEX={'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language':'ko-KR,ko;q=0.9','cache-control':'no-cache','pragma':'no-cache','priority':'u=0, i','referer':'https://www.tving.com/',}
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjui.get(kJndetKVMsoFRWYSyrPxcpCBGaTjuQ,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjEX,impersonate=kJndetKVMsoFRWYSyrPxcpCBGaTjuE)
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq('{} - {}'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjig.status_code,kJndetKVMsoFRWYSyrPxcpCBGaTjig.url))
   for kJndetKVMsoFRWYSyrPxcpCBGaTjum in kJndetKVMsoFRWYSyrPxcpCBGaTjig.cookies.jar:
    kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies'][kJndetKVMsoFRWYSyrPxcpCBGaTjum.name]=kJndetKVMsoFRWYSyrPxcpCBGaTjum.value
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
   kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Init_TV_Total()
   return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuv=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   kJndetKVMsoFRWYSyrPxcpCBGaTjuw={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':kJndetKVMsoFRWYSyrPxcpCBGaTjOQ,'cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   kJndetKVMsoFRWYSyrPxcpCBGaTjEX['referer']=kJndetKVMsoFRWYSyrPxcpCBGaTjuQ
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjui.post(url=kJndetKVMsoFRWYSyrPxcpCBGaTjuv,data=kJndetKVMsoFRWYSyrPxcpCBGaTjuw,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjEX,impersonate=kJndetKVMsoFRWYSyrPxcpCBGaTjuE)
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq('{} - {}'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjig.status_code,kJndetKVMsoFRWYSyrPxcpCBGaTjig.url))
   for kJndetKVMsoFRWYSyrPxcpCBGaTjum in kJndetKVMsoFRWYSyrPxcpCBGaTjig.cookies.jar:
    kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies'][kJndetKVMsoFRWYSyrPxcpCBGaTjum.name]=kJndetKVMsoFRWYSyrPxcpCBGaTjum.value
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
   kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Init_TV_Total()
   return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  kJndetKVMsoFRWYSyrPxcpCBGaTjuh=[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjuO =''
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   kJndetKVMsoFRWYSyrPxcpCBGaTjEX['referer']=kJndetKVMsoFRWYSyrPxcpCBGaTjuv
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjui.get(url=kJndetKVMsoFRWYSyrPxcpCBGaTjuz,data=kJndetKVMsoFRWYSyrPxcpCBGaTjuw,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjEX,impersonate=kJndetKVMsoFRWYSyrPxcpCBGaTjuE)
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq('{} - {}'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjig.status_code,kJndetKVMsoFRWYSyrPxcpCBGaTjig.url))
   for kJndetKVMsoFRWYSyrPxcpCBGaTjum in kJndetKVMsoFRWYSyrPxcpCBGaTjig.cookies.jar:
    kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies'][kJndetKVMsoFRWYSyrPxcpCBGaTjum.name]=kJndetKVMsoFRWYSyrPxcpCBGaTjum.value
   kJndetKVMsoFRWYSyrPxcpCBGaTjuh =re.findall('data-profile-no="\d+"',kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   for i in kJndetKVMsoFRWYSyrPxcpCBGaTjOD(kJndetKVMsoFRWYSyrPxcpCBGaTjOh(kJndetKVMsoFRWYSyrPxcpCBGaTjuh)):
    kJndetKVMsoFRWYSyrPxcpCBGaTjuD =kJndetKVMsoFRWYSyrPxcpCBGaTjuh[i].replace('data-profile-no=','').replace('"','')
    kJndetKVMsoFRWYSyrPxcpCBGaTjuh[i]=kJndetKVMsoFRWYSyrPxcpCBGaTjuD
   kJndetKVMsoFRWYSyrPxcpCBGaTjuO=kJndetKVMsoFRWYSyrPxcpCBGaTjuh[user_pf]
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
   kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Init_TV_Total()
   return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuH ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   kJndetKVMsoFRWYSyrPxcpCBGaTjEX['referer']=kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjuw={'profileNo':kJndetKVMsoFRWYSyrPxcpCBGaTjuO}
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjui.post(url=kJndetKVMsoFRWYSyrPxcpCBGaTjuH,data=kJndetKVMsoFRWYSyrPxcpCBGaTjuw,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjEX,impersonate=kJndetKVMsoFRWYSyrPxcpCBGaTjuE)
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq('{} - {}'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjig.status_code,kJndetKVMsoFRWYSyrPxcpCBGaTjig.url))
   for kJndetKVMsoFRWYSyrPxcpCBGaTjum in kJndetKVMsoFRWYSyrPxcpCBGaTjig.cookies.jar:
    kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies'][kJndetKVMsoFRWYSyrPxcpCBGaTjum.name]=kJndetKVMsoFRWYSyrPxcpCBGaTjum.value
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
   kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Init_TV_Total()
   return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  kJndetKVMsoFRWYSyrPxcpCBGaTjiA =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDeviceList()
  if kJndetKVMsoFRWYSyrPxcpCBGaTjiA not in['','-']:
   kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies']['tving_uuid']=kJndetKVMsoFRWYSyrPxcpCBGaTjiA+'-'+kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetUniqueid(kJndetKVMsoFRWYSyrPxcpCBGaTjiA)
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.JsonFile_Save(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.COOKIE_FILE_NAME,kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjOw
 def GetDeviceList(kJndetKVMsoFRWYSyrPxcpCBGaTjEw):
  kJndetKVMsoFRWYSyrPxcpCBGaTjuN=[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjuI='-'
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v1/user/device/list'
   kJndetKVMsoFRWYSyrPxcpCBGaTjuf=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjub=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
   kJndetKVMsoFRWYSyrPxcpCBGaTjEq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.makeDefaultCookies()
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjuf,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjub,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjEq)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuN=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(kJndetKVMsoFRWYSyrPxcpCBGaTjuN)
   for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjuN:
    if kJndetKVMsoFRWYSyrPxcpCBGaTjuU['model'].lower().startswith('pc'):
     kJndetKVMsoFRWYSyrPxcpCBGaTjuI=kJndetKVMsoFRWYSyrPxcpCBGaTjuU['uuid']
     break
   if kJndetKVMsoFRWYSyrPxcpCBGaTjuI=='-':
    kJndetKVMsoFRWYSyrPxcpCBGaTjuI=kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetNoCache(timetype=1))
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjuI
 def Get_Now_Datetime(kJndetKVMsoFRWYSyrPxcpCBGaTjEw):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,mediacode,sel_quality,stype,pvrmode='-',optUHD=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ):
  kJndetKVMsoFRWYSyrPxcpCBGaTjul ={'streaming_url':'','subtitleYn':kJndetKVMsoFRWYSyrPxcpCBGaTjOQ,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'','watermark':'','watermarkKey':'','qt_stream':'',}
  kJndetKVMsoFRWYSyrPxcpCBGaTjuI =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies']['tving_uuid'].split('-')[0] 
  kJndetKVMsoFRWYSyrPxcpCBGaTjuX =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies']['tving_uuid'] 
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjug=kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetNoCache(1))
   if stype!='tvingtv':
    kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v2/media/stream/info'
    kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
    kJndetKVMsoFRWYSyrPxcpCBGaTjub={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':kJndetKVMsoFRWYSyrPxcpCBGaTjuX,'deviceInfo':'PC','noCache':kJndetKVMsoFRWYSyrPxcpCBGaTjug,}
    kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
    kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
    kJndetKVMsoFRWYSyrPxcpCBGaTjEq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.makeDefaultCookies()
    kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjEq)
    if kJndetKVMsoFRWYSyrPxcpCBGaTjig.status_code!=200:
     kJndetKVMsoFRWYSyrPxcpCBGaTjul['error_msg']='First Step - {} error'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjig.status_code)
     return kJndetKVMsoFRWYSyrPxcpCBGaTjul
    kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
    if kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']['code']=='060':
     for kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjEl in kJndetKVMsoFRWYSyrPxcpCBGaTjEu.items():
      if kJndetKVMsoFRWYSyrPxcpCBGaTjEl==sel_quality:
       kJndetKVMsoFRWYSyrPxcpCBGaTjQE=kJndetKVMsoFRWYSyrPxcpCBGaTjEA
    elif kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']['code']!='000':
     kJndetKVMsoFRWYSyrPxcpCBGaTjul['error_msg']=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']['message']
     return kJndetKVMsoFRWYSyrPxcpCBGaTjul
    else: 
     if not('stream' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']):return kJndetKVMsoFRWYSyrPxcpCBGaTjul
     kJndetKVMsoFRWYSyrPxcpCBGaTjQi=[]
     for kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjEl in kJndetKVMsoFRWYSyrPxcpCBGaTjEu.items():
      for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['stream']['quality']:
       if kJndetKVMsoFRWYSyrPxcpCBGaTjuU['active']=='Y' and kJndetKVMsoFRWYSyrPxcpCBGaTjuU['code']==kJndetKVMsoFRWYSyrPxcpCBGaTjEA:
        kJndetKVMsoFRWYSyrPxcpCBGaTjQi.append({kJndetKVMsoFRWYSyrPxcpCBGaTjEu.get(kJndetKVMsoFRWYSyrPxcpCBGaTjuU['code']):kJndetKVMsoFRWYSyrPxcpCBGaTjuU['code']})
     kJndetKVMsoFRWYSyrPxcpCBGaTjQE=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.CheckQuality(sel_quality,kJndetKVMsoFRWYSyrPxcpCBGaTjQi)
     try:
      if optUHD==kJndetKVMsoFRWYSyrPxcpCBGaTjOw and kJndetKVMsoFRWYSyrPxcpCBGaTjQE=='stream50' and 'stream_support_info' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['content']['info']:
       if kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['content']['info']['stream_support_info']!=kJndetKVMsoFRWYSyrPxcpCBGaTjOu:
        if 'stream70' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['content']['info']['stream_support_info']:
         kJndetKVMsoFRWYSyrPxcpCBGaTjQE='stream70'
         kJndetKVMsoFRWYSyrPxcpCBGaTjul['qt_stream']='stream70'
     except:
      pass
     try:
      if optUHD==kJndetKVMsoFRWYSyrPxcpCBGaTjOw and kJndetKVMsoFRWYSyrPxcpCBGaTjQE=='stream50' and 'stream' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['content']['info']:
       if kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['content']['info']['stream']!=kJndetKVMsoFRWYSyrPxcpCBGaTjOu:
        for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['content']['info']['stream']:
         if kJndetKVMsoFRWYSyrPxcpCBGaTjuU['code']=='stream70':
          kJndetKVMsoFRWYSyrPxcpCBGaTjQE='stream70'
          break
     except:
      pass
   else:
    kJndetKVMsoFRWYSyrPxcpCBGaTjQE='stream40'
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
   kJndetKVMsoFRWYSyrPxcpCBGaTjul['error_msg']='First Step - except error'
   return kJndetKVMsoFRWYSyrPxcpCBGaTjul
  kJndetKVMsoFRWYSyrPxcpCBGaTjul['qt_stream']=kJndetKVMsoFRWYSyrPxcpCBGaTjQE
  kJndetKVMsoFRWYSyrPxcpCBGaTjhq(kJndetKVMsoFRWYSyrPxcpCBGaTjQE)
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjug=kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetNoCache(1))
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v3/media/stream/info'
   if kJndetKVMsoFRWYSyrPxcpCBGaTjul['qt_stream']=='stream70':
    kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams(uhd=kJndetKVMsoFRWYSyrPxcpCBGaTjOw)
    kJndetKVMsoFRWYSyrPxcpCBGaTjub={'mediaCode':mediacode,'deviceId':kJndetKVMsoFRWYSyrPxcpCBGaTjuI,'uuid':kJndetKVMsoFRWYSyrPxcpCBGaTjuX,'deviceInfo':'PC_Chrome WebView','streamCode':kJndetKVMsoFRWYSyrPxcpCBGaTjQE,'noCache':kJndetKVMsoFRWYSyrPxcpCBGaTjug,'callingFrom':'HTML5','model':'android_chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header','streamType':'hls',}
   else:
    kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
    kJndetKVMsoFRWYSyrPxcpCBGaTjub={'mediaCode':mediacode,'deviceId':kJndetKVMsoFRWYSyrPxcpCBGaTjuI,'uuid':kJndetKVMsoFRWYSyrPxcpCBGaTjuX,'deviceInfo':'PC_Chrome','streamCode':kJndetKVMsoFRWYSyrPxcpCBGaTjQE,'noCache':kJndetKVMsoFRWYSyrPxcpCBGaTjug,'callingFrom':'HTML5','model':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjEq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.makeDefaultCookies()
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Post',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjEq,redirects=kJndetKVMsoFRWYSyrPxcpCBGaTjOw)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']['code']!='000':
    kJndetKVMsoFRWYSyrPxcpCBGaTjul['error_msg']=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']['message']
    return kJndetKVMsoFRWYSyrPxcpCBGaTjul
   kJndetKVMsoFRWYSyrPxcpCBGaTjQu=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['stream']
   if kJndetKVMsoFRWYSyrPxcpCBGaTjQu['drm_yn']=='Y':
    kJndetKVMsoFRWYSyrPxcpCBGaTjQm=kJndetKVMsoFRWYSyrPxcpCBGaTjQu['playback']['drm']['widevine']
    for kJndetKVMsoFRWYSyrPxcpCBGaTjQv in kJndetKVMsoFRWYSyrPxcpCBGaTjQu['playback']['drm']['license']['drm_license_data']:
     if kJndetKVMsoFRWYSyrPxcpCBGaTjQv['drm_type']=='Widevine':
      kJndetKVMsoFRWYSyrPxcpCBGaTjul['drm_server_url'] =kJndetKVMsoFRWYSyrPxcpCBGaTjQv['drm_server_url']
      kJndetKVMsoFRWYSyrPxcpCBGaTjul['drm_header_key'] =kJndetKVMsoFRWYSyrPxcpCBGaTjQv['drm_header_key']
      kJndetKVMsoFRWYSyrPxcpCBGaTjul['drm_header_value']=kJndetKVMsoFRWYSyrPxcpCBGaTjQv['drm_header_value']
      break
   else:
    kJndetKVMsoFRWYSyrPxcpCBGaTjQm=kJndetKVMsoFRWYSyrPxcpCBGaTjQu['playback']['non_drm']
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
   kJndetKVMsoFRWYSyrPxcpCBGaTjul['error_msg']='Second Step - except error'
   return kJndetKVMsoFRWYSyrPxcpCBGaTjul
  kJndetKVMsoFRWYSyrPxcpCBGaTjQw=kJndetKVMsoFRWYSyrPxcpCBGaTjug
  kJndetKVMsoFRWYSyrPxcpCBGaTjQm=kJndetKVMsoFRWYSyrPxcpCBGaTjQm.split('|')[1]
  kJndetKVMsoFRWYSyrPxcpCBGaTjQm,kJndetKVMsoFRWYSyrPxcpCBGaTjQh,kJndetKVMsoFRWYSyrPxcpCBGaTjQO=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Decrypt_Url(kJndetKVMsoFRWYSyrPxcpCBGaTjQm,mediacode,kJndetKVMsoFRWYSyrPxcpCBGaTjQw)
  kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url']=kJndetKVMsoFRWYSyrPxcpCBGaTjQm
  kJndetKVMsoFRWYSyrPxcpCBGaTjul['watermark'] =kJndetKVMsoFRWYSyrPxcpCBGaTjQh
  kJndetKVMsoFRWYSyrPxcpCBGaTjul['watermarkKey']=kJndetKVMsoFRWYSyrPxcpCBGaTjQO
  if 'subtitles' in kJndetKVMsoFRWYSyrPxcpCBGaTjQu:
   for kJndetKVMsoFRWYSyrPxcpCBGaTjQz in kJndetKVMsoFRWYSyrPxcpCBGaTjQu.get('subtitles'):
    if kJndetKVMsoFRWYSyrPxcpCBGaTjQz.get('code')in['KO','KO_CC']:
     kJndetKVMsoFRWYSyrPxcpCBGaTjul['subtitleYn']=kJndetKVMsoFRWYSyrPxcpCBGaTjOw
     break
  kJndetKVMsoFRWYSyrPxcpCBGaTjQD=urllib.parse.urlparse(kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url'])
  kJndetKVMsoFRWYSyrPxcpCBGaTjQH =kJndetKVMsoFRWYSyrPxcpCBGaTjQD.path.strip('/').split('/')
  kJndetKVMsoFRWYSyrPxcpCBGaTjul['url_filename']=kJndetKVMsoFRWYSyrPxcpCBGaTjQH[kJndetKVMsoFRWYSyrPxcpCBGaTjOh(kJndetKVMsoFRWYSyrPxcpCBGaTjQH)-1]
  return kJndetKVMsoFRWYSyrPxcpCBGaTjul
 def TestUrl(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,kJndetKVMsoFRWYSyrPxcpCBGaTjil):
  kJndetKVMsoFRWYSyrPxcpCBGaTjEX={}
  kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,redirects=kJndetKVMsoFRWYSyrPxcpCBGaTjOw)
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TextFile_Save(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV_SESSION_TEXT1,kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
 def Tving_Parse_mpd(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,stream_url,watermarkKey=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,watermark=kJndetKVMsoFRWYSyrPxcpCBGaTjOu):
  if watermarkKey not in['',kJndetKVMsoFRWYSyrPxcpCBGaTjOu]:
   kJndetKVMsoFRWYSyrPxcpCBGaTjEX={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,}
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=requests.get(url=stream_url,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjEX,allow_redirects=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ)
  else:
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=requests.get(url=stream_url)
  kJndetKVMsoFRWYSyrPxcpCBGaTjQN=kJndetKVMsoFRWYSyrPxcpCBGaTjig.content.decode('utf-8')
  kJndetKVMsoFRWYSyrPxcpCBGaTjQI=0
  kJndetKVMsoFRWYSyrPxcpCBGaTjQf =ET.ElementTree(ET.fromstring(kJndetKVMsoFRWYSyrPxcpCBGaTjQN))
  kJndetKVMsoFRWYSyrPxcpCBGaTjQb =kJndetKVMsoFRWYSyrPxcpCBGaTjQf.getroot()
  kJndetKVMsoFRWYSyrPxcpCBGaTjQL=re.match(r'\{.*\}',kJndetKVMsoFRWYSyrPxcpCBGaTjQb.tag)[0] 
  kJndetKVMsoFRWYSyrPxcpCBGaTjQU=kJndetKVMsoFRWYSyrPxcpCBGaTjOI([node for _,node in ET.iterparse(io.StringIO(kJndetKVMsoFRWYSyrPxcpCBGaTjQN),events=['start-ns'])])
  for kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjmH in kJndetKVMsoFRWYSyrPxcpCBGaTjQU.items():
   if kJndetKVMsoFRWYSyrPxcpCBGaTjEA!='ns2':
    ET.register_namespace(kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjmH)
  kJndetKVMsoFRWYSyrPxcpCBGaTjQA=kJndetKVMsoFRWYSyrPxcpCBGaTjQb.find(kJndetKVMsoFRWYSyrPxcpCBGaTjQL+'Period')
  for kJndetKVMsoFRWYSyrPxcpCBGaTjQl in kJndetKVMsoFRWYSyrPxcpCBGaTjQA.findall(kJndetKVMsoFRWYSyrPxcpCBGaTjQL+'AdaptationSet'):
   if(kJndetKVMsoFRWYSyrPxcpCBGaTjQl.attrib.get('mimeType')=='video/mp4' or kJndetKVMsoFRWYSyrPxcpCBGaTjQl.attrib.get('contentType')=='video'):
    for kJndetKVMsoFRWYSyrPxcpCBGaTjQX in kJndetKVMsoFRWYSyrPxcpCBGaTjQl.findall(kJndetKVMsoFRWYSyrPxcpCBGaTjQL+'Representation'):
     kJndetKVMsoFRWYSyrPxcpCBGaTjQg=kJndetKVMsoFRWYSyrPxcpCBGaTjOz(kJndetKVMsoFRWYSyrPxcpCBGaTjQX.attrib.get('bandwidth'))
     if kJndetKVMsoFRWYSyrPxcpCBGaTjQI<kJndetKVMsoFRWYSyrPxcpCBGaTjQg:kJndetKVMsoFRWYSyrPxcpCBGaTjQI=kJndetKVMsoFRWYSyrPxcpCBGaTjQg
    for kJndetKVMsoFRWYSyrPxcpCBGaTjQX in kJndetKVMsoFRWYSyrPxcpCBGaTjQl.findall(kJndetKVMsoFRWYSyrPxcpCBGaTjQL+'Representation'):
     if kJndetKVMsoFRWYSyrPxcpCBGaTjQI>kJndetKVMsoFRWYSyrPxcpCBGaTjOz(kJndetKVMsoFRWYSyrPxcpCBGaTjQX.attrib.get('bandwidth')):
      kJndetKVMsoFRWYSyrPxcpCBGaTjQl.remove(kJndetKVMsoFRWYSyrPxcpCBGaTjQX)
   else:
    continue
  kJndetKVMsoFRWYSyrPxcpCBGaTjQq=ET.tostring(kJndetKVMsoFRWYSyrPxcpCBGaTjQb).decode('utf-8')
  kJndetKVMsoFRWYSyrPxcpCBGaTjmE='<?xml version="1.0" encoding="UTF-8"?>\n'
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TextFile_Save(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV_STREAM_FILENAME,kJndetKVMsoFRWYSyrPxcpCBGaTjmE+kJndetKVMsoFRWYSyrPxcpCBGaTjQq)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjOw
 def Tving_Parse_m3u8(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,stream_url):
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=requests.get(url=stream_url,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,stream=kJndetKVMsoFRWYSyrPxcpCBGaTjOw)
   kJndetKVMsoFRWYSyrPxcpCBGaTjmi=kJndetKVMsoFRWYSyrPxcpCBGaTjig.content.decode('utf-8')
   if '#EXTM3U' not in kJndetKVMsoFRWYSyrPxcpCBGaTjmi:
    return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
   if '#EXT-X-STREAM-INF' not in kJndetKVMsoFRWYSyrPxcpCBGaTjmi: 
    return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
   kJndetKVMsoFRWYSyrPxcpCBGaTjmu=0
   for kJndetKVMsoFRWYSyrPxcpCBGaTjmQ in kJndetKVMsoFRWYSyrPxcpCBGaTjmi.splitlines():
    if kJndetKVMsoFRWYSyrPxcpCBGaTjmQ.startswith('#EXT-X-STREAM-INF'):
     kJndetKVMsoFRWYSyrPxcpCBGaTjmv=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.MediaLine_Parse(kJndetKVMsoFRWYSyrPxcpCBGaTjmQ,'#EXT-X-STREAM-INF')
     if kJndetKVMsoFRWYSyrPxcpCBGaTjmu<kJndetKVMsoFRWYSyrPxcpCBGaTjOz(kJndetKVMsoFRWYSyrPxcpCBGaTjmv.get('BANDWIDTH')):
      kJndetKVMsoFRWYSyrPxcpCBGaTjmu=kJndetKVMsoFRWYSyrPxcpCBGaTjOz(kJndetKVMsoFRWYSyrPxcpCBGaTjmv.get('BANDWIDTH'))
   kJndetKVMsoFRWYSyrPxcpCBGaTjmw=[]
   kJndetKVMsoFRWYSyrPxcpCBGaTjmh=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
   for kJndetKVMsoFRWYSyrPxcpCBGaTjmQ in kJndetKVMsoFRWYSyrPxcpCBGaTjmi.splitlines():
    if kJndetKVMsoFRWYSyrPxcpCBGaTjmh==kJndetKVMsoFRWYSyrPxcpCBGaTjOw:
     kJndetKVMsoFRWYSyrPxcpCBGaTjmh=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
     continue
    if kJndetKVMsoFRWYSyrPxcpCBGaTjmQ.startswith('#EXT-X-STREAM-INF'):
     kJndetKVMsoFRWYSyrPxcpCBGaTjmv=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.MediaLine_Parse(kJndetKVMsoFRWYSyrPxcpCBGaTjmQ,'#EXT-X-STREAM-INF')
     if kJndetKVMsoFRWYSyrPxcpCBGaTjmu!=kJndetKVMsoFRWYSyrPxcpCBGaTjOz(kJndetKVMsoFRWYSyrPxcpCBGaTjmv.get('BANDWIDTH')):
      kJndetKVMsoFRWYSyrPxcpCBGaTjmh=kJndetKVMsoFRWYSyrPxcpCBGaTjOw
      continue
    kJndetKVMsoFRWYSyrPxcpCBGaTjmw.append(kJndetKVMsoFRWYSyrPxcpCBGaTjmQ)
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
   return kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  kJndetKVMsoFRWYSyrPxcpCBGaTjmO='\n'.join(kJndetKVMsoFRWYSyrPxcpCBGaTjmw)
  kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TextFile_Save(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV_STREAM_FILENAME,kJndetKVMsoFRWYSyrPxcpCBGaTjmO)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjOw
 def MediaLine_Parse(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,kJndetKVMsoFRWYSyrPxcpCBGaTjmQ,prefix):
  kJndetKVMsoFRWYSyrPxcpCBGaTjmv={}
  for kJndetKVMsoFRWYSyrPxcpCBGaTjmz in kJndetKVMsoFRWYSyrPxcpCBGaTjEm.split(kJndetKVMsoFRWYSyrPxcpCBGaTjmQ.replace(prefix+':',''))[1::2]:
   kJndetKVMsoFRWYSyrPxcpCBGaTjmD,kJndetKVMsoFRWYSyrPxcpCBGaTjmH=kJndetKVMsoFRWYSyrPxcpCBGaTjmz.split('=',1)
   kJndetKVMsoFRWYSyrPxcpCBGaTjmv[kJndetKVMsoFRWYSyrPxcpCBGaTjmD.upper()]=kJndetKVMsoFRWYSyrPxcpCBGaTjmH.replace('"','').strip()
  return kJndetKVMsoFRWYSyrPxcpCBGaTjmv
 def CheckQuality(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,sel_qt,kJndetKVMsoFRWYSyrPxcpCBGaTjQi):
  for kJndetKVMsoFRWYSyrPxcpCBGaTjmN in kJndetKVMsoFRWYSyrPxcpCBGaTjQi:
   if sel_qt>=kJndetKVMsoFRWYSyrPxcpCBGaTjOf(kJndetKVMsoFRWYSyrPxcpCBGaTjmN)[0]:return kJndetKVMsoFRWYSyrPxcpCBGaTjmN.get(kJndetKVMsoFRWYSyrPxcpCBGaTjOf(kJndetKVMsoFRWYSyrPxcpCBGaTjmN)[0])
   kJndetKVMsoFRWYSyrPxcpCBGaTjmI=kJndetKVMsoFRWYSyrPxcpCBGaTjmN.get(kJndetKVMsoFRWYSyrPxcpCBGaTjOf(kJndetKVMsoFRWYSyrPxcpCBGaTjmN)[0])
  return kJndetKVMsoFRWYSyrPxcpCBGaTjmI
 def makeOocUrl(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,ooc_params):
  kJndetKVMsoFRWYSyrPxcpCBGaTjil=''
  for kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjEl in ooc_params.items():
   kJndetKVMsoFRWYSyrPxcpCBGaTjil+="%s=%s^"%(kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjEl)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjil
 def GetLiveChannelList(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,stype,page_int):
  kJndetKVMsoFRWYSyrPxcpCBGaTjuN=[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v2/media/lives'
   if stype=='onair': 
    kJndetKVMsoFRWYSyrPxcpCBGaTjmb='CPCS0100,CPCS0400'
   else:
    kJndetKVMsoFRWYSyrPxcpCBGaTjmb='CPCS0300'
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'cacheType':'main','pageNo':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(page_int),'pageSize':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':kJndetKVMsoFRWYSyrPxcpCBGaTjmb,}
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if not('result' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']):return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
   kJndetKVMsoFRWYSyrPxcpCBGaTjmL=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']
   for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjmL:
    kJndetKVMsoFRWYSyrPxcpCBGaTjmU=kJndetKVMsoFRWYSyrPxcpCBGaTjmX=kJndetKVMsoFRWYSyrPxcpCBGaTjmg=''
    kJndetKVMsoFRWYSyrPxcpCBGaTjmA=kJndetKVMsoFRWYSyrPxcpCBGaTjvL=''
    kJndetKVMsoFRWYSyrPxcpCBGaTjml=kJndetKVMsoFRWYSyrPxcpCBGaTjuU['live_code']
    kJndetKVMsoFRWYSyrPxcpCBGaTjmU =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['channel']['name']['ko']
    if kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['episode']!=kJndetKVMsoFRWYSyrPxcpCBGaTjOu:
     kJndetKVMsoFRWYSyrPxcpCBGaTjmX =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['program']['name']['ko']
     kJndetKVMsoFRWYSyrPxcpCBGaTjmX =kJndetKVMsoFRWYSyrPxcpCBGaTjmX+', '+kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['episode']['frequency'])+'회'
     kJndetKVMsoFRWYSyrPxcpCBGaTjmg=kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['episode']['synopsis']['ko']
    else:
     kJndetKVMsoFRWYSyrPxcpCBGaTjmX =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['program']['name']['ko']
     kJndetKVMsoFRWYSyrPxcpCBGaTjmg=kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['program']['synopsis']['ko']
    try: 
     kJndetKVMsoFRWYSyrPxcpCBGaTjmq =''
     kJndetKVMsoFRWYSyrPxcpCBGaTjvE =''
     kJndetKVMsoFRWYSyrPxcpCBGaTjvi=''
     kJndetKVMsoFRWYSyrPxcpCBGaTjvu =''
     kJndetKVMsoFRWYSyrPxcpCBGaTjvQ =''
     kJndetKVMsoFRWYSyrPxcpCBGaTjvm =''
     for kJndetKVMsoFRWYSyrPxcpCBGaTjvw in kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['program']['image']:
      if kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP0900':kJndetKVMsoFRWYSyrPxcpCBGaTjvE =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
      elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP1800':kJndetKVMsoFRWYSyrPxcpCBGaTjvi=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
      elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP2000':kJndetKVMsoFRWYSyrPxcpCBGaTjvu =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
      elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP1900':kJndetKVMsoFRWYSyrPxcpCBGaTjvQ =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
      elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP0200':kJndetKVMsoFRWYSyrPxcpCBGaTjvm =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
      elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP0500':kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
      elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP0800':kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     if kJndetKVMsoFRWYSyrPxcpCBGaTjmq=='':
      for kJndetKVMsoFRWYSyrPxcpCBGaTjvw in kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['channel']['image']:
       if kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIC0400':kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
       elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIC1400':kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
       elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIC1900':kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
    except:
     kJndetKVMsoFRWYSyrPxcpCBGaTjOu
    try:
     kJndetKVMsoFRWYSyrPxcpCBGaTjvh =[]
     kJndetKVMsoFRWYSyrPxcpCBGaTjvO=[]
     kJndetKVMsoFRWYSyrPxcpCBGaTjvz =[]
     kJndetKVMsoFRWYSyrPxcpCBGaTjvD=''
     kJndetKVMsoFRWYSyrPxcpCBGaTjvH=''
     kJndetKVMsoFRWYSyrPxcpCBGaTjvN=''
     for kJndetKVMsoFRWYSyrPxcpCBGaTjvI in kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('schedule').get('program').get('actor'):
      if kJndetKVMsoFRWYSyrPxcpCBGaTjvI!='' and kJndetKVMsoFRWYSyrPxcpCBGaTjvI!=u'없음':kJndetKVMsoFRWYSyrPxcpCBGaTjvh.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvI)
     for kJndetKVMsoFRWYSyrPxcpCBGaTjvf in kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('schedule').get('program').get('director'):
      if kJndetKVMsoFRWYSyrPxcpCBGaTjvf!='' and kJndetKVMsoFRWYSyrPxcpCBGaTjvf!='-' and kJndetKVMsoFRWYSyrPxcpCBGaTjvf!=u'없음':kJndetKVMsoFRWYSyrPxcpCBGaTjvO.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvf)
     if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('schedule').get('program').get('category1_name').get('ko')!='':
      kJndetKVMsoFRWYSyrPxcpCBGaTjvz.append(kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['program']['category1_name']['ko'])
     if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('schedule').get('program').get('category2_name').get('ko')!='':
      kJndetKVMsoFRWYSyrPxcpCBGaTjvz.append(kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['program']['category2_name']['ko'])
     if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('schedule').get('program').get('product_year'):kJndetKVMsoFRWYSyrPxcpCBGaTjvD=kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['program']['product_year']
     if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('schedule').get('program').get('grade_code') :kJndetKVMsoFRWYSyrPxcpCBGaTjvH= kJndetKVMsoFRWYSyrPxcpCBGaTjEQ.get(kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['program']['grade_code'])
     if 'broad_dt' in kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('schedule').get('program'):
      kJndetKVMsoFRWYSyrPxcpCBGaTjvb =kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('schedule').get('program').get('broad_dt')
      kJndetKVMsoFRWYSyrPxcpCBGaTjvN='%s-%s-%s'%(kJndetKVMsoFRWYSyrPxcpCBGaTjvb[:4],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[4:6],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[6:])
    except:
     kJndetKVMsoFRWYSyrPxcpCBGaTjOu
    kJndetKVMsoFRWYSyrPxcpCBGaTjmA=kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['broadcast_start_time'])[8:12]
    kJndetKVMsoFRWYSyrPxcpCBGaTjvL =kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjuU['schedule']['broadcast_end_time'])[8:12]
    kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'channel':kJndetKVMsoFRWYSyrPxcpCBGaTjmU,'title':kJndetKVMsoFRWYSyrPxcpCBGaTjmX,'mediacode':kJndetKVMsoFRWYSyrPxcpCBGaTjml,'thumbnail':{'poster':kJndetKVMsoFRWYSyrPxcpCBGaTjvE,'thumb':kJndetKVMsoFRWYSyrPxcpCBGaTjmq,'clearlogo':kJndetKVMsoFRWYSyrPxcpCBGaTjvi,'icon':kJndetKVMsoFRWYSyrPxcpCBGaTjvu,'fanart':kJndetKVMsoFRWYSyrPxcpCBGaTjvm},'synopsis':kJndetKVMsoFRWYSyrPxcpCBGaTjmg,'channelepg':' [%s:%s ~ %s:%s]'%(kJndetKVMsoFRWYSyrPxcpCBGaTjmA[0:2],kJndetKVMsoFRWYSyrPxcpCBGaTjmA[2:],kJndetKVMsoFRWYSyrPxcpCBGaTjvL[0:2],kJndetKVMsoFRWYSyrPxcpCBGaTjvL[2:]),'cast':kJndetKVMsoFRWYSyrPxcpCBGaTjvh,'director':kJndetKVMsoFRWYSyrPxcpCBGaTjvO,'info_genre':kJndetKVMsoFRWYSyrPxcpCBGaTjvz,'year':kJndetKVMsoFRWYSyrPxcpCBGaTjvD,'mpaa':kJndetKVMsoFRWYSyrPxcpCBGaTjvH,'premiered':kJndetKVMsoFRWYSyrPxcpCBGaTjvN}
    kJndetKVMsoFRWYSyrPxcpCBGaTjuN.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
   if kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['has_more']=='Y':
    kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOw
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
 def GetProgramList(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,genre,orderby,page_int,genreCode='all'):
  kJndetKVMsoFRWYSyrPxcpCBGaTjuN=[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v2/media/episodes'
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'cacheType':'main','pageSize':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(page_int),}
   if genre not in['all','PARAMOUNT']:kJndetKVMsoFRWYSyrPxcpCBGaTjub['categoryCode']=genre
   if genreCode!='all' :kJndetKVMsoFRWYSyrPxcpCBGaTjub['genreCode'] =genreCode 
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if not('result' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']):return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
   kJndetKVMsoFRWYSyrPxcpCBGaTjmL=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']
   for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjmL:
    kJndetKVMsoFRWYSyrPxcpCBGaTjvA=kJndetKVMsoFRWYSyrPxcpCBGaTjuU['program']['code']
    kJndetKVMsoFRWYSyrPxcpCBGaTjmX =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['program']['name']['ko']
    kJndetKVMsoFRWYSyrPxcpCBGaTjvH =kJndetKVMsoFRWYSyrPxcpCBGaTjEQ.get(kJndetKVMsoFRWYSyrPxcpCBGaTjuU['program'].get('grade_code'))
    kJndetKVMsoFRWYSyrPxcpCBGaTjvE =''
    kJndetKVMsoFRWYSyrPxcpCBGaTjmq =''
    kJndetKVMsoFRWYSyrPxcpCBGaTjvi=''
    kJndetKVMsoFRWYSyrPxcpCBGaTjvu =''
    kJndetKVMsoFRWYSyrPxcpCBGaTjvQ =''
    for kJndetKVMsoFRWYSyrPxcpCBGaTjvw in kJndetKVMsoFRWYSyrPxcpCBGaTjuU['program']['image']:
     if kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP0900':kJndetKVMsoFRWYSyrPxcpCBGaTjvE =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP0200':kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP1800':kJndetKVMsoFRWYSyrPxcpCBGaTjvi=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP2000':kJndetKVMsoFRWYSyrPxcpCBGaTjvu =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP1900':kJndetKVMsoFRWYSyrPxcpCBGaTjvQ =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
    kJndetKVMsoFRWYSyrPxcpCBGaTjmg =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['program']['synopsis']['ko']
    try:
     kJndetKVMsoFRWYSyrPxcpCBGaTjvl=kJndetKVMsoFRWYSyrPxcpCBGaTjuU['channel']['name']['ko']
    except:
     kJndetKVMsoFRWYSyrPxcpCBGaTjvl=''
    try:
     kJndetKVMsoFRWYSyrPxcpCBGaTjvh =[]
     kJndetKVMsoFRWYSyrPxcpCBGaTjvO=[]
     kJndetKVMsoFRWYSyrPxcpCBGaTjvz =[]
     kJndetKVMsoFRWYSyrPxcpCBGaTjvD =''
     kJndetKVMsoFRWYSyrPxcpCBGaTjvN=''
     for kJndetKVMsoFRWYSyrPxcpCBGaTjvI in kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('program').get('actor'):
      if kJndetKVMsoFRWYSyrPxcpCBGaTjvI!='' and kJndetKVMsoFRWYSyrPxcpCBGaTjvI!='-' and kJndetKVMsoFRWYSyrPxcpCBGaTjvI!=u'없음':kJndetKVMsoFRWYSyrPxcpCBGaTjvh.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvI)
     for kJndetKVMsoFRWYSyrPxcpCBGaTjvf in kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('program').get('director'):
      if kJndetKVMsoFRWYSyrPxcpCBGaTjvf!='' and kJndetKVMsoFRWYSyrPxcpCBGaTjvf!='-' and kJndetKVMsoFRWYSyrPxcpCBGaTjvf!=u'없음':kJndetKVMsoFRWYSyrPxcpCBGaTjvO.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvf)
     if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('program').get('category1_name').get('ko')!='':
      kJndetKVMsoFRWYSyrPxcpCBGaTjvz.append(kJndetKVMsoFRWYSyrPxcpCBGaTjuU['program']['category1_name']['ko'])
     if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('program').get('category2_name').get('ko')!='':
      kJndetKVMsoFRWYSyrPxcpCBGaTjvz.append(kJndetKVMsoFRWYSyrPxcpCBGaTjuU['program']['category2_name']['ko'])
     if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('program').get('product_year'):kJndetKVMsoFRWYSyrPxcpCBGaTjvD=kJndetKVMsoFRWYSyrPxcpCBGaTjuU['program']['product_year']
     if 'broad_dt' in kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('program'):
      kJndetKVMsoFRWYSyrPxcpCBGaTjvb =kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('program').get('broad_dt')
      kJndetKVMsoFRWYSyrPxcpCBGaTjvN='%s-%s-%s'%(kJndetKVMsoFRWYSyrPxcpCBGaTjvb[:4],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[4:6],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[6:])
    except:
     kJndetKVMsoFRWYSyrPxcpCBGaTjOu
    kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'program':kJndetKVMsoFRWYSyrPxcpCBGaTjvA,'title':kJndetKVMsoFRWYSyrPxcpCBGaTjmX,'thumbnail':{'poster':kJndetKVMsoFRWYSyrPxcpCBGaTjvE,'thumb':kJndetKVMsoFRWYSyrPxcpCBGaTjmq,'clearlogo':kJndetKVMsoFRWYSyrPxcpCBGaTjvi,'icon':kJndetKVMsoFRWYSyrPxcpCBGaTjvu,'banner':kJndetKVMsoFRWYSyrPxcpCBGaTjvQ,'fanart':kJndetKVMsoFRWYSyrPxcpCBGaTjmq},'synopsis':kJndetKVMsoFRWYSyrPxcpCBGaTjmg,'channel':kJndetKVMsoFRWYSyrPxcpCBGaTjvl,'cast':kJndetKVMsoFRWYSyrPxcpCBGaTjvh,'director':kJndetKVMsoFRWYSyrPxcpCBGaTjvO,'info_genre':kJndetKVMsoFRWYSyrPxcpCBGaTjvz,'year':kJndetKVMsoFRWYSyrPxcpCBGaTjvD,'premiered':kJndetKVMsoFRWYSyrPxcpCBGaTjvN,'mpaa':kJndetKVMsoFRWYSyrPxcpCBGaTjvH}
    kJndetKVMsoFRWYSyrPxcpCBGaTjuN.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
   if kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['has_more']=='Y':kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOw
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
 def Get_UHD_ProgramList(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,page_int):
  kJndetKVMsoFRWYSyrPxcpCBGaTjuN=[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v2/operator/highlights'
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams(uhd=kJndetKVMsoFRWYSyrPxcpCBGaTjOw)
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(page_int),'pocType':'APP_X_TVING_4.0.0',}
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if not('result' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']):return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
   kJndetKVMsoFRWYSyrPxcpCBGaTjmL=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']
   for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjmL:
    kJndetKVMsoFRWYSyrPxcpCBGaTjvX=kJndetKVMsoFRWYSyrPxcpCBGaTjuU['content']['program']
    kJndetKVMsoFRWYSyrPxcpCBGaTjvg =kJndetKVMsoFRWYSyrPxcpCBGaTjvX['code']
    kJndetKVMsoFRWYSyrPxcpCBGaTjmX =kJndetKVMsoFRWYSyrPxcpCBGaTjvX['name']['ko'].strip()
    kJndetKVMsoFRWYSyrPxcpCBGaTjvH =kJndetKVMsoFRWYSyrPxcpCBGaTjEQ.get(kJndetKVMsoFRWYSyrPxcpCBGaTjvX.get('grade_code'))
    kJndetKVMsoFRWYSyrPxcpCBGaTjmg =kJndetKVMsoFRWYSyrPxcpCBGaTjvX['synopsis']['ko']
    kJndetKVMsoFRWYSyrPxcpCBGaTjvl =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['content']['channel']['name']['ko']
    kJndetKVMsoFRWYSyrPxcpCBGaTjvD =kJndetKVMsoFRWYSyrPxcpCBGaTjvX['product_year']
    kJndetKVMsoFRWYSyrPxcpCBGaTjvE =''
    kJndetKVMsoFRWYSyrPxcpCBGaTjmq =''
    kJndetKVMsoFRWYSyrPxcpCBGaTjvi=''
    kJndetKVMsoFRWYSyrPxcpCBGaTjvu =''
    kJndetKVMsoFRWYSyrPxcpCBGaTjvQ =''
    for kJndetKVMsoFRWYSyrPxcpCBGaTjvw in kJndetKVMsoFRWYSyrPxcpCBGaTjvX['image']:
     if kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP0900':kJndetKVMsoFRWYSyrPxcpCBGaTjvE =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP0200':kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP1800':kJndetKVMsoFRWYSyrPxcpCBGaTjvi=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP2000':kJndetKVMsoFRWYSyrPxcpCBGaTjvu =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP1900':kJndetKVMsoFRWYSyrPxcpCBGaTjvQ =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
    kJndetKVMsoFRWYSyrPxcpCBGaTjvz =[]
    kJndetKVMsoFRWYSyrPxcpCBGaTjvh =[]
    kJndetKVMsoFRWYSyrPxcpCBGaTjvO=[]
    kJndetKVMsoFRWYSyrPxcpCBGaTjvN =''
    if kJndetKVMsoFRWYSyrPxcpCBGaTjvX.get('category1_name').get('ko')!='':
     kJndetKVMsoFRWYSyrPxcpCBGaTjvz.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvX['category1_name']['ko'])
    if kJndetKVMsoFRWYSyrPxcpCBGaTjvX.get('category2_name').get('ko')!='':
     kJndetKVMsoFRWYSyrPxcpCBGaTjvz.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvX['category2_name']['ko'])
    for kJndetKVMsoFRWYSyrPxcpCBGaTjvI in kJndetKVMsoFRWYSyrPxcpCBGaTjvX.get('actor'):
     if kJndetKVMsoFRWYSyrPxcpCBGaTjvI!='' and kJndetKVMsoFRWYSyrPxcpCBGaTjvI!='-' and kJndetKVMsoFRWYSyrPxcpCBGaTjvI!=u'없음':kJndetKVMsoFRWYSyrPxcpCBGaTjvh.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvI)
    for kJndetKVMsoFRWYSyrPxcpCBGaTjvf in kJndetKVMsoFRWYSyrPxcpCBGaTjvX.get('director'):
     if kJndetKVMsoFRWYSyrPxcpCBGaTjvf!='' and kJndetKVMsoFRWYSyrPxcpCBGaTjvf!='-' and kJndetKVMsoFRWYSyrPxcpCBGaTjvf!=u'없음':kJndetKVMsoFRWYSyrPxcpCBGaTjvO.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvf)
    if kJndetKVMsoFRWYSyrPxcpCBGaTjvX.get('broad_dt')not in[kJndetKVMsoFRWYSyrPxcpCBGaTjOu,'']:
     kJndetKVMsoFRWYSyrPxcpCBGaTjvb =kJndetKVMsoFRWYSyrPxcpCBGaTjvX.get('broad_dt')
     kJndetKVMsoFRWYSyrPxcpCBGaTjvN='%s-%s-%s'%(kJndetKVMsoFRWYSyrPxcpCBGaTjvb[:4],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[4:6],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[6:])
    kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'program':kJndetKVMsoFRWYSyrPxcpCBGaTjvg,'title':kJndetKVMsoFRWYSyrPxcpCBGaTjmX,'mpaa':kJndetKVMsoFRWYSyrPxcpCBGaTjvH,'thumbnail':{'poster':kJndetKVMsoFRWYSyrPxcpCBGaTjvE,'thumb':kJndetKVMsoFRWYSyrPxcpCBGaTjmq,'clearlogo':kJndetKVMsoFRWYSyrPxcpCBGaTjvi,'icon':kJndetKVMsoFRWYSyrPxcpCBGaTjvu,'banner':kJndetKVMsoFRWYSyrPxcpCBGaTjvQ,'fanart':kJndetKVMsoFRWYSyrPxcpCBGaTjmq},'channel':kJndetKVMsoFRWYSyrPxcpCBGaTjvl,'synopsis':kJndetKVMsoFRWYSyrPxcpCBGaTjmg,'year':kJndetKVMsoFRWYSyrPxcpCBGaTjvD,'info_genre':kJndetKVMsoFRWYSyrPxcpCBGaTjvz,'cast':kJndetKVMsoFRWYSyrPxcpCBGaTjvh,'director':kJndetKVMsoFRWYSyrPxcpCBGaTjvO,'premiered':kJndetKVMsoFRWYSyrPxcpCBGaTjvN,}
    kJndetKVMsoFRWYSyrPxcpCBGaTjuN.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
 def Get_Origianl_ProgramList(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,page_int):
  kJndetKVMsoFRWYSyrPxcpCBGaTjuN=[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v2/media/band/originals'
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'pageSize':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(page_int),}
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjvq=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   kJndetKVMsoFRWYSyrPxcpCBGaTjEw.JsonFile_Save(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV_SESSION_COOKIES2,kJndetKVMsoFRWYSyrPxcpCBGaTjvq)
   if not('contents' in kJndetKVMsoFRWYSyrPxcpCBGaTjvq['body']):return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
   kJndetKVMsoFRWYSyrPxcpCBGaTjmL=kJndetKVMsoFRWYSyrPxcpCBGaTjvq['body']['contents']
   for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjmL:
    kJndetKVMsoFRWYSyrPxcpCBGaTjwE =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['vod_code']
    kJndetKVMsoFRWYSyrPxcpCBGaTjmX =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['vod_name']
    kJndetKVMsoFRWYSyrPxcpCBGaTjvE =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuU['image']
    kJndetKVMsoFRWYSyrPxcpCBGaTjwi ='movie' if kJndetKVMsoFRWYSyrPxcpCBGaTjwE.startswith('M')else 'vod'
    kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'vod_code':kJndetKVMsoFRWYSyrPxcpCBGaTjwE,'title':kJndetKVMsoFRWYSyrPxcpCBGaTjmX,'thumbnail':{'poster':kJndetKVMsoFRWYSyrPxcpCBGaTjvE,'thumb':kJndetKVMsoFRWYSyrPxcpCBGaTjvE},'vod_type':kJndetKVMsoFRWYSyrPxcpCBGaTjwi,}
    kJndetKVMsoFRWYSyrPxcpCBGaTjuN.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
   if kJndetKVMsoFRWYSyrPxcpCBGaTjvq['body']['has_more']=='Y':kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOw
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
 def GetEpisodeList(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,program_code,page_int,orderby='desc'):
  kJndetKVMsoFRWYSyrPxcpCBGaTjuN=[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v2/media/frequency/program/'+program_code
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if not('result' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']):return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
   kJndetKVMsoFRWYSyrPxcpCBGaTjmL=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']
   kJndetKVMsoFRWYSyrPxcpCBGaTjwu=kJndetKVMsoFRWYSyrPxcpCBGaTjOz(kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['total_count'])
   kJndetKVMsoFRWYSyrPxcpCBGaTjwQ =kJndetKVMsoFRWYSyrPxcpCBGaTjOz(kJndetKVMsoFRWYSyrPxcpCBGaTjwu//(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    kJndetKVMsoFRWYSyrPxcpCBGaTjwm =(kJndetKVMsoFRWYSyrPxcpCBGaTjwu-1)-((page_int-1)*kJndetKVMsoFRWYSyrPxcpCBGaTjEw.EPISODE_LIMIT)
   else:
    kJndetKVMsoFRWYSyrPxcpCBGaTjwm =(page_int-1)*kJndetKVMsoFRWYSyrPxcpCBGaTjEw.EPISODE_LIMIT
   for i in kJndetKVMsoFRWYSyrPxcpCBGaTjOD(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.EPISODE_LIMIT):
    if orderby=='desc':
     kJndetKVMsoFRWYSyrPxcpCBGaTjwv=kJndetKVMsoFRWYSyrPxcpCBGaTjwm-i
     if kJndetKVMsoFRWYSyrPxcpCBGaTjwv<0:break
    else:
     kJndetKVMsoFRWYSyrPxcpCBGaTjwv=kJndetKVMsoFRWYSyrPxcpCBGaTjwm+i
     if kJndetKVMsoFRWYSyrPxcpCBGaTjwv>=kJndetKVMsoFRWYSyrPxcpCBGaTjwu:break
    kJndetKVMsoFRWYSyrPxcpCBGaTjwh=kJndetKVMsoFRWYSyrPxcpCBGaTjmL[kJndetKVMsoFRWYSyrPxcpCBGaTjwv]['episode']['code']
    kJndetKVMsoFRWYSyrPxcpCBGaTjmX =kJndetKVMsoFRWYSyrPxcpCBGaTjmL[kJndetKVMsoFRWYSyrPxcpCBGaTjwv]['vod_name']['ko']
    kJndetKVMsoFRWYSyrPxcpCBGaTjwO =''
    try:
     kJndetKVMsoFRWYSyrPxcpCBGaTjvb=kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjmL[kJndetKVMsoFRWYSyrPxcpCBGaTjwv]['episode']['broadcast_date'])
     kJndetKVMsoFRWYSyrPxcpCBGaTjwO='%s-%s-%s'%(kJndetKVMsoFRWYSyrPxcpCBGaTjvb[:4],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[4:6],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[6:])
    except:
     kJndetKVMsoFRWYSyrPxcpCBGaTjOu
    try:
     if kJndetKVMsoFRWYSyrPxcpCBGaTjmL[kJndetKVMsoFRWYSyrPxcpCBGaTjwv]['episode']['pip_cliptype']=='C012':
      kJndetKVMsoFRWYSyrPxcpCBGaTjwO+=' - Quick VOD'
    except:
     kJndetKVMsoFRWYSyrPxcpCBGaTjOu
    kJndetKVMsoFRWYSyrPxcpCBGaTjmg =kJndetKVMsoFRWYSyrPxcpCBGaTjmL[kJndetKVMsoFRWYSyrPxcpCBGaTjwv]['episode']['synopsis']['ko']
    kJndetKVMsoFRWYSyrPxcpCBGaTjvE =''
    kJndetKVMsoFRWYSyrPxcpCBGaTjmq =''
    kJndetKVMsoFRWYSyrPxcpCBGaTjvi=''
    kJndetKVMsoFRWYSyrPxcpCBGaTjvu =''
    kJndetKVMsoFRWYSyrPxcpCBGaTjvQ =''
    kJndetKVMsoFRWYSyrPxcpCBGaTjvm =''
    for kJndetKVMsoFRWYSyrPxcpCBGaTjvw in kJndetKVMsoFRWYSyrPxcpCBGaTjmL[kJndetKVMsoFRWYSyrPxcpCBGaTjwv]['program']['image']:
     if kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP0900':kJndetKVMsoFRWYSyrPxcpCBGaTjvE =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP1800':kJndetKVMsoFRWYSyrPxcpCBGaTjvi=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP2000':kJndetKVMsoFRWYSyrPxcpCBGaTjvu =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP1900':kJndetKVMsoFRWYSyrPxcpCBGaTjvQ =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIP0200':kJndetKVMsoFRWYSyrPxcpCBGaTjvm =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
    for kJndetKVMsoFRWYSyrPxcpCBGaTjvw in kJndetKVMsoFRWYSyrPxcpCBGaTjmL[kJndetKVMsoFRWYSyrPxcpCBGaTjwv]['episode']['image']:
     if kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIE0400':kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
    try:
     kJndetKVMsoFRWYSyrPxcpCBGaTjwz=kJndetKVMsoFRWYSyrPxcpCBGaTjwH=kJndetKVMsoFRWYSyrPxcpCBGaTjwN=''
     kJndetKVMsoFRWYSyrPxcpCBGaTjwD=0
     kJndetKVMsoFRWYSyrPxcpCBGaTjwz =kJndetKVMsoFRWYSyrPxcpCBGaTjmL[kJndetKVMsoFRWYSyrPxcpCBGaTjwv]['program']['name']['ko']
     kJndetKVMsoFRWYSyrPxcpCBGaTjwH =kJndetKVMsoFRWYSyrPxcpCBGaTjwO
     kJndetKVMsoFRWYSyrPxcpCBGaTjwN =kJndetKVMsoFRWYSyrPxcpCBGaTjmL[kJndetKVMsoFRWYSyrPxcpCBGaTjwv]['channel']['name']['ko']
     if 'frequency' in kJndetKVMsoFRWYSyrPxcpCBGaTjmL[kJndetKVMsoFRWYSyrPxcpCBGaTjwv]['episode']:kJndetKVMsoFRWYSyrPxcpCBGaTjwD=kJndetKVMsoFRWYSyrPxcpCBGaTjmL[kJndetKVMsoFRWYSyrPxcpCBGaTjwv]['episode']['frequency']
    except:
     kJndetKVMsoFRWYSyrPxcpCBGaTjOu
    kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'episode':kJndetKVMsoFRWYSyrPxcpCBGaTjwh,'title':kJndetKVMsoFRWYSyrPxcpCBGaTjmX,'subtitle':kJndetKVMsoFRWYSyrPxcpCBGaTjwO,'thumbnail':{'poster':kJndetKVMsoFRWYSyrPxcpCBGaTjvE,'thumb':kJndetKVMsoFRWYSyrPxcpCBGaTjmq,'clearlogo':kJndetKVMsoFRWYSyrPxcpCBGaTjvi,'icon':kJndetKVMsoFRWYSyrPxcpCBGaTjvu,'banner':kJndetKVMsoFRWYSyrPxcpCBGaTjvQ,'fanart':kJndetKVMsoFRWYSyrPxcpCBGaTjvm},'synopsis':kJndetKVMsoFRWYSyrPxcpCBGaTjmg,'info_title':kJndetKVMsoFRWYSyrPxcpCBGaTjwz,'aired':kJndetKVMsoFRWYSyrPxcpCBGaTjwH,'studio':kJndetKVMsoFRWYSyrPxcpCBGaTjwN,'frequency':kJndetKVMsoFRWYSyrPxcpCBGaTjwD}
    kJndetKVMsoFRWYSyrPxcpCBGaTjuN.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
   if kJndetKVMsoFRWYSyrPxcpCBGaTjwQ>page_int:kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOw
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf,kJndetKVMsoFRWYSyrPxcpCBGaTjwQ
 def GetMovieList(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,genre,orderby,page_int):
  kJndetKVMsoFRWYSyrPxcpCBGaTjuN=[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v2/media/movies'
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'pageSize':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:kJndetKVMsoFRWYSyrPxcpCBGaTjub['categoryCode']=genre
   kJndetKVMsoFRWYSyrPxcpCBGaTjub['productPackageCode']=','.join(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.MOVIE_LITE)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if not('result' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']):return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
   kJndetKVMsoFRWYSyrPxcpCBGaTjmL=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']
   for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjmL:
    if 'release_date' in kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('movie'):
     kJndetKVMsoFRWYSyrPxcpCBGaTjvD=kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('movie').get('release_date'))[:4]
    else:
     kJndetKVMsoFRWYSyrPxcpCBGaTjvD=kJndetKVMsoFRWYSyrPxcpCBGaTjOu
    kJndetKVMsoFRWYSyrPxcpCBGaTjwI =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['movie']['code']
    kJndetKVMsoFRWYSyrPxcpCBGaTjmX =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['movie']['name']['ko'].strip()
    if kJndetKVMsoFRWYSyrPxcpCBGaTjvD not in[kJndetKVMsoFRWYSyrPxcpCBGaTjOu,'0','']:kJndetKVMsoFRWYSyrPxcpCBGaTjmX+=u' (%s)'%(kJndetKVMsoFRWYSyrPxcpCBGaTjvD)
    kJndetKVMsoFRWYSyrPxcpCBGaTjvE=''
    kJndetKVMsoFRWYSyrPxcpCBGaTjmq =''
    kJndetKVMsoFRWYSyrPxcpCBGaTjvi=''
    for kJndetKVMsoFRWYSyrPxcpCBGaTjvw in kJndetKVMsoFRWYSyrPxcpCBGaTjuU['movie']['image']:
     if kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIM2100':kJndetKVMsoFRWYSyrPxcpCBGaTjvE =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIM0400':kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIM1800':kJndetKVMsoFRWYSyrPxcpCBGaTjvi=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
    kJndetKVMsoFRWYSyrPxcpCBGaTjmg =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['movie']['story']['ko']
    try:
     kJndetKVMsoFRWYSyrPxcpCBGaTjwz =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['movie']['name']['ko'].strip()
     kJndetKVMsoFRWYSyrPxcpCBGaTjvH =kJndetKVMsoFRWYSyrPxcpCBGaTjEQ.get(kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('grade_code'))
     kJndetKVMsoFRWYSyrPxcpCBGaTjvh=[]
     kJndetKVMsoFRWYSyrPxcpCBGaTjvO=[]
     kJndetKVMsoFRWYSyrPxcpCBGaTjvz=[]
     kJndetKVMsoFRWYSyrPxcpCBGaTjwf=0
     kJndetKVMsoFRWYSyrPxcpCBGaTjvN=''
     kJndetKVMsoFRWYSyrPxcpCBGaTjwN =''
     for kJndetKVMsoFRWYSyrPxcpCBGaTjvI in kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('movie').get('actor'):
      if kJndetKVMsoFRWYSyrPxcpCBGaTjvI!='':kJndetKVMsoFRWYSyrPxcpCBGaTjvh.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvI)
     for kJndetKVMsoFRWYSyrPxcpCBGaTjvf in kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('movie').get('director'):
      if kJndetKVMsoFRWYSyrPxcpCBGaTjvf!='':kJndetKVMsoFRWYSyrPxcpCBGaTjvO.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvf)
     if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('movie').get('category1_name').get('ko')!='':
      kJndetKVMsoFRWYSyrPxcpCBGaTjvz.append(kJndetKVMsoFRWYSyrPxcpCBGaTjuU['movie']['category1_name']['ko'])
     if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('movie').get('category2_name').get('ko')!='':
      kJndetKVMsoFRWYSyrPxcpCBGaTjvz.append(kJndetKVMsoFRWYSyrPxcpCBGaTjuU['movie']['category2_name']['ko'])
     if 'duration' in kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('movie'):kJndetKVMsoFRWYSyrPxcpCBGaTjwf=kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('movie').get('duration')
     if 'release_date' in kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('movie'):
      kJndetKVMsoFRWYSyrPxcpCBGaTjvb=kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('movie').get('release_date'))
      if kJndetKVMsoFRWYSyrPxcpCBGaTjvb!='0':kJndetKVMsoFRWYSyrPxcpCBGaTjvN='%s-%s-%s'%(kJndetKVMsoFRWYSyrPxcpCBGaTjvb[:4],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[4:6],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[6:])
     if 'production' in kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('movie'):kJndetKVMsoFRWYSyrPxcpCBGaTjwN=kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('movie').get('production')
    except:
     kJndetKVMsoFRWYSyrPxcpCBGaTjOu
    kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'moviecode':kJndetKVMsoFRWYSyrPxcpCBGaTjwI,'title':kJndetKVMsoFRWYSyrPxcpCBGaTjmX,'thumbnail':{'poster':kJndetKVMsoFRWYSyrPxcpCBGaTjvE,'thumb':kJndetKVMsoFRWYSyrPxcpCBGaTjmq,'clearlogo':kJndetKVMsoFRWYSyrPxcpCBGaTjvi,'fanart':kJndetKVMsoFRWYSyrPxcpCBGaTjmq},'synopsis':kJndetKVMsoFRWYSyrPxcpCBGaTjmg,'info_title':kJndetKVMsoFRWYSyrPxcpCBGaTjwz,'year':kJndetKVMsoFRWYSyrPxcpCBGaTjvD,'cast':kJndetKVMsoFRWYSyrPxcpCBGaTjvh,'director':kJndetKVMsoFRWYSyrPxcpCBGaTjvO,'info_genre':kJndetKVMsoFRWYSyrPxcpCBGaTjvz,'duration':kJndetKVMsoFRWYSyrPxcpCBGaTjwf,'premiered':kJndetKVMsoFRWYSyrPxcpCBGaTjvN,'studio':kJndetKVMsoFRWYSyrPxcpCBGaTjwN,'mpaa':kJndetKVMsoFRWYSyrPxcpCBGaTjvH}
    kJndetKVMsoFRWYSyrPxcpCBGaTjwb=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
    for kJndetKVMsoFRWYSyrPxcpCBGaTjwL in kJndetKVMsoFRWYSyrPxcpCBGaTjuU['billing_package_id']:
     if kJndetKVMsoFRWYSyrPxcpCBGaTjwL in kJndetKVMsoFRWYSyrPxcpCBGaTjEw.MOVIE_LITE:
      kJndetKVMsoFRWYSyrPxcpCBGaTjwb=kJndetKVMsoFRWYSyrPxcpCBGaTjOw
      break
    if kJndetKVMsoFRWYSyrPxcpCBGaTjwb==kJndetKVMsoFRWYSyrPxcpCBGaTjOQ: 
     kJndetKVMsoFRWYSyrPxcpCBGaTjvU['title']=kJndetKVMsoFRWYSyrPxcpCBGaTjvU['title']+' [개별구매]'
    kJndetKVMsoFRWYSyrPxcpCBGaTjuN.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
   if kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['has_more']=='Y':kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOw
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
 def Get_UHD_MovieList(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,page_int):
  kJndetKVMsoFRWYSyrPxcpCBGaTjuN=[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v2/operator/highlights'
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams(uhd=kJndetKVMsoFRWYSyrPxcpCBGaTjOw)
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(page_int),'pocType':'APP_X_TVING_4.0.0',}
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if not('result' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']):return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
   kJndetKVMsoFRWYSyrPxcpCBGaTjmL=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']
   for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjmL:
    kJndetKVMsoFRWYSyrPxcpCBGaTjvX=kJndetKVMsoFRWYSyrPxcpCBGaTjuU['content']['movie']
    kJndetKVMsoFRWYSyrPxcpCBGaTjvg =kJndetKVMsoFRWYSyrPxcpCBGaTjvX['code']
    kJndetKVMsoFRWYSyrPxcpCBGaTjmX =kJndetKVMsoFRWYSyrPxcpCBGaTjvX['name']['ko'].strip()
    kJndetKVMsoFRWYSyrPxcpCBGaTjwz =kJndetKVMsoFRWYSyrPxcpCBGaTjvX['name']['ko'].strip()
    kJndetKVMsoFRWYSyrPxcpCBGaTjvD =kJndetKVMsoFRWYSyrPxcpCBGaTjvX['product_year']
    if kJndetKVMsoFRWYSyrPxcpCBGaTjvD:kJndetKVMsoFRWYSyrPxcpCBGaTjmX+=u' (%s)'%(kJndetKVMsoFRWYSyrPxcpCBGaTjvX['product_year'])
    kJndetKVMsoFRWYSyrPxcpCBGaTjmg =kJndetKVMsoFRWYSyrPxcpCBGaTjvX['story']['ko']
    kJndetKVMsoFRWYSyrPxcpCBGaTjwf =kJndetKVMsoFRWYSyrPxcpCBGaTjvX['duration']
    kJndetKVMsoFRWYSyrPxcpCBGaTjvH =kJndetKVMsoFRWYSyrPxcpCBGaTjEQ.get(kJndetKVMsoFRWYSyrPxcpCBGaTjvX.get('grade_code'))
    kJndetKVMsoFRWYSyrPxcpCBGaTjwN =kJndetKVMsoFRWYSyrPxcpCBGaTjvX['production']
    kJndetKVMsoFRWYSyrPxcpCBGaTjvE=''
    kJndetKVMsoFRWYSyrPxcpCBGaTjmq =''
    kJndetKVMsoFRWYSyrPxcpCBGaTjvi=''
    kJndetKVMsoFRWYSyrPxcpCBGaTjvz =[]
    kJndetKVMsoFRWYSyrPxcpCBGaTjvh =[]
    kJndetKVMsoFRWYSyrPxcpCBGaTjvO=[]
    kJndetKVMsoFRWYSyrPxcpCBGaTjvN =''
    for kJndetKVMsoFRWYSyrPxcpCBGaTjvw in kJndetKVMsoFRWYSyrPxcpCBGaTjvX['image']:
     if kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIM2100':kJndetKVMsoFRWYSyrPxcpCBGaTjvE =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIM0400':kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
     elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw['code']=='CAIM1800':kJndetKVMsoFRWYSyrPxcpCBGaTjvi=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw['url']
    if kJndetKVMsoFRWYSyrPxcpCBGaTjvX['release_date']not in[kJndetKVMsoFRWYSyrPxcpCBGaTjOu,0]:
     kJndetKVMsoFRWYSyrPxcpCBGaTjvb=kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjvX['release_date'])
     if kJndetKVMsoFRWYSyrPxcpCBGaTjvb!='0':kJndetKVMsoFRWYSyrPxcpCBGaTjvN='%s-%s-%s'%(kJndetKVMsoFRWYSyrPxcpCBGaTjvb[:4],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[4:6],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[6:])
    if kJndetKVMsoFRWYSyrPxcpCBGaTjvX.get('category1_name').get('ko')!='':
     kJndetKVMsoFRWYSyrPxcpCBGaTjvz.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvX['category1_name']['ko'])
    if kJndetKVMsoFRWYSyrPxcpCBGaTjvX.get('category2_name').get('ko')!='':
     kJndetKVMsoFRWYSyrPxcpCBGaTjvz.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvX['category2_name']['ko'])
    for kJndetKVMsoFRWYSyrPxcpCBGaTjvI in kJndetKVMsoFRWYSyrPxcpCBGaTjvX.get('actor'):
     if kJndetKVMsoFRWYSyrPxcpCBGaTjvI!='':kJndetKVMsoFRWYSyrPxcpCBGaTjvh.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvI)
    for kJndetKVMsoFRWYSyrPxcpCBGaTjvf in kJndetKVMsoFRWYSyrPxcpCBGaTjvX.get('director'):
     if kJndetKVMsoFRWYSyrPxcpCBGaTjvf!='':kJndetKVMsoFRWYSyrPxcpCBGaTjvO.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvf)
    kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'moviecode':kJndetKVMsoFRWYSyrPxcpCBGaTjvg,'title':kJndetKVMsoFRWYSyrPxcpCBGaTjmX,'thumbnail':{'poster':kJndetKVMsoFRWYSyrPxcpCBGaTjvE,'thumb':kJndetKVMsoFRWYSyrPxcpCBGaTjmq,'clearlogo':kJndetKVMsoFRWYSyrPxcpCBGaTjvi,'fanart':kJndetKVMsoFRWYSyrPxcpCBGaTjmq},'year':kJndetKVMsoFRWYSyrPxcpCBGaTjvD,'info_title':kJndetKVMsoFRWYSyrPxcpCBGaTjwz,'synopsis':kJndetKVMsoFRWYSyrPxcpCBGaTjmg,'mpaa':kJndetKVMsoFRWYSyrPxcpCBGaTjvH,'duration':kJndetKVMsoFRWYSyrPxcpCBGaTjwf,'premiered':kJndetKVMsoFRWYSyrPxcpCBGaTjvN,'studio':kJndetKVMsoFRWYSyrPxcpCBGaTjwN,'info_genre':kJndetKVMsoFRWYSyrPxcpCBGaTjvz,'cast':kJndetKVMsoFRWYSyrPxcpCBGaTjvh,'director':kJndetKVMsoFRWYSyrPxcpCBGaTjvO,}
    kJndetKVMsoFRWYSyrPxcpCBGaTjuN.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
 def GetMovieGenre(kJndetKVMsoFRWYSyrPxcpCBGaTjEw):
  kJndetKVMsoFRWYSyrPxcpCBGaTjuN=[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v2/media/movie/curations'
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if not('result' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']):return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
   kJndetKVMsoFRWYSyrPxcpCBGaTjmL=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']
   for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjmL:
    kJndetKVMsoFRWYSyrPxcpCBGaTjwU =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['curation_code']
    kJndetKVMsoFRWYSyrPxcpCBGaTjwA =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['curation_name']
    kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'curation_code':kJndetKVMsoFRWYSyrPxcpCBGaTjwU,'curation_name':kJndetKVMsoFRWYSyrPxcpCBGaTjwA}
    kJndetKVMsoFRWYSyrPxcpCBGaTjuN.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
 def GetSearchList(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,search_key,page_int,stype):
  kJndetKVMsoFRWYSyrPxcpCBGaTjwl=[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOQ
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/search/getSearch.jsp'
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.SCREENCODE,'os':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.OSCODE,'network':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.APIKEY,'networkCode':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.NETWORKCODE,'osCode ':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.OSCODE,'teleCode ':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TELECODE,'screenCode ':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.SCREENCODE}
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.SEARCH_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjub,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if stype=='vod':
    if not('programRsb' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL):return kJndetKVMsoFRWYSyrPxcpCBGaTjwl,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
    kJndetKVMsoFRWYSyrPxcpCBGaTjwX=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['programRsb']['dataList']
    kJndetKVMsoFRWYSyrPxcpCBGaTjwg =kJndetKVMsoFRWYSyrPxcpCBGaTjOz(kJndetKVMsoFRWYSyrPxcpCBGaTjuL['programRsb']['count'])
    for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjwX:
     kJndetKVMsoFRWYSyrPxcpCBGaTjvA=kJndetKVMsoFRWYSyrPxcpCBGaTjuU['mast_cd']
     kJndetKVMsoFRWYSyrPxcpCBGaTjmX =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['mast_nm']
     kJndetKVMsoFRWYSyrPxcpCBGaTjvE=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuU['web_url4']
     kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuU['web_url']
     try:
      kJndetKVMsoFRWYSyrPxcpCBGaTjvh =[]
      kJndetKVMsoFRWYSyrPxcpCBGaTjvO=[]
      kJndetKVMsoFRWYSyrPxcpCBGaTjvz =[]
      kJndetKVMsoFRWYSyrPxcpCBGaTjwf =0
      kJndetKVMsoFRWYSyrPxcpCBGaTjvH =''
      kJndetKVMsoFRWYSyrPxcpCBGaTjvD =''
      kJndetKVMsoFRWYSyrPxcpCBGaTjwH =''
      if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('actor') !='' and kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('actor') !='-':kJndetKVMsoFRWYSyrPxcpCBGaTjvh =kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('actor').split(',')
      if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('director')!='' and kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('director')!='-':kJndetKVMsoFRWYSyrPxcpCBGaTjvO=kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('director').split(',')
      if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('cate_nm')!='' and kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('cate_nm')!='-':kJndetKVMsoFRWYSyrPxcpCBGaTjvz =kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('cate_nm').split('/')
      if 'targetage' in kJndetKVMsoFRWYSyrPxcpCBGaTjuU:kJndetKVMsoFRWYSyrPxcpCBGaTjvH=kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('targetage')
      if 'broad_dt' in kJndetKVMsoFRWYSyrPxcpCBGaTjuU:
       kJndetKVMsoFRWYSyrPxcpCBGaTjvb=kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('broad_dt')
       kJndetKVMsoFRWYSyrPxcpCBGaTjwH='%s-%s-%s'%(kJndetKVMsoFRWYSyrPxcpCBGaTjvb[:4],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[4:6],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[6:])
       kJndetKVMsoFRWYSyrPxcpCBGaTjvD =kJndetKVMsoFRWYSyrPxcpCBGaTjvb[:4]
     except:
      kJndetKVMsoFRWYSyrPxcpCBGaTjOu
     kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'program':kJndetKVMsoFRWYSyrPxcpCBGaTjvA,'title':kJndetKVMsoFRWYSyrPxcpCBGaTjmX,'thumbnail':{'poster':kJndetKVMsoFRWYSyrPxcpCBGaTjvE,'thumb':kJndetKVMsoFRWYSyrPxcpCBGaTjmq,'fanart':kJndetKVMsoFRWYSyrPxcpCBGaTjmq},'synopsis':'','cast':kJndetKVMsoFRWYSyrPxcpCBGaTjvh,'director':kJndetKVMsoFRWYSyrPxcpCBGaTjvO,'info_genre':kJndetKVMsoFRWYSyrPxcpCBGaTjvz,'duration':kJndetKVMsoFRWYSyrPxcpCBGaTjwf,'mpaa':kJndetKVMsoFRWYSyrPxcpCBGaTjvH,'year':kJndetKVMsoFRWYSyrPxcpCBGaTjvD,'aired':kJndetKVMsoFRWYSyrPxcpCBGaTjwH}
     kJndetKVMsoFRWYSyrPxcpCBGaTjwl.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
   else:
    if not('vodMVRsb' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL):return kJndetKVMsoFRWYSyrPxcpCBGaTjwl,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
    kJndetKVMsoFRWYSyrPxcpCBGaTjwq=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['vodMVRsb']['dataList']
    kJndetKVMsoFRWYSyrPxcpCBGaTjwg =kJndetKVMsoFRWYSyrPxcpCBGaTjOz(kJndetKVMsoFRWYSyrPxcpCBGaTjuL['vodMVRsb']['count'])
    for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjwq:
     kJndetKVMsoFRWYSyrPxcpCBGaTjvA=kJndetKVMsoFRWYSyrPxcpCBGaTjuU['mast_cd']
     kJndetKVMsoFRWYSyrPxcpCBGaTjmX =kJndetKVMsoFRWYSyrPxcpCBGaTjuU['mast_nm'].strip()
     kJndetKVMsoFRWYSyrPxcpCBGaTjvE =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuU['web_url']
     kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjvE
     kJndetKVMsoFRWYSyrPxcpCBGaTjvi=''
     try:
      kJndetKVMsoFRWYSyrPxcpCBGaTjvh =[]
      kJndetKVMsoFRWYSyrPxcpCBGaTjvO=[]
      kJndetKVMsoFRWYSyrPxcpCBGaTjvz =[]
      kJndetKVMsoFRWYSyrPxcpCBGaTjwf =0
      kJndetKVMsoFRWYSyrPxcpCBGaTjvH =''
      kJndetKVMsoFRWYSyrPxcpCBGaTjvD =''
      kJndetKVMsoFRWYSyrPxcpCBGaTjwH =''
      if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('actor') !='' and kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('actor') !='-':kJndetKVMsoFRWYSyrPxcpCBGaTjvh =kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('actor').split(',')
      if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('director')!='' and kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('director')!='-':kJndetKVMsoFRWYSyrPxcpCBGaTjvO=kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('director').split(',')
      if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('cate_nm')!='' and kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('cate_nm')!='-':kJndetKVMsoFRWYSyrPxcpCBGaTjvz =kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('cate_nm').split('/')
      if kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('runtime_sec')!='':kJndetKVMsoFRWYSyrPxcpCBGaTjwf=kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('runtime_sec')
      if 'grade_nm' in kJndetKVMsoFRWYSyrPxcpCBGaTjuU:kJndetKVMsoFRWYSyrPxcpCBGaTjvH=kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('grade_nm')
      kJndetKVMsoFRWYSyrPxcpCBGaTjvb=kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('broad_dt')
      if data_str!='':
       kJndetKVMsoFRWYSyrPxcpCBGaTjwH='%s-%s-%s'%(kJndetKVMsoFRWYSyrPxcpCBGaTjvb[:4],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[4:6],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[6:])
       kJndetKVMsoFRWYSyrPxcpCBGaTjvD =kJndetKVMsoFRWYSyrPxcpCBGaTjvb[:4]
     except:
      kJndetKVMsoFRWYSyrPxcpCBGaTjOu
     kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'movie':kJndetKVMsoFRWYSyrPxcpCBGaTjvA,'title':kJndetKVMsoFRWYSyrPxcpCBGaTjmX,'thumbnail':{'poster':kJndetKVMsoFRWYSyrPxcpCBGaTjvE,'thumb':kJndetKVMsoFRWYSyrPxcpCBGaTjmq,'fanart':kJndetKVMsoFRWYSyrPxcpCBGaTjmq,'clearlogo':kJndetKVMsoFRWYSyrPxcpCBGaTjvi},'synopsis':'','cast':kJndetKVMsoFRWYSyrPxcpCBGaTjvh,'director':kJndetKVMsoFRWYSyrPxcpCBGaTjvO,'info_genre':kJndetKVMsoFRWYSyrPxcpCBGaTjvz,'duration':kJndetKVMsoFRWYSyrPxcpCBGaTjwf,'mpaa':kJndetKVMsoFRWYSyrPxcpCBGaTjvH,'year':kJndetKVMsoFRWYSyrPxcpCBGaTjvD,'aired':kJndetKVMsoFRWYSyrPxcpCBGaTjwH}
     kJndetKVMsoFRWYSyrPxcpCBGaTjwl.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
   if kJndetKVMsoFRWYSyrPxcpCBGaTjwg>(page_int*kJndetKVMsoFRWYSyrPxcpCBGaTjEw.SEARCH_LIMIT):kJndetKVMsoFRWYSyrPxcpCBGaTjmf=kJndetKVMsoFRWYSyrPxcpCBGaTjOw
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjwl,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
 def GetBookmarkInfo(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,videoid,vidtype):
  kJndetKVMsoFRWYSyrPxcpCBGaTjhE={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+'/v2/media/program/'+videoid
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'pageNo':'1','pageSize':'10','order':'name',}
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjvq=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if not('body' in kJndetKVMsoFRWYSyrPxcpCBGaTjvq):return{}
   kJndetKVMsoFRWYSyrPxcpCBGaTjhi=kJndetKVMsoFRWYSyrPxcpCBGaTjvq['body']
   kJndetKVMsoFRWYSyrPxcpCBGaTjmX=kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('name').get('ko').strip()
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['title'] =kJndetKVMsoFRWYSyrPxcpCBGaTjmX
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['title']=kJndetKVMsoFRWYSyrPxcpCBGaTjmX
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['mpaa'] =kJndetKVMsoFRWYSyrPxcpCBGaTjEQ.get(kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('grade_code'))
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['plot'] =kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('synopsis').get('ko')
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['year'] =kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('product_year')
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['cast'] =kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('actor')
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['director']=kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('director')
   if kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('category1_name').get('ko')!='':
    kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['genre'].append(kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('category1_name').get('ko'))
   if kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('category2_name').get('ko')!='':
    kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['genre'].append(kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('category2_name').get('ko'))
   kJndetKVMsoFRWYSyrPxcpCBGaTjvb=kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('broad_dt'))
   if kJndetKVMsoFRWYSyrPxcpCBGaTjvb!='0':kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(kJndetKVMsoFRWYSyrPxcpCBGaTjvb[:4],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[4:6],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[6:])
   kJndetKVMsoFRWYSyrPxcpCBGaTjvE =''
   kJndetKVMsoFRWYSyrPxcpCBGaTjmq =''
   kJndetKVMsoFRWYSyrPxcpCBGaTjvi=''
   kJndetKVMsoFRWYSyrPxcpCBGaTjvu =''
   kJndetKVMsoFRWYSyrPxcpCBGaTjvQ =''
   for kJndetKVMsoFRWYSyrPxcpCBGaTjvw in kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('image'):
    if kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('code')=='CAIP0900':kJndetKVMsoFRWYSyrPxcpCBGaTjvE =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('url')
    elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('code')=='CAIP0200':kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('url')
    elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('code')=='CAIP1800':kJndetKVMsoFRWYSyrPxcpCBGaTjvi=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('url')
    elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('code')=='CAIP2000':kJndetKVMsoFRWYSyrPxcpCBGaTjvu =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('url')
    elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('code')=='CAIP1900':kJndetKVMsoFRWYSyrPxcpCBGaTjvQ =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('url')
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['thumbnail']['poster']=kJndetKVMsoFRWYSyrPxcpCBGaTjvE
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['thumbnail']['thumb']=kJndetKVMsoFRWYSyrPxcpCBGaTjmq
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['thumbnail']['clearlogo']=kJndetKVMsoFRWYSyrPxcpCBGaTjvi
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['thumbnail']['icon']=kJndetKVMsoFRWYSyrPxcpCBGaTjvu
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['thumbnail']['banner']=kJndetKVMsoFRWYSyrPxcpCBGaTjvQ
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['thumbnail']['fanart']=kJndetKVMsoFRWYSyrPxcpCBGaTjmq
  else:
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+'/v2a/media/stream/info'
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies']['tving_uuid'].split('-')[0],'uuid':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetNoCache(1)),'wm':'Y',}
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjvq=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if not('content' in kJndetKVMsoFRWYSyrPxcpCBGaTjvq['body']):return{}
   kJndetKVMsoFRWYSyrPxcpCBGaTjhi=kJndetKVMsoFRWYSyrPxcpCBGaTjvq['body']['content']['info']['movie']
   kJndetKVMsoFRWYSyrPxcpCBGaTjmX =kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('name').get('ko').strip()
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['title']=kJndetKVMsoFRWYSyrPxcpCBGaTjmX
   kJndetKVMsoFRWYSyrPxcpCBGaTjmX +=u' (%s)'%(kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('product_year'))
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['title'] =kJndetKVMsoFRWYSyrPxcpCBGaTjmX
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['mpaa'] =kJndetKVMsoFRWYSyrPxcpCBGaTjEQ.get(kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('grade_code'))
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['plot'] =kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('story').get('ko')
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['year'] =kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('product_year')
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['studio'] =kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('production')
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['duration']=kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('duration')
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['cast'] =kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('actor')
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['director']=kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('director')
   if kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('category1_name').get('ko')!='':
    kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['genre'].append(kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('category1_name').get('ko'))
   if kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('category2_name').get('ko')!='':
    kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['genre'].append(kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('category2_name').get('ko'))
   kJndetKVMsoFRWYSyrPxcpCBGaTjvb=kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('release_date'))
   if kJndetKVMsoFRWYSyrPxcpCBGaTjvb!='0':kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(kJndetKVMsoFRWYSyrPxcpCBGaTjvb[:4],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[4:6],kJndetKVMsoFRWYSyrPxcpCBGaTjvb[6:])
   kJndetKVMsoFRWYSyrPxcpCBGaTjvE=''
   kJndetKVMsoFRWYSyrPxcpCBGaTjmq =''
   kJndetKVMsoFRWYSyrPxcpCBGaTjvi=''
   for kJndetKVMsoFRWYSyrPxcpCBGaTjvw in kJndetKVMsoFRWYSyrPxcpCBGaTjhi.get('image'):
    if kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('code')=='CAIM2100':kJndetKVMsoFRWYSyrPxcpCBGaTjvE =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('url')
    elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('code')=='CAIM0400':kJndetKVMsoFRWYSyrPxcpCBGaTjmq =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('url')
    elif kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('code')=='CAIM1800':kJndetKVMsoFRWYSyrPxcpCBGaTjvi=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.IMG_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjvw.get('url')
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['thumbnail']['poster']=kJndetKVMsoFRWYSyrPxcpCBGaTjvE
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['thumbnail']['thumb']=kJndetKVMsoFRWYSyrPxcpCBGaTjvE 
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['thumbnail']['clearlogo']=kJndetKVMsoFRWYSyrPxcpCBGaTjvi
   kJndetKVMsoFRWYSyrPxcpCBGaTjhE['saveinfo']['thumbnail']['fanart']=kJndetKVMsoFRWYSyrPxcpCBGaTjmq
  return kJndetKVMsoFRWYSyrPxcpCBGaTjhE
 def GetEuroChannelList(kJndetKVMsoFRWYSyrPxcpCBGaTjEw):
  kJndetKVMsoFRWYSyrPxcpCBGaTjuN=[]
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v2/operator/highlights'
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetNoCache(2))}
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if not('result' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']):return kJndetKVMsoFRWYSyrPxcpCBGaTjuN,kJndetKVMsoFRWYSyrPxcpCBGaTjmf
   kJndetKVMsoFRWYSyrPxcpCBGaTjmL=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']
   kJndetKVMsoFRWYSyrPxcpCBGaTjhu =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Get_Now_Datetime()
   kJndetKVMsoFRWYSyrPxcpCBGaTjhQ=kJndetKVMsoFRWYSyrPxcpCBGaTjhu+datetime.timedelta(days=-1)
   kJndetKVMsoFRWYSyrPxcpCBGaTjhQ=kJndetKVMsoFRWYSyrPxcpCBGaTjOz(kJndetKVMsoFRWYSyrPxcpCBGaTjhQ.strftime('%Y%m%d'))
   for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjmL:
    kJndetKVMsoFRWYSyrPxcpCBGaTjhm=kJndetKVMsoFRWYSyrPxcpCBGaTjOz(kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('content').get('banner_title2')[:8])
    if kJndetKVMsoFRWYSyrPxcpCBGaTjhQ<=kJndetKVMsoFRWYSyrPxcpCBGaTjhm:
     kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'channel':kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('content').get('banner_sub_title3'),'title':kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('content').get('banner_title'),'subtitle':kJndetKVMsoFRWYSyrPxcpCBGaTjuU.get('content').get('banner_sub_title2'),}
     kJndetKVMsoFRWYSyrPxcpCBGaTjuN.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjuN
 def Make_DecryptKey(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,step,mediacode='000',timecode='000'):
  if step=='1':
   kJndetKVMsoFRWYSyrPxcpCBGaTjiz=kJndetKVMsoFRWYSyrPxcpCBGaTjOH('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   kJndetKVMsoFRWYSyrPxcpCBGaTjiD=kJndetKVMsoFRWYSyrPxcpCBGaTjOH('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   kJndetKVMsoFRWYSyrPxcpCBGaTjiz=kJndetKVMsoFRWYSyrPxcpCBGaTjOH('kss2lym0kdw1lks3','utf-8')
   kJndetKVMsoFRWYSyrPxcpCBGaTjiD=kJndetKVMsoFRWYSyrPxcpCBGaTjOH([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return kJndetKVMsoFRWYSyrPxcpCBGaTjiz,kJndetKVMsoFRWYSyrPxcpCBGaTjiD
 def DecryptPlaintext(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,kJndetKVMsoFRWYSyrPxcpCBGaTjif,kJndetKVMsoFRWYSyrPxcpCBGaTjiH,kJndetKVMsoFRWYSyrPxcpCBGaTjiN):
  kJndetKVMsoFRWYSyrPxcpCBGaTjiI=AES.new(kJndetKVMsoFRWYSyrPxcpCBGaTjiH,AES.MODE_CBC,kJndetKVMsoFRWYSyrPxcpCBGaTjiN,)
  kJndetKVMsoFRWYSyrPxcpCBGaTjib=Padding.unpad(kJndetKVMsoFRWYSyrPxcpCBGaTjiI.decrypt(base64.standard_b64decode(kJndetKVMsoFRWYSyrPxcpCBGaTjif)),16)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjib.decode('utf-8')
 def Decrypt_Url(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,kJndetKVMsoFRWYSyrPxcpCBGaTjif,mediacode,kJndetKVMsoFRWYSyrPxcpCBGaTjQw):
  kJndetKVMsoFRWYSyrPxcpCBGaTjhv=''
  kJndetKVMsoFRWYSyrPxcpCBGaTjQh=''
  kJndetKVMsoFRWYSyrPxcpCBGaTjQO=''
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjiz,kJndetKVMsoFRWYSyrPxcpCBGaTjiD=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Make_DecryptKey('1',mediacode=mediacode,timecode=kJndetKVMsoFRWYSyrPxcpCBGaTjQw)
   kJndetKVMsoFRWYSyrPxcpCBGaTjhw=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.DecryptPlaintext(kJndetKVMsoFRWYSyrPxcpCBGaTjif,kJndetKVMsoFRWYSyrPxcpCBGaTjiz,kJndetKVMsoFRWYSyrPxcpCBGaTjiD))
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(kJndetKVMsoFRWYSyrPxcpCBGaTjhw)
   kJndetKVMsoFRWYSyrPxcpCBGaTjhO =kJndetKVMsoFRWYSyrPxcpCBGaTjhw.get('url')
   kJndetKVMsoFRWYSyrPxcpCBGaTjQh =kJndetKVMsoFRWYSyrPxcpCBGaTjhw.get('watermark') if 'watermark' in kJndetKVMsoFRWYSyrPxcpCBGaTjhw else ''
   kJndetKVMsoFRWYSyrPxcpCBGaTjQO=kJndetKVMsoFRWYSyrPxcpCBGaTjhw.get('watermark_key')if 'watermark_key' in kJndetKVMsoFRWYSyrPxcpCBGaTjhw else ''
   kJndetKVMsoFRWYSyrPxcpCBGaTjiz,kJndetKVMsoFRWYSyrPxcpCBGaTjiD=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Make_DecryptKey('2',mediacode=mediacode,timecode=kJndetKVMsoFRWYSyrPxcpCBGaTjQw)
   kJndetKVMsoFRWYSyrPxcpCBGaTjhv=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.DecryptPlaintext(kJndetKVMsoFRWYSyrPxcpCBGaTjhO,kJndetKVMsoFRWYSyrPxcpCBGaTjiz,kJndetKVMsoFRWYSyrPxcpCBGaTjiD)
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjhv,kJndetKVMsoFRWYSyrPxcpCBGaTjQh,kJndetKVMsoFRWYSyrPxcpCBGaTjQO
 def Get_Apple_buildId(kJndetKVMsoFRWYSyrPxcpCBGaTjEw):
  kJndetKVMsoFRWYSyrPxcpCBGaTjhz=''
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjil ='https://www.tving.com/more/special/SP0071'
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjhD=r'"buildId":"(.*?)"'
   kJndetKVMsoFRWYSyrPxcpCBGaTjhz =re.compile(kJndetKVMsoFRWYSyrPxcpCBGaTjhD,re.DOTALL).findall(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)[0]
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjhz
 def Get_AppleGroup_List(kJndetKVMsoFRWYSyrPxcpCBGaTjEw):
  kJndetKVMsoFRWYSyrPxcpCBGaTjhH=[]
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhz=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Get_Apple_buildId()
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/_next/data/{}/ko/more/special/SP0071.json'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjhz)
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'key':'SP0071'}
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.URL_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjub,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjvq=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if not('pageProps' in kJndetKVMsoFRWYSyrPxcpCBGaTjvq):return kJndetKVMsoFRWYSyrPxcpCBGaTjhH
   kJndetKVMsoFRWYSyrPxcpCBGaTjmL=kJndetKVMsoFRWYSyrPxcpCBGaTjvq['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
   for kJndetKVMsoFRWYSyrPxcpCBGaTjhN in kJndetKVMsoFRWYSyrPxcpCBGaTjmL:
    if kJndetKVMsoFRWYSyrPxcpCBGaTjhN['bandType']not in['VOD_BASIC']:continue
    kJndetKVMsoFRWYSyrPxcpCBGaTjhI =re.findall('/band/\w+|/curation/\w+',kJndetKVMsoFRWYSyrPxcpCBGaTjhN['moreUrl'])[0]
    kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'bandName':kJndetKVMsoFRWYSyrPxcpCBGaTjhN['bandName'],'bandKey':kJndetKVMsoFRWYSyrPxcpCBGaTjhI.split('/')[2],'moreUrl':kJndetKVMsoFRWYSyrPxcpCBGaTjhI,}
    kJndetKVMsoFRWYSyrPxcpCBGaTjhH.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjhH
 def Get_Band_VodList(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,bandKey,kJndetKVMsoFRWYSyrPxcpCBGaTjhI,nextApiUrl='-'):
  kJndetKVMsoFRWYSyrPxcpCBGaTjhf =[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjhb =''
  try:
   if nextApiUrl in[kJndetKVMsoFRWYSyrPxcpCBGaTjOu,'','-']:
    kJndetKVMsoFRWYSyrPxcpCBGaTjhz=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Get_Apple_buildId()
    kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/_next/data/{}/ko/more{}.json'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjhz,kJndetKVMsoFRWYSyrPxcpCBGaTjhI)
    kJndetKVMsoFRWYSyrPxcpCBGaTjub={'key':bandKey}
    kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.URL_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
    kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjub,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
    kJndetKVMsoFRWYSyrPxcpCBGaTjvq=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
    if not('pageProps' in kJndetKVMsoFRWYSyrPxcpCBGaTjvq):return kJndetKVMsoFRWYSyrPxcpCBGaTjhf,kJndetKVMsoFRWYSyrPxcpCBGaTjhb
    if 'band' in kJndetKVMsoFRWYSyrPxcpCBGaTjhI:
     kJndetKVMsoFRWYSyrPxcpCBGaTjmL=kJndetKVMsoFRWYSyrPxcpCBGaTjvq['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['band']
    else:
     kJndetKVMsoFRWYSyrPxcpCBGaTjmL=kJndetKVMsoFRWYSyrPxcpCBGaTjvq['pageProps']['dehydratedState']['queries'][0]['state']['data']['data']['bands'][0]
   else:
    kJndetKVMsoFRWYSyrPxcpCBGaTjil='{}{}{}'.format('https://gw.tving.com',nextApiUrl,'&screenCode=CSSD0100&osCode=CSOD0900')
    kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
    kJndetKVMsoFRWYSyrPxcpCBGaTjvq=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
    if not('data' in kJndetKVMsoFRWYSyrPxcpCBGaTjvq):return kJndetKVMsoFRWYSyrPxcpCBGaTjhf,kJndetKVMsoFRWYSyrPxcpCBGaTjhb
    kJndetKVMsoFRWYSyrPxcpCBGaTjmL=kJndetKVMsoFRWYSyrPxcpCBGaTjvq['data']
   for kJndetKVMsoFRWYSyrPxcpCBGaTjhN in kJndetKVMsoFRWYSyrPxcpCBGaTjmL['items']:
    kJndetKVMsoFRWYSyrPxcpCBGaTjhL=kJndetKVMsoFRWYSyrPxcpCBGaTjhN['imageUrl']
    kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'program':kJndetKVMsoFRWYSyrPxcpCBGaTjhN['code'],'title':kJndetKVMsoFRWYSyrPxcpCBGaTjhN['title'],'thumbnail':{'poster':kJndetKVMsoFRWYSyrPxcpCBGaTjhL,'thumb':kJndetKVMsoFRWYSyrPxcpCBGaTjhL,'fanart':kJndetKVMsoFRWYSyrPxcpCBGaTjhL},}
    kJndetKVMsoFRWYSyrPxcpCBGaTjhf.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
   kJndetKVMsoFRWYSyrPxcpCBGaTjhb=kJndetKVMsoFRWYSyrPxcpCBGaTjmL.get('nextApiUrl')or ''
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjhf,kJndetKVMsoFRWYSyrPxcpCBGaTjhb
 def Get_Apple_NowList(kJndetKVMsoFRWYSyrPxcpCBGaTjEw):
  kJndetKVMsoFRWYSyrPxcpCBGaTjhf =[]
  kJndetKVMsoFRWYSyrPxcpCBGaTjhb ='-'
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhz=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Get_Apple_buildId()
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/_next/data/{}/ko/more/special/SP0071.json'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjhz)
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'key':'SP0071'}
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.URL_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjub,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjOu)
   kJndetKVMsoFRWYSyrPxcpCBGaTjvq=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   kJndetKVMsoFRWYSyrPxcpCBGaTjvq=kJndetKVMsoFRWYSyrPxcpCBGaTjvq['pageProps']['dehydratedState']['queries'][0]['state']['data']['pages'][0]['data']['bands']
   for kJndetKVMsoFRWYSyrPxcpCBGaTjhU in kJndetKVMsoFRWYSyrPxcpCBGaTjvq:
    if kJndetKVMsoFRWYSyrPxcpCBGaTjhU['bandCode']=='HM192222':
     for kJndetKVMsoFRWYSyrPxcpCBGaTjhN in kJndetKVMsoFRWYSyrPxcpCBGaTjhU['items']:
      kJndetKVMsoFRWYSyrPxcpCBGaTjhL=kJndetKVMsoFRWYSyrPxcpCBGaTjhN['imageUrl']
      kJndetKVMsoFRWYSyrPxcpCBGaTjvU={'program':kJndetKVMsoFRWYSyrPxcpCBGaTjhN['code'],'title':kJndetKVMsoFRWYSyrPxcpCBGaTjhN['title'],'thumbnail':{'poster':kJndetKVMsoFRWYSyrPxcpCBGaTjhL,'thumb':kJndetKVMsoFRWYSyrPxcpCBGaTjhL,'fanart':kJndetKVMsoFRWYSyrPxcpCBGaTjhL},}
      kJndetKVMsoFRWYSyrPxcpCBGaTjhf.append(kJndetKVMsoFRWYSyrPxcpCBGaTjvU)
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
  return kJndetKVMsoFRWYSyrPxcpCBGaTjhf,kJndetKVMsoFRWYSyrPxcpCBGaTjhb
 def GetLiveURL_Test(kJndetKVMsoFRWYSyrPxcpCBGaTjEw,mediacode,sel_quality):
  kJndetKVMsoFRWYSyrPxcpCBGaTjul ={'streaming_url':'','subtitleYn':kJndetKVMsoFRWYSyrPxcpCBGaTjOQ,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  kJndetKVMsoFRWYSyrPxcpCBGaTjuI =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies']['tving_uuid'].split('-')[0] 
  kJndetKVMsoFRWYSyrPxcpCBGaTjuX =kJndetKVMsoFRWYSyrPxcpCBGaTjEw.TV['cookies']['tving_uuid'] 
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjug=kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetNoCache(1))
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v2/media/stream/info' 
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':kJndetKVMsoFRWYSyrPxcpCBGaTjuX,'deviceInfo':'PC','noCache':kJndetKVMsoFRWYSyrPxcpCBGaTjug,}
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjEq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.makeDefaultCookies()
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Get',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjEq)
   if kJndetKVMsoFRWYSyrPxcpCBGaTjig.status_code!=200:
    kJndetKVMsoFRWYSyrPxcpCBGaTjul['error_msg']='First Step - {} error'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjig.status_code)
    return kJndetKVMsoFRWYSyrPxcpCBGaTjul
   kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']['code']=='060':
    for kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjEl in kJndetKVMsoFRWYSyrPxcpCBGaTjEu.items():
     if kJndetKVMsoFRWYSyrPxcpCBGaTjEl==sel_quality:
      kJndetKVMsoFRWYSyrPxcpCBGaTjQE=kJndetKVMsoFRWYSyrPxcpCBGaTjEA
   elif kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']['code']!='000':
    kJndetKVMsoFRWYSyrPxcpCBGaTjul['error_msg']=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']['message']
    return kJndetKVMsoFRWYSyrPxcpCBGaTjul
   else: 
    if not('stream' in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']):return kJndetKVMsoFRWYSyrPxcpCBGaTjul
    kJndetKVMsoFRWYSyrPxcpCBGaTjQi=[]
    for kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjEl in kJndetKVMsoFRWYSyrPxcpCBGaTjEu.items():
     for kJndetKVMsoFRWYSyrPxcpCBGaTjuU in kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['stream']['quality']:
      if kJndetKVMsoFRWYSyrPxcpCBGaTjuU['active']=='Y' and kJndetKVMsoFRWYSyrPxcpCBGaTjuU['code']==kJndetKVMsoFRWYSyrPxcpCBGaTjEA:
       kJndetKVMsoFRWYSyrPxcpCBGaTjQi.append({kJndetKVMsoFRWYSyrPxcpCBGaTjEu.get(kJndetKVMsoFRWYSyrPxcpCBGaTjuU['code']):kJndetKVMsoFRWYSyrPxcpCBGaTjuU['code']})
    kJndetKVMsoFRWYSyrPxcpCBGaTjQE=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.CheckQuality(sel_quality,kJndetKVMsoFRWYSyrPxcpCBGaTjQi)
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
   kJndetKVMsoFRWYSyrPxcpCBGaTjul['error_msg']='First Step - except error'
   return kJndetKVMsoFRWYSyrPxcpCBGaTjul
  try:
   kJndetKVMsoFRWYSyrPxcpCBGaTjug=kJndetKVMsoFRWYSyrPxcpCBGaTjOm(kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetNoCache(1))
   kJndetKVMsoFRWYSyrPxcpCBGaTjuz ='/v3/media/stream/info'
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.GetDefaultParams()
   kJndetKVMsoFRWYSyrPxcpCBGaTjub={'mediaCode':mediacode,'deviceId':kJndetKVMsoFRWYSyrPxcpCBGaTjuI,'uuid':kJndetKVMsoFRWYSyrPxcpCBGaTjuX,'deviceInfo':'PC_Chrome','streamCode':kJndetKVMsoFRWYSyrPxcpCBGaTjQE,'noCache':kJndetKVMsoFRWYSyrPxcpCBGaTjug,'callingFrom':'HTML5','model':kJndetKVMsoFRWYSyrPxcpCBGaTjEw.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   kJndetKVMsoFRWYSyrPxcpCBGaTjuq.update(kJndetKVMsoFRWYSyrPxcpCBGaTjub)
   kJndetKVMsoFRWYSyrPxcpCBGaTjil=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.API_DOMAIN+kJndetKVMsoFRWYSyrPxcpCBGaTjuz
   kJndetKVMsoFRWYSyrPxcpCBGaTjEq=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.makeDefaultCookies()
   kJndetKVMsoFRWYSyrPxcpCBGaTjig=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.callRequestCookies('Post',kJndetKVMsoFRWYSyrPxcpCBGaTjil,payload=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,params=kJndetKVMsoFRWYSyrPxcpCBGaTjuq,headers=kJndetKVMsoFRWYSyrPxcpCBGaTjOu,cookies=kJndetKVMsoFRWYSyrPxcpCBGaTjEq,redirects=kJndetKVMsoFRWYSyrPxcpCBGaTjOw)
   kJndetKVMsoFRWYSyrPxcpCBGaTjuL=json.loads(kJndetKVMsoFRWYSyrPxcpCBGaTjig.text)
   if kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']['code']!='000':
    kJndetKVMsoFRWYSyrPxcpCBGaTjul['error_msg']=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['result']['message']
    return kJndetKVMsoFRWYSyrPxcpCBGaTjul
   kJndetKVMsoFRWYSyrPxcpCBGaTjQu=kJndetKVMsoFRWYSyrPxcpCBGaTjuL['body']['stream']
   if kJndetKVMsoFRWYSyrPxcpCBGaTjQu['drm_yn']=='Y':
    kJndetKVMsoFRWYSyrPxcpCBGaTjQm=kJndetKVMsoFRWYSyrPxcpCBGaTjQu['playback']['drm']['widevine']
    for kJndetKVMsoFRWYSyrPxcpCBGaTjQv in kJndetKVMsoFRWYSyrPxcpCBGaTjQu['playback']['drm']['license']['drm_license_data']:
     if kJndetKVMsoFRWYSyrPxcpCBGaTjQv['drm_type']=='Widevine':
      kJndetKVMsoFRWYSyrPxcpCBGaTjul['drm_server_url'] =kJndetKVMsoFRWYSyrPxcpCBGaTjQv['drm_server_url']
      kJndetKVMsoFRWYSyrPxcpCBGaTjul['drm_header_key'] =kJndetKVMsoFRWYSyrPxcpCBGaTjQv['drm_header_key']
      kJndetKVMsoFRWYSyrPxcpCBGaTjul['drm_header_value']=kJndetKVMsoFRWYSyrPxcpCBGaTjQv['drm_header_value']
      break
   else:
    kJndetKVMsoFRWYSyrPxcpCBGaTjQm=kJndetKVMsoFRWYSyrPxcpCBGaTjQu['playback']['non_drm']
  except kJndetKVMsoFRWYSyrPxcpCBGaTjON as exception:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhq(exception)
   kJndetKVMsoFRWYSyrPxcpCBGaTjul['error_msg']='Second Step - except error'
   return kJndetKVMsoFRWYSyrPxcpCBGaTjul
  kJndetKVMsoFRWYSyrPxcpCBGaTjQw=kJndetKVMsoFRWYSyrPxcpCBGaTjug
  kJndetKVMsoFRWYSyrPxcpCBGaTjQm=kJndetKVMsoFRWYSyrPxcpCBGaTjQm.split('|')[1]
  kJndetKVMsoFRWYSyrPxcpCBGaTjQm,kJndetKVMsoFRWYSyrPxcpCBGaTjQh,kJndetKVMsoFRWYSyrPxcpCBGaTjQO=kJndetKVMsoFRWYSyrPxcpCBGaTjEw.Decrypt_Url(kJndetKVMsoFRWYSyrPxcpCBGaTjQm,mediacode,kJndetKVMsoFRWYSyrPxcpCBGaTjQw)
  kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url']=kJndetKVMsoFRWYSyrPxcpCBGaTjQm
  kJndetKVMsoFRWYSyrPxcpCBGaTjhA =kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url'].find('Policy=')
  if kJndetKVMsoFRWYSyrPxcpCBGaTjhA!=-1:
   kJndetKVMsoFRWYSyrPxcpCBGaTjhl =kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url'].split('?')[0]
   kJndetKVMsoFRWYSyrPxcpCBGaTjhX=kJndetKVMsoFRWYSyrPxcpCBGaTjOI(urllib.parse.parse_qsl(urllib.parse.urlsplit(kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url']).query))
   kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url']='{}&CloudFront-Policy={}'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url'],kJndetKVMsoFRWYSyrPxcpCBGaTjhX['Policy'])
   kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url']='{}&CloudFront-Signature={}'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url'],kJndetKVMsoFRWYSyrPxcpCBGaTjhX['Signature'])
   kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url'],kJndetKVMsoFRWYSyrPxcpCBGaTjhX['Key-Pair-Id'])
  kJndetKVMsoFRWYSyrPxcpCBGaTjhg=['_tving_token','accessToken','authToken',]
  for kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjEl in kJndetKVMsoFRWYSyrPxcpCBGaTjEq.items():
   if kJndetKVMsoFRWYSyrPxcpCBGaTjEA in kJndetKVMsoFRWYSyrPxcpCBGaTjhg:
    kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url']='{}&{}={}'.format(kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url'],kJndetKVMsoFRWYSyrPxcpCBGaTjEA,kJndetKVMsoFRWYSyrPxcpCBGaTjEl)
  kJndetKVMsoFRWYSyrPxcpCBGaTjhq(kJndetKVMsoFRWYSyrPxcpCBGaTjul['streaming_url'])
  return kJndetKVMsoFRWYSyrPxcpCBGaTjul
# Created by pyminifier (https://github.com/liftoff/pyminifier)
