__author__="NightRain"
tuPvBojUYhaJIpgyAxLlMwTCVckKDQ=object
tuPvBojUYhaJIpgyAxLlMwTCVckKDb=None
tuPvBojUYhaJIpgyAxLlMwTCVckKzn=False
tuPvBojUYhaJIpgyAxLlMwTCVckKzm=True
tuPvBojUYhaJIpgyAxLlMwTCVckKzr=int
tuPvBojUYhaJIpgyAxLlMwTCVckKzd=len
tuPvBojUYhaJIpgyAxLlMwTCVckKzD=str
tuPvBojUYhaJIpgyAxLlMwTCVckKze=open
tuPvBojUYhaJIpgyAxLlMwTCVckKzN=dict
tuPvBojUYhaJIpgyAxLlMwTCVckKzG=Exception
tuPvBojUYhaJIpgyAxLlMwTCVckKzW=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmc.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
tuPvBojUYhaJIpgyAxLlMwTCVckKnr=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 (인기순)','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 (최신순)','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'월정액 영화관 (인기)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'-'},{'title':'월정액 영화관 (최신)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
tuPvBojUYhaJIpgyAxLlMwTCVckKnd=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
tuPvBojUYhaJIpgyAxLlMwTCVckKnD=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
tuPvBojUYhaJIpgyAxLlMwTCVckKnz=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
tuPvBojUYhaJIpgyAxLlMwTCVckKne=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'PROGRAM','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
tuPvBojUYhaJIpgyAxLlMwTCVckKnN={'C00551':'tvN','C00544':'중화TV','C00575':'Olive','C00579':'Mnet','C00590':'OGN','C01141':'XtvN','C01142':'ONSTYLE','C01143':'OtvN','C04601':'CGV','C06941':'tooniverse','C07381':'OCN','C07382':'SUPER ACTION','C15251':'OGN x LOL','C15252':'OGN x 오버워치','C15042':'티빙라이브','C01581':'TV CHOSUN','C01583':'채널A','C00708':'MBN','C00593':'YTN','C01101':'YTN Life','C15347':'YTN science','C01723':'연합뉴스TV','C15152':'DIA TV','C01582':'JTBC','C00588':'JTBC Golf','C15741':'JTBC2','C00805':'JTBC3 FOX Sports','C05661':'디즈니채널','C18641':'IHQ','C22041':'JTBC4','C23343':'t.cast','C23441':'E channel','C17341':'히스토리','C00585':'TV CHOSUN2','C17141':'채널A 플러스','C00611':'LIFETIME','C08041':'tvN go','C05901':'채널W','C23442':"D'LIVE",'C27441':'KBS N'}
tuPvBojUYhaJIpgyAxLlMwTCVckKnG ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
tuPvBojUYhaJIpgyAxLlMwTCVckKnW=xbmc.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class tuPvBojUYhaJIpgyAxLlMwTCVckKnm(tuPvBojUYhaJIpgyAxLlMwTCVckKDQ):
 def __init__(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKnO,tuPvBojUYhaJIpgyAxLlMwTCVckKnq,tuPvBojUYhaJIpgyAxLlMwTCVckKni):
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_url =tuPvBojUYhaJIpgyAxLlMwTCVckKnO
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_handle=tuPvBojUYhaJIpgyAxLlMwTCVckKnq
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.main_params =tuPvBojUYhaJIpgyAxLlMwTCVckKni
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj =SWzNtTXEGyxahijdOMPgbJpRVQBYcK() 
 def addon_noti(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,sting):
  try:
   tuPvBojUYhaJIpgyAxLlMwTCVckKnX=xbmcgui.Dialog()
   tuPvBojUYhaJIpgyAxLlMwTCVckKnX.notification(__addonname__,sting)
  except:
   tuPvBojUYhaJIpgyAxLlMwTCVckKDb
 def addon_log(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,string,isDebug=tuPvBojUYhaJIpgyAxLlMwTCVckKzn):
  try:
   tuPvBojUYhaJIpgyAxLlMwTCVckKnH=string.encode('utf-8','ignore')
  except:
   tuPvBojUYhaJIpgyAxLlMwTCVckKnH='addonException: addon_log'
  if isDebug:tuPvBojUYhaJIpgyAxLlMwTCVckKnf=xbmc.LOGDEBUG
  else:tuPvBojUYhaJIpgyAxLlMwTCVckKnf=xbmc.LOGNOTICE
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,tuPvBojUYhaJIpgyAxLlMwTCVckKnH),level=tuPvBojUYhaJIpgyAxLlMwTCVckKnf)
 def get_keyboard_input(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKme):
  tuPvBojUYhaJIpgyAxLlMwTCVckKnR=tuPvBojUYhaJIpgyAxLlMwTCVckKDb
  kb=xbmc.Keyboard()
  kb.setHeading(tuPvBojUYhaJIpgyAxLlMwTCVckKme)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   tuPvBojUYhaJIpgyAxLlMwTCVckKnR=kb.getText()
  return tuPvBojUYhaJIpgyAxLlMwTCVckKnR
 def get_settings_login_info(tuPvBojUYhaJIpgyAxLlMwTCVckKnS):
  tuPvBojUYhaJIpgyAxLlMwTCVckKns =__addon__.getSetting('id')
  tuPvBojUYhaJIpgyAxLlMwTCVckKnF =__addon__.getSetting('pw')
  tuPvBojUYhaJIpgyAxLlMwTCVckKnQ =__addon__.getSetting('login_type')
  return(tuPvBojUYhaJIpgyAxLlMwTCVckKns,tuPvBojUYhaJIpgyAxLlMwTCVckKnF,tuPvBojUYhaJIpgyAxLlMwTCVckKnQ)
 def get_settings_premiumyn(tuPvBojUYhaJIpgyAxLlMwTCVckKnS):
  tuPvBojUYhaJIpgyAxLlMwTCVckKnb =__addon__.getSetting('premium_movieyn')
  if tuPvBojUYhaJIpgyAxLlMwTCVckKnb=='false':
   return tuPvBojUYhaJIpgyAxLlMwTCVckKzn
  else:
   return tuPvBojUYhaJIpgyAxLlMwTCVckKzm
 def get_settings_direct_replay(tuPvBojUYhaJIpgyAxLlMwTCVckKnS):
  tuPvBojUYhaJIpgyAxLlMwTCVckKmn=tuPvBojUYhaJIpgyAxLlMwTCVckKzr(__addon__.getSetting('direct_replay'))
  if tuPvBojUYhaJIpgyAxLlMwTCVckKmn==0:
   return tuPvBojUYhaJIpgyAxLlMwTCVckKzn
  else:
   return tuPvBojUYhaJIpgyAxLlMwTCVckKzm
 def get_settings_thumbnail_landyn(tuPvBojUYhaJIpgyAxLlMwTCVckKnS):
  tuPvBojUYhaJIpgyAxLlMwTCVckKmr =tuPvBojUYhaJIpgyAxLlMwTCVckKzr(__addon__.getSetting('thumbnail_way'))
  if tuPvBojUYhaJIpgyAxLlMwTCVckKmr==0:
   return tuPvBojUYhaJIpgyAxLlMwTCVckKzm
  else:
   return tuPvBojUYhaJIpgyAxLlMwTCVckKzn
 def set_winCredential(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,credential):
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd=xbmcgui.Window(10000)
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd.setProperty('TVING_M_LOGINTIME',datetime.datetime.now().strftime('%Y-%m-%d'))
 def get_winCredential(tuPvBojUYhaJIpgyAxLlMwTCVckKnS):
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd=xbmcgui.Window(10000)
  tuPvBojUYhaJIpgyAxLlMwTCVckKmD={'tving_token':tuPvBojUYhaJIpgyAxLlMwTCVckKmd.getProperty('TVING_M_TOKEN'),'poc_userinfo':tuPvBojUYhaJIpgyAxLlMwTCVckKmd.getProperty('TVING_M_USERINFO'),'tving_uuid':tuPvBojUYhaJIpgyAxLlMwTCVckKmd.getProperty('TVING_M_UUID')}
  return tuPvBojUYhaJIpgyAxLlMwTCVckKmD
 def set_winEpisodeOrderby(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKri):
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd=xbmcgui.Window(10000)
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd.setProperty('TVING_M_ORDERBY',tuPvBojUYhaJIpgyAxLlMwTCVckKri)
 def get_winEpisodeOrderby(tuPvBojUYhaJIpgyAxLlMwTCVckKnS):
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd=xbmcgui.Window(10000)
  return tuPvBojUYhaJIpgyAxLlMwTCVckKmd.getProperty('TVING_M_ORDERBY')
 def add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,label,sublabel='',img='',infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKDb,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzm,params=''):
  tuPvBojUYhaJIpgyAxLlMwTCVckKmz='%s?%s'%(tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_url,urllib.parse.urlencode(params))
  if sublabel:tuPvBojUYhaJIpgyAxLlMwTCVckKme='%s < %s >'%(label,sublabel)
  else: tuPvBojUYhaJIpgyAxLlMwTCVckKme=label
  if not img:img='DefaultFolder.png'
  tuPvBojUYhaJIpgyAxLlMwTCVckKmN=xbmcgui.ListItem(tuPvBojUYhaJIpgyAxLlMwTCVckKme)
  tuPvBojUYhaJIpgyAxLlMwTCVckKmN.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:tuPvBojUYhaJIpgyAxLlMwTCVckKmN.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:tuPvBojUYhaJIpgyAxLlMwTCVckKmN.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_handle,tuPvBojUYhaJIpgyAxLlMwTCVckKmz,tuPvBojUYhaJIpgyAxLlMwTCVckKmN,isFolder)
 def get_selQuality(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,etype):
  try:
   tuPvBojUYhaJIpgyAxLlMwTCVckKmG='selected_quality'
   tuPvBojUYhaJIpgyAxLlMwTCVckKmW=[1080,720,480,360]
   tuPvBojUYhaJIpgyAxLlMwTCVckKmS=tuPvBojUYhaJIpgyAxLlMwTCVckKzr(__addon__.getSetting(tuPvBojUYhaJIpgyAxLlMwTCVckKmG))
   return tuPvBojUYhaJIpgyAxLlMwTCVckKmW[tuPvBojUYhaJIpgyAxLlMwTCVckKmS]
  except:
   tuPvBojUYhaJIpgyAxLlMwTCVckKDb
  return 720 
 def dp_Main_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS):
  for tuPvBojUYhaJIpgyAxLlMwTCVckKmO in tuPvBojUYhaJIpgyAxLlMwTCVckKnr:
   tuPvBojUYhaJIpgyAxLlMwTCVckKme=tuPvBojUYhaJIpgyAxLlMwTCVckKmO.get('title')
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':tuPvBojUYhaJIpgyAxLlMwTCVckKmO.get('mode'),'stype':tuPvBojUYhaJIpgyAxLlMwTCVckKmO.get('stype'),'orderby':tuPvBojUYhaJIpgyAxLlMwTCVckKmO.get('orderby'),'ordernm':tuPvBojUYhaJIpgyAxLlMwTCVckKmO.get('ordernm'),'page':'1'}
   if tuPvBojUYhaJIpgyAxLlMwTCVckKmO.get('mode')=='XXX':
    tuPvBojUYhaJIpgyAxLlMwTCVckKmq['mode']='XXX'
    tuPvBojUYhaJIpgyAxLlMwTCVckKmi=tuPvBojUYhaJIpgyAxLlMwTCVckKzn
   else:
    tuPvBojUYhaJIpgyAxLlMwTCVckKmi=tuPvBojUYhaJIpgyAxLlMwTCVckKzm
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel='',img='',infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKDb,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKmi,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKzd(tuPvBojUYhaJIpgyAxLlMwTCVckKnr)>0:xbmcplugin.endOfDirectory(tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_handle)
 def login_main(tuPvBojUYhaJIpgyAxLlMwTCVckKnS):
  (tuPvBojUYhaJIpgyAxLlMwTCVckKmX,tuPvBojUYhaJIpgyAxLlMwTCVckKmH,tuPvBojUYhaJIpgyAxLlMwTCVckKmf)=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_settings_login_info()
  if not(tuPvBojUYhaJIpgyAxLlMwTCVckKmX and tuPvBojUYhaJIpgyAxLlMwTCVckKmH):
   tuPvBojUYhaJIpgyAxLlMwTCVckKnX=xbmcgui.Dialog()
   tuPvBojUYhaJIpgyAxLlMwTCVckKmR=tuPvBojUYhaJIpgyAxLlMwTCVckKnX.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if tuPvBojUYhaJIpgyAxLlMwTCVckKmR==tuPvBojUYhaJIpgyAxLlMwTCVckKzm:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_winEpisodeOrderby()=='':
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.set_winEpisodeOrderby('desc')
  if tuPvBojUYhaJIpgyAxLlMwTCVckKnS.cookiefile_check():return
  tuPvBojUYhaJIpgyAxLlMwTCVckKms =tuPvBojUYhaJIpgyAxLlMwTCVckKzr(datetime.datetime.now().strftime('%Y%m%d'))
  tuPvBojUYhaJIpgyAxLlMwTCVckKmF=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if tuPvBojUYhaJIpgyAxLlMwTCVckKmF==tuPvBojUYhaJIpgyAxLlMwTCVckKDb or tuPvBojUYhaJIpgyAxLlMwTCVckKmF=='':tuPvBojUYhaJIpgyAxLlMwTCVckKmF=tuPvBojUYhaJIpgyAxLlMwTCVckKzr('19000101')
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   tuPvBojUYhaJIpgyAxLlMwTCVckKmQ=0
   while tuPvBojUYhaJIpgyAxLlMwTCVckKzm:
    tuPvBojUYhaJIpgyAxLlMwTCVckKmQ+=1
    time.sleep(0.05)
    if tuPvBojUYhaJIpgyAxLlMwTCVckKmF>=tuPvBojUYhaJIpgyAxLlMwTCVckKms:return
    if tuPvBojUYhaJIpgyAxLlMwTCVckKmQ>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if tuPvBojUYhaJIpgyAxLlMwTCVckKmF>=tuPvBojUYhaJIpgyAxLlMwTCVckKms:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.GetCredential(tuPvBojUYhaJIpgyAxLlMwTCVckKmX,tuPvBojUYhaJIpgyAxLlMwTCVckKmH,tuPvBojUYhaJIpgyAxLlMwTCVckKmf):
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.set_winCredential(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.LoadCredential())
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKrd):
  tuPvBojUYhaJIpgyAxLlMwTCVckKmb=tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('stype')
  if tuPvBojUYhaJIpgyAxLlMwTCVckKmb=='live':
   tuPvBojUYhaJIpgyAxLlMwTCVckKrn=tuPvBojUYhaJIpgyAxLlMwTCVckKnd
  else:
   tuPvBojUYhaJIpgyAxLlMwTCVckKrn=tuPvBojUYhaJIpgyAxLlMwTCVckKne
  for tuPvBojUYhaJIpgyAxLlMwTCVckKrm in tuPvBojUYhaJIpgyAxLlMwTCVckKrn:
   tuPvBojUYhaJIpgyAxLlMwTCVckKme=tuPvBojUYhaJIpgyAxLlMwTCVckKrm.get('title')
   if tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('ordernm')!='-':
    tuPvBojUYhaJIpgyAxLlMwTCVckKme+='  ('+tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('ordernm')+')'
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':tuPvBojUYhaJIpgyAxLlMwTCVckKrm.get('mode'),'stype':tuPvBojUYhaJIpgyAxLlMwTCVckKrm.get('stype'),'orderby':tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('orderby'),'page':'1'}
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel='',img='',infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKDb,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzm,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKzd(tuPvBojUYhaJIpgyAxLlMwTCVckKrn)>0:xbmcplugin.endOfDirectory(tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_handle)
 def dp_LiveChannel_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKrd):
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.SaveCredential(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_winCredential())
  tuPvBojUYhaJIpgyAxLlMwTCVckKmb =tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('stype')
  tuPvBojUYhaJIpgyAxLlMwTCVckKrD =tuPvBojUYhaJIpgyAxLlMwTCVckKzr(tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('page'))
  tuPvBojUYhaJIpgyAxLlMwTCVckKrz,tuPvBojUYhaJIpgyAxLlMwTCVckKre=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.GetLiveChannelList(tuPvBojUYhaJIpgyAxLlMwTCVckKmb,tuPvBojUYhaJIpgyAxLlMwTCVckKrD)
  for tuPvBojUYhaJIpgyAxLlMwTCVckKrN in tuPvBojUYhaJIpgyAxLlMwTCVckKrz:
   tuPvBojUYhaJIpgyAxLlMwTCVckKme =tuPvBojUYhaJIpgyAxLlMwTCVckKrN.get('title')
   tuPvBojUYhaJIpgyAxLlMwTCVckKmE =tuPvBojUYhaJIpgyAxLlMwTCVckKrN.get('channel')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrG =tuPvBojUYhaJIpgyAxLlMwTCVckKrN.get('thumbnail')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrW =tuPvBojUYhaJIpgyAxLlMwTCVckKrN.get('synopsis')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrS=tuPvBojUYhaJIpgyAxLlMwTCVckKrN.get('channelepg')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrO=tuPvBojUYhaJIpgyAxLlMwTCVckKrN.get('info')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrO['plot']='%s\n%s\n%s\n\n%s'%(tuPvBojUYhaJIpgyAxLlMwTCVckKmE,tuPvBojUYhaJIpgyAxLlMwTCVckKme,tuPvBojUYhaJIpgyAxLlMwTCVckKrS,tuPvBojUYhaJIpgyAxLlMwTCVckKrW)
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':'LIVE','mediacode':tuPvBojUYhaJIpgyAxLlMwTCVckKrN.get('mediacode'),'stype':tuPvBojUYhaJIpgyAxLlMwTCVckKmb}
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKmE,sublabel=tuPvBojUYhaJIpgyAxLlMwTCVckKme,img=tuPvBojUYhaJIpgyAxLlMwTCVckKrG,infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKrO,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzn,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKre:
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['mode']='CHANNEL' 
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['stype']=tuPvBojUYhaJIpgyAxLlMwTCVckKmb 
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['page']=tuPvBojUYhaJIpgyAxLlMwTCVckKzD(tuPvBojUYhaJIpgyAxLlMwTCVckKrD+1)
   tuPvBojUYhaJIpgyAxLlMwTCVckKme='[B]%s >>[/B]'%'다음 페이지'
   tuPvBojUYhaJIpgyAxLlMwTCVckKrq=tuPvBojUYhaJIpgyAxLlMwTCVckKzD(tuPvBojUYhaJIpgyAxLlMwTCVckKrD+1)
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel=tuPvBojUYhaJIpgyAxLlMwTCVckKrq,img='',infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKDb,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzm,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKzd(tuPvBojUYhaJIpgyAxLlMwTCVckKrz)>0:xbmcplugin.endOfDirectory(tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_handle,cacheToDisc=tuPvBojUYhaJIpgyAxLlMwTCVckKzn)
 def dp_Program_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKrd):
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.SaveCredential(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_winCredential())
  tuPvBojUYhaJIpgyAxLlMwTCVckKmb =tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('stype')
  tuPvBojUYhaJIpgyAxLlMwTCVckKri =tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('orderby')
  tuPvBojUYhaJIpgyAxLlMwTCVckKrD =tuPvBojUYhaJIpgyAxLlMwTCVckKzr(tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('page'))
  tuPvBojUYhaJIpgyAxLlMwTCVckKrE,tuPvBojUYhaJIpgyAxLlMwTCVckKre=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.GetProgramList(tuPvBojUYhaJIpgyAxLlMwTCVckKmb,tuPvBojUYhaJIpgyAxLlMwTCVckKri,tuPvBojUYhaJIpgyAxLlMwTCVckKrD,landyn=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_settings_thumbnail_landyn())
  for tuPvBojUYhaJIpgyAxLlMwTCVckKrX in tuPvBojUYhaJIpgyAxLlMwTCVckKrE:
   tuPvBojUYhaJIpgyAxLlMwTCVckKme =tuPvBojUYhaJIpgyAxLlMwTCVckKrX.get('title')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrG=tuPvBojUYhaJIpgyAxLlMwTCVckKrX.get('thumbnail')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrW =tuPvBojUYhaJIpgyAxLlMwTCVckKrX.get('synopsis')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrH =tuPvBojUYhaJIpgyAxLlMwTCVckKnN.get(tuPvBojUYhaJIpgyAxLlMwTCVckKrX.get('channel'))
   tuPvBojUYhaJIpgyAxLlMwTCVckKrO=tuPvBojUYhaJIpgyAxLlMwTCVckKrX.get('info')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrO['studio']=tuPvBojUYhaJIpgyAxLlMwTCVckKrH
   tuPvBojUYhaJIpgyAxLlMwTCVckKrO['plot']='%s <%s>\n\n%s'%(tuPvBojUYhaJIpgyAxLlMwTCVckKme,tuPvBojUYhaJIpgyAxLlMwTCVckKrH,tuPvBojUYhaJIpgyAxLlMwTCVckKrW)
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':'EPISODE','programcode':tuPvBojUYhaJIpgyAxLlMwTCVckKrX.get('program'),'page':'1'}
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel=tuPvBojUYhaJIpgyAxLlMwTCVckKrH,img=tuPvBojUYhaJIpgyAxLlMwTCVckKrG,infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKrO,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzm,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKre:
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['mode'] ='PROGRAM' 
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['stype'] =tuPvBojUYhaJIpgyAxLlMwTCVckKmb
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['orderby']=tuPvBojUYhaJIpgyAxLlMwTCVckKri
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['page'] =tuPvBojUYhaJIpgyAxLlMwTCVckKzD(tuPvBojUYhaJIpgyAxLlMwTCVckKrD+1)
   tuPvBojUYhaJIpgyAxLlMwTCVckKme='[B]%s >>[/B]'%'다음 페이지'
   tuPvBojUYhaJIpgyAxLlMwTCVckKrq=tuPvBojUYhaJIpgyAxLlMwTCVckKzD(tuPvBojUYhaJIpgyAxLlMwTCVckKrD+1)
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel=tuPvBojUYhaJIpgyAxLlMwTCVckKrq,img='',infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKDb,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzm,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKzd(tuPvBojUYhaJIpgyAxLlMwTCVckKrE)>0:xbmcplugin.endOfDirectory(tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_handle,cacheToDisc=tuPvBojUYhaJIpgyAxLlMwTCVckKzn)
 def dp_Episode_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKrd):
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.SaveCredential(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_winCredential())
  tuPvBojUYhaJIpgyAxLlMwTCVckKrf=tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('programcode')
  tuPvBojUYhaJIpgyAxLlMwTCVckKrD =tuPvBojUYhaJIpgyAxLlMwTCVckKzr(tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('page'))
  tuPvBojUYhaJIpgyAxLlMwTCVckKrR,tuPvBojUYhaJIpgyAxLlMwTCVckKre,tuPvBojUYhaJIpgyAxLlMwTCVckKrs=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.GetEpisodoList(tuPvBojUYhaJIpgyAxLlMwTCVckKrf,tuPvBojUYhaJIpgyAxLlMwTCVckKrD,orderby=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_winEpisodeOrderby())
  for tuPvBojUYhaJIpgyAxLlMwTCVckKrF in tuPvBojUYhaJIpgyAxLlMwTCVckKrR:
   tuPvBojUYhaJIpgyAxLlMwTCVckKme =tuPvBojUYhaJIpgyAxLlMwTCVckKrF.get('title')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrq =tuPvBojUYhaJIpgyAxLlMwTCVckKrF.get('subtitle')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrG=tuPvBojUYhaJIpgyAxLlMwTCVckKrF.get('thumbnail')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrW =tuPvBojUYhaJIpgyAxLlMwTCVckKrF.get('synopsis')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrO=tuPvBojUYhaJIpgyAxLlMwTCVckKrF.get('info')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrO['plot']='%s\n\n%s'%(tuPvBojUYhaJIpgyAxLlMwTCVckKme,tuPvBojUYhaJIpgyAxLlMwTCVckKrW)
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':'VOD','mediacode':tuPvBojUYhaJIpgyAxLlMwTCVckKrF.get('episode'),'stype':'vod','programcode':tuPvBojUYhaJIpgyAxLlMwTCVckKrf,'title':tuPvBojUYhaJIpgyAxLlMwTCVckKme,'thumbnail':tuPvBojUYhaJIpgyAxLlMwTCVckKrG}
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel=tuPvBojUYhaJIpgyAxLlMwTCVckKrq,img=tuPvBojUYhaJIpgyAxLlMwTCVckKrG,infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKrO,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzn,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKrD==1:
   tuPvBojUYhaJIpgyAxLlMwTCVckKrO={'plot':'정렬순서를 변경합니다.'}
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq={}
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['mode'] ='ORDER_BY' 
   if tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_winEpisodeOrderby()=='desc':
    tuPvBojUYhaJIpgyAxLlMwTCVckKme='정렬순서변경 : 최신화부터 -> 1회부터'
    tuPvBojUYhaJIpgyAxLlMwTCVckKmq['orderby']='asc'
   else:
    tuPvBojUYhaJIpgyAxLlMwTCVckKme='정렬순서변경 : 1회부터 -> 최신화부터'
    tuPvBojUYhaJIpgyAxLlMwTCVckKmq['orderby']='desc'
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel='',img='',infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKrO,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzn,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKre:
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['mode'] ='EPISODE' 
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['programcode']=tuPvBojUYhaJIpgyAxLlMwTCVckKrf
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['page'] =tuPvBojUYhaJIpgyAxLlMwTCVckKzD(tuPvBojUYhaJIpgyAxLlMwTCVckKrD+1)
   tuPvBojUYhaJIpgyAxLlMwTCVckKme='[B]%s >>[/B]'%'다음 페이지'
   tuPvBojUYhaJIpgyAxLlMwTCVckKrq=tuPvBojUYhaJIpgyAxLlMwTCVckKzD(tuPvBojUYhaJIpgyAxLlMwTCVckKrD+1)
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel=tuPvBojUYhaJIpgyAxLlMwTCVckKrq,img='',infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKDb,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzm,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKzd(tuPvBojUYhaJIpgyAxLlMwTCVckKrR)>0:xbmcplugin.endOfDirectory(tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_handle,cacheToDisc=tuPvBojUYhaJIpgyAxLlMwTCVckKzm)
 def dp_setEpOrderby(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKrd):
  tuPvBojUYhaJIpgyAxLlMwTCVckKri =tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('orderby')
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.set_winEpisodeOrderby(tuPvBojUYhaJIpgyAxLlMwTCVckKri)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKrd):
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.SaveCredential(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_winCredential())
  tuPvBojUYhaJIpgyAxLlMwTCVckKri =tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('orderby')
  tuPvBojUYhaJIpgyAxLlMwTCVckKrD=tuPvBojUYhaJIpgyAxLlMwTCVckKzr(tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('page'))
  tuPvBojUYhaJIpgyAxLlMwTCVckKrQ,tuPvBojUYhaJIpgyAxLlMwTCVckKre=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.GetMovieList(tuPvBojUYhaJIpgyAxLlMwTCVckKri,tuPvBojUYhaJIpgyAxLlMwTCVckKrD,premiumyn=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_settings_premiumyn(),landyn=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_settings_thumbnail_landyn())
  for tuPvBojUYhaJIpgyAxLlMwTCVckKrb in tuPvBojUYhaJIpgyAxLlMwTCVckKrQ:
   tuPvBojUYhaJIpgyAxLlMwTCVckKme =tuPvBojUYhaJIpgyAxLlMwTCVckKrb.get('title')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrG=tuPvBojUYhaJIpgyAxLlMwTCVckKrb.get('thumbnail')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrW =tuPvBojUYhaJIpgyAxLlMwTCVckKrb.get('synopsis')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrO=tuPvBojUYhaJIpgyAxLlMwTCVckKrb.get('info')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrO['plot']='%s\n\n%s'%(tuPvBojUYhaJIpgyAxLlMwTCVckKme,tuPvBojUYhaJIpgyAxLlMwTCVckKrW)
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':'MOVIE','mediacode':tuPvBojUYhaJIpgyAxLlMwTCVckKrb.get('moviecode'),'stype':'movie','title':tuPvBojUYhaJIpgyAxLlMwTCVckKme,'thumbnail':tuPvBojUYhaJIpgyAxLlMwTCVckKrG}
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel='',img=tuPvBojUYhaJIpgyAxLlMwTCVckKrG,infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKrO,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzn,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKre:
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['mode'] ='MOVIE_GROUP' 
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['orderby']=tuPvBojUYhaJIpgyAxLlMwTCVckKri
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['page'] =tuPvBojUYhaJIpgyAxLlMwTCVckKzD(tuPvBojUYhaJIpgyAxLlMwTCVckKrD+1)
   tuPvBojUYhaJIpgyAxLlMwTCVckKme='[B]%s >>[/B]'%'다음 페이지'
   tuPvBojUYhaJIpgyAxLlMwTCVckKrq=tuPvBojUYhaJIpgyAxLlMwTCVckKzD(tuPvBojUYhaJIpgyAxLlMwTCVckKrD+1)
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel=tuPvBojUYhaJIpgyAxLlMwTCVckKrq,img='',infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKDb,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzm,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKzd(tuPvBojUYhaJIpgyAxLlMwTCVckKrQ)>0:xbmcplugin.endOfDirectory(tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_handle,cacheToDisc=tuPvBojUYhaJIpgyAxLlMwTCVckKzn)
 def dp_Search_Group(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKrd):
  for tuPvBojUYhaJIpgyAxLlMwTCVckKrm in tuPvBojUYhaJIpgyAxLlMwTCVckKnz:
   tuPvBojUYhaJIpgyAxLlMwTCVckKme=tuPvBojUYhaJIpgyAxLlMwTCVckKrm.get('title')
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':tuPvBojUYhaJIpgyAxLlMwTCVckKrm.get('mode'),'stype':tuPvBojUYhaJIpgyAxLlMwTCVckKrm.get('stype'),'page':'1'}
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel='',img='',infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKDb,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzm,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKzd(tuPvBojUYhaJIpgyAxLlMwTCVckKnz)>0:xbmcplugin.endOfDirectory(tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_handle)
 def dp_Search_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKrd):
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.SaveCredential(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_winCredential())
  tuPvBojUYhaJIpgyAxLlMwTCVckKdn =__addon__.getSetting('id')
  tuPvBojUYhaJIpgyAxLlMwTCVckKrD =tuPvBojUYhaJIpgyAxLlMwTCVckKzr(tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('page'))
  tuPvBojUYhaJIpgyAxLlMwTCVckKmb =tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('stype')
  if 'search_key' in tuPvBojUYhaJIpgyAxLlMwTCVckKrd:
   tuPvBojUYhaJIpgyAxLlMwTCVckKdm=tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('search_key')
  else:
   tuPvBojUYhaJIpgyAxLlMwTCVckKdm=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not tuPvBojUYhaJIpgyAxLlMwTCVckKdm:return
  tuPvBojUYhaJIpgyAxLlMwTCVckKdr,tuPvBojUYhaJIpgyAxLlMwTCVckKre=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.GetSearchList(tuPvBojUYhaJIpgyAxLlMwTCVckKdm,tuPvBojUYhaJIpgyAxLlMwTCVckKdn,tuPvBojUYhaJIpgyAxLlMwTCVckKrD,tuPvBojUYhaJIpgyAxLlMwTCVckKmb,premiumyn=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_settings_premiumyn(),landyn=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_settings_thumbnail_landyn())
  if tuPvBojUYhaJIpgyAxLlMwTCVckKzd(tuPvBojUYhaJIpgyAxLlMwTCVckKdr)==0:return
  for tuPvBojUYhaJIpgyAxLlMwTCVckKdD in tuPvBojUYhaJIpgyAxLlMwTCVckKdr:
   tuPvBojUYhaJIpgyAxLlMwTCVckKme =tuPvBojUYhaJIpgyAxLlMwTCVckKdD.get('title')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrG=tuPvBojUYhaJIpgyAxLlMwTCVckKdD.get('thumbnail')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrW =tuPvBojUYhaJIpgyAxLlMwTCVckKdD.get('synopsis')
   tuPvBojUYhaJIpgyAxLlMwTCVckKdz =tuPvBojUYhaJIpgyAxLlMwTCVckKdD.get('program')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrO=tuPvBojUYhaJIpgyAxLlMwTCVckKdD.get('info')
   tuPvBojUYhaJIpgyAxLlMwTCVckKrO['plot']='%s\n\n%s'%(tuPvBojUYhaJIpgyAxLlMwTCVckKme,tuPvBojUYhaJIpgyAxLlMwTCVckKrW)
   if tuPvBojUYhaJIpgyAxLlMwTCVckKmb=='vod':
    tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':'EPISODE','programcode':tuPvBojUYhaJIpgyAxLlMwTCVckKdD.get('program'),'page':'1'}
    tuPvBojUYhaJIpgyAxLlMwTCVckKmi=tuPvBojUYhaJIpgyAxLlMwTCVckKzm
   else:
    tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':'MOVIE','mediacode':tuPvBojUYhaJIpgyAxLlMwTCVckKdD.get('movie'),'stype':'movie','title':tuPvBojUYhaJIpgyAxLlMwTCVckKme,'thumbnail':tuPvBojUYhaJIpgyAxLlMwTCVckKrG}
    tuPvBojUYhaJIpgyAxLlMwTCVckKmi=tuPvBojUYhaJIpgyAxLlMwTCVckKzn
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel='',img=tuPvBojUYhaJIpgyAxLlMwTCVckKrG,infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKrO,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKmi,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKre:
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['mode'] ='SEARCH' 
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['search_key']=tuPvBojUYhaJIpgyAxLlMwTCVckKdm
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq['page'] =tuPvBojUYhaJIpgyAxLlMwTCVckKzD(tuPvBojUYhaJIpgyAxLlMwTCVckKrD+1)
   tuPvBojUYhaJIpgyAxLlMwTCVckKme='[B]%s >>[/B]'%'다음 페이지'
   tuPvBojUYhaJIpgyAxLlMwTCVckKrq=tuPvBojUYhaJIpgyAxLlMwTCVckKzD(tuPvBojUYhaJIpgyAxLlMwTCVckKrD+1)
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel=tuPvBojUYhaJIpgyAxLlMwTCVckKrq,img='',infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKDb,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzm,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKzd(tuPvBojUYhaJIpgyAxLlMwTCVckKdr)>0:xbmcplugin.endOfDirectory(tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_handle)
 def Delete_Watched_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKmb):
  try:
   tuPvBojUYhaJIpgyAxLlMwTCVckKde=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%tuPvBojUYhaJIpgyAxLlMwTCVckKmb))
   with tuPvBojUYhaJIpgyAxLlMwTCVckKze(tuPvBojUYhaJIpgyAxLlMwTCVckKde,'w',-1,'utf-8')as fp:
    fp.write('')
  except:
   tuPvBojUYhaJIpgyAxLlMwTCVckKDb
 def dp_WatchList_Delete(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKrd):
  tuPvBojUYhaJIpgyAxLlMwTCVckKmb=tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('stype')
  tuPvBojUYhaJIpgyAxLlMwTCVckKnX=xbmcgui.Dialog()
  tuPvBojUYhaJIpgyAxLlMwTCVckKmR=tuPvBojUYhaJIpgyAxLlMwTCVckKnX.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if tuPvBojUYhaJIpgyAxLlMwTCVckKmR==tuPvBojUYhaJIpgyAxLlMwTCVckKzn:sys.exit()
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.Delete_Watched_List(tuPvBojUYhaJIpgyAxLlMwTCVckKmb)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKmb):
  try:
   tuPvBojUYhaJIpgyAxLlMwTCVckKde=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%tuPvBojUYhaJIpgyAxLlMwTCVckKmb))
   with tuPvBojUYhaJIpgyAxLlMwTCVckKze(tuPvBojUYhaJIpgyAxLlMwTCVckKde,'r',-1,'utf-8')as fp:
    tuPvBojUYhaJIpgyAxLlMwTCVckKdN=fp.readlines()
  except:
   tuPvBojUYhaJIpgyAxLlMwTCVckKdN=[]
  return tuPvBojUYhaJIpgyAxLlMwTCVckKdN
 def Save_Watched_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKmb,tuPvBojUYhaJIpgyAxLlMwTCVckKni):
  try:
   tuPvBojUYhaJIpgyAxLlMwTCVckKde=xbmc.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%tuPvBojUYhaJIpgyAxLlMwTCVckKmb))
   tuPvBojUYhaJIpgyAxLlMwTCVckKdG=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.Load_Watched_List(tuPvBojUYhaJIpgyAxLlMwTCVckKmb) 
   with tuPvBojUYhaJIpgyAxLlMwTCVckKze(tuPvBojUYhaJIpgyAxLlMwTCVckKde,'w',-1,'utf-8')as fp:
    tuPvBojUYhaJIpgyAxLlMwTCVckKdW=urllib.parse.urlencode(tuPvBojUYhaJIpgyAxLlMwTCVckKni)
    tuPvBojUYhaJIpgyAxLlMwTCVckKdW=tuPvBojUYhaJIpgyAxLlMwTCVckKdW+'\n'
    fp.write(tuPvBojUYhaJIpgyAxLlMwTCVckKdW)
    tuPvBojUYhaJIpgyAxLlMwTCVckKdS=0
    for tuPvBojUYhaJIpgyAxLlMwTCVckKdO in tuPvBojUYhaJIpgyAxLlMwTCVckKdG:
     tuPvBojUYhaJIpgyAxLlMwTCVckKdq=tuPvBojUYhaJIpgyAxLlMwTCVckKzN(urllib.parse.parse_qsl(tuPvBojUYhaJIpgyAxLlMwTCVckKdO))
     tuPvBojUYhaJIpgyAxLlMwTCVckKdi=tuPvBojUYhaJIpgyAxLlMwTCVckKni.get('code')
     tuPvBojUYhaJIpgyAxLlMwTCVckKdE=tuPvBojUYhaJIpgyAxLlMwTCVckKdq.get('code')
     if tuPvBojUYhaJIpgyAxLlMwTCVckKmb=='vod' and tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_settings_direct_replay()==tuPvBojUYhaJIpgyAxLlMwTCVckKzm:
      tuPvBojUYhaJIpgyAxLlMwTCVckKdi=tuPvBojUYhaJIpgyAxLlMwTCVckKni.get('videoid')
      tuPvBojUYhaJIpgyAxLlMwTCVckKdE=tuPvBojUYhaJIpgyAxLlMwTCVckKdq.get('videoid')if tuPvBojUYhaJIpgyAxLlMwTCVckKdE!=tuPvBojUYhaJIpgyAxLlMwTCVckKDb else '-'
     if tuPvBojUYhaJIpgyAxLlMwTCVckKdi!=tuPvBojUYhaJIpgyAxLlMwTCVckKdE:
      fp.write(tuPvBojUYhaJIpgyAxLlMwTCVckKdO)
      tuPvBojUYhaJIpgyAxLlMwTCVckKdS+=1
      if tuPvBojUYhaJIpgyAxLlMwTCVckKdS>=50:break
  except:
   tuPvBojUYhaJIpgyAxLlMwTCVckKDb
 def dp_Watch_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKrd):
  tuPvBojUYhaJIpgyAxLlMwTCVckKmb =tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('stype')
  tuPvBojUYhaJIpgyAxLlMwTCVckKmn=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_settings_direct_replay()
  if tuPvBojUYhaJIpgyAxLlMwTCVckKmb=='-':
   for tuPvBojUYhaJIpgyAxLlMwTCVckKrm in tuPvBojUYhaJIpgyAxLlMwTCVckKnD:
    tuPvBojUYhaJIpgyAxLlMwTCVckKme=tuPvBojUYhaJIpgyAxLlMwTCVckKrm.get('title')
    tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':tuPvBojUYhaJIpgyAxLlMwTCVckKrm.get('mode'),'stype':tuPvBojUYhaJIpgyAxLlMwTCVckKrm.get('stype')}
    tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel='',img='',infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKDb,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzm,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
   if tuPvBojUYhaJIpgyAxLlMwTCVckKzd(tuPvBojUYhaJIpgyAxLlMwTCVckKnD)>0:xbmcplugin.endOfDirectory(tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_handle)
  else:
   tuPvBojUYhaJIpgyAxLlMwTCVckKdX=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.Load_Watched_List(tuPvBojUYhaJIpgyAxLlMwTCVckKmb)
   for tuPvBojUYhaJIpgyAxLlMwTCVckKdH in tuPvBojUYhaJIpgyAxLlMwTCVckKdX:
    tuPvBojUYhaJIpgyAxLlMwTCVckKdf=tuPvBojUYhaJIpgyAxLlMwTCVckKzN(urllib.parse.parse_qsl(tuPvBojUYhaJIpgyAxLlMwTCVckKdH))
    tuPvBojUYhaJIpgyAxLlMwTCVckKme =tuPvBojUYhaJIpgyAxLlMwTCVckKdf.get('title')
    tuPvBojUYhaJIpgyAxLlMwTCVckKrG=tuPvBojUYhaJIpgyAxLlMwTCVckKdf.get('img')
    tuPvBojUYhaJIpgyAxLlMwTCVckKdR =tuPvBojUYhaJIpgyAxLlMwTCVckKdf.get('videoid')
    tuPvBojUYhaJIpgyAxLlMwTCVckKrO={}
    tuPvBojUYhaJIpgyAxLlMwTCVckKrO['plot']=tuPvBojUYhaJIpgyAxLlMwTCVckKme
    if tuPvBojUYhaJIpgyAxLlMwTCVckKmb=='vod':
     if tuPvBojUYhaJIpgyAxLlMwTCVckKmn==tuPvBojUYhaJIpgyAxLlMwTCVckKzn or tuPvBojUYhaJIpgyAxLlMwTCVckKdR==tuPvBojUYhaJIpgyAxLlMwTCVckKDb:
      tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':'EPISODE','programcode':tuPvBojUYhaJIpgyAxLlMwTCVckKdf.get('code'),'page':'1'}
      tuPvBojUYhaJIpgyAxLlMwTCVckKmi=tuPvBojUYhaJIpgyAxLlMwTCVckKzm
     else:
      tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':'VOD','mediacode':tuPvBojUYhaJIpgyAxLlMwTCVckKdR,'stype':'vod','programcode':tuPvBojUYhaJIpgyAxLlMwTCVckKdf.get('code'),'title':tuPvBojUYhaJIpgyAxLlMwTCVckKme,'thumbnail':tuPvBojUYhaJIpgyAxLlMwTCVckKrG}
      tuPvBojUYhaJIpgyAxLlMwTCVckKmi=tuPvBojUYhaJIpgyAxLlMwTCVckKzn
    else:
     tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':'MOVIE','mediacode':tuPvBojUYhaJIpgyAxLlMwTCVckKdf.get('code'),'stype':'movie','title':tuPvBojUYhaJIpgyAxLlMwTCVckKme,'thumbnail':tuPvBojUYhaJIpgyAxLlMwTCVckKrG}
     tuPvBojUYhaJIpgyAxLlMwTCVckKmi=tuPvBojUYhaJIpgyAxLlMwTCVckKzn
    tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel='',img=tuPvBojUYhaJIpgyAxLlMwTCVckKrG,infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKrO,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKmi,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
   tuPvBojUYhaJIpgyAxLlMwTCVckKrO={'plot':'시청목록을 삭제합니다.'}
   tuPvBojUYhaJIpgyAxLlMwTCVckKme='*** 시청목록 삭제 ***'
   tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'mode':'MYVIEW_REMOVE','stype':tuPvBojUYhaJIpgyAxLlMwTCVckKmb}
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.add_dir(tuPvBojUYhaJIpgyAxLlMwTCVckKme,sublabel='',img='',infoLabels=tuPvBojUYhaJIpgyAxLlMwTCVckKrO,isFolder=tuPvBojUYhaJIpgyAxLlMwTCVckKzn,params=tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
   xbmcplugin.endOfDirectory(tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_handle,cacheToDisc=tuPvBojUYhaJIpgyAxLlMwTCVckKzn)
 def play_VIDEO(tuPvBojUYhaJIpgyAxLlMwTCVckKnS,tuPvBojUYhaJIpgyAxLlMwTCVckKrd):
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.SaveCredential(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_winCredential())
  tuPvBojUYhaJIpgyAxLlMwTCVckKdF =tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('mediacode')
  tuPvBojUYhaJIpgyAxLlMwTCVckKmb =tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('stype')
  tuPvBojUYhaJIpgyAxLlMwTCVckKdQ=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.get_selQuality(tuPvBojUYhaJIpgyAxLlMwTCVckKmb)
  tuPvBojUYhaJIpgyAxLlMwTCVckKdb,tuPvBojUYhaJIpgyAxLlMwTCVckKDn=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.TvingObj.GetBroadURL(tuPvBojUYhaJIpgyAxLlMwTCVckKdF,tuPvBojUYhaJIpgyAxLlMwTCVckKdQ,tuPvBojUYhaJIpgyAxLlMwTCVckKmb)
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.addon_log('qt, stype, url : %s - %s - %s'%(tuPvBojUYhaJIpgyAxLlMwTCVckKzD(tuPvBojUYhaJIpgyAxLlMwTCVckKdQ),tuPvBojUYhaJIpgyAxLlMwTCVckKmb,tuPvBojUYhaJIpgyAxLlMwTCVckKdb))
  if tuPvBojUYhaJIpgyAxLlMwTCVckKdb=='':
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.addon_noti(__language__(30908).encode('utf8'))
   return
  tuPvBojUYhaJIpgyAxLlMwTCVckKDm =tuPvBojUYhaJIpgyAxLlMwTCVckKdb.find('Policy=')
  if tuPvBojUYhaJIpgyAxLlMwTCVckKDm!=-1:
   tuPvBojUYhaJIpgyAxLlMwTCVckKDr =tuPvBojUYhaJIpgyAxLlMwTCVckKdb.split('?')[0]
   tuPvBojUYhaJIpgyAxLlMwTCVckKDd=tuPvBojUYhaJIpgyAxLlMwTCVckKzN(urllib.parse.parse_qsl(urllib.parse.urlsplit(tuPvBojUYhaJIpgyAxLlMwTCVckKdb).query))
   tuPvBojUYhaJIpgyAxLlMwTCVckKDd=urllib.parse.urlencode(tuPvBojUYhaJIpgyAxLlMwTCVckKDd)
   tuPvBojUYhaJIpgyAxLlMwTCVckKDd=tuPvBojUYhaJIpgyAxLlMwTCVckKDd.replace('&',';')
   tuPvBojUYhaJIpgyAxLlMwTCVckKDd=tuPvBojUYhaJIpgyAxLlMwTCVckKDd.replace('Policy','CloudFront-Policy')
   tuPvBojUYhaJIpgyAxLlMwTCVckKDd=tuPvBojUYhaJIpgyAxLlMwTCVckKDd.replace('Signature','CloudFront-Signature')
   tuPvBojUYhaJIpgyAxLlMwTCVckKDd=tuPvBojUYhaJIpgyAxLlMwTCVckKDd.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   tuPvBojUYhaJIpgyAxLlMwTCVckKDz='%s|Cookie=%s'%(tuPvBojUYhaJIpgyAxLlMwTCVckKDr,tuPvBojUYhaJIpgyAxLlMwTCVckKDd)
  else:
   tuPvBojUYhaJIpgyAxLlMwTCVckKDz=tuPvBojUYhaJIpgyAxLlMwTCVckKdb
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.addon_log(tuPvBojUYhaJIpgyAxLlMwTCVckKDz,tuPvBojUYhaJIpgyAxLlMwTCVckKzn)
  tuPvBojUYhaJIpgyAxLlMwTCVckKDe=xbmcgui.ListItem(path=tuPvBojUYhaJIpgyAxLlMwTCVckKDz)
  if tuPvBojUYhaJIpgyAxLlMwTCVckKDn!='':
   tuPvBojUYhaJIpgyAxLlMwTCVckKDN=tuPvBojUYhaJIpgyAxLlMwTCVckKDn
   tuPvBojUYhaJIpgyAxLlMwTCVckKDG ='https://cj.drmkeyserver.com/widevine_license'
   tuPvBojUYhaJIpgyAxLlMwTCVckKDW ='mpd'
   tuPvBojUYhaJIpgyAxLlMwTCVckKDS ='com.widevine.alpha'
   tuPvBojUYhaJIpgyAxLlMwTCVckKDO =inputstreamhelper.Helper(tuPvBojUYhaJIpgyAxLlMwTCVckKDW,drm='widevine')
   if tuPvBojUYhaJIpgyAxLlMwTCVckKDO.check_inputstream():
    tuPvBojUYhaJIpgyAxLlMwTCVckKDq={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%tuPvBojUYhaJIpgyAxLlMwTCVckKdF,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':tuPvBojUYhaJIpgyAxLlMwTCVckKnG,'AcquireLicenseAssertion':tuPvBojUYhaJIpgyAxLlMwTCVckKDN,'Host':'cj.drmkeyserver.com'}
    tuPvBojUYhaJIpgyAxLlMwTCVckKDi=tuPvBojUYhaJIpgyAxLlMwTCVckKDG+'|'+urllib.parse.urlencode(tuPvBojUYhaJIpgyAxLlMwTCVckKDq)+'|R{SSM}|'
    tuPvBojUYhaJIpgyAxLlMwTCVckKDe.setProperty('inputstream',tuPvBojUYhaJIpgyAxLlMwTCVckKDO.inputstream_addon)
    tuPvBojUYhaJIpgyAxLlMwTCVckKDe.setProperty('inputstream.adaptive.manifest_type',tuPvBojUYhaJIpgyAxLlMwTCVckKDW)
    tuPvBojUYhaJIpgyAxLlMwTCVckKDe.setProperty('inputstream.adaptive.license_type',tuPvBojUYhaJIpgyAxLlMwTCVckKDS)
    tuPvBojUYhaJIpgyAxLlMwTCVckKDe.setProperty('inputstream.adaptive.license_key',tuPvBojUYhaJIpgyAxLlMwTCVckKDi)
    tuPvBojUYhaJIpgyAxLlMwTCVckKDe.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(tuPvBojUYhaJIpgyAxLlMwTCVckKnG))
  xbmcplugin.setResolvedUrl(tuPvBojUYhaJIpgyAxLlMwTCVckKnS._addon_handle,tuPvBojUYhaJIpgyAxLlMwTCVckKzm,tuPvBojUYhaJIpgyAxLlMwTCVckKDe)
  try:
   if tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('mode')in['VOD','MOVIE']and tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('title'):
    tuPvBojUYhaJIpgyAxLlMwTCVckKmq={'code':tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('programcode')if tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('mode')=='VOD' else tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('mediacode'),'img':tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('thumbnail'),'title':tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('title'),'videoid':tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('mediacode')}
    tuPvBojUYhaJIpgyAxLlMwTCVckKnS.Save_Watched_List(tuPvBojUYhaJIpgyAxLlMwTCVckKrd.get('stype'),tuPvBojUYhaJIpgyAxLlMwTCVckKmq)
  except:
   tuPvBojUYhaJIpgyAxLlMwTCVckKDb
 def logout(tuPvBojUYhaJIpgyAxLlMwTCVckKnS):
  tuPvBojUYhaJIpgyAxLlMwTCVckKnX=xbmcgui.Dialog()
  tuPvBojUYhaJIpgyAxLlMwTCVckKmR=tuPvBojUYhaJIpgyAxLlMwTCVckKnX.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if tuPvBojUYhaJIpgyAxLlMwTCVckKmR==tuPvBojUYhaJIpgyAxLlMwTCVckKzn:sys.exit()
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.wininfo_clear()
  if os.path.isfile(tuPvBojUYhaJIpgyAxLlMwTCVckKnW):os.remove(tuPvBojUYhaJIpgyAxLlMwTCVckKnW)
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(tuPvBojUYhaJIpgyAxLlMwTCVckKnS):
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd=xbmcgui.Window(10000)
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd.setProperty('TVING_M_TOKEN','')
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd.setProperty('TVING_M_USERINFO','')
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd.setProperty('TVING_M_UUID','')
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd.setProperty('TVING_M_LOGINTIME','')
 def cookiefile_save(tuPvBojUYhaJIpgyAxLlMwTCVckKnS):
  tuPvBojUYhaJIpgyAxLlMwTCVckKDE =datetime.datetime.now()
  tuPvBojUYhaJIpgyAxLlMwTCVckKDX=tuPvBojUYhaJIpgyAxLlMwTCVckKDE+datetime.timedelta(days=tuPvBojUYhaJIpgyAxLlMwTCVckKzr(__addon__.getSetting('cache_ttl')))
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd=xbmcgui.Window(10000)
  tuPvBojUYhaJIpgyAxLlMwTCVckKDH={'tving_token':tuPvBojUYhaJIpgyAxLlMwTCVckKmd.getProperty('TVING_M_TOKEN'),'tving_userinfo':tuPvBojUYhaJIpgyAxLlMwTCVckKmd.getProperty('TVING_M_USERINFO'),'tving_uuid':tuPvBojUYhaJIpgyAxLlMwTCVckKmd.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_limitdate':tuPvBojUYhaJIpgyAxLlMwTCVckKDX.strftime('%Y-%m-%d')}
  try: 
   with tuPvBojUYhaJIpgyAxLlMwTCVckKze(tuPvBojUYhaJIpgyAxLlMwTCVckKnW,'w',-1,'utf-8')as fp:
    tuPvBojUYhaJIpgyAxLlMwTCVckKDf.dump(tuPvBojUYhaJIpgyAxLlMwTCVckKDH,fp)
  except tuPvBojUYhaJIpgyAxLlMwTCVckKzG as exception:
   tuPvBojUYhaJIpgyAxLlMwTCVckKzW(exception)
 def cookiefile_check(tuPvBojUYhaJIpgyAxLlMwTCVckKnS):
  tuPvBojUYhaJIpgyAxLlMwTCVckKDH={}
  try: 
   with tuPvBojUYhaJIpgyAxLlMwTCVckKze(tuPvBojUYhaJIpgyAxLlMwTCVckKnW,'r',-1,'utf-8')as fp:
    tuPvBojUYhaJIpgyAxLlMwTCVckKDH= tuPvBojUYhaJIpgyAxLlMwTCVckKDf.load(fp)
  except tuPvBojUYhaJIpgyAxLlMwTCVckKzG as exception:
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.wininfo_clear()
   return tuPvBojUYhaJIpgyAxLlMwTCVckKzn
  tuPvBojUYhaJIpgyAxLlMwTCVckKmX =__addon__.getSetting('id')
  tuPvBojUYhaJIpgyAxLlMwTCVckKmH =__addon__.getSetting('pw')
  tuPvBojUYhaJIpgyAxLlMwTCVckKDR=__addon__.getSetting('login_type')
  tuPvBojUYhaJIpgyAxLlMwTCVckKDH['tving_id']=base64.standard_b64decode(tuPvBojUYhaJIpgyAxLlMwTCVckKDH['tving_id']).decode('utf-8')
  tuPvBojUYhaJIpgyAxLlMwTCVckKDH['tving_pw']=base64.standard_b64decode(tuPvBojUYhaJIpgyAxLlMwTCVckKDH['tving_pw']).decode('utf-8')
  if tuPvBojUYhaJIpgyAxLlMwTCVckKmX!=tuPvBojUYhaJIpgyAxLlMwTCVckKDH['tving_id']or tuPvBojUYhaJIpgyAxLlMwTCVckKmH!=tuPvBojUYhaJIpgyAxLlMwTCVckKDH['tving_pw']or tuPvBojUYhaJIpgyAxLlMwTCVckKDR!=tuPvBojUYhaJIpgyAxLlMwTCVckKDH['tving_logintype']:
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.wininfo_clear()
   return tuPvBojUYhaJIpgyAxLlMwTCVckKzn
  tuPvBojUYhaJIpgyAxLlMwTCVckKms =tuPvBojUYhaJIpgyAxLlMwTCVckKzr(datetime.datetime.now().strftime('%Y%m%d'))
  tuPvBojUYhaJIpgyAxLlMwTCVckKDs=tuPvBojUYhaJIpgyAxLlMwTCVckKDH['tving_limitdate']
  tuPvBojUYhaJIpgyAxLlMwTCVckKmF =tuPvBojUYhaJIpgyAxLlMwTCVckKzr(re.sub('-','',tuPvBojUYhaJIpgyAxLlMwTCVckKDs))
  if tuPvBojUYhaJIpgyAxLlMwTCVckKmF<tuPvBojUYhaJIpgyAxLlMwTCVckKms:
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.wininfo_clear()
   return tuPvBojUYhaJIpgyAxLlMwTCVckKzn
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd=xbmcgui.Window(10000)
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd.setProperty('TVING_M_TOKEN',tuPvBojUYhaJIpgyAxLlMwTCVckKDH['tving_token'])
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd.setProperty('TVING_M_USERINFO',tuPvBojUYhaJIpgyAxLlMwTCVckKDH['tving_userinfo'])
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd.setProperty('TVING_M_UUID',tuPvBojUYhaJIpgyAxLlMwTCVckKDH['tving_uuid'])
  tuPvBojUYhaJIpgyAxLlMwTCVckKmd.setProperty('TVING_M_LOGINTIME',tuPvBojUYhaJIpgyAxLlMwTCVckKDs)
  return tuPvBojUYhaJIpgyAxLlMwTCVckKzm
 def tving_main(tuPvBojUYhaJIpgyAxLlMwTCVckKnS):
  tuPvBojUYhaJIpgyAxLlMwTCVckKDF=tuPvBojUYhaJIpgyAxLlMwTCVckKnS.main_params.get('mode',tuPvBojUYhaJIpgyAxLlMwTCVckKDb)
  tuPvBojUYhaJIpgyAxLlMwTCVckKnS.login_main()
  if tuPvBojUYhaJIpgyAxLlMwTCVckKDF is tuPvBojUYhaJIpgyAxLlMwTCVckKDb:
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.dp_Main_List()
  elif tuPvBojUYhaJIpgyAxLlMwTCVckKDF in['LIVE_GROUP','VOD_GROUP']:
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.dp_Title_Group(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.main_params)
  elif tuPvBojUYhaJIpgyAxLlMwTCVckKDF=='CHANNEL':
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.dp_LiveChannel_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.main_params)
  elif tuPvBojUYhaJIpgyAxLlMwTCVckKDF in['LIVE','VOD','MOVIE']:
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.play_VIDEO(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.main_params)
   time.sleep(0.1)
  elif tuPvBojUYhaJIpgyAxLlMwTCVckKDF=='PROGRAM':
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.dp_Program_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.main_params)
  elif tuPvBojUYhaJIpgyAxLlMwTCVckKDF=='EPISODE':
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.dp_Episode_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.main_params)
  elif tuPvBojUYhaJIpgyAxLlMwTCVckKDF=='MOVIE_GROUP':
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.dp_Movie_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.main_params)
  elif tuPvBojUYhaJIpgyAxLlMwTCVckKDF=='SEARCH_GROUP':
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.dp_Search_Group(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.main_params)
  elif tuPvBojUYhaJIpgyAxLlMwTCVckKDF=='SEARCH':
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.dp_Search_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.main_params)
  elif tuPvBojUYhaJIpgyAxLlMwTCVckKDF=='WATCH':
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.dp_Watch_List(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.main_params)
  elif tuPvBojUYhaJIpgyAxLlMwTCVckKDF=='MYVIEW_REMOVE':
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.dp_WatchList_Delete(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.main_params)
  elif tuPvBojUYhaJIpgyAxLlMwTCVckKDF=='ORDER_BY':
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.dp_setEpOrderby(tuPvBojUYhaJIpgyAxLlMwTCVckKnS.main_params)
  elif tuPvBojUYhaJIpgyAxLlMwTCVckKDF=='LOGOUT':
   tuPvBojUYhaJIpgyAxLlMwTCVckKnS.logout()
  else:
   tuPvBojUYhaJIpgyAxLlMwTCVckKDb
# Created by pyminifier (https://github.com/liftoff/pyminifier)
