__author__="NightRain"
SWzNtTXEGyxahijdOMPgbJpRVQBYmw=object
SWzNtTXEGyxahijdOMPgbJpRVQBYme=None
SWzNtTXEGyxahijdOMPgbJpRVQBYmr=False
SWzNtTXEGyxahijdOMPgbJpRVQBYmA=int
SWzNtTXEGyxahijdOMPgbJpRVQBYuc=True
SWzNtTXEGyxahijdOMPgbJpRVQBYuK=Exception
SWzNtTXEGyxahijdOMPgbJpRVQBYuF=print
SWzNtTXEGyxahijdOMPgbJpRVQBYum=str
SWzNtTXEGyxahijdOMPgbJpRVQBYuf=list
SWzNtTXEGyxahijdOMPgbJpRVQBYuo=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
SWzNtTXEGyxahijdOMPgbJpRVQBYcF ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36'
SWzNtTXEGyxahijdOMPgbJpRVQBYcm={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
class SWzNtTXEGyxahijdOMPgbJpRVQBYcK(SWzNtTXEGyxahijdOMPgbJpRVQBYmw):
 def __init__(SWzNtTXEGyxahijdOMPgbJpRVQBYcu):
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.TVING_TOKEN =''
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.POC_USERINFO =''
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.TVING_UUID ='-'
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.NETWORKCODE ='CSND0900'
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.OSCODE ='CSOD0900' 
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.TELECODE ='CSCD0900'
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.SCREENCODE ='CSSD0100'
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.LIVE_LIMIT =23
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.VOD_LIMIT =20
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.EPISODE_LIMIT=30 
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.SEARCH_LIMIT =80 
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.MOVIE_LIMIT =18
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.API_DOMAIN ='https://api.tving.com'
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN ='https://image.tving.com'
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.SEARCH_DOMAIN='https://search.tving.com'
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.LOGIN_DOMAIN ='https://user.tving.com'
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.URL_DOMAIN ='https://www.tving.com'
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.MOVIE_LITE ='338723'
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.MOVIE_PREMIUM='1513561'
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.DEFAULT_HEADER={'user-agent':SWzNtTXEGyxahijdOMPgbJpRVQBYcF}
 def callRequestCookies(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,jobtype,SWzNtTXEGyxahijdOMPgbJpRVQBYcD,payload=SWzNtTXEGyxahijdOMPgbJpRVQBYme,params=SWzNtTXEGyxahijdOMPgbJpRVQBYme,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYme,cookies=SWzNtTXEGyxahijdOMPgbJpRVQBYme,redirects=SWzNtTXEGyxahijdOMPgbJpRVQBYmr):
  SWzNtTXEGyxahijdOMPgbJpRVQBYcf=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.DEFAULT_HEADER
  if headers:SWzNtTXEGyxahijdOMPgbJpRVQBYcf.update(headers)
  if jobtype=='Get':
   SWzNtTXEGyxahijdOMPgbJpRVQBYco=requests.get(SWzNtTXEGyxahijdOMPgbJpRVQBYcD,params=params,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYcf,cookies=cookies,allow_redirects=redirects)
  else:
   SWzNtTXEGyxahijdOMPgbJpRVQBYco=requests.post(SWzNtTXEGyxahijdOMPgbJpRVQBYcD,data=payload,params=params,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYcf,cookies=cookies,allow_redirects=redirects)
  return SWzNtTXEGyxahijdOMPgbJpRVQBYco
 def makeDefaultCookies(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,vToken=SWzNtTXEGyxahijdOMPgbJpRVQBYme,vUserinfo=SWzNtTXEGyxahijdOMPgbJpRVQBYme):
  SWzNtTXEGyxahijdOMPgbJpRVQBYcl={}
  SWzNtTXEGyxahijdOMPgbJpRVQBYcl['_tving_token']=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.TVING_TOKEN if vToken==SWzNtTXEGyxahijdOMPgbJpRVQBYme else vToken
  SWzNtTXEGyxahijdOMPgbJpRVQBYcl['POC_USERINFO']=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.POC_USERINFO if vToken==SWzNtTXEGyxahijdOMPgbJpRVQBYme else vUserinfo
  return SWzNtTXEGyxahijdOMPgbJpRVQBYcl
 def getDeviceStr(SWzNtTXEGyxahijdOMPgbJpRVQBYcu):
  SWzNtTXEGyxahijdOMPgbJpRVQBYcU=[]
  SWzNtTXEGyxahijdOMPgbJpRVQBYcU.append('Windows') 
  SWzNtTXEGyxahijdOMPgbJpRVQBYcU.append('Chrome') 
  SWzNtTXEGyxahijdOMPgbJpRVQBYcU.append('ko-KR') 
  SWzNtTXEGyxahijdOMPgbJpRVQBYcU.append('undefined') 
  SWzNtTXEGyxahijdOMPgbJpRVQBYcU.append('24') 
  SWzNtTXEGyxahijdOMPgbJpRVQBYcU.append(u'한국 표준시')
  SWzNtTXEGyxahijdOMPgbJpRVQBYcU.append('undefined') 
  SWzNtTXEGyxahijdOMPgbJpRVQBYcU.append('undefined') 
  SWzNtTXEGyxahijdOMPgbJpRVQBYcU.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  SWzNtTXEGyxahijdOMPgbJpRVQBYcs=''
  for SWzNtTXEGyxahijdOMPgbJpRVQBYck in SWzNtTXEGyxahijdOMPgbJpRVQBYcU:
   SWzNtTXEGyxahijdOMPgbJpRVQBYcs+=SWzNtTXEGyxahijdOMPgbJpRVQBYck+'|'
  return SWzNtTXEGyxahijdOMPgbJpRVQBYcs
 def SaveCredential(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,SWzNtTXEGyxahijdOMPgbJpRVQBYcn):
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.TVING_TOKEN =SWzNtTXEGyxahijdOMPgbJpRVQBYcn.get('tving_token')
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.POC_USERINFO=SWzNtTXEGyxahijdOMPgbJpRVQBYcn.get('poc_userinfo')
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.TVING_UUID =SWzNtTXEGyxahijdOMPgbJpRVQBYcn.get('tving_uuid')
 def LoadCredential(SWzNtTXEGyxahijdOMPgbJpRVQBYcu):
  SWzNtTXEGyxahijdOMPgbJpRVQBYcn={'tving_token':SWzNtTXEGyxahijdOMPgbJpRVQBYcu.TVING_TOKEN,'poc_userinfo':SWzNtTXEGyxahijdOMPgbJpRVQBYcu.POC_USERINFO,'tving_uuid':SWzNtTXEGyxahijdOMPgbJpRVQBYcu.TVING_UUID}
  return SWzNtTXEGyxahijdOMPgbJpRVQBYcn
 def GetDefaultParams(SWzNtTXEGyxahijdOMPgbJpRVQBYcu):
  SWzNtTXEGyxahijdOMPgbJpRVQBYcC={'apiKey':SWzNtTXEGyxahijdOMPgbJpRVQBYcu.APIKEY,'networkCode':SWzNtTXEGyxahijdOMPgbJpRVQBYcu.NETWORKCODE,'osCode':SWzNtTXEGyxahijdOMPgbJpRVQBYcu.OSCODE,'teleCode':SWzNtTXEGyxahijdOMPgbJpRVQBYcu.TELECODE,'screenCode':SWzNtTXEGyxahijdOMPgbJpRVQBYcu.SCREENCODE}
  return SWzNtTXEGyxahijdOMPgbJpRVQBYcC
 def GetNoCache(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,timetype=1):
  if timetype==1:
   return SWzNtTXEGyxahijdOMPgbJpRVQBYmA(time.time())
  else:
   return SWzNtTXEGyxahijdOMPgbJpRVQBYmA(time.time()*1000)
 def makeurl(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,domain,path,query1=SWzNtTXEGyxahijdOMPgbJpRVQBYme,query2=SWzNtTXEGyxahijdOMPgbJpRVQBYme):
  SWzNtTXEGyxahijdOMPgbJpRVQBYcD=domain+path
  if query1:
   SWzNtTXEGyxahijdOMPgbJpRVQBYcD+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   SWzNtTXEGyxahijdOMPgbJpRVQBYcD+='&%s'%urllib.parse.urlencode(query2)
  return SWzNtTXEGyxahijdOMPgbJpRVQBYcD
 def GetCredential(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,user_id,user_pw,login_type):
  SWzNtTXEGyxahijdOMPgbJpRVQBYcv=SWzNtTXEGyxahijdOMPgbJpRVQBYmr
  SWzNtTXEGyxahijdOMPgbJpRVQBYcq=SWzNtTXEGyxahijdOMPgbJpRVQBYKc='' 
  SWzNtTXEGyxahijdOMPgbJpRVQBYcI='-'
  try:
   SWzNtTXEGyxahijdOMPgbJpRVQBYcw=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   SWzNtTXEGyxahijdOMPgbJpRVQBYce={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'','csite':''}
   SWzNtTXEGyxahijdOMPgbJpRVQBYcr=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.callRequestCookies('Post',SWzNtTXEGyxahijdOMPgbJpRVQBYcw,payload=SWzNtTXEGyxahijdOMPgbJpRVQBYce,params=SWzNtTXEGyxahijdOMPgbJpRVQBYme,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYme,cookies=SWzNtTXEGyxahijdOMPgbJpRVQBYme)
   for SWzNtTXEGyxahijdOMPgbJpRVQBYcA in SWzNtTXEGyxahijdOMPgbJpRVQBYcr.cookies:
    if SWzNtTXEGyxahijdOMPgbJpRVQBYcA.name=='_tving_token':
     SWzNtTXEGyxahijdOMPgbJpRVQBYcq=SWzNtTXEGyxahijdOMPgbJpRVQBYcA.value
    elif SWzNtTXEGyxahijdOMPgbJpRVQBYcA.name=='POC_USERINFO':
     SWzNtTXEGyxahijdOMPgbJpRVQBYKc=SWzNtTXEGyxahijdOMPgbJpRVQBYcA.value
   if SWzNtTXEGyxahijdOMPgbJpRVQBYcq:SWzNtTXEGyxahijdOMPgbJpRVQBYcv=SWzNtTXEGyxahijdOMPgbJpRVQBYuc
   SWzNtTXEGyxahijdOMPgbJpRVQBYcI=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetDeviceList(SWzNtTXEGyxahijdOMPgbJpRVQBYcq,SWzNtTXEGyxahijdOMPgbJpRVQBYKc)
  except SWzNtTXEGyxahijdOMPgbJpRVQBYuK as exception:
   SWzNtTXEGyxahijdOMPgbJpRVQBYcq=SWzNtTXEGyxahijdOMPgbJpRVQBYKc='' 
   SWzNtTXEGyxahijdOMPgbJpRVQBYcI='-'
   SWzNtTXEGyxahijdOMPgbJpRVQBYuF(exception)
  SWzNtTXEGyxahijdOMPgbJpRVQBYcn={'tving_token':SWzNtTXEGyxahijdOMPgbJpRVQBYcq,'poc_userinfo':SWzNtTXEGyxahijdOMPgbJpRVQBYKc,'tving_uuid':SWzNtTXEGyxahijdOMPgbJpRVQBYcI}
  SWzNtTXEGyxahijdOMPgbJpRVQBYcu.SaveCredential(SWzNtTXEGyxahijdOMPgbJpRVQBYcn)
  return SWzNtTXEGyxahijdOMPgbJpRVQBYcv
 def GetBroadURL(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,mediacode,sel_quality,stype):
  SWzNtTXEGyxahijdOMPgbJpRVQBYKF=''
  SWzNtTXEGyxahijdOMPgbJpRVQBYKm=''
  SWzNtTXEGyxahijdOMPgbJpRVQBYKu=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.TVING_UUID 
  try:
   if stype!='tvingtv':
    SWzNtTXEGyxahijdOMPgbJpRVQBYKf ='/v2/media/stream/info'
    SWzNtTXEGyxahijdOMPgbJpRVQBYKo=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetDefaultParams()
    SWzNtTXEGyxahijdOMPgbJpRVQBYKl={'info':'Y','mediaCode':mediacode,'noCache':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetNoCache(1)),'callingFrom':'HTML5','adReq':'none','ooc':'','deviceId':SWzNtTXEGyxahijdOMPgbJpRVQBYKu,'wm':'Y'}
    SWzNtTXEGyxahijdOMPgbJpRVQBYKo.update(SWzNtTXEGyxahijdOMPgbJpRVQBYKl)
    SWzNtTXEGyxahijdOMPgbJpRVQBYcD=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeurl(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.API_DOMAIN,SWzNtTXEGyxahijdOMPgbJpRVQBYKf)
    SWzNtTXEGyxahijdOMPgbJpRVQBYcl=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeDefaultCookies()
    SWzNtTXEGyxahijdOMPgbJpRVQBYcr=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.callRequestCookies('Get',SWzNtTXEGyxahijdOMPgbJpRVQBYcD,payload=SWzNtTXEGyxahijdOMPgbJpRVQBYme,params=SWzNtTXEGyxahijdOMPgbJpRVQBYKo,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYme,cookies=SWzNtTXEGyxahijdOMPgbJpRVQBYcl)
    SWzNtTXEGyxahijdOMPgbJpRVQBYKU=json.loads(SWzNtTXEGyxahijdOMPgbJpRVQBYcr.text)
    if not('stream' in SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']):return SWzNtTXEGyxahijdOMPgbJpRVQBYKF,SWzNtTXEGyxahijdOMPgbJpRVQBYKm 
    SWzNtTXEGyxahijdOMPgbJpRVQBYKs=SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']['stream']
    if 'drm_license_assertion' in SWzNtTXEGyxahijdOMPgbJpRVQBYKs:
     SWzNtTXEGyxahijdOMPgbJpRVQBYKm=SWzNtTXEGyxahijdOMPgbJpRVQBYKs['drm_license_assertion']
    SWzNtTXEGyxahijdOMPgbJpRVQBYKk=SWzNtTXEGyxahijdOMPgbJpRVQBYKs['quality']
    SWzNtTXEGyxahijdOMPgbJpRVQBYKn=[]
    for SWzNtTXEGyxahijdOMPgbJpRVQBYKC in SWzNtTXEGyxahijdOMPgbJpRVQBYKk:
     if SWzNtTXEGyxahijdOMPgbJpRVQBYKC['active']=='Y':
      SWzNtTXEGyxahijdOMPgbJpRVQBYKn.append({SWzNtTXEGyxahijdOMPgbJpRVQBYcm.get(SWzNtTXEGyxahijdOMPgbJpRVQBYKC['code']):SWzNtTXEGyxahijdOMPgbJpRVQBYKC['code']})
    SWzNtTXEGyxahijdOMPgbJpRVQBYKD=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.CheckQuality(sel_quality,SWzNtTXEGyxahijdOMPgbJpRVQBYKn)
   else:
    for SWzNtTXEGyxahijdOMPgbJpRVQBYKL,SWzNtTXEGyxahijdOMPgbJpRVQBYKA in SWzNtTXEGyxahijdOMPgbJpRVQBYcm.items():
     if SWzNtTXEGyxahijdOMPgbJpRVQBYKA==sel_quality:
      SWzNtTXEGyxahijdOMPgbJpRVQBYKD=SWzNtTXEGyxahijdOMPgbJpRVQBYKL
  except SWzNtTXEGyxahijdOMPgbJpRVQBYuK as exception:
   SWzNtTXEGyxahijdOMPgbJpRVQBYuF(exception)
   for SWzNtTXEGyxahijdOMPgbJpRVQBYKL,SWzNtTXEGyxahijdOMPgbJpRVQBYKA in SWzNtTXEGyxahijdOMPgbJpRVQBYcm.items():
    if SWzNtTXEGyxahijdOMPgbJpRVQBYKA==sel_quality:
     SWzNtTXEGyxahijdOMPgbJpRVQBYKD=SWzNtTXEGyxahijdOMPgbJpRVQBYKL
   return SWzNtTXEGyxahijdOMPgbJpRVQBYKF,SWzNtTXEGyxahijdOMPgbJpRVQBYKm
  try:
   SWzNtTXEGyxahijdOMPgbJpRVQBYKf ='/streaming/info'
   SWzNtTXEGyxahijdOMPgbJpRVQBYKo=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetDefaultParams()
   if stype=='onair':SWzNtTXEGyxahijdOMPgbJpRVQBYKo['osCode']='CSOD0400' 
   SWzNtTXEGyxahijdOMPgbJpRVQBYKH={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2158.7350000045262','returnValue':'true','cancelBubble':'false'}
   SWzNtTXEGyxahijdOMPgbJpRVQBYKv=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeOocUrl(SWzNtTXEGyxahijdOMPgbJpRVQBYKH)
   SWzNtTXEGyxahijdOMPgbJpRVQBYKq=urllib.parse.quote(SWzNtTXEGyxahijdOMPgbJpRVQBYKv)
   SWzNtTXEGyxahijdOMPgbJpRVQBYKl={'info':'Y','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':SWzNtTXEGyxahijdOMPgbJpRVQBYKD,'adReq':'none','ooc':SWzNtTXEGyxahijdOMPgbJpRVQBYKv,'deviceId':SWzNtTXEGyxahijdOMPgbJpRVQBYKu}
   SWzNtTXEGyxahijdOMPgbJpRVQBYKI =SWzNtTXEGyxahijdOMPgbJpRVQBYKo
   SWzNtTXEGyxahijdOMPgbJpRVQBYKI.update(SWzNtTXEGyxahijdOMPgbJpRVQBYKl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcD=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.URL_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYKf
   SWzNtTXEGyxahijdOMPgbJpRVQBYKw={'origin':'https://www.tving.com','Referer':'https://www.tving.com/vod/player/'+mediacode}
   SWzNtTXEGyxahijdOMPgbJpRVQBYcl=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeDefaultCookies()
   SWzNtTXEGyxahijdOMPgbJpRVQBYcl['onClickEvent2']=SWzNtTXEGyxahijdOMPgbJpRVQBYKq
   SWzNtTXEGyxahijdOMPgbJpRVQBYcr=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.callRequestCookies('Post',SWzNtTXEGyxahijdOMPgbJpRVQBYcD,payload=SWzNtTXEGyxahijdOMPgbJpRVQBYKI,params=SWzNtTXEGyxahijdOMPgbJpRVQBYme,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYKw,cookies=SWzNtTXEGyxahijdOMPgbJpRVQBYcl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYKU=json.loads(SWzNtTXEGyxahijdOMPgbJpRVQBYcr.text)
   if SWzNtTXEGyxahijdOMPgbJpRVQBYKm!='':
    SWzNtTXEGyxahijdOMPgbJpRVQBYKm =SWzNtTXEGyxahijdOMPgbJpRVQBYKU['stream']['drm_license_assertion']
    SWzNtTXEGyxahijdOMPgbJpRVQBYKF=SWzNtTXEGyxahijdOMPgbJpRVQBYKU['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in SWzNtTXEGyxahijdOMPgbJpRVQBYKU['stream']['broadcast']):return SWzNtTXEGyxahijdOMPgbJpRVQBYKF,SWzNtTXEGyxahijdOMPgbJpRVQBYKm
    SWzNtTXEGyxahijdOMPgbJpRVQBYKF=SWzNtTXEGyxahijdOMPgbJpRVQBYKU['stream']['broadcast']['broad_url']
  except SWzNtTXEGyxahijdOMPgbJpRVQBYuK as exception:
   SWzNtTXEGyxahijdOMPgbJpRVQBYuF(exception)
  return SWzNtTXEGyxahijdOMPgbJpRVQBYKF,SWzNtTXEGyxahijdOMPgbJpRVQBYKm
 def CheckQuality(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,sel_qt,SWzNtTXEGyxahijdOMPgbJpRVQBYKn):
  for SWzNtTXEGyxahijdOMPgbJpRVQBYKe in SWzNtTXEGyxahijdOMPgbJpRVQBYKn:
   if sel_qt>=SWzNtTXEGyxahijdOMPgbJpRVQBYuf(SWzNtTXEGyxahijdOMPgbJpRVQBYKe)[0]:return SWzNtTXEGyxahijdOMPgbJpRVQBYKe.get(SWzNtTXEGyxahijdOMPgbJpRVQBYuf(SWzNtTXEGyxahijdOMPgbJpRVQBYKe)[0])
   SWzNtTXEGyxahijdOMPgbJpRVQBYKr=SWzNtTXEGyxahijdOMPgbJpRVQBYKe.get(SWzNtTXEGyxahijdOMPgbJpRVQBYuf(SWzNtTXEGyxahijdOMPgbJpRVQBYKe)[0])
  return SWzNtTXEGyxahijdOMPgbJpRVQBYKr
 def makeOocUrl(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,SWzNtTXEGyxahijdOMPgbJpRVQBYKH):
  SWzNtTXEGyxahijdOMPgbJpRVQBYcD=''
  for SWzNtTXEGyxahijdOMPgbJpRVQBYKL,SWzNtTXEGyxahijdOMPgbJpRVQBYKA in SWzNtTXEGyxahijdOMPgbJpRVQBYKH.items():
   SWzNtTXEGyxahijdOMPgbJpRVQBYcD+="%s=%s^"%(SWzNtTXEGyxahijdOMPgbJpRVQBYKL,SWzNtTXEGyxahijdOMPgbJpRVQBYKA)
  return SWzNtTXEGyxahijdOMPgbJpRVQBYcD
 def GetLiveChannelList(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,stype,page_int):
  SWzNtTXEGyxahijdOMPgbJpRVQBYFc=[]
  SWzNtTXEGyxahijdOMPgbJpRVQBYFK=SWzNtTXEGyxahijdOMPgbJpRVQBYmr
  try:
   SWzNtTXEGyxahijdOMPgbJpRVQBYKf ='/v2/media/lives'
   if stype=='onair':
    SWzNtTXEGyxahijdOMPgbJpRVQBYFm='CPCS0100,CPCS0400'
   else:
    SWzNtTXEGyxahijdOMPgbJpRVQBYFm='CPCS0300'
   SWzNtTXEGyxahijdOMPgbJpRVQBYKo=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetDefaultParams()
   SWzNtTXEGyxahijdOMPgbJpRVQBYKl={'pageNo':SWzNtTXEGyxahijdOMPgbJpRVQBYum(page_int),'pageSize':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':SWzNtTXEGyxahijdOMPgbJpRVQBYFm,'_':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetNoCache(2))}
   SWzNtTXEGyxahijdOMPgbJpRVQBYKo.update(SWzNtTXEGyxahijdOMPgbJpRVQBYKl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcD=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeurl(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.API_DOMAIN,SWzNtTXEGyxahijdOMPgbJpRVQBYKf)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcl=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeDefaultCookies()
   SWzNtTXEGyxahijdOMPgbJpRVQBYcr=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.callRequestCookies('Get',SWzNtTXEGyxahijdOMPgbJpRVQBYcD,payload=SWzNtTXEGyxahijdOMPgbJpRVQBYme,params=SWzNtTXEGyxahijdOMPgbJpRVQBYKo,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYme,cookies=SWzNtTXEGyxahijdOMPgbJpRVQBYcl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYKU=json.loads(SWzNtTXEGyxahijdOMPgbJpRVQBYcr.text)
   if not('result' in SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']):return SWzNtTXEGyxahijdOMPgbJpRVQBYFc,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
   SWzNtTXEGyxahijdOMPgbJpRVQBYFu=SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']['result']
   for SWzNtTXEGyxahijdOMPgbJpRVQBYKC in SWzNtTXEGyxahijdOMPgbJpRVQBYFu:
    SWzNtTXEGyxahijdOMPgbJpRVQBYFf={}
    SWzNtTXEGyxahijdOMPgbJpRVQBYFf['mediatype']='video'
    SWzNtTXEGyxahijdOMPgbJpRVQBYFo=SWzNtTXEGyxahijdOMPgbJpRVQBYFs=SWzNtTXEGyxahijdOMPgbJpRVQBYFk=SWzNtTXEGyxahijdOMPgbJpRVQBYFn=''
    SWzNtTXEGyxahijdOMPgbJpRVQBYFl=SWzNtTXEGyxahijdOMPgbJpRVQBYFH=''
    SWzNtTXEGyxahijdOMPgbJpRVQBYFU=SWzNtTXEGyxahijdOMPgbJpRVQBYKC['live_code']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFo =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['channel']['name']['ko']
    if SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['episode']!=SWzNtTXEGyxahijdOMPgbJpRVQBYme:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFs =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['program']['name']['ko']
     SWzNtTXEGyxahijdOMPgbJpRVQBYFs =SWzNtTXEGyxahijdOMPgbJpRVQBYFs+', '+SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['episode']['frequency'])+'회'
     if SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['episode']['image']!=[]:
      SWzNtTXEGyxahijdOMPgbJpRVQBYFk=SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['episode']['image'][0]['url']
     SWzNtTXEGyxahijdOMPgbJpRVQBYFn=SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['episode']['synopsis']['ko']
    else:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFs =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['program']['name']['ko']
     if SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['program']['image']!=[]:
      SWzNtTXEGyxahijdOMPgbJpRVQBYFk=SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['program']['image'][0]['url']
     SWzNtTXEGyxahijdOMPgbJpRVQBYFn=SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['program']['synopsis']['ko']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFf['title'] =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['program']['name']['ko']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFf['studio'] =SWzNtTXEGyxahijdOMPgbJpRVQBYFo
    try:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFC=[]
     for SWzNtTXEGyxahijdOMPgbJpRVQBYFD in SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('schedule').get('program').get('actor'):SWzNtTXEGyxahijdOMPgbJpRVQBYFC.append(SWzNtTXEGyxahijdOMPgbJpRVQBYFD)
     if SWzNtTXEGyxahijdOMPgbJpRVQBYFC[0]!='' and SWzNtTXEGyxahijdOMPgbJpRVQBYFC[0]!=u'없음':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['cast']=SWzNtTXEGyxahijdOMPgbJpRVQBYFC
    except:
     SWzNtTXEGyxahijdOMPgbJpRVQBYme
    try:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFL=[]
     if SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('schedule').get('program').get('category1_name').get('ko')!='':
      SWzNtTXEGyxahijdOMPgbJpRVQBYFL.append(SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['program']['category1_name']['ko'])
     if SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('schedule').get('program').get('category2_name').get('ko')!='':
      SWzNtTXEGyxahijdOMPgbJpRVQBYFL.append(SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['program']['category2_name']['ko'])
     if SWzNtTXEGyxahijdOMPgbJpRVQBYFL[0]!='':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['genre']=SWzNtTXEGyxahijdOMPgbJpRVQBYFL
    except:
     SWzNtTXEGyxahijdOMPgbJpRVQBYme
    if SWzNtTXEGyxahijdOMPgbJpRVQBYFk=='':
     SWzNtTXEGyxahijdOMPgbJpRVQBYFk=SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['channel']['image'][0]['url']
    if SWzNtTXEGyxahijdOMPgbJpRVQBYFk!='':SWzNtTXEGyxahijdOMPgbJpRVQBYFk=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYFk
    SWzNtTXEGyxahijdOMPgbJpRVQBYFl=SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['broadcast_start_time'])[8:12]
    SWzNtTXEGyxahijdOMPgbJpRVQBYFH =SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYKC['schedule']['broadcast_end_time'])[8:12]
    SWzNtTXEGyxahijdOMPgbJpRVQBYFv={'channel':SWzNtTXEGyxahijdOMPgbJpRVQBYFo,'title':SWzNtTXEGyxahijdOMPgbJpRVQBYFs,'mediacode':SWzNtTXEGyxahijdOMPgbJpRVQBYFU,'thumbnail':SWzNtTXEGyxahijdOMPgbJpRVQBYFk,'synopsis':SWzNtTXEGyxahijdOMPgbJpRVQBYFn,'channelepg':' [%s:%s ~ %s:%s]'%(SWzNtTXEGyxahijdOMPgbJpRVQBYFl[0:2],SWzNtTXEGyxahijdOMPgbJpRVQBYFl[2:],SWzNtTXEGyxahijdOMPgbJpRVQBYFH[0:2],SWzNtTXEGyxahijdOMPgbJpRVQBYFH[2:]),'info':SWzNtTXEGyxahijdOMPgbJpRVQBYFf}
    SWzNtTXEGyxahijdOMPgbJpRVQBYFc.append(SWzNtTXEGyxahijdOMPgbJpRVQBYFv)
   if SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']['has_more']=='Y':SWzNtTXEGyxahijdOMPgbJpRVQBYFK=SWzNtTXEGyxahijdOMPgbJpRVQBYuc
  except SWzNtTXEGyxahijdOMPgbJpRVQBYuK as exception:
   SWzNtTXEGyxahijdOMPgbJpRVQBYuF(exception)
  return SWzNtTXEGyxahijdOMPgbJpRVQBYFc,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
 def GetProgramList(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,stype,orderby,page_int,landyn=SWzNtTXEGyxahijdOMPgbJpRVQBYmr):
  SWzNtTXEGyxahijdOMPgbJpRVQBYFc=[]
  SWzNtTXEGyxahijdOMPgbJpRVQBYFK=SWzNtTXEGyxahijdOMPgbJpRVQBYmr
  try:
   SWzNtTXEGyxahijdOMPgbJpRVQBYKf ='/v2/media/episodes'
   SWzNtTXEGyxahijdOMPgbJpRVQBYKo=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetDefaultParams()
   SWzNtTXEGyxahijdOMPgbJpRVQBYKl={'pageNo':SWzNtTXEGyxahijdOMPgbJpRVQBYum(page_int),'pageSize':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetNoCache(2))}
   if stype!='all':SWzNtTXEGyxahijdOMPgbJpRVQBYKl['multiCategoryCode']=stype
   SWzNtTXEGyxahijdOMPgbJpRVQBYKo.update(SWzNtTXEGyxahijdOMPgbJpRVQBYKl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcD=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeurl(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.API_DOMAIN,SWzNtTXEGyxahijdOMPgbJpRVQBYKf)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcl=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeDefaultCookies()
   SWzNtTXEGyxahijdOMPgbJpRVQBYcr=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.callRequestCookies('Get',SWzNtTXEGyxahijdOMPgbJpRVQBYcD,payload=SWzNtTXEGyxahijdOMPgbJpRVQBYme,params=SWzNtTXEGyxahijdOMPgbJpRVQBYKo,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYme,cookies=SWzNtTXEGyxahijdOMPgbJpRVQBYcl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYKU=json.loads(SWzNtTXEGyxahijdOMPgbJpRVQBYcr.text)
   if not('result' in SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']):return SWzNtTXEGyxahijdOMPgbJpRVQBYFc,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
   SWzNtTXEGyxahijdOMPgbJpRVQBYFu=SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']['result']
   for SWzNtTXEGyxahijdOMPgbJpRVQBYKC in SWzNtTXEGyxahijdOMPgbJpRVQBYFu:
    SWzNtTXEGyxahijdOMPgbJpRVQBYFq=SWzNtTXEGyxahijdOMPgbJpRVQBYKC['program']['code']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFs =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['program']['name']['ko']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFk =SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYKC['program']['image'][0]['url']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFI='CAIP0200' if landyn else 'CAIP0900' 
    for SWzNtTXEGyxahijdOMPgbJpRVQBYFw in SWzNtTXEGyxahijdOMPgbJpRVQBYKC['program']['image']:
     if SWzNtTXEGyxahijdOMPgbJpRVQBYFw['code']==SWzNtTXEGyxahijdOMPgbJpRVQBYFI:
      SWzNtTXEGyxahijdOMPgbJpRVQBYFk =SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYFw['url']
      break
    SWzNtTXEGyxahijdOMPgbJpRVQBYFn =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['program']['synopsis']['ko']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFe=SWzNtTXEGyxahijdOMPgbJpRVQBYKC['program']['channel_code']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFf={}
    SWzNtTXEGyxahijdOMPgbJpRVQBYFf['title'] =SWzNtTXEGyxahijdOMPgbJpRVQBYFs 
    SWzNtTXEGyxahijdOMPgbJpRVQBYFf['mediatype']='episode' 
    try:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFC=[]
     for SWzNtTXEGyxahijdOMPgbJpRVQBYFD in SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('program').get('actor'):SWzNtTXEGyxahijdOMPgbJpRVQBYFC.append(SWzNtTXEGyxahijdOMPgbJpRVQBYFD)
     if SWzNtTXEGyxahijdOMPgbJpRVQBYFC[0]!='' and SWzNtTXEGyxahijdOMPgbJpRVQBYFC[0]!='-':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['cast']=SWzNtTXEGyxahijdOMPgbJpRVQBYFC
    except:
     SWzNtTXEGyxahijdOMPgbJpRVQBYme
    try:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFr=[]
     for SWzNtTXEGyxahijdOMPgbJpRVQBYFA in SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('program').get('director'):SWzNtTXEGyxahijdOMPgbJpRVQBYFr.append(SWzNtTXEGyxahijdOMPgbJpRVQBYFA)
     if SWzNtTXEGyxahijdOMPgbJpRVQBYFr[0]!='' and SWzNtTXEGyxahijdOMPgbJpRVQBYFr[0]!='-':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['director']=SWzNtTXEGyxahijdOMPgbJpRVQBYFr
    except:
     SWzNtTXEGyxahijdOMPgbJpRVQBYme
    SWzNtTXEGyxahijdOMPgbJpRVQBYFL=[]
    if SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('program').get('category1_name').get('ko')!='':
     SWzNtTXEGyxahijdOMPgbJpRVQBYFL.append(SWzNtTXEGyxahijdOMPgbJpRVQBYKC['program']['category1_name']['ko'])
    if SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('program').get('category2_name').get('ko')!='':
     SWzNtTXEGyxahijdOMPgbJpRVQBYFL.append(SWzNtTXEGyxahijdOMPgbJpRVQBYKC['program']['category2_name']['ko'])
    if SWzNtTXEGyxahijdOMPgbJpRVQBYFL[0]!='':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['genre']=SWzNtTXEGyxahijdOMPgbJpRVQBYFL
    try:
     if SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('program').get('product_year'):SWzNtTXEGyxahijdOMPgbJpRVQBYFf['year']=SWzNtTXEGyxahijdOMPgbJpRVQBYKC['program']['product_year']
     if 'broad_dt' in SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('program'):
      SWzNtTXEGyxahijdOMPgbJpRVQBYmc=SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('program').get('broad_dt')
      SWzNtTXEGyxahijdOMPgbJpRVQBYFf['aired']='%s-%s-%s'%(SWzNtTXEGyxahijdOMPgbJpRVQBYmc[:4],SWzNtTXEGyxahijdOMPgbJpRVQBYmc[4:6],SWzNtTXEGyxahijdOMPgbJpRVQBYmc[6:])
    except:
     SWzNtTXEGyxahijdOMPgbJpRVQBYme
    SWzNtTXEGyxahijdOMPgbJpRVQBYFv={'program':SWzNtTXEGyxahijdOMPgbJpRVQBYFq,'title':SWzNtTXEGyxahijdOMPgbJpRVQBYFs,'thumbnail':SWzNtTXEGyxahijdOMPgbJpRVQBYFk,'synopsis':SWzNtTXEGyxahijdOMPgbJpRVQBYFn,'channel':SWzNtTXEGyxahijdOMPgbJpRVQBYFe,'info':SWzNtTXEGyxahijdOMPgbJpRVQBYFf}
    SWzNtTXEGyxahijdOMPgbJpRVQBYFc.append(SWzNtTXEGyxahijdOMPgbJpRVQBYFv)
   if SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']['has_more']=='Y':SWzNtTXEGyxahijdOMPgbJpRVQBYFK=SWzNtTXEGyxahijdOMPgbJpRVQBYuc
  except SWzNtTXEGyxahijdOMPgbJpRVQBYuK as exception:
   SWzNtTXEGyxahijdOMPgbJpRVQBYuF(exception)
  return SWzNtTXEGyxahijdOMPgbJpRVQBYFc,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
 def GetEpisodoList(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,program_code,page_int,orderby='desc'):
  SWzNtTXEGyxahijdOMPgbJpRVQBYFc=[]
  SWzNtTXEGyxahijdOMPgbJpRVQBYFK=SWzNtTXEGyxahijdOMPgbJpRVQBYmr
  try:
   SWzNtTXEGyxahijdOMPgbJpRVQBYKf ='/v2/media/frequency/program/'+program_code
   SWzNtTXEGyxahijdOMPgbJpRVQBYKo=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetDefaultParams()
   SWzNtTXEGyxahijdOMPgbJpRVQBYKl={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetNoCache(2))}
   SWzNtTXEGyxahijdOMPgbJpRVQBYKo.update(SWzNtTXEGyxahijdOMPgbJpRVQBYKl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcD=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeurl(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.API_DOMAIN,SWzNtTXEGyxahijdOMPgbJpRVQBYKf)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcl=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeDefaultCookies()
   SWzNtTXEGyxahijdOMPgbJpRVQBYcr=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.callRequestCookies('Get',SWzNtTXEGyxahijdOMPgbJpRVQBYcD,payload=SWzNtTXEGyxahijdOMPgbJpRVQBYme,params=SWzNtTXEGyxahijdOMPgbJpRVQBYKo,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYme,cookies=SWzNtTXEGyxahijdOMPgbJpRVQBYcl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYKU=json.loads(SWzNtTXEGyxahijdOMPgbJpRVQBYcr.text)
   if not('result' in SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']):return SWzNtTXEGyxahijdOMPgbJpRVQBYFc,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
   SWzNtTXEGyxahijdOMPgbJpRVQBYFu=SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']['result']
   SWzNtTXEGyxahijdOMPgbJpRVQBYmK=SWzNtTXEGyxahijdOMPgbJpRVQBYmA(SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']['total_count'])
   SWzNtTXEGyxahijdOMPgbJpRVQBYmF =SWzNtTXEGyxahijdOMPgbJpRVQBYmA(SWzNtTXEGyxahijdOMPgbJpRVQBYmK//(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    SWzNtTXEGyxahijdOMPgbJpRVQBYmu =(SWzNtTXEGyxahijdOMPgbJpRVQBYmK-1)-((page_int-1)*SWzNtTXEGyxahijdOMPgbJpRVQBYcu.EPISODE_LIMIT)
   else:
    SWzNtTXEGyxahijdOMPgbJpRVQBYmu =(page_int-1)*SWzNtTXEGyxahijdOMPgbJpRVQBYcu.EPISODE_LIMIT
   for i in SWzNtTXEGyxahijdOMPgbJpRVQBYuo(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.EPISODE_LIMIT):
    if orderby=='desc':
     SWzNtTXEGyxahijdOMPgbJpRVQBYmf=SWzNtTXEGyxahijdOMPgbJpRVQBYmu-i
     if SWzNtTXEGyxahijdOMPgbJpRVQBYmf<0:break
    else:
     SWzNtTXEGyxahijdOMPgbJpRVQBYmf=SWzNtTXEGyxahijdOMPgbJpRVQBYmu+i
     if SWzNtTXEGyxahijdOMPgbJpRVQBYmf>=SWzNtTXEGyxahijdOMPgbJpRVQBYmK:break
    SWzNtTXEGyxahijdOMPgbJpRVQBYmo=SWzNtTXEGyxahijdOMPgbJpRVQBYFu[SWzNtTXEGyxahijdOMPgbJpRVQBYmf]['episode']['code']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFs =SWzNtTXEGyxahijdOMPgbJpRVQBYFu[SWzNtTXEGyxahijdOMPgbJpRVQBYmf]['vod_name']['ko']
    SWzNtTXEGyxahijdOMPgbJpRVQBYml =''
    try:
     SWzNtTXEGyxahijdOMPgbJpRVQBYmc=SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYFu[SWzNtTXEGyxahijdOMPgbJpRVQBYmf]['episode']['broadcast_date'])
     SWzNtTXEGyxahijdOMPgbJpRVQBYml='%s-%s-%s'%(SWzNtTXEGyxahijdOMPgbJpRVQBYmc[:4],SWzNtTXEGyxahijdOMPgbJpRVQBYmc[4:6],SWzNtTXEGyxahijdOMPgbJpRVQBYmc[6:])
    except:
     SWzNtTXEGyxahijdOMPgbJpRVQBYme
    if SWzNtTXEGyxahijdOMPgbJpRVQBYFu[SWzNtTXEGyxahijdOMPgbJpRVQBYmf]['episode']['image']!=[]:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFk=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYFu[SWzNtTXEGyxahijdOMPgbJpRVQBYmf]['episode']['image'][0]['url']
    else:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFk=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYFu[SWzNtTXEGyxahijdOMPgbJpRVQBYmf]['program']['image'][0]['url']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFn =SWzNtTXEGyxahijdOMPgbJpRVQBYFu[SWzNtTXEGyxahijdOMPgbJpRVQBYmf]['episode']['synopsis']['ko']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFf={}
    SWzNtTXEGyxahijdOMPgbJpRVQBYFf['mediatype']='episode' 
    try:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFf['title'] =SWzNtTXEGyxahijdOMPgbJpRVQBYFu[SWzNtTXEGyxahijdOMPgbJpRVQBYmf]['program']['name']['ko']
     SWzNtTXEGyxahijdOMPgbJpRVQBYFf['aired'] =SWzNtTXEGyxahijdOMPgbJpRVQBYml
     SWzNtTXEGyxahijdOMPgbJpRVQBYFf['studio'] =SWzNtTXEGyxahijdOMPgbJpRVQBYFu[SWzNtTXEGyxahijdOMPgbJpRVQBYmf]['channel']['name']['ko']
     if 'frequency' in SWzNtTXEGyxahijdOMPgbJpRVQBYFu[SWzNtTXEGyxahijdOMPgbJpRVQBYmf]['episode']:SWzNtTXEGyxahijdOMPgbJpRVQBYFf['episode']=SWzNtTXEGyxahijdOMPgbJpRVQBYFu[SWzNtTXEGyxahijdOMPgbJpRVQBYmf]['episode']['frequency']
    except:
     SWzNtTXEGyxahijdOMPgbJpRVQBYme
    SWzNtTXEGyxahijdOMPgbJpRVQBYFv={'episode':SWzNtTXEGyxahijdOMPgbJpRVQBYmo,'title':SWzNtTXEGyxahijdOMPgbJpRVQBYFs,'subtitle':SWzNtTXEGyxahijdOMPgbJpRVQBYml,'thumbnail':SWzNtTXEGyxahijdOMPgbJpRVQBYFk,'synopsis':SWzNtTXEGyxahijdOMPgbJpRVQBYFn,'info':SWzNtTXEGyxahijdOMPgbJpRVQBYFf}
    SWzNtTXEGyxahijdOMPgbJpRVQBYFc.append(SWzNtTXEGyxahijdOMPgbJpRVQBYFv)
   if SWzNtTXEGyxahijdOMPgbJpRVQBYmF>page_int:SWzNtTXEGyxahijdOMPgbJpRVQBYFK=SWzNtTXEGyxahijdOMPgbJpRVQBYuc
  except SWzNtTXEGyxahijdOMPgbJpRVQBYuK as exception:
   SWzNtTXEGyxahijdOMPgbJpRVQBYuF(exception)
  return SWzNtTXEGyxahijdOMPgbJpRVQBYFc,SWzNtTXEGyxahijdOMPgbJpRVQBYFK,SWzNtTXEGyxahijdOMPgbJpRVQBYmF
 def GetMovieList(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,orderby,page_int,premiumyn=SWzNtTXEGyxahijdOMPgbJpRVQBYmr,landyn=SWzNtTXEGyxahijdOMPgbJpRVQBYmr):
  SWzNtTXEGyxahijdOMPgbJpRVQBYFc=[]
  SWzNtTXEGyxahijdOMPgbJpRVQBYFK=SWzNtTXEGyxahijdOMPgbJpRVQBYmr
  if premiumyn==SWzNtTXEGyxahijdOMPgbJpRVQBYuc:
   SWzNtTXEGyxahijdOMPgbJpRVQBYmU=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.MOVIE_LITE+','+SWzNtTXEGyxahijdOMPgbJpRVQBYcu.MOVIE_PREMIUM
  else:
   SWzNtTXEGyxahijdOMPgbJpRVQBYmU=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.MOVIE_LITE
  try:
   SWzNtTXEGyxahijdOMPgbJpRVQBYKf ='/v2/media/movies'
   SWzNtTXEGyxahijdOMPgbJpRVQBYKo=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetDefaultParams()
   SWzNtTXEGyxahijdOMPgbJpRVQBYKl={'pageNo':SWzNtTXEGyxahijdOMPgbJpRVQBYum(page_int),'pageSize':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','productPackageCode':SWzNtTXEGyxahijdOMPgbJpRVQBYmU,'_':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetNoCache(2))}
   SWzNtTXEGyxahijdOMPgbJpRVQBYKo.update(SWzNtTXEGyxahijdOMPgbJpRVQBYKl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcD=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeurl(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.API_DOMAIN,SWzNtTXEGyxahijdOMPgbJpRVQBYKf)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcl=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeDefaultCookies()
   SWzNtTXEGyxahijdOMPgbJpRVQBYcr=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.callRequestCookies('Get',SWzNtTXEGyxahijdOMPgbJpRVQBYcD,payload=SWzNtTXEGyxahijdOMPgbJpRVQBYme,params=SWzNtTXEGyxahijdOMPgbJpRVQBYKo,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYme,cookies=SWzNtTXEGyxahijdOMPgbJpRVQBYcl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYKU=json.loads(SWzNtTXEGyxahijdOMPgbJpRVQBYcr.text)
   if not('result' in SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']):return SWzNtTXEGyxahijdOMPgbJpRVQBYFc,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
   SWzNtTXEGyxahijdOMPgbJpRVQBYFu=SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']['result']
   for SWzNtTXEGyxahijdOMPgbJpRVQBYKC in SWzNtTXEGyxahijdOMPgbJpRVQBYFu:
    SWzNtTXEGyxahijdOMPgbJpRVQBYms =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['movie']['code']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFs =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['movie']['name']['ko'].strip()
    SWzNtTXEGyxahijdOMPgbJpRVQBYFs +=u' (%s년)'%(SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('movie').get('product_year'))
    SWzNtTXEGyxahijdOMPgbJpRVQBYFk =SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYKC['movie']['image'][0]['url']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFI='CAIM0400' if landyn else 'CAIM2100' 
    for SWzNtTXEGyxahijdOMPgbJpRVQBYFw in SWzNtTXEGyxahijdOMPgbJpRVQBYKC['movie']['image']:
     if SWzNtTXEGyxahijdOMPgbJpRVQBYFw['code']==SWzNtTXEGyxahijdOMPgbJpRVQBYFI:
      SWzNtTXEGyxahijdOMPgbJpRVQBYFk =SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYFw['url']
      break
    SWzNtTXEGyxahijdOMPgbJpRVQBYFn =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['movie']['story']['ko']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFf={}
    SWzNtTXEGyxahijdOMPgbJpRVQBYFf['mediatype']='movie' 
    SWzNtTXEGyxahijdOMPgbJpRVQBYFf['title'] = SWzNtTXEGyxahijdOMPgbJpRVQBYKC['movie']['name']['ko'].strip()
    SWzNtTXEGyxahijdOMPgbJpRVQBYFf['year'] =SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('movie').get('product_year')
    try:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFC=[]
     for SWzNtTXEGyxahijdOMPgbJpRVQBYFD in SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('movie').get('actor'):SWzNtTXEGyxahijdOMPgbJpRVQBYFC.append(SWzNtTXEGyxahijdOMPgbJpRVQBYFD)
     if SWzNtTXEGyxahijdOMPgbJpRVQBYFC[0]!='':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['cast']=SWzNtTXEGyxahijdOMPgbJpRVQBYFC
    except:
     SWzNtTXEGyxahijdOMPgbJpRVQBYme
    try:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFr=[]
     for SWzNtTXEGyxahijdOMPgbJpRVQBYFA in SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('movie').get('director'):SWzNtTXEGyxahijdOMPgbJpRVQBYFr.append(SWzNtTXEGyxahijdOMPgbJpRVQBYFA)
     if SWzNtTXEGyxahijdOMPgbJpRVQBYFr[0]!='':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['director']=SWzNtTXEGyxahijdOMPgbJpRVQBYFr
    except:
     SWzNtTXEGyxahijdOMPgbJpRVQBYme
    try:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFL=[]
     if SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('movie').get('category1_name').get('ko')!='':
      SWzNtTXEGyxahijdOMPgbJpRVQBYFL.append(SWzNtTXEGyxahijdOMPgbJpRVQBYKC['movie']['category1_name']['ko'])
     if SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('movie').get('category2_name').get('ko')!='':
      SWzNtTXEGyxahijdOMPgbJpRVQBYFL.append(SWzNtTXEGyxahijdOMPgbJpRVQBYKC['movie']['category2_name']['ko'])
     if SWzNtTXEGyxahijdOMPgbJpRVQBYFL[0]!='':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['genre']=SWzNtTXEGyxahijdOMPgbJpRVQBYFL
    except:
     SWzNtTXEGyxahijdOMPgbJpRVQBYme
    try:
     if 'release_date' in SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('movie'):
      SWzNtTXEGyxahijdOMPgbJpRVQBYmc=SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('movie').get('release_date'))
      SWzNtTXEGyxahijdOMPgbJpRVQBYFf['aired']='%s-%s-%s'%(SWzNtTXEGyxahijdOMPgbJpRVQBYmc[:4],SWzNtTXEGyxahijdOMPgbJpRVQBYmc[4:6],SWzNtTXEGyxahijdOMPgbJpRVQBYmc[6:])
    except:
     SWzNtTXEGyxahijdOMPgbJpRVQBYme
    try:
     if 'duration' in SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('movie'):SWzNtTXEGyxahijdOMPgbJpRVQBYFf['duration']=SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('movie').get('duration')
    except:
     SWzNtTXEGyxahijdOMPgbJpRVQBYme
    SWzNtTXEGyxahijdOMPgbJpRVQBYFv={'moviecode':SWzNtTXEGyxahijdOMPgbJpRVQBYms,'title':SWzNtTXEGyxahijdOMPgbJpRVQBYFs,'thumbnail':SWzNtTXEGyxahijdOMPgbJpRVQBYFk,'synopsis':SWzNtTXEGyxahijdOMPgbJpRVQBYFn,'info':SWzNtTXEGyxahijdOMPgbJpRVQBYFf}
    if premiumyn==SWzNtTXEGyxahijdOMPgbJpRVQBYuc:
     SWzNtTXEGyxahijdOMPgbJpRVQBYmk=SWzNtTXEGyxahijdOMPgbJpRVQBYmr
     for SWzNtTXEGyxahijdOMPgbJpRVQBYmn in SWzNtTXEGyxahijdOMPgbJpRVQBYKC['billing_package_id']:
      if SWzNtTXEGyxahijdOMPgbJpRVQBYmn==SWzNtTXEGyxahijdOMPgbJpRVQBYcu.MOVIE_LITE:
       SWzNtTXEGyxahijdOMPgbJpRVQBYmk=SWzNtTXEGyxahijdOMPgbJpRVQBYuc
       break
     if SWzNtTXEGyxahijdOMPgbJpRVQBYmk==SWzNtTXEGyxahijdOMPgbJpRVQBYmr:
      SWzNtTXEGyxahijdOMPgbJpRVQBYFv['title']=SWzNtTXEGyxahijdOMPgbJpRVQBYFv['title']+' [Premium]'
    SWzNtTXEGyxahijdOMPgbJpRVQBYFc.append(SWzNtTXEGyxahijdOMPgbJpRVQBYFv)
   if SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']['has_more']=='Y':SWzNtTXEGyxahijdOMPgbJpRVQBYFK=SWzNtTXEGyxahijdOMPgbJpRVQBYuc
  except SWzNtTXEGyxahijdOMPgbJpRVQBYuK as exception:
   SWzNtTXEGyxahijdOMPgbJpRVQBYuF(exception)
  return SWzNtTXEGyxahijdOMPgbJpRVQBYFc,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
 def GetMovieListGenre(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,genre,page_int,premiumyn=SWzNtTXEGyxahijdOMPgbJpRVQBYmr):
  SWzNtTXEGyxahijdOMPgbJpRVQBYFc=[]
  SWzNtTXEGyxahijdOMPgbJpRVQBYFK=SWzNtTXEGyxahijdOMPgbJpRVQBYmr
  if premiumyn==SWzNtTXEGyxahijdOMPgbJpRVQBYuc:
   SWzNtTXEGyxahijdOMPgbJpRVQBYmU=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.MOVIE_LITE+','+SWzNtTXEGyxahijdOMPgbJpRVQBYcu.MOVIE_PREMIUM
  else:
   SWzNtTXEGyxahijdOMPgbJpRVQBYmU=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.MOVIE_LITE
  try:
   SWzNtTXEGyxahijdOMPgbJpRVQBYKf ='/v2/media/movie/curation/'+genre
   SWzNtTXEGyxahijdOMPgbJpRVQBYKo=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetDefaultParams()
   SWzNtTXEGyxahijdOMPgbJpRVQBYKl={'pageNo':SWzNtTXEGyxahijdOMPgbJpRVQBYum(page_int),'pageSize':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.MOVIE_LIMIT),'productPackageCode':SWzNtTXEGyxahijdOMPgbJpRVQBYmU,'_':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetNoCache(2))}
   SWzNtTXEGyxahijdOMPgbJpRVQBYKo.update(SWzNtTXEGyxahijdOMPgbJpRVQBYKl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcD=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeurl(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.API_DOMAIN,SWzNtTXEGyxahijdOMPgbJpRVQBYKf)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcl=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeDefaultCookies()
   SWzNtTXEGyxahijdOMPgbJpRVQBYcr=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.callRequestCookies('Get',SWzNtTXEGyxahijdOMPgbJpRVQBYcD,payload=SWzNtTXEGyxahijdOMPgbJpRVQBYme,params=SWzNtTXEGyxahijdOMPgbJpRVQBYKo,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYme,cookies=SWzNtTXEGyxahijdOMPgbJpRVQBYcl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYKU=json.loads(SWzNtTXEGyxahijdOMPgbJpRVQBYcr.text)
   if not('movies' in SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']):return SWzNtTXEGyxahijdOMPgbJpRVQBYFc,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
   SWzNtTXEGyxahijdOMPgbJpRVQBYFu=SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']['movies']
   for SWzNtTXEGyxahijdOMPgbJpRVQBYKC in SWzNtTXEGyxahijdOMPgbJpRVQBYFu:
    SWzNtTXEGyxahijdOMPgbJpRVQBYms =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['code']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFs =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['name']['ko']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFk =SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYKC['image'][0]['url']
    for SWzNtTXEGyxahijdOMPgbJpRVQBYFw in SWzNtTXEGyxahijdOMPgbJpRVQBYKC['image']:
     if SWzNtTXEGyxahijdOMPgbJpRVQBYFw['code']=='CAIM2100':
      SWzNtTXEGyxahijdOMPgbJpRVQBYFk =SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYFw['url']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFn =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['story']['ko']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFv={'moviecode':SWzNtTXEGyxahijdOMPgbJpRVQBYms,'title':SWzNtTXEGyxahijdOMPgbJpRVQBYFs.strip(),'thumbnail':SWzNtTXEGyxahijdOMPgbJpRVQBYFk,'synopsis':SWzNtTXEGyxahijdOMPgbJpRVQBYFn}
    if premiumyn==SWzNtTXEGyxahijdOMPgbJpRVQBYuc:
     SWzNtTXEGyxahijdOMPgbJpRVQBYmk=SWzNtTXEGyxahijdOMPgbJpRVQBYmr
     for SWzNtTXEGyxahijdOMPgbJpRVQBYmn in SWzNtTXEGyxahijdOMPgbJpRVQBYKC['billing_package_id']:
      if SWzNtTXEGyxahijdOMPgbJpRVQBYmn==SWzNtTXEGyxahijdOMPgbJpRVQBYcu.MOVIE_LITE:
       SWzNtTXEGyxahijdOMPgbJpRVQBYmk=SWzNtTXEGyxahijdOMPgbJpRVQBYuc
       break
     if SWzNtTXEGyxahijdOMPgbJpRVQBYmk==SWzNtTXEGyxahijdOMPgbJpRVQBYmr:
      SWzNtTXEGyxahijdOMPgbJpRVQBYFv['title']=SWzNtTXEGyxahijdOMPgbJpRVQBYFv['title']+' [Premium]'
    SWzNtTXEGyxahijdOMPgbJpRVQBYFc.append(SWzNtTXEGyxahijdOMPgbJpRVQBYFv)
  except SWzNtTXEGyxahijdOMPgbJpRVQBYuK as exception:
   SWzNtTXEGyxahijdOMPgbJpRVQBYuF(exception)
  return SWzNtTXEGyxahijdOMPgbJpRVQBYFc,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
 def GetMovieGenre(SWzNtTXEGyxahijdOMPgbJpRVQBYcu):
  SWzNtTXEGyxahijdOMPgbJpRVQBYFc=[]
  SWzNtTXEGyxahijdOMPgbJpRVQBYFK=SWzNtTXEGyxahijdOMPgbJpRVQBYmr
  try:
   SWzNtTXEGyxahijdOMPgbJpRVQBYKf ='/v2/media/movie/curations'
   SWzNtTXEGyxahijdOMPgbJpRVQBYKo=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetDefaultParams()
   SWzNtTXEGyxahijdOMPgbJpRVQBYKl={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetNoCache(2))}
   SWzNtTXEGyxahijdOMPgbJpRVQBYKo.update(SWzNtTXEGyxahijdOMPgbJpRVQBYKl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcD=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeurl(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.API_DOMAIN,SWzNtTXEGyxahijdOMPgbJpRVQBYKf)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcl=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeDefaultCookies()
   SWzNtTXEGyxahijdOMPgbJpRVQBYcr=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.callRequestCookies('Get',SWzNtTXEGyxahijdOMPgbJpRVQBYcD,payload=SWzNtTXEGyxahijdOMPgbJpRVQBYme,params=SWzNtTXEGyxahijdOMPgbJpRVQBYKo,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYme,cookies=SWzNtTXEGyxahijdOMPgbJpRVQBYcl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYKU=json.loads(SWzNtTXEGyxahijdOMPgbJpRVQBYcr.text)
   if not('result' in SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']):return SWzNtTXEGyxahijdOMPgbJpRVQBYFc,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
   SWzNtTXEGyxahijdOMPgbJpRVQBYFu=SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']['result']
   for SWzNtTXEGyxahijdOMPgbJpRVQBYKC in SWzNtTXEGyxahijdOMPgbJpRVQBYFu:
    SWzNtTXEGyxahijdOMPgbJpRVQBYmC =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['curation_code']
    SWzNtTXEGyxahijdOMPgbJpRVQBYmD =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['curation_name']
    SWzNtTXEGyxahijdOMPgbJpRVQBYFv={'curation_code':SWzNtTXEGyxahijdOMPgbJpRVQBYmC,'curation_name':SWzNtTXEGyxahijdOMPgbJpRVQBYmD}
    SWzNtTXEGyxahijdOMPgbJpRVQBYFc.append(SWzNtTXEGyxahijdOMPgbJpRVQBYFv)
  except SWzNtTXEGyxahijdOMPgbJpRVQBYuK as exception:
   SWzNtTXEGyxahijdOMPgbJpRVQBYuF(exception)
  return SWzNtTXEGyxahijdOMPgbJpRVQBYFc,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
 def GetSearchList(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,search_key,userid,page_int,stype,premiumyn=SWzNtTXEGyxahijdOMPgbJpRVQBYmr,landyn=SWzNtTXEGyxahijdOMPgbJpRVQBYmr):
  SWzNtTXEGyxahijdOMPgbJpRVQBYmL=[]
  SWzNtTXEGyxahijdOMPgbJpRVQBYFK=SWzNtTXEGyxahijdOMPgbJpRVQBYmr
  try:
   SWzNtTXEGyxahijdOMPgbJpRVQBYKf ='/search/getSearch.jsp'
   SWzNtTXEGyxahijdOMPgbJpRVQBYKl={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'TOTAL','pageNum':SWzNtTXEGyxahijdOMPgbJpRVQBYum(page_int),'pageSize':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':SWzNtTXEGyxahijdOMPgbJpRVQBYcu.SCREENCODE,'os':SWzNtTXEGyxahijdOMPgbJpRVQBYcu.OSCODE,'network':SWzNtTXEGyxahijdOMPgbJpRVQBYcu.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.SEARCH_LIMIT),'vodMVReqCnt':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':SWzNtTXEGyxahijdOMPgbJpRVQBYum(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.GetNoCache(2))}
   SWzNtTXEGyxahijdOMPgbJpRVQBYcD=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeurl(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.SEARCH_DOMAIN,SWzNtTXEGyxahijdOMPgbJpRVQBYKf)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcl=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeDefaultCookies()
   SWzNtTXEGyxahijdOMPgbJpRVQBYcr=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.callRequestCookies('Get',SWzNtTXEGyxahijdOMPgbJpRVQBYcD,payload=SWzNtTXEGyxahijdOMPgbJpRVQBYme,params=SWzNtTXEGyxahijdOMPgbJpRVQBYKl,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYme,cookies=SWzNtTXEGyxahijdOMPgbJpRVQBYcl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYKU=json.loads(SWzNtTXEGyxahijdOMPgbJpRVQBYcr.text)
   if stype=='vod':
    if not('programRsb' in SWzNtTXEGyxahijdOMPgbJpRVQBYKU):return SWzNtTXEGyxahijdOMPgbJpRVQBYmL,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
    SWzNtTXEGyxahijdOMPgbJpRVQBYmH=SWzNtTXEGyxahijdOMPgbJpRVQBYKU['programRsb']['dataList']
    SWzNtTXEGyxahijdOMPgbJpRVQBYmv =SWzNtTXEGyxahijdOMPgbJpRVQBYmA(SWzNtTXEGyxahijdOMPgbJpRVQBYKU['programRsb']['count'])
    for SWzNtTXEGyxahijdOMPgbJpRVQBYKC in SWzNtTXEGyxahijdOMPgbJpRVQBYmH:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFq=SWzNtTXEGyxahijdOMPgbJpRVQBYKC['mast_cd']
     SWzNtTXEGyxahijdOMPgbJpRVQBYFs =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['mast_nm']
     SWzNtTXEGyxahijdOMPgbJpRVQBYFk =SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYKC['web_url']
     if landyn==SWzNtTXEGyxahijdOMPgbJpRVQBYmr:
      SWzNtTXEGyxahijdOMPgbJpRVQBYFk =SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYKC['web_url4']
     SWzNtTXEGyxahijdOMPgbJpRVQBYFf={}
     SWzNtTXEGyxahijdOMPgbJpRVQBYFf['title']=SWzNtTXEGyxahijdOMPgbJpRVQBYKC['mast_nm']
     SWzNtTXEGyxahijdOMPgbJpRVQBYFf['mediatype']='episode' 
     try:
      if SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('actor')!='' and SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('actor')!='-':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['cast'] =SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('actor').split(',')
      if SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('director')!='' and SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('director')!='-':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['director']=SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('director').split(',')
      if SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('cate_nm')!='':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['genre'] =SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('cate_nm').split('/')
      if 'targetage' in SWzNtTXEGyxahijdOMPgbJpRVQBYKC:SWzNtTXEGyxahijdOMPgbJpRVQBYFf['mpaa']=SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('targetage')
     except:
      SWzNtTXEGyxahijdOMPgbJpRVQBYme
     try:
      if 'broad_dt' in SWzNtTXEGyxahijdOMPgbJpRVQBYKC:
       SWzNtTXEGyxahijdOMPgbJpRVQBYmc=SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('broad_dt')
       SWzNtTXEGyxahijdOMPgbJpRVQBYFf['aired']='%s-%s-%s'%(SWzNtTXEGyxahijdOMPgbJpRVQBYmc[:4],SWzNtTXEGyxahijdOMPgbJpRVQBYmc[4:6],SWzNtTXEGyxahijdOMPgbJpRVQBYmc[6:])
     except:
      SWzNtTXEGyxahijdOMPgbJpRVQBYme
     SWzNtTXEGyxahijdOMPgbJpRVQBYFv={'program':SWzNtTXEGyxahijdOMPgbJpRVQBYFq,'title':SWzNtTXEGyxahijdOMPgbJpRVQBYFs,'thumbnail':SWzNtTXEGyxahijdOMPgbJpRVQBYFk,'synopsis':'','info':SWzNtTXEGyxahijdOMPgbJpRVQBYFf}
     SWzNtTXEGyxahijdOMPgbJpRVQBYmL.append(SWzNtTXEGyxahijdOMPgbJpRVQBYFv)
   else:
    if not('vodMVRsb' in SWzNtTXEGyxahijdOMPgbJpRVQBYKU):return SWzNtTXEGyxahijdOMPgbJpRVQBYmL,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
    SWzNtTXEGyxahijdOMPgbJpRVQBYmq=SWzNtTXEGyxahijdOMPgbJpRVQBYKU['vodMVRsb']['dataList']
    SWzNtTXEGyxahijdOMPgbJpRVQBYmv =SWzNtTXEGyxahijdOMPgbJpRVQBYmA(SWzNtTXEGyxahijdOMPgbJpRVQBYKU['vodMVRsb']['count'])
    for SWzNtTXEGyxahijdOMPgbJpRVQBYKC in SWzNtTXEGyxahijdOMPgbJpRVQBYmq:
     SWzNtTXEGyxahijdOMPgbJpRVQBYFq=SWzNtTXEGyxahijdOMPgbJpRVQBYKC['mast_cd']
     SWzNtTXEGyxahijdOMPgbJpRVQBYFs =SWzNtTXEGyxahijdOMPgbJpRVQBYKC['mast_nm'].strip()
     SWzNtTXEGyxahijdOMPgbJpRVQBYFk =SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYKC['web_url']
     if landyn==SWzNtTXEGyxahijdOMPgbJpRVQBYmr:
      SWzNtTXEGyxahijdOMPgbJpRVQBYFk =SWzNtTXEGyxahijdOMPgbJpRVQBYcu.IMG_DOMAIN+SWzNtTXEGyxahijdOMPgbJpRVQBYKC['web_url5']
     SWzNtTXEGyxahijdOMPgbJpRVQBYFf={}
     SWzNtTXEGyxahijdOMPgbJpRVQBYFf['title'] =SWzNtTXEGyxahijdOMPgbJpRVQBYFs
     SWzNtTXEGyxahijdOMPgbJpRVQBYFf['mediatype']='movie' 
     try:
      if SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('actor') !='':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['cast'] =SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('actor').split(',')
      if SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('cate_nm')!='':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['genre'] =SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('cate_nm').split('/')
      if SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('runtime_sec')!='':SWzNtTXEGyxahijdOMPgbJpRVQBYFf['duration']=SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('runtime_sec')
      if 'grade_nm' in SWzNtTXEGyxahijdOMPgbJpRVQBYKC:SWzNtTXEGyxahijdOMPgbJpRVQBYFf['mpaa']=SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('grade_nm')
     except:
      SWzNtTXEGyxahijdOMPgbJpRVQBYme
     try:
      SWzNtTXEGyxahijdOMPgbJpRVQBYmc=SWzNtTXEGyxahijdOMPgbJpRVQBYKC.get('broad_dt')
      if data_str!='':
       SWzNtTXEGyxahijdOMPgbJpRVQBYFf['aired']='%s-%s-%s'%(SWzNtTXEGyxahijdOMPgbJpRVQBYmc[:4],SWzNtTXEGyxahijdOMPgbJpRVQBYmc[4:6],SWzNtTXEGyxahijdOMPgbJpRVQBYmc[6:])
       SWzNtTXEGyxahijdOMPgbJpRVQBYFf['year']=SWzNtTXEGyxahijdOMPgbJpRVQBYmc[:4]
     except:
      SWzNtTXEGyxahijdOMPgbJpRVQBYme
     if SWzNtTXEGyxahijdOMPgbJpRVQBYuc:
      SWzNtTXEGyxahijdOMPgbJpRVQBYFv={'movie':SWzNtTXEGyxahijdOMPgbJpRVQBYFq,'title':SWzNtTXEGyxahijdOMPgbJpRVQBYFs,'thumbnail':SWzNtTXEGyxahijdOMPgbJpRVQBYFk,'synopsis':'','info':SWzNtTXEGyxahijdOMPgbJpRVQBYFf}
      SWzNtTXEGyxahijdOMPgbJpRVQBYmL.append(SWzNtTXEGyxahijdOMPgbJpRVQBYFv)
  except SWzNtTXEGyxahijdOMPgbJpRVQBYuK as exception:
   SWzNtTXEGyxahijdOMPgbJpRVQBYuF(exception)
  return SWzNtTXEGyxahijdOMPgbJpRVQBYmL,SWzNtTXEGyxahijdOMPgbJpRVQBYFK
 def GetDeviceList(SWzNtTXEGyxahijdOMPgbJpRVQBYcu,SWzNtTXEGyxahijdOMPgbJpRVQBYcq,SWzNtTXEGyxahijdOMPgbJpRVQBYKc):
  SWzNtTXEGyxahijdOMPgbJpRVQBYFc=[]
  SWzNtTXEGyxahijdOMPgbJpRVQBYKu='-'
  try:
   SWzNtTXEGyxahijdOMPgbJpRVQBYKf ='/v1/user/device/list'
   SWzNtTXEGyxahijdOMPgbJpRVQBYmI=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeurl(SWzNtTXEGyxahijdOMPgbJpRVQBYcu.API_DOMAIN,SWzNtTXEGyxahijdOMPgbJpRVQBYKf)
   SWzNtTXEGyxahijdOMPgbJpRVQBYKl={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   SWzNtTXEGyxahijdOMPgbJpRVQBYcl=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.makeDefaultCookies(vToken=SWzNtTXEGyxahijdOMPgbJpRVQBYcq,vUserinfo=SWzNtTXEGyxahijdOMPgbJpRVQBYKc)
   SWzNtTXEGyxahijdOMPgbJpRVQBYcr=SWzNtTXEGyxahijdOMPgbJpRVQBYcu.callRequestCookies('Get',SWzNtTXEGyxahijdOMPgbJpRVQBYmI,payload=SWzNtTXEGyxahijdOMPgbJpRVQBYme,params=SWzNtTXEGyxahijdOMPgbJpRVQBYKl,headers=SWzNtTXEGyxahijdOMPgbJpRVQBYme,cookies=SWzNtTXEGyxahijdOMPgbJpRVQBYcl)
   SWzNtTXEGyxahijdOMPgbJpRVQBYKU=json.loads(SWzNtTXEGyxahijdOMPgbJpRVQBYcr.text)
   SWzNtTXEGyxahijdOMPgbJpRVQBYFc=SWzNtTXEGyxahijdOMPgbJpRVQBYKU['body']
   for SWzNtTXEGyxahijdOMPgbJpRVQBYKC in SWzNtTXEGyxahijdOMPgbJpRVQBYFc:
    if SWzNtTXEGyxahijdOMPgbJpRVQBYKC['model']=='PC':
     SWzNtTXEGyxahijdOMPgbJpRVQBYKu=SWzNtTXEGyxahijdOMPgbJpRVQBYKC['uuid']
  except SWzNtTXEGyxahijdOMPgbJpRVQBYuK as exception:
   SWzNtTXEGyxahijdOMPgbJpRVQBYuF(exception)
  return SWzNtTXEGyxahijdOMPgbJpRVQBYKu
# Created by pyminifier (https://github.com/liftoff/pyminifier)
