__author__="NightRain"
tLOawUzIxgbmMJycrkiTDuKFpjBVdv=object
tLOawUzIxgbmMJycrkiTDuKFpjBVdH=None
tLOawUzIxgbmMJycrkiTDuKFpjBVde=False
tLOawUzIxgbmMJycrkiTDuKFpjBVRo=int
tLOawUzIxgbmMJycrkiTDuKFpjBVRP=True
tLOawUzIxgbmMJycrkiTDuKFpjBVRE=Exception
tLOawUzIxgbmMJycrkiTDuKFpjBVRd=print
tLOawUzIxgbmMJycrkiTDuKFpjBVRC=str
tLOawUzIxgbmMJycrkiTDuKFpjBVRQ=list
tLOawUzIxgbmMJycrkiTDuKFpjBVRq=range
import urllib
import http.cookiejar 
import re
import json
import sys
import time
import requests
import datetime
tLOawUzIxgbmMJycrkiTDuKFpjBVoE ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
tLOawUzIxgbmMJycrkiTDuKFpjBVod={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
class tLOawUzIxgbmMJycrkiTDuKFpjBVoP(tLOawUzIxgbmMJycrkiTDuKFpjBVdv):
 def __init__(tLOawUzIxgbmMJycrkiTDuKFpjBVoR):
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.TVING_TOKEN =''
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.POC_USERINFO =''
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.TVING_UUID ='-'
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.NETWORKCODE ='CSND0900'
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.OSCODE ='CSOD0900' 
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.TELECODE ='CSCD0900'
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.SCREENCODE ='CSSD0100'
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.LIVE_LIMIT =23
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.VOD_LIMIT =20
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.EPISODE_LIMIT=30 
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.SEARCH_LIMIT =80 
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.MOVIE_LIMIT =18
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.API_DOMAIN ='https://api.tving.com'
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN ='https://image.tving.com'
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.SEARCH_DOMAIN='https://search.tving.com'
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.LOGIN_DOMAIN ='https://user.tving.com'
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.URL_DOMAIN ='https://www.tving.com'
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.MOVIE_LITE ='338723'
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.MOVIE_PREMIUM='1513561'
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.DEFAULT_HEADER={'user-agent':tLOawUzIxgbmMJycrkiTDuKFpjBVoE}
 def callRequestCookies(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,jobtype,tLOawUzIxgbmMJycrkiTDuKFpjBVos,payload=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,params=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,cookies=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,redirects=tLOawUzIxgbmMJycrkiTDuKFpjBVde):
  tLOawUzIxgbmMJycrkiTDuKFpjBVoC=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.DEFAULT_HEADER
  if headers:tLOawUzIxgbmMJycrkiTDuKFpjBVoC.update(headers)
  if jobtype=='Get':
   tLOawUzIxgbmMJycrkiTDuKFpjBVoQ=requests.get(tLOawUzIxgbmMJycrkiTDuKFpjBVos,params=params,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVoC,cookies=cookies,allow_redirects=redirects)
  else:
   tLOawUzIxgbmMJycrkiTDuKFpjBVoQ=requests.post(tLOawUzIxgbmMJycrkiTDuKFpjBVos,data=payload,params=params,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVoC,cookies=cookies,allow_redirects=redirects)
  return tLOawUzIxgbmMJycrkiTDuKFpjBVoQ
 def makeDefaultCookies(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,vToken=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,vUserinfo=tLOawUzIxgbmMJycrkiTDuKFpjBVdH):
  tLOawUzIxgbmMJycrkiTDuKFpjBVoq={}
  tLOawUzIxgbmMJycrkiTDuKFpjBVoq['_tving_token']=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.TVING_TOKEN if vToken==tLOawUzIxgbmMJycrkiTDuKFpjBVdH else vToken
  tLOawUzIxgbmMJycrkiTDuKFpjBVoq['POC_USERINFO']=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.POC_USERINFO if vToken==tLOawUzIxgbmMJycrkiTDuKFpjBVdH else vUserinfo
  return tLOawUzIxgbmMJycrkiTDuKFpjBVoq
 def getDeviceStr(tLOawUzIxgbmMJycrkiTDuKFpjBVoR):
  tLOawUzIxgbmMJycrkiTDuKFpjBVof=[]
  tLOawUzIxgbmMJycrkiTDuKFpjBVof.append('Windows') 
  tLOawUzIxgbmMJycrkiTDuKFpjBVof.append('Chrome') 
  tLOawUzIxgbmMJycrkiTDuKFpjBVof.append('ko-KR') 
  tLOawUzIxgbmMJycrkiTDuKFpjBVof.append('undefined') 
  tLOawUzIxgbmMJycrkiTDuKFpjBVof.append('24') 
  tLOawUzIxgbmMJycrkiTDuKFpjBVof.append(u'한국 표준시')
  tLOawUzIxgbmMJycrkiTDuKFpjBVof.append('undefined') 
  tLOawUzIxgbmMJycrkiTDuKFpjBVof.append('undefined') 
  tLOawUzIxgbmMJycrkiTDuKFpjBVof.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  tLOawUzIxgbmMJycrkiTDuKFpjBVoA=''
  for tLOawUzIxgbmMJycrkiTDuKFpjBVon in tLOawUzIxgbmMJycrkiTDuKFpjBVof:
   tLOawUzIxgbmMJycrkiTDuKFpjBVoA+=tLOawUzIxgbmMJycrkiTDuKFpjBVon+'|'
  return tLOawUzIxgbmMJycrkiTDuKFpjBVoA
 def SaveCredential(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,tLOawUzIxgbmMJycrkiTDuKFpjBVoh):
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.TVING_TOKEN =tLOawUzIxgbmMJycrkiTDuKFpjBVoh.get('tving_token')
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.POC_USERINFO=tLOawUzIxgbmMJycrkiTDuKFpjBVoh.get('poc_userinfo')
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.TVING_UUID =tLOawUzIxgbmMJycrkiTDuKFpjBVoh.get('tving_uuid')
 def LoadCredential(tLOawUzIxgbmMJycrkiTDuKFpjBVoR):
  tLOawUzIxgbmMJycrkiTDuKFpjBVoh={'tving_token':tLOawUzIxgbmMJycrkiTDuKFpjBVoR.TVING_TOKEN,'poc_userinfo':tLOawUzIxgbmMJycrkiTDuKFpjBVoR.POC_USERINFO,'tving_uuid':tLOawUzIxgbmMJycrkiTDuKFpjBVoR.TVING_UUID}
  return tLOawUzIxgbmMJycrkiTDuKFpjBVoh
 def GetDefaultParams(tLOawUzIxgbmMJycrkiTDuKFpjBVoR):
  tLOawUzIxgbmMJycrkiTDuKFpjBVoX={'apiKey':tLOawUzIxgbmMJycrkiTDuKFpjBVoR.APIKEY,'networkCode':tLOawUzIxgbmMJycrkiTDuKFpjBVoR.NETWORKCODE,'osCode':tLOawUzIxgbmMJycrkiTDuKFpjBVoR.OSCODE,'teleCode':tLOawUzIxgbmMJycrkiTDuKFpjBVoR.TELECODE,'screenCode':tLOawUzIxgbmMJycrkiTDuKFpjBVoR.SCREENCODE}
  return tLOawUzIxgbmMJycrkiTDuKFpjBVoX
 def GetNoCache(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,timetype=1):
  if timetype==1:
   return tLOawUzIxgbmMJycrkiTDuKFpjBVRo(time.time())
  else:
   return tLOawUzIxgbmMJycrkiTDuKFpjBVRo(time.time()*1000)
 def makeurl(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,domain,path,query1=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,query2=tLOawUzIxgbmMJycrkiTDuKFpjBVdH):
  tLOawUzIxgbmMJycrkiTDuKFpjBVos=domain+path
  if query1:
   tLOawUzIxgbmMJycrkiTDuKFpjBVos+='?%s'%urllib.parse.urlencode(query1)
  if query2:
   tLOawUzIxgbmMJycrkiTDuKFpjBVos+='&%s'%urllib.parse.urlencode(query2)
  return tLOawUzIxgbmMJycrkiTDuKFpjBVos
 def GetCredential(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,user_id,user_pw,login_type):
  tLOawUzIxgbmMJycrkiTDuKFpjBVoG=tLOawUzIxgbmMJycrkiTDuKFpjBVde
  tLOawUzIxgbmMJycrkiTDuKFpjBVoS=tLOawUzIxgbmMJycrkiTDuKFpjBVPo='' 
  tLOawUzIxgbmMJycrkiTDuKFpjBVoN='-'
  try:
   tLOawUzIxgbmMJycrkiTDuKFpjBVoY=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   tLOawUzIxgbmMJycrkiTDuKFpjBVov={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'','csite':''}
   tLOawUzIxgbmMJycrkiTDuKFpjBVoH=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.callRequestCookies('Post',tLOawUzIxgbmMJycrkiTDuKFpjBVoY,payload=tLOawUzIxgbmMJycrkiTDuKFpjBVov,params=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,cookies=tLOawUzIxgbmMJycrkiTDuKFpjBVdH)
   for tLOawUzIxgbmMJycrkiTDuKFpjBVoe in tLOawUzIxgbmMJycrkiTDuKFpjBVoH.cookies:
    if tLOawUzIxgbmMJycrkiTDuKFpjBVoe.name=='_tving_token':
     tLOawUzIxgbmMJycrkiTDuKFpjBVoS=tLOawUzIxgbmMJycrkiTDuKFpjBVoe.value
    elif tLOawUzIxgbmMJycrkiTDuKFpjBVoe.name=='POC_USERINFO':
     tLOawUzIxgbmMJycrkiTDuKFpjBVPo=tLOawUzIxgbmMJycrkiTDuKFpjBVoe.value
   if tLOawUzIxgbmMJycrkiTDuKFpjBVoS:tLOawUzIxgbmMJycrkiTDuKFpjBVoG=tLOawUzIxgbmMJycrkiTDuKFpjBVRP
   tLOawUzIxgbmMJycrkiTDuKFpjBVoN=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetDeviceList(tLOawUzIxgbmMJycrkiTDuKFpjBVoS,tLOawUzIxgbmMJycrkiTDuKFpjBVPo)
  except tLOawUzIxgbmMJycrkiTDuKFpjBVRE as exception:
   tLOawUzIxgbmMJycrkiTDuKFpjBVoS=tLOawUzIxgbmMJycrkiTDuKFpjBVPo='' 
   tLOawUzIxgbmMJycrkiTDuKFpjBVoN='-'
   tLOawUzIxgbmMJycrkiTDuKFpjBVRd(exception)
  tLOawUzIxgbmMJycrkiTDuKFpjBVoh={'tving_token':tLOawUzIxgbmMJycrkiTDuKFpjBVoS,'poc_userinfo':tLOawUzIxgbmMJycrkiTDuKFpjBVPo,'tving_uuid':tLOawUzIxgbmMJycrkiTDuKFpjBVoN}
  tLOawUzIxgbmMJycrkiTDuKFpjBVoR.SaveCredential(tLOawUzIxgbmMJycrkiTDuKFpjBVoh)
  return tLOawUzIxgbmMJycrkiTDuKFpjBVoG
 def Get_Now_Datetime(tLOawUzIxgbmMJycrkiTDuKFpjBVoR):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,mediacode,sel_quality,stype,pvrmode='-'):
  tLOawUzIxgbmMJycrkiTDuKFpjBVPd=''
  tLOawUzIxgbmMJycrkiTDuKFpjBVPR=''
  tLOawUzIxgbmMJycrkiTDuKFpjBVPC=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.TVING_UUID 
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    tLOawUzIxgbmMJycrkiTDuKFpjBVPQ ='/v2/media/stream/info'
    tLOawUzIxgbmMJycrkiTDuKFpjBVPq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetDefaultParams()
    tLOawUzIxgbmMJycrkiTDuKFpjBVPf={'info':'Y','mediaCode':mediacode,'noCache':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetNoCache(1)),'callingFrom':'HTML5','adReq':'none','ooc':'','deviceId':tLOawUzIxgbmMJycrkiTDuKFpjBVPC,'wm':'Y'}
    tLOawUzIxgbmMJycrkiTDuKFpjBVPq.update(tLOawUzIxgbmMJycrkiTDuKFpjBVPf)
    tLOawUzIxgbmMJycrkiTDuKFpjBVos=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeurl(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.API_DOMAIN,tLOawUzIxgbmMJycrkiTDuKFpjBVPQ)
    tLOawUzIxgbmMJycrkiTDuKFpjBVoq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeDefaultCookies()
    tLOawUzIxgbmMJycrkiTDuKFpjBVoH=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.callRequestCookies('Get',tLOawUzIxgbmMJycrkiTDuKFpjBVos,payload=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,params=tLOawUzIxgbmMJycrkiTDuKFpjBVPq,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,cookies=tLOawUzIxgbmMJycrkiTDuKFpjBVoq)
    tLOawUzIxgbmMJycrkiTDuKFpjBVPA=json.loads(tLOawUzIxgbmMJycrkiTDuKFpjBVoH.text)
    if not('stream' in tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']):return tLOawUzIxgbmMJycrkiTDuKFpjBVPd,tLOawUzIxgbmMJycrkiTDuKFpjBVPR 
    tLOawUzIxgbmMJycrkiTDuKFpjBVPn=tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']['stream']
    tLOawUzIxgbmMJycrkiTDuKFpjBVPh=tLOawUzIxgbmMJycrkiTDuKFpjBVPn['quality']
    tLOawUzIxgbmMJycrkiTDuKFpjBVPX=[]
    for tLOawUzIxgbmMJycrkiTDuKFpjBVPs in tLOawUzIxgbmMJycrkiTDuKFpjBVPh:
     if tLOawUzIxgbmMJycrkiTDuKFpjBVPs['active']=='Y':
      tLOawUzIxgbmMJycrkiTDuKFpjBVPX.append({tLOawUzIxgbmMJycrkiTDuKFpjBVod.get(tLOawUzIxgbmMJycrkiTDuKFpjBVPs['code']):tLOawUzIxgbmMJycrkiTDuKFpjBVPs['code']})
    tLOawUzIxgbmMJycrkiTDuKFpjBVPl=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.CheckQuality(sel_quality,tLOawUzIxgbmMJycrkiTDuKFpjBVPX)
   else:
    for tLOawUzIxgbmMJycrkiTDuKFpjBVPW,tLOawUzIxgbmMJycrkiTDuKFpjBVEo in tLOawUzIxgbmMJycrkiTDuKFpjBVod.items():
     if tLOawUzIxgbmMJycrkiTDuKFpjBVEo==sel_quality:
      tLOawUzIxgbmMJycrkiTDuKFpjBVPl=tLOawUzIxgbmMJycrkiTDuKFpjBVPW
  except tLOawUzIxgbmMJycrkiTDuKFpjBVRE as exception:
   tLOawUzIxgbmMJycrkiTDuKFpjBVRd(exception)
   for tLOawUzIxgbmMJycrkiTDuKFpjBVPW,tLOawUzIxgbmMJycrkiTDuKFpjBVEo in tLOawUzIxgbmMJycrkiTDuKFpjBVod.items():
    if tLOawUzIxgbmMJycrkiTDuKFpjBVEo==sel_quality:
     tLOawUzIxgbmMJycrkiTDuKFpjBVPl=tLOawUzIxgbmMJycrkiTDuKFpjBVPW
   return tLOawUzIxgbmMJycrkiTDuKFpjBVPd,tLOawUzIxgbmMJycrkiTDuKFpjBVPR
  try:
   tLOawUzIxgbmMJycrkiTDuKFpjBVPQ ='/streaming/info'
   tLOawUzIxgbmMJycrkiTDuKFpjBVPq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetDefaultParams()
   if stype=='onair':tLOawUzIxgbmMJycrkiTDuKFpjBVPq['osCode']='CSOD0400' 
   tLOawUzIxgbmMJycrkiTDuKFpjBVPG={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2158.7350000045262','returnValue':'true','cancelBubble':'false'}
   tLOawUzIxgbmMJycrkiTDuKFpjBVPS=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeOocUrl(tLOawUzIxgbmMJycrkiTDuKFpjBVPG)
   tLOawUzIxgbmMJycrkiTDuKFpjBVPN=urllib.parse.quote(tLOawUzIxgbmMJycrkiTDuKFpjBVPS)
   tLOawUzIxgbmMJycrkiTDuKFpjBVPf={'info':'Y','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':tLOawUzIxgbmMJycrkiTDuKFpjBVPl,'adReq':'none','ooc':tLOawUzIxgbmMJycrkiTDuKFpjBVPS,'deviceId':tLOawUzIxgbmMJycrkiTDuKFpjBVPC}
   tLOawUzIxgbmMJycrkiTDuKFpjBVPY =tLOawUzIxgbmMJycrkiTDuKFpjBVPq
   tLOawUzIxgbmMJycrkiTDuKFpjBVPY.update(tLOawUzIxgbmMJycrkiTDuKFpjBVPf)
   tLOawUzIxgbmMJycrkiTDuKFpjBVos=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.URL_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVPQ
   tLOawUzIxgbmMJycrkiTDuKFpjBVPv={'origin':'https://www.tving.com','Referer':'https://www.tving.com/vod/player/'+mediacode}
   tLOawUzIxgbmMJycrkiTDuKFpjBVoq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeDefaultCookies()
   tLOawUzIxgbmMJycrkiTDuKFpjBVoq['onClickEvent2']=tLOawUzIxgbmMJycrkiTDuKFpjBVPN
   tLOawUzIxgbmMJycrkiTDuKFpjBVoH=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.callRequestCookies('Post',tLOawUzIxgbmMJycrkiTDuKFpjBVos,payload=tLOawUzIxgbmMJycrkiTDuKFpjBVPY,params=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVPv,cookies=tLOawUzIxgbmMJycrkiTDuKFpjBVoq)
   tLOawUzIxgbmMJycrkiTDuKFpjBVPA=json.loads(tLOawUzIxgbmMJycrkiTDuKFpjBVoH.text)
   if 'drm_license_assertion' in tLOawUzIxgbmMJycrkiTDuKFpjBVPA['stream']:
    tLOawUzIxgbmMJycrkiTDuKFpjBVPR =tLOawUzIxgbmMJycrkiTDuKFpjBVPA['stream']['drm_license_assertion']
    tLOawUzIxgbmMJycrkiTDuKFpjBVPd=tLOawUzIxgbmMJycrkiTDuKFpjBVPA['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in tLOawUzIxgbmMJycrkiTDuKFpjBVPA['stream']['broadcast']):return tLOawUzIxgbmMJycrkiTDuKFpjBVPd,tLOawUzIxgbmMJycrkiTDuKFpjBVPR
    tLOawUzIxgbmMJycrkiTDuKFpjBVPd=tLOawUzIxgbmMJycrkiTDuKFpjBVPA['stream']['broadcast']['broad_url']
  except tLOawUzIxgbmMJycrkiTDuKFpjBVRE as exception:
   tLOawUzIxgbmMJycrkiTDuKFpjBVRd(exception)
  return tLOawUzIxgbmMJycrkiTDuKFpjBVPd,tLOawUzIxgbmMJycrkiTDuKFpjBVPR
 def CheckQuality(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,sel_qt,tLOawUzIxgbmMJycrkiTDuKFpjBVPX):
  for tLOawUzIxgbmMJycrkiTDuKFpjBVPH in tLOawUzIxgbmMJycrkiTDuKFpjBVPX:
   if sel_qt>=tLOawUzIxgbmMJycrkiTDuKFpjBVRQ(tLOawUzIxgbmMJycrkiTDuKFpjBVPH)[0]:return tLOawUzIxgbmMJycrkiTDuKFpjBVPH.get(tLOawUzIxgbmMJycrkiTDuKFpjBVRQ(tLOawUzIxgbmMJycrkiTDuKFpjBVPH)[0])
   tLOawUzIxgbmMJycrkiTDuKFpjBVPe=tLOawUzIxgbmMJycrkiTDuKFpjBVPH.get(tLOawUzIxgbmMJycrkiTDuKFpjBVRQ(tLOawUzIxgbmMJycrkiTDuKFpjBVPH)[0])
  return tLOawUzIxgbmMJycrkiTDuKFpjBVPe
 def makeOocUrl(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,tLOawUzIxgbmMJycrkiTDuKFpjBVPG):
  tLOawUzIxgbmMJycrkiTDuKFpjBVos=''
  for tLOawUzIxgbmMJycrkiTDuKFpjBVPW,tLOawUzIxgbmMJycrkiTDuKFpjBVEo in tLOawUzIxgbmMJycrkiTDuKFpjBVPG.items():
   tLOawUzIxgbmMJycrkiTDuKFpjBVos+="%s=%s^"%(tLOawUzIxgbmMJycrkiTDuKFpjBVPW,tLOawUzIxgbmMJycrkiTDuKFpjBVEo)
  return tLOawUzIxgbmMJycrkiTDuKFpjBVos
 def GetLiveChannelList(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,stype,page_int):
  tLOawUzIxgbmMJycrkiTDuKFpjBVEP=[]
  tLOawUzIxgbmMJycrkiTDuKFpjBVEd=tLOawUzIxgbmMJycrkiTDuKFpjBVde
  try:
   tLOawUzIxgbmMJycrkiTDuKFpjBVPQ ='/v2/media/lives'
   if stype=='onair':
    tLOawUzIxgbmMJycrkiTDuKFpjBVER='CPCS0100,CPCS0400'
   else:
    tLOawUzIxgbmMJycrkiTDuKFpjBVER='CPCS0300'
   tLOawUzIxgbmMJycrkiTDuKFpjBVPq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetDefaultParams()
   tLOawUzIxgbmMJycrkiTDuKFpjBVPf={'pageNo':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(page_int),'pageSize':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':tLOawUzIxgbmMJycrkiTDuKFpjBVER,'_':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetNoCache(2))}
   tLOawUzIxgbmMJycrkiTDuKFpjBVPq.update(tLOawUzIxgbmMJycrkiTDuKFpjBVPf)
   tLOawUzIxgbmMJycrkiTDuKFpjBVos=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeurl(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.API_DOMAIN,tLOawUzIxgbmMJycrkiTDuKFpjBVPQ)
   tLOawUzIxgbmMJycrkiTDuKFpjBVoq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeDefaultCookies()
   tLOawUzIxgbmMJycrkiTDuKFpjBVoH=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.callRequestCookies('Get',tLOawUzIxgbmMJycrkiTDuKFpjBVos,payload=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,params=tLOawUzIxgbmMJycrkiTDuKFpjBVPq,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,cookies=tLOawUzIxgbmMJycrkiTDuKFpjBVoq)
   tLOawUzIxgbmMJycrkiTDuKFpjBVPA=json.loads(tLOawUzIxgbmMJycrkiTDuKFpjBVoH.text)
   if not('result' in tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']):return tLOawUzIxgbmMJycrkiTDuKFpjBVEP,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
   tLOawUzIxgbmMJycrkiTDuKFpjBVEC=tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']['result']
   for tLOawUzIxgbmMJycrkiTDuKFpjBVPs in tLOawUzIxgbmMJycrkiTDuKFpjBVEC:
    tLOawUzIxgbmMJycrkiTDuKFpjBVEQ={}
    tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['mediatype']='video'
    tLOawUzIxgbmMJycrkiTDuKFpjBVEq=tLOawUzIxgbmMJycrkiTDuKFpjBVEn=tLOawUzIxgbmMJycrkiTDuKFpjBVEh=tLOawUzIxgbmMJycrkiTDuKFpjBVEX=''
    tLOawUzIxgbmMJycrkiTDuKFpjBVEf=tLOawUzIxgbmMJycrkiTDuKFpjBVEG=''
    tLOawUzIxgbmMJycrkiTDuKFpjBVEA=tLOawUzIxgbmMJycrkiTDuKFpjBVPs['live_code']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEq =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['channel']['name']['ko']
    if tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['episode']!=tLOawUzIxgbmMJycrkiTDuKFpjBVdH:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEn =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['program']['name']['ko']
     tLOawUzIxgbmMJycrkiTDuKFpjBVEn =tLOawUzIxgbmMJycrkiTDuKFpjBVEn+', '+tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['episode']['frequency'])+'회'
     if tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['episode']['image']!=[]:
      tLOawUzIxgbmMJycrkiTDuKFpjBVEh=tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['episode']['image'][0]['url']
     tLOawUzIxgbmMJycrkiTDuKFpjBVEX=tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['episode']['synopsis']['ko']
    else:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEn =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['program']['name']['ko']
     if tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['program']['image']!=[]:
      tLOawUzIxgbmMJycrkiTDuKFpjBVEh=tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['program']['image'][0]['url']
     tLOawUzIxgbmMJycrkiTDuKFpjBVEX=tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['program']['synopsis']['ko']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['title'] =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['program']['name']['ko']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['studio'] =tLOawUzIxgbmMJycrkiTDuKFpjBVEq
    try:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEs=[]
     for tLOawUzIxgbmMJycrkiTDuKFpjBVEl in tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('schedule').get('program').get('actor'):tLOawUzIxgbmMJycrkiTDuKFpjBVEs.append(tLOawUzIxgbmMJycrkiTDuKFpjBVEl)
     if tLOawUzIxgbmMJycrkiTDuKFpjBVEs[0]!='' and tLOawUzIxgbmMJycrkiTDuKFpjBVEs[0]!=u'없음':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['cast']=tLOawUzIxgbmMJycrkiTDuKFpjBVEs
    except:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdH
    try:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEW=[]
     if tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('schedule').get('program').get('category1_name').get('ko')!='':
      tLOawUzIxgbmMJycrkiTDuKFpjBVEW.append(tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['program']['category1_name']['ko'])
     if tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('schedule').get('program').get('category2_name').get('ko')!='':
      tLOawUzIxgbmMJycrkiTDuKFpjBVEW.append(tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['program']['category2_name']['ko'])
     if tLOawUzIxgbmMJycrkiTDuKFpjBVEW[0]!='':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['genre']=tLOawUzIxgbmMJycrkiTDuKFpjBVEW
    except:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdH
    if tLOawUzIxgbmMJycrkiTDuKFpjBVEh=='':
     tLOawUzIxgbmMJycrkiTDuKFpjBVEh=tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['channel']['image'][0]['url']
    if tLOawUzIxgbmMJycrkiTDuKFpjBVEh!='':tLOawUzIxgbmMJycrkiTDuKFpjBVEh=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVEh
    tLOawUzIxgbmMJycrkiTDuKFpjBVEf=tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['broadcast_start_time'])[8:12]
    tLOawUzIxgbmMJycrkiTDuKFpjBVEG =tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVPs['schedule']['broadcast_end_time'])[8:12]
    tLOawUzIxgbmMJycrkiTDuKFpjBVES={'channel':tLOawUzIxgbmMJycrkiTDuKFpjBVEq,'title':tLOawUzIxgbmMJycrkiTDuKFpjBVEn,'mediacode':tLOawUzIxgbmMJycrkiTDuKFpjBVEA,'thumbnail':tLOawUzIxgbmMJycrkiTDuKFpjBVEh,'synopsis':tLOawUzIxgbmMJycrkiTDuKFpjBVEX,'channelepg':' [%s:%s ~ %s:%s]'%(tLOawUzIxgbmMJycrkiTDuKFpjBVEf[0:2],tLOawUzIxgbmMJycrkiTDuKFpjBVEf[2:],tLOawUzIxgbmMJycrkiTDuKFpjBVEG[0:2],tLOawUzIxgbmMJycrkiTDuKFpjBVEG[2:]),'info':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ}
    tLOawUzIxgbmMJycrkiTDuKFpjBVEP.append(tLOawUzIxgbmMJycrkiTDuKFpjBVES)
   if tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']['has_more']=='Y':tLOawUzIxgbmMJycrkiTDuKFpjBVEd=tLOawUzIxgbmMJycrkiTDuKFpjBVRP
  except tLOawUzIxgbmMJycrkiTDuKFpjBVRE as exception:
   tLOawUzIxgbmMJycrkiTDuKFpjBVRd(exception)
  return tLOawUzIxgbmMJycrkiTDuKFpjBVEP,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
 def GetProgramList(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,stype,orderby,page_int,landyn=tLOawUzIxgbmMJycrkiTDuKFpjBVde):
  tLOawUzIxgbmMJycrkiTDuKFpjBVEP=[]
  tLOawUzIxgbmMJycrkiTDuKFpjBVEd=tLOawUzIxgbmMJycrkiTDuKFpjBVde
  try:
   tLOawUzIxgbmMJycrkiTDuKFpjBVPQ ='/v2/media/episodes'
   tLOawUzIxgbmMJycrkiTDuKFpjBVPq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetDefaultParams()
   tLOawUzIxgbmMJycrkiTDuKFpjBVPf={'pageNo':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(page_int),'pageSize':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetNoCache(2))}
   if stype!='all':tLOawUzIxgbmMJycrkiTDuKFpjBVPf['multiCategoryCode']=stype
   tLOawUzIxgbmMJycrkiTDuKFpjBVPq.update(tLOawUzIxgbmMJycrkiTDuKFpjBVPf)
   tLOawUzIxgbmMJycrkiTDuKFpjBVos=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeurl(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.API_DOMAIN,tLOawUzIxgbmMJycrkiTDuKFpjBVPQ)
   tLOawUzIxgbmMJycrkiTDuKFpjBVoq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeDefaultCookies()
   tLOawUzIxgbmMJycrkiTDuKFpjBVoH=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.callRequestCookies('Get',tLOawUzIxgbmMJycrkiTDuKFpjBVos,payload=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,params=tLOawUzIxgbmMJycrkiTDuKFpjBVPq,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,cookies=tLOawUzIxgbmMJycrkiTDuKFpjBVoq)
   tLOawUzIxgbmMJycrkiTDuKFpjBVPA=json.loads(tLOawUzIxgbmMJycrkiTDuKFpjBVoH.text)
   if not('result' in tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']):return tLOawUzIxgbmMJycrkiTDuKFpjBVEP,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
   tLOawUzIxgbmMJycrkiTDuKFpjBVEC=tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']['result']
   for tLOawUzIxgbmMJycrkiTDuKFpjBVPs in tLOawUzIxgbmMJycrkiTDuKFpjBVEC:
    tLOawUzIxgbmMJycrkiTDuKFpjBVEN=tLOawUzIxgbmMJycrkiTDuKFpjBVPs['program']['code']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEn =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['program']['name']['ko']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEh =tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVPs['program']['image'][0]['url']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEY='CAIP0200' if landyn else 'CAIP0900' 
    for tLOawUzIxgbmMJycrkiTDuKFpjBVEv in tLOawUzIxgbmMJycrkiTDuKFpjBVPs['program']['image']:
     if tLOawUzIxgbmMJycrkiTDuKFpjBVEv['code']==tLOawUzIxgbmMJycrkiTDuKFpjBVEY:
      tLOawUzIxgbmMJycrkiTDuKFpjBVEh =tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVEv['url']
      break
    tLOawUzIxgbmMJycrkiTDuKFpjBVEX =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['program']['synopsis']['ko']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEH=tLOawUzIxgbmMJycrkiTDuKFpjBVPs['program']['channel_code']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEQ={}
    tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['title'] =tLOawUzIxgbmMJycrkiTDuKFpjBVEn 
    tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['mediatype']='episode' 
    try:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEs=[]
     for tLOawUzIxgbmMJycrkiTDuKFpjBVEl in tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('program').get('actor'):tLOawUzIxgbmMJycrkiTDuKFpjBVEs.append(tLOawUzIxgbmMJycrkiTDuKFpjBVEl)
     if tLOawUzIxgbmMJycrkiTDuKFpjBVEs[0]!='' and tLOawUzIxgbmMJycrkiTDuKFpjBVEs[0]!='-':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['cast']=tLOawUzIxgbmMJycrkiTDuKFpjBVEs
    except:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdH
    try:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEe=[]
     for tLOawUzIxgbmMJycrkiTDuKFpjBVdo in tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('program').get('director'):tLOawUzIxgbmMJycrkiTDuKFpjBVEe.append(tLOawUzIxgbmMJycrkiTDuKFpjBVdo)
     if tLOawUzIxgbmMJycrkiTDuKFpjBVEe[0]!='' and tLOawUzIxgbmMJycrkiTDuKFpjBVEe[0]!='-':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['director']=tLOawUzIxgbmMJycrkiTDuKFpjBVEe
    except:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdH
    tLOawUzIxgbmMJycrkiTDuKFpjBVEW=[]
    if tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('program').get('category1_name').get('ko')!='':
     tLOawUzIxgbmMJycrkiTDuKFpjBVEW.append(tLOawUzIxgbmMJycrkiTDuKFpjBVPs['program']['category1_name']['ko'])
    if tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('program').get('category2_name').get('ko')!='':
     tLOawUzIxgbmMJycrkiTDuKFpjBVEW.append(tLOawUzIxgbmMJycrkiTDuKFpjBVPs['program']['category2_name']['ko'])
    if tLOawUzIxgbmMJycrkiTDuKFpjBVEW[0]!='':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['genre']=tLOawUzIxgbmMJycrkiTDuKFpjBVEW
    try:
     if tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('program').get('product_year'):tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['year']=tLOawUzIxgbmMJycrkiTDuKFpjBVPs['program']['product_year']
     if 'broad_dt' in tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('program'):
      tLOawUzIxgbmMJycrkiTDuKFpjBVdP=tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('program').get('broad_dt')
      tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['aired']='%s-%s-%s'%(tLOawUzIxgbmMJycrkiTDuKFpjBVdP[:4],tLOawUzIxgbmMJycrkiTDuKFpjBVdP[4:6],tLOawUzIxgbmMJycrkiTDuKFpjBVdP[6:])
    except:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdH
    tLOawUzIxgbmMJycrkiTDuKFpjBVES={'program':tLOawUzIxgbmMJycrkiTDuKFpjBVEN,'title':tLOawUzIxgbmMJycrkiTDuKFpjBVEn,'thumbnail':tLOawUzIxgbmMJycrkiTDuKFpjBVEh,'synopsis':tLOawUzIxgbmMJycrkiTDuKFpjBVEX,'channel':tLOawUzIxgbmMJycrkiTDuKFpjBVEH,'info':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ}
    tLOawUzIxgbmMJycrkiTDuKFpjBVEP.append(tLOawUzIxgbmMJycrkiTDuKFpjBVES)
   if tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']['has_more']=='Y':tLOawUzIxgbmMJycrkiTDuKFpjBVEd=tLOawUzIxgbmMJycrkiTDuKFpjBVRP
  except tLOawUzIxgbmMJycrkiTDuKFpjBVRE as exception:
   tLOawUzIxgbmMJycrkiTDuKFpjBVRd(exception)
  return tLOawUzIxgbmMJycrkiTDuKFpjBVEP,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
 def GetEpisodoList(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,program_code,page_int,orderby='desc'):
  tLOawUzIxgbmMJycrkiTDuKFpjBVEP=[]
  tLOawUzIxgbmMJycrkiTDuKFpjBVEd=tLOawUzIxgbmMJycrkiTDuKFpjBVde
  try:
   tLOawUzIxgbmMJycrkiTDuKFpjBVPQ ='/v2/media/frequency/program/'+program_code
   tLOawUzIxgbmMJycrkiTDuKFpjBVPq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetDefaultParams()
   tLOawUzIxgbmMJycrkiTDuKFpjBVPf={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetNoCache(2))}
   tLOawUzIxgbmMJycrkiTDuKFpjBVPq.update(tLOawUzIxgbmMJycrkiTDuKFpjBVPf)
   tLOawUzIxgbmMJycrkiTDuKFpjBVos=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeurl(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.API_DOMAIN,tLOawUzIxgbmMJycrkiTDuKFpjBVPQ)
   tLOawUzIxgbmMJycrkiTDuKFpjBVoq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeDefaultCookies()
   tLOawUzIxgbmMJycrkiTDuKFpjBVoH=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.callRequestCookies('Get',tLOawUzIxgbmMJycrkiTDuKFpjBVos,payload=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,params=tLOawUzIxgbmMJycrkiTDuKFpjBVPq,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,cookies=tLOawUzIxgbmMJycrkiTDuKFpjBVoq)
   tLOawUzIxgbmMJycrkiTDuKFpjBVPA=json.loads(tLOawUzIxgbmMJycrkiTDuKFpjBVoH.text)
   if not('result' in tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']):return tLOawUzIxgbmMJycrkiTDuKFpjBVEP,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
   tLOawUzIxgbmMJycrkiTDuKFpjBVEC=tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']['result']
   tLOawUzIxgbmMJycrkiTDuKFpjBVdE=tLOawUzIxgbmMJycrkiTDuKFpjBVRo(tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']['total_count'])
   tLOawUzIxgbmMJycrkiTDuKFpjBVdR =tLOawUzIxgbmMJycrkiTDuKFpjBVRo(tLOawUzIxgbmMJycrkiTDuKFpjBVdE//(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    tLOawUzIxgbmMJycrkiTDuKFpjBVdC =(tLOawUzIxgbmMJycrkiTDuKFpjBVdE-1)-((page_int-1)*tLOawUzIxgbmMJycrkiTDuKFpjBVoR.EPISODE_LIMIT)
   else:
    tLOawUzIxgbmMJycrkiTDuKFpjBVdC =(page_int-1)*tLOawUzIxgbmMJycrkiTDuKFpjBVoR.EPISODE_LIMIT
   for i in tLOawUzIxgbmMJycrkiTDuKFpjBVRq(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.EPISODE_LIMIT):
    if orderby=='desc':
     tLOawUzIxgbmMJycrkiTDuKFpjBVdQ=tLOawUzIxgbmMJycrkiTDuKFpjBVdC-i
     if tLOawUzIxgbmMJycrkiTDuKFpjBVdQ<0:break
    else:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdQ=tLOawUzIxgbmMJycrkiTDuKFpjBVdC+i
     if tLOawUzIxgbmMJycrkiTDuKFpjBVdQ>=tLOawUzIxgbmMJycrkiTDuKFpjBVdE:break
    tLOawUzIxgbmMJycrkiTDuKFpjBVdq=tLOawUzIxgbmMJycrkiTDuKFpjBVEC[tLOawUzIxgbmMJycrkiTDuKFpjBVdQ]['episode']['code']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEn =tLOawUzIxgbmMJycrkiTDuKFpjBVEC[tLOawUzIxgbmMJycrkiTDuKFpjBVdQ]['vod_name']['ko']
    tLOawUzIxgbmMJycrkiTDuKFpjBVdf =''
    try:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdP=tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVEC[tLOawUzIxgbmMJycrkiTDuKFpjBVdQ]['episode']['broadcast_date'])
     tLOawUzIxgbmMJycrkiTDuKFpjBVdf='%s-%s-%s'%(tLOawUzIxgbmMJycrkiTDuKFpjBVdP[:4],tLOawUzIxgbmMJycrkiTDuKFpjBVdP[4:6],tLOawUzIxgbmMJycrkiTDuKFpjBVdP[6:])
    except:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdH
    if tLOawUzIxgbmMJycrkiTDuKFpjBVEC[tLOawUzIxgbmMJycrkiTDuKFpjBVdQ]['episode']['image']!=[]:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEh=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVEC[tLOawUzIxgbmMJycrkiTDuKFpjBVdQ]['episode']['image'][0]['url']
    else:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEh=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVEC[tLOawUzIxgbmMJycrkiTDuKFpjBVdQ]['program']['image'][0]['url']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEX =tLOawUzIxgbmMJycrkiTDuKFpjBVEC[tLOawUzIxgbmMJycrkiTDuKFpjBVdQ]['episode']['synopsis']['ko']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEQ={}
    tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['mediatype']='episode' 
    try:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['title'] =tLOawUzIxgbmMJycrkiTDuKFpjBVEC[tLOawUzIxgbmMJycrkiTDuKFpjBVdQ]['program']['name']['ko']
     tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['aired'] =tLOawUzIxgbmMJycrkiTDuKFpjBVdf
     tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['studio'] =tLOawUzIxgbmMJycrkiTDuKFpjBVEC[tLOawUzIxgbmMJycrkiTDuKFpjBVdQ]['channel']['name']['ko']
     if 'frequency' in tLOawUzIxgbmMJycrkiTDuKFpjBVEC[tLOawUzIxgbmMJycrkiTDuKFpjBVdQ]['episode']:tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['episode']=tLOawUzIxgbmMJycrkiTDuKFpjBVEC[tLOawUzIxgbmMJycrkiTDuKFpjBVdQ]['episode']['frequency']
    except:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdH
    tLOawUzIxgbmMJycrkiTDuKFpjBVES={'episode':tLOawUzIxgbmMJycrkiTDuKFpjBVdq,'title':tLOawUzIxgbmMJycrkiTDuKFpjBVEn,'subtitle':tLOawUzIxgbmMJycrkiTDuKFpjBVdf,'thumbnail':tLOawUzIxgbmMJycrkiTDuKFpjBVEh,'synopsis':tLOawUzIxgbmMJycrkiTDuKFpjBVEX,'info':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ}
    tLOawUzIxgbmMJycrkiTDuKFpjBVEP.append(tLOawUzIxgbmMJycrkiTDuKFpjBVES)
   if tLOawUzIxgbmMJycrkiTDuKFpjBVdR>page_int:tLOawUzIxgbmMJycrkiTDuKFpjBVEd=tLOawUzIxgbmMJycrkiTDuKFpjBVRP
  except tLOawUzIxgbmMJycrkiTDuKFpjBVRE as exception:
   tLOawUzIxgbmMJycrkiTDuKFpjBVRd(exception)
  return tLOawUzIxgbmMJycrkiTDuKFpjBVEP,tLOawUzIxgbmMJycrkiTDuKFpjBVEd,tLOawUzIxgbmMJycrkiTDuKFpjBVdR
 def GetMovieList(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,orderby,page_int,premiumyn=tLOawUzIxgbmMJycrkiTDuKFpjBVde,landyn=tLOawUzIxgbmMJycrkiTDuKFpjBVde):
  tLOawUzIxgbmMJycrkiTDuKFpjBVEP=[]
  tLOawUzIxgbmMJycrkiTDuKFpjBVEd=tLOawUzIxgbmMJycrkiTDuKFpjBVde
  if premiumyn==tLOawUzIxgbmMJycrkiTDuKFpjBVRP:
   tLOawUzIxgbmMJycrkiTDuKFpjBVdA=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.MOVIE_LITE+','+tLOawUzIxgbmMJycrkiTDuKFpjBVoR.MOVIE_PREMIUM
  else:
   tLOawUzIxgbmMJycrkiTDuKFpjBVdA=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.MOVIE_LITE
  try:
   tLOawUzIxgbmMJycrkiTDuKFpjBVPQ ='/v2/media/movies'
   tLOawUzIxgbmMJycrkiTDuKFpjBVPq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetDefaultParams()
   tLOawUzIxgbmMJycrkiTDuKFpjBVPf={'pageNo':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(page_int),'pageSize':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','productPackageCode':tLOawUzIxgbmMJycrkiTDuKFpjBVdA,'_':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetNoCache(2))}
   tLOawUzIxgbmMJycrkiTDuKFpjBVPq.update(tLOawUzIxgbmMJycrkiTDuKFpjBVPf)
   tLOawUzIxgbmMJycrkiTDuKFpjBVos=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeurl(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.API_DOMAIN,tLOawUzIxgbmMJycrkiTDuKFpjBVPQ)
   tLOawUzIxgbmMJycrkiTDuKFpjBVoq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeDefaultCookies()
   tLOawUzIxgbmMJycrkiTDuKFpjBVoH=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.callRequestCookies('Get',tLOawUzIxgbmMJycrkiTDuKFpjBVos,payload=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,params=tLOawUzIxgbmMJycrkiTDuKFpjBVPq,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,cookies=tLOawUzIxgbmMJycrkiTDuKFpjBVoq)
   tLOawUzIxgbmMJycrkiTDuKFpjBVPA=json.loads(tLOawUzIxgbmMJycrkiTDuKFpjBVoH.text)
   if not('result' in tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']):return tLOawUzIxgbmMJycrkiTDuKFpjBVEP,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
   tLOawUzIxgbmMJycrkiTDuKFpjBVEC=tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']['result']
   for tLOawUzIxgbmMJycrkiTDuKFpjBVPs in tLOawUzIxgbmMJycrkiTDuKFpjBVEC:
    tLOawUzIxgbmMJycrkiTDuKFpjBVdn =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['movie']['code']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEn =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['movie']['name']['ko'].strip()
    tLOawUzIxgbmMJycrkiTDuKFpjBVEn +=u' (%s년)'%(tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('movie').get('product_year'))
    tLOawUzIxgbmMJycrkiTDuKFpjBVEh =tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVPs['movie']['image'][0]['url']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEY='CAIM0400' if landyn else 'CAIM2100' 
    for tLOawUzIxgbmMJycrkiTDuKFpjBVEv in tLOawUzIxgbmMJycrkiTDuKFpjBVPs['movie']['image']:
     if tLOawUzIxgbmMJycrkiTDuKFpjBVEv['code']==tLOawUzIxgbmMJycrkiTDuKFpjBVEY:
      tLOawUzIxgbmMJycrkiTDuKFpjBVEh =tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVEv['url']
      break
    tLOawUzIxgbmMJycrkiTDuKFpjBVEX =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['movie']['story']['ko']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEQ={}
    tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['mediatype']='movie' 
    tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['title'] = tLOawUzIxgbmMJycrkiTDuKFpjBVPs['movie']['name']['ko'].strip()
    tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['year'] =tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('movie').get('product_year')
    try:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEs=[]
     for tLOawUzIxgbmMJycrkiTDuKFpjBVEl in tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('movie').get('actor'):tLOawUzIxgbmMJycrkiTDuKFpjBVEs.append(tLOawUzIxgbmMJycrkiTDuKFpjBVEl)
     if tLOawUzIxgbmMJycrkiTDuKFpjBVEs[0]!='':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['cast']=tLOawUzIxgbmMJycrkiTDuKFpjBVEs
    except:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdH
    try:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEe=[]
     for tLOawUzIxgbmMJycrkiTDuKFpjBVdo in tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('movie').get('director'):tLOawUzIxgbmMJycrkiTDuKFpjBVEe.append(tLOawUzIxgbmMJycrkiTDuKFpjBVdo)
     if tLOawUzIxgbmMJycrkiTDuKFpjBVEe[0]!='':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['director']=tLOawUzIxgbmMJycrkiTDuKFpjBVEe
    except:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdH
    try:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEW=[]
     if tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('movie').get('category1_name').get('ko')!='':
      tLOawUzIxgbmMJycrkiTDuKFpjBVEW.append(tLOawUzIxgbmMJycrkiTDuKFpjBVPs['movie']['category1_name']['ko'])
     if tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('movie').get('category2_name').get('ko')!='':
      tLOawUzIxgbmMJycrkiTDuKFpjBVEW.append(tLOawUzIxgbmMJycrkiTDuKFpjBVPs['movie']['category2_name']['ko'])
     if tLOawUzIxgbmMJycrkiTDuKFpjBVEW[0]!='':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['genre']=tLOawUzIxgbmMJycrkiTDuKFpjBVEW
    except:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdH
    try:
     if 'release_date' in tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('movie'):
      tLOawUzIxgbmMJycrkiTDuKFpjBVdP=tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('movie').get('release_date'))
      tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['aired']='%s-%s-%s'%(tLOawUzIxgbmMJycrkiTDuKFpjBVdP[:4],tLOawUzIxgbmMJycrkiTDuKFpjBVdP[4:6],tLOawUzIxgbmMJycrkiTDuKFpjBVdP[6:])
    except:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdH
    try:
     if 'duration' in tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('movie'):tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['duration']=tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('movie').get('duration')
    except:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdH
    tLOawUzIxgbmMJycrkiTDuKFpjBVES={'moviecode':tLOawUzIxgbmMJycrkiTDuKFpjBVdn,'title':tLOawUzIxgbmMJycrkiTDuKFpjBVEn,'thumbnail':tLOawUzIxgbmMJycrkiTDuKFpjBVEh,'synopsis':tLOawUzIxgbmMJycrkiTDuKFpjBVEX,'info':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ}
    if premiumyn==tLOawUzIxgbmMJycrkiTDuKFpjBVRP:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdh=tLOawUzIxgbmMJycrkiTDuKFpjBVde
     for tLOawUzIxgbmMJycrkiTDuKFpjBVdX in tLOawUzIxgbmMJycrkiTDuKFpjBVPs['billing_package_id']:
      if tLOawUzIxgbmMJycrkiTDuKFpjBVdX==tLOawUzIxgbmMJycrkiTDuKFpjBVoR.MOVIE_LITE:
       tLOawUzIxgbmMJycrkiTDuKFpjBVdh=tLOawUzIxgbmMJycrkiTDuKFpjBVRP
       break
     if tLOawUzIxgbmMJycrkiTDuKFpjBVdh==tLOawUzIxgbmMJycrkiTDuKFpjBVde:
      tLOawUzIxgbmMJycrkiTDuKFpjBVES['title']=tLOawUzIxgbmMJycrkiTDuKFpjBVES['title']+' [Premium]'
    tLOawUzIxgbmMJycrkiTDuKFpjBVEP.append(tLOawUzIxgbmMJycrkiTDuKFpjBVES)
   if tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']['has_more']=='Y':tLOawUzIxgbmMJycrkiTDuKFpjBVEd=tLOawUzIxgbmMJycrkiTDuKFpjBVRP
  except tLOawUzIxgbmMJycrkiTDuKFpjBVRE as exception:
   tLOawUzIxgbmMJycrkiTDuKFpjBVRd(exception)
  return tLOawUzIxgbmMJycrkiTDuKFpjBVEP,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
 def GetMovieListGenre(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,genre,page_int,premiumyn=tLOawUzIxgbmMJycrkiTDuKFpjBVde):
  tLOawUzIxgbmMJycrkiTDuKFpjBVEP=[]
  tLOawUzIxgbmMJycrkiTDuKFpjBVEd=tLOawUzIxgbmMJycrkiTDuKFpjBVde
  if premiumyn==tLOawUzIxgbmMJycrkiTDuKFpjBVRP:
   tLOawUzIxgbmMJycrkiTDuKFpjBVdA=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.MOVIE_LITE+','+tLOawUzIxgbmMJycrkiTDuKFpjBVoR.MOVIE_PREMIUM
  else:
   tLOawUzIxgbmMJycrkiTDuKFpjBVdA=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.MOVIE_LITE
  try:
   tLOawUzIxgbmMJycrkiTDuKFpjBVPQ ='/v2/media/movie/curation/'+genre
   tLOawUzIxgbmMJycrkiTDuKFpjBVPq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetDefaultParams()
   tLOawUzIxgbmMJycrkiTDuKFpjBVPf={'pageNo':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(page_int),'pageSize':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.MOVIE_LIMIT),'productPackageCode':tLOawUzIxgbmMJycrkiTDuKFpjBVdA,'_':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetNoCache(2))}
   tLOawUzIxgbmMJycrkiTDuKFpjBVPq.update(tLOawUzIxgbmMJycrkiTDuKFpjBVPf)
   tLOawUzIxgbmMJycrkiTDuKFpjBVos=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeurl(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.API_DOMAIN,tLOawUzIxgbmMJycrkiTDuKFpjBVPQ)
   tLOawUzIxgbmMJycrkiTDuKFpjBVoq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeDefaultCookies()
   tLOawUzIxgbmMJycrkiTDuKFpjBVoH=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.callRequestCookies('Get',tLOawUzIxgbmMJycrkiTDuKFpjBVos,payload=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,params=tLOawUzIxgbmMJycrkiTDuKFpjBVPq,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,cookies=tLOawUzIxgbmMJycrkiTDuKFpjBVoq)
   tLOawUzIxgbmMJycrkiTDuKFpjBVPA=json.loads(tLOawUzIxgbmMJycrkiTDuKFpjBVoH.text)
   if not('movies' in tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']):return tLOawUzIxgbmMJycrkiTDuKFpjBVEP,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
   tLOawUzIxgbmMJycrkiTDuKFpjBVEC=tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']['movies']
   for tLOawUzIxgbmMJycrkiTDuKFpjBVPs in tLOawUzIxgbmMJycrkiTDuKFpjBVEC:
    tLOawUzIxgbmMJycrkiTDuKFpjBVdn =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['code']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEn =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['name']['ko']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEh =tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVPs['image'][0]['url']
    for tLOawUzIxgbmMJycrkiTDuKFpjBVEv in tLOawUzIxgbmMJycrkiTDuKFpjBVPs['image']:
     if tLOawUzIxgbmMJycrkiTDuKFpjBVEv['code']=='CAIM2100':
      tLOawUzIxgbmMJycrkiTDuKFpjBVEh =tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVEv['url']
    tLOawUzIxgbmMJycrkiTDuKFpjBVEX =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['story']['ko']
    tLOawUzIxgbmMJycrkiTDuKFpjBVES={'moviecode':tLOawUzIxgbmMJycrkiTDuKFpjBVdn,'title':tLOawUzIxgbmMJycrkiTDuKFpjBVEn.strip(),'thumbnail':tLOawUzIxgbmMJycrkiTDuKFpjBVEh,'synopsis':tLOawUzIxgbmMJycrkiTDuKFpjBVEX}
    if premiumyn==tLOawUzIxgbmMJycrkiTDuKFpjBVRP:
     tLOawUzIxgbmMJycrkiTDuKFpjBVdh=tLOawUzIxgbmMJycrkiTDuKFpjBVde
     for tLOawUzIxgbmMJycrkiTDuKFpjBVdX in tLOawUzIxgbmMJycrkiTDuKFpjBVPs['billing_package_id']:
      if tLOawUzIxgbmMJycrkiTDuKFpjBVdX==tLOawUzIxgbmMJycrkiTDuKFpjBVoR.MOVIE_LITE:
       tLOawUzIxgbmMJycrkiTDuKFpjBVdh=tLOawUzIxgbmMJycrkiTDuKFpjBVRP
       break
     if tLOawUzIxgbmMJycrkiTDuKFpjBVdh==tLOawUzIxgbmMJycrkiTDuKFpjBVde:
      tLOawUzIxgbmMJycrkiTDuKFpjBVES['title']=tLOawUzIxgbmMJycrkiTDuKFpjBVES['title']+' [Premium]'
    tLOawUzIxgbmMJycrkiTDuKFpjBVEP.append(tLOawUzIxgbmMJycrkiTDuKFpjBVES)
  except tLOawUzIxgbmMJycrkiTDuKFpjBVRE as exception:
   tLOawUzIxgbmMJycrkiTDuKFpjBVRd(exception)
  return tLOawUzIxgbmMJycrkiTDuKFpjBVEP,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
 def GetMovieGenre(tLOawUzIxgbmMJycrkiTDuKFpjBVoR):
  tLOawUzIxgbmMJycrkiTDuKFpjBVEP=[]
  tLOawUzIxgbmMJycrkiTDuKFpjBVEd=tLOawUzIxgbmMJycrkiTDuKFpjBVde
  try:
   tLOawUzIxgbmMJycrkiTDuKFpjBVPQ ='/v2/media/movie/curations'
   tLOawUzIxgbmMJycrkiTDuKFpjBVPq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetDefaultParams()
   tLOawUzIxgbmMJycrkiTDuKFpjBVPf={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetNoCache(2))}
   tLOawUzIxgbmMJycrkiTDuKFpjBVPq.update(tLOawUzIxgbmMJycrkiTDuKFpjBVPf)
   tLOawUzIxgbmMJycrkiTDuKFpjBVos=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeurl(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.API_DOMAIN,tLOawUzIxgbmMJycrkiTDuKFpjBVPQ)
   tLOawUzIxgbmMJycrkiTDuKFpjBVoq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeDefaultCookies()
   tLOawUzIxgbmMJycrkiTDuKFpjBVoH=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.callRequestCookies('Get',tLOawUzIxgbmMJycrkiTDuKFpjBVos,payload=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,params=tLOawUzIxgbmMJycrkiTDuKFpjBVPq,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,cookies=tLOawUzIxgbmMJycrkiTDuKFpjBVoq)
   tLOawUzIxgbmMJycrkiTDuKFpjBVPA=json.loads(tLOawUzIxgbmMJycrkiTDuKFpjBVoH.text)
   if not('result' in tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']):return tLOawUzIxgbmMJycrkiTDuKFpjBVEP,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
   tLOawUzIxgbmMJycrkiTDuKFpjBVEC=tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']['result']
   for tLOawUzIxgbmMJycrkiTDuKFpjBVPs in tLOawUzIxgbmMJycrkiTDuKFpjBVEC:
    tLOawUzIxgbmMJycrkiTDuKFpjBVds =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['curation_code']
    tLOawUzIxgbmMJycrkiTDuKFpjBVdl =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['curation_name']
    tLOawUzIxgbmMJycrkiTDuKFpjBVES={'curation_code':tLOawUzIxgbmMJycrkiTDuKFpjBVds,'curation_name':tLOawUzIxgbmMJycrkiTDuKFpjBVdl}
    tLOawUzIxgbmMJycrkiTDuKFpjBVEP.append(tLOawUzIxgbmMJycrkiTDuKFpjBVES)
  except tLOawUzIxgbmMJycrkiTDuKFpjBVRE as exception:
   tLOawUzIxgbmMJycrkiTDuKFpjBVRd(exception)
  return tLOawUzIxgbmMJycrkiTDuKFpjBVEP,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
 def GetSearchList(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,search_key,userid,page_int,stype,premiumyn=tLOawUzIxgbmMJycrkiTDuKFpjBVde,landyn=tLOawUzIxgbmMJycrkiTDuKFpjBVde):
  tLOawUzIxgbmMJycrkiTDuKFpjBVdW=[]
  tLOawUzIxgbmMJycrkiTDuKFpjBVEd=tLOawUzIxgbmMJycrkiTDuKFpjBVde
  try:
   tLOawUzIxgbmMJycrkiTDuKFpjBVPQ ='/search/getSearch.jsp'
   tLOawUzIxgbmMJycrkiTDuKFpjBVPf={'kwd':search_key,'notFoundText':search_key,'userid':userid,'siteName':'TVING_WEB','category':'TOTAL','pageNum':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(page_int),'pageSize':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':tLOawUzIxgbmMJycrkiTDuKFpjBVoR.SCREENCODE,'os':tLOawUzIxgbmMJycrkiTDuKFpjBVoR.OSCODE,'network':tLOawUzIxgbmMJycrkiTDuKFpjBVoR.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.SEARCH_LIMIT),'vodMVReqCnt':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.SEARCH_LIMIT),'smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':tLOawUzIxgbmMJycrkiTDuKFpjBVRC(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.GetNoCache(2))}
   tLOawUzIxgbmMJycrkiTDuKFpjBVos=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeurl(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.SEARCH_DOMAIN,tLOawUzIxgbmMJycrkiTDuKFpjBVPQ)
   tLOawUzIxgbmMJycrkiTDuKFpjBVoq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeDefaultCookies()
   tLOawUzIxgbmMJycrkiTDuKFpjBVoH=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.callRequestCookies('Get',tLOawUzIxgbmMJycrkiTDuKFpjBVos,payload=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,params=tLOawUzIxgbmMJycrkiTDuKFpjBVPf,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,cookies=tLOawUzIxgbmMJycrkiTDuKFpjBVoq)
   tLOawUzIxgbmMJycrkiTDuKFpjBVPA=json.loads(tLOawUzIxgbmMJycrkiTDuKFpjBVoH.text)
   if stype=='vod':
    if not('programRsb' in tLOawUzIxgbmMJycrkiTDuKFpjBVPA):return tLOawUzIxgbmMJycrkiTDuKFpjBVdW,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
    tLOawUzIxgbmMJycrkiTDuKFpjBVdG=tLOawUzIxgbmMJycrkiTDuKFpjBVPA['programRsb']['dataList']
    tLOawUzIxgbmMJycrkiTDuKFpjBVdS =tLOawUzIxgbmMJycrkiTDuKFpjBVRo(tLOawUzIxgbmMJycrkiTDuKFpjBVPA['programRsb']['count'])
    for tLOawUzIxgbmMJycrkiTDuKFpjBVPs in tLOawUzIxgbmMJycrkiTDuKFpjBVdG:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEN=tLOawUzIxgbmMJycrkiTDuKFpjBVPs['mast_cd']
     tLOawUzIxgbmMJycrkiTDuKFpjBVEn =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['mast_nm']
     tLOawUzIxgbmMJycrkiTDuKFpjBVEh =tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVPs['web_url']
     if landyn==tLOawUzIxgbmMJycrkiTDuKFpjBVde:
      tLOawUzIxgbmMJycrkiTDuKFpjBVEh =tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVPs['web_url4']
     tLOawUzIxgbmMJycrkiTDuKFpjBVEQ={}
     tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['title']=tLOawUzIxgbmMJycrkiTDuKFpjBVPs['mast_nm']
     tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['mediatype']='episode' 
     try:
      if tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('actor')!='' and tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('actor')!='-':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['cast'] =tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('actor').split(',')
      if tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('director')!='' and tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('director')!='-':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['director']=tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('director').split(',')
      if tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('cate_nm')!='':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['genre'] =tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('cate_nm').split('/')
      if 'targetage' in tLOawUzIxgbmMJycrkiTDuKFpjBVPs:tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['mpaa']=tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('targetage')
     except:
      tLOawUzIxgbmMJycrkiTDuKFpjBVdH
     try:
      if 'broad_dt' in tLOawUzIxgbmMJycrkiTDuKFpjBVPs:
       tLOawUzIxgbmMJycrkiTDuKFpjBVdP=tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('broad_dt')
       tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['aired']='%s-%s-%s'%(tLOawUzIxgbmMJycrkiTDuKFpjBVdP[:4],tLOawUzIxgbmMJycrkiTDuKFpjBVdP[4:6],tLOawUzIxgbmMJycrkiTDuKFpjBVdP[6:])
     except:
      tLOawUzIxgbmMJycrkiTDuKFpjBVdH
     tLOawUzIxgbmMJycrkiTDuKFpjBVES={'program':tLOawUzIxgbmMJycrkiTDuKFpjBVEN,'title':tLOawUzIxgbmMJycrkiTDuKFpjBVEn,'thumbnail':tLOawUzIxgbmMJycrkiTDuKFpjBVEh,'synopsis':'','info':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ}
     tLOawUzIxgbmMJycrkiTDuKFpjBVdW.append(tLOawUzIxgbmMJycrkiTDuKFpjBVES)
   else:
    if not('vodMVRsb' in tLOawUzIxgbmMJycrkiTDuKFpjBVPA):return tLOawUzIxgbmMJycrkiTDuKFpjBVdW,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
    tLOawUzIxgbmMJycrkiTDuKFpjBVdN=tLOawUzIxgbmMJycrkiTDuKFpjBVPA['vodMVRsb']['dataList']
    tLOawUzIxgbmMJycrkiTDuKFpjBVdS =tLOawUzIxgbmMJycrkiTDuKFpjBVRo(tLOawUzIxgbmMJycrkiTDuKFpjBVPA['vodMVRsb']['count'])
    for tLOawUzIxgbmMJycrkiTDuKFpjBVPs in tLOawUzIxgbmMJycrkiTDuKFpjBVdN:
     tLOawUzIxgbmMJycrkiTDuKFpjBVEN=tLOawUzIxgbmMJycrkiTDuKFpjBVPs['mast_cd']
     tLOawUzIxgbmMJycrkiTDuKFpjBVEn =tLOawUzIxgbmMJycrkiTDuKFpjBVPs['mast_nm'].strip()
     tLOawUzIxgbmMJycrkiTDuKFpjBVEh =tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVPs['web_url']
     if landyn==tLOawUzIxgbmMJycrkiTDuKFpjBVde:
      tLOawUzIxgbmMJycrkiTDuKFpjBVEh =tLOawUzIxgbmMJycrkiTDuKFpjBVoR.IMG_DOMAIN+tLOawUzIxgbmMJycrkiTDuKFpjBVPs['web_url5']
     tLOawUzIxgbmMJycrkiTDuKFpjBVEQ={}
     tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['title'] =tLOawUzIxgbmMJycrkiTDuKFpjBVEn
     tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['mediatype']='movie' 
     try:
      if tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('actor') !='':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['cast'] =tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('actor').split(',')
      if tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('cate_nm')!='':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['genre'] =tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('cate_nm').split('/')
      if tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('runtime_sec')!='':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['duration']=tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('runtime_sec')
      if 'grade_nm' in tLOawUzIxgbmMJycrkiTDuKFpjBVPs:tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['mpaa']=tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('grade_nm')
     except:
      tLOawUzIxgbmMJycrkiTDuKFpjBVdH
     try:
      tLOawUzIxgbmMJycrkiTDuKFpjBVdP=tLOawUzIxgbmMJycrkiTDuKFpjBVPs.get('broad_dt')
      if data_str!='':
       tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['aired']='%s-%s-%s'%(tLOawUzIxgbmMJycrkiTDuKFpjBVdP[:4],tLOawUzIxgbmMJycrkiTDuKFpjBVdP[4:6],tLOawUzIxgbmMJycrkiTDuKFpjBVdP[6:])
       tLOawUzIxgbmMJycrkiTDuKFpjBVEQ['year']=tLOawUzIxgbmMJycrkiTDuKFpjBVdP[:4]
     except:
      tLOawUzIxgbmMJycrkiTDuKFpjBVdH
     if tLOawUzIxgbmMJycrkiTDuKFpjBVRP:
      tLOawUzIxgbmMJycrkiTDuKFpjBVES={'movie':tLOawUzIxgbmMJycrkiTDuKFpjBVEN,'title':tLOawUzIxgbmMJycrkiTDuKFpjBVEn,'thumbnail':tLOawUzIxgbmMJycrkiTDuKFpjBVEh,'synopsis':'','info':tLOawUzIxgbmMJycrkiTDuKFpjBVEQ}
      tLOawUzIxgbmMJycrkiTDuKFpjBVdW.append(tLOawUzIxgbmMJycrkiTDuKFpjBVES)
  except tLOawUzIxgbmMJycrkiTDuKFpjBVRE as exception:
   tLOawUzIxgbmMJycrkiTDuKFpjBVRd(exception)
  return tLOawUzIxgbmMJycrkiTDuKFpjBVdW,tLOawUzIxgbmMJycrkiTDuKFpjBVEd
 def GetDeviceList(tLOawUzIxgbmMJycrkiTDuKFpjBVoR,tLOawUzIxgbmMJycrkiTDuKFpjBVoS,tLOawUzIxgbmMJycrkiTDuKFpjBVPo):
  tLOawUzIxgbmMJycrkiTDuKFpjBVEP=[]
  tLOawUzIxgbmMJycrkiTDuKFpjBVPC='-'
  try:
   tLOawUzIxgbmMJycrkiTDuKFpjBVPQ ='/v1/user/device/list'
   tLOawUzIxgbmMJycrkiTDuKFpjBVdY=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeurl(tLOawUzIxgbmMJycrkiTDuKFpjBVoR.API_DOMAIN,tLOawUzIxgbmMJycrkiTDuKFpjBVPQ)
   tLOawUzIxgbmMJycrkiTDuKFpjBVPf={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   tLOawUzIxgbmMJycrkiTDuKFpjBVoq=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.makeDefaultCookies(vToken=tLOawUzIxgbmMJycrkiTDuKFpjBVoS,vUserinfo=tLOawUzIxgbmMJycrkiTDuKFpjBVPo)
   tLOawUzIxgbmMJycrkiTDuKFpjBVoH=tLOawUzIxgbmMJycrkiTDuKFpjBVoR.callRequestCookies('Get',tLOawUzIxgbmMJycrkiTDuKFpjBVdY,payload=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,params=tLOawUzIxgbmMJycrkiTDuKFpjBVPf,headers=tLOawUzIxgbmMJycrkiTDuKFpjBVdH,cookies=tLOawUzIxgbmMJycrkiTDuKFpjBVoq)
   tLOawUzIxgbmMJycrkiTDuKFpjBVPA=json.loads(tLOawUzIxgbmMJycrkiTDuKFpjBVoH.text)
   tLOawUzIxgbmMJycrkiTDuKFpjBVEP=tLOawUzIxgbmMJycrkiTDuKFpjBVPA['body']
   for tLOawUzIxgbmMJycrkiTDuKFpjBVPs in tLOawUzIxgbmMJycrkiTDuKFpjBVEP:
    if tLOawUzIxgbmMJycrkiTDuKFpjBVPs['model']=='PC':
     tLOawUzIxgbmMJycrkiTDuKFpjBVPC=tLOawUzIxgbmMJycrkiTDuKFpjBVPs['uuid']
  except tLOawUzIxgbmMJycrkiTDuKFpjBVRE as exception:
   tLOawUzIxgbmMJycrkiTDuKFpjBVRd(exception)
  return tLOawUzIxgbmMJycrkiTDuKFpjBVPC
# Created by pyminifier (https://github.com/liftoff/pyminifier)
