__author__="NightRain"
rdfKicuzPTnpHJUjwXLOFQloMvsgbh=object
rdfKicuzPTnpHJUjwXLOFQloMvsgBN=None
rdfKicuzPTnpHJUjwXLOFQloMvsgBm=False
rdfKicuzPTnpHJUjwXLOFQloMvsgBD=True
rdfKicuzPTnpHJUjwXLOFQloMvsgBV=int
rdfKicuzPTnpHJUjwXLOFQloMvsgBb=len
rdfKicuzPTnpHJUjwXLOFQloMvsgBA=str
rdfKicuzPTnpHJUjwXLOFQloMvsgBW=open
rdfKicuzPTnpHJUjwXLOFQloMvsgBE=dict
rdfKicuzPTnpHJUjwXLOFQloMvsgBt=Exception
rdfKicuzPTnpHJUjwXLOFQloMvsgBS=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
rdfKicuzPTnpHJUjwXLOFQloMvsgND=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'VOD 방송 (인기순)','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 (최신순)','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'월정액 영화관 (인기)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'-'},{'title':'월정액 영화관 (최신)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'검색 (search)','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-'}]
rdfKicuzPTnpHJUjwXLOFQloMvsgNV=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
rdfKicuzPTnpHJUjwXLOFQloMvsgNb=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
rdfKicuzPTnpHJUjwXLOFQloMvsgNB=[{'title':'VOD 검색','mode':'SEARCH','stype':'vod'},{'title':'영화 검색','mode':'SEARCH','stype':'movie'}]
rdfKicuzPTnpHJUjwXLOFQloMvsgNA=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'PROGRAM','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
rdfKicuzPTnpHJUjwXLOFQloMvsgNW={'C00551':'tvN','C00544':'중화TV','C00575':'Olive','C00579':'Mnet','C00590':'OGN','C01141':'XtvN','C01142':'ONSTYLE','C01143':'OtvN','C04601':'CGV','C06941':'tooniverse','C07381':'OCN','C07382':'SUPER ACTION','C15251':'OGN x LOL','C15252':'OGN x 오버워치','C15042':'티빙라이브','C01581':'TV CHOSUN','C01583':'채널A','C00708':'MBN','C00593':'YTN','C01101':'YTN Life','C15347':'YTN science','C01723':'연합뉴스TV','C15152':'DIA TV','C01582':'JTBC','C00588':'JTBC Golf','C15741':'JTBC2','C00805':'JTBC3 FOX Sports','C05661':'디즈니채널','C18641':'IHQ','C22041':'JTBC4','C23343':'t.cast','C23441':'E channel','C17341':'히스토리','C00585':'TV CHOSUN2','C17141':'채널A 플러스','C00611':'LIFETIME','C08041':'tvN go','C05901':'채널W','C23442':"D'LIVE",'C27441':'KBS N'}
rdfKicuzPTnpHJUjwXLOFQloMvsgNE ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
rdfKicuzPTnpHJUjwXLOFQloMvsgNt=xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
from tvingCore import*
class rdfKicuzPTnpHJUjwXLOFQloMvsgNm(rdfKicuzPTnpHJUjwXLOFQloMvsgbh):
 def __init__(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgNC,rdfKicuzPTnpHJUjwXLOFQloMvsgNq,rdfKicuzPTnpHJUjwXLOFQloMvsgNI):
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_url =rdfKicuzPTnpHJUjwXLOFQloMvsgNC
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_handle=rdfKicuzPTnpHJUjwXLOFQloMvsgNq
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.main_params =rdfKicuzPTnpHJUjwXLOFQloMvsgNI
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj =tLOawUzIxgbmMJycrkiTDuKFpjBVoP() 
 def addon_noti(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,sting):
  try:
   rdfKicuzPTnpHJUjwXLOFQloMvsgNY=xbmcgui.Dialog()
   rdfKicuzPTnpHJUjwXLOFQloMvsgNY.notification(__addonname__,sting)
  except:
   rdfKicuzPTnpHJUjwXLOFQloMvsgBN
 def addon_log(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,string):
  try:
   rdfKicuzPTnpHJUjwXLOFQloMvsgNx=string.encode('utf-8','ignore')
  except:
   rdfKicuzPTnpHJUjwXLOFQloMvsgNx='addonException: addon_log'
  rdfKicuzPTnpHJUjwXLOFQloMvsgNa=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,rdfKicuzPTnpHJUjwXLOFQloMvsgNx),level=rdfKicuzPTnpHJUjwXLOFQloMvsgNa)
 def get_keyboard_input(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgmA):
  rdfKicuzPTnpHJUjwXLOFQloMvsgNy=rdfKicuzPTnpHJUjwXLOFQloMvsgBN
  kb=xbmc.Keyboard()
  kb.setHeading(rdfKicuzPTnpHJUjwXLOFQloMvsgmA)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   rdfKicuzPTnpHJUjwXLOFQloMvsgNy=kb.getText()
  return rdfKicuzPTnpHJUjwXLOFQloMvsgNy
 def get_settings_login_info(rdfKicuzPTnpHJUjwXLOFQloMvsgNS):
  rdfKicuzPTnpHJUjwXLOFQloMvsgNR =__addon__.getSetting('id')
  rdfKicuzPTnpHJUjwXLOFQloMvsgNe =__addon__.getSetting('pw')
  rdfKicuzPTnpHJUjwXLOFQloMvsgNG =__addon__.getSetting('login_type')
  return(rdfKicuzPTnpHJUjwXLOFQloMvsgNR,rdfKicuzPTnpHJUjwXLOFQloMvsgNe,rdfKicuzPTnpHJUjwXLOFQloMvsgNG)
 def get_settings_premiumyn(rdfKicuzPTnpHJUjwXLOFQloMvsgNS):
  rdfKicuzPTnpHJUjwXLOFQloMvsgNh =__addon__.getSetting('premium_movieyn')
  if rdfKicuzPTnpHJUjwXLOFQloMvsgNh=='false':
   return rdfKicuzPTnpHJUjwXLOFQloMvsgBm
  else:
   return rdfKicuzPTnpHJUjwXLOFQloMvsgBD
 def get_settings_direct_replay(rdfKicuzPTnpHJUjwXLOFQloMvsgNS):
  rdfKicuzPTnpHJUjwXLOFQloMvsgmN=rdfKicuzPTnpHJUjwXLOFQloMvsgBV(__addon__.getSetting('direct_replay'))
  if rdfKicuzPTnpHJUjwXLOFQloMvsgmN==0:
   return rdfKicuzPTnpHJUjwXLOFQloMvsgBm
  else:
   return rdfKicuzPTnpHJUjwXLOFQloMvsgBD
 def get_settings_thumbnail_landyn(rdfKicuzPTnpHJUjwXLOFQloMvsgNS):
  rdfKicuzPTnpHJUjwXLOFQloMvsgmD =rdfKicuzPTnpHJUjwXLOFQloMvsgBV(__addon__.getSetting('thumbnail_way'))
  if rdfKicuzPTnpHJUjwXLOFQloMvsgmD==0:
   return rdfKicuzPTnpHJUjwXLOFQloMvsgBD
  else:
   return rdfKicuzPTnpHJUjwXLOFQloMvsgBm
 def set_winCredential(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,credential):
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV=xbmcgui.Window(10000)
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV.setProperty('TVING_M_LOGINTIME',rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
 def get_winCredential(rdfKicuzPTnpHJUjwXLOFQloMvsgNS):
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV=xbmcgui.Window(10000)
  rdfKicuzPTnpHJUjwXLOFQloMvsgmb={'tving_token':rdfKicuzPTnpHJUjwXLOFQloMvsgmV.getProperty('TVING_M_TOKEN'),'poc_userinfo':rdfKicuzPTnpHJUjwXLOFQloMvsgmV.getProperty('TVING_M_USERINFO'),'tving_uuid':rdfKicuzPTnpHJUjwXLOFQloMvsgmV.getProperty('TVING_M_UUID')}
  return rdfKicuzPTnpHJUjwXLOFQloMvsgmb
 def set_winEpisodeOrderby(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgDI):
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV=xbmcgui.Window(10000)
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV.setProperty('TVING_M_ORDERBY',rdfKicuzPTnpHJUjwXLOFQloMvsgDI)
 def get_winEpisodeOrderby(rdfKicuzPTnpHJUjwXLOFQloMvsgNS):
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV=xbmcgui.Window(10000)
  return rdfKicuzPTnpHJUjwXLOFQloMvsgmV.getProperty('TVING_M_ORDERBY')
 def add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,label,sublabel='',img='',infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgBN,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBD,params=''):
  rdfKicuzPTnpHJUjwXLOFQloMvsgmB='%s?%s'%(rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_url,urllib.parse.urlencode(params))
  if sublabel:rdfKicuzPTnpHJUjwXLOFQloMvsgmA='%s < %s >'%(label,sublabel)
  else: rdfKicuzPTnpHJUjwXLOFQloMvsgmA=label
  if not img:img='DefaultFolder.png'
  rdfKicuzPTnpHJUjwXLOFQloMvsgmW=xbmcgui.ListItem(rdfKicuzPTnpHJUjwXLOFQloMvsgmA)
  rdfKicuzPTnpHJUjwXLOFQloMvsgmW.setArt({'thumbnailImage':img,'icon':img,'poster':img})
  if infoLabels:rdfKicuzPTnpHJUjwXLOFQloMvsgmW.setInfo(type="Video",infoLabels=infoLabels)
  if not isFolder:rdfKicuzPTnpHJUjwXLOFQloMvsgmW.setProperty('IsPlayable','true')
  xbmcplugin.addDirectoryItem(rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_handle,rdfKicuzPTnpHJUjwXLOFQloMvsgmB,rdfKicuzPTnpHJUjwXLOFQloMvsgmW,isFolder)
 def get_selQuality(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,etype):
  try:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmE='selected_quality'
   rdfKicuzPTnpHJUjwXLOFQloMvsgmt=[1080,720,480,360]
   rdfKicuzPTnpHJUjwXLOFQloMvsgmS=rdfKicuzPTnpHJUjwXLOFQloMvsgBV(__addon__.getSetting(rdfKicuzPTnpHJUjwXLOFQloMvsgmE))
   return rdfKicuzPTnpHJUjwXLOFQloMvsgmt[rdfKicuzPTnpHJUjwXLOFQloMvsgmS]
  except:
   rdfKicuzPTnpHJUjwXLOFQloMvsgBN
  return 720 
 def dp_Main_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS):
  for rdfKicuzPTnpHJUjwXLOFQloMvsgmC in rdfKicuzPTnpHJUjwXLOFQloMvsgND:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA=rdfKicuzPTnpHJUjwXLOFQloMvsgmC.get('title')
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':rdfKicuzPTnpHJUjwXLOFQloMvsgmC.get('mode'),'stype':rdfKicuzPTnpHJUjwXLOFQloMvsgmC.get('stype'),'orderby':rdfKicuzPTnpHJUjwXLOFQloMvsgmC.get('orderby'),'ordernm':rdfKicuzPTnpHJUjwXLOFQloMvsgmC.get('ordernm'),'page':'1'}
   if rdfKicuzPTnpHJUjwXLOFQloMvsgmC.get('mode')=='XXX':
    rdfKicuzPTnpHJUjwXLOFQloMvsgmq['mode']='XXX'
    rdfKicuzPTnpHJUjwXLOFQloMvsgmI=rdfKicuzPTnpHJUjwXLOFQloMvsgBm
   else:
    rdfKicuzPTnpHJUjwXLOFQloMvsgmI=rdfKicuzPTnpHJUjwXLOFQloMvsgBD
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel='',img='',infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgBN,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgmI,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgBb(rdfKicuzPTnpHJUjwXLOFQloMvsgND)>0:xbmcplugin.endOfDirectory(rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_handle)
 def login_main(rdfKicuzPTnpHJUjwXLOFQloMvsgNS):
  (rdfKicuzPTnpHJUjwXLOFQloMvsgmY,rdfKicuzPTnpHJUjwXLOFQloMvsgmx,rdfKicuzPTnpHJUjwXLOFQloMvsgma)=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_settings_login_info()
  if not(rdfKicuzPTnpHJUjwXLOFQloMvsgmY and rdfKicuzPTnpHJUjwXLOFQloMvsgmx):
   rdfKicuzPTnpHJUjwXLOFQloMvsgNY=xbmcgui.Dialog()
   rdfKicuzPTnpHJUjwXLOFQloMvsgmy=rdfKicuzPTnpHJUjwXLOFQloMvsgNY.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if rdfKicuzPTnpHJUjwXLOFQloMvsgmy==rdfKicuzPTnpHJUjwXLOFQloMvsgBD:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_winEpisodeOrderby()=='':
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.set_winEpisodeOrderby('desc')
  if rdfKicuzPTnpHJUjwXLOFQloMvsgNS.cookiefile_check():return
  rdfKicuzPTnpHJUjwXLOFQloMvsgmR =rdfKicuzPTnpHJUjwXLOFQloMvsgBV(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  rdfKicuzPTnpHJUjwXLOFQloMvsgme=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if rdfKicuzPTnpHJUjwXLOFQloMvsgme==rdfKicuzPTnpHJUjwXLOFQloMvsgBN or rdfKicuzPTnpHJUjwXLOFQloMvsgme=='':
   rdfKicuzPTnpHJUjwXLOFQloMvsgme=rdfKicuzPTnpHJUjwXLOFQloMvsgBV('19000101')
  else:
   rdfKicuzPTnpHJUjwXLOFQloMvsgme=rdfKicuzPTnpHJUjwXLOFQloMvsgBV(re.sub('-','',rdfKicuzPTnpHJUjwXLOFQloMvsgme))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   rdfKicuzPTnpHJUjwXLOFQloMvsgmG=0
   while rdfKicuzPTnpHJUjwXLOFQloMvsgBD:
    rdfKicuzPTnpHJUjwXLOFQloMvsgmG+=1
    time.sleep(0.05)
    if rdfKicuzPTnpHJUjwXLOFQloMvsgme>=rdfKicuzPTnpHJUjwXLOFQloMvsgmR:return
    if rdfKicuzPTnpHJUjwXLOFQloMvsgmG>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if rdfKicuzPTnpHJUjwXLOFQloMvsgme>=rdfKicuzPTnpHJUjwXLOFQloMvsgmR:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.GetCredential(rdfKicuzPTnpHJUjwXLOFQloMvsgmY,rdfKicuzPTnpHJUjwXLOFQloMvsgmx,rdfKicuzPTnpHJUjwXLOFQloMvsgma):
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.set_winCredential(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.LoadCredential())
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgDV):
  rdfKicuzPTnpHJUjwXLOFQloMvsgmh=rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('stype')
  if rdfKicuzPTnpHJUjwXLOFQloMvsgmh=='live':
   rdfKicuzPTnpHJUjwXLOFQloMvsgDN=rdfKicuzPTnpHJUjwXLOFQloMvsgNV
  else:
   rdfKicuzPTnpHJUjwXLOFQloMvsgDN=rdfKicuzPTnpHJUjwXLOFQloMvsgNA
  for rdfKicuzPTnpHJUjwXLOFQloMvsgDm in rdfKicuzPTnpHJUjwXLOFQloMvsgDN:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA=rdfKicuzPTnpHJUjwXLOFQloMvsgDm.get('title')
   if rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('ordernm')!='-':
    rdfKicuzPTnpHJUjwXLOFQloMvsgmA+='  ('+rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('ordernm')+')'
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':rdfKicuzPTnpHJUjwXLOFQloMvsgDm.get('mode'),'stype':rdfKicuzPTnpHJUjwXLOFQloMvsgDm.get('stype'),'orderby':rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('orderby'),'page':'1'}
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel='',img='',infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgBN,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBD,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgBb(rdfKicuzPTnpHJUjwXLOFQloMvsgDN)>0:xbmcplugin.endOfDirectory(rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_handle)
 def dp_LiveChannel_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgDV):
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.SaveCredential(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_winCredential())
  rdfKicuzPTnpHJUjwXLOFQloMvsgmh =rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('stype')
  rdfKicuzPTnpHJUjwXLOFQloMvsgDb =rdfKicuzPTnpHJUjwXLOFQloMvsgBV(rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('page'))
  rdfKicuzPTnpHJUjwXLOFQloMvsgDB,rdfKicuzPTnpHJUjwXLOFQloMvsgDA=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.GetLiveChannelList(rdfKicuzPTnpHJUjwXLOFQloMvsgmh,rdfKicuzPTnpHJUjwXLOFQloMvsgDb)
  for rdfKicuzPTnpHJUjwXLOFQloMvsgDW in rdfKicuzPTnpHJUjwXLOFQloMvsgDB:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA =rdfKicuzPTnpHJUjwXLOFQloMvsgDW.get('title')
   rdfKicuzPTnpHJUjwXLOFQloMvsgmk =rdfKicuzPTnpHJUjwXLOFQloMvsgDW.get('channel')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDE =rdfKicuzPTnpHJUjwXLOFQloMvsgDW.get('thumbnail')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDt =rdfKicuzPTnpHJUjwXLOFQloMvsgDW.get('synopsis')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDS=rdfKicuzPTnpHJUjwXLOFQloMvsgDW.get('channelepg')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDC=rdfKicuzPTnpHJUjwXLOFQloMvsgDW.get('info')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDC['plot']='%s\n%s\n%s\n\n%s'%(rdfKicuzPTnpHJUjwXLOFQloMvsgmk,rdfKicuzPTnpHJUjwXLOFQloMvsgmA,rdfKicuzPTnpHJUjwXLOFQloMvsgDS,rdfKicuzPTnpHJUjwXLOFQloMvsgDt)
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':'LIVE','mediacode':rdfKicuzPTnpHJUjwXLOFQloMvsgDW.get('mediacode'),'stype':rdfKicuzPTnpHJUjwXLOFQloMvsgmh}
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmk,sublabel=rdfKicuzPTnpHJUjwXLOFQloMvsgmA,img=rdfKicuzPTnpHJUjwXLOFQloMvsgDE,infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgDC,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBm,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgDA:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['mode']='CHANNEL' 
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['stype']=rdfKicuzPTnpHJUjwXLOFQloMvsgmh 
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['page']=rdfKicuzPTnpHJUjwXLOFQloMvsgBA(rdfKicuzPTnpHJUjwXLOFQloMvsgDb+1)
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA='[B]%s >>[/B]'%'다음 페이지'
   rdfKicuzPTnpHJUjwXLOFQloMvsgDq=rdfKicuzPTnpHJUjwXLOFQloMvsgBA(rdfKicuzPTnpHJUjwXLOFQloMvsgDb+1)
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel=rdfKicuzPTnpHJUjwXLOFQloMvsgDq,img='',infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgBN,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBD,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgBb(rdfKicuzPTnpHJUjwXLOFQloMvsgDB)>0:xbmcplugin.endOfDirectory(rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_handle,cacheToDisc=rdfKicuzPTnpHJUjwXLOFQloMvsgBm)
 def dp_Program_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgDV):
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.SaveCredential(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_winCredential())
  rdfKicuzPTnpHJUjwXLOFQloMvsgmh =rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('stype')
  rdfKicuzPTnpHJUjwXLOFQloMvsgDI =rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('orderby')
  rdfKicuzPTnpHJUjwXLOFQloMvsgDb =rdfKicuzPTnpHJUjwXLOFQloMvsgBV(rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('page'))
  rdfKicuzPTnpHJUjwXLOFQloMvsgDk,rdfKicuzPTnpHJUjwXLOFQloMvsgDA=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.GetProgramList(rdfKicuzPTnpHJUjwXLOFQloMvsgmh,rdfKicuzPTnpHJUjwXLOFQloMvsgDI,rdfKicuzPTnpHJUjwXLOFQloMvsgDb,landyn=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_settings_thumbnail_landyn())
  for rdfKicuzPTnpHJUjwXLOFQloMvsgDY in rdfKicuzPTnpHJUjwXLOFQloMvsgDk:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA =rdfKicuzPTnpHJUjwXLOFQloMvsgDY.get('title')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDE=rdfKicuzPTnpHJUjwXLOFQloMvsgDY.get('thumbnail')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDt =rdfKicuzPTnpHJUjwXLOFQloMvsgDY.get('synopsis')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDx =rdfKicuzPTnpHJUjwXLOFQloMvsgNW.get(rdfKicuzPTnpHJUjwXLOFQloMvsgDY.get('channel'))
   rdfKicuzPTnpHJUjwXLOFQloMvsgDC=rdfKicuzPTnpHJUjwXLOFQloMvsgDY.get('info')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDC['studio']=rdfKicuzPTnpHJUjwXLOFQloMvsgDx
   rdfKicuzPTnpHJUjwXLOFQloMvsgDC['plot']='%s <%s>\n\n%s'%(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,rdfKicuzPTnpHJUjwXLOFQloMvsgDx,rdfKicuzPTnpHJUjwXLOFQloMvsgDt)
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':'EPISODE','programcode':rdfKicuzPTnpHJUjwXLOFQloMvsgDY.get('program'),'page':'1'}
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel=rdfKicuzPTnpHJUjwXLOFQloMvsgDx,img=rdfKicuzPTnpHJUjwXLOFQloMvsgDE,infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgDC,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBD,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgDA:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['mode'] ='PROGRAM' 
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['stype'] =rdfKicuzPTnpHJUjwXLOFQloMvsgmh
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['orderby']=rdfKicuzPTnpHJUjwXLOFQloMvsgDI
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['page'] =rdfKicuzPTnpHJUjwXLOFQloMvsgBA(rdfKicuzPTnpHJUjwXLOFQloMvsgDb+1)
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA='[B]%s >>[/B]'%'다음 페이지'
   rdfKicuzPTnpHJUjwXLOFQloMvsgDq=rdfKicuzPTnpHJUjwXLOFQloMvsgBA(rdfKicuzPTnpHJUjwXLOFQloMvsgDb+1)
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel=rdfKicuzPTnpHJUjwXLOFQloMvsgDq,img='',infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgBN,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBD,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgBb(rdfKicuzPTnpHJUjwXLOFQloMvsgDk)>0:xbmcplugin.endOfDirectory(rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_handle,cacheToDisc=rdfKicuzPTnpHJUjwXLOFQloMvsgBm)
 def dp_Episode_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgDV):
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.SaveCredential(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_winCredential())
  rdfKicuzPTnpHJUjwXLOFQloMvsgDa=rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('programcode')
  rdfKicuzPTnpHJUjwXLOFQloMvsgDb =rdfKicuzPTnpHJUjwXLOFQloMvsgBV(rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('page'))
  rdfKicuzPTnpHJUjwXLOFQloMvsgDy,rdfKicuzPTnpHJUjwXLOFQloMvsgDA,rdfKicuzPTnpHJUjwXLOFQloMvsgDR=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.GetEpisodoList(rdfKicuzPTnpHJUjwXLOFQloMvsgDa,rdfKicuzPTnpHJUjwXLOFQloMvsgDb,orderby=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_winEpisodeOrderby())
  for rdfKicuzPTnpHJUjwXLOFQloMvsgDe in rdfKicuzPTnpHJUjwXLOFQloMvsgDy:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA =rdfKicuzPTnpHJUjwXLOFQloMvsgDe.get('title')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDq =rdfKicuzPTnpHJUjwXLOFQloMvsgDe.get('subtitle')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDE=rdfKicuzPTnpHJUjwXLOFQloMvsgDe.get('thumbnail')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDt =rdfKicuzPTnpHJUjwXLOFQloMvsgDe.get('synopsis')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDC=rdfKicuzPTnpHJUjwXLOFQloMvsgDe.get('info')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDC['plot']='%s\n\n%s'%(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,rdfKicuzPTnpHJUjwXLOFQloMvsgDt)
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':'VOD','mediacode':rdfKicuzPTnpHJUjwXLOFQloMvsgDe.get('episode'),'stype':'vod','programcode':rdfKicuzPTnpHJUjwXLOFQloMvsgDa,'title':rdfKicuzPTnpHJUjwXLOFQloMvsgmA,'thumbnail':rdfKicuzPTnpHJUjwXLOFQloMvsgDE}
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel=rdfKicuzPTnpHJUjwXLOFQloMvsgDq,img=rdfKicuzPTnpHJUjwXLOFQloMvsgDE,infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgDC,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBm,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgDb==1:
   rdfKicuzPTnpHJUjwXLOFQloMvsgDC={'plot':'정렬순서를 변경합니다.'}
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq={}
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['mode'] ='ORDER_BY' 
   if rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_winEpisodeOrderby()=='desc':
    rdfKicuzPTnpHJUjwXLOFQloMvsgmA='정렬순서변경 : 최신화부터 -> 1회부터'
    rdfKicuzPTnpHJUjwXLOFQloMvsgmq['orderby']='asc'
   else:
    rdfKicuzPTnpHJUjwXLOFQloMvsgmA='정렬순서변경 : 1회부터 -> 최신화부터'
    rdfKicuzPTnpHJUjwXLOFQloMvsgmq['orderby']='desc'
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel='',img='',infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgDC,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBm,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgDA:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['mode'] ='EPISODE' 
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['programcode']=rdfKicuzPTnpHJUjwXLOFQloMvsgDa
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['page'] =rdfKicuzPTnpHJUjwXLOFQloMvsgBA(rdfKicuzPTnpHJUjwXLOFQloMvsgDb+1)
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA='[B]%s >>[/B]'%'다음 페이지'
   rdfKicuzPTnpHJUjwXLOFQloMvsgDq=rdfKicuzPTnpHJUjwXLOFQloMvsgBA(rdfKicuzPTnpHJUjwXLOFQloMvsgDb+1)
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel=rdfKicuzPTnpHJUjwXLOFQloMvsgDq,img='',infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgBN,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBD,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgBb(rdfKicuzPTnpHJUjwXLOFQloMvsgDy)>0:xbmcplugin.endOfDirectory(rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_handle,cacheToDisc=rdfKicuzPTnpHJUjwXLOFQloMvsgBD)
 def dp_setEpOrderby(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgDV):
  rdfKicuzPTnpHJUjwXLOFQloMvsgDI =rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('orderby')
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.set_winEpisodeOrderby(rdfKicuzPTnpHJUjwXLOFQloMvsgDI)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgDV):
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.SaveCredential(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_winCredential())
  rdfKicuzPTnpHJUjwXLOFQloMvsgDI =rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('orderby')
  rdfKicuzPTnpHJUjwXLOFQloMvsgDb=rdfKicuzPTnpHJUjwXLOFQloMvsgBV(rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('page'))
  rdfKicuzPTnpHJUjwXLOFQloMvsgDG,rdfKicuzPTnpHJUjwXLOFQloMvsgDA=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.GetMovieList(rdfKicuzPTnpHJUjwXLOFQloMvsgDI,rdfKicuzPTnpHJUjwXLOFQloMvsgDb,premiumyn=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_settings_premiumyn(),landyn=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_settings_thumbnail_landyn())
  for rdfKicuzPTnpHJUjwXLOFQloMvsgDh in rdfKicuzPTnpHJUjwXLOFQloMvsgDG:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA =rdfKicuzPTnpHJUjwXLOFQloMvsgDh.get('title')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDE=rdfKicuzPTnpHJUjwXLOFQloMvsgDh.get('thumbnail')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDt =rdfKicuzPTnpHJUjwXLOFQloMvsgDh.get('synopsis')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDC=rdfKicuzPTnpHJUjwXLOFQloMvsgDh.get('info')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDC['plot']='%s\n\n%s'%(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,rdfKicuzPTnpHJUjwXLOFQloMvsgDt)
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':'MOVIE','mediacode':rdfKicuzPTnpHJUjwXLOFQloMvsgDh.get('moviecode'),'stype':'movie','title':rdfKicuzPTnpHJUjwXLOFQloMvsgmA,'thumbnail':rdfKicuzPTnpHJUjwXLOFQloMvsgDE}
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel='',img=rdfKicuzPTnpHJUjwXLOFQloMvsgDE,infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgDC,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBm,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgDA:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['mode'] ='MOVIE_GROUP' 
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['orderby']=rdfKicuzPTnpHJUjwXLOFQloMvsgDI
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['page'] =rdfKicuzPTnpHJUjwXLOFQloMvsgBA(rdfKicuzPTnpHJUjwXLOFQloMvsgDb+1)
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA='[B]%s >>[/B]'%'다음 페이지'
   rdfKicuzPTnpHJUjwXLOFQloMvsgDq=rdfKicuzPTnpHJUjwXLOFQloMvsgBA(rdfKicuzPTnpHJUjwXLOFQloMvsgDb+1)
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel=rdfKicuzPTnpHJUjwXLOFQloMvsgDq,img='',infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgBN,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBD,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgBb(rdfKicuzPTnpHJUjwXLOFQloMvsgDG)>0:xbmcplugin.endOfDirectory(rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_handle,cacheToDisc=rdfKicuzPTnpHJUjwXLOFQloMvsgBm)
 def dp_Search_Group(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgDV):
  for rdfKicuzPTnpHJUjwXLOFQloMvsgDm in rdfKicuzPTnpHJUjwXLOFQloMvsgNB:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA=rdfKicuzPTnpHJUjwXLOFQloMvsgDm.get('title')
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':rdfKicuzPTnpHJUjwXLOFQloMvsgDm.get('mode'),'stype':rdfKicuzPTnpHJUjwXLOFQloMvsgDm.get('stype'),'page':'1'}
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel='',img='',infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgBN,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBD,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgBb(rdfKicuzPTnpHJUjwXLOFQloMvsgNB)>0:xbmcplugin.endOfDirectory(rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_handle)
 def dp_Search_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgDV):
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.SaveCredential(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_winCredential())
  rdfKicuzPTnpHJUjwXLOFQloMvsgVN =__addon__.getSetting('id')
  rdfKicuzPTnpHJUjwXLOFQloMvsgDb =rdfKicuzPTnpHJUjwXLOFQloMvsgBV(rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('page'))
  rdfKicuzPTnpHJUjwXLOFQloMvsgmh =rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('stype')
  if 'search_key' in rdfKicuzPTnpHJUjwXLOFQloMvsgDV:
   rdfKicuzPTnpHJUjwXLOFQloMvsgVm=rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('search_key')
  else:
   rdfKicuzPTnpHJUjwXLOFQloMvsgVm=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not rdfKicuzPTnpHJUjwXLOFQloMvsgVm:return
  rdfKicuzPTnpHJUjwXLOFQloMvsgVD,rdfKicuzPTnpHJUjwXLOFQloMvsgDA=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.GetSearchList(rdfKicuzPTnpHJUjwXLOFQloMvsgVm,rdfKicuzPTnpHJUjwXLOFQloMvsgVN,rdfKicuzPTnpHJUjwXLOFQloMvsgDb,rdfKicuzPTnpHJUjwXLOFQloMvsgmh,premiumyn=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_settings_premiumyn(),landyn=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_settings_thumbnail_landyn())
  if rdfKicuzPTnpHJUjwXLOFQloMvsgBb(rdfKicuzPTnpHJUjwXLOFQloMvsgVD)==0:return
  for rdfKicuzPTnpHJUjwXLOFQloMvsgVb in rdfKicuzPTnpHJUjwXLOFQloMvsgVD:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA =rdfKicuzPTnpHJUjwXLOFQloMvsgVb.get('title')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDE=rdfKicuzPTnpHJUjwXLOFQloMvsgVb.get('thumbnail')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDt =rdfKicuzPTnpHJUjwXLOFQloMvsgVb.get('synopsis')
   rdfKicuzPTnpHJUjwXLOFQloMvsgVB =rdfKicuzPTnpHJUjwXLOFQloMvsgVb.get('program')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDC=rdfKicuzPTnpHJUjwXLOFQloMvsgVb.get('info')
   rdfKicuzPTnpHJUjwXLOFQloMvsgDC['plot']='%s\n\n%s'%(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,rdfKicuzPTnpHJUjwXLOFQloMvsgDt)
   if rdfKicuzPTnpHJUjwXLOFQloMvsgmh=='vod':
    rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':'EPISODE','programcode':rdfKicuzPTnpHJUjwXLOFQloMvsgVb.get('program'),'page':'1'}
    rdfKicuzPTnpHJUjwXLOFQloMvsgmI=rdfKicuzPTnpHJUjwXLOFQloMvsgBD
   else:
    rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':'MOVIE','mediacode':rdfKicuzPTnpHJUjwXLOFQloMvsgVb.get('movie'),'stype':'movie','title':rdfKicuzPTnpHJUjwXLOFQloMvsgmA,'thumbnail':rdfKicuzPTnpHJUjwXLOFQloMvsgDE}
    rdfKicuzPTnpHJUjwXLOFQloMvsgmI=rdfKicuzPTnpHJUjwXLOFQloMvsgBm
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel='',img=rdfKicuzPTnpHJUjwXLOFQloMvsgDE,infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgDC,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgmI,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgDA:
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['mode'] ='SEARCH' 
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['search_key']=rdfKicuzPTnpHJUjwXLOFQloMvsgVm
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq['page'] =rdfKicuzPTnpHJUjwXLOFQloMvsgBA(rdfKicuzPTnpHJUjwXLOFQloMvsgDb+1)
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA='[B]%s >>[/B]'%'다음 페이지'
   rdfKicuzPTnpHJUjwXLOFQloMvsgDq=rdfKicuzPTnpHJUjwXLOFQloMvsgBA(rdfKicuzPTnpHJUjwXLOFQloMvsgDb+1)
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel=rdfKicuzPTnpHJUjwXLOFQloMvsgDq,img='',infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgBN,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBD,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgBb(rdfKicuzPTnpHJUjwXLOFQloMvsgVD)>0:xbmcplugin.endOfDirectory(rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_handle)
 def Delete_Watched_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgmh):
  try:
   rdfKicuzPTnpHJUjwXLOFQloMvsgVA=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rdfKicuzPTnpHJUjwXLOFQloMvsgmh))
   fp=rdfKicuzPTnpHJUjwXLOFQloMvsgBW(rdfKicuzPTnpHJUjwXLOFQloMvsgVA,'w',-1,'utf-8')
   fp.write('')
   fp.close()
  except:
   rdfKicuzPTnpHJUjwXLOFQloMvsgBN
 def dp_WatchList_Delete(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgDV):
  rdfKicuzPTnpHJUjwXLOFQloMvsgmh=rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('stype')
  rdfKicuzPTnpHJUjwXLOFQloMvsgNY=xbmcgui.Dialog()
  rdfKicuzPTnpHJUjwXLOFQloMvsgmy=rdfKicuzPTnpHJUjwXLOFQloMvsgNY.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if rdfKicuzPTnpHJUjwXLOFQloMvsgmy==rdfKicuzPTnpHJUjwXLOFQloMvsgBm:sys.exit()
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.Delete_Watched_List(rdfKicuzPTnpHJUjwXLOFQloMvsgmh)
  xbmc.executebuiltin("Container.Refresh")
 def Load_Watched_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgmh):
  try:
   rdfKicuzPTnpHJUjwXLOFQloMvsgVA=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rdfKicuzPTnpHJUjwXLOFQloMvsgmh))
   fp=rdfKicuzPTnpHJUjwXLOFQloMvsgBW(rdfKicuzPTnpHJUjwXLOFQloMvsgVA,'r',-1,'utf-8')
   rdfKicuzPTnpHJUjwXLOFQloMvsgVW=fp.readlines()
   fp.close()
  except:
   rdfKicuzPTnpHJUjwXLOFQloMvsgVW=[]
  return rdfKicuzPTnpHJUjwXLOFQloMvsgVW
 def Save_Watched_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgmh,rdfKicuzPTnpHJUjwXLOFQloMvsgNI):
  try:
   rdfKicuzPTnpHJUjwXLOFQloMvsgVA=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%rdfKicuzPTnpHJUjwXLOFQloMvsgmh))
   rdfKicuzPTnpHJUjwXLOFQloMvsgVE=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.Load_Watched_List(rdfKicuzPTnpHJUjwXLOFQloMvsgmh) 
   fp=rdfKicuzPTnpHJUjwXLOFQloMvsgBW(rdfKicuzPTnpHJUjwXLOFQloMvsgVA,'w',-1,'utf-8')
   rdfKicuzPTnpHJUjwXLOFQloMvsgVt=urllib.parse.urlencode(rdfKicuzPTnpHJUjwXLOFQloMvsgNI)
   rdfKicuzPTnpHJUjwXLOFQloMvsgVt=rdfKicuzPTnpHJUjwXLOFQloMvsgVt+'\n'
   fp.write(rdfKicuzPTnpHJUjwXLOFQloMvsgVt)
   rdfKicuzPTnpHJUjwXLOFQloMvsgVS=0
   for rdfKicuzPTnpHJUjwXLOFQloMvsgVC in rdfKicuzPTnpHJUjwXLOFQloMvsgVE:
    rdfKicuzPTnpHJUjwXLOFQloMvsgVq=rdfKicuzPTnpHJUjwXLOFQloMvsgBE(urllib.parse.parse_qsl(rdfKicuzPTnpHJUjwXLOFQloMvsgVC))
    rdfKicuzPTnpHJUjwXLOFQloMvsgVI=rdfKicuzPTnpHJUjwXLOFQloMvsgNI.get('code').strip()
    rdfKicuzPTnpHJUjwXLOFQloMvsgVk=rdfKicuzPTnpHJUjwXLOFQloMvsgVq.get('code').strip()
    if rdfKicuzPTnpHJUjwXLOFQloMvsgmh=='vod' and rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_settings_direct_replay()==rdfKicuzPTnpHJUjwXLOFQloMvsgBD:
     rdfKicuzPTnpHJUjwXLOFQloMvsgVI=rdfKicuzPTnpHJUjwXLOFQloMvsgNI.get('videoid').strip()
     rdfKicuzPTnpHJUjwXLOFQloMvsgVk=rdfKicuzPTnpHJUjwXLOFQloMvsgVq.get('videoid').strip()if rdfKicuzPTnpHJUjwXLOFQloMvsgVk!=rdfKicuzPTnpHJUjwXLOFQloMvsgBN else '-'
    if rdfKicuzPTnpHJUjwXLOFQloMvsgVI!=rdfKicuzPTnpHJUjwXLOFQloMvsgVk:
     fp.write(rdfKicuzPTnpHJUjwXLOFQloMvsgVC)
     rdfKicuzPTnpHJUjwXLOFQloMvsgVS+=1
     if rdfKicuzPTnpHJUjwXLOFQloMvsgVS>=50:break
   fp.close()
  except:
   rdfKicuzPTnpHJUjwXLOFQloMvsgBN
 def dp_Watch_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgDV):
  rdfKicuzPTnpHJUjwXLOFQloMvsgmh =rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('stype')
  rdfKicuzPTnpHJUjwXLOFQloMvsgmN=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_settings_direct_replay()
  if rdfKicuzPTnpHJUjwXLOFQloMvsgmh=='-':
   for rdfKicuzPTnpHJUjwXLOFQloMvsgDm in rdfKicuzPTnpHJUjwXLOFQloMvsgNb:
    rdfKicuzPTnpHJUjwXLOFQloMvsgmA=rdfKicuzPTnpHJUjwXLOFQloMvsgDm.get('title')
    rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':rdfKicuzPTnpHJUjwXLOFQloMvsgDm.get('mode'),'stype':rdfKicuzPTnpHJUjwXLOFQloMvsgDm.get('stype')}
    rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel='',img='',infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgBN,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBD,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
   if rdfKicuzPTnpHJUjwXLOFQloMvsgBb(rdfKicuzPTnpHJUjwXLOFQloMvsgNb)>0:xbmcplugin.endOfDirectory(rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_handle)
  else:
   rdfKicuzPTnpHJUjwXLOFQloMvsgVY=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.Load_Watched_List(rdfKicuzPTnpHJUjwXLOFQloMvsgmh)
   for rdfKicuzPTnpHJUjwXLOFQloMvsgVx in rdfKicuzPTnpHJUjwXLOFQloMvsgVY:
    rdfKicuzPTnpHJUjwXLOFQloMvsgVa=rdfKicuzPTnpHJUjwXLOFQloMvsgBE(urllib.parse.parse_qsl(rdfKicuzPTnpHJUjwXLOFQloMvsgVx))
    rdfKicuzPTnpHJUjwXLOFQloMvsgVy =rdfKicuzPTnpHJUjwXLOFQloMvsgVa.get('code').strip()
    rdfKicuzPTnpHJUjwXLOFQloMvsgmA =rdfKicuzPTnpHJUjwXLOFQloMvsgVa.get('title').strip()
    rdfKicuzPTnpHJUjwXLOFQloMvsgDE=rdfKicuzPTnpHJUjwXLOFQloMvsgVa.get('img').strip()
    rdfKicuzPTnpHJUjwXLOFQloMvsgVR =rdfKicuzPTnpHJUjwXLOFQloMvsgVa.get('videoid').strip()
    rdfKicuzPTnpHJUjwXLOFQloMvsgDC={}
    rdfKicuzPTnpHJUjwXLOFQloMvsgDC['plot']=rdfKicuzPTnpHJUjwXLOFQloMvsgmA
    if rdfKicuzPTnpHJUjwXLOFQloMvsgmh=='vod':
     if rdfKicuzPTnpHJUjwXLOFQloMvsgmN==rdfKicuzPTnpHJUjwXLOFQloMvsgBm or rdfKicuzPTnpHJUjwXLOFQloMvsgVR==rdfKicuzPTnpHJUjwXLOFQloMvsgBN:
      rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':'EPISODE','programcode':rdfKicuzPTnpHJUjwXLOFQloMvsgVy,'page':'1'}
      rdfKicuzPTnpHJUjwXLOFQloMvsgmI=rdfKicuzPTnpHJUjwXLOFQloMvsgBD
     else:
      rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':'VOD','mediacode':rdfKicuzPTnpHJUjwXLOFQloMvsgVR,'stype':'vod','programcode':rdfKicuzPTnpHJUjwXLOFQloMvsgVy,'title':rdfKicuzPTnpHJUjwXLOFQloMvsgmA,'thumbnail':rdfKicuzPTnpHJUjwXLOFQloMvsgDE}
      rdfKicuzPTnpHJUjwXLOFQloMvsgmI=rdfKicuzPTnpHJUjwXLOFQloMvsgBm
    else:
     rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':'MOVIE','mediacode':rdfKicuzPTnpHJUjwXLOFQloMvsgVy,'stype':'movie','title':rdfKicuzPTnpHJUjwXLOFQloMvsgmA,'thumbnail':rdfKicuzPTnpHJUjwXLOFQloMvsgDE}
     rdfKicuzPTnpHJUjwXLOFQloMvsgmI=rdfKicuzPTnpHJUjwXLOFQloMvsgBm
    rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel='',img=rdfKicuzPTnpHJUjwXLOFQloMvsgDE,infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgDC,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgmI,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
   rdfKicuzPTnpHJUjwXLOFQloMvsgDC={'plot':'시청목록을 삭제합니다.'}
   rdfKicuzPTnpHJUjwXLOFQloMvsgmA='*** 시청목록 삭제 ***'
   rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'mode':'MYVIEW_REMOVE','stype':rdfKicuzPTnpHJUjwXLOFQloMvsgmh}
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.add_dir(rdfKicuzPTnpHJUjwXLOFQloMvsgmA,sublabel='',img='',infoLabels=rdfKicuzPTnpHJUjwXLOFQloMvsgDC,isFolder=rdfKicuzPTnpHJUjwXLOFQloMvsgBm,params=rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
   xbmcplugin.endOfDirectory(rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_handle,cacheToDisc=rdfKicuzPTnpHJUjwXLOFQloMvsgBm)
 def play_VIDEO(rdfKicuzPTnpHJUjwXLOFQloMvsgNS,rdfKicuzPTnpHJUjwXLOFQloMvsgDV):
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.SaveCredential(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_winCredential())
  rdfKicuzPTnpHJUjwXLOFQloMvsgVG =rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('mediacode')
  rdfKicuzPTnpHJUjwXLOFQloMvsgmh =rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('stype')
  rdfKicuzPTnpHJUjwXLOFQloMvsgVh =rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('pvrmode')
  rdfKicuzPTnpHJUjwXLOFQloMvsgbN=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.get_selQuality(rdfKicuzPTnpHJUjwXLOFQloMvsgmh)
  rdfKicuzPTnpHJUjwXLOFQloMvsgbm,rdfKicuzPTnpHJUjwXLOFQloMvsgbD=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.GetBroadURL(rdfKicuzPTnpHJUjwXLOFQloMvsgVG,rdfKicuzPTnpHJUjwXLOFQloMvsgbN,rdfKicuzPTnpHJUjwXLOFQloMvsgmh,rdfKicuzPTnpHJUjwXLOFQloMvsgVh)
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.addon_log('qt, stype, url : %s - %s - %s'%(rdfKicuzPTnpHJUjwXLOFQloMvsgBA(rdfKicuzPTnpHJUjwXLOFQloMvsgbN),rdfKicuzPTnpHJUjwXLOFQloMvsgmh,rdfKicuzPTnpHJUjwXLOFQloMvsgbm))
  if rdfKicuzPTnpHJUjwXLOFQloMvsgbm=='':
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.addon_noti(__language__(30908).encode('utf8'))
   return
  rdfKicuzPTnpHJUjwXLOFQloMvsgbV =rdfKicuzPTnpHJUjwXLOFQloMvsgbm.find('Policy=')
  if rdfKicuzPTnpHJUjwXLOFQloMvsgbV!=-1:
   rdfKicuzPTnpHJUjwXLOFQloMvsgbB =rdfKicuzPTnpHJUjwXLOFQloMvsgbm.split('?')[0]
   rdfKicuzPTnpHJUjwXLOFQloMvsgbA=rdfKicuzPTnpHJUjwXLOFQloMvsgBE(urllib.parse.parse_qsl(urllib.parse.urlsplit(rdfKicuzPTnpHJUjwXLOFQloMvsgbm).query))
   rdfKicuzPTnpHJUjwXLOFQloMvsgbA=urllib.parse.urlencode(rdfKicuzPTnpHJUjwXLOFQloMvsgbA)
   rdfKicuzPTnpHJUjwXLOFQloMvsgbA=rdfKicuzPTnpHJUjwXLOFQloMvsgbA.replace('&',';')
   rdfKicuzPTnpHJUjwXLOFQloMvsgbA=rdfKicuzPTnpHJUjwXLOFQloMvsgbA.replace('Policy','CloudFront-Policy')
   rdfKicuzPTnpHJUjwXLOFQloMvsgbA=rdfKicuzPTnpHJUjwXLOFQloMvsgbA.replace('Signature','CloudFront-Signature')
   rdfKicuzPTnpHJUjwXLOFQloMvsgbA=rdfKicuzPTnpHJUjwXLOFQloMvsgbA.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   rdfKicuzPTnpHJUjwXLOFQloMvsgbW='%s|Cookie=%s'%(rdfKicuzPTnpHJUjwXLOFQloMvsgbB,rdfKicuzPTnpHJUjwXLOFQloMvsgbA)
  else:
   rdfKicuzPTnpHJUjwXLOFQloMvsgbW=rdfKicuzPTnpHJUjwXLOFQloMvsgbm
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.addon_log(rdfKicuzPTnpHJUjwXLOFQloMvsgbW)
  rdfKicuzPTnpHJUjwXLOFQloMvsgbE=xbmcgui.ListItem(path=rdfKicuzPTnpHJUjwXLOFQloMvsgbW)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgbD!='':
   rdfKicuzPTnpHJUjwXLOFQloMvsgbt=rdfKicuzPTnpHJUjwXLOFQloMvsgbD
   rdfKicuzPTnpHJUjwXLOFQloMvsgbS ='https://cj.drmkeyserver.com/widevine_license'
   rdfKicuzPTnpHJUjwXLOFQloMvsgbC ='mpd'
   rdfKicuzPTnpHJUjwXLOFQloMvsgbq ='com.widevine.alpha'
   rdfKicuzPTnpHJUjwXLOFQloMvsgbI =inputstreamhelper.Helper(rdfKicuzPTnpHJUjwXLOFQloMvsgbC,drm='widevine')
   if rdfKicuzPTnpHJUjwXLOFQloMvsgbI.check_inputstream():
    rdfKicuzPTnpHJUjwXLOFQloMvsgbk={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%rdfKicuzPTnpHJUjwXLOFQloMvsgVG,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':rdfKicuzPTnpHJUjwXLOFQloMvsgNE,'AcquireLicenseAssertion':rdfKicuzPTnpHJUjwXLOFQloMvsgbt,'Host':'cj.drmkeyserver.com'}
    rdfKicuzPTnpHJUjwXLOFQloMvsgbY=rdfKicuzPTnpHJUjwXLOFQloMvsgbS+'|'+urllib.parse.urlencode(rdfKicuzPTnpHJUjwXLOFQloMvsgbk)+'|R{SSM}|'
    rdfKicuzPTnpHJUjwXLOFQloMvsgbE.setProperty('inputstream',rdfKicuzPTnpHJUjwXLOFQloMvsgbI.inputstream_addon)
    rdfKicuzPTnpHJUjwXLOFQloMvsgbE.setProperty('inputstream.adaptive.manifest_type',rdfKicuzPTnpHJUjwXLOFQloMvsgbC)
    rdfKicuzPTnpHJUjwXLOFQloMvsgbE.setProperty('inputstream.adaptive.license_type',rdfKicuzPTnpHJUjwXLOFQloMvsgbq)
    rdfKicuzPTnpHJUjwXLOFQloMvsgbE.setProperty('inputstream.adaptive.license_key',rdfKicuzPTnpHJUjwXLOFQloMvsgbY)
    rdfKicuzPTnpHJUjwXLOFQloMvsgbE.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(rdfKicuzPTnpHJUjwXLOFQloMvsgNE))
  xbmcplugin.setResolvedUrl(rdfKicuzPTnpHJUjwXLOFQloMvsgNS._addon_handle,rdfKicuzPTnpHJUjwXLOFQloMvsgBD,rdfKicuzPTnpHJUjwXLOFQloMvsgbE)
  try:
   if rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('mode')in['VOD','MOVIE']and rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('title'):
    rdfKicuzPTnpHJUjwXLOFQloMvsgmq={'code':rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('programcode')if rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('mode')=='VOD' else rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('mediacode'),'img':rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('thumbnail'),'title':rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('title'),'videoid':rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('mediacode')}
    rdfKicuzPTnpHJUjwXLOFQloMvsgNS.Save_Watched_List(rdfKicuzPTnpHJUjwXLOFQloMvsgDV.get('stype'),rdfKicuzPTnpHJUjwXLOFQloMvsgmq)
  except:
   rdfKicuzPTnpHJUjwXLOFQloMvsgBN
 def logout(rdfKicuzPTnpHJUjwXLOFQloMvsgNS):
  rdfKicuzPTnpHJUjwXLOFQloMvsgNY=xbmcgui.Dialog()
  rdfKicuzPTnpHJUjwXLOFQloMvsgmy=rdfKicuzPTnpHJUjwXLOFQloMvsgNY.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if rdfKicuzPTnpHJUjwXLOFQloMvsgmy==rdfKicuzPTnpHJUjwXLOFQloMvsgBm:sys.exit()
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.wininfo_clear()
  if os.path.isfile(rdfKicuzPTnpHJUjwXLOFQloMvsgNt):os.remove(rdfKicuzPTnpHJUjwXLOFQloMvsgNt)
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(rdfKicuzPTnpHJUjwXLOFQloMvsgNS):
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV=xbmcgui.Window(10000)
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV.setProperty('TVING_M_TOKEN','')
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV.setProperty('TVING_M_USERINFO','')
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV.setProperty('TVING_M_UUID','')
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV.setProperty('TVING_M_LOGINTIME','')
 def cookiefile_save(rdfKicuzPTnpHJUjwXLOFQloMvsgNS):
  rdfKicuzPTnpHJUjwXLOFQloMvsgbx =rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.Get_Now_Datetime()
  rdfKicuzPTnpHJUjwXLOFQloMvsgba=rdfKicuzPTnpHJUjwXLOFQloMvsgbx+datetime.timedelta(days=rdfKicuzPTnpHJUjwXLOFQloMvsgBV(__addon__.getSetting('cache_ttl')))
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV=xbmcgui.Window(10000)
  rdfKicuzPTnpHJUjwXLOFQloMvsgby={'tving_token':rdfKicuzPTnpHJUjwXLOFQloMvsgmV.getProperty('TVING_M_TOKEN'),'tving_userinfo':rdfKicuzPTnpHJUjwXLOFQloMvsgmV.getProperty('TVING_M_USERINFO'),'tving_uuid':rdfKicuzPTnpHJUjwXLOFQloMvsgmV.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_limitdate':rdfKicuzPTnpHJUjwXLOFQloMvsgba.strftime('%Y-%m-%d')}
  try: 
   fp=rdfKicuzPTnpHJUjwXLOFQloMvsgBW(rdfKicuzPTnpHJUjwXLOFQloMvsgNt,'w',-1,'utf-8')
   json.dump(rdfKicuzPTnpHJUjwXLOFQloMvsgby,fp)
   fp.close()
  except rdfKicuzPTnpHJUjwXLOFQloMvsgBt as exception:
   rdfKicuzPTnpHJUjwXLOFQloMvsgBS(exception)
 def cookiefile_check(rdfKicuzPTnpHJUjwXLOFQloMvsgNS):
  rdfKicuzPTnpHJUjwXLOFQloMvsgby={}
  try: 
   fp=rdfKicuzPTnpHJUjwXLOFQloMvsgBW(rdfKicuzPTnpHJUjwXLOFQloMvsgNt,'r',-1,'utf-8')
   rdfKicuzPTnpHJUjwXLOFQloMvsgby= json.load(fp)
   fp.close()
  except rdfKicuzPTnpHJUjwXLOFQloMvsgBt as exception:
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.wininfo_clear()
   return rdfKicuzPTnpHJUjwXLOFQloMvsgBm
  rdfKicuzPTnpHJUjwXLOFQloMvsgmY =__addon__.getSetting('id')
  rdfKicuzPTnpHJUjwXLOFQloMvsgmx =__addon__.getSetting('pw')
  rdfKicuzPTnpHJUjwXLOFQloMvsgbR=__addon__.getSetting('login_type')
  rdfKicuzPTnpHJUjwXLOFQloMvsgby['tving_id']=base64.standard_b64decode(rdfKicuzPTnpHJUjwXLOFQloMvsgby['tving_id']).decode('utf-8')
  rdfKicuzPTnpHJUjwXLOFQloMvsgby['tving_pw']=base64.standard_b64decode(rdfKicuzPTnpHJUjwXLOFQloMvsgby['tving_pw']).decode('utf-8')
  if rdfKicuzPTnpHJUjwXLOFQloMvsgmY!=rdfKicuzPTnpHJUjwXLOFQloMvsgby['tving_id']or rdfKicuzPTnpHJUjwXLOFQloMvsgmx!=rdfKicuzPTnpHJUjwXLOFQloMvsgby['tving_pw']or rdfKicuzPTnpHJUjwXLOFQloMvsgbR!=rdfKicuzPTnpHJUjwXLOFQloMvsgby['tving_logintype']:
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.wininfo_clear()
   return rdfKicuzPTnpHJUjwXLOFQloMvsgBm
  rdfKicuzPTnpHJUjwXLOFQloMvsgmR =rdfKicuzPTnpHJUjwXLOFQloMvsgBV(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  rdfKicuzPTnpHJUjwXLOFQloMvsgbe=rdfKicuzPTnpHJUjwXLOFQloMvsgby['tving_limitdate']
  rdfKicuzPTnpHJUjwXLOFQloMvsgme =rdfKicuzPTnpHJUjwXLOFQloMvsgBV(re.sub('-','',rdfKicuzPTnpHJUjwXLOFQloMvsgbe))
  if rdfKicuzPTnpHJUjwXLOFQloMvsgme<rdfKicuzPTnpHJUjwXLOFQloMvsgmR:
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.wininfo_clear()
   return rdfKicuzPTnpHJUjwXLOFQloMvsgBm
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV=xbmcgui.Window(10000)
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV.setProperty('TVING_M_TOKEN',rdfKicuzPTnpHJUjwXLOFQloMvsgby['tving_token'])
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV.setProperty('TVING_M_USERINFO',rdfKicuzPTnpHJUjwXLOFQloMvsgby['tving_userinfo'])
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV.setProperty('TVING_M_UUID',rdfKicuzPTnpHJUjwXLOFQloMvsgby['tving_uuid'])
  rdfKicuzPTnpHJUjwXLOFQloMvsgmV.setProperty('TVING_M_LOGINTIME',rdfKicuzPTnpHJUjwXLOFQloMvsgbe)
  return rdfKicuzPTnpHJUjwXLOFQloMvsgBD
 def tving_main(rdfKicuzPTnpHJUjwXLOFQloMvsgNS):
  rdfKicuzPTnpHJUjwXLOFQloMvsgbG=rdfKicuzPTnpHJUjwXLOFQloMvsgNS.main_params.get('mode',rdfKicuzPTnpHJUjwXLOFQloMvsgBN)
  if rdfKicuzPTnpHJUjwXLOFQloMvsgbG=='LOGOUT':
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.logout()
   return
  rdfKicuzPTnpHJUjwXLOFQloMvsgNS.login_main()
  if rdfKicuzPTnpHJUjwXLOFQloMvsgbG is rdfKicuzPTnpHJUjwXLOFQloMvsgBN:
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.dp_Main_List()
  elif rdfKicuzPTnpHJUjwXLOFQloMvsgbG in['LIVE_GROUP','VOD_GROUP']:
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.dp_Title_Group(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.main_params)
  elif rdfKicuzPTnpHJUjwXLOFQloMvsgbG=='CHANNEL':
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.dp_LiveChannel_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.main_params)
  elif rdfKicuzPTnpHJUjwXLOFQloMvsgbG in['LIVE','VOD','MOVIE']:
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.play_VIDEO(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.main_params)
  elif rdfKicuzPTnpHJUjwXLOFQloMvsgbG=='PROGRAM':
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.dp_Program_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.main_params)
  elif rdfKicuzPTnpHJUjwXLOFQloMvsgbG=='EPISODE':
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.dp_Episode_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.main_params)
  elif rdfKicuzPTnpHJUjwXLOFQloMvsgbG=='MOVIE_GROUP':
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.dp_Movie_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.main_params)
  elif rdfKicuzPTnpHJUjwXLOFQloMvsgbG=='SEARCH_GROUP':
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.dp_Search_Group(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.main_params)
  elif rdfKicuzPTnpHJUjwXLOFQloMvsgbG=='SEARCH':
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.dp_Search_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.main_params)
  elif rdfKicuzPTnpHJUjwXLOFQloMvsgbG=='WATCH':
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.dp_Watch_List(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.main_params)
  elif rdfKicuzPTnpHJUjwXLOFQloMvsgbG=='MYVIEW_REMOVE':
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.dp_WatchList_Delete(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.main_params)
  elif rdfKicuzPTnpHJUjwXLOFQloMvsgbG=='ORDER_BY':
   rdfKicuzPTnpHJUjwXLOFQloMvsgNS.dp_setEpOrderby(rdfKicuzPTnpHJUjwXLOFQloMvsgNS.main_params)
  else:
   rdfKicuzPTnpHJUjwXLOFQloMvsgBN
# Created by pyminifier (https://github.com/liftoff/pyminifier)
