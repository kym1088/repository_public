__author__="NightRain"
WtkjsYqwiJySrnCNlOFpvMXIxmhVEP=object
WtkjsYqwiJySrnCNlOFpvMXIxmhVEo=None
WtkjsYqwiJySrnCNlOFpvMXIxmhVEB=int
WtkjsYqwiJySrnCNlOFpvMXIxmhVEz=True
WtkjsYqwiJySrnCNlOFpvMXIxmhVEf=False
WtkjsYqwiJySrnCNlOFpvMXIxmhVED=type
WtkjsYqwiJySrnCNlOFpvMXIxmhVET=dict
WtkjsYqwiJySrnCNlOFpvMXIxmhVER=len
WtkjsYqwiJySrnCNlOFpvMXIxmhVEa=str
WtkjsYqwiJySrnCNlOFpvMXIxmhVEb=range
WtkjsYqwiJySrnCNlOFpvMXIxmhVEH=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
WtkjsYqwiJySrnCNlOFpvMXIxmhVGK=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
WtkjsYqwiJySrnCNlOFpvMXIxmhVGQ=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
WtkjsYqwiJySrnCNlOFpvMXIxmhVGc=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
WtkjsYqwiJySrnCNlOFpvMXIxmhVGA=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
WtkjsYqwiJySrnCNlOFpvMXIxmhVGe=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'공연','mode':'PROGRAM','stype':'PCM'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
WtkjsYqwiJySrnCNlOFpvMXIxmhVGE=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG160,MG140,MG150'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐/클래식','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
WtkjsYqwiJySrnCNlOFpvMXIxmhVGg=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
WtkjsYqwiJySrnCNlOFpvMXIxmhVGP =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
WtkjsYqwiJySrnCNlOFpvMXIxmhVGo=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class WtkjsYqwiJySrnCNlOFpvMXIxmhVGU(WtkjsYqwiJySrnCNlOFpvMXIxmhVEP):
 def __init__(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVGz,WtkjsYqwiJySrnCNlOFpvMXIxmhVGf,WtkjsYqwiJySrnCNlOFpvMXIxmhVGD):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_url =WtkjsYqwiJySrnCNlOFpvMXIxmhVGz
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle=WtkjsYqwiJySrnCNlOFpvMXIxmhVGf
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params =WtkjsYqwiJySrnCNlOFpvMXIxmhVGD
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj =RqQNmjCyGrMufBKHWsFvdkXhgDPtni() 
 def addon_noti(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,sting):
  try:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGR=xbmcgui.Dialog()
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGR.notification(__addonname__,sting)
  except:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
 def addon_log(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,string):
  try:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGa=string.encode('utf-8','ignore')
  except:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGa='addonException: addon_log'
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGb=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,WtkjsYqwiJySrnCNlOFpvMXIxmhVGa),level=WtkjsYqwiJySrnCNlOFpvMXIxmhVGb)
 def get_keyboard_input(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVUB):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGH=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
  kb=xbmc.Keyboard()
  kb.setHeading(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGH=kb.getText()
  return WtkjsYqwiJySrnCNlOFpvMXIxmhVGH
 def get_settings_account(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGd =__addon__.getSetting('id')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGL =__addon__.getSetting('pw')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGu =__addon__.getSetting('login_type')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUG=WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(__addon__.getSetting('selected_profile'))
  return(WtkjsYqwiJySrnCNlOFpvMXIxmhVGd,WtkjsYqwiJySrnCNlOFpvMXIxmhVGL,WtkjsYqwiJySrnCNlOFpvMXIxmhVGu,WtkjsYqwiJySrnCNlOFpvMXIxmhVUG)
 def get_settings_uhd(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB):
  return WtkjsYqwiJySrnCNlOFpvMXIxmhVEz if __addon__.getSetting('active_uhd')=='true' else WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
 def get_settings_totalsearch(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUK =WtkjsYqwiJySrnCNlOFpvMXIxmhVEz if __addon__.getSetting('local_search')=='true' else WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUQ=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz if __addon__.getSetting('local_history')=='true' else WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUc =WtkjsYqwiJySrnCNlOFpvMXIxmhVEz if __addon__.getSetting('total_search')=='true' else WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUA=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz if __addon__.getSetting('total_history')=='true' else WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUe=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz if __addon__.getSetting('menu_bookmark')=='true' else WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
  return(WtkjsYqwiJySrnCNlOFpvMXIxmhVUK,WtkjsYqwiJySrnCNlOFpvMXIxmhVUQ,WtkjsYqwiJySrnCNlOFpvMXIxmhVUc,WtkjsYqwiJySrnCNlOFpvMXIxmhVUA,WtkjsYqwiJySrnCNlOFpvMXIxmhVUe)
 def get_settings_makebookmark(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB):
  return WtkjsYqwiJySrnCNlOFpvMXIxmhVEz if __addon__.getSetting('make_bookmark')=='true' else WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
 def get_settings_direct_replay(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUE=WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(__addon__.getSetting('direct_replay'))
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVUE==0:
   return WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
  else:
   return WtkjsYqwiJySrnCNlOFpvMXIxmhVEz
 def set_winEpisodeOrderby(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVUP):
  __addon__.setSetting('tving_orderby',WtkjsYqwiJySrnCNlOFpvMXIxmhVUP)
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUg=xbmcgui.Window(10000)
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUg.setProperty('TVING_M_ORDERBY',WtkjsYqwiJySrnCNlOFpvMXIxmhVUP)
 def get_winEpisodeOrderby(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUP=__addon__.getSetting('tving_orderby')
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVUP in['',WtkjsYqwiJySrnCNlOFpvMXIxmhVEo]:WtkjsYqwiJySrnCNlOFpvMXIxmhVUP='desc'
  return WtkjsYqwiJySrnCNlOFpvMXIxmhVUP
 def add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,label,sublabel='',img='',infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params='',isLink=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf,ContextMenu=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUo='%s?%s'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_url,urllib.parse.urlencode(params))
  if sublabel:WtkjsYqwiJySrnCNlOFpvMXIxmhVUB='%s < %s >'%(label,sublabel)
  else: WtkjsYqwiJySrnCNlOFpvMXIxmhVUB=label
  if not img:img='DefaultFolder.png'
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUz=xbmcgui.ListItem(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVED(img)==WtkjsYqwiJySrnCNlOFpvMXIxmhVET:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUz.setArt(img)
  else:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUz.setArt({'thumb':img,'poster':img})
  if infoLabels:WtkjsYqwiJySrnCNlOFpvMXIxmhVUz.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUz.setProperty('IsPlayable','true')
  if ContextMenu:WtkjsYqwiJySrnCNlOFpvMXIxmhVUz.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,WtkjsYqwiJySrnCNlOFpvMXIxmhVUo,WtkjsYqwiJySrnCNlOFpvMXIxmhVUz,isFolder)
 def get_selQuality(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,etype):
  try:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUf='selected_quality'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUD=[1080,720,480,360]
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUT=WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(__addon__.getSetting(WtkjsYqwiJySrnCNlOFpvMXIxmhVUf))
   return WtkjsYqwiJySrnCNlOFpvMXIxmhVUD[WtkjsYqwiJySrnCNlOFpvMXIxmhVUT]
  except:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
  return 720 
 def dp_Main_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB):
  (WtkjsYqwiJySrnCNlOFpvMXIxmhVUK,WtkjsYqwiJySrnCNlOFpvMXIxmhVUQ,WtkjsYqwiJySrnCNlOFpvMXIxmhVUc,WtkjsYqwiJySrnCNlOFpvMXIxmhVUA,WtkjsYqwiJySrnCNlOFpvMXIxmhVUe)=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_settings_totalsearch()
  for WtkjsYqwiJySrnCNlOFpvMXIxmhVUR in WtkjsYqwiJySrnCNlOFpvMXIxmhVGK:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB=WtkjsYqwiJySrnCNlOFpvMXIxmhVUR.get('title')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUa=''
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVUR.get('mode')=='SEARCH_GROUP' and WtkjsYqwiJySrnCNlOFpvMXIxmhVUK ==WtkjsYqwiJySrnCNlOFpvMXIxmhVEf:continue
   elif WtkjsYqwiJySrnCNlOFpvMXIxmhVUR.get('mode')=='SEARCH_HISTORY' and WtkjsYqwiJySrnCNlOFpvMXIxmhVUQ==WtkjsYqwiJySrnCNlOFpvMXIxmhVEf:continue
   elif WtkjsYqwiJySrnCNlOFpvMXIxmhVUR.get('mode')=='TOTAL_SEARCH' and WtkjsYqwiJySrnCNlOFpvMXIxmhVUc ==WtkjsYqwiJySrnCNlOFpvMXIxmhVEf:continue
   elif WtkjsYqwiJySrnCNlOFpvMXIxmhVUR.get('mode')=='TOTAL_HISTORY' and WtkjsYqwiJySrnCNlOFpvMXIxmhVUA==WtkjsYqwiJySrnCNlOFpvMXIxmhVEf:continue
   elif WtkjsYqwiJySrnCNlOFpvMXIxmhVUR.get('mode')=='MENU_BOOKMARK' and WtkjsYqwiJySrnCNlOFpvMXIxmhVUe==WtkjsYqwiJySrnCNlOFpvMXIxmhVEf:continue
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':WtkjsYqwiJySrnCNlOFpvMXIxmhVUR.get('mode'),'stype':WtkjsYqwiJySrnCNlOFpvMXIxmhVUR.get('stype'),'orderby':WtkjsYqwiJySrnCNlOFpvMXIxmhVUR.get('orderby'),'ordernm':WtkjsYqwiJySrnCNlOFpvMXIxmhVUR.get('ordernm'),'page':'1'}
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVUR.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUH=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUd =WtkjsYqwiJySrnCNlOFpvMXIxmhVEz
   else:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUH=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUd =WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
   if 'icon' in WtkjsYqwiJySrnCNlOFpvMXIxmhVUR:WtkjsYqwiJySrnCNlOFpvMXIxmhVUa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',WtkjsYqwiJySrnCNlOFpvMXIxmhVUR.get('icon')) 
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel='',img=WtkjsYqwiJySrnCNlOFpvMXIxmhVUa,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVUH,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb,isLink=WtkjsYqwiJySrnCNlOFpvMXIxmhVUd)
  xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle)
 def login_main(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB):
  (WtkjsYqwiJySrnCNlOFpvMXIxmhVUu,WtkjsYqwiJySrnCNlOFpvMXIxmhVKG,WtkjsYqwiJySrnCNlOFpvMXIxmhVKU,WtkjsYqwiJySrnCNlOFpvMXIxmhVKQ)=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_settings_account()
  if not(WtkjsYqwiJySrnCNlOFpvMXIxmhVUu and WtkjsYqwiJySrnCNlOFpvMXIxmhVKG):
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGR=xbmcgui.Dialog()
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKc=WtkjsYqwiJySrnCNlOFpvMXIxmhVGR.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVKc==WtkjsYqwiJySrnCNlOFpvMXIxmhVEz:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKA=0
   while WtkjsYqwiJySrnCNlOFpvMXIxmhVEz:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVKA+=1
    time.sleep(0.05)
    if WtkjsYqwiJySrnCNlOFpvMXIxmhVKA>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKe=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.GetCredential(WtkjsYqwiJySrnCNlOFpvMXIxmhVUu,WtkjsYqwiJySrnCNlOFpvMXIxmhVKG,WtkjsYqwiJySrnCNlOFpvMXIxmhVKU,WtkjsYqwiJySrnCNlOFpvMXIxmhVKQ)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKe:WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKe==WtkjsYqwiJySrnCNlOFpvMXIxmhVEf:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKE=WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('stype')
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKE=='live':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKg=WtkjsYqwiJySrnCNlOFpvMXIxmhVGQ
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVKE=='vod':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKg=WtkjsYqwiJySrnCNlOFpvMXIxmhVGe
  else:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKg=WtkjsYqwiJySrnCNlOFpvMXIxmhVGE
  for WtkjsYqwiJySrnCNlOFpvMXIxmhVKP in WtkjsYqwiJySrnCNlOFpvMXIxmhVKg:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB=WtkjsYqwiJySrnCNlOFpvMXIxmhVKP.get('title')
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('ordernm')!='-':
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUB+='  ('+WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('ordernm')+')'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':WtkjsYqwiJySrnCNlOFpvMXIxmhVKP.get('mode'),'stype':WtkjsYqwiJySrnCNlOFpvMXIxmhVKP.get('stype'),'orderby':WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('orderby'),'ordernm':WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('ordernm'),'page':'1'}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel='',img='',infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVER(WtkjsYqwiJySrnCNlOFpvMXIxmhVKg)>0:xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle)
 def dp_SubTitle_Group(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo): 
  for WtkjsYqwiJySrnCNlOFpvMXIxmhVKP in WtkjsYqwiJySrnCNlOFpvMXIxmhVGg:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB=WtkjsYqwiJySrnCNlOFpvMXIxmhVKP.get('title')
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('ordernm')!='-':
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUB+='  ('+WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('ordernm')+')'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':WtkjsYqwiJySrnCNlOFpvMXIxmhVKP.get('mode'),'genreCode':WtkjsYqwiJySrnCNlOFpvMXIxmhVKP.get('genreCode'),'stype':WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('stype'),'orderby':WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('orderby'),'page':'1'}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel='',img='',infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVER(WtkjsYqwiJySrnCNlOFpvMXIxmhVGg)>0:xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle)
 def dp_LiveChannel_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKE =WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('stype')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKB =WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('page'))
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKz,WtkjsYqwiJySrnCNlOFpvMXIxmhVKf=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.GetLiveChannelList(WtkjsYqwiJySrnCNlOFpvMXIxmhVKE,WtkjsYqwiJySrnCNlOFpvMXIxmhVKB)
  for WtkjsYqwiJySrnCNlOFpvMXIxmhVKD in WtkjsYqwiJySrnCNlOFpvMXIxmhVKz:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('title')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUL =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('channel')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKT =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('thumbnail')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKR =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('synopsis')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKa =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('channelepg')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKb =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('cast')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKH =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('director')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKd =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('info_genre')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKL =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('year')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKu =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('mpaa')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQG =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('premiered')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQU={'mediatype':'episode','title':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'studio':WtkjsYqwiJySrnCNlOFpvMXIxmhVUL,'cast':WtkjsYqwiJySrnCNlOFpvMXIxmhVKb,'director':WtkjsYqwiJySrnCNlOFpvMXIxmhVKH,'genre':WtkjsYqwiJySrnCNlOFpvMXIxmhVKd,'plot':'%s\n%s\n%s\n\n%s'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVUL,WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKa,WtkjsYqwiJySrnCNlOFpvMXIxmhVKR),'year':WtkjsYqwiJySrnCNlOFpvMXIxmhVKL,'mpaa':WtkjsYqwiJySrnCNlOFpvMXIxmhVKu,'premiered':WtkjsYqwiJySrnCNlOFpvMXIxmhVQG}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'LIVE','mediacode':WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('mediacode'),'stype':WtkjsYqwiJySrnCNlOFpvMXIxmhVKE}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUL,sublabel=WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,img=WtkjsYqwiJySrnCNlOFpvMXIxmhVKT,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVQU,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKf:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['mode']='CHANNEL' 
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['stype']=WtkjsYqwiJySrnCNlOFpvMXIxmhVKE 
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['page']=WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB='[B]%s >>[/B]'%'다음 페이지'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQK=WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel=WtkjsYqwiJySrnCNlOFpvMXIxmhVQK,img=WtkjsYqwiJySrnCNlOFpvMXIxmhVUa,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVER(WtkjsYqwiJySrnCNlOFpvMXIxmhVKz)>0:xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,cacheToDisc=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf)
 def dp_Program_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVQc =WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('stype')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUP =WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('orderby')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKB =WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('page'))
  WtkjsYqwiJySrnCNlOFpvMXIxmhVQA=WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('genreCode')
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVQA==WtkjsYqwiJySrnCNlOFpvMXIxmhVEo:WtkjsYqwiJySrnCNlOFpvMXIxmhVQA='all'
  WtkjsYqwiJySrnCNlOFpvMXIxmhVQe,WtkjsYqwiJySrnCNlOFpvMXIxmhVKf=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.GetProgramList(WtkjsYqwiJySrnCNlOFpvMXIxmhVQc,WtkjsYqwiJySrnCNlOFpvMXIxmhVUP,WtkjsYqwiJySrnCNlOFpvMXIxmhVKB,WtkjsYqwiJySrnCNlOFpvMXIxmhVQA)
  for WtkjsYqwiJySrnCNlOFpvMXIxmhVQE in WtkjsYqwiJySrnCNlOFpvMXIxmhVQe:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('title')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKT =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('thumbnail')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKR =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('synopsis')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQg =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('channel')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKb =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('cast')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKH =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('director')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKd=WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('info_genre')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKL =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('year')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQG =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('premiered')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKu =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('mpaa')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQU={'mediatype':'tvshow','title':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'studio':WtkjsYqwiJySrnCNlOFpvMXIxmhVQg,'cast':WtkjsYqwiJySrnCNlOFpvMXIxmhVKb,'director':WtkjsYqwiJySrnCNlOFpvMXIxmhVKH,'genre':WtkjsYqwiJySrnCNlOFpvMXIxmhVKd,'year':WtkjsYqwiJySrnCNlOFpvMXIxmhVKL,'premiered':WtkjsYqwiJySrnCNlOFpvMXIxmhVQG,'mpaa':WtkjsYqwiJySrnCNlOFpvMXIxmhVKu,'plot':WtkjsYqwiJySrnCNlOFpvMXIxmhVKR}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'EPISODE','programcode':WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('program'),'page':'1'}
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_settings_makebookmark():
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQP={'videoid':WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('program'),'vidtype':'tvshow','vtitle':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'vsubtitle':WtkjsYqwiJySrnCNlOFpvMXIxmhVQg,}
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQo=json.dumps(WtkjsYqwiJySrnCNlOFpvMXIxmhVQP)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQo=urllib.parse.quote(WtkjsYqwiJySrnCNlOFpvMXIxmhVQo)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQB='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVQo)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQz=[('(통합) 찜 영상에 추가',WtkjsYqwiJySrnCNlOFpvMXIxmhVQB)]
   else:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQz=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel=WtkjsYqwiJySrnCNlOFpvMXIxmhVQg,img=WtkjsYqwiJySrnCNlOFpvMXIxmhVKT,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVQU,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb,ContextMenu=WtkjsYqwiJySrnCNlOFpvMXIxmhVQz)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKf:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['mode'] ='PROGRAM' 
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['stype'] =WtkjsYqwiJySrnCNlOFpvMXIxmhVQc
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['orderby'] =WtkjsYqwiJySrnCNlOFpvMXIxmhVUP
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['page'] =WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['genreCode']=WtkjsYqwiJySrnCNlOFpvMXIxmhVQA 
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB='[B]%s >>[/B]'%'다음 페이지'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQK=WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel=WtkjsYqwiJySrnCNlOFpvMXIxmhVQK,img=WtkjsYqwiJySrnCNlOFpvMXIxmhVUa,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  xbmcplugin.setContent(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,cacheToDisc=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf)
 def dp_4K_Program_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKB =WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('page'))
  WtkjsYqwiJySrnCNlOFpvMXIxmhVQe,WtkjsYqwiJySrnCNlOFpvMXIxmhVKf=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.Get_UHD_ProgramList(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB)
  for WtkjsYqwiJySrnCNlOFpvMXIxmhVQE in WtkjsYqwiJySrnCNlOFpvMXIxmhVQe:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('title')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKT =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('thumbnail')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKR =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('synopsis')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQg =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('channel')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKb =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('cast')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKH =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('director')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKd=WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('info_genre')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKL =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('year')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQG =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('premiered')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKu =WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('mpaa')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQU={'mediatype':'tvshow','title':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'studio':WtkjsYqwiJySrnCNlOFpvMXIxmhVQg,'cast':WtkjsYqwiJySrnCNlOFpvMXIxmhVKb,'director':WtkjsYqwiJySrnCNlOFpvMXIxmhVKH,'genre':WtkjsYqwiJySrnCNlOFpvMXIxmhVKd,'year':WtkjsYqwiJySrnCNlOFpvMXIxmhVKL,'premiered':WtkjsYqwiJySrnCNlOFpvMXIxmhVQG,'mpaa':WtkjsYqwiJySrnCNlOFpvMXIxmhVKu,'plot':WtkjsYqwiJySrnCNlOFpvMXIxmhVKR}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'EPISODE','programcode':WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('program'),'page':'1'}
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_settings_makebookmark():
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQP={'videoid':WtkjsYqwiJySrnCNlOFpvMXIxmhVQE.get('program'),'vidtype':'tvshow','vtitle':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'vsubtitle':WtkjsYqwiJySrnCNlOFpvMXIxmhVQg,}
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQo=json.dumps(WtkjsYqwiJySrnCNlOFpvMXIxmhVQP)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQo=urllib.parse.quote(WtkjsYqwiJySrnCNlOFpvMXIxmhVQo)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQB='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVQo)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQz=[('(통합) 찜 영상에 추가',WtkjsYqwiJySrnCNlOFpvMXIxmhVQB)]
   else:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQz=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel=WtkjsYqwiJySrnCNlOFpvMXIxmhVQg,img=WtkjsYqwiJySrnCNlOFpvMXIxmhVKT,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVQU,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb,ContextMenu=WtkjsYqwiJySrnCNlOFpvMXIxmhVQz)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKf:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['mode'] ='4K_PROGRAM' 
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['page'] =WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB='[B]%s >>[/B]'%'다음 페이지'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQK=WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel=WtkjsYqwiJySrnCNlOFpvMXIxmhVQK,img=WtkjsYqwiJySrnCNlOFpvMXIxmhVUa,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  xbmcplugin.setContent(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,cacheToDisc=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf)
 def dp_Episode_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVQD=WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('programcode')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKB =WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('page'))
  WtkjsYqwiJySrnCNlOFpvMXIxmhVQT,WtkjsYqwiJySrnCNlOFpvMXIxmhVKf,WtkjsYqwiJySrnCNlOFpvMXIxmhVQR=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.GetEpisodeList(WtkjsYqwiJySrnCNlOFpvMXIxmhVQD,WtkjsYqwiJySrnCNlOFpvMXIxmhVKB,orderby=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_winEpisodeOrderby())
  for WtkjsYqwiJySrnCNlOFpvMXIxmhVQa in WtkjsYqwiJySrnCNlOFpvMXIxmhVQT:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB =WtkjsYqwiJySrnCNlOFpvMXIxmhVQa.get('title')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQK =WtkjsYqwiJySrnCNlOFpvMXIxmhVQa.get('subtitle')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKT =WtkjsYqwiJySrnCNlOFpvMXIxmhVQa.get('thumbnail')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKR =WtkjsYqwiJySrnCNlOFpvMXIxmhVQa.get('synopsis')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQb=WtkjsYqwiJySrnCNlOFpvMXIxmhVQa.get('info_title')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQH =WtkjsYqwiJySrnCNlOFpvMXIxmhVQa.get('aired')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQd =WtkjsYqwiJySrnCNlOFpvMXIxmhVQa.get('studio')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQL =WtkjsYqwiJySrnCNlOFpvMXIxmhVQa.get('frequency')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQU={'mediatype':'episode','title':WtkjsYqwiJySrnCNlOFpvMXIxmhVQb,'aired':WtkjsYqwiJySrnCNlOFpvMXIxmhVQH,'studio':WtkjsYqwiJySrnCNlOFpvMXIxmhVQd,'episode':WtkjsYqwiJySrnCNlOFpvMXIxmhVQL,'plot':WtkjsYqwiJySrnCNlOFpvMXIxmhVKR}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'VOD','mediacode':WtkjsYqwiJySrnCNlOFpvMXIxmhVQa.get('episode'),'stype':'vod','programcode':WtkjsYqwiJySrnCNlOFpvMXIxmhVQD,'title':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'thumbnail':WtkjsYqwiJySrnCNlOFpvMXIxmhVKT}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel=WtkjsYqwiJySrnCNlOFpvMXIxmhVQK,img=WtkjsYqwiJySrnCNlOFpvMXIxmhVKT,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVQU,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKB==1:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQU={'plot':'정렬순서를 변경합니다.'}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['mode'] ='ORDER_BY' 
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_winEpisodeOrderby()=='desc':
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUB='정렬순서변경 : 최신화부터 -> 1회부터'
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['orderby']='asc'
   else:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUB='정렬순서변경 : 1회부터 -> 최신화부터'
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['orderby']='desc'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel='',img=WtkjsYqwiJySrnCNlOFpvMXIxmhVUa,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVQU,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb,isLink=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKf:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['mode'] ='EPISODE' 
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['programcode']=WtkjsYqwiJySrnCNlOFpvMXIxmhVQD
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['page'] =WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB='[B]%s >>[/B]'%'다음 페이지'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQK=WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel=WtkjsYqwiJySrnCNlOFpvMXIxmhVQK,img=WtkjsYqwiJySrnCNlOFpvMXIxmhVUa,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  xbmcplugin.setContent(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,'episodes')
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVER(WtkjsYqwiJySrnCNlOFpvMXIxmhVQT)>0:xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,cacheToDisc=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz)
 def dp_setEpOrderby(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUP =WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('orderby')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.set_winEpisodeOrderby(WtkjsYqwiJySrnCNlOFpvMXIxmhVUP)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVQc =WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('stype')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUP =WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('orderby')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKB=WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('page'))
  WtkjsYqwiJySrnCNlOFpvMXIxmhVQu,WtkjsYqwiJySrnCNlOFpvMXIxmhVKf=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.GetMovieList(WtkjsYqwiJySrnCNlOFpvMXIxmhVQc,WtkjsYqwiJySrnCNlOFpvMXIxmhVUP,WtkjsYqwiJySrnCNlOFpvMXIxmhVKB)
  for WtkjsYqwiJySrnCNlOFpvMXIxmhVcG in WtkjsYqwiJySrnCNlOFpvMXIxmhVQu:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('title')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKT =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('thumbnail')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKR =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('synopsis')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQb =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('info_title')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKL =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('year')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKb =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('cast')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKH =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('director')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKd =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('info_genre')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVcU =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('duration')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQG =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('premiered')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQd =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('studio')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKu =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('mpaa')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQU={'mediatype':'movie','title':WtkjsYqwiJySrnCNlOFpvMXIxmhVQb,'year':WtkjsYqwiJySrnCNlOFpvMXIxmhVKL,'cast':WtkjsYqwiJySrnCNlOFpvMXIxmhVKb,'director':WtkjsYqwiJySrnCNlOFpvMXIxmhVKH,'genre':WtkjsYqwiJySrnCNlOFpvMXIxmhVKd,'duration':WtkjsYqwiJySrnCNlOFpvMXIxmhVcU,'premiered':WtkjsYqwiJySrnCNlOFpvMXIxmhVQG,'studio':WtkjsYqwiJySrnCNlOFpvMXIxmhVQd,'mpaa':WtkjsYqwiJySrnCNlOFpvMXIxmhVKu,'plot':WtkjsYqwiJySrnCNlOFpvMXIxmhVKR}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'MOVIE','mediacode':WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('moviecode'),'stype':'movie','title':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'thumbnail':WtkjsYqwiJySrnCNlOFpvMXIxmhVKT}
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_settings_makebookmark():
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQP={'videoid':WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('moviecode'),'vidtype':'movie','vtitle':WtkjsYqwiJySrnCNlOFpvMXIxmhVQb,'vsubtitle':'',}
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQo=json.dumps(WtkjsYqwiJySrnCNlOFpvMXIxmhVQP)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQo=urllib.parse.quote(WtkjsYqwiJySrnCNlOFpvMXIxmhVQo)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQB='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVQo)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQz=[('(통합) 찜 영상에 추가',WtkjsYqwiJySrnCNlOFpvMXIxmhVQB)]
   else:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQz=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel='',img=WtkjsYqwiJySrnCNlOFpvMXIxmhVKT,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVQU,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb,ContextMenu=WtkjsYqwiJySrnCNlOFpvMXIxmhVQz)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKf:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['mode'] ='MOVIE_SUB' 
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['orderby']=WtkjsYqwiJySrnCNlOFpvMXIxmhVUP
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['stype'] =WtkjsYqwiJySrnCNlOFpvMXIxmhVQc
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['page'] =WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB='[B]%s >>[/B]'%'다음 페이지'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQK=WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel=WtkjsYqwiJySrnCNlOFpvMXIxmhVQK,img=WtkjsYqwiJySrnCNlOFpvMXIxmhVUa,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  xbmcplugin.setContent(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,'movies')
  xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,cacheToDisc=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf)
 def dp_4K_Movie_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKB=WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('page'))
  WtkjsYqwiJySrnCNlOFpvMXIxmhVQu,WtkjsYqwiJySrnCNlOFpvMXIxmhVKf=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.Get_UHD_MovieList(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB)
  for WtkjsYqwiJySrnCNlOFpvMXIxmhVcG in WtkjsYqwiJySrnCNlOFpvMXIxmhVQu:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('title')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKT =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('thumbnail')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKR =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('synopsis')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQb =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('info_title')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKL =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('year')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKb =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('cast')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKH =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('director')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKd =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('info_genre')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVcU =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('duration')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQG =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('premiered')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQd =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('studio')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKu =WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('mpaa')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQU={'mediatype':'movie','title':WtkjsYqwiJySrnCNlOFpvMXIxmhVQb,'year':WtkjsYqwiJySrnCNlOFpvMXIxmhVKL,'cast':WtkjsYqwiJySrnCNlOFpvMXIxmhVKb,'director':WtkjsYqwiJySrnCNlOFpvMXIxmhVKH,'genre':WtkjsYqwiJySrnCNlOFpvMXIxmhVKd,'duration':WtkjsYqwiJySrnCNlOFpvMXIxmhVcU,'premiered':WtkjsYqwiJySrnCNlOFpvMXIxmhVQG,'studio':WtkjsYqwiJySrnCNlOFpvMXIxmhVQd,'mpaa':WtkjsYqwiJySrnCNlOFpvMXIxmhVKu,'plot':WtkjsYqwiJySrnCNlOFpvMXIxmhVKR}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'MOVIE','mediacode':WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('moviecode'),'stype':'movie','title':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'thumbnail':WtkjsYqwiJySrnCNlOFpvMXIxmhVKT}
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_settings_makebookmark():
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQP={'videoid':WtkjsYqwiJySrnCNlOFpvMXIxmhVcG.get('moviecode'),'vidtype':'movie','vtitle':WtkjsYqwiJySrnCNlOFpvMXIxmhVQb,'vsubtitle':'',}
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQo=json.dumps(WtkjsYqwiJySrnCNlOFpvMXIxmhVQP)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQo=urllib.parse.quote(WtkjsYqwiJySrnCNlOFpvMXIxmhVQo)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQB='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVQo)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQz=[('(통합) 찜 영상에 추가',WtkjsYqwiJySrnCNlOFpvMXIxmhVQB)]
   else:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQz=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel='',img=WtkjsYqwiJySrnCNlOFpvMXIxmhVKT,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVQU,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb,ContextMenu=WtkjsYqwiJySrnCNlOFpvMXIxmhVQz)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKf:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['mode'] ='4K_MOVIE' 
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['page'] =WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB='[B]%s >>[/B]'%'다음 페이지'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQK=WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel=WtkjsYqwiJySrnCNlOFpvMXIxmhVQK,img=WtkjsYqwiJySrnCNlOFpvMXIxmhVUa,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  xbmcplugin.setContent(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,'movies')
  xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,cacheToDisc=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf)
 def dp_Set_Bookmark(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcK=urllib.parse.unquote(WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('bm_param'))
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcK=json.loads(WtkjsYqwiJySrnCNlOFpvMXIxmhVcK)
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcQ =WtkjsYqwiJySrnCNlOFpvMXIxmhVcK.get('videoid')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcA =WtkjsYqwiJySrnCNlOFpvMXIxmhVcK.get('vidtype')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVce =WtkjsYqwiJySrnCNlOFpvMXIxmhVcK.get('vtitle')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcE =WtkjsYqwiJySrnCNlOFpvMXIxmhVcK.get('vsubtitle')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGR=xbmcgui.Dialog()
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKc=WtkjsYqwiJySrnCNlOFpvMXIxmhVGR.yesno(__language__(30913).encode('utf8'),WtkjsYqwiJySrnCNlOFpvMXIxmhVce+' \n\n'+__language__(30914))
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKc==WtkjsYqwiJySrnCNlOFpvMXIxmhVEf:return
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcg=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.GetBookmarkInfo(WtkjsYqwiJySrnCNlOFpvMXIxmhVcQ,WtkjsYqwiJySrnCNlOFpvMXIxmhVcA)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVcE!='':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVcg['saveinfo']['subtitle']=WtkjsYqwiJySrnCNlOFpvMXIxmhVcE 
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVcA=='tvshow':WtkjsYqwiJySrnCNlOFpvMXIxmhVcg['saveinfo']['infoLabels']['studio']=WtkjsYqwiJySrnCNlOFpvMXIxmhVcE 
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcP=json.dumps(WtkjsYqwiJySrnCNlOFpvMXIxmhVcg)
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcP=urllib.parse.quote(WtkjsYqwiJySrnCNlOFpvMXIxmhVcP)
  WtkjsYqwiJySrnCNlOFpvMXIxmhVQB ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVcP)
  xbmc.executebuiltin(WtkjsYqwiJySrnCNlOFpvMXIxmhVQB)
 def dp_Search_Group(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  if 'search_key' in WtkjsYqwiJySrnCNlOFpvMXIxmhVKo:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVco=WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('search_key')
  else:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVco=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not WtkjsYqwiJySrnCNlOFpvMXIxmhVco:
    return
  for WtkjsYqwiJySrnCNlOFpvMXIxmhVKP in WtkjsYqwiJySrnCNlOFpvMXIxmhVGA:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVcB =WtkjsYqwiJySrnCNlOFpvMXIxmhVKP.get('mode')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKE=WtkjsYqwiJySrnCNlOFpvMXIxmhVKP.get('stype')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB=WtkjsYqwiJySrnCNlOFpvMXIxmhVKP.get('title')
   (WtkjsYqwiJySrnCNlOFpvMXIxmhVcz,WtkjsYqwiJySrnCNlOFpvMXIxmhVKf)=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.GetSearchList(WtkjsYqwiJySrnCNlOFpvMXIxmhVco,1,WtkjsYqwiJySrnCNlOFpvMXIxmhVKE)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVcf={'plot':'검색어 : '+WtkjsYqwiJySrnCNlOFpvMXIxmhVco+'\n\n'+WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.Search_FreeList(WtkjsYqwiJySrnCNlOFpvMXIxmhVcz)}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':WtkjsYqwiJySrnCNlOFpvMXIxmhVcB,'stype':WtkjsYqwiJySrnCNlOFpvMXIxmhVKE,'search_key':WtkjsYqwiJySrnCNlOFpvMXIxmhVco,'page':'1',}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel='',img='',infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVcf,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVER(WtkjsYqwiJySrnCNlOFpvMXIxmhVGA)>0:xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,cacheToDisc=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz)
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.Save_Searched_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVco)
 def Search_FreeList(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVcu):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcD=''
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcT=7
  try:
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVER(WtkjsYqwiJySrnCNlOFpvMXIxmhVcu)==0:return '검색결과 없음'
   for i in WtkjsYqwiJySrnCNlOFpvMXIxmhVEb(WtkjsYqwiJySrnCNlOFpvMXIxmhVER(WtkjsYqwiJySrnCNlOFpvMXIxmhVcu)):
    if i>=WtkjsYqwiJySrnCNlOFpvMXIxmhVcT:
     WtkjsYqwiJySrnCNlOFpvMXIxmhVcD=WtkjsYqwiJySrnCNlOFpvMXIxmhVcD+'...'
     break
    WtkjsYqwiJySrnCNlOFpvMXIxmhVcD=WtkjsYqwiJySrnCNlOFpvMXIxmhVcD+WtkjsYqwiJySrnCNlOFpvMXIxmhVcu[i]['title']+'\n'
  except:
   return ''
  return WtkjsYqwiJySrnCNlOFpvMXIxmhVcD
 def dp_Search_History(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcR=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.Load_List_File('search')
  for WtkjsYqwiJySrnCNlOFpvMXIxmhVca in WtkjsYqwiJySrnCNlOFpvMXIxmhVcR:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVcb=WtkjsYqwiJySrnCNlOFpvMXIxmhVET(urllib.parse.parse_qsl(WtkjsYqwiJySrnCNlOFpvMXIxmhVca))
   WtkjsYqwiJySrnCNlOFpvMXIxmhVcH=WtkjsYqwiJySrnCNlOFpvMXIxmhVcb.get('skey').strip()
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'SEARCH_GROUP','search_key':WtkjsYqwiJySrnCNlOFpvMXIxmhVcH,}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVcd={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':WtkjsYqwiJySrnCNlOFpvMXIxmhVcH,'vType':'-',}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVcL=urllib.parse.urlencode(WtkjsYqwiJySrnCNlOFpvMXIxmhVcd)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQz=[('선택된 검색어 ( %s ) 삭제'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVcH),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVcL))]
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVcH,sublabel='',img=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb,ContextMenu=WtkjsYqwiJySrnCNlOFpvMXIxmhVQz)
  WtkjsYqwiJySrnCNlOFpvMXIxmhVQU={'plot':'검색목록 전체를 삭제합니다.'}
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUB='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel='',img=WtkjsYqwiJySrnCNlOFpvMXIxmhVUa,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVQU,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb,isLink=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz)
  xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,cacheToDisc=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf)
 def dp_Search_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKB =WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('page'))
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKE =WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('stype')
  if 'search_key' in WtkjsYqwiJySrnCNlOFpvMXIxmhVKo:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVco=WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('search_key')
  else:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVco=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not WtkjsYqwiJySrnCNlOFpvMXIxmhVco:
    xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle)
    return
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcz,WtkjsYqwiJySrnCNlOFpvMXIxmhVKf=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.GetSearchList(WtkjsYqwiJySrnCNlOFpvMXIxmhVco,WtkjsYqwiJySrnCNlOFpvMXIxmhVKB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKE)
  for WtkjsYqwiJySrnCNlOFpvMXIxmhVcu in WtkjsYqwiJySrnCNlOFpvMXIxmhVcz:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB =WtkjsYqwiJySrnCNlOFpvMXIxmhVcu.get('title')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKT =WtkjsYqwiJySrnCNlOFpvMXIxmhVcu.get('thumbnail')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKR =WtkjsYqwiJySrnCNlOFpvMXIxmhVcu.get('synopsis')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAG =WtkjsYqwiJySrnCNlOFpvMXIxmhVcu.get('program')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKb =WtkjsYqwiJySrnCNlOFpvMXIxmhVcu.get('cast')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKH =WtkjsYqwiJySrnCNlOFpvMXIxmhVcu.get('director')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKd=WtkjsYqwiJySrnCNlOFpvMXIxmhVcu.get('info_genre')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVcU =WtkjsYqwiJySrnCNlOFpvMXIxmhVcu.get('duration')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKu =WtkjsYqwiJySrnCNlOFpvMXIxmhVcu.get('mpaa')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKL =WtkjsYqwiJySrnCNlOFpvMXIxmhVcu.get('year')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQH =WtkjsYqwiJySrnCNlOFpvMXIxmhVcu.get('aired')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQU={'mediatype':'tvshow' if WtkjsYqwiJySrnCNlOFpvMXIxmhVKE=='vod' else 'movie','title':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'cast':WtkjsYqwiJySrnCNlOFpvMXIxmhVKb,'director':WtkjsYqwiJySrnCNlOFpvMXIxmhVKH,'genre':WtkjsYqwiJySrnCNlOFpvMXIxmhVKd,'duration':WtkjsYqwiJySrnCNlOFpvMXIxmhVcU,'mpaa':WtkjsYqwiJySrnCNlOFpvMXIxmhVKu,'year':WtkjsYqwiJySrnCNlOFpvMXIxmhVKL,'aired':WtkjsYqwiJySrnCNlOFpvMXIxmhVQH,'plot':'%s\n\n%s'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKR)}
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVKE=='vod':
    WtkjsYqwiJySrnCNlOFpvMXIxmhVcQ=WtkjsYqwiJySrnCNlOFpvMXIxmhVcu.get('program')
    WtkjsYqwiJySrnCNlOFpvMXIxmhVcA='tvshow'
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'EPISODE','programcode':WtkjsYqwiJySrnCNlOFpvMXIxmhVcQ,'page':'1',}
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUH=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz
   else:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVcQ=WtkjsYqwiJySrnCNlOFpvMXIxmhVcu.get('movie')
    WtkjsYqwiJySrnCNlOFpvMXIxmhVcA='movie'
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'MOVIE','mediacode':WtkjsYqwiJySrnCNlOFpvMXIxmhVcQ,'stype':'movie','title':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'thumbnail':WtkjsYqwiJySrnCNlOFpvMXIxmhVKT,}
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUH=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_settings_makebookmark():
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQP={'videoid':WtkjsYqwiJySrnCNlOFpvMXIxmhVcQ,'vidtype':WtkjsYqwiJySrnCNlOFpvMXIxmhVcA,'vtitle':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'vsubtitle':'',}
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQo=json.dumps(WtkjsYqwiJySrnCNlOFpvMXIxmhVQP)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQo=urllib.parse.quote(WtkjsYqwiJySrnCNlOFpvMXIxmhVQo)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQB='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVQo)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQz=[('(통합) 찜 영상에 추가',WtkjsYqwiJySrnCNlOFpvMXIxmhVQB)]
   else:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQz=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel='',img=WtkjsYqwiJySrnCNlOFpvMXIxmhVKT,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVQU,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVUH,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb,isLink=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf,ContextMenu=WtkjsYqwiJySrnCNlOFpvMXIxmhVQz)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKf:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['mode'] ='SEARCH' 
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['search_key']=WtkjsYqwiJySrnCNlOFpvMXIxmhVco
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb['page'] =WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB='[B]%s >>[/B]'%'다음 페이지'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQK=WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVKB+1)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel=WtkjsYqwiJySrnCNlOFpvMXIxmhVQK,img=WtkjsYqwiJySrnCNlOFpvMXIxmhVUa,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKE=='movie':xbmcplugin.setContent(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,'movies')
  else:xbmcplugin.setContent(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,cacheToDisc=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf)
 def dp_History_Remove(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVAU=WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('delType')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVAK =WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('sKey')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVAQ =WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('vType')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGR=xbmcgui.Dialog()
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVAU=='SEARCH_ALL':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKc=WtkjsYqwiJySrnCNlOFpvMXIxmhVGR.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVAU=='SEARCH_ONE':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKc=WtkjsYqwiJySrnCNlOFpvMXIxmhVGR.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVAU=='WATCH_ALL':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKc=WtkjsYqwiJySrnCNlOFpvMXIxmhVGR.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVAU=='WATCH_ONE':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVKc=WtkjsYqwiJySrnCNlOFpvMXIxmhVGR.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKc==WtkjsYqwiJySrnCNlOFpvMXIxmhVEf:sys.exit()
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVAU=='SEARCH_ALL':
   if os.path.isfile(WtkjsYqwiJySrnCNlOFpvMXIxmhVGo):os.remove(WtkjsYqwiJySrnCNlOFpvMXIxmhVGo)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVAU=='SEARCH_ONE':
   try:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVAc=WtkjsYqwiJySrnCNlOFpvMXIxmhVGo
    WtkjsYqwiJySrnCNlOFpvMXIxmhVAe=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.Load_List_File('search') 
    fp=WtkjsYqwiJySrnCNlOFpvMXIxmhVEH(WtkjsYqwiJySrnCNlOFpvMXIxmhVAc,'w',-1,'utf-8')
    for WtkjsYqwiJySrnCNlOFpvMXIxmhVAE in WtkjsYqwiJySrnCNlOFpvMXIxmhVAe:
     WtkjsYqwiJySrnCNlOFpvMXIxmhVAg=WtkjsYqwiJySrnCNlOFpvMXIxmhVET(urllib.parse.parse_qsl(WtkjsYqwiJySrnCNlOFpvMXIxmhVAE))
     WtkjsYqwiJySrnCNlOFpvMXIxmhVAP=WtkjsYqwiJySrnCNlOFpvMXIxmhVAg.get('skey').strip()
     if WtkjsYqwiJySrnCNlOFpvMXIxmhVAK!=WtkjsYqwiJySrnCNlOFpvMXIxmhVAP:
      fp.write(WtkjsYqwiJySrnCNlOFpvMXIxmhVAE)
    fp.close()
   except:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVAU=='WATCH_ALL':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAc=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WtkjsYqwiJySrnCNlOFpvMXIxmhVAQ))
   if os.path.isfile(WtkjsYqwiJySrnCNlOFpvMXIxmhVAc):os.remove(WtkjsYqwiJySrnCNlOFpvMXIxmhVAc)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVAU=='WATCH_ONE':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAc=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WtkjsYqwiJySrnCNlOFpvMXIxmhVAQ))
   try:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVAe=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.Load_List_File(WtkjsYqwiJySrnCNlOFpvMXIxmhVAQ) 
    fp=WtkjsYqwiJySrnCNlOFpvMXIxmhVEH(WtkjsYqwiJySrnCNlOFpvMXIxmhVAc,'w',-1,'utf-8')
    for WtkjsYqwiJySrnCNlOFpvMXIxmhVAE in WtkjsYqwiJySrnCNlOFpvMXIxmhVAe:
     WtkjsYqwiJySrnCNlOFpvMXIxmhVAg=WtkjsYqwiJySrnCNlOFpvMXIxmhVET(urllib.parse.parse_qsl(WtkjsYqwiJySrnCNlOFpvMXIxmhVAE))
     WtkjsYqwiJySrnCNlOFpvMXIxmhVAP=WtkjsYqwiJySrnCNlOFpvMXIxmhVAg.get('code').strip()
     if WtkjsYqwiJySrnCNlOFpvMXIxmhVAK!=WtkjsYqwiJySrnCNlOFpvMXIxmhVAP:
      fp.write(WtkjsYqwiJySrnCNlOFpvMXIxmhVAE)
    fp.close()
   except:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKE): 
  try:
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVKE=='search':
    WtkjsYqwiJySrnCNlOFpvMXIxmhVAc=WtkjsYqwiJySrnCNlOFpvMXIxmhVGo
   elif WtkjsYqwiJySrnCNlOFpvMXIxmhVKE in['vod','movie']:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVAc=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WtkjsYqwiJySrnCNlOFpvMXIxmhVKE))
   else:
    return[]
   fp=WtkjsYqwiJySrnCNlOFpvMXIxmhVEH(WtkjsYqwiJySrnCNlOFpvMXIxmhVAc,'r',-1,'utf-8')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAo=fp.readlines()
   fp.close()
  except:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAo=[]
  return WtkjsYqwiJySrnCNlOFpvMXIxmhVAo
 def Save_Watched_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKE,WtkjsYqwiJySrnCNlOFpvMXIxmhVGD):
  try:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAB=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%WtkjsYqwiJySrnCNlOFpvMXIxmhVKE))
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAe=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.Load_List_File(WtkjsYqwiJySrnCNlOFpvMXIxmhVKE) 
   fp=WtkjsYqwiJySrnCNlOFpvMXIxmhVEH(WtkjsYqwiJySrnCNlOFpvMXIxmhVAB,'w',-1,'utf-8')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAz=urllib.parse.urlencode(WtkjsYqwiJySrnCNlOFpvMXIxmhVGD)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAz=WtkjsYqwiJySrnCNlOFpvMXIxmhVAz+'\n'
   fp.write(WtkjsYqwiJySrnCNlOFpvMXIxmhVAz)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAf=0
   for WtkjsYqwiJySrnCNlOFpvMXIxmhVAE in WtkjsYqwiJySrnCNlOFpvMXIxmhVAe:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVAg=WtkjsYqwiJySrnCNlOFpvMXIxmhVET(urllib.parse.parse_qsl(WtkjsYqwiJySrnCNlOFpvMXIxmhVAE))
    WtkjsYqwiJySrnCNlOFpvMXIxmhVAD=WtkjsYqwiJySrnCNlOFpvMXIxmhVGD.get('code').strip()
    WtkjsYqwiJySrnCNlOFpvMXIxmhVAT=WtkjsYqwiJySrnCNlOFpvMXIxmhVAg.get('code').strip()
    if WtkjsYqwiJySrnCNlOFpvMXIxmhVKE=='vod' and WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_settings_direct_replay()==WtkjsYqwiJySrnCNlOFpvMXIxmhVEz:
     WtkjsYqwiJySrnCNlOFpvMXIxmhVAD=WtkjsYqwiJySrnCNlOFpvMXIxmhVGD.get('videoid').strip()
     WtkjsYqwiJySrnCNlOFpvMXIxmhVAT=WtkjsYqwiJySrnCNlOFpvMXIxmhVAg.get('videoid').strip()if WtkjsYqwiJySrnCNlOFpvMXIxmhVAT!=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo else '-'
    if WtkjsYqwiJySrnCNlOFpvMXIxmhVAD!=WtkjsYqwiJySrnCNlOFpvMXIxmhVAT:
     fp.write(WtkjsYqwiJySrnCNlOFpvMXIxmhVAE)
     WtkjsYqwiJySrnCNlOFpvMXIxmhVAf+=1
     if WtkjsYqwiJySrnCNlOFpvMXIxmhVAf>=50:break
   fp.close()
  except:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
 def dp_Watch_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKE =WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('stype')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVUE=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_settings_direct_replay()
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKE=='-':
   for WtkjsYqwiJySrnCNlOFpvMXIxmhVKP in WtkjsYqwiJySrnCNlOFpvMXIxmhVGc:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUB=WtkjsYqwiJySrnCNlOFpvMXIxmhVKP.get('title')
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':WtkjsYqwiJySrnCNlOFpvMXIxmhVKP.get('mode'),'stype':WtkjsYqwiJySrnCNlOFpvMXIxmhVKP.get('stype')}
    WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel='',img='',infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVEo,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVER(WtkjsYqwiJySrnCNlOFpvMXIxmhVGc)>0:xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle)
  else:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAR=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.Load_List_File(WtkjsYqwiJySrnCNlOFpvMXIxmhVKE)
   for WtkjsYqwiJySrnCNlOFpvMXIxmhVAa in WtkjsYqwiJySrnCNlOFpvMXIxmhVAR:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVcb=WtkjsYqwiJySrnCNlOFpvMXIxmhVET(urllib.parse.parse_qsl(WtkjsYqwiJySrnCNlOFpvMXIxmhVAa))
    WtkjsYqwiJySrnCNlOFpvMXIxmhVAb =WtkjsYqwiJySrnCNlOFpvMXIxmhVcb.get('code').strip()
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUB =WtkjsYqwiJySrnCNlOFpvMXIxmhVcb.get('title').strip()
    WtkjsYqwiJySrnCNlOFpvMXIxmhVKT=WtkjsYqwiJySrnCNlOFpvMXIxmhVcb.get('img').strip()
    WtkjsYqwiJySrnCNlOFpvMXIxmhVcQ =WtkjsYqwiJySrnCNlOFpvMXIxmhVcb.get('videoid').strip()
    try:
     WtkjsYqwiJySrnCNlOFpvMXIxmhVKT=WtkjsYqwiJySrnCNlOFpvMXIxmhVKT.replace('\'','\"')
     WtkjsYqwiJySrnCNlOFpvMXIxmhVKT=json.loads(WtkjsYqwiJySrnCNlOFpvMXIxmhVKT)
    except:
     WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQU={}
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQU['plot']=WtkjsYqwiJySrnCNlOFpvMXIxmhVUB
    if WtkjsYqwiJySrnCNlOFpvMXIxmhVKE=='vod':
     if WtkjsYqwiJySrnCNlOFpvMXIxmhVUE==WtkjsYqwiJySrnCNlOFpvMXIxmhVEf or WtkjsYqwiJySrnCNlOFpvMXIxmhVcQ==WtkjsYqwiJySrnCNlOFpvMXIxmhVEo:
      WtkjsYqwiJySrnCNlOFpvMXIxmhVQU['mediatype']='tvshow'
      WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'EPISODE','programcode':WtkjsYqwiJySrnCNlOFpvMXIxmhVAb,'page':'1'}
      WtkjsYqwiJySrnCNlOFpvMXIxmhVUH=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz
     else:
      WtkjsYqwiJySrnCNlOFpvMXIxmhVQU['mediatype']='episode'
      WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'VOD','mediacode':WtkjsYqwiJySrnCNlOFpvMXIxmhVcQ,'stype':'vod','programcode':WtkjsYqwiJySrnCNlOFpvMXIxmhVAb,'title':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'thumbnail':WtkjsYqwiJySrnCNlOFpvMXIxmhVKT}
      WtkjsYqwiJySrnCNlOFpvMXIxmhVUH=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
    else:
     WtkjsYqwiJySrnCNlOFpvMXIxmhVQU['mediatype']='movie'
     WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'MOVIE','mediacode':WtkjsYqwiJySrnCNlOFpvMXIxmhVAb,'stype':'movie','title':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'thumbnail':WtkjsYqwiJySrnCNlOFpvMXIxmhVKT}
     WtkjsYqwiJySrnCNlOFpvMXIxmhVUH=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
    WtkjsYqwiJySrnCNlOFpvMXIxmhVcd={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':WtkjsYqwiJySrnCNlOFpvMXIxmhVAb,'vType':WtkjsYqwiJySrnCNlOFpvMXIxmhVKE,}
    WtkjsYqwiJySrnCNlOFpvMXIxmhVcL=urllib.parse.urlencode(WtkjsYqwiJySrnCNlOFpvMXIxmhVcd)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVQz=[('선택된 시청이력 ( %s ) 삭제'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVcL))]
    WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel='',img=WtkjsYqwiJySrnCNlOFpvMXIxmhVKT,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVQU,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVUH,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb,ContextMenu=WtkjsYqwiJySrnCNlOFpvMXIxmhVQz)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQU={'plot':'시청목록을 삭제합니다.'}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':WtkjsYqwiJySrnCNlOFpvMXIxmhVKE,}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUa=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel='',img=WtkjsYqwiJySrnCNlOFpvMXIxmhVUa,infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVQU,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb,isLink=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz)
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVKE=='movie':xbmcplugin.setContent(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,'movies')
   else:xbmcplugin.setContent(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,cacheToDisc=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf)
 def Save_Searched_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVco):
  try:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAH=WtkjsYqwiJySrnCNlOFpvMXIxmhVGo
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAe=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.Load_List_File('search') 
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAd={'skey':WtkjsYqwiJySrnCNlOFpvMXIxmhVco.strip()}
   fp=WtkjsYqwiJySrnCNlOFpvMXIxmhVEH(WtkjsYqwiJySrnCNlOFpvMXIxmhVAH,'w',-1,'utf-8')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAz=urllib.parse.urlencode(WtkjsYqwiJySrnCNlOFpvMXIxmhVAd)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAz=WtkjsYqwiJySrnCNlOFpvMXIxmhVAz+'\n'
   fp.write(WtkjsYqwiJySrnCNlOFpvMXIxmhVAz)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVAf=0
   for WtkjsYqwiJySrnCNlOFpvMXIxmhVAE in WtkjsYqwiJySrnCNlOFpvMXIxmhVAe:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVAg=WtkjsYqwiJySrnCNlOFpvMXIxmhVET(urllib.parse.parse_qsl(WtkjsYqwiJySrnCNlOFpvMXIxmhVAE))
    WtkjsYqwiJySrnCNlOFpvMXIxmhVAD=WtkjsYqwiJySrnCNlOFpvMXIxmhVAd.get('skey').strip()
    WtkjsYqwiJySrnCNlOFpvMXIxmhVAT=WtkjsYqwiJySrnCNlOFpvMXIxmhVAg.get('skey').strip()
    if WtkjsYqwiJySrnCNlOFpvMXIxmhVAD!=WtkjsYqwiJySrnCNlOFpvMXIxmhVAT:
     fp.write(WtkjsYqwiJySrnCNlOFpvMXIxmhVAE)
     WtkjsYqwiJySrnCNlOFpvMXIxmhVAf+=1
     if WtkjsYqwiJySrnCNlOFpvMXIxmhVAf>=50:break
   fp.close()
  except:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
 def play_VIDEO(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVAL =WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('mediacode')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKE =WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('stype')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVAu =WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('pvrmode')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVeG=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_selQuality(WtkjsYqwiJySrnCNlOFpvMXIxmhVKE)
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVAL,WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVeG),WtkjsYqwiJySrnCNlOFpvMXIxmhVKE,WtkjsYqwiJySrnCNlOFpvMXIxmhVAu))
  WtkjsYqwiJySrnCNlOFpvMXIxmhVeU=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.GetBroadURL(WtkjsYqwiJySrnCNlOFpvMXIxmhVAL,WtkjsYqwiJySrnCNlOFpvMXIxmhVeG,WtkjsYqwiJySrnCNlOFpvMXIxmhVKE,WtkjsYqwiJySrnCNlOFpvMXIxmhVAu,optUHD=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_settings_uhd())
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.addon_log('qt, stype, url : %s - %s - %s'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVEa(WtkjsYqwiJySrnCNlOFpvMXIxmhVeG),WtkjsYqwiJySrnCNlOFpvMXIxmhVKE,WtkjsYqwiJySrnCNlOFpvMXIxmhVeU['streaming_url']))
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVeU['streaming_url']=='':
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVeU['error_msg']=='':
    WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.addon_noti(__language__(30908).encode('utf8'))
   else:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.addon_noti(WtkjsYqwiJySrnCNlOFpvMXIxmhVeU['error_msg'].encode('utf8'))
   return
  WtkjsYqwiJySrnCNlOFpvMXIxmhVeK='user-agent={}'.format(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.USER_AGENT)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVeU['watermark'] !='':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVeK='{}&x-tving-param1={}&x-tving-param2={}'.format(WtkjsYqwiJySrnCNlOFpvMXIxmhVeK,WtkjsYqwiJySrnCNlOFpvMXIxmhVeU['watermarkKey'],WtkjsYqwiJySrnCNlOFpvMXIxmhVeU['watermark'])
  WtkjsYqwiJySrnCNlOFpvMXIxmhVeQ =WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
  WtkjsYqwiJySrnCNlOFpvMXIxmhVec =WtkjsYqwiJySrnCNlOFpvMXIxmhVeU['streaming_url'].find('Policy=')
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVec!=-1:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVeA =WtkjsYqwiJySrnCNlOFpvMXIxmhVeU['streaming_url'].split('?')[0]
   WtkjsYqwiJySrnCNlOFpvMXIxmhVeE=WtkjsYqwiJySrnCNlOFpvMXIxmhVET(urllib.parse.parse_qsl(urllib.parse.urlsplit(WtkjsYqwiJySrnCNlOFpvMXIxmhVeU['streaming_url']).query))
   WtkjsYqwiJySrnCNlOFpvMXIxmhVeg='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVeE['Policy'],WtkjsYqwiJySrnCNlOFpvMXIxmhVeE['Signature'],WtkjsYqwiJySrnCNlOFpvMXIxmhVeE['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in WtkjsYqwiJySrnCNlOFpvMXIxmhVeA:
    WtkjsYqwiJySrnCNlOFpvMXIxmhVeQ=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz
    WtkjsYqwiJySrnCNlOFpvMXIxmhVeP =WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVeo=WtkjsYqwiJySrnCNlOFpvMXIxmhVeP.strftime('%Y-%m-%d-%H:%M:%S')
    if WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(WtkjsYqwiJySrnCNlOFpvMXIxmhVeo.replace('-','').replace(':',''))<WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(WtkjsYqwiJySrnCNlOFpvMXIxmhVeE['end'].replace('-','').replace(':','')):
     WtkjsYqwiJySrnCNlOFpvMXIxmhVeE['end']=WtkjsYqwiJySrnCNlOFpvMXIxmhVeo
     WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.addon_noti(__language__(30915).encode('utf8'))
    WtkjsYqwiJySrnCNlOFpvMXIxmhVeA ='%s?%s'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVeA,urllib.parse.urlencode(WtkjsYqwiJySrnCNlOFpvMXIxmhVeE,doseq=WtkjsYqwiJySrnCNlOFpvMXIxmhVEz))
   WtkjsYqwiJySrnCNlOFpvMXIxmhVeB='{}|{}&Cookie={}'.format(WtkjsYqwiJySrnCNlOFpvMXIxmhVeA,WtkjsYqwiJySrnCNlOFpvMXIxmhVeK,WtkjsYqwiJySrnCNlOFpvMXIxmhVeg)
  else:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVeB=WtkjsYqwiJySrnCNlOFpvMXIxmhVeU['streaming_url']+'|'+WtkjsYqwiJySrnCNlOFpvMXIxmhVeK
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.addon_log('if tmp_pos == -1')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.addon_log(WtkjsYqwiJySrnCNlOFpvMXIxmhVeB)
  WtkjsYqwiJySrnCNlOFpvMXIxmhVez=xbmcgui.ListItem(path=WtkjsYqwiJySrnCNlOFpvMXIxmhVeB)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVeU['drm_license']!='':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVef=WtkjsYqwiJySrnCNlOFpvMXIxmhVeU['drm_license']
   WtkjsYqwiJySrnCNlOFpvMXIxmhVeD ='https://cj.drmkeyserver.com/widevine_license'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVeT ='mpd'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVeR ='com.widevine.alpha'
   WtkjsYqwiJySrnCNlOFpvMXIxmhVea =inputstreamhelper.Helper(WtkjsYqwiJySrnCNlOFpvMXIxmhVeT,drm='widevine')
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVea.check_inputstream():
    WtkjsYqwiJySrnCNlOFpvMXIxmhVeb={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.USER_AGENT,'AcquireLicenseAssertion':WtkjsYqwiJySrnCNlOFpvMXIxmhVef,'Host':'cj.drmkeyserver.com',}
    WtkjsYqwiJySrnCNlOFpvMXIxmhVeH=WtkjsYqwiJySrnCNlOFpvMXIxmhVeD+'|'+urllib.parse.urlencode(WtkjsYqwiJySrnCNlOFpvMXIxmhVeb)+'|R{SSM}|'
    WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setProperty('inputstream',WtkjsYqwiJySrnCNlOFpvMXIxmhVea.inputstream_addon)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setProperty('inputstream.adaptive.manifest_type',WtkjsYqwiJySrnCNlOFpvMXIxmhVeT)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setProperty('inputstream.adaptive.license_type',WtkjsYqwiJySrnCNlOFpvMXIxmhVeR)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setProperty('inputstream.adaptive.license_key',WtkjsYqwiJySrnCNlOFpvMXIxmhVeH)
    WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setProperty('inputstream.adaptive.stream_headers',WtkjsYqwiJySrnCNlOFpvMXIxmhVeK)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVeQ==WtkjsYqwiJySrnCNlOFpvMXIxmhVEz:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setContentLookup(WtkjsYqwiJySrnCNlOFpvMXIxmhVEf)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setMimeType('application/x-mpegURL')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setProperty('inputstream','inputstream.ffmpegdirect')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setProperty('ResumeTime','0')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setProperty('TotalTime','10000')
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('mode')in['VOD','MOVIE']:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setContentLookup(WtkjsYqwiJySrnCNlOFpvMXIxmhVEf)
   WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setMimeType('application/x-mpegURL')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setProperty('inputstream','inputstream.adaptive')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVez.setProperty('inputstream.adaptive.manifest_type','hls')
  xbmcplugin.setResolvedUrl(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,WtkjsYqwiJySrnCNlOFpvMXIxmhVEz,WtkjsYqwiJySrnCNlOFpvMXIxmhVez)
  try:
   if WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('mode')in['VOD','MOVIE']and WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('title'):
    WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'code':WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('programcode')if WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('mode')=='VOD' else WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('mediacode'),'img':WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('thumbnail'),'title':WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('title'),'videoid':WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('mediacode')}
    WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.Save_Watched_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('stype'),WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  except:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
 def logout(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGR=xbmcgui.Dialog()
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKc=WtkjsYqwiJySrnCNlOFpvMXIxmhVGR.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVKc==WtkjsYqwiJySrnCNlOFpvMXIxmhVEf:sys.exit()
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.Init_TV_Total()
  if os.path.isfile(WtkjsYqwiJySrnCNlOFpvMXIxmhVGP):os.remove(WtkjsYqwiJySrnCNlOFpvMXIxmhVGP)
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVed =WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.Get_Now_Datetime()
  WtkjsYqwiJySrnCNlOFpvMXIxmhVeL=WtkjsYqwiJySrnCNlOFpvMXIxmhVed+datetime.timedelta(days=WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(__addon__.getSetting('cache_ttl')))
  (WtkjsYqwiJySrnCNlOFpvMXIxmhVUu,WtkjsYqwiJySrnCNlOFpvMXIxmhVKG,WtkjsYqwiJySrnCNlOFpvMXIxmhVKU,WtkjsYqwiJySrnCNlOFpvMXIxmhVKQ)=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_settings_account()
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.Save_session_acount(WtkjsYqwiJySrnCNlOFpvMXIxmhVUu,WtkjsYqwiJySrnCNlOFpvMXIxmhVKG,WtkjsYqwiJySrnCNlOFpvMXIxmhVKU,WtkjsYqwiJySrnCNlOFpvMXIxmhVKQ)
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.TV['account']['token_limit']=WtkjsYqwiJySrnCNlOFpvMXIxmhVeL.strftime('%Y%m%d')
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.JsonFile_Save(WtkjsYqwiJySrnCNlOFpvMXIxmhVGP,WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.TV)
 def cookiefile_check(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.TV=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.JsonFile_Load(WtkjsYqwiJySrnCNlOFpvMXIxmhVGP)
  if 'account' not in WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.TV:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.Init_TV_Total()
   return WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
  (WtkjsYqwiJySrnCNlOFpvMXIxmhVeu,WtkjsYqwiJySrnCNlOFpvMXIxmhVEG,WtkjsYqwiJySrnCNlOFpvMXIxmhVEU,WtkjsYqwiJySrnCNlOFpvMXIxmhVEK)=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.get_settings_account()
  (WtkjsYqwiJySrnCNlOFpvMXIxmhVEQ,WtkjsYqwiJySrnCNlOFpvMXIxmhVEc,WtkjsYqwiJySrnCNlOFpvMXIxmhVEA,WtkjsYqwiJySrnCNlOFpvMXIxmhVEe)=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.Load_session_acount()
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVeu!=WtkjsYqwiJySrnCNlOFpvMXIxmhVEQ or WtkjsYqwiJySrnCNlOFpvMXIxmhVEG!=WtkjsYqwiJySrnCNlOFpvMXIxmhVEc or WtkjsYqwiJySrnCNlOFpvMXIxmhVEU!=WtkjsYqwiJySrnCNlOFpvMXIxmhVEA or WtkjsYqwiJySrnCNlOFpvMXIxmhVEK!=WtkjsYqwiJySrnCNlOFpvMXIxmhVEe:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.Init_TV_Total()
   return WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>WtkjsYqwiJySrnCNlOFpvMXIxmhVEB(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.TV['account']['token_limit']):
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.Init_TV_Total()
   return WtkjsYqwiJySrnCNlOFpvMXIxmhVEf
  return WtkjsYqwiJySrnCNlOFpvMXIxmhVEz
 def dp_Global_Search(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=WtkjsYqwiJySrnCNlOFpvMXIxmhVKo.get('mode')
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='TOTAL_SEARCH':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVEg='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVEg='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(WtkjsYqwiJySrnCNlOFpvMXIxmhVEg)
 def dp_Bookmark_Menu(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVEg='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(WtkjsYqwiJySrnCNlOFpvMXIxmhVEg)
 def dp_EuroLive_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB,WtkjsYqwiJySrnCNlOFpvMXIxmhVKo):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVKz=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.TvingObj.GetEuroChannelList()
  for WtkjsYqwiJySrnCNlOFpvMXIxmhVKD in WtkjsYqwiJySrnCNlOFpvMXIxmhVKz:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQg =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('channel')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUB =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('title')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQK =WtkjsYqwiJySrnCNlOFpvMXIxmhVKD.get('subtitle')
   WtkjsYqwiJySrnCNlOFpvMXIxmhVQU={'mediatype':'episode','title':WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,'plot':'%s\n%s'%(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,WtkjsYqwiJySrnCNlOFpvMXIxmhVQK)}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVUb={'mode':'LIVE','mediacode':WtkjsYqwiJySrnCNlOFpvMXIxmhVQg,'stype':'onair',}
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.add_dir(WtkjsYqwiJySrnCNlOFpvMXIxmhVUB,sublabel=WtkjsYqwiJySrnCNlOFpvMXIxmhVQK,img='',infoLabels=WtkjsYqwiJySrnCNlOFpvMXIxmhVQU,isFolder=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf,params=WtkjsYqwiJySrnCNlOFpvMXIxmhVUb)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVER(WtkjsYqwiJySrnCNlOFpvMXIxmhVKz)>0:xbmcplugin.endOfDirectory(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB._addon_handle,cacheToDisc=WtkjsYqwiJySrnCNlOFpvMXIxmhVEf)
 def tving_main(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB):
  WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params.get('mode',WtkjsYqwiJySrnCNlOFpvMXIxmhVEo)
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='LOGOUT':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.logout()
   return
  WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.login_main()
  if WtkjsYqwiJySrnCNlOFpvMXIxmhVcB is WtkjsYqwiJySrnCNlOFpvMXIxmhVEo:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_Main_List()
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_Title_Group(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB in['GLOBAL_GROUP']:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_SubTitle_Group(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='CHANNEL':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_LiveChannel_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB in['LIVE','VOD','MOVIE']:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.play_VIDEO(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='PROGRAM':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_Program_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='4K_PROGRAM':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_4K_Program_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='EPISODE':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_Episode_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='MOVIE_SUB':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_Movie_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='4K_MOVIE':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_4K_Movie_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='SEARCH_GROUP':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_Search_Group(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB in['SEARCH','LOCAL_SEARCH']:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_Search_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='WATCH':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_Watch_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_History_Remove(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='ORDER_BY':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_setEpOrderby(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='SET_BOOKMARK':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_Set_Bookmark(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB in['TOTAL_SEARCH','TOTAL_HISTORY']:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_Global_Search(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='SEARCH_HISTORY':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_Search_History(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='MENU_BOOKMARK':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_Bookmark_Menu(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  elif WtkjsYqwiJySrnCNlOFpvMXIxmhVcB=='EURO_GROUP':
   WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.dp_EuroLive_List(WtkjsYqwiJySrnCNlOFpvMXIxmhVGB.main_params)
  else:
   WtkjsYqwiJySrnCNlOFpvMXIxmhVEo
# Created by pyminifier (https://github.com/liftoff/pyminifier)
