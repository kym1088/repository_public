__author__="NightRain"
RqQNmjCyGrMufBKHWsFvdkXhgDPtOY=ImportError
RqQNmjCyGrMufBKHWsFvdkXhgDPtOa=object
RqQNmjCyGrMufBKHWsFvdkXhgDPtOc=None
RqQNmjCyGrMufBKHWsFvdkXhgDPtOV=False
RqQNmjCyGrMufBKHWsFvdkXhgDPtOp=open
RqQNmjCyGrMufBKHWsFvdkXhgDPtOw=True
RqQNmjCyGrMufBKHWsFvdkXhgDPtOo=int
RqQNmjCyGrMufBKHWsFvdkXhgDPtOS=range
RqQNmjCyGrMufBKHWsFvdkXhgDPtOx=Exception
RqQNmjCyGrMufBKHWsFvdkXhgDPtOz=print
RqQNmjCyGrMufBKHWsFvdkXhgDPtOJ=len
RqQNmjCyGrMufBKHWsFvdkXhgDPtOE=str
RqQNmjCyGrMufBKHWsFvdkXhgDPtOT=list
RqQNmjCyGrMufBKHWsFvdkXhgDPtOL=bytes
RqQNmjCyGrMufBKHWsFvdkXhgDPtln=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
try:
 from Cryptodome.PublicKey import RSA
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
except RqQNmjCyGrMufBKHWsFvdkXhgDPtOY:
 from Crypto.PublicKey import RSA
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
RqQNmjCyGrMufBKHWsFvdkXhgDPtnb={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
RqQNmjCyGrMufBKHWsFvdkXhgDPtnU ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class RqQNmjCyGrMufBKHWsFvdkXhgDPtni(RqQNmjCyGrMufBKHWsFvdkXhgDPtOa):
 def __init__(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.NETWORKCODE ='CSND0900'
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.OSCODE ='CSOD0900' 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TELECODE ='CSCD0900'
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.SCREENCODE ='CSSD0100'
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.APIKEY_ATV ='b6ac9e6384d93d6e533b144b3ef22c42' 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.SCREENCODE_ATV ='CSSD1300' 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.LIVE_LIMIT =20 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.VOD_LIMIT =24 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.EPISODE_LIMIT =30 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.SEARCH_LIMIT =30 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.MOVIE_LIMIT =24 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN ='https://api.tving.com'
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN ='https://image.tving.com'
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.SEARCH_DOMAIN ='https://search.tving.com'
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.LOGIN_DOMAIN ='https://user.tving.com'
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.URL_DOMAIN ='https://www.tving.com'
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.MOVIE_LITE =['2610061','2610161','261062']
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.DEFAULT_HEADER ={'user-agent':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.USER_AGENT}
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV_SESSION_COOKIES1=''
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV_SESSION_COOKIES2=''
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV ={}
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.Init_TV_Total()
 def Init_TV_Total(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N',},}
 def callRequestCookies(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,jobtype,RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,redirects=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnO=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.DEFAULT_HEADER
  if headers:RqQNmjCyGrMufBKHWsFvdkXhgDPtnO.update(headers)
  if jobtype=='Get':
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnl=requests.get(RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,params=params,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtnO,cookies=cookies,allow_redirects=redirects)
  else:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnl=requests.post(RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,data=payload,params=params,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtnO,cookies=cookies,allow_redirects=redirects)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtnl
 def JsonFile_Save(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,filename,RqQNmjCyGrMufBKHWsFvdkXhgDPtne):
  if filename=='':return RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
  try:
   fp=RqQNmjCyGrMufBKHWsFvdkXhgDPtOp(filename,'w',-1,'utf-8')
   json.dump(RqQNmjCyGrMufBKHWsFvdkXhgDPtne,fp,indent=4,ensure_ascii=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV)
   fp.close()
  except:
   return RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtOw
 def JsonFile_Load(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,filename):
  if filename=='':return{}
  try:
   fp=RqQNmjCyGrMufBKHWsFvdkXhgDPtOp(filename,'r',-1,'utf-8')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnY=json.load(fp)
   fp.close()
  except:
   return{}
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtnY
 def Save_session_acount(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,RqQNmjCyGrMufBKHWsFvdkXhgDPtna,RqQNmjCyGrMufBKHWsFvdkXhgDPtnc,RqQNmjCyGrMufBKHWsFvdkXhgDPtnV,RqQNmjCyGrMufBKHWsFvdkXhgDPtnp):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['account']['tvid'] =base64.standard_b64encode(RqQNmjCyGrMufBKHWsFvdkXhgDPtna.encode()).decode('utf-8')
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['account']['tvpw'] =base64.standard_b64encode(RqQNmjCyGrMufBKHWsFvdkXhgDPtnc.encode()).decode('utf-8')
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['account']['tvtype']=RqQNmjCyGrMufBKHWsFvdkXhgDPtnV 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['account']['tvpf'] =RqQNmjCyGrMufBKHWsFvdkXhgDPtnp 
 def Load_session_acount(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI):
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtna =base64.standard_b64decode(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['account']['tvid']).decode('utf-8')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnc =base64.standard_b64decode(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['account']['tvpw']).decode('utf-8')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnV=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['account']['tvtype']
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnp =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtna,RqQNmjCyGrMufBKHWsFvdkXhgDPtnc,RqQNmjCyGrMufBKHWsFvdkXhgDPtnV,RqQNmjCyGrMufBKHWsFvdkXhgDPtnp
 def makeDefaultCookies(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnw={}
  if RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_token']:RqQNmjCyGrMufBKHWsFvdkXhgDPtnw['_tving_token']=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_token']
  if RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_userinfo']:RqQNmjCyGrMufBKHWsFvdkXhgDPtnw['POC_USERINFO']=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_userinfo']
  if RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_maintoken']:RqQNmjCyGrMufBKHWsFvdkXhgDPtnw[RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GLOBAL_COOKIENM['tv_maintoken']]=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_maintoken']
  if RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_cookiekey']:RqQNmjCyGrMufBKHWsFvdkXhgDPtnw[RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GLOBAL_COOKIENM['tv_cookiekey']]=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_cookiekey']
  if RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_lockkey']:RqQNmjCyGrMufBKHWsFvdkXhgDPtnw[RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GLOBAL_COOKIENM['tv_lockkey']]=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_lockkey']
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtnw
 def getDeviceStr(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtno=[]
  RqQNmjCyGrMufBKHWsFvdkXhgDPtno.append('Windows') 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtno.append('Chrome') 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtno.append('ko-KR') 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtno.append('undefined') 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtno.append('24') 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtno.append(u'한국 표준시')
  RqQNmjCyGrMufBKHWsFvdkXhgDPtno.append('undefined') 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtno.append('undefined') 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtno.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  RqQNmjCyGrMufBKHWsFvdkXhgDPtnS=''
  for RqQNmjCyGrMufBKHWsFvdkXhgDPtnx in RqQNmjCyGrMufBKHWsFvdkXhgDPtno:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnS+=RqQNmjCyGrMufBKHWsFvdkXhgDPtnx+'|'
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtnS
 def GetDefaultParams(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,uhd=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV):
  if uhd==RqQNmjCyGrMufBKHWsFvdkXhgDPtOV:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnz={'apiKey':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.APIKEY,'networkCode':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.NETWORKCODE,'osCode':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.OSCODE,'teleCode':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TELECODE,'screenCode':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.SCREENCODE,}
  else:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnz={'apiKey':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.APIKEY_ATV,'networkCode':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.NETWORKCODE,'osCode':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.OSCODE,'teleCode':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TELECODE,'screenCode':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.SCREENCODE_ATV,}
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtnz
 def GetNoCache(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,timetype=1):
  if timetype==1:
   return RqQNmjCyGrMufBKHWsFvdkXhgDPtOo(time.time())
  else:
   return RqQNmjCyGrMufBKHWsFvdkXhgDPtOo(time.time()*1000)
 def GetUniqueid(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,hValue=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc):
  if hValue:
   import hashlib
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnJ=hashlib.sha1()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnJ.update(hValue.encode())
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnE=RqQNmjCyGrMufBKHWsFvdkXhgDPtnJ.hexdigest()[:8]
  else:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnT=[0 for i in RqQNmjCyGrMufBKHWsFvdkXhgDPtOS(256)]
   for i in RqQNmjCyGrMufBKHWsFvdkXhgDPtOS(256):
    RqQNmjCyGrMufBKHWsFvdkXhgDPtnT[i]='%02x'%(i)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnL=RqQNmjCyGrMufBKHWsFvdkXhgDPtOo(4294967295*random.random())|0
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnE=RqQNmjCyGrMufBKHWsFvdkXhgDPtnT[255&RqQNmjCyGrMufBKHWsFvdkXhgDPtnL]+RqQNmjCyGrMufBKHWsFvdkXhgDPtnT[RqQNmjCyGrMufBKHWsFvdkXhgDPtnL>>8&255]+RqQNmjCyGrMufBKHWsFvdkXhgDPtnT[RqQNmjCyGrMufBKHWsFvdkXhgDPtnL>>16&255]+RqQNmjCyGrMufBKHWsFvdkXhgDPtnT[RqQNmjCyGrMufBKHWsFvdkXhgDPtnL>>24&255]
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtnE
 def GetCredential(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,user_id,user_pw,login_type,user_pf):
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtin=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   RqQNmjCyGrMufBKHWsFvdkXhgDPtib={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Post',RqQNmjCyGrMufBKHWsFvdkXhgDPtin,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtib,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc)
   for RqQNmjCyGrMufBKHWsFvdkXhgDPtiI in RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.cookies:
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtiI.name=='_tving_token':
     RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_token']=RqQNmjCyGrMufBKHWsFvdkXhgDPtiI.value
    elif RqQNmjCyGrMufBKHWsFvdkXhgDPtiI.name=='POC_USERINFO':
     RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_userinfo']=RqQNmjCyGrMufBKHWsFvdkXhgDPtiI.value
   if not RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_token']:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.Init_TV_Total()
    return RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_maintoken']=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_token']
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetProfileToken(user_pf)==RqQNmjCyGrMufBKHWsFvdkXhgDPtOV:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.Init_TV_Total()
    return RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiO =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDeviceList()
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtiO not in['','-']:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_uuid']=RqQNmjCyGrMufBKHWsFvdkXhgDPtiO+'-'+RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetUniqueid(RqQNmjCyGrMufBKHWsFvdkXhgDPtiO)
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.Init_TV_Total()
   return RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtOw
 def GetProfileToken(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,user_pf):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtil=[]
  RqQNmjCyGrMufBKHWsFvdkXhgDPtie =''
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnw=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.makeDefaultCookies()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiA,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtnw)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtil =re.findall('data-profile-no="\d+"',RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   for i in RqQNmjCyGrMufBKHWsFvdkXhgDPtOS(RqQNmjCyGrMufBKHWsFvdkXhgDPtOJ(RqQNmjCyGrMufBKHWsFvdkXhgDPtil)):
    RqQNmjCyGrMufBKHWsFvdkXhgDPtiY =RqQNmjCyGrMufBKHWsFvdkXhgDPtil[i].replace('data-profile-no=','').replace('"','')
    RqQNmjCyGrMufBKHWsFvdkXhgDPtil[i]=RqQNmjCyGrMufBKHWsFvdkXhgDPtiY
   RqQNmjCyGrMufBKHWsFvdkXhgDPtie=RqQNmjCyGrMufBKHWsFvdkXhgDPtil[user_pf]
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.Init_TV_Total()
   return RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnw=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.makeDefaultCookies()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtib={'profileNo':RqQNmjCyGrMufBKHWsFvdkXhgDPtie}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Post',RqQNmjCyGrMufBKHWsFvdkXhgDPtiA,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtib,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtnw)
   for RqQNmjCyGrMufBKHWsFvdkXhgDPtiI in RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.cookies:
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtiI.name=='_tving_token':
     RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_token']=RqQNmjCyGrMufBKHWsFvdkXhgDPtiI.value
    elif RqQNmjCyGrMufBKHWsFvdkXhgDPtiI.name==RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GLOBAL_COOKIENM['tv_cookiekey']:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_cookiekey']=RqQNmjCyGrMufBKHWsFvdkXhgDPtiI.value
    elif RqQNmjCyGrMufBKHWsFvdkXhgDPtiI.name==RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GLOBAL_COOKIENM['tv_lockkey']:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_lockkey']=RqQNmjCyGrMufBKHWsFvdkXhgDPtiI.value
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.Init_TV_Total()
   return RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtOw
 def GetDeviceList(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtia=[]
  RqQNmjCyGrMufBKHWsFvdkXhgDPtic='-'
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='/v1/user/device/list'
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiV=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtiA
   RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnw=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.makeDefaultCookies()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiV,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtip,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtnw)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiw=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtia=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']
   for RqQNmjCyGrMufBKHWsFvdkXhgDPtio in RqQNmjCyGrMufBKHWsFvdkXhgDPtia:
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtio['model']=='PC' or RqQNmjCyGrMufBKHWsFvdkXhgDPtio['model']=='PC-Chrome':
     RqQNmjCyGrMufBKHWsFvdkXhgDPtic=RqQNmjCyGrMufBKHWsFvdkXhgDPtio['uuid']
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtic
 def Get_Now_Datetime(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,mediacode,sel_quality,stype,pvrmode='-',optUHD=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtix ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','error_msg':'',}
  RqQNmjCyGrMufBKHWsFvdkXhgDPtic =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_uuid'].split('-')[0] 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtiz =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_uuid'] 
  RqQNmjCyGrMufBKHWsFvdkXhgDPtiJ=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV 
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiE=RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetNoCache(1))
   if stype!='tvingtv':
    RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='/v2/media/stream/info' 
    RqQNmjCyGrMufBKHWsFvdkXhgDPtiT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDefaultParams()
    RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':RqQNmjCyGrMufBKHWsFvdkXhgDPtiz,'deviceInfo':'PC','noCache':RqQNmjCyGrMufBKHWsFvdkXhgDPtiE,}
    RqQNmjCyGrMufBKHWsFvdkXhgDPtiT.update(RqQNmjCyGrMufBKHWsFvdkXhgDPtip)
    RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtiA
    RqQNmjCyGrMufBKHWsFvdkXhgDPtnw=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.makeDefaultCookies()
    RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtiT,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtnw)
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.status_code!=200:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtix['error_msg']='First Step - {} error'.format(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.status_code)
     return RqQNmjCyGrMufBKHWsFvdkXhgDPtix
    RqQNmjCyGrMufBKHWsFvdkXhgDPtiw=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['result']['code']=='060':
     for RqQNmjCyGrMufBKHWsFvdkXhgDPtbn,RqQNmjCyGrMufBKHWsFvdkXhgDPtbc in RqQNmjCyGrMufBKHWsFvdkXhgDPtnb.items():
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtbc==sel_quality:
       RqQNmjCyGrMufBKHWsFvdkXhgDPtbi=RqQNmjCyGrMufBKHWsFvdkXhgDPtbn
    elif RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['result']['code']!='000':
     RqQNmjCyGrMufBKHWsFvdkXhgDPtix['error_msg']=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['result']['message']
     return RqQNmjCyGrMufBKHWsFvdkXhgDPtix
    else: 
     if not('stream' in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']):return RqQNmjCyGrMufBKHWsFvdkXhgDPtix
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbU=[]
     for RqQNmjCyGrMufBKHWsFvdkXhgDPtio in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['stream']['quality']:
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtio['active']=='Y':
       RqQNmjCyGrMufBKHWsFvdkXhgDPtbU.append({RqQNmjCyGrMufBKHWsFvdkXhgDPtnb.get(RqQNmjCyGrMufBKHWsFvdkXhgDPtio['code']):RqQNmjCyGrMufBKHWsFvdkXhgDPtio['code']})
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbi=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.CheckQuality(sel_quality,RqQNmjCyGrMufBKHWsFvdkXhgDPtbU)
     try:
      if optUHD==RqQNmjCyGrMufBKHWsFvdkXhgDPtOw and RqQNmjCyGrMufBKHWsFvdkXhgDPtbi=='stream50' and 'stream_support_info' in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['content']['info']:
       if 'stream70' in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['content']['info']['stream_support_info']:
        RqQNmjCyGrMufBKHWsFvdkXhgDPtbi='stream70'
        RqQNmjCyGrMufBKHWsFvdkXhgDPtiJ =RqQNmjCyGrMufBKHWsFvdkXhgDPtOw
     except:
      pass
   else:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbi='stream40'
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtix['error_msg']='First Step - except error'
   return RqQNmjCyGrMufBKHWsFvdkXhgDPtix
  RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(RqQNmjCyGrMufBKHWsFvdkXhgDPtbi)
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiE=RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetNoCache(1))
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='/v2a/media/stream/info'
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtiJ==RqQNmjCyGrMufBKHWsFvdkXhgDPtOw:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtiT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDefaultParams(uhd=RqQNmjCyGrMufBKHWsFvdkXhgDPtOw)
    RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'mediaCode':mediacode,'noCache':RqQNmjCyGrMufBKHWsFvdkXhgDPtiE,'streamType':'hls','streamCode':RqQNmjCyGrMufBKHWsFvdkXhgDPtbi,'deviceId':RqQNmjCyGrMufBKHWsFvdkXhgDPtic,'adReq':'none','wm':'Y','ad_device':'','uuid':RqQNmjCyGrMufBKHWsFvdkXhgDPtiz,'deviceInfo':'android_tv',}
   else:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtiT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDefaultParams()
    RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':RqQNmjCyGrMufBKHWsFvdkXhgDPtbi,'deviceId':RqQNmjCyGrMufBKHWsFvdkXhgDPtic,'uuid':RqQNmjCyGrMufBKHWsFvdkXhgDPtiz,'deviceInfo':'PC_Chrome','noCache':RqQNmjCyGrMufBKHWsFvdkXhgDPtiE,'wm':'Y'}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT.update(RqQNmjCyGrMufBKHWsFvdkXhgDPtip)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtiA
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnw=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.makeDefaultCookies()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtiT,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtnw,redirects=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiw=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.JsonFile_Save(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV_SESSION_COOKIES1,RqQNmjCyGrMufBKHWsFvdkXhgDPtiw)
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['result']['code']!='000':
    RqQNmjCyGrMufBKHWsFvdkXhgDPtix['error_msg']=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['result']['message']
    return RqQNmjCyGrMufBKHWsFvdkXhgDPtix
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbI=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['stream']
   if 'drm_license_assertion' in RqQNmjCyGrMufBKHWsFvdkXhgDPtbI:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtix['drm_license']=RqQNmjCyGrMufBKHWsFvdkXhgDPtbI['drm_license_assertion']
    if '4k_nondrm_url' in RqQNmjCyGrMufBKHWsFvdkXhgDPtbI['broadcast']and RqQNmjCyGrMufBKHWsFvdkXhgDPtiJ==RqQNmjCyGrMufBKHWsFvdkXhgDPtOw:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbO =RqQNmjCyGrMufBKHWsFvdkXhgDPtbI['broadcast']['4k_nondrm_url']
     RqQNmjCyGrMufBKHWsFvdkXhgDPtix['drm_license']=''
    else:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbO =RqQNmjCyGrMufBKHWsFvdkXhgDPtbI['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in RqQNmjCyGrMufBKHWsFvdkXhgDPtbI['broadcast']):return RqQNmjCyGrMufBKHWsFvdkXhgDPtix
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbO=RqQNmjCyGrMufBKHWsFvdkXhgDPtbI['broadcast']['broad_url']
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtix['error_msg']='Second Step - except error'
   return RqQNmjCyGrMufBKHWsFvdkXhgDPtix
  RqQNmjCyGrMufBKHWsFvdkXhgDPtbl=RqQNmjCyGrMufBKHWsFvdkXhgDPtiE
  RqQNmjCyGrMufBKHWsFvdkXhgDPtbO=RqQNmjCyGrMufBKHWsFvdkXhgDPtbO.split('|')[1]
  RqQNmjCyGrMufBKHWsFvdkXhgDPtbO,RqQNmjCyGrMufBKHWsFvdkXhgDPtbe,RqQNmjCyGrMufBKHWsFvdkXhgDPtbA=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.Decrypt_Url(RqQNmjCyGrMufBKHWsFvdkXhgDPtbO,mediacode,RqQNmjCyGrMufBKHWsFvdkXhgDPtbl)
  RqQNmjCyGrMufBKHWsFvdkXhgDPtix['streaming_url']=RqQNmjCyGrMufBKHWsFvdkXhgDPtbO
  RqQNmjCyGrMufBKHWsFvdkXhgDPtix['watermark'] =RqQNmjCyGrMufBKHWsFvdkXhgDPtbe
  RqQNmjCyGrMufBKHWsFvdkXhgDPtix['watermarkKey']=RqQNmjCyGrMufBKHWsFvdkXhgDPtbA
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtix
 def CheckQuality(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,sel_qt,RqQNmjCyGrMufBKHWsFvdkXhgDPtbU):
  for RqQNmjCyGrMufBKHWsFvdkXhgDPtbY in RqQNmjCyGrMufBKHWsFvdkXhgDPtbU:
   if sel_qt>=RqQNmjCyGrMufBKHWsFvdkXhgDPtOT(RqQNmjCyGrMufBKHWsFvdkXhgDPtbY)[0]:return RqQNmjCyGrMufBKHWsFvdkXhgDPtbY.get(RqQNmjCyGrMufBKHWsFvdkXhgDPtOT(RqQNmjCyGrMufBKHWsFvdkXhgDPtbY)[0])
   RqQNmjCyGrMufBKHWsFvdkXhgDPtba=RqQNmjCyGrMufBKHWsFvdkXhgDPtbY.get(RqQNmjCyGrMufBKHWsFvdkXhgDPtOT(RqQNmjCyGrMufBKHWsFvdkXhgDPtbY)[0])
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtba
 def makeOocUrl(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,ooc_params):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=''
  for RqQNmjCyGrMufBKHWsFvdkXhgDPtbn,RqQNmjCyGrMufBKHWsFvdkXhgDPtbc in ooc_params.items():
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiL+="%s=%s^"%(RqQNmjCyGrMufBKHWsFvdkXhgDPtbn,RqQNmjCyGrMufBKHWsFvdkXhgDPtbc)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtiL
 def GetLiveChannelList(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,stype,page_int):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtia=[]
  RqQNmjCyGrMufBKHWsFvdkXhgDPtbV=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='/v2/media/lives'
   if stype=='onair': 
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbp='CPCS0100,CPCS0400'
   else:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbp='CPCS0300'
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDefaultParams()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'cacheType':'main','pageNo':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(page_int),'pageSize':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':RqQNmjCyGrMufBKHWsFvdkXhgDPtbp,}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT.update(RqQNmjCyGrMufBKHWsFvdkXhgDPtip)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtiA
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtiT,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiw=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   if not('result' in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']):return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbw=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['result']
   for RqQNmjCyGrMufBKHWsFvdkXhgDPtio in RqQNmjCyGrMufBKHWsFvdkXhgDPtbw:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbo=RqQNmjCyGrMufBKHWsFvdkXhgDPtbz=RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ=''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbS=RqQNmjCyGrMufBKHWsFvdkXhgDPtUw=''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbx=RqQNmjCyGrMufBKHWsFvdkXhgDPtio['live_code']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbo =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['channel']['name']['ko']
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['episode']!=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbz =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['program']['name']['ko']
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbz =RqQNmjCyGrMufBKHWsFvdkXhgDPtbz+', '+RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['episode']['frequency'])+'회'
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ=RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['episode']['synopsis']['ko']
    else:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbz =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['program']['name']['ko']
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ=RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['program']['synopsis']['ko']
    try: 
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =''
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =''
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=''
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUn =''
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUi =''
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUb =''
     for RqQNmjCyGrMufBKHWsFvdkXhgDPtUI in RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['program']['image']:
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP0900':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
      elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP1800':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
      elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP2000':RqQNmjCyGrMufBKHWsFvdkXhgDPtUn =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
      elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP1900':RqQNmjCyGrMufBKHWsFvdkXhgDPtUi =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
      elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP0200':RqQNmjCyGrMufBKHWsFvdkXhgDPtUb =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
      elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP0500':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
      elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP0800':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtbE=='':
      for RqQNmjCyGrMufBKHWsFvdkXhgDPtUI in RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['channel']['image']:
       if RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIC0400':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
       elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIC1400':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
       elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIC1900':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
    except:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtOc
    try:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUO =[]
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUl=[]
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUe =[]
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUA=''
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUY=''
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUa=''
     for RqQNmjCyGrMufBKHWsFvdkXhgDPtUc in RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('schedule').get('program').get('actor'):
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtUc!='' and RqQNmjCyGrMufBKHWsFvdkXhgDPtUc!=u'없음':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUc)
     for RqQNmjCyGrMufBKHWsFvdkXhgDPtUV in RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('schedule').get('program').get('director'):
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtUV!='' and RqQNmjCyGrMufBKHWsFvdkXhgDPtUV!='-' and RqQNmjCyGrMufBKHWsFvdkXhgDPtUV!=u'없음':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUV)
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('schedule').get('program').get('category1_name').get('ko')!='':
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUe.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['program']['category1_name']['ko'])
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('schedule').get('program').get('category2_name').get('ko')!='':
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUe.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['program']['category2_name']['ko'])
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('schedule').get('program').get('product_year'):RqQNmjCyGrMufBKHWsFvdkXhgDPtUA=RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['program']['product_year']
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('schedule').get('program').get('grade_code') :RqQNmjCyGrMufBKHWsFvdkXhgDPtUY= RqQNmjCyGrMufBKHWsFvdkXhgDPtnU.get(RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['program']['grade_code'])
     if 'broad_dt' in RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('schedule').get('program'):
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUp =RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('schedule').get('program').get('broad_dt')
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUa='%s-%s-%s'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[:4],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[4:6],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[6:])
    except:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtOc
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbS=RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['broadcast_start_time'])[8:12]
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUw =RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtio['schedule']['broadcast_end_time'])[8:12]
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUo={'channel':RqQNmjCyGrMufBKHWsFvdkXhgDPtbo,'title':RqQNmjCyGrMufBKHWsFvdkXhgDPtbz,'mediacode':RqQNmjCyGrMufBKHWsFvdkXhgDPtbx,'thumbnail':{'poster':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT,'thumb':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE,'clearlogo':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL,'icon':RqQNmjCyGrMufBKHWsFvdkXhgDPtUn,'fanart':RqQNmjCyGrMufBKHWsFvdkXhgDPtUb},'synopsis':RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ,'channelepg':' [%s:%s ~ %s:%s]'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtbS[0:2],RqQNmjCyGrMufBKHWsFvdkXhgDPtbS[2:],RqQNmjCyGrMufBKHWsFvdkXhgDPtUw[0:2],RqQNmjCyGrMufBKHWsFvdkXhgDPtUw[2:]),'cast':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO,'director':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl,'info_genre':RqQNmjCyGrMufBKHWsFvdkXhgDPtUe,'year':RqQNmjCyGrMufBKHWsFvdkXhgDPtUA,'mpaa':RqQNmjCyGrMufBKHWsFvdkXhgDPtUY,'premiered':RqQNmjCyGrMufBKHWsFvdkXhgDPtUa}
    RqQNmjCyGrMufBKHWsFvdkXhgDPtia.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUo)
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['has_more']=='Y':
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbV=RqQNmjCyGrMufBKHWsFvdkXhgDPtOw
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
 def GetProgramList(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,genre,orderby,page_int,genreCode='all'):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtia=[]
  RqQNmjCyGrMufBKHWsFvdkXhgDPtbV=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='/v2/media/episodes'
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDefaultParams()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'cacheType':'main','pageSize':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(page_int),}
   if genre !='all':RqQNmjCyGrMufBKHWsFvdkXhgDPtip['categoryCode']=genre
   if genreCode!='all':RqQNmjCyGrMufBKHWsFvdkXhgDPtip['genreCode'] =genreCode 
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT.update(RqQNmjCyGrMufBKHWsFvdkXhgDPtip)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtiA
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtiT,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiw=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   if not('result' in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']):return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbw=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['result']
   for RqQNmjCyGrMufBKHWsFvdkXhgDPtio in RqQNmjCyGrMufBKHWsFvdkXhgDPtbw:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUS=RqQNmjCyGrMufBKHWsFvdkXhgDPtio['program']['code']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbz =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['program']['name']['ko']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUY =RqQNmjCyGrMufBKHWsFvdkXhgDPtnU.get(RqQNmjCyGrMufBKHWsFvdkXhgDPtio['program'].get('grade_code'))
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUn =''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUi =''
    for RqQNmjCyGrMufBKHWsFvdkXhgDPtUI in RqQNmjCyGrMufBKHWsFvdkXhgDPtio['program']['image']:
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP0900':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP0200':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP1800':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP2000':RqQNmjCyGrMufBKHWsFvdkXhgDPtUn =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP1900':RqQNmjCyGrMufBKHWsFvdkXhgDPtUi =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['program']['synopsis']['ko']
    try:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUx=RqQNmjCyGrMufBKHWsFvdkXhgDPtio['channel']['name']['ko']
    except:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUx=''
    try:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUO =[]
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUl=[]
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUe =[]
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUA =''
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUa=''
     for RqQNmjCyGrMufBKHWsFvdkXhgDPtUc in RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('program').get('actor'):
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtUc!='' and RqQNmjCyGrMufBKHWsFvdkXhgDPtUc!='-' and RqQNmjCyGrMufBKHWsFvdkXhgDPtUc!=u'없음':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUc)
     for RqQNmjCyGrMufBKHWsFvdkXhgDPtUV in RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('program').get('director'):
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtUV!='' and RqQNmjCyGrMufBKHWsFvdkXhgDPtUV!='-' and RqQNmjCyGrMufBKHWsFvdkXhgDPtUV!=u'없음':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUV)
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('program').get('category1_name').get('ko')!='':
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUe.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtio['program']['category1_name']['ko'])
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('program').get('category2_name').get('ko')!='':
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUe.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtio['program']['category2_name']['ko'])
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('program').get('product_year'):RqQNmjCyGrMufBKHWsFvdkXhgDPtUA=RqQNmjCyGrMufBKHWsFvdkXhgDPtio['program']['product_year']
     if 'broad_dt' in RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('program'):
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUp =RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('program').get('broad_dt')
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUa='%s-%s-%s'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[:4],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[4:6],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[6:])
    except:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtOc
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUo={'program':RqQNmjCyGrMufBKHWsFvdkXhgDPtUS,'title':RqQNmjCyGrMufBKHWsFvdkXhgDPtbz,'thumbnail':{'poster':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT,'thumb':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE,'clearlogo':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL,'icon':RqQNmjCyGrMufBKHWsFvdkXhgDPtUn,'banner':RqQNmjCyGrMufBKHWsFvdkXhgDPtUi,'fanart':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE},'synopsis':RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ,'channel':RqQNmjCyGrMufBKHWsFvdkXhgDPtUx,'cast':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO,'director':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl,'info_genre':RqQNmjCyGrMufBKHWsFvdkXhgDPtUe,'year':RqQNmjCyGrMufBKHWsFvdkXhgDPtUA,'premiered':RqQNmjCyGrMufBKHWsFvdkXhgDPtUa,'mpaa':RqQNmjCyGrMufBKHWsFvdkXhgDPtUY}
    RqQNmjCyGrMufBKHWsFvdkXhgDPtia.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUo)
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['has_more']=='Y':RqQNmjCyGrMufBKHWsFvdkXhgDPtbV=RqQNmjCyGrMufBKHWsFvdkXhgDPtOw
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
 def Get_UHD_ProgramList(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,page_int):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtia=[]
  RqQNmjCyGrMufBKHWsFvdkXhgDPtbV=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='/v2/operator/highlights'
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDefaultParams(uhd=RqQNmjCyGrMufBKHWsFvdkXhgDPtOw)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(page_int),'pocType':'APP_X_TVING_4.0.0',}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT.update(RqQNmjCyGrMufBKHWsFvdkXhgDPtip)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtiA
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtiT,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiw=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   if not('result' in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']):return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbw=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['result']
   for RqQNmjCyGrMufBKHWsFvdkXhgDPtio in RqQNmjCyGrMufBKHWsFvdkXhgDPtbw:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUz=RqQNmjCyGrMufBKHWsFvdkXhgDPtio['content']['program']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUJ =RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['code']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbz =RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['name']['ko'].strip()
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUY =RqQNmjCyGrMufBKHWsFvdkXhgDPtnU.get(RqQNmjCyGrMufBKHWsFvdkXhgDPtUz.get('grade_code'))
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ =RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['synopsis']['ko']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUx =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['content']['channel']['name']['ko']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUA =RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['product_year']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUn =''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUi =''
    for RqQNmjCyGrMufBKHWsFvdkXhgDPtUI in RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['image']:
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP0900':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP0200':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP1800':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP2000':RqQNmjCyGrMufBKHWsFvdkXhgDPtUn =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP1900':RqQNmjCyGrMufBKHWsFvdkXhgDPtUi =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUe =[]
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUO =[]
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUl=[]
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUa =''
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtUz.get('category1_name').get('ko')!='':
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUe.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['category1_name']['ko'])
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtUz.get('category2_name').get('ko')!='':
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUe.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['category2_name']['ko'])
    for RqQNmjCyGrMufBKHWsFvdkXhgDPtUc in RqQNmjCyGrMufBKHWsFvdkXhgDPtUz.get('actor'):
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtUc!='' and RqQNmjCyGrMufBKHWsFvdkXhgDPtUc!='-' and RqQNmjCyGrMufBKHWsFvdkXhgDPtUc!=u'없음':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUc)
    for RqQNmjCyGrMufBKHWsFvdkXhgDPtUV in RqQNmjCyGrMufBKHWsFvdkXhgDPtUz.get('director'):
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtUV!='' and RqQNmjCyGrMufBKHWsFvdkXhgDPtUV!='-' and RqQNmjCyGrMufBKHWsFvdkXhgDPtUV!=u'없음':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUV)
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtUz.get('broad_dt')not in[RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,'']:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUp =RqQNmjCyGrMufBKHWsFvdkXhgDPtUz.get('broad_dt')
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUa='%s-%s-%s'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[:4],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[4:6],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[6:])
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUo={'program':RqQNmjCyGrMufBKHWsFvdkXhgDPtUJ,'title':RqQNmjCyGrMufBKHWsFvdkXhgDPtbz,'mpaa':RqQNmjCyGrMufBKHWsFvdkXhgDPtUY,'thumbnail':{'poster':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT,'thumb':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE,'clearlogo':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL,'icon':RqQNmjCyGrMufBKHWsFvdkXhgDPtUn,'banner':RqQNmjCyGrMufBKHWsFvdkXhgDPtUi,'fanart':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE},'channel':RqQNmjCyGrMufBKHWsFvdkXhgDPtUx,'synopsis':RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ,'year':RqQNmjCyGrMufBKHWsFvdkXhgDPtUA,'info_genre':RqQNmjCyGrMufBKHWsFvdkXhgDPtUe,'cast':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO,'director':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl,'premiered':RqQNmjCyGrMufBKHWsFvdkXhgDPtUa,}
    RqQNmjCyGrMufBKHWsFvdkXhgDPtia.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUo)
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
 def GetEpisodeList(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,program_code,page_int,orderby='desc'):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtia=[]
  RqQNmjCyGrMufBKHWsFvdkXhgDPtbV=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='/v2/media/frequency/program/'+program_code
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDefaultParams()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT.update(RqQNmjCyGrMufBKHWsFvdkXhgDPtip)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtiA
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtiT,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiw=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   if not('result' in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']):return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbw=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['result']
   RqQNmjCyGrMufBKHWsFvdkXhgDPtUE=RqQNmjCyGrMufBKHWsFvdkXhgDPtOo(RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['total_count'])
   RqQNmjCyGrMufBKHWsFvdkXhgDPtUT =RqQNmjCyGrMufBKHWsFvdkXhgDPtOo(RqQNmjCyGrMufBKHWsFvdkXhgDPtUE//(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUL =(RqQNmjCyGrMufBKHWsFvdkXhgDPtUE-1)-((page_int-1)*RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.EPISODE_LIMIT)
   else:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUL =(page_int-1)*RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.EPISODE_LIMIT
   for i in RqQNmjCyGrMufBKHWsFvdkXhgDPtOS(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.EPISODE_LIMIT):
    if orderby=='desc':
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIn=RqQNmjCyGrMufBKHWsFvdkXhgDPtUL-i
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtIn<0:break
    else:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIn=RqQNmjCyGrMufBKHWsFvdkXhgDPtUL+i
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtIn>=RqQNmjCyGrMufBKHWsFvdkXhgDPtUE:break
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIi=RqQNmjCyGrMufBKHWsFvdkXhgDPtbw[RqQNmjCyGrMufBKHWsFvdkXhgDPtIn]['episode']['code']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbz =RqQNmjCyGrMufBKHWsFvdkXhgDPtbw[RqQNmjCyGrMufBKHWsFvdkXhgDPtIn]['vod_name']['ko']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIb =''
    try:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUp=RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtbw[RqQNmjCyGrMufBKHWsFvdkXhgDPtIn]['episode']['broadcast_date'])
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIb='%s-%s-%s'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[:4],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[4:6],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[6:])
    except:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtOc
    try:
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtbw[RqQNmjCyGrMufBKHWsFvdkXhgDPtIn]['episode']['pip_cliptype']=='C012':
      RqQNmjCyGrMufBKHWsFvdkXhgDPtIb+=' - Quick VOD'
    except:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtOc
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ =RqQNmjCyGrMufBKHWsFvdkXhgDPtbw[RqQNmjCyGrMufBKHWsFvdkXhgDPtIn]['episode']['synopsis']['ko']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUn =''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUi =''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUb =''
    for RqQNmjCyGrMufBKHWsFvdkXhgDPtUI in RqQNmjCyGrMufBKHWsFvdkXhgDPtbw[RqQNmjCyGrMufBKHWsFvdkXhgDPtIn]['program']['image']:
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP0900':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP1800':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP2000':RqQNmjCyGrMufBKHWsFvdkXhgDPtUn =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP1900':RqQNmjCyGrMufBKHWsFvdkXhgDPtUi =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIP0200':RqQNmjCyGrMufBKHWsFvdkXhgDPtUb =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
    for RqQNmjCyGrMufBKHWsFvdkXhgDPtUI in RqQNmjCyGrMufBKHWsFvdkXhgDPtbw[RqQNmjCyGrMufBKHWsFvdkXhgDPtIn]['episode']['image']:
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIE0400':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
    try:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIU=RqQNmjCyGrMufBKHWsFvdkXhgDPtIl=RqQNmjCyGrMufBKHWsFvdkXhgDPtIe=''
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIO=0
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIU =RqQNmjCyGrMufBKHWsFvdkXhgDPtbw[RqQNmjCyGrMufBKHWsFvdkXhgDPtIn]['program']['name']['ko']
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIl =RqQNmjCyGrMufBKHWsFvdkXhgDPtIb
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIe =RqQNmjCyGrMufBKHWsFvdkXhgDPtbw[RqQNmjCyGrMufBKHWsFvdkXhgDPtIn]['channel']['name']['ko']
     if 'frequency' in RqQNmjCyGrMufBKHWsFvdkXhgDPtbw[RqQNmjCyGrMufBKHWsFvdkXhgDPtIn]['episode']:RqQNmjCyGrMufBKHWsFvdkXhgDPtIO=RqQNmjCyGrMufBKHWsFvdkXhgDPtbw[RqQNmjCyGrMufBKHWsFvdkXhgDPtIn]['episode']['frequency']
    except:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtOc
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUo={'episode':RqQNmjCyGrMufBKHWsFvdkXhgDPtIi,'title':RqQNmjCyGrMufBKHWsFvdkXhgDPtbz,'subtitle':RqQNmjCyGrMufBKHWsFvdkXhgDPtIb,'thumbnail':{'poster':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT,'thumb':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE,'clearlogo':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL,'icon':RqQNmjCyGrMufBKHWsFvdkXhgDPtUn,'banner':RqQNmjCyGrMufBKHWsFvdkXhgDPtUi,'fanart':RqQNmjCyGrMufBKHWsFvdkXhgDPtUb},'synopsis':RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ,'info_title':RqQNmjCyGrMufBKHWsFvdkXhgDPtIU,'aired':RqQNmjCyGrMufBKHWsFvdkXhgDPtIl,'studio':RqQNmjCyGrMufBKHWsFvdkXhgDPtIe,'frequency':RqQNmjCyGrMufBKHWsFvdkXhgDPtIO}
    RqQNmjCyGrMufBKHWsFvdkXhgDPtia.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUo)
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtUT>page_int:RqQNmjCyGrMufBKHWsFvdkXhgDPtbV=RqQNmjCyGrMufBKHWsFvdkXhgDPtOw
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV,RqQNmjCyGrMufBKHWsFvdkXhgDPtUT
 def GetMovieList(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,genre,orderby,page_int):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtia=[]
  RqQNmjCyGrMufBKHWsFvdkXhgDPtbV=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='/v2/media/movies'
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDefaultParams()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'pageSize':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N','pageNo':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(page_int),}
   if genre!='all' :RqQNmjCyGrMufBKHWsFvdkXhgDPtip['categoryCode']=genre
   RqQNmjCyGrMufBKHWsFvdkXhgDPtip['productPackageCode']=','.join(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.MOVIE_LITE)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT.update(RqQNmjCyGrMufBKHWsFvdkXhgDPtip)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtiA
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtiT,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiw=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   if not('result' in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']):return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbw=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['result']
   for RqQNmjCyGrMufBKHWsFvdkXhgDPtio in RqQNmjCyGrMufBKHWsFvdkXhgDPtbw:
    if 'release_date' in RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('movie'):
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUA=RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('movie').get('release_date'))[:4]
    else:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUA=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIA =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['movie']['code']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbz =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['movie']['name']['ko'].strip()
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtUA not in[RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,'0','']:RqQNmjCyGrMufBKHWsFvdkXhgDPtbz+=u' (%s)'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtUA)
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbT=''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=''
    for RqQNmjCyGrMufBKHWsFvdkXhgDPtUI in RqQNmjCyGrMufBKHWsFvdkXhgDPtio['movie']['image']:
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIM2100':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIM0400':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIM1800':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['movie']['story']['ko']
    try:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIU =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['movie']['name']['ko'].strip()
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUY =RqQNmjCyGrMufBKHWsFvdkXhgDPtnU.get(RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('grade_code'))
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUO=[]
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUl=[]
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUe=[]
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIY=0
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUa=''
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIe =''
     for RqQNmjCyGrMufBKHWsFvdkXhgDPtUc in RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('movie').get('actor'):
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtUc!='':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUc)
     for RqQNmjCyGrMufBKHWsFvdkXhgDPtUV in RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('movie').get('director'):
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtUV!='':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUV)
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('movie').get('category1_name').get('ko')!='':
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUe.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtio['movie']['category1_name']['ko'])
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('movie').get('category2_name').get('ko')!='':
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUe.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtio['movie']['category2_name']['ko'])
     if 'duration' in RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('movie'):RqQNmjCyGrMufBKHWsFvdkXhgDPtIY=RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('movie').get('duration')
     if 'release_date' in RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('movie'):
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUp=RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('movie').get('release_date'))
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtUp!='0':RqQNmjCyGrMufBKHWsFvdkXhgDPtUa='%s-%s-%s'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[:4],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[4:6],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[6:])
     if 'production' in RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('movie'):RqQNmjCyGrMufBKHWsFvdkXhgDPtIe=RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('movie').get('production')
    except:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtOc
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUo={'moviecode':RqQNmjCyGrMufBKHWsFvdkXhgDPtIA,'title':RqQNmjCyGrMufBKHWsFvdkXhgDPtbz,'thumbnail':{'poster':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT,'thumb':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE,'clearlogo':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL,'fanart':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE},'synopsis':RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ,'info_title':RqQNmjCyGrMufBKHWsFvdkXhgDPtIU,'year':RqQNmjCyGrMufBKHWsFvdkXhgDPtUA,'cast':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO,'director':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl,'info_genre':RqQNmjCyGrMufBKHWsFvdkXhgDPtUe,'duration':RqQNmjCyGrMufBKHWsFvdkXhgDPtIY,'premiered':RqQNmjCyGrMufBKHWsFvdkXhgDPtUa,'studio':RqQNmjCyGrMufBKHWsFvdkXhgDPtIe,'mpaa':RqQNmjCyGrMufBKHWsFvdkXhgDPtUY}
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIa=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
    for RqQNmjCyGrMufBKHWsFvdkXhgDPtIc in RqQNmjCyGrMufBKHWsFvdkXhgDPtio['billing_package_id']:
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtIc in RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.MOVIE_LITE:
      RqQNmjCyGrMufBKHWsFvdkXhgDPtIa=RqQNmjCyGrMufBKHWsFvdkXhgDPtOw
      break
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtIa==RqQNmjCyGrMufBKHWsFvdkXhgDPtOV: 
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUo['title']=RqQNmjCyGrMufBKHWsFvdkXhgDPtUo['title']+' [개별구매]'
    RqQNmjCyGrMufBKHWsFvdkXhgDPtia.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUo)
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['has_more']=='Y':RqQNmjCyGrMufBKHWsFvdkXhgDPtbV=RqQNmjCyGrMufBKHWsFvdkXhgDPtOw
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
 def Get_UHD_MovieList(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,page_int):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtia=[]
  RqQNmjCyGrMufBKHWsFvdkXhgDPtbV=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='/v2/operator/highlights'
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDefaultParams(uhd=RqQNmjCyGrMufBKHWsFvdkXhgDPtOw)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(page_int),'pocType':'APP_X_TVING_4.0.0',}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT.update(RqQNmjCyGrMufBKHWsFvdkXhgDPtip)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtiA
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtiT,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiw=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   if not('result' in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']):return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbw=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['result']
   for RqQNmjCyGrMufBKHWsFvdkXhgDPtio in RqQNmjCyGrMufBKHWsFvdkXhgDPtbw:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUz=RqQNmjCyGrMufBKHWsFvdkXhgDPtio['content']['movie']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUJ =RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['code']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbz =RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['name']['ko'].strip()
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIU =RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['name']['ko'].strip()
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUA =RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['product_year']
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtUA:RqQNmjCyGrMufBKHWsFvdkXhgDPtbz+=u' (%s)'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['product_year'])
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ =RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['story']['ko']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIY =RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['duration']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUY =RqQNmjCyGrMufBKHWsFvdkXhgDPtnU.get(RqQNmjCyGrMufBKHWsFvdkXhgDPtUz.get('grade_code'))
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIe =RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['production']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbT=''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=''
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUe =[]
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUO =[]
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUl=[]
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUa =''
    for RqQNmjCyGrMufBKHWsFvdkXhgDPtUI in RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['image']:
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIM2100':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIM0400':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
     elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['code']=='CAIM1800':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI['url']
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['release_date']not in[RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,0]:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUp=RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['release_date'])
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtUp!='0':RqQNmjCyGrMufBKHWsFvdkXhgDPtUa='%s-%s-%s'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[:4],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[4:6],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[6:])
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtUz.get('category1_name').get('ko')!='':
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUe.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['category1_name']['ko'])
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtUz.get('category2_name').get('ko')!='':
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUe.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUz['category2_name']['ko'])
    for RqQNmjCyGrMufBKHWsFvdkXhgDPtUc in RqQNmjCyGrMufBKHWsFvdkXhgDPtUz.get('actor'):
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtUc!='':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUc)
    for RqQNmjCyGrMufBKHWsFvdkXhgDPtUV in RqQNmjCyGrMufBKHWsFvdkXhgDPtUz.get('director'):
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtUV!='':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUV)
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUo={'moviecode':RqQNmjCyGrMufBKHWsFvdkXhgDPtUJ,'title':RqQNmjCyGrMufBKHWsFvdkXhgDPtbz,'thumbnail':{'poster':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT,'thumb':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE,'clearlogo':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL,'fanart':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE},'year':RqQNmjCyGrMufBKHWsFvdkXhgDPtUA,'info_title':RqQNmjCyGrMufBKHWsFvdkXhgDPtIU,'synopsis':RqQNmjCyGrMufBKHWsFvdkXhgDPtbJ,'mpaa':RqQNmjCyGrMufBKHWsFvdkXhgDPtUY,'duration':RqQNmjCyGrMufBKHWsFvdkXhgDPtIY,'premiered':RqQNmjCyGrMufBKHWsFvdkXhgDPtUa,'studio':RqQNmjCyGrMufBKHWsFvdkXhgDPtIe,'info_genre':RqQNmjCyGrMufBKHWsFvdkXhgDPtUe,'cast':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO,'director':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl,}
    RqQNmjCyGrMufBKHWsFvdkXhgDPtia.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUo)
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
 def GetMovieGenre(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtia=[]
  RqQNmjCyGrMufBKHWsFvdkXhgDPtbV=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='/v2/media/movie/curations'
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDefaultParams()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT.update(RqQNmjCyGrMufBKHWsFvdkXhgDPtip)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtiA
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtiT,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiw=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   if not('result' in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']):return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbw=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['result']
   for RqQNmjCyGrMufBKHWsFvdkXhgDPtio in RqQNmjCyGrMufBKHWsFvdkXhgDPtbw:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIV =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['curation_code']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIp =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['curation_name']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtUo={'curation_code':RqQNmjCyGrMufBKHWsFvdkXhgDPtIV,'curation_name':RqQNmjCyGrMufBKHWsFvdkXhgDPtIp}
    RqQNmjCyGrMufBKHWsFvdkXhgDPtia.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUo)
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
 def GetSearchList(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,search_key,page_int,stype):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtIw=[]
  RqQNmjCyGrMufBKHWsFvdkXhgDPtbV=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='/search/getSearch.jsp'
   RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(page_int),'pageSize':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.SCREENCODE,'os':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.OSCODE,'network':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.SEARCH_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtiA
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtip,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiw=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   if stype=='vod':
    if not('programRsb' in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw):return RqQNmjCyGrMufBKHWsFvdkXhgDPtIw,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIo=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['programRsb']['dataList']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIS =RqQNmjCyGrMufBKHWsFvdkXhgDPtOo(RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['programRsb']['count'])
    for RqQNmjCyGrMufBKHWsFvdkXhgDPtio in RqQNmjCyGrMufBKHWsFvdkXhgDPtIo:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUS=RqQNmjCyGrMufBKHWsFvdkXhgDPtio['mast_cd']
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbz =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['mast_nm']
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtio['web_url4']
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtio['web_url']
     try:
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUO =[]
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUl=[]
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUe =[]
      RqQNmjCyGrMufBKHWsFvdkXhgDPtIY =0
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUY =''
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUA =''
      RqQNmjCyGrMufBKHWsFvdkXhgDPtIl =''
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('actor') !='' and RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('actor') !='-':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO =RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('actor').split(',')
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('director')!='' and RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('director')!='-':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl=RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('director').split(',')
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('cate_nm')!='' and RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('cate_nm')!='-':RqQNmjCyGrMufBKHWsFvdkXhgDPtUe =RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('cate_nm').split('/')
      if 'targetage' in RqQNmjCyGrMufBKHWsFvdkXhgDPtio:RqQNmjCyGrMufBKHWsFvdkXhgDPtUY=RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('targetage')
      if 'broad_dt' in RqQNmjCyGrMufBKHWsFvdkXhgDPtio:
       RqQNmjCyGrMufBKHWsFvdkXhgDPtUp=RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('broad_dt')
       RqQNmjCyGrMufBKHWsFvdkXhgDPtIl='%s-%s-%s'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[:4],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[4:6],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[6:])
       RqQNmjCyGrMufBKHWsFvdkXhgDPtUA =RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[:4]
     except:
      RqQNmjCyGrMufBKHWsFvdkXhgDPtOc
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUo={'program':RqQNmjCyGrMufBKHWsFvdkXhgDPtUS,'title':RqQNmjCyGrMufBKHWsFvdkXhgDPtbz,'thumbnail':{'poster':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT,'thumb':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE,'fanart':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE},'synopsis':'','cast':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO,'director':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl,'info_genre':RqQNmjCyGrMufBKHWsFvdkXhgDPtUe,'duration':RqQNmjCyGrMufBKHWsFvdkXhgDPtIY,'mpaa':RqQNmjCyGrMufBKHWsFvdkXhgDPtUY,'year':RqQNmjCyGrMufBKHWsFvdkXhgDPtUA,'aired':RqQNmjCyGrMufBKHWsFvdkXhgDPtIl}
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIw.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUo)
   else:
    if not('vodMVRsb' in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw):return RqQNmjCyGrMufBKHWsFvdkXhgDPtIw,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIx=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['vodMVRsb']['dataList']
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIS =RqQNmjCyGrMufBKHWsFvdkXhgDPtOo(RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['vodMVRsb']['count'])
    for RqQNmjCyGrMufBKHWsFvdkXhgDPtio in RqQNmjCyGrMufBKHWsFvdkXhgDPtIx:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUS=RqQNmjCyGrMufBKHWsFvdkXhgDPtio['mast_cd']
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbz =RqQNmjCyGrMufBKHWsFvdkXhgDPtio['mast_nm'].strip()
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtio['web_url']
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtbT
     RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=''
     try:
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUO =[]
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUl=[]
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUe =[]
      RqQNmjCyGrMufBKHWsFvdkXhgDPtIY =0
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUY =''
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUA =''
      RqQNmjCyGrMufBKHWsFvdkXhgDPtIl =''
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('actor') !='' and RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('actor') !='-':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO =RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('actor').split(',')
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('director')!='' and RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('director')!='-':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl=RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('director').split(',')
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('cate_nm')!='' and RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('cate_nm')!='-':RqQNmjCyGrMufBKHWsFvdkXhgDPtUe =RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('cate_nm').split('/')
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('runtime_sec')!='':RqQNmjCyGrMufBKHWsFvdkXhgDPtIY=RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('runtime_sec')
      if 'grade_nm' in RqQNmjCyGrMufBKHWsFvdkXhgDPtio:RqQNmjCyGrMufBKHWsFvdkXhgDPtUY=RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('grade_nm')
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUp=RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('broad_dt')
      if data_str!='':
       RqQNmjCyGrMufBKHWsFvdkXhgDPtIl='%s-%s-%s'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[:4],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[4:6],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[6:])
       RqQNmjCyGrMufBKHWsFvdkXhgDPtUA =RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[:4]
     except:
      RqQNmjCyGrMufBKHWsFvdkXhgDPtOc
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUo={'movie':RqQNmjCyGrMufBKHWsFvdkXhgDPtUS,'title':RqQNmjCyGrMufBKHWsFvdkXhgDPtbz,'thumbnail':{'poster':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT,'thumb':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE,'fanart':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE,'clearlogo':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL},'synopsis':'','cast':RqQNmjCyGrMufBKHWsFvdkXhgDPtUO,'director':RqQNmjCyGrMufBKHWsFvdkXhgDPtUl,'info_genre':RqQNmjCyGrMufBKHWsFvdkXhgDPtUe,'duration':RqQNmjCyGrMufBKHWsFvdkXhgDPtIY,'mpaa':RqQNmjCyGrMufBKHWsFvdkXhgDPtUY,'year':RqQNmjCyGrMufBKHWsFvdkXhgDPtUA,'aired':RqQNmjCyGrMufBKHWsFvdkXhgDPtIl}
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIa=RqQNmjCyGrMufBKHWsFvdkXhgDPtOV
     for RqQNmjCyGrMufBKHWsFvdkXhgDPtIc in RqQNmjCyGrMufBKHWsFvdkXhgDPtio['bill']:
      if RqQNmjCyGrMufBKHWsFvdkXhgDPtIc in RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.MOVIE_LITE:
       RqQNmjCyGrMufBKHWsFvdkXhgDPtIa=RqQNmjCyGrMufBKHWsFvdkXhgDPtOw
       break
     if RqQNmjCyGrMufBKHWsFvdkXhgDPtIa==RqQNmjCyGrMufBKHWsFvdkXhgDPtOV: 
      RqQNmjCyGrMufBKHWsFvdkXhgDPtUo['title']=RqQNmjCyGrMufBKHWsFvdkXhgDPtUo['title']+' [개별구매]'
     RqQNmjCyGrMufBKHWsFvdkXhgDPtIw.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUo)
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtIS>(page_int*RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.SEARCH_LIMIT):RqQNmjCyGrMufBKHWsFvdkXhgDPtbV=RqQNmjCyGrMufBKHWsFvdkXhgDPtOw
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtIw,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
 def GetBookmarkInfo(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,videoid,vidtype):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtIz={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN+'/v2/media/program/'+videoid
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDefaultParams()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'pageNo':'1','pageSize':'10','order':'name',}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT.update(RqQNmjCyGrMufBKHWsFvdkXhgDPtip)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtiT,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIJ=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   if not('body' in RqQNmjCyGrMufBKHWsFvdkXhgDPtIJ):return{}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIE=RqQNmjCyGrMufBKHWsFvdkXhgDPtIJ['body']
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbz=RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('name').get('ko').strip()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['title'] =RqQNmjCyGrMufBKHWsFvdkXhgDPtbz
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['title']=RqQNmjCyGrMufBKHWsFvdkXhgDPtbz
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['mpaa'] =RqQNmjCyGrMufBKHWsFvdkXhgDPtnU.get(RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('grade_code'))
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['plot'] =RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('synopsis').get('ko')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['year'] =RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('product_year')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['cast'] =RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('actor')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['director']=RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('director')
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('category1_name').get('ko')!='':
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['genre'].append(RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('category1_name').get('ko'))
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('category2_name').get('ko')!='':
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['genre'].append(RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('category2_name').get('ko'))
   RqQNmjCyGrMufBKHWsFvdkXhgDPtUp=RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('broad_dt'))
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtUp!='0':RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[:4],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[4:6],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[6:])
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =''
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =''
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=''
   RqQNmjCyGrMufBKHWsFvdkXhgDPtUn =''
   RqQNmjCyGrMufBKHWsFvdkXhgDPtUi =''
   for RqQNmjCyGrMufBKHWsFvdkXhgDPtUI in RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('image'):
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('code')=='CAIP0900':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('url')
    elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('code')=='CAIP0200':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('url')
    elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('code')=='CAIP1800':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('url')
    elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('code')=='CAIP2000':RqQNmjCyGrMufBKHWsFvdkXhgDPtUn =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('url')
    elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('code')=='CAIP1900':RqQNmjCyGrMufBKHWsFvdkXhgDPtUi =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('url')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['thumbnail']['poster']=RqQNmjCyGrMufBKHWsFvdkXhgDPtbT
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['thumbnail']['thumb']=RqQNmjCyGrMufBKHWsFvdkXhgDPtbE
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['thumbnail']['clearlogo']=RqQNmjCyGrMufBKHWsFvdkXhgDPtbL
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['thumbnail']['icon']=RqQNmjCyGrMufBKHWsFvdkXhgDPtUn
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['thumbnail']['banner']=RqQNmjCyGrMufBKHWsFvdkXhgDPtUi
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['thumbnail']['fanart']=RqQNmjCyGrMufBKHWsFvdkXhgDPtbE
  else:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN+'/v2a/media/stream/info'
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDefaultParams()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_uuid'].split('-')[0],'uuid':RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetNoCache(1)),'wm':'Y',}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT.update(RqQNmjCyGrMufBKHWsFvdkXhgDPtip)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtiT,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIJ=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   if not('content' in RqQNmjCyGrMufBKHWsFvdkXhgDPtIJ['body']):return{}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIE=RqQNmjCyGrMufBKHWsFvdkXhgDPtIJ['body']['content']['info']['movie']
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbz =RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('name').get('ko').strip()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['title']=RqQNmjCyGrMufBKHWsFvdkXhgDPtbz
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbz +=u' (%s)'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('product_year'))
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['title'] =RqQNmjCyGrMufBKHWsFvdkXhgDPtbz
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['mpaa'] =RqQNmjCyGrMufBKHWsFvdkXhgDPtnU.get(RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('grade_code'))
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['plot'] =RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('story').get('ko')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['year'] =RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('product_year')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['studio'] =RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('production')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['duration']=RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('duration')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['cast'] =RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('actor')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['director']=RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('director')
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('category1_name').get('ko')!='':
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['genre'].append(RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('category1_name').get('ko'))
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('category2_name').get('ko')!='':
    RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['genre'].append(RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('category2_name').get('ko'))
   RqQNmjCyGrMufBKHWsFvdkXhgDPtUp=RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('release_date'))
   if RqQNmjCyGrMufBKHWsFvdkXhgDPtUp!='0':RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[:4],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[4:6],RqQNmjCyGrMufBKHWsFvdkXhgDPtUp[6:])
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbT=''
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =''
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=''
   for RqQNmjCyGrMufBKHWsFvdkXhgDPtUI in RqQNmjCyGrMufBKHWsFvdkXhgDPtIE.get('image'):
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('code')=='CAIM2100':RqQNmjCyGrMufBKHWsFvdkXhgDPtbT =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('url')
    elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('code')=='CAIM0400':RqQNmjCyGrMufBKHWsFvdkXhgDPtbE =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('url')
    elif RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('code')=='CAIM1800':RqQNmjCyGrMufBKHWsFvdkXhgDPtbL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.IMG_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtUI.get('url')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['thumbnail']['poster']=RqQNmjCyGrMufBKHWsFvdkXhgDPtbT
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['thumbnail']['thumb']=RqQNmjCyGrMufBKHWsFvdkXhgDPtbT 
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['thumbnail']['clearlogo']=RqQNmjCyGrMufBKHWsFvdkXhgDPtbL
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIz['saveinfo']['thumbnail']['fanart']=RqQNmjCyGrMufBKHWsFvdkXhgDPtbE
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtIz
 def GetEuroChannelList(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtia=[]
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiA ='/v2/operator/highlights'
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetDefaultParams()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtip={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':RqQNmjCyGrMufBKHWsFvdkXhgDPtOE(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.GetNoCache(2))}
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiT.update(RqQNmjCyGrMufBKHWsFvdkXhgDPtip)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiL=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.API_DOMAIN+RqQNmjCyGrMufBKHWsFvdkXhgDPtiA
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiU=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.callRequestCookies('Get',RqQNmjCyGrMufBKHWsFvdkXhgDPtiL,payload=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,params=RqQNmjCyGrMufBKHWsFvdkXhgDPtiT,headers=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc,cookies=RqQNmjCyGrMufBKHWsFvdkXhgDPtOc)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtiw=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtiU.text)
   if not('result' in RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']):return RqQNmjCyGrMufBKHWsFvdkXhgDPtia,RqQNmjCyGrMufBKHWsFvdkXhgDPtbV
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbw=RqQNmjCyGrMufBKHWsFvdkXhgDPtiw['body']['result']
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIT =RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.Get_Now_Datetime()
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIL=RqQNmjCyGrMufBKHWsFvdkXhgDPtIT+datetime.timedelta(days=-1)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtIL=RqQNmjCyGrMufBKHWsFvdkXhgDPtOo(RqQNmjCyGrMufBKHWsFvdkXhgDPtIL.strftime('%Y%m%d'))
   for RqQNmjCyGrMufBKHWsFvdkXhgDPtio in RqQNmjCyGrMufBKHWsFvdkXhgDPtbw:
    RqQNmjCyGrMufBKHWsFvdkXhgDPtOn=RqQNmjCyGrMufBKHWsFvdkXhgDPtOo(RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('content').get('banner_title2')[:8])
    if RqQNmjCyGrMufBKHWsFvdkXhgDPtIL<=RqQNmjCyGrMufBKHWsFvdkXhgDPtOn:
     RqQNmjCyGrMufBKHWsFvdkXhgDPtUo={'channel':RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('content').get('banner_sub_title3'),'title':RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('content').get('banner_title'),'subtitle':RqQNmjCyGrMufBKHWsFvdkXhgDPtio.get('content').get('banner_sub_title2'),}
     RqQNmjCyGrMufBKHWsFvdkXhgDPtia.append(RqQNmjCyGrMufBKHWsFvdkXhgDPtUo)
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtia
 def Make_DecryptKey(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,step,mediacode='000',timecode='000'):
  if step=='1':
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOi=RqQNmjCyGrMufBKHWsFvdkXhgDPtOL('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOb=RqQNmjCyGrMufBKHWsFvdkXhgDPtOL('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOi=RqQNmjCyGrMufBKHWsFvdkXhgDPtOL('kss2lym0kdw1lks3','utf-8')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOb=RqQNmjCyGrMufBKHWsFvdkXhgDPtOL([RqQNmjCyGrMufBKHWsFvdkXhgDPtln('*'),0x07,RqQNmjCyGrMufBKHWsFvdkXhgDPtln('r'),RqQNmjCyGrMufBKHWsFvdkXhgDPtln(';'),RqQNmjCyGrMufBKHWsFvdkXhgDPtln('7'),0x05,0x1e,0x01,RqQNmjCyGrMufBKHWsFvdkXhgDPtln('n'),RqQNmjCyGrMufBKHWsFvdkXhgDPtln('D'),0x02,RqQNmjCyGrMufBKHWsFvdkXhgDPtln('3'),RqQNmjCyGrMufBKHWsFvdkXhgDPtln('*'),RqQNmjCyGrMufBKHWsFvdkXhgDPtln('a'),RqQNmjCyGrMufBKHWsFvdkXhgDPtln('&'),RqQNmjCyGrMufBKHWsFvdkXhgDPtln('<')])
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtOi,RqQNmjCyGrMufBKHWsFvdkXhgDPtOb
 def DecryptPlaintext(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,ciphertext,encryption_key,init_vector):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtOU=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  RqQNmjCyGrMufBKHWsFvdkXhgDPtOI=Padding.unpad(RqQNmjCyGrMufBKHWsFvdkXhgDPtOU.decrypt(base64.standard_b64decode(ciphertext)),16)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtOI.decode('utf-8')
 def Decrypt_Url(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI,ciphertext,mediacode,RqQNmjCyGrMufBKHWsFvdkXhgDPtbl):
  RqQNmjCyGrMufBKHWsFvdkXhgDPtOl=''
  RqQNmjCyGrMufBKHWsFvdkXhgDPtbe=''
  RqQNmjCyGrMufBKHWsFvdkXhgDPtbA=''
  try:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOi,RqQNmjCyGrMufBKHWsFvdkXhgDPtOb=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.Make_DecryptKey('1',mediacode=mediacode,timecode=RqQNmjCyGrMufBKHWsFvdkXhgDPtbl)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOe=json.loads(RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.DecryptPlaintext(ciphertext,RqQNmjCyGrMufBKHWsFvdkXhgDPtOi,RqQNmjCyGrMufBKHWsFvdkXhgDPtOb))
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOA =RqQNmjCyGrMufBKHWsFvdkXhgDPtOe.get('broad_url')
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbe =RqQNmjCyGrMufBKHWsFvdkXhgDPtOe.get('watermark') if 'watermark' in RqQNmjCyGrMufBKHWsFvdkXhgDPtOe else ''
   RqQNmjCyGrMufBKHWsFvdkXhgDPtbA=RqQNmjCyGrMufBKHWsFvdkXhgDPtOe.get('watermarkKey')if 'watermarkKey' in RqQNmjCyGrMufBKHWsFvdkXhgDPtOe else ''
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOi,RqQNmjCyGrMufBKHWsFvdkXhgDPtOb=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.Make_DecryptKey('2',mediacode=mediacode,timecode=RqQNmjCyGrMufBKHWsFvdkXhgDPtbl)
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOl=RqQNmjCyGrMufBKHWsFvdkXhgDPtnI.DecryptPlaintext(RqQNmjCyGrMufBKHWsFvdkXhgDPtOA,RqQNmjCyGrMufBKHWsFvdkXhgDPtOi,RqQNmjCyGrMufBKHWsFvdkXhgDPtOb)
  except RqQNmjCyGrMufBKHWsFvdkXhgDPtOx as exception:
   RqQNmjCyGrMufBKHWsFvdkXhgDPtOz(exception)
  return RqQNmjCyGrMufBKHWsFvdkXhgDPtOl,RqQNmjCyGrMufBKHWsFvdkXhgDPtbe,RqQNmjCyGrMufBKHWsFvdkXhgDPtbA
# Created by pyminifier (https://github.com/liftoff/pyminifier)
