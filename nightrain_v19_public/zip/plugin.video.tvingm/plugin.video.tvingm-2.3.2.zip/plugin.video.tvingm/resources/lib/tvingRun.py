__author__="NightRain"
IJiOuzyTVKCNGjtAaeEwhSBXdMUxvD=object
IJiOuzyTVKCNGjtAaeEwhSBXdMUxro=None
IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq=int
IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY=True
IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR=False
IJiOuzyTVKCNGjtAaeEwhSBXdMUxrk=type
IJiOuzyTVKCNGjtAaeEwhSBXdMUxrH=dict
IJiOuzyTVKCNGjtAaeEwhSBXdMUxrv=len
IJiOuzyTVKCNGjtAaeEwhSBXdMUxrF=str
IJiOuzyTVKCNGjtAaeEwhSBXdMUxrc=range
IJiOuzyTVKCNGjtAaeEwhSBXdMUxrm=open
IJiOuzyTVKCNGjtAaeEwhSBXdMUxrb=Exception
IJiOuzyTVKCNGjtAaeEwhSBXdMUxrs=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
IJiOuzyTVKCNGjtAaeEwhSBXdMUxoY=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'Euro 2020','mode':'EURO_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
IJiOuzyTVKCNGjtAaeEwhSBXdMUxoR=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
IJiOuzyTVKCNGjtAaeEwhSBXdMUxok=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
IJiOuzyTVKCNGjtAaeEwhSBXdMUxoH=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
IJiOuzyTVKCNGjtAaeEwhSBXdMUxov=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
IJiOuzyTVKCNGjtAaeEwhSBXdMUxor=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
IJiOuzyTVKCNGjtAaeEwhSBXdMUxoF=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
IJiOuzyTVKCNGjtAaeEwhSBXdMUxoc =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
IJiOuzyTVKCNGjtAaeEwhSBXdMUxom=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class IJiOuzyTVKCNGjtAaeEwhSBXdMUxoq(IJiOuzyTVKCNGjtAaeEwhSBXdMUxvD):
 def __init__(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxos,IJiOuzyTVKCNGjtAaeEwhSBXdMUxog,IJiOuzyTVKCNGjtAaeEwhSBXdMUxoP):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_url =IJiOuzyTVKCNGjtAaeEwhSBXdMUxos
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle=IJiOuzyTVKCNGjtAaeEwhSBXdMUxog
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params =IJiOuzyTVKCNGjtAaeEwhSBXdMUxoP
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj =VLyAsDwCHjJFMOQKGeXTUSnulBIcpY() 
 def addon_noti(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,sting):
  try:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxoL=xbmcgui.Dialog()
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxoL.notification(__addonname__,sting)
  except:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
 def addon_log(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,string):
  try:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxoQ=string.encode('utf-8','ignore')
  except:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxoQ='addonException: addon_log'
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxol=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,IJiOuzyTVKCNGjtAaeEwhSBXdMUxoQ),level=IJiOuzyTVKCNGjtAaeEwhSBXdMUxol)
 def get_keyboard_input(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxon=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
  kb=xbmc.Keyboard()
  kb.setHeading(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxon=kb.getText()
  return IJiOuzyTVKCNGjtAaeEwhSBXdMUxon
 def get_settings_login_info(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxop =__addon__.getSetting('id')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxoW =__addon__.getSetting('pw')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxoD =__addon__.getSetting('login_type')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqo=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq(__addon__.getSetting('selected_profile'))
  return(IJiOuzyTVKCNGjtAaeEwhSBXdMUxop,IJiOuzyTVKCNGjtAaeEwhSBXdMUxoW,IJiOuzyTVKCNGjtAaeEwhSBXdMUxoD,IJiOuzyTVKCNGjtAaeEwhSBXdMUxqo)
 def get_settings_totalsearch(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqY =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY if __addon__.getSetting('local_search')=='true' else IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqR=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY if __addon__.getSetting('local_history')=='true' else IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqk =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY if __addon__.getSetting('total_search')=='true' else IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqH=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY if __addon__.getSetting('total_history')=='true' else IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqv=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY if __addon__.getSetting('menu_bookmark')=='true' else IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
  return(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqY,IJiOuzyTVKCNGjtAaeEwhSBXdMUxqR,IJiOuzyTVKCNGjtAaeEwhSBXdMUxqk,IJiOuzyTVKCNGjtAaeEwhSBXdMUxqH,IJiOuzyTVKCNGjtAaeEwhSBXdMUxqv)
 def get_settings_makebookmark(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob):
  return IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY if __addon__.getSetting('make_bookmark')=='true' else IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
 def get_settings_direct_replay(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqr=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq(__addon__.getSetting('direct_replay'))
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxqr==0:
   return IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
  else:
   return IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY
 def set_winCredential(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,credential):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF=xbmcgui.Window(10000)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_LOGINTIME',IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF=xbmcgui.Window(10000)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqc={'tving_token':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.getProperty('TVING_M_TOKEN'),'poc_userinfo':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.getProperty('TVING_M_USERINFO'),'tving_uuid':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.getProperty('TVING_M_UUID'),'tving_maintoken':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.getProperty('TVING_M_LOCKKEY')}
  return IJiOuzyTVKCNGjtAaeEwhSBXdMUxqc
 def set_winEpisodeOrderby(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxRv):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF=xbmcgui.Window(10000)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_ORDERBY',IJiOuzyTVKCNGjtAaeEwhSBXdMUxRv)
 def get_winEpisodeOrderby(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF=xbmcgui.Window(10000)
  return IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.getProperty('TVING_M_ORDERBY')
 def add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,label,sublabel='',img='',infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY,params='',isLink=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR,ContextMenu=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqm='%s?%s'%(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_url,urllib.parse.urlencode(params))
  if sublabel:IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb='%s < %s >'%(label,sublabel)
  else: IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb=label
  if not img:img='DefaultFolder.png'
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqs=xbmcgui.ListItem(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxrk(img)==IJiOuzyTVKCNGjtAaeEwhSBXdMUxrH:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqs.setArt(img)
  else:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqs.setArt({'thumb':img,'poster':img})
  if infoLabels:IJiOuzyTVKCNGjtAaeEwhSBXdMUxqs.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqs.setProperty('IsPlayable','true')
  if ContextMenu:IJiOuzyTVKCNGjtAaeEwhSBXdMUxqs.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,IJiOuzyTVKCNGjtAaeEwhSBXdMUxqm,IJiOuzyTVKCNGjtAaeEwhSBXdMUxqs,isFolder)
 def get_selQuality(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,etype):
  try:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqg='selected_quality'
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqP=[1080,720,480,360]
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqf=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq(__addon__.getSetting(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqg))
   return IJiOuzyTVKCNGjtAaeEwhSBXdMUxqP[IJiOuzyTVKCNGjtAaeEwhSBXdMUxqf]
  except:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
  return 720 
 def dp_Main_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob):
  (IJiOuzyTVKCNGjtAaeEwhSBXdMUxqY,IJiOuzyTVKCNGjtAaeEwhSBXdMUxqR,IJiOuzyTVKCNGjtAaeEwhSBXdMUxqk,IJiOuzyTVKCNGjtAaeEwhSBXdMUxqH,IJiOuzyTVKCNGjtAaeEwhSBXdMUxqv)=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_settings_totalsearch()
  for IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL in IJiOuzyTVKCNGjtAaeEwhSBXdMUxoY:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL.get('title')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ=''
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL.get('mode')=='SEARCH_GROUP' and IJiOuzyTVKCNGjtAaeEwhSBXdMUxqY ==IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR:continue
   elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL.get('mode')=='SEARCH_HISTORY' and IJiOuzyTVKCNGjtAaeEwhSBXdMUxqR==IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR:continue
   elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL.get('mode')=='TOTAL_SEARCH' and IJiOuzyTVKCNGjtAaeEwhSBXdMUxqk ==IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR:continue
   elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL.get('mode')=='TOTAL_HISTORY' and IJiOuzyTVKCNGjtAaeEwhSBXdMUxqH==IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR:continue
   elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL.get('mode')=='MENU_BOOKMARK' and IJiOuzyTVKCNGjtAaeEwhSBXdMUxqv==IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR:continue
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL.get('mode'),'stype':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL.get('stype'),'orderby':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL.get('orderby'),'ordernm':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL.get('ordernm'),'page':'1'}
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxqn=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxqp =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY
   else:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxqn=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxqp =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
   if 'icon' in IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL:IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',IJiOuzyTVKCNGjtAaeEwhSBXdMUxqL.get('icon')) 
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel='',img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqn,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql,isLink=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqp)
  xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle)
 def login_main(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob):
  (IJiOuzyTVKCNGjtAaeEwhSBXdMUxqD,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYo,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYq,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYR)=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_settings_login_info()
  if not(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqD and IJiOuzyTVKCNGjtAaeEwhSBXdMUxYo):
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxoL=xbmcgui.Dialog()
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxoL.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYk==IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_winEpisodeOrderby()=='':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.set_winEpisodeOrderby('desc')
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.cookiefile_check():return
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYH =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYv=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYv==IJiOuzyTVKCNGjtAaeEwhSBXdMUxro or IJiOuzyTVKCNGjtAaeEwhSBXdMUxYv=='':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYv=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq('19000101')
  else:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYv=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq(re.sub('-','',IJiOuzyTVKCNGjtAaeEwhSBXdMUxYv))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYr=0
   while IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxYr+=1
    time.sleep(0.05)
    if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYv>=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYH:return
    if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYr>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYv>=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYH:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.GetCredential(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqD,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYo,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYq,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYR):
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.set_winCredential(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.LoadCredential())
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('stype')
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='live':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYc=IJiOuzyTVKCNGjtAaeEwhSBXdMUxoR
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='vod':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYc=IJiOuzyTVKCNGjtAaeEwhSBXdMUxov
  else:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYc=IJiOuzyTVKCNGjtAaeEwhSBXdMUxor
  for IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm in IJiOuzyTVKCNGjtAaeEwhSBXdMUxYc:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm.get('title')
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('ordernm')!='-':
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb+='  ('+IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('ordernm')+')'
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm.get('mode'),'stype':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm.get('stype'),'orderby':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('orderby'),'ordernm':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('ordernm'),'page':'1'}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel='',img='',infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxrv(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYc)>0:xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle)
 def dp_SubTitle_Group(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb): 
  for IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm in IJiOuzyTVKCNGjtAaeEwhSBXdMUxoF:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm.get('title')
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('ordernm')!='-':
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb+='  ('+IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('ordernm')+')'
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm.get('mode'),'genreCode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm.get('genreCode'),'stype':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('stype'),'orderby':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('orderby'),'page':'1'}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel='',img='',infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxrv(IJiOuzyTVKCNGjtAaeEwhSBXdMUxoF)>0:xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle)
 def dp_LiveChannel_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.SaveCredential(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_winCredential())
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('stype')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('page'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYg,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYP=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.GetLiveChannelList(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs)
  for IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf in IJiOuzyTVKCNGjtAaeEwhSBXdMUxYg:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('title')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqW =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('channel')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('thumbnail')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYQ =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('synopsis')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYl =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('channelepg')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYn =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('cast')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYp =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('director')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYW =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('info_genre')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYD =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('year')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRo =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('mpaa')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRq =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('premiered')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY={'mediatype':'episode','title':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,'studio':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqW,'cast':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYn,'director':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYp,'genre':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYW,'plot':'%s\n%s\n%s\n\n%s'%(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqW,IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYl,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYQ),'year':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYD,'mpaa':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRo,'premiered':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRq}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':'LIVE','mediacode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('mediacode'),'stype':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqW,sublabel=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYP:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['mode']='CHANNEL' 
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['stype']=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF 
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['page']=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrF(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs+1)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb='[B]%s >>[/B]'%'다음 페이지'
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrF(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs+1)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk,img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxrv(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYg)>0:xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,cacheToDisc=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR)
 def dp_Program_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.SaveCredential(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_winCredential())
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxRH =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('stype')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxRv =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('orderby')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('page'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxRr=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('genreCode')
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxRr==IJiOuzyTVKCNGjtAaeEwhSBXdMUxro:IJiOuzyTVKCNGjtAaeEwhSBXdMUxRr='all'
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxRF,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYP=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.GetProgramList(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRH,IJiOuzyTVKCNGjtAaeEwhSBXdMUxRv,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs,IJiOuzyTVKCNGjtAaeEwhSBXdMUxRr)
  for IJiOuzyTVKCNGjtAaeEwhSBXdMUxRc in IJiOuzyTVKCNGjtAaeEwhSBXdMUxRF:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRc.get('title')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRc.get('thumbnail')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYQ =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRc.get('synopsis')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRm =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRc.get('channel')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYn =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRc.get('cast')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYp =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRc.get('director')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYW=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRc.get('info_genre')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYD =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRc.get('year')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRq =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRc.get('premiered')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRo =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRc.get('mpaa')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY={'mediatype':'tvshow','title':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,'studio':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRm,'cast':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYn,'director':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYp,'genre':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYW,'year':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYD,'premiered':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRq,'mpaa':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRo,'plot':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYQ}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':'EPISODE','programcode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRc.get('program'),'page':'1'}
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_settings_makebookmark():
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRb={'videoid':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRc.get('program'),'vidtype':'tvshow','vtitle':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,'vsubtitle':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRm,}
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRs=json.dumps(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRb)
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRs=urllib.parse.quote(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRs)
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRg='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRs)
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRP=[('(통합) 찜 영상에 추가',IJiOuzyTVKCNGjtAaeEwhSBXdMUxRg)]
   else:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRP=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRm,img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql,ContextMenu=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRP)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYP:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['mode'] ='PROGRAM' 
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['stype'] =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRH
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['orderby'] =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRv
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['page'] =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrF(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs+1)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['genreCode']=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRr 
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb='[B]%s >>[/B]'%'다음 페이지'
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrF(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs+1)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk,img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
  xbmcplugin.setContent(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,cacheToDisc=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR)
 def dp_Episode_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.SaveCredential(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_winCredential())
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxRL=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('programcode')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('page'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxRQ,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYP,IJiOuzyTVKCNGjtAaeEwhSBXdMUxRl=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.GetEpisodeList(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRL,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs,orderby=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_winEpisodeOrderby())
  for IJiOuzyTVKCNGjtAaeEwhSBXdMUxRn in IJiOuzyTVKCNGjtAaeEwhSBXdMUxRQ:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRn.get('title')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRn.get('subtitle')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRn.get('thumbnail')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYQ =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRn.get('synopsis')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRp=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRn.get('info_title')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRW =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRn.get('aired')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRD =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRn.get('studio')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxko =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRn.get('frequency')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY={'mediatype':'episode','title':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRp,'aired':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRW,'studio':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRD,'episode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxko,'plot':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYQ}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':'VOD','mediacode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRn.get('episode'),'stype':'vod','programcode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRL,'title':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,'thumbnail':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk,img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs==1:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY={'plot':'정렬순서를 변경합니다.'}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['mode'] ='ORDER_BY' 
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_winEpisodeOrderby()=='desc':
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb='정렬순서변경 : 최신화부터 -> 1회부터'
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['orderby']='asc'
   else:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb='정렬순서변경 : 1회부터 -> 최신화부터'
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['orderby']='desc'
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel='',img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql,isLink=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYP:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['mode'] ='EPISODE' 
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['programcode']=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRL
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['page'] =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrF(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs+1)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb='[B]%s >>[/B]'%'다음 페이지'
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrF(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs+1)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk,img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
  xbmcplugin.setContent(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,'episodes')
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxrv(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRQ)>0:xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,cacheToDisc=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY)
 def dp_setEpOrderby(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxRv =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('orderby')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.set_winEpisodeOrderby(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRv)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.SaveCredential(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_winCredential())
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxRH =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('stype')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxRv =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('orderby')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('page'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkq,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYP=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.GetMovieList(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRH,IJiOuzyTVKCNGjtAaeEwhSBXdMUxRv,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs)
  for IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY in IJiOuzyTVKCNGjtAaeEwhSBXdMUxkq:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('title')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('thumbnail')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYQ =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('synopsis')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRp =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('info_title')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYD =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('year')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYn =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('cast')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYp =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('director')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYW =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('info_genre')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxkR =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('duration')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRq =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('premiered')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRD =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('studio')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRo =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('mpaa')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY={'mediatype':'movie','title':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRp,'year':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYD,'cast':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYn,'director':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYp,'genre':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYW,'duration':IJiOuzyTVKCNGjtAaeEwhSBXdMUxkR,'premiered':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRq,'studio':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRD,'mpaa':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRo,'plot':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYQ}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':'MOVIE','mediacode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('moviecode'),'stype':'movie','title':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,'thumbnail':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL}
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_settings_makebookmark():
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRb={'videoid':IJiOuzyTVKCNGjtAaeEwhSBXdMUxkY.get('moviecode'),'vidtype':'movie','vtitle':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRp,'vsubtitle':'',}
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRs=json.dumps(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRb)
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRs=urllib.parse.quote(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRs)
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRg='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRs)
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRP=[('(통합) 찜 영상에 추가',IJiOuzyTVKCNGjtAaeEwhSBXdMUxRg)]
   else:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRP=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel='',img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql,ContextMenu=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRP)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYP:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['mode'] ='MOVIE_SUB' 
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['orderby']=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRv
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['stype'] =IJiOuzyTVKCNGjtAaeEwhSBXdMUxRH
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['page'] =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrF(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs+1)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb='[B]%s >>[/B]'%'다음 페이지'
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrF(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs+1)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk,img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
  xbmcplugin.setContent(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,'movies')
  xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,cacheToDisc=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR)
 def dp_Set_Bookmark(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkH=urllib.parse.unquote(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('bm_param'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkH=json.loads(IJiOuzyTVKCNGjtAaeEwhSBXdMUxkH)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkv =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkH.get('videoid')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkr =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkH.get('vidtype')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkF =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkH.get('vtitle')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkc =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkH.get('vsubtitle')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxoL=xbmcgui.Dialog()
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxoL.yesno(__language__(30913).encode('utf8'),IJiOuzyTVKCNGjtAaeEwhSBXdMUxkF+' \n\n'+__language__(30914))
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYk==IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR:return
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkm=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.GetBookmarkInfo(IJiOuzyTVKCNGjtAaeEwhSBXdMUxkv,IJiOuzyTVKCNGjtAaeEwhSBXdMUxkr)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxkc!='':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxkm['saveinfo']['subtitle']=IJiOuzyTVKCNGjtAaeEwhSBXdMUxkc 
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxkr=='tvshow':IJiOuzyTVKCNGjtAaeEwhSBXdMUxkm['saveinfo']['infoLabels']['studio']=IJiOuzyTVKCNGjtAaeEwhSBXdMUxkc 
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkb=json.dumps(IJiOuzyTVKCNGjtAaeEwhSBXdMUxkm)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkb=urllib.parse.quote(IJiOuzyTVKCNGjtAaeEwhSBXdMUxkb)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxRg ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(IJiOuzyTVKCNGjtAaeEwhSBXdMUxkb)
  xbmc.executebuiltin(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRg)
 def dp_Search_Group(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  if 'search_key' in IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxks=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('search_key')
  else:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxks=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not IJiOuzyTVKCNGjtAaeEwhSBXdMUxks:
    return
  for IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm in IJiOuzyTVKCNGjtAaeEwhSBXdMUxoH:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm.get('mode')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm.get('stype')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm.get('title')
   (IJiOuzyTVKCNGjtAaeEwhSBXdMUxkP,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYP)=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.GetSearchList(IJiOuzyTVKCNGjtAaeEwhSBXdMUxks,1,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxkf={'plot':'검색어 : '+IJiOuzyTVKCNGjtAaeEwhSBXdMUxks+'\n\n'+IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.Search_FreeList(IJiOuzyTVKCNGjtAaeEwhSBXdMUxkP)}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg,'stype':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF,'search_key':IJiOuzyTVKCNGjtAaeEwhSBXdMUxks,'page':'1',}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel='',img='',infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxkf,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxrv(IJiOuzyTVKCNGjtAaeEwhSBXdMUxoH)>0:xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,cacheToDisc=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.Save_Searched_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxks)
 def Search_FreeList(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkL=''
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkQ=7
  try:
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxrv(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq)==0:return '검색결과 없음'
   for i in IJiOuzyTVKCNGjtAaeEwhSBXdMUxrc(IJiOuzyTVKCNGjtAaeEwhSBXdMUxrv(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq)):
    if i>=IJiOuzyTVKCNGjtAaeEwhSBXdMUxkQ:
     IJiOuzyTVKCNGjtAaeEwhSBXdMUxkL=IJiOuzyTVKCNGjtAaeEwhSBXdMUxkL+'...'
     break
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxkL=IJiOuzyTVKCNGjtAaeEwhSBXdMUxkL+IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq[i]['title']+'\n'
  except:
   return ''
  return IJiOuzyTVKCNGjtAaeEwhSBXdMUxkL
 def dp_Search_History(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkl=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.Load_List_File('search')
  for IJiOuzyTVKCNGjtAaeEwhSBXdMUxkn in IJiOuzyTVKCNGjtAaeEwhSBXdMUxkl:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxkp=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrH(urllib.parse.parse_qsl(IJiOuzyTVKCNGjtAaeEwhSBXdMUxkn))
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxkW=IJiOuzyTVKCNGjtAaeEwhSBXdMUxkp.get('skey').strip()
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':'SEARCH_GROUP','search_key':IJiOuzyTVKCNGjtAaeEwhSBXdMUxkW,}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxkD={'mode':'SEARCH_REMOVE','stype':'ONE','skey':IJiOuzyTVKCNGjtAaeEwhSBXdMUxkW,}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHo=urllib.parse.urlencode(IJiOuzyTVKCNGjtAaeEwhSBXdMUxkD)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRP=[('선택된 검색어 ( %s ) 삭제'%(IJiOuzyTVKCNGjtAaeEwhSBXdMUxkW),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHo))]
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxkW,sublabel='',img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql,ContextMenu=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRP)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY={'plot':'검색목록 전체를 삭제합니다.'}
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel='',img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql,isLink=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY)
  xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,cacheToDisc=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR)
 def dp_Search_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.SaveCredential(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_winCredential())
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('page'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('stype')
  if 'search_key' in IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxks=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('search_key')
  else:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxks=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not IJiOuzyTVKCNGjtAaeEwhSBXdMUxks:
    xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle)
    return
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkP,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYP=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.GetSearchList(IJiOuzyTVKCNGjtAaeEwhSBXdMUxks,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF)
  for IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq in IJiOuzyTVKCNGjtAaeEwhSBXdMUxkP:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb =IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq.get('title')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL =IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq.get('thumbnail')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYQ =IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq.get('synopsis')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHY =IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq.get('program')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYn =IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq.get('cast')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYp =IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq.get('director')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYW=IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq.get('info_genre')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxkR =IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq.get('duration')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRo =IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq.get('mpaa')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYD =IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq.get('year')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRW =IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq.get('aired')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY={'mediatype':'tvshow' if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='vod' else 'movie','title':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,'cast':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYn,'director':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYp,'genre':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYW,'duration':IJiOuzyTVKCNGjtAaeEwhSBXdMUxkR,'mpaa':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRo,'year':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYD,'aired':IJiOuzyTVKCNGjtAaeEwhSBXdMUxRW,'plot':'%s\n\n%s'%(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYQ)}
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='vod':
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxkv=IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq.get('program')
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxkr='tvshow'
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':'EPISODE','programcode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxkv,'page':'1',}
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxqn=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY
   else:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxkv=IJiOuzyTVKCNGjtAaeEwhSBXdMUxHq.get('movie')
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxkr='movie'
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':'MOVIE','mediacode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxkv,'stype':'movie','title':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,'thumbnail':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL,}
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxqn=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_settings_makebookmark():
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRb={'videoid':IJiOuzyTVKCNGjtAaeEwhSBXdMUxkv,'vidtype':IJiOuzyTVKCNGjtAaeEwhSBXdMUxkr,'vtitle':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,'vsubtitle':'',}
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRs=json.dumps(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRb)
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRs=urllib.parse.quote(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRs)
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRg='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(IJiOuzyTVKCNGjtAaeEwhSBXdMUxRs)
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRP=[('(통합) 찜 영상에 추가',IJiOuzyTVKCNGjtAaeEwhSBXdMUxRg)]
   else:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRP=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel='',img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqn,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql,isLink=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR,ContextMenu=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRP)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYP:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['mode'] ='SEARCH' 
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['search_key']=IJiOuzyTVKCNGjtAaeEwhSBXdMUxks
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql['page'] =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrF(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs+1)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb='[B]%s >>[/B]'%'다음 페이지'
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrF(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYs+1)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk,img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='movie':xbmcplugin.setContent(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,'movies')
  else:xbmcplugin.setContent(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,cacheToDisc=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR)
 def Delete_List_File(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF,skey='-'):
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='ALL':
   try:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxHR=IJiOuzyTVKCNGjtAaeEwhSBXdMUxom
    fp=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrm(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHR,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='ONE':
   try:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxHR=IJiOuzyTVKCNGjtAaeEwhSBXdMUxom
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxHk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.Load_List_File('search') 
    fp=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrm(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHR,'w',-1,'utf-8')
    for IJiOuzyTVKCNGjtAaeEwhSBXdMUxHv in IJiOuzyTVKCNGjtAaeEwhSBXdMUxHk:
     IJiOuzyTVKCNGjtAaeEwhSBXdMUxHr=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrH(urllib.parse.parse_qsl(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHv))
     IJiOuzyTVKCNGjtAaeEwhSBXdMUxHF=IJiOuzyTVKCNGjtAaeEwhSBXdMUxHr.get('skey').strip()
     if skey!=IJiOuzyTVKCNGjtAaeEwhSBXdMUxHF:
      fp.write(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHv)
    fp.close()
   except:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF in['vod','movie']:
   try:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxHR=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF))
    fp=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrm(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHR,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
 def dp_Listfile_Delete(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('stype')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkW =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('skey')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxoL=xbmcgui.Dialog()
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='ALL':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxoL.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='ONE':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxoL.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF in['vod','movie']:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxYk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxoL.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYk==IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR:sys.exit()
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.Delete_List_File(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF,skey=IJiOuzyTVKCNGjtAaeEwhSBXdMUxkW)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF): 
  try:
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='search':
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxHR=IJiOuzyTVKCNGjtAaeEwhSBXdMUxom
   elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF in['vod','movie']:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxHR=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF))
   else:
    return[]
   fp=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrm(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHR,'r',-1,'utf-8')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHc=fp.readlines()
   fp.close()
  except:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHc=[]
  return IJiOuzyTVKCNGjtAaeEwhSBXdMUxHc
 def Save_Watched_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF,IJiOuzyTVKCNGjtAaeEwhSBXdMUxoP):
  try:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF))
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.Load_List_File(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF) 
   fp=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrm(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHm,'w',-1,'utf-8')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHb=urllib.parse.urlencode(IJiOuzyTVKCNGjtAaeEwhSBXdMUxoP)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHb=IJiOuzyTVKCNGjtAaeEwhSBXdMUxHb+'\n'
   fp.write(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHb)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHs=0
   for IJiOuzyTVKCNGjtAaeEwhSBXdMUxHv in IJiOuzyTVKCNGjtAaeEwhSBXdMUxHk:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxHr=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrH(urllib.parse.parse_qsl(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHv))
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxHg=IJiOuzyTVKCNGjtAaeEwhSBXdMUxoP.get('code').strip()
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxHP=IJiOuzyTVKCNGjtAaeEwhSBXdMUxHr.get('code').strip()
    if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='vod' and IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_settings_direct_replay()==IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY:
     IJiOuzyTVKCNGjtAaeEwhSBXdMUxHg=IJiOuzyTVKCNGjtAaeEwhSBXdMUxoP.get('videoid').strip()
     IJiOuzyTVKCNGjtAaeEwhSBXdMUxHP=IJiOuzyTVKCNGjtAaeEwhSBXdMUxHr.get('videoid').strip()if IJiOuzyTVKCNGjtAaeEwhSBXdMUxHP!=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro else '-'
    if IJiOuzyTVKCNGjtAaeEwhSBXdMUxHg!=IJiOuzyTVKCNGjtAaeEwhSBXdMUxHP:
     fp.write(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHv)
     IJiOuzyTVKCNGjtAaeEwhSBXdMUxHs+=1
     if IJiOuzyTVKCNGjtAaeEwhSBXdMUxHs>=50:break
   fp.close()
  except:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
 def dp_Watch_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('stype')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqr=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_settings_direct_replay()
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='-':
   for IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm in IJiOuzyTVKCNGjtAaeEwhSBXdMUxok:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm.get('title')
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm.get('mode'),'stype':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYm.get('stype')}
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel='',img='',infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxro,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxrv(IJiOuzyTVKCNGjtAaeEwhSBXdMUxok)>0:xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle)
  else:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHf=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.Load_List_File(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF)
   for IJiOuzyTVKCNGjtAaeEwhSBXdMUxHL in IJiOuzyTVKCNGjtAaeEwhSBXdMUxHf:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxkp=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrH(urllib.parse.parse_qsl(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHL))
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxHQ =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkp.get('code').strip()
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkp.get('title').strip()
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL=IJiOuzyTVKCNGjtAaeEwhSBXdMUxkp.get('img').strip()
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxkv =IJiOuzyTVKCNGjtAaeEwhSBXdMUxkp.get('videoid').strip()
    try:
     IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL.replace('\'','\"')
     IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL=json.loads(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL)
    except:
     IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY={}
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY['plot']=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb
    if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='vod':
     if IJiOuzyTVKCNGjtAaeEwhSBXdMUxqr==IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR or IJiOuzyTVKCNGjtAaeEwhSBXdMUxkv==IJiOuzyTVKCNGjtAaeEwhSBXdMUxro:
      IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':'EPISODE','programcode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxHQ,'page':'1'}
      IJiOuzyTVKCNGjtAaeEwhSBXdMUxqn=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY
     else:
      IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':'VOD','mediacode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxkv,'stype':'vod','programcode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxHQ,'title':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,'thumbnail':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL}
      IJiOuzyTVKCNGjtAaeEwhSBXdMUxqn=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
    else:
     IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':'MOVIE','mediacode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxHQ,'stype':'movie','title':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,'thumbnail':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL}
     IJiOuzyTVKCNGjtAaeEwhSBXdMUxqn=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel='',img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYL,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqn,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY={'plot':'시청목록을 삭제합니다.'}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb='*** 시청목록 삭제 ***'
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':'MYVIEW_REMOVE','stype':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF,'skey':'-',}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel='',img=IJiOuzyTVKCNGjtAaeEwhSBXdMUxqQ,infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql,isLink=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY)
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF=='movie':xbmcplugin.setContent(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,'movies')
   else:xbmcplugin.setContent(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,cacheToDisc=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR)
 def Save_Searched_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxks):
  try:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHl=IJiOuzyTVKCNGjtAaeEwhSBXdMUxom
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.Load_List_File('search') 
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHn={'skey':IJiOuzyTVKCNGjtAaeEwhSBXdMUxks.strip()}
   fp=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrm(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHl,'w',-1,'utf-8')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHb=urllib.parse.urlencode(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHn)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHb=IJiOuzyTVKCNGjtAaeEwhSBXdMUxHb+'\n'
   fp.write(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHb)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxHs=0
   for IJiOuzyTVKCNGjtAaeEwhSBXdMUxHv in IJiOuzyTVKCNGjtAaeEwhSBXdMUxHk:
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxHr=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrH(urllib.parse.parse_qsl(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHv))
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxHg=IJiOuzyTVKCNGjtAaeEwhSBXdMUxHn.get('skey').strip()
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxHP=IJiOuzyTVKCNGjtAaeEwhSBXdMUxHr.get('skey').strip()
    if IJiOuzyTVKCNGjtAaeEwhSBXdMUxHg!=IJiOuzyTVKCNGjtAaeEwhSBXdMUxHP:
     fp.write(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHv)
     IJiOuzyTVKCNGjtAaeEwhSBXdMUxHs+=1
     if IJiOuzyTVKCNGjtAaeEwhSBXdMUxHs>=50:break
   fp.close()
  except:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
 def play_VIDEO(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.SaveCredential(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_winCredential())
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxHp =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('mediacode')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('stype')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxHW =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('pvrmode')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxHD=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_selQuality(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxvo,IJiOuzyTVKCNGjtAaeEwhSBXdMUxvq=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.GetBroadURL(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHp,IJiOuzyTVKCNGjtAaeEwhSBXdMUxHD,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF,IJiOuzyTVKCNGjtAaeEwhSBXdMUxHW)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.addon_log('qt, stype, url : %s - %s - %s'%(IJiOuzyTVKCNGjtAaeEwhSBXdMUxrF(IJiOuzyTVKCNGjtAaeEwhSBXdMUxHD),IJiOuzyTVKCNGjtAaeEwhSBXdMUxYF,IJiOuzyTVKCNGjtAaeEwhSBXdMUxvo))
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxvo=='':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.addon_noti(__language__(30908).encode('utf8'))
   return
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxvY =IJiOuzyTVKCNGjtAaeEwhSBXdMUxvo.find('Policy=')
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxvY!=-1:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvR =IJiOuzyTVKCNGjtAaeEwhSBXdMUxvo.split('?')[0]
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrH(urllib.parse.parse_qsl(urllib.parse.urlsplit(IJiOuzyTVKCNGjtAaeEwhSBXdMUxvo).query))
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvk=urllib.parse.urlencode(IJiOuzyTVKCNGjtAaeEwhSBXdMUxvk)
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvk.replace('&',';')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvk.replace('Policy','CloudFront-Policy')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvk.replace('Signature','CloudFront-Signature')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvk.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvH='%s|Cookie=%s'%(IJiOuzyTVKCNGjtAaeEwhSBXdMUxvR,IJiOuzyTVKCNGjtAaeEwhSBXdMUxvk)
  else:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvH=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvo
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.addon_log(IJiOuzyTVKCNGjtAaeEwhSBXdMUxvH)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxvr=xbmcgui.ListItem(path=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvH)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxvq!='':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvF=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvq
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvc ='https://cj.drmkeyserver.com/widevine_license'
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvm ='mpd'
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvb ='com.widevine.alpha'
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvs =inputstreamhelper.Helper(IJiOuzyTVKCNGjtAaeEwhSBXdMUxvm,drm='widevine')
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxvs.check_inputstream():
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxvg={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%IJiOuzyTVKCNGjtAaeEwhSBXdMUxHp,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.USER_AGENT,'AcquireLicenseAssertion':IJiOuzyTVKCNGjtAaeEwhSBXdMUxvF,'Host':'cj.drmkeyserver.com'}
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxvP=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvc+'|'+urllib.parse.urlencode(IJiOuzyTVKCNGjtAaeEwhSBXdMUxvg)+'|R{SSM}|'
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxvr.setProperty('inputstream',IJiOuzyTVKCNGjtAaeEwhSBXdMUxvs.inputstream_addon)
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxvr.setProperty('inputstream.adaptive.manifest_type',IJiOuzyTVKCNGjtAaeEwhSBXdMUxvm)
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxvr.setProperty('inputstream.adaptive.license_type',IJiOuzyTVKCNGjtAaeEwhSBXdMUxvb)
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxvr.setProperty('inputstream.adaptive.license_key',IJiOuzyTVKCNGjtAaeEwhSBXdMUxvP)
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxvr.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.USER_AGENT))
  xbmcplugin.setResolvedUrl(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY,IJiOuzyTVKCNGjtAaeEwhSBXdMUxvr)
  try:
   if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('mode')in['VOD','MOVIE']and IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('title'):
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'code':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('programcode')if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('mode')=='VOD' else IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('mediacode'),'img':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('thumbnail'),'title':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('title'),'videoid':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('mediacode')}
    IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.Save_Watched_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('stype'),IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
  except:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
 def logout(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxoL=xbmcgui.Dialog()
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYk=IJiOuzyTVKCNGjtAaeEwhSBXdMUxoL.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYk==IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR:sys.exit()
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.wininfo_clear()
  if os.path.isfile(IJiOuzyTVKCNGjtAaeEwhSBXdMUxoc):os.remove(IJiOuzyTVKCNGjtAaeEwhSBXdMUxoc)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF=xbmcgui.Window(10000)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_TOKEN','')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_USERINFO','')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_UUID','')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_LOGINTIME','')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_MAINTOKEN','')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_COOKIEKEY','')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxvf =IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.Get_Now_Datetime()
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxvL=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvf+datetime.timedelta(days=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq(__addon__.getSetting('cache_ttl')))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF=xbmcgui.Window(10000)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ={'tving_token':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.getProperty('TVING_M_TOKEN'),'tving_userinfo':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.getProperty('TVING_M_USERINFO'),'tving_uuid':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':IJiOuzyTVKCNGjtAaeEwhSBXdMUxvL.strftime('%Y-%m-%d'),'tving_maintoken':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrm(IJiOuzyTVKCNGjtAaeEwhSBXdMUxoc,'w',-1,'utf-8')
   json.dump(IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ,fp)
   fp.close()
  except IJiOuzyTVKCNGjtAaeEwhSBXdMUxrb as exception:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxrs(exception)
 def cookiefile_check(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ={}
  try: 
   fp=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrm(IJiOuzyTVKCNGjtAaeEwhSBXdMUxoc,'r',-1,'utf-8')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ= json.load(fp)
   fp.close()
  except IJiOuzyTVKCNGjtAaeEwhSBXdMUxrb as exception:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.wininfo_clear()
   return IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqD =__addon__.getSetting('id')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYo =__addon__.getSetting('pw')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxvl=__addon__.getSetting('login_type')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxvn =__addon__.getSetting('selected_profile')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_id']=base64.standard_b64decode(IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_id']).decode('utf-8')
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_pw']=base64.standard_b64decode(IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_pw']).decode('utf-8')
  try:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_profile']
  except:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_profile']='0'
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxqD!=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_id']or IJiOuzyTVKCNGjtAaeEwhSBXdMUxYo!=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_pw']or IJiOuzyTVKCNGjtAaeEwhSBXdMUxvl!=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_logintype']or IJiOuzyTVKCNGjtAaeEwhSBXdMUxvn!=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_profile']:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.wininfo_clear()
   return IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYH =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxvp=IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_limitdate']
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYv =IJiOuzyTVKCNGjtAaeEwhSBXdMUxrq(re.sub('-','',IJiOuzyTVKCNGjtAaeEwhSBXdMUxvp))
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxYv<IJiOuzyTVKCNGjtAaeEwhSBXdMUxYH:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.wininfo_clear()
   return IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF=xbmcgui.Window(10000)
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_TOKEN',IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_token'])
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_USERINFO',IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_userinfo'])
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_UUID',IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_uuid'])
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_LOGINTIME',IJiOuzyTVKCNGjtAaeEwhSBXdMUxvp)
  try:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_MAINTOKEN',IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_maintoken'])
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_COOKIEKEY',IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_cookiekey'])
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_LOCKKEY',IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_lockkey'])
  except:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_MAINTOKEN',IJiOuzyTVKCNGjtAaeEwhSBXdMUxvQ['tving_token'])
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_COOKIEKEY','Y')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqF.setProperty('TVING_M_LOCKKEY','N')
  return IJiOuzyTVKCNGjtAaeEwhSBXdMUxrY
 def dp_Global_Search(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb.get('mode')
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=='TOTAL_SEARCH':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvW='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxvW='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(IJiOuzyTVKCNGjtAaeEwhSBXdMUxvW)
 def dp_Bookmark_Menu(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxvW='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(IJiOuzyTVKCNGjtAaeEwhSBXdMUxvW)
 def dp_EuroLive_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob,IJiOuzyTVKCNGjtAaeEwhSBXdMUxYb):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.SaveCredential(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.get_winCredential())
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxYg=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.TvingObj.GetEuroChannelList()
  for IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf in IJiOuzyTVKCNGjtAaeEwhSBXdMUxYg:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRm =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('channel')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('title')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk =IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('subtitle')
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY={'mediatype':'episode','title':IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,'plot':'%s\n%s'%(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk)}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxql={'mode':'LIVE','mediacode':IJiOuzyTVKCNGjtAaeEwhSBXdMUxYf.get('channel'),'stype':'onair',}
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.add_dir(IJiOuzyTVKCNGjtAaeEwhSBXdMUxqb,sublabel=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRk,img='',infoLabels=IJiOuzyTVKCNGjtAaeEwhSBXdMUxRY,isFolder=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR,params=IJiOuzyTVKCNGjtAaeEwhSBXdMUxql)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxrv(IJiOuzyTVKCNGjtAaeEwhSBXdMUxYg)>0:xbmcplugin.endOfDirectory(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob._addon_handle,cacheToDisc=IJiOuzyTVKCNGjtAaeEwhSBXdMUxrR)
 def tving_main(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob):
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params.get('mode',IJiOuzyTVKCNGjtAaeEwhSBXdMUxro)
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=='LOGOUT':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.logout()
   return
  IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.login_main()
  if IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg is IJiOuzyTVKCNGjtAaeEwhSBXdMUxro:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_Main_List()
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_Title_Group(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg in['GLOBAL_GROUP']:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_SubTitle_Group(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=='CHANNEL':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_LiveChannel_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg in['LIVE','VOD','MOVIE']:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.play_VIDEO(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=='PROGRAM':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_Program_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=='EPISODE':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_Episode_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=='MOVIE_SUB':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_Movie_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=='SEARCH_GROUP':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_Search_Group(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg in['SEARCH','LOCAL_SEARCH']:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_Search_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=='WATCH':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_Watch_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_Listfile_Delete(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=='ORDER_BY':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_setEpOrderby(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=='SET_BOOKMARK':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_Set_Bookmark(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg in['TOTAL_SEARCH','TOTAL_HISTORY']:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_Global_Search(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=='SEARCH_HISTORY':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_Search_History(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=='MENU_BOOKMARK':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_Bookmark_Menu(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  elif IJiOuzyTVKCNGjtAaeEwhSBXdMUxkg=='EURO_GROUP':
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.dp_EuroLive_List(IJiOuzyTVKCNGjtAaeEwhSBXdMUxob.main_params)
  else:
   IJiOuzyTVKCNGjtAaeEwhSBXdMUxro
# Created by pyminifier (https://github.com/liftoff/pyminifier)
