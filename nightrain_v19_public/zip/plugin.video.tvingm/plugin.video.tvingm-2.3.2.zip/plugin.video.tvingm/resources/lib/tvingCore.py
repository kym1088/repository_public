__author__="NightRain"
VLyAsDwCHjJFMOQKGeXTUSnulBIcaR=object
VLyAsDwCHjJFMOQKGeXTUSnulBIcaf=None
VLyAsDwCHjJFMOQKGeXTUSnulBIcao=False
VLyAsDwCHjJFMOQKGeXTUSnulBIcat=int
VLyAsDwCHjJFMOQKGeXTUSnulBIcah=range
VLyAsDwCHjJFMOQKGeXTUSnulBIcak=True
VLyAsDwCHjJFMOQKGeXTUSnulBIcaW=Exception
VLyAsDwCHjJFMOQKGeXTUSnulBIcaP=print
VLyAsDwCHjJFMOQKGeXTUSnulBIcaN=str
VLyAsDwCHjJFMOQKGeXTUSnulBIcar=list
VLyAsDwCHjJFMOQKGeXTUSnulBIcaz=len
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
VLyAsDwCHjJFMOQKGeXTUSnulBIcpx={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
VLyAsDwCHjJFMOQKGeXTUSnulBIcpg ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class VLyAsDwCHjJFMOQKGeXTUSnulBIcpY(VLyAsDwCHjJFMOQKGeXTUSnulBIcaR):
 def __init__(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_TOKEN =''
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.POC_USERINFO =''
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_UUID ='-'
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_MAINTOKEN=''
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVIGN_COOKIEKEY=''
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_LOCKKEY =''
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.NETWORKCODE ='CSND0900'
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.OSCODE ='CSOD0900' 
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TELECODE ='CSCD0900'
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.SCREENCODE ='CSSD0100'
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.LIVE_LIMIT =23
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.VOD_LIMIT =20
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.EPISODE_LIMIT =30 
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.SEARCH_LIMIT =30 
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.MOVIE_LIMIT =18
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.API_DOMAIN ='https://api.tving.com'
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN ='https://image.tving.com'
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.SEARCH_DOMAIN ='https://search.tving.com'
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.LOGIN_DOMAIN ='https://user.tving.com'
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.URL_DOMAIN ='https://www.tving.com'
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.MOVIE_LITE =['2610061','2610161','261062']
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.DEFAULT_HEADER ={'user-agent':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.USER_AGENT}
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,jobtype,VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,redirects=VLyAsDwCHjJFMOQKGeXTUSnulBIcao):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpa=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.DEFAULT_HEADER
  if headers:VLyAsDwCHjJFMOQKGeXTUSnulBIcpa.update(headers)
  if jobtype=='Get':
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpf=requests.get(VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,params=params,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcpa,cookies=cookies,allow_redirects=redirects)
  else:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpf=requests.post(VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,data=payload,params=params,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcpa,cookies=cookies,allow_redirects=redirects)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcpf
 def makeDefaultCookies(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,vToken=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,vUserinfo=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpo={}
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpo['_tving_token']=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_TOKEN if vToken==VLyAsDwCHjJFMOQKGeXTUSnulBIcaf else vToken
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpo['POC_USERINFO']=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.POC_USERINFO if vToken==VLyAsDwCHjJFMOQKGeXTUSnulBIcaf else vUserinfo
  if VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_MAINTOKEN!='':VLyAsDwCHjJFMOQKGeXTUSnulBIcpo[VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GLOBAL_COOKIENM['tv_maintoken']]=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_MAINTOKEN
  if VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVIGN_COOKIEKEY!='':VLyAsDwCHjJFMOQKGeXTUSnulBIcpo[VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GLOBAL_COOKIENM['tv_cookiekey']]=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVIGN_COOKIEKEY
  if VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_LOCKKEY !='':VLyAsDwCHjJFMOQKGeXTUSnulBIcpo[VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GLOBAL_COOKIENM['tv_lockkey']] =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_LOCKKEY
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcpo
 def getDeviceStr(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpt=[]
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpt.append('Windows') 
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpt.append('Chrome') 
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpt.append('ko-KR') 
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpt.append('undefined') 
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpt.append('24') 
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpt.append(u'한국 표준시')
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpt.append('undefined') 
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpt.append('undefined') 
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpt.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  VLyAsDwCHjJFMOQKGeXTUSnulBIcph=''
  for VLyAsDwCHjJFMOQKGeXTUSnulBIcpk in VLyAsDwCHjJFMOQKGeXTUSnulBIcpt:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcph+=VLyAsDwCHjJFMOQKGeXTUSnulBIcpk+'|'
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcph
 def SaveCredential(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,VLyAsDwCHjJFMOQKGeXTUSnulBIcpW):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_TOKEN =VLyAsDwCHjJFMOQKGeXTUSnulBIcpW.get('tving_token')
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.POC_USERINFO =VLyAsDwCHjJFMOQKGeXTUSnulBIcpW.get('poc_userinfo')
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_UUID =VLyAsDwCHjJFMOQKGeXTUSnulBIcpW.get('tving_uuid')
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_MAINTOKEN=VLyAsDwCHjJFMOQKGeXTUSnulBIcpW.get('tving_maintoken')
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVIGN_COOKIEKEY=VLyAsDwCHjJFMOQKGeXTUSnulBIcpW.get('tving_cookiekey')
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_LOCKKEY =VLyAsDwCHjJFMOQKGeXTUSnulBIcpW.get('tving_lockkey')
 def LoadCredential(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpW={'tving_token':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_TOKEN,'poc_userinfo':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.POC_USERINFO,'tving_uuid':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_UUID,'tving_maintoken':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_MAINTOKEN,'tving_cookiekey':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVIGN_COOKIEKEY,'tving_lockkey':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_LOCKKEY}
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcpW
 def GetDefaultParams(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpP={'apiKey':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.APIKEY,'networkCode':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.NETWORKCODE,'osCode':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.OSCODE,'teleCode':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TELECODE,'screenCode':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.SCREENCODE}
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcpP
 def GetNoCache(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,timetype=1):
  if timetype==1:
   return VLyAsDwCHjJFMOQKGeXTUSnulBIcat(time.time())
  else:
   return VLyAsDwCHjJFMOQKGeXTUSnulBIcat(time.time()*1000)
 def GetUniqueid(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpN=[0 for i in VLyAsDwCHjJFMOQKGeXTUSnulBIcah(256)]
  for i in VLyAsDwCHjJFMOQKGeXTUSnulBIcah(256):
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpN[i]='%02x'%(i)
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpr=VLyAsDwCHjJFMOQKGeXTUSnulBIcat(4294967295*random.random())|0
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpz=VLyAsDwCHjJFMOQKGeXTUSnulBIcpN[255&VLyAsDwCHjJFMOQKGeXTUSnulBIcpr]+VLyAsDwCHjJFMOQKGeXTUSnulBIcpN[VLyAsDwCHjJFMOQKGeXTUSnulBIcpr>>8&255]+VLyAsDwCHjJFMOQKGeXTUSnulBIcpN[VLyAsDwCHjJFMOQKGeXTUSnulBIcpr>>16&255]+VLyAsDwCHjJFMOQKGeXTUSnulBIcpN[VLyAsDwCHjJFMOQKGeXTUSnulBIcpr>>24&255]
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcpz
 def GetCredential(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,user_id,user_pw,login_type,user_pf):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpb=VLyAsDwCHjJFMOQKGeXTUSnulBIcao
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpi=VLyAsDwCHjJFMOQKGeXTUSnulBIcYp=VLyAsDwCHjJFMOQKGeXTUSnulBIcYx=VLyAsDwCHjJFMOQKGeXTUSnulBIcYg=VLyAsDwCHjJFMOQKGeXTUSnulBIcYR='' 
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpv ='-'
  try:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpq=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpE={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Post',VLyAsDwCHjJFMOQKGeXTUSnulBIcpq,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcpE,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf)
   for VLyAsDwCHjJFMOQKGeXTUSnulBIcpd in VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.cookies:
    if VLyAsDwCHjJFMOQKGeXTUSnulBIcpd.name=='_tving_token':
     VLyAsDwCHjJFMOQKGeXTUSnulBIcYp=VLyAsDwCHjJFMOQKGeXTUSnulBIcpd.value
    elif VLyAsDwCHjJFMOQKGeXTUSnulBIcpd.name=='POC_USERINFO':
     VLyAsDwCHjJFMOQKGeXTUSnulBIcYx=VLyAsDwCHjJFMOQKGeXTUSnulBIcpd.value
   if VLyAsDwCHjJFMOQKGeXTUSnulBIcYp=='':return VLyAsDwCHjJFMOQKGeXTUSnulBIcpb
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpi=VLyAsDwCHjJFMOQKGeXTUSnulBIcYp
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYp,VLyAsDwCHjJFMOQKGeXTUSnulBIcYg,VLyAsDwCHjJFMOQKGeXTUSnulBIcYR=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetProfileToken(VLyAsDwCHjJFMOQKGeXTUSnulBIcYp,VLyAsDwCHjJFMOQKGeXTUSnulBIcYx,user_pf)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpb=VLyAsDwCHjJFMOQKGeXTUSnulBIcak
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpv =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetDeviceList(VLyAsDwCHjJFMOQKGeXTUSnulBIcYp,VLyAsDwCHjJFMOQKGeXTUSnulBIcYx)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpv =VLyAsDwCHjJFMOQKGeXTUSnulBIcpv+'-'+VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetUniqueid()
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpi=VLyAsDwCHjJFMOQKGeXTUSnulBIcYp=VLyAsDwCHjJFMOQKGeXTUSnulBIcYx=VLyAsDwCHjJFMOQKGeXTUSnulBIcYg=VLyAsDwCHjJFMOQKGeXTUSnulBIcYR=''
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpv='-'
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpW={'tving_token':VLyAsDwCHjJFMOQKGeXTUSnulBIcYp,'poc_userinfo':VLyAsDwCHjJFMOQKGeXTUSnulBIcYx,'tving_uuid':VLyAsDwCHjJFMOQKGeXTUSnulBIcpv,'tving_maintoken':VLyAsDwCHjJFMOQKGeXTUSnulBIcpi,'tving_cookiekey':VLyAsDwCHjJFMOQKGeXTUSnulBIcYg,'tving_lockkey':VLyAsDwCHjJFMOQKGeXTUSnulBIcYR}
  VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.SaveCredential(VLyAsDwCHjJFMOQKGeXTUSnulBIcpW)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcpb
 def Get_Now_Datetime(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,mediacode,sel_quality,stype,pvrmode='-'):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcYf=''
  VLyAsDwCHjJFMOQKGeXTUSnulBIcYo=''
  VLyAsDwCHjJFMOQKGeXTUSnulBIcYt =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_UUID.split('-')[0] 
  VLyAsDwCHjJFMOQKGeXTUSnulBIcYh =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.TVING_UUID 
  if mediacode=='C01345':
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYf='http://ocn-mcdn.tving.com/ocn/live5000.smil/playlist.m3u8?Policy=eyJTdGF0ZW1lbnQiOiBbeyJSZXNvdXJjZSI6Imh0dHA6Ly8qIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNjEwODMwODAwfSwiSXBBZGRyZXNzIjp7IkFXUzpTb3VyY2VJcCI6IjAuMC4wLjAvMCJ9fX1dfQ__&Signature=eqJMOA5c~hIlgUVIDOtLCCfKXnNO0XHex3uQVQE87ZfuutuH2hqAgddlijKNWDz2Qrg5ScRkuXuU-7QQoj4QFSPPjyvwJSSrrZtNNVxU8xERXywdUKUwQGfDvl78F4rhS7WP-O1Q86KnLwif9QW0GPRK~n8ceOITlYq22rVLqp~EKwmoGQ3cvw01TMBFRInvobRtXR-zGyMZCx9MDgeHMRay0U9Ibp7nUPb3~T~set~W3so1ovUnF0iLuQpuarXQA3QIBy25O24NVbwalTtzjPoULkpEHeuVsMx-ACom3MTM65kB5TKJNIx19sdlAFQIII7n39FpWgSOO6A8jvu~rA__&Key-Pair-Id=APKAIXCIJCFRGOUEZDWA'
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    VLyAsDwCHjJFMOQKGeXTUSnulBIcYk ='/v2a/media/stream/info' 
    VLyAsDwCHjJFMOQKGeXTUSnulBIcYW=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetDefaultParams()
    VLyAsDwCHjJFMOQKGeXTUSnulBIcYP={'info':'N','mediaCode':mediacode,'noCache':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':VLyAsDwCHjJFMOQKGeXTUSnulBIcYt,'uuid':VLyAsDwCHjJFMOQKGeXTUSnulBIcYh,'deviceInfo':'PC','wm':'Y'}
    VLyAsDwCHjJFMOQKGeXTUSnulBIcYW.update(VLyAsDwCHjJFMOQKGeXTUSnulBIcYP)
    VLyAsDwCHjJFMOQKGeXTUSnulBIcYN=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.API_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYk
    VLyAsDwCHjJFMOQKGeXTUSnulBIcpo=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.makeDefaultCookies()
    VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Get',VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcYW,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcpo)
    VLyAsDwCHjJFMOQKGeXTUSnulBIcYr=json.loads(VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
    if not('stream' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']):return VLyAsDwCHjJFMOQKGeXTUSnulBIcYf,VLyAsDwCHjJFMOQKGeXTUSnulBIcYo 
    VLyAsDwCHjJFMOQKGeXTUSnulBIcYz=VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']['stream']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcYb=VLyAsDwCHjJFMOQKGeXTUSnulBIcYz['quality']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcYi=[]
    for VLyAsDwCHjJFMOQKGeXTUSnulBIcYv in VLyAsDwCHjJFMOQKGeXTUSnulBIcYb:
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['active']=='Y':
      VLyAsDwCHjJFMOQKGeXTUSnulBIcYi.append({VLyAsDwCHjJFMOQKGeXTUSnulBIcpx.get(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['code']):VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['code']})
    VLyAsDwCHjJFMOQKGeXTUSnulBIcYq=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.CheckQuality(sel_quality,VLyAsDwCHjJFMOQKGeXTUSnulBIcYi)
   else:
    for VLyAsDwCHjJFMOQKGeXTUSnulBIcYE,VLyAsDwCHjJFMOQKGeXTUSnulBIcxf in VLyAsDwCHjJFMOQKGeXTUSnulBIcpx.items():
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcxf==sel_quality:
      VLyAsDwCHjJFMOQKGeXTUSnulBIcYq=VLyAsDwCHjJFMOQKGeXTUSnulBIcYE
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
   for VLyAsDwCHjJFMOQKGeXTUSnulBIcYE,VLyAsDwCHjJFMOQKGeXTUSnulBIcxf in VLyAsDwCHjJFMOQKGeXTUSnulBIcpx.items():
    if VLyAsDwCHjJFMOQKGeXTUSnulBIcxf==sel_quality:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcYq=VLyAsDwCHjJFMOQKGeXTUSnulBIcYE
   return VLyAsDwCHjJFMOQKGeXTUSnulBIcYf,VLyAsDwCHjJFMOQKGeXTUSnulBIcYo
  VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(VLyAsDwCHjJFMOQKGeXTUSnulBIcYq)
  try:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYk ='/streaming/info'
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetDefaultParams()
   if stype=='onair':VLyAsDwCHjJFMOQKGeXTUSnulBIcYW['osCode']='CSOD0400' 
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYm={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYd=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.makeOocUrl(VLyAsDwCHjJFMOQKGeXTUSnulBIcYm)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxp=urllib.parse.quote(VLyAsDwCHjJFMOQKGeXTUSnulBIcYd)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYP={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':VLyAsDwCHjJFMOQKGeXTUSnulBIcYq,'adReq':'adproxy','ooc':VLyAsDwCHjJFMOQKGeXTUSnulBIcYd,'deviceId':VLyAsDwCHjJFMOQKGeXTUSnulBIcYt,'uuid':VLyAsDwCHjJFMOQKGeXTUSnulBIcYh,'deviceInfo':'PC'}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxY =VLyAsDwCHjJFMOQKGeXTUSnulBIcYW
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxY.update(VLyAsDwCHjJFMOQKGeXTUSnulBIcYP)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYN=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.URL_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYk
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxg={'origin':'https://www.tving.com'}
   if stype=='onair':VLyAsDwCHjJFMOQKGeXTUSnulBIcxg['Referer']='https://www.tving.com/live/player/'+mediacode
   else: VLyAsDwCHjJFMOQKGeXTUSnulBIcxg['Referer']='https://www.tving.com/vod/player/'+mediacode
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpo=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.makeDefaultCookies()
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpo['onClickEvent2']=VLyAsDwCHjJFMOQKGeXTUSnulBIcxp
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Post',VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcxY,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcxg,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcpo,redirects=VLyAsDwCHjJFMOQKGeXTUSnulBIcao)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYr=json.loads(VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
   if 'drm_license_assertion' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['stream']:
    VLyAsDwCHjJFMOQKGeXTUSnulBIcYo =VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['stream']['drm_license_assertion']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcYf=VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['stream']['broadcast']):return VLyAsDwCHjJFMOQKGeXTUSnulBIcYf,VLyAsDwCHjJFMOQKGeXTUSnulBIcYo
    VLyAsDwCHjJFMOQKGeXTUSnulBIcYf=VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['stream']['broadcast']['broad_url']
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcYf,VLyAsDwCHjJFMOQKGeXTUSnulBIcYo
 def CheckQuality(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,sel_qt,VLyAsDwCHjJFMOQKGeXTUSnulBIcYi):
  for VLyAsDwCHjJFMOQKGeXTUSnulBIcxR in VLyAsDwCHjJFMOQKGeXTUSnulBIcYi:
   if sel_qt>=VLyAsDwCHjJFMOQKGeXTUSnulBIcar(VLyAsDwCHjJFMOQKGeXTUSnulBIcxR)[0]:return VLyAsDwCHjJFMOQKGeXTUSnulBIcxR.get(VLyAsDwCHjJFMOQKGeXTUSnulBIcar(VLyAsDwCHjJFMOQKGeXTUSnulBIcxR)[0])
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxa=VLyAsDwCHjJFMOQKGeXTUSnulBIcxR.get(VLyAsDwCHjJFMOQKGeXTUSnulBIcar(VLyAsDwCHjJFMOQKGeXTUSnulBIcxR)[0])
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcxa
 def makeOocUrl(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,VLyAsDwCHjJFMOQKGeXTUSnulBIcYm):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcYN=''
  for VLyAsDwCHjJFMOQKGeXTUSnulBIcYE,VLyAsDwCHjJFMOQKGeXTUSnulBIcxf in VLyAsDwCHjJFMOQKGeXTUSnulBIcYm.items():
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYN+="%s=%s^"%(VLyAsDwCHjJFMOQKGeXTUSnulBIcYE,VLyAsDwCHjJFMOQKGeXTUSnulBIcxf)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcYN
 def GetLiveChannelList(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,stype,page_int):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxo=[]
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxt=VLyAsDwCHjJFMOQKGeXTUSnulBIcao
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxh=VLyAsDwCHjJFMOQKGeXTUSnulBIcao
  try:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYk ='/v2/media/lives'
   if stype=='onair': 
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxk='CPCS0100,CPCS0400'
   else:
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxk='CPCS0300'
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetDefaultParams()
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYP={'pageNo':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(page_int),'pageSize':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':VLyAsDwCHjJFMOQKGeXTUSnulBIcxk,'_':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetNoCache(2))}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW.update(VLyAsDwCHjJFMOQKGeXTUSnulBIcYP)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYN=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.API_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYk
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Get',VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcYW,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYr=json.loads(VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
   if not('result' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']):return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxW=VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']['result']
   for VLyAsDwCHjJFMOQKGeXTUSnulBIcYv in VLyAsDwCHjJFMOQKGeXTUSnulBIcxW:
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxP=VLyAsDwCHjJFMOQKGeXTUSnulBIcxz=VLyAsDwCHjJFMOQKGeXTUSnulBIcxb=''
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxN=VLyAsDwCHjJFMOQKGeXTUSnulBIcgW=''
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxr=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['live_code']
    if VLyAsDwCHjJFMOQKGeXTUSnulBIcxr=='C01345':VLyAsDwCHjJFMOQKGeXTUSnulBIcxh=VLyAsDwCHjJFMOQKGeXTUSnulBIcak 
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxP =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['channel']['name']['ko']
    if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['episode']!=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxz =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['program']['name']['ko']
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxz =VLyAsDwCHjJFMOQKGeXTUSnulBIcxz+', '+VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['episode']['frequency'])+'회'
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxb=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['episode']['synopsis']['ko']
    else:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxz =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['program']['name']['ko']
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxb=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['program']['synopsis']['ko']
    try: 
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =''
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxv =''
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxq=''
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxE =''
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxm =''
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxd =''
     for VLyAsDwCHjJFMOQKGeXTUSnulBIcgp in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['program']['image']:
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP0900':VLyAsDwCHjJFMOQKGeXTUSnulBIcxv =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
      elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP1800':VLyAsDwCHjJFMOQKGeXTUSnulBIcxq=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
      elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP2000':VLyAsDwCHjJFMOQKGeXTUSnulBIcxE =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
      elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP1900':VLyAsDwCHjJFMOQKGeXTUSnulBIcxm =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
      elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP0200':VLyAsDwCHjJFMOQKGeXTUSnulBIcxd =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
      elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP0500':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
      elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP0800':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcxi=='':
      for VLyAsDwCHjJFMOQKGeXTUSnulBIcgp in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['channel']['image']:
       if VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIC0400':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
       elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIC1400':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
       elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIC1900':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
    except:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcaf
    try:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgY =[]
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgx=[]
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgR =[]
     VLyAsDwCHjJFMOQKGeXTUSnulBIcga=''
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgf=''
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgo=''
     for VLyAsDwCHjJFMOQKGeXTUSnulBIcgt in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('schedule').get('program').get('actor'):
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcgt!='' and VLyAsDwCHjJFMOQKGeXTUSnulBIcgt!=u'없음':VLyAsDwCHjJFMOQKGeXTUSnulBIcgY.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgt)
     for VLyAsDwCHjJFMOQKGeXTUSnulBIcgh in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('schedule').get('program').get('director'):
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcgh!='' and VLyAsDwCHjJFMOQKGeXTUSnulBIcgh!='-' and VLyAsDwCHjJFMOQKGeXTUSnulBIcgh!=u'없음':VLyAsDwCHjJFMOQKGeXTUSnulBIcgx.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgh)
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('schedule').get('program').get('category1_name').get('ko')!='':
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgR.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['program']['category1_name']['ko'])
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('schedule').get('program').get('category2_name').get('ko')!='':
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgR.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['program']['category2_name']['ko'])
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('schedule').get('program').get('product_year'):VLyAsDwCHjJFMOQKGeXTUSnulBIcga=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['program']['product_year']
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('schedule').get('program').get('grade_code') :VLyAsDwCHjJFMOQKGeXTUSnulBIcgf= VLyAsDwCHjJFMOQKGeXTUSnulBIcpg.get(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['program']['grade_code'])
     if 'broad_dt' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('schedule').get('program'):
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgk =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('schedule').get('program').get('broad_dt')
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgo='%s-%s-%s'%(VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[:4],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[4:6],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[6:])
    except:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcaf
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxN=VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['broadcast_start_time'])[8:12]
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgW =VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['schedule']['broadcast_end_time'])[8:12]
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgP={'channel':VLyAsDwCHjJFMOQKGeXTUSnulBIcxP,'title':VLyAsDwCHjJFMOQKGeXTUSnulBIcxz,'mediacode':VLyAsDwCHjJFMOQKGeXTUSnulBIcxr,'thumbnail':{'poster':VLyAsDwCHjJFMOQKGeXTUSnulBIcxv,'thumb':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi,'clearlogo':VLyAsDwCHjJFMOQKGeXTUSnulBIcxq,'icon':VLyAsDwCHjJFMOQKGeXTUSnulBIcxE,'fanart':VLyAsDwCHjJFMOQKGeXTUSnulBIcxd},'synopsis':VLyAsDwCHjJFMOQKGeXTUSnulBIcxb,'channelepg':' [%s:%s ~ %s:%s]'%(VLyAsDwCHjJFMOQKGeXTUSnulBIcxN[0:2],VLyAsDwCHjJFMOQKGeXTUSnulBIcxN[2:],VLyAsDwCHjJFMOQKGeXTUSnulBIcgW[0:2],VLyAsDwCHjJFMOQKGeXTUSnulBIcgW[2:]),'cast':VLyAsDwCHjJFMOQKGeXTUSnulBIcgY,'director':VLyAsDwCHjJFMOQKGeXTUSnulBIcgx,'info_genre':VLyAsDwCHjJFMOQKGeXTUSnulBIcgR,'year':VLyAsDwCHjJFMOQKGeXTUSnulBIcga,'mpaa':VLyAsDwCHjJFMOQKGeXTUSnulBIcgf,'premiered':VLyAsDwCHjJFMOQKGeXTUSnulBIcgo}
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxo.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgP)
   if VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']['has_more']=='Y':
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxt=VLyAsDwCHjJFMOQKGeXTUSnulBIcak
   else:
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgP={'channel':'OCN Original','title':'temp','mediacode':'C01345','thumbnail':'http://image.tving.com/upload/cms/caic/CAIC0400/C01345.png','cast':[],'director':[]}
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
 def GetProgramList(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,genre,orderby,page_int,genreCode='all'):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxo=[]
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxt=VLyAsDwCHjJFMOQKGeXTUSnulBIcao
  try:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYk ='/v2/media/episodes'
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetDefaultParams()
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYP={'pageNo':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(page_int),'pageSize':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetNoCache(2))}
   if genre !='all':VLyAsDwCHjJFMOQKGeXTUSnulBIcYP['categoryCode']=genre
   if genreCode!='all':VLyAsDwCHjJFMOQKGeXTUSnulBIcYP['genreCode'] =genreCode 
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW.update(VLyAsDwCHjJFMOQKGeXTUSnulBIcYP)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYN=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.API_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYk
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Get',VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcYW,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYr=json.loads(VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
   if not('result' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']):return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxW=VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']['result']
   for VLyAsDwCHjJFMOQKGeXTUSnulBIcYv in VLyAsDwCHjJFMOQKGeXTUSnulBIcxW:
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgN=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['program']['code']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxz =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['program']['name']['ko']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgf =VLyAsDwCHjJFMOQKGeXTUSnulBIcpg.get(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['program'].get('grade_code'))
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxv =''
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =''
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxq=''
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxE =''
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxm =''
    for VLyAsDwCHjJFMOQKGeXTUSnulBIcgp in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['program']['image']:
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP0900':VLyAsDwCHjJFMOQKGeXTUSnulBIcxv =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
     elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP0200':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
     elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP1800':VLyAsDwCHjJFMOQKGeXTUSnulBIcxq=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
     elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP2000':VLyAsDwCHjJFMOQKGeXTUSnulBIcxE =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
     elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP1900':VLyAsDwCHjJFMOQKGeXTUSnulBIcxm =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxb =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['program']['synopsis']['ko']
    try:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgr=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['channel']['name']['ko']
    except:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgr=''
    try:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgY =[]
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgx=[]
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgR =[]
     VLyAsDwCHjJFMOQKGeXTUSnulBIcga =''
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgo=''
     for VLyAsDwCHjJFMOQKGeXTUSnulBIcgt in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('program').get('actor'):
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcgt!='' and VLyAsDwCHjJFMOQKGeXTUSnulBIcgt!='-' and VLyAsDwCHjJFMOQKGeXTUSnulBIcgt!=u'없음':VLyAsDwCHjJFMOQKGeXTUSnulBIcgY.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgt)
     for VLyAsDwCHjJFMOQKGeXTUSnulBIcgh in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('program').get('director'):
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcgh!='' and VLyAsDwCHjJFMOQKGeXTUSnulBIcgh!='-' and VLyAsDwCHjJFMOQKGeXTUSnulBIcgh!=u'없음':VLyAsDwCHjJFMOQKGeXTUSnulBIcgx.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgh)
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('program').get('category1_name').get('ko')!='':
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgR.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['program']['category1_name']['ko'])
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('program').get('category2_name').get('ko')!='':
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgR.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['program']['category2_name']['ko'])
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('program').get('product_year'):VLyAsDwCHjJFMOQKGeXTUSnulBIcga=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['program']['product_year']
     if 'broad_dt' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('program'):
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgk =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('program').get('broad_dt')
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgo='%s-%s-%s'%(VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[:4],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[4:6],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[6:])
    except:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcaf
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgP={'program':VLyAsDwCHjJFMOQKGeXTUSnulBIcgN,'title':VLyAsDwCHjJFMOQKGeXTUSnulBIcxz,'thumbnail':{'poster':VLyAsDwCHjJFMOQKGeXTUSnulBIcxv,'thumb':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi,'clearlogo':VLyAsDwCHjJFMOQKGeXTUSnulBIcxq,'icon':VLyAsDwCHjJFMOQKGeXTUSnulBIcxE,'banner':VLyAsDwCHjJFMOQKGeXTUSnulBIcxm,'fanart':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi},'synopsis':VLyAsDwCHjJFMOQKGeXTUSnulBIcxb,'channel':VLyAsDwCHjJFMOQKGeXTUSnulBIcgr,'cast':VLyAsDwCHjJFMOQKGeXTUSnulBIcgY,'director':VLyAsDwCHjJFMOQKGeXTUSnulBIcgx,'info_genre':VLyAsDwCHjJFMOQKGeXTUSnulBIcgR,'year':VLyAsDwCHjJFMOQKGeXTUSnulBIcga,'premiered':VLyAsDwCHjJFMOQKGeXTUSnulBIcgo,'mpaa':VLyAsDwCHjJFMOQKGeXTUSnulBIcgf}
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxo.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgP)
   if VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']['has_more']=='Y':VLyAsDwCHjJFMOQKGeXTUSnulBIcxt=VLyAsDwCHjJFMOQKGeXTUSnulBIcak
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
 def GetEpisodeList(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,program_code,page_int,orderby='desc'):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxo=[]
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxt=VLyAsDwCHjJFMOQKGeXTUSnulBIcao
  try:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYk ='/v2/media/frequency/program/'+program_code
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetDefaultParams()
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYP={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetNoCache(2))}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW.update(VLyAsDwCHjJFMOQKGeXTUSnulBIcYP)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYN=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.API_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYk
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Get',VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcYW,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYr=json.loads(VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
   if not('result' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']):return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxW=VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']['result']
   VLyAsDwCHjJFMOQKGeXTUSnulBIcgz=VLyAsDwCHjJFMOQKGeXTUSnulBIcat(VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']['total_count'])
   VLyAsDwCHjJFMOQKGeXTUSnulBIcgb =VLyAsDwCHjJFMOQKGeXTUSnulBIcat(VLyAsDwCHjJFMOQKGeXTUSnulBIcgz//(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgi =(VLyAsDwCHjJFMOQKGeXTUSnulBIcgz-1)-((page_int-1)*VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.EPISODE_LIMIT)
   else:
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgi =(page_int-1)*VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.EPISODE_LIMIT
   for i in VLyAsDwCHjJFMOQKGeXTUSnulBIcah(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.EPISODE_LIMIT):
    if orderby=='desc':
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgv=VLyAsDwCHjJFMOQKGeXTUSnulBIcgi-i
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcgv<0:break
    else:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgv=VLyAsDwCHjJFMOQKGeXTUSnulBIcgi+i
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcgv>=VLyAsDwCHjJFMOQKGeXTUSnulBIcgz:break
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgq=VLyAsDwCHjJFMOQKGeXTUSnulBIcxW[VLyAsDwCHjJFMOQKGeXTUSnulBIcgv]['episode']['code']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxz =VLyAsDwCHjJFMOQKGeXTUSnulBIcxW[VLyAsDwCHjJFMOQKGeXTUSnulBIcgv]['vod_name']['ko']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgE =''
    try:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgk=VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcxW[VLyAsDwCHjJFMOQKGeXTUSnulBIcgv]['episode']['broadcast_date'])
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgE='%s-%s-%s'%(VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[:4],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[4:6],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[6:])
    except:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcaf
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxb =VLyAsDwCHjJFMOQKGeXTUSnulBIcxW[VLyAsDwCHjJFMOQKGeXTUSnulBIcgv]['episode']['synopsis']['ko']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxv =''
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =''
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxq=''
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxE =''
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxm =''
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxd =''
    for VLyAsDwCHjJFMOQKGeXTUSnulBIcgp in VLyAsDwCHjJFMOQKGeXTUSnulBIcxW[VLyAsDwCHjJFMOQKGeXTUSnulBIcgv]['program']['image']:
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP0900':VLyAsDwCHjJFMOQKGeXTUSnulBIcxv =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
     elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP1800':VLyAsDwCHjJFMOQKGeXTUSnulBIcxq=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
     elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP2000':VLyAsDwCHjJFMOQKGeXTUSnulBIcxE =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
     elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP1900':VLyAsDwCHjJFMOQKGeXTUSnulBIcxm =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
     elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIP0200':VLyAsDwCHjJFMOQKGeXTUSnulBIcxd =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
    for VLyAsDwCHjJFMOQKGeXTUSnulBIcgp in VLyAsDwCHjJFMOQKGeXTUSnulBIcxW[VLyAsDwCHjJFMOQKGeXTUSnulBIcgv]['episode']['image']:
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIE0400':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
    try:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgm=VLyAsDwCHjJFMOQKGeXTUSnulBIcRp=VLyAsDwCHjJFMOQKGeXTUSnulBIcRY=''
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgd=0
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgm =VLyAsDwCHjJFMOQKGeXTUSnulBIcxW[VLyAsDwCHjJFMOQKGeXTUSnulBIcgv]['program']['name']['ko']
     VLyAsDwCHjJFMOQKGeXTUSnulBIcRp =VLyAsDwCHjJFMOQKGeXTUSnulBIcgE
     VLyAsDwCHjJFMOQKGeXTUSnulBIcRY =VLyAsDwCHjJFMOQKGeXTUSnulBIcxW[VLyAsDwCHjJFMOQKGeXTUSnulBIcgv]['channel']['name']['ko']
     if 'frequency' in VLyAsDwCHjJFMOQKGeXTUSnulBIcxW[VLyAsDwCHjJFMOQKGeXTUSnulBIcgv]['episode']:VLyAsDwCHjJFMOQKGeXTUSnulBIcgd=VLyAsDwCHjJFMOQKGeXTUSnulBIcxW[VLyAsDwCHjJFMOQKGeXTUSnulBIcgv]['episode']['frequency']
    except:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcaf
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgP={'episode':VLyAsDwCHjJFMOQKGeXTUSnulBIcgq,'title':VLyAsDwCHjJFMOQKGeXTUSnulBIcxz,'subtitle':VLyAsDwCHjJFMOQKGeXTUSnulBIcgE,'thumbnail':{'poster':VLyAsDwCHjJFMOQKGeXTUSnulBIcxv,'thumb':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi,'clearlogo':VLyAsDwCHjJFMOQKGeXTUSnulBIcxq,'icon':VLyAsDwCHjJFMOQKGeXTUSnulBIcxE,'banner':VLyAsDwCHjJFMOQKGeXTUSnulBIcxm,'fanart':VLyAsDwCHjJFMOQKGeXTUSnulBIcxd},'synopsis':VLyAsDwCHjJFMOQKGeXTUSnulBIcxb,'info_title':VLyAsDwCHjJFMOQKGeXTUSnulBIcgm,'aired':VLyAsDwCHjJFMOQKGeXTUSnulBIcRp,'studio':VLyAsDwCHjJFMOQKGeXTUSnulBIcRY,'frequency':VLyAsDwCHjJFMOQKGeXTUSnulBIcgd}
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxo.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgP)
   if VLyAsDwCHjJFMOQKGeXTUSnulBIcgb>page_int:VLyAsDwCHjJFMOQKGeXTUSnulBIcxt=VLyAsDwCHjJFMOQKGeXTUSnulBIcak
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt,VLyAsDwCHjJFMOQKGeXTUSnulBIcgb
 def GetMovieList(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,genre,orderby,page_int):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxo=[]
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxt=VLyAsDwCHjJFMOQKGeXTUSnulBIcao
  try:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYk ='/v2/media/movies'
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetDefaultParams()
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYP={'pageNo':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(page_int),'pageSize':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetNoCache(2))}
   if genre!='all' :VLyAsDwCHjJFMOQKGeXTUSnulBIcYP['multiCategoryCode']=genre
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYP['productPackageCode']=','.join(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.MOVIE_LITE)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW.update(VLyAsDwCHjJFMOQKGeXTUSnulBIcYP)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYN=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.API_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYk
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Get',VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcYW,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYr=json.loads(VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
   if not('result' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']):return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxW=VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']['result']
   for VLyAsDwCHjJFMOQKGeXTUSnulBIcYv in VLyAsDwCHjJFMOQKGeXTUSnulBIcxW:
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRx =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['movie']['code']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxz =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['movie']['name']['ko'].strip()
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxz +=u' (%s)'%(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('movie').get('product_year'))
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxv=''
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =''
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxq=''
    for VLyAsDwCHjJFMOQKGeXTUSnulBIcgp in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['movie']['image']:
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIM2100':VLyAsDwCHjJFMOQKGeXTUSnulBIcxv =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
     elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIM0400':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
     elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIM1800':VLyAsDwCHjJFMOQKGeXTUSnulBIcxq=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxb =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['movie']['story']['ko']
    try:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgm =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['movie']['name']['ko'].strip()
     VLyAsDwCHjJFMOQKGeXTUSnulBIcga =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('movie').get('product_year')
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgf =VLyAsDwCHjJFMOQKGeXTUSnulBIcpg.get(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('grade_code'))
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgY=[]
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgx=[]
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgR=[]
     VLyAsDwCHjJFMOQKGeXTUSnulBIcRg=0
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgo=''
     VLyAsDwCHjJFMOQKGeXTUSnulBIcRY =''
     for VLyAsDwCHjJFMOQKGeXTUSnulBIcgt in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('movie').get('actor'):
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcgt!='':VLyAsDwCHjJFMOQKGeXTUSnulBIcgY.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgt)
     for VLyAsDwCHjJFMOQKGeXTUSnulBIcgh in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('movie').get('director'):
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcgh!='':VLyAsDwCHjJFMOQKGeXTUSnulBIcgx.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgh)
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('movie').get('category1_name').get('ko')!='':
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgR.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['movie']['category1_name']['ko'])
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('movie').get('category2_name').get('ko')!='':
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgR.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['movie']['category2_name']['ko'])
     if 'duration' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('movie'):VLyAsDwCHjJFMOQKGeXTUSnulBIcRg=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('movie').get('duration')
     if 'release_date' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('movie'):
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgk=VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('movie').get('release_date'))
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcgk!='0':VLyAsDwCHjJFMOQKGeXTUSnulBIcgo='%s-%s-%s'%(VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[:4],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[4:6],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[6:])
     if 'production' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('movie'):VLyAsDwCHjJFMOQKGeXTUSnulBIcRY=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('movie').get('production')
    except:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcaf
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgP={'moviecode':VLyAsDwCHjJFMOQKGeXTUSnulBIcRx,'title':VLyAsDwCHjJFMOQKGeXTUSnulBIcxz,'thumbnail':{'poster':VLyAsDwCHjJFMOQKGeXTUSnulBIcxv,'thumb':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi,'clearlogo':VLyAsDwCHjJFMOQKGeXTUSnulBIcxq,'fanart':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi},'synopsis':VLyAsDwCHjJFMOQKGeXTUSnulBIcxb,'info_title':VLyAsDwCHjJFMOQKGeXTUSnulBIcgm,'year':VLyAsDwCHjJFMOQKGeXTUSnulBIcga,'cast':VLyAsDwCHjJFMOQKGeXTUSnulBIcgY,'director':VLyAsDwCHjJFMOQKGeXTUSnulBIcgx,'info_genre':VLyAsDwCHjJFMOQKGeXTUSnulBIcgR,'duration':VLyAsDwCHjJFMOQKGeXTUSnulBIcRg,'premiered':VLyAsDwCHjJFMOQKGeXTUSnulBIcgo,'studio':VLyAsDwCHjJFMOQKGeXTUSnulBIcRY,'mpaa':VLyAsDwCHjJFMOQKGeXTUSnulBIcgf}
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRa=VLyAsDwCHjJFMOQKGeXTUSnulBIcao
    for VLyAsDwCHjJFMOQKGeXTUSnulBIcRf in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['billing_package_id']:
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcRf in VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.MOVIE_LITE:
      VLyAsDwCHjJFMOQKGeXTUSnulBIcRa=VLyAsDwCHjJFMOQKGeXTUSnulBIcak
      break
    if VLyAsDwCHjJFMOQKGeXTUSnulBIcRa==VLyAsDwCHjJFMOQKGeXTUSnulBIcao: 
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgP['title']=VLyAsDwCHjJFMOQKGeXTUSnulBIcgP['title']+' [개별구매]'
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxo.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgP)
   if VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']['has_more']=='Y':VLyAsDwCHjJFMOQKGeXTUSnulBIcxt=VLyAsDwCHjJFMOQKGeXTUSnulBIcak
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
 def GetMovieListGenre(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,genre,page_int):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxo=[]
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxt=VLyAsDwCHjJFMOQKGeXTUSnulBIcao
  try:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYk ='/v2/media/movie/curation/'+genre
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetDefaultParams()
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYP={'pageNo':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(page_int),'pageSize':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.MOVIE_LIMIT),'_':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetNoCache(2))}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW.update(VLyAsDwCHjJFMOQKGeXTUSnulBIcYP)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYN=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.API_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYk
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Get',VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcYW,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYr=json.loads(VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
   if not('movies' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']):return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxW=VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']['movies']
   for VLyAsDwCHjJFMOQKGeXTUSnulBIcYv in VLyAsDwCHjJFMOQKGeXTUSnulBIcxW:
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRx =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['code']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxz =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['name']['ko']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRo =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['image'][0]['url']
    for VLyAsDwCHjJFMOQKGeXTUSnulBIcgp in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['image']:
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['code']=='CAIM2100':
      VLyAsDwCHjJFMOQKGeXTUSnulBIcRo =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp['url']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxb =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['story']['ko']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgP={'moviecode':VLyAsDwCHjJFMOQKGeXTUSnulBIcRx,'title':VLyAsDwCHjJFMOQKGeXTUSnulBIcxz.strip(),'thumbnail':VLyAsDwCHjJFMOQKGeXTUSnulBIcRo,'synopsis':VLyAsDwCHjJFMOQKGeXTUSnulBIcxb}
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxo.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgP)
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
 def GetMovieGenre(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxo=[]
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxt=VLyAsDwCHjJFMOQKGeXTUSnulBIcao
  try:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYk ='/v2/media/movie/curations'
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetDefaultParams()
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYP={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetNoCache(2))}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW.update(VLyAsDwCHjJFMOQKGeXTUSnulBIcYP)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYN=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.API_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYk
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Get',VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcYW,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYr=json.loads(VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
   if not('result' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']):return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxW=VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']['result']
   for VLyAsDwCHjJFMOQKGeXTUSnulBIcYv in VLyAsDwCHjJFMOQKGeXTUSnulBIcxW:
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRt =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['curation_code']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRh =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['curation_name']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcgP={'curation_code':VLyAsDwCHjJFMOQKGeXTUSnulBIcRt,'curation_name':VLyAsDwCHjJFMOQKGeXTUSnulBIcRh}
    VLyAsDwCHjJFMOQKGeXTUSnulBIcxo.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgP)
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
 def GetSearchList(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,search_key,page_int,stype):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcRk=[]
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxt=VLyAsDwCHjJFMOQKGeXTUSnulBIcao
  try:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYk ='/search/getSearch.jsp'
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYP={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(page_int),'pageSize':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.SCREENCODE,'os':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.OSCODE,'network':VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetNoCache(2))}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYN=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.SEARCH_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYk
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Get',VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcYP,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYr=json.loads(VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
   if stype=='vod':
    if not('programRsb' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYr):return VLyAsDwCHjJFMOQKGeXTUSnulBIcRk,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRW=VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['programRsb']['dataList']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRP =VLyAsDwCHjJFMOQKGeXTUSnulBIcat(VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['programRsb']['count'])
    for VLyAsDwCHjJFMOQKGeXTUSnulBIcYv in VLyAsDwCHjJFMOQKGeXTUSnulBIcRW:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgN=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['mast_cd']
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxz =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['mast_nm']
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxv=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['web_url4']
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['web_url']
     try:
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgY =[]
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgx=[]
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgR =[]
      VLyAsDwCHjJFMOQKGeXTUSnulBIcRg =0
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgf =''
      VLyAsDwCHjJFMOQKGeXTUSnulBIcga =''
      VLyAsDwCHjJFMOQKGeXTUSnulBIcRp =''
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('actor') !='' and VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('actor') !='-':VLyAsDwCHjJFMOQKGeXTUSnulBIcgY =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('actor').split(',')
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('director')!='' and VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('director')!='-':VLyAsDwCHjJFMOQKGeXTUSnulBIcgx=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('director').split(',')
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('cate_nm')!='' and VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('cate_nm')!='-':VLyAsDwCHjJFMOQKGeXTUSnulBIcgR =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('cate_nm').split('/')
      if 'targetage' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv:VLyAsDwCHjJFMOQKGeXTUSnulBIcgf=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('targetage')
      if 'broad_dt' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv:
       VLyAsDwCHjJFMOQKGeXTUSnulBIcgk=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('broad_dt')
       VLyAsDwCHjJFMOQKGeXTUSnulBIcRp='%s-%s-%s'%(VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[:4],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[4:6],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[6:])
       VLyAsDwCHjJFMOQKGeXTUSnulBIcga =VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[:4]
     except:
      VLyAsDwCHjJFMOQKGeXTUSnulBIcaf
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgP={'program':VLyAsDwCHjJFMOQKGeXTUSnulBIcgN,'title':VLyAsDwCHjJFMOQKGeXTUSnulBIcxz,'thumbnail':{'poster':VLyAsDwCHjJFMOQKGeXTUSnulBIcxv,'thumb':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi,'fanart':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi},'synopsis':'','cast':VLyAsDwCHjJFMOQKGeXTUSnulBIcgY,'director':VLyAsDwCHjJFMOQKGeXTUSnulBIcgx,'info_genre':VLyAsDwCHjJFMOQKGeXTUSnulBIcgR,'duration':VLyAsDwCHjJFMOQKGeXTUSnulBIcRg,'mpaa':VLyAsDwCHjJFMOQKGeXTUSnulBIcgf,'year':VLyAsDwCHjJFMOQKGeXTUSnulBIcga,'aired':VLyAsDwCHjJFMOQKGeXTUSnulBIcRp}
     VLyAsDwCHjJFMOQKGeXTUSnulBIcRk.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgP)
   else:
    if not('vodMVRsb' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYr):return VLyAsDwCHjJFMOQKGeXTUSnulBIcRk,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRN=VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['vodMVRsb']['dataList']
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRP =VLyAsDwCHjJFMOQKGeXTUSnulBIcat(VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['vodMVRsb']['count'])
    for VLyAsDwCHjJFMOQKGeXTUSnulBIcYv in VLyAsDwCHjJFMOQKGeXTUSnulBIcRN:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgN=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['mast_cd']
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxz =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['mast_nm'].strip()
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxv =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['web_url']
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =VLyAsDwCHjJFMOQKGeXTUSnulBIcxv
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxq=''
     try:
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgY =[]
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgx=[]
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgR =[]
      VLyAsDwCHjJFMOQKGeXTUSnulBIcRg =0
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgf =''
      VLyAsDwCHjJFMOQKGeXTUSnulBIcga =''
      VLyAsDwCHjJFMOQKGeXTUSnulBIcRp =''
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('actor') !='' and VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('actor') !='-':VLyAsDwCHjJFMOQKGeXTUSnulBIcgY =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('actor').split(',')
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('director')!='' and VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('director')!='-':VLyAsDwCHjJFMOQKGeXTUSnulBIcgx=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('director').split(',')
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('cate_nm')!='' and VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('cate_nm')!='-':VLyAsDwCHjJFMOQKGeXTUSnulBIcgR =VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('cate_nm').split('/')
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('runtime_sec')!='':VLyAsDwCHjJFMOQKGeXTUSnulBIcRg=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('runtime_sec')
      if 'grade_nm' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv:VLyAsDwCHjJFMOQKGeXTUSnulBIcgf=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('grade_nm')
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgk=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('broad_dt')
      if data_str!='':
       VLyAsDwCHjJFMOQKGeXTUSnulBIcRp='%s-%s-%s'%(VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[:4],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[4:6],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[6:])
       VLyAsDwCHjJFMOQKGeXTUSnulBIcga =VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[:4]
     except:
      VLyAsDwCHjJFMOQKGeXTUSnulBIcaf
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgP={'movie':VLyAsDwCHjJFMOQKGeXTUSnulBIcgN,'title':VLyAsDwCHjJFMOQKGeXTUSnulBIcxz,'thumbnail':{'poster':VLyAsDwCHjJFMOQKGeXTUSnulBIcxv,'thumb':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi,'fanart':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi,'clearlogo':VLyAsDwCHjJFMOQKGeXTUSnulBIcxq},'synopsis':'','cast':VLyAsDwCHjJFMOQKGeXTUSnulBIcgY,'director':VLyAsDwCHjJFMOQKGeXTUSnulBIcgx,'info_genre':VLyAsDwCHjJFMOQKGeXTUSnulBIcgR,'duration':VLyAsDwCHjJFMOQKGeXTUSnulBIcRg,'mpaa':VLyAsDwCHjJFMOQKGeXTUSnulBIcgf,'year':VLyAsDwCHjJFMOQKGeXTUSnulBIcga,'aired':VLyAsDwCHjJFMOQKGeXTUSnulBIcRp}
     VLyAsDwCHjJFMOQKGeXTUSnulBIcRa=VLyAsDwCHjJFMOQKGeXTUSnulBIcao
     for VLyAsDwCHjJFMOQKGeXTUSnulBIcRf in VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['bill']:
      if VLyAsDwCHjJFMOQKGeXTUSnulBIcRf in VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.MOVIE_LITE:
       VLyAsDwCHjJFMOQKGeXTUSnulBIcRa=VLyAsDwCHjJFMOQKGeXTUSnulBIcak
       break
     if VLyAsDwCHjJFMOQKGeXTUSnulBIcRa==VLyAsDwCHjJFMOQKGeXTUSnulBIcao: 
      VLyAsDwCHjJFMOQKGeXTUSnulBIcgP['title']=VLyAsDwCHjJFMOQKGeXTUSnulBIcgP['title']+' [개별구매]'
     VLyAsDwCHjJFMOQKGeXTUSnulBIcRk.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgP)
   if VLyAsDwCHjJFMOQKGeXTUSnulBIcRP>(page_int*VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.SEARCH_LIMIT):VLyAsDwCHjJFMOQKGeXTUSnulBIcxt=VLyAsDwCHjJFMOQKGeXTUSnulBIcak
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcRk,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
 def GetDeviceList(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,VLyAsDwCHjJFMOQKGeXTUSnulBIcYp,VLyAsDwCHjJFMOQKGeXTUSnulBIcYx):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxo=[]
  VLyAsDwCHjJFMOQKGeXTUSnulBIcYt='-'
  try:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYk ='/v1/user/device/list'
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRr=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.API_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYk
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYP={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpo=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.makeDefaultCookies(vToken=VLyAsDwCHjJFMOQKGeXTUSnulBIcYp,vUserinfo=VLyAsDwCHjJFMOQKGeXTUSnulBIcYx)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Get',VLyAsDwCHjJFMOQKGeXTUSnulBIcRr,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcYP,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcpo)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYr=json.loads(VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxo=VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']
   for VLyAsDwCHjJFMOQKGeXTUSnulBIcYv in VLyAsDwCHjJFMOQKGeXTUSnulBIcxo:
    if VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['model']=='PC':
     VLyAsDwCHjJFMOQKGeXTUSnulBIcYt=VLyAsDwCHjJFMOQKGeXTUSnulBIcYv['uuid']
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcYt
 def GetProfileToken(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,VLyAsDwCHjJFMOQKGeXTUSnulBIcYp,VLyAsDwCHjJFMOQKGeXTUSnulBIcYx,user_pf):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcRz=[]
  VLyAsDwCHjJFMOQKGeXTUSnulBIcRb =''
  VLyAsDwCHjJFMOQKGeXTUSnulBIcRi =''
  VLyAsDwCHjJFMOQKGeXTUSnulBIcRv='Y'
  VLyAsDwCHjJFMOQKGeXTUSnulBIcRq ='N'
  try:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYk ='/profile/select.do'
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRr=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.URL_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYk
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpo=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.makeDefaultCookies(vToken=VLyAsDwCHjJFMOQKGeXTUSnulBIcYp,vUserinfo=VLyAsDwCHjJFMOQKGeXTUSnulBIcYx)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Get',VLyAsDwCHjJFMOQKGeXTUSnulBIcRr,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcpo)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRz =re.findall('data-profile-no="\d+"',VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
   for i in VLyAsDwCHjJFMOQKGeXTUSnulBIcah(VLyAsDwCHjJFMOQKGeXTUSnulBIcaz(VLyAsDwCHjJFMOQKGeXTUSnulBIcRz)):
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRE =VLyAsDwCHjJFMOQKGeXTUSnulBIcRz[i].replace('data-profile-no=','').replace('"','')
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRz[i]=VLyAsDwCHjJFMOQKGeXTUSnulBIcRE
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRb=VLyAsDwCHjJFMOQKGeXTUSnulBIcRz[user_pf]
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
   return VLyAsDwCHjJFMOQKGeXTUSnulBIcRi,VLyAsDwCHjJFMOQKGeXTUSnulBIcRv,VLyAsDwCHjJFMOQKGeXTUSnulBIcRq
  try:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYk ='/profile/api/select.do'
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRr=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.URL_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYk
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpo=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.makeDefaultCookies(vToken=VLyAsDwCHjJFMOQKGeXTUSnulBIcYp,vUserinfo=VLyAsDwCHjJFMOQKGeXTUSnulBIcYx)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpE={'profileNo':VLyAsDwCHjJFMOQKGeXTUSnulBIcRb}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Post',VLyAsDwCHjJFMOQKGeXTUSnulBIcRr,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcpE,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcpo)
   for VLyAsDwCHjJFMOQKGeXTUSnulBIcpd in VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.cookies:
    if VLyAsDwCHjJFMOQKGeXTUSnulBIcpd.name=='_tving_token':
     VLyAsDwCHjJFMOQKGeXTUSnulBIcRi=VLyAsDwCHjJFMOQKGeXTUSnulBIcpd.value
    elif VLyAsDwCHjJFMOQKGeXTUSnulBIcpd.name==VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GLOBAL_COOKIENM['tv_cookiekey']:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcRv=VLyAsDwCHjJFMOQKGeXTUSnulBIcpd.value
    elif VLyAsDwCHjJFMOQKGeXTUSnulBIcpd.name==VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GLOBAL_COOKIENM['tv_lockkey']:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcRq=VLyAsDwCHjJFMOQKGeXTUSnulBIcpd.value
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcRi,VLyAsDwCHjJFMOQKGeXTUSnulBIcRv,VLyAsDwCHjJFMOQKGeXTUSnulBIcRq
 def GetBookmarkInfo(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR,videoid,vidtype):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcRm={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYN=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.API_DOMAIN+'/v2/media/program/'+videoid
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetDefaultParams()
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYP={'pageNo':'1','pageSize':'10','order':'name',}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW.update(VLyAsDwCHjJFMOQKGeXTUSnulBIcYP)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Get',VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcYW,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRd=json.loads(VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
   if not('body' in VLyAsDwCHjJFMOQKGeXTUSnulBIcRd):return{}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcap=VLyAsDwCHjJFMOQKGeXTUSnulBIcRd['body']
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxz=VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('name').get('ko').strip()
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['title'] =VLyAsDwCHjJFMOQKGeXTUSnulBIcxz
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['title']=VLyAsDwCHjJFMOQKGeXTUSnulBIcxz
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['mpaa'] =VLyAsDwCHjJFMOQKGeXTUSnulBIcpg.get(VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('grade_code'))
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['plot'] =VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('synopsis').get('ko')
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['year'] =VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('product_year')
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['cast'] =VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('actor')
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['director']=VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('director')
   if VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('category1_name').get('ko')!='':
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['genre'].append(VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('category1_name').get('ko'))
   if VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('category2_name').get('ko')!='':
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['genre'].append(VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('category2_name').get('ko'))
   VLyAsDwCHjJFMOQKGeXTUSnulBIcgk=VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('broad_dt'))
   if VLyAsDwCHjJFMOQKGeXTUSnulBIcgk!='0':VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[:4],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[4:6],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[6:])
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxv =''
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =''
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxq=''
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxE =''
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxm =''
   for VLyAsDwCHjJFMOQKGeXTUSnulBIcgp in VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('image'):
    if VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('code')=='CAIP0900':VLyAsDwCHjJFMOQKGeXTUSnulBIcxv =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('url')
    elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('code')=='CAIP0200':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('url')
    elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('code')=='CAIP1800':VLyAsDwCHjJFMOQKGeXTUSnulBIcxq=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('url')
    elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('code')=='CAIP2000':VLyAsDwCHjJFMOQKGeXTUSnulBIcxE =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('url')
    elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('code')=='CAIP1900':VLyAsDwCHjJFMOQKGeXTUSnulBIcxm =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('url')
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['thumbnail']['poster']=VLyAsDwCHjJFMOQKGeXTUSnulBIcxv
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['thumbnail']['thumb']=VLyAsDwCHjJFMOQKGeXTUSnulBIcxi
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['thumbnail']['clearlogo']=VLyAsDwCHjJFMOQKGeXTUSnulBIcxq
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['thumbnail']['icon']=VLyAsDwCHjJFMOQKGeXTUSnulBIcxE
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['thumbnail']['banner']=VLyAsDwCHjJFMOQKGeXTUSnulBIcxm
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['thumbnail']['fanart']=VLyAsDwCHjJFMOQKGeXTUSnulBIcxi
  else:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYN=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.API_DOMAIN+'/v2a/media/stream/info'
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetDefaultParams()
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYP={'info':'Y','mediaCode':videoid,'noCache':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':'','uuid':'','deviceInfo':'PC','wm':'Y',}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW.update(VLyAsDwCHjJFMOQKGeXTUSnulBIcYP)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Get',VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcYW,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRd=json.loads(VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
   if not('content' in VLyAsDwCHjJFMOQKGeXTUSnulBIcRd['body']):return{}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcap=VLyAsDwCHjJFMOQKGeXTUSnulBIcRd['body']['content']['info']['movie']
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxz =VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('name').get('ko').strip()
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['title']=VLyAsDwCHjJFMOQKGeXTUSnulBIcxz
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxz +=u' (%s)'%(VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('product_year'))
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['title'] =VLyAsDwCHjJFMOQKGeXTUSnulBIcxz
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['mpaa'] =VLyAsDwCHjJFMOQKGeXTUSnulBIcpg.get(VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('grade_code'))
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['plot'] =VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('story').get('ko')
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['year'] =VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('product_year')
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['studio'] =VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('production')
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['duration']=VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('duration')
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['cast'] =VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('actor')
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['director']=VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('director')
   if VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('category1_name').get('ko')!='':
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['genre'].append(VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('category1_name').get('ko'))
   if VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('category2_name').get('ko')!='':
    VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['genre'].append(VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('category2_name').get('ko'))
   VLyAsDwCHjJFMOQKGeXTUSnulBIcgk=VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('release_date'))
   if VLyAsDwCHjJFMOQKGeXTUSnulBIcgk!='0':VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[:4],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[4:6],VLyAsDwCHjJFMOQKGeXTUSnulBIcgk[6:])
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxv=''
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =''
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxq=''
   for VLyAsDwCHjJFMOQKGeXTUSnulBIcgp in VLyAsDwCHjJFMOQKGeXTUSnulBIcap.get('image'):
    if VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('code')=='CAIM2100':VLyAsDwCHjJFMOQKGeXTUSnulBIcxv =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('url')
    elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('code')=='CAIM0400':VLyAsDwCHjJFMOQKGeXTUSnulBIcxi =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('url')
    elif VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('code')=='CAIM1800':VLyAsDwCHjJFMOQKGeXTUSnulBIcxq=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.IMG_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcgp.get('url')
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['thumbnail']['poster']=VLyAsDwCHjJFMOQKGeXTUSnulBIcxv
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['thumbnail']['thumb']=VLyAsDwCHjJFMOQKGeXTUSnulBIcxv 
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['thumbnail']['clearlogo']=VLyAsDwCHjJFMOQKGeXTUSnulBIcxq
   VLyAsDwCHjJFMOQKGeXTUSnulBIcRm['saveinfo']['thumbnail']['fanart']=VLyAsDwCHjJFMOQKGeXTUSnulBIcxi
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcRm
 def GetEuroChannelList(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR):
  VLyAsDwCHjJFMOQKGeXTUSnulBIcxo=[]
  try:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYk ='/v2/operator/highlights'
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetDefaultParams()
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYP={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':VLyAsDwCHjJFMOQKGeXTUSnulBIcaN(VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.GetNoCache(2))}
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYW.update(VLyAsDwCHjJFMOQKGeXTUSnulBIcYP)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYN=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.API_DOMAIN+VLyAsDwCHjJFMOQKGeXTUSnulBIcYk
   VLyAsDwCHjJFMOQKGeXTUSnulBIcpm=VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.callRequestCookies('Get',VLyAsDwCHjJFMOQKGeXTUSnulBIcYN,payload=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,params=VLyAsDwCHjJFMOQKGeXTUSnulBIcYW,headers=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf,cookies=VLyAsDwCHjJFMOQKGeXTUSnulBIcaf)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcYr=json.loads(VLyAsDwCHjJFMOQKGeXTUSnulBIcpm.text)
   if not('result' in VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']):return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo,VLyAsDwCHjJFMOQKGeXTUSnulBIcxt
   VLyAsDwCHjJFMOQKGeXTUSnulBIcxW=VLyAsDwCHjJFMOQKGeXTUSnulBIcYr['body']['result']
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaY =VLyAsDwCHjJFMOQKGeXTUSnulBIcpR.Get_Now_Datetime()
   VLyAsDwCHjJFMOQKGeXTUSnulBIcax=VLyAsDwCHjJFMOQKGeXTUSnulBIcaY+datetime.timedelta(days=-1)
   VLyAsDwCHjJFMOQKGeXTUSnulBIcax=VLyAsDwCHjJFMOQKGeXTUSnulBIcat(VLyAsDwCHjJFMOQKGeXTUSnulBIcax.strftime('%Y%m%d'))
   for VLyAsDwCHjJFMOQKGeXTUSnulBIcYv in VLyAsDwCHjJFMOQKGeXTUSnulBIcxW:
    VLyAsDwCHjJFMOQKGeXTUSnulBIcag=VLyAsDwCHjJFMOQKGeXTUSnulBIcat(VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('content').get('banner_title2')[:8])
    if VLyAsDwCHjJFMOQKGeXTUSnulBIcax<=VLyAsDwCHjJFMOQKGeXTUSnulBIcag:
     VLyAsDwCHjJFMOQKGeXTUSnulBIcgP={'channel':VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('content').get('banner_sub_title3'),'title':VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('content').get('banner_title'),'subtitle':VLyAsDwCHjJFMOQKGeXTUSnulBIcYv.get('content').get('banner_sub_title2'),}
     VLyAsDwCHjJFMOQKGeXTUSnulBIcxo.append(VLyAsDwCHjJFMOQKGeXTUSnulBIcgP)
  except VLyAsDwCHjJFMOQKGeXTUSnulBIcaW as exception:
   VLyAsDwCHjJFMOQKGeXTUSnulBIcaP(exception)
  return VLyAsDwCHjJFMOQKGeXTUSnulBIcxo
# Created by pyminifier (https://github.com/liftoff/pyminifier)
