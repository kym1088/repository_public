__author__="NightRain"
EnVytgCOpDKrqfbBUQdhNHozAkGSXi=object
EnVytgCOpDKrqfbBUQdhNHozAkGSXI=None
EnVytgCOpDKrqfbBUQdhNHozAkGSXY=False
EnVytgCOpDKrqfbBUQdhNHozAkGSXP=int
EnVytgCOpDKrqfbBUQdhNHozAkGSXx=range
EnVytgCOpDKrqfbBUQdhNHozAkGSXW=True
EnVytgCOpDKrqfbBUQdhNHozAkGSXa=Exception
EnVytgCOpDKrqfbBUQdhNHozAkGSXL=print
EnVytgCOpDKrqfbBUQdhNHozAkGSXv=str
EnVytgCOpDKrqfbBUQdhNHozAkGSXs=list
EnVytgCOpDKrqfbBUQdhNHozAkGSXM=len
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
EnVytgCOpDKrqfbBUQdhNHozAkGSRm={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
EnVytgCOpDKrqfbBUQdhNHozAkGSRu ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class EnVytgCOpDKrqfbBUQdhNHozAkGSRT(EnVytgCOpDKrqfbBUQdhNHozAkGSXi):
 def __init__(EnVytgCOpDKrqfbBUQdhNHozAkGSRw):
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_TOKEN =''
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.POC_USERINFO =''
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_UUID ='-'
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_MAINTOKEN=''
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVIGN_COOKIEKEY=''
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_LOCKKEY =''
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.NETWORKCODE ='CSND0900'
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.OSCODE ='CSOD0900' 
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TELECODE ='CSCD0900'
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.SCREENCODE ='CSSD0100'
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.LIVE_LIMIT =23
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.VOD_LIMIT =20
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.EPISODE_LIMIT =30 
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.SEARCH_LIMIT =30 
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.MOVIE_LIMIT =18
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.API_DOMAIN ='https://api.tving.com'
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN ='https://image.tving.com'
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.SEARCH_DOMAIN ='https://search.tving.com'
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.LOGIN_DOMAIN ='https://user.tving.com'
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.URL_DOMAIN ='https://www.tving.com'
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.MOVIE_LITE =['2610061','2610161','261062']
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.DEFAULT_HEADER ={'user-agent':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.USER_AGENT}
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,jobtype,EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,redirects=EnVytgCOpDKrqfbBUQdhNHozAkGSXY):
  EnVytgCOpDKrqfbBUQdhNHozAkGSRX=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.DEFAULT_HEADER
  if headers:EnVytgCOpDKrqfbBUQdhNHozAkGSRX.update(headers)
  if jobtype=='Get':
   EnVytgCOpDKrqfbBUQdhNHozAkGSRc=requests.get(EnVytgCOpDKrqfbBUQdhNHozAkGSTx,params=params,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSRX,cookies=cookies,allow_redirects=redirects)
  else:
   EnVytgCOpDKrqfbBUQdhNHozAkGSRc=requests.post(EnVytgCOpDKrqfbBUQdhNHozAkGSTx,data=payload,params=params,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSRX,cookies=cookies,allow_redirects=redirects)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSRc
 def makeDefaultCookies(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,vToken=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,vUserinfo=EnVytgCOpDKrqfbBUQdhNHozAkGSXI):
  EnVytgCOpDKrqfbBUQdhNHozAkGSRF={}
  EnVytgCOpDKrqfbBUQdhNHozAkGSRF['_tving_token']=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_TOKEN if vToken==EnVytgCOpDKrqfbBUQdhNHozAkGSXI else vToken
  EnVytgCOpDKrqfbBUQdhNHozAkGSRF['POC_USERINFO']=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.POC_USERINFO if vToken==EnVytgCOpDKrqfbBUQdhNHozAkGSXI else vUserinfo
  if EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_MAINTOKEN!='':EnVytgCOpDKrqfbBUQdhNHozAkGSRF[EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GLOBAL_COOKIENM['tv_maintoken']]=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_MAINTOKEN
  if EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVIGN_COOKIEKEY!='':EnVytgCOpDKrqfbBUQdhNHozAkGSRF[EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GLOBAL_COOKIENM['tv_cookiekey']]=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVIGN_COOKIEKEY
  if EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_LOCKKEY !='':EnVytgCOpDKrqfbBUQdhNHozAkGSRF[EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GLOBAL_COOKIENM['tv_lockkey']] =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_LOCKKEY
  return EnVytgCOpDKrqfbBUQdhNHozAkGSRF
 def getDeviceStr(EnVytgCOpDKrqfbBUQdhNHozAkGSRw):
  EnVytgCOpDKrqfbBUQdhNHozAkGSRl=[]
  EnVytgCOpDKrqfbBUQdhNHozAkGSRl.append('Windows') 
  EnVytgCOpDKrqfbBUQdhNHozAkGSRl.append('Chrome') 
  EnVytgCOpDKrqfbBUQdhNHozAkGSRl.append('ko-KR') 
  EnVytgCOpDKrqfbBUQdhNHozAkGSRl.append('undefined') 
  EnVytgCOpDKrqfbBUQdhNHozAkGSRl.append('24') 
  EnVytgCOpDKrqfbBUQdhNHozAkGSRl.append(u'한국 표준시')
  EnVytgCOpDKrqfbBUQdhNHozAkGSRl.append('undefined') 
  EnVytgCOpDKrqfbBUQdhNHozAkGSRl.append('undefined') 
  EnVytgCOpDKrqfbBUQdhNHozAkGSRl.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  EnVytgCOpDKrqfbBUQdhNHozAkGSRi=''
  for EnVytgCOpDKrqfbBUQdhNHozAkGSRI in EnVytgCOpDKrqfbBUQdhNHozAkGSRl:
   EnVytgCOpDKrqfbBUQdhNHozAkGSRi+=EnVytgCOpDKrqfbBUQdhNHozAkGSRI+'|'
  return EnVytgCOpDKrqfbBUQdhNHozAkGSRi
 def SaveCredential(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,EnVytgCOpDKrqfbBUQdhNHozAkGSRY):
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_TOKEN =EnVytgCOpDKrqfbBUQdhNHozAkGSRY.get('tving_token')
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.POC_USERINFO =EnVytgCOpDKrqfbBUQdhNHozAkGSRY.get('poc_userinfo')
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_UUID =EnVytgCOpDKrqfbBUQdhNHozAkGSRY.get('tving_uuid')
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_MAINTOKEN=EnVytgCOpDKrqfbBUQdhNHozAkGSRY.get('tving_maintoken')
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVIGN_COOKIEKEY=EnVytgCOpDKrqfbBUQdhNHozAkGSRY.get('tving_cookiekey')
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_LOCKKEY =EnVytgCOpDKrqfbBUQdhNHozAkGSRY.get('tving_lockkey')
 def LoadCredential(EnVytgCOpDKrqfbBUQdhNHozAkGSRw):
  EnVytgCOpDKrqfbBUQdhNHozAkGSRY={'tving_token':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_TOKEN,'poc_userinfo':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.POC_USERINFO,'tving_uuid':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_UUID,'tving_maintoken':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_MAINTOKEN,'tving_cookiekey':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVIGN_COOKIEKEY,'tving_lockkey':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_LOCKKEY}
  return EnVytgCOpDKrqfbBUQdhNHozAkGSRY
 def GetDefaultParams(EnVytgCOpDKrqfbBUQdhNHozAkGSRw):
  EnVytgCOpDKrqfbBUQdhNHozAkGSRP={'apiKey':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.APIKEY,'networkCode':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.NETWORKCODE,'osCode':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.OSCODE,'teleCode':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TELECODE,'screenCode':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.SCREENCODE}
  return EnVytgCOpDKrqfbBUQdhNHozAkGSRP
 def GetNoCache(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,timetype=1):
  if timetype==1:
   return EnVytgCOpDKrqfbBUQdhNHozAkGSXP(time.time())
  else:
   return EnVytgCOpDKrqfbBUQdhNHozAkGSXP(time.time()*1000)
 def GetUniqueid(EnVytgCOpDKrqfbBUQdhNHozAkGSRw):
  EnVytgCOpDKrqfbBUQdhNHozAkGSRx=[0 for i in EnVytgCOpDKrqfbBUQdhNHozAkGSXx(256)]
  for i in EnVytgCOpDKrqfbBUQdhNHozAkGSXx(256):
   EnVytgCOpDKrqfbBUQdhNHozAkGSRx[i]='%02x'%(i)
  EnVytgCOpDKrqfbBUQdhNHozAkGSRW=EnVytgCOpDKrqfbBUQdhNHozAkGSXP(4294967295*random.random())|0
  EnVytgCOpDKrqfbBUQdhNHozAkGSRa=EnVytgCOpDKrqfbBUQdhNHozAkGSRx[255&EnVytgCOpDKrqfbBUQdhNHozAkGSRW]+EnVytgCOpDKrqfbBUQdhNHozAkGSRx[EnVytgCOpDKrqfbBUQdhNHozAkGSRW>>8&255]+EnVytgCOpDKrqfbBUQdhNHozAkGSRx[EnVytgCOpDKrqfbBUQdhNHozAkGSRW>>16&255]+EnVytgCOpDKrqfbBUQdhNHozAkGSRx[EnVytgCOpDKrqfbBUQdhNHozAkGSRW>>24&255]
  return EnVytgCOpDKrqfbBUQdhNHozAkGSRa
 def GetCredential(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,user_id,user_pw,login_type,user_pf):
  EnVytgCOpDKrqfbBUQdhNHozAkGSRL=EnVytgCOpDKrqfbBUQdhNHozAkGSXY
  EnVytgCOpDKrqfbBUQdhNHozAkGSRv=EnVytgCOpDKrqfbBUQdhNHozAkGSTR=EnVytgCOpDKrqfbBUQdhNHozAkGSTm=EnVytgCOpDKrqfbBUQdhNHozAkGSTu=EnVytgCOpDKrqfbBUQdhNHozAkGSTw='' 
  EnVytgCOpDKrqfbBUQdhNHozAkGSRs ='-'
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSRM=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   EnVytgCOpDKrqfbBUQdhNHozAkGSRe={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Post',EnVytgCOpDKrqfbBUQdhNHozAkGSRM,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSRe,params=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSXI)
   for EnVytgCOpDKrqfbBUQdhNHozAkGSRj in EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.cookies:
    if EnVytgCOpDKrqfbBUQdhNHozAkGSRj.name=='_tving_token':
     EnVytgCOpDKrqfbBUQdhNHozAkGSTR=EnVytgCOpDKrqfbBUQdhNHozAkGSRj.value
    elif EnVytgCOpDKrqfbBUQdhNHozAkGSRj.name=='POC_USERINFO':
     EnVytgCOpDKrqfbBUQdhNHozAkGSTm=EnVytgCOpDKrqfbBUQdhNHozAkGSRj.value
   if EnVytgCOpDKrqfbBUQdhNHozAkGSTR=='':return EnVytgCOpDKrqfbBUQdhNHozAkGSRL
   EnVytgCOpDKrqfbBUQdhNHozAkGSRv=EnVytgCOpDKrqfbBUQdhNHozAkGSTR
   EnVytgCOpDKrqfbBUQdhNHozAkGSTR,EnVytgCOpDKrqfbBUQdhNHozAkGSTu,EnVytgCOpDKrqfbBUQdhNHozAkGSTw=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetProfileToken(EnVytgCOpDKrqfbBUQdhNHozAkGSTR,EnVytgCOpDKrqfbBUQdhNHozAkGSTm,user_pf)
   EnVytgCOpDKrqfbBUQdhNHozAkGSRL=EnVytgCOpDKrqfbBUQdhNHozAkGSXW
   EnVytgCOpDKrqfbBUQdhNHozAkGSRs =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetDeviceList(EnVytgCOpDKrqfbBUQdhNHozAkGSTR,EnVytgCOpDKrqfbBUQdhNHozAkGSTm)
   EnVytgCOpDKrqfbBUQdhNHozAkGSRs =EnVytgCOpDKrqfbBUQdhNHozAkGSRs+'-'+EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetUniqueid()
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSRv=EnVytgCOpDKrqfbBUQdhNHozAkGSTR=EnVytgCOpDKrqfbBUQdhNHozAkGSTm=EnVytgCOpDKrqfbBUQdhNHozAkGSTu=EnVytgCOpDKrqfbBUQdhNHozAkGSTw=''
   EnVytgCOpDKrqfbBUQdhNHozAkGSRs='-'
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  EnVytgCOpDKrqfbBUQdhNHozAkGSRY={'tving_token':EnVytgCOpDKrqfbBUQdhNHozAkGSTR,'poc_userinfo':EnVytgCOpDKrqfbBUQdhNHozAkGSTm,'tving_uuid':EnVytgCOpDKrqfbBUQdhNHozAkGSRs,'tving_maintoken':EnVytgCOpDKrqfbBUQdhNHozAkGSRv,'tving_cookiekey':EnVytgCOpDKrqfbBUQdhNHozAkGSTu,'tving_lockkey':EnVytgCOpDKrqfbBUQdhNHozAkGSTw}
  EnVytgCOpDKrqfbBUQdhNHozAkGSRw.SaveCredential(EnVytgCOpDKrqfbBUQdhNHozAkGSRY)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSRL
 def Get_Now_Datetime(EnVytgCOpDKrqfbBUQdhNHozAkGSRw):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,mediacode,sel_quality,stype,pvrmode='-'):
  EnVytgCOpDKrqfbBUQdhNHozAkGSTc=''
  EnVytgCOpDKrqfbBUQdhNHozAkGSTF=''
  EnVytgCOpDKrqfbBUQdhNHozAkGSTl =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_UUID.split('-')[0] 
  EnVytgCOpDKrqfbBUQdhNHozAkGSTi =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.TVING_UUID 
  if mediacode=='C01345':
   EnVytgCOpDKrqfbBUQdhNHozAkGSTc='http://ocn-mcdn.tving.com/ocn/live5000.smil/playlist.m3u8?Policy=eyJTdGF0ZW1lbnQiOiBbeyJSZXNvdXJjZSI6Imh0dHA6Ly8qIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNjEwODMwODAwfSwiSXBBZGRyZXNzIjp7IkFXUzpTb3VyY2VJcCI6IjAuMC4wLjAvMCJ9fX1dfQ__&Signature=eqJMOA5c~hIlgUVIDOtLCCfKXnNO0XHex3uQVQE87ZfuutuH2hqAgddlijKNWDz2Qrg5ScRkuXuU-7QQoj4QFSPPjyvwJSSrrZtNNVxU8xERXywdUKUwQGfDvl78F4rhS7WP-O1Q86KnLwif9QW0GPRK~n8ceOITlYq22rVLqp~EKwmoGQ3cvw01TMBFRInvobRtXR-zGyMZCx9MDgeHMRay0U9Ibp7nUPb3~T~set~W3so1ovUnF0iLuQpuarXQA3QIBy25O24NVbwalTtzjPoULkpEHeuVsMx-ACom3MTM65kB5TKJNIx19sdlAFQIII7n39FpWgSOO6A8jvu~rA__&Key-Pair-Id=APKAIXCIJCFRGOUEZDWA'
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/v2a/media/stream/info' 
    EnVytgCOpDKrqfbBUQdhNHozAkGSTY=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetDefaultParams()
    EnVytgCOpDKrqfbBUQdhNHozAkGSTP={'info':'N','mediaCode':mediacode,'noCache':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':EnVytgCOpDKrqfbBUQdhNHozAkGSTl,'uuid':EnVytgCOpDKrqfbBUQdhNHozAkGSTi,'deviceInfo':'PC','wm':'Y'}
    EnVytgCOpDKrqfbBUQdhNHozAkGSTY.update(EnVytgCOpDKrqfbBUQdhNHozAkGSTP)
    EnVytgCOpDKrqfbBUQdhNHozAkGSTx=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.API_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
    EnVytgCOpDKrqfbBUQdhNHozAkGSRF=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.makeDefaultCookies()
    EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSTY,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSRF)
    EnVytgCOpDKrqfbBUQdhNHozAkGSTW=json.loads(EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
    if not('stream' in EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']):return EnVytgCOpDKrqfbBUQdhNHozAkGSTc,EnVytgCOpDKrqfbBUQdhNHozAkGSTF 
    EnVytgCOpDKrqfbBUQdhNHozAkGSTa=EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']['stream']
    EnVytgCOpDKrqfbBUQdhNHozAkGSTL=EnVytgCOpDKrqfbBUQdhNHozAkGSTa['quality']
    EnVytgCOpDKrqfbBUQdhNHozAkGSTv=[]
    for EnVytgCOpDKrqfbBUQdhNHozAkGSTs in EnVytgCOpDKrqfbBUQdhNHozAkGSTL:
     if EnVytgCOpDKrqfbBUQdhNHozAkGSTs['active']=='Y':
      EnVytgCOpDKrqfbBUQdhNHozAkGSTv.append({EnVytgCOpDKrqfbBUQdhNHozAkGSRm.get(EnVytgCOpDKrqfbBUQdhNHozAkGSTs['code']):EnVytgCOpDKrqfbBUQdhNHozAkGSTs['code']})
    EnVytgCOpDKrqfbBUQdhNHozAkGSTM=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.CheckQuality(sel_quality,EnVytgCOpDKrqfbBUQdhNHozAkGSTv)
   else:
    for EnVytgCOpDKrqfbBUQdhNHozAkGSTe,EnVytgCOpDKrqfbBUQdhNHozAkGSmc in EnVytgCOpDKrqfbBUQdhNHozAkGSRm.items():
     if EnVytgCOpDKrqfbBUQdhNHozAkGSmc==sel_quality:
      EnVytgCOpDKrqfbBUQdhNHozAkGSTM=EnVytgCOpDKrqfbBUQdhNHozAkGSTe
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
   for EnVytgCOpDKrqfbBUQdhNHozAkGSTe,EnVytgCOpDKrqfbBUQdhNHozAkGSmc in EnVytgCOpDKrqfbBUQdhNHozAkGSRm.items():
    if EnVytgCOpDKrqfbBUQdhNHozAkGSmc==sel_quality:
     EnVytgCOpDKrqfbBUQdhNHozAkGSTM=EnVytgCOpDKrqfbBUQdhNHozAkGSTe
   return EnVytgCOpDKrqfbBUQdhNHozAkGSTc,EnVytgCOpDKrqfbBUQdhNHozAkGSTF
  EnVytgCOpDKrqfbBUQdhNHozAkGSXL(EnVytgCOpDKrqfbBUQdhNHozAkGSTM)
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/streaming/info'
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetDefaultParams()
   if stype=='onair':EnVytgCOpDKrqfbBUQdhNHozAkGSTY['osCode']='CSOD0400' 
   EnVytgCOpDKrqfbBUQdhNHozAkGSTJ={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   EnVytgCOpDKrqfbBUQdhNHozAkGSTj=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.makeOocUrl(EnVytgCOpDKrqfbBUQdhNHozAkGSTJ)
   EnVytgCOpDKrqfbBUQdhNHozAkGSmR=urllib.parse.quote(EnVytgCOpDKrqfbBUQdhNHozAkGSTj)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTP={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':EnVytgCOpDKrqfbBUQdhNHozAkGSTM,'adReq':'adproxy','ooc':EnVytgCOpDKrqfbBUQdhNHozAkGSTj,'deviceId':EnVytgCOpDKrqfbBUQdhNHozAkGSTl,'uuid':EnVytgCOpDKrqfbBUQdhNHozAkGSTi,'deviceInfo':'PC'}
   EnVytgCOpDKrqfbBUQdhNHozAkGSmT =EnVytgCOpDKrqfbBUQdhNHozAkGSTY
   EnVytgCOpDKrqfbBUQdhNHozAkGSmT.update(EnVytgCOpDKrqfbBUQdhNHozAkGSTP)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.URL_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSmu={'origin':'https://www.tving.com'}
   if stype=='onair':EnVytgCOpDKrqfbBUQdhNHozAkGSmu['Referer']='https://www.tving.com/live/player/'+mediacode
   else: EnVytgCOpDKrqfbBUQdhNHozAkGSmu['Referer']='https://www.tving.com/vod/player/'+mediacode
   EnVytgCOpDKrqfbBUQdhNHozAkGSRF=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.makeDefaultCookies()
   EnVytgCOpDKrqfbBUQdhNHozAkGSRF['onClickEvent2']=EnVytgCOpDKrqfbBUQdhNHozAkGSmR
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Post',EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSmT,params=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSmu,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSRF,redirects=EnVytgCOpDKrqfbBUQdhNHozAkGSXY)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTW=json.loads(EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   if 'drm_license_assertion' in EnVytgCOpDKrqfbBUQdhNHozAkGSTW['stream']:
    EnVytgCOpDKrqfbBUQdhNHozAkGSTF =EnVytgCOpDKrqfbBUQdhNHozAkGSTW['stream']['drm_license_assertion']
    EnVytgCOpDKrqfbBUQdhNHozAkGSTc=EnVytgCOpDKrqfbBUQdhNHozAkGSTW['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in EnVytgCOpDKrqfbBUQdhNHozAkGSTW['stream']['broadcast']):return EnVytgCOpDKrqfbBUQdhNHozAkGSTc,EnVytgCOpDKrqfbBUQdhNHozAkGSTF
    EnVytgCOpDKrqfbBUQdhNHozAkGSTc=EnVytgCOpDKrqfbBUQdhNHozAkGSTW['stream']['broadcast']['broad_url']
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSTc,EnVytgCOpDKrqfbBUQdhNHozAkGSTF
 def CheckQuality(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,sel_qt,EnVytgCOpDKrqfbBUQdhNHozAkGSTv):
  for EnVytgCOpDKrqfbBUQdhNHozAkGSmw in EnVytgCOpDKrqfbBUQdhNHozAkGSTv:
   if sel_qt>=EnVytgCOpDKrqfbBUQdhNHozAkGSXs(EnVytgCOpDKrqfbBUQdhNHozAkGSmw)[0]:return EnVytgCOpDKrqfbBUQdhNHozAkGSmw.get(EnVytgCOpDKrqfbBUQdhNHozAkGSXs(EnVytgCOpDKrqfbBUQdhNHozAkGSmw)[0])
   EnVytgCOpDKrqfbBUQdhNHozAkGSmX=EnVytgCOpDKrqfbBUQdhNHozAkGSmw.get(EnVytgCOpDKrqfbBUQdhNHozAkGSXs(EnVytgCOpDKrqfbBUQdhNHozAkGSmw)[0])
  return EnVytgCOpDKrqfbBUQdhNHozAkGSmX
 def makeOocUrl(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,EnVytgCOpDKrqfbBUQdhNHozAkGSTJ):
  EnVytgCOpDKrqfbBUQdhNHozAkGSTx=''
  for EnVytgCOpDKrqfbBUQdhNHozAkGSTe,EnVytgCOpDKrqfbBUQdhNHozAkGSmc in EnVytgCOpDKrqfbBUQdhNHozAkGSTJ.items():
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx+="%s=%s^"%(EnVytgCOpDKrqfbBUQdhNHozAkGSTe,EnVytgCOpDKrqfbBUQdhNHozAkGSmc)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSTx
 def GetLiveChannelList(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,stype,page_int):
  EnVytgCOpDKrqfbBUQdhNHozAkGSmF=[]
  EnVytgCOpDKrqfbBUQdhNHozAkGSml=EnVytgCOpDKrqfbBUQdhNHozAkGSXY
  EnVytgCOpDKrqfbBUQdhNHozAkGSmi=EnVytgCOpDKrqfbBUQdhNHozAkGSXY
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/v2/media/lives'
   if stype=='onair': 
    EnVytgCOpDKrqfbBUQdhNHozAkGSmI='CPCS0100,CPCS0400'
   else:
    EnVytgCOpDKrqfbBUQdhNHozAkGSmI='CPCS0300'
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetDefaultParams()
   EnVytgCOpDKrqfbBUQdhNHozAkGSTP={'pageNo':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(page_int),'pageSize':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':EnVytgCOpDKrqfbBUQdhNHozAkGSmI,'_':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetNoCache(2))}
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY.update(EnVytgCOpDKrqfbBUQdhNHozAkGSTP)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.API_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSTY,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSXI)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTW=json.loads(EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   if not('result' in EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']):return EnVytgCOpDKrqfbBUQdhNHozAkGSmF,EnVytgCOpDKrqfbBUQdhNHozAkGSml
   EnVytgCOpDKrqfbBUQdhNHozAkGSmY=EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']['result']
   for EnVytgCOpDKrqfbBUQdhNHozAkGSTs in EnVytgCOpDKrqfbBUQdhNHozAkGSmY:
    EnVytgCOpDKrqfbBUQdhNHozAkGSmP=EnVytgCOpDKrqfbBUQdhNHozAkGSma=EnVytgCOpDKrqfbBUQdhNHozAkGSmL=''
    EnVytgCOpDKrqfbBUQdhNHozAkGSmx=EnVytgCOpDKrqfbBUQdhNHozAkGSuY=''
    EnVytgCOpDKrqfbBUQdhNHozAkGSmW=EnVytgCOpDKrqfbBUQdhNHozAkGSTs['live_code']
    if EnVytgCOpDKrqfbBUQdhNHozAkGSmW=='C01345':EnVytgCOpDKrqfbBUQdhNHozAkGSmi=EnVytgCOpDKrqfbBUQdhNHozAkGSXW 
    EnVytgCOpDKrqfbBUQdhNHozAkGSmP =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['channel']['name']['ko']
    if EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['episode']!=EnVytgCOpDKrqfbBUQdhNHozAkGSXI:
     EnVytgCOpDKrqfbBUQdhNHozAkGSma =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['program']['name']['ko']
     EnVytgCOpDKrqfbBUQdhNHozAkGSma =EnVytgCOpDKrqfbBUQdhNHozAkGSma+', '+EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['episode']['frequency'])+'회'
     EnVytgCOpDKrqfbBUQdhNHozAkGSmL=EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['episode']['synopsis']['ko']
    else:
     EnVytgCOpDKrqfbBUQdhNHozAkGSma =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['program']['name']['ko']
     EnVytgCOpDKrqfbBUQdhNHozAkGSmL=EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['program']['synopsis']['ko']
    try: 
     EnVytgCOpDKrqfbBUQdhNHozAkGSmv =''
     EnVytgCOpDKrqfbBUQdhNHozAkGSms =''
     EnVytgCOpDKrqfbBUQdhNHozAkGSmM=''
     EnVytgCOpDKrqfbBUQdhNHozAkGSme =''
     EnVytgCOpDKrqfbBUQdhNHozAkGSmJ =''
     EnVytgCOpDKrqfbBUQdhNHozAkGSmj =''
     for EnVytgCOpDKrqfbBUQdhNHozAkGSuR in EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['program']['image']:
      if EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP0900':EnVytgCOpDKrqfbBUQdhNHozAkGSms =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
      elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP1800':EnVytgCOpDKrqfbBUQdhNHozAkGSmM=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
      elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP2000':EnVytgCOpDKrqfbBUQdhNHozAkGSme =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
      elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP1900':EnVytgCOpDKrqfbBUQdhNHozAkGSmJ =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
      elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP0200':EnVytgCOpDKrqfbBUQdhNHozAkGSmj =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
      elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP0500':EnVytgCOpDKrqfbBUQdhNHozAkGSmv =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
      elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP0800':EnVytgCOpDKrqfbBUQdhNHozAkGSmv =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
     if EnVytgCOpDKrqfbBUQdhNHozAkGSmv=='':
      for EnVytgCOpDKrqfbBUQdhNHozAkGSuR in EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['channel']['image']:
       if EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIC0400':EnVytgCOpDKrqfbBUQdhNHozAkGSmv =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
       elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIC1400':EnVytgCOpDKrqfbBUQdhNHozAkGSmv =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
       elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIC1900':EnVytgCOpDKrqfbBUQdhNHozAkGSmv =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
    except:
     EnVytgCOpDKrqfbBUQdhNHozAkGSXI
    try:
     EnVytgCOpDKrqfbBUQdhNHozAkGSuT =[]
     EnVytgCOpDKrqfbBUQdhNHozAkGSum=[]
     EnVytgCOpDKrqfbBUQdhNHozAkGSuw =[]
     EnVytgCOpDKrqfbBUQdhNHozAkGSuX=''
     EnVytgCOpDKrqfbBUQdhNHozAkGSuc=''
     EnVytgCOpDKrqfbBUQdhNHozAkGSuF=''
     for EnVytgCOpDKrqfbBUQdhNHozAkGSul in EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('schedule').get('program').get('actor'):
      if EnVytgCOpDKrqfbBUQdhNHozAkGSul!='' and EnVytgCOpDKrqfbBUQdhNHozAkGSul!=u'없음':EnVytgCOpDKrqfbBUQdhNHozAkGSuT.append(EnVytgCOpDKrqfbBUQdhNHozAkGSul)
     for EnVytgCOpDKrqfbBUQdhNHozAkGSui in EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('schedule').get('program').get('director'):
      if EnVytgCOpDKrqfbBUQdhNHozAkGSui!='' and EnVytgCOpDKrqfbBUQdhNHozAkGSui!='-' and EnVytgCOpDKrqfbBUQdhNHozAkGSui!=u'없음':EnVytgCOpDKrqfbBUQdhNHozAkGSum.append(EnVytgCOpDKrqfbBUQdhNHozAkGSui)
     if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('schedule').get('program').get('category1_name').get('ko')!='':
      EnVytgCOpDKrqfbBUQdhNHozAkGSuw.append(EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['program']['category1_name']['ko'])
     if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('schedule').get('program').get('category2_name').get('ko')!='':
      EnVytgCOpDKrqfbBUQdhNHozAkGSuw.append(EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['program']['category2_name']['ko'])
     if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('schedule').get('program').get('product_year'):EnVytgCOpDKrqfbBUQdhNHozAkGSuX=EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['program']['product_year']
     if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('schedule').get('program').get('grade_code') :EnVytgCOpDKrqfbBUQdhNHozAkGSuc= EnVytgCOpDKrqfbBUQdhNHozAkGSRu.get(EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['program']['grade_code'])
     if 'broad_dt' in EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('schedule').get('program'):
      EnVytgCOpDKrqfbBUQdhNHozAkGSuI =EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('schedule').get('program').get('broad_dt')
      EnVytgCOpDKrqfbBUQdhNHozAkGSuF='%s-%s-%s'%(EnVytgCOpDKrqfbBUQdhNHozAkGSuI[:4],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[4:6],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[6:])
    except:
     EnVytgCOpDKrqfbBUQdhNHozAkGSXI
    EnVytgCOpDKrqfbBUQdhNHozAkGSmx=EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['broadcast_start_time'])[8:12]
    EnVytgCOpDKrqfbBUQdhNHozAkGSuY =EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSTs['schedule']['broadcast_end_time'])[8:12]
    EnVytgCOpDKrqfbBUQdhNHozAkGSuP={'channel':EnVytgCOpDKrqfbBUQdhNHozAkGSmP,'title':EnVytgCOpDKrqfbBUQdhNHozAkGSma,'mediacode':EnVytgCOpDKrqfbBUQdhNHozAkGSmW,'thumbnail':{'poster':EnVytgCOpDKrqfbBUQdhNHozAkGSms,'thumb':EnVytgCOpDKrqfbBUQdhNHozAkGSmv,'clearlogo':EnVytgCOpDKrqfbBUQdhNHozAkGSmM,'icon':EnVytgCOpDKrqfbBUQdhNHozAkGSme,'fanart':EnVytgCOpDKrqfbBUQdhNHozAkGSmj},'synopsis':EnVytgCOpDKrqfbBUQdhNHozAkGSmL,'channelepg':' [%s:%s ~ %s:%s]'%(EnVytgCOpDKrqfbBUQdhNHozAkGSmx[0:2],EnVytgCOpDKrqfbBUQdhNHozAkGSmx[2:],EnVytgCOpDKrqfbBUQdhNHozAkGSuY[0:2],EnVytgCOpDKrqfbBUQdhNHozAkGSuY[2:]),'cast':EnVytgCOpDKrqfbBUQdhNHozAkGSuT,'director':EnVytgCOpDKrqfbBUQdhNHozAkGSum,'info_genre':EnVytgCOpDKrqfbBUQdhNHozAkGSuw,'year':EnVytgCOpDKrqfbBUQdhNHozAkGSuX,'mpaa':EnVytgCOpDKrqfbBUQdhNHozAkGSuc,'premiered':EnVytgCOpDKrqfbBUQdhNHozAkGSuF}
    EnVytgCOpDKrqfbBUQdhNHozAkGSmF.append(EnVytgCOpDKrqfbBUQdhNHozAkGSuP)
   if EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']['has_more']=='Y':
    EnVytgCOpDKrqfbBUQdhNHozAkGSml=EnVytgCOpDKrqfbBUQdhNHozAkGSXW
   else:
    EnVytgCOpDKrqfbBUQdhNHozAkGSuP={'channel':'OCN Original','title':'temp','mediacode':'C01345','thumbnail':'http://image.tving.com/upload/cms/caic/CAIC0400/C01345.png','cast':[],'director':[]}
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSmF,EnVytgCOpDKrqfbBUQdhNHozAkGSml
 def GetProgramList(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,genre,orderby,page_int,genreCode='all'):
  EnVytgCOpDKrqfbBUQdhNHozAkGSmF=[]
  EnVytgCOpDKrqfbBUQdhNHozAkGSml=EnVytgCOpDKrqfbBUQdhNHozAkGSXY
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/v2/media/episodes'
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetDefaultParams()
   EnVytgCOpDKrqfbBUQdhNHozAkGSTP={'pageNo':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(page_int),'pageSize':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetNoCache(2))}
   if genre !='all':EnVytgCOpDKrqfbBUQdhNHozAkGSTP['categoryCode']=genre
   if genreCode!='all':EnVytgCOpDKrqfbBUQdhNHozAkGSTP['genreCode'] =genreCode 
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY.update(EnVytgCOpDKrqfbBUQdhNHozAkGSTP)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.API_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSTY,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSXI)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTW=json.loads(EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   if not('result' in EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']):return EnVytgCOpDKrqfbBUQdhNHozAkGSmF,EnVytgCOpDKrqfbBUQdhNHozAkGSml
   EnVytgCOpDKrqfbBUQdhNHozAkGSmY=EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']['result']
   for EnVytgCOpDKrqfbBUQdhNHozAkGSTs in EnVytgCOpDKrqfbBUQdhNHozAkGSmY:
    EnVytgCOpDKrqfbBUQdhNHozAkGSux=EnVytgCOpDKrqfbBUQdhNHozAkGSTs['program']['code']
    EnVytgCOpDKrqfbBUQdhNHozAkGSma =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['program']['name']['ko']
    EnVytgCOpDKrqfbBUQdhNHozAkGSuc =EnVytgCOpDKrqfbBUQdhNHozAkGSRu.get(EnVytgCOpDKrqfbBUQdhNHozAkGSTs['program'].get('grade_code'))
    EnVytgCOpDKrqfbBUQdhNHozAkGSms =''
    EnVytgCOpDKrqfbBUQdhNHozAkGSmv =''
    EnVytgCOpDKrqfbBUQdhNHozAkGSmM=''
    EnVytgCOpDKrqfbBUQdhNHozAkGSme =''
    EnVytgCOpDKrqfbBUQdhNHozAkGSmJ =''
    for EnVytgCOpDKrqfbBUQdhNHozAkGSuR in EnVytgCOpDKrqfbBUQdhNHozAkGSTs['program']['image']:
     if EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP0900':EnVytgCOpDKrqfbBUQdhNHozAkGSms =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
     elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP0200':EnVytgCOpDKrqfbBUQdhNHozAkGSmv =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
     elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP1800':EnVytgCOpDKrqfbBUQdhNHozAkGSmM=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
     elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP2000':EnVytgCOpDKrqfbBUQdhNHozAkGSme =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
     elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP1900':EnVytgCOpDKrqfbBUQdhNHozAkGSmJ =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
    EnVytgCOpDKrqfbBUQdhNHozAkGSmL =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['program']['synopsis']['ko']
    try:
     EnVytgCOpDKrqfbBUQdhNHozAkGSuW=EnVytgCOpDKrqfbBUQdhNHozAkGSTs['channel']['name']['ko']
    except:
     EnVytgCOpDKrqfbBUQdhNHozAkGSuW=''
    try:
     EnVytgCOpDKrqfbBUQdhNHozAkGSuT =[]
     EnVytgCOpDKrqfbBUQdhNHozAkGSum=[]
     EnVytgCOpDKrqfbBUQdhNHozAkGSuw =[]
     EnVytgCOpDKrqfbBUQdhNHozAkGSuX =''
     EnVytgCOpDKrqfbBUQdhNHozAkGSuF=''
     for EnVytgCOpDKrqfbBUQdhNHozAkGSul in EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('program').get('actor'):
      if EnVytgCOpDKrqfbBUQdhNHozAkGSul!='' and EnVytgCOpDKrqfbBUQdhNHozAkGSul!='-' and EnVytgCOpDKrqfbBUQdhNHozAkGSul!=u'없음':EnVytgCOpDKrqfbBUQdhNHozAkGSuT.append(EnVytgCOpDKrqfbBUQdhNHozAkGSul)
     for EnVytgCOpDKrqfbBUQdhNHozAkGSui in EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('program').get('director'):
      if EnVytgCOpDKrqfbBUQdhNHozAkGSui!='' and EnVytgCOpDKrqfbBUQdhNHozAkGSui!='-' and EnVytgCOpDKrqfbBUQdhNHozAkGSui!=u'없음':EnVytgCOpDKrqfbBUQdhNHozAkGSum.append(EnVytgCOpDKrqfbBUQdhNHozAkGSui)
     if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('program').get('category1_name').get('ko')!='':
      EnVytgCOpDKrqfbBUQdhNHozAkGSuw.append(EnVytgCOpDKrqfbBUQdhNHozAkGSTs['program']['category1_name']['ko'])
     if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('program').get('category2_name').get('ko')!='':
      EnVytgCOpDKrqfbBUQdhNHozAkGSuw.append(EnVytgCOpDKrqfbBUQdhNHozAkGSTs['program']['category2_name']['ko'])
     if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('program').get('product_year'):EnVytgCOpDKrqfbBUQdhNHozAkGSuX=EnVytgCOpDKrqfbBUQdhNHozAkGSTs['program']['product_year']
     if 'broad_dt' in EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('program'):
      EnVytgCOpDKrqfbBUQdhNHozAkGSuI =EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('program').get('broad_dt')
      EnVytgCOpDKrqfbBUQdhNHozAkGSuF='%s-%s-%s'%(EnVytgCOpDKrqfbBUQdhNHozAkGSuI[:4],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[4:6],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[6:])
    except:
     EnVytgCOpDKrqfbBUQdhNHozAkGSXI
    EnVytgCOpDKrqfbBUQdhNHozAkGSuP={'program':EnVytgCOpDKrqfbBUQdhNHozAkGSux,'title':EnVytgCOpDKrqfbBUQdhNHozAkGSma,'thumbnail':{'poster':EnVytgCOpDKrqfbBUQdhNHozAkGSms,'thumb':EnVytgCOpDKrqfbBUQdhNHozAkGSmv,'clearlogo':EnVytgCOpDKrqfbBUQdhNHozAkGSmM,'icon':EnVytgCOpDKrqfbBUQdhNHozAkGSme,'banner':EnVytgCOpDKrqfbBUQdhNHozAkGSmJ,'fanart':EnVytgCOpDKrqfbBUQdhNHozAkGSmv},'synopsis':EnVytgCOpDKrqfbBUQdhNHozAkGSmL,'channel':EnVytgCOpDKrqfbBUQdhNHozAkGSuW,'cast':EnVytgCOpDKrqfbBUQdhNHozAkGSuT,'director':EnVytgCOpDKrqfbBUQdhNHozAkGSum,'info_genre':EnVytgCOpDKrqfbBUQdhNHozAkGSuw,'year':EnVytgCOpDKrqfbBUQdhNHozAkGSuX,'premiered':EnVytgCOpDKrqfbBUQdhNHozAkGSuF,'mpaa':EnVytgCOpDKrqfbBUQdhNHozAkGSuc}
    EnVytgCOpDKrqfbBUQdhNHozAkGSmF.append(EnVytgCOpDKrqfbBUQdhNHozAkGSuP)
   if EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']['has_more']=='Y':EnVytgCOpDKrqfbBUQdhNHozAkGSml=EnVytgCOpDKrqfbBUQdhNHozAkGSXW
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSmF,EnVytgCOpDKrqfbBUQdhNHozAkGSml
 def GetEpisodeList(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,program_code,page_int,orderby='desc'):
  EnVytgCOpDKrqfbBUQdhNHozAkGSmF=[]
  EnVytgCOpDKrqfbBUQdhNHozAkGSml=EnVytgCOpDKrqfbBUQdhNHozAkGSXY
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/v2/media/frequency/program/'+program_code
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetDefaultParams()
   EnVytgCOpDKrqfbBUQdhNHozAkGSTP={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetNoCache(2))}
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY.update(EnVytgCOpDKrqfbBUQdhNHozAkGSTP)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.API_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSTY,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSXI)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTW=json.loads(EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   if not('result' in EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']):return EnVytgCOpDKrqfbBUQdhNHozAkGSmF,EnVytgCOpDKrqfbBUQdhNHozAkGSml
   EnVytgCOpDKrqfbBUQdhNHozAkGSmY=EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']['result']
   EnVytgCOpDKrqfbBUQdhNHozAkGSua=EnVytgCOpDKrqfbBUQdhNHozAkGSXP(EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']['total_count'])
   EnVytgCOpDKrqfbBUQdhNHozAkGSuL =EnVytgCOpDKrqfbBUQdhNHozAkGSXP(EnVytgCOpDKrqfbBUQdhNHozAkGSua//(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    EnVytgCOpDKrqfbBUQdhNHozAkGSuv =(EnVytgCOpDKrqfbBUQdhNHozAkGSua-1)-((page_int-1)*EnVytgCOpDKrqfbBUQdhNHozAkGSRw.EPISODE_LIMIT)
   else:
    EnVytgCOpDKrqfbBUQdhNHozAkGSuv =(page_int-1)*EnVytgCOpDKrqfbBUQdhNHozAkGSRw.EPISODE_LIMIT
   for i in EnVytgCOpDKrqfbBUQdhNHozAkGSXx(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.EPISODE_LIMIT):
    if orderby=='desc':
     EnVytgCOpDKrqfbBUQdhNHozAkGSus=EnVytgCOpDKrqfbBUQdhNHozAkGSuv-i
     if EnVytgCOpDKrqfbBUQdhNHozAkGSus<0:break
    else:
     EnVytgCOpDKrqfbBUQdhNHozAkGSus=EnVytgCOpDKrqfbBUQdhNHozAkGSuv+i
     if EnVytgCOpDKrqfbBUQdhNHozAkGSus>=EnVytgCOpDKrqfbBUQdhNHozAkGSua:break
    EnVytgCOpDKrqfbBUQdhNHozAkGSuM=EnVytgCOpDKrqfbBUQdhNHozAkGSmY[EnVytgCOpDKrqfbBUQdhNHozAkGSus]['episode']['code']
    EnVytgCOpDKrqfbBUQdhNHozAkGSma =EnVytgCOpDKrqfbBUQdhNHozAkGSmY[EnVytgCOpDKrqfbBUQdhNHozAkGSus]['vod_name']['ko']
    EnVytgCOpDKrqfbBUQdhNHozAkGSue =''
    try:
     EnVytgCOpDKrqfbBUQdhNHozAkGSuI=EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSmY[EnVytgCOpDKrqfbBUQdhNHozAkGSus]['episode']['broadcast_date'])
     EnVytgCOpDKrqfbBUQdhNHozAkGSue='%s-%s-%s'%(EnVytgCOpDKrqfbBUQdhNHozAkGSuI[:4],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[4:6],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[6:])
    except:
     EnVytgCOpDKrqfbBUQdhNHozAkGSXI
    try:
     if EnVytgCOpDKrqfbBUQdhNHozAkGSmY[EnVytgCOpDKrqfbBUQdhNHozAkGSus]['episode']['pip_cliptype']=='C012':
      EnVytgCOpDKrqfbBUQdhNHozAkGSue+=' - Quick VOD'
    except:
     EnVytgCOpDKrqfbBUQdhNHozAkGSXI
    EnVytgCOpDKrqfbBUQdhNHozAkGSmL =EnVytgCOpDKrqfbBUQdhNHozAkGSmY[EnVytgCOpDKrqfbBUQdhNHozAkGSus]['episode']['synopsis']['ko']
    EnVytgCOpDKrqfbBUQdhNHozAkGSms =''
    EnVytgCOpDKrqfbBUQdhNHozAkGSmv =''
    EnVytgCOpDKrqfbBUQdhNHozAkGSmM=''
    EnVytgCOpDKrqfbBUQdhNHozAkGSme =''
    EnVytgCOpDKrqfbBUQdhNHozAkGSmJ =''
    EnVytgCOpDKrqfbBUQdhNHozAkGSmj =''
    for EnVytgCOpDKrqfbBUQdhNHozAkGSuR in EnVytgCOpDKrqfbBUQdhNHozAkGSmY[EnVytgCOpDKrqfbBUQdhNHozAkGSus]['program']['image']:
     if EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP0900':EnVytgCOpDKrqfbBUQdhNHozAkGSms =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
     elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP1800':EnVytgCOpDKrqfbBUQdhNHozAkGSmM=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
     elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP2000':EnVytgCOpDKrqfbBUQdhNHozAkGSme =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
     elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP1900':EnVytgCOpDKrqfbBUQdhNHozAkGSmJ =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
     elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIP0200':EnVytgCOpDKrqfbBUQdhNHozAkGSmj =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
    for EnVytgCOpDKrqfbBUQdhNHozAkGSuR in EnVytgCOpDKrqfbBUQdhNHozAkGSmY[EnVytgCOpDKrqfbBUQdhNHozAkGSus]['episode']['image']:
     if EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIE0400':EnVytgCOpDKrqfbBUQdhNHozAkGSmv =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
    try:
     EnVytgCOpDKrqfbBUQdhNHozAkGSuJ=EnVytgCOpDKrqfbBUQdhNHozAkGSwR=EnVytgCOpDKrqfbBUQdhNHozAkGSwT=''
     EnVytgCOpDKrqfbBUQdhNHozAkGSuj=0
     EnVytgCOpDKrqfbBUQdhNHozAkGSuJ =EnVytgCOpDKrqfbBUQdhNHozAkGSmY[EnVytgCOpDKrqfbBUQdhNHozAkGSus]['program']['name']['ko']
     EnVytgCOpDKrqfbBUQdhNHozAkGSwR =EnVytgCOpDKrqfbBUQdhNHozAkGSue
     EnVytgCOpDKrqfbBUQdhNHozAkGSwT =EnVytgCOpDKrqfbBUQdhNHozAkGSmY[EnVytgCOpDKrqfbBUQdhNHozAkGSus]['channel']['name']['ko']
     if 'frequency' in EnVytgCOpDKrqfbBUQdhNHozAkGSmY[EnVytgCOpDKrqfbBUQdhNHozAkGSus]['episode']:EnVytgCOpDKrqfbBUQdhNHozAkGSuj=EnVytgCOpDKrqfbBUQdhNHozAkGSmY[EnVytgCOpDKrqfbBUQdhNHozAkGSus]['episode']['frequency']
    except:
     EnVytgCOpDKrqfbBUQdhNHozAkGSXI
    EnVytgCOpDKrqfbBUQdhNHozAkGSuP={'episode':EnVytgCOpDKrqfbBUQdhNHozAkGSuM,'title':EnVytgCOpDKrqfbBUQdhNHozAkGSma,'subtitle':EnVytgCOpDKrqfbBUQdhNHozAkGSue,'thumbnail':{'poster':EnVytgCOpDKrqfbBUQdhNHozAkGSms,'thumb':EnVytgCOpDKrqfbBUQdhNHozAkGSmv,'clearlogo':EnVytgCOpDKrqfbBUQdhNHozAkGSmM,'icon':EnVytgCOpDKrqfbBUQdhNHozAkGSme,'banner':EnVytgCOpDKrqfbBUQdhNHozAkGSmJ,'fanart':EnVytgCOpDKrqfbBUQdhNHozAkGSmj},'synopsis':EnVytgCOpDKrqfbBUQdhNHozAkGSmL,'info_title':EnVytgCOpDKrqfbBUQdhNHozAkGSuJ,'aired':EnVytgCOpDKrqfbBUQdhNHozAkGSwR,'studio':EnVytgCOpDKrqfbBUQdhNHozAkGSwT,'frequency':EnVytgCOpDKrqfbBUQdhNHozAkGSuj}
    EnVytgCOpDKrqfbBUQdhNHozAkGSmF.append(EnVytgCOpDKrqfbBUQdhNHozAkGSuP)
   if EnVytgCOpDKrqfbBUQdhNHozAkGSuL>page_int:EnVytgCOpDKrqfbBUQdhNHozAkGSml=EnVytgCOpDKrqfbBUQdhNHozAkGSXW
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSmF,EnVytgCOpDKrqfbBUQdhNHozAkGSml,EnVytgCOpDKrqfbBUQdhNHozAkGSuL
 def GetMovieList(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,genre,orderby,page_int):
  EnVytgCOpDKrqfbBUQdhNHozAkGSmF=[]
  EnVytgCOpDKrqfbBUQdhNHozAkGSml=EnVytgCOpDKrqfbBUQdhNHozAkGSXY
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/v2/media/movies'
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetDefaultParams()
   EnVytgCOpDKrqfbBUQdhNHozAkGSTP={'pageNo':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(page_int),'pageSize':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetNoCache(2))}
   if genre!='all' :EnVytgCOpDKrqfbBUQdhNHozAkGSTP['multiCategoryCode']=genre
   EnVytgCOpDKrqfbBUQdhNHozAkGSTP['productPackageCode']=','.join(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.MOVIE_LITE)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY.update(EnVytgCOpDKrqfbBUQdhNHozAkGSTP)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.API_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSTY,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSXI)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTW=json.loads(EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   if not('result' in EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']):return EnVytgCOpDKrqfbBUQdhNHozAkGSmF,EnVytgCOpDKrqfbBUQdhNHozAkGSml
   EnVytgCOpDKrqfbBUQdhNHozAkGSmY=EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']['result']
   for EnVytgCOpDKrqfbBUQdhNHozAkGSTs in EnVytgCOpDKrqfbBUQdhNHozAkGSmY:
    EnVytgCOpDKrqfbBUQdhNHozAkGSwm =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['movie']['code']
    EnVytgCOpDKrqfbBUQdhNHozAkGSma =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['movie']['name']['ko'].strip()
    EnVytgCOpDKrqfbBUQdhNHozAkGSma +=u' (%s)'%(EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('movie').get('product_year'))
    EnVytgCOpDKrqfbBUQdhNHozAkGSms=''
    EnVytgCOpDKrqfbBUQdhNHozAkGSmv =''
    EnVytgCOpDKrqfbBUQdhNHozAkGSmM=''
    for EnVytgCOpDKrqfbBUQdhNHozAkGSuR in EnVytgCOpDKrqfbBUQdhNHozAkGSTs['movie']['image']:
     if EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIM2100':EnVytgCOpDKrqfbBUQdhNHozAkGSms =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
     elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIM0400':EnVytgCOpDKrqfbBUQdhNHozAkGSmv =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
     elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIM1800':EnVytgCOpDKrqfbBUQdhNHozAkGSmM=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
    EnVytgCOpDKrqfbBUQdhNHozAkGSmL =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['movie']['story']['ko']
    try:
     EnVytgCOpDKrqfbBUQdhNHozAkGSuJ =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['movie']['name']['ko'].strip()
     EnVytgCOpDKrqfbBUQdhNHozAkGSuX =EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('movie').get('product_year')
     EnVytgCOpDKrqfbBUQdhNHozAkGSuc =EnVytgCOpDKrqfbBUQdhNHozAkGSRu.get(EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('grade_code'))
     EnVytgCOpDKrqfbBUQdhNHozAkGSuT=[]
     EnVytgCOpDKrqfbBUQdhNHozAkGSum=[]
     EnVytgCOpDKrqfbBUQdhNHozAkGSuw=[]
     EnVytgCOpDKrqfbBUQdhNHozAkGSwu=0
     EnVytgCOpDKrqfbBUQdhNHozAkGSuF=''
     EnVytgCOpDKrqfbBUQdhNHozAkGSwT =''
     for EnVytgCOpDKrqfbBUQdhNHozAkGSul in EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('movie').get('actor'):
      if EnVytgCOpDKrqfbBUQdhNHozAkGSul!='':EnVytgCOpDKrqfbBUQdhNHozAkGSuT.append(EnVytgCOpDKrqfbBUQdhNHozAkGSul)
     for EnVytgCOpDKrqfbBUQdhNHozAkGSui in EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('movie').get('director'):
      if EnVytgCOpDKrqfbBUQdhNHozAkGSui!='':EnVytgCOpDKrqfbBUQdhNHozAkGSum.append(EnVytgCOpDKrqfbBUQdhNHozAkGSui)
     if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('movie').get('category1_name').get('ko')!='':
      EnVytgCOpDKrqfbBUQdhNHozAkGSuw.append(EnVytgCOpDKrqfbBUQdhNHozAkGSTs['movie']['category1_name']['ko'])
     if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('movie').get('category2_name').get('ko')!='':
      EnVytgCOpDKrqfbBUQdhNHozAkGSuw.append(EnVytgCOpDKrqfbBUQdhNHozAkGSTs['movie']['category2_name']['ko'])
     if 'duration' in EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('movie'):EnVytgCOpDKrqfbBUQdhNHozAkGSwu=EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('movie').get('duration')
     if 'release_date' in EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('movie'):
      EnVytgCOpDKrqfbBUQdhNHozAkGSuI=EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('movie').get('release_date'))
      if EnVytgCOpDKrqfbBUQdhNHozAkGSuI!='0':EnVytgCOpDKrqfbBUQdhNHozAkGSuF='%s-%s-%s'%(EnVytgCOpDKrqfbBUQdhNHozAkGSuI[:4],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[4:6],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[6:])
     if 'production' in EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('movie'):EnVytgCOpDKrqfbBUQdhNHozAkGSwT=EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('movie').get('production')
    except:
     EnVytgCOpDKrqfbBUQdhNHozAkGSXI
    EnVytgCOpDKrqfbBUQdhNHozAkGSuP={'moviecode':EnVytgCOpDKrqfbBUQdhNHozAkGSwm,'title':EnVytgCOpDKrqfbBUQdhNHozAkGSma,'thumbnail':{'poster':EnVytgCOpDKrqfbBUQdhNHozAkGSms,'thumb':EnVytgCOpDKrqfbBUQdhNHozAkGSmv,'clearlogo':EnVytgCOpDKrqfbBUQdhNHozAkGSmM,'fanart':EnVytgCOpDKrqfbBUQdhNHozAkGSmv},'synopsis':EnVytgCOpDKrqfbBUQdhNHozAkGSmL,'info_title':EnVytgCOpDKrqfbBUQdhNHozAkGSuJ,'year':EnVytgCOpDKrqfbBUQdhNHozAkGSuX,'cast':EnVytgCOpDKrqfbBUQdhNHozAkGSuT,'director':EnVytgCOpDKrqfbBUQdhNHozAkGSum,'info_genre':EnVytgCOpDKrqfbBUQdhNHozAkGSuw,'duration':EnVytgCOpDKrqfbBUQdhNHozAkGSwu,'premiered':EnVytgCOpDKrqfbBUQdhNHozAkGSuF,'studio':EnVytgCOpDKrqfbBUQdhNHozAkGSwT,'mpaa':EnVytgCOpDKrqfbBUQdhNHozAkGSuc}
    EnVytgCOpDKrqfbBUQdhNHozAkGSwX=EnVytgCOpDKrqfbBUQdhNHozAkGSXY
    for EnVytgCOpDKrqfbBUQdhNHozAkGSwc in EnVytgCOpDKrqfbBUQdhNHozAkGSTs['billing_package_id']:
     if EnVytgCOpDKrqfbBUQdhNHozAkGSwc in EnVytgCOpDKrqfbBUQdhNHozAkGSRw.MOVIE_LITE:
      EnVytgCOpDKrqfbBUQdhNHozAkGSwX=EnVytgCOpDKrqfbBUQdhNHozAkGSXW
      break
    if EnVytgCOpDKrqfbBUQdhNHozAkGSwX==EnVytgCOpDKrqfbBUQdhNHozAkGSXY: 
     EnVytgCOpDKrqfbBUQdhNHozAkGSuP['title']=EnVytgCOpDKrqfbBUQdhNHozAkGSuP['title']+' [개별구매]'
    EnVytgCOpDKrqfbBUQdhNHozAkGSmF.append(EnVytgCOpDKrqfbBUQdhNHozAkGSuP)
   if EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']['has_more']=='Y':EnVytgCOpDKrqfbBUQdhNHozAkGSml=EnVytgCOpDKrqfbBUQdhNHozAkGSXW
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSmF,EnVytgCOpDKrqfbBUQdhNHozAkGSml
 def GetMovieListGenre(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,genre,page_int):
  EnVytgCOpDKrqfbBUQdhNHozAkGSmF=[]
  EnVytgCOpDKrqfbBUQdhNHozAkGSml=EnVytgCOpDKrqfbBUQdhNHozAkGSXY
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/v2/media/movie/curation/'+genre
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetDefaultParams()
   EnVytgCOpDKrqfbBUQdhNHozAkGSTP={'pageNo':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(page_int),'pageSize':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.MOVIE_LIMIT),'_':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetNoCache(2))}
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY.update(EnVytgCOpDKrqfbBUQdhNHozAkGSTP)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.API_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSTY,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSXI)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTW=json.loads(EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   if not('movies' in EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']):return EnVytgCOpDKrqfbBUQdhNHozAkGSmF,EnVytgCOpDKrqfbBUQdhNHozAkGSml
   EnVytgCOpDKrqfbBUQdhNHozAkGSmY=EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']['movies']
   for EnVytgCOpDKrqfbBUQdhNHozAkGSTs in EnVytgCOpDKrqfbBUQdhNHozAkGSmY:
    EnVytgCOpDKrqfbBUQdhNHozAkGSwm =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['code']
    EnVytgCOpDKrqfbBUQdhNHozAkGSma =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['name']['ko']
    EnVytgCOpDKrqfbBUQdhNHozAkGSwF =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTs['image'][0]['url']
    for EnVytgCOpDKrqfbBUQdhNHozAkGSuR in EnVytgCOpDKrqfbBUQdhNHozAkGSTs['image']:
     if EnVytgCOpDKrqfbBUQdhNHozAkGSuR['code']=='CAIM2100':
      EnVytgCOpDKrqfbBUQdhNHozAkGSwF =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR['url']
    EnVytgCOpDKrqfbBUQdhNHozAkGSmL =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['story']['ko']
    EnVytgCOpDKrqfbBUQdhNHozAkGSuP={'moviecode':EnVytgCOpDKrqfbBUQdhNHozAkGSwm,'title':EnVytgCOpDKrqfbBUQdhNHozAkGSma.strip(),'thumbnail':EnVytgCOpDKrqfbBUQdhNHozAkGSwF,'synopsis':EnVytgCOpDKrqfbBUQdhNHozAkGSmL}
    EnVytgCOpDKrqfbBUQdhNHozAkGSmF.append(EnVytgCOpDKrqfbBUQdhNHozAkGSuP)
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSmF,EnVytgCOpDKrqfbBUQdhNHozAkGSml
 def GetMovieGenre(EnVytgCOpDKrqfbBUQdhNHozAkGSRw):
  EnVytgCOpDKrqfbBUQdhNHozAkGSmF=[]
  EnVytgCOpDKrqfbBUQdhNHozAkGSml=EnVytgCOpDKrqfbBUQdhNHozAkGSXY
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/v2/media/movie/curations'
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetDefaultParams()
   EnVytgCOpDKrqfbBUQdhNHozAkGSTP={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetNoCache(2))}
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY.update(EnVytgCOpDKrqfbBUQdhNHozAkGSTP)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.API_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSTY,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSXI)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTW=json.loads(EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   if not('result' in EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']):return EnVytgCOpDKrqfbBUQdhNHozAkGSmF,EnVytgCOpDKrqfbBUQdhNHozAkGSml
   EnVytgCOpDKrqfbBUQdhNHozAkGSmY=EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']['result']
   for EnVytgCOpDKrqfbBUQdhNHozAkGSTs in EnVytgCOpDKrqfbBUQdhNHozAkGSmY:
    EnVytgCOpDKrqfbBUQdhNHozAkGSwl =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['curation_code']
    EnVytgCOpDKrqfbBUQdhNHozAkGSwi =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['curation_name']
    EnVytgCOpDKrqfbBUQdhNHozAkGSuP={'curation_code':EnVytgCOpDKrqfbBUQdhNHozAkGSwl,'curation_name':EnVytgCOpDKrqfbBUQdhNHozAkGSwi}
    EnVytgCOpDKrqfbBUQdhNHozAkGSmF.append(EnVytgCOpDKrqfbBUQdhNHozAkGSuP)
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSmF,EnVytgCOpDKrqfbBUQdhNHozAkGSml
 def GetSearchList(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,search_key,page_int,stype):
  EnVytgCOpDKrqfbBUQdhNHozAkGSwI=[]
  EnVytgCOpDKrqfbBUQdhNHozAkGSml=EnVytgCOpDKrqfbBUQdhNHozAkGSXY
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/search/getSearch.jsp'
   EnVytgCOpDKrqfbBUQdhNHozAkGSTP={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(page_int),'pageSize':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.SCREENCODE,'os':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.OSCODE,'network':EnVytgCOpDKrqfbBUQdhNHozAkGSRw.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetNoCache(2))}
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.SEARCH_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSTP,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSXI)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTW=json.loads(EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   if stype=='vod':
    if not('programRsb' in EnVytgCOpDKrqfbBUQdhNHozAkGSTW):return EnVytgCOpDKrqfbBUQdhNHozAkGSwI,EnVytgCOpDKrqfbBUQdhNHozAkGSml
    EnVytgCOpDKrqfbBUQdhNHozAkGSwY=EnVytgCOpDKrqfbBUQdhNHozAkGSTW['programRsb']['dataList']
    EnVytgCOpDKrqfbBUQdhNHozAkGSwP =EnVytgCOpDKrqfbBUQdhNHozAkGSXP(EnVytgCOpDKrqfbBUQdhNHozAkGSTW['programRsb']['count'])
    for EnVytgCOpDKrqfbBUQdhNHozAkGSTs in EnVytgCOpDKrqfbBUQdhNHozAkGSwY:
     EnVytgCOpDKrqfbBUQdhNHozAkGSux=EnVytgCOpDKrqfbBUQdhNHozAkGSTs['mast_cd']
     EnVytgCOpDKrqfbBUQdhNHozAkGSma =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['mast_nm']
     EnVytgCOpDKrqfbBUQdhNHozAkGSms=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTs['web_url4']
     EnVytgCOpDKrqfbBUQdhNHozAkGSmv =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTs['web_url']
     try:
      EnVytgCOpDKrqfbBUQdhNHozAkGSuT =[]
      EnVytgCOpDKrqfbBUQdhNHozAkGSum=[]
      EnVytgCOpDKrqfbBUQdhNHozAkGSuw =[]
      EnVytgCOpDKrqfbBUQdhNHozAkGSwu =0
      EnVytgCOpDKrqfbBUQdhNHozAkGSuc =''
      EnVytgCOpDKrqfbBUQdhNHozAkGSuX =''
      EnVytgCOpDKrqfbBUQdhNHozAkGSwR =''
      if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('actor') !='' and EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('actor') !='-':EnVytgCOpDKrqfbBUQdhNHozAkGSuT =EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('actor').split(',')
      if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('director')!='' and EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('director')!='-':EnVytgCOpDKrqfbBUQdhNHozAkGSum=EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('director').split(',')
      if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('cate_nm')!='' and EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('cate_nm')!='-':EnVytgCOpDKrqfbBUQdhNHozAkGSuw =EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('cate_nm').split('/')
      if 'targetage' in EnVytgCOpDKrqfbBUQdhNHozAkGSTs:EnVytgCOpDKrqfbBUQdhNHozAkGSuc=EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('targetage')
      if 'broad_dt' in EnVytgCOpDKrqfbBUQdhNHozAkGSTs:
       EnVytgCOpDKrqfbBUQdhNHozAkGSuI=EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('broad_dt')
       EnVytgCOpDKrqfbBUQdhNHozAkGSwR='%s-%s-%s'%(EnVytgCOpDKrqfbBUQdhNHozAkGSuI[:4],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[4:6],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[6:])
       EnVytgCOpDKrqfbBUQdhNHozAkGSuX =EnVytgCOpDKrqfbBUQdhNHozAkGSuI[:4]
     except:
      EnVytgCOpDKrqfbBUQdhNHozAkGSXI
     EnVytgCOpDKrqfbBUQdhNHozAkGSuP={'program':EnVytgCOpDKrqfbBUQdhNHozAkGSux,'title':EnVytgCOpDKrqfbBUQdhNHozAkGSma,'thumbnail':{'poster':EnVytgCOpDKrqfbBUQdhNHozAkGSms,'thumb':EnVytgCOpDKrqfbBUQdhNHozAkGSmv,'fanart':EnVytgCOpDKrqfbBUQdhNHozAkGSmv},'synopsis':'','cast':EnVytgCOpDKrqfbBUQdhNHozAkGSuT,'director':EnVytgCOpDKrqfbBUQdhNHozAkGSum,'info_genre':EnVytgCOpDKrqfbBUQdhNHozAkGSuw,'duration':EnVytgCOpDKrqfbBUQdhNHozAkGSwu,'mpaa':EnVytgCOpDKrqfbBUQdhNHozAkGSuc,'year':EnVytgCOpDKrqfbBUQdhNHozAkGSuX,'aired':EnVytgCOpDKrqfbBUQdhNHozAkGSwR}
     EnVytgCOpDKrqfbBUQdhNHozAkGSwI.append(EnVytgCOpDKrqfbBUQdhNHozAkGSuP)
   else:
    if not('vodMVRsb' in EnVytgCOpDKrqfbBUQdhNHozAkGSTW):return EnVytgCOpDKrqfbBUQdhNHozAkGSwI,EnVytgCOpDKrqfbBUQdhNHozAkGSml
    EnVytgCOpDKrqfbBUQdhNHozAkGSwx=EnVytgCOpDKrqfbBUQdhNHozAkGSTW['vodMVRsb']['dataList']
    EnVytgCOpDKrqfbBUQdhNHozAkGSwP =EnVytgCOpDKrqfbBUQdhNHozAkGSXP(EnVytgCOpDKrqfbBUQdhNHozAkGSTW['vodMVRsb']['count'])
    for EnVytgCOpDKrqfbBUQdhNHozAkGSTs in EnVytgCOpDKrqfbBUQdhNHozAkGSwx:
     EnVytgCOpDKrqfbBUQdhNHozAkGSux=EnVytgCOpDKrqfbBUQdhNHozAkGSTs['mast_cd']
     EnVytgCOpDKrqfbBUQdhNHozAkGSma =EnVytgCOpDKrqfbBUQdhNHozAkGSTs['mast_nm'].strip()
     EnVytgCOpDKrqfbBUQdhNHozAkGSms =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTs['web_url']
     EnVytgCOpDKrqfbBUQdhNHozAkGSmv =EnVytgCOpDKrqfbBUQdhNHozAkGSms
     EnVytgCOpDKrqfbBUQdhNHozAkGSmM=''
     try:
      EnVytgCOpDKrqfbBUQdhNHozAkGSuT =[]
      EnVytgCOpDKrqfbBUQdhNHozAkGSum=[]
      EnVytgCOpDKrqfbBUQdhNHozAkGSuw =[]
      EnVytgCOpDKrqfbBUQdhNHozAkGSwu =0
      EnVytgCOpDKrqfbBUQdhNHozAkGSuc =''
      EnVytgCOpDKrqfbBUQdhNHozAkGSuX =''
      EnVytgCOpDKrqfbBUQdhNHozAkGSwR =''
      if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('actor') !='' and EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('actor') !='-':EnVytgCOpDKrqfbBUQdhNHozAkGSuT =EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('actor').split(',')
      if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('director')!='' and EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('director')!='-':EnVytgCOpDKrqfbBUQdhNHozAkGSum=EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('director').split(',')
      if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('cate_nm')!='' and EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('cate_nm')!='-':EnVytgCOpDKrqfbBUQdhNHozAkGSuw =EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('cate_nm').split('/')
      if EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('runtime_sec')!='':EnVytgCOpDKrqfbBUQdhNHozAkGSwu=EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('runtime_sec')
      if 'grade_nm' in EnVytgCOpDKrqfbBUQdhNHozAkGSTs:EnVytgCOpDKrqfbBUQdhNHozAkGSuc=EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('grade_nm')
      EnVytgCOpDKrqfbBUQdhNHozAkGSuI=EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('broad_dt')
      if data_str!='':
       EnVytgCOpDKrqfbBUQdhNHozAkGSwR='%s-%s-%s'%(EnVytgCOpDKrqfbBUQdhNHozAkGSuI[:4],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[4:6],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[6:])
       EnVytgCOpDKrqfbBUQdhNHozAkGSuX =EnVytgCOpDKrqfbBUQdhNHozAkGSuI[:4]
     except:
      EnVytgCOpDKrqfbBUQdhNHozAkGSXI
     EnVytgCOpDKrqfbBUQdhNHozAkGSuP={'movie':EnVytgCOpDKrqfbBUQdhNHozAkGSux,'title':EnVytgCOpDKrqfbBUQdhNHozAkGSma,'thumbnail':{'poster':EnVytgCOpDKrqfbBUQdhNHozAkGSms,'thumb':EnVytgCOpDKrqfbBUQdhNHozAkGSmv,'fanart':EnVytgCOpDKrqfbBUQdhNHozAkGSmv,'clearlogo':EnVytgCOpDKrqfbBUQdhNHozAkGSmM},'synopsis':'','cast':EnVytgCOpDKrqfbBUQdhNHozAkGSuT,'director':EnVytgCOpDKrqfbBUQdhNHozAkGSum,'info_genre':EnVytgCOpDKrqfbBUQdhNHozAkGSuw,'duration':EnVytgCOpDKrqfbBUQdhNHozAkGSwu,'mpaa':EnVytgCOpDKrqfbBUQdhNHozAkGSuc,'year':EnVytgCOpDKrqfbBUQdhNHozAkGSuX,'aired':EnVytgCOpDKrqfbBUQdhNHozAkGSwR}
     EnVytgCOpDKrqfbBUQdhNHozAkGSwX=EnVytgCOpDKrqfbBUQdhNHozAkGSXY
     for EnVytgCOpDKrqfbBUQdhNHozAkGSwc in EnVytgCOpDKrqfbBUQdhNHozAkGSTs['bill']:
      if EnVytgCOpDKrqfbBUQdhNHozAkGSwc in EnVytgCOpDKrqfbBUQdhNHozAkGSRw.MOVIE_LITE:
       EnVytgCOpDKrqfbBUQdhNHozAkGSwX=EnVytgCOpDKrqfbBUQdhNHozAkGSXW
       break
     if EnVytgCOpDKrqfbBUQdhNHozAkGSwX==EnVytgCOpDKrqfbBUQdhNHozAkGSXY: 
      EnVytgCOpDKrqfbBUQdhNHozAkGSuP['title']=EnVytgCOpDKrqfbBUQdhNHozAkGSuP['title']+' [개별구매]'
     EnVytgCOpDKrqfbBUQdhNHozAkGSwI.append(EnVytgCOpDKrqfbBUQdhNHozAkGSuP)
   if EnVytgCOpDKrqfbBUQdhNHozAkGSwP>(page_int*EnVytgCOpDKrqfbBUQdhNHozAkGSRw.SEARCH_LIMIT):EnVytgCOpDKrqfbBUQdhNHozAkGSml=EnVytgCOpDKrqfbBUQdhNHozAkGSXW
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSwI,EnVytgCOpDKrqfbBUQdhNHozAkGSml
 def GetDeviceList(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,EnVytgCOpDKrqfbBUQdhNHozAkGSTR,EnVytgCOpDKrqfbBUQdhNHozAkGSTm):
  EnVytgCOpDKrqfbBUQdhNHozAkGSmF=[]
  EnVytgCOpDKrqfbBUQdhNHozAkGSTl='-'
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/v1/user/device/list'
   EnVytgCOpDKrqfbBUQdhNHozAkGSwW=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.API_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSTP={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   EnVytgCOpDKrqfbBUQdhNHozAkGSRF=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.makeDefaultCookies(vToken=EnVytgCOpDKrqfbBUQdhNHozAkGSTR,vUserinfo=EnVytgCOpDKrqfbBUQdhNHozAkGSTm)
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSwW,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSTP,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSRF)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTW=json.loads(EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   EnVytgCOpDKrqfbBUQdhNHozAkGSmF=EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']
   for EnVytgCOpDKrqfbBUQdhNHozAkGSTs in EnVytgCOpDKrqfbBUQdhNHozAkGSmF:
    if EnVytgCOpDKrqfbBUQdhNHozAkGSTs['model']=='PC':
     EnVytgCOpDKrqfbBUQdhNHozAkGSTl=EnVytgCOpDKrqfbBUQdhNHozAkGSTs['uuid']
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSTl
 def GetProfileToken(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,EnVytgCOpDKrqfbBUQdhNHozAkGSTR,EnVytgCOpDKrqfbBUQdhNHozAkGSTm,user_pf):
  EnVytgCOpDKrqfbBUQdhNHozAkGSwa=[]
  EnVytgCOpDKrqfbBUQdhNHozAkGSwL =''
  EnVytgCOpDKrqfbBUQdhNHozAkGSwv =''
  EnVytgCOpDKrqfbBUQdhNHozAkGSws='Y'
  EnVytgCOpDKrqfbBUQdhNHozAkGSwM ='N'
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/profile/select.do'
   EnVytgCOpDKrqfbBUQdhNHozAkGSwW=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.URL_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSRF=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.makeDefaultCookies(vToken=EnVytgCOpDKrqfbBUQdhNHozAkGSTR,vUserinfo=EnVytgCOpDKrqfbBUQdhNHozAkGSTm)
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSwW,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSRF)
   EnVytgCOpDKrqfbBUQdhNHozAkGSwa =re.findall('data-profile-no="\d+"',EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   for i in EnVytgCOpDKrqfbBUQdhNHozAkGSXx(EnVytgCOpDKrqfbBUQdhNHozAkGSXM(EnVytgCOpDKrqfbBUQdhNHozAkGSwa)):
    EnVytgCOpDKrqfbBUQdhNHozAkGSwe =EnVytgCOpDKrqfbBUQdhNHozAkGSwa[i].replace('data-profile-no=','').replace('"','')
    EnVytgCOpDKrqfbBUQdhNHozAkGSwa[i]=EnVytgCOpDKrqfbBUQdhNHozAkGSwe
   EnVytgCOpDKrqfbBUQdhNHozAkGSwL=EnVytgCOpDKrqfbBUQdhNHozAkGSwa[user_pf]
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
   return EnVytgCOpDKrqfbBUQdhNHozAkGSwv,EnVytgCOpDKrqfbBUQdhNHozAkGSws,EnVytgCOpDKrqfbBUQdhNHozAkGSwM
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/profile/api/select.do'
   EnVytgCOpDKrqfbBUQdhNHozAkGSwW=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.URL_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSRF=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.makeDefaultCookies(vToken=EnVytgCOpDKrqfbBUQdhNHozAkGSTR,vUserinfo=EnVytgCOpDKrqfbBUQdhNHozAkGSTm)
   EnVytgCOpDKrqfbBUQdhNHozAkGSRe={'profileNo':EnVytgCOpDKrqfbBUQdhNHozAkGSwL}
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Post',EnVytgCOpDKrqfbBUQdhNHozAkGSwW,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSRe,params=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSRF)
   for EnVytgCOpDKrqfbBUQdhNHozAkGSRj in EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.cookies:
    if EnVytgCOpDKrqfbBUQdhNHozAkGSRj.name=='_tving_token':
     EnVytgCOpDKrqfbBUQdhNHozAkGSwv=EnVytgCOpDKrqfbBUQdhNHozAkGSRj.value
    elif EnVytgCOpDKrqfbBUQdhNHozAkGSRj.name==EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GLOBAL_COOKIENM['tv_cookiekey']:
     EnVytgCOpDKrqfbBUQdhNHozAkGSws=EnVytgCOpDKrqfbBUQdhNHozAkGSRj.value
    elif EnVytgCOpDKrqfbBUQdhNHozAkGSRj.name==EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GLOBAL_COOKIENM['tv_lockkey']:
     EnVytgCOpDKrqfbBUQdhNHozAkGSwM=EnVytgCOpDKrqfbBUQdhNHozAkGSRj.value
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSwv,EnVytgCOpDKrqfbBUQdhNHozAkGSws,EnVytgCOpDKrqfbBUQdhNHozAkGSwM
 def GetProfileLockYN(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,EnVytgCOpDKrqfbBUQdhNHozAkGSTR,EnVytgCOpDKrqfbBUQdhNHozAkGSTm):
  EnVytgCOpDKrqfbBUQdhNHozAkGSwa=[]
  EnVytgCOpDKrqfbBUQdhNHozAkGSwM ='N'
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/profile/select.do'
   EnVytgCOpDKrqfbBUQdhNHozAkGSwW=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.URL_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSRF=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.makeDefaultCookies(vToken=EnVytgCOpDKrqfbBUQdhNHozAkGSTR,vUserinfo=EnVytgCOpDKrqfbBUQdhNHozAkGSTm)
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSwW,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSRF)
   EnVytgCOpDKrqfbBUQdhNHozAkGSwa =re.findall('data-profile-no="\d+"',EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   for i in EnVytgCOpDKrqfbBUQdhNHozAkGSXx(EnVytgCOpDKrqfbBUQdhNHozAkGSXM(EnVytgCOpDKrqfbBUQdhNHozAkGSwa)):
    EnVytgCOpDKrqfbBUQdhNHozAkGSwe =EnVytgCOpDKrqfbBUQdhNHozAkGSwa[i].replace('data-profile-no=','').replace('"','')
    EnVytgCOpDKrqfbBUQdhNHozAkGSwa[i]=EnVytgCOpDKrqfbBUQdhNHozAkGSwe
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
   return EnVytgCOpDKrqfbBUQdhNHozAkGSwM
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/profile/api/select.do'
   EnVytgCOpDKrqfbBUQdhNHozAkGSwW=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.URL_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSRF=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.makeDefaultCookies(vToken=EnVytgCOpDKrqfbBUQdhNHozAkGSTR,vUserinfo=EnVytgCOpDKrqfbBUQdhNHozAkGSTm)
   for i in EnVytgCOpDKrqfbBUQdhNHozAkGSXx(EnVytgCOpDKrqfbBUQdhNHozAkGSXM(EnVytgCOpDKrqfbBUQdhNHozAkGSwa)):
    EnVytgCOpDKrqfbBUQdhNHozAkGSRe={'profileNo':EnVytgCOpDKrqfbBUQdhNHozAkGSwa[i]}
    EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Post',EnVytgCOpDKrqfbBUQdhNHozAkGSwW,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSRe,params=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSRF)
    for EnVytgCOpDKrqfbBUQdhNHozAkGSRj in EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.cookies:
     if EnVytgCOpDKrqfbBUQdhNHozAkGSRj.name=='_tving_token':
      EnVytgCOpDKrqfbBUQdhNHozAkGSwJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRj.value
     elif EnVytgCOpDKrqfbBUQdhNHozAkGSRj.name==EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GLOBAL_COOKIENM['tv_lockkey']:
      EnVytgCOpDKrqfbBUQdhNHozAkGSwj=EnVytgCOpDKrqfbBUQdhNHozAkGSRj.value
    if EnVytgCOpDKrqfbBUQdhNHozAkGSwJ==EnVytgCOpDKrqfbBUQdhNHozAkGSTR:
     EnVytgCOpDKrqfbBUQdhNHozAkGSwM=EnVytgCOpDKrqfbBUQdhNHozAkGSwj
     EnVytgCOpDKrqfbBUQdhNHozAkGSXL(EnVytgCOpDKrqfbBUQdhNHozAkGSTR)
     break
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSwM
 def GetBookmarkInfo(EnVytgCOpDKrqfbBUQdhNHozAkGSRw,videoid,vidtype):
  EnVytgCOpDKrqfbBUQdhNHozAkGSXR={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.API_DOMAIN+'/v2/media/program/'+videoid
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetDefaultParams()
   EnVytgCOpDKrqfbBUQdhNHozAkGSTP={'pageNo':'1','pageSize':'10','order':'name',}
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY.update(EnVytgCOpDKrqfbBUQdhNHozAkGSTP)
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSTY,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSXI)
   EnVytgCOpDKrqfbBUQdhNHozAkGSXT=json.loads(EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   if not('body' in EnVytgCOpDKrqfbBUQdhNHozAkGSXT):return{}
   EnVytgCOpDKrqfbBUQdhNHozAkGSXm=EnVytgCOpDKrqfbBUQdhNHozAkGSXT['body']
   EnVytgCOpDKrqfbBUQdhNHozAkGSma=EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('name').get('ko').strip()
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['title'] =EnVytgCOpDKrqfbBUQdhNHozAkGSma
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['title']=EnVytgCOpDKrqfbBUQdhNHozAkGSma
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['mpaa'] =EnVytgCOpDKrqfbBUQdhNHozAkGSRu.get(EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('grade_code'))
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['plot'] =EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('synopsis').get('ko')
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['year'] =EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('product_year')
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['cast'] =EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('actor')
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['director']=EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('director')
   if EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('category1_name').get('ko')!='':
    EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['genre'].append(EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('category1_name').get('ko'))
   if EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('category2_name').get('ko')!='':
    EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['genre'].append(EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('category2_name').get('ko'))
   EnVytgCOpDKrqfbBUQdhNHozAkGSuI=EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('broad_dt'))
   if EnVytgCOpDKrqfbBUQdhNHozAkGSuI!='0':EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(EnVytgCOpDKrqfbBUQdhNHozAkGSuI[:4],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[4:6],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[6:])
   EnVytgCOpDKrqfbBUQdhNHozAkGSms =''
   EnVytgCOpDKrqfbBUQdhNHozAkGSmv =''
   EnVytgCOpDKrqfbBUQdhNHozAkGSmM=''
   EnVytgCOpDKrqfbBUQdhNHozAkGSme =''
   EnVytgCOpDKrqfbBUQdhNHozAkGSmJ =''
   for EnVytgCOpDKrqfbBUQdhNHozAkGSuR in EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('image'):
    if EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('code')=='CAIP0900':EnVytgCOpDKrqfbBUQdhNHozAkGSms =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('url')
    elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('code')=='CAIP0200':EnVytgCOpDKrqfbBUQdhNHozAkGSmv =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('url')
    elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('code')=='CAIP1800':EnVytgCOpDKrqfbBUQdhNHozAkGSmM=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('url')
    elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('code')=='CAIP2000':EnVytgCOpDKrqfbBUQdhNHozAkGSme =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('url')
    elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('code')=='CAIP1900':EnVytgCOpDKrqfbBUQdhNHozAkGSmJ =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('url')
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['thumbnail']['poster']=EnVytgCOpDKrqfbBUQdhNHozAkGSms
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['thumbnail']['thumb']=EnVytgCOpDKrqfbBUQdhNHozAkGSmv
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['thumbnail']['clearlogo']=EnVytgCOpDKrqfbBUQdhNHozAkGSmM
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['thumbnail']['icon']=EnVytgCOpDKrqfbBUQdhNHozAkGSme
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['thumbnail']['banner']=EnVytgCOpDKrqfbBUQdhNHozAkGSmJ
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['thumbnail']['fanart']=EnVytgCOpDKrqfbBUQdhNHozAkGSmv
  else:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.API_DOMAIN+'/v2a/media/stream/info'
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetDefaultParams()
   EnVytgCOpDKrqfbBUQdhNHozAkGSTP={'info':'Y','mediaCode':videoid,'noCache':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':'','uuid':'','deviceInfo':'PC','wm':'Y',}
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY.update(EnVytgCOpDKrqfbBUQdhNHozAkGSTP)
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSTY,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSXI)
   EnVytgCOpDKrqfbBUQdhNHozAkGSXT=json.loads(EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   if not('content' in EnVytgCOpDKrqfbBUQdhNHozAkGSXT['body']):return{}
   EnVytgCOpDKrqfbBUQdhNHozAkGSXm=EnVytgCOpDKrqfbBUQdhNHozAkGSXT['body']['content']['info']['movie']
   EnVytgCOpDKrqfbBUQdhNHozAkGSma =EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('name').get('ko').strip()
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['title']=EnVytgCOpDKrqfbBUQdhNHozAkGSma
   EnVytgCOpDKrqfbBUQdhNHozAkGSma +=u' (%s)'%(EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('product_year'))
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['title'] =EnVytgCOpDKrqfbBUQdhNHozAkGSma
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['mpaa'] =EnVytgCOpDKrqfbBUQdhNHozAkGSRu.get(EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('grade_code'))
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['plot'] =EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('story').get('ko')
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['year'] =EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('product_year')
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['studio'] =EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('production')
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['duration']=EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('duration')
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['cast'] =EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('actor')
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['director']=EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('director')
   if EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('category1_name').get('ko')!='':
    EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['genre'].append(EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('category1_name').get('ko'))
   if EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('category2_name').get('ko')!='':
    EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['genre'].append(EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('category2_name').get('ko'))
   EnVytgCOpDKrqfbBUQdhNHozAkGSuI=EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('release_date'))
   if EnVytgCOpDKrqfbBUQdhNHozAkGSuI!='0':EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(EnVytgCOpDKrqfbBUQdhNHozAkGSuI[:4],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[4:6],EnVytgCOpDKrqfbBUQdhNHozAkGSuI[6:])
   EnVytgCOpDKrqfbBUQdhNHozAkGSms=''
   EnVytgCOpDKrqfbBUQdhNHozAkGSmv =''
   EnVytgCOpDKrqfbBUQdhNHozAkGSmM=''
   for EnVytgCOpDKrqfbBUQdhNHozAkGSuR in EnVytgCOpDKrqfbBUQdhNHozAkGSXm.get('image'):
    if EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('code')=='CAIM2100':EnVytgCOpDKrqfbBUQdhNHozAkGSms =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('url')
    elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('code')=='CAIM0400':EnVytgCOpDKrqfbBUQdhNHozAkGSmv =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('url')
    elif EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('code')=='CAIM1800':EnVytgCOpDKrqfbBUQdhNHozAkGSmM=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.IMG_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSuR.get('url')
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['thumbnail']['poster']=EnVytgCOpDKrqfbBUQdhNHozAkGSms
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['thumbnail']['thumb']=EnVytgCOpDKrqfbBUQdhNHozAkGSms 
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['thumbnail']['clearlogo']=EnVytgCOpDKrqfbBUQdhNHozAkGSmM
   EnVytgCOpDKrqfbBUQdhNHozAkGSXR['saveinfo']['thumbnail']['fanart']=EnVytgCOpDKrqfbBUQdhNHozAkGSmv
  return EnVytgCOpDKrqfbBUQdhNHozAkGSXR
 def GetEuroChannelList(EnVytgCOpDKrqfbBUQdhNHozAkGSRw):
  EnVytgCOpDKrqfbBUQdhNHozAkGSmF=[]
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTI ='/v2/operator/highlights'
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetDefaultParams()
   EnVytgCOpDKrqfbBUQdhNHozAkGSTP={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':EnVytgCOpDKrqfbBUQdhNHozAkGSXv(EnVytgCOpDKrqfbBUQdhNHozAkGSRw.GetNoCache(2))}
   EnVytgCOpDKrqfbBUQdhNHozAkGSTY.update(EnVytgCOpDKrqfbBUQdhNHozAkGSTP)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.API_DOMAIN+EnVytgCOpDKrqfbBUQdhNHozAkGSTI
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSTY,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSXI)
   EnVytgCOpDKrqfbBUQdhNHozAkGSTW=json.loads(EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   if not('result' in EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']):return EnVytgCOpDKrqfbBUQdhNHozAkGSmF,EnVytgCOpDKrqfbBUQdhNHozAkGSml
   EnVytgCOpDKrqfbBUQdhNHozAkGSmY=EnVytgCOpDKrqfbBUQdhNHozAkGSTW['body']['result']
   EnVytgCOpDKrqfbBUQdhNHozAkGSXu =EnVytgCOpDKrqfbBUQdhNHozAkGSRw.Get_Now_Datetime()
   EnVytgCOpDKrqfbBUQdhNHozAkGSXw=EnVytgCOpDKrqfbBUQdhNHozAkGSXu+datetime.timedelta(days=-1)
   EnVytgCOpDKrqfbBUQdhNHozAkGSXw=EnVytgCOpDKrqfbBUQdhNHozAkGSXP(EnVytgCOpDKrqfbBUQdhNHozAkGSXw.strftime('%Y%m%d'))
   for EnVytgCOpDKrqfbBUQdhNHozAkGSTs in EnVytgCOpDKrqfbBUQdhNHozAkGSmY:
    EnVytgCOpDKrqfbBUQdhNHozAkGSXc=EnVytgCOpDKrqfbBUQdhNHozAkGSXP(EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('content').get('banner_title2')[:8])
    if EnVytgCOpDKrqfbBUQdhNHozAkGSXw<=EnVytgCOpDKrqfbBUQdhNHozAkGSXc:
     EnVytgCOpDKrqfbBUQdhNHozAkGSuP={'channel':EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('content').get('banner_sub_title3'),'title':EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('content').get('banner_title'),'subtitle':EnVytgCOpDKrqfbBUQdhNHozAkGSTs.get('content').get('banner_sub_title2'),}
     EnVytgCOpDKrqfbBUQdhNHozAkGSmF.append(EnVytgCOpDKrqfbBUQdhNHozAkGSuP)
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSmF
 def Get_Naver_Login(EnVytgCOpDKrqfbBUQdhNHozAkGSRw):
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx='https://user.tving.com/oauth/oauthLogin.tving?target=naver&from=pc&rtUrl=https://user.tving.com/pc/user/login.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fmain.do%3FretRef%3DY%26source%3Dhttps%3A%2F%2Fwww.google.com%2F&csite=&isAuto=false'
   EnVytgCOpDKrqfbBUQdhNHozAkGSRJ=EnVytgCOpDKrqfbBUQdhNHozAkGSRw.callRequestCookies('Get',EnVytgCOpDKrqfbBUQdhNHozAkGSTx,payload=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,params=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,headers=EnVytgCOpDKrqfbBUQdhNHozAkGSXI,cookies=EnVytgCOpDKrqfbBUQdhNHozAkGSXI)
   if EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.status_code!=200:return EnVytgCOpDKrqfbBUQdhNHozAkGSXY
   EnVytgCOpDKrqfbBUQdhNHozAkGSXF=re.findall('\'https://nid.naver.com/(?:[a-zA-Z]|[0-9]|[$\-@\.&+:/?=_]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+\'',EnVytgCOpDKrqfbBUQdhNHozAkGSRJ.text)
   EnVytgCOpDKrqfbBUQdhNHozAkGSXl=EnVytgCOpDKrqfbBUQdhNHozAkGSXF[0].replace('\'','')
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(EnVytgCOpDKrqfbBUQdhNHozAkGSXl)
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL('n login pass1 error')
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  try:
   EnVytgCOpDKrqfbBUQdhNHozAkGSTx=EnVytgCOpDKrqfbBUQdhNHozAkGSXl
  except EnVytgCOpDKrqfbBUQdhNHozAkGSXa as exception:
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL('n login pass1 error')
   EnVytgCOpDKrqfbBUQdhNHozAkGSXL(exception)
  return EnVytgCOpDKrqfbBUQdhNHozAkGSXW
# Created by pyminifier (https://github.com/liftoff/pyminifier)
