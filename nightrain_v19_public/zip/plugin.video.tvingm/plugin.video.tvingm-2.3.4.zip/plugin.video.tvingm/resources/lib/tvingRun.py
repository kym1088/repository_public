__author__="NightRain"
PzJpUWCRLDjfoxtgyNTbqIQOXneAvh=object
PzJpUWCRLDjfoxtgyNTbqIQOXneAuw=None
PzJpUWCRLDjfoxtgyNTbqIQOXneAus=int
PzJpUWCRLDjfoxtgyNTbqIQOXneAuF=True
PzJpUWCRLDjfoxtgyNTbqIQOXneAum=False
PzJpUWCRLDjfoxtgyNTbqIQOXneAuk=type
PzJpUWCRLDjfoxtgyNTbqIQOXneAuB=dict
PzJpUWCRLDjfoxtgyNTbqIQOXneAuv=len
PzJpUWCRLDjfoxtgyNTbqIQOXneAuE=str
PzJpUWCRLDjfoxtgyNTbqIQOXneAul=range
PzJpUWCRLDjfoxtgyNTbqIQOXneAuH=open
PzJpUWCRLDjfoxtgyNTbqIQOXneAua=Exception
PzJpUWCRLDjfoxtgyNTbqIQOXneAuV=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
PzJpUWCRLDjfoxtgyNTbqIQOXneAwF=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'Euro 2020','mode':'EURO_GROUP','stype':'live','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
PzJpUWCRLDjfoxtgyNTbqIQOXneAwm=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
PzJpUWCRLDjfoxtgyNTbqIQOXneAwk=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
PzJpUWCRLDjfoxtgyNTbqIQOXneAwB=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
PzJpUWCRLDjfoxtgyNTbqIQOXneAwv=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
PzJpUWCRLDjfoxtgyNTbqIQOXneAwu=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
PzJpUWCRLDjfoxtgyNTbqIQOXneAwE=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
PzJpUWCRLDjfoxtgyNTbqIQOXneAwl =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
PzJpUWCRLDjfoxtgyNTbqIQOXneAwH=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class PzJpUWCRLDjfoxtgyNTbqIQOXneAws(PzJpUWCRLDjfoxtgyNTbqIQOXneAvh):
 def __init__(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAwV,PzJpUWCRLDjfoxtgyNTbqIQOXneAwi,PzJpUWCRLDjfoxtgyNTbqIQOXneAwG):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_url =PzJpUWCRLDjfoxtgyNTbqIQOXneAwV
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle=PzJpUWCRLDjfoxtgyNTbqIQOXneAwi
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params =PzJpUWCRLDjfoxtgyNTbqIQOXneAwG
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj =EnVytgCOpDKrqfbBUQdhNHozAkGSRT() 
 def addon_noti(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,sting):
  try:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwr=xbmcgui.Dialog()
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwr.notification(__addonname__,sting)
  except:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
 def addon_log(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,string):
  try:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwd=string.encode('utf-8','ignore')
  except:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwd='addonException: addon_log'
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwY=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,PzJpUWCRLDjfoxtgyNTbqIQOXneAwd),level=PzJpUWCRLDjfoxtgyNTbqIQOXneAwY)
 def get_keyboard_input(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAsa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwc=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
  kb=xbmc.Keyboard()
  kb.setHeading(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwc=kb.getText()
  return PzJpUWCRLDjfoxtgyNTbqIQOXneAwc
 def get_settings_login_info(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwK =__addon__.getSetting('id')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwM =__addon__.getSetting('pw')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwh =__addon__.getSetting('login_type')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsw=PzJpUWCRLDjfoxtgyNTbqIQOXneAus(__addon__.getSetting('selected_profile'))
  return(PzJpUWCRLDjfoxtgyNTbqIQOXneAwK,PzJpUWCRLDjfoxtgyNTbqIQOXneAwM,PzJpUWCRLDjfoxtgyNTbqIQOXneAwh,PzJpUWCRLDjfoxtgyNTbqIQOXneAsw)
 def get_settings_totalsearch(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsF =PzJpUWCRLDjfoxtgyNTbqIQOXneAuF if __addon__.getSetting('local_search')=='true' else PzJpUWCRLDjfoxtgyNTbqIQOXneAum
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsm=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF if __addon__.getSetting('local_history')=='true' else PzJpUWCRLDjfoxtgyNTbqIQOXneAum
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsk =PzJpUWCRLDjfoxtgyNTbqIQOXneAuF if __addon__.getSetting('total_search')=='true' else PzJpUWCRLDjfoxtgyNTbqIQOXneAum
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsB=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF if __addon__.getSetting('total_history')=='true' else PzJpUWCRLDjfoxtgyNTbqIQOXneAum
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsv=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF if __addon__.getSetting('menu_bookmark')=='true' else PzJpUWCRLDjfoxtgyNTbqIQOXneAum
  return(PzJpUWCRLDjfoxtgyNTbqIQOXneAsF,PzJpUWCRLDjfoxtgyNTbqIQOXneAsm,PzJpUWCRLDjfoxtgyNTbqIQOXneAsk,PzJpUWCRLDjfoxtgyNTbqIQOXneAsB,PzJpUWCRLDjfoxtgyNTbqIQOXneAsv)
 def get_settings_makebookmark(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa):
  return PzJpUWCRLDjfoxtgyNTbqIQOXneAuF if __addon__.getSetting('make_bookmark')=='true' else PzJpUWCRLDjfoxtgyNTbqIQOXneAum
 def get_settings_direct_replay(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsu=PzJpUWCRLDjfoxtgyNTbqIQOXneAus(__addon__.getSetting('direct_replay'))
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAsu==0:
   return PzJpUWCRLDjfoxtgyNTbqIQOXneAum
  else:
   return PzJpUWCRLDjfoxtgyNTbqIQOXneAuF
 def set_winCredential(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,credential):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE=xbmcgui.Window(10000)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_LOGINTIME',PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE=xbmcgui.Window(10000)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsl={'tving_token':PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.getProperty('TVING_M_TOKEN'),'poc_userinfo':PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.getProperty('TVING_M_USERINFO'),'tving_uuid':PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.getProperty('TVING_M_UUID'),'tving_maintoken':PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.getProperty('TVING_M_LOCKKEY')}
  return PzJpUWCRLDjfoxtgyNTbqIQOXneAsl
 def set_winEpisodeOrderby(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAmv):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE=xbmcgui.Window(10000)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_ORDERBY',PzJpUWCRLDjfoxtgyNTbqIQOXneAmv)
 def get_winEpisodeOrderby(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE=xbmcgui.Window(10000)
  return PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.getProperty('TVING_M_ORDERBY')
 def add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,label,sublabel='',img='',infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF,params='',isLink=PzJpUWCRLDjfoxtgyNTbqIQOXneAum,ContextMenu=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsH='%s?%s'%(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_url,urllib.parse.urlencode(params))
  if sublabel:PzJpUWCRLDjfoxtgyNTbqIQOXneAsa='%s < %s >'%(label,sublabel)
  else: PzJpUWCRLDjfoxtgyNTbqIQOXneAsa=label
  if not img:img='DefaultFolder.png'
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsV=xbmcgui.ListItem(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAuk(img)==PzJpUWCRLDjfoxtgyNTbqIQOXneAuB:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsV.setArt(img)
  else:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsV.setArt({'thumb':img,'poster':img})
  if infoLabels:PzJpUWCRLDjfoxtgyNTbqIQOXneAsV.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsV.setProperty('IsPlayable','true')
  if ContextMenu:PzJpUWCRLDjfoxtgyNTbqIQOXneAsV.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,PzJpUWCRLDjfoxtgyNTbqIQOXneAsH,PzJpUWCRLDjfoxtgyNTbqIQOXneAsV,isFolder)
 def get_selQuality(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,etype):
  try:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsi='selected_quality'
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsG=[1080,720,480,360]
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsS=PzJpUWCRLDjfoxtgyNTbqIQOXneAus(__addon__.getSetting(PzJpUWCRLDjfoxtgyNTbqIQOXneAsi))
   return PzJpUWCRLDjfoxtgyNTbqIQOXneAsG[PzJpUWCRLDjfoxtgyNTbqIQOXneAsS]
  except:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
  return 720 
 def dp_Main_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa):
  (PzJpUWCRLDjfoxtgyNTbqIQOXneAsF,PzJpUWCRLDjfoxtgyNTbqIQOXneAsm,PzJpUWCRLDjfoxtgyNTbqIQOXneAsk,PzJpUWCRLDjfoxtgyNTbqIQOXneAsB,PzJpUWCRLDjfoxtgyNTbqIQOXneAsv)=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_settings_totalsearch()
  for PzJpUWCRLDjfoxtgyNTbqIQOXneAsr in PzJpUWCRLDjfoxtgyNTbqIQOXneAwF:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa=PzJpUWCRLDjfoxtgyNTbqIQOXneAsr.get('title')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsd=''
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAsr.get('mode')=='SEARCH_GROUP' and PzJpUWCRLDjfoxtgyNTbqIQOXneAsF ==PzJpUWCRLDjfoxtgyNTbqIQOXneAum:continue
   elif PzJpUWCRLDjfoxtgyNTbqIQOXneAsr.get('mode')=='SEARCH_HISTORY' and PzJpUWCRLDjfoxtgyNTbqIQOXneAsm==PzJpUWCRLDjfoxtgyNTbqIQOXneAum:continue
   elif PzJpUWCRLDjfoxtgyNTbqIQOXneAsr.get('mode')=='TOTAL_SEARCH' and PzJpUWCRLDjfoxtgyNTbqIQOXneAsk ==PzJpUWCRLDjfoxtgyNTbqIQOXneAum:continue
   elif PzJpUWCRLDjfoxtgyNTbqIQOXneAsr.get('mode')=='TOTAL_HISTORY' and PzJpUWCRLDjfoxtgyNTbqIQOXneAsB==PzJpUWCRLDjfoxtgyNTbqIQOXneAum:continue
   elif PzJpUWCRLDjfoxtgyNTbqIQOXneAsr.get('mode')=='MENU_BOOKMARK' and PzJpUWCRLDjfoxtgyNTbqIQOXneAsv==PzJpUWCRLDjfoxtgyNTbqIQOXneAum:continue
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':PzJpUWCRLDjfoxtgyNTbqIQOXneAsr.get('mode'),'stype':PzJpUWCRLDjfoxtgyNTbqIQOXneAsr.get('stype'),'orderby':PzJpUWCRLDjfoxtgyNTbqIQOXneAsr.get('orderby'),'ordernm':PzJpUWCRLDjfoxtgyNTbqIQOXneAsr.get('ordernm'),'page':'1'}
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAsr.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsc=PzJpUWCRLDjfoxtgyNTbqIQOXneAum
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsK =PzJpUWCRLDjfoxtgyNTbqIQOXneAuF
   else:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsc=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsK =PzJpUWCRLDjfoxtgyNTbqIQOXneAum
   if 'icon' in PzJpUWCRLDjfoxtgyNTbqIQOXneAsr:PzJpUWCRLDjfoxtgyNTbqIQOXneAsd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',PzJpUWCRLDjfoxtgyNTbqIQOXneAsr.get('icon')) 
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel='',img=PzJpUWCRLDjfoxtgyNTbqIQOXneAsd,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAsc,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY,isLink=PzJpUWCRLDjfoxtgyNTbqIQOXneAsK)
  xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle)
 def login_main(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa):
  (PzJpUWCRLDjfoxtgyNTbqIQOXneAsh,PzJpUWCRLDjfoxtgyNTbqIQOXneAFw,PzJpUWCRLDjfoxtgyNTbqIQOXneAFs,PzJpUWCRLDjfoxtgyNTbqIQOXneAFm)=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_settings_login_info()
  if not(PzJpUWCRLDjfoxtgyNTbqIQOXneAsh and PzJpUWCRLDjfoxtgyNTbqIQOXneAFw):
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwr=xbmcgui.Dialog()
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFk=PzJpUWCRLDjfoxtgyNTbqIQOXneAwr.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAFk==PzJpUWCRLDjfoxtgyNTbqIQOXneAuF:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_winEpisodeOrderby()=='':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.set_winEpisodeOrderby('desc')
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.cookiefile_check():return
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFB =PzJpUWCRLDjfoxtgyNTbqIQOXneAus(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFv=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFv==PzJpUWCRLDjfoxtgyNTbqIQOXneAuw or PzJpUWCRLDjfoxtgyNTbqIQOXneAFv=='':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFv=PzJpUWCRLDjfoxtgyNTbqIQOXneAus('19000101')
  else:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFv=PzJpUWCRLDjfoxtgyNTbqIQOXneAus(re.sub('-','',PzJpUWCRLDjfoxtgyNTbqIQOXneAFv))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFu=0
   while PzJpUWCRLDjfoxtgyNTbqIQOXneAuF:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAFu+=1
    time.sleep(0.05)
    if PzJpUWCRLDjfoxtgyNTbqIQOXneAFv>=PzJpUWCRLDjfoxtgyNTbqIQOXneAFB:return
    if PzJpUWCRLDjfoxtgyNTbqIQOXneAFu>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFv>=PzJpUWCRLDjfoxtgyNTbqIQOXneAFB:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.GetCredential(PzJpUWCRLDjfoxtgyNTbqIQOXneAsh,PzJpUWCRLDjfoxtgyNTbqIQOXneAFw,PzJpUWCRLDjfoxtgyNTbqIQOXneAFs,PzJpUWCRLDjfoxtgyNTbqIQOXneAFm):
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.set_winCredential(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.LoadCredential())
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('stype')
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='live':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFl=PzJpUWCRLDjfoxtgyNTbqIQOXneAwm
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='vod':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFl=PzJpUWCRLDjfoxtgyNTbqIQOXneAwv
  else:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFl=PzJpUWCRLDjfoxtgyNTbqIQOXneAwu
  for PzJpUWCRLDjfoxtgyNTbqIQOXneAFH in PzJpUWCRLDjfoxtgyNTbqIQOXneAFl:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa=PzJpUWCRLDjfoxtgyNTbqIQOXneAFH.get('title')
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('ordernm')!='-':
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsa+='  ('+PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('ordernm')+')'
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':PzJpUWCRLDjfoxtgyNTbqIQOXneAFH.get('mode'),'stype':PzJpUWCRLDjfoxtgyNTbqIQOXneAFH.get('stype'),'orderby':PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('orderby'),'ordernm':PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('ordernm'),'page':'1'}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel='',img='',infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAuv(PzJpUWCRLDjfoxtgyNTbqIQOXneAFl)>0:xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle)
 def dp_SubTitle_Group(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa): 
  for PzJpUWCRLDjfoxtgyNTbqIQOXneAFH in PzJpUWCRLDjfoxtgyNTbqIQOXneAwE:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa=PzJpUWCRLDjfoxtgyNTbqIQOXneAFH.get('title')
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('ordernm')!='-':
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsa+='  ('+PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('ordernm')+')'
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':PzJpUWCRLDjfoxtgyNTbqIQOXneAFH.get('mode'),'genreCode':PzJpUWCRLDjfoxtgyNTbqIQOXneAFH.get('genreCode'),'stype':PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('stype'),'orderby':PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('orderby'),'page':'1'}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel='',img='',infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAuv(PzJpUWCRLDjfoxtgyNTbqIQOXneAwE)>0:xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle)
 def dp_LiveChannel_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.SaveCredential(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_winCredential())
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFE =PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('stype')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFV =PzJpUWCRLDjfoxtgyNTbqIQOXneAus(PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('page'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFi,PzJpUWCRLDjfoxtgyNTbqIQOXneAFG=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.GetLiveChannelList(PzJpUWCRLDjfoxtgyNTbqIQOXneAFE,PzJpUWCRLDjfoxtgyNTbqIQOXneAFV)
  for PzJpUWCRLDjfoxtgyNTbqIQOXneAFS in PzJpUWCRLDjfoxtgyNTbqIQOXneAFi:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('title')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsM =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('channel')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFr =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('thumbnail')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFd =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('synopsis')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFY =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('channelepg')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFc =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('cast')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFK =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('director')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFM =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('info_genre')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFh =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('year')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmw =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('mpaa')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAms =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('premiered')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmF={'mediatype':'episode','title':PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,'studio':PzJpUWCRLDjfoxtgyNTbqIQOXneAsM,'cast':PzJpUWCRLDjfoxtgyNTbqIQOXneAFc,'director':PzJpUWCRLDjfoxtgyNTbqIQOXneAFK,'genre':PzJpUWCRLDjfoxtgyNTbqIQOXneAFM,'plot':'%s\n%s\n%s\n\n%s'%(PzJpUWCRLDjfoxtgyNTbqIQOXneAsM,PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFY,PzJpUWCRLDjfoxtgyNTbqIQOXneAFd),'year':PzJpUWCRLDjfoxtgyNTbqIQOXneAFh,'mpaa':PzJpUWCRLDjfoxtgyNTbqIQOXneAmw,'premiered':PzJpUWCRLDjfoxtgyNTbqIQOXneAms}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':'LIVE','mediacode':PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('mediacode'),'stype':PzJpUWCRLDjfoxtgyNTbqIQOXneAFE}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsM,sublabel=PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,img=PzJpUWCRLDjfoxtgyNTbqIQOXneAFr,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAmF,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAum,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFG:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['mode']='CHANNEL' 
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['stype']=PzJpUWCRLDjfoxtgyNTbqIQOXneAFE 
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['page']=PzJpUWCRLDjfoxtgyNTbqIQOXneAuE(PzJpUWCRLDjfoxtgyNTbqIQOXneAFV+1)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa='[B]%s >>[/B]'%'다음 페이지'
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmk=PzJpUWCRLDjfoxtgyNTbqIQOXneAuE(PzJpUWCRLDjfoxtgyNTbqIQOXneAFV+1)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel=PzJpUWCRLDjfoxtgyNTbqIQOXneAmk,img=PzJpUWCRLDjfoxtgyNTbqIQOXneAsd,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAuv(PzJpUWCRLDjfoxtgyNTbqIQOXneAFi)>0:xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,cacheToDisc=PzJpUWCRLDjfoxtgyNTbqIQOXneAum)
 def dp_Program_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.SaveCredential(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_winCredential())
  PzJpUWCRLDjfoxtgyNTbqIQOXneAmB =PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('stype')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAmv =PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('orderby')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFV =PzJpUWCRLDjfoxtgyNTbqIQOXneAus(PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('page'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAmu=PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('genreCode')
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAmu==PzJpUWCRLDjfoxtgyNTbqIQOXneAuw:PzJpUWCRLDjfoxtgyNTbqIQOXneAmu='all'
  PzJpUWCRLDjfoxtgyNTbqIQOXneAmE,PzJpUWCRLDjfoxtgyNTbqIQOXneAFG=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.GetProgramList(PzJpUWCRLDjfoxtgyNTbqIQOXneAmB,PzJpUWCRLDjfoxtgyNTbqIQOXneAmv,PzJpUWCRLDjfoxtgyNTbqIQOXneAFV,PzJpUWCRLDjfoxtgyNTbqIQOXneAmu)
  for PzJpUWCRLDjfoxtgyNTbqIQOXneAml in PzJpUWCRLDjfoxtgyNTbqIQOXneAmE:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa =PzJpUWCRLDjfoxtgyNTbqIQOXneAml.get('title')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFr =PzJpUWCRLDjfoxtgyNTbqIQOXneAml.get('thumbnail')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFd =PzJpUWCRLDjfoxtgyNTbqIQOXneAml.get('synopsis')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmH =PzJpUWCRLDjfoxtgyNTbqIQOXneAml.get('channel')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFc =PzJpUWCRLDjfoxtgyNTbqIQOXneAml.get('cast')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFK =PzJpUWCRLDjfoxtgyNTbqIQOXneAml.get('director')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFM=PzJpUWCRLDjfoxtgyNTbqIQOXneAml.get('info_genre')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFh =PzJpUWCRLDjfoxtgyNTbqIQOXneAml.get('year')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAms =PzJpUWCRLDjfoxtgyNTbqIQOXneAml.get('premiered')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmw =PzJpUWCRLDjfoxtgyNTbqIQOXneAml.get('mpaa')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmF={'mediatype':'tvshow','title':PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,'studio':PzJpUWCRLDjfoxtgyNTbqIQOXneAmH,'cast':PzJpUWCRLDjfoxtgyNTbqIQOXneAFc,'director':PzJpUWCRLDjfoxtgyNTbqIQOXneAFK,'genre':PzJpUWCRLDjfoxtgyNTbqIQOXneAFM,'year':PzJpUWCRLDjfoxtgyNTbqIQOXneAFh,'premiered':PzJpUWCRLDjfoxtgyNTbqIQOXneAms,'mpaa':PzJpUWCRLDjfoxtgyNTbqIQOXneAmw,'plot':PzJpUWCRLDjfoxtgyNTbqIQOXneAFd}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':'EPISODE','programcode':PzJpUWCRLDjfoxtgyNTbqIQOXneAml.get('program'),'page':'1'}
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_settings_makebookmark():
    PzJpUWCRLDjfoxtgyNTbqIQOXneAma={'videoid':PzJpUWCRLDjfoxtgyNTbqIQOXneAml.get('program'),'vidtype':'tvshow','vtitle':PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,'vsubtitle':PzJpUWCRLDjfoxtgyNTbqIQOXneAmH,}
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmV=json.dumps(PzJpUWCRLDjfoxtgyNTbqIQOXneAma)
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmV=urllib.parse.quote(PzJpUWCRLDjfoxtgyNTbqIQOXneAmV)
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmi='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(PzJpUWCRLDjfoxtgyNTbqIQOXneAmV)
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmG=[('(통합) 찜 영상에 추가',PzJpUWCRLDjfoxtgyNTbqIQOXneAmi)]
   else:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmG=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel=PzJpUWCRLDjfoxtgyNTbqIQOXneAmH,img=PzJpUWCRLDjfoxtgyNTbqIQOXneAFr,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAmF,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY,ContextMenu=PzJpUWCRLDjfoxtgyNTbqIQOXneAmG)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFG:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['mode'] ='PROGRAM' 
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['stype'] =PzJpUWCRLDjfoxtgyNTbqIQOXneAmB
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['orderby'] =PzJpUWCRLDjfoxtgyNTbqIQOXneAmv
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['page'] =PzJpUWCRLDjfoxtgyNTbqIQOXneAuE(PzJpUWCRLDjfoxtgyNTbqIQOXneAFV+1)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['genreCode']=PzJpUWCRLDjfoxtgyNTbqIQOXneAmu 
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa='[B]%s >>[/B]'%'다음 페이지'
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmk=PzJpUWCRLDjfoxtgyNTbqIQOXneAuE(PzJpUWCRLDjfoxtgyNTbqIQOXneAFV+1)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel=PzJpUWCRLDjfoxtgyNTbqIQOXneAmk,img=PzJpUWCRLDjfoxtgyNTbqIQOXneAsd,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
  xbmcplugin.setContent(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,cacheToDisc=PzJpUWCRLDjfoxtgyNTbqIQOXneAum)
 def dp_Episode_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.SaveCredential(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_winCredential())
  PzJpUWCRLDjfoxtgyNTbqIQOXneAmr=PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('programcode')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFV =PzJpUWCRLDjfoxtgyNTbqIQOXneAus(PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('page'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAmd,PzJpUWCRLDjfoxtgyNTbqIQOXneAFG,PzJpUWCRLDjfoxtgyNTbqIQOXneAmY=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.GetEpisodeList(PzJpUWCRLDjfoxtgyNTbqIQOXneAmr,PzJpUWCRLDjfoxtgyNTbqIQOXneAFV,orderby=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_winEpisodeOrderby())
  for PzJpUWCRLDjfoxtgyNTbqIQOXneAmc in PzJpUWCRLDjfoxtgyNTbqIQOXneAmd:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa =PzJpUWCRLDjfoxtgyNTbqIQOXneAmc.get('title')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmk =PzJpUWCRLDjfoxtgyNTbqIQOXneAmc.get('subtitle')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFr =PzJpUWCRLDjfoxtgyNTbqIQOXneAmc.get('thumbnail')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFd =PzJpUWCRLDjfoxtgyNTbqIQOXneAmc.get('synopsis')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmK=PzJpUWCRLDjfoxtgyNTbqIQOXneAmc.get('info_title')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmM =PzJpUWCRLDjfoxtgyNTbqIQOXneAmc.get('aired')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmh =PzJpUWCRLDjfoxtgyNTbqIQOXneAmc.get('studio')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAkw =PzJpUWCRLDjfoxtgyNTbqIQOXneAmc.get('frequency')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmF={'mediatype':'episode','title':PzJpUWCRLDjfoxtgyNTbqIQOXneAmK,'aired':PzJpUWCRLDjfoxtgyNTbqIQOXneAmM,'studio':PzJpUWCRLDjfoxtgyNTbqIQOXneAmh,'episode':PzJpUWCRLDjfoxtgyNTbqIQOXneAkw,'plot':PzJpUWCRLDjfoxtgyNTbqIQOXneAFd}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':'VOD','mediacode':PzJpUWCRLDjfoxtgyNTbqIQOXneAmc.get('episode'),'stype':'vod','programcode':PzJpUWCRLDjfoxtgyNTbqIQOXneAmr,'title':PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,'thumbnail':PzJpUWCRLDjfoxtgyNTbqIQOXneAFr}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel=PzJpUWCRLDjfoxtgyNTbqIQOXneAmk,img=PzJpUWCRLDjfoxtgyNTbqIQOXneAFr,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAmF,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAum,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFV==1:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmF={'plot':'정렬순서를 변경합니다.'}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['mode'] ='ORDER_BY' 
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_winEpisodeOrderby()=='desc':
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsa='정렬순서변경 : 최신화부터 -> 1회부터'
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['orderby']='asc'
   else:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsa='정렬순서변경 : 1회부터 -> 최신화부터'
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['orderby']='desc'
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel='',img=PzJpUWCRLDjfoxtgyNTbqIQOXneAsd,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAmF,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAum,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY,isLink=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFG:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['mode'] ='EPISODE' 
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['programcode']=PzJpUWCRLDjfoxtgyNTbqIQOXneAmr
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['page'] =PzJpUWCRLDjfoxtgyNTbqIQOXneAuE(PzJpUWCRLDjfoxtgyNTbqIQOXneAFV+1)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa='[B]%s >>[/B]'%'다음 페이지'
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmk=PzJpUWCRLDjfoxtgyNTbqIQOXneAuE(PzJpUWCRLDjfoxtgyNTbqIQOXneAFV+1)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel=PzJpUWCRLDjfoxtgyNTbqIQOXneAmk,img=PzJpUWCRLDjfoxtgyNTbqIQOXneAsd,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
  xbmcplugin.setContent(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,'episodes')
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAuv(PzJpUWCRLDjfoxtgyNTbqIQOXneAmd)>0:xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,cacheToDisc=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF)
 def dp_setEpOrderby(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAmv =PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('orderby')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.set_winEpisodeOrderby(PzJpUWCRLDjfoxtgyNTbqIQOXneAmv)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.SaveCredential(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_winCredential())
  PzJpUWCRLDjfoxtgyNTbqIQOXneAmB =PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('stype')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAmv =PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('orderby')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFV=PzJpUWCRLDjfoxtgyNTbqIQOXneAus(PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('page'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAks,PzJpUWCRLDjfoxtgyNTbqIQOXneAFG=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.GetMovieList(PzJpUWCRLDjfoxtgyNTbqIQOXneAmB,PzJpUWCRLDjfoxtgyNTbqIQOXneAmv,PzJpUWCRLDjfoxtgyNTbqIQOXneAFV)
  for PzJpUWCRLDjfoxtgyNTbqIQOXneAkF in PzJpUWCRLDjfoxtgyNTbqIQOXneAks:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa =PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('title')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFr =PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('thumbnail')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFd =PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('synopsis')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmK =PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('info_title')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFh =PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('year')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFc =PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('cast')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFK =PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('director')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFM =PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('info_genre')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAkm =PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('duration')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAms =PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('premiered')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmh =PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('studio')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmw =PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('mpaa')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmF={'mediatype':'movie','title':PzJpUWCRLDjfoxtgyNTbqIQOXneAmK,'year':PzJpUWCRLDjfoxtgyNTbqIQOXneAFh,'cast':PzJpUWCRLDjfoxtgyNTbqIQOXneAFc,'director':PzJpUWCRLDjfoxtgyNTbqIQOXneAFK,'genre':PzJpUWCRLDjfoxtgyNTbqIQOXneAFM,'duration':PzJpUWCRLDjfoxtgyNTbqIQOXneAkm,'premiered':PzJpUWCRLDjfoxtgyNTbqIQOXneAms,'studio':PzJpUWCRLDjfoxtgyNTbqIQOXneAmh,'mpaa':PzJpUWCRLDjfoxtgyNTbqIQOXneAmw,'plot':PzJpUWCRLDjfoxtgyNTbqIQOXneAFd}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':'MOVIE','mediacode':PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('moviecode'),'stype':'movie','title':PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,'thumbnail':PzJpUWCRLDjfoxtgyNTbqIQOXneAFr}
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_settings_makebookmark():
    PzJpUWCRLDjfoxtgyNTbqIQOXneAma={'videoid':PzJpUWCRLDjfoxtgyNTbqIQOXneAkF.get('moviecode'),'vidtype':'movie','vtitle':PzJpUWCRLDjfoxtgyNTbqIQOXneAmK,'vsubtitle':'',}
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmV=json.dumps(PzJpUWCRLDjfoxtgyNTbqIQOXneAma)
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmV=urllib.parse.quote(PzJpUWCRLDjfoxtgyNTbqIQOXneAmV)
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmi='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(PzJpUWCRLDjfoxtgyNTbqIQOXneAmV)
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmG=[('(통합) 찜 영상에 추가',PzJpUWCRLDjfoxtgyNTbqIQOXneAmi)]
   else:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmG=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel='',img=PzJpUWCRLDjfoxtgyNTbqIQOXneAFr,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAmF,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAum,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY,ContextMenu=PzJpUWCRLDjfoxtgyNTbqIQOXneAmG)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFG:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['mode'] ='MOVIE_SUB' 
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['orderby']=PzJpUWCRLDjfoxtgyNTbqIQOXneAmv
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['stype'] =PzJpUWCRLDjfoxtgyNTbqIQOXneAmB
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['page'] =PzJpUWCRLDjfoxtgyNTbqIQOXneAuE(PzJpUWCRLDjfoxtgyNTbqIQOXneAFV+1)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa='[B]%s >>[/B]'%'다음 페이지'
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmk=PzJpUWCRLDjfoxtgyNTbqIQOXneAuE(PzJpUWCRLDjfoxtgyNTbqIQOXneAFV+1)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel=PzJpUWCRLDjfoxtgyNTbqIQOXneAmk,img=PzJpUWCRLDjfoxtgyNTbqIQOXneAsd,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
  xbmcplugin.setContent(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,'movies')
  xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,cacheToDisc=PzJpUWCRLDjfoxtgyNTbqIQOXneAum)
 def dp_Set_Bookmark(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAkB=urllib.parse.unquote(PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('bm_param'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAkB=json.loads(PzJpUWCRLDjfoxtgyNTbqIQOXneAkB)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAkv =PzJpUWCRLDjfoxtgyNTbqIQOXneAkB.get('videoid')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAku =PzJpUWCRLDjfoxtgyNTbqIQOXneAkB.get('vidtype')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAkE =PzJpUWCRLDjfoxtgyNTbqIQOXneAkB.get('vtitle')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAkl =PzJpUWCRLDjfoxtgyNTbqIQOXneAkB.get('vsubtitle')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwr=xbmcgui.Dialog()
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFk=PzJpUWCRLDjfoxtgyNTbqIQOXneAwr.yesno(__language__(30913).encode('utf8'),PzJpUWCRLDjfoxtgyNTbqIQOXneAkE+' \n\n'+__language__(30914))
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFk==PzJpUWCRLDjfoxtgyNTbqIQOXneAum:return
  PzJpUWCRLDjfoxtgyNTbqIQOXneAkH=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.GetBookmarkInfo(PzJpUWCRLDjfoxtgyNTbqIQOXneAkv,PzJpUWCRLDjfoxtgyNTbqIQOXneAku)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAkl!='':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAkH['saveinfo']['subtitle']=PzJpUWCRLDjfoxtgyNTbqIQOXneAkl 
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAku=='tvshow':PzJpUWCRLDjfoxtgyNTbqIQOXneAkH['saveinfo']['infoLabels']['studio']=PzJpUWCRLDjfoxtgyNTbqIQOXneAkl 
  PzJpUWCRLDjfoxtgyNTbqIQOXneAka=json.dumps(PzJpUWCRLDjfoxtgyNTbqIQOXneAkH)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAka=urllib.parse.quote(PzJpUWCRLDjfoxtgyNTbqIQOXneAka)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAmi ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(PzJpUWCRLDjfoxtgyNTbqIQOXneAka)
  xbmc.executebuiltin(PzJpUWCRLDjfoxtgyNTbqIQOXneAmi)
 def dp_Search_Group(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  if 'search_key' in PzJpUWCRLDjfoxtgyNTbqIQOXneAFa:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAkV=PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('search_key')
  else:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAkV=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not PzJpUWCRLDjfoxtgyNTbqIQOXneAkV:
    return
  for PzJpUWCRLDjfoxtgyNTbqIQOXneAFH in PzJpUWCRLDjfoxtgyNTbqIQOXneAwB:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAki =PzJpUWCRLDjfoxtgyNTbqIQOXneAFH.get('mode')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=PzJpUWCRLDjfoxtgyNTbqIQOXneAFH.get('stype')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa=PzJpUWCRLDjfoxtgyNTbqIQOXneAFH.get('title')
   (PzJpUWCRLDjfoxtgyNTbqIQOXneAkG,PzJpUWCRLDjfoxtgyNTbqIQOXneAFG)=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.GetSearchList(PzJpUWCRLDjfoxtgyNTbqIQOXneAkV,1,PzJpUWCRLDjfoxtgyNTbqIQOXneAFE)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAkS={'plot':'검색어 : '+PzJpUWCRLDjfoxtgyNTbqIQOXneAkV+'\n\n'+PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.Search_FreeList(PzJpUWCRLDjfoxtgyNTbqIQOXneAkG)}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':PzJpUWCRLDjfoxtgyNTbqIQOXneAki,'stype':PzJpUWCRLDjfoxtgyNTbqIQOXneAFE,'search_key':PzJpUWCRLDjfoxtgyNTbqIQOXneAkV,'page':'1',}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel='',img='',infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAkS,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAuv(PzJpUWCRLDjfoxtgyNTbqIQOXneAwB)>0:xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,cacheToDisc=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.Save_Searched_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAkV)
 def Search_FreeList(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneABs):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAkr=''
  PzJpUWCRLDjfoxtgyNTbqIQOXneAkd=7
  try:
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAuv(PzJpUWCRLDjfoxtgyNTbqIQOXneABs)==0:return '검색결과 없음'
   for i in PzJpUWCRLDjfoxtgyNTbqIQOXneAul(PzJpUWCRLDjfoxtgyNTbqIQOXneAuv(PzJpUWCRLDjfoxtgyNTbqIQOXneABs)):
    if i>=PzJpUWCRLDjfoxtgyNTbqIQOXneAkd:
     PzJpUWCRLDjfoxtgyNTbqIQOXneAkr=PzJpUWCRLDjfoxtgyNTbqIQOXneAkr+'...'
     break
    PzJpUWCRLDjfoxtgyNTbqIQOXneAkr=PzJpUWCRLDjfoxtgyNTbqIQOXneAkr+PzJpUWCRLDjfoxtgyNTbqIQOXneABs[i]['title']+'\n'
  except:
   return ''
  return PzJpUWCRLDjfoxtgyNTbqIQOXneAkr
 def dp_Search_History(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAkY=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.Load_List_File('search')
  for PzJpUWCRLDjfoxtgyNTbqIQOXneAkc in PzJpUWCRLDjfoxtgyNTbqIQOXneAkY:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAkK=PzJpUWCRLDjfoxtgyNTbqIQOXneAuB(urllib.parse.parse_qsl(PzJpUWCRLDjfoxtgyNTbqIQOXneAkc))
   PzJpUWCRLDjfoxtgyNTbqIQOXneAkM=PzJpUWCRLDjfoxtgyNTbqIQOXneAkK.get('skey').strip()
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':'SEARCH_GROUP','search_key':PzJpUWCRLDjfoxtgyNTbqIQOXneAkM,}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAkh={'mode':'SEARCH_REMOVE','stype':'ONE','skey':PzJpUWCRLDjfoxtgyNTbqIQOXneAkM,}
   PzJpUWCRLDjfoxtgyNTbqIQOXneABw=urllib.parse.urlencode(PzJpUWCRLDjfoxtgyNTbqIQOXneAkh)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmG=[('선택된 검색어 ( %s ) 삭제'%(PzJpUWCRLDjfoxtgyNTbqIQOXneAkM),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(PzJpUWCRLDjfoxtgyNTbqIQOXneABw))]
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAkM,sublabel='',img=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY,ContextMenu=PzJpUWCRLDjfoxtgyNTbqIQOXneAmG)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAmF={'plot':'검색목록 전체를 삭제합니다.'}
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsa='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel='',img=PzJpUWCRLDjfoxtgyNTbqIQOXneAsd,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAmF,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAum,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY,isLink=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF)
  xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,cacheToDisc=PzJpUWCRLDjfoxtgyNTbqIQOXneAum)
 def dp_Search_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.SaveCredential(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_winCredential())
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFV =PzJpUWCRLDjfoxtgyNTbqIQOXneAus(PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('page'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFE =PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('stype')
  if 'search_key' in PzJpUWCRLDjfoxtgyNTbqIQOXneAFa:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAkV=PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('search_key')
  else:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAkV=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not PzJpUWCRLDjfoxtgyNTbqIQOXneAkV:
    xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle)
    return
  PzJpUWCRLDjfoxtgyNTbqIQOXneAkG,PzJpUWCRLDjfoxtgyNTbqIQOXneAFG=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.GetSearchList(PzJpUWCRLDjfoxtgyNTbqIQOXneAkV,PzJpUWCRLDjfoxtgyNTbqIQOXneAFV,PzJpUWCRLDjfoxtgyNTbqIQOXneAFE)
  for PzJpUWCRLDjfoxtgyNTbqIQOXneABs in PzJpUWCRLDjfoxtgyNTbqIQOXneAkG:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa =PzJpUWCRLDjfoxtgyNTbqIQOXneABs.get('title')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFr =PzJpUWCRLDjfoxtgyNTbqIQOXneABs.get('thumbnail')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFd =PzJpUWCRLDjfoxtgyNTbqIQOXneABs.get('synopsis')
   PzJpUWCRLDjfoxtgyNTbqIQOXneABF =PzJpUWCRLDjfoxtgyNTbqIQOXneABs.get('program')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFc =PzJpUWCRLDjfoxtgyNTbqIQOXneABs.get('cast')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFK =PzJpUWCRLDjfoxtgyNTbqIQOXneABs.get('director')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFM=PzJpUWCRLDjfoxtgyNTbqIQOXneABs.get('info_genre')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAkm =PzJpUWCRLDjfoxtgyNTbqIQOXneABs.get('duration')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmw =PzJpUWCRLDjfoxtgyNTbqIQOXneABs.get('mpaa')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFh =PzJpUWCRLDjfoxtgyNTbqIQOXneABs.get('year')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmM =PzJpUWCRLDjfoxtgyNTbqIQOXneABs.get('aired')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmF={'mediatype':'tvshow' if PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='vod' else 'movie','title':PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,'cast':PzJpUWCRLDjfoxtgyNTbqIQOXneAFc,'director':PzJpUWCRLDjfoxtgyNTbqIQOXneAFK,'genre':PzJpUWCRLDjfoxtgyNTbqIQOXneAFM,'duration':PzJpUWCRLDjfoxtgyNTbqIQOXneAkm,'mpaa':PzJpUWCRLDjfoxtgyNTbqIQOXneAmw,'year':PzJpUWCRLDjfoxtgyNTbqIQOXneAFh,'aired':PzJpUWCRLDjfoxtgyNTbqIQOXneAmM,'plot':'%s\n\n%s'%(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFd)}
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='vod':
    PzJpUWCRLDjfoxtgyNTbqIQOXneAkv=PzJpUWCRLDjfoxtgyNTbqIQOXneABs.get('program')
    PzJpUWCRLDjfoxtgyNTbqIQOXneAku='tvshow'
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':'EPISODE','programcode':PzJpUWCRLDjfoxtgyNTbqIQOXneAkv,'page':'1',}
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsc=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF
   else:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAkv=PzJpUWCRLDjfoxtgyNTbqIQOXneABs.get('movie')
    PzJpUWCRLDjfoxtgyNTbqIQOXneAku='movie'
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':'MOVIE','mediacode':PzJpUWCRLDjfoxtgyNTbqIQOXneAkv,'stype':'movie','title':PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,'thumbnail':PzJpUWCRLDjfoxtgyNTbqIQOXneAFr,}
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsc=PzJpUWCRLDjfoxtgyNTbqIQOXneAum
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_settings_makebookmark():
    PzJpUWCRLDjfoxtgyNTbqIQOXneAma={'videoid':PzJpUWCRLDjfoxtgyNTbqIQOXneAkv,'vidtype':PzJpUWCRLDjfoxtgyNTbqIQOXneAku,'vtitle':PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,'vsubtitle':'',}
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmV=json.dumps(PzJpUWCRLDjfoxtgyNTbqIQOXneAma)
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmV=urllib.parse.quote(PzJpUWCRLDjfoxtgyNTbqIQOXneAmV)
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmi='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(PzJpUWCRLDjfoxtgyNTbqIQOXneAmV)
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmG=[('(통합) 찜 영상에 추가',PzJpUWCRLDjfoxtgyNTbqIQOXneAmi)]
   else:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmG=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel='',img=PzJpUWCRLDjfoxtgyNTbqIQOXneAFr,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAmF,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAsc,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY,isLink=PzJpUWCRLDjfoxtgyNTbqIQOXneAum,ContextMenu=PzJpUWCRLDjfoxtgyNTbqIQOXneAmG)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFG:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['mode'] ='SEARCH' 
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['search_key']=PzJpUWCRLDjfoxtgyNTbqIQOXneAkV
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY['page'] =PzJpUWCRLDjfoxtgyNTbqIQOXneAuE(PzJpUWCRLDjfoxtgyNTbqIQOXneAFV+1)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa='[B]%s >>[/B]'%'다음 페이지'
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmk=PzJpUWCRLDjfoxtgyNTbqIQOXneAuE(PzJpUWCRLDjfoxtgyNTbqIQOXneAFV+1)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel=PzJpUWCRLDjfoxtgyNTbqIQOXneAmk,img=PzJpUWCRLDjfoxtgyNTbqIQOXneAsd,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='movie':xbmcplugin.setContent(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,'movies')
  else:xbmcplugin.setContent(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,cacheToDisc=PzJpUWCRLDjfoxtgyNTbqIQOXneAum)
 def Delete_List_File(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFE,skey='-'):
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='ALL':
   try:
    PzJpUWCRLDjfoxtgyNTbqIQOXneABm=PzJpUWCRLDjfoxtgyNTbqIQOXneAwH
    fp=PzJpUWCRLDjfoxtgyNTbqIQOXneAuH(PzJpUWCRLDjfoxtgyNTbqIQOXneABm,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='ONE':
   try:
    PzJpUWCRLDjfoxtgyNTbqIQOXneABm=PzJpUWCRLDjfoxtgyNTbqIQOXneAwH
    PzJpUWCRLDjfoxtgyNTbqIQOXneABk=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.Load_List_File('search') 
    fp=PzJpUWCRLDjfoxtgyNTbqIQOXneAuH(PzJpUWCRLDjfoxtgyNTbqIQOXneABm,'w',-1,'utf-8')
    for PzJpUWCRLDjfoxtgyNTbqIQOXneABv in PzJpUWCRLDjfoxtgyNTbqIQOXneABk:
     PzJpUWCRLDjfoxtgyNTbqIQOXneABu=PzJpUWCRLDjfoxtgyNTbqIQOXneAuB(urllib.parse.parse_qsl(PzJpUWCRLDjfoxtgyNTbqIQOXneABv))
     PzJpUWCRLDjfoxtgyNTbqIQOXneABE=PzJpUWCRLDjfoxtgyNTbqIQOXneABu.get('skey').strip()
     if skey!=PzJpUWCRLDjfoxtgyNTbqIQOXneABE:
      fp.write(PzJpUWCRLDjfoxtgyNTbqIQOXneABv)
    fp.close()
   except:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAFE in['vod','movie']:
   try:
    PzJpUWCRLDjfoxtgyNTbqIQOXneABm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PzJpUWCRLDjfoxtgyNTbqIQOXneAFE))
    fp=PzJpUWCRLDjfoxtgyNTbqIQOXneAuH(PzJpUWCRLDjfoxtgyNTbqIQOXneABm,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
 def dp_Listfile_Delete(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('stype')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAkM =PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('skey')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwr=xbmcgui.Dialog()
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='ALL':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFk=PzJpUWCRLDjfoxtgyNTbqIQOXneAwr.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='ONE':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFk=PzJpUWCRLDjfoxtgyNTbqIQOXneAwr.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAFE in['vod','movie']:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAFk=PzJpUWCRLDjfoxtgyNTbqIQOXneAwr.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFk==PzJpUWCRLDjfoxtgyNTbqIQOXneAum:sys.exit()
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.Delete_List_File(PzJpUWCRLDjfoxtgyNTbqIQOXneAFE,skey=PzJpUWCRLDjfoxtgyNTbqIQOXneAkM)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFE): 
  try:
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='search':
    PzJpUWCRLDjfoxtgyNTbqIQOXneABm=PzJpUWCRLDjfoxtgyNTbqIQOXneAwH
   elif PzJpUWCRLDjfoxtgyNTbqIQOXneAFE in['vod','movie']:
    PzJpUWCRLDjfoxtgyNTbqIQOXneABm=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PzJpUWCRLDjfoxtgyNTbqIQOXneAFE))
   else:
    return[]
   fp=PzJpUWCRLDjfoxtgyNTbqIQOXneAuH(PzJpUWCRLDjfoxtgyNTbqIQOXneABm,'r',-1,'utf-8')
   PzJpUWCRLDjfoxtgyNTbqIQOXneABl=fp.readlines()
   fp.close()
  except:
   PzJpUWCRLDjfoxtgyNTbqIQOXneABl=[]
  return PzJpUWCRLDjfoxtgyNTbqIQOXneABl
 def Save_Watched_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFE,PzJpUWCRLDjfoxtgyNTbqIQOXneAwG):
  try:
   PzJpUWCRLDjfoxtgyNTbqIQOXneABH=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PzJpUWCRLDjfoxtgyNTbqIQOXneAFE))
   PzJpUWCRLDjfoxtgyNTbqIQOXneABk=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.Load_List_File(PzJpUWCRLDjfoxtgyNTbqIQOXneAFE) 
   fp=PzJpUWCRLDjfoxtgyNTbqIQOXneAuH(PzJpUWCRLDjfoxtgyNTbqIQOXneABH,'w',-1,'utf-8')
   PzJpUWCRLDjfoxtgyNTbqIQOXneABa=urllib.parse.urlencode(PzJpUWCRLDjfoxtgyNTbqIQOXneAwG)
   PzJpUWCRLDjfoxtgyNTbqIQOXneABa=PzJpUWCRLDjfoxtgyNTbqIQOXneABa+'\n'
   fp.write(PzJpUWCRLDjfoxtgyNTbqIQOXneABa)
   PzJpUWCRLDjfoxtgyNTbqIQOXneABV=0
   for PzJpUWCRLDjfoxtgyNTbqIQOXneABv in PzJpUWCRLDjfoxtgyNTbqIQOXneABk:
    PzJpUWCRLDjfoxtgyNTbqIQOXneABu=PzJpUWCRLDjfoxtgyNTbqIQOXneAuB(urllib.parse.parse_qsl(PzJpUWCRLDjfoxtgyNTbqIQOXneABv))
    PzJpUWCRLDjfoxtgyNTbqIQOXneABi=PzJpUWCRLDjfoxtgyNTbqIQOXneAwG.get('code').strip()
    PzJpUWCRLDjfoxtgyNTbqIQOXneABG=PzJpUWCRLDjfoxtgyNTbqIQOXneABu.get('code').strip()
    if PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='vod' and PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_settings_direct_replay()==PzJpUWCRLDjfoxtgyNTbqIQOXneAuF:
     PzJpUWCRLDjfoxtgyNTbqIQOXneABi=PzJpUWCRLDjfoxtgyNTbqIQOXneAwG.get('videoid').strip()
     PzJpUWCRLDjfoxtgyNTbqIQOXneABG=PzJpUWCRLDjfoxtgyNTbqIQOXneABu.get('videoid').strip()if PzJpUWCRLDjfoxtgyNTbqIQOXneABG!=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw else '-'
    if PzJpUWCRLDjfoxtgyNTbqIQOXneABi!=PzJpUWCRLDjfoxtgyNTbqIQOXneABG:
     fp.write(PzJpUWCRLDjfoxtgyNTbqIQOXneABv)
     PzJpUWCRLDjfoxtgyNTbqIQOXneABV+=1
     if PzJpUWCRLDjfoxtgyNTbqIQOXneABV>=50:break
   fp.close()
  except:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
 def dp_Watch_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFE =PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('stype')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsu=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_settings_direct_replay()
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='-':
   for PzJpUWCRLDjfoxtgyNTbqIQOXneAFH in PzJpUWCRLDjfoxtgyNTbqIQOXneAwk:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsa=PzJpUWCRLDjfoxtgyNTbqIQOXneAFH.get('title')
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':PzJpUWCRLDjfoxtgyNTbqIQOXneAFH.get('mode'),'stype':PzJpUWCRLDjfoxtgyNTbqIQOXneAFH.get('stype')}
    PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel='',img='',infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAuw,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAuv(PzJpUWCRLDjfoxtgyNTbqIQOXneAwk)>0:xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle)
  else:
   PzJpUWCRLDjfoxtgyNTbqIQOXneABS=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.Load_List_File(PzJpUWCRLDjfoxtgyNTbqIQOXneAFE)
   for PzJpUWCRLDjfoxtgyNTbqIQOXneABr in PzJpUWCRLDjfoxtgyNTbqIQOXneABS:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAkK=PzJpUWCRLDjfoxtgyNTbqIQOXneAuB(urllib.parse.parse_qsl(PzJpUWCRLDjfoxtgyNTbqIQOXneABr))
    PzJpUWCRLDjfoxtgyNTbqIQOXneABd =PzJpUWCRLDjfoxtgyNTbqIQOXneAkK.get('code').strip()
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsa =PzJpUWCRLDjfoxtgyNTbqIQOXneAkK.get('title').strip()
    PzJpUWCRLDjfoxtgyNTbqIQOXneAFr=PzJpUWCRLDjfoxtgyNTbqIQOXneAkK.get('img').strip()
    PzJpUWCRLDjfoxtgyNTbqIQOXneAkv =PzJpUWCRLDjfoxtgyNTbqIQOXneAkK.get('videoid').strip()
    try:
     PzJpUWCRLDjfoxtgyNTbqIQOXneAFr=PzJpUWCRLDjfoxtgyNTbqIQOXneAFr.replace('\'','\"')
     PzJpUWCRLDjfoxtgyNTbqIQOXneAFr=json.loads(PzJpUWCRLDjfoxtgyNTbqIQOXneAFr)
    except:
     PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmF={}
    PzJpUWCRLDjfoxtgyNTbqIQOXneAmF['plot']=PzJpUWCRLDjfoxtgyNTbqIQOXneAsa
    if PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='vod':
     if PzJpUWCRLDjfoxtgyNTbqIQOXneAsu==PzJpUWCRLDjfoxtgyNTbqIQOXneAum or PzJpUWCRLDjfoxtgyNTbqIQOXneAkv==PzJpUWCRLDjfoxtgyNTbqIQOXneAuw:
      PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':'EPISODE','programcode':PzJpUWCRLDjfoxtgyNTbqIQOXneABd,'page':'1'}
      PzJpUWCRLDjfoxtgyNTbqIQOXneAsc=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF
     else:
      PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':'VOD','mediacode':PzJpUWCRLDjfoxtgyNTbqIQOXneAkv,'stype':'vod','programcode':PzJpUWCRLDjfoxtgyNTbqIQOXneABd,'title':PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,'thumbnail':PzJpUWCRLDjfoxtgyNTbqIQOXneAFr}
      PzJpUWCRLDjfoxtgyNTbqIQOXneAsc=PzJpUWCRLDjfoxtgyNTbqIQOXneAum
    else:
     PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':'MOVIE','mediacode':PzJpUWCRLDjfoxtgyNTbqIQOXneABd,'stype':'movie','title':PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,'thumbnail':PzJpUWCRLDjfoxtgyNTbqIQOXneAFr}
     PzJpUWCRLDjfoxtgyNTbqIQOXneAsc=PzJpUWCRLDjfoxtgyNTbqIQOXneAum
    PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel='',img=PzJpUWCRLDjfoxtgyNTbqIQOXneAFr,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAmF,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAsc,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmF={'plot':'시청목록을 삭제합니다.'}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa='*** 시청목록 삭제 ***'
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':'MYVIEW_REMOVE','stype':PzJpUWCRLDjfoxtgyNTbqIQOXneAFE,'skey':'-',}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsd=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel='',img=PzJpUWCRLDjfoxtgyNTbqIQOXneAsd,infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAmF,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAum,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY,isLink=PzJpUWCRLDjfoxtgyNTbqIQOXneAuF)
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAFE=='movie':xbmcplugin.setContent(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,'movies')
   else:xbmcplugin.setContent(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,cacheToDisc=PzJpUWCRLDjfoxtgyNTbqIQOXneAum)
 def Save_Searched_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAkV):
  try:
   PzJpUWCRLDjfoxtgyNTbqIQOXneABY=PzJpUWCRLDjfoxtgyNTbqIQOXneAwH
   PzJpUWCRLDjfoxtgyNTbqIQOXneABk=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.Load_List_File('search') 
   PzJpUWCRLDjfoxtgyNTbqIQOXneABc={'skey':PzJpUWCRLDjfoxtgyNTbqIQOXneAkV.strip()}
   fp=PzJpUWCRLDjfoxtgyNTbqIQOXneAuH(PzJpUWCRLDjfoxtgyNTbqIQOXneABY,'w',-1,'utf-8')
   PzJpUWCRLDjfoxtgyNTbqIQOXneABa=urllib.parse.urlencode(PzJpUWCRLDjfoxtgyNTbqIQOXneABc)
   PzJpUWCRLDjfoxtgyNTbqIQOXneABa=PzJpUWCRLDjfoxtgyNTbqIQOXneABa+'\n'
   fp.write(PzJpUWCRLDjfoxtgyNTbqIQOXneABa)
   PzJpUWCRLDjfoxtgyNTbqIQOXneABV=0
   for PzJpUWCRLDjfoxtgyNTbqIQOXneABv in PzJpUWCRLDjfoxtgyNTbqIQOXneABk:
    PzJpUWCRLDjfoxtgyNTbqIQOXneABu=PzJpUWCRLDjfoxtgyNTbqIQOXneAuB(urllib.parse.parse_qsl(PzJpUWCRLDjfoxtgyNTbqIQOXneABv))
    PzJpUWCRLDjfoxtgyNTbqIQOXneABi=PzJpUWCRLDjfoxtgyNTbqIQOXneABc.get('skey').strip()
    PzJpUWCRLDjfoxtgyNTbqIQOXneABG=PzJpUWCRLDjfoxtgyNTbqIQOXneABu.get('skey').strip()
    if PzJpUWCRLDjfoxtgyNTbqIQOXneABi!=PzJpUWCRLDjfoxtgyNTbqIQOXneABG:
     fp.write(PzJpUWCRLDjfoxtgyNTbqIQOXneABv)
     PzJpUWCRLDjfoxtgyNTbqIQOXneABV+=1
     if PzJpUWCRLDjfoxtgyNTbqIQOXneABV>=50:break
   fp.close()
  except:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
 def play_VIDEO(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.SaveCredential(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_winCredential())
  PzJpUWCRLDjfoxtgyNTbqIQOXneABK =PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('mediacode')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFE =PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('stype')
  PzJpUWCRLDjfoxtgyNTbqIQOXneABM =PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('pvrmode')
  PzJpUWCRLDjfoxtgyNTbqIQOXneABh=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_selQuality(PzJpUWCRLDjfoxtgyNTbqIQOXneAFE)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAvw,PzJpUWCRLDjfoxtgyNTbqIQOXneAvs=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.GetBroadURL(PzJpUWCRLDjfoxtgyNTbqIQOXneABK,PzJpUWCRLDjfoxtgyNTbqIQOXneABh,PzJpUWCRLDjfoxtgyNTbqIQOXneAFE,PzJpUWCRLDjfoxtgyNTbqIQOXneABM)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.addon_log('qt, stype, url : %s - %s - %s'%(PzJpUWCRLDjfoxtgyNTbqIQOXneAuE(PzJpUWCRLDjfoxtgyNTbqIQOXneABh),PzJpUWCRLDjfoxtgyNTbqIQOXneAFE,PzJpUWCRLDjfoxtgyNTbqIQOXneAvw))
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAvw=='':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.addon_noti(__language__(30908).encode('utf8'))
   return
  PzJpUWCRLDjfoxtgyNTbqIQOXneAvF =PzJpUWCRLDjfoxtgyNTbqIQOXneAvw.find('Policy=')
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAvF!=-1:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvm =PzJpUWCRLDjfoxtgyNTbqIQOXneAvw.split('?')[0]
   if 'quickvod-mcdn.tving.com' in PzJpUWCRLDjfoxtgyNTbqIQOXneAvm:
    PzJpUWCRLDjfoxtgyNTbqIQOXneAvm=PzJpUWCRLDjfoxtgyNTbqIQOXneAvw
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvk=PzJpUWCRLDjfoxtgyNTbqIQOXneAuB(urllib.parse.parse_qsl(urllib.parse.urlsplit(PzJpUWCRLDjfoxtgyNTbqIQOXneAvw).query))
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvk=urllib.parse.urlencode(PzJpUWCRLDjfoxtgyNTbqIQOXneAvk)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvk=PzJpUWCRLDjfoxtgyNTbqIQOXneAvk.replace('&',';')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvk=PzJpUWCRLDjfoxtgyNTbqIQOXneAvk.replace('Policy','CloudFront-Policy')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvk=PzJpUWCRLDjfoxtgyNTbqIQOXneAvk.replace('Signature','CloudFront-Signature')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvk=PzJpUWCRLDjfoxtgyNTbqIQOXneAvk.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvB='%s|Cookie=%s'%(PzJpUWCRLDjfoxtgyNTbqIQOXneAvm,PzJpUWCRLDjfoxtgyNTbqIQOXneAvk)
  else:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvB=PzJpUWCRLDjfoxtgyNTbqIQOXneAvw
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.addon_log(PzJpUWCRLDjfoxtgyNTbqIQOXneAvB)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAvu=xbmcgui.ListItem(path=PzJpUWCRLDjfoxtgyNTbqIQOXneAvB)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAvs!='':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvE=PzJpUWCRLDjfoxtgyNTbqIQOXneAvs
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvl ='https://cj.drmkeyserver.com/widevine_license'
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvH ='mpd'
   PzJpUWCRLDjfoxtgyNTbqIQOXneAva ='com.widevine.alpha'
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvV =inputstreamhelper.Helper(PzJpUWCRLDjfoxtgyNTbqIQOXneAvH,drm='widevine')
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAvV.check_inputstream():
    PzJpUWCRLDjfoxtgyNTbqIQOXneAvi={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%PzJpUWCRLDjfoxtgyNTbqIQOXneABK,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.USER_AGENT,'AcquireLicenseAssertion':PzJpUWCRLDjfoxtgyNTbqIQOXneAvE,'Host':'cj.drmkeyserver.com'}
    PzJpUWCRLDjfoxtgyNTbqIQOXneAvG=PzJpUWCRLDjfoxtgyNTbqIQOXneAvl+'|'+urllib.parse.urlencode(PzJpUWCRLDjfoxtgyNTbqIQOXneAvi)+'|R{SSM}|'
    PzJpUWCRLDjfoxtgyNTbqIQOXneAvu.setProperty('inputstream',PzJpUWCRLDjfoxtgyNTbqIQOXneAvV.inputstream_addon)
    PzJpUWCRLDjfoxtgyNTbqIQOXneAvu.setProperty('inputstream.adaptive.manifest_type',PzJpUWCRLDjfoxtgyNTbqIQOXneAvH)
    PzJpUWCRLDjfoxtgyNTbqIQOXneAvu.setProperty('inputstream.adaptive.license_type',PzJpUWCRLDjfoxtgyNTbqIQOXneAva)
    PzJpUWCRLDjfoxtgyNTbqIQOXneAvu.setProperty('inputstream.adaptive.license_key',PzJpUWCRLDjfoxtgyNTbqIQOXneAvG)
    PzJpUWCRLDjfoxtgyNTbqIQOXneAvu.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.USER_AGENT))
  elif 'quickvod-mcdn.tving.com' in PzJpUWCRLDjfoxtgyNTbqIQOXneAvB:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvu.setContentLookup(PzJpUWCRLDjfoxtgyNTbqIQOXneAum)
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvu.setMimeType('application/x-mpegURL')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvu.setProperty('inputstream','inputstream.ffmpegdirect')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvu.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvu.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvu.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvu.setProperty('ResumeTime','0')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvu.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,PzJpUWCRLDjfoxtgyNTbqIQOXneAuF,PzJpUWCRLDjfoxtgyNTbqIQOXneAvu)
  try:
   if PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('mode')in['VOD','MOVIE']and PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('title'):
    PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'code':PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('programcode')if PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('mode')=='VOD' else PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('mediacode'),'img':PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('thumbnail'),'title':PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('title'),'videoid':PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('mediacode')}
    PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.Save_Watched_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('stype'),PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
  except:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
 def logout(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwr=xbmcgui.Dialog()
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFk=PzJpUWCRLDjfoxtgyNTbqIQOXneAwr.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFk==PzJpUWCRLDjfoxtgyNTbqIQOXneAum:sys.exit()
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.wininfo_clear()
  if os.path.isfile(PzJpUWCRLDjfoxtgyNTbqIQOXneAwl):os.remove(PzJpUWCRLDjfoxtgyNTbqIQOXneAwl)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE=xbmcgui.Window(10000)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_TOKEN','')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_USERINFO','')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_UUID','')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_LOGINTIME','')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_MAINTOKEN','')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_COOKIEKEY','')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAvS =PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.Get_Now_Datetime()
  PzJpUWCRLDjfoxtgyNTbqIQOXneAvr=PzJpUWCRLDjfoxtgyNTbqIQOXneAvS+datetime.timedelta(days=PzJpUWCRLDjfoxtgyNTbqIQOXneAus(__addon__.getSetting('cache_ttl')))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE=xbmcgui.Window(10000)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAvd={'tving_token':PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.getProperty('TVING_M_TOKEN'),'tving_userinfo':PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.getProperty('TVING_M_USERINFO'),'tving_uuid':PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':PzJpUWCRLDjfoxtgyNTbqIQOXneAvr.strftime('%Y-%m-%d'),'tving_maintoken':PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=PzJpUWCRLDjfoxtgyNTbqIQOXneAuH(PzJpUWCRLDjfoxtgyNTbqIQOXneAwl,'w',-1,'utf-8')
   json.dump(PzJpUWCRLDjfoxtgyNTbqIQOXneAvd,fp)
   fp.close()
  except PzJpUWCRLDjfoxtgyNTbqIQOXneAua as exception:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAuV(exception)
 def cookiefile_check(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAvd={}
  try: 
   fp=PzJpUWCRLDjfoxtgyNTbqIQOXneAuH(PzJpUWCRLDjfoxtgyNTbqIQOXneAwl,'r',-1,'utf-8')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvd= json.load(fp)
   fp.close()
  except PzJpUWCRLDjfoxtgyNTbqIQOXneAua as exception:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.wininfo_clear()
   return PzJpUWCRLDjfoxtgyNTbqIQOXneAum
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsh =__addon__.getSetting('id')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFw =__addon__.getSetting('pw')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAvY=__addon__.getSetting('login_type')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAvc =__addon__.getSetting('selected_profile')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_id']=base64.standard_b64decode(PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_id']).decode('utf-8')
  PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_pw']=base64.standard_b64decode(PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_pw']).decode('utf-8')
  try:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_profile']
  except:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_profile']='0'
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAsh!=PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_id']or PzJpUWCRLDjfoxtgyNTbqIQOXneAFw!=PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_pw']or PzJpUWCRLDjfoxtgyNTbqIQOXneAvY!=PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_logintype']or PzJpUWCRLDjfoxtgyNTbqIQOXneAvc!=PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_profile']:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.wininfo_clear()
   return PzJpUWCRLDjfoxtgyNTbqIQOXneAum
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFB =PzJpUWCRLDjfoxtgyNTbqIQOXneAus(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  PzJpUWCRLDjfoxtgyNTbqIQOXneAvK=PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_limitdate']
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFv =PzJpUWCRLDjfoxtgyNTbqIQOXneAus(re.sub('-','',PzJpUWCRLDjfoxtgyNTbqIQOXneAvK))
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAFv<PzJpUWCRLDjfoxtgyNTbqIQOXneAFB:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.wininfo_clear()
   return PzJpUWCRLDjfoxtgyNTbqIQOXneAum
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE=xbmcgui.Window(10000)
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_TOKEN',PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_token'])
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_USERINFO',PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_userinfo'])
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_UUID',PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_uuid'])
  PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_LOGINTIME',PzJpUWCRLDjfoxtgyNTbqIQOXneAvK)
  try:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_MAINTOKEN',PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_maintoken'])
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_COOKIEKEY',PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_cookiekey'])
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_LOCKKEY',PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_lockkey'])
  except:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_MAINTOKEN',PzJpUWCRLDjfoxtgyNTbqIQOXneAvd['tving_token'])
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_COOKIEKEY','Y')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsE.setProperty('TVING_M_LOCKKEY','N')
  return PzJpUWCRLDjfoxtgyNTbqIQOXneAuF
 def dp_Global_Search(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAki=PzJpUWCRLDjfoxtgyNTbqIQOXneAFa.get('mode')
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAki=='TOTAL_SEARCH':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvM='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAvM='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(PzJpUWCRLDjfoxtgyNTbqIQOXneAvM)
 def dp_Bookmark_Menu(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAvM='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(PzJpUWCRLDjfoxtgyNTbqIQOXneAvM)
 def dp_EuroLive_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa,PzJpUWCRLDjfoxtgyNTbqIQOXneAFa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.SaveCredential(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.get_winCredential())
  PzJpUWCRLDjfoxtgyNTbqIQOXneAFi=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.TvingObj.GetEuroChannelList()
  for PzJpUWCRLDjfoxtgyNTbqIQOXneAFS in PzJpUWCRLDjfoxtgyNTbqIQOXneAFi:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmH =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('channel')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsa =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('title')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmk =PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('subtitle')
   PzJpUWCRLDjfoxtgyNTbqIQOXneAmF={'mediatype':'episode','title':PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,'plot':'%s\n%s'%(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,PzJpUWCRLDjfoxtgyNTbqIQOXneAmk)}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAsY={'mode':'LIVE','mediacode':PzJpUWCRLDjfoxtgyNTbqIQOXneAFS.get('channel'),'stype':'onair',}
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.add_dir(PzJpUWCRLDjfoxtgyNTbqIQOXneAsa,sublabel=PzJpUWCRLDjfoxtgyNTbqIQOXneAmk,img='',infoLabels=PzJpUWCRLDjfoxtgyNTbqIQOXneAmF,isFolder=PzJpUWCRLDjfoxtgyNTbqIQOXneAum,params=PzJpUWCRLDjfoxtgyNTbqIQOXneAsY)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAuv(PzJpUWCRLDjfoxtgyNTbqIQOXneAFi)>0:xbmcplugin.endOfDirectory(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa._addon_handle,cacheToDisc=PzJpUWCRLDjfoxtgyNTbqIQOXneAum)
 def tving_main(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa):
  PzJpUWCRLDjfoxtgyNTbqIQOXneAki=PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params.get('mode',PzJpUWCRLDjfoxtgyNTbqIQOXneAuw)
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAki=='LOGOUT':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.logout()
   return
  PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.login_main()
  if PzJpUWCRLDjfoxtgyNTbqIQOXneAki is PzJpUWCRLDjfoxtgyNTbqIQOXneAuw:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_Main_List()
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_Title_Group(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki in['GLOBAL_GROUP']:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_SubTitle_Group(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki=='CHANNEL':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_LiveChannel_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki in['LIVE','VOD','MOVIE']:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.play_VIDEO(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki=='PROGRAM':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_Program_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki=='EPISODE':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_Episode_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki=='MOVIE_SUB':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_Movie_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki=='SEARCH_GROUP':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_Search_Group(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki in['SEARCH','LOCAL_SEARCH']:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_Search_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki=='WATCH':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_Watch_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_Listfile_Delete(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki=='ORDER_BY':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_setEpOrderby(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki=='SET_BOOKMARK':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_Set_Bookmark(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki in['TOTAL_SEARCH','TOTAL_HISTORY']:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_Global_Search(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki=='SEARCH_HISTORY':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_Search_History(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki=='MENU_BOOKMARK':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_Bookmark_Menu(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  elif PzJpUWCRLDjfoxtgyNTbqIQOXneAki=='EURO_GROUP':
   PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.dp_EuroLive_List(PzJpUWCRLDjfoxtgyNTbqIQOXneAwa.main_params)
  else:
   PzJpUWCRLDjfoxtgyNTbqIQOXneAuw
# Created by pyminifier (https://github.com/liftoff/pyminifier)
