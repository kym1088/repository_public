_R='0.0.0.0'
_Q='headers'
_P='postData'
_O='last_type'
_N='scheme'
_M='Content-Type'
_L='url_filename'
_K='content-length'
_J='last_path'
_I='proxy-mini'
_H='playOption'
_G='path'
_F='url'
_E='utf-8'
_D=None
_C=True
_B=False
_A='addon'
import threading
from http.server import HTTPServer,BaseHTTPRequestHandler
import requests,urllib,json,base64,re,xml.etree.ElementTree as ET,os,time
try:from Cryptodome.Cipher import PKCS1_OAEP,AES;from Cryptodome.Util import Padding
except ImportError:from Crypto.Cipher import PKCS1_OAEP,AES;from Crypto.Util import Padding
REMOVE_IN_HEADERS=[_I,'host','referer','upgrade']
REMOVE_OUT_HEADERS=['date','server','set-cookie','keep-alive','connection','transfer-encoding','content-encoding',_K]
def Addon_Log(string):
	A=string
	try:import xbmc as B,xbmcaddon as C,xbmcvfs;D=A.encode(_E,'ignore');E=B.LOGINFO;B.log('[%s]: %s'%(C.Addon().getAddonInfo('id'),D),level=E)
	except:print(A)
class BoriProxyHandler(BaseHTTPRequestHandler):
	def __init__(A,request,client_address,server):
		A.HTTP_CLIENT=requests.Session();A.REQ_INFO={}
		try:BaseHTTPRequestHandler.__init__(A,request,client_address,server)
		except(IOError,OSError)as B:pass
	def log_message(A,format,*B):0
	def Make_Header(D,header_exceptList=[]):
		A=header_exceptList;B={};A.extend(REMOVE_IN_HEADERS)
		for(C,E)in dict(D.headers).items():
			if C.lower()not in A:B[C.lower()]=E
		return B
	def Make_NewUrl(B,scheme,netloc,path,params='',query='',fragemnt=''):A=scheme,netloc,path,params,query,fragemnt;return urllib.parse.urlunparse(A)
	def Send_BlankImage(A):A.send_response(200);A.send_header(_M,'image/x-icon');A.send_header('Content-Length',0);A.end_headers()
	def Send_ErrorPage(A):A.send_response(200);A.send_header(_M,'text/html; charset=UTF-8');A.end_headers();A.wfile.write('request error!'.encode(_E))
	def Parse_BaseRequest(A):
		E='query';D='/';A.REQ_INFO={}
		try:
			A.REQ_INFO[_F]=A.path.strip(D);C=urllib.parse.urlparse(A.REQ_INFO[_F]);A.REQ_INFO[_N]=C.scheme;A.REQ_INFO['netloc']=C.netloc;A.REQ_INFO[_G]=C.path.strip(D).split(D);A.REQ_INFO[_J]=A.REQ_INFO[_G][len(A.REQ_INFO[_G])-1];A.REQ_INFO[E]=dict(urllib.parse.parse_qsl(C.query));F=A.REQ_INFO[_J].split('.');A.REQ_INFO[_O]=F[len(F)-1];G=int(dict(A.headers).get(_K,0));A.REQ_INFO[_P]=A.rfile.read(G)if G else _D;B={}
			if _I in dict(A.headers):B=dict(A.headers).get(_I)
			elif _I in A.REQ_INFO[E]:B=A.REQ_INFO[E].get(_I)
			if B:B=B.replace(' ','+');A.REQ_INFO[_A]=json.loads(base64.standard_b64decode(B).decode(_E));Addon_Log('proxyData 111111')
			else:A.REQ_INFO[_A]={_A:'',_H:{},_L:''}
		except Exception as H:print(Exception);A.REQ_INFO[_A]={_A:'',_H:{},_L:''};return _B
		return _C
	def Output_Headers(A,response):
		B=response;A.send_response(B.status_code)
		for C in list(B.headers.items()):A.send_header(C[0],C[1])
		A.end_headers()
	def Output_Response(B,response,res_data=_D,header_exceptList=[],binType=_B):
		F=binType;D=res_data;A=response
		for E in list(A.headers.items()):
			if E[0].lower()in REMOVE_OUT_HEADERS or E[0].lower()in header_exceptList:A.headers.pop(E[0],_D)
		if D and F==_B:C=D.encode(_E);A.headers[_K]=str(len(C));B.Output_Headers(A);B.wfile.write(C)
		elif D and F==_C:C=D;A.headers[_K]=str(len(C));B.Output_Headers(A);B.wfile.write(C)
		else:
			B.Output_Headers(A)
			for G in A.iter_content(1048576):
				try:B.wfile.write(G)
				except Exception as H:print(H);break
	def do_HEAD(A):A.send_response(200)
	def do_POST(A):
		if A.Parse_BaseRequest()==_B:A.send_response(404);return
		try:B=requests.post(url=A.REQ_INFO[_F],headers=A.Make_Header(),data=A.REQ_INFO[_P],stream=_C)
		except Exception as C:print(C);A.Send_ErrorPage();return
		A.Output_Response(B,res_data=_D,header_exceptList=[])
	def Make_DecryptKey(C,step,mediacode='000',timecode='000'):
		if step=='1':A=bytes('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),_E);B=bytes('6yhlJ4WF9ZIj6I8n',_E)
		else:A=bytes('kss2lym0kdw1lks3',_E);B=bytes([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
		return A,B
	def DecryptPlaintext(C,ciphertext,encryption_key,init_vector):A=AES.new(encryption_key,AES.MODE_CBC,init_vector);B=Padding.unpad(A.decrypt(base64.standard_b64decode(ciphertext)),16);return B.decode(_E)
	def Decrypt_Url(A,ciphertext,mediacode,timecode):
		E=timecode;D=mediacode;F=''
		try:B,C=A.Make_DecryptKey('1',mediacode=D,timecode=E);G=json.loads(A.DecryptPlaintext(ciphertext,B,C));H=G.get(_F);B,C=A.Make_DecryptKey('2',mediacode=D,timecode=E);F=A.DecryptPlaintext(H,B,C)
		except Exception as I:print(I)
		return F
	def renew_live_mpd(B,resText,mediacode):
		try:C=str(int(time.time()));D=json.loads(resText);A=D['body']['stream']['playback']['drm']['widevine'];A=A.split('|')[1];A=B.Decrypt_Url(A,mediacode,C);E=requests.get(url=A,headers=B.REQ_INFO.get(_A).get(_Q));F=E.text;return F
		except Exception as G:print(G);return''
	def do_GET(A):
		I='content-type';H='streamFilename';G='do_get reuests call error';F='tvingm'
		if A.Parse_BaseRequest()==_B:A.send_response(404);return
		if A.REQ_INFO[_J].lower()=='favicon.ico':A.Send_BlankImage();return
		if A.REQ_INFO[_J].lower()=='live.mpd'and len(A.REQ_INFO[_G])==1 and A.REQ_INFO.get(_A).get(_A)==F:L=A.REQ_INFO.get(_A).get('get_url');M=A.REQ_INFO.get(_A).get(_Q);N=A.REQ_INFO.get(_A).get('params');O=A.REQ_INFO.get(_A).get('cookies');B=requests.post(url=L,params=N,headers=M,cookies=O);C=A.renew_live_mpd(B.text,A.REQ_INFO.get(_A).get('mediacode'));A.Output_Response(B,C,header_exceptList=[],binType=_B);return
		if A.REQ_INFO[_N].lower()not in['http','https']:A.send_response(404);return
		C=_D
		try:
			if A.REQ_INFO[_G][len(A.REQ_INFO[_G])-2].startswith('QualityLevels(1000,as=KO)')and A.REQ_INFO[_G][len(A.REQ_INFO[_G])-1].startswith('Fragments(KO=')and A.REQ_INFO.get(_A).get(_A)==F:
				try:B=requests.get(url=A.REQ_INFO[_F],headers=A.Make_Header(),stream=_B)
				except Exception as D:print(D);Addon_Log(G);A.Send_ErrorPage();return
				if'<p begin="'in B.text:Addon_Log('**  Tving_Parse_subtitle **');P=B.text;C=A.Tving_Parse_subtitle(P)
				A.Output_Response(B,C,header_exceptList=[],binType=_B)
			elif A.REQ_INFO[_O].lower()in['mpd']and A.REQ_INFO.get(_A).get(_A)==F:
				try:B=requests.get(url=A.REQ_INFO[_F],headers=A.Make_Header(),stream=_B)
				except Exception as D:print(D);Addon_Log(G);A.Send_ErrorPage();return
				Addon_Log('mpd os.isfile')
				if os.path.isfile(A.REQ_INFO[_A][_H][H]):
					try:E=open(A.REQ_INFO[_A][_H][H],'r',-1,_E);C=E.read();E.close()
					except:C=_D
				else:Q=B.text;C=Q
				A.Output_Response(B,C,header_exceptList=[],binType=_B)
			elif A.REQ_INFO[_J].lower()in A.REQ_INFO.get(_A).get(_L)and A.REQ_INFO.get(_A).get(_A)==F:
				try:B=requests.get(url=A.REQ_INFO[_F],headers=_D,stream=_C)
				except Exception as D:print(D);Addon_Log(G);A.Send_ErrorPage();return
				print(A.REQ_INFO[_F]);K=B.text;C=_D
				if os.path.isfile(A.REQ_INFO[_A][_H][H]):
					Addon_Log('do_get : m3u8   os.isfile')
					if'#EXTM3U'in K and'#EXT-X-STREAM-INF'in K:
						Addon_Log('do_get : if m3u8  EXT-X-STREAM-INF')
						try:E=open(A.REQ_INFO[_A][_H][H],'r',-1,_E);C=E.read();E.close()
						except:_D
					A.Output_Response(B,C,header_exceptList=[],binType=_B)
				else:A.Output_Response(B,C,header_exceptList=[],binType=_C)
			else:
				C=_D
				try:B=requests.get(url=A.REQ_INFO[_F],headers=A.Make_Header(),stream=_C)
				except Exception as D:print(D);Addon_Log(G);A.Send_ErrorPage();return
				if B.headers[I].lower()in['video/mp2t','binary/octet-stream']or'octet-stream'in B.headers[I].lower()or'binary'in B.headers[I].lower()or'video'in B.headers[I].lower():C=B.content;J=_C
				else:
					try:C=B.content.decode(_E);J=_B
					except:C=B.content;J=_C
				A.Output_Response(B,C,header_exceptList=[],binType=J)
		except Exception as D:print(D);return
	def Tving_Parse_subtitle(L,subtitle):
		J='</p>';I='<p begin=';H=b'\n';F=b'';K=subtitle.split(H);A=F;D=F;C=_B
		for B in K:
			try:E=B.decode();G=_C
			except:G=_B
			if C==_B and A!=F:A+=H
			if G==_B:A+=B;C=_B
			elif E.strip().startswith(I)==_C and E.strip().endswith(J)==_C:A+=B;C=_B
			elif E.strip().startswith(I)==_C:D=B;C=_C
			elif E.strip().endswith(J)==_C:D+=b' '+B;C=_B;A+=D
			elif C==_C:D+=+b'  '+B
			else:A+=B;D=''
		return A
	def indent(D,elem,level=0):
		C=level;A=elem;B='\n'+C*'  '
		if len(A):
			if not A.text or not A.text.strip():A.text=B+'  '
			if not A.tail or not A.tail.strip():A.tail=B
			for A in A:D.indent(A,C+1)
			if not A.tail or not A.tail.strip():A.tail=B
		elif C and(not A.tail or not A.tail.strip()):A.tail=B
	def _gzip(E,data=_D):from io import BytesIO as C;from gzip import GzipFile as D;A=C();B=D(fileobj=A,mode='w',compresslevel=5);B.write(data);B.close();return A.getvalue()
class TvingProxy:
	def __init__(A):A.started=_B;A.PORT=_D
	def start(A):
		if A.started:return
		A._server=HTTPServer((_R,A.PORT),BoriProxyHandler);A._httpd_thread=threading.Thread(target=A._server.serve_forever);A._httpd_thread.start();A.started=_C
	def stop(A):
		if not A.started:return
		A._server.shutdown();A._server.server_close();A._server.socket.close();A._httpd_thread.join();A.started=_B
if __name__=='__main__':TEST_PORT=9999;httpd=HTTPServer((_R,TEST_PORT),BoriProxyHandler);print(f"Server running on port : {TEST_PORT}");httpd.serve_forever()