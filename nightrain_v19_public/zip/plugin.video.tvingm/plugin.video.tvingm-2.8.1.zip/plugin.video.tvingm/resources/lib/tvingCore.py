_B5='VOD_BASIC_RANKING'
_B4='/_next/data/{}/ko/more/special/SP0071.json'
_B3='https://gw.tving.com'
_B2='genreCode'
_B1='Second Step - except error'
_B0='drm_license_data'
_A_='/v3/media/stream/info'
_Az='mediacode'
_Ay='h264|hevc'
_Ax='6yhlJ4WF9ZIj6I8n'
_Aw='kss2lym0kdw1lks3'
_Av='user-agent'
_Au='_tving_token'
_At='token'
_As='nextApiUrl'
_Ar='studio'
_Aq='aired'
_Ap='CAIP1900'
_Ao='CAIP2000'
_An='CAIP1800'
_Am='CAIP0200'
_Al='CAIP0900'
_Ak='scope'
_Aj='guest'
_Ai='adult'
_Ah='cacheType'
_Ag='url_filename'
_Af='subtitleYn'
_Ae='header'
_Ad='streamType'
_Ac='authType'
_Ab='audioTypes'
_Aa='videoTypes'
_AZ='model'
_AY='networkCode'
_AX='apiKey'
_AW='refreshToken'
_AV='bandType'
_AU='pages'
_AT='movie'
_AS='items'
_AR='banner'
_AQ='icon'
_AP='info_genre'
_AO='frequency'
_AN='access-token'
_AM='HTML5'
_AL='PC_Chrome'
_AK='callingFrom'
_AJ='noCache'
_AI='streamCode'
_AH='deviceInfo'
_AG='uuid'
_AF='deviceId'
_AE='mediaCode'
_AD='screenCode'
_AC='osCode'
_AB='authToken'
_AA='state'
_A9='queries'
_A8='dehydratedState'
_A7='duration'
_A6='vod'
_A5='imageUrl'
_A4='premiered'
_A3='grade_code'
_A2='pageNo'
_A1='bands'
_A0='bandCode'
_z='genre'
_y='desc'
_x='clearlogo'
_w='channel'
_v='order'
_u='playback'
_t='drm_header_value'
_s='drm_header_key'
_r='drm_server_url'
_q='error_msg'
_p='mpaa'
_o='year'
_n='cast'
_m='%s-%s-%s'
_l='product_year'
_k='image'
_j='pageSize'
_i='Y'
_h='broad_dt'
_g='category2_name'
_f='category1_name'
_e='fanart'
_d='tving_uuid'
_c='account'
_b='accessToken'
_a='thumb'
_Z='actor'
_Y='synopsis'
_X='name'
_W='result'
_V='pageProps'
_U='episode'
_T='poster'
_S='cookies'
_R='0'
_Q='all'
_P='director'
_O='streaming_url'
_N='data'
_M='Get'
_L='body'
_K='-'
_J=True
_I='thumbnail'
_H='title'
_G='url'
_F='utf-8'
_E=False
_D='ko'
_C='code'
_B='program'
_A=None
__author__='NightRain'
import urllib,re,json,sys,time,requests,datetime,random,base64,os,xml.etree.ElementTree as ET,xml.dom.minidom,io
'\nimport xbmcplugin, xbmcgui, xbmcaddon, xbmc, xbmcvfs\n__addon__ = xbmcaddon.Addon()\n__language__  = __addon__.getLocalizedString\n__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo(\'profile\'))\n__version__ = __addon__.getAddonInfo(\'version\')\n__addonid__ = __addon__.getAddonInfo(\'id\')\n__addonname__ = __addon__.getAddonInfo(\'name\')\n\n\ndef addon_log( string ):\n\ttry:\n\t\tlog_message = string.encode(\'utf-8\', \'ignore\')\n\texcept:\n\t\tlog_message = \'addonException: addon_log\'\n\tlevel = xbmc.LOGINFO\n\txbmc.log("[%s-%s]: %s" %(__addonid__, __version__, log_message), level=level)\n'
try:from Cryptodome.Cipher import PKCS1_OAEP,AES;from Cryptodome.Util import Padding;print('Cryptodome')
except ImportError:from Crypto.Cipher import PKCS1_OAEP,AES;from Crypto.Util import Padding;print('Crypto')
QUALITY_LIST={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
MPAA_LIST={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
ATTRIBUTE_PATTERN=re.compile('((?:[^,"\']|"[^"]*"|\'[^\']*\')+)')
KEY_LIST=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583',_AB,'cs','TSID',_b,_AW,_Au,'GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7']
class Tving:
	def __init__(A):A.APIKEY='1e7952d0917d6aab1f0293a063697610';A.NETWORKCODE='CSND0900';A.OSCODE='CSOD0900';A.TELECODE='CSCD0900';A.SCREENCODE='CSSD0100';A.APIKEY_ATV='b6ac9e6384d93d6e533b144b3ef22c42';A.SCREENCODE_ATV='CSSD1300';A.LIVE_LIMIT=20;A.VOD_LIMIT=24;A.EPISODE_LIMIT=30;A.SEARCH_LIMIT=30;A.MOVIE_LIMIT=24;A.PAGE_SIZE=20;A.API_DOMAIN='https://api.tving.com';A.IMG_DOMAIN='https://image.tving.com';A.SEARCH_DOMAIN='https://search-api.tving.com';A.LOGIN_DOMAIN='https://user.tving.com';A.URL_DOMAIN='https://www.tving.com';A.USER_AGENT='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36';A.MODEL='windows_chrome_153.0.0.0';A.MODEL2='"Not;A=Brand";v="8", "Chromium";v="153", "Google Chrome";v="153"';A.DEFAULT_HEADER={_Av:A.USER_AGENT};A.TV_COOKIE_FILENAME='';A.TV_TOKEN_FILENAME='';A.SEARCHED_FILE_NAME='';A.TV_SESSION_COOKIES1='';A.TV_SESSION_COOKIES2='';A.TV_STREAM_FILENAME='';A.TV_SESSION_TEXT1='';A.TV_SESSION_TEXT2='';A.KodiVersion=20;A.TV={};A.TV_TOKEN={};A.Init_TV_Total()
	def Init_TV_Total(A):A.TV={_c:{},_S:{}};A.TV_TOKEN={}
	"\n\tdef callRequestCookies( self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):\n\t\t#HTTP_CLIENT = httpx.Client()  # httpx\n\n\t\tsetHeader = self.DEFAULT_HEADER\n\t\tif headers: setHeader.update( headers )\n\n\t\tif jobtype == 'Get': # Get/Post\n\t\t\tres = httpx.get( url, params=params, headers=setHeader, cookies=cookies )\n\t\telse:\n\t\t\tres = httpx.post( url, json=payload, params=params, headers=setHeader, cookies=cookies )\n\n\t\tprint( str(res.status_code) + ' - ' + str(res.url) )\n\n\t\treturn res\n\t"
	def callRequestCookies(G,jobtype,url,payload=_A,json=_A,params=_A,headers=_A,cookies=_A,redirects=_E):
		F=redirects;E=cookies;D=headers;C=params;B=G.DEFAULT_HEADER
		if D:B.update(D)
		if jobtype==_M:A=requests.get(url,params=C,headers=B,cookies=E,allow_redirects=F)
		else:A=requests.post(url,data=payload,json=json,params=C,headers=B,cookies=E,allow_redirects=F)
		print(str(A.status_code)+' - '+A.url);return A
	def JsonFile_Save(C,filename,dic):
		A=filename
		if A=='':return _E
		try:B=open(A,'w',-1,_F);json.dump(dic,B,indent=4,ensure_ascii=_E);B.close()
		except:return _E
		return _J
	def JsonFile_Load(D,filename):
		A=filename
		if A=='':return{}
		try:B=open(A,'r',-1,_F);C=json.load(B);B.close()
		except:return{}
		return C
	def TextFile_Save(C,filename,resText):
		A=filename
		if A=='':return _E
		try:B=open(A,'w',-1,_F);B.write(resText);B.close()
		except:return _E
		return _J
	def Save_session_acount(A,tvid,tvpw,tvtype,tvpf):A.TV[_c]['tvid']=base64.standard_b64encode(tvid.encode()).decode(_F);A.TV[_c]['tvpw']=base64.standard_b64encode(tvpw.encode()).decode(_F);A.TV[_c]['tvtype']=tvtype;A.TV[_c]['tvpf']=tvpf
	def Load_session_acount(A):
		try:B=base64.standard_b64decode(A.TV[_c]['tvid']).decode(_F);C=base64.standard_b64decode(A.TV[_c]['tvpw']).decode(_F);D=A.TV[_c]['tvtype'];E=A.TV[_c]['tvpf']
		except:return'','',_R,0
		return B,C,D,E
	def make_stream_header(J,headers,cookies):
		I='{}={}';G=headers;A=cookies;B=''
		if A not in[{},_A,'']:
			H=len(A)
			for(C,D)in A.items():
				B+=I.format(C,D);H+=-1
				if H>0:B+='; '
			G['cookie']=B
		E='';F=0
		for(C,D)in G.items():
			F=F+1
			if F>1:E+='&'
			E+=I.format(C,urllib.parse.quote(D))
		return E
	def makeDefaultCookies(B):
		A={}
		for(C,D)in B.TV[_S].items():A[C]=D
		return A
	def GetDefaultParams(A,uhd=_E):
		C='teleCode'
		if uhd==_E:B={_AX:A.APIKEY,_AY:A.NETWORKCODE,_AC:A.OSCODE,C:A.TELECODE,_AD:A.SCREENCODE}
		else:B={_AX:A.APIKEY_ATV,_AY:A.NETWORKCODE,_AC:A.OSCODE,C:A.TELECODE,_AD:A.SCREENCODE_ATV}
		return B
	def GetNoCache(A,timetype=1):
		if timetype==1:return int(time.time())
		else:return int(time.time()*1000)
	def GetUniqueid(H,hValue=_A):
		C=hValue
		if C:import hashlib as G;D=G.sha1();D.update(C.encode());E=D.hexdigest()[:8]
		else:
			A=[0 for A in range(256)]
			for F in range(256):A[F]='%02x'%F
			B=int(4294967295*random.random())|0;E=A[255&B]+A[B>>8&255]+A[B>>16&255]+A[B>>24&255]
		return E
	def Web_DecryptKey(C):A=bytes(_Aw,_F);B=bytes(_Ax,_F);return A,B
	def Web_EncryptCiphertext(A,plaintext):B,C=A.Web_DecryptKey();D=AES.new(B,AES.MODE_CBC,C);E=D.encrypt(Padding.pad(plaintext.encode(_F),16));return base64.standard_b64encode(E).decode(_F)
	def Web_DecryptPlaintext(A,ciphertext):B,C=A.Web_DecryptKey();D=AES.new(B,AES.MODE_CBC,C);E=Padding.unpad(D.decrypt(base64.standard_b64decode(ciphertext)),16);return E.decode(_F)
	def WebCookies_Load(A,wc_file):
		try:
			C=open(wc_file,'r',-1,_F);D=C.read();C.close();E=A.Web_DecryptPlaintext(D);A.TV=json.loads(E);B=A.GetDeviceList()
			if B not in['',_K]:A.TV[_S][_d]=B+_K+A.GetUniqueid(B)
		except:return _E
		return _J
	def GetCredential2(B,user_id,user_pw,login_type,user_pf):
		D=user_id
		try:
			if base64.standard_b64encode(D.encode()).decode(_F)in['a3ltOTUxMDg4','a3ltMTA4OA==']:E='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE5MDkwL3R2aW5nbG9naW4='
			else:E='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx'
			A={'addon':'tvingm','method':'LOGIN',_N:{'type':login_type,'id':D,'pw':user_pw,'pf':user_pf}};A=json.dumps(A,separators=(',',':'));A=base64.standard_b64encode(A.encode()).decode(_F);G={'proxy-mini':A};F=requests.get(base64.standard_b64decode(E).decode(_F),headers=G)
			if F.status_code!=200:B.Init_TV_Total();return _E
			C=base64.standard_b64decode(F.text).decode(_F);C=json.loads(C);B.TV[_S]=C
		except Exception as H:print(H);B.Init_TV_Total();return _E
		return _J
	def GetDeviceList(B):C=[];A=_K;A=str(B.GetNoCache(timetype=1));return A
	def Get_Now_Datetime(A):return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
	def get_renewal_url(A,mediacode,quality_int=1080,proxyPort=9999):
		C=mediacode;E=A.TV[_S][_d].split(_K)[0];F=A.TV[_S][_d]
		for(G,H)in QUALITY_LIST.items():
			if H==quality_int:I=G
		D=A.GetDefaultParams();J={_AE:C,_AF:E,_AG:F,_AH:_AL,_AI:I,_AJ:str(A.GetNoCache(1)),_AK:_AM,_AZ:A.MODEL,_Aa:_Ay,_Ab:'aac',_Ac:_Ae,_Ad:'hls'};D.update(J);B={'addon':'tvingm',_Az:C,'get_url':'https://api.tving.com/v3/media/stream/info','headers':{_Av:A.USER_AGENT,_AN:A.TV_TOKEN[_b]},'params':D,_S:A.makeDefaultCookies()};B=json.dumps(B,separators=(',',':'));B=base64.standard_b64encode(B.encode()).decode(_F);K='http://127.0.0.1:{}/live.mpd?proxy-mini={}'.format(proxyPort,B);return K
	def GetBroadURL(B,mediacode,sel_quality,stype):
		M='subtitles';L='qt_stream';H=mediacode;A={_O:'',_Af:_E,_q:'',_r:'',_s:'',_t:'',_Ag:'',L:''};N=B.TV[_S][_d].split(_K)[0];O=B.TV[_S][_d]
		for(P,Q)in QUALITY_LIST.items():
			if Q==sel_quality:F=P
		A[L]=F;print(F)
		try:
			I=str(B.GetNoCache(1));R=_A_;S={_AN:B.TV_TOKEN[_b]};J=B.GetDefaultParams();T={_AE:H,_AF:N,_AG:O,_AH:_AL,_AJ:I,_AK:_AM,_AZ:B.MODEL,_Aa:'h264|av1',_Ab:'aac',_Ac:_Ae,'dev.drm':'pr','dev.sl':'SL3000','dev.osn':'windows','dev.osv':'11',_AI:F,_Ad:'hls'};J.update(T);U=B.API_DOMAIN+R;V=B.makeDefaultCookies();W=B.callRequestCookies('Post',U,payload=_A,params=J,headers=S,cookies=V,redirects=_J);G=json.loads(W.text)
			if G[_L][_W][_C]!='000':A[_q]=G[_L][_W]['message'];return A
			C=G[_L]['stream']
			if C['drm_yn']==_i:
				D=C[_u]['drm']['widevine']
				for E in C[_u]['drm']['license'][_B0]:
					if E['drm_type']=='Widevine':A[_r]=E[_r];A[_s]=E[_s];A[_t]=E[_t];break
			else:D=C[_u]['non_drm']
		except Exception as X:print(X);A[_q]=_B1;return A
		Y=I;D=D.split('|')[1];D=B.Decrypt_Url(D,H,Y);A[_O]=D
		if M in C:
			for Z in C.get(M):
				if Z.get(_C)in['KO','KO_CC']:A[_Af]=_J;break
		a=urllib.parse.urlparse(A[_O]);K=a.path.strip('/').split('/');A[_Ag]=K[len(K)-1];return A
	def Tving_Parse_mpd(F,stream_url):
		K='bandwidth';J='Representation';L=requests.get(url=stream_url);G=L.content.decode(_F);D=0;M=ET.ElementTree(ET.fromstring(G));E=M.getroot();B=re.match('\\{.*\\}',E.tag)[0];N=dict([A for(B,A)in ET.iterparse(io.StringIO(G),events=['start-ns'])])
		for(H,O)in N.items():
			if H!='ns2':ET.register_namespace(H,O)
		P=E.find(B+'Period')
		for A in P.findall(B+'AdaptationSet'):
			if A.attrib.get('mimeType')=='video/mp4'or A.attrib.get('contentType')=='video':
				for C in A.findall(B+J):
					I=int(C.attrib.get(K))
					if D<I:D=I
				for C in A.findall(B+J):
					if D>int(C.attrib.get(K)):A.remove(C)
			else:continue
		Q=ET.tostring(E).decode(_F);R='<?xml version="1.0" encoding="UTF-8"?>\n';F.TextFile_Save(F.TV_STREAM_FILENAME,R+Q);return _J
	def Tving_Parse_m3u8(C,stream_url):
		H='BANDWIDTH';B='#EXT-X-STREAM-INF'
		try:
			J=requests.get(url=stream_url,headers=_A,stream=_J);D=J.content.decode(_F)
			if'#EXTM3U'not in D:return _E
			if B not in D:return _E
			F=0
			for A in D.splitlines():
				if A.startswith(B):
					E=C.MediaLine_Parse(A,B)
					if F<int(E.get(H)):F=int(E.get(H))
			I=[];G=_E
			for A in D.splitlines():
				if G==_J:G=_E;continue
				if A.startswith(B):
					E=C.MediaLine_Parse(A,B)
					if F!=int(E.get(H)):G=_J;continue
				I.append(A)
		except Exception as K:print(K);return _E
		L='\n'.join(I);C.TextFile_Save(C.TV_STREAM_FILENAME,L);return _J
	def MediaLine_Parse(E,line,prefix):
		A={}
		for B in ATTRIBUTE_PATTERN.split(line.replace(prefix+':',''))[1::2]:C,D=B.split('=',1);A[C.upper()]=D.replace('"','').strip()
		return A
	def CheckQuality(C,sel_qt,qt_list):
		for A in qt_list:
			if sel_qt>=list(A)[0]:return A.get(list(A)[0])
			B=A.get(list(A)[0])
		return B
	def GetLiveChannelList(C,stype,page_int):
		B='schedule';H=[];I=_E
		try:
			Y='/v2/media/lives'
			if stype=='onair':Q='CPCS0100,CPCS0400'
			else:Q='CPCS0300'
			R=C.GetDefaultParams();Z={_Ah:'main',_A2:str(page_int),_j:str(C.LIVE_LIMIT),_v:'rating',_Ai:_Q,'free':_Q,_Aj:_Q,_Ak:_Q,'channelType':Q};R.update(Z);a=C.API_DOMAIN+Y;b=C.callRequestCookies(_M,a,payload=_A,params=R,headers=_A,cookies=_A);J=json.loads(b.text)
			if not _W in J[_L]:return H,I
			c=J[_L][_W]
			for A in c:
				S=D=K='';L=M='';d=A['live_code'];S=A[B][_w][_X][_D]
				if A[B][_U]!=_A:D=A[B][_B][_X][_D];D=D+', '+str(A[B][_U][_AO])+'회';K=A[B][_U][_Y][_D]
				else:D=A[B][_B][_X][_D];K=A[B][_B][_Y][_D]
				try:
					F='';"\n\t\t\t\t\tfor now_img in i_section['schedule']['program']['image']:\n\t\t\t\t\t\tif   now_img['code'] == 'CAIP0900': tmp_poster    = self.IMG_DOMAIN + now_img['url'] #CAIP0900/CAIP2300\n\t\t\t\t\t\telif now_img['code'] == 'CAIP1800':\ttmp_clearlogo = self.IMG_DOMAIN + now_img['url']\n\t\t\t\t\t\telif now_img['code'] == 'CAIP2000':\ttmp_icon      = self.IMG_DOMAIN + now_img['url']\n\t\t\t\t\t\telif now_img['code'] == 'CAIP0200':\ttmp_fanart    = self.IMG_DOMAIN + now_img['url']\n\t\t\t\t\t\telif now_img['code'] == 'CAIP0500':\ttmp_thumb     = self.IMG_DOMAIN + now_img['url'] #CAIP0800/CAIP0500\n\t\t\t\t\t\telif now_img['code'] == 'CAIP0800':\ttmp_thumb     = self.IMG_DOMAIN + now_img['url'] #CAIP0800/CAIP0500\n\n\t\t\t\t\tif tmp_thumb == '':\n\t\t\t\t\t\tfor now_img in i_section['schedule']['channel']['image']:\n\t\t\t\t\t\t\tif now_img['code'] in ['CAIC0400','CAIC1400','CAIC1900','CAIC1500']:\n\t\t\t\t\t\t\t\ttmp_thumb   = self.IMG_DOMAIN + now_img['url']\n\t\t\t\t\t\t\t\tbreak\n\t\t\t\t\t"
					for E in A[B][_w][_k]:
						if E[_C]in['CAIC1500']:F=C.IMG_DOMAIN+E[_G];break
					if F=='':
						for E in A[B][_B][_k]:
							if E[_C]in['CAIP0500']:F=C.IMG_DOMAIN+E[_G];break
				except:_A
				try:
					T=[];U=[];N=[];V='';W='';X=''
					for O in A.get(B).get(_B).get(_Z):
						if O!=''and O!='없음':T.append(O)
					for G in A.get(B).get(_B).get(_P):
						if G!=''and G!=_K and G!='없음':U.append(G)
					if A.get(B).get(_B).get(_f).get(_D)!='':N.append(A[B][_B][_f][_D])
					if A.get(B).get(_B).get(_g).get(_D)!='':N.append(A[B][_B][_g][_D])
					if A.get(B).get(_B).get(_l):V=A[B][_B][_l]
					if A.get(B).get(_B).get(_A3):W=MPAA_LIST.get(A[B][_B][_A3])
					if _h in A.get(B).get(_B):P=A.get(B).get(_B).get(_h);X=_m%(P[:4],P[4:6],P[6:])
				except:_A
				L=str(A[B]['broadcast_start_time'])[8:12];M=str(A[B]['broadcast_end_time'])[8:12];e={_w:S,_H:D,_Az:d,_I:{_a:F},_Y:K,'channelepg':' [%s:%s ~ %s:%s]'%(L[0:2],L[2:],M[0:2],M[2:]),_n:T,_P:U,_AP:N,_o:V,_p:W,_A4:X};H.append(e)
			if J[_L]['has_more']==_i:I=_J
		except Exception as f:print(f)
		return H,I
	def GetProgramList(C,genre,orderby,page_int,genreCode=_Q):
		N=genreCode;M=genre;F=[];G=_E
		try:
			Y='/v2/media/episodes';O=C.GetDefaultParams();H={_Ah:'main',_j:str(C.VOD_LIMIT),_v:orderby,_Ai:_Q,'free':_Q,_Aj:_Q,_Ak:_Q,'lastFrequency':'y','personal':'N',_A2:str(page_int)}
			if M not in[_Q,'PARAMOUNT']:H['categoryCode']=M
			if N!=_Q:H[_B2]=N
			O.update(H);Z=C.API_DOMAIN+Y;a=C.callRequestCookies(_M,Z,payload=_A,params=O,headers=_A,cookies=_A);I=json.loads(a.text)
			if not _W in I[_L]:return F,G
			b=I[_L][_W]
			for A in b:
				c=A[_B][_C];d=A[_B][_X][_D];e=MPAA_LIST.get(A[_B].get(_A3));P='';J='';Q='';R='';S=''
				for B in A[_B][_k]:
					if B[_C]==_Al:P=C.IMG_DOMAIN+B[_G]
					elif B[_C]==_Am:J=C.IMG_DOMAIN+B[_G]
					elif B[_C]==_An:Q=C.IMG_DOMAIN+B[_G]
					elif B[_C]==_Ao:R=C.IMG_DOMAIN+B[_G]
					elif B[_C]==_Ap:S=C.IMG_DOMAIN+B[_G]
				f=A[_B][_Y][_D]
				try:T=A[_w][_X][_D]
				except:T=''
				try:
					U=[];V=[];K=[];W='';X=''
					for D in A.get(_B).get(_Z):
						if D!=''and D!=_K and D!='없음':U.append(D)
					for E in A.get(_B).get(_P):
						if E!=''and E!=_K and E!='없음':V.append(E)
					if A.get(_B).get(_f).get(_D)!='':K.append(A[_B][_f][_D])
					if A.get(_B).get(_g).get(_D)!='':K.append(A[_B][_g][_D])
					if A.get(_B).get(_l):W=A[_B][_l]
					if _h in A.get(_B):L=A.get(_B).get(_h);X=_m%(L[:4],L[4:6],L[6:])
				except:_A
				g={_B:c,_H:d,_I:{_T:P,_a:J,_x:Q,_AQ:R,_AR:S,_e:J},_Y:f,_w:T,_n:U,_P:V,_AP:K,_o:W,_A4:X,_p:e};F.append(g)
			if I[_L]['has_more']==_i:G=_J
		except Exception as h:print(h)
		return F,G
	def GetEpisodeList(B,program_code,page_int,orderby=_y):
		M=orderby;F=page_int;G=[];H=_E
		try:
			a='/v2/media/frequency/program/'+program_code;N=B.GetDefaultParams();b={_v:'newUpdate',_Ah:'main',_j:'20',_v:'new',_Ai:_Q,'free':_Q,_Aj:_Q,_Ak:_Q};N.update(b);c=B.API_DOMAIN+a;d=B.callRequestCookies(_M,c,payload=_A,params=N,headers=_A,cookies=_A);I=json.loads(d.text)
			if not _W in I[_L]:return G,H
			D=I[_L][_W];J=int(I[_L]['total_count']);O=int(J//(B.EPISODE_LIMIT+1))+1
			if M==_y:K=J-1-(F-1)*B.EPISODE_LIMIT
			else:K=(F-1)*B.EPISODE_LIMIT
			for P in range(B.EPISODE_LIMIT):
				if M==_y:
					A=K-P
					if A<0:break
				else:
					A=K+P
					if A>=J:break
				e=D[A][_U][_C];f=D[A]['vod_name'][_D];E=''
				try:L=str(D[A][_U]['broadcast_date']);E=_m%(L[:4],L[4:6],L[6:])
				except:_A
				try:
					if D[A][_U]['pip_cliptype']=='C012':E+=' - Quick VOD'
				except:_A
				g=D[A][_U][_Y][_D];Q='';R='';S='';T='';U='';V=''
				for C in D[A][_B][_k]:
					if C[_C]==_Al:Q=B.IMG_DOMAIN+C[_G]
					elif C[_C]==_An:S=B.IMG_DOMAIN+C[_G]
					elif C[_C]==_Ao:T=B.IMG_DOMAIN+C[_G]
					elif C[_C]==_Ap:U=B.IMG_DOMAIN+C[_G]
					elif C[_C]==_Am:V=B.IMG_DOMAIN+C[_G]
				for C in D[A][_U][_k]:
					if C[_C]=='CAIE0400':R=B.IMG_DOMAIN+C[_G]
				try:
					W=X=Y='';Z=0;W=D[A][_B][_X][_D];X=E;Y=D[A][_w][_X][_D]
					if _AO in D[A][_U]:Z=D[A][_U][_AO]
				except:_A
				h={_U:e,_H:f,'subtitle':E,_I:{_T:Q,_a:R,_x:S,_AQ:T,_AR:U,_e:V},_Y:g,'info_title':W,_Aq:X,_Ar:Y,_AO:Z};G.append(h)
			if O>F:H=_J
		except Exception as i:print(i)
		return G,H,O
	def Gn2_Program_List(B,genre,orderby,page_int):
		C=[];D=_E
		try:
			F=_B3+'/bff/web/v3/content/vod';G={_A2:str(page_int),_j:str(B.PAGE_SIZE),_v:orderby,_B2:genre,_AD:'CSSD0100',_AC:'CSOD0900'};H=B.callRequestCookies(_M,F,payload=_A,params=G,headers=_A,cookies=_A);E=json.loads(H.text);I=E[_N][_AS]
			for A in I:J={_C:A[_C],_H:A[_H],_I:{_T:A[_A5]}};C.append(J)
			if _As in E[_N]:D=_J
		except Exception as K:print(K)
		return C,D
	def GetSearchList(B,search_key,page_int,stype):
		i='grade_nm';h='runtime_sec';g='targetage';f='web_url';e='mast_nm';d='mast_cd';c='count';b='dataList';Z=page_int;Y=search_key;X='vodMVRsb';W='programRsb';V='NO';R='ALL';N=stype;E='cate_nm';F=[];O=_E
		try:
			j='/search/getSearch.jsp';r=B.GetDefaultParams();k={'kwd':Y,'category':'PROGRAM'if N==_A6 else'VODMV','pageNum':str(Z),'notFoundText':Y,'userid':'','siteName':'TVING_WEB',_j:str(B.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':R,'runTime':R,'grade':R,_z:R,'screen':B.SCREENCODE,'os':B.OSCODE,'network':B.NETWORKCODE,'sort1':V,'sort2':V,'sort3':V,'type1':_y,'type2':_y,'type3':_y,'fixedType':_i,'spcMethod':'someword','spcSize':_R,'schReqCnt':_R,'vodBCReqCnt':_R,'programReqCnt':str(B.SEARCH_LIMIT)if N==_A6 else _R,'vodMVReqCnt':str(B.SEARCH_LIMIT)if N==_AT else _R,'aloneReqCnt':_R,'smrclipReqCnt':_R,'pickClipReqCnt':_R,'cSocialClipCnt':_R,'boardReqCnt':_R,'talkReqCnt':_R,'nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'',_AX:B.APIKEY,_AY:B.NETWORKCODE,'osCode ':B.OSCODE,'teleCode ':B.TELECODE,'screenCode ':B.SCREENCODE};l=B.SEARCH_DOMAIN+j;m=B.callRequestCookies(_M,l,payload=_A,params=k,headers=_A,cookies=_A);D=json.loads(m.text)
			if N==_A6:
				if not W in D:return F,O
				n=D[W][b];a=int(D[W][c])
				for A in n:
					S=A[d];T=A[e];P=B.IMG_DOMAIN+A['web_url4'];G=B.IMG_DOMAIN+A[f]
					try:
						H=[];I=[];J=[];Q=0;K='';L='';M=''
						if A.get(_Z)!=''and A.get(_Z)!=_K:H=A.get(_Z).split(',')
						if A.get(_P)!=''and A.get(_P)!=_K:I=A.get(_P).split(',')
						if A.get(E)!=''and A.get(E)!=_K:J=A.get(E).split('/')
						if g in A:K=A.get(g)
						if _h in A:C=A.get(_h);M=_m%(C[:4],C[4:6],C[6:]);L=C[:4]
					except:_A
					U={_B:S,_H:T,_I:{_T:P,_a:G,_e:G},_Y:'',_n:H,_P:I,_AP:J,_A7:Q,_p:K,_o:L,_Aq:M};F.append(U)
			else:
				if not X in D:return F,O
				o=D[X][b];a=int(D[X][c])
				for A in o:
					S=A[d];T=A[e].strip();P=B.IMG_DOMAIN+A[f];G=P;p=''
					try:
						H=[];I=[];J=[];Q=0;K='';L='';M=''
						if A.get(_Z)!=''and A.get(_Z)!=_K:H=A.get(_Z).split(',')
						if A.get(_P)!=''and A.get(_P)!=_K:I=A.get(_P).split(',')
						if A.get(E)!=''and A.get(E)!=_K:J=A.get(E).split('/')
						if A.get(h)!='':Q=A.get(h)
						if i in A:K=A.get(i)
						C=A.get(_h)
						if data_str!='':M=_m%(C[:4],C[4:6],C[6:]);L=C[:4]
					except:_A
					U={_AT:S,_H:T,_I:{_T:P,_a:G,_e:G,_x:p},_Y:'',_n:H,_P:I,_AP:J,_A7:Q,_p:K,_o:L,_Aq:M};F.append(U)
			if a>Z*B.SEARCH_LIMIT:O=_J
		except Exception as q:print(q)
		return F,O
	def Gn2_Search_List(B,search_key,page_int,stype):
		C=stype;D=[];E=_E
		try:
			if C==_A6:F='https://gw.tving.com/bff/search/v2/more/content/series/search';G='AI_SCH_SERIES'
			else:F='https://gw.tving.com/bff/search/v2/more/content/movie/search';G='AI_SCH_MOVIE'
			J={'keyword':search_key,_A2:str(page_int),_j:str(B.PAGE_SIZE),'bandComposeMethod':'MANUAL',_A0:G,_AC:B.OSCODE,_AD:B.SCREENCODE};K=B.callRequestCookies(_M,F,payload=_A,params=J,headers=_A,cookies=_A);H=json.loads(K.text).get(_N).get(_A1)[0]
			for A in H[_AS]:
				if C==_A6:I={_B:A[_C],_H:A[_H],_I:{_T:A[_A5]}}
				else:I={_AT:A[_C],_H:A[_H],_I:{_T:A[_A5]}}
				D.append(I)
			if _As in H:E=_J
		except Exception as L:print(L)
		return D,E
	def GetBookmarkInfo(E,videoid,vidtype):
		W='content';V='info';S='plot';O=vidtype;N=videoid;D='infoLabels';B='saveinfo';A={'indexinfo':{'ott':'tving','videoid':N,'vidtype':O},B:{_H:'','subtitle':'',_I:{_T:'',_a:'',_x:'',_AQ:'',_AR:'',_e:''},D:{'mediatype':O,_H:'',_p:'',S:'',_o:'',_Ar:'',_A7:0,_n:[],_P:[],_z:[],_A4:'','country':''}}}
		if O=='tvshow':
			P=E.API_DOMAIN+'/v2/media/program/'+N;K=E.GetDefaultParams();Q={_A2:'1',_j:'10',_v:_X};K.update(Q);R=E.callRequestCookies(_M,P,payload=_A,params=K,headers=_A,cookies=_A);L=json.loads(R.text)
			if not _L in L:return{}
			C=L[_L];H=C.get(_X).get(_D).strip();A[B][_H]=H;A[B][D][_H]=H;A[B][D][_p]=MPAA_LIST.get(C.get(_A3));A[B][D][S]=C.get(_Y).get(_D);A[B][D][_o]=C.get(_l);A[B][D][_n]=C.get(_Z);A[B][D][_P]=C.get(_P)
			if C.get(_f).get(_D)!='':A[B][D][_z].append(C.get(_f).get(_D))
			if C.get(_g).get(_D)!='':A[B][D][_z].append(C.get(_g).get(_D))
			G=str(C.get(_h))
			if G!=_R:A[B][D][_A4]=_m%(G[:4],G[4:6],G[6:])
			I='';J='';M='';T='';U=''
			for F in C.get(_k):
				if F.get(_C)==_Al:I=E.IMG_DOMAIN+F.get(_G)
				elif F.get(_C)==_Am:J=E.IMG_DOMAIN+F.get(_G)
				elif F.get(_C)==_An:M=E.IMG_DOMAIN+F.get(_G)
				elif F.get(_C)==_Ao:T=E.IMG_DOMAIN+F.get(_G)
				elif F.get(_C)==_Ap:U=E.IMG_DOMAIN+F.get(_G)
			A[B][_I][_T]=I;A[B][_I][_a]=J;A[B][_I][_x]=M;A[B][_I][_AQ]=T;A[B][_I][_AR]=U;A[B][_I][_e]=J
		else:
			P=E.API_DOMAIN+'/v2a/media/stream/info';K=E.GetDefaultParams();Q={_AK:_AM,_AE:N,V:_i,'adReq':'adproxy',_AI:'stream40',_AF:E.TV[_S][_d].split(_K)[0],_AG:E.TV[_S][_d],_AH:_AL,_AJ:str(E.GetNoCache(1)),'wm':_i};K.update(Q);R=E.callRequestCookies(_M,P,payload=_A,params=K,headers=_A,cookies=_A);L=json.loads(R.text)
			if not W in L[_L]:return{}
			C=L[_L][W][V][_AT];H=C.get(_X).get(_D).strip();A[B][D][_H]=H;H+=' (%s)'%C.get(_l);A[B][_H]=H;A[B][D][_p]=MPAA_LIST.get(C.get(_A3));A[B][D][S]=C.get('story').get(_D);A[B][D][_o]=C.get(_l);A[B][D][_Ar]=C.get('production');A[B][D][_A7]=C.get(_A7);A[B][D][_n]=C.get(_Z);A[B][D][_P]=C.get(_P)
			if C.get(_f).get(_D)!='':A[B][D][_z].append(C.get(_f).get(_D))
			if C.get(_g).get(_D)!='':A[B][D][_z].append(C.get(_g).get(_D))
			G=str(C.get('release_date'))
			if G!=_R:A[B][D][_A4]=_m%(G[:4],G[4:6],G[6:])
			I='';J='';M=''
			for F in C.get(_k):
				if F.get(_C)=='CAIM2100':I=E.IMG_DOMAIN+F.get(_G)
				elif F.get(_C)=='CAIM0400':J=E.IMG_DOMAIN+F.get(_G)
				elif F.get(_C)=='CAIM1800':M=E.IMG_DOMAIN+F.get(_G)
			A[B][_I][_T]=I;A[B][_I][_a]=I;A[B][_I][_x]=M;A[B][_I][_e]=J
		return A
	def Make_DecryptKey(C,step,mediacode='000',timecode='000'):
		if step=='1':A=bytes('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),_F);B=bytes(_Ax,_F)
		else:A=bytes(_Aw,_F);B=bytes([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
		return A,B
	def DecryptPlaintext(C,ciphertext,encryption_key,init_vector):A=AES.new(encryption_key,AES.MODE_CBC,init_vector);B=Padding.unpad(A.decrypt(base64.standard_b64decode(ciphertext)),16);return B.decode(_F)
	def Decrypt_Url(A,ciphertext,mediacode,timecode):
		E=timecode;D=mediacode;F=''
		try:B,C=A.Make_DecryptKey('1',mediacode=D,timecode=E);G=json.loads(A.DecryptPlaintext(ciphertext,B,C));H=G.get(_G);B,C=A.Make_DecryptKey('2',mediacode=D,timecode=E);F=A.DecryptPlaintext(H,B,C)
		except Exception as I:print(I)
		return F
	def Get_Apple_buildId(B):
		A=''
		try:C='https://www.tving.com/more/special/SP0071';D=B.callRequestCookies(_M,C,payload=_A,params=_A,headers=_A,cookies=_A);E='"buildId":"(.*?)"';A=re.compile(E,re.DOTALL).findall(D.text)[0]
		except Exception as F:print(F)
		return A
	def Get_AppleGroup_List(A):
		E='bandName';B=[]
		try:
			F=A.Get_Apple_buildId();G=_B4.format(F);H={'key':'SP0071'};I=A.URL_DOMAIN+G;J=A.callRequestCookies(_M,I,payload=_A,params=H,headers=_A,cookies=_A);D=json.loads(J.text)
			if not _V in D:return B
			K=D[_V][_A8][_A9][0][_AA][_N][_AU][0][_N][_A1]
			for C in K:
				if C[_AV]not in['VOD_BASIC']:continue
				L=re.findall('/band/\\w+|/curation/\\w+',C['moreUrl'])[0];M={E:C[E],'bandKey':L.split('/')[2]};B.append(M)
		except Exception as N:print(N)
		return B
	def Get_Band_VodList(C,bandKey,nextApiUrl=_K):
		K=nextApiUrl;B=bandKey;D=[];E=''
		try:
			if B.startswith('CR'):L='/curation/{}'.format(B)
			else:L='/band/{}'.format(B)
			if K in[_A,'',_K]:
				M=C.Get_Apple_buildId();N='/_next/data/{}/ko/more{}.json'.format(M,L);O={'key':B};G=C.URL_DOMAIN+N;H=C.callRequestCookies(_M,G,payload=_A,params=O,headers=_A,cookies=_A);A=json.loads(H.text)
				if not _V in A:return D,E
				if B.startswith('CR'):F=A[_V][_A8][_A9][0][_AA][_N][_N][_A1][0]
				else:F=A[_V][_A8][_A9][0][_AA][_N][_AU][0][_N]['band']
			else:
				G='{}{}{}'.format(_B3,K,'&screenCode=CSSD0100&osCode=CSOD0900');H=C.callRequestCookies(_M,G,payload=_A,params=_A,headers=_A,cookies=_A);A=json.loads(H.text)
				if not _N in A:return D,E
				F=A[_N]
			for I in F[_AS]:J=I[_A5];P={_B:I[_C],_H:I[_H],_I:{_T:J,_a:J,_e:J}};D.append(P)
			E=F.get(_As)or''
		except Exception as Q:print(Q)
		return D,E
	def Get_bandCode_GroupCode(B,GroupCode):
		D=GroupCode;C=''
		try:
			if D=='TVING_APPLE_HOUR':
				G=B.Get_Apple_buildId();H='https://www.tving.com/_next/data/{}/ko/more/special/SP0071.json?key=SP0071'.format(G);E=B.callRequestCookies(_M,H,payload=_A,params=_A,headers=_A,cookies=_A);F=json.loads(E.text)
				if not _V in F:return C
				I=F[_V][_A8][_A9][0][_AA][_N][_AU][0][_N][_A1]
				for A in I:
					if A[_AV]!=_B5:continue
					return A[_A0]
			else:
				J={'authorization':'Bearer {}'.format(B.TV_TOKEN[_At]),_AN:B.TV_TOKEN[_b]};K=['https://gw.tving.com/bff/web/v3/home/main?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/drama?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/entertainment?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/movie?screenCode=CSSD0100&osCode=CSOD0900']
				for L in K:
					E=B.callRequestCookies(_M,L,payload=_A,params=_A,headers=J,cookies=_A);M=json.loads(E.text)
					for A in M[_N][_A1]:
						if D in A[_A0]or D=='TVING_ORIGINAL'and A[_AV]=='VOD_BASIC_ORIGINAL':
							if':'in A[_A0]:C=A[_A0].split(':')[0]
							else:C=A[_A0]
							return C
		except Exception as N:print(N)
		return C
	def Get_Apple_NowList(A):
		E=[];G=_K
		try:
			H=A.Get_Apple_buildId();I=_B4.format(H);J={'key':'SP0071'};K=A.URL_DOMAIN+I;L=A.callRequestCookies(_M,K,payload=_A,params=J,headers=_A,cookies=_A);B=json.loads(L.text);B=B[_V][_A8][_A9][0][_AA][_N][_AU][0][_N][_A1]
			for F in B:
				if F[_AV]==_B5:
					for C in F[_AS]:D=C[_A5];M={_B:C[_C],_H:C[_H],_I:{_T:D,_a:D,_e:D}};E.append(M)
		except Exception as N:print(N)
		return E,G
	def Get_AccessToken(A):
		E='userInfo';D='props'
		try:
			G=A.URL_DOMAIN;F=A.makeDefaultCookies();F.pop(_b);B=A.callRequestCookies(_M,G,payload=_A,params=_A,headers=_A,cookies=F)
			if B.status_code!=200:return _E
			H='<script id="__NEXT_DATA__" type="application/json">\\s*(.*?)\\s*</script>';I=re.compile(H,re.DOTALL).findall(B.text)[0];C=json.loads(I);A.TV_TOKEN[_At]=C.get(D).get(_V).get(E).get(_At);A.TV_TOKEN[_AB]=C.get(D).get(_V).get(E).get(_AB);A.TV_TOKEN[_b]=B.cookies[_b];A.TV_TOKEN[_AW]=C.get(D).get(_V).get(E).get(_AW);J=A.Get_Now_Datetime();K=J+datetime.timedelta(days=0);A.TV_TOKEN['token_date']=K.strftime('%Y%m%d');A.JsonFile_Save(A.TV_TOKEN_FILENAME,A.TV_TOKEN)
		except Exception as L:print(L);return _E
		return _J
	def GetLiveURL_Test(B,mediacode,sel_quality):
		H=mediacode;A={_O:'',_Af:_E,_q:'',_r:'',_s:'',_t:'',_Ag:''};M=B.TV[_S][_d].split(_K)[0];N=B.TV[_S][_d]
		try:
			I=str(B.GetNoCache(1));O=_A_;P={_AN:B.TV_TOKEN[_b]};J=B.GetDefaultParams();Q={_AE:H,_AF:M,_AG:N,_AH:_AL,_AI:'stream50',_AJ:I,_AK:_AM,_AZ:B.MODEL,_Aa:_Ay,_Ab:'aac',_Ac:_Ae,_Ad:'hls'};J.update(Q);R=B.API_DOMAIN+O;K=B.makeDefaultCookies();S=B.callRequestCookies('Post',R,payload=_A,params=J,headers=P,cookies=K,redirects=_J);F=json.loads(S.text)
			if F[_L][_W][_C]!='000':A[_q]=F[_L][_W]['message'];return A
			D=F[_L]['stream']
			if D['drm_yn']==_i:
				C=D[_u]['drm']['widevine']
				for E in D[_u]['drm']['license'][_B0]:
					if E['drm_type']=='Widevine':A[_r]=E[_r];A[_s]=E[_s];A[_t]=E[_t];break
			else:C=D[_u]['non_drm']
		except Exception as T:print(T);A[_q]=_B1;return A
		U=I;C=C.split('|')[1];C=B.Decrypt_Url(C,H,U);A[_O]=C;V=A[_O].find('Policy=')
		if V!=-1:Y=A[_O].split('?')[0];G=dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(A[_O]).query));A[_O]='{}&CloudFront-Policy={}'.format(A[_O],G['Policy']);A[_O]='{}&CloudFront-Signature={}'.format(A[_O],G['Signature']);A[_O]='{}&CloudFront-Key-Pair-Id={}'.format(A[_O],G['Key-Pair-Id'])
		W=[_Au,_b,_AB]
		for(L,X)in K.items():
			if L in W:A[_O]='{}&{}={}'.format(A[_O],L,X)
		print(A[_O]);return A