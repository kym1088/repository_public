_Ap='Dialog.Close(all,true)'
_Ao='token_limit'
_An='delete.png'
_Am='RunPlugin(plugin://plugin.video.tvingm/?%s)'
_Al='Container.Refresh'
_Ak='info_title'
_Aj='tving_orderby'
_Ai='search_history.png'
_Ah='search.png'
_Ag='APPLE_GROUP'
_Af='-----------------'
_Ae='TVING_APPLE_HOUR'
_Ad='LIVE_GROUP'
_Ac='%Y%m%d'
_Ab='MYVIEW_REMOVE'
_Aa='WATCH_ONE'
_AZ='WATCH_ALL'
_AY='SEARCH_ALL'
_AX='SEARCH_ONE'
_AW='SEARCH_REMOVE'
_AV='info_genre'
_AU='duration'
_AT='aired'
_AS='LOCAL_SEARCH'
_AR='SEARCH_HISTORY'
_AQ='MOVIE_GROUP'
_AP='enter'
_AO='ENTER_GROUP'
_AN='update'
_AM='drama'
_AL='DRAMA_GROUP'
_AK='watchedlist_%s.txt'
_AJ='search'
_AI='movies'
_AH='(통합) 찜 영상에 추가'
_AG='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'
_AF='program'
_AE='synopsis'
_AD='nextApiUrl'
_AC='CHANNEL'
_AB='MENU_BOOKMARK'
_AA='TOTAL_HISTORY'
_A9='SEARCH_GROUP'
_A8='WATCH'
_A7='vType'
_A6='delType'
_A5='tvshows'
_A4='vsubtitle'
_A3='vtitle'
_A2='vidtype'
_A1='list'
_A0='int'
_z='TOTAL_SEARCH'
_y='episode'
_x='XXX'
_w='BAND_VODLIST'
_v='bandGroup'
_u='code'
_t='skey'
_s='search_key'
_r='VOD'
_q='EPISODE'
_p='next.png'
_o='다음 페이지'
_n='[B]%s >>[/B]'
_m='director'
_l='cast'
_k='year'
_j='premiered'
_i='mpaa'
_h='string'
_g='studio'
_f='MOVIE'
_e='videoid'
_d='1'
_c='true'
_b='vod'
_a='bandKey'
_Z='icon'
_Y='programcode'
_X='path'
_W='utf-8'
_V='mediacode'
_U='mediatype'
_T='img'
_S='plot'
_R='thumbnail'
_Q='utf8'
_P='type'
_O='func'
_N='ordernm'
_M='page'
_L='orderby'
_K='movie'
_J=None
_I='-'
_H=True
_G='tvshow'
_F=False
_E='GN2_LIST'
_D='genre'
_C='stype'
_B='title'
_A='mode'
__author__='NightRain'
import os,xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs,sys,inputstreamhelper,datetime,time,urllib,base64,json
__addon__=xbmcaddon.Addon()
__language__=__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
MAIN_GROUP=[{_B:'LIVE 채널',_A:_Ad,_C:'live',_L:_I,_N:_I,_Z:'live.png'},{_B:'실시간 인기 드라마',_A:_w,_a:'HM218820',_v:''},{_B:'실시간 인기 예능',_A:_w,_a:'HM156521',_v:''},{_B:'Apple TV+ 실시간 인기',_A:_w,_a:_I,_v:_Ae},{_B:_Af,_A:_x,_C:_x,_L:_I,_N:_I},{_B:'드라마 - 인기순',_A:_AL,_C:_AM,_L:'hit',_N:'인기'},{_B:'드라마 - 업데이트',_A:_AL,_C:_AM,_L:_AN,_N:'업데이트'},{_B:'예능   - 인기순',_A:_AO,_C:_AP,_L:'hit',_N:'인기'},{_B:'예능   - 업데이트',_A:_AO,_C:_AP,_L:_AN,_N:'업데이트'},{_B:'영화 - 인기순',_A:_AQ,_C:_K,_L:'hit',_N:'인기'},{_B:'영화 - 업데이트',_A:_AQ,_C:_K,_L:_AN,_N:'업데이트'},{_B:'Apple TV+',_A:_Ag,_C:_I,_L:_I,_N:_I},{_B:_Af,_A:_x,_C:_x,_L:_I,_N:_I},{_B:'Watched (시청목록)',_A:_A8,_C:_I,_L:_I,_N:_I,_Z:'history.png'},{_B:'(티빙) 검색',_A:_A9,_C:_I,_L:_I,_N:_I,_Z:_Ah},{_B:'(티빙) 검색기록',_A:_AR,_C:_I,_L:_I,_N:_I,_Z:_Ai},{_B:'통합검색 (웨이브,티빙,왓챠,넷플릭스)',_A:_z,_C:_I,_L:_I,_N:_I,_Z:_Ah},{_B:'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록',_A:_AA,_C:_I,_L:_I,_N:_I,_Z:_Ai},{_B:'통합 찜 목록 (bookmark mini)',_A:_AB,_C:_I,_L:_I,_N:_I,_Z:'bookmark.png'}]
LIVE_GROUP=[{_B:'실시간 TV',_A:_AC,_C:'onair'},{_B:'TVING TV',_A:_AC,_C:'tvingtv'}]
WATCH_GROUP=[{_B:'VOD 시청내역',_A:_A8,_C:_b},{_B:'영화 시청내역',_A:_A8,_C:_K}]
SEARCH_GROUP=[{_B:'VOD 검색',_A:_AS,_C:_b},{_B:'영화 검색',_A:_AS,_C:_K}]
DRAMA_GROUP=[{_B:'전체',_A:_E,_D:'PCA',_C:_G},{_B:'로맨스',_A:_E,_D:'PCA007',_C:_G},{_B:'코미디',_A:_E,_D:'PCA020',_C:_G},{_B:'판타지',_A:_E,_D:'PCA023',_C:_G},{_B:'무협',_A:_E,_D:'PCAB',_C:_G},{_B:'공포',_A:_E,_D:'PCAD',_C:_G},{_B:'복수',_A:_E,_D:'PCA030',_C:_G},{_B:'휴먼',_A:_E,_D:'PCA024',_C:_G},{_B:'범죄 스릴러',_A:_E,_D:'PCA015',_C:_G},{_B:'의학',_A:_E,_D:'PCA025',_C:_G},{_B:'웹튠/소설 원작',_A:_E,_D:'PCA028',_C:_G},{_B:'정치/권력',_A:_E,_D:'PCA034',_C:_G},{_B:'법정',_A:_E,_D:'PCA036',_C:_G},{_B:'청춘(성장)',_A:_E,_D:'PCA029',_C:_G},{_B:'오피스 드라마',_A:_E,_D:'PCA040',_C:_G},{_B:'사극/시대극',_A:_E,_D:'PCA017',_C:_G},{_B:'타임슬립',_A:_E,_D:'PCA026',_C:_G},{_B:'단막극',_A:_E,_D:'PCA038',_C:_G},{_B:'해외드라마',_A:_E,_D:'PCPOS',_C:_G},{_B:'미국드라마',_A:_E,_D:'POS007',_C:_G},{_B:'영국드라마',_A:_E,_D:'POS008',_C:_G},{_B:'중국드라마',_A:_E,_D:'POS005',_C:_G},{_B:'일본드라마',_A:_E,_D:'POS006',_C:_G}]
ENTER_GROUP=[{_B:'버라이어티',_A:_E,_D:'PCD005',_C:_G},{_B:'다큐멘터리',_A:_E,_D:'PCT',_C:_G},{_B:'여행',_A:_E,_D:'PCD003',_C:_G},{_B:'쿡방/먹방',_A:_E,_D:'PCD023',_C:_G},{_B:'연애 리얼리티',_A:_E,_D:'PCAB',_C:'PCD010'},{_B:'나영석 예능',_A:_E,_D:'PCD032',_C:_G},{_B:'게임/퀴즈쇼',_A:_E,_D:'PCD029',_C:_G},{_B:'토크쇼',_A:_E,_D:'PCD011',_C:_G},{_B:'서바이벌',_A:_E,_D:'PCD025',_C:_G},{_B:'관찰리얼리티',_A:_E,_D:'PCD024',_C:_G},{_B:'스포츠',_A:_E,_D:'PCD037',_C:_G},{_B:'교육&독서',_A:_E,_D:'PCD038',_C:_G},{_B:'힐링 예능',_A:_E,_D:'PCD034',_C:_G},{_B:'아이돌',_A:_E,_D:'PCD01',_C:_G},{_B:'음악 서바이벌',_A:_E,_D:'PCD027',_C:_G},{_B:'음악예능',_A:_E,_D:'PCD021',_C:_G},{_B:'코미디',_A:_E,_D:'PCD017',_C:_G},{_B:'가족예능',_A:_E,_D:'PCD035',_C:_G},{_B:'뷰티/스타일',_A:_E,_D:'PCD022',_C:_G},{_B:'펫/애니멀',_A:_E,_D:'PCD026',_C:_G},{_B:'콘서트/시상식',_A:_E,_D:'PCD009',_C:_G},{_B:'예능 스페셜',_A:_E,_D:'PCD042',_C:_G}]
MOVIE_GROUP=[{_B:'드라마',_A:_E,_D:'MG100',_C:_K},{_B:'로맨스',_A:_E,_D:'MG130',_C:_K},{_B:'코미디',_A:_E,_D:'MG110',_C:_K},{_B:'애니메이션',_A:_E,_D:'MG240',_C:_K},{_B:'스릴러',_A:_E,_D:'MG140',_C:_K},{_B:'미스터리',_A:_E,_D:'MG150',_C:_K},{_B:'모험',_A:_E,_D:'MG170',_C:_K},{_B:'액션',_A:_E,_D:'MG120',_C:_K},{_B:'판타지',_A:_E,_D:'MG200',_C:_K},{_B:'SF',_A:_E,_D:'MG210',_C:_K},{_B:'공포',_A:_E,_D:'MG160',_C:_K},{_B:'다큐멘터리',_A:_E,_D:'MG250',_C:_K}]
INFO_CONVERT_KEY={_B:{_O:'setTitle',_P:_h},_S:{_O:'setPlot',_P:_h},_i:{_O:'setMpaa',_P:_h},_U:{_O:'setMediaType',_P:_h},'tvshowtitle':{_O:'setTvShowTitle',_P:_h},_j:{_O:'setPremiered',_P:_h},_AT:{_O:'setFirstAired',_P:_h},_k:{_O:'setYear',_P:_A0},_AU:{_O:'setDuration',_P:_A0},_y:{_O:'setEpisode',_P:_A0},'season':{_O:'setSeason',_P:_A0},_g:{_O:'setStudios',_P:_A1},_D:{_O:'setGenres',_P:_A1},'country':{_O:'setCountries',_P:_A1},_l:{_O:'setCast',_P:'actor'},_m:{_O:'setDirectors',_P:_A1}}
from tvingCore import*
class TvingRun:
	def __init__(self,in_addonurl,in_handle,in_params):self._addon_url=in_addonurl;self._addon_handle=in_handle;self.main_params=in_params;self.TvingObj=Tving();self.TvingObj.TV_STREAM_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'));self.TvingObj.TV_COOKIE_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'));self.TvingObj.TV_TOKEN_FILENAME=xbmcvfs.translatePath(os.path.join(__profile__,'tving_token.json'));self.TvingObj.SEARCHED_FILE_NAME=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
	def addon_noti(self,sting):
		try:dialog=xbmcgui.Dialog();dialog.notification(__addonname__,sting)
		except:_J
	def addon_log(self,string):
		try:log_message=string.encode(_W,'ignore')
		except:log_message='addonException: addon_log'
		level=xbmc.LOGINFO;xbmc.log('[%s-%s]: %s'%(__addonid__,__version__,log_message),level=level)
	def get_keyboard_input(self,title):
		input_text=_J;kb=xbmc.Keyboard();kb.setHeading(title);xbmc.sleep(1000);kb.doModal()
		if kb.isConfirmed():input_text=kb.getText()
		return input_text
	def get_settings_account(self):uid=__addon__.getSetting('id');pwd=__addon__.getSetting('pw');ltype=__addon__.getSetting('login_type');profile=int(__addon__.getSetting('selected_profile'));return uid,pwd,ltype,profile
	def get_settings_uhd(self):return _F
	def get_settings_playback(self):A='active_uhd';playOption={A:_H if __addon__.getSetting(A)==_c else _F,'streamFilename':self.TvingObj.TV_STREAM_FILENAME};return playOption
	def get_settings_proxyport(self):proxyUse=_H if __addon__.getSetting('proxyYn')==_c else _F;proxyPort=int(__addon__.getSetting('proxyPort'));return proxyUse,proxyPort
	def get_settings_totalsearch(self):local_search=_H if __addon__.getSetting('local_search')==_c else _F;local_history=_H if __addon__.getSetting('local_history')==_c else _F;total_search=_H if __addon__.getSetting('total_search')==_c else _F;total_history=_H if __addon__.getSetting('total_history')==_c else _F;menu_bookmark=_H if __addon__.getSetting('menu_bookmark')==_c else _F;return local_search,local_history,total_search,total_history,menu_bookmark
	def get_settings_makebookmark(self):return _H if __addon__.getSetting('make_bookmark')==_c else _F
	def get_settings_direct_replay(self):
		direct_replay=int(__addon__.getSetting('direct_replay'))
		if direct_replay==0:return _F
		else:return _H
	def set_winEpisodeOrderby(self,orderby):__addon__.setSetting(_Aj,orderby);WIN=xbmcgui.Window(10000);WIN.setProperty('TVING_M_ORDERBY',orderby)
	def get_winEpisodeOrderby(self):
		orderby=__addon__.getSetting(_Aj)
		if orderby in['',_J]:orderby='desc'
		return orderby
	def add_dir(self,label,sublabel='',img='',infoLabels=_J,isFolder=_H,params='',isLink=_F,ContextMenu=_J):
		url='%s?%s'%(self._addon_url,urllib.parse.urlencode(params))
		if sublabel:title='%s < %s >'%(label,sublabel)
		else:title=label
		if not img:img='DefaultFolder.png'
		listitem=xbmcgui.ListItem(title)
		if type(img)==dict:listitem.setArt(img)
		else:listitem.setArt({'thumb':img,'poster':img})
		if self.TvingObj.KodiVersion>=20:
			if infoLabels:self.Set_InfoTag(listitem.getVideoInfoTag(),infoLabels)
		elif infoLabels:listitem.setInfo('Video',infoLabels)
		if not isFolder and not isLink:listitem.setProperty('IsPlayable',_c)
		if ContextMenu:listitem.addContextMenuItems(ContextMenu)
		xbmcplugin.addDirectoryItem(self._addon_handle,url,listitem,isFolder)
	def get_selQuality(self):
		try:quality_type='selected_quality';QT_LIST=[1080,720,480,360];sel_quality_idx=int(__addon__.getSetting(quality_type));return QT_LIST[sel_quality_idx]
		except:_J
		return 720
	def Set_InfoTag(self,video_InfoTag,infoLabels):
		for(key,value)in infoLabels.items():
			if INFO_CONVERT_KEY[key][_P]==_h:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_O])(value)
			elif INFO_CONVERT_KEY[key][_P]==_A0:
				if type(value)==int:intValue=int(value)
				else:intValue=0
				getattr(video_InfoTag,INFO_CONVERT_KEY[key][_O])(intValue)
			elif INFO_CONVERT_KEY[key][_P]=='actor':
				if value!=[]:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_O])([xbmc.Actor(name)for name in value])
			elif INFO_CONVERT_KEY[key][_P]==_A1:
				if type(value)==list:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_O])(value)
				else:getattr(video_InfoTag,INFO_CONVERT_KEY[key][_O])([value])
	def dp_Main_List(self):
		local_search,local_history,total_search,total_history,menu_bookmark=self.get_settings_totalsearch()
		for main_group in MAIN_GROUP:
			title=main_group.get(_B);icon_img=''
			if main_group.get(_A)==_A9 and local_search==_F:continue
			elif main_group.get(_A)==_AR and local_history==_F:continue
			elif main_group.get(_A)==_z and total_search==_F:continue
			elif main_group.get(_A)==_AA and total_history==_F:continue
			elif main_group.get(_A)==_AB and menu_bookmark==_F:continue
			params={_A:main_group.get(_A),_C:main_group.get(_C),_L:main_group.get(_L),_N:main_group.get(_N),_M:_d,_a:main_group.get(_a),_v:main_group.get(_v),_AD:_I}
			if main_group.get(_A)in[_x,_z,_AA,_AB]:isFolder=_F;isLink=_H
			else:isFolder=_H;isLink=_F
			infoLabels={_B:title,_S:title}
			if main_group.get(_A)==_x:infoLabels=_J
			if _Z in main_group:icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_X),_T,main_group.get(_Z))
			self.add_dir(title,sublabel='',img=icon_img,infoLabels=infoLabels,isFolder=isFolder,params=params,isLink=isLink)
		xbmcplugin.endOfDirectory(self._addon_handle)
	def login_main(self):
		tving_id,tving_pw,login_type,tving_pf=self.get_settings_account()
		if not(tving_id and tving_pw):
			dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30901).encode(_Q),__language__(30902).encode(_Q))
			if ret==_H:__addon__.openSettings();sys.exit()
			else:sys.exit()
		if self.cookiefile_check():return
		if base64.standard_b64encode(tving_id.encode()).decode(_W)in['a3ltOTUxMDg4','a3ltMTA4OA==']:loginResult=self.TvingObj.GetCredential2(tving_id,tving_pw,login_type,tving_pf)
		else:
			dialog=xbmcgui.Dialog();wc_file=dialog.browse(1,__language__(30917).encode(_Q),'','.twc',_F,_F,'',_F)
			if wc_file!='':
				tempFile=xbmcvfs.translatePath(os.path.join(__profile__,'tvinginfo-temp.twc'));xbmcvfs.copy(wc_file,tempFile);loginResult=self.TvingObj.WebCookies_Load(tempFile);xbmcvfs.delete(tempFile)
				if loginResult:self.TvingObj.JsonFile_Save(self.TvingObj.TV_COOKIE_FILENAME,self.TvingObj.TV);self.addon_noti(__language__(30918).encode(_Q));return
			else:loginResult=_F
		if loginResult==_H:self.cookiefile_save()
		else:self.addon_noti(__language__(30903).encode(_Q));sys.exit()
	def dp_Title_Group(self,args):
		stype=args.get(_C)
		if stype=='live':GROUP_LIST=LIVE_GROUP
		elif stype==_AM:GROUP_LIST=DRAMA_GROUP
		elif stype==_AP:GROUP_LIST=ENTER_GROUP
		else:GROUP_LIST=MOVIE_GROUP
		for i_section in GROUP_LIST:
			title=i_section.get(_B)
			if args.get(_N)!=_I:title+='  ('+args.get(_N)+')'
			params={_A:i_section.get(_A),_C:i_section.get(_C),_D:i_section.get(_D),_L:args.get(_L),_N:args.get(_N),_M:_d};self.add_dir(title,sublabel='',img='',infoLabels=_J,isFolder=_H,params=params)
		if len(GROUP_LIST)>0:xbmcplugin.endOfDirectory(self._addon_handle)
	def dp_LiveChannel_List(self,args):
		stype=args.get(_C);page_int=int(args.get(_M));LIVE_LIST,more_page=self.TvingObj.GetLiveChannelList(stype,page_int)
		for live_list in LIVE_LIST:title=live_list.get(_B);sublabel=live_list.get('channel');thumbnail=live_list.get(_R);synopsis=live_list.get(_AE);channelepg=live_list.get('channelepg');cast=live_list.get(_l);director=live_list.get(_m);info_genre=live_list.get(_AV);year=live_list.get(_k);mpaa=live_list.get(_i);premiered=live_list.get(_j);info={_U:_y,_B:title,_g:sublabel,_l:cast,_m:director,_D:info_genre,_S:'%s\n%s\n%s\n\n%s'%(sublabel,title,channelepg,synopsis),_k:year,_i:mpaa,_j:premiered};params={_A:'LIVE',_V:live_list.get(_V),_C:stype};self.add_dir(sublabel,sublabel=title,img=thumbnail,infoLabels=info,isFolder=_F,params=params)
		if more_page:params[_A]=_AC;params[_C]=stype;params[_M]=str(page_int+1);title=_n%_o;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_X),_T,_p);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		if len(LIVE_LIST)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_F)
	def dp_Program_List(self,args):
		A='genreCode';genre=args.get(_C);orderby=args.get(_L);page_int=int(args.get(_M));genreCode=args.get(A)
		if genreCode==_J:genreCode='all'
		PROGRAM_LIST,more_page=self.TvingObj.GetProgramList(genre,orderby,page_int,genreCode)
		for program_list in PROGRAM_LIST:
			title=program_list.get(_B);thumbnail=program_list.get(_R);synopsis=program_list.get(_AE);channel=program_list.get('channel');cast=program_list.get(_l);director=program_list.get(_m);info_genre=program_list.get(_AV);year=program_list.get(_k);premiered=program_list.get(_j);mpaa=program_list.get(_i);info={_U:_G,_B:title,_g:channel,_l:cast,_m:director,_D:info_genre,_k:year,_j:premiered,_i:mpaa,_S:synopsis};params={_A:_q,_Y:program_list.get(_AF),_M:_d}
			if self.get_settings_makebookmark():bm_param={_e:program_list.get(_AF),_A2:_G,_A3:title,_A4:channel};bm_param_str=json.dumps(bm_param);bm_param_str=urllib.parse.quote(bm_param_str);bookmark_url=_AG%bm_param_str;ContextMenu=[(_AH,bookmark_url)]
			else:ContextMenu=_J
			self.add_dir(title,sublabel=channel,img=thumbnail,infoLabels=info,isFolder=_H,params=params,ContextMenu=ContextMenu)
		if more_page:params[_A]='PROGRAM';params[_C]=genre;params[_L]=orderby;params[_M]=str(page_int+1);params[A]=genreCode;title=_n%_o;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_X),_T,_p);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		xbmcplugin.setContent(self._addon_handle,_A5);xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_F)
	def dp_Episode_List(self,args):
		programcode=args.get(_Y);page_int=int(args.get(_M));self.addon_log('programcode : {}'.format(args.get(_Y)));self.addon_log('page        : {}'.format(args.get(_M)));EPISODE_LIST,more_page,total_page=self.TvingObj.GetEpisodeList(programcode,page_int,orderby=self.get_winEpisodeOrderby());self.addon_log('count       : {}'.format(len(EPISODE_LIST)))
		for episode_list in EPISODE_LIST:title=episode_list.get(_B);subtitle=episode_list.get('subtitle');thumbnail=episode_list.get(_R);synopsis=episode_list.get(_AE);info_title=episode_list.get(_Ak);aired=episode_list.get(_AT);studio=episode_list.get(_g);frequency=episode_list.get('frequency');info={_U:_y,_B:info_title,_AT:aired,_g:studio,_y:frequency,_S:synopsis};params={_A:_r,_V:episode_list.get(_y),_C:_b,_Y:programcode,_B:title,_R:thumbnail};self.add_dir(title,sublabel=subtitle,img=thumbnail,infoLabels=info,isFolder=_F,params=params)
		if page_int==1:
			info={_S:'정렬순서를 변경합니다.'};params={};params[_A]='ORDER_BY'
			if self.get_winEpisodeOrderby()=='desc':title='정렬순서변경 : 최신화부터 -> 1회부터';params[_L]='asc'
			else:title='정렬순서변경 : 1회부터 -> 최신화부터';params[_L]='desc'
			icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_X),_T,'sort.png');self.add_dir(title,sublabel='',img=icon_img,infoLabels=info,isFolder=_F,params=params,isLink=_H)
		if more_page:params[_A]=_q;params[_Y]=programcode;params[_M]=str(page_int+1);title=_n%_o;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_X),_T,_p);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		xbmcplugin.setContent(self._addon_handle,'episodes')
		if len(EPISODE_LIST)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_F)
	def dp_setEpOrderby(self,args):orderby=args.get(_L);self.set_winEpisodeOrderby(orderby);xbmc.executebuiltin(_Al)
	def dp_Movie_List(self,args):
		A='moviecode';genre=args.get(_C);orderby=args.get(_L);page_int=int(args.get(_M));MOVIE_LIST,more_page=self.TvingObj.GetMovieList(genre,orderby,page_int)
		for movie_list in MOVIE_LIST:
			title=movie_list.get(_B);thumbnail=movie_list.get(_R);synopsis=movie_list.get(_AE);info_title=movie_list.get(_Ak);year=movie_list.get(_k);cast=movie_list.get(_l);director=movie_list.get(_m);info_genre=movie_list.get(_AV);duration=movie_list.get(_AU);premiered=movie_list.get(_j);studio=movie_list.get(_g);mpaa=movie_list.get(_i);info={_U:_K,_B:info_title,_k:year,_l:cast,_m:director,_D:info_genre,_AU:duration,_j:premiered,_g:studio,_i:mpaa,_S:synopsis};params={_A:_f,_V:movie_list.get(A),_C:_K,_B:title,_R:thumbnail}
			if self.get_settings_makebookmark():bm_param={_e:movie_list.get(A),_A2:_K,_A3:info_title,_A4:''};bm_param_str=json.dumps(bm_param);bm_param_str=urllib.parse.quote(bm_param_str);bookmark_url=_AG%bm_param_str;ContextMenu=[(_AH,bookmark_url)]
			else:ContextMenu=_J
			self.add_dir(title,sublabel='',img=thumbnail,infoLabels=info,isFolder=_F,params=params,ContextMenu=ContextMenu)
		if more_page:params={};params[_A]='MOVIE_SUB';params[_L]=orderby;params[_C]=genre;params[_M]=str(page_int+1);title=_n%_o;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_X),_T,_p);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		xbmcplugin.setContent(self._addon_handle,_AI);xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_F)
	def dp_Set_Bookmark(self,args):
		A='saveinfo';main_param=urllib.parse.unquote(args.get('bm_param'));main_param=json.loads(main_param);videoid=main_param.get(_e);vidtype=main_param.get(_A2);vtitle=main_param.get(_A3);vsubtitle=main_param.get(_A4);dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30913).encode(_Q),vtitle+' \n\n'+__language__(30914))
		if ret==_F:return
		VIDEO_INFO=self.TvingObj.GetBookmarkInfo(videoid,vidtype)
		if vsubtitle!='':
			VIDEO_INFO[A]['subtitle']=vsubtitle
			if vidtype==_G:VIDEO_INFO[A]['infoLabels'][_g]=vsubtitle
		bookmark_param=json.dumps(VIDEO_INFO);bookmark_param=urllib.parse.quote(bookmark_param);bookmark_url='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%bookmark_param;xbmc.executebuiltin(bookmark_url)
	def dp_Search_Group(self,args):
		if _s in args:search_key=args.get(_s)
		else:
			search_key=self.get_keyboard_input(__language__(30906).encode(_W))
			if not search_key:return
		for i_section in SEARCH_GROUP:mode=i_section.get(_A);stype=i_section.get(_C);title=i_section.get(_B);SEARCH_LIST,more_page=self.TvingObj.Gn2_Search_List(search_key,1,stype);infoLabels={_S:'검색어 : '+search_key+'\n\n'+self.Search_FreeList(SEARCH_LIST)};params={_A:mode,_C:stype,_s:search_key,_M:_d};self.add_dir(title,sublabel='',img='',infoLabels=infoLabels,isFolder=_H,params=params)
		if len(SEARCH_GROUP)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_H)
		self.Save_Searched_List(search_key)
	def Search_FreeList(self,search_list):
		resultText='';max_count=7
		try:
			if len(search_list)==0:return'검색결과 없음'
			for i in range(len(search_list)):
				if i>=max_count:resultText=resultText+'...';break
				resultText=resultText+search_list[i][_B]+'\n'
		except:return''
		return resultText
	def dp_Search_History(self,args):
		SEARCH_HISTORY=self.Load_List_File(_AJ)
		for search_history in SEARCH_HISTORY:hist_params=dict(urllib.parse.parse_qsl(search_history));skey=hist_params.get(_t).strip();params={_A:_A9,_s:skey};menu_param={_A:_AW,_A6:_AX,'sKey':skey,_A7:_I};menu_param_str=urllib.parse.urlencode(menu_param);ContextMenu=[('선택된 검색어 ( %s ) 삭제'%skey,_Am%menu_param_str)];self.add_dir(skey,sublabel='',img=_J,infoLabels=_J,isFolder=_H,params=params,ContextMenu=ContextMenu)
		info={_S:'검색목록 전체를 삭제합니다.'};title='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **';params={_A:_AW,_A6:_AY,_t:_I,_A7:_I};icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_X),_T,_An);self.add_dir(title,sublabel='',img=icon_img,infoLabels=info,isFolder=_F,params=params,isLink=_H);xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_F)
	def dp_Search_List(self,args):
		page_int=int(args.get(_M));stype=args.get(_C)
		if _s in args:search_key=args.get(_s)
		else:
			search_key=self.get_keyboard_input(__language__(30906).encode(_W))
			if not search_key:xbmcplugin.endOfDirectory(self._addon_handle);return
		SEARCH_LIST,more_page=self.TvingObj.Gn2_Search_List(search_key,page_int,stype)
		for search_list in SEARCH_LIST:
			title=search_list.get(_B);thumbnail=search_list.get(_R);info={_U:_G if stype==_b else _K,_B:title,_S:'%s'%title}
			if stype==_b:videoid=search_list.get(_AF);vidtype=_G;params={_A:_q,_Y:videoid,_M:_d};isFolder=_H
			else:videoid=search_list.get(_K);vidtype=_K;params={_A:_f,_V:videoid,_C:_K,_B:title,_R:thumbnail};isFolder=_F
			if self.get_settings_makebookmark():bm_param={_e:videoid,_A2:vidtype,_A3:title,_A4:''};bm_param_str=json.dumps(bm_param);bm_param_str=urllib.parse.quote(bm_param_str);bookmark_url=_AG%bm_param_str;ContextMenu=[(_AH,bookmark_url)]
			else:ContextMenu=_J
			self.add_dir(title,sublabel='',img=thumbnail,infoLabels=info,isFolder=isFolder,params=params,isLink=_F,ContextMenu=ContextMenu)
		if more_page:params[_A]='SEARCH';params[_s]=search_key;params[_M]=str(page_int+1);title=_n%_o;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_X),_T,_p);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		if stype==_K:xbmcplugin.setContent(self._addon_handle,_AI)
		else:xbmcplugin.setContent(self._addon_handle,_A5)
		xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_F)
	def dp_History_Remove(self,args):
		delType=args.get(_A6);sKey=args.get('sKey');vType=args.get(_A7);dialog=xbmcgui.Dialog()
		if delType==_AY:ret=dialog.yesno(__language__(30911).encode(_Q),__language__(30905).encode(_Q))
		elif delType==_AX:ret=dialog.yesno(__language__(30912).encode(_Q),__language__(30905).encode(_Q))
		elif delType==_AZ:ret=dialog.yesno(__language__(30904).encode(_Q),__language__(30905).encode(_Q))
		elif delType==_Aa:ret=dialog.yesno(__language__(30916).encode(_Q),__language__(30905).encode(_Q))
		if ret==_F:sys.exit()
		if delType==_AY:
			if os.path.isfile(self.TvingObj.SEARCHED_FILE_NAME):os.remove(self.TvingObj.SEARCHED_FILE_NAME)
		elif delType==_AX:
			try:
				filename=self.TvingObj.SEARCHED_FILE_NAME;oldlist=self.Load_List_File(_AJ);fp=open(filename,'w',-1,_W)
				for olditem in oldlist:
					old_dic=dict(urllib.parse.parse_qsl(olditem));old_skey=old_dic.get(_t).strip()
					if sKey!=old_skey:fp.write(olditem)
				fp.close()
			except:_J
		elif delType==_AZ:
			filename=xbmcvfs.translatePath(os.path.join(__profile__,_AK%vType))
			if os.path.isfile(filename):os.remove(filename)
		elif delType==_Aa:
			filename=xbmcvfs.translatePath(os.path.join(__profile__,_AK%vType))
			try:
				oldlist=self.Load_List_File(vType);fp=open(filename,'w',-1,_W)
				for olditem in oldlist:
					old_dic=dict(urllib.parse.parse_qsl(olditem));old_skey=old_dic.get(_u).strip()
					if sKey!=old_skey:fp.write(olditem)
				fp.close()
			except:_J
		xbmc.executebuiltin(_Al)
	def Load_List_File(self,stype):
		try:
			if stype==_AJ:filename=self.TvingObj.SEARCHED_FILE_NAME
			elif stype in[_b,_K]:filename=xbmcvfs.translatePath(os.path.join(__profile__,_AK%stype))
			else:return[]
			fp=open(filename,'r',-1,_W);result=fp.readlines();fp.close()
		except:result=[]
		return result
	def Save_Watched_List(self,stype,in_params):
		try:
			watchfile=xbmcvfs.translatePath(os.path.join(__profile__,_AK%stype));oldlist=self.Load_List_File(stype);fp=open(watchfile,'w',-1,_W);newlist=urllib.parse.urlencode(in_params);newlist=newlist+'\n';fp.write(newlist);addcount=0
			for olditem in oldlist:
				old_dic=dict(urllib.parse.parse_qsl(olditem));new_id=in_params.get(_u).strip();old_id=old_dic.get(_u).strip()
				if stype==_b and self.get_settings_direct_replay()==_H:new_id=in_params.get(_e).strip();old_id=old_dic.get(_e).strip()if old_id!=_J else _I
				if new_id!=old_id:
					fp.write(olditem);addcount+=1
					if addcount>=50:break
			fp.close()
		except:_J
	def dp_Watch_List(self,args):
		stype=args.get(_C);direct_replay=self.get_settings_direct_replay()
		if stype==_I:
			for i_section in WATCH_GROUP:title=i_section.get(_B);params={_A:i_section.get(_A),_C:i_section.get(_C)};self.add_dir(title,sublabel='',img='',infoLabels=_J,isFolder=_H,params=params)
			if len(WATCH_GROUP)>0:xbmcplugin.endOfDirectory(self._addon_handle)
		else:
			WATCHLIST=self.Load_List_File(stype)
			for watchlist in WATCHLIST:
				hist_params=dict(urllib.parse.parse_qsl(watchlist));code=hist_params.get(_u).strip();title=hist_params.get(_B).strip();thumbnail=hist_params.get(_T).strip();videoid=hist_params.get(_e).strip()
				try:thumbnail=thumbnail.replace("'",'"');thumbnail=json.loads(thumbnail)
				except:_J
				info={};info[_S]=title
				if stype==_b:
					if direct_replay==_F or videoid==_J:info[_U]=_G;params={_A:_q,_Y:code,_M:_d};isFolder=_H
					else:info[_U]=_y;params={_A:_r,_V:videoid,_C:_b,_Y:code,_B:title,_R:thumbnail};isFolder=_F
				else:info[_U]=_K;params={_A:_f,_V:code,_C:_K,_B:title,_R:thumbnail};isFolder=_F
				menu_param={_A:_Ab,_A6:_Aa,'sKey':code,_A7:stype};menu_param_str=urllib.parse.urlencode(menu_param);ContextMenu=[('선택된 시청이력 ( %s ) 삭제'%title,_Am%menu_param_str)];self.add_dir(title,sublabel='',img=thumbnail,infoLabels=info,isFolder=isFolder,params=params,ContextMenu=ContextMenu)
			info={_S:'시청목록을 삭제합니다.'};title='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **';params={_A:_Ab,_A6:_AZ,_t:_I,_A7:stype};icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_X),_T,_An);self.add_dir(title,sublabel='',img=icon_img,infoLabels=info,isFolder=_F,params=params,isLink=_H)
			if stype==_K:xbmcplugin.setContent(self._addon_handle,_AI)
			else:xbmcplugin.setContent(self._addon_handle,_A5)
			xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_F)
	def Save_Searched_List(self,search_key):
		try:
			searchfile=self.TvingObj.SEARCHED_FILE_NAME;oldlist=self.Load_List_File(_AJ);save_params={_t:search_key.strip()};fp=open(searchfile,'w',-1,_W);newlist=urllib.parse.urlencode(save_params);newlist=newlist+'\n';fp.write(newlist);addcount=0
			for olditem in oldlist:
				old_dic=dict(urllib.parse.parse_qsl(olditem));new_id=save_params.get(_t).strip();old_id=old_dic.get(_t).strip()
				if new_id!=old_id:
					fp.write(olditem);addcount+=1
					if addcount>=50:break
			fp.close()
		except:_J
	def play_VIDEO(self,args):
		W='hls';V='application/x-mpegURL';U='inputstream.adaptive.manifest_headers';T='inputstream.adaptive.stream_headers';S='inputstream.adaptive.manifest_type';R='inputstream.adaptive';Q='com.widevine.alpha';P='end';O='drm_header_value';N='drm_header_key';M='watermarkKey';L='stream70';K='qt_stream';J='error_msg';I='inputstream';H='{}|{}';G=':';F='watermark';E='user-agent';D='mpd';C='url_filename';B='drm_server_url';A='streaming_url';mediacode=args.get(_V);stype=args.get(_C);pvrmode=args.get('pvrmode');quality_int=self.get_selQuality();self.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(mediacode,str(quality_int),stype,pvrmode));url_info=self.TvingObj.GetBroadURL(mediacode,quality_int,stype,pvrmode,optUHD=self.get_settings_uhd());self.addon_log('qt, stype, url : %s - %s - %s'%(str(quality_int),stype,url_info[A]))
		if url_info[A]=='':
			if url_info[J]=='':self.addon_noti(__language__(30908).encode(_Q))
			else:self.addon_noti(url_info[J].encode(_Q))
			return
		if url_info[K]==L:raw_headers={E:self.TvingObj.USER_AGENT_ATV}
		else:raw_headers={E:self.TvingObj.USER_AGENT}
		raw_cookies=self.TvingObj.makeDefaultCookies()
		if url_info[F]!='':raw_headers['x-tving-param1']=url_info[M];raw_headers['x-tving-param2']=url_info[F]
		if url_info[B]!='':raw_headers[url_info[N]]=url_info[O]
		quick_vod=_F;tmp_pos=url_info[A].find('Policy=')
		if tmp_pos!=-1:
			tmp_url=url_info[A].split('?')[0];param_dict=dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(url_info[A]).query));raw_cookies['CloudFront-Policy']=param_dict['Policy'];raw_cookies['CloudFront-Signature']=param_dict['Signature'];raw_cookies['CloudFront-Key-Pair-Id']=param_dict['Key-Pair-Id'];stream_headers=self.TvingObj.make_stream_header(raw_headers,raw_cookies)
			if'quickvod-mcdn.tving.com'in tmp_url:
				quick_vod=_H;nowTime=self.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1);nowTimeStr=nowTime.strftime('%Y-%m-%d-%H:%M:%S')
				if int(nowTimeStr.replace(_I,'').replace(G,''))<int(param_dict[P].replace(_I,'').replace(G,'')):param_dict[P]=nowTimeStr;self.addon_noti(__language__(30915).encode(_Q))
				tmp_url='%s?%s'%(tmp_url,urllib.parse.urlencode(param_dict,doseq=_H));surl=H.format(tmp_url,stream_headers)
			else:surl=H.format(url_info[A],stream_headers)
		else:stream_headers=self.TvingObj.make_stream_header(raw_headers,raw_cookies);surl=H.format(url_info[A],stream_headers);self.addon_log('if tmp_pos == -1')
		proxyUse,proxyPort=self.get_settings_proxyport();playOption=self.get_settings_playback()
		if proxyUse and args.get(_A)in[_r,_f]and quick_vod==_F and(url_info[B]!=''or url_info[C].split('.')[1]==D or url_info[C].split('.')[1]!=D and self.TvingObj.KodiVersion>=21 and url_info[K]==L):
			if url_info[C].split('.')[1]==D:self.TvingObj.Tving_Parse_mpd(url_info[A],url_info[M],url_info[F])
			else:self.TvingObj.Tving_Parse_m3u8(url_info[A])
			self.addon_log('xxx '+url_info[A]);proxyHeader={'addon':'tvingm','playOption':playOption,C:url_info[C]};proxyHeader=json.dumps(proxyHeader,separators=(',',G));proxyHeader=base64.standard_b64encode(proxyHeader.encode()).decode(_W);surl='http://127.0.0.1:{}/{}&proxy-mini={}'.format(proxyPort,surl,proxyHeader);raw_headers['proxy-mini']=proxyHeader
		self.addon_log('surl(2) : {}'.format(surl));self.addon_log('drm     : {}'.format(url_info[B]));stream_headers=self.TvingObj.make_stream_header(raw_headers,raw_cookies);item=xbmcgui.ListItem(path=surl)
		if url_info[B]!='':
			if stype=='onair':renew_url=self.TvingObj.get_renewal_url(mediacode,quality_int,proxyPort);item=xbmcgui.ListItem(path=renew_url);self.addon_log('renew_url : {}'.format(renew_url))
			CUSTOMDATA=url_info[B];DRMHOST='https://license-global.pallycon.com/ri/licenseManager.do';PROTOCOL=D;DRM=Q;inputstreamhelper.Helper(D,drm=Q).check_inputstream();headers={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site',E:self.TvingObj.USER_AGENT,url_info[N]:url_info[O]};LICENSE_KEY=DRMHOST+'|'+urllib.parse.urlencode(headers)+'|R{SSM}|';item.setProperty(I,R)
			if self.TvingObj.KodiVersion<=20:item.setProperty(S,PROTOCOL)
			item.setProperty('inputstream.adaptive.license_type',DRM);item.setProperty('inputstream.adaptive.license_key',LICENSE_KEY);item.setProperty(T,stream_headers);item.setProperty(U,stream_headers)
		elif args.get(_A)in[_r,_f]:
			item.setContentLookup(_F);item.setMimeType(V);item.setProperty(I,R)
			if self.TvingObj.KodiVersion<=20:item.setProperty(S,W)
			item.setProperty(T,stream_headers);item.setProperty(U,stream_headers)
		elif quick_vod==_H:item.setContentLookup(_F);item.setMimeType(V);item.setProperty(I,'inputstream.ffmpegdirect');item.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg');item.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false');item.setProperty('inputstream.ffmpegdirect.mime_type',W);item.setProperty('ResumeTime','0');item.setProperty('TotalTime','10000')
		xbmcplugin.setResolvedUrl(self._addon_handle,_H,item)
		try:
			if args.get(_A)in[_r,_f]and args.get(_B):params={_u:args.get(_Y)if args.get(_A)==_r else args.get(_V),_T:args.get(_R),_B:args.get(_B),_e:args.get(_V)};self.Save_Watched_List(args.get(_C),params)
		except:_J
	def logout(self):
		dialog=xbmcgui.Dialog();ret=dialog.yesno(__language__(30910).encode(_Q),__language__(30905).encode(_Q))
		if ret==_F:sys.exit()
		self.TvingObj.Init_TV_Total()
		if os.path.isfile(self.TvingObj.TV_COOKIE_FILENAME):os.remove(self.TvingObj.TV_COOKIE_FILENAME)
		if os.path.isfile(self.TvingObj.TV_TOKEN_FILENAME):os.remove(self.TvingObj.TV_TOKEN_FILENAME)
		self.addon_noti(__language__(30909).encode(_W))
	def cookiefile_save(self):current=self.TvingObj.Get_Now_Datetime();limit_date=current+datetime.timedelta(days=30);tving_id,tving_pw,login_type,tving_pf=self.get_settings_account();self.TvingObj.Save_session_acount(tving_id,tving_pw,login_type,tving_pf);self.TvingObj.TV['account'][_Ao]=limit_date.strftime(_Ac);self.TvingObj.JsonFile_Save(self.TvingObj.TV_COOKIE_FILENAME,self.TvingObj.TV)
	def cookiefile_check(self):
		self.TvingObj.TV=self.TvingObj.JsonFile_Load(self.TvingObj.TV_COOKIE_FILENAME)
		if self.TvingObj.TV=={}:self.TvingObj.Init_TV_Total();return _F
		cf_id,cf_pw,cf_ty,cf_pf=self.get_settings_account();ck_id,ck_pw,ck_ty,ck_pf=self.TvingObj.Load_session_acount()
		if(cf_id!=ck_id or cf_pw!=ck_pw or cf_ty!=ck_ty or cf_pf!=ck_pf)and ck_id!='xxxxx':self.TvingObj.Init_TV_Total();return _F
		if int(self.TvingObj.Get_Now_Datetime().strftime(_Ac))>int(self.TvingObj.TV['account'][_Ao]):self.TvingObj.Init_TV_Total();return _F
		return _H
	def tokenfile_check(self):
		self.TvingObj.TV_TOKEN=self.TvingObj.JsonFile_Load(self.TvingObj.TV_TOKEN_FILENAME)
		if self.TvingObj.TV_TOKEN=={}:return _F
		if int(self.TvingObj.Get_Now_Datetime().strftime(_Ac))>int(self.TvingObj.TV_TOKEN['token_date']):self.TvingObj.TV_TOKEN={};return _F
		return _H
	def get_reToken(self):
		if self.tokenfile_check()==_F:self.TvingObj.Get_AccessToken()
	def dp_Global_Search(self,args):
		mode=args.get(_A)
		if mode==_z:ott_url='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
		else:ott_url='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
		xbmc.executebuiltin(_Ap);xbmc.executebuiltin(ott_url)
	def dp_Bookmark_Menu(self,args):ott_url='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)';xbmc.executebuiltin(_Ap);xbmc.executebuiltin(ott_url)
	def dp_Apple_Group(self,args):
		BAND_LIST=self.TvingObj.Get_AppleGroup_List()
		for band_list in BAND_LIST:bandName=band_list.get('bandName');bandKey=band_list.get(_a);info={_U:_G,_B:bandName,_S:'%s'%bandKey};params={_A:_w,_a:bandKey,_M:_d,_AD:_I};self.add_dir(bandName,sublabel=_J,img='',infoLabels=info,isFolder=_H,params=params)
		if len(BAND_LIST)>0:xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_F)
	def dp_Band_VodList(self,args):
		A='M';bandKey=args.get(_a);bandGroup=args.get(_v);nextApiUrl=args.get(_AD);channelNm='';page_int=int(args.get(_M));self.addon_log('bandKey    : {}'.format(bandKey));self.addon_log('bandGroup  : {}'.format(bandGroup));self.addon_log('nextApiUrl : {}'.format(nextApiUrl))
		if bandGroup==_Ae:PROGRAM_LIST,nextApiUrl=self.TvingObj.Get_Apple_NowList()
		else:
			if bandGroup not in['',_J]:bandKey=self.TvingObj.Get_bandCode_GroupCode(bandGroup);self.addon_log('new bandKey    : {}'.format(bandKey))
			PROGRAM_LIST,nextApiUrl=self.TvingObj.Get_Band_VodList(bandKey,nextApiUrl)
		for program_list in PROGRAM_LIST:
			title=program_list.get(_B);thumbnail=program_list.get(_R);videoid=program_list.get(_AF);info={_U:_G if not videoid.startswith(A)else _K,_B:title,_S:title+'\n'+_G if not videoid.startswith(A)else _K}
			if not videoid.startswith(A):params={_A:_q,_Y:videoid,_M:_d};isFolder=_H
			else:params={_A:_f,_V:videoid,_C:_K,_B:title,_R:thumbnail};isFolder=_F
			if self.get_settings_makebookmark():bm_param={_e:videoid,_A2:_G,_A3:title,_A4:channelNm};bm_param_str=json.dumps(bm_param);bm_param_str=urllib.parse.quote(bm_param_str);bookmark_url=_AG%bm_param_str;ContextMenu=[(_AH,bookmark_url)]
			else:ContextMenu=_J
			self.add_dir(title,sublabel=channelNm,img=thumbnail,infoLabels=info,isFolder=isFolder,params=params,ContextMenu=ContextMenu)
		if nextApiUrl not in[_J,'',_I]:params[_A]=_w;params[_a]=bandKey;params[_AD]=nextApiUrl;params[_M]=str(page_int+1);title=_n%_o;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_X),_T,_p);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		xbmcplugin.setContent(self._addon_handle,_A5);xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_F)
	def dp_Gn2_Program(self,args):
		genre=args.get(_D);stype=args.get(_C);orderby=args.get(_L);page_int=int(args.get(_M));PROGRAM_LIST,more_page=self.TvingObj.Gn2_Program_List(genre,orderby,page_int)
		for i_list in PROGRAM_LIST:
			title=i_list.get(_B);thumbnail=i_list.get(_R);info={_U:stype,_B:title,_S:title}
			if stype==_K:params={_A:_f,_V:i_list.get(_u),_C:stype,_B:title,_R:thumbnail};isFolder=_F
			else:params={_A:_q,_Y:i_list.get(_u),_C:stype,_B:title,_R:thumbnail,_M:_d};isFolder=_H
			self.add_dir(title,sublabel='',img=thumbnail,infoLabels=info,isFolder=isFolder,params=params,ContextMenu=_J)
		if more_page:params={};params[_A]=_E;params[_L]=orderby;params[_C]=stype;params[_D]=genre;params[_M]=str(page_int+1);title=_n%_o;subtitle=str(page_int+1);icon_img=os.path.join(xbmcaddon.Addon().getAddonInfo(_X),_T,_p);self.add_dir(title,sublabel=subtitle,img=icon_img,infoLabels=_J,isFolder=_H,params=params)
		if stype==_K:xbmcplugin.setContent(self._addon_handle,_AI)
		else:xbmcplugin.setContent(self._addon_handle,_A5)
		xbmcplugin.endOfDirectory(self._addon_handle,cacheToDisc=_F)
	def tving_main(self):
		self.TvingObj.KodiVersion=int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0]);mode=self.main_params.get(_A,_J)
		if mode=='LOGOUT':self.logout();return
		self.login_main();self.get_reToken()
		if mode is _J:self.dp_Main_List()
		elif mode in[_Ad,_AL,_AO,_AQ]:self.dp_Title_Group(self.main_params)
		elif mode==_AC:self.dp_LiveChannel_List(self.main_params)
		elif mode in['LIVE',_r,_f]:self.play_VIDEO(self.main_params)
		elif mode=='PROGRAM':self.dp_Program_List(self.main_params)
		elif mode==_q:self.dp_Episode_List(self.main_params)
		elif mode==_A9:self.dp_Search_Group(self.main_params)
		elif mode in['SEARCH',_AS]:self.dp_Search_List(self.main_params)
		elif mode==_A8:self.dp_Watch_List(self.main_params)
		elif mode in[_Ab,_AW]:self.dp_History_Remove(self.main_params)
		elif mode=='ORDER_BY':self.dp_setEpOrderby(self.main_params)
		elif mode=='SET_BOOKMARK':self.dp_Set_Bookmark(self.main_params)
		elif mode in[_z,_AA]:self.dp_Global_Search(self.main_params)
		elif mode==_AR:self.dp_Search_History(self.main_params)
		elif mode==_AB:self.dp_Bookmark_Menu(self.main_params)
		elif mode==_Ag:self.dp_Apple_Group(self.main_params)
		elif mode==_w:self.dp_Band_VodList(self.main_params)
		elif mode==_E:self.dp_Gn2_Program(self.main_params)
		else:_J