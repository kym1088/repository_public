_BH='VOD_BASIC_RANKING'
_BG='/_next/data/{}/ko/more/special/SP0071.json'
_BF='https://gw.tving.com'
_BE='info_title'
_BD='genreCode'
_BC='categoryCode'
_BB='PARAMOUNT'
_BA='Second Step - except error'
_B9='drm_license_data'
_B8='/v3/media/stream/info'
_B7='mediacode'
_B6='6yhlJ4WF9ZIj6I8n'
_B5='kss2lym0kdw1lks3'
_B4='_tving_token'
_B3='token'
_B2='nextApiUrl'
_B1='production'
_B0='aired'
_A_='has_more'
_Az='cacheType'
_Ay='message'
_Ax='url_filename'
_Aw='subtitleYn'
_Av='access-token'
_Au='streamType'
_At='networkCode'
_As='apiKey'
_Ar='refreshToken'
_Aq='bandType'
_Ap='pages'
_Ao='items'
_An='studio'
_Am='banner'
_Al='CAIP0200'
_Ak='CAIP1900'
_Aj='CAIP2000'
_Ai='CAIP1800'
_Ah='CAIP0900'
_Ag='frequency'
_Af='scope'
_Ae='guest'
_Ad='free'
_Ac='adult'
_Ab='stream'
_Aa='watermark'
_AZ='header'
_AY='h264|hevc'
_AX='PC_Chrome'
_AW='authType'
_AV='audioTypes'
_AU='videoTypes'
_AT='model'
_AS='screenCode'
_AR='osCode'
_AQ='user-agent'
_AP='authToken'
_AO='state'
_AN='queries'
_AM='dehydratedState'
_AL='vod'
_AK='imageUrl'
_AJ='release_date'
_AI='icon'
_AH='info_genre'
_AG='000'
_AF='streamCode'
_AE='bands'
_AD='bandCode'
_AC='genre'
_AB='desc'
_AA='premiered'
_A9='grade_code'
_A8='channel'
_A7='pageNo'
_A6='playback'
_A5='drm_header_value'
_A4='drm_header_key'
_A3='drm_server_url'
_A2='HTML5'
_A1='callingFrom'
_A0='noCache'
_z='deviceInfo'
_y='uuid'
_x='mediaCode'
_w='deviceId'
_v='product_year'
_u='order'
_t=','
_s='duration'
_r='clearlogo'
_q='mpaa'
_p='year'
_o='cast'
_n='%s-%s-%s'
_m='broad_dt'
_l='image'
_k='pageSize'
_j='accessToken'
_i='error_msg'
_h='tving_uuid'
_g='account'
_f='category2_name'
_e='category1_name'
_d='pageProps'
_c='fanart'
_b='thumb'
_a='actor'
_Z='synopsis'
_Y='episode'
_X='Y'
_W='name'
_V='poster'
_U='cookies'
_T='result'
_S='streaming_url'
_R='data'
_Q='0'
_P='director'
_O='all'
_N='-'
_M='Get'
_L='thumbnail'
_K='movie'
_J='title'
_I=True
_H='utf-8'
_G='body'
_F='url'
_E=False
_D='program'
_C='ko'
_B='code'
_A=None
__author__='NightRain'
import urllib,re,json,sys,time,requests,datetime,random,base64,os,xml.etree.ElementTree as ET,xml.dom.minidom,io
'\nimport xbmcplugin, xbmcgui, xbmcaddon, xbmc, xbmcvfs\n__addon__ = xbmcaddon.Addon()\n__language__  = __addon__.getLocalizedString\n__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo(\'profile\'))\n__version__ = __addon__.getAddonInfo(\'version\')\n__addonid__ = __addon__.getAddonInfo(\'id\')\n__addonname__ = __addon__.getAddonInfo(\'name\')\n\n\ndef addon_log( string ):\n\ttry:\n\t\tlog_message = string.encode(\'utf-8\', \'ignore\')\n\texcept:\n\t\tlog_message = \'addonException: addon_log\'\n\tlevel = xbmc.LOGINFO\n\txbmc.log("[%s-%s]: %s" %(__addonid__, __version__, log_message), level=level)\n'
try:from Cryptodome.Cipher import PKCS1_OAEP,AES;from Cryptodome.Util import Padding;print('Cryptodome')
except ImportError:from Crypto.Cipher import PKCS1_OAEP,AES;from Crypto.Util import Padding;print('Crypto')
QUALITY_LIST={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
MPAA_LIST={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
ATTRIBUTE_PATTERN=re.compile('((?:[^,"\']|"[^"]*"|\'[^\']*\')+)')
KEY_LIST=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583',_AP,'cs','TSID',_j,_Ar,_B4,'GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7']
class Tving:
	def __init__(A):A.APIKEY='1e7952d0917d6aab1f0293a063697610';A.NETWORKCODE='CSND0900';A.OSCODE='CSOD0900';A.TELECODE='CSCD0900';A.SCREENCODE='CSSD0100';A.APIKEY_ATV='b6ac9e6384d93d6e533b144b3ef22c42';A.SCREENCODE_ATV='CSSD1300';A.LIVE_LIMIT=20;A.VOD_LIMIT=24;A.EPISODE_LIMIT=30;A.SEARCH_LIMIT=30;A.MOVIE_LIMIT=24;A.PAGE_SIZE=20;A.API_DOMAIN='https://api.tving.com';A.IMG_DOMAIN='https://image.tving.com';A.SEARCH_DOMAIN='https://search-api.tving.com';A.LOGIN_DOMAIN='https://user.tving.com';A.URL_DOMAIN='https://www.tving.com';A.MOVIE_LITE=['2610061','2610161','261062'];A.USER_AGENT='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36';A.MODEL='windows_chrome_149.0.0.0';A.USER_AGENT_ATV='Mozilla/5.0 (Linux; Android 9; A95X_F3_Air Build/A95X_F3_AIR_M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36';A.DEFAULT_HEADER={_AQ:A.USER_AGENT};A.TV_COOKIE_FILENAME='';A.TV_TOKEN_FILENAME='';A.SEARCHED_FILE_NAME='';A.TV_SESSION_COOKIES1='';A.TV_SESSION_COOKIES2='';A.TV_STREAM_FILENAME='';A.TV_SESSION_TEXT1='';A.TV_SESSION_TEXT2='';A.KodiVersion=20;A.TV={};A.TV_TOKEN={};A.Init_TV_Total()
	def Init_TV_Total(A):A.TV={_g:{},_U:{}};A.TV_TOKEN={}
	"\n\tdef callRequestCookies( self, jobtype, url, payload=None, params=None , headers=None, cookies=None, redirects=False ):\n\t\t#HTTP_CLIENT = httpx.Client()  # httpx\n\n\t\tsetHeader = self.DEFAULT_HEADER\n\t\tif headers: setHeader.update( headers )\n\n\t\tif jobtype == 'Get': # Get/Post\n\t\t\tres = httpx.get( url, params=params, headers=setHeader, cookies=cookies )\n\t\telse:\n\t\t\tres = httpx.post( url, json=payload, params=params, headers=setHeader, cookies=cookies )\n\n\t\tprint( str(res.status_code) + ' - ' + str(res.url) )\n\n\t\treturn res\n\t"
	def callRequestCookies(G,jobtype,url,payload=_A,json=_A,params=_A,headers=_A,cookies=_A,redirects=_E):
		F=redirects;E=cookies;D=headers;C=params;B=G.DEFAULT_HEADER
		if D:B.update(D)
		if jobtype==_M:A=requests.get(url,params=C,headers=B,cookies=E,allow_redirects=F)
		else:A=requests.post(url,data=payload,json=json,params=C,headers=B,cookies=E,allow_redirects=F)
		print(str(A.status_code)+' - '+A.url);return A
	def JsonFile_Save(C,filename,dic):
		A=filename
		if A=='':return _E
		try:B=open(A,'w',-1,_H);json.dump(dic,B,indent=4,ensure_ascii=_E);B.close()
		except:return _E
		return _I
	def JsonFile_Load(D,filename):
		A=filename
		if A=='':return{}
		try:B=open(A,'r',-1,_H);C=json.load(B);B.close()
		except:return{}
		return C
	def TextFile_Save(C,filename,resText):
		A=filename
		if A=='':return _E
		try:B=open(A,'w',-1,_H);B.write(resText);B.close()
		except:return _E
		return _I
	def Save_session_acount(A,tvid,tvpw,tvtype,tvpf):A.TV[_g]['tvid']=base64.standard_b64encode(tvid.encode()).decode(_H);A.TV[_g]['tvpw']=base64.standard_b64encode(tvpw.encode()).decode(_H);A.TV[_g]['tvtype']=tvtype;A.TV[_g]['tvpf']=tvpf
	def Load_session_acount(A):
		try:B=base64.standard_b64decode(A.TV[_g]['tvid']).decode(_H);C=base64.standard_b64decode(A.TV[_g]['tvpw']).decode(_H);D=A.TV[_g]['tvtype'];E=A.TV[_g]['tvpf']
		except:return'','',_Q,0
		return B,C,D,E
	def make_stream_header(J,headers,cookies):
		I='{}={}';G=headers;A=cookies;B=''
		if A not in[{},_A,'']:
			H=len(A)
			for(C,D)in A.items():
				B+=I.format(C,D);H+=-1
				if H>0:B+='; '
			G['cookie']=B
		E='';F=0
		for(C,D)in G.items():
			F=F+1
			if F>1:E+='&'
			E+=I.format(C,urllib.parse.quote(D))
		return E
	def makeDefaultCookies(B):
		A={}
		for(C,D)in B.TV[_U].items():A[C]=D
		return A
	def getDeviceStr(E):
		B='undefined';A=[];A.append('Windows');A.append('Chrome');A.append('ko-KR');A.append(B);A.append('24');A.append('한국 표준시');A.append(B);A.append(B);A.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC');C=''
		for D in A:C+=D+'|'
		return C
	def GetDefaultParams(A,uhd=_E):
		C='teleCode'
		if uhd==_E:B={_As:A.APIKEY,_At:A.NETWORKCODE,_AR:A.OSCODE,C:A.TELECODE,_AS:A.SCREENCODE}
		else:B={_As:A.APIKEY_ATV,_At:A.NETWORKCODE,_AR:A.OSCODE,C:A.TELECODE,_AS:A.SCREENCODE_ATV}
		return B
	def GetNoCache(A,timetype=1):
		if timetype==1:return int(time.time())
		else:return int(time.time()*1000)
	def GetUniqueid(H,hValue=_A):
		C=hValue
		if C:import hashlib as G;D=G.sha1();D.update(C.encode());E=D.hexdigest()[:8]
		else:
			A=[0 for A in range(256)]
			for F in range(256):A[F]='%02x'%F
			B=int(4294967295*random.random())|0;E=A[255&B]+A[B>>8&255]+A[B>>16&255]+A[B>>24&255]
		return E
	def Web_DecryptKey(C):A=bytes(_B5,_H);B=bytes(_B6,_H);return A,B
	def Web_EncryptCiphertext(A,plaintext):B,C=A.Web_DecryptKey();D=AES.new(B,AES.MODE_CBC,C);E=D.encrypt(Padding.pad(plaintext.encode(_H),16));return base64.standard_b64encode(E).decode(_H)
	def Web_DecryptPlaintext(A,ciphertext):B,C=A.Web_DecryptKey();D=AES.new(B,AES.MODE_CBC,C);E=Padding.unpad(D.decrypt(base64.standard_b64decode(ciphertext)),16);return E.decode(_H)
	def WebCookies_Load(A,wc_file):
		try:
			C=open(wc_file,'r',-1,_H);D=C.read();C.close();E=A.Web_DecryptPlaintext(D);A.TV=json.loads(E);B=A.GetDeviceList()
			if B not in['',_N]:A.TV[_U][_h]=B+_N+A.GetUniqueid(B)
		except:return _E
		return _I
	def GetCredential2(B,user_id,user_pw,login_type,user_pf):
		D=user_id
		try:
			if base64.standard_b64encode(D.encode()).decode(_H)in['a3ltOTUxMDg4','a3ltMTA4OA==']:E='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx'
			else:E='aHR0cDovLzEzMS4xODYuMjAuMTE0OjE2NTcx'
			A={'addon':'tvingm','method':'LOGIN',_R:{'type':login_type,'id':D,'pw':user_pw,'pf':user_pf}};A=json.dumps(A,separators=(_t,':'));A=base64.standard_b64encode(A.encode()).decode(_H);G={'proxy-mini':A};F=requests.get(base64.standard_b64decode(E).decode(_H),headers=G)
			if F.status_code!=200:B.Init_TV_Total();return _E
			C=base64.standard_b64decode(F.text).decode(_H);C=json.loads(C);B.TV[_U]=C
		except Exception as H:print(H);B.Init_TV_Total();return _E
		return _I
	def GetCredential_test(A,user_id,user_pw,login_type,user_pf):
		M='{} - {}';L='ko-KR,ko;q=0.9';K='accept-language';J='accept';I='WEB';from curl_cffi import requests as N;E='chrome';F=N.Session()
		try:
			if login_type==_Q:G='https://www.tving.com/account/login/cj-one'
			else:G='https://www.tving.com/account/login/tving'
			O={'returnUrl':'https://www.tving.com/onboarding',_w:I,'deviceModel':'Windows,none,Chrome','deviceName':A.USER_AGENT,'loginPocType':I};C={J:'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',K:L,_AQ:A.USER_AGENT};B=F.get(G,params=O,headers=C,impersonate=E);print(M.format(B.status_code,B.url))
			for H in B.cookies.jar:A.TV[_U][H.name]=H.value
		except Exception as D:print(D);A.Init_TV_Total();return _E
		try:P='https://www.google.com/recaptcha/enterprise/reload?k=6LddMCQqAAAAAF58SSwcjpnOv1c9wWuaaQyiFQIC';C={'x-browser-channel':'stable','x-browser-copyright':'Copyright 2025 Google LLC. All Rights reserved.','x-browser-validation':'UujAs0GAwdnCJ9nvrswZ+O+oco0=','x-browser-year':'2025',_AQ:A.USER_AGENT,'content-type':'application/x-protobuffer','origin':'https://www.google.com','referer':'https://www.google.com/recaptcha/enterprise/anchor?ar=1&k=6LddMCQqAAAAAF58SSwcjpnOv1c9wWuaaQyiFQIC&co=aHR0cHM6Ly93d3cudHZpbmcuY29tOjQ0Mw..&hl=ko&v=7gg7H51Q-naNfhmCP3_R47ho&size=invisible&anchor-ms=20000&execute-ms=30000&cb=mb9i1hcvsm1e',J:'*/*',K:L};Q='\n\x187gg7H51Q-naNfhmCP3_R47ho\x12¤\r03AFcWeA7QlpoZ4DOfv2QeXMFJBndjiCpoGkHbxdiRdUkUwS1-uMxF5AIucNffP6voVUzd7eAaGwPxir2l9yY-FLgXty2qUMuoQInziN-bUWT3SnvIEr1A0PQe1GkEq4gx1jFrRUg3OGK67obgqII7-3EGZs306dPx1e0I81cI7JL7TY9k7OaFgBAtvmxTwMpFY9ZYj_C8Wn8WFP72uJ-8A4_aYJzizfqHB2PsHHQ121CiB39h7SRfCFWQF4RukTz1a__PqmsHCQw0eXBcsdYWmZWjE-Amu_Vi_zCigufEsDu7qkAGxm4dWVVjAGGmxXVLUY5cRNR2YRfOTfyxVMftRV31JQho2dPYUOMtYDk7D1bPLROCHm3UMsYx1ZqwovHc5kBypHI7nmyDZVQNurpxnf8BHJdO-bENRFfVEcD4lQqHbseWkfkGmjVaM0pY1XzOBzDmeOL5cgIsbEq-A_NV7Q9X2uQ0Cp4aBu7wWwdkWSRzkXmWQMMhZlS3WSxK0O-fOevhnOFoqYtNtXS9JLcJ2ikEf_4GAy8wRSG4TSexStmWr5AJcBfwbOKEF_7-7oi3-P0veTBJdPmpALZhGvRYJDQWRW_UWp0D3_BoAlVP1z58HhXqRoxiTnvOnfPj_VvMIXScxcV8H7Y-Zy6fWWVXcT9ZRh63PymBu8jAiHsUOHXzTLD5op5LriFZ7C2XbD1nMJ2nvfpxvfeEuOEhgYbTHXXmE-rrgQMiaXq9Ge__kb_0KFaYeAvAtoZU2R_q3JGVv1VFEzJq_00AE4TZgAqQF5akl3weSUS2XikH1ow6zSxX1g2abeNYszN3leb_4MoXKLcXFkWGrRSsHecRchq3EFZsEACLZ91lHfSZMB6fntPUvoW4CZVRPxTBmSc_Kb_9Nzu_4tnx0Ii1kyvMvOWvjPGsd30n37XesUzk15RhkUExbXi1ehzoNjjE3hZkQoN3F44zB4DGkp0Z-71aQQ_T0m1E16ATTFIrXjPRBTmHDWqMzIdEM37NpX3kQTIXZl1fBSrwhXoS2fk8STlsEIbhAXV5gU15ePgDpgN1g_mnMFMjTgA6wpOs5rq1_f4PwuCtnc3_SSfYavCRgm2U9mWeYtVv3t0JwswPglbbyRmt6EZefRX8ZW6lWZkJTauZDxIDZu63gxgjgQuaRD5h_EKbQH-xHVZaJ-IHLdEtCrwFWyAF89IAeUrD8T666dgMWSos7Z1JUiSItl0d-jKr1vE-B3LgJU8SpKY_G0sqMgNjeDFMnzJ51rOSwd0nd2VGH__UT48vTOvuoFXvhh9B5ZygVx_LmziXx0nF-5TzRPwMvdCfz9OtODiAOnBVYo8TBT8jnRYU3N2Q6TpY6MRbZMV-9BElHg6cife5Kiwn2Yw1uLPEn7B4iR-jRADgiwpU7M7imTDmeFHgXCNT9MISqAeQfEm3Ps3v6xPKeqMhPw-WKMoozij_j2KtwHCkez7LMjrbzf9CAt92oG1XQ650J-AKCnXHrG3nVpsPRAkzw8VsUjRdkqzrmlcAPNYh4ioKkeKP-Jo_Zu6Z9a4aVVVXFmLzS2_ABbdg4o0b_3p75TUG9E8r66sbRC1QZ-JhvEdhHDNw8vC2hjtUgFiMVs0d4v_4wOWRnX4I7Oda0tK7BCCFXpXeUjAGNvo5PhqSvpOTsXNTndzRROSA3SLNBHxWSIlbYllwVG8ZsJgRWA"á\x1c!T0mgSUwKAAQeAj8ibQEHewKxYiBr9egqvd-Uqn6k1oUR2hGwD5HCWI_PDIqqgn-QUgbaTEFsh0EkpOUDMOBC6TbH1kpzngk5TF9xUa1y4ZnxTilYIRg-180Di84XbN-W8Rqhth_Kog8Qo_psMH0CzrSwWqsJsE7HeAOWVrHSsib1Xx3DlJgy-MiaCayD_TZZ3MF3TczgXPAjsnBpcAZU14WIgb6nykNJsk11lRr6esfaKT8gTa5JtsMf8lHJQtv-AAksxw1fs1NZZSF8BXdy0tpGuQpjiYJ92BD5Jd6jN_cY6m9pgR8VTBVJs7ZveJU6pGldP3tGPEkJ1YEHFAvXufFlnIY6bBC7wJ2j8IrdZb4noXm1gROlBQ0942z461QHjkBAUzbwKt5Dr5eHf2En29QToBkKZzSD4HYZ2K2g5X-7TcHKGYAEVoSb1Cm7Ja8mIacZe2qvHEjrWQKADO40YQYt9OV0A2_pcdS8rlkTBHDpWO6v4uPuOvARtyNzgZq-lInyfgOePtO3aQvMuNshM_VH3KA7QN1T2Y_h1wG6AChlUeIjoA-7m4Li4anYMr2_kC5K0xZX8Vc9p0qVqq4OJAMjGMQkEhrC0NOPU0jpWp3Gua99nbD0xsWCrzA72rc9KTjTbxyncNwJi8z-fFRup60njPb-jejty5rZ_gDun_Bn8oHU3CWa8eFyrY33z1hWzbszcYFKLRAUgC4GrpAYvGMXKipynF0E6_DBh4DwKNI-R78OPsn4nvXVYUR5PpLRqPlaSFEop1hBGJEaRkp6fhCD0J2LZbIPYjshsjlrIcLPJM7T6fEJVV2QUMQ1xOmtWwayl08mZkJoDuIIPAjFYdJALWWWC6mFfENOeJ1CaxC9q-ralKa1pB_Uhs-MR1gH30ab02d-_Q27M0royzM4nz_wlfRI1_yTNO6qCe_jEVVkPhWcCAKTJjNpXhd66EGBHPHR8drtTxYH_7Ck_mQ_vnTJJ4f8nDW8kP4VUrEWOPeGubm1CI9LCvO9aL911Mm0Ps3bjPWtpeUzhNFf0xJuwfc1op-XLEzVtcXUogcbN6HTfLE3y3AgMGCwxZiSLykZjonxZrATCNPvMAdwhLLtWq0FGDuDbFBF7RfZQ-hCvUG6PcTF9ma9YfKXl8j5gUPDjbkoO-ulFjE5mEereJbkSaQB5WiKlyJih1xSTdbwvt4zBH1kDJnq_zJQBCRc7aKOSVO1A-0wjmlMraVsRAV8dyBJgS7CBBPbE6Fi0njmpkdIokLCCIjVjFk3-4KuMNX8PPKPSePNUfwnnYB-wfebjHUgG-fFquFIHBxgi44jgng3OVbCS18vTp4li2-K0Yh2Z1iHGOli8EuoryizLltxBeohnsTOS-uTTjLgLvk-Hxg8xufzngtLeBL3ElSZOphEpBL3pLxgUI4vs1YhEQkQhopIoI0QPGEHOaPtuQEPbjrzoSv8qpYdhK5AOozbzc_8lFD1oKbJ6AncRxHGLd6YwE9SBlCaHCpIKlHi4okZC14FTN-4qroiM6RqKzH9L1QT0Sn2Z44fNMuPwzI-RXV4kP996fMHUDYVDU6PNlUz58o-bLK-Mqi-2vQu_PDg_CJbjW4MAtlEFM-uusY4mPrV6GgaM9bwYtWGkqRqiGljYV_zez1DPvGUzBNiQ-ktXB47rq2Cx7BlLdRX_ACZPIfCSupIZNJcc-3CK9kf16juEqQu7KlhucqfaE5_7hf3ZY8XBKF-ErucVBvKfTGBA_6jj3JigYJveDr-DH41TlRHWquZljiblx4e_YkY-f85yjRLAHCoi5NvQJhiKILmPkGayZAEfDBZgA--cuT4tfbP5t4qIk0QNdeJ8l_QLm-DJZxdZKG4fH1b9jBasBd7eVczL9OPGNi1A05uJZ0sIUMF4HCm3FjPtpyA-kb8AFAZxsZ5KhDW_fAGmPsWTghNTIxb6rUjf-OfhPxnlNBYn4_DOIo2HGLj5DheHoMIxOLufShix6yaOVy3jbhDBqqKr7TW98qyzaoV6IdMGh2R3RpNFMATWgfvBEmlxDUqHMiQnsg2rKlDW125wnJcu5VcvDwCyaGU2o9CVS9-B5gIAt5x2f9o6n8hlTiX2eP79PZotUbiZYuCmhoSgXWe13hNLPVHJZJ-L74JGfS7Y78AAJDUXZeV6wlX8BY8z-7sotW_K3kDB5kv9Zzm_TVDd75pvF08l52PvmZNLFBsltIB-VdEirSQTk60liURyMAr06OMvZSJfa5VE1IY-5_vhZIaFIa52Dzht-ybIv8NY8700ct7Ifq8Apz_ZRduGXQKN5i3VDg-Dq-eeF2gzuh9hqrLA-gN30VWhsBFdsONdBfWg8-Lcj9DNmvxypF-3_gYR5oKCwUmjaR_SgyfRuWWfJWe69Gp-sa92yuCPKQtXb-K2kOohCqiM-pzjDvVK6oAAK5j_V38fyPtPDYEUCypFkKgbjfae7SP-sQMHXv00H4YZKIIbLZnuMlIMf-F_z2TzJoGLVVsLOoBO0_ctvUmctPQmH-y7lE_Ri2M_Wc20UeYqqf1Z9pbWBFsOTasQO76p4mDgPrs3AnlimT6ouczFG2hAFDeSbI7EYQ0hfCoZQWQcBaZ_KytiNNZqFYwJxo74oe9-qrgGdlWlkgWwKU6SlmJLz0CoZdoXq-LAxOzZ0S0or5HUyJ74rOwFZzcwNQ9n3bWVlm2TU8SJT_XkLo_UPZAwlKTO8ChbgBkF9FRi9A82i80YAZiV5g-yjDbjTYWb5ht5_F4VmA2H7I0ZZcT2-Bxi4SLRosehyWfIG4Dv0QGK3zFKiv2CpgCPj5atV7fZHHlTSS0vzHHWmiIZzQ4_AvYGlmX8pxnAjrifecVQoCCRjrCDtgJ2BsnmLwsR-oMIoSvfuTscYcPT5M6BbEPFkSlJKU-wd_sJI3tyBjz2W0GiSKEwpS0L_8pP1pIjF1-AU7LUKVNDNykkErt6m7sfYv063D6ic0dQF4eZcIYkdM4rlXpdZW6jk7_M-5AiaxxJvCgSToBLgH3D76R5huRS18Wd-W-MIitIOzYr64SmHFFxXntH7tN6OXd39LFH6i68T75mzzpJwNvwtfHlb-V665y6dX2Vi9Yj7vvIdTzzK8lPXI7y9dNWc1MCzExjQlAg5b1XTTA2RCKzi8pbKnlBZUWajZrXQ51rAZ_-HZ-pqsCeJRkd9qN_p2QFk62qvF1DpyF8Z0gsF3ACbh5TYF7DKSIUhoSRq2hdJXlvoXgRIRPAWRrm-oUhdFsv_R_vci8LuQAFM_gam0ReAQjdKcUIkMvbU0vDJfx45Yhi-xUIIcv-c2e_ba3W8H66QRWjOWGcnCn6cuFHCSt31UCLaFa30RctRGVaqaIqvs3OcREZcGekd3zqj9UGZwNQz2a8a4Vu86iyKsLH_FLTKonzbLCKrmYoBmf58F1tBh-gKURZrmEl_O3UvdRdstZEu1oDmxYMRgka_tfMRyhm4z-ycpRZG3ZnFdwkB061AxUoab7KFJPRoP-itIXBvCOtBG3TBT9Okr0UR6LmYBEz9k4ZTZ3Yr_UYyFJ860NzL1NRAdaNg4ZliDkRzObaO-1uJEKF7pnL-_ap4_txmN00uFlS_qXTqOdyEDj7TThxcCok94rYq8OYeaoEGXKBP9fYeA5-yhMQeiQh0ascFICZ2WMFQlCw1rtbPiF4yTmUBH6qTHU*\n-8304418012\x01qB\x05LOGINr(6LddMCQqAAAAAF58SSwcjpnOv1c9wWuaaQyiFQIC\x82\x01×-0RRWH7UOiwWLIHn2cPaP5WHcYftQzUqcZqAQ1gutPqUqwBmWEJYvhQF8AZrwbOttBl_YVthxy0fCR902sy2zSKIemR60DYoEiiN49XP1juRg3xeuS7TGt6HKb-nroFYUMTo0fYOgjdwhhlRtYoxJu5TuvIHa5C1j0VqjpIrzqUKj9iMtkxxhd3ECL-0rEEGTCOUy1VrwScZAxl-1MawxyyCdG502jAiHCKH7d_J0DWbjXeN40k7JTuQ9ujRtB4CyS7WGlJWnrQHvhYZwFaLwWmt1ZmyA5yBhX5hms8WKlFYS0QX37RaIMR9YadMJbs_CEpDBw2T2P6HSkN2rnOYXvY7HrXL5GouUliBF03QB-316EFFGwFFrvVqcVRbUigNAqfQNasSN74its9zWAF3e1RpfcMbzoS6j1i7MluBFQsP2Ovyho8Fd34ESpB2G7JIXeaJYkSuk8shxqsRh1oQpw0y-L5U6vBpLATnQTZ9wEk_xVpN1KyR-c01pkzTOX8VWoEXLLVYMRN9YsmbMcgORAn_dgwRik0mCGJXXoRHICP6X0fb4eiOotjSk0nQNnvh944UGiJVPhB6bzWdjiS68SddMmj-9P0wGPtVSHJzGa_mPDHnXePp4iUN4Eo9Y3oP-L9BCC6SecImWjF4OyG4HgRZ72X78fo9FfhSR05Eyd7minFIHDQ57jXp0MV-I2odokg8w1m_tZvRB52Te963mfPp_Ocq_6V5cAZMcqidtEpAOItkRqCVOmO0WuFHLQL4nyUrA2ZPIYtwJKy_NcwCSA4jegAF3kEqDGZZgSQqsRcMwyhu9PqzNh7xW0C3eR-mDEG3zVPp76grA-ZANH1hdV5kamBTnPC4qqA3ffUpf2d473W7wYfdc7mvNVtQx11zW553WbOobrXMcCZaU7feU2gfd3r0KKzTWw-UbV7VjpM23pQqbseeA4rPhJqCNcoDmS2RyUEECdD5PcN5vlbrX1jOEHkgxCz-mN1xOZwD-65T2N9lrAH37ROpr3fqxNswlohxU72hqFD0rI9mu_FZLYJJAXQeHpUrgZfNItlvhO2giWvFuy-DihB2vCI3zlRaEpV-ULquBlvjiH_Fay6FWjI4r0LYnkVcsnbMVBnd5ImhlXshpc1hmc2VybDGvkParsMZMGjsMpaMpXhOGKuwaHxUqiAUCzDVb8LXsQesQGhegpmctRsSxt5yur-jm4FHneQ2H7W6jvbcwzVeVQpg9f0gRy0k5ZwiaM60ulAmK_IYHXQ6L7hLJAZgV1suJLsRB1ziaP70rTAaIIXr3capAvdeUhfPFUmjVGrxN62TGP8k6xEWzEMI_mcZ8tU_JbxPF0pBOPvhR7-k2vCVq0RIHndpIqcus_buBWwOWI2Seo2yOj3F7ZOXe7OIYMLqzxi9cPjstjxxFeuwR8-zug5HiuN3b-V7__R68bmfwWrfVkz-lovhGr5TrM5VzfQZ7wY77deNNBjc1TsdZalg6XxUal61Kb20SuDGvNJIbkRaD6ZsUbp9VjiSh92zGtClO04EmtEXLRKIzuTasFXsohgQs5x-2M1i53yDGV-1q6DHXWMLnndZs6rA0XgOZGqgdbxCV8CDbE6on3UrwKeJMVQaoOc9Muhe5NpzJg7hSzE1LlHXgCI6v9X6wXcrUTpANF1TNe5FGx5F-P62y6AnPfR5P2WK09nNFRqh1clgOZ2CCd0kCO_EvGQ677TJgmY7g7Xu9YnNdSvRqN7juG6zOsD1f0M2wRb5oiiqgcd9dBkQN2zw1_zy6d-k-vMmXMDoT-ZsP_YbIihBAvzRdawARx50jF2VGcEnXhPKn8S6gkdcc4oPRN0htkqEWn21uc3lTYJKXYLn74U5r9hOcpcupJzxOQ3yGxBU_QKoe9Q4jyR4IHhtQ5g_hMruw3yPNutTdy92vAMlHYJYvrWKvkiegoc9RPpdtuzfVt_U6c-XeoF5fzJKjuRNEbass5gNkrsxlYyDN54WGM8XPdHlTZG24GVqspguRBrMU7lwV63AaF3Dez9GPjQqDULI8RT5Qzd-w5lARgxgVg3E2dCCGmKnTAAmLUOI0hS7EwcLcsjPt0sSaFxDR-EWi7-HDtHIUFOqfjduQNfdYdrhM3yAdn3FiODmXTAJHhS4juQ54gZ7chefYithJ2szVs81m95VfK82zFFrL0PqQacL86rf03q_h02_9f9TSjAVHVC3XHN6YLLbAXZtQjgPxPiRhKviR3A1a783-wMmPrMbYAV7D0mdcxq-RjwDRv5RqlykW4HF7BGZnUZa8RQ-Arb80unglqwxhXwSSIBHG8G2_hHIz5KpsUdqcfkAIetfN-nfpt8C-041CA6U2xDWzEKIblcZ8tU_I8o_5azhuB3EuHxzCW-lGyC3TULrjmdJo5mf4onP5YpRGQzmaBDj-1CGrGVnjzaJAAgq9Tct9ewDFZtk5q3Sed-l3EN4TjGXwZR9wrbNM2ltJVjjCUux6CAzet_lTWB34JT6MBQr36YNUTitRQqgdYoQpu0i2S5U6uB5LATnQTgLYzgMUiuxlwlypv0k1v7HfJE03INXIPR5slXZb_Y8ooguQ_pPxavBSA3zbB732jQrEDUn7nTa8QasIri-RvnStR8GF_An61Noy4MbLxdrETbe4tcsxnrSlM7DiAyFGdHnDfIYvsIqLbUJo3jdUSbtdvxwmT4k-c4FGiBEasI4D3EXreQ6P-Vb4edwIwvuSDyUupFFXGEFLeLn8IaoMHgcEmePY5e_xKsDJs0xeI5GeuBF_qQpzjaaQpT9kgnsITfOJEpAJXwCB4BDLA5oW6To7nSLUSat0aWsMnjOZMngdnv0t5By3MDnj9VZEKWJX4mcgQlxZexvxFrEODDk2z6Hq0SHHgRGzVOZ7-WbAZeNldi_NRsAtqzySy2He5A6YBOMcSXs84kdRLsfR0hu9TtxF4yjOS83elM1nZQqvkfdYYn8BRoPA7yjVc9DJ3Bj-D7FC1DnLQMIzoTKcBbcwjrtxqkC971U19-ku3C2vNRbjvQcUmXuQLbORurQaAzElj_l-P9Fmg-pfXOrnHMJT3WrkLdNMyuOZ0mjmD71yb_YvFA3XBRcX4T9MtaPgcdu9OxzZrzwmSBC2IFn_HQ3i0HYPjRp34YcAfpdNhhwdw2VWs7EXENH6-Hmz7YJ7lYckJbbEagN9CnfVhwENx_yXEGWf2UoYQPqICg7kqjdtCtwFRxRN50xu-EFmxKnjcLbvjSKkfZuolrcxliBp7ugOF81yY0DmdAV66FH3cOMHvfaNCjBBixy-MqiCEAjyI-H7rCaXaJILcTqsfddZUvelnzPBs9kmU6Su8BmWnCVa_I4njQ5oDYr5HdQNiwedr8lGoDGR-AITtSab9GYLXRacFU-0bqc9P0zyY9VC7EiaP5FK0EmD6KLbcZ-dLVtYclSRy3jNQuQ593ivFJFK1EGX5as4jjfRPXfclsxKE6kCfviJ83zqPP6TBNokWZ5wydcRXa89RjvSCsR-BzXCAHEraJHroQrf7QuA-W-AZkRBol_GD1VWG7mWf64zbBXn9RZkcRaEVdvNkoBdPrjeSuEa60ni18IvBRnP_Oa4YjsMdoNQbhOFB1CSN_0-01mbI-3PEUKbiMMkhXLBCeM89oexf5kam9zXCG37j-pXRFZYRS83wYuMIa-RFjx9nqSGj5C-O0myaO6H3VnUWfNIxUN5QtgxrivBIqwZb4F6GHWLIBYKyTHobgdc2VfZcshEw0TeN7AuZC3HHJkWoA2bBFsn7VLsicfFNjh86yumDsVK4Dm2MLZPpSGf1Z80jgqEEX8IdchVDsxx4u0vA-Ui2D5rZGJQTYI8Dbc4Nses5u-iHoUKj_zuDDmzB-2m2SboMJb_te-1TqQgni-VKo_hu-DW8F0PeBna8UrbdWMAxmN5RiA96semDzwyA5yieKEzEJqP-YsgEWMYzl90qjBpKxROXtxVq6y--DHHjIarwN80qVd5Fc-ZYfyB0zhpuyzquDTqpJpjKDp_NRbwSh-wYjAM7nSZczwRg_TjCFnfaLpLHFpPSLo8CbbJKnwomlxpapRqIv0h__F7iFFTBHLYaZtAahsMisehzmPc71QORA2m_Hj2g-165DrUWbb_7mftdvAdY0DB0sg-oBUu5_3-6GqD-WL0GdaoJTecVoxV70TBPsw1wyyCeIU_MUKTaWM3kROIqhPk_kxRjvj6csheZ2XS8FmSwRYzUUKv-e885rwhblBhE0v14-DzCHn-oDZzlGpQTRIoFg8A-p-tjzCpeozij_1J6EFrEN1_TYK_pTcYHVbpRtPFxkSNq0zKE_TiY_F3fRZkBXLsCgNMxbfU_vNdOqxFy2BCN_EfKA1mpGortS5QnUNgGdflEe_FAnjNX8ieV0UCjBJOrMqDlQ58da-wmkuAjff9fvBx3zE-w_S-4_0PdC5kLcccmRakDZsEWhiBXyTRf9VWZ7lXc-Yy4N3YDdtIYT8dRj-FOzQN7ySZrylO3Hn_DLn3RM4v9btwpnbotqBVLjxOHz1F78ErFA1q0JXQEUsLghbQYfdgpfgZRzSRxwxaeDSu78IXLG2ztasnuTZErWedZvxV0k_ZRtA9kDkelJVW1CmXLI6ouh7s4dAE4egh-uyRcq0VzAXPZL46tEGvOKX4eis9Pj-lKu-WEqDxm9CSUGGvTNXXtIoHFX40bjfNJqMcrhehDmCei-jam_nKzBGEFY7ELf7Qskbs6o880pTVLqkSj_WOMK2m1CovRKLXYUbsOYe06idk3xPtu8DmXyFK9JmbDCqMPJ70Aa7syoeVBgiBdtjqT9B296GPTDX_rL4XuS6cNW6UmrOwhwiN64iJu3jCNEjyXPo3KJq_OR5Eofd8rpwJFpS5XxB2ivze1DkHYHnPcHqsbVJMLk-JJsMswkS1iqB6iDkGD3HniMaPeYLriUK43kP5clOxH1TVmzia03kabI4HlFnzeX7ITZtEkgswzsu1xyQWG7U53DWOuDXKsKWrBY4PeXqI8fttRnuCErDNa2SZz9liZL2fLMJXlbJ__grcmbPpjhiKB3TFk1Bmu70yxHVPcF7cVLsUkgLBOrtxNywuLtSho0xp-4nDF_VrPNrvwNrUQWutVp-ddzRyTvwqB7FWkGmjbH6HwU6Eafs05fadBb_1v1SuKqQ1nyyV6KYTEJKDzYZ4ChcH8cfA1eiA-2fV9thKuAlKWAkazCa7LRrbliMojlvQfxSVZvfieuV-r9jmtNpbYNKHNT6EChcI9aN46i_V34Rmd8D-hDVi-GJzyFHnQb9ciitRTkOM9rwpKwxuq2T_G_D_mRYTgIZggX7gRZrkygtUz0jWLsEqezTuX_37GRX7fQYUia9cNl9JOighGui1y9k2dxmDC6YOuHJgGSYrkXNYWY9IwlRk-1ypyu1aVA2-1Doe_HazjPYEKZesGgeZXgxVuxEJu0jKJ1VKlJpLTRa_3L8XrkdoZZclaghmDvf939Ry59D6TGlbeJnkKVdQKhuREkeApldlzoUKo_l18HYPZOFf4XrQTMsAymO5NbM8qjeg9xB-I_0K2InzrBWDbWsLueNY4XLtKmx1X0viTvACayFbILoTjAmXAI37TQLs_l_xZtt5WqT5mzBS81Wa2JJCeOGb0ZswigaADXsEcceKEvDt16iyeHkzeDnjLUpnlPtYdcsMnpQtskfA0zvyK_GK4FzaZ9FeyB4nsOccmkeogoc07oBGNxwSq-CaaCFm9O6ECJ4bKZMPxkvhOrcxagAB9wzCz5jucLGHKIGHyWZMkWqwHZqoTetg1l_dXsxN3yTWU63akRasBYH8ghtw7WugOrfOAuelSthp10y2W9VDaOQ¢\x01²\x05tbMyw1NzcsMTc1MV0sWzEsMjg5LDIyNzRdXSxbWzIsMTA0LDIwOTAuMTk5OTk5ODA5MjY1XSxbMiw1NiwyMTk0LjVdLFsyLDgwLDIyNjEuMTk5OTk5ODA5MjY1XSxbMiwzODIsMjQ2Mi40MDAwMDAwOTUzNjc0XSxbMiwxMzYsMjg1Ni41XSxbMiw5Niw0MzA5LjkwMDAwMDA5NTM2N11dLFtudWxsLG51bGwsbnVsbCxbNTUyLDAuMTA3NDI3NTMzMTIyMDc2NTEsMC4wMDAxMDk0NjU4NTg4MDM3NjExMSwyMF0sWzQxNjEsMC4wOTAzNjI4OTIyNzQ2NDM0MiwwLjAwMDY5NDA4MzcwMTk4MTcyOTEsNl0sNDksMCwwXSxbInd3dy50dmluZy5jb20iLCJzLmdvLW1wdWxzZS5uZXQiLCJvNDUwODIzODI1NTc1MTE2OC5pbmdlc3QudXMuc2VudHJ5LmlvIiwiY2xpZW50LXNkay5oYWNrbGUuaW8iLCJldmVudC5oYWNrbGUuaW8iLCJ3d3cuZ29vZ2xlLmNvbSIsInNyLWNsaWVudC1jZmcuYW1wbGl0dWRlLmNvbSIsImMuZ28tbXB1bHNlLm5ldCIsInd3dy5nc3RhdGljLmNvbSIsImFwaTIuYW1wbGl0dWRlLmNvbSJdLFszLDU1M11d²\x01¤\x1dBDAAYAIAGEcAAUoYIwlDCKAsCLlcgB6AIJtAggoIEEOALSoQRZxSZyAJBDAJCkAJUYhBJESBlKAAIAEgrQBjfABoCBZoQAINGKKCoQGAcMQFGGIBAAIhAhYAT4AFtQiEUjolYQ69EiAXICQeQCCkQgEcQOFRJhQAYJmdAAkAQIIAkTJZocAIAASACBwGMgACCESoELFCFAhQgJCEJcDjQg2VAEAIgABJoEAKEEBgcAQKUIzGcAdAAKgUERAAFUshGKIkkaIoIIAMysQAiWkARQAQATIAFCWGrAFAAhIyZMCxBF4RJQ04JXFwiGMCwmQtCNdSEiwBKgQEDFqNQM8LQEJJPIQWiAIrBtKOAARAygLWQEMCKGRoCIUEBIxsLkRgEgQByFBhFGEzQYqAGGGDbQMQYBAABQAGADIUAMIhiMACwgATNMoRmiCEBVQXEEAIEEwCIrgQTgagwBnpCIpAGybFIDAEAkAgAJLRmRJUigI0m8gBAREUUJgQ0iSJBSEKMB5QQwBAAFQIoBtBAHKJNUAI4EIQrCMhkECAZICqQIMBAAQhQBBCAgQkMEKBQJJDUCqRgUTAAAgAhWgEc0BBUQSigKFEQIAm4BhEByMAISEC4MBkiCOQQah0CIKEAIBAwEAThIOJ+UmRlETAQQkCCCSUQsAQEQRQhEAgcBYGHWAFFIoAMGEhAhAC1EkFBgHgDpgCimRQIA0BAMGQMASOIChiKBDGoCEARiCq7oAIAHYBAIZoAeQQAPAggoAAxACpEggIExgAKCBEKQohCACoF0HSAAJQgAYqbQACYFQhRwSAQLgEqCBACEuDIiICMYAhIBEAJMJgAhTUoaRUBKESfkQE4AUAA5NgKOBCAoRoGCABBkiMACQgAUJxEghoAoFHcApoI8gIARA4rYBmEBhgNBCCD6ZIGGzghAD1AIxEBJCaCgMRCXQj0CAcBtIIAAQJKEAEgMQyauIcyErLIAihUCCECAAikBECQFoADBZScQJ8ABgoBLAGFFpCEIDICggAAQgigCCAlARCmVJDwh64gCQGIrKZQCBhaAlMkoGZAoEQCFRIUgAKAWiQAqARARQFUQgkCZsBI6BNAmoAAg4QCBAOEIJwAGKcKmEADMEQggA4QIoIEgKlSUrC2sDBSQRYr4ACwhECMCwFy2AoIIAWCwSwEiAcRFAIELvJTUSABaIt4NQBwvRFAmUoGRQJLGhRCgAAICVBMgkWEwLwKBCsIOSBAxSIDATIMgyAGMAgoAILBJUyEJBaQDAACKBCxAEwgXAgwaYckAADOGBHyVRUqIwIADYImLMT4kuwSgzAueAmsoaAGumwCDMCLoESaCRgkQEFBGDgBQKc0iCwrCkNEDgAUNAAhIQDsGdDKgSEOUIA3CwWAVmNR2UJD4DozBzIsKQ8eYABB1KANIgSBogAqAhOlEKqvyISQgEAACSCBQWJQBKKEAACmICCiClYAQzhQZBFAA0sNogIBQDFUEQhBEkGBAEQAYCBogEAjWCRIkQEAEAyCSoSCRBwgwAEvaYRaBBkxlhhgYQJDIoAAUkCBhIOQggIoBRDgHBiAQAQGICgQNIiTAGwQARASNSFSkREjJVdKYAopBiABFoAzQImlDKErrACqTIIA0AgSEGiRgEAAgMlDSIiECGYEMWQA5yBBNkBgaQGwOIhJIKUIgACRChC9goAAIBAIAzDTSkgAgQqgpANAA0QIACOhDIZHIUAAQYIEgaAGohFEpAgBqElAECAWDABKSUAQYgJERYIkLIiABBBxAA1EKCYKATxECAAAEgCMgJIDjBAJcBAuUO4iOKoAVgIFAwcLismEEgKAJAlwAw0IA9wEFACQAgNAkYI0BIAggFxAGCJBCRUAVmCJIB4EBaAAOAApBUAZImAEgjkoaQBFHGAEJMjCLAEhFcTKEAgCsAtAYwpICEECACOJBAgADgJIwCEAA4AyGUYCApPJADikhBgwLzAgAQjQiTCQEMgAiqBk1REBAhprWAcIJCAEAQEQghJIIBJrAtCTOGCQkCvQEAUqmnBnBRLAoUAwDQgMICoEQILBhsAAiIABAYBRIhMKQQMgQnoAAAxEhpBJ6BGqJkaAZAO4LsDABR1sgEjAAZgwzp8CBAEhAASQFmQwwFdAJIiAAyjBTvQCBSYBHzQBgDuDQoAYCONIAkijAAQQgImAABEE4MARqmAUhJIAMCwQCoGQzImyN4ICQQIsb3gJAJQcEiA6i2jhITATC3BBBAmMAKCRBkAcAgBCDIOAISsoJLmgCBwIOWRmUBQmgEBLMEQTBiUInCKAMJAhQQBIFRiIgSAVxZCMARQ4AAXAUWChMBCWgAqCCkBABKGAaBZCASYCCFE1CECAdQEcIOkUCCgQMAQYCRkPRBIgIIoRUWUiAMMFMIAEjJABEIxg6JECgIACEoQIBAQMAABkRHDgUIABgAQAEELsCyIUwEQIEtUokAkShRQpFIqbMICAAIAgmckmAEMMVIQQgAEqELmFGCdgEAAVGIDGAOEag0ECBIIQQQyAggYkAaQl4VEDClAVykgSJB2CQAAUJoBkgihEERCAiFnQDIfQIPQgABMIEAAgB8FIIUthUgGxYBAEEQBKSNqSpIQihcbcEBQTIUMHCgYgFswJWhFcjgoABAgZpQgwohWAIxAAGAw0AABA4LAJpLlEIRxAiAIRTWUE0GPlSEQIAcGrwAOxEAJEABCBDAzsIyAhAGIIaQA0gGDMAkQIkBQQAgcCIDZsBQiKKhIQDKEQhihHmQLvNFES4yCFLpAhwjAOQIAQVkARECAAI0IQAGOJGFBAQQ1ESh4QQAGBCCIVkuWBkpqCAFCRaxIDDQlFA4j3DjAIAYwMAOsNAMQpJAEGmNPShASgAEEBAAAMoCupoQGAEocAMABGwjiwCCABDIUAAAgCE2AQBQnBAJABAAEFJDwANDREFkOEMBmRgADCSKBlIgKlSCmSMOBzCQIG6alBQBAFEBRAAgBgIEC4ITLJvA+BgjSIZAxIgoAhGEUmUiEJAEAEIRwgm0IIcYBB0AdAiAJMU4CgAqJYAQYoGAKACSH5CMWqoMAnAAgCCEBYHEUJAUAmqBKQViAg4IkTjABECCeLDCmGRsCQgpBEnDoIAjDKEAQEEkBBHKDABQgAIDI4AgCJEBIxYFB4AsJAwAQAJQIARAaSEhKA4swGCtTggCASgKYhMTEAgIIG/8SRigBAjAJEQYgABATBBDJEUAgQpxYwgARVxCBQnTDUEEAUxAJhREcFJTwgsiRDAAAAgH4LIA5bEZQnxgcJQA2AC0LQfhJwZUQAXUTETAIQCgaEDDAixtAABgyCJ3gAAQxEAENA8BAhEAUKDZgM0AWkAnCDZjAAAhNHJsAzqQQ5CACVAkRAoFFQvCSpSYhkAogIIgQXNFCRUICjYGDgLaiDQQGIEmggABMSCBnCgAiiIlmWBAjtJOEIQJUJEEQAAOcpWgpmBKBgsoRGENITWiKCggiCUIFgSIGB4IwAiGKCn0gngRRSAigIRAAAg3RGOMcE4okWEjJAlKiYAAEAPAIQUhKBkABUIgbhDiGCEMAMgAgEBAIAhQA0QzAgEmAgooJkC0iATgsjgfh0HYARBwQiM0AoLBIC0EwWBogFVXKgpEQUE1NAlkBayAICWRwYiBrRAI4JEElLA4wHozVg5AYhEBaAjoKCreDQgBACIAkhEBRACDAeiNAVBUBNtVAjUkOBQijJlPAhaFUADIqAR2ZSQKgD4CIÊ\x01WW1tbNTAwNiwxMjE2XSxbNjQ2MDcsM10sWzM1ODM3LDNdLFs0NTQ2NCwzXSxbMzE2MTcsNF0sWzM3MTc4LDRdXV0à\x01\xa0\x9c\x01è\x01°ê\x01';B=F.post(P,headers=C,data=Q,impersonate=E);print(M.format(B.status_code,B.url));A.JsonFile_Save(A.TV_SESSION_TEXT1,json.loads(B.text))
		except Exception as D:print(D);A.Init_TV_Total();return _E
		"\n\t\ttry:\n\t\t\tif login_type == '0':\n\t\t\t\t# https://www.tving.com/account/login/cj-one?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding&deviceId=WEB&deviceModel=Windows%2Cnone%2CChrome&deviceName=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F143.0.0.0+Safari%2F537.36&loginPocType=WEB\n\t\t\t\tfirst_url = 'https://www.tving.com/account/login/cj-one'\n\t\t\t# tving\t\t\t\t\n\t\t\telse:\n\t\t\t\t# https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding&deviceId=WEB&deviceModel=Windows%2Cnone%2CChrome&deviceName=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F143.0.0.0+Safari%2F537.36&loginPocType=WEB\n\t\t\t\tfirst_url = 'https://www.tving.com/account/login/tving'\n\n\t\t\tparams = {\n\t\t\t\t\t\t\t'returnUrl'    : 'https://www.tving.com/onboarding',\n\t\t\t\t\t\t\t'deviceId'     : 'WEB',\n\t\t\t\t\t\t\t'deviceModel'  : 'Windows,none,Chrome',\n\t\t\t\t\t\t\t'deviceName'   : self.USER_AGENT,\n\t\t\t\t\t\t\t'loginPocType' : 'WEB',\n\t\t\t}\t\t\n\n\t\t\tpayload = [{\n\t\t\t\t\t\t'captchaCheckboxToken' : None,\n\t\t\t\t\t\t'captchaScoreToken'    : None,\n\t\t\t\t\t\t'deviceId'             : 'ac6a5c9b-700d-4cf5-9282-18587d194f93',\n\t\t\t\t\t\t'deviceModel'          : '',\n\t\t\t\t\t\t'deviceName'           : None,\n\t\t\t\t\t\t'id'                   : 'dfdafdfafd', #user_id,\n\t\t\t\t\t\t'password'             : 'sdddfdfa', #user_pw,\n\t\t\t\t\t\t'isAutoLogin'          : False,\n\t\t\t\t\t\t'loginPocType'         : 'WEB',\n\t\t\t\t\t\t'networkCode'\t\t   : 'CSND0900',\n\t\t\t\t\t\t'osCode'\t\t       : 'CSOD0900',\n\t\t\t\t\t\t'pocType'\t\t\t   : 'PCWEB',\n\t\t\t\t\t\t'returnUrl'            : 'https://www.tving.com/onboarding',\n\t\t\t\t\t\t'screenCode'\t\t   : 'CSSD0100',\n\t\t\t\t\t\t'teleCode'\t\t\t   : 'CSCD0900',\n\t\t\t}]\n\n\t\t\theaders = {\n\t\t\t\t\t\t'user-agent'           : self.USER_AGENT,\n\t\t\t}\n\n\t\t\tresponse = SESSION.post(first_url, params=params, headers=headers, json=payload, impersonate=impersonate )\n\t\t\tprint( '{} - {}'.format( response.status_code, response.url ) )\n\n\t\t\tself.JsonFile_Save( self.TV_SESSION_TEXT1, response.text )\n\t\t\t#self.JsonFile_Save( self.TV_SESSION_COOKIES2, json.loads(response.text) )\n\n\t\texcept Exception as exception:\n\t\t\tprint(exception)\n\t\t\tself.Init_TV_Total()\n\t\t\treturn False\n\t\t";return _I
	def GetDeviceList(B):C=[];A=_N;A=str(B.GetNoCache(timetype=1));return A;"\n\t\ttry:\n\t\t\turl_path   = '/v1/user/device/list'\n\t\t\treq_url = self.API_DOMAIN + url_path\n\n\t\t\t#url_params = { 'apiKey'      : '4263d7d76161f4a19a9efe9ca7903ec4'\n\t\t\t#\t\t\t , 'model'       : 'PC'\n\t\t\t#}\n\t\t\turl_params = self.GetDefaultParams()\n\t\t\tcookies = self.makeDefaultCookies()\n\n\t\t\tresponse = self.callRequestCookies( 'Get', req_url, payload=None, params=url_params, headers=None, cookies=cookies )\n\t\t\treq_json = json.loads( response.text )\n\n\t\t\tsection_list = req_json['body']\n\n\t\t\t#print( req_json )\n\t\t\tfor i_section in section_list:\n\t\t\t\t#if i_section['model'].lower() == 'pc' or i_section['model'].lower() == 'pc-chrome' or i_section['model'].lower() == 'pc-edge':\n\t\t\t\tif i_section['model'].lower().startswith('pc') :\n\t\t\t\t\tdeviceid = i_section['uuid']\n\t\t\t\t\tbreak\n\n\t\t\tif deviceid == '-':\n\t\t\t\tdeviceid = str(self.GetNoCache(timetype=1))\n\t\t\t\t#for i_section in section_list:\n\t\t\t\t#\tdeviceid = i_section['uuid']\n\t\t\t\t#\tbreak\n\n\t\texcept Exception as exception:\n\t\t\tprint(exception)\n\t\t\n\t\treturn deviceid\n\t\t"
	def Get_Now_Datetime(A):return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
	def get_renewal_url(A,mediacode,quality_int=1080,proxyPort=9999):
		C=mediacode;E=A.TV[_U][_h].split(_N)[0];F=A.TV[_U][_h]
		for(G,H)in QUALITY_LIST.items():
			if H==quality_int:I=G
		D=A.GetDefaultParams();J={_x:C,_w:E,_y:F,_z:_AX,_AF:I,_A0:str(A.GetNoCache(1)),_A1:_A2,_AT:A.MODEL,_AU:_AY,_AV:'aac',_AW:_AZ,_Au:'hls'};D.update(J);B={'addon':'tvingm',_B7:C,'get_url':'https://api.tving.com/v3/media/stream/info','headers':{_AQ:A.USER_AGENT,_Av:A.TV_TOKEN[_j]},'params':D,_U:A.makeDefaultCookies()};B=json.dumps(B,separators=(_t,':'));B=base64.standard_b64encode(B.encode()).decode(_H);K='http://127.0.0.1:{}/live.mpd?proxy-mini={}'.format(proxyPort,B);return K
	def GetBroadURL(B,mediacode,sel_quality,stype,pvrmode=_N,optUHD=_E):
		Q='subtitles';P='watermarkKey';K='qt_stream';G=mediacode;A={_S:'',_Aw:_E,_i:'',_A3:'',_A4:'',_A5:'',_Ax:'',_Aa:'',P:'',K:''};L=B.TV[_U][_h].split(_N)[0];M=B.TV[_U][_h];"\n\t\ttry:\n\t\t\ttimecd = str(self.GetNoCache(1))\n\n\t\t\tif stype != 'tvingtv': # and ( pvrmode == '-' or stype != 'onair' ) : #and 1==2:\n\n\t\t\t\turl_path   = '/v2/media/stream/info'\n\n\t\t\t\tdef_params = self.GetDefaultParams( )\n\t\t\t\theaders    = {\n\t\t\t\t\t\t\t\t#'access-token' : self.TV['cookies']['accessToken']\n\t\t\t\t\t\t\t\t'access-token' : self.TV_TOKEN['accessToken']\n\t\t\t\t}\n\n\t\t\t\turl_params = {\n\t\t\t\t\t\t\t'mediaCode'   : mediacode,\n\t\t\t\t\t\t\t'info'        : 'Y',\n\t\t\t\t\t\t\t'callingFrom' : 'HTML5',\n\t\t\t\t\t\t\t'deviceId'    : deviceid, # 1990423667\n\t\t\t\t\t\t\t'uuid'        : uuid,     # 1990423667-d7b03414\n\t\t\t\t\t\t\t'deviceInfo'  : 'PC_Chrome',\n\t\t\t\t\t\t\t'noCache'     : timecd,\n\t\t\t\t\t\t\t'model'       : self.MODEL,\n\t\t\t\t\t\t\t'videoTypes'  : 'h264|av1',\n\t\t\t\t\t\t\t'audioTypes'  : 'aac',\n\t\t\t\t\t\t\t'authType'    : 'header',\n\t\t\t\t\t\t\t'xr'          : '102',\n\t\t\t\t}\n\t\t\t\tdef_params.update(url_params)\n\n\t\t\t\turl = self.API_DOMAIN + url_path\n\n\t\t\t\tcookies = self.makeDefaultCookies()\n\t\t\t\tresponse = self.callRequestCookies( 'Get', url, payload=None, params=def_params, headers=headers, cookies=cookies )\n\t\t\t\tif response.status_code != 200 :\n\t\t\t\t\turl_info['error_msg'] = 'First Step - {} error'.format( response.status_code )\n\t\t\t\t\treturn url_info\n\n\t\t\t\treq_json = json.loads( response.text )\n\t\t\t\t#self.JsonFile_Save( self.TV_SESSION_COOKIES1, req_json )\n\n\t\t\t\t# 오류시 (2021.12.18)\n\t\t\t\tif req_json['body']['result']['code'] == '060': # 기기등록후 사용~~\n\t\t\t\t\tfor key, element in QUALITY_LIST.items():\n\t\t\t\t\t\tif element == sel_quality:\n\t\t\t\t\t\t\tqt_stream = key\n\t\t\t\t\t\n\t\t\t\telif req_json['body']['result']['code'] != '000':\n\t\t\t\t\turl_info['error_msg'] = req_json['body']['result']['message']\n\t\t\t\t\treturn url_info\n\n\t\t\t\telse:\t\t\t\t\n\t\t\t\t\tif not ('stream' in req_json['body']): return url_info\n\n\t\t\t\t\tqt_list = []\n\t\t\t\t\t#print( req_json['body']['stream']['quality'] )\n\t\t\t\t\tfor key, element in QUALITY_LIST.items():\n\t\t\t\t\t\tfor i_section in req_json['body']['stream']['quality']:\n\t\t\t\t\t\t\tif i_section['active'] == 'Y' and i_section['code'] == key:\n\t\t\t\t\t\t\t\tqt_list.append( { QUALITY_LIST.get(i_section['code']) : i_section['code'] } )\n\n\t\t\t\t\t#print(sel_quality)\n\t\t\t\t\t#print(qt_list)\n\t\t\t\t\tqt_stream = self.CheckQuality(sel_quality, qt_list)\n\n\t\t\t\t\ttry:\n\t\t\t\t\t\tif optUHD == True  and  qt_stream == 'stream50' and 'stream_support_info' in req_json['body']['content']['info']:\n\t\t\t\t\t\t\tif req_json['body']['content']['info']['stream_support_info'] != None:\n\t\t\t\t\t\t\t\tif 'stream70' in req_json['body']['content']['info']['stream_support_info']: # string\n\t\t\t\t\t\t\t\t\tqt_stream = 'stream70'\n\t\t\t\t\t\t\t\t\t#VOD_UHD   = True\n\t\t\t\t\t\t\t\t\turl_info['qt_stream'] = 'stream70'\n\t\t\t\t\texcept:\n\t\t\t\t\t\tpass\n\n\t\t\t\t\ttry:\n\t\t\t\t\t\t# 2023.02.03\n\t\t\t\t\t\tif optUHD == True  and  qt_stream == 'stream50' and 'stream' in req_json['body']['content']['info']:\n\t\t\t\t\t\t\tif req_json['body']['content']['info']['stream'] != None:\n\t\t\t\t\t\t\t\tfor i_section in req_json['body']['content']['info']['stream']:\n\t\t\t\t\t\t\t\t\tif i_section['code'] == 'stream70':\n\t\t\t\t\t\t\t\t\t\tqt_stream = 'stream70'\n\t\t\t\t\t\t\t\t\t\t#VOD_UHD   = True\n\t\t\t\t\t\t\t\t\t\tbreak\n\t\t\t\t\texcept:\n\t\t\t\t\t\tpass\n\n\n\t\t\telse:\n\t\t\t\tqt_stream = 'stream40'\n\n\n\t\texcept Exception as exception:\n\t\t\tprint(exception)\n\t\t\turl_info['error_msg'] = 'First Step - except error'\n\t\t\treturn url_info\n\t\t"
		for(R,S)in QUALITY_LIST.items():
			if S==sel_quality:E=R
		A[K]=E;print(E)
		try:
			H=str(B.GetNoCache(1));T=_B8;U={_Av:B.TV_TOKEN[_j]}
			if A[K]=='stream70':I=B.GetDefaultParams(uhd=_I);N={_x:G,_w:L,_y:M,_z:'PC_Chrome WebView',_AF:E,_A0:H,_A1:_A2,_AT:'android_chrome webview_96.0.4664.104',_AU:_AY,_AV:'aac',_AW:_AZ,_Au:'hls'}
			else:I=B.GetDefaultParams();N={_x:G,_w:L,_y:M,_z:_AX,_AF:E,_A0:H,_A1:_A2,_AT:B.MODEL,_AU:_AY,_AV:'aac',_AW:_AZ,_Au:'hls'}
			I.update(N);V=B.API_DOMAIN+T;W=B.makeDefaultCookies();X=B.callRequestCookies('Post',V,payload=_A,params=I,headers=U,cookies=W,redirects=_I);J=json.loads(X.text)
			if J[_G][_T][_B]!=_AG:A[_i]=J[_G][_T][_Ay];return A
			C=J[_G][_Ab]
			if C['drm_yn']==_X:
				D=C[_A6]['drm']['widevine']
				for F in C[_A6]['drm']['license'][_B9]:
					if F['drm_type']=='Widevine':A[_A3]=F[_A3];A[_A4]=F[_A4];A[_A5]=F[_A5];break
			else:D=C[_A6]['non_drm']
		except Exception as Y:print(Y);A[_i]=_BA;return A
		Z=H;D=D.split('|')[1];D,a,b=B.Decrypt_Url(D,G,Z);A[_S]=D;A[_Aa]=a;A[P]=b
		if Q in C:
			for c in C.get(Q):
				if c.get(_B)in['KO','KO_CC']:A[_Aw]=_I;break
		d=urllib.parse.urlparse(A[_S]);O=d.path.strip('/').split('/');A[_Ax]=O[len(O)-1];return A
	def TestUrl(A,url):C={};B=A.callRequestCookies(_M,url,payload=_A,params=_A,headers=_A,cookies=_A,redirects=_I);A.TextFile_Save(A.TV_SESSION_TEXT1,B.text)
	def Tving_Parse_mpd(F,stream_url,watermarkKey=_A,watermark=_A):
		N='bandwidth';M='Representation';H=watermarkKey;G=stream_url
		if H not in['',_A]:O={'X-Tving-Param1':H,'X-Tving-Param2':watermark};I=requests.get(url=G,headers=O,allow_redirects=_E)
		else:I=requests.get(url=G)
		J=I.content.decode(_H);D=0;P=ET.ElementTree(ET.fromstring(J));E=P.getroot();B=re.match('\\{.*\\}',E.tag)[0];Q=dict([A for(B,A)in ET.iterparse(io.StringIO(J),events=['start-ns'])])
		for(K,R)in Q.items():
			if K!='ns2':ET.register_namespace(K,R)
		S=E.find(B+'Period')
		for A in S.findall(B+'AdaptationSet'):
			if A.attrib.get('mimeType')=='video/mp4'or A.attrib.get('contentType')=='video':
				for C in A.findall(B+M):
					L=int(C.attrib.get(N))
					if D<L:D=L
				for C in A.findall(B+M):
					if D>int(C.attrib.get(N)):A.remove(C)
			else:continue
		T=ET.tostring(E).decode(_H);U='<?xml version="1.0" encoding="UTF-8"?>\n';F.TextFile_Save(F.TV_STREAM_FILENAME,U+T);return _I
	def Tving_Parse_m3u8(C,stream_url):
		H='BANDWIDTH';B='#EXT-X-STREAM-INF'
		try:
			J=requests.get(url=stream_url,headers=_A,stream=_I);D=J.content.decode(_H)
			if'#EXTM3U'not in D:return _E
			if B not in D:return _E
			F=0
			for A in D.splitlines():
				if A.startswith(B):
					E=C.MediaLine_Parse(A,B)
					if F<int(E.get(H)):F=int(E.get(H))
			I=[];G=_E
			for A in D.splitlines():
				if G==_I:G=_E;continue
				if A.startswith(B):
					E=C.MediaLine_Parse(A,B)
					if F!=int(E.get(H)):G=_I;continue
				I.append(A)
		except Exception as K:print(K);return _E
		L='\n'.join(I);C.TextFile_Save(C.TV_STREAM_FILENAME,L);return _I
	def MediaLine_Parse(E,line,prefix):
		A={}
		for B in ATTRIBUTE_PATTERN.split(line.replace(prefix+':',''))[1::2]:C,D=B.split('=',1);A[C.upper()]=D.replace('"','').strip()
		return A
	def CheckQuality(C,sel_qt,qt_list):
		for A in qt_list:
			if sel_qt>=list(A)[0]:return A.get(list(A)[0])
			B=A.get(list(A)[0])
		return B
	def makeOocUrl(D,ooc_params):
		A=''
		for(B,C)in ooc_params.items():A+='%s=%s^'%(B,C)
		return A
	def GetLiveChannelList(D,stype,page_int):
		B='schedule';H=[];I=_E
		try:
			c='/v2/media/lives'
			if stype=='onair':Q='CPCS0100,CPCS0400'
			else:Q='CPCS0300'
			R=D.GetDefaultParams();d={_Az:'main',_A7:str(page_int),_k:str(D.LIVE_LIMIT),_u:'rating',_Ac:_O,_Ad:_O,_Ae:_O,_Af:_O,'channelType':Q};R.update(d);e=D.API_DOMAIN+c;f=D.callRequestCookies(_M,e,payload=_A,params=R,headers=_A,cookies=_A);J=json.loads(f.text)
			if not _T in J[_G]:return H,I
			g=J[_G][_T]
			for A in g:
				S=F=K='';L=M='';h=A['live_code'];S=A[B][_A8][_W][_C]
				if A[B][_Y]!=_A:F=A[B][_D][_W][_C];F=F+', '+str(A[B][_Y][_Ag])+'회';K=A[B][_Y][_Z][_C]
				else:F=A[B][_D][_W][_C];K=A[B][_D][_Z][_C]
				try:
					E='';T='';U='';V='';i='';W=''
					for C in A[B][_D][_l]:
						if C[_B]==_Ah:T=D.IMG_DOMAIN+C[_F]
						elif C[_B]==_Ai:U=D.IMG_DOMAIN+C[_F]
						elif C[_B]==_Aj:V=D.IMG_DOMAIN+C[_F]
						elif C[_B]==_Ak:i=D.IMG_DOMAIN+C[_F]
						elif C[_B]==_Al:W=D.IMG_DOMAIN+C[_F]
						elif C[_B]=='CAIP0500':E=D.IMG_DOMAIN+C[_F]
						elif C[_B]=='CAIP0800':E=D.IMG_DOMAIN+C[_F]
					if E=='':
						for C in A[B][_A8][_l]:
							if C[_B]=='CAIC0400':E=D.IMG_DOMAIN+C[_F]
							elif C[_B]=='CAIC1400':E=D.IMG_DOMAIN+C[_F]
							elif C[_B]=='CAIC1900':E=D.IMG_DOMAIN+C[_F]
				except:_A
				try:
					X=[];Y=[];N=[];Z='';a='';b=''
					for O in A.get(B).get(_D).get(_a):
						if O!=''and O!='없음':X.append(O)
					for G in A.get(B).get(_D).get(_P):
						if G!=''and G!=_N and G!='없음':Y.append(G)
					if A.get(B).get(_D).get(_e).get(_C)!='':N.append(A[B][_D][_e][_C])
					if A.get(B).get(_D).get(_f).get(_C)!='':N.append(A[B][_D][_f][_C])
					if A.get(B).get(_D).get(_v):Z=A[B][_D][_v]
					if A.get(B).get(_D).get(_A9):a=MPAA_LIST.get(A[B][_D][_A9])
					if _m in A.get(B).get(_D):P=A.get(B).get(_D).get(_m);b=_n%(P[:4],P[4:6],P[6:])
				except:_A
				L=str(A[B]['broadcast_start_time'])[8:12];M=str(A[B]['broadcast_end_time'])[8:12];j={_A8:S,_J:F,_B7:h,_L:{_V:T,_b:E,_r:U,_AI:V,_c:W},_Z:K,'channelepg':' [%s:%s ~ %s:%s]'%(L[0:2],L[2:],M[0:2],M[2:]),_o:X,_P:Y,_AH:N,_p:Z,_q:a,_AA:b};H.append(j)
			if J[_G][_A_]==_X:I=_I
		except Exception as k:print(k)
		return H,I
	def GetProgramList(C,genre,orderby,page_int,genreCode=_O):
		N=genreCode;M=genre;F=[];G=_E
		try:
			Y='/v2/media/episodes';O=C.GetDefaultParams();H={_Az:'main',_k:str(C.VOD_LIMIT),_u:orderby,_Ac:_O,_Ad:_O,_Ae:_O,_Af:_O,'lastFrequency':'y','personal':'N',_A7:str(page_int)}
			if M not in[_O,_BB]:H[_BC]=M
			if N!=_O:H[_BD]=N
			O.update(H);Z=C.API_DOMAIN+Y;a=C.callRequestCookies(_M,Z,payload=_A,params=O,headers=_A,cookies=_A);I=json.loads(a.text)
			if not _T in I[_G]:return F,G
			b=I[_G][_T]
			for A in b:
				c=A[_D][_B];d=A[_D][_W][_C];e=MPAA_LIST.get(A[_D].get(_A9));P='';J='';Q='';R='';S=''
				for B in A[_D][_l]:
					if B[_B]==_Ah:P=C.IMG_DOMAIN+B[_F]
					elif B[_B]==_Al:J=C.IMG_DOMAIN+B[_F]
					elif B[_B]==_Ai:Q=C.IMG_DOMAIN+B[_F]
					elif B[_B]==_Aj:R=C.IMG_DOMAIN+B[_F]
					elif B[_B]==_Ak:S=C.IMG_DOMAIN+B[_F]
				f=A[_D][_Z][_C]
				try:T=A[_A8][_W][_C]
				except:T=''
				try:
					U=[];V=[];K=[];W='';X=''
					for D in A.get(_D).get(_a):
						if D!=''and D!=_N and D!='없음':U.append(D)
					for E in A.get(_D).get(_P):
						if E!=''and E!=_N and E!='없음':V.append(E)
					if A.get(_D).get(_e).get(_C)!='':K.append(A[_D][_e][_C])
					if A.get(_D).get(_f).get(_C)!='':K.append(A[_D][_f][_C])
					if A.get(_D).get(_v):W=A[_D][_v]
					if _m in A.get(_D):L=A.get(_D).get(_m);X=_n%(L[:4],L[4:6],L[6:])
				except:_A
				g={_D:c,_J:d,_L:{_V:P,_b:J,_r:Q,_AI:R,_Am:S,_c:J},_Z:f,_A8:T,_o:U,_P:V,_AH:K,_p:W,_AA:X,_q:e};F.append(g)
			if I[_G][_A_]==_X:G=_I
		except Exception as h:print(h)
		return F,G
	def GetEpisodeList(B,program_code,page_int,orderby=_AB):
		M=orderby;F=page_int;G=[];H=_E
		try:
			a='/v2/media/frequency/program/'+program_code;N=B.GetDefaultParams();b={_u:'newUpdate',_Az:'main',_k:'20',_u:'new',_Ac:_O,_Ad:_O,_Ae:_O,_Af:_O};N.update(b);c=B.API_DOMAIN+a;d=B.callRequestCookies(_M,c,payload=_A,params=N,headers=_A,cookies=_A);I=json.loads(d.text)
			if not _T in I[_G]:return G,H
			D=I[_G][_T];J=int(I[_G]['total_count']);O=int(J//(B.EPISODE_LIMIT+1))+1
			if M==_AB:K=J-1-(F-1)*B.EPISODE_LIMIT
			else:K=(F-1)*B.EPISODE_LIMIT
			for P in range(B.EPISODE_LIMIT):
				if M==_AB:
					A=K-P
					if A<0:break
				else:
					A=K+P
					if A>=J:break
				e=D[A][_Y][_B];f=D[A]['vod_name'][_C];E=''
				try:L=str(D[A][_Y]['broadcast_date']);E=_n%(L[:4],L[4:6],L[6:])
				except:_A
				try:
					if D[A][_Y]['pip_cliptype']=='C012':E+=' - Quick VOD'
				except:_A
				g=D[A][_Y][_Z][_C];Q='';R='';S='';T='';U='';V=''
				for C in D[A][_D][_l]:
					if C[_B]==_Ah:Q=B.IMG_DOMAIN+C[_F]
					elif C[_B]==_Ai:S=B.IMG_DOMAIN+C[_F]
					elif C[_B]==_Aj:T=B.IMG_DOMAIN+C[_F]
					elif C[_B]==_Ak:U=B.IMG_DOMAIN+C[_F]
					elif C[_B]==_Al:V=B.IMG_DOMAIN+C[_F]
				for C in D[A][_Y][_l]:
					if C[_B]=='CAIE0400':R=B.IMG_DOMAIN+C[_F]
				try:
					W=X=Y='';Z=0;W=D[A][_D][_W][_C];X=E;Y=D[A][_A8][_W][_C]
					if _Ag in D[A][_Y]:Z=D[A][_Y][_Ag]
				except:_A
				h={_Y:e,_J:f,'subtitle':E,_L:{_V:Q,_b:R,_r:S,_AI:T,_Am:U,_c:V},_Z:g,_BE:W,_B0:X,_An:Y,_Ag:Z};G.append(h)
			if O>F:H=_I
		except Exception as i:print(i)
		return G,H,O
	def GetMovieList(B,genre,orderby,page_int):
		N='diversityYn';F=genre;G=[];H=_E
		try:
			a='/v2/media/movies';O=B.GetDefaultParams();I={_k:str(B.MOVIE_LIMIT),_u:orderby,_Ad:_O,_Ac:_O,_Ae:_O,_Af:_O,'personal':'N',N:'N'if F!=N else _X,_A7:str(page_int)}
			if F not in[_O,_BB,N]:I[_BC]=F
			I['productPackageCode']=_t.join(B.MOVIE_LITE);O.update(I);b=B.API_DOMAIN+a;c=B.callRequestCookies(_M,b,payload=_A,params=O,headers=_A,cookies=_A);J=json.loads(c.text)
			if not _T in J[_G]:return G,H
			d=J[_G][_T]
			for A in d:
				if _AJ in A.get(_K):D=str(A.get(_K).get(_AJ))[:4]
				else:D=_A
				e=A[_K][_B];P=A[_K][_W][_C].strip()
				if D not in[_A,_Q,'']:P+=' (%s)'%D
				Q='';K='';R=''
				for C in A[_K][_l]:
					if C[_B]=='CAIM2100':Q=B.IMG_DOMAIN+C[_F]
					elif C[_B]=='CAIM0400':K=B.IMG_DOMAIN+C[_F]
					elif C[_B]=='CAIM1800':R=B.IMG_DOMAIN+C[_F]
				f=A[_K]['story'][_C]
				try:
					g=A[_K][_W][_C].strip();h=MPAA_LIST.get(A.get(_A9));S=[];T=[];L=[];U=0;V='';W=''
					for X in A.get(_K).get(_a):
						if X!='':S.append(X)
					for Y in A.get(_K).get(_P):
						if Y!='':T.append(Y)
					if A.get(_K).get(_e).get(_C)!='':L.append(A[_K][_e][_C])
					if A.get(_K).get(_f).get(_C)!='':L.append(A[_K][_f][_C])
					if _s in A.get(_K):U=A.get(_K).get(_s)
					if _AJ in A.get(_K):
						E=str(A.get(_K).get(_AJ))
						if E!=_Q:V=_n%(E[:4],E[4:6],E[6:])
					if _B1 in A.get(_K):W=A.get(_K).get(_B1)
				except:_A
				M={'moviecode':e,_J:P,_L:{_V:Q,_b:K,_r:R,_c:K},_Z:f,_BE:g,_p:D,_o:S,_P:T,_AH:L,_s:U,_AA:V,_An:W,_q:h};Z=_E
				for i in A['billing_package_id']:
					if i in B.MOVIE_LITE:Z=_I;break
				if Z==_E:M[_J]=M[_J]+' [개별구매]'
				G.append(M)
			if J[_G][_A_]==_X:H=_I
		except Exception as j:print(j)
		return G,H
	def Gn2_Program_List(B,genre,orderby,page_int):
		C=[];D=_E
		try:
			F=_BF+'/bff/web/v3/content/vod';G={_A7:str(page_int),_k:str(B.PAGE_SIZE),_u:orderby,_BD:genre,_AS:'CSSD0100',_AR:'CSOD0900'};H=B.callRequestCookies(_M,F,payload=_A,params=G,headers=_A,cookies=_A);E=json.loads(H.text);I=E[_R][_Ao]
			for A in I:J={_B:A[_B],_J:A[_J],_L:{_V:A[_AK]}};C.append(J)
			if _B2 in E[_R]:D=_I
		except Exception as K:print(K)
		return C,D
	def GetSearchList(B,search_key,page_int,stype):
		i='grade_nm';h='runtime_sec';g='targetage';f='web_url';e='mast_nm';d='mast_cd';c='count';b='dataList';Z=page_int;Y=search_key;X='vodMVRsb';W='programRsb';V='NO';R='ALL';N=stype;E='cate_nm';F=[];O=_E
		try:
			j='/search/getSearch.jsp';r=B.GetDefaultParams();k={'kwd':Y,'category':'PROGRAM'if N==_AL else'VODMV','pageNum':str(Z),'notFoundText':Y,'userid':'','siteName':'TVING_WEB',_k:str(B.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':R,'runTime':R,'grade':R,_AC:R,'screen':B.SCREENCODE,'os':B.OSCODE,'network':B.NETWORKCODE,'sort1':V,'sort2':V,'sort3':V,'type1':_AB,'type2':_AB,'type3':_AB,'fixedType':_X,'spcMethod':'someword','spcSize':_Q,'schReqCnt':_Q,'vodBCReqCnt':_Q,'programReqCnt':str(B.SEARCH_LIMIT)if N==_AL else _Q,'vodMVReqCnt':str(B.SEARCH_LIMIT)if N==_K else _Q,'aloneReqCnt':_Q,'smrclipReqCnt':_Q,'pickClipReqCnt':_Q,'cSocialClipCnt':_Q,'boardReqCnt':_Q,'talkReqCnt':_Q,'nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'',_As:B.APIKEY,_At:B.NETWORKCODE,'osCode ':B.OSCODE,'teleCode ':B.TELECODE,'screenCode ':B.SCREENCODE};l=B.SEARCH_DOMAIN+j;m=B.callRequestCookies(_M,l,payload=_A,params=k,headers=_A,cookies=_A);D=json.loads(m.text)
			if N==_AL:
				if not W in D:return F,O
				n=D[W][b];a=int(D[W][c])
				for A in n:
					S=A[d];T=A[e];P=B.IMG_DOMAIN+A['web_url4'];G=B.IMG_DOMAIN+A[f]
					try:
						H=[];I=[];J=[];Q=0;K='';L='';M=''
						if A.get(_a)!=''and A.get(_a)!=_N:H=A.get(_a).split(_t)
						if A.get(_P)!=''and A.get(_P)!=_N:I=A.get(_P).split(_t)
						if A.get(E)!=''and A.get(E)!=_N:J=A.get(E).split('/')
						if g in A:K=A.get(g)
						if _m in A:C=A.get(_m);M=_n%(C[:4],C[4:6],C[6:]);L=C[:4]
					except:_A
					U={_D:S,_J:T,_L:{_V:P,_b:G,_c:G},_Z:'',_o:H,_P:I,_AH:J,_s:Q,_q:K,_p:L,_B0:M};F.append(U)
			else:
				if not X in D:return F,O
				o=D[X][b];a=int(D[X][c])
				for A in o:
					S=A[d];T=A[e].strip();P=B.IMG_DOMAIN+A[f];G=P;p=''
					try:
						H=[];I=[];J=[];Q=0;K='';L='';M=''
						if A.get(_a)!=''and A.get(_a)!=_N:H=A.get(_a).split(_t)
						if A.get(_P)!=''and A.get(_P)!=_N:I=A.get(_P).split(_t)
						if A.get(E)!=''and A.get(E)!=_N:J=A.get(E).split('/')
						if A.get(h)!='':Q=A.get(h)
						if i in A:K=A.get(i)
						C=A.get(_m)
						if data_str!='':M=_n%(C[:4],C[4:6],C[6:]);L=C[:4]
					except:_A
					U={_K:S,_J:T,_L:{_V:P,_b:G,_c:G,_r:p},_Z:'',_o:H,_P:I,_AH:J,_s:Q,_q:K,_p:L,_B0:M};F.append(U)
			if a>Z*B.SEARCH_LIMIT:O=_I
		except Exception as q:print(q)
		return F,O
	def Gn2_Search_List(B,search_key,page_int,stype):
		C=stype;D=[];E=_E
		try:
			if C==_AL:F='https://gw.tving.com/bff/search/v2/more/content/series/search';G='AI_SCH_SERIES'
			else:F='https://gw.tving.com/bff/search/v2/more/content/movie/search';G='AI_SCH_MOVIE'
			J={'keyword':search_key,_A7:str(page_int),_k:str(B.PAGE_SIZE),'bandComposeMethod':'MANUAL',_AD:G,_AR:B.OSCODE,_AS:B.SCREENCODE};K=B.callRequestCookies(_M,F,payload=_A,params=J,headers=_A,cookies=_A);H=json.loads(K.text).get(_R).get(_AE)[0]
			for A in H[_Ao]:
				if C==_AL:I={_D:A[_B],_J:A[_J],_L:{_V:A[_AK]}}
				else:I={_K:A[_B],_J:A[_J],_L:{_V:A[_AK]}}
				D.append(I)
			if _B2 in H:E=_I
		except Exception as L:print(L)
		return D,E
	def GetBookmarkInfo(E,videoid,vidtype):
		V='content';S='plot';O=vidtype;N=videoid;D='infoLabels';B='saveinfo';A={'indexinfo':{'ott':'tving','videoid':N,'vidtype':O},B:{_J:'','subtitle':'',_L:{_V:'',_b:'',_r:'',_AI:'',_Am:'',_c:''},D:{'mediatype':O,_J:'',_q:'',S:'',_p:'',_An:'',_s:0,_o:[],_P:[],_AC:[],_AA:'','country':''}}}
		if O=='tvshow':
			P=E.API_DOMAIN+'/v2/media/program/'+N;K=E.GetDefaultParams();Q={_A7:'1',_k:'10',_u:_W};K.update(Q);R=E.callRequestCookies(_M,P,payload=_A,params=K,headers=_A,cookies=_A);L=json.loads(R.text)
			if not _G in L:return{}
			C=L[_G];H=C.get(_W).get(_C).strip();A[B][_J]=H;A[B][D][_J]=H;A[B][D][_q]=MPAA_LIST.get(C.get(_A9));A[B][D][S]=C.get(_Z).get(_C);A[B][D][_p]=C.get(_v);A[B][D][_o]=C.get(_a);A[B][D][_P]=C.get(_P)
			if C.get(_e).get(_C)!='':A[B][D][_AC].append(C.get(_e).get(_C))
			if C.get(_f).get(_C)!='':A[B][D][_AC].append(C.get(_f).get(_C))
			G=str(C.get(_m))
			if G!=_Q:A[B][D][_AA]=_n%(G[:4],G[4:6],G[6:])
			I='';J='';M='';T='';U=''
			for F in C.get(_l):
				if F.get(_B)==_Ah:I=E.IMG_DOMAIN+F.get(_F)
				elif F.get(_B)==_Al:J=E.IMG_DOMAIN+F.get(_F)
				elif F.get(_B)==_Ai:M=E.IMG_DOMAIN+F.get(_F)
				elif F.get(_B)==_Aj:T=E.IMG_DOMAIN+F.get(_F)
				elif F.get(_B)==_Ak:U=E.IMG_DOMAIN+F.get(_F)
			A[B][_L][_V]=I;A[B][_L][_b]=J;A[B][_L][_r]=M;A[B][_L][_AI]=T;A[B][_L][_Am]=U;A[B][_L][_c]=J
		else:
			P=E.API_DOMAIN+'/v2a/media/stream/info';K=E.GetDefaultParams();Q={_A1:_A2,_x:N,'info':_X,'adReq':'adproxy',_AF:'stream40',_w:E.TV[_U][_h].split(_N)[0],_y:E.TV[_U][_h],_z:_AX,_A0:str(E.GetNoCache(1)),'wm':_X};K.update(Q);R=E.callRequestCookies(_M,P,payload=_A,params=K,headers=_A,cookies=_A);L=json.loads(R.text)
			if not V in L[_G]:return{}
			C=L[_G][V]['info'][_K];H=C.get(_W).get(_C).strip();A[B][D][_J]=H;H+=' (%s)'%C.get(_v);A[B][_J]=H;A[B][D][_q]=MPAA_LIST.get(C.get(_A9));A[B][D][S]=C.get('story').get(_C);A[B][D][_p]=C.get(_v);A[B][D][_An]=C.get(_B1);A[B][D][_s]=C.get(_s);A[B][D][_o]=C.get(_a);A[B][D][_P]=C.get(_P)
			if C.get(_e).get(_C)!='':A[B][D][_AC].append(C.get(_e).get(_C))
			if C.get(_f).get(_C)!='':A[B][D][_AC].append(C.get(_f).get(_C))
			G=str(C.get(_AJ))
			if G!=_Q:A[B][D][_AA]=_n%(G[:4],G[4:6],G[6:])
			I='';J='';M=''
			for F in C.get(_l):
				if F.get(_B)=='CAIM2100':I=E.IMG_DOMAIN+F.get(_F)
				elif F.get(_B)=='CAIM0400':J=E.IMG_DOMAIN+F.get(_F)
				elif F.get(_B)=='CAIM1800':M=E.IMG_DOMAIN+F.get(_F)
			A[B][_L][_V]=I;A[B][_L][_b]=I;A[B][_L][_r]=M;A[B][_L][_c]=J
		return A
	def Make_DecryptKey(C,step,mediacode=_AG,timecode=_AG):
		if step=='1':A=bytes('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),_H);B=bytes(_B6,_H)
		else:A=bytes(_B5,_H);B=bytes([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
		return A,B
	def DecryptPlaintext(C,ciphertext,encryption_key,init_vector):A=AES.new(encryption_key,AES.MODE_CBC,init_vector);B=Padding.unpad(A.decrypt(base64.standard_b64decode(ciphertext)),16);return B.decode(_H)
	def Decrypt_Url(B,ciphertext,mediacode,timecode):
		J='watermark_key';F=timecode;E=mediacode;G='';H='';I=''
		try:C,D=B.Make_DecryptKey('1',mediacode=E,timecode=F);A=json.loads(B.DecryptPlaintext(ciphertext,C,D));K=A.get(_F);H=A.get(_Aa)if _Aa in A else'';I=A.get(J)if J in A else'';C,D=B.Make_DecryptKey('2',mediacode=E,timecode=F);G=B.DecryptPlaintext(K,C,D)
		except Exception as L:print(L)
		return G,H,I
	def Get_Apple_buildId(B):
		A=''
		try:C='https://www.tving.com/more/special/SP0071';D=B.callRequestCookies(_M,C,payload=_A,params=_A,headers=_A,cookies=_A);E='"buildId":"(.*?)"';A=re.compile(E,re.DOTALL).findall(D.text)[0]
		except Exception as F:print(F)
		return A
	def Get_AppleGroup_List(A):
		E='bandName';B=[]
		try:
			F=A.Get_Apple_buildId();G=_BG.format(F);H={'key':'SP0071'};I=A.URL_DOMAIN+G;J=A.callRequestCookies(_M,I,payload=_A,params=H,headers=_A,cookies=_A);D=json.loads(J.text)
			if not _d in D:return B
			K=D[_d][_AM][_AN][0][_AO][_R][_Ap][0][_R][_AE]
			for C in K:
				if C[_Aq]not in['VOD_BASIC']:continue
				L=re.findall('/band/\\w+|/curation/\\w+',C['moreUrl'])[0];M={E:C[E],'bandKey':L.split('/')[2]};B.append(M)
		except Exception as N:print(N)
		return B
	def Get_Band_VodList(C,bandKey,nextApiUrl=_N):
		K=nextApiUrl;B=bandKey;D=[];E=''
		try:
			if B.startswith('CR'):L='/curation/{}'.format(B)
			else:L='/band/{}'.format(B)
			if K in[_A,'',_N]:
				M=C.Get_Apple_buildId();N='/_next/data/{}/ko/more{}.json'.format(M,L);O={'key':B};G=C.URL_DOMAIN+N;H=C.callRequestCookies(_M,G,payload=_A,params=O,headers=_A,cookies=_A);A=json.loads(H.text)
				if not _d in A:return D,E
				if B.startswith('CR'):F=A[_d][_AM][_AN][0][_AO][_R][_R][_AE][0]
				else:F=A[_d][_AM][_AN][0][_AO][_R][_Ap][0][_R]['band']
			else:
				G='{}{}{}'.format(_BF,K,'&screenCode=CSSD0100&osCode=CSOD0900');H=C.callRequestCookies(_M,G,payload=_A,params=_A,headers=_A,cookies=_A);A=json.loads(H.text)
				if not _R in A:return D,E
				F=A[_R]
			for I in F[_Ao]:J=I[_AK];P={_D:I[_B],_J:I[_J],_L:{_V:J,_b:J,_c:J}};D.append(P)
			E=F.get(_B2)or''
		except Exception as Q:print(Q)
		return D,E
	def Get_bandCode_GroupCode(B,GroupCode):
		D=GroupCode;C=''
		try:
			if D=='TVING_APPLE_HOUR':
				G=B.Get_Apple_buildId();H='https://www.tving.com/_next/data/{}/ko/more/special/SP0071.json?key=SP0071'.format(G);E=B.callRequestCookies(_M,H,payload=_A,params=_A,headers=_A,cookies=_A);F=json.loads(E.text)
				if not _d in F:return C
				I=F[_d][_AM][_AN][0][_AO][_R][_Ap][0][_R][_AE]
				for A in I:
					if A[_Aq]!=_BH:continue
					return A[_AD]
			else:
				J={'authorization':'Bearer {}'.format(B.TV_TOKEN[_B3]),_Av:B.TV_TOKEN[_j]};K=['https://gw.tving.com/bff/web/v3/home/main?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/drama?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/entertainment?screenCode=CSSD0100&osCode=CSOD0900','https://gw.tving.com/bff/web/v3/home/movie?screenCode=CSSD0100&osCode=CSOD0900']
				for L in K:
					E=B.callRequestCookies(_M,L,payload=_A,params=_A,headers=J,cookies=_A);M=json.loads(E.text)
					for A in M[_R][_AE]:
						if D in A[_AD]or D=='TVING_ORIGINAL'and A[_Aq]=='VOD_BASIC_ORIGINAL':
							if':'in A[_AD]:C=A[_AD].split(':')[0]
							else:C=A[_AD]
							return C
		except Exception as N:print(N)
		return C
	def Get_Apple_NowList(A):
		E=[];G=_N
		try:
			H=A.Get_Apple_buildId();I=_BG.format(H);J={'key':'SP0071'};K=A.URL_DOMAIN+I;L=A.callRequestCookies(_M,K,payload=_A,params=J,headers=_A,cookies=_A);B=json.loads(L.text);B=B[_d][_AM][_AN][0][_AO][_R][_Ap][0][_R][_AE]
			for F in B:
				if F[_Aq]==_BH:
					for C in F[_Ao]:D=C[_AK];M={_D:C[_B],_J:C[_J],_L:{_V:D,_b:D,_c:D}};E.append(M)
		except Exception as N:print(N)
		return E,G
	def Get_AccessToken(A):
		E='userInfo';D='props'
		try:
			G=A.URL_DOMAIN;F=A.makeDefaultCookies();F.pop(_j);B=A.callRequestCookies(_M,G,payload=_A,params=_A,headers=_A,cookies=F)
			if B.status_code!=200:return _E
			H='<script id="__NEXT_DATA__" type="application/json">\\s*(.*?)\\s*</script>';I=re.compile(H,re.DOTALL).findall(B.text)[0];C=json.loads(I);A.TV_TOKEN[_B3]=C.get(D).get(_d).get(E).get(_B3);A.TV_TOKEN[_AP]=C.get(D).get(_d).get(E).get(_AP);A.TV_TOKEN[_j]=B.cookies[_j];A.TV_TOKEN[_Ar]=C.get(D).get(_d).get(E).get(_Ar);J=A.Get_Now_Datetime();K=J+datetime.timedelta(days=0);A.TV_TOKEN['token_date']=K.strftime('%Y%m%d');A.JsonFile_Save(A.TV_TOKEN_FILENAME,A.TV_TOKEN)
		except Exception as L:print(L);return _E
		return _I
	def GetLiveURL_Test(B,mediacode,sel_quality):
		T=sel_quality;N=mediacode;A={_S:'',_Aw:_E,_i:'',_A3:'',_A4:'',_A5:'',_Ax:''};X=B.TV[_U][_h].split(_N)[0];U=B.TV[_U][_h]
		try:
			H=str(B.GetNoCache(1));O='/v2/media/stream/info';F=B.GetDefaultParams();P={_x:N,'info':_X,_A1:_A2,'adReq':'adproxy',_y:U,_z:'PC',_A0:H};F.update(P);Q=B.API_DOMAIN+O;I=B.makeDefaultCookies();G=B.callRequestCookies(_M,Q,payload=_A,params=F,headers=_A,cookies=I)
			if G.status_code!=200:A[_i]='First Step - {} error'.format(G.status_code);return A
			C=json.loads(G.text)
			if C[_G][_T][_B]=='060':
				for(D,J)in QUALITY_LIST.items():
					if J==T:V=D
			elif C[_G][_T][_B]!=_AG:A[_i]=C[_G][_T][_Ay];return A
			else:
				if not _Ab in C[_G]:return A
				W=[]
				for(D,J)in QUALITY_LIST.items():
					for K in C[_G][_Ab]['quality']:
						if K['active']==_X and K[_B]==D:W.append({QUALITY_LIST.get(K[_B]):K[_B]})
				V=B.CheckQuality(T,W)
		except Exception as R:print(R);A[_i]='First Step - except error';return A
		try:
			H=str(B.GetNoCache(1));O=_B8;F=B.GetDefaultParams();P={_x:N,_w:X,_y:U,_z:_AX,_AF:V,_A0:H,_A1:_A2,_AT:B.MODEL,_AU:_AY,_AV:'aac',_AW:_AZ};F.update(P);Q=B.API_DOMAIN+O;I=B.makeDefaultCookies();G=B.callRequestCookies('Post',Q,payload=_A,params=F,headers=_A,cookies=I,redirects=_I);C=json.loads(G.text)
			if C[_G][_T][_B]!=_AG:A[_i]=C[_G][_T][_Ay];return A
			L=C[_G][_Ab]
			if L['drm_yn']==_X:
				E=L[_A6]['drm']['widevine']
				for M in L[_A6]['drm']['license'][_B9]:
					if M['drm_type']=='Widevine':A[_A3]=M[_A3];A[_A4]=M[_A4];A[_A5]=M[_A5];break
			else:E=L[_A6]['non_drm']
		except Exception as R:print(R);A[_i]=_BA;return A
		Y=H;E=E.split('|')[1];E,b,c=B.Decrypt_Url(E,N,Y);A[_S]=E;Z=A[_S].find('Policy=')
		if Z!=-1:d=A[_S].split('?')[0];S=dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(A[_S]).query));A[_S]='{}&CloudFront-Policy={}'.format(A[_S],S['Policy']);A[_S]='{}&CloudFront-Signature={}'.format(A[_S],S['Signature']);A[_S]='{}&CloudFront-Key-Pair-Id={}'.format(A[_S],S['Key-Pair-Id'])
		a=[_B4,_j,_AP]
		for(D,J)in I.items():
			if D in a:A[_S]='{}&{}={}'.format(A[_S],D,J)
		print(A[_S]);return A