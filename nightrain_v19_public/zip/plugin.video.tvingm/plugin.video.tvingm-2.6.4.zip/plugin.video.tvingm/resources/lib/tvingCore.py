__author__="NightRain"
UwIylzbDaSQfvrtuWmEgCdVsHcBeGA=print
UwIylzbDaSQfvrtuWmEgCdVsHcBeGp=ImportError
UwIylzbDaSQfvrtuWmEgCdVsHcBeGP=object
UwIylzbDaSQfvrtuWmEgCdVsHcBeGi=None
UwIylzbDaSQfvrtuWmEgCdVsHcBeGM=False
UwIylzbDaSQfvrtuWmEgCdVsHcBeGx=str
UwIylzbDaSQfvrtuWmEgCdVsHcBeGn=open
UwIylzbDaSQfvrtuWmEgCdVsHcBeGO=True
UwIylzbDaSQfvrtuWmEgCdVsHcBeGK=len
UwIylzbDaSQfvrtuWmEgCdVsHcBeGX=int
UwIylzbDaSQfvrtuWmEgCdVsHcBeGJ=range
UwIylzbDaSQfvrtuWmEgCdVsHcBeGL=Exception
UwIylzbDaSQfvrtuWmEgCdVsHcBeGj=dict
UwIylzbDaSQfvrtuWmEgCdVsHcBeGh=list
UwIylzbDaSQfvrtuWmEgCdVsHcBeGk=bytes
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 UwIylzbDaSQfvrtuWmEgCdVsHcBeGA('Cryptodome')
except UwIylzbDaSQfvrtuWmEgCdVsHcBeGp:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 UwIylzbDaSQfvrtuWmEgCdVsHcBeGA('Crypto')
UwIylzbDaSQfvrtuWmEgCdVsHcBeFq={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
UwIylzbDaSQfvrtuWmEgCdVsHcBeFo ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
UwIylzbDaSQfvrtuWmEgCdVsHcBeFR =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
UwIylzbDaSQfvrtuWmEgCdVsHcBeFY=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class UwIylzbDaSQfvrtuWmEgCdVsHcBeFT(UwIylzbDaSQfvrtuWmEgCdVsHcBeGP):
 def __init__(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.NETWORKCODE ='CSND0900'
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.OSCODE ='CSOD0900' 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TELECODE ='CSCD0900'
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.SCREENCODE ='CSSD0100'
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.SCREENCODE_ATV ='CSSD1300' 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.LIVE_LIMIT =20 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.VOD_LIMIT =24 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.EPISODE_LIMIT =30 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.SEARCH_LIMIT =30 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.MOVIE_LIMIT =24 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN ='https://api.tving.com'
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN ='https://image.tving.com'
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.SEARCH_DOMAIN ='https://search-api.tving.com'
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.LOGIN_DOMAIN ='https://user.tving.com'
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.URL_DOMAIN ='https://www.tving.com'
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.MOVIE_LITE =['2610061','2610161','261062']
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.MODEL ='chrome_128.0.0.0' 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.DEFAULT_HEADER ={'user-agent':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.USER_AGENT}
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.COOKIE_FILE_NAME =''
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV_SESSION_COOKIES1=''
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV_SESSION_COOKIES2=''
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV_STREAM_FILENAME =''
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV_SESSION_TEXT1 =''
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV_SESSION_TEXT2 =''
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.KodiVersion=20
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV ={}
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.Init_TV_Total()
 def Init_TV_Total(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV={'account':{},'cookies':{},}
 def callRequestCookies(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,jobtype,UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,json=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,redirects=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFG=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.DEFAULT_HEADER
  if headers:UwIylzbDaSQfvrtuWmEgCdVsHcBeFG.update(headers)
  if jobtype=='Get':
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFp=requests.get(UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,params=params,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeFG,cookies=cookies,allow_redirects=redirects)
  else:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFp=requests.post(UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,data=payload,json=json,params=params,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeFG,cookies=cookies,allow_redirects=redirects)
  UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFp.status_code)+' - '+UwIylzbDaSQfvrtuWmEgCdVsHcBeFp.url)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeFp
 def JsonFile_Save(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,filename,UwIylzbDaSQfvrtuWmEgCdVsHcBeFP):
  if filename=='':return UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  try:
   fp=UwIylzbDaSQfvrtuWmEgCdVsHcBeGn(filename,'w',-1,'utf-8')
   json.dump(UwIylzbDaSQfvrtuWmEgCdVsHcBeFP,fp,indent=4,ensure_ascii=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM)
   fp.close()
  except:
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
 def JsonFile_Load(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,filename):
  if filename=='':return{}
  try:
   fp=UwIylzbDaSQfvrtuWmEgCdVsHcBeGn(filename,'r',-1,'utf-8')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFM=json.load(fp)
   fp.close()
  except:
   return{}
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeFM
 def TextFile_Save(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,filename,resText):
  if filename=='':return UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  try:
   fp=UwIylzbDaSQfvrtuWmEgCdVsHcBeGn(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
 def Save_session_acount(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,UwIylzbDaSQfvrtuWmEgCdVsHcBeFx,UwIylzbDaSQfvrtuWmEgCdVsHcBeFn,UwIylzbDaSQfvrtuWmEgCdVsHcBeFO,UwIylzbDaSQfvrtuWmEgCdVsHcBeFK):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['account']['tvid'] =base64.standard_b64encode(UwIylzbDaSQfvrtuWmEgCdVsHcBeFx.encode()).decode('utf-8')
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['account']['tvpw'] =base64.standard_b64encode(UwIylzbDaSQfvrtuWmEgCdVsHcBeFn.encode()).decode('utf-8')
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['account']['tvtype']=UwIylzbDaSQfvrtuWmEgCdVsHcBeFO 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['account']['tvpf'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeFK 
 def Load_session_acount(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA):
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFx =base64.standard_b64decode(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['account']['tvid']).decode('utf-8')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFn =base64.standard_b64decode(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['account']['tvpw']).decode('utf-8')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['account']['tvtype']
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFK =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeFx,UwIylzbDaSQfvrtuWmEgCdVsHcBeFn,UwIylzbDaSQfvrtuWmEgCdVsHcBeFO,UwIylzbDaSQfvrtuWmEgCdVsHcBeFK
 def make_stream_header(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,UwIylzbDaSQfvrtuWmEgCdVsHcBeFh,UwIylzbDaSQfvrtuWmEgCdVsHcBeFN):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFX=''
  if UwIylzbDaSQfvrtuWmEgCdVsHcBeFN not in[{},UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,'']:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFJ=UwIylzbDaSQfvrtuWmEgCdVsHcBeGK(UwIylzbDaSQfvrtuWmEgCdVsHcBeFN)
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeFj in UwIylzbDaSQfvrtuWmEgCdVsHcBeFN.items():
    UwIylzbDaSQfvrtuWmEgCdVsHcBeFX+='{}={}'.format(UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeFj)
    UwIylzbDaSQfvrtuWmEgCdVsHcBeFJ+=-1
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeFJ>0:UwIylzbDaSQfvrtuWmEgCdVsHcBeFX+='; '
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFh['cookie']=UwIylzbDaSQfvrtuWmEgCdVsHcBeFX
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFk=''
  i=0
  for UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeFj in UwIylzbDaSQfvrtuWmEgCdVsHcBeFh.items():
   i=i+1
   if i>1:UwIylzbDaSQfvrtuWmEgCdVsHcBeFk+='&'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFk+='{}={}'.format(UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,urllib.parse.quote(UwIylzbDaSQfvrtuWmEgCdVsHcBeFj))
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeFk
 def makeDefaultCookies(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFN={}
  for UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeFj in UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['cookies'].items():
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFN[UwIylzbDaSQfvrtuWmEgCdVsHcBeFL]=UwIylzbDaSQfvrtuWmEgCdVsHcBeFj
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeFN
 def getDeviceStr(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTF=[]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTF.append('Windows') 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTF.append('Chrome') 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTF.append('ko-KR') 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTF.append('undefined') 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTF.append('24') 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTF.append(u'한국 표준시')
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTF.append('undefined') 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTF.append('undefined') 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTF.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTq=''
  for UwIylzbDaSQfvrtuWmEgCdVsHcBeTo in UwIylzbDaSQfvrtuWmEgCdVsHcBeTF:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTq+=UwIylzbDaSQfvrtuWmEgCdVsHcBeTo+'|'
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeTq
 def GetDefaultParams(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,uhd=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM):
  if uhd==UwIylzbDaSQfvrtuWmEgCdVsHcBeGM:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTR={'apiKey':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.APIKEY,'networkCode':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.NETWORKCODE,'osCode':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.OSCODE,'teleCode':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TELECODE,'screenCode':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.SCREENCODE,}
  else:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTR={'apiKey':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.APIKEY_ATV,'networkCode':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.NETWORKCODE,'osCode':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.OSCODE,'teleCode':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TELECODE,'screenCode':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.SCREENCODE_ATV,}
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeTR
 def GetNoCache(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,timetype=1):
  if timetype==1:
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(time.time())
  else:
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(time.time()*1000)
 def GetUniqueid(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,hValue=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi):
  if hValue:
   import hashlib
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTY=hashlib.sha1()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTY.update(hValue.encode())
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTA=UwIylzbDaSQfvrtuWmEgCdVsHcBeTY.hexdigest()[:8]
  else:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTG=[0 for i in UwIylzbDaSQfvrtuWmEgCdVsHcBeGJ(256)]
   for i in UwIylzbDaSQfvrtuWmEgCdVsHcBeGJ(256):
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTG[i]='%02x'%(i)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTp=UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(4294967295*random.random())|0
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTA=UwIylzbDaSQfvrtuWmEgCdVsHcBeTG[255&UwIylzbDaSQfvrtuWmEgCdVsHcBeTp]+UwIylzbDaSQfvrtuWmEgCdVsHcBeTG[UwIylzbDaSQfvrtuWmEgCdVsHcBeTp>>8&255]+UwIylzbDaSQfvrtuWmEgCdVsHcBeTG[UwIylzbDaSQfvrtuWmEgCdVsHcBeTp>>16&255]+UwIylzbDaSQfvrtuWmEgCdVsHcBeTG[UwIylzbDaSQfvrtuWmEgCdVsHcBeTp>>24&255]
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeTA
 def GetCredential2(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,user_id,user_pw,login_type,user_pf):
  try:
   if base64.standard_b64encode(user_id.encode()).decode('utf-8')=='a3ltOTUxMDg4':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTP='aHR0cDovL21pbmk5NTEwODguYXN1c2NvbW0uY29tOjE2NTcx'
   else:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTP='aHR0cDovLzEzMi4xNDUuOTQuMzM6MTY1NzE='
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTi={'addon':'tvingm','method':'LOGIN','data':{'type':login_type,'id':user_id,'pw':user_pw,'pf':user_pf,}}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTi=json.dumps(UwIylzbDaSQfvrtuWmEgCdVsHcBeTi,separators=(',',':'))
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTi=base64.standard_b64encode(UwIylzbDaSQfvrtuWmEgCdVsHcBeTi.encode()).decode('utf-8')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFh={'proxy-mini':UwIylzbDaSQfvrtuWmEgCdVsHcBeTi}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=requests.get(base64.standard_b64decode(UwIylzbDaSQfvrtuWmEgCdVsHcBeTP).decode('utf-8'),headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeFh)
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.status_code!=200:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.Init_TV_Total()
    return UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTx=base64.standard_b64decode(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text).decode('utf-8')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTx=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTx)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['cookies']=UwIylzbDaSQfvrtuWmEgCdVsHcBeTx
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.Init_TV_Total()
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
 def GetCredential(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,user_id,user_pw,login_type,user_pf):
  from curl_cffi import requests
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTn='chrome' 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTO=requests.Session()
  try:
   if login_type=='0':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTK='https://user.tving.com/pc/user/otherLogin.tving?loginType=10&from=pc&csite=&isAuto=false&rtUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   else:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTK='https://www.tving.com/account/login/tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFh={'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','accept-language':'ko-KR,ko;q=0.9','cache-control':'no-cache','pragma':'no-cache','priority':'u=0, i','referer':'https://www.tving.com/',}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeTO.get(UwIylzbDaSQfvrtuWmEgCdVsHcBeTK,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeFh,impersonate=UwIylzbDaSQfvrtuWmEgCdVsHcBeTn)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA('{} - {}'.format(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.status_code,UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.url))
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeTX in UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.cookies.jar:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['cookies'][UwIylzbDaSQfvrtuWmEgCdVsHcBeTX.name]=UwIylzbDaSQfvrtuWmEgCdVsHcBeTX.value
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.Init_TV_Total()
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTJ=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTL={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':UwIylzbDaSQfvrtuWmEgCdVsHcBeGM,'cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFh['referer']=UwIylzbDaSQfvrtuWmEgCdVsHcBeTK
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeTO.post(url=UwIylzbDaSQfvrtuWmEgCdVsHcBeTJ,data=UwIylzbDaSQfvrtuWmEgCdVsHcBeTL,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeFh,impersonate=UwIylzbDaSQfvrtuWmEgCdVsHcBeTn)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA('{} - {}'.format(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.status_code,UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.url))
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeTX in UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.cookies.jar:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['cookies'][UwIylzbDaSQfvrtuWmEgCdVsHcBeTX.name]=UwIylzbDaSQfvrtuWmEgCdVsHcBeTX.value
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.Init_TV_Total()
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTj=[]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTh =''
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFh['referer']=UwIylzbDaSQfvrtuWmEgCdVsHcBeTJ
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeTO.get(url=UwIylzbDaSQfvrtuWmEgCdVsHcBeTk,data=UwIylzbDaSQfvrtuWmEgCdVsHcBeTL,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeFh,impersonate=UwIylzbDaSQfvrtuWmEgCdVsHcBeTn)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA('{} - {}'.format(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.status_code,UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.url))
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeTX in UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.cookies.jar:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['cookies'][UwIylzbDaSQfvrtuWmEgCdVsHcBeTX.name]=UwIylzbDaSQfvrtuWmEgCdVsHcBeTX.value
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTj =re.findall('data-profile-no="\d+"',UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   for i in UwIylzbDaSQfvrtuWmEgCdVsHcBeGJ(UwIylzbDaSQfvrtuWmEgCdVsHcBeGK(UwIylzbDaSQfvrtuWmEgCdVsHcBeTj)):
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTN =UwIylzbDaSQfvrtuWmEgCdVsHcBeTj[i].replace('data-profile-no=','').replace('"','')
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTj[i]=UwIylzbDaSQfvrtuWmEgCdVsHcBeTN
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTh=UwIylzbDaSQfvrtuWmEgCdVsHcBeTj[user_pf]
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.Init_TV_Total()
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqF ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFh['referer']=UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTL={'profileNo':UwIylzbDaSQfvrtuWmEgCdVsHcBeTh}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeTO.post(url=UwIylzbDaSQfvrtuWmEgCdVsHcBeqF,data=UwIylzbDaSQfvrtuWmEgCdVsHcBeTL,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeFh,impersonate=UwIylzbDaSQfvrtuWmEgCdVsHcBeTn)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA('{} - {}'.format(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.status_code,UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.url))
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeTX in UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.cookies.jar:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['cookies'][UwIylzbDaSQfvrtuWmEgCdVsHcBeTX.name]=UwIylzbDaSQfvrtuWmEgCdVsHcBeTX.value
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.Init_TV_Total()
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqT =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDeviceList()
  if UwIylzbDaSQfvrtuWmEgCdVsHcBeqT not in['','-']:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['cookies']['tving_uuid']=UwIylzbDaSQfvrtuWmEgCdVsHcBeqT+'-'+UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetUniqueid(UwIylzbDaSQfvrtuWmEgCdVsHcBeqT)
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.JsonFile_Save(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.COOKIE_FILE_NAME,UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
 def GetDeviceList(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqo=[]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqR='-'
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v1/user/device/list'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqY=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFN=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.makeDefaultCookies()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeqY,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqA,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeFN)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqo=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeqo:
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['model'].lower().startswith('pc'):
     UwIylzbDaSQfvrtuWmEgCdVsHcBeqR=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['uuid']
     break
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeqR=='-':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqR=UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetNoCache(timetype=1))
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeqR
 def Get_Now_Datetime(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,mediacode,sel_quality,stype,pvrmode='-',optUHD=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqi ={'streaming_url':'','subtitleYn':UwIylzbDaSQfvrtuWmEgCdVsHcBeGM,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqR =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['cookies']['tving_uuid'].split('-')[0] 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqM =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['cookies']['tving_uuid'] 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqx=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM 
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqn=UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetNoCache(1))
   if stype!='tvingtv':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v2/media/stream/info'
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':UwIylzbDaSQfvrtuWmEgCdVsHcBeqM,'deviceInfo':'PC','noCache':UwIylzbDaSQfvrtuWmEgCdVsHcBeqn,}
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
    UwIylzbDaSQfvrtuWmEgCdVsHcBeFN=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.makeDefaultCookies()
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeFN)
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.status_code!=200:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['error_msg']='First Step - {} error'.format(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.status_code)
     return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']['code']=='060':
     for UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeFj in UwIylzbDaSQfvrtuWmEgCdVsHcBeFq.items():
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeFj==sel_quality:
       UwIylzbDaSQfvrtuWmEgCdVsHcBeqK=UwIylzbDaSQfvrtuWmEgCdVsHcBeFL
    elif UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']['code']!='000':
     UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['error_msg']=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']['message']
     return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
    else: 
     if not('stream' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']):return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
     UwIylzbDaSQfvrtuWmEgCdVsHcBeqX=[]
     for UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeFj in UwIylzbDaSQfvrtuWmEgCdVsHcBeFq.items():
      for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['stream']['quality']:
       if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['active']=='Y' and UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['code']==UwIylzbDaSQfvrtuWmEgCdVsHcBeFL:
        UwIylzbDaSQfvrtuWmEgCdVsHcBeqX.append({UwIylzbDaSQfvrtuWmEgCdVsHcBeFq.get(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['code']):UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['code']})
     UwIylzbDaSQfvrtuWmEgCdVsHcBeqK=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.CheckQuality(sel_quality,UwIylzbDaSQfvrtuWmEgCdVsHcBeqX)
     try:
      if optUHD==UwIylzbDaSQfvrtuWmEgCdVsHcBeGO and UwIylzbDaSQfvrtuWmEgCdVsHcBeqK=='stream50' and 'stream_support_info' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['content']['info']:
       if UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['content']['info']['stream_support_info']!=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi:
        if 'stream70' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['content']['info']['stream_support_info']:
         UwIylzbDaSQfvrtuWmEgCdVsHcBeqK='stream70'
         UwIylzbDaSQfvrtuWmEgCdVsHcBeqx =UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
     except:
      pass
     try:
      if optUHD==UwIylzbDaSQfvrtuWmEgCdVsHcBeGO and UwIylzbDaSQfvrtuWmEgCdVsHcBeqK=='stream50' and 'stream' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['content']['info']:
       if UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['content']['info']['stream']!=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi:
        for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['content']['info']['stream']:
         if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['code']=='stream70':
          UwIylzbDaSQfvrtuWmEgCdVsHcBeqK='stream70'
          UwIylzbDaSQfvrtuWmEgCdVsHcBeqx =UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
          break
     except:
      pass
   else:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqK='stream40'
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['error_msg']='First Step - except error'
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
  UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(UwIylzbDaSQfvrtuWmEgCdVsHcBeqK)
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqn=UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetNoCache(1))
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v3/media/stream/info'
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeqx==UwIylzbDaSQfvrtuWmEgCdVsHcBeGO:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams(uhd=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO)
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'mediaCode':mediacode,'deviceId':UwIylzbDaSQfvrtuWmEgCdVsHcBeqR,'uuid':UwIylzbDaSQfvrtuWmEgCdVsHcBeqM,'deviceInfo':'PC_Chrome WebView','streamCode':UwIylzbDaSQfvrtuWmEgCdVsHcBeqK,'noCache':UwIylzbDaSQfvrtuWmEgCdVsHcBeqn,'callingFrom':'HTML5','model':'chrome webview_96.0.4664.104','videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   else:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'mediaCode':mediacode,'deviceId':UwIylzbDaSQfvrtuWmEgCdVsHcBeqR,'uuid':UwIylzbDaSQfvrtuWmEgCdVsHcBeqM,'deviceInfo':'PC_Chrome','streamCode':UwIylzbDaSQfvrtuWmEgCdVsHcBeqK,'noCache':UwIylzbDaSQfvrtuWmEgCdVsHcBeqn,'callingFrom':'HTML5','model':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFN=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.makeDefaultCookies()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Post',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeFN,redirects=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']['code']!='000':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['error_msg']=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']['message']
    return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqJ=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['stream']
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeqJ['drm_yn']=='Y':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqL=UwIylzbDaSQfvrtuWmEgCdVsHcBeqJ['playback']['drm']['widevine']
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeqj in UwIylzbDaSQfvrtuWmEgCdVsHcBeqJ['playback']['drm']['license']['drm_license_data']:
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeqj['drm_type']=='Widevine':
      UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['drm_server_url'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeqj['drm_server_url']
      UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['drm_header_key'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeqj['drm_header_key']
      UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['drm_header_value']=UwIylzbDaSQfvrtuWmEgCdVsHcBeqj['drm_header_value']
      break
   else:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqL=UwIylzbDaSQfvrtuWmEgCdVsHcBeqJ['playback']['non_drm']
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['error_msg']='Second Step - except error'
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqh=UwIylzbDaSQfvrtuWmEgCdVsHcBeqn
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqL=UwIylzbDaSQfvrtuWmEgCdVsHcBeqL.split('|')[1]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqL=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.Decrypt_Url(UwIylzbDaSQfvrtuWmEgCdVsHcBeqL,mediacode,UwIylzbDaSQfvrtuWmEgCdVsHcBeqh)
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url']=UwIylzbDaSQfvrtuWmEgCdVsHcBeqL
  if 'subtitles' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqJ:
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeqk in UwIylzbDaSQfvrtuWmEgCdVsHcBeqJ.get('subtitles'):
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeqk.get('code')in['KO','KO_CC']:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['subtitleYn']=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
     break
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqN=urllib.parse.urlparse(UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url'])
  UwIylzbDaSQfvrtuWmEgCdVsHcBeoF =UwIylzbDaSQfvrtuWmEgCdVsHcBeqN.path.strip('/').split('/')
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['url_filename']=UwIylzbDaSQfvrtuWmEgCdVsHcBeoF[UwIylzbDaSQfvrtuWmEgCdVsHcBeGK(UwIylzbDaSQfvrtuWmEgCdVsHcBeoF)-1]
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
 def Tving_Parse_mpd(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,stream_url):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=requests.get(url=stream_url)
  UwIylzbDaSQfvrtuWmEgCdVsHcBeoT=UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.content.decode('utf-8')
  UwIylzbDaSQfvrtuWmEgCdVsHcBeoq=0
  UwIylzbDaSQfvrtuWmEgCdVsHcBeoR =ET.ElementTree(ET.fromstring(UwIylzbDaSQfvrtuWmEgCdVsHcBeoT))
  UwIylzbDaSQfvrtuWmEgCdVsHcBeoY =UwIylzbDaSQfvrtuWmEgCdVsHcBeoR.getroot()
  UwIylzbDaSQfvrtuWmEgCdVsHcBeoA=re.match(r'\{.*\}',UwIylzbDaSQfvrtuWmEgCdVsHcBeoY.tag)[0] 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeoG=UwIylzbDaSQfvrtuWmEgCdVsHcBeGj([node for _,node in ET.iterparse(io.StringIO(UwIylzbDaSQfvrtuWmEgCdVsHcBeoT),events=['start-ns'])])
  for UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeRF in UwIylzbDaSQfvrtuWmEgCdVsHcBeoG.items():
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeFL!='ns2':
    ET.register_namespace(UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeRF)
  UwIylzbDaSQfvrtuWmEgCdVsHcBeop=UwIylzbDaSQfvrtuWmEgCdVsHcBeoY.find(UwIylzbDaSQfvrtuWmEgCdVsHcBeoA+'Period')
  for UwIylzbDaSQfvrtuWmEgCdVsHcBeoP in UwIylzbDaSQfvrtuWmEgCdVsHcBeop.findall(UwIylzbDaSQfvrtuWmEgCdVsHcBeoA+'AdaptationSet'):
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeoP.attrib.get('mimeType')=='video/mp4':
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeoi in UwIylzbDaSQfvrtuWmEgCdVsHcBeoP.findall(UwIylzbDaSQfvrtuWmEgCdVsHcBeoA+'Representation'):
     UwIylzbDaSQfvrtuWmEgCdVsHcBeoM=UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(UwIylzbDaSQfvrtuWmEgCdVsHcBeoi.attrib.get('bandwidth'))
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeoq<UwIylzbDaSQfvrtuWmEgCdVsHcBeoM:UwIylzbDaSQfvrtuWmEgCdVsHcBeoq=UwIylzbDaSQfvrtuWmEgCdVsHcBeoM
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeoi in UwIylzbDaSQfvrtuWmEgCdVsHcBeoP.findall(UwIylzbDaSQfvrtuWmEgCdVsHcBeoA+'Representation'):
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeoq>UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(UwIylzbDaSQfvrtuWmEgCdVsHcBeoi.attrib.get('bandwidth')):
      UwIylzbDaSQfvrtuWmEgCdVsHcBeoP.remove(UwIylzbDaSQfvrtuWmEgCdVsHcBeoi)
   else:
    continue
  UwIylzbDaSQfvrtuWmEgCdVsHcBeox=ET.tostring(UwIylzbDaSQfvrtuWmEgCdVsHcBeoY).decode('utf-8')
  UwIylzbDaSQfvrtuWmEgCdVsHcBeon='<?xml version="1.0" encoding="UTF-8"?>\n'
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TextFile_Save(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV_STREAM_FILENAME,UwIylzbDaSQfvrtuWmEgCdVsHcBeon+UwIylzbDaSQfvrtuWmEgCdVsHcBeox)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
 def Tving_Parse_m3u8(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,stream_url):
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=requests.get(url=stream_url,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,stream=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeoO=UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.content.decode('utf-8')
   if '#EXTM3U' not in UwIylzbDaSQfvrtuWmEgCdVsHcBeoO:
    return UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
   if '#EXT-X-STREAM-INF' not in UwIylzbDaSQfvrtuWmEgCdVsHcBeoO: 
    return UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
   UwIylzbDaSQfvrtuWmEgCdVsHcBeoK=0
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeoX in UwIylzbDaSQfvrtuWmEgCdVsHcBeoO.splitlines():
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeoX.startswith('#EXT-X-STREAM-INF'):
     UwIylzbDaSQfvrtuWmEgCdVsHcBeoJ=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.MediaLine_Parse(UwIylzbDaSQfvrtuWmEgCdVsHcBeoX,'#EXT-X-STREAM-INF')
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeoK<UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(UwIylzbDaSQfvrtuWmEgCdVsHcBeoJ.get('BANDWIDTH')):
      UwIylzbDaSQfvrtuWmEgCdVsHcBeoK=UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(UwIylzbDaSQfvrtuWmEgCdVsHcBeoJ.get('BANDWIDTH'))
   UwIylzbDaSQfvrtuWmEgCdVsHcBeoL=[]
   UwIylzbDaSQfvrtuWmEgCdVsHcBeoj=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeoX in UwIylzbDaSQfvrtuWmEgCdVsHcBeoO.splitlines():
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeoj==UwIylzbDaSQfvrtuWmEgCdVsHcBeGO:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeoj=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
     continue
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeoX.startswith('#EXT-X-STREAM-INF'):
     UwIylzbDaSQfvrtuWmEgCdVsHcBeoJ=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.MediaLine_Parse(UwIylzbDaSQfvrtuWmEgCdVsHcBeoX,'#EXT-X-STREAM-INF')
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeoK!=UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(UwIylzbDaSQfvrtuWmEgCdVsHcBeoJ.get('BANDWIDTH')):
      UwIylzbDaSQfvrtuWmEgCdVsHcBeoj=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
      continue
    UwIylzbDaSQfvrtuWmEgCdVsHcBeoL.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeoX)
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  UwIylzbDaSQfvrtuWmEgCdVsHcBeoh='\n'.join(UwIylzbDaSQfvrtuWmEgCdVsHcBeoL)
  UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TextFile_Save(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV_STREAM_FILENAME,UwIylzbDaSQfvrtuWmEgCdVsHcBeoh)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
 def MediaLine_Parse(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,UwIylzbDaSQfvrtuWmEgCdVsHcBeoX,prefix):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeoJ={}
  for UwIylzbDaSQfvrtuWmEgCdVsHcBeok in UwIylzbDaSQfvrtuWmEgCdVsHcBeFR.split(UwIylzbDaSQfvrtuWmEgCdVsHcBeoX.replace(prefix+':',''))[1::2]:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeoN,UwIylzbDaSQfvrtuWmEgCdVsHcBeRF=UwIylzbDaSQfvrtuWmEgCdVsHcBeok.split('=',1)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeoJ[UwIylzbDaSQfvrtuWmEgCdVsHcBeoN.upper()]=UwIylzbDaSQfvrtuWmEgCdVsHcBeRF.replace('"','').strip()
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeoJ
 def CheckQuality(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,sel_qt,UwIylzbDaSQfvrtuWmEgCdVsHcBeqX):
  for UwIylzbDaSQfvrtuWmEgCdVsHcBeRT in UwIylzbDaSQfvrtuWmEgCdVsHcBeqX:
   if sel_qt>=UwIylzbDaSQfvrtuWmEgCdVsHcBeGh(UwIylzbDaSQfvrtuWmEgCdVsHcBeRT)[0]:return UwIylzbDaSQfvrtuWmEgCdVsHcBeRT.get(UwIylzbDaSQfvrtuWmEgCdVsHcBeGh(UwIylzbDaSQfvrtuWmEgCdVsHcBeRT)[0])
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRq=UwIylzbDaSQfvrtuWmEgCdVsHcBeRT.get(UwIylzbDaSQfvrtuWmEgCdVsHcBeGh(UwIylzbDaSQfvrtuWmEgCdVsHcBeRT)[0])
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeRq
 def makeOocUrl(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,ooc_params):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=''
  for UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeFj in ooc_params.items():
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP+="%s=%s^"%(UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeFj)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeTP
 def GetLiveChannelList(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,stype,page_int):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqo=[]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v2/media/lives'
   if stype=='onair': 
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRY='CPCS0100,CPCS0400'
   else:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRY='CPCS0300'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'cacheType':'main','pageNo':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(page_int),'pageSize':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':UwIylzbDaSQfvrtuWmEgCdVsHcBeRY,}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if not('result' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']):return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRA=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeRA:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRG=UwIylzbDaSQfvrtuWmEgCdVsHcBeRi=UwIylzbDaSQfvrtuWmEgCdVsHcBeRM=''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRp=UwIylzbDaSQfvrtuWmEgCdVsHcBeYA=''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRP=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['live_code']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRG =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['channel']['name']['ko']
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['episode']!=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRi =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['program']['name']['ko']
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRi =UwIylzbDaSQfvrtuWmEgCdVsHcBeRi+', '+UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['episode']['frequency'])+'회'
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRM=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['episode']['synopsis']['ko']
    else:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRi =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['program']['name']['ko']
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRM=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['program']['synopsis']['ko']
    try: 
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =''
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =''
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=''
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRK =''
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRX =''
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRJ =''
     for UwIylzbDaSQfvrtuWmEgCdVsHcBeRL in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['program']['image']:
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP0900':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
      elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP1800':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
      elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP2000':UwIylzbDaSQfvrtuWmEgCdVsHcBeRK =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
      elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP1900':UwIylzbDaSQfvrtuWmEgCdVsHcBeRX =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
      elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP0200':UwIylzbDaSQfvrtuWmEgCdVsHcBeRJ =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
      elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP0500':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
      elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP0800':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeRx=='':
      for UwIylzbDaSQfvrtuWmEgCdVsHcBeRL in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['channel']['image']:
       if UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIC0400':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
       elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIC1400':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
       elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIC1900':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
    except:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeGi
    try:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRj =[]
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRh=[]
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRk =[]
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRN=''
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYF=''
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYT=''
     for UwIylzbDaSQfvrtuWmEgCdVsHcBeYq in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('schedule').get('program').get('actor'):
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeYq!='' and UwIylzbDaSQfvrtuWmEgCdVsHcBeYq!=u'없음':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYq)
     for UwIylzbDaSQfvrtuWmEgCdVsHcBeYo in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('schedule').get('program').get('director'):
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeYo!='' and UwIylzbDaSQfvrtuWmEgCdVsHcBeYo!='-' and UwIylzbDaSQfvrtuWmEgCdVsHcBeYo!=u'없음':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYo)
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('schedule').get('program').get('category1_name').get('ko')!='':
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRk.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['program']['category1_name']['ko'])
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('schedule').get('program').get('category2_name').get('ko')!='':
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRk.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['program']['category2_name']['ko'])
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('schedule').get('program').get('product_year'):UwIylzbDaSQfvrtuWmEgCdVsHcBeRN=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['program']['product_year']
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('schedule').get('program').get('grade_code') :UwIylzbDaSQfvrtuWmEgCdVsHcBeYF= UwIylzbDaSQfvrtuWmEgCdVsHcBeFo.get(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['program']['grade_code'])
     if 'broad_dt' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('schedule').get('program'):
      UwIylzbDaSQfvrtuWmEgCdVsHcBeYR =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('schedule').get('program').get('broad_dt')
      UwIylzbDaSQfvrtuWmEgCdVsHcBeYT='%s-%s-%s'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[:4],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[4:6],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[6:])
    except:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeGi
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRp=UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['broadcast_start_time'])[8:12]
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYA =UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['schedule']['broadcast_end_time'])[8:12]
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYG={'channel':UwIylzbDaSQfvrtuWmEgCdVsHcBeRG,'title':UwIylzbDaSQfvrtuWmEgCdVsHcBeRi,'mediacode':UwIylzbDaSQfvrtuWmEgCdVsHcBeRP,'thumbnail':{'poster':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn,'thumb':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx,'clearlogo':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO,'icon':UwIylzbDaSQfvrtuWmEgCdVsHcBeRK,'fanart':UwIylzbDaSQfvrtuWmEgCdVsHcBeRJ},'synopsis':UwIylzbDaSQfvrtuWmEgCdVsHcBeRM,'channelepg':' [%s:%s ~ %s:%s]'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeRp[0:2],UwIylzbDaSQfvrtuWmEgCdVsHcBeRp[2:],UwIylzbDaSQfvrtuWmEgCdVsHcBeYA[0:2],UwIylzbDaSQfvrtuWmEgCdVsHcBeYA[2:]),'cast':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj,'director':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh,'info_genre':UwIylzbDaSQfvrtuWmEgCdVsHcBeRk,'year':UwIylzbDaSQfvrtuWmEgCdVsHcBeRN,'mpaa':UwIylzbDaSQfvrtuWmEgCdVsHcBeYF,'premiered':UwIylzbDaSQfvrtuWmEgCdVsHcBeYT}
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqo.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYG)
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['has_more']=='Y':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
 def GetProgramList(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,genre,orderby,page_int,genreCode='all'):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqo=[]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  try:
   if genre=='PARAMOUNT':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v2/media/paramount/episodes'
   else:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v2/media/episodes'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'cacheType':'main','pageSize':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(page_int),}
   if genre not in['all','PARAMOUNT']:UwIylzbDaSQfvrtuWmEgCdVsHcBeqA['categoryCode']=genre
   if genreCode!='all' :UwIylzbDaSQfvrtuWmEgCdVsHcBeqA['genreCode'] =genreCode 
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if not('result' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']):return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRA=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeRA:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYp=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['program']['code']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRi =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['program']['name']['ko']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYF =UwIylzbDaSQfvrtuWmEgCdVsHcBeFo.get(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['program'].get('grade_code'))
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRK =''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRX =''
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeRL in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['program']['image']:
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP0900':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP0200':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP1800':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP2000':UwIylzbDaSQfvrtuWmEgCdVsHcBeRK =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP1900':UwIylzbDaSQfvrtuWmEgCdVsHcBeRX =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRM =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['program']['synopsis']['ko']
    try:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYP=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['channel']['name']['ko']
    except:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYP=''
    try:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRj =[]
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRh=[]
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRk =[]
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRN =''
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYT=''
     for UwIylzbDaSQfvrtuWmEgCdVsHcBeYq in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('program').get('actor'):
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeYq!='' and UwIylzbDaSQfvrtuWmEgCdVsHcBeYq!='-' and UwIylzbDaSQfvrtuWmEgCdVsHcBeYq!=u'없음':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYq)
     for UwIylzbDaSQfvrtuWmEgCdVsHcBeYo in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('program').get('director'):
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeYo!='' and UwIylzbDaSQfvrtuWmEgCdVsHcBeYo!='-' and UwIylzbDaSQfvrtuWmEgCdVsHcBeYo!=u'없음':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYo)
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('program').get('category1_name').get('ko')!='':
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRk.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['program']['category1_name']['ko'])
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('program').get('category2_name').get('ko')!='':
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRk.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['program']['category2_name']['ko'])
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('program').get('product_year'):UwIylzbDaSQfvrtuWmEgCdVsHcBeRN=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['program']['product_year']
     if 'broad_dt' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('program'):
      UwIylzbDaSQfvrtuWmEgCdVsHcBeYR =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('program').get('broad_dt')
      UwIylzbDaSQfvrtuWmEgCdVsHcBeYT='%s-%s-%s'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[:4],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[4:6],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[6:])
    except:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeGi
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYG={'program':UwIylzbDaSQfvrtuWmEgCdVsHcBeYp,'title':UwIylzbDaSQfvrtuWmEgCdVsHcBeRi,'thumbnail':{'poster':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn,'thumb':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx,'clearlogo':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO,'icon':UwIylzbDaSQfvrtuWmEgCdVsHcBeRK,'banner':UwIylzbDaSQfvrtuWmEgCdVsHcBeRX,'fanart':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx},'synopsis':UwIylzbDaSQfvrtuWmEgCdVsHcBeRM,'channel':UwIylzbDaSQfvrtuWmEgCdVsHcBeYP,'cast':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj,'director':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh,'info_genre':UwIylzbDaSQfvrtuWmEgCdVsHcBeRk,'year':UwIylzbDaSQfvrtuWmEgCdVsHcBeRN,'premiered':UwIylzbDaSQfvrtuWmEgCdVsHcBeYT,'mpaa':UwIylzbDaSQfvrtuWmEgCdVsHcBeYF}
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqo.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYG)
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['has_more']=='Y':UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
 def Get_UHD_ProgramList(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,page_int):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqo=[]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v2/operator/highlights'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams(uhd=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(page_int),'pocType':'APP_X_TVING_4.0.0',}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if not('result' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']):return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRA=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeRA:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYi=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['content']['program']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYM =UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['code']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRi =UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['name']['ko'].strip()
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYF =UwIylzbDaSQfvrtuWmEgCdVsHcBeFo.get(UwIylzbDaSQfvrtuWmEgCdVsHcBeYi.get('grade_code'))
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRM =UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['synopsis']['ko']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYP =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['content']['channel']['name']['ko']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRN =UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['product_year']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRK =''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRX =''
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeRL in UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['image']:
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP0900':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP0200':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP1800':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP2000':UwIylzbDaSQfvrtuWmEgCdVsHcBeRK =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP1900':UwIylzbDaSQfvrtuWmEgCdVsHcBeRX =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRk =[]
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRj =[]
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRh=[]
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYT =''
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeYi.get('category1_name').get('ko')!='':
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRk.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['category1_name']['ko'])
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeYi.get('category2_name').get('ko')!='':
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRk.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['category2_name']['ko'])
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeYq in UwIylzbDaSQfvrtuWmEgCdVsHcBeYi.get('actor'):
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeYq!='' and UwIylzbDaSQfvrtuWmEgCdVsHcBeYq!='-' and UwIylzbDaSQfvrtuWmEgCdVsHcBeYq!=u'없음':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYq)
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeYo in UwIylzbDaSQfvrtuWmEgCdVsHcBeYi.get('director'):
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeYo!='' and UwIylzbDaSQfvrtuWmEgCdVsHcBeYo!='-' and UwIylzbDaSQfvrtuWmEgCdVsHcBeYo!=u'없음':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYo)
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeYi.get('broad_dt')not in[UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,'']:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYR =UwIylzbDaSQfvrtuWmEgCdVsHcBeYi.get('broad_dt')
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYT='%s-%s-%s'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[:4],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[4:6],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[6:])
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYG={'program':UwIylzbDaSQfvrtuWmEgCdVsHcBeYM,'title':UwIylzbDaSQfvrtuWmEgCdVsHcBeRi,'mpaa':UwIylzbDaSQfvrtuWmEgCdVsHcBeYF,'thumbnail':{'poster':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn,'thumb':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx,'clearlogo':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO,'icon':UwIylzbDaSQfvrtuWmEgCdVsHcBeRK,'banner':UwIylzbDaSQfvrtuWmEgCdVsHcBeRX,'fanart':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx},'channel':UwIylzbDaSQfvrtuWmEgCdVsHcBeYP,'synopsis':UwIylzbDaSQfvrtuWmEgCdVsHcBeRM,'year':UwIylzbDaSQfvrtuWmEgCdVsHcBeRN,'info_genre':UwIylzbDaSQfvrtuWmEgCdVsHcBeRk,'cast':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj,'director':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh,'premiered':UwIylzbDaSQfvrtuWmEgCdVsHcBeYT,}
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqo.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYG)
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
 def Get_Origianl_ProgramList(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,page_int):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqo=[]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v2/media/band/originals'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'pageSize':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(page_int),}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeYx=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.JsonFile_Save(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV_SESSION_COOKIES2,UwIylzbDaSQfvrtuWmEgCdVsHcBeYx)
   if not('contents' in UwIylzbDaSQfvrtuWmEgCdVsHcBeYx['body']):return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRA=UwIylzbDaSQfvrtuWmEgCdVsHcBeYx['body']['contents']
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeRA:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYn =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['vod_code']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRi =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['vod_name']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['image']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYO ='movie' if UwIylzbDaSQfvrtuWmEgCdVsHcBeYn.startswith('M')else 'vod'
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYG={'vod_code':UwIylzbDaSQfvrtuWmEgCdVsHcBeYn,'title':UwIylzbDaSQfvrtuWmEgCdVsHcBeRi,'thumbnail':{'poster':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn,'thumb':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn},'vod_type':UwIylzbDaSQfvrtuWmEgCdVsHcBeYO,}
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqo.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYG)
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeYx['body']['has_more']=='Y':UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
 def GetEpisodeList(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,program_code,page_int,orderby='desc'):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqo=[]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v2/media/frequency/program/'+program_code
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if not('result' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']):return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRA=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']
   UwIylzbDaSQfvrtuWmEgCdVsHcBeYK=UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['total_count'])
   UwIylzbDaSQfvrtuWmEgCdVsHcBeYX =UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(UwIylzbDaSQfvrtuWmEgCdVsHcBeYK//(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYJ =(UwIylzbDaSQfvrtuWmEgCdVsHcBeYK-1)-((page_int-1)*UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.EPISODE_LIMIT)
   else:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYJ =(page_int-1)*UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.EPISODE_LIMIT
   for i in UwIylzbDaSQfvrtuWmEgCdVsHcBeGJ(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.EPISODE_LIMIT):
    if orderby=='desc':
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYL=UwIylzbDaSQfvrtuWmEgCdVsHcBeYJ-i
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeYL<0:break
    else:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYL=UwIylzbDaSQfvrtuWmEgCdVsHcBeYJ+i
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeYL>=UwIylzbDaSQfvrtuWmEgCdVsHcBeYK:break
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYj=UwIylzbDaSQfvrtuWmEgCdVsHcBeRA[UwIylzbDaSQfvrtuWmEgCdVsHcBeYL]['episode']['code']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRi =UwIylzbDaSQfvrtuWmEgCdVsHcBeRA[UwIylzbDaSQfvrtuWmEgCdVsHcBeYL]['vod_name']['ko']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYh =''
    try:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYR=UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeRA[UwIylzbDaSQfvrtuWmEgCdVsHcBeYL]['episode']['broadcast_date'])
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYh='%s-%s-%s'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[:4],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[4:6],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[6:])
    except:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeGi
    try:
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeRA[UwIylzbDaSQfvrtuWmEgCdVsHcBeYL]['episode']['pip_cliptype']=='C012':
      UwIylzbDaSQfvrtuWmEgCdVsHcBeYh+=' - Quick VOD'
    except:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeGi
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRM =UwIylzbDaSQfvrtuWmEgCdVsHcBeRA[UwIylzbDaSQfvrtuWmEgCdVsHcBeYL]['episode']['synopsis']['ko']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRK =''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRX =''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRJ =''
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeRL in UwIylzbDaSQfvrtuWmEgCdVsHcBeRA[UwIylzbDaSQfvrtuWmEgCdVsHcBeYL]['program']['image']:
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP0900':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP1800':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP2000':UwIylzbDaSQfvrtuWmEgCdVsHcBeRK =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP1900':UwIylzbDaSQfvrtuWmEgCdVsHcBeRX =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIP0200':UwIylzbDaSQfvrtuWmEgCdVsHcBeRJ =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeRL in UwIylzbDaSQfvrtuWmEgCdVsHcBeRA[UwIylzbDaSQfvrtuWmEgCdVsHcBeYL]['episode']['image']:
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIE0400':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
    try:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYk=UwIylzbDaSQfvrtuWmEgCdVsHcBeAF=UwIylzbDaSQfvrtuWmEgCdVsHcBeAT=''
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYN=0
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYk =UwIylzbDaSQfvrtuWmEgCdVsHcBeRA[UwIylzbDaSQfvrtuWmEgCdVsHcBeYL]['program']['name']['ko']
     UwIylzbDaSQfvrtuWmEgCdVsHcBeAF =UwIylzbDaSQfvrtuWmEgCdVsHcBeYh
     UwIylzbDaSQfvrtuWmEgCdVsHcBeAT =UwIylzbDaSQfvrtuWmEgCdVsHcBeRA[UwIylzbDaSQfvrtuWmEgCdVsHcBeYL]['channel']['name']['ko']
     if 'frequency' in UwIylzbDaSQfvrtuWmEgCdVsHcBeRA[UwIylzbDaSQfvrtuWmEgCdVsHcBeYL]['episode']:UwIylzbDaSQfvrtuWmEgCdVsHcBeYN=UwIylzbDaSQfvrtuWmEgCdVsHcBeRA[UwIylzbDaSQfvrtuWmEgCdVsHcBeYL]['episode']['frequency']
    except:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeGi
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYG={'episode':UwIylzbDaSQfvrtuWmEgCdVsHcBeYj,'title':UwIylzbDaSQfvrtuWmEgCdVsHcBeRi,'subtitle':UwIylzbDaSQfvrtuWmEgCdVsHcBeYh,'thumbnail':{'poster':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn,'thumb':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx,'clearlogo':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO,'icon':UwIylzbDaSQfvrtuWmEgCdVsHcBeRK,'banner':UwIylzbDaSQfvrtuWmEgCdVsHcBeRX,'fanart':UwIylzbDaSQfvrtuWmEgCdVsHcBeRJ},'synopsis':UwIylzbDaSQfvrtuWmEgCdVsHcBeRM,'info_title':UwIylzbDaSQfvrtuWmEgCdVsHcBeYk,'aired':UwIylzbDaSQfvrtuWmEgCdVsHcBeAF,'studio':UwIylzbDaSQfvrtuWmEgCdVsHcBeAT,'frequency':UwIylzbDaSQfvrtuWmEgCdVsHcBeYN}
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqo.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYG)
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeYX>page_int:UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo,UwIylzbDaSQfvrtuWmEgCdVsHcBeYX
 def GetMovieList(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,genre,orderby,page_int):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqo=[]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  try:
   if genre=='PARAMOUNT':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v2/media/paramount/movies'
   else:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v2/media/movies'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'pageSize':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:UwIylzbDaSQfvrtuWmEgCdVsHcBeqA['categoryCode']=genre
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA['productPackageCode']=','.join(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.MOVIE_LITE)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if not('result' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']):return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRA=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeRA:
    if 'release_date' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('movie'):
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRN=UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('movie').get('release_date'))[:4]
    else:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRN=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAq =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['movie']['code']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRi =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['movie']['name']['ko'].strip()
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeRN not in[UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,'0','']:UwIylzbDaSQfvrtuWmEgCdVsHcBeRi+=u' (%s)'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeRN)
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRn=''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=''
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeRL in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['movie']['image']:
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIM2100':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIM0400':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIM1800':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRM =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['movie']['story']['ko']
    try:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYk =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['movie']['name']['ko'].strip()
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYF =UwIylzbDaSQfvrtuWmEgCdVsHcBeFo.get(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('grade_code'))
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRj=[]
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRh=[]
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRk=[]
     UwIylzbDaSQfvrtuWmEgCdVsHcBeAo=0
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYT=''
     UwIylzbDaSQfvrtuWmEgCdVsHcBeAT =''
     for UwIylzbDaSQfvrtuWmEgCdVsHcBeYq in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('movie').get('actor'):
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeYq!='':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYq)
     for UwIylzbDaSQfvrtuWmEgCdVsHcBeYo in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('movie').get('director'):
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeYo!='':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYo)
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('movie').get('category1_name').get('ko')!='':
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRk.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['movie']['category1_name']['ko'])
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('movie').get('category2_name').get('ko')!='':
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRk.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['movie']['category2_name']['ko'])
     if 'duration' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('movie'):UwIylzbDaSQfvrtuWmEgCdVsHcBeAo=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('movie').get('duration')
     if 'release_date' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('movie'):
      UwIylzbDaSQfvrtuWmEgCdVsHcBeYR=UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('movie').get('release_date'))
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeYR!='0':UwIylzbDaSQfvrtuWmEgCdVsHcBeYT='%s-%s-%s'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[:4],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[4:6],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[6:])
     if 'production' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('movie'):UwIylzbDaSQfvrtuWmEgCdVsHcBeAT=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('movie').get('production')
    except:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeGi
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYG={'moviecode':UwIylzbDaSQfvrtuWmEgCdVsHcBeAq,'title':UwIylzbDaSQfvrtuWmEgCdVsHcBeRi,'thumbnail':{'poster':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn,'thumb':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx,'clearlogo':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO,'fanart':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx},'synopsis':UwIylzbDaSQfvrtuWmEgCdVsHcBeRM,'info_title':UwIylzbDaSQfvrtuWmEgCdVsHcBeYk,'year':UwIylzbDaSQfvrtuWmEgCdVsHcBeRN,'cast':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj,'director':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh,'info_genre':UwIylzbDaSQfvrtuWmEgCdVsHcBeRk,'duration':UwIylzbDaSQfvrtuWmEgCdVsHcBeAo,'premiered':UwIylzbDaSQfvrtuWmEgCdVsHcBeYT,'studio':UwIylzbDaSQfvrtuWmEgCdVsHcBeAT,'mpaa':UwIylzbDaSQfvrtuWmEgCdVsHcBeYF}
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAR=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeAY in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['billing_package_id']:
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeAY in UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.MOVIE_LITE:
      UwIylzbDaSQfvrtuWmEgCdVsHcBeAR=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
      break
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeAR==UwIylzbDaSQfvrtuWmEgCdVsHcBeGM: 
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYG['title']=UwIylzbDaSQfvrtuWmEgCdVsHcBeYG['title']+' [개별구매]'
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqo.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYG)
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['has_more']=='Y':UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
 def Get_UHD_MovieList(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,page_int):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqo=[]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v2/operator/highlights'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams(uhd=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(page_int),'pocType':'APP_X_TVING_4.0.0',}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if not('result' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']):return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRA=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeRA:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYi=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['content']['movie']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYM =UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['code']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRi =UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['name']['ko'].strip()
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYk =UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['name']['ko'].strip()
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRN =UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['product_year']
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeRN:UwIylzbDaSQfvrtuWmEgCdVsHcBeRi+=u' (%s)'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['product_year'])
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRM =UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['story']['ko']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAo =UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['duration']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYF =UwIylzbDaSQfvrtuWmEgCdVsHcBeFo.get(UwIylzbDaSQfvrtuWmEgCdVsHcBeYi.get('grade_code'))
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAT =UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['production']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRn=''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=''
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRk =[]
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRj =[]
    UwIylzbDaSQfvrtuWmEgCdVsHcBeRh=[]
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYT =''
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeRL in UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['image']:
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIM2100':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIM0400':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
     elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['code']=='CAIM1800':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL['url']
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['release_date']not in[UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,0]:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYR=UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['release_date'])
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeYR!='0':UwIylzbDaSQfvrtuWmEgCdVsHcBeYT='%s-%s-%s'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[:4],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[4:6],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[6:])
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeYi.get('category1_name').get('ko')!='':
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRk.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['category1_name']['ko'])
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeYi.get('category2_name').get('ko')!='':
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRk.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYi['category2_name']['ko'])
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeYq in UwIylzbDaSQfvrtuWmEgCdVsHcBeYi.get('actor'):
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeYq!='':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYq)
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeYo in UwIylzbDaSQfvrtuWmEgCdVsHcBeYi.get('director'):
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeYo!='':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYo)
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYG={'moviecode':UwIylzbDaSQfvrtuWmEgCdVsHcBeYM,'title':UwIylzbDaSQfvrtuWmEgCdVsHcBeRi,'thumbnail':{'poster':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn,'thumb':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx,'clearlogo':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO,'fanart':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx},'year':UwIylzbDaSQfvrtuWmEgCdVsHcBeRN,'info_title':UwIylzbDaSQfvrtuWmEgCdVsHcBeYk,'synopsis':UwIylzbDaSQfvrtuWmEgCdVsHcBeRM,'mpaa':UwIylzbDaSQfvrtuWmEgCdVsHcBeYF,'duration':UwIylzbDaSQfvrtuWmEgCdVsHcBeAo,'premiered':UwIylzbDaSQfvrtuWmEgCdVsHcBeYT,'studio':UwIylzbDaSQfvrtuWmEgCdVsHcBeAT,'info_genre':UwIylzbDaSQfvrtuWmEgCdVsHcBeRk,'cast':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj,'director':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh,}
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqo.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYG)
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
 def GetMovieGenre(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqo=[]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v2/media/movie/curations'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if not('result' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']):return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRA=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeRA:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAG =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['curation_code']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAp =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['curation_name']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeYG={'curation_code':UwIylzbDaSQfvrtuWmEgCdVsHcBeAG,'curation_name':UwIylzbDaSQfvrtuWmEgCdVsHcBeAp}
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqo.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYG)
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
 def GetSearchList(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,search_key,page_int,stype):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeAP=[]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGM
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/search/getSearch.jsp'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.SCREENCODE,'os':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.OSCODE,'network':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.APIKEY,'networkCode':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.NETWORKCODE,'osCode ':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.OSCODE,'teleCode ':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TELECODE,'screenCode ':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.SCREENCODE}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.SEARCH_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqA,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if stype=='vod':
    if not('programRsb' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG):return UwIylzbDaSQfvrtuWmEgCdVsHcBeAP,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAi=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['programRsb']['dataList']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAM =UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['programRsb']['count'])
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeAi:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYp=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['mast_cd']
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRi =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['mast_nm']
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRn=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['web_url4']
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['web_url']
     try:
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRj =[]
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRh=[]
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRk =[]
      UwIylzbDaSQfvrtuWmEgCdVsHcBeAo =0
      UwIylzbDaSQfvrtuWmEgCdVsHcBeYF =''
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRN =''
      UwIylzbDaSQfvrtuWmEgCdVsHcBeAF =''
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('actor') !='' and UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('actor') !='-':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('actor').split(',')
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('director')!='' and UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('director')!='-':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('director').split(',')
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('cate_nm')!='' and UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('cate_nm')!='-':UwIylzbDaSQfvrtuWmEgCdVsHcBeRk =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('cate_nm').split('/')
      if 'targetage' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp:UwIylzbDaSQfvrtuWmEgCdVsHcBeYF=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('targetage')
      if 'broad_dt' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp:
       UwIylzbDaSQfvrtuWmEgCdVsHcBeYR=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('broad_dt')
       UwIylzbDaSQfvrtuWmEgCdVsHcBeAF='%s-%s-%s'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[:4],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[4:6],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[6:])
       UwIylzbDaSQfvrtuWmEgCdVsHcBeRN =UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[:4]
     except:
      UwIylzbDaSQfvrtuWmEgCdVsHcBeGi
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYG={'program':UwIylzbDaSQfvrtuWmEgCdVsHcBeYp,'title':UwIylzbDaSQfvrtuWmEgCdVsHcBeRi,'thumbnail':{'poster':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn,'thumb':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx,'fanart':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx},'synopsis':'','cast':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj,'director':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh,'info_genre':UwIylzbDaSQfvrtuWmEgCdVsHcBeRk,'duration':UwIylzbDaSQfvrtuWmEgCdVsHcBeAo,'mpaa':UwIylzbDaSQfvrtuWmEgCdVsHcBeYF,'year':UwIylzbDaSQfvrtuWmEgCdVsHcBeRN,'aired':UwIylzbDaSQfvrtuWmEgCdVsHcBeAF}
     UwIylzbDaSQfvrtuWmEgCdVsHcBeAP.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYG)
   else:
    if not('vodMVRsb' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG):return UwIylzbDaSQfvrtuWmEgCdVsHcBeAP,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAx=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['vodMVRsb']['dataList']
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAM =UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['vodMVRsb']['count'])
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeAx:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYp=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['mast_cd']
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRi =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['mast_nm'].strip()
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['web_url']
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeRn
     UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=''
     try:
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRj =[]
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRh=[]
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRk =[]
      UwIylzbDaSQfvrtuWmEgCdVsHcBeAo =0
      UwIylzbDaSQfvrtuWmEgCdVsHcBeYF =''
      UwIylzbDaSQfvrtuWmEgCdVsHcBeRN =''
      UwIylzbDaSQfvrtuWmEgCdVsHcBeAF =''
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('actor') !='' and UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('actor') !='-':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('actor').split(',')
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('director')!='' and UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('director')!='-':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('director').split(',')
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('cate_nm')!='' and UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('cate_nm')!='-':UwIylzbDaSQfvrtuWmEgCdVsHcBeRk =UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('cate_nm').split('/')
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('runtime_sec')!='':UwIylzbDaSQfvrtuWmEgCdVsHcBeAo=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('runtime_sec')
      if 'grade_nm' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqp:UwIylzbDaSQfvrtuWmEgCdVsHcBeYF=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('grade_nm')
      UwIylzbDaSQfvrtuWmEgCdVsHcBeYR=UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('broad_dt')
      if data_str!='':
       UwIylzbDaSQfvrtuWmEgCdVsHcBeAF='%s-%s-%s'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[:4],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[4:6],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[6:])
       UwIylzbDaSQfvrtuWmEgCdVsHcBeRN =UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[:4]
     except:
      UwIylzbDaSQfvrtuWmEgCdVsHcBeGi
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYG={'movie':UwIylzbDaSQfvrtuWmEgCdVsHcBeYp,'title':UwIylzbDaSQfvrtuWmEgCdVsHcBeRi,'thumbnail':{'poster':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn,'thumb':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx,'fanart':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx,'clearlogo':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO},'synopsis':'','cast':UwIylzbDaSQfvrtuWmEgCdVsHcBeRj,'director':UwIylzbDaSQfvrtuWmEgCdVsHcBeRh,'info_genre':UwIylzbDaSQfvrtuWmEgCdVsHcBeRk,'duration':UwIylzbDaSQfvrtuWmEgCdVsHcBeAo,'mpaa':UwIylzbDaSQfvrtuWmEgCdVsHcBeYF,'year':UwIylzbDaSQfvrtuWmEgCdVsHcBeRN,'aired':UwIylzbDaSQfvrtuWmEgCdVsHcBeAF}
     UwIylzbDaSQfvrtuWmEgCdVsHcBeAP.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYG)
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeAM>(page_int*UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.SEARCH_LIMIT):UwIylzbDaSQfvrtuWmEgCdVsHcBeRo=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeAP,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
 def GetBookmarkInfo(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,videoid,vidtype):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeAn={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+'/v2/media/program/'+videoid
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'pageNo':'1','pageSize':'10','order':'name',}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeYx=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if not('body' in UwIylzbDaSQfvrtuWmEgCdVsHcBeYx):return{}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAO=UwIylzbDaSQfvrtuWmEgCdVsHcBeYx['body']
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRi=UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('name').get('ko').strip()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['title'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeRi
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['title']=UwIylzbDaSQfvrtuWmEgCdVsHcBeRi
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['mpaa'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeFo.get(UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('grade_code'))
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['plot'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('synopsis').get('ko')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['year'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('product_year')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['cast'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('actor')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['director']=UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('director')
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('category1_name').get('ko')!='':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['genre'].append(UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('category1_name').get('ko'))
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('category2_name').get('ko')!='':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['genre'].append(UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('category2_name').get('ko'))
   UwIylzbDaSQfvrtuWmEgCdVsHcBeYR=UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('broad_dt'))
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeYR!='0':UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[:4],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[4:6],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[6:])
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =''
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =''
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=''
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRK =''
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRX =''
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeRL in UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('image'):
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('code')=='CAIP0900':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('url')
    elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('code')=='CAIP0200':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('url')
    elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('code')=='CAIP1800':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('url')
    elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('code')=='CAIP2000':UwIylzbDaSQfvrtuWmEgCdVsHcBeRK =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('url')
    elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('code')=='CAIP1900':UwIylzbDaSQfvrtuWmEgCdVsHcBeRX =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('url')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['thumbnail']['poster']=UwIylzbDaSQfvrtuWmEgCdVsHcBeRn
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['thumbnail']['thumb']=UwIylzbDaSQfvrtuWmEgCdVsHcBeRx
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['thumbnail']['clearlogo']=UwIylzbDaSQfvrtuWmEgCdVsHcBeRO
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['thumbnail']['icon']=UwIylzbDaSQfvrtuWmEgCdVsHcBeRK
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['thumbnail']['banner']=UwIylzbDaSQfvrtuWmEgCdVsHcBeRX
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['thumbnail']['fanart']=UwIylzbDaSQfvrtuWmEgCdVsHcBeRx
  else:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+'/v2a/media/stream/info'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['cookies']['tving_uuid'].split('-')[0],'uuid':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetNoCache(1)),'wm':'Y',}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeYx=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if not('content' in UwIylzbDaSQfvrtuWmEgCdVsHcBeYx['body']):return{}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAO=UwIylzbDaSQfvrtuWmEgCdVsHcBeYx['body']['content']['info']['movie']
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRi =UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('name').get('ko').strip()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['title']=UwIylzbDaSQfvrtuWmEgCdVsHcBeRi
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRi +=u' (%s)'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('product_year'))
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['title'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeRi
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['mpaa'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeFo.get(UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('grade_code'))
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['plot'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('story').get('ko')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['year'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('product_year')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['studio'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('production')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['duration']=UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('duration')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['cast'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('actor')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['director']=UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('director')
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('category1_name').get('ko')!='':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['genre'].append(UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('category1_name').get('ko'))
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('category2_name').get('ko')!='':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['genre'].append(UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('category2_name').get('ko'))
   UwIylzbDaSQfvrtuWmEgCdVsHcBeYR=UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('release_date'))
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeYR!='0':UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[:4],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[4:6],UwIylzbDaSQfvrtuWmEgCdVsHcBeYR[6:])
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRn=''
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =''
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=''
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeRL in UwIylzbDaSQfvrtuWmEgCdVsHcBeAO.get('image'):
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('code')=='CAIM2100':UwIylzbDaSQfvrtuWmEgCdVsHcBeRn =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('url')
    elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('code')=='CAIM0400':UwIylzbDaSQfvrtuWmEgCdVsHcBeRx =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('url')
    elif UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('code')=='CAIM1800':UwIylzbDaSQfvrtuWmEgCdVsHcBeRO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.IMG_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeRL.get('url')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['thumbnail']['poster']=UwIylzbDaSQfvrtuWmEgCdVsHcBeRn
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['thumbnail']['thumb']=UwIylzbDaSQfvrtuWmEgCdVsHcBeRn 
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['thumbnail']['clearlogo']=UwIylzbDaSQfvrtuWmEgCdVsHcBeRO
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAn['saveinfo']['thumbnail']['fanart']=UwIylzbDaSQfvrtuWmEgCdVsHcBeRx
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeAn
 def GetEuroChannelList(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqo=[]
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v2/operator/highlights'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetNoCache(2))}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if not('result' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']):return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo,UwIylzbDaSQfvrtuWmEgCdVsHcBeRo
   UwIylzbDaSQfvrtuWmEgCdVsHcBeRA=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAK =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.Get_Now_Datetime()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAX=UwIylzbDaSQfvrtuWmEgCdVsHcBeAK+datetime.timedelta(days=-1)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAX=UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(UwIylzbDaSQfvrtuWmEgCdVsHcBeAX.strftime('%Y%m%d'))
   for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeRA:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeAJ=UwIylzbDaSQfvrtuWmEgCdVsHcBeGX(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('content').get('banner_title2')[:8])
    if UwIylzbDaSQfvrtuWmEgCdVsHcBeAX<=UwIylzbDaSQfvrtuWmEgCdVsHcBeAJ:
     UwIylzbDaSQfvrtuWmEgCdVsHcBeYG={'channel':UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('content').get('banner_sub_title3'),'title':UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('content').get('banner_title'),'subtitle':UwIylzbDaSQfvrtuWmEgCdVsHcBeqp.get('content').get('banner_sub_title2'),}
     UwIylzbDaSQfvrtuWmEgCdVsHcBeqo.append(UwIylzbDaSQfvrtuWmEgCdVsHcBeYG)
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeqo
 def Make_DecryptKey(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,step,mediacode='000',timecode='000'):
  if step=='1':
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAL=UwIylzbDaSQfvrtuWmEgCdVsHcBeGk('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAj=UwIylzbDaSQfvrtuWmEgCdVsHcBeGk('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAL=UwIylzbDaSQfvrtuWmEgCdVsHcBeGk('kss2lym0kdw1lks3','utf-8')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAj=UwIylzbDaSQfvrtuWmEgCdVsHcBeGk([42,7,114,59,55,5,30,1,110,68,2,51,42,97,38,60])
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeAL,UwIylzbDaSQfvrtuWmEgCdVsHcBeAj
 def DecryptPlaintext(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,ciphertext,encryption_key,init_vector):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeAh=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  UwIylzbDaSQfvrtuWmEgCdVsHcBeAk=Padding.unpad(UwIylzbDaSQfvrtuWmEgCdVsHcBeAh.decrypt(base64.standard_b64decode(ciphertext)),16)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeAk.decode('utf-8')
 def Decrypt_Url(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,ciphertext,mediacode,UwIylzbDaSQfvrtuWmEgCdVsHcBeqh):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeAN=''
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAL,UwIylzbDaSQfvrtuWmEgCdVsHcBeAj=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.Make_DecryptKey('1',mediacode=mediacode,timecode=UwIylzbDaSQfvrtuWmEgCdVsHcBeqh)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGF=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.DecryptPlaintext(ciphertext,UwIylzbDaSQfvrtuWmEgCdVsHcBeAL,UwIylzbDaSQfvrtuWmEgCdVsHcBeAj))
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGT =UwIylzbDaSQfvrtuWmEgCdVsHcBeGF.get('url')
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAL,UwIylzbDaSQfvrtuWmEgCdVsHcBeAj=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.Make_DecryptKey('2',mediacode=mediacode,timecode=UwIylzbDaSQfvrtuWmEgCdVsHcBeqh)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeAN=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.DecryptPlaintext(UwIylzbDaSQfvrtuWmEgCdVsHcBeGT,UwIylzbDaSQfvrtuWmEgCdVsHcBeAL,UwIylzbDaSQfvrtuWmEgCdVsHcBeAj)
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeAN
 def GetLiveURL_Test(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA,mediacode,sel_quality):
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqi ={'streaming_url':'','subtitleYn':UwIylzbDaSQfvrtuWmEgCdVsHcBeGM,'error_msg':'','drm_server_url':'','drm_header_key':'','drm_header_value':'','url_filename':'',}
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqR =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['cookies']['tving_uuid'].split('-')[0] 
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqM =UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.TV['cookies']['tving_uuid'] 
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqn=UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetNoCache(1))
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v2/media/stream/info' 
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':UwIylzbDaSQfvrtuWmEgCdVsHcBeqM,'deviceInfo':'PC','noCache':UwIylzbDaSQfvrtuWmEgCdVsHcBeqn,}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFN=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.makeDefaultCookies()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Get',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeFN)
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.status_code!=200:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['error_msg']='First Step - {} error'.format(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.status_code)
    return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']['code']=='060':
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeFj in UwIylzbDaSQfvrtuWmEgCdVsHcBeFq.items():
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeFj==sel_quality:
      UwIylzbDaSQfvrtuWmEgCdVsHcBeqK=UwIylzbDaSQfvrtuWmEgCdVsHcBeFL
   elif UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']['code']!='000':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['error_msg']=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']['message']
    return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
   else: 
    if not('stream' in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']):return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqX=[]
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeFj in UwIylzbDaSQfvrtuWmEgCdVsHcBeFq.items():
     for UwIylzbDaSQfvrtuWmEgCdVsHcBeqp in UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['stream']['quality']:
      if UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['active']=='Y' and UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['code']==UwIylzbDaSQfvrtuWmEgCdVsHcBeFL:
       UwIylzbDaSQfvrtuWmEgCdVsHcBeqX.append({UwIylzbDaSQfvrtuWmEgCdVsHcBeFq.get(UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['code']):UwIylzbDaSQfvrtuWmEgCdVsHcBeqp['code']})
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqK=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.CheckQuality(sel_quality,UwIylzbDaSQfvrtuWmEgCdVsHcBeqX)
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['error_msg']='First Step - except error'
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
  try:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqn=UwIylzbDaSQfvrtuWmEgCdVsHcBeGx(UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetNoCache(1))
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTk ='/v3/media/stream/info'
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.GetDefaultParams()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqA={'mediaCode':mediacode,'deviceId':UwIylzbDaSQfvrtuWmEgCdVsHcBeqR,'uuid':UwIylzbDaSQfvrtuWmEgCdVsHcBeqM,'deviceInfo':'PC_Chrome','streamCode':UwIylzbDaSQfvrtuWmEgCdVsHcBeqK,'noCache':UwIylzbDaSQfvrtuWmEgCdVsHcBeqn,'callingFrom':'HTML5','model':UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.MODEL,'videoTypes':'h264|hevc','audioTypes':'aac','authType':'header',}
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqO.update(UwIylzbDaSQfvrtuWmEgCdVsHcBeqA)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTP=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.API_DOMAIN+UwIylzbDaSQfvrtuWmEgCdVsHcBeTk
   UwIylzbDaSQfvrtuWmEgCdVsHcBeFN=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.makeDefaultCookies()
   UwIylzbDaSQfvrtuWmEgCdVsHcBeTM=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.callRequestCookies('Post',UwIylzbDaSQfvrtuWmEgCdVsHcBeTP,payload=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,params=UwIylzbDaSQfvrtuWmEgCdVsHcBeqO,headers=UwIylzbDaSQfvrtuWmEgCdVsHcBeGi,cookies=UwIylzbDaSQfvrtuWmEgCdVsHcBeFN,redirects=UwIylzbDaSQfvrtuWmEgCdVsHcBeGO)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqG=json.loads(UwIylzbDaSQfvrtuWmEgCdVsHcBeTM.text)
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']['code']!='000':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['error_msg']=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['result']['message']
    return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqJ=UwIylzbDaSQfvrtuWmEgCdVsHcBeqG['body']['stream']
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeqJ['drm_yn']=='Y':
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqL=UwIylzbDaSQfvrtuWmEgCdVsHcBeqJ['playback']['drm']['widevine']
    for UwIylzbDaSQfvrtuWmEgCdVsHcBeqj in UwIylzbDaSQfvrtuWmEgCdVsHcBeqJ['playback']['drm']['license']['drm_license_data']:
     if UwIylzbDaSQfvrtuWmEgCdVsHcBeqj['drm_type']=='Widevine':
      UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['drm_server_url'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeqj['drm_server_url']
      UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['drm_header_key'] =UwIylzbDaSQfvrtuWmEgCdVsHcBeqj['drm_header_key']
      UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['drm_header_value']=UwIylzbDaSQfvrtuWmEgCdVsHcBeqj['drm_header_value']
      break
   else:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqL=UwIylzbDaSQfvrtuWmEgCdVsHcBeqJ['playback']['non_drm']
  except UwIylzbDaSQfvrtuWmEgCdVsHcBeGL as exception:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(exception)
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['error_msg']='Second Step - except error'
   return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqh=UwIylzbDaSQfvrtuWmEgCdVsHcBeqn
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqL=UwIylzbDaSQfvrtuWmEgCdVsHcBeqL.split('|')[1]
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqL=UwIylzbDaSQfvrtuWmEgCdVsHcBeFA.Decrypt_Url(UwIylzbDaSQfvrtuWmEgCdVsHcBeqL,mediacode,UwIylzbDaSQfvrtuWmEgCdVsHcBeqh)
  UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url']=UwIylzbDaSQfvrtuWmEgCdVsHcBeqL
  UwIylzbDaSQfvrtuWmEgCdVsHcBeGq =UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url'].find('Policy=')
  if UwIylzbDaSQfvrtuWmEgCdVsHcBeGq!=-1:
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGo =UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url'].split('?')[0]
   UwIylzbDaSQfvrtuWmEgCdVsHcBeGR=UwIylzbDaSQfvrtuWmEgCdVsHcBeGj(urllib.parse.parse_qsl(urllib.parse.urlsplit(UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url']).query))
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url']='{}&CloudFront-Policy={}'.format(UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url'],UwIylzbDaSQfvrtuWmEgCdVsHcBeGR['Policy'])
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url']='{}&CloudFront-Signature={}'.format(UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url'],UwIylzbDaSQfvrtuWmEgCdVsHcBeGR['Signature'])
   UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url'],UwIylzbDaSQfvrtuWmEgCdVsHcBeGR['Key-Pair-Id'])
  UwIylzbDaSQfvrtuWmEgCdVsHcBeGY=['_tving_token','accessToken','authToken',]
  for UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeFj in UwIylzbDaSQfvrtuWmEgCdVsHcBeFN.items():
   if UwIylzbDaSQfvrtuWmEgCdVsHcBeFL in UwIylzbDaSQfvrtuWmEgCdVsHcBeGY:
    UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url']='{}&{}={}'.format(UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url'],UwIylzbDaSQfvrtuWmEgCdVsHcBeFL,UwIylzbDaSQfvrtuWmEgCdVsHcBeFj)
  UwIylzbDaSQfvrtuWmEgCdVsHcBeGA(UwIylzbDaSQfvrtuWmEgCdVsHcBeqi['streaming_url'])
  return UwIylzbDaSQfvrtuWmEgCdVsHcBeqi
# Created by pyminifier (https://github.com/liftoff/pyminifier)
