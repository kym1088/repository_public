__author__="NightRain"
TKRdIHXDQAGOYsjyhEFzVMmvxwJucN=object
TKRdIHXDQAGOYsjyhEFzVMmvxwJucW=None
TKRdIHXDQAGOYsjyhEFzVMmvxwJucr=int
TKRdIHXDQAGOYsjyhEFzVMmvxwJuce=True
TKRdIHXDQAGOYsjyhEFzVMmvxwJucC=False
TKRdIHXDQAGOYsjyhEFzVMmvxwJuBa=type
TKRdIHXDQAGOYsjyhEFzVMmvxwJuBo=dict
TKRdIHXDQAGOYsjyhEFzVMmvxwJuBb=getattr
TKRdIHXDQAGOYsjyhEFzVMmvxwJuBq=list
TKRdIHXDQAGOYsjyhEFzVMmvxwJuBS=len
TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk=str
TKRdIHXDQAGOYsjyhEFzVMmvxwJuBP=range
TKRdIHXDQAGOYsjyhEFzVMmvxwJuBc=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
TKRdIHXDQAGOYsjyhEFzVMmvxwJuab=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
TKRdIHXDQAGOYsjyhEFzVMmvxwJuaq=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
TKRdIHXDQAGOYsjyhEFzVMmvxwJuaS=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
TKRdIHXDQAGOYsjyhEFzVMmvxwJuak=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
TKRdIHXDQAGOYsjyhEFzVMmvxwJuaP=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'}]
TKRdIHXDQAGOYsjyhEFzVMmvxwJuac=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'}]
TKRdIHXDQAGOYsjyhEFzVMmvxwJuaB=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
TKRdIHXDQAGOYsjyhEFzVMmvxwJuan={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
TKRdIHXDQAGOYsjyhEFzVMmvxwJuat =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
TKRdIHXDQAGOYsjyhEFzVMmvxwJuaL=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class TKRdIHXDQAGOYsjyhEFzVMmvxwJuao(TKRdIHXDQAGOYsjyhEFzVMmvxwJucN):
 def __init__(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJuaf,TKRdIHXDQAGOYsjyhEFzVMmvxwJuai,TKRdIHXDQAGOYsjyhEFzVMmvxwJuaU):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_url =TKRdIHXDQAGOYsjyhEFzVMmvxwJuaf
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle=TKRdIHXDQAGOYsjyhEFzVMmvxwJuai
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params =TKRdIHXDQAGOYsjyhEFzVMmvxwJuaU
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj =UwIylzbDaSQfvrtuWmEgCdVsHcBeFT() 
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,sting):
  try:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJual=xbmcgui.Dialog()
   TKRdIHXDQAGOYsjyhEFzVMmvxwJual.notification(__addonname__,sting)
  except:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
 def addon_log(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,string):
  try:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuaN=string.encode('utf-8','ignore')
  except:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuaN='addonException: addon_log'
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuaW=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,TKRdIHXDQAGOYsjyhEFzVMmvxwJuaN),level=TKRdIHXDQAGOYsjyhEFzVMmvxwJuaW)
 def get_keyboard_input(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuar=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
  kb=xbmc.Keyboard()
  kb.setHeading(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuar=kb.getText()
  return TKRdIHXDQAGOYsjyhEFzVMmvxwJuar
 def get_settings_account(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuae =__addon__.getSetting('id')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuaC =__addon__.getSetting('pw')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuoa =__addon__.getSetting('login_type')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuob=TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(__addon__.getSetting('selected_profile'))
  return(TKRdIHXDQAGOYsjyhEFzVMmvxwJuae,TKRdIHXDQAGOYsjyhEFzVMmvxwJuaC,TKRdIHXDQAGOYsjyhEFzVMmvxwJuoa,TKRdIHXDQAGOYsjyhEFzVMmvxwJuob)
 def get_settings_uhd(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  return TKRdIHXDQAGOYsjyhEFzVMmvxwJuce if __addon__.getSetting('active_uhd')=='true' else TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
 def get_settings_playback(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuoq={'active_uhd':TKRdIHXDQAGOYsjyhEFzVMmvxwJuce if __addon__.getSetting('active_uhd')=='true' else TKRdIHXDQAGOYsjyhEFzVMmvxwJucC,'streamFilename':TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.TV_STREAM_FILENAME,}
  return TKRdIHXDQAGOYsjyhEFzVMmvxwJuoq
 def get_settings_proxyport(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuoS =TKRdIHXDQAGOYsjyhEFzVMmvxwJuce if __addon__.getSetting('proxyYn')=='true' else TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuok=TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(__addon__.getSetting('proxyPort'))
  return TKRdIHXDQAGOYsjyhEFzVMmvxwJuoS,TKRdIHXDQAGOYsjyhEFzVMmvxwJuok
 def get_settings_totalsearch(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuoP =TKRdIHXDQAGOYsjyhEFzVMmvxwJuce if __addon__.getSetting('local_search')=='true' else TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuoc=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce if __addon__.getSetting('local_history')=='true' else TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuoB =TKRdIHXDQAGOYsjyhEFzVMmvxwJuce if __addon__.getSetting('total_search')=='true' else TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuon=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce if __addon__.getSetting('total_history')=='true' else TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuot=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce if __addon__.getSetting('menu_bookmark')=='true' else TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
  return(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoP,TKRdIHXDQAGOYsjyhEFzVMmvxwJuoc,TKRdIHXDQAGOYsjyhEFzVMmvxwJuoB,TKRdIHXDQAGOYsjyhEFzVMmvxwJuon,TKRdIHXDQAGOYsjyhEFzVMmvxwJuot)
 def get_settings_makebookmark(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  return TKRdIHXDQAGOYsjyhEFzVMmvxwJuce if __addon__.getSetting('make_bookmark')=='true' else TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
 def get_settings_direct_replay(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuoL=TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(__addon__.getSetting('direct_replay'))
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuoL==0:
   return TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
  else:
   return TKRdIHXDQAGOYsjyhEFzVMmvxwJuce
 def set_winEpisodeOrderby(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJuof):
  __addon__.setSetting('tving_orderby',TKRdIHXDQAGOYsjyhEFzVMmvxwJuof)
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuog=xbmcgui.Window(10000)
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuog.setProperty('TVING_M_ORDERBY',TKRdIHXDQAGOYsjyhEFzVMmvxwJuof)
 def get_winEpisodeOrderby(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuof=__addon__.getSetting('tving_orderby')
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuof in['',TKRdIHXDQAGOYsjyhEFzVMmvxwJucW]:TKRdIHXDQAGOYsjyhEFzVMmvxwJuof='desc'
  return TKRdIHXDQAGOYsjyhEFzVMmvxwJuof
 def add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,label,sublabel='',img='',infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params='',isLink=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC,ContextMenu=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuoi='%s?%s'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_url,urllib.parse.urlencode(params))
  if sublabel:TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU='%s < %s >'%(label,sublabel)
  else: TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU=label
  if not img:img='DefaultFolder.png'
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuop=xbmcgui.ListItem(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuBa(img)==TKRdIHXDQAGOYsjyhEFzVMmvxwJuBo:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuop.setArt(img)
  else:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuop.setArt({'thumb':img,'poster':img})
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.KodiVersion>=20:
   if infoLabels:TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.Set_InfoTag(TKRdIHXDQAGOYsjyhEFzVMmvxwJuop.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:TKRdIHXDQAGOYsjyhEFzVMmvxwJuop.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuop.setProperty('IsPlayable','true')
  if ContextMenu:TKRdIHXDQAGOYsjyhEFzVMmvxwJuop.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,TKRdIHXDQAGOYsjyhEFzVMmvxwJuoi,TKRdIHXDQAGOYsjyhEFzVMmvxwJuop,isFolder)
 def get_selQuality(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,etype):
  try:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuol='selected_quality'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoN=[1080,720,480,360]
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoW=TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(__addon__.getSetting(TKRdIHXDQAGOYsjyhEFzVMmvxwJuol))
   return TKRdIHXDQAGOYsjyhEFzVMmvxwJuoN[TKRdIHXDQAGOYsjyhEFzVMmvxwJuoW]
  except:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
  return 720 
 def Set_InfoTag(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,video_InfoTag:xbmc.InfoTagVideo,TKRdIHXDQAGOYsjyhEFzVMmvxwJubk):
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJuor,value in TKRdIHXDQAGOYsjyhEFzVMmvxwJubk.items():
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuan[TKRdIHXDQAGOYsjyhEFzVMmvxwJuor]['type']=='string':
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuBb(video_InfoTag,TKRdIHXDQAGOYsjyhEFzVMmvxwJuan[TKRdIHXDQAGOYsjyhEFzVMmvxwJuor]['func'])(value)
   elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuan[TKRdIHXDQAGOYsjyhEFzVMmvxwJuor]['type']=='int':
    if TKRdIHXDQAGOYsjyhEFzVMmvxwJuBa(value)==TKRdIHXDQAGOYsjyhEFzVMmvxwJucr:
     TKRdIHXDQAGOYsjyhEFzVMmvxwJuoe=TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(value)
    else:
     TKRdIHXDQAGOYsjyhEFzVMmvxwJuoe=0
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuBb(video_InfoTag,TKRdIHXDQAGOYsjyhEFzVMmvxwJuan[TKRdIHXDQAGOYsjyhEFzVMmvxwJuor]['func'])(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoe)
   elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuan[TKRdIHXDQAGOYsjyhEFzVMmvxwJuor]['type']=='actor':
    if value!=[]:
     TKRdIHXDQAGOYsjyhEFzVMmvxwJuBb(video_InfoTag,TKRdIHXDQAGOYsjyhEFzVMmvxwJuan[TKRdIHXDQAGOYsjyhEFzVMmvxwJuor]['func'])([xbmc.Actor(name)for name in value])
   elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuan[TKRdIHXDQAGOYsjyhEFzVMmvxwJuor]['type']=='list':
    if TKRdIHXDQAGOYsjyhEFzVMmvxwJuBa(value)==TKRdIHXDQAGOYsjyhEFzVMmvxwJuBq:
     TKRdIHXDQAGOYsjyhEFzVMmvxwJuBb(video_InfoTag,TKRdIHXDQAGOYsjyhEFzVMmvxwJuan[TKRdIHXDQAGOYsjyhEFzVMmvxwJuor]['func'])(value)
    else:
     TKRdIHXDQAGOYsjyhEFzVMmvxwJuBb(video_InfoTag,TKRdIHXDQAGOYsjyhEFzVMmvxwJuan[TKRdIHXDQAGOYsjyhEFzVMmvxwJuor]['func'])([value])
 def dp_Main_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  (TKRdIHXDQAGOYsjyhEFzVMmvxwJuoP,TKRdIHXDQAGOYsjyhEFzVMmvxwJuoc,TKRdIHXDQAGOYsjyhEFzVMmvxwJuoB,TKRdIHXDQAGOYsjyhEFzVMmvxwJuon,TKRdIHXDQAGOYsjyhEFzVMmvxwJuot)=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_totalsearch()
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC in TKRdIHXDQAGOYsjyhEFzVMmvxwJuab:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU=TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC.get('title')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuba=''
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC.get('mode')=='SEARCH_GROUP' and TKRdIHXDQAGOYsjyhEFzVMmvxwJuoP ==TKRdIHXDQAGOYsjyhEFzVMmvxwJucC:continue
   elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC.get('mode')=='SEARCH_HISTORY' and TKRdIHXDQAGOYsjyhEFzVMmvxwJuoc==TKRdIHXDQAGOYsjyhEFzVMmvxwJucC:continue
   elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC.get('mode')=='TOTAL_SEARCH' and TKRdIHXDQAGOYsjyhEFzVMmvxwJuoB ==TKRdIHXDQAGOYsjyhEFzVMmvxwJucC:continue
   elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC.get('mode')=='TOTAL_HISTORY' and TKRdIHXDQAGOYsjyhEFzVMmvxwJuon==TKRdIHXDQAGOYsjyhEFzVMmvxwJucC:continue
   elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC.get('mode')=='MENU_BOOKMARK' and TKRdIHXDQAGOYsjyhEFzVMmvxwJuot==TKRdIHXDQAGOYsjyhEFzVMmvxwJucC:continue
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC.get('mode'),'stype':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC.get('stype'),'orderby':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC.get('orderby'),'ordernm':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC.get('ordernm'),'page':'1'}
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubq=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubS =TKRdIHXDQAGOYsjyhEFzVMmvxwJuce
   else:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubq=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubS =TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubk={'title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'plot':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU}
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC.get('mode')=='XXX':TKRdIHXDQAGOYsjyhEFzVMmvxwJubk=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
   if 'icon' in TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC:TKRdIHXDQAGOYsjyhEFzVMmvxwJuba=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',TKRdIHXDQAGOYsjyhEFzVMmvxwJuoC.get('icon')) 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel='',img=TKRdIHXDQAGOYsjyhEFzVMmvxwJuba,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJubk,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJubq,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo,isLink=TKRdIHXDQAGOYsjyhEFzVMmvxwJubS)
  xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle)
 def login_main(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  (TKRdIHXDQAGOYsjyhEFzVMmvxwJubc,TKRdIHXDQAGOYsjyhEFzVMmvxwJubB,TKRdIHXDQAGOYsjyhEFzVMmvxwJubn,TKRdIHXDQAGOYsjyhEFzVMmvxwJubt)=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_account()
  if not(TKRdIHXDQAGOYsjyhEFzVMmvxwJubc and TKRdIHXDQAGOYsjyhEFzVMmvxwJubB):
   TKRdIHXDQAGOYsjyhEFzVMmvxwJual=xbmcgui.Dialog()
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubL=TKRdIHXDQAGOYsjyhEFzVMmvxwJual.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJubL==TKRdIHXDQAGOYsjyhEFzVMmvxwJuce:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubg=0
   while TKRdIHXDQAGOYsjyhEFzVMmvxwJuce:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubg+=1
    time.sleep(0.05)
    if TKRdIHXDQAGOYsjyhEFzVMmvxwJubg>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubf=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.GetCredential2(TKRdIHXDQAGOYsjyhEFzVMmvxwJubc,TKRdIHXDQAGOYsjyhEFzVMmvxwJubB,TKRdIHXDQAGOYsjyhEFzVMmvxwJubn,TKRdIHXDQAGOYsjyhEFzVMmvxwJubt)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubf:TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubf==TKRdIHXDQAGOYsjyhEFzVMmvxwJucC:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubi=TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('stype')
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubi=='live':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubU=TKRdIHXDQAGOYsjyhEFzVMmvxwJuaq
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJubi=='vod':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubU=TKRdIHXDQAGOYsjyhEFzVMmvxwJuaP
  else:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubU=TKRdIHXDQAGOYsjyhEFzVMmvxwJuac
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJubp in TKRdIHXDQAGOYsjyhEFzVMmvxwJubU:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU=TKRdIHXDQAGOYsjyhEFzVMmvxwJubp.get('title')
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('ordernm')!='-':
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU+='  ('+TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('ordernm')+')'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':TKRdIHXDQAGOYsjyhEFzVMmvxwJubp.get('mode'),'stype':TKRdIHXDQAGOYsjyhEFzVMmvxwJubp.get('stype'),'orderby':TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('orderby'),'ordernm':TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('ordernm'),'page':'1'}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel='',img='',infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuBS(TKRdIHXDQAGOYsjyhEFzVMmvxwJubU)>0:xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle)
 def dp_SubTitle_Group(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl): 
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJubp in TKRdIHXDQAGOYsjyhEFzVMmvxwJuaB:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU=TKRdIHXDQAGOYsjyhEFzVMmvxwJubp.get('title')
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('ordernm')!='-':
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU+='  ('+TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('ordernm')+')'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':TKRdIHXDQAGOYsjyhEFzVMmvxwJubp.get('mode'),'genreCode':TKRdIHXDQAGOYsjyhEFzVMmvxwJubp.get('genreCode'),'stype':TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('stype'),'orderby':TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('orderby'),'page':'1'}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel='',img='',infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuBS(TKRdIHXDQAGOYsjyhEFzVMmvxwJuaB)>0:xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle)
 def dp_LiveChannel_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubi =TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('stype')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubN =TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('page'))
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubW,TKRdIHXDQAGOYsjyhEFzVMmvxwJubr=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.GetLiveChannelList(TKRdIHXDQAGOYsjyhEFzVMmvxwJubi,TKRdIHXDQAGOYsjyhEFzVMmvxwJubN)
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJube in TKRdIHXDQAGOYsjyhEFzVMmvxwJubW:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('title')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubP =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('channel')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubC =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('thumbnail')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('synopsis')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqo =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('channelepg')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqb =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('cast')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqS =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('director')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqk =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('info_genre')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqP =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('year')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqc =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('mpaa')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqB =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('premiered')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={'mediatype':'episode','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'studio':TKRdIHXDQAGOYsjyhEFzVMmvxwJubP,'cast':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqb,'director':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqS,'genre':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqk,'plot':'%s\n%s\n%s\n\n%s'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJubP,TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,TKRdIHXDQAGOYsjyhEFzVMmvxwJuqo,TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa),'year':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqP,'mpaa':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqc,'premiered':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqB}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'LIVE','mediacode':TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('mediacode'),'stype':TKRdIHXDQAGOYsjyhEFzVMmvxwJubi}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJubP,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,img=TKRdIHXDQAGOYsjyhEFzVMmvxwJubC,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubr:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['mode']='CHANNEL' 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['stype']=TKRdIHXDQAGOYsjyhEFzVMmvxwJubi 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['page']=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU='[B]%s >>[/B]'%'다음 페이지'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuba=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt,img=TKRdIHXDQAGOYsjyhEFzVMmvxwJuba,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuBS(TKRdIHXDQAGOYsjyhEFzVMmvxwJubW)>0:xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,cacheToDisc=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC)
 def dp_Program_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuqL =TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('stype')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuof =TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('orderby')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubN =TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('page'))
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuqg=TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('genreCode')
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuqg==TKRdIHXDQAGOYsjyhEFzVMmvxwJucW:TKRdIHXDQAGOYsjyhEFzVMmvxwJuqg='all'
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuqf,TKRdIHXDQAGOYsjyhEFzVMmvxwJubr=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.GetProgramList(TKRdIHXDQAGOYsjyhEFzVMmvxwJuqL,TKRdIHXDQAGOYsjyhEFzVMmvxwJuof,TKRdIHXDQAGOYsjyhEFzVMmvxwJubN,TKRdIHXDQAGOYsjyhEFzVMmvxwJuqg)
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi in TKRdIHXDQAGOYsjyhEFzVMmvxwJuqf:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('title')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubC =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('thumbnail')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('synopsis')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqU =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('channel')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqb =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('cast')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqS =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('director')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqk=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('info_genre')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqP =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('year')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqB =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('premiered')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqc =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('mpaa')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={'mediatype':'tvshow','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'studio':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqU,'cast':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqb,'director':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqS,'genre':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqk,'year':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqP,'premiered':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqB,'mpaa':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqc,'plot':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'EPISODE','programcode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('program'),'page':'1'}
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_makebookmark():
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqp={'videoid':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('program'),'vidtype':'tvshow','vtitle':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'vsubtitle':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqU,}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuql=json.dumps(TKRdIHXDQAGOYsjyhEFzVMmvxwJuqp)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuql=urllib.parse.quote(TKRdIHXDQAGOYsjyhEFzVMmvxwJuql)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqN='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJuql)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW=[('(통합) 찜 영상에 추가',TKRdIHXDQAGOYsjyhEFzVMmvxwJuqN)]
   else:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqU,img=TKRdIHXDQAGOYsjyhEFzVMmvxwJubC,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo,ContextMenu=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubr:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['mode'] ='PROGRAM' 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['stype'] =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqL
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['orderby'] =TKRdIHXDQAGOYsjyhEFzVMmvxwJuof
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['page'] =TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['genreCode']=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqg 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU='[B]%s >>[/B]'%'다음 페이지'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuba=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt,img=TKRdIHXDQAGOYsjyhEFzVMmvxwJuba,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  xbmcplugin.setContent(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,cacheToDisc=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC)
 def dp_4K_Program_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubN =TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('page'))
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuqf,TKRdIHXDQAGOYsjyhEFzVMmvxwJubr=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Get_UHD_ProgramList(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN)
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi in TKRdIHXDQAGOYsjyhEFzVMmvxwJuqf:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('title')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubC =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('thumbnail')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('synopsis')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqU =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('channel')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqb =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('cast')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqS =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('director')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqk=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('info_genre')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqP =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('year')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqB =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('premiered')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqc =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('mpaa')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={'mediatype':'tvshow','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'studio':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqU,'cast':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqb,'director':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqS,'genre':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqk,'year':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqP,'premiered':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqB,'mpaa':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqc,'plot':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'EPISODE','programcode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('program'),'page':'1'}
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_makebookmark():
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqp={'videoid':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('program'),'vidtype':'tvshow','vtitle':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'vsubtitle':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqU,}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuql=json.dumps(TKRdIHXDQAGOYsjyhEFzVMmvxwJuqp)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuql=urllib.parse.quote(TKRdIHXDQAGOYsjyhEFzVMmvxwJuql)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqN='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJuql)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW=[('(통합) 찜 영상에 추가',TKRdIHXDQAGOYsjyhEFzVMmvxwJuqN)]
   else:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqU,img=TKRdIHXDQAGOYsjyhEFzVMmvxwJubC,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo,ContextMenu=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubr:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['mode'] ='4K_PROGRAM' 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['page'] =TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU='[B]%s >>[/B]'%'다음 페이지'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuba=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt,img=TKRdIHXDQAGOYsjyhEFzVMmvxwJuba,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  xbmcplugin.setContent(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,cacheToDisc=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC)
 def dp_Ori_Program_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubN =TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('page'))
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuqf,TKRdIHXDQAGOYsjyhEFzVMmvxwJubr=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Get_Origianl_ProgramList(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN)
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi in TKRdIHXDQAGOYsjyhEFzVMmvxwJuqf:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('title')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubC =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('thumbnail')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqe =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('vod_type')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqC =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqi.get('vod_code')
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuqe=='vod':
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={'mediatype':'tvshow','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'EPISODE','programcode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqC,'page':'1',}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubq=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce
   else:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={'mediatype':'movie','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'plot':'movie',}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'MOVIE','mediacode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqC,'stype':'movie','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'thumbnail':TKRdIHXDQAGOYsjyhEFzVMmvxwJubC,}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubq=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,img=TKRdIHXDQAGOYsjyhEFzVMmvxwJubC,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJubq,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo,ContextMenu=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubr:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['mode'] ='ORI_PROGRAM' 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['page'] =TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU='[B]%s >>[/B]'%'다음 페이지'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuba=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt,img=TKRdIHXDQAGOYsjyhEFzVMmvxwJuba,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  xbmcplugin.setContent(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,cacheToDisc=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC)
 def dp_Episode_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSa=TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('programcode')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubN =TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('page'))
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSo,TKRdIHXDQAGOYsjyhEFzVMmvxwJubr,TKRdIHXDQAGOYsjyhEFzVMmvxwJuSb=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.GetEpisodeList(TKRdIHXDQAGOYsjyhEFzVMmvxwJuSa,TKRdIHXDQAGOYsjyhEFzVMmvxwJubN,orderby=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_winEpisodeOrderby())
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJuSq in TKRdIHXDQAGOYsjyhEFzVMmvxwJuSo:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSq.get('title')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSq.get('subtitle')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubC =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSq.get('thumbnail')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSq.get('synopsis')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSk=TKRdIHXDQAGOYsjyhEFzVMmvxwJuSq.get('info_title')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSP =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSq.get('aired')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSc =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSq.get('studio')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSB =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSq.get('frequency')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={'mediatype':'episode','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSk,'aired':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSP,'studio':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSc,'episode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSB,'plot':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'VOD','mediacode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSq.get('episode'),'stype':'vod','programcode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSa,'title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'thumbnail':TKRdIHXDQAGOYsjyhEFzVMmvxwJubC}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt,img=TKRdIHXDQAGOYsjyhEFzVMmvxwJubC,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubN==1:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={'plot':'정렬순서를 변경합니다.'}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['mode'] ='ORDER_BY' 
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_winEpisodeOrderby()=='desc':
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU='정렬순서변경 : 최신화부터 -> 1회부터'
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['orderby']='asc'
   else:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU='정렬순서변경 : 1회부터 -> 최신화부터'
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['orderby']='desc'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuba=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel='',img=TKRdIHXDQAGOYsjyhEFzVMmvxwJuba,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo,isLink=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubr:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['mode'] ='EPISODE' 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['programcode']=TKRdIHXDQAGOYsjyhEFzVMmvxwJuSa
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['page'] =TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU='[B]%s >>[/B]'%'다음 페이지'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuba=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt,img=TKRdIHXDQAGOYsjyhEFzVMmvxwJuba,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  xbmcplugin.setContent(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,'episodes')
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuBS(TKRdIHXDQAGOYsjyhEFzVMmvxwJuSo)>0:xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,cacheToDisc=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce)
 def dp_setEpOrderby(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuof =TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('orderby')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.set_winEpisodeOrderby(TKRdIHXDQAGOYsjyhEFzVMmvxwJuof)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuqL =TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('stype')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuof =TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('orderby')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubN=TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('page'))
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSn,TKRdIHXDQAGOYsjyhEFzVMmvxwJubr=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.GetMovieList(TKRdIHXDQAGOYsjyhEFzVMmvxwJuqL,TKRdIHXDQAGOYsjyhEFzVMmvxwJuof,TKRdIHXDQAGOYsjyhEFzVMmvxwJubN)
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt in TKRdIHXDQAGOYsjyhEFzVMmvxwJuSn:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('title')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubC =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('thumbnail')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('synopsis')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSk =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('info_title')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqP =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('year')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqb =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('cast')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqS =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('director')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqk =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('info_genre')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSL =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('duration')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqB =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('premiered')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSc =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('studio')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqc =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('mpaa')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={'mediatype':'movie','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSk,'year':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqP,'cast':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqb,'director':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqS,'genre':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqk,'duration':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSL,'premiered':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqB,'studio':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSc,'mpaa':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqc,'plot':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'MOVIE','mediacode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('moviecode'),'stype':'movie','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'thumbnail':TKRdIHXDQAGOYsjyhEFzVMmvxwJubC}
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_makebookmark():
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqp={'videoid':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('moviecode'),'vidtype':'movie','vtitle':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSk,'vsubtitle':'',}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuql=json.dumps(TKRdIHXDQAGOYsjyhEFzVMmvxwJuqp)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuql=urllib.parse.quote(TKRdIHXDQAGOYsjyhEFzVMmvxwJuql)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqN='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJuql)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW=[('(통합) 찜 영상에 추가',TKRdIHXDQAGOYsjyhEFzVMmvxwJuqN)]
   else:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel='',img=TKRdIHXDQAGOYsjyhEFzVMmvxwJubC,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo,ContextMenu=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubr:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['mode'] ='MOVIE_SUB' 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['orderby']=TKRdIHXDQAGOYsjyhEFzVMmvxwJuof
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['stype'] =TKRdIHXDQAGOYsjyhEFzVMmvxwJuqL
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['page'] =TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU='[B]%s >>[/B]'%'다음 페이지'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuba=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt,img=TKRdIHXDQAGOYsjyhEFzVMmvxwJuba,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  xbmcplugin.setContent(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,'movies')
  xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,cacheToDisc=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC)
 def dp_4K_Movie_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubN=TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('page'))
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSn,TKRdIHXDQAGOYsjyhEFzVMmvxwJubr=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Get_UHD_MovieList(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN)
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt in TKRdIHXDQAGOYsjyhEFzVMmvxwJuSn:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('title')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubC =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('thumbnail')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('synopsis')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSk =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('info_title')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqP =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('year')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqb =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('cast')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqS =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('director')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqk =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('info_genre')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSL =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('duration')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqB =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('premiered')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSc =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('studio')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqc =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('mpaa')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={'mediatype':'movie','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSk,'year':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqP,'cast':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqb,'director':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqS,'genre':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqk,'duration':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSL,'premiered':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqB,'studio':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSc,'mpaa':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqc,'plot':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'MOVIE','mediacode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('moviecode'),'stype':'movie','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'thumbnail':TKRdIHXDQAGOYsjyhEFzVMmvxwJubC}
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_makebookmark():
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqp={'videoid':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSt.get('moviecode'),'vidtype':'movie','vtitle':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSk,'vsubtitle':'',}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuql=json.dumps(TKRdIHXDQAGOYsjyhEFzVMmvxwJuqp)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuql=urllib.parse.quote(TKRdIHXDQAGOYsjyhEFzVMmvxwJuql)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqN='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJuql)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW=[('(통합) 찜 영상에 추가',TKRdIHXDQAGOYsjyhEFzVMmvxwJuqN)]
   else:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel='',img=TKRdIHXDQAGOYsjyhEFzVMmvxwJubC,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo,ContextMenu=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubr:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['mode'] ='4K_MOVIE' 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['page'] =TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU='[B]%s >>[/B]'%'다음 페이지'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuba=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt,img=TKRdIHXDQAGOYsjyhEFzVMmvxwJuba,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  xbmcplugin.setContent(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,'movies')
  xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,cacheToDisc=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC)
 def dp_Set_Bookmark(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSg=urllib.parse.unquote(TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('bm_param'))
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSg=json.loads(TKRdIHXDQAGOYsjyhEFzVMmvxwJuSg)
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSf =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSg.get('videoid')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSi =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSg.get('vidtype')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSU =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSg.get('vtitle')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSp =TKRdIHXDQAGOYsjyhEFzVMmvxwJuSg.get('vsubtitle')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJual=xbmcgui.Dialog()
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubL=TKRdIHXDQAGOYsjyhEFzVMmvxwJual.yesno(__language__(30913).encode('utf8'),TKRdIHXDQAGOYsjyhEFzVMmvxwJuSU+' \n\n'+__language__(30914))
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubL==TKRdIHXDQAGOYsjyhEFzVMmvxwJucC:return
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSl=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.GetBookmarkInfo(TKRdIHXDQAGOYsjyhEFzVMmvxwJuSf,TKRdIHXDQAGOYsjyhEFzVMmvxwJuSi)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuSp!='':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSl['saveinfo']['subtitle']=TKRdIHXDQAGOYsjyhEFzVMmvxwJuSp 
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuSi=='tvshow':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSl['saveinfo']['infoLabels']['studio']=TKRdIHXDQAGOYsjyhEFzVMmvxwJuSp 
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSN=json.dumps(TKRdIHXDQAGOYsjyhEFzVMmvxwJuSl)
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSN=urllib.parse.quote(TKRdIHXDQAGOYsjyhEFzVMmvxwJuSN)
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuqN ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJuSN)
  xbmc.executebuiltin(TKRdIHXDQAGOYsjyhEFzVMmvxwJuqN)
 def dp_Search_Group(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  if 'search_key' in TKRdIHXDQAGOYsjyhEFzVMmvxwJubl:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW=TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('search_key')
  else:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW:
    return
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJubp in TKRdIHXDQAGOYsjyhEFzVMmvxwJuak:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr =TKRdIHXDQAGOYsjyhEFzVMmvxwJubp.get('mode')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubi=TKRdIHXDQAGOYsjyhEFzVMmvxwJubp.get('stype')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU=TKRdIHXDQAGOYsjyhEFzVMmvxwJubp.get('title')
   (TKRdIHXDQAGOYsjyhEFzVMmvxwJuSe,TKRdIHXDQAGOYsjyhEFzVMmvxwJubr)=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.GetSearchList(TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW,1,TKRdIHXDQAGOYsjyhEFzVMmvxwJubi)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubk={'plot':'검색어 : '+TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW+'\n\n'+TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.Search_FreeList(TKRdIHXDQAGOYsjyhEFzVMmvxwJuSe)}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr,'stype':TKRdIHXDQAGOYsjyhEFzVMmvxwJubi,'search_key':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW,'page':'1',}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel='',img='',infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJubk,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuBS(TKRdIHXDQAGOYsjyhEFzVMmvxwJuak)>0:xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,cacheToDisc=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce)
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.Save_Searched_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW)
 def Search_FreeList(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJukB):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSC=''
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuka=7
  try:
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuBS(TKRdIHXDQAGOYsjyhEFzVMmvxwJukB)==0:return '검색결과 없음'
   for i in TKRdIHXDQAGOYsjyhEFzVMmvxwJuBP(TKRdIHXDQAGOYsjyhEFzVMmvxwJuBS(TKRdIHXDQAGOYsjyhEFzVMmvxwJukB)):
    if i>=TKRdIHXDQAGOYsjyhEFzVMmvxwJuka:
     TKRdIHXDQAGOYsjyhEFzVMmvxwJuSC=TKRdIHXDQAGOYsjyhEFzVMmvxwJuSC+'...'
     break
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuSC=TKRdIHXDQAGOYsjyhEFzVMmvxwJuSC+TKRdIHXDQAGOYsjyhEFzVMmvxwJukB[i]['title']+'\n'
  except:
   return ''
  return TKRdIHXDQAGOYsjyhEFzVMmvxwJuSC
 def dp_Search_History(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuko=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.Load_List_File('search')
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJukb in TKRdIHXDQAGOYsjyhEFzVMmvxwJuko:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukq=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBo(urllib.parse.parse_qsl(TKRdIHXDQAGOYsjyhEFzVMmvxwJukb))
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukS=TKRdIHXDQAGOYsjyhEFzVMmvxwJukq.get('skey').strip()
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'SEARCH_GROUP','search_key':TKRdIHXDQAGOYsjyhEFzVMmvxwJukS,}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukP={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':TKRdIHXDQAGOYsjyhEFzVMmvxwJukS,'vType':'-',}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukc=urllib.parse.urlencode(TKRdIHXDQAGOYsjyhEFzVMmvxwJukP)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW=[('선택된 검색어 ( %s ) 삭제'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJukS),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJukc))]
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJukS,sublabel='',img=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo,ContextMenu=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW)
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={'plot':'검색목록 전체를 삭제합니다.'}
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuba=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel='',img=TKRdIHXDQAGOYsjyhEFzVMmvxwJuba,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo,isLink=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce)
  xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,cacheToDisc=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC)
 def dp_Search_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubN =TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('page'))
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubi =TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('stype')
  if 'search_key' in TKRdIHXDQAGOYsjyhEFzVMmvxwJubl:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW=TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('search_key')
  else:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW:
    xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle)
    return
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSe,TKRdIHXDQAGOYsjyhEFzVMmvxwJubr=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.GetSearchList(TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW,TKRdIHXDQAGOYsjyhEFzVMmvxwJubN,TKRdIHXDQAGOYsjyhEFzVMmvxwJubi)
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJukB in TKRdIHXDQAGOYsjyhEFzVMmvxwJuSe:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU =TKRdIHXDQAGOYsjyhEFzVMmvxwJukB.get('title')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubC =TKRdIHXDQAGOYsjyhEFzVMmvxwJukB.get('thumbnail')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa =TKRdIHXDQAGOYsjyhEFzVMmvxwJukB.get('synopsis')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukn =TKRdIHXDQAGOYsjyhEFzVMmvxwJukB.get('program')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqb =TKRdIHXDQAGOYsjyhEFzVMmvxwJukB.get('cast')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqS =TKRdIHXDQAGOYsjyhEFzVMmvxwJukB.get('director')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqk=TKRdIHXDQAGOYsjyhEFzVMmvxwJukB.get('info_genre')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSL =TKRdIHXDQAGOYsjyhEFzVMmvxwJukB.get('duration')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqc =TKRdIHXDQAGOYsjyhEFzVMmvxwJukB.get('mpaa')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqP =TKRdIHXDQAGOYsjyhEFzVMmvxwJukB.get('year')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuSP =TKRdIHXDQAGOYsjyhEFzVMmvxwJukB.get('aired')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={'mediatype':'tvshow' if TKRdIHXDQAGOYsjyhEFzVMmvxwJubi=='vod' else 'movie','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'cast':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqb,'director':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqS,'genre':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqk,'duration':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSL,'mpaa':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqc,'year':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqP,'aired':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSP,'plot':'%s\n\n%s'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,TKRdIHXDQAGOYsjyhEFzVMmvxwJuqa)}
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJubi=='vod':
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuSf=TKRdIHXDQAGOYsjyhEFzVMmvxwJukB.get('program')
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuSi='tvshow'
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'EPISODE','programcode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSf,'page':'1',}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubq=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce
   else:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuSf=TKRdIHXDQAGOYsjyhEFzVMmvxwJukB.get('movie')
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuSi='movie'
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'MOVIE','mediacode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSf,'stype':'movie','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'thumbnail':TKRdIHXDQAGOYsjyhEFzVMmvxwJubC,}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubq=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_makebookmark():
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqp={'videoid':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSf,'vidtype':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSi,'vtitle':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'vsubtitle':'',}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuql=json.dumps(TKRdIHXDQAGOYsjyhEFzVMmvxwJuqp)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuql=urllib.parse.quote(TKRdIHXDQAGOYsjyhEFzVMmvxwJuql)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqN='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJuql)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW=[('(통합) 찜 영상에 추가',TKRdIHXDQAGOYsjyhEFzVMmvxwJuqN)]
   else:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel='',img=TKRdIHXDQAGOYsjyhEFzVMmvxwJubC,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJubq,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo,isLink=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC,ContextMenu=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubr:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['mode'] ='SEARCH' 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['search_key']=TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo['page'] =TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU='[B]%s >>[/B]'%'다음 페이지'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJubN+1)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuba=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt,img=TKRdIHXDQAGOYsjyhEFzVMmvxwJuba,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubi=='movie':xbmcplugin.setContent(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,'movies')
  else:xbmcplugin.setContent(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,cacheToDisc=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC)
 def dp_History_Remove(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJukt=TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('delType')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJukL =TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('sKey')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJukg =TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('vType')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJual=xbmcgui.Dialog()
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJukt=='SEARCH_ALL':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubL=TKRdIHXDQAGOYsjyhEFzVMmvxwJual.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJukt=='SEARCH_ONE':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubL=TKRdIHXDQAGOYsjyhEFzVMmvxwJual.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJukt=='WATCH_ALL':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubL=TKRdIHXDQAGOYsjyhEFzVMmvxwJual.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJukt=='WATCH_ONE':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubL=TKRdIHXDQAGOYsjyhEFzVMmvxwJual.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubL==TKRdIHXDQAGOYsjyhEFzVMmvxwJucC:sys.exit()
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJukt=='SEARCH_ALL':
   if os.path.isfile(TKRdIHXDQAGOYsjyhEFzVMmvxwJuaL):os.remove(TKRdIHXDQAGOYsjyhEFzVMmvxwJuaL)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJukt=='SEARCH_ONE':
   try:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJukf=TKRdIHXDQAGOYsjyhEFzVMmvxwJuaL
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuki=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.Load_List_File('search') 
    fp=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBc(TKRdIHXDQAGOYsjyhEFzVMmvxwJukf,'w',-1,'utf-8')
    for TKRdIHXDQAGOYsjyhEFzVMmvxwJukU in TKRdIHXDQAGOYsjyhEFzVMmvxwJuki:
     TKRdIHXDQAGOYsjyhEFzVMmvxwJukp=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBo(urllib.parse.parse_qsl(TKRdIHXDQAGOYsjyhEFzVMmvxwJukU))
     TKRdIHXDQAGOYsjyhEFzVMmvxwJukl=TKRdIHXDQAGOYsjyhEFzVMmvxwJukp.get('skey').strip()
     if TKRdIHXDQAGOYsjyhEFzVMmvxwJukL!=TKRdIHXDQAGOYsjyhEFzVMmvxwJukl:
      fp.write(TKRdIHXDQAGOYsjyhEFzVMmvxwJukU)
    fp.close()
   except:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJukt=='WATCH_ALL':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TKRdIHXDQAGOYsjyhEFzVMmvxwJukg))
   if os.path.isfile(TKRdIHXDQAGOYsjyhEFzVMmvxwJukf):os.remove(TKRdIHXDQAGOYsjyhEFzVMmvxwJukf)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJukt=='WATCH_ONE':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TKRdIHXDQAGOYsjyhEFzVMmvxwJukg))
   try:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuki=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.Load_List_File(TKRdIHXDQAGOYsjyhEFzVMmvxwJukg) 
    fp=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBc(TKRdIHXDQAGOYsjyhEFzVMmvxwJukf,'w',-1,'utf-8')
    for TKRdIHXDQAGOYsjyhEFzVMmvxwJukU in TKRdIHXDQAGOYsjyhEFzVMmvxwJuki:
     TKRdIHXDQAGOYsjyhEFzVMmvxwJukp=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBo(urllib.parse.parse_qsl(TKRdIHXDQAGOYsjyhEFzVMmvxwJukU))
     TKRdIHXDQAGOYsjyhEFzVMmvxwJukl=TKRdIHXDQAGOYsjyhEFzVMmvxwJukp.get('code').strip()
     if TKRdIHXDQAGOYsjyhEFzVMmvxwJukL!=TKRdIHXDQAGOYsjyhEFzVMmvxwJukl:
      fp.write(TKRdIHXDQAGOYsjyhEFzVMmvxwJukU)
    fp.close()
   except:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubi): 
  try:
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJubi=='search':
    TKRdIHXDQAGOYsjyhEFzVMmvxwJukf=TKRdIHXDQAGOYsjyhEFzVMmvxwJuaL
   elif TKRdIHXDQAGOYsjyhEFzVMmvxwJubi in['vod','movie']:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJukf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TKRdIHXDQAGOYsjyhEFzVMmvxwJubi))
   else:
    return[]
   fp=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBc(TKRdIHXDQAGOYsjyhEFzVMmvxwJukf,'r',-1,'utf-8')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukN=fp.readlines()
   fp.close()
  except:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukN=[]
  return TKRdIHXDQAGOYsjyhEFzVMmvxwJukN
 def Save_Watched_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubi,TKRdIHXDQAGOYsjyhEFzVMmvxwJuaU):
  try:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukW=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%TKRdIHXDQAGOYsjyhEFzVMmvxwJubi))
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuki=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.Load_List_File(TKRdIHXDQAGOYsjyhEFzVMmvxwJubi) 
   fp=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBc(TKRdIHXDQAGOYsjyhEFzVMmvxwJukW,'w',-1,'utf-8')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukr=urllib.parse.urlencode(TKRdIHXDQAGOYsjyhEFzVMmvxwJuaU)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukr=TKRdIHXDQAGOYsjyhEFzVMmvxwJukr+'\n'
   fp.write(TKRdIHXDQAGOYsjyhEFzVMmvxwJukr)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuke=0
   for TKRdIHXDQAGOYsjyhEFzVMmvxwJukU in TKRdIHXDQAGOYsjyhEFzVMmvxwJuki:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJukp=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBo(urllib.parse.parse_qsl(TKRdIHXDQAGOYsjyhEFzVMmvxwJukU))
    TKRdIHXDQAGOYsjyhEFzVMmvxwJukC=TKRdIHXDQAGOYsjyhEFzVMmvxwJuaU.get('code').strip()
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuPa=TKRdIHXDQAGOYsjyhEFzVMmvxwJukp.get('code').strip()
    if TKRdIHXDQAGOYsjyhEFzVMmvxwJubi=='vod' and TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_direct_replay()==TKRdIHXDQAGOYsjyhEFzVMmvxwJuce:
     TKRdIHXDQAGOYsjyhEFzVMmvxwJukC=TKRdIHXDQAGOYsjyhEFzVMmvxwJuaU.get('videoid').strip()
     TKRdIHXDQAGOYsjyhEFzVMmvxwJuPa=TKRdIHXDQAGOYsjyhEFzVMmvxwJukp.get('videoid').strip()if TKRdIHXDQAGOYsjyhEFzVMmvxwJuPa!=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW else '-'
    if TKRdIHXDQAGOYsjyhEFzVMmvxwJukC!=TKRdIHXDQAGOYsjyhEFzVMmvxwJuPa:
     fp.write(TKRdIHXDQAGOYsjyhEFzVMmvxwJukU)
     TKRdIHXDQAGOYsjyhEFzVMmvxwJuke+=1
     if TKRdIHXDQAGOYsjyhEFzVMmvxwJuke>=50:break
   fp.close()
  except:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
 def dp_Watch_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubi =TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('stype')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuoL=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_direct_replay()
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubi=='-':
   for TKRdIHXDQAGOYsjyhEFzVMmvxwJubp in TKRdIHXDQAGOYsjyhEFzVMmvxwJuaS:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU=TKRdIHXDQAGOYsjyhEFzVMmvxwJubp.get('title')
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':TKRdIHXDQAGOYsjyhEFzVMmvxwJubp.get('mode'),'stype':TKRdIHXDQAGOYsjyhEFzVMmvxwJubp.get('stype')}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel='',img='',infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJucW,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuBS(TKRdIHXDQAGOYsjyhEFzVMmvxwJuaS)>0:xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle)
  else:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPo=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.Load_List_File(TKRdIHXDQAGOYsjyhEFzVMmvxwJubi)
   for TKRdIHXDQAGOYsjyhEFzVMmvxwJuPb in TKRdIHXDQAGOYsjyhEFzVMmvxwJuPo:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJukq=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBo(urllib.parse.parse_qsl(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPb))
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuPq =TKRdIHXDQAGOYsjyhEFzVMmvxwJukq.get('code').strip()
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU =TKRdIHXDQAGOYsjyhEFzVMmvxwJukq.get('title').strip()
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubC=TKRdIHXDQAGOYsjyhEFzVMmvxwJukq.get('img').strip()
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuSf =TKRdIHXDQAGOYsjyhEFzVMmvxwJukq.get('videoid').strip()
    try:
     TKRdIHXDQAGOYsjyhEFzVMmvxwJubC=TKRdIHXDQAGOYsjyhEFzVMmvxwJubC.replace('\'','\"')
     TKRdIHXDQAGOYsjyhEFzVMmvxwJubC=json.loads(TKRdIHXDQAGOYsjyhEFzVMmvxwJubC)
    except:
     TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn['plot']=TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU
    if TKRdIHXDQAGOYsjyhEFzVMmvxwJubi=='vod':
     if TKRdIHXDQAGOYsjyhEFzVMmvxwJuoL==TKRdIHXDQAGOYsjyhEFzVMmvxwJucC or TKRdIHXDQAGOYsjyhEFzVMmvxwJuSf==TKRdIHXDQAGOYsjyhEFzVMmvxwJucW:
      TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn['mediatype']='tvshow'
      TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'EPISODE','programcode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuPq,'page':'1'}
      TKRdIHXDQAGOYsjyhEFzVMmvxwJubq=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce
     else:
      TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn['mediatype']='episode'
      TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'VOD','mediacode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSf,'stype':'vod','programcode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuPq,'title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'thumbnail':TKRdIHXDQAGOYsjyhEFzVMmvxwJubC}
      TKRdIHXDQAGOYsjyhEFzVMmvxwJubq=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
    else:
     TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn['mediatype']='movie'
     TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'MOVIE','mediacode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuPq,'stype':'movie','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'thumbnail':TKRdIHXDQAGOYsjyhEFzVMmvxwJubC}
     TKRdIHXDQAGOYsjyhEFzVMmvxwJubq=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
    TKRdIHXDQAGOYsjyhEFzVMmvxwJukP={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':TKRdIHXDQAGOYsjyhEFzVMmvxwJuPq,'vType':TKRdIHXDQAGOYsjyhEFzVMmvxwJubi,}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJukc=urllib.parse.urlencode(TKRdIHXDQAGOYsjyhEFzVMmvxwJukP)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW=[('선택된 시청이력 ( %s ) 삭제'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJukc))]
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel='',img=TKRdIHXDQAGOYsjyhEFzVMmvxwJubC,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJubq,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo,ContextMenu=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqW)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={'plot':'시청목록을 삭제합니다.'}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':TKRdIHXDQAGOYsjyhEFzVMmvxwJubi,}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuba=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel='',img=TKRdIHXDQAGOYsjyhEFzVMmvxwJuba,infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo,isLink=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce)
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJubi=='movie':xbmcplugin.setContent(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,'movies')
   else:xbmcplugin.setContent(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,cacheToDisc=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC)
 def Save_Searched_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW):
  try:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPS=TKRdIHXDQAGOYsjyhEFzVMmvxwJuaL
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuki=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.Load_List_File('search') 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPk={'skey':TKRdIHXDQAGOYsjyhEFzVMmvxwJuSW.strip()}
   fp=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBc(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPS,'w',-1,'utf-8')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukr=urllib.parse.urlencode(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPk)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJukr=TKRdIHXDQAGOYsjyhEFzVMmvxwJukr+'\n'
   fp.write(TKRdIHXDQAGOYsjyhEFzVMmvxwJukr)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuke=0
   for TKRdIHXDQAGOYsjyhEFzVMmvxwJukU in TKRdIHXDQAGOYsjyhEFzVMmvxwJuki:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJukp=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBo(urllib.parse.parse_qsl(TKRdIHXDQAGOYsjyhEFzVMmvxwJukU))
    TKRdIHXDQAGOYsjyhEFzVMmvxwJukC=TKRdIHXDQAGOYsjyhEFzVMmvxwJuPk.get('skey').strip()
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuPa=TKRdIHXDQAGOYsjyhEFzVMmvxwJukp.get('skey').strip()
    if TKRdIHXDQAGOYsjyhEFzVMmvxwJukC!=TKRdIHXDQAGOYsjyhEFzVMmvxwJuPa:
     fp.write(TKRdIHXDQAGOYsjyhEFzVMmvxwJukU)
     TKRdIHXDQAGOYsjyhEFzVMmvxwJuke+=1
     if TKRdIHXDQAGOYsjyhEFzVMmvxwJuke>=50:break
   fp.close()
  except:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
 def play_VIDEO(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuPc =TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('mediacode')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubi =TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('stype')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuPB =TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('pvrmode')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuPn=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_selQuality(TKRdIHXDQAGOYsjyhEFzVMmvxwJubi)
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPc,TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPn),TKRdIHXDQAGOYsjyhEFzVMmvxwJubi,TKRdIHXDQAGOYsjyhEFzVMmvxwJuPB))
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.GetBroadURL(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPc,TKRdIHXDQAGOYsjyhEFzVMmvxwJuPn,TKRdIHXDQAGOYsjyhEFzVMmvxwJubi,TKRdIHXDQAGOYsjyhEFzVMmvxwJuPB,optUHD=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_uhd())
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.addon_log('qt, stype, url : %s - %s - %s'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJuBk(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPn),TKRdIHXDQAGOYsjyhEFzVMmvxwJubi,TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['streaming_url']))
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['streaming_url']=='':
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['error_msg']=='':
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.addon_noti(__language__(30908).encode('utf8'))
   else:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.addon_noti(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['error_msg'].encode('utf8'))
   return
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuPL={'user-agent':TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.USER_AGENT}
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuPg=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.makeDefaultCookies() 
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['drm_server_url'] !='':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPL[TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['drm_header_key']]=TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['drm_header_value']
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuPf =TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuPi =TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['streaming_url'].find('Policy=')
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuPi!=-1:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPU =TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['streaming_url'].split('?')[0]
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPp=TKRdIHXDQAGOYsjyhEFzVMmvxwJuBo(urllib.parse.parse_qsl(urllib.parse.urlsplit(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['streaming_url']).query))
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPg['CloudFront-Policy'] =TKRdIHXDQAGOYsjyhEFzVMmvxwJuPp['Policy'] 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPg['CloudFront-Signature'] =TKRdIHXDQAGOYsjyhEFzVMmvxwJuPp['Signature'] 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPg['CloudFront-Key-Pair-Id']=TKRdIHXDQAGOYsjyhEFzVMmvxwJuPp['Key-Pair-Id'] 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPl=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.make_stream_header(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPL,TKRdIHXDQAGOYsjyhEFzVMmvxwJuPg)
   if 'quickvod-mcdn.tving.com' in TKRdIHXDQAGOYsjyhEFzVMmvxwJuPU:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuPf=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuPN =TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuPW=TKRdIHXDQAGOYsjyhEFzVMmvxwJuPN.strftime('%Y-%m-%d-%H:%M:%S')
    if TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPW.replace('-','').replace(':',''))<TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPp['end'].replace('-','').replace(':','')):
     TKRdIHXDQAGOYsjyhEFzVMmvxwJuPp['end']=TKRdIHXDQAGOYsjyhEFzVMmvxwJuPW
     TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.addon_noti(__language__(30915).encode('utf8'))
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuPU ='%s?%s'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPU,urllib.parse.urlencode(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPp,doseq=TKRdIHXDQAGOYsjyhEFzVMmvxwJuce))
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuPr='{}|{}'.format(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPU,TKRdIHXDQAGOYsjyhEFzVMmvxwJuPl)
   else:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuPr='{}|{}'.format(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['streaming_url'],TKRdIHXDQAGOYsjyhEFzVMmvxwJuPl)
  else:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPl=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.make_stream_header(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPL,TKRdIHXDQAGOYsjyhEFzVMmvxwJuPg)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPr='{}|{}'.format(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['streaming_url'],TKRdIHXDQAGOYsjyhEFzVMmvxwJuPl)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.addon_log('if tmp_pos == -1')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuoS,TKRdIHXDQAGOYsjyhEFzVMmvxwJuok=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_proxyport()
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuoq=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_playback()
  if(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoS and TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('mode')in['VOD','MOVIE']and TKRdIHXDQAGOYsjyhEFzVMmvxwJuPf==TKRdIHXDQAGOYsjyhEFzVMmvxwJucC and(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['drm_server_url']!='' or TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.KodiVersion>=21)):
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['url_filename'].split('.')[1]=='mpd':
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Tving_Parse_mpd(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['streaming_url'])
   else:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Tving_Parse_m3u8(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['streaming_url'])
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.addon_log('xxx '+TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['streaming_url'])
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPe={'addon':'tvingm','playOption':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoq,'url_filename':TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['url_filename'],}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPe=json.dumps(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPe,separators=(',',':'))
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPe=base64.standard_b64encode(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPe.encode()).decode('utf-8')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPr ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(TKRdIHXDQAGOYsjyhEFzVMmvxwJuok,TKRdIHXDQAGOYsjyhEFzVMmvxwJuPr,TKRdIHXDQAGOYsjyhEFzVMmvxwJuPe)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPL['proxy-mini']=TKRdIHXDQAGOYsjyhEFzVMmvxwJuPe 
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.addon_log('surl(2) : {}'.format(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPr))
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuPl=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.make_stream_header(TKRdIHXDQAGOYsjyhEFzVMmvxwJuPL,TKRdIHXDQAGOYsjyhEFzVMmvxwJuPg)
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC=xbmcgui.ListItem(path=TKRdIHXDQAGOYsjyhEFzVMmvxwJuPr)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['drm_server_url']!='':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuca=TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['drm_server_url']
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuco ='https://license-global.pallycon.com/ri/licenseManager.do' 
   TKRdIHXDQAGOYsjyhEFzVMmvxwJucb ='mpd'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJucq ='com.widevine.alpha'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJucS={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'cross-site','user-agent':TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.USER_AGENT,TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['drm_header_key']:TKRdIHXDQAGOYsjyhEFzVMmvxwJuPt['drm_header_value'],}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuck=TKRdIHXDQAGOYsjyhEFzVMmvxwJuco+'|'+urllib.parse.urlencode(TKRdIHXDQAGOYsjyhEFzVMmvxwJucS)+'|R{SSM}|'
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream','inputstream.adaptive')
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.KodiVersion<=20:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream.adaptive.manifest_type',TKRdIHXDQAGOYsjyhEFzVMmvxwJucb)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream.adaptive.license_type',TKRdIHXDQAGOYsjyhEFzVMmvxwJucq)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream.adaptive.license_key',TKRdIHXDQAGOYsjyhEFzVMmvxwJuck)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream.adaptive.stream_headers',TKRdIHXDQAGOYsjyhEFzVMmvxwJuPl)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream.adaptive.manifest_headers',TKRdIHXDQAGOYsjyhEFzVMmvxwJuPl)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('mode')in['VOD','MOVIE']:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setContentLookup(TKRdIHXDQAGOYsjyhEFzVMmvxwJucC)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setMimeType('application/x-mpegURL')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream','inputstream.adaptive')
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.KodiVersion<=20:
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream.adaptive.manifest_type','hls')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream.adaptive.stream_headers',TKRdIHXDQAGOYsjyhEFzVMmvxwJuPl)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream.adaptive.manifest_headers',TKRdIHXDQAGOYsjyhEFzVMmvxwJuPl)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuPf==TKRdIHXDQAGOYsjyhEFzVMmvxwJuce:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setContentLookup(TKRdIHXDQAGOYsjyhEFzVMmvxwJucC)
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setMimeType('application/x-mpegURL')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream','inputstream.ffmpegdirect')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('ResumeTime','0')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,TKRdIHXDQAGOYsjyhEFzVMmvxwJuce,TKRdIHXDQAGOYsjyhEFzVMmvxwJuPC)
  try:
   if TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('mode')in['VOD','MOVIE']and TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('title'):
    TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'code':TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('programcode')if TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('mode')=='VOD' else TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('mediacode'),'img':TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('thumbnail'),'title':TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('title'),'videoid':TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('mediacode')}
    TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.Save_Watched_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('stype'),TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  except:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
 def logout(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJual=xbmcgui.Dialog()
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubL=TKRdIHXDQAGOYsjyhEFzVMmvxwJual.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJubL==TKRdIHXDQAGOYsjyhEFzVMmvxwJucC:sys.exit()
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Init_TV_Total()
  if os.path.isfile(TKRdIHXDQAGOYsjyhEFzVMmvxwJuat):os.remove(TKRdIHXDQAGOYsjyhEFzVMmvxwJuat)
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJucP =TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Get_Now_Datetime()
  TKRdIHXDQAGOYsjyhEFzVMmvxwJucB=TKRdIHXDQAGOYsjyhEFzVMmvxwJucP+datetime.timedelta(days=30) 
  (TKRdIHXDQAGOYsjyhEFzVMmvxwJubc,TKRdIHXDQAGOYsjyhEFzVMmvxwJubB,TKRdIHXDQAGOYsjyhEFzVMmvxwJubn,TKRdIHXDQAGOYsjyhEFzVMmvxwJubt)=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_account()
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Save_session_acount(TKRdIHXDQAGOYsjyhEFzVMmvxwJubc,TKRdIHXDQAGOYsjyhEFzVMmvxwJubB,TKRdIHXDQAGOYsjyhEFzVMmvxwJubn,TKRdIHXDQAGOYsjyhEFzVMmvxwJubt)
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.TV['account']['token_limit']=TKRdIHXDQAGOYsjyhEFzVMmvxwJucB.strftime('%Y%m%d')
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.JsonFile_Save(TKRdIHXDQAGOYsjyhEFzVMmvxwJuat,TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.TV)
 def cookiefile_check(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.TV=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.JsonFile_Load(TKRdIHXDQAGOYsjyhEFzVMmvxwJuat)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.TV=={}:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Init_TV_Total()
   return TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
  if '_tving_token' not in TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.TV.get('cookies'):
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Init_TV_Total()
   return TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
  (TKRdIHXDQAGOYsjyhEFzVMmvxwJucn,TKRdIHXDQAGOYsjyhEFzVMmvxwJuct,TKRdIHXDQAGOYsjyhEFzVMmvxwJucL,TKRdIHXDQAGOYsjyhEFzVMmvxwJucg)=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.get_settings_account()
  (TKRdIHXDQAGOYsjyhEFzVMmvxwJucf,TKRdIHXDQAGOYsjyhEFzVMmvxwJuci,TKRdIHXDQAGOYsjyhEFzVMmvxwJucU,TKRdIHXDQAGOYsjyhEFzVMmvxwJucp)=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Load_session_acount()
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJucn!=TKRdIHXDQAGOYsjyhEFzVMmvxwJucf or TKRdIHXDQAGOYsjyhEFzVMmvxwJuct!=TKRdIHXDQAGOYsjyhEFzVMmvxwJuci or TKRdIHXDQAGOYsjyhEFzVMmvxwJucL!=TKRdIHXDQAGOYsjyhEFzVMmvxwJucU or TKRdIHXDQAGOYsjyhEFzVMmvxwJucg!=TKRdIHXDQAGOYsjyhEFzVMmvxwJucp:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Init_TV_Total()
   return TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.TV['account']['token_limit']):
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.Init_TV_Total()
   return TKRdIHXDQAGOYsjyhEFzVMmvxwJucC
  return TKRdIHXDQAGOYsjyhEFzVMmvxwJuce
 def dp_Global_Search(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=TKRdIHXDQAGOYsjyhEFzVMmvxwJubl.get('mode')
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='TOTAL_SEARCH':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJucl='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJucl='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(TKRdIHXDQAGOYsjyhEFzVMmvxwJucl)
 def dp_Bookmark_Menu(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJucl='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(TKRdIHXDQAGOYsjyhEFzVMmvxwJucl)
 def dp_EuroLive_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag,TKRdIHXDQAGOYsjyhEFzVMmvxwJubl):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJubW=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.GetEuroChannelList()
  for TKRdIHXDQAGOYsjyhEFzVMmvxwJube in TKRdIHXDQAGOYsjyhEFzVMmvxwJubW:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqU =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('channel')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('title')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt =TKRdIHXDQAGOYsjyhEFzVMmvxwJube.get('subtitle')
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn={'mediatype':'episode','title':TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,'plot':'%s\n%s'%(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt)}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJubo={'mode':'LIVE','mediacode':TKRdIHXDQAGOYsjyhEFzVMmvxwJuqU,'stype':'onair',}
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.add_dir(TKRdIHXDQAGOYsjyhEFzVMmvxwJuoU,sublabel=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqt,img='',infoLabels=TKRdIHXDQAGOYsjyhEFzVMmvxwJuqn,isFolder=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC,params=TKRdIHXDQAGOYsjyhEFzVMmvxwJubo)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuBS(TKRdIHXDQAGOYsjyhEFzVMmvxwJubW)>0:xbmcplugin.endOfDirectory(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag._addon_handle,cacheToDisc=TKRdIHXDQAGOYsjyhEFzVMmvxwJucC)
 def tving_main(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag):
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.TvingObj.KodiVersion=TKRdIHXDQAGOYsjyhEFzVMmvxwJucr(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params.get('mode',TKRdIHXDQAGOYsjyhEFzVMmvxwJucW)
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='LOGOUT':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.logout()
   return
  TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.login_main()
  if TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr is TKRdIHXDQAGOYsjyhEFzVMmvxwJucW:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_Main_List()
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_Title_Group(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr in['GLOBAL_GROUP']:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_SubTitle_Group(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='CHANNEL':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_LiveChannel_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr in['LIVE','VOD','MOVIE']:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.play_VIDEO(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='PROGRAM':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_Program_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='4K_PROGRAM':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_4K_Program_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='ORI_PROGRAM':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_Ori_Program_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='EPISODE':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_Episode_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='MOVIE_SUB':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_Movie_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='4K_MOVIE':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_4K_Movie_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='SEARCH_GROUP':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_Search_Group(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr in['SEARCH','LOCAL_SEARCH']:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_Search_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='WATCH':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_Watch_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_History_Remove(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='ORDER_BY':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_setEpOrderby(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='SET_BOOKMARK':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_Set_Bookmark(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr in['TOTAL_SEARCH','TOTAL_HISTORY']:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_Global_Search(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='SEARCH_HISTORY':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_Search_History(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='MENU_BOOKMARK':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_Bookmark_Menu(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  elif TKRdIHXDQAGOYsjyhEFzVMmvxwJuSr=='EURO_GROUP':
   TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.dp_EuroLive_List(TKRdIHXDQAGOYsjyhEFzVMmvxwJuag.main_params)
  else:
   TKRdIHXDQAGOYsjyhEFzVMmvxwJucW
# Created by pyminifier (https://github.com/liftoff/pyminifier)
