__author__="NightRain"
AHiFRoBQENLKYdhDgVXwTCIekmnOfv=print
AHiFRoBQENLKYdhDgVXwTCIekmnOfz=ImportError
AHiFRoBQENLKYdhDgVXwTCIekmnOfr=object
AHiFRoBQENLKYdhDgVXwTCIekmnOfP=None
AHiFRoBQENLKYdhDgVXwTCIekmnOfc=False
AHiFRoBQENLKYdhDgVXwTCIekmnOsG=open
AHiFRoBQENLKYdhDgVXwTCIekmnOsj=True
AHiFRoBQENLKYdhDgVXwTCIekmnOsx=int
AHiFRoBQENLKYdhDgVXwTCIekmnOsy=range
AHiFRoBQENLKYdhDgVXwTCIekmnOsJ=Exception
AHiFRoBQENLKYdhDgVXwTCIekmnOsa=len
AHiFRoBQENLKYdhDgVXwTCIekmnOsf=str
AHiFRoBQENLKYdhDgVXwTCIekmnOsq=dict
AHiFRoBQENLKYdhDgVXwTCIekmnOsW=list
AHiFRoBQENLKYdhDgVXwTCIekmnOsp=bytes
AHiFRoBQENLKYdhDgVXwTCIekmnOsM=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 AHiFRoBQENLKYdhDgVXwTCIekmnOfv('Cryptodome')
except AHiFRoBQENLKYdhDgVXwTCIekmnOfz:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 AHiFRoBQENLKYdhDgVXwTCIekmnOfv('Crypto')
AHiFRoBQENLKYdhDgVXwTCIekmnOGx={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
AHiFRoBQENLKYdhDgVXwTCIekmnOGy ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
AHiFRoBQENLKYdhDgVXwTCIekmnOGJ =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
AHiFRoBQENLKYdhDgVXwTCIekmnOGa=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class AHiFRoBQENLKYdhDgVXwTCIekmnOGj(AHiFRoBQENLKYdhDgVXwTCIekmnOfr):
 def __init__(AHiFRoBQENLKYdhDgVXwTCIekmnOGf):
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.NETWORKCODE ='CSND0900'
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.OSCODE ='CSOD0900' 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TELECODE ='CSCD0900'
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.SCREENCODE ='CSSD0100'
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.SCREENCODE_ATV ='CSSD1300' 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.LIVE_LIMIT =20 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.VOD_LIMIT =24 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.EPISODE_LIMIT =30 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.SEARCH_LIMIT =30 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.MOVIE_LIMIT =24 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN ='https://api.tving.com'
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN ='https://image.tving.com'
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.SEARCH_DOMAIN ='https://search-api.tving.com'
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.LOGIN_DOMAIN ='https://user.tving.com'
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.URL_DOMAIN ='https://www.tving.com'
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.MOVIE_LITE =['2610061','2610161','261062']
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.DEFAULT_HEADER ={'user-agent':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.USER_AGENT}
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.COOKIE_FILE_NAME =''
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV_SESSION_COOKIES1=''
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV_SESSION_COOKIES2=''
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV_STREAM_FILENAME =''
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV_SESSION_TEXT1 =''
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV_SESSION_TEXT2 =''
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.KodiVersion=20
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV ={}
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.Init_TV_Total()
 def Init_TV_Total(AHiFRoBQENLKYdhDgVXwTCIekmnOGf):
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV={'account':{},'cookies':{},}
 def callRequestCookies(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,jobtype,AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,redirects=AHiFRoBQENLKYdhDgVXwTCIekmnOfc):
  AHiFRoBQENLKYdhDgVXwTCIekmnOGs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.DEFAULT_HEADER
  if headers:AHiFRoBQENLKYdhDgVXwTCIekmnOGs.update(headers)
  if jobtype=='Get':
   AHiFRoBQENLKYdhDgVXwTCIekmnOGq=requests.get(AHiFRoBQENLKYdhDgVXwTCIekmnOxq,params=params,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOGs,cookies=cookies,allow_redirects=redirects)
  else:
   AHiFRoBQENLKYdhDgVXwTCIekmnOGq=requests.post(AHiFRoBQENLKYdhDgVXwTCIekmnOxq,data=payload,params=params,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOGs,cookies=cookies,allow_redirects=redirects)
  AHiFRoBQENLKYdhDgVXwTCIekmnOfv(AHiFRoBQENLKYdhDgVXwTCIekmnOGq.url)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOGq
 def JsonFile_Save(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,filename,AHiFRoBQENLKYdhDgVXwTCIekmnOGW):
  if filename=='':return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  try:
   fp=AHiFRoBQENLKYdhDgVXwTCIekmnOsG(filename,'w',-1,'utf-8')
   json.dump(AHiFRoBQENLKYdhDgVXwTCIekmnOGW,fp,indent=4,ensure_ascii=AHiFRoBQENLKYdhDgVXwTCIekmnOfc)
   fp.close()
  except:
   return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  return AHiFRoBQENLKYdhDgVXwTCIekmnOsj
 def JsonFile_Load(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,filename):
  if filename=='':return{}
  try:
   fp=AHiFRoBQENLKYdhDgVXwTCIekmnOsG(filename,'r',-1,'utf-8')
   AHiFRoBQENLKYdhDgVXwTCIekmnOGM=json.load(fp)
   fp.close()
  except:
   return{}
  return AHiFRoBQENLKYdhDgVXwTCIekmnOGM
 def TextFile_Save(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,filename,resText):
  if filename=='':return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  try:
   fp=AHiFRoBQENLKYdhDgVXwTCIekmnOsG(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  return AHiFRoBQENLKYdhDgVXwTCIekmnOsj
 def Save_session_acount(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,AHiFRoBQENLKYdhDgVXwTCIekmnOGt,AHiFRoBQENLKYdhDgVXwTCIekmnOGu,AHiFRoBQENLKYdhDgVXwTCIekmnOGU,AHiFRoBQENLKYdhDgVXwTCIekmnOGl):
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['account']['tvid'] =base64.standard_b64encode(AHiFRoBQENLKYdhDgVXwTCIekmnOGt.encode()).decode('utf-8')
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['account']['tvpw'] =base64.standard_b64encode(AHiFRoBQENLKYdhDgVXwTCIekmnOGu.encode()).decode('utf-8')
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['account']['tvtype']=AHiFRoBQENLKYdhDgVXwTCIekmnOGU 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['account']['tvpf'] =AHiFRoBQENLKYdhDgVXwTCIekmnOGl 
 def Load_session_acount(AHiFRoBQENLKYdhDgVXwTCIekmnOGf):
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOGt =base64.standard_b64decode(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['account']['tvid']).decode('utf-8')
   AHiFRoBQENLKYdhDgVXwTCIekmnOGu =base64.standard_b64decode(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['account']['tvpw']).decode('utf-8')
   AHiFRoBQENLKYdhDgVXwTCIekmnOGU=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['account']['tvtype']
   AHiFRoBQENLKYdhDgVXwTCIekmnOGl =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return AHiFRoBQENLKYdhDgVXwTCIekmnOGt,AHiFRoBQENLKYdhDgVXwTCIekmnOGu,AHiFRoBQENLKYdhDgVXwTCIekmnOGU,AHiFRoBQENLKYdhDgVXwTCIekmnOGl
 def makeDefaultCookies(AHiFRoBQENLKYdhDgVXwTCIekmnOGf):
  AHiFRoBQENLKYdhDgVXwTCIekmnOGb={}
  for AHiFRoBQENLKYdhDgVXwTCIekmnOGS,AHiFRoBQENLKYdhDgVXwTCIekmnOjc in AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies'].items():
   AHiFRoBQENLKYdhDgVXwTCIekmnOGb[AHiFRoBQENLKYdhDgVXwTCIekmnOGS]=AHiFRoBQENLKYdhDgVXwTCIekmnOjc
  return AHiFRoBQENLKYdhDgVXwTCIekmnOGb
 def getDeviceStr(AHiFRoBQENLKYdhDgVXwTCIekmnOGf):
  AHiFRoBQENLKYdhDgVXwTCIekmnOGv=[]
  AHiFRoBQENLKYdhDgVXwTCIekmnOGv.append('Windows') 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGv.append('Chrome') 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGv.append('ko-KR') 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGv.append('undefined') 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGv.append('24') 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGv.append(u'한국 표준시')
  AHiFRoBQENLKYdhDgVXwTCIekmnOGv.append('undefined') 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGv.append('undefined') 
  AHiFRoBQENLKYdhDgVXwTCIekmnOGv.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  AHiFRoBQENLKYdhDgVXwTCIekmnOGz=''
  for AHiFRoBQENLKYdhDgVXwTCIekmnOGr in AHiFRoBQENLKYdhDgVXwTCIekmnOGv:
   AHiFRoBQENLKYdhDgVXwTCIekmnOGz+=AHiFRoBQENLKYdhDgVXwTCIekmnOGr+'|'
  return AHiFRoBQENLKYdhDgVXwTCIekmnOGz
 def GetDefaultParams(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,uhd=AHiFRoBQENLKYdhDgVXwTCIekmnOfc):
  if uhd==AHiFRoBQENLKYdhDgVXwTCIekmnOfc:
   AHiFRoBQENLKYdhDgVXwTCIekmnOGP={'apiKey':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.APIKEY,'networkCode':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.NETWORKCODE,'osCode':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.OSCODE,'teleCode':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TELECODE,'screenCode':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.SCREENCODE,}
  else:
   AHiFRoBQENLKYdhDgVXwTCIekmnOGP={'apiKey':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.APIKEY_ATV,'networkCode':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.NETWORKCODE,'osCode':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.OSCODE,'teleCode':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TELECODE,'screenCode':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.SCREENCODE_ATV,}
  return AHiFRoBQENLKYdhDgVXwTCIekmnOGP
 def GetNoCache(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,timetype=1):
  if timetype==1:
   return AHiFRoBQENLKYdhDgVXwTCIekmnOsx(time.time())
  else:
   return AHiFRoBQENLKYdhDgVXwTCIekmnOsx(time.time()*1000)
 def GetUniqueid(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,hValue=AHiFRoBQENLKYdhDgVXwTCIekmnOfP):
  if hValue:
   import hashlib
   AHiFRoBQENLKYdhDgVXwTCIekmnOGc=hashlib.sha1()
   AHiFRoBQENLKYdhDgVXwTCIekmnOGc.update(hValue.encode())
   AHiFRoBQENLKYdhDgVXwTCIekmnOjG=AHiFRoBQENLKYdhDgVXwTCIekmnOGc.hexdigest()[:8]
  else:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjx=[0 for i in AHiFRoBQENLKYdhDgVXwTCIekmnOsy(256)]
   for i in AHiFRoBQENLKYdhDgVXwTCIekmnOsy(256):
    AHiFRoBQENLKYdhDgVXwTCIekmnOjx[i]='%02x'%(i)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjy=AHiFRoBQENLKYdhDgVXwTCIekmnOsx(4294967295*random.random())|0
   AHiFRoBQENLKYdhDgVXwTCIekmnOjG=AHiFRoBQENLKYdhDgVXwTCIekmnOjx[255&AHiFRoBQENLKYdhDgVXwTCIekmnOjy]+AHiFRoBQENLKYdhDgVXwTCIekmnOjx[AHiFRoBQENLKYdhDgVXwTCIekmnOjy>>8&255]+AHiFRoBQENLKYdhDgVXwTCIekmnOjx[AHiFRoBQENLKYdhDgVXwTCIekmnOjy>>16&255]+AHiFRoBQENLKYdhDgVXwTCIekmnOjx[AHiFRoBQENLKYdhDgVXwTCIekmnOjy>>24&255]
  return AHiFRoBQENLKYdhDgVXwTCIekmnOjG
 def GetCredential(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,user_id,user_pw,login_type,user_pf):
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjJ=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   AHiFRoBQENLKYdhDgVXwTCIekmnOja={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Post',AHiFRoBQENLKYdhDgVXwTCIekmnOjJ,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOja,params=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjs in AHiFRoBQENLKYdhDgVXwTCIekmnOjf.cookies:
    AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies'][AHiFRoBQENLKYdhDgVXwTCIekmnOjs.name]=AHiFRoBQENLKYdhDgVXwTCIekmnOjs.value
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
   AHiFRoBQENLKYdhDgVXwTCIekmnOGf.Init_TV_Total()
   return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  AHiFRoBQENLKYdhDgVXwTCIekmnOjq=[]
  AHiFRoBQENLKYdhDgVXwTCIekmnOjW =''
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   AHiFRoBQENLKYdhDgVXwTCIekmnOGb=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.makeDefaultCookies()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOjp,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOGb)
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjs in AHiFRoBQENLKYdhDgVXwTCIekmnOjf.cookies:
    AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies'][AHiFRoBQENLKYdhDgVXwTCIekmnOjs.name]=AHiFRoBQENLKYdhDgVXwTCIekmnOjs.value
   AHiFRoBQENLKYdhDgVXwTCIekmnOjq =re.findall('data-profile-no="\d+"',AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   for i in AHiFRoBQENLKYdhDgVXwTCIekmnOsy(AHiFRoBQENLKYdhDgVXwTCIekmnOsa(AHiFRoBQENLKYdhDgVXwTCIekmnOjq)):
    AHiFRoBQENLKYdhDgVXwTCIekmnOjM =AHiFRoBQENLKYdhDgVXwTCIekmnOjq[i].replace('data-profile-no=','').replace('"','')
    AHiFRoBQENLKYdhDgVXwTCIekmnOjq[i]=AHiFRoBQENLKYdhDgVXwTCIekmnOjM
   AHiFRoBQENLKYdhDgVXwTCIekmnOjW=AHiFRoBQENLKYdhDgVXwTCIekmnOjq[user_pf]
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
   AHiFRoBQENLKYdhDgVXwTCIekmnOGf.Init_TV_Total()
   return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   AHiFRoBQENLKYdhDgVXwTCIekmnOGb=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.makeDefaultCookies()
   AHiFRoBQENLKYdhDgVXwTCIekmnOja={'profileNo':AHiFRoBQENLKYdhDgVXwTCIekmnOjW}
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Post',AHiFRoBQENLKYdhDgVXwTCIekmnOjp,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOja,params=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOGb)
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjs in AHiFRoBQENLKYdhDgVXwTCIekmnOjf.cookies:
    AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies'][AHiFRoBQENLKYdhDgVXwTCIekmnOjs.name]=AHiFRoBQENLKYdhDgVXwTCIekmnOjs.value
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
   AHiFRoBQENLKYdhDgVXwTCIekmnOGf.Init_TV_Total()
   return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  AHiFRoBQENLKYdhDgVXwTCIekmnOjt =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDeviceList()
  if AHiFRoBQENLKYdhDgVXwTCIekmnOjt not in['','-']:
   AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_uuid']=AHiFRoBQENLKYdhDgVXwTCIekmnOjt+'-'+AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetUniqueid(AHiFRoBQENLKYdhDgVXwTCIekmnOjt)
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.JsonFile_Save(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.COOKIE_FILE_NAME,AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOsj
 def GetCredential_old(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,user_id,user_pw,login_type,user_pf):
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjJ=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   AHiFRoBQENLKYdhDgVXwTCIekmnOja={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Post',AHiFRoBQENLKYdhDgVXwTCIekmnOjJ,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOja,params=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjs in AHiFRoBQENLKYdhDgVXwTCIekmnOjf.cookies:
    if AHiFRoBQENLKYdhDgVXwTCIekmnOjs.name=='_tving_token':
     AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_token']=AHiFRoBQENLKYdhDgVXwTCIekmnOjs.value
    elif AHiFRoBQENLKYdhDgVXwTCIekmnOjs.name=='POC_USERINFO':
     AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_userinfo']=AHiFRoBQENLKYdhDgVXwTCIekmnOjs.value
    elif AHiFRoBQENLKYdhDgVXwTCIekmnOjs.name=='authToken':
     AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_authToken']=AHiFRoBQENLKYdhDgVXwTCIekmnOjs.value
   if not AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_token']:
    AHiFRoBQENLKYdhDgVXwTCIekmnOGf.Init_TV_Total()
    return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
   AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_maintoken']=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_token']
   if AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetProfileToken(user_pf)==AHiFRoBQENLKYdhDgVXwTCIekmnOfc:
    AHiFRoBQENLKYdhDgVXwTCIekmnOGf.Init_TV_Total()
    return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies'])
   AHiFRoBQENLKYdhDgVXwTCIekmnOjt =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDeviceList()
   if AHiFRoBQENLKYdhDgVXwTCIekmnOjt not in['','-']:
    AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_uuid']=AHiFRoBQENLKYdhDgVXwTCIekmnOjt+'-'+AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetUniqueid(AHiFRoBQENLKYdhDgVXwTCIekmnOjt)
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
   AHiFRoBQENLKYdhDgVXwTCIekmnOGf.Init_TV_Total()
   return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  return AHiFRoBQENLKYdhDgVXwTCIekmnOsj
 def GetProfileToken(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,user_pf):
  AHiFRoBQENLKYdhDgVXwTCIekmnOjq=[]
  AHiFRoBQENLKYdhDgVXwTCIekmnOjW =''
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   AHiFRoBQENLKYdhDgVXwTCIekmnOGb=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.makeDefaultCookies()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOjp,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOGb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjq =re.findall('data-profile-no="\d+"',AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(AHiFRoBQENLKYdhDgVXwTCIekmnOjq)
   for i in AHiFRoBQENLKYdhDgVXwTCIekmnOsy(AHiFRoBQENLKYdhDgVXwTCIekmnOsa(AHiFRoBQENLKYdhDgVXwTCIekmnOjq)):
    AHiFRoBQENLKYdhDgVXwTCIekmnOjM =AHiFRoBQENLKYdhDgVXwTCIekmnOjq[i].replace('data-profile-no=','').replace('"','')
    AHiFRoBQENLKYdhDgVXwTCIekmnOjq[i]=AHiFRoBQENLKYdhDgVXwTCIekmnOjM
   AHiFRoBQENLKYdhDgVXwTCIekmnOjW=AHiFRoBQENLKYdhDgVXwTCIekmnOjq[user_pf]
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
   AHiFRoBQENLKYdhDgVXwTCIekmnOGf.Init_TV_Total()
   return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   AHiFRoBQENLKYdhDgVXwTCIekmnOGb=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.makeDefaultCookies()
   AHiFRoBQENLKYdhDgVXwTCIekmnOja={'profileNo':AHiFRoBQENLKYdhDgVXwTCIekmnOjW}
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Post',AHiFRoBQENLKYdhDgVXwTCIekmnOjp,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOja,params=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOGb)
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjs in AHiFRoBQENLKYdhDgVXwTCIekmnOjf.cookies:
    if AHiFRoBQENLKYdhDgVXwTCIekmnOjs.name=='_tving_token':
     AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_token']=AHiFRoBQENLKYdhDgVXwTCIekmnOjs.value
    elif AHiFRoBQENLKYdhDgVXwTCIekmnOjs.name==AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GLOBAL_COOKIENM['tv_cookiekey']:
     AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_cookiekey']=AHiFRoBQENLKYdhDgVXwTCIekmnOjs.value
    elif AHiFRoBQENLKYdhDgVXwTCIekmnOjs.name==AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GLOBAL_COOKIENM['tv_lockkey']:
     AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_lockkey']=AHiFRoBQENLKYdhDgVXwTCIekmnOjs.value
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
   AHiFRoBQENLKYdhDgVXwTCIekmnOGf.Init_TV_Total()
   return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  return AHiFRoBQENLKYdhDgVXwTCIekmnOsj
 def GetDeviceList(AHiFRoBQENLKYdhDgVXwTCIekmnOGf):
  AHiFRoBQENLKYdhDgVXwTCIekmnOju=[]
  AHiFRoBQENLKYdhDgVXwTCIekmnOjU='-'
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v1/user/device/list'
   AHiFRoBQENLKYdhDgVXwTCIekmnOjl=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjp
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams()
   AHiFRoBQENLKYdhDgVXwTCIekmnOGb=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.makeDefaultCookies()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOjl,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOjb,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOGb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjS=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   AHiFRoBQENLKYdhDgVXwTCIekmnOju=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjv in AHiFRoBQENLKYdhDgVXwTCIekmnOju:
    if AHiFRoBQENLKYdhDgVXwTCIekmnOjv['model'].lower().startswith('pc'):
     AHiFRoBQENLKYdhDgVXwTCIekmnOjU=AHiFRoBQENLKYdhDgVXwTCIekmnOjv['uuid']
     break
   if AHiFRoBQENLKYdhDgVXwTCIekmnOjU=='-':
    AHiFRoBQENLKYdhDgVXwTCIekmnOjU=AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetNoCache(timetype=1))
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOjU
 def Get_Now_Datetime(AHiFRoBQENLKYdhDgVXwTCIekmnOGf):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def make_stream_header(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,AHiFRoBQENLKYdhDgVXwTCIekmnOxG,AHiFRoBQENLKYdhDgVXwTCIekmnOGb):
  AHiFRoBQENLKYdhDgVXwTCIekmnOjr=''
  if AHiFRoBQENLKYdhDgVXwTCIekmnOGb not in[{},AHiFRoBQENLKYdhDgVXwTCIekmnOfP,'']:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjP=AHiFRoBQENLKYdhDgVXwTCIekmnOsa(AHiFRoBQENLKYdhDgVXwTCIekmnOGb)
   for AHiFRoBQENLKYdhDgVXwTCIekmnOGS,AHiFRoBQENLKYdhDgVXwTCIekmnOjc in AHiFRoBQENLKYdhDgVXwTCIekmnOGb.items():
    AHiFRoBQENLKYdhDgVXwTCIekmnOjr+='{}={}'.format(AHiFRoBQENLKYdhDgVXwTCIekmnOGS,AHiFRoBQENLKYdhDgVXwTCIekmnOjc)
    AHiFRoBQENLKYdhDgVXwTCIekmnOjP+=-1
    if AHiFRoBQENLKYdhDgVXwTCIekmnOjP>0:AHiFRoBQENLKYdhDgVXwTCIekmnOjr+='; '
   AHiFRoBQENLKYdhDgVXwTCIekmnOxG['cookie']=AHiFRoBQENLKYdhDgVXwTCIekmnOjr
  AHiFRoBQENLKYdhDgVXwTCIekmnOxj=''
  i=0
  for AHiFRoBQENLKYdhDgVXwTCIekmnOGS,AHiFRoBQENLKYdhDgVXwTCIekmnOjc in AHiFRoBQENLKYdhDgVXwTCIekmnOxG.items():
   i=i+1
   if i>1:AHiFRoBQENLKYdhDgVXwTCIekmnOxj+='&'
   AHiFRoBQENLKYdhDgVXwTCIekmnOxj+='{}={}'.format(AHiFRoBQENLKYdhDgVXwTCIekmnOGS,urllib.parse.quote(AHiFRoBQENLKYdhDgVXwTCIekmnOjc))
  return AHiFRoBQENLKYdhDgVXwTCIekmnOxj
 def GetBroadURL(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,mediacode,sel_quality,stype,pvrmode='-',optUHD=AHiFRoBQENLKYdhDgVXwTCIekmnOfc):
  AHiFRoBQENLKYdhDgVXwTCIekmnOxy ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','subtitleYn':AHiFRoBQENLKYdhDgVXwTCIekmnOfc,'error_msg':'',}
  AHiFRoBQENLKYdhDgVXwTCIekmnOjU =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_uuid'].split('-')[0] 
  AHiFRoBQENLKYdhDgVXwTCIekmnOxJ =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_uuid'] 
  AHiFRoBQENLKYdhDgVXwTCIekmnOxa=AHiFRoBQENLKYdhDgVXwTCIekmnOfc 
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOxf=AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetNoCache(1))
   if stype!='tvingtv':
    AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v2/media/stream/info' 
    AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams()
    AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':AHiFRoBQENLKYdhDgVXwTCIekmnOxJ,'deviceInfo':'PC','noCache':AHiFRoBQENLKYdhDgVXwTCIekmnOxf,}
    AHiFRoBQENLKYdhDgVXwTCIekmnOxs.update(AHiFRoBQENLKYdhDgVXwTCIekmnOjb)
    AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjp
    AHiFRoBQENLKYdhDgVXwTCIekmnOGb=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.makeDefaultCookies()
    AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOxs,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOGb)
    if AHiFRoBQENLKYdhDgVXwTCIekmnOjf.status_code!=200:
     AHiFRoBQENLKYdhDgVXwTCIekmnOxy['error_msg']='First Step - {} error'.format(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.status_code)
     return AHiFRoBQENLKYdhDgVXwTCIekmnOxy
    AHiFRoBQENLKYdhDgVXwTCIekmnOjS=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
    if AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['result']['code']=='060':
     for AHiFRoBQENLKYdhDgVXwTCIekmnOGS,AHiFRoBQENLKYdhDgVXwTCIekmnOjc in AHiFRoBQENLKYdhDgVXwTCIekmnOGx.items():
      if AHiFRoBQENLKYdhDgVXwTCIekmnOjc==sel_quality:
       AHiFRoBQENLKYdhDgVXwTCIekmnOxW=AHiFRoBQENLKYdhDgVXwTCIekmnOGS
    elif AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['result']['code']!='000':
     AHiFRoBQENLKYdhDgVXwTCIekmnOxy['error_msg']=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['result']['message']
     return AHiFRoBQENLKYdhDgVXwTCIekmnOxy
    else: 
     if not('stream' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']):return AHiFRoBQENLKYdhDgVXwTCIekmnOxy
     AHiFRoBQENLKYdhDgVXwTCIekmnOxp=[]
     for AHiFRoBQENLKYdhDgVXwTCIekmnOGS,AHiFRoBQENLKYdhDgVXwTCIekmnOjc in AHiFRoBQENLKYdhDgVXwTCIekmnOGx.items():
      for AHiFRoBQENLKYdhDgVXwTCIekmnOjv in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['stream']['quality']:
       if AHiFRoBQENLKYdhDgVXwTCIekmnOjv['active']=='Y' and AHiFRoBQENLKYdhDgVXwTCIekmnOjv['code']==AHiFRoBQENLKYdhDgVXwTCIekmnOGS:
        AHiFRoBQENLKYdhDgVXwTCIekmnOxp.append({AHiFRoBQENLKYdhDgVXwTCIekmnOGx.get(AHiFRoBQENLKYdhDgVXwTCIekmnOjv['code']):AHiFRoBQENLKYdhDgVXwTCIekmnOjv['code']})
     AHiFRoBQENLKYdhDgVXwTCIekmnOxW=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.CheckQuality(sel_quality,AHiFRoBQENLKYdhDgVXwTCIekmnOxp)
     try:
      if optUHD==AHiFRoBQENLKYdhDgVXwTCIekmnOsj and AHiFRoBQENLKYdhDgVXwTCIekmnOxW=='stream50' and 'stream_support_info' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['content']['info']:
       if AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['content']['info']['stream_support_info']!=AHiFRoBQENLKYdhDgVXwTCIekmnOfP:
        if 'stream70' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['content']['info']['stream_support_info']:
         AHiFRoBQENLKYdhDgVXwTCIekmnOxW='stream70'
         AHiFRoBQENLKYdhDgVXwTCIekmnOxa =AHiFRoBQENLKYdhDgVXwTCIekmnOsj
     except:
      pass
     try:
      if optUHD==AHiFRoBQENLKYdhDgVXwTCIekmnOsj and AHiFRoBQENLKYdhDgVXwTCIekmnOxW=='stream50' and 'stream' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['content']['info']:
       if AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['content']['info']['stream']!=AHiFRoBQENLKYdhDgVXwTCIekmnOfP:
        for AHiFRoBQENLKYdhDgVXwTCIekmnOjv in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['content']['info']['stream']:
         if AHiFRoBQENLKYdhDgVXwTCIekmnOjv['code']=='stream70':
          AHiFRoBQENLKYdhDgVXwTCIekmnOxW='stream70'
          AHiFRoBQENLKYdhDgVXwTCIekmnOxa =AHiFRoBQENLKYdhDgVXwTCIekmnOsj
          break
     except:
      pass
   else:
    AHiFRoBQENLKYdhDgVXwTCIekmnOxW='stream40'
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
   AHiFRoBQENLKYdhDgVXwTCIekmnOxy['error_msg']='First Step - except error'
   return AHiFRoBQENLKYdhDgVXwTCIekmnOxy
  AHiFRoBQENLKYdhDgVXwTCIekmnOfv(AHiFRoBQENLKYdhDgVXwTCIekmnOxW)
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOxf=AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetNoCache(1))
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v2a/media/stream/info'
   if AHiFRoBQENLKYdhDgVXwTCIekmnOxa==AHiFRoBQENLKYdhDgVXwTCIekmnOsj:
    AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams(uhd=AHiFRoBQENLKYdhDgVXwTCIekmnOsj)
    AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'mediaCode':mediacode,'noCache':AHiFRoBQENLKYdhDgVXwTCIekmnOxf,'streamType':'hls','streamCode':AHiFRoBQENLKYdhDgVXwTCIekmnOxW,'deviceId':AHiFRoBQENLKYdhDgVXwTCIekmnOjU,'adReq':'none','wm':'Y','ad_device':'','uuid':AHiFRoBQENLKYdhDgVXwTCIekmnOxJ,'deviceInfo':'android_tv',}
   else:
    AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams()
    AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':AHiFRoBQENLKYdhDgVXwTCIekmnOxW,'deviceId':AHiFRoBQENLKYdhDgVXwTCIekmnOjU,'uuid':AHiFRoBQENLKYdhDgVXwTCIekmnOxJ,'deviceInfo':'PC_Chrome','noCache':AHiFRoBQENLKYdhDgVXwTCIekmnOxf,'wm':'Y'}
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs.update(AHiFRoBQENLKYdhDgVXwTCIekmnOjb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjp
   AHiFRoBQENLKYdhDgVXwTCIekmnOGb=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.makeDefaultCookies()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOxs,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOGb,redirects=AHiFRoBQENLKYdhDgVXwTCIekmnOsj)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjS=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   if AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['result']['code']!='000':
    AHiFRoBQENLKYdhDgVXwTCIekmnOxy['error_msg']=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['result']['message']
    return AHiFRoBQENLKYdhDgVXwTCIekmnOxy
   AHiFRoBQENLKYdhDgVXwTCIekmnOxM=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['stream']
   if 'drm_license_assertion' in AHiFRoBQENLKYdhDgVXwTCIekmnOxM:
    AHiFRoBQENLKYdhDgVXwTCIekmnOxy['drm_license']=AHiFRoBQENLKYdhDgVXwTCIekmnOxM['drm_license_assertion']
    if '4k_nondrm_url' in AHiFRoBQENLKYdhDgVXwTCIekmnOxM['broadcast']and AHiFRoBQENLKYdhDgVXwTCIekmnOxa==AHiFRoBQENLKYdhDgVXwTCIekmnOsj:
     AHiFRoBQENLKYdhDgVXwTCIekmnOxt =AHiFRoBQENLKYdhDgVXwTCIekmnOxM['broadcast']['4k_nondrm_url']
     AHiFRoBQENLKYdhDgVXwTCIekmnOxy['drm_license']=''
    else:
     AHiFRoBQENLKYdhDgVXwTCIekmnOxt =AHiFRoBQENLKYdhDgVXwTCIekmnOxM['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in AHiFRoBQENLKYdhDgVXwTCIekmnOxM['broadcast']):return AHiFRoBQENLKYdhDgVXwTCIekmnOxy
    AHiFRoBQENLKYdhDgVXwTCIekmnOxt=AHiFRoBQENLKYdhDgVXwTCIekmnOxM['broadcast']['broad_url']
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
   AHiFRoBQENLKYdhDgVXwTCIekmnOxy['error_msg']='Second Step - except error'
   return AHiFRoBQENLKYdhDgVXwTCIekmnOxy
  AHiFRoBQENLKYdhDgVXwTCIekmnOxu=AHiFRoBQENLKYdhDgVXwTCIekmnOxf
  AHiFRoBQENLKYdhDgVXwTCIekmnOxt=AHiFRoBQENLKYdhDgVXwTCIekmnOxt.split('|')[1]
  AHiFRoBQENLKYdhDgVXwTCIekmnOxt,AHiFRoBQENLKYdhDgVXwTCIekmnOxU,AHiFRoBQENLKYdhDgVXwTCIekmnOxl=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.Decrypt_Url(AHiFRoBQENLKYdhDgVXwTCIekmnOxt,mediacode,AHiFRoBQENLKYdhDgVXwTCIekmnOxu)
  AHiFRoBQENLKYdhDgVXwTCIekmnOxy['streaming_url']=AHiFRoBQENLKYdhDgVXwTCIekmnOxt
  AHiFRoBQENLKYdhDgVXwTCIekmnOxy['watermark'] =AHiFRoBQENLKYdhDgVXwTCIekmnOxU
  AHiFRoBQENLKYdhDgVXwTCIekmnOxy['watermarkKey']=AHiFRoBQENLKYdhDgVXwTCIekmnOxl
  if 'subtitles' in AHiFRoBQENLKYdhDgVXwTCIekmnOxM:
   for AHiFRoBQENLKYdhDgVXwTCIekmnOxb in AHiFRoBQENLKYdhDgVXwTCIekmnOxM.get('subtitles'):
    if AHiFRoBQENLKYdhDgVXwTCIekmnOxb.get('code')in['KO','KO_CC']:
     AHiFRoBQENLKYdhDgVXwTCIekmnOxy['subtitleYn']=AHiFRoBQENLKYdhDgVXwTCIekmnOsj
     break
  return AHiFRoBQENLKYdhDgVXwTCIekmnOxy
 def Tving_Parse_mpd(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,stream_url,watermarkKey=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,watermark=AHiFRoBQENLKYdhDgVXwTCIekmnOfP):
  if watermarkKey not in['',AHiFRoBQENLKYdhDgVXwTCIekmnOfP]:
   AHiFRoBQENLKYdhDgVXwTCIekmnOxG={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,'Access-Control-Request-Headers':'x-tving-param1,x-tving-param2',}
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=requests.get(url=stream_url,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOxG,allow_redirects=AHiFRoBQENLKYdhDgVXwTCIekmnOfc)
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.status_code)+' - '+AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.url))
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv('')
  else:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=requests.get(url=stream_url)
  AHiFRoBQENLKYdhDgVXwTCIekmnOxS=AHiFRoBQENLKYdhDgVXwTCIekmnOjf.content.decode('utf-8')
  AHiFRoBQENLKYdhDgVXwTCIekmnOxv=0
  AHiFRoBQENLKYdhDgVXwTCIekmnOxz =ET.ElementTree(ET.fromstring(AHiFRoBQENLKYdhDgVXwTCIekmnOxS))
  AHiFRoBQENLKYdhDgVXwTCIekmnOxr =AHiFRoBQENLKYdhDgVXwTCIekmnOxz.getroot()
  AHiFRoBQENLKYdhDgVXwTCIekmnOxP=re.match(r'\{.*\}',AHiFRoBQENLKYdhDgVXwTCIekmnOxr.tag)[0] 
  AHiFRoBQENLKYdhDgVXwTCIekmnOxc=AHiFRoBQENLKYdhDgVXwTCIekmnOsq([node for _,node in ET.iterparse(io.StringIO(AHiFRoBQENLKYdhDgVXwTCIekmnOxS),events=['start-ns'])])
  for AHiFRoBQENLKYdhDgVXwTCIekmnOGS,AHiFRoBQENLKYdhDgVXwTCIekmnOyb in AHiFRoBQENLKYdhDgVXwTCIekmnOxc.items():
   if AHiFRoBQENLKYdhDgVXwTCIekmnOGS!='ns2':
    ET.register_namespace(AHiFRoBQENLKYdhDgVXwTCIekmnOGS,AHiFRoBQENLKYdhDgVXwTCIekmnOyb)
  AHiFRoBQENLKYdhDgVXwTCIekmnOyG=AHiFRoBQENLKYdhDgVXwTCIekmnOxr.find(AHiFRoBQENLKYdhDgVXwTCIekmnOxP+'Period')
  for AHiFRoBQENLKYdhDgVXwTCIekmnOyj in AHiFRoBQENLKYdhDgVXwTCIekmnOyG.findall(AHiFRoBQENLKYdhDgVXwTCIekmnOxP+'AdaptationSet'):
   if AHiFRoBQENLKYdhDgVXwTCIekmnOyj.attrib.get('mimeType')=='video/mp4':
    for AHiFRoBQENLKYdhDgVXwTCIekmnOyx in AHiFRoBQENLKYdhDgVXwTCIekmnOyj.findall(AHiFRoBQENLKYdhDgVXwTCIekmnOxP+'Representation'):
     AHiFRoBQENLKYdhDgVXwTCIekmnOyJ=AHiFRoBQENLKYdhDgVXwTCIekmnOsx(AHiFRoBQENLKYdhDgVXwTCIekmnOyx.attrib.get('bandwidth'))
     if AHiFRoBQENLKYdhDgVXwTCIekmnOxv<AHiFRoBQENLKYdhDgVXwTCIekmnOyJ:AHiFRoBQENLKYdhDgVXwTCIekmnOxv=AHiFRoBQENLKYdhDgVXwTCIekmnOyJ
    for AHiFRoBQENLKYdhDgVXwTCIekmnOyx in AHiFRoBQENLKYdhDgVXwTCIekmnOyj.findall(AHiFRoBQENLKYdhDgVXwTCIekmnOxP+'Representation'):
     if AHiFRoBQENLKYdhDgVXwTCIekmnOxv>AHiFRoBQENLKYdhDgVXwTCIekmnOsx(AHiFRoBQENLKYdhDgVXwTCIekmnOyx.attrib.get('bandwidth')):
      AHiFRoBQENLKYdhDgVXwTCIekmnOyj.remove(AHiFRoBQENLKYdhDgVXwTCIekmnOyx)
   else:
    continue
  AHiFRoBQENLKYdhDgVXwTCIekmnOya=ET.tostring(AHiFRoBQENLKYdhDgVXwTCIekmnOxr).decode('utf-8')
  AHiFRoBQENLKYdhDgVXwTCIekmnOyf='<?xml version="1.0" encoding="UTF-8"?>\n'
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TextFile_Save(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV_STREAM_FILENAME,AHiFRoBQENLKYdhDgVXwTCIekmnOyf+AHiFRoBQENLKYdhDgVXwTCIekmnOya)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOsj
 def Tving_Parse_m3u8(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,stream_url):
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=requests.get(url=stream_url,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,stream=AHiFRoBQENLKYdhDgVXwTCIekmnOsj)
   AHiFRoBQENLKYdhDgVXwTCIekmnOys=AHiFRoBQENLKYdhDgVXwTCIekmnOjf.content.decode('utf-8')
   if '#EXTM3U' not in AHiFRoBQENLKYdhDgVXwTCIekmnOys:
    return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
   if '#EXT-X-STREAM-INF' not in AHiFRoBQENLKYdhDgVXwTCIekmnOys: 
    return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
   AHiFRoBQENLKYdhDgVXwTCIekmnOyq=0
   for AHiFRoBQENLKYdhDgVXwTCIekmnOyW in AHiFRoBQENLKYdhDgVXwTCIekmnOys.splitlines():
    if AHiFRoBQENLKYdhDgVXwTCIekmnOyW.startswith('#EXT-X-STREAM-INF'):
     AHiFRoBQENLKYdhDgVXwTCIekmnOyp=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.MediaLine_Parse(AHiFRoBQENLKYdhDgVXwTCIekmnOyW,'#EXT-X-STREAM-INF')
     if AHiFRoBQENLKYdhDgVXwTCIekmnOyq<AHiFRoBQENLKYdhDgVXwTCIekmnOsx(AHiFRoBQENLKYdhDgVXwTCIekmnOyp.get('BANDWIDTH')):
      AHiFRoBQENLKYdhDgVXwTCIekmnOyq=AHiFRoBQENLKYdhDgVXwTCIekmnOsx(AHiFRoBQENLKYdhDgVXwTCIekmnOyp.get('BANDWIDTH'))
   AHiFRoBQENLKYdhDgVXwTCIekmnOyM=[]
   AHiFRoBQENLKYdhDgVXwTCIekmnOyt=AHiFRoBQENLKYdhDgVXwTCIekmnOfc
   for AHiFRoBQENLKYdhDgVXwTCIekmnOyW in AHiFRoBQENLKYdhDgVXwTCIekmnOys.splitlines():
    if AHiFRoBQENLKYdhDgVXwTCIekmnOyt==AHiFRoBQENLKYdhDgVXwTCIekmnOsj:
     AHiFRoBQENLKYdhDgVXwTCIekmnOyt=AHiFRoBQENLKYdhDgVXwTCIekmnOfc
     continue
    if AHiFRoBQENLKYdhDgVXwTCIekmnOyW.startswith('#EXT-X-STREAM-INF'):
     AHiFRoBQENLKYdhDgVXwTCIekmnOyp=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.MediaLine_Parse(AHiFRoBQENLKYdhDgVXwTCIekmnOyW,'#EXT-X-STREAM-INF')
     if AHiFRoBQENLKYdhDgVXwTCIekmnOyq!=AHiFRoBQENLKYdhDgVXwTCIekmnOsx(AHiFRoBQENLKYdhDgVXwTCIekmnOyp.get('BANDWIDTH')):
      AHiFRoBQENLKYdhDgVXwTCIekmnOyt=AHiFRoBQENLKYdhDgVXwTCIekmnOsj
      continue
    AHiFRoBQENLKYdhDgVXwTCIekmnOyM.append(AHiFRoBQENLKYdhDgVXwTCIekmnOyW)
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
   return AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  AHiFRoBQENLKYdhDgVXwTCIekmnOyu='\n'.join(AHiFRoBQENLKYdhDgVXwTCIekmnOyM)
  AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TextFile_Save(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV_STREAM_FILENAME,AHiFRoBQENLKYdhDgVXwTCIekmnOyu)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOsj
 def MediaLine_Parse(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,AHiFRoBQENLKYdhDgVXwTCIekmnOyW,prefix):
  AHiFRoBQENLKYdhDgVXwTCIekmnOyp={}
  for AHiFRoBQENLKYdhDgVXwTCIekmnOyU in AHiFRoBQENLKYdhDgVXwTCIekmnOGJ.split(AHiFRoBQENLKYdhDgVXwTCIekmnOyW.replace(prefix+':',''))[1::2]:
   AHiFRoBQENLKYdhDgVXwTCIekmnOyl,AHiFRoBQENLKYdhDgVXwTCIekmnOyb=AHiFRoBQENLKYdhDgVXwTCIekmnOyU.split('=',1)
   AHiFRoBQENLKYdhDgVXwTCIekmnOyp[AHiFRoBQENLKYdhDgVXwTCIekmnOyl.upper()]=AHiFRoBQENLKYdhDgVXwTCIekmnOyb.replace('"','').strip()
  return AHiFRoBQENLKYdhDgVXwTCIekmnOyp
 def CheckQuality(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,sel_qt,AHiFRoBQENLKYdhDgVXwTCIekmnOxp):
  for AHiFRoBQENLKYdhDgVXwTCIekmnOyS in AHiFRoBQENLKYdhDgVXwTCIekmnOxp:
   if sel_qt>=AHiFRoBQENLKYdhDgVXwTCIekmnOsW(AHiFRoBQENLKYdhDgVXwTCIekmnOyS)[0]:return AHiFRoBQENLKYdhDgVXwTCIekmnOyS.get(AHiFRoBQENLKYdhDgVXwTCIekmnOsW(AHiFRoBQENLKYdhDgVXwTCIekmnOyS)[0])
   AHiFRoBQENLKYdhDgVXwTCIekmnOyv=AHiFRoBQENLKYdhDgVXwTCIekmnOyS.get(AHiFRoBQENLKYdhDgVXwTCIekmnOsW(AHiFRoBQENLKYdhDgVXwTCIekmnOyS)[0])
  return AHiFRoBQENLKYdhDgVXwTCIekmnOyv
 def makeOocUrl(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,ooc_params):
  AHiFRoBQENLKYdhDgVXwTCIekmnOxq=''
  for AHiFRoBQENLKYdhDgVXwTCIekmnOGS,AHiFRoBQENLKYdhDgVXwTCIekmnOjc in ooc_params.items():
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq+="%s=%s^"%(AHiFRoBQENLKYdhDgVXwTCIekmnOGS,AHiFRoBQENLKYdhDgVXwTCIekmnOjc)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOxq
 def GetLiveChannelList(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,stype,page_int):
  AHiFRoBQENLKYdhDgVXwTCIekmnOju=[]
  AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v2/media/lives'
   if stype=='onair': 
    AHiFRoBQENLKYdhDgVXwTCIekmnOyr='CPCS0100,CPCS0400'
   else:
    AHiFRoBQENLKYdhDgVXwTCIekmnOyr='CPCS0300'
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'cacheType':'main','pageNo':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(page_int),'pageSize':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':AHiFRoBQENLKYdhDgVXwTCIekmnOyr,}
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs.update(AHiFRoBQENLKYdhDgVXwTCIekmnOjb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjp
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOxs,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjS=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   if not('result' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']):return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
   AHiFRoBQENLKYdhDgVXwTCIekmnOyP=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['result']
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjv in AHiFRoBQENLKYdhDgVXwTCIekmnOyP:
    AHiFRoBQENLKYdhDgVXwTCIekmnOyc=AHiFRoBQENLKYdhDgVXwTCIekmnOJx=AHiFRoBQENLKYdhDgVXwTCIekmnOJy=''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJG=AHiFRoBQENLKYdhDgVXwTCIekmnOJP=''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJj=AHiFRoBQENLKYdhDgVXwTCIekmnOjv['live_code']
    AHiFRoBQENLKYdhDgVXwTCIekmnOyc =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['channel']['name']['ko']
    if AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['episode']!=AHiFRoBQENLKYdhDgVXwTCIekmnOfP:
     AHiFRoBQENLKYdhDgVXwTCIekmnOJx =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['program']['name']['ko']
     AHiFRoBQENLKYdhDgVXwTCIekmnOJx =AHiFRoBQENLKYdhDgVXwTCIekmnOJx+', '+AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['episode']['frequency'])+'회'
     AHiFRoBQENLKYdhDgVXwTCIekmnOJy=AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['episode']['synopsis']['ko']
    else:
     AHiFRoBQENLKYdhDgVXwTCIekmnOJx =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['program']['name']['ko']
     AHiFRoBQENLKYdhDgVXwTCIekmnOJy=AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['program']['synopsis']['ko']
    try: 
     AHiFRoBQENLKYdhDgVXwTCIekmnOJa =''
     AHiFRoBQENLKYdhDgVXwTCIekmnOJf =''
     AHiFRoBQENLKYdhDgVXwTCIekmnOJs=''
     AHiFRoBQENLKYdhDgVXwTCIekmnOJq =''
     AHiFRoBQENLKYdhDgVXwTCIekmnOJW =''
     AHiFRoBQENLKYdhDgVXwTCIekmnOJp =''
     for AHiFRoBQENLKYdhDgVXwTCIekmnOJM in AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['program']['image']:
      if AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP0900':AHiFRoBQENLKYdhDgVXwTCIekmnOJf =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
      elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP1800':AHiFRoBQENLKYdhDgVXwTCIekmnOJs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
      elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP2000':AHiFRoBQENLKYdhDgVXwTCIekmnOJq =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
      elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP1900':AHiFRoBQENLKYdhDgVXwTCIekmnOJW =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
      elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP0200':AHiFRoBQENLKYdhDgVXwTCIekmnOJp =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
      elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP0500':AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
      elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP0800':AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     if AHiFRoBQENLKYdhDgVXwTCIekmnOJa=='':
      for AHiFRoBQENLKYdhDgVXwTCIekmnOJM in AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['channel']['image']:
       if AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIC0400':AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
       elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIC1400':AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
       elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIC1900':AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
    except:
     AHiFRoBQENLKYdhDgVXwTCIekmnOfP
    try:
     AHiFRoBQENLKYdhDgVXwTCIekmnOJt =[]
     AHiFRoBQENLKYdhDgVXwTCIekmnOJu=[]
     AHiFRoBQENLKYdhDgVXwTCIekmnOJU =[]
     AHiFRoBQENLKYdhDgVXwTCIekmnOJl=''
     AHiFRoBQENLKYdhDgVXwTCIekmnOJb=''
     AHiFRoBQENLKYdhDgVXwTCIekmnOJS=''
     for AHiFRoBQENLKYdhDgVXwTCIekmnOJv in AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('schedule').get('program').get('actor'):
      if AHiFRoBQENLKYdhDgVXwTCIekmnOJv!='' and AHiFRoBQENLKYdhDgVXwTCIekmnOJv!=u'없음':AHiFRoBQENLKYdhDgVXwTCIekmnOJt.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJv)
     for AHiFRoBQENLKYdhDgVXwTCIekmnOJz in AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('schedule').get('program').get('director'):
      if AHiFRoBQENLKYdhDgVXwTCIekmnOJz!='' and AHiFRoBQENLKYdhDgVXwTCIekmnOJz!='-' and AHiFRoBQENLKYdhDgVXwTCIekmnOJz!=u'없음':AHiFRoBQENLKYdhDgVXwTCIekmnOJu.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJz)
     if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('schedule').get('program').get('category1_name').get('ko')!='':
      AHiFRoBQENLKYdhDgVXwTCIekmnOJU.append(AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['program']['category1_name']['ko'])
     if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('schedule').get('program').get('category2_name').get('ko')!='':
      AHiFRoBQENLKYdhDgVXwTCIekmnOJU.append(AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['program']['category2_name']['ko'])
     if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('schedule').get('program').get('product_year'):AHiFRoBQENLKYdhDgVXwTCIekmnOJl=AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['program']['product_year']
     if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('schedule').get('program').get('grade_code') :AHiFRoBQENLKYdhDgVXwTCIekmnOJb= AHiFRoBQENLKYdhDgVXwTCIekmnOGy.get(AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['program']['grade_code'])
     if 'broad_dt' in AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('schedule').get('program'):
      AHiFRoBQENLKYdhDgVXwTCIekmnOJr =AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('schedule').get('program').get('broad_dt')
      AHiFRoBQENLKYdhDgVXwTCIekmnOJS='%s-%s-%s'%(AHiFRoBQENLKYdhDgVXwTCIekmnOJr[:4],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[4:6],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[6:])
    except:
     AHiFRoBQENLKYdhDgVXwTCIekmnOfP
    AHiFRoBQENLKYdhDgVXwTCIekmnOJG=AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['broadcast_start_time'])[8:12]
    AHiFRoBQENLKYdhDgVXwTCIekmnOJP =AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOjv['schedule']['broadcast_end_time'])[8:12]
    AHiFRoBQENLKYdhDgVXwTCIekmnOJc={'channel':AHiFRoBQENLKYdhDgVXwTCIekmnOyc,'title':AHiFRoBQENLKYdhDgVXwTCIekmnOJx,'mediacode':AHiFRoBQENLKYdhDgVXwTCIekmnOJj,'thumbnail':{'poster':AHiFRoBQENLKYdhDgVXwTCIekmnOJf,'thumb':AHiFRoBQENLKYdhDgVXwTCIekmnOJa,'clearlogo':AHiFRoBQENLKYdhDgVXwTCIekmnOJs,'icon':AHiFRoBQENLKYdhDgVXwTCIekmnOJq,'fanart':AHiFRoBQENLKYdhDgVXwTCIekmnOJp},'synopsis':AHiFRoBQENLKYdhDgVXwTCIekmnOJy,'channelepg':' [%s:%s ~ %s:%s]'%(AHiFRoBQENLKYdhDgVXwTCIekmnOJG[0:2],AHiFRoBQENLKYdhDgVXwTCIekmnOJG[2:],AHiFRoBQENLKYdhDgVXwTCIekmnOJP[0:2],AHiFRoBQENLKYdhDgVXwTCIekmnOJP[2:]),'cast':AHiFRoBQENLKYdhDgVXwTCIekmnOJt,'director':AHiFRoBQENLKYdhDgVXwTCIekmnOJu,'info_genre':AHiFRoBQENLKYdhDgVXwTCIekmnOJU,'year':AHiFRoBQENLKYdhDgVXwTCIekmnOJl,'mpaa':AHiFRoBQENLKYdhDgVXwTCIekmnOJb,'premiered':AHiFRoBQENLKYdhDgVXwTCIekmnOJS}
    AHiFRoBQENLKYdhDgVXwTCIekmnOju.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJc)
   if AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['has_more']=='Y':
    AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOsj
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
 def GetProgramList(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,genre,orderby,page_int,genreCode='all'):
  AHiFRoBQENLKYdhDgVXwTCIekmnOju=[]
  AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  try:
   if genre=='PARAMOUNT':
    AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v2/media/paramount/episodes'
   else:
    AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v2/media/episodes'
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'cacheType':'main','pageSize':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(page_int),}
   if genre not in['all','PARAMOUNT']:AHiFRoBQENLKYdhDgVXwTCIekmnOjb['categoryCode']=genre
   if genreCode!='all' :AHiFRoBQENLKYdhDgVXwTCIekmnOjb['genreCode'] =genreCode 
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs.update(AHiFRoBQENLKYdhDgVXwTCIekmnOjb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjp
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOxs,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjS=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   if not('result' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']):return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
   AHiFRoBQENLKYdhDgVXwTCIekmnOyP=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['result']
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjv in AHiFRoBQENLKYdhDgVXwTCIekmnOyP:
    AHiFRoBQENLKYdhDgVXwTCIekmnOaG=AHiFRoBQENLKYdhDgVXwTCIekmnOjv['program']['code']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJx =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['program']['name']['ko']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJb =AHiFRoBQENLKYdhDgVXwTCIekmnOGy.get(AHiFRoBQENLKYdhDgVXwTCIekmnOjv['program'].get('grade_code'))
    AHiFRoBQENLKYdhDgVXwTCIekmnOJf =''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJa =''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJs=''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJq =''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJW =''
    for AHiFRoBQENLKYdhDgVXwTCIekmnOJM in AHiFRoBQENLKYdhDgVXwTCIekmnOjv['program']['image']:
     if AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP0900':AHiFRoBQENLKYdhDgVXwTCIekmnOJf =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP0200':AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP1800':AHiFRoBQENLKYdhDgVXwTCIekmnOJs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP2000':AHiFRoBQENLKYdhDgVXwTCIekmnOJq =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP1900':AHiFRoBQENLKYdhDgVXwTCIekmnOJW =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJy =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['program']['synopsis']['ko']
    try:
     AHiFRoBQENLKYdhDgVXwTCIekmnOaj=AHiFRoBQENLKYdhDgVXwTCIekmnOjv['channel']['name']['ko']
    except:
     AHiFRoBQENLKYdhDgVXwTCIekmnOaj=''
    try:
     AHiFRoBQENLKYdhDgVXwTCIekmnOJt =[]
     AHiFRoBQENLKYdhDgVXwTCIekmnOJu=[]
     AHiFRoBQENLKYdhDgVXwTCIekmnOJU =[]
     AHiFRoBQENLKYdhDgVXwTCIekmnOJl =''
     AHiFRoBQENLKYdhDgVXwTCIekmnOJS=''
     for AHiFRoBQENLKYdhDgVXwTCIekmnOJv in AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('program').get('actor'):
      if AHiFRoBQENLKYdhDgVXwTCIekmnOJv!='' and AHiFRoBQENLKYdhDgVXwTCIekmnOJv!='-' and AHiFRoBQENLKYdhDgVXwTCIekmnOJv!=u'없음':AHiFRoBQENLKYdhDgVXwTCIekmnOJt.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJv)
     for AHiFRoBQENLKYdhDgVXwTCIekmnOJz in AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('program').get('director'):
      if AHiFRoBQENLKYdhDgVXwTCIekmnOJz!='' and AHiFRoBQENLKYdhDgVXwTCIekmnOJz!='-' and AHiFRoBQENLKYdhDgVXwTCIekmnOJz!=u'없음':AHiFRoBQENLKYdhDgVXwTCIekmnOJu.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJz)
     if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('program').get('category1_name').get('ko')!='':
      AHiFRoBQENLKYdhDgVXwTCIekmnOJU.append(AHiFRoBQENLKYdhDgVXwTCIekmnOjv['program']['category1_name']['ko'])
     if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('program').get('category2_name').get('ko')!='':
      AHiFRoBQENLKYdhDgVXwTCIekmnOJU.append(AHiFRoBQENLKYdhDgVXwTCIekmnOjv['program']['category2_name']['ko'])
     if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('program').get('product_year'):AHiFRoBQENLKYdhDgVXwTCIekmnOJl=AHiFRoBQENLKYdhDgVXwTCIekmnOjv['program']['product_year']
     if 'broad_dt' in AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('program'):
      AHiFRoBQENLKYdhDgVXwTCIekmnOJr =AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('program').get('broad_dt')
      AHiFRoBQENLKYdhDgVXwTCIekmnOJS='%s-%s-%s'%(AHiFRoBQENLKYdhDgVXwTCIekmnOJr[:4],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[4:6],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[6:])
    except:
     AHiFRoBQENLKYdhDgVXwTCIekmnOfP
    AHiFRoBQENLKYdhDgVXwTCIekmnOJc={'program':AHiFRoBQENLKYdhDgVXwTCIekmnOaG,'title':AHiFRoBQENLKYdhDgVXwTCIekmnOJx,'thumbnail':{'poster':AHiFRoBQENLKYdhDgVXwTCIekmnOJf,'thumb':AHiFRoBQENLKYdhDgVXwTCIekmnOJa,'clearlogo':AHiFRoBQENLKYdhDgVXwTCIekmnOJs,'icon':AHiFRoBQENLKYdhDgVXwTCIekmnOJq,'banner':AHiFRoBQENLKYdhDgVXwTCIekmnOJW,'fanart':AHiFRoBQENLKYdhDgVXwTCIekmnOJa},'synopsis':AHiFRoBQENLKYdhDgVXwTCIekmnOJy,'channel':AHiFRoBQENLKYdhDgVXwTCIekmnOaj,'cast':AHiFRoBQENLKYdhDgVXwTCIekmnOJt,'director':AHiFRoBQENLKYdhDgVXwTCIekmnOJu,'info_genre':AHiFRoBQENLKYdhDgVXwTCIekmnOJU,'year':AHiFRoBQENLKYdhDgVXwTCIekmnOJl,'premiered':AHiFRoBQENLKYdhDgVXwTCIekmnOJS,'mpaa':AHiFRoBQENLKYdhDgVXwTCIekmnOJb}
    AHiFRoBQENLKYdhDgVXwTCIekmnOju.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJc)
   if AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['has_more']=='Y':AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOsj
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
 def Get_UHD_ProgramList(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,page_int):
  AHiFRoBQENLKYdhDgVXwTCIekmnOju=[]
  AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v2/operator/highlights'
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams(uhd=AHiFRoBQENLKYdhDgVXwTCIekmnOsj)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(page_int),'pocType':'APP_X_TVING_4.0.0',}
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs.update(AHiFRoBQENLKYdhDgVXwTCIekmnOjb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjp
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOxs,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjS=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   if not('result' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']):return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
   AHiFRoBQENLKYdhDgVXwTCIekmnOyP=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['result']
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjv in AHiFRoBQENLKYdhDgVXwTCIekmnOyP:
    AHiFRoBQENLKYdhDgVXwTCIekmnOax=AHiFRoBQENLKYdhDgVXwTCIekmnOjv['content']['program']
    AHiFRoBQENLKYdhDgVXwTCIekmnOay =AHiFRoBQENLKYdhDgVXwTCIekmnOax['code']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJx =AHiFRoBQENLKYdhDgVXwTCIekmnOax['name']['ko'].strip()
    AHiFRoBQENLKYdhDgVXwTCIekmnOJb =AHiFRoBQENLKYdhDgVXwTCIekmnOGy.get(AHiFRoBQENLKYdhDgVXwTCIekmnOax.get('grade_code'))
    AHiFRoBQENLKYdhDgVXwTCIekmnOJy =AHiFRoBQENLKYdhDgVXwTCIekmnOax['synopsis']['ko']
    AHiFRoBQENLKYdhDgVXwTCIekmnOaj =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['content']['channel']['name']['ko']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJl =AHiFRoBQENLKYdhDgVXwTCIekmnOax['product_year']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJf =''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJa =''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJs=''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJq =''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJW =''
    for AHiFRoBQENLKYdhDgVXwTCIekmnOJM in AHiFRoBQENLKYdhDgVXwTCIekmnOax['image']:
     if AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP0900':AHiFRoBQENLKYdhDgVXwTCIekmnOJf =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP0200':AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP1800':AHiFRoBQENLKYdhDgVXwTCIekmnOJs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP2000':AHiFRoBQENLKYdhDgVXwTCIekmnOJq =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP1900':AHiFRoBQENLKYdhDgVXwTCIekmnOJW =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJU =[]
    AHiFRoBQENLKYdhDgVXwTCIekmnOJt =[]
    AHiFRoBQENLKYdhDgVXwTCIekmnOJu=[]
    AHiFRoBQENLKYdhDgVXwTCIekmnOJS =''
    if AHiFRoBQENLKYdhDgVXwTCIekmnOax.get('category1_name').get('ko')!='':
     AHiFRoBQENLKYdhDgVXwTCIekmnOJU.append(AHiFRoBQENLKYdhDgVXwTCIekmnOax['category1_name']['ko'])
    if AHiFRoBQENLKYdhDgVXwTCIekmnOax.get('category2_name').get('ko')!='':
     AHiFRoBQENLKYdhDgVXwTCIekmnOJU.append(AHiFRoBQENLKYdhDgVXwTCIekmnOax['category2_name']['ko'])
    for AHiFRoBQENLKYdhDgVXwTCIekmnOJv in AHiFRoBQENLKYdhDgVXwTCIekmnOax.get('actor'):
     if AHiFRoBQENLKYdhDgVXwTCIekmnOJv!='' and AHiFRoBQENLKYdhDgVXwTCIekmnOJv!='-' and AHiFRoBQENLKYdhDgVXwTCIekmnOJv!=u'없음':AHiFRoBQENLKYdhDgVXwTCIekmnOJt.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJv)
    for AHiFRoBQENLKYdhDgVXwTCIekmnOJz in AHiFRoBQENLKYdhDgVXwTCIekmnOax.get('director'):
     if AHiFRoBQENLKYdhDgVXwTCIekmnOJz!='' and AHiFRoBQENLKYdhDgVXwTCIekmnOJz!='-' and AHiFRoBQENLKYdhDgVXwTCIekmnOJz!=u'없음':AHiFRoBQENLKYdhDgVXwTCIekmnOJu.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJz)
    if AHiFRoBQENLKYdhDgVXwTCIekmnOax.get('broad_dt')not in[AHiFRoBQENLKYdhDgVXwTCIekmnOfP,'']:
     AHiFRoBQENLKYdhDgVXwTCIekmnOJr =AHiFRoBQENLKYdhDgVXwTCIekmnOax.get('broad_dt')
     AHiFRoBQENLKYdhDgVXwTCIekmnOJS='%s-%s-%s'%(AHiFRoBQENLKYdhDgVXwTCIekmnOJr[:4],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[4:6],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[6:])
    AHiFRoBQENLKYdhDgVXwTCIekmnOJc={'program':AHiFRoBQENLKYdhDgVXwTCIekmnOay,'title':AHiFRoBQENLKYdhDgVXwTCIekmnOJx,'mpaa':AHiFRoBQENLKYdhDgVXwTCIekmnOJb,'thumbnail':{'poster':AHiFRoBQENLKYdhDgVXwTCIekmnOJf,'thumb':AHiFRoBQENLKYdhDgVXwTCIekmnOJa,'clearlogo':AHiFRoBQENLKYdhDgVXwTCIekmnOJs,'icon':AHiFRoBQENLKYdhDgVXwTCIekmnOJq,'banner':AHiFRoBQENLKYdhDgVXwTCIekmnOJW,'fanart':AHiFRoBQENLKYdhDgVXwTCIekmnOJa},'channel':AHiFRoBQENLKYdhDgVXwTCIekmnOaj,'synopsis':AHiFRoBQENLKYdhDgVXwTCIekmnOJy,'year':AHiFRoBQENLKYdhDgVXwTCIekmnOJl,'info_genre':AHiFRoBQENLKYdhDgVXwTCIekmnOJU,'cast':AHiFRoBQENLKYdhDgVXwTCIekmnOJt,'director':AHiFRoBQENLKYdhDgVXwTCIekmnOJu,'premiered':AHiFRoBQENLKYdhDgVXwTCIekmnOJS,}
    AHiFRoBQENLKYdhDgVXwTCIekmnOju.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJc)
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
 def Get_Origianl_ProgramList(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,page_int):
  AHiFRoBQENLKYdhDgVXwTCIekmnOju=[]
  AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v2/media/band/originals'
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'pageSize':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(page_int),}
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs.update(AHiFRoBQENLKYdhDgVXwTCIekmnOjb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjp
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOxs,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   AHiFRoBQENLKYdhDgVXwTCIekmnOaJ=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   AHiFRoBQENLKYdhDgVXwTCIekmnOGf.JsonFile_Save(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV_SESSION_COOKIES2,AHiFRoBQENLKYdhDgVXwTCIekmnOaJ)
   if not('contents' in AHiFRoBQENLKYdhDgVXwTCIekmnOaJ['body']):return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
   AHiFRoBQENLKYdhDgVXwTCIekmnOyP=AHiFRoBQENLKYdhDgVXwTCIekmnOaJ['body']['contents']
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjv in AHiFRoBQENLKYdhDgVXwTCIekmnOyP:
    AHiFRoBQENLKYdhDgVXwTCIekmnOaf =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['vod_code']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJx =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['vod_name']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJf =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjv['image']
    AHiFRoBQENLKYdhDgVXwTCIekmnOas ='movie' if AHiFRoBQENLKYdhDgVXwTCIekmnOaf.startswith('M')else 'vod'
    AHiFRoBQENLKYdhDgVXwTCIekmnOJc={'vod_code':AHiFRoBQENLKYdhDgVXwTCIekmnOaf,'title':AHiFRoBQENLKYdhDgVXwTCIekmnOJx,'thumbnail':{'poster':AHiFRoBQENLKYdhDgVXwTCIekmnOJf,'thumb':AHiFRoBQENLKYdhDgVXwTCIekmnOJf},'vod_type':AHiFRoBQENLKYdhDgVXwTCIekmnOas,}
    AHiFRoBQENLKYdhDgVXwTCIekmnOju.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJc)
   if AHiFRoBQENLKYdhDgVXwTCIekmnOaJ['body']['has_more']=='Y':AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOsj
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
 def GetEpisodeList(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,program_code,page_int,orderby='desc'):
  AHiFRoBQENLKYdhDgVXwTCIekmnOju=[]
  AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v2/media/frequency/program/'+program_code
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs.update(AHiFRoBQENLKYdhDgVXwTCIekmnOjb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjp
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOxs,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjS=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   if not('result' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']):return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
   AHiFRoBQENLKYdhDgVXwTCIekmnOyP=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['result']
   AHiFRoBQENLKYdhDgVXwTCIekmnOaq=AHiFRoBQENLKYdhDgVXwTCIekmnOsx(AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['total_count'])
   AHiFRoBQENLKYdhDgVXwTCIekmnOaW =AHiFRoBQENLKYdhDgVXwTCIekmnOsx(AHiFRoBQENLKYdhDgVXwTCIekmnOaq//(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    AHiFRoBQENLKYdhDgVXwTCIekmnOap =(AHiFRoBQENLKYdhDgVXwTCIekmnOaq-1)-((page_int-1)*AHiFRoBQENLKYdhDgVXwTCIekmnOGf.EPISODE_LIMIT)
   else:
    AHiFRoBQENLKYdhDgVXwTCIekmnOap =(page_int-1)*AHiFRoBQENLKYdhDgVXwTCIekmnOGf.EPISODE_LIMIT
   for i in AHiFRoBQENLKYdhDgVXwTCIekmnOsy(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.EPISODE_LIMIT):
    if orderby=='desc':
     AHiFRoBQENLKYdhDgVXwTCIekmnOaM=AHiFRoBQENLKYdhDgVXwTCIekmnOap-i
     if AHiFRoBQENLKYdhDgVXwTCIekmnOaM<0:break
    else:
     AHiFRoBQENLKYdhDgVXwTCIekmnOaM=AHiFRoBQENLKYdhDgVXwTCIekmnOap+i
     if AHiFRoBQENLKYdhDgVXwTCIekmnOaM>=AHiFRoBQENLKYdhDgVXwTCIekmnOaq:break
    AHiFRoBQENLKYdhDgVXwTCIekmnOat=AHiFRoBQENLKYdhDgVXwTCIekmnOyP[AHiFRoBQENLKYdhDgVXwTCIekmnOaM]['episode']['code']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJx =AHiFRoBQENLKYdhDgVXwTCIekmnOyP[AHiFRoBQENLKYdhDgVXwTCIekmnOaM]['vod_name']['ko']
    AHiFRoBQENLKYdhDgVXwTCIekmnOau =''
    try:
     AHiFRoBQENLKYdhDgVXwTCIekmnOJr=AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOyP[AHiFRoBQENLKYdhDgVXwTCIekmnOaM]['episode']['broadcast_date'])
     AHiFRoBQENLKYdhDgVXwTCIekmnOau='%s-%s-%s'%(AHiFRoBQENLKYdhDgVXwTCIekmnOJr[:4],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[4:6],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[6:])
    except:
     AHiFRoBQENLKYdhDgVXwTCIekmnOfP
    try:
     if AHiFRoBQENLKYdhDgVXwTCIekmnOyP[AHiFRoBQENLKYdhDgVXwTCIekmnOaM]['episode']['pip_cliptype']=='C012':
      AHiFRoBQENLKYdhDgVXwTCIekmnOau+=' - Quick VOD'
    except:
     AHiFRoBQENLKYdhDgVXwTCIekmnOfP
    AHiFRoBQENLKYdhDgVXwTCIekmnOJy =AHiFRoBQENLKYdhDgVXwTCIekmnOyP[AHiFRoBQENLKYdhDgVXwTCIekmnOaM]['episode']['synopsis']['ko']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJf =''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJa =''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJs=''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJq =''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJW =''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJp =''
    for AHiFRoBQENLKYdhDgVXwTCIekmnOJM in AHiFRoBQENLKYdhDgVXwTCIekmnOyP[AHiFRoBQENLKYdhDgVXwTCIekmnOaM]['program']['image']:
     if AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP0900':AHiFRoBQENLKYdhDgVXwTCIekmnOJf =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP1800':AHiFRoBQENLKYdhDgVXwTCIekmnOJs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP2000':AHiFRoBQENLKYdhDgVXwTCIekmnOJq =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP1900':AHiFRoBQENLKYdhDgVXwTCIekmnOJW =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIP0200':AHiFRoBQENLKYdhDgVXwTCIekmnOJp =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
    for AHiFRoBQENLKYdhDgVXwTCIekmnOJM in AHiFRoBQENLKYdhDgVXwTCIekmnOyP[AHiFRoBQENLKYdhDgVXwTCIekmnOaM]['episode']['image']:
     if AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIE0400':AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
    try:
     AHiFRoBQENLKYdhDgVXwTCIekmnOaU=AHiFRoBQENLKYdhDgVXwTCIekmnOab=AHiFRoBQENLKYdhDgVXwTCIekmnOaS=''
     AHiFRoBQENLKYdhDgVXwTCIekmnOal=0
     AHiFRoBQENLKYdhDgVXwTCIekmnOaU =AHiFRoBQENLKYdhDgVXwTCIekmnOyP[AHiFRoBQENLKYdhDgVXwTCIekmnOaM]['program']['name']['ko']
     AHiFRoBQENLKYdhDgVXwTCIekmnOab =AHiFRoBQENLKYdhDgVXwTCIekmnOau
     AHiFRoBQENLKYdhDgVXwTCIekmnOaS =AHiFRoBQENLKYdhDgVXwTCIekmnOyP[AHiFRoBQENLKYdhDgVXwTCIekmnOaM]['channel']['name']['ko']
     if 'frequency' in AHiFRoBQENLKYdhDgVXwTCIekmnOyP[AHiFRoBQENLKYdhDgVXwTCIekmnOaM]['episode']:AHiFRoBQENLKYdhDgVXwTCIekmnOal=AHiFRoBQENLKYdhDgVXwTCIekmnOyP[AHiFRoBQENLKYdhDgVXwTCIekmnOaM]['episode']['frequency']
    except:
     AHiFRoBQENLKYdhDgVXwTCIekmnOfP
    AHiFRoBQENLKYdhDgVXwTCIekmnOJc={'episode':AHiFRoBQENLKYdhDgVXwTCIekmnOat,'title':AHiFRoBQENLKYdhDgVXwTCIekmnOJx,'subtitle':AHiFRoBQENLKYdhDgVXwTCIekmnOau,'thumbnail':{'poster':AHiFRoBQENLKYdhDgVXwTCIekmnOJf,'thumb':AHiFRoBQENLKYdhDgVXwTCIekmnOJa,'clearlogo':AHiFRoBQENLKYdhDgVXwTCIekmnOJs,'icon':AHiFRoBQENLKYdhDgVXwTCIekmnOJq,'banner':AHiFRoBQENLKYdhDgVXwTCIekmnOJW,'fanart':AHiFRoBQENLKYdhDgVXwTCIekmnOJp},'synopsis':AHiFRoBQENLKYdhDgVXwTCIekmnOJy,'info_title':AHiFRoBQENLKYdhDgVXwTCIekmnOaU,'aired':AHiFRoBQENLKYdhDgVXwTCIekmnOab,'studio':AHiFRoBQENLKYdhDgVXwTCIekmnOaS,'frequency':AHiFRoBQENLKYdhDgVXwTCIekmnOal}
    AHiFRoBQENLKYdhDgVXwTCIekmnOju.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJc)
   if AHiFRoBQENLKYdhDgVXwTCIekmnOaW>page_int:AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOsj
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz,AHiFRoBQENLKYdhDgVXwTCIekmnOaW
 def GetMovieList(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,genre,orderby,page_int):
  AHiFRoBQENLKYdhDgVXwTCIekmnOju=[]
  AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  try:
   if genre=='PARAMOUNT':
    AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v2/media/paramount/movies'
   else:
    AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v2/media/movies'
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'pageSize':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:AHiFRoBQENLKYdhDgVXwTCIekmnOjb['categoryCode']=genre
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb['productPackageCode']=','.join(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.MOVIE_LITE)
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs.update(AHiFRoBQENLKYdhDgVXwTCIekmnOjb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjp
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOxs,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjS=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   if not('result' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']):return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
   AHiFRoBQENLKYdhDgVXwTCIekmnOyP=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['result']
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjv in AHiFRoBQENLKYdhDgVXwTCIekmnOyP:
    if 'release_date' in AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('movie'):
     AHiFRoBQENLKYdhDgVXwTCIekmnOJl=AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('movie').get('release_date'))[:4]
    else:
     AHiFRoBQENLKYdhDgVXwTCIekmnOJl=AHiFRoBQENLKYdhDgVXwTCIekmnOfP
    AHiFRoBQENLKYdhDgVXwTCIekmnOav =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['movie']['code']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJx =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['movie']['name']['ko'].strip()
    if AHiFRoBQENLKYdhDgVXwTCIekmnOJl not in[AHiFRoBQENLKYdhDgVXwTCIekmnOfP,'0','']:AHiFRoBQENLKYdhDgVXwTCIekmnOJx+=u' (%s)'%(AHiFRoBQENLKYdhDgVXwTCIekmnOJl)
    AHiFRoBQENLKYdhDgVXwTCIekmnOJf=''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJa =''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJs=''
    for AHiFRoBQENLKYdhDgVXwTCIekmnOJM in AHiFRoBQENLKYdhDgVXwTCIekmnOjv['movie']['image']:
     if AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIM2100':AHiFRoBQENLKYdhDgVXwTCIekmnOJf =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIM0400':AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIM1800':AHiFRoBQENLKYdhDgVXwTCIekmnOJs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJy =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['movie']['story']['ko']
    try:
     AHiFRoBQENLKYdhDgVXwTCIekmnOaU =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['movie']['name']['ko'].strip()
     AHiFRoBQENLKYdhDgVXwTCIekmnOJb =AHiFRoBQENLKYdhDgVXwTCIekmnOGy.get(AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('grade_code'))
     AHiFRoBQENLKYdhDgVXwTCIekmnOJt=[]
     AHiFRoBQENLKYdhDgVXwTCIekmnOJu=[]
     AHiFRoBQENLKYdhDgVXwTCIekmnOJU=[]
     AHiFRoBQENLKYdhDgVXwTCIekmnOaz=0
     AHiFRoBQENLKYdhDgVXwTCIekmnOJS=''
     AHiFRoBQENLKYdhDgVXwTCIekmnOaS =''
     for AHiFRoBQENLKYdhDgVXwTCIekmnOJv in AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('movie').get('actor'):
      if AHiFRoBQENLKYdhDgVXwTCIekmnOJv!='':AHiFRoBQENLKYdhDgVXwTCIekmnOJt.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJv)
     for AHiFRoBQENLKYdhDgVXwTCIekmnOJz in AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('movie').get('director'):
      if AHiFRoBQENLKYdhDgVXwTCIekmnOJz!='':AHiFRoBQENLKYdhDgVXwTCIekmnOJu.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJz)
     if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('movie').get('category1_name').get('ko')!='':
      AHiFRoBQENLKYdhDgVXwTCIekmnOJU.append(AHiFRoBQENLKYdhDgVXwTCIekmnOjv['movie']['category1_name']['ko'])
     if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('movie').get('category2_name').get('ko')!='':
      AHiFRoBQENLKYdhDgVXwTCIekmnOJU.append(AHiFRoBQENLKYdhDgVXwTCIekmnOjv['movie']['category2_name']['ko'])
     if 'duration' in AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('movie'):AHiFRoBQENLKYdhDgVXwTCIekmnOaz=AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('movie').get('duration')
     if 'release_date' in AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('movie'):
      AHiFRoBQENLKYdhDgVXwTCIekmnOJr=AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('movie').get('release_date'))
      if AHiFRoBQENLKYdhDgVXwTCIekmnOJr!='0':AHiFRoBQENLKYdhDgVXwTCIekmnOJS='%s-%s-%s'%(AHiFRoBQENLKYdhDgVXwTCIekmnOJr[:4],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[4:6],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[6:])
     if 'production' in AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('movie'):AHiFRoBQENLKYdhDgVXwTCIekmnOaS=AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('movie').get('production')
    except:
     AHiFRoBQENLKYdhDgVXwTCIekmnOfP
    AHiFRoBQENLKYdhDgVXwTCIekmnOJc={'moviecode':AHiFRoBQENLKYdhDgVXwTCIekmnOav,'title':AHiFRoBQENLKYdhDgVXwTCIekmnOJx,'thumbnail':{'poster':AHiFRoBQENLKYdhDgVXwTCIekmnOJf,'thumb':AHiFRoBQENLKYdhDgVXwTCIekmnOJa,'clearlogo':AHiFRoBQENLKYdhDgVXwTCIekmnOJs,'fanart':AHiFRoBQENLKYdhDgVXwTCIekmnOJa},'synopsis':AHiFRoBQENLKYdhDgVXwTCIekmnOJy,'info_title':AHiFRoBQENLKYdhDgVXwTCIekmnOaU,'year':AHiFRoBQENLKYdhDgVXwTCIekmnOJl,'cast':AHiFRoBQENLKYdhDgVXwTCIekmnOJt,'director':AHiFRoBQENLKYdhDgVXwTCIekmnOJu,'info_genre':AHiFRoBQENLKYdhDgVXwTCIekmnOJU,'duration':AHiFRoBQENLKYdhDgVXwTCIekmnOaz,'premiered':AHiFRoBQENLKYdhDgVXwTCIekmnOJS,'studio':AHiFRoBQENLKYdhDgVXwTCIekmnOaS,'mpaa':AHiFRoBQENLKYdhDgVXwTCIekmnOJb}
    AHiFRoBQENLKYdhDgVXwTCIekmnOar=AHiFRoBQENLKYdhDgVXwTCIekmnOfc
    for AHiFRoBQENLKYdhDgVXwTCIekmnOaP in AHiFRoBQENLKYdhDgVXwTCIekmnOjv['billing_package_id']:
     if AHiFRoBQENLKYdhDgVXwTCIekmnOaP in AHiFRoBQENLKYdhDgVXwTCIekmnOGf.MOVIE_LITE:
      AHiFRoBQENLKYdhDgVXwTCIekmnOar=AHiFRoBQENLKYdhDgVXwTCIekmnOsj
      break
    if AHiFRoBQENLKYdhDgVXwTCIekmnOar==AHiFRoBQENLKYdhDgVXwTCIekmnOfc: 
     AHiFRoBQENLKYdhDgVXwTCIekmnOJc['title']=AHiFRoBQENLKYdhDgVXwTCIekmnOJc['title']+' [개별구매]'
    AHiFRoBQENLKYdhDgVXwTCIekmnOju.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJc)
   if AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['has_more']=='Y':AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOsj
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
 def Get_UHD_MovieList(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,page_int):
  AHiFRoBQENLKYdhDgVXwTCIekmnOju=[]
  AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v2/operator/highlights'
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams(uhd=AHiFRoBQENLKYdhDgVXwTCIekmnOsj)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(page_int),'pocType':'APP_X_TVING_4.0.0',}
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs.update(AHiFRoBQENLKYdhDgVXwTCIekmnOjb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjp
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOxs,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjS=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   if not('result' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']):return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
   AHiFRoBQENLKYdhDgVXwTCIekmnOyP=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['result']
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjv in AHiFRoBQENLKYdhDgVXwTCIekmnOyP:
    AHiFRoBQENLKYdhDgVXwTCIekmnOax=AHiFRoBQENLKYdhDgVXwTCIekmnOjv['content']['movie']
    AHiFRoBQENLKYdhDgVXwTCIekmnOay =AHiFRoBQENLKYdhDgVXwTCIekmnOax['code']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJx =AHiFRoBQENLKYdhDgVXwTCIekmnOax['name']['ko'].strip()
    AHiFRoBQENLKYdhDgVXwTCIekmnOaU =AHiFRoBQENLKYdhDgVXwTCIekmnOax['name']['ko'].strip()
    AHiFRoBQENLKYdhDgVXwTCIekmnOJl =AHiFRoBQENLKYdhDgVXwTCIekmnOax['product_year']
    if AHiFRoBQENLKYdhDgVXwTCIekmnOJl:AHiFRoBQENLKYdhDgVXwTCIekmnOJx+=u' (%s)'%(AHiFRoBQENLKYdhDgVXwTCIekmnOax['product_year'])
    AHiFRoBQENLKYdhDgVXwTCIekmnOJy =AHiFRoBQENLKYdhDgVXwTCIekmnOax['story']['ko']
    AHiFRoBQENLKYdhDgVXwTCIekmnOaz =AHiFRoBQENLKYdhDgVXwTCIekmnOax['duration']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJb =AHiFRoBQENLKYdhDgVXwTCIekmnOGy.get(AHiFRoBQENLKYdhDgVXwTCIekmnOax.get('grade_code'))
    AHiFRoBQENLKYdhDgVXwTCIekmnOaS =AHiFRoBQENLKYdhDgVXwTCIekmnOax['production']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJf=''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJa =''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJs=''
    AHiFRoBQENLKYdhDgVXwTCIekmnOJU =[]
    AHiFRoBQENLKYdhDgVXwTCIekmnOJt =[]
    AHiFRoBQENLKYdhDgVXwTCIekmnOJu=[]
    AHiFRoBQENLKYdhDgVXwTCIekmnOJS =''
    for AHiFRoBQENLKYdhDgVXwTCIekmnOJM in AHiFRoBQENLKYdhDgVXwTCIekmnOax['image']:
     if AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIM2100':AHiFRoBQENLKYdhDgVXwTCIekmnOJf =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIM0400':AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
     elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM['code']=='CAIM1800':AHiFRoBQENLKYdhDgVXwTCIekmnOJs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM['url']
    if AHiFRoBQENLKYdhDgVXwTCIekmnOax['release_date']not in[AHiFRoBQENLKYdhDgVXwTCIekmnOfP,0]:
     AHiFRoBQENLKYdhDgVXwTCIekmnOJr=AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOax['release_date'])
     if AHiFRoBQENLKYdhDgVXwTCIekmnOJr!='0':AHiFRoBQENLKYdhDgVXwTCIekmnOJS='%s-%s-%s'%(AHiFRoBQENLKYdhDgVXwTCIekmnOJr[:4],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[4:6],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[6:])
    if AHiFRoBQENLKYdhDgVXwTCIekmnOax.get('category1_name').get('ko')!='':
     AHiFRoBQENLKYdhDgVXwTCIekmnOJU.append(AHiFRoBQENLKYdhDgVXwTCIekmnOax['category1_name']['ko'])
    if AHiFRoBQENLKYdhDgVXwTCIekmnOax.get('category2_name').get('ko')!='':
     AHiFRoBQENLKYdhDgVXwTCIekmnOJU.append(AHiFRoBQENLKYdhDgVXwTCIekmnOax['category2_name']['ko'])
    for AHiFRoBQENLKYdhDgVXwTCIekmnOJv in AHiFRoBQENLKYdhDgVXwTCIekmnOax.get('actor'):
     if AHiFRoBQENLKYdhDgVXwTCIekmnOJv!='':AHiFRoBQENLKYdhDgVXwTCIekmnOJt.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJv)
    for AHiFRoBQENLKYdhDgVXwTCIekmnOJz in AHiFRoBQENLKYdhDgVXwTCIekmnOax.get('director'):
     if AHiFRoBQENLKYdhDgVXwTCIekmnOJz!='':AHiFRoBQENLKYdhDgVXwTCIekmnOJu.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJz)
    AHiFRoBQENLKYdhDgVXwTCIekmnOJc={'moviecode':AHiFRoBQENLKYdhDgVXwTCIekmnOay,'title':AHiFRoBQENLKYdhDgVXwTCIekmnOJx,'thumbnail':{'poster':AHiFRoBQENLKYdhDgVXwTCIekmnOJf,'thumb':AHiFRoBQENLKYdhDgVXwTCIekmnOJa,'clearlogo':AHiFRoBQENLKYdhDgVXwTCIekmnOJs,'fanart':AHiFRoBQENLKYdhDgVXwTCIekmnOJa},'year':AHiFRoBQENLKYdhDgVXwTCIekmnOJl,'info_title':AHiFRoBQENLKYdhDgVXwTCIekmnOaU,'synopsis':AHiFRoBQENLKYdhDgVXwTCIekmnOJy,'mpaa':AHiFRoBQENLKYdhDgVXwTCIekmnOJb,'duration':AHiFRoBQENLKYdhDgVXwTCIekmnOaz,'premiered':AHiFRoBQENLKYdhDgVXwTCIekmnOJS,'studio':AHiFRoBQENLKYdhDgVXwTCIekmnOaS,'info_genre':AHiFRoBQENLKYdhDgVXwTCIekmnOJU,'cast':AHiFRoBQENLKYdhDgVXwTCIekmnOJt,'director':AHiFRoBQENLKYdhDgVXwTCIekmnOJu,}
    AHiFRoBQENLKYdhDgVXwTCIekmnOju.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJc)
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
 def GetMovieGenre(AHiFRoBQENLKYdhDgVXwTCIekmnOGf):
  AHiFRoBQENLKYdhDgVXwTCIekmnOju=[]
  AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v2/media/movie/curations'
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs.update(AHiFRoBQENLKYdhDgVXwTCIekmnOjb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjp
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOxs,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjS=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   if not('result' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']):return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
   AHiFRoBQENLKYdhDgVXwTCIekmnOyP=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['result']
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjv in AHiFRoBQENLKYdhDgVXwTCIekmnOyP:
    AHiFRoBQENLKYdhDgVXwTCIekmnOac =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['curation_code']
    AHiFRoBQENLKYdhDgVXwTCIekmnOfG =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['curation_name']
    AHiFRoBQENLKYdhDgVXwTCIekmnOJc={'curation_code':AHiFRoBQENLKYdhDgVXwTCIekmnOac,'curation_name':AHiFRoBQENLKYdhDgVXwTCIekmnOfG}
    AHiFRoBQENLKYdhDgVXwTCIekmnOju.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJc)
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
 def GetSearchList(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,search_key,page_int,stype):
  AHiFRoBQENLKYdhDgVXwTCIekmnOfj=[]
  AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOfc
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/search/getSearch.jsp'
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.SCREENCODE,'os':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.OSCODE,'network':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.APIKEY,'networkCode':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.NETWORKCODE,'osCode ':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.OSCODE,'teleCode ':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TELECODE,'screenCode ':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.SCREENCODE}
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.SEARCH_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjp
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOjb,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjS=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   if stype=='vod':
    if not('programRsb' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS):return AHiFRoBQENLKYdhDgVXwTCIekmnOfj,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
    AHiFRoBQENLKYdhDgVXwTCIekmnOfx=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['programRsb']['dataList']
    AHiFRoBQENLKYdhDgVXwTCIekmnOfy =AHiFRoBQENLKYdhDgVXwTCIekmnOsx(AHiFRoBQENLKYdhDgVXwTCIekmnOjS['programRsb']['count'])
    for AHiFRoBQENLKYdhDgVXwTCIekmnOjv in AHiFRoBQENLKYdhDgVXwTCIekmnOfx:
     AHiFRoBQENLKYdhDgVXwTCIekmnOaG=AHiFRoBQENLKYdhDgVXwTCIekmnOjv['mast_cd']
     AHiFRoBQENLKYdhDgVXwTCIekmnOJx =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['mast_nm']
     AHiFRoBQENLKYdhDgVXwTCIekmnOJf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjv['web_url4']
     AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjv['web_url']
     try:
      AHiFRoBQENLKYdhDgVXwTCIekmnOJt =[]
      AHiFRoBQENLKYdhDgVXwTCIekmnOJu=[]
      AHiFRoBQENLKYdhDgVXwTCIekmnOJU =[]
      AHiFRoBQENLKYdhDgVXwTCIekmnOaz =0
      AHiFRoBQENLKYdhDgVXwTCIekmnOJb =''
      AHiFRoBQENLKYdhDgVXwTCIekmnOJl =''
      AHiFRoBQENLKYdhDgVXwTCIekmnOab =''
      if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('actor') !='' and AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('actor') !='-':AHiFRoBQENLKYdhDgVXwTCIekmnOJt =AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('actor').split(',')
      if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('director')!='' and AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('director')!='-':AHiFRoBQENLKYdhDgVXwTCIekmnOJu=AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('director').split(',')
      if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('cate_nm')!='' and AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('cate_nm')!='-':AHiFRoBQENLKYdhDgVXwTCIekmnOJU =AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('cate_nm').split('/')
      if 'targetage' in AHiFRoBQENLKYdhDgVXwTCIekmnOjv:AHiFRoBQENLKYdhDgVXwTCIekmnOJb=AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('targetage')
      if 'broad_dt' in AHiFRoBQENLKYdhDgVXwTCIekmnOjv:
       AHiFRoBQENLKYdhDgVXwTCIekmnOJr=AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('broad_dt')
       AHiFRoBQENLKYdhDgVXwTCIekmnOab='%s-%s-%s'%(AHiFRoBQENLKYdhDgVXwTCIekmnOJr[:4],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[4:6],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[6:])
       AHiFRoBQENLKYdhDgVXwTCIekmnOJl =AHiFRoBQENLKYdhDgVXwTCIekmnOJr[:4]
     except:
      AHiFRoBQENLKYdhDgVXwTCIekmnOfP
     AHiFRoBQENLKYdhDgVXwTCIekmnOJc={'program':AHiFRoBQENLKYdhDgVXwTCIekmnOaG,'title':AHiFRoBQENLKYdhDgVXwTCIekmnOJx,'thumbnail':{'poster':AHiFRoBQENLKYdhDgVXwTCIekmnOJf,'thumb':AHiFRoBQENLKYdhDgVXwTCIekmnOJa,'fanart':AHiFRoBQENLKYdhDgVXwTCIekmnOJa},'synopsis':'','cast':AHiFRoBQENLKYdhDgVXwTCIekmnOJt,'director':AHiFRoBQENLKYdhDgVXwTCIekmnOJu,'info_genre':AHiFRoBQENLKYdhDgVXwTCIekmnOJU,'duration':AHiFRoBQENLKYdhDgVXwTCIekmnOaz,'mpaa':AHiFRoBQENLKYdhDgVXwTCIekmnOJb,'year':AHiFRoBQENLKYdhDgVXwTCIekmnOJl,'aired':AHiFRoBQENLKYdhDgVXwTCIekmnOab}
     AHiFRoBQENLKYdhDgVXwTCIekmnOfj.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJc)
   else:
    if not('vodMVRsb' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS):return AHiFRoBQENLKYdhDgVXwTCIekmnOfj,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
    AHiFRoBQENLKYdhDgVXwTCIekmnOfJ=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['vodMVRsb']['dataList']
    AHiFRoBQENLKYdhDgVXwTCIekmnOfy =AHiFRoBQENLKYdhDgVXwTCIekmnOsx(AHiFRoBQENLKYdhDgVXwTCIekmnOjS['vodMVRsb']['count'])
    for AHiFRoBQENLKYdhDgVXwTCIekmnOjv in AHiFRoBQENLKYdhDgVXwTCIekmnOfJ:
     AHiFRoBQENLKYdhDgVXwTCIekmnOaG=AHiFRoBQENLKYdhDgVXwTCIekmnOjv['mast_cd']
     AHiFRoBQENLKYdhDgVXwTCIekmnOJx =AHiFRoBQENLKYdhDgVXwTCIekmnOjv['mast_nm'].strip()
     AHiFRoBQENLKYdhDgVXwTCIekmnOJf =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjv['web_url']
     AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOJf
     AHiFRoBQENLKYdhDgVXwTCIekmnOJs=''
     try:
      AHiFRoBQENLKYdhDgVXwTCIekmnOJt =[]
      AHiFRoBQENLKYdhDgVXwTCIekmnOJu=[]
      AHiFRoBQENLKYdhDgVXwTCIekmnOJU =[]
      AHiFRoBQENLKYdhDgVXwTCIekmnOaz =0
      AHiFRoBQENLKYdhDgVXwTCIekmnOJb =''
      AHiFRoBQENLKYdhDgVXwTCIekmnOJl =''
      AHiFRoBQENLKYdhDgVXwTCIekmnOab =''
      if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('actor') !='' and AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('actor') !='-':AHiFRoBQENLKYdhDgVXwTCIekmnOJt =AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('actor').split(',')
      if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('director')!='' and AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('director')!='-':AHiFRoBQENLKYdhDgVXwTCIekmnOJu=AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('director').split(',')
      if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('cate_nm')!='' and AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('cate_nm')!='-':AHiFRoBQENLKYdhDgVXwTCIekmnOJU =AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('cate_nm').split('/')
      if AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('runtime_sec')!='':AHiFRoBQENLKYdhDgVXwTCIekmnOaz=AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('runtime_sec')
      if 'grade_nm' in AHiFRoBQENLKYdhDgVXwTCIekmnOjv:AHiFRoBQENLKYdhDgVXwTCIekmnOJb=AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('grade_nm')
      AHiFRoBQENLKYdhDgVXwTCIekmnOJr=AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('broad_dt')
      if data_str!='':
       AHiFRoBQENLKYdhDgVXwTCIekmnOab='%s-%s-%s'%(AHiFRoBQENLKYdhDgVXwTCIekmnOJr[:4],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[4:6],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[6:])
       AHiFRoBQENLKYdhDgVXwTCIekmnOJl =AHiFRoBQENLKYdhDgVXwTCIekmnOJr[:4]
     except:
      AHiFRoBQENLKYdhDgVXwTCIekmnOfP
     AHiFRoBQENLKYdhDgVXwTCIekmnOJc={'movie':AHiFRoBQENLKYdhDgVXwTCIekmnOaG,'title':AHiFRoBQENLKYdhDgVXwTCIekmnOJx,'thumbnail':{'poster':AHiFRoBQENLKYdhDgVXwTCIekmnOJf,'thumb':AHiFRoBQENLKYdhDgVXwTCIekmnOJa,'fanart':AHiFRoBQENLKYdhDgVXwTCIekmnOJa,'clearlogo':AHiFRoBQENLKYdhDgVXwTCIekmnOJs},'synopsis':'','cast':AHiFRoBQENLKYdhDgVXwTCIekmnOJt,'director':AHiFRoBQENLKYdhDgVXwTCIekmnOJu,'info_genre':AHiFRoBQENLKYdhDgVXwTCIekmnOJU,'duration':AHiFRoBQENLKYdhDgVXwTCIekmnOaz,'mpaa':AHiFRoBQENLKYdhDgVXwTCIekmnOJb,'year':AHiFRoBQENLKYdhDgVXwTCIekmnOJl,'aired':AHiFRoBQENLKYdhDgVXwTCIekmnOab}
     AHiFRoBQENLKYdhDgVXwTCIekmnOar=AHiFRoBQENLKYdhDgVXwTCIekmnOfc
     for AHiFRoBQENLKYdhDgVXwTCIekmnOaP in AHiFRoBQENLKYdhDgVXwTCIekmnOjv['bill']:
      if AHiFRoBQENLKYdhDgVXwTCIekmnOaP in AHiFRoBQENLKYdhDgVXwTCIekmnOGf.MOVIE_LITE:
       AHiFRoBQENLKYdhDgVXwTCIekmnOar=AHiFRoBQENLKYdhDgVXwTCIekmnOsj
       break
     if AHiFRoBQENLKYdhDgVXwTCIekmnOar==AHiFRoBQENLKYdhDgVXwTCIekmnOfc: 
      AHiFRoBQENLKYdhDgVXwTCIekmnOJc['title']=AHiFRoBQENLKYdhDgVXwTCIekmnOJc['title']+' [개별구매]'
     AHiFRoBQENLKYdhDgVXwTCIekmnOfj.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJc)
   if AHiFRoBQENLKYdhDgVXwTCIekmnOfy>(page_int*AHiFRoBQENLKYdhDgVXwTCIekmnOGf.SEARCH_LIMIT):AHiFRoBQENLKYdhDgVXwTCIekmnOyz=AHiFRoBQENLKYdhDgVXwTCIekmnOsj
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOfj,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
 def GetBookmarkInfo(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,videoid,vidtype):
  AHiFRoBQENLKYdhDgVXwTCIekmnOfa={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+'/v2/media/program/'+videoid
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'pageNo':'1','pageSize':'10','order':'name',}
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs.update(AHiFRoBQENLKYdhDgVXwTCIekmnOjb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOxs,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   AHiFRoBQENLKYdhDgVXwTCIekmnOaJ=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   if not('body' in AHiFRoBQENLKYdhDgVXwTCIekmnOaJ):return{}
   AHiFRoBQENLKYdhDgVXwTCIekmnOfs=AHiFRoBQENLKYdhDgVXwTCIekmnOaJ['body']
   AHiFRoBQENLKYdhDgVXwTCIekmnOJx=AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('name').get('ko').strip()
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['title'] =AHiFRoBQENLKYdhDgVXwTCIekmnOJx
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['title']=AHiFRoBQENLKYdhDgVXwTCIekmnOJx
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['mpaa'] =AHiFRoBQENLKYdhDgVXwTCIekmnOGy.get(AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('grade_code'))
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['plot'] =AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('synopsis').get('ko')
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['year'] =AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('product_year')
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['cast'] =AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('actor')
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['director']=AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('director')
   if AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('category1_name').get('ko')!='':
    AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['genre'].append(AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('category1_name').get('ko'))
   if AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('category2_name').get('ko')!='':
    AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['genre'].append(AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('category2_name').get('ko'))
   AHiFRoBQENLKYdhDgVXwTCIekmnOJr=AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('broad_dt'))
   if AHiFRoBQENLKYdhDgVXwTCIekmnOJr!='0':AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(AHiFRoBQENLKYdhDgVXwTCIekmnOJr[:4],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[4:6],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[6:])
   AHiFRoBQENLKYdhDgVXwTCIekmnOJf =''
   AHiFRoBQENLKYdhDgVXwTCIekmnOJa =''
   AHiFRoBQENLKYdhDgVXwTCIekmnOJs=''
   AHiFRoBQENLKYdhDgVXwTCIekmnOJq =''
   AHiFRoBQENLKYdhDgVXwTCIekmnOJW =''
   for AHiFRoBQENLKYdhDgVXwTCIekmnOJM in AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('image'):
    if AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('code')=='CAIP0900':AHiFRoBQENLKYdhDgVXwTCIekmnOJf =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('url')
    elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('code')=='CAIP0200':AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('url')
    elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('code')=='CAIP1800':AHiFRoBQENLKYdhDgVXwTCIekmnOJs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('url')
    elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('code')=='CAIP2000':AHiFRoBQENLKYdhDgVXwTCIekmnOJq =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('url')
    elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('code')=='CAIP1900':AHiFRoBQENLKYdhDgVXwTCIekmnOJW =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('url')
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['thumbnail']['poster']=AHiFRoBQENLKYdhDgVXwTCIekmnOJf
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['thumbnail']['thumb']=AHiFRoBQENLKYdhDgVXwTCIekmnOJa
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['thumbnail']['clearlogo']=AHiFRoBQENLKYdhDgVXwTCIekmnOJs
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['thumbnail']['icon']=AHiFRoBQENLKYdhDgVXwTCIekmnOJq
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['thumbnail']['banner']=AHiFRoBQENLKYdhDgVXwTCIekmnOJW
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['thumbnail']['fanart']=AHiFRoBQENLKYdhDgVXwTCIekmnOJa
  else:
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+'/v2a/media/stream/info'
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_uuid'].split('-')[0],'uuid':AHiFRoBQENLKYdhDgVXwTCIekmnOGf.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetNoCache(1)),'wm':'Y',}
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs.update(AHiFRoBQENLKYdhDgVXwTCIekmnOjb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOxs,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   AHiFRoBQENLKYdhDgVXwTCIekmnOaJ=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   if not('content' in AHiFRoBQENLKYdhDgVXwTCIekmnOaJ['body']):return{}
   AHiFRoBQENLKYdhDgVXwTCIekmnOfs=AHiFRoBQENLKYdhDgVXwTCIekmnOaJ['body']['content']['info']['movie']
   AHiFRoBQENLKYdhDgVXwTCIekmnOJx =AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('name').get('ko').strip()
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['title']=AHiFRoBQENLKYdhDgVXwTCIekmnOJx
   AHiFRoBQENLKYdhDgVXwTCIekmnOJx +=u' (%s)'%(AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('product_year'))
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['title'] =AHiFRoBQENLKYdhDgVXwTCIekmnOJx
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['mpaa'] =AHiFRoBQENLKYdhDgVXwTCIekmnOGy.get(AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('grade_code'))
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['plot'] =AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('story').get('ko')
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['year'] =AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('product_year')
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['studio'] =AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('production')
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['duration']=AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('duration')
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['cast'] =AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('actor')
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['director']=AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('director')
   if AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('category1_name').get('ko')!='':
    AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['genre'].append(AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('category1_name').get('ko'))
   if AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('category2_name').get('ko')!='':
    AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['genre'].append(AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('category2_name').get('ko'))
   AHiFRoBQENLKYdhDgVXwTCIekmnOJr=AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('release_date'))
   if AHiFRoBQENLKYdhDgVXwTCIekmnOJr!='0':AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(AHiFRoBQENLKYdhDgVXwTCIekmnOJr[:4],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[4:6],AHiFRoBQENLKYdhDgVXwTCIekmnOJr[6:])
   AHiFRoBQENLKYdhDgVXwTCIekmnOJf=''
   AHiFRoBQENLKYdhDgVXwTCIekmnOJa =''
   AHiFRoBQENLKYdhDgVXwTCIekmnOJs=''
   for AHiFRoBQENLKYdhDgVXwTCIekmnOJM in AHiFRoBQENLKYdhDgVXwTCIekmnOfs.get('image'):
    if AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('code')=='CAIM2100':AHiFRoBQENLKYdhDgVXwTCIekmnOJf =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('url')
    elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('code')=='CAIM0400':AHiFRoBQENLKYdhDgVXwTCIekmnOJa =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('url')
    elif AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('code')=='CAIM1800':AHiFRoBQENLKYdhDgVXwTCIekmnOJs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.IMG_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOJM.get('url')
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['thumbnail']['poster']=AHiFRoBQENLKYdhDgVXwTCIekmnOJf
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['thumbnail']['thumb']=AHiFRoBQENLKYdhDgVXwTCIekmnOJf 
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['thumbnail']['clearlogo']=AHiFRoBQENLKYdhDgVXwTCIekmnOJs
   AHiFRoBQENLKYdhDgVXwTCIekmnOfa['saveinfo']['thumbnail']['fanart']=AHiFRoBQENLKYdhDgVXwTCIekmnOJa
  return AHiFRoBQENLKYdhDgVXwTCIekmnOfa
 def GetEuroChannelList(AHiFRoBQENLKYdhDgVXwTCIekmnOGf):
  AHiFRoBQENLKYdhDgVXwTCIekmnOju=[]
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOjp ='/v2/operator/highlights'
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetDefaultParams()
   AHiFRoBQENLKYdhDgVXwTCIekmnOjb={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':AHiFRoBQENLKYdhDgVXwTCIekmnOsf(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.GetNoCache(2))}
   AHiFRoBQENLKYdhDgVXwTCIekmnOxs.update(AHiFRoBQENLKYdhDgVXwTCIekmnOjb)
   AHiFRoBQENLKYdhDgVXwTCIekmnOxq=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.API_DOMAIN+AHiFRoBQENLKYdhDgVXwTCIekmnOjp
   AHiFRoBQENLKYdhDgVXwTCIekmnOjf=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.callRequestCookies('Get',AHiFRoBQENLKYdhDgVXwTCIekmnOxq,payload=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,params=AHiFRoBQENLKYdhDgVXwTCIekmnOxs,headers=AHiFRoBQENLKYdhDgVXwTCIekmnOfP,cookies=AHiFRoBQENLKYdhDgVXwTCIekmnOfP)
   AHiFRoBQENLKYdhDgVXwTCIekmnOjS=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOjf.text)
   if not('result' in AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']):return AHiFRoBQENLKYdhDgVXwTCIekmnOju,AHiFRoBQENLKYdhDgVXwTCIekmnOyz
   AHiFRoBQENLKYdhDgVXwTCIekmnOyP=AHiFRoBQENLKYdhDgVXwTCIekmnOjS['body']['result']
   AHiFRoBQENLKYdhDgVXwTCIekmnOfq =AHiFRoBQENLKYdhDgVXwTCIekmnOGf.Get_Now_Datetime()
   AHiFRoBQENLKYdhDgVXwTCIekmnOfW=AHiFRoBQENLKYdhDgVXwTCIekmnOfq+datetime.timedelta(days=-1)
   AHiFRoBQENLKYdhDgVXwTCIekmnOfW=AHiFRoBQENLKYdhDgVXwTCIekmnOsx(AHiFRoBQENLKYdhDgVXwTCIekmnOfW.strftime('%Y%m%d'))
   for AHiFRoBQENLKYdhDgVXwTCIekmnOjv in AHiFRoBQENLKYdhDgVXwTCIekmnOyP:
    AHiFRoBQENLKYdhDgVXwTCIekmnOfp=AHiFRoBQENLKYdhDgVXwTCIekmnOsx(AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('content').get('banner_title2')[:8])
    if AHiFRoBQENLKYdhDgVXwTCIekmnOfW<=AHiFRoBQENLKYdhDgVXwTCIekmnOfp:
     AHiFRoBQENLKYdhDgVXwTCIekmnOJc={'channel':AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('content').get('banner_sub_title3'),'title':AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('content').get('banner_title'),'subtitle':AHiFRoBQENLKYdhDgVXwTCIekmnOjv.get('content').get('banner_sub_title2'),}
     AHiFRoBQENLKYdhDgVXwTCIekmnOju.append(AHiFRoBQENLKYdhDgVXwTCIekmnOJc)
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOju
 def Make_DecryptKey(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,step,mediacode='000',timecode='000'):
  if step=='1':
   AHiFRoBQENLKYdhDgVXwTCIekmnOfM=AHiFRoBQENLKYdhDgVXwTCIekmnOsp('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   AHiFRoBQENLKYdhDgVXwTCIekmnOft=AHiFRoBQENLKYdhDgVXwTCIekmnOsp('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfM=AHiFRoBQENLKYdhDgVXwTCIekmnOsp('kss2lym0kdw1lks3','utf-8')
   AHiFRoBQENLKYdhDgVXwTCIekmnOft=AHiFRoBQENLKYdhDgVXwTCIekmnOsp([AHiFRoBQENLKYdhDgVXwTCIekmnOsM('*'),0x07,AHiFRoBQENLKYdhDgVXwTCIekmnOsM('r'),AHiFRoBQENLKYdhDgVXwTCIekmnOsM(';'),AHiFRoBQENLKYdhDgVXwTCIekmnOsM('7'),0x05,0x1e,0x01,AHiFRoBQENLKYdhDgVXwTCIekmnOsM('n'),AHiFRoBQENLKYdhDgVXwTCIekmnOsM('D'),0x02,AHiFRoBQENLKYdhDgVXwTCIekmnOsM('3'),AHiFRoBQENLKYdhDgVXwTCIekmnOsM('*'),AHiFRoBQENLKYdhDgVXwTCIekmnOsM('a'),AHiFRoBQENLKYdhDgVXwTCIekmnOsM('&'),AHiFRoBQENLKYdhDgVXwTCIekmnOsM('<')])
  return AHiFRoBQENLKYdhDgVXwTCIekmnOfM,AHiFRoBQENLKYdhDgVXwTCIekmnOft
 def DecryptPlaintext(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,ciphertext,encryption_key,init_vector):
  AHiFRoBQENLKYdhDgVXwTCIekmnOfu=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  AHiFRoBQENLKYdhDgVXwTCIekmnOfU=Padding.unpad(AHiFRoBQENLKYdhDgVXwTCIekmnOfu.decrypt(base64.standard_b64decode(ciphertext)),16)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOfU.decode('utf-8')
 def Decrypt_Url(AHiFRoBQENLKYdhDgVXwTCIekmnOGf,ciphertext,mediacode,AHiFRoBQENLKYdhDgVXwTCIekmnOxu):
  AHiFRoBQENLKYdhDgVXwTCIekmnOfl=''
  AHiFRoBQENLKYdhDgVXwTCIekmnOxU=''
  AHiFRoBQENLKYdhDgVXwTCIekmnOxl=''
  try:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfM,AHiFRoBQENLKYdhDgVXwTCIekmnOft=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.Make_DecryptKey('1',mediacode=mediacode,timecode=AHiFRoBQENLKYdhDgVXwTCIekmnOxu)
   AHiFRoBQENLKYdhDgVXwTCIekmnOfb=json.loads(AHiFRoBQENLKYdhDgVXwTCIekmnOGf.DecryptPlaintext(ciphertext,AHiFRoBQENLKYdhDgVXwTCIekmnOfM,AHiFRoBQENLKYdhDgVXwTCIekmnOft))
   AHiFRoBQENLKYdhDgVXwTCIekmnOfS =AHiFRoBQENLKYdhDgVXwTCIekmnOfb.get('broad_url')
   AHiFRoBQENLKYdhDgVXwTCIekmnOxU =AHiFRoBQENLKYdhDgVXwTCIekmnOfb.get('watermark') if 'watermark' in AHiFRoBQENLKYdhDgVXwTCIekmnOfb else ''
   AHiFRoBQENLKYdhDgVXwTCIekmnOxl=AHiFRoBQENLKYdhDgVXwTCIekmnOfb.get('watermarkKey')if 'watermarkKey' in AHiFRoBQENLKYdhDgVXwTCIekmnOfb else ''
   AHiFRoBQENLKYdhDgVXwTCIekmnOfM,AHiFRoBQENLKYdhDgVXwTCIekmnOft=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.Make_DecryptKey('2',mediacode=mediacode,timecode=AHiFRoBQENLKYdhDgVXwTCIekmnOxu)
   AHiFRoBQENLKYdhDgVXwTCIekmnOfl=AHiFRoBQENLKYdhDgVXwTCIekmnOGf.DecryptPlaintext(AHiFRoBQENLKYdhDgVXwTCIekmnOfS,AHiFRoBQENLKYdhDgVXwTCIekmnOfM,AHiFRoBQENLKYdhDgVXwTCIekmnOft)
  except AHiFRoBQENLKYdhDgVXwTCIekmnOsJ as exception:
   AHiFRoBQENLKYdhDgVXwTCIekmnOfv(exception)
  return AHiFRoBQENLKYdhDgVXwTCIekmnOfl,AHiFRoBQENLKYdhDgVXwTCIekmnOxU,AHiFRoBQENLKYdhDgVXwTCIekmnOxl
# Created by pyminifier (https://github.com/liftoff/pyminifier)
