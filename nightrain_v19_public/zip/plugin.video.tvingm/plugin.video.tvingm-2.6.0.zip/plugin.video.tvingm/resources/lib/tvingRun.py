__author__="NightRain"
IcKWOrYGdHfQvinTJAEbXqzMBkstuw=object
IcKWOrYGdHfQvinTJAEbXqzMBkstua=None
IcKWOrYGdHfQvinTJAEbXqzMBkstug=int
IcKWOrYGdHfQvinTJAEbXqzMBkstFL=True
IcKWOrYGdHfQvinTJAEbXqzMBkstFC=False
IcKWOrYGdHfQvinTJAEbXqzMBkstFx=type
IcKWOrYGdHfQvinTJAEbXqzMBkstFD=dict
IcKWOrYGdHfQvinTJAEbXqzMBkstFV=getattr
IcKWOrYGdHfQvinTJAEbXqzMBkstFo=list
IcKWOrYGdHfQvinTJAEbXqzMBkstFN=len
IcKWOrYGdHfQvinTJAEbXqzMBkstFu=str
IcKWOrYGdHfQvinTJAEbXqzMBkstFS=range
IcKWOrYGdHfQvinTJAEbXqzMBkstFP=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
IcKWOrYGdHfQvinTJAEbXqzMBkstLx=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
IcKWOrYGdHfQvinTJAEbXqzMBkstLD=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
IcKWOrYGdHfQvinTJAEbXqzMBkstLV=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
IcKWOrYGdHfQvinTJAEbXqzMBkstLo=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
IcKWOrYGdHfQvinTJAEbXqzMBkstLN=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
IcKWOrYGdHfQvinTJAEbXqzMBkstLu=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
IcKWOrYGdHfQvinTJAEbXqzMBkstLF=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
IcKWOrYGdHfQvinTJAEbXqzMBkstLS={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
IcKWOrYGdHfQvinTJAEbXqzMBkstLP =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
IcKWOrYGdHfQvinTJAEbXqzMBkstLm=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class IcKWOrYGdHfQvinTJAEbXqzMBkstLC(IcKWOrYGdHfQvinTJAEbXqzMBkstuw):
 def __init__(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstLU,IcKWOrYGdHfQvinTJAEbXqzMBkstLp,IcKWOrYGdHfQvinTJAEbXqzMBkstLj):
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_url =IcKWOrYGdHfQvinTJAEbXqzMBkstLU
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle=IcKWOrYGdHfQvinTJAEbXqzMBkstLp
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params =IcKWOrYGdHfQvinTJAEbXqzMBkstLj
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj =AHiFRoBQENLKYdhDgVXwTCIekmnOGj() 
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,sting):
  try:
   IcKWOrYGdHfQvinTJAEbXqzMBkstLR=xbmcgui.Dialog()
   IcKWOrYGdHfQvinTJAEbXqzMBkstLR.notification(__addonname__,sting)
  except:
   IcKWOrYGdHfQvinTJAEbXqzMBkstua
 def addon_log(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,string):
  try:
   IcKWOrYGdHfQvinTJAEbXqzMBkstLh=string.encode('utf-8','ignore')
  except:
   IcKWOrYGdHfQvinTJAEbXqzMBkstLh='addonException: addon_log'
  IcKWOrYGdHfQvinTJAEbXqzMBkstLy=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,IcKWOrYGdHfQvinTJAEbXqzMBkstLh),level=IcKWOrYGdHfQvinTJAEbXqzMBkstLy)
 def get_keyboard_input(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstCj):
  IcKWOrYGdHfQvinTJAEbXqzMBkstLw=IcKWOrYGdHfQvinTJAEbXqzMBkstua
  kb=xbmc.Keyboard()
  kb.setHeading(IcKWOrYGdHfQvinTJAEbXqzMBkstCj)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   IcKWOrYGdHfQvinTJAEbXqzMBkstLw=kb.getText()
  return IcKWOrYGdHfQvinTJAEbXqzMBkstLw
 def get_settings_account(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  IcKWOrYGdHfQvinTJAEbXqzMBkstLa =__addon__.getSetting('id')
  IcKWOrYGdHfQvinTJAEbXqzMBkstLg =__addon__.getSetting('pw')
  IcKWOrYGdHfQvinTJAEbXqzMBkstCL =__addon__.getSetting('login_type')
  IcKWOrYGdHfQvinTJAEbXqzMBkstCx=IcKWOrYGdHfQvinTJAEbXqzMBkstug(__addon__.getSetting('selected_profile'))
  return(IcKWOrYGdHfQvinTJAEbXqzMBkstLa,IcKWOrYGdHfQvinTJAEbXqzMBkstLg,IcKWOrYGdHfQvinTJAEbXqzMBkstCL,IcKWOrYGdHfQvinTJAEbXqzMBkstCx)
 def get_settings_uhd(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  return IcKWOrYGdHfQvinTJAEbXqzMBkstFL if __addon__.getSetting('active_uhd')=='true' else IcKWOrYGdHfQvinTJAEbXqzMBkstFC
 def get_settings_playback(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  IcKWOrYGdHfQvinTJAEbXqzMBkstCD={'active_uhd':IcKWOrYGdHfQvinTJAEbXqzMBkstFL if __addon__.getSetting('active_uhd')=='true' else IcKWOrYGdHfQvinTJAEbXqzMBkstFC,'streamFilename':IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.TV_STREAM_FILENAME,}
  return IcKWOrYGdHfQvinTJAEbXqzMBkstCD
 def get_settings_proxyport(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  IcKWOrYGdHfQvinTJAEbXqzMBkstCV =IcKWOrYGdHfQvinTJAEbXqzMBkstFL if __addon__.getSetting('proxyYn')=='true' else IcKWOrYGdHfQvinTJAEbXqzMBkstFC
  IcKWOrYGdHfQvinTJAEbXqzMBkstCo=IcKWOrYGdHfQvinTJAEbXqzMBkstug(__addon__.getSetting('proxyPort'))
  return IcKWOrYGdHfQvinTJAEbXqzMBkstCV,IcKWOrYGdHfQvinTJAEbXqzMBkstCo
 def get_settings_totalsearch(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  IcKWOrYGdHfQvinTJAEbXqzMBkstCN =IcKWOrYGdHfQvinTJAEbXqzMBkstFL if __addon__.getSetting('local_search')=='true' else IcKWOrYGdHfQvinTJAEbXqzMBkstFC
  IcKWOrYGdHfQvinTJAEbXqzMBkstCu=IcKWOrYGdHfQvinTJAEbXqzMBkstFL if __addon__.getSetting('local_history')=='true' else IcKWOrYGdHfQvinTJAEbXqzMBkstFC
  IcKWOrYGdHfQvinTJAEbXqzMBkstCF =IcKWOrYGdHfQvinTJAEbXqzMBkstFL if __addon__.getSetting('total_search')=='true' else IcKWOrYGdHfQvinTJAEbXqzMBkstFC
  IcKWOrYGdHfQvinTJAEbXqzMBkstCS=IcKWOrYGdHfQvinTJAEbXqzMBkstFL if __addon__.getSetting('total_history')=='true' else IcKWOrYGdHfQvinTJAEbXqzMBkstFC
  IcKWOrYGdHfQvinTJAEbXqzMBkstCP=IcKWOrYGdHfQvinTJAEbXqzMBkstFL if __addon__.getSetting('menu_bookmark')=='true' else IcKWOrYGdHfQvinTJAEbXqzMBkstFC
  return(IcKWOrYGdHfQvinTJAEbXqzMBkstCN,IcKWOrYGdHfQvinTJAEbXqzMBkstCu,IcKWOrYGdHfQvinTJAEbXqzMBkstCF,IcKWOrYGdHfQvinTJAEbXqzMBkstCS,IcKWOrYGdHfQvinTJAEbXqzMBkstCP)
 def get_settings_makebookmark(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  return IcKWOrYGdHfQvinTJAEbXqzMBkstFL if __addon__.getSetting('make_bookmark')=='true' else IcKWOrYGdHfQvinTJAEbXqzMBkstFC
 def get_settings_direct_replay(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  IcKWOrYGdHfQvinTJAEbXqzMBkstCm=IcKWOrYGdHfQvinTJAEbXqzMBkstug(__addon__.getSetting('direct_replay'))
  if IcKWOrYGdHfQvinTJAEbXqzMBkstCm==0:
   return IcKWOrYGdHfQvinTJAEbXqzMBkstFC
  else:
   return IcKWOrYGdHfQvinTJAEbXqzMBkstFL
 def set_winEpisodeOrderby(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstCU):
  __addon__.setSetting('tving_orderby',IcKWOrYGdHfQvinTJAEbXqzMBkstCU)
  IcKWOrYGdHfQvinTJAEbXqzMBkstCl=xbmcgui.Window(10000)
  IcKWOrYGdHfQvinTJAEbXqzMBkstCl.setProperty('TVING_M_ORDERBY',IcKWOrYGdHfQvinTJAEbXqzMBkstCU)
 def get_winEpisodeOrderby(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  IcKWOrYGdHfQvinTJAEbXqzMBkstCU=__addon__.getSetting('tving_orderby')
  if IcKWOrYGdHfQvinTJAEbXqzMBkstCU in['',IcKWOrYGdHfQvinTJAEbXqzMBkstua]:IcKWOrYGdHfQvinTJAEbXqzMBkstCU='desc'
  return IcKWOrYGdHfQvinTJAEbXqzMBkstCU
 def add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,label,sublabel='',img='',infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstua,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params='',isLink=IcKWOrYGdHfQvinTJAEbXqzMBkstFC,ContextMenu=IcKWOrYGdHfQvinTJAEbXqzMBkstua):
  IcKWOrYGdHfQvinTJAEbXqzMBkstCp='%s?%s'%(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_url,urllib.parse.urlencode(params))
  if sublabel:IcKWOrYGdHfQvinTJAEbXqzMBkstCj='%s < %s >'%(label,sublabel)
  else: IcKWOrYGdHfQvinTJAEbXqzMBkstCj=label
  if not img:img='DefaultFolder.png'
  IcKWOrYGdHfQvinTJAEbXqzMBkstCe=xbmcgui.ListItem(IcKWOrYGdHfQvinTJAEbXqzMBkstCj)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstFx(img)==IcKWOrYGdHfQvinTJAEbXqzMBkstFD:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCe.setArt(img)
  else:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCe.setArt({'thumb':img,'poster':img})
  if IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.KodiVersion>=20:
   if infoLabels:IcKWOrYGdHfQvinTJAEbXqzMBkstLl.Set_InfoTag(IcKWOrYGdHfQvinTJAEbXqzMBkstCe.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:IcKWOrYGdHfQvinTJAEbXqzMBkstCe.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCe.setProperty('IsPlayable','true')
  if ContextMenu:IcKWOrYGdHfQvinTJAEbXqzMBkstCe.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,IcKWOrYGdHfQvinTJAEbXqzMBkstCp,IcKWOrYGdHfQvinTJAEbXqzMBkstCe,isFolder)
 def get_selQuality(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,etype):
  try:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCR='selected_quality'
   IcKWOrYGdHfQvinTJAEbXqzMBkstCh=[1080,720,480,360]
   IcKWOrYGdHfQvinTJAEbXqzMBkstCy=IcKWOrYGdHfQvinTJAEbXqzMBkstug(__addon__.getSetting(IcKWOrYGdHfQvinTJAEbXqzMBkstCR))
   return IcKWOrYGdHfQvinTJAEbXqzMBkstCh[IcKWOrYGdHfQvinTJAEbXqzMBkstCy]
  except:
   IcKWOrYGdHfQvinTJAEbXqzMBkstua
  return 720 
 def Set_InfoTag(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,video_InfoTag:xbmc.InfoTagVideo,IcKWOrYGdHfQvinTJAEbXqzMBkstxo):
  for IcKWOrYGdHfQvinTJAEbXqzMBkstCw,value in IcKWOrYGdHfQvinTJAEbXqzMBkstxo.items():
   if IcKWOrYGdHfQvinTJAEbXqzMBkstLS[IcKWOrYGdHfQvinTJAEbXqzMBkstCw]['type']=='string':
    IcKWOrYGdHfQvinTJAEbXqzMBkstFV(video_InfoTag,IcKWOrYGdHfQvinTJAEbXqzMBkstLS[IcKWOrYGdHfQvinTJAEbXqzMBkstCw]['func'])(value)
   elif IcKWOrYGdHfQvinTJAEbXqzMBkstLS[IcKWOrYGdHfQvinTJAEbXqzMBkstCw]['type']=='int':
    if IcKWOrYGdHfQvinTJAEbXqzMBkstFx(value)==IcKWOrYGdHfQvinTJAEbXqzMBkstug:
     IcKWOrYGdHfQvinTJAEbXqzMBkstCa=IcKWOrYGdHfQvinTJAEbXqzMBkstug(value)
    else:
     IcKWOrYGdHfQvinTJAEbXqzMBkstCa=0
    IcKWOrYGdHfQvinTJAEbXqzMBkstFV(video_InfoTag,IcKWOrYGdHfQvinTJAEbXqzMBkstLS[IcKWOrYGdHfQvinTJAEbXqzMBkstCw]['func'])(IcKWOrYGdHfQvinTJAEbXqzMBkstCa)
   elif IcKWOrYGdHfQvinTJAEbXqzMBkstLS[IcKWOrYGdHfQvinTJAEbXqzMBkstCw]['type']=='actor':
    if value!=[]:
     IcKWOrYGdHfQvinTJAEbXqzMBkstFV(video_InfoTag,IcKWOrYGdHfQvinTJAEbXqzMBkstLS[IcKWOrYGdHfQvinTJAEbXqzMBkstCw]['func'])([xbmc.Actor(name)for name in value])
   elif IcKWOrYGdHfQvinTJAEbXqzMBkstLS[IcKWOrYGdHfQvinTJAEbXqzMBkstCw]['type']=='list':
    if IcKWOrYGdHfQvinTJAEbXqzMBkstFx(value)==IcKWOrYGdHfQvinTJAEbXqzMBkstFo:
     IcKWOrYGdHfQvinTJAEbXqzMBkstFV(video_InfoTag,IcKWOrYGdHfQvinTJAEbXqzMBkstLS[IcKWOrYGdHfQvinTJAEbXqzMBkstCw]['func'])(value)
    else:
     IcKWOrYGdHfQvinTJAEbXqzMBkstFV(video_InfoTag,IcKWOrYGdHfQvinTJAEbXqzMBkstLS[IcKWOrYGdHfQvinTJAEbXqzMBkstCw]['func'])([value])
 def dp_Main_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  (IcKWOrYGdHfQvinTJAEbXqzMBkstCN,IcKWOrYGdHfQvinTJAEbXqzMBkstCu,IcKWOrYGdHfQvinTJAEbXqzMBkstCF,IcKWOrYGdHfQvinTJAEbXqzMBkstCS,IcKWOrYGdHfQvinTJAEbXqzMBkstCP)=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_totalsearch()
  for IcKWOrYGdHfQvinTJAEbXqzMBkstCg in IcKWOrYGdHfQvinTJAEbXqzMBkstLx:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj=IcKWOrYGdHfQvinTJAEbXqzMBkstCg.get('title')
   IcKWOrYGdHfQvinTJAEbXqzMBkstxL=''
   if IcKWOrYGdHfQvinTJAEbXqzMBkstCg.get('mode')=='SEARCH_GROUP' and IcKWOrYGdHfQvinTJAEbXqzMBkstCN ==IcKWOrYGdHfQvinTJAEbXqzMBkstFC:continue
   elif IcKWOrYGdHfQvinTJAEbXqzMBkstCg.get('mode')=='SEARCH_HISTORY' and IcKWOrYGdHfQvinTJAEbXqzMBkstCu==IcKWOrYGdHfQvinTJAEbXqzMBkstFC:continue
   elif IcKWOrYGdHfQvinTJAEbXqzMBkstCg.get('mode')=='TOTAL_SEARCH' and IcKWOrYGdHfQvinTJAEbXqzMBkstCF ==IcKWOrYGdHfQvinTJAEbXqzMBkstFC:continue
   elif IcKWOrYGdHfQvinTJAEbXqzMBkstCg.get('mode')=='TOTAL_HISTORY' and IcKWOrYGdHfQvinTJAEbXqzMBkstCS==IcKWOrYGdHfQvinTJAEbXqzMBkstFC:continue
   elif IcKWOrYGdHfQvinTJAEbXqzMBkstCg.get('mode')=='MENU_BOOKMARK' and IcKWOrYGdHfQvinTJAEbXqzMBkstCP==IcKWOrYGdHfQvinTJAEbXqzMBkstFC:continue
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':IcKWOrYGdHfQvinTJAEbXqzMBkstCg.get('mode'),'stype':IcKWOrYGdHfQvinTJAEbXqzMBkstCg.get('stype'),'orderby':IcKWOrYGdHfQvinTJAEbXqzMBkstCg.get('orderby'),'ordernm':IcKWOrYGdHfQvinTJAEbXqzMBkstCg.get('ordernm'),'page':'1'}
   if IcKWOrYGdHfQvinTJAEbXqzMBkstCg.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    IcKWOrYGdHfQvinTJAEbXqzMBkstxD=IcKWOrYGdHfQvinTJAEbXqzMBkstFC
    IcKWOrYGdHfQvinTJAEbXqzMBkstxV =IcKWOrYGdHfQvinTJAEbXqzMBkstFL
   else:
    IcKWOrYGdHfQvinTJAEbXqzMBkstxD=IcKWOrYGdHfQvinTJAEbXqzMBkstFL
    IcKWOrYGdHfQvinTJAEbXqzMBkstxV =IcKWOrYGdHfQvinTJAEbXqzMBkstFC
   IcKWOrYGdHfQvinTJAEbXqzMBkstxo={'title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'plot':IcKWOrYGdHfQvinTJAEbXqzMBkstCj}
   if IcKWOrYGdHfQvinTJAEbXqzMBkstCg.get('mode')=='XXX':IcKWOrYGdHfQvinTJAEbXqzMBkstxo=IcKWOrYGdHfQvinTJAEbXqzMBkstua
   if 'icon' in IcKWOrYGdHfQvinTJAEbXqzMBkstCg:IcKWOrYGdHfQvinTJAEbXqzMBkstxL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',IcKWOrYGdHfQvinTJAEbXqzMBkstCg.get('icon')) 
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel='',img=IcKWOrYGdHfQvinTJAEbXqzMBkstxL,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstxo,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstxD,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC,isLink=IcKWOrYGdHfQvinTJAEbXqzMBkstxV)
  xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle)
 def login_main(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  (IcKWOrYGdHfQvinTJAEbXqzMBkstxu,IcKWOrYGdHfQvinTJAEbXqzMBkstxF,IcKWOrYGdHfQvinTJAEbXqzMBkstxS,IcKWOrYGdHfQvinTJAEbXqzMBkstxP)=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_account()
  if not(IcKWOrYGdHfQvinTJAEbXqzMBkstxu and IcKWOrYGdHfQvinTJAEbXqzMBkstxF):
   IcKWOrYGdHfQvinTJAEbXqzMBkstLR=xbmcgui.Dialog()
   IcKWOrYGdHfQvinTJAEbXqzMBkstxm=IcKWOrYGdHfQvinTJAEbXqzMBkstLR.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if IcKWOrYGdHfQvinTJAEbXqzMBkstxm==IcKWOrYGdHfQvinTJAEbXqzMBkstFL:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if IcKWOrYGdHfQvinTJAEbXqzMBkstLl.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   IcKWOrYGdHfQvinTJAEbXqzMBkstxl=0
   while IcKWOrYGdHfQvinTJAEbXqzMBkstFL:
    IcKWOrYGdHfQvinTJAEbXqzMBkstxl+=1
    time.sleep(0.05)
    if IcKWOrYGdHfQvinTJAEbXqzMBkstxl>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  IcKWOrYGdHfQvinTJAEbXqzMBkstxU=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.GetCredential(IcKWOrYGdHfQvinTJAEbXqzMBkstxu,IcKWOrYGdHfQvinTJAEbXqzMBkstxF,IcKWOrYGdHfQvinTJAEbXqzMBkstxS,IcKWOrYGdHfQvinTJAEbXqzMBkstxP)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxU:IcKWOrYGdHfQvinTJAEbXqzMBkstLl.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxU==IcKWOrYGdHfQvinTJAEbXqzMBkstFC:
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstxp=IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('stype')
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxp=='live':
   IcKWOrYGdHfQvinTJAEbXqzMBkstxj=IcKWOrYGdHfQvinTJAEbXqzMBkstLD
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstxp=='vod':
   IcKWOrYGdHfQvinTJAEbXqzMBkstxj=IcKWOrYGdHfQvinTJAEbXqzMBkstLN
  else:
   IcKWOrYGdHfQvinTJAEbXqzMBkstxj=IcKWOrYGdHfQvinTJAEbXqzMBkstLu
  for IcKWOrYGdHfQvinTJAEbXqzMBkstxe in IcKWOrYGdHfQvinTJAEbXqzMBkstxj:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj=IcKWOrYGdHfQvinTJAEbXqzMBkstxe.get('title')
   if IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('ordernm')!='-':
    IcKWOrYGdHfQvinTJAEbXqzMBkstCj+='  ('+IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('ordernm')+')'
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':IcKWOrYGdHfQvinTJAEbXqzMBkstxe.get('mode'),'stype':IcKWOrYGdHfQvinTJAEbXqzMBkstxe.get('stype'),'orderby':IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('orderby'),'ordernm':IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('ordernm'),'page':'1'}
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel='',img='',infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstua,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstFN(IcKWOrYGdHfQvinTJAEbXqzMBkstxj)>0:xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle)
 def dp_SubTitle_Group(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR): 
  for IcKWOrYGdHfQvinTJAEbXqzMBkstxe in IcKWOrYGdHfQvinTJAEbXqzMBkstLF:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj=IcKWOrYGdHfQvinTJAEbXqzMBkstxe.get('title')
   if IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('ordernm')!='-':
    IcKWOrYGdHfQvinTJAEbXqzMBkstCj+='  ('+IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('ordernm')+')'
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':IcKWOrYGdHfQvinTJAEbXqzMBkstxe.get('mode'),'genreCode':IcKWOrYGdHfQvinTJAEbXqzMBkstxe.get('genreCode'),'stype':IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('stype'),'orderby':IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('orderby'),'page':'1'}
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel='',img='',infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstua,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstFN(IcKWOrYGdHfQvinTJAEbXqzMBkstLF)>0:xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle)
 def dp_LiveChannel_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstxp =IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('stype')
  IcKWOrYGdHfQvinTJAEbXqzMBkstxh =IcKWOrYGdHfQvinTJAEbXqzMBkstug(IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('page'))
  IcKWOrYGdHfQvinTJAEbXqzMBkstxy,IcKWOrYGdHfQvinTJAEbXqzMBkstxw=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.GetLiveChannelList(IcKWOrYGdHfQvinTJAEbXqzMBkstxp,IcKWOrYGdHfQvinTJAEbXqzMBkstxh)
  for IcKWOrYGdHfQvinTJAEbXqzMBkstxa in IcKWOrYGdHfQvinTJAEbXqzMBkstxy:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('title')
   IcKWOrYGdHfQvinTJAEbXqzMBkstxN =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('channel')
   IcKWOrYGdHfQvinTJAEbXqzMBkstxg =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('thumbnail')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDL =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('synopsis')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDC =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('channelepg')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDx =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('cast')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDV =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('director')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDo =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('info_genre')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDN =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('year')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDu =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('mpaa')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDF =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('premiered')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDS={'mediatype':'episode','title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'studio':IcKWOrYGdHfQvinTJAEbXqzMBkstxN,'cast':IcKWOrYGdHfQvinTJAEbXqzMBkstDx,'director':IcKWOrYGdHfQvinTJAEbXqzMBkstDV,'genre':IcKWOrYGdHfQvinTJAEbXqzMBkstDo,'plot':'%s\n%s\n%s\n\n%s'%(IcKWOrYGdHfQvinTJAEbXqzMBkstxN,IcKWOrYGdHfQvinTJAEbXqzMBkstCj,IcKWOrYGdHfQvinTJAEbXqzMBkstDC,IcKWOrYGdHfQvinTJAEbXqzMBkstDL),'year':IcKWOrYGdHfQvinTJAEbXqzMBkstDN,'mpaa':IcKWOrYGdHfQvinTJAEbXqzMBkstDu,'premiered':IcKWOrYGdHfQvinTJAEbXqzMBkstDF}
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'LIVE','mediacode':IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('mediacode'),'stype':IcKWOrYGdHfQvinTJAEbXqzMBkstxp}
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstxN,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstCj,img=IcKWOrYGdHfQvinTJAEbXqzMBkstxg,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstDS,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFC,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxw:
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['mode']='CHANNEL' 
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['stype']=IcKWOrYGdHfQvinTJAEbXqzMBkstxp 
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['page']=IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj='[B]%s >>[/B]'%'다음 페이지'
   IcKWOrYGdHfQvinTJAEbXqzMBkstDP=IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstxL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstDP,img=IcKWOrYGdHfQvinTJAEbXqzMBkstxL,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstua,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstFN(IcKWOrYGdHfQvinTJAEbXqzMBkstxy)>0:xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,cacheToDisc=IcKWOrYGdHfQvinTJAEbXqzMBkstFC)
 def dp_Program_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstDm =IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('stype')
  IcKWOrYGdHfQvinTJAEbXqzMBkstCU =IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('orderby')
  IcKWOrYGdHfQvinTJAEbXqzMBkstxh =IcKWOrYGdHfQvinTJAEbXqzMBkstug(IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('page'))
  IcKWOrYGdHfQvinTJAEbXqzMBkstDl=IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('genreCode')
  if IcKWOrYGdHfQvinTJAEbXqzMBkstDl==IcKWOrYGdHfQvinTJAEbXqzMBkstua:IcKWOrYGdHfQvinTJAEbXqzMBkstDl='all'
  IcKWOrYGdHfQvinTJAEbXqzMBkstDU,IcKWOrYGdHfQvinTJAEbXqzMBkstxw=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.GetProgramList(IcKWOrYGdHfQvinTJAEbXqzMBkstDm,IcKWOrYGdHfQvinTJAEbXqzMBkstCU,IcKWOrYGdHfQvinTJAEbXqzMBkstxh,IcKWOrYGdHfQvinTJAEbXqzMBkstDl)
  for IcKWOrYGdHfQvinTJAEbXqzMBkstDp in IcKWOrYGdHfQvinTJAEbXqzMBkstDU:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('title')
   IcKWOrYGdHfQvinTJAEbXqzMBkstxg =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('thumbnail')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDL =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('synopsis')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDj =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('channel')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDx =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('cast')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDV =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('director')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDo=IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('info_genre')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDN =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('year')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDF =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('premiered')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDu =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('mpaa')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDS={'mediatype':'tvshow','title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'studio':IcKWOrYGdHfQvinTJAEbXqzMBkstDj,'cast':IcKWOrYGdHfQvinTJAEbXqzMBkstDx,'director':IcKWOrYGdHfQvinTJAEbXqzMBkstDV,'genre':IcKWOrYGdHfQvinTJAEbXqzMBkstDo,'year':IcKWOrYGdHfQvinTJAEbXqzMBkstDN,'premiered':IcKWOrYGdHfQvinTJAEbXqzMBkstDF,'mpaa':IcKWOrYGdHfQvinTJAEbXqzMBkstDu,'plot':IcKWOrYGdHfQvinTJAEbXqzMBkstDL}
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'EPISODE','programcode':IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('program'),'page':'1'}
   if IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_makebookmark():
    IcKWOrYGdHfQvinTJAEbXqzMBkstDe={'videoid':IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('program'),'vidtype':'tvshow','vtitle':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'vsubtitle':IcKWOrYGdHfQvinTJAEbXqzMBkstDj,}
    IcKWOrYGdHfQvinTJAEbXqzMBkstDR=json.dumps(IcKWOrYGdHfQvinTJAEbXqzMBkstDe)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDR=urllib.parse.quote(IcKWOrYGdHfQvinTJAEbXqzMBkstDR)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDh='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(IcKWOrYGdHfQvinTJAEbXqzMBkstDR)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDy=[('(통합) 찜 영상에 추가',IcKWOrYGdHfQvinTJAEbXqzMBkstDh)]
   else:
    IcKWOrYGdHfQvinTJAEbXqzMBkstDy=IcKWOrYGdHfQvinTJAEbXqzMBkstua
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstDj,img=IcKWOrYGdHfQvinTJAEbXqzMBkstxg,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstDS,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC,ContextMenu=IcKWOrYGdHfQvinTJAEbXqzMBkstDy)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxw:
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['mode'] ='PROGRAM' 
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['stype'] =IcKWOrYGdHfQvinTJAEbXqzMBkstDm
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['orderby'] =IcKWOrYGdHfQvinTJAEbXqzMBkstCU
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['page'] =IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['genreCode']=IcKWOrYGdHfQvinTJAEbXqzMBkstDl 
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj='[B]%s >>[/B]'%'다음 페이지'
   IcKWOrYGdHfQvinTJAEbXqzMBkstDP=IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstxL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstDP,img=IcKWOrYGdHfQvinTJAEbXqzMBkstxL,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstua,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  xbmcplugin.setContent(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,cacheToDisc=IcKWOrYGdHfQvinTJAEbXqzMBkstFC)
 def dp_4K_Program_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstxh =IcKWOrYGdHfQvinTJAEbXqzMBkstug(IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('page'))
  IcKWOrYGdHfQvinTJAEbXqzMBkstDU,IcKWOrYGdHfQvinTJAEbXqzMBkstxw=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Get_UHD_ProgramList(IcKWOrYGdHfQvinTJAEbXqzMBkstxh)
  for IcKWOrYGdHfQvinTJAEbXqzMBkstDp in IcKWOrYGdHfQvinTJAEbXqzMBkstDU:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('title')
   IcKWOrYGdHfQvinTJAEbXqzMBkstxg =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('thumbnail')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDL =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('synopsis')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDj =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('channel')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDx =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('cast')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDV =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('director')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDo=IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('info_genre')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDN =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('year')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDF =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('premiered')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDu =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('mpaa')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDS={'mediatype':'tvshow','title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'studio':IcKWOrYGdHfQvinTJAEbXqzMBkstDj,'cast':IcKWOrYGdHfQvinTJAEbXqzMBkstDx,'director':IcKWOrYGdHfQvinTJAEbXqzMBkstDV,'genre':IcKWOrYGdHfQvinTJAEbXqzMBkstDo,'year':IcKWOrYGdHfQvinTJAEbXqzMBkstDN,'premiered':IcKWOrYGdHfQvinTJAEbXqzMBkstDF,'mpaa':IcKWOrYGdHfQvinTJAEbXqzMBkstDu,'plot':IcKWOrYGdHfQvinTJAEbXqzMBkstDL}
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'EPISODE','programcode':IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('program'),'page':'1'}
   if IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_makebookmark():
    IcKWOrYGdHfQvinTJAEbXqzMBkstDe={'videoid':IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('program'),'vidtype':'tvshow','vtitle':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'vsubtitle':IcKWOrYGdHfQvinTJAEbXqzMBkstDj,}
    IcKWOrYGdHfQvinTJAEbXqzMBkstDR=json.dumps(IcKWOrYGdHfQvinTJAEbXqzMBkstDe)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDR=urllib.parse.quote(IcKWOrYGdHfQvinTJAEbXqzMBkstDR)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDh='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(IcKWOrYGdHfQvinTJAEbXqzMBkstDR)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDy=[('(통합) 찜 영상에 추가',IcKWOrYGdHfQvinTJAEbXqzMBkstDh)]
   else:
    IcKWOrYGdHfQvinTJAEbXqzMBkstDy=IcKWOrYGdHfQvinTJAEbXqzMBkstua
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstDj,img=IcKWOrYGdHfQvinTJAEbXqzMBkstxg,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstDS,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC,ContextMenu=IcKWOrYGdHfQvinTJAEbXqzMBkstDy)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxw:
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['mode'] ='4K_PROGRAM' 
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['page'] =IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj='[B]%s >>[/B]'%'다음 페이지'
   IcKWOrYGdHfQvinTJAEbXqzMBkstDP=IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstxL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstDP,img=IcKWOrYGdHfQvinTJAEbXqzMBkstxL,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstua,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  xbmcplugin.setContent(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,cacheToDisc=IcKWOrYGdHfQvinTJAEbXqzMBkstFC)
 def dp_Ori_Program_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstxh =IcKWOrYGdHfQvinTJAEbXqzMBkstug(IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('page'))
  IcKWOrYGdHfQvinTJAEbXqzMBkstDU,IcKWOrYGdHfQvinTJAEbXqzMBkstxw=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Get_Origianl_ProgramList(IcKWOrYGdHfQvinTJAEbXqzMBkstxh)
  for IcKWOrYGdHfQvinTJAEbXqzMBkstDp in IcKWOrYGdHfQvinTJAEbXqzMBkstDU:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('title')
   IcKWOrYGdHfQvinTJAEbXqzMBkstxg =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('thumbnail')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDa =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('vod_type')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDg =IcKWOrYGdHfQvinTJAEbXqzMBkstDp.get('vod_code')
   if IcKWOrYGdHfQvinTJAEbXqzMBkstDa=='vod':
    IcKWOrYGdHfQvinTJAEbXqzMBkstDS={'mediatype':'tvshow','title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,}
    IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'EPISODE','programcode':IcKWOrYGdHfQvinTJAEbXqzMBkstDg,'page':'1',}
    IcKWOrYGdHfQvinTJAEbXqzMBkstxD=IcKWOrYGdHfQvinTJAEbXqzMBkstFL
   else:
    IcKWOrYGdHfQvinTJAEbXqzMBkstDS={'mediatype':'movie','title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'plot':'movie',}
    IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'MOVIE','mediacode':IcKWOrYGdHfQvinTJAEbXqzMBkstDg,'stype':'movie','title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'thumbnail':IcKWOrYGdHfQvinTJAEbXqzMBkstxg,}
    IcKWOrYGdHfQvinTJAEbXqzMBkstxD=IcKWOrYGdHfQvinTJAEbXqzMBkstFC
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstua,img=IcKWOrYGdHfQvinTJAEbXqzMBkstxg,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstDS,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstxD,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC,ContextMenu=IcKWOrYGdHfQvinTJAEbXqzMBkstua)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxw:
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['mode'] ='ORI_PROGRAM' 
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['page'] =IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj='[B]%s >>[/B]'%'다음 페이지'
   IcKWOrYGdHfQvinTJAEbXqzMBkstDP=IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstxL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstDP,img=IcKWOrYGdHfQvinTJAEbXqzMBkstxL,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstua,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  xbmcplugin.setContent(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,cacheToDisc=IcKWOrYGdHfQvinTJAEbXqzMBkstFC)
 def dp_Episode_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstVL=IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('programcode')
  IcKWOrYGdHfQvinTJAEbXqzMBkstxh =IcKWOrYGdHfQvinTJAEbXqzMBkstug(IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('page'))
  IcKWOrYGdHfQvinTJAEbXqzMBkstVC,IcKWOrYGdHfQvinTJAEbXqzMBkstxw,IcKWOrYGdHfQvinTJAEbXqzMBkstVx=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.GetEpisodeList(IcKWOrYGdHfQvinTJAEbXqzMBkstVL,IcKWOrYGdHfQvinTJAEbXqzMBkstxh,orderby=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_winEpisodeOrderby())
  for IcKWOrYGdHfQvinTJAEbXqzMBkstVD in IcKWOrYGdHfQvinTJAEbXqzMBkstVC:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj =IcKWOrYGdHfQvinTJAEbXqzMBkstVD.get('title')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDP =IcKWOrYGdHfQvinTJAEbXqzMBkstVD.get('subtitle')
   IcKWOrYGdHfQvinTJAEbXqzMBkstxg =IcKWOrYGdHfQvinTJAEbXqzMBkstVD.get('thumbnail')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDL =IcKWOrYGdHfQvinTJAEbXqzMBkstVD.get('synopsis')
   IcKWOrYGdHfQvinTJAEbXqzMBkstVo=IcKWOrYGdHfQvinTJAEbXqzMBkstVD.get('info_title')
   IcKWOrYGdHfQvinTJAEbXqzMBkstVN =IcKWOrYGdHfQvinTJAEbXqzMBkstVD.get('aired')
   IcKWOrYGdHfQvinTJAEbXqzMBkstVu =IcKWOrYGdHfQvinTJAEbXqzMBkstVD.get('studio')
   IcKWOrYGdHfQvinTJAEbXqzMBkstVF =IcKWOrYGdHfQvinTJAEbXqzMBkstVD.get('frequency')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDS={'mediatype':'episode','title':IcKWOrYGdHfQvinTJAEbXqzMBkstVo,'aired':IcKWOrYGdHfQvinTJAEbXqzMBkstVN,'studio':IcKWOrYGdHfQvinTJAEbXqzMBkstVu,'episode':IcKWOrYGdHfQvinTJAEbXqzMBkstVF,'plot':IcKWOrYGdHfQvinTJAEbXqzMBkstDL}
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'VOD','mediacode':IcKWOrYGdHfQvinTJAEbXqzMBkstVD.get('episode'),'stype':'vod','programcode':IcKWOrYGdHfQvinTJAEbXqzMBkstVL,'title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'thumbnail':IcKWOrYGdHfQvinTJAEbXqzMBkstxg}
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstDP,img=IcKWOrYGdHfQvinTJAEbXqzMBkstxg,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstDS,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFC,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxh==1:
   IcKWOrYGdHfQvinTJAEbXqzMBkstDS={'plot':'정렬순서를 변경합니다.'}
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={}
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['mode'] ='ORDER_BY' 
   if IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_winEpisodeOrderby()=='desc':
    IcKWOrYGdHfQvinTJAEbXqzMBkstCj='정렬순서변경 : 최신화부터 -> 1회부터'
    IcKWOrYGdHfQvinTJAEbXqzMBkstxC['orderby']='asc'
   else:
    IcKWOrYGdHfQvinTJAEbXqzMBkstCj='정렬순서변경 : 1회부터 -> 최신화부터'
    IcKWOrYGdHfQvinTJAEbXqzMBkstxC['orderby']='desc'
   IcKWOrYGdHfQvinTJAEbXqzMBkstxL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel='',img=IcKWOrYGdHfQvinTJAEbXqzMBkstxL,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstDS,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFC,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC,isLink=IcKWOrYGdHfQvinTJAEbXqzMBkstFL)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxw:
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['mode'] ='EPISODE' 
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['programcode']=IcKWOrYGdHfQvinTJAEbXqzMBkstVL
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['page'] =IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj='[B]%s >>[/B]'%'다음 페이지'
   IcKWOrYGdHfQvinTJAEbXqzMBkstDP=IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstxL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstDP,img=IcKWOrYGdHfQvinTJAEbXqzMBkstxL,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstua,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  xbmcplugin.setContent(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,'episodes')
  if IcKWOrYGdHfQvinTJAEbXqzMBkstFN(IcKWOrYGdHfQvinTJAEbXqzMBkstVC)>0:xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,cacheToDisc=IcKWOrYGdHfQvinTJAEbXqzMBkstFL)
 def dp_setEpOrderby(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstCU =IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('orderby')
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.set_winEpisodeOrderby(IcKWOrYGdHfQvinTJAEbXqzMBkstCU)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstDm =IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('stype')
  IcKWOrYGdHfQvinTJAEbXqzMBkstCU =IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('orderby')
  IcKWOrYGdHfQvinTJAEbXqzMBkstxh=IcKWOrYGdHfQvinTJAEbXqzMBkstug(IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('page'))
  IcKWOrYGdHfQvinTJAEbXqzMBkstVS,IcKWOrYGdHfQvinTJAEbXqzMBkstxw=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.GetMovieList(IcKWOrYGdHfQvinTJAEbXqzMBkstDm,IcKWOrYGdHfQvinTJAEbXqzMBkstCU,IcKWOrYGdHfQvinTJAEbXqzMBkstxh)
  for IcKWOrYGdHfQvinTJAEbXqzMBkstVP in IcKWOrYGdHfQvinTJAEbXqzMBkstVS:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('title')
   IcKWOrYGdHfQvinTJAEbXqzMBkstxg =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('thumbnail')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDL =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('synopsis')
   IcKWOrYGdHfQvinTJAEbXqzMBkstVo =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('info_title')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDN =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('year')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDx =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('cast')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDV =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('director')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDo =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('info_genre')
   IcKWOrYGdHfQvinTJAEbXqzMBkstVm =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('duration')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDF =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('premiered')
   IcKWOrYGdHfQvinTJAEbXqzMBkstVu =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('studio')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDu =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('mpaa')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDS={'mediatype':'movie','title':IcKWOrYGdHfQvinTJAEbXqzMBkstVo,'year':IcKWOrYGdHfQvinTJAEbXqzMBkstDN,'cast':IcKWOrYGdHfQvinTJAEbXqzMBkstDx,'director':IcKWOrYGdHfQvinTJAEbXqzMBkstDV,'genre':IcKWOrYGdHfQvinTJAEbXqzMBkstDo,'duration':IcKWOrYGdHfQvinTJAEbXqzMBkstVm,'premiered':IcKWOrYGdHfQvinTJAEbXqzMBkstDF,'studio':IcKWOrYGdHfQvinTJAEbXqzMBkstVu,'mpaa':IcKWOrYGdHfQvinTJAEbXqzMBkstDu,'plot':IcKWOrYGdHfQvinTJAEbXqzMBkstDL}
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'MOVIE','mediacode':IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('moviecode'),'stype':'movie','title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'thumbnail':IcKWOrYGdHfQvinTJAEbXqzMBkstxg}
   if IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_makebookmark():
    IcKWOrYGdHfQvinTJAEbXqzMBkstDe={'videoid':IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('moviecode'),'vidtype':'movie','vtitle':IcKWOrYGdHfQvinTJAEbXqzMBkstVo,'vsubtitle':'',}
    IcKWOrYGdHfQvinTJAEbXqzMBkstDR=json.dumps(IcKWOrYGdHfQvinTJAEbXqzMBkstDe)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDR=urllib.parse.quote(IcKWOrYGdHfQvinTJAEbXqzMBkstDR)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDh='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(IcKWOrYGdHfQvinTJAEbXqzMBkstDR)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDy=[('(통합) 찜 영상에 추가',IcKWOrYGdHfQvinTJAEbXqzMBkstDh)]
   else:
    IcKWOrYGdHfQvinTJAEbXqzMBkstDy=IcKWOrYGdHfQvinTJAEbXqzMBkstua
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel='',img=IcKWOrYGdHfQvinTJAEbXqzMBkstxg,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstDS,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFC,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC,ContextMenu=IcKWOrYGdHfQvinTJAEbXqzMBkstDy)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxw:
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={}
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['mode'] ='MOVIE_SUB' 
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['orderby']=IcKWOrYGdHfQvinTJAEbXqzMBkstCU
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['stype'] =IcKWOrYGdHfQvinTJAEbXqzMBkstDm
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['page'] =IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj='[B]%s >>[/B]'%'다음 페이지'
   IcKWOrYGdHfQvinTJAEbXqzMBkstDP=IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstxL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstDP,img=IcKWOrYGdHfQvinTJAEbXqzMBkstxL,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstua,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  xbmcplugin.setContent(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,'movies')
  xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,cacheToDisc=IcKWOrYGdHfQvinTJAEbXqzMBkstFC)
 def dp_4K_Movie_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstxh=IcKWOrYGdHfQvinTJAEbXqzMBkstug(IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('page'))
  IcKWOrYGdHfQvinTJAEbXqzMBkstVS,IcKWOrYGdHfQvinTJAEbXqzMBkstxw=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Get_UHD_MovieList(IcKWOrYGdHfQvinTJAEbXqzMBkstxh)
  for IcKWOrYGdHfQvinTJAEbXqzMBkstVP in IcKWOrYGdHfQvinTJAEbXqzMBkstVS:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('title')
   IcKWOrYGdHfQvinTJAEbXqzMBkstxg =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('thumbnail')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDL =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('synopsis')
   IcKWOrYGdHfQvinTJAEbXqzMBkstVo =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('info_title')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDN =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('year')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDx =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('cast')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDV =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('director')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDo =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('info_genre')
   IcKWOrYGdHfQvinTJAEbXqzMBkstVm =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('duration')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDF =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('premiered')
   IcKWOrYGdHfQvinTJAEbXqzMBkstVu =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('studio')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDu =IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('mpaa')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDS={'mediatype':'movie','title':IcKWOrYGdHfQvinTJAEbXqzMBkstVo,'year':IcKWOrYGdHfQvinTJAEbXqzMBkstDN,'cast':IcKWOrYGdHfQvinTJAEbXqzMBkstDx,'director':IcKWOrYGdHfQvinTJAEbXqzMBkstDV,'genre':IcKWOrYGdHfQvinTJAEbXqzMBkstDo,'duration':IcKWOrYGdHfQvinTJAEbXqzMBkstVm,'premiered':IcKWOrYGdHfQvinTJAEbXqzMBkstDF,'studio':IcKWOrYGdHfQvinTJAEbXqzMBkstVu,'mpaa':IcKWOrYGdHfQvinTJAEbXqzMBkstDu,'plot':IcKWOrYGdHfQvinTJAEbXqzMBkstDL}
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'MOVIE','mediacode':IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('moviecode'),'stype':'movie','title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'thumbnail':IcKWOrYGdHfQvinTJAEbXqzMBkstxg}
   if IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_makebookmark():
    IcKWOrYGdHfQvinTJAEbXqzMBkstDe={'videoid':IcKWOrYGdHfQvinTJAEbXqzMBkstVP.get('moviecode'),'vidtype':'movie','vtitle':IcKWOrYGdHfQvinTJAEbXqzMBkstVo,'vsubtitle':'',}
    IcKWOrYGdHfQvinTJAEbXqzMBkstDR=json.dumps(IcKWOrYGdHfQvinTJAEbXqzMBkstDe)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDR=urllib.parse.quote(IcKWOrYGdHfQvinTJAEbXqzMBkstDR)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDh='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(IcKWOrYGdHfQvinTJAEbXqzMBkstDR)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDy=[('(통합) 찜 영상에 추가',IcKWOrYGdHfQvinTJAEbXqzMBkstDh)]
   else:
    IcKWOrYGdHfQvinTJAEbXqzMBkstDy=IcKWOrYGdHfQvinTJAEbXqzMBkstua
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel='',img=IcKWOrYGdHfQvinTJAEbXqzMBkstxg,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstDS,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFC,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC,ContextMenu=IcKWOrYGdHfQvinTJAEbXqzMBkstDy)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxw:
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={}
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['mode'] ='4K_MOVIE' 
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['page'] =IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj='[B]%s >>[/B]'%'다음 페이지'
   IcKWOrYGdHfQvinTJAEbXqzMBkstDP=IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstxL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstDP,img=IcKWOrYGdHfQvinTJAEbXqzMBkstxL,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstua,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  xbmcplugin.setContent(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,'movies')
  xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,cacheToDisc=IcKWOrYGdHfQvinTJAEbXqzMBkstFC)
 def dp_Set_Bookmark(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstVl=urllib.parse.unquote(IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('bm_param'))
  IcKWOrYGdHfQvinTJAEbXqzMBkstVl=json.loads(IcKWOrYGdHfQvinTJAEbXqzMBkstVl)
  IcKWOrYGdHfQvinTJAEbXqzMBkstVU =IcKWOrYGdHfQvinTJAEbXqzMBkstVl.get('videoid')
  IcKWOrYGdHfQvinTJAEbXqzMBkstVp =IcKWOrYGdHfQvinTJAEbXqzMBkstVl.get('vidtype')
  IcKWOrYGdHfQvinTJAEbXqzMBkstVj =IcKWOrYGdHfQvinTJAEbXqzMBkstVl.get('vtitle')
  IcKWOrYGdHfQvinTJAEbXqzMBkstVe =IcKWOrYGdHfQvinTJAEbXqzMBkstVl.get('vsubtitle')
  IcKWOrYGdHfQvinTJAEbXqzMBkstLR=xbmcgui.Dialog()
  IcKWOrYGdHfQvinTJAEbXqzMBkstxm=IcKWOrYGdHfQvinTJAEbXqzMBkstLR.yesno(__language__(30913).encode('utf8'),IcKWOrYGdHfQvinTJAEbXqzMBkstVj+' \n\n'+__language__(30914))
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxm==IcKWOrYGdHfQvinTJAEbXqzMBkstFC:return
  IcKWOrYGdHfQvinTJAEbXqzMBkstVR=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.GetBookmarkInfo(IcKWOrYGdHfQvinTJAEbXqzMBkstVU,IcKWOrYGdHfQvinTJAEbXqzMBkstVp)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstVe!='':
   IcKWOrYGdHfQvinTJAEbXqzMBkstVR['saveinfo']['subtitle']=IcKWOrYGdHfQvinTJAEbXqzMBkstVe 
   if IcKWOrYGdHfQvinTJAEbXqzMBkstVp=='tvshow':IcKWOrYGdHfQvinTJAEbXqzMBkstVR['saveinfo']['infoLabels']['studio']=IcKWOrYGdHfQvinTJAEbXqzMBkstVe 
  IcKWOrYGdHfQvinTJAEbXqzMBkstVh=json.dumps(IcKWOrYGdHfQvinTJAEbXqzMBkstVR)
  IcKWOrYGdHfQvinTJAEbXqzMBkstVh=urllib.parse.quote(IcKWOrYGdHfQvinTJAEbXqzMBkstVh)
  IcKWOrYGdHfQvinTJAEbXqzMBkstDh ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(IcKWOrYGdHfQvinTJAEbXqzMBkstVh)
  xbmc.executebuiltin(IcKWOrYGdHfQvinTJAEbXqzMBkstDh)
 def dp_Search_Group(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  if 'search_key' in IcKWOrYGdHfQvinTJAEbXqzMBkstxR:
   IcKWOrYGdHfQvinTJAEbXqzMBkstVy=IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('search_key')
  else:
   IcKWOrYGdHfQvinTJAEbXqzMBkstVy=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not IcKWOrYGdHfQvinTJAEbXqzMBkstVy:
    return
  for IcKWOrYGdHfQvinTJAEbXqzMBkstxe in IcKWOrYGdHfQvinTJAEbXqzMBkstLo:
   IcKWOrYGdHfQvinTJAEbXqzMBkstVw =IcKWOrYGdHfQvinTJAEbXqzMBkstxe.get('mode')
   IcKWOrYGdHfQvinTJAEbXqzMBkstxp=IcKWOrYGdHfQvinTJAEbXqzMBkstxe.get('stype')
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj=IcKWOrYGdHfQvinTJAEbXqzMBkstxe.get('title')
   (IcKWOrYGdHfQvinTJAEbXqzMBkstVa,IcKWOrYGdHfQvinTJAEbXqzMBkstxw)=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.GetSearchList(IcKWOrYGdHfQvinTJAEbXqzMBkstVy,1,IcKWOrYGdHfQvinTJAEbXqzMBkstxp)
   IcKWOrYGdHfQvinTJAEbXqzMBkstxo={'plot':'검색어 : '+IcKWOrYGdHfQvinTJAEbXqzMBkstVy+'\n\n'+IcKWOrYGdHfQvinTJAEbXqzMBkstLl.Search_FreeList(IcKWOrYGdHfQvinTJAEbXqzMBkstVa)}
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':IcKWOrYGdHfQvinTJAEbXqzMBkstVw,'stype':IcKWOrYGdHfQvinTJAEbXqzMBkstxp,'search_key':IcKWOrYGdHfQvinTJAEbXqzMBkstVy,'page':'1',}
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel='',img='',infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstxo,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstFN(IcKWOrYGdHfQvinTJAEbXqzMBkstLo)>0:xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,cacheToDisc=IcKWOrYGdHfQvinTJAEbXqzMBkstFL)
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.Save_Searched_List(IcKWOrYGdHfQvinTJAEbXqzMBkstVy)
 def Search_FreeList(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstoF):
  IcKWOrYGdHfQvinTJAEbXqzMBkstVg=''
  IcKWOrYGdHfQvinTJAEbXqzMBkstoL=7
  try:
   if IcKWOrYGdHfQvinTJAEbXqzMBkstFN(IcKWOrYGdHfQvinTJAEbXqzMBkstoF)==0:return '검색결과 없음'
   for i in IcKWOrYGdHfQvinTJAEbXqzMBkstFS(IcKWOrYGdHfQvinTJAEbXqzMBkstFN(IcKWOrYGdHfQvinTJAEbXqzMBkstoF)):
    if i>=IcKWOrYGdHfQvinTJAEbXqzMBkstoL:
     IcKWOrYGdHfQvinTJAEbXqzMBkstVg=IcKWOrYGdHfQvinTJAEbXqzMBkstVg+'...'
     break
    IcKWOrYGdHfQvinTJAEbXqzMBkstVg=IcKWOrYGdHfQvinTJAEbXqzMBkstVg+IcKWOrYGdHfQvinTJAEbXqzMBkstoF[i]['title']+'\n'
  except:
   return ''
  return IcKWOrYGdHfQvinTJAEbXqzMBkstVg
 def dp_Search_History(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstoC=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.Load_List_File('search')
  for IcKWOrYGdHfQvinTJAEbXqzMBkstox in IcKWOrYGdHfQvinTJAEbXqzMBkstoC:
   IcKWOrYGdHfQvinTJAEbXqzMBkstoD=IcKWOrYGdHfQvinTJAEbXqzMBkstFD(urllib.parse.parse_qsl(IcKWOrYGdHfQvinTJAEbXqzMBkstox))
   IcKWOrYGdHfQvinTJAEbXqzMBkstoV=IcKWOrYGdHfQvinTJAEbXqzMBkstoD.get('skey').strip()
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'SEARCH_GROUP','search_key':IcKWOrYGdHfQvinTJAEbXqzMBkstoV,}
   IcKWOrYGdHfQvinTJAEbXqzMBkstoN={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':IcKWOrYGdHfQvinTJAEbXqzMBkstoV,'vType':'-',}
   IcKWOrYGdHfQvinTJAEbXqzMBkstou=urllib.parse.urlencode(IcKWOrYGdHfQvinTJAEbXqzMBkstoN)
   IcKWOrYGdHfQvinTJAEbXqzMBkstDy=[('선택된 검색어 ( %s ) 삭제'%(IcKWOrYGdHfQvinTJAEbXqzMBkstoV),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(IcKWOrYGdHfQvinTJAEbXqzMBkstou))]
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstoV,sublabel='',img=IcKWOrYGdHfQvinTJAEbXqzMBkstua,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstua,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC,ContextMenu=IcKWOrYGdHfQvinTJAEbXqzMBkstDy)
  IcKWOrYGdHfQvinTJAEbXqzMBkstDS={'plot':'검색목록 전체를 삭제합니다.'}
  IcKWOrYGdHfQvinTJAEbXqzMBkstCj='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  IcKWOrYGdHfQvinTJAEbXqzMBkstxL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel='',img=IcKWOrYGdHfQvinTJAEbXqzMBkstxL,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstDS,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFC,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC,isLink=IcKWOrYGdHfQvinTJAEbXqzMBkstFL)
  xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,cacheToDisc=IcKWOrYGdHfQvinTJAEbXqzMBkstFC)
 def dp_Search_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstxh =IcKWOrYGdHfQvinTJAEbXqzMBkstug(IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('page'))
  IcKWOrYGdHfQvinTJAEbXqzMBkstxp =IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('stype')
  if 'search_key' in IcKWOrYGdHfQvinTJAEbXqzMBkstxR:
   IcKWOrYGdHfQvinTJAEbXqzMBkstVy=IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('search_key')
  else:
   IcKWOrYGdHfQvinTJAEbXqzMBkstVy=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not IcKWOrYGdHfQvinTJAEbXqzMBkstVy:
    xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle)
    return
  IcKWOrYGdHfQvinTJAEbXqzMBkstVa,IcKWOrYGdHfQvinTJAEbXqzMBkstxw=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.GetSearchList(IcKWOrYGdHfQvinTJAEbXqzMBkstVy,IcKWOrYGdHfQvinTJAEbXqzMBkstxh,IcKWOrYGdHfQvinTJAEbXqzMBkstxp)
  for IcKWOrYGdHfQvinTJAEbXqzMBkstoF in IcKWOrYGdHfQvinTJAEbXqzMBkstVa:
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj =IcKWOrYGdHfQvinTJAEbXqzMBkstoF.get('title')
   IcKWOrYGdHfQvinTJAEbXqzMBkstxg =IcKWOrYGdHfQvinTJAEbXqzMBkstoF.get('thumbnail')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDL =IcKWOrYGdHfQvinTJAEbXqzMBkstoF.get('synopsis')
   IcKWOrYGdHfQvinTJAEbXqzMBkstoS =IcKWOrYGdHfQvinTJAEbXqzMBkstoF.get('program')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDx =IcKWOrYGdHfQvinTJAEbXqzMBkstoF.get('cast')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDV =IcKWOrYGdHfQvinTJAEbXqzMBkstoF.get('director')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDo=IcKWOrYGdHfQvinTJAEbXqzMBkstoF.get('info_genre')
   IcKWOrYGdHfQvinTJAEbXqzMBkstVm =IcKWOrYGdHfQvinTJAEbXqzMBkstoF.get('duration')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDu =IcKWOrYGdHfQvinTJAEbXqzMBkstoF.get('mpaa')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDN =IcKWOrYGdHfQvinTJAEbXqzMBkstoF.get('year')
   IcKWOrYGdHfQvinTJAEbXqzMBkstVN =IcKWOrYGdHfQvinTJAEbXqzMBkstoF.get('aired')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDS={'mediatype':'tvshow' if IcKWOrYGdHfQvinTJAEbXqzMBkstxp=='vod' else 'movie','title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'cast':IcKWOrYGdHfQvinTJAEbXqzMBkstDx,'director':IcKWOrYGdHfQvinTJAEbXqzMBkstDV,'genre':IcKWOrYGdHfQvinTJAEbXqzMBkstDo,'duration':IcKWOrYGdHfQvinTJAEbXqzMBkstVm,'mpaa':IcKWOrYGdHfQvinTJAEbXqzMBkstDu,'year':IcKWOrYGdHfQvinTJAEbXqzMBkstDN,'aired':IcKWOrYGdHfQvinTJAEbXqzMBkstVN,'plot':'%s\n\n%s'%(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,IcKWOrYGdHfQvinTJAEbXqzMBkstDL)}
   if IcKWOrYGdHfQvinTJAEbXqzMBkstxp=='vod':
    IcKWOrYGdHfQvinTJAEbXqzMBkstVU=IcKWOrYGdHfQvinTJAEbXqzMBkstoF.get('program')
    IcKWOrYGdHfQvinTJAEbXqzMBkstVp='tvshow'
    IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'EPISODE','programcode':IcKWOrYGdHfQvinTJAEbXqzMBkstVU,'page':'1',}
    IcKWOrYGdHfQvinTJAEbXqzMBkstxD=IcKWOrYGdHfQvinTJAEbXqzMBkstFL
   else:
    IcKWOrYGdHfQvinTJAEbXqzMBkstVU=IcKWOrYGdHfQvinTJAEbXqzMBkstoF.get('movie')
    IcKWOrYGdHfQvinTJAEbXqzMBkstVp='movie'
    IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'MOVIE','mediacode':IcKWOrYGdHfQvinTJAEbXqzMBkstVU,'stype':'movie','title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'thumbnail':IcKWOrYGdHfQvinTJAEbXqzMBkstxg,}
    IcKWOrYGdHfQvinTJAEbXqzMBkstxD=IcKWOrYGdHfQvinTJAEbXqzMBkstFC
   if IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_makebookmark():
    IcKWOrYGdHfQvinTJAEbXqzMBkstDe={'videoid':IcKWOrYGdHfQvinTJAEbXqzMBkstVU,'vidtype':IcKWOrYGdHfQvinTJAEbXqzMBkstVp,'vtitle':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'vsubtitle':'',}
    IcKWOrYGdHfQvinTJAEbXqzMBkstDR=json.dumps(IcKWOrYGdHfQvinTJAEbXqzMBkstDe)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDR=urllib.parse.quote(IcKWOrYGdHfQvinTJAEbXqzMBkstDR)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDh='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(IcKWOrYGdHfQvinTJAEbXqzMBkstDR)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDy=[('(통합) 찜 영상에 추가',IcKWOrYGdHfQvinTJAEbXqzMBkstDh)]
   else:
    IcKWOrYGdHfQvinTJAEbXqzMBkstDy=IcKWOrYGdHfQvinTJAEbXqzMBkstua
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel='',img=IcKWOrYGdHfQvinTJAEbXqzMBkstxg,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstDS,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstxD,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC,isLink=IcKWOrYGdHfQvinTJAEbXqzMBkstFC,ContextMenu=IcKWOrYGdHfQvinTJAEbXqzMBkstDy)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxw:
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['mode'] ='SEARCH' 
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['search_key']=IcKWOrYGdHfQvinTJAEbXqzMBkstVy
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC['page'] =IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj='[B]%s >>[/B]'%'다음 페이지'
   IcKWOrYGdHfQvinTJAEbXqzMBkstDP=IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstxh+1)
   IcKWOrYGdHfQvinTJAEbXqzMBkstxL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstDP,img=IcKWOrYGdHfQvinTJAEbXqzMBkstxL,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstua,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxp=='movie':xbmcplugin.setContent(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,'movies')
  else:xbmcplugin.setContent(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,cacheToDisc=IcKWOrYGdHfQvinTJAEbXqzMBkstFC)
 def dp_History_Remove(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstoP=IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('delType')
  IcKWOrYGdHfQvinTJAEbXqzMBkstom =IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('sKey')
  IcKWOrYGdHfQvinTJAEbXqzMBkstol =IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('vType')
  IcKWOrYGdHfQvinTJAEbXqzMBkstLR=xbmcgui.Dialog()
  if IcKWOrYGdHfQvinTJAEbXqzMBkstoP=='SEARCH_ALL':
   IcKWOrYGdHfQvinTJAEbXqzMBkstxm=IcKWOrYGdHfQvinTJAEbXqzMBkstLR.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstoP=='SEARCH_ONE':
   IcKWOrYGdHfQvinTJAEbXqzMBkstxm=IcKWOrYGdHfQvinTJAEbXqzMBkstLR.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstoP=='WATCH_ALL':
   IcKWOrYGdHfQvinTJAEbXqzMBkstxm=IcKWOrYGdHfQvinTJAEbXqzMBkstLR.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstoP=='WATCH_ONE':
   IcKWOrYGdHfQvinTJAEbXqzMBkstxm=IcKWOrYGdHfQvinTJAEbXqzMBkstLR.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxm==IcKWOrYGdHfQvinTJAEbXqzMBkstFC:sys.exit()
  if IcKWOrYGdHfQvinTJAEbXqzMBkstoP=='SEARCH_ALL':
   if os.path.isfile(IcKWOrYGdHfQvinTJAEbXqzMBkstLm):os.remove(IcKWOrYGdHfQvinTJAEbXqzMBkstLm)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstoP=='SEARCH_ONE':
   try:
    IcKWOrYGdHfQvinTJAEbXqzMBkstoU=IcKWOrYGdHfQvinTJAEbXqzMBkstLm
    IcKWOrYGdHfQvinTJAEbXqzMBkstop=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.Load_List_File('search') 
    fp=IcKWOrYGdHfQvinTJAEbXqzMBkstFP(IcKWOrYGdHfQvinTJAEbXqzMBkstoU,'w',-1,'utf-8')
    for IcKWOrYGdHfQvinTJAEbXqzMBkstoj in IcKWOrYGdHfQvinTJAEbXqzMBkstop:
     IcKWOrYGdHfQvinTJAEbXqzMBkstoe=IcKWOrYGdHfQvinTJAEbXqzMBkstFD(urllib.parse.parse_qsl(IcKWOrYGdHfQvinTJAEbXqzMBkstoj))
     IcKWOrYGdHfQvinTJAEbXqzMBkstoR=IcKWOrYGdHfQvinTJAEbXqzMBkstoe.get('skey').strip()
     if IcKWOrYGdHfQvinTJAEbXqzMBkstom!=IcKWOrYGdHfQvinTJAEbXqzMBkstoR:
      fp.write(IcKWOrYGdHfQvinTJAEbXqzMBkstoj)
    fp.close()
   except:
    IcKWOrYGdHfQvinTJAEbXqzMBkstua
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstoP=='WATCH_ALL':
   IcKWOrYGdHfQvinTJAEbXqzMBkstoU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IcKWOrYGdHfQvinTJAEbXqzMBkstol))
   if os.path.isfile(IcKWOrYGdHfQvinTJAEbXqzMBkstoU):os.remove(IcKWOrYGdHfQvinTJAEbXqzMBkstoU)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstoP=='WATCH_ONE':
   IcKWOrYGdHfQvinTJAEbXqzMBkstoU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IcKWOrYGdHfQvinTJAEbXqzMBkstol))
   try:
    IcKWOrYGdHfQvinTJAEbXqzMBkstop=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.Load_List_File(IcKWOrYGdHfQvinTJAEbXqzMBkstol) 
    fp=IcKWOrYGdHfQvinTJAEbXqzMBkstFP(IcKWOrYGdHfQvinTJAEbXqzMBkstoU,'w',-1,'utf-8')
    for IcKWOrYGdHfQvinTJAEbXqzMBkstoj in IcKWOrYGdHfQvinTJAEbXqzMBkstop:
     IcKWOrYGdHfQvinTJAEbXqzMBkstoe=IcKWOrYGdHfQvinTJAEbXqzMBkstFD(urllib.parse.parse_qsl(IcKWOrYGdHfQvinTJAEbXqzMBkstoj))
     IcKWOrYGdHfQvinTJAEbXqzMBkstoR=IcKWOrYGdHfQvinTJAEbXqzMBkstoe.get('code').strip()
     if IcKWOrYGdHfQvinTJAEbXqzMBkstom!=IcKWOrYGdHfQvinTJAEbXqzMBkstoR:
      fp.write(IcKWOrYGdHfQvinTJAEbXqzMBkstoj)
    fp.close()
   except:
    IcKWOrYGdHfQvinTJAEbXqzMBkstua
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxp): 
  try:
   if IcKWOrYGdHfQvinTJAEbXqzMBkstxp=='search':
    IcKWOrYGdHfQvinTJAEbXqzMBkstoU=IcKWOrYGdHfQvinTJAEbXqzMBkstLm
   elif IcKWOrYGdHfQvinTJAEbXqzMBkstxp in['vod','movie']:
    IcKWOrYGdHfQvinTJAEbXqzMBkstoU=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IcKWOrYGdHfQvinTJAEbXqzMBkstxp))
   else:
    return[]
   fp=IcKWOrYGdHfQvinTJAEbXqzMBkstFP(IcKWOrYGdHfQvinTJAEbXqzMBkstoU,'r',-1,'utf-8')
   IcKWOrYGdHfQvinTJAEbXqzMBkstoh=fp.readlines()
   fp.close()
  except:
   IcKWOrYGdHfQvinTJAEbXqzMBkstoh=[]
  return IcKWOrYGdHfQvinTJAEbXqzMBkstoh
 def Save_Watched_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxp,IcKWOrYGdHfQvinTJAEbXqzMBkstLj):
  try:
   IcKWOrYGdHfQvinTJAEbXqzMBkstoy=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%IcKWOrYGdHfQvinTJAEbXqzMBkstxp))
   IcKWOrYGdHfQvinTJAEbXqzMBkstop=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.Load_List_File(IcKWOrYGdHfQvinTJAEbXqzMBkstxp) 
   fp=IcKWOrYGdHfQvinTJAEbXqzMBkstFP(IcKWOrYGdHfQvinTJAEbXqzMBkstoy,'w',-1,'utf-8')
   IcKWOrYGdHfQvinTJAEbXqzMBkstow=urllib.parse.urlencode(IcKWOrYGdHfQvinTJAEbXqzMBkstLj)
   IcKWOrYGdHfQvinTJAEbXqzMBkstow=IcKWOrYGdHfQvinTJAEbXqzMBkstow+'\n'
   fp.write(IcKWOrYGdHfQvinTJAEbXqzMBkstow)
   IcKWOrYGdHfQvinTJAEbXqzMBkstoa=0
   for IcKWOrYGdHfQvinTJAEbXqzMBkstoj in IcKWOrYGdHfQvinTJAEbXqzMBkstop:
    IcKWOrYGdHfQvinTJAEbXqzMBkstoe=IcKWOrYGdHfQvinTJAEbXqzMBkstFD(urllib.parse.parse_qsl(IcKWOrYGdHfQvinTJAEbXqzMBkstoj))
    IcKWOrYGdHfQvinTJAEbXqzMBkstog=IcKWOrYGdHfQvinTJAEbXqzMBkstLj.get('code').strip()
    IcKWOrYGdHfQvinTJAEbXqzMBkstNL=IcKWOrYGdHfQvinTJAEbXqzMBkstoe.get('code').strip()
    if IcKWOrYGdHfQvinTJAEbXqzMBkstxp=='vod' and IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_direct_replay()==IcKWOrYGdHfQvinTJAEbXqzMBkstFL:
     IcKWOrYGdHfQvinTJAEbXqzMBkstog=IcKWOrYGdHfQvinTJAEbXqzMBkstLj.get('videoid').strip()
     IcKWOrYGdHfQvinTJAEbXqzMBkstNL=IcKWOrYGdHfQvinTJAEbXqzMBkstoe.get('videoid').strip()if IcKWOrYGdHfQvinTJAEbXqzMBkstNL!=IcKWOrYGdHfQvinTJAEbXqzMBkstua else '-'
    if IcKWOrYGdHfQvinTJAEbXqzMBkstog!=IcKWOrYGdHfQvinTJAEbXqzMBkstNL:
     fp.write(IcKWOrYGdHfQvinTJAEbXqzMBkstoj)
     IcKWOrYGdHfQvinTJAEbXqzMBkstoa+=1
     if IcKWOrYGdHfQvinTJAEbXqzMBkstoa>=50:break
   fp.close()
  except:
   IcKWOrYGdHfQvinTJAEbXqzMBkstua
 def dp_Watch_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstxp =IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('stype')
  IcKWOrYGdHfQvinTJAEbXqzMBkstCm=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_direct_replay()
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxp=='-':
   for IcKWOrYGdHfQvinTJAEbXqzMBkstxe in IcKWOrYGdHfQvinTJAEbXqzMBkstLV:
    IcKWOrYGdHfQvinTJAEbXqzMBkstCj=IcKWOrYGdHfQvinTJAEbXqzMBkstxe.get('title')
    IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':IcKWOrYGdHfQvinTJAEbXqzMBkstxe.get('mode'),'stype':IcKWOrYGdHfQvinTJAEbXqzMBkstxe.get('stype')}
    IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel='',img='',infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstua,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFL,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
   if IcKWOrYGdHfQvinTJAEbXqzMBkstFN(IcKWOrYGdHfQvinTJAEbXqzMBkstLV)>0:xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle)
  else:
   IcKWOrYGdHfQvinTJAEbXqzMBkstNC=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.Load_List_File(IcKWOrYGdHfQvinTJAEbXqzMBkstxp)
   for IcKWOrYGdHfQvinTJAEbXqzMBkstNx in IcKWOrYGdHfQvinTJAEbXqzMBkstNC:
    IcKWOrYGdHfQvinTJAEbXqzMBkstoD=IcKWOrYGdHfQvinTJAEbXqzMBkstFD(urllib.parse.parse_qsl(IcKWOrYGdHfQvinTJAEbXqzMBkstNx))
    IcKWOrYGdHfQvinTJAEbXqzMBkstND =IcKWOrYGdHfQvinTJAEbXqzMBkstoD.get('code').strip()
    IcKWOrYGdHfQvinTJAEbXqzMBkstCj =IcKWOrYGdHfQvinTJAEbXqzMBkstoD.get('title').strip()
    IcKWOrYGdHfQvinTJAEbXqzMBkstxg=IcKWOrYGdHfQvinTJAEbXqzMBkstoD.get('img').strip()
    IcKWOrYGdHfQvinTJAEbXqzMBkstVU =IcKWOrYGdHfQvinTJAEbXqzMBkstoD.get('videoid').strip()
    try:
     IcKWOrYGdHfQvinTJAEbXqzMBkstxg=IcKWOrYGdHfQvinTJAEbXqzMBkstxg.replace('\'','\"')
     IcKWOrYGdHfQvinTJAEbXqzMBkstxg=json.loads(IcKWOrYGdHfQvinTJAEbXqzMBkstxg)
    except:
     IcKWOrYGdHfQvinTJAEbXqzMBkstua
    IcKWOrYGdHfQvinTJAEbXqzMBkstDS={}
    IcKWOrYGdHfQvinTJAEbXqzMBkstDS['plot']=IcKWOrYGdHfQvinTJAEbXqzMBkstCj
    if IcKWOrYGdHfQvinTJAEbXqzMBkstxp=='vod':
     if IcKWOrYGdHfQvinTJAEbXqzMBkstCm==IcKWOrYGdHfQvinTJAEbXqzMBkstFC or IcKWOrYGdHfQvinTJAEbXqzMBkstVU==IcKWOrYGdHfQvinTJAEbXqzMBkstua:
      IcKWOrYGdHfQvinTJAEbXqzMBkstDS['mediatype']='tvshow'
      IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'EPISODE','programcode':IcKWOrYGdHfQvinTJAEbXqzMBkstND,'page':'1'}
      IcKWOrYGdHfQvinTJAEbXqzMBkstxD=IcKWOrYGdHfQvinTJAEbXqzMBkstFL
     else:
      IcKWOrYGdHfQvinTJAEbXqzMBkstDS['mediatype']='episode'
      IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'VOD','mediacode':IcKWOrYGdHfQvinTJAEbXqzMBkstVU,'stype':'vod','programcode':IcKWOrYGdHfQvinTJAEbXqzMBkstND,'title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'thumbnail':IcKWOrYGdHfQvinTJAEbXqzMBkstxg}
      IcKWOrYGdHfQvinTJAEbXqzMBkstxD=IcKWOrYGdHfQvinTJAEbXqzMBkstFC
    else:
     IcKWOrYGdHfQvinTJAEbXqzMBkstDS['mediatype']='movie'
     IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'MOVIE','mediacode':IcKWOrYGdHfQvinTJAEbXqzMBkstND,'stype':'movie','title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'thumbnail':IcKWOrYGdHfQvinTJAEbXqzMBkstxg}
     IcKWOrYGdHfQvinTJAEbXqzMBkstxD=IcKWOrYGdHfQvinTJAEbXqzMBkstFC
    IcKWOrYGdHfQvinTJAEbXqzMBkstoN={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':IcKWOrYGdHfQvinTJAEbXqzMBkstND,'vType':IcKWOrYGdHfQvinTJAEbXqzMBkstxp,}
    IcKWOrYGdHfQvinTJAEbXqzMBkstou=urllib.parse.urlencode(IcKWOrYGdHfQvinTJAEbXqzMBkstoN)
    IcKWOrYGdHfQvinTJAEbXqzMBkstDy=[('선택된 시청이력 ( %s ) 삭제'%(IcKWOrYGdHfQvinTJAEbXqzMBkstCj),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(IcKWOrYGdHfQvinTJAEbXqzMBkstou))]
    IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel='',img=IcKWOrYGdHfQvinTJAEbXqzMBkstxg,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstDS,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstxD,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC,ContextMenu=IcKWOrYGdHfQvinTJAEbXqzMBkstDy)
   IcKWOrYGdHfQvinTJAEbXqzMBkstDS={'plot':'시청목록을 삭제합니다.'}
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':IcKWOrYGdHfQvinTJAEbXqzMBkstxp,}
   IcKWOrYGdHfQvinTJAEbXqzMBkstxL=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel='',img=IcKWOrYGdHfQvinTJAEbXqzMBkstxL,infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstDS,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFC,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC,isLink=IcKWOrYGdHfQvinTJAEbXqzMBkstFL)
   if IcKWOrYGdHfQvinTJAEbXqzMBkstxp=='movie':xbmcplugin.setContent(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,'movies')
   else:xbmcplugin.setContent(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,cacheToDisc=IcKWOrYGdHfQvinTJAEbXqzMBkstFC)
 def Save_Searched_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstVy):
  try:
   IcKWOrYGdHfQvinTJAEbXqzMBkstNV=IcKWOrYGdHfQvinTJAEbXqzMBkstLm
   IcKWOrYGdHfQvinTJAEbXqzMBkstop=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.Load_List_File('search') 
   IcKWOrYGdHfQvinTJAEbXqzMBkstNo={'skey':IcKWOrYGdHfQvinTJAEbXqzMBkstVy.strip()}
   fp=IcKWOrYGdHfQvinTJAEbXqzMBkstFP(IcKWOrYGdHfQvinTJAEbXqzMBkstNV,'w',-1,'utf-8')
   IcKWOrYGdHfQvinTJAEbXqzMBkstow=urllib.parse.urlencode(IcKWOrYGdHfQvinTJAEbXqzMBkstNo)
   IcKWOrYGdHfQvinTJAEbXqzMBkstow=IcKWOrYGdHfQvinTJAEbXqzMBkstow+'\n'
   fp.write(IcKWOrYGdHfQvinTJAEbXqzMBkstow)
   IcKWOrYGdHfQvinTJAEbXqzMBkstoa=0
   for IcKWOrYGdHfQvinTJAEbXqzMBkstoj in IcKWOrYGdHfQvinTJAEbXqzMBkstop:
    IcKWOrYGdHfQvinTJAEbXqzMBkstoe=IcKWOrYGdHfQvinTJAEbXqzMBkstFD(urllib.parse.parse_qsl(IcKWOrYGdHfQvinTJAEbXqzMBkstoj))
    IcKWOrYGdHfQvinTJAEbXqzMBkstog=IcKWOrYGdHfQvinTJAEbXqzMBkstNo.get('skey').strip()
    IcKWOrYGdHfQvinTJAEbXqzMBkstNL=IcKWOrYGdHfQvinTJAEbXqzMBkstoe.get('skey').strip()
    if IcKWOrYGdHfQvinTJAEbXqzMBkstog!=IcKWOrYGdHfQvinTJAEbXqzMBkstNL:
     fp.write(IcKWOrYGdHfQvinTJAEbXqzMBkstoj)
     IcKWOrYGdHfQvinTJAEbXqzMBkstoa+=1
     if IcKWOrYGdHfQvinTJAEbXqzMBkstoa>=50:break
   fp.close()
  except:
   IcKWOrYGdHfQvinTJAEbXqzMBkstua
 def play_VIDEO(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstNu =IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('mediacode')
  IcKWOrYGdHfQvinTJAEbXqzMBkstxp =IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('stype')
  IcKWOrYGdHfQvinTJAEbXqzMBkstNF =IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('pvrmode')
  IcKWOrYGdHfQvinTJAEbXqzMBkstNS=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_selQuality(IcKWOrYGdHfQvinTJAEbXqzMBkstxp)
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(IcKWOrYGdHfQvinTJAEbXqzMBkstNu,IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstNS),IcKWOrYGdHfQvinTJAEbXqzMBkstxp,IcKWOrYGdHfQvinTJAEbXqzMBkstNF))
  IcKWOrYGdHfQvinTJAEbXqzMBkstNP=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.GetBroadURL(IcKWOrYGdHfQvinTJAEbXqzMBkstNu,IcKWOrYGdHfQvinTJAEbXqzMBkstNS,IcKWOrYGdHfQvinTJAEbXqzMBkstxp,IcKWOrYGdHfQvinTJAEbXqzMBkstNF,optUHD=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_uhd())
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_log('qt, stype, url : %s - %s - %s'%(IcKWOrYGdHfQvinTJAEbXqzMBkstFu(IcKWOrYGdHfQvinTJAEbXqzMBkstNS),IcKWOrYGdHfQvinTJAEbXqzMBkstxp,IcKWOrYGdHfQvinTJAEbXqzMBkstNP['streaming_url']))
  if IcKWOrYGdHfQvinTJAEbXqzMBkstNP['streaming_url']=='':
   if IcKWOrYGdHfQvinTJAEbXqzMBkstNP['error_msg']=='':
    IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_noti(__language__(30908).encode('utf8'))
   else:
    IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_noti(IcKWOrYGdHfQvinTJAEbXqzMBkstNP['error_msg'].encode('utf8'))
   return
  IcKWOrYGdHfQvinTJAEbXqzMBkstNm={'user-agent':IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.USER_AGENT}
  IcKWOrYGdHfQvinTJAEbXqzMBkstNl=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.makeDefaultCookies() 
  if IcKWOrYGdHfQvinTJAEbXqzMBkstNP['watermark'] !='':
   IcKWOrYGdHfQvinTJAEbXqzMBkstNm['x-tving-param1']=IcKWOrYGdHfQvinTJAEbXqzMBkstNP['watermarkKey']
   IcKWOrYGdHfQvinTJAEbXqzMBkstNm['x-tving-param2']=IcKWOrYGdHfQvinTJAEbXqzMBkstNP['watermark'] 
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_log('streaming_url = {}'.format(IcKWOrYGdHfQvinTJAEbXqzMBkstNP['streaming_url']))
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_log('drm_license   = {}'.format(IcKWOrYGdHfQvinTJAEbXqzMBkstNP['drm_license']))
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_log('watermark     = {}'.format(IcKWOrYGdHfQvinTJAEbXqzMBkstNP['watermark']))
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_log('watermarkKey  = {}'.format(IcKWOrYGdHfQvinTJAEbXqzMBkstNP['watermarkKey']))
  IcKWOrYGdHfQvinTJAEbXqzMBkstNU =IcKWOrYGdHfQvinTJAEbXqzMBkstFC
  IcKWOrYGdHfQvinTJAEbXqzMBkstNp =IcKWOrYGdHfQvinTJAEbXqzMBkstNP['streaming_url'].find('Policy=')
  if IcKWOrYGdHfQvinTJAEbXqzMBkstNp!=-1:
   IcKWOrYGdHfQvinTJAEbXqzMBkstNj =IcKWOrYGdHfQvinTJAEbXqzMBkstNP['streaming_url'].split('?')[0]
   IcKWOrYGdHfQvinTJAEbXqzMBkstNe=IcKWOrYGdHfQvinTJAEbXqzMBkstFD(urllib.parse.parse_qsl(urllib.parse.urlsplit(IcKWOrYGdHfQvinTJAEbXqzMBkstNP['streaming_url']).query))
   IcKWOrYGdHfQvinTJAEbXqzMBkstNl['CloudFront-Policy'] =IcKWOrYGdHfQvinTJAEbXqzMBkstNe['Policy'] 
   IcKWOrYGdHfQvinTJAEbXqzMBkstNl['CloudFront-Signature'] =IcKWOrYGdHfQvinTJAEbXqzMBkstNe['Signature'] 
   IcKWOrYGdHfQvinTJAEbXqzMBkstNl['CloudFront-Key-Pair-Id']=IcKWOrYGdHfQvinTJAEbXqzMBkstNe['Key-Pair-Id'] 
   if 'quickvod-mcdn.tving.com' in IcKWOrYGdHfQvinTJAEbXqzMBkstNj and 1==2:
    IcKWOrYGdHfQvinTJAEbXqzMBkstNU=IcKWOrYGdHfQvinTJAEbXqzMBkstFL
    IcKWOrYGdHfQvinTJAEbXqzMBkstNR =IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    IcKWOrYGdHfQvinTJAEbXqzMBkstNh=IcKWOrYGdHfQvinTJAEbXqzMBkstNR.strftime('%Y-%m-%d-%H:%M:%S')
    if IcKWOrYGdHfQvinTJAEbXqzMBkstug(IcKWOrYGdHfQvinTJAEbXqzMBkstNh.replace('-','').replace(':',''))<IcKWOrYGdHfQvinTJAEbXqzMBkstug(IcKWOrYGdHfQvinTJAEbXqzMBkstNe['end'].replace('-','').replace(':','')):
     IcKWOrYGdHfQvinTJAEbXqzMBkstNe['end']=IcKWOrYGdHfQvinTJAEbXqzMBkstNh
     IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_noti(__language__(30915).encode('utf8'))
    IcKWOrYGdHfQvinTJAEbXqzMBkstNj ='%s?%s'%(IcKWOrYGdHfQvinTJAEbXqzMBkstNj,urllib.parse.urlencode(IcKWOrYGdHfQvinTJAEbXqzMBkstNe,doseq=IcKWOrYGdHfQvinTJAEbXqzMBkstFL))
    IcKWOrYGdHfQvinTJAEbXqzMBkstNy='{}|{}'.format(IcKWOrYGdHfQvinTJAEbXqzMBkstNj,IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.make_stream_header(IcKWOrYGdHfQvinTJAEbXqzMBkstNm,IcKWOrYGdHfQvinTJAEbXqzMBkstNl))
   else:
    IcKWOrYGdHfQvinTJAEbXqzMBkstNy='{}|{}'.format(IcKWOrYGdHfQvinTJAEbXqzMBkstNP['streaming_url'],IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.make_stream_header(IcKWOrYGdHfQvinTJAEbXqzMBkstNm,IcKWOrYGdHfQvinTJAEbXqzMBkstNl))
  else:
   IcKWOrYGdHfQvinTJAEbXqzMBkstNy='{}|{}'.format(IcKWOrYGdHfQvinTJAEbXqzMBkstNP['streaming_url'],IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.make_stream_header(IcKWOrYGdHfQvinTJAEbXqzMBkstNm,IcKWOrYGdHfQvinTJAEbXqzMBkstNl))
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_log('if tmp_pos == -1')
  IcKWOrYGdHfQvinTJAEbXqzMBkstCV,IcKWOrYGdHfQvinTJAEbXqzMBkstCo=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_proxyport()
  IcKWOrYGdHfQvinTJAEbXqzMBkstCD=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_playback()
  IcKWOrYGdHfQvinTJAEbXqzMBkstNw=urllib.parse.urlparse(IcKWOrYGdHfQvinTJAEbXqzMBkstNP['streaming_url'])
  IcKWOrYGdHfQvinTJAEbXqzMBkstNw=IcKWOrYGdHfQvinTJAEbXqzMBkstNw.path.strip('/').split('/')
  IcKWOrYGdHfQvinTJAEbXqzMBkstNw=IcKWOrYGdHfQvinTJAEbXqzMBkstNw[IcKWOrYGdHfQvinTJAEbXqzMBkstFN(IcKWOrYGdHfQvinTJAEbXqzMBkstNw)-1] 
  if(IcKWOrYGdHfQvinTJAEbXqzMBkstCV and IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('mode')in['VOD','MOVIE']and IcKWOrYGdHfQvinTJAEbXqzMBkstNU==IcKWOrYGdHfQvinTJAEbXqzMBkstFC and IcKWOrYGdHfQvinTJAEbXqzMBkstNP['drm_license']!=''):
   if IcKWOrYGdHfQvinTJAEbXqzMBkstNw.split('.')[1]=='mpd':
    IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Tving_Parse_mpd(IcKWOrYGdHfQvinTJAEbXqzMBkstNP['streaming_url'],IcKWOrYGdHfQvinTJAEbXqzMBkstNP['watermarkKey'],IcKWOrYGdHfQvinTJAEbXqzMBkstNP['watermark'])
   else:
    IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Tving_Parse_m3u8(IcKWOrYGdHfQvinTJAEbXqzMBkstNP['streaming_url'])
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_log('xxx '+IcKWOrYGdHfQvinTJAEbXqzMBkstNP['streaming_url'])
   IcKWOrYGdHfQvinTJAEbXqzMBkstNa={'addon':'tvingm','playOption':IcKWOrYGdHfQvinTJAEbXqzMBkstCD,}
   IcKWOrYGdHfQvinTJAEbXqzMBkstNa=json.dumps(IcKWOrYGdHfQvinTJAEbXqzMBkstNa,separators=(',',':'))
   IcKWOrYGdHfQvinTJAEbXqzMBkstNa=base64.standard_b64encode(IcKWOrYGdHfQvinTJAEbXqzMBkstNa.encode()).decode('utf-8')
   IcKWOrYGdHfQvinTJAEbXqzMBkstNy ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(IcKWOrYGdHfQvinTJAEbXqzMBkstCo,IcKWOrYGdHfQvinTJAEbXqzMBkstNy,IcKWOrYGdHfQvinTJAEbXqzMBkstNa)
   IcKWOrYGdHfQvinTJAEbXqzMBkstNm['proxy-mini']=IcKWOrYGdHfQvinTJAEbXqzMBkstNa 
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_log('surl(2) : {}'.format(IcKWOrYGdHfQvinTJAEbXqzMBkstNy))
  IcKWOrYGdHfQvinTJAEbXqzMBkstNg=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.make_stream_header(IcKWOrYGdHfQvinTJAEbXqzMBkstNm,IcKWOrYGdHfQvinTJAEbXqzMBkstNl)
  IcKWOrYGdHfQvinTJAEbXqzMBkstuL=xbmcgui.ListItem(path=IcKWOrYGdHfQvinTJAEbXqzMBkstNy)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstNP['drm_license']!='':
   IcKWOrYGdHfQvinTJAEbXqzMBkstuC=IcKWOrYGdHfQvinTJAEbXqzMBkstNP['drm_license']
   IcKWOrYGdHfQvinTJAEbXqzMBkstux ='https://cj.drmkeyserver.com/widevine_license'
   IcKWOrYGdHfQvinTJAEbXqzMBkstuD ='mpd'
   IcKWOrYGdHfQvinTJAEbXqzMBkstuV ='com.widevine.alpha'
   IcKWOrYGdHfQvinTJAEbXqzMBkstuo =inputstreamhelper.Helper(IcKWOrYGdHfQvinTJAEbXqzMBkstuD,drm='widevine')
   if IcKWOrYGdHfQvinTJAEbXqzMBkstuo.check_inputstream():
    IcKWOrYGdHfQvinTJAEbXqzMBkstuN={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.USER_AGENT,'AcquireLicenseAssertion':IcKWOrYGdHfQvinTJAEbXqzMBkstuC,'Host':'cj.drmkeyserver.com',}
    IcKWOrYGdHfQvinTJAEbXqzMBkstuF=IcKWOrYGdHfQvinTJAEbXqzMBkstux+'|'+urllib.parse.urlencode(IcKWOrYGdHfQvinTJAEbXqzMBkstuN)+'|R{SSM}|'
    IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('inputstream',IcKWOrYGdHfQvinTJAEbXqzMBkstuo.inputstream_addon)
    IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('inputstream.adaptive.manifest_type',IcKWOrYGdHfQvinTJAEbXqzMBkstuD)
    IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('inputstream.adaptive.license_type',IcKWOrYGdHfQvinTJAEbXqzMBkstuV)
    IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('inputstream.adaptive.license_key',IcKWOrYGdHfQvinTJAEbXqzMBkstuF)
    IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('inputstream.adaptive.stream_headers',IcKWOrYGdHfQvinTJAEbXqzMBkstNg)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('mode')in['VOD','MOVIE']:
   IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setContentLookup(IcKWOrYGdHfQvinTJAEbXqzMBkstFC)
   IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setMimeType('application/x-mpegURL')
   IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('inputstream','inputstream.adaptive')
   IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('inputstream.adaptive.manifest_type','hls')
   IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('inputstream.adaptive.stream_headers',IcKWOrYGdHfQvinTJAEbXqzMBkstNg)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstNU==IcKWOrYGdHfQvinTJAEbXqzMBkstFL:
   IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setContentLookup(IcKWOrYGdHfQvinTJAEbXqzMBkstFC)
   IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setMimeType('application/x-mpegURL')
   IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('inputstream','inputstream.ffmpegdirect')
   IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('ResumeTime','0')
   IcKWOrYGdHfQvinTJAEbXqzMBkstuL.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,IcKWOrYGdHfQvinTJAEbXqzMBkstFL,IcKWOrYGdHfQvinTJAEbXqzMBkstuL)
  try:
   if IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('mode')in['VOD','MOVIE']and IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('title'):
    IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'code':IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('programcode')if IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('mode')=='VOD' else IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('mediacode'),'img':IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('thumbnail'),'title':IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('title'),'videoid':IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('mediacode')}
    IcKWOrYGdHfQvinTJAEbXqzMBkstLl.Save_Watched_List(IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('stype'),IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  except:
   IcKWOrYGdHfQvinTJAEbXqzMBkstua
 def logout(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  IcKWOrYGdHfQvinTJAEbXqzMBkstLR=xbmcgui.Dialog()
  IcKWOrYGdHfQvinTJAEbXqzMBkstxm=IcKWOrYGdHfQvinTJAEbXqzMBkstLR.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if IcKWOrYGdHfQvinTJAEbXqzMBkstxm==IcKWOrYGdHfQvinTJAEbXqzMBkstFC:sys.exit()
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Init_TV_Total()
  if os.path.isfile(IcKWOrYGdHfQvinTJAEbXqzMBkstLP):os.remove(IcKWOrYGdHfQvinTJAEbXqzMBkstLP)
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  IcKWOrYGdHfQvinTJAEbXqzMBkstuS =IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Get_Now_Datetime()
  IcKWOrYGdHfQvinTJAEbXqzMBkstuP=IcKWOrYGdHfQvinTJAEbXqzMBkstuS+datetime.timedelta(days=IcKWOrYGdHfQvinTJAEbXqzMBkstug(__addon__.getSetting('cache_ttl')))
  (IcKWOrYGdHfQvinTJAEbXqzMBkstxu,IcKWOrYGdHfQvinTJAEbXqzMBkstxF,IcKWOrYGdHfQvinTJAEbXqzMBkstxS,IcKWOrYGdHfQvinTJAEbXqzMBkstxP)=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_account()
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Save_session_acount(IcKWOrYGdHfQvinTJAEbXqzMBkstxu,IcKWOrYGdHfQvinTJAEbXqzMBkstxF,IcKWOrYGdHfQvinTJAEbXqzMBkstxS,IcKWOrYGdHfQvinTJAEbXqzMBkstxP)
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.TV['account']['token_limit']=IcKWOrYGdHfQvinTJAEbXqzMBkstuP.strftime('%Y%m%d')
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.JsonFile_Save(IcKWOrYGdHfQvinTJAEbXqzMBkstLP,IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.TV)
 def cookiefile_check(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.TV=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.JsonFile_Load(IcKWOrYGdHfQvinTJAEbXqzMBkstLP)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.TV=={}:
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Init_TV_Total()
   return IcKWOrYGdHfQvinTJAEbXqzMBkstFC
  if '_tving_token' not in IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.TV.get('cookies'):
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Init_TV_Total()
   return IcKWOrYGdHfQvinTJAEbXqzMBkstFC
  (IcKWOrYGdHfQvinTJAEbXqzMBkstum,IcKWOrYGdHfQvinTJAEbXqzMBkstul,IcKWOrYGdHfQvinTJAEbXqzMBkstuU,IcKWOrYGdHfQvinTJAEbXqzMBkstup)=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.get_settings_account()
  (IcKWOrYGdHfQvinTJAEbXqzMBkstuj,IcKWOrYGdHfQvinTJAEbXqzMBkstue,IcKWOrYGdHfQvinTJAEbXqzMBkstuR,IcKWOrYGdHfQvinTJAEbXqzMBkstuh)=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Load_session_acount()
  if IcKWOrYGdHfQvinTJAEbXqzMBkstum!=IcKWOrYGdHfQvinTJAEbXqzMBkstuj or IcKWOrYGdHfQvinTJAEbXqzMBkstul!=IcKWOrYGdHfQvinTJAEbXqzMBkstue or IcKWOrYGdHfQvinTJAEbXqzMBkstuU!=IcKWOrYGdHfQvinTJAEbXqzMBkstuR or IcKWOrYGdHfQvinTJAEbXqzMBkstup!=IcKWOrYGdHfQvinTJAEbXqzMBkstuh:
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Init_TV_Total()
   return IcKWOrYGdHfQvinTJAEbXqzMBkstFC
  if IcKWOrYGdHfQvinTJAEbXqzMBkstug(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>IcKWOrYGdHfQvinTJAEbXqzMBkstug(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.TV['account']['token_limit']):
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.Init_TV_Total()
   return IcKWOrYGdHfQvinTJAEbXqzMBkstFC
  return IcKWOrYGdHfQvinTJAEbXqzMBkstFL
 def dp_Global_Search(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstVw=IcKWOrYGdHfQvinTJAEbXqzMBkstxR.get('mode')
  if IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='TOTAL_SEARCH':
   IcKWOrYGdHfQvinTJAEbXqzMBkstuy='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   IcKWOrYGdHfQvinTJAEbXqzMBkstuy='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(IcKWOrYGdHfQvinTJAEbXqzMBkstuy)
 def dp_Bookmark_Menu(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstuy='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(IcKWOrYGdHfQvinTJAEbXqzMBkstuy)
 def dp_EuroLive_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl,IcKWOrYGdHfQvinTJAEbXqzMBkstxR):
  IcKWOrYGdHfQvinTJAEbXqzMBkstxy=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.GetEuroChannelList()
  for IcKWOrYGdHfQvinTJAEbXqzMBkstxa in IcKWOrYGdHfQvinTJAEbXqzMBkstxy:
   IcKWOrYGdHfQvinTJAEbXqzMBkstDj =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('channel')
   IcKWOrYGdHfQvinTJAEbXqzMBkstCj =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('title')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDP =IcKWOrYGdHfQvinTJAEbXqzMBkstxa.get('subtitle')
   IcKWOrYGdHfQvinTJAEbXqzMBkstDS={'mediatype':'episode','title':IcKWOrYGdHfQvinTJAEbXqzMBkstCj,'plot':'%s\n%s'%(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,IcKWOrYGdHfQvinTJAEbXqzMBkstDP)}
   IcKWOrYGdHfQvinTJAEbXqzMBkstxC={'mode':'LIVE','mediacode':IcKWOrYGdHfQvinTJAEbXqzMBkstDj,'stype':'onair',}
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.add_dir(IcKWOrYGdHfQvinTJAEbXqzMBkstCj,sublabel=IcKWOrYGdHfQvinTJAEbXqzMBkstDP,img='',infoLabels=IcKWOrYGdHfQvinTJAEbXqzMBkstDS,isFolder=IcKWOrYGdHfQvinTJAEbXqzMBkstFC,params=IcKWOrYGdHfQvinTJAEbXqzMBkstxC)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstFN(IcKWOrYGdHfQvinTJAEbXqzMBkstxy)>0:xbmcplugin.endOfDirectory(IcKWOrYGdHfQvinTJAEbXqzMBkstLl._addon_handle,cacheToDisc=IcKWOrYGdHfQvinTJAEbXqzMBkstFC)
 def tving_main(IcKWOrYGdHfQvinTJAEbXqzMBkstLl):
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.TvingObj.KodiVersion=IcKWOrYGdHfQvinTJAEbXqzMBkstug(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  IcKWOrYGdHfQvinTJAEbXqzMBkstVw=IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params.get('mode',IcKWOrYGdHfQvinTJAEbXqzMBkstua)
  if IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='LOGOUT':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.logout()
   return
  IcKWOrYGdHfQvinTJAEbXqzMBkstLl.login_main()
  if IcKWOrYGdHfQvinTJAEbXqzMBkstVw is IcKWOrYGdHfQvinTJAEbXqzMBkstua:
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_Main_List()
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_Title_Group(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw in['GLOBAL_GROUP']:
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_SubTitle_Group(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='CHANNEL':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_LiveChannel_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw in['LIVE','VOD','MOVIE']:
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.play_VIDEO(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='PROGRAM':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_Program_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='4K_PROGRAM':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_4K_Program_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='ORI_PROGRAM':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_Ori_Program_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='EPISODE':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_Episode_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='MOVIE_SUB':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_Movie_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='4K_MOVIE':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_4K_Movie_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='SEARCH_GROUP':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_Search_Group(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw in['SEARCH','LOCAL_SEARCH']:
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_Search_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='WATCH':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_Watch_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_History_Remove(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='ORDER_BY':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_setEpOrderby(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='SET_BOOKMARK':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_Set_Bookmark(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw in['TOTAL_SEARCH','TOTAL_HISTORY']:
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_Global_Search(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='SEARCH_HISTORY':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_Search_History(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='MENU_BOOKMARK':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_Bookmark_Menu(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  elif IcKWOrYGdHfQvinTJAEbXqzMBkstVw=='EURO_GROUP':
   IcKWOrYGdHfQvinTJAEbXqzMBkstLl.dp_EuroLive_List(IcKWOrYGdHfQvinTJAEbXqzMBkstLl.main_params)
  else:
   IcKWOrYGdHfQvinTJAEbXqzMBkstua
# Created by pyminifier (https://github.com/liftoff/pyminifier)
