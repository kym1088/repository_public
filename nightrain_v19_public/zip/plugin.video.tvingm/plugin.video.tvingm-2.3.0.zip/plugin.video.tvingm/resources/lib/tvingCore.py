__author__="NightRain"
vVDzaejqgTlnESXfsLAUHFIPGoxWBu=object
vVDzaejqgTlnESXfsLAUHFIPGoxWBr=None
vVDzaejqgTlnESXfsLAUHFIPGoxWBi=False
vVDzaejqgTlnESXfsLAUHFIPGoxWBk=int
vVDzaejqgTlnESXfsLAUHFIPGoxWBw=range
vVDzaejqgTlnESXfsLAUHFIPGoxWBy=True
vVDzaejqgTlnESXfsLAUHFIPGoxWBC=Exception
vVDzaejqgTlnESXfsLAUHFIPGoxWBJ=print
vVDzaejqgTlnESXfsLAUHFIPGoxWBN=str
vVDzaejqgTlnESXfsLAUHFIPGoxWBR=list
vVDzaejqgTlnESXfsLAUHFIPGoxWBb=len
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
vVDzaejqgTlnESXfsLAUHFIPGoxWOr={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
vVDzaejqgTlnESXfsLAUHFIPGoxWOi ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class vVDzaejqgTlnESXfsLAUHFIPGoxWOu(vVDzaejqgTlnESXfsLAUHFIPGoxWBu):
 def __init__(vVDzaejqgTlnESXfsLAUHFIPGoxWOk):
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_TOKEN =''
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.POC_USERINFO =''
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_UUID ='-'
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_MAINTOKEN=''
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVIGN_COOKIEKEY=''
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_LOCKKEY =''
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.NETWORKCODE ='CSND0900'
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.OSCODE ='CSOD0900' 
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TELECODE ='CSCD0900'
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.SCREENCODE ='CSSD0100'
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.LIVE_LIMIT =23
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.VOD_LIMIT =20
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.EPISODE_LIMIT =30 
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.SEARCH_LIMIT =30 
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.MOVIE_LIMIT =18
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.API_DOMAIN ='https://api.tving.com'
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN ='https://image.tving.com'
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.SEARCH_DOMAIN ='https://search.tving.com'
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.LOGIN_DOMAIN ='https://user.tving.com'
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.URL_DOMAIN ='https://www.tving.com'
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.MOVIE_LITE =['2610061','2610161','261062']
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.DEFAULT_HEADER ={'user-agent':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.USER_AGENT}
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,jobtype,vVDzaejqgTlnESXfsLAUHFIPGoxWut,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,params=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,redirects=vVDzaejqgTlnESXfsLAUHFIPGoxWBi):
  vVDzaejqgTlnESXfsLAUHFIPGoxWOB=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.DEFAULT_HEADER
  if headers:vVDzaejqgTlnESXfsLAUHFIPGoxWOB.update(headers)
  if jobtype=='Get':
   vVDzaejqgTlnESXfsLAUHFIPGoxWOw=requests.get(vVDzaejqgTlnESXfsLAUHFIPGoxWut,params=params,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWOB,cookies=cookies,allow_redirects=redirects)
  else:
   vVDzaejqgTlnESXfsLAUHFIPGoxWOw=requests.post(vVDzaejqgTlnESXfsLAUHFIPGoxWut,data=payload,params=params,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWOB,cookies=cookies,allow_redirects=redirects)
  return vVDzaejqgTlnESXfsLAUHFIPGoxWOw
 def makeDefaultCookies(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,vToken=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,vUserinfo=vVDzaejqgTlnESXfsLAUHFIPGoxWBr):
  vVDzaejqgTlnESXfsLAUHFIPGoxWOy={}
  vVDzaejqgTlnESXfsLAUHFIPGoxWOy['_tving_token']=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_TOKEN if vToken==vVDzaejqgTlnESXfsLAUHFIPGoxWBr else vToken
  vVDzaejqgTlnESXfsLAUHFIPGoxWOy['POC_USERINFO']=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.POC_USERINFO if vToken==vVDzaejqgTlnESXfsLAUHFIPGoxWBr else vUserinfo
  if vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_MAINTOKEN!='':vVDzaejqgTlnESXfsLAUHFIPGoxWOy[vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GLOBAL_COOKIENM['tv_maintoken']]=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_MAINTOKEN
  if vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVIGN_COOKIEKEY!='':vVDzaejqgTlnESXfsLAUHFIPGoxWOy[vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GLOBAL_COOKIENM['tv_cookiekey']]=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVIGN_COOKIEKEY
  if vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_LOCKKEY !='':vVDzaejqgTlnESXfsLAUHFIPGoxWOy[vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GLOBAL_COOKIENM['tv_lockkey']] =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_LOCKKEY
  return vVDzaejqgTlnESXfsLAUHFIPGoxWOy
 def getDeviceStr(vVDzaejqgTlnESXfsLAUHFIPGoxWOk):
  vVDzaejqgTlnESXfsLAUHFIPGoxWOC=[]
  vVDzaejqgTlnESXfsLAUHFIPGoxWOC.append('Windows') 
  vVDzaejqgTlnESXfsLAUHFIPGoxWOC.append('Chrome') 
  vVDzaejqgTlnESXfsLAUHFIPGoxWOC.append('ko-KR') 
  vVDzaejqgTlnESXfsLAUHFIPGoxWOC.append('undefined') 
  vVDzaejqgTlnESXfsLAUHFIPGoxWOC.append('24') 
  vVDzaejqgTlnESXfsLAUHFIPGoxWOC.append(u'한국 표준시')
  vVDzaejqgTlnESXfsLAUHFIPGoxWOC.append('undefined') 
  vVDzaejqgTlnESXfsLAUHFIPGoxWOC.append('undefined') 
  vVDzaejqgTlnESXfsLAUHFIPGoxWOC.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  vVDzaejqgTlnESXfsLAUHFIPGoxWOJ=''
  for vVDzaejqgTlnESXfsLAUHFIPGoxWON in vVDzaejqgTlnESXfsLAUHFIPGoxWOC:
   vVDzaejqgTlnESXfsLAUHFIPGoxWOJ+=vVDzaejqgTlnESXfsLAUHFIPGoxWON+'|'
  return vVDzaejqgTlnESXfsLAUHFIPGoxWOJ
 def SaveCredential(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,vVDzaejqgTlnESXfsLAUHFIPGoxWOR):
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_TOKEN =vVDzaejqgTlnESXfsLAUHFIPGoxWOR.get('tving_token')
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.POC_USERINFO =vVDzaejqgTlnESXfsLAUHFIPGoxWOR.get('poc_userinfo')
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_UUID =vVDzaejqgTlnESXfsLAUHFIPGoxWOR.get('tving_uuid')
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_MAINTOKEN=vVDzaejqgTlnESXfsLAUHFIPGoxWOR.get('tving_maintoken')
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVIGN_COOKIEKEY=vVDzaejqgTlnESXfsLAUHFIPGoxWOR.get('tving_cookiekey')
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_LOCKKEY =vVDzaejqgTlnESXfsLAUHFIPGoxWOR.get('tving_lockkey')
 def LoadCredential(vVDzaejqgTlnESXfsLAUHFIPGoxWOk):
  vVDzaejqgTlnESXfsLAUHFIPGoxWOR={'tving_token':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_TOKEN,'poc_userinfo':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.POC_USERINFO,'tving_uuid':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_UUID,'tving_maintoken':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_MAINTOKEN,'tving_cookiekey':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVIGN_COOKIEKEY,'tving_lockkey':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_LOCKKEY}
  return vVDzaejqgTlnESXfsLAUHFIPGoxWOR
 def GetDefaultParams(vVDzaejqgTlnESXfsLAUHFIPGoxWOk):
  vVDzaejqgTlnESXfsLAUHFIPGoxWOb={'apiKey':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.APIKEY,'networkCode':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.NETWORKCODE,'osCode':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.OSCODE,'teleCode':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TELECODE,'screenCode':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.SCREENCODE}
  return vVDzaejqgTlnESXfsLAUHFIPGoxWOb
 def GetNoCache(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,timetype=1):
  if timetype==1:
   return vVDzaejqgTlnESXfsLAUHFIPGoxWBk(time.time())
  else:
   return vVDzaejqgTlnESXfsLAUHFIPGoxWBk(time.time()*1000)
 def GetUniqueid(vVDzaejqgTlnESXfsLAUHFIPGoxWOk):
  vVDzaejqgTlnESXfsLAUHFIPGoxWOt=[0 for i in vVDzaejqgTlnESXfsLAUHFIPGoxWBw(256)]
  for i in vVDzaejqgTlnESXfsLAUHFIPGoxWBw(256):
   vVDzaejqgTlnESXfsLAUHFIPGoxWOt[i]='%02x'%(i)
  vVDzaejqgTlnESXfsLAUHFIPGoxWOh=vVDzaejqgTlnESXfsLAUHFIPGoxWBk(4294967295*random.random())|0
  vVDzaejqgTlnESXfsLAUHFIPGoxWOQ=vVDzaejqgTlnESXfsLAUHFIPGoxWOt[255&vVDzaejqgTlnESXfsLAUHFIPGoxWOh]+vVDzaejqgTlnESXfsLAUHFIPGoxWOt[vVDzaejqgTlnESXfsLAUHFIPGoxWOh>>8&255]+vVDzaejqgTlnESXfsLAUHFIPGoxWOt[vVDzaejqgTlnESXfsLAUHFIPGoxWOh>>16&255]+vVDzaejqgTlnESXfsLAUHFIPGoxWOt[vVDzaejqgTlnESXfsLAUHFIPGoxWOh>>24&255]
  return vVDzaejqgTlnESXfsLAUHFIPGoxWOQ
 def GetCredential(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,user_id,user_pw,login_type,user_pf):
  vVDzaejqgTlnESXfsLAUHFIPGoxWOd=vVDzaejqgTlnESXfsLAUHFIPGoxWBi
  vVDzaejqgTlnESXfsLAUHFIPGoxWOM=vVDzaejqgTlnESXfsLAUHFIPGoxWuO=vVDzaejqgTlnESXfsLAUHFIPGoxWur=vVDzaejqgTlnESXfsLAUHFIPGoxWui=vVDzaejqgTlnESXfsLAUHFIPGoxWuk='' 
  vVDzaejqgTlnESXfsLAUHFIPGoxWOc ='-'
  try:
   vVDzaejqgTlnESXfsLAUHFIPGoxWOp=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   vVDzaejqgTlnESXfsLAUHFIPGoxWOm={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Post',vVDzaejqgTlnESXfsLAUHFIPGoxWOp,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWOm,params=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWBr)
   for vVDzaejqgTlnESXfsLAUHFIPGoxWOK in vVDzaejqgTlnESXfsLAUHFIPGoxWOY.cookies:
    if vVDzaejqgTlnESXfsLAUHFIPGoxWOK.name=='_tving_token':
     vVDzaejqgTlnESXfsLAUHFIPGoxWuO=vVDzaejqgTlnESXfsLAUHFIPGoxWOK.value
    elif vVDzaejqgTlnESXfsLAUHFIPGoxWOK.name=='POC_USERINFO':
     vVDzaejqgTlnESXfsLAUHFIPGoxWur=vVDzaejqgTlnESXfsLAUHFIPGoxWOK.value
   if vVDzaejqgTlnESXfsLAUHFIPGoxWuO=='':return vVDzaejqgTlnESXfsLAUHFIPGoxWOd
   vVDzaejqgTlnESXfsLAUHFIPGoxWOM=vVDzaejqgTlnESXfsLAUHFIPGoxWuO
   vVDzaejqgTlnESXfsLAUHFIPGoxWuO,vVDzaejqgTlnESXfsLAUHFIPGoxWui,vVDzaejqgTlnESXfsLAUHFIPGoxWuk=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetProfileToken(vVDzaejqgTlnESXfsLAUHFIPGoxWuO,vVDzaejqgTlnESXfsLAUHFIPGoxWur,user_pf)
   vVDzaejqgTlnESXfsLAUHFIPGoxWOd=vVDzaejqgTlnESXfsLAUHFIPGoxWBy
   vVDzaejqgTlnESXfsLAUHFIPGoxWOc =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetDeviceList(vVDzaejqgTlnESXfsLAUHFIPGoxWuO,vVDzaejqgTlnESXfsLAUHFIPGoxWur)
   vVDzaejqgTlnESXfsLAUHFIPGoxWOc =vVDzaejqgTlnESXfsLAUHFIPGoxWOc+'-'+vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetUniqueid()
  except vVDzaejqgTlnESXfsLAUHFIPGoxWBC as exception:
   vVDzaejqgTlnESXfsLAUHFIPGoxWOM=vVDzaejqgTlnESXfsLAUHFIPGoxWuO=vVDzaejqgTlnESXfsLAUHFIPGoxWur=vVDzaejqgTlnESXfsLAUHFIPGoxWui=vVDzaejqgTlnESXfsLAUHFIPGoxWuk=''
   vVDzaejqgTlnESXfsLAUHFIPGoxWOc='-'
   vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(exception)
  vVDzaejqgTlnESXfsLAUHFIPGoxWOR={'tving_token':vVDzaejqgTlnESXfsLAUHFIPGoxWuO,'poc_userinfo':vVDzaejqgTlnESXfsLAUHFIPGoxWur,'tving_uuid':vVDzaejqgTlnESXfsLAUHFIPGoxWOc,'tving_maintoken':vVDzaejqgTlnESXfsLAUHFIPGoxWOM,'tving_cookiekey':vVDzaejqgTlnESXfsLAUHFIPGoxWui,'tving_lockkey':vVDzaejqgTlnESXfsLAUHFIPGoxWuk}
  vVDzaejqgTlnESXfsLAUHFIPGoxWOk.SaveCredential(vVDzaejqgTlnESXfsLAUHFIPGoxWOR)
  return vVDzaejqgTlnESXfsLAUHFIPGoxWOd
 def Get_Now_Datetime(vVDzaejqgTlnESXfsLAUHFIPGoxWOk):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,mediacode,sel_quality,stype,pvrmode='-'):
  vVDzaejqgTlnESXfsLAUHFIPGoxWuw=''
  vVDzaejqgTlnESXfsLAUHFIPGoxWuy=''
  vVDzaejqgTlnESXfsLAUHFIPGoxWuC =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_UUID.split('-')[0] 
  vVDzaejqgTlnESXfsLAUHFIPGoxWuJ =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.TVING_UUID 
  if mediacode=='C01345':
   vVDzaejqgTlnESXfsLAUHFIPGoxWuw='http://ocn-mcdn.tving.com/ocn/live5000.smil/playlist.m3u8?Policy=eyJTdGF0ZW1lbnQiOiBbeyJSZXNvdXJjZSI6Imh0dHA6Ly8qIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNjEwODMwODAwfSwiSXBBZGRyZXNzIjp7IkFXUzpTb3VyY2VJcCI6IjAuMC4wLjAvMCJ9fX1dfQ__&Signature=eqJMOA5c~hIlgUVIDOtLCCfKXnNO0XHex3uQVQE87ZfuutuH2hqAgddlijKNWDz2Qrg5ScRkuXuU-7QQoj4QFSPPjyvwJSSrrZtNNVxU8xERXywdUKUwQGfDvl78F4rhS7WP-O1Q86KnLwif9QW0GPRK~n8ceOITlYq22rVLqp~EKwmoGQ3cvw01TMBFRInvobRtXR-zGyMZCx9MDgeHMRay0U9Ibp7nUPb3~T~set~W3so1ovUnF0iLuQpuarXQA3QIBy25O24NVbwalTtzjPoULkpEHeuVsMx-ACom3MTM65kB5TKJNIx19sdlAFQIII7n39FpWgSOO6A8jvu~rA__&Key-Pair-Id=APKAIXCIJCFRGOUEZDWA'
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    vVDzaejqgTlnESXfsLAUHFIPGoxWuN ='/v2a/media/stream/info' 
    vVDzaejqgTlnESXfsLAUHFIPGoxWuR=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetDefaultParams()
    vVDzaejqgTlnESXfsLAUHFIPGoxWub={'info':'N','mediaCode':mediacode,'noCache':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':vVDzaejqgTlnESXfsLAUHFIPGoxWuC,'uuid':vVDzaejqgTlnESXfsLAUHFIPGoxWuJ,'deviceInfo':'PC','wm':'Y'}
    vVDzaejqgTlnESXfsLAUHFIPGoxWuR.update(vVDzaejqgTlnESXfsLAUHFIPGoxWub)
    vVDzaejqgTlnESXfsLAUHFIPGoxWut=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.API_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuN
    vVDzaejqgTlnESXfsLAUHFIPGoxWOy=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.makeDefaultCookies()
    vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Get',vVDzaejqgTlnESXfsLAUHFIPGoxWut,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,params=vVDzaejqgTlnESXfsLAUHFIPGoxWuR,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWOy)
    vVDzaejqgTlnESXfsLAUHFIPGoxWuh=json.loads(vVDzaejqgTlnESXfsLAUHFIPGoxWOY.text)
    if not('stream' in vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']):return vVDzaejqgTlnESXfsLAUHFIPGoxWuw,vVDzaejqgTlnESXfsLAUHFIPGoxWuy 
    vVDzaejqgTlnESXfsLAUHFIPGoxWuQ=vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']['stream']
    vVDzaejqgTlnESXfsLAUHFIPGoxWud=vVDzaejqgTlnESXfsLAUHFIPGoxWuQ['quality']
    vVDzaejqgTlnESXfsLAUHFIPGoxWuM=[]
    for vVDzaejqgTlnESXfsLAUHFIPGoxWuc in vVDzaejqgTlnESXfsLAUHFIPGoxWud:
     if vVDzaejqgTlnESXfsLAUHFIPGoxWuc['active']=='Y':
      vVDzaejqgTlnESXfsLAUHFIPGoxWuM.append({vVDzaejqgTlnESXfsLAUHFIPGoxWOr.get(vVDzaejqgTlnESXfsLAUHFIPGoxWuc['code']):vVDzaejqgTlnESXfsLAUHFIPGoxWuc['code']})
    vVDzaejqgTlnESXfsLAUHFIPGoxWup=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.CheckQuality(sel_quality,vVDzaejqgTlnESXfsLAUHFIPGoxWuM)
   else:
    for vVDzaejqgTlnESXfsLAUHFIPGoxWum,vVDzaejqgTlnESXfsLAUHFIPGoxWrw in vVDzaejqgTlnESXfsLAUHFIPGoxWOr.items():
     if vVDzaejqgTlnESXfsLAUHFIPGoxWrw==sel_quality:
      vVDzaejqgTlnESXfsLAUHFIPGoxWup=vVDzaejqgTlnESXfsLAUHFIPGoxWum
  except vVDzaejqgTlnESXfsLAUHFIPGoxWBC as exception:
   vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(exception)
   for vVDzaejqgTlnESXfsLAUHFIPGoxWum,vVDzaejqgTlnESXfsLAUHFIPGoxWrw in vVDzaejqgTlnESXfsLAUHFIPGoxWOr.items():
    if vVDzaejqgTlnESXfsLAUHFIPGoxWrw==sel_quality:
     vVDzaejqgTlnESXfsLAUHFIPGoxWup=vVDzaejqgTlnESXfsLAUHFIPGoxWum
   return vVDzaejqgTlnESXfsLAUHFIPGoxWuw,vVDzaejqgTlnESXfsLAUHFIPGoxWuy
  vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(vVDzaejqgTlnESXfsLAUHFIPGoxWup)
  try:
   vVDzaejqgTlnESXfsLAUHFIPGoxWuN ='/streaming/info'
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetDefaultParams()
   if stype=='onair':vVDzaejqgTlnESXfsLAUHFIPGoxWuR['osCode']='CSOD0400' 
   vVDzaejqgTlnESXfsLAUHFIPGoxWuY={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   vVDzaejqgTlnESXfsLAUHFIPGoxWuK=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.makeOocUrl(vVDzaejqgTlnESXfsLAUHFIPGoxWuY)
   vVDzaejqgTlnESXfsLAUHFIPGoxWrO=urllib.parse.quote(vVDzaejqgTlnESXfsLAUHFIPGoxWuK)
   vVDzaejqgTlnESXfsLAUHFIPGoxWub={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':vVDzaejqgTlnESXfsLAUHFIPGoxWup,'adReq':'adproxy','ooc':vVDzaejqgTlnESXfsLAUHFIPGoxWuK,'deviceId':vVDzaejqgTlnESXfsLAUHFIPGoxWuC,'uuid':vVDzaejqgTlnESXfsLAUHFIPGoxWuJ,'deviceInfo':'PC'}
   vVDzaejqgTlnESXfsLAUHFIPGoxWru =vVDzaejqgTlnESXfsLAUHFIPGoxWuR
   vVDzaejqgTlnESXfsLAUHFIPGoxWru.update(vVDzaejqgTlnESXfsLAUHFIPGoxWub)
   vVDzaejqgTlnESXfsLAUHFIPGoxWut=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.URL_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuN
   vVDzaejqgTlnESXfsLAUHFIPGoxWri={'origin':'https://www.tving.com'}
   if stype=='onair':vVDzaejqgTlnESXfsLAUHFIPGoxWri['Referer']='https://www.tving.com/live/player/'+mediacode
   else: vVDzaejqgTlnESXfsLAUHFIPGoxWri['Referer']='https://www.tving.com/vod/player/'+mediacode
   vVDzaejqgTlnESXfsLAUHFIPGoxWOy=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.makeDefaultCookies()
   vVDzaejqgTlnESXfsLAUHFIPGoxWOy['onClickEvent2']=vVDzaejqgTlnESXfsLAUHFIPGoxWrO
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Post',vVDzaejqgTlnESXfsLAUHFIPGoxWut,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWru,params=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWri,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWOy,redirects=vVDzaejqgTlnESXfsLAUHFIPGoxWBi)
   vVDzaejqgTlnESXfsLAUHFIPGoxWuh=json.loads(vVDzaejqgTlnESXfsLAUHFIPGoxWOY.text)
   if 'drm_license_assertion' in vVDzaejqgTlnESXfsLAUHFIPGoxWuh['stream']:
    vVDzaejqgTlnESXfsLAUHFIPGoxWuy =vVDzaejqgTlnESXfsLAUHFIPGoxWuh['stream']['drm_license_assertion']
    vVDzaejqgTlnESXfsLAUHFIPGoxWuw=vVDzaejqgTlnESXfsLAUHFIPGoxWuh['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in vVDzaejqgTlnESXfsLAUHFIPGoxWuh['stream']['broadcast']):return vVDzaejqgTlnESXfsLAUHFIPGoxWuw,vVDzaejqgTlnESXfsLAUHFIPGoxWuy
    vVDzaejqgTlnESXfsLAUHFIPGoxWuw=vVDzaejqgTlnESXfsLAUHFIPGoxWuh['stream']['broadcast']['broad_url']
  except vVDzaejqgTlnESXfsLAUHFIPGoxWBC as exception:
   vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(exception)
  return vVDzaejqgTlnESXfsLAUHFIPGoxWuw,vVDzaejqgTlnESXfsLAUHFIPGoxWuy
 def CheckQuality(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,sel_qt,vVDzaejqgTlnESXfsLAUHFIPGoxWuM):
  for vVDzaejqgTlnESXfsLAUHFIPGoxWrk in vVDzaejqgTlnESXfsLAUHFIPGoxWuM:
   if sel_qt>=vVDzaejqgTlnESXfsLAUHFIPGoxWBR(vVDzaejqgTlnESXfsLAUHFIPGoxWrk)[0]:return vVDzaejqgTlnESXfsLAUHFIPGoxWrk.get(vVDzaejqgTlnESXfsLAUHFIPGoxWBR(vVDzaejqgTlnESXfsLAUHFIPGoxWrk)[0])
   vVDzaejqgTlnESXfsLAUHFIPGoxWrB=vVDzaejqgTlnESXfsLAUHFIPGoxWrk.get(vVDzaejqgTlnESXfsLAUHFIPGoxWBR(vVDzaejqgTlnESXfsLAUHFIPGoxWrk)[0])
  return vVDzaejqgTlnESXfsLAUHFIPGoxWrB
 def makeOocUrl(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,vVDzaejqgTlnESXfsLAUHFIPGoxWuY):
  vVDzaejqgTlnESXfsLAUHFIPGoxWut=''
  for vVDzaejqgTlnESXfsLAUHFIPGoxWum,vVDzaejqgTlnESXfsLAUHFIPGoxWrw in vVDzaejqgTlnESXfsLAUHFIPGoxWuY.items():
   vVDzaejqgTlnESXfsLAUHFIPGoxWut+="%s=%s^"%(vVDzaejqgTlnESXfsLAUHFIPGoxWum,vVDzaejqgTlnESXfsLAUHFIPGoxWrw)
  return vVDzaejqgTlnESXfsLAUHFIPGoxWut
 def GetLiveChannelList(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,stype,page_int):
  vVDzaejqgTlnESXfsLAUHFIPGoxWry=[]
  vVDzaejqgTlnESXfsLAUHFIPGoxWrC=vVDzaejqgTlnESXfsLAUHFIPGoxWBi
  vVDzaejqgTlnESXfsLAUHFIPGoxWrJ=vVDzaejqgTlnESXfsLAUHFIPGoxWBi
  try:
   vVDzaejqgTlnESXfsLAUHFIPGoxWuN ='/v2/media/lives'
   if stype=='onair': 
    vVDzaejqgTlnESXfsLAUHFIPGoxWrN='CPCS0100,CPCS0400'
   else:
    vVDzaejqgTlnESXfsLAUHFIPGoxWrN='CPCS0300'
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetDefaultParams()
   vVDzaejqgTlnESXfsLAUHFIPGoxWub={'pageNo':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(page_int),'pageSize':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':vVDzaejqgTlnESXfsLAUHFIPGoxWrN,'_':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetNoCache(2))}
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR.update(vVDzaejqgTlnESXfsLAUHFIPGoxWub)
   vVDzaejqgTlnESXfsLAUHFIPGoxWut=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.API_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuN
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Get',vVDzaejqgTlnESXfsLAUHFIPGoxWut,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,params=vVDzaejqgTlnESXfsLAUHFIPGoxWuR,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWBr)
   vVDzaejqgTlnESXfsLAUHFIPGoxWuh=json.loads(vVDzaejqgTlnESXfsLAUHFIPGoxWOY.text)
   if not('result' in vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']):return vVDzaejqgTlnESXfsLAUHFIPGoxWry,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
   vVDzaejqgTlnESXfsLAUHFIPGoxWrR=vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']['result']
   for vVDzaejqgTlnESXfsLAUHFIPGoxWuc in vVDzaejqgTlnESXfsLAUHFIPGoxWrR:
    vVDzaejqgTlnESXfsLAUHFIPGoxWrb=vVDzaejqgTlnESXfsLAUHFIPGoxWrQ=vVDzaejqgTlnESXfsLAUHFIPGoxWrd=''
    vVDzaejqgTlnESXfsLAUHFIPGoxWrt=vVDzaejqgTlnESXfsLAUHFIPGoxWiR=''
    vVDzaejqgTlnESXfsLAUHFIPGoxWrh=vVDzaejqgTlnESXfsLAUHFIPGoxWuc['live_code']
    if vVDzaejqgTlnESXfsLAUHFIPGoxWrh=='C01345':vVDzaejqgTlnESXfsLAUHFIPGoxWrJ=vVDzaejqgTlnESXfsLAUHFIPGoxWBy 
    vVDzaejqgTlnESXfsLAUHFIPGoxWrb =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['channel']['name']['ko']
    if vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['episode']!=vVDzaejqgTlnESXfsLAUHFIPGoxWBr:
     vVDzaejqgTlnESXfsLAUHFIPGoxWrQ =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['program']['name']['ko']
     vVDzaejqgTlnESXfsLAUHFIPGoxWrQ =vVDzaejqgTlnESXfsLAUHFIPGoxWrQ+', '+vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['episode']['frequency'])+'회'
     vVDzaejqgTlnESXfsLAUHFIPGoxWrd=vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['episode']['synopsis']['ko']
    else:
     vVDzaejqgTlnESXfsLAUHFIPGoxWrQ =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['program']['name']['ko']
     vVDzaejqgTlnESXfsLAUHFIPGoxWrd=vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['program']['synopsis']['ko']
    try: 
     vVDzaejqgTlnESXfsLAUHFIPGoxWrM =''
     vVDzaejqgTlnESXfsLAUHFIPGoxWrc =''
     vVDzaejqgTlnESXfsLAUHFIPGoxWrp=''
     vVDzaejqgTlnESXfsLAUHFIPGoxWrm =''
     vVDzaejqgTlnESXfsLAUHFIPGoxWrY =''
     vVDzaejqgTlnESXfsLAUHFIPGoxWrK =''
     for vVDzaejqgTlnESXfsLAUHFIPGoxWiO in vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['program']['image']:
      if vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP0900':vVDzaejqgTlnESXfsLAUHFIPGoxWrc =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
      elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP1800':vVDzaejqgTlnESXfsLAUHFIPGoxWrp=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
      elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP2000':vVDzaejqgTlnESXfsLAUHFIPGoxWrm =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
      elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP1900':vVDzaejqgTlnESXfsLAUHFIPGoxWrY =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
      elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP0200':vVDzaejqgTlnESXfsLAUHFIPGoxWrK =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
      elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP0500':vVDzaejqgTlnESXfsLAUHFIPGoxWrM =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
      elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP0800':vVDzaejqgTlnESXfsLAUHFIPGoxWrM =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
     if vVDzaejqgTlnESXfsLAUHFIPGoxWrM=='':
      for vVDzaejqgTlnESXfsLAUHFIPGoxWiO in vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['channel']['image']:
       if vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIC0400':vVDzaejqgTlnESXfsLAUHFIPGoxWrM =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
       elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIC1400':vVDzaejqgTlnESXfsLAUHFIPGoxWrM =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
       elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIC1900':vVDzaejqgTlnESXfsLAUHFIPGoxWrM =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
    except:
     vVDzaejqgTlnESXfsLAUHFIPGoxWBr
    try:
     vVDzaejqgTlnESXfsLAUHFIPGoxWiu =[]
     vVDzaejqgTlnESXfsLAUHFIPGoxWir=[]
     vVDzaejqgTlnESXfsLAUHFIPGoxWik =[]
     vVDzaejqgTlnESXfsLAUHFIPGoxWiB=''
     vVDzaejqgTlnESXfsLAUHFIPGoxWiw=''
     vVDzaejqgTlnESXfsLAUHFIPGoxWiy=''
     for vVDzaejqgTlnESXfsLAUHFIPGoxWiC in vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('schedule').get('program').get('actor'):
      if vVDzaejqgTlnESXfsLAUHFIPGoxWiC!='' and vVDzaejqgTlnESXfsLAUHFIPGoxWiC!=u'없음':vVDzaejqgTlnESXfsLAUHFIPGoxWiu.append(vVDzaejqgTlnESXfsLAUHFIPGoxWiC)
     for vVDzaejqgTlnESXfsLAUHFIPGoxWiJ in vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('schedule').get('program').get('director'):
      if vVDzaejqgTlnESXfsLAUHFIPGoxWiJ!='' and vVDzaejqgTlnESXfsLAUHFIPGoxWiJ!='-' and vVDzaejqgTlnESXfsLAUHFIPGoxWiJ!=u'없음':vVDzaejqgTlnESXfsLAUHFIPGoxWir.append(vVDzaejqgTlnESXfsLAUHFIPGoxWiJ)
     if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('schedule').get('program').get('category1_name').get('ko')!='':
      vVDzaejqgTlnESXfsLAUHFIPGoxWik.append(vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['program']['category1_name']['ko'])
     if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('schedule').get('program').get('category2_name').get('ko')!='':
      vVDzaejqgTlnESXfsLAUHFIPGoxWik.append(vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['program']['category2_name']['ko'])
     if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('schedule').get('program').get('product_year'):vVDzaejqgTlnESXfsLAUHFIPGoxWiB=vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['program']['product_year']
     if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('schedule').get('program').get('grade_code') :vVDzaejqgTlnESXfsLAUHFIPGoxWiw= vVDzaejqgTlnESXfsLAUHFIPGoxWOi.get(vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['program']['grade_code'])
     if 'broad_dt' in vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('schedule').get('program'):
      vVDzaejqgTlnESXfsLAUHFIPGoxWiN =vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('schedule').get('program').get('broad_dt')
      vVDzaejqgTlnESXfsLAUHFIPGoxWiy='%s-%s-%s'%(vVDzaejqgTlnESXfsLAUHFIPGoxWiN[:4],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[4:6],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[6:])
    except:
     vVDzaejqgTlnESXfsLAUHFIPGoxWBr
    vVDzaejqgTlnESXfsLAUHFIPGoxWrt=vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['broadcast_start_time'])[8:12]
    vVDzaejqgTlnESXfsLAUHFIPGoxWiR =vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWuc['schedule']['broadcast_end_time'])[8:12]
    vVDzaejqgTlnESXfsLAUHFIPGoxWib={'channel':vVDzaejqgTlnESXfsLAUHFIPGoxWrb,'title':vVDzaejqgTlnESXfsLAUHFIPGoxWrQ,'mediacode':vVDzaejqgTlnESXfsLAUHFIPGoxWrh,'thumbnail':{'poster':vVDzaejqgTlnESXfsLAUHFIPGoxWrc,'thumb':vVDzaejqgTlnESXfsLAUHFIPGoxWrM,'clearlogo':vVDzaejqgTlnESXfsLAUHFIPGoxWrp,'icon':vVDzaejqgTlnESXfsLAUHFIPGoxWrm,'fanart':vVDzaejqgTlnESXfsLAUHFIPGoxWrK},'synopsis':vVDzaejqgTlnESXfsLAUHFIPGoxWrd,'channelepg':' [%s:%s ~ %s:%s]'%(vVDzaejqgTlnESXfsLAUHFIPGoxWrt[0:2],vVDzaejqgTlnESXfsLAUHFIPGoxWrt[2:],vVDzaejqgTlnESXfsLAUHFIPGoxWiR[0:2],vVDzaejqgTlnESXfsLAUHFIPGoxWiR[2:]),'cast':vVDzaejqgTlnESXfsLAUHFIPGoxWiu,'director':vVDzaejqgTlnESXfsLAUHFIPGoxWir,'info_genre':vVDzaejqgTlnESXfsLAUHFIPGoxWik,'year':vVDzaejqgTlnESXfsLAUHFIPGoxWiB,'mpaa':vVDzaejqgTlnESXfsLAUHFIPGoxWiw,'premiered':vVDzaejqgTlnESXfsLAUHFIPGoxWiy}
    vVDzaejqgTlnESXfsLAUHFIPGoxWry.append(vVDzaejqgTlnESXfsLAUHFIPGoxWib)
   if vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']['has_more']=='Y':
    vVDzaejqgTlnESXfsLAUHFIPGoxWrC=vVDzaejqgTlnESXfsLAUHFIPGoxWBy
   else:
    vVDzaejqgTlnESXfsLAUHFIPGoxWib={'channel':'OCN Original','title':'temp','mediacode':'C01345','thumbnail':'http://image.tving.com/upload/cms/caic/CAIC0400/C01345.png','cast':[],'director':[]}
  except vVDzaejqgTlnESXfsLAUHFIPGoxWBC as exception:
   vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(exception)
  return vVDzaejqgTlnESXfsLAUHFIPGoxWry,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
 def GetProgramList(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,genre,orderby,page_int,genreCode='all'):
  vVDzaejqgTlnESXfsLAUHFIPGoxWry=[]
  vVDzaejqgTlnESXfsLAUHFIPGoxWrC=vVDzaejqgTlnESXfsLAUHFIPGoxWBi
  try:
   vVDzaejqgTlnESXfsLAUHFIPGoxWuN ='/v2/media/episodes'
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetDefaultParams()
   vVDzaejqgTlnESXfsLAUHFIPGoxWub={'pageNo':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(page_int),'pageSize':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetNoCache(2))}
   if genre !='all':vVDzaejqgTlnESXfsLAUHFIPGoxWub['categoryCode']=genre
   if genreCode!='all':vVDzaejqgTlnESXfsLAUHFIPGoxWub['genreCode'] =genreCode 
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR.update(vVDzaejqgTlnESXfsLAUHFIPGoxWub)
   vVDzaejqgTlnESXfsLAUHFIPGoxWut=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.API_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuN
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Get',vVDzaejqgTlnESXfsLAUHFIPGoxWut,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,params=vVDzaejqgTlnESXfsLAUHFIPGoxWuR,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWBr)
   vVDzaejqgTlnESXfsLAUHFIPGoxWuh=json.loads(vVDzaejqgTlnESXfsLAUHFIPGoxWOY.text)
   if not('result' in vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']):return vVDzaejqgTlnESXfsLAUHFIPGoxWry,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
   vVDzaejqgTlnESXfsLAUHFIPGoxWrR=vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']['result']
   for vVDzaejqgTlnESXfsLAUHFIPGoxWuc in vVDzaejqgTlnESXfsLAUHFIPGoxWrR:
    vVDzaejqgTlnESXfsLAUHFIPGoxWit=vVDzaejqgTlnESXfsLAUHFIPGoxWuc['program']['code']
    vVDzaejqgTlnESXfsLAUHFIPGoxWrQ =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['program']['name']['ko']
    vVDzaejqgTlnESXfsLAUHFIPGoxWiw =vVDzaejqgTlnESXfsLAUHFIPGoxWOi.get(vVDzaejqgTlnESXfsLAUHFIPGoxWuc['program'].get('grade_code'))
    vVDzaejqgTlnESXfsLAUHFIPGoxWrc =''
    vVDzaejqgTlnESXfsLAUHFIPGoxWrM =''
    vVDzaejqgTlnESXfsLAUHFIPGoxWrp=''
    vVDzaejqgTlnESXfsLAUHFIPGoxWrm =''
    vVDzaejqgTlnESXfsLAUHFIPGoxWrY =''
    for vVDzaejqgTlnESXfsLAUHFIPGoxWiO in vVDzaejqgTlnESXfsLAUHFIPGoxWuc['program']['image']:
     if vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP0900':vVDzaejqgTlnESXfsLAUHFIPGoxWrc =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
     elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP0200':vVDzaejqgTlnESXfsLAUHFIPGoxWrM =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
     elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP1800':vVDzaejqgTlnESXfsLAUHFIPGoxWrp=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
     elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP2000':vVDzaejqgTlnESXfsLAUHFIPGoxWrm =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
     elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP1900':vVDzaejqgTlnESXfsLAUHFIPGoxWrY =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
    vVDzaejqgTlnESXfsLAUHFIPGoxWrd =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['program']['synopsis']['ko']
    try:
     vVDzaejqgTlnESXfsLAUHFIPGoxWih=vVDzaejqgTlnESXfsLAUHFIPGoxWuc['channel']['name']['ko']
    except:
     vVDzaejqgTlnESXfsLAUHFIPGoxWih=''
    try:
     vVDzaejqgTlnESXfsLAUHFIPGoxWiu =[]
     vVDzaejqgTlnESXfsLAUHFIPGoxWir=[]
     vVDzaejqgTlnESXfsLAUHFIPGoxWik =[]
     vVDzaejqgTlnESXfsLAUHFIPGoxWiB =''
     vVDzaejqgTlnESXfsLAUHFIPGoxWiy=''
     for vVDzaejqgTlnESXfsLAUHFIPGoxWiC in vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('program').get('actor'):
      if vVDzaejqgTlnESXfsLAUHFIPGoxWiC!='' and vVDzaejqgTlnESXfsLAUHFIPGoxWiC!='-' and vVDzaejqgTlnESXfsLAUHFIPGoxWiC!=u'없음':vVDzaejqgTlnESXfsLAUHFIPGoxWiu.append(vVDzaejqgTlnESXfsLAUHFIPGoxWiC)
     for vVDzaejqgTlnESXfsLAUHFIPGoxWiJ in vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('program').get('director'):
      if vVDzaejqgTlnESXfsLAUHFIPGoxWiJ!='' and vVDzaejqgTlnESXfsLAUHFIPGoxWiJ!='-' and vVDzaejqgTlnESXfsLAUHFIPGoxWiJ!=u'없음':vVDzaejqgTlnESXfsLAUHFIPGoxWir.append(vVDzaejqgTlnESXfsLAUHFIPGoxWiJ)
     if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('program').get('category1_name').get('ko')!='':
      vVDzaejqgTlnESXfsLAUHFIPGoxWik.append(vVDzaejqgTlnESXfsLAUHFIPGoxWuc['program']['category1_name']['ko'])
     if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('program').get('category2_name').get('ko')!='':
      vVDzaejqgTlnESXfsLAUHFIPGoxWik.append(vVDzaejqgTlnESXfsLAUHFIPGoxWuc['program']['category2_name']['ko'])
     if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('program').get('product_year'):vVDzaejqgTlnESXfsLAUHFIPGoxWiB=vVDzaejqgTlnESXfsLAUHFIPGoxWuc['program']['product_year']
     if 'broad_dt' in vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('program'):
      vVDzaejqgTlnESXfsLAUHFIPGoxWiN =vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('program').get('broad_dt')
      vVDzaejqgTlnESXfsLAUHFIPGoxWiy='%s-%s-%s'%(vVDzaejqgTlnESXfsLAUHFIPGoxWiN[:4],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[4:6],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[6:])
    except:
     vVDzaejqgTlnESXfsLAUHFIPGoxWBr
    vVDzaejqgTlnESXfsLAUHFIPGoxWib={'program':vVDzaejqgTlnESXfsLAUHFIPGoxWit,'title':vVDzaejqgTlnESXfsLAUHFIPGoxWrQ,'thumbnail':{'poster':vVDzaejqgTlnESXfsLAUHFIPGoxWrc,'thumb':vVDzaejqgTlnESXfsLAUHFIPGoxWrM,'clearlogo':vVDzaejqgTlnESXfsLAUHFIPGoxWrp,'icon':vVDzaejqgTlnESXfsLAUHFIPGoxWrm,'banner':vVDzaejqgTlnESXfsLAUHFIPGoxWrY,'fanart':vVDzaejqgTlnESXfsLAUHFIPGoxWrM},'synopsis':vVDzaejqgTlnESXfsLAUHFIPGoxWrd,'channel':vVDzaejqgTlnESXfsLAUHFIPGoxWih,'cast':vVDzaejqgTlnESXfsLAUHFIPGoxWiu,'director':vVDzaejqgTlnESXfsLAUHFIPGoxWir,'info_genre':vVDzaejqgTlnESXfsLAUHFIPGoxWik,'year':vVDzaejqgTlnESXfsLAUHFIPGoxWiB,'premiered':vVDzaejqgTlnESXfsLAUHFIPGoxWiy,'mpaa':vVDzaejqgTlnESXfsLAUHFIPGoxWiw}
    vVDzaejqgTlnESXfsLAUHFIPGoxWry.append(vVDzaejqgTlnESXfsLAUHFIPGoxWib)
   if vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']['has_more']=='Y':vVDzaejqgTlnESXfsLAUHFIPGoxWrC=vVDzaejqgTlnESXfsLAUHFIPGoxWBy
  except vVDzaejqgTlnESXfsLAUHFIPGoxWBC as exception:
   vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(exception)
  return vVDzaejqgTlnESXfsLAUHFIPGoxWry,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
 def GetEpisodeList(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,program_code,page_int,orderby='desc'):
  vVDzaejqgTlnESXfsLAUHFIPGoxWry=[]
  vVDzaejqgTlnESXfsLAUHFIPGoxWrC=vVDzaejqgTlnESXfsLAUHFIPGoxWBi
  try:
   vVDzaejqgTlnESXfsLAUHFIPGoxWuN ='/v2/media/frequency/program/'+program_code
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetDefaultParams()
   vVDzaejqgTlnESXfsLAUHFIPGoxWub={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetNoCache(2))}
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR.update(vVDzaejqgTlnESXfsLAUHFIPGoxWub)
   vVDzaejqgTlnESXfsLAUHFIPGoxWut=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.API_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuN
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Get',vVDzaejqgTlnESXfsLAUHFIPGoxWut,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,params=vVDzaejqgTlnESXfsLAUHFIPGoxWuR,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWBr)
   vVDzaejqgTlnESXfsLAUHFIPGoxWuh=json.loads(vVDzaejqgTlnESXfsLAUHFIPGoxWOY.text)
   if not('result' in vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']):return vVDzaejqgTlnESXfsLAUHFIPGoxWry,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
   vVDzaejqgTlnESXfsLAUHFIPGoxWrR=vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']['result']
   vVDzaejqgTlnESXfsLAUHFIPGoxWiQ=vVDzaejqgTlnESXfsLAUHFIPGoxWBk(vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']['total_count'])
   vVDzaejqgTlnESXfsLAUHFIPGoxWid =vVDzaejqgTlnESXfsLAUHFIPGoxWBk(vVDzaejqgTlnESXfsLAUHFIPGoxWiQ//(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    vVDzaejqgTlnESXfsLAUHFIPGoxWiM =(vVDzaejqgTlnESXfsLAUHFIPGoxWiQ-1)-((page_int-1)*vVDzaejqgTlnESXfsLAUHFIPGoxWOk.EPISODE_LIMIT)
   else:
    vVDzaejqgTlnESXfsLAUHFIPGoxWiM =(page_int-1)*vVDzaejqgTlnESXfsLAUHFIPGoxWOk.EPISODE_LIMIT
   for i in vVDzaejqgTlnESXfsLAUHFIPGoxWBw(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.EPISODE_LIMIT):
    if orderby=='desc':
     vVDzaejqgTlnESXfsLAUHFIPGoxWic=vVDzaejqgTlnESXfsLAUHFIPGoxWiM-i
     if vVDzaejqgTlnESXfsLAUHFIPGoxWic<0:break
    else:
     vVDzaejqgTlnESXfsLAUHFIPGoxWic=vVDzaejqgTlnESXfsLAUHFIPGoxWiM+i
     if vVDzaejqgTlnESXfsLAUHFIPGoxWic>=vVDzaejqgTlnESXfsLAUHFIPGoxWiQ:break
    vVDzaejqgTlnESXfsLAUHFIPGoxWip=vVDzaejqgTlnESXfsLAUHFIPGoxWrR[vVDzaejqgTlnESXfsLAUHFIPGoxWic]['episode']['code']
    vVDzaejqgTlnESXfsLAUHFIPGoxWrQ =vVDzaejqgTlnESXfsLAUHFIPGoxWrR[vVDzaejqgTlnESXfsLAUHFIPGoxWic]['vod_name']['ko']
    vVDzaejqgTlnESXfsLAUHFIPGoxWim =''
    try:
     vVDzaejqgTlnESXfsLAUHFIPGoxWiN=vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWrR[vVDzaejqgTlnESXfsLAUHFIPGoxWic]['episode']['broadcast_date'])
     vVDzaejqgTlnESXfsLAUHFIPGoxWim='%s-%s-%s'%(vVDzaejqgTlnESXfsLAUHFIPGoxWiN[:4],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[4:6],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[6:])
    except:
     vVDzaejqgTlnESXfsLAUHFIPGoxWBr
    vVDzaejqgTlnESXfsLAUHFIPGoxWrd =vVDzaejqgTlnESXfsLAUHFIPGoxWrR[vVDzaejqgTlnESXfsLAUHFIPGoxWic]['episode']['synopsis']['ko']
    vVDzaejqgTlnESXfsLAUHFIPGoxWrc =''
    vVDzaejqgTlnESXfsLAUHFIPGoxWrM =''
    vVDzaejqgTlnESXfsLAUHFIPGoxWrp=''
    vVDzaejqgTlnESXfsLAUHFIPGoxWrm =''
    vVDzaejqgTlnESXfsLAUHFIPGoxWrY =''
    vVDzaejqgTlnESXfsLAUHFIPGoxWrK =''
    for vVDzaejqgTlnESXfsLAUHFIPGoxWiO in vVDzaejqgTlnESXfsLAUHFIPGoxWrR[vVDzaejqgTlnESXfsLAUHFIPGoxWic]['program']['image']:
     if vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP0900':vVDzaejqgTlnESXfsLAUHFIPGoxWrc =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
     elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP1800':vVDzaejqgTlnESXfsLAUHFIPGoxWrp=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
     elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP2000':vVDzaejqgTlnESXfsLAUHFIPGoxWrm =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
     elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP1900':vVDzaejqgTlnESXfsLAUHFIPGoxWrY =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
     elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIP0200':vVDzaejqgTlnESXfsLAUHFIPGoxWrK =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
    for vVDzaejqgTlnESXfsLAUHFIPGoxWiO in vVDzaejqgTlnESXfsLAUHFIPGoxWrR[vVDzaejqgTlnESXfsLAUHFIPGoxWic]['episode']['image']:
     if vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIE0400':vVDzaejqgTlnESXfsLAUHFIPGoxWrM =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
    try:
     vVDzaejqgTlnESXfsLAUHFIPGoxWiY=vVDzaejqgTlnESXfsLAUHFIPGoxWkO=vVDzaejqgTlnESXfsLAUHFIPGoxWku=''
     vVDzaejqgTlnESXfsLAUHFIPGoxWiK=0
     vVDzaejqgTlnESXfsLAUHFIPGoxWiY =vVDzaejqgTlnESXfsLAUHFIPGoxWrR[vVDzaejqgTlnESXfsLAUHFIPGoxWic]['program']['name']['ko']
     vVDzaejqgTlnESXfsLAUHFIPGoxWkO =vVDzaejqgTlnESXfsLAUHFIPGoxWim
     vVDzaejqgTlnESXfsLAUHFIPGoxWku =vVDzaejqgTlnESXfsLAUHFIPGoxWrR[vVDzaejqgTlnESXfsLAUHFIPGoxWic]['channel']['name']['ko']
     if 'frequency' in vVDzaejqgTlnESXfsLAUHFIPGoxWrR[vVDzaejqgTlnESXfsLAUHFIPGoxWic]['episode']:vVDzaejqgTlnESXfsLAUHFIPGoxWiK=vVDzaejqgTlnESXfsLAUHFIPGoxWrR[vVDzaejqgTlnESXfsLAUHFIPGoxWic]['episode']['frequency']
    except:
     vVDzaejqgTlnESXfsLAUHFIPGoxWBr
    vVDzaejqgTlnESXfsLAUHFIPGoxWib={'episode':vVDzaejqgTlnESXfsLAUHFIPGoxWip,'title':vVDzaejqgTlnESXfsLAUHFIPGoxWrQ,'subtitle':vVDzaejqgTlnESXfsLAUHFIPGoxWim,'thumbnail':{'poster':vVDzaejqgTlnESXfsLAUHFIPGoxWrc,'thumb':vVDzaejqgTlnESXfsLAUHFIPGoxWrM,'clearlogo':vVDzaejqgTlnESXfsLAUHFIPGoxWrp,'icon':vVDzaejqgTlnESXfsLAUHFIPGoxWrm,'banner':vVDzaejqgTlnESXfsLAUHFIPGoxWrY,'fanart':vVDzaejqgTlnESXfsLAUHFIPGoxWrK},'synopsis':vVDzaejqgTlnESXfsLAUHFIPGoxWrd,'info_title':vVDzaejqgTlnESXfsLAUHFIPGoxWiY,'aired':vVDzaejqgTlnESXfsLAUHFIPGoxWkO,'studio':vVDzaejqgTlnESXfsLAUHFIPGoxWku,'frequency':vVDzaejqgTlnESXfsLAUHFIPGoxWiK}
    vVDzaejqgTlnESXfsLAUHFIPGoxWry.append(vVDzaejqgTlnESXfsLAUHFIPGoxWib)
   if vVDzaejqgTlnESXfsLAUHFIPGoxWid>page_int:vVDzaejqgTlnESXfsLAUHFIPGoxWrC=vVDzaejqgTlnESXfsLAUHFIPGoxWBy
  except vVDzaejqgTlnESXfsLAUHFIPGoxWBC as exception:
   vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(exception)
  return vVDzaejqgTlnESXfsLAUHFIPGoxWry,vVDzaejqgTlnESXfsLAUHFIPGoxWrC,vVDzaejqgTlnESXfsLAUHFIPGoxWid
 def GetMovieList(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,genre,orderby,page_int):
  vVDzaejqgTlnESXfsLAUHFIPGoxWry=[]
  vVDzaejqgTlnESXfsLAUHFIPGoxWrC=vVDzaejqgTlnESXfsLAUHFIPGoxWBi
  try:
   vVDzaejqgTlnESXfsLAUHFIPGoxWuN ='/v2/media/movies'
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetDefaultParams()
   vVDzaejqgTlnESXfsLAUHFIPGoxWub={'pageNo':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(page_int),'pageSize':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetNoCache(2))}
   if genre!='all' :vVDzaejqgTlnESXfsLAUHFIPGoxWub['multiCategoryCode']=genre
   vVDzaejqgTlnESXfsLAUHFIPGoxWub['productPackageCode']=','.join(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.MOVIE_LITE)
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR.update(vVDzaejqgTlnESXfsLAUHFIPGoxWub)
   vVDzaejqgTlnESXfsLAUHFIPGoxWut=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.API_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuN
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Get',vVDzaejqgTlnESXfsLAUHFIPGoxWut,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,params=vVDzaejqgTlnESXfsLAUHFIPGoxWuR,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWBr)
   vVDzaejqgTlnESXfsLAUHFIPGoxWuh=json.loads(vVDzaejqgTlnESXfsLAUHFIPGoxWOY.text)
   if not('result' in vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']):return vVDzaejqgTlnESXfsLAUHFIPGoxWry,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
   vVDzaejqgTlnESXfsLAUHFIPGoxWrR=vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']['result']
   for vVDzaejqgTlnESXfsLAUHFIPGoxWuc in vVDzaejqgTlnESXfsLAUHFIPGoxWrR:
    vVDzaejqgTlnESXfsLAUHFIPGoxWkr =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['movie']['code']
    vVDzaejqgTlnESXfsLAUHFIPGoxWrQ =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['movie']['name']['ko'].strip()
    vVDzaejqgTlnESXfsLAUHFIPGoxWrQ +=u' (%s년)'%(vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('movie').get('product_year'))
    vVDzaejqgTlnESXfsLAUHFIPGoxWrc=''
    vVDzaejqgTlnESXfsLAUHFIPGoxWrM =''
    vVDzaejqgTlnESXfsLAUHFIPGoxWrp=''
    for vVDzaejqgTlnESXfsLAUHFIPGoxWiO in vVDzaejqgTlnESXfsLAUHFIPGoxWuc['movie']['image']:
     if vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIM2100':vVDzaejqgTlnESXfsLAUHFIPGoxWrc =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
     elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIM0400':vVDzaejqgTlnESXfsLAUHFIPGoxWrM =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
     elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIM1800':vVDzaejqgTlnESXfsLAUHFIPGoxWrp=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
    vVDzaejqgTlnESXfsLAUHFIPGoxWrd =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['movie']['story']['ko']
    try:
     vVDzaejqgTlnESXfsLAUHFIPGoxWiY =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['movie']['name']['ko'].strip()
     vVDzaejqgTlnESXfsLAUHFIPGoxWiB =vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('movie').get('product_year')
     vVDzaejqgTlnESXfsLAUHFIPGoxWiw =vVDzaejqgTlnESXfsLAUHFIPGoxWOi.get(vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('grade_code'))
     vVDzaejqgTlnESXfsLAUHFIPGoxWiu=[]
     vVDzaejqgTlnESXfsLAUHFIPGoxWir=[]
     vVDzaejqgTlnESXfsLAUHFIPGoxWik=[]
     vVDzaejqgTlnESXfsLAUHFIPGoxWki=0
     vVDzaejqgTlnESXfsLAUHFIPGoxWiy=''
     vVDzaejqgTlnESXfsLAUHFIPGoxWku =''
     for vVDzaejqgTlnESXfsLAUHFIPGoxWiC in vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('movie').get('actor'):
      if vVDzaejqgTlnESXfsLAUHFIPGoxWiC!='':vVDzaejqgTlnESXfsLAUHFIPGoxWiu.append(vVDzaejqgTlnESXfsLAUHFIPGoxWiC)
     for vVDzaejqgTlnESXfsLAUHFIPGoxWiJ in vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('movie').get('director'):
      if vVDzaejqgTlnESXfsLAUHFIPGoxWiJ!='':vVDzaejqgTlnESXfsLAUHFIPGoxWir.append(vVDzaejqgTlnESXfsLAUHFIPGoxWiJ)
     if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('movie').get('category1_name').get('ko')!='':
      vVDzaejqgTlnESXfsLAUHFIPGoxWik.append(vVDzaejqgTlnESXfsLAUHFIPGoxWuc['movie']['category1_name']['ko'])
     if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('movie').get('category2_name').get('ko')!='':
      vVDzaejqgTlnESXfsLAUHFIPGoxWik.append(vVDzaejqgTlnESXfsLAUHFIPGoxWuc['movie']['category2_name']['ko'])
     if 'duration' in vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('movie'):vVDzaejqgTlnESXfsLAUHFIPGoxWki=vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('movie').get('duration')
     if 'release_date' in vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('movie'):
      vVDzaejqgTlnESXfsLAUHFIPGoxWiN=vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('movie').get('release_date'))
      if vVDzaejqgTlnESXfsLAUHFIPGoxWiN!='0':vVDzaejqgTlnESXfsLAUHFIPGoxWiy='%s-%s-%s'%(vVDzaejqgTlnESXfsLAUHFIPGoxWiN[:4],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[4:6],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[6:])
     if 'production' in vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('movie'):vVDzaejqgTlnESXfsLAUHFIPGoxWku=vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('movie').get('production')
    except:
     vVDzaejqgTlnESXfsLAUHFIPGoxWBr
    vVDzaejqgTlnESXfsLAUHFIPGoxWib={'moviecode':vVDzaejqgTlnESXfsLAUHFIPGoxWkr,'title':vVDzaejqgTlnESXfsLAUHFIPGoxWrQ,'thumbnail':{'poster':vVDzaejqgTlnESXfsLAUHFIPGoxWrc,'thumb':vVDzaejqgTlnESXfsLAUHFIPGoxWrM,'clearlogo':vVDzaejqgTlnESXfsLAUHFIPGoxWrp,'fanart':vVDzaejqgTlnESXfsLAUHFIPGoxWrM},'synopsis':vVDzaejqgTlnESXfsLAUHFIPGoxWrd,'info_title':vVDzaejqgTlnESXfsLAUHFIPGoxWiY,'year':vVDzaejqgTlnESXfsLAUHFIPGoxWiB,'cast':vVDzaejqgTlnESXfsLAUHFIPGoxWiu,'director':vVDzaejqgTlnESXfsLAUHFIPGoxWir,'info_genre':vVDzaejqgTlnESXfsLAUHFIPGoxWik,'duration':vVDzaejqgTlnESXfsLAUHFIPGoxWki,'premiered':vVDzaejqgTlnESXfsLAUHFIPGoxWiy,'studio':vVDzaejqgTlnESXfsLAUHFIPGoxWku,'mpaa':vVDzaejqgTlnESXfsLAUHFIPGoxWiw}
    vVDzaejqgTlnESXfsLAUHFIPGoxWkB=vVDzaejqgTlnESXfsLAUHFIPGoxWBi
    for vVDzaejqgTlnESXfsLAUHFIPGoxWkw in vVDzaejqgTlnESXfsLAUHFIPGoxWuc['billing_package_id']:
     if vVDzaejqgTlnESXfsLAUHFIPGoxWkw in vVDzaejqgTlnESXfsLAUHFIPGoxWOk.MOVIE_LITE:
      vVDzaejqgTlnESXfsLAUHFIPGoxWkB=vVDzaejqgTlnESXfsLAUHFIPGoxWBy
      break
    if vVDzaejqgTlnESXfsLAUHFIPGoxWkB==vVDzaejqgTlnESXfsLAUHFIPGoxWBi: 
     vVDzaejqgTlnESXfsLAUHFIPGoxWib['title']=vVDzaejqgTlnESXfsLAUHFIPGoxWib['title']+' [개별구매]'
    vVDzaejqgTlnESXfsLAUHFIPGoxWry.append(vVDzaejqgTlnESXfsLAUHFIPGoxWib)
   if vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']['has_more']=='Y':vVDzaejqgTlnESXfsLAUHFIPGoxWrC=vVDzaejqgTlnESXfsLAUHFIPGoxWBy
  except vVDzaejqgTlnESXfsLAUHFIPGoxWBC as exception:
   vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(exception)
  return vVDzaejqgTlnESXfsLAUHFIPGoxWry,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
 def GetMovieListGenre(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,genre,page_int):
  vVDzaejqgTlnESXfsLAUHFIPGoxWry=[]
  vVDzaejqgTlnESXfsLAUHFIPGoxWrC=vVDzaejqgTlnESXfsLAUHFIPGoxWBi
  try:
   vVDzaejqgTlnESXfsLAUHFIPGoxWuN ='/v2/media/movie/curation/'+genre
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetDefaultParams()
   vVDzaejqgTlnESXfsLAUHFIPGoxWub={'pageNo':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(page_int),'pageSize':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.MOVIE_LIMIT),'_':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetNoCache(2))}
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR.update(vVDzaejqgTlnESXfsLAUHFIPGoxWub)
   vVDzaejqgTlnESXfsLAUHFIPGoxWut=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.API_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuN
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Get',vVDzaejqgTlnESXfsLAUHFIPGoxWut,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,params=vVDzaejqgTlnESXfsLAUHFIPGoxWuR,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWBr)
   vVDzaejqgTlnESXfsLAUHFIPGoxWuh=json.loads(vVDzaejqgTlnESXfsLAUHFIPGoxWOY.text)
   if not('movies' in vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']):return vVDzaejqgTlnESXfsLAUHFIPGoxWry,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
   vVDzaejqgTlnESXfsLAUHFIPGoxWrR=vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']['movies']
   for vVDzaejqgTlnESXfsLAUHFIPGoxWuc in vVDzaejqgTlnESXfsLAUHFIPGoxWrR:
    vVDzaejqgTlnESXfsLAUHFIPGoxWkr =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['code']
    vVDzaejqgTlnESXfsLAUHFIPGoxWrQ =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['name']['ko']
    vVDzaejqgTlnESXfsLAUHFIPGoxWky =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuc['image'][0]['url']
    for vVDzaejqgTlnESXfsLAUHFIPGoxWiO in vVDzaejqgTlnESXfsLAUHFIPGoxWuc['image']:
     if vVDzaejqgTlnESXfsLAUHFIPGoxWiO['code']=='CAIM2100':
      vVDzaejqgTlnESXfsLAUHFIPGoxWky =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO['url']
    vVDzaejqgTlnESXfsLAUHFIPGoxWrd =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['story']['ko']
    vVDzaejqgTlnESXfsLAUHFIPGoxWib={'moviecode':vVDzaejqgTlnESXfsLAUHFIPGoxWkr,'title':vVDzaejqgTlnESXfsLAUHFIPGoxWrQ.strip(),'thumbnail':vVDzaejqgTlnESXfsLAUHFIPGoxWky,'synopsis':vVDzaejqgTlnESXfsLAUHFIPGoxWrd}
    vVDzaejqgTlnESXfsLAUHFIPGoxWry.append(vVDzaejqgTlnESXfsLAUHFIPGoxWib)
  except vVDzaejqgTlnESXfsLAUHFIPGoxWBC as exception:
   vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(exception)
  return vVDzaejqgTlnESXfsLAUHFIPGoxWry,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
 def GetMovieGenre(vVDzaejqgTlnESXfsLAUHFIPGoxWOk):
  vVDzaejqgTlnESXfsLAUHFIPGoxWry=[]
  vVDzaejqgTlnESXfsLAUHFIPGoxWrC=vVDzaejqgTlnESXfsLAUHFIPGoxWBi
  try:
   vVDzaejqgTlnESXfsLAUHFIPGoxWuN ='/v2/media/movie/curations'
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetDefaultParams()
   vVDzaejqgTlnESXfsLAUHFIPGoxWub={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetNoCache(2))}
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR.update(vVDzaejqgTlnESXfsLAUHFIPGoxWub)
   vVDzaejqgTlnESXfsLAUHFIPGoxWut=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.API_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuN
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Get',vVDzaejqgTlnESXfsLAUHFIPGoxWut,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,params=vVDzaejqgTlnESXfsLAUHFIPGoxWuR,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWBr)
   vVDzaejqgTlnESXfsLAUHFIPGoxWuh=json.loads(vVDzaejqgTlnESXfsLAUHFIPGoxWOY.text)
   if not('result' in vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']):return vVDzaejqgTlnESXfsLAUHFIPGoxWry,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
   vVDzaejqgTlnESXfsLAUHFIPGoxWrR=vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']['result']
   for vVDzaejqgTlnESXfsLAUHFIPGoxWuc in vVDzaejqgTlnESXfsLAUHFIPGoxWrR:
    vVDzaejqgTlnESXfsLAUHFIPGoxWkC =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['curation_code']
    vVDzaejqgTlnESXfsLAUHFIPGoxWkJ =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['curation_name']
    vVDzaejqgTlnESXfsLAUHFIPGoxWib={'curation_code':vVDzaejqgTlnESXfsLAUHFIPGoxWkC,'curation_name':vVDzaejqgTlnESXfsLAUHFIPGoxWkJ}
    vVDzaejqgTlnESXfsLAUHFIPGoxWry.append(vVDzaejqgTlnESXfsLAUHFIPGoxWib)
  except vVDzaejqgTlnESXfsLAUHFIPGoxWBC as exception:
   vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(exception)
  return vVDzaejqgTlnESXfsLAUHFIPGoxWry,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
 def GetSearchList(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,search_key,page_int,stype):
  vVDzaejqgTlnESXfsLAUHFIPGoxWkN=[]
  vVDzaejqgTlnESXfsLAUHFIPGoxWrC=vVDzaejqgTlnESXfsLAUHFIPGoxWBi
  try:
   vVDzaejqgTlnESXfsLAUHFIPGoxWuN ='/search/getSearch.jsp'
   vVDzaejqgTlnESXfsLAUHFIPGoxWub={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(page_int),'pageSize':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.SCREENCODE,'os':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.OSCODE,'network':vVDzaejqgTlnESXfsLAUHFIPGoxWOk.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetNoCache(2))}
   vVDzaejqgTlnESXfsLAUHFIPGoxWut=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.SEARCH_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuN
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Get',vVDzaejqgTlnESXfsLAUHFIPGoxWut,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,params=vVDzaejqgTlnESXfsLAUHFIPGoxWub,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWBr)
   vVDzaejqgTlnESXfsLAUHFIPGoxWuh=json.loads(vVDzaejqgTlnESXfsLAUHFIPGoxWOY.text)
   if stype=='vod':
    if not('programRsb' in vVDzaejqgTlnESXfsLAUHFIPGoxWuh):return vVDzaejqgTlnESXfsLAUHFIPGoxWkN,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
    vVDzaejqgTlnESXfsLAUHFIPGoxWkR=vVDzaejqgTlnESXfsLAUHFIPGoxWuh['programRsb']['dataList']
    vVDzaejqgTlnESXfsLAUHFIPGoxWkb =vVDzaejqgTlnESXfsLAUHFIPGoxWBk(vVDzaejqgTlnESXfsLAUHFIPGoxWuh['programRsb']['count'])
    for vVDzaejqgTlnESXfsLAUHFIPGoxWuc in vVDzaejqgTlnESXfsLAUHFIPGoxWkR:
     vVDzaejqgTlnESXfsLAUHFIPGoxWit=vVDzaejqgTlnESXfsLAUHFIPGoxWuc['mast_cd']
     vVDzaejqgTlnESXfsLAUHFIPGoxWrQ =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['mast_nm']
     vVDzaejqgTlnESXfsLAUHFIPGoxWrc=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuc['web_url4']
     vVDzaejqgTlnESXfsLAUHFIPGoxWrM =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuc['web_url']
     try:
      vVDzaejqgTlnESXfsLAUHFIPGoxWiu =[]
      vVDzaejqgTlnESXfsLAUHFIPGoxWir=[]
      vVDzaejqgTlnESXfsLAUHFIPGoxWik =[]
      vVDzaejqgTlnESXfsLAUHFIPGoxWki =0
      vVDzaejqgTlnESXfsLAUHFIPGoxWiw =''
      vVDzaejqgTlnESXfsLAUHFIPGoxWiB =''
      vVDzaejqgTlnESXfsLAUHFIPGoxWkO =''
      if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('actor') !='' and vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('actor') !='-':vVDzaejqgTlnESXfsLAUHFIPGoxWiu =vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('actor').split(',')
      if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('director')!='' and vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('director')!='-':vVDzaejqgTlnESXfsLAUHFIPGoxWir=vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('director').split(',')
      if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('cate_nm')!='' and vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('cate_nm')!='-':vVDzaejqgTlnESXfsLAUHFIPGoxWik =vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('cate_nm').split('/')
      if 'targetage' in vVDzaejqgTlnESXfsLAUHFIPGoxWuc:vVDzaejqgTlnESXfsLAUHFIPGoxWiw=vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('targetage')
      if 'broad_dt' in vVDzaejqgTlnESXfsLAUHFIPGoxWuc:
       vVDzaejqgTlnESXfsLAUHFIPGoxWiN=vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('broad_dt')
       vVDzaejqgTlnESXfsLAUHFIPGoxWkO='%s-%s-%s'%(vVDzaejqgTlnESXfsLAUHFIPGoxWiN[:4],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[4:6],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[6:])
       vVDzaejqgTlnESXfsLAUHFIPGoxWiB =vVDzaejqgTlnESXfsLAUHFIPGoxWiN[:4]
     except:
      vVDzaejqgTlnESXfsLAUHFIPGoxWBr
     vVDzaejqgTlnESXfsLAUHFIPGoxWib={'program':vVDzaejqgTlnESXfsLAUHFIPGoxWit,'title':vVDzaejqgTlnESXfsLAUHFIPGoxWrQ,'thumbnail':{'poster':vVDzaejqgTlnESXfsLAUHFIPGoxWrc,'thumb':vVDzaejqgTlnESXfsLAUHFIPGoxWrM,'fanart':vVDzaejqgTlnESXfsLAUHFIPGoxWrM},'synopsis':'','cast':vVDzaejqgTlnESXfsLAUHFIPGoxWiu,'director':vVDzaejqgTlnESXfsLAUHFIPGoxWir,'info_genre':vVDzaejqgTlnESXfsLAUHFIPGoxWik,'duration':vVDzaejqgTlnESXfsLAUHFIPGoxWki,'mpaa':vVDzaejqgTlnESXfsLAUHFIPGoxWiw,'year':vVDzaejqgTlnESXfsLAUHFIPGoxWiB,'aired':vVDzaejqgTlnESXfsLAUHFIPGoxWkO}
     vVDzaejqgTlnESXfsLAUHFIPGoxWkN.append(vVDzaejqgTlnESXfsLAUHFIPGoxWib)
   else:
    if not('vodMVRsb' in vVDzaejqgTlnESXfsLAUHFIPGoxWuh):return vVDzaejqgTlnESXfsLAUHFIPGoxWkN,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
    vVDzaejqgTlnESXfsLAUHFIPGoxWkt=vVDzaejqgTlnESXfsLAUHFIPGoxWuh['vodMVRsb']['dataList']
    vVDzaejqgTlnESXfsLAUHFIPGoxWkb =vVDzaejqgTlnESXfsLAUHFIPGoxWBk(vVDzaejqgTlnESXfsLAUHFIPGoxWuh['vodMVRsb']['count'])
    for vVDzaejqgTlnESXfsLAUHFIPGoxWuc in vVDzaejqgTlnESXfsLAUHFIPGoxWkt:
     vVDzaejqgTlnESXfsLAUHFIPGoxWit=vVDzaejqgTlnESXfsLAUHFIPGoxWuc['mast_cd']
     vVDzaejqgTlnESXfsLAUHFIPGoxWrQ =vVDzaejqgTlnESXfsLAUHFIPGoxWuc['mast_nm'].strip()
     vVDzaejqgTlnESXfsLAUHFIPGoxWrc =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuc['web_url']
     vVDzaejqgTlnESXfsLAUHFIPGoxWrM =vVDzaejqgTlnESXfsLAUHFIPGoxWrc
     vVDzaejqgTlnESXfsLAUHFIPGoxWrp=''
     try:
      vVDzaejqgTlnESXfsLAUHFIPGoxWiu =[]
      vVDzaejqgTlnESXfsLAUHFIPGoxWir=[]
      vVDzaejqgTlnESXfsLAUHFIPGoxWik =[]
      vVDzaejqgTlnESXfsLAUHFIPGoxWki =0
      vVDzaejqgTlnESXfsLAUHFIPGoxWiw =''
      vVDzaejqgTlnESXfsLAUHFIPGoxWiB =''
      vVDzaejqgTlnESXfsLAUHFIPGoxWkO =''
      if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('actor') !='' and vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('actor') !='-':vVDzaejqgTlnESXfsLAUHFIPGoxWiu =vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('actor').split(',')
      if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('director')!='' and vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('director')!='-':vVDzaejqgTlnESXfsLAUHFIPGoxWir=vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('director').split(',')
      if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('cate_nm')!='' and vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('cate_nm')!='-':vVDzaejqgTlnESXfsLAUHFIPGoxWik =vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('cate_nm').split('/')
      if vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('runtime_sec')!='':vVDzaejqgTlnESXfsLAUHFIPGoxWki=vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('runtime_sec')
      if 'grade_nm' in vVDzaejqgTlnESXfsLAUHFIPGoxWuc:vVDzaejqgTlnESXfsLAUHFIPGoxWiw=vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('grade_nm')
      vVDzaejqgTlnESXfsLAUHFIPGoxWiN=vVDzaejqgTlnESXfsLAUHFIPGoxWuc.get('broad_dt')
      if data_str!='':
       vVDzaejqgTlnESXfsLAUHFIPGoxWkO='%s-%s-%s'%(vVDzaejqgTlnESXfsLAUHFIPGoxWiN[:4],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[4:6],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[6:])
       vVDzaejqgTlnESXfsLAUHFIPGoxWiB =vVDzaejqgTlnESXfsLAUHFIPGoxWiN[:4]
     except:
      vVDzaejqgTlnESXfsLAUHFIPGoxWBr
     vVDzaejqgTlnESXfsLAUHFIPGoxWib={'movie':vVDzaejqgTlnESXfsLAUHFIPGoxWit,'title':vVDzaejqgTlnESXfsLAUHFIPGoxWrQ,'thumbnail':{'poster':vVDzaejqgTlnESXfsLAUHFIPGoxWrc,'thumb':vVDzaejqgTlnESXfsLAUHFIPGoxWrM,'fanart':vVDzaejqgTlnESXfsLAUHFIPGoxWrM,'clearlogo':vVDzaejqgTlnESXfsLAUHFIPGoxWrp},'synopsis':'','cast':vVDzaejqgTlnESXfsLAUHFIPGoxWiu,'director':vVDzaejqgTlnESXfsLAUHFIPGoxWir,'info_genre':vVDzaejqgTlnESXfsLAUHFIPGoxWik,'duration':vVDzaejqgTlnESXfsLAUHFIPGoxWki,'mpaa':vVDzaejqgTlnESXfsLAUHFIPGoxWiw,'year':vVDzaejqgTlnESXfsLAUHFIPGoxWiB,'aired':vVDzaejqgTlnESXfsLAUHFIPGoxWkO}
     vVDzaejqgTlnESXfsLAUHFIPGoxWkB=vVDzaejqgTlnESXfsLAUHFIPGoxWBi
     for vVDzaejqgTlnESXfsLAUHFIPGoxWkw in vVDzaejqgTlnESXfsLAUHFIPGoxWuc['bill']:
      if vVDzaejqgTlnESXfsLAUHFIPGoxWkw in vVDzaejqgTlnESXfsLAUHFIPGoxWOk.MOVIE_LITE:
       vVDzaejqgTlnESXfsLAUHFIPGoxWkB=vVDzaejqgTlnESXfsLAUHFIPGoxWBy
       break
     if vVDzaejqgTlnESXfsLAUHFIPGoxWkB==vVDzaejqgTlnESXfsLAUHFIPGoxWBi: 
      vVDzaejqgTlnESXfsLAUHFIPGoxWib['title']=vVDzaejqgTlnESXfsLAUHFIPGoxWib['title']+' [개별구매]'
     vVDzaejqgTlnESXfsLAUHFIPGoxWkN.append(vVDzaejqgTlnESXfsLAUHFIPGoxWib)
   if vVDzaejqgTlnESXfsLAUHFIPGoxWkb>(page_int*vVDzaejqgTlnESXfsLAUHFIPGoxWOk.SEARCH_LIMIT):vVDzaejqgTlnESXfsLAUHFIPGoxWrC=vVDzaejqgTlnESXfsLAUHFIPGoxWBy
  except vVDzaejqgTlnESXfsLAUHFIPGoxWBC as exception:
   vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(exception)
  return vVDzaejqgTlnESXfsLAUHFIPGoxWkN,vVDzaejqgTlnESXfsLAUHFIPGoxWrC
 def GetDeviceList(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,vVDzaejqgTlnESXfsLAUHFIPGoxWuO,vVDzaejqgTlnESXfsLAUHFIPGoxWur):
  vVDzaejqgTlnESXfsLAUHFIPGoxWry=[]
  vVDzaejqgTlnESXfsLAUHFIPGoxWuC='-'
  try:
   vVDzaejqgTlnESXfsLAUHFIPGoxWuN ='/v1/user/device/list'
   vVDzaejqgTlnESXfsLAUHFIPGoxWkh=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.API_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuN
   vVDzaejqgTlnESXfsLAUHFIPGoxWub={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   vVDzaejqgTlnESXfsLAUHFIPGoxWOy=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.makeDefaultCookies(vToken=vVDzaejqgTlnESXfsLAUHFIPGoxWuO,vUserinfo=vVDzaejqgTlnESXfsLAUHFIPGoxWur)
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Get',vVDzaejqgTlnESXfsLAUHFIPGoxWkh,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,params=vVDzaejqgTlnESXfsLAUHFIPGoxWub,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWOy)
   vVDzaejqgTlnESXfsLAUHFIPGoxWuh=json.loads(vVDzaejqgTlnESXfsLAUHFIPGoxWOY.text)
   vVDzaejqgTlnESXfsLAUHFIPGoxWry=vVDzaejqgTlnESXfsLAUHFIPGoxWuh['body']
   for vVDzaejqgTlnESXfsLAUHFIPGoxWuc in vVDzaejqgTlnESXfsLAUHFIPGoxWry:
    if vVDzaejqgTlnESXfsLAUHFIPGoxWuc['model']=='PC':
     vVDzaejqgTlnESXfsLAUHFIPGoxWuC=vVDzaejqgTlnESXfsLAUHFIPGoxWuc['uuid']
  except vVDzaejqgTlnESXfsLAUHFIPGoxWBC as exception:
   vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(exception)
  return vVDzaejqgTlnESXfsLAUHFIPGoxWuC
 def GetProfileToken(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,vVDzaejqgTlnESXfsLAUHFIPGoxWuO,vVDzaejqgTlnESXfsLAUHFIPGoxWur,user_pf):
  vVDzaejqgTlnESXfsLAUHFIPGoxWkQ=[]
  vVDzaejqgTlnESXfsLAUHFIPGoxWkd =''
  vVDzaejqgTlnESXfsLAUHFIPGoxWkM =''
  vVDzaejqgTlnESXfsLAUHFIPGoxWkc='Y'
  vVDzaejqgTlnESXfsLAUHFIPGoxWkp ='N'
  try:
   vVDzaejqgTlnESXfsLAUHFIPGoxWuN ='/profile/select.do'
   vVDzaejqgTlnESXfsLAUHFIPGoxWkh=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.URL_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuN
   vVDzaejqgTlnESXfsLAUHFIPGoxWOy=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.makeDefaultCookies(vToken=vVDzaejqgTlnESXfsLAUHFIPGoxWuO,vUserinfo=vVDzaejqgTlnESXfsLAUHFIPGoxWur)
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Get',vVDzaejqgTlnESXfsLAUHFIPGoxWkh,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,params=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWOy)
   vVDzaejqgTlnESXfsLAUHFIPGoxWkQ =re.findall('data-profile-no="\d+"',vVDzaejqgTlnESXfsLAUHFIPGoxWOY.text)
   for i in vVDzaejqgTlnESXfsLAUHFIPGoxWBw(vVDzaejqgTlnESXfsLAUHFIPGoxWBb(vVDzaejqgTlnESXfsLAUHFIPGoxWkQ)):
    vVDzaejqgTlnESXfsLAUHFIPGoxWkm =vVDzaejqgTlnESXfsLAUHFIPGoxWkQ[i].replace('data-profile-no=','').replace('"','')
    vVDzaejqgTlnESXfsLAUHFIPGoxWkQ[i]=vVDzaejqgTlnESXfsLAUHFIPGoxWkm
   vVDzaejqgTlnESXfsLAUHFIPGoxWkd=vVDzaejqgTlnESXfsLAUHFIPGoxWkQ[user_pf]
  except vVDzaejqgTlnESXfsLAUHFIPGoxWBC as exception:
   vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(exception)
   return vVDzaejqgTlnESXfsLAUHFIPGoxWkM,vVDzaejqgTlnESXfsLAUHFIPGoxWkc,vVDzaejqgTlnESXfsLAUHFIPGoxWkp
  try:
   vVDzaejqgTlnESXfsLAUHFIPGoxWuN ='/profile/api/select.do'
   vVDzaejqgTlnESXfsLAUHFIPGoxWkh=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.URL_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWuN
   vVDzaejqgTlnESXfsLAUHFIPGoxWOy=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.makeDefaultCookies(vToken=vVDzaejqgTlnESXfsLAUHFIPGoxWuO,vUserinfo=vVDzaejqgTlnESXfsLAUHFIPGoxWur)
   vVDzaejqgTlnESXfsLAUHFIPGoxWOm={'profileNo':vVDzaejqgTlnESXfsLAUHFIPGoxWkd}
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Post',vVDzaejqgTlnESXfsLAUHFIPGoxWkh,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWOm,params=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWOy)
   for vVDzaejqgTlnESXfsLAUHFIPGoxWOK in vVDzaejqgTlnESXfsLAUHFIPGoxWOY.cookies:
    if vVDzaejqgTlnESXfsLAUHFIPGoxWOK.name=='_tving_token':
     vVDzaejqgTlnESXfsLAUHFIPGoxWkM=vVDzaejqgTlnESXfsLAUHFIPGoxWOK.value
    elif vVDzaejqgTlnESXfsLAUHFIPGoxWOK.name==vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GLOBAL_COOKIENM['tv_cookiekey']:
     vVDzaejqgTlnESXfsLAUHFIPGoxWkc=vVDzaejqgTlnESXfsLAUHFIPGoxWOK.value
    elif vVDzaejqgTlnESXfsLAUHFIPGoxWOK.name==vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GLOBAL_COOKIENM['tv_lockkey']:
     vVDzaejqgTlnESXfsLAUHFIPGoxWkp=vVDzaejqgTlnESXfsLAUHFIPGoxWOK.value
  except vVDzaejqgTlnESXfsLAUHFIPGoxWBC as exception:
   vVDzaejqgTlnESXfsLAUHFIPGoxWBJ(exception)
  return vVDzaejqgTlnESXfsLAUHFIPGoxWkM,vVDzaejqgTlnESXfsLAUHFIPGoxWkc,vVDzaejqgTlnESXfsLAUHFIPGoxWkp
 def GetBookmarkInfo(vVDzaejqgTlnESXfsLAUHFIPGoxWOk,videoid,vidtype):
  vVDzaejqgTlnESXfsLAUHFIPGoxWkY={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   vVDzaejqgTlnESXfsLAUHFIPGoxWut=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.API_DOMAIN+'/v2/media/program/'+videoid
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetDefaultParams()
   vVDzaejqgTlnESXfsLAUHFIPGoxWub={'pageNo':'1','pageSize':'10','order':'name',}
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR.update(vVDzaejqgTlnESXfsLAUHFIPGoxWub)
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Get',vVDzaejqgTlnESXfsLAUHFIPGoxWut,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,params=vVDzaejqgTlnESXfsLAUHFIPGoxWuR,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWBr)
   vVDzaejqgTlnESXfsLAUHFIPGoxWkK=json.loads(vVDzaejqgTlnESXfsLAUHFIPGoxWOY.text)
   if not('body' in vVDzaejqgTlnESXfsLAUHFIPGoxWkK):return{}
   vVDzaejqgTlnESXfsLAUHFIPGoxWBO=vVDzaejqgTlnESXfsLAUHFIPGoxWkK['body']
   vVDzaejqgTlnESXfsLAUHFIPGoxWrQ=vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('name').get('ko').strip()
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['title'] =vVDzaejqgTlnESXfsLAUHFIPGoxWrQ
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['title']=vVDzaejqgTlnESXfsLAUHFIPGoxWrQ
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['mpaa'] =vVDzaejqgTlnESXfsLAUHFIPGoxWOi.get(vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('grade_code'))
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['plot'] =vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('synopsis').get('ko')
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['year'] =vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('product_year')
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['cast'] =vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('actor')
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['director']=vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('director')
   if vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('category1_name').get('ko')!='':
    vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['genre'].append(vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('category1_name').get('ko'))
   if vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('category2_name').get('ko')!='':
    vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['genre'].append(vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('category2_name').get('ko'))
   vVDzaejqgTlnESXfsLAUHFIPGoxWiN=vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('broad_dt'))
   if vVDzaejqgTlnESXfsLAUHFIPGoxWiN!='0':vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(vVDzaejqgTlnESXfsLAUHFIPGoxWiN[:4],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[4:6],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[6:])
   vVDzaejqgTlnESXfsLAUHFIPGoxWrc =''
   vVDzaejqgTlnESXfsLAUHFIPGoxWrM =''
   vVDzaejqgTlnESXfsLAUHFIPGoxWrp=''
   vVDzaejqgTlnESXfsLAUHFIPGoxWrm =''
   vVDzaejqgTlnESXfsLAUHFIPGoxWrY =''
   for vVDzaejqgTlnESXfsLAUHFIPGoxWiO in vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('image'):
    if vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('code')=='CAIP0900':vVDzaejqgTlnESXfsLAUHFIPGoxWrc =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('url')
    elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('code')=='CAIP0200':vVDzaejqgTlnESXfsLAUHFIPGoxWrM =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('url')
    elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('code')=='CAIP1800':vVDzaejqgTlnESXfsLAUHFIPGoxWrp=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('url')
    elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('code')=='CAIP2000':vVDzaejqgTlnESXfsLAUHFIPGoxWrm =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('url')
    elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('code')=='CAIP1900':vVDzaejqgTlnESXfsLAUHFIPGoxWrY =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('url')
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['thumbnail']['poster']=vVDzaejqgTlnESXfsLAUHFIPGoxWrc
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['thumbnail']['thumb']=vVDzaejqgTlnESXfsLAUHFIPGoxWrM
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['thumbnail']['clearlogo']=vVDzaejqgTlnESXfsLAUHFIPGoxWrp
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['thumbnail']['icon']=vVDzaejqgTlnESXfsLAUHFIPGoxWrm
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['thumbnail']['banner']=vVDzaejqgTlnESXfsLAUHFIPGoxWrY
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['thumbnail']['fanart']=vVDzaejqgTlnESXfsLAUHFIPGoxWrM
  else:
   vVDzaejqgTlnESXfsLAUHFIPGoxWut=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.API_DOMAIN+'/v2a/media/stream/info'
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetDefaultParams()
   vVDzaejqgTlnESXfsLAUHFIPGoxWub={'info':'Y','mediaCode':videoid,'noCache':vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWOk.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':'','uuid':'','deviceInfo':'PC','wm':'Y',}
   vVDzaejqgTlnESXfsLAUHFIPGoxWuR.update(vVDzaejqgTlnESXfsLAUHFIPGoxWub)
   vVDzaejqgTlnESXfsLAUHFIPGoxWOY=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.callRequestCookies('Get',vVDzaejqgTlnESXfsLAUHFIPGoxWut,payload=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,params=vVDzaejqgTlnESXfsLAUHFIPGoxWuR,headers=vVDzaejqgTlnESXfsLAUHFIPGoxWBr,cookies=vVDzaejqgTlnESXfsLAUHFIPGoxWBr)
   vVDzaejqgTlnESXfsLAUHFIPGoxWkK=json.loads(vVDzaejqgTlnESXfsLAUHFIPGoxWOY.text)
   if not('content' in vVDzaejqgTlnESXfsLAUHFIPGoxWkK['body']):return{}
   vVDzaejqgTlnESXfsLAUHFIPGoxWBO=vVDzaejqgTlnESXfsLAUHFIPGoxWkK['body']['content']['info']['movie']
   vVDzaejqgTlnESXfsLAUHFIPGoxWrQ =vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('name').get('ko').strip()
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['title']=vVDzaejqgTlnESXfsLAUHFIPGoxWrQ
   vVDzaejqgTlnESXfsLAUHFIPGoxWrQ +=u' (%s년)'%(vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('product_year'))
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['title'] =vVDzaejqgTlnESXfsLAUHFIPGoxWrQ
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['mpaa'] =vVDzaejqgTlnESXfsLAUHFIPGoxWOi.get(vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('grade_code'))
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['plot'] =vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('story').get('ko')
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['year'] =vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('product_year')
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['studio'] =vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('production')
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['duration']=vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('duration')
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['cast'] =vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('actor')
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['director']=vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('director')
   if vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('category1_name').get('ko')!='':
    vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['genre'].append(vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('category1_name').get('ko'))
   if vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('category2_name').get('ko')!='':
    vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['genre'].append(vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('category2_name').get('ko'))
   vVDzaejqgTlnESXfsLAUHFIPGoxWiN=vVDzaejqgTlnESXfsLAUHFIPGoxWBN(vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('release_date'))
   if vVDzaejqgTlnESXfsLAUHFIPGoxWiN!='0':vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(vVDzaejqgTlnESXfsLAUHFIPGoxWiN[:4],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[4:6],vVDzaejqgTlnESXfsLAUHFIPGoxWiN[6:])
   vVDzaejqgTlnESXfsLAUHFIPGoxWrc=''
   vVDzaejqgTlnESXfsLAUHFIPGoxWrM =''
   vVDzaejqgTlnESXfsLAUHFIPGoxWrp=''
   for vVDzaejqgTlnESXfsLAUHFIPGoxWiO in vVDzaejqgTlnESXfsLAUHFIPGoxWBO.get('image'):
    if vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('code')=='CAIM2100':vVDzaejqgTlnESXfsLAUHFIPGoxWrc =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('url')
    elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('code')=='CAIM0400':vVDzaejqgTlnESXfsLAUHFIPGoxWrM =vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('url')
    elif vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('code')=='CAIM1800':vVDzaejqgTlnESXfsLAUHFIPGoxWrp=vVDzaejqgTlnESXfsLAUHFIPGoxWOk.IMG_DOMAIN+vVDzaejqgTlnESXfsLAUHFIPGoxWiO.get('url')
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['thumbnail']['poster']=vVDzaejqgTlnESXfsLAUHFIPGoxWrc
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['thumbnail']['thumb']=vVDzaejqgTlnESXfsLAUHFIPGoxWrc 
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['thumbnail']['clearlogo']=vVDzaejqgTlnESXfsLAUHFIPGoxWrp
   vVDzaejqgTlnESXfsLAUHFIPGoxWkY['saveinfo']['thumbnail']['fanart']=vVDzaejqgTlnESXfsLAUHFIPGoxWrM
  return vVDzaejqgTlnESXfsLAUHFIPGoxWkY
# Created by pyminifier (https://github.com/liftoff/pyminifier)
