__author__="NightRain"
RVUpqQxMJjhmzBFYvwfnXbNWSePgOH=object
RVUpqQxMJjhmzBFYvwfnXbNWSePgAy=None
RVUpqQxMJjhmzBFYvwfnXbNWSePgAs=int
RVUpqQxMJjhmzBFYvwfnXbNWSePgAi=True
RVUpqQxMJjhmzBFYvwfnXbNWSePgAE=False
RVUpqQxMJjhmzBFYvwfnXbNWSePgAa=type
RVUpqQxMJjhmzBFYvwfnXbNWSePgAL=dict
RVUpqQxMJjhmzBFYvwfnXbNWSePgAO=len
RVUpqQxMJjhmzBFYvwfnXbNWSePgAt=str
RVUpqQxMJjhmzBFYvwfnXbNWSePgAu=range
RVUpqQxMJjhmzBFYvwfnXbNWSePgAo=open
RVUpqQxMJjhmzBFYvwfnXbNWSePgAG=Exception
RVUpqQxMJjhmzBFYvwfnXbNWSePgAI=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
RVUpqQxMJjhmzBFYvwfnXbNWSePgyi=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
RVUpqQxMJjhmzBFYvwfnXbNWSePgyE=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
RVUpqQxMJjhmzBFYvwfnXbNWSePgya=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
RVUpqQxMJjhmzBFYvwfnXbNWSePgyL=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
RVUpqQxMJjhmzBFYvwfnXbNWSePgyO=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
RVUpqQxMJjhmzBFYvwfnXbNWSePgyA=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
RVUpqQxMJjhmzBFYvwfnXbNWSePgyt=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
RVUpqQxMJjhmzBFYvwfnXbNWSePgyu =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
RVUpqQxMJjhmzBFYvwfnXbNWSePgyo=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class RVUpqQxMJjhmzBFYvwfnXbNWSePgys(RVUpqQxMJjhmzBFYvwfnXbNWSePgOH):
 def __init__(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgyI,RVUpqQxMJjhmzBFYvwfnXbNWSePgyr,RVUpqQxMJjhmzBFYvwfnXbNWSePgyd):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_url =RVUpqQxMJjhmzBFYvwfnXbNWSePgyI
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle=RVUpqQxMJjhmzBFYvwfnXbNWSePgyr
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params =RVUpqQxMJjhmzBFYvwfnXbNWSePgyd
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj =vVDzaejqgTlnESXfsLAUHFIPGoxWOu() 
 def addon_noti(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,sting):
  try:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyT=xbmcgui.Dialog()
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyT.notification(__addonname__,sting)
  except:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
 def addon_log(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,string):
  try:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyc=string.encode('utf-8','ignore')
  except:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyc='addonException: addon_log'
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyk=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,RVUpqQxMJjhmzBFYvwfnXbNWSePgyc),level=RVUpqQxMJjhmzBFYvwfnXbNWSePgyk)
 def get_keyboard_input(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgsG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyD=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
  kb=xbmc.Keyboard()
  kb.setHeading(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyD=kb.getText()
  return RVUpqQxMJjhmzBFYvwfnXbNWSePgyD
 def get_settings_login_info(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyC =__addon__.getSetting('id')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyK =__addon__.getSetting('pw')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyH =__addon__.getSetting('login_type')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsy=RVUpqQxMJjhmzBFYvwfnXbNWSePgAs(__addon__.getSetting('selected_profile'))
  return(RVUpqQxMJjhmzBFYvwfnXbNWSePgyC,RVUpqQxMJjhmzBFYvwfnXbNWSePgyK,RVUpqQxMJjhmzBFYvwfnXbNWSePgyH,RVUpqQxMJjhmzBFYvwfnXbNWSePgsy)
 def get_settings_totalsearch(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsi =RVUpqQxMJjhmzBFYvwfnXbNWSePgAi if __addon__.getSetting('local_search')=='true' else RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsE=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi if __addon__.getSetting('local_history')=='true' else RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsa =RVUpqQxMJjhmzBFYvwfnXbNWSePgAi if __addon__.getSetting('total_search')=='true' else RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsL=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi if __addon__.getSetting('total_history')=='true' else RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsO=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi if __addon__.getSetting('menu_bookmark')=='true' else RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
  return(RVUpqQxMJjhmzBFYvwfnXbNWSePgsi,RVUpqQxMJjhmzBFYvwfnXbNWSePgsE,RVUpqQxMJjhmzBFYvwfnXbNWSePgsa,RVUpqQxMJjhmzBFYvwfnXbNWSePgsL,RVUpqQxMJjhmzBFYvwfnXbNWSePgsO)
 def get_settings_makebookmark(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG):
  return RVUpqQxMJjhmzBFYvwfnXbNWSePgAi if __addon__.getSetting('make_bookmark')=='true' else RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
 def get_settings_direct_replay(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsA=RVUpqQxMJjhmzBFYvwfnXbNWSePgAs(__addon__.getSetting('direct_replay'))
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgsA==0:
   return RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
  else:
   return RVUpqQxMJjhmzBFYvwfnXbNWSePgAi
 def set_winCredential(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,credential):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst=xbmcgui.Window(10000)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_LOGINTIME',RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst=xbmcgui.Window(10000)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsu={'tving_token':RVUpqQxMJjhmzBFYvwfnXbNWSePgst.getProperty('TVING_M_TOKEN'),'poc_userinfo':RVUpqQxMJjhmzBFYvwfnXbNWSePgst.getProperty('TVING_M_USERINFO'),'tving_uuid':RVUpqQxMJjhmzBFYvwfnXbNWSePgst.getProperty('TVING_M_UUID'),'tving_maintoken':RVUpqQxMJjhmzBFYvwfnXbNWSePgst.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':RVUpqQxMJjhmzBFYvwfnXbNWSePgst.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':RVUpqQxMJjhmzBFYvwfnXbNWSePgst.getProperty('TVING_M_LOCKKEY')}
  return RVUpqQxMJjhmzBFYvwfnXbNWSePgsu
 def set_winEpisodeOrderby(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgEO):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst=xbmcgui.Window(10000)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_ORDERBY',RVUpqQxMJjhmzBFYvwfnXbNWSePgEO)
 def get_winEpisodeOrderby(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst=xbmcgui.Window(10000)
  return RVUpqQxMJjhmzBFYvwfnXbNWSePgst.getProperty('TVING_M_ORDERBY')
 def add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,label,sublabel='',img='',infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi,params='',isLink=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE,ContextMenu=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgso='%s?%s'%(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_url,urllib.parse.urlencode(params))
  if sublabel:RVUpqQxMJjhmzBFYvwfnXbNWSePgsG='%s < %s >'%(label,sublabel)
  else: RVUpqQxMJjhmzBFYvwfnXbNWSePgsG=label
  if not img:img='DefaultFolder.png'
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsI=xbmcgui.ListItem(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgAa(img)==RVUpqQxMJjhmzBFYvwfnXbNWSePgAL:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsI.setArt(img)
  else:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsI.setArt({'thumb':img,'poster':img})
  if infoLabels:RVUpqQxMJjhmzBFYvwfnXbNWSePgsI.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsI.setProperty('IsPlayable','true')
  if ContextMenu:RVUpqQxMJjhmzBFYvwfnXbNWSePgsI.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,RVUpqQxMJjhmzBFYvwfnXbNWSePgso,RVUpqQxMJjhmzBFYvwfnXbNWSePgsI,isFolder)
 def get_selQuality(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,etype):
  try:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsr='selected_quality'
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsd=[1080,720,480,360]
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsl=RVUpqQxMJjhmzBFYvwfnXbNWSePgAs(__addon__.getSetting(RVUpqQxMJjhmzBFYvwfnXbNWSePgsr))
   return RVUpqQxMJjhmzBFYvwfnXbNWSePgsd[RVUpqQxMJjhmzBFYvwfnXbNWSePgsl]
  except:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
  return 720 
 def dp_Main_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG):
  (RVUpqQxMJjhmzBFYvwfnXbNWSePgsi,RVUpqQxMJjhmzBFYvwfnXbNWSePgsE,RVUpqQxMJjhmzBFYvwfnXbNWSePgsa,RVUpqQxMJjhmzBFYvwfnXbNWSePgsL,RVUpqQxMJjhmzBFYvwfnXbNWSePgsO)=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_settings_totalsearch()
  for RVUpqQxMJjhmzBFYvwfnXbNWSePgsT in RVUpqQxMJjhmzBFYvwfnXbNWSePgyi:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG=RVUpqQxMJjhmzBFYvwfnXbNWSePgsT.get('title')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsc=''
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgsT.get('mode')=='SEARCH_GROUP' and RVUpqQxMJjhmzBFYvwfnXbNWSePgsi ==RVUpqQxMJjhmzBFYvwfnXbNWSePgAE:continue
   elif RVUpqQxMJjhmzBFYvwfnXbNWSePgsT.get('mode')=='SEARCH_HISTORY' and RVUpqQxMJjhmzBFYvwfnXbNWSePgsE==RVUpqQxMJjhmzBFYvwfnXbNWSePgAE:continue
   elif RVUpqQxMJjhmzBFYvwfnXbNWSePgsT.get('mode')=='TOTAL_SEARCH' and RVUpqQxMJjhmzBFYvwfnXbNWSePgsa ==RVUpqQxMJjhmzBFYvwfnXbNWSePgAE:continue
   elif RVUpqQxMJjhmzBFYvwfnXbNWSePgsT.get('mode')=='TOTAL_HISTORY' and RVUpqQxMJjhmzBFYvwfnXbNWSePgsL==RVUpqQxMJjhmzBFYvwfnXbNWSePgAE:continue
   elif RVUpqQxMJjhmzBFYvwfnXbNWSePgsT.get('mode')=='MENU_BOOKMARK' and RVUpqQxMJjhmzBFYvwfnXbNWSePgsO==RVUpqQxMJjhmzBFYvwfnXbNWSePgAE:continue
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':RVUpqQxMJjhmzBFYvwfnXbNWSePgsT.get('mode'),'stype':RVUpqQxMJjhmzBFYvwfnXbNWSePgsT.get('stype'),'orderby':RVUpqQxMJjhmzBFYvwfnXbNWSePgsT.get('orderby'),'ordernm':RVUpqQxMJjhmzBFYvwfnXbNWSePgsT.get('ordernm'),'page':'1'}
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgsT.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsD=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsC =RVUpqQxMJjhmzBFYvwfnXbNWSePgAi
   else:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsD=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsC =RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
   if 'icon' in RVUpqQxMJjhmzBFYvwfnXbNWSePgsT:RVUpqQxMJjhmzBFYvwfnXbNWSePgsc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',RVUpqQxMJjhmzBFYvwfnXbNWSePgsT.get('icon')) 
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel='',img=RVUpqQxMJjhmzBFYvwfnXbNWSePgsc,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgsD,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk,isLink=RVUpqQxMJjhmzBFYvwfnXbNWSePgsC)
  xbmcplugin.endOfDirectory(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle)
 def login_main(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG):
  (RVUpqQxMJjhmzBFYvwfnXbNWSePgsH,RVUpqQxMJjhmzBFYvwfnXbNWSePgiy,RVUpqQxMJjhmzBFYvwfnXbNWSePgis,RVUpqQxMJjhmzBFYvwfnXbNWSePgiE)=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_settings_login_info()
  if not(RVUpqQxMJjhmzBFYvwfnXbNWSePgsH and RVUpqQxMJjhmzBFYvwfnXbNWSePgiy):
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyT=xbmcgui.Dialog()
   RVUpqQxMJjhmzBFYvwfnXbNWSePgia=RVUpqQxMJjhmzBFYvwfnXbNWSePgyT.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgia==RVUpqQxMJjhmzBFYvwfnXbNWSePgAi:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_winEpisodeOrderby()=='':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.set_winEpisodeOrderby('desc')
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.cookiefile_check():return
  RVUpqQxMJjhmzBFYvwfnXbNWSePgiL =RVUpqQxMJjhmzBFYvwfnXbNWSePgAs(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgiO=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgiO==RVUpqQxMJjhmzBFYvwfnXbNWSePgAy or RVUpqQxMJjhmzBFYvwfnXbNWSePgiO=='':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiO=RVUpqQxMJjhmzBFYvwfnXbNWSePgAs('19000101')
  else:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiO=RVUpqQxMJjhmzBFYvwfnXbNWSePgAs(re.sub('-','',RVUpqQxMJjhmzBFYvwfnXbNWSePgiO))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiA=0
   while RVUpqQxMJjhmzBFYvwfnXbNWSePgAi:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgiA+=1
    time.sleep(0.05)
    if RVUpqQxMJjhmzBFYvwfnXbNWSePgiO>=RVUpqQxMJjhmzBFYvwfnXbNWSePgiL:return
    if RVUpqQxMJjhmzBFYvwfnXbNWSePgiA>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgiO>=RVUpqQxMJjhmzBFYvwfnXbNWSePgiL:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.GetCredential(RVUpqQxMJjhmzBFYvwfnXbNWSePgsH,RVUpqQxMJjhmzBFYvwfnXbNWSePgiy,RVUpqQxMJjhmzBFYvwfnXbNWSePgis,RVUpqQxMJjhmzBFYvwfnXbNWSePgiE):
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.set_winCredential(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.LoadCredential())
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgit=RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('stype')
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='live':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiu=RVUpqQxMJjhmzBFYvwfnXbNWSePgyE
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='vod':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiu=RVUpqQxMJjhmzBFYvwfnXbNWSePgyO
  else:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiu=RVUpqQxMJjhmzBFYvwfnXbNWSePgyA
  for RVUpqQxMJjhmzBFYvwfnXbNWSePgio in RVUpqQxMJjhmzBFYvwfnXbNWSePgiu:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG=RVUpqQxMJjhmzBFYvwfnXbNWSePgio.get('title')
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('ordernm')!='-':
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsG+='  ('+RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('ordernm')+')'
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':RVUpqQxMJjhmzBFYvwfnXbNWSePgio.get('mode'),'stype':RVUpqQxMJjhmzBFYvwfnXbNWSePgio.get('stype'),'orderby':RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('orderby'),'ordernm':RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('ordernm'),'page':'1'}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel='',img='',infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgAO(RVUpqQxMJjhmzBFYvwfnXbNWSePgiu)>0:xbmcplugin.endOfDirectory(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle)
 def dp_SubTitle_Group(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG): 
  for RVUpqQxMJjhmzBFYvwfnXbNWSePgio in RVUpqQxMJjhmzBFYvwfnXbNWSePgyt:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG=RVUpqQxMJjhmzBFYvwfnXbNWSePgio.get('title')
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('ordernm')!='-':
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsG+='  ('+RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('ordernm')+')'
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':RVUpqQxMJjhmzBFYvwfnXbNWSePgio.get('mode'),'genreCode':RVUpqQxMJjhmzBFYvwfnXbNWSePgio.get('genreCode'),'stype':RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('stype'),'orderby':RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('orderby'),'page':'1'}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel='',img='',infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgAO(RVUpqQxMJjhmzBFYvwfnXbNWSePgyt)>0:xbmcplugin.endOfDirectory(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle)
 def dp_LiveChannel_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.SaveCredential(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_winCredential())
  RVUpqQxMJjhmzBFYvwfnXbNWSePgit =RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('stype')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgiI =RVUpqQxMJjhmzBFYvwfnXbNWSePgAs(RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('page'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgir,RVUpqQxMJjhmzBFYvwfnXbNWSePgid=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.GetLiveChannelList(RVUpqQxMJjhmzBFYvwfnXbNWSePgit,RVUpqQxMJjhmzBFYvwfnXbNWSePgiI)
  for RVUpqQxMJjhmzBFYvwfnXbNWSePgil in RVUpqQxMJjhmzBFYvwfnXbNWSePgir:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG =RVUpqQxMJjhmzBFYvwfnXbNWSePgil.get('title')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsK =RVUpqQxMJjhmzBFYvwfnXbNWSePgil.get('channel')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiT =RVUpqQxMJjhmzBFYvwfnXbNWSePgil.get('thumbnail')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgic =RVUpqQxMJjhmzBFYvwfnXbNWSePgil.get('synopsis')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgik =RVUpqQxMJjhmzBFYvwfnXbNWSePgil.get('channelepg')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiD =RVUpqQxMJjhmzBFYvwfnXbNWSePgil.get('cast')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiC =RVUpqQxMJjhmzBFYvwfnXbNWSePgil.get('director')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiK =RVUpqQxMJjhmzBFYvwfnXbNWSePgil.get('info_genre')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiH =RVUpqQxMJjhmzBFYvwfnXbNWSePgil.get('year')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEy =RVUpqQxMJjhmzBFYvwfnXbNWSePgil.get('mpaa')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEs =RVUpqQxMJjhmzBFYvwfnXbNWSePgil.get('premiered')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEi={'mediatype':'episode','title':RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,'studio':RVUpqQxMJjhmzBFYvwfnXbNWSePgsK,'cast':RVUpqQxMJjhmzBFYvwfnXbNWSePgiD,'director':RVUpqQxMJjhmzBFYvwfnXbNWSePgiC,'genre':RVUpqQxMJjhmzBFYvwfnXbNWSePgiK,'plot':'%s\n%s\n%s\n\n%s'%(RVUpqQxMJjhmzBFYvwfnXbNWSePgsK,RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,RVUpqQxMJjhmzBFYvwfnXbNWSePgik,RVUpqQxMJjhmzBFYvwfnXbNWSePgic),'year':RVUpqQxMJjhmzBFYvwfnXbNWSePgiH,'mpaa':RVUpqQxMJjhmzBFYvwfnXbNWSePgEy,'premiered':RVUpqQxMJjhmzBFYvwfnXbNWSePgEs}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':'LIVE','mediacode':RVUpqQxMJjhmzBFYvwfnXbNWSePgil.get('mediacode'),'stype':RVUpqQxMJjhmzBFYvwfnXbNWSePgit}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsK,sublabel=RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,img=RVUpqQxMJjhmzBFYvwfnXbNWSePgiT,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgEi,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgid:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['mode']='CHANNEL' 
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['stype']=RVUpqQxMJjhmzBFYvwfnXbNWSePgit 
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['page']=RVUpqQxMJjhmzBFYvwfnXbNWSePgAt(RVUpqQxMJjhmzBFYvwfnXbNWSePgiI+1)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG='[B]%s >>[/B]'%'다음 페이지'
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEa=RVUpqQxMJjhmzBFYvwfnXbNWSePgAt(RVUpqQxMJjhmzBFYvwfnXbNWSePgiI+1)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel=RVUpqQxMJjhmzBFYvwfnXbNWSePgEa,img=RVUpqQxMJjhmzBFYvwfnXbNWSePgsc,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgAO(RVUpqQxMJjhmzBFYvwfnXbNWSePgir)>0:xbmcplugin.endOfDirectory(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,cacheToDisc=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE)
 def dp_Program_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.SaveCredential(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_winCredential())
  RVUpqQxMJjhmzBFYvwfnXbNWSePgEL =RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('stype')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgEO =RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('orderby')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgiI =RVUpqQxMJjhmzBFYvwfnXbNWSePgAs(RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('page'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgEA=RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('genreCode')
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgEA==RVUpqQxMJjhmzBFYvwfnXbNWSePgAy:RVUpqQxMJjhmzBFYvwfnXbNWSePgEA='all'
  RVUpqQxMJjhmzBFYvwfnXbNWSePgEt,RVUpqQxMJjhmzBFYvwfnXbNWSePgid=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.GetProgramList(RVUpqQxMJjhmzBFYvwfnXbNWSePgEL,RVUpqQxMJjhmzBFYvwfnXbNWSePgEO,RVUpqQxMJjhmzBFYvwfnXbNWSePgiI,RVUpqQxMJjhmzBFYvwfnXbNWSePgEA)
  for RVUpqQxMJjhmzBFYvwfnXbNWSePgEu in RVUpqQxMJjhmzBFYvwfnXbNWSePgEt:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG =RVUpqQxMJjhmzBFYvwfnXbNWSePgEu.get('title')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiT =RVUpqQxMJjhmzBFYvwfnXbNWSePgEu.get('thumbnail')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgic =RVUpqQxMJjhmzBFYvwfnXbNWSePgEu.get('synopsis')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEo =RVUpqQxMJjhmzBFYvwfnXbNWSePgEu.get('channel')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiD =RVUpqQxMJjhmzBFYvwfnXbNWSePgEu.get('cast')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiC =RVUpqQxMJjhmzBFYvwfnXbNWSePgEu.get('director')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiK=RVUpqQxMJjhmzBFYvwfnXbNWSePgEu.get('info_genre')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiH =RVUpqQxMJjhmzBFYvwfnXbNWSePgEu.get('year')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEs =RVUpqQxMJjhmzBFYvwfnXbNWSePgEu.get('premiered')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEy =RVUpqQxMJjhmzBFYvwfnXbNWSePgEu.get('mpaa')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEi={'mediatype':'tvshow','title':RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,'studio':RVUpqQxMJjhmzBFYvwfnXbNWSePgEo,'cast':RVUpqQxMJjhmzBFYvwfnXbNWSePgiD,'director':RVUpqQxMJjhmzBFYvwfnXbNWSePgiC,'genre':RVUpqQxMJjhmzBFYvwfnXbNWSePgiK,'year':RVUpqQxMJjhmzBFYvwfnXbNWSePgiH,'premiered':RVUpqQxMJjhmzBFYvwfnXbNWSePgEs,'mpaa':RVUpqQxMJjhmzBFYvwfnXbNWSePgEy,'plot':RVUpqQxMJjhmzBFYvwfnXbNWSePgic}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':'EPISODE','programcode':RVUpqQxMJjhmzBFYvwfnXbNWSePgEu.get('program'),'page':'1'}
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_settings_makebookmark():
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEG={'videoid':RVUpqQxMJjhmzBFYvwfnXbNWSePgEu.get('program'),'vidtype':'tvshow','vtitle':RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,'vsubtitle':RVUpqQxMJjhmzBFYvwfnXbNWSePgEo,}
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEI=json.dumps(RVUpqQxMJjhmzBFYvwfnXbNWSePgEG)
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEI=urllib.parse.quote(RVUpqQxMJjhmzBFYvwfnXbNWSePgEI)
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEr='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(RVUpqQxMJjhmzBFYvwfnXbNWSePgEI)
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEd=[('찜한 영상에 추가 (통합 bookmark mini)',RVUpqQxMJjhmzBFYvwfnXbNWSePgEr)]
   else:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEd=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel=RVUpqQxMJjhmzBFYvwfnXbNWSePgEo,img=RVUpqQxMJjhmzBFYvwfnXbNWSePgiT,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgEi,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk,ContextMenu=RVUpqQxMJjhmzBFYvwfnXbNWSePgEd)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgid:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['mode'] ='PROGRAM' 
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['stype'] =RVUpqQxMJjhmzBFYvwfnXbNWSePgEL
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['orderby'] =RVUpqQxMJjhmzBFYvwfnXbNWSePgEO
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['page'] =RVUpqQxMJjhmzBFYvwfnXbNWSePgAt(RVUpqQxMJjhmzBFYvwfnXbNWSePgiI+1)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['genreCode']=RVUpqQxMJjhmzBFYvwfnXbNWSePgEA 
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG='[B]%s >>[/B]'%'다음 페이지'
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEa=RVUpqQxMJjhmzBFYvwfnXbNWSePgAt(RVUpqQxMJjhmzBFYvwfnXbNWSePgiI+1)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel=RVUpqQxMJjhmzBFYvwfnXbNWSePgEa,img=RVUpqQxMJjhmzBFYvwfnXbNWSePgsc,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk)
  xbmcplugin.setContent(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,'tvshows')
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgAO(RVUpqQxMJjhmzBFYvwfnXbNWSePgEt)>0:xbmcplugin.endOfDirectory(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,cacheToDisc=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE)
 def dp_Episode_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.SaveCredential(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_winCredential())
  RVUpqQxMJjhmzBFYvwfnXbNWSePgEl=RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('programcode')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgiI =RVUpqQxMJjhmzBFYvwfnXbNWSePgAs(RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('page'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgET,RVUpqQxMJjhmzBFYvwfnXbNWSePgid,RVUpqQxMJjhmzBFYvwfnXbNWSePgEc=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.GetEpisodeList(RVUpqQxMJjhmzBFYvwfnXbNWSePgEl,RVUpqQxMJjhmzBFYvwfnXbNWSePgiI,orderby=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_winEpisodeOrderby())
  for RVUpqQxMJjhmzBFYvwfnXbNWSePgEk in RVUpqQxMJjhmzBFYvwfnXbNWSePgET:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG =RVUpqQxMJjhmzBFYvwfnXbNWSePgEk.get('title')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEa =RVUpqQxMJjhmzBFYvwfnXbNWSePgEk.get('subtitle')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiT =RVUpqQxMJjhmzBFYvwfnXbNWSePgEk.get('thumbnail')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgic =RVUpqQxMJjhmzBFYvwfnXbNWSePgEk.get('synopsis')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgED=RVUpqQxMJjhmzBFYvwfnXbNWSePgEk.get('info_title')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEC =RVUpqQxMJjhmzBFYvwfnXbNWSePgEk.get('aired')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEK =RVUpqQxMJjhmzBFYvwfnXbNWSePgEk.get('studio')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEH =RVUpqQxMJjhmzBFYvwfnXbNWSePgEk.get('frequency')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEi={'mediatype':'episode','title':RVUpqQxMJjhmzBFYvwfnXbNWSePgED,'aired':RVUpqQxMJjhmzBFYvwfnXbNWSePgEC,'studio':RVUpqQxMJjhmzBFYvwfnXbNWSePgEK,'episode':RVUpqQxMJjhmzBFYvwfnXbNWSePgEH,'plot':RVUpqQxMJjhmzBFYvwfnXbNWSePgic}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':'VOD','mediacode':RVUpqQxMJjhmzBFYvwfnXbNWSePgEk.get('episode'),'stype':'vod','programcode':RVUpqQxMJjhmzBFYvwfnXbNWSePgEl,'title':RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,'thumbnail':RVUpqQxMJjhmzBFYvwfnXbNWSePgiT}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel=RVUpqQxMJjhmzBFYvwfnXbNWSePgEa,img=RVUpqQxMJjhmzBFYvwfnXbNWSePgiT,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgEi,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgiI==1:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEi={'plot':'정렬순서를 변경합니다.'}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['mode'] ='ORDER_BY' 
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_winEpisodeOrderby()=='desc':
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsG='정렬순서변경 : 최신화부터 -> 1회부터'
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['orderby']='asc'
   else:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsG='정렬순서변경 : 1회부터 -> 최신화부터'
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['orderby']='desc'
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel='',img=RVUpqQxMJjhmzBFYvwfnXbNWSePgsc,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgEi,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk,isLink=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgid:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['mode'] ='EPISODE' 
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['programcode']=RVUpqQxMJjhmzBFYvwfnXbNWSePgEl
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['page'] =RVUpqQxMJjhmzBFYvwfnXbNWSePgAt(RVUpqQxMJjhmzBFYvwfnXbNWSePgiI+1)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG='[B]%s >>[/B]'%'다음 페이지'
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEa=RVUpqQxMJjhmzBFYvwfnXbNWSePgAt(RVUpqQxMJjhmzBFYvwfnXbNWSePgiI+1)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel=RVUpqQxMJjhmzBFYvwfnXbNWSePgEa,img=RVUpqQxMJjhmzBFYvwfnXbNWSePgsc,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk)
  xbmcplugin.setContent(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,'episodes')
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgAO(RVUpqQxMJjhmzBFYvwfnXbNWSePgET)>0:xbmcplugin.endOfDirectory(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,cacheToDisc=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi)
 def dp_setEpOrderby(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgEO =RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('orderby')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.set_winEpisodeOrderby(RVUpqQxMJjhmzBFYvwfnXbNWSePgEO)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.SaveCredential(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_winCredential())
  RVUpqQxMJjhmzBFYvwfnXbNWSePgEL =RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('stype')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgEO =RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('orderby')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgiI=RVUpqQxMJjhmzBFYvwfnXbNWSePgAs(RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('page'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgay,RVUpqQxMJjhmzBFYvwfnXbNWSePgid=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.GetMovieList(RVUpqQxMJjhmzBFYvwfnXbNWSePgEL,RVUpqQxMJjhmzBFYvwfnXbNWSePgEO,RVUpqQxMJjhmzBFYvwfnXbNWSePgiI)
  for RVUpqQxMJjhmzBFYvwfnXbNWSePgas in RVUpqQxMJjhmzBFYvwfnXbNWSePgay:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG =RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('title')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiT =RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('thumbnail')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgic =RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('synopsis')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgED =RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('info_title')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiH =RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('year')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiD =RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('cast')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiC =RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('director')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiK =RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('info_genre')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgai =RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('duration')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEs =RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('premiered')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEK =RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('studio')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEy =RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('mpaa')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEi={'mediatype':'movie','title':RVUpqQxMJjhmzBFYvwfnXbNWSePgED,'year':RVUpqQxMJjhmzBFYvwfnXbNWSePgiH,'cast':RVUpqQxMJjhmzBFYvwfnXbNWSePgiD,'director':RVUpqQxMJjhmzBFYvwfnXbNWSePgiC,'genre':RVUpqQxMJjhmzBFYvwfnXbNWSePgiK,'duration':RVUpqQxMJjhmzBFYvwfnXbNWSePgai,'premiered':RVUpqQxMJjhmzBFYvwfnXbNWSePgEs,'studio':RVUpqQxMJjhmzBFYvwfnXbNWSePgEK,'mpaa':RVUpqQxMJjhmzBFYvwfnXbNWSePgEy,'plot':RVUpqQxMJjhmzBFYvwfnXbNWSePgic}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':'MOVIE','mediacode':RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('moviecode'),'stype':'movie','title':RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,'thumbnail':RVUpqQxMJjhmzBFYvwfnXbNWSePgiT}
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_settings_makebookmark():
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEG={'videoid':RVUpqQxMJjhmzBFYvwfnXbNWSePgas.get('moviecode'),'vidtype':'movie','vtitle':RVUpqQxMJjhmzBFYvwfnXbNWSePgED,'vsubtitle':'',}
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEI=json.dumps(RVUpqQxMJjhmzBFYvwfnXbNWSePgEG)
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEI=urllib.parse.quote(RVUpqQxMJjhmzBFYvwfnXbNWSePgEI)
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEr='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(RVUpqQxMJjhmzBFYvwfnXbNWSePgEI)
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEd=[('찜한 영상에 추가 (통합 bookmark mini)',RVUpqQxMJjhmzBFYvwfnXbNWSePgEr)]
   else:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEd=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel='',img=RVUpqQxMJjhmzBFYvwfnXbNWSePgiT,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgEi,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk,ContextMenu=RVUpqQxMJjhmzBFYvwfnXbNWSePgEd)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgid:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['mode'] ='MOVIE_SUB' 
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['orderby']=RVUpqQxMJjhmzBFYvwfnXbNWSePgEO
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['stype'] =RVUpqQxMJjhmzBFYvwfnXbNWSePgEL
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['page'] =RVUpqQxMJjhmzBFYvwfnXbNWSePgAt(RVUpqQxMJjhmzBFYvwfnXbNWSePgiI+1)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG='[B]%s >>[/B]'%'다음 페이지'
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEa=RVUpqQxMJjhmzBFYvwfnXbNWSePgAt(RVUpqQxMJjhmzBFYvwfnXbNWSePgiI+1)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel=RVUpqQxMJjhmzBFYvwfnXbNWSePgEa,img=RVUpqQxMJjhmzBFYvwfnXbNWSePgsc,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk)
  xbmcplugin.setContent(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,'movies')
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgAO(RVUpqQxMJjhmzBFYvwfnXbNWSePgay)>0:xbmcplugin.endOfDirectory(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,cacheToDisc=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE)
 def dp_Set_Bookmark(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgaE=urllib.parse.unquote(RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('bm_param'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgaE=json.loads(RVUpqQxMJjhmzBFYvwfnXbNWSePgaE)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgaL =RVUpqQxMJjhmzBFYvwfnXbNWSePgaE.get('videoid')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgaO =RVUpqQxMJjhmzBFYvwfnXbNWSePgaE.get('vidtype')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgaA =RVUpqQxMJjhmzBFYvwfnXbNWSePgaE.get('vtitle')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgat =RVUpqQxMJjhmzBFYvwfnXbNWSePgaE.get('vsubtitle')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyT=xbmcgui.Dialog()
  RVUpqQxMJjhmzBFYvwfnXbNWSePgia=RVUpqQxMJjhmzBFYvwfnXbNWSePgyT.yesno(__language__(30913).encode('utf8'),RVUpqQxMJjhmzBFYvwfnXbNWSePgaA+' \n\n'+__language__(30914))
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgia==RVUpqQxMJjhmzBFYvwfnXbNWSePgAE:return
  RVUpqQxMJjhmzBFYvwfnXbNWSePgau=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.GetBookmarkInfo(RVUpqQxMJjhmzBFYvwfnXbNWSePgaL,RVUpqQxMJjhmzBFYvwfnXbNWSePgaO)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgat!='':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgau['saveinfo']['subtitle']=RVUpqQxMJjhmzBFYvwfnXbNWSePgat 
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgaO=='tvshow':RVUpqQxMJjhmzBFYvwfnXbNWSePgau['saveinfo']['infoLabels']['studio']=RVUpqQxMJjhmzBFYvwfnXbNWSePgat 
  RVUpqQxMJjhmzBFYvwfnXbNWSePgao=json.dumps(RVUpqQxMJjhmzBFYvwfnXbNWSePgau)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgao=urllib.parse.quote(RVUpqQxMJjhmzBFYvwfnXbNWSePgao)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgEr ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(RVUpqQxMJjhmzBFYvwfnXbNWSePgao)
  xbmc.executebuiltin(RVUpqQxMJjhmzBFYvwfnXbNWSePgEr)
 def dp_Search_Group(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  if 'search_key' in RVUpqQxMJjhmzBFYvwfnXbNWSePgiG:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgaG=RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('search_key')
  else:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgaG=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not RVUpqQxMJjhmzBFYvwfnXbNWSePgaG:
    return
  for RVUpqQxMJjhmzBFYvwfnXbNWSePgio in RVUpqQxMJjhmzBFYvwfnXbNWSePgyL:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgaI =RVUpqQxMJjhmzBFYvwfnXbNWSePgio.get('mode')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgit=RVUpqQxMJjhmzBFYvwfnXbNWSePgio.get('stype')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG=RVUpqQxMJjhmzBFYvwfnXbNWSePgio.get('title')
   (RVUpqQxMJjhmzBFYvwfnXbNWSePgar,RVUpqQxMJjhmzBFYvwfnXbNWSePgid)=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.GetSearchList(RVUpqQxMJjhmzBFYvwfnXbNWSePgaG,1,RVUpqQxMJjhmzBFYvwfnXbNWSePgit)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgad={'plot':'검색어 : '+RVUpqQxMJjhmzBFYvwfnXbNWSePgaG+'\n\n'+RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.Search_FreeList(RVUpqQxMJjhmzBFYvwfnXbNWSePgar)}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':RVUpqQxMJjhmzBFYvwfnXbNWSePgaI,'stype':RVUpqQxMJjhmzBFYvwfnXbNWSePgit,'search_key':RVUpqQxMJjhmzBFYvwfnXbNWSePgaG,'page':'1',}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel='',img='',infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgad,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgAO(RVUpqQxMJjhmzBFYvwfnXbNWSePgyL)>0:xbmcplugin.endOfDirectory(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,cacheToDisc=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.Save_Searched_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgaG)
 def Search_FreeList(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgLs):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgal=''
  RVUpqQxMJjhmzBFYvwfnXbNWSePgaT=7
  try:
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgAO(RVUpqQxMJjhmzBFYvwfnXbNWSePgLs)==0:return '검색결과 없음'
   for i in RVUpqQxMJjhmzBFYvwfnXbNWSePgAu(RVUpqQxMJjhmzBFYvwfnXbNWSePgAO(RVUpqQxMJjhmzBFYvwfnXbNWSePgLs)):
    if i>=RVUpqQxMJjhmzBFYvwfnXbNWSePgaT:
     RVUpqQxMJjhmzBFYvwfnXbNWSePgal=RVUpqQxMJjhmzBFYvwfnXbNWSePgal+'...'
     break
    RVUpqQxMJjhmzBFYvwfnXbNWSePgal=RVUpqQxMJjhmzBFYvwfnXbNWSePgal+RVUpqQxMJjhmzBFYvwfnXbNWSePgLs[i]['title']+'\n'
  except:
   return ''
  return RVUpqQxMJjhmzBFYvwfnXbNWSePgal
 def dp_Search_History(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgac=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.Load_List_File('search')
  for RVUpqQxMJjhmzBFYvwfnXbNWSePgak in RVUpqQxMJjhmzBFYvwfnXbNWSePgac:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgaD=RVUpqQxMJjhmzBFYvwfnXbNWSePgAL(urllib.parse.parse_qsl(RVUpqQxMJjhmzBFYvwfnXbNWSePgak))
   RVUpqQxMJjhmzBFYvwfnXbNWSePgaC=RVUpqQxMJjhmzBFYvwfnXbNWSePgaD.get('skey').strip()
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':'SEARCH_GROUP','search_key':RVUpqQxMJjhmzBFYvwfnXbNWSePgaC,}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgaK={'mode':'SEARCH_REMOVE','stype':'ONE','skey':RVUpqQxMJjhmzBFYvwfnXbNWSePgaC,}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgaH=urllib.parse.urlencode(RVUpqQxMJjhmzBFYvwfnXbNWSePgaK)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEd=[('선택된 검색어 ( %s ) 삭제'%(RVUpqQxMJjhmzBFYvwfnXbNWSePgaC),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(RVUpqQxMJjhmzBFYvwfnXbNWSePgaH))]
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgaC,sublabel='',img=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk,ContextMenu=RVUpqQxMJjhmzBFYvwfnXbNWSePgEd)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgEi={'plot':'검색목록 전체를 삭제합니다.'}
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsG='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel='',img=RVUpqQxMJjhmzBFYvwfnXbNWSePgsc,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgEi,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk,isLink=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi)
  xbmcplugin.endOfDirectory(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,cacheToDisc=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE)
 def dp_Search_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.SaveCredential(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_winCredential())
  RVUpqQxMJjhmzBFYvwfnXbNWSePgiI =RVUpqQxMJjhmzBFYvwfnXbNWSePgAs(RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('page'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgit =RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('stype')
  if 'search_key' in RVUpqQxMJjhmzBFYvwfnXbNWSePgiG:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgaG=RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('search_key')
  else:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgaG=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not RVUpqQxMJjhmzBFYvwfnXbNWSePgaG:
    xbmcplugin.endOfDirectory(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle)
    return
  RVUpqQxMJjhmzBFYvwfnXbNWSePgar,RVUpqQxMJjhmzBFYvwfnXbNWSePgid=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.GetSearchList(RVUpqQxMJjhmzBFYvwfnXbNWSePgaG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiI,RVUpqQxMJjhmzBFYvwfnXbNWSePgit)
  for RVUpqQxMJjhmzBFYvwfnXbNWSePgLs in RVUpqQxMJjhmzBFYvwfnXbNWSePgar:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG =RVUpqQxMJjhmzBFYvwfnXbNWSePgLs.get('title')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiT =RVUpqQxMJjhmzBFYvwfnXbNWSePgLs.get('thumbnail')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgic =RVUpqQxMJjhmzBFYvwfnXbNWSePgLs.get('synopsis')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLi =RVUpqQxMJjhmzBFYvwfnXbNWSePgLs.get('program')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiD =RVUpqQxMJjhmzBFYvwfnXbNWSePgLs.get('cast')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiC =RVUpqQxMJjhmzBFYvwfnXbNWSePgLs.get('director')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiK=RVUpqQxMJjhmzBFYvwfnXbNWSePgLs.get('info_genre')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgai =RVUpqQxMJjhmzBFYvwfnXbNWSePgLs.get('duration')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEy =RVUpqQxMJjhmzBFYvwfnXbNWSePgLs.get('mpaa')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgiH =RVUpqQxMJjhmzBFYvwfnXbNWSePgLs.get('year')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEC =RVUpqQxMJjhmzBFYvwfnXbNWSePgLs.get('aired')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEi={'mediatype':'tvshow' if RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='vod' else 'movie','title':RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,'cast':RVUpqQxMJjhmzBFYvwfnXbNWSePgiD,'director':RVUpqQxMJjhmzBFYvwfnXbNWSePgiC,'genre':RVUpqQxMJjhmzBFYvwfnXbNWSePgiK,'duration':RVUpqQxMJjhmzBFYvwfnXbNWSePgai,'mpaa':RVUpqQxMJjhmzBFYvwfnXbNWSePgEy,'year':RVUpqQxMJjhmzBFYvwfnXbNWSePgiH,'aired':RVUpqQxMJjhmzBFYvwfnXbNWSePgEC,'plot':'%s\n\n%s'%(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,RVUpqQxMJjhmzBFYvwfnXbNWSePgic)}
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='vod':
    RVUpqQxMJjhmzBFYvwfnXbNWSePgaL=RVUpqQxMJjhmzBFYvwfnXbNWSePgLs.get('program')
    RVUpqQxMJjhmzBFYvwfnXbNWSePgaO='tvshow'
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':'EPISODE','programcode':RVUpqQxMJjhmzBFYvwfnXbNWSePgaL,'page':'1',}
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsD=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi
   else:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgaL=RVUpqQxMJjhmzBFYvwfnXbNWSePgLs.get('movie')
    RVUpqQxMJjhmzBFYvwfnXbNWSePgaO='movie'
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':'MOVIE','mediacode':RVUpqQxMJjhmzBFYvwfnXbNWSePgaL,'stype':'movie','title':RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,'thumbnail':RVUpqQxMJjhmzBFYvwfnXbNWSePgiT,}
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsD=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_settings_makebookmark():
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEG={'videoid':RVUpqQxMJjhmzBFYvwfnXbNWSePgaL,'vidtype':RVUpqQxMJjhmzBFYvwfnXbNWSePgaO,'vtitle':RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,'vsubtitle':'',}
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEI=json.dumps(RVUpqQxMJjhmzBFYvwfnXbNWSePgEG)
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEI=urllib.parse.quote(RVUpqQxMJjhmzBFYvwfnXbNWSePgEI)
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEr='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(RVUpqQxMJjhmzBFYvwfnXbNWSePgEI)
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEd=[('찜한 영상에 추가 (통합 bookmark mini)',RVUpqQxMJjhmzBFYvwfnXbNWSePgEr)]
   else:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEd=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel='',img=RVUpqQxMJjhmzBFYvwfnXbNWSePgiT,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgEi,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgsD,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk,isLink=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE,ContextMenu=RVUpqQxMJjhmzBFYvwfnXbNWSePgEd)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgid:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['mode'] ='SEARCH' 
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['search_key']=RVUpqQxMJjhmzBFYvwfnXbNWSePgaG
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk['page'] =RVUpqQxMJjhmzBFYvwfnXbNWSePgAt(RVUpqQxMJjhmzBFYvwfnXbNWSePgiI+1)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG='[B]%s >>[/B]'%'다음 페이지'
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEa=RVUpqQxMJjhmzBFYvwfnXbNWSePgAt(RVUpqQxMJjhmzBFYvwfnXbNWSePgiI+1)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel=RVUpqQxMJjhmzBFYvwfnXbNWSePgEa,img=RVUpqQxMJjhmzBFYvwfnXbNWSePgsc,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='movie':xbmcplugin.setContent(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,'movies')
  else:xbmcplugin.setContent(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,cacheToDisc=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE)
 def Delete_List_File(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgit,skey='-'):
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='ALL':
   try:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgLE=RVUpqQxMJjhmzBFYvwfnXbNWSePgyo
    fp=RVUpqQxMJjhmzBFYvwfnXbNWSePgAo(RVUpqQxMJjhmzBFYvwfnXbNWSePgLE,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='ONE':
   try:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgLE=RVUpqQxMJjhmzBFYvwfnXbNWSePgyo
    RVUpqQxMJjhmzBFYvwfnXbNWSePgLa=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.Load_List_File('search') 
    fp=RVUpqQxMJjhmzBFYvwfnXbNWSePgAo(RVUpqQxMJjhmzBFYvwfnXbNWSePgLE,'w',-1,'utf-8')
    for RVUpqQxMJjhmzBFYvwfnXbNWSePgLO in RVUpqQxMJjhmzBFYvwfnXbNWSePgLa:
     RVUpqQxMJjhmzBFYvwfnXbNWSePgLA=RVUpqQxMJjhmzBFYvwfnXbNWSePgAL(urllib.parse.parse_qsl(RVUpqQxMJjhmzBFYvwfnXbNWSePgLO))
     RVUpqQxMJjhmzBFYvwfnXbNWSePgLt=RVUpqQxMJjhmzBFYvwfnXbNWSePgLA.get('skey').strip()
     if skey!=RVUpqQxMJjhmzBFYvwfnXbNWSePgLt:
      fp.write(RVUpqQxMJjhmzBFYvwfnXbNWSePgLO)
    fp.close()
   except:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgit in['vod','movie']:
   try:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgLE=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%RVUpqQxMJjhmzBFYvwfnXbNWSePgit))
    fp=RVUpqQxMJjhmzBFYvwfnXbNWSePgAo(RVUpqQxMJjhmzBFYvwfnXbNWSePgLE,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
 def dp_Listfile_Delete(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgit=RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('stype')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgaC =RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('skey')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyT=xbmcgui.Dialog()
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='ALL':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgia=RVUpqQxMJjhmzBFYvwfnXbNWSePgyT.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='ONE':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgia=RVUpqQxMJjhmzBFYvwfnXbNWSePgyT.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgit in['vod','movie']:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgia=RVUpqQxMJjhmzBFYvwfnXbNWSePgyT.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgia==RVUpqQxMJjhmzBFYvwfnXbNWSePgAE:sys.exit()
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.Delete_List_File(RVUpqQxMJjhmzBFYvwfnXbNWSePgit,skey=RVUpqQxMJjhmzBFYvwfnXbNWSePgaC)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgit): 
  try:
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='search':
    RVUpqQxMJjhmzBFYvwfnXbNWSePgLE=RVUpqQxMJjhmzBFYvwfnXbNWSePgyo
   elif RVUpqQxMJjhmzBFYvwfnXbNWSePgit in['vod','movie']:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgLE=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%RVUpqQxMJjhmzBFYvwfnXbNWSePgit))
   else:
    return[]
   fp=RVUpqQxMJjhmzBFYvwfnXbNWSePgAo(RVUpqQxMJjhmzBFYvwfnXbNWSePgLE,'r',-1,'utf-8')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLu=fp.readlines()
   fp.close()
  except:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLu=[]
  return RVUpqQxMJjhmzBFYvwfnXbNWSePgLu
 def Save_Watched_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgit,RVUpqQxMJjhmzBFYvwfnXbNWSePgyd):
  try:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLo=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%RVUpqQxMJjhmzBFYvwfnXbNWSePgit))
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLa=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.Load_List_File(RVUpqQxMJjhmzBFYvwfnXbNWSePgit) 
   fp=RVUpqQxMJjhmzBFYvwfnXbNWSePgAo(RVUpqQxMJjhmzBFYvwfnXbNWSePgLo,'w',-1,'utf-8')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLG=urllib.parse.urlencode(RVUpqQxMJjhmzBFYvwfnXbNWSePgyd)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLG=RVUpqQxMJjhmzBFYvwfnXbNWSePgLG+'\n'
   fp.write(RVUpqQxMJjhmzBFYvwfnXbNWSePgLG)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLI=0
   for RVUpqQxMJjhmzBFYvwfnXbNWSePgLO in RVUpqQxMJjhmzBFYvwfnXbNWSePgLa:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgLA=RVUpqQxMJjhmzBFYvwfnXbNWSePgAL(urllib.parse.parse_qsl(RVUpqQxMJjhmzBFYvwfnXbNWSePgLO))
    RVUpqQxMJjhmzBFYvwfnXbNWSePgLr=RVUpqQxMJjhmzBFYvwfnXbNWSePgyd.get('code').strip()
    RVUpqQxMJjhmzBFYvwfnXbNWSePgLd=RVUpqQxMJjhmzBFYvwfnXbNWSePgLA.get('code').strip()
    if RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='vod' and RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_settings_direct_replay()==RVUpqQxMJjhmzBFYvwfnXbNWSePgAi:
     RVUpqQxMJjhmzBFYvwfnXbNWSePgLr=RVUpqQxMJjhmzBFYvwfnXbNWSePgyd.get('videoid').strip()
     RVUpqQxMJjhmzBFYvwfnXbNWSePgLd=RVUpqQxMJjhmzBFYvwfnXbNWSePgLA.get('videoid').strip()if RVUpqQxMJjhmzBFYvwfnXbNWSePgLd!=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy else '-'
    if RVUpqQxMJjhmzBFYvwfnXbNWSePgLr!=RVUpqQxMJjhmzBFYvwfnXbNWSePgLd:
     fp.write(RVUpqQxMJjhmzBFYvwfnXbNWSePgLO)
     RVUpqQxMJjhmzBFYvwfnXbNWSePgLI+=1
     if RVUpqQxMJjhmzBFYvwfnXbNWSePgLI>=50:break
   fp.close()
  except:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
 def dp_Watch_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgit =RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('stype')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsA=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_settings_direct_replay()
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='-':
   for RVUpqQxMJjhmzBFYvwfnXbNWSePgio in RVUpqQxMJjhmzBFYvwfnXbNWSePgya:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsG=RVUpqQxMJjhmzBFYvwfnXbNWSePgio.get('title')
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':RVUpqQxMJjhmzBFYvwfnXbNWSePgio.get('mode'),'stype':RVUpqQxMJjhmzBFYvwfnXbNWSePgio.get('stype')}
    RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel='',img='',infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgAy,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk)
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgAO(RVUpqQxMJjhmzBFYvwfnXbNWSePgya)>0:xbmcplugin.endOfDirectory(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle)
  else:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLl=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.Load_List_File(RVUpqQxMJjhmzBFYvwfnXbNWSePgit)
   for RVUpqQxMJjhmzBFYvwfnXbNWSePgLT in RVUpqQxMJjhmzBFYvwfnXbNWSePgLl:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgaD=RVUpqQxMJjhmzBFYvwfnXbNWSePgAL(urllib.parse.parse_qsl(RVUpqQxMJjhmzBFYvwfnXbNWSePgLT))
    RVUpqQxMJjhmzBFYvwfnXbNWSePgLc =RVUpqQxMJjhmzBFYvwfnXbNWSePgaD.get('code').strip()
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsG =RVUpqQxMJjhmzBFYvwfnXbNWSePgaD.get('title').strip()
    RVUpqQxMJjhmzBFYvwfnXbNWSePgiT=RVUpqQxMJjhmzBFYvwfnXbNWSePgaD.get('img').strip()
    RVUpqQxMJjhmzBFYvwfnXbNWSePgaL =RVUpqQxMJjhmzBFYvwfnXbNWSePgaD.get('videoid').strip()
    try:
     RVUpqQxMJjhmzBFYvwfnXbNWSePgiT=RVUpqQxMJjhmzBFYvwfnXbNWSePgiT.replace('\'','\"')
     RVUpqQxMJjhmzBFYvwfnXbNWSePgiT=json.loads(RVUpqQxMJjhmzBFYvwfnXbNWSePgiT)
    except:
     RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEi={}
    RVUpqQxMJjhmzBFYvwfnXbNWSePgEi['plot']=RVUpqQxMJjhmzBFYvwfnXbNWSePgsG
    if RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='vod':
     if RVUpqQxMJjhmzBFYvwfnXbNWSePgsA==RVUpqQxMJjhmzBFYvwfnXbNWSePgAE or RVUpqQxMJjhmzBFYvwfnXbNWSePgaL==RVUpqQxMJjhmzBFYvwfnXbNWSePgAy:
      RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':'EPISODE','programcode':RVUpqQxMJjhmzBFYvwfnXbNWSePgLc,'page':'1'}
      RVUpqQxMJjhmzBFYvwfnXbNWSePgsD=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi
     else:
      RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':'VOD','mediacode':RVUpqQxMJjhmzBFYvwfnXbNWSePgaL,'stype':'vod','programcode':RVUpqQxMJjhmzBFYvwfnXbNWSePgLc,'title':RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,'thumbnail':RVUpqQxMJjhmzBFYvwfnXbNWSePgiT}
      RVUpqQxMJjhmzBFYvwfnXbNWSePgsD=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
    else:
     RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':'MOVIE','mediacode':RVUpqQxMJjhmzBFYvwfnXbNWSePgLc,'stype':'movie','title':RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,'thumbnail':RVUpqQxMJjhmzBFYvwfnXbNWSePgiT}
     RVUpqQxMJjhmzBFYvwfnXbNWSePgsD=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
    RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel='',img=RVUpqQxMJjhmzBFYvwfnXbNWSePgiT,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgEi,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgsD,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgEi={'plot':'시청목록을 삭제합니다.'}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsG='*** 시청목록 삭제 ***'
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'mode':'MYVIEW_REMOVE','stype':RVUpqQxMJjhmzBFYvwfnXbNWSePgit,'skey':'-',}
   RVUpqQxMJjhmzBFYvwfnXbNWSePgsc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.add_dir(RVUpqQxMJjhmzBFYvwfnXbNWSePgsG,sublabel='',img=RVUpqQxMJjhmzBFYvwfnXbNWSePgsc,infoLabels=RVUpqQxMJjhmzBFYvwfnXbNWSePgEi,isFolder=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE,params=RVUpqQxMJjhmzBFYvwfnXbNWSePgsk,isLink=RVUpqQxMJjhmzBFYvwfnXbNWSePgAi)
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgit=='movie':xbmcplugin.setContent(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,'movies')
   else:xbmcplugin.setContent(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,cacheToDisc=RVUpqQxMJjhmzBFYvwfnXbNWSePgAE)
 def Save_Searched_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgaG):
  try:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLk=RVUpqQxMJjhmzBFYvwfnXbNWSePgyo
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLa=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.Load_List_File('search') 
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLD={'skey':RVUpqQxMJjhmzBFYvwfnXbNWSePgaG.strip()}
   fp=RVUpqQxMJjhmzBFYvwfnXbNWSePgAo(RVUpqQxMJjhmzBFYvwfnXbNWSePgLk,'w',-1,'utf-8')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLG=urllib.parse.urlencode(RVUpqQxMJjhmzBFYvwfnXbNWSePgLD)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLG=RVUpqQxMJjhmzBFYvwfnXbNWSePgLG+'\n'
   fp.write(RVUpqQxMJjhmzBFYvwfnXbNWSePgLG)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgLI=0
   for RVUpqQxMJjhmzBFYvwfnXbNWSePgLO in RVUpqQxMJjhmzBFYvwfnXbNWSePgLa:
    RVUpqQxMJjhmzBFYvwfnXbNWSePgLA=RVUpqQxMJjhmzBFYvwfnXbNWSePgAL(urllib.parse.parse_qsl(RVUpqQxMJjhmzBFYvwfnXbNWSePgLO))
    RVUpqQxMJjhmzBFYvwfnXbNWSePgLr=RVUpqQxMJjhmzBFYvwfnXbNWSePgLD.get('skey').strip()
    RVUpqQxMJjhmzBFYvwfnXbNWSePgLd=RVUpqQxMJjhmzBFYvwfnXbNWSePgLA.get('skey').strip()
    if RVUpqQxMJjhmzBFYvwfnXbNWSePgLr!=RVUpqQxMJjhmzBFYvwfnXbNWSePgLd:
     fp.write(RVUpqQxMJjhmzBFYvwfnXbNWSePgLO)
     RVUpqQxMJjhmzBFYvwfnXbNWSePgLI+=1
     if RVUpqQxMJjhmzBFYvwfnXbNWSePgLI>=50:break
   fp.close()
  except:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
 def play_VIDEO(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.SaveCredential(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_winCredential())
  RVUpqQxMJjhmzBFYvwfnXbNWSePgLC =RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('mediacode')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgit =RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('stype')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgLK =RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('pvrmode')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgLH=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.get_selQuality(RVUpqQxMJjhmzBFYvwfnXbNWSePgit)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgOy,RVUpqQxMJjhmzBFYvwfnXbNWSePgOs=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.GetBroadURL(RVUpqQxMJjhmzBFYvwfnXbNWSePgLC,RVUpqQxMJjhmzBFYvwfnXbNWSePgLH,RVUpqQxMJjhmzBFYvwfnXbNWSePgit,RVUpqQxMJjhmzBFYvwfnXbNWSePgLK)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.addon_log('qt, stype, url : %s - %s - %s'%(RVUpqQxMJjhmzBFYvwfnXbNWSePgAt(RVUpqQxMJjhmzBFYvwfnXbNWSePgLH),RVUpqQxMJjhmzBFYvwfnXbNWSePgit,RVUpqQxMJjhmzBFYvwfnXbNWSePgOy))
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgOy=='':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.addon_noti(__language__(30908).encode('utf8'))
   return
  RVUpqQxMJjhmzBFYvwfnXbNWSePgOi =RVUpqQxMJjhmzBFYvwfnXbNWSePgOy.find('Policy=')
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgOi!=-1:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOE =RVUpqQxMJjhmzBFYvwfnXbNWSePgOy.split('?')[0]
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOa=RVUpqQxMJjhmzBFYvwfnXbNWSePgAL(urllib.parse.parse_qsl(urllib.parse.urlsplit(RVUpqQxMJjhmzBFYvwfnXbNWSePgOy).query))
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOa=urllib.parse.urlencode(RVUpqQxMJjhmzBFYvwfnXbNWSePgOa)
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOa=RVUpqQxMJjhmzBFYvwfnXbNWSePgOa.replace('&',';')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOa=RVUpqQxMJjhmzBFYvwfnXbNWSePgOa.replace('Policy','CloudFront-Policy')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOa=RVUpqQxMJjhmzBFYvwfnXbNWSePgOa.replace('Signature','CloudFront-Signature')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOa=RVUpqQxMJjhmzBFYvwfnXbNWSePgOa.replace('Key-Pair-Id','CloudFront-Key-Pair-Id')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOL='%s|Cookie=%s'%(RVUpqQxMJjhmzBFYvwfnXbNWSePgOE,RVUpqQxMJjhmzBFYvwfnXbNWSePgOa)
  else:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOL=RVUpqQxMJjhmzBFYvwfnXbNWSePgOy
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.addon_log(RVUpqQxMJjhmzBFYvwfnXbNWSePgOL)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgOA=xbmcgui.ListItem(path=RVUpqQxMJjhmzBFYvwfnXbNWSePgOL)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgOs!='':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOt=RVUpqQxMJjhmzBFYvwfnXbNWSePgOs
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOu ='https://cj.drmkeyserver.com/widevine_license'
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOo ='mpd'
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOG ='com.widevine.alpha'
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOI =inputstreamhelper.Helper(RVUpqQxMJjhmzBFYvwfnXbNWSePgOo,drm='widevine')
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgOI.check_inputstream():
    RVUpqQxMJjhmzBFYvwfnXbNWSePgOr={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%RVUpqQxMJjhmzBFYvwfnXbNWSePgLC,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.USER_AGENT,'AcquireLicenseAssertion':RVUpqQxMJjhmzBFYvwfnXbNWSePgOt,'Host':'cj.drmkeyserver.com'}
    RVUpqQxMJjhmzBFYvwfnXbNWSePgOd=RVUpqQxMJjhmzBFYvwfnXbNWSePgOu+'|'+urllib.parse.urlencode(RVUpqQxMJjhmzBFYvwfnXbNWSePgOr)+'|R{SSM}|'
    RVUpqQxMJjhmzBFYvwfnXbNWSePgOA.setProperty('inputstream',RVUpqQxMJjhmzBFYvwfnXbNWSePgOI.inputstream_addon)
    RVUpqQxMJjhmzBFYvwfnXbNWSePgOA.setProperty('inputstream.adaptive.manifest_type',RVUpqQxMJjhmzBFYvwfnXbNWSePgOo)
    RVUpqQxMJjhmzBFYvwfnXbNWSePgOA.setProperty('inputstream.adaptive.license_type',RVUpqQxMJjhmzBFYvwfnXbNWSePgOG)
    RVUpqQxMJjhmzBFYvwfnXbNWSePgOA.setProperty('inputstream.adaptive.license_key',RVUpqQxMJjhmzBFYvwfnXbNWSePgOd)
    RVUpqQxMJjhmzBFYvwfnXbNWSePgOA.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.USER_AGENT))
  xbmcplugin.setResolvedUrl(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG._addon_handle,RVUpqQxMJjhmzBFYvwfnXbNWSePgAi,RVUpqQxMJjhmzBFYvwfnXbNWSePgOA)
  try:
   if RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('mode')in['VOD','MOVIE']and RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('title'):
    RVUpqQxMJjhmzBFYvwfnXbNWSePgsk={'code':RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('programcode')if RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('mode')=='VOD' else RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('mediacode'),'img':RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('thumbnail'),'title':RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('title'),'videoid':RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('mediacode')}
    RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.Save_Watched_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('stype'),RVUpqQxMJjhmzBFYvwfnXbNWSePgsk)
  except:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
 def logout(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyT=xbmcgui.Dialog()
  RVUpqQxMJjhmzBFYvwfnXbNWSePgia=RVUpqQxMJjhmzBFYvwfnXbNWSePgyT.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgia==RVUpqQxMJjhmzBFYvwfnXbNWSePgAE:sys.exit()
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.wininfo_clear()
  if os.path.isfile(RVUpqQxMJjhmzBFYvwfnXbNWSePgyu):os.remove(RVUpqQxMJjhmzBFYvwfnXbNWSePgyu)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst=xbmcgui.Window(10000)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_TOKEN','')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_USERINFO','')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_UUID','')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_LOGINTIME','')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_MAINTOKEN','')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_COOKIEKEY','')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgOl =RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.Get_Now_Datetime()
  RVUpqQxMJjhmzBFYvwfnXbNWSePgOT=RVUpqQxMJjhmzBFYvwfnXbNWSePgOl+datetime.timedelta(days=RVUpqQxMJjhmzBFYvwfnXbNWSePgAs(__addon__.getSetting('cache_ttl')))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst=xbmcgui.Window(10000)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgOc={'tving_token':RVUpqQxMJjhmzBFYvwfnXbNWSePgst.getProperty('TVING_M_TOKEN'),'tving_userinfo':RVUpqQxMJjhmzBFYvwfnXbNWSePgst.getProperty('TVING_M_USERINFO'),'tving_uuid':RVUpqQxMJjhmzBFYvwfnXbNWSePgst.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':RVUpqQxMJjhmzBFYvwfnXbNWSePgOT.strftime('%Y-%m-%d'),'tving_maintoken':RVUpqQxMJjhmzBFYvwfnXbNWSePgst.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':RVUpqQxMJjhmzBFYvwfnXbNWSePgst.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':RVUpqQxMJjhmzBFYvwfnXbNWSePgst.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=RVUpqQxMJjhmzBFYvwfnXbNWSePgAo(RVUpqQxMJjhmzBFYvwfnXbNWSePgyu,'w',-1,'utf-8')
   json.dump(RVUpqQxMJjhmzBFYvwfnXbNWSePgOc,fp)
   fp.close()
  except RVUpqQxMJjhmzBFYvwfnXbNWSePgAG as exception:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgAI(exception)
 def cookiefile_check(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgOc={}
  try: 
   fp=RVUpqQxMJjhmzBFYvwfnXbNWSePgAo(RVUpqQxMJjhmzBFYvwfnXbNWSePgyu,'r',-1,'utf-8')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOc= json.load(fp)
   fp.close()
  except RVUpqQxMJjhmzBFYvwfnXbNWSePgAG as exception:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.wininfo_clear()
   return RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
  RVUpqQxMJjhmzBFYvwfnXbNWSePgsH =__addon__.getSetting('id')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgiy =__addon__.getSetting('pw')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgOk=__addon__.getSetting('login_type')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgOD =__addon__.getSetting('selected_profile')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_id']=base64.standard_b64decode(RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_id']).decode('utf-8')
  RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_pw']=base64.standard_b64decode(RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_pw']).decode('utf-8')
  try:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_profile']
  except:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_profile']='0'
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgsH!=RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_id']or RVUpqQxMJjhmzBFYvwfnXbNWSePgiy!=RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_pw']or RVUpqQxMJjhmzBFYvwfnXbNWSePgOk!=RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_logintype']or RVUpqQxMJjhmzBFYvwfnXbNWSePgOD!=RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_profile']:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.wininfo_clear()
   return RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
  RVUpqQxMJjhmzBFYvwfnXbNWSePgiL =RVUpqQxMJjhmzBFYvwfnXbNWSePgAs(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  RVUpqQxMJjhmzBFYvwfnXbNWSePgOC=RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_limitdate']
  RVUpqQxMJjhmzBFYvwfnXbNWSePgiO =RVUpqQxMJjhmzBFYvwfnXbNWSePgAs(re.sub('-','',RVUpqQxMJjhmzBFYvwfnXbNWSePgOC))
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgiO<RVUpqQxMJjhmzBFYvwfnXbNWSePgiL:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.wininfo_clear()
   return RVUpqQxMJjhmzBFYvwfnXbNWSePgAE
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst=xbmcgui.Window(10000)
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_TOKEN',RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_token'])
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_USERINFO',RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_userinfo'])
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_UUID',RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_uuid'])
  RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_LOGINTIME',RVUpqQxMJjhmzBFYvwfnXbNWSePgOC)
  try:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_MAINTOKEN',RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_maintoken'])
   RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_COOKIEKEY',RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_cookiekey'])
   RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_LOCKKEY',RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_lockkey'])
  except:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_MAINTOKEN',RVUpqQxMJjhmzBFYvwfnXbNWSePgOc['tving_token'])
   RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_COOKIEKEY','Y')
   RVUpqQxMJjhmzBFYvwfnXbNWSePgst.setProperty('TVING_M_LOCKKEY','N')
  return RVUpqQxMJjhmzBFYvwfnXbNWSePgAi
 def dp_Global_Search(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=RVUpqQxMJjhmzBFYvwfnXbNWSePgiG.get('mode')
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=='TOTAL_SEARCH':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOK='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgOK='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(RVUpqQxMJjhmzBFYvwfnXbNWSePgOK)
 def dp_Bookmark_Menu(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG,RVUpqQxMJjhmzBFYvwfnXbNWSePgiG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgOK='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(RVUpqQxMJjhmzBFYvwfnXbNWSePgOK)
 def tving_main(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG):
  RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params.get('mode',RVUpqQxMJjhmzBFYvwfnXbNWSePgAy)
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=='LOGOUT':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.logout()
   return
  RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.login_main()
  if RVUpqQxMJjhmzBFYvwfnXbNWSePgaI is RVUpqQxMJjhmzBFYvwfnXbNWSePgAy:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_Main_List()
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_Title_Group(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI in['GLOBAL_GROUP']:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_SubTitle_Group(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=='CHANNEL':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_LiveChannel_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI in['LIVE','VOD','MOVIE']:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.play_VIDEO(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=='PROGRAM':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_Program_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=='EPISODE':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_Episode_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=='MOVIE_SUB':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_Movie_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=='SEARCH_GROUP':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_Search_Group(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI in['SEARCH','LOCAL_SEARCH']:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_Search_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=='WATCH':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_Watch_List(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_Listfile_Delete(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=='ORDER_BY':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_setEpOrderby(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=='SET_BOOKMARK':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_Set_Bookmark(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI in['TOTAL_SEARCH','TOTAL_HISTORY']:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_Global_Search(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=='SEARCH_HISTORY':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_Search_History(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  elif RVUpqQxMJjhmzBFYvwfnXbNWSePgaI=='MENU_BOOKMARK':
   RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.dp_Bookmark_Menu(RVUpqQxMJjhmzBFYvwfnXbNWSePgyG.main_params)
  else:
   RVUpqQxMJjhmzBFYvwfnXbNWSePgAy
# Created by pyminifier (https://github.com/liftoff/pyminifier)
