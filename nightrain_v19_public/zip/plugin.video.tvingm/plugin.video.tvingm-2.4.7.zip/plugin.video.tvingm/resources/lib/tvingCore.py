__author__="NightRain"
WwxiflVJtKTbuHpyoRjkaAGOPmBXEC=ImportError
WwxiflVJtKTbuHpyoRjkaAGOPmBXEM=object
WwxiflVJtKTbuHpyoRjkaAGOPmBXEF=None
WwxiflVJtKTbuHpyoRjkaAGOPmBXEI=False
WwxiflVJtKTbuHpyoRjkaAGOPmBXED=open
WwxiflVJtKTbuHpyoRjkaAGOPmBXES=True
WwxiflVJtKTbuHpyoRjkaAGOPmBXEL=int
WwxiflVJtKTbuHpyoRjkaAGOPmBXEs=range
WwxiflVJtKTbuHpyoRjkaAGOPmBXEU=Exception
WwxiflVJtKTbuHpyoRjkaAGOPmBXEY=print
WwxiflVJtKTbuHpyoRjkaAGOPmBXEv=len
WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ=str
WwxiflVJtKTbuHpyoRjkaAGOPmBXEz=list
WwxiflVJtKTbuHpyoRjkaAGOPmBXEc=bytes
WwxiflVJtKTbuHpyoRjkaAGOPmBXnd=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
try:
 from Cryptodome.PublicKey import RSA
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
except WwxiflVJtKTbuHpyoRjkaAGOPmBXEC:
 from Crypto.PublicKey import RSA
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
WwxiflVJtKTbuHpyoRjkaAGOPmBXdq={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
WwxiflVJtKTbuHpyoRjkaAGOPmBXdr ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class WwxiflVJtKTbuHpyoRjkaAGOPmBXdh(WwxiflVJtKTbuHpyoRjkaAGOPmBXEM):
 def __init__(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.NETWORKCODE ='CSND0900'
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.OSCODE ='CSOD0900' 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TELECODE ='CSCD0900'
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.SCREENCODE ='CSSD0100'
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.APIKEY_ATV ='b6ac9e6384d93d6e533b144b3ef22c42' 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.SCREENCODE_ATV ='CSSD1300' 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.LIVE_LIMIT =20 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.VOD_LIMIT =24 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.EPISODE_LIMIT =30 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.SEARCH_LIMIT =30 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.MOVIE_LIMIT =24 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN ='https://api.tving.com'
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN ='https://image.tving.com'
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.SEARCH_DOMAIN ='https://search.tving.com'
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.LOGIN_DOMAIN ='https://user.tving.com'
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.URL_DOMAIN ='https://www.tving.com'
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.MOVIE_LITE =['2610061','2610161','261062']
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.DEFAULT_HEADER ={'user-agent':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.USER_AGENT}
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV_SESSION_COOKIES1=''
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV_SESSION_COOKIES2=''
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV ={}
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.Init_TV_Total()
 def Init_TV_Total(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N',},}
 def callRequestCookies(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,jobtype,WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,redirects=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdE=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.DEFAULT_HEADER
  if headers:WwxiflVJtKTbuHpyoRjkaAGOPmBXdE.update(headers)
  if jobtype=='Get':
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdn=requests.get(WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,params=params,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXdE,cookies=cookies,allow_redirects=redirects)
  else:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdn=requests.post(WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,data=payload,params=params,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXdE,cookies=cookies,allow_redirects=redirects)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXdn
 def JsonFile_Save(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,filename,WwxiflVJtKTbuHpyoRjkaAGOPmBXde):
  if filename=='':return WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
  try:
   fp=WwxiflVJtKTbuHpyoRjkaAGOPmBXED(filename,'w',-1,'utf-8')
   json.dump(WwxiflVJtKTbuHpyoRjkaAGOPmBXde,fp,indent=4,ensure_ascii=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI)
   fp.close()
  except:
   return WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXES
 def JsonFile_Load(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,filename):
  if filename=='':return{}
  try:
   fp=WwxiflVJtKTbuHpyoRjkaAGOPmBXED(filename,'r',-1,'utf-8')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdC=json.load(fp)
   fp.close()
  except:
   return{}
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXdC
 def Save_session_acount(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,WwxiflVJtKTbuHpyoRjkaAGOPmBXdM,WwxiflVJtKTbuHpyoRjkaAGOPmBXdF,WwxiflVJtKTbuHpyoRjkaAGOPmBXdI,WwxiflVJtKTbuHpyoRjkaAGOPmBXdD):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['account']['tvid'] =base64.standard_b64encode(WwxiflVJtKTbuHpyoRjkaAGOPmBXdM.encode()).decode('utf-8')
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['account']['tvpw'] =base64.standard_b64encode(WwxiflVJtKTbuHpyoRjkaAGOPmBXdF.encode()).decode('utf-8')
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['account']['tvtype']=WwxiflVJtKTbuHpyoRjkaAGOPmBXdI 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['account']['tvpf'] =WwxiflVJtKTbuHpyoRjkaAGOPmBXdD 
 def Load_session_acount(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg):
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdM =base64.standard_b64decode(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['account']['tvid']).decode('utf-8')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdF =base64.standard_b64decode(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['account']['tvpw']).decode('utf-8')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdI=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['account']['tvtype']
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdD =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXdM,WwxiflVJtKTbuHpyoRjkaAGOPmBXdF,WwxiflVJtKTbuHpyoRjkaAGOPmBXdI,WwxiflVJtKTbuHpyoRjkaAGOPmBXdD
 def makeDefaultCookies(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdS={}
  if WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_token']:WwxiflVJtKTbuHpyoRjkaAGOPmBXdS['_tving_token']=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_token']
  if WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_userinfo']:WwxiflVJtKTbuHpyoRjkaAGOPmBXdS['POC_USERINFO']=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_userinfo']
  if WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_maintoken']:WwxiflVJtKTbuHpyoRjkaAGOPmBXdS[WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GLOBAL_COOKIENM['tv_maintoken']]=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_maintoken']
  if WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_cookiekey']:WwxiflVJtKTbuHpyoRjkaAGOPmBXdS[WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GLOBAL_COOKIENM['tv_cookiekey']]=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_cookiekey']
  if WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_lockkey']:WwxiflVJtKTbuHpyoRjkaAGOPmBXdS[WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GLOBAL_COOKIENM['tv_lockkey']]=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_lockkey']
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXdS
 def getDeviceStr(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdL=[]
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdL.append('Windows') 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdL.append('Chrome') 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdL.append('ko-KR') 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdL.append('undefined') 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdL.append('24') 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdL.append(u'한국 표준시')
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdL.append('undefined') 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdL.append('undefined') 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXdL.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  WwxiflVJtKTbuHpyoRjkaAGOPmBXds=''
  for WwxiflVJtKTbuHpyoRjkaAGOPmBXdU in WwxiflVJtKTbuHpyoRjkaAGOPmBXdL:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXds+=WwxiflVJtKTbuHpyoRjkaAGOPmBXdU+'|'
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXds
 def GetDefaultParams(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,uhd=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI):
  if uhd==WwxiflVJtKTbuHpyoRjkaAGOPmBXEI:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdY={'apiKey':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.APIKEY,'networkCode':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.NETWORKCODE,'osCode':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.OSCODE,'teleCode':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TELECODE,'screenCode':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.SCREENCODE,}
  else:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdY={'apiKey':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.APIKEY_ATV,'networkCode':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.NETWORKCODE,'osCode':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.OSCODE,'teleCode':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TELECODE,'screenCode':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.SCREENCODE_ATV,}
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXdY
 def GetNoCache(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,timetype=1):
  if timetype==1:
   return WwxiflVJtKTbuHpyoRjkaAGOPmBXEL(time.time())
  else:
   return WwxiflVJtKTbuHpyoRjkaAGOPmBXEL(time.time()*1000)
 def GetUniqueid(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,hValue=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF):
  if hValue:
   import hashlib
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdv=hashlib.sha1()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdv.update(hValue.encode())
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdQ=WwxiflVJtKTbuHpyoRjkaAGOPmBXdv.hexdigest()[:8]
  else:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdz=[0 for i in WwxiflVJtKTbuHpyoRjkaAGOPmBXEs(256)]
   for i in WwxiflVJtKTbuHpyoRjkaAGOPmBXEs(256):
    WwxiflVJtKTbuHpyoRjkaAGOPmBXdz[i]='%02x'%(i)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdc=WwxiflVJtKTbuHpyoRjkaAGOPmBXEL(4294967295*random.random())|0
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdQ=WwxiflVJtKTbuHpyoRjkaAGOPmBXdz[255&WwxiflVJtKTbuHpyoRjkaAGOPmBXdc]+WwxiflVJtKTbuHpyoRjkaAGOPmBXdz[WwxiflVJtKTbuHpyoRjkaAGOPmBXdc>>8&255]+WwxiflVJtKTbuHpyoRjkaAGOPmBXdz[WwxiflVJtKTbuHpyoRjkaAGOPmBXdc>>16&255]+WwxiflVJtKTbuHpyoRjkaAGOPmBXdz[WwxiflVJtKTbuHpyoRjkaAGOPmBXdc>>24&255]
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXdQ
 def GetCredential(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,user_id,user_pw,login_type,user_pf):
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhd=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhq={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Post',WwxiflVJtKTbuHpyoRjkaAGOPmBXhd,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXhq,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF)
   for WwxiflVJtKTbuHpyoRjkaAGOPmBXhg in WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.cookies:
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXhg.name=='_tving_token':
     WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_token']=WwxiflVJtKTbuHpyoRjkaAGOPmBXhg.value
    elif WwxiflVJtKTbuHpyoRjkaAGOPmBXhg.name=='POC_USERINFO':
     WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_userinfo']=WwxiflVJtKTbuHpyoRjkaAGOPmBXhg.value
   if not WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_token']:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.Init_TV_Total()
    return WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_maintoken']=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_token']
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetProfileToken(user_pf)==WwxiflVJtKTbuHpyoRjkaAGOPmBXEI:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.Init_TV_Total()
    return WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhE =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDeviceList()
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXhE not in['','-']:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_uuid']=WwxiflVJtKTbuHpyoRjkaAGOPmBXhE+'-'+WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetUniqueid(WwxiflVJtKTbuHpyoRjkaAGOPmBXhE)
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.Init_TV_Total()
   return WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXES
 def GetProfileToken(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,user_pf):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhn=[]
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhe =''
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdS=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.makeDefaultCookies()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhN,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXdS)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhn =re.findall('data-profile-no="\d+"',WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   for i in WwxiflVJtKTbuHpyoRjkaAGOPmBXEs(WwxiflVJtKTbuHpyoRjkaAGOPmBXEv(WwxiflVJtKTbuHpyoRjkaAGOPmBXhn)):
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhC =WwxiflVJtKTbuHpyoRjkaAGOPmBXhn[i].replace('data-profile-no=','').replace('"','')
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhn[i]=WwxiflVJtKTbuHpyoRjkaAGOPmBXhC
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhe=WwxiflVJtKTbuHpyoRjkaAGOPmBXhn[user_pf]
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.Init_TV_Total()
   return WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdS=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.makeDefaultCookies()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhq={'profileNo':WwxiflVJtKTbuHpyoRjkaAGOPmBXhe}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Post',WwxiflVJtKTbuHpyoRjkaAGOPmBXhN,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXhq,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXdS)
   for WwxiflVJtKTbuHpyoRjkaAGOPmBXhg in WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.cookies:
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXhg.name=='_tving_token':
     WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_token']=WwxiflVJtKTbuHpyoRjkaAGOPmBXhg.value
    elif WwxiflVJtKTbuHpyoRjkaAGOPmBXhg.name==WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GLOBAL_COOKIENM['tv_cookiekey']:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_cookiekey']=WwxiflVJtKTbuHpyoRjkaAGOPmBXhg.value
    elif WwxiflVJtKTbuHpyoRjkaAGOPmBXhg.name==WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GLOBAL_COOKIENM['tv_lockkey']:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_lockkey']=WwxiflVJtKTbuHpyoRjkaAGOPmBXhg.value
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.Init_TV_Total()
   return WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXES
 def GetDeviceList(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhM=[]
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhF='-'
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/v1/user/device/list'
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhI=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhN
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdS=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.makeDefaultCookies()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhI,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhD,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXdS)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhS=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhM=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']
   for WwxiflVJtKTbuHpyoRjkaAGOPmBXhL in WwxiflVJtKTbuHpyoRjkaAGOPmBXhM:
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['model']=='PC' or WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['model']=='PC-Chrome':
     WwxiflVJtKTbuHpyoRjkaAGOPmBXhF=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['uuid']
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXhF
 def Get_Now_Datetime(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,mediacode,sel_quality,stype,pvrmode='-',optUHD=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhU ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','error_msg':'',}
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhF =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_uuid'].split('-')[0] 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhY =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_uuid'] 
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhv=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI 
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhQ=WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetNoCache(1))
   if stype!='tvingtv':
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/v2/media/stream/info' 
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDefaultParams()
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':WwxiflVJtKTbuHpyoRjkaAGOPmBXhY,'deviceInfo':'PC','noCache':WwxiflVJtKTbuHpyoRjkaAGOPmBXhQ,}
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhz.update(WwxiflVJtKTbuHpyoRjkaAGOPmBXhD)
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhN
    WwxiflVJtKTbuHpyoRjkaAGOPmBXdS=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.makeDefaultCookies()
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhz,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXdS)
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.status_code!=200:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXhU['error_msg']='First Step - {} error'.format(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.status_code)
     return WwxiflVJtKTbuHpyoRjkaAGOPmBXhU
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhS=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['result']['code']=='060':
     for WwxiflVJtKTbuHpyoRjkaAGOPmBXqd,WwxiflVJtKTbuHpyoRjkaAGOPmBXqF in WwxiflVJtKTbuHpyoRjkaAGOPmBXdq.items():
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXqF==sel_quality:
       WwxiflVJtKTbuHpyoRjkaAGOPmBXqh=WwxiflVJtKTbuHpyoRjkaAGOPmBXqd
    elif WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['result']['code']!='000':
     WwxiflVJtKTbuHpyoRjkaAGOPmBXhU['error_msg']=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['result']['message']
     return WwxiflVJtKTbuHpyoRjkaAGOPmBXhU
    else: 
     if not('stream' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']):return WwxiflVJtKTbuHpyoRjkaAGOPmBXhU
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqr=[]
     for WwxiflVJtKTbuHpyoRjkaAGOPmBXqd,WwxiflVJtKTbuHpyoRjkaAGOPmBXqF in WwxiflVJtKTbuHpyoRjkaAGOPmBXdq.items():
      for WwxiflVJtKTbuHpyoRjkaAGOPmBXhL in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['stream']['quality']:
       if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['active']=='Y' and WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['code']==WwxiflVJtKTbuHpyoRjkaAGOPmBXqd:
        WwxiflVJtKTbuHpyoRjkaAGOPmBXqr.append({WwxiflVJtKTbuHpyoRjkaAGOPmBXdq.get(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['code']):WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['code']})
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqh=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.CheckQuality(sel_quality,WwxiflVJtKTbuHpyoRjkaAGOPmBXqr)
     try:
      if optUHD==WwxiflVJtKTbuHpyoRjkaAGOPmBXES and WwxiflVJtKTbuHpyoRjkaAGOPmBXqh=='stream50' and 'stream_support_info' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['content']['info']:
       if 'stream70' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['content']['info']['stream_support_info']:
        WwxiflVJtKTbuHpyoRjkaAGOPmBXqh='stream70'
        WwxiflVJtKTbuHpyoRjkaAGOPmBXhv =WwxiflVJtKTbuHpyoRjkaAGOPmBXES
     except:
      pass
   else:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqh='stream40'
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhU['error_msg']='First Step - except error'
   return WwxiflVJtKTbuHpyoRjkaAGOPmBXhU
  WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(WwxiflVJtKTbuHpyoRjkaAGOPmBXqh)
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhQ=WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetNoCache(1))
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/v2a/media/stream/info'
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXhv==WwxiflVJtKTbuHpyoRjkaAGOPmBXES:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDefaultParams(uhd=WwxiflVJtKTbuHpyoRjkaAGOPmBXES)
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'mediaCode':mediacode,'noCache':WwxiflVJtKTbuHpyoRjkaAGOPmBXhQ,'streamType':'hls','streamCode':WwxiflVJtKTbuHpyoRjkaAGOPmBXqh,'deviceId':WwxiflVJtKTbuHpyoRjkaAGOPmBXhF,'adReq':'none','wm':'Y','ad_device':'','uuid':WwxiflVJtKTbuHpyoRjkaAGOPmBXhY,'deviceInfo':'android_tv',}
   else:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDefaultParams()
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':WwxiflVJtKTbuHpyoRjkaAGOPmBXqh,'deviceId':WwxiflVJtKTbuHpyoRjkaAGOPmBXhF,'uuid':WwxiflVJtKTbuHpyoRjkaAGOPmBXhY,'deviceInfo':'PC_Chrome','noCache':WwxiflVJtKTbuHpyoRjkaAGOPmBXhQ,'wm':'Y'}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz.update(WwxiflVJtKTbuHpyoRjkaAGOPmBXhD)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhN
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdS=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.makeDefaultCookies()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhz,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXdS,redirects=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhS=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.JsonFile_Save(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV_SESSION_COOKIES1,WwxiflVJtKTbuHpyoRjkaAGOPmBXhS)
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['result']['code']!='000':
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhU['error_msg']=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['result']['message']
    return WwxiflVJtKTbuHpyoRjkaAGOPmBXhU
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqg=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['stream']
   if 'drm_license_assertion' in WwxiflVJtKTbuHpyoRjkaAGOPmBXqg:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhU['drm_license']=WwxiflVJtKTbuHpyoRjkaAGOPmBXqg['drm_license_assertion']
    if '4k_nondrm_url' in WwxiflVJtKTbuHpyoRjkaAGOPmBXqg['broadcast']and WwxiflVJtKTbuHpyoRjkaAGOPmBXhv==WwxiflVJtKTbuHpyoRjkaAGOPmBXES:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqE =WwxiflVJtKTbuHpyoRjkaAGOPmBXqg['broadcast']['4k_nondrm_url']
     WwxiflVJtKTbuHpyoRjkaAGOPmBXhU['drm_license']=''
    else:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqE =WwxiflVJtKTbuHpyoRjkaAGOPmBXqg['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in WwxiflVJtKTbuHpyoRjkaAGOPmBXqg['broadcast']):return WwxiflVJtKTbuHpyoRjkaAGOPmBXhU
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqE=WwxiflVJtKTbuHpyoRjkaAGOPmBXqg['broadcast']['broad_url']
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhU['error_msg']='Second Step - except error'
   return WwxiflVJtKTbuHpyoRjkaAGOPmBXhU
  WwxiflVJtKTbuHpyoRjkaAGOPmBXqn=WwxiflVJtKTbuHpyoRjkaAGOPmBXhQ
  WwxiflVJtKTbuHpyoRjkaAGOPmBXqE=WwxiflVJtKTbuHpyoRjkaAGOPmBXqE.split('|')[1]
  WwxiflVJtKTbuHpyoRjkaAGOPmBXqE,WwxiflVJtKTbuHpyoRjkaAGOPmBXqe,WwxiflVJtKTbuHpyoRjkaAGOPmBXqN=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.Decrypt_Url(WwxiflVJtKTbuHpyoRjkaAGOPmBXqE,mediacode,WwxiflVJtKTbuHpyoRjkaAGOPmBXqn)
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhU['streaming_url']=WwxiflVJtKTbuHpyoRjkaAGOPmBXqE
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhU['watermark'] =WwxiflVJtKTbuHpyoRjkaAGOPmBXqe
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhU['watermarkKey']=WwxiflVJtKTbuHpyoRjkaAGOPmBXqN
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXhU
 def CheckQuality(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,sel_qt,WwxiflVJtKTbuHpyoRjkaAGOPmBXqr):
  for WwxiflVJtKTbuHpyoRjkaAGOPmBXqC in WwxiflVJtKTbuHpyoRjkaAGOPmBXqr:
   if sel_qt>=WwxiflVJtKTbuHpyoRjkaAGOPmBXEz(WwxiflVJtKTbuHpyoRjkaAGOPmBXqC)[0]:return WwxiflVJtKTbuHpyoRjkaAGOPmBXqC.get(WwxiflVJtKTbuHpyoRjkaAGOPmBXEz(WwxiflVJtKTbuHpyoRjkaAGOPmBXqC)[0])
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqM=WwxiflVJtKTbuHpyoRjkaAGOPmBXqC.get(WwxiflVJtKTbuHpyoRjkaAGOPmBXEz(WwxiflVJtKTbuHpyoRjkaAGOPmBXqC)[0])
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXqM
 def makeOocUrl(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,ooc_params):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=''
  for WwxiflVJtKTbuHpyoRjkaAGOPmBXqd,WwxiflVJtKTbuHpyoRjkaAGOPmBXqF in ooc_params.items():
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhc+="%s=%s^"%(WwxiflVJtKTbuHpyoRjkaAGOPmBXqd,WwxiflVJtKTbuHpyoRjkaAGOPmBXqF)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXhc
 def GetLiveChannelList(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,stype,page_int):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhM=[]
  WwxiflVJtKTbuHpyoRjkaAGOPmBXqI=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/v2/media/lives'
   if stype=='onair': 
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqD='CPCS0100,CPCS0400'
   else:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqD='CPCS0300'
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDefaultParams()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'cacheType':'main','pageNo':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(page_int),'pageSize':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':WwxiflVJtKTbuHpyoRjkaAGOPmBXqD,}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz.update(WwxiflVJtKTbuHpyoRjkaAGOPmBXhD)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhN
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhz,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhS=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   if not('result' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']):return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqS=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['result']
   for WwxiflVJtKTbuHpyoRjkaAGOPmBXhL in WwxiflVJtKTbuHpyoRjkaAGOPmBXqS:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqL=WwxiflVJtKTbuHpyoRjkaAGOPmBXqY=WwxiflVJtKTbuHpyoRjkaAGOPmBXqv=''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqs=WwxiflVJtKTbuHpyoRjkaAGOPmBXrS=''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqU=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['live_code']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqL =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['channel']['name']['ko']
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['episode']!=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqY =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['program']['name']['ko']
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqY =WwxiflVJtKTbuHpyoRjkaAGOPmBXqY+', '+WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['episode']['frequency'])+'회'
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqv=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['episode']['synopsis']['ko']
    else:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqY =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['program']['name']['ko']
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqv=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['program']['synopsis']['ko']
    try: 
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =''
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =''
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=''
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrd =''
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrh =''
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrq =''
     for WwxiflVJtKTbuHpyoRjkaAGOPmBXrg in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['program']['image']:
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP0900':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
      elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP1800':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
      elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP2000':WwxiflVJtKTbuHpyoRjkaAGOPmBXrd =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
      elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP1900':WwxiflVJtKTbuHpyoRjkaAGOPmBXrh =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
      elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP0200':WwxiflVJtKTbuHpyoRjkaAGOPmBXrq =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
      elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP0500':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
      elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP0800':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ=='':
      for WwxiflVJtKTbuHpyoRjkaAGOPmBXrg in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['channel']['image']:
       if WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIC0400':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
       elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIC1400':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
       elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIC1900':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
    except:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXEF
    try:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrE =[]
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrn=[]
     WwxiflVJtKTbuHpyoRjkaAGOPmBXre =[]
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrN=''
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrC=''
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrM=''
     for WwxiflVJtKTbuHpyoRjkaAGOPmBXrF in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('schedule').get('program').get('actor'):
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXrF!='' and WwxiflVJtKTbuHpyoRjkaAGOPmBXrF!=u'없음':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrF)
     for WwxiflVJtKTbuHpyoRjkaAGOPmBXrI in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('schedule').get('program').get('director'):
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXrI!='' and WwxiflVJtKTbuHpyoRjkaAGOPmBXrI!='-' and WwxiflVJtKTbuHpyoRjkaAGOPmBXrI!=u'없음':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrI)
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('schedule').get('program').get('category1_name').get('ko')!='':
      WwxiflVJtKTbuHpyoRjkaAGOPmBXre.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['program']['category1_name']['ko'])
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('schedule').get('program').get('category2_name').get('ko')!='':
      WwxiflVJtKTbuHpyoRjkaAGOPmBXre.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['program']['category2_name']['ko'])
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('schedule').get('program').get('product_year'):WwxiflVJtKTbuHpyoRjkaAGOPmBXrN=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['program']['product_year']
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('schedule').get('program').get('grade_code') :WwxiflVJtKTbuHpyoRjkaAGOPmBXrC= WwxiflVJtKTbuHpyoRjkaAGOPmBXdr.get(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['program']['grade_code'])
     if 'broad_dt' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('schedule').get('program'):
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrD =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('schedule').get('program').get('broad_dt')
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrM='%s-%s-%s'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[:4],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[4:6],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[6:])
    except:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXEF
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqs=WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['broadcast_start_time'])[8:12]
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrS =WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['schedule']['broadcast_end_time'])[8:12]
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrL={'channel':WwxiflVJtKTbuHpyoRjkaAGOPmBXqL,'title':WwxiflVJtKTbuHpyoRjkaAGOPmBXqY,'mediacode':WwxiflVJtKTbuHpyoRjkaAGOPmBXqU,'thumbnail':{'poster':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz,'thumb':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ,'clearlogo':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc,'icon':WwxiflVJtKTbuHpyoRjkaAGOPmBXrd,'fanart':WwxiflVJtKTbuHpyoRjkaAGOPmBXrq},'synopsis':WwxiflVJtKTbuHpyoRjkaAGOPmBXqv,'channelepg':' [%s:%s ~ %s:%s]'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXqs[0:2],WwxiflVJtKTbuHpyoRjkaAGOPmBXqs[2:],WwxiflVJtKTbuHpyoRjkaAGOPmBXrS[0:2],WwxiflVJtKTbuHpyoRjkaAGOPmBXrS[2:]),'cast':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE,'director':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn,'info_genre':WwxiflVJtKTbuHpyoRjkaAGOPmBXre,'year':WwxiflVJtKTbuHpyoRjkaAGOPmBXrN,'mpaa':WwxiflVJtKTbuHpyoRjkaAGOPmBXrC,'premiered':WwxiflVJtKTbuHpyoRjkaAGOPmBXrM}
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhM.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrL)
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['has_more']=='Y':
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqI=WwxiflVJtKTbuHpyoRjkaAGOPmBXES
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
 def GetProgramList(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,genre,orderby,page_int,genreCode='all'):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhM=[]
  WwxiflVJtKTbuHpyoRjkaAGOPmBXqI=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
  try:
   if genre=='PARAMOUNT':
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/v2/media/paramount/episodes'
   else:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/v2/media/episodes'
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDefaultParams()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'cacheType':'main','pageSize':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(page_int),}
   if genre not in['all','PARAMOUNT']:WwxiflVJtKTbuHpyoRjkaAGOPmBXhD['categoryCode']=genre
   if genreCode!='all' :WwxiflVJtKTbuHpyoRjkaAGOPmBXhD['genreCode'] =genreCode 
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz.update(WwxiflVJtKTbuHpyoRjkaAGOPmBXhD)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhN
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhz,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhS=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   if not('result' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']):return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqS=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['result']
   for WwxiflVJtKTbuHpyoRjkaAGOPmBXhL in WwxiflVJtKTbuHpyoRjkaAGOPmBXqS:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrs=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['program']['code']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqY =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['program']['name']['ko']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrC =WwxiflVJtKTbuHpyoRjkaAGOPmBXdr.get(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['program'].get('grade_code'))
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrd =''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrh =''
    for WwxiflVJtKTbuHpyoRjkaAGOPmBXrg in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['program']['image']:
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP0900':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP0200':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP1800':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP2000':WwxiflVJtKTbuHpyoRjkaAGOPmBXrd =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP1900':WwxiflVJtKTbuHpyoRjkaAGOPmBXrh =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqv =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['program']['synopsis']['ko']
    try:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrU=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['channel']['name']['ko']
    except:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrU=''
    try:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrE =[]
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrn=[]
     WwxiflVJtKTbuHpyoRjkaAGOPmBXre =[]
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrN =''
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrM=''
     for WwxiflVJtKTbuHpyoRjkaAGOPmBXrF in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('program').get('actor'):
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXrF!='' and WwxiflVJtKTbuHpyoRjkaAGOPmBXrF!='-' and WwxiflVJtKTbuHpyoRjkaAGOPmBXrF!=u'없음':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrF)
     for WwxiflVJtKTbuHpyoRjkaAGOPmBXrI in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('program').get('director'):
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXrI!='' and WwxiflVJtKTbuHpyoRjkaAGOPmBXrI!='-' and WwxiflVJtKTbuHpyoRjkaAGOPmBXrI!=u'없음':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrI)
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('program').get('category1_name').get('ko')!='':
      WwxiflVJtKTbuHpyoRjkaAGOPmBXre.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['program']['category1_name']['ko'])
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('program').get('category2_name').get('ko')!='':
      WwxiflVJtKTbuHpyoRjkaAGOPmBXre.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['program']['category2_name']['ko'])
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('program').get('product_year'):WwxiflVJtKTbuHpyoRjkaAGOPmBXrN=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['program']['product_year']
     if 'broad_dt' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('program'):
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrD =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('program').get('broad_dt')
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrM='%s-%s-%s'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[:4],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[4:6],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[6:])
    except:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXEF
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrL={'program':WwxiflVJtKTbuHpyoRjkaAGOPmBXrs,'title':WwxiflVJtKTbuHpyoRjkaAGOPmBXqY,'thumbnail':{'poster':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz,'thumb':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ,'clearlogo':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc,'icon':WwxiflVJtKTbuHpyoRjkaAGOPmBXrd,'banner':WwxiflVJtKTbuHpyoRjkaAGOPmBXrh,'fanart':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ},'synopsis':WwxiflVJtKTbuHpyoRjkaAGOPmBXqv,'channel':WwxiflVJtKTbuHpyoRjkaAGOPmBXrU,'cast':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE,'director':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn,'info_genre':WwxiflVJtKTbuHpyoRjkaAGOPmBXre,'year':WwxiflVJtKTbuHpyoRjkaAGOPmBXrN,'premiered':WwxiflVJtKTbuHpyoRjkaAGOPmBXrM,'mpaa':WwxiflVJtKTbuHpyoRjkaAGOPmBXrC}
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhM.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrL)
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['has_more']=='Y':WwxiflVJtKTbuHpyoRjkaAGOPmBXqI=WwxiflVJtKTbuHpyoRjkaAGOPmBXES
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
 def Get_UHD_ProgramList(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,page_int):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhM=[]
  WwxiflVJtKTbuHpyoRjkaAGOPmBXqI=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/v2/operator/highlights'
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDefaultParams(uhd=WwxiflVJtKTbuHpyoRjkaAGOPmBXES)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(page_int),'pocType':'APP_X_TVING_4.0.0',}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz.update(WwxiflVJtKTbuHpyoRjkaAGOPmBXhD)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhN
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhz,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhS=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   if not('result' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']):return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqS=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['result']
   for WwxiflVJtKTbuHpyoRjkaAGOPmBXhL in WwxiflVJtKTbuHpyoRjkaAGOPmBXqS:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrY=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['content']['program']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrv =WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['code']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqY =WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['name']['ko'].strip()
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrC =WwxiflVJtKTbuHpyoRjkaAGOPmBXdr.get(WwxiflVJtKTbuHpyoRjkaAGOPmBXrY.get('grade_code'))
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqv =WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['synopsis']['ko']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrU =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['content']['channel']['name']['ko']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrN =WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['product_year']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrd =''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrh =''
    for WwxiflVJtKTbuHpyoRjkaAGOPmBXrg in WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['image']:
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP0900':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP0200':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP1800':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP2000':WwxiflVJtKTbuHpyoRjkaAGOPmBXrd =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP1900':WwxiflVJtKTbuHpyoRjkaAGOPmBXrh =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXre =[]
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrE =[]
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrn=[]
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrM =''
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXrY.get('category1_name').get('ko')!='':
     WwxiflVJtKTbuHpyoRjkaAGOPmBXre.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['category1_name']['ko'])
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXrY.get('category2_name').get('ko')!='':
     WwxiflVJtKTbuHpyoRjkaAGOPmBXre.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['category2_name']['ko'])
    for WwxiflVJtKTbuHpyoRjkaAGOPmBXrF in WwxiflVJtKTbuHpyoRjkaAGOPmBXrY.get('actor'):
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXrF!='' and WwxiflVJtKTbuHpyoRjkaAGOPmBXrF!='-' and WwxiflVJtKTbuHpyoRjkaAGOPmBXrF!=u'없음':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrF)
    for WwxiflVJtKTbuHpyoRjkaAGOPmBXrI in WwxiflVJtKTbuHpyoRjkaAGOPmBXrY.get('director'):
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXrI!='' and WwxiflVJtKTbuHpyoRjkaAGOPmBXrI!='-' and WwxiflVJtKTbuHpyoRjkaAGOPmBXrI!=u'없음':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrI)
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXrY.get('broad_dt')not in[WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,'']:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrD =WwxiflVJtKTbuHpyoRjkaAGOPmBXrY.get('broad_dt')
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrM='%s-%s-%s'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[:4],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[4:6],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[6:])
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrL={'program':WwxiflVJtKTbuHpyoRjkaAGOPmBXrv,'title':WwxiflVJtKTbuHpyoRjkaAGOPmBXqY,'mpaa':WwxiflVJtKTbuHpyoRjkaAGOPmBXrC,'thumbnail':{'poster':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz,'thumb':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ,'clearlogo':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc,'icon':WwxiflVJtKTbuHpyoRjkaAGOPmBXrd,'banner':WwxiflVJtKTbuHpyoRjkaAGOPmBXrh,'fanart':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ},'channel':WwxiflVJtKTbuHpyoRjkaAGOPmBXrU,'synopsis':WwxiflVJtKTbuHpyoRjkaAGOPmBXqv,'year':WwxiflVJtKTbuHpyoRjkaAGOPmBXrN,'info_genre':WwxiflVJtKTbuHpyoRjkaAGOPmBXre,'cast':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE,'director':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn,'premiered':WwxiflVJtKTbuHpyoRjkaAGOPmBXrM,}
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhM.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrL)
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
 def GetEpisodeList(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,program_code,page_int,orderby='desc'):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhM=[]
  WwxiflVJtKTbuHpyoRjkaAGOPmBXqI=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/v2/media/frequency/program/'+program_code
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDefaultParams()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz.update(WwxiflVJtKTbuHpyoRjkaAGOPmBXhD)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhN
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhz,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhS=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   if not('result' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']):return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqS=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['result']
   WwxiflVJtKTbuHpyoRjkaAGOPmBXrQ=WwxiflVJtKTbuHpyoRjkaAGOPmBXEL(WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['total_count'])
   WwxiflVJtKTbuHpyoRjkaAGOPmBXrz =WwxiflVJtKTbuHpyoRjkaAGOPmBXEL(WwxiflVJtKTbuHpyoRjkaAGOPmBXrQ//(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrc =(WwxiflVJtKTbuHpyoRjkaAGOPmBXrQ-1)-((page_int-1)*WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.EPISODE_LIMIT)
   else:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrc =(page_int-1)*WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.EPISODE_LIMIT
   for i in WwxiflVJtKTbuHpyoRjkaAGOPmBXEs(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.EPISODE_LIMIT):
    if orderby=='desc':
     WwxiflVJtKTbuHpyoRjkaAGOPmBXgd=WwxiflVJtKTbuHpyoRjkaAGOPmBXrc-i
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXgd<0:break
    else:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXgd=WwxiflVJtKTbuHpyoRjkaAGOPmBXrc+i
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXgd>=WwxiflVJtKTbuHpyoRjkaAGOPmBXrQ:break
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgh=WwxiflVJtKTbuHpyoRjkaAGOPmBXqS[WwxiflVJtKTbuHpyoRjkaAGOPmBXgd]['episode']['code']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqY =WwxiflVJtKTbuHpyoRjkaAGOPmBXqS[WwxiflVJtKTbuHpyoRjkaAGOPmBXgd]['vod_name']['ko']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgq =''
    try:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrD=WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXqS[WwxiflVJtKTbuHpyoRjkaAGOPmBXgd]['episode']['broadcast_date'])
     WwxiflVJtKTbuHpyoRjkaAGOPmBXgq='%s-%s-%s'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[:4],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[4:6],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[6:])
    except:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXEF
    try:
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXqS[WwxiflVJtKTbuHpyoRjkaAGOPmBXgd]['episode']['pip_cliptype']=='C012':
      WwxiflVJtKTbuHpyoRjkaAGOPmBXgq+=' - Quick VOD'
    except:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXEF
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqv =WwxiflVJtKTbuHpyoRjkaAGOPmBXqS[WwxiflVJtKTbuHpyoRjkaAGOPmBXgd]['episode']['synopsis']['ko']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrd =''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrh =''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrq =''
    for WwxiflVJtKTbuHpyoRjkaAGOPmBXrg in WwxiflVJtKTbuHpyoRjkaAGOPmBXqS[WwxiflVJtKTbuHpyoRjkaAGOPmBXgd]['program']['image']:
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP0900':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP1800':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP2000':WwxiflVJtKTbuHpyoRjkaAGOPmBXrd =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP1900':WwxiflVJtKTbuHpyoRjkaAGOPmBXrh =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIP0200':WwxiflVJtKTbuHpyoRjkaAGOPmBXrq =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
    for WwxiflVJtKTbuHpyoRjkaAGOPmBXrg in WwxiflVJtKTbuHpyoRjkaAGOPmBXqS[WwxiflVJtKTbuHpyoRjkaAGOPmBXgd]['episode']['image']:
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIE0400':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
    try:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXgr=WwxiflVJtKTbuHpyoRjkaAGOPmBXgn=WwxiflVJtKTbuHpyoRjkaAGOPmBXge=''
     WwxiflVJtKTbuHpyoRjkaAGOPmBXgE=0
     WwxiflVJtKTbuHpyoRjkaAGOPmBXgr =WwxiflVJtKTbuHpyoRjkaAGOPmBXqS[WwxiflVJtKTbuHpyoRjkaAGOPmBXgd]['program']['name']['ko']
     WwxiflVJtKTbuHpyoRjkaAGOPmBXgn =WwxiflVJtKTbuHpyoRjkaAGOPmBXgq
     WwxiflVJtKTbuHpyoRjkaAGOPmBXge =WwxiflVJtKTbuHpyoRjkaAGOPmBXqS[WwxiflVJtKTbuHpyoRjkaAGOPmBXgd]['channel']['name']['ko']
     if 'frequency' in WwxiflVJtKTbuHpyoRjkaAGOPmBXqS[WwxiflVJtKTbuHpyoRjkaAGOPmBXgd]['episode']:WwxiflVJtKTbuHpyoRjkaAGOPmBXgE=WwxiflVJtKTbuHpyoRjkaAGOPmBXqS[WwxiflVJtKTbuHpyoRjkaAGOPmBXgd]['episode']['frequency']
    except:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXEF
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrL={'episode':WwxiflVJtKTbuHpyoRjkaAGOPmBXgh,'title':WwxiflVJtKTbuHpyoRjkaAGOPmBXqY,'subtitle':WwxiflVJtKTbuHpyoRjkaAGOPmBXgq,'thumbnail':{'poster':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz,'thumb':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ,'clearlogo':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc,'icon':WwxiflVJtKTbuHpyoRjkaAGOPmBXrd,'banner':WwxiflVJtKTbuHpyoRjkaAGOPmBXrh,'fanart':WwxiflVJtKTbuHpyoRjkaAGOPmBXrq},'synopsis':WwxiflVJtKTbuHpyoRjkaAGOPmBXqv,'info_title':WwxiflVJtKTbuHpyoRjkaAGOPmBXgr,'aired':WwxiflVJtKTbuHpyoRjkaAGOPmBXgn,'studio':WwxiflVJtKTbuHpyoRjkaAGOPmBXge,'frequency':WwxiflVJtKTbuHpyoRjkaAGOPmBXgE}
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhM.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrL)
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXrz>page_int:WwxiflVJtKTbuHpyoRjkaAGOPmBXqI=WwxiflVJtKTbuHpyoRjkaAGOPmBXES
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI,WwxiflVJtKTbuHpyoRjkaAGOPmBXrz
 def GetMovieList(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,genre,orderby,page_int):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhM=[]
  WwxiflVJtKTbuHpyoRjkaAGOPmBXqI=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
  try:
   if genre=='PARAMOUNT':
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/v2/media/paramount/movies'
   else:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/v2/media/movies'
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDefaultParams()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'pageSize':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N','pageNo':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(page_int),}
   if genre not in['all','PARAMOUNT']:WwxiflVJtKTbuHpyoRjkaAGOPmBXhD['categoryCode']=genre
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhD['productPackageCode']=','.join(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.MOVIE_LITE)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz.update(WwxiflVJtKTbuHpyoRjkaAGOPmBXhD)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhN
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhz,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhS=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   if not('result' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']):return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqS=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['result']
   for WwxiflVJtKTbuHpyoRjkaAGOPmBXhL in WwxiflVJtKTbuHpyoRjkaAGOPmBXqS:
    if 'release_date' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('movie'):
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrN=WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('movie').get('release_date'))[:4]
    else:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrN=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgN =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['movie']['code']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqY =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['movie']['name']['ko'].strip()
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXrN not in[WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,'0','']:WwxiflVJtKTbuHpyoRjkaAGOPmBXqY+=u' (%s)'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXrN)
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqz=''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=''
    for WwxiflVJtKTbuHpyoRjkaAGOPmBXrg in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['movie']['image']:
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIM2100':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIM0400':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIM1800':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqv =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['movie']['story']['ko']
    try:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXgr =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['movie']['name']['ko'].strip()
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrC =WwxiflVJtKTbuHpyoRjkaAGOPmBXdr.get(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('grade_code'))
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrE=[]
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrn=[]
     WwxiflVJtKTbuHpyoRjkaAGOPmBXre=[]
     WwxiflVJtKTbuHpyoRjkaAGOPmBXgC=0
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrM=''
     WwxiflVJtKTbuHpyoRjkaAGOPmBXge =''
     for WwxiflVJtKTbuHpyoRjkaAGOPmBXrF in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('movie').get('actor'):
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXrF!='':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrF)
     for WwxiflVJtKTbuHpyoRjkaAGOPmBXrI in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('movie').get('director'):
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXrI!='':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrI)
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('movie').get('category1_name').get('ko')!='':
      WwxiflVJtKTbuHpyoRjkaAGOPmBXre.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['movie']['category1_name']['ko'])
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('movie').get('category2_name').get('ko')!='':
      WwxiflVJtKTbuHpyoRjkaAGOPmBXre.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['movie']['category2_name']['ko'])
     if 'duration' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('movie'):WwxiflVJtKTbuHpyoRjkaAGOPmBXgC=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('movie').get('duration')
     if 'release_date' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('movie'):
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrD=WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('movie').get('release_date'))
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXrD!='0':WwxiflVJtKTbuHpyoRjkaAGOPmBXrM='%s-%s-%s'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[:4],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[4:6],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[6:])
     if 'production' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('movie'):WwxiflVJtKTbuHpyoRjkaAGOPmBXge=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('movie').get('production')
    except:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXEF
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrL={'moviecode':WwxiflVJtKTbuHpyoRjkaAGOPmBXgN,'title':WwxiflVJtKTbuHpyoRjkaAGOPmBXqY,'thumbnail':{'poster':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz,'thumb':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ,'clearlogo':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc,'fanart':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ},'synopsis':WwxiflVJtKTbuHpyoRjkaAGOPmBXqv,'info_title':WwxiflVJtKTbuHpyoRjkaAGOPmBXgr,'year':WwxiflVJtKTbuHpyoRjkaAGOPmBXrN,'cast':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE,'director':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn,'info_genre':WwxiflVJtKTbuHpyoRjkaAGOPmBXre,'duration':WwxiflVJtKTbuHpyoRjkaAGOPmBXgC,'premiered':WwxiflVJtKTbuHpyoRjkaAGOPmBXrM,'studio':WwxiflVJtKTbuHpyoRjkaAGOPmBXge,'mpaa':WwxiflVJtKTbuHpyoRjkaAGOPmBXrC}
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgM=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
    for WwxiflVJtKTbuHpyoRjkaAGOPmBXgF in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['billing_package_id']:
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXgF in WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.MOVIE_LITE:
      WwxiflVJtKTbuHpyoRjkaAGOPmBXgM=WwxiflVJtKTbuHpyoRjkaAGOPmBXES
      break
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXgM==WwxiflVJtKTbuHpyoRjkaAGOPmBXEI: 
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrL['title']=WwxiflVJtKTbuHpyoRjkaAGOPmBXrL['title']+' [개별구매]'
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhM.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrL)
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['has_more']=='Y':WwxiflVJtKTbuHpyoRjkaAGOPmBXqI=WwxiflVJtKTbuHpyoRjkaAGOPmBXES
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
 def Get_UHD_MovieList(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,page_int):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhM=[]
  WwxiflVJtKTbuHpyoRjkaAGOPmBXqI=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/v2/operator/highlights'
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDefaultParams(uhd=WwxiflVJtKTbuHpyoRjkaAGOPmBXES)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(page_int),'pocType':'APP_X_TVING_4.0.0',}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz.update(WwxiflVJtKTbuHpyoRjkaAGOPmBXhD)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhN
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhz,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhS=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   if not('result' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']):return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqS=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['result']
   for WwxiflVJtKTbuHpyoRjkaAGOPmBXhL in WwxiflVJtKTbuHpyoRjkaAGOPmBXqS:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrY=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['content']['movie']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrv =WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['code']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqY =WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['name']['ko'].strip()
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgr =WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['name']['ko'].strip()
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrN =WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['product_year']
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXrN:WwxiflVJtKTbuHpyoRjkaAGOPmBXqY+=u' (%s)'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['product_year'])
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqv =WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['story']['ko']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgC =WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['duration']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrC =WwxiflVJtKTbuHpyoRjkaAGOPmBXdr.get(WwxiflVJtKTbuHpyoRjkaAGOPmBXrY.get('grade_code'))
    WwxiflVJtKTbuHpyoRjkaAGOPmBXge =WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['production']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqz=''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=''
    WwxiflVJtKTbuHpyoRjkaAGOPmBXre =[]
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrE =[]
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrn=[]
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrM =''
    for WwxiflVJtKTbuHpyoRjkaAGOPmBXrg in WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['image']:
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIM2100':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIM0400':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
     elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['code']=='CAIM1800':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg['url']
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['release_date']not in[WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,0]:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrD=WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['release_date'])
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXrD!='0':WwxiflVJtKTbuHpyoRjkaAGOPmBXrM='%s-%s-%s'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[:4],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[4:6],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[6:])
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXrY.get('category1_name').get('ko')!='':
     WwxiflVJtKTbuHpyoRjkaAGOPmBXre.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['category1_name']['ko'])
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXrY.get('category2_name').get('ko')!='':
     WwxiflVJtKTbuHpyoRjkaAGOPmBXre.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrY['category2_name']['ko'])
    for WwxiflVJtKTbuHpyoRjkaAGOPmBXrF in WwxiflVJtKTbuHpyoRjkaAGOPmBXrY.get('actor'):
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXrF!='':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrF)
    for WwxiflVJtKTbuHpyoRjkaAGOPmBXrI in WwxiflVJtKTbuHpyoRjkaAGOPmBXrY.get('director'):
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXrI!='':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrI)
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrL={'moviecode':WwxiflVJtKTbuHpyoRjkaAGOPmBXrv,'title':WwxiflVJtKTbuHpyoRjkaAGOPmBXqY,'thumbnail':{'poster':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz,'thumb':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ,'clearlogo':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc,'fanart':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ},'year':WwxiflVJtKTbuHpyoRjkaAGOPmBXrN,'info_title':WwxiflVJtKTbuHpyoRjkaAGOPmBXgr,'synopsis':WwxiflVJtKTbuHpyoRjkaAGOPmBXqv,'mpaa':WwxiflVJtKTbuHpyoRjkaAGOPmBXrC,'duration':WwxiflVJtKTbuHpyoRjkaAGOPmBXgC,'premiered':WwxiflVJtKTbuHpyoRjkaAGOPmBXrM,'studio':WwxiflVJtKTbuHpyoRjkaAGOPmBXge,'info_genre':WwxiflVJtKTbuHpyoRjkaAGOPmBXre,'cast':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE,'director':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn,}
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhM.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrL)
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
 def GetMovieGenre(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhM=[]
  WwxiflVJtKTbuHpyoRjkaAGOPmBXqI=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/v2/media/movie/curations'
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDefaultParams()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz.update(WwxiflVJtKTbuHpyoRjkaAGOPmBXhD)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhN
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhz,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhS=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   if not('result' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']):return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqS=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['result']
   for WwxiflVJtKTbuHpyoRjkaAGOPmBXhL in WwxiflVJtKTbuHpyoRjkaAGOPmBXqS:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgI =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['curation_code']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgD =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['curation_name']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXrL={'curation_code':WwxiflVJtKTbuHpyoRjkaAGOPmBXgI,'curation_name':WwxiflVJtKTbuHpyoRjkaAGOPmBXgD}
    WwxiflVJtKTbuHpyoRjkaAGOPmBXhM.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrL)
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
 def GetSearchList(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,search_key,page_int,stype):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXgS=[]
  WwxiflVJtKTbuHpyoRjkaAGOPmBXqI=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/search/getSearch.jsp'
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(page_int),'pageSize':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.SCREENCODE,'os':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.OSCODE,'network':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.SEARCH_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhN
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhD,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhS=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   if stype=='vod':
    if not('programRsb' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS):return WwxiflVJtKTbuHpyoRjkaAGOPmBXgS,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgL=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['programRsb']['dataList']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgs =WwxiflVJtKTbuHpyoRjkaAGOPmBXEL(WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['programRsb']['count'])
    for WwxiflVJtKTbuHpyoRjkaAGOPmBXhL in WwxiflVJtKTbuHpyoRjkaAGOPmBXgL:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrs=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['mast_cd']
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqY =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['mast_nm']
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['web_url4']
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['web_url']
     try:
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrE =[]
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrn=[]
      WwxiflVJtKTbuHpyoRjkaAGOPmBXre =[]
      WwxiflVJtKTbuHpyoRjkaAGOPmBXgC =0
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrC =''
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrN =''
      WwxiflVJtKTbuHpyoRjkaAGOPmBXgn =''
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('actor') !='' and WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('actor') !='-':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('actor').split(',')
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('director')!='' and WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('director')!='-':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('director').split(',')
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('cate_nm')!='' and WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('cate_nm')!='-':WwxiflVJtKTbuHpyoRjkaAGOPmBXre =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('cate_nm').split('/')
      if 'targetage' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL:WwxiflVJtKTbuHpyoRjkaAGOPmBXrC=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('targetage')
      if 'broad_dt' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL:
       WwxiflVJtKTbuHpyoRjkaAGOPmBXrD=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('broad_dt')
       WwxiflVJtKTbuHpyoRjkaAGOPmBXgn='%s-%s-%s'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[:4],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[4:6],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[6:])
       WwxiflVJtKTbuHpyoRjkaAGOPmBXrN =WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[:4]
     except:
      WwxiflVJtKTbuHpyoRjkaAGOPmBXEF
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrL={'program':WwxiflVJtKTbuHpyoRjkaAGOPmBXrs,'title':WwxiflVJtKTbuHpyoRjkaAGOPmBXqY,'thumbnail':{'poster':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz,'thumb':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ,'fanart':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ},'synopsis':'','cast':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE,'director':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn,'info_genre':WwxiflVJtKTbuHpyoRjkaAGOPmBXre,'duration':WwxiflVJtKTbuHpyoRjkaAGOPmBXgC,'mpaa':WwxiflVJtKTbuHpyoRjkaAGOPmBXrC,'year':WwxiflVJtKTbuHpyoRjkaAGOPmBXrN,'aired':WwxiflVJtKTbuHpyoRjkaAGOPmBXgn}
     WwxiflVJtKTbuHpyoRjkaAGOPmBXgS.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrL)
   else:
    if not('vodMVRsb' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS):return WwxiflVJtKTbuHpyoRjkaAGOPmBXgS,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgU=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['vodMVRsb']['dataList']
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgs =WwxiflVJtKTbuHpyoRjkaAGOPmBXEL(WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['vodMVRsb']['count'])
    for WwxiflVJtKTbuHpyoRjkaAGOPmBXhL in WwxiflVJtKTbuHpyoRjkaAGOPmBXgU:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrs=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['mast_cd']
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqY =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['mast_nm'].strip()
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['web_url']
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXqz
     WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=''
     try:
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrE =[]
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrn=[]
      WwxiflVJtKTbuHpyoRjkaAGOPmBXre =[]
      WwxiflVJtKTbuHpyoRjkaAGOPmBXgC =0
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrC =''
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrN =''
      WwxiflVJtKTbuHpyoRjkaAGOPmBXgn =''
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('actor') !='' and WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('actor') !='-':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('actor').split(',')
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('director')!='' and WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('director')!='-':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('director').split(',')
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('cate_nm')!='' and WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('cate_nm')!='-':WwxiflVJtKTbuHpyoRjkaAGOPmBXre =WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('cate_nm').split('/')
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('runtime_sec')!='':WwxiflVJtKTbuHpyoRjkaAGOPmBXgC=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('runtime_sec')
      if 'grade_nm' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL:WwxiflVJtKTbuHpyoRjkaAGOPmBXrC=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('grade_nm')
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrD=WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('broad_dt')
      if data_str!='':
       WwxiflVJtKTbuHpyoRjkaAGOPmBXgn='%s-%s-%s'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[:4],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[4:6],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[6:])
       WwxiflVJtKTbuHpyoRjkaAGOPmBXrN =WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[:4]
     except:
      WwxiflVJtKTbuHpyoRjkaAGOPmBXEF
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrL={'movie':WwxiflVJtKTbuHpyoRjkaAGOPmBXrs,'title':WwxiflVJtKTbuHpyoRjkaAGOPmBXqY,'thumbnail':{'poster':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz,'thumb':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ,'fanart':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ,'clearlogo':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc},'synopsis':'','cast':WwxiflVJtKTbuHpyoRjkaAGOPmBXrE,'director':WwxiflVJtKTbuHpyoRjkaAGOPmBXrn,'info_genre':WwxiflVJtKTbuHpyoRjkaAGOPmBXre,'duration':WwxiflVJtKTbuHpyoRjkaAGOPmBXgC,'mpaa':WwxiflVJtKTbuHpyoRjkaAGOPmBXrC,'year':WwxiflVJtKTbuHpyoRjkaAGOPmBXrN,'aired':WwxiflVJtKTbuHpyoRjkaAGOPmBXgn}
     WwxiflVJtKTbuHpyoRjkaAGOPmBXgM=WwxiflVJtKTbuHpyoRjkaAGOPmBXEI
     for WwxiflVJtKTbuHpyoRjkaAGOPmBXgF in WwxiflVJtKTbuHpyoRjkaAGOPmBXhL['bill']:
      if WwxiflVJtKTbuHpyoRjkaAGOPmBXgF in WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.MOVIE_LITE:
       WwxiflVJtKTbuHpyoRjkaAGOPmBXgM=WwxiflVJtKTbuHpyoRjkaAGOPmBXES
       break
     if WwxiflVJtKTbuHpyoRjkaAGOPmBXgM==WwxiflVJtKTbuHpyoRjkaAGOPmBXEI: 
      WwxiflVJtKTbuHpyoRjkaAGOPmBXrL['title']=WwxiflVJtKTbuHpyoRjkaAGOPmBXrL['title']+' [개별구매]'
     WwxiflVJtKTbuHpyoRjkaAGOPmBXgS.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrL)
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXgs>(page_int*WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.SEARCH_LIMIT):WwxiflVJtKTbuHpyoRjkaAGOPmBXqI=WwxiflVJtKTbuHpyoRjkaAGOPmBXES
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXgS,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
 def GetBookmarkInfo(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,videoid,vidtype):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXgY={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN+'/v2/media/program/'+videoid
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDefaultParams()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'pageNo':'1','pageSize':'10','order':'name',}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz.update(WwxiflVJtKTbuHpyoRjkaAGOPmBXhD)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhz,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgv=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   if not('body' in WwxiflVJtKTbuHpyoRjkaAGOPmBXgv):return{}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ=WwxiflVJtKTbuHpyoRjkaAGOPmBXgv['body']
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqY=WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('name').get('ko').strip()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['title'] =WwxiflVJtKTbuHpyoRjkaAGOPmBXqY
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['title']=WwxiflVJtKTbuHpyoRjkaAGOPmBXqY
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['mpaa'] =WwxiflVJtKTbuHpyoRjkaAGOPmBXdr.get(WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('grade_code'))
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['plot'] =WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('synopsis').get('ko')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['year'] =WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('product_year')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['cast'] =WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('actor')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['director']=WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('director')
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('category1_name').get('ko')!='':
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['genre'].append(WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('category1_name').get('ko'))
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('category2_name').get('ko')!='':
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['genre'].append(WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('category2_name').get('ko'))
   WwxiflVJtKTbuHpyoRjkaAGOPmBXrD=WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('broad_dt'))
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXrD!='0':WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[:4],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[4:6],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[6:])
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =''
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =''
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=''
   WwxiflVJtKTbuHpyoRjkaAGOPmBXrd =''
   WwxiflVJtKTbuHpyoRjkaAGOPmBXrh =''
   for WwxiflVJtKTbuHpyoRjkaAGOPmBXrg in WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('image'):
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('code')=='CAIP0900':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('url')
    elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('code')=='CAIP0200':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('url')
    elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('code')=='CAIP1800':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('url')
    elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('code')=='CAIP2000':WwxiflVJtKTbuHpyoRjkaAGOPmBXrd =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('url')
    elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('code')=='CAIP1900':WwxiflVJtKTbuHpyoRjkaAGOPmBXrh =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('url')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['thumbnail']['poster']=WwxiflVJtKTbuHpyoRjkaAGOPmBXqz
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['thumbnail']['thumb']=WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['thumbnail']['clearlogo']=WwxiflVJtKTbuHpyoRjkaAGOPmBXqc
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['thumbnail']['icon']=WwxiflVJtKTbuHpyoRjkaAGOPmBXrd
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['thumbnail']['banner']=WwxiflVJtKTbuHpyoRjkaAGOPmBXrh
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['thumbnail']['fanart']=WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ
  else:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN+'/v2a/media/stream/info'
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDefaultParams()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_uuid'].split('-')[0],'uuid':WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetNoCache(1)),'wm':'Y',}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz.update(WwxiflVJtKTbuHpyoRjkaAGOPmBXhD)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhz,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgv=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   if not('content' in WwxiflVJtKTbuHpyoRjkaAGOPmBXgv['body']):return{}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ=WwxiflVJtKTbuHpyoRjkaAGOPmBXgv['body']['content']['info']['movie']
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqY =WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('name').get('ko').strip()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['title']=WwxiflVJtKTbuHpyoRjkaAGOPmBXqY
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqY +=u' (%s)'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('product_year'))
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['title'] =WwxiflVJtKTbuHpyoRjkaAGOPmBXqY
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['mpaa'] =WwxiflVJtKTbuHpyoRjkaAGOPmBXdr.get(WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('grade_code'))
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['plot'] =WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('story').get('ko')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['year'] =WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('product_year')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['studio'] =WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('production')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['duration']=WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('duration')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['cast'] =WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('actor')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['director']=WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('director')
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('category1_name').get('ko')!='':
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['genre'].append(WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('category1_name').get('ko'))
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('category2_name').get('ko')!='':
    WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['genre'].append(WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('category2_name').get('ko'))
   WwxiflVJtKTbuHpyoRjkaAGOPmBXrD=WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('release_date'))
   if WwxiflVJtKTbuHpyoRjkaAGOPmBXrD!='0':WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[:4],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[4:6],WwxiflVJtKTbuHpyoRjkaAGOPmBXrD[6:])
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqz=''
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =''
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=''
   for WwxiflVJtKTbuHpyoRjkaAGOPmBXrg in WwxiflVJtKTbuHpyoRjkaAGOPmBXgQ.get('image'):
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('code')=='CAIM2100':WwxiflVJtKTbuHpyoRjkaAGOPmBXqz =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('url')
    elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('code')=='CAIM0400':WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('url')
    elif WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('code')=='CAIM1800':WwxiflVJtKTbuHpyoRjkaAGOPmBXqc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.IMG_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXrg.get('url')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['thumbnail']['poster']=WwxiflVJtKTbuHpyoRjkaAGOPmBXqz
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['thumbnail']['thumb']=WwxiflVJtKTbuHpyoRjkaAGOPmBXqz 
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['thumbnail']['clearlogo']=WwxiflVJtKTbuHpyoRjkaAGOPmBXqc
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgY['saveinfo']['thumbnail']['fanart']=WwxiflVJtKTbuHpyoRjkaAGOPmBXqQ
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXgY
 def GetEuroChannelList(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXhM=[]
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhN ='/v2/operator/highlights'
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetDefaultParams()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhD={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':WwxiflVJtKTbuHpyoRjkaAGOPmBXEQ(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.GetNoCache(2))}
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhz.update(WwxiflVJtKTbuHpyoRjkaAGOPmBXhD)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhc=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.API_DOMAIN+WwxiflVJtKTbuHpyoRjkaAGOPmBXhN
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhr=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.callRequestCookies('Get',WwxiflVJtKTbuHpyoRjkaAGOPmBXhc,payload=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,params=WwxiflVJtKTbuHpyoRjkaAGOPmBXhz,headers=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF,cookies=WwxiflVJtKTbuHpyoRjkaAGOPmBXEF)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXhS=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXhr.text)
   if not('result' in WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']):return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM,WwxiflVJtKTbuHpyoRjkaAGOPmBXqI
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqS=WwxiflVJtKTbuHpyoRjkaAGOPmBXhS['body']['result']
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgz =WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.Get_Now_Datetime()
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgc=WwxiflVJtKTbuHpyoRjkaAGOPmBXgz+datetime.timedelta(days=-1)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXgc=WwxiflVJtKTbuHpyoRjkaAGOPmBXEL(WwxiflVJtKTbuHpyoRjkaAGOPmBXgc.strftime('%Y%m%d'))
   for WwxiflVJtKTbuHpyoRjkaAGOPmBXhL in WwxiflVJtKTbuHpyoRjkaAGOPmBXqS:
    WwxiflVJtKTbuHpyoRjkaAGOPmBXEd=WwxiflVJtKTbuHpyoRjkaAGOPmBXEL(WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('content').get('banner_title2')[:8])
    if WwxiflVJtKTbuHpyoRjkaAGOPmBXgc<=WwxiflVJtKTbuHpyoRjkaAGOPmBXEd:
     WwxiflVJtKTbuHpyoRjkaAGOPmBXrL={'channel':WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('content').get('banner_sub_title3'),'title':WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('content').get('banner_title'),'subtitle':WwxiflVJtKTbuHpyoRjkaAGOPmBXhL.get('content').get('banner_sub_title2'),}
     WwxiflVJtKTbuHpyoRjkaAGOPmBXhM.append(WwxiflVJtKTbuHpyoRjkaAGOPmBXrL)
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXhM
 def Make_DecryptKey(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,step,mediacode='000',timecode='000'):
  if step=='1':
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEh=WwxiflVJtKTbuHpyoRjkaAGOPmBXEc('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEq=WwxiflVJtKTbuHpyoRjkaAGOPmBXEc('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEh=WwxiflVJtKTbuHpyoRjkaAGOPmBXEc('kss2lym0kdw1lks3','utf-8')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEq=WwxiflVJtKTbuHpyoRjkaAGOPmBXEc([WwxiflVJtKTbuHpyoRjkaAGOPmBXnd('*'),0x07,WwxiflVJtKTbuHpyoRjkaAGOPmBXnd('r'),WwxiflVJtKTbuHpyoRjkaAGOPmBXnd(';'),WwxiflVJtKTbuHpyoRjkaAGOPmBXnd('7'),0x05,0x1e,0x01,WwxiflVJtKTbuHpyoRjkaAGOPmBXnd('n'),WwxiflVJtKTbuHpyoRjkaAGOPmBXnd('D'),0x02,WwxiflVJtKTbuHpyoRjkaAGOPmBXnd('3'),WwxiflVJtKTbuHpyoRjkaAGOPmBXnd('*'),WwxiflVJtKTbuHpyoRjkaAGOPmBXnd('a'),WwxiflVJtKTbuHpyoRjkaAGOPmBXnd('&'),WwxiflVJtKTbuHpyoRjkaAGOPmBXnd('<')])
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXEh,WwxiflVJtKTbuHpyoRjkaAGOPmBXEq
 def DecryptPlaintext(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,ciphertext,encryption_key,init_vector):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXEr=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  WwxiflVJtKTbuHpyoRjkaAGOPmBXEg=Padding.unpad(WwxiflVJtKTbuHpyoRjkaAGOPmBXEr.decrypt(base64.standard_b64decode(ciphertext)),16)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXEg.decode('utf-8')
 def Decrypt_Url(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg,ciphertext,mediacode,WwxiflVJtKTbuHpyoRjkaAGOPmBXqn):
  WwxiflVJtKTbuHpyoRjkaAGOPmBXEn=''
  WwxiflVJtKTbuHpyoRjkaAGOPmBXqe=''
  WwxiflVJtKTbuHpyoRjkaAGOPmBXqN=''
  try:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEh,WwxiflVJtKTbuHpyoRjkaAGOPmBXEq=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.Make_DecryptKey('1',mediacode=mediacode,timecode=WwxiflVJtKTbuHpyoRjkaAGOPmBXqn)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEe=json.loads(WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.DecryptPlaintext(ciphertext,WwxiflVJtKTbuHpyoRjkaAGOPmBXEh,WwxiflVJtKTbuHpyoRjkaAGOPmBXEq))
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEN =WwxiflVJtKTbuHpyoRjkaAGOPmBXEe.get('broad_url')
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqe =WwxiflVJtKTbuHpyoRjkaAGOPmBXEe.get('watermark') if 'watermark' in WwxiflVJtKTbuHpyoRjkaAGOPmBXEe else ''
   WwxiflVJtKTbuHpyoRjkaAGOPmBXqN=WwxiflVJtKTbuHpyoRjkaAGOPmBXEe.get('watermarkKey')if 'watermarkKey' in WwxiflVJtKTbuHpyoRjkaAGOPmBXEe else ''
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEh,WwxiflVJtKTbuHpyoRjkaAGOPmBXEq=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.Make_DecryptKey('2',mediacode=mediacode,timecode=WwxiflVJtKTbuHpyoRjkaAGOPmBXqn)
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEn=WwxiflVJtKTbuHpyoRjkaAGOPmBXdg.DecryptPlaintext(WwxiflVJtKTbuHpyoRjkaAGOPmBXEN,WwxiflVJtKTbuHpyoRjkaAGOPmBXEh,WwxiflVJtKTbuHpyoRjkaAGOPmBXEq)
  except WwxiflVJtKTbuHpyoRjkaAGOPmBXEU as exception:
   WwxiflVJtKTbuHpyoRjkaAGOPmBXEY(exception)
  return WwxiflVJtKTbuHpyoRjkaAGOPmBXEn,WwxiflVJtKTbuHpyoRjkaAGOPmBXqe,WwxiflVJtKTbuHpyoRjkaAGOPmBXqN
# Created by pyminifier (https://github.com/liftoff/pyminifier)
