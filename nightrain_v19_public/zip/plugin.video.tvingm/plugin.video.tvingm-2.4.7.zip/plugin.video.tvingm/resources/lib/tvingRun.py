__author__="NightRain"
CeAImtYSvEDuqUyQXKsarfMxgLGVNj=object
CeAImtYSvEDuqUyQXKsarfMxgLGVNc=None
CeAImtYSvEDuqUyQXKsarfMxgLGVNl=int
CeAImtYSvEDuqUyQXKsarfMxgLGVNH=True
CeAImtYSvEDuqUyQXKsarfMxgLGVNT=False
CeAImtYSvEDuqUyQXKsarfMxgLGVNR=type
CeAImtYSvEDuqUyQXKsarfMxgLGVNh=dict
CeAImtYSvEDuqUyQXKsarfMxgLGVNn=len
CeAImtYSvEDuqUyQXKsarfMxgLGVNo=str
CeAImtYSvEDuqUyQXKsarfMxgLGVNW=range
CeAImtYSvEDuqUyQXKsarfMxgLGVNO=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
CeAImtYSvEDuqUyQXKsarfMxgLGVzk=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
CeAImtYSvEDuqUyQXKsarfMxgLGVzp=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
CeAImtYSvEDuqUyQXKsarfMxgLGVzP=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
CeAImtYSvEDuqUyQXKsarfMxgLGVzJ=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
CeAImtYSvEDuqUyQXKsarfMxgLGVzB=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
CeAImtYSvEDuqUyQXKsarfMxgLGVzN=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG160,MG140,MG150'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐/클래식','mode':'MOVIE_SUB','stype':'MG250,MG330'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
CeAImtYSvEDuqUyQXKsarfMxgLGVzd=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
CeAImtYSvEDuqUyQXKsarfMxgLGVzj =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
CeAImtYSvEDuqUyQXKsarfMxgLGVzc=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class CeAImtYSvEDuqUyQXKsarfMxgLGVzw(CeAImtYSvEDuqUyQXKsarfMxgLGVNj):
 def __init__(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVzH,CeAImtYSvEDuqUyQXKsarfMxgLGVzT,CeAImtYSvEDuqUyQXKsarfMxgLGVzR):
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_url =CeAImtYSvEDuqUyQXKsarfMxgLGVzH
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle=CeAImtYSvEDuqUyQXKsarfMxgLGVzT
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params =CeAImtYSvEDuqUyQXKsarfMxgLGVzR
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj =WwxiflVJtKTbuHpyoRjkaAGOPmBXdh() 
 def addon_noti(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,sting):
  try:
   CeAImtYSvEDuqUyQXKsarfMxgLGVzn=xbmcgui.Dialog()
   CeAImtYSvEDuqUyQXKsarfMxgLGVzn.notification(__addonname__,sting)
  except:
   CeAImtYSvEDuqUyQXKsarfMxgLGVNc
 def addon_log(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,string):
  try:
   CeAImtYSvEDuqUyQXKsarfMxgLGVzo=string.encode('utf-8','ignore')
  except:
   CeAImtYSvEDuqUyQXKsarfMxgLGVzo='addonException: addon_log'
  CeAImtYSvEDuqUyQXKsarfMxgLGVzW=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,CeAImtYSvEDuqUyQXKsarfMxgLGVzo),level=CeAImtYSvEDuqUyQXKsarfMxgLGVzW)
 def get_keyboard_input(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVwl):
  CeAImtYSvEDuqUyQXKsarfMxgLGVzO=CeAImtYSvEDuqUyQXKsarfMxgLGVNc
  kb=xbmc.Keyboard()
  kb.setHeading(CeAImtYSvEDuqUyQXKsarfMxgLGVwl)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   CeAImtYSvEDuqUyQXKsarfMxgLGVzO=kb.getText()
  return CeAImtYSvEDuqUyQXKsarfMxgLGVzO
 def get_settings_account(CeAImtYSvEDuqUyQXKsarfMxgLGVzl):
  CeAImtYSvEDuqUyQXKsarfMxgLGVzi =__addon__.getSetting('id')
  CeAImtYSvEDuqUyQXKsarfMxgLGVzb =__addon__.getSetting('pw')
  CeAImtYSvEDuqUyQXKsarfMxgLGVzF =__addon__.getSetting('login_type')
  CeAImtYSvEDuqUyQXKsarfMxgLGVwz=CeAImtYSvEDuqUyQXKsarfMxgLGVNl(__addon__.getSetting('selected_profile'))
  return(CeAImtYSvEDuqUyQXKsarfMxgLGVzi,CeAImtYSvEDuqUyQXKsarfMxgLGVzb,CeAImtYSvEDuqUyQXKsarfMxgLGVzF,CeAImtYSvEDuqUyQXKsarfMxgLGVwz)
 def get_settings_uhd(CeAImtYSvEDuqUyQXKsarfMxgLGVzl):
  return CeAImtYSvEDuqUyQXKsarfMxgLGVNH if __addon__.getSetting('active_uhd')=='true' else CeAImtYSvEDuqUyQXKsarfMxgLGVNT
 def get_settings_totalsearch(CeAImtYSvEDuqUyQXKsarfMxgLGVzl):
  CeAImtYSvEDuqUyQXKsarfMxgLGVwk =CeAImtYSvEDuqUyQXKsarfMxgLGVNH if __addon__.getSetting('local_search')=='true' else CeAImtYSvEDuqUyQXKsarfMxgLGVNT
  CeAImtYSvEDuqUyQXKsarfMxgLGVwp=CeAImtYSvEDuqUyQXKsarfMxgLGVNH if __addon__.getSetting('local_history')=='true' else CeAImtYSvEDuqUyQXKsarfMxgLGVNT
  CeAImtYSvEDuqUyQXKsarfMxgLGVwP =CeAImtYSvEDuqUyQXKsarfMxgLGVNH if __addon__.getSetting('total_search')=='true' else CeAImtYSvEDuqUyQXKsarfMxgLGVNT
  CeAImtYSvEDuqUyQXKsarfMxgLGVwJ=CeAImtYSvEDuqUyQXKsarfMxgLGVNH if __addon__.getSetting('total_history')=='true' else CeAImtYSvEDuqUyQXKsarfMxgLGVNT
  CeAImtYSvEDuqUyQXKsarfMxgLGVwB=CeAImtYSvEDuqUyQXKsarfMxgLGVNH if __addon__.getSetting('menu_bookmark')=='true' else CeAImtYSvEDuqUyQXKsarfMxgLGVNT
  return(CeAImtYSvEDuqUyQXKsarfMxgLGVwk,CeAImtYSvEDuqUyQXKsarfMxgLGVwp,CeAImtYSvEDuqUyQXKsarfMxgLGVwP,CeAImtYSvEDuqUyQXKsarfMxgLGVwJ,CeAImtYSvEDuqUyQXKsarfMxgLGVwB)
 def get_settings_makebookmark(CeAImtYSvEDuqUyQXKsarfMxgLGVzl):
  return CeAImtYSvEDuqUyQXKsarfMxgLGVNH if __addon__.getSetting('make_bookmark')=='true' else CeAImtYSvEDuqUyQXKsarfMxgLGVNT
 def get_settings_direct_replay(CeAImtYSvEDuqUyQXKsarfMxgLGVzl):
  CeAImtYSvEDuqUyQXKsarfMxgLGVwN=CeAImtYSvEDuqUyQXKsarfMxgLGVNl(__addon__.getSetting('direct_replay'))
  if CeAImtYSvEDuqUyQXKsarfMxgLGVwN==0:
   return CeAImtYSvEDuqUyQXKsarfMxgLGVNT
  else:
   return CeAImtYSvEDuqUyQXKsarfMxgLGVNH
 def set_winEpisodeOrderby(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVwj):
  __addon__.setSetting('tving_orderby',CeAImtYSvEDuqUyQXKsarfMxgLGVwj)
  CeAImtYSvEDuqUyQXKsarfMxgLGVwd=xbmcgui.Window(10000)
  CeAImtYSvEDuqUyQXKsarfMxgLGVwd.setProperty('TVING_M_ORDERBY',CeAImtYSvEDuqUyQXKsarfMxgLGVwj)
 def get_winEpisodeOrderby(CeAImtYSvEDuqUyQXKsarfMxgLGVzl):
  CeAImtYSvEDuqUyQXKsarfMxgLGVwj=__addon__.getSetting('tving_orderby')
  if CeAImtYSvEDuqUyQXKsarfMxgLGVwj in['',CeAImtYSvEDuqUyQXKsarfMxgLGVNc]:CeAImtYSvEDuqUyQXKsarfMxgLGVwj='desc'
  return CeAImtYSvEDuqUyQXKsarfMxgLGVwj
 def add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,label,sublabel='',img='',infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params='',isLink=CeAImtYSvEDuqUyQXKsarfMxgLGVNT,ContextMenu=CeAImtYSvEDuqUyQXKsarfMxgLGVNc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVwc='%s?%s'%(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_url,urllib.parse.urlencode(params))
  if sublabel:CeAImtYSvEDuqUyQXKsarfMxgLGVwl='%s < %s >'%(label,sublabel)
  else: CeAImtYSvEDuqUyQXKsarfMxgLGVwl=label
  if not img:img='DefaultFolder.png'
  CeAImtYSvEDuqUyQXKsarfMxgLGVwH=xbmcgui.ListItem(CeAImtYSvEDuqUyQXKsarfMxgLGVwl)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVNR(img)==CeAImtYSvEDuqUyQXKsarfMxgLGVNh:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwH.setArt(img)
  else:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwH.setArt({'thumb':img,'poster':img})
  if infoLabels:CeAImtYSvEDuqUyQXKsarfMxgLGVwH.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwH.setProperty('IsPlayable','true')
  if ContextMenu:CeAImtYSvEDuqUyQXKsarfMxgLGVwH.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,CeAImtYSvEDuqUyQXKsarfMxgLGVwc,CeAImtYSvEDuqUyQXKsarfMxgLGVwH,isFolder)
 def get_selQuality(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,etype):
  try:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwT='selected_quality'
   CeAImtYSvEDuqUyQXKsarfMxgLGVwR=[1080,720,480,360]
   CeAImtYSvEDuqUyQXKsarfMxgLGVwh=CeAImtYSvEDuqUyQXKsarfMxgLGVNl(__addon__.getSetting(CeAImtYSvEDuqUyQXKsarfMxgLGVwT))
   return CeAImtYSvEDuqUyQXKsarfMxgLGVwR[CeAImtYSvEDuqUyQXKsarfMxgLGVwh]
  except:
   CeAImtYSvEDuqUyQXKsarfMxgLGVNc
  return 720 
 def dp_Main_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl):
  (CeAImtYSvEDuqUyQXKsarfMxgLGVwk,CeAImtYSvEDuqUyQXKsarfMxgLGVwp,CeAImtYSvEDuqUyQXKsarfMxgLGVwP,CeAImtYSvEDuqUyQXKsarfMxgLGVwJ,CeAImtYSvEDuqUyQXKsarfMxgLGVwB)=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_settings_totalsearch()
  for CeAImtYSvEDuqUyQXKsarfMxgLGVwn in CeAImtYSvEDuqUyQXKsarfMxgLGVzk:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl=CeAImtYSvEDuqUyQXKsarfMxgLGVwn.get('title')
   CeAImtYSvEDuqUyQXKsarfMxgLGVwo=''
   if CeAImtYSvEDuqUyQXKsarfMxgLGVwn.get('mode')=='SEARCH_GROUP' and CeAImtYSvEDuqUyQXKsarfMxgLGVwk ==CeAImtYSvEDuqUyQXKsarfMxgLGVNT:continue
   elif CeAImtYSvEDuqUyQXKsarfMxgLGVwn.get('mode')=='SEARCH_HISTORY' and CeAImtYSvEDuqUyQXKsarfMxgLGVwp==CeAImtYSvEDuqUyQXKsarfMxgLGVNT:continue
   elif CeAImtYSvEDuqUyQXKsarfMxgLGVwn.get('mode')=='TOTAL_SEARCH' and CeAImtYSvEDuqUyQXKsarfMxgLGVwP ==CeAImtYSvEDuqUyQXKsarfMxgLGVNT:continue
   elif CeAImtYSvEDuqUyQXKsarfMxgLGVwn.get('mode')=='TOTAL_HISTORY' and CeAImtYSvEDuqUyQXKsarfMxgLGVwJ==CeAImtYSvEDuqUyQXKsarfMxgLGVNT:continue
   elif CeAImtYSvEDuqUyQXKsarfMxgLGVwn.get('mode')=='MENU_BOOKMARK' and CeAImtYSvEDuqUyQXKsarfMxgLGVwB==CeAImtYSvEDuqUyQXKsarfMxgLGVNT:continue
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':CeAImtYSvEDuqUyQXKsarfMxgLGVwn.get('mode'),'stype':CeAImtYSvEDuqUyQXKsarfMxgLGVwn.get('stype'),'orderby':CeAImtYSvEDuqUyQXKsarfMxgLGVwn.get('orderby'),'ordernm':CeAImtYSvEDuqUyQXKsarfMxgLGVwn.get('ordernm'),'page':'1'}
   if CeAImtYSvEDuqUyQXKsarfMxgLGVwn.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    CeAImtYSvEDuqUyQXKsarfMxgLGVwO=CeAImtYSvEDuqUyQXKsarfMxgLGVNT
    CeAImtYSvEDuqUyQXKsarfMxgLGVwi =CeAImtYSvEDuqUyQXKsarfMxgLGVNH
   else:
    CeAImtYSvEDuqUyQXKsarfMxgLGVwO=CeAImtYSvEDuqUyQXKsarfMxgLGVNH
    CeAImtYSvEDuqUyQXKsarfMxgLGVwi =CeAImtYSvEDuqUyQXKsarfMxgLGVNT
   if 'icon' in CeAImtYSvEDuqUyQXKsarfMxgLGVwn:CeAImtYSvEDuqUyQXKsarfMxgLGVwo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',CeAImtYSvEDuqUyQXKsarfMxgLGVwn.get('icon')) 
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel='',img=CeAImtYSvEDuqUyQXKsarfMxgLGVwo,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVwO,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW,isLink=CeAImtYSvEDuqUyQXKsarfMxgLGVwi)
  xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle)
 def login_main(CeAImtYSvEDuqUyQXKsarfMxgLGVzl):
  (CeAImtYSvEDuqUyQXKsarfMxgLGVwF,CeAImtYSvEDuqUyQXKsarfMxgLGVkz,CeAImtYSvEDuqUyQXKsarfMxgLGVkw,CeAImtYSvEDuqUyQXKsarfMxgLGVkp)=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_settings_account()
  if not(CeAImtYSvEDuqUyQXKsarfMxgLGVwF and CeAImtYSvEDuqUyQXKsarfMxgLGVkz):
   CeAImtYSvEDuqUyQXKsarfMxgLGVzn=xbmcgui.Dialog()
   CeAImtYSvEDuqUyQXKsarfMxgLGVkP=CeAImtYSvEDuqUyQXKsarfMxgLGVzn.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if CeAImtYSvEDuqUyQXKsarfMxgLGVkP==CeAImtYSvEDuqUyQXKsarfMxgLGVNH:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if CeAImtYSvEDuqUyQXKsarfMxgLGVzl.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   CeAImtYSvEDuqUyQXKsarfMxgLGVkJ=0
   while CeAImtYSvEDuqUyQXKsarfMxgLGVNH:
    CeAImtYSvEDuqUyQXKsarfMxgLGVkJ+=1
    time.sleep(0.05)
    if CeAImtYSvEDuqUyQXKsarfMxgLGVkJ>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  CeAImtYSvEDuqUyQXKsarfMxgLGVkB=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.GetCredential(CeAImtYSvEDuqUyQXKsarfMxgLGVwF,CeAImtYSvEDuqUyQXKsarfMxgLGVkz,CeAImtYSvEDuqUyQXKsarfMxgLGVkw,CeAImtYSvEDuqUyQXKsarfMxgLGVkp)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkB:CeAImtYSvEDuqUyQXKsarfMxgLGVzl.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkB==CeAImtYSvEDuqUyQXKsarfMxgLGVNT:
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVkN=CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('stype')
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkN=='live':
   CeAImtYSvEDuqUyQXKsarfMxgLGVkd=CeAImtYSvEDuqUyQXKsarfMxgLGVzp
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVkN=='vod':
   CeAImtYSvEDuqUyQXKsarfMxgLGVkd=CeAImtYSvEDuqUyQXKsarfMxgLGVzB
  else:
   CeAImtYSvEDuqUyQXKsarfMxgLGVkd=CeAImtYSvEDuqUyQXKsarfMxgLGVzN
  for CeAImtYSvEDuqUyQXKsarfMxgLGVkj in CeAImtYSvEDuqUyQXKsarfMxgLGVkd:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl=CeAImtYSvEDuqUyQXKsarfMxgLGVkj.get('title')
   if CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('ordernm')!='-':
    CeAImtYSvEDuqUyQXKsarfMxgLGVwl+='  ('+CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('ordernm')+')'
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':CeAImtYSvEDuqUyQXKsarfMxgLGVkj.get('mode'),'stype':CeAImtYSvEDuqUyQXKsarfMxgLGVkj.get('stype'),'orderby':CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('orderby'),'ordernm':CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('ordernm'),'page':'1'}
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel='',img='',infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVNn(CeAImtYSvEDuqUyQXKsarfMxgLGVkd)>0:xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle)
 def dp_SubTitle_Group(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc): 
  for CeAImtYSvEDuqUyQXKsarfMxgLGVkj in CeAImtYSvEDuqUyQXKsarfMxgLGVzd:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl=CeAImtYSvEDuqUyQXKsarfMxgLGVkj.get('title')
   if CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('ordernm')!='-':
    CeAImtYSvEDuqUyQXKsarfMxgLGVwl+='  ('+CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('ordernm')+')'
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':CeAImtYSvEDuqUyQXKsarfMxgLGVkj.get('mode'),'genreCode':CeAImtYSvEDuqUyQXKsarfMxgLGVkj.get('genreCode'),'stype':CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('stype'),'orderby':CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('orderby'),'page':'1'}
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel='',img='',infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVNn(CeAImtYSvEDuqUyQXKsarfMxgLGVzd)>0:xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle)
 def dp_LiveChannel_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVkN =CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('stype')
  CeAImtYSvEDuqUyQXKsarfMxgLGVkl =CeAImtYSvEDuqUyQXKsarfMxgLGVNl(CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('page'))
  CeAImtYSvEDuqUyQXKsarfMxgLGVkH,CeAImtYSvEDuqUyQXKsarfMxgLGVkT=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.GetLiveChannelList(CeAImtYSvEDuqUyQXKsarfMxgLGVkN,CeAImtYSvEDuqUyQXKsarfMxgLGVkl)
  for CeAImtYSvEDuqUyQXKsarfMxgLGVkR in CeAImtYSvEDuqUyQXKsarfMxgLGVkH:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('title')
   CeAImtYSvEDuqUyQXKsarfMxgLGVwb =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('channel')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkh =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('thumbnail')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkn =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('synopsis')
   CeAImtYSvEDuqUyQXKsarfMxgLGVko =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('channelepg')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkW =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('cast')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkO =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('director')
   CeAImtYSvEDuqUyQXKsarfMxgLGVki =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('info_genre')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkb =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('year')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkF =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('mpaa')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpz =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('premiered')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpw={'mediatype':'episode','title':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'studio':CeAImtYSvEDuqUyQXKsarfMxgLGVwb,'cast':CeAImtYSvEDuqUyQXKsarfMxgLGVkW,'director':CeAImtYSvEDuqUyQXKsarfMxgLGVkO,'genre':CeAImtYSvEDuqUyQXKsarfMxgLGVki,'plot':'%s\n%s\n%s\n\n%s'%(CeAImtYSvEDuqUyQXKsarfMxgLGVwb,CeAImtYSvEDuqUyQXKsarfMxgLGVwl,CeAImtYSvEDuqUyQXKsarfMxgLGVko,CeAImtYSvEDuqUyQXKsarfMxgLGVkn),'year':CeAImtYSvEDuqUyQXKsarfMxgLGVkb,'mpaa':CeAImtYSvEDuqUyQXKsarfMxgLGVkF,'premiered':CeAImtYSvEDuqUyQXKsarfMxgLGVpz}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'LIVE','mediacode':CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('mediacode'),'stype':CeAImtYSvEDuqUyQXKsarfMxgLGVkN}
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwb,sublabel=CeAImtYSvEDuqUyQXKsarfMxgLGVwl,img=CeAImtYSvEDuqUyQXKsarfMxgLGVkh,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVpw,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNT,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkT:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['mode']='CHANNEL' 
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['stype']=CeAImtYSvEDuqUyQXKsarfMxgLGVkN 
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['page']=CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl='[B]%s >>[/B]'%'다음 페이지'
   CeAImtYSvEDuqUyQXKsarfMxgLGVpk=CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel=CeAImtYSvEDuqUyQXKsarfMxgLGVpk,img=CeAImtYSvEDuqUyQXKsarfMxgLGVwo,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVNn(CeAImtYSvEDuqUyQXKsarfMxgLGVkH)>0:xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,cacheToDisc=CeAImtYSvEDuqUyQXKsarfMxgLGVNT)
 def dp_Program_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVpP =CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('stype')
  CeAImtYSvEDuqUyQXKsarfMxgLGVwj =CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('orderby')
  CeAImtYSvEDuqUyQXKsarfMxgLGVkl =CeAImtYSvEDuqUyQXKsarfMxgLGVNl(CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('page'))
  CeAImtYSvEDuqUyQXKsarfMxgLGVpJ=CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('genreCode')
  if CeAImtYSvEDuqUyQXKsarfMxgLGVpJ==CeAImtYSvEDuqUyQXKsarfMxgLGVNc:CeAImtYSvEDuqUyQXKsarfMxgLGVpJ='all'
  CeAImtYSvEDuqUyQXKsarfMxgLGVpB,CeAImtYSvEDuqUyQXKsarfMxgLGVkT=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.GetProgramList(CeAImtYSvEDuqUyQXKsarfMxgLGVpP,CeAImtYSvEDuqUyQXKsarfMxgLGVwj,CeAImtYSvEDuqUyQXKsarfMxgLGVkl,CeAImtYSvEDuqUyQXKsarfMxgLGVpJ)
  for CeAImtYSvEDuqUyQXKsarfMxgLGVpN in CeAImtYSvEDuqUyQXKsarfMxgLGVpB:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('title')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkh =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('thumbnail')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkn =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('synopsis')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpd =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('channel')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkW =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('cast')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkO =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('director')
   CeAImtYSvEDuqUyQXKsarfMxgLGVki=CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('info_genre')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkb =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('year')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpz =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('premiered')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkF =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('mpaa')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpw={'mediatype':'tvshow','title':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'studio':CeAImtYSvEDuqUyQXKsarfMxgLGVpd,'cast':CeAImtYSvEDuqUyQXKsarfMxgLGVkW,'director':CeAImtYSvEDuqUyQXKsarfMxgLGVkO,'genre':CeAImtYSvEDuqUyQXKsarfMxgLGVki,'year':CeAImtYSvEDuqUyQXKsarfMxgLGVkb,'premiered':CeAImtYSvEDuqUyQXKsarfMxgLGVpz,'mpaa':CeAImtYSvEDuqUyQXKsarfMxgLGVkF,'plot':CeAImtYSvEDuqUyQXKsarfMxgLGVkn}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'EPISODE','programcode':CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('program'),'page':'1'}
   if CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_settings_makebookmark():
    CeAImtYSvEDuqUyQXKsarfMxgLGVpj={'videoid':CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('program'),'vidtype':'tvshow','vtitle':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'vsubtitle':CeAImtYSvEDuqUyQXKsarfMxgLGVpd,}
    CeAImtYSvEDuqUyQXKsarfMxgLGVpc=json.dumps(CeAImtYSvEDuqUyQXKsarfMxgLGVpj)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpc=urllib.parse.quote(CeAImtYSvEDuqUyQXKsarfMxgLGVpc)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpl='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(CeAImtYSvEDuqUyQXKsarfMxgLGVpc)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpH=[('(통합) 찜 영상에 추가',CeAImtYSvEDuqUyQXKsarfMxgLGVpl)]
   else:
    CeAImtYSvEDuqUyQXKsarfMxgLGVpH=CeAImtYSvEDuqUyQXKsarfMxgLGVNc
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel=CeAImtYSvEDuqUyQXKsarfMxgLGVpd,img=CeAImtYSvEDuqUyQXKsarfMxgLGVkh,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVpw,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW,ContextMenu=CeAImtYSvEDuqUyQXKsarfMxgLGVpH)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkT:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['mode'] ='PROGRAM' 
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['stype'] =CeAImtYSvEDuqUyQXKsarfMxgLGVpP
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['orderby'] =CeAImtYSvEDuqUyQXKsarfMxgLGVwj
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['page'] =CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['genreCode']=CeAImtYSvEDuqUyQXKsarfMxgLGVpJ 
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl='[B]%s >>[/B]'%'다음 페이지'
   CeAImtYSvEDuqUyQXKsarfMxgLGVpk=CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel=CeAImtYSvEDuqUyQXKsarfMxgLGVpk,img=CeAImtYSvEDuqUyQXKsarfMxgLGVwo,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  xbmcplugin.setContent(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,cacheToDisc=CeAImtYSvEDuqUyQXKsarfMxgLGVNT)
 def dp_4K_Program_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVkl =CeAImtYSvEDuqUyQXKsarfMxgLGVNl(CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('page'))
  CeAImtYSvEDuqUyQXKsarfMxgLGVpB,CeAImtYSvEDuqUyQXKsarfMxgLGVkT=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.Get_UHD_ProgramList(CeAImtYSvEDuqUyQXKsarfMxgLGVkl)
  for CeAImtYSvEDuqUyQXKsarfMxgLGVpN in CeAImtYSvEDuqUyQXKsarfMxgLGVpB:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('title')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkh =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('thumbnail')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkn =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('synopsis')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpd =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('channel')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkW =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('cast')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkO =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('director')
   CeAImtYSvEDuqUyQXKsarfMxgLGVki=CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('info_genre')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkb =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('year')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpz =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('premiered')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkF =CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('mpaa')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpw={'mediatype':'tvshow','title':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'studio':CeAImtYSvEDuqUyQXKsarfMxgLGVpd,'cast':CeAImtYSvEDuqUyQXKsarfMxgLGVkW,'director':CeAImtYSvEDuqUyQXKsarfMxgLGVkO,'genre':CeAImtYSvEDuqUyQXKsarfMxgLGVki,'year':CeAImtYSvEDuqUyQXKsarfMxgLGVkb,'premiered':CeAImtYSvEDuqUyQXKsarfMxgLGVpz,'mpaa':CeAImtYSvEDuqUyQXKsarfMxgLGVkF,'plot':CeAImtYSvEDuqUyQXKsarfMxgLGVkn}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'EPISODE','programcode':CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('program'),'page':'1'}
   if CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_settings_makebookmark():
    CeAImtYSvEDuqUyQXKsarfMxgLGVpj={'videoid':CeAImtYSvEDuqUyQXKsarfMxgLGVpN.get('program'),'vidtype':'tvshow','vtitle':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'vsubtitle':CeAImtYSvEDuqUyQXKsarfMxgLGVpd,}
    CeAImtYSvEDuqUyQXKsarfMxgLGVpc=json.dumps(CeAImtYSvEDuqUyQXKsarfMxgLGVpj)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpc=urllib.parse.quote(CeAImtYSvEDuqUyQXKsarfMxgLGVpc)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpl='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(CeAImtYSvEDuqUyQXKsarfMxgLGVpc)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpH=[('(통합) 찜 영상에 추가',CeAImtYSvEDuqUyQXKsarfMxgLGVpl)]
   else:
    CeAImtYSvEDuqUyQXKsarfMxgLGVpH=CeAImtYSvEDuqUyQXKsarfMxgLGVNc
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel=CeAImtYSvEDuqUyQXKsarfMxgLGVpd,img=CeAImtYSvEDuqUyQXKsarfMxgLGVkh,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVpw,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW,ContextMenu=CeAImtYSvEDuqUyQXKsarfMxgLGVpH)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkT:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['mode'] ='4K_PROGRAM' 
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['page'] =CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl='[B]%s >>[/B]'%'다음 페이지'
   CeAImtYSvEDuqUyQXKsarfMxgLGVpk=CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel=CeAImtYSvEDuqUyQXKsarfMxgLGVpk,img=CeAImtYSvEDuqUyQXKsarfMxgLGVwo,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  xbmcplugin.setContent(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,cacheToDisc=CeAImtYSvEDuqUyQXKsarfMxgLGVNT)
 def dp_Episode_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVpR=CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('programcode')
  CeAImtYSvEDuqUyQXKsarfMxgLGVkl =CeAImtYSvEDuqUyQXKsarfMxgLGVNl(CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('page'))
  CeAImtYSvEDuqUyQXKsarfMxgLGVph,CeAImtYSvEDuqUyQXKsarfMxgLGVkT,CeAImtYSvEDuqUyQXKsarfMxgLGVpn=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.GetEpisodeList(CeAImtYSvEDuqUyQXKsarfMxgLGVpR,CeAImtYSvEDuqUyQXKsarfMxgLGVkl,orderby=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_winEpisodeOrderby())
  for CeAImtYSvEDuqUyQXKsarfMxgLGVpo in CeAImtYSvEDuqUyQXKsarfMxgLGVph:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl =CeAImtYSvEDuqUyQXKsarfMxgLGVpo.get('title')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpk =CeAImtYSvEDuqUyQXKsarfMxgLGVpo.get('subtitle')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkh =CeAImtYSvEDuqUyQXKsarfMxgLGVpo.get('thumbnail')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkn =CeAImtYSvEDuqUyQXKsarfMxgLGVpo.get('synopsis')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpW=CeAImtYSvEDuqUyQXKsarfMxgLGVpo.get('info_title')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpO =CeAImtYSvEDuqUyQXKsarfMxgLGVpo.get('aired')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpi =CeAImtYSvEDuqUyQXKsarfMxgLGVpo.get('studio')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpb =CeAImtYSvEDuqUyQXKsarfMxgLGVpo.get('frequency')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpw={'mediatype':'episode','title':CeAImtYSvEDuqUyQXKsarfMxgLGVpW,'aired':CeAImtYSvEDuqUyQXKsarfMxgLGVpO,'studio':CeAImtYSvEDuqUyQXKsarfMxgLGVpi,'episode':CeAImtYSvEDuqUyQXKsarfMxgLGVpb,'plot':CeAImtYSvEDuqUyQXKsarfMxgLGVkn}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'VOD','mediacode':CeAImtYSvEDuqUyQXKsarfMxgLGVpo.get('episode'),'stype':'vod','programcode':CeAImtYSvEDuqUyQXKsarfMxgLGVpR,'title':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'thumbnail':CeAImtYSvEDuqUyQXKsarfMxgLGVkh}
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel=CeAImtYSvEDuqUyQXKsarfMxgLGVpk,img=CeAImtYSvEDuqUyQXKsarfMxgLGVkh,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVpw,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNT,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkl==1:
   CeAImtYSvEDuqUyQXKsarfMxgLGVpw={'plot':'정렬순서를 변경합니다.'}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['mode'] ='ORDER_BY' 
   if CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_winEpisodeOrderby()=='desc':
    CeAImtYSvEDuqUyQXKsarfMxgLGVwl='정렬순서변경 : 최신화부터 -> 1회부터'
    CeAImtYSvEDuqUyQXKsarfMxgLGVwW['orderby']='asc'
   else:
    CeAImtYSvEDuqUyQXKsarfMxgLGVwl='정렬순서변경 : 1회부터 -> 최신화부터'
    CeAImtYSvEDuqUyQXKsarfMxgLGVwW['orderby']='desc'
   CeAImtYSvEDuqUyQXKsarfMxgLGVwo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel='',img=CeAImtYSvEDuqUyQXKsarfMxgLGVwo,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVpw,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNT,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW,isLink=CeAImtYSvEDuqUyQXKsarfMxgLGVNH)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkT:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['mode'] ='EPISODE' 
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['programcode']=CeAImtYSvEDuqUyQXKsarfMxgLGVpR
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['page'] =CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl='[B]%s >>[/B]'%'다음 페이지'
   CeAImtYSvEDuqUyQXKsarfMxgLGVpk=CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel=CeAImtYSvEDuqUyQXKsarfMxgLGVpk,img=CeAImtYSvEDuqUyQXKsarfMxgLGVwo,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  xbmcplugin.setContent(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,'episodes')
  if CeAImtYSvEDuqUyQXKsarfMxgLGVNn(CeAImtYSvEDuqUyQXKsarfMxgLGVph)>0:xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,cacheToDisc=CeAImtYSvEDuqUyQXKsarfMxgLGVNH)
 def dp_setEpOrderby(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVwj =CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('orderby')
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.set_winEpisodeOrderby(CeAImtYSvEDuqUyQXKsarfMxgLGVwj)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVpP =CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('stype')
  CeAImtYSvEDuqUyQXKsarfMxgLGVwj =CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('orderby')
  CeAImtYSvEDuqUyQXKsarfMxgLGVkl=CeAImtYSvEDuqUyQXKsarfMxgLGVNl(CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('page'))
  CeAImtYSvEDuqUyQXKsarfMxgLGVpF,CeAImtYSvEDuqUyQXKsarfMxgLGVkT=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.GetMovieList(CeAImtYSvEDuqUyQXKsarfMxgLGVpP,CeAImtYSvEDuqUyQXKsarfMxgLGVwj,CeAImtYSvEDuqUyQXKsarfMxgLGVkl)
  for CeAImtYSvEDuqUyQXKsarfMxgLGVPz in CeAImtYSvEDuqUyQXKsarfMxgLGVpF:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('title')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkh =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('thumbnail')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkn =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('synopsis')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpW =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('info_title')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkb =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('year')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkW =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('cast')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkO =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('director')
   CeAImtYSvEDuqUyQXKsarfMxgLGVki =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('info_genre')
   CeAImtYSvEDuqUyQXKsarfMxgLGVPw =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('duration')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpz =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('premiered')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpi =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('studio')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkF =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('mpaa')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpw={'mediatype':'movie','title':CeAImtYSvEDuqUyQXKsarfMxgLGVpW,'year':CeAImtYSvEDuqUyQXKsarfMxgLGVkb,'cast':CeAImtYSvEDuqUyQXKsarfMxgLGVkW,'director':CeAImtYSvEDuqUyQXKsarfMxgLGVkO,'genre':CeAImtYSvEDuqUyQXKsarfMxgLGVki,'duration':CeAImtYSvEDuqUyQXKsarfMxgLGVPw,'premiered':CeAImtYSvEDuqUyQXKsarfMxgLGVpz,'studio':CeAImtYSvEDuqUyQXKsarfMxgLGVpi,'mpaa':CeAImtYSvEDuqUyQXKsarfMxgLGVkF,'plot':CeAImtYSvEDuqUyQXKsarfMxgLGVkn}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'MOVIE','mediacode':CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('moviecode'),'stype':'movie','title':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'thumbnail':CeAImtYSvEDuqUyQXKsarfMxgLGVkh}
   if CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_settings_makebookmark():
    CeAImtYSvEDuqUyQXKsarfMxgLGVpj={'videoid':CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('moviecode'),'vidtype':'movie','vtitle':CeAImtYSvEDuqUyQXKsarfMxgLGVpW,'vsubtitle':'',}
    CeAImtYSvEDuqUyQXKsarfMxgLGVpc=json.dumps(CeAImtYSvEDuqUyQXKsarfMxgLGVpj)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpc=urllib.parse.quote(CeAImtYSvEDuqUyQXKsarfMxgLGVpc)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpl='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(CeAImtYSvEDuqUyQXKsarfMxgLGVpc)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpH=[('(통합) 찜 영상에 추가',CeAImtYSvEDuqUyQXKsarfMxgLGVpl)]
   else:
    CeAImtYSvEDuqUyQXKsarfMxgLGVpH=CeAImtYSvEDuqUyQXKsarfMxgLGVNc
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel='',img=CeAImtYSvEDuqUyQXKsarfMxgLGVkh,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVpw,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNT,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW,ContextMenu=CeAImtYSvEDuqUyQXKsarfMxgLGVpH)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkT:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['mode'] ='MOVIE_SUB' 
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['orderby']=CeAImtYSvEDuqUyQXKsarfMxgLGVwj
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['stype'] =CeAImtYSvEDuqUyQXKsarfMxgLGVpP
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['page'] =CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl='[B]%s >>[/B]'%'다음 페이지'
   CeAImtYSvEDuqUyQXKsarfMxgLGVpk=CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel=CeAImtYSvEDuqUyQXKsarfMxgLGVpk,img=CeAImtYSvEDuqUyQXKsarfMxgLGVwo,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  xbmcplugin.setContent(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,'movies')
  xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,cacheToDisc=CeAImtYSvEDuqUyQXKsarfMxgLGVNT)
 def dp_4K_Movie_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVkl=CeAImtYSvEDuqUyQXKsarfMxgLGVNl(CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('page'))
  CeAImtYSvEDuqUyQXKsarfMxgLGVpF,CeAImtYSvEDuqUyQXKsarfMxgLGVkT=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.Get_UHD_MovieList(CeAImtYSvEDuqUyQXKsarfMxgLGVkl)
  for CeAImtYSvEDuqUyQXKsarfMxgLGVPz in CeAImtYSvEDuqUyQXKsarfMxgLGVpF:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('title')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkh =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('thumbnail')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkn =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('synopsis')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpW =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('info_title')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkb =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('year')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkW =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('cast')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkO =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('director')
   CeAImtYSvEDuqUyQXKsarfMxgLGVki =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('info_genre')
   CeAImtYSvEDuqUyQXKsarfMxgLGVPw =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('duration')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpz =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('premiered')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpi =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('studio')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkF =CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('mpaa')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpw={'mediatype':'movie','title':CeAImtYSvEDuqUyQXKsarfMxgLGVpW,'year':CeAImtYSvEDuqUyQXKsarfMxgLGVkb,'cast':CeAImtYSvEDuqUyQXKsarfMxgLGVkW,'director':CeAImtYSvEDuqUyQXKsarfMxgLGVkO,'genre':CeAImtYSvEDuqUyQXKsarfMxgLGVki,'duration':CeAImtYSvEDuqUyQXKsarfMxgLGVPw,'premiered':CeAImtYSvEDuqUyQXKsarfMxgLGVpz,'studio':CeAImtYSvEDuqUyQXKsarfMxgLGVpi,'mpaa':CeAImtYSvEDuqUyQXKsarfMxgLGVkF,'plot':CeAImtYSvEDuqUyQXKsarfMxgLGVkn}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'MOVIE','mediacode':CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('moviecode'),'stype':'movie','title':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'thumbnail':CeAImtYSvEDuqUyQXKsarfMxgLGVkh}
   if CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_settings_makebookmark():
    CeAImtYSvEDuqUyQXKsarfMxgLGVpj={'videoid':CeAImtYSvEDuqUyQXKsarfMxgLGVPz.get('moviecode'),'vidtype':'movie','vtitle':CeAImtYSvEDuqUyQXKsarfMxgLGVpW,'vsubtitle':'',}
    CeAImtYSvEDuqUyQXKsarfMxgLGVpc=json.dumps(CeAImtYSvEDuqUyQXKsarfMxgLGVpj)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpc=urllib.parse.quote(CeAImtYSvEDuqUyQXKsarfMxgLGVpc)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpl='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(CeAImtYSvEDuqUyQXKsarfMxgLGVpc)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpH=[('(통합) 찜 영상에 추가',CeAImtYSvEDuqUyQXKsarfMxgLGVpl)]
   else:
    CeAImtYSvEDuqUyQXKsarfMxgLGVpH=CeAImtYSvEDuqUyQXKsarfMxgLGVNc
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel='',img=CeAImtYSvEDuqUyQXKsarfMxgLGVkh,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVpw,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNT,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW,ContextMenu=CeAImtYSvEDuqUyQXKsarfMxgLGVpH)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkT:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['mode'] ='4K_MOVIE' 
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['page'] =CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl='[B]%s >>[/B]'%'다음 페이지'
   CeAImtYSvEDuqUyQXKsarfMxgLGVpk=CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel=CeAImtYSvEDuqUyQXKsarfMxgLGVpk,img=CeAImtYSvEDuqUyQXKsarfMxgLGVwo,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  xbmcplugin.setContent(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,'movies')
  xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,cacheToDisc=CeAImtYSvEDuqUyQXKsarfMxgLGVNT)
 def dp_Set_Bookmark(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVPk=urllib.parse.unquote(CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('bm_param'))
  CeAImtYSvEDuqUyQXKsarfMxgLGVPk=json.loads(CeAImtYSvEDuqUyQXKsarfMxgLGVPk)
  CeAImtYSvEDuqUyQXKsarfMxgLGVPp =CeAImtYSvEDuqUyQXKsarfMxgLGVPk.get('videoid')
  CeAImtYSvEDuqUyQXKsarfMxgLGVPJ =CeAImtYSvEDuqUyQXKsarfMxgLGVPk.get('vidtype')
  CeAImtYSvEDuqUyQXKsarfMxgLGVPB =CeAImtYSvEDuqUyQXKsarfMxgLGVPk.get('vtitle')
  CeAImtYSvEDuqUyQXKsarfMxgLGVPN =CeAImtYSvEDuqUyQXKsarfMxgLGVPk.get('vsubtitle')
  CeAImtYSvEDuqUyQXKsarfMxgLGVzn=xbmcgui.Dialog()
  CeAImtYSvEDuqUyQXKsarfMxgLGVkP=CeAImtYSvEDuqUyQXKsarfMxgLGVzn.yesno(__language__(30913).encode('utf8'),CeAImtYSvEDuqUyQXKsarfMxgLGVPB+' \n\n'+__language__(30914))
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkP==CeAImtYSvEDuqUyQXKsarfMxgLGVNT:return
  CeAImtYSvEDuqUyQXKsarfMxgLGVPd=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.GetBookmarkInfo(CeAImtYSvEDuqUyQXKsarfMxgLGVPp,CeAImtYSvEDuqUyQXKsarfMxgLGVPJ)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVPN!='':
   CeAImtYSvEDuqUyQXKsarfMxgLGVPd['saveinfo']['subtitle']=CeAImtYSvEDuqUyQXKsarfMxgLGVPN 
   if CeAImtYSvEDuqUyQXKsarfMxgLGVPJ=='tvshow':CeAImtYSvEDuqUyQXKsarfMxgLGVPd['saveinfo']['infoLabels']['studio']=CeAImtYSvEDuqUyQXKsarfMxgLGVPN 
  CeAImtYSvEDuqUyQXKsarfMxgLGVPj=json.dumps(CeAImtYSvEDuqUyQXKsarfMxgLGVPd)
  CeAImtYSvEDuqUyQXKsarfMxgLGVPj=urllib.parse.quote(CeAImtYSvEDuqUyQXKsarfMxgLGVPj)
  CeAImtYSvEDuqUyQXKsarfMxgLGVpl ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(CeAImtYSvEDuqUyQXKsarfMxgLGVPj)
  xbmc.executebuiltin(CeAImtYSvEDuqUyQXKsarfMxgLGVpl)
 def dp_Search_Group(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  if 'search_key' in CeAImtYSvEDuqUyQXKsarfMxgLGVkc:
   CeAImtYSvEDuqUyQXKsarfMxgLGVPc=CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('search_key')
  else:
   CeAImtYSvEDuqUyQXKsarfMxgLGVPc=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not CeAImtYSvEDuqUyQXKsarfMxgLGVPc:
    return
  for CeAImtYSvEDuqUyQXKsarfMxgLGVkj in CeAImtYSvEDuqUyQXKsarfMxgLGVzJ:
   CeAImtYSvEDuqUyQXKsarfMxgLGVPl =CeAImtYSvEDuqUyQXKsarfMxgLGVkj.get('mode')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkN=CeAImtYSvEDuqUyQXKsarfMxgLGVkj.get('stype')
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl=CeAImtYSvEDuqUyQXKsarfMxgLGVkj.get('title')
   (CeAImtYSvEDuqUyQXKsarfMxgLGVPH,CeAImtYSvEDuqUyQXKsarfMxgLGVkT)=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.GetSearchList(CeAImtYSvEDuqUyQXKsarfMxgLGVPc,1,CeAImtYSvEDuqUyQXKsarfMxgLGVkN)
   CeAImtYSvEDuqUyQXKsarfMxgLGVPT={'plot':'검색어 : '+CeAImtYSvEDuqUyQXKsarfMxgLGVPc+'\n\n'+CeAImtYSvEDuqUyQXKsarfMxgLGVzl.Search_FreeList(CeAImtYSvEDuqUyQXKsarfMxgLGVPH)}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':CeAImtYSvEDuqUyQXKsarfMxgLGVPl,'stype':CeAImtYSvEDuqUyQXKsarfMxgLGVkN,'search_key':CeAImtYSvEDuqUyQXKsarfMxgLGVPc,'page':'1',}
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel='',img='',infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVPT,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVNn(CeAImtYSvEDuqUyQXKsarfMxgLGVzJ)>0:xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,cacheToDisc=CeAImtYSvEDuqUyQXKsarfMxgLGVNH)
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.Save_Searched_List(CeAImtYSvEDuqUyQXKsarfMxgLGVPc)
 def Search_FreeList(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVPF):
  CeAImtYSvEDuqUyQXKsarfMxgLGVPR=''
  CeAImtYSvEDuqUyQXKsarfMxgLGVPh=7
  try:
   if CeAImtYSvEDuqUyQXKsarfMxgLGVNn(CeAImtYSvEDuqUyQXKsarfMxgLGVPF)==0:return '검색결과 없음'
   for i in CeAImtYSvEDuqUyQXKsarfMxgLGVNW(CeAImtYSvEDuqUyQXKsarfMxgLGVNn(CeAImtYSvEDuqUyQXKsarfMxgLGVPF)):
    if i>=CeAImtYSvEDuqUyQXKsarfMxgLGVPh:
     CeAImtYSvEDuqUyQXKsarfMxgLGVPR=CeAImtYSvEDuqUyQXKsarfMxgLGVPR+'...'
     break
    CeAImtYSvEDuqUyQXKsarfMxgLGVPR=CeAImtYSvEDuqUyQXKsarfMxgLGVPR+CeAImtYSvEDuqUyQXKsarfMxgLGVPF[i]['title']+'\n'
  except:
   return ''
  return CeAImtYSvEDuqUyQXKsarfMxgLGVPR
 def dp_Search_History(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVPn=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.Load_List_File('search')
  for CeAImtYSvEDuqUyQXKsarfMxgLGVPo in CeAImtYSvEDuqUyQXKsarfMxgLGVPn:
   CeAImtYSvEDuqUyQXKsarfMxgLGVPW=CeAImtYSvEDuqUyQXKsarfMxgLGVNh(urllib.parse.parse_qsl(CeAImtYSvEDuqUyQXKsarfMxgLGVPo))
   CeAImtYSvEDuqUyQXKsarfMxgLGVPO=CeAImtYSvEDuqUyQXKsarfMxgLGVPW.get('skey').strip()
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'SEARCH_GROUP','search_key':CeAImtYSvEDuqUyQXKsarfMxgLGVPO,}
   CeAImtYSvEDuqUyQXKsarfMxgLGVPi={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':CeAImtYSvEDuqUyQXKsarfMxgLGVPO,'vType':'-',}
   CeAImtYSvEDuqUyQXKsarfMxgLGVPb=urllib.parse.urlencode(CeAImtYSvEDuqUyQXKsarfMxgLGVPi)
   CeAImtYSvEDuqUyQXKsarfMxgLGVpH=[('선택된 검색어 ( %s ) 삭제'%(CeAImtYSvEDuqUyQXKsarfMxgLGVPO),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(CeAImtYSvEDuqUyQXKsarfMxgLGVPb))]
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVPO,sublabel='',img=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW,ContextMenu=CeAImtYSvEDuqUyQXKsarfMxgLGVpH)
  CeAImtYSvEDuqUyQXKsarfMxgLGVpw={'plot':'검색목록 전체를 삭제합니다.'}
  CeAImtYSvEDuqUyQXKsarfMxgLGVwl='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  CeAImtYSvEDuqUyQXKsarfMxgLGVwo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel='',img=CeAImtYSvEDuqUyQXKsarfMxgLGVwo,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVpw,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNT,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW,isLink=CeAImtYSvEDuqUyQXKsarfMxgLGVNH)
  xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,cacheToDisc=CeAImtYSvEDuqUyQXKsarfMxgLGVNT)
 def dp_Search_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVkl =CeAImtYSvEDuqUyQXKsarfMxgLGVNl(CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('page'))
  CeAImtYSvEDuqUyQXKsarfMxgLGVkN =CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('stype')
  if 'search_key' in CeAImtYSvEDuqUyQXKsarfMxgLGVkc:
   CeAImtYSvEDuqUyQXKsarfMxgLGVPc=CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('search_key')
  else:
   CeAImtYSvEDuqUyQXKsarfMxgLGVPc=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not CeAImtYSvEDuqUyQXKsarfMxgLGVPc:
    xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle)
    return
  CeAImtYSvEDuqUyQXKsarfMxgLGVPH,CeAImtYSvEDuqUyQXKsarfMxgLGVkT=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.GetSearchList(CeAImtYSvEDuqUyQXKsarfMxgLGVPc,CeAImtYSvEDuqUyQXKsarfMxgLGVkl,CeAImtYSvEDuqUyQXKsarfMxgLGVkN)
  for CeAImtYSvEDuqUyQXKsarfMxgLGVPF in CeAImtYSvEDuqUyQXKsarfMxgLGVPH:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl =CeAImtYSvEDuqUyQXKsarfMxgLGVPF.get('title')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkh =CeAImtYSvEDuqUyQXKsarfMxgLGVPF.get('thumbnail')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkn =CeAImtYSvEDuqUyQXKsarfMxgLGVPF.get('synopsis')
   CeAImtYSvEDuqUyQXKsarfMxgLGVJz =CeAImtYSvEDuqUyQXKsarfMxgLGVPF.get('program')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkW =CeAImtYSvEDuqUyQXKsarfMxgLGVPF.get('cast')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkO =CeAImtYSvEDuqUyQXKsarfMxgLGVPF.get('director')
   CeAImtYSvEDuqUyQXKsarfMxgLGVki=CeAImtYSvEDuqUyQXKsarfMxgLGVPF.get('info_genre')
   CeAImtYSvEDuqUyQXKsarfMxgLGVPw =CeAImtYSvEDuqUyQXKsarfMxgLGVPF.get('duration')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkF =CeAImtYSvEDuqUyQXKsarfMxgLGVPF.get('mpaa')
   CeAImtYSvEDuqUyQXKsarfMxgLGVkb =CeAImtYSvEDuqUyQXKsarfMxgLGVPF.get('year')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpO =CeAImtYSvEDuqUyQXKsarfMxgLGVPF.get('aired')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpw={'mediatype':'tvshow' if CeAImtYSvEDuqUyQXKsarfMxgLGVkN=='vod' else 'movie','title':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'cast':CeAImtYSvEDuqUyQXKsarfMxgLGVkW,'director':CeAImtYSvEDuqUyQXKsarfMxgLGVkO,'genre':CeAImtYSvEDuqUyQXKsarfMxgLGVki,'duration':CeAImtYSvEDuqUyQXKsarfMxgLGVPw,'mpaa':CeAImtYSvEDuqUyQXKsarfMxgLGVkF,'year':CeAImtYSvEDuqUyQXKsarfMxgLGVkb,'aired':CeAImtYSvEDuqUyQXKsarfMxgLGVpO,'plot':'%s\n\n%s'%(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,CeAImtYSvEDuqUyQXKsarfMxgLGVkn)}
   if CeAImtYSvEDuqUyQXKsarfMxgLGVkN=='vod':
    CeAImtYSvEDuqUyQXKsarfMxgLGVPp=CeAImtYSvEDuqUyQXKsarfMxgLGVPF.get('program')
    CeAImtYSvEDuqUyQXKsarfMxgLGVPJ='tvshow'
    CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'EPISODE','programcode':CeAImtYSvEDuqUyQXKsarfMxgLGVPp,'page':'1',}
    CeAImtYSvEDuqUyQXKsarfMxgLGVwO=CeAImtYSvEDuqUyQXKsarfMxgLGVNH
   else:
    CeAImtYSvEDuqUyQXKsarfMxgLGVPp=CeAImtYSvEDuqUyQXKsarfMxgLGVPF.get('movie')
    CeAImtYSvEDuqUyQXKsarfMxgLGVPJ='movie'
    CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'MOVIE','mediacode':CeAImtYSvEDuqUyQXKsarfMxgLGVPp,'stype':'movie','title':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'thumbnail':CeAImtYSvEDuqUyQXKsarfMxgLGVkh,}
    CeAImtYSvEDuqUyQXKsarfMxgLGVwO=CeAImtYSvEDuqUyQXKsarfMxgLGVNT
   if CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_settings_makebookmark():
    CeAImtYSvEDuqUyQXKsarfMxgLGVpj={'videoid':CeAImtYSvEDuqUyQXKsarfMxgLGVPp,'vidtype':CeAImtYSvEDuqUyQXKsarfMxgLGVPJ,'vtitle':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'vsubtitle':'',}
    CeAImtYSvEDuqUyQXKsarfMxgLGVpc=json.dumps(CeAImtYSvEDuqUyQXKsarfMxgLGVpj)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpc=urllib.parse.quote(CeAImtYSvEDuqUyQXKsarfMxgLGVpc)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpl='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(CeAImtYSvEDuqUyQXKsarfMxgLGVpc)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpH=[('(통합) 찜 영상에 추가',CeAImtYSvEDuqUyQXKsarfMxgLGVpl)]
   else:
    CeAImtYSvEDuqUyQXKsarfMxgLGVpH=CeAImtYSvEDuqUyQXKsarfMxgLGVNc
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel='',img=CeAImtYSvEDuqUyQXKsarfMxgLGVkh,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVpw,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVwO,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW,isLink=CeAImtYSvEDuqUyQXKsarfMxgLGVNT,ContextMenu=CeAImtYSvEDuqUyQXKsarfMxgLGVpH)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkT:
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['mode'] ='SEARCH' 
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['search_key']=CeAImtYSvEDuqUyQXKsarfMxgLGVPc
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW['page'] =CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl='[B]%s >>[/B]'%'다음 페이지'
   CeAImtYSvEDuqUyQXKsarfMxgLGVpk=CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVkl+1)
   CeAImtYSvEDuqUyQXKsarfMxgLGVwo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel=CeAImtYSvEDuqUyQXKsarfMxgLGVpk,img=CeAImtYSvEDuqUyQXKsarfMxgLGVwo,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkN=='movie':xbmcplugin.setContent(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,'movies')
  else:xbmcplugin.setContent(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,cacheToDisc=CeAImtYSvEDuqUyQXKsarfMxgLGVNT)
 def dp_History_Remove(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVJw=CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('delType')
  CeAImtYSvEDuqUyQXKsarfMxgLGVJk =CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('sKey')
  CeAImtYSvEDuqUyQXKsarfMxgLGVJp =CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('vType')
  CeAImtYSvEDuqUyQXKsarfMxgLGVzn=xbmcgui.Dialog()
  if CeAImtYSvEDuqUyQXKsarfMxgLGVJw=='SEARCH_ALL':
   CeAImtYSvEDuqUyQXKsarfMxgLGVkP=CeAImtYSvEDuqUyQXKsarfMxgLGVzn.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVJw=='SEARCH_ONE':
   CeAImtYSvEDuqUyQXKsarfMxgLGVkP=CeAImtYSvEDuqUyQXKsarfMxgLGVzn.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVJw=='WATCH_ALL':
   CeAImtYSvEDuqUyQXKsarfMxgLGVkP=CeAImtYSvEDuqUyQXKsarfMxgLGVzn.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVJw=='WATCH_ONE':
   CeAImtYSvEDuqUyQXKsarfMxgLGVkP=CeAImtYSvEDuqUyQXKsarfMxgLGVzn.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkP==CeAImtYSvEDuqUyQXKsarfMxgLGVNT:sys.exit()
  if CeAImtYSvEDuqUyQXKsarfMxgLGVJw=='SEARCH_ALL':
   if os.path.isfile(CeAImtYSvEDuqUyQXKsarfMxgLGVzc):os.remove(CeAImtYSvEDuqUyQXKsarfMxgLGVzc)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVJw=='SEARCH_ONE':
   try:
    CeAImtYSvEDuqUyQXKsarfMxgLGVJP=CeAImtYSvEDuqUyQXKsarfMxgLGVzc
    CeAImtYSvEDuqUyQXKsarfMxgLGVJB=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.Load_List_File('search') 
    fp=CeAImtYSvEDuqUyQXKsarfMxgLGVNO(CeAImtYSvEDuqUyQXKsarfMxgLGVJP,'w',-1,'utf-8')
    for CeAImtYSvEDuqUyQXKsarfMxgLGVJN in CeAImtYSvEDuqUyQXKsarfMxgLGVJB:
     CeAImtYSvEDuqUyQXKsarfMxgLGVJd=CeAImtYSvEDuqUyQXKsarfMxgLGVNh(urllib.parse.parse_qsl(CeAImtYSvEDuqUyQXKsarfMxgLGVJN))
     CeAImtYSvEDuqUyQXKsarfMxgLGVJj=CeAImtYSvEDuqUyQXKsarfMxgLGVJd.get('skey').strip()
     if CeAImtYSvEDuqUyQXKsarfMxgLGVJk!=CeAImtYSvEDuqUyQXKsarfMxgLGVJj:
      fp.write(CeAImtYSvEDuqUyQXKsarfMxgLGVJN)
    fp.close()
   except:
    CeAImtYSvEDuqUyQXKsarfMxgLGVNc
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVJw=='WATCH_ALL':
   CeAImtYSvEDuqUyQXKsarfMxgLGVJP=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%CeAImtYSvEDuqUyQXKsarfMxgLGVJp))
   if os.path.isfile(CeAImtYSvEDuqUyQXKsarfMxgLGVJP):os.remove(CeAImtYSvEDuqUyQXKsarfMxgLGVJP)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVJw=='WATCH_ONE':
   CeAImtYSvEDuqUyQXKsarfMxgLGVJP=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%CeAImtYSvEDuqUyQXKsarfMxgLGVJp))
   try:
    CeAImtYSvEDuqUyQXKsarfMxgLGVJB=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.Load_List_File(CeAImtYSvEDuqUyQXKsarfMxgLGVJp) 
    fp=CeAImtYSvEDuqUyQXKsarfMxgLGVNO(CeAImtYSvEDuqUyQXKsarfMxgLGVJP,'w',-1,'utf-8')
    for CeAImtYSvEDuqUyQXKsarfMxgLGVJN in CeAImtYSvEDuqUyQXKsarfMxgLGVJB:
     CeAImtYSvEDuqUyQXKsarfMxgLGVJd=CeAImtYSvEDuqUyQXKsarfMxgLGVNh(urllib.parse.parse_qsl(CeAImtYSvEDuqUyQXKsarfMxgLGVJN))
     CeAImtYSvEDuqUyQXKsarfMxgLGVJj=CeAImtYSvEDuqUyQXKsarfMxgLGVJd.get('code').strip()
     if CeAImtYSvEDuqUyQXKsarfMxgLGVJk!=CeAImtYSvEDuqUyQXKsarfMxgLGVJj:
      fp.write(CeAImtYSvEDuqUyQXKsarfMxgLGVJN)
    fp.close()
   except:
    CeAImtYSvEDuqUyQXKsarfMxgLGVNc
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkN): 
  try:
   if CeAImtYSvEDuqUyQXKsarfMxgLGVkN=='search':
    CeAImtYSvEDuqUyQXKsarfMxgLGVJP=CeAImtYSvEDuqUyQXKsarfMxgLGVzc
   elif CeAImtYSvEDuqUyQXKsarfMxgLGVkN in['vod','movie']:
    CeAImtYSvEDuqUyQXKsarfMxgLGVJP=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%CeAImtYSvEDuqUyQXKsarfMxgLGVkN))
   else:
    return[]
   fp=CeAImtYSvEDuqUyQXKsarfMxgLGVNO(CeAImtYSvEDuqUyQXKsarfMxgLGVJP,'r',-1,'utf-8')
   CeAImtYSvEDuqUyQXKsarfMxgLGVJc=fp.readlines()
   fp.close()
  except:
   CeAImtYSvEDuqUyQXKsarfMxgLGVJc=[]
  return CeAImtYSvEDuqUyQXKsarfMxgLGVJc
 def Save_Watched_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkN,CeAImtYSvEDuqUyQXKsarfMxgLGVzR):
  try:
   CeAImtYSvEDuqUyQXKsarfMxgLGVJl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%CeAImtYSvEDuqUyQXKsarfMxgLGVkN))
   CeAImtYSvEDuqUyQXKsarfMxgLGVJB=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.Load_List_File(CeAImtYSvEDuqUyQXKsarfMxgLGVkN) 
   fp=CeAImtYSvEDuqUyQXKsarfMxgLGVNO(CeAImtYSvEDuqUyQXKsarfMxgLGVJl,'w',-1,'utf-8')
   CeAImtYSvEDuqUyQXKsarfMxgLGVJH=urllib.parse.urlencode(CeAImtYSvEDuqUyQXKsarfMxgLGVzR)
   CeAImtYSvEDuqUyQXKsarfMxgLGVJH=CeAImtYSvEDuqUyQXKsarfMxgLGVJH+'\n'
   fp.write(CeAImtYSvEDuqUyQXKsarfMxgLGVJH)
   CeAImtYSvEDuqUyQXKsarfMxgLGVJT=0
   for CeAImtYSvEDuqUyQXKsarfMxgLGVJN in CeAImtYSvEDuqUyQXKsarfMxgLGVJB:
    CeAImtYSvEDuqUyQXKsarfMxgLGVJd=CeAImtYSvEDuqUyQXKsarfMxgLGVNh(urllib.parse.parse_qsl(CeAImtYSvEDuqUyQXKsarfMxgLGVJN))
    CeAImtYSvEDuqUyQXKsarfMxgLGVJR=CeAImtYSvEDuqUyQXKsarfMxgLGVzR.get('code').strip()
    CeAImtYSvEDuqUyQXKsarfMxgLGVJh=CeAImtYSvEDuqUyQXKsarfMxgLGVJd.get('code').strip()
    if CeAImtYSvEDuqUyQXKsarfMxgLGVkN=='vod' and CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_settings_direct_replay()==CeAImtYSvEDuqUyQXKsarfMxgLGVNH:
     CeAImtYSvEDuqUyQXKsarfMxgLGVJR=CeAImtYSvEDuqUyQXKsarfMxgLGVzR.get('videoid').strip()
     CeAImtYSvEDuqUyQXKsarfMxgLGVJh=CeAImtYSvEDuqUyQXKsarfMxgLGVJd.get('videoid').strip()if CeAImtYSvEDuqUyQXKsarfMxgLGVJh!=CeAImtYSvEDuqUyQXKsarfMxgLGVNc else '-'
    if CeAImtYSvEDuqUyQXKsarfMxgLGVJR!=CeAImtYSvEDuqUyQXKsarfMxgLGVJh:
     fp.write(CeAImtYSvEDuqUyQXKsarfMxgLGVJN)
     CeAImtYSvEDuqUyQXKsarfMxgLGVJT+=1
     if CeAImtYSvEDuqUyQXKsarfMxgLGVJT>=50:break
   fp.close()
  except:
   CeAImtYSvEDuqUyQXKsarfMxgLGVNc
 def dp_Watch_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVkN =CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('stype')
  CeAImtYSvEDuqUyQXKsarfMxgLGVwN=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_settings_direct_replay()
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkN=='-':
   for CeAImtYSvEDuqUyQXKsarfMxgLGVkj in CeAImtYSvEDuqUyQXKsarfMxgLGVzP:
    CeAImtYSvEDuqUyQXKsarfMxgLGVwl=CeAImtYSvEDuqUyQXKsarfMxgLGVkj.get('title')
    CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':CeAImtYSvEDuqUyQXKsarfMxgLGVkj.get('mode'),'stype':CeAImtYSvEDuqUyQXKsarfMxgLGVkj.get('stype')}
    CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel='',img='',infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVNc,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNH,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
   if CeAImtYSvEDuqUyQXKsarfMxgLGVNn(CeAImtYSvEDuqUyQXKsarfMxgLGVzP)>0:xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle)
  else:
   CeAImtYSvEDuqUyQXKsarfMxgLGVJn=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.Load_List_File(CeAImtYSvEDuqUyQXKsarfMxgLGVkN)
   for CeAImtYSvEDuqUyQXKsarfMxgLGVJo in CeAImtYSvEDuqUyQXKsarfMxgLGVJn:
    CeAImtYSvEDuqUyQXKsarfMxgLGVPW=CeAImtYSvEDuqUyQXKsarfMxgLGVNh(urllib.parse.parse_qsl(CeAImtYSvEDuqUyQXKsarfMxgLGVJo))
    CeAImtYSvEDuqUyQXKsarfMxgLGVJW =CeAImtYSvEDuqUyQXKsarfMxgLGVPW.get('code').strip()
    CeAImtYSvEDuqUyQXKsarfMxgLGVwl =CeAImtYSvEDuqUyQXKsarfMxgLGVPW.get('title').strip()
    CeAImtYSvEDuqUyQXKsarfMxgLGVkh=CeAImtYSvEDuqUyQXKsarfMxgLGVPW.get('img').strip()
    CeAImtYSvEDuqUyQXKsarfMxgLGVPp =CeAImtYSvEDuqUyQXKsarfMxgLGVPW.get('videoid').strip()
    try:
     CeAImtYSvEDuqUyQXKsarfMxgLGVkh=CeAImtYSvEDuqUyQXKsarfMxgLGVkh.replace('\'','\"')
     CeAImtYSvEDuqUyQXKsarfMxgLGVkh=json.loads(CeAImtYSvEDuqUyQXKsarfMxgLGVkh)
    except:
     CeAImtYSvEDuqUyQXKsarfMxgLGVNc
    CeAImtYSvEDuqUyQXKsarfMxgLGVpw={}
    CeAImtYSvEDuqUyQXKsarfMxgLGVpw['plot']=CeAImtYSvEDuqUyQXKsarfMxgLGVwl
    if CeAImtYSvEDuqUyQXKsarfMxgLGVkN=='vod':
     if CeAImtYSvEDuqUyQXKsarfMxgLGVwN==CeAImtYSvEDuqUyQXKsarfMxgLGVNT or CeAImtYSvEDuqUyQXKsarfMxgLGVPp==CeAImtYSvEDuqUyQXKsarfMxgLGVNc:
      CeAImtYSvEDuqUyQXKsarfMxgLGVpw['mediatype']='tvshow'
      CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'EPISODE','programcode':CeAImtYSvEDuqUyQXKsarfMxgLGVJW,'page':'1'}
      CeAImtYSvEDuqUyQXKsarfMxgLGVwO=CeAImtYSvEDuqUyQXKsarfMxgLGVNH
     else:
      CeAImtYSvEDuqUyQXKsarfMxgLGVpw['mediatype']='episode'
      CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'VOD','mediacode':CeAImtYSvEDuqUyQXKsarfMxgLGVPp,'stype':'vod','programcode':CeAImtYSvEDuqUyQXKsarfMxgLGVJW,'title':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'thumbnail':CeAImtYSvEDuqUyQXKsarfMxgLGVkh}
      CeAImtYSvEDuqUyQXKsarfMxgLGVwO=CeAImtYSvEDuqUyQXKsarfMxgLGVNT
    else:
     CeAImtYSvEDuqUyQXKsarfMxgLGVpw['mediatype']='movie'
     CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'MOVIE','mediacode':CeAImtYSvEDuqUyQXKsarfMxgLGVJW,'stype':'movie','title':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'thumbnail':CeAImtYSvEDuqUyQXKsarfMxgLGVkh}
     CeAImtYSvEDuqUyQXKsarfMxgLGVwO=CeAImtYSvEDuqUyQXKsarfMxgLGVNT
    CeAImtYSvEDuqUyQXKsarfMxgLGVPi={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':CeAImtYSvEDuqUyQXKsarfMxgLGVJW,'vType':CeAImtYSvEDuqUyQXKsarfMxgLGVkN,}
    CeAImtYSvEDuqUyQXKsarfMxgLGVPb=urllib.parse.urlencode(CeAImtYSvEDuqUyQXKsarfMxgLGVPi)
    CeAImtYSvEDuqUyQXKsarfMxgLGVpH=[('선택된 시청이력 ( %s ) 삭제'%(CeAImtYSvEDuqUyQXKsarfMxgLGVwl),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(CeAImtYSvEDuqUyQXKsarfMxgLGVPb))]
    CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel='',img=CeAImtYSvEDuqUyQXKsarfMxgLGVkh,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVpw,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVwO,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW,ContextMenu=CeAImtYSvEDuqUyQXKsarfMxgLGVpH)
   CeAImtYSvEDuqUyQXKsarfMxgLGVpw={'plot':'시청목록을 삭제합니다.'}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':CeAImtYSvEDuqUyQXKsarfMxgLGVkN,}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwo=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel='',img=CeAImtYSvEDuqUyQXKsarfMxgLGVwo,infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVpw,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNT,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW,isLink=CeAImtYSvEDuqUyQXKsarfMxgLGVNH)
   if CeAImtYSvEDuqUyQXKsarfMxgLGVkN=='movie':xbmcplugin.setContent(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,'movies')
   else:xbmcplugin.setContent(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,cacheToDisc=CeAImtYSvEDuqUyQXKsarfMxgLGVNT)
 def Save_Searched_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVPc):
  try:
   CeAImtYSvEDuqUyQXKsarfMxgLGVJO=CeAImtYSvEDuqUyQXKsarfMxgLGVzc
   CeAImtYSvEDuqUyQXKsarfMxgLGVJB=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.Load_List_File('search') 
   CeAImtYSvEDuqUyQXKsarfMxgLGVJi={'skey':CeAImtYSvEDuqUyQXKsarfMxgLGVPc.strip()}
   fp=CeAImtYSvEDuqUyQXKsarfMxgLGVNO(CeAImtYSvEDuqUyQXKsarfMxgLGVJO,'w',-1,'utf-8')
   CeAImtYSvEDuqUyQXKsarfMxgLGVJH=urllib.parse.urlencode(CeAImtYSvEDuqUyQXKsarfMxgLGVJi)
   CeAImtYSvEDuqUyQXKsarfMxgLGVJH=CeAImtYSvEDuqUyQXKsarfMxgLGVJH+'\n'
   fp.write(CeAImtYSvEDuqUyQXKsarfMxgLGVJH)
   CeAImtYSvEDuqUyQXKsarfMxgLGVJT=0
   for CeAImtYSvEDuqUyQXKsarfMxgLGVJN in CeAImtYSvEDuqUyQXKsarfMxgLGVJB:
    CeAImtYSvEDuqUyQXKsarfMxgLGVJd=CeAImtYSvEDuqUyQXKsarfMxgLGVNh(urllib.parse.parse_qsl(CeAImtYSvEDuqUyQXKsarfMxgLGVJN))
    CeAImtYSvEDuqUyQXKsarfMxgLGVJR=CeAImtYSvEDuqUyQXKsarfMxgLGVJi.get('skey').strip()
    CeAImtYSvEDuqUyQXKsarfMxgLGVJh=CeAImtYSvEDuqUyQXKsarfMxgLGVJd.get('skey').strip()
    if CeAImtYSvEDuqUyQXKsarfMxgLGVJR!=CeAImtYSvEDuqUyQXKsarfMxgLGVJh:
     fp.write(CeAImtYSvEDuqUyQXKsarfMxgLGVJN)
     CeAImtYSvEDuqUyQXKsarfMxgLGVJT+=1
     if CeAImtYSvEDuqUyQXKsarfMxgLGVJT>=50:break
   fp.close()
  except:
   CeAImtYSvEDuqUyQXKsarfMxgLGVNc
 def play_VIDEO(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVJb =CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('mediacode')
  CeAImtYSvEDuqUyQXKsarfMxgLGVkN =CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('stype')
  CeAImtYSvEDuqUyQXKsarfMxgLGVJF =CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('pvrmode')
  CeAImtYSvEDuqUyQXKsarfMxgLGVBz=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_selQuality(CeAImtYSvEDuqUyQXKsarfMxgLGVkN)
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(CeAImtYSvEDuqUyQXKsarfMxgLGVJb,CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVBz),CeAImtYSvEDuqUyQXKsarfMxgLGVkN,CeAImtYSvEDuqUyQXKsarfMxgLGVJF))
  CeAImtYSvEDuqUyQXKsarfMxgLGVBw=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.GetBroadURL(CeAImtYSvEDuqUyQXKsarfMxgLGVJb,CeAImtYSvEDuqUyQXKsarfMxgLGVBz,CeAImtYSvEDuqUyQXKsarfMxgLGVkN,CeAImtYSvEDuqUyQXKsarfMxgLGVJF,optUHD=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_settings_uhd())
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.addon_log('qt, stype, url : %s - %s - %s'%(CeAImtYSvEDuqUyQXKsarfMxgLGVNo(CeAImtYSvEDuqUyQXKsarfMxgLGVBz),CeAImtYSvEDuqUyQXKsarfMxgLGVkN,CeAImtYSvEDuqUyQXKsarfMxgLGVBw['streaming_url']))
  if CeAImtYSvEDuqUyQXKsarfMxgLGVBw['streaming_url']=='':
   if CeAImtYSvEDuqUyQXKsarfMxgLGVBw['error_msg']=='':
    CeAImtYSvEDuqUyQXKsarfMxgLGVzl.addon_noti(__language__(30908).encode('utf8'))
   else:
    CeAImtYSvEDuqUyQXKsarfMxgLGVzl.addon_noti(CeAImtYSvEDuqUyQXKsarfMxgLGVBw['error_msg'].encode('utf8'))
   return
  CeAImtYSvEDuqUyQXKsarfMxgLGVBk='user-agent={}'.format(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.USER_AGENT)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVBw['watermark'] !='':
   CeAImtYSvEDuqUyQXKsarfMxgLGVBk='{}&x-tving-param1={}&x-tving-param2={}'.format(CeAImtYSvEDuqUyQXKsarfMxgLGVBk,CeAImtYSvEDuqUyQXKsarfMxgLGVBw['watermarkKey'],CeAImtYSvEDuqUyQXKsarfMxgLGVBw['watermark'])
  CeAImtYSvEDuqUyQXKsarfMxgLGVBp =CeAImtYSvEDuqUyQXKsarfMxgLGVNT
  CeAImtYSvEDuqUyQXKsarfMxgLGVBP =CeAImtYSvEDuqUyQXKsarfMxgLGVBw['streaming_url'].find('Policy=')
  if CeAImtYSvEDuqUyQXKsarfMxgLGVBP!=-1:
   CeAImtYSvEDuqUyQXKsarfMxgLGVBJ =CeAImtYSvEDuqUyQXKsarfMxgLGVBw['streaming_url'].split('?')[0]
   CeAImtYSvEDuqUyQXKsarfMxgLGVBN=CeAImtYSvEDuqUyQXKsarfMxgLGVNh(urllib.parse.parse_qsl(urllib.parse.urlsplit(CeAImtYSvEDuqUyQXKsarfMxgLGVBw['streaming_url']).query))
   CeAImtYSvEDuqUyQXKsarfMxgLGVBd='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(CeAImtYSvEDuqUyQXKsarfMxgLGVBN['Policy'],CeAImtYSvEDuqUyQXKsarfMxgLGVBN['Signature'],CeAImtYSvEDuqUyQXKsarfMxgLGVBN['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in CeAImtYSvEDuqUyQXKsarfMxgLGVBJ:
    CeAImtYSvEDuqUyQXKsarfMxgLGVBp=CeAImtYSvEDuqUyQXKsarfMxgLGVNH
    CeAImtYSvEDuqUyQXKsarfMxgLGVBj =CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    CeAImtYSvEDuqUyQXKsarfMxgLGVBc=CeAImtYSvEDuqUyQXKsarfMxgLGVBj.strftime('%Y-%m-%d-%H:%M:%S')
    if CeAImtYSvEDuqUyQXKsarfMxgLGVNl(CeAImtYSvEDuqUyQXKsarfMxgLGVBc.replace('-','').replace(':',''))<CeAImtYSvEDuqUyQXKsarfMxgLGVNl(CeAImtYSvEDuqUyQXKsarfMxgLGVBN['end'].replace('-','').replace(':','')):
     CeAImtYSvEDuqUyQXKsarfMxgLGVBN['end']=CeAImtYSvEDuqUyQXKsarfMxgLGVBc
     CeAImtYSvEDuqUyQXKsarfMxgLGVzl.addon_noti(__language__(30915).encode('utf8'))
    CeAImtYSvEDuqUyQXKsarfMxgLGVBJ ='%s?%s'%(CeAImtYSvEDuqUyQXKsarfMxgLGVBJ,urllib.parse.urlencode(CeAImtYSvEDuqUyQXKsarfMxgLGVBN,doseq=CeAImtYSvEDuqUyQXKsarfMxgLGVNH))
   CeAImtYSvEDuqUyQXKsarfMxgLGVBl='{}|{}&Cookie={}'.format(CeAImtYSvEDuqUyQXKsarfMxgLGVBJ,CeAImtYSvEDuqUyQXKsarfMxgLGVBk,CeAImtYSvEDuqUyQXKsarfMxgLGVBd)
  else:
   CeAImtYSvEDuqUyQXKsarfMxgLGVBl=CeAImtYSvEDuqUyQXKsarfMxgLGVBw['streaming_url']+'|'+CeAImtYSvEDuqUyQXKsarfMxgLGVBk
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.addon_log('if tmp_pos == -1')
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.addon_log(CeAImtYSvEDuqUyQXKsarfMxgLGVBl)
  CeAImtYSvEDuqUyQXKsarfMxgLGVBH=xbmcgui.ListItem(path=CeAImtYSvEDuqUyQXKsarfMxgLGVBl)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVBw['drm_license']!='':
   CeAImtYSvEDuqUyQXKsarfMxgLGVBT=CeAImtYSvEDuqUyQXKsarfMxgLGVBw['drm_license']
   CeAImtYSvEDuqUyQXKsarfMxgLGVBR ='https://cj.drmkeyserver.com/widevine_license'
   CeAImtYSvEDuqUyQXKsarfMxgLGVBh ='mpd'
   CeAImtYSvEDuqUyQXKsarfMxgLGVBn ='com.widevine.alpha'
   CeAImtYSvEDuqUyQXKsarfMxgLGVBo =inputstreamhelper.Helper(CeAImtYSvEDuqUyQXKsarfMxgLGVBh,drm='widevine')
   if CeAImtYSvEDuqUyQXKsarfMxgLGVBo.check_inputstream():
    CeAImtYSvEDuqUyQXKsarfMxgLGVBW={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.USER_AGENT,'AcquireLicenseAssertion':CeAImtYSvEDuqUyQXKsarfMxgLGVBT,'Host':'cj.drmkeyserver.com',}
    CeAImtYSvEDuqUyQXKsarfMxgLGVBO=CeAImtYSvEDuqUyQXKsarfMxgLGVBR+'|'+urllib.parse.urlencode(CeAImtYSvEDuqUyQXKsarfMxgLGVBW)+'|R{SSM}|'
    CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setProperty('inputstream',CeAImtYSvEDuqUyQXKsarfMxgLGVBo.inputstream_addon)
    CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setProperty('inputstream.adaptive.manifest_type',CeAImtYSvEDuqUyQXKsarfMxgLGVBh)
    CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setProperty('inputstream.adaptive.license_type',CeAImtYSvEDuqUyQXKsarfMxgLGVBn)
    CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setProperty('inputstream.adaptive.license_key',CeAImtYSvEDuqUyQXKsarfMxgLGVBO)
    CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setProperty('inputstream.adaptive.stream_headers',CeAImtYSvEDuqUyQXKsarfMxgLGVBk)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVBp==CeAImtYSvEDuqUyQXKsarfMxgLGVNH:
   CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setContentLookup(CeAImtYSvEDuqUyQXKsarfMxgLGVNT)
   CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setMimeType('application/x-mpegURL')
   CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setProperty('inputstream','inputstream.ffmpegdirect')
   CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setProperty('ResumeTime','0')
   CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setProperty('TotalTime','10000')
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('mode')in['VOD','MOVIE']:
   CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setContentLookup(CeAImtYSvEDuqUyQXKsarfMxgLGVNT)
   CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setMimeType('application/x-mpegURL')
   CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setProperty('inputstream','inputstream.adaptive')
   CeAImtYSvEDuqUyQXKsarfMxgLGVBH.setProperty('inputstream.adaptive.manifest_type','hls')
  xbmcplugin.setResolvedUrl(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,CeAImtYSvEDuqUyQXKsarfMxgLGVNH,CeAImtYSvEDuqUyQXKsarfMxgLGVBH)
  try:
   if CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('mode')in['VOD','MOVIE']and CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('title'):
    CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'code':CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('programcode')if CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('mode')=='VOD' else CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('mediacode'),'img':CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('thumbnail'),'title':CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('title'),'videoid':CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('mediacode')}
    CeAImtYSvEDuqUyQXKsarfMxgLGVzl.Save_Watched_List(CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('stype'),CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  except:
   CeAImtYSvEDuqUyQXKsarfMxgLGVNc
 def logout(CeAImtYSvEDuqUyQXKsarfMxgLGVzl):
  CeAImtYSvEDuqUyQXKsarfMxgLGVzn=xbmcgui.Dialog()
  CeAImtYSvEDuqUyQXKsarfMxgLGVkP=CeAImtYSvEDuqUyQXKsarfMxgLGVzn.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if CeAImtYSvEDuqUyQXKsarfMxgLGVkP==CeAImtYSvEDuqUyQXKsarfMxgLGVNT:sys.exit()
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.Init_TV_Total()
  if os.path.isfile(CeAImtYSvEDuqUyQXKsarfMxgLGVzj):os.remove(CeAImtYSvEDuqUyQXKsarfMxgLGVzj)
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(CeAImtYSvEDuqUyQXKsarfMxgLGVzl):
  CeAImtYSvEDuqUyQXKsarfMxgLGVBi =CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.Get_Now_Datetime()
  CeAImtYSvEDuqUyQXKsarfMxgLGVBb=CeAImtYSvEDuqUyQXKsarfMxgLGVBi+datetime.timedelta(days=CeAImtYSvEDuqUyQXKsarfMxgLGVNl(__addon__.getSetting('cache_ttl')))
  (CeAImtYSvEDuqUyQXKsarfMxgLGVwF,CeAImtYSvEDuqUyQXKsarfMxgLGVkz,CeAImtYSvEDuqUyQXKsarfMxgLGVkw,CeAImtYSvEDuqUyQXKsarfMxgLGVkp)=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_settings_account()
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.Save_session_acount(CeAImtYSvEDuqUyQXKsarfMxgLGVwF,CeAImtYSvEDuqUyQXKsarfMxgLGVkz,CeAImtYSvEDuqUyQXKsarfMxgLGVkw,CeAImtYSvEDuqUyQXKsarfMxgLGVkp)
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.TV['account']['token_limit']=CeAImtYSvEDuqUyQXKsarfMxgLGVBb.strftime('%Y%m%d')
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.JsonFile_Save(CeAImtYSvEDuqUyQXKsarfMxgLGVzj,CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.TV)
 def cookiefile_check(CeAImtYSvEDuqUyQXKsarfMxgLGVzl):
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.TV=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.JsonFile_Load(CeAImtYSvEDuqUyQXKsarfMxgLGVzj)
  if 'account' not in CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.TV:
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.Init_TV_Total()
   return CeAImtYSvEDuqUyQXKsarfMxgLGVNT
  (CeAImtYSvEDuqUyQXKsarfMxgLGVBF,CeAImtYSvEDuqUyQXKsarfMxgLGVNz,CeAImtYSvEDuqUyQXKsarfMxgLGVNw,CeAImtYSvEDuqUyQXKsarfMxgLGVNk)=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.get_settings_account()
  (CeAImtYSvEDuqUyQXKsarfMxgLGVNp,CeAImtYSvEDuqUyQXKsarfMxgLGVNP,CeAImtYSvEDuqUyQXKsarfMxgLGVNJ,CeAImtYSvEDuqUyQXKsarfMxgLGVNB)=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.Load_session_acount()
  if CeAImtYSvEDuqUyQXKsarfMxgLGVBF!=CeAImtYSvEDuqUyQXKsarfMxgLGVNp or CeAImtYSvEDuqUyQXKsarfMxgLGVNz!=CeAImtYSvEDuqUyQXKsarfMxgLGVNP or CeAImtYSvEDuqUyQXKsarfMxgLGVNw!=CeAImtYSvEDuqUyQXKsarfMxgLGVNJ or CeAImtYSvEDuqUyQXKsarfMxgLGVNk!=CeAImtYSvEDuqUyQXKsarfMxgLGVNB:
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.Init_TV_Total()
   return CeAImtYSvEDuqUyQXKsarfMxgLGVNT
  if CeAImtYSvEDuqUyQXKsarfMxgLGVNl(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>CeAImtYSvEDuqUyQXKsarfMxgLGVNl(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.TV['account']['token_limit']):
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.Init_TV_Total()
   return CeAImtYSvEDuqUyQXKsarfMxgLGVNT
  return CeAImtYSvEDuqUyQXKsarfMxgLGVNH
 def dp_Global_Search(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVPl=CeAImtYSvEDuqUyQXKsarfMxgLGVkc.get('mode')
  if CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='TOTAL_SEARCH':
   CeAImtYSvEDuqUyQXKsarfMxgLGVNd='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   CeAImtYSvEDuqUyQXKsarfMxgLGVNd='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(CeAImtYSvEDuqUyQXKsarfMxgLGVNd)
 def dp_Bookmark_Menu(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVNd='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(CeAImtYSvEDuqUyQXKsarfMxgLGVNd)
 def dp_EuroLive_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl,CeAImtYSvEDuqUyQXKsarfMxgLGVkc):
  CeAImtYSvEDuqUyQXKsarfMxgLGVkH=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.TvingObj.GetEuroChannelList()
  for CeAImtYSvEDuqUyQXKsarfMxgLGVkR in CeAImtYSvEDuqUyQXKsarfMxgLGVkH:
   CeAImtYSvEDuqUyQXKsarfMxgLGVpd =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('channel')
   CeAImtYSvEDuqUyQXKsarfMxgLGVwl =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('title')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpk =CeAImtYSvEDuqUyQXKsarfMxgLGVkR.get('subtitle')
   CeAImtYSvEDuqUyQXKsarfMxgLGVpw={'mediatype':'episode','title':CeAImtYSvEDuqUyQXKsarfMxgLGVwl,'plot':'%s\n%s'%(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,CeAImtYSvEDuqUyQXKsarfMxgLGVpk)}
   CeAImtYSvEDuqUyQXKsarfMxgLGVwW={'mode':'LIVE','mediacode':CeAImtYSvEDuqUyQXKsarfMxgLGVpd,'stype':'onair',}
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.add_dir(CeAImtYSvEDuqUyQXKsarfMxgLGVwl,sublabel=CeAImtYSvEDuqUyQXKsarfMxgLGVpk,img='',infoLabels=CeAImtYSvEDuqUyQXKsarfMxgLGVpw,isFolder=CeAImtYSvEDuqUyQXKsarfMxgLGVNT,params=CeAImtYSvEDuqUyQXKsarfMxgLGVwW)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVNn(CeAImtYSvEDuqUyQXKsarfMxgLGVkH)>0:xbmcplugin.endOfDirectory(CeAImtYSvEDuqUyQXKsarfMxgLGVzl._addon_handle,cacheToDisc=CeAImtYSvEDuqUyQXKsarfMxgLGVNT)
 def tving_main(CeAImtYSvEDuqUyQXKsarfMxgLGVzl):
  CeAImtYSvEDuqUyQXKsarfMxgLGVPl=CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params.get('mode',CeAImtYSvEDuqUyQXKsarfMxgLGVNc)
  if CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='LOGOUT':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.logout()
   return
  CeAImtYSvEDuqUyQXKsarfMxgLGVzl.login_main()
  if CeAImtYSvEDuqUyQXKsarfMxgLGVPl is CeAImtYSvEDuqUyQXKsarfMxgLGVNc:
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_Main_List()
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_Title_Group(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl in['GLOBAL_GROUP']:
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_SubTitle_Group(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='CHANNEL':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_LiveChannel_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl in['LIVE','VOD','MOVIE']:
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.play_VIDEO(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='PROGRAM':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_Program_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='4K_PROGRAM':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_4K_Program_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='EPISODE':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_Episode_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='MOVIE_SUB':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_Movie_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='4K_MOVIE':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_4K_Movie_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='SEARCH_GROUP':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_Search_Group(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl in['SEARCH','LOCAL_SEARCH']:
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_Search_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='WATCH':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_Watch_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_History_Remove(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='ORDER_BY':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_setEpOrderby(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='SET_BOOKMARK':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_Set_Bookmark(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl in['TOTAL_SEARCH','TOTAL_HISTORY']:
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_Global_Search(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='SEARCH_HISTORY':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_Search_History(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='MENU_BOOKMARK':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_Bookmark_Menu(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  elif CeAImtYSvEDuqUyQXKsarfMxgLGVPl=='EURO_GROUP':
   CeAImtYSvEDuqUyQXKsarfMxgLGVzl.dp_EuroLive_List(CeAImtYSvEDuqUyQXKsarfMxgLGVzl.main_params)
  else:
   CeAImtYSvEDuqUyQXKsarfMxgLGVNc
# Created by pyminifier (https://github.com/liftoff/pyminifier)
