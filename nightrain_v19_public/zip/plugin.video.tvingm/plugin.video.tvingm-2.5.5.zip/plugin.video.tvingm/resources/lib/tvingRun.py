__author__="NightRain"
bKExsAkyLwWePTNUFJOnqjtrmCaIYQ=object
bKExsAkyLwWePTNUFJOnqjtrmCaIYM=None
bKExsAkyLwWePTNUFJOnqjtrmCaIYo=int
bKExsAkyLwWePTNUFJOnqjtrmCaIYd=True
bKExsAkyLwWePTNUFJOnqjtrmCaIYf=False
bKExsAkyLwWePTNUFJOnqjtrmCaIYi=type
bKExsAkyLwWePTNUFJOnqjtrmCaIHB=dict
bKExsAkyLwWePTNUFJOnqjtrmCaIHu=getattr
bKExsAkyLwWePTNUFJOnqjtrmCaIHp=list
bKExsAkyLwWePTNUFJOnqjtrmCaIHX=len
bKExsAkyLwWePTNUFJOnqjtrmCaIHh=str
bKExsAkyLwWePTNUFJOnqjtrmCaIHl=range
bKExsAkyLwWePTNUFJOnqjtrmCaIHS=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
bKExsAkyLwWePTNUFJOnqjtrmCaIBp=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
bKExsAkyLwWePTNUFJOnqjtrmCaIBX=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
bKExsAkyLwWePTNUFJOnqjtrmCaIBh=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
bKExsAkyLwWePTNUFJOnqjtrmCaIBl=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
bKExsAkyLwWePTNUFJOnqjtrmCaIBS=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
bKExsAkyLwWePTNUFJOnqjtrmCaIBY=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
bKExsAkyLwWePTNUFJOnqjtrmCaIBH=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
bKExsAkyLwWePTNUFJOnqjtrmCaIBG={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
bKExsAkyLwWePTNUFJOnqjtrmCaIBv =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
bKExsAkyLwWePTNUFJOnqjtrmCaIBV=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class bKExsAkyLwWePTNUFJOnqjtrmCaIBu(bKExsAkyLwWePTNUFJOnqjtrmCaIYQ):
 def __init__(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIBg,bKExsAkyLwWePTNUFJOnqjtrmCaIBD,bKExsAkyLwWePTNUFJOnqjtrmCaIBz):
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_url =bKExsAkyLwWePTNUFJOnqjtrmCaIBg
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle=bKExsAkyLwWePTNUFJOnqjtrmCaIBD
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params =bKExsAkyLwWePTNUFJOnqjtrmCaIBz
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj =bdKARiXhIcgsQTnYUpaHSxeFEjJqky() 
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,sting):
  try:
   bKExsAkyLwWePTNUFJOnqjtrmCaIBQ=xbmcgui.Dialog()
   bKExsAkyLwWePTNUFJOnqjtrmCaIBQ.notification(__addonname__,sting)
  except:
   bKExsAkyLwWePTNUFJOnqjtrmCaIYM
 def addon_log(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,string):
  try:
   bKExsAkyLwWePTNUFJOnqjtrmCaIBM=string.encode('utf-8','ignore')
  except:
   bKExsAkyLwWePTNUFJOnqjtrmCaIBM='addonException: addon_log'
  bKExsAkyLwWePTNUFJOnqjtrmCaIBo=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,bKExsAkyLwWePTNUFJOnqjtrmCaIBM),level=bKExsAkyLwWePTNUFJOnqjtrmCaIBo)
 def get_keyboard_input(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIuz):
  bKExsAkyLwWePTNUFJOnqjtrmCaIBd=bKExsAkyLwWePTNUFJOnqjtrmCaIYM
  kb=xbmc.Keyboard()
  kb.setHeading(bKExsAkyLwWePTNUFJOnqjtrmCaIuz)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   bKExsAkyLwWePTNUFJOnqjtrmCaIBd=kb.getText()
  return bKExsAkyLwWePTNUFJOnqjtrmCaIBd
 def get_settings_account(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  bKExsAkyLwWePTNUFJOnqjtrmCaIBf =__addon__.getSetting('id')
  bKExsAkyLwWePTNUFJOnqjtrmCaIBi =__addon__.getSetting('pw')
  bKExsAkyLwWePTNUFJOnqjtrmCaIuB =__addon__.getSetting('login_type')
  bKExsAkyLwWePTNUFJOnqjtrmCaIup=bKExsAkyLwWePTNUFJOnqjtrmCaIYo(__addon__.getSetting('selected_profile'))
  return(bKExsAkyLwWePTNUFJOnqjtrmCaIBf,bKExsAkyLwWePTNUFJOnqjtrmCaIBi,bKExsAkyLwWePTNUFJOnqjtrmCaIuB,bKExsAkyLwWePTNUFJOnqjtrmCaIup)
 def get_settings_uhd(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  return bKExsAkyLwWePTNUFJOnqjtrmCaIYd if __addon__.getSetting('active_uhd')=='true' else bKExsAkyLwWePTNUFJOnqjtrmCaIYf
 def get_settings_playback(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  bKExsAkyLwWePTNUFJOnqjtrmCaIuX={'active_uhd':bKExsAkyLwWePTNUFJOnqjtrmCaIYd if __addon__.getSetting('active_uhd')=='true' else bKExsAkyLwWePTNUFJOnqjtrmCaIYf,'streamFilename':bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.TV_STREAM_FILENAME,}
  return bKExsAkyLwWePTNUFJOnqjtrmCaIuX
 def get_settings_proxyport(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  bKExsAkyLwWePTNUFJOnqjtrmCaIuh =bKExsAkyLwWePTNUFJOnqjtrmCaIYd if __addon__.getSetting('proxyYn')=='true' else bKExsAkyLwWePTNUFJOnqjtrmCaIYf
  bKExsAkyLwWePTNUFJOnqjtrmCaIul=bKExsAkyLwWePTNUFJOnqjtrmCaIYo(__addon__.getSetting('proxyPort'))
  return bKExsAkyLwWePTNUFJOnqjtrmCaIuh,bKExsAkyLwWePTNUFJOnqjtrmCaIul
 def get_settings_totalsearch(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  bKExsAkyLwWePTNUFJOnqjtrmCaIuS =bKExsAkyLwWePTNUFJOnqjtrmCaIYd if __addon__.getSetting('local_search')=='true' else bKExsAkyLwWePTNUFJOnqjtrmCaIYf
  bKExsAkyLwWePTNUFJOnqjtrmCaIuY=bKExsAkyLwWePTNUFJOnqjtrmCaIYd if __addon__.getSetting('local_history')=='true' else bKExsAkyLwWePTNUFJOnqjtrmCaIYf
  bKExsAkyLwWePTNUFJOnqjtrmCaIuH =bKExsAkyLwWePTNUFJOnqjtrmCaIYd if __addon__.getSetting('total_search')=='true' else bKExsAkyLwWePTNUFJOnqjtrmCaIYf
  bKExsAkyLwWePTNUFJOnqjtrmCaIuG=bKExsAkyLwWePTNUFJOnqjtrmCaIYd if __addon__.getSetting('total_history')=='true' else bKExsAkyLwWePTNUFJOnqjtrmCaIYf
  bKExsAkyLwWePTNUFJOnqjtrmCaIuv=bKExsAkyLwWePTNUFJOnqjtrmCaIYd if __addon__.getSetting('menu_bookmark')=='true' else bKExsAkyLwWePTNUFJOnqjtrmCaIYf
  return(bKExsAkyLwWePTNUFJOnqjtrmCaIuS,bKExsAkyLwWePTNUFJOnqjtrmCaIuY,bKExsAkyLwWePTNUFJOnqjtrmCaIuH,bKExsAkyLwWePTNUFJOnqjtrmCaIuG,bKExsAkyLwWePTNUFJOnqjtrmCaIuv)
 def get_settings_makebookmark(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  return bKExsAkyLwWePTNUFJOnqjtrmCaIYd if __addon__.getSetting('make_bookmark')=='true' else bKExsAkyLwWePTNUFJOnqjtrmCaIYf
 def get_settings_direct_replay(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  bKExsAkyLwWePTNUFJOnqjtrmCaIuV=bKExsAkyLwWePTNUFJOnqjtrmCaIYo(__addon__.getSetting('direct_replay'))
  if bKExsAkyLwWePTNUFJOnqjtrmCaIuV==0:
   return bKExsAkyLwWePTNUFJOnqjtrmCaIYf
  else:
   return bKExsAkyLwWePTNUFJOnqjtrmCaIYd
 def set_winEpisodeOrderby(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIug):
  __addon__.setSetting('tving_orderby',bKExsAkyLwWePTNUFJOnqjtrmCaIug)
  bKExsAkyLwWePTNUFJOnqjtrmCaIuc=xbmcgui.Window(10000)
  bKExsAkyLwWePTNUFJOnqjtrmCaIuc.setProperty('TVING_M_ORDERBY',bKExsAkyLwWePTNUFJOnqjtrmCaIug)
 def get_winEpisodeOrderby(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  bKExsAkyLwWePTNUFJOnqjtrmCaIug=__addon__.getSetting('tving_orderby')
  if bKExsAkyLwWePTNUFJOnqjtrmCaIug in['',bKExsAkyLwWePTNUFJOnqjtrmCaIYM]:bKExsAkyLwWePTNUFJOnqjtrmCaIug='desc'
  return bKExsAkyLwWePTNUFJOnqjtrmCaIug
 def add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,label,sublabel='',img='',infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params='',isLink=bKExsAkyLwWePTNUFJOnqjtrmCaIYf,ContextMenu=bKExsAkyLwWePTNUFJOnqjtrmCaIYM):
  bKExsAkyLwWePTNUFJOnqjtrmCaIuD='%s?%s'%(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_url,urllib.parse.urlencode(params))
  if sublabel:bKExsAkyLwWePTNUFJOnqjtrmCaIuz='%s < %s >'%(label,sublabel)
  else: bKExsAkyLwWePTNUFJOnqjtrmCaIuz=label
  if not img:img='DefaultFolder.png'
  bKExsAkyLwWePTNUFJOnqjtrmCaIuR=xbmcgui.ListItem(bKExsAkyLwWePTNUFJOnqjtrmCaIuz)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIYi(img)==bKExsAkyLwWePTNUFJOnqjtrmCaIHB:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuR.setArt(img)
  else:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuR.setArt({'thumb':img,'poster':img})
  if bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.KodiVersion>=20:
   if infoLabels:bKExsAkyLwWePTNUFJOnqjtrmCaIBc.Set_InfoTag(bKExsAkyLwWePTNUFJOnqjtrmCaIuR.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:bKExsAkyLwWePTNUFJOnqjtrmCaIuR.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuR.setProperty('IsPlayable','true')
  if ContextMenu:bKExsAkyLwWePTNUFJOnqjtrmCaIuR.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,bKExsAkyLwWePTNUFJOnqjtrmCaIuD,bKExsAkyLwWePTNUFJOnqjtrmCaIuR,isFolder)
 def get_selQuality(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,etype):
  try:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuQ='selected_quality'
   bKExsAkyLwWePTNUFJOnqjtrmCaIuM=[1080,720,480,360]
   bKExsAkyLwWePTNUFJOnqjtrmCaIuo=bKExsAkyLwWePTNUFJOnqjtrmCaIYo(__addon__.getSetting(bKExsAkyLwWePTNUFJOnqjtrmCaIuQ))
   return bKExsAkyLwWePTNUFJOnqjtrmCaIuM[bKExsAkyLwWePTNUFJOnqjtrmCaIuo]
  except:
   bKExsAkyLwWePTNUFJOnqjtrmCaIYM
  return 720 
 def Set_InfoTag(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,video_InfoTag:xbmc.InfoTagVideo,bKExsAkyLwWePTNUFJOnqjtrmCaIpl):
  for bKExsAkyLwWePTNUFJOnqjtrmCaIud,value in bKExsAkyLwWePTNUFJOnqjtrmCaIpl.items():
   if bKExsAkyLwWePTNUFJOnqjtrmCaIBG[bKExsAkyLwWePTNUFJOnqjtrmCaIud]['type']=='string':
    bKExsAkyLwWePTNUFJOnqjtrmCaIHu(video_InfoTag,bKExsAkyLwWePTNUFJOnqjtrmCaIBG[bKExsAkyLwWePTNUFJOnqjtrmCaIud]['func'])(value)
   elif bKExsAkyLwWePTNUFJOnqjtrmCaIBG[bKExsAkyLwWePTNUFJOnqjtrmCaIud]['type']=='int':
    if bKExsAkyLwWePTNUFJOnqjtrmCaIYi(value)==bKExsAkyLwWePTNUFJOnqjtrmCaIYo:
     bKExsAkyLwWePTNUFJOnqjtrmCaIuf=bKExsAkyLwWePTNUFJOnqjtrmCaIYo(value)
    else:
     bKExsAkyLwWePTNUFJOnqjtrmCaIuf=0
    bKExsAkyLwWePTNUFJOnqjtrmCaIHu(video_InfoTag,bKExsAkyLwWePTNUFJOnqjtrmCaIBG[bKExsAkyLwWePTNUFJOnqjtrmCaIud]['func'])(bKExsAkyLwWePTNUFJOnqjtrmCaIuf)
   elif bKExsAkyLwWePTNUFJOnqjtrmCaIBG[bKExsAkyLwWePTNUFJOnqjtrmCaIud]['type']=='actor':
    if value!=[]:
     bKExsAkyLwWePTNUFJOnqjtrmCaIHu(video_InfoTag,bKExsAkyLwWePTNUFJOnqjtrmCaIBG[bKExsAkyLwWePTNUFJOnqjtrmCaIud]['func'])([xbmc.Actor(name)for name in value])
   elif bKExsAkyLwWePTNUFJOnqjtrmCaIBG[bKExsAkyLwWePTNUFJOnqjtrmCaIud]['type']=='list':
    if bKExsAkyLwWePTNUFJOnqjtrmCaIYi(value)==bKExsAkyLwWePTNUFJOnqjtrmCaIHp:
     bKExsAkyLwWePTNUFJOnqjtrmCaIHu(video_InfoTag,bKExsAkyLwWePTNUFJOnqjtrmCaIBG[bKExsAkyLwWePTNUFJOnqjtrmCaIud]['func'])(value)
    else:
     bKExsAkyLwWePTNUFJOnqjtrmCaIHu(video_InfoTag,bKExsAkyLwWePTNUFJOnqjtrmCaIBG[bKExsAkyLwWePTNUFJOnqjtrmCaIud]['func'])([value])
 def dp_Main_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  (bKExsAkyLwWePTNUFJOnqjtrmCaIuS,bKExsAkyLwWePTNUFJOnqjtrmCaIuY,bKExsAkyLwWePTNUFJOnqjtrmCaIuH,bKExsAkyLwWePTNUFJOnqjtrmCaIuG,bKExsAkyLwWePTNUFJOnqjtrmCaIuv)=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_totalsearch()
  for bKExsAkyLwWePTNUFJOnqjtrmCaIui in bKExsAkyLwWePTNUFJOnqjtrmCaIBp:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz=bKExsAkyLwWePTNUFJOnqjtrmCaIui.get('title')
   bKExsAkyLwWePTNUFJOnqjtrmCaIpB=''
   if bKExsAkyLwWePTNUFJOnqjtrmCaIui.get('mode')=='SEARCH_GROUP' and bKExsAkyLwWePTNUFJOnqjtrmCaIuS ==bKExsAkyLwWePTNUFJOnqjtrmCaIYf:continue
   elif bKExsAkyLwWePTNUFJOnqjtrmCaIui.get('mode')=='SEARCH_HISTORY' and bKExsAkyLwWePTNUFJOnqjtrmCaIuY==bKExsAkyLwWePTNUFJOnqjtrmCaIYf:continue
   elif bKExsAkyLwWePTNUFJOnqjtrmCaIui.get('mode')=='TOTAL_SEARCH' and bKExsAkyLwWePTNUFJOnqjtrmCaIuH ==bKExsAkyLwWePTNUFJOnqjtrmCaIYf:continue
   elif bKExsAkyLwWePTNUFJOnqjtrmCaIui.get('mode')=='TOTAL_HISTORY' and bKExsAkyLwWePTNUFJOnqjtrmCaIuG==bKExsAkyLwWePTNUFJOnqjtrmCaIYf:continue
   elif bKExsAkyLwWePTNUFJOnqjtrmCaIui.get('mode')=='MENU_BOOKMARK' and bKExsAkyLwWePTNUFJOnqjtrmCaIuv==bKExsAkyLwWePTNUFJOnqjtrmCaIYf:continue
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':bKExsAkyLwWePTNUFJOnqjtrmCaIui.get('mode'),'stype':bKExsAkyLwWePTNUFJOnqjtrmCaIui.get('stype'),'orderby':bKExsAkyLwWePTNUFJOnqjtrmCaIui.get('orderby'),'ordernm':bKExsAkyLwWePTNUFJOnqjtrmCaIui.get('ordernm'),'page':'1'}
   if bKExsAkyLwWePTNUFJOnqjtrmCaIui.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    bKExsAkyLwWePTNUFJOnqjtrmCaIpX=bKExsAkyLwWePTNUFJOnqjtrmCaIYf
    bKExsAkyLwWePTNUFJOnqjtrmCaIph =bKExsAkyLwWePTNUFJOnqjtrmCaIYd
   else:
    bKExsAkyLwWePTNUFJOnqjtrmCaIpX=bKExsAkyLwWePTNUFJOnqjtrmCaIYd
    bKExsAkyLwWePTNUFJOnqjtrmCaIph =bKExsAkyLwWePTNUFJOnqjtrmCaIYf
   bKExsAkyLwWePTNUFJOnqjtrmCaIpl={'title':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'plot':bKExsAkyLwWePTNUFJOnqjtrmCaIuz}
   if bKExsAkyLwWePTNUFJOnqjtrmCaIui.get('mode')=='XXX':bKExsAkyLwWePTNUFJOnqjtrmCaIpl=bKExsAkyLwWePTNUFJOnqjtrmCaIYM
   if 'icon' in bKExsAkyLwWePTNUFJOnqjtrmCaIui:bKExsAkyLwWePTNUFJOnqjtrmCaIpB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',bKExsAkyLwWePTNUFJOnqjtrmCaIui.get('icon')) 
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel='',img=bKExsAkyLwWePTNUFJOnqjtrmCaIpB,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIpl,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIpX,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu,isLink=bKExsAkyLwWePTNUFJOnqjtrmCaIph)
  xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle)
 def login_main(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  (bKExsAkyLwWePTNUFJOnqjtrmCaIpY,bKExsAkyLwWePTNUFJOnqjtrmCaIpH,bKExsAkyLwWePTNUFJOnqjtrmCaIpG,bKExsAkyLwWePTNUFJOnqjtrmCaIpv)=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_account()
  if not(bKExsAkyLwWePTNUFJOnqjtrmCaIpY and bKExsAkyLwWePTNUFJOnqjtrmCaIpH):
   bKExsAkyLwWePTNUFJOnqjtrmCaIBQ=xbmcgui.Dialog()
   bKExsAkyLwWePTNUFJOnqjtrmCaIpV=bKExsAkyLwWePTNUFJOnqjtrmCaIBQ.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if bKExsAkyLwWePTNUFJOnqjtrmCaIpV==bKExsAkyLwWePTNUFJOnqjtrmCaIYd:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if bKExsAkyLwWePTNUFJOnqjtrmCaIBc.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   bKExsAkyLwWePTNUFJOnqjtrmCaIpc=0
   while bKExsAkyLwWePTNUFJOnqjtrmCaIYd:
    bKExsAkyLwWePTNUFJOnqjtrmCaIpc+=1
    time.sleep(0.05)
    if bKExsAkyLwWePTNUFJOnqjtrmCaIpc>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  bKExsAkyLwWePTNUFJOnqjtrmCaIpg=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.GetCredential(bKExsAkyLwWePTNUFJOnqjtrmCaIpY,bKExsAkyLwWePTNUFJOnqjtrmCaIpH,bKExsAkyLwWePTNUFJOnqjtrmCaIpG,bKExsAkyLwWePTNUFJOnqjtrmCaIpv)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpg:bKExsAkyLwWePTNUFJOnqjtrmCaIBc.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpg==bKExsAkyLwWePTNUFJOnqjtrmCaIYf:
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIpD=bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('stype')
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpD=='live':
   bKExsAkyLwWePTNUFJOnqjtrmCaIpz=bKExsAkyLwWePTNUFJOnqjtrmCaIBX
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIpD=='vod':
   bKExsAkyLwWePTNUFJOnqjtrmCaIpz=bKExsAkyLwWePTNUFJOnqjtrmCaIBS
  else:
   bKExsAkyLwWePTNUFJOnqjtrmCaIpz=bKExsAkyLwWePTNUFJOnqjtrmCaIBY
  for bKExsAkyLwWePTNUFJOnqjtrmCaIpR in bKExsAkyLwWePTNUFJOnqjtrmCaIpz:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz=bKExsAkyLwWePTNUFJOnqjtrmCaIpR.get('title')
   if bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('ordernm')!='-':
    bKExsAkyLwWePTNUFJOnqjtrmCaIuz+='  ('+bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('ordernm')+')'
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':bKExsAkyLwWePTNUFJOnqjtrmCaIpR.get('mode'),'stype':bKExsAkyLwWePTNUFJOnqjtrmCaIpR.get('stype'),'orderby':bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('orderby'),'ordernm':bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('ordernm'),'page':'1'}
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel='',img='',infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIHX(bKExsAkyLwWePTNUFJOnqjtrmCaIpz)>0:xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle)
 def dp_SubTitle_Group(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ): 
  for bKExsAkyLwWePTNUFJOnqjtrmCaIpR in bKExsAkyLwWePTNUFJOnqjtrmCaIBH:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz=bKExsAkyLwWePTNUFJOnqjtrmCaIpR.get('title')
   if bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('ordernm')!='-':
    bKExsAkyLwWePTNUFJOnqjtrmCaIuz+='  ('+bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('ordernm')+')'
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':bKExsAkyLwWePTNUFJOnqjtrmCaIpR.get('mode'),'genreCode':bKExsAkyLwWePTNUFJOnqjtrmCaIpR.get('genreCode'),'stype':bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('stype'),'orderby':bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('orderby'),'page':'1'}
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel='',img='',infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIHX(bKExsAkyLwWePTNUFJOnqjtrmCaIBH)>0:xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle)
 def dp_LiveChannel_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIpD =bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('stype')
  bKExsAkyLwWePTNUFJOnqjtrmCaIpM =bKExsAkyLwWePTNUFJOnqjtrmCaIYo(bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('page'))
  bKExsAkyLwWePTNUFJOnqjtrmCaIpo,bKExsAkyLwWePTNUFJOnqjtrmCaIpd=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.GetLiveChannelList(bKExsAkyLwWePTNUFJOnqjtrmCaIpD,bKExsAkyLwWePTNUFJOnqjtrmCaIpM)
  for bKExsAkyLwWePTNUFJOnqjtrmCaIpf in bKExsAkyLwWePTNUFJOnqjtrmCaIpo:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('title')
   bKExsAkyLwWePTNUFJOnqjtrmCaIpS =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('channel')
   bKExsAkyLwWePTNUFJOnqjtrmCaIpi =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('thumbnail')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXB =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('synopsis')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXu =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('channelepg')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXp =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('cast')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXh =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('director')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXl =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('info_genre')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXS =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('year')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXY =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('mpaa')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXH =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('premiered')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXG={'mediatype':'episode','title':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'studio':bKExsAkyLwWePTNUFJOnqjtrmCaIpS,'cast':bKExsAkyLwWePTNUFJOnqjtrmCaIXp,'director':bKExsAkyLwWePTNUFJOnqjtrmCaIXh,'genre':bKExsAkyLwWePTNUFJOnqjtrmCaIXl,'plot':'%s\n%s\n%s\n\n%s'%(bKExsAkyLwWePTNUFJOnqjtrmCaIpS,bKExsAkyLwWePTNUFJOnqjtrmCaIuz,bKExsAkyLwWePTNUFJOnqjtrmCaIXu,bKExsAkyLwWePTNUFJOnqjtrmCaIXB),'year':bKExsAkyLwWePTNUFJOnqjtrmCaIXS,'mpaa':bKExsAkyLwWePTNUFJOnqjtrmCaIXY,'premiered':bKExsAkyLwWePTNUFJOnqjtrmCaIXH}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'LIVE','mediacode':bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('mediacode'),'stype':bKExsAkyLwWePTNUFJOnqjtrmCaIpD}
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIpS,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIuz,img=bKExsAkyLwWePTNUFJOnqjtrmCaIpi,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIXG,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYf,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpd:
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['mode']='CHANNEL' 
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['stype']=bKExsAkyLwWePTNUFJOnqjtrmCaIpD 
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['page']=bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz='[B]%s >>[/B]'%'다음 페이지'
   bKExsAkyLwWePTNUFJOnqjtrmCaIXv=bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIpB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIXv,img=bKExsAkyLwWePTNUFJOnqjtrmCaIpB,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIHX(bKExsAkyLwWePTNUFJOnqjtrmCaIpo)>0:xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,cacheToDisc=bKExsAkyLwWePTNUFJOnqjtrmCaIYf)
 def dp_Program_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIXV =bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('stype')
  bKExsAkyLwWePTNUFJOnqjtrmCaIug =bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('orderby')
  bKExsAkyLwWePTNUFJOnqjtrmCaIpM =bKExsAkyLwWePTNUFJOnqjtrmCaIYo(bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('page'))
  bKExsAkyLwWePTNUFJOnqjtrmCaIXc=bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('genreCode')
  if bKExsAkyLwWePTNUFJOnqjtrmCaIXc==bKExsAkyLwWePTNUFJOnqjtrmCaIYM:bKExsAkyLwWePTNUFJOnqjtrmCaIXc='all'
  bKExsAkyLwWePTNUFJOnqjtrmCaIXg,bKExsAkyLwWePTNUFJOnqjtrmCaIpd=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.GetProgramList(bKExsAkyLwWePTNUFJOnqjtrmCaIXV,bKExsAkyLwWePTNUFJOnqjtrmCaIug,bKExsAkyLwWePTNUFJOnqjtrmCaIpM,bKExsAkyLwWePTNUFJOnqjtrmCaIXc)
  for bKExsAkyLwWePTNUFJOnqjtrmCaIXD in bKExsAkyLwWePTNUFJOnqjtrmCaIXg:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('title')
   bKExsAkyLwWePTNUFJOnqjtrmCaIpi =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('thumbnail')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXB =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('synopsis')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXz =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('channel')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXp =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('cast')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXh =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('director')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXl=bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('info_genre')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXS =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('year')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXH =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('premiered')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXY =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('mpaa')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXG={'mediatype':'tvshow','title':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'studio':bKExsAkyLwWePTNUFJOnqjtrmCaIXz,'cast':bKExsAkyLwWePTNUFJOnqjtrmCaIXp,'director':bKExsAkyLwWePTNUFJOnqjtrmCaIXh,'genre':bKExsAkyLwWePTNUFJOnqjtrmCaIXl,'year':bKExsAkyLwWePTNUFJOnqjtrmCaIXS,'premiered':bKExsAkyLwWePTNUFJOnqjtrmCaIXH,'mpaa':bKExsAkyLwWePTNUFJOnqjtrmCaIXY,'plot':bKExsAkyLwWePTNUFJOnqjtrmCaIXB}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'EPISODE','programcode':bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('program'),'page':'1'}
   if bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_makebookmark():
    bKExsAkyLwWePTNUFJOnqjtrmCaIXR={'videoid':bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('program'),'vidtype':'tvshow','vtitle':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'vsubtitle':bKExsAkyLwWePTNUFJOnqjtrmCaIXz,}
    bKExsAkyLwWePTNUFJOnqjtrmCaIXQ=json.dumps(bKExsAkyLwWePTNUFJOnqjtrmCaIXR)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXQ=urllib.parse.quote(bKExsAkyLwWePTNUFJOnqjtrmCaIXQ)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(bKExsAkyLwWePTNUFJOnqjtrmCaIXQ)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXo=[('(통합) 찜 영상에 추가',bKExsAkyLwWePTNUFJOnqjtrmCaIXM)]
   else:
    bKExsAkyLwWePTNUFJOnqjtrmCaIXo=bKExsAkyLwWePTNUFJOnqjtrmCaIYM
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIXz,img=bKExsAkyLwWePTNUFJOnqjtrmCaIpi,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIXG,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu,ContextMenu=bKExsAkyLwWePTNUFJOnqjtrmCaIXo)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpd:
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['mode'] ='PROGRAM' 
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['stype'] =bKExsAkyLwWePTNUFJOnqjtrmCaIXV
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['orderby'] =bKExsAkyLwWePTNUFJOnqjtrmCaIug
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['page'] =bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['genreCode']=bKExsAkyLwWePTNUFJOnqjtrmCaIXc 
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz='[B]%s >>[/B]'%'다음 페이지'
   bKExsAkyLwWePTNUFJOnqjtrmCaIXv=bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIpB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIXv,img=bKExsAkyLwWePTNUFJOnqjtrmCaIpB,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  xbmcplugin.setContent(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,cacheToDisc=bKExsAkyLwWePTNUFJOnqjtrmCaIYf)
 def dp_4K_Program_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIpM =bKExsAkyLwWePTNUFJOnqjtrmCaIYo(bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('page'))
  bKExsAkyLwWePTNUFJOnqjtrmCaIXg,bKExsAkyLwWePTNUFJOnqjtrmCaIpd=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Get_UHD_ProgramList(bKExsAkyLwWePTNUFJOnqjtrmCaIpM)
  for bKExsAkyLwWePTNUFJOnqjtrmCaIXD in bKExsAkyLwWePTNUFJOnqjtrmCaIXg:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('title')
   bKExsAkyLwWePTNUFJOnqjtrmCaIpi =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('thumbnail')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXB =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('synopsis')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXz =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('channel')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXp =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('cast')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXh =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('director')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXl=bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('info_genre')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXS =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('year')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXH =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('premiered')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXY =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('mpaa')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXG={'mediatype':'tvshow','title':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'studio':bKExsAkyLwWePTNUFJOnqjtrmCaIXz,'cast':bKExsAkyLwWePTNUFJOnqjtrmCaIXp,'director':bKExsAkyLwWePTNUFJOnqjtrmCaIXh,'genre':bKExsAkyLwWePTNUFJOnqjtrmCaIXl,'year':bKExsAkyLwWePTNUFJOnqjtrmCaIXS,'premiered':bKExsAkyLwWePTNUFJOnqjtrmCaIXH,'mpaa':bKExsAkyLwWePTNUFJOnqjtrmCaIXY,'plot':bKExsAkyLwWePTNUFJOnqjtrmCaIXB}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'EPISODE','programcode':bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('program'),'page':'1'}
   if bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_makebookmark():
    bKExsAkyLwWePTNUFJOnqjtrmCaIXR={'videoid':bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('program'),'vidtype':'tvshow','vtitle':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'vsubtitle':bKExsAkyLwWePTNUFJOnqjtrmCaIXz,}
    bKExsAkyLwWePTNUFJOnqjtrmCaIXQ=json.dumps(bKExsAkyLwWePTNUFJOnqjtrmCaIXR)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXQ=urllib.parse.quote(bKExsAkyLwWePTNUFJOnqjtrmCaIXQ)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(bKExsAkyLwWePTNUFJOnqjtrmCaIXQ)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXo=[('(통합) 찜 영상에 추가',bKExsAkyLwWePTNUFJOnqjtrmCaIXM)]
   else:
    bKExsAkyLwWePTNUFJOnqjtrmCaIXo=bKExsAkyLwWePTNUFJOnqjtrmCaIYM
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIXz,img=bKExsAkyLwWePTNUFJOnqjtrmCaIpi,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIXG,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu,ContextMenu=bKExsAkyLwWePTNUFJOnqjtrmCaIXo)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpd:
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['mode'] ='4K_PROGRAM' 
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['page'] =bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz='[B]%s >>[/B]'%'다음 페이지'
   bKExsAkyLwWePTNUFJOnqjtrmCaIXv=bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIpB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIXv,img=bKExsAkyLwWePTNUFJOnqjtrmCaIpB,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  xbmcplugin.setContent(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,cacheToDisc=bKExsAkyLwWePTNUFJOnqjtrmCaIYf)
 def dp_Ori_Program_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIpM =bKExsAkyLwWePTNUFJOnqjtrmCaIYo(bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('page'))
  bKExsAkyLwWePTNUFJOnqjtrmCaIXg,bKExsAkyLwWePTNUFJOnqjtrmCaIpd=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Get_Origianl_ProgramList(bKExsAkyLwWePTNUFJOnqjtrmCaIpM)
  for bKExsAkyLwWePTNUFJOnqjtrmCaIXD in bKExsAkyLwWePTNUFJOnqjtrmCaIXg:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('title')
   bKExsAkyLwWePTNUFJOnqjtrmCaIpi =bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('thumbnail')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXG={'mediatype':'tvshow','title':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'EPISODE','programcode':bKExsAkyLwWePTNUFJOnqjtrmCaIXD.get('program'),'page':'1',}
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,img=bKExsAkyLwWePTNUFJOnqjtrmCaIpi,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIXG,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu,ContextMenu=bKExsAkyLwWePTNUFJOnqjtrmCaIYM)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpd:
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['mode'] ='ORI_PROGRAM' 
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['page'] =bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz='[B]%s >>[/B]'%'다음 페이지'
   bKExsAkyLwWePTNUFJOnqjtrmCaIXv=bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIpB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIXv,img=bKExsAkyLwWePTNUFJOnqjtrmCaIpB,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  xbmcplugin.setContent(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,cacheToDisc=bKExsAkyLwWePTNUFJOnqjtrmCaIYf)
 def dp_Episode_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIXf=bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('programcode')
  bKExsAkyLwWePTNUFJOnqjtrmCaIpM =bKExsAkyLwWePTNUFJOnqjtrmCaIYo(bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('page'))
  bKExsAkyLwWePTNUFJOnqjtrmCaIXi,bKExsAkyLwWePTNUFJOnqjtrmCaIpd,bKExsAkyLwWePTNUFJOnqjtrmCaIhB=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.GetEpisodeList(bKExsAkyLwWePTNUFJOnqjtrmCaIXf,bKExsAkyLwWePTNUFJOnqjtrmCaIpM,orderby=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_winEpisodeOrderby())
  for bKExsAkyLwWePTNUFJOnqjtrmCaIhu in bKExsAkyLwWePTNUFJOnqjtrmCaIXi:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz =bKExsAkyLwWePTNUFJOnqjtrmCaIhu.get('title')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXv =bKExsAkyLwWePTNUFJOnqjtrmCaIhu.get('subtitle')
   bKExsAkyLwWePTNUFJOnqjtrmCaIpi =bKExsAkyLwWePTNUFJOnqjtrmCaIhu.get('thumbnail')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXB =bKExsAkyLwWePTNUFJOnqjtrmCaIhu.get('synopsis')
   bKExsAkyLwWePTNUFJOnqjtrmCaIhp=bKExsAkyLwWePTNUFJOnqjtrmCaIhu.get('info_title')
   bKExsAkyLwWePTNUFJOnqjtrmCaIhX =bKExsAkyLwWePTNUFJOnqjtrmCaIhu.get('aired')
   bKExsAkyLwWePTNUFJOnqjtrmCaIhl =bKExsAkyLwWePTNUFJOnqjtrmCaIhu.get('studio')
   bKExsAkyLwWePTNUFJOnqjtrmCaIhS =bKExsAkyLwWePTNUFJOnqjtrmCaIhu.get('frequency')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXG={'mediatype':'episode','title':bKExsAkyLwWePTNUFJOnqjtrmCaIhp,'aired':bKExsAkyLwWePTNUFJOnqjtrmCaIhX,'studio':bKExsAkyLwWePTNUFJOnqjtrmCaIhl,'episode':bKExsAkyLwWePTNUFJOnqjtrmCaIhS,'plot':bKExsAkyLwWePTNUFJOnqjtrmCaIXB}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'VOD','mediacode':bKExsAkyLwWePTNUFJOnqjtrmCaIhu.get('episode'),'stype':'vod','programcode':bKExsAkyLwWePTNUFJOnqjtrmCaIXf,'title':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'thumbnail':bKExsAkyLwWePTNUFJOnqjtrmCaIpi}
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIXv,img=bKExsAkyLwWePTNUFJOnqjtrmCaIpi,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIXG,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYf,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpM==1:
   bKExsAkyLwWePTNUFJOnqjtrmCaIXG={'plot':'정렬순서를 변경합니다.'}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['mode'] ='ORDER_BY' 
   if bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_winEpisodeOrderby()=='desc':
    bKExsAkyLwWePTNUFJOnqjtrmCaIuz='정렬순서변경 : 최신화부터 -> 1회부터'
    bKExsAkyLwWePTNUFJOnqjtrmCaIpu['orderby']='asc'
   else:
    bKExsAkyLwWePTNUFJOnqjtrmCaIuz='정렬순서변경 : 1회부터 -> 최신화부터'
    bKExsAkyLwWePTNUFJOnqjtrmCaIpu['orderby']='desc'
   bKExsAkyLwWePTNUFJOnqjtrmCaIpB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel='',img=bKExsAkyLwWePTNUFJOnqjtrmCaIpB,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIXG,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYf,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu,isLink=bKExsAkyLwWePTNUFJOnqjtrmCaIYd)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpd:
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['mode'] ='EPISODE' 
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['programcode']=bKExsAkyLwWePTNUFJOnqjtrmCaIXf
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['page'] =bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz='[B]%s >>[/B]'%'다음 페이지'
   bKExsAkyLwWePTNUFJOnqjtrmCaIXv=bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIpB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIXv,img=bKExsAkyLwWePTNUFJOnqjtrmCaIpB,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  xbmcplugin.setContent(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,'episodes')
  if bKExsAkyLwWePTNUFJOnqjtrmCaIHX(bKExsAkyLwWePTNUFJOnqjtrmCaIXi)>0:xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,cacheToDisc=bKExsAkyLwWePTNUFJOnqjtrmCaIYd)
 def dp_setEpOrderby(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIug =bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('orderby')
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.set_winEpisodeOrderby(bKExsAkyLwWePTNUFJOnqjtrmCaIug)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIXV =bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('stype')
  bKExsAkyLwWePTNUFJOnqjtrmCaIug =bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('orderby')
  bKExsAkyLwWePTNUFJOnqjtrmCaIpM=bKExsAkyLwWePTNUFJOnqjtrmCaIYo(bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('page'))
  bKExsAkyLwWePTNUFJOnqjtrmCaIhY,bKExsAkyLwWePTNUFJOnqjtrmCaIpd=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.GetMovieList(bKExsAkyLwWePTNUFJOnqjtrmCaIXV,bKExsAkyLwWePTNUFJOnqjtrmCaIug,bKExsAkyLwWePTNUFJOnqjtrmCaIpM)
  for bKExsAkyLwWePTNUFJOnqjtrmCaIhH in bKExsAkyLwWePTNUFJOnqjtrmCaIhY:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('title')
   bKExsAkyLwWePTNUFJOnqjtrmCaIpi =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('thumbnail')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXB =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('synopsis')
   bKExsAkyLwWePTNUFJOnqjtrmCaIhp =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('info_title')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXS =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('year')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXp =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('cast')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXh =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('director')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXl =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('info_genre')
   bKExsAkyLwWePTNUFJOnqjtrmCaIhG =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('duration')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXH =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('premiered')
   bKExsAkyLwWePTNUFJOnqjtrmCaIhl =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('studio')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXY =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('mpaa')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXG={'mediatype':'movie','title':bKExsAkyLwWePTNUFJOnqjtrmCaIhp,'year':bKExsAkyLwWePTNUFJOnqjtrmCaIXS,'cast':bKExsAkyLwWePTNUFJOnqjtrmCaIXp,'director':bKExsAkyLwWePTNUFJOnqjtrmCaIXh,'genre':bKExsAkyLwWePTNUFJOnqjtrmCaIXl,'duration':bKExsAkyLwWePTNUFJOnqjtrmCaIhG,'premiered':bKExsAkyLwWePTNUFJOnqjtrmCaIXH,'studio':bKExsAkyLwWePTNUFJOnqjtrmCaIhl,'mpaa':bKExsAkyLwWePTNUFJOnqjtrmCaIXY,'plot':bKExsAkyLwWePTNUFJOnqjtrmCaIXB}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'MOVIE','mediacode':bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('moviecode'),'stype':'movie','title':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'thumbnail':bKExsAkyLwWePTNUFJOnqjtrmCaIpi}
   if bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_makebookmark():
    bKExsAkyLwWePTNUFJOnqjtrmCaIXR={'videoid':bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('moviecode'),'vidtype':'movie','vtitle':bKExsAkyLwWePTNUFJOnqjtrmCaIhp,'vsubtitle':'',}
    bKExsAkyLwWePTNUFJOnqjtrmCaIXQ=json.dumps(bKExsAkyLwWePTNUFJOnqjtrmCaIXR)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXQ=urllib.parse.quote(bKExsAkyLwWePTNUFJOnqjtrmCaIXQ)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(bKExsAkyLwWePTNUFJOnqjtrmCaIXQ)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXo=[('(통합) 찜 영상에 추가',bKExsAkyLwWePTNUFJOnqjtrmCaIXM)]
   else:
    bKExsAkyLwWePTNUFJOnqjtrmCaIXo=bKExsAkyLwWePTNUFJOnqjtrmCaIYM
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel='',img=bKExsAkyLwWePTNUFJOnqjtrmCaIpi,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIXG,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYf,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu,ContextMenu=bKExsAkyLwWePTNUFJOnqjtrmCaIXo)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpd:
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['mode'] ='MOVIE_SUB' 
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['orderby']=bKExsAkyLwWePTNUFJOnqjtrmCaIug
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['stype'] =bKExsAkyLwWePTNUFJOnqjtrmCaIXV
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['page'] =bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz='[B]%s >>[/B]'%'다음 페이지'
   bKExsAkyLwWePTNUFJOnqjtrmCaIXv=bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIpB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIXv,img=bKExsAkyLwWePTNUFJOnqjtrmCaIpB,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  xbmcplugin.setContent(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,'movies')
  xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,cacheToDisc=bKExsAkyLwWePTNUFJOnqjtrmCaIYf)
 def dp_4K_Movie_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIpM=bKExsAkyLwWePTNUFJOnqjtrmCaIYo(bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('page'))
  bKExsAkyLwWePTNUFJOnqjtrmCaIhY,bKExsAkyLwWePTNUFJOnqjtrmCaIpd=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Get_UHD_MovieList(bKExsAkyLwWePTNUFJOnqjtrmCaIpM)
  for bKExsAkyLwWePTNUFJOnqjtrmCaIhH in bKExsAkyLwWePTNUFJOnqjtrmCaIhY:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('title')
   bKExsAkyLwWePTNUFJOnqjtrmCaIpi =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('thumbnail')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXB =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('synopsis')
   bKExsAkyLwWePTNUFJOnqjtrmCaIhp =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('info_title')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXS =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('year')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXp =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('cast')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXh =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('director')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXl =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('info_genre')
   bKExsAkyLwWePTNUFJOnqjtrmCaIhG =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('duration')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXH =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('premiered')
   bKExsAkyLwWePTNUFJOnqjtrmCaIhl =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('studio')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXY =bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('mpaa')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXG={'mediatype':'movie','title':bKExsAkyLwWePTNUFJOnqjtrmCaIhp,'year':bKExsAkyLwWePTNUFJOnqjtrmCaIXS,'cast':bKExsAkyLwWePTNUFJOnqjtrmCaIXp,'director':bKExsAkyLwWePTNUFJOnqjtrmCaIXh,'genre':bKExsAkyLwWePTNUFJOnqjtrmCaIXl,'duration':bKExsAkyLwWePTNUFJOnqjtrmCaIhG,'premiered':bKExsAkyLwWePTNUFJOnqjtrmCaIXH,'studio':bKExsAkyLwWePTNUFJOnqjtrmCaIhl,'mpaa':bKExsAkyLwWePTNUFJOnqjtrmCaIXY,'plot':bKExsAkyLwWePTNUFJOnqjtrmCaIXB}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'MOVIE','mediacode':bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('moviecode'),'stype':'movie','title':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'thumbnail':bKExsAkyLwWePTNUFJOnqjtrmCaIpi}
   if bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_makebookmark():
    bKExsAkyLwWePTNUFJOnqjtrmCaIXR={'videoid':bKExsAkyLwWePTNUFJOnqjtrmCaIhH.get('moviecode'),'vidtype':'movie','vtitle':bKExsAkyLwWePTNUFJOnqjtrmCaIhp,'vsubtitle':'',}
    bKExsAkyLwWePTNUFJOnqjtrmCaIXQ=json.dumps(bKExsAkyLwWePTNUFJOnqjtrmCaIXR)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXQ=urllib.parse.quote(bKExsAkyLwWePTNUFJOnqjtrmCaIXQ)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(bKExsAkyLwWePTNUFJOnqjtrmCaIXQ)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXo=[('(통합) 찜 영상에 추가',bKExsAkyLwWePTNUFJOnqjtrmCaIXM)]
   else:
    bKExsAkyLwWePTNUFJOnqjtrmCaIXo=bKExsAkyLwWePTNUFJOnqjtrmCaIYM
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel='',img=bKExsAkyLwWePTNUFJOnqjtrmCaIpi,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIXG,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYf,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu,ContextMenu=bKExsAkyLwWePTNUFJOnqjtrmCaIXo)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpd:
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['mode'] ='4K_MOVIE' 
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['page'] =bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz='[B]%s >>[/B]'%'다음 페이지'
   bKExsAkyLwWePTNUFJOnqjtrmCaIXv=bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIpB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIXv,img=bKExsAkyLwWePTNUFJOnqjtrmCaIpB,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  xbmcplugin.setContent(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,'movies')
  xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,cacheToDisc=bKExsAkyLwWePTNUFJOnqjtrmCaIYf)
 def dp_Set_Bookmark(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIhv=urllib.parse.unquote(bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('bm_param'))
  bKExsAkyLwWePTNUFJOnqjtrmCaIhv=json.loads(bKExsAkyLwWePTNUFJOnqjtrmCaIhv)
  bKExsAkyLwWePTNUFJOnqjtrmCaIhV =bKExsAkyLwWePTNUFJOnqjtrmCaIhv.get('videoid')
  bKExsAkyLwWePTNUFJOnqjtrmCaIhc =bKExsAkyLwWePTNUFJOnqjtrmCaIhv.get('vidtype')
  bKExsAkyLwWePTNUFJOnqjtrmCaIhg =bKExsAkyLwWePTNUFJOnqjtrmCaIhv.get('vtitle')
  bKExsAkyLwWePTNUFJOnqjtrmCaIhD =bKExsAkyLwWePTNUFJOnqjtrmCaIhv.get('vsubtitle')
  bKExsAkyLwWePTNUFJOnqjtrmCaIBQ=xbmcgui.Dialog()
  bKExsAkyLwWePTNUFJOnqjtrmCaIpV=bKExsAkyLwWePTNUFJOnqjtrmCaIBQ.yesno(__language__(30913).encode('utf8'),bKExsAkyLwWePTNUFJOnqjtrmCaIhg+' \n\n'+__language__(30914))
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpV==bKExsAkyLwWePTNUFJOnqjtrmCaIYf:return
  bKExsAkyLwWePTNUFJOnqjtrmCaIhz=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.GetBookmarkInfo(bKExsAkyLwWePTNUFJOnqjtrmCaIhV,bKExsAkyLwWePTNUFJOnqjtrmCaIhc)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIhD!='':
   bKExsAkyLwWePTNUFJOnqjtrmCaIhz['saveinfo']['subtitle']=bKExsAkyLwWePTNUFJOnqjtrmCaIhD 
   if bKExsAkyLwWePTNUFJOnqjtrmCaIhc=='tvshow':bKExsAkyLwWePTNUFJOnqjtrmCaIhz['saveinfo']['infoLabels']['studio']=bKExsAkyLwWePTNUFJOnqjtrmCaIhD 
  bKExsAkyLwWePTNUFJOnqjtrmCaIhR=json.dumps(bKExsAkyLwWePTNUFJOnqjtrmCaIhz)
  bKExsAkyLwWePTNUFJOnqjtrmCaIhR=urllib.parse.quote(bKExsAkyLwWePTNUFJOnqjtrmCaIhR)
  bKExsAkyLwWePTNUFJOnqjtrmCaIXM ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(bKExsAkyLwWePTNUFJOnqjtrmCaIhR)
  xbmc.executebuiltin(bKExsAkyLwWePTNUFJOnqjtrmCaIXM)
 def dp_Search_Group(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  if 'search_key' in bKExsAkyLwWePTNUFJOnqjtrmCaIpQ:
   bKExsAkyLwWePTNUFJOnqjtrmCaIhQ=bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('search_key')
  else:
   bKExsAkyLwWePTNUFJOnqjtrmCaIhQ=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not bKExsAkyLwWePTNUFJOnqjtrmCaIhQ:
    return
  for bKExsAkyLwWePTNUFJOnqjtrmCaIpR in bKExsAkyLwWePTNUFJOnqjtrmCaIBl:
   bKExsAkyLwWePTNUFJOnqjtrmCaIhM =bKExsAkyLwWePTNUFJOnqjtrmCaIpR.get('mode')
   bKExsAkyLwWePTNUFJOnqjtrmCaIpD=bKExsAkyLwWePTNUFJOnqjtrmCaIpR.get('stype')
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz=bKExsAkyLwWePTNUFJOnqjtrmCaIpR.get('title')
   (bKExsAkyLwWePTNUFJOnqjtrmCaIho,bKExsAkyLwWePTNUFJOnqjtrmCaIpd)=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.GetSearchList(bKExsAkyLwWePTNUFJOnqjtrmCaIhQ,1,bKExsAkyLwWePTNUFJOnqjtrmCaIpD)
   bKExsAkyLwWePTNUFJOnqjtrmCaIpl={'plot':'검색어 : '+bKExsAkyLwWePTNUFJOnqjtrmCaIhQ+'\n\n'+bKExsAkyLwWePTNUFJOnqjtrmCaIBc.Search_FreeList(bKExsAkyLwWePTNUFJOnqjtrmCaIho)}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':bKExsAkyLwWePTNUFJOnqjtrmCaIhM,'stype':bKExsAkyLwWePTNUFJOnqjtrmCaIpD,'search_key':bKExsAkyLwWePTNUFJOnqjtrmCaIhQ,'page':'1',}
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel='',img='',infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIpl,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIHX(bKExsAkyLwWePTNUFJOnqjtrmCaIBl)>0:xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,cacheToDisc=bKExsAkyLwWePTNUFJOnqjtrmCaIYd)
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.Save_Searched_List(bKExsAkyLwWePTNUFJOnqjtrmCaIhQ)
 def Search_FreeList(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIlS):
  bKExsAkyLwWePTNUFJOnqjtrmCaIhd=''
  bKExsAkyLwWePTNUFJOnqjtrmCaIhf=7
  try:
   if bKExsAkyLwWePTNUFJOnqjtrmCaIHX(bKExsAkyLwWePTNUFJOnqjtrmCaIlS)==0:return '검색결과 없음'
   for i in bKExsAkyLwWePTNUFJOnqjtrmCaIHl(bKExsAkyLwWePTNUFJOnqjtrmCaIHX(bKExsAkyLwWePTNUFJOnqjtrmCaIlS)):
    if i>=bKExsAkyLwWePTNUFJOnqjtrmCaIhf:
     bKExsAkyLwWePTNUFJOnqjtrmCaIhd=bKExsAkyLwWePTNUFJOnqjtrmCaIhd+'...'
     break
    bKExsAkyLwWePTNUFJOnqjtrmCaIhd=bKExsAkyLwWePTNUFJOnqjtrmCaIhd+bKExsAkyLwWePTNUFJOnqjtrmCaIlS[i]['title']+'\n'
  except:
   return ''
  return bKExsAkyLwWePTNUFJOnqjtrmCaIhd
 def dp_Search_History(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIhi=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.Load_List_File('search')
  for bKExsAkyLwWePTNUFJOnqjtrmCaIlB in bKExsAkyLwWePTNUFJOnqjtrmCaIhi:
   bKExsAkyLwWePTNUFJOnqjtrmCaIlu=bKExsAkyLwWePTNUFJOnqjtrmCaIHB(urllib.parse.parse_qsl(bKExsAkyLwWePTNUFJOnqjtrmCaIlB))
   bKExsAkyLwWePTNUFJOnqjtrmCaIlp=bKExsAkyLwWePTNUFJOnqjtrmCaIlu.get('skey').strip()
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'SEARCH_GROUP','search_key':bKExsAkyLwWePTNUFJOnqjtrmCaIlp,}
   bKExsAkyLwWePTNUFJOnqjtrmCaIlX={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':bKExsAkyLwWePTNUFJOnqjtrmCaIlp,'vType':'-',}
   bKExsAkyLwWePTNUFJOnqjtrmCaIlh=urllib.parse.urlencode(bKExsAkyLwWePTNUFJOnqjtrmCaIlX)
   bKExsAkyLwWePTNUFJOnqjtrmCaIXo=[('선택된 검색어 ( %s ) 삭제'%(bKExsAkyLwWePTNUFJOnqjtrmCaIlp),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(bKExsAkyLwWePTNUFJOnqjtrmCaIlh))]
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIlp,sublabel='',img=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu,ContextMenu=bKExsAkyLwWePTNUFJOnqjtrmCaIXo)
  bKExsAkyLwWePTNUFJOnqjtrmCaIXG={'plot':'검색목록 전체를 삭제합니다.'}
  bKExsAkyLwWePTNUFJOnqjtrmCaIuz='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  bKExsAkyLwWePTNUFJOnqjtrmCaIpB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel='',img=bKExsAkyLwWePTNUFJOnqjtrmCaIpB,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIXG,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYf,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu,isLink=bKExsAkyLwWePTNUFJOnqjtrmCaIYd)
  xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,cacheToDisc=bKExsAkyLwWePTNUFJOnqjtrmCaIYf)
 def dp_Search_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIpM =bKExsAkyLwWePTNUFJOnqjtrmCaIYo(bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('page'))
  bKExsAkyLwWePTNUFJOnqjtrmCaIpD =bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('stype')
  if 'search_key' in bKExsAkyLwWePTNUFJOnqjtrmCaIpQ:
   bKExsAkyLwWePTNUFJOnqjtrmCaIhQ=bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('search_key')
  else:
   bKExsAkyLwWePTNUFJOnqjtrmCaIhQ=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not bKExsAkyLwWePTNUFJOnqjtrmCaIhQ:
    xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle)
    return
  bKExsAkyLwWePTNUFJOnqjtrmCaIho,bKExsAkyLwWePTNUFJOnqjtrmCaIpd=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.GetSearchList(bKExsAkyLwWePTNUFJOnqjtrmCaIhQ,bKExsAkyLwWePTNUFJOnqjtrmCaIpM,bKExsAkyLwWePTNUFJOnqjtrmCaIpD)
  for bKExsAkyLwWePTNUFJOnqjtrmCaIlS in bKExsAkyLwWePTNUFJOnqjtrmCaIho:
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz =bKExsAkyLwWePTNUFJOnqjtrmCaIlS.get('title')
   bKExsAkyLwWePTNUFJOnqjtrmCaIpi =bKExsAkyLwWePTNUFJOnqjtrmCaIlS.get('thumbnail')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXB =bKExsAkyLwWePTNUFJOnqjtrmCaIlS.get('synopsis')
   bKExsAkyLwWePTNUFJOnqjtrmCaIlY =bKExsAkyLwWePTNUFJOnqjtrmCaIlS.get('program')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXp =bKExsAkyLwWePTNUFJOnqjtrmCaIlS.get('cast')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXh =bKExsAkyLwWePTNUFJOnqjtrmCaIlS.get('director')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXl=bKExsAkyLwWePTNUFJOnqjtrmCaIlS.get('info_genre')
   bKExsAkyLwWePTNUFJOnqjtrmCaIhG =bKExsAkyLwWePTNUFJOnqjtrmCaIlS.get('duration')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXY =bKExsAkyLwWePTNUFJOnqjtrmCaIlS.get('mpaa')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXS =bKExsAkyLwWePTNUFJOnqjtrmCaIlS.get('year')
   bKExsAkyLwWePTNUFJOnqjtrmCaIhX =bKExsAkyLwWePTNUFJOnqjtrmCaIlS.get('aired')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXG={'mediatype':'tvshow' if bKExsAkyLwWePTNUFJOnqjtrmCaIpD=='vod' else 'movie','title':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'cast':bKExsAkyLwWePTNUFJOnqjtrmCaIXp,'director':bKExsAkyLwWePTNUFJOnqjtrmCaIXh,'genre':bKExsAkyLwWePTNUFJOnqjtrmCaIXl,'duration':bKExsAkyLwWePTNUFJOnqjtrmCaIhG,'mpaa':bKExsAkyLwWePTNUFJOnqjtrmCaIXY,'year':bKExsAkyLwWePTNUFJOnqjtrmCaIXS,'aired':bKExsAkyLwWePTNUFJOnqjtrmCaIhX,'plot':'%s\n\n%s'%(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,bKExsAkyLwWePTNUFJOnqjtrmCaIXB)}
   if bKExsAkyLwWePTNUFJOnqjtrmCaIpD=='vod':
    bKExsAkyLwWePTNUFJOnqjtrmCaIhV=bKExsAkyLwWePTNUFJOnqjtrmCaIlS.get('program')
    bKExsAkyLwWePTNUFJOnqjtrmCaIhc='tvshow'
    bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'EPISODE','programcode':bKExsAkyLwWePTNUFJOnqjtrmCaIhV,'page':'1',}
    bKExsAkyLwWePTNUFJOnqjtrmCaIpX=bKExsAkyLwWePTNUFJOnqjtrmCaIYd
   else:
    bKExsAkyLwWePTNUFJOnqjtrmCaIhV=bKExsAkyLwWePTNUFJOnqjtrmCaIlS.get('movie')
    bKExsAkyLwWePTNUFJOnqjtrmCaIhc='movie'
    bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'MOVIE','mediacode':bKExsAkyLwWePTNUFJOnqjtrmCaIhV,'stype':'movie','title':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'thumbnail':bKExsAkyLwWePTNUFJOnqjtrmCaIpi,}
    bKExsAkyLwWePTNUFJOnqjtrmCaIpX=bKExsAkyLwWePTNUFJOnqjtrmCaIYf
   if bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_makebookmark():
    bKExsAkyLwWePTNUFJOnqjtrmCaIXR={'videoid':bKExsAkyLwWePTNUFJOnqjtrmCaIhV,'vidtype':bKExsAkyLwWePTNUFJOnqjtrmCaIhc,'vtitle':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'vsubtitle':'',}
    bKExsAkyLwWePTNUFJOnqjtrmCaIXQ=json.dumps(bKExsAkyLwWePTNUFJOnqjtrmCaIXR)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXQ=urllib.parse.quote(bKExsAkyLwWePTNUFJOnqjtrmCaIXQ)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXM='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(bKExsAkyLwWePTNUFJOnqjtrmCaIXQ)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXo=[('(통합) 찜 영상에 추가',bKExsAkyLwWePTNUFJOnqjtrmCaIXM)]
   else:
    bKExsAkyLwWePTNUFJOnqjtrmCaIXo=bKExsAkyLwWePTNUFJOnqjtrmCaIYM
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel='',img=bKExsAkyLwWePTNUFJOnqjtrmCaIpi,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIXG,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIpX,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu,isLink=bKExsAkyLwWePTNUFJOnqjtrmCaIYf,ContextMenu=bKExsAkyLwWePTNUFJOnqjtrmCaIXo)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpd:
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['mode'] ='SEARCH' 
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['search_key']=bKExsAkyLwWePTNUFJOnqjtrmCaIhQ
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu['page'] =bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz='[B]%s >>[/B]'%'다음 페이지'
   bKExsAkyLwWePTNUFJOnqjtrmCaIXv=bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaIpM+1)
   bKExsAkyLwWePTNUFJOnqjtrmCaIpB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIXv,img=bKExsAkyLwWePTNUFJOnqjtrmCaIpB,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpD=='movie':xbmcplugin.setContent(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,'movies')
  else:xbmcplugin.setContent(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,cacheToDisc=bKExsAkyLwWePTNUFJOnqjtrmCaIYf)
 def dp_History_Remove(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIlH=bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('delType')
  bKExsAkyLwWePTNUFJOnqjtrmCaIlG =bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('sKey')
  bKExsAkyLwWePTNUFJOnqjtrmCaIlv =bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('vType')
  bKExsAkyLwWePTNUFJOnqjtrmCaIBQ=xbmcgui.Dialog()
  if bKExsAkyLwWePTNUFJOnqjtrmCaIlH=='SEARCH_ALL':
   bKExsAkyLwWePTNUFJOnqjtrmCaIpV=bKExsAkyLwWePTNUFJOnqjtrmCaIBQ.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIlH=='SEARCH_ONE':
   bKExsAkyLwWePTNUFJOnqjtrmCaIpV=bKExsAkyLwWePTNUFJOnqjtrmCaIBQ.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIlH=='WATCH_ALL':
   bKExsAkyLwWePTNUFJOnqjtrmCaIpV=bKExsAkyLwWePTNUFJOnqjtrmCaIBQ.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIlH=='WATCH_ONE':
   bKExsAkyLwWePTNUFJOnqjtrmCaIpV=bKExsAkyLwWePTNUFJOnqjtrmCaIBQ.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpV==bKExsAkyLwWePTNUFJOnqjtrmCaIYf:sys.exit()
  if bKExsAkyLwWePTNUFJOnqjtrmCaIlH=='SEARCH_ALL':
   if os.path.isfile(bKExsAkyLwWePTNUFJOnqjtrmCaIBV):os.remove(bKExsAkyLwWePTNUFJOnqjtrmCaIBV)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIlH=='SEARCH_ONE':
   try:
    bKExsAkyLwWePTNUFJOnqjtrmCaIlV=bKExsAkyLwWePTNUFJOnqjtrmCaIBV
    bKExsAkyLwWePTNUFJOnqjtrmCaIlc=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.Load_List_File('search') 
    fp=bKExsAkyLwWePTNUFJOnqjtrmCaIHS(bKExsAkyLwWePTNUFJOnqjtrmCaIlV,'w',-1,'utf-8')
    for bKExsAkyLwWePTNUFJOnqjtrmCaIlg in bKExsAkyLwWePTNUFJOnqjtrmCaIlc:
     bKExsAkyLwWePTNUFJOnqjtrmCaIlD=bKExsAkyLwWePTNUFJOnqjtrmCaIHB(urllib.parse.parse_qsl(bKExsAkyLwWePTNUFJOnqjtrmCaIlg))
     bKExsAkyLwWePTNUFJOnqjtrmCaIlz=bKExsAkyLwWePTNUFJOnqjtrmCaIlD.get('skey').strip()
     if bKExsAkyLwWePTNUFJOnqjtrmCaIlG!=bKExsAkyLwWePTNUFJOnqjtrmCaIlz:
      fp.write(bKExsAkyLwWePTNUFJOnqjtrmCaIlg)
    fp.close()
   except:
    bKExsAkyLwWePTNUFJOnqjtrmCaIYM
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIlH=='WATCH_ALL':
   bKExsAkyLwWePTNUFJOnqjtrmCaIlV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bKExsAkyLwWePTNUFJOnqjtrmCaIlv))
   if os.path.isfile(bKExsAkyLwWePTNUFJOnqjtrmCaIlV):os.remove(bKExsAkyLwWePTNUFJOnqjtrmCaIlV)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIlH=='WATCH_ONE':
   bKExsAkyLwWePTNUFJOnqjtrmCaIlV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bKExsAkyLwWePTNUFJOnqjtrmCaIlv))
   try:
    bKExsAkyLwWePTNUFJOnqjtrmCaIlc=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.Load_List_File(bKExsAkyLwWePTNUFJOnqjtrmCaIlv) 
    fp=bKExsAkyLwWePTNUFJOnqjtrmCaIHS(bKExsAkyLwWePTNUFJOnqjtrmCaIlV,'w',-1,'utf-8')
    for bKExsAkyLwWePTNUFJOnqjtrmCaIlg in bKExsAkyLwWePTNUFJOnqjtrmCaIlc:
     bKExsAkyLwWePTNUFJOnqjtrmCaIlD=bKExsAkyLwWePTNUFJOnqjtrmCaIHB(urllib.parse.parse_qsl(bKExsAkyLwWePTNUFJOnqjtrmCaIlg))
     bKExsAkyLwWePTNUFJOnqjtrmCaIlz=bKExsAkyLwWePTNUFJOnqjtrmCaIlD.get('code').strip()
     if bKExsAkyLwWePTNUFJOnqjtrmCaIlG!=bKExsAkyLwWePTNUFJOnqjtrmCaIlz:
      fp.write(bKExsAkyLwWePTNUFJOnqjtrmCaIlg)
    fp.close()
   except:
    bKExsAkyLwWePTNUFJOnqjtrmCaIYM
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpD): 
  try:
   if bKExsAkyLwWePTNUFJOnqjtrmCaIpD=='search':
    bKExsAkyLwWePTNUFJOnqjtrmCaIlV=bKExsAkyLwWePTNUFJOnqjtrmCaIBV
   elif bKExsAkyLwWePTNUFJOnqjtrmCaIpD in['vod','movie']:
    bKExsAkyLwWePTNUFJOnqjtrmCaIlV=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bKExsAkyLwWePTNUFJOnqjtrmCaIpD))
   else:
    return[]
   fp=bKExsAkyLwWePTNUFJOnqjtrmCaIHS(bKExsAkyLwWePTNUFJOnqjtrmCaIlV,'r',-1,'utf-8')
   bKExsAkyLwWePTNUFJOnqjtrmCaIlR=fp.readlines()
   fp.close()
  except:
   bKExsAkyLwWePTNUFJOnqjtrmCaIlR=[]
  return bKExsAkyLwWePTNUFJOnqjtrmCaIlR
 def Save_Watched_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpD,bKExsAkyLwWePTNUFJOnqjtrmCaIBz):
  try:
   bKExsAkyLwWePTNUFJOnqjtrmCaIlQ=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bKExsAkyLwWePTNUFJOnqjtrmCaIpD))
   bKExsAkyLwWePTNUFJOnqjtrmCaIlc=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.Load_List_File(bKExsAkyLwWePTNUFJOnqjtrmCaIpD) 
   fp=bKExsAkyLwWePTNUFJOnqjtrmCaIHS(bKExsAkyLwWePTNUFJOnqjtrmCaIlQ,'w',-1,'utf-8')
   bKExsAkyLwWePTNUFJOnqjtrmCaIlM=urllib.parse.urlencode(bKExsAkyLwWePTNUFJOnqjtrmCaIBz)
   bKExsAkyLwWePTNUFJOnqjtrmCaIlM=bKExsAkyLwWePTNUFJOnqjtrmCaIlM+'\n'
   fp.write(bKExsAkyLwWePTNUFJOnqjtrmCaIlM)
   bKExsAkyLwWePTNUFJOnqjtrmCaIlo=0
   for bKExsAkyLwWePTNUFJOnqjtrmCaIlg in bKExsAkyLwWePTNUFJOnqjtrmCaIlc:
    bKExsAkyLwWePTNUFJOnqjtrmCaIlD=bKExsAkyLwWePTNUFJOnqjtrmCaIHB(urllib.parse.parse_qsl(bKExsAkyLwWePTNUFJOnqjtrmCaIlg))
    bKExsAkyLwWePTNUFJOnqjtrmCaIld=bKExsAkyLwWePTNUFJOnqjtrmCaIBz.get('code').strip()
    bKExsAkyLwWePTNUFJOnqjtrmCaIlf=bKExsAkyLwWePTNUFJOnqjtrmCaIlD.get('code').strip()
    if bKExsAkyLwWePTNUFJOnqjtrmCaIpD=='vod' and bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_direct_replay()==bKExsAkyLwWePTNUFJOnqjtrmCaIYd:
     bKExsAkyLwWePTNUFJOnqjtrmCaIld=bKExsAkyLwWePTNUFJOnqjtrmCaIBz.get('videoid').strip()
     bKExsAkyLwWePTNUFJOnqjtrmCaIlf=bKExsAkyLwWePTNUFJOnqjtrmCaIlD.get('videoid').strip()if bKExsAkyLwWePTNUFJOnqjtrmCaIlf!=bKExsAkyLwWePTNUFJOnqjtrmCaIYM else '-'
    if bKExsAkyLwWePTNUFJOnqjtrmCaIld!=bKExsAkyLwWePTNUFJOnqjtrmCaIlf:
     fp.write(bKExsAkyLwWePTNUFJOnqjtrmCaIlg)
     bKExsAkyLwWePTNUFJOnqjtrmCaIlo+=1
     if bKExsAkyLwWePTNUFJOnqjtrmCaIlo>=50:break
   fp.close()
  except:
   bKExsAkyLwWePTNUFJOnqjtrmCaIYM
 def dp_Watch_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIpD =bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('stype')
  bKExsAkyLwWePTNUFJOnqjtrmCaIuV=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_direct_replay()
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpD=='-':
   for bKExsAkyLwWePTNUFJOnqjtrmCaIpR in bKExsAkyLwWePTNUFJOnqjtrmCaIBh:
    bKExsAkyLwWePTNUFJOnqjtrmCaIuz=bKExsAkyLwWePTNUFJOnqjtrmCaIpR.get('title')
    bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':bKExsAkyLwWePTNUFJOnqjtrmCaIpR.get('mode'),'stype':bKExsAkyLwWePTNUFJOnqjtrmCaIpR.get('stype')}
    bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel='',img='',infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIYM,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYd,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
   if bKExsAkyLwWePTNUFJOnqjtrmCaIHX(bKExsAkyLwWePTNUFJOnqjtrmCaIBh)>0:xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle)
  else:
   bKExsAkyLwWePTNUFJOnqjtrmCaIli=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.Load_List_File(bKExsAkyLwWePTNUFJOnqjtrmCaIpD)
   for bKExsAkyLwWePTNUFJOnqjtrmCaISB in bKExsAkyLwWePTNUFJOnqjtrmCaIli:
    bKExsAkyLwWePTNUFJOnqjtrmCaIlu=bKExsAkyLwWePTNUFJOnqjtrmCaIHB(urllib.parse.parse_qsl(bKExsAkyLwWePTNUFJOnqjtrmCaISB))
    bKExsAkyLwWePTNUFJOnqjtrmCaISu =bKExsAkyLwWePTNUFJOnqjtrmCaIlu.get('code').strip()
    bKExsAkyLwWePTNUFJOnqjtrmCaIuz =bKExsAkyLwWePTNUFJOnqjtrmCaIlu.get('title').strip()
    bKExsAkyLwWePTNUFJOnqjtrmCaIpi=bKExsAkyLwWePTNUFJOnqjtrmCaIlu.get('img').strip()
    bKExsAkyLwWePTNUFJOnqjtrmCaIhV =bKExsAkyLwWePTNUFJOnqjtrmCaIlu.get('videoid').strip()
    try:
     bKExsAkyLwWePTNUFJOnqjtrmCaIpi=bKExsAkyLwWePTNUFJOnqjtrmCaIpi.replace('\'','\"')
     bKExsAkyLwWePTNUFJOnqjtrmCaIpi=json.loads(bKExsAkyLwWePTNUFJOnqjtrmCaIpi)
    except:
     bKExsAkyLwWePTNUFJOnqjtrmCaIYM
    bKExsAkyLwWePTNUFJOnqjtrmCaIXG={}
    bKExsAkyLwWePTNUFJOnqjtrmCaIXG['plot']=bKExsAkyLwWePTNUFJOnqjtrmCaIuz
    if bKExsAkyLwWePTNUFJOnqjtrmCaIpD=='vod':
     if bKExsAkyLwWePTNUFJOnqjtrmCaIuV==bKExsAkyLwWePTNUFJOnqjtrmCaIYf or bKExsAkyLwWePTNUFJOnqjtrmCaIhV==bKExsAkyLwWePTNUFJOnqjtrmCaIYM:
      bKExsAkyLwWePTNUFJOnqjtrmCaIXG['mediatype']='tvshow'
      bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'EPISODE','programcode':bKExsAkyLwWePTNUFJOnqjtrmCaISu,'page':'1'}
      bKExsAkyLwWePTNUFJOnqjtrmCaIpX=bKExsAkyLwWePTNUFJOnqjtrmCaIYd
     else:
      bKExsAkyLwWePTNUFJOnqjtrmCaIXG['mediatype']='episode'
      bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'VOD','mediacode':bKExsAkyLwWePTNUFJOnqjtrmCaIhV,'stype':'vod','programcode':bKExsAkyLwWePTNUFJOnqjtrmCaISu,'title':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'thumbnail':bKExsAkyLwWePTNUFJOnqjtrmCaIpi}
      bKExsAkyLwWePTNUFJOnqjtrmCaIpX=bKExsAkyLwWePTNUFJOnqjtrmCaIYf
    else:
     bKExsAkyLwWePTNUFJOnqjtrmCaIXG['mediatype']='movie'
     bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'MOVIE','mediacode':bKExsAkyLwWePTNUFJOnqjtrmCaISu,'stype':'movie','title':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'thumbnail':bKExsAkyLwWePTNUFJOnqjtrmCaIpi}
     bKExsAkyLwWePTNUFJOnqjtrmCaIpX=bKExsAkyLwWePTNUFJOnqjtrmCaIYf
    bKExsAkyLwWePTNUFJOnqjtrmCaIlX={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':bKExsAkyLwWePTNUFJOnqjtrmCaISu,'vType':bKExsAkyLwWePTNUFJOnqjtrmCaIpD,}
    bKExsAkyLwWePTNUFJOnqjtrmCaIlh=urllib.parse.urlencode(bKExsAkyLwWePTNUFJOnqjtrmCaIlX)
    bKExsAkyLwWePTNUFJOnqjtrmCaIXo=[('선택된 시청이력 ( %s ) 삭제'%(bKExsAkyLwWePTNUFJOnqjtrmCaIuz),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(bKExsAkyLwWePTNUFJOnqjtrmCaIlh))]
    bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel='',img=bKExsAkyLwWePTNUFJOnqjtrmCaIpi,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIXG,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIpX,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu,ContextMenu=bKExsAkyLwWePTNUFJOnqjtrmCaIXo)
   bKExsAkyLwWePTNUFJOnqjtrmCaIXG={'plot':'시청목록을 삭제합니다.'}
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':bKExsAkyLwWePTNUFJOnqjtrmCaIpD,}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpB=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel='',img=bKExsAkyLwWePTNUFJOnqjtrmCaIpB,infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIXG,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYf,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu,isLink=bKExsAkyLwWePTNUFJOnqjtrmCaIYd)
   if bKExsAkyLwWePTNUFJOnqjtrmCaIpD=='movie':xbmcplugin.setContent(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,'movies')
   else:xbmcplugin.setContent(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,cacheToDisc=bKExsAkyLwWePTNUFJOnqjtrmCaIYf)
 def Save_Searched_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIhQ):
  try:
   bKExsAkyLwWePTNUFJOnqjtrmCaISp=bKExsAkyLwWePTNUFJOnqjtrmCaIBV
   bKExsAkyLwWePTNUFJOnqjtrmCaIlc=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.Load_List_File('search') 
   bKExsAkyLwWePTNUFJOnqjtrmCaISX={'skey':bKExsAkyLwWePTNUFJOnqjtrmCaIhQ.strip()}
   fp=bKExsAkyLwWePTNUFJOnqjtrmCaIHS(bKExsAkyLwWePTNUFJOnqjtrmCaISp,'w',-1,'utf-8')
   bKExsAkyLwWePTNUFJOnqjtrmCaIlM=urllib.parse.urlencode(bKExsAkyLwWePTNUFJOnqjtrmCaISX)
   bKExsAkyLwWePTNUFJOnqjtrmCaIlM=bKExsAkyLwWePTNUFJOnqjtrmCaIlM+'\n'
   fp.write(bKExsAkyLwWePTNUFJOnqjtrmCaIlM)
   bKExsAkyLwWePTNUFJOnqjtrmCaIlo=0
   for bKExsAkyLwWePTNUFJOnqjtrmCaIlg in bKExsAkyLwWePTNUFJOnqjtrmCaIlc:
    bKExsAkyLwWePTNUFJOnqjtrmCaIlD=bKExsAkyLwWePTNUFJOnqjtrmCaIHB(urllib.parse.parse_qsl(bKExsAkyLwWePTNUFJOnqjtrmCaIlg))
    bKExsAkyLwWePTNUFJOnqjtrmCaIld=bKExsAkyLwWePTNUFJOnqjtrmCaISX.get('skey').strip()
    bKExsAkyLwWePTNUFJOnqjtrmCaIlf=bKExsAkyLwWePTNUFJOnqjtrmCaIlD.get('skey').strip()
    if bKExsAkyLwWePTNUFJOnqjtrmCaIld!=bKExsAkyLwWePTNUFJOnqjtrmCaIlf:
     fp.write(bKExsAkyLwWePTNUFJOnqjtrmCaIlg)
     bKExsAkyLwWePTNUFJOnqjtrmCaIlo+=1
     if bKExsAkyLwWePTNUFJOnqjtrmCaIlo>=50:break
   fp.close()
  except:
   bKExsAkyLwWePTNUFJOnqjtrmCaIYM
 def play_VIDEO(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaISh =bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('mediacode')
  bKExsAkyLwWePTNUFJOnqjtrmCaIpD =bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('stype')
  bKExsAkyLwWePTNUFJOnqjtrmCaISl =bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('pvrmode')
  bKExsAkyLwWePTNUFJOnqjtrmCaISY=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_selQuality(bKExsAkyLwWePTNUFJOnqjtrmCaIpD)
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(bKExsAkyLwWePTNUFJOnqjtrmCaISh,bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaISY),bKExsAkyLwWePTNUFJOnqjtrmCaIpD,bKExsAkyLwWePTNUFJOnqjtrmCaISl))
  bKExsAkyLwWePTNUFJOnqjtrmCaISH=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.GetBroadURL(bKExsAkyLwWePTNUFJOnqjtrmCaISh,bKExsAkyLwWePTNUFJOnqjtrmCaISY,bKExsAkyLwWePTNUFJOnqjtrmCaIpD,bKExsAkyLwWePTNUFJOnqjtrmCaISl,optUHD=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_uhd())
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_log('qt, stype, url : %s - %s - %s'%(bKExsAkyLwWePTNUFJOnqjtrmCaIHh(bKExsAkyLwWePTNUFJOnqjtrmCaISY),bKExsAkyLwWePTNUFJOnqjtrmCaIpD,bKExsAkyLwWePTNUFJOnqjtrmCaISH['streaming_url']))
  if bKExsAkyLwWePTNUFJOnqjtrmCaISH['streaming_url']=='':
   if bKExsAkyLwWePTNUFJOnqjtrmCaISH['error_msg']=='':
    bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_noti(__language__(30908).encode('utf8'))
   else:
    bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_noti(bKExsAkyLwWePTNUFJOnqjtrmCaISH['error_msg'].encode('utf8'))
   return
  bKExsAkyLwWePTNUFJOnqjtrmCaISG='user-agent={}'.format(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.USER_AGENT)
  if bKExsAkyLwWePTNUFJOnqjtrmCaISH['watermark'] !='':
   bKExsAkyLwWePTNUFJOnqjtrmCaISG='{}&x-tving-param1={}&x-tving-param2={}'.format(bKExsAkyLwWePTNUFJOnqjtrmCaISG,bKExsAkyLwWePTNUFJOnqjtrmCaISH['watermarkKey'],bKExsAkyLwWePTNUFJOnqjtrmCaISH['watermark'])
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_log('streaming_url = {}'.format(bKExsAkyLwWePTNUFJOnqjtrmCaISH['streaming_url']))
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_log('drm_license   = {}'.format(bKExsAkyLwWePTNUFJOnqjtrmCaISH['drm_license']))
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_log('watermark     = {}'.format(bKExsAkyLwWePTNUFJOnqjtrmCaISH['watermark']))
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_log('watermarkKey  = {}'.format(bKExsAkyLwWePTNUFJOnqjtrmCaISH['watermarkKey']))
  bKExsAkyLwWePTNUFJOnqjtrmCaISv =bKExsAkyLwWePTNUFJOnqjtrmCaIYf
  bKExsAkyLwWePTNUFJOnqjtrmCaISV =bKExsAkyLwWePTNUFJOnqjtrmCaISH['streaming_url'].find('Policy=')
  if bKExsAkyLwWePTNUFJOnqjtrmCaISV!=-1:
   bKExsAkyLwWePTNUFJOnqjtrmCaISc =bKExsAkyLwWePTNUFJOnqjtrmCaISH['streaming_url'].split('?')[0]
   bKExsAkyLwWePTNUFJOnqjtrmCaISg=bKExsAkyLwWePTNUFJOnqjtrmCaIHB(urllib.parse.parse_qsl(urllib.parse.urlsplit(bKExsAkyLwWePTNUFJOnqjtrmCaISH['streaming_url']).query))
   bKExsAkyLwWePTNUFJOnqjtrmCaISD='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(bKExsAkyLwWePTNUFJOnqjtrmCaISg['Policy'],bKExsAkyLwWePTNUFJOnqjtrmCaISg['Signature'],bKExsAkyLwWePTNUFJOnqjtrmCaISg['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in bKExsAkyLwWePTNUFJOnqjtrmCaISc:
    bKExsAkyLwWePTNUFJOnqjtrmCaISv=bKExsAkyLwWePTNUFJOnqjtrmCaIYd
    bKExsAkyLwWePTNUFJOnqjtrmCaISz =bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    bKExsAkyLwWePTNUFJOnqjtrmCaISR=bKExsAkyLwWePTNUFJOnqjtrmCaISz.strftime('%Y-%m-%d-%H:%M:%S')
    if bKExsAkyLwWePTNUFJOnqjtrmCaIYo(bKExsAkyLwWePTNUFJOnqjtrmCaISR.replace('-','').replace(':',''))<bKExsAkyLwWePTNUFJOnqjtrmCaIYo(bKExsAkyLwWePTNUFJOnqjtrmCaISg['end'].replace('-','').replace(':','')):
     bKExsAkyLwWePTNUFJOnqjtrmCaISg['end']=bKExsAkyLwWePTNUFJOnqjtrmCaISR
     bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_noti(__language__(30915).encode('utf8'))
    bKExsAkyLwWePTNUFJOnqjtrmCaISc ='%s?%s'%(bKExsAkyLwWePTNUFJOnqjtrmCaISc,urllib.parse.urlencode(bKExsAkyLwWePTNUFJOnqjtrmCaISg,doseq=bKExsAkyLwWePTNUFJOnqjtrmCaIYd))
    bKExsAkyLwWePTNUFJOnqjtrmCaISQ='{}|{}&Cookie={}'.format(bKExsAkyLwWePTNUFJOnqjtrmCaISc,bKExsAkyLwWePTNUFJOnqjtrmCaISG,bKExsAkyLwWePTNUFJOnqjtrmCaISD)
   else:
    bKExsAkyLwWePTNUFJOnqjtrmCaISQ='{}|{}&Cookie={}'.format(bKExsAkyLwWePTNUFJOnqjtrmCaISH['streaming_url'],bKExsAkyLwWePTNUFJOnqjtrmCaISG,bKExsAkyLwWePTNUFJOnqjtrmCaISD)
  else:
   bKExsAkyLwWePTNUFJOnqjtrmCaISQ=bKExsAkyLwWePTNUFJOnqjtrmCaISH['streaming_url']+'|'+bKExsAkyLwWePTNUFJOnqjtrmCaISG
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_log('if tmp_pos == -1')
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_log(bKExsAkyLwWePTNUFJOnqjtrmCaISQ)
  bKExsAkyLwWePTNUFJOnqjtrmCaIuh,bKExsAkyLwWePTNUFJOnqjtrmCaIul=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_proxyport()
  bKExsAkyLwWePTNUFJOnqjtrmCaIuX=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_playback()
  bKExsAkyLwWePTNUFJOnqjtrmCaISM=urllib.parse.urlparse(bKExsAkyLwWePTNUFJOnqjtrmCaISH['streaming_url'])
  bKExsAkyLwWePTNUFJOnqjtrmCaISM=bKExsAkyLwWePTNUFJOnqjtrmCaISM.path.strip('/').split('/')
  bKExsAkyLwWePTNUFJOnqjtrmCaISM=bKExsAkyLwWePTNUFJOnqjtrmCaISM[bKExsAkyLwWePTNUFJOnqjtrmCaIHX(bKExsAkyLwWePTNUFJOnqjtrmCaISM)-1] 
  if bKExsAkyLwWePTNUFJOnqjtrmCaIuh and bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('mode')in['VOD','MOVIE']and bKExsAkyLwWePTNUFJOnqjtrmCaISH['drm_license']!='':
   if bKExsAkyLwWePTNUFJOnqjtrmCaISM.split('.')[1]=='mpd':
    bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Tving_Parse_mpd(bKExsAkyLwWePTNUFJOnqjtrmCaISH['streaming_url'])
   else:
    bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Tving_Parse_m3u8(bKExsAkyLwWePTNUFJOnqjtrmCaISH['streaming_url'])
   bKExsAkyLwWePTNUFJOnqjtrmCaISo={'addon':'tvingm','playOption':bKExsAkyLwWePTNUFJOnqjtrmCaIuX,}
   bKExsAkyLwWePTNUFJOnqjtrmCaISo=json.dumps(bKExsAkyLwWePTNUFJOnqjtrmCaISo,separators=(',',':'))
   bKExsAkyLwWePTNUFJOnqjtrmCaISo=base64.standard_b64encode(bKExsAkyLwWePTNUFJOnqjtrmCaISo.encode()).decode('utf-8')
   bKExsAkyLwWePTNUFJOnqjtrmCaISQ ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(bKExsAkyLwWePTNUFJOnqjtrmCaIul,bKExsAkyLwWePTNUFJOnqjtrmCaISQ,bKExsAkyLwWePTNUFJOnqjtrmCaISo)
   bKExsAkyLwWePTNUFJOnqjtrmCaISG='{}&proxy-mini={}'.format(bKExsAkyLwWePTNUFJOnqjtrmCaISG,bKExsAkyLwWePTNUFJOnqjtrmCaISo)
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_log(bKExsAkyLwWePTNUFJOnqjtrmCaISQ)
  bKExsAkyLwWePTNUFJOnqjtrmCaISd=xbmcgui.ListItem(path=bKExsAkyLwWePTNUFJOnqjtrmCaISQ)
  if bKExsAkyLwWePTNUFJOnqjtrmCaISH['drm_license']!='':
   bKExsAkyLwWePTNUFJOnqjtrmCaISf=bKExsAkyLwWePTNUFJOnqjtrmCaISH['drm_license']
   bKExsAkyLwWePTNUFJOnqjtrmCaISi ='https://cj.drmkeyserver.com/widevine_license'
   bKExsAkyLwWePTNUFJOnqjtrmCaIYB ='mpd'
   bKExsAkyLwWePTNUFJOnqjtrmCaIYu ='com.widevine.alpha'
   bKExsAkyLwWePTNUFJOnqjtrmCaIYp =inputstreamhelper.Helper(bKExsAkyLwWePTNUFJOnqjtrmCaIYB,drm='widevine')
   if bKExsAkyLwWePTNUFJOnqjtrmCaIYp.check_inputstream():
    bKExsAkyLwWePTNUFJOnqjtrmCaIYX={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.USER_AGENT,'AcquireLicenseAssertion':bKExsAkyLwWePTNUFJOnqjtrmCaISf,'Host':'cj.drmkeyserver.com',}
    bKExsAkyLwWePTNUFJOnqjtrmCaIYh=bKExsAkyLwWePTNUFJOnqjtrmCaISi+'|'+urllib.parse.urlencode(bKExsAkyLwWePTNUFJOnqjtrmCaIYX)+'|R{SSM}|'
    bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('inputstream',bKExsAkyLwWePTNUFJOnqjtrmCaIYp.inputstream_addon)
    bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('inputstream.adaptive.manifest_type',bKExsAkyLwWePTNUFJOnqjtrmCaIYB)
    bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('inputstream.adaptive.license_type',bKExsAkyLwWePTNUFJOnqjtrmCaIYu)
    bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('inputstream.adaptive.license_key',bKExsAkyLwWePTNUFJOnqjtrmCaIYh)
    bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('inputstream.adaptive.stream_headers',bKExsAkyLwWePTNUFJOnqjtrmCaISG)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('mode')in['VOD','MOVIE']:
   bKExsAkyLwWePTNUFJOnqjtrmCaISd.setContentLookup(bKExsAkyLwWePTNUFJOnqjtrmCaIYf)
   bKExsAkyLwWePTNUFJOnqjtrmCaISd.setMimeType('application/x-mpegURL')
   bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('inputstream','inputstream.adaptive')
   bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('inputstream.adaptive.manifest_type','hls')
   bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('inputstream.adaptive.stream_headers',bKExsAkyLwWePTNUFJOnqjtrmCaISG)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaISv==bKExsAkyLwWePTNUFJOnqjtrmCaIYd:
   bKExsAkyLwWePTNUFJOnqjtrmCaISd.setContentLookup(bKExsAkyLwWePTNUFJOnqjtrmCaIYf)
   bKExsAkyLwWePTNUFJOnqjtrmCaISd.setMimeType('application/x-mpegURL')
   bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('inputstream','inputstream.ffmpegdirect')
   bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('ResumeTime','0')
   bKExsAkyLwWePTNUFJOnqjtrmCaISd.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,bKExsAkyLwWePTNUFJOnqjtrmCaIYd,bKExsAkyLwWePTNUFJOnqjtrmCaISd)
  try:
   if bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('mode')in['VOD','MOVIE']and bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('title'):
    bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'code':bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('programcode')if bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('mode')=='VOD' else bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('mediacode'),'img':bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('thumbnail'),'title':bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('title'),'videoid':bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('mediacode')}
    bKExsAkyLwWePTNUFJOnqjtrmCaIBc.Save_Watched_List(bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('stype'),bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  except:
   bKExsAkyLwWePTNUFJOnqjtrmCaIYM
 def logout(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  bKExsAkyLwWePTNUFJOnqjtrmCaIBQ=xbmcgui.Dialog()
  bKExsAkyLwWePTNUFJOnqjtrmCaIpV=bKExsAkyLwWePTNUFJOnqjtrmCaIBQ.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if bKExsAkyLwWePTNUFJOnqjtrmCaIpV==bKExsAkyLwWePTNUFJOnqjtrmCaIYf:sys.exit()
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Init_TV_Total()
  if os.path.isfile(bKExsAkyLwWePTNUFJOnqjtrmCaIBv):os.remove(bKExsAkyLwWePTNUFJOnqjtrmCaIBv)
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  bKExsAkyLwWePTNUFJOnqjtrmCaIYl =bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Get_Now_Datetime()
  bKExsAkyLwWePTNUFJOnqjtrmCaIYS=bKExsAkyLwWePTNUFJOnqjtrmCaIYl+datetime.timedelta(days=bKExsAkyLwWePTNUFJOnqjtrmCaIYo(__addon__.getSetting('cache_ttl')))
  (bKExsAkyLwWePTNUFJOnqjtrmCaIpY,bKExsAkyLwWePTNUFJOnqjtrmCaIpH,bKExsAkyLwWePTNUFJOnqjtrmCaIpG,bKExsAkyLwWePTNUFJOnqjtrmCaIpv)=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_account()
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Save_session_acount(bKExsAkyLwWePTNUFJOnqjtrmCaIpY,bKExsAkyLwWePTNUFJOnqjtrmCaIpH,bKExsAkyLwWePTNUFJOnqjtrmCaIpG,bKExsAkyLwWePTNUFJOnqjtrmCaIpv)
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.TV['account']['token_limit']=bKExsAkyLwWePTNUFJOnqjtrmCaIYS.strftime('%Y%m%d')
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.JsonFile_Save(bKExsAkyLwWePTNUFJOnqjtrmCaIBv,bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.TV)
 def cookiefile_check(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.TV=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.JsonFile_Load(bKExsAkyLwWePTNUFJOnqjtrmCaIBv)
  if 'account' not in bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.TV:
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Init_TV_Total()
   return bKExsAkyLwWePTNUFJOnqjtrmCaIYf
  (bKExsAkyLwWePTNUFJOnqjtrmCaIYH,bKExsAkyLwWePTNUFJOnqjtrmCaIYG,bKExsAkyLwWePTNUFJOnqjtrmCaIYv,bKExsAkyLwWePTNUFJOnqjtrmCaIYV)=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.get_settings_account()
  (bKExsAkyLwWePTNUFJOnqjtrmCaIYc,bKExsAkyLwWePTNUFJOnqjtrmCaIYg,bKExsAkyLwWePTNUFJOnqjtrmCaIYD,bKExsAkyLwWePTNUFJOnqjtrmCaIYz)=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Load_session_acount()
  if bKExsAkyLwWePTNUFJOnqjtrmCaIYH!=bKExsAkyLwWePTNUFJOnqjtrmCaIYc or bKExsAkyLwWePTNUFJOnqjtrmCaIYG!=bKExsAkyLwWePTNUFJOnqjtrmCaIYg or bKExsAkyLwWePTNUFJOnqjtrmCaIYv!=bKExsAkyLwWePTNUFJOnqjtrmCaIYD or bKExsAkyLwWePTNUFJOnqjtrmCaIYV!=bKExsAkyLwWePTNUFJOnqjtrmCaIYz:
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Init_TV_Total()
   return bKExsAkyLwWePTNUFJOnqjtrmCaIYf
  if bKExsAkyLwWePTNUFJOnqjtrmCaIYo(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>bKExsAkyLwWePTNUFJOnqjtrmCaIYo(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.TV['account']['token_limit']):
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.Init_TV_Total()
   return bKExsAkyLwWePTNUFJOnqjtrmCaIYf
  return bKExsAkyLwWePTNUFJOnqjtrmCaIYd
 def dp_Global_Search(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIhM=bKExsAkyLwWePTNUFJOnqjtrmCaIpQ.get('mode')
  if bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='TOTAL_SEARCH':
   bKExsAkyLwWePTNUFJOnqjtrmCaIYR='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   bKExsAkyLwWePTNUFJOnqjtrmCaIYR='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(bKExsAkyLwWePTNUFJOnqjtrmCaIYR)
 def dp_Bookmark_Menu(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIYR='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(bKExsAkyLwWePTNUFJOnqjtrmCaIYR)
 def dp_EuroLive_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc,bKExsAkyLwWePTNUFJOnqjtrmCaIpQ):
  bKExsAkyLwWePTNUFJOnqjtrmCaIpo=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.GetEuroChannelList()
  for bKExsAkyLwWePTNUFJOnqjtrmCaIpf in bKExsAkyLwWePTNUFJOnqjtrmCaIpo:
   bKExsAkyLwWePTNUFJOnqjtrmCaIXz =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('channel')
   bKExsAkyLwWePTNUFJOnqjtrmCaIuz =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('title')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXv =bKExsAkyLwWePTNUFJOnqjtrmCaIpf.get('subtitle')
   bKExsAkyLwWePTNUFJOnqjtrmCaIXG={'mediatype':'episode','title':bKExsAkyLwWePTNUFJOnqjtrmCaIuz,'plot':'%s\n%s'%(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,bKExsAkyLwWePTNUFJOnqjtrmCaIXv)}
   bKExsAkyLwWePTNUFJOnqjtrmCaIpu={'mode':'LIVE','mediacode':bKExsAkyLwWePTNUFJOnqjtrmCaIXz,'stype':'onair',}
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.add_dir(bKExsAkyLwWePTNUFJOnqjtrmCaIuz,sublabel=bKExsAkyLwWePTNUFJOnqjtrmCaIXv,img='',infoLabels=bKExsAkyLwWePTNUFJOnqjtrmCaIXG,isFolder=bKExsAkyLwWePTNUFJOnqjtrmCaIYf,params=bKExsAkyLwWePTNUFJOnqjtrmCaIpu)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIHX(bKExsAkyLwWePTNUFJOnqjtrmCaIpo)>0:xbmcplugin.endOfDirectory(bKExsAkyLwWePTNUFJOnqjtrmCaIBc._addon_handle,cacheToDisc=bKExsAkyLwWePTNUFJOnqjtrmCaIYf)
 def tving_main(bKExsAkyLwWePTNUFJOnqjtrmCaIBc):
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.TvingObj.KodiVersion=bKExsAkyLwWePTNUFJOnqjtrmCaIYo(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  bKExsAkyLwWePTNUFJOnqjtrmCaIhM=bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params.get('mode',bKExsAkyLwWePTNUFJOnqjtrmCaIYM)
  if bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='LOGOUT':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.logout()
   return
  bKExsAkyLwWePTNUFJOnqjtrmCaIBc.login_main()
  if bKExsAkyLwWePTNUFJOnqjtrmCaIhM is bKExsAkyLwWePTNUFJOnqjtrmCaIYM:
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_Main_List()
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_Title_Group(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM in['GLOBAL_GROUP']:
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_SubTitle_Group(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='CHANNEL':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_LiveChannel_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM in['LIVE','VOD','MOVIE']:
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.play_VIDEO(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='PROGRAM':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_Program_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='4K_PROGRAM':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_4K_Program_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='ORI_PROGRAM':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_Ori_Program_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='EPISODE':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_Episode_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='MOVIE_SUB':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_Movie_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='4K_MOVIE':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_4K_Movie_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='SEARCH_GROUP':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_Search_Group(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM in['SEARCH','LOCAL_SEARCH']:
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_Search_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='WATCH':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_Watch_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_History_Remove(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='ORDER_BY':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_setEpOrderby(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='SET_BOOKMARK':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_Set_Bookmark(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM in['TOTAL_SEARCH','TOTAL_HISTORY']:
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_Global_Search(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='SEARCH_HISTORY':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_Search_History(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='MENU_BOOKMARK':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_Bookmark_Menu(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  elif bKExsAkyLwWePTNUFJOnqjtrmCaIhM=='EURO_GROUP':
   bKExsAkyLwWePTNUFJOnqjtrmCaIBc.dp_EuroLive_List(bKExsAkyLwWePTNUFJOnqjtrmCaIBc.main_params)
  else:
   bKExsAkyLwWePTNUFJOnqjtrmCaIYM
# Created by pyminifier (https://github.com/liftoff/pyminifier)
