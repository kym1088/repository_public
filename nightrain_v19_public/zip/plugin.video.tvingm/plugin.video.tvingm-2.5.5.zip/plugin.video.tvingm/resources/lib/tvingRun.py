__author__="NightRain"
trCwivRxKUGdkbeMoPVNJhgIqBHTly=object
trCwivRxKUGdkbeMoPVNJhgIqBHTlQ=None
trCwivRxKUGdkbeMoPVNJhgIqBHTla=int
trCwivRxKUGdkbeMoPVNJhgIqBHTlW=True
trCwivRxKUGdkbeMoPVNJhgIqBHTlf=False
trCwivRxKUGdkbeMoPVNJhgIqBHTlS=type
trCwivRxKUGdkbeMoPVNJhgIqBHTYj=dict
trCwivRxKUGdkbeMoPVNJhgIqBHTYO=getattr
trCwivRxKUGdkbeMoPVNJhgIqBHTYX=list
trCwivRxKUGdkbeMoPVNJhgIqBHTYL=len
trCwivRxKUGdkbeMoPVNJhgIqBHTYE=str
trCwivRxKUGdkbeMoPVNJhgIqBHTYA=range
trCwivRxKUGdkbeMoPVNJhgIqBHTYm=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
trCwivRxKUGdkbeMoPVNJhgIqBHTjX=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
trCwivRxKUGdkbeMoPVNJhgIqBHTjL=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
trCwivRxKUGdkbeMoPVNJhgIqBHTjE=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
trCwivRxKUGdkbeMoPVNJhgIqBHTjA=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
trCwivRxKUGdkbeMoPVNJhgIqBHTjm=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
trCwivRxKUGdkbeMoPVNJhgIqBHTjl=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
trCwivRxKUGdkbeMoPVNJhgIqBHTjY=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
trCwivRxKUGdkbeMoPVNJhgIqBHTjs={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
trCwivRxKUGdkbeMoPVNJhgIqBHTju =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
trCwivRxKUGdkbeMoPVNJhgIqBHTjz=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class trCwivRxKUGdkbeMoPVNJhgIqBHTjO(trCwivRxKUGdkbeMoPVNJhgIqBHTly):
 def __init__(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTjn,trCwivRxKUGdkbeMoPVNJhgIqBHTjc,trCwivRxKUGdkbeMoPVNJhgIqBHTjp):
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_url =trCwivRxKUGdkbeMoPVNJhgIqBHTjn
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle=trCwivRxKUGdkbeMoPVNJhgIqBHTjc
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params =trCwivRxKUGdkbeMoPVNJhgIqBHTjp
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj =FtHzUBemVuawEiqGQDoWNJfcsSCTIR() 
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,sting):
  try:
   trCwivRxKUGdkbeMoPVNJhgIqBHTjy=xbmcgui.Dialog()
   trCwivRxKUGdkbeMoPVNJhgIqBHTjy.notification(__addonname__,sting)
  except:
   trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
 def addon_log(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,string):
  try:
   trCwivRxKUGdkbeMoPVNJhgIqBHTjQ=string.encode('utf-8','ignore')
  except:
   trCwivRxKUGdkbeMoPVNJhgIqBHTjQ='addonException: addon_log'
  trCwivRxKUGdkbeMoPVNJhgIqBHTja=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,trCwivRxKUGdkbeMoPVNJhgIqBHTjQ),level=trCwivRxKUGdkbeMoPVNJhgIqBHTja)
 def get_keyboard_input(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTOp):
  trCwivRxKUGdkbeMoPVNJhgIqBHTjW=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
  kb=xbmc.Keyboard()
  kb.setHeading(trCwivRxKUGdkbeMoPVNJhgIqBHTOp)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   trCwivRxKUGdkbeMoPVNJhgIqBHTjW=kb.getText()
  return trCwivRxKUGdkbeMoPVNJhgIqBHTjW
 def get_settings_account(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  trCwivRxKUGdkbeMoPVNJhgIqBHTjf =__addon__.getSetting('id')
  trCwivRxKUGdkbeMoPVNJhgIqBHTjS =__addon__.getSetting('pw')
  trCwivRxKUGdkbeMoPVNJhgIqBHTOj =__addon__.getSetting('login_type')
  trCwivRxKUGdkbeMoPVNJhgIqBHTOX=trCwivRxKUGdkbeMoPVNJhgIqBHTla(__addon__.getSetting('selected_profile'))
  return(trCwivRxKUGdkbeMoPVNJhgIqBHTjf,trCwivRxKUGdkbeMoPVNJhgIqBHTjS,trCwivRxKUGdkbeMoPVNJhgIqBHTOj,trCwivRxKUGdkbeMoPVNJhgIqBHTOX)
 def get_settings_uhd(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  return trCwivRxKUGdkbeMoPVNJhgIqBHTlW if __addon__.getSetting('active_uhd')=='true' else trCwivRxKUGdkbeMoPVNJhgIqBHTlf
 def get_settings_playback(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  trCwivRxKUGdkbeMoPVNJhgIqBHTOL={'active_uhd':trCwivRxKUGdkbeMoPVNJhgIqBHTlW if __addon__.getSetting('active_uhd')=='true' else trCwivRxKUGdkbeMoPVNJhgIqBHTlf,'streamFilename':trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.TV_STREAM_FILENAME,}
  return trCwivRxKUGdkbeMoPVNJhgIqBHTOL
 def get_settings_proxyport(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  trCwivRxKUGdkbeMoPVNJhgIqBHTOE =trCwivRxKUGdkbeMoPVNJhgIqBHTlW if __addon__.getSetting('proxyYn')=='true' else trCwivRxKUGdkbeMoPVNJhgIqBHTlf
  trCwivRxKUGdkbeMoPVNJhgIqBHTOA=trCwivRxKUGdkbeMoPVNJhgIqBHTla(__addon__.getSetting('proxyPort'))
  return trCwivRxKUGdkbeMoPVNJhgIqBHTOE,trCwivRxKUGdkbeMoPVNJhgIqBHTOA
 def get_settings_totalsearch(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  trCwivRxKUGdkbeMoPVNJhgIqBHTOm =trCwivRxKUGdkbeMoPVNJhgIqBHTlW if __addon__.getSetting('local_search')=='true' else trCwivRxKUGdkbeMoPVNJhgIqBHTlf
  trCwivRxKUGdkbeMoPVNJhgIqBHTOl=trCwivRxKUGdkbeMoPVNJhgIqBHTlW if __addon__.getSetting('local_history')=='true' else trCwivRxKUGdkbeMoPVNJhgIqBHTlf
  trCwivRxKUGdkbeMoPVNJhgIqBHTOY =trCwivRxKUGdkbeMoPVNJhgIqBHTlW if __addon__.getSetting('total_search')=='true' else trCwivRxKUGdkbeMoPVNJhgIqBHTlf
  trCwivRxKUGdkbeMoPVNJhgIqBHTOs=trCwivRxKUGdkbeMoPVNJhgIqBHTlW if __addon__.getSetting('total_history')=='true' else trCwivRxKUGdkbeMoPVNJhgIqBHTlf
  trCwivRxKUGdkbeMoPVNJhgIqBHTOu=trCwivRxKUGdkbeMoPVNJhgIqBHTlW if __addon__.getSetting('menu_bookmark')=='true' else trCwivRxKUGdkbeMoPVNJhgIqBHTlf
  return(trCwivRxKUGdkbeMoPVNJhgIqBHTOm,trCwivRxKUGdkbeMoPVNJhgIqBHTOl,trCwivRxKUGdkbeMoPVNJhgIqBHTOY,trCwivRxKUGdkbeMoPVNJhgIqBHTOs,trCwivRxKUGdkbeMoPVNJhgIqBHTOu)
 def get_settings_makebookmark(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  return trCwivRxKUGdkbeMoPVNJhgIqBHTlW if __addon__.getSetting('make_bookmark')=='true' else trCwivRxKUGdkbeMoPVNJhgIqBHTlf
 def get_settings_direct_replay(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  trCwivRxKUGdkbeMoPVNJhgIqBHTOz=trCwivRxKUGdkbeMoPVNJhgIqBHTla(__addon__.getSetting('direct_replay'))
  if trCwivRxKUGdkbeMoPVNJhgIqBHTOz==0:
   return trCwivRxKUGdkbeMoPVNJhgIqBHTlf
  else:
   return trCwivRxKUGdkbeMoPVNJhgIqBHTlW
 def set_winEpisodeOrderby(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTOn):
  __addon__.setSetting('tving_orderby',trCwivRxKUGdkbeMoPVNJhgIqBHTOn)
  trCwivRxKUGdkbeMoPVNJhgIqBHTOF=xbmcgui.Window(10000)
  trCwivRxKUGdkbeMoPVNJhgIqBHTOF.setProperty('TVING_M_ORDERBY',trCwivRxKUGdkbeMoPVNJhgIqBHTOn)
 def get_winEpisodeOrderby(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  trCwivRxKUGdkbeMoPVNJhgIqBHTOn=__addon__.getSetting('tving_orderby')
  if trCwivRxKUGdkbeMoPVNJhgIqBHTOn in['',trCwivRxKUGdkbeMoPVNJhgIqBHTlQ]:trCwivRxKUGdkbeMoPVNJhgIqBHTOn='desc'
  return trCwivRxKUGdkbeMoPVNJhgIqBHTOn
 def add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,label,sublabel='',img='',infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params='',isLink=trCwivRxKUGdkbeMoPVNJhgIqBHTlf,ContextMenu=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ):
  trCwivRxKUGdkbeMoPVNJhgIqBHTOc='%s?%s'%(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_url,urllib.parse.urlencode(params))
  if sublabel:trCwivRxKUGdkbeMoPVNJhgIqBHTOp='%s < %s >'%(label,sublabel)
  else: trCwivRxKUGdkbeMoPVNJhgIqBHTOp=label
  if not img:img='DefaultFolder.png'
  trCwivRxKUGdkbeMoPVNJhgIqBHTOD=xbmcgui.ListItem(trCwivRxKUGdkbeMoPVNJhgIqBHTOp)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTlS(img)==trCwivRxKUGdkbeMoPVNJhgIqBHTYj:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOD.setArt(img)
  else:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOD.setArt({'thumb':img,'poster':img})
  if trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.KodiVersion>=20:
   if infoLabels:trCwivRxKUGdkbeMoPVNJhgIqBHTjF.Set_InfoTag(trCwivRxKUGdkbeMoPVNJhgIqBHTOD.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:trCwivRxKUGdkbeMoPVNJhgIqBHTOD.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOD.setProperty('IsPlayable','true')
  if ContextMenu:trCwivRxKUGdkbeMoPVNJhgIqBHTOD.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,trCwivRxKUGdkbeMoPVNJhgIqBHTOc,trCwivRxKUGdkbeMoPVNJhgIqBHTOD,isFolder)
 def get_selQuality(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,etype):
  try:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOy='selected_quality'
   trCwivRxKUGdkbeMoPVNJhgIqBHTOQ=[1080,720,480,360]
   trCwivRxKUGdkbeMoPVNJhgIqBHTOa=trCwivRxKUGdkbeMoPVNJhgIqBHTla(__addon__.getSetting(trCwivRxKUGdkbeMoPVNJhgIqBHTOy))
   return trCwivRxKUGdkbeMoPVNJhgIqBHTOQ[trCwivRxKUGdkbeMoPVNJhgIqBHTOa]
  except:
   trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
  return 720 
 def Set_InfoTag(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,video_InfoTag:xbmc.InfoTagVideo,trCwivRxKUGdkbeMoPVNJhgIqBHTXA):
  for trCwivRxKUGdkbeMoPVNJhgIqBHTOW,value in trCwivRxKUGdkbeMoPVNJhgIqBHTXA.items():
   if trCwivRxKUGdkbeMoPVNJhgIqBHTjs[trCwivRxKUGdkbeMoPVNJhgIqBHTOW]['type']=='string':
    trCwivRxKUGdkbeMoPVNJhgIqBHTYO(video_InfoTag,trCwivRxKUGdkbeMoPVNJhgIqBHTjs[trCwivRxKUGdkbeMoPVNJhgIqBHTOW]['func'])(value)
   elif trCwivRxKUGdkbeMoPVNJhgIqBHTjs[trCwivRxKUGdkbeMoPVNJhgIqBHTOW]['type']=='int':
    if trCwivRxKUGdkbeMoPVNJhgIqBHTlS(value)==trCwivRxKUGdkbeMoPVNJhgIqBHTla:
     trCwivRxKUGdkbeMoPVNJhgIqBHTOf=trCwivRxKUGdkbeMoPVNJhgIqBHTla(value)
    else:
     trCwivRxKUGdkbeMoPVNJhgIqBHTOf=0
    trCwivRxKUGdkbeMoPVNJhgIqBHTYO(video_InfoTag,trCwivRxKUGdkbeMoPVNJhgIqBHTjs[trCwivRxKUGdkbeMoPVNJhgIqBHTOW]['func'])(trCwivRxKUGdkbeMoPVNJhgIqBHTOf)
   elif trCwivRxKUGdkbeMoPVNJhgIqBHTjs[trCwivRxKUGdkbeMoPVNJhgIqBHTOW]['type']=='actor':
    if value!=[]:
     trCwivRxKUGdkbeMoPVNJhgIqBHTYO(video_InfoTag,trCwivRxKUGdkbeMoPVNJhgIqBHTjs[trCwivRxKUGdkbeMoPVNJhgIqBHTOW]['func'])([xbmc.Actor(name)for name in value])
   elif trCwivRxKUGdkbeMoPVNJhgIqBHTjs[trCwivRxKUGdkbeMoPVNJhgIqBHTOW]['type']=='list':
    if trCwivRxKUGdkbeMoPVNJhgIqBHTlS(value)==trCwivRxKUGdkbeMoPVNJhgIqBHTYX:
     trCwivRxKUGdkbeMoPVNJhgIqBHTYO(video_InfoTag,trCwivRxKUGdkbeMoPVNJhgIqBHTjs[trCwivRxKUGdkbeMoPVNJhgIqBHTOW]['func'])(value)
    else:
     trCwivRxKUGdkbeMoPVNJhgIqBHTYO(video_InfoTag,trCwivRxKUGdkbeMoPVNJhgIqBHTjs[trCwivRxKUGdkbeMoPVNJhgIqBHTOW]['func'])([value])
 def dp_Main_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  (trCwivRxKUGdkbeMoPVNJhgIqBHTOm,trCwivRxKUGdkbeMoPVNJhgIqBHTOl,trCwivRxKUGdkbeMoPVNJhgIqBHTOY,trCwivRxKUGdkbeMoPVNJhgIqBHTOs,trCwivRxKUGdkbeMoPVNJhgIqBHTOu)=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_totalsearch()
  for trCwivRxKUGdkbeMoPVNJhgIqBHTOS in trCwivRxKUGdkbeMoPVNJhgIqBHTjX:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp=trCwivRxKUGdkbeMoPVNJhgIqBHTOS.get('title')
   trCwivRxKUGdkbeMoPVNJhgIqBHTXj=''
   if trCwivRxKUGdkbeMoPVNJhgIqBHTOS.get('mode')=='SEARCH_GROUP' and trCwivRxKUGdkbeMoPVNJhgIqBHTOm ==trCwivRxKUGdkbeMoPVNJhgIqBHTlf:continue
   elif trCwivRxKUGdkbeMoPVNJhgIqBHTOS.get('mode')=='SEARCH_HISTORY' and trCwivRxKUGdkbeMoPVNJhgIqBHTOl==trCwivRxKUGdkbeMoPVNJhgIqBHTlf:continue
   elif trCwivRxKUGdkbeMoPVNJhgIqBHTOS.get('mode')=='TOTAL_SEARCH' and trCwivRxKUGdkbeMoPVNJhgIqBHTOY ==trCwivRxKUGdkbeMoPVNJhgIqBHTlf:continue
   elif trCwivRxKUGdkbeMoPVNJhgIqBHTOS.get('mode')=='TOTAL_HISTORY' and trCwivRxKUGdkbeMoPVNJhgIqBHTOs==trCwivRxKUGdkbeMoPVNJhgIqBHTlf:continue
   elif trCwivRxKUGdkbeMoPVNJhgIqBHTOS.get('mode')=='MENU_BOOKMARK' and trCwivRxKUGdkbeMoPVNJhgIqBHTOu==trCwivRxKUGdkbeMoPVNJhgIqBHTlf:continue
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':trCwivRxKUGdkbeMoPVNJhgIqBHTOS.get('mode'),'stype':trCwivRxKUGdkbeMoPVNJhgIqBHTOS.get('stype'),'orderby':trCwivRxKUGdkbeMoPVNJhgIqBHTOS.get('orderby'),'ordernm':trCwivRxKUGdkbeMoPVNJhgIqBHTOS.get('ordernm'),'page':'1'}
   if trCwivRxKUGdkbeMoPVNJhgIqBHTOS.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    trCwivRxKUGdkbeMoPVNJhgIqBHTXL=trCwivRxKUGdkbeMoPVNJhgIqBHTlf
    trCwivRxKUGdkbeMoPVNJhgIqBHTXE =trCwivRxKUGdkbeMoPVNJhgIqBHTlW
   else:
    trCwivRxKUGdkbeMoPVNJhgIqBHTXL=trCwivRxKUGdkbeMoPVNJhgIqBHTlW
    trCwivRxKUGdkbeMoPVNJhgIqBHTXE =trCwivRxKUGdkbeMoPVNJhgIqBHTlf
   trCwivRxKUGdkbeMoPVNJhgIqBHTXA={'title':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'plot':trCwivRxKUGdkbeMoPVNJhgIqBHTOp}
   if trCwivRxKUGdkbeMoPVNJhgIqBHTOS.get('mode')=='XXX':trCwivRxKUGdkbeMoPVNJhgIqBHTXA=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
   if 'icon' in trCwivRxKUGdkbeMoPVNJhgIqBHTOS:trCwivRxKUGdkbeMoPVNJhgIqBHTXj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',trCwivRxKUGdkbeMoPVNJhgIqBHTOS.get('icon')) 
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel='',img=trCwivRxKUGdkbeMoPVNJhgIqBHTXj,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTXA,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTXL,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO,isLink=trCwivRxKUGdkbeMoPVNJhgIqBHTXE)
  xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle)
 def login_main(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  (trCwivRxKUGdkbeMoPVNJhgIqBHTXl,trCwivRxKUGdkbeMoPVNJhgIqBHTXY,trCwivRxKUGdkbeMoPVNJhgIqBHTXs,trCwivRxKUGdkbeMoPVNJhgIqBHTXu)=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_account()
  if not(trCwivRxKUGdkbeMoPVNJhgIqBHTXl and trCwivRxKUGdkbeMoPVNJhgIqBHTXY):
   trCwivRxKUGdkbeMoPVNJhgIqBHTjy=xbmcgui.Dialog()
   trCwivRxKUGdkbeMoPVNJhgIqBHTXz=trCwivRxKUGdkbeMoPVNJhgIqBHTjy.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if trCwivRxKUGdkbeMoPVNJhgIqBHTXz==trCwivRxKUGdkbeMoPVNJhgIqBHTlW:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if trCwivRxKUGdkbeMoPVNJhgIqBHTjF.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   trCwivRxKUGdkbeMoPVNJhgIqBHTXF=0
   while trCwivRxKUGdkbeMoPVNJhgIqBHTlW:
    trCwivRxKUGdkbeMoPVNJhgIqBHTXF+=1
    time.sleep(0.05)
    if trCwivRxKUGdkbeMoPVNJhgIqBHTXF>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  trCwivRxKUGdkbeMoPVNJhgIqBHTXn=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.GetCredential(trCwivRxKUGdkbeMoPVNJhgIqBHTXl,trCwivRxKUGdkbeMoPVNJhgIqBHTXY,trCwivRxKUGdkbeMoPVNJhgIqBHTXs,trCwivRxKUGdkbeMoPVNJhgIqBHTXu)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXn:trCwivRxKUGdkbeMoPVNJhgIqBHTjF.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXn==trCwivRxKUGdkbeMoPVNJhgIqBHTlf:
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTXc=trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('stype')
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXc=='live':
   trCwivRxKUGdkbeMoPVNJhgIqBHTXp=trCwivRxKUGdkbeMoPVNJhgIqBHTjL
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTXc=='vod':
   trCwivRxKUGdkbeMoPVNJhgIqBHTXp=trCwivRxKUGdkbeMoPVNJhgIqBHTjm
  else:
   trCwivRxKUGdkbeMoPVNJhgIqBHTXp=trCwivRxKUGdkbeMoPVNJhgIqBHTjl
  for trCwivRxKUGdkbeMoPVNJhgIqBHTXD in trCwivRxKUGdkbeMoPVNJhgIqBHTXp:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp=trCwivRxKUGdkbeMoPVNJhgIqBHTXD.get('title')
   if trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('ordernm')!='-':
    trCwivRxKUGdkbeMoPVNJhgIqBHTOp+='  ('+trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('ordernm')+')'
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':trCwivRxKUGdkbeMoPVNJhgIqBHTXD.get('mode'),'stype':trCwivRxKUGdkbeMoPVNJhgIqBHTXD.get('stype'),'orderby':trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('orderby'),'ordernm':trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('ordernm'),'page':'1'}
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel='',img='',infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTYL(trCwivRxKUGdkbeMoPVNJhgIqBHTXp)>0:xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle)
 def dp_SubTitle_Group(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy): 
  for trCwivRxKUGdkbeMoPVNJhgIqBHTXD in trCwivRxKUGdkbeMoPVNJhgIqBHTjY:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp=trCwivRxKUGdkbeMoPVNJhgIqBHTXD.get('title')
   if trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('ordernm')!='-':
    trCwivRxKUGdkbeMoPVNJhgIqBHTOp+='  ('+trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('ordernm')+')'
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':trCwivRxKUGdkbeMoPVNJhgIqBHTXD.get('mode'),'genreCode':trCwivRxKUGdkbeMoPVNJhgIqBHTXD.get('genreCode'),'stype':trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('stype'),'orderby':trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('orderby'),'page':'1'}
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel='',img='',infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTYL(trCwivRxKUGdkbeMoPVNJhgIqBHTjY)>0:xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle)
 def dp_LiveChannel_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTXc =trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('stype')
  trCwivRxKUGdkbeMoPVNJhgIqBHTXQ =trCwivRxKUGdkbeMoPVNJhgIqBHTla(trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('page'))
  trCwivRxKUGdkbeMoPVNJhgIqBHTXa,trCwivRxKUGdkbeMoPVNJhgIqBHTXW=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.GetLiveChannelList(trCwivRxKUGdkbeMoPVNJhgIqBHTXc,trCwivRxKUGdkbeMoPVNJhgIqBHTXQ)
  for trCwivRxKUGdkbeMoPVNJhgIqBHTXf in trCwivRxKUGdkbeMoPVNJhgIqBHTXa:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('title')
   trCwivRxKUGdkbeMoPVNJhgIqBHTXm =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('channel')
   trCwivRxKUGdkbeMoPVNJhgIqBHTXS =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('thumbnail')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLj =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('synopsis')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLO =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('channelepg')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLX =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('cast')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLE =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('director')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLA =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('info_genre')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLm =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('year')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLl =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('mpaa')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLY =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('premiered')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLs={'mediatype':'episode','title':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'studio':trCwivRxKUGdkbeMoPVNJhgIqBHTXm,'cast':trCwivRxKUGdkbeMoPVNJhgIqBHTLX,'director':trCwivRxKUGdkbeMoPVNJhgIqBHTLE,'genre':trCwivRxKUGdkbeMoPVNJhgIqBHTLA,'plot':'%s\n%s\n%s\n\n%s'%(trCwivRxKUGdkbeMoPVNJhgIqBHTXm,trCwivRxKUGdkbeMoPVNJhgIqBHTOp,trCwivRxKUGdkbeMoPVNJhgIqBHTLO,trCwivRxKUGdkbeMoPVNJhgIqBHTLj),'year':trCwivRxKUGdkbeMoPVNJhgIqBHTLm,'mpaa':trCwivRxKUGdkbeMoPVNJhgIqBHTLl,'premiered':trCwivRxKUGdkbeMoPVNJhgIqBHTLY}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'LIVE','mediacode':trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('mediacode'),'stype':trCwivRxKUGdkbeMoPVNJhgIqBHTXc}
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTXm,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTOp,img=trCwivRxKUGdkbeMoPVNJhgIqBHTXS,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTLs,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlf,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXW:
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['mode']='CHANNEL' 
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['stype']=trCwivRxKUGdkbeMoPVNJhgIqBHTXc 
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['page']=trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp='[B]%s >>[/B]'%'다음 페이지'
   trCwivRxKUGdkbeMoPVNJhgIqBHTLu=trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTXj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTLu,img=trCwivRxKUGdkbeMoPVNJhgIqBHTXj,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTYL(trCwivRxKUGdkbeMoPVNJhgIqBHTXa)>0:xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,cacheToDisc=trCwivRxKUGdkbeMoPVNJhgIqBHTlf)
 def dp_Program_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTLz =trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('stype')
  trCwivRxKUGdkbeMoPVNJhgIqBHTOn =trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('orderby')
  trCwivRxKUGdkbeMoPVNJhgIqBHTXQ =trCwivRxKUGdkbeMoPVNJhgIqBHTla(trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('page'))
  trCwivRxKUGdkbeMoPVNJhgIqBHTLF=trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('genreCode')
  if trCwivRxKUGdkbeMoPVNJhgIqBHTLF==trCwivRxKUGdkbeMoPVNJhgIqBHTlQ:trCwivRxKUGdkbeMoPVNJhgIqBHTLF='all'
  trCwivRxKUGdkbeMoPVNJhgIqBHTLn,trCwivRxKUGdkbeMoPVNJhgIqBHTXW=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.GetProgramList(trCwivRxKUGdkbeMoPVNJhgIqBHTLz,trCwivRxKUGdkbeMoPVNJhgIqBHTOn,trCwivRxKUGdkbeMoPVNJhgIqBHTXQ,trCwivRxKUGdkbeMoPVNJhgIqBHTLF)
  for trCwivRxKUGdkbeMoPVNJhgIqBHTLc in trCwivRxKUGdkbeMoPVNJhgIqBHTLn:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('title')
   trCwivRxKUGdkbeMoPVNJhgIqBHTXS =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('thumbnail')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLj =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('synopsis')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLp =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('channel')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLX =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('cast')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLE =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('director')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLA=trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('info_genre')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLm =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('year')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLY =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('premiered')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLl =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('mpaa')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLs={'mediatype':'tvshow','title':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'studio':trCwivRxKUGdkbeMoPVNJhgIqBHTLp,'cast':trCwivRxKUGdkbeMoPVNJhgIqBHTLX,'director':trCwivRxKUGdkbeMoPVNJhgIqBHTLE,'genre':trCwivRxKUGdkbeMoPVNJhgIqBHTLA,'year':trCwivRxKUGdkbeMoPVNJhgIqBHTLm,'premiered':trCwivRxKUGdkbeMoPVNJhgIqBHTLY,'mpaa':trCwivRxKUGdkbeMoPVNJhgIqBHTLl,'plot':trCwivRxKUGdkbeMoPVNJhgIqBHTLj}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'EPISODE','programcode':trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('program'),'page':'1'}
   if trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_makebookmark():
    trCwivRxKUGdkbeMoPVNJhgIqBHTLD={'videoid':trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('program'),'vidtype':'tvshow','vtitle':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'vsubtitle':trCwivRxKUGdkbeMoPVNJhgIqBHTLp,}
    trCwivRxKUGdkbeMoPVNJhgIqBHTLy=json.dumps(trCwivRxKUGdkbeMoPVNJhgIqBHTLD)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLy=urllib.parse.quote(trCwivRxKUGdkbeMoPVNJhgIqBHTLy)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(trCwivRxKUGdkbeMoPVNJhgIqBHTLy)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLa=[('(통합) 찜 영상에 추가',trCwivRxKUGdkbeMoPVNJhgIqBHTLQ)]
   else:
    trCwivRxKUGdkbeMoPVNJhgIqBHTLa=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTLp,img=trCwivRxKUGdkbeMoPVNJhgIqBHTXS,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTLs,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO,ContextMenu=trCwivRxKUGdkbeMoPVNJhgIqBHTLa)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXW:
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['mode'] ='PROGRAM' 
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['stype'] =trCwivRxKUGdkbeMoPVNJhgIqBHTLz
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['orderby'] =trCwivRxKUGdkbeMoPVNJhgIqBHTOn
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['page'] =trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['genreCode']=trCwivRxKUGdkbeMoPVNJhgIqBHTLF 
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp='[B]%s >>[/B]'%'다음 페이지'
   trCwivRxKUGdkbeMoPVNJhgIqBHTLu=trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTXj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTLu,img=trCwivRxKUGdkbeMoPVNJhgIqBHTXj,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  xbmcplugin.setContent(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,cacheToDisc=trCwivRxKUGdkbeMoPVNJhgIqBHTlf)
 def dp_4K_Program_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTXQ =trCwivRxKUGdkbeMoPVNJhgIqBHTla(trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('page'))
  trCwivRxKUGdkbeMoPVNJhgIqBHTLn,trCwivRxKUGdkbeMoPVNJhgIqBHTXW=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Get_UHD_ProgramList(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ)
  for trCwivRxKUGdkbeMoPVNJhgIqBHTLc in trCwivRxKUGdkbeMoPVNJhgIqBHTLn:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('title')
   trCwivRxKUGdkbeMoPVNJhgIqBHTXS =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('thumbnail')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLj =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('synopsis')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLp =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('channel')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLX =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('cast')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLE =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('director')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLA=trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('info_genre')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLm =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('year')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLY =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('premiered')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLl =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('mpaa')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLs={'mediatype':'tvshow','title':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'studio':trCwivRxKUGdkbeMoPVNJhgIqBHTLp,'cast':trCwivRxKUGdkbeMoPVNJhgIqBHTLX,'director':trCwivRxKUGdkbeMoPVNJhgIqBHTLE,'genre':trCwivRxKUGdkbeMoPVNJhgIqBHTLA,'year':trCwivRxKUGdkbeMoPVNJhgIqBHTLm,'premiered':trCwivRxKUGdkbeMoPVNJhgIqBHTLY,'mpaa':trCwivRxKUGdkbeMoPVNJhgIqBHTLl,'plot':trCwivRxKUGdkbeMoPVNJhgIqBHTLj}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'EPISODE','programcode':trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('program'),'page':'1'}
   if trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_makebookmark():
    trCwivRxKUGdkbeMoPVNJhgIqBHTLD={'videoid':trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('program'),'vidtype':'tvshow','vtitle':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'vsubtitle':trCwivRxKUGdkbeMoPVNJhgIqBHTLp,}
    trCwivRxKUGdkbeMoPVNJhgIqBHTLy=json.dumps(trCwivRxKUGdkbeMoPVNJhgIqBHTLD)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLy=urllib.parse.quote(trCwivRxKUGdkbeMoPVNJhgIqBHTLy)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(trCwivRxKUGdkbeMoPVNJhgIqBHTLy)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLa=[('(통합) 찜 영상에 추가',trCwivRxKUGdkbeMoPVNJhgIqBHTLQ)]
   else:
    trCwivRxKUGdkbeMoPVNJhgIqBHTLa=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTLp,img=trCwivRxKUGdkbeMoPVNJhgIqBHTXS,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTLs,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO,ContextMenu=trCwivRxKUGdkbeMoPVNJhgIqBHTLa)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXW:
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['mode'] ='4K_PROGRAM' 
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['page'] =trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp='[B]%s >>[/B]'%'다음 페이지'
   trCwivRxKUGdkbeMoPVNJhgIqBHTLu=trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTXj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTLu,img=trCwivRxKUGdkbeMoPVNJhgIqBHTXj,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  xbmcplugin.setContent(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,cacheToDisc=trCwivRxKUGdkbeMoPVNJhgIqBHTlf)
 def dp_Ori_Program_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTXQ =trCwivRxKUGdkbeMoPVNJhgIqBHTla(trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('page'))
  trCwivRxKUGdkbeMoPVNJhgIqBHTLn,trCwivRxKUGdkbeMoPVNJhgIqBHTXW=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Get_Origianl_ProgramList(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ)
  for trCwivRxKUGdkbeMoPVNJhgIqBHTLc in trCwivRxKUGdkbeMoPVNJhgIqBHTLn:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('title')
   trCwivRxKUGdkbeMoPVNJhgIqBHTXS =trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('thumbnail')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLs={'mediatype':'tvshow','title':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'EPISODE','programcode':trCwivRxKUGdkbeMoPVNJhgIqBHTLc.get('program'),'page':'1',}
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,img=trCwivRxKUGdkbeMoPVNJhgIqBHTXS,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTLs,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO,ContextMenu=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXW:
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['mode'] ='ORI_PROGRAM' 
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['page'] =trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp='[B]%s >>[/B]'%'다음 페이지'
   trCwivRxKUGdkbeMoPVNJhgIqBHTLu=trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTXj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTLu,img=trCwivRxKUGdkbeMoPVNJhgIqBHTXj,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  xbmcplugin.setContent(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,cacheToDisc=trCwivRxKUGdkbeMoPVNJhgIqBHTlf)
 def dp_Episode_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTLf=trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('programcode')
  trCwivRxKUGdkbeMoPVNJhgIqBHTXQ =trCwivRxKUGdkbeMoPVNJhgIqBHTla(trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('page'))
  trCwivRxKUGdkbeMoPVNJhgIqBHTLS,trCwivRxKUGdkbeMoPVNJhgIqBHTXW,trCwivRxKUGdkbeMoPVNJhgIqBHTEj=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.GetEpisodeList(trCwivRxKUGdkbeMoPVNJhgIqBHTLf,trCwivRxKUGdkbeMoPVNJhgIqBHTXQ,orderby=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_winEpisodeOrderby())
  for trCwivRxKUGdkbeMoPVNJhgIqBHTEO in trCwivRxKUGdkbeMoPVNJhgIqBHTLS:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp =trCwivRxKUGdkbeMoPVNJhgIqBHTEO.get('title')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLu =trCwivRxKUGdkbeMoPVNJhgIqBHTEO.get('subtitle')
   trCwivRxKUGdkbeMoPVNJhgIqBHTXS =trCwivRxKUGdkbeMoPVNJhgIqBHTEO.get('thumbnail')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLj =trCwivRxKUGdkbeMoPVNJhgIqBHTEO.get('synopsis')
   trCwivRxKUGdkbeMoPVNJhgIqBHTEX=trCwivRxKUGdkbeMoPVNJhgIqBHTEO.get('info_title')
   trCwivRxKUGdkbeMoPVNJhgIqBHTEL =trCwivRxKUGdkbeMoPVNJhgIqBHTEO.get('aired')
   trCwivRxKUGdkbeMoPVNJhgIqBHTEA =trCwivRxKUGdkbeMoPVNJhgIqBHTEO.get('studio')
   trCwivRxKUGdkbeMoPVNJhgIqBHTEm =trCwivRxKUGdkbeMoPVNJhgIqBHTEO.get('frequency')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLs={'mediatype':'episode','title':trCwivRxKUGdkbeMoPVNJhgIqBHTEX,'aired':trCwivRxKUGdkbeMoPVNJhgIqBHTEL,'studio':trCwivRxKUGdkbeMoPVNJhgIqBHTEA,'episode':trCwivRxKUGdkbeMoPVNJhgIqBHTEm,'plot':trCwivRxKUGdkbeMoPVNJhgIqBHTLj}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'VOD','mediacode':trCwivRxKUGdkbeMoPVNJhgIqBHTEO.get('episode'),'stype':'vod','programcode':trCwivRxKUGdkbeMoPVNJhgIqBHTLf,'title':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'thumbnail':trCwivRxKUGdkbeMoPVNJhgIqBHTXS}
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTLu,img=trCwivRxKUGdkbeMoPVNJhgIqBHTXS,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTLs,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlf,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXQ==1:
   trCwivRxKUGdkbeMoPVNJhgIqBHTLs={'plot':'정렬순서를 변경합니다.'}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['mode'] ='ORDER_BY' 
   if trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_winEpisodeOrderby()=='desc':
    trCwivRxKUGdkbeMoPVNJhgIqBHTOp='정렬순서변경 : 최신화부터 -> 1회부터'
    trCwivRxKUGdkbeMoPVNJhgIqBHTXO['orderby']='asc'
   else:
    trCwivRxKUGdkbeMoPVNJhgIqBHTOp='정렬순서변경 : 1회부터 -> 최신화부터'
    trCwivRxKUGdkbeMoPVNJhgIqBHTXO['orderby']='desc'
   trCwivRxKUGdkbeMoPVNJhgIqBHTXj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel='',img=trCwivRxKUGdkbeMoPVNJhgIqBHTXj,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTLs,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlf,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO,isLink=trCwivRxKUGdkbeMoPVNJhgIqBHTlW)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXW:
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['mode'] ='EPISODE' 
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['programcode']=trCwivRxKUGdkbeMoPVNJhgIqBHTLf
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['page'] =trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp='[B]%s >>[/B]'%'다음 페이지'
   trCwivRxKUGdkbeMoPVNJhgIqBHTLu=trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTXj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTLu,img=trCwivRxKUGdkbeMoPVNJhgIqBHTXj,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  xbmcplugin.setContent(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,'episodes')
  if trCwivRxKUGdkbeMoPVNJhgIqBHTYL(trCwivRxKUGdkbeMoPVNJhgIqBHTLS)>0:xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,cacheToDisc=trCwivRxKUGdkbeMoPVNJhgIqBHTlW)
 def dp_setEpOrderby(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTOn =trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('orderby')
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.set_winEpisodeOrderby(trCwivRxKUGdkbeMoPVNJhgIqBHTOn)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTLz =trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('stype')
  trCwivRxKUGdkbeMoPVNJhgIqBHTOn =trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('orderby')
  trCwivRxKUGdkbeMoPVNJhgIqBHTXQ=trCwivRxKUGdkbeMoPVNJhgIqBHTla(trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('page'))
  trCwivRxKUGdkbeMoPVNJhgIqBHTEl,trCwivRxKUGdkbeMoPVNJhgIqBHTXW=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.GetMovieList(trCwivRxKUGdkbeMoPVNJhgIqBHTLz,trCwivRxKUGdkbeMoPVNJhgIqBHTOn,trCwivRxKUGdkbeMoPVNJhgIqBHTXQ)
  for trCwivRxKUGdkbeMoPVNJhgIqBHTEY in trCwivRxKUGdkbeMoPVNJhgIqBHTEl:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('title')
   trCwivRxKUGdkbeMoPVNJhgIqBHTXS =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('thumbnail')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLj =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('synopsis')
   trCwivRxKUGdkbeMoPVNJhgIqBHTEX =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('info_title')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLm =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('year')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLX =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('cast')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLE =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('director')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLA =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('info_genre')
   trCwivRxKUGdkbeMoPVNJhgIqBHTEs =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('duration')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLY =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('premiered')
   trCwivRxKUGdkbeMoPVNJhgIqBHTEA =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('studio')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLl =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('mpaa')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLs={'mediatype':'movie','title':trCwivRxKUGdkbeMoPVNJhgIqBHTEX,'year':trCwivRxKUGdkbeMoPVNJhgIqBHTLm,'cast':trCwivRxKUGdkbeMoPVNJhgIqBHTLX,'director':trCwivRxKUGdkbeMoPVNJhgIqBHTLE,'genre':trCwivRxKUGdkbeMoPVNJhgIqBHTLA,'duration':trCwivRxKUGdkbeMoPVNJhgIqBHTEs,'premiered':trCwivRxKUGdkbeMoPVNJhgIqBHTLY,'studio':trCwivRxKUGdkbeMoPVNJhgIqBHTEA,'mpaa':trCwivRxKUGdkbeMoPVNJhgIqBHTLl,'plot':trCwivRxKUGdkbeMoPVNJhgIqBHTLj}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'MOVIE','mediacode':trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('moviecode'),'stype':'movie','title':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'thumbnail':trCwivRxKUGdkbeMoPVNJhgIqBHTXS}
   if trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_makebookmark():
    trCwivRxKUGdkbeMoPVNJhgIqBHTLD={'videoid':trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('moviecode'),'vidtype':'movie','vtitle':trCwivRxKUGdkbeMoPVNJhgIqBHTEX,'vsubtitle':'',}
    trCwivRxKUGdkbeMoPVNJhgIqBHTLy=json.dumps(trCwivRxKUGdkbeMoPVNJhgIqBHTLD)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLy=urllib.parse.quote(trCwivRxKUGdkbeMoPVNJhgIqBHTLy)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(trCwivRxKUGdkbeMoPVNJhgIqBHTLy)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLa=[('(통합) 찜 영상에 추가',trCwivRxKUGdkbeMoPVNJhgIqBHTLQ)]
   else:
    trCwivRxKUGdkbeMoPVNJhgIqBHTLa=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel='',img=trCwivRxKUGdkbeMoPVNJhgIqBHTXS,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTLs,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlf,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO,ContextMenu=trCwivRxKUGdkbeMoPVNJhgIqBHTLa)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXW:
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['mode'] ='MOVIE_SUB' 
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['orderby']=trCwivRxKUGdkbeMoPVNJhgIqBHTOn
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['stype'] =trCwivRxKUGdkbeMoPVNJhgIqBHTLz
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['page'] =trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp='[B]%s >>[/B]'%'다음 페이지'
   trCwivRxKUGdkbeMoPVNJhgIqBHTLu=trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTXj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTLu,img=trCwivRxKUGdkbeMoPVNJhgIqBHTXj,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  xbmcplugin.setContent(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,'movies')
  xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,cacheToDisc=trCwivRxKUGdkbeMoPVNJhgIqBHTlf)
 def dp_4K_Movie_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTXQ=trCwivRxKUGdkbeMoPVNJhgIqBHTla(trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('page'))
  trCwivRxKUGdkbeMoPVNJhgIqBHTEl,trCwivRxKUGdkbeMoPVNJhgIqBHTXW=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Get_UHD_MovieList(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ)
  for trCwivRxKUGdkbeMoPVNJhgIqBHTEY in trCwivRxKUGdkbeMoPVNJhgIqBHTEl:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('title')
   trCwivRxKUGdkbeMoPVNJhgIqBHTXS =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('thumbnail')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLj =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('synopsis')
   trCwivRxKUGdkbeMoPVNJhgIqBHTEX =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('info_title')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLm =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('year')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLX =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('cast')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLE =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('director')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLA =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('info_genre')
   trCwivRxKUGdkbeMoPVNJhgIqBHTEs =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('duration')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLY =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('premiered')
   trCwivRxKUGdkbeMoPVNJhgIqBHTEA =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('studio')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLl =trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('mpaa')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLs={'mediatype':'movie','title':trCwivRxKUGdkbeMoPVNJhgIqBHTEX,'year':trCwivRxKUGdkbeMoPVNJhgIqBHTLm,'cast':trCwivRxKUGdkbeMoPVNJhgIqBHTLX,'director':trCwivRxKUGdkbeMoPVNJhgIqBHTLE,'genre':trCwivRxKUGdkbeMoPVNJhgIqBHTLA,'duration':trCwivRxKUGdkbeMoPVNJhgIqBHTEs,'premiered':trCwivRxKUGdkbeMoPVNJhgIqBHTLY,'studio':trCwivRxKUGdkbeMoPVNJhgIqBHTEA,'mpaa':trCwivRxKUGdkbeMoPVNJhgIqBHTLl,'plot':trCwivRxKUGdkbeMoPVNJhgIqBHTLj}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'MOVIE','mediacode':trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('moviecode'),'stype':'movie','title':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'thumbnail':trCwivRxKUGdkbeMoPVNJhgIqBHTXS}
   if trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_makebookmark():
    trCwivRxKUGdkbeMoPVNJhgIqBHTLD={'videoid':trCwivRxKUGdkbeMoPVNJhgIqBHTEY.get('moviecode'),'vidtype':'movie','vtitle':trCwivRxKUGdkbeMoPVNJhgIqBHTEX,'vsubtitle':'',}
    trCwivRxKUGdkbeMoPVNJhgIqBHTLy=json.dumps(trCwivRxKUGdkbeMoPVNJhgIqBHTLD)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLy=urllib.parse.quote(trCwivRxKUGdkbeMoPVNJhgIqBHTLy)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(trCwivRxKUGdkbeMoPVNJhgIqBHTLy)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLa=[('(통합) 찜 영상에 추가',trCwivRxKUGdkbeMoPVNJhgIqBHTLQ)]
   else:
    trCwivRxKUGdkbeMoPVNJhgIqBHTLa=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel='',img=trCwivRxKUGdkbeMoPVNJhgIqBHTXS,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTLs,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlf,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO,ContextMenu=trCwivRxKUGdkbeMoPVNJhgIqBHTLa)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXW:
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['mode'] ='4K_MOVIE' 
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['page'] =trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp='[B]%s >>[/B]'%'다음 페이지'
   trCwivRxKUGdkbeMoPVNJhgIqBHTLu=trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTXj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTLu,img=trCwivRxKUGdkbeMoPVNJhgIqBHTXj,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  xbmcplugin.setContent(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,'movies')
  xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,cacheToDisc=trCwivRxKUGdkbeMoPVNJhgIqBHTlf)
 def dp_Set_Bookmark(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTEu=urllib.parse.unquote(trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('bm_param'))
  trCwivRxKUGdkbeMoPVNJhgIqBHTEu=json.loads(trCwivRxKUGdkbeMoPVNJhgIqBHTEu)
  trCwivRxKUGdkbeMoPVNJhgIqBHTEz =trCwivRxKUGdkbeMoPVNJhgIqBHTEu.get('videoid')
  trCwivRxKUGdkbeMoPVNJhgIqBHTEF =trCwivRxKUGdkbeMoPVNJhgIqBHTEu.get('vidtype')
  trCwivRxKUGdkbeMoPVNJhgIqBHTEn =trCwivRxKUGdkbeMoPVNJhgIqBHTEu.get('vtitle')
  trCwivRxKUGdkbeMoPVNJhgIqBHTEc =trCwivRxKUGdkbeMoPVNJhgIqBHTEu.get('vsubtitle')
  trCwivRxKUGdkbeMoPVNJhgIqBHTjy=xbmcgui.Dialog()
  trCwivRxKUGdkbeMoPVNJhgIqBHTXz=trCwivRxKUGdkbeMoPVNJhgIqBHTjy.yesno(__language__(30913).encode('utf8'),trCwivRxKUGdkbeMoPVNJhgIqBHTEn+' \n\n'+__language__(30914))
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXz==trCwivRxKUGdkbeMoPVNJhgIqBHTlf:return
  trCwivRxKUGdkbeMoPVNJhgIqBHTEp=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.GetBookmarkInfo(trCwivRxKUGdkbeMoPVNJhgIqBHTEz,trCwivRxKUGdkbeMoPVNJhgIqBHTEF)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTEc!='':
   trCwivRxKUGdkbeMoPVNJhgIqBHTEp['saveinfo']['subtitle']=trCwivRxKUGdkbeMoPVNJhgIqBHTEc 
   if trCwivRxKUGdkbeMoPVNJhgIqBHTEF=='tvshow':trCwivRxKUGdkbeMoPVNJhgIqBHTEp['saveinfo']['infoLabels']['studio']=trCwivRxKUGdkbeMoPVNJhgIqBHTEc 
  trCwivRxKUGdkbeMoPVNJhgIqBHTED=json.dumps(trCwivRxKUGdkbeMoPVNJhgIqBHTEp)
  trCwivRxKUGdkbeMoPVNJhgIqBHTED=urllib.parse.quote(trCwivRxKUGdkbeMoPVNJhgIqBHTED)
  trCwivRxKUGdkbeMoPVNJhgIqBHTLQ ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(trCwivRxKUGdkbeMoPVNJhgIqBHTED)
  xbmc.executebuiltin(trCwivRxKUGdkbeMoPVNJhgIqBHTLQ)
 def dp_Search_Group(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  if 'search_key' in trCwivRxKUGdkbeMoPVNJhgIqBHTXy:
   trCwivRxKUGdkbeMoPVNJhgIqBHTEy=trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('search_key')
  else:
   trCwivRxKUGdkbeMoPVNJhgIqBHTEy=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not trCwivRxKUGdkbeMoPVNJhgIqBHTEy:
    return
  for trCwivRxKUGdkbeMoPVNJhgIqBHTXD in trCwivRxKUGdkbeMoPVNJhgIqBHTjA:
   trCwivRxKUGdkbeMoPVNJhgIqBHTEQ =trCwivRxKUGdkbeMoPVNJhgIqBHTXD.get('mode')
   trCwivRxKUGdkbeMoPVNJhgIqBHTXc=trCwivRxKUGdkbeMoPVNJhgIqBHTXD.get('stype')
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp=trCwivRxKUGdkbeMoPVNJhgIqBHTXD.get('title')
   (trCwivRxKUGdkbeMoPVNJhgIqBHTEa,trCwivRxKUGdkbeMoPVNJhgIqBHTXW)=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.GetSearchList(trCwivRxKUGdkbeMoPVNJhgIqBHTEy,1,trCwivRxKUGdkbeMoPVNJhgIqBHTXc)
   trCwivRxKUGdkbeMoPVNJhgIqBHTXA={'plot':'검색어 : '+trCwivRxKUGdkbeMoPVNJhgIqBHTEy+'\n\n'+trCwivRxKUGdkbeMoPVNJhgIqBHTjF.Search_FreeList(trCwivRxKUGdkbeMoPVNJhgIqBHTEa)}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':trCwivRxKUGdkbeMoPVNJhgIqBHTEQ,'stype':trCwivRxKUGdkbeMoPVNJhgIqBHTXc,'search_key':trCwivRxKUGdkbeMoPVNJhgIqBHTEy,'page':'1',}
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel='',img='',infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTXA,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTYL(trCwivRxKUGdkbeMoPVNJhgIqBHTjA)>0:xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,cacheToDisc=trCwivRxKUGdkbeMoPVNJhgIqBHTlW)
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.Save_Searched_List(trCwivRxKUGdkbeMoPVNJhgIqBHTEy)
 def Search_FreeList(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTAm):
  trCwivRxKUGdkbeMoPVNJhgIqBHTEW=''
  trCwivRxKUGdkbeMoPVNJhgIqBHTEf=7
  try:
   if trCwivRxKUGdkbeMoPVNJhgIqBHTYL(trCwivRxKUGdkbeMoPVNJhgIqBHTAm)==0:return '검색결과 없음'
   for i in trCwivRxKUGdkbeMoPVNJhgIqBHTYA(trCwivRxKUGdkbeMoPVNJhgIqBHTYL(trCwivRxKUGdkbeMoPVNJhgIqBHTAm)):
    if i>=trCwivRxKUGdkbeMoPVNJhgIqBHTEf:
     trCwivRxKUGdkbeMoPVNJhgIqBHTEW=trCwivRxKUGdkbeMoPVNJhgIqBHTEW+'...'
     break
    trCwivRxKUGdkbeMoPVNJhgIqBHTEW=trCwivRxKUGdkbeMoPVNJhgIqBHTEW+trCwivRxKUGdkbeMoPVNJhgIqBHTAm[i]['title']+'\n'
  except:
   return ''
  return trCwivRxKUGdkbeMoPVNJhgIqBHTEW
 def dp_Search_History(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTES=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.Load_List_File('search')
  for trCwivRxKUGdkbeMoPVNJhgIqBHTAj in trCwivRxKUGdkbeMoPVNJhgIqBHTES:
   trCwivRxKUGdkbeMoPVNJhgIqBHTAO=trCwivRxKUGdkbeMoPVNJhgIqBHTYj(urllib.parse.parse_qsl(trCwivRxKUGdkbeMoPVNJhgIqBHTAj))
   trCwivRxKUGdkbeMoPVNJhgIqBHTAX=trCwivRxKUGdkbeMoPVNJhgIqBHTAO.get('skey').strip()
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'SEARCH_GROUP','search_key':trCwivRxKUGdkbeMoPVNJhgIqBHTAX,}
   trCwivRxKUGdkbeMoPVNJhgIqBHTAL={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':trCwivRxKUGdkbeMoPVNJhgIqBHTAX,'vType':'-',}
   trCwivRxKUGdkbeMoPVNJhgIqBHTAE=urllib.parse.urlencode(trCwivRxKUGdkbeMoPVNJhgIqBHTAL)
   trCwivRxKUGdkbeMoPVNJhgIqBHTLa=[('선택된 검색어 ( %s ) 삭제'%(trCwivRxKUGdkbeMoPVNJhgIqBHTAX),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(trCwivRxKUGdkbeMoPVNJhgIqBHTAE))]
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTAX,sublabel='',img=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO,ContextMenu=trCwivRxKUGdkbeMoPVNJhgIqBHTLa)
  trCwivRxKUGdkbeMoPVNJhgIqBHTLs={'plot':'검색목록 전체를 삭제합니다.'}
  trCwivRxKUGdkbeMoPVNJhgIqBHTOp='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  trCwivRxKUGdkbeMoPVNJhgIqBHTXj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel='',img=trCwivRxKUGdkbeMoPVNJhgIqBHTXj,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTLs,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlf,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO,isLink=trCwivRxKUGdkbeMoPVNJhgIqBHTlW)
  xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,cacheToDisc=trCwivRxKUGdkbeMoPVNJhgIqBHTlf)
 def dp_Search_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTXQ =trCwivRxKUGdkbeMoPVNJhgIqBHTla(trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('page'))
  trCwivRxKUGdkbeMoPVNJhgIqBHTXc =trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('stype')
  if 'search_key' in trCwivRxKUGdkbeMoPVNJhgIqBHTXy:
   trCwivRxKUGdkbeMoPVNJhgIqBHTEy=trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('search_key')
  else:
   trCwivRxKUGdkbeMoPVNJhgIqBHTEy=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not trCwivRxKUGdkbeMoPVNJhgIqBHTEy:
    xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle)
    return
  trCwivRxKUGdkbeMoPVNJhgIqBHTEa,trCwivRxKUGdkbeMoPVNJhgIqBHTXW=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.GetSearchList(trCwivRxKUGdkbeMoPVNJhgIqBHTEy,trCwivRxKUGdkbeMoPVNJhgIqBHTXQ,trCwivRxKUGdkbeMoPVNJhgIqBHTXc)
  for trCwivRxKUGdkbeMoPVNJhgIqBHTAm in trCwivRxKUGdkbeMoPVNJhgIqBHTEa:
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp =trCwivRxKUGdkbeMoPVNJhgIqBHTAm.get('title')
   trCwivRxKUGdkbeMoPVNJhgIqBHTXS =trCwivRxKUGdkbeMoPVNJhgIqBHTAm.get('thumbnail')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLj =trCwivRxKUGdkbeMoPVNJhgIqBHTAm.get('synopsis')
   trCwivRxKUGdkbeMoPVNJhgIqBHTAl =trCwivRxKUGdkbeMoPVNJhgIqBHTAm.get('program')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLX =trCwivRxKUGdkbeMoPVNJhgIqBHTAm.get('cast')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLE =trCwivRxKUGdkbeMoPVNJhgIqBHTAm.get('director')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLA=trCwivRxKUGdkbeMoPVNJhgIqBHTAm.get('info_genre')
   trCwivRxKUGdkbeMoPVNJhgIqBHTEs =trCwivRxKUGdkbeMoPVNJhgIqBHTAm.get('duration')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLl =trCwivRxKUGdkbeMoPVNJhgIqBHTAm.get('mpaa')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLm =trCwivRxKUGdkbeMoPVNJhgIqBHTAm.get('year')
   trCwivRxKUGdkbeMoPVNJhgIqBHTEL =trCwivRxKUGdkbeMoPVNJhgIqBHTAm.get('aired')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLs={'mediatype':'tvshow' if trCwivRxKUGdkbeMoPVNJhgIqBHTXc=='vod' else 'movie','title':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'cast':trCwivRxKUGdkbeMoPVNJhgIqBHTLX,'director':trCwivRxKUGdkbeMoPVNJhgIqBHTLE,'genre':trCwivRxKUGdkbeMoPVNJhgIqBHTLA,'duration':trCwivRxKUGdkbeMoPVNJhgIqBHTEs,'mpaa':trCwivRxKUGdkbeMoPVNJhgIqBHTLl,'year':trCwivRxKUGdkbeMoPVNJhgIqBHTLm,'aired':trCwivRxKUGdkbeMoPVNJhgIqBHTEL,'plot':'%s\n\n%s'%(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,trCwivRxKUGdkbeMoPVNJhgIqBHTLj)}
   if trCwivRxKUGdkbeMoPVNJhgIqBHTXc=='vod':
    trCwivRxKUGdkbeMoPVNJhgIqBHTEz=trCwivRxKUGdkbeMoPVNJhgIqBHTAm.get('program')
    trCwivRxKUGdkbeMoPVNJhgIqBHTEF='tvshow'
    trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'EPISODE','programcode':trCwivRxKUGdkbeMoPVNJhgIqBHTEz,'page':'1',}
    trCwivRxKUGdkbeMoPVNJhgIqBHTXL=trCwivRxKUGdkbeMoPVNJhgIqBHTlW
   else:
    trCwivRxKUGdkbeMoPVNJhgIqBHTEz=trCwivRxKUGdkbeMoPVNJhgIqBHTAm.get('movie')
    trCwivRxKUGdkbeMoPVNJhgIqBHTEF='movie'
    trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'MOVIE','mediacode':trCwivRxKUGdkbeMoPVNJhgIqBHTEz,'stype':'movie','title':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'thumbnail':trCwivRxKUGdkbeMoPVNJhgIqBHTXS,}
    trCwivRxKUGdkbeMoPVNJhgIqBHTXL=trCwivRxKUGdkbeMoPVNJhgIqBHTlf
   if trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_makebookmark():
    trCwivRxKUGdkbeMoPVNJhgIqBHTLD={'videoid':trCwivRxKUGdkbeMoPVNJhgIqBHTEz,'vidtype':trCwivRxKUGdkbeMoPVNJhgIqBHTEF,'vtitle':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'vsubtitle':'',}
    trCwivRxKUGdkbeMoPVNJhgIqBHTLy=json.dumps(trCwivRxKUGdkbeMoPVNJhgIqBHTLD)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLy=urllib.parse.quote(trCwivRxKUGdkbeMoPVNJhgIqBHTLy)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLQ='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(trCwivRxKUGdkbeMoPVNJhgIqBHTLy)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLa=[('(통합) 찜 영상에 추가',trCwivRxKUGdkbeMoPVNJhgIqBHTLQ)]
   else:
    trCwivRxKUGdkbeMoPVNJhgIqBHTLa=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel='',img=trCwivRxKUGdkbeMoPVNJhgIqBHTXS,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTLs,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTXL,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO,isLink=trCwivRxKUGdkbeMoPVNJhgIqBHTlf,ContextMenu=trCwivRxKUGdkbeMoPVNJhgIqBHTLa)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXW:
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['mode'] ='SEARCH' 
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['search_key']=trCwivRxKUGdkbeMoPVNJhgIqBHTEy
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO['page'] =trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp='[B]%s >>[/B]'%'다음 페이지'
   trCwivRxKUGdkbeMoPVNJhgIqBHTLu=trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTXQ+1)
   trCwivRxKUGdkbeMoPVNJhgIqBHTXj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTLu,img=trCwivRxKUGdkbeMoPVNJhgIqBHTXj,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXc=='movie':xbmcplugin.setContent(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,'movies')
  else:xbmcplugin.setContent(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,cacheToDisc=trCwivRxKUGdkbeMoPVNJhgIqBHTlf)
 def dp_History_Remove(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTAY=trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('delType')
  trCwivRxKUGdkbeMoPVNJhgIqBHTAs =trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('sKey')
  trCwivRxKUGdkbeMoPVNJhgIqBHTAu =trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('vType')
  trCwivRxKUGdkbeMoPVNJhgIqBHTjy=xbmcgui.Dialog()
  if trCwivRxKUGdkbeMoPVNJhgIqBHTAY=='SEARCH_ALL':
   trCwivRxKUGdkbeMoPVNJhgIqBHTXz=trCwivRxKUGdkbeMoPVNJhgIqBHTjy.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTAY=='SEARCH_ONE':
   trCwivRxKUGdkbeMoPVNJhgIqBHTXz=trCwivRxKUGdkbeMoPVNJhgIqBHTjy.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTAY=='WATCH_ALL':
   trCwivRxKUGdkbeMoPVNJhgIqBHTXz=trCwivRxKUGdkbeMoPVNJhgIqBHTjy.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTAY=='WATCH_ONE':
   trCwivRxKUGdkbeMoPVNJhgIqBHTXz=trCwivRxKUGdkbeMoPVNJhgIqBHTjy.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXz==trCwivRxKUGdkbeMoPVNJhgIqBHTlf:sys.exit()
  if trCwivRxKUGdkbeMoPVNJhgIqBHTAY=='SEARCH_ALL':
   if os.path.isfile(trCwivRxKUGdkbeMoPVNJhgIqBHTjz):os.remove(trCwivRxKUGdkbeMoPVNJhgIqBHTjz)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTAY=='SEARCH_ONE':
   try:
    trCwivRxKUGdkbeMoPVNJhgIqBHTAz=trCwivRxKUGdkbeMoPVNJhgIqBHTjz
    trCwivRxKUGdkbeMoPVNJhgIqBHTAF=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.Load_List_File('search') 
    fp=trCwivRxKUGdkbeMoPVNJhgIqBHTYm(trCwivRxKUGdkbeMoPVNJhgIqBHTAz,'w',-1,'utf-8')
    for trCwivRxKUGdkbeMoPVNJhgIqBHTAn in trCwivRxKUGdkbeMoPVNJhgIqBHTAF:
     trCwivRxKUGdkbeMoPVNJhgIqBHTAc=trCwivRxKUGdkbeMoPVNJhgIqBHTYj(urllib.parse.parse_qsl(trCwivRxKUGdkbeMoPVNJhgIqBHTAn))
     trCwivRxKUGdkbeMoPVNJhgIqBHTAp=trCwivRxKUGdkbeMoPVNJhgIqBHTAc.get('skey').strip()
     if trCwivRxKUGdkbeMoPVNJhgIqBHTAs!=trCwivRxKUGdkbeMoPVNJhgIqBHTAp:
      fp.write(trCwivRxKUGdkbeMoPVNJhgIqBHTAn)
    fp.close()
   except:
    trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTAY=='WATCH_ALL':
   trCwivRxKUGdkbeMoPVNJhgIqBHTAz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%trCwivRxKUGdkbeMoPVNJhgIqBHTAu))
   if os.path.isfile(trCwivRxKUGdkbeMoPVNJhgIqBHTAz):os.remove(trCwivRxKUGdkbeMoPVNJhgIqBHTAz)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTAY=='WATCH_ONE':
   trCwivRxKUGdkbeMoPVNJhgIqBHTAz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%trCwivRxKUGdkbeMoPVNJhgIqBHTAu))
   try:
    trCwivRxKUGdkbeMoPVNJhgIqBHTAF=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.Load_List_File(trCwivRxKUGdkbeMoPVNJhgIqBHTAu) 
    fp=trCwivRxKUGdkbeMoPVNJhgIqBHTYm(trCwivRxKUGdkbeMoPVNJhgIqBHTAz,'w',-1,'utf-8')
    for trCwivRxKUGdkbeMoPVNJhgIqBHTAn in trCwivRxKUGdkbeMoPVNJhgIqBHTAF:
     trCwivRxKUGdkbeMoPVNJhgIqBHTAc=trCwivRxKUGdkbeMoPVNJhgIqBHTYj(urllib.parse.parse_qsl(trCwivRxKUGdkbeMoPVNJhgIqBHTAn))
     trCwivRxKUGdkbeMoPVNJhgIqBHTAp=trCwivRxKUGdkbeMoPVNJhgIqBHTAc.get('code').strip()
     if trCwivRxKUGdkbeMoPVNJhgIqBHTAs!=trCwivRxKUGdkbeMoPVNJhgIqBHTAp:
      fp.write(trCwivRxKUGdkbeMoPVNJhgIqBHTAn)
    fp.close()
   except:
    trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXc): 
  try:
   if trCwivRxKUGdkbeMoPVNJhgIqBHTXc=='search':
    trCwivRxKUGdkbeMoPVNJhgIqBHTAz=trCwivRxKUGdkbeMoPVNJhgIqBHTjz
   elif trCwivRxKUGdkbeMoPVNJhgIqBHTXc in['vod','movie']:
    trCwivRxKUGdkbeMoPVNJhgIqBHTAz=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%trCwivRxKUGdkbeMoPVNJhgIqBHTXc))
   else:
    return[]
   fp=trCwivRxKUGdkbeMoPVNJhgIqBHTYm(trCwivRxKUGdkbeMoPVNJhgIqBHTAz,'r',-1,'utf-8')
   trCwivRxKUGdkbeMoPVNJhgIqBHTAD=fp.readlines()
   fp.close()
  except:
   trCwivRxKUGdkbeMoPVNJhgIqBHTAD=[]
  return trCwivRxKUGdkbeMoPVNJhgIqBHTAD
 def Save_Watched_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXc,trCwivRxKUGdkbeMoPVNJhgIqBHTjp):
  try:
   trCwivRxKUGdkbeMoPVNJhgIqBHTAy=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%trCwivRxKUGdkbeMoPVNJhgIqBHTXc))
   trCwivRxKUGdkbeMoPVNJhgIqBHTAF=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.Load_List_File(trCwivRxKUGdkbeMoPVNJhgIqBHTXc) 
   fp=trCwivRxKUGdkbeMoPVNJhgIqBHTYm(trCwivRxKUGdkbeMoPVNJhgIqBHTAy,'w',-1,'utf-8')
   trCwivRxKUGdkbeMoPVNJhgIqBHTAQ=urllib.parse.urlencode(trCwivRxKUGdkbeMoPVNJhgIqBHTjp)
   trCwivRxKUGdkbeMoPVNJhgIqBHTAQ=trCwivRxKUGdkbeMoPVNJhgIqBHTAQ+'\n'
   fp.write(trCwivRxKUGdkbeMoPVNJhgIqBHTAQ)
   trCwivRxKUGdkbeMoPVNJhgIqBHTAa=0
   for trCwivRxKUGdkbeMoPVNJhgIqBHTAn in trCwivRxKUGdkbeMoPVNJhgIqBHTAF:
    trCwivRxKUGdkbeMoPVNJhgIqBHTAc=trCwivRxKUGdkbeMoPVNJhgIqBHTYj(urllib.parse.parse_qsl(trCwivRxKUGdkbeMoPVNJhgIqBHTAn))
    trCwivRxKUGdkbeMoPVNJhgIqBHTAW=trCwivRxKUGdkbeMoPVNJhgIqBHTjp.get('code').strip()
    trCwivRxKUGdkbeMoPVNJhgIqBHTAf=trCwivRxKUGdkbeMoPVNJhgIqBHTAc.get('code').strip()
    if trCwivRxKUGdkbeMoPVNJhgIqBHTXc=='vod' and trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_direct_replay()==trCwivRxKUGdkbeMoPVNJhgIqBHTlW:
     trCwivRxKUGdkbeMoPVNJhgIqBHTAW=trCwivRxKUGdkbeMoPVNJhgIqBHTjp.get('videoid').strip()
     trCwivRxKUGdkbeMoPVNJhgIqBHTAf=trCwivRxKUGdkbeMoPVNJhgIqBHTAc.get('videoid').strip()if trCwivRxKUGdkbeMoPVNJhgIqBHTAf!=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ else '-'
    if trCwivRxKUGdkbeMoPVNJhgIqBHTAW!=trCwivRxKUGdkbeMoPVNJhgIqBHTAf:
     fp.write(trCwivRxKUGdkbeMoPVNJhgIqBHTAn)
     trCwivRxKUGdkbeMoPVNJhgIqBHTAa+=1
     if trCwivRxKUGdkbeMoPVNJhgIqBHTAa>=50:break
   fp.close()
  except:
   trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
 def dp_Watch_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTXc =trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('stype')
  trCwivRxKUGdkbeMoPVNJhgIqBHTOz=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_direct_replay()
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXc=='-':
   for trCwivRxKUGdkbeMoPVNJhgIqBHTXD in trCwivRxKUGdkbeMoPVNJhgIqBHTjE:
    trCwivRxKUGdkbeMoPVNJhgIqBHTOp=trCwivRxKUGdkbeMoPVNJhgIqBHTXD.get('title')
    trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':trCwivRxKUGdkbeMoPVNJhgIqBHTXD.get('mode'),'stype':trCwivRxKUGdkbeMoPVNJhgIqBHTXD.get('stype')}
    trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel='',img='',infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTlQ,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlW,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
   if trCwivRxKUGdkbeMoPVNJhgIqBHTYL(trCwivRxKUGdkbeMoPVNJhgIqBHTjE)>0:xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle)
  else:
   trCwivRxKUGdkbeMoPVNJhgIqBHTAS=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.Load_List_File(trCwivRxKUGdkbeMoPVNJhgIqBHTXc)
   for trCwivRxKUGdkbeMoPVNJhgIqBHTmj in trCwivRxKUGdkbeMoPVNJhgIqBHTAS:
    trCwivRxKUGdkbeMoPVNJhgIqBHTAO=trCwivRxKUGdkbeMoPVNJhgIqBHTYj(urllib.parse.parse_qsl(trCwivRxKUGdkbeMoPVNJhgIqBHTmj))
    trCwivRxKUGdkbeMoPVNJhgIqBHTmO =trCwivRxKUGdkbeMoPVNJhgIqBHTAO.get('code').strip()
    trCwivRxKUGdkbeMoPVNJhgIqBHTOp =trCwivRxKUGdkbeMoPVNJhgIqBHTAO.get('title').strip()
    trCwivRxKUGdkbeMoPVNJhgIqBHTXS=trCwivRxKUGdkbeMoPVNJhgIqBHTAO.get('img').strip()
    trCwivRxKUGdkbeMoPVNJhgIqBHTEz =trCwivRxKUGdkbeMoPVNJhgIqBHTAO.get('videoid').strip()
    try:
     trCwivRxKUGdkbeMoPVNJhgIqBHTXS=trCwivRxKUGdkbeMoPVNJhgIqBHTXS.replace('\'','\"')
     trCwivRxKUGdkbeMoPVNJhgIqBHTXS=json.loads(trCwivRxKUGdkbeMoPVNJhgIqBHTXS)
    except:
     trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
    trCwivRxKUGdkbeMoPVNJhgIqBHTLs={}
    trCwivRxKUGdkbeMoPVNJhgIqBHTLs['plot']=trCwivRxKUGdkbeMoPVNJhgIqBHTOp
    if trCwivRxKUGdkbeMoPVNJhgIqBHTXc=='vod':
     if trCwivRxKUGdkbeMoPVNJhgIqBHTOz==trCwivRxKUGdkbeMoPVNJhgIqBHTlf or trCwivRxKUGdkbeMoPVNJhgIqBHTEz==trCwivRxKUGdkbeMoPVNJhgIqBHTlQ:
      trCwivRxKUGdkbeMoPVNJhgIqBHTLs['mediatype']='tvshow'
      trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'EPISODE','programcode':trCwivRxKUGdkbeMoPVNJhgIqBHTmO,'page':'1'}
      trCwivRxKUGdkbeMoPVNJhgIqBHTXL=trCwivRxKUGdkbeMoPVNJhgIqBHTlW
     else:
      trCwivRxKUGdkbeMoPVNJhgIqBHTLs['mediatype']='episode'
      trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'VOD','mediacode':trCwivRxKUGdkbeMoPVNJhgIqBHTEz,'stype':'vod','programcode':trCwivRxKUGdkbeMoPVNJhgIqBHTmO,'title':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'thumbnail':trCwivRxKUGdkbeMoPVNJhgIqBHTXS}
      trCwivRxKUGdkbeMoPVNJhgIqBHTXL=trCwivRxKUGdkbeMoPVNJhgIqBHTlf
    else:
     trCwivRxKUGdkbeMoPVNJhgIqBHTLs['mediatype']='movie'
     trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'MOVIE','mediacode':trCwivRxKUGdkbeMoPVNJhgIqBHTmO,'stype':'movie','title':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'thumbnail':trCwivRxKUGdkbeMoPVNJhgIqBHTXS}
     trCwivRxKUGdkbeMoPVNJhgIqBHTXL=trCwivRxKUGdkbeMoPVNJhgIqBHTlf
    trCwivRxKUGdkbeMoPVNJhgIqBHTAL={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':trCwivRxKUGdkbeMoPVNJhgIqBHTmO,'vType':trCwivRxKUGdkbeMoPVNJhgIqBHTXc,}
    trCwivRxKUGdkbeMoPVNJhgIqBHTAE=urllib.parse.urlencode(trCwivRxKUGdkbeMoPVNJhgIqBHTAL)
    trCwivRxKUGdkbeMoPVNJhgIqBHTLa=[('선택된 시청이력 ( %s ) 삭제'%(trCwivRxKUGdkbeMoPVNJhgIqBHTOp),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(trCwivRxKUGdkbeMoPVNJhgIqBHTAE))]
    trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel='',img=trCwivRxKUGdkbeMoPVNJhgIqBHTXS,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTLs,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTXL,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO,ContextMenu=trCwivRxKUGdkbeMoPVNJhgIqBHTLa)
   trCwivRxKUGdkbeMoPVNJhgIqBHTLs={'plot':'시청목록을 삭제합니다.'}
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':trCwivRxKUGdkbeMoPVNJhgIqBHTXc,}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXj=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel='',img=trCwivRxKUGdkbeMoPVNJhgIqBHTXj,infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTLs,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlf,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO,isLink=trCwivRxKUGdkbeMoPVNJhgIqBHTlW)
   if trCwivRxKUGdkbeMoPVNJhgIqBHTXc=='movie':xbmcplugin.setContent(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,'movies')
   else:xbmcplugin.setContent(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,cacheToDisc=trCwivRxKUGdkbeMoPVNJhgIqBHTlf)
 def Save_Searched_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTEy):
  try:
   trCwivRxKUGdkbeMoPVNJhgIqBHTmX=trCwivRxKUGdkbeMoPVNJhgIqBHTjz
   trCwivRxKUGdkbeMoPVNJhgIqBHTAF=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.Load_List_File('search') 
   trCwivRxKUGdkbeMoPVNJhgIqBHTmL={'skey':trCwivRxKUGdkbeMoPVNJhgIqBHTEy.strip()}
   fp=trCwivRxKUGdkbeMoPVNJhgIqBHTYm(trCwivRxKUGdkbeMoPVNJhgIqBHTmX,'w',-1,'utf-8')
   trCwivRxKUGdkbeMoPVNJhgIqBHTAQ=urllib.parse.urlencode(trCwivRxKUGdkbeMoPVNJhgIqBHTmL)
   trCwivRxKUGdkbeMoPVNJhgIqBHTAQ=trCwivRxKUGdkbeMoPVNJhgIqBHTAQ+'\n'
   fp.write(trCwivRxKUGdkbeMoPVNJhgIqBHTAQ)
   trCwivRxKUGdkbeMoPVNJhgIqBHTAa=0
   for trCwivRxKUGdkbeMoPVNJhgIqBHTAn in trCwivRxKUGdkbeMoPVNJhgIqBHTAF:
    trCwivRxKUGdkbeMoPVNJhgIqBHTAc=trCwivRxKUGdkbeMoPVNJhgIqBHTYj(urllib.parse.parse_qsl(trCwivRxKUGdkbeMoPVNJhgIqBHTAn))
    trCwivRxKUGdkbeMoPVNJhgIqBHTAW=trCwivRxKUGdkbeMoPVNJhgIqBHTmL.get('skey').strip()
    trCwivRxKUGdkbeMoPVNJhgIqBHTAf=trCwivRxKUGdkbeMoPVNJhgIqBHTAc.get('skey').strip()
    if trCwivRxKUGdkbeMoPVNJhgIqBHTAW!=trCwivRxKUGdkbeMoPVNJhgIqBHTAf:
     fp.write(trCwivRxKUGdkbeMoPVNJhgIqBHTAn)
     trCwivRxKUGdkbeMoPVNJhgIqBHTAa+=1
     if trCwivRxKUGdkbeMoPVNJhgIqBHTAa>=50:break
   fp.close()
  except:
   trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
 def play_VIDEO(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTmE =trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('mediacode')
  trCwivRxKUGdkbeMoPVNJhgIqBHTXc =trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('stype')
  trCwivRxKUGdkbeMoPVNJhgIqBHTmA =trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('pvrmode')
  trCwivRxKUGdkbeMoPVNJhgIqBHTml=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_selQuality(trCwivRxKUGdkbeMoPVNJhgIqBHTXc)
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(trCwivRxKUGdkbeMoPVNJhgIqBHTmE,trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTml),trCwivRxKUGdkbeMoPVNJhgIqBHTXc,trCwivRxKUGdkbeMoPVNJhgIqBHTmA))
  trCwivRxKUGdkbeMoPVNJhgIqBHTmY=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.GetBroadURL(trCwivRxKUGdkbeMoPVNJhgIqBHTmE,trCwivRxKUGdkbeMoPVNJhgIqBHTml,trCwivRxKUGdkbeMoPVNJhgIqBHTXc,trCwivRxKUGdkbeMoPVNJhgIqBHTmA,optUHD=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_uhd())
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_log('qt, stype, url : %s - %s - %s'%(trCwivRxKUGdkbeMoPVNJhgIqBHTYE(trCwivRxKUGdkbeMoPVNJhgIqBHTml),trCwivRxKUGdkbeMoPVNJhgIqBHTXc,trCwivRxKUGdkbeMoPVNJhgIqBHTmY['streaming_url']))
  if trCwivRxKUGdkbeMoPVNJhgIqBHTmY['streaming_url']=='':
   if trCwivRxKUGdkbeMoPVNJhgIqBHTmY['error_msg']=='':
    trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_noti(__language__(30908).encode('utf8'))
   else:
    trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_noti(trCwivRxKUGdkbeMoPVNJhgIqBHTmY['error_msg'].encode('utf8'))
   return
  trCwivRxKUGdkbeMoPVNJhgIqBHTms='user-agent={}'.format(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.USER_AGENT)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTmY['watermark'] !='':
   trCwivRxKUGdkbeMoPVNJhgIqBHTms='{}&x-tving-param1={}&x-tving-param2={}'.format(trCwivRxKUGdkbeMoPVNJhgIqBHTms,trCwivRxKUGdkbeMoPVNJhgIqBHTmY['watermarkKey'],trCwivRxKUGdkbeMoPVNJhgIqBHTmY['watermark'])
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_log('streaming_url = {}'.format(trCwivRxKUGdkbeMoPVNJhgIqBHTmY['streaming_url']))
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_log('drm_license   = {}'.format(trCwivRxKUGdkbeMoPVNJhgIqBHTmY['drm_license']))
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_log('watermark     = {}'.format(trCwivRxKUGdkbeMoPVNJhgIqBHTmY['watermark']))
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_log('watermarkKey  = {}'.format(trCwivRxKUGdkbeMoPVNJhgIqBHTmY['watermarkKey']))
  trCwivRxKUGdkbeMoPVNJhgIqBHTmu =trCwivRxKUGdkbeMoPVNJhgIqBHTlf
  trCwivRxKUGdkbeMoPVNJhgIqBHTmz =trCwivRxKUGdkbeMoPVNJhgIqBHTmY['streaming_url'].find('Policy=')
  if trCwivRxKUGdkbeMoPVNJhgIqBHTmz!=-1:
   trCwivRxKUGdkbeMoPVNJhgIqBHTmF =trCwivRxKUGdkbeMoPVNJhgIqBHTmY['streaming_url'].split('?')[0]
   trCwivRxKUGdkbeMoPVNJhgIqBHTmn=trCwivRxKUGdkbeMoPVNJhgIqBHTYj(urllib.parse.parse_qsl(urllib.parse.urlsplit(trCwivRxKUGdkbeMoPVNJhgIqBHTmY['streaming_url']).query))
   trCwivRxKUGdkbeMoPVNJhgIqBHTmc='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(trCwivRxKUGdkbeMoPVNJhgIqBHTmn['Policy'],trCwivRxKUGdkbeMoPVNJhgIqBHTmn['Signature'],trCwivRxKUGdkbeMoPVNJhgIqBHTmn['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in trCwivRxKUGdkbeMoPVNJhgIqBHTmF:
    trCwivRxKUGdkbeMoPVNJhgIqBHTmu=trCwivRxKUGdkbeMoPVNJhgIqBHTlW
    trCwivRxKUGdkbeMoPVNJhgIqBHTmp =trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    trCwivRxKUGdkbeMoPVNJhgIqBHTmD=trCwivRxKUGdkbeMoPVNJhgIqBHTmp.strftime('%Y-%m-%d-%H:%M:%S')
    if trCwivRxKUGdkbeMoPVNJhgIqBHTla(trCwivRxKUGdkbeMoPVNJhgIqBHTmD.replace('-','').replace(':',''))<trCwivRxKUGdkbeMoPVNJhgIqBHTla(trCwivRxKUGdkbeMoPVNJhgIqBHTmn['end'].replace('-','').replace(':','')):
     trCwivRxKUGdkbeMoPVNJhgIqBHTmn['end']=trCwivRxKUGdkbeMoPVNJhgIqBHTmD
     trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_noti(__language__(30915).encode('utf8'))
    trCwivRxKUGdkbeMoPVNJhgIqBHTmF ='%s?%s'%(trCwivRxKUGdkbeMoPVNJhgIqBHTmF,urllib.parse.urlencode(trCwivRxKUGdkbeMoPVNJhgIqBHTmn,doseq=trCwivRxKUGdkbeMoPVNJhgIqBHTlW))
    trCwivRxKUGdkbeMoPVNJhgIqBHTmy='{}|{}&Cookie={}'.format(trCwivRxKUGdkbeMoPVNJhgIqBHTmF,trCwivRxKUGdkbeMoPVNJhgIqBHTms,trCwivRxKUGdkbeMoPVNJhgIqBHTmc)
   else:
    trCwivRxKUGdkbeMoPVNJhgIqBHTmy='{}|{}&Cookie={}'.format(trCwivRxKUGdkbeMoPVNJhgIqBHTmY['streaming_url'],trCwivRxKUGdkbeMoPVNJhgIqBHTms,trCwivRxKUGdkbeMoPVNJhgIqBHTmc)
  else:
   trCwivRxKUGdkbeMoPVNJhgIqBHTmy=trCwivRxKUGdkbeMoPVNJhgIqBHTmY['streaming_url']+'|'+trCwivRxKUGdkbeMoPVNJhgIqBHTms
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_log('if tmp_pos == -1')
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_log(trCwivRxKUGdkbeMoPVNJhgIqBHTmy)
  trCwivRxKUGdkbeMoPVNJhgIqBHTOE,trCwivRxKUGdkbeMoPVNJhgIqBHTOA=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_proxyport()
  trCwivRxKUGdkbeMoPVNJhgIqBHTOL=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_playback()
  trCwivRxKUGdkbeMoPVNJhgIqBHTmQ=urllib.parse.urlparse(trCwivRxKUGdkbeMoPVNJhgIqBHTmY['streaming_url'])
  trCwivRxKUGdkbeMoPVNJhgIqBHTmQ=trCwivRxKUGdkbeMoPVNJhgIqBHTmQ.path.strip('/').split('/')
  trCwivRxKUGdkbeMoPVNJhgIqBHTmQ=trCwivRxKUGdkbeMoPVNJhgIqBHTmQ[trCwivRxKUGdkbeMoPVNJhgIqBHTYL(trCwivRxKUGdkbeMoPVNJhgIqBHTmQ)-1] 
  if trCwivRxKUGdkbeMoPVNJhgIqBHTOE and trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('mode')in['VOD','MOVIE']:
   if trCwivRxKUGdkbeMoPVNJhgIqBHTmQ.split('.')[1]=='mpd':
    trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Tving_Parse_mpd(trCwivRxKUGdkbeMoPVNJhgIqBHTmY['streaming_url'])
   else:
    trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Tving_Parse_m3u8(trCwivRxKUGdkbeMoPVNJhgIqBHTmY['streaming_url'])
   trCwivRxKUGdkbeMoPVNJhgIqBHTma={'addon':'tvingm','playOption':trCwivRxKUGdkbeMoPVNJhgIqBHTOL,}
   trCwivRxKUGdkbeMoPVNJhgIqBHTma=json.dumps(trCwivRxKUGdkbeMoPVNJhgIqBHTma,separators=(',',':'))
   trCwivRxKUGdkbeMoPVNJhgIqBHTma=base64.standard_b64encode(trCwivRxKUGdkbeMoPVNJhgIqBHTma.encode()).decode('utf-8')
   trCwivRxKUGdkbeMoPVNJhgIqBHTmy ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(trCwivRxKUGdkbeMoPVNJhgIqBHTOA,trCwivRxKUGdkbeMoPVNJhgIqBHTmy,trCwivRxKUGdkbeMoPVNJhgIqBHTma)
   trCwivRxKUGdkbeMoPVNJhgIqBHTms='{}&proxy-mini={}'.format(trCwivRxKUGdkbeMoPVNJhgIqBHTms,trCwivRxKUGdkbeMoPVNJhgIqBHTma)
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_log(trCwivRxKUGdkbeMoPVNJhgIqBHTmy)
  trCwivRxKUGdkbeMoPVNJhgIqBHTmW=xbmcgui.ListItem(path=trCwivRxKUGdkbeMoPVNJhgIqBHTmy)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTmY['drm_license']!='':
   trCwivRxKUGdkbeMoPVNJhgIqBHTmf=trCwivRxKUGdkbeMoPVNJhgIqBHTmY['drm_license']
   trCwivRxKUGdkbeMoPVNJhgIqBHTmS ='https://cj.drmkeyserver.com/widevine_license'
   trCwivRxKUGdkbeMoPVNJhgIqBHTlj ='mpd'
   trCwivRxKUGdkbeMoPVNJhgIqBHTlO ='com.widevine.alpha'
   trCwivRxKUGdkbeMoPVNJhgIqBHTlX =inputstreamhelper.Helper(trCwivRxKUGdkbeMoPVNJhgIqBHTlj,drm='widevine')
   if trCwivRxKUGdkbeMoPVNJhgIqBHTlX.check_inputstream():
    trCwivRxKUGdkbeMoPVNJhgIqBHTlL={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.USER_AGENT,'AcquireLicenseAssertion':trCwivRxKUGdkbeMoPVNJhgIqBHTmf,'Host':'cj.drmkeyserver.com',}
    trCwivRxKUGdkbeMoPVNJhgIqBHTlE=trCwivRxKUGdkbeMoPVNJhgIqBHTmS+'|'+urllib.parse.urlencode(trCwivRxKUGdkbeMoPVNJhgIqBHTlL)+'|R{SSM}|'
    trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('inputstream',trCwivRxKUGdkbeMoPVNJhgIqBHTlX.inputstream_addon)
    trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('inputstream.adaptive.manifest_type',trCwivRxKUGdkbeMoPVNJhgIqBHTlj)
    trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('inputstream.adaptive.license_type',trCwivRxKUGdkbeMoPVNJhgIqBHTlO)
    trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('inputstream.adaptive.license_key',trCwivRxKUGdkbeMoPVNJhgIqBHTlE)
    trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('inputstream.adaptive.stream_headers',trCwivRxKUGdkbeMoPVNJhgIqBHTms)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('mode')in['VOD','MOVIE']:
   trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setContentLookup(trCwivRxKUGdkbeMoPVNJhgIqBHTlf)
   trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setMimeType('application/x-mpegURL')
   trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('inputstream','inputstream.adaptive')
   trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('inputstream.adaptive.manifest_type','hls')
   trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('inputstream.adaptive.stream_headers',trCwivRxKUGdkbeMoPVNJhgIqBHTms)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTmu==trCwivRxKUGdkbeMoPVNJhgIqBHTlW:
   trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setContentLookup(trCwivRxKUGdkbeMoPVNJhgIqBHTlf)
   trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setMimeType('application/x-mpegURL')
   trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('inputstream','inputstream.ffmpegdirect')
   trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('ResumeTime','0')
   trCwivRxKUGdkbeMoPVNJhgIqBHTmW.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,trCwivRxKUGdkbeMoPVNJhgIqBHTlW,trCwivRxKUGdkbeMoPVNJhgIqBHTmW)
  try:
   if trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('mode')in['VOD','MOVIE']and trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('title'):
    trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'code':trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('programcode')if trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('mode')=='VOD' else trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('mediacode'),'img':trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('thumbnail'),'title':trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('title'),'videoid':trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('mediacode')}
    trCwivRxKUGdkbeMoPVNJhgIqBHTjF.Save_Watched_List(trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('stype'),trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  except:
   trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
 def logout(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  trCwivRxKUGdkbeMoPVNJhgIqBHTjy=xbmcgui.Dialog()
  trCwivRxKUGdkbeMoPVNJhgIqBHTXz=trCwivRxKUGdkbeMoPVNJhgIqBHTjy.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if trCwivRxKUGdkbeMoPVNJhgIqBHTXz==trCwivRxKUGdkbeMoPVNJhgIqBHTlf:sys.exit()
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Init_TV_Total()
  if os.path.isfile(trCwivRxKUGdkbeMoPVNJhgIqBHTju):os.remove(trCwivRxKUGdkbeMoPVNJhgIqBHTju)
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  trCwivRxKUGdkbeMoPVNJhgIqBHTlA =trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Get_Now_Datetime()
  trCwivRxKUGdkbeMoPVNJhgIqBHTlm=trCwivRxKUGdkbeMoPVNJhgIqBHTlA+datetime.timedelta(days=trCwivRxKUGdkbeMoPVNJhgIqBHTla(__addon__.getSetting('cache_ttl')))
  (trCwivRxKUGdkbeMoPVNJhgIqBHTXl,trCwivRxKUGdkbeMoPVNJhgIqBHTXY,trCwivRxKUGdkbeMoPVNJhgIqBHTXs,trCwivRxKUGdkbeMoPVNJhgIqBHTXu)=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_account()
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Save_session_acount(trCwivRxKUGdkbeMoPVNJhgIqBHTXl,trCwivRxKUGdkbeMoPVNJhgIqBHTXY,trCwivRxKUGdkbeMoPVNJhgIqBHTXs,trCwivRxKUGdkbeMoPVNJhgIqBHTXu)
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.TV['account']['token_limit']=trCwivRxKUGdkbeMoPVNJhgIqBHTlm.strftime('%Y%m%d')
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.JsonFile_Save(trCwivRxKUGdkbeMoPVNJhgIqBHTju,trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.TV)
 def cookiefile_check(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.TV=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.JsonFile_Load(trCwivRxKUGdkbeMoPVNJhgIqBHTju)
  if 'account' not in trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.TV:
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Init_TV_Total()
   return trCwivRxKUGdkbeMoPVNJhgIqBHTlf
  (trCwivRxKUGdkbeMoPVNJhgIqBHTlY,trCwivRxKUGdkbeMoPVNJhgIqBHTls,trCwivRxKUGdkbeMoPVNJhgIqBHTlu,trCwivRxKUGdkbeMoPVNJhgIqBHTlz)=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.get_settings_account()
  (trCwivRxKUGdkbeMoPVNJhgIqBHTlF,trCwivRxKUGdkbeMoPVNJhgIqBHTln,trCwivRxKUGdkbeMoPVNJhgIqBHTlc,trCwivRxKUGdkbeMoPVNJhgIqBHTlp)=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Load_session_acount()
  if trCwivRxKUGdkbeMoPVNJhgIqBHTlY!=trCwivRxKUGdkbeMoPVNJhgIqBHTlF or trCwivRxKUGdkbeMoPVNJhgIqBHTls!=trCwivRxKUGdkbeMoPVNJhgIqBHTln or trCwivRxKUGdkbeMoPVNJhgIqBHTlu!=trCwivRxKUGdkbeMoPVNJhgIqBHTlc or trCwivRxKUGdkbeMoPVNJhgIqBHTlz!=trCwivRxKUGdkbeMoPVNJhgIqBHTlp:
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Init_TV_Total()
   return trCwivRxKUGdkbeMoPVNJhgIqBHTlf
  if trCwivRxKUGdkbeMoPVNJhgIqBHTla(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>trCwivRxKUGdkbeMoPVNJhgIqBHTla(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.TV['account']['token_limit']):
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.Init_TV_Total()
   return trCwivRxKUGdkbeMoPVNJhgIqBHTlf
  return trCwivRxKUGdkbeMoPVNJhgIqBHTlW
 def dp_Global_Search(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=trCwivRxKUGdkbeMoPVNJhgIqBHTXy.get('mode')
  if trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='TOTAL_SEARCH':
   trCwivRxKUGdkbeMoPVNJhgIqBHTlD='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   trCwivRxKUGdkbeMoPVNJhgIqBHTlD='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(trCwivRxKUGdkbeMoPVNJhgIqBHTlD)
 def dp_Bookmark_Menu(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTlD='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(trCwivRxKUGdkbeMoPVNJhgIqBHTlD)
 def dp_EuroLive_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF,trCwivRxKUGdkbeMoPVNJhgIqBHTXy):
  trCwivRxKUGdkbeMoPVNJhgIqBHTXa=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.GetEuroChannelList()
  for trCwivRxKUGdkbeMoPVNJhgIqBHTXf in trCwivRxKUGdkbeMoPVNJhgIqBHTXa:
   trCwivRxKUGdkbeMoPVNJhgIqBHTLp =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('channel')
   trCwivRxKUGdkbeMoPVNJhgIqBHTOp =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('title')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLu =trCwivRxKUGdkbeMoPVNJhgIqBHTXf.get('subtitle')
   trCwivRxKUGdkbeMoPVNJhgIqBHTLs={'mediatype':'episode','title':trCwivRxKUGdkbeMoPVNJhgIqBHTOp,'plot':'%s\n%s'%(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,trCwivRxKUGdkbeMoPVNJhgIqBHTLu)}
   trCwivRxKUGdkbeMoPVNJhgIqBHTXO={'mode':'LIVE','mediacode':trCwivRxKUGdkbeMoPVNJhgIqBHTLp,'stype':'onair',}
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.add_dir(trCwivRxKUGdkbeMoPVNJhgIqBHTOp,sublabel=trCwivRxKUGdkbeMoPVNJhgIqBHTLu,img='',infoLabels=trCwivRxKUGdkbeMoPVNJhgIqBHTLs,isFolder=trCwivRxKUGdkbeMoPVNJhgIqBHTlf,params=trCwivRxKUGdkbeMoPVNJhgIqBHTXO)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTYL(trCwivRxKUGdkbeMoPVNJhgIqBHTXa)>0:xbmcplugin.endOfDirectory(trCwivRxKUGdkbeMoPVNJhgIqBHTjF._addon_handle,cacheToDisc=trCwivRxKUGdkbeMoPVNJhgIqBHTlf)
 def tving_main(trCwivRxKUGdkbeMoPVNJhgIqBHTjF):
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.TvingObj.KodiVersion=trCwivRxKUGdkbeMoPVNJhgIqBHTla(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params.get('mode',trCwivRxKUGdkbeMoPVNJhgIqBHTlQ)
  if trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='LOGOUT':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.logout()
   return
  trCwivRxKUGdkbeMoPVNJhgIqBHTjF.login_main()
  if trCwivRxKUGdkbeMoPVNJhgIqBHTEQ is trCwivRxKUGdkbeMoPVNJhgIqBHTlQ:
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_Main_List()
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_Title_Group(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ in['GLOBAL_GROUP']:
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_SubTitle_Group(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='CHANNEL':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_LiveChannel_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ in['LIVE','VOD','MOVIE']:
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.play_VIDEO(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='PROGRAM':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_Program_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='4K_PROGRAM':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_4K_Program_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='ORI_PROGRAM':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_Ori_Program_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='EPISODE':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_Episode_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='MOVIE_SUB':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_Movie_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='4K_MOVIE':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_4K_Movie_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='SEARCH_GROUP':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_Search_Group(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ in['SEARCH','LOCAL_SEARCH']:
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_Search_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='WATCH':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_Watch_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_History_Remove(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='ORDER_BY':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_setEpOrderby(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='SET_BOOKMARK':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_Set_Bookmark(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ in['TOTAL_SEARCH','TOTAL_HISTORY']:
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_Global_Search(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='SEARCH_HISTORY':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_Search_History(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='MENU_BOOKMARK':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_Bookmark_Menu(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  elif trCwivRxKUGdkbeMoPVNJhgIqBHTEQ=='EURO_GROUP':
   trCwivRxKUGdkbeMoPVNJhgIqBHTjF.dp_EuroLive_List(trCwivRxKUGdkbeMoPVNJhgIqBHTjF.main_params)
  else:
   trCwivRxKUGdkbeMoPVNJhgIqBHTlQ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
