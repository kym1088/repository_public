__author__="NightRain"
bdKARiXhIcgsQTnYUpaHSxeFEjJqwP=print
bdKARiXhIcgsQTnYUpaHSxeFEjJqwf=ImportError
bdKARiXhIcgsQTnYUpaHSxeFEjJqwu=object
bdKARiXhIcgsQTnYUpaHSxeFEjJqwG=None
bdKARiXhIcgsQTnYUpaHSxeFEjJqwV=False
bdKARiXhIcgsQTnYUpaHSxeFEjJqwr=open
bdKARiXhIcgsQTnYUpaHSxeFEjJqwv=True
bdKARiXhIcgsQTnYUpaHSxeFEjJqwt=int
bdKARiXhIcgsQTnYUpaHSxeFEjJqwo=range
bdKARiXhIcgsQTnYUpaHSxeFEjJqwO=Exception
bdKARiXhIcgsQTnYUpaHSxeFEjJqwM=len
bdKARiXhIcgsQTnYUpaHSxeFEjJqwC=str
bdKARiXhIcgsQTnYUpaHSxeFEjJqwz=dict
bdKARiXhIcgsQTnYUpaHSxeFEjJqBk=list
bdKARiXhIcgsQTnYUpaHSxeFEjJqBy=bytes
bdKARiXhIcgsQTnYUpaHSxeFEjJqBm=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 bdKARiXhIcgsQTnYUpaHSxeFEjJqwP('Cryptodome')
except bdKARiXhIcgsQTnYUpaHSxeFEjJqwf:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 bdKARiXhIcgsQTnYUpaHSxeFEjJqwP('Crypto')
bdKARiXhIcgsQTnYUpaHSxeFEjJqkm={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
bdKARiXhIcgsQTnYUpaHSxeFEjJqkL ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
bdKARiXhIcgsQTnYUpaHSxeFEjJqkN =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class bdKARiXhIcgsQTnYUpaHSxeFEjJqky(bdKARiXhIcgsQTnYUpaHSxeFEjJqwu):
 def __init__(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.NETWORKCODE ='CSND0900'
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.OSCODE ='CSOD0900' 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TELECODE ='CSCD0900'
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.SCREENCODE ='CSSD0100'
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.SCREENCODE_ATV ='CSSD1300' 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.LIVE_LIMIT =20 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.VOD_LIMIT =24 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.EPISODE_LIMIT =30 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.SEARCH_LIMIT =30 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.MOVIE_LIMIT =24 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN ='https://api.tving.com'
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN ='https://image.tving.com'
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.SEARCH_DOMAIN ='https://search.tving.com'
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.LOGIN_DOMAIN ='https://user.tving.com'
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.URL_DOMAIN ='https://www.tving.com'
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.MOVIE_LITE =['2610061','2610161','261062']
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.DEFAULT_HEADER ={'user-agent':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.USER_AGENT}
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV_SESSION_COOKIES1=''
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV_SESSION_COOKIES2=''
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV_STREAM_FILENAME =''
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.KodiVersion=20
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV ={}
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.Init_TV_Total()
 def Init_TV_Total(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N','tving_authToken':'',},}
 def callRequestCookies(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,jobtype,bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,redirects=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkw=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.DEFAULT_HEADER
  if headers:bdKARiXhIcgsQTnYUpaHSxeFEjJqkw.update(headers)
  if jobtype=='Get':
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkB=requests.get(bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,params=params,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqkw,cookies=cookies,allow_redirects=redirects)
  else:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkB=requests.post(bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,data=payload,params=params,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqkw,cookies=cookies,allow_redirects=redirects)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqkB
 def JsonFile_Save(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,filename,bdKARiXhIcgsQTnYUpaHSxeFEjJqkD):
  if filename=='':return bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  try:
   fp=bdKARiXhIcgsQTnYUpaHSxeFEjJqwr(filename,'w',-1,'utf-8')
   json.dump(bdKARiXhIcgsQTnYUpaHSxeFEjJqkD,fp,indent=4,ensure_ascii=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV)
   fp.close()
  except:
   return bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
 def JsonFile_Load(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,filename):
  if filename=='':return{}
  try:
   fp=bdKARiXhIcgsQTnYUpaHSxeFEjJqwr(filename,'r',-1,'utf-8')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkP=json.load(fp)
   fp.close()
  except:
   return{}
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqkP
 def TextFile_Save(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,filename,resText):
  if filename=='':return bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  try:
   fp=bdKARiXhIcgsQTnYUpaHSxeFEjJqwr(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
 def Save_session_acount(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,bdKARiXhIcgsQTnYUpaHSxeFEjJqkf,bdKARiXhIcgsQTnYUpaHSxeFEjJqku,bdKARiXhIcgsQTnYUpaHSxeFEjJqkG,bdKARiXhIcgsQTnYUpaHSxeFEjJqkV):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['account']['tvid'] =base64.standard_b64encode(bdKARiXhIcgsQTnYUpaHSxeFEjJqkf.encode()).decode('utf-8')
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['account']['tvpw'] =base64.standard_b64encode(bdKARiXhIcgsQTnYUpaHSxeFEjJqku.encode()).decode('utf-8')
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['account']['tvtype']=bdKARiXhIcgsQTnYUpaHSxeFEjJqkG 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['account']['tvpf'] =bdKARiXhIcgsQTnYUpaHSxeFEjJqkV 
 def Load_session_acount(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl):
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkf =base64.standard_b64decode(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['account']['tvid']).decode('utf-8')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqku =base64.standard_b64decode(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['account']['tvpw']).decode('utf-8')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkG=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['account']['tvtype']
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkV =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqkf,bdKARiXhIcgsQTnYUpaHSxeFEjJqku,bdKARiXhIcgsQTnYUpaHSxeFEjJqkG,bdKARiXhIcgsQTnYUpaHSxeFEjJqkV
 def makeDefaultCookies(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkr={}
  if bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_token']:bdKARiXhIcgsQTnYUpaHSxeFEjJqkr['_tving_token']=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_token']
  if bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_userinfo']:bdKARiXhIcgsQTnYUpaHSxeFEjJqkr['POC_USERINFO']=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_userinfo']
  if bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_maintoken']:bdKARiXhIcgsQTnYUpaHSxeFEjJqkr[bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GLOBAL_COOKIENM['tv_maintoken']]=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_maintoken']
  if bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_cookiekey']:bdKARiXhIcgsQTnYUpaHSxeFEjJqkr[bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GLOBAL_COOKIENM['tv_cookiekey']]=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_cookiekey']
  if bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_lockkey']:bdKARiXhIcgsQTnYUpaHSxeFEjJqkr[bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GLOBAL_COOKIENM['tv_lockkey']]=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_lockkey']
  if bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_authToken']:bdKARiXhIcgsQTnYUpaHSxeFEjJqkr['authToken']=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_authToken']
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqkr
 def makeCookiesStr(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl):
  return '_tving_token='+bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_token']+';'+ 'POC_USERINFO='+bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_userinfo']+';'+ bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GLOBAL_COOKIENM['tv_maintoken']+'='+bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_maintoken']+';'+ bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GLOBAL_COOKIENM['tv_cookiekey']+'='+bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_cookiekey']+';'+ bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GLOBAL_COOKIENM['tv_lockkey']+'='+bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_lockkey']
 def getDeviceStr(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkv=[]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkv.append('Windows') 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkv.append('Chrome') 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkv.append('ko-KR') 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkv.append('undefined') 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkv.append('24') 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkv.append(u'한국 표준시')
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkv.append('undefined') 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkv.append('undefined') 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkv.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkt=''
  for bdKARiXhIcgsQTnYUpaHSxeFEjJqko in bdKARiXhIcgsQTnYUpaHSxeFEjJqkv:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkt+=bdKARiXhIcgsQTnYUpaHSxeFEjJqko+'|'
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqkt
 def GetDefaultParams(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,uhd=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV):
  if uhd==bdKARiXhIcgsQTnYUpaHSxeFEjJqwV:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkO={'apiKey':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.APIKEY,'networkCode':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.NETWORKCODE,'osCode':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.OSCODE,'teleCode':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TELECODE,'screenCode':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.SCREENCODE,}
  else:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkO={'apiKey':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.APIKEY_ATV,'networkCode':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.NETWORKCODE,'osCode':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.OSCODE,'teleCode':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TELECODE,'screenCode':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.SCREENCODE_ATV,}
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqkO
 def GetNoCache(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,timetype=1):
  if timetype==1:
   return bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(time.time())
  else:
   return bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(time.time()*1000)
 def GetUniqueid(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,hValue=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG):
  if hValue:
   import hashlib
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkM=hashlib.sha1()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkM.update(hValue.encode())
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkC=bdKARiXhIcgsQTnYUpaHSxeFEjJqkM.hexdigest()[:8]
  else:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkz=[0 for i in bdKARiXhIcgsQTnYUpaHSxeFEjJqwo(256)]
   for i in bdKARiXhIcgsQTnYUpaHSxeFEjJqwo(256):
    bdKARiXhIcgsQTnYUpaHSxeFEjJqkz[i]='%02x'%(i)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyk=bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(4294967295*random.random())|0
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkC=bdKARiXhIcgsQTnYUpaHSxeFEjJqkz[255&bdKARiXhIcgsQTnYUpaHSxeFEjJqyk]+bdKARiXhIcgsQTnYUpaHSxeFEjJqkz[bdKARiXhIcgsQTnYUpaHSxeFEjJqyk>>8&255]+bdKARiXhIcgsQTnYUpaHSxeFEjJqkz[bdKARiXhIcgsQTnYUpaHSxeFEjJqyk>>16&255]+bdKARiXhIcgsQTnYUpaHSxeFEjJqkz[bdKARiXhIcgsQTnYUpaHSxeFEjJqyk>>24&255]
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqkC
 def GetCredential(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,user_id,user_pw,login_type,user_pf):
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqym=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyL={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Post',bdKARiXhIcgsQTnYUpaHSxeFEjJqym,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqyL,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG)
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqyl in bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.cookies:
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqyl.name=='_tving_token':
     bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_token']=bdKARiXhIcgsQTnYUpaHSxeFEjJqyl.value
    elif bdKARiXhIcgsQTnYUpaHSxeFEjJqyl.name=='POC_USERINFO':
     bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_userinfo']=bdKARiXhIcgsQTnYUpaHSxeFEjJqyl.value
    elif bdKARiXhIcgsQTnYUpaHSxeFEjJqyl.name=='authToken':
     bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_authToken']=bdKARiXhIcgsQTnYUpaHSxeFEjJqyl.value
   if not bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_token']:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.Init_TV_Total()
    return bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_maintoken']=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_token']
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetProfileToken(user_pf)==bdKARiXhIcgsQTnYUpaHSxeFEjJqwV:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.Init_TV_Total()
    return bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies'])
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyw =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDeviceList()
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqyw not in['','-']:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_uuid']=bdKARiXhIcgsQTnYUpaHSxeFEjJqyw+'-'+bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetUniqueid(bdKARiXhIcgsQTnYUpaHSxeFEjJqyw)
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.Init_TV_Total()
   return bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
 def GetProfileToken(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,user_pf):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyB=[]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyD =''
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkr=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.makeDefaultCookies()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(bdKARiXhIcgsQTnYUpaHSxeFEjJqkr)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqyW,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqkr)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyB =re.findall('data-profile-no="\d+"',bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(bdKARiXhIcgsQTnYUpaHSxeFEjJqyB)
   for i in bdKARiXhIcgsQTnYUpaHSxeFEjJqwo(bdKARiXhIcgsQTnYUpaHSxeFEjJqwM(bdKARiXhIcgsQTnYUpaHSxeFEjJqyB)):
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyP =bdKARiXhIcgsQTnYUpaHSxeFEjJqyB[i].replace('data-profile-no=','').replace('"','')
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyB[i]=bdKARiXhIcgsQTnYUpaHSxeFEjJqyP
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyD=bdKARiXhIcgsQTnYUpaHSxeFEjJqyB[user_pf]
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.Init_TV_Total()
   return bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkr=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.makeDefaultCookies()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyL={'profileNo':bdKARiXhIcgsQTnYUpaHSxeFEjJqyD}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Post',bdKARiXhIcgsQTnYUpaHSxeFEjJqyW,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqyL,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqkr)
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqyl in bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.cookies:
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqyl.name=='_tving_token':
     bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_token']=bdKARiXhIcgsQTnYUpaHSxeFEjJqyl.value
    elif bdKARiXhIcgsQTnYUpaHSxeFEjJqyl.name==bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GLOBAL_COOKIENM['tv_cookiekey']:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_cookiekey']=bdKARiXhIcgsQTnYUpaHSxeFEjJqyl.value
    elif bdKARiXhIcgsQTnYUpaHSxeFEjJqyl.name==bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GLOBAL_COOKIENM['tv_lockkey']:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_lockkey']=bdKARiXhIcgsQTnYUpaHSxeFEjJqyl.value
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.Init_TV_Total()
   return bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
 def GetDeviceList(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyf=[]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyu='-'
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v1/user/device/list'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyG=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyW
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkr=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.makeDefaultCookies()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqyG,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyV,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqkr)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyr=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyf=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqyv in bdKARiXhIcgsQTnYUpaHSxeFEjJqyf:
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['model']=='PC' or bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['model']=='PC-Chrome':
     bdKARiXhIcgsQTnYUpaHSxeFEjJqyu=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['uuid']
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqyu
 def Get_Now_Datetime(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,mediacode,sel_quality,stype,pvrmode='-',optUHD=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyo ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','subtitleYn':bdKARiXhIcgsQTnYUpaHSxeFEjJqwV,'error_msg':'',}
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyu =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_uuid'].split('-')[0] 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyO =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_uuid'] 
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyM=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV 
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyC=bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetNoCache(1))
   if stype!='tvingtv':
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v2/media/stream/info' 
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams()
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':bdKARiXhIcgsQTnYUpaHSxeFEjJqyO,'deviceInfo':'PC','noCache':bdKARiXhIcgsQTnYUpaHSxeFEjJqyC,}
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyz.update(bdKARiXhIcgsQTnYUpaHSxeFEjJqyV)
    bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyW
    bdKARiXhIcgsQTnYUpaHSxeFEjJqkr=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.makeDefaultCookies()
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyz,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqkr)
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.status_code!=200:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqyo['error_msg']='First Step - {} error'.format(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.status_code)
     return bdKARiXhIcgsQTnYUpaHSxeFEjJqyo
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyr=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['result']['code']=='060':
     for bdKARiXhIcgsQTnYUpaHSxeFEjJqmy,bdKARiXhIcgsQTnYUpaHSxeFEjJqLu in bdKARiXhIcgsQTnYUpaHSxeFEjJqkm.items():
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqLu==sel_quality:
       bdKARiXhIcgsQTnYUpaHSxeFEjJqmL=bdKARiXhIcgsQTnYUpaHSxeFEjJqmy
    elif bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['result']['code']!='000':
     bdKARiXhIcgsQTnYUpaHSxeFEjJqyo['error_msg']=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['result']['message']
     return bdKARiXhIcgsQTnYUpaHSxeFEjJqyo
    else: 
     if not('stream' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']):return bdKARiXhIcgsQTnYUpaHSxeFEjJqyo
     bdKARiXhIcgsQTnYUpaHSxeFEjJqmN=[]
     for bdKARiXhIcgsQTnYUpaHSxeFEjJqmy,bdKARiXhIcgsQTnYUpaHSxeFEjJqLu in bdKARiXhIcgsQTnYUpaHSxeFEjJqkm.items():
      for bdKARiXhIcgsQTnYUpaHSxeFEjJqyv in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['stream']['quality']:
       if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['active']=='Y' and bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['code']==bdKARiXhIcgsQTnYUpaHSxeFEjJqmy:
        bdKARiXhIcgsQTnYUpaHSxeFEjJqmN.append({bdKARiXhIcgsQTnYUpaHSxeFEjJqkm.get(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['code']):bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['code']})
     bdKARiXhIcgsQTnYUpaHSxeFEjJqmL=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.CheckQuality(sel_quality,bdKARiXhIcgsQTnYUpaHSxeFEjJqmN)
     try:
      if optUHD==bdKARiXhIcgsQTnYUpaHSxeFEjJqwv and bdKARiXhIcgsQTnYUpaHSxeFEjJqmL=='stream50' and 'stream_support_info' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['content']['info']:
       if bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['content']['info']['stream_support_info']!=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG:
        if 'stream70' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['content']['info']['stream_support_info']:
         bdKARiXhIcgsQTnYUpaHSxeFEjJqmL='stream70'
         bdKARiXhIcgsQTnYUpaHSxeFEjJqyM =bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
     except:
      pass
     try:
      if optUHD==bdKARiXhIcgsQTnYUpaHSxeFEjJqwv and bdKARiXhIcgsQTnYUpaHSxeFEjJqmL=='stream50' and 'stream' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['content']['info']:
       if bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['content']['info']['stream']!=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG:
        for bdKARiXhIcgsQTnYUpaHSxeFEjJqyv in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['content']['info']['stream']:
         if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['code']=='stream70':
          bdKARiXhIcgsQTnYUpaHSxeFEjJqmL='stream70'
          bdKARiXhIcgsQTnYUpaHSxeFEjJqyM =bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
          break
     except:
      pass
   else:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqmL='stream40'
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyo['error_msg']='First Step - except error'
   return bdKARiXhIcgsQTnYUpaHSxeFEjJqyo
  bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(bdKARiXhIcgsQTnYUpaHSxeFEjJqmL)
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyC=bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetNoCache(1))
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v2a/media/stream/info'
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqyM==bdKARiXhIcgsQTnYUpaHSxeFEjJqwv:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams(uhd=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv)
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'mediaCode':mediacode,'noCache':bdKARiXhIcgsQTnYUpaHSxeFEjJqyC,'streamType':'hls','streamCode':bdKARiXhIcgsQTnYUpaHSxeFEjJqmL,'deviceId':bdKARiXhIcgsQTnYUpaHSxeFEjJqyu,'adReq':'none','wm':'Y','ad_device':'','uuid':bdKARiXhIcgsQTnYUpaHSxeFEjJqyO,'deviceInfo':'android_tv',}
   else:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams()
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':bdKARiXhIcgsQTnYUpaHSxeFEjJqmL,'deviceId':bdKARiXhIcgsQTnYUpaHSxeFEjJqyu,'uuid':bdKARiXhIcgsQTnYUpaHSxeFEjJqyO,'deviceInfo':'PC_Chrome','noCache':bdKARiXhIcgsQTnYUpaHSxeFEjJqyC,'wm':'Y'}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz.update(bdKARiXhIcgsQTnYUpaHSxeFEjJqyV)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyW
   bdKARiXhIcgsQTnYUpaHSxeFEjJqkr=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.makeDefaultCookies()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyz,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqkr,redirects=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyr=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['result']['code']!='000':
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyo['error_msg']=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['result']['message']
    return bdKARiXhIcgsQTnYUpaHSxeFEjJqyo
   bdKARiXhIcgsQTnYUpaHSxeFEjJqml=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['stream']
   if 'drm_license_assertion' in bdKARiXhIcgsQTnYUpaHSxeFEjJqml:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyo['drm_license']=bdKARiXhIcgsQTnYUpaHSxeFEjJqml['drm_license_assertion']
    if '4k_nondrm_url' in bdKARiXhIcgsQTnYUpaHSxeFEjJqml['broadcast']and bdKARiXhIcgsQTnYUpaHSxeFEjJqyM==bdKARiXhIcgsQTnYUpaHSxeFEjJqwv:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqmw =bdKARiXhIcgsQTnYUpaHSxeFEjJqml['broadcast']['4k_nondrm_url']
     bdKARiXhIcgsQTnYUpaHSxeFEjJqyo['drm_license']=''
    else:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqmw =bdKARiXhIcgsQTnYUpaHSxeFEjJqml['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in bdKARiXhIcgsQTnYUpaHSxeFEjJqml['broadcast']):return bdKARiXhIcgsQTnYUpaHSxeFEjJqyo
    bdKARiXhIcgsQTnYUpaHSxeFEjJqmw=bdKARiXhIcgsQTnYUpaHSxeFEjJqml['broadcast']['broad_url']
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyo['error_msg']='Second Step - except error'
   return bdKARiXhIcgsQTnYUpaHSxeFEjJqyo
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmB=bdKARiXhIcgsQTnYUpaHSxeFEjJqyC
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmw=bdKARiXhIcgsQTnYUpaHSxeFEjJqmw.split('|')[1]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmw,bdKARiXhIcgsQTnYUpaHSxeFEjJqmD,bdKARiXhIcgsQTnYUpaHSxeFEjJqmW=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.Decrypt_Url(bdKARiXhIcgsQTnYUpaHSxeFEjJqmw,mediacode,bdKARiXhIcgsQTnYUpaHSxeFEjJqmB)
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyo['streaming_url']=bdKARiXhIcgsQTnYUpaHSxeFEjJqmw
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyo['watermark'] =bdKARiXhIcgsQTnYUpaHSxeFEjJqmD
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyo['watermarkKey']=bdKARiXhIcgsQTnYUpaHSxeFEjJqmW
  if 'subtitles' in bdKARiXhIcgsQTnYUpaHSxeFEjJqml:
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqmP in bdKARiXhIcgsQTnYUpaHSxeFEjJqml.get('subtitles'):
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqmP.get('code')in['KO','KO_CC']:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqyo['subtitleYn']=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
     break
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqyo
 def Tving_Parse_mpd(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,stream_url):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=requests.get(url=stream_url)
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmf=bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.content.decode('utf-8')
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmu=0
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmG =ET.ElementTree(ET.fromstring(bdKARiXhIcgsQTnYUpaHSxeFEjJqmf))
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmV =bdKARiXhIcgsQTnYUpaHSxeFEjJqmG.getroot()
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmr=re.match(r'\{.*\}',bdKARiXhIcgsQTnYUpaHSxeFEjJqmV.tag)[0]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmv=bdKARiXhIcgsQTnYUpaHSxeFEjJqwz([node for _,node in ET.iterparse(io.StringIO(bdKARiXhIcgsQTnYUpaHSxeFEjJqmf),events=['start-ns'])])
  for bdKARiXhIcgsQTnYUpaHSxeFEjJqmy,bdKARiXhIcgsQTnYUpaHSxeFEjJqLW in bdKARiXhIcgsQTnYUpaHSxeFEjJqmv.items():
   ET.register_namespace(bdKARiXhIcgsQTnYUpaHSxeFEjJqmy,bdKARiXhIcgsQTnYUpaHSxeFEjJqLW)
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmt=bdKARiXhIcgsQTnYUpaHSxeFEjJqmV.find(bdKARiXhIcgsQTnYUpaHSxeFEjJqmr+'Period')
  for bdKARiXhIcgsQTnYUpaHSxeFEjJqmo in bdKARiXhIcgsQTnYUpaHSxeFEjJqmt.findall(bdKARiXhIcgsQTnYUpaHSxeFEjJqmr+'AdaptationSet'):
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqmo.attrib.get('mimeType')=='video/mp4':
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqmO in bdKARiXhIcgsQTnYUpaHSxeFEjJqmo.findall(bdKARiXhIcgsQTnYUpaHSxeFEjJqmr+'Representation'):
     bdKARiXhIcgsQTnYUpaHSxeFEjJqmM=bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(bdKARiXhIcgsQTnYUpaHSxeFEjJqmO.attrib.get('bandwidth'))
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqmu<bdKARiXhIcgsQTnYUpaHSxeFEjJqmM:bdKARiXhIcgsQTnYUpaHSxeFEjJqmu=bdKARiXhIcgsQTnYUpaHSxeFEjJqmM
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqmO in bdKARiXhIcgsQTnYUpaHSxeFEjJqmo.findall(bdKARiXhIcgsQTnYUpaHSxeFEjJqmr+'Representation'):
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqmu>bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(bdKARiXhIcgsQTnYUpaHSxeFEjJqmO.attrib.get('bandwidth')):
      bdKARiXhIcgsQTnYUpaHSxeFEjJqmo.remove(bdKARiXhIcgsQTnYUpaHSxeFEjJqmO)
   else:
    continue
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmC=ET.tostring(bdKARiXhIcgsQTnYUpaHSxeFEjJqmV).decode('utf-8')
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TextFile_Save(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV_STREAM_FILENAME,bdKARiXhIcgsQTnYUpaHSxeFEjJqmC)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
 def Tving_Parse_m3u8(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,stream_url):
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=requests.get(url=stream_url,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,stream=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmz=bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.content.decode('utf-8')
   if '#EXTM3U' not in bdKARiXhIcgsQTnYUpaHSxeFEjJqmz:
    return bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
   if '#EXT-X-STREAM-INF' not in bdKARiXhIcgsQTnYUpaHSxeFEjJqmz: 
    return bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLk=0
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqLy in bdKARiXhIcgsQTnYUpaHSxeFEjJqmz.splitlines():
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqLy.startswith('#EXT-X-STREAM-INF'):
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLm=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.MediaLine_Parse(bdKARiXhIcgsQTnYUpaHSxeFEjJqLy,'#EXT-X-STREAM-INF')
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqLk<bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(bdKARiXhIcgsQTnYUpaHSxeFEjJqLm.get('BANDWIDTH')):
      bdKARiXhIcgsQTnYUpaHSxeFEjJqLk=bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(bdKARiXhIcgsQTnYUpaHSxeFEjJqLm.get('BANDWIDTH'))
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLN=[]
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLl=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqLy in bdKARiXhIcgsQTnYUpaHSxeFEjJqmz.splitlines():
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqLl==bdKARiXhIcgsQTnYUpaHSxeFEjJqwv:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLl=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
     continue
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqLy.startswith('#EXT-X-STREAM-INF'):
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLm=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.MediaLine_Parse(bdKARiXhIcgsQTnYUpaHSxeFEjJqLy,'#EXT-X-STREAM-INF')
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqLk!=bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(bdKARiXhIcgsQTnYUpaHSxeFEjJqLm.get('BANDWIDTH')):
      bdKARiXhIcgsQTnYUpaHSxeFEjJqLl=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
      continue
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLN.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqLy)
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
   return bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  bdKARiXhIcgsQTnYUpaHSxeFEjJqLw='\n'.join(bdKARiXhIcgsQTnYUpaHSxeFEjJqLN)
  bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TextFile_Save(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV_STREAM_FILENAME,bdKARiXhIcgsQTnYUpaHSxeFEjJqLw)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
 def MediaLine_Parse(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,bdKARiXhIcgsQTnYUpaHSxeFEjJqLy,prefix):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqLm={}
  for bdKARiXhIcgsQTnYUpaHSxeFEjJqLB in bdKARiXhIcgsQTnYUpaHSxeFEjJqkN.split(bdKARiXhIcgsQTnYUpaHSxeFEjJqLy.replace(prefix+':',''))[1::2]:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLD,bdKARiXhIcgsQTnYUpaHSxeFEjJqLW=bdKARiXhIcgsQTnYUpaHSxeFEjJqLB.split('=',1)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLm[bdKARiXhIcgsQTnYUpaHSxeFEjJqLD.upper()]=bdKARiXhIcgsQTnYUpaHSxeFEjJqLW.replace('"','').strip()
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqLm
 def CheckQuality(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,sel_qt,bdKARiXhIcgsQTnYUpaHSxeFEjJqmN):
  for bdKARiXhIcgsQTnYUpaHSxeFEjJqLP in bdKARiXhIcgsQTnYUpaHSxeFEjJqmN:
   if sel_qt>=bdKARiXhIcgsQTnYUpaHSxeFEjJqBk(bdKARiXhIcgsQTnYUpaHSxeFEjJqLP)[0]:return bdKARiXhIcgsQTnYUpaHSxeFEjJqLP.get(bdKARiXhIcgsQTnYUpaHSxeFEjJqBk(bdKARiXhIcgsQTnYUpaHSxeFEjJqLP)[0])
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLf=bdKARiXhIcgsQTnYUpaHSxeFEjJqLP.get(bdKARiXhIcgsQTnYUpaHSxeFEjJqBk(bdKARiXhIcgsQTnYUpaHSxeFEjJqLP)[0])
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqLf
 def makeOocUrl(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,ooc_params):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=''
  for bdKARiXhIcgsQTnYUpaHSxeFEjJqmy,bdKARiXhIcgsQTnYUpaHSxeFEjJqLu in ooc_params.items():
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk+="%s=%s^"%(bdKARiXhIcgsQTnYUpaHSxeFEjJqmy,bdKARiXhIcgsQTnYUpaHSxeFEjJqLu)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqmk
 def GetLiveChannelList(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,stype,page_int):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyf=[]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v2/media/lives'
   if stype=='onair': 
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLV='CPCS0100,CPCS0400'
   else:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLV='CPCS0300'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'cacheType':'main','pageNo':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(page_int),'pageSize':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':bdKARiXhIcgsQTnYUpaHSxeFEjJqLV,}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz.update(bdKARiXhIcgsQTnYUpaHSxeFEjJqyV)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyW
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyz,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyr=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   if not('result' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']):return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLr=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['result']
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqyv in bdKARiXhIcgsQTnYUpaHSxeFEjJqLr:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLv=bdKARiXhIcgsQTnYUpaHSxeFEjJqLO=bdKARiXhIcgsQTnYUpaHSxeFEjJqLM=''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLt=bdKARiXhIcgsQTnYUpaHSxeFEjJqNr=''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLo=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['live_code']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLv =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['channel']['name']['ko']
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['episode']!=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLO =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['program']['name']['ko']
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLO =bdKARiXhIcgsQTnYUpaHSxeFEjJqLO+', '+bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['episode']['frequency'])+'회'
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLM=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['episode']['synopsis']['ko']
    else:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLO =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['program']['name']['ko']
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLM=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['program']['synopsis']['ko']
    try: 
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =''
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =''
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=''
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNy =''
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNm =''
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNL =''
     for bdKARiXhIcgsQTnYUpaHSxeFEjJqNl in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['program']['image']:
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP0900':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
      elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP1800':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
      elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP2000':bdKARiXhIcgsQTnYUpaHSxeFEjJqNy =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
      elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP1900':bdKARiXhIcgsQTnYUpaHSxeFEjJqNm =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
      elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP0200':bdKARiXhIcgsQTnYUpaHSxeFEjJqNL =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
      elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP0500':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
      elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP0800':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqLC=='':
      for bdKARiXhIcgsQTnYUpaHSxeFEjJqNl in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['channel']['image']:
       if bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIC0400':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
       elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIC1400':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
       elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIC1900':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
    except:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqwG
    try:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNw =[]
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNB=[]
     bdKARiXhIcgsQTnYUpaHSxeFEjJqND =[]
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNW=''
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNP=''
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNf=''
     for bdKARiXhIcgsQTnYUpaHSxeFEjJqNu in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('schedule').get('program').get('actor'):
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqNu!='' and bdKARiXhIcgsQTnYUpaHSxeFEjJqNu!=u'없음':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNu)
     for bdKARiXhIcgsQTnYUpaHSxeFEjJqNG in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('schedule').get('program').get('director'):
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqNG!='' and bdKARiXhIcgsQTnYUpaHSxeFEjJqNG!='-' and bdKARiXhIcgsQTnYUpaHSxeFEjJqNG!=u'없음':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNG)
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('schedule').get('program').get('category1_name').get('ko')!='':
      bdKARiXhIcgsQTnYUpaHSxeFEjJqND.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['program']['category1_name']['ko'])
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('schedule').get('program').get('category2_name').get('ko')!='':
      bdKARiXhIcgsQTnYUpaHSxeFEjJqND.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['program']['category2_name']['ko'])
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('schedule').get('program').get('product_year'):bdKARiXhIcgsQTnYUpaHSxeFEjJqNW=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['program']['product_year']
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('schedule').get('program').get('grade_code') :bdKARiXhIcgsQTnYUpaHSxeFEjJqNP= bdKARiXhIcgsQTnYUpaHSxeFEjJqkL.get(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['program']['grade_code'])
     if 'broad_dt' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('schedule').get('program'):
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNV =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('schedule').get('program').get('broad_dt')
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNf='%s-%s-%s'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[:4],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[4:6],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[6:])
    except:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqwG
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLt=bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['broadcast_start_time'])[8:12]
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNr =bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['schedule']['broadcast_end_time'])[8:12]
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNv={'channel':bdKARiXhIcgsQTnYUpaHSxeFEjJqLv,'title':bdKARiXhIcgsQTnYUpaHSxeFEjJqLO,'mediacode':bdKARiXhIcgsQTnYUpaHSxeFEjJqLo,'thumbnail':{'poster':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz,'thumb':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC,'clearlogo':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk,'icon':bdKARiXhIcgsQTnYUpaHSxeFEjJqNy,'fanart':bdKARiXhIcgsQTnYUpaHSxeFEjJqNL},'synopsis':bdKARiXhIcgsQTnYUpaHSxeFEjJqLM,'channelepg':' [%s:%s ~ %s:%s]'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqLt[0:2],bdKARiXhIcgsQTnYUpaHSxeFEjJqLt[2:],bdKARiXhIcgsQTnYUpaHSxeFEjJqNr[0:2],bdKARiXhIcgsQTnYUpaHSxeFEjJqNr[2:]),'cast':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw,'director':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB,'info_genre':bdKARiXhIcgsQTnYUpaHSxeFEjJqND,'year':bdKARiXhIcgsQTnYUpaHSxeFEjJqNW,'mpaa':bdKARiXhIcgsQTnYUpaHSxeFEjJqNP,'premiered':bdKARiXhIcgsQTnYUpaHSxeFEjJqNf}
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyf.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNv)
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['has_more']=='Y':
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
 def GetProgramList(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,genre,orderby,page_int,genreCode='all'):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyf=[]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  try:
   if genre=='PARAMOUNT':
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v2/media/paramount/episodes'
   else:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v2/media/episodes'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'cacheType':'main','pageSize':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(page_int),}
   if genre not in['all','PARAMOUNT']:bdKARiXhIcgsQTnYUpaHSxeFEjJqyV['categoryCode']=genre
   if genreCode!='all' :bdKARiXhIcgsQTnYUpaHSxeFEjJqyV['genreCode'] =genreCode 
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz.update(bdKARiXhIcgsQTnYUpaHSxeFEjJqyV)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyW
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyz,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyr=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   if not('result' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']):return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLr=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['result']
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqyv in bdKARiXhIcgsQTnYUpaHSxeFEjJqLr:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNt=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['program']['code']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLO =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['program']['name']['ko']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNP =bdKARiXhIcgsQTnYUpaHSxeFEjJqkL.get(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['program'].get('grade_code'))
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNy =''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNm =''
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqNl in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['program']['image']:
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP0900':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP0200':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP1800':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP2000':bdKARiXhIcgsQTnYUpaHSxeFEjJqNy =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP1900':bdKARiXhIcgsQTnYUpaHSxeFEjJqNm =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLM =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['program']['synopsis']['ko']
    try:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNo=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['channel']['name']['ko']
    except:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNo=''
    try:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNw =[]
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNB=[]
     bdKARiXhIcgsQTnYUpaHSxeFEjJqND =[]
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNW =''
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNf=''
     for bdKARiXhIcgsQTnYUpaHSxeFEjJqNu in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('program').get('actor'):
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqNu!='' and bdKARiXhIcgsQTnYUpaHSxeFEjJqNu!='-' and bdKARiXhIcgsQTnYUpaHSxeFEjJqNu!=u'없음':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNu)
     for bdKARiXhIcgsQTnYUpaHSxeFEjJqNG in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('program').get('director'):
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqNG!='' and bdKARiXhIcgsQTnYUpaHSxeFEjJqNG!='-' and bdKARiXhIcgsQTnYUpaHSxeFEjJqNG!=u'없음':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNG)
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('program').get('category1_name').get('ko')!='':
      bdKARiXhIcgsQTnYUpaHSxeFEjJqND.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['program']['category1_name']['ko'])
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('program').get('category2_name').get('ko')!='':
      bdKARiXhIcgsQTnYUpaHSxeFEjJqND.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['program']['category2_name']['ko'])
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('program').get('product_year'):bdKARiXhIcgsQTnYUpaHSxeFEjJqNW=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['program']['product_year']
     if 'broad_dt' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('program'):
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNV =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('program').get('broad_dt')
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNf='%s-%s-%s'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[:4],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[4:6],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[6:])
    except:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqwG
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNv={'program':bdKARiXhIcgsQTnYUpaHSxeFEjJqNt,'title':bdKARiXhIcgsQTnYUpaHSxeFEjJqLO,'thumbnail':{'poster':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz,'thumb':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC,'clearlogo':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk,'icon':bdKARiXhIcgsQTnYUpaHSxeFEjJqNy,'banner':bdKARiXhIcgsQTnYUpaHSxeFEjJqNm,'fanart':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC},'synopsis':bdKARiXhIcgsQTnYUpaHSxeFEjJqLM,'channel':bdKARiXhIcgsQTnYUpaHSxeFEjJqNo,'cast':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw,'director':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB,'info_genre':bdKARiXhIcgsQTnYUpaHSxeFEjJqND,'year':bdKARiXhIcgsQTnYUpaHSxeFEjJqNW,'premiered':bdKARiXhIcgsQTnYUpaHSxeFEjJqNf,'mpaa':bdKARiXhIcgsQTnYUpaHSxeFEjJqNP}
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyf.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNv)
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['has_more']=='Y':bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
 def Get_UHD_ProgramList(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,page_int):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyf=[]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v2/operator/highlights'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams(uhd=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(page_int),'pocType':'APP_X_TVING_4.0.0',}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz.update(bdKARiXhIcgsQTnYUpaHSxeFEjJqyV)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyW
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyz,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyr=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   if not('result' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']):return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLr=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['result']
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqyv in bdKARiXhIcgsQTnYUpaHSxeFEjJqLr:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNO=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['content']['program']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNM =bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['code']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLO =bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['name']['ko'].strip()
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNP =bdKARiXhIcgsQTnYUpaHSxeFEjJqkL.get(bdKARiXhIcgsQTnYUpaHSxeFEjJqNO.get('grade_code'))
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLM =bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['synopsis']['ko']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNo =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['content']['channel']['name']['ko']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNW =bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['product_year']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNy =''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNm =''
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqNl in bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['image']:
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP0900':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP0200':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP1800':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP2000':bdKARiXhIcgsQTnYUpaHSxeFEjJqNy =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP1900':bdKARiXhIcgsQTnYUpaHSxeFEjJqNm =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqND =[]
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNw =[]
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNB=[]
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNf =''
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqNO.get('category1_name').get('ko')!='':
     bdKARiXhIcgsQTnYUpaHSxeFEjJqND.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['category1_name']['ko'])
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqNO.get('category2_name').get('ko')!='':
     bdKARiXhIcgsQTnYUpaHSxeFEjJqND.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['category2_name']['ko'])
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqNu in bdKARiXhIcgsQTnYUpaHSxeFEjJqNO.get('actor'):
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqNu!='' and bdKARiXhIcgsQTnYUpaHSxeFEjJqNu!='-' and bdKARiXhIcgsQTnYUpaHSxeFEjJqNu!=u'없음':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNu)
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqNG in bdKARiXhIcgsQTnYUpaHSxeFEjJqNO.get('director'):
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqNG!='' and bdKARiXhIcgsQTnYUpaHSxeFEjJqNG!='-' and bdKARiXhIcgsQTnYUpaHSxeFEjJqNG!=u'없음':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNG)
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqNO.get('broad_dt')not in[bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,'']:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNV =bdKARiXhIcgsQTnYUpaHSxeFEjJqNO.get('broad_dt')
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNf='%s-%s-%s'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[:4],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[4:6],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[6:])
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNv={'program':bdKARiXhIcgsQTnYUpaHSxeFEjJqNM,'title':bdKARiXhIcgsQTnYUpaHSxeFEjJqLO,'mpaa':bdKARiXhIcgsQTnYUpaHSxeFEjJqNP,'thumbnail':{'poster':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz,'thumb':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC,'clearlogo':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk,'icon':bdKARiXhIcgsQTnYUpaHSxeFEjJqNy,'banner':bdKARiXhIcgsQTnYUpaHSxeFEjJqNm,'fanart':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC},'channel':bdKARiXhIcgsQTnYUpaHSxeFEjJqNo,'synopsis':bdKARiXhIcgsQTnYUpaHSxeFEjJqLM,'year':bdKARiXhIcgsQTnYUpaHSxeFEjJqNW,'info_genre':bdKARiXhIcgsQTnYUpaHSxeFEjJqND,'cast':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw,'director':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB,'premiered':bdKARiXhIcgsQTnYUpaHSxeFEjJqNf,}
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyf.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNv)
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
 def Get_Origianl_ProgramList(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,page_int):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyf=[]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v2/media/band/originals'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'pageSize':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(page_int),}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz.update(bdKARiXhIcgsQTnYUpaHSxeFEjJqyV)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyW
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyz,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyr=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   if not('contents' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']):return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLr=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['contents']
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqyv in bdKARiXhIcgsQTnYUpaHSxeFEjJqLr:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNt=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['vod_code']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLO =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['vod_name']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['image']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNv={'program':bdKARiXhIcgsQTnYUpaHSxeFEjJqNt,'title':bdKARiXhIcgsQTnYUpaHSxeFEjJqLO,'thumbnail':{'poster':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz,'thumb':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz}}
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyf.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNv)
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['has_more']=='Y':bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
 def GetEpisodeList(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,program_code,page_int,orderby='desc'):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyf=[]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v2/media/frequency/program/'+program_code
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz.update(bdKARiXhIcgsQTnYUpaHSxeFEjJqyV)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyW
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyz,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyr=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   if not('result' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']):return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLr=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['result']
   bdKARiXhIcgsQTnYUpaHSxeFEjJqNC=bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['total_count'])
   bdKARiXhIcgsQTnYUpaHSxeFEjJqNz =bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(bdKARiXhIcgsQTnYUpaHSxeFEjJqNC//(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlk =(bdKARiXhIcgsQTnYUpaHSxeFEjJqNC-1)-((page_int-1)*bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.EPISODE_LIMIT)
   else:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlk =(page_int-1)*bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.EPISODE_LIMIT
   for i in bdKARiXhIcgsQTnYUpaHSxeFEjJqwo(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.EPISODE_LIMIT):
    if orderby=='desc':
     bdKARiXhIcgsQTnYUpaHSxeFEjJqly=bdKARiXhIcgsQTnYUpaHSxeFEjJqlk-i
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqly<0:break
    else:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqly=bdKARiXhIcgsQTnYUpaHSxeFEjJqlk+i
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqly>=bdKARiXhIcgsQTnYUpaHSxeFEjJqNC:break
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlm=bdKARiXhIcgsQTnYUpaHSxeFEjJqLr[bdKARiXhIcgsQTnYUpaHSxeFEjJqly]['episode']['code']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLO =bdKARiXhIcgsQTnYUpaHSxeFEjJqLr[bdKARiXhIcgsQTnYUpaHSxeFEjJqly]['vod_name']['ko']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlL =''
    try:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNV=bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqLr[bdKARiXhIcgsQTnYUpaHSxeFEjJqly]['episode']['broadcast_date'])
     bdKARiXhIcgsQTnYUpaHSxeFEjJqlL='%s-%s-%s'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[:4],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[4:6],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[6:])
    except:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqwG
    try:
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqLr[bdKARiXhIcgsQTnYUpaHSxeFEjJqly]['episode']['pip_cliptype']=='C012':
      bdKARiXhIcgsQTnYUpaHSxeFEjJqlL+=' - Quick VOD'
    except:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqwG
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLM =bdKARiXhIcgsQTnYUpaHSxeFEjJqLr[bdKARiXhIcgsQTnYUpaHSxeFEjJqly]['episode']['synopsis']['ko']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNy =''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNm =''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNL =''
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqNl in bdKARiXhIcgsQTnYUpaHSxeFEjJqLr[bdKARiXhIcgsQTnYUpaHSxeFEjJqly]['program']['image']:
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP0900':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP1800':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP2000':bdKARiXhIcgsQTnYUpaHSxeFEjJqNy =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP1900':bdKARiXhIcgsQTnYUpaHSxeFEjJqNm =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIP0200':bdKARiXhIcgsQTnYUpaHSxeFEjJqNL =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqNl in bdKARiXhIcgsQTnYUpaHSxeFEjJqLr[bdKARiXhIcgsQTnYUpaHSxeFEjJqly]['episode']['image']:
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIE0400':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
    try:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqlN=bdKARiXhIcgsQTnYUpaHSxeFEjJqlB=bdKARiXhIcgsQTnYUpaHSxeFEjJqlD=''
     bdKARiXhIcgsQTnYUpaHSxeFEjJqlw=0
     bdKARiXhIcgsQTnYUpaHSxeFEjJqlN =bdKARiXhIcgsQTnYUpaHSxeFEjJqLr[bdKARiXhIcgsQTnYUpaHSxeFEjJqly]['program']['name']['ko']
     bdKARiXhIcgsQTnYUpaHSxeFEjJqlB =bdKARiXhIcgsQTnYUpaHSxeFEjJqlL
     bdKARiXhIcgsQTnYUpaHSxeFEjJqlD =bdKARiXhIcgsQTnYUpaHSxeFEjJqLr[bdKARiXhIcgsQTnYUpaHSxeFEjJqly]['channel']['name']['ko']
     if 'frequency' in bdKARiXhIcgsQTnYUpaHSxeFEjJqLr[bdKARiXhIcgsQTnYUpaHSxeFEjJqly]['episode']:bdKARiXhIcgsQTnYUpaHSxeFEjJqlw=bdKARiXhIcgsQTnYUpaHSxeFEjJqLr[bdKARiXhIcgsQTnYUpaHSxeFEjJqly]['episode']['frequency']
    except:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqwG
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNv={'episode':bdKARiXhIcgsQTnYUpaHSxeFEjJqlm,'title':bdKARiXhIcgsQTnYUpaHSxeFEjJqLO,'subtitle':bdKARiXhIcgsQTnYUpaHSxeFEjJqlL,'thumbnail':{'poster':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz,'thumb':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC,'clearlogo':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk,'icon':bdKARiXhIcgsQTnYUpaHSxeFEjJqNy,'banner':bdKARiXhIcgsQTnYUpaHSxeFEjJqNm,'fanart':bdKARiXhIcgsQTnYUpaHSxeFEjJqNL},'synopsis':bdKARiXhIcgsQTnYUpaHSxeFEjJqLM,'info_title':bdKARiXhIcgsQTnYUpaHSxeFEjJqlN,'aired':bdKARiXhIcgsQTnYUpaHSxeFEjJqlB,'studio':bdKARiXhIcgsQTnYUpaHSxeFEjJqlD,'frequency':bdKARiXhIcgsQTnYUpaHSxeFEjJqlw}
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyf.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNv)
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqNz>page_int:bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG,bdKARiXhIcgsQTnYUpaHSxeFEjJqNz
 def GetMovieList(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,genre,orderby,page_int):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyf=[]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  try:
   if genre=='PARAMOUNT':
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v2/media/paramount/movies'
   else:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v2/media/movies'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'pageSize':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:bdKARiXhIcgsQTnYUpaHSxeFEjJqyV['categoryCode']=genre
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV['productPackageCode']=','.join(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.MOVIE_LITE)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz.update(bdKARiXhIcgsQTnYUpaHSxeFEjJqyV)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyW
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyz,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyr=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   if not('result' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']):return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLr=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['result']
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqyv in bdKARiXhIcgsQTnYUpaHSxeFEjJqLr:
    if 'release_date' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('movie'):
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNW=bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('movie').get('release_date'))[:4]
    else:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNW=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlW =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['movie']['code']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLO =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['movie']['name']['ko'].strip()
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqNW not in[bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,'0','']:bdKARiXhIcgsQTnYUpaHSxeFEjJqLO+=u' (%s)'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqNW)
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLz=''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=''
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqNl in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['movie']['image']:
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIM2100':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIM0400':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIM1800':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLM =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['movie']['story']['ko']
    try:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqlN =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['movie']['name']['ko'].strip()
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNP =bdKARiXhIcgsQTnYUpaHSxeFEjJqkL.get(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('grade_code'))
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNw=[]
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNB=[]
     bdKARiXhIcgsQTnYUpaHSxeFEjJqND=[]
     bdKARiXhIcgsQTnYUpaHSxeFEjJqlP=0
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNf=''
     bdKARiXhIcgsQTnYUpaHSxeFEjJqlD =''
     for bdKARiXhIcgsQTnYUpaHSxeFEjJqNu in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('movie').get('actor'):
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqNu!='':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNu)
     for bdKARiXhIcgsQTnYUpaHSxeFEjJqNG in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('movie').get('director'):
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqNG!='':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNG)
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('movie').get('category1_name').get('ko')!='':
      bdKARiXhIcgsQTnYUpaHSxeFEjJqND.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['movie']['category1_name']['ko'])
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('movie').get('category2_name').get('ko')!='':
      bdKARiXhIcgsQTnYUpaHSxeFEjJqND.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['movie']['category2_name']['ko'])
     if 'duration' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('movie'):bdKARiXhIcgsQTnYUpaHSxeFEjJqlP=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('movie').get('duration')
     if 'release_date' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('movie'):
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNV=bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('movie').get('release_date'))
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqNV!='0':bdKARiXhIcgsQTnYUpaHSxeFEjJqNf='%s-%s-%s'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[:4],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[4:6],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[6:])
     if 'production' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('movie'):bdKARiXhIcgsQTnYUpaHSxeFEjJqlD=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('movie').get('production')
    except:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqwG
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNv={'moviecode':bdKARiXhIcgsQTnYUpaHSxeFEjJqlW,'title':bdKARiXhIcgsQTnYUpaHSxeFEjJqLO,'thumbnail':{'poster':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz,'thumb':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC,'clearlogo':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk,'fanart':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC},'synopsis':bdKARiXhIcgsQTnYUpaHSxeFEjJqLM,'info_title':bdKARiXhIcgsQTnYUpaHSxeFEjJqlN,'year':bdKARiXhIcgsQTnYUpaHSxeFEjJqNW,'cast':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw,'director':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB,'info_genre':bdKARiXhIcgsQTnYUpaHSxeFEjJqND,'duration':bdKARiXhIcgsQTnYUpaHSxeFEjJqlP,'premiered':bdKARiXhIcgsQTnYUpaHSxeFEjJqNf,'studio':bdKARiXhIcgsQTnYUpaHSxeFEjJqlD,'mpaa':bdKARiXhIcgsQTnYUpaHSxeFEjJqNP}
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlf=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqlu in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['billing_package_id']:
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqlu in bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.MOVIE_LITE:
      bdKARiXhIcgsQTnYUpaHSxeFEjJqlf=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
      break
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqlf==bdKARiXhIcgsQTnYUpaHSxeFEjJqwV: 
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNv['title']=bdKARiXhIcgsQTnYUpaHSxeFEjJqNv['title']+' [개별구매]'
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyf.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNv)
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['has_more']=='Y':bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
 def Get_UHD_MovieList(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,page_int):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyf=[]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v2/operator/highlights'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams(uhd=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(page_int),'pocType':'APP_X_TVING_4.0.0',}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz.update(bdKARiXhIcgsQTnYUpaHSxeFEjJqyV)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyW
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyz,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyr=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   if not('result' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']):return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLr=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['result']
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqyv in bdKARiXhIcgsQTnYUpaHSxeFEjJqLr:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNO=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['content']['movie']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNM =bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['code']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLO =bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['name']['ko'].strip()
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlN =bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['name']['ko'].strip()
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNW =bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['product_year']
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqNW:bdKARiXhIcgsQTnYUpaHSxeFEjJqLO+=u' (%s)'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['product_year'])
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLM =bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['story']['ko']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlP =bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['duration']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNP =bdKARiXhIcgsQTnYUpaHSxeFEjJqkL.get(bdKARiXhIcgsQTnYUpaHSxeFEjJqNO.get('grade_code'))
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlD =bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['production']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLz=''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=''
    bdKARiXhIcgsQTnYUpaHSxeFEjJqND =[]
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNw =[]
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNB=[]
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNf =''
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqNl in bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['image']:
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIM2100':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIM0400':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
     elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['code']=='CAIM1800':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl['url']
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['release_date']not in[bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,0]:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNV=bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['release_date'])
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqNV!='0':bdKARiXhIcgsQTnYUpaHSxeFEjJqNf='%s-%s-%s'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[:4],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[4:6],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[6:])
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqNO.get('category1_name').get('ko')!='':
     bdKARiXhIcgsQTnYUpaHSxeFEjJqND.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['category1_name']['ko'])
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqNO.get('category2_name').get('ko')!='':
     bdKARiXhIcgsQTnYUpaHSxeFEjJqND.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNO['category2_name']['ko'])
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqNu in bdKARiXhIcgsQTnYUpaHSxeFEjJqNO.get('actor'):
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqNu!='':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNu)
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqNG in bdKARiXhIcgsQTnYUpaHSxeFEjJqNO.get('director'):
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqNG!='':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNG)
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNv={'moviecode':bdKARiXhIcgsQTnYUpaHSxeFEjJqNM,'title':bdKARiXhIcgsQTnYUpaHSxeFEjJqLO,'thumbnail':{'poster':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz,'thumb':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC,'clearlogo':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk,'fanart':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC},'year':bdKARiXhIcgsQTnYUpaHSxeFEjJqNW,'info_title':bdKARiXhIcgsQTnYUpaHSxeFEjJqlN,'synopsis':bdKARiXhIcgsQTnYUpaHSxeFEjJqLM,'mpaa':bdKARiXhIcgsQTnYUpaHSxeFEjJqNP,'duration':bdKARiXhIcgsQTnYUpaHSxeFEjJqlP,'premiered':bdKARiXhIcgsQTnYUpaHSxeFEjJqNf,'studio':bdKARiXhIcgsQTnYUpaHSxeFEjJqlD,'info_genre':bdKARiXhIcgsQTnYUpaHSxeFEjJqND,'cast':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw,'director':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB,}
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyf.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNv)
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
 def GetMovieGenre(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyf=[]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v2/media/movie/curations'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz.update(bdKARiXhIcgsQTnYUpaHSxeFEjJqyV)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyW
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyz,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyr=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   if not('result' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']):return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLr=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['result']
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqyv in bdKARiXhIcgsQTnYUpaHSxeFEjJqLr:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlG =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['curation_code']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlV =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['curation_name']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqNv={'curation_code':bdKARiXhIcgsQTnYUpaHSxeFEjJqlG,'curation_name':bdKARiXhIcgsQTnYUpaHSxeFEjJqlV}
    bdKARiXhIcgsQTnYUpaHSxeFEjJqyf.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNv)
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
 def GetSearchList(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,search_key,page_int,stype):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqlr=[]
  bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/search/getSearch.jsp'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(page_int),'pageSize':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.SCREENCODE,'os':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.OSCODE,'network':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.SEARCH_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyW
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyV,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyr=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   if stype=='vod':
    if not('programRsb' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr):return bdKARiXhIcgsQTnYUpaHSxeFEjJqlr,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlv=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['programRsb']['dataList']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlt =bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['programRsb']['count'])
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqyv in bdKARiXhIcgsQTnYUpaHSxeFEjJqlv:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNt=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['mast_cd']
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLO =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['mast_nm']
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['web_url4']
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['web_url']
     try:
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNw =[]
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNB=[]
      bdKARiXhIcgsQTnYUpaHSxeFEjJqND =[]
      bdKARiXhIcgsQTnYUpaHSxeFEjJqlP =0
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNP =''
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNW =''
      bdKARiXhIcgsQTnYUpaHSxeFEjJqlB =''
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('actor') !='' and bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('actor') !='-':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('actor').split(',')
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('director')!='' and bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('director')!='-':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('director').split(',')
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('cate_nm')!='' and bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('cate_nm')!='-':bdKARiXhIcgsQTnYUpaHSxeFEjJqND =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('cate_nm').split('/')
      if 'targetage' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv:bdKARiXhIcgsQTnYUpaHSxeFEjJqNP=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('targetage')
      if 'broad_dt' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv:
       bdKARiXhIcgsQTnYUpaHSxeFEjJqNV=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('broad_dt')
       bdKARiXhIcgsQTnYUpaHSxeFEjJqlB='%s-%s-%s'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[:4],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[4:6],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[6:])
       bdKARiXhIcgsQTnYUpaHSxeFEjJqNW =bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[:4]
     except:
      bdKARiXhIcgsQTnYUpaHSxeFEjJqwG
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNv={'program':bdKARiXhIcgsQTnYUpaHSxeFEjJqNt,'title':bdKARiXhIcgsQTnYUpaHSxeFEjJqLO,'thumbnail':{'poster':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz,'thumb':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC,'fanart':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC},'synopsis':'','cast':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw,'director':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB,'info_genre':bdKARiXhIcgsQTnYUpaHSxeFEjJqND,'duration':bdKARiXhIcgsQTnYUpaHSxeFEjJqlP,'mpaa':bdKARiXhIcgsQTnYUpaHSxeFEjJqNP,'year':bdKARiXhIcgsQTnYUpaHSxeFEjJqNW,'aired':bdKARiXhIcgsQTnYUpaHSxeFEjJqlB}
     bdKARiXhIcgsQTnYUpaHSxeFEjJqlr.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNv)
   else:
    if not('vodMVRsb' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr):return bdKARiXhIcgsQTnYUpaHSxeFEjJqlr,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlo=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['vodMVRsb']['dataList']
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlt =bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['vodMVRsb']['count'])
    for bdKARiXhIcgsQTnYUpaHSxeFEjJqyv in bdKARiXhIcgsQTnYUpaHSxeFEjJqlo:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNt=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['mast_cd']
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLO =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['mast_nm'].strip()
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['web_url']
     bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqLz
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=''
     try:
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNw =[]
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNB=[]
      bdKARiXhIcgsQTnYUpaHSxeFEjJqND =[]
      bdKARiXhIcgsQTnYUpaHSxeFEjJqlP =0
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNP =''
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNW =''
      bdKARiXhIcgsQTnYUpaHSxeFEjJqlB =''
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('actor') !='' and bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('actor') !='-':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('actor').split(',')
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('director')!='' and bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('director')!='-':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('director').split(',')
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('cate_nm')!='' and bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('cate_nm')!='-':bdKARiXhIcgsQTnYUpaHSxeFEjJqND =bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('cate_nm').split('/')
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('runtime_sec')!='':bdKARiXhIcgsQTnYUpaHSxeFEjJqlP=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('runtime_sec')
      if 'grade_nm' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv:bdKARiXhIcgsQTnYUpaHSxeFEjJqNP=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('grade_nm')
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNV=bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('broad_dt')
      if data_str!='':
       bdKARiXhIcgsQTnYUpaHSxeFEjJqlB='%s-%s-%s'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[:4],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[4:6],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[6:])
       bdKARiXhIcgsQTnYUpaHSxeFEjJqNW =bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[:4]
     except:
      bdKARiXhIcgsQTnYUpaHSxeFEjJqwG
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNv={'movie':bdKARiXhIcgsQTnYUpaHSxeFEjJqNt,'title':bdKARiXhIcgsQTnYUpaHSxeFEjJqLO,'thumbnail':{'poster':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz,'thumb':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC,'fanart':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC,'clearlogo':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk},'synopsis':'','cast':bdKARiXhIcgsQTnYUpaHSxeFEjJqNw,'director':bdKARiXhIcgsQTnYUpaHSxeFEjJqNB,'info_genre':bdKARiXhIcgsQTnYUpaHSxeFEjJqND,'duration':bdKARiXhIcgsQTnYUpaHSxeFEjJqlP,'mpaa':bdKARiXhIcgsQTnYUpaHSxeFEjJqNP,'year':bdKARiXhIcgsQTnYUpaHSxeFEjJqNW,'aired':bdKARiXhIcgsQTnYUpaHSxeFEjJqlB}
     bdKARiXhIcgsQTnYUpaHSxeFEjJqlf=bdKARiXhIcgsQTnYUpaHSxeFEjJqwV
     for bdKARiXhIcgsQTnYUpaHSxeFEjJqlu in bdKARiXhIcgsQTnYUpaHSxeFEjJqyv['bill']:
      if bdKARiXhIcgsQTnYUpaHSxeFEjJqlu in bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.MOVIE_LITE:
       bdKARiXhIcgsQTnYUpaHSxeFEjJqlf=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
       break
     if bdKARiXhIcgsQTnYUpaHSxeFEjJqlf==bdKARiXhIcgsQTnYUpaHSxeFEjJqwV: 
      bdKARiXhIcgsQTnYUpaHSxeFEjJqNv['title']=bdKARiXhIcgsQTnYUpaHSxeFEjJqNv['title']+' [개별구매]'
     bdKARiXhIcgsQTnYUpaHSxeFEjJqlr.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNv)
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqlt>(page_int*bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.SEARCH_LIMIT):bdKARiXhIcgsQTnYUpaHSxeFEjJqLG=bdKARiXhIcgsQTnYUpaHSxeFEjJqwv
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqlr,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
 def GetBookmarkInfo(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,videoid,vidtype):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqlO={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+'/v2/media/program/'+videoid
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'pageNo':'1','pageSize':'10','order':'name',}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz.update(bdKARiXhIcgsQTnYUpaHSxeFEjJqyV)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyz,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlM=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   if not('body' in bdKARiXhIcgsQTnYUpaHSxeFEjJqlM):return{}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlC=bdKARiXhIcgsQTnYUpaHSxeFEjJqlM['body']
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLO=bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('name').get('ko').strip()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['title'] =bdKARiXhIcgsQTnYUpaHSxeFEjJqLO
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['title']=bdKARiXhIcgsQTnYUpaHSxeFEjJqLO
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['mpaa'] =bdKARiXhIcgsQTnYUpaHSxeFEjJqkL.get(bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('grade_code'))
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['plot'] =bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('synopsis').get('ko')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['year'] =bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('product_year')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['cast'] =bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('actor')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['director']=bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('director')
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('category1_name').get('ko')!='':
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['genre'].append(bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('category1_name').get('ko'))
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('category2_name').get('ko')!='':
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['genre'].append(bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('category2_name').get('ko'))
   bdKARiXhIcgsQTnYUpaHSxeFEjJqNV=bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('broad_dt'))
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqNV!='0':bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[:4],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[4:6],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[6:])
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =''
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =''
   bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=''
   bdKARiXhIcgsQTnYUpaHSxeFEjJqNy =''
   bdKARiXhIcgsQTnYUpaHSxeFEjJqNm =''
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqNl in bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('image'):
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('code')=='CAIP0900':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('url')
    elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('code')=='CAIP0200':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('url')
    elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('code')=='CAIP1800':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('url')
    elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('code')=='CAIP2000':bdKARiXhIcgsQTnYUpaHSxeFEjJqNy =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('url')
    elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('code')=='CAIP1900':bdKARiXhIcgsQTnYUpaHSxeFEjJqNm =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('url')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['thumbnail']['poster']=bdKARiXhIcgsQTnYUpaHSxeFEjJqLz
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['thumbnail']['thumb']=bdKARiXhIcgsQTnYUpaHSxeFEjJqLC
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['thumbnail']['clearlogo']=bdKARiXhIcgsQTnYUpaHSxeFEjJqNk
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['thumbnail']['icon']=bdKARiXhIcgsQTnYUpaHSxeFEjJqNy
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['thumbnail']['banner']=bdKARiXhIcgsQTnYUpaHSxeFEjJqNm
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['thumbnail']['fanart']=bdKARiXhIcgsQTnYUpaHSxeFEjJqLC
  else:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+'/v2a/media/stream/info'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_uuid'].split('-')[0],'uuid':bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetNoCache(1)),'wm':'Y',}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz.update(bdKARiXhIcgsQTnYUpaHSxeFEjJqyV)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyz,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlM=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   if not('content' in bdKARiXhIcgsQTnYUpaHSxeFEjJqlM['body']):return{}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlC=bdKARiXhIcgsQTnYUpaHSxeFEjJqlM['body']['content']['info']['movie']
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLO =bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('name').get('ko').strip()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['title']=bdKARiXhIcgsQTnYUpaHSxeFEjJqLO
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLO +=u' (%s)'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('product_year'))
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['title'] =bdKARiXhIcgsQTnYUpaHSxeFEjJqLO
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['mpaa'] =bdKARiXhIcgsQTnYUpaHSxeFEjJqkL.get(bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('grade_code'))
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['plot'] =bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('story').get('ko')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['year'] =bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('product_year')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['studio'] =bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('production')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['duration']=bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('duration')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['cast'] =bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('actor')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['director']=bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('director')
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('category1_name').get('ko')!='':
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['genre'].append(bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('category1_name').get('ko'))
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('category2_name').get('ko')!='':
    bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['genre'].append(bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('category2_name').get('ko'))
   bdKARiXhIcgsQTnYUpaHSxeFEjJqNV=bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('release_date'))
   if bdKARiXhIcgsQTnYUpaHSxeFEjJqNV!='0':bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[:4],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[4:6],bdKARiXhIcgsQTnYUpaHSxeFEjJqNV[6:])
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLz=''
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =''
   bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=''
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqNl in bdKARiXhIcgsQTnYUpaHSxeFEjJqlC.get('image'):
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('code')=='CAIM2100':bdKARiXhIcgsQTnYUpaHSxeFEjJqLz =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('url')
    elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('code')=='CAIM0400':bdKARiXhIcgsQTnYUpaHSxeFEjJqLC =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('url')
    elif bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('code')=='CAIM1800':bdKARiXhIcgsQTnYUpaHSxeFEjJqNk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.IMG_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqNl.get('url')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['thumbnail']['poster']=bdKARiXhIcgsQTnYUpaHSxeFEjJqLz
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['thumbnail']['thumb']=bdKARiXhIcgsQTnYUpaHSxeFEjJqLz 
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['thumbnail']['clearlogo']=bdKARiXhIcgsQTnYUpaHSxeFEjJqNk
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlO['saveinfo']['thumbnail']['fanart']=bdKARiXhIcgsQTnYUpaHSxeFEjJqLC
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqlO
 def GetEuroChannelList(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqyf=[]
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyW ='/v2/operator/highlights'
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetDefaultParams()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyV={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':bdKARiXhIcgsQTnYUpaHSxeFEjJqwC(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.GetNoCache(2))}
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyz.update(bdKARiXhIcgsQTnYUpaHSxeFEjJqyV)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmk=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.API_DOMAIN+bdKARiXhIcgsQTnYUpaHSxeFEjJqyW
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyN=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.callRequestCookies('Get',bdKARiXhIcgsQTnYUpaHSxeFEjJqmk,payload=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,params=bdKARiXhIcgsQTnYUpaHSxeFEjJqyz,headers=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG,cookies=bdKARiXhIcgsQTnYUpaHSxeFEjJqwG)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqyr=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqyN.text)
   if not('result' in bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']):return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf,bdKARiXhIcgsQTnYUpaHSxeFEjJqLG
   bdKARiXhIcgsQTnYUpaHSxeFEjJqLr=bdKARiXhIcgsQTnYUpaHSxeFEjJqyr['body']['result']
   bdKARiXhIcgsQTnYUpaHSxeFEjJqlz =bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.Get_Now_Datetime()
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwk=bdKARiXhIcgsQTnYUpaHSxeFEjJqlz+datetime.timedelta(days=-1)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwk=bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(bdKARiXhIcgsQTnYUpaHSxeFEjJqwk.strftime('%Y%m%d'))
   for bdKARiXhIcgsQTnYUpaHSxeFEjJqyv in bdKARiXhIcgsQTnYUpaHSxeFEjJqLr:
    bdKARiXhIcgsQTnYUpaHSxeFEjJqwy=bdKARiXhIcgsQTnYUpaHSxeFEjJqwt(bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('content').get('banner_title2')[:8])
    if bdKARiXhIcgsQTnYUpaHSxeFEjJqwk<=bdKARiXhIcgsQTnYUpaHSxeFEjJqwy:
     bdKARiXhIcgsQTnYUpaHSxeFEjJqNv={'channel':bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('content').get('banner_sub_title3'),'title':bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('content').get('banner_title'),'subtitle':bdKARiXhIcgsQTnYUpaHSxeFEjJqyv.get('content').get('banner_sub_title2'),}
     bdKARiXhIcgsQTnYUpaHSxeFEjJqyf.append(bdKARiXhIcgsQTnYUpaHSxeFEjJqNv)
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqyf
 def Make_DecryptKey(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,step,mediacode='000',timecode='000'):
  if step=='1':
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwm=bdKARiXhIcgsQTnYUpaHSxeFEjJqBy('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwL=bdKARiXhIcgsQTnYUpaHSxeFEjJqBy('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwm=bdKARiXhIcgsQTnYUpaHSxeFEjJqBy('kss2lym0kdw1lks3','utf-8')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwL=bdKARiXhIcgsQTnYUpaHSxeFEjJqBy([bdKARiXhIcgsQTnYUpaHSxeFEjJqBm('*'),0x07,bdKARiXhIcgsQTnYUpaHSxeFEjJqBm('r'),bdKARiXhIcgsQTnYUpaHSxeFEjJqBm(';'),bdKARiXhIcgsQTnYUpaHSxeFEjJqBm('7'),0x05,0x1e,0x01,bdKARiXhIcgsQTnYUpaHSxeFEjJqBm('n'),bdKARiXhIcgsQTnYUpaHSxeFEjJqBm('D'),0x02,bdKARiXhIcgsQTnYUpaHSxeFEjJqBm('3'),bdKARiXhIcgsQTnYUpaHSxeFEjJqBm('*'),bdKARiXhIcgsQTnYUpaHSxeFEjJqBm('a'),bdKARiXhIcgsQTnYUpaHSxeFEjJqBm('&'),bdKARiXhIcgsQTnYUpaHSxeFEjJqBm('<')])
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqwm,bdKARiXhIcgsQTnYUpaHSxeFEjJqwL
 def DecryptPlaintext(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,ciphertext,encryption_key,init_vector):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqwN=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  bdKARiXhIcgsQTnYUpaHSxeFEjJqwl=Padding.unpad(bdKARiXhIcgsQTnYUpaHSxeFEjJqwN.decrypt(base64.standard_b64decode(ciphertext)),16)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqwl.decode('utf-8')
 def Decrypt_Url(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl,ciphertext,mediacode,bdKARiXhIcgsQTnYUpaHSxeFEjJqmB):
  bdKARiXhIcgsQTnYUpaHSxeFEjJqwB=''
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmD=''
  bdKARiXhIcgsQTnYUpaHSxeFEjJqmW=''
  try:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwm,bdKARiXhIcgsQTnYUpaHSxeFEjJqwL=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.Make_DecryptKey('1',mediacode=mediacode,timecode=bdKARiXhIcgsQTnYUpaHSxeFEjJqmB)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwD=json.loads(bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.DecryptPlaintext(ciphertext,bdKARiXhIcgsQTnYUpaHSxeFEjJqwm,bdKARiXhIcgsQTnYUpaHSxeFEjJqwL))
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwW =bdKARiXhIcgsQTnYUpaHSxeFEjJqwD.get('broad_url')
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmD =bdKARiXhIcgsQTnYUpaHSxeFEjJqwD.get('watermark') if 'watermark' in bdKARiXhIcgsQTnYUpaHSxeFEjJqwD else ''
   bdKARiXhIcgsQTnYUpaHSxeFEjJqmW=bdKARiXhIcgsQTnYUpaHSxeFEjJqwD.get('watermarkKey')if 'watermarkKey' in bdKARiXhIcgsQTnYUpaHSxeFEjJqwD else ''
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwm,bdKARiXhIcgsQTnYUpaHSxeFEjJqwL=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.Make_DecryptKey('2',mediacode=mediacode,timecode=bdKARiXhIcgsQTnYUpaHSxeFEjJqmB)
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwB=bdKARiXhIcgsQTnYUpaHSxeFEjJqkl.DecryptPlaintext(bdKARiXhIcgsQTnYUpaHSxeFEjJqwW,bdKARiXhIcgsQTnYUpaHSxeFEjJqwm,bdKARiXhIcgsQTnYUpaHSxeFEjJqwL)
  except bdKARiXhIcgsQTnYUpaHSxeFEjJqwO as exception:
   bdKARiXhIcgsQTnYUpaHSxeFEjJqwP(exception)
  return bdKARiXhIcgsQTnYUpaHSxeFEjJqwB,bdKARiXhIcgsQTnYUpaHSxeFEjJqmD,bdKARiXhIcgsQTnYUpaHSxeFEjJqmW
# Created by pyminifier (https://github.com/liftoff/pyminifier)
