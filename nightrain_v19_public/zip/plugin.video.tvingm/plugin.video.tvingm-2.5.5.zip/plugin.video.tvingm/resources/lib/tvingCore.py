__author__="NightRain"
FtHzUBemVuawEiqGQDoWNJfcsSCTjp=print
FtHzUBemVuawEiqGQDoWNJfcsSCTjA=ImportError
FtHzUBemVuawEiqGQDoWNJfcsSCTjd=object
FtHzUBemVuawEiqGQDoWNJfcsSCTjb=None
FtHzUBemVuawEiqGQDoWNJfcsSCTjg=False
FtHzUBemVuawEiqGQDoWNJfcsSCTjx=open
FtHzUBemVuawEiqGQDoWNJfcsSCTjv=True
FtHzUBemVuawEiqGQDoWNJfcsSCTjh=int
FtHzUBemVuawEiqGQDoWNJfcsSCTjO=range
FtHzUBemVuawEiqGQDoWNJfcsSCTjY=Exception
FtHzUBemVuawEiqGQDoWNJfcsSCTjM=len
FtHzUBemVuawEiqGQDoWNJfcsSCTjl=str
FtHzUBemVuawEiqGQDoWNJfcsSCTjk=dict
FtHzUBemVuawEiqGQDoWNJfcsSCTyI=list
FtHzUBemVuawEiqGQDoWNJfcsSCTyR=bytes
FtHzUBemVuawEiqGQDoWNJfcsSCTyr=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 FtHzUBemVuawEiqGQDoWNJfcsSCTjp('Cryptodome')
except FtHzUBemVuawEiqGQDoWNJfcsSCTjA:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 FtHzUBemVuawEiqGQDoWNJfcsSCTjp('Crypto')
FtHzUBemVuawEiqGQDoWNJfcsSCTIr={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
FtHzUBemVuawEiqGQDoWNJfcsSCTIP ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
FtHzUBemVuawEiqGQDoWNJfcsSCTIK =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
class FtHzUBemVuawEiqGQDoWNJfcsSCTIR(FtHzUBemVuawEiqGQDoWNJfcsSCTjd):
 def __init__(FtHzUBemVuawEiqGQDoWNJfcsSCTIn):
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.NETWORKCODE ='CSND0900'
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.OSCODE ='CSOD0900' 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TELECODE ='CSCD0900'
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.SCREENCODE ='CSSD0100'
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.SCREENCODE_ATV ='CSSD1300' 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.LIVE_LIMIT =20 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.VOD_LIMIT =24 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.EPISODE_LIMIT =30 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.SEARCH_LIMIT =30 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.MOVIE_LIMIT =24 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN ='https://api.tving.com'
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN ='https://image.tving.com'
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.SEARCH_DOMAIN ='https://search.tving.com'
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.LOGIN_DOMAIN ='https://user.tving.com'
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.URL_DOMAIN ='https://www.tving.com'
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.MOVIE_LITE =['2610061','2610161','261062']
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36'
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.DEFAULT_HEADER ={'user-agent':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.USER_AGENT}
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV_SESSION_COOKIES1=''
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV_SESSION_COOKIES2=''
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV_STREAM_FILENAME =''
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.KodiVersion=20
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV ={}
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.Init_TV_Total()
 def Init_TV_Total(FtHzUBemVuawEiqGQDoWNJfcsSCTIn):
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV={'account':{},'cookies':{'tving_token':'','tving_userinfo':'','tving_uuid':'-','tving_maintoken':'','tving_cookiekey':'Y','tving_lockkey':'N','tving_authToken':'',},}
 def callRequestCookies(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,jobtype,FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,redirects=FtHzUBemVuawEiqGQDoWNJfcsSCTjg):
  FtHzUBemVuawEiqGQDoWNJfcsSCTIj=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.DEFAULT_HEADER
  if headers:FtHzUBemVuawEiqGQDoWNJfcsSCTIj.update(headers)
  if jobtype=='Get':
   FtHzUBemVuawEiqGQDoWNJfcsSCTIy=requests.get(FtHzUBemVuawEiqGQDoWNJfcsSCTrI,params=params,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTIj,cookies=cookies,allow_redirects=redirects)
  else:
   FtHzUBemVuawEiqGQDoWNJfcsSCTIy=requests.post(FtHzUBemVuawEiqGQDoWNJfcsSCTrI,data=payload,params=params,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTIj,cookies=cookies,allow_redirects=redirects)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTIy
 def JsonFile_Save(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,filename,FtHzUBemVuawEiqGQDoWNJfcsSCTIX):
  if filename=='':return FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  try:
   fp=FtHzUBemVuawEiqGQDoWNJfcsSCTjx(filename,'w',-1,'utf-8')
   json.dump(FtHzUBemVuawEiqGQDoWNJfcsSCTIX,fp,indent=4,ensure_ascii=FtHzUBemVuawEiqGQDoWNJfcsSCTjg)
   fp.close()
  except:
   return FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  return FtHzUBemVuawEiqGQDoWNJfcsSCTjv
 def JsonFile_Load(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,filename):
  if filename=='':return{}
  try:
   fp=FtHzUBemVuawEiqGQDoWNJfcsSCTjx(filename,'r',-1,'utf-8')
   FtHzUBemVuawEiqGQDoWNJfcsSCTIp=json.load(fp)
   fp.close()
  except:
   return{}
  return FtHzUBemVuawEiqGQDoWNJfcsSCTIp
 def TextFile_Save(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,filename,resText):
  if filename=='':return FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  try:
   fp=FtHzUBemVuawEiqGQDoWNJfcsSCTjx(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  return FtHzUBemVuawEiqGQDoWNJfcsSCTjv
 def Save_session_acount(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,FtHzUBemVuawEiqGQDoWNJfcsSCTIA,FtHzUBemVuawEiqGQDoWNJfcsSCTId,FtHzUBemVuawEiqGQDoWNJfcsSCTIb,FtHzUBemVuawEiqGQDoWNJfcsSCTIg):
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['account']['tvid'] =base64.standard_b64encode(FtHzUBemVuawEiqGQDoWNJfcsSCTIA.encode()).decode('utf-8')
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['account']['tvpw'] =base64.standard_b64encode(FtHzUBemVuawEiqGQDoWNJfcsSCTId.encode()).decode('utf-8')
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['account']['tvtype']=FtHzUBemVuawEiqGQDoWNJfcsSCTIb 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['account']['tvpf'] =FtHzUBemVuawEiqGQDoWNJfcsSCTIg 
 def Load_session_acount(FtHzUBemVuawEiqGQDoWNJfcsSCTIn):
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTIA =base64.standard_b64decode(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['account']['tvid']).decode('utf-8')
   FtHzUBemVuawEiqGQDoWNJfcsSCTId =base64.standard_b64decode(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['account']['tvpw']).decode('utf-8')
   FtHzUBemVuawEiqGQDoWNJfcsSCTIb=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['account']['tvtype']
   FtHzUBemVuawEiqGQDoWNJfcsSCTIg =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return FtHzUBemVuawEiqGQDoWNJfcsSCTIA,FtHzUBemVuawEiqGQDoWNJfcsSCTId,FtHzUBemVuawEiqGQDoWNJfcsSCTIb,FtHzUBemVuawEiqGQDoWNJfcsSCTIg
 def makeDefaultCookies(FtHzUBemVuawEiqGQDoWNJfcsSCTIn):
  FtHzUBemVuawEiqGQDoWNJfcsSCTIx={}
  if FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_token']:FtHzUBemVuawEiqGQDoWNJfcsSCTIx['_tving_token']=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_token']
  if FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_userinfo']:FtHzUBemVuawEiqGQDoWNJfcsSCTIx['POC_USERINFO']=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_userinfo']
  if FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_maintoken']:FtHzUBemVuawEiqGQDoWNJfcsSCTIx[FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GLOBAL_COOKIENM['tv_maintoken']]=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_maintoken']
  if FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_cookiekey']:FtHzUBemVuawEiqGQDoWNJfcsSCTIx[FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GLOBAL_COOKIENM['tv_cookiekey']]=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_cookiekey']
  if FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_lockkey']:FtHzUBemVuawEiqGQDoWNJfcsSCTIx[FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GLOBAL_COOKIENM['tv_lockkey']]=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_lockkey']
  if FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_authToken']:FtHzUBemVuawEiqGQDoWNJfcsSCTIx['authToken']=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_authToken']
  return FtHzUBemVuawEiqGQDoWNJfcsSCTIx
 def makeCookiesStr(FtHzUBemVuawEiqGQDoWNJfcsSCTIn):
  return '_tving_token='+FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_token']+';'+ 'POC_USERINFO='+FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_userinfo']+';'+ FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GLOBAL_COOKIENM['tv_maintoken']+'='+FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_maintoken']+';'+ FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GLOBAL_COOKIENM['tv_cookiekey']+'='+FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_cookiekey']+';'+ FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GLOBAL_COOKIENM['tv_lockkey']+'='+FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_lockkey']
 def getDeviceStr(FtHzUBemVuawEiqGQDoWNJfcsSCTIn):
  FtHzUBemVuawEiqGQDoWNJfcsSCTIv=[]
  FtHzUBemVuawEiqGQDoWNJfcsSCTIv.append('Windows') 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIv.append('Chrome') 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIv.append('ko-KR') 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIv.append('undefined') 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIv.append('24') 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIv.append(u'한국 표준시')
  FtHzUBemVuawEiqGQDoWNJfcsSCTIv.append('undefined') 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIv.append('undefined') 
  FtHzUBemVuawEiqGQDoWNJfcsSCTIv.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  FtHzUBemVuawEiqGQDoWNJfcsSCTIh=''
  for FtHzUBemVuawEiqGQDoWNJfcsSCTIO in FtHzUBemVuawEiqGQDoWNJfcsSCTIv:
   FtHzUBemVuawEiqGQDoWNJfcsSCTIh+=FtHzUBemVuawEiqGQDoWNJfcsSCTIO+'|'
  return FtHzUBemVuawEiqGQDoWNJfcsSCTIh
 def GetDefaultParams(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,uhd=FtHzUBemVuawEiqGQDoWNJfcsSCTjg):
  if uhd==FtHzUBemVuawEiqGQDoWNJfcsSCTjg:
   FtHzUBemVuawEiqGQDoWNJfcsSCTIY={'apiKey':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.APIKEY,'networkCode':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.NETWORKCODE,'osCode':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.OSCODE,'teleCode':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TELECODE,'screenCode':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.SCREENCODE,}
  else:
   FtHzUBemVuawEiqGQDoWNJfcsSCTIY={'apiKey':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.APIKEY_ATV,'networkCode':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.NETWORKCODE,'osCode':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.OSCODE,'teleCode':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TELECODE,'screenCode':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.SCREENCODE_ATV,}
  return FtHzUBemVuawEiqGQDoWNJfcsSCTIY
 def GetNoCache(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,timetype=1):
  if timetype==1:
   return FtHzUBemVuawEiqGQDoWNJfcsSCTjh(time.time())
  else:
   return FtHzUBemVuawEiqGQDoWNJfcsSCTjh(time.time()*1000)
 def GetUniqueid(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,hValue=FtHzUBemVuawEiqGQDoWNJfcsSCTjb):
  if hValue:
   import hashlib
   FtHzUBemVuawEiqGQDoWNJfcsSCTIM=hashlib.sha1()
   FtHzUBemVuawEiqGQDoWNJfcsSCTIM.update(hValue.encode())
   FtHzUBemVuawEiqGQDoWNJfcsSCTIl=FtHzUBemVuawEiqGQDoWNJfcsSCTIM.hexdigest()[:8]
  else:
   FtHzUBemVuawEiqGQDoWNJfcsSCTIk=[0 for i in FtHzUBemVuawEiqGQDoWNJfcsSCTjO(256)]
   for i in FtHzUBemVuawEiqGQDoWNJfcsSCTjO(256):
    FtHzUBemVuawEiqGQDoWNJfcsSCTIk[i]='%02x'%(i)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRI=FtHzUBemVuawEiqGQDoWNJfcsSCTjh(4294967295*random.random())|0
   FtHzUBemVuawEiqGQDoWNJfcsSCTIl=FtHzUBemVuawEiqGQDoWNJfcsSCTIk[255&FtHzUBemVuawEiqGQDoWNJfcsSCTRI]+FtHzUBemVuawEiqGQDoWNJfcsSCTIk[FtHzUBemVuawEiqGQDoWNJfcsSCTRI>>8&255]+FtHzUBemVuawEiqGQDoWNJfcsSCTIk[FtHzUBemVuawEiqGQDoWNJfcsSCTRI>>16&255]+FtHzUBemVuawEiqGQDoWNJfcsSCTIk[FtHzUBemVuawEiqGQDoWNJfcsSCTRI>>24&255]
  return FtHzUBemVuawEiqGQDoWNJfcsSCTIl
 def GetCredential(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,user_id,user_pw,login_type,user_pf):
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRr=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   FtHzUBemVuawEiqGQDoWNJfcsSCTRP={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Post',FtHzUBemVuawEiqGQDoWNJfcsSCTRr,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTRP,params=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb)
   for FtHzUBemVuawEiqGQDoWNJfcsSCTRn in FtHzUBemVuawEiqGQDoWNJfcsSCTRK.cookies:
    if FtHzUBemVuawEiqGQDoWNJfcsSCTRn.name=='_tving_token':
     FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_token']=FtHzUBemVuawEiqGQDoWNJfcsSCTRn.value
    elif FtHzUBemVuawEiqGQDoWNJfcsSCTRn.name=='POC_USERINFO':
     FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_userinfo']=FtHzUBemVuawEiqGQDoWNJfcsSCTRn.value
    elif FtHzUBemVuawEiqGQDoWNJfcsSCTRn.name=='authToken':
     FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_authToken']=FtHzUBemVuawEiqGQDoWNJfcsSCTRn.value
   if not FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_token']:
    FtHzUBemVuawEiqGQDoWNJfcsSCTIn.Init_TV_Total()
    return FtHzUBemVuawEiqGQDoWNJfcsSCTjg
   FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_maintoken']=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_token']
   if FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetProfileToken(user_pf)==FtHzUBemVuawEiqGQDoWNJfcsSCTjg:
    FtHzUBemVuawEiqGQDoWNJfcsSCTIn.Init_TV_Total()
    return FtHzUBemVuawEiqGQDoWNJfcsSCTjg
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies'])
   FtHzUBemVuawEiqGQDoWNJfcsSCTRj =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDeviceList()
   if FtHzUBemVuawEiqGQDoWNJfcsSCTRj not in['','-']:
    FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_uuid']=FtHzUBemVuawEiqGQDoWNJfcsSCTRj+'-'+FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetUniqueid(FtHzUBemVuawEiqGQDoWNJfcsSCTRj)
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
   FtHzUBemVuawEiqGQDoWNJfcsSCTIn.Init_TV_Total()
   return FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  return FtHzUBemVuawEiqGQDoWNJfcsSCTjv
 def GetProfileToken(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,user_pf):
  FtHzUBemVuawEiqGQDoWNJfcsSCTRy=[]
  FtHzUBemVuawEiqGQDoWNJfcsSCTRX =''
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   FtHzUBemVuawEiqGQDoWNJfcsSCTIx=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.makeDefaultCookies()
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(FtHzUBemVuawEiqGQDoWNJfcsSCTIx)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTRL,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTIx)
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRy =re.findall('data-profile-no="\d+"',FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(FtHzUBemVuawEiqGQDoWNJfcsSCTRy)
   for i in FtHzUBemVuawEiqGQDoWNJfcsSCTjO(FtHzUBemVuawEiqGQDoWNJfcsSCTjM(FtHzUBemVuawEiqGQDoWNJfcsSCTRy)):
    FtHzUBemVuawEiqGQDoWNJfcsSCTRp =FtHzUBemVuawEiqGQDoWNJfcsSCTRy[i].replace('data-profile-no=','').replace('"','')
    FtHzUBemVuawEiqGQDoWNJfcsSCTRy[i]=FtHzUBemVuawEiqGQDoWNJfcsSCTRp
   FtHzUBemVuawEiqGQDoWNJfcsSCTRX=FtHzUBemVuawEiqGQDoWNJfcsSCTRy[user_pf]
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
   FtHzUBemVuawEiqGQDoWNJfcsSCTIn.Init_TV_Total()
   return FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   FtHzUBemVuawEiqGQDoWNJfcsSCTIx=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.makeDefaultCookies()
   FtHzUBemVuawEiqGQDoWNJfcsSCTRP={'profileNo':FtHzUBemVuawEiqGQDoWNJfcsSCTRX}
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Post',FtHzUBemVuawEiqGQDoWNJfcsSCTRL,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTRP,params=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTIx)
   for FtHzUBemVuawEiqGQDoWNJfcsSCTRn in FtHzUBemVuawEiqGQDoWNJfcsSCTRK.cookies:
    if FtHzUBemVuawEiqGQDoWNJfcsSCTRn.name=='_tving_token':
     FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_token']=FtHzUBemVuawEiqGQDoWNJfcsSCTRn.value
    elif FtHzUBemVuawEiqGQDoWNJfcsSCTRn.name==FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GLOBAL_COOKIENM['tv_cookiekey']:
     FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_cookiekey']=FtHzUBemVuawEiqGQDoWNJfcsSCTRn.value
    elif FtHzUBemVuawEiqGQDoWNJfcsSCTRn.name==FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GLOBAL_COOKIENM['tv_lockkey']:
     FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_lockkey']=FtHzUBemVuawEiqGQDoWNJfcsSCTRn.value
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
   FtHzUBemVuawEiqGQDoWNJfcsSCTIn.Init_TV_Total()
   return FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  return FtHzUBemVuawEiqGQDoWNJfcsSCTjv
 def GetDeviceList(FtHzUBemVuawEiqGQDoWNJfcsSCTIn):
  FtHzUBemVuawEiqGQDoWNJfcsSCTRA=[]
  FtHzUBemVuawEiqGQDoWNJfcsSCTRd='-'
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v1/user/device/list'
   FtHzUBemVuawEiqGQDoWNJfcsSCTRb=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRL
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   FtHzUBemVuawEiqGQDoWNJfcsSCTIx=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.makeDefaultCookies()
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTRb,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRg,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTIx)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRx=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRA=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']
   for FtHzUBemVuawEiqGQDoWNJfcsSCTRv in FtHzUBemVuawEiqGQDoWNJfcsSCTRA:
    if FtHzUBemVuawEiqGQDoWNJfcsSCTRv['model']=='PC' or FtHzUBemVuawEiqGQDoWNJfcsSCTRv['model']=='PC-Chrome':
     FtHzUBemVuawEiqGQDoWNJfcsSCTRd=FtHzUBemVuawEiqGQDoWNJfcsSCTRv['uuid']
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTRd
 def Get_Now_Datetime(FtHzUBemVuawEiqGQDoWNJfcsSCTIn):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,mediacode,sel_quality,stype,pvrmode='-',optUHD=FtHzUBemVuawEiqGQDoWNJfcsSCTjg):
  FtHzUBemVuawEiqGQDoWNJfcsSCTRO ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','subtitleYn':FtHzUBemVuawEiqGQDoWNJfcsSCTjg,'error_msg':'',}
  FtHzUBemVuawEiqGQDoWNJfcsSCTRd =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_uuid'].split('-')[0] 
  FtHzUBemVuawEiqGQDoWNJfcsSCTRY =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_uuid'] 
  FtHzUBemVuawEiqGQDoWNJfcsSCTRM=FtHzUBemVuawEiqGQDoWNJfcsSCTjg 
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRl=FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetNoCache(1))
   if stype!='tvingtv':
    FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v2/media/stream/info' 
    FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams()
    FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':FtHzUBemVuawEiqGQDoWNJfcsSCTRY,'deviceInfo':'PC','noCache':FtHzUBemVuawEiqGQDoWNJfcsSCTRl,}
    FtHzUBemVuawEiqGQDoWNJfcsSCTRk.update(FtHzUBemVuawEiqGQDoWNJfcsSCTRg)
    FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRL
    FtHzUBemVuawEiqGQDoWNJfcsSCTIx=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.makeDefaultCookies()
    FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRk,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTIx)
    if FtHzUBemVuawEiqGQDoWNJfcsSCTRK.status_code!=200:
     FtHzUBemVuawEiqGQDoWNJfcsSCTRO['error_msg']='First Step - {} error'.format(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.status_code)
     return FtHzUBemVuawEiqGQDoWNJfcsSCTRO
    FtHzUBemVuawEiqGQDoWNJfcsSCTRx=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
    if FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['result']['code']=='060':
     for FtHzUBemVuawEiqGQDoWNJfcsSCTrR,FtHzUBemVuawEiqGQDoWNJfcsSCTPd in FtHzUBemVuawEiqGQDoWNJfcsSCTIr.items():
      if FtHzUBemVuawEiqGQDoWNJfcsSCTPd==sel_quality:
       FtHzUBemVuawEiqGQDoWNJfcsSCTrP=FtHzUBemVuawEiqGQDoWNJfcsSCTrR
    elif FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['result']['code']!='000':
     FtHzUBemVuawEiqGQDoWNJfcsSCTRO['error_msg']=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['result']['message']
     return FtHzUBemVuawEiqGQDoWNJfcsSCTRO
    else: 
     if not('stream' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']):return FtHzUBemVuawEiqGQDoWNJfcsSCTRO
     FtHzUBemVuawEiqGQDoWNJfcsSCTrK=[]
     for FtHzUBemVuawEiqGQDoWNJfcsSCTrR,FtHzUBemVuawEiqGQDoWNJfcsSCTPd in FtHzUBemVuawEiqGQDoWNJfcsSCTIr.items():
      for FtHzUBemVuawEiqGQDoWNJfcsSCTRv in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['stream']['quality']:
       if FtHzUBemVuawEiqGQDoWNJfcsSCTRv['active']=='Y' and FtHzUBemVuawEiqGQDoWNJfcsSCTRv['code']==FtHzUBemVuawEiqGQDoWNJfcsSCTrR:
        FtHzUBemVuawEiqGQDoWNJfcsSCTrK.append({FtHzUBemVuawEiqGQDoWNJfcsSCTIr.get(FtHzUBemVuawEiqGQDoWNJfcsSCTRv['code']):FtHzUBemVuawEiqGQDoWNJfcsSCTRv['code']})
     FtHzUBemVuawEiqGQDoWNJfcsSCTrP=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.CheckQuality(sel_quality,FtHzUBemVuawEiqGQDoWNJfcsSCTrK)
     try:
      if optUHD==FtHzUBemVuawEiqGQDoWNJfcsSCTjv and FtHzUBemVuawEiqGQDoWNJfcsSCTrP=='stream50' and 'stream_support_info' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['content']['info']:
       if FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['content']['info']['stream_support_info']!=FtHzUBemVuawEiqGQDoWNJfcsSCTjb:
        if 'stream70' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['content']['info']['stream_support_info']:
         FtHzUBemVuawEiqGQDoWNJfcsSCTrP='stream70'
         FtHzUBemVuawEiqGQDoWNJfcsSCTRM =FtHzUBemVuawEiqGQDoWNJfcsSCTjv
     except:
      pass
     try:
      if optUHD==FtHzUBemVuawEiqGQDoWNJfcsSCTjv and FtHzUBemVuawEiqGQDoWNJfcsSCTrP=='stream50' and 'stream' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['content']['info']:
       if FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['content']['info']['stream']!=FtHzUBemVuawEiqGQDoWNJfcsSCTjb:
        for FtHzUBemVuawEiqGQDoWNJfcsSCTRv in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['content']['info']['stream']:
         if FtHzUBemVuawEiqGQDoWNJfcsSCTRv['code']=='stream70':
          FtHzUBemVuawEiqGQDoWNJfcsSCTrP='stream70'
          FtHzUBemVuawEiqGQDoWNJfcsSCTRM =FtHzUBemVuawEiqGQDoWNJfcsSCTjv
          break
     except:
      pass
   else:
    FtHzUBemVuawEiqGQDoWNJfcsSCTrP='stream40'
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRO['error_msg']='First Step - except error'
   return FtHzUBemVuawEiqGQDoWNJfcsSCTRO
  FtHzUBemVuawEiqGQDoWNJfcsSCTjp(FtHzUBemVuawEiqGQDoWNJfcsSCTrP)
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRl=FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetNoCache(1))
   FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v2a/media/stream/info'
   if FtHzUBemVuawEiqGQDoWNJfcsSCTRM==FtHzUBemVuawEiqGQDoWNJfcsSCTjv:
    FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams(uhd=FtHzUBemVuawEiqGQDoWNJfcsSCTjv)
    FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'mediaCode':mediacode,'noCache':FtHzUBemVuawEiqGQDoWNJfcsSCTRl,'streamType':'hls','streamCode':FtHzUBemVuawEiqGQDoWNJfcsSCTrP,'deviceId':FtHzUBemVuawEiqGQDoWNJfcsSCTRd,'adReq':'none','wm':'Y','ad_device':'','uuid':FtHzUBemVuawEiqGQDoWNJfcsSCTRY,'deviceInfo':'android_tv',}
   else:
    FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams()
    FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':FtHzUBemVuawEiqGQDoWNJfcsSCTrP,'deviceId':FtHzUBemVuawEiqGQDoWNJfcsSCTRd,'uuid':FtHzUBemVuawEiqGQDoWNJfcsSCTRY,'deviceInfo':'PC_Chrome','noCache':FtHzUBemVuawEiqGQDoWNJfcsSCTRl,'wm':'Y'}
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk.update(FtHzUBemVuawEiqGQDoWNJfcsSCTRg)
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRL
   FtHzUBemVuawEiqGQDoWNJfcsSCTIx=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.makeDefaultCookies()
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRk,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTIx,redirects=FtHzUBemVuawEiqGQDoWNJfcsSCTjg)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRx=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   if FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['result']['code']!='000':
    FtHzUBemVuawEiqGQDoWNJfcsSCTRO['error_msg']=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['result']['message']
    return FtHzUBemVuawEiqGQDoWNJfcsSCTRO
   FtHzUBemVuawEiqGQDoWNJfcsSCTrn=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['stream']
   if 'drm_license_assertion' in FtHzUBemVuawEiqGQDoWNJfcsSCTrn:
    FtHzUBemVuawEiqGQDoWNJfcsSCTRO['drm_license']=FtHzUBemVuawEiqGQDoWNJfcsSCTrn['drm_license_assertion']
    if '4k_nondrm_url' in FtHzUBemVuawEiqGQDoWNJfcsSCTrn['broadcast']and FtHzUBemVuawEiqGQDoWNJfcsSCTRM==FtHzUBemVuawEiqGQDoWNJfcsSCTjv:
     FtHzUBemVuawEiqGQDoWNJfcsSCTrj =FtHzUBemVuawEiqGQDoWNJfcsSCTrn['broadcast']['4k_nondrm_url']
     FtHzUBemVuawEiqGQDoWNJfcsSCTRO['drm_license']=''
    else:
     FtHzUBemVuawEiqGQDoWNJfcsSCTrj =FtHzUBemVuawEiqGQDoWNJfcsSCTrn['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in FtHzUBemVuawEiqGQDoWNJfcsSCTrn['broadcast']):return FtHzUBemVuawEiqGQDoWNJfcsSCTRO
    FtHzUBemVuawEiqGQDoWNJfcsSCTrj=FtHzUBemVuawEiqGQDoWNJfcsSCTrn['broadcast']['broad_url']
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRO['error_msg']='Second Step - except error'
   return FtHzUBemVuawEiqGQDoWNJfcsSCTRO
  FtHzUBemVuawEiqGQDoWNJfcsSCTry=FtHzUBemVuawEiqGQDoWNJfcsSCTRl
  FtHzUBemVuawEiqGQDoWNJfcsSCTrj=FtHzUBemVuawEiqGQDoWNJfcsSCTrj.split('|')[1]
  FtHzUBemVuawEiqGQDoWNJfcsSCTrj,FtHzUBemVuawEiqGQDoWNJfcsSCTrX,FtHzUBemVuawEiqGQDoWNJfcsSCTrL=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.Decrypt_Url(FtHzUBemVuawEiqGQDoWNJfcsSCTrj,mediacode,FtHzUBemVuawEiqGQDoWNJfcsSCTry)
  FtHzUBemVuawEiqGQDoWNJfcsSCTRO['streaming_url']=FtHzUBemVuawEiqGQDoWNJfcsSCTrj
  FtHzUBemVuawEiqGQDoWNJfcsSCTRO['watermark'] =FtHzUBemVuawEiqGQDoWNJfcsSCTrX
  FtHzUBemVuawEiqGQDoWNJfcsSCTRO['watermarkKey']=FtHzUBemVuawEiqGQDoWNJfcsSCTrL
  if 'subtitles' in FtHzUBemVuawEiqGQDoWNJfcsSCTrn:
   for FtHzUBemVuawEiqGQDoWNJfcsSCTrp in FtHzUBemVuawEiqGQDoWNJfcsSCTrn.get('subtitles'):
    if FtHzUBemVuawEiqGQDoWNJfcsSCTrp.get('code')in['KO','KO_CC']:
     FtHzUBemVuawEiqGQDoWNJfcsSCTRO['subtitleYn']=FtHzUBemVuawEiqGQDoWNJfcsSCTjv
     break
  return FtHzUBemVuawEiqGQDoWNJfcsSCTRO
 def Tving_Parse_mpd(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,stream_url):
  FtHzUBemVuawEiqGQDoWNJfcsSCTRK=requests.get(url=stream_url)
  FtHzUBemVuawEiqGQDoWNJfcsSCTrA=FtHzUBemVuawEiqGQDoWNJfcsSCTRK.content.decode('utf-8')
  FtHzUBemVuawEiqGQDoWNJfcsSCTrd=0
  FtHzUBemVuawEiqGQDoWNJfcsSCTrb =ET.ElementTree(ET.fromstring(FtHzUBemVuawEiqGQDoWNJfcsSCTrA))
  FtHzUBemVuawEiqGQDoWNJfcsSCTrg =FtHzUBemVuawEiqGQDoWNJfcsSCTrb.getroot()
  FtHzUBemVuawEiqGQDoWNJfcsSCTrx=re.match(r'\{.*\}',FtHzUBemVuawEiqGQDoWNJfcsSCTrg.tag)[0]
  FtHzUBemVuawEiqGQDoWNJfcsSCTrv=FtHzUBemVuawEiqGQDoWNJfcsSCTjk([node for _,node in ET.iterparse(io.StringIO(FtHzUBemVuawEiqGQDoWNJfcsSCTrA),events=['start-ns'])])
  for FtHzUBemVuawEiqGQDoWNJfcsSCTrR,FtHzUBemVuawEiqGQDoWNJfcsSCTPL in FtHzUBemVuawEiqGQDoWNJfcsSCTrv.items():
   ET.register_namespace(FtHzUBemVuawEiqGQDoWNJfcsSCTrR,FtHzUBemVuawEiqGQDoWNJfcsSCTPL)
  FtHzUBemVuawEiqGQDoWNJfcsSCTrh=FtHzUBemVuawEiqGQDoWNJfcsSCTrg.find(FtHzUBemVuawEiqGQDoWNJfcsSCTrx+'Period')
  for FtHzUBemVuawEiqGQDoWNJfcsSCTrO in FtHzUBemVuawEiqGQDoWNJfcsSCTrh.findall(FtHzUBemVuawEiqGQDoWNJfcsSCTrx+'AdaptationSet'):
   if FtHzUBemVuawEiqGQDoWNJfcsSCTrO.attrib.get('mimeType')=='video/mp4':
    for FtHzUBemVuawEiqGQDoWNJfcsSCTrY in FtHzUBemVuawEiqGQDoWNJfcsSCTrO.findall(FtHzUBemVuawEiqGQDoWNJfcsSCTrx+'Representation'):
     FtHzUBemVuawEiqGQDoWNJfcsSCTrM=FtHzUBemVuawEiqGQDoWNJfcsSCTjh(FtHzUBemVuawEiqGQDoWNJfcsSCTrY.attrib.get('bandwidth'))
     if FtHzUBemVuawEiqGQDoWNJfcsSCTrd<FtHzUBemVuawEiqGQDoWNJfcsSCTrM:FtHzUBemVuawEiqGQDoWNJfcsSCTrd=FtHzUBemVuawEiqGQDoWNJfcsSCTrM
    for FtHzUBemVuawEiqGQDoWNJfcsSCTrY in FtHzUBemVuawEiqGQDoWNJfcsSCTrO.findall(FtHzUBemVuawEiqGQDoWNJfcsSCTrx+'Representation'):
     if FtHzUBemVuawEiqGQDoWNJfcsSCTrd>FtHzUBemVuawEiqGQDoWNJfcsSCTjh(FtHzUBemVuawEiqGQDoWNJfcsSCTrY.attrib.get('bandwidth')):
      FtHzUBemVuawEiqGQDoWNJfcsSCTrO.remove(FtHzUBemVuawEiqGQDoWNJfcsSCTrY)
   else:
    continue
  FtHzUBemVuawEiqGQDoWNJfcsSCTrl=ET.tostring(FtHzUBemVuawEiqGQDoWNJfcsSCTrg).decode('utf-8')
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TextFile_Save(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV_STREAM_FILENAME,FtHzUBemVuawEiqGQDoWNJfcsSCTrl)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTjv
 def Tving_Parse_m3u8(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,stream_url):
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=requests.get(url=stream_url,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,stream=FtHzUBemVuawEiqGQDoWNJfcsSCTjv)
   FtHzUBemVuawEiqGQDoWNJfcsSCTrk=FtHzUBemVuawEiqGQDoWNJfcsSCTRK.content.decode('utf-8')
   if '#EXTM3U' not in FtHzUBemVuawEiqGQDoWNJfcsSCTrk:
    return FtHzUBemVuawEiqGQDoWNJfcsSCTjg
   if '#EXT-X-STREAM-INF' not in FtHzUBemVuawEiqGQDoWNJfcsSCTrk: 
    return FtHzUBemVuawEiqGQDoWNJfcsSCTjg
   FtHzUBemVuawEiqGQDoWNJfcsSCTPI=0
   for FtHzUBemVuawEiqGQDoWNJfcsSCTPR in FtHzUBemVuawEiqGQDoWNJfcsSCTrk.splitlines():
    if FtHzUBemVuawEiqGQDoWNJfcsSCTPR.startswith('#EXT-X-STREAM-INF'):
     FtHzUBemVuawEiqGQDoWNJfcsSCTPr=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.MediaLine_Parse(FtHzUBemVuawEiqGQDoWNJfcsSCTPR,'#EXT-X-STREAM-INF')
     if FtHzUBemVuawEiqGQDoWNJfcsSCTPI<FtHzUBemVuawEiqGQDoWNJfcsSCTjh(FtHzUBemVuawEiqGQDoWNJfcsSCTPr.get('BANDWIDTH')):
      FtHzUBemVuawEiqGQDoWNJfcsSCTPI=FtHzUBemVuawEiqGQDoWNJfcsSCTjh(FtHzUBemVuawEiqGQDoWNJfcsSCTPr.get('BANDWIDTH'))
   FtHzUBemVuawEiqGQDoWNJfcsSCTPK=[]
   FtHzUBemVuawEiqGQDoWNJfcsSCTPn=FtHzUBemVuawEiqGQDoWNJfcsSCTjg
   for FtHzUBemVuawEiqGQDoWNJfcsSCTPR in FtHzUBemVuawEiqGQDoWNJfcsSCTrk.splitlines():
    if FtHzUBemVuawEiqGQDoWNJfcsSCTPn==FtHzUBemVuawEiqGQDoWNJfcsSCTjv:
     FtHzUBemVuawEiqGQDoWNJfcsSCTPn=FtHzUBemVuawEiqGQDoWNJfcsSCTjg
     continue
    if FtHzUBemVuawEiqGQDoWNJfcsSCTPR.startswith('#EXT-X-STREAM-INF'):
     FtHzUBemVuawEiqGQDoWNJfcsSCTPr=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.MediaLine_Parse(FtHzUBemVuawEiqGQDoWNJfcsSCTPR,'#EXT-X-STREAM-INF')
     if FtHzUBemVuawEiqGQDoWNJfcsSCTPI!=FtHzUBemVuawEiqGQDoWNJfcsSCTjh(FtHzUBemVuawEiqGQDoWNJfcsSCTPr.get('BANDWIDTH')):
      FtHzUBemVuawEiqGQDoWNJfcsSCTPn=FtHzUBemVuawEiqGQDoWNJfcsSCTjv
      continue
    FtHzUBemVuawEiqGQDoWNJfcsSCTPK.append(FtHzUBemVuawEiqGQDoWNJfcsSCTPR)
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
   return FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  FtHzUBemVuawEiqGQDoWNJfcsSCTPj='\n'.join(FtHzUBemVuawEiqGQDoWNJfcsSCTPK)
  FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TextFile_Save(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV_STREAM_FILENAME,FtHzUBemVuawEiqGQDoWNJfcsSCTPj)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTjv
 def MediaLine_Parse(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,FtHzUBemVuawEiqGQDoWNJfcsSCTPR,prefix):
  FtHzUBemVuawEiqGQDoWNJfcsSCTPr={}
  for FtHzUBemVuawEiqGQDoWNJfcsSCTPy in FtHzUBemVuawEiqGQDoWNJfcsSCTIK.split(FtHzUBemVuawEiqGQDoWNJfcsSCTPR.replace(prefix+':',''))[1::2]:
   FtHzUBemVuawEiqGQDoWNJfcsSCTPX,FtHzUBemVuawEiqGQDoWNJfcsSCTPL=FtHzUBemVuawEiqGQDoWNJfcsSCTPy.split('=',1)
   FtHzUBemVuawEiqGQDoWNJfcsSCTPr[FtHzUBemVuawEiqGQDoWNJfcsSCTPX.upper()]=FtHzUBemVuawEiqGQDoWNJfcsSCTPL.replace('"','').strip()
  return FtHzUBemVuawEiqGQDoWNJfcsSCTPr
 def CheckQuality(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,sel_qt,FtHzUBemVuawEiqGQDoWNJfcsSCTrK):
  for FtHzUBemVuawEiqGQDoWNJfcsSCTPp in FtHzUBemVuawEiqGQDoWNJfcsSCTrK:
   if sel_qt>=FtHzUBemVuawEiqGQDoWNJfcsSCTyI(FtHzUBemVuawEiqGQDoWNJfcsSCTPp)[0]:return FtHzUBemVuawEiqGQDoWNJfcsSCTPp.get(FtHzUBemVuawEiqGQDoWNJfcsSCTyI(FtHzUBemVuawEiqGQDoWNJfcsSCTPp)[0])
   FtHzUBemVuawEiqGQDoWNJfcsSCTPA=FtHzUBemVuawEiqGQDoWNJfcsSCTPp.get(FtHzUBemVuawEiqGQDoWNJfcsSCTyI(FtHzUBemVuawEiqGQDoWNJfcsSCTPp)[0])
  return FtHzUBemVuawEiqGQDoWNJfcsSCTPA
 def makeOocUrl(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,ooc_params):
  FtHzUBemVuawEiqGQDoWNJfcsSCTrI=''
  for FtHzUBemVuawEiqGQDoWNJfcsSCTrR,FtHzUBemVuawEiqGQDoWNJfcsSCTPd in ooc_params.items():
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI+="%s=%s^"%(FtHzUBemVuawEiqGQDoWNJfcsSCTrR,FtHzUBemVuawEiqGQDoWNJfcsSCTPd)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTrI
 def GetLiveChannelList(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,stype,page_int):
  FtHzUBemVuawEiqGQDoWNJfcsSCTRA=[]
  FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v2/media/lives'
   if stype=='onair': 
    FtHzUBemVuawEiqGQDoWNJfcsSCTPg='CPCS0100,CPCS0400'
   else:
    FtHzUBemVuawEiqGQDoWNJfcsSCTPg='CPCS0300'
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams()
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'cacheType':'main','pageNo':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(page_int),'pageSize':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':FtHzUBemVuawEiqGQDoWNJfcsSCTPg,}
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk.update(FtHzUBemVuawEiqGQDoWNJfcsSCTRg)
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRL
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRk,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRx=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   if not('result' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']):return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
   FtHzUBemVuawEiqGQDoWNJfcsSCTPx=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['result']
   for FtHzUBemVuawEiqGQDoWNJfcsSCTRv in FtHzUBemVuawEiqGQDoWNJfcsSCTPx:
    FtHzUBemVuawEiqGQDoWNJfcsSCTPv=FtHzUBemVuawEiqGQDoWNJfcsSCTPY=FtHzUBemVuawEiqGQDoWNJfcsSCTPM=''
    FtHzUBemVuawEiqGQDoWNJfcsSCTPh=FtHzUBemVuawEiqGQDoWNJfcsSCTKx=''
    FtHzUBemVuawEiqGQDoWNJfcsSCTPO=FtHzUBemVuawEiqGQDoWNJfcsSCTRv['live_code']
    FtHzUBemVuawEiqGQDoWNJfcsSCTPv =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['channel']['name']['ko']
    if FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['episode']!=FtHzUBemVuawEiqGQDoWNJfcsSCTjb:
     FtHzUBemVuawEiqGQDoWNJfcsSCTPY =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['program']['name']['ko']
     FtHzUBemVuawEiqGQDoWNJfcsSCTPY =FtHzUBemVuawEiqGQDoWNJfcsSCTPY+', '+FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['episode']['frequency'])+'회'
     FtHzUBemVuawEiqGQDoWNJfcsSCTPM=FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['episode']['synopsis']['ko']
    else:
     FtHzUBemVuawEiqGQDoWNJfcsSCTPY =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['program']['name']['ko']
     FtHzUBemVuawEiqGQDoWNJfcsSCTPM=FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['program']['synopsis']['ko']
    try: 
     FtHzUBemVuawEiqGQDoWNJfcsSCTPl =''
     FtHzUBemVuawEiqGQDoWNJfcsSCTPk =''
     FtHzUBemVuawEiqGQDoWNJfcsSCTKI=''
     FtHzUBemVuawEiqGQDoWNJfcsSCTKR =''
     FtHzUBemVuawEiqGQDoWNJfcsSCTKr =''
     FtHzUBemVuawEiqGQDoWNJfcsSCTKP =''
     for FtHzUBemVuawEiqGQDoWNJfcsSCTKn in FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['program']['image']:
      if FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP0900':FtHzUBemVuawEiqGQDoWNJfcsSCTPk =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
      elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP1800':FtHzUBemVuawEiqGQDoWNJfcsSCTKI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
      elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP2000':FtHzUBemVuawEiqGQDoWNJfcsSCTKR =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
      elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP1900':FtHzUBemVuawEiqGQDoWNJfcsSCTKr =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
      elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP0200':FtHzUBemVuawEiqGQDoWNJfcsSCTKP =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
      elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP0500':FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
      elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP0800':FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     if FtHzUBemVuawEiqGQDoWNJfcsSCTPl=='':
      for FtHzUBemVuawEiqGQDoWNJfcsSCTKn in FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['channel']['image']:
       if FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIC0400':FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
       elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIC1400':FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
       elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIC1900':FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
    except:
     FtHzUBemVuawEiqGQDoWNJfcsSCTjb
    try:
     FtHzUBemVuawEiqGQDoWNJfcsSCTKj =[]
     FtHzUBemVuawEiqGQDoWNJfcsSCTKy=[]
     FtHzUBemVuawEiqGQDoWNJfcsSCTKX =[]
     FtHzUBemVuawEiqGQDoWNJfcsSCTKL=''
     FtHzUBemVuawEiqGQDoWNJfcsSCTKp=''
     FtHzUBemVuawEiqGQDoWNJfcsSCTKA=''
     for FtHzUBemVuawEiqGQDoWNJfcsSCTKd in FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('schedule').get('program').get('actor'):
      if FtHzUBemVuawEiqGQDoWNJfcsSCTKd!='' and FtHzUBemVuawEiqGQDoWNJfcsSCTKd!=u'없음':FtHzUBemVuawEiqGQDoWNJfcsSCTKj.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKd)
     for FtHzUBemVuawEiqGQDoWNJfcsSCTKb in FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('schedule').get('program').get('director'):
      if FtHzUBemVuawEiqGQDoWNJfcsSCTKb!='' and FtHzUBemVuawEiqGQDoWNJfcsSCTKb!='-' and FtHzUBemVuawEiqGQDoWNJfcsSCTKb!=u'없음':FtHzUBemVuawEiqGQDoWNJfcsSCTKy.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKb)
     if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('schedule').get('program').get('category1_name').get('ko')!='':
      FtHzUBemVuawEiqGQDoWNJfcsSCTKX.append(FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['program']['category1_name']['ko'])
     if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('schedule').get('program').get('category2_name').get('ko')!='':
      FtHzUBemVuawEiqGQDoWNJfcsSCTKX.append(FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['program']['category2_name']['ko'])
     if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('schedule').get('program').get('product_year'):FtHzUBemVuawEiqGQDoWNJfcsSCTKL=FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['program']['product_year']
     if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('schedule').get('program').get('grade_code') :FtHzUBemVuawEiqGQDoWNJfcsSCTKp= FtHzUBemVuawEiqGQDoWNJfcsSCTIP.get(FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['program']['grade_code'])
     if 'broad_dt' in FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('schedule').get('program'):
      FtHzUBemVuawEiqGQDoWNJfcsSCTKg =FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('schedule').get('program').get('broad_dt')
      FtHzUBemVuawEiqGQDoWNJfcsSCTKA='%s-%s-%s'%(FtHzUBemVuawEiqGQDoWNJfcsSCTKg[:4],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[4:6],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[6:])
    except:
     FtHzUBemVuawEiqGQDoWNJfcsSCTjb
    FtHzUBemVuawEiqGQDoWNJfcsSCTPh=FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['broadcast_start_time'])[8:12]
    FtHzUBemVuawEiqGQDoWNJfcsSCTKx =FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTRv['schedule']['broadcast_end_time'])[8:12]
    FtHzUBemVuawEiqGQDoWNJfcsSCTKv={'channel':FtHzUBemVuawEiqGQDoWNJfcsSCTPv,'title':FtHzUBemVuawEiqGQDoWNJfcsSCTPY,'mediacode':FtHzUBemVuawEiqGQDoWNJfcsSCTPO,'thumbnail':{'poster':FtHzUBemVuawEiqGQDoWNJfcsSCTPk,'thumb':FtHzUBemVuawEiqGQDoWNJfcsSCTPl,'clearlogo':FtHzUBemVuawEiqGQDoWNJfcsSCTKI,'icon':FtHzUBemVuawEiqGQDoWNJfcsSCTKR,'fanart':FtHzUBemVuawEiqGQDoWNJfcsSCTKP},'synopsis':FtHzUBemVuawEiqGQDoWNJfcsSCTPM,'channelepg':' [%s:%s ~ %s:%s]'%(FtHzUBemVuawEiqGQDoWNJfcsSCTPh[0:2],FtHzUBemVuawEiqGQDoWNJfcsSCTPh[2:],FtHzUBemVuawEiqGQDoWNJfcsSCTKx[0:2],FtHzUBemVuawEiqGQDoWNJfcsSCTKx[2:]),'cast':FtHzUBemVuawEiqGQDoWNJfcsSCTKj,'director':FtHzUBemVuawEiqGQDoWNJfcsSCTKy,'info_genre':FtHzUBemVuawEiqGQDoWNJfcsSCTKX,'year':FtHzUBemVuawEiqGQDoWNJfcsSCTKL,'mpaa':FtHzUBemVuawEiqGQDoWNJfcsSCTKp,'premiered':FtHzUBemVuawEiqGQDoWNJfcsSCTKA}
    FtHzUBemVuawEiqGQDoWNJfcsSCTRA.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKv)
   if FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['has_more']=='Y':
    FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjv
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
 def GetProgramList(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,genre,orderby,page_int,genreCode='all'):
  FtHzUBemVuawEiqGQDoWNJfcsSCTRA=[]
  FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  try:
   if genre=='PARAMOUNT':
    FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v2/media/paramount/episodes'
   else:
    FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v2/media/episodes'
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams()
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'cacheType':'main','pageSize':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(page_int),}
   if genre not in['all','PARAMOUNT']:FtHzUBemVuawEiqGQDoWNJfcsSCTRg['categoryCode']=genre
   if genreCode!='all' :FtHzUBemVuawEiqGQDoWNJfcsSCTRg['genreCode'] =genreCode 
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk.update(FtHzUBemVuawEiqGQDoWNJfcsSCTRg)
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRL
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRk,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRx=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   if not('result' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']):return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
   FtHzUBemVuawEiqGQDoWNJfcsSCTPx=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['result']
   for FtHzUBemVuawEiqGQDoWNJfcsSCTRv in FtHzUBemVuawEiqGQDoWNJfcsSCTPx:
    FtHzUBemVuawEiqGQDoWNJfcsSCTKh=FtHzUBemVuawEiqGQDoWNJfcsSCTRv['program']['code']
    FtHzUBemVuawEiqGQDoWNJfcsSCTPY =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['program']['name']['ko']
    FtHzUBemVuawEiqGQDoWNJfcsSCTKp =FtHzUBemVuawEiqGQDoWNJfcsSCTIP.get(FtHzUBemVuawEiqGQDoWNJfcsSCTRv['program'].get('grade_code'))
    FtHzUBemVuawEiqGQDoWNJfcsSCTPk =''
    FtHzUBemVuawEiqGQDoWNJfcsSCTPl =''
    FtHzUBemVuawEiqGQDoWNJfcsSCTKI=''
    FtHzUBemVuawEiqGQDoWNJfcsSCTKR =''
    FtHzUBemVuawEiqGQDoWNJfcsSCTKr =''
    for FtHzUBemVuawEiqGQDoWNJfcsSCTKn in FtHzUBemVuawEiqGQDoWNJfcsSCTRv['program']['image']:
     if FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP0900':FtHzUBemVuawEiqGQDoWNJfcsSCTPk =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP0200':FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP1800':FtHzUBemVuawEiqGQDoWNJfcsSCTKI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP2000':FtHzUBemVuawEiqGQDoWNJfcsSCTKR =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP1900':FtHzUBemVuawEiqGQDoWNJfcsSCTKr =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
    FtHzUBemVuawEiqGQDoWNJfcsSCTPM =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['program']['synopsis']['ko']
    try:
     FtHzUBemVuawEiqGQDoWNJfcsSCTKO=FtHzUBemVuawEiqGQDoWNJfcsSCTRv['channel']['name']['ko']
    except:
     FtHzUBemVuawEiqGQDoWNJfcsSCTKO=''
    try:
     FtHzUBemVuawEiqGQDoWNJfcsSCTKj =[]
     FtHzUBemVuawEiqGQDoWNJfcsSCTKy=[]
     FtHzUBemVuawEiqGQDoWNJfcsSCTKX =[]
     FtHzUBemVuawEiqGQDoWNJfcsSCTKL =''
     FtHzUBemVuawEiqGQDoWNJfcsSCTKA=''
     for FtHzUBemVuawEiqGQDoWNJfcsSCTKd in FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('program').get('actor'):
      if FtHzUBemVuawEiqGQDoWNJfcsSCTKd!='' and FtHzUBemVuawEiqGQDoWNJfcsSCTKd!='-' and FtHzUBemVuawEiqGQDoWNJfcsSCTKd!=u'없음':FtHzUBemVuawEiqGQDoWNJfcsSCTKj.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKd)
     for FtHzUBemVuawEiqGQDoWNJfcsSCTKb in FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('program').get('director'):
      if FtHzUBemVuawEiqGQDoWNJfcsSCTKb!='' and FtHzUBemVuawEiqGQDoWNJfcsSCTKb!='-' and FtHzUBemVuawEiqGQDoWNJfcsSCTKb!=u'없음':FtHzUBemVuawEiqGQDoWNJfcsSCTKy.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKb)
     if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('program').get('category1_name').get('ko')!='':
      FtHzUBemVuawEiqGQDoWNJfcsSCTKX.append(FtHzUBemVuawEiqGQDoWNJfcsSCTRv['program']['category1_name']['ko'])
     if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('program').get('category2_name').get('ko')!='':
      FtHzUBemVuawEiqGQDoWNJfcsSCTKX.append(FtHzUBemVuawEiqGQDoWNJfcsSCTRv['program']['category2_name']['ko'])
     if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('program').get('product_year'):FtHzUBemVuawEiqGQDoWNJfcsSCTKL=FtHzUBemVuawEiqGQDoWNJfcsSCTRv['program']['product_year']
     if 'broad_dt' in FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('program'):
      FtHzUBemVuawEiqGQDoWNJfcsSCTKg =FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('program').get('broad_dt')
      FtHzUBemVuawEiqGQDoWNJfcsSCTKA='%s-%s-%s'%(FtHzUBemVuawEiqGQDoWNJfcsSCTKg[:4],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[4:6],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[6:])
    except:
     FtHzUBemVuawEiqGQDoWNJfcsSCTjb
    FtHzUBemVuawEiqGQDoWNJfcsSCTKv={'program':FtHzUBemVuawEiqGQDoWNJfcsSCTKh,'title':FtHzUBemVuawEiqGQDoWNJfcsSCTPY,'thumbnail':{'poster':FtHzUBemVuawEiqGQDoWNJfcsSCTPk,'thumb':FtHzUBemVuawEiqGQDoWNJfcsSCTPl,'clearlogo':FtHzUBemVuawEiqGQDoWNJfcsSCTKI,'icon':FtHzUBemVuawEiqGQDoWNJfcsSCTKR,'banner':FtHzUBemVuawEiqGQDoWNJfcsSCTKr,'fanart':FtHzUBemVuawEiqGQDoWNJfcsSCTPl},'synopsis':FtHzUBemVuawEiqGQDoWNJfcsSCTPM,'channel':FtHzUBemVuawEiqGQDoWNJfcsSCTKO,'cast':FtHzUBemVuawEiqGQDoWNJfcsSCTKj,'director':FtHzUBemVuawEiqGQDoWNJfcsSCTKy,'info_genre':FtHzUBemVuawEiqGQDoWNJfcsSCTKX,'year':FtHzUBemVuawEiqGQDoWNJfcsSCTKL,'premiered':FtHzUBemVuawEiqGQDoWNJfcsSCTKA,'mpaa':FtHzUBemVuawEiqGQDoWNJfcsSCTKp}
    FtHzUBemVuawEiqGQDoWNJfcsSCTRA.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKv)
   if FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['has_more']=='Y':FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjv
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
 def Get_UHD_ProgramList(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,page_int):
  FtHzUBemVuawEiqGQDoWNJfcsSCTRA=[]
  FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v2/operator/highlights'
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams(uhd=FtHzUBemVuawEiqGQDoWNJfcsSCTjv)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(page_int),'pocType':'APP_X_TVING_4.0.0',}
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk.update(FtHzUBemVuawEiqGQDoWNJfcsSCTRg)
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRL
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRk,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRx=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   if not('result' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']):return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
   FtHzUBemVuawEiqGQDoWNJfcsSCTPx=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['result']
   for FtHzUBemVuawEiqGQDoWNJfcsSCTRv in FtHzUBemVuawEiqGQDoWNJfcsSCTPx:
    FtHzUBemVuawEiqGQDoWNJfcsSCTKY=FtHzUBemVuawEiqGQDoWNJfcsSCTRv['content']['program']
    FtHzUBemVuawEiqGQDoWNJfcsSCTKM =FtHzUBemVuawEiqGQDoWNJfcsSCTKY['code']
    FtHzUBemVuawEiqGQDoWNJfcsSCTPY =FtHzUBemVuawEiqGQDoWNJfcsSCTKY['name']['ko'].strip()
    FtHzUBemVuawEiqGQDoWNJfcsSCTKp =FtHzUBemVuawEiqGQDoWNJfcsSCTIP.get(FtHzUBemVuawEiqGQDoWNJfcsSCTKY.get('grade_code'))
    FtHzUBemVuawEiqGQDoWNJfcsSCTPM =FtHzUBemVuawEiqGQDoWNJfcsSCTKY['synopsis']['ko']
    FtHzUBemVuawEiqGQDoWNJfcsSCTKO =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['content']['channel']['name']['ko']
    FtHzUBemVuawEiqGQDoWNJfcsSCTKL =FtHzUBemVuawEiqGQDoWNJfcsSCTKY['product_year']
    FtHzUBemVuawEiqGQDoWNJfcsSCTPk =''
    FtHzUBemVuawEiqGQDoWNJfcsSCTPl =''
    FtHzUBemVuawEiqGQDoWNJfcsSCTKI=''
    FtHzUBemVuawEiqGQDoWNJfcsSCTKR =''
    FtHzUBemVuawEiqGQDoWNJfcsSCTKr =''
    for FtHzUBemVuawEiqGQDoWNJfcsSCTKn in FtHzUBemVuawEiqGQDoWNJfcsSCTKY['image']:
     if FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP0900':FtHzUBemVuawEiqGQDoWNJfcsSCTPk =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP0200':FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP1800':FtHzUBemVuawEiqGQDoWNJfcsSCTKI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP2000':FtHzUBemVuawEiqGQDoWNJfcsSCTKR =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP1900':FtHzUBemVuawEiqGQDoWNJfcsSCTKr =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
    FtHzUBemVuawEiqGQDoWNJfcsSCTKX =[]
    FtHzUBemVuawEiqGQDoWNJfcsSCTKj =[]
    FtHzUBemVuawEiqGQDoWNJfcsSCTKy=[]
    FtHzUBemVuawEiqGQDoWNJfcsSCTKA =''
    if FtHzUBemVuawEiqGQDoWNJfcsSCTKY.get('category1_name').get('ko')!='':
     FtHzUBemVuawEiqGQDoWNJfcsSCTKX.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKY['category1_name']['ko'])
    if FtHzUBemVuawEiqGQDoWNJfcsSCTKY.get('category2_name').get('ko')!='':
     FtHzUBemVuawEiqGQDoWNJfcsSCTKX.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKY['category2_name']['ko'])
    for FtHzUBemVuawEiqGQDoWNJfcsSCTKd in FtHzUBemVuawEiqGQDoWNJfcsSCTKY.get('actor'):
     if FtHzUBemVuawEiqGQDoWNJfcsSCTKd!='' and FtHzUBemVuawEiqGQDoWNJfcsSCTKd!='-' and FtHzUBemVuawEiqGQDoWNJfcsSCTKd!=u'없음':FtHzUBemVuawEiqGQDoWNJfcsSCTKj.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKd)
    for FtHzUBemVuawEiqGQDoWNJfcsSCTKb in FtHzUBemVuawEiqGQDoWNJfcsSCTKY.get('director'):
     if FtHzUBemVuawEiqGQDoWNJfcsSCTKb!='' and FtHzUBemVuawEiqGQDoWNJfcsSCTKb!='-' and FtHzUBemVuawEiqGQDoWNJfcsSCTKb!=u'없음':FtHzUBemVuawEiqGQDoWNJfcsSCTKy.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKb)
    if FtHzUBemVuawEiqGQDoWNJfcsSCTKY.get('broad_dt')not in[FtHzUBemVuawEiqGQDoWNJfcsSCTjb,'']:
     FtHzUBemVuawEiqGQDoWNJfcsSCTKg =FtHzUBemVuawEiqGQDoWNJfcsSCTKY.get('broad_dt')
     FtHzUBemVuawEiqGQDoWNJfcsSCTKA='%s-%s-%s'%(FtHzUBemVuawEiqGQDoWNJfcsSCTKg[:4],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[4:6],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[6:])
    FtHzUBemVuawEiqGQDoWNJfcsSCTKv={'program':FtHzUBemVuawEiqGQDoWNJfcsSCTKM,'title':FtHzUBemVuawEiqGQDoWNJfcsSCTPY,'mpaa':FtHzUBemVuawEiqGQDoWNJfcsSCTKp,'thumbnail':{'poster':FtHzUBemVuawEiqGQDoWNJfcsSCTPk,'thumb':FtHzUBemVuawEiqGQDoWNJfcsSCTPl,'clearlogo':FtHzUBemVuawEiqGQDoWNJfcsSCTKI,'icon':FtHzUBemVuawEiqGQDoWNJfcsSCTKR,'banner':FtHzUBemVuawEiqGQDoWNJfcsSCTKr,'fanart':FtHzUBemVuawEiqGQDoWNJfcsSCTPl},'channel':FtHzUBemVuawEiqGQDoWNJfcsSCTKO,'synopsis':FtHzUBemVuawEiqGQDoWNJfcsSCTPM,'year':FtHzUBemVuawEiqGQDoWNJfcsSCTKL,'info_genre':FtHzUBemVuawEiqGQDoWNJfcsSCTKX,'cast':FtHzUBemVuawEiqGQDoWNJfcsSCTKj,'director':FtHzUBemVuawEiqGQDoWNJfcsSCTKy,'premiered':FtHzUBemVuawEiqGQDoWNJfcsSCTKA,}
    FtHzUBemVuawEiqGQDoWNJfcsSCTRA.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKv)
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
 def Get_Origianl_ProgramList(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,page_int):
  FtHzUBemVuawEiqGQDoWNJfcsSCTRA=[]
  FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v2/media/band/originals'
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams()
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'pageSize':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(page_int),}
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk.update(FtHzUBemVuawEiqGQDoWNJfcsSCTRg)
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRL
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRk,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRx=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   if not('contents' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']):return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
   FtHzUBemVuawEiqGQDoWNJfcsSCTPx=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['contents']
   for FtHzUBemVuawEiqGQDoWNJfcsSCTRv in FtHzUBemVuawEiqGQDoWNJfcsSCTPx:
    FtHzUBemVuawEiqGQDoWNJfcsSCTKh=FtHzUBemVuawEiqGQDoWNJfcsSCTRv['vod_code']
    FtHzUBemVuawEiqGQDoWNJfcsSCTPY =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['vod_name']
    FtHzUBemVuawEiqGQDoWNJfcsSCTPk =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRv['image']
    FtHzUBemVuawEiqGQDoWNJfcsSCTKv={'program':FtHzUBemVuawEiqGQDoWNJfcsSCTKh,'title':FtHzUBemVuawEiqGQDoWNJfcsSCTPY,'thumbnail':{'poster':FtHzUBemVuawEiqGQDoWNJfcsSCTPk,'thumb':FtHzUBemVuawEiqGQDoWNJfcsSCTPk}}
    FtHzUBemVuawEiqGQDoWNJfcsSCTRA.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKv)
   if FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['has_more']=='Y':FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjv
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
 def GetEpisodeList(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,program_code,page_int,orderby='desc'):
  FtHzUBemVuawEiqGQDoWNJfcsSCTRA=[]
  FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v2/media/frequency/program/'+program_code
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams()
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk.update(FtHzUBemVuawEiqGQDoWNJfcsSCTRg)
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRL
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRk,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRx=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   if not('result' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']):return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
   FtHzUBemVuawEiqGQDoWNJfcsSCTPx=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['result']
   FtHzUBemVuawEiqGQDoWNJfcsSCTKl=FtHzUBemVuawEiqGQDoWNJfcsSCTjh(FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['total_count'])
   FtHzUBemVuawEiqGQDoWNJfcsSCTKk =FtHzUBemVuawEiqGQDoWNJfcsSCTjh(FtHzUBemVuawEiqGQDoWNJfcsSCTKl//(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    FtHzUBemVuawEiqGQDoWNJfcsSCTnI =(FtHzUBemVuawEiqGQDoWNJfcsSCTKl-1)-((page_int-1)*FtHzUBemVuawEiqGQDoWNJfcsSCTIn.EPISODE_LIMIT)
   else:
    FtHzUBemVuawEiqGQDoWNJfcsSCTnI =(page_int-1)*FtHzUBemVuawEiqGQDoWNJfcsSCTIn.EPISODE_LIMIT
   for i in FtHzUBemVuawEiqGQDoWNJfcsSCTjO(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.EPISODE_LIMIT):
    if orderby=='desc':
     FtHzUBemVuawEiqGQDoWNJfcsSCTnR=FtHzUBemVuawEiqGQDoWNJfcsSCTnI-i
     if FtHzUBemVuawEiqGQDoWNJfcsSCTnR<0:break
    else:
     FtHzUBemVuawEiqGQDoWNJfcsSCTnR=FtHzUBemVuawEiqGQDoWNJfcsSCTnI+i
     if FtHzUBemVuawEiqGQDoWNJfcsSCTnR>=FtHzUBemVuawEiqGQDoWNJfcsSCTKl:break
    FtHzUBemVuawEiqGQDoWNJfcsSCTnr=FtHzUBemVuawEiqGQDoWNJfcsSCTPx[FtHzUBemVuawEiqGQDoWNJfcsSCTnR]['episode']['code']
    FtHzUBemVuawEiqGQDoWNJfcsSCTPY =FtHzUBemVuawEiqGQDoWNJfcsSCTPx[FtHzUBemVuawEiqGQDoWNJfcsSCTnR]['vod_name']['ko']
    FtHzUBemVuawEiqGQDoWNJfcsSCTnP =''
    try:
     FtHzUBemVuawEiqGQDoWNJfcsSCTKg=FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTPx[FtHzUBemVuawEiqGQDoWNJfcsSCTnR]['episode']['broadcast_date'])
     FtHzUBemVuawEiqGQDoWNJfcsSCTnP='%s-%s-%s'%(FtHzUBemVuawEiqGQDoWNJfcsSCTKg[:4],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[4:6],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[6:])
    except:
     FtHzUBemVuawEiqGQDoWNJfcsSCTjb
    try:
     if FtHzUBemVuawEiqGQDoWNJfcsSCTPx[FtHzUBemVuawEiqGQDoWNJfcsSCTnR]['episode']['pip_cliptype']=='C012':
      FtHzUBemVuawEiqGQDoWNJfcsSCTnP+=' - Quick VOD'
    except:
     FtHzUBemVuawEiqGQDoWNJfcsSCTjb
    FtHzUBemVuawEiqGQDoWNJfcsSCTPM =FtHzUBemVuawEiqGQDoWNJfcsSCTPx[FtHzUBemVuawEiqGQDoWNJfcsSCTnR]['episode']['synopsis']['ko']
    FtHzUBemVuawEiqGQDoWNJfcsSCTPk =''
    FtHzUBemVuawEiqGQDoWNJfcsSCTPl =''
    FtHzUBemVuawEiqGQDoWNJfcsSCTKI=''
    FtHzUBemVuawEiqGQDoWNJfcsSCTKR =''
    FtHzUBemVuawEiqGQDoWNJfcsSCTKr =''
    FtHzUBemVuawEiqGQDoWNJfcsSCTKP =''
    for FtHzUBemVuawEiqGQDoWNJfcsSCTKn in FtHzUBemVuawEiqGQDoWNJfcsSCTPx[FtHzUBemVuawEiqGQDoWNJfcsSCTnR]['program']['image']:
     if FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP0900':FtHzUBemVuawEiqGQDoWNJfcsSCTPk =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP1800':FtHzUBemVuawEiqGQDoWNJfcsSCTKI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP2000':FtHzUBemVuawEiqGQDoWNJfcsSCTKR =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP1900':FtHzUBemVuawEiqGQDoWNJfcsSCTKr =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIP0200':FtHzUBemVuawEiqGQDoWNJfcsSCTKP =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
    for FtHzUBemVuawEiqGQDoWNJfcsSCTKn in FtHzUBemVuawEiqGQDoWNJfcsSCTPx[FtHzUBemVuawEiqGQDoWNJfcsSCTnR]['episode']['image']:
     if FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIE0400':FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
    try:
     FtHzUBemVuawEiqGQDoWNJfcsSCTnK=FtHzUBemVuawEiqGQDoWNJfcsSCTny=FtHzUBemVuawEiqGQDoWNJfcsSCTnX=''
     FtHzUBemVuawEiqGQDoWNJfcsSCTnj=0
     FtHzUBemVuawEiqGQDoWNJfcsSCTnK =FtHzUBemVuawEiqGQDoWNJfcsSCTPx[FtHzUBemVuawEiqGQDoWNJfcsSCTnR]['program']['name']['ko']
     FtHzUBemVuawEiqGQDoWNJfcsSCTny =FtHzUBemVuawEiqGQDoWNJfcsSCTnP
     FtHzUBemVuawEiqGQDoWNJfcsSCTnX =FtHzUBemVuawEiqGQDoWNJfcsSCTPx[FtHzUBemVuawEiqGQDoWNJfcsSCTnR]['channel']['name']['ko']
     if 'frequency' in FtHzUBemVuawEiqGQDoWNJfcsSCTPx[FtHzUBemVuawEiqGQDoWNJfcsSCTnR]['episode']:FtHzUBemVuawEiqGQDoWNJfcsSCTnj=FtHzUBemVuawEiqGQDoWNJfcsSCTPx[FtHzUBemVuawEiqGQDoWNJfcsSCTnR]['episode']['frequency']
    except:
     FtHzUBemVuawEiqGQDoWNJfcsSCTjb
    FtHzUBemVuawEiqGQDoWNJfcsSCTKv={'episode':FtHzUBemVuawEiqGQDoWNJfcsSCTnr,'title':FtHzUBemVuawEiqGQDoWNJfcsSCTPY,'subtitle':FtHzUBemVuawEiqGQDoWNJfcsSCTnP,'thumbnail':{'poster':FtHzUBemVuawEiqGQDoWNJfcsSCTPk,'thumb':FtHzUBemVuawEiqGQDoWNJfcsSCTPl,'clearlogo':FtHzUBemVuawEiqGQDoWNJfcsSCTKI,'icon':FtHzUBemVuawEiqGQDoWNJfcsSCTKR,'banner':FtHzUBemVuawEiqGQDoWNJfcsSCTKr,'fanart':FtHzUBemVuawEiqGQDoWNJfcsSCTKP},'synopsis':FtHzUBemVuawEiqGQDoWNJfcsSCTPM,'info_title':FtHzUBemVuawEiqGQDoWNJfcsSCTnK,'aired':FtHzUBemVuawEiqGQDoWNJfcsSCTny,'studio':FtHzUBemVuawEiqGQDoWNJfcsSCTnX,'frequency':FtHzUBemVuawEiqGQDoWNJfcsSCTnj}
    FtHzUBemVuawEiqGQDoWNJfcsSCTRA.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKv)
   if FtHzUBemVuawEiqGQDoWNJfcsSCTKk>page_int:FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjv
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb,FtHzUBemVuawEiqGQDoWNJfcsSCTKk
 def GetMovieList(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,genre,orderby,page_int):
  FtHzUBemVuawEiqGQDoWNJfcsSCTRA=[]
  FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  try:
   if genre=='PARAMOUNT':
    FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v2/media/paramount/movies'
   else:
    FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v2/media/movies'
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams()
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'pageSize':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:FtHzUBemVuawEiqGQDoWNJfcsSCTRg['categoryCode']=genre
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg['productPackageCode']=','.join(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.MOVIE_LITE)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk.update(FtHzUBemVuawEiqGQDoWNJfcsSCTRg)
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRL
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRk,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRx=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   if not('result' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']):return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
   FtHzUBemVuawEiqGQDoWNJfcsSCTPx=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['result']
   for FtHzUBemVuawEiqGQDoWNJfcsSCTRv in FtHzUBemVuawEiqGQDoWNJfcsSCTPx:
    if 'release_date' in FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('movie'):
     FtHzUBemVuawEiqGQDoWNJfcsSCTKL=FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('movie').get('release_date'))[:4]
    else:
     FtHzUBemVuawEiqGQDoWNJfcsSCTKL=FtHzUBemVuawEiqGQDoWNJfcsSCTjb
    FtHzUBemVuawEiqGQDoWNJfcsSCTnL =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['movie']['code']
    FtHzUBemVuawEiqGQDoWNJfcsSCTPY =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['movie']['name']['ko'].strip()
    if FtHzUBemVuawEiqGQDoWNJfcsSCTKL not in[FtHzUBemVuawEiqGQDoWNJfcsSCTjb,'0','']:FtHzUBemVuawEiqGQDoWNJfcsSCTPY+=u' (%s)'%(FtHzUBemVuawEiqGQDoWNJfcsSCTKL)
    FtHzUBemVuawEiqGQDoWNJfcsSCTPk=''
    FtHzUBemVuawEiqGQDoWNJfcsSCTPl =''
    FtHzUBemVuawEiqGQDoWNJfcsSCTKI=''
    for FtHzUBemVuawEiqGQDoWNJfcsSCTKn in FtHzUBemVuawEiqGQDoWNJfcsSCTRv['movie']['image']:
     if FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIM2100':FtHzUBemVuawEiqGQDoWNJfcsSCTPk =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIM0400':FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIM1800':FtHzUBemVuawEiqGQDoWNJfcsSCTKI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
    FtHzUBemVuawEiqGQDoWNJfcsSCTPM =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['movie']['story']['ko']
    try:
     FtHzUBemVuawEiqGQDoWNJfcsSCTnK =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['movie']['name']['ko'].strip()
     FtHzUBemVuawEiqGQDoWNJfcsSCTKp =FtHzUBemVuawEiqGQDoWNJfcsSCTIP.get(FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('grade_code'))
     FtHzUBemVuawEiqGQDoWNJfcsSCTKj=[]
     FtHzUBemVuawEiqGQDoWNJfcsSCTKy=[]
     FtHzUBemVuawEiqGQDoWNJfcsSCTKX=[]
     FtHzUBemVuawEiqGQDoWNJfcsSCTnp=0
     FtHzUBemVuawEiqGQDoWNJfcsSCTKA=''
     FtHzUBemVuawEiqGQDoWNJfcsSCTnX =''
     for FtHzUBemVuawEiqGQDoWNJfcsSCTKd in FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('movie').get('actor'):
      if FtHzUBemVuawEiqGQDoWNJfcsSCTKd!='':FtHzUBemVuawEiqGQDoWNJfcsSCTKj.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKd)
     for FtHzUBemVuawEiqGQDoWNJfcsSCTKb in FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('movie').get('director'):
      if FtHzUBemVuawEiqGQDoWNJfcsSCTKb!='':FtHzUBemVuawEiqGQDoWNJfcsSCTKy.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKb)
     if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('movie').get('category1_name').get('ko')!='':
      FtHzUBemVuawEiqGQDoWNJfcsSCTKX.append(FtHzUBemVuawEiqGQDoWNJfcsSCTRv['movie']['category1_name']['ko'])
     if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('movie').get('category2_name').get('ko')!='':
      FtHzUBemVuawEiqGQDoWNJfcsSCTKX.append(FtHzUBemVuawEiqGQDoWNJfcsSCTRv['movie']['category2_name']['ko'])
     if 'duration' in FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('movie'):FtHzUBemVuawEiqGQDoWNJfcsSCTnp=FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('movie').get('duration')
     if 'release_date' in FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('movie'):
      FtHzUBemVuawEiqGQDoWNJfcsSCTKg=FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('movie').get('release_date'))
      if FtHzUBemVuawEiqGQDoWNJfcsSCTKg!='0':FtHzUBemVuawEiqGQDoWNJfcsSCTKA='%s-%s-%s'%(FtHzUBemVuawEiqGQDoWNJfcsSCTKg[:4],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[4:6],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[6:])
     if 'production' in FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('movie'):FtHzUBemVuawEiqGQDoWNJfcsSCTnX=FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('movie').get('production')
    except:
     FtHzUBemVuawEiqGQDoWNJfcsSCTjb
    FtHzUBemVuawEiqGQDoWNJfcsSCTKv={'moviecode':FtHzUBemVuawEiqGQDoWNJfcsSCTnL,'title':FtHzUBemVuawEiqGQDoWNJfcsSCTPY,'thumbnail':{'poster':FtHzUBemVuawEiqGQDoWNJfcsSCTPk,'thumb':FtHzUBemVuawEiqGQDoWNJfcsSCTPl,'clearlogo':FtHzUBemVuawEiqGQDoWNJfcsSCTKI,'fanart':FtHzUBemVuawEiqGQDoWNJfcsSCTPl},'synopsis':FtHzUBemVuawEiqGQDoWNJfcsSCTPM,'info_title':FtHzUBemVuawEiqGQDoWNJfcsSCTnK,'year':FtHzUBemVuawEiqGQDoWNJfcsSCTKL,'cast':FtHzUBemVuawEiqGQDoWNJfcsSCTKj,'director':FtHzUBemVuawEiqGQDoWNJfcsSCTKy,'info_genre':FtHzUBemVuawEiqGQDoWNJfcsSCTKX,'duration':FtHzUBemVuawEiqGQDoWNJfcsSCTnp,'premiered':FtHzUBemVuawEiqGQDoWNJfcsSCTKA,'studio':FtHzUBemVuawEiqGQDoWNJfcsSCTnX,'mpaa':FtHzUBemVuawEiqGQDoWNJfcsSCTKp}
    FtHzUBemVuawEiqGQDoWNJfcsSCTnA=FtHzUBemVuawEiqGQDoWNJfcsSCTjg
    for FtHzUBemVuawEiqGQDoWNJfcsSCTnd in FtHzUBemVuawEiqGQDoWNJfcsSCTRv['billing_package_id']:
     if FtHzUBemVuawEiqGQDoWNJfcsSCTnd in FtHzUBemVuawEiqGQDoWNJfcsSCTIn.MOVIE_LITE:
      FtHzUBemVuawEiqGQDoWNJfcsSCTnA=FtHzUBemVuawEiqGQDoWNJfcsSCTjv
      break
    if FtHzUBemVuawEiqGQDoWNJfcsSCTnA==FtHzUBemVuawEiqGQDoWNJfcsSCTjg: 
     FtHzUBemVuawEiqGQDoWNJfcsSCTKv['title']=FtHzUBemVuawEiqGQDoWNJfcsSCTKv['title']+' [개별구매]'
    FtHzUBemVuawEiqGQDoWNJfcsSCTRA.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKv)
   if FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['has_more']=='Y':FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjv
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
 def Get_UHD_MovieList(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,page_int):
  FtHzUBemVuawEiqGQDoWNJfcsSCTRA=[]
  FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v2/operator/highlights'
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams(uhd=FtHzUBemVuawEiqGQDoWNJfcsSCTjv)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(page_int),'pocType':'APP_X_TVING_4.0.0',}
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk.update(FtHzUBemVuawEiqGQDoWNJfcsSCTRg)
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRL
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRk,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRx=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   if not('result' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']):return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
   FtHzUBemVuawEiqGQDoWNJfcsSCTPx=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['result']
   for FtHzUBemVuawEiqGQDoWNJfcsSCTRv in FtHzUBemVuawEiqGQDoWNJfcsSCTPx:
    FtHzUBemVuawEiqGQDoWNJfcsSCTKY=FtHzUBemVuawEiqGQDoWNJfcsSCTRv['content']['movie']
    FtHzUBemVuawEiqGQDoWNJfcsSCTKM =FtHzUBemVuawEiqGQDoWNJfcsSCTKY['code']
    FtHzUBemVuawEiqGQDoWNJfcsSCTPY =FtHzUBemVuawEiqGQDoWNJfcsSCTKY['name']['ko'].strip()
    FtHzUBemVuawEiqGQDoWNJfcsSCTnK =FtHzUBemVuawEiqGQDoWNJfcsSCTKY['name']['ko'].strip()
    FtHzUBemVuawEiqGQDoWNJfcsSCTKL =FtHzUBemVuawEiqGQDoWNJfcsSCTKY['product_year']
    if FtHzUBemVuawEiqGQDoWNJfcsSCTKL:FtHzUBemVuawEiqGQDoWNJfcsSCTPY+=u' (%s)'%(FtHzUBemVuawEiqGQDoWNJfcsSCTKY['product_year'])
    FtHzUBemVuawEiqGQDoWNJfcsSCTPM =FtHzUBemVuawEiqGQDoWNJfcsSCTKY['story']['ko']
    FtHzUBemVuawEiqGQDoWNJfcsSCTnp =FtHzUBemVuawEiqGQDoWNJfcsSCTKY['duration']
    FtHzUBemVuawEiqGQDoWNJfcsSCTKp =FtHzUBemVuawEiqGQDoWNJfcsSCTIP.get(FtHzUBemVuawEiqGQDoWNJfcsSCTKY.get('grade_code'))
    FtHzUBemVuawEiqGQDoWNJfcsSCTnX =FtHzUBemVuawEiqGQDoWNJfcsSCTKY['production']
    FtHzUBemVuawEiqGQDoWNJfcsSCTPk=''
    FtHzUBemVuawEiqGQDoWNJfcsSCTPl =''
    FtHzUBemVuawEiqGQDoWNJfcsSCTKI=''
    FtHzUBemVuawEiqGQDoWNJfcsSCTKX =[]
    FtHzUBemVuawEiqGQDoWNJfcsSCTKj =[]
    FtHzUBemVuawEiqGQDoWNJfcsSCTKy=[]
    FtHzUBemVuawEiqGQDoWNJfcsSCTKA =''
    for FtHzUBemVuawEiqGQDoWNJfcsSCTKn in FtHzUBemVuawEiqGQDoWNJfcsSCTKY['image']:
     if FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIM2100':FtHzUBemVuawEiqGQDoWNJfcsSCTPk =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIM0400':FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
     elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn['code']=='CAIM1800':FtHzUBemVuawEiqGQDoWNJfcsSCTKI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn['url']
    if FtHzUBemVuawEiqGQDoWNJfcsSCTKY['release_date']not in[FtHzUBemVuawEiqGQDoWNJfcsSCTjb,0]:
     FtHzUBemVuawEiqGQDoWNJfcsSCTKg=FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTKY['release_date'])
     if FtHzUBemVuawEiqGQDoWNJfcsSCTKg!='0':FtHzUBemVuawEiqGQDoWNJfcsSCTKA='%s-%s-%s'%(FtHzUBemVuawEiqGQDoWNJfcsSCTKg[:4],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[4:6],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[6:])
    if FtHzUBemVuawEiqGQDoWNJfcsSCTKY.get('category1_name').get('ko')!='':
     FtHzUBemVuawEiqGQDoWNJfcsSCTKX.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKY['category1_name']['ko'])
    if FtHzUBemVuawEiqGQDoWNJfcsSCTKY.get('category2_name').get('ko')!='':
     FtHzUBemVuawEiqGQDoWNJfcsSCTKX.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKY['category2_name']['ko'])
    for FtHzUBemVuawEiqGQDoWNJfcsSCTKd in FtHzUBemVuawEiqGQDoWNJfcsSCTKY.get('actor'):
     if FtHzUBemVuawEiqGQDoWNJfcsSCTKd!='':FtHzUBemVuawEiqGQDoWNJfcsSCTKj.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKd)
    for FtHzUBemVuawEiqGQDoWNJfcsSCTKb in FtHzUBemVuawEiqGQDoWNJfcsSCTKY.get('director'):
     if FtHzUBemVuawEiqGQDoWNJfcsSCTKb!='':FtHzUBemVuawEiqGQDoWNJfcsSCTKy.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKb)
    FtHzUBemVuawEiqGQDoWNJfcsSCTKv={'moviecode':FtHzUBemVuawEiqGQDoWNJfcsSCTKM,'title':FtHzUBemVuawEiqGQDoWNJfcsSCTPY,'thumbnail':{'poster':FtHzUBemVuawEiqGQDoWNJfcsSCTPk,'thumb':FtHzUBemVuawEiqGQDoWNJfcsSCTPl,'clearlogo':FtHzUBemVuawEiqGQDoWNJfcsSCTKI,'fanart':FtHzUBemVuawEiqGQDoWNJfcsSCTPl},'year':FtHzUBemVuawEiqGQDoWNJfcsSCTKL,'info_title':FtHzUBemVuawEiqGQDoWNJfcsSCTnK,'synopsis':FtHzUBemVuawEiqGQDoWNJfcsSCTPM,'mpaa':FtHzUBemVuawEiqGQDoWNJfcsSCTKp,'duration':FtHzUBemVuawEiqGQDoWNJfcsSCTnp,'premiered':FtHzUBemVuawEiqGQDoWNJfcsSCTKA,'studio':FtHzUBemVuawEiqGQDoWNJfcsSCTnX,'info_genre':FtHzUBemVuawEiqGQDoWNJfcsSCTKX,'cast':FtHzUBemVuawEiqGQDoWNJfcsSCTKj,'director':FtHzUBemVuawEiqGQDoWNJfcsSCTKy,}
    FtHzUBemVuawEiqGQDoWNJfcsSCTRA.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKv)
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
 def GetMovieGenre(FtHzUBemVuawEiqGQDoWNJfcsSCTIn):
  FtHzUBemVuawEiqGQDoWNJfcsSCTRA=[]
  FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v2/media/movie/curations'
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams()
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk.update(FtHzUBemVuawEiqGQDoWNJfcsSCTRg)
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRL
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRk,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRx=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   if not('result' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']):return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
   FtHzUBemVuawEiqGQDoWNJfcsSCTPx=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['result']
   for FtHzUBemVuawEiqGQDoWNJfcsSCTRv in FtHzUBemVuawEiqGQDoWNJfcsSCTPx:
    FtHzUBemVuawEiqGQDoWNJfcsSCTnb =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['curation_code']
    FtHzUBemVuawEiqGQDoWNJfcsSCTng =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['curation_name']
    FtHzUBemVuawEiqGQDoWNJfcsSCTKv={'curation_code':FtHzUBemVuawEiqGQDoWNJfcsSCTnb,'curation_name':FtHzUBemVuawEiqGQDoWNJfcsSCTng}
    FtHzUBemVuawEiqGQDoWNJfcsSCTRA.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKv)
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
 def GetSearchList(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,search_key,page_int,stype):
  FtHzUBemVuawEiqGQDoWNJfcsSCTnx=[]
  FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjg
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/search/getSearch.jsp'
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(page_int),'pageSize':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.SCREENCODE,'os':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.OSCODE,'network':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':''}
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.SEARCH_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRL
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRg,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRx=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   if stype=='vod':
    if not('programRsb' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx):return FtHzUBemVuawEiqGQDoWNJfcsSCTnx,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
    FtHzUBemVuawEiqGQDoWNJfcsSCTnv=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['programRsb']['dataList']
    FtHzUBemVuawEiqGQDoWNJfcsSCTnh =FtHzUBemVuawEiqGQDoWNJfcsSCTjh(FtHzUBemVuawEiqGQDoWNJfcsSCTRx['programRsb']['count'])
    for FtHzUBemVuawEiqGQDoWNJfcsSCTRv in FtHzUBemVuawEiqGQDoWNJfcsSCTnv:
     FtHzUBemVuawEiqGQDoWNJfcsSCTKh=FtHzUBemVuawEiqGQDoWNJfcsSCTRv['mast_cd']
     FtHzUBemVuawEiqGQDoWNJfcsSCTPY =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['mast_nm']
     FtHzUBemVuawEiqGQDoWNJfcsSCTPk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRv['web_url4']
     FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRv['web_url']
     try:
      FtHzUBemVuawEiqGQDoWNJfcsSCTKj =[]
      FtHzUBemVuawEiqGQDoWNJfcsSCTKy=[]
      FtHzUBemVuawEiqGQDoWNJfcsSCTKX =[]
      FtHzUBemVuawEiqGQDoWNJfcsSCTnp =0
      FtHzUBemVuawEiqGQDoWNJfcsSCTKp =''
      FtHzUBemVuawEiqGQDoWNJfcsSCTKL =''
      FtHzUBemVuawEiqGQDoWNJfcsSCTny =''
      if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('actor') !='' and FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('actor') !='-':FtHzUBemVuawEiqGQDoWNJfcsSCTKj =FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('actor').split(',')
      if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('director')!='' and FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('director')!='-':FtHzUBemVuawEiqGQDoWNJfcsSCTKy=FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('director').split(',')
      if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('cate_nm')!='' and FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('cate_nm')!='-':FtHzUBemVuawEiqGQDoWNJfcsSCTKX =FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('cate_nm').split('/')
      if 'targetage' in FtHzUBemVuawEiqGQDoWNJfcsSCTRv:FtHzUBemVuawEiqGQDoWNJfcsSCTKp=FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('targetage')
      if 'broad_dt' in FtHzUBemVuawEiqGQDoWNJfcsSCTRv:
       FtHzUBemVuawEiqGQDoWNJfcsSCTKg=FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('broad_dt')
       FtHzUBemVuawEiqGQDoWNJfcsSCTny='%s-%s-%s'%(FtHzUBemVuawEiqGQDoWNJfcsSCTKg[:4],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[4:6],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[6:])
       FtHzUBemVuawEiqGQDoWNJfcsSCTKL =FtHzUBemVuawEiqGQDoWNJfcsSCTKg[:4]
     except:
      FtHzUBemVuawEiqGQDoWNJfcsSCTjb
     FtHzUBemVuawEiqGQDoWNJfcsSCTKv={'program':FtHzUBemVuawEiqGQDoWNJfcsSCTKh,'title':FtHzUBemVuawEiqGQDoWNJfcsSCTPY,'thumbnail':{'poster':FtHzUBemVuawEiqGQDoWNJfcsSCTPk,'thumb':FtHzUBemVuawEiqGQDoWNJfcsSCTPl,'fanart':FtHzUBemVuawEiqGQDoWNJfcsSCTPl},'synopsis':'','cast':FtHzUBemVuawEiqGQDoWNJfcsSCTKj,'director':FtHzUBemVuawEiqGQDoWNJfcsSCTKy,'info_genre':FtHzUBemVuawEiqGQDoWNJfcsSCTKX,'duration':FtHzUBemVuawEiqGQDoWNJfcsSCTnp,'mpaa':FtHzUBemVuawEiqGQDoWNJfcsSCTKp,'year':FtHzUBemVuawEiqGQDoWNJfcsSCTKL,'aired':FtHzUBemVuawEiqGQDoWNJfcsSCTny}
     FtHzUBemVuawEiqGQDoWNJfcsSCTnx.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKv)
   else:
    if not('vodMVRsb' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx):return FtHzUBemVuawEiqGQDoWNJfcsSCTnx,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
    FtHzUBemVuawEiqGQDoWNJfcsSCTnO=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['vodMVRsb']['dataList']
    FtHzUBemVuawEiqGQDoWNJfcsSCTnh =FtHzUBemVuawEiqGQDoWNJfcsSCTjh(FtHzUBemVuawEiqGQDoWNJfcsSCTRx['vodMVRsb']['count'])
    for FtHzUBemVuawEiqGQDoWNJfcsSCTRv in FtHzUBemVuawEiqGQDoWNJfcsSCTnO:
     FtHzUBemVuawEiqGQDoWNJfcsSCTKh=FtHzUBemVuawEiqGQDoWNJfcsSCTRv['mast_cd']
     FtHzUBemVuawEiqGQDoWNJfcsSCTPY =FtHzUBemVuawEiqGQDoWNJfcsSCTRv['mast_nm'].strip()
     FtHzUBemVuawEiqGQDoWNJfcsSCTPk =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRv['web_url']
     FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTPk
     FtHzUBemVuawEiqGQDoWNJfcsSCTKI=''
     try:
      FtHzUBemVuawEiqGQDoWNJfcsSCTKj =[]
      FtHzUBemVuawEiqGQDoWNJfcsSCTKy=[]
      FtHzUBemVuawEiqGQDoWNJfcsSCTKX =[]
      FtHzUBemVuawEiqGQDoWNJfcsSCTnp =0
      FtHzUBemVuawEiqGQDoWNJfcsSCTKp =''
      FtHzUBemVuawEiqGQDoWNJfcsSCTKL =''
      FtHzUBemVuawEiqGQDoWNJfcsSCTny =''
      if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('actor') !='' and FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('actor') !='-':FtHzUBemVuawEiqGQDoWNJfcsSCTKj =FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('actor').split(',')
      if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('director')!='' and FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('director')!='-':FtHzUBemVuawEiqGQDoWNJfcsSCTKy=FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('director').split(',')
      if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('cate_nm')!='' and FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('cate_nm')!='-':FtHzUBemVuawEiqGQDoWNJfcsSCTKX =FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('cate_nm').split('/')
      if FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('runtime_sec')!='':FtHzUBemVuawEiqGQDoWNJfcsSCTnp=FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('runtime_sec')
      if 'grade_nm' in FtHzUBemVuawEiqGQDoWNJfcsSCTRv:FtHzUBemVuawEiqGQDoWNJfcsSCTKp=FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('grade_nm')
      FtHzUBemVuawEiqGQDoWNJfcsSCTKg=FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('broad_dt')
      if data_str!='':
       FtHzUBemVuawEiqGQDoWNJfcsSCTny='%s-%s-%s'%(FtHzUBemVuawEiqGQDoWNJfcsSCTKg[:4],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[4:6],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[6:])
       FtHzUBemVuawEiqGQDoWNJfcsSCTKL =FtHzUBemVuawEiqGQDoWNJfcsSCTKg[:4]
     except:
      FtHzUBemVuawEiqGQDoWNJfcsSCTjb
     FtHzUBemVuawEiqGQDoWNJfcsSCTKv={'movie':FtHzUBemVuawEiqGQDoWNJfcsSCTKh,'title':FtHzUBemVuawEiqGQDoWNJfcsSCTPY,'thumbnail':{'poster':FtHzUBemVuawEiqGQDoWNJfcsSCTPk,'thumb':FtHzUBemVuawEiqGQDoWNJfcsSCTPl,'fanart':FtHzUBemVuawEiqGQDoWNJfcsSCTPl,'clearlogo':FtHzUBemVuawEiqGQDoWNJfcsSCTKI},'synopsis':'','cast':FtHzUBemVuawEiqGQDoWNJfcsSCTKj,'director':FtHzUBemVuawEiqGQDoWNJfcsSCTKy,'info_genre':FtHzUBemVuawEiqGQDoWNJfcsSCTKX,'duration':FtHzUBemVuawEiqGQDoWNJfcsSCTnp,'mpaa':FtHzUBemVuawEiqGQDoWNJfcsSCTKp,'year':FtHzUBemVuawEiqGQDoWNJfcsSCTKL,'aired':FtHzUBemVuawEiqGQDoWNJfcsSCTny}
     FtHzUBemVuawEiqGQDoWNJfcsSCTnA=FtHzUBemVuawEiqGQDoWNJfcsSCTjg
     for FtHzUBemVuawEiqGQDoWNJfcsSCTnd in FtHzUBemVuawEiqGQDoWNJfcsSCTRv['bill']:
      if FtHzUBemVuawEiqGQDoWNJfcsSCTnd in FtHzUBemVuawEiqGQDoWNJfcsSCTIn.MOVIE_LITE:
       FtHzUBemVuawEiqGQDoWNJfcsSCTnA=FtHzUBemVuawEiqGQDoWNJfcsSCTjv
       break
     if FtHzUBemVuawEiqGQDoWNJfcsSCTnA==FtHzUBemVuawEiqGQDoWNJfcsSCTjg: 
      FtHzUBemVuawEiqGQDoWNJfcsSCTKv['title']=FtHzUBemVuawEiqGQDoWNJfcsSCTKv['title']+' [개별구매]'
     FtHzUBemVuawEiqGQDoWNJfcsSCTnx.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKv)
   if FtHzUBemVuawEiqGQDoWNJfcsSCTnh>(page_int*FtHzUBemVuawEiqGQDoWNJfcsSCTIn.SEARCH_LIMIT):FtHzUBemVuawEiqGQDoWNJfcsSCTPb=FtHzUBemVuawEiqGQDoWNJfcsSCTjv
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTnx,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
 def GetBookmarkInfo(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,videoid,vidtype):
  FtHzUBemVuawEiqGQDoWNJfcsSCTnY={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+'/v2/media/program/'+videoid
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams()
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'pageNo':'1','pageSize':'10','order':'name',}
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk.update(FtHzUBemVuawEiqGQDoWNJfcsSCTRg)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRk,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb)
   FtHzUBemVuawEiqGQDoWNJfcsSCTnM=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   if not('body' in FtHzUBemVuawEiqGQDoWNJfcsSCTnM):return{}
   FtHzUBemVuawEiqGQDoWNJfcsSCTnl=FtHzUBemVuawEiqGQDoWNJfcsSCTnM['body']
   FtHzUBemVuawEiqGQDoWNJfcsSCTPY=FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('name').get('ko').strip()
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['title'] =FtHzUBemVuawEiqGQDoWNJfcsSCTPY
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['title']=FtHzUBemVuawEiqGQDoWNJfcsSCTPY
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['mpaa'] =FtHzUBemVuawEiqGQDoWNJfcsSCTIP.get(FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('grade_code'))
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['plot'] =FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('synopsis').get('ko')
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['year'] =FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('product_year')
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['cast'] =FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('actor')
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['director']=FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('director')
   if FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('category1_name').get('ko')!='':
    FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['genre'].append(FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('category1_name').get('ko'))
   if FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('category2_name').get('ko')!='':
    FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['genre'].append(FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('category2_name').get('ko'))
   FtHzUBemVuawEiqGQDoWNJfcsSCTKg=FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('broad_dt'))
   if FtHzUBemVuawEiqGQDoWNJfcsSCTKg!='0':FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(FtHzUBemVuawEiqGQDoWNJfcsSCTKg[:4],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[4:6],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[6:])
   FtHzUBemVuawEiqGQDoWNJfcsSCTPk =''
   FtHzUBemVuawEiqGQDoWNJfcsSCTPl =''
   FtHzUBemVuawEiqGQDoWNJfcsSCTKI=''
   FtHzUBemVuawEiqGQDoWNJfcsSCTKR =''
   FtHzUBemVuawEiqGQDoWNJfcsSCTKr =''
   for FtHzUBemVuawEiqGQDoWNJfcsSCTKn in FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('image'):
    if FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('code')=='CAIP0900':FtHzUBemVuawEiqGQDoWNJfcsSCTPk =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('url')
    elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('code')=='CAIP0200':FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('url')
    elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('code')=='CAIP1800':FtHzUBemVuawEiqGQDoWNJfcsSCTKI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('url')
    elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('code')=='CAIP2000':FtHzUBemVuawEiqGQDoWNJfcsSCTKR =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('url')
    elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('code')=='CAIP1900':FtHzUBemVuawEiqGQDoWNJfcsSCTKr =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('url')
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['thumbnail']['poster']=FtHzUBemVuawEiqGQDoWNJfcsSCTPk
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['thumbnail']['thumb']=FtHzUBemVuawEiqGQDoWNJfcsSCTPl
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['thumbnail']['clearlogo']=FtHzUBemVuawEiqGQDoWNJfcsSCTKI
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['thumbnail']['icon']=FtHzUBemVuawEiqGQDoWNJfcsSCTKR
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['thumbnail']['banner']=FtHzUBemVuawEiqGQDoWNJfcsSCTKr
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['thumbnail']['fanart']=FtHzUBemVuawEiqGQDoWNJfcsSCTPl
  else:
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+'/v2a/media/stream/info'
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams()
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_uuid'].split('-')[0],'uuid':FtHzUBemVuawEiqGQDoWNJfcsSCTIn.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetNoCache(1)),'wm':'Y',}
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk.update(FtHzUBemVuawEiqGQDoWNJfcsSCTRg)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRk,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb)
   FtHzUBemVuawEiqGQDoWNJfcsSCTnM=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   if not('content' in FtHzUBemVuawEiqGQDoWNJfcsSCTnM['body']):return{}
   FtHzUBemVuawEiqGQDoWNJfcsSCTnl=FtHzUBemVuawEiqGQDoWNJfcsSCTnM['body']['content']['info']['movie']
   FtHzUBemVuawEiqGQDoWNJfcsSCTPY =FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('name').get('ko').strip()
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['title']=FtHzUBemVuawEiqGQDoWNJfcsSCTPY
   FtHzUBemVuawEiqGQDoWNJfcsSCTPY +=u' (%s)'%(FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('product_year'))
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['title'] =FtHzUBemVuawEiqGQDoWNJfcsSCTPY
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['mpaa'] =FtHzUBemVuawEiqGQDoWNJfcsSCTIP.get(FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('grade_code'))
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['plot'] =FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('story').get('ko')
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['year'] =FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('product_year')
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['studio'] =FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('production')
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['duration']=FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('duration')
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['cast'] =FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('actor')
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['director']=FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('director')
   if FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('category1_name').get('ko')!='':
    FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['genre'].append(FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('category1_name').get('ko'))
   if FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('category2_name').get('ko')!='':
    FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['genre'].append(FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('category2_name').get('ko'))
   FtHzUBemVuawEiqGQDoWNJfcsSCTKg=FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('release_date'))
   if FtHzUBemVuawEiqGQDoWNJfcsSCTKg!='0':FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(FtHzUBemVuawEiqGQDoWNJfcsSCTKg[:4],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[4:6],FtHzUBemVuawEiqGQDoWNJfcsSCTKg[6:])
   FtHzUBemVuawEiqGQDoWNJfcsSCTPk=''
   FtHzUBemVuawEiqGQDoWNJfcsSCTPl =''
   FtHzUBemVuawEiqGQDoWNJfcsSCTKI=''
   for FtHzUBemVuawEiqGQDoWNJfcsSCTKn in FtHzUBemVuawEiqGQDoWNJfcsSCTnl.get('image'):
    if FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('code')=='CAIM2100':FtHzUBemVuawEiqGQDoWNJfcsSCTPk =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('url')
    elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('code')=='CAIM0400':FtHzUBemVuawEiqGQDoWNJfcsSCTPl =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('url')
    elif FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('code')=='CAIM1800':FtHzUBemVuawEiqGQDoWNJfcsSCTKI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.IMG_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTKn.get('url')
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['thumbnail']['poster']=FtHzUBemVuawEiqGQDoWNJfcsSCTPk
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['thumbnail']['thumb']=FtHzUBemVuawEiqGQDoWNJfcsSCTPk 
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['thumbnail']['clearlogo']=FtHzUBemVuawEiqGQDoWNJfcsSCTKI
   FtHzUBemVuawEiqGQDoWNJfcsSCTnY['saveinfo']['thumbnail']['fanart']=FtHzUBemVuawEiqGQDoWNJfcsSCTPl
  return FtHzUBemVuawEiqGQDoWNJfcsSCTnY
 def GetEuroChannelList(FtHzUBemVuawEiqGQDoWNJfcsSCTIn):
  FtHzUBemVuawEiqGQDoWNJfcsSCTRA=[]
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTRL ='/v2/operator/highlights'
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetDefaultParams()
   FtHzUBemVuawEiqGQDoWNJfcsSCTRg={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':FtHzUBemVuawEiqGQDoWNJfcsSCTjl(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.GetNoCache(2))}
   FtHzUBemVuawEiqGQDoWNJfcsSCTRk.update(FtHzUBemVuawEiqGQDoWNJfcsSCTRg)
   FtHzUBemVuawEiqGQDoWNJfcsSCTrI=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.API_DOMAIN+FtHzUBemVuawEiqGQDoWNJfcsSCTRL
   FtHzUBemVuawEiqGQDoWNJfcsSCTRK=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.callRequestCookies('Get',FtHzUBemVuawEiqGQDoWNJfcsSCTrI,payload=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,params=FtHzUBemVuawEiqGQDoWNJfcsSCTRk,headers=FtHzUBemVuawEiqGQDoWNJfcsSCTjb,cookies=FtHzUBemVuawEiqGQDoWNJfcsSCTjb)
   FtHzUBemVuawEiqGQDoWNJfcsSCTRx=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTRK.text)
   if not('result' in FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']):return FtHzUBemVuawEiqGQDoWNJfcsSCTRA,FtHzUBemVuawEiqGQDoWNJfcsSCTPb
   FtHzUBemVuawEiqGQDoWNJfcsSCTPx=FtHzUBemVuawEiqGQDoWNJfcsSCTRx['body']['result']
   FtHzUBemVuawEiqGQDoWNJfcsSCTnk =FtHzUBemVuawEiqGQDoWNJfcsSCTIn.Get_Now_Datetime()
   FtHzUBemVuawEiqGQDoWNJfcsSCTjI=FtHzUBemVuawEiqGQDoWNJfcsSCTnk+datetime.timedelta(days=-1)
   FtHzUBemVuawEiqGQDoWNJfcsSCTjI=FtHzUBemVuawEiqGQDoWNJfcsSCTjh(FtHzUBemVuawEiqGQDoWNJfcsSCTjI.strftime('%Y%m%d'))
   for FtHzUBemVuawEiqGQDoWNJfcsSCTRv in FtHzUBemVuawEiqGQDoWNJfcsSCTPx:
    FtHzUBemVuawEiqGQDoWNJfcsSCTjR=FtHzUBemVuawEiqGQDoWNJfcsSCTjh(FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('content').get('banner_title2')[:8])
    if FtHzUBemVuawEiqGQDoWNJfcsSCTjI<=FtHzUBemVuawEiqGQDoWNJfcsSCTjR:
     FtHzUBemVuawEiqGQDoWNJfcsSCTKv={'channel':FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('content').get('banner_sub_title3'),'title':FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('content').get('banner_title'),'subtitle':FtHzUBemVuawEiqGQDoWNJfcsSCTRv.get('content').get('banner_sub_title2'),}
     FtHzUBemVuawEiqGQDoWNJfcsSCTRA.append(FtHzUBemVuawEiqGQDoWNJfcsSCTKv)
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTRA
 def Make_DecryptKey(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,step,mediacode='000',timecode='000'):
  if step=='1':
   FtHzUBemVuawEiqGQDoWNJfcsSCTjr=FtHzUBemVuawEiqGQDoWNJfcsSCTyR('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   FtHzUBemVuawEiqGQDoWNJfcsSCTjP=FtHzUBemVuawEiqGQDoWNJfcsSCTyR('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjr=FtHzUBemVuawEiqGQDoWNJfcsSCTyR('kss2lym0kdw1lks3','utf-8')
   FtHzUBemVuawEiqGQDoWNJfcsSCTjP=FtHzUBemVuawEiqGQDoWNJfcsSCTyR([FtHzUBemVuawEiqGQDoWNJfcsSCTyr('*'),0x07,FtHzUBemVuawEiqGQDoWNJfcsSCTyr('r'),FtHzUBemVuawEiqGQDoWNJfcsSCTyr(';'),FtHzUBemVuawEiqGQDoWNJfcsSCTyr('7'),0x05,0x1e,0x01,FtHzUBemVuawEiqGQDoWNJfcsSCTyr('n'),FtHzUBemVuawEiqGQDoWNJfcsSCTyr('D'),0x02,FtHzUBemVuawEiqGQDoWNJfcsSCTyr('3'),FtHzUBemVuawEiqGQDoWNJfcsSCTyr('*'),FtHzUBemVuawEiqGQDoWNJfcsSCTyr('a'),FtHzUBemVuawEiqGQDoWNJfcsSCTyr('&'),FtHzUBemVuawEiqGQDoWNJfcsSCTyr('<')])
  return FtHzUBemVuawEiqGQDoWNJfcsSCTjr,FtHzUBemVuawEiqGQDoWNJfcsSCTjP
 def DecryptPlaintext(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,ciphertext,encryption_key,init_vector):
  FtHzUBemVuawEiqGQDoWNJfcsSCTjK=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  FtHzUBemVuawEiqGQDoWNJfcsSCTjn=Padding.unpad(FtHzUBemVuawEiqGQDoWNJfcsSCTjK.decrypt(base64.standard_b64decode(ciphertext)),16)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTjn.decode('utf-8')
 def Decrypt_Url(FtHzUBemVuawEiqGQDoWNJfcsSCTIn,ciphertext,mediacode,FtHzUBemVuawEiqGQDoWNJfcsSCTry):
  FtHzUBemVuawEiqGQDoWNJfcsSCTjy=''
  FtHzUBemVuawEiqGQDoWNJfcsSCTrX=''
  FtHzUBemVuawEiqGQDoWNJfcsSCTrL=''
  try:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjr,FtHzUBemVuawEiqGQDoWNJfcsSCTjP=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.Make_DecryptKey('1',mediacode=mediacode,timecode=FtHzUBemVuawEiqGQDoWNJfcsSCTry)
   FtHzUBemVuawEiqGQDoWNJfcsSCTjX=json.loads(FtHzUBemVuawEiqGQDoWNJfcsSCTIn.DecryptPlaintext(ciphertext,FtHzUBemVuawEiqGQDoWNJfcsSCTjr,FtHzUBemVuawEiqGQDoWNJfcsSCTjP))
   FtHzUBemVuawEiqGQDoWNJfcsSCTjL =FtHzUBemVuawEiqGQDoWNJfcsSCTjX.get('broad_url')
   FtHzUBemVuawEiqGQDoWNJfcsSCTrX =FtHzUBemVuawEiqGQDoWNJfcsSCTjX.get('watermark') if 'watermark' in FtHzUBemVuawEiqGQDoWNJfcsSCTjX else ''
   FtHzUBemVuawEiqGQDoWNJfcsSCTrL=FtHzUBemVuawEiqGQDoWNJfcsSCTjX.get('watermarkKey')if 'watermarkKey' in FtHzUBemVuawEiqGQDoWNJfcsSCTjX else ''
   FtHzUBemVuawEiqGQDoWNJfcsSCTjr,FtHzUBemVuawEiqGQDoWNJfcsSCTjP=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.Make_DecryptKey('2',mediacode=mediacode,timecode=FtHzUBemVuawEiqGQDoWNJfcsSCTry)
   FtHzUBemVuawEiqGQDoWNJfcsSCTjy=FtHzUBemVuawEiqGQDoWNJfcsSCTIn.DecryptPlaintext(FtHzUBemVuawEiqGQDoWNJfcsSCTjL,FtHzUBemVuawEiqGQDoWNJfcsSCTjr,FtHzUBemVuawEiqGQDoWNJfcsSCTjP)
  except FtHzUBemVuawEiqGQDoWNJfcsSCTjY as exception:
   FtHzUBemVuawEiqGQDoWNJfcsSCTjp(exception)
  return FtHzUBemVuawEiqGQDoWNJfcsSCTjy,FtHzUBemVuawEiqGQDoWNJfcsSCTrX,FtHzUBemVuawEiqGQDoWNJfcsSCTrL
# Created by pyminifier (https://github.com/liftoff/pyminifier)
