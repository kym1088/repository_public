__author__="NightRain"
PMeDuSnUkATvXfBsdyQHxqFgNzoYaR=object
PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ=None
PMeDuSnUkATvXfBsdyQHxqFgNzoYaG=int
PMeDuSnUkATvXfBsdyQHxqFgNzoYaw=True
PMeDuSnUkATvXfBsdyQHxqFgNzoYCc=False
PMeDuSnUkATvXfBsdyQHxqFgNzoYCV=type
PMeDuSnUkATvXfBsdyQHxqFgNzoYCm=dict
PMeDuSnUkATvXfBsdyQHxqFgNzoYCW=getattr
PMeDuSnUkATvXfBsdyQHxqFgNzoYCl=list
PMeDuSnUkATvXfBsdyQHxqFgNzoYCp=len
PMeDuSnUkATvXfBsdyQHxqFgNzoYCI=str
PMeDuSnUkATvXfBsdyQHxqFgNzoYCa=range
PMeDuSnUkATvXfBsdyQHxqFgNzoYCb=open
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
import json 
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
PMeDuSnUkATvXfBsdyQHxqFgNzoYcm=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'오직 티빙에만','mode':'ORI_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'VOD 방송 - 4K','mode':'4K_PROGRAM','stype':'-','orderby':'-','ordernm':'-'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewDay','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 4K','mode':'4K_MOVIE','stype':'-','orderby':'-','ordernm':'-'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
PMeDuSnUkATvXfBsdyQHxqFgNzoYcW=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
PMeDuSnUkATvXfBsdyQHxqFgNzoYcl=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
PMeDuSnUkATvXfBsdyQHxqFgNzoYcp=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
PMeDuSnUkATvXfBsdyQHxqFgNzoYcI=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'애니메이션','mode':'PROGRAM','stype':'PCAN'},{'title':'로맨스','mode':'PROGRAM','stype':'PCO'},{'title':'코미디','mode':'PROGRAM','stype':'PCP'},{'title':'스릴러','mode':'PROGRAM','stype':'PCQ'},{'title':'미스터리(추리)','mode':'PROGRAM','stype':'PCAA'},{'title':'모험','mode':'PROGRAM','stype':'PCX'},{'title':'액션','mode':'PROGRAM','stype':'PCY'},{'title':'판타지','mode':'PROGRAM','stype':'PCR'},{'title':'무협','mode':'PROGRAM','stype':'PCAB'},{'title':'공포','mode':'PROGRAM','stype':'PCAD'},{'title':'리얼리티','mode':'PROGRAM','stype':'PCV'},{'title':'토크쇼','mode':'PROGRAM','stype':'PCU'},{'title':'다큐멘터리','mode':'PROGRAM','stype':'PCT'},{'title':'키즈','mode':'PROGRAM','stype':'PCC'},{'title':'스포츠','mode':'PROGRAM','stype':'PCF'},{'title':'음악','mode':'PROGRAM','stype':'PCAC'},{'title':'공연','mode':'PROGRAM','stype':'PCW'},{'title':'사극(시대극)','mode':'PROGRAM','stype':'PCS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'Paramount+','mode':'PROGRAM','stype':'PARAMOUNT'}]
PMeDuSnUkATvXfBsdyQHxqFgNzoYca=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG23'},{'title':'로맨스','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'스릴러','mode':'MOVIE_SUB','stype':'MG140'},{'title':'미스터리','mode':'MOVIE_SUB','stype':'MG150'},{'title':'모험','mode':'MOVIE_SUB','stype':'MG170'},{'title':'액션','mode':'MOVIE_SUB','stype':'MG120'},{'title':'판타지','mode':'MOVIE_SUB','stype':'MG200'},{'title':'SF','mode':'MOVIE_SUB','stype':'MG210'},{'title':'공포','mode':'MOVIE_SUB','stype':'MG160'},{'title':'다큐멘터리','mode':'MOVIE_SUB','stype':'MG250'},{'title':'다양성 영화','mode':'MOVIE_SUB','stype':'diversityYn'},{'title':'Paramount+','mode':'MOVIE_SUB','stype':'PARAMOUNT'}]
PMeDuSnUkATvXfBsdyQHxqFgNzoYcC=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
PMeDuSnUkATvXfBsdyQHxqFgNzoYcb={'title':{'func':'setTitle','type':'string'},'plot':{'func':'setPlot','type':'string'},'mpaa':{'func':'setMpaa','type':'string'},'mediatype':{'func':'setMediaType','type':'string'},'tvshowtitle':{'func':'setTvShowTitle','type':'string'},'premiered':{'func':'setPremiered','type':'string'},'aired':{'func':'setFirstAired','type':'string'},'year':{'func':'setYear','type':'int'},'duration':{'func':'setDuration','type':'int'},'episode':{'func':'setEpisode','type':'int'},'season':{'func':'setSeason','type':'int'},'studio':{'func':'setStudios','type':'list'},'genre':{'func':'setGenres','type':'list'},'country':{'func':'setCountries','type':'list'},'cast':{'func':'setCast','type':'actor'},'director':{'func':'setDirectors','type':'list'},}
from tvingCore import*
PMeDuSnUkATvXfBsdyQHxqFgNzoYcE =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
PMeDuSnUkATvXfBsdyQHxqFgNzoYch=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
class PMeDuSnUkATvXfBsdyQHxqFgNzoYcV(PMeDuSnUkATvXfBsdyQHxqFgNzoYaR):
 def __init__(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYcL,PMeDuSnUkATvXfBsdyQHxqFgNzoYci,PMeDuSnUkATvXfBsdyQHxqFgNzoYcO):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_url =PMeDuSnUkATvXfBsdyQHxqFgNzoYcL
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle=PMeDuSnUkATvXfBsdyQHxqFgNzoYci
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params =PMeDuSnUkATvXfBsdyQHxqFgNzoYcO
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj =NvhOQfsGtWaUeATlKCRPpLIgXHBwJo() 
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.TV_STREAM_FILENAME =xbmcvfs.translatePath(os.path.join(__profile__,'tving_stream(mpd,m3u8)'))
 def addon_noti(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,sting):
  try:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcK=xbmcgui.Dialog()
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcK.notification(__addonname__,sting)
  except:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
 def addon_log(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,string):
  try:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYct=string.encode('utf-8','ignore')
  except:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYct='addonException: addon_log'
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcR=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,PMeDuSnUkATvXfBsdyQHxqFgNzoYct),level=PMeDuSnUkATvXfBsdyQHxqFgNzoYcR)
 def get_keyboard_input(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYVO):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcJ=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
  kb=xbmc.Keyboard()
  kb.setHeading(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcJ=kb.getText()
  return PMeDuSnUkATvXfBsdyQHxqFgNzoYcJ
 def get_settings_account(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcG =__addon__.getSetting('id')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcw =__addon__.getSetting('pw')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVc =__addon__.getSetting('login_type')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVm=PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(__addon__.getSetting('selected_profile'))
  return(PMeDuSnUkATvXfBsdyQHxqFgNzoYcG,PMeDuSnUkATvXfBsdyQHxqFgNzoYcw,PMeDuSnUkATvXfBsdyQHxqFgNzoYVc,PMeDuSnUkATvXfBsdyQHxqFgNzoYVm)
 def get_settings_uhd(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  return PMeDuSnUkATvXfBsdyQHxqFgNzoYaw if __addon__.getSetting('active_uhd')=='true' else PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
 def get_settings_playback(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVW={'active_uhd':PMeDuSnUkATvXfBsdyQHxqFgNzoYaw if __addon__.getSetting('active_uhd')=='true' else PMeDuSnUkATvXfBsdyQHxqFgNzoYCc,'streamFilename':PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.TV_STREAM_FILENAME,}
  return PMeDuSnUkATvXfBsdyQHxqFgNzoYVW
 def get_settings_proxyport(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVl =PMeDuSnUkATvXfBsdyQHxqFgNzoYaw if __addon__.getSetting('proxyYn')=='true' else PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVp=PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(__addon__.getSetting('proxyPort'))
  return PMeDuSnUkATvXfBsdyQHxqFgNzoYVl,PMeDuSnUkATvXfBsdyQHxqFgNzoYVp
 def get_settings_totalsearch(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVI =PMeDuSnUkATvXfBsdyQHxqFgNzoYaw if __addon__.getSetting('local_search')=='true' else PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVa=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw if __addon__.getSetting('local_history')=='true' else PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVC =PMeDuSnUkATvXfBsdyQHxqFgNzoYaw if __addon__.getSetting('total_search')=='true' else PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVb=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw if __addon__.getSetting('total_history')=='true' else PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVE=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw if __addon__.getSetting('menu_bookmark')=='true' else PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
  return(PMeDuSnUkATvXfBsdyQHxqFgNzoYVI,PMeDuSnUkATvXfBsdyQHxqFgNzoYVa,PMeDuSnUkATvXfBsdyQHxqFgNzoYVC,PMeDuSnUkATvXfBsdyQHxqFgNzoYVb,PMeDuSnUkATvXfBsdyQHxqFgNzoYVE)
 def get_settings_makebookmark(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  return PMeDuSnUkATvXfBsdyQHxqFgNzoYaw if __addon__.getSetting('make_bookmark')=='true' else PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
 def get_settings_direct_replay(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVh=PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(__addon__.getSetting('direct_replay'))
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYVh==0:
   return PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
  else:
   return PMeDuSnUkATvXfBsdyQHxqFgNzoYaw
 def set_winEpisodeOrderby(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYVL):
  __addon__.setSetting('tving_orderby',PMeDuSnUkATvXfBsdyQHxqFgNzoYVL)
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVr=xbmcgui.Window(10000)
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVr.setProperty('TVING_M_ORDERBY',PMeDuSnUkATvXfBsdyQHxqFgNzoYVL)
 def get_winEpisodeOrderby(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVL=__addon__.getSetting('tving_orderby')
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYVL in['',PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ]:PMeDuSnUkATvXfBsdyQHxqFgNzoYVL='desc'
  return PMeDuSnUkATvXfBsdyQHxqFgNzoYVL
 def add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,label,sublabel='',img='',infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params='',isLink=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc,ContextMenu=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVi='%s?%s'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_url,urllib.parse.urlencode(params))
  if sublabel:PMeDuSnUkATvXfBsdyQHxqFgNzoYVO='%s < %s >'%(label,sublabel)
  else: PMeDuSnUkATvXfBsdyQHxqFgNzoYVO=label
  if not img:img='DefaultFolder.png'
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVj=xbmcgui.ListItem(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYCV(img)==PMeDuSnUkATvXfBsdyQHxqFgNzoYCm:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVj.setArt(img)
  else:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVj.setArt({'thumb':img,'poster':img})
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.KodiVersion>=20:
   if infoLabels:PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.Set_InfoTag(PMeDuSnUkATvXfBsdyQHxqFgNzoYVj.getVideoInfoTag(),infoLabels)
  else:
   if infoLabels:PMeDuSnUkATvXfBsdyQHxqFgNzoYVj.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVj.setProperty('IsPlayable','true')
  if ContextMenu:PMeDuSnUkATvXfBsdyQHxqFgNzoYVj.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,PMeDuSnUkATvXfBsdyQHxqFgNzoYVi,PMeDuSnUkATvXfBsdyQHxqFgNzoYVj,isFolder)
 def get_selQuality(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,etype):
  try:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVK='selected_quality'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVt=[1080,720,480,360]
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVR=PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(__addon__.getSetting(PMeDuSnUkATvXfBsdyQHxqFgNzoYVK))
   return PMeDuSnUkATvXfBsdyQHxqFgNzoYVt[PMeDuSnUkATvXfBsdyQHxqFgNzoYVR]
  except:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
  return 720 
 def Set_InfoTag(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,video_InfoTag:xbmc.InfoTagVideo,PMeDuSnUkATvXfBsdyQHxqFgNzoYmp):
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYVJ,value in PMeDuSnUkATvXfBsdyQHxqFgNzoYmp.items():
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYcb[PMeDuSnUkATvXfBsdyQHxqFgNzoYVJ]['type']=='string':
    PMeDuSnUkATvXfBsdyQHxqFgNzoYCW(video_InfoTag,PMeDuSnUkATvXfBsdyQHxqFgNzoYcb[PMeDuSnUkATvXfBsdyQHxqFgNzoYVJ]['func'])(value)
   elif PMeDuSnUkATvXfBsdyQHxqFgNzoYcb[PMeDuSnUkATvXfBsdyQHxqFgNzoYVJ]['type']=='int':
    if PMeDuSnUkATvXfBsdyQHxqFgNzoYCV(value)==PMeDuSnUkATvXfBsdyQHxqFgNzoYaG:
     PMeDuSnUkATvXfBsdyQHxqFgNzoYVG=PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(value)
    else:
     PMeDuSnUkATvXfBsdyQHxqFgNzoYVG=0
    PMeDuSnUkATvXfBsdyQHxqFgNzoYCW(video_InfoTag,PMeDuSnUkATvXfBsdyQHxqFgNzoYcb[PMeDuSnUkATvXfBsdyQHxqFgNzoYVJ]['func'])(PMeDuSnUkATvXfBsdyQHxqFgNzoYVG)
   elif PMeDuSnUkATvXfBsdyQHxqFgNzoYcb[PMeDuSnUkATvXfBsdyQHxqFgNzoYVJ]['type']=='actor':
    if value!=[]:
     PMeDuSnUkATvXfBsdyQHxqFgNzoYCW(video_InfoTag,PMeDuSnUkATvXfBsdyQHxqFgNzoYcb[PMeDuSnUkATvXfBsdyQHxqFgNzoYVJ]['func'])([xbmc.Actor(name)for name in value])
   elif PMeDuSnUkATvXfBsdyQHxqFgNzoYcb[PMeDuSnUkATvXfBsdyQHxqFgNzoYVJ]['type']=='list':
    if PMeDuSnUkATvXfBsdyQHxqFgNzoYCV(value)==PMeDuSnUkATvXfBsdyQHxqFgNzoYCl:
     PMeDuSnUkATvXfBsdyQHxqFgNzoYCW(video_InfoTag,PMeDuSnUkATvXfBsdyQHxqFgNzoYcb[PMeDuSnUkATvXfBsdyQHxqFgNzoYVJ]['func'])(value)
    else:
     PMeDuSnUkATvXfBsdyQHxqFgNzoYCW(video_InfoTag,PMeDuSnUkATvXfBsdyQHxqFgNzoYcb[PMeDuSnUkATvXfBsdyQHxqFgNzoYVJ]['func'])([value])
 def dp_Main_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  (PMeDuSnUkATvXfBsdyQHxqFgNzoYVI,PMeDuSnUkATvXfBsdyQHxqFgNzoYVa,PMeDuSnUkATvXfBsdyQHxqFgNzoYVC,PMeDuSnUkATvXfBsdyQHxqFgNzoYVb,PMeDuSnUkATvXfBsdyQHxqFgNzoYVE)=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_totalsearch()
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYVw in PMeDuSnUkATvXfBsdyQHxqFgNzoYcm:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO=PMeDuSnUkATvXfBsdyQHxqFgNzoYVw.get('title')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmc=''
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYVw.get('mode')=='SEARCH_GROUP' and PMeDuSnUkATvXfBsdyQHxqFgNzoYVI ==PMeDuSnUkATvXfBsdyQHxqFgNzoYCc:continue
   elif PMeDuSnUkATvXfBsdyQHxqFgNzoYVw.get('mode')=='SEARCH_HISTORY' and PMeDuSnUkATvXfBsdyQHxqFgNzoYVa==PMeDuSnUkATvXfBsdyQHxqFgNzoYCc:continue
   elif PMeDuSnUkATvXfBsdyQHxqFgNzoYVw.get('mode')=='TOTAL_SEARCH' and PMeDuSnUkATvXfBsdyQHxqFgNzoYVC ==PMeDuSnUkATvXfBsdyQHxqFgNzoYCc:continue
   elif PMeDuSnUkATvXfBsdyQHxqFgNzoYVw.get('mode')=='TOTAL_HISTORY' and PMeDuSnUkATvXfBsdyQHxqFgNzoYVb==PMeDuSnUkATvXfBsdyQHxqFgNzoYCc:continue
   elif PMeDuSnUkATvXfBsdyQHxqFgNzoYVw.get('mode')=='MENU_BOOKMARK' and PMeDuSnUkATvXfBsdyQHxqFgNzoYVE==PMeDuSnUkATvXfBsdyQHxqFgNzoYCc:continue
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':PMeDuSnUkATvXfBsdyQHxqFgNzoYVw.get('mode'),'stype':PMeDuSnUkATvXfBsdyQHxqFgNzoYVw.get('stype'),'orderby':PMeDuSnUkATvXfBsdyQHxqFgNzoYVw.get('orderby'),'ordernm':PMeDuSnUkATvXfBsdyQHxqFgNzoYVw.get('ordernm'),'page':'1'}
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYVw.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmW=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
    PMeDuSnUkATvXfBsdyQHxqFgNzoYml =PMeDuSnUkATvXfBsdyQHxqFgNzoYaw
   else:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmW=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw
    PMeDuSnUkATvXfBsdyQHxqFgNzoYml =PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmp={'title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'plot':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO}
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYVw.get('mode')=='XXX':PMeDuSnUkATvXfBsdyQHxqFgNzoYmp=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
   if 'icon' in PMeDuSnUkATvXfBsdyQHxqFgNzoYVw:PMeDuSnUkATvXfBsdyQHxqFgNzoYmc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',PMeDuSnUkATvXfBsdyQHxqFgNzoYVw.get('icon')) 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel='',img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmc,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYmp,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYmW,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV,isLink=PMeDuSnUkATvXfBsdyQHxqFgNzoYml)
  xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle)
 def login_main(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  (PMeDuSnUkATvXfBsdyQHxqFgNzoYma,PMeDuSnUkATvXfBsdyQHxqFgNzoYmC,PMeDuSnUkATvXfBsdyQHxqFgNzoYmb,PMeDuSnUkATvXfBsdyQHxqFgNzoYmE)=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_account()
  if not(PMeDuSnUkATvXfBsdyQHxqFgNzoYma and PMeDuSnUkATvXfBsdyQHxqFgNzoYmC):
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcK=xbmcgui.Dialog()
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmh=PMeDuSnUkATvXfBsdyQHxqFgNzoYcK.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYmh==PMeDuSnUkATvXfBsdyQHxqFgNzoYaw:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.cookiefile_check():return
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmr=0
   while PMeDuSnUkATvXfBsdyQHxqFgNzoYaw:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmr+=1
    time.sleep(0.05)
    if PMeDuSnUkATvXfBsdyQHxqFgNzoYmr>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmL=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.GetCredential(PMeDuSnUkATvXfBsdyQHxqFgNzoYma,PMeDuSnUkATvXfBsdyQHxqFgNzoYmC,PMeDuSnUkATvXfBsdyQHxqFgNzoYmb,PMeDuSnUkATvXfBsdyQHxqFgNzoYmE)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmL:PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmL==PMeDuSnUkATvXfBsdyQHxqFgNzoYCc:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_noti(__language__(30903).encode('utf8'))
   sys.exit()
 def dp_Title_Group(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmi=PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('stype')
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmi=='live':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmO=PMeDuSnUkATvXfBsdyQHxqFgNzoYcW
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYmi=='vod':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmO=PMeDuSnUkATvXfBsdyQHxqFgNzoYcI
  else:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmO=PMeDuSnUkATvXfBsdyQHxqFgNzoYca
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYmj in PMeDuSnUkATvXfBsdyQHxqFgNzoYmO:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO=PMeDuSnUkATvXfBsdyQHxqFgNzoYmj.get('title')
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('ordernm')!='-':
    PMeDuSnUkATvXfBsdyQHxqFgNzoYVO+='  ('+PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('ordernm')+')'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':PMeDuSnUkATvXfBsdyQHxqFgNzoYmj.get('mode'),'stype':PMeDuSnUkATvXfBsdyQHxqFgNzoYmj.get('stype'),'orderby':PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('orderby'),'ordernm':PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('ordernm'),'page':'1'}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel='',img='',infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYCp(PMeDuSnUkATvXfBsdyQHxqFgNzoYmO)>0:xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle)
 def dp_SubTitle_Group(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK): 
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYmj in PMeDuSnUkATvXfBsdyQHxqFgNzoYcC:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO=PMeDuSnUkATvXfBsdyQHxqFgNzoYmj.get('title')
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('ordernm')!='-':
    PMeDuSnUkATvXfBsdyQHxqFgNzoYVO+='  ('+PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('ordernm')+')'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':PMeDuSnUkATvXfBsdyQHxqFgNzoYmj.get('mode'),'genreCode':PMeDuSnUkATvXfBsdyQHxqFgNzoYmj.get('genreCode'),'stype':PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('stype'),'orderby':PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('orderby'),'page':'1'}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel='',img='',infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYCp(PMeDuSnUkATvXfBsdyQHxqFgNzoYcC)>0:xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle)
 def dp_LiveChannel_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmi =PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('stype')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmt =PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('page'))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmR,PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.GetLiveChannelList(PMeDuSnUkATvXfBsdyQHxqFgNzoYmi,PMeDuSnUkATvXfBsdyQHxqFgNzoYmt)
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYmG in PMeDuSnUkATvXfBsdyQHxqFgNzoYmR:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('title')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmI =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('channel')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmw =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('thumbnail')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWc =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('synopsis')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWV =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('channelepg')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWm =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('cast')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWl =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('director')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWp =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('info_genre')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWI =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('year')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWa =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('mpaa')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWC =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('premiered')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={'mediatype':'episode','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'studio':PMeDuSnUkATvXfBsdyQHxqFgNzoYmI,'cast':PMeDuSnUkATvXfBsdyQHxqFgNzoYWm,'director':PMeDuSnUkATvXfBsdyQHxqFgNzoYWl,'genre':PMeDuSnUkATvXfBsdyQHxqFgNzoYWp,'plot':'%s\n%s\n%s\n\n%s'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYmI,PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,PMeDuSnUkATvXfBsdyQHxqFgNzoYWV,PMeDuSnUkATvXfBsdyQHxqFgNzoYWc),'year':PMeDuSnUkATvXfBsdyQHxqFgNzoYWI,'mpaa':PMeDuSnUkATvXfBsdyQHxqFgNzoYWa,'premiered':PMeDuSnUkATvXfBsdyQHxqFgNzoYWC}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'LIVE','mediacode':PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('mediacode'),'stype':PMeDuSnUkATvXfBsdyQHxqFgNzoYmi}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYmI,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmw,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYWb,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['mode']='CHANNEL' 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['stype']=PMeDuSnUkATvXfBsdyQHxqFgNzoYmi 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['page']=PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO='[B]%s >>[/B]'%'다음 페이지'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWE=PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYWE,img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmc,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYCp(PMeDuSnUkATvXfBsdyQHxqFgNzoYmR)>0:xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,cacheToDisc=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc)
 def dp_Program_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYWh =PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('stype')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVL =PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('orderby')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmt =PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('page'))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYWr=PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('genreCode')
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYWr==PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ:PMeDuSnUkATvXfBsdyQHxqFgNzoYWr='all'
  PMeDuSnUkATvXfBsdyQHxqFgNzoYWL,PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.GetProgramList(PMeDuSnUkATvXfBsdyQHxqFgNzoYWh,PMeDuSnUkATvXfBsdyQHxqFgNzoYVL,PMeDuSnUkATvXfBsdyQHxqFgNzoYmt,PMeDuSnUkATvXfBsdyQHxqFgNzoYWr)
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYWi in PMeDuSnUkATvXfBsdyQHxqFgNzoYWL:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('title')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmw =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('thumbnail')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWc =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('synopsis')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWO =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('channel')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWm =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('cast')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWl =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('director')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWp=PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('info_genre')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWI =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('year')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWC =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('premiered')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWa =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('mpaa')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={'mediatype':'tvshow','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'studio':PMeDuSnUkATvXfBsdyQHxqFgNzoYWO,'cast':PMeDuSnUkATvXfBsdyQHxqFgNzoYWm,'director':PMeDuSnUkATvXfBsdyQHxqFgNzoYWl,'genre':PMeDuSnUkATvXfBsdyQHxqFgNzoYWp,'year':PMeDuSnUkATvXfBsdyQHxqFgNzoYWI,'premiered':PMeDuSnUkATvXfBsdyQHxqFgNzoYWC,'mpaa':PMeDuSnUkATvXfBsdyQHxqFgNzoYWa,'plot':PMeDuSnUkATvXfBsdyQHxqFgNzoYWc}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'EPISODE','programcode':PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('program'),'page':'1'}
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_makebookmark():
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWj={'videoid':PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('program'),'vidtype':'tvshow','vtitle':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'vsubtitle':PMeDuSnUkATvXfBsdyQHxqFgNzoYWO,}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWK=json.dumps(PMeDuSnUkATvXfBsdyQHxqFgNzoYWj)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWK=urllib.parse.quote(PMeDuSnUkATvXfBsdyQHxqFgNzoYWK)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWt='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYWK)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWR=[('(통합) 찜 영상에 추가',PMeDuSnUkATvXfBsdyQHxqFgNzoYWt)]
   else:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWR=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYWO,img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmw,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYWb,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV,ContextMenu=PMeDuSnUkATvXfBsdyQHxqFgNzoYWR)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['mode'] ='PROGRAM' 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['stype'] =PMeDuSnUkATvXfBsdyQHxqFgNzoYWh
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['orderby'] =PMeDuSnUkATvXfBsdyQHxqFgNzoYVL
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['page'] =PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['genreCode']=PMeDuSnUkATvXfBsdyQHxqFgNzoYWr 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO='[B]%s >>[/B]'%'다음 페이지'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWE=PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYWE,img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmc,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  xbmcplugin.setContent(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,cacheToDisc=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc)
 def dp_4K_Program_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmt =PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('page'))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYWL,PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Get_UHD_ProgramList(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt)
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYWi in PMeDuSnUkATvXfBsdyQHxqFgNzoYWL:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('title')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmw =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('thumbnail')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWc =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('synopsis')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWO =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('channel')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWm =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('cast')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWl =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('director')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWp=PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('info_genre')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWI =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('year')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWC =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('premiered')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWa =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('mpaa')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={'mediatype':'tvshow','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'studio':PMeDuSnUkATvXfBsdyQHxqFgNzoYWO,'cast':PMeDuSnUkATvXfBsdyQHxqFgNzoYWm,'director':PMeDuSnUkATvXfBsdyQHxqFgNzoYWl,'genre':PMeDuSnUkATvXfBsdyQHxqFgNzoYWp,'year':PMeDuSnUkATvXfBsdyQHxqFgNzoYWI,'premiered':PMeDuSnUkATvXfBsdyQHxqFgNzoYWC,'mpaa':PMeDuSnUkATvXfBsdyQHxqFgNzoYWa,'plot':PMeDuSnUkATvXfBsdyQHxqFgNzoYWc}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'EPISODE','programcode':PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('program'),'page':'1'}
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_makebookmark():
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWj={'videoid':PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('program'),'vidtype':'tvshow','vtitle':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'vsubtitle':PMeDuSnUkATvXfBsdyQHxqFgNzoYWO,}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWK=json.dumps(PMeDuSnUkATvXfBsdyQHxqFgNzoYWj)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWK=urllib.parse.quote(PMeDuSnUkATvXfBsdyQHxqFgNzoYWK)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWt='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYWK)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWR=[('(통합) 찜 영상에 추가',PMeDuSnUkATvXfBsdyQHxqFgNzoYWt)]
   else:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWR=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYWO,img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmw,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYWb,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV,ContextMenu=PMeDuSnUkATvXfBsdyQHxqFgNzoYWR)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['mode'] ='4K_PROGRAM' 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['page'] =PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO='[B]%s >>[/B]'%'다음 페이지'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWE=PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYWE,img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmc,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  xbmcplugin.setContent(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,cacheToDisc=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc)
 def dp_Ori_Program_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmt =PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('page'))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYWL,PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Get_Origianl_ProgramList(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt)
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYWi in PMeDuSnUkATvXfBsdyQHxqFgNzoYWL:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('title')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmw =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('thumbnail')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWG =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('vod_type')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWw =PMeDuSnUkATvXfBsdyQHxqFgNzoYWi.get('vod_code')
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYWG=='vod':
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={'mediatype':'tvshow','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'EPISODE','programcode':PMeDuSnUkATvXfBsdyQHxqFgNzoYWw,'page':'1',}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmW=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw
   else:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={'mediatype':'movie','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'plot':'movie',}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'MOVIE','mediacode':PMeDuSnUkATvXfBsdyQHxqFgNzoYWw,'stype':'movie','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'thumbnail':PMeDuSnUkATvXfBsdyQHxqFgNzoYmw,}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmW=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmw,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYWb,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYmW,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV,ContextMenu=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['mode'] ='ORI_PROGRAM' 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['page'] =PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO='[B]%s >>[/B]'%'다음 페이지'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWE=PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYWE,img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmc,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  xbmcplugin.setContent(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,cacheToDisc=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc)
 def dp_Episode_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlc=PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('programcode')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmt =PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('page'))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlV,PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ,PMeDuSnUkATvXfBsdyQHxqFgNzoYlm=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.GetEpisodeList(PMeDuSnUkATvXfBsdyQHxqFgNzoYlc,PMeDuSnUkATvXfBsdyQHxqFgNzoYmt,orderby=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_winEpisodeOrderby())
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYlW in PMeDuSnUkATvXfBsdyQHxqFgNzoYlV:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO =PMeDuSnUkATvXfBsdyQHxqFgNzoYlW.get('title')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWE =PMeDuSnUkATvXfBsdyQHxqFgNzoYlW.get('subtitle')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmw =PMeDuSnUkATvXfBsdyQHxqFgNzoYlW.get('thumbnail')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWc =PMeDuSnUkATvXfBsdyQHxqFgNzoYlW.get('synopsis')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlp=PMeDuSnUkATvXfBsdyQHxqFgNzoYlW.get('info_title')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlI =PMeDuSnUkATvXfBsdyQHxqFgNzoYlW.get('aired')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYla =PMeDuSnUkATvXfBsdyQHxqFgNzoYlW.get('studio')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlC =PMeDuSnUkATvXfBsdyQHxqFgNzoYlW.get('frequency')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={'mediatype':'episode','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYlp,'aired':PMeDuSnUkATvXfBsdyQHxqFgNzoYlI,'studio':PMeDuSnUkATvXfBsdyQHxqFgNzoYla,'episode':PMeDuSnUkATvXfBsdyQHxqFgNzoYlC,'plot':PMeDuSnUkATvXfBsdyQHxqFgNzoYWc}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'VOD','mediacode':PMeDuSnUkATvXfBsdyQHxqFgNzoYlW.get('episode'),'stype':'vod','programcode':PMeDuSnUkATvXfBsdyQHxqFgNzoYlc,'title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'thumbnail':PMeDuSnUkATvXfBsdyQHxqFgNzoYmw}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYWE,img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmw,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYWb,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmt==1:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={'plot':'정렬순서를 변경합니다.'}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['mode'] ='ORDER_BY' 
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_winEpisodeOrderby()=='desc':
    PMeDuSnUkATvXfBsdyQHxqFgNzoYVO='정렬순서변경 : 최신화부터 -> 1회부터'
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['orderby']='asc'
   else:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYVO='정렬순서변경 : 1회부터 -> 최신화부터'
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['orderby']='desc'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel='',img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmc,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYWb,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV,isLink=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['mode'] ='EPISODE' 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['programcode']=PMeDuSnUkATvXfBsdyQHxqFgNzoYlc
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['page'] =PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO='[B]%s >>[/B]'%'다음 페이지'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWE=PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYWE,img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmc,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  xbmcplugin.setContent(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,'episodes')
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYCp(PMeDuSnUkATvXfBsdyQHxqFgNzoYlV)>0:xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,cacheToDisc=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw)
 def dp_setEpOrderby(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVL =PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('orderby')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.set_winEpisodeOrderby(PMeDuSnUkATvXfBsdyQHxqFgNzoYVL)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYWh =PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('stype')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVL =PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('orderby')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmt=PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('page'))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlb,PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.GetMovieList(PMeDuSnUkATvXfBsdyQHxqFgNzoYWh,PMeDuSnUkATvXfBsdyQHxqFgNzoYVL,PMeDuSnUkATvXfBsdyQHxqFgNzoYmt)
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYlE in PMeDuSnUkATvXfBsdyQHxqFgNzoYlb:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('title')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmw =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('thumbnail')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWc =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('synopsis')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlp =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('info_title')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWI =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('year')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWm =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('cast')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWl =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('director')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWp =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('info_genre')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlh =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('duration')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWC =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('premiered')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYla =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('studio')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWa =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('mpaa')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={'mediatype':'movie','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYlp,'year':PMeDuSnUkATvXfBsdyQHxqFgNzoYWI,'cast':PMeDuSnUkATvXfBsdyQHxqFgNzoYWm,'director':PMeDuSnUkATvXfBsdyQHxqFgNzoYWl,'genre':PMeDuSnUkATvXfBsdyQHxqFgNzoYWp,'duration':PMeDuSnUkATvXfBsdyQHxqFgNzoYlh,'premiered':PMeDuSnUkATvXfBsdyQHxqFgNzoYWC,'studio':PMeDuSnUkATvXfBsdyQHxqFgNzoYla,'mpaa':PMeDuSnUkATvXfBsdyQHxqFgNzoYWa,'plot':PMeDuSnUkATvXfBsdyQHxqFgNzoYWc}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'MOVIE','mediacode':PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('moviecode'),'stype':'movie','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'thumbnail':PMeDuSnUkATvXfBsdyQHxqFgNzoYmw}
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_makebookmark():
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWj={'videoid':PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('moviecode'),'vidtype':'movie','vtitle':PMeDuSnUkATvXfBsdyQHxqFgNzoYlp,'vsubtitle':'',}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWK=json.dumps(PMeDuSnUkATvXfBsdyQHxqFgNzoYWj)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWK=urllib.parse.quote(PMeDuSnUkATvXfBsdyQHxqFgNzoYWK)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWt='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYWK)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWR=[('(통합) 찜 영상에 추가',PMeDuSnUkATvXfBsdyQHxqFgNzoYWt)]
   else:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWR=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel='',img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmw,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYWb,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV,ContextMenu=PMeDuSnUkATvXfBsdyQHxqFgNzoYWR)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['mode'] ='MOVIE_SUB' 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['orderby']=PMeDuSnUkATvXfBsdyQHxqFgNzoYVL
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['stype'] =PMeDuSnUkATvXfBsdyQHxqFgNzoYWh
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['page'] =PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO='[B]%s >>[/B]'%'다음 페이지'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWE=PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYWE,img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmc,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  xbmcplugin.setContent(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,'movies')
  xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,cacheToDisc=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc)
 def dp_4K_Movie_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmt=PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('page'))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlb,PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Get_UHD_MovieList(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt)
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYlE in PMeDuSnUkATvXfBsdyQHxqFgNzoYlb:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('title')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmw =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('thumbnail')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWc =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('synopsis')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlp =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('info_title')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWI =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('year')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWm =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('cast')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWl =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('director')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWp =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('info_genre')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlh =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('duration')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWC =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('premiered')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYla =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('studio')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWa =PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('mpaa')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={'mediatype':'movie','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYlp,'year':PMeDuSnUkATvXfBsdyQHxqFgNzoYWI,'cast':PMeDuSnUkATvXfBsdyQHxqFgNzoYWm,'director':PMeDuSnUkATvXfBsdyQHxqFgNzoYWl,'genre':PMeDuSnUkATvXfBsdyQHxqFgNzoYWp,'duration':PMeDuSnUkATvXfBsdyQHxqFgNzoYlh,'premiered':PMeDuSnUkATvXfBsdyQHxqFgNzoYWC,'studio':PMeDuSnUkATvXfBsdyQHxqFgNzoYla,'mpaa':PMeDuSnUkATvXfBsdyQHxqFgNzoYWa,'plot':PMeDuSnUkATvXfBsdyQHxqFgNzoYWc}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'MOVIE','mediacode':PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('moviecode'),'stype':'movie','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'thumbnail':PMeDuSnUkATvXfBsdyQHxqFgNzoYmw}
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_makebookmark():
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWj={'videoid':PMeDuSnUkATvXfBsdyQHxqFgNzoYlE.get('moviecode'),'vidtype':'movie','vtitle':PMeDuSnUkATvXfBsdyQHxqFgNzoYlp,'vsubtitle':'',}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWK=json.dumps(PMeDuSnUkATvXfBsdyQHxqFgNzoYWj)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWK=urllib.parse.quote(PMeDuSnUkATvXfBsdyQHxqFgNzoYWK)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWt='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYWK)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWR=[('(통합) 찜 영상에 추가',PMeDuSnUkATvXfBsdyQHxqFgNzoYWt)]
   else:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWR=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel='',img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmw,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYWb,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV,ContextMenu=PMeDuSnUkATvXfBsdyQHxqFgNzoYWR)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['mode'] ='4K_MOVIE' 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['page'] =PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO='[B]%s >>[/B]'%'다음 페이지'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWE=PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYWE,img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmc,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  xbmcplugin.setContent(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,'movies')
  xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,cacheToDisc=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc)
 def dp_Set_Bookmark(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlr=urllib.parse.unquote(PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('bm_param'))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlr=json.loads(PMeDuSnUkATvXfBsdyQHxqFgNzoYlr)
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlL =PMeDuSnUkATvXfBsdyQHxqFgNzoYlr.get('videoid')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYli =PMeDuSnUkATvXfBsdyQHxqFgNzoYlr.get('vidtype')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlO =PMeDuSnUkATvXfBsdyQHxqFgNzoYlr.get('vtitle')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlj =PMeDuSnUkATvXfBsdyQHxqFgNzoYlr.get('vsubtitle')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcK=xbmcgui.Dialog()
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmh=PMeDuSnUkATvXfBsdyQHxqFgNzoYcK.yesno(__language__(30913).encode('utf8'),PMeDuSnUkATvXfBsdyQHxqFgNzoYlO+' \n\n'+__language__(30914))
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmh==PMeDuSnUkATvXfBsdyQHxqFgNzoYCc:return
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlK=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.GetBookmarkInfo(PMeDuSnUkATvXfBsdyQHxqFgNzoYlL,PMeDuSnUkATvXfBsdyQHxqFgNzoYli)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYlj!='':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlK['saveinfo']['subtitle']=PMeDuSnUkATvXfBsdyQHxqFgNzoYlj 
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYli=='tvshow':PMeDuSnUkATvXfBsdyQHxqFgNzoYlK['saveinfo']['infoLabels']['studio']=PMeDuSnUkATvXfBsdyQHxqFgNzoYlj 
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlt=json.dumps(PMeDuSnUkATvXfBsdyQHxqFgNzoYlK)
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlt=urllib.parse.quote(PMeDuSnUkATvXfBsdyQHxqFgNzoYlt)
  PMeDuSnUkATvXfBsdyQHxqFgNzoYWt ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYlt)
  xbmc.executebuiltin(PMeDuSnUkATvXfBsdyQHxqFgNzoYWt)
 def dp_Search_Group(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  if 'search_key' in PMeDuSnUkATvXfBsdyQHxqFgNzoYmK:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlR=PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('search_key')
  else:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlR=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not PMeDuSnUkATvXfBsdyQHxqFgNzoYlR:
    return
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYmj in PMeDuSnUkATvXfBsdyQHxqFgNzoYcp:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ =PMeDuSnUkATvXfBsdyQHxqFgNzoYmj.get('mode')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmi=PMeDuSnUkATvXfBsdyQHxqFgNzoYmj.get('stype')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO=PMeDuSnUkATvXfBsdyQHxqFgNzoYmj.get('title')
   (PMeDuSnUkATvXfBsdyQHxqFgNzoYlG,PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ)=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.GetSearchList(PMeDuSnUkATvXfBsdyQHxqFgNzoYlR,1,PMeDuSnUkATvXfBsdyQHxqFgNzoYmi)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmp={'plot':'검색어 : '+PMeDuSnUkATvXfBsdyQHxqFgNzoYlR+'\n\n'+PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.Search_FreeList(PMeDuSnUkATvXfBsdyQHxqFgNzoYlG)}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ,'stype':PMeDuSnUkATvXfBsdyQHxqFgNzoYmi,'search_key':PMeDuSnUkATvXfBsdyQHxqFgNzoYlR,'page':'1',}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel='',img='',infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYmp,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYCp(PMeDuSnUkATvXfBsdyQHxqFgNzoYcp)>0:xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,cacheToDisc=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw)
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.Save_Searched_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYlR)
 def Search_FreeList(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYpC):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlw=''
  PMeDuSnUkATvXfBsdyQHxqFgNzoYpc=7
  try:
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYCp(PMeDuSnUkATvXfBsdyQHxqFgNzoYpC)==0:return '검색결과 없음'
   for i in PMeDuSnUkATvXfBsdyQHxqFgNzoYCa(PMeDuSnUkATvXfBsdyQHxqFgNzoYCp(PMeDuSnUkATvXfBsdyQHxqFgNzoYpC)):
    if i>=PMeDuSnUkATvXfBsdyQHxqFgNzoYpc:
     PMeDuSnUkATvXfBsdyQHxqFgNzoYlw=PMeDuSnUkATvXfBsdyQHxqFgNzoYlw+'...'
     break
    PMeDuSnUkATvXfBsdyQHxqFgNzoYlw=PMeDuSnUkATvXfBsdyQHxqFgNzoYlw+PMeDuSnUkATvXfBsdyQHxqFgNzoYpC[i]['title']+'\n'
  except:
   return ''
  return PMeDuSnUkATvXfBsdyQHxqFgNzoYlw
 def dp_Search_History(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYpV=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.Load_List_File('search')
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYpm in PMeDuSnUkATvXfBsdyQHxqFgNzoYpV:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpW=PMeDuSnUkATvXfBsdyQHxqFgNzoYCm(urllib.parse.parse_qsl(PMeDuSnUkATvXfBsdyQHxqFgNzoYpm))
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpl=PMeDuSnUkATvXfBsdyQHxqFgNzoYpW.get('skey').strip()
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'SEARCH_GROUP','search_key':PMeDuSnUkATvXfBsdyQHxqFgNzoYpl,}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpI={'mode':'SEARCH_REMOVE','delType':'SEARCH_ONE','sKey':PMeDuSnUkATvXfBsdyQHxqFgNzoYpl,'vType':'-',}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpa=urllib.parse.urlencode(PMeDuSnUkATvXfBsdyQHxqFgNzoYpI)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWR=[('선택된 검색어 ( %s ) 삭제'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYpl),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYpa))]
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYpl,sublabel='',img=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV,ContextMenu=PMeDuSnUkATvXfBsdyQHxqFgNzoYWR)
  PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={'plot':'검색목록 전체를 삭제합니다.'}
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVO='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'SEARCH_REMOVE','delType':'SEARCH_ALL','skey':'-','vType':'-',}
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel='',img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmc,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYWb,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV,isLink=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw)
  xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,cacheToDisc=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc)
 def dp_Search_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmt =PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('page'))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmi =PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('stype')
  if 'search_key' in PMeDuSnUkATvXfBsdyQHxqFgNzoYmK:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlR=PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('search_key')
  else:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlR=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not PMeDuSnUkATvXfBsdyQHxqFgNzoYlR:
    xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle)
    return
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlG,PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.GetSearchList(PMeDuSnUkATvXfBsdyQHxqFgNzoYlR,PMeDuSnUkATvXfBsdyQHxqFgNzoYmt,PMeDuSnUkATvXfBsdyQHxqFgNzoYmi)
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYpC in PMeDuSnUkATvXfBsdyQHxqFgNzoYlG:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO =PMeDuSnUkATvXfBsdyQHxqFgNzoYpC.get('title')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmw =PMeDuSnUkATvXfBsdyQHxqFgNzoYpC.get('thumbnail')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWc =PMeDuSnUkATvXfBsdyQHxqFgNzoYpC.get('synopsis')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpb =PMeDuSnUkATvXfBsdyQHxqFgNzoYpC.get('program')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWm =PMeDuSnUkATvXfBsdyQHxqFgNzoYpC.get('cast')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWl =PMeDuSnUkATvXfBsdyQHxqFgNzoYpC.get('director')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWp=PMeDuSnUkATvXfBsdyQHxqFgNzoYpC.get('info_genre')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlh =PMeDuSnUkATvXfBsdyQHxqFgNzoYpC.get('duration')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWa =PMeDuSnUkATvXfBsdyQHxqFgNzoYpC.get('mpaa')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWI =PMeDuSnUkATvXfBsdyQHxqFgNzoYpC.get('year')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYlI =PMeDuSnUkATvXfBsdyQHxqFgNzoYpC.get('aired')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={'mediatype':'tvshow' if PMeDuSnUkATvXfBsdyQHxqFgNzoYmi=='vod' else 'movie','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'cast':PMeDuSnUkATvXfBsdyQHxqFgNzoYWm,'director':PMeDuSnUkATvXfBsdyQHxqFgNzoYWl,'genre':PMeDuSnUkATvXfBsdyQHxqFgNzoYWp,'duration':PMeDuSnUkATvXfBsdyQHxqFgNzoYlh,'mpaa':PMeDuSnUkATvXfBsdyQHxqFgNzoYWa,'year':PMeDuSnUkATvXfBsdyQHxqFgNzoYWI,'aired':PMeDuSnUkATvXfBsdyQHxqFgNzoYlI,'plot':'%s\n\n%s'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,PMeDuSnUkATvXfBsdyQHxqFgNzoYWc)}
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYmi=='vod':
    PMeDuSnUkATvXfBsdyQHxqFgNzoYlL=PMeDuSnUkATvXfBsdyQHxqFgNzoYpC.get('program')
    PMeDuSnUkATvXfBsdyQHxqFgNzoYli='tvshow'
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'EPISODE','programcode':PMeDuSnUkATvXfBsdyQHxqFgNzoYlL,'page':'1',}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmW=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw
   else:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYlL=PMeDuSnUkATvXfBsdyQHxqFgNzoYpC.get('movie')
    PMeDuSnUkATvXfBsdyQHxqFgNzoYli='movie'
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'MOVIE','mediacode':PMeDuSnUkATvXfBsdyQHxqFgNzoYlL,'stype':'movie','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'thumbnail':PMeDuSnUkATvXfBsdyQHxqFgNzoYmw,}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmW=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_makebookmark():
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWj={'videoid':PMeDuSnUkATvXfBsdyQHxqFgNzoYlL,'vidtype':PMeDuSnUkATvXfBsdyQHxqFgNzoYli,'vtitle':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'vsubtitle':'',}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWK=json.dumps(PMeDuSnUkATvXfBsdyQHxqFgNzoYWj)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWK=urllib.parse.quote(PMeDuSnUkATvXfBsdyQHxqFgNzoYWK)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWt='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYWK)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWR=[('(통합) 찜 영상에 추가',PMeDuSnUkATvXfBsdyQHxqFgNzoYWt)]
   else:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWR=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel='',img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmw,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYWb,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYmW,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV,isLink=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc,ContextMenu=PMeDuSnUkATvXfBsdyQHxqFgNzoYWR)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmJ:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['mode'] ='SEARCH' 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['search_key']=PMeDuSnUkATvXfBsdyQHxqFgNzoYlR
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV['page'] =PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO='[B]%s >>[/B]'%'다음 페이지'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWE=PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYmt+1)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYWE,img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmc,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmi=='movie':xbmcplugin.setContent(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,'movies')
  else:xbmcplugin.setContent(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,cacheToDisc=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc)
 def dp_History_Remove(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYpE=PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('delType')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYph =PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('sKey')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYpr =PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('vType')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcK=xbmcgui.Dialog()
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYpE=='SEARCH_ALL':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmh=PMeDuSnUkATvXfBsdyQHxqFgNzoYcK.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYpE=='SEARCH_ONE':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmh=PMeDuSnUkATvXfBsdyQHxqFgNzoYcK.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYpE=='WATCH_ALL':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmh=PMeDuSnUkATvXfBsdyQHxqFgNzoYcK.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYpE=='WATCH_ONE':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmh=PMeDuSnUkATvXfBsdyQHxqFgNzoYcK.yesno(__language__(30916).encode('utf8'),__language__(30905).encode('utf8'))
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmh==PMeDuSnUkATvXfBsdyQHxqFgNzoYCc:sys.exit()
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYpE=='SEARCH_ALL':
   if os.path.isfile(PMeDuSnUkATvXfBsdyQHxqFgNzoYch):os.remove(PMeDuSnUkATvXfBsdyQHxqFgNzoYch)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYpE=='SEARCH_ONE':
   try:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYpL=PMeDuSnUkATvXfBsdyQHxqFgNzoYch
    PMeDuSnUkATvXfBsdyQHxqFgNzoYpi=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.Load_List_File('search') 
    fp=PMeDuSnUkATvXfBsdyQHxqFgNzoYCb(PMeDuSnUkATvXfBsdyQHxqFgNzoYpL,'w',-1,'utf-8')
    for PMeDuSnUkATvXfBsdyQHxqFgNzoYpO in PMeDuSnUkATvXfBsdyQHxqFgNzoYpi:
     PMeDuSnUkATvXfBsdyQHxqFgNzoYpj=PMeDuSnUkATvXfBsdyQHxqFgNzoYCm(urllib.parse.parse_qsl(PMeDuSnUkATvXfBsdyQHxqFgNzoYpO))
     PMeDuSnUkATvXfBsdyQHxqFgNzoYpK=PMeDuSnUkATvXfBsdyQHxqFgNzoYpj.get('skey').strip()
     if PMeDuSnUkATvXfBsdyQHxqFgNzoYph!=PMeDuSnUkATvXfBsdyQHxqFgNzoYpK:
      fp.write(PMeDuSnUkATvXfBsdyQHxqFgNzoYpO)
    fp.close()
   except:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYpE=='WATCH_ALL':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PMeDuSnUkATvXfBsdyQHxqFgNzoYpr))
   if os.path.isfile(PMeDuSnUkATvXfBsdyQHxqFgNzoYpL):os.remove(PMeDuSnUkATvXfBsdyQHxqFgNzoYpL)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYpE=='WATCH_ONE':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PMeDuSnUkATvXfBsdyQHxqFgNzoYpr))
   try:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYpi=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.Load_List_File(PMeDuSnUkATvXfBsdyQHxqFgNzoYpr) 
    fp=PMeDuSnUkATvXfBsdyQHxqFgNzoYCb(PMeDuSnUkATvXfBsdyQHxqFgNzoYpL,'w',-1,'utf-8')
    for PMeDuSnUkATvXfBsdyQHxqFgNzoYpO in PMeDuSnUkATvXfBsdyQHxqFgNzoYpi:
     PMeDuSnUkATvXfBsdyQHxqFgNzoYpj=PMeDuSnUkATvXfBsdyQHxqFgNzoYCm(urllib.parse.parse_qsl(PMeDuSnUkATvXfBsdyQHxqFgNzoYpO))
     PMeDuSnUkATvXfBsdyQHxqFgNzoYpK=PMeDuSnUkATvXfBsdyQHxqFgNzoYpj.get('code').strip()
     if PMeDuSnUkATvXfBsdyQHxqFgNzoYph!=PMeDuSnUkATvXfBsdyQHxqFgNzoYpK:
      fp.write(PMeDuSnUkATvXfBsdyQHxqFgNzoYpO)
    fp.close()
   except:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmi): 
  try:
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYmi=='search':
    PMeDuSnUkATvXfBsdyQHxqFgNzoYpL=PMeDuSnUkATvXfBsdyQHxqFgNzoYch
   elif PMeDuSnUkATvXfBsdyQHxqFgNzoYmi in['vod','movie']:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYpL=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PMeDuSnUkATvXfBsdyQHxqFgNzoYmi))
   else:
    return[]
   fp=PMeDuSnUkATvXfBsdyQHxqFgNzoYCb(PMeDuSnUkATvXfBsdyQHxqFgNzoYpL,'r',-1,'utf-8')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpt=fp.readlines()
   fp.close()
  except:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpt=[]
  return PMeDuSnUkATvXfBsdyQHxqFgNzoYpt
 def Save_Watched_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmi,PMeDuSnUkATvXfBsdyQHxqFgNzoYcO):
  try:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpR=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%PMeDuSnUkATvXfBsdyQHxqFgNzoYmi))
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpi=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.Load_List_File(PMeDuSnUkATvXfBsdyQHxqFgNzoYmi) 
   fp=PMeDuSnUkATvXfBsdyQHxqFgNzoYCb(PMeDuSnUkATvXfBsdyQHxqFgNzoYpR,'w',-1,'utf-8')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpJ=urllib.parse.urlencode(PMeDuSnUkATvXfBsdyQHxqFgNzoYcO)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpJ=PMeDuSnUkATvXfBsdyQHxqFgNzoYpJ+'\n'
   fp.write(PMeDuSnUkATvXfBsdyQHxqFgNzoYpJ)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpG=0
   for PMeDuSnUkATvXfBsdyQHxqFgNzoYpO in PMeDuSnUkATvXfBsdyQHxqFgNzoYpi:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYpj=PMeDuSnUkATvXfBsdyQHxqFgNzoYCm(urllib.parse.parse_qsl(PMeDuSnUkATvXfBsdyQHxqFgNzoYpO))
    PMeDuSnUkATvXfBsdyQHxqFgNzoYpw=PMeDuSnUkATvXfBsdyQHxqFgNzoYcO.get('code').strip()
    PMeDuSnUkATvXfBsdyQHxqFgNzoYIc=PMeDuSnUkATvXfBsdyQHxqFgNzoYpj.get('code').strip()
    if PMeDuSnUkATvXfBsdyQHxqFgNzoYmi=='vod' and PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_direct_replay()==PMeDuSnUkATvXfBsdyQHxqFgNzoYaw:
     PMeDuSnUkATvXfBsdyQHxqFgNzoYpw=PMeDuSnUkATvXfBsdyQHxqFgNzoYcO.get('videoid').strip()
     PMeDuSnUkATvXfBsdyQHxqFgNzoYIc=PMeDuSnUkATvXfBsdyQHxqFgNzoYpj.get('videoid').strip()if PMeDuSnUkATvXfBsdyQHxqFgNzoYIc!=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ else '-'
    if PMeDuSnUkATvXfBsdyQHxqFgNzoYpw!=PMeDuSnUkATvXfBsdyQHxqFgNzoYIc:
     fp.write(PMeDuSnUkATvXfBsdyQHxqFgNzoYpO)
     PMeDuSnUkATvXfBsdyQHxqFgNzoYpG+=1
     if PMeDuSnUkATvXfBsdyQHxqFgNzoYpG>=50:break
   fp.close()
  except:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
 def dp_Watch_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmi =PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('stype')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVh=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_direct_replay()
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmi=='-':
   for PMeDuSnUkATvXfBsdyQHxqFgNzoYmj in PMeDuSnUkATvXfBsdyQHxqFgNzoYcl:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYVO=PMeDuSnUkATvXfBsdyQHxqFgNzoYmj.get('title')
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':PMeDuSnUkATvXfBsdyQHxqFgNzoYmj.get('mode'),'stype':PMeDuSnUkATvXfBsdyQHxqFgNzoYmj.get('stype')}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel='',img='',infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYCp(PMeDuSnUkATvXfBsdyQHxqFgNzoYcl)>0:xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle)
  else:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIV=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.Load_List_File(PMeDuSnUkATvXfBsdyQHxqFgNzoYmi)
   for PMeDuSnUkATvXfBsdyQHxqFgNzoYIm in PMeDuSnUkATvXfBsdyQHxqFgNzoYIV:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYpW=PMeDuSnUkATvXfBsdyQHxqFgNzoYCm(urllib.parse.parse_qsl(PMeDuSnUkATvXfBsdyQHxqFgNzoYIm))
    PMeDuSnUkATvXfBsdyQHxqFgNzoYIW =PMeDuSnUkATvXfBsdyQHxqFgNzoYpW.get('code').strip()
    PMeDuSnUkATvXfBsdyQHxqFgNzoYVO =PMeDuSnUkATvXfBsdyQHxqFgNzoYpW.get('title').strip()
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmw=PMeDuSnUkATvXfBsdyQHxqFgNzoYpW.get('img').strip()
    PMeDuSnUkATvXfBsdyQHxqFgNzoYlL =PMeDuSnUkATvXfBsdyQHxqFgNzoYpW.get('videoid').strip()
    try:
     PMeDuSnUkATvXfBsdyQHxqFgNzoYmw=PMeDuSnUkATvXfBsdyQHxqFgNzoYmw.replace('\'','\"')
     PMeDuSnUkATvXfBsdyQHxqFgNzoYmw=json.loads(PMeDuSnUkATvXfBsdyQHxqFgNzoYmw)
    except:
     PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWb['plot']=PMeDuSnUkATvXfBsdyQHxqFgNzoYVO
    if PMeDuSnUkATvXfBsdyQHxqFgNzoYmi=='vod':
     if PMeDuSnUkATvXfBsdyQHxqFgNzoYVh==PMeDuSnUkATvXfBsdyQHxqFgNzoYCc or PMeDuSnUkATvXfBsdyQHxqFgNzoYlL==PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ:
      PMeDuSnUkATvXfBsdyQHxqFgNzoYWb['mediatype']='tvshow'
      PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'EPISODE','programcode':PMeDuSnUkATvXfBsdyQHxqFgNzoYIW,'page':'1'}
      PMeDuSnUkATvXfBsdyQHxqFgNzoYmW=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw
     else:
      PMeDuSnUkATvXfBsdyQHxqFgNzoYWb['mediatype']='episode'
      PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'VOD','mediacode':PMeDuSnUkATvXfBsdyQHxqFgNzoYlL,'stype':'vod','programcode':PMeDuSnUkATvXfBsdyQHxqFgNzoYIW,'title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'thumbnail':PMeDuSnUkATvXfBsdyQHxqFgNzoYmw}
      PMeDuSnUkATvXfBsdyQHxqFgNzoYmW=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
    else:
     PMeDuSnUkATvXfBsdyQHxqFgNzoYWb['mediatype']='movie'
     PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'MOVIE','mediacode':PMeDuSnUkATvXfBsdyQHxqFgNzoYIW,'stype':'movie','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'thumbnail':PMeDuSnUkATvXfBsdyQHxqFgNzoYmw}
     PMeDuSnUkATvXfBsdyQHxqFgNzoYmW=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
    PMeDuSnUkATvXfBsdyQHxqFgNzoYpI={'mode':'MYVIEW_REMOVE','delType':'WATCH_ONE','sKey':PMeDuSnUkATvXfBsdyQHxqFgNzoYIW,'vType':PMeDuSnUkATvXfBsdyQHxqFgNzoYmi,}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYpa=urllib.parse.urlencode(PMeDuSnUkATvXfBsdyQHxqFgNzoYpI)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYWR=[('선택된 시청이력 ( %s ) 삭제'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYpa))]
    PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel='',img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmw,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYWb,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYmW,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV,ContextMenu=PMeDuSnUkATvXfBsdyQHxqFgNzoYWR)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={'plot':'시청목록을 삭제합니다.'}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO='** 시청목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'MYVIEW_REMOVE','delType':'WATCH_ALL','skey':'-','vType':PMeDuSnUkATvXfBsdyQHxqFgNzoYmi,}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmc=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel='',img=PMeDuSnUkATvXfBsdyQHxqFgNzoYmc,infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYWb,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV,isLink=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw)
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYmi=='movie':xbmcplugin.setContent(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,'movies')
   else:xbmcplugin.setContent(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,cacheToDisc=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc)
 def Save_Searched_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYlR):
  try:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIl=PMeDuSnUkATvXfBsdyQHxqFgNzoYch
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpi=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.Load_List_File('search') 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIp={'skey':PMeDuSnUkATvXfBsdyQHxqFgNzoYlR.strip()}
   fp=PMeDuSnUkATvXfBsdyQHxqFgNzoYCb(PMeDuSnUkATvXfBsdyQHxqFgNzoYIl,'w',-1,'utf-8')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpJ=urllib.parse.urlencode(PMeDuSnUkATvXfBsdyQHxqFgNzoYIp)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpJ=PMeDuSnUkATvXfBsdyQHxqFgNzoYpJ+'\n'
   fp.write(PMeDuSnUkATvXfBsdyQHxqFgNzoYpJ)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYpG=0
   for PMeDuSnUkATvXfBsdyQHxqFgNzoYpO in PMeDuSnUkATvXfBsdyQHxqFgNzoYpi:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYpj=PMeDuSnUkATvXfBsdyQHxqFgNzoYCm(urllib.parse.parse_qsl(PMeDuSnUkATvXfBsdyQHxqFgNzoYpO))
    PMeDuSnUkATvXfBsdyQHxqFgNzoYpw=PMeDuSnUkATvXfBsdyQHxqFgNzoYIp.get('skey').strip()
    PMeDuSnUkATvXfBsdyQHxqFgNzoYIc=PMeDuSnUkATvXfBsdyQHxqFgNzoYpj.get('skey').strip()
    if PMeDuSnUkATvXfBsdyQHxqFgNzoYpw!=PMeDuSnUkATvXfBsdyQHxqFgNzoYIc:
     fp.write(PMeDuSnUkATvXfBsdyQHxqFgNzoYpO)
     PMeDuSnUkATvXfBsdyQHxqFgNzoYpG+=1
     if PMeDuSnUkATvXfBsdyQHxqFgNzoYpG>=50:break
   fp.close()
  except:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
 def play_VIDEO(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYIa =PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('mediacode')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmi =PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('stype')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYIC =PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('pvrmode')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYIb=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_selQuality(PMeDuSnUkATvXfBsdyQHxqFgNzoYmi)
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYIa,PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYIb),PMeDuSnUkATvXfBsdyQHxqFgNzoYmi,PMeDuSnUkATvXfBsdyQHxqFgNzoYIC))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYIE=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.GetBroadURL(PMeDuSnUkATvXfBsdyQHxqFgNzoYIa,PMeDuSnUkATvXfBsdyQHxqFgNzoYIb,PMeDuSnUkATvXfBsdyQHxqFgNzoYmi,PMeDuSnUkATvXfBsdyQHxqFgNzoYIC,optUHD=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_uhd())
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_log('qt, stype, url : %s - %s - %s'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYCI(PMeDuSnUkATvXfBsdyQHxqFgNzoYIb),PMeDuSnUkATvXfBsdyQHxqFgNzoYmi,PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['streaming_url']))
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['streaming_url']=='':
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['error_msg']=='':
    PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_noti(__language__(30908).encode('utf8'))
   else:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_noti(PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['error_msg'].encode('utf8'))
   return
  PMeDuSnUkATvXfBsdyQHxqFgNzoYIh={'user-agent':PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.USER_AGENT}
  PMeDuSnUkATvXfBsdyQHxqFgNzoYIr=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.makeDefaultCookies() 
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['watermark'] !='':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIh['x-tving-param1']=PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['watermarkKey']
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIh['x-tving-param2']=PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['watermark'] 
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_log('streaming_url = {}'.format(PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['streaming_url']))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_log('drm_license   = {}'.format(PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['drm_license']))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_log('watermark     = {}'.format(PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['watermark']))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_log('watermarkKey  = {}'.format(PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['watermarkKey']))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYIL =PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
  PMeDuSnUkATvXfBsdyQHxqFgNzoYIi =PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['streaming_url'].find('Policy=')
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYIi!=-1:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIO =PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['streaming_url'].split('?')[0]
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIj=PMeDuSnUkATvXfBsdyQHxqFgNzoYCm(urllib.parse.parse_qsl(urllib.parse.urlsplit(PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['streaming_url']).query))
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIr['CloudFront-Policy'] =PMeDuSnUkATvXfBsdyQHxqFgNzoYIj['Policy'] 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIr['CloudFront-Signature'] =PMeDuSnUkATvXfBsdyQHxqFgNzoYIj['Signature'] 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIr['CloudFront-Key-Pair-Id']=PMeDuSnUkATvXfBsdyQHxqFgNzoYIj['Key-Pair-Id'] 
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIK=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.make_stream_header(PMeDuSnUkATvXfBsdyQHxqFgNzoYIh,PMeDuSnUkATvXfBsdyQHxqFgNzoYIr)
   if 'quickvod-mcdn.tving.com' in PMeDuSnUkATvXfBsdyQHxqFgNzoYIO:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYIL=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw
    PMeDuSnUkATvXfBsdyQHxqFgNzoYIt =PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    PMeDuSnUkATvXfBsdyQHxqFgNzoYIR=PMeDuSnUkATvXfBsdyQHxqFgNzoYIt.strftime('%Y-%m-%d-%H:%M:%S')
    if PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(PMeDuSnUkATvXfBsdyQHxqFgNzoYIR.replace('-','').replace(':',''))<PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(PMeDuSnUkATvXfBsdyQHxqFgNzoYIj['end'].replace('-','').replace(':','')):
     PMeDuSnUkATvXfBsdyQHxqFgNzoYIj['end']=PMeDuSnUkATvXfBsdyQHxqFgNzoYIR
     PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_noti(__language__(30915).encode('utf8'))
    PMeDuSnUkATvXfBsdyQHxqFgNzoYIO ='%s?%s'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYIO,urllib.parse.urlencode(PMeDuSnUkATvXfBsdyQHxqFgNzoYIj,doseq=PMeDuSnUkATvXfBsdyQHxqFgNzoYaw))
    PMeDuSnUkATvXfBsdyQHxqFgNzoYIJ='{}|{}'.format(PMeDuSnUkATvXfBsdyQHxqFgNzoYIO,PMeDuSnUkATvXfBsdyQHxqFgNzoYIK)
   else:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYIJ='{}|{}'.format(PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['streaming_url'],PMeDuSnUkATvXfBsdyQHxqFgNzoYIK)
  else:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIK=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.make_stream_header(PMeDuSnUkATvXfBsdyQHxqFgNzoYIh,PMeDuSnUkATvXfBsdyQHxqFgNzoYIr)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIJ='{}|{}'.format(PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['streaming_url'],PMeDuSnUkATvXfBsdyQHxqFgNzoYIK)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_log('if tmp_pos == -1')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVl,PMeDuSnUkATvXfBsdyQHxqFgNzoYVp=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_proxyport()
  PMeDuSnUkATvXfBsdyQHxqFgNzoYVW=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_playback()
  PMeDuSnUkATvXfBsdyQHxqFgNzoYIG=urllib.parse.urlparse(PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['streaming_url'])
  PMeDuSnUkATvXfBsdyQHxqFgNzoYIG=PMeDuSnUkATvXfBsdyQHxqFgNzoYIG.path.strip('/').split('/')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYIG=PMeDuSnUkATvXfBsdyQHxqFgNzoYIG[PMeDuSnUkATvXfBsdyQHxqFgNzoYCp(PMeDuSnUkATvXfBsdyQHxqFgNzoYIG)-1] 
  if(PMeDuSnUkATvXfBsdyQHxqFgNzoYVl and PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('mode')in['VOD','MOVIE']and PMeDuSnUkATvXfBsdyQHxqFgNzoYIL==PMeDuSnUkATvXfBsdyQHxqFgNzoYCc and PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['drm_license']!=''):
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYIG.split('.')[1]=='mpd':
    PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Tving_Parse_mpd(PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['streaming_url'],PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['watermarkKey'],PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['watermark'])
   else:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Tving_Parse_m3u8(PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['streaming_url'])
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_log('xxx '+PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['streaming_url'])
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIw={'addon':'tvingm','playOption':PMeDuSnUkATvXfBsdyQHxqFgNzoYVW,}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIw=json.dumps(PMeDuSnUkATvXfBsdyQHxqFgNzoYIw,separators=(',',':'))
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIw=base64.standard_b64encode(PMeDuSnUkATvXfBsdyQHxqFgNzoYIw.encode()).decode('utf-8')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIJ ='http://127.0.0.1:{}/{}&proxy-mini={}'.format(PMeDuSnUkATvXfBsdyQHxqFgNzoYVp,PMeDuSnUkATvXfBsdyQHxqFgNzoYIJ,PMeDuSnUkATvXfBsdyQHxqFgNzoYIw)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYIh['proxy-mini']=PMeDuSnUkATvXfBsdyQHxqFgNzoYIw 
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_log('surl(2) : {}'.format(PMeDuSnUkATvXfBsdyQHxqFgNzoYIJ))
  PMeDuSnUkATvXfBsdyQHxqFgNzoYIK=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.make_stream_header(PMeDuSnUkATvXfBsdyQHxqFgNzoYIh,PMeDuSnUkATvXfBsdyQHxqFgNzoYIr)
  PMeDuSnUkATvXfBsdyQHxqFgNzoYac=xbmcgui.ListItem(path=PMeDuSnUkATvXfBsdyQHxqFgNzoYIJ)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['drm_license']!='':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYaV=PMeDuSnUkATvXfBsdyQHxqFgNzoYIE['drm_license']
   PMeDuSnUkATvXfBsdyQHxqFgNzoYam ='https://cj.drmkeyserver.com/widevine_license'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYaW ='mpd'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYal ='com.widevine.alpha'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYap={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/','sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.USER_AGENT,'AcquireLicenseAssertion':PMeDuSnUkATvXfBsdyQHxqFgNzoYaV,'Host':'cj.drmkeyserver.com',}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYaI=PMeDuSnUkATvXfBsdyQHxqFgNzoYam+'|'+urllib.parse.urlencode(PMeDuSnUkATvXfBsdyQHxqFgNzoYap)+'|R{SSM}|'
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream','inputstream.adaptive')
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.KodiVersion<=20:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream.adaptive.manifest_type',PMeDuSnUkATvXfBsdyQHxqFgNzoYaW)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream.adaptive.license_type',PMeDuSnUkATvXfBsdyQHxqFgNzoYal)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream.adaptive.license_key',PMeDuSnUkATvXfBsdyQHxqFgNzoYaI)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream.adaptive.stream_headers',PMeDuSnUkATvXfBsdyQHxqFgNzoYIK)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream.adaptive.manifest_headers',PMeDuSnUkATvXfBsdyQHxqFgNzoYIK)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('mode')in['VOD','MOVIE']:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setContentLookup(PMeDuSnUkATvXfBsdyQHxqFgNzoYCc)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setMimeType('application/x-mpegURL')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream','inputstream.adaptive')
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.KodiVersion<=20:
    PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream.adaptive.manifest_type','hls')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream.adaptive.stream_headers',PMeDuSnUkATvXfBsdyQHxqFgNzoYIK)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream.adaptive.manifest_headers',PMeDuSnUkATvXfBsdyQHxqFgNzoYIK)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYIL==PMeDuSnUkATvXfBsdyQHxqFgNzoYaw:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setContentLookup(PMeDuSnUkATvXfBsdyQHxqFgNzoYCc)
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setMimeType('application/x-mpegURL')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream','inputstream.ffmpegdirect')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('ResumeTime','0')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYac.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,PMeDuSnUkATvXfBsdyQHxqFgNzoYaw,PMeDuSnUkATvXfBsdyQHxqFgNzoYac)
  try:
   if PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('mode')in['VOD','MOVIE']and PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('title'):
    PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'code':PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('programcode')if PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('mode')=='VOD' else PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('mediacode'),'img':PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('thumbnail'),'title':PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('title'),'videoid':PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('mediacode')}
    PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.Save_Watched_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('stype'),PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  except:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
 def logout(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcK=xbmcgui.Dialog()
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmh=PMeDuSnUkATvXfBsdyQHxqFgNzoYcK.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYmh==PMeDuSnUkATvXfBsdyQHxqFgNzoYCc:sys.exit()
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Init_TV_Total()
  if os.path.isfile(PMeDuSnUkATvXfBsdyQHxqFgNzoYcE):os.remove(PMeDuSnUkATvXfBsdyQHxqFgNzoYcE)
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.addon_noti(__language__(30909).encode('utf-8'))
 def cookiefile_save(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYaC =PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Get_Now_Datetime()
  PMeDuSnUkATvXfBsdyQHxqFgNzoYab=PMeDuSnUkATvXfBsdyQHxqFgNzoYaC+datetime.timedelta(days=PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(__addon__.getSetting('cache_ttl')))
  (PMeDuSnUkATvXfBsdyQHxqFgNzoYma,PMeDuSnUkATvXfBsdyQHxqFgNzoYmC,PMeDuSnUkATvXfBsdyQHxqFgNzoYmb,PMeDuSnUkATvXfBsdyQHxqFgNzoYmE)=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_account()
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Save_session_acount(PMeDuSnUkATvXfBsdyQHxqFgNzoYma,PMeDuSnUkATvXfBsdyQHxqFgNzoYmC,PMeDuSnUkATvXfBsdyQHxqFgNzoYmb,PMeDuSnUkATvXfBsdyQHxqFgNzoYmE)
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.TV['account']['token_limit']=PMeDuSnUkATvXfBsdyQHxqFgNzoYab.strftime('%Y%m%d')
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.JsonFile_Save(PMeDuSnUkATvXfBsdyQHxqFgNzoYcE,PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.TV)
 def cookiefile_check(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.TV=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.JsonFile_Load(PMeDuSnUkATvXfBsdyQHxqFgNzoYcE)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.TV=={}:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Init_TV_Total()
   return PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
  if '_tving_token' not in PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.TV.get('cookies'):
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Init_TV_Total()
   return PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
  (PMeDuSnUkATvXfBsdyQHxqFgNzoYaE,PMeDuSnUkATvXfBsdyQHxqFgNzoYah,PMeDuSnUkATvXfBsdyQHxqFgNzoYar,PMeDuSnUkATvXfBsdyQHxqFgNzoYaL)=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.get_settings_account()
  (PMeDuSnUkATvXfBsdyQHxqFgNzoYai,PMeDuSnUkATvXfBsdyQHxqFgNzoYaO,PMeDuSnUkATvXfBsdyQHxqFgNzoYaj,PMeDuSnUkATvXfBsdyQHxqFgNzoYaK)=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Load_session_acount()
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYaE!=PMeDuSnUkATvXfBsdyQHxqFgNzoYai or PMeDuSnUkATvXfBsdyQHxqFgNzoYah!=PMeDuSnUkATvXfBsdyQHxqFgNzoYaO or PMeDuSnUkATvXfBsdyQHxqFgNzoYar!=PMeDuSnUkATvXfBsdyQHxqFgNzoYaj or PMeDuSnUkATvXfBsdyQHxqFgNzoYaL!=PMeDuSnUkATvXfBsdyQHxqFgNzoYaK:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Init_TV_Total()
   return PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))>PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.TV['account']['token_limit']):
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.Init_TV_Total()
   return PMeDuSnUkATvXfBsdyQHxqFgNzoYCc
  return PMeDuSnUkATvXfBsdyQHxqFgNzoYaw
 def dp_Global_Search(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=PMeDuSnUkATvXfBsdyQHxqFgNzoYmK.get('mode')
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='TOTAL_SEARCH':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYat='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYat='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(PMeDuSnUkATvXfBsdyQHxqFgNzoYat)
 def dp_Bookmark_Menu(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYat='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(PMeDuSnUkATvXfBsdyQHxqFgNzoYat)
 def dp_EuroLive_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr,PMeDuSnUkATvXfBsdyQHxqFgNzoYmK):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYmR=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.GetEuroChannelList()
  for PMeDuSnUkATvXfBsdyQHxqFgNzoYmG in PMeDuSnUkATvXfBsdyQHxqFgNzoYmR:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWO =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('channel')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYVO =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('title')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWE =PMeDuSnUkATvXfBsdyQHxqFgNzoYmG.get('subtitle')
   PMeDuSnUkATvXfBsdyQHxqFgNzoYWb={'mediatype':'episode','title':PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,'plot':'%s\n%s'%(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,PMeDuSnUkATvXfBsdyQHxqFgNzoYWE)}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYmV={'mode':'LIVE','mediacode':PMeDuSnUkATvXfBsdyQHxqFgNzoYWO,'stype':'onair',}
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.add_dir(PMeDuSnUkATvXfBsdyQHxqFgNzoYVO,sublabel=PMeDuSnUkATvXfBsdyQHxqFgNzoYWE,img='',infoLabels=PMeDuSnUkATvXfBsdyQHxqFgNzoYWb,isFolder=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc,params=PMeDuSnUkATvXfBsdyQHxqFgNzoYmV)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYCp(PMeDuSnUkATvXfBsdyQHxqFgNzoYmR)>0:xbmcplugin.endOfDirectory(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr._addon_handle,cacheToDisc=PMeDuSnUkATvXfBsdyQHxqFgNzoYCc)
 def tving_main(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr):
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.TvingObj.KodiVersion=PMeDuSnUkATvXfBsdyQHxqFgNzoYaG(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
  PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params.get('mode',PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ)
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='LOGOUT':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.logout()
   return
  PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.login_main()
  if PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ is PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_Main_List()
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_Title_Group(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ in['GLOBAL_GROUP']:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_SubTitle_Group(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='CHANNEL':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_LiveChannel_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ in['LIVE','VOD','MOVIE']:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.play_VIDEO(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='PROGRAM':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_Program_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='4K_PROGRAM':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_4K_Program_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='ORI_PROGRAM':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_Ori_Program_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='EPISODE':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_Episode_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='MOVIE_SUB':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_Movie_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='4K_MOVIE':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_4K_Movie_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='SEARCH_GROUP':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_Search_Group(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ in['SEARCH','LOCAL_SEARCH']:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_Search_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='WATCH':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_Watch_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_History_Remove(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='ORDER_BY':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_setEpOrderby(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='SET_BOOKMARK':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_Set_Bookmark(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ in['TOTAL_SEARCH','TOTAL_HISTORY']:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_Global_Search(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='SEARCH_HISTORY':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_Search_History(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='MENU_BOOKMARK':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_Bookmark_Menu(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  elif PMeDuSnUkATvXfBsdyQHxqFgNzoYlJ=='EURO_GROUP':
   PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.dp_EuroLive_List(PMeDuSnUkATvXfBsdyQHxqFgNzoYcr.main_params)
  else:
   PMeDuSnUkATvXfBsdyQHxqFgNzoYaJ
# Created by pyminifier (https://github.com/liftoff/pyminifier)
