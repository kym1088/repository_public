__author__="NightRain"
NvhOQfsGtWaUeATlKCRPpLIgXHBwry=print
NvhOQfsGtWaUeATlKCRPpLIgXHBwEJ=ImportError
NvhOQfsGtWaUeATlKCRPpLIgXHBwEo=object
NvhOQfsGtWaUeATlKCRPpLIgXHBwES=None
NvhOQfsGtWaUeATlKCRPpLIgXHBwEk=False
NvhOQfsGtWaUeATlKCRPpLIgXHBwEx=open
NvhOQfsGtWaUeATlKCRPpLIgXHBwEc=True
NvhOQfsGtWaUeATlKCRPpLIgXHBwEr=len
NvhOQfsGtWaUeATlKCRPpLIgXHBwEd=int
NvhOQfsGtWaUeATlKCRPpLIgXHBwEb=range
NvhOQfsGtWaUeATlKCRPpLIgXHBwEi=Exception
NvhOQfsGtWaUeATlKCRPpLIgXHBwEM=str
NvhOQfsGtWaUeATlKCRPpLIgXHBwEq=dict
NvhOQfsGtWaUeATlKCRPpLIgXHBwEV=list
NvhOQfsGtWaUeATlKCRPpLIgXHBwED=bytes
NvhOQfsGtWaUeATlKCRPpLIgXHBwEY=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 NvhOQfsGtWaUeATlKCRPpLIgXHBwry('Cryptodome')
except NvhOQfsGtWaUeATlKCRPpLIgXHBwEJ:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 NvhOQfsGtWaUeATlKCRPpLIgXHBwry('Crypto')
NvhOQfsGtWaUeATlKCRPpLIgXHBwJS={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
NvhOQfsGtWaUeATlKCRPpLIgXHBwJk ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
NvhOQfsGtWaUeATlKCRPpLIgXHBwJx =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
NvhOQfsGtWaUeATlKCRPpLIgXHBwJc=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','authToken','cs','TSID','accessToken','refreshToken','_tving_token','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class NvhOQfsGtWaUeATlKCRPpLIgXHBwJo(NvhOQfsGtWaUeATlKCRPpLIgXHBwEo):
 def __init__(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.NETWORKCODE ='CSND0900'
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.OSCODE ='CSOD0900' 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TELECODE ='CSCD0900'
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.SCREENCODE ='CSSD0100'
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.SCREENCODE_ATV ='CSSD1300' 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.LIVE_LIMIT =20 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.VOD_LIMIT =24 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.EPISODE_LIMIT =30 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.SEARCH_LIMIT =30 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.MOVIE_LIMIT =24 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN ='https://api.tving.com'
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN ='https://image.tving.com'
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.SEARCH_DOMAIN ='https://search-api.tving.com'
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.LOGIN_DOMAIN ='https://user.tving.com'
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.URL_DOMAIN ='https://www.tving.com'
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.MOVIE_LITE =['2610061','2610161','261062']
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.DEFAULT_HEADER ={'user-agent':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.USER_AGENT}
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.COOKIE_FILE_NAME =''
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV_SESSION_COOKIES1=''
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV_SESSION_COOKIES2=''
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV_STREAM_FILENAME =''
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV_SESSION_TEXT1 =''
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV_SESSION_TEXT2 =''
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.KodiVersion=20
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV ={}
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Init_TV_Total()
 def Init_TV_Total(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV={'account':{},'cookies':{},}
 def callRequestCookies(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,jobtype,NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,redirects=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.DEFAULT_HEADER
  if headers:NvhOQfsGtWaUeATlKCRPpLIgXHBwJE.update(headers)
  if jobtype=='Get':
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJd=requests.get(NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,params=params,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwJE,cookies=cookies,allow_redirects=redirects)
  else:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJd=requests.post(NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,data=payload,params=params,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwJE,cookies=cookies,allow_redirects=redirects)
  NvhOQfsGtWaUeATlKCRPpLIgXHBwry(NvhOQfsGtWaUeATlKCRPpLIgXHBwJd.url)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwJd
 def JsonFile_Save(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,filename,NvhOQfsGtWaUeATlKCRPpLIgXHBwJb):
  if filename=='':return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  try:
   fp=NvhOQfsGtWaUeATlKCRPpLIgXHBwEx(filename,'w',-1,'utf-8')
   json.dump(NvhOQfsGtWaUeATlKCRPpLIgXHBwJb,fp,indent=4,ensure_ascii=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk)
   fp.close()
  except:
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
 def JsonFile_Load(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,filename):
  if filename=='':return{}
  try:
   fp=NvhOQfsGtWaUeATlKCRPpLIgXHBwEx(filename,'r',-1,'utf-8')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJM=json.load(fp)
   fp.close()
  except:
   return{}
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwJM
 def TextFile_Save(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,filename,resText):
  if filename=='':return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  try:
   fp=NvhOQfsGtWaUeATlKCRPpLIgXHBwEx(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
 def Save_session_acount(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,NvhOQfsGtWaUeATlKCRPpLIgXHBwJq,NvhOQfsGtWaUeATlKCRPpLIgXHBwJV,NvhOQfsGtWaUeATlKCRPpLIgXHBwJD,NvhOQfsGtWaUeATlKCRPpLIgXHBwJY):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['account']['tvid'] =base64.standard_b64encode(NvhOQfsGtWaUeATlKCRPpLIgXHBwJq.encode()).decode('utf-8')
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['account']['tvpw'] =base64.standard_b64encode(NvhOQfsGtWaUeATlKCRPpLIgXHBwJV.encode()).decode('utf-8')
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['account']['tvtype']=NvhOQfsGtWaUeATlKCRPpLIgXHBwJD 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['account']['tvpf'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwJY 
 def Load_session_acount(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr):
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJq =base64.standard_b64decode(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['account']['tvid']).decode('utf-8')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJV =base64.standard_b64decode(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['account']['tvpw']).decode('utf-8')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJD=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['account']['tvtype']
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJY =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwJq,NvhOQfsGtWaUeATlKCRPpLIgXHBwJV,NvhOQfsGtWaUeATlKCRPpLIgXHBwJD,NvhOQfsGtWaUeATlKCRPpLIgXHBwJY
 def make_stream_header(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,NvhOQfsGtWaUeATlKCRPpLIgXHBwJu,NvhOQfsGtWaUeATlKCRPpLIgXHBwJy):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJn=''
  if NvhOQfsGtWaUeATlKCRPpLIgXHBwJy not in[{},NvhOQfsGtWaUeATlKCRPpLIgXHBwES,'']:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJj=NvhOQfsGtWaUeATlKCRPpLIgXHBwEr(NvhOQfsGtWaUeATlKCRPpLIgXHBwJy)
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwJF,NvhOQfsGtWaUeATlKCRPpLIgXHBwJm in NvhOQfsGtWaUeATlKCRPpLIgXHBwJy.items():
    NvhOQfsGtWaUeATlKCRPpLIgXHBwJn+='{}={}'.format(NvhOQfsGtWaUeATlKCRPpLIgXHBwJF,NvhOQfsGtWaUeATlKCRPpLIgXHBwJm)
    NvhOQfsGtWaUeATlKCRPpLIgXHBwJj+=-1
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwJj>0:NvhOQfsGtWaUeATlKCRPpLIgXHBwJn+='; '
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJu['cookie']=NvhOQfsGtWaUeATlKCRPpLIgXHBwJn
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJz=''
  i=0
  for NvhOQfsGtWaUeATlKCRPpLIgXHBwJF,NvhOQfsGtWaUeATlKCRPpLIgXHBwJm in NvhOQfsGtWaUeATlKCRPpLIgXHBwJu.items():
   i=i+1
   if i>1:NvhOQfsGtWaUeATlKCRPpLIgXHBwJz+='&'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJz+='{}={}'.format(NvhOQfsGtWaUeATlKCRPpLIgXHBwJF,urllib.parse.quote(NvhOQfsGtWaUeATlKCRPpLIgXHBwJm))
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwJz
 def makeDefaultCookies(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJy={}
  for NvhOQfsGtWaUeATlKCRPpLIgXHBwJF,NvhOQfsGtWaUeATlKCRPpLIgXHBwJm in NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies'].items():
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJy[NvhOQfsGtWaUeATlKCRPpLIgXHBwJF]=NvhOQfsGtWaUeATlKCRPpLIgXHBwJm
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwJy
 def getDeviceStr(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoJ=[]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoJ.append('Windows') 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoJ.append('Chrome') 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoJ.append('ko-KR') 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoJ.append('undefined') 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoJ.append('24') 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoJ.append(u'한국 표준시')
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoJ.append('undefined') 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoJ.append('undefined') 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoJ.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoS=''
  for NvhOQfsGtWaUeATlKCRPpLIgXHBwok in NvhOQfsGtWaUeATlKCRPpLIgXHBwoJ:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoS+=NvhOQfsGtWaUeATlKCRPpLIgXHBwok+'|'
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwoS
 def GetDefaultParams(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,uhd=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk):
  if uhd==NvhOQfsGtWaUeATlKCRPpLIgXHBwEk:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwox={'apiKey':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.APIKEY,'networkCode':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.NETWORKCODE,'osCode':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.OSCODE,'teleCode':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TELECODE,'screenCode':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.SCREENCODE,}
  else:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwox={'apiKey':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.APIKEY_ATV,'networkCode':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.NETWORKCODE,'osCode':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.OSCODE,'teleCode':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TELECODE,'screenCode':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.SCREENCODE_ATV,}
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwox
 def GetNoCache(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,timetype=1):
  if timetype==1:
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(time.time())
  else:
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(time.time()*1000)
 def GetUniqueid(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,hValue=NvhOQfsGtWaUeATlKCRPpLIgXHBwES):
  if hValue:
   import hashlib
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoc=hashlib.sha1()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoc.update(hValue.encode())
   NvhOQfsGtWaUeATlKCRPpLIgXHBwor=NvhOQfsGtWaUeATlKCRPpLIgXHBwoc.hexdigest()[:8]
  else:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoE=[0 for i in NvhOQfsGtWaUeATlKCRPpLIgXHBwEb(256)]
   for i in NvhOQfsGtWaUeATlKCRPpLIgXHBwEb(256):
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoE[i]='%02x'%(i)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwod=NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(4294967295*random.random())|0
   NvhOQfsGtWaUeATlKCRPpLIgXHBwor=NvhOQfsGtWaUeATlKCRPpLIgXHBwoE[255&NvhOQfsGtWaUeATlKCRPpLIgXHBwod]+NvhOQfsGtWaUeATlKCRPpLIgXHBwoE[NvhOQfsGtWaUeATlKCRPpLIgXHBwod>>8&255]+NvhOQfsGtWaUeATlKCRPpLIgXHBwoE[NvhOQfsGtWaUeATlKCRPpLIgXHBwod>>16&255]+NvhOQfsGtWaUeATlKCRPpLIgXHBwoE[NvhOQfsGtWaUeATlKCRPpLIgXHBwod>>24&255]
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwor
 def GetCredential(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,user_id,user_pw,login_type,user_pf):
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwob=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoi={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Post',NvhOQfsGtWaUeATlKCRPpLIgXHBwob,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwoi,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwoq in NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.cookies:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies'][NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.name]=NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.value
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Init_TV_Total()
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoV=[]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoD =''
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJy=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.makeDefaultCookies()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwoY,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwJy)
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwoq in NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.cookies:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies'][NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.name]=NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.value
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoV =re.findall('data-profile-no="\d+"',NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   for i in NvhOQfsGtWaUeATlKCRPpLIgXHBwEb(NvhOQfsGtWaUeATlKCRPpLIgXHBwEr(NvhOQfsGtWaUeATlKCRPpLIgXHBwoV)):
    NvhOQfsGtWaUeATlKCRPpLIgXHBwon =NvhOQfsGtWaUeATlKCRPpLIgXHBwoV[i].replace('data-profile-no=','').replace('"','')
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoV[i]=NvhOQfsGtWaUeATlKCRPpLIgXHBwon
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoD=NvhOQfsGtWaUeATlKCRPpLIgXHBwoV[user_pf]
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Init_TV_Total()
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJy=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.makeDefaultCookies()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoi={'profileNo':NvhOQfsGtWaUeATlKCRPpLIgXHBwoD}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Post',NvhOQfsGtWaUeATlKCRPpLIgXHBwoY,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwoi,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwJy)
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwoq in NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.cookies:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies'][NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.name]=NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.value
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Init_TV_Total()
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoj =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDeviceList()
  if NvhOQfsGtWaUeATlKCRPpLIgXHBwoj not in['','-']:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_uuid']=NvhOQfsGtWaUeATlKCRPpLIgXHBwoj+'-'+NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetUniqueid(NvhOQfsGtWaUeATlKCRPpLIgXHBwoj)
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.JsonFile_Save(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.COOKIE_FILE_NAME,NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
 def GetCredential_old(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,user_id,user_pw,login_type,user_pf):
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwob=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoi={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Post',NvhOQfsGtWaUeATlKCRPpLIgXHBwob,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwoi,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwoq in NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.cookies:
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.name=='_tving_token':
     NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_token']=NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.value
    elif NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.name=='POC_USERINFO':
     NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_userinfo']=NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.value
    elif NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.name=='authToken':
     NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_authToken']=NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.value
   if not NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_token']:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Init_TV_Total()
    return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_maintoken']=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_token']
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetProfileToken(user_pf)==NvhOQfsGtWaUeATlKCRPpLIgXHBwEk:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Init_TV_Total()
    return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies'])
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoj =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDeviceList()
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwoj not in['','-']:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_uuid']=NvhOQfsGtWaUeATlKCRPpLIgXHBwoj+'-'+NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetUniqueid(NvhOQfsGtWaUeATlKCRPpLIgXHBwoj)
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Init_TV_Total()
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
 def GetProfileToken(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,user_pf):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoV=[]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoD =''
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJy=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.makeDefaultCookies()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwoY,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwJy)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoV =re.findall('data-profile-no="\d+"',NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(NvhOQfsGtWaUeATlKCRPpLIgXHBwoV)
   for i in NvhOQfsGtWaUeATlKCRPpLIgXHBwEb(NvhOQfsGtWaUeATlKCRPpLIgXHBwEr(NvhOQfsGtWaUeATlKCRPpLIgXHBwoV)):
    NvhOQfsGtWaUeATlKCRPpLIgXHBwon =NvhOQfsGtWaUeATlKCRPpLIgXHBwoV[i].replace('data-profile-no=','').replace('"','')
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoV[i]=NvhOQfsGtWaUeATlKCRPpLIgXHBwon
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoD=NvhOQfsGtWaUeATlKCRPpLIgXHBwoV[user_pf]
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Init_TV_Total()
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJy=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.makeDefaultCookies()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoi={'profileNo':NvhOQfsGtWaUeATlKCRPpLIgXHBwoD}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Post',NvhOQfsGtWaUeATlKCRPpLIgXHBwoY,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwoi,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwJy)
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwoq in NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.cookies:
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.name=='_tving_token':
     NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_token']=NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.value
    elif NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.name==NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GLOBAL_COOKIENM['tv_cookiekey']:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_cookiekey']=NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.value
    elif NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.name==NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GLOBAL_COOKIENM['tv_lockkey']:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_lockkey']=NvhOQfsGtWaUeATlKCRPpLIgXHBwoq.value
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Init_TV_Total()
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
 def GetDeviceList(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoF=[]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwom='-'
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v1/user/device/list'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwou=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJy=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.makeDefaultCookies()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwou,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwoz,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwJy)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoF=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwoF:
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['model'].lower().startswith('pc'):
     NvhOQfsGtWaUeATlKCRPpLIgXHBwom=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['uuid']
     break
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwom=='-':
    NvhOQfsGtWaUeATlKCRPpLIgXHBwom=NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetNoCache(timetype=1))
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwom
 def Get_Now_Datetime(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,mediacode,sel_quality,stype,pvrmode='-',optUHD=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSk ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','subtitleYn':NvhOQfsGtWaUeATlKCRPpLIgXHBwEk,'error_msg':'',}
  NvhOQfsGtWaUeATlKCRPpLIgXHBwom =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_uuid'].split('-')[0] 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSx =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_uuid'] 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSc=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk 
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSr=NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetNoCache(1))
   if stype!='tvingtv':
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2/media/stream/info' 
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':NvhOQfsGtWaUeATlKCRPpLIgXHBwSx,'deviceInfo':'PC','noCache':NvhOQfsGtWaUeATlKCRPpLIgXHBwSr,}
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
    NvhOQfsGtWaUeATlKCRPpLIgXHBwJy=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.makeDefaultCookies()
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwJy)
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.status_code!=200:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['error_msg']='First Step - {} error'.format(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.status_code)
     return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']['code']=='060':
     for NvhOQfsGtWaUeATlKCRPpLIgXHBwJF,NvhOQfsGtWaUeATlKCRPpLIgXHBwJm in NvhOQfsGtWaUeATlKCRPpLIgXHBwJS.items():
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwJm==sel_quality:
       NvhOQfsGtWaUeATlKCRPpLIgXHBwSb=NvhOQfsGtWaUeATlKCRPpLIgXHBwJF
    elif NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']['code']!='000':
     NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['error_msg']=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']['message']
     return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
    else: 
     if not('stream' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']):return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
     NvhOQfsGtWaUeATlKCRPpLIgXHBwSi=[]
     for NvhOQfsGtWaUeATlKCRPpLIgXHBwJF,NvhOQfsGtWaUeATlKCRPpLIgXHBwJm in NvhOQfsGtWaUeATlKCRPpLIgXHBwJS.items():
      for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['stream']['quality']:
       if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['active']=='Y' and NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['code']==NvhOQfsGtWaUeATlKCRPpLIgXHBwJF:
        NvhOQfsGtWaUeATlKCRPpLIgXHBwSi.append({NvhOQfsGtWaUeATlKCRPpLIgXHBwJS.get(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['code']):NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['code']})
     NvhOQfsGtWaUeATlKCRPpLIgXHBwSb=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.CheckQuality(sel_quality,NvhOQfsGtWaUeATlKCRPpLIgXHBwSi)
     try:
      if optUHD==NvhOQfsGtWaUeATlKCRPpLIgXHBwEc and NvhOQfsGtWaUeATlKCRPpLIgXHBwSb=='stream50' and 'stream_support_info' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['content']['info']:
       if NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['content']['info']['stream_support_info']!=NvhOQfsGtWaUeATlKCRPpLIgXHBwES:
        if 'stream70' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['content']['info']['stream_support_info']:
         NvhOQfsGtWaUeATlKCRPpLIgXHBwSb='stream70'
         NvhOQfsGtWaUeATlKCRPpLIgXHBwSc =NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
     except:
      pass
     try:
      if optUHD==NvhOQfsGtWaUeATlKCRPpLIgXHBwEc and NvhOQfsGtWaUeATlKCRPpLIgXHBwSb=='stream50' and 'stream' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['content']['info']:
       if NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['content']['info']['stream']!=NvhOQfsGtWaUeATlKCRPpLIgXHBwES:
        for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['content']['info']['stream']:
         if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['code']=='stream70':
          NvhOQfsGtWaUeATlKCRPpLIgXHBwSb='stream70'
          NvhOQfsGtWaUeATlKCRPpLIgXHBwSc =NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
          break
     except:
      pass
   else:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSb='stream40'
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['error_msg']='First Step - except error'
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
  NvhOQfsGtWaUeATlKCRPpLIgXHBwry(NvhOQfsGtWaUeATlKCRPpLIgXHBwSb)
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSr=NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetNoCache(1))
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2a/media/stream/info'
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwSc==NvhOQfsGtWaUeATlKCRPpLIgXHBwEc:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams(uhd=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc)
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'mediaCode':mediacode,'noCache':NvhOQfsGtWaUeATlKCRPpLIgXHBwSr,'streamType':'hls','streamCode':NvhOQfsGtWaUeATlKCRPpLIgXHBwSb,'deviceId':NvhOQfsGtWaUeATlKCRPpLIgXHBwom,'adReq':'none','wm':'Y','ad_device':'','uuid':NvhOQfsGtWaUeATlKCRPpLIgXHBwSx,'deviceInfo':'android_tv',}
   else:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':NvhOQfsGtWaUeATlKCRPpLIgXHBwSb,'deviceId':NvhOQfsGtWaUeATlKCRPpLIgXHBwom,'uuid':NvhOQfsGtWaUeATlKCRPpLIgXHBwSx,'deviceInfo':'PC_Chrome','noCache':NvhOQfsGtWaUeATlKCRPpLIgXHBwSr,'wm':'Y'}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJy=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.makeDefaultCookies()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwJy,redirects=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']['code']!='000':
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['error_msg']=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']['message']
    return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSM=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['stream']
   if 'drm_license_assertion' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSM:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['drm_license']=NvhOQfsGtWaUeATlKCRPpLIgXHBwSM['drm_license_assertion']
    if '4k_nondrm_url' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSM['broadcast']and NvhOQfsGtWaUeATlKCRPpLIgXHBwSc==NvhOQfsGtWaUeATlKCRPpLIgXHBwEc:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwSq =NvhOQfsGtWaUeATlKCRPpLIgXHBwSM['broadcast']['4k_nondrm_url']
     NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['drm_license']=''
    else:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwSq =NvhOQfsGtWaUeATlKCRPpLIgXHBwSM['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSM['broadcast']):return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSq=NvhOQfsGtWaUeATlKCRPpLIgXHBwSM['broadcast']['broad_url']
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['error_msg']='Second Step - except error'
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSV=NvhOQfsGtWaUeATlKCRPpLIgXHBwSr
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSq=NvhOQfsGtWaUeATlKCRPpLIgXHBwSq.split('|')[1]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSq,NvhOQfsGtWaUeATlKCRPpLIgXHBwSD,NvhOQfsGtWaUeATlKCRPpLIgXHBwSY=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Decrypt_Url(NvhOQfsGtWaUeATlKCRPpLIgXHBwSq,mediacode,NvhOQfsGtWaUeATlKCRPpLIgXHBwSV)
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['streaming_url']=NvhOQfsGtWaUeATlKCRPpLIgXHBwSq
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['watermark'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwSD
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['watermarkKey']=NvhOQfsGtWaUeATlKCRPpLIgXHBwSY
  if 'subtitles' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSM:
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwSn in NvhOQfsGtWaUeATlKCRPpLIgXHBwSM.get('subtitles'):
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwSn.get('code')in['KO','KO_CC']:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['subtitleYn']=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
     break
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
 def Tving_Parse_mpd(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,stream_url,watermarkKey=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,watermark=NvhOQfsGtWaUeATlKCRPpLIgXHBwES):
  if watermarkKey not in['',NvhOQfsGtWaUeATlKCRPpLIgXHBwES]:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJu={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,'Access-Control-Request-Headers':'x-tving-param1,x-tving-param2',}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=requests.get(url=stream_url,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwJu,allow_redirects=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.status_code)+' - '+NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.url))
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry('')
  else:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=requests.get(url=stream_url)
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSj=NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.content.decode('utf-8')
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSF=0
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSm =ET.ElementTree(ET.fromstring(NvhOQfsGtWaUeATlKCRPpLIgXHBwSj))
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSu =NvhOQfsGtWaUeATlKCRPpLIgXHBwSm.getroot()
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSz=re.match(r'\{.*\}',NvhOQfsGtWaUeATlKCRPpLIgXHBwSu.tag)[0] 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSy=NvhOQfsGtWaUeATlKCRPpLIgXHBwEq([node for _,node in ET.iterparse(io.StringIO(NvhOQfsGtWaUeATlKCRPpLIgXHBwSj),events=['start-ns'])])
  for NvhOQfsGtWaUeATlKCRPpLIgXHBwJF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkn in NvhOQfsGtWaUeATlKCRPpLIgXHBwSy.items():
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwJF!='ns2':
    ET.register_namespace(NvhOQfsGtWaUeATlKCRPpLIgXHBwJF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkn)
  NvhOQfsGtWaUeATlKCRPpLIgXHBwkJ=NvhOQfsGtWaUeATlKCRPpLIgXHBwSu.find(NvhOQfsGtWaUeATlKCRPpLIgXHBwSz+'Period')
  for NvhOQfsGtWaUeATlKCRPpLIgXHBwko in NvhOQfsGtWaUeATlKCRPpLIgXHBwkJ.findall(NvhOQfsGtWaUeATlKCRPpLIgXHBwSz+'AdaptationSet'):
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwko.attrib.get('mimeType')=='video/mp4':
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwkS in NvhOQfsGtWaUeATlKCRPpLIgXHBwko.findall(NvhOQfsGtWaUeATlKCRPpLIgXHBwSz+'Representation'):
     NvhOQfsGtWaUeATlKCRPpLIgXHBwkx=NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(NvhOQfsGtWaUeATlKCRPpLIgXHBwkS.attrib.get('bandwidth'))
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwSF<NvhOQfsGtWaUeATlKCRPpLIgXHBwkx:NvhOQfsGtWaUeATlKCRPpLIgXHBwSF=NvhOQfsGtWaUeATlKCRPpLIgXHBwkx
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwkS in NvhOQfsGtWaUeATlKCRPpLIgXHBwko.findall(NvhOQfsGtWaUeATlKCRPpLIgXHBwSz+'Representation'):
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwSF>NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(NvhOQfsGtWaUeATlKCRPpLIgXHBwkS.attrib.get('bandwidth')):
      NvhOQfsGtWaUeATlKCRPpLIgXHBwko.remove(NvhOQfsGtWaUeATlKCRPpLIgXHBwkS)
   else:
    continue
  NvhOQfsGtWaUeATlKCRPpLIgXHBwkc=ET.tostring(NvhOQfsGtWaUeATlKCRPpLIgXHBwSu).decode('utf-8')
  NvhOQfsGtWaUeATlKCRPpLIgXHBwkr='<?xml version="1.0" encoding="UTF-8"?>\n'
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TextFile_Save(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV_STREAM_FILENAME,NvhOQfsGtWaUeATlKCRPpLIgXHBwkr+NvhOQfsGtWaUeATlKCRPpLIgXHBwkc)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
 def Tving_Parse_m3u8(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,stream_url):
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=requests.get(url=stream_url,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,stream=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkE=NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.content.decode('utf-8')
   if '#EXTM3U' not in NvhOQfsGtWaUeATlKCRPpLIgXHBwkE:
    return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
   if '#EXT-X-STREAM-INF' not in NvhOQfsGtWaUeATlKCRPpLIgXHBwkE: 
    return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkd=0
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwkb in NvhOQfsGtWaUeATlKCRPpLIgXHBwkE.splitlines():
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwkb.startswith('#EXT-X-STREAM-INF'):
     NvhOQfsGtWaUeATlKCRPpLIgXHBwki=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.MediaLine_Parse(NvhOQfsGtWaUeATlKCRPpLIgXHBwkb,'#EXT-X-STREAM-INF')
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwkd<NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(NvhOQfsGtWaUeATlKCRPpLIgXHBwki.get('BANDWIDTH')):
      NvhOQfsGtWaUeATlKCRPpLIgXHBwkd=NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(NvhOQfsGtWaUeATlKCRPpLIgXHBwki.get('BANDWIDTH'))
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkM=[]
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkq=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwkb in NvhOQfsGtWaUeATlKCRPpLIgXHBwkE.splitlines():
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwkq==NvhOQfsGtWaUeATlKCRPpLIgXHBwEc:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwkq=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
     continue
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwkb.startswith('#EXT-X-STREAM-INF'):
     NvhOQfsGtWaUeATlKCRPpLIgXHBwki=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.MediaLine_Parse(NvhOQfsGtWaUeATlKCRPpLIgXHBwkb,'#EXT-X-STREAM-INF')
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwkd!=NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(NvhOQfsGtWaUeATlKCRPpLIgXHBwki.get('BANDWIDTH')):
      NvhOQfsGtWaUeATlKCRPpLIgXHBwkq=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
      continue
    NvhOQfsGtWaUeATlKCRPpLIgXHBwkM.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwkb)
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  NvhOQfsGtWaUeATlKCRPpLIgXHBwkV='\n'.join(NvhOQfsGtWaUeATlKCRPpLIgXHBwkM)
  NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TextFile_Save(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV_STREAM_FILENAME,NvhOQfsGtWaUeATlKCRPpLIgXHBwkV)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
 def MediaLine_Parse(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,NvhOQfsGtWaUeATlKCRPpLIgXHBwkb,prefix):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwki={}
  for NvhOQfsGtWaUeATlKCRPpLIgXHBwkD in NvhOQfsGtWaUeATlKCRPpLIgXHBwJx.split(NvhOQfsGtWaUeATlKCRPpLIgXHBwkb.replace(prefix+':',''))[1::2]:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkY,NvhOQfsGtWaUeATlKCRPpLIgXHBwkn=NvhOQfsGtWaUeATlKCRPpLIgXHBwkD.split('=',1)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwki[NvhOQfsGtWaUeATlKCRPpLIgXHBwkY.upper()]=NvhOQfsGtWaUeATlKCRPpLIgXHBwkn.replace('"','').strip()
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwki
 def CheckQuality(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,sel_qt,NvhOQfsGtWaUeATlKCRPpLIgXHBwSi):
  for NvhOQfsGtWaUeATlKCRPpLIgXHBwkj in NvhOQfsGtWaUeATlKCRPpLIgXHBwSi:
   if sel_qt>=NvhOQfsGtWaUeATlKCRPpLIgXHBwEV(NvhOQfsGtWaUeATlKCRPpLIgXHBwkj)[0]:return NvhOQfsGtWaUeATlKCRPpLIgXHBwkj.get(NvhOQfsGtWaUeATlKCRPpLIgXHBwEV(NvhOQfsGtWaUeATlKCRPpLIgXHBwkj)[0])
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkF=NvhOQfsGtWaUeATlKCRPpLIgXHBwkj.get(NvhOQfsGtWaUeATlKCRPpLIgXHBwEV(NvhOQfsGtWaUeATlKCRPpLIgXHBwkj)[0])
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwkF
 def makeOocUrl(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,ooc_params):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=''
  for NvhOQfsGtWaUeATlKCRPpLIgXHBwJF,NvhOQfsGtWaUeATlKCRPpLIgXHBwJm in ooc_params.items():
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd+="%s=%s^"%(NvhOQfsGtWaUeATlKCRPpLIgXHBwJF,NvhOQfsGtWaUeATlKCRPpLIgXHBwJm)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwSd
 def GetLiveChannelList(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,stype,page_int):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoF=[]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2/media/lives'
   if stype=='onair': 
    NvhOQfsGtWaUeATlKCRPpLIgXHBwku='CPCS0100,CPCS0400'
   else:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwku='CPCS0300'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'cacheType':'main','pageNo':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(page_int),'pageSize':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':NvhOQfsGtWaUeATlKCRPpLIgXHBwku,}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if not('result' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']):return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkz=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwkz:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwky=NvhOQfsGtWaUeATlKCRPpLIgXHBwxS=NvhOQfsGtWaUeATlKCRPpLIgXHBwxk=''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxJ=NvhOQfsGtWaUeATlKCRPpLIgXHBwxz=''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxo=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['live_code']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwky =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['channel']['name']['ko']
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['episode']!=NvhOQfsGtWaUeATlKCRPpLIgXHBwES:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxS =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['program']['name']['ko']
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxS =NvhOQfsGtWaUeATlKCRPpLIgXHBwxS+', '+NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['episode']['frequency'])+'회'
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxk=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['episode']['synopsis']['ko']
    else:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxS =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['program']['name']['ko']
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxk=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['program']['synopsis']['ko']
    try: 
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =''
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =''
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=''
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxd =''
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxb =''
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxi =''
     for NvhOQfsGtWaUeATlKCRPpLIgXHBwxM in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['program']['image']:
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP0900':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
      elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP1800':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
      elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP2000':NvhOQfsGtWaUeATlKCRPpLIgXHBwxd =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
      elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP1900':NvhOQfsGtWaUeATlKCRPpLIgXHBwxb =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
      elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP0200':NvhOQfsGtWaUeATlKCRPpLIgXHBwxi =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
      elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP0500':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
      elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP0800':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwxc=='':
      for NvhOQfsGtWaUeATlKCRPpLIgXHBwxM in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['channel']['image']:
       if NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIC0400':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
       elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIC1400':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
       elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIC1900':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
    except:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwES
    try:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxq =[]
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxV=[]
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxD =[]
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxY=''
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxn=''
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxj=''
     for NvhOQfsGtWaUeATlKCRPpLIgXHBwxF in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('schedule').get('program').get('actor'):
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwxF!='' and NvhOQfsGtWaUeATlKCRPpLIgXHBwxF!=u'없음':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxF)
     for NvhOQfsGtWaUeATlKCRPpLIgXHBwxm in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('schedule').get('program').get('director'):
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwxm!='' and NvhOQfsGtWaUeATlKCRPpLIgXHBwxm!='-' and NvhOQfsGtWaUeATlKCRPpLIgXHBwxm!=u'없음':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxm)
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('schedule').get('program').get('category1_name').get('ko')!='':
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxD.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['program']['category1_name']['ko'])
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('schedule').get('program').get('category2_name').get('ko')!='':
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxD.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['program']['category2_name']['ko'])
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('schedule').get('program').get('product_year'):NvhOQfsGtWaUeATlKCRPpLIgXHBwxY=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['program']['product_year']
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('schedule').get('program').get('grade_code') :NvhOQfsGtWaUeATlKCRPpLIgXHBwxn= NvhOQfsGtWaUeATlKCRPpLIgXHBwJk.get(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['program']['grade_code'])
     if 'broad_dt' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('schedule').get('program'):
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxu =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('schedule').get('program').get('broad_dt')
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxj='%s-%s-%s'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[:4],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[4:6],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[6:])
    except:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwES
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxJ=NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['broadcast_start_time'])[8:12]
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxz =NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['schedule']['broadcast_end_time'])[8:12]
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxy={'channel':NvhOQfsGtWaUeATlKCRPpLIgXHBwky,'title':NvhOQfsGtWaUeATlKCRPpLIgXHBwxS,'mediacode':NvhOQfsGtWaUeATlKCRPpLIgXHBwxo,'thumbnail':{'poster':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr,'thumb':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc,'clearlogo':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE,'icon':NvhOQfsGtWaUeATlKCRPpLIgXHBwxd,'fanart':NvhOQfsGtWaUeATlKCRPpLIgXHBwxi},'synopsis':NvhOQfsGtWaUeATlKCRPpLIgXHBwxk,'channelepg':' [%s:%s ~ %s:%s]'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwxJ[0:2],NvhOQfsGtWaUeATlKCRPpLIgXHBwxJ[2:],NvhOQfsGtWaUeATlKCRPpLIgXHBwxz[0:2],NvhOQfsGtWaUeATlKCRPpLIgXHBwxz[2:]),'cast':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq,'director':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV,'info_genre':NvhOQfsGtWaUeATlKCRPpLIgXHBwxD,'year':NvhOQfsGtWaUeATlKCRPpLIgXHBwxY,'mpaa':NvhOQfsGtWaUeATlKCRPpLIgXHBwxn,'premiered':NvhOQfsGtWaUeATlKCRPpLIgXHBwxj}
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoF.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxy)
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['has_more']=='Y':
    NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
 def GetProgramList(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,genre,orderby,page_int,genreCode='all'):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoF=[]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  try:
   if genre=='PARAMOUNT':
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2/media/paramount/episodes'
   else:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2/media/episodes'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'cacheType':'main','pageSize':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(page_int),}
   if genre not in['all','PARAMOUNT']:NvhOQfsGtWaUeATlKCRPpLIgXHBwoz['categoryCode']=genre
   if genreCode!='all' :NvhOQfsGtWaUeATlKCRPpLIgXHBwoz['genreCode'] =genreCode 
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if not('result' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']):return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkz=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwkz:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwcJ=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['program']['code']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxS =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['program']['name']['ko']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxn =NvhOQfsGtWaUeATlKCRPpLIgXHBwJk.get(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['program'].get('grade_code'))
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxd =''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxb =''
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwxM in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['program']['image']:
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP0900':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP0200':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP1800':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP2000':NvhOQfsGtWaUeATlKCRPpLIgXHBwxd =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP1900':NvhOQfsGtWaUeATlKCRPpLIgXHBwxb =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxk =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['program']['synopsis']['ko']
    try:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwco=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['channel']['name']['ko']
    except:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwco=''
    try:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxq =[]
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxV=[]
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxD =[]
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxY =''
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxj=''
     for NvhOQfsGtWaUeATlKCRPpLIgXHBwxF in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('program').get('actor'):
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwxF!='' and NvhOQfsGtWaUeATlKCRPpLIgXHBwxF!='-' and NvhOQfsGtWaUeATlKCRPpLIgXHBwxF!=u'없음':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxF)
     for NvhOQfsGtWaUeATlKCRPpLIgXHBwxm in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('program').get('director'):
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwxm!='' and NvhOQfsGtWaUeATlKCRPpLIgXHBwxm!='-' and NvhOQfsGtWaUeATlKCRPpLIgXHBwxm!=u'없음':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxm)
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('program').get('category1_name').get('ko')!='':
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxD.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['program']['category1_name']['ko'])
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('program').get('category2_name').get('ko')!='':
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxD.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['program']['category2_name']['ko'])
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('program').get('product_year'):NvhOQfsGtWaUeATlKCRPpLIgXHBwxY=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['program']['product_year']
     if 'broad_dt' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('program'):
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxu =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('program').get('broad_dt')
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxj='%s-%s-%s'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[:4],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[4:6],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[6:])
    except:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwES
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxy={'program':NvhOQfsGtWaUeATlKCRPpLIgXHBwcJ,'title':NvhOQfsGtWaUeATlKCRPpLIgXHBwxS,'thumbnail':{'poster':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr,'thumb':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc,'clearlogo':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE,'icon':NvhOQfsGtWaUeATlKCRPpLIgXHBwxd,'banner':NvhOQfsGtWaUeATlKCRPpLIgXHBwxb,'fanart':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc},'synopsis':NvhOQfsGtWaUeATlKCRPpLIgXHBwxk,'channel':NvhOQfsGtWaUeATlKCRPpLIgXHBwco,'cast':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq,'director':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV,'info_genre':NvhOQfsGtWaUeATlKCRPpLIgXHBwxD,'year':NvhOQfsGtWaUeATlKCRPpLIgXHBwxY,'premiered':NvhOQfsGtWaUeATlKCRPpLIgXHBwxj,'mpaa':NvhOQfsGtWaUeATlKCRPpLIgXHBwxn}
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoF.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxy)
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['has_more']=='Y':NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
 def Get_UHD_ProgramList(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,page_int):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoF=[]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2/operator/highlights'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams(uhd=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(page_int),'pocType':'APP_X_TVING_4.0.0',}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if not('result' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']):return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkz=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwkz:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwcS=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['content']['program']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwck =NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['code']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxS =NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['name']['ko'].strip()
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxn =NvhOQfsGtWaUeATlKCRPpLIgXHBwJk.get(NvhOQfsGtWaUeATlKCRPpLIgXHBwcS.get('grade_code'))
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxk =NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['synopsis']['ko']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwco =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['content']['channel']['name']['ko']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxY =NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['product_year']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxd =''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxb =''
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwxM in NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['image']:
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP0900':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP0200':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP1800':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP2000':NvhOQfsGtWaUeATlKCRPpLIgXHBwxd =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP1900':NvhOQfsGtWaUeATlKCRPpLIgXHBwxb =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxD =[]
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxq =[]
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxV=[]
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxj =''
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwcS.get('category1_name').get('ko')!='':
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxD.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['category1_name']['ko'])
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwcS.get('category2_name').get('ko')!='':
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxD.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['category2_name']['ko'])
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwxF in NvhOQfsGtWaUeATlKCRPpLIgXHBwcS.get('actor'):
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwxF!='' and NvhOQfsGtWaUeATlKCRPpLIgXHBwxF!='-' and NvhOQfsGtWaUeATlKCRPpLIgXHBwxF!=u'없음':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxF)
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwxm in NvhOQfsGtWaUeATlKCRPpLIgXHBwcS.get('director'):
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwxm!='' and NvhOQfsGtWaUeATlKCRPpLIgXHBwxm!='-' and NvhOQfsGtWaUeATlKCRPpLIgXHBwxm!=u'없음':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxm)
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwcS.get('broad_dt')not in[NvhOQfsGtWaUeATlKCRPpLIgXHBwES,'']:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxu =NvhOQfsGtWaUeATlKCRPpLIgXHBwcS.get('broad_dt')
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxj='%s-%s-%s'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[:4],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[4:6],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[6:])
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxy={'program':NvhOQfsGtWaUeATlKCRPpLIgXHBwck,'title':NvhOQfsGtWaUeATlKCRPpLIgXHBwxS,'mpaa':NvhOQfsGtWaUeATlKCRPpLIgXHBwxn,'thumbnail':{'poster':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr,'thumb':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc,'clearlogo':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE,'icon':NvhOQfsGtWaUeATlKCRPpLIgXHBwxd,'banner':NvhOQfsGtWaUeATlKCRPpLIgXHBwxb,'fanart':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc},'channel':NvhOQfsGtWaUeATlKCRPpLIgXHBwco,'synopsis':NvhOQfsGtWaUeATlKCRPpLIgXHBwxk,'year':NvhOQfsGtWaUeATlKCRPpLIgXHBwxY,'info_genre':NvhOQfsGtWaUeATlKCRPpLIgXHBwxD,'cast':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq,'director':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV,'premiered':NvhOQfsGtWaUeATlKCRPpLIgXHBwxj,}
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoF.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxy)
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
 def Get_Origianl_ProgramList(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,page_int):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoF=[]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2/media/band/originals'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'pageSize':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(page_int),}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwcx=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.JsonFile_Save(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV_SESSION_COOKIES2,NvhOQfsGtWaUeATlKCRPpLIgXHBwcx)
   if not('contents' in NvhOQfsGtWaUeATlKCRPpLIgXHBwcx['body']):return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkz=NvhOQfsGtWaUeATlKCRPpLIgXHBwcx['body']['contents']
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwkz:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwcr =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['vod_code']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxS =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['vod_name']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['image']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwcE ='movie' if NvhOQfsGtWaUeATlKCRPpLIgXHBwcr.startswith('M')else 'vod'
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxy={'vod_code':NvhOQfsGtWaUeATlKCRPpLIgXHBwcr,'title':NvhOQfsGtWaUeATlKCRPpLIgXHBwxS,'thumbnail':{'poster':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr,'thumb':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr},'vod_type':NvhOQfsGtWaUeATlKCRPpLIgXHBwcE,}
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoF.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxy)
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwcx['body']['has_more']=='Y':NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
 def GetEpisodeList(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,program_code,page_int,orderby='desc'):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoF=[]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2/media/frequency/program/'+program_code
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if not('result' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']):return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkz=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']
   NvhOQfsGtWaUeATlKCRPpLIgXHBwcd=NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['total_count'])
   NvhOQfsGtWaUeATlKCRPpLIgXHBwcb =NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(NvhOQfsGtWaUeATlKCRPpLIgXHBwcd//(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    NvhOQfsGtWaUeATlKCRPpLIgXHBwci =(NvhOQfsGtWaUeATlKCRPpLIgXHBwcd-1)-((page_int-1)*NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.EPISODE_LIMIT)
   else:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwci =(page_int-1)*NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.EPISODE_LIMIT
   for i in NvhOQfsGtWaUeATlKCRPpLIgXHBwEb(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.EPISODE_LIMIT):
    if orderby=='desc':
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcM=NvhOQfsGtWaUeATlKCRPpLIgXHBwci-i
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwcM<0:break
    else:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcM=NvhOQfsGtWaUeATlKCRPpLIgXHBwci+i
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwcM>=NvhOQfsGtWaUeATlKCRPpLIgXHBwcd:break
    NvhOQfsGtWaUeATlKCRPpLIgXHBwcq=NvhOQfsGtWaUeATlKCRPpLIgXHBwkz[NvhOQfsGtWaUeATlKCRPpLIgXHBwcM]['episode']['code']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxS =NvhOQfsGtWaUeATlKCRPpLIgXHBwkz[NvhOQfsGtWaUeATlKCRPpLIgXHBwcM]['vod_name']['ko']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwcV =''
    try:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxu=NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwkz[NvhOQfsGtWaUeATlKCRPpLIgXHBwcM]['episode']['broadcast_date'])
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcV='%s-%s-%s'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[:4],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[4:6],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[6:])
    except:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwES
    try:
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwkz[NvhOQfsGtWaUeATlKCRPpLIgXHBwcM]['episode']['pip_cliptype']=='C012':
      NvhOQfsGtWaUeATlKCRPpLIgXHBwcV+=' - Quick VOD'
    except:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwES
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxk =NvhOQfsGtWaUeATlKCRPpLIgXHBwkz[NvhOQfsGtWaUeATlKCRPpLIgXHBwcM]['episode']['synopsis']['ko']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxd =''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxb =''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxi =''
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwxM in NvhOQfsGtWaUeATlKCRPpLIgXHBwkz[NvhOQfsGtWaUeATlKCRPpLIgXHBwcM]['program']['image']:
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP0900':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP1800':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP2000':NvhOQfsGtWaUeATlKCRPpLIgXHBwxd =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP1900':NvhOQfsGtWaUeATlKCRPpLIgXHBwxb =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIP0200':NvhOQfsGtWaUeATlKCRPpLIgXHBwxi =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwxM in NvhOQfsGtWaUeATlKCRPpLIgXHBwkz[NvhOQfsGtWaUeATlKCRPpLIgXHBwcM]['episode']['image']:
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIE0400':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
    try:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcD=NvhOQfsGtWaUeATlKCRPpLIgXHBwcn=NvhOQfsGtWaUeATlKCRPpLIgXHBwcj=''
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcY=0
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcD =NvhOQfsGtWaUeATlKCRPpLIgXHBwkz[NvhOQfsGtWaUeATlKCRPpLIgXHBwcM]['program']['name']['ko']
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcn =NvhOQfsGtWaUeATlKCRPpLIgXHBwcV
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcj =NvhOQfsGtWaUeATlKCRPpLIgXHBwkz[NvhOQfsGtWaUeATlKCRPpLIgXHBwcM]['channel']['name']['ko']
     if 'frequency' in NvhOQfsGtWaUeATlKCRPpLIgXHBwkz[NvhOQfsGtWaUeATlKCRPpLIgXHBwcM]['episode']:NvhOQfsGtWaUeATlKCRPpLIgXHBwcY=NvhOQfsGtWaUeATlKCRPpLIgXHBwkz[NvhOQfsGtWaUeATlKCRPpLIgXHBwcM]['episode']['frequency']
    except:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwES
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxy={'episode':NvhOQfsGtWaUeATlKCRPpLIgXHBwcq,'title':NvhOQfsGtWaUeATlKCRPpLIgXHBwxS,'subtitle':NvhOQfsGtWaUeATlKCRPpLIgXHBwcV,'thumbnail':{'poster':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr,'thumb':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc,'clearlogo':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE,'icon':NvhOQfsGtWaUeATlKCRPpLIgXHBwxd,'banner':NvhOQfsGtWaUeATlKCRPpLIgXHBwxb,'fanart':NvhOQfsGtWaUeATlKCRPpLIgXHBwxi},'synopsis':NvhOQfsGtWaUeATlKCRPpLIgXHBwxk,'info_title':NvhOQfsGtWaUeATlKCRPpLIgXHBwcD,'aired':NvhOQfsGtWaUeATlKCRPpLIgXHBwcn,'studio':NvhOQfsGtWaUeATlKCRPpLIgXHBwcj,'frequency':NvhOQfsGtWaUeATlKCRPpLIgXHBwcY}
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoF.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxy)
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwcb>page_int:NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm,NvhOQfsGtWaUeATlKCRPpLIgXHBwcb
 def GetMovieList(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,genre,orderby,page_int):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoF=[]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  try:
   if genre=='PARAMOUNT':
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2/media/paramount/movies'
   else:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2/media/movies'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'pageSize':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:NvhOQfsGtWaUeATlKCRPpLIgXHBwoz['categoryCode']=genre
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz['productPackageCode']=','.join(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.MOVIE_LITE)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if not('result' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']):return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkz=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwkz:
    if 'release_date' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('movie'):
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxY=NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('movie').get('release_date'))[:4]
    else:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxY=NvhOQfsGtWaUeATlKCRPpLIgXHBwES
    NvhOQfsGtWaUeATlKCRPpLIgXHBwcF =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['movie']['code']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxS =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['movie']['name']['ko'].strip()
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwxY not in[NvhOQfsGtWaUeATlKCRPpLIgXHBwES,'0','']:NvhOQfsGtWaUeATlKCRPpLIgXHBwxS+=u' (%s)'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwxY)
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxr=''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=''
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwxM in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['movie']['image']:
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIM2100':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIM0400':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIM1800':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxk =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['movie']['story']['ko']
    try:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcD =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['movie']['name']['ko'].strip()
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxn =NvhOQfsGtWaUeATlKCRPpLIgXHBwJk.get(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('grade_code'))
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxq=[]
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxV=[]
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxD=[]
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcm=0
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxj=''
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcj =''
     for NvhOQfsGtWaUeATlKCRPpLIgXHBwxF in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('movie').get('actor'):
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwxF!='':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxF)
     for NvhOQfsGtWaUeATlKCRPpLIgXHBwxm in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('movie').get('director'):
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwxm!='':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxm)
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('movie').get('category1_name').get('ko')!='':
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxD.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['movie']['category1_name']['ko'])
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('movie').get('category2_name').get('ko')!='':
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxD.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['movie']['category2_name']['ko'])
     if 'duration' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('movie'):NvhOQfsGtWaUeATlKCRPpLIgXHBwcm=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('movie').get('duration')
     if 'release_date' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('movie'):
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxu=NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('movie').get('release_date'))
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwxu!='0':NvhOQfsGtWaUeATlKCRPpLIgXHBwxj='%s-%s-%s'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[:4],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[4:6],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[6:])
     if 'production' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('movie'):NvhOQfsGtWaUeATlKCRPpLIgXHBwcj=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('movie').get('production')
    except:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwES
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxy={'moviecode':NvhOQfsGtWaUeATlKCRPpLIgXHBwcF,'title':NvhOQfsGtWaUeATlKCRPpLIgXHBwxS,'thumbnail':{'poster':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr,'thumb':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc,'clearlogo':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE,'fanart':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc},'synopsis':NvhOQfsGtWaUeATlKCRPpLIgXHBwxk,'info_title':NvhOQfsGtWaUeATlKCRPpLIgXHBwcD,'year':NvhOQfsGtWaUeATlKCRPpLIgXHBwxY,'cast':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq,'director':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV,'info_genre':NvhOQfsGtWaUeATlKCRPpLIgXHBwxD,'duration':NvhOQfsGtWaUeATlKCRPpLIgXHBwcm,'premiered':NvhOQfsGtWaUeATlKCRPpLIgXHBwxj,'studio':NvhOQfsGtWaUeATlKCRPpLIgXHBwcj,'mpaa':NvhOQfsGtWaUeATlKCRPpLIgXHBwxn}
    NvhOQfsGtWaUeATlKCRPpLIgXHBwcu=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwcz in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['billing_package_id']:
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwcz in NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.MOVIE_LITE:
      NvhOQfsGtWaUeATlKCRPpLIgXHBwcu=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
      break
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwcu==NvhOQfsGtWaUeATlKCRPpLIgXHBwEk: 
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxy['title']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxy['title']+' [개별구매]'
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoF.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxy)
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['has_more']=='Y':NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
 def Get_UHD_MovieList(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,page_int):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoF=[]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2/operator/highlights'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams(uhd=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(page_int),'pocType':'APP_X_TVING_4.0.0',}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if not('result' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']):return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkz=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwkz:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwcS=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['content']['movie']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwck =NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['code']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxS =NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['name']['ko'].strip()
    NvhOQfsGtWaUeATlKCRPpLIgXHBwcD =NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['name']['ko'].strip()
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxY =NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['product_year']
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwxY:NvhOQfsGtWaUeATlKCRPpLIgXHBwxS+=u' (%s)'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['product_year'])
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxk =NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['story']['ko']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwcm =NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['duration']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxn =NvhOQfsGtWaUeATlKCRPpLIgXHBwJk.get(NvhOQfsGtWaUeATlKCRPpLIgXHBwcS.get('grade_code'))
    NvhOQfsGtWaUeATlKCRPpLIgXHBwcj =NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['production']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxr=''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=''
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxD =[]
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxq =[]
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxV=[]
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxj =''
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwxM in NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['image']:
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIM2100':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIM0400':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
     elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['code']=='CAIM1800':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM['url']
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['release_date']not in[NvhOQfsGtWaUeATlKCRPpLIgXHBwES,0]:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxu=NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['release_date'])
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwxu!='0':NvhOQfsGtWaUeATlKCRPpLIgXHBwxj='%s-%s-%s'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[:4],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[4:6],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[6:])
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwcS.get('category1_name').get('ko')!='':
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxD.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['category1_name']['ko'])
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwcS.get('category2_name').get('ko')!='':
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxD.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwcS['category2_name']['ko'])
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwxF in NvhOQfsGtWaUeATlKCRPpLIgXHBwcS.get('actor'):
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwxF!='':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxF)
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwxm in NvhOQfsGtWaUeATlKCRPpLIgXHBwcS.get('director'):
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwxm!='':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxm)
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxy={'moviecode':NvhOQfsGtWaUeATlKCRPpLIgXHBwck,'title':NvhOQfsGtWaUeATlKCRPpLIgXHBwxS,'thumbnail':{'poster':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr,'thumb':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc,'clearlogo':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE,'fanart':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc},'year':NvhOQfsGtWaUeATlKCRPpLIgXHBwxY,'info_title':NvhOQfsGtWaUeATlKCRPpLIgXHBwcD,'synopsis':NvhOQfsGtWaUeATlKCRPpLIgXHBwxk,'mpaa':NvhOQfsGtWaUeATlKCRPpLIgXHBwxn,'duration':NvhOQfsGtWaUeATlKCRPpLIgXHBwcm,'premiered':NvhOQfsGtWaUeATlKCRPpLIgXHBwxj,'studio':NvhOQfsGtWaUeATlKCRPpLIgXHBwcj,'info_genre':NvhOQfsGtWaUeATlKCRPpLIgXHBwxD,'cast':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq,'director':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV,}
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoF.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxy)
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
 def GetMovieGenre(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoF=[]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2/media/movie/curations'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if not('result' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']):return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkz=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwkz:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwcy =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['curation_code']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwrJ =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['curation_name']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwxy={'curation_code':NvhOQfsGtWaUeATlKCRPpLIgXHBwcy,'curation_name':NvhOQfsGtWaUeATlKCRPpLIgXHBwrJ}
    NvhOQfsGtWaUeATlKCRPpLIgXHBwoF.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxy)
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
 def GetSearchList(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,search_key,page_int,stype):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwro=[]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/search/getSearch.jsp'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.SCREENCODE,'os':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.OSCODE,'network':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.APIKEY,'networkCode':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.NETWORKCODE,'osCode ':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.OSCODE,'teleCode ':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TELECODE,'screenCode ':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.SCREENCODE}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.SEARCH_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwoz,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if stype=='vod':
    if not('programRsb' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy):return NvhOQfsGtWaUeATlKCRPpLIgXHBwro,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
    NvhOQfsGtWaUeATlKCRPpLIgXHBwrS=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['programRsb']['dataList']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwrk =NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['programRsb']['count'])
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwrS:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcJ=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['mast_cd']
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxS =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['mast_nm']
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxr=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['web_url4']
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['web_url']
     try:
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxq =[]
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxV=[]
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxD =[]
      NvhOQfsGtWaUeATlKCRPpLIgXHBwcm =0
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxn =''
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxY =''
      NvhOQfsGtWaUeATlKCRPpLIgXHBwcn =''
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('actor') !='' and NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('actor') !='-':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('actor').split(',')
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('director')!='' and NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('director')!='-':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('director').split(',')
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('cate_nm')!='' and NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('cate_nm')!='-':NvhOQfsGtWaUeATlKCRPpLIgXHBwxD =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('cate_nm').split('/')
      if 'targetage' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ:NvhOQfsGtWaUeATlKCRPpLIgXHBwxn=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('targetage')
      if 'broad_dt' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ:
       NvhOQfsGtWaUeATlKCRPpLIgXHBwxu=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('broad_dt')
       NvhOQfsGtWaUeATlKCRPpLIgXHBwcn='%s-%s-%s'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[:4],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[4:6],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[6:])
       NvhOQfsGtWaUeATlKCRPpLIgXHBwxY =NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[:4]
     except:
      NvhOQfsGtWaUeATlKCRPpLIgXHBwES
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxy={'program':NvhOQfsGtWaUeATlKCRPpLIgXHBwcJ,'title':NvhOQfsGtWaUeATlKCRPpLIgXHBwxS,'thumbnail':{'poster':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr,'thumb':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc,'fanart':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc},'synopsis':'','cast':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq,'director':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV,'info_genre':NvhOQfsGtWaUeATlKCRPpLIgXHBwxD,'duration':NvhOQfsGtWaUeATlKCRPpLIgXHBwcm,'mpaa':NvhOQfsGtWaUeATlKCRPpLIgXHBwxn,'year':NvhOQfsGtWaUeATlKCRPpLIgXHBwxY,'aired':NvhOQfsGtWaUeATlKCRPpLIgXHBwcn}
     NvhOQfsGtWaUeATlKCRPpLIgXHBwro.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxy)
   else:
    if not('vodMVRsb' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy):return NvhOQfsGtWaUeATlKCRPpLIgXHBwro,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
    NvhOQfsGtWaUeATlKCRPpLIgXHBwrx=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['vodMVRsb']['dataList']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwrk =NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['vodMVRsb']['count'])
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwrx:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcJ=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['mast_cd']
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxS =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['mast_nm'].strip()
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['web_url']
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwxr
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=''
     try:
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxq =[]
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxV=[]
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxD =[]
      NvhOQfsGtWaUeATlKCRPpLIgXHBwcm =0
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxn =''
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxY =''
      NvhOQfsGtWaUeATlKCRPpLIgXHBwcn =''
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('actor') !='' and NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('actor') !='-':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('actor').split(',')
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('director')!='' and NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('director')!='-':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('director').split(',')
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('cate_nm')!='' and NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('cate_nm')!='-':NvhOQfsGtWaUeATlKCRPpLIgXHBwxD =NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('cate_nm').split('/')
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('runtime_sec')!='':NvhOQfsGtWaUeATlKCRPpLIgXHBwcm=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('runtime_sec')
      if 'grade_nm' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ:NvhOQfsGtWaUeATlKCRPpLIgXHBwxn=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('grade_nm')
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxu=NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('broad_dt')
      if data_str!='':
       NvhOQfsGtWaUeATlKCRPpLIgXHBwcn='%s-%s-%s'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[:4],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[4:6],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[6:])
       NvhOQfsGtWaUeATlKCRPpLIgXHBwxY =NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[:4]
     except:
      NvhOQfsGtWaUeATlKCRPpLIgXHBwES
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxy={'movie':NvhOQfsGtWaUeATlKCRPpLIgXHBwcJ,'title':NvhOQfsGtWaUeATlKCRPpLIgXHBwxS,'thumbnail':{'poster':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr,'thumb':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc,'fanart':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc,'clearlogo':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE},'synopsis':'','cast':NvhOQfsGtWaUeATlKCRPpLIgXHBwxq,'director':NvhOQfsGtWaUeATlKCRPpLIgXHBwxV,'info_genre':NvhOQfsGtWaUeATlKCRPpLIgXHBwxD,'duration':NvhOQfsGtWaUeATlKCRPpLIgXHBwcm,'mpaa':NvhOQfsGtWaUeATlKCRPpLIgXHBwxn,'year':NvhOQfsGtWaUeATlKCRPpLIgXHBwxY,'aired':NvhOQfsGtWaUeATlKCRPpLIgXHBwcn}
     NvhOQfsGtWaUeATlKCRPpLIgXHBwcu=NvhOQfsGtWaUeATlKCRPpLIgXHBwEk
     for NvhOQfsGtWaUeATlKCRPpLIgXHBwcz in NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['bill']:
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwcz in NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.MOVIE_LITE:
       NvhOQfsGtWaUeATlKCRPpLIgXHBwcu=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
       break
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwcu==NvhOQfsGtWaUeATlKCRPpLIgXHBwEk: 
      NvhOQfsGtWaUeATlKCRPpLIgXHBwxy['title']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxy['title']+' [개별구매]'
     NvhOQfsGtWaUeATlKCRPpLIgXHBwro.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxy)
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwrk>(page_int*NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.SEARCH_LIMIT):NvhOQfsGtWaUeATlKCRPpLIgXHBwkm=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwro,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
 def GetBookmarkInfo(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,videoid,vidtype):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwrc={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+'/v2/media/program/'+videoid
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'pageNo':'1','pageSize':'10','order':'name',}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwcx=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if not('body' in NvhOQfsGtWaUeATlKCRPpLIgXHBwcx):return{}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrE=NvhOQfsGtWaUeATlKCRPpLIgXHBwcx['body']
   NvhOQfsGtWaUeATlKCRPpLIgXHBwxS=NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('name').get('ko').strip()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['title'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwxS
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['title']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxS
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['mpaa'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwJk.get(NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('grade_code'))
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['plot'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('synopsis').get('ko')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['year'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('product_year')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['cast'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('actor')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['director']=NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('director')
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('category1_name').get('ko')!='':
    NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['genre'].append(NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('category1_name').get('ko'))
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('category2_name').get('ko')!='':
    NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['genre'].append(NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('category2_name').get('ko'))
   NvhOQfsGtWaUeATlKCRPpLIgXHBwxu=NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('broad_dt'))
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwxu!='0':NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[:4],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[4:6],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[6:])
   NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =''
   NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =''
   NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=''
   NvhOQfsGtWaUeATlKCRPpLIgXHBwxd =''
   NvhOQfsGtWaUeATlKCRPpLIgXHBwxb =''
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwxM in NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('image'):
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('code')=='CAIP0900':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('url')
    elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('code')=='CAIP0200':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('url')
    elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('code')=='CAIP1800':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('url')
    elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('code')=='CAIP2000':NvhOQfsGtWaUeATlKCRPpLIgXHBwxd =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('url')
    elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('code')=='CAIP1900':NvhOQfsGtWaUeATlKCRPpLIgXHBwxb =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('url')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['thumbnail']['poster']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxr
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['thumbnail']['thumb']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxc
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['thumbnail']['clearlogo']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxE
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['thumbnail']['icon']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxd
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['thumbnail']['banner']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxb
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['thumbnail']['fanart']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxc
  else:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+'/v2a/media/stream/info'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_uuid'].split('-')[0],'uuid':NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetNoCache(1)),'wm':'Y',}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwcx=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if not('content' in NvhOQfsGtWaUeATlKCRPpLIgXHBwcx['body']):return{}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrE=NvhOQfsGtWaUeATlKCRPpLIgXHBwcx['body']['content']['info']['movie']
   NvhOQfsGtWaUeATlKCRPpLIgXHBwxS =NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('name').get('ko').strip()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['title']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxS
   NvhOQfsGtWaUeATlKCRPpLIgXHBwxS +=u' (%s)'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('product_year'))
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['title'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwxS
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['mpaa'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwJk.get(NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('grade_code'))
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['plot'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('story').get('ko')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['year'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('product_year')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['studio'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('production')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['duration']=NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('duration')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['cast'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('actor')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['director']=NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('director')
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('category1_name').get('ko')!='':
    NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['genre'].append(NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('category1_name').get('ko'))
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('category2_name').get('ko')!='':
    NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['genre'].append(NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('category2_name').get('ko'))
   NvhOQfsGtWaUeATlKCRPpLIgXHBwxu=NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('release_date'))
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwxu!='0':NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[:4],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[4:6],NvhOQfsGtWaUeATlKCRPpLIgXHBwxu[6:])
   NvhOQfsGtWaUeATlKCRPpLIgXHBwxr=''
   NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =''
   NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=''
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwxM in NvhOQfsGtWaUeATlKCRPpLIgXHBwrE.get('image'):
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('code')=='CAIM2100':NvhOQfsGtWaUeATlKCRPpLIgXHBwxr =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('url')
    elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('code')=='CAIM0400':NvhOQfsGtWaUeATlKCRPpLIgXHBwxc =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('url')
    elif NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('code')=='CAIM1800':NvhOQfsGtWaUeATlKCRPpLIgXHBwxE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.IMG_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwxM.get('url')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['thumbnail']['poster']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxr
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['thumbnail']['thumb']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxr 
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['thumbnail']['clearlogo']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxE
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrc['saveinfo']['thumbnail']['fanart']=NvhOQfsGtWaUeATlKCRPpLIgXHBwxc
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwrc
 def GetEuroChannelList(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwoF=[]
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2/operator/highlights'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetNoCache(2))}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwES)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if not('result' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']):return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF,NvhOQfsGtWaUeATlKCRPpLIgXHBwkm
   NvhOQfsGtWaUeATlKCRPpLIgXHBwkz=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrd =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Get_Now_Datetime()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrb=NvhOQfsGtWaUeATlKCRPpLIgXHBwrd+datetime.timedelta(days=-1)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrb=NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(NvhOQfsGtWaUeATlKCRPpLIgXHBwrb.strftime('%Y%m%d'))
   for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwkz:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwri=NvhOQfsGtWaUeATlKCRPpLIgXHBwEd(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('content').get('banner_title2')[:8])
    if NvhOQfsGtWaUeATlKCRPpLIgXHBwrb<=NvhOQfsGtWaUeATlKCRPpLIgXHBwri:
     NvhOQfsGtWaUeATlKCRPpLIgXHBwxy={'channel':NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('content').get('banner_sub_title3'),'title':NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('content').get('banner_title'),'subtitle':NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ.get('content').get('banner_sub_title2'),}
     NvhOQfsGtWaUeATlKCRPpLIgXHBwoF.append(NvhOQfsGtWaUeATlKCRPpLIgXHBwxy)
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwoF
 def Make_DecryptKey(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,step,mediacode='000',timecode='000'):
  if step=='1':
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrM=NvhOQfsGtWaUeATlKCRPpLIgXHBwED('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrq=NvhOQfsGtWaUeATlKCRPpLIgXHBwED('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrM=NvhOQfsGtWaUeATlKCRPpLIgXHBwED('kss2lym0kdw1lks3','utf-8')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrq=NvhOQfsGtWaUeATlKCRPpLIgXHBwED([NvhOQfsGtWaUeATlKCRPpLIgXHBwEY('*'),0x07,NvhOQfsGtWaUeATlKCRPpLIgXHBwEY('r'),NvhOQfsGtWaUeATlKCRPpLIgXHBwEY(';'),NvhOQfsGtWaUeATlKCRPpLIgXHBwEY('7'),0x05,0x1e,0x01,NvhOQfsGtWaUeATlKCRPpLIgXHBwEY('n'),NvhOQfsGtWaUeATlKCRPpLIgXHBwEY('D'),0x02,NvhOQfsGtWaUeATlKCRPpLIgXHBwEY('3'),NvhOQfsGtWaUeATlKCRPpLIgXHBwEY('*'),NvhOQfsGtWaUeATlKCRPpLIgXHBwEY('a'),NvhOQfsGtWaUeATlKCRPpLIgXHBwEY('&'),NvhOQfsGtWaUeATlKCRPpLIgXHBwEY('<')])
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwrM,NvhOQfsGtWaUeATlKCRPpLIgXHBwrq
 def DecryptPlaintext(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,ciphertext,encryption_key,init_vector):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwrV=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  NvhOQfsGtWaUeATlKCRPpLIgXHBwrD=Padding.unpad(NvhOQfsGtWaUeATlKCRPpLIgXHBwrV.decrypt(base64.standard_b64decode(ciphertext)),16)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwrD.decode('utf-8')
 def Decrypt_Url(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,ciphertext,mediacode,NvhOQfsGtWaUeATlKCRPpLIgXHBwSV):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwrY=''
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSD=''
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSY=''
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrM,NvhOQfsGtWaUeATlKCRPpLIgXHBwrq=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Make_DecryptKey('1',mediacode=mediacode,timecode=NvhOQfsGtWaUeATlKCRPpLIgXHBwSV)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrn=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.DecryptPlaintext(ciphertext,NvhOQfsGtWaUeATlKCRPpLIgXHBwrM,NvhOQfsGtWaUeATlKCRPpLIgXHBwrq))
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrj =NvhOQfsGtWaUeATlKCRPpLIgXHBwrn.get('broad_url')
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSD =NvhOQfsGtWaUeATlKCRPpLIgXHBwrn.get('watermark') if 'watermark' in NvhOQfsGtWaUeATlKCRPpLIgXHBwrn else ''
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSY=NvhOQfsGtWaUeATlKCRPpLIgXHBwrn.get('watermarkKey')if 'watermarkKey' in NvhOQfsGtWaUeATlKCRPpLIgXHBwrn else ''
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrM,NvhOQfsGtWaUeATlKCRPpLIgXHBwrq=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Make_DecryptKey('2',mediacode=mediacode,timecode=NvhOQfsGtWaUeATlKCRPpLIgXHBwSV)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrY=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.DecryptPlaintext(NvhOQfsGtWaUeATlKCRPpLIgXHBwrj,NvhOQfsGtWaUeATlKCRPpLIgXHBwrM,NvhOQfsGtWaUeATlKCRPpLIgXHBwrq)
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwrY,NvhOQfsGtWaUeATlKCRPpLIgXHBwSD,NvhOQfsGtWaUeATlKCRPpLIgXHBwSY
 def GetLiveURL_Test(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr,mediacode,sel_quality):
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSk ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','error_msg':'',}
  NvhOQfsGtWaUeATlKCRPpLIgXHBwom =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_uuid'].split('-')[0] 
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSx =NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.TV['cookies']['tving_uuid'] 
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSr=NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetNoCache(1))
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2/media/stream/info' 
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':NvhOQfsGtWaUeATlKCRPpLIgXHBwSx,'deviceInfo':'PC','noCache':NvhOQfsGtWaUeATlKCRPpLIgXHBwSr,}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJy=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.makeDefaultCookies()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwJy)
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.status_code!=200:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['error_msg']='First Step - {} error'.format(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.status_code)
    return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']['code']=='060':
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwJF,NvhOQfsGtWaUeATlKCRPpLIgXHBwJm in NvhOQfsGtWaUeATlKCRPpLIgXHBwJS.items():
     if NvhOQfsGtWaUeATlKCRPpLIgXHBwJm==sel_quality:
      NvhOQfsGtWaUeATlKCRPpLIgXHBwSb=NvhOQfsGtWaUeATlKCRPpLIgXHBwJF
   elif NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']['code']!='000':
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['error_msg']=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']['message']
    return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
   else: 
    if not('stream' in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']):return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSi=[]
    for NvhOQfsGtWaUeATlKCRPpLIgXHBwJF,NvhOQfsGtWaUeATlKCRPpLIgXHBwJm in NvhOQfsGtWaUeATlKCRPpLIgXHBwJS.items():
     for NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ in NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['stream']['quality']:
      if NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['active']=='Y' and NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['code']==NvhOQfsGtWaUeATlKCRPpLIgXHBwJF:
       NvhOQfsGtWaUeATlKCRPpLIgXHBwSi.append({NvhOQfsGtWaUeATlKCRPpLIgXHBwJS.get(NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['code']):NvhOQfsGtWaUeATlKCRPpLIgXHBwSJ['code']})
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSb=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.CheckQuality(sel_quality,NvhOQfsGtWaUeATlKCRPpLIgXHBwSi)
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['error_msg']='First Step - except error'
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
  try:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSr=NvhOQfsGtWaUeATlKCRPpLIgXHBwEM(NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetNoCache(1))
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoY ='/v2a/media/stream/info'
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.GetDefaultParams()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoz={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':NvhOQfsGtWaUeATlKCRPpLIgXHBwSb,'deviceId':NvhOQfsGtWaUeATlKCRPpLIgXHBwom,'uuid':NvhOQfsGtWaUeATlKCRPpLIgXHBwSx,'deviceInfo':'PC_Chrome','noCache':NvhOQfsGtWaUeATlKCRPpLIgXHBwSr,'wm':'Y'}
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSE.update(NvhOQfsGtWaUeATlKCRPpLIgXHBwoz)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSd=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.API_DOMAIN+NvhOQfsGtWaUeATlKCRPpLIgXHBwoY
   NvhOQfsGtWaUeATlKCRPpLIgXHBwJy=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.makeDefaultCookies()
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoM=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.callRequestCookies('Get',NvhOQfsGtWaUeATlKCRPpLIgXHBwSd,payload=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,params=NvhOQfsGtWaUeATlKCRPpLIgXHBwSE,headers=NvhOQfsGtWaUeATlKCRPpLIgXHBwES,cookies=NvhOQfsGtWaUeATlKCRPpLIgXHBwJy,redirects=NvhOQfsGtWaUeATlKCRPpLIgXHBwEc)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwoy=json.loads(NvhOQfsGtWaUeATlKCRPpLIgXHBwoM.text)
   if NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']['code']!='000':
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['error_msg']=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['result']['message']
    return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSM=NvhOQfsGtWaUeATlKCRPpLIgXHBwoy['body']['stream']
   if 'drm_license_assertion' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSM:
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['drm_license']=NvhOQfsGtWaUeATlKCRPpLIgXHBwSM['drm_license_assertion']
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSq =NvhOQfsGtWaUeATlKCRPpLIgXHBwSM['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in NvhOQfsGtWaUeATlKCRPpLIgXHBwSM['broadcast']):return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
    NvhOQfsGtWaUeATlKCRPpLIgXHBwSq=NvhOQfsGtWaUeATlKCRPpLIgXHBwSM['broadcast']['broad_url']
  except NvhOQfsGtWaUeATlKCRPpLIgXHBwEi as exception:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwry(exception)
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['error_msg']='Second Step - except error'
   return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSV=NvhOQfsGtWaUeATlKCRPpLIgXHBwSr
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSq=NvhOQfsGtWaUeATlKCRPpLIgXHBwSq.split('|')[1]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSq,NvhOQfsGtWaUeATlKCRPpLIgXHBwSD,NvhOQfsGtWaUeATlKCRPpLIgXHBwSY=NvhOQfsGtWaUeATlKCRPpLIgXHBwJr.Decrypt_Url(NvhOQfsGtWaUeATlKCRPpLIgXHBwSq,mediacode,NvhOQfsGtWaUeATlKCRPpLIgXHBwSV)
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['streaming_url']=NvhOQfsGtWaUeATlKCRPpLIgXHBwSq
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['watermark'] =NvhOQfsGtWaUeATlKCRPpLIgXHBwSD
  NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['watermarkKey']=NvhOQfsGtWaUeATlKCRPpLIgXHBwSY
  NvhOQfsGtWaUeATlKCRPpLIgXHBwrF =NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['streaming_url'].find('Policy=')
  if NvhOQfsGtWaUeATlKCRPpLIgXHBwrF!=-1:
   NvhOQfsGtWaUeATlKCRPpLIgXHBwrm =NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['streaming_url'].split('?')[0]
   NvhOQfsGtWaUeATlKCRPpLIgXHBwru=NvhOQfsGtWaUeATlKCRPpLIgXHBwEq(urllib.parse.parse_qsl(urllib.parse.urlsplit(NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['streaming_url']).query))
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['streaming_url']='{}&CloudFront-Policy={}'.format(NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['streaming_url'],NvhOQfsGtWaUeATlKCRPpLIgXHBwru['Policy'])
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['streaming_url']='{}&CloudFront-Signature={}'.format(NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['streaming_url'],NvhOQfsGtWaUeATlKCRPpLIgXHBwru['Signature'])
   NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['streaming_url']='{}&CloudFront-Key-Pair-Id={}'.format(NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['streaming_url'],NvhOQfsGtWaUeATlKCRPpLIgXHBwru['Key-Pair-Id'])
  NvhOQfsGtWaUeATlKCRPpLIgXHBwrz=['_tving_token','accessToken','authToken',]
  NvhOQfsGtWaUeATlKCRPpLIgXHBwry(NvhOQfsGtWaUeATlKCRPpLIgXHBwSk['streaming_url'])
  return NvhOQfsGtWaUeATlKCRPpLIgXHBwSk
# Created by pyminifier (https://github.com/liftoff/pyminifier)
