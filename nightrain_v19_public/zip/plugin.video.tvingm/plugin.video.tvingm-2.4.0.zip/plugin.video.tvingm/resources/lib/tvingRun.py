__author__="NightRain"
bvswWedxIVFLUDGpoEghmlJnXKCyaj=object
bvswWedxIVFLUDGpoEghmlJnXKCyaA=None
bvswWedxIVFLUDGpoEghmlJnXKCyaR=int
bvswWedxIVFLUDGpoEghmlJnXKCyaM=True
bvswWedxIVFLUDGpoEghmlJnXKCyaS=False
bvswWedxIVFLUDGpoEghmlJnXKCyaB=type
bvswWedxIVFLUDGpoEghmlJnXKCyaz=dict
bvswWedxIVFLUDGpoEghmlJnXKCyaN=len
bvswWedxIVFLUDGpoEghmlJnXKCyaP=str
bvswWedxIVFLUDGpoEghmlJnXKCyaH=range
bvswWedxIVFLUDGpoEghmlJnXKCyac=open
bvswWedxIVFLUDGpoEghmlJnXKCyak=Exception
bvswWedxIVFLUDGpoEghmlJnXKCyat=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
bvswWedxIVFLUDGpoEghmlJnXKCyQT=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
bvswWedxIVFLUDGpoEghmlJnXKCyQf=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
bvswWedxIVFLUDGpoEghmlJnXKCyQY=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
bvswWedxIVFLUDGpoEghmlJnXKCyQj=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
bvswWedxIVFLUDGpoEghmlJnXKCyQA=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
bvswWedxIVFLUDGpoEghmlJnXKCyQa=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
bvswWedxIVFLUDGpoEghmlJnXKCyQR=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
bvswWedxIVFLUDGpoEghmlJnXKCyQM =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
bvswWedxIVFLUDGpoEghmlJnXKCyQS=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class bvswWedxIVFLUDGpoEghmlJnXKCyQO(bvswWedxIVFLUDGpoEghmlJnXKCyaj):
 def __init__(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyQz,bvswWedxIVFLUDGpoEghmlJnXKCyQN,bvswWedxIVFLUDGpoEghmlJnXKCyQP):
  bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_url =bvswWedxIVFLUDGpoEghmlJnXKCyQz
  bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle=bvswWedxIVFLUDGpoEghmlJnXKCyQN
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params =bvswWedxIVFLUDGpoEghmlJnXKCyQP
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj =nbTvDjESpRtQJCGUkuircyoedzqgFW() 
 def addon_noti(bvswWedxIVFLUDGpoEghmlJnXKCyQB,sting):
  try:
   bvswWedxIVFLUDGpoEghmlJnXKCyQc=xbmcgui.Dialog()
   bvswWedxIVFLUDGpoEghmlJnXKCyQc.notification(__addonname__,sting)
  except:
   bvswWedxIVFLUDGpoEghmlJnXKCyaA
 def addon_log(bvswWedxIVFLUDGpoEghmlJnXKCyQB,string):
  try:
   bvswWedxIVFLUDGpoEghmlJnXKCyQk=string.encode('utf-8','ignore')
  except:
   bvswWedxIVFLUDGpoEghmlJnXKCyQk='addonException: addon_log'
  bvswWedxIVFLUDGpoEghmlJnXKCyQt=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,bvswWedxIVFLUDGpoEghmlJnXKCyQk),level=bvswWedxIVFLUDGpoEghmlJnXKCyQt)
 def get_keyboard_input(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyOB):
  bvswWedxIVFLUDGpoEghmlJnXKCyQq=bvswWedxIVFLUDGpoEghmlJnXKCyaA
  kb=xbmc.Keyboard()
  kb.setHeading(bvswWedxIVFLUDGpoEghmlJnXKCyOB)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   bvswWedxIVFLUDGpoEghmlJnXKCyQq=kb.getText()
  return bvswWedxIVFLUDGpoEghmlJnXKCyQq
 def get_settings_login_info(bvswWedxIVFLUDGpoEghmlJnXKCyQB):
  bvswWedxIVFLUDGpoEghmlJnXKCyQr =__addon__.getSetting('id')
  bvswWedxIVFLUDGpoEghmlJnXKCyQu =__addon__.getSetting('pw')
  bvswWedxIVFLUDGpoEghmlJnXKCyQi =__addon__.getSetting('login_type')
  bvswWedxIVFLUDGpoEghmlJnXKCyOQ=bvswWedxIVFLUDGpoEghmlJnXKCyaR(__addon__.getSetting('selected_profile'))
  return(bvswWedxIVFLUDGpoEghmlJnXKCyQr,bvswWedxIVFLUDGpoEghmlJnXKCyQu,bvswWedxIVFLUDGpoEghmlJnXKCyQi,bvswWedxIVFLUDGpoEghmlJnXKCyOQ)
 def get_settings_totalsearch(bvswWedxIVFLUDGpoEghmlJnXKCyQB):
  bvswWedxIVFLUDGpoEghmlJnXKCyOT =bvswWedxIVFLUDGpoEghmlJnXKCyaM if __addon__.getSetting('local_search')=='true' else bvswWedxIVFLUDGpoEghmlJnXKCyaS
  bvswWedxIVFLUDGpoEghmlJnXKCyOf=bvswWedxIVFLUDGpoEghmlJnXKCyaM if __addon__.getSetting('local_history')=='true' else bvswWedxIVFLUDGpoEghmlJnXKCyaS
  bvswWedxIVFLUDGpoEghmlJnXKCyOY =bvswWedxIVFLUDGpoEghmlJnXKCyaM if __addon__.getSetting('total_search')=='true' else bvswWedxIVFLUDGpoEghmlJnXKCyaS
  bvswWedxIVFLUDGpoEghmlJnXKCyOj=bvswWedxIVFLUDGpoEghmlJnXKCyaM if __addon__.getSetting('total_history')=='true' else bvswWedxIVFLUDGpoEghmlJnXKCyaS
  bvswWedxIVFLUDGpoEghmlJnXKCyOA=bvswWedxIVFLUDGpoEghmlJnXKCyaM if __addon__.getSetting('menu_bookmark')=='true' else bvswWedxIVFLUDGpoEghmlJnXKCyaS
  return(bvswWedxIVFLUDGpoEghmlJnXKCyOT,bvswWedxIVFLUDGpoEghmlJnXKCyOf,bvswWedxIVFLUDGpoEghmlJnXKCyOY,bvswWedxIVFLUDGpoEghmlJnXKCyOj,bvswWedxIVFLUDGpoEghmlJnXKCyOA)
 def get_settings_makebookmark(bvswWedxIVFLUDGpoEghmlJnXKCyQB):
  return bvswWedxIVFLUDGpoEghmlJnXKCyaM if __addon__.getSetting('make_bookmark')=='true' else bvswWedxIVFLUDGpoEghmlJnXKCyaS
 def get_settings_direct_replay(bvswWedxIVFLUDGpoEghmlJnXKCyQB):
  bvswWedxIVFLUDGpoEghmlJnXKCyOa=bvswWedxIVFLUDGpoEghmlJnXKCyaR(__addon__.getSetting('direct_replay'))
  if bvswWedxIVFLUDGpoEghmlJnXKCyOa==0:
   return bvswWedxIVFLUDGpoEghmlJnXKCyaS
  else:
   return bvswWedxIVFLUDGpoEghmlJnXKCyaM
 def set_winCredential(bvswWedxIVFLUDGpoEghmlJnXKCyQB,credential):
  bvswWedxIVFLUDGpoEghmlJnXKCyOR=xbmcgui.Window(10000)
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_LOGINTIME',bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(bvswWedxIVFLUDGpoEghmlJnXKCyQB):
  bvswWedxIVFLUDGpoEghmlJnXKCyOR=xbmcgui.Window(10000)
  bvswWedxIVFLUDGpoEghmlJnXKCyOM={'tving_token':bvswWedxIVFLUDGpoEghmlJnXKCyOR.getProperty('TVING_M_TOKEN'),'poc_userinfo':bvswWedxIVFLUDGpoEghmlJnXKCyOR.getProperty('TVING_M_USERINFO'),'tving_uuid':bvswWedxIVFLUDGpoEghmlJnXKCyOR.getProperty('TVING_M_UUID'),'tving_maintoken':bvswWedxIVFLUDGpoEghmlJnXKCyOR.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':bvswWedxIVFLUDGpoEghmlJnXKCyOR.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':bvswWedxIVFLUDGpoEghmlJnXKCyOR.getProperty('TVING_M_LOCKKEY')}
  return bvswWedxIVFLUDGpoEghmlJnXKCyOM
 def set_winEpisodeOrderby(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyfA):
  bvswWedxIVFLUDGpoEghmlJnXKCyOR=xbmcgui.Window(10000)
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_ORDERBY',bvswWedxIVFLUDGpoEghmlJnXKCyfA)
 def get_winEpisodeOrderby(bvswWedxIVFLUDGpoEghmlJnXKCyQB):
  bvswWedxIVFLUDGpoEghmlJnXKCyOR=xbmcgui.Window(10000)
  return bvswWedxIVFLUDGpoEghmlJnXKCyOR.getProperty('TVING_M_ORDERBY')
 def add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyQB,label,sublabel='',img='',infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyaA,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaM,params='',isLink=bvswWedxIVFLUDGpoEghmlJnXKCyaS,ContextMenu=bvswWedxIVFLUDGpoEghmlJnXKCyaA):
  bvswWedxIVFLUDGpoEghmlJnXKCyOS='%s?%s'%(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_url,urllib.parse.urlencode(params))
  if sublabel:bvswWedxIVFLUDGpoEghmlJnXKCyOB='%s < %s >'%(label,sublabel)
  else: bvswWedxIVFLUDGpoEghmlJnXKCyOB=label
  if not img:img='DefaultFolder.png'
  bvswWedxIVFLUDGpoEghmlJnXKCyOz=xbmcgui.ListItem(bvswWedxIVFLUDGpoEghmlJnXKCyOB)
  if bvswWedxIVFLUDGpoEghmlJnXKCyaB(img)==bvswWedxIVFLUDGpoEghmlJnXKCyaz:
   bvswWedxIVFLUDGpoEghmlJnXKCyOz.setArt(img)
  else:
   bvswWedxIVFLUDGpoEghmlJnXKCyOz.setArt({'thumb':img,'poster':img})
  if infoLabels:bvswWedxIVFLUDGpoEghmlJnXKCyOz.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   bvswWedxIVFLUDGpoEghmlJnXKCyOz.setProperty('IsPlayable','true')
  if ContextMenu:bvswWedxIVFLUDGpoEghmlJnXKCyOz.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,bvswWedxIVFLUDGpoEghmlJnXKCyOS,bvswWedxIVFLUDGpoEghmlJnXKCyOz,isFolder)
 def get_selQuality(bvswWedxIVFLUDGpoEghmlJnXKCyQB,etype):
  try:
   bvswWedxIVFLUDGpoEghmlJnXKCyON='selected_quality'
   bvswWedxIVFLUDGpoEghmlJnXKCyOP=[1080,720,480,360]
   bvswWedxIVFLUDGpoEghmlJnXKCyOH=bvswWedxIVFLUDGpoEghmlJnXKCyaR(__addon__.getSetting(bvswWedxIVFLUDGpoEghmlJnXKCyON))
   return bvswWedxIVFLUDGpoEghmlJnXKCyOP[bvswWedxIVFLUDGpoEghmlJnXKCyOH]
  except:
   bvswWedxIVFLUDGpoEghmlJnXKCyaA
  return 720 
 def dp_Main_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB):
  (bvswWedxIVFLUDGpoEghmlJnXKCyOT,bvswWedxIVFLUDGpoEghmlJnXKCyOf,bvswWedxIVFLUDGpoEghmlJnXKCyOY,bvswWedxIVFLUDGpoEghmlJnXKCyOj,bvswWedxIVFLUDGpoEghmlJnXKCyOA)=bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_settings_totalsearch()
  for bvswWedxIVFLUDGpoEghmlJnXKCyOc in bvswWedxIVFLUDGpoEghmlJnXKCyQT:
   bvswWedxIVFLUDGpoEghmlJnXKCyOB=bvswWedxIVFLUDGpoEghmlJnXKCyOc.get('title')
   bvswWedxIVFLUDGpoEghmlJnXKCyOk=''
   if bvswWedxIVFLUDGpoEghmlJnXKCyOc.get('mode')=='SEARCH_GROUP' and bvswWedxIVFLUDGpoEghmlJnXKCyOT ==bvswWedxIVFLUDGpoEghmlJnXKCyaS:continue
   elif bvswWedxIVFLUDGpoEghmlJnXKCyOc.get('mode')=='SEARCH_HISTORY' and bvswWedxIVFLUDGpoEghmlJnXKCyOf==bvswWedxIVFLUDGpoEghmlJnXKCyaS:continue
   elif bvswWedxIVFLUDGpoEghmlJnXKCyOc.get('mode')=='TOTAL_SEARCH' and bvswWedxIVFLUDGpoEghmlJnXKCyOY ==bvswWedxIVFLUDGpoEghmlJnXKCyaS:continue
   elif bvswWedxIVFLUDGpoEghmlJnXKCyOc.get('mode')=='TOTAL_HISTORY' and bvswWedxIVFLUDGpoEghmlJnXKCyOj==bvswWedxIVFLUDGpoEghmlJnXKCyaS:continue
   elif bvswWedxIVFLUDGpoEghmlJnXKCyOc.get('mode')=='MENU_BOOKMARK' and bvswWedxIVFLUDGpoEghmlJnXKCyOA==bvswWedxIVFLUDGpoEghmlJnXKCyaS:continue
   bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':bvswWedxIVFLUDGpoEghmlJnXKCyOc.get('mode'),'stype':bvswWedxIVFLUDGpoEghmlJnXKCyOc.get('stype'),'orderby':bvswWedxIVFLUDGpoEghmlJnXKCyOc.get('orderby'),'ordernm':bvswWedxIVFLUDGpoEghmlJnXKCyOc.get('ordernm'),'page':'1'}
   if bvswWedxIVFLUDGpoEghmlJnXKCyOc.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    bvswWedxIVFLUDGpoEghmlJnXKCyOq=bvswWedxIVFLUDGpoEghmlJnXKCyaS
    bvswWedxIVFLUDGpoEghmlJnXKCyOr =bvswWedxIVFLUDGpoEghmlJnXKCyaM
   else:
    bvswWedxIVFLUDGpoEghmlJnXKCyOq=bvswWedxIVFLUDGpoEghmlJnXKCyaM
    bvswWedxIVFLUDGpoEghmlJnXKCyOr =bvswWedxIVFLUDGpoEghmlJnXKCyaS
   if 'icon' in bvswWedxIVFLUDGpoEghmlJnXKCyOc:bvswWedxIVFLUDGpoEghmlJnXKCyOk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',bvswWedxIVFLUDGpoEghmlJnXKCyOc.get('icon')) 
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel='',img=bvswWedxIVFLUDGpoEghmlJnXKCyOk,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyaA,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyOq,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt,isLink=bvswWedxIVFLUDGpoEghmlJnXKCyOr)
  xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle)
 def login_main(bvswWedxIVFLUDGpoEghmlJnXKCyQB):
  (bvswWedxIVFLUDGpoEghmlJnXKCyOi,bvswWedxIVFLUDGpoEghmlJnXKCyTQ,bvswWedxIVFLUDGpoEghmlJnXKCyTO,bvswWedxIVFLUDGpoEghmlJnXKCyTf)=bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_settings_login_info()
  if not(bvswWedxIVFLUDGpoEghmlJnXKCyOi and bvswWedxIVFLUDGpoEghmlJnXKCyTQ):
   bvswWedxIVFLUDGpoEghmlJnXKCyQc=xbmcgui.Dialog()
   bvswWedxIVFLUDGpoEghmlJnXKCyTY=bvswWedxIVFLUDGpoEghmlJnXKCyQc.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if bvswWedxIVFLUDGpoEghmlJnXKCyTY==bvswWedxIVFLUDGpoEghmlJnXKCyaM:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_winEpisodeOrderby()=='':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.set_winEpisodeOrderby('desc')
  if bvswWedxIVFLUDGpoEghmlJnXKCyQB.cookiefile_check():return
  bvswWedxIVFLUDGpoEghmlJnXKCyTj =bvswWedxIVFLUDGpoEghmlJnXKCyaR(bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  bvswWedxIVFLUDGpoEghmlJnXKCyTA=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if bvswWedxIVFLUDGpoEghmlJnXKCyTA==bvswWedxIVFLUDGpoEghmlJnXKCyaA or bvswWedxIVFLUDGpoEghmlJnXKCyTA=='':
   bvswWedxIVFLUDGpoEghmlJnXKCyTA=bvswWedxIVFLUDGpoEghmlJnXKCyaR('19000101')
  else:
   bvswWedxIVFLUDGpoEghmlJnXKCyTA=bvswWedxIVFLUDGpoEghmlJnXKCyaR(re.sub('-','',bvswWedxIVFLUDGpoEghmlJnXKCyTA))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   bvswWedxIVFLUDGpoEghmlJnXKCyTa=0
   while bvswWedxIVFLUDGpoEghmlJnXKCyaM:
    bvswWedxIVFLUDGpoEghmlJnXKCyTa+=1
    time.sleep(0.05)
    if bvswWedxIVFLUDGpoEghmlJnXKCyTA>=bvswWedxIVFLUDGpoEghmlJnXKCyTj:return
    if bvswWedxIVFLUDGpoEghmlJnXKCyTa>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if bvswWedxIVFLUDGpoEghmlJnXKCyTA>=bvswWedxIVFLUDGpoEghmlJnXKCyTj:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.GetCredential(bvswWedxIVFLUDGpoEghmlJnXKCyOi,bvswWedxIVFLUDGpoEghmlJnXKCyTQ,bvswWedxIVFLUDGpoEghmlJnXKCyTO,bvswWedxIVFLUDGpoEghmlJnXKCyTf):
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.set_winCredential(bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.LoadCredential())
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyTR=bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('stype')
  if bvswWedxIVFLUDGpoEghmlJnXKCyTR=='live':
   bvswWedxIVFLUDGpoEghmlJnXKCyTM=bvswWedxIVFLUDGpoEghmlJnXKCyQf
  elif bvswWedxIVFLUDGpoEghmlJnXKCyTR=='vod':
   bvswWedxIVFLUDGpoEghmlJnXKCyTM=bvswWedxIVFLUDGpoEghmlJnXKCyQA
  else:
   bvswWedxIVFLUDGpoEghmlJnXKCyTM=bvswWedxIVFLUDGpoEghmlJnXKCyQa
  for bvswWedxIVFLUDGpoEghmlJnXKCyTS in bvswWedxIVFLUDGpoEghmlJnXKCyTM:
   bvswWedxIVFLUDGpoEghmlJnXKCyOB=bvswWedxIVFLUDGpoEghmlJnXKCyTS.get('title')
   if bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('ordernm')!='-':
    bvswWedxIVFLUDGpoEghmlJnXKCyOB+='  ('+bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('ordernm')+')'
   bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':bvswWedxIVFLUDGpoEghmlJnXKCyTS.get('mode'),'stype':bvswWedxIVFLUDGpoEghmlJnXKCyTS.get('stype'),'orderby':bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('orderby'),'ordernm':bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('ordernm'),'page':'1'}
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel='',img='',infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyaA,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaM,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt)
  if bvswWedxIVFLUDGpoEghmlJnXKCyaN(bvswWedxIVFLUDGpoEghmlJnXKCyTM)>0:xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle)
 def dp_SubTitle_Group(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB): 
  for bvswWedxIVFLUDGpoEghmlJnXKCyTS in bvswWedxIVFLUDGpoEghmlJnXKCyQR:
   bvswWedxIVFLUDGpoEghmlJnXKCyOB=bvswWedxIVFLUDGpoEghmlJnXKCyTS.get('title')
   if bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('ordernm')!='-':
    bvswWedxIVFLUDGpoEghmlJnXKCyOB+='  ('+bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('ordernm')+')'
   bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':bvswWedxIVFLUDGpoEghmlJnXKCyTS.get('mode'),'genreCode':bvswWedxIVFLUDGpoEghmlJnXKCyTS.get('genreCode'),'stype':bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('stype'),'orderby':bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('orderby'),'page':'1'}
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel='',img='',infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyaA,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaM,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt)
  if bvswWedxIVFLUDGpoEghmlJnXKCyaN(bvswWedxIVFLUDGpoEghmlJnXKCyQR)>0:xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle)
 def dp_LiveChannel_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.SaveCredential(bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_winCredential())
  bvswWedxIVFLUDGpoEghmlJnXKCyTR =bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('stype')
  bvswWedxIVFLUDGpoEghmlJnXKCyTz =bvswWedxIVFLUDGpoEghmlJnXKCyaR(bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('page'))
  bvswWedxIVFLUDGpoEghmlJnXKCyTN,bvswWedxIVFLUDGpoEghmlJnXKCyTP=bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.GetLiveChannelList(bvswWedxIVFLUDGpoEghmlJnXKCyTR,bvswWedxIVFLUDGpoEghmlJnXKCyTz)
  for bvswWedxIVFLUDGpoEghmlJnXKCyTH in bvswWedxIVFLUDGpoEghmlJnXKCyTN:
   bvswWedxIVFLUDGpoEghmlJnXKCyOB =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('title')
   bvswWedxIVFLUDGpoEghmlJnXKCyOu =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('channel')
   bvswWedxIVFLUDGpoEghmlJnXKCyTc =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('thumbnail')
   bvswWedxIVFLUDGpoEghmlJnXKCyTk =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('synopsis')
   bvswWedxIVFLUDGpoEghmlJnXKCyTt =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('channelepg')
   bvswWedxIVFLUDGpoEghmlJnXKCyTq =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('cast')
   bvswWedxIVFLUDGpoEghmlJnXKCyTr =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('director')
   bvswWedxIVFLUDGpoEghmlJnXKCyTu =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('info_genre')
   bvswWedxIVFLUDGpoEghmlJnXKCyTi =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('year')
   bvswWedxIVFLUDGpoEghmlJnXKCyfQ =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('mpaa')
   bvswWedxIVFLUDGpoEghmlJnXKCyfO =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('premiered')
   bvswWedxIVFLUDGpoEghmlJnXKCyfT={'mediatype':'episode','title':bvswWedxIVFLUDGpoEghmlJnXKCyOB,'studio':bvswWedxIVFLUDGpoEghmlJnXKCyOu,'cast':bvswWedxIVFLUDGpoEghmlJnXKCyTq,'director':bvswWedxIVFLUDGpoEghmlJnXKCyTr,'genre':bvswWedxIVFLUDGpoEghmlJnXKCyTu,'plot':'%s\n%s\n%s\n\n%s'%(bvswWedxIVFLUDGpoEghmlJnXKCyOu,bvswWedxIVFLUDGpoEghmlJnXKCyOB,bvswWedxIVFLUDGpoEghmlJnXKCyTt,bvswWedxIVFLUDGpoEghmlJnXKCyTk),'year':bvswWedxIVFLUDGpoEghmlJnXKCyTi,'mpaa':bvswWedxIVFLUDGpoEghmlJnXKCyfQ,'premiered':bvswWedxIVFLUDGpoEghmlJnXKCyfO}
   bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':'LIVE','mediacode':bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('mediacode'),'stype':bvswWedxIVFLUDGpoEghmlJnXKCyTR}
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOu,sublabel=bvswWedxIVFLUDGpoEghmlJnXKCyOB,img=bvswWedxIVFLUDGpoEghmlJnXKCyTc,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyfT,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaS,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt)
  if bvswWedxIVFLUDGpoEghmlJnXKCyTP:
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['mode']='CHANNEL' 
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['stype']=bvswWedxIVFLUDGpoEghmlJnXKCyTR 
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['page']=bvswWedxIVFLUDGpoEghmlJnXKCyaP(bvswWedxIVFLUDGpoEghmlJnXKCyTz+1)
   bvswWedxIVFLUDGpoEghmlJnXKCyOB='[B]%s >>[/B]'%'다음 페이지'
   bvswWedxIVFLUDGpoEghmlJnXKCyfY=bvswWedxIVFLUDGpoEghmlJnXKCyaP(bvswWedxIVFLUDGpoEghmlJnXKCyTz+1)
   bvswWedxIVFLUDGpoEghmlJnXKCyOk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel=bvswWedxIVFLUDGpoEghmlJnXKCyfY,img=bvswWedxIVFLUDGpoEghmlJnXKCyOk,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyaA,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaM,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt)
  if bvswWedxIVFLUDGpoEghmlJnXKCyaN(bvswWedxIVFLUDGpoEghmlJnXKCyTN)>0:xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,cacheToDisc=bvswWedxIVFLUDGpoEghmlJnXKCyaS)
 def dp_Program_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.SaveCredential(bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_winCredential())
  bvswWedxIVFLUDGpoEghmlJnXKCyfj =bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('stype')
  bvswWedxIVFLUDGpoEghmlJnXKCyfA =bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('orderby')
  bvswWedxIVFLUDGpoEghmlJnXKCyTz =bvswWedxIVFLUDGpoEghmlJnXKCyaR(bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('page'))
  bvswWedxIVFLUDGpoEghmlJnXKCyfa=bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('genreCode')
  if bvswWedxIVFLUDGpoEghmlJnXKCyfa==bvswWedxIVFLUDGpoEghmlJnXKCyaA:bvswWedxIVFLUDGpoEghmlJnXKCyfa='all'
  bvswWedxIVFLUDGpoEghmlJnXKCyfR,bvswWedxIVFLUDGpoEghmlJnXKCyTP=bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.GetProgramList(bvswWedxIVFLUDGpoEghmlJnXKCyfj,bvswWedxIVFLUDGpoEghmlJnXKCyfA,bvswWedxIVFLUDGpoEghmlJnXKCyTz,bvswWedxIVFLUDGpoEghmlJnXKCyfa)
  for bvswWedxIVFLUDGpoEghmlJnXKCyfM in bvswWedxIVFLUDGpoEghmlJnXKCyfR:
   bvswWedxIVFLUDGpoEghmlJnXKCyOB =bvswWedxIVFLUDGpoEghmlJnXKCyfM.get('title')
   bvswWedxIVFLUDGpoEghmlJnXKCyTc =bvswWedxIVFLUDGpoEghmlJnXKCyfM.get('thumbnail')
   bvswWedxIVFLUDGpoEghmlJnXKCyTk =bvswWedxIVFLUDGpoEghmlJnXKCyfM.get('synopsis')
   bvswWedxIVFLUDGpoEghmlJnXKCyfS =bvswWedxIVFLUDGpoEghmlJnXKCyfM.get('channel')
   bvswWedxIVFLUDGpoEghmlJnXKCyTq =bvswWedxIVFLUDGpoEghmlJnXKCyfM.get('cast')
   bvswWedxIVFLUDGpoEghmlJnXKCyTr =bvswWedxIVFLUDGpoEghmlJnXKCyfM.get('director')
   bvswWedxIVFLUDGpoEghmlJnXKCyTu=bvswWedxIVFLUDGpoEghmlJnXKCyfM.get('info_genre')
   bvswWedxIVFLUDGpoEghmlJnXKCyTi =bvswWedxIVFLUDGpoEghmlJnXKCyfM.get('year')
   bvswWedxIVFLUDGpoEghmlJnXKCyfO =bvswWedxIVFLUDGpoEghmlJnXKCyfM.get('premiered')
   bvswWedxIVFLUDGpoEghmlJnXKCyfQ =bvswWedxIVFLUDGpoEghmlJnXKCyfM.get('mpaa')
   bvswWedxIVFLUDGpoEghmlJnXKCyfT={'mediatype':'tvshow','title':bvswWedxIVFLUDGpoEghmlJnXKCyOB,'studio':bvswWedxIVFLUDGpoEghmlJnXKCyfS,'cast':bvswWedxIVFLUDGpoEghmlJnXKCyTq,'director':bvswWedxIVFLUDGpoEghmlJnXKCyTr,'genre':bvswWedxIVFLUDGpoEghmlJnXKCyTu,'year':bvswWedxIVFLUDGpoEghmlJnXKCyTi,'premiered':bvswWedxIVFLUDGpoEghmlJnXKCyfO,'mpaa':bvswWedxIVFLUDGpoEghmlJnXKCyfQ,'plot':bvswWedxIVFLUDGpoEghmlJnXKCyTk}
   bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':'EPISODE','programcode':bvswWedxIVFLUDGpoEghmlJnXKCyfM.get('program'),'page':'1'}
   if bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_settings_makebookmark():
    bvswWedxIVFLUDGpoEghmlJnXKCyfB={'videoid':bvswWedxIVFLUDGpoEghmlJnXKCyfM.get('program'),'vidtype':'tvshow','vtitle':bvswWedxIVFLUDGpoEghmlJnXKCyOB,'vsubtitle':bvswWedxIVFLUDGpoEghmlJnXKCyfS,}
    bvswWedxIVFLUDGpoEghmlJnXKCyfz=bvswWedxIVFLUDGpoEghmlJnXKCyAi.dumps(bvswWedxIVFLUDGpoEghmlJnXKCyfB)
    bvswWedxIVFLUDGpoEghmlJnXKCyfz=urllib.parse.quote(bvswWedxIVFLUDGpoEghmlJnXKCyfz)
    bvswWedxIVFLUDGpoEghmlJnXKCyfN='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(bvswWedxIVFLUDGpoEghmlJnXKCyfz)
    bvswWedxIVFLUDGpoEghmlJnXKCyfP=[('(통합) 찜 영상에 추가',bvswWedxIVFLUDGpoEghmlJnXKCyfN)]
   else:
    bvswWedxIVFLUDGpoEghmlJnXKCyfP=bvswWedxIVFLUDGpoEghmlJnXKCyaA
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel=bvswWedxIVFLUDGpoEghmlJnXKCyfS,img=bvswWedxIVFLUDGpoEghmlJnXKCyTc,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyfT,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaM,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt,ContextMenu=bvswWedxIVFLUDGpoEghmlJnXKCyfP)
  if bvswWedxIVFLUDGpoEghmlJnXKCyTP:
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['mode'] ='PROGRAM' 
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['stype'] =bvswWedxIVFLUDGpoEghmlJnXKCyfj
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['orderby'] =bvswWedxIVFLUDGpoEghmlJnXKCyfA
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['page'] =bvswWedxIVFLUDGpoEghmlJnXKCyaP(bvswWedxIVFLUDGpoEghmlJnXKCyTz+1)
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['genreCode']=bvswWedxIVFLUDGpoEghmlJnXKCyfa 
   bvswWedxIVFLUDGpoEghmlJnXKCyOB='[B]%s >>[/B]'%'다음 페이지'
   bvswWedxIVFLUDGpoEghmlJnXKCyfY=bvswWedxIVFLUDGpoEghmlJnXKCyaP(bvswWedxIVFLUDGpoEghmlJnXKCyTz+1)
   bvswWedxIVFLUDGpoEghmlJnXKCyOk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel=bvswWedxIVFLUDGpoEghmlJnXKCyfY,img=bvswWedxIVFLUDGpoEghmlJnXKCyOk,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyaA,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaM,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt)
  xbmcplugin.setContent(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,cacheToDisc=bvswWedxIVFLUDGpoEghmlJnXKCyaS)
 def dp_Episode_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.SaveCredential(bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_winCredential())
  bvswWedxIVFLUDGpoEghmlJnXKCyfc=bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('programcode')
  bvswWedxIVFLUDGpoEghmlJnXKCyTz =bvswWedxIVFLUDGpoEghmlJnXKCyaR(bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('page'))
  bvswWedxIVFLUDGpoEghmlJnXKCyfk,bvswWedxIVFLUDGpoEghmlJnXKCyTP,bvswWedxIVFLUDGpoEghmlJnXKCyft=bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.GetEpisodeList(bvswWedxIVFLUDGpoEghmlJnXKCyfc,bvswWedxIVFLUDGpoEghmlJnXKCyTz,orderby=bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_winEpisodeOrderby())
  for bvswWedxIVFLUDGpoEghmlJnXKCyfq in bvswWedxIVFLUDGpoEghmlJnXKCyfk:
   bvswWedxIVFLUDGpoEghmlJnXKCyOB =bvswWedxIVFLUDGpoEghmlJnXKCyfq.get('title')
   bvswWedxIVFLUDGpoEghmlJnXKCyfY =bvswWedxIVFLUDGpoEghmlJnXKCyfq.get('subtitle')
   bvswWedxIVFLUDGpoEghmlJnXKCyTc =bvswWedxIVFLUDGpoEghmlJnXKCyfq.get('thumbnail')
   bvswWedxIVFLUDGpoEghmlJnXKCyTk =bvswWedxIVFLUDGpoEghmlJnXKCyfq.get('synopsis')
   bvswWedxIVFLUDGpoEghmlJnXKCyfr=bvswWedxIVFLUDGpoEghmlJnXKCyfq.get('info_title')
   bvswWedxIVFLUDGpoEghmlJnXKCyfu =bvswWedxIVFLUDGpoEghmlJnXKCyfq.get('aired')
   bvswWedxIVFLUDGpoEghmlJnXKCyfi =bvswWedxIVFLUDGpoEghmlJnXKCyfq.get('studio')
   bvswWedxIVFLUDGpoEghmlJnXKCyYQ =bvswWedxIVFLUDGpoEghmlJnXKCyfq.get('frequency')
   bvswWedxIVFLUDGpoEghmlJnXKCyfT={'mediatype':'episode','title':bvswWedxIVFLUDGpoEghmlJnXKCyfr,'aired':bvswWedxIVFLUDGpoEghmlJnXKCyfu,'studio':bvswWedxIVFLUDGpoEghmlJnXKCyfi,'episode':bvswWedxIVFLUDGpoEghmlJnXKCyYQ,'plot':bvswWedxIVFLUDGpoEghmlJnXKCyTk}
   bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':'VOD','mediacode':bvswWedxIVFLUDGpoEghmlJnXKCyfq.get('episode'),'stype':'vod','programcode':bvswWedxIVFLUDGpoEghmlJnXKCyfc,'title':bvswWedxIVFLUDGpoEghmlJnXKCyOB,'thumbnail':bvswWedxIVFLUDGpoEghmlJnXKCyTc}
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel=bvswWedxIVFLUDGpoEghmlJnXKCyfY,img=bvswWedxIVFLUDGpoEghmlJnXKCyTc,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyfT,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaS,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt)
  if bvswWedxIVFLUDGpoEghmlJnXKCyTz==1:
   bvswWedxIVFLUDGpoEghmlJnXKCyfT={'plot':'정렬순서를 변경합니다.'}
   bvswWedxIVFLUDGpoEghmlJnXKCyOt={}
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['mode'] ='ORDER_BY' 
   if bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_winEpisodeOrderby()=='desc':
    bvswWedxIVFLUDGpoEghmlJnXKCyOB='정렬순서변경 : 최신화부터 -> 1회부터'
    bvswWedxIVFLUDGpoEghmlJnXKCyOt['orderby']='asc'
   else:
    bvswWedxIVFLUDGpoEghmlJnXKCyOB='정렬순서변경 : 1회부터 -> 최신화부터'
    bvswWedxIVFLUDGpoEghmlJnXKCyOt['orderby']='desc'
   bvswWedxIVFLUDGpoEghmlJnXKCyOk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel='',img=bvswWedxIVFLUDGpoEghmlJnXKCyOk,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyfT,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaS,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt,isLink=bvswWedxIVFLUDGpoEghmlJnXKCyaM)
  if bvswWedxIVFLUDGpoEghmlJnXKCyTP:
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['mode'] ='EPISODE' 
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['programcode']=bvswWedxIVFLUDGpoEghmlJnXKCyfc
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['page'] =bvswWedxIVFLUDGpoEghmlJnXKCyaP(bvswWedxIVFLUDGpoEghmlJnXKCyTz+1)
   bvswWedxIVFLUDGpoEghmlJnXKCyOB='[B]%s >>[/B]'%'다음 페이지'
   bvswWedxIVFLUDGpoEghmlJnXKCyfY=bvswWedxIVFLUDGpoEghmlJnXKCyaP(bvswWedxIVFLUDGpoEghmlJnXKCyTz+1)
   bvswWedxIVFLUDGpoEghmlJnXKCyOk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel=bvswWedxIVFLUDGpoEghmlJnXKCyfY,img=bvswWedxIVFLUDGpoEghmlJnXKCyOk,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyaA,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaM,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt)
  xbmcplugin.setContent(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,'episodes')
  if bvswWedxIVFLUDGpoEghmlJnXKCyaN(bvswWedxIVFLUDGpoEghmlJnXKCyfk)>0:xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,cacheToDisc=bvswWedxIVFLUDGpoEghmlJnXKCyaM)
 def dp_setEpOrderby(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyfA =bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('orderby')
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.set_winEpisodeOrderby(bvswWedxIVFLUDGpoEghmlJnXKCyfA)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.SaveCredential(bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_winCredential())
  bvswWedxIVFLUDGpoEghmlJnXKCyfj =bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('stype')
  bvswWedxIVFLUDGpoEghmlJnXKCyfA =bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('orderby')
  bvswWedxIVFLUDGpoEghmlJnXKCyTz=bvswWedxIVFLUDGpoEghmlJnXKCyaR(bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('page'))
  bvswWedxIVFLUDGpoEghmlJnXKCyYO,bvswWedxIVFLUDGpoEghmlJnXKCyTP=bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.GetMovieList(bvswWedxIVFLUDGpoEghmlJnXKCyfj,bvswWedxIVFLUDGpoEghmlJnXKCyfA,bvswWedxIVFLUDGpoEghmlJnXKCyTz)
  for bvswWedxIVFLUDGpoEghmlJnXKCyYT in bvswWedxIVFLUDGpoEghmlJnXKCyYO:
   bvswWedxIVFLUDGpoEghmlJnXKCyOB =bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('title')
   bvswWedxIVFLUDGpoEghmlJnXKCyTc =bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('thumbnail')
   bvswWedxIVFLUDGpoEghmlJnXKCyTk =bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('synopsis')
   bvswWedxIVFLUDGpoEghmlJnXKCyfr =bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('info_title')
   bvswWedxIVFLUDGpoEghmlJnXKCyTi =bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('year')
   bvswWedxIVFLUDGpoEghmlJnXKCyTq =bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('cast')
   bvswWedxIVFLUDGpoEghmlJnXKCyTr =bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('director')
   bvswWedxIVFLUDGpoEghmlJnXKCyTu =bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('info_genre')
   bvswWedxIVFLUDGpoEghmlJnXKCyYf =bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('duration')
   bvswWedxIVFLUDGpoEghmlJnXKCyfO =bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('premiered')
   bvswWedxIVFLUDGpoEghmlJnXKCyfi =bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('studio')
   bvswWedxIVFLUDGpoEghmlJnXKCyfQ =bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('mpaa')
   bvswWedxIVFLUDGpoEghmlJnXKCyfT={'mediatype':'movie','title':bvswWedxIVFLUDGpoEghmlJnXKCyfr,'year':bvswWedxIVFLUDGpoEghmlJnXKCyTi,'cast':bvswWedxIVFLUDGpoEghmlJnXKCyTq,'director':bvswWedxIVFLUDGpoEghmlJnXKCyTr,'genre':bvswWedxIVFLUDGpoEghmlJnXKCyTu,'duration':bvswWedxIVFLUDGpoEghmlJnXKCyYf,'premiered':bvswWedxIVFLUDGpoEghmlJnXKCyfO,'studio':bvswWedxIVFLUDGpoEghmlJnXKCyfi,'mpaa':bvswWedxIVFLUDGpoEghmlJnXKCyfQ,'plot':bvswWedxIVFLUDGpoEghmlJnXKCyTk}
   bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':'MOVIE','mediacode':bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('moviecode'),'stype':'movie','title':bvswWedxIVFLUDGpoEghmlJnXKCyOB,'thumbnail':bvswWedxIVFLUDGpoEghmlJnXKCyTc}
   if bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_settings_makebookmark():
    bvswWedxIVFLUDGpoEghmlJnXKCyfB={'videoid':bvswWedxIVFLUDGpoEghmlJnXKCyYT.get('moviecode'),'vidtype':'movie','vtitle':bvswWedxIVFLUDGpoEghmlJnXKCyfr,'vsubtitle':'',}
    bvswWedxIVFLUDGpoEghmlJnXKCyfz=bvswWedxIVFLUDGpoEghmlJnXKCyAi.dumps(bvswWedxIVFLUDGpoEghmlJnXKCyfB)
    bvswWedxIVFLUDGpoEghmlJnXKCyfz=urllib.parse.quote(bvswWedxIVFLUDGpoEghmlJnXKCyfz)
    bvswWedxIVFLUDGpoEghmlJnXKCyfN='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(bvswWedxIVFLUDGpoEghmlJnXKCyfz)
    bvswWedxIVFLUDGpoEghmlJnXKCyfP=[('(통합) 찜 영상에 추가',bvswWedxIVFLUDGpoEghmlJnXKCyfN)]
   else:
    bvswWedxIVFLUDGpoEghmlJnXKCyfP=bvswWedxIVFLUDGpoEghmlJnXKCyaA
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel='',img=bvswWedxIVFLUDGpoEghmlJnXKCyTc,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyfT,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaS,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt,ContextMenu=bvswWedxIVFLUDGpoEghmlJnXKCyfP)
  if bvswWedxIVFLUDGpoEghmlJnXKCyTP:
   bvswWedxIVFLUDGpoEghmlJnXKCyOt={}
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['mode'] ='MOVIE_SUB' 
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['orderby']=bvswWedxIVFLUDGpoEghmlJnXKCyfA
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['stype'] =bvswWedxIVFLUDGpoEghmlJnXKCyfj
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['page'] =bvswWedxIVFLUDGpoEghmlJnXKCyaP(bvswWedxIVFLUDGpoEghmlJnXKCyTz+1)
   bvswWedxIVFLUDGpoEghmlJnXKCyOB='[B]%s >>[/B]'%'다음 페이지'
   bvswWedxIVFLUDGpoEghmlJnXKCyfY=bvswWedxIVFLUDGpoEghmlJnXKCyaP(bvswWedxIVFLUDGpoEghmlJnXKCyTz+1)
   bvswWedxIVFLUDGpoEghmlJnXKCyOk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel=bvswWedxIVFLUDGpoEghmlJnXKCyfY,img=bvswWedxIVFLUDGpoEghmlJnXKCyOk,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyaA,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaM,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt)
  xbmcplugin.setContent(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,'movies')
  xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,cacheToDisc=bvswWedxIVFLUDGpoEghmlJnXKCyaS)
 def dp_Set_Bookmark(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyYj=urllib.parse.unquote(bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('bm_param'))
  bvswWedxIVFLUDGpoEghmlJnXKCyYj=bvswWedxIVFLUDGpoEghmlJnXKCyAi.loads(bvswWedxIVFLUDGpoEghmlJnXKCyYj)
  bvswWedxIVFLUDGpoEghmlJnXKCyYA =bvswWedxIVFLUDGpoEghmlJnXKCyYj.get('videoid')
  bvswWedxIVFLUDGpoEghmlJnXKCyYa =bvswWedxIVFLUDGpoEghmlJnXKCyYj.get('vidtype')
  bvswWedxIVFLUDGpoEghmlJnXKCyYR =bvswWedxIVFLUDGpoEghmlJnXKCyYj.get('vtitle')
  bvswWedxIVFLUDGpoEghmlJnXKCyYM =bvswWedxIVFLUDGpoEghmlJnXKCyYj.get('vsubtitle')
  bvswWedxIVFLUDGpoEghmlJnXKCyQc=xbmcgui.Dialog()
  bvswWedxIVFLUDGpoEghmlJnXKCyTY=bvswWedxIVFLUDGpoEghmlJnXKCyQc.yesno(__language__(30913).encode('utf8'),bvswWedxIVFLUDGpoEghmlJnXKCyYR+' \n\n'+__language__(30914))
  if bvswWedxIVFLUDGpoEghmlJnXKCyTY==bvswWedxIVFLUDGpoEghmlJnXKCyaS:return
  bvswWedxIVFLUDGpoEghmlJnXKCyYS=bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.GetBookmarkInfo(bvswWedxIVFLUDGpoEghmlJnXKCyYA,bvswWedxIVFLUDGpoEghmlJnXKCyYa)
  if bvswWedxIVFLUDGpoEghmlJnXKCyYM!='':
   bvswWedxIVFLUDGpoEghmlJnXKCyYS['saveinfo']['subtitle']=bvswWedxIVFLUDGpoEghmlJnXKCyYM 
   if bvswWedxIVFLUDGpoEghmlJnXKCyYa=='tvshow':bvswWedxIVFLUDGpoEghmlJnXKCyYS['saveinfo']['infoLabels']['studio']=bvswWedxIVFLUDGpoEghmlJnXKCyYM 
  bvswWedxIVFLUDGpoEghmlJnXKCyYB=bvswWedxIVFLUDGpoEghmlJnXKCyAi.dumps(bvswWedxIVFLUDGpoEghmlJnXKCyYS)
  bvswWedxIVFLUDGpoEghmlJnXKCyYB=urllib.parse.quote(bvswWedxIVFLUDGpoEghmlJnXKCyYB)
  bvswWedxIVFLUDGpoEghmlJnXKCyfN ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(bvswWedxIVFLUDGpoEghmlJnXKCyYB)
  xbmc.executebuiltin(bvswWedxIVFLUDGpoEghmlJnXKCyfN)
 def dp_Search_Group(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  if 'search_key' in bvswWedxIVFLUDGpoEghmlJnXKCyTB:
   bvswWedxIVFLUDGpoEghmlJnXKCyYz=bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('search_key')
  else:
   bvswWedxIVFLUDGpoEghmlJnXKCyYz=bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not bvswWedxIVFLUDGpoEghmlJnXKCyYz:
    return
  for bvswWedxIVFLUDGpoEghmlJnXKCyTS in bvswWedxIVFLUDGpoEghmlJnXKCyQj:
   bvswWedxIVFLUDGpoEghmlJnXKCyYN =bvswWedxIVFLUDGpoEghmlJnXKCyTS.get('mode')
   bvswWedxIVFLUDGpoEghmlJnXKCyTR=bvswWedxIVFLUDGpoEghmlJnXKCyTS.get('stype')
   bvswWedxIVFLUDGpoEghmlJnXKCyOB=bvswWedxIVFLUDGpoEghmlJnXKCyTS.get('title')
   (bvswWedxIVFLUDGpoEghmlJnXKCyYP,bvswWedxIVFLUDGpoEghmlJnXKCyTP)=bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.GetSearchList(bvswWedxIVFLUDGpoEghmlJnXKCyYz,1,bvswWedxIVFLUDGpoEghmlJnXKCyTR)
   bvswWedxIVFLUDGpoEghmlJnXKCyYH={'plot':'검색어 : '+bvswWedxIVFLUDGpoEghmlJnXKCyYz+'\n\n'+bvswWedxIVFLUDGpoEghmlJnXKCyQB.Search_FreeList(bvswWedxIVFLUDGpoEghmlJnXKCyYP)}
   bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':bvswWedxIVFLUDGpoEghmlJnXKCyYN,'stype':bvswWedxIVFLUDGpoEghmlJnXKCyTR,'search_key':bvswWedxIVFLUDGpoEghmlJnXKCyYz,'page':'1',}
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel='',img='',infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyYH,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaM,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt)
  if bvswWedxIVFLUDGpoEghmlJnXKCyaN(bvswWedxIVFLUDGpoEghmlJnXKCyQj)>0:xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,cacheToDisc=bvswWedxIVFLUDGpoEghmlJnXKCyaM)
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.Save_Searched_List(bvswWedxIVFLUDGpoEghmlJnXKCyYz)
 def Search_FreeList(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyjO):
  bvswWedxIVFLUDGpoEghmlJnXKCyYc=''
  bvswWedxIVFLUDGpoEghmlJnXKCyYk=7
  try:
   if bvswWedxIVFLUDGpoEghmlJnXKCyaN(bvswWedxIVFLUDGpoEghmlJnXKCyjO)==0:return '검색결과 없음'
   for i in bvswWedxIVFLUDGpoEghmlJnXKCyaH(bvswWedxIVFLUDGpoEghmlJnXKCyaN(bvswWedxIVFLUDGpoEghmlJnXKCyjO)):
    if i>=bvswWedxIVFLUDGpoEghmlJnXKCyYk:
     bvswWedxIVFLUDGpoEghmlJnXKCyYc=bvswWedxIVFLUDGpoEghmlJnXKCyYc+'...'
     break
    bvswWedxIVFLUDGpoEghmlJnXKCyYc=bvswWedxIVFLUDGpoEghmlJnXKCyYc+bvswWedxIVFLUDGpoEghmlJnXKCyjO[i]['title']+'\n'
  except:
   return ''
  return bvswWedxIVFLUDGpoEghmlJnXKCyYc
 def dp_Search_History(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyYt=bvswWedxIVFLUDGpoEghmlJnXKCyQB.Load_List_File('search')
  for bvswWedxIVFLUDGpoEghmlJnXKCyYq in bvswWedxIVFLUDGpoEghmlJnXKCyYt:
   bvswWedxIVFLUDGpoEghmlJnXKCyYr=bvswWedxIVFLUDGpoEghmlJnXKCyaz(urllib.parse.parse_qsl(bvswWedxIVFLUDGpoEghmlJnXKCyYq))
   bvswWedxIVFLUDGpoEghmlJnXKCyYu=bvswWedxIVFLUDGpoEghmlJnXKCyYr.get('skey').strip()
   bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':'SEARCH_GROUP','search_key':bvswWedxIVFLUDGpoEghmlJnXKCyYu,}
   bvswWedxIVFLUDGpoEghmlJnXKCyYi={'mode':'SEARCH_REMOVE','stype':'ONE','skey':bvswWedxIVFLUDGpoEghmlJnXKCyYu,}
   bvswWedxIVFLUDGpoEghmlJnXKCyjQ=urllib.parse.urlencode(bvswWedxIVFLUDGpoEghmlJnXKCyYi)
   bvswWedxIVFLUDGpoEghmlJnXKCyfP=[('선택된 검색어 ( %s ) 삭제'%(bvswWedxIVFLUDGpoEghmlJnXKCyYu),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(bvswWedxIVFLUDGpoEghmlJnXKCyjQ))]
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyYu,sublabel='',img=bvswWedxIVFLUDGpoEghmlJnXKCyaA,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyaA,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaM,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt,ContextMenu=bvswWedxIVFLUDGpoEghmlJnXKCyfP)
  bvswWedxIVFLUDGpoEghmlJnXKCyfT={'plot':'검색목록 전체를 삭제합니다.'}
  bvswWedxIVFLUDGpoEghmlJnXKCyOB='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  bvswWedxIVFLUDGpoEghmlJnXKCyOk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel='',img=bvswWedxIVFLUDGpoEghmlJnXKCyOk,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyfT,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaS,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt,isLink=bvswWedxIVFLUDGpoEghmlJnXKCyaM)
  xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,cacheToDisc=bvswWedxIVFLUDGpoEghmlJnXKCyaS)
 def dp_Search_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.SaveCredential(bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_winCredential())
  bvswWedxIVFLUDGpoEghmlJnXKCyTz =bvswWedxIVFLUDGpoEghmlJnXKCyaR(bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('page'))
  bvswWedxIVFLUDGpoEghmlJnXKCyTR =bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('stype')
  if 'search_key' in bvswWedxIVFLUDGpoEghmlJnXKCyTB:
   bvswWedxIVFLUDGpoEghmlJnXKCyYz=bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('search_key')
  else:
   bvswWedxIVFLUDGpoEghmlJnXKCyYz=bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not bvswWedxIVFLUDGpoEghmlJnXKCyYz:
    xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle)
    return
  bvswWedxIVFLUDGpoEghmlJnXKCyYP,bvswWedxIVFLUDGpoEghmlJnXKCyTP=bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.GetSearchList(bvswWedxIVFLUDGpoEghmlJnXKCyYz,bvswWedxIVFLUDGpoEghmlJnXKCyTz,bvswWedxIVFLUDGpoEghmlJnXKCyTR)
  for bvswWedxIVFLUDGpoEghmlJnXKCyjO in bvswWedxIVFLUDGpoEghmlJnXKCyYP:
   bvswWedxIVFLUDGpoEghmlJnXKCyOB =bvswWedxIVFLUDGpoEghmlJnXKCyjO.get('title')
   bvswWedxIVFLUDGpoEghmlJnXKCyTc =bvswWedxIVFLUDGpoEghmlJnXKCyjO.get('thumbnail')
   bvswWedxIVFLUDGpoEghmlJnXKCyTk =bvswWedxIVFLUDGpoEghmlJnXKCyjO.get('synopsis')
   bvswWedxIVFLUDGpoEghmlJnXKCyjT =bvswWedxIVFLUDGpoEghmlJnXKCyjO.get('program')
   bvswWedxIVFLUDGpoEghmlJnXKCyTq =bvswWedxIVFLUDGpoEghmlJnXKCyjO.get('cast')
   bvswWedxIVFLUDGpoEghmlJnXKCyTr =bvswWedxIVFLUDGpoEghmlJnXKCyjO.get('director')
   bvswWedxIVFLUDGpoEghmlJnXKCyTu=bvswWedxIVFLUDGpoEghmlJnXKCyjO.get('info_genre')
   bvswWedxIVFLUDGpoEghmlJnXKCyYf =bvswWedxIVFLUDGpoEghmlJnXKCyjO.get('duration')
   bvswWedxIVFLUDGpoEghmlJnXKCyfQ =bvswWedxIVFLUDGpoEghmlJnXKCyjO.get('mpaa')
   bvswWedxIVFLUDGpoEghmlJnXKCyTi =bvswWedxIVFLUDGpoEghmlJnXKCyjO.get('year')
   bvswWedxIVFLUDGpoEghmlJnXKCyfu =bvswWedxIVFLUDGpoEghmlJnXKCyjO.get('aired')
   bvswWedxIVFLUDGpoEghmlJnXKCyfT={'mediatype':'tvshow' if bvswWedxIVFLUDGpoEghmlJnXKCyTR=='vod' else 'movie','title':bvswWedxIVFLUDGpoEghmlJnXKCyOB,'cast':bvswWedxIVFLUDGpoEghmlJnXKCyTq,'director':bvswWedxIVFLUDGpoEghmlJnXKCyTr,'genre':bvswWedxIVFLUDGpoEghmlJnXKCyTu,'duration':bvswWedxIVFLUDGpoEghmlJnXKCyYf,'mpaa':bvswWedxIVFLUDGpoEghmlJnXKCyfQ,'year':bvswWedxIVFLUDGpoEghmlJnXKCyTi,'aired':bvswWedxIVFLUDGpoEghmlJnXKCyfu,'plot':'%s\n\n%s'%(bvswWedxIVFLUDGpoEghmlJnXKCyOB,bvswWedxIVFLUDGpoEghmlJnXKCyTk)}
   if bvswWedxIVFLUDGpoEghmlJnXKCyTR=='vod':
    bvswWedxIVFLUDGpoEghmlJnXKCyYA=bvswWedxIVFLUDGpoEghmlJnXKCyjO.get('program')
    bvswWedxIVFLUDGpoEghmlJnXKCyYa='tvshow'
    bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':'EPISODE','programcode':bvswWedxIVFLUDGpoEghmlJnXKCyYA,'page':'1',}
    bvswWedxIVFLUDGpoEghmlJnXKCyOq=bvswWedxIVFLUDGpoEghmlJnXKCyaM
   else:
    bvswWedxIVFLUDGpoEghmlJnXKCyYA=bvswWedxIVFLUDGpoEghmlJnXKCyjO.get('movie')
    bvswWedxIVFLUDGpoEghmlJnXKCyYa='movie'
    bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':'MOVIE','mediacode':bvswWedxIVFLUDGpoEghmlJnXKCyYA,'stype':'movie','title':bvswWedxIVFLUDGpoEghmlJnXKCyOB,'thumbnail':bvswWedxIVFLUDGpoEghmlJnXKCyTc,}
    bvswWedxIVFLUDGpoEghmlJnXKCyOq=bvswWedxIVFLUDGpoEghmlJnXKCyaS
   if bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_settings_makebookmark():
    bvswWedxIVFLUDGpoEghmlJnXKCyfB={'videoid':bvswWedxIVFLUDGpoEghmlJnXKCyYA,'vidtype':bvswWedxIVFLUDGpoEghmlJnXKCyYa,'vtitle':bvswWedxIVFLUDGpoEghmlJnXKCyOB,'vsubtitle':'',}
    bvswWedxIVFLUDGpoEghmlJnXKCyfz=bvswWedxIVFLUDGpoEghmlJnXKCyAi.dumps(bvswWedxIVFLUDGpoEghmlJnXKCyfB)
    bvswWedxIVFLUDGpoEghmlJnXKCyfz=urllib.parse.quote(bvswWedxIVFLUDGpoEghmlJnXKCyfz)
    bvswWedxIVFLUDGpoEghmlJnXKCyfN='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(bvswWedxIVFLUDGpoEghmlJnXKCyfz)
    bvswWedxIVFLUDGpoEghmlJnXKCyfP=[('(통합) 찜 영상에 추가',bvswWedxIVFLUDGpoEghmlJnXKCyfN)]
   else:
    bvswWedxIVFLUDGpoEghmlJnXKCyfP=bvswWedxIVFLUDGpoEghmlJnXKCyaA
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel='',img=bvswWedxIVFLUDGpoEghmlJnXKCyTc,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyfT,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyOq,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt,isLink=bvswWedxIVFLUDGpoEghmlJnXKCyaS,ContextMenu=bvswWedxIVFLUDGpoEghmlJnXKCyfP)
  if bvswWedxIVFLUDGpoEghmlJnXKCyTP:
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['mode'] ='SEARCH' 
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['search_key']=bvswWedxIVFLUDGpoEghmlJnXKCyYz
   bvswWedxIVFLUDGpoEghmlJnXKCyOt['page'] =bvswWedxIVFLUDGpoEghmlJnXKCyaP(bvswWedxIVFLUDGpoEghmlJnXKCyTz+1)
   bvswWedxIVFLUDGpoEghmlJnXKCyOB='[B]%s >>[/B]'%'다음 페이지'
   bvswWedxIVFLUDGpoEghmlJnXKCyfY=bvswWedxIVFLUDGpoEghmlJnXKCyaP(bvswWedxIVFLUDGpoEghmlJnXKCyTz+1)
   bvswWedxIVFLUDGpoEghmlJnXKCyOk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel=bvswWedxIVFLUDGpoEghmlJnXKCyfY,img=bvswWedxIVFLUDGpoEghmlJnXKCyOk,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyaA,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaM,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt)
  if bvswWedxIVFLUDGpoEghmlJnXKCyTR=='movie':xbmcplugin.setContent(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,'movies')
  else:xbmcplugin.setContent(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,cacheToDisc=bvswWedxIVFLUDGpoEghmlJnXKCyaS)
 def Delete_List_File(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTR,skey='-'):
  if bvswWedxIVFLUDGpoEghmlJnXKCyTR=='ALL':
   try:
    bvswWedxIVFLUDGpoEghmlJnXKCyjf=bvswWedxIVFLUDGpoEghmlJnXKCyQS
    fp=bvswWedxIVFLUDGpoEghmlJnXKCyac(bvswWedxIVFLUDGpoEghmlJnXKCyjf,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    bvswWedxIVFLUDGpoEghmlJnXKCyaA
  elif bvswWedxIVFLUDGpoEghmlJnXKCyTR=='ONE':
   try:
    bvswWedxIVFLUDGpoEghmlJnXKCyjf=bvswWedxIVFLUDGpoEghmlJnXKCyQS
    bvswWedxIVFLUDGpoEghmlJnXKCyjY=bvswWedxIVFLUDGpoEghmlJnXKCyQB.Load_List_File('search') 
    fp=bvswWedxIVFLUDGpoEghmlJnXKCyac(bvswWedxIVFLUDGpoEghmlJnXKCyjf,'w',-1,'utf-8')
    for bvswWedxIVFLUDGpoEghmlJnXKCyjA in bvswWedxIVFLUDGpoEghmlJnXKCyjY:
     bvswWedxIVFLUDGpoEghmlJnXKCyja=bvswWedxIVFLUDGpoEghmlJnXKCyaz(urllib.parse.parse_qsl(bvswWedxIVFLUDGpoEghmlJnXKCyjA))
     bvswWedxIVFLUDGpoEghmlJnXKCyjR=bvswWedxIVFLUDGpoEghmlJnXKCyja.get('skey').strip()
     if skey!=bvswWedxIVFLUDGpoEghmlJnXKCyjR:
      fp.write(bvswWedxIVFLUDGpoEghmlJnXKCyjA)
    fp.close()
   except:
    bvswWedxIVFLUDGpoEghmlJnXKCyaA
  elif bvswWedxIVFLUDGpoEghmlJnXKCyTR in['vod','movie']:
   try:
    bvswWedxIVFLUDGpoEghmlJnXKCyjf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bvswWedxIVFLUDGpoEghmlJnXKCyTR))
    fp=bvswWedxIVFLUDGpoEghmlJnXKCyac(bvswWedxIVFLUDGpoEghmlJnXKCyjf,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    bvswWedxIVFLUDGpoEghmlJnXKCyaA
 def dp_Listfile_Delete(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyTR=bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('stype')
  bvswWedxIVFLUDGpoEghmlJnXKCyYu =bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('skey')
  bvswWedxIVFLUDGpoEghmlJnXKCyQc=xbmcgui.Dialog()
  if bvswWedxIVFLUDGpoEghmlJnXKCyTR=='ALL':
   bvswWedxIVFLUDGpoEghmlJnXKCyTY=bvswWedxIVFLUDGpoEghmlJnXKCyQc.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif bvswWedxIVFLUDGpoEghmlJnXKCyTR=='ONE':
   bvswWedxIVFLUDGpoEghmlJnXKCyTY=bvswWedxIVFLUDGpoEghmlJnXKCyQc.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif bvswWedxIVFLUDGpoEghmlJnXKCyTR in['vod','movie']:
   bvswWedxIVFLUDGpoEghmlJnXKCyTY=bvswWedxIVFLUDGpoEghmlJnXKCyQc.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if bvswWedxIVFLUDGpoEghmlJnXKCyTY==bvswWedxIVFLUDGpoEghmlJnXKCyaS:sys.exit()
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.Delete_List_File(bvswWedxIVFLUDGpoEghmlJnXKCyTR,skey=bvswWedxIVFLUDGpoEghmlJnXKCyYu)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTR): 
  try:
   if bvswWedxIVFLUDGpoEghmlJnXKCyTR=='search':
    bvswWedxIVFLUDGpoEghmlJnXKCyjf=bvswWedxIVFLUDGpoEghmlJnXKCyQS
   elif bvswWedxIVFLUDGpoEghmlJnXKCyTR in['vod','movie']:
    bvswWedxIVFLUDGpoEghmlJnXKCyjf=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bvswWedxIVFLUDGpoEghmlJnXKCyTR))
   else:
    return[]
   fp=bvswWedxIVFLUDGpoEghmlJnXKCyac(bvswWedxIVFLUDGpoEghmlJnXKCyjf,'r',-1,'utf-8')
   bvswWedxIVFLUDGpoEghmlJnXKCyjM=fp.readlines()
   fp.close()
  except:
   bvswWedxIVFLUDGpoEghmlJnXKCyjM=[]
  return bvswWedxIVFLUDGpoEghmlJnXKCyjM
 def Save_Watched_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTR,bvswWedxIVFLUDGpoEghmlJnXKCyQP):
  try:
   bvswWedxIVFLUDGpoEghmlJnXKCyjS=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%bvswWedxIVFLUDGpoEghmlJnXKCyTR))
   bvswWedxIVFLUDGpoEghmlJnXKCyjY=bvswWedxIVFLUDGpoEghmlJnXKCyQB.Load_List_File(bvswWedxIVFLUDGpoEghmlJnXKCyTR) 
   fp=bvswWedxIVFLUDGpoEghmlJnXKCyac(bvswWedxIVFLUDGpoEghmlJnXKCyjS,'w',-1,'utf-8')
   bvswWedxIVFLUDGpoEghmlJnXKCyjB=urllib.parse.urlencode(bvswWedxIVFLUDGpoEghmlJnXKCyQP)
   bvswWedxIVFLUDGpoEghmlJnXKCyjB=bvswWedxIVFLUDGpoEghmlJnXKCyjB+'\n'
   fp.write(bvswWedxIVFLUDGpoEghmlJnXKCyjB)
   bvswWedxIVFLUDGpoEghmlJnXKCyjz=0
   for bvswWedxIVFLUDGpoEghmlJnXKCyjA in bvswWedxIVFLUDGpoEghmlJnXKCyjY:
    bvswWedxIVFLUDGpoEghmlJnXKCyja=bvswWedxIVFLUDGpoEghmlJnXKCyaz(urllib.parse.parse_qsl(bvswWedxIVFLUDGpoEghmlJnXKCyjA))
    bvswWedxIVFLUDGpoEghmlJnXKCyjN=bvswWedxIVFLUDGpoEghmlJnXKCyQP.get('code').strip()
    bvswWedxIVFLUDGpoEghmlJnXKCyjP=bvswWedxIVFLUDGpoEghmlJnXKCyja.get('code').strip()
    if bvswWedxIVFLUDGpoEghmlJnXKCyTR=='vod' and bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_settings_direct_replay()==bvswWedxIVFLUDGpoEghmlJnXKCyaM:
     bvswWedxIVFLUDGpoEghmlJnXKCyjN=bvswWedxIVFLUDGpoEghmlJnXKCyQP.get('videoid').strip()
     bvswWedxIVFLUDGpoEghmlJnXKCyjP=bvswWedxIVFLUDGpoEghmlJnXKCyja.get('videoid').strip()if bvswWedxIVFLUDGpoEghmlJnXKCyjP!=bvswWedxIVFLUDGpoEghmlJnXKCyaA else '-'
    if bvswWedxIVFLUDGpoEghmlJnXKCyjN!=bvswWedxIVFLUDGpoEghmlJnXKCyjP:
     fp.write(bvswWedxIVFLUDGpoEghmlJnXKCyjA)
     bvswWedxIVFLUDGpoEghmlJnXKCyjz+=1
     if bvswWedxIVFLUDGpoEghmlJnXKCyjz>=50:break
   fp.close()
  except:
   bvswWedxIVFLUDGpoEghmlJnXKCyaA
 def dp_Watch_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyTR =bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('stype')
  bvswWedxIVFLUDGpoEghmlJnXKCyOa=bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_settings_direct_replay()
  if bvswWedxIVFLUDGpoEghmlJnXKCyTR=='-':
   for bvswWedxIVFLUDGpoEghmlJnXKCyTS in bvswWedxIVFLUDGpoEghmlJnXKCyQY:
    bvswWedxIVFLUDGpoEghmlJnXKCyOB=bvswWedxIVFLUDGpoEghmlJnXKCyTS.get('title')
    bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':bvswWedxIVFLUDGpoEghmlJnXKCyTS.get('mode'),'stype':bvswWedxIVFLUDGpoEghmlJnXKCyTS.get('stype')}
    bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel='',img='',infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyaA,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaM,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt)
   if bvswWedxIVFLUDGpoEghmlJnXKCyaN(bvswWedxIVFLUDGpoEghmlJnXKCyQY)>0:xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle)
  else:
   bvswWedxIVFLUDGpoEghmlJnXKCyjH=bvswWedxIVFLUDGpoEghmlJnXKCyQB.Load_List_File(bvswWedxIVFLUDGpoEghmlJnXKCyTR)
   for bvswWedxIVFLUDGpoEghmlJnXKCyjc in bvswWedxIVFLUDGpoEghmlJnXKCyjH:
    bvswWedxIVFLUDGpoEghmlJnXKCyYr=bvswWedxIVFLUDGpoEghmlJnXKCyaz(urllib.parse.parse_qsl(bvswWedxIVFLUDGpoEghmlJnXKCyjc))
    bvswWedxIVFLUDGpoEghmlJnXKCyjk =bvswWedxIVFLUDGpoEghmlJnXKCyYr.get('code').strip()
    bvswWedxIVFLUDGpoEghmlJnXKCyOB =bvswWedxIVFLUDGpoEghmlJnXKCyYr.get('title').strip()
    bvswWedxIVFLUDGpoEghmlJnXKCyTc=bvswWedxIVFLUDGpoEghmlJnXKCyYr.get('img').strip()
    bvswWedxIVFLUDGpoEghmlJnXKCyYA =bvswWedxIVFLUDGpoEghmlJnXKCyYr.get('videoid').strip()
    try:
     bvswWedxIVFLUDGpoEghmlJnXKCyTc=bvswWedxIVFLUDGpoEghmlJnXKCyTc.replace('\'','\"')
     bvswWedxIVFLUDGpoEghmlJnXKCyTc=bvswWedxIVFLUDGpoEghmlJnXKCyAi.loads(bvswWedxIVFLUDGpoEghmlJnXKCyTc)
    except:
     bvswWedxIVFLUDGpoEghmlJnXKCyaA
    bvswWedxIVFLUDGpoEghmlJnXKCyfT={}
    bvswWedxIVFLUDGpoEghmlJnXKCyfT['plot']=bvswWedxIVFLUDGpoEghmlJnXKCyOB
    if bvswWedxIVFLUDGpoEghmlJnXKCyTR=='vod':
     if bvswWedxIVFLUDGpoEghmlJnXKCyOa==bvswWedxIVFLUDGpoEghmlJnXKCyaS or bvswWedxIVFLUDGpoEghmlJnXKCyYA==bvswWedxIVFLUDGpoEghmlJnXKCyaA:
      bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':'EPISODE','programcode':bvswWedxIVFLUDGpoEghmlJnXKCyjk,'page':'1'}
      bvswWedxIVFLUDGpoEghmlJnXKCyOq=bvswWedxIVFLUDGpoEghmlJnXKCyaM
     else:
      bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':'VOD','mediacode':bvswWedxIVFLUDGpoEghmlJnXKCyYA,'stype':'vod','programcode':bvswWedxIVFLUDGpoEghmlJnXKCyjk,'title':bvswWedxIVFLUDGpoEghmlJnXKCyOB,'thumbnail':bvswWedxIVFLUDGpoEghmlJnXKCyTc}
      bvswWedxIVFLUDGpoEghmlJnXKCyOq=bvswWedxIVFLUDGpoEghmlJnXKCyaS
    else:
     bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':'MOVIE','mediacode':bvswWedxIVFLUDGpoEghmlJnXKCyjk,'stype':'movie','title':bvswWedxIVFLUDGpoEghmlJnXKCyOB,'thumbnail':bvswWedxIVFLUDGpoEghmlJnXKCyTc}
     bvswWedxIVFLUDGpoEghmlJnXKCyOq=bvswWedxIVFLUDGpoEghmlJnXKCyaS
    bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel='',img=bvswWedxIVFLUDGpoEghmlJnXKCyTc,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyfT,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyOq,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt)
   bvswWedxIVFLUDGpoEghmlJnXKCyfT={'plot':'시청목록을 삭제합니다.'}
   bvswWedxIVFLUDGpoEghmlJnXKCyOB='*** 시청목록 삭제 ***'
   bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':'MYVIEW_REMOVE','stype':bvswWedxIVFLUDGpoEghmlJnXKCyTR,'skey':'-',}
   bvswWedxIVFLUDGpoEghmlJnXKCyOk=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel='',img=bvswWedxIVFLUDGpoEghmlJnXKCyOk,infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyfT,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaS,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt,isLink=bvswWedxIVFLUDGpoEghmlJnXKCyaM)
   if bvswWedxIVFLUDGpoEghmlJnXKCyTR=='movie':xbmcplugin.setContent(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,'movies')
   else:xbmcplugin.setContent(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,cacheToDisc=bvswWedxIVFLUDGpoEghmlJnXKCyaS)
 def Save_Searched_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyYz):
  try:
   bvswWedxIVFLUDGpoEghmlJnXKCyjt=bvswWedxIVFLUDGpoEghmlJnXKCyQS
   bvswWedxIVFLUDGpoEghmlJnXKCyjY=bvswWedxIVFLUDGpoEghmlJnXKCyQB.Load_List_File('search') 
   bvswWedxIVFLUDGpoEghmlJnXKCyjq={'skey':bvswWedxIVFLUDGpoEghmlJnXKCyYz.strip()}
   fp=bvswWedxIVFLUDGpoEghmlJnXKCyac(bvswWedxIVFLUDGpoEghmlJnXKCyjt,'w',-1,'utf-8')
   bvswWedxIVFLUDGpoEghmlJnXKCyjB=urllib.parse.urlencode(bvswWedxIVFLUDGpoEghmlJnXKCyjq)
   bvswWedxIVFLUDGpoEghmlJnXKCyjB=bvswWedxIVFLUDGpoEghmlJnXKCyjB+'\n'
   fp.write(bvswWedxIVFLUDGpoEghmlJnXKCyjB)
   bvswWedxIVFLUDGpoEghmlJnXKCyjz=0
   for bvswWedxIVFLUDGpoEghmlJnXKCyjA in bvswWedxIVFLUDGpoEghmlJnXKCyjY:
    bvswWedxIVFLUDGpoEghmlJnXKCyja=bvswWedxIVFLUDGpoEghmlJnXKCyaz(urllib.parse.parse_qsl(bvswWedxIVFLUDGpoEghmlJnXKCyjA))
    bvswWedxIVFLUDGpoEghmlJnXKCyjN=bvswWedxIVFLUDGpoEghmlJnXKCyjq.get('skey').strip()
    bvswWedxIVFLUDGpoEghmlJnXKCyjP=bvswWedxIVFLUDGpoEghmlJnXKCyja.get('skey').strip()
    if bvswWedxIVFLUDGpoEghmlJnXKCyjN!=bvswWedxIVFLUDGpoEghmlJnXKCyjP:
     fp.write(bvswWedxIVFLUDGpoEghmlJnXKCyjA)
     bvswWedxIVFLUDGpoEghmlJnXKCyjz+=1
     if bvswWedxIVFLUDGpoEghmlJnXKCyjz>=50:break
   fp.close()
  except:
   bvswWedxIVFLUDGpoEghmlJnXKCyaA
 def play_VIDEO(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.SaveCredential(bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_winCredential())
  bvswWedxIVFLUDGpoEghmlJnXKCyjr =bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('mediacode')
  bvswWedxIVFLUDGpoEghmlJnXKCyTR =bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('stype')
  bvswWedxIVFLUDGpoEghmlJnXKCyju =bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('pvrmode')
  bvswWedxIVFLUDGpoEghmlJnXKCyji=bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_selQuality(bvswWedxIVFLUDGpoEghmlJnXKCyTR)
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.addon_log('mediacode, quality_int, stype, pvrmode : %s - %s - %s - %s'%(bvswWedxIVFLUDGpoEghmlJnXKCyjr,bvswWedxIVFLUDGpoEghmlJnXKCyaP(bvswWedxIVFLUDGpoEghmlJnXKCyji),bvswWedxIVFLUDGpoEghmlJnXKCyTR,bvswWedxIVFLUDGpoEghmlJnXKCyju))
  bvswWedxIVFLUDGpoEghmlJnXKCyAQ,bvswWedxIVFLUDGpoEghmlJnXKCyAO=bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.GetBroadURL(bvswWedxIVFLUDGpoEghmlJnXKCyjr,bvswWedxIVFLUDGpoEghmlJnXKCyji,bvswWedxIVFLUDGpoEghmlJnXKCyTR,bvswWedxIVFLUDGpoEghmlJnXKCyju)
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.addon_log('qt, stype, url : %s - %s - %s'%(bvswWedxIVFLUDGpoEghmlJnXKCyaP(bvswWedxIVFLUDGpoEghmlJnXKCyji),bvswWedxIVFLUDGpoEghmlJnXKCyTR,bvswWedxIVFLUDGpoEghmlJnXKCyAQ))
  if bvswWedxIVFLUDGpoEghmlJnXKCyAQ=='':
   if bvswWedxIVFLUDGpoEghmlJnXKCyAO=='':
    bvswWedxIVFLUDGpoEghmlJnXKCyQB.addon_noti(__language__(30908).encode('utf8'))
   else:
    bvswWedxIVFLUDGpoEghmlJnXKCyQB.addon_noti(bvswWedxIVFLUDGpoEghmlJnXKCyAO.encode('utf8'))
   return
  bvswWedxIVFLUDGpoEghmlJnXKCyAT =bvswWedxIVFLUDGpoEghmlJnXKCyaS
  bvswWedxIVFLUDGpoEghmlJnXKCyAf =bvswWedxIVFLUDGpoEghmlJnXKCyAQ.find('Policy=')
  if bvswWedxIVFLUDGpoEghmlJnXKCyAf!=-1:
   bvswWedxIVFLUDGpoEghmlJnXKCyAY =bvswWedxIVFLUDGpoEghmlJnXKCyAQ.split('?')[0]
   bvswWedxIVFLUDGpoEghmlJnXKCyAj=bvswWedxIVFLUDGpoEghmlJnXKCyaz(urllib.parse.parse_qsl(urllib.parse.urlsplit(bvswWedxIVFLUDGpoEghmlJnXKCyAQ).query))
   bvswWedxIVFLUDGpoEghmlJnXKCyAa='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(bvswWedxIVFLUDGpoEghmlJnXKCyAj['Policy'],bvswWedxIVFLUDGpoEghmlJnXKCyAj['Signature'],bvswWedxIVFLUDGpoEghmlJnXKCyAj['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in bvswWedxIVFLUDGpoEghmlJnXKCyAY:
    bvswWedxIVFLUDGpoEghmlJnXKCyAT=bvswWedxIVFLUDGpoEghmlJnXKCyaM
    bvswWedxIVFLUDGpoEghmlJnXKCyAR =bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    bvswWedxIVFLUDGpoEghmlJnXKCyAM=bvswWedxIVFLUDGpoEghmlJnXKCyAR.strftime('%Y-%m-%d-%H:%M:%S')
    if bvswWedxIVFLUDGpoEghmlJnXKCyaR(bvswWedxIVFLUDGpoEghmlJnXKCyAM.replace('-','').replace(':',''))<bvswWedxIVFLUDGpoEghmlJnXKCyaR(bvswWedxIVFLUDGpoEghmlJnXKCyAj['end'].replace('-','').replace(':','')):
     bvswWedxIVFLUDGpoEghmlJnXKCyAj['end']=bvswWedxIVFLUDGpoEghmlJnXKCyAM
     bvswWedxIVFLUDGpoEghmlJnXKCyQB.addon_noti(__language__(30915).encode('utf8'))
    bvswWedxIVFLUDGpoEghmlJnXKCyAY ='%s?%s'%(bvswWedxIVFLUDGpoEghmlJnXKCyAY,urllib.parse.urlencode(bvswWedxIVFLUDGpoEghmlJnXKCyAj,doseq=bvswWedxIVFLUDGpoEghmlJnXKCyaM))
   bvswWedxIVFLUDGpoEghmlJnXKCyAS='%s|Cookie=%s'%(bvswWedxIVFLUDGpoEghmlJnXKCyAY,bvswWedxIVFLUDGpoEghmlJnXKCyAa)
  else:
   bvswWedxIVFLUDGpoEghmlJnXKCyAS=bvswWedxIVFLUDGpoEghmlJnXKCyAQ
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.addon_log(bvswWedxIVFLUDGpoEghmlJnXKCyAS)
  bvswWedxIVFLUDGpoEghmlJnXKCyAB=xbmcgui.ListItem(path=bvswWedxIVFLUDGpoEghmlJnXKCyAS)
  if bvswWedxIVFLUDGpoEghmlJnXKCyAO!='':
   bvswWedxIVFLUDGpoEghmlJnXKCyAz=bvswWedxIVFLUDGpoEghmlJnXKCyAO
   bvswWedxIVFLUDGpoEghmlJnXKCyAN ='https://cj.drmkeyserver.com/widevine_license'
   bvswWedxIVFLUDGpoEghmlJnXKCyAP ='mpd'
   bvswWedxIVFLUDGpoEghmlJnXKCyAH ='com.widevine.alpha'
   bvswWedxIVFLUDGpoEghmlJnXKCyAc =inputstreamhelper.Helper(bvswWedxIVFLUDGpoEghmlJnXKCyAP,drm='widevine')
   if bvswWedxIVFLUDGpoEghmlJnXKCyAc.check_inputstream():
    bvswWedxIVFLUDGpoEghmlJnXKCyAk={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%bvswWedxIVFLUDGpoEghmlJnXKCyjr,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.USER_AGENT,'AcquireLicenseAssertion':bvswWedxIVFLUDGpoEghmlJnXKCyAz,'Host':'cj.drmkeyserver.com'}
    bvswWedxIVFLUDGpoEghmlJnXKCyAt=bvswWedxIVFLUDGpoEghmlJnXKCyAN+'|'+urllib.parse.urlencode(bvswWedxIVFLUDGpoEghmlJnXKCyAk)+'|R{SSM}|'
    bvswWedxIVFLUDGpoEghmlJnXKCyAB.setProperty('inputstream',bvswWedxIVFLUDGpoEghmlJnXKCyAc.inputstream_addon)
    bvswWedxIVFLUDGpoEghmlJnXKCyAB.setProperty('inputstream.adaptive.manifest_type',bvswWedxIVFLUDGpoEghmlJnXKCyAP)
    bvswWedxIVFLUDGpoEghmlJnXKCyAB.setProperty('inputstream.adaptive.license_type',bvswWedxIVFLUDGpoEghmlJnXKCyAH)
    bvswWedxIVFLUDGpoEghmlJnXKCyAB.setProperty('inputstream.adaptive.license_key',bvswWedxIVFLUDGpoEghmlJnXKCyAt)
    bvswWedxIVFLUDGpoEghmlJnXKCyAB.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.USER_AGENT))
  elif bvswWedxIVFLUDGpoEghmlJnXKCyAT==bvswWedxIVFLUDGpoEghmlJnXKCyaM:
   bvswWedxIVFLUDGpoEghmlJnXKCyAB.setContentLookup(bvswWedxIVFLUDGpoEghmlJnXKCyaS)
   bvswWedxIVFLUDGpoEghmlJnXKCyAB.setMimeType('application/x-mpegURL')
   bvswWedxIVFLUDGpoEghmlJnXKCyAB.setProperty('inputstream','inputstream.ffmpegdirect')
   bvswWedxIVFLUDGpoEghmlJnXKCyAB.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   bvswWedxIVFLUDGpoEghmlJnXKCyAB.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   bvswWedxIVFLUDGpoEghmlJnXKCyAB.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   bvswWedxIVFLUDGpoEghmlJnXKCyAB.setProperty('ResumeTime','0')
   bvswWedxIVFLUDGpoEghmlJnXKCyAB.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,bvswWedxIVFLUDGpoEghmlJnXKCyaM,bvswWedxIVFLUDGpoEghmlJnXKCyAB)
  try:
   if bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('mode')in['VOD','MOVIE']and bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('title'):
    bvswWedxIVFLUDGpoEghmlJnXKCyOt={'code':bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('programcode')if bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('mode')=='VOD' else bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('mediacode'),'img':bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('thumbnail'),'title':bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('title'),'videoid':bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('mediacode')}
    bvswWedxIVFLUDGpoEghmlJnXKCyQB.Save_Watched_List(bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('stype'),bvswWedxIVFLUDGpoEghmlJnXKCyOt)
  except:
   bvswWedxIVFLUDGpoEghmlJnXKCyaA
 def logout(bvswWedxIVFLUDGpoEghmlJnXKCyQB):
  bvswWedxIVFLUDGpoEghmlJnXKCyQc=xbmcgui.Dialog()
  bvswWedxIVFLUDGpoEghmlJnXKCyTY=bvswWedxIVFLUDGpoEghmlJnXKCyQc.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if bvswWedxIVFLUDGpoEghmlJnXKCyTY==bvswWedxIVFLUDGpoEghmlJnXKCyaS:sys.exit()
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.wininfo_clear()
  if os.path.isfile(bvswWedxIVFLUDGpoEghmlJnXKCyQM):os.remove(bvswWedxIVFLUDGpoEghmlJnXKCyQM)
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(bvswWedxIVFLUDGpoEghmlJnXKCyQB):
  bvswWedxIVFLUDGpoEghmlJnXKCyOR=xbmcgui.Window(10000)
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_TOKEN','')
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_USERINFO','')
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_UUID','')
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_LOGINTIME','')
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_MAINTOKEN','')
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_COOKIEKEY','')
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(bvswWedxIVFLUDGpoEghmlJnXKCyQB):
  bvswWedxIVFLUDGpoEghmlJnXKCyAq =bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.Get_Now_Datetime()
  bvswWedxIVFLUDGpoEghmlJnXKCyAr=bvswWedxIVFLUDGpoEghmlJnXKCyAq+datetime.timedelta(days=bvswWedxIVFLUDGpoEghmlJnXKCyaR(__addon__.getSetting('cache_ttl')))
  bvswWedxIVFLUDGpoEghmlJnXKCyOR=xbmcgui.Window(10000)
  bvswWedxIVFLUDGpoEghmlJnXKCyAu={'tving_token':bvswWedxIVFLUDGpoEghmlJnXKCyOR.getProperty('TVING_M_TOKEN'),'tving_userinfo':bvswWedxIVFLUDGpoEghmlJnXKCyOR.getProperty('TVING_M_USERINFO'),'tving_uuid':bvswWedxIVFLUDGpoEghmlJnXKCyOR.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':bvswWedxIVFLUDGpoEghmlJnXKCyAr.strftime('%Y-%m-%d'),'tving_maintoken':bvswWedxIVFLUDGpoEghmlJnXKCyOR.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':bvswWedxIVFLUDGpoEghmlJnXKCyOR.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':bvswWedxIVFLUDGpoEghmlJnXKCyOR.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=bvswWedxIVFLUDGpoEghmlJnXKCyac(bvswWedxIVFLUDGpoEghmlJnXKCyQM,'w',-1,'utf-8')
   bvswWedxIVFLUDGpoEghmlJnXKCyAi.dump(bvswWedxIVFLUDGpoEghmlJnXKCyAu,fp,indent=4,ensure_ascii=bvswWedxIVFLUDGpoEghmlJnXKCyaS)
   fp.close()
  except bvswWedxIVFLUDGpoEghmlJnXKCyak as exception:
   bvswWedxIVFLUDGpoEghmlJnXKCyat(exception)
 def cookiefile_check(bvswWedxIVFLUDGpoEghmlJnXKCyQB):
  bvswWedxIVFLUDGpoEghmlJnXKCyAu={}
  try: 
   fp=bvswWedxIVFLUDGpoEghmlJnXKCyac(bvswWedxIVFLUDGpoEghmlJnXKCyQM,'r',-1,'utf-8')
   bvswWedxIVFLUDGpoEghmlJnXKCyAu= bvswWedxIVFLUDGpoEghmlJnXKCyAi.load(fp)
   fp.close()
  except bvswWedxIVFLUDGpoEghmlJnXKCyak as exception:
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.wininfo_clear()
   return bvswWedxIVFLUDGpoEghmlJnXKCyaS
  bvswWedxIVFLUDGpoEghmlJnXKCyOi =__addon__.getSetting('id')
  bvswWedxIVFLUDGpoEghmlJnXKCyTQ =__addon__.getSetting('pw')
  bvswWedxIVFLUDGpoEghmlJnXKCyaO=__addon__.getSetting('login_type')
  bvswWedxIVFLUDGpoEghmlJnXKCyaT =__addon__.getSetting('selected_profile')
  bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_id']=base64.standard_b64decode(bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_id']).decode('utf-8')
  bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_pw']=base64.standard_b64decode(bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_pw']).decode('utf-8')
  try:
   bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_profile']
  except:
   bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_profile']='0'
  if bvswWedxIVFLUDGpoEghmlJnXKCyOi!=bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_id']or bvswWedxIVFLUDGpoEghmlJnXKCyTQ!=bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_pw']or bvswWedxIVFLUDGpoEghmlJnXKCyaO!=bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_logintype']or bvswWedxIVFLUDGpoEghmlJnXKCyaT!=bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_profile']or bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_token']=='':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.wininfo_clear()
   return bvswWedxIVFLUDGpoEghmlJnXKCyaS
  bvswWedxIVFLUDGpoEghmlJnXKCyTj =bvswWedxIVFLUDGpoEghmlJnXKCyaR(bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  bvswWedxIVFLUDGpoEghmlJnXKCyaf=bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_limitdate']
  bvswWedxIVFLUDGpoEghmlJnXKCyTA =bvswWedxIVFLUDGpoEghmlJnXKCyaR(re.sub('-','',bvswWedxIVFLUDGpoEghmlJnXKCyaf))
  if bvswWedxIVFLUDGpoEghmlJnXKCyTA<bvswWedxIVFLUDGpoEghmlJnXKCyTj:
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.wininfo_clear()
   return bvswWedxIVFLUDGpoEghmlJnXKCyaS
  bvswWedxIVFLUDGpoEghmlJnXKCyOR=xbmcgui.Window(10000)
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_TOKEN',bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_token'])
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_USERINFO',bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_userinfo'])
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_UUID',bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_uuid'])
  bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_LOGINTIME',bvswWedxIVFLUDGpoEghmlJnXKCyaf)
  try:
   bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_MAINTOKEN',bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_maintoken'])
   bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_COOKIEKEY',bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_cookiekey'])
   bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_LOCKKEY',bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_lockkey'])
  except:
   bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_MAINTOKEN',bvswWedxIVFLUDGpoEghmlJnXKCyAu['tving_token'])
   bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_COOKIEKEY','Y')
   bvswWedxIVFLUDGpoEghmlJnXKCyOR.setProperty('TVING_M_LOCKKEY','N')
  return bvswWedxIVFLUDGpoEghmlJnXKCyaM
 def dp_Global_Search(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyYN=bvswWedxIVFLUDGpoEghmlJnXKCyTB.get('mode')
  if bvswWedxIVFLUDGpoEghmlJnXKCyYN=='TOTAL_SEARCH':
   bvswWedxIVFLUDGpoEghmlJnXKCyaY='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   bvswWedxIVFLUDGpoEghmlJnXKCyaY='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(bvswWedxIVFLUDGpoEghmlJnXKCyaY)
 def dp_Bookmark_Menu(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyaY='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(bvswWedxIVFLUDGpoEghmlJnXKCyaY)
 def dp_EuroLive_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB,bvswWedxIVFLUDGpoEghmlJnXKCyTB):
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.SaveCredential(bvswWedxIVFLUDGpoEghmlJnXKCyQB.get_winCredential())
  bvswWedxIVFLUDGpoEghmlJnXKCyTN=bvswWedxIVFLUDGpoEghmlJnXKCyQB.TvingObj.GetEuroChannelList()
  for bvswWedxIVFLUDGpoEghmlJnXKCyTH in bvswWedxIVFLUDGpoEghmlJnXKCyTN:
   bvswWedxIVFLUDGpoEghmlJnXKCyfS =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('channel')
   bvswWedxIVFLUDGpoEghmlJnXKCyOB =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('title')
   bvswWedxIVFLUDGpoEghmlJnXKCyfY =bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('subtitle')
   bvswWedxIVFLUDGpoEghmlJnXKCyfT={'mediatype':'episode','title':bvswWedxIVFLUDGpoEghmlJnXKCyOB,'plot':'%s\n%s'%(bvswWedxIVFLUDGpoEghmlJnXKCyOB,bvswWedxIVFLUDGpoEghmlJnXKCyfY)}
   bvswWedxIVFLUDGpoEghmlJnXKCyOt={'mode':'LIVE','mediacode':bvswWedxIVFLUDGpoEghmlJnXKCyTH.get('channel'),'stype':'onair',}
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.add_dir(bvswWedxIVFLUDGpoEghmlJnXKCyOB,sublabel=bvswWedxIVFLUDGpoEghmlJnXKCyfY,img='',infoLabels=bvswWedxIVFLUDGpoEghmlJnXKCyfT,isFolder=bvswWedxIVFLUDGpoEghmlJnXKCyaS,params=bvswWedxIVFLUDGpoEghmlJnXKCyOt)
  if bvswWedxIVFLUDGpoEghmlJnXKCyaN(bvswWedxIVFLUDGpoEghmlJnXKCyTN)>0:xbmcplugin.endOfDirectory(bvswWedxIVFLUDGpoEghmlJnXKCyQB._addon_handle,cacheToDisc=bvswWedxIVFLUDGpoEghmlJnXKCyaS)
 def tving_main(bvswWedxIVFLUDGpoEghmlJnXKCyQB):
  bvswWedxIVFLUDGpoEghmlJnXKCyYN=bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params.get('mode',bvswWedxIVFLUDGpoEghmlJnXKCyaA)
  if bvswWedxIVFLUDGpoEghmlJnXKCyYN=='LOGOUT':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.logout()
   return
  bvswWedxIVFLUDGpoEghmlJnXKCyQB.login_main()
  if bvswWedxIVFLUDGpoEghmlJnXKCyYN is bvswWedxIVFLUDGpoEghmlJnXKCyaA:
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_Main_List()
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_Title_Group(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN in['GLOBAL_GROUP']:
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_SubTitle_Group(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN=='CHANNEL':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_LiveChannel_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN in['LIVE','VOD','MOVIE']:
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.play_VIDEO(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN=='PROGRAM':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_Program_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN=='EPISODE':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_Episode_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN=='MOVIE_SUB':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_Movie_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN=='SEARCH_GROUP':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_Search_Group(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN in['SEARCH','LOCAL_SEARCH']:
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_Search_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN=='WATCH':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_Watch_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_Listfile_Delete(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN=='ORDER_BY':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_setEpOrderby(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN=='SET_BOOKMARK':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_Set_Bookmark(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN in['TOTAL_SEARCH','TOTAL_HISTORY']:
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_Global_Search(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN=='SEARCH_HISTORY':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_Search_History(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN=='MENU_BOOKMARK':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_Bookmark_Menu(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  elif bvswWedxIVFLUDGpoEghmlJnXKCyYN=='EURO_GROUP':
   bvswWedxIVFLUDGpoEghmlJnXKCyQB.dp_EuroLive_List(bvswWedxIVFLUDGpoEghmlJnXKCyQB.main_params)
  else:
   bvswWedxIVFLUDGpoEghmlJnXKCyaA
# Created by pyminifier (https://github.com/liftoff/pyminifier)
