__author__="NightRain"
nbTvDjESpRtQJCGUkuircyoedzqglw=ImportError
nbTvDjESpRtQJCGUkuircyoedzqglM=object
nbTvDjESpRtQJCGUkuircyoedzqgla=None
nbTvDjESpRtQJCGUkuircyoedzqgls=False
nbTvDjESpRtQJCGUkuircyoedzqglx=int
nbTvDjESpRtQJCGUkuircyoedzqglX=range
nbTvDjESpRtQJCGUkuircyoedzqglI=True
nbTvDjESpRtQJCGUkuircyoedzqglL=print
nbTvDjESpRtQJCGUkuircyoedzqglO=Exception
nbTvDjESpRtQJCGUkuircyoedzqglA=str
nbTvDjESpRtQJCGUkuircyoedzqglY=list
nbTvDjESpRtQJCGUkuircyoedzqgKF=len
nbTvDjESpRtQJCGUkuircyoedzqgKW=bytes
nbTvDjESpRtQJCGUkuircyoedzqgKV=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
try:
 from Cryptodome.PublicKey import RSA
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
except nbTvDjESpRtQJCGUkuircyoedzqglw:
 from Crypto.PublicKey import RSA
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
nbTvDjESpRtQJCGUkuircyoedzqgFV={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
nbTvDjESpRtQJCGUkuircyoedzqgFm ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class nbTvDjESpRtQJCGUkuircyoedzqgFW(nbTvDjESpRtQJCGUkuircyoedzqglM):
 def __init__(nbTvDjESpRtQJCGUkuircyoedzqgFP):
  nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_TOKEN =''
  nbTvDjESpRtQJCGUkuircyoedzqgFP.POC_USERINFO =''
  nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_UUID ='-'
  nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_MAINTOKEN=''
  nbTvDjESpRtQJCGUkuircyoedzqgFP.TVIGN_COOKIEKEY=''
  nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_LOCKKEY =''
  nbTvDjESpRtQJCGUkuircyoedzqgFP.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  nbTvDjESpRtQJCGUkuircyoedzqgFP.NETWORKCODE ='CSND0900'
  nbTvDjESpRtQJCGUkuircyoedzqgFP.OSCODE ='CSOD0900' 
  nbTvDjESpRtQJCGUkuircyoedzqgFP.TELECODE ='CSCD0900'
  nbTvDjESpRtQJCGUkuircyoedzqgFP.SCREENCODE ='CSSD0100'
  nbTvDjESpRtQJCGUkuircyoedzqgFP.LIVE_LIMIT =23
  nbTvDjESpRtQJCGUkuircyoedzqgFP.VOD_LIMIT =20
  nbTvDjESpRtQJCGUkuircyoedzqgFP.EPISODE_LIMIT =30 
  nbTvDjESpRtQJCGUkuircyoedzqgFP.SEARCH_LIMIT =30 
  nbTvDjESpRtQJCGUkuircyoedzqgFP.MOVIE_LIMIT =18
  nbTvDjESpRtQJCGUkuircyoedzqgFP.API_DOMAIN ='https://api.tving.com'
  nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN ='https://image.tving.com'
  nbTvDjESpRtQJCGUkuircyoedzqgFP.SEARCH_DOMAIN ='https://search.tving.com'
  nbTvDjESpRtQJCGUkuircyoedzqgFP.LOGIN_DOMAIN ='https://user.tving.com'
  nbTvDjESpRtQJCGUkuircyoedzqgFP.URL_DOMAIN ='https://www.tving.com'
  nbTvDjESpRtQJCGUkuircyoedzqgFP.MOVIE_LITE =['2610061','2610161','261062']
  nbTvDjESpRtQJCGUkuircyoedzqgFP.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  nbTvDjESpRtQJCGUkuircyoedzqgFP.DEFAULT_HEADER ={'user-agent':nbTvDjESpRtQJCGUkuircyoedzqgFP.USER_AGENT}
  nbTvDjESpRtQJCGUkuircyoedzqgFP.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(nbTvDjESpRtQJCGUkuircyoedzqgFP,jobtype,nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgla,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgla,redirects=nbTvDjESpRtQJCGUkuircyoedzqgls):
  nbTvDjESpRtQJCGUkuircyoedzqgFl=nbTvDjESpRtQJCGUkuircyoedzqgFP.DEFAULT_HEADER
  if headers:nbTvDjESpRtQJCGUkuircyoedzqgFl.update(headers)
  if jobtype=='Get':
   nbTvDjESpRtQJCGUkuircyoedzqgFK=requests.get(nbTvDjESpRtQJCGUkuircyoedzqgWa,params=params,headers=nbTvDjESpRtQJCGUkuircyoedzqgFl,cookies=cookies,allow_redirects=redirects)
  else:
   nbTvDjESpRtQJCGUkuircyoedzqgFK=requests.post(nbTvDjESpRtQJCGUkuircyoedzqgWa,data=payload,params=params,headers=nbTvDjESpRtQJCGUkuircyoedzqgFl,cookies=cookies,allow_redirects=redirects)
  return nbTvDjESpRtQJCGUkuircyoedzqgFK
 def makeDefaultCookies(nbTvDjESpRtQJCGUkuircyoedzqgFP,vToken=nbTvDjESpRtQJCGUkuircyoedzqgla,vUserinfo=nbTvDjESpRtQJCGUkuircyoedzqgla):
  nbTvDjESpRtQJCGUkuircyoedzqgFh={}
  nbTvDjESpRtQJCGUkuircyoedzqgFh['_tving_token']=nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_TOKEN if vToken==nbTvDjESpRtQJCGUkuircyoedzqgla else vToken
  nbTvDjESpRtQJCGUkuircyoedzqgFh['POC_USERINFO']=nbTvDjESpRtQJCGUkuircyoedzqgFP.POC_USERINFO if vToken==nbTvDjESpRtQJCGUkuircyoedzqgla else vUserinfo
  if nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_MAINTOKEN!='':nbTvDjESpRtQJCGUkuircyoedzqgFh[nbTvDjESpRtQJCGUkuircyoedzqgFP.GLOBAL_COOKIENM['tv_maintoken']]=nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_MAINTOKEN
  if nbTvDjESpRtQJCGUkuircyoedzqgFP.TVIGN_COOKIEKEY!='':nbTvDjESpRtQJCGUkuircyoedzqgFh[nbTvDjESpRtQJCGUkuircyoedzqgFP.GLOBAL_COOKIENM['tv_cookiekey']]=nbTvDjESpRtQJCGUkuircyoedzqgFP.TVIGN_COOKIEKEY
  if nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_LOCKKEY !='':nbTvDjESpRtQJCGUkuircyoedzqgFh[nbTvDjESpRtQJCGUkuircyoedzqgFP.GLOBAL_COOKIENM['tv_lockkey']] =nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_LOCKKEY
  return nbTvDjESpRtQJCGUkuircyoedzqgFh
 def getDeviceStr(nbTvDjESpRtQJCGUkuircyoedzqgFP):
  nbTvDjESpRtQJCGUkuircyoedzqgFf=[]
  nbTvDjESpRtQJCGUkuircyoedzqgFf.append('Windows') 
  nbTvDjESpRtQJCGUkuircyoedzqgFf.append('Chrome') 
  nbTvDjESpRtQJCGUkuircyoedzqgFf.append('ko-KR') 
  nbTvDjESpRtQJCGUkuircyoedzqgFf.append('undefined') 
  nbTvDjESpRtQJCGUkuircyoedzqgFf.append('24') 
  nbTvDjESpRtQJCGUkuircyoedzqgFf.append(u'한국 표준시')
  nbTvDjESpRtQJCGUkuircyoedzqgFf.append('undefined') 
  nbTvDjESpRtQJCGUkuircyoedzqgFf.append('undefined') 
  nbTvDjESpRtQJCGUkuircyoedzqgFf.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  nbTvDjESpRtQJCGUkuircyoedzqgFH=''
  for nbTvDjESpRtQJCGUkuircyoedzqgFB in nbTvDjESpRtQJCGUkuircyoedzqgFf:
   nbTvDjESpRtQJCGUkuircyoedzqgFH+=nbTvDjESpRtQJCGUkuircyoedzqgFB+'|'
  return nbTvDjESpRtQJCGUkuircyoedzqgFH
 def SaveCredential(nbTvDjESpRtQJCGUkuircyoedzqgFP,nbTvDjESpRtQJCGUkuircyoedzqgFN):
  nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_TOKEN =nbTvDjESpRtQJCGUkuircyoedzqgFN.get('tving_token')
  nbTvDjESpRtQJCGUkuircyoedzqgFP.POC_USERINFO =nbTvDjESpRtQJCGUkuircyoedzqgFN.get('poc_userinfo')
  nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_UUID =nbTvDjESpRtQJCGUkuircyoedzqgFN.get('tving_uuid')
  nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_MAINTOKEN=nbTvDjESpRtQJCGUkuircyoedzqgFN.get('tving_maintoken')
  nbTvDjESpRtQJCGUkuircyoedzqgFP.TVIGN_COOKIEKEY=nbTvDjESpRtQJCGUkuircyoedzqgFN.get('tving_cookiekey')
  nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_LOCKKEY =nbTvDjESpRtQJCGUkuircyoedzqgFN.get('tving_lockkey')
 def LoadCredential(nbTvDjESpRtQJCGUkuircyoedzqgFP):
  nbTvDjESpRtQJCGUkuircyoedzqgFN={'tving_token':nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_TOKEN,'poc_userinfo':nbTvDjESpRtQJCGUkuircyoedzqgFP.POC_USERINFO,'tving_uuid':nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_UUID,'tving_maintoken':nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_MAINTOKEN,'tving_cookiekey':nbTvDjESpRtQJCGUkuircyoedzqgFP.TVIGN_COOKIEKEY,'tving_lockkey':nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_LOCKKEY}
  return nbTvDjESpRtQJCGUkuircyoedzqgFN
 def GetDefaultParams(nbTvDjESpRtQJCGUkuircyoedzqgFP):
  nbTvDjESpRtQJCGUkuircyoedzqgFw={'apiKey':nbTvDjESpRtQJCGUkuircyoedzqgFP.APIKEY,'networkCode':nbTvDjESpRtQJCGUkuircyoedzqgFP.NETWORKCODE,'osCode':nbTvDjESpRtQJCGUkuircyoedzqgFP.OSCODE,'teleCode':nbTvDjESpRtQJCGUkuircyoedzqgFP.TELECODE,'screenCode':nbTvDjESpRtQJCGUkuircyoedzqgFP.SCREENCODE}
  return nbTvDjESpRtQJCGUkuircyoedzqgFw
 def GetNoCache(nbTvDjESpRtQJCGUkuircyoedzqgFP,timetype=1):
  if timetype==1:
   return nbTvDjESpRtQJCGUkuircyoedzqglx(time.time())
  else:
   return nbTvDjESpRtQJCGUkuircyoedzqglx(time.time()*1000)
 def GetUniqueid(nbTvDjESpRtQJCGUkuircyoedzqgFP):
  nbTvDjESpRtQJCGUkuircyoedzqgFM=[0 for i in nbTvDjESpRtQJCGUkuircyoedzqglX(256)]
  for i in nbTvDjESpRtQJCGUkuircyoedzqglX(256):
   nbTvDjESpRtQJCGUkuircyoedzqgFM[i]='%02x'%(i)
  nbTvDjESpRtQJCGUkuircyoedzqgFa=nbTvDjESpRtQJCGUkuircyoedzqglx(4294967295*random.random())|0
  nbTvDjESpRtQJCGUkuircyoedzqgFs=nbTvDjESpRtQJCGUkuircyoedzqgFM[255&nbTvDjESpRtQJCGUkuircyoedzqgFa]+nbTvDjESpRtQJCGUkuircyoedzqgFM[nbTvDjESpRtQJCGUkuircyoedzqgFa>>8&255]+nbTvDjESpRtQJCGUkuircyoedzqgFM[nbTvDjESpRtQJCGUkuircyoedzqgFa>>16&255]+nbTvDjESpRtQJCGUkuircyoedzqgFM[nbTvDjESpRtQJCGUkuircyoedzqgFa>>24&255]
  return nbTvDjESpRtQJCGUkuircyoedzqgFs
 def GetCredential(nbTvDjESpRtQJCGUkuircyoedzqgFP,user_id,user_pw,login_type,user_pf):
  nbTvDjESpRtQJCGUkuircyoedzqgFx=nbTvDjESpRtQJCGUkuircyoedzqgls
  nbTvDjESpRtQJCGUkuircyoedzqgFX=nbTvDjESpRtQJCGUkuircyoedzqgWF=nbTvDjESpRtQJCGUkuircyoedzqgWV=nbTvDjESpRtQJCGUkuircyoedzqgWm=nbTvDjESpRtQJCGUkuircyoedzqgWP='' 
  nbTvDjESpRtQJCGUkuircyoedzqgFI ='-'
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgFL=nbTvDjESpRtQJCGUkuircyoedzqgFP.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   nbTvDjESpRtQJCGUkuircyoedzqgFO={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Post',nbTvDjESpRtQJCGUkuircyoedzqgFL,payload=nbTvDjESpRtQJCGUkuircyoedzqgFO,params=nbTvDjESpRtQJCGUkuircyoedzqgla,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgla)
   for nbTvDjESpRtQJCGUkuircyoedzqgFY in nbTvDjESpRtQJCGUkuircyoedzqgFA.cookies:
    if nbTvDjESpRtQJCGUkuircyoedzqgFY.name=='_tving_token':
     nbTvDjESpRtQJCGUkuircyoedzqgWF=nbTvDjESpRtQJCGUkuircyoedzqgFY.value
    elif nbTvDjESpRtQJCGUkuircyoedzqgFY.name=='POC_USERINFO':
     nbTvDjESpRtQJCGUkuircyoedzqgWV=nbTvDjESpRtQJCGUkuircyoedzqgFY.value
   if nbTvDjESpRtQJCGUkuircyoedzqgWF=='':return nbTvDjESpRtQJCGUkuircyoedzqgFx
   nbTvDjESpRtQJCGUkuircyoedzqgFX=nbTvDjESpRtQJCGUkuircyoedzqgWF
   nbTvDjESpRtQJCGUkuircyoedzqgWF,nbTvDjESpRtQJCGUkuircyoedzqgWm,nbTvDjESpRtQJCGUkuircyoedzqgWP=nbTvDjESpRtQJCGUkuircyoedzqgFP.GetProfileToken(nbTvDjESpRtQJCGUkuircyoedzqgWF,nbTvDjESpRtQJCGUkuircyoedzqgWV,user_pf)
   nbTvDjESpRtQJCGUkuircyoedzqgFx=nbTvDjESpRtQJCGUkuircyoedzqglI
   nbTvDjESpRtQJCGUkuircyoedzqgFI =nbTvDjESpRtQJCGUkuircyoedzqgFP.GetDeviceList(nbTvDjESpRtQJCGUkuircyoedzqgWF,nbTvDjESpRtQJCGUkuircyoedzqgWV)
   nbTvDjESpRtQJCGUkuircyoedzqgFI =nbTvDjESpRtQJCGUkuircyoedzqgFI+'-'+nbTvDjESpRtQJCGUkuircyoedzqgFP.GetUniqueid()
   nbTvDjESpRtQJCGUkuircyoedzqglL(nbTvDjESpRtQJCGUkuircyoedzqgFI)
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqgFX=nbTvDjESpRtQJCGUkuircyoedzqgWF=nbTvDjESpRtQJCGUkuircyoedzqgWV=nbTvDjESpRtQJCGUkuircyoedzqgWm=nbTvDjESpRtQJCGUkuircyoedzqgWP=''
   nbTvDjESpRtQJCGUkuircyoedzqgFI='-'
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  nbTvDjESpRtQJCGUkuircyoedzqgFN={'tving_token':nbTvDjESpRtQJCGUkuircyoedzqgWF,'poc_userinfo':nbTvDjESpRtQJCGUkuircyoedzqgWV,'tving_uuid':nbTvDjESpRtQJCGUkuircyoedzqgFI,'tving_maintoken':nbTvDjESpRtQJCGUkuircyoedzqgFX,'tving_cookiekey':nbTvDjESpRtQJCGUkuircyoedzqgWm,'tving_lockkey':nbTvDjESpRtQJCGUkuircyoedzqgWP}
  nbTvDjESpRtQJCGUkuircyoedzqgFP.SaveCredential(nbTvDjESpRtQJCGUkuircyoedzqgFN)
  return nbTvDjESpRtQJCGUkuircyoedzqgFx
 def Get_Now_Datetime(nbTvDjESpRtQJCGUkuircyoedzqgFP):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(nbTvDjESpRtQJCGUkuircyoedzqgFP,mediacode,sel_quality,stype,pvrmode='-'):
  nbTvDjESpRtQJCGUkuircyoedzqgWK=''
  nbTvDjESpRtQJCGUkuircyoedzqgWh=''
  nbTvDjESpRtQJCGUkuircyoedzqgWf =nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_UUID.split('-')[0] 
  nbTvDjESpRtQJCGUkuircyoedzqgWH =nbTvDjESpRtQJCGUkuircyoedzqgFP.TVING_UUID 
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWB=nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.GetNoCache(1))
   if stype!='tvingtv':
    nbTvDjESpRtQJCGUkuircyoedzqgWN ='/v2/media/stream/info' 
    nbTvDjESpRtQJCGUkuircyoedzqgWw=nbTvDjESpRtQJCGUkuircyoedzqgFP.GetDefaultParams()
    nbTvDjESpRtQJCGUkuircyoedzqgWM={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':nbTvDjESpRtQJCGUkuircyoedzqgWH,'deviceInfo':'PC','noCache':nbTvDjESpRtQJCGUkuircyoedzqgWB,}
    nbTvDjESpRtQJCGUkuircyoedzqgWw.update(nbTvDjESpRtQJCGUkuircyoedzqgWM)
    nbTvDjESpRtQJCGUkuircyoedzqgWa=nbTvDjESpRtQJCGUkuircyoedzqgFP.API_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWN
    nbTvDjESpRtQJCGUkuircyoedzqgFh=nbTvDjESpRtQJCGUkuircyoedzqgFP.makeDefaultCookies()
    nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgWw,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgFh)
    if nbTvDjESpRtQJCGUkuircyoedzqgFA.status_code!=200:return nbTvDjESpRtQJCGUkuircyoedzqgWK,nbTvDjESpRtQJCGUkuircyoedzqgWh
    nbTvDjESpRtQJCGUkuircyoedzqgWs=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
    if nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['result']['code']=='060':
     for nbTvDjESpRtQJCGUkuircyoedzqgWx,nbTvDjESpRtQJCGUkuircyoedzqgVm in nbTvDjESpRtQJCGUkuircyoedzqgFV.items():
      if nbTvDjESpRtQJCGUkuircyoedzqgVm==sel_quality:
       nbTvDjESpRtQJCGUkuircyoedzqgWX=nbTvDjESpRtQJCGUkuircyoedzqgWx
    elif nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['result']['code']!='000':
     nbTvDjESpRtQJCGUkuircyoedzqgWh=nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['result']['message']
     return nbTvDjESpRtQJCGUkuircyoedzqgWK,nbTvDjESpRtQJCGUkuircyoedzqgWh
    else: 
     if not('stream' in nbTvDjESpRtQJCGUkuircyoedzqgWs['body']):return nbTvDjESpRtQJCGUkuircyoedzqgWK,nbTvDjESpRtQJCGUkuircyoedzqgWh 
     nbTvDjESpRtQJCGUkuircyoedzqgWI=nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['stream']
     nbTvDjESpRtQJCGUkuircyoedzqgWL=nbTvDjESpRtQJCGUkuircyoedzqgWI['quality']
     nbTvDjESpRtQJCGUkuircyoedzqgWO=[]
     for nbTvDjESpRtQJCGUkuircyoedzqgWA in nbTvDjESpRtQJCGUkuircyoedzqgWL:
      if nbTvDjESpRtQJCGUkuircyoedzqgWA['active']=='Y':
       nbTvDjESpRtQJCGUkuircyoedzqgWO.append({nbTvDjESpRtQJCGUkuircyoedzqgFV.get(nbTvDjESpRtQJCGUkuircyoedzqgWA['code']):nbTvDjESpRtQJCGUkuircyoedzqgWA['code']})
     nbTvDjESpRtQJCGUkuircyoedzqgWX=nbTvDjESpRtQJCGUkuircyoedzqgFP.CheckQuality(sel_quality,nbTvDjESpRtQJCGUkuircyoedzqgWO)
   else:
    nbTvDjESpRtQJCGUkuircyoedzqgWX='stream40'
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
   return nbTvDjESpRtQJCGUkuircyoedzqgWK,nbTvDjESpRtQJCGUkuircyoedzqgWh
  nbTvDjESpRtQJCGUkuircyoedzqglL(nbTvDjESpRtQJCGUkuircyoedzqgWX)
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWB=nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.GetNoCache(1))
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='/v2a/media/stream/info'
   nbTvDjESpRtQJCGUkuircyoedzqgWw=nbTvDjESpRtQJCGUkuircyoedzqgFP.GetDefaultParams()
   nbTvDjESpRtQJCGUkuircyoedzqgWM={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':nbTvDjESpRtQJCGUkuircyoedzqgWX,'deviceId':nbTvDjESpRtQJCGUkuircyoedzqgWf,'uuid':nbTvDjESpRtQJCGUkuircyoedzqgWH,'deviceInfo':'PC_Chrome','noCache':nbTvDjESpRtQJCGUkuircyoedzqgWB,'wm':'Y'}
   nbTvDjESpRtQJCGUkuircyoedzqgWw.update(nbTvDjESpRtQJCGUkuircyoedzqgWM)
   nbTvDjESpRtQJCGUkuircyoedzqgWa=nbTvDjESpRtQJCGUkuircyoedzqgFP.API_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWN
   nbTvDjESpRtQJCGUkuircyoedzqgFh=nbTvDjESpRtQJCGUkuircyoedzqgFP.makeDefaultCookies()
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgWw,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgFh,redirects=nbTvDjESpRtQJCGUkuircyoedzqgls)
   nbTvDjESpRtQJCGUkuircyoedzqgWs=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   if nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['result']['code']!='000':
    nbTvDjESpRtQJCGUkuircyoedzqgWh=nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['result']['message']
    return nbTvDjESpRtQJCGUkuircyoedzqgWK,nbTvDjESpRtQJCGUkuircyoedzqgWh
   nbTvDjESpRtQJCGUkuircyoedzqgWI=nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['stream']
   if 'drm_license_assertion' in nbTvDjESpRtQJCGUkuircyoedzqgWI:
    nbTvDjESpRtQJCGUkuircyoedzqgWh =nbTvDjESpRtQJCGUkuircyoedzqgWI['drm_license_assertion']
    nbTvDjESpRtQJCGUkuircyoedzqgWK=nbTvDjESpRtQJCGUkuircyoedzqgWI['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in nbTvDjESpRtQJCGUkuircyoedzqgWI['broadcast']):return nbTvDjESpRtQJCGUkuircyoedzqgWK,nbTvDjESpRtQJCGUkuircyoedzqgWh
    nbTvDjESpRtQJCGUkuircyoedzqgWK=nbTvDjESpRtQJCGUkuircyoedzqgWI['broadcast']['broad_url']
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  nbTvDjESpRtQJCGUkuircyoedzqgWY=nbTvDjESpRtQJCGUkuircyoedzqgWB
  nbTvDjESpRtQJCGUkuircyoedzqgWK=nbTvDjESpRtQJCGUkuircyoedzqgWK.split('|')[1]
  nbTvDjESpRtQJCGUkuircyoedzqgWK=nbTvDjESpRtQJCGUkuircyoedzqgFP.Decrypt_Url(nbTvDjESpRtQJCGUkuircyoedzqgWK,mediacode,nbTvDjESpRtQJCGUkuircyoedzqgWY)
  return nbTvDjESpRtQJCGUkuircyoedzqgWK,nbTvDjESpRtQJCGUkuircyoedzqgWh
 def CheckQuality(nbTvDjESpRtQJCGUkuircyoedzqgFP,sel_qt,nbTvDjESpRtQJCGUkuircyoedzqgWO):
  for nbTvDjESpRtQJCGUkuircyoedzqgVF in nbTvDjESpRtQJCGUkuircyoedzqgWO:
   if sel_qt>=nbTvDjESpRtQJCGUkuircyoedzqglY(nbTvDjESpRtQJCGUkuircyoedzqgVF)[0]:return nbTvDjESpRtQJCGUkuircyoedzqgVF.get(nbTvDjESpRtQJCGUkuircyoedzqglY(nbTvDjESpRtQJCGUkuircyoedzqgVF)[0])
   nbTvDjESpRtQJCGUkuircyoedzqgVW=nbTvDjESpRtQJCGUkuircyoedzqgVF.get(nbTvDjESpRtQJCGUkuircyoedzqglY(nbTvDjESpRtQJCGUkuircyoedzqgVF)[0])
  return nbTvDjESpRtQJCGUkuircyoedzqgVW
 def makeOocUrl(nbTvDjESpRtQJCGUkuircyoedzqgFP,ooc_params):
  nbTvDjESpRtQJCGUkuircyoedzqgWa=''
  for nbTvDjESpRtQJCGUkuircyoedzqgWx,nbTvDjESpRtQJCGUkuircyoedzqgVm in ooc_params.items():
   nbTvDjESpRtQJCGUkuircyoedzqgWa+="%s=%s^"%(nbTvDjESpRtQJCGUkuircyoedzqgWx,nbTvDjESpRtQJCGUkuircyoedzqgVm)
  return nbTvDjESpRtQJCGUkuircyoedzqgWa
 def GetLiveChannelList(nbTvDjESpRtQJCGUkuircyoedzqgFP,stype,page_int):
  nbTvDjESpRtQJCGUkuircyoedzqgVP=[]
  nbTvDjESpRtQJCGUkuircyoedzqgVl=nbTvDjESpRtQJCGUkuircyoedzqgls
  nbTvDjESpRtQJCGUkuircyoedzqgVK=nbTvDjESpRtQJCGUkuircyoedzqgls
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='/v2/media/lives'
   if stype=='onair': 
    nbTvDjESpRtQJCGUkuircyoedzqgVh='CPCS0100,CPCS0400'
   else:
    nbTvDjESpRtQJCGUkuircyoedzqgVh='CPCS0300'
   nbTvDjESpRtQJCGUkuircyoedzqgWw=nbTvDjESpRtQJCGUkuircyoedzqgFP.GetDefaultParams()
   nbTvDjESpRtQJCGUkuircyoedzqgWM={'pageNo':nbTvDjESpRtQJCGUkuircyoedzqglA(page_int),'pageSize':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':nbTvDjESpRtQJCGUkuircyoedzqgVh,'_':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.GetNoCache(2))}
   nbTvDjESpRtQJCGUkuircyoedzqgWw.update(nbTvDjESpRtQJCGUkuircyoedzqgWM)
   nbTvDjESpRtQJCGUkuircyoedzqgWa=nbTvDjESpRtQJCGUkuircyoedzqgFP.API_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWN
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgWw,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgla)
   nbTvDjESpRtQJCGUkuircyoedzqgWs=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   if not('result' in nbTvDjESpRtQJCGUkuircyoedzqgWs['body']):return nbTvDjESpRtQJCGUkuircyoedzqgVP,nbTvDjESpRtQJCGUkuircyoedzqgVl
   nbTvDjESpRtQJCGUkuircyoedzqgVf=nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['result']
   for nbTvDjESpRtQJCGUkuircyoedzqgWA in nbTvDjESpRtQJCGUkuircyoedzqgVf:
    nbTvDjESpRtQJCGUkuircyoedzqgVH=nbTvDjESpRtQJCGUkuircyoedzqgVw=nbTvDjESpRtQJCGUkuircyoedzqgVM=''
    nbTvDjESpRtQJCGUkuircyoedzqgVB=nbTvDjESpRtQJCGUkuircyoedzqgmf=''
    nbTvDjESpRtQJCGUkuircyoedzqgVN=nbTvDjESpRtQJCGUkuircyoedzqgWA['live_code']
    if nbTvDjESpRtQJCGUkuircyoedzqgVN=='C01345':nbTvDjESpRtQJCGUkuircyoedzqgVK=nbTvDjESpRtQJCGUkuircyoedzqglI 
    nbTvDjESpRtQJCGUkuircyoedzqgVH =nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['channel']['name']['ko']
    if nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['episode']!=nbTvDjESpRtQJCGUkuircyoedzqgla:
     nbTvDjESpRtQJCGUkuircyoedzqgVw =nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['program']['name']['ko']
     nbTvDjESpRtQJCGUkuircyoedzqgVw =nbTvDjESpRtQJCGUkuircyoedzqgVw+', '+nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['episode']['frequency'])+'회'
     nbTvDjESpRtQJCGUkuircyoedzqgVM=nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['episode']['synopsis']['ko']
    else:
     nbTvDjESpRtQJCGUkuircyoedzqgVw =nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['program']['name']['ko']
     nbTvDjESpRtQJCGUkuircyoedzqgVM=nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['program']['synopsis']['ko']
    try: 
     nbTvDjESpRtQJCGUkuircyoedzqgVa =''
     nbTvDjESpRtQJCGUkuircyoedzqgVs =''
     nbTvDjESpRtQJCGUkuircyoedzqgVx=''
     nbTvDjESpRtQJCGUkuircyoedzqgVX =''
     nbTvDjESpRtQJCGUkuircyoedzqgVI =''
     nbTvDjESpRtQJCGUkuircyoedzqgVL =''
     for nbTvDjESpRtQJCGUkuircyoedzqgVO in nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['program']['image']:
      if nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP0900':nbTvDjESpRtQJCGUkuircyoedzqgVs =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
      elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP1800':nbTvDjESpRtQJCGUkuircyoedzqgVx=nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
      elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP2000':nbTvDjESpRtQJCGUkuircyoedzqgVX =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
      elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP1900':nbTvDjESpRtQJCGUkuircyoedzqgVI =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
      elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP0200':nbTvDjESpRtQJCGUkuircyoedzqgVL =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
      elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP0500':nbTvDjESpRtQJCGUkuircyoedzqgVa =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
      elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP0800':nbTvDjESpRtQJCGUkuircyoedzqgVa =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
     if nbTvDjESpRtQJCGUkuircyoedzqgVa=='':
      for nbTvDjESpRtQJCGUkuircyoedzqgVO in nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['channel']['image']:
       if nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIC0400':nbTvDjESpRtQJCGUkuircyoedzqgVa =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
       elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIC1400':nbTvDjESpRtQJCGUkuircyoedzqgVa =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
       elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIC1900':nbTvDjESpRtQJCGUkuircyoedzqgVa =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
    except:
     nbTvDjESpRtQJCGUkuircyoedzqgla
    try:
     nbTvDjESpRtQJCGUkuircyoedzqgVA =[]
     nbTvDjESpRtQJCGUkuircyoedzqgVY=[]
     nbTvDjESpRtQJCGUkuircyoedzqgmF =[]
     nbTvDjESpRtQJCGUkuircyoedzqgmW=''
     nbTvDjESpRtQJCGUkuircyoedzqgmV=''
     nbTvDjESpRtQJCGUkuircyoedzqgmP=''
     for nbTvDjESpRtQJCGUkuircyoedzqgml in nbTvDjESpRtQJCGUkuircyoedzqgWA.get('schedule').get('program').get('actor'):
      if nbTvDjESpRtQJCGUkuircyoedzqgml!='' and nbTvDjESpRtQJCGUkuircyoedzqgml!=u'없음':nbTvDjESpRtQJCGUkuircyoedzqgVA.append(nbTvDjESpRtQJCGUkuircyoedzqgml)
     for nbTvDjESpRtQJCGUkuircyoedzqgmK in nbTvDjESpRtQJCGUkuircyoedzqgWA.get('schedule').get('program').get('director'):
      if nbTvDjESpRtQJCGUkuircyoedzqgmK!='' and nbTvDjESpRtQJCGUkuircyoedzqgmK!='-' and nbTvDjESpRtQJCGUkuircyoedzqgmK!=u'없음':nbTvDjESpRtQJCGUkuircyoedzqgVY.append(nbTvDjESpRtQJCGUkuircyoedzqgmK)
     if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('schedule').get('program').get('category1_name').get('ko')!='':
      nbTvDjESpRtQJCGUkuircyoedzqgmF.append(nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['program']['category1_name']['ko'])
     if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('schedule').get('program').get('category2_name').get('ko')!='':
      nbTvDjESpRtQJCGUkuircyoedzqgmF.append(nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['program']['category2_name']['ko'])
     if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('schedule').get('program').get('product_year'):nbTvDjESpRtQJCGUkuircyoedzqgmW=nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['program']['product_year']
     if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('schedule').get('program').get('grade_code') :nbTvDjESpRtQJCGUkuircyoedzqgmV= nbTvDjESpRtQJCGUkuircyoedzqgFm.get(nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['program']['grade_code'])
     if 'broad_dt' in nbTvDjESpRtQJCGUkuircyoedzqgWA.get('schedule').get('program'):
      nbTvDjESpRtQJCGUkuircyoedzqgmh =nbTvDjESpRtQJCGUkuircyoedzqgWA.get('schedule').get('program').get('broad_dt')
      nbTvDjESpRtQJCGUkuircyoedzqgmP='%s-%s-%s'%(nbTvDjESpRtQJCGUkuircyoedzqgmh[:4],nbTvDjESpRtQJCGUkuircyoedzqgmh[4:6],nbTvDjESpRtQJCGUkuircyoedzqgmh[6:])
    except:
     nbTvDjESpRtQJCGUkuircyoedzqgla
    nbTvDjESpRtQJCGUkuircyoedzqgVB=nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['broadcast_start_time'])[8:12]
    nbTvDjESpRtQJCGUkuircyoedzqgmf =nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgWA['schedule']['broadcast_end_time'])[8:12]
    nbTvDjESpRtQJCGUkuircyoedzqgmH={'channel':nbTvDjESpRtQJCGUkuircyoedzqgVH,'title':nbTvDjESpRtQJCGUkuircyoedzqgVw,'mediacode':nbTvDjESpRtQJCGUkuircyoedzqgVN,'thumbnail':{'poster':nbTvDjESpRtQJCGUkuircyoedzqgVs,'thumb':nbTvDjESpRtQJCGUkuircyoedzqgVa,'clearlogo':nbTvDjESpRtQJCGUkuircyoedzqgVx,'icon':nbTvDjESpRtQJCGUkuircyoedzqgVX,'fanart':nbTvDjESpRtQJCGUkuircyoedzqgVL},'synopsis':nbTvDjESpRtQJCGUkuircyoedzqgVM,'channelepg':' [%s:%s ~ %s:%s]'%(nbTvDjESpRtQJCGUkuircyoedzqgVB[0:2],nbTvDjESpRtQJCGUkuircyoedzqgVB[2:],nbTvDjESpRtQJCGUkuircyoedzqgmf[0:2],nbTvDjESpRtQJCGUkuircyoedzqgmf[2:]),'cast':nbTvDjESpRtQJCGUkuircyoedzqgVA,'director':nbTvDjESpRtQJCGUkuircyoedzqgVY,'info_genre':nbTvDjESpRtQJCGUkuircyoedzqgmF,'year':nbTvDjESpRtQJCGUkuircyoedzqgmW,'mpaa':nbTvDjESpRtQJCGUkuircyoedzqgmV,'premiered':nbTvDjESpRtQJCGUkuircyoedzqgmP}
    nbTvDjESpRtQJCGUkuircyoedzqgVP.append(nbTvDjESpRtQJCGUkuircyoedzqgmH)
   if nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['has_more']=='Y':
    nbTvDjESpRtQJCGUkuircyoedzqgVl=nbTvDjESpRtQJCGUkuircyoedzqglI
   else:
    nbTvDjESpRtQJCGUkuircyoedzqgmH={'channel':'OCN Original','title':'temp','mediacode':'C01345','thumbnail':'http://image.tving.com/upload/cms/caic/CAIC0400/C01345.png','cast':[],'director':[]}
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  return nbTvDjESpRtQJCGUkuircyoedzqgVP,nbTvDjESpRtQJCGUkuircyoedzqgVl
 def GetProgramList(nbTvDjESpRtQJCGUkuircyoedzqgFP,genre,orderby,page_int,genreCode='all'):
  nbTvDjESpRtQJCGUkuircyoedzqgVP=[]
  nbTvDjESpRtQJCGUkuircyoedzqgVl=nbTvDjESpRtQJCGUkuircyoedzqgls
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='/v2/media/episodes'
   nbTvDjESpRtQJCGUkuircyoedzqgWw=nbTvDjESpRtQJCGUkuircyoedzqgFP.GetDefaultParams()
   nbTvDjESpRtQJCGUkuircyoedzqgWM={'pageNo':nbTvDjESpRtQJCGUkuircyoedzqglA(page_int),'pageSize':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.GetNoCache(2))}
   if genre !='all':nbTvDjESpRtQJCGUkuircyoedzqgWM['categoryCode']=genre
   if genreCode!='all':nbTvDjESpRtQJCGUkuircyoedzqgWM['genreCode'] =genreCode 
   nbTvDjESpRtQJCGUkuircyoedzqgWw.update(nbTvDjESpRtQJCGUkuircyoedzqgWM)
   nbTvDjESpRtQJCGUkuircyoedzqgWa=nbTvDjESpRtQJCGUkuircyoedzqgFP.API_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWN
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgWw,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgla)
   nbTvDjESpRtQJCGUkuircyoedzqgWs=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   if not('result' in nbTvDjESpRtQJCGUkuircyoedzqgWs['body']):return nbTvDjESpRtQJCGUkuircyoedzqgVP,nbTvDjESpRtQJCGUkuircyoedzqgVl
   nbTvDjESpRtQJCGUkuircyoedzqgVf=nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['result']
   for nbTvDjESpRtQJCGUkuircyoedzqgWA in nbTvDjESpRtQJCGUkuircyoedzqgVf:
    nbTvDjESpRtQJCGUkuircyoedzqgmB=nbTvDjESpRtQJCGUkuircyoedzqgWA['program']['code']
    nbTvDjESpRtQJCGUkuircyoedzqgVw =nbTvDjESpRtQJCGUkuircyoedzqgWA['program']['name']['ko']
    nbTvDjESpRtQJCGUkuircyoedzqgmV =nbTvDjESpRtQJCGUkuircyoedzqgFm.get(nbTvDjESpRtQJCGUkuircyoedzqgWA['program'].get('grade_code'))
    nbTvDjESpRtQJCGUkuircyoedzqgVs =''
    nbTvDjESpRtQJCGUkuircyoedzqgVa =''
    nbTvDjESpRtQJCGUkuircyoedzqgVx=''
    nbTvDjESpRtQJCGUkuircyoedzqgVX =''
    nbTvDjESpRtQJCGUkuircyoedzqgVI =''
    for nbTvDjESpRtQJCGUkuircyoedzqgVO in nbTvDjESpRtQJCGUkuircyoedzqgWA['program']['image']:
     if nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP0900':nbTvDjESpRtQJCGUkuircyoedzqgVs =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
     elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP0200':nbTvDjESpRtQJCGUkuircyoedzqgVa =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
     elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP1800':nbTvDjESpRtQJCGUkuircyoedzqgVx=nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
     elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP2000':nbTvDjESpRtQJCGUkuircyoedzqgVX =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
     elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP1900':nbTvDjESpRtQJCGUkuircyoedzqgVI =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
    nbTvDjESpRtQJCGUkuircyoedzqgVM =nbTvDjESpRtQJCGUkuircyoedzqgWA['program']['synopsis']['ko']
    try:
     nbTvDjESpRtQJCGUkuircyoedzqgmN=nbTvDjESpRtQJCGUkuircyoedzqgWA['channel']['name']['ko']
    except:
     nbTvDjESpRtQJCGUkuircyoedzqgmN=''
    try:
     nbTvDjESpRtQJCGUkuircyoedzqgVA =[]
     nbTvDjESpRtQJCGUkuircyoedzqgVY=[]
     nbTvDjESpRtQJCGUkuircyoedzqgmF =[]
     nbTvDjESpRtQJCGUkuircyoedzqgmW =''
     nbTvDjESpRtQJCGUkuircyoedzqgmP=''
     for nbTvDjESpRtQJCGUkuircyoedzqgml in nbTvDjESpRtQJCGUkuircyoedzqgWA.get('program').get('actor'):
      if nbTvDjESpRtQJCGUkuircyoedzqgml!='' and nbTvDjESpRtQJCGUkuircyoedzqgml!='-' and nbTvDjESpRtQJCGUkuircyoedzqgml!=u'없음':nbTvDjESpRtQJCGUkuircyoedzqgVA.append(nbTvDjESpRtQJCGUkuircyoedzqgml)
     for nbTvDjESpRtQJCGUkuircyoedzqgmK in nbTvDjESpRtQJCGUkuircyoedzqgWA.get('program').get('director'):
      if nbTvDjESpRtQJCGUkuircyoedzqgmK!='' and nbTvDjESpRtQJCGUkuircyoedzqgmK!='-' and nbTvDjESpRtQJCGUkuircyoedzqgmK!=u'없음':nbTvDjESpRtQJCGUkuircyoedzqgVY.append(nbTvDjESpRtQJCGUkuircyoedzqgmK)
     if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('program').get('category1_name').get('ko')!='':
      nbTvDjESpRtQJCGUkuircyoedzqgmF.append(nbTvDjESpRtQJCGUkuircyoedzqgWA['program']['category1_name']['ko'])
     if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('program').get('category2_name').get('ko')!='':
      nbTvDjESpRtQJCGUkuircyoedzqgmF.append(nbTvDjESpRtQJCGUkuircyoedzqgWA['program']['category2_name']['ko'])
     if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('program').get('product_year'):nbTvDjESpRtQJCGUkuircyoedzqgmW=nbTvDjESpRtQJCGUkuircyoedzqgWA['program']['product_year']
     if 'broad_dt' in nbTvDjESpRtQJCGUkuircyoedzqgWA.get('program'):
      nbTvDjESpRtQJCGUkuircyoedzqgmh =nbTvDjESpRtQJCGUkuircyoedzqgWA.get('program').get('broad_dt')
      nbTvDjESpRtQJCGUkuircyoedzqgmP='%s-%s-%s'%(nbTvDjESpRtQJCGUkuircyoedzqgmh[:4],nbTvDjESpRtQJCGUkuircyoedzqgmh[4:6],nbTvDjESpRtQJCGUkuircyoedzqgmh[6:])
    except:
     nbTvDjESpRtQJCGUkuircyoedzqgla
    nbTvDjESpRtQJCGUkuircyoedzqgmH={'program':nbTvDjESpRtQJCGUkuircyoedzqgmB,'title':nbTvDjESpRtQJCGUkuircyoedzqgVw,'thumbnail':{'poster':nbTvDjESpRtQJCGUkuircyoedzqgVs,'thumb':nbTvDjESpRtQJCGUkuircyoedzqgVa,'clearlogo':nbTvDjESpRtQJCGUkuircyoedzqgVx,'icon':nbTvDjESpRtQJCGUkuircyoedzqgVX,'banner':nbTvDjESpRtQJCGUkuircyoedzqgVI,'fanart':nbTvDjESpRtQJCGUkuircyoedzqgVa},'synopsis':nbTvDjESpRtQJCGUkuircyoedzqgVM,'channel':nbTvDjESpRtQJCGUkuircyoedzqgmN,'cast':nbTvDjESpRtQJCGUkuircyoedzqgVA,'director':nbTvDjESpRtQJCGUkuircyoedzqgVY,'info_genre':nbTvDjESpRtQJCGUkuircyoedzqgmF,'year':nbTvDjESpRtQJCGUkuircyoedzqgmW,'premiered':nbTvDjESpRtQJCGUkuircyoedzqgmP,'mpaa':nbTvDjESpRtQJCGUkuircyoedzqgmV}
    nbTvDjESpRtQJCGUkuircyoedzqgVP.append(nbTvDjESpRtQJCGUkuircyoedzqgmH)
   if nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['has_more']=='Y':nbTvDjESpRtQJCGUkuircyoedzqgVl=nbTvDjESpRtQJCGUkuircyoedzqglI
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  return nbTvDjESpRtQJCGUkuircyoedzqgVP,nbTvDjESpRtQJCGUkuircyoedzqgVl
 def GetEpisodeList(nbTvDjESpRtQJCGUkuircyoedzqgFP,program_code,page_int,orderby='desc'):
  nbTvDjESpRtQJCGUkuircyoedzqgVP=[]
  nbTvDjESpRtQJCGUkuircyoedzqgVl=nbTvDjESpRtQJCGUkuircyoedzqgls
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='/v2/media/frequency/program/'+program_code
   nbTvDjESpRtQJCGUkuircyoedzqgWw=nbTvDjESpRtQJCGUkuircyoedzqgFP.GetDefaultParams()
   nbTvDjESpRtQJCGUkuircyoedzqgWM={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.GetNoCache(2))}
   nbTvDjESpRtQJCGUkuircyoedzqgWw.update(nbTvDjESpRtQJCGUkuircyoedzqgWM)
   nbTvDjESpRtQJCGUkuircyoedzqgWa=nbTvDjESpRtQJCGUkuircyoedzqgFP.API_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWN
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgWw,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgla)
   nbTvDjESpRtQJCGUkuircyoedzqgWs=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   if not('result' in nbTvDjESpRtQJCGUkuircyoedzqgWs['body']):return nbTvDjESpRtQJCGUkuircyoedzqgVP,nbTvDjESpRtQJCGUkuircyoedzqgVl
   nbTvDjESpRtQJCGUkuircyoedzqgVf=nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['result']
   nbTvDjESpRtQJCGUkuircyoedzqgmw=nbTvDjESpRtQJCGUkuircyoedzqglx(nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['total_count'])
   nbTvDjESpRtQJCGUkuircyoedzqgmM =nbTvDjESpRtQJCGUkuircyoedzqglx(nbTvDjESpRtQJCGUkuircyoedzqgmw//(nbTvDjESpRtQJCGUkuircyoedzqgFP.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    nbTvDjESpRtQJCGUkuircyoedzqgma =(nbTvDjESpRtQJCGUkuircyoedzqgmw-1)-((page_int-1)*nbTvDjESpRtQJCGUkuircyoedzqgFP.EPISODE_LIMIT)
   else:
    nbTvDjESpRtQJCGUkuircyoedzqgma =(page_int-1)*nbTvDjESpRtQJCGUkuircyoedzqgFP.EPISODE_LIMIT
   for i in nbTvDjESpRtQJCGUkuircyoedzqglX(nbTvDjESpRtQJCGUkuircyoedzqgFP.EPISODE_LIMIT):
    if orderby=='desc':
     nbTvDjESpRtQJCGUkuircyoedzqgms=nbTvDjESpRtQJCGUkuircyoedzqgma-i
     if nbTvDjESpRtQJCGUkuircyoedzqgms<0:break
    else:
     nbTvDjESpRtQJCGUkuircyoedzqgms=nbTvDjESpRtQJCGUkuircyoedzqgma+i
     if nbTvDjESpRtQJCGUkuircyoedzqgms>=nbTvDjESpRtQJCGUkuircyoedzqgmw:break
    nbTvDjESpRtQJCGUkuircyoedzqgmx=nbTvDjESpRtQJCGUkuircyoedzqgVf[nbTvDjESpRtQJCGUkuircyoedzqgms]['episode']['code']
    nbTvDjESpRtQJCGUkuircyoedzqgVw =nbTvDjESpRtQJCGUkuircyoedzqgVf[nbTvDjESpRtQJCGUkuircyoedzqgms]['vod_name']['ko']
    nbTvDjESpRtQJCGUkuircyoedzqgmX =''
    try:
     nbTvDjESpRtQJCGUkuircyoedzqgmh=nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgVf[nbTvDjESpRtQJCGUkuircyoedzqgms]['episode']['broadcast_date'])
     nbTvDjESpRtQJCGUkuircyoedzqgmX='%s-%s-%s'%(nbTvDjESpRtQJCGUkuircyoedzqgmh[:4],nbTvDjESpRtQJCGUkuircyoedzqgmh[4:6],nbTvDjESpRtQJCGUkuircyoedzqgmh[6:])
    except:
     nbTvDjESpRtQJCGUkuircyoedzqgla
    try:
     if nbTvDjESpRtQJCGUkuircyoedzqgVf[nbTvDjESpRtQJCGUkuircyoedzqgms]['episode']['pip_cliptype']=='C012':
      nbTvDjESpRtQJCGUkuircyoedzqgmX+=' - Quick VOD'
    except:
     nbTvDjESpRtQJCGUkuircyoedzqgla
    nbTvDjESpRtQJCGUkuircyoedzqgVM =nbTvDjESpRtQJCGUkuircyoedzqgVf[nbTvDjESpRtQJCGUkuircyoedzqgms]['episode']['synopsis']['ko']
    nbTvDjESpRtQJCGUkuircyoedzqgVs =''
    nbTvDjESpRtQJCGUkuircyoedzqgVa =''
    nbTvDjESpRtQJCGUkuircyoedzqgVx=''
    nbTvDjESpRtQJCGUkuircyoedzqgVX =''
    nbTvDjESpRtQJCGUkuircyoedzqgVI =''
    nbTvDjESpRtQJCGUkuircyoedzqgVL =''
    for nbTvDjESpRtQJCGUkuircyoedzqgVO in nbTvDjESpRtQJCGUkuircyoedzqgVf[nbTvDjESpRtQJCGUkuircyoedzqgms]['program']['image']:
     if nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP0900':nbTvDjESpRtQJCGUkuircyoedzqgVs =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
     elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP1800':nbTvDjESpRtQJCGUkuircyoedzqgVx=nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
     elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP2000':nbTvDjESpRtQJCGUkuircyoedzqgVX =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
     elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP1900':nbTvDjESpRtQJCGUkuircyoedzqgVI =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
     elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIP0200':nbTvDjESpRtQJCGUkuircyoedzqgVL =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
    for nbTvDjESpRtQJCGUkuircyoedzqgVO in nbTvDjESpRtQJCGUkuircyoedzqgVf[nbTvDjESpRtQJCGUkuircyoedzqgms]['episode']['image']:
     if nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIE0400':nbTvDjESpRtQJCGUkuircyoedzqgVa =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
    try:
     nbTvDjESpRtQJCGUkuircyoedzqgmI=nbTvDjESpRtQJCGUkuircyoedzqgmO=nbTvDjESpRtQJCGUkuircyoedzqgmA=''
     nbTvDjESpRtQJCGUkuircyoedzqgmL=0
     nbTvDjESpRtQJCGUkuircyoedzqgmI =nbTvDjESpRtQJCGUkuircyoedzqgVf[nbTvDjESpRtQJCGUkuircyoedzqgms]['program']['name']['ko']
     nbTvDjESpRtQJCGUkuircyoedzqgmO =nbTvDjESpRtQJCGUkuircyoedzqgmX
     nbTvDjESpRtQJCGUkuircyoedzqgmA =nbTvDjESpRtQJCGUkuircyoedzqgVf[nbTvDjESpRtQJCGUkuircyoedzqgms]['channel']['name']['ko']
     if 'frequency' in nbTvDjESpRtQJCGUkuircyoedzqgVf[nbTvDjESpRtQJCGUkuircyoedzqgms]['episode']:nbTvDjESpRtQJCGUkuircyoedzqgmL=nbTvDjESpRtQJCGUkuircyoedzqgVf[nbTvDjESpRtQJCGUkuircyoedzqgms]['episode']['frequency']
    except:
     nbTvDjESpRtQJCGUkuircyoedzqgla
    nbTvDjESpRtQJCGUkuircyoedzqgmH={'episode':nbTvDjESpRtQJCGUkuircyoedzqgmx,'title':nbTvDjESpRtQJCGUkuircyoedzqgVw,'subtitle':nbTvDjESpRtQJCGUkuircyoedzqgmX,'thumbnail':{'poster':nbTvDjESpRtQJCGUkuircyoedzqgVs,'thumb':nbTvDjESpRtQJCGUkuircyoedzqgVa,'clearlogo':nbTvDjESpRtQJCGUkuircyoedzqgVx,'icon':nbTvDjESpRtQJCGUkuircyoedzqgVX,'banner':nbTvDjESpRtQJCGUkuircyoedzqgVI,'fanart':nbTvDjESpRtQJCGUkuircyoedzqgVL},'synopsis':nbTvDjESpRtQJCGUkuircyoedzqgVM,'info_title':nbTvDjESpRtQJCGUkuircyoedzqgmI,'aired':nbTvDjESpRtQJCGUkuircyoedzqgmO,'studio':nbTvDjESpRtQJCGUkuircyoedzqgmA,'frequency':nbTvDjESpRtQJCGUkuircyoedzqgmL}
    nbTvDjESpRtQJCGUkuircyoedzqgVP.append(nbTvDjESpRtQJCGUkuircyoedzqgmH)
   if nbTvDjESpRtQJCGUkuircyoedzqgmM>page_int:nbTvDjESpRtQJCGUkuircyoedzqgVl=nbTvDjESpRtQJCGUkuircyoedzqglI
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  return nbTvDjESpRtQJCGUkuircyoedzqgVP,nbTvDjESpRtQJCGUkuircyoedzqgVl,nbTvDjESpRtQJCGUkuircyoedzqgmM
 def GetMovieList(nbTvDjESpRtQJCGUkuircyoedzqgFP,genre,orderby,page_int):
  nbTvDjESpRtQJCGUkuircyoedzqgVP=[]
  nbTvDjESpRtQJCGUkuircyoedzqgVl=nbTvDjESpRtQJCGUkuircyoedzqgls
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='/v2/media/movies'
   nbTvDjESpRtQJCGUkuircyoedzqgWw=nbTvDjESpRtQJCGUkuircyoedzqgFP.GetDefaultParams()
   nbTvDjESpRtQJCGUkuircyoedzqgWM={'pageNo':nbTvDjESpRtQJCGUkuircyoedzqglA(page_int),'pageSize':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.GetNoCache(2))}
   if genre!='all' :nbTvDjESpRtQJCGUkuircyoedzqgWM['multiCategoryCode']=genre
   nbTvDjESpRtQJCGUkuircyoedzqgWM['productPackageCode']=','.join(nbTvDjESpRtQJCGUkuircyoedzqgFP.MOVIE_LITE)
   nbTvDjESpRtQJCGUkuircyoedzqgWw.update(nbTvDjESpRtQJCGUkuircyoedzqgWM)
   nbTvDjESpRtQJCGUkuircyoedzqgWa=nbTvDjESpRtQJCGUkuircyoedzqgFP.API_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWN
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgWw,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgla)
   nbTvDjESpRtQJCGUkuircyoedzqgWs=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   if not('result' in nbTvDjESpRtQJCGUkuircyoedzqgWs['body']):return nbTvDjESpRtQJCGUkuircyoedzqgVP,nbTvDjESpRtQJCGUkuircyoedzqgVl
   nbTvDjESpRtQJCGUkuircyoedzqgVf=nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['result']
   for nbTvDjESpRtQJCGUkuircyoedzqgWA in nbTvDjESpRtQJCGUkuircyoedzqgVf:
    nbTvDjESpRtQJCGUkuircyoedzqgmY =nbTvDjESpRtQJCGUkuircyoedzqgWA['movie']['code']
    nbTvDjESpRtQJCGUkuircyoedzqgVw =nbTvDjESpRtQJCGUkuircyoedzqgWA['movie']['name']['ko'].strip()
    nbTvDjESpRtQJCGUkuircyoedzqgVw +=u' (%s)'%(nbTvDjESpRtQJCGUkuircyoedzqgWA.get('movie').get('product_year'))
    nbTvDjESpRtQJCGUkuircyoedzqgVs=''
    nbTvDjESpRtQJCGUkuircyoedzqgVa =''
    nbTvDjESpRtQJCGUkuircyoedzqgVx=''
    for nbTvDjESpRtQJCGUkuircyoedzqgVO in nbTvDjESpRtQJCGUkuircyoedzqgWA['movie']['image']:
     if nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIM2100':nbTvDjESpRtQJCGUkuircyoedzqgVs =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
     elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIM0400':nbTvDjESpRtQJCGUkuircyoedzqgVa =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
     elif nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIM1800':nbTvDjESpRtQJCGUkuircyoedzqgVx=nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
    nbTvDjESpRtQJCGUkuircyoedzqgVM =nbTvDjESpRtQJCGUkuircyoedzqgWA['movie']['story']['ko']
    try:
     nbTvDjESpRtQJCGUkuircyoedzqgmI =nbTvDjESpRtQJCGUkuircyoedzqgWA['movie']['name']['ko'].strip()
     nbTvDjESpRtQJCGUkuircyoedzqgmW =nbTvDjESpRtQJCGUkuircyoedzqgWA.get('movie').get('product_year')
     nbTvDjESpRtQJCGUkuircyoedzqgmV =nbTvDjESpRtQJCGUkuircyoedzqgFm.get(nbTvDjESpRtQJCGUkuircyoedzqgWA.get('grade_code'))
     nbTvDjESpRtQJCGUkuircyoedzqgVA=[]
     nbTvDjESpRtQJCGUkuircyoedzqgVY=[]
     nbTvDjESpRtQJCGUkuircyoedzqgmF=[]
     nbTvDjESpRtQJCGUkuircyoedzqgPF=0
     nbTvDjESpRtQJCGUkuircyoedzqgmP=''
     nbTvDjESpRtQJCGUkuircyoedzqgmA =''
     for nbTvDjESpRtQJCGUkuircyoedzqgml in nbTvDjESpRtQJCGUkuircyoedzqgWA.get('movie').get('actor'):
      if nbTvDjESpRtQJCGUkuircyoedzqgml!='':nbTvDjESpRtQJCGUkuircyoedzqgVA.append(nbTvDjESpRtQJCGUkuircyoedzqgml)
     for nbTvDjESpRtQJCGUkuircyoedzqgmK in nbTvDjESpRtQJCGUkuircyoedzqgWA.get('movie').get('director'):
      if nbTvDjESpRtQJCGUkuircyoedzqgmK!='':nbTvDjESpRtQJCGUkuircyoedzqgVY.append(nbTvDjESpRtQJCGUkuircyoedzqgmK)
     if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('movie').get('category1_name').get('ko')!='':
      nbTvDjESpRtQJCGUkuircyoedzqgmF.append(nbTvDjESpRtQJCGUkuircyoedzqgWA['movie']['category1_name']['ko'])
     if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('movie').get('category2_name').get('ko')!='':
      nbTvDjESpRtQJCGUkuircyoedzqgmF.append(nbTvDjESpRtQJCGUkuircyoedzqgWA['movie']['category2_name']['ko'])
     if 'duration' in nbTvDjESpRtQJCGUkuircyoedzqgWA.get('movie'):nbTvDjESpRtQJCGUkuircyoedzqgPF=nbTvDjESpRtQJCGUkuircyoedzqgWA.get('movie').get('duration')
     if 'release_date' in nbTvDjESpRtQJCGUkuircyoedzqgWA.get('movie'):
      nbTvDjESpRtQJCGUkuircyoedzqgmh=nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgWA.get('movie').get('release_date'))
      if nbTvDjESpRtQJCGUkuircyoedzqgmh!='0':nbTvDjESpRtQJCGUkuircyoedzqgmP='%s-%s-%s'%(nbTvDjESpRtQJCGUkuircyoedzqgmh[:4],nbTvDjESpRtQJCGUkuircyoedzqgmh[4:6],nbTvDjESpRtQJCGUkuircyoedzqgmh[6:])
     if 'production' in nbTvDjESpRtQJCGUkuircyoedzqgWA.get('movie'):nbTvDjESpRtQJCGUkuircyoedzqgmA=nbTvDjESpRtQJCGUkuircyoedzqgWA.get('movie').get('production')
    except:
     nbTvDjESpRtQJCGUkuircyoedzqgla
    nbTvDjESpRtQJCGUkuircyoedzqgmH={'moviecode':nbTvDjESpRtQJCGUkuircyoedzqgmY,'title':nbTvDjESpRtQJCGUkuircyoedzqgVw,'thumbnail':{'poster':nbTvDjESpRtQJCGUkuircyoedzqgVs,'thumb':nbTvDjESpRtQJCGUkuircyoedzqgVa,'clearlogo':nbTvDjESpRtQJCGUkuircyoedzqgVx,'fanart':nbTvDjESpRtQJCGUkuircyoedzqgVa},'synopsis':nbTvDjESpRtQJCGUkuircyoedzqgVM,'info_title':nbTvDjESpRtQJCGUkuircyoedzqgmI,'year':nbTvDjESpRtQJCGUkuircyoedzqgmW,'cast':nbTvDjESpRtQJCGUkuircyoedzqgVA,'director':nbTvDjESpRtQJCGUkuircyoedzqgVY,'info_genre':nbTvDjESpRtQJCGUkuircyoedzqgmF,'duration':nbTvDjESpRtQJCGUkuircyoedzqgPF,'premiered':nbTvDjESpRtQJCGUkuircyoedzqgmP,'studio':nbTvDjESpRtQJCGUkuircyoedzqgmA,'mpaa':nbTvDjESpRtQJCGUkuircyoedzqgmV}
    nbTvDjESpRtQJCGUkuircyoedzqgPW=nbTvDjESpRtQJCGUkuircyoedzqgls
    for nbTvDjESpRtQJCGUkuircyoedzqgPV in nbTvDjESpRtQJCGUkuircyoedzqgWA['billing_package_id']:
     if nbTvDjESpRtQJCGUkuircyoedzqgPV in nbTvDjESpRtQJCGUkuircyoedzqgFP.MOVIE_LITE:
      nbTvDjESpRtQJCGUkuircyoedzqgPW=nbTvDjESpRtQJCGUkuircyoedzqglI
      break
    if nbTvDjESpRtQJCGUkuircyoedzqgPW==nbTvDjESpRtQJCGUkuircyoedzqgls: 
     nbTvDjESpRtQJCGUkuircyoedzqgmH['title']=nbTvDjESpRtQJCGUkuircyoedzqgmH['title']+' [개별구매]'
    nbTvDjESpRtQJCGUkuircyoedzqgVP.append(nbTvDjESpRtQJCGUkuircyoedzqgmH)
   if nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['has_more']=='Y':nbTvDjESpRtQJCGUkuircyoedzqgVl=nbTvDjESpRtQJCGUkuircyoedzqglI
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  return nbTvDjESpRtQJCGUkuircyoedzqgVP,nbTvDjESpRtQJCGUkuircyoedzqgVl
 def GetMovieListGenre(nbTvDjESpRtQJCGUkuircyoedzqgFP,genre,page_int):
  nbTvDjESpRtQJCGUkuircyoedzqgVP=[]
  nbTvDjESpRtQJCGUkuircyoedzqgVl=nbTvDjESpRtQJCGUkuircyoedzqgls
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='/v2/media/movie/curation/'+genre
   nbTvDjESpRtQJCGUkuircyoedzqgWw=nbTvDjESpRtQJCGUkuircyoedzqgFP.GetDefaultParams()
   nbTvDjESpRtQJCGUkuircyoedzqgWM={'pageNo':nbTvDjESpRtQJCGUkuircyoedzqglA(page_int),'pageSize':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.MOVIE_LIMIT),'_':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.GetNoCache(2))}
   nbTvDjESpRtQJCGUkuircyoedzqgWw.update(nbTvDjESpRtQJCGUkuircyoedzqgWM)
   nbTvDjESpRtQJCGUkuircyoedzqgWa=nbTvDjESpRtQJCGUkuircyoedzqgFP.API_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWN
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgWw,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgla)
   nbTvDjESpRtQJCGUkuircyoedzqgWs=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   if not('movies' in nbTvDjESpRtQJCGUkuircyoedzqgWs['body']):return nbTvDjESpRtQJCGUkuircyoedzqgVP,nbTvDjESpRtQJCGUkuircyoedzqgVl
   nbTvDjESpRtQJCGUkuircyoedzqgVf=nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['movies']
   for nbTvDjESpRtQJCGUkuircyoedzqgWA in nbTvDjESpRtQJCGUkuircyoedzqgVf:
    nbTvDjESpRtQJCGUkuircyoedzqgmY =nbTvDjESpRtQJCGUkuircyoedzqgWA['code']
    nbTvDjESpRtQJCGUkuircyoedzqgVw =nbTvDjESpRtQJCGUkuircyoedzqgWA['name']['ko']
    nbTvDjESpRtQJCGUkuircyoedzqgPm =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWA['image'][0]['url']
    for nbTvDjESpRtQJCGUkuircyoedzqgVO in nbTvDjESpRtQJCGUkuircyoedzqgWA['image']:
     if nbTvDjESpRtQJCGUkuircyoedzqgVO['code']=='CAIM2100':
      nbTvDjESpRtQJCGUkuircyoedzqgPm =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO['url']
    nbTvDjESpRtQJCGUkuircyoedzqgVM =nbTvDjESpRtQJCGUkuircyoedzqgWA['story']['ko']
    nbTvDjESpRtQJCGUkuircyoedzqgmH={'moviecode':nbTvDjESpRtQJCGUkuircyoedzqgmY,'title':nbTvDjESpRtQJCGUkuircyoedzqgVw.strip(),'thumbnail':nbTvDjESpRtQJCGUkuircyoedzqgPm,'synopsis':nbTvDjESpRtQJCGUkuircyoedzqgVM}
    nbTvDjESpRtQJCGUkuircyoedzqgVP.append(nbTvDjESpRtQJCGUkuircyoedzqgmH)
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  return nbTvDjESpRtQJCGUkuircyoedzqgVP,nbTvDjESpRtQJCGUkuircyoedzqgVl
 def GetMovieGenre(nbTvDjESpRtQJCGUkuircyoedzqgFP):
  nbTvDjESpRtQJCGUkuircyoedzqgVP=[]
  nbTvDjESpRtQJCGUkuircyoedzqgVl=nbTvDjESpRtQJCGUkuircyoedzqgls
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='/v2/media/movie/curations'
   nbTvDjESpRtQJCGUkuircyoedzqgWw=nbTvDjESpRtQJCGUkuircyoedzqgFP.GetDefaultParams()
   nbTvDjESpRtQJCGUkuircyoedzqgWM={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.GetNoCache(2))}
   nbTvDjESpRtQJCGUkuircyoedzqgWw.update(nbTvDjESpRtQJCGUkuircyoedzqgWM)
   nbTvDjESpRtQJCGUkuircyoedzqgWa=nbTvDjESpRtQJCGUkuircyoedzqgFP.API_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWN
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgWw,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgla)
   nbTvDjESpRtQJCGUkuircyoedzqgWs=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   if not('result' in nbTvDjESpRtQJCGUkuircyoedzqgWs['body']):return nbTvDjESpRtQJCGUkuircyoedzqgVP,nbTvDjESpRtQJCGUkuircyoedzqgVl
   nbTvDjESpRtQJCGUkuircyoedzqgVf=nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['result']
   for nbTvDjESpRtQJCGUkuircyoedzqgWA in nbTvDjESpRtQJCGUkuircyoedzqgVf:
    nbTvDjESpRtQJCGUkuircyoedzqgPl =nbTvDjESpRtQJCGUkuircyoedzqgWA['curation_code']
    nbTvDjESpRtQJCGUkuircyoedzqgPK =nbTvDjESpRtQJCGUkuircyoedzqgWA['curation_name']
    nbTvDjESpRtQJCGUkuircyoedzqgmH={'curation_code':nbTvDjESpRtQJCGUkuircyoedzqgPl,'curation_name':nbTvDjESpRtQJCGUkuircyoedzqgPK}
    nbTvDjESpRtQJCGUkuircyoedzqgVP.append(nbTvDjESpRtQJCGUkuircyoedzqgmH)
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  return nbTvDjESpRtQJCGUkuircyoedzqgVP,nbTvDjESpRtQJCGUkuircyoedzqgVl
 def GetSearchList(nbTvDjESpRtQJCGUkuircyoedzqgFP,search_key,page_int,stype):
  nbTvDjESpRtQJCGUkuircyoedzqgPh=[]
  nbTvDjESpRtQJCGUkuircyoedzqgVl=nbTvDjESpRtQJCGUkuircyoedzqgls
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='/search/getSearch.jsp'
   nbTvDjESpRtQJCGUkuircyoedzqgWM={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':nbTvDjESpRtQJCGUkuircyoedzqglA(page_int),'pageSize':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':nbTvDjESpRtQJCGUkuircyoedzqgFP.SCREENCODE,'os':nbTvDjESpRtQJCGUkuircyoedzqgFP.OSCODE,'network':nbTvDjESpRtQJCGUkuircyoedzqgFP.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.GetNoCache(2))}
   nbTvDjESpRtQJCGUkuircyoedzqgWa=nbTvDjESpRtQJCGUkuircyoedzqgFP.SEARCH_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWN
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgWM,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgla)
   nbTvDjESpRtQJCGUkuircyoedzqgWs=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   if stype=='vod':
    if not('programRsb' in nbTvDjESpRtQJCGUkuircyoedzqgWs):return nbTvDjESpRtQJCGUkuircyoedzqgPh,nbTvDjESpRtQJCGUkuircyoedzqgVl
    nbTvDjESpRtQJCGUkuircyoedzqgPf=nbTvDjESpRtQJCGUkuircyoedzqgWs['programRsb']['dataList']
    nbTvDjESpRtQJCGUkuircyoedzqgPH =nbTvDjESpRtQJCGUkuircyoedzqglx(nbTvDjESpRtQJCGUkuircyoedzqgWs['programRsb']['count'])
    for nbTvDjESpRtQJCGUkuircyoedzqgWA in nbTvDjESpRtQJCGUkuircyoedzqgPf:
     nbTvDjESpRtQJCGUkuircyoedzqgmB=nbTvDjESpRtQJCGUkuircyoedzqgWA['mast_cd']
     nbTvDjESpRtQJCGUkuircyoedzqgVw =nbTvDjESpRtQJCGUkuircyoedzqgWA['mast_nm']
     nbTvDjESpRtQJCGUkuircyoedzqgVs=nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWA['web_url4']
     nbTvDjESpRtQJCGUkuircyoedzqgVa =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWA['web_url']
     try:
      nbTvDjESpRtQJCGUkuircyoedzqgVA =[]
      nbTvDjESpRtQJCGUkuircyoedzqgVY=[]
      nbTvDjESpRtQJCGUkuircyoedzqgmF =[]
      nbTvDjESpRtQJCGUkuircyoedzqgPF =0
      nbTvDjESpRtQJCGUkuircyoedzqgmV =''
      nbTvDjESpRtQJCGUkuircyoedzqgmW =''
      nbTvDjESpRtQJCGUkuircyoedzqgmO =''
      if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('actor') !='' and nbTvDjESpRtQJCGUkuircyoedzqgWA.get('actor') !='-':nbTvDjESpRtQJCGUkuircyoedzqgVA =nbTvDjESpRtQJCGUkuircyoedzqgWA.get('actor').split(',')
      if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('director')!='' and nbTvDjESpRtQJCGUkuircyoedzqgWA.get('director')!='-':nbTvDjESpRtQJCGUkuircyoedzqgVY=nbTvDjESpRtQJCGUkuircyoedzqgWA.get('director').split(',')
      if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('cate_nm')!='' and nbTvDjESpRtQJCGUkuircyoedzqgWA.get('cate_nm')!='-':nbTvDjESpRtQJCGUkuircyoedzqgmF =nbTvDjESpRtQJCGUkuircyoedzqgWA.get('cate_nm').split('/')
      if 'targetage' in nbTvDjESpRtQJCGUkuircyoedzqgWA:nbTvDjESpRtQJCGUkuircyoedzqgmV=nbTvDjESpRtQJCGUkuircyoedzqgWA.get('targetage')
      if 'broad_dt' in nbTvDjESpRtQJCGUkuircyoedzqgWA:
       nbTvDjESpRtQJCGUkuircyoedzqgmh=nbTvDjESpRtQJCGUkuircyoedzqgWA.get('broad_dt')
       nbTvDjESpRtQJCGUkuircyoedzqgmO='%s-%s-%s'%(nbTvDjESpRtQJCGUkuircyoedzqgmh[:4],nbTvDjESpRtQJCGUkuircyoedzqgmh[4:6],nbTvDjESpRtQJCGUkuircyoedzqgmh[6:])
       nbTvDjESpRtQJCGUkuircyoedzqgmW =nbTvDjESpRtQJCGUkuircyoedzqgmh[:4]
     except:
      nbTvDjESpRtQJCGUkuircyoedzqgla
     nbTvDjESpRtQJCGUkuircyoedzqgmH={'program':nbTvDjESpRtQJCGUkuircyoedzqgmB,'title':nbTvDjESpRtQJCGUkuircyoedzqgVw,'thumbnail':{'poster':nbTvDjESpRtQJCGUkuircyoedzqgVs,'thumb':nbTvDjESpRtQJCGUkuircyoedzqgVa,'fanart':nbTvDjESpRtQJCGUkuircyoedzqgVa},'synopsis':'','cast':nbTvDjESpRtQJCGUkuircyoedzqgVA,'director':nbTvDjESpRtQJCGUkuircyoedzqgVY,'info_genre':nbTvDjESpRtQJCGUkuircyoedzqgmF,'duration':nbTvDjESpRtQJCGUkuircyoedzqgPF,'mpaa':nbTvDjESpRtQJCGUkuircyoedzqgmV,'year':nbTvDjESpRtQJCGUkuircyoedzqgmW,'aired':nbTvDjESpRtQJCGUkuircyoedzqgmO}
     nbTvDjESpRtQJCGUkuircyoedzqgPh.append(nbTvDjESpRtQJCGUkuircyoedzqgmH)
   else:
    if not('vodMVRsb' in nbTvDjESpRtQJCGUkuircyoedzqgWs):return nbTvDjESpRtQJCGUkuircyoedzqgPh,nbTvDjESpRtQJCGUkuircyoedzqgVl
    nbTvDjESpRtQJCGUkuircyoedzqgPB=nbTvDjESpRtQJCGUkuircyoedzqgWs['vodMVRsb']['dataList']
    nbTvDjESpRtQJCGUkuircyoedzqgPH =nbTvDjESpRtQJCGUkuircyoedzqglx(nbTvDjESpRtQJCGUkuircyoedzqgWs['vodMVRsb']['count'])
    for nbTvDjESpRtQJCGUkuircyoedzqgWA in nbTvDjESpRtQJCGUkuircyoedzqgPB:
     nbTvDjESpRtQJCGUkuircyoedzqgmB=nbTvDjESpRtQJCGUkuircyoedzqgWA['mast_cd']
     nbTvDjESpRtQJCGUkuircyoedzqgVw =nbTvDjESpRtQJCGUkuircyoedzqgWA['mast_nm'].strip()
     nbTvDjESpRtQJCGUkuircyoedzqgVs =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWA['web_url']
     nbTvDjESpRtQJCGUkuircyoedzqgVa =nbTvDjESpRtQJCGUkuircyoedzqgVs
     nbTvDjESpRtQJCGUkuircyoedzqgVx=''
     try:
      nbTvDjESpRtQJCGUkuircyoedzqgVA =[]
      nbTvDjESpRtQJCGUkuircyoedzqgVY=[]
      nbTvDjESpRtQJCGUkuircyoedzqgmF =[]
      nbTvDjESpRtQJCGUkuircyoedzqgPF =0
      nbTvDjESpRtQJCGUkuircyoedzqgmV =''
      nbTvDjESpRtQJCGUkuircyoedzqgmW =''
      nbTvDjESpRtQJCGUkuircyoedzqgmO =''
      if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('actor') !='' and nbTvDjESpRtQJCGUkuircyoedzqgWA.get('actor') !='-':nbTvDjESpRtQJCGUkuircyoedzqgVA =nbTvDjESpRtQJCGUkuircyoedzqgWA.get('actor').split(',')
      if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('director')!='' and nbTvDjESpRtQJCGUkuircyoedzqgWA.get('director')!='-':nbTvDjESpRtQJCGUkuircyoedzqgVY=nbTvDjESpRtQJCGUkuircyoedzqgWA.get('director').split(',')
      if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('cate_nm')!='' and nbTvDjESpRtQJCGUkuircyoedzqgWA.get('cate_nm')!='-':nbTvDjESpRtQJCGUkuircyoedzqgmF =nbTvDjESpRtQJCGUkuircyoedzqgWA.get('cate_nm').split('/')
      if nbTvDjESpRtQJCGUkuircyoedzqgWA.get('runtime_sec')!='':nbTvDjESpRtQJCGUkuircyoedzqgPF=nbTvDjESpRtQJCGUkuircyoedzqgWA.get('runtime_sec')
      if 'grade_nm' in nbTvDjESpRtQJCGUkuircyoedzqgWA:nbTvDjESpRtQJCGUkuircyoedzqgmV=nbTvDjESpRtQJCGUkuircyoedzqgWA.get('grade_nm')
      nbTvDjESpRtQJCGUkuircyoedzqgmh=nbTvDjESpRtQJCGUkuircyoedzqgWA.get('broad_dt')
      if data_str!='':
       nbTvDjESpRtQJCGUkuircyoedzqgmO='%s-%s-%s'%(nbTvDjESpRtQJCGUkuircyoedzqgmh[:4],nbTvDjESpRtQJCGUkuircyoedzqgmh[4:6],nbTvDjESpRtQJCGUkuircyoedzqgmh[6:])
       nbTvDjESpRtQJCGUkuircyoedzqgmW =nbTvDjESpRtQJCGUkuircyoedzqgmh[:4]
     except:
      nbTvDjESpRtQJCGUkuircyoedzqgla
     nbTvDjESpRtQJCGUkuircyoedzqgmH={'movie':nbTvDjESpRtQJCGUkuircyoedzqgmB,'title':nbTvDjESpRtQJCGUkuircyoedzqgVw,'thumbnail':{'poster':nbTvDjESpRtQJCGUkuircyoedzqgVs,'thumb':nbTvDjESpRtQJCGUkuircyoedzqgVa,'fanart':nbTvDjESpRtQJCGUkuircyoedzqgVa,'clearlogo':nbTvDjESpRtQJCGUkuircyoedzqgVx},'synopsis':'','cast':nbTvDjESpRtQJCGUkuircyoedzqgVA,'director':nbTvDjESpRtQJCGUkuircyoedzqgVY,'info_genre':nbTvDjESpRtQJCGUkuircyoedzqgmF,'duration':nbTvDjESpRtQJCGUkuircyoedzqgPF,'mpaa':nbTvDjESpRtQJCGUkuircyoedzqgmV,'year':nbTvDjESpRtQJCGUkuircyoedzqgmW,'aired':nbTvDjESpRtQJCGUkuircyoedzqgmO}
     nbTvDjESpRtQJCGUkuircyoedzqgPW=nbTvDjESpRtQJCGUkuircyoedzqgls
     for nbTvDjESpRtQJCGUkuircyoedzqgPV in nbTvDjESpRtQJCGUkuircyoedzqgWA['bill']:
      if nbTvDjESpRtQJCGUkuircyoedzqgPV in nbTvDjESpRtQJCGUkuircyoedzqgFP.MOVIE_LITE:
       nbTvDjESpRtQJCGUkuircyoedzqgPW=nbTvDjESpRtQJCGUkuircyoedzqglI
       break
     if nbTvDjESpRtQJCGUkuircyoedzqgPW==nbTvDjESpRtQJCGUkuircyoedzqgls: 
      nbTvDjESpRtQJCGUkuircyoedzqgmH['title']=nbTvDjESpRtQJCGUkuircyoedzqgmH['title']+' [개별구매]'
     nbTvDjESpRtQJCGUkuircyoedzqgPh.append(nbTvDjESpRtQJCGUkuircyoedzqgmH)
   if nbTvDjESpRtQJCGUkuircyoedzqgPH>(page_int*nbTvDjESpRtQJCGUkuircyoedzqgFP.SEARCH_LIMIT):nbTvDjESpRtQJCGUkuircyoedzqgVl=nbTvDjESpRtQJCGUkuircyoedzqglI
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  return nbTvDjESpRtQJCGUkuircyoedzqgPh,nbTvDjESpRtQJCGUkuircyoedzqgVl
 def GetDeviceList(nbTvDjESpRtQJCGUkuircyoedzqgFP,nbTvDjESpRtQJCGUkuircyoedzqgWF,nbTvDjESpRtQJCGUkuircyoedzqgWV):
  nbTvDjESpRtQJCGUkuircyoedzqgVP=[]
  nbTvDjESpRtQJCGUkuircyoedzqgWf='-'
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='/v1/user/device/list'
   nbTvDjESpRtQJCGUkuircyoedzqgPN=nbTvDjESpRtQJCGUkuircyoedzqgFP.API_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWN
   nbTvDjESpRtQJCGUkuircyoedzqgWM={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   nbTvDjESpRtQJCGUkuircyoedzqgFh=nbTvDjESpRtQJCGUkuircyoedzqgFP.makeDefaultCookies(vToken=nbTvDjESpRtQJCGUkuircyoedzqgWF,vUserinfo=nbTvDjESpRtQJCGUkuircyoedzqgWV)
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgPN,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgWM,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgFh)
   nbTvDjESpRtQJCGUkuircyoedzqgWs=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   nbTvDjESpRtQJCGUkuircyoedzqglL(nbTvDjESpRtQJCGUkuircyoedzqgWs)
   nbTvDjESpRtQJCGUkuircyoedzqgVP=nbTvDjESpRtQJCGUkuircyoedzqgWs['body']
   for nbTvDjESpRtQJCGUkuircyoedzqgWA in nbTvDjESpRtQJCGUkuircyoedzqgVP:
    if nbTvDjESpRtQJCGUkuircyoedzqgWA['model']=='PC' or nbTvDjESpRtQJCGUkuircyoedzqgWA['model']=='PC-Chrome':
     nbTvDjESpRtQJCGUkuircyoedzqgWf=nbTvDjESpRtQJCGUkuircyoedzqgWA['uuid']
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  return nbTvDjESpRtQJCGUkuircyoedzqgWf
 def GetProfileToken(nbTvDjESpRtQJCGUkuircyoedzqgFP,nbTvDjESpRtQJCGUkuircyoedzqgWF,nbTvDjESpRtQJCGUkuircyoedzqgWV,user_pf):
  nbTvDjESpRtQJCGUkuircyoedzqgPw=[]
  nbTvDjESpRtQJCGUkuircyoedzqgPM =''
  nbTvDjESpRtQJCGUkuircyoedzqgPa =''
  nbTvDjESpRtQJCGUkuircyoedzqgPs='Y'
  nbTvDjESpRtQJCGUkuircyoedzqgPx ='N'
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   nbTvDjESpRtQJCGUkuircyoedzqgFh=nbTvDjESpRtQJCGUkuircyoedzqgFP.makeDefaultCookies(vToken=nbTvDjESpRtQJCGUkuircyoedzqgWF,vUserinfo=nbTvDjESpRtQJCGUkuircyoedzqgWV)
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWN,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgla,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgFh)
   nbTvDjESpRtQJCGUkuircyoedzqgPw =re.findall('data-profile-no="\d+"',nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   for i in nbTvDjESpRtQJCGUkuircyoedzqglX(nbTvDjESpRtQJCGUkuircyoedzqgKF(nbTvDjESpRtQJCGUkuircyoedzqgPw)):
    nbTvDjESpRtQJCGUkuircyoedzqgPX =nbTvDjESpRtQJCGUkuircyoedzqgPw[i].replace('data-profile-no=','').replace('"','')
    nbTvDjESpRtQJCGUkuircyoedzqgPw[i]=nbTvDjESpRtQJCGUkuircyoedzqgPX
   nbTvDjESpRtQJCGUkuircyoedzqgPM=nbTvDjESpRtQJCGUkuircyoedzqgPw[user_pf]
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
   return nbTvDjESpRtQJCGUkuircyoedzqgPa,nbTvDjESpRtQJCGUkuircyoedzqgPs,nbTvDjESpRtQJCGUkuircyoedzqgPx
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   nbTvDjESpRtQJCGUkuircyoedzqgFh=nbTvDjESpRtQJCGUkuircyoedzqgFP.makeDefaultCookies(vToken=nbTvDjESpRtQJCGUkuircyoedzqgWF,vUserinfo=nbTvDjESpRtQJCGUkuircyoedzqgWV)
   nbTvDjESpRtQJCGUkuircyoedzqgFO={'profileNo':nbTvDjESpRtQJCGUkuircyoedzqgPM}
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Post',nbTvDjESpRtQJCGUkuircyoedzqgWN,payload=nbTvDjESpRtQJCGUkuircyoedzqgFO,params=nbTvDjESpRtQJCGUkuircyoedzqgla,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgFh)
   for nbTvDjESpRtQJCGUkuircyoedzqgFY in nbTvDjESpRtQJCGUkuircyoedzqgFA.cookies:
    if nbTvDjESpRtQJCGUkuircyoedzqgFY.name=='_tving_token':
     nbTvDjESpRtQJCGUkuircyoedzqgPa=nbTvDjESpRtQJCGUkuircyoedzqgFY.value
    elif nbTvDjESpRtQJCGUkuircyoedzqgFY.name==nbTvDjESpRtQJCGUkuircyoedzqgFP.GLOBAL_COOKIENM['tv_cookiekey']:
     nbTvDjESpRtQJCGUkuircyoedzqgPs=nbTvDjESpRtQJCGUkuircyoedzqgFY.value
    elif nbTvDjESpRtQJCGUkuircyoedzqgFY.name==nbTvDjESpRtQJCGUkuircyoedzqgFP.GLOBAL_COOKIENM['tv_lockkey']:
     nbTvDjESpRtQJCGUkuircyoedzqgPx=nbTvDjESpRtQJCGUkuircyoedzqgFY.value
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  return nbTvDjESpRtQJCGUkuircyoedzqgPa,nbTvDjESpRtQJCGUkuircyoedzqgPs,nbTvDjESpRtQJCGUkuircyoedzqgPx
 def GetProfileLockYN(nbTvDjESpRtQJCGUkuircyoedzqgFP,nbTvDjESpRtQJCGUkuircyoedzqgWF,nbTvDjESpRtQJCGUkuircyoedzqgWV):
  nbTvDjESpRtQJCGUkuircyoedzqgPw=[]
  nbTvDjESpRtQJCGUkuircyoedzqgPx ='N'
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='/profile/select.do'
   nbTvDjESpRtQJCGUkuircyoedzqgPN=nbTvDjESpRtQJCGUkuircyoedzqgFP.URL_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWN
   nbTvDjESpRtQJCGUkuircyoedzqgFh=nbTvDjESpRtQJCGUkuircyoedzqgFP.makeDefaultCookies(vToken=nbTvDjESpRtQJCGUkuircyoedzqgWF,vUserinfo=nbTvDjESpRtQJCGUkuircyoedzqgWV)
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgPN,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgla,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgFh)
   nbTvDjESpRtQJCGUkuircyoedzqgPw =re.findall('data-profile-no="\d+"',nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   for i in nbTvDjESpRtQJCGUkuircyoedzqglX(nbTvDjESpRtQJCGUkuircyoedzqgKF(nbTvDjESpRtQJCGUkuircyoedzqgPw)):
    nbTvDjESpRtQJCGUkuircyoedzqgPX =nbTvDjESpRtQJCGUkuircyoedzqgPw[i].replace('data-profile-no=','').replace('"','')
    nbTvDjESpRtQJCGUkuircyoedzqgPw[i]=nbTvDjESpRtQJCGUkuircyoedzqgPX
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
   return nbTvDjESpRtQJCGUkuircyoedzqgPx
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='/profile/api/select.do'
   nbTvDjESpRtQJCGUkuircyoedzqgPN=nbTvDjESpRtQJCGUkuircyoedzqgFP.URL_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWN
   nbTvDjESpRtQJCGUkuircyoedzqgFh=nbTvDjESpRtQJCGUkuircyoedzqgFP.makeDefaultCookies(vToken=nbTvDjESpRtQJCGUkuircyoedzqgWF,vUserinfo=nbTvDjESpRtQJCGUkuircyoedzqgWV)
   for i in nbTvDjESpRtQJCGUkuircyoedzqglX(nbTvDjESpRtQJCGUkuircyoedzqgKF(nbTvDjESpRtQJCGUkuircyoedzqgPw)):
    nbTvDjESpRtQJCGUkuircyoedzqgFO={'profileNo':nbTvDjESpRtQJCGUkuircyoedzqgPw[i]}
    nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Post',nbTvDjESpRtQJCGUkuircyoedzqgPN,payload=nbTvDjESpRtQJCGUkuircyoedzqgFO,params=nbTvDjESpRtQJCGUkuircyoedzqgla,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgFh)
    for nbTvDjESpRtQJCGUkuircyoedzqgFY in nbTvDjESpRtQJCGUkuircyoedzqgFA.cookies:
     if nbTvDjESpRtQJCGUkuircyoedzqgFY.name=='_tving_token':
      nbTvDjESpRtQJCGUkuircyoedzqgPI=nbTvDjESpRtQJCGUkuircyoedzqgFY.value
     elif nbTvDjESpRtQJCGUkuircyoedzqgFY.name==nbTvDjESpRtQJCGUkuircyoedzqgFP.GLOBAL_COOKIENM['tv_lockkey']:
      nbTvDjESpRtQJCGUkuircyoedzqgPL=nbTvDjESpRtQJCGUkuircyoedzqgFY.value
    if nbTvDjESpRtQJCGUkuircyoedzqgPI==nbTvDjESpRtQJCGUkuircyoedzqgWF:
     nbTvDjESpRtQJCGUkuircyoedzqgPx=nbTvDjESpRtQJCGUkuircyoedzqgPL
     nbTvDjESpRtQJCGUkuircyoedzqglL(nbTvDjESpRtQJCGUkuircyoedzqgWF)
     break
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  return nbTvDjESpRtQJCGUkuircyoedzqgPx
 def GetBookmarkInfo(nbTvDjESpRtQJCGUkuircyoedzqgFP,videoid,vidtype):
  nbTvDjESpRtQJCGUkuircyoedzqgPO={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   nbTvDjESpRtQJCGUkuircyoedzqgWa=nbTvDjESpRtQJCGUkuircyoedzqgFP.API_DOMAIN+'/v2/media/program/'+videoid
   nbTvDjESpRtQJCGUkuircyoedzqgWw=nbTvDjESpRtQJCGUkuircyoedzqgFP.GetDefaultParams()
   nbTvDjESpRtQJCGUkuircyoedzqgWM={'pageNo':'1','pageSize':'10','order':'name',}
   nbTvDjESpRtQJCGUkuircyoedzqgWw.update(nbTvDjESpRtQJCGUkuircyoedzqgWM)
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgWw,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgla)
   nbTvDjESpRtQJCGUkuircyoedzqgPA=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   if not('body' in nbTvDjESpRtQJCGUkuircyoedzqgPA):return{}
   nbTvDjESpRtQJCGUkuircyoedzqgPY=nbTvDjESpRtQJCGUkuircyoedzqgPA['body']
   nbTvDjESpRtQJCGUkuircyoedzqgVw=nbTvDjESpRtQJCGUkuircyoedzqgPY.get('name').get('ko').strip()
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['title'] =nbTvDjESpRtQJCGUkuircyoedzqgVw
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['title']=nbTvDjESpRtQJCGUkuircyoedzqgVw
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['mpaa'] =nbTvDjESpRtQJCGUkuircyoedzqgFm.get(nbTvDjESpRtQJCGUkuircyoedzqgPY.get('grade_code'))
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['plot'] =nbTvDjESpRtQJCGUkuircyoedzqgPY.get('synopsis').get('ko')
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['year'] =nbTvDjESpRtQJCGUkuircyoedzqgPY.get('product_year')
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['cast'] =nbTvDjESpRtQJCGUkuircyoedzqgPY.get('actor')
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['director']=nbTvDjESpRtQJCGUkuircyoedzqgPY.get('director')
   if nbTvDjESpRtQJCGUkuircyoedzqgPY.get('category1_name').get('ko')!='':
    nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['genre'].append(nbTvDjESpRtQJCGUkuircyoedzqgPY.get('category1_name').get('ko'))
   if nbTvDjESpRtQJCGUkuircyoedzqgPY.get('category2_name').get('ko')!='':
    nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['genre'].append(nbTvDjESpRtQJCGUkuircyoedzqgPY.get('category2_name').get('ko'))
   nbTvDjESpRtQJCGUkuircyoedzqgmh=nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgPY.get('broad_dt'))
   if nbTvDjESpRtQJCGUkuircyoedzqgmh!='0':nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(nbTvDjESpRtQJCGUkuircyoedzqgmh[:4],nbTvDjESpRtQJCGUkuircyoedzqgmh[4:6],nbTvDjESpRtQJCGUkuircyoedzqgmh[6:])
   nbTvDjESpRtQJCGUkuircyoedzqgVs =''
   nbTvDjESpRtQJCGUkuircyoedzqgVa =''
   nbTvDjESpRtQJCGUkuircyoedzqgVx=''
   nbTvDjESpRtQJCGUkuircyoedzqgVX =''
   nbTvDjESpRtQJCGUkuircyoedzqgVI =''
   for nbTvDjESpRtQJCGUkuircyoedzqgVO in nbTvDjESpRtQJCGUkuircyoedzqgPY.get('image'):
    if nbTvDjESpRtQJCGUkuircyoedzqgVO.get('code')=='CAIP0900':nbTvDjESpRtQJCGUkuircyoedzqgVs =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO.get('url')
    elif nbTvDjESpRtQJCGUkuircyoedzqgVO.get('code')=='CAIP0200':nbTvDjESpRtQJCGUkuircyoedzqgVa =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO.get('url')
    elif nbTvDjESpRtQJCGUkuircyoedzqgVO.get('code')=='CAIP1800':nbTvDjESpRtQJCGUkuircyoedzqgVx=nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO.get('url')
    elif nbTvDjESpRtQJCGUkuircyoedzqgVO.get('code')=='CAIP2000':nbTvDjESpRtQJCGUkuircyoedzqgVX =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO.get('url')
    elif nbTvDjESpRtQJCGUkuircyoedzqgVO.get('code')=='CAIP1900':nbTvDjESpRtQJCGUkuircyoedzqgVI =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO.get('url')
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['thumbnail']['poster']=nbTvDjESpRtQJCGUkuircyoedzqgVs
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['thumbnail']['thumb']=nbTvDjESpRtQJCGUkuircyoedzqgVa
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['thumbnail']['clearlogo']=nbTvDjESpRtQJCGUkuircyoedzqgVx
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['thumbnail']['icon']=nbTvDjESpRtQJCGUkuircyoedzqgVX
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['thumbnail']['banner']=nbTvDjESpRtQJCGUkuircyoedzqgVI
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['thumbnail']['fanart']=nbTvDjESpRtQJCGUkuircyoedzqgVa
  else:
   nbTvDjESpRtQJCGUkuircyoedzqgWa=nbTvDjESpRtQJCGUkuircyoedzqgFP.API_DOMAIN+'/v2a/media/stream/info'
   nbTvDjESpRtQJCGUkuircyoedzqgWw=nbTvDjESpRtQJCGUkuircyoedzqgFP.GetDefaultParams()
   nbTvDjESpRtQJCGUkuircyoedzqgWM={'info':'Y','mediaCode':videoid,'noCache':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':'','uuid':'','deviceInfo':'PC','wm':'Y',}
   nbTvDjESpRtQJCGUkuircyoedzqgWw.update(nbTvDjESpRtQJCGUkuircyoedzqgWM)
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgWw,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgla)
   nbTvDjESpRtQJCGUkuircyoedzqgPA=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   if not('content' in nbTvDjESpRtQJCGUkuircyoedzqgPA['body']):return{}
   nbTvDjESpRtQJCGUkuircyoedzqgPY=nbTvDjESpRtQJCGUkuircyoedzqgPA['body']['content']['info']['movie']
   nbTvDjESpRtQJCGUkuircyoedzqgVw =nbTvDjESpRtQJCGUkuircyoedzqgPY.get('name').get('ko').strip()
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['title']=nbTvDjESpRtQJCGUkuircyoedzqgVw
   nbTvDjESpRtQJCGUkuircyoedzqgVw +=u' (%s)'%(nbTvDjESpRtQJCGUkuircyoedzqgPY.get('product_year'))
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['title'] =nbTvDjESpRtQJCGUkuircyoedzqgVw
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['mpaa'] =nbTvDjESpRtQJCGUkuircyoedzqgFm.get(nbTvDjESpRtQJCGUkuircyoedzqgPY.get('grade_code'))
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['plot'] =nbTvDjESpRtQJCGUkuircyoedzqgPY.get('story').get('ko')
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['year'] =nbTvDjESpRtQJCGUkuircyoedzqgPY.get('product_year')
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['studio'] =nbTvDjESpRtQJCGUkuircyoedzqgPY.get('production')
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['duration']=nbTvDjESpRtQJCGUkuircyoedzqgPY.get('duration')
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['cast'] =nbTvDjESpRtQJCGUkuircyoedzqgPY.get('actor')
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['director']=nbTvDjESpRtQJCGUkuircyoedzqgPY.get('director')
   if nbTvDjESpRtQJCGUkuircyoedzqgPY.get('category1_name').get('ko')!='':
    nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['genre'].append(nbTvDjESpRtQJCGUkuircyoedzqgPY.get('category1_name').get('ko'))
   if nbTvDjESpRtQJCGUkuircyoedzqgPY.get('category2_name').get('ko')!='':
    nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['genre'].append(nbTvDjESpRtQJCGUkuircyoedzqgPY.get('category2_name').get('ko'))
   nbTvDjESpRtQJCGUkuircyoedzqgmh=nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgPY.get('release_date'))
   if nbTvDjESpRtQJCGUkuircyoedzqgmh!='0':nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(nbTvDjESpRtQJCGUkuircyoedzqgmh[:4],nbTvDjESpRtQJCGUkuircyoedzqgmh[4:6],nbTvDjESpRtQJCGUkuircyoedzqgmh[6:])
   nbTvDjESpRtQJCGUkuircyoedzqgVs=''
   nbTvDjESpRtQJCGUkuircyoedzqgVa =''
   nbTvDjESpRtQJCGUkuircyoedzqgVx=''
   for nbTvDjESpRtQJCGUkuircyoedzqgVO in nbTvDjESpRtQJCGUkuircyoedzqgPY.get('image'):
    if nbTvDjESpRtQJCGUkuircyoedzqgVO.get('code')=='CAIM2100':nbTvDjESpRtQJCGUkuircyoedzqgVs =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO.get('url')
    elif nbTvDjESpRtQJCGUkuircyoedzqgVO.get('code')=='CAIM0400':nbTvDjESpRtQJCGUkuircyoedzqgVa =nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO.get('url')
    elif nbTvDjESpRtQJCGUkuircyoedzqgVO.get('code')=='CAIM1800':nbTvDjESpRtQJCGUkuircyoedzqgVx=nbTvDjESpRtQJCGUkuircyoedzqgFP.IMG_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgVO.get('url')
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['thumbnail']['poster']=nbTvDjESpRtQJCGUkuircyoedzqgVs
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['thumbnail']['thumb']=nbTvDjESpRtQJCGUkuircyoedzqgVs 
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['thumbnail']['clearlogo']=nbTvDjESpRtQJCGUkuircyoedzqgVx
   nbTvDjESpRtQJCGUkuircyoedzqgPO['saveinfo']['thumbnail']['fanart']=nbTvDjESpRtQJCGUkuircyoedzqgVa
  return nbTvDjESpRtQJCGUkuircyoedzqgPO
 def GetEuroChannelList(nbTvDjESpRtQJCGUkuircyoedzqgFP):
  nbTvDjESpRtQJCGUkuircyoedzqgVP=[]
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWN ='/v2/operator/highlights'
   nbTvDjESpRtQJCGUkuircyoedzqgWw=nbTvDjESpRtQJCGUkuircyoedzqgFP.GetDefaultParams()
   nbTvDjESpRtQJCGUkuircyoedzqgWM={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':nbTvDjESpRtQJCGUkuircyoedzqglA(nbTvDjESpRtQJCGUkuircyoedzqgFP.GetNoCache(2))}
   nbTvDjESpRtQJCGUkuircyoedzqgWw.update(nbTvDjESpRtQJCGUkuircyoedzqgWM)
   nbTvDjESpRtQJCGUkuircyoedzqgWa=nbTvDjESpRtQJCGUkuircyoedzqgFP.API_DOMAIN+nbTvDjESpRtQJCGUkuircyoedzqgWN
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgWw,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgla)
   nbTvDjESpRtQJCGUkuircyoedzqgWs=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   if not('result' in nbTvDjESpRtQJCGUkuircyoedzqgWs['body']):return nbTvDjESpRtQJCGUkuircyoedzqgVP,nbTvDjESpRtQJCGUkuircyoedzqgVl
   nbTvDjESpRtQJCGUkuircyoedzqgVf=nbTvDjESpRtQJCGUkuircyoedzqgWs['body']['result']
   nbTvDjESpRtQJCGUkuircyoedzqglF =nbTvDjESpRtQJCGUkuircyoedzqgFP.Get_Now_Datetime()
   nbTvDjESpRtQJCGUkuircyoedzqglW=nbTvDjESpRtQJCGUkuircyoedzqglF+datetime.timedelta(days=-1)
   nbTvDjESpRtQJCGUkuircyoedzqglW=nbTvDjESpRtQJCGUkuircyoedzqglx(nbTvDjESpRtQJCGUkuircyoedzqglW.strftime('%Y%m%d'))
   for nbTvDjESpRtQJCGUkuircyoedzqgWA in nbTvDjESpRtQJCGUkuircyoedzqgVf:
    nbTvDjESpRtQJCGUkuircyoedzqglV=nbTvDjESpRtQJCGUkuircyoedzqglx(nbTvDjESpRtQJCGUkuircyoedzqgWA.get('content').get('banner_title2')[:8])
    if nbTvDjESpRtQJCGUkuircyoedzqglW<=nbTvDjESpRtQJCGUkuircyoedzqglV:
     nbTvDjESpRtQJCGUkuircyoedzqgmH={'channel':nbTvDjESpRtQJCGUkuircyoedzqgWA.get('content').get('banner_sub_title3'),'title':nbTvDjESpRtQJCGUkuircyoedzqgWA.get('content').get('banner_title'),'subtitle':nbTvDjESpRtQJCGUkuircyoedzqgWA.get('content').get('banner_sub_title2'),}
     nbTvDjESpRtQJCGUkuircyoedzqgVP.append(nbTvDjESpRtQJCGUkuircyoedzqgmH)
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  return nbTvDjESpRtQJCGUkuircyoedzqgVP
 def Make_DecryptKey(nbTvDjESpRtQJCGUkuircyoedzqgFP,step,mediacode='000',timecode='000'):
  if step=='1':
   nbTvDjESpRtQJCGUkuircyoedzqglm=nbTvDjESpRtQJCGUkuircyoedzqgKW('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   nbTvDjESpRtQJCGUkuircyoedzqglP=nbTvDjESpRtQJCGUkuircyoedzqgKW('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   nbTvDjESpRtQJCGUkuircyoedzqglm=nbTvDjESpRtQJCGUkuircyoedzqgKW('kss2lym0kdw1lks3','utf-8')
   nbTvDjESpRtQJCGUkuircyoedzqglP=nbTvDjESpRtQJCGUkuircyoedzqgKW([nbTvDjESpRtQJCGUkuircyoedzqgKV('*'),0x07,nbTvDjESpRtQJCGUkuircyoedzqgKV('r'),nbTvDjESpRtQJCGUkuircyoedzqgKV(';'),nbTvDjESpRtQJCGUkuircyoedzqgKV('7'),0x05,0x1e,0x01,nbTvDjESpRtQJCGUkuircyoedzqgKV('n'),nbTvDjESpRtQJCGUkuircyoedzqgKV('D'),0x02,nbTvDjESpRtQJCGUkuircyoedzqgKV('3'),nbTvDjESpRtQJCGUkuircyoedzqgKV('*'),nbTvDjESpRtQJCGUkuircyoedzqgKV('a'),nbTvDjESpRtQJCGUkuircyoedzqgKV('&'),nbTvDjESpRtQJCGUkuircyoedzqgKV('<')])
  return nbTvDjESpRtQJCGUkuircyoedzqglm,nbTvDjESpRtQJCGUkuircyoedzqglP
 def DecryptPlaintext(nbTvDjESpRtQJCGUkuircyoedzqgFP,ciphertext,encryption_key,init_vector):
  nbTvDjESpRtQJCGUkuircyoedzqglK=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  nbTvDjESpRtQJCGUkuircyoedzqglh=Padding.unpad(nbTvDjESpRtQJCGUkuircyoedzqglK.decrypt(base64.standard_b64decode(ciphertext)),16)
  return nbTvDjESpRtQJCGUkuircyoedzqglh.decode('utf-8')
 def Decrypt_Url(nbTvDjESpRtQJCGUkuircyoedzqgFP,ciphertext,mediacode,nbTvDjESpRtQJCGUkuircyoedzqgWY):
  nbTvDjESpRtQJCGUkuircyoedzqglf=''
  try:
   nbTvDjESpRtQJCGUkuircyoedzqglm,nbTvDjESpRtQJCGUkuircyoedzqglP=nbTvDjESpRtQJCGUkuircyoedzqgFP.Make_DecryptKey('1',mediacode=mediacode,timecode=nbTvDjESpRtQJCGUkuircyoedzqgWY)
   nbTvDjESpRtQJCGUkuircyoedzqglH=json.loads(nbTvDjESpRtQJCGUkuircyoedzqgFP.DecryptPlaintext(ciphertext,nbTvDjESpRtQJCGUkuircyoedzqglm,nbTvDjESpRtQJCGUkuircyoedzqglP)).get('broad_url')
   nbTvDjESpRtQJCGUkuircyoedzqglm,nbTvDjESpRtQJCGUkuircyoedzqglP=nbTvDjESpRtQJCGUkuircyoedzqgFP.Make_DecryptKey('2',mediacode=mediacode,timecode=nbTvDjESpRtQJCGUkuircyoedzqgWY)
   nbTvDjESpRtQJCGUkuircyoedzqglf=nbTvDjESpRtQJCGUkuircyoedzqgFP.DecryptPlaintext(nbTvDjESpRtQJCGUkuircyoedzqglH,nbTvDjESpRtQJCGUkuircyoedzqglm,nbTvDjESpRtQJCGUkuircyoedzqglP)
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  return nbTvDjESpRtQJCGUkuircyoedzqglf
 def Get_Naver_Login(nbTvDjESpRtQJCGUkuircyoedzqgFP):
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWa='https://user.tving.com/oauth/oauthLogin.tving?target=naver&from=pc&rtUrl=https://user.tving.com/pc/user/login.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fmain.do%3FretRef%3DY%26source%3Dhttps%3A%2F%2Fwww.google.com%2F&csite=&isAuto=false'
   nbTvDjESpRtQJCGUkuircyoedzqgFA=nbTvDjESpRtQJCGUkuircyoedzqgFP.callRequestCookies('Get',nbTvDjESpRtQJCGUkuircyoedzqgWa,payload=nbTvDjESpRtQJCGUkuircyoedzqgla,params=nbTvDjESpRtQJCGUkuircyoedzqgla,headers=nbTvDjESpRtQJCGUkuircyoedzqgla,cookies=nbTvDjESpRtQJCGUkuircyoedzqgla)
   if nbTvDjESpRtQJCGUkuircyoedzqgFA.status_code!=200:return nbTvDjESpRtQJCGUkuircyoedzqgls
   nbTvDjESpRtQJCGUkuircyoedzqglB=re.findall('\'https://nid.naver.com/(?:[a-zA-Z]|[0-9]|[$\-@\.&+:/?=_]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+\'',nbTvDjESpRtQJCGUkuircyoedzqgFA.text)
   nbTvDjESpRtQJCGUkuircyoedzqglN=nbTvDjESpRtQJCGUkuircyoedzqglB[0].replace('\'','')
   nbTvDjESpRtQJCGUkuircyoedzqglL(nbTvDjESpRtQJCGUkuircyoedzqglN)
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL('n login pass1 error')
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  try:
   nbTvDjESpRtQJCGUkuircyoedzqgWa=nbTvDjESpRtQJCGUkuircyoedzqglN
  except nbTvDjESpRtQJCGUkuircyoedzqglO as exception:
   nbTvDjESpRtQJCGUkuircyoedzqglL('n login pass1 error')
   nbTvDjESpRtQJCGUkuircyoedzqglL(exception)
  return nbTvDjESpRtQJCGUkuircyoedzqglI
# Created by pyminifier (https://github.com/liftoff/pyminifier)
