__author__="NightRain"
dgQPySXEMOGhKaHnWIDwBbpqcrfmCl=object
dgQPySXEMOGhKaHnWIDwBbpqcrfmCV=None
dgQPySXEMOGhKaHnWIDwBbpqcrfmCN=int
dgQPySXEMOGhKaHnWIDwBbpqcrfmCY=True
dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ=False
dgQPySXEMOGhKaHnWIDwBbpqcrfmCu=type
dgQPySXEMOGhKaHnWIDwBbpqcrfmCA=dict
dgQPySXEMOGhKaHnWIDwBbpqcrfmCx=len
dgQPySXEMOGhKaHnWIDwBbpqcrfmCs=str
dgQPySXEMOGhKaHnWIDwBbpqcrfmCR=range
dgQPySXEMOGhKaHnWIDwBbpqcrfmCi=open
dgQPySXEMOGhKaHnWIDwBbpqcrfmCz=Exception
dgQPySXEMOGhKaHnWIDwBbpqcrfmCe=print
import os
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,xbmcvfs
import sys
import inputstreamhelper
import datetime
import time
import urllib
import base64
__addon__=xbmcaddon.Addon()
__language__ =__addon__.getLocalizedString
__profile__=xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__version__=__addon__.getAddonInfo('version')
__addonid__=__addon__.getAddonInfo('id')
__addonname__=__addon__.getAddonInfo('name')
dgQPySXEMOGhKaHnWIDwBbpqcrfmtU=[{'title':'LIVE 채널','mode':'LIVE_GROUP','stype':'live','orderby':'-','ordernm':'-','icon':'live.png'},{'title':'VOD 방송 - 인기순','mode':'VOD_GROUP','stype':'vod','orderby':'viewDay','ordernm':'인기'},{'title':'VOD 방송 - 최신순','mode':'VOD_GROUP','stype':'vod','orderby':'new','ordernm':'최신'},{'title':'영화(Movie) - 인기순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'viewWeek','ordernm':'인기'},{'title':'영화(Movie) - 최신순 (개별구매 제외)','mode':'MOVIE_GROUP','stype':'movie','orderby':'new','ordernm':'최신'},{'title':'-----------------','mode':'XXX','stype':'XXX','orderby':'-','ordernm':'-'},{'title':'Watched (시청목록)','mode':'WATCH','stype':'-','orderby':'-','ordernm':'-','icon':'history.png'},{'title':'(티빙) 검색','mode':'SEARCH_GROUP','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'(티빙) 검색기록','mode':'SEARCH_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스)','mode':'TOTAL_SEARCH','stype':'-','orderby':'-','ordernm':'-','icon':'search.png'},{'title':'통합검색 (웨이브,티빙,왓챠,넷플릭스) 기록','mode':'TOTAL_HISTORY','stype':'-','orderby':'-','ordernm':'-','icon':'search_history.png'},{'title':'통합 찜 목록 (bookmark mini)','mode':'MENU_BOOKMARK','stype':'-','orderby':'-','ordernm':'-','icon':'bookmark.png'}]
dgQPySXEMOGhKaHnWIDwBbpqcrfmtl=[{'title':'실시간 TV','mode':'CHANNEL','stype':'onair'},{'title':'TVING TV','mode':'CHANNEL','stype':'tvingtv'}]
dgQPySXEMOGhKaHnWIDwBbpqcrfmtV=[{'title':'VOD 시청내역','mode':'WATCH','stype':'vod'},{'title':'영화 시청내역','mode':'WATCH','stype':'movie'}]
dgQPySXEMOGhKaHnWIDwBbpqcrfmtN=[{'title':'VOD 검색','mode':'LOCAL_SEARCH','stype':'vod'},{'title':'영화 검색','mode':'LOCAL_SEARCH','stype':'movie'}]
dgQPySXEMOGhKaHnWIDwBbpqcrfmtY=[{'title':'전체','mode':'PROGRAM','stype':'all'},{'title':'드라마','mode':'PROGRAM','stype':'PCA'},{'title':'예능','mode':'PROGRAM','stype':'PCD'},{'title':'해외시리즈','mode':'GLOBAL_GROUP','stype':'PCPOS'},{'title':'디지털오리지널','mode':'PROGRAM','stype':'PCWD'},{'title':'교양','mode':'PROGRAM','stype':'PCK'},{'title':'키즈/애니','mode':'PROGRAM','stype':'PCC,PCAN'},{'title':'스포츠/취미','mode':'PROGRAM','stype':'PCF'},{'title':'뮤직','mode':'PROGRAM','stype':'PCG'},{'title':'e 스포츠','mode':'PROGRAM','stype':'PCE'}]
dgQPySXEMOGhKaHnWIDwBbpqcrfmtC=[{'title':'전체','mode':'MOVIE_SUB','stype':'all'},{'title':'드라마','mode':'MOVIE_SUB','stype':'MG100,MG190,MG230,MG270,MG290'},{'title':'로맨스/멜로','mode':'MOVIE_SUB','stype':'MG130'},{'title':'코미디','mode':'MOVIE_SUB','stype':'MG110'},{'title':'액션/SF','mode':'MOVIE_SUB','stype':'MG120,MG170,MG180,MG220,MG260,MG200,MG210'},{'title':'공포/스릴러','mode':'MOVIE_SUB','stype':'MG140,MG150,MG160'},{'title':'애니메이션','mode':'MOVIE_SUB','stype':'MG240'},{'title':'다큐','mode':'MOVIE_SUB','stype':'MG250,MG330'}]
dgQPySXEMOGhKaHnWIDwBbpqcrfmtJ=[{'title':'전체','mode':'PROGRAM','genreCode':'all'},{'title':'미국','mode':'PROGRAM','genreCode':'POS007'},{'title':'중국','mode':'PROGRAM','genreCode':'POS005'},{'title':'일본','mode':'PROGRAM','genreCode':'POS006'},{'title':'영국','mode':'PROGRAM','genreCode':'POS008'},{'title':'로맨스','mode':'PROGRAM','genreCode':'POS011'},{'title':'시대극','mode':'PROGRAM','genreCode':'POS012'},{'title':'현대극','mode':'PROGRAM','genreCode':'POS013'},{'title':'다큐멘터리','mode':'PROGRAM','genreCode':'POS010'},{'title':'글로벌','mode':'PROGRAM','genreCode':'POS009'}]
dgQPySXEMOGhKaHnWIDwBbpqcrfmtu =xbmcvfs.translatePath(os.path.join(__profile__,'tving_cookies.json'))
dgQPySXEMOGhKaHnWIDwBbpqcrfmtA=xbmcvfs.translatePath(os.path.join(__profile__,'tving_searched.txt'))
from tvingCore import*
class dgQPySXEMOGhKaHnWIDwBbpqcrfmtv(dgQPySXEMOGhKaHnWIDwBbpqcrfmCl):
 def __init__(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmts,dgQPySXEMOGhKaHnWIDwBbpqcrfmtR,dgQPySXEMOGhKaHnWIDwBbpqcrfmti):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_url =dgQPySXEMOGhKaHnWIDwBbpqcrfmts
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle=dgQPySXEMOGhKaHnWIDwBbpqcrfmtR
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params =dgQPySXEMOGhKaHnWIDwBbpqcrfmti
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj =QpLJXxhfDcPvOrwdzyAqsUCKbmFnak() 
 def addon_noti(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,sting):
  try:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmte=xbmcgui.Dialog()
   dgQPySXEMOGhKaHnWIDwBbpqcrfmte.notification(__addonname__,sting)
  except:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
 def addon_log(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,string):
  try:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtF=string.encode('utf-8','ignore')
  except:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtF='addonException: addon_log'
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtL=xbmc.LOGINFO
  xbmc.log("[%s-%s]: %s"%(__addonid__,__version__,dgQPySXEMOGhKaHnWIDwBbpqcrfmtF),level=dgQPySXEMOGhKaHnWIDwBbpqcrfmtL)
 def get_keyboard_input(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmvx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtk=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
  kb=xbmc.Keyboard()
  kb.setHeading(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx)
  xbmc.sleep(1000)
  kb.doModal()
  if(kb.isConfirmed()):
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtk=kb.getText()
  return dgQPySXEMOGhKaHnWIDwBbpqcrfmtk
 def get_settings_login_info(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmto =__addon__.getSetting('id')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtT =__addon__.getSetting('pw')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtj =__addon__.getSetting('login_type')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvt=dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(__addon__.getSetting('selected_profile'))
  return(dgQPySXEMOGhKaHnWIDwBbpqcrfmto,dgQPySXEMOGhKaHnWIDwBbpqcrfmtT,dgQPySXEMOGhKaHnWIDwBbpqcrfmtj,dgQPySXEMOGhKaHnWIDwBbpqcrfmvt)
 def get_settings_totalsearch(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvU =dgQPySXEMOGhKaHnWIDwBbpqcrfmCY if __addon__.getSetting('local_search')=='true' else dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvl=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY if __addon__.getSetting('local_history')=='true' else dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvV =dgQPySXEMOGhKaHnWIDwBbpqcrfmCY if __addon__.getSetting('total_search')=='true' else dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvN=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY if __addon__.getSetting('total_history')=='true' else dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvY=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY if __addon__.getSetting('menu_bookmark')=='true' else dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
  return(dgQPySXEMOGhKaHnWIDwBbpqcrfmvU,dgQPySXEMOGhKaHnWIDwBbpqcrfmvl,dgQPySXEMOGhKaHnWIDwBbpqcrfmvV,dgQPySXEMOGhKaHnWIDwBbpqcrfmvN,dgQPySXEMOGhKaHnWIDwBbpqcrfmvY)
 def get_settings_makebookmark(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx):
  return dgQPySXEMOGhKaHnWIDwBbpqcrfmCY if __addon__.getSetting('make_bookmark')=='true' else dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
 def get_settings_direct_replay(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvC=dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(__addon__.getSetting('direct_replay'))
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmvC==0:
   return dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
  else:
   return dgQPySXEMOGhKaHnWIDwBbpqcrfmCY
 def set_winCredential(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,credential):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ=xbmcgui.Window(10000)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_TOKEN',credential.get('tving_token'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_USERINFO',credential.get('poc_userinfo'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_UUID',credential.get('tving_uuid'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_LOGINTIME',dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.Get_Now_Datetime().strftime('%Y-%m-%d'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_MAINTOKEN',credential.get('tving_maintoken'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_COOKIEKEY',credential.get('tving_cookiekey'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_LOCKKEY',credential.get('tving_lockkey'))
 def get_winCredential(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ=xbmcgui.Window(10000)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvu={'tving_token':dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.getProperty('TVING_M_TOKEN'),'poc_userinfo':dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.getProperty('TVING_M_USERINFO'),'tving_uuid':dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.getProperty('TVING_M_UUID'),'tving_maintoken':dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.getProperty('TVING_M_LOCKKEY')}
  return dgQPySXEMOGhKaHnWIDwBbpqcrfmvu
 def set_winEpisodeOrderby(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmlY):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ=xbmcgui.Window(10000)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_ORDERBY',dgQPySXEMOGhKaHnWIDwBbpqcrfmlY)
 def get_winEpisodeOrderby(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ=xbmcgui.Window(10000)
  return dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.getProperty('TVING_M_ORDERBY')
 def add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,label,sublabel='',img='',infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY,params='',isLink=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ,ContextMenu=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvA='%s?%s'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_url,urllib.parse.urlencode(params))
  if sublabel:dgQPySXEMOGhKaHnWIDwBbpqcrfmvx='%s < %s >'%(label,sublabel)
  else: dgQPySXEMOGhKaHnWIDwBbpqcrfmvx=label
  if not img:img='DefaultFolder.png'
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvs=xbmcgui.ListItem(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmCu(img)==dgQPySXEMOGhKaHnWIDwBbpqcrfmCA:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvs.setArt(img)
  else:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvs.setArt({'thumb':img,'poster':img})
  if infoLabels:dgQPySXEMOGhKaHnWIDwBbpqcrfmvs.setInfo('Video',infoLabels)
  if not isFolder and not isLink:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvs.setProperty('IsPlayable','true')
  if ContextMenu:dgQPySXEMOGhKaHnWIDwBbpqcrfmvs.addContextMenuItems(ContextMenu)
  xbmcplugin.addDirectoryItem(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,dgQPySXEMOGhKaHnWIDwBbpqcrfmvA,dgQPySXEMOGhKaHnWIDwBbpqcrfmvs,isFolder)
 def get_selQuality(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,etype):
  try:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvR='selected_quality'
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvi=[1080,720,480,360]
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvz=dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(__addon__.getSetting(dgQPySXEMOGhKaHnWIDwBbpqcrfmvR))
   return dgQPySXEMOGhKaHnWIDwBbpqcrfmvi[dgQPySXEMOGhKaHnWIDwBbpqcrfmvz]
  except:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
  return 720 
 def dp_Main_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx):
  (dgQPySXEMOGhKaHnWIDwBbpqcrfmvU,dgQPySXEMOGhKaHnWIDwBbpqcrfmvl,dgQPySXEMOGhKaHnWIDwBbpqcrfmvV,dgQPySXEMOGhKaHnWIDwBbpqcrfmvN,dgQPySXEMOGhKaHnWIDwBbpqcrfmvY)=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_settings_totalsearch()
  for dgQPySXEMOGhKaHnWIDwBbpqcrfmve in dgQPySXEMOGhKaHnWIDwBbpqcrfmtU:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx=dgQPySXEMOGhKaHnWIDwBbpqcrfmve.get('title')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvF=''
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmve.get('mode')=='SEARCH_GROUP' and dgQPySXEMOGhKaHnWIDwBbpqcrfmvU ==dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ:continue
   elif dgQPySXEMOGhKaHnWIDwBbpqcrfmve.get('mode')=='SEARCH_HISTORY' and dgQPySXEMOGhKaHnWIDwBbpqcrfmvl==dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ:continue
   elif dgQPySXEMOGhKaHnWIDwBbpqcrfmve.get('mode')=='TOTAL_SEARCH' and dgQPySXEMOGhKaHnWIDwBbpqcrfmvV ==dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ:continue
   elif dgQPySXEMOGhKaHnWIDwBbpqcrfmve.get('mode')=='TOTAL_HISTORY' and dgQPySXEMOGhKaHnWIDwBbpqcrfmvN==dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ:continue
   elif dgQPySXEMOGhKaHnWIDwBbpqcrfmve.get('mode')=='MENU_BOOKMARK' and dgQPySXEMOGhKaHnWIDwBbpqcrfmvY==dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ:continue
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':dgQPySXEMOGhKaHnWIDwBbpqcrfmve.get('mode'),'stype':dgQPySXEMOGhKaHnWIDwBbpqcrfmve.get('stype'),'orderby':dgQPySXEMOGhKaHnWIDwBbpqcrfmve.get('orderby'),'ordernm':dgQPySXEMOGhKaHnWIDwBbpqcrfmve.get('ordernm'),'page':'1'}
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmve.get('mode')in['XXX','TOTAL_SEARCH','TOTAL_HISTORY','MENU_BOOKMARK']:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvk=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvo =dgQPySXEMOGhKaHnWIDwBbpqcrfmCY
   else:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvk=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvo =dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
   if 'icon' in dgQPySXEMOGhKaHnWIDwBbpqcrfmve:dgQPySXEMOGhKaHnWIDwBbpqcrfmvF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img',dgQPySXEMOGhKaHnWIDwBbpqcrfmve.get('icon')) 
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel='',img=dgQPySXEMOGhKaHnWIDwBbpqcrfmvF,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmvk,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL,isLink=dgQPySXEMOGhKaHnWIDwBbpqcrfmvo)
  xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle)
 def login_main(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx):
  (dgQPySXEMOGhKaHnWIDwBbpqcrfmvj,dgQPySXEMOGhKaHnWIDwBbpqcrfmUt,dgQPySXEMOGhKaHnWIDwBbpqcrfmUv,dgQPySXEMOGhKaHnWIDwBbpqcrfmUl)=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_settings_login_info()
  if not(dgQPySXEMOGhKaHnWIDwBbpqcrfmvj and dgQPySXEMOGhKaHnWIDwBbpqcrfmUt):
   dgQPySXEMOGhKaHnWIDwBbpqcrfmte=xbmcgui.Dialog()
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUV=dgQPySXEMOGhKaHnWIDwBbpqcrfmte.yesno(__language__(30901).encode('utf8'),__language__(30902).encode('utf8'))
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmUV==dgQPySXEMOGhKaHnWIDwBbpqcrfmCY:
    __addon__.openSettings()
    sys.exit()
   else:
    sys.exit()
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_winEpisodeOrderby()=='':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.set_winEpisodeOrderby('desc')
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.cookiefile_check():return
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUN =dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUY=xbmcgui.Window(10000).getProperty('TVING_M_LOGINTIME')
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUY==dgQPySXEMOGhKaHnWIDwBbpqcrfmCV or dgQPySXEMOGhKaHnWIDwBbpqcrfmUY=='':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUY=dgQPySXEMOGhKaHnWIDwBbpqcrfmCN('19000101')
  else:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUY=dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(re.sub('-','',dgQPySXEMOGhKaHnWIDwBbpqcrfmUY))
  if xbmcgui.Window(10000).getProperty('TVING_M_LOGINWAIT')=='TRUE':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUC=0
   while dgQPySXEMOGhKaHnWIDwBbpqcrfmCY:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmUC+=1
    time.sleep(0.05)
    if dgQPySXEMOGhKaHnWIDwBbpqcrfmUY>=dgQPySXEMOGhKaHnWIDwBbpqcrfmUN:return
    if dgQPySXEMOGhKaHnWIDwBbpqcrfmUC>600:return
  else:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','TRUE')
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUY>=dgQPySXEMOGhKaHnWIDwBbpqcrfmUN:
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   return
  if not dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.GetCredential(dgQPySXEMOGhKaHnWIDwBbpqcrfmvj,dgQPySXEMOGhKaHnWIDwBbpqcrfmUt,dgQPySXEMOGhKaHnWIDwBbpqcrfmUv,dgQPySXEMOGhKaHnWIDwBbpqcrfmUl):
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.addon_noti(__language__(30903).encode('utf8'))
   xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
   sys.exit()
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.set_winCredential(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.LoadCredential())
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.cookiefile_save()
  xbmcgui.Window(10000).setProperty('TVING_M_LOGINWAIT','FALSE')
 def dp_Title_Group(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('stype')
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='live':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUu=dgQPySXEMOGhKaHnWIDwBbpqcrfmtl
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='vod':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUu=dgQPySXEMOGhKaHnWIDwBbpqcrfmtY
  else:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUu=dgQPySXEMOGhKaHnWIDwBbpqcrfmtC
  for dgQPySXEMOGhKaHnWIDwBbpqcrfmUA in dgQPySXEMOGhKaHnWIDwBbpqcrfmUu:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx=dgQPySXEMOGhKaHnWIDwBbpqcrfmUA.get('title')
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('ordernm')!='-':
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvx+='  ('+dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('ordernm')+')'
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':dgQPySXEMOGhKaHnWIDwBbpqcrfmUA.get('mode'),'stype':dgQPySXEMOGhKaHnWIDwBbpqcrfmUA.get('stype'),'orderby':dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('orderby'),'ordernm':dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('ordernm'),'page':'1'}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel='',img='',infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmCx(dgQPySXEMOGhKaHnWIDwBbpqcrfmUu)>0:xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle)
 def dp_SubTitle_Group(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx): 
  for dgQPySXEMOGhKaHnWIDwBbpqcrfmUA in dgQPySXEMOGhKaHnWIDwBbpqcrfmtJ:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx=dgQPySXEMOGhKaHnWIDwBbpqcrfmUA.get('title')
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('ordernm')!='-':
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvx+='  ('+dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('ordernm')+')'
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':dgQPySXEMOGhKaHnWIDwBbpqcrfmUA.get('mode'),'genreCode':dgQPySXEMOGhKaHnWIDwBbpqcrfmUA.get('genreCode'),'stype':dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('stype'),'orderby':dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('orderby'),'page':'1'}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel='',img='',infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmCx(dgQPySXEMOGhKaHnWIDwBbpqcrfmtJ)>0:xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle)
 def dp_LiveChannel_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.SaveCredential(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_winCredential())
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ =dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('stype')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUs =dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('page'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUR,dgQPySXEMOGhKaHnWIDwBbpqcrfmUi=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.GetLiveChannelList(dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ,dgQPySXEMOGhKaHnWIDwBbpqcrfmUs)
  for dgQPySXEMOGhKaHnWIDwBbpqcrfmUz in dgQPySXEMOGhKaHnWIDwBbpqcrfmUR:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('title')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvT =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('channel')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUe =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('thumbnail')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUF =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('synopsis')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUL =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('channelepg')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUk =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('cast')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUo =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('director')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUT =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('info_genre')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUj =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('year')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlt =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('mpaa')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlv =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('premiered')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlU={'mediatype':'episode','title':dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,'studio':dgQPySXEMOGhKaHnWIDwBbpqcrfmvT,'cast':dgQPySXEMOGhKaHnWIDwBbpqcrfmUk,'director':dgQPySXEMOGhKaHnWIDwBbpqcrfmUo,'genre':dgQPySXEMOGhKaHnWIDwBbpqcrfmUT,'plot':'%s\n%s\n%s\n\n%s'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmvT,dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUL,dgQPySXEMOGhKaHnWIDwBbpqcrfmUF),'year':dgQPySXEMOGhKaHnWIDwBbpqcrfmUj,'mpaa':dgQPySXEMOGhKaHnWIDwBbpqcrfmlt,'premiered':dgQPySXEMOGhKaHnWIDwBbpqcrfmlv}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':'LIVE','mediacode':dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('mediacode'),'stype':dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvT,sublabel=dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,img=dgQPySXEMOGhKaHnWIDwBbpqcrfmUe,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmlU,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUi:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['mode']='CHANNEL' 
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['stype']=dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ 
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['page']=dgQPySXEMOGhKaHnWIDwBbpqcrfmCs(dgQPySXEMOGhKaHnWIDwBbpqcrfmUs+1)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx='[B]%s >>[/B]'%'다음 페이지'
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlV=dgQPySXEMOGhKaHnWIDwBbpqcrfmCs(dgQPySXEMOGhKaHnWIDwBbpqcrfmUs+1)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel=dgQPySXEMOGhKaHnWIDwBbpqcrfmlV,img=dgQPySXEMOGhKaHnWIDwBbpqcrfmvF,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmCx(dgQPySXEMOGhKaHnWIDwBbpqcrfmUR)>0:xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,cacheToDisc=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ)
 def dp_Program_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.SaveCredential(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_winCredential())
  dgQPySXEMOGhKaHnWIDwBbpqcrfmlN =dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('stype')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmlY =dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('orderby')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUs =dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('page'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmlC=dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('genreCode')
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmlC==dgQPySXEMOGhKaHnWIDwBbpqcrfmCV:dgQPySXEMOGhKaHnWIDwBbpqcrfmlC='all'
  dgQPySXEMOGhKaHnWIDwBbpqcrfmlJ,dgQPySXEMOGhKaHnWIDwBbpqcrfmUi=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.GetProgramList(dgQPySXEMOGhKaHnWIDwBbpqcrfmlN,dgQPySXEMOGhKaHnWIDwBbpqcrfmlY,dgQPySXEMOGhKaHnWIDwBbpqcrfmUs,dgQPySXEMOGhKaHnWIDwBbpqcrfmlC)
  for dgQPySXEMOGhKaHnWIDwBbpqcrfmlu in dgQPySXEMOGhKaHnWIDwBbpqcrfmlJ:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx =dgQPySXEMOGhKaHnWIDwBbpqcrfmlu.get('title')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUe =dgQPySXEMOGhKaHnWIDwBbpqcrfmlu.get('thumbnail')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUF =dgQPySXEMOGhKaHnWIDwBbpqcrfmlu.get('synopsis')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlA =dgQPySXEMOGhKaHnWIDwBbpqcrfmlu.get('channel')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUk =dgQPySXEMOGhKaHnWIDwBbpqcrfmlu.get('cast')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUo =dgQPySXEMOGhKaHnWIDwBbpqcrfmlu.get('director')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUT=dgQPySXEMOGhKaHnWIDwBbpqcrfmlu.get('info_genre')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUj =dgQPySXEMOGhKaHnWIDwBbpqcrfmlu.get('year')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlv =dgQPySXEMOGhKaHnWIDwBbpqcrfmlu.get('premiered')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlt =dgQPySXEMOGhKaHnWIDwBbpqcrfmlu.get('mpaa')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlU={'mediatype':'tvshow','title':dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,'studio':dgQPySXEMOGhKaHnWIDwBbpqcrfmlA,'cast':dgQPySXEMOGhKaHnWIDwBbpqcrfmUk,'director':dgQPySXEMOGhKaHnWIDwBbpqcrfmUo,'genre':dgQPySXEMOGhKaHnWIDwBbpqcrfmUT,'year':dgQPySXEMOGhKaHnWIDwBbpqcrfmUj,'premiered':dgQPySXEMOGhKaHnWIDwBbpqcrfmlv,'mpaa':dgQPySXEMOGhKaHnWIDwBbpqcrfmlt,'plot':dgQPySXEMOGhKaHnWIDwBbpqcrfmUF}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':'EPISODE','programcode':dgQPySXEMOGhKaHnWIDwBbpqcrfmlu.get('program'),'page':'1'}
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_settings_makebookmark():
    dgQPySXEMOGhKaHnWIDwBbpqcrfmlx={'videoid':dgQPySXEMOGhKaHnWIDwBbpqcrfmlu.get('program'),'vidtype':'tvshow','vtitle':dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,'vsubtitle':dgQPySXEMOGhKaHnWIDwBbpqcrfmlA,}
    dgQPySXEMOGhKaHnWIDwBbpqcrfmls=json.dumps(dgQPySXEMOGhKaHnWIDwBbpqcrfmlx)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmls=urllib.parse.quote(dgQPySXEMOGhKaHnWIDwBbpqcrfmls)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmlR='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmls)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmli=[('(통합) 찜 영상에 추가',dgQPySXEMOGhKaHnWIDwBbpqcrfmlR)]
   else:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmli=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel=dgQPySXEMOGhKaHnWIDwBbpqcrfmlA,img=dgQPySXEMOGhKaHnWIDwBbpqcrfmUe,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmlU,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL,ContextMenu=dgQPySXEMOGhKaHnWIDwBbpqcrfmli)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUi:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['mode'] ='PROGRAM' 
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['stype'] =dgQPySXEMOGhKaHnWIDwBbpqcrfmlN
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['orderby'] =dgQPySXEMOGhKaHnWIDwBbpqcrfmlY
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['page'] =dgQPySXEMOGhKaHnWIDwBbpqcrfmCs(dgQPySXEMOGhKaHnWIDwBbpqcrfmUs+1)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['genreCode']=dgQPySXEMOGhKaHnWIDwBbpqcrfmlC 
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx='[B]%s >>[/B]'%'다음 페이지'
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlV=dgQPySXEMOGhKaHnWIDwBbpqcrfmCs(dgQPySXEMOGhKaHnWIDwBbpqcrfmUs+1)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel=dgQPySXEMOGhKaHnWIDwBbpqcrfmlV,img=dgQPySXEMOGhKaHnWIDwBbpqcrfmvF,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
  xbmcplugin.setContent(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,cacheToDisc=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ)
 def dp_Episode_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.SaveCredential(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_winCredential())
  dgQPySXEMOGhKaHnWIDwBbpqcrfmle=dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('programcode')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUs =dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('page'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmlF,dgQPySXEMOGhKaHnWIDwBbpqcrfmUi,dgQPySXEMOGhKaHnWIDwBbpqcrfmlL=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.GetEpisodeList(dgQPySXEMOGhKaHnWIDwBbpqcrfmle,dgQPySXEMOGhKaHnWIDwBbpqcrfmUs,orderby=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_winEpisodeOrderby())
  for dgQPySXEMOGhKaHnWIDwBbpqcrfmlk in dgQPySXEMOGhKaHnWIDwBbpqcrfmlF:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx =dgQPySXEMOGhKaHnWIDwBbpqcrfmlk.get('title')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlV =dgQPySXEMOGhKaHnWIDwBbpqcrfmlk.get('subtitle')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUe =dgQPySXEMOGhKaHnWIDwBbpqcrfmlk.get('thumbnail')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUF =dgQPySXEMOGhKaHnWIDwBbpqcrfmlk.get('synopsis')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlo=dgQPySXEMOGhKaHnWIDwBbpqcrfmlk.get('info_title')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlT =dgQPySXEMOGhKaHnWIDwBbpqcrfmlk.get('aired')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlj =dgQPySXEMOGhKaHnWIDwBbpqcrfmlk.get('studio')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmVt =dgQPySXEMOGhKaHnWIDwBbpqcrfmlk.get('frequency')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlU={'mediatype':'episode','title':dgQPySXEMOGhKaHnWIDwBbpqcrfmlo,'aired':dgQPySXEMOGhKaHnWIDwBbpqcrfmlT,'studio':dgQPySXEMOGhKaHnWIDwBbpqcrfmlj,'episode':dgQPySXEMOGhKaHnWIDwBbpqcrfmVt,'plot':dgQPySXEMOGhKaHnWIDwBbpqcrfmUF}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':'VOD','mediacode':dgQPySXEMOGhKaHnWIDwBbpqcrfmlk.get('episode'),'stype':'vod','programcode':dgQPySXEMOGhKaHnWIDwBbpqcrfmle,'title':dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,'thumbnail':dgQPySXEMOGhKaHnWIDwBbpqcrfmUe}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel=dgQPySXEMOGhKaHnWIDwBbpqcrfmlV,img=dgQPySXEMOGhKaHnWIDwBbpqcrfmUe,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmlU,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUs==1:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlU={'plot':'정렬순서를 변경합니다.'}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['mode'] ='ORDER_BY' 
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_winEpisodeOrderby()=='desc':
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvx='정렬순서변경 : 최신화부터 -> 1회부터'
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['orderby']='asc'
   else:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvx='정렬순서변경 : 1회부터 -> 최신화부터'
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['orderby']='desc'
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','sort.png')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel='',img=dgQPySXEMOGhKaHnWIDwBbpqcrfmvF,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmlU,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL,isLink=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUi:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['mode'] ='EPISODE' 
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['programcode']=dgQPySXEMOGhKaHnWIDwBbpqcrfmle
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['page'] =dgQPySXEMOGhKaHnWIDwBbpqcrfmCs(dgQPySXEMOGhKaHnWIDwBbpqcrfmUs+1)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx='[B]%s >>[/B]'%'다음 페이지'
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlV=dgQPySXEMOGhKaHnWIDwBbpqcrfmCs(dgQPySXEMOGhKaHnWIDwBbpqcrfmUs+1)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel=dgQPySXEMOGhKaHnWIDwBbpqcrfmlV,img=dgQPySXEMOGhKaHnWIDwBbpqcrfmvF,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
  xbmcplugin.setContent(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,'episodes')
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmCx(dgQPySXEMOGhKaHnWIDwBbpqcrfmlF)>0:xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,cacheToDisc=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY)
 def dp_setEpOrderby(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmlY =dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('orderby')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.set_winEpisodeOrderby(dgQPySXEMOGhKaHnWIDwBbpqcrfmlY)
  xbmc.executebuiltin("Container.Refresh")
 def dp_Movie_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.SaveCredential(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_winCredential())
  dgQPySXEMOGhKaHnWIDwBbpqcrfmlN =dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('stype')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmlY =dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('orderby')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUs=dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('page'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVv,dgQPySXEMOGhKaHnWIDwBbpqcrfmUi=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.GetMovieList(dgQPySXEMOGhKaHnWIDwBbpqcrfmlN,dgQPySXEMOGhKaHnWIDwBbpqcrfmlY,dgQPySXEMOGhKaHnWIDwBbpqcrfmUs)
  for dgQPySXEMOGhKaHnWIDwBbpqcrfmVU in dgQPySXEMOGhKaHnWIDwBbpqcrfmVv:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx =dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('title')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUe =dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('thumbnail')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUF =dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('synopsis')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlo =dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('info_title')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUj =dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('year')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUk =dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('cast')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUo =dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('director')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUT =dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('info_genre')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmVl =dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('duration')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlv =dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('premiered')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlj =dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('studio')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlt =dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('mpaa')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlU={'mediatype':'movie','title':dgQPySXEMOGhKaHnWIDwBbpqcrfmlo,'year':dgQPySXEMOGhKaHnWIDwBbpqcrfmUj,'cast':dgQPySXEMOGhKaHnWIDwBbpqcrfmUk,'director':dgQPySXEMOGhKaHnWIDwBbpqcrfmUo,'genre':dgQPySXEMOGhKaHnWIDwBbpqcrfmUT,'duration':dgQPySXEMOGhKaHnWIDwBbpqcrfmVl,'premiered':dgQPySXEMOGhKaHnWIDwBbpqcrfmlv,'studio':dgQPySXEMOGhKaHnWIDwBbpqcrfmlj,'mpaa':dgQPySXEMOGhKaHnWIDwBbpqcrfmlt,'plot':dgQPySXEMOGhKaHnWIDwBbpqcrfmUF}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':'MOVIE','mediacode':dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('moviecode'),'stype':'movie','title':dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,'thumbnail':dgQPySXEMOGhKaHnWIDwBbpqcrfmUe}
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_settings_makebookmark():
    dgQPySXEMOGhKaHnWIDwBbpqcrfmlx={'videoid':dgQPySXEMOGhKaHnWIDwBbpqcrfmVU.get('moviecode'),'vidtype':'movie','vtitle':dgQPySXEMOGhKaHnWIDwBbpqcrfmlo,'vsubtitle':'',}
    dgQPySXEMOGhKaHnWIDwBbpqcrfmls=json.dumps(dgQPySXEMOGhKaHnWIDwBbpqcrfmlx)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmls=urllib.parse.quote(dgQPySXEMOGhKaHnWIDwBbpqcrfmls)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmlR='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmls)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmli=[('(통합) 찜 영상에 추가',dgQPySXEMOGhKaHnWIDwBbpqcrfmlR)]
   else:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmli=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel='',img=dgQPySXEMOGhKaHnWIDwBbpqcrfmUe,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmlU,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL,ContextMenu=dgQPySXEMOGhKaHnWIDwBbpqcrfmli)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUi:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['mode'] ='MOVIE_SUB' 
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['orderby']=dgQPySXEMOGhKaHnWIDwBbpqcrfmlY
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['stype'] =dgQPySXEMOGhKaHnWIDwBbpqcrfmlN
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['page'] =dgQPySXEMOGhKaHnWIDwBbpqcrfmCs(dgQPySXEMOGhKaHnWIDwBbpqcrfmUs+1)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx='[B]%s >>[/B]'%'다음 페이지'
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlV=dgQPySXEMOGhKaHnWIDwBbpqcrfmCs(dgQPySXEMOGhKaHnWIDwBbpqcrfmUs+1)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel=dgQPySXEMOGhKaHnWIDwBbpqcrfmlV,img=dgQPySXEMOGhKaHnWIDwBbpqcrfmvF,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
  xbmcplugin.setContent(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,'movies')
  xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,cacheToDisc=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ)
 def dp_Set_Bookmark(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVN=urllib.parse.unquote(dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('bm_param'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVN=json.loads(dgQPySXEMOGhKaHnWIDwBbpqcrfmVN)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVY =dgQPySXEMOGhKaHnWIDwBbpqcrfmVN.get('videoid')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVC =dgQPySXEMOGhKaHnWIDwBbpqcrfmVN.get('vidtype')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVJ =dgQPySXEMOGhKaHnWIDwBbpqcrfmVN.get('vtitle')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVu =dgQPySXEMOGhKaHnWIDwBbpqcrfmVN.get('vsubtitle')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmte=xbmcgui.Dialog()
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUV=dgQPySXEMOGhKaHnWIDwBbpqcrfmte.yesno(__language__(30913).encode('utf8'),dgQPySXEMOGhKaHnWIDwBbpqcrfmVJ+' \n\n'+__language__(30914))
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUV==dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ:return
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVA=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.GetBookmarkInfo(dgQPySXEMOGhKaHnWIDwBbpqcrfmVY,dgQPySXEMOGhKaHnWIDwBbpqcrfmVC)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmVu!='':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmVA['saveinfo']['subtitle']=dgQPySXEMOGhKaHnWIDwBbpqcrfmVu 
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmVC=='tvshow':dgQPySXEMOGhKaHnWIDwBbpqcrfmVA['saveinfo']['infoLabels']['studio']=dgQPySXEMOGhKaHnWIDwBbpqcrfmVu 
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVx=json.dumps(dgQPySXEMOGhKaHnWIDwBbpqcrfmVA)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVx=urllib.parse.quote(dgQPySXEMOGhKaHnWIDwBbpqcrfmVx)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmlR ='RunPlugin(plugin://plugin.video.bookmarkm/?mode=SET_BOOKMARK&bm_param=%s)'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmVx)
  xbmc.executebuiltin(dgQPySXEMOGhKaHnWIDwBbpqcrfmlR)
 def dp_Search_Group(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  if 'search_key' in dgQPySXEMOGhKaHnWIDwBbpqcrfmUx:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmVs=dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('search_key')
  else:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmVs=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not dgQPySXEMOGhKaHnWIDwBbpqcrfmVs:
    return
  for dgQPySXEMOGhKaHnWIDwBbpqcrfmUA in dgQPySXEMOGhKaHnWIDwBbpqcrfmtN:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmVR =dgQPySXEMOGhKaHnWIDwBbpqcrfmUA.get('mode')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=dgQPySXEMOGhKaHnWIDwBbpqcrfmUA.get('stype')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx=dgQPySXEMOGhKaHnWIDwBbpqcrfmUA.get('title')
   (dgQPySXEMOGhKaHnWIDwBbpqcrfmVi,dgQPySXEMOGhKaHnWIDwBbpqcrfmUi)=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.GetSearchList(dgQPySXEMOGhKaHnWIDwBbpqcrfmVs,1,dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmVz={'plot':'검색어 : '+dgQPySXEMOGhKaHnWIDwBbpqcrfmVs+'\n\n'+dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.Search_FreeList(dgQPySXEMOGhKaHnWIDwBbpqcrfmVi)}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':dgQPySXEMOGhKaHnWIDwBbpqcrfmVR,'stype':dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ,'search_key':dgQPySXEMOGhKaHnWIDwBbpqcrfmVs,'page':'1',}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel='',img='',infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmVz,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmCx(dgQPySXEMOGhKaHnWIDwBbpqcrfmtN)>0:xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,cacheToDisc=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.Save_Searched_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmVs)
 def Search_FreeList(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmNv):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVe=''
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVF=7
  try:
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmCx(dgQPySXEMOGhKaHnWIDwBbpqcrfmNv)==0:return '검색결과 없음'
   for i in dgQPySXEMOGhKaHnWIDwBbpqcrfmCR(dgQPySXEMOGhKaHnWIDwBbpqcrfmCx(dgQPySXEMOGhKaHnWIDwBbpqcrfmNv)):
    if i>=dgQPySXEMOGhKaHnWIDwBbpqcrfmVF:
     dgQPySXEMOGhKaHnWIDwBbpqcrfmVe=dgQPySXEMOGhKaHnWIDwBbpqcrfmVe+'...'
     break
    dgQPySXEMOGhKaHnWIDwBbpqcrfmVe=dgQPySXEMOGhKaHnWIDwBbpqcrfmVe+dgQPySXEMOGhKaHnWIDwBbpqcrfmNv[i]['title']+'\n'
  except:
   return ''
  return dgQPySXEMOGhKaHnWIDwBbpqcrfmVe
 def dp_Search_History(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVL=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.Load_List_File('search')
  for dgQPySXEMOGhKaHnWIDwBbpqcrfmVk in dgQPySXEMOGhKaHnWIDwBbpqcrfmVL:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmVo=dgQPySXEMOGhKaHnWIDwBbpqcrfmCA(urllib.parse.parse_qsl(dgQPySXEMOGhKaHnWIDwBbpqcrfmVk))
   dgQPySXEMOGhKaHnWIDwBbpqcrfmVT=dgQPySXEMOGhKaHnWIDwBbpqcrfmVo.get('skey').strip()
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':'SEARCH_GROUP','search_key':dgQPySXEMOGhKaHnWIDwBbpqcrfmVT,}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmVj={'mode':'SEARCH_REMOVE','stype':'ONE','skey':dgQPySXEMOGhKaHnWIDwBbpqcrfmVT,}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNt=urllib.parse.urlencode(dgQPySXEMOGhKaHnWIDwBbpqcrfmVj)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmli=[('선택된 검색어 ( %s ) 삭제'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmVT),'RunPlugin(plugin://plugin.video.tvingm/?%s)'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmNt))]
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmVT,sublabel='',img=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL,ContextMenu=dgQPySXEMOGhKaHnWIDwBbpqcrfmli)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmlU={'plot':'검색목록 전체를 삭제합니다.'}
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvx='** 검색목록 전체삭제 (개별삭제는 팝업메뉴 사용) **'
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':'SEARCH_REMOVE','stype':'ALL','skey':'-',}
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png') 
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel='',img=dgQPySXEMOGhKaHnWIDwBbpqcrfmvF,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmlU,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL,isLink=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY)
  xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,cacheToDisc=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ)
 def dp_Search_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.SaveCredential(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_winCredential())
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUs =dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('page'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ =dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('stype')
  if 'search_key' in dgQPySXEMOGhKaHnWIDwBbpqcrfmUx:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmVs=dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('search_key')
  else:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmVs=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_keyboard_input(__language__(30906).encode('utf-8'))
   if not dgQPySXEMOGhKaHnWIDwBbpqcrfmVs:
    xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle)
    return
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVi,dgQPySXEMOGhKaHnWIDwBbpqcrfmUi=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.GetSearchList(dgQPySXEMOGhKaHnWIDwBbpqcrfmVs,dgQPySXEMOGhKaHnWIDwBbpqcrfmUs,dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ)
  for dgQPySXEMOGhKaHnWIDwBbpqcrfmNv in dgQPySXEMOGhKaHnWIDwBbpqcrfmVi:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx =dgQPySXEMOGhKaHnWIDwBbpqcrfmNv.get('title')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUe =dgQPySXEMOGhKaHnWIDwBbpqcrfmNv.get('thumbnail')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUF =dgQPySXEMOGhKaHnWIDwBbpqcrfmNv.get('synopsis')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNU =dgQPySXEMOGhKaHnWIDwBbpqcrfmNv.get('program')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUk =dgQPySXEMOGhKaHnWIDwBbpqcrfmNv.get('cast')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUo =dgQPySXEMOGhKaHnWIDwBbpqcrfmNv.get('director')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUT=dgQPySXEMOGhKaHnWIDwBbpqcrfmNv.get('info_genre')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmVl =dgQPySXEMOGhKaHnWIDwBbpqcrfmNv.get('duration')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlt =dgQPySXEMOGhKaHnWIDwBbpqcrfmNv.get('mpaa')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUj =dgQPySXEMOGhKaHnWIDwBbpqcrfmNv.get('year')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlT =dgQPySXEMOGhKaHnWIDwBbpqcrfmNv.get('aired')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlU={'mediatype':'tvshow' if dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='vod' else 'movie','title':dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,'cast':dgQPySXEMOGhKaHnWIDwBbpqcrfmUk,'director':dgQPySXEMOGhKaHnWIDwBbpqcrfmUo,'genre':dgQPySXEMOGhKaHnWIDwBbpqcrfmUT,'duration':dgQPySXEMOGhKaHnWIDwBbpqcrfmVl,'mpaa':dgQPySXEMOGhKaHnWIDwBbpqcrfmlt,'year':dgQPySXEMOGhKaHnWIDwBbpqcrfmUj,'aired':dgQPySXEMOGhKaHnWIDwBbpqcrfmlT,'plot':'%s\n\n%s'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUF)}
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='vod':
    dgQPySXEMOGhKaHnWIDwBbpqcrfmVY=dgQPySXEMOGhKaHnWIDwBbpqcrfmNv.get('program')
    dgQPySXEMOGhKaHnWIDwBbpqcrfmVC='tvshow'
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':'EPISODE','programcode':dgQPySXEMOGhKaHnWIDwBbpqcrfmVY,'page':'1',}
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvk=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY
   else:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmVY=dgQPySXEMOGhKaHnWIDwBbpqcrfmNv.get('movie')
    dgQPySXEMOGhKaHnWIDwBbpqcrfmVC='movie'
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':'MOVIE','mediacode':dgQPySXEMOGhKaHnWIDwBbpqcrfmVY,'stype':'movie','title':dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,'thumbnail':dgQPySXEMOGhKaHnWIDwBbpqcrfmUe,}
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvk=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_settings_makebookmark():
    dgQPySXEMOGhKaHnWIDwBbpqcrfmlx={'videoid':dgQPySXEMOGhKaHnWIDwBbpqcrfmVY,'vidtype':dgQPySXEMOGhKaHnWIDwBbpqcrfmVC,'vtitle':dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,'vsubtitle':'',}
    dgQPySXEMOGhKaHnWIDwBbpqcrfmls=json.dumps(dgQPySXEMOGhKaHnWIDwBbpqcrfmlx)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmls=urllib.parse.quote(dgQPySXEMOGhKaHnWIDwBbpqcrfmls)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmlR='RunPlugin(plugin://plugin.video.tvingm/?mode=SET_BOOKMARK&bm_param=%s)'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmls)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmli=[('(통합) 찜 영상에 추가',dgQPySXEMOGhKaHnWIDwBbpqcrfmlR)]
   else:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmli=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel='',img=dgQPySXEMOGhKaHnWIDwBbpqcrfmUe,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmlU,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmvk,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL,isLink=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ,ContextMenu=dgQPySXEMOGhKaHnWIDwBbpqcrfmli)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUi:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['mode'] ='SEARCH' 
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['search_key']=dgQPySXEMOGhKaHnWIDwBbpqcrfmVs
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL['page'] =dgQPySXEMOGhKaHnWIDwBbpqcrfmCs(dgQPySXEMOGhKaHnWIDwBbpqcrfmUs+1)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx='[B]%s >>[/B]'%'다음 페이지'
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlV=dgQPySXEMOGhKaHnWIDwBbpqcrfmCs(dgQPySXEMOGhKaHnWIDwBbpqcrfmUs+1)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','next.png')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel=dgQPySXEMOGhKaHnWIDwBbpqcrfmlV,img=dgQPySXEMOGhKaHnWIDwBbpqcrfmvF,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='movie':xbmcplugin.setContent(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,'movies')
  else:xbmcplugin.setContent(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,'tvshows')
  xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,cacheToDisc=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ)
 def Delete_List_File(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ,skey='-'):
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='ALL':
   try:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmNl=dgQPySXEMOGhKaHnWIDwBbpqcrfmtA
    fp=dgQPySXEMOGhKaHnWIDwBbpqcrfmCi(dgQPySXEMOGhKaHnWIDwBbpqcrfmNl,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='ONE':
   try:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmNl=dgQPySXEMOGhKaHnWIDwBbpqcrfmtA
    dgQPySXEMOGhKaHnWIDwBbpqcrfmNV=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.Load_List_File('search') 
    fp=dgQPySXEMOGhKaHnWIDwBbpqcrfmCi(dgQPySXEMOGhKaHnWIDwBbpqcrfmNl,'w',-1,'utf-8')
    for dgQPySXEMOGhKaHnWIDwBbpqcrfmNY in dgQPySXEMOGhKaHnWIDwBbpqcrfmNV:
     dgQPySXEMOGhKaHnWIDwBbpqcrfmNC=dgQPySXEMOGhKaHnWIDwBbpqcrfmCA(urllib.parse.parse_qsl(dgQPySXEMOGhKaHnWIDwBbpqcrfmNY))
     dgQPySXEMOGhKaHnWIDwBbpqcrfmNJ=dgQPySXEMOGhKaHnWIDwBbpqcrfmNC.get('skey').strip()
     if skey!=dgQPySXEMOGhKaHnWIDwBbpqcrfmNJ:
      fp.write(dgQPySXEMOGhKaHnWIDwBbpqcrfmNY)
    fp.close()
   except:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ in['vod','movie']:
   try:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmNl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ))
    fp=dgQPySXEMOGhKaHnWIDwBbpqcrfmCi(dgQPySXEMOGhKaHnWIDwBbpqcrfmNl,'w',-1,'utf-8')
    fp.write('')
    fp.close()
   except:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
 def dp_Listfile_Delete(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('stype')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVT =dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('skey')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmte=xbmcgui.Dialog()
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='ALL':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUV=dgQPySXEMOGhKaHnWIDwBbpqcrfmte.yesno(__language__(30911).encode('utf8'),__language__(30905).encode('utf8'))
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='ONE':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUV=dgQPySXEMOGhKaHnWIDwBbpqcrfmte.yesno(__language__(30912).encode('utf8'),__language__(30905).encode('utf8'))
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ in['vod','movie']:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmUV=dgQPySXEMOGhKaHnWIDwBbpqcrfmte.yesno(__language__(30904).encode('utf8'),__language__(30905).encode('utf8'))
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUV==dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ:sys.exit()
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.Delete_List_File(dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ,skey=dgQPySXEMOGhKaHnWIDwBbpqcrfmVT)
  xbmc.executebuiltin("Container.Refresh")
 def Load_List_File(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ): 
  try:
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='search':
    dgQPySXEMOGhKaHnWIDwBbpqcrfmNl=dgQPySXEMOGhKaHnWIDwBbpqcrfmtA
   elif dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ in['vod','movie']:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmNl=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ))
   else:
    return[]
   fp=dgQPySXEMOGhKaHnWIDwBbpqcrfmCi(dgQPySXEMOGhKaHnWIDwBbpqcrfmNl,'r',-1,'utf-8')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNu=fp.readlines()
   fp.close()
  except:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNu=[]
  return dgQPySXEMOGhKaHnWIDwBbpqcrfmNu
 def Save_Watched_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ,dgQPySXEMOGhKaHnWIDwBbpqcrfmti):
  try:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNA=xbmcvfs.translatePath(os.path.join(__profile__,'watchedlist_%s.txt'%dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ))
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNV=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.Load_List_File(dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ) 
   fp=dgQPySXEMOGhKaHnWIDwBbpqcrfmCi(dgQPySXEMOGhKaHnWIDwBbpqcrfmNA,'w',-1,'utf-8')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNx=urllib.parse.urlencode(dgQPySXEMOGhKaHnWIDwBbpqcrfmti)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNx=dgQPySXEMOGhKaHnWIDwBbpqcrfmNx+'\n'
   fp.write(dgQPySXEMOGhKaHnWIDwBbpqcrfmNx)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNs=0
   for dgQPySXEMOGhKaHnWIDwBbpqcrfmNY in dgQPySXEMOGhKaHnWIDwBbpqcrfmNV:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmNC=dgQPySXEMOGhKaHnWIDwBbpqcrfmCA(urllib.parse.parse_qsl(dgQPySXEMOGhKaHnWIDwBbpqcrfmNY))
    dgQPySXEMOGhKaHnWIDwBbpqcrfmNR=dgQPySXEMOGhKaHnWIDwBbpqcrfmti.get('code').strip()
    dgQPySXEMOGhKaHnWIDwBbpqcrfmNi=dgQPySXEMOGhKaHnWIDwBbpqcrfmNC.get('code').strip()
    if dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='vod' and dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_settings_direct_replay()==dgQPySXEMOGhKaHnWIDwBbpqcrfmCY:
     dgQPySXEMOGhKaHnWIDwBbpqcrfmNR=dgQPySXEMOGhKaHnWIDwBbpqcrfmti.get('videoid').strip()
     dgQPySXEMOGhKaHnWIDwBbpqcrfmNi=dgQPySXEMOGhKaHnWIDwBbpqcrfmNC.get('videoid').strip()if dgQPySXEMOGhKaHnWIDwBbpqcrfmNi!=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV else '-'
    if dgQPySXEMOGhKaHnWIDwBbpqcrfmNR!=dgQPySXEMOGhKaHnWIDwBbpqcrfmNi:
     fp.write(dgQPySXEMOGhKaHnWIDwBbpqcrfmNY)
     dgQPySXEMOGhKaHnWIDwBbpqcrfmNs+=1
     if dgQPySXEMOGhKaHnWIDwBbpqcrfmNs>=50:break
   fp.close()
  except:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
 def dp_Watch_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ =dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('stype')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvC=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_settings_direct_replay()
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='-':
   for dgQPySXEMOGhKaHnWIDwBbpqcrfmUA in dgQPySXEMOGhKaHnWIDwBbpqcrfmtV:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvx=dgQPySXEMOGhKaHnWIDwBbpqcrfmUA.get('title')
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':dgQPySXEMOGhKaHnWIDwBbpqcrfmUA.get('mode'),'stype':dgQPySXEMOGhKaHnWIDwBbpqcrfmUA.get('stype')}
    dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel='',img='',infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmCV,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmCx(dgQPySXEMOGhKaHnWIDwBbpqcrfmtV)>0:xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle)
  else:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNz=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.Load_List_File(dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ)
   for dgQPySXEMOGhKaHnWIDwBbpqcrfmNe in dgQPySXEMOGhKaHnWIDwBbpqcrfmNz:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmVo=dgQPySXEMOGhKaHnWIDwBbpqcrfmCA(urllib.parse.parse_qsl(dgQPySXEMOGhKaHnWIDwBbpqcrfmNe))
    dgQPySXEMOGhKaHnWIDwBbpqcrfmNF =dgQPySXEMOGhKaHnWIDwBbpqcrfmVo.get('code').strip()
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvx =dgQPySXEMOGhKaHnWIDwBbpqcrfmVo.get('title').strip()
    dgQPySXEMOGhKaHnWIDwBbpqcrfmUe=dgQPySXEMOGhKaHnWIDwBbpqcrfmVo.get('img').strip()
    dgQPySXEMOGhKaHnWIDwBbpqcrfmVY =dgQPySXEMOGhKaHnWIDwBbpqcrfmVo.get('videoid').strip()
    try:
     dgQPySXEMOGhKaHnWIDwBbpqcrfmUe=dgQPySXEMOGhKaHnWIDwBbpqcrfmUe.replace('\'','\"')
     dgQPySXEMOGhKaHnWIDwBbpqcrfmUe=json.loads(dgQPySXEMOGhKaHnWIDwBbpqcrfmUe)
    except:
     dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
    dgQPySXEMOGhKaHnWIDwBbpqcrfmlU={}
    dgQPySXEMOGhKaHnWIDwBbpqcrfmlU['plot']=dgQPySXEMOGhKaHnWIDwBbpqcrfmvx
    if dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='vod':
     if dgQPySXEMOGhKaHnWIDwBbpqcrfmvC==dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ or dgQPySXEMOGhKaHnWIDwBbpqcrfmVY==dgQPySXEMOGhKaHnWIDwBbpqcrfmCV:
      dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':'EPISODE','programcode':dgQPySXEMOGhKaHnWIDwBbpqcrfmNF,'page':'1'}
      dgQPySXEMOGhKaHnWIDwBbpqcrfmvk=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY
     else:
      dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':'VOD','mediacode':dgQPySXEMOGhKaHnWIDwBbpqcrfmVY,'stype':'vod','programcode':dgQPySXEMOGhKaHnWIDwBbpqcrfmNF,'title':dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,'thumbnail':dgQPySXEMOGhKaHnWIDwBbpqcrfmUe}
      dgQPySXEMOGhKaHnWIDwBbpqcrfmvk=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
    else:
     dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':'MOVIE','mediacode':dgQPySXEMOGhKaHnWIDwBbpqcrfmNF,'stype':'movie','title':dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,'thumbnail':dgQPySXEMOGhKaHnWIDwBbpqcrfmUe}
     dgQPySXEMOGhKaHnWIDwBbpqcrfmvk=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
    dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel='',img=dgQPySXEMOGhKaHnWIDwBbpqcrfmUe,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmlU,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmvk,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlU={'plot':'시청목록을 삭제합니다.'}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx='*** 시청목록 삭제 ***'
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':'MYVIEW_REMOVE','stype':dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ,'skey':'-',}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvF=os.path.join(xbmcaddon.Addon().getAddonInfo('path'),'img','delete.png')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel='',img=dgQPySXEMOGhKaHnWIDwBbpqcrfmvF,infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmlU,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL,isLink=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY)
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ=='movie':xbmcplugin.setContent(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,'movies')
   else:xbmcplugin.setContent(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,'tvshows')
   xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,cacheToDisc=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ)
 def Save_Searched_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmVs):
  try:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNL=dgQPySXEMOGhKaHnWIDwBbpqcrfmtA
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNV=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.Load_List_File('search') 
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNk={'skey':dgQPySXEMOGhKaHnWIDwBbpqcrfmVs.strip()}
   fp=dgQPySXEMOGhKaHnWIDwBbpqcrfmCi(dgQPySXEMOGhKaHnWIDwBbpqcrfmNL,'w',-1,'utf-8')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNx=urllib.parse.urlencode(dgQPySXEMOGhKaHnWIDwBbpqcrfmNk)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNx=dgQPySXEMOGhKaHnWIDwBbpqcrfmNx+'\n'
   fp.write(dgQPySXEMOGhKaHnWIDwBbpqcrfmNx)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmNs=0
   for dgQPySXEMOGhKaHnWIDwBbpqcrfmNY in dgQPySXEMOGhKaHnWIDwBbpqcrfmNV:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmNC=dgQPySXEMOGhKaHnWIDwBbpqcrfmCA(urllib.parse.parse_qsl(dgQPySXEMOGhKaHnWIDwBbpqcrfmNY))
    dgQPySXEMOGhKaHnWIDwBbpqcrfmNR=dgQPySXEMOGhKaHnWIDwBbpqcrfmNk.get('skey').strip()
    dgQPySXEMOGhKaHnWIDwBbpqcrfmNi=dgQPySXEMOGhKaHnWIDwBbpqcrfmNC.get('skey').strip()
    if dgQPySXEMOGhKaHnWIDwBbpqcrfmNR!=dgQPySXEMOGhKaHnWIDwBbpqcrfmNi:
     fp.write(dgQPySXEMOGhKaHnWIDwBbpqcrfmNY)
     dgQPySXEMOGhKaHnWIDwBbpqcrfmNs+=1
     if dgQPySXEMOGhKaHnWIDwBbpqcrfmNs>=50:break
   fp.close()
  except:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
 def play_VIDEO(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.SaveCredential(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_winCredential())
  dgQPySXEMOGhKaHnWIDwBbpqcrfmNo =dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('mediacode')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ =dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('stype')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmNT =dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('pvrmode')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmNj=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_selQuality(dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmYt,dgQPySXEMOGhKaHnWIDwBbpqcrfmYv=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.GetBroadURL(dgQPySXEMOGhKaHnWIDwBbpqcrfmNo,dgQPySXEMOGhKaHnWIDwBbpqcrfmNj,dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ,dgQPySXEMOGhKaHnWIDwBbpqcrfmNT)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.addon_log('qt, stype, url : %s - %s - %s'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmCs(dgQPySXEMOGhKaHnWIDwBbpqcrfmNj),dgQPySXEMOGhKaHnWIDwBbpqcrfmUJ,dgQPySXEMOGhKaHnWIDwBbpqcrfmYt))
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmYt=='':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.addon_noti(__language__(30908).encode('utf8'))
   return
  dgQPySXEMOGhKaHnWIDwBbpqcrfmYU =dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
  dgQPySXEMOGhKaHnWIDwBbpqcrfmYl =dgQPySXEMOGhKaHnWIDwBbpqcrfmYt.find('Policy=')
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmYl!=-1:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYV =dgQPySXEMOGhKaHnWIDwBbpqcrfmYt.split('?')[0]
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYN=dgQPySXEMOGhKaHnWIDwBbpqcrfmCA(urllib.parse.parse_qsl(urllib.parse.urlsplit(dgQPySXEMOGhKaHnWIDwBbpqcrfmYt).query))
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYC='CloudFront-Policy=%s;CloudFront-Signature=%s;CloudFront-Key-Pair-Id=%s'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmYN['Policy'],dgQPySXEMOGhKaHnWIDwBbpqcrfmYN['Signature'],dgQPySXEMOGhKaHnWIDwBbpqcrfmYN['Key-Pair-Id'])
   if 'quickvod-mcdn.tving.com' in dgQPySXEMOGhKaHnWIDwBbpqcrfmYV:
    dgQPySXEMOGhKaHnWIDwBbpqcrfmYU=dgQPySXEMOGhKaHnWIDwBbpqcrfmCY
    dgQPySXEMOGhKaHnWIDwBbpqcrfmYJ =dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.Get_Now_Datetime()+datetime.timedelta(minutes=-1)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmYu=dgQPySXEMOGhKaHnWIDwBbpqcrfmYJ.strftime('%Y-%m-%d-%H:%M:%S')
    if dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(dgQPySXEMOGhKaHnWIDwBbpqcrfmYu.replace('-','').replace(':',''))<dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(dgQPySXEMOGhKaHnWIDwBbpqcrfmYN['end'].replace('-','').replace(':','')):
     dgQPySXEMOGhKaHnWIDwBbpqcrfmYN['end']=dgQPySXEMOGhKaHnWIDwBbpqcrfmYu
     dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.addon_noti(__language__(30915).encode('utf8'))
    dgQPySXEMOGhKaHnWIDwBbpqcrfmYV ='%s?start=%s&end=%s'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmYV,dgQPySXEMOGhKaHnWIDwBbpqcrfmYN['start'],dgQPySXEMOGhKaHnWIDwBbpqcrfmYN['end'])
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYA='%s|Cookie=%s'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmYV,dgQPySXEMOGhKaHnWIDwBbpqcrfmYC)
  else:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYA=dgQPySXEMOGhKaHnWIDwBbpqcrfmYt
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.addon_log(dgQPySXEMOGhKaHnWIDwBbpqcrfmYA)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmYx=xbmcgui.ListItem(path=dgQPySXEMOGhKaHnWIDwBbpqcrfmYA)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmYv!='':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYs=dgQPySXEMOGhKaHnWIDwBbpqcrfmYv
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYR ='https://cj.drmkeyserver.com/widevine_license'
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYi ='mpd'
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYz ='com.widevine.alpha'
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYe =inputstreamhelper.Helper(dgQPySXEMOGhKaHnWIDwBbpqcrfmYi,drm='widevine')
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmYe.check_inputstream():
    dgQPySXEMOGhKaHnWIDwBbpqcrfmYF={'origin':'https://www.tving.com','pragma':'no-cache','referer':'https://www.tving.com/live/player/%s'%dgQPySXEMOGhKaHnWIDwBbpqcrfmNo,'sec-fetch-mode':'cors','sec-fetch-site':'same-site','user-agent':dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.USER_AGENT,'AcquireLicenseAssertion':dgQPySXEMOGhKaHnWIDwBbpqcrfmYs,'Host':'cj.drmkeyserver.com'}
    dgQPySXEMOGhKaHnWIDwBbpqcrfmYL=dgQPySXEMOGhKaHnWIDwBbpqcrfmYR+'|'+urllib.parse.urlencode(dgQPySXEMOGhKaHnWIDwBbpqcrfmYF)+'|R{SSM}|'
    dgQPySXEMOGhKaHnWIDwBbpqcrfmYx.setProperty('inputstream',dgQPySXEMOGhKaHnWIDwBbpqcrfmYe.inputstream_addon)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmYx.setProperty('inputstream.adaptive.manifest_type',dgQPySXEMOGhKaHnWIDwBbpqcrfmYi)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmYx.setProperty('inputstream.adaptive.license_type',dgQPySXEMOGhKaHnWIDwBbpqcrfmYz)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmYx.setProperty('inputstream.adaptive.license_key',dgQPySXEMOGhKaHnWIDwBbpqcrfmYL)
    dgQPySXEMOGhKaHnWIDwBbpqcrfmYx.setProperty('inputstream.adaptive.stream_headers','user-agent=%s'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.USER_AGENT))
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmYU==dgQPySXEMOGhKaHnWIDwBbpqcrfmCY:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYx.setContentLookup(dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ)
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYx.setMimeType('application/x-mpegURL')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYx.setProperty('inputstream','inputstream.ffmpegdirect')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYx.setProperty('inputstream.ffmpegdirect.open_mode','ffmpeg')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYx.setProperty('inputstream.ffmpegdirect.is_realtime_stream','false')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYx.setProperty('inputstream.ffmpegdirect.mime_type','hls')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYx.setProperty('ResumeTime','0')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYx.setProperty('TotalTime','10000')
  xbmcplugin.setResolvedUrl(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,dgQPySXEMOGhKaHnWIDwBbpqcrfmCY,dgQPySXEMOGhKaHnWIDwBbpqcrfmYx)
  try:
   if dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('mode')in['VOD','MOVIE']and dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('title'):
    dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'code':dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('programcode')if dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('mode')=='VOD' else dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('mediacode'),'img':dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('thumbnail'),'title':dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('title'),'videoid':dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('mediacode')}
    dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.Save_Watched_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('stype'),dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
  except:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
 def logout(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmte=xbmcgui.Dialog()
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUV=dgQPySXEMOGhKaHnWIDwBbpqcrfmte.yesno(__language__(30910).encode('utf8'),__language__(30905).encode('utf8'))
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUV==dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ:sys.exit()
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.wininfo_clear()
  if os.path.isfile(dgQPySXEMOGhKaHnWIDwBbpqcrfmtu):os.remove(dgQPySXEMOGhKaHnWIDwBbpqcrfmtu)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.addon_noti(__language__(30909).encode('utf-8'))
 def wininfo_clear(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ=xbmcgui.Window(10000)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_TOKEN','')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_USERINFO','')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_UUID','')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_LOGINTIME','')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_MAINTOKEN','')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_COOKIEKEY','')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_LOCKKEY','')
 def cookiefile_save(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmYk =dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.Get_Now_Datetime()
  dgQPySXEMOGhKaHnWIDwBbpqcrfmYo=dgQPySXEMOGhKaHnWIDwBbpqcrfmYk+datetime.timedelta(days=dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(__addon__.getSetting('cache_ttl')))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ=xbmcgui.Window(10000)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmYT={'tving_token':dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.getProperty('TVING_M_TOKEN'),'tving_userinfo':dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.getProperty('TVING_M_USERINFO'),'tving_uuid':dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.getProperty('TVING_M_UUID'),'tving_id':base64.standard_b64encode(__addon__.getSetting('id').encode()).decode('utf-8'),'tving_pw':base64.standard_b64encode(__addon__.getSetting('pw').encode()).decode('utf-8'),'tving_logintype':__addon__.getSetting('login_type'),'tving_profile':__addon__.getSetting('selected_profile'),'tving_limitdate':dgQPySXEMOGhKaHnWIDwBbpqcrfmYo.strftime('%Y-%m-%d'),'tving_maintoken':dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.getProperty('TVING_M_MAINTOKEN'),'tving_cookiekey':dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.getProperty('TVING_M_COOKIEKEY'),'tving_lockkey':dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.getProperty('TVING_M_LOCKKEY')}
  try: 
   fp=dgQPySXEMOGhKaHnWIDwBbpqcrfmCi(dgQPySXEMOGhKaHnWIDwBbpqcrfmtu,'w',-1,'utf-8')
   json.dump(dgQPySXEMOGhKaHnWIDwBbpqcrfmYT,fp)
   fp.close()
  except dgQPySXEMOGhKaHnWIDwBbpqcrfmCz as exception:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmCe(exception)
 def cookiefile_check(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmYT={}
  try: 
   fp=dgQPySXEMOGhKaHnWIDwBbpqcrfmCi(dgQPySXEMOGhKaHnWIDwBbpqcrfmtu,'r',-1,'utf-8')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYT= json.load(fp)
   fp.close()
  except dgQPySXEMOGhKaHnWIDwBbpqcrfmCz as exception:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.wininfo_clear()
   return dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvj =__addon__.getSetting('id')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUt =__addon__.getSetting('pw')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmYj=__addon__.getSetting('login_type')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmCt =__addon__.getSetting('selected_profile')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_id']=base64.standard_b64decode(dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_id']).decode('utf-8')
  dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_pw']=base64.standard_b64decode(dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_pw']).decode('utf-8')
  try:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_profile']
  except:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_profile']='0'
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmvj!=dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_id']or dgQPySXEMOGhKaHnWIDwBbpqcrfmUt!=dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_pw']or dgQPySXEMOGhKaHnWIDwBbpqcrfmYj!=dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_logintype']or dgQPySXEMOGhKaHnWIDwBbpqcrfmCt!=dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_profile']:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.wininfo_clear()
   return dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUN =dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.Get_Now_Datetime().strftime('%Y%m%d'))
  dgQPySXEMOGhKaHnWIDwBbpqcrfmCv=dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_limitdate']
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUY =dgQPySXEMOGhKaHnWIDwBbpqcrfmCN(re.sub('-','',dgQPySXEMOGhKaHnWIDwBbpqcrfmCv))
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmUY<dgQPySXEMOGhKaHnWIDwBbpqcrfmUN:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.wininfo_clear()
   return dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ=xbmcgui.Window(10000)
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_TOKEN',dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_token'])
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_USERINFO',dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_userinfo'])
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_UUID',dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_uuid'])
  dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_LOGINTIME',dgQPySXEMOGhKaHnWIDwBbpqcrfmCv)
  try:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_MAINTOKEN',dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_maintoken'])
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_COOKIEKEY',dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_cookiekey'])
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_LOCKKEY',dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_lockkey'])
  except:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_MAINTOKEN',dgQPySXEMOGhKaHnWIDwBbpqcrfmYT['tving_token'])
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_COOKIEKEY','Y')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvJ.setProperty('TVING_M_LOCKKEY','N')
  return dgQPySXEMOGhKaHnWIDwBbpqcrfmCY
 def dp_Global_Search(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=dgQPySXEMOGhKaHnWIDwBbpqcrfmUx.get('mode')
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=='TOTAL_SEARCH':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmCU='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_SEARCH",return)'
  else:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmCU='ActivateWindow(10025,"plugin://plugin.video.searchm/?mode=TOTAL_HISTORY",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(dgQPySXEMOGhKaHnWIDwBbpqcrfmCU)
 def dp_Bookmark_Menu(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmCU='ActivateWindow(10025,"plugin://plugin.video.bookmarkm/",return)'
  xbmc.executebuiltin('Dialog.Close(all,true)')
  xbmc.executebuiltin(dgQPySXEMOGhKaHnWIDwBbpqcrfmCU)
 def dp_EuroLive_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx,dgQPySXEMOGhKaHnWIDwBbpqcrfmUx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.SaveCredential(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.get_winCredential())
  dgQPySXEMOGhKaHnWIDwBbpqcrfmUR=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.TvingObj.GetEuroChannelList()
  for dgQPySXEMOGhKaHnWIDwBbpqcrfmUz in dgQPySXEMOGhKaHnWIDwBbpqcrfmUR:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlA =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('channel')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvx =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('title')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlV =dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('subtitle')
   dgQPySXEMOGhKaHnWIDwBbpqcrfmlU={'mediatype':'episode','title':dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,'plot':'%s\n%s'%(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,dgQPySXEMOGhKaHnWIDwBbpqcrfmlV)}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmvL={'mode':'LIVE','mediacode':dgQPySXEMOGhKaHnWIDwBbpqcrfmUz.get('channel'),'stype':'onair',}
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.add_dir(dgQPySXEMOGhKaHnWIDwBbpqcrfmvx,sublabel=dgQPySXEMOGhKaHnWIDwBbpqcrfmlV,img='',infoLabels=dgQPySXEMOGhKaHnWIDwBbpqcrfmlU,isFolder=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ,params=dgQPySXEMOGhKaHnWIDwBbpqcrfmvL)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmCx(dgQPySXEMOGhKaHnWIDwBbpqcrfmUR)>0:xbmcplugin.endOfDirectory(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx._addon_handle,cacheToDisc=dgQPySXEMOGhKaHnWIDwBbpqcrfmCJ)
 def tving_main(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx):
  dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params.get('mode',dgQPySXEMOGhKaHnWIDwBbpqcrfmCV)
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=='LOGOUT':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.logout()
   return
  dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.login_main()
  if dgQPySXEMOGhKaHnWIDwBbpqcrfmVR is dgQPySXEMOGhKaHnWIDwBbpqcrfmCV:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_Main_List()
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR in['LIVE_GROUP','VOD_GROUP','MOVIE_GROUP']:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_Title_Group(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR in['GLOBAL_GROUP']:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_SubTitle_Group(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=='CHANNEL':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_LiveChannel_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR in['LIVE','VOD','MOVIE']:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.play_VIDEO(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=='PROGRAM':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_Program_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=='EPISODE':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_Episode_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=='MOVIE_SUB':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_Movie_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=='SEARCH_GROUP':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_Search_Group(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR in['SEARCH','LOCAL_SEARCH']:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_Search_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=='WATCH':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_Watch_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR in['MYVIEW_REMOVE','SEARCH_REMOVE']:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_Listfile_Delete(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=='ORDER_BY':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_setEpOrderby(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=='SET_BOOKMARK':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_Set_Bookmark(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR in['TOTAL_SEARCH','TOTAL_HISTORY']:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_Global_Search(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=='SEARCH_HISTORY':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_Search_History(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=='MENU_BOOKMARK':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_Bookmark_Menu(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  elif dgQPySXEMOGhKaHnWIDwBbpqcrfmVR=='EURO_GROUP':
   dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.dp_EuroLive_List(dgQPySXEMOGhKaHnWIDwBbpqcrfmtx.main_params)
  else:
   dgQPySXEMOGhKaHnWIDwBbpqcrfmCV
# Created by pyminifier (https://github.com/liftoff/pyminifier)
