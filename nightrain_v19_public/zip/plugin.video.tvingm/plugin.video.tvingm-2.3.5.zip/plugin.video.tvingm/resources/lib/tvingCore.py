__author__="NightRain"
QpLJXxhfDcPvOrwdzyAqsUCKbmFnol=object
QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS=None
QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB=False
QpLJXxhfDcPvOrwdzyAqsUCKbmFnoH=int
QpLJXxhfDcPvOrwdzyAqsUCKbmFnog=range
QpLJXxhfDcPvOrwdzyAqsUCKbmFnoY=True
QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM=Exception
QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV=print
QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj=str
QpLJXxhfDcPvOrwdzyAqsUCKbmFnoW=list
QpLJXxhfDcPvOrwdzyAqsUCKbmFnot=len
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
QpLJXxhfDcPvOrwdzyAqsUCKbmFnae={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
QpLJXxhfDcPvOrwdzyAqsUCKbmFnaT ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
class QpLJXxhfDcPvOrwdzyAqsUCKbmFnak(QpLJXxhfDcPvOrwdzyAqsUCKbmFnol):
 def __init__(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_TOKEN =''
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.POC_USERINFO =''
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_UUID ='-'
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_MAINTOKEN=''
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVIGN_COOKIEKEY=''
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_LOCKKEY =''
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.NETWORKCODE ='CSND0900'
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.OSCODE ='CSOD0900' 
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TELECODE ='CSCD0900'
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.SCREENCODE ='CSSD0100'
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.LIVE_LIMIT =23
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.VOD_LIMIT =20
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.EPISODE_LIMIT =30 
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.SEARCH_LIMIT =30 
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.MOVIE_LIMIT =18
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.API_DOMAIN ='https://api.tving.com'
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN ='https://image.tving.com'
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.SEARCH_DOMAIN ='https://search.tving.com'
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.LOGIN_DOMAIN ='https://user.tving.com'
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.URL_DOMAIN ='https://www.tving.com'
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.MOVIE_LITE =['2610061','2610161','261062']
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36'
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.DEFAULT_HEADER ={'user-agent':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.USER_AGENT}
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GLOBAL_COOKIENM={'tv_maintoken':'_tutB3583','tv_cookiekey':'TP2wgas1K9Q8F7B359108383','tv_lockkey':'TPLYFLt9NxVcJjQhn7Ee0069'}
 def callRequestCookies(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,jobtype,QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,redirects=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnao=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.DEFAULT_HEADER
  if headers:QpLJXxhfDcPvOrwdzyAqsUCKbmFnao.update(headers)
  if jobtype=='Get':
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnau=requests.get(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,params=params,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnao,cookies=cookies,allow_redirects=redirects)
  else:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnau=requests.post(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,data=payload,params=params,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnao,cookies=cookies,allow_redirects=redirects)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnau
 def makeDefaultCookies(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,vToken=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,vUserinfo=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnai={}
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnai['_tving_token']=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_TOKEN if vToken==QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS else vToken
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnai['POC_USERINFO']=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.POC_USERINFO if vToken==QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS else vUserinfo
  if QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_MAINTOKEN!='':QpLJXxhfDcPvOrwdzyAqsUCKbmFnai[QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GLOBAL_COOKIENM['tv_maintoken']]=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_MAINTOKEN
  if QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVIGN_COOKIEKEY!='':QpLJXxhfDcPvOrwdzyAqsUCKbmFnai[QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GLOBAL_COOKIENM['tv_cookiekey']]=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVIGN_COOKIEKEY
  if QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_LOCKKEY !='':QpLJXxhfDcPvOrwdzyAqsUCKbmFnai[QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GLOBAL_COOKIENM['tv_lockkey']] =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_LOCKKEY
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnai
 def getDeviceStr(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaR=[]
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaR.append('Windows') 
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaR.append('Chrome') 
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaR.append('ko-KR') 
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaR.append('undefined') 
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaR.append('24') 
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaR.append(u'한국 표준시')
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaR.append('undefined') 
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaR.append('undefined') 
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaR.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnal=''
  for QpLJXxhfDcPvOrwdzyAqsUCKbmFnaS in QpLJXxhfDcPvOrwdzyAqsUCKbmFnaR:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnal+=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaS+'|'
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnal
 def SaveCredential(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,QpLJXxhfDcPvOrwdzyAqsUCKbmFnaB):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_TOKEN =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaB.get('tving_token')
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.POC_USERINFO =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaB.get('poc_userinfo')
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_UUID =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaB.get('tving_uuid')
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_MAINTOKEN=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaB.get('tving_maintoken')
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVIGN_COOKIEKEY=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaB.get('tving_cookiekey')
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_LOCKKEY =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaB.get('tving_lockkey')
 def LoadCredential(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaB={'tving_token':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_TOKEN,'poc_userinfo':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.POC_USERINFO,'tving_uuid':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_UUID,'tving_maintoken':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_MAINTOKEN,'tving_cookiekey':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVIGN_COOKIEKEY,'tving_lockkey':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_LOCKKEY}
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnaB
 def GetDefaultParams(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaH={'apiKey':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.APIKEY,'networkCode':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.NETWORKCODE,'osCode':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.OSCODE,'teleCode':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TELECODE,'screenCode':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.SCREENCODE}
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnaH
 def GetNoCache(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,timetype=1):
  if timetype==1:
   return QpLJXxhfDcPvOrwdzyAqsUCKbmFnoH(time.time())
  else:
   return QpLJXxhfDcPvOrwdzyAqsUCKbmFnoH(time.time()*1000)
 def GetUniqueid(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnag=[0 for i in QpLJXxhfDcPvOrwdzyAqsUCKbmFnog(256)]
  for i in QpLJXxhfDcPvOrwdzyAqsUCKbmFnog(256):
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnag[i]='%02x'%(i)
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaY=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoH(4294967295*random.random())|0
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaM=QpLJXxhfDcPvOrwdzyAqsUCKbmFnag[255&QpLJXxhfDcPvOrwdzyAqsUCKbmFnaY]+QpLJXxhfDcPvOrwdzyAqsUCKbmFnag[QpLJXxhfDcPvOrwdzyAqsUCKbmFnaY>>8&255]+QpLJXxhfDcPvOrwdzyAqsUCKbmFnag[QpLJXxhfDcPvOrwdzyAqsUCKbmFnaY>>16&255]+QpLJXxhfDcPvOrwdzyAqsUCKbmFnag[QpLJXxhfDcPvOrwdzyAqsUCKbmFnaY>>24&255]
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnaM
 def GetCredential(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,user_id,user_pw,login_type,user_pf):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaV=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaj=QpLJXxhfDcPvOrwdzyAqsUCKbmFnka=QpLJXxhfDcPvOrwdzyAqsUCKbmFnke=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkT=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkN='' 
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaW ='-'
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnat=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaG={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com/main.do','csite':''}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Post',QpLJXxhfDcPvOrwdzyAqsUCKbmFnat,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaG,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS)
   for QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI in QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.cookies:
    if QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.name=='_tving_token':
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnka=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.value
    elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.name=='POC_USERINFO':
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnke=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.value
   if QpLJXxhfDcPvOrwdzyAqsUCKbmFnka=='':return QpLJXxhfDcPvOrwdzyAqsUCKbmFnaV
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaj=QpLJXxhfDcPvOrwdzyAqsUCKbmFnka
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnka,QpLJXxhfDcPvOrwdzyAqsUCKbmFnkT,QpLJXxhfDcPvOrwdzyAqsUCKbmFnkN=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetProfileToken(QpLJXxhfDcPvOrwdzyAqsUCKbmFnka,QpLJXxhfDcPvOrwdzyAqsUCKbmFnke,user_pf)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaV=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoY
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaW =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetDeviceList(QpLJXxhfDcPvOrwdzyAqsUCKbmFnka,QpLJXxhfDcPvOrwdzyAqsUCKbmFnke)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaW =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaW+'-'+QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetUniqueid()
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaj=QpLJXxhfDcPvOrwdzyAqsUCKbmFnka=QpLJXxhfDcPvOrwdzyAqsUCKbmFnke=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkT=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkN=''
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaW='-'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaB={'tving_token':QpLJXxhfDcPvOrwdzyAqsUCKbmFnka,'poc_userinfo':QpLJXxhfDcPvOrwdzyAqsUCKbmFnke,'tving_uuid':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaW,'tving_maintoken':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaj,'tving_cookiekey':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkT,'tving_lockkey':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkN}
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.SaveCredential(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaB)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnaV
 def Get_Now_Datetime(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def GetBroadURL(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,mediacode,sel_quality,stype,pvrmode='-'):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnku=''
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnki=''
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnkR =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_UUID.split('-')[0] 
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnkl =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.TVING_UUID 
  if mediacode=='C01345':
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnku='http://ocn-mcdn.tving.com/ocn/live5000.smil/playlist.m3u8?Policy=eyJTdGF0ZW1lbnQiOiBbeyJSZXNvdXJjZSI6Imh0dHA6Ly8qIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNjEwODMwODAwfSwiSXBBZGRyZXNzIjp7IkFXUzpTb3VyY2VJcCI6IjAuMC4wLjAvMCJ9fX1dfQ__&Signature=eqJMOA5c~hIlgUVIDOtLCCfKXnNO0XHex3uQVQE87ZfuutuH2hqAgddlijKNWDz2Qrg5ScRkuXuU-7QQoj4QFSPPjyvwJSSrrZtNNVxU8xERXywdUKUwQGfDvl78F4rhS7WP-O1Q86KnLwif9QW0GPRK~n8ceOITlYq22rVLqp~EKwmoGQ3cvw01TMBFRInvobRtXR-zGyMZCx9MDgeHMRay0U9Ibp7nUPb3~T~set~W3so1ovUnF0iLuQpuarXQA3QIBy25O24NVbwalTtzjPoULkpEHeuVsMx-ACom3MTM65kB5TKJNIx19sdlAFQIII7n39FpWgSOO6A8jvu~rA__&Key-Pair-Id=APKAIXCIJCFRGOUEZDWA'
  try:
   if stype!='tvingtv' and(pvrmode=='-' or stype!='onair'):
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/v2a/media/stream/info' 
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetDefaultParams()
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH={'info':'N','mediaCode':mediacode,'noCache':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkR,'uuid':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkl,'deviceInfo':'PC','wm':'Y'}
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB.update(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH)
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.API_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnai=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.makeDefaultCookies()
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnai)
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY=json.loads(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
    if not('stream' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']):return QpLJXxhfDcPvOrwdzyAqsUCKbmFnku,QpLJXxhfDcPvOrwdzyAqsUCKbmFnki 
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnkM=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']['stream']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnkV=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkM['quality']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnkj=[]
    for QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkV:
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['active']=='Y':
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnkj.append({QpLJXxhfDcPvOrwdzyAqsUCKbmFnae.get(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['code']):QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['code']})
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnkt=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.CheckQuality(sel_quality,QpLJXxhfDcPvOrwdzyAqsUCKbmFnkj)
   else:
    for QpLJXxhfDcPvOrwdzyAqsUCKbmFnkG,QpLJXxhfDcPvOrwdzyAqsUCKbmFneu in QpLJXxhfDcPvOrwdzyAqsUCKbmFnae.items():
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFneu==sel_quality:
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnkt=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkG
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
   for QpLJXxhfDcPvOrwdzyAqsUCKbmFnkG,QpLJXxhfDcPvOrwdzyAqsUCKbmFneu in QpLJXxhfDcPvOrwdzyAqsUCKbmFnae.items():
    if QpLJXxhfDcPvOrwdzyAqsUCKbmFneu==sel_quality:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnkt=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkG
   return QpLJXxhfDcPvOrwdzyAqsUCKbmFnku,QpLJXxhfDcPvOrwdzyAqsUCKbmFnki
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkt)
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/streaming/info'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetDefaultParams()
   if stype=='onair':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB['osCode']='CSOD0400' 
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkE={'isTrusted':'false','NONE':'0','CAPTURING_PHASE':'1','AT_TARGET':'2','BUBBLING_PHASE':'3','type':'oocCreate','eventPhase':'0','bubbles':'false','cancelable':'false','defaultPrevented':'false','composed':'false','timeStamp':'2785.9800000005635','returnValue':'true','cancelBubble':'false'}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkI=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.makeOocUrl(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkE)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnea=urllib.parse.quote(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkI)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH={'info':'N','mediaCode':mediacode,'callingFrom':'HTML5','streamCode':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkt,'adReq':'adproxy','ooc':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkI,'deviceId':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkR,'uuid':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkl,'deviceInfo':'PC'}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnek =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnek.update(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.URL_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneT={'origin':'https://www.tving.com'}
   if stype=='onair':QpLJXxhfDcPvOrwdzyAqsUCKbmFneT['Referer']='https://www.tving.com/live/player/'+mediacode
   else: QpLJXxhfDcPvOrwdzyAqsUCKbmFneT['Referer']='https://www.tving.com/vod/player/'+mediacode
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnai=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.makeDefaultCookies()
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnai['onClickEvent2']=QpLJXxhfDcPvOrwdzyAqsUCKbmFnea
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Post',QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnek,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFneT,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnai,redirects=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY=json.loads(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   if 'drm_license_assertion' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['stream']:
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnki =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['stream']['drm_license_assertion']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnku=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['stream']['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['stream']['broadcast']):return QpLJXxhfDcPvOrwdzyAqsUCKbmFnku,QpLJXxhfDcPvOrwdzyAqsUCKbmFnki
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnku=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['stream']['broadcast']['broad_url']
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnku,QpLJXxhfDcPvOrwdzyAqsUCKbmFnki
 def CheckQuality(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,sel_qt,QpLJXxhfDcPvOrwdzyAqsUCKbmFnkj):
  for QpLJXxhfDcPvOrwdzyAqsUCKbmFneN in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkj:
   if sel_qt>=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoW(QpLJXxhfDcPvOrwdzyAqsUCKbmFneN)[0]:return QpLJXxhfDcPvOrwdzyAqsUCKbmFneN.get(QpLJXxhfDcPvOrwdzyAqsUCKbmFnoW(QpLJXxhfDcPvOrwdzyAqsUCKbmFneN)[0])
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneo=QpLJXxhfDcPvOrwdzyAqsUCKbmFneN.get(QpLJXxhfDcPvOrwdzyAqsUCKbmFnoW(QpLJXxhfDcPvOrwdzyAqsUCKbmFneN)[0])
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFneo
 def makeOocUrl(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,QpLJXxhfDcPvOrwdzyAqsUCKbmFnkE):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=''
  for QpLJXxhfDcPvOrwdzyAqsUCKbmFnkG,QpLJXxhfDcPvOrwdzyAqsUCKbmFneu in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkE.items():
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg+="%s=%s^"%(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkG,QpLJXxhfDcPvOrwdzyAqsUCKbmFneu)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg
 def GetLiveChannelList(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,stype,page_int):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnei=[]
  QpLJXxhfDcPvOrwdzyAqsUCKbmFneR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnel=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/v2/media/lives'
   if stype=='onair': 
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneS='CPCS0100,CPCS0400'
   else:
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneS='CPCS0300'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetDefaultParams()
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH={'pageNo':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(page_int),'pageSize':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':QpLJXxhfDcPvOrwdzyAqsUCKbmFneS,'_':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetNoCache(2))}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB.update(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.API_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY=json.loads(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   if not('result' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']):return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']['result']
   for QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW in QpLJXxhfDcPvOrwdzyAqsUCKbmFneB:
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneH=QpLJXxhfDcPvOrwdzyAqsUCKbmFneM=QpLJXxhfDcPvOrwdzyAqsUCKbmFneV=''
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnTB=''
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneY=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['live_code']
    if QpLJXxhfDcPvOrwdzyAqsUCKbmFneY=='C01345':QpLJXxhfDcPvOrwdzyAqsUCKbmFnel=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoY 
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneH =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['channel']['name']['ko']
    if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['episode']!=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFneM =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['program']['name']['ko']
     QpLJXxhfDcPvOrwdzyAqsUCKbmFneM =QpLJXxhfDcPvOrwdzyAqsUCKbmFneM+', '+QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['episode']['frequency'])+'회'
     QpLJXxhfDcPvOrwdzyAqsUCKbmFneV=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['episode']['synopsis']['ko']
    else:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFneM =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['program']['name']['ko']
     QpLJXxhfDcPvOrwdzyAqsUCKbmFneV=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['program']['synopsis']['ko']
    try: 
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =''
     QpLJXxhfDcPvOrwdzyAqsUCKbmFneW =''
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnet=''
     QpLJXxhfDcPvOrwdzyAqsUCKbmFneG =''
     QpLJXxhfDcPvOrwdzyAqsUCKbmFneE =''
     QpLJXxhfDcPvOrwdzyAqsUCKbmFneI =''
     for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['program']['image']:
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP0900':QpLJXxhfDcPvOrwdzyAqsUCKbmFneW =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
      elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP1800':QpLJXxhfDcPvOrwdzyAqsUCKbmFnet=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
      elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP2000':QpLJXxhfDcPvOrwdzyAqsUCKbmFneG =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
      elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP1900':QpLJXxhfDcPvOrwdzyAqsUCKbmFneE =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
      elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP0200':QpLJXxhfDcPvOrwdzyAqsUCKbmFneI =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
      elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP0500':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
      elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP0800':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnej=='':
      for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['channel']['image']:
       if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIC0400':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
       elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIC1400':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
       elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIC1900':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
    except:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS
    try:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk =[]
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe=[]
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN =[]
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo=''
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTu=''
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTi=''
     for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTR in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('schedule').get('program').get('actor'):
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTR!='' and QpLJXxhfDcPvOrwdzyAqsUCKbmFnTR!=u'없음':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTR)
     for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTl in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('schedule').get('program').get('director'):
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTl!='' and QpLJXxhfDcPvOrwdzyAqsUCKbmFnTl!='-' and QpLJXxhfDcPvOrwdzyAqsUCKbmFnTl!=u'없음':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTl)
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('schedule').get('program').get('category1_name').get('ko')!='':
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['program']['category1_name']['ko'])
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('schedule').get('program').get('category2_name').get('ko')!='':
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['program']['category2_name']['ko'])
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('schedule').get('program').get('product_year'):QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['program']['product_year']
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('schedule').get('program').get('grade_code') :QpLJXxhfDcPvOrwdzyAqsUCKbmFnTu= QpLJXxhfDcPvOrwdzyAqsUCKbmFnaT.get(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['program']['grade_code'])
     if 'broad_dt' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('schedule').get('program'):
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('schedule').get('program').get('broad_dt')
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTi='%s-%s-%s'%(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[:4],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[4:6],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[6:])
    except:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['broadcast_start_time'])[8:12]
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTB =QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['schedule']['broadcast_end_time'])[8:12]
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH={'channel':QpLJXxhfDcPvOrwdzyAqsUCKbmFneH,'title':QpLJXxhfDcPvOrwdzyAqsUCKbmFneM,'mediacode':QpLJXxhfDcPvOrwdzyAqsUCKbmFneY,'thumbnail':{'poster':QpLJXxhfDcPvOrwdzyAqsUCKbmFneW,'thumb':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej,'clearlogo':QpLJXxhfDcPvOrwdzyAqsUCKbmFnet,'icon':QpLJXxhfDcPvOrwdzyAqsUCKbmFneG,'fanart':QpLJXxhfDcPvOrwdzyAqsUCKbmFneI},'synopsis':QpLJXxhfDcPvOrwdzyAqsUCKbmFneV,'channelepg':' [%s:%s ~ %s:%s]'%(QpLJXxhfDcPvOrwdzyAqsUCKbmFneg[0:2],QpLJXxhfDcPvOrwdzyAqsUCKbmFneg[2:],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTB[0:2],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTB[2:]),'cast':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk,'director':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe,'info_genre':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN,'year':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo,'mpaa':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTu,'premiered':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTi}
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnei.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH)
   if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']['has_more']=='Y':
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoY
   else:
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH={'channel':'OCN Original','title':'temp','mediacode':'C01345','thumbnail':'http://image.tving.com/upload/cms/caic/CAIC0400/C01345.png','cast':[],'director':[]}
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
 def GetProgramList(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,genre,orderby,page_int,genreCode='all'):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnei=[]
  QpLJXxhfDcPvOrwdzyAqsUCKbmFneR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/v2/media/episodes'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetDefaultParams()
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH={'pageNo':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(page_int),'pageSize':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','_':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetNoCache(2))}
   if genre !='all':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH['categoryCode']=genre
   if genreCode!='all':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH['genreCode'] =genreCode 
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB.update(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.API_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY=json.loads(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   if not('result' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']):return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']['result']
   for QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW in QpLJXxhfDcPvOrwdzyAqsUCKbmFneB:
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['program']['code']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneM =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['program']['name']['ko']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTu =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaT.get(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['program'].get('grade_code'))
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneW =''
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =''
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnet=''
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneG =''
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneE =''
    for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['program']['image']:
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP0900':QpLJXxhfDcPvOrwdzyAqsUCKbmFneW =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
     elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP0200':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
     elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP1800':QpLJXxhfDcPvOrwdzyAqsUCKbmFnet=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
     elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP2000':QpLJXxhfDcPvOrwdzyAqsUCKbmFneG =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
     elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP1900':QpLJXxhfDcPvOrwdzyAqsUCKbmFneE =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneV =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['program']['synopsis']['ko']
    try:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTY=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['channel']['name']['ko']
    except:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTY=''
    try:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk =[]
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe=[]
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN =[]
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo =''
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTi=''
     for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTR in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('program').get('actor'):
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTR!='' and QpLJXxhfDcPvOrwdzyAqsUCKbmFnTR!='-' and QpLJXxhfDcPvOrwdzyAqsUCKbmFnTR!=u'없음':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTR)
     for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTl in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('program').get('director'):
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTl!='' and QpLJXxhfDcPvOrwdzyAqsUCKbmFnTl!='-' and QpLJXxhfDcPvOrwdzyAqsUCKbmFnTl!=u'없음':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTl)
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('program').get('category1_name').get('ko')!='':
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['program']['category1_name']['ko'])
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('program').get('category2_name').get('ko')!='':
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['program']['category2_name']['ko'])
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('program').get('product_year'):QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['program']['product_year']
     if 'broad_dt' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('program'):
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('program').get('broad_dt')
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTi='%s-%s-%s'%(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[:4],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[4:6],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[6:])
    except:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH={'program':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTg,'title':QpLJXxhfDcPvOrwdzyAqsUCKbmFneM,'thumbnail':{'poster':QpLJXxhfDcPvOrwdzyAqsUCKbmFneW,'thumb':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej,'clearlogo':QpLJXxhfDcPvOrwdzyAqsUCKbmFnet,'icon':QpLJXxhfDcPvOrwdzyAqsUCKbmFneG,'banner':QpLJXxhfDcPvOrwdzyAqsUCKbmFneE,'fanart':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej},'synopsis':QpLJXxhfDcPvOrwdzyAqsUCKbmFneV,'channel':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTY,'cast':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk,'director':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe,'info_genre':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN,'year':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo,'premiered':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTi,'mpaa':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTu}
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnei.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH)
   if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']['has_more']=='Y':QpLJXxhfDcPvOrwdzyAqsUCKbmFneR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoY
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
 def GetEpisodeList(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,program_code,page_int,orderby='desc'):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnei=[]
  QpLJXxhfDcPvOrwdzyAqsUCKbmFneR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/v2/media/frequency/program/'+program_code
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetDefaultParams()
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH={'pageNo':'1','pageSize':'10','order':'new','free':'all','adult':'all','scope':'all','_':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetNoCache(2))}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB.update(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.API_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY=json.loads(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   if not('result' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']):return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']['result']
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnTM=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoH(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']['total_count'])
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnTV =QpLJXxhfDcPvOrwdzyAqsUCKbmFnoH(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTM//(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTj =(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTM-1)-((page_int-1)*QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.EPISODE_LIMIT)
   else:
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTj =(page_int-1)*QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.EPISODE_LIMIT
   for i in QpLJXxhfDcPvOrwdzyAqsUCKbmFnog(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.EPISODE_LIMIT):
    if orderby=='desc':
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW=QpLJXxhfDcPvOrwdzyAqsUCKbmFnTj-i
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW<0:break
    else:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW=QpLJXxhfDcPvOrwdzyAqsUCKbmFnTj+i
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW>=QpLJXxhfDcPvOrwdzyAqsUCKbmFnTM:break
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTt=QpLJXxhfDcPvOrwdzyAqsUCKbmFneB[QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW]['episode']['code']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneM =QpLJXxhfDcPvOrwdzyAqsUCKbmFneB[QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW]['vod_name']['ko']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTG =''
    try:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFneB[QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW]['episode']['broadcast_date'])
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTG='%s-%s-%s'%(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[:4],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[4:6],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[6:])
    except:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS
    try:
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFneB[QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW]['episode']['pip_cliptype']=='C012':
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTG+=' - Quick VOD'
    except:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneV =QpLJXxhfDcPvOrwdzyAqsUCKbmFneB[QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW]['episode']['synopsis']['ko']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneW =''
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =''
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnet=''
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneG =''
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneE =''
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneI =''
    for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa in QpLJXxhfDcPvOrwdzyAqsUCKbmFneB[QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW]['program']['image']:
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP0900':QpLJXxhfDcPvOrwdzyAqsUCKbmFneW =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
     elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP1800':QpLJXxhfDcPvOrwdzyAqsUCKbmFnet=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
     elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP2000':QpLJXxhfDcPvOrwdzyAqsUCKbmFneG =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
     elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP1900':QpLJXxhfDcPvOrwdzyAqsUCKbmFneE =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
     elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIP0200':QpLJXxhfDcPvOrwdzyAqsUCKbmFneI =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
    for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa in QpLJXxhfDcPvOrwdzyAqsUCKbmFneB[QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW]['episode']['image']:
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIE0400':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
    try:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnNa=QpLJXxhfDcPvOrwdzyAqsUCKbmFnNk=''
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTI=0
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTE =QpLJXxhfDcPvOrwdzyAqsUCKbmFneB[QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW]['program']['name']['ko']
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnNa =QpLJXxhfDcPvOrwdzyAqsUCKbmFnTG
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnNk =QpLJXxhfDcPvOrwdzyAqsUCKbmFneB[QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW]['channel']['name']['ko']
     if 'frequency' in QpLJXxhfDcPvOrwdzyAqsUCKbmFneB[QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW]['episode']:QpLJXxhfDcPvOrwdzyAqsUCKbmFnTI=QpLJXxhfDcPvOrwdzyAqsUCKbmFneB[QpLJXxhfDcPvOrwdzyAqsUCKbmFnTW]['episode']['frequency']
    except:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH={'episode':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTt,'title':QpLJXxhfDcPvOrwdzyAqsUCKbmFneM,'subtitle':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTG,'thumbnail':{'poster':QpLJXxhfDcPvOrwdzyAqsUCKbmFneW,'thumb':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej,'clearlogo':QpLJXxhfDcPvOrwdzyAqsUCKbmFnet,'icon':QpLJXxhfDcPvOrwdzyAqsUCKbmFneG,'banner':QpLJXxhfDcPvOrwdzyAqsUCKbmFneE,'fanart':QpLJXxhfDcPvOrwdzyAqsUCKbmFneI},'synopsis':QpLJXxhfDcPvOrwdzyAqsUCKbmFneV,'info_title':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTE,'aired':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNa,'studio':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNk,'frequency':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTI}
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnei.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH)
   if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTV>page_int:QpLJXxhfDcPvOrwdzyAqsUCKbmFneR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoY
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR,QpLJXxhfDcPvOrwdzyAqsUCKbmFnTV
 def GetMovieList(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,genre,orderby,page_int):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnei=[]
  QpLJXxhfDcPvOrwdzyAqsUCKbmFneR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/v2/media/movies'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetDefaultParams()
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH={'pageNo':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(page_int),'pageSize':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','_':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetNoCache(2))}
   if genre!='all' :QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH['multiCategoryCode']=genre
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH['productPackageCode']=','.join(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.MOVIE_LITE)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB.update(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.API_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY=json.loads(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   if not('result' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']):return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']['result']
   for QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW in QpLJXxhfDcPvOrwdzyAqsUCKbmFneB:
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNe =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['movie']['code']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneM =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['movie']['name']['ko'].strip()
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneM +=u' (%s)'%(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('movie').get('product_year'))
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneW=''
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =''
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnet=''
    for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['movie']['image']:
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIM2100':QpLJXxhfDcPvOrwdzyAqsUCKbmFneW =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
     elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIM0400':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
     elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIM1800':QpLJXxhfDcPvOrwdzyAqsUCKbmFnet=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneV =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['movie']['story']['ko']
    try:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTE =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['movie']['name']['ko'].strip()
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('movie').get('product_year')
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTu =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaT.get(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('grade_code'))
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk=[]
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe=[]
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN=[]
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnNT=0
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTi=''
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnNk =''
     for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTR in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('movie').get('actor'):
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTR!='':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTR)
     for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTl in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('movie').get('director'):
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTl!='':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTl)
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('movie').get('category1_name').get('ko')!='':
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['movie']['category1_name']['ko'])
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('movie').get('category2_name').get('ko')!='':
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['movie']['category2_name']['ko'])
     if 'duration' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('movie'):QpLJXxhfDcPvOrwdzyAqsUCKbmFnNT=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('movie').get('duration')
     if 'release_date' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('movie'):
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('movie').get('release_date'))
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS!='0':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTi='%s-%s-%s'%(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[:4],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[4:6],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[6:])
     if 'production' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('movie'):QpLJXxhfDcPvOrwdzyAqsUCKbmFnNk=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('movie').get('production')
    except:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH={'moviecode':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNe,'title':QpLJXxhfDcPvOrwdzyAqsUCKbmFneM,'thumbnail':{'poster':QpLJXxhfDcPvOrwdzyAqsUCKbmFneW,'thumb':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej,'clearlogo':QpLJXxhfDcPvOrwdzyAqsUCKbmFnet,'fanart':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej},'synopsis':QpLJXxhfDcPvOrwdzyAqsUCKbmFneV,'info_title':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTE,'year':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo,'cast':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk,'director':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe,'info_genre':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN,'duration':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNT,'premiered':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTi,'studio':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNk,'mpaa':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTu}
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNo=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB
    for QpLJXxhfDcPvOrwdzyAqsUCKbmFnNu in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['billing_package_id']:
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnNu in QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.MOVIE_LITE:
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnNo=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoY
      break
    if QpLJXxhfDcPvOrwdzyAqsUCKbmFnNo==QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB: 
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH['title']=QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH['title']+' [개별구매]'
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnei.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH)
   if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']['has_more']=='Y':QpLJXxhfDcPvOrwdzyAqsUCKbmFneR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoY
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
 def GetMovieListGenre(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,genre,page_int):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnei=[]
  QpLJXxhfDcPvOrwdzyAqsUCKbmFneR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/v2/media/movie/curation/'+genre
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetDefaultParams()
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH={'pageNo':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(page_int),'pageSize':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.MOVIE_LIMIT),'_':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetNoCache(2))}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB.update(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.API_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY=json.loads(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   if not('movies' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']):return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']['movies']
   for QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW in QpLJXxhfDcPvOrwdzyAqsUCKbmFneB:
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNe =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['code']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneM =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['name']['ko']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNi =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['image'][0]['url']
    for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['image']:
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['code']=='CAIM2100':
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnNi =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa['url']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFneV =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['story']['ko']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH={'moviecode':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNe,'title':QpLJXxhfDcPvOrwdzyAqsUCKbmFneM.strip(),'thumbnail':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNi,'synopsis':QpLJXxhfDcPvOrwdzyAqsUCKbmFneV}
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnei.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH)
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
 def GetMovieGenre(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnei=[]
  QpLJXxhfDcPvOrwdzyAqsUCKbmFneR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/v2/media/movie/curations'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetDefaultParams()
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code','_':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetNoCache(2))}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB.update(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.API_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY=json.loads(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   if not('result' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']):return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']['result']
   for QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW in QpLJXxhfDcPvOrwdzyAqsUCKbmFneB:
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNR =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['curation_code']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNl =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['curation_name']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH={'curation_code':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNR,'curation_name':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNl}
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnei.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH)
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
 def GetSearchList(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,search_key,page_int,stype):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnNS=[]
  QpLJXxhfDcPvOrwdzyAqsUCKbmFneR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/search/getSearch.jsp'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH={'kwd':search_key,'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(page_int),'pageSize':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.SCREENCODE,'os':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.OSCODE,'network':QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.SEARCH_LIMIT)if stype=='vod' else '','vodMVReqCnt':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.SEARCH_LIMIT)if stype=='movie' else '','smrclipReqCnt':'0','pickClipReqCnt':'0','aloneReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','_':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetNoCache(2))}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.SEARCH_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY=json.loads(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   if stype=='vod':
    if not('programRsb' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY):return QpLJXxhfDcPvOrwdzyAqsUCKbmFnNS,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['programRsb']['dataList']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNH =QpLJXxhfDcPvOrwdzyAqsUCKbmFnoH(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['programRsb']['count'])
    for QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW in QpLJXxhfDcPvOrwdzyAqsUCKbmFnNB:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['mast_cd']
     QpLJXxhfDcPvOrwdzyAqsUCKbmFneM =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['mast_nm']
     QpLJXxhfDcPvOrwdzyAqsUCKbmFneW=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['web_url4']
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['web_url']
     try:
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk =[]
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe=[]
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN =[]
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnNT =0
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTu =''
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo =''
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnNa =''
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('actor') !='' and QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('actor') !='-':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('actor').split(',')
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('director')!='' and QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('director')!='-':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('director').split(',')
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('cate_nm')!='' and QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('cate_nm')!='-':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('cate_nm').split('/')
      if 'targetage' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW:QpLJXxhfDcPvOrwdzyAqsUCKbmFnTu=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('targetage')
      if 'broad_dt' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW:
       QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('broad_dt')
       QpLJXxhfDcPvOrwdzyAqsUCKbmFnNa='%s-%s-%s'%(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[:4],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[4:6],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[6:])
       QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo =QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[:4]
     except:
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH={'program':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTg,'title':QpLJXxhfDcPvOrwdzyAqsUCKbmFneM,'thumbnail':{'poster':QpLJXxhfDcPvOrwdzyAqsUCKbmFneW,'thumb':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej,'fanart':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej},'synopsis':'','cast':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk,'director':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe,'info_genre':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN,'duration':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNT,'mpaa':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTu,'year':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo,'aired':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNa}
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnNS.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH)
   else:
    if not('vodMVRsb' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY):return QpLJXxhfDcPvOrwdzyAqsUCKbmFnNS,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['vodMVRsb']['dataList']
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNH =QpLJXxhfDcPvOrwdzyAqsUCKbmFnoH(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['vodMVRsb']['count'])
    for QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW in QpLJXxhfDcPvOrwdzyAqsUCKbmFnNg:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['mast_cd']
     QpLJXxhfDcPvOrwdzyAqsUCKbmFneM =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['mast_nm'].strip()
     QpLJXxhfDcPvOrwdzyAqsUCKbmFneW =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['web_url']
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =QpLJXxhfDcPvOrwdzyAqsUCKbmFneW
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnet=''
     try:
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk =[]
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe=[]
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN =[]
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnNT =0
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTu =''
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo =''
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnNa =''
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('actor') !='' and QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('actor') !='-':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('actor').split(',')
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('director')!='' and QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('director')!='-':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('director').split(',')
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('cate_nm')!='' and QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('cate_nm')!='-':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN =QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('cate_nm').split('/')
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('runtime_sec')!='':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNT=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('runtime_sec')
      if 'grade_nm' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW:QpLJXxhfDcPvOrwdzyAqsUCKbmFnTu=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('grade_nm')
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('broad_dt')
      if data_str!='':
       QpLJXxhfDcPvOrwdzyAqsUCKbmFnNa='%s-%s-%s'%(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[:4],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[4:6],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[6:])
       QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo =QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[:4]
     except:
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH={'movie':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTg,'title':QpLJXxhfDcPvOrwdzyAqsUCKbmFneM,'thumbnail':{'poster':QpLJXxhfDcPvOrwdzyAqsUCKbmFneW,'thumb':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej,'fanart':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej,'clearlogo':QpLJXxhfDcPvOrwdzyAqsUCKbmFnet},'synopsis':'','cast':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTk,'director':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTe,'info_genre':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTN,'duration':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNT,'mpaa':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTu,'year':QpLJXxhfDcPvOrwdzyAqsUCKbmFnTo,'aired':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNa}
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnNo=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB
     for QpLJXxhfDcPvOrwdzyAqsUCKbmFnNu in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['bill']:
      if QpLJXxhfDcPvOrwdzyAqsUCKbmFnNu in QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.MOVIE_LITE:
       QpLJXxhfDcPvOrwdzyAqsUCKbmFnNo=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoY
       break
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnNo==QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB: 
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH['title']=QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH['title']+' [개별구매]'
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnNS.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH)
   if QpLJXxhfDcPvOrwdzyAqsUCKbmFnNH>(page_int*QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.SEARCH_LIMIT):QpLJXxhfDcPvOrwdzyAqsUCKbmFneR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoY
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnNS,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
 def GetDeviceList(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,QpLJXxhfDcPvOrwdzyAqsUCKbmFnka,QpLJXxhfDcPvOrwdzyAqsUCKbmFnke):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnei=[]
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnkR='-'
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/v1/user/device/list'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnNY=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.API_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnai=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.makeDefaultCookies(vToken=QpLJXxhfDcPvOrwdzyAqsUCKbmFnka,vUserinfo=QpLJXxhfDcPvOrwdzyAqsUCKbmFnke)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnNY,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnai)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY=json.loads(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnei=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']
   for QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW in QpLJXxhfDcPvOrwdzyAqsUCKbmFnei:
    if QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['model']=='PC':
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnkR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW['uuid']
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnkR
 def GetProfileToken(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,QpLJXxhfDcPvOrwdzyAqsUCKbmFnka,QpLJXxhfDcPvOrwdzyAqsUCKbmFnke,user_pf):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnNM=[]
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnNV =''
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnNj =''
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnNW='Y'
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnNt ='N'
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/profile/select.do'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnNY=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.URL_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnai=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.makeDefaultCookies(vToken=QpLJXxhfDcPvOrwdzyAqsUCKbmFnka,vUserinfo=QpLJXxhfDcPvOrwdzyAqsUCKbmFnke)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnNY,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnai)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnNM =re.findall('data-profile-no="\d+"',QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   for i in QpLJXxhfDcPvOrwdzyAqsUCKbmFnog(QpLJXxhfDcPvOrwdzyAqsUCKbmFnot(QpLJXxhfDcPvOrwdzyAqsUCKbmFnNM)):
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNG =QpLJXxhfDcPvOrwdzyAqsUCKbmFnNM[i].replace('data-profile-no=','').replace('"','')
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNM[i]=QpLJXxhfDcPvOrwdzyAqsUCKbmFnNG
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnNV=QpLJXxhfDcPvOrwdzyAqsUCKbmFnNM[user_pf]
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
   return QpLJXxhfDcPvOrwdzyAqsUCKbmFnNj,QpLJXxhfDcPvOrwdzyAqsUCKbmFnNW,QpLJXxhfDcPvOrwdzyAqsUCKbmFnNt
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/profile/api/select.do'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnNY=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.URL_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnai=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.makeDefaultCookies(vToken=QpLJXxhfDcPvOrwdzyAqsUCKbmFnka,vUserinfo=QpLJXxhfDcPvOrwdzyAqsUCKbmFnke)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaG={'profileNo':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNV}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Post',QpLJXxhfDcPvOrwdzyAqsUCKbmFnNY,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaG,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnai)
   for QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI in QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.cookies:
    if QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.name=='_tving_token':
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnNj=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.value
    elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.name==QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GLOBAL_COOKIENM['tv_cookiekey']:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnNW=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.value
    elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.name==QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GLOBAL_COOKIENM['tv_lockkey']:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnNt=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.value
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnNj,QpLJXxhfDcPvOrwdzyAqsUCKbmFnNW,QpLJXxhfDcPvOrwdzyAqsUCKbmFnNt
 def GetProfileLockYN(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,QpLJXxhfDcPvOrwdzyAqsUCKbmFnka,QpLJXxhfDcPvOrwdzyAqsUCKbmFnke):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnNM=[]
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnNt ='N'
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/profile/select.do'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnNY=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.URL_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnai=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.makeDefaultCookies(vToken=QpLJXxhfDcPvOrwdzyAqsUCKbmFnka,vUserinfo=QpLJXxhfDcPvOrwdzyAqsUCKbmFnke)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnNY,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnai)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnNM =re.findall('data-profile-no="\d+"',QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   for i in QpLJXxhfDcPvOrwdzyAqsUCKbmFnog(QpLJXxhfDcPvOrwdzyAqsUCKbmFnot(QpLJXxhfDcPvOrwdzyAqsUCKbmFnNM)):
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNG =QpLJXxhfDcPvOrwdzyAqsUCKbmFnNM[i].replace('data-profile-no=','').replace('"','')
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnNM[i]=QpLJXxhfDcPvOrwdzyAqsUCKbmFnNG
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
   return QpLJXxhfDcPvOrwdzyAqsUCKbmFnNt
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/profile/api/select.do'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnNY=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.URL_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnai=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.makeDefaultCookies(vToken=QpLJXxhfDcPvOrwdzyAqsUCKbmFnka,vUserinfo=QpLJXxhfDcPvOrwdzyAqsUCKbmFnke)
   for i in QpLJXxhfDcPvOrwdzyAqsUCKbmFnog(QpLJXxhfDcPvOrwdzyAqsUCKbmFnot(QpLJXxhfDcPvOrwdzyAqsUCKbmFnNM)):
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnaG={'profileNo':QpLJXxhfDcPvOrwdzyAqsUCKbmFnNM[i]}
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Post',QpLJXxhfDcPvOrwdzyAqsUCKbmFnNY,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaG,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnai)
    for QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI in QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.cookies:
     if QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.name=='_tving_token':
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnNE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.value
     elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.name==QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GLOBAL_COOKIENM['tv_lockkey']:
      QpLJXxhfDcPvOrwdzyAqsUCKbmFnNI=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaI.value
    if QpLJXxhfDcPvOrwdzyAqsUCKbmFnNE==QpLJXxhfDcPvOrwdzyAqsUCKbmFnka:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnNt=QpLJXxhfDcPvOrwdzyAqsUCKbmFnNI
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(QpLJXxhfDcPvOrwdzyAqsUCKbmFnka)
     break
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnNt
 def GetBookmarkInfo(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN,videoid,vidtype):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.API_DOMAIN+'/v2/media/program/'+videoid
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetDefaultParams()
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH={'pageNo':'1','pageSize':'10','order':'name',}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB.update(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnok=json.loads(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   if not('body' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnok):return{}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe=QpLJXxhfDcPvOrwdzyAqsUCKbmFnok['body']
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneM=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('name').get('ko').strip()
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['title'] =QpLJXxhfDcPvOrwdzyAqsUCKbmFneM
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['title']=QpLJXxhfDcPvOrwdzyAqsUCKbmFneM
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['mpaa'] =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaT.get(QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('grade_code'))
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['plot'] =QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('synopsis').get('ko')
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['year'] =QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('product_year')
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['cast'] =QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('actor')
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['director']=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('director')
   if QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('category1_name').get('ko')!='':
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['genre'].append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('category1_name').get('ko'))
   if QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('category2_name').get('ko')!='':
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['genre'].append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('category2_name').get('ko'))
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('broad_dt'))
   if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS!='0':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[:4],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[4:6],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[6:])
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneW =''
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =''
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnet=''
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneG =''
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneE =''
   for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa in QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('image'):
    if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('code')=='CAIP0900':QpLJXxhfDcPvOrwdzyAqsUCKbmFneW =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('url')
    elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('code')=='CAIP0200':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('url')
    elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('code')=='CAIP1800':QpLJXxhfDcPvOrwdzyAqsUCKbmFnet=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('url')
    elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('code')=='CAIP2000':QpLJXxhfDcPvOrwdzyAqsUCKbmFneG =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('url')
    elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('code')=='CAIP1900':QpLJXxhfDcPvOrwdzyAqsUCKbmFneE =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('url')
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['thumbnail']['poster']=QpLJXxhfDcPvOrwdzyAqsUCKbmFneW
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['thumbnail']['thumb']=QpLJXxhfDcPvOrwdzyAqsUCKbmFnej
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['thumbnail']['clearlogo']=QpLJXxhfDcPvOrwdzyAqsUCKbmFnet
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['thumbnail']['icon']=QpLJXxhfDcPvOrwdzyAqsUCKbmFneG
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['thumbnail']['banner']=QpLJXxhfDcPvOrwdzyAqsUCKbmFneE
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['thumbnail']['fanart']=QpLJXxhfDcPvOrwdzyAqsUCKbmFnej
  else:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.API_DOMAIN+'/v2a/media/stream/info'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetDefaultParams()
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH={'info':'Y','mediaCode':videoid,'noCache':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetNoCache(1)),'callingFrom':'HTML5','adReq':'adproxy','ooc':'','deviceId':'','uuid':'','deviceInfo':'PC','wm':'Y',}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB.update(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnok=json.loads(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   if not('content' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnok['body']):return{}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe=QpLJXxhfDcPvOrwdzyAqsUCKbmFnok['body']['content']['info']['movie']
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneM =QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('name').get('ko').strip()
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['title']=QpLJXxhfDcPvOrwdzyAqsUCKbmFneM
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneM +=u' (%s)'%(QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('product_year'))
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['title'] =QpLJXxhfDcPvOrwdzyAqsUCKbmFneM
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['mpaa'] =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaT.get(QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('grade_code'))
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['plot'] =QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('story').get('ko')
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['year'] =QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('product_year')
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['studio'] =QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('production')
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['duration']=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('duration')
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['cast'] =QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('actor')
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['director']=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('director')
   if QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('category1_name').get('ko')!='':
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['genre'].append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('category1_name').get('ko'))
   if QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('category2_name').get('ko')!='':
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['genre'].append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('category2_name').get('ko'))
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('release_date'))
   if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS!='0':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[:4],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[4:6],QpLJXxhfDcPvOrwdzyAqsUCKbmFnTS[6:])
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneW=''
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =''
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnet=''
   for QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa in QpLJXxhfDcPvOrwdzyAqsUCKbmFnoe.get('image'):
    if QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('code')=='CAIM2100':QpLJXxhfDcPvOrwdzyAqsUCKbmFneW =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('url')
    elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('code')=='CAIM0400':QpLJXxhfDcPvOrwdzyAqsUCKbmFnej =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('url')
    elif QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('code')=='CAIM1800':QpLJXxhfDcPvOrwdzyAqsUCKbmFnet=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.IMG_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnTa.get('url')
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['thumbnail']['poster']=QpLJXxhfDcPvOrwdzyAqsUCKbmFneW
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['thumbnail']['thumb']=QpLJXxhfDcPvOrwdzyAqsUCKbmFneW 
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['thumbnail']['clearlogo']=QpLJXxhfDcPvOrwdzyAqsUCKbmFnet
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa['saveinfo']['thumbnail']['fanart']=QpLJXxhfDcPvOrwdzyAqsUCKbmFnej
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnoa
 def GetEuroChannelList(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN):
  QpLJXxhfDcPvOrwdzyAqsUCKbmFnei=[]
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS ='/v2/operator/highlights'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetDefaultParams()
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':QpLJXxhfDcPvOrwdzyAqsUCKbmFnoj(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.GetNoCache(2))}
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB.update(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkH)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.API_DOMAIN+QpLJXxhfDcPvOrwdzyAqsUCKbmFnkS
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkB,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY=json.loads(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   if not('result' in QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']):return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei,QpLJXxhfDcPvOrwdzyAqsUCKbmFneR
   QpLJXxhfDcPvOrwdzyAqsUCKbmFneB=QpLJXxhfDcPvOrwdzyAqsUCKbmFnkY['body']['result']
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoT =QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.Get_Now_Datetime()
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoN=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoT+datetime.timedelta(days=-1)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoN=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoH(QpLJXxhfDcPvOrwdzyAqsUCKbmFnoN.strftime('%Y%m%d'))
   for QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW in QpLJXxhfDcPvOrwdzyAqsUCKbmFneB:
    QpLJXxhfDcPvOrwdzyAqsUCKbmFnou=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoH(QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('content').get('banner_title2')[:8])
    if QpLJXxhfDcPvOrwdzyAqsUCKbmFnoN<=QpLJXxhfDcPvOrwdzyAqsUCKbmFnou:
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH={'channel':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('content').get('banner_sub_title3'),'title':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('content').get('banner_title'),'subtitle':QpLJXxhfDcPvOrwdzyAqsUCKbmFnkW.get('content').get('banner_sub_title2'),}
     QpLJXxhfDcPvOrwdzyAqsUCKbmFnei.append(QpLJXxhfDcPvOrwdzyAqsUCKbmFnTH)
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnei
 def Get_Naver_Login(QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN):
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg='https://user.tving.com/oauth/oauthLogin.tving?target=naver&from=pc&rtUrl=https://user.tving.com/pc/user/login.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fmain.do%3FretRef%3DY%26source%3Dhttps%3A%2F%2Fwww.google.com%2F&csite=&isAuto=false'
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE=QpLJXxhfDcPvOrwdzyAqsUCKbmFnaN.callRequestCookies('Get',QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg,payload=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,params=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,headers=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS,cookies=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoS)
   if QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.status_code!=200:return QpLJXxhfDcPvOrwdzyAqsUCKbmFnoB
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoi=re.findall('\'https://nid.naver.com/(?:[a-zA-Z]|[0-9]|[$\-@\.&+:/?=_]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+\'',QpLJXxhfDcPvOrwdzyAqsUCKbmFnaE.text)
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoR=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoi[0].replace('\'','')
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(QpLJXxhfDcPvOrwdzyAqsUCKbmFnoR)
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV('n login pass1 error')
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  try:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnkg=QpLJXxhfDcPvOrwdzyAqsUCKbmFnoR
  except QpLJXxhfDcPvOrwdzyAqsUCKbmFnoM as exception:
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV('n login pass1 error')
   QpLJXxhfDcPvOrwdzyAqsUCKbmFnoV(exception)
  return QpLJXxhfDcPvOrwdzyAqsUCKbmFnoY
# Created by pyminifier (https://github.com/liftoff/pyminifier)
