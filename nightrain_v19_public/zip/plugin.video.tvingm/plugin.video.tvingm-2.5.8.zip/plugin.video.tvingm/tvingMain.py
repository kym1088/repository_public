__author__="NightRain"
YLEbdUyHiIePJMCmqNSDWruhvBARsQ=int
import os
import sys
import xbmcaddon,xbmcvfs
import urllib
__cwd__=xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
__lib__=os.path.join(__cwd__,'resources','lib')
sys.path.append(__lib__)
YLEbdUyHiIePJMCmqNSDWruhvBARsj =os.path.join(__cwd__,'packages')
sys.path.append(YLEbdUyHiIePJMCmqNSDWruhvBARsj)
from tvingRun import*
def get_params():
 p=urllib.parse.parse_qs(sys.argv[2][1:])
 for i in p.keys():
  p[i]=p[i][0]
 return p
YLEbdUyHiIePJMCmqNSDWruhvBARsG=nOCvrwJihTtRPylKbxYVgHAcmWSaGN(sys.argv[0],YLEbdUyHiIePJMCmqNSDWruhvBARsQ(sys.argv[1]),get_params()) 
YLEbdUyHiIePJMCmqNSDWruhvBARsG.tving_main()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
