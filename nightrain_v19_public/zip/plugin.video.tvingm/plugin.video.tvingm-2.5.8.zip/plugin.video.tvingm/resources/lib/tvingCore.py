__author__="NightRain"
qxdaJLSMjgcHOBKyzRlYXUusEeCvND=print
qxdaJLSMjgcHOBKyzRlYXUusEeCvNw=ImportError
qxdaJLSMjgcHOBKyzRlYXUusEeCvNr=object
qxdaJLSMjgcHOBKyzRlYXUusEeCvNA=None
qxdaJLSMjgcHOBKyzRlYXUusEeCvNG=False
qxdaJLSMjgcHOBKyzRlYXUusEeCvNW=open
qxdaJLSMjgcHOBKyzRlYXUusEeCvNn=True
qxdaJLSMjgcHOBKyzRlYXUusEeCvNF=int
qxdaJLSMjgcHOBKyzRlYXUusEeCvQb=range
qxdaJLSMjgcHOBKyzRlYXUusEeCvQt=Exception
qxdaJLSMjgcHOBKyzRlYXUusEeCvQk=len
qxdaJLSMjgcHOBKyzRlYXUusEeCvQV=str
qxdaJLSMjgcHOBKyzRlYXUusEeCvQP=dict
qxdaJLSMjgcHOBKyzRlYXUusEeCvQo=list
qxdaJLSMjgcHOBKyzRlYXUusEeCvQN=bytes
qxdaJLSMjgcHOBKyzRlYXUusEeCvQT=ord
import urllib
import re
import json
import sys
import time
import requests
import datetime
import random
import base64
import os
import xml.etree.ElementTree as ET
import xml.dom.minidom
import io
try:
 from Cryptodome.Cipher import PKCS1_OAEP,AES
 from Cryptodome.Util import Padding
 qxdaJLSMjgcHOBKyzRlYXUusEeCvND('Cryptodome')
except qxdaJLSMjgcHOBKyzRlYXUusEeCvNw:
 from Crypto.Cipher import PKCS1_OAEP,AES
 from Crypto.Util import Padding
 qxdaJLSMjgcHOBKyzRlYXUusEeCvND('Crypto')
qxdaJLSMjgcHOBKyzRlYXUusEeCvbk={'stream50':1080,'stream40':720,'stream30':480,'stream25':360}
qxdaJLSMjgcHOBKyzRlYXUusEeCvbV ={'CMMG0100':'전체 관람가','CMMG0200':'12세 관람가','CMMG0300':'15세 관람가','CMMG0400':'청소년 관람불가','CPTG0100':'전체','CPTG0300':'12세 이하','CPTG0400':'15세 이하','CPTG0500':'19세 이하'}
qxdaJLSMjgcHOBKyzRlYXUusEeCvbP =re.compile(r'''((?:[^,"']|"[^"]*"|'[^']*')+)''')
qxdaJLSMjgcHOBKyzRlYXUusEeCvbo=['TP2wgas1K9Q8F7B359108383','TPLYFLt9NxVcJjQhn7Ee0069','_tutB3583','cs','TSID','accessToken','refreshToken','_tving_token','authToken','GA360_USERTYPE_JSON','ADULT_CONFIRM_YN','LEGAL_CONFIRM_YN','TLPUDB35Qhn7',]
class qxdaJLSMjgcHOBKyzRlYXUusEeCvbt(qxdaJLSMjgcHOBKyzRlYXUusEeCvNr):
 def __init__(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.APIKEY ='1e7952d0917d6aab1f0293a063697610'
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.NETWORKCODE ='CSND0900'
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.OSCODE ='CSOD0900' 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TELECODE ='CSCD0900'
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.SCREENCODE ='CSSD0100'
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.APIKEY_ATV ='f0f74595d2f123ffc362362e334aeb52' 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.SCREENCODE_ATV ='CSSD1300' 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.LIVE_LIMIT =20 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.VOD_LIMIT =24 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.EPISODE_LIMIT =30 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.SEARCH_LIMIT =30 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.MOVIE_LIMIT =24 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN ='https://api.tving.com'
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN ='https://image.tving.com'
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.SEARCH_DOMAIN ='https://search-api.tving.com'
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.LOGIN_DOMAIN ='https://user.tving.com'
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.URL_DOMAIN ='https://www.tving.com'
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.MOVIE_LITE =['2610061','2610161','261062']
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.USER_AGENT ='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.DEFAULT_HEADER ={'user-agent':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.USER_AGENT}
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.COOKIE_FILE_NAME =''
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV_SESSION_COOKIES1=''
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV_SESSION_COOKIES2=''
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV_STREAM_FILENAME =''
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV_SESSION_TEXT1 =''
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV_SESSION_TEXT2 =''
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.KodiVersion=20
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV ={}
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.Init_TV_Total()
 def Init_TV_Total(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV={'account':{},'cookies':{},}
 def callRequestCookies(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,jobtype,qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,redirects=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.DEFAULT_HEADER
  if headers:qxdaJLSMjgcHOBKyzRlYXUusEeCvbQ.update(headers)
  if jobtype=='Get':
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbT=requests.get(qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,params=params,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvbQ,cookies=cookies,allow_redirects=redirects)
  else:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbT=requests.post(qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,data=payload,params=params,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvbQ,cookies=cookies,allow_redirects=redirects)
  qxdaJLSMjgcHOBKyzRlYXUusEeCvND(qxdaJLSMjgcHOBKyzRlYXUusEeCvbT.url)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvbT
 def JsonFile_Save(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,filename,qxdaJLSMjgcHOBKyzRlYXUusEeCvbh):
  if filename=='':return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  try:
   fp=qxdaJLSMjgcHOBKyzRlYXUusEeCvNW(filename,'w',-1,'utf-8')
   json.dump(qxdaJLSMjgcHOBKyzRlYXUusEeCvbh,fp,indent=4,ensure_ascii=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG)
   fp.close()
  except:
   return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
 def JsonFile_Load(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,filename):
  if filename=='':return{}
  try:
   fp=qxdaJLSMjgcHOBKyzRlYXUusEeCvNW(filename,'r',-1,'utf-8')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbI=json.load(fp)
   fp.close()
  except:
   return{}
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvbI
 def TextFile_Save(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,filename,resText):
  if filename=='':return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  try:
   fp=qxdaJLSMjgcHOBKyzRlYXUusEeCvNW(filename,'w',-1,'utf-8')
   fp.write(resText)
   fp.close()
  except:
   return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
 def Save_session_acount(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,qxdaJLSMjgcHOBKyzRlYXUusEeCvbm,qxdaJLSMjgcHOBKyzRlYXUusEeCvbp,qxdaJLSMjgcHOBKyzRlYXUusEeCvbi,qxdaJLSMjgcHOBKyzRlYXUusEeCvbD):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['account']['tvid'] =base64.standard_b64encode(qxdaJLSMjgcHOBKyzRlYXUusEeCvbm.encode()).decode('utf-8')
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['account']['tvpw'] =base64.standard_b64encode(qxdaJLSMjgcHOBKyzRlYXUusEeCvbp.encode()).decode('utf-8')
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['account']['tvtype']=qxdaJLSMjgcHOBKyzRlYXUusEeCvbi 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['account']['tvpf'] =qxdaJLSMjgcHOBKyzRlYXUusEeCvbD 
 def Load_session_acount(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN):
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbm =base64.standard_b64decode(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['account']['tvid']).decode('utf-8')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbp =base64.standard_b64decode(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['account']['tvpw']).decode('utf-8')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbi=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['account']['tvtype']
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbD =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['account']['tvpf'] 
  except:
   return '','','0',0
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvbm,qxdaJLSMjgcHOBKyzRlYXUusEeCvbp,qxdaJLSMjgcHOBKyzRlYXUusEeCvbi,qxdaJLSMjgcHOBKyzRlYXUusEeCvbD
 def makeDefaultCookies(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbw={}
  for qxdaJLSMjgcHOBKyzRlYXUusEeCvbr,qxdaJLSMjgcHOBKyzRlYXUusEeCvtF in qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies'].items():
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbw[qxdaJLSMjgcHOBKyzRlYXUusEeCvbr]=qxdaJLSMjgcHOBKyzRlYXUusEeCvtF
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvbw
 def getDeviceStr(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbA=[]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbA.append('Windows') 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbA.append('Chrome') 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbA.append('ko-KR') 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbA.append('undefined') 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbA.append('24') 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbA.append(u'한국 표준시')
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbA.append('undefined') 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbA.append('undefined') 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbA.append('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAATtklEQVR4Xu2be1hVdbrHvwvEDYKICuItMxUDFXVQQZuevIRp5uNRvIXXYcwNdp7H0eZkk9qZTlqaXbxMKWxSRxvTGkJOUz7HS+atFCVT8ZIpZAgqoiYgyBZhnee39l6bxWaLGBj+pi9/iXtd3vV53/XZ7+9dCwX8IQESIAFJCCiSxMkw65CAaoZah4eT5lCKBax3abLlOlAmUPIE/pLwKaxfQo37PAgEKKwHIQu/cgwU1q8MnKerMwIUVp2hlOdAFJY8uWKklQlUFdbk9d7wLPkEijrMsOmfYIldof3+XGIg3Mp3QVVmIdG8FdMtq7T/TzTPqBVc/bzACu24zj/mhJlQlRDHeVzFqSrxtY6jVhchx86/hrBy4YsoxGElPkIPZN8RzFZ0xVDM1D73xw3swNJqt68NYc6wakPvwdi3srBi43tAVXYAWOBCULs0GTgLq66u416EVSGrrY44K/YHSjzH4cMpRXUV2r/bce63sISsBuDPuAKfagV0FG0xHmZ8DIsmKSGvWRiHXXgHgSioc+wUVp0j/dUPWCEsJwlMO4Fm7iV4Q1HRpsTq7Xv1SrswT9ONhKSk/35LdFhBnVLfHDRwzVMHDoxpfvTYU5lms7lQRG9JTBBfp8vtV3IFihqJhLijdtElA9gCYKH98+9R7jYAVtMNvaszmYowdMj737QMzFia0AdJDiL2Dis21nwmvzAgdNPGhf2gqOOnzYw77xynj++VpE0D82Kq0HTuyowdmZB1udtL2j6KGg39M9FBKmqc/VhLAIxwdJc1Sdd0yxAAIx2dX+Xj2a7/g+m5qK6ztX1JuGYn9nXV5Ro70oovIn9XncwMTEQ8ntCuJhiXHMIQAklBT6zChppcqbaNfqxoHMJhtEOi70pkhl3CY6eBoIuVDyO2FT/i+Ic7APuC3PAt2qFj+TVEHy+osn2Ng7jDhhRWbQnW//4VwrIV9cdCArGxcU3UMvxJUfB1Qm+8qxXiIXQoBxaWWBtdW7d+6ZPOwtJuSNtNMsTR4YibVVGXaTel+LEtJTO1z8WPWHoCWdq+9hs2IPDHtaNGLYpUyrHjTsIqKWnUQcTg7f3z/omT/nJLUfGDHqcuWnH4Mk/MXd0V17RzVXRglc7nOL+r7lJcj7gHdanoslGVoS6XrcZ82vZd7hCf+MyZj+P3shh4uq91xKJvC7yiCb/M/VK17IycjfITy2u38kta16wqk7SYJ6/3HuZ16IY4xSewYDV+r3U24t/esGIFBlX6XV+yGUVWXdn+HY9hLL7FWQTgD75jMKm3BT7uxRh0vLKwimDCOJgxBCfwdKud2BMCPHEKePfiRKBDFnq334sRaUBAHTZaFFb9C6e2EVQIy170oaHbRvV77NNZRgnoJ4k9jCdKraZZ27bH9vLyvPFXY4c1deqssh9/DBu5Z9+kZ0RHFZuGFwAMzMt7ONTdvfR66W2vV1NS5izSRDdoTX9VwZn8n1tOKLnpHRDQ4tzuq3ntX9u6Pfbd4cPfLW3a9FK5/Zxf6SKy3+whosNSVbS0fBC/oU3r07uDH93X5OSp/rh4McjRzYk4UY44uCE+IQx7tGMZbupps6eXiq7MWuIdIjpHrSPbtGCZEPbAgWuWBAWl9igr8/C4crndaHeP0t3JQ7PGmQ9hifWWd0Te5fZ9GzYsSgpscU6wS64k1cpdUsXcD8D4bYHPZV8MfvPrfRMnCHGI4ykKQrTYVBS6AfNX9UGmLlw9tub+WYfLyzy+/PAfb0bfiV3m2fC3d+7+w7qoqNfT/ZtnnRNsoCorUe4WFRs3faLGqw/mCC7ii6hxln9UHnwQXp6FwuM9sffi7zVhbY2w4qKfjbxnKRzCEN3PwYDGeCX1Ve2zmsyZ4iMa40u/1hhQmANPzxuajIwdli6smdiJoogT2nGjUoVhB+GUqRkeD09CSA4QllnbEq/Yn8KqO5b1daQqwho5csnLgS0yxlW62Y3R2WdYzh3WsxPmef50rvv4/fvHeXUP3YEmfrk4eHAkrFZvREQkr+0asssvOWVe9wD/cwuF6FQ3FHy86bVzpbc8B0VHzzuvAgVrVr/fuSYdln4D6l1f3tV2DZKT54213fzKFpczLHs3M6D/6tjOIanzUY4CS0LiO14++Z9FjVyYVaZ63BDLTE1YnVKfuXnT7+iH/3hTdIjPx06PexIqep/5od8yXQwB/lleULHOIaw7zOB0cecXBlzRl7HieKqCznoHKLYRv0PFW+fPd/vs2rXWXVJTR4uruTImauE6X7/Lwdu2xYbqXxLO7NzdS69aLJbGPbpv69C3b9LVz7fMOpuT3SVg2izzPG25XI4duXkdb1utXutPn36scWZmLww3pWFM+BqUwh3LD74At84ZCPTLxoKDPyHCegE7QoFcP2DkQcDbCm3Jtj8IQKkHktJisKxgS7XD8Y9CmmJRZhyWNPsAF0Ly7iisONN2FIR/j8DrQGS6XVhohcERtmWokFhd/VBYdUWy/o5TZUn4zLDlH7RtczJM/8avElo1wjqf1W1EUVHTKRHhyWPghrWO7gbA1H2N3ktPjxxbWOj/khCW1p0kJrQWS8g/xszcq7iVBW3c+PpD3o1/ttxtSagLS8Smdw2Kgoa3b3uYLlx8tO+1q61fS31u29uVYrcLa8rk/9ro5VUwTLu+hMQiMRsaOHDN6rZtTo39aldM16CgA692DkqNzL3c8ZOUlDkvPtTu2MtPP/3+BG2JmpC4VyzNIsI/Xd2jx7Z+CrDRVYdl8rwxTJvDtcwQy1Fbl2hfcvfsufXPEX2SxfCmcndWsdy0CbdRcSe943uk/ZHhxq7WmV0DU0n7zZtf3lF6y2vxyBGLTx5MG9Xm5In+c2NnmG/esno+v3nz3N7Xrwd2BKB1fcvNg1Sx1PvP0FX42e+2JqXdnRvgI79gJB38Ix6xFlYZfIsBeSRmw79VBmK6rUUT3KyyzDPy1gfqS1v9rVphRZqOoEX4Xkc3pc+1RoduQEEjCqv+1PBgnrnK0D2i76e5Pbtv9awkLOOTQVU54mroLpaEZzP6RN8uNS3SbmYFDY2XLGTy3XdP96ipsFK/GfPI0fTBXzieAhqG7tnZIcO++GK21bmTmrLHd1J+fsA7nl5FeU2aXtpXaYZlXxJOnvTSRi/v6621z1bEPySkICTSretO867dU3+nC6uwoNm6jzYunhkUdOCfYgmrCTghPl/Mg4I6pb7okK7xwQAAfUl39MiQhqmpUTGOGZadoZBdz57bwip1sPpQXVGf1x5QAHj2q4C1Nwr8x4globv77UJjh+VKWPu/Gb0sPf2pzUOHvpdXXNSkw57dU3uJ5WDelXZ9kz+d762zEl2pT0ZgRq6HF3ohC82LyzVhFZuAz3oD+R4N8HV5Z0QdL8bEi+e0eZZ47cB5hpXnC2wJg8thuoj/bsIS22hyMlkdy79HM21zLbFMdA89QWE9mM6o16iqvNYg5kJ9I5Iy/Fucn611SBWysg3LTVafOz0lzMkJCTt6bHDQU4MTvvUwWZclrEw87Xhny0l0d+uwtBv+wOjASgN6Rd0aa45toA/doSq2Vy30H7uUBvX/+9SgzvtnVepi7Eu2xx/f6Nel21fpP5yKWLhr97QEMeieYTa/VVjst9QoLE0o8Qk9/fxyZ44a9UZaQ1PJyoRVlmjxxDCoU2rMnYQlQjE+Yb2QE3zhX5+/UK4/lGj/8JHoyEjLeXePsvcSVlm8tIcSZe5j4V72T/H00Ww2P1lW5tEzMzOsz/4D48v69ft4Tk06LE3Ayyyvd+iYFhcSvO9CI5/8MU2b5kw9e7rvlZ27YkbrTIqKm3Y4diwyom16S63D2usXiOMHh2GTdb02dP+XKRiJ4T4Y0OgIiku9kZM2AKsK/teB+EwrYGc326/Og/R76bB0qU0yTcb08BXocr0IZekVrzV8HWGbtnNJWK9+eOBOXuXF0dC/jQ72b569/+rVdn7H0iP1gLWlhPh2tpaa3t73TXS4Wu4239VrDSmb57YJ7b5jwo/nekLMSqA/UXNaSrrqEsRMq6TEZ9GgQWtOBjTPWrT+w7ejI/omDbtZ3ATHjg3WXgrV5j1iiLxi/f9E9N9wqKHpZog+K9PnV9P+MsUkZjcZZ8IDv/zyuYaOTmzyeu8uvbbuadXyTNihtBEoyG9hO+ZhPFF8w/dl45JQ74C8Zy9eExa2JSYnJ1hcj3it4XGxhBRzripLQhfp1WdYqopTYvDdYu7cDQY+Fa99TLcM8W1y+f/Cwr7AmTN983OyQ8YLmXXrunN7eHhK27stCe3C6iOOIb4wmvmfT1ZUBLmpWLDKYnlRiKxNm+/xbdrw7etvbhoch4l4J3QBVL9CbRn4ubW3Fr3+8mZr32yt4/rdOdvgW59hGYfx1VWzqw4r82LV96xEB/fXiDbaoTJSh2gD/U6mbKSEg0P3B04X9R+Qyz/NMcyFqrzWIAa+4uZoWAw/8ZqD3sWIp17icrSnUeIJoYre+rJSH46Lbd2Aw8b9xD760FkcV/yuD4rFfMjlZ/bXGPTjqkC2OK+OM/YQxogv58u5Hd/Y/Nmc/8BNr2X6i6SO1x7E0L0P5jj/7uoJo3499qH70mej5//QpHGef6Wh+11yKWJSgXCdT6Whuz1eBbCogFlnarg+k+KO5W5lyK6Onf4Kh/4EUlWQ4xjs288hcrIyERm6gPyKbYP1/Z2rDtm/a297UnjeHzgX8Mu6HdGR6a8sOL+HpSNz3kbEpp+brzXUvyQepAju+LeEDskoaGwI2PGagVFCQixGYYntKz22F/9hf6LmvJ+zsMRNZ+xKyhphsf5iqHYYe6eix2Rcfun/57hRl1n6QFEfFctIoyCc9zEeUxeWPsOCompv04vryc9vOUy8htE84Pwajwa3Wjo/WLiXxBr5qCpuCSGJJbgmWwVT7dd6S3RxQr5QkOamIqUmwjIco+K1EENOQn/CcCGqDrnAsYdtS7vW16B1Ndcb2a6iQXn1S76aXqsrYbkSkuMpZB2e2zlGPiWsadYe3O1+E3/8bBdUXJkn4h0vktYkJ05viOtLzhkzpwSWK3ilNsKqyenv1zb3+09z7lfctT0uhVVbgvW//29CWPaOo53jJdR74G7oxhxv0xuXqfckwHs47/3clMK6n3R57PtJ4DchrNoCNL7rpS3VDLOh2h67PvansOqDOs9ZFwQorLqgKNkxKCzJEsZwHQQoLBYDCZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAQoLGlSxUBJgAQoLNYACZCANAT+H9FJng/hy/8wAAAAAElFTkSuQmCC')
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbG=''
  for qxdaJLSMjgcHOBKyzRlYXUusEeCvbW in qxdaJLSMjgcHOBKyzRlYXUusEeCvbA:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbG+=qxdaJLSMjgcHOBKyzRlYXUusEeCvbW+'|'
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvbG
 def GetDefaultParams(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,uhd=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG):
  if uhd==qxdaJLSMjgcHOBKyzRlYXUusEeCvNG:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbn={'apiKey':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.APIKEY,'networkCode':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.NETWORKCODE,'osCode':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.OSCODE,'teleCode':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TELECODE,'screenCode':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.SCREENCODE,}
  else:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbn={'apiKey':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.APIKEY_ATV,'networkCode':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.NETWORKCODE,'osCode':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.OSCODE,'teleCode':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TELECODE,'screenCode':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.SCREENCODE_ATV,}
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvbn
 def GetNoCache(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,timetype=1):
  if timetype==1:
   return qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(time.time())
  else:
   return qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(time.time()*1000)
 def GetUniqueid(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,hValue=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA):
  if hValue:
   import hashlib
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbF=hashlib.sha1()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbF.update(hValue.encode())
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtb=qxdaJLSMjgcHOBKyzRlYXUusEeCvbF.hexdigest()[:8]
  else:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtk=[0 for i in qxdaJLSMjgcHOBKyzRlYXUusEeCvQb(256)]
   for i in qxdaJLSMjgcHOBKyzRlYXUusEeCvQb(256):
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtk[i]='%02x'%(i)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtV=qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(4294967295*random.random())|0
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtb=qxdaJLSMjgcHOBKyzRlYXUusEeCvtk[255&qxdaJLSMjgcHOBKyzRlYXUusEeCvtV]+qxdaJLSMjgcHOBKyzRlYXUusEeCvtk[qxdaJLSMjgcHOBKyzRlYXUusEeCvtV>>8&255]+qxdaJLSMjgcHOBKyzRlYXUusEeCvtk[qxdaJLSMjgcHOBKyzRlYXUusEeCvtV>>16&255]+qxdaJLSMjgcHOBKyzRlYXUusEeCvtk[qxdaJLSMjgcHOBKyzRlYXUusEeCvtV>>24&255]
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvtb
 def GetCredential(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,user_id,user_pw,login_type,user_pf):
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtP=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvto={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'https://www.tving.com/onboarding','csite':'','rtUrl':'https%3A%2F%2Fwww.tving.com%2Fonboarding',}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Post',qxdaJLSMjgcHOBKyzRlYXUusEeCvtP,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvto,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ in qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.cookies:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies'][qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.name]=qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.value
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.Init_TV_Total()
   return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtT=[]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvth =''
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com%2Fonboarding'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbw=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.makeDefaultCookies()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvtf,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvbw)
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ in qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.cookies:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies'][qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.name]=qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.value
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtT =re.findall('data-profile-no="\d+"',qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   for i in qxdaJLSMjgcHOBKyzRlYXUusEeCvQb(qxdaJLSMjgcHOBKyzRlYXUusEeCvQk(qxdaJLSMjgcHOBKyzRlYXUusEeCvtT)):
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtI =qxdaJLSMjgcHOBKyzRlYXUusEeCvtT[i].replace('data-profile-no=','').replace('"','')
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtT[i]=qxdaJLSMjgcHOBKyzRlYXUusEeCvtI
   qxdaJLSMjgcHOBKyzRlYXUusEeCvth=qxdaJLSMjgcHOBKyzRlYXUusEeCvtT[user_pf]
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.Init_TV_Total()
   return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbw=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.makeDefaultCookies()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvto={'profileNo':qxdaJLSMjgcHOBKyzRlYXUusEeCvth}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Post',qxdaJLSMjgcHOBKyzRlYXUusEeCvtf,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvto,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvbw)
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ in qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.cookies:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies'][qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.name]=qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.value
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.Init_TV_Total()
   return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtm =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDeviceList()
  if qxdaJLSMjgcHOBKyzRlYXUusEeCvtm not in['','-']:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_uuid']=qxdaJLSMjgcHOBKyzRlYXUusEeCvtm+'-'+qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetUniqueid(qxdaJLSMjgcHOBKyzRlYXUusEeCvtm)
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.JsonFile_Save(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.COOKIE_FILE_NAME,qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
 def GetCredential_old(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,user_id,user_pw,login_type,user_pf):
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtP=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.LOGIN_DOMAIN+'/pc/user/doLogin.tving'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvto={'userId':user_id,'password':user_pw,'loginType':'10' if login_type=='0' else '20','autoLogin':'false','cjOneCookie':'','kaptcha':'','returnUrl':'http://www.tving.com','csite':'',}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Post',qxdaJLSMjgcHOBKyzRlYXUusEeCvtP,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvto,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ in qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.cookies:
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.name=='_tving_token':
     qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_token']=qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.value
    elif qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.name=='POC_USERINFO':
     qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_userinfo']=qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.value
    elif qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.name=='authToken':
     qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_authToken']=qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.value
   if not qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_token']:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.Init_TV_Total()
    return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_maintoken']=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_token']
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetProfileToken(user_pf)==qxdaJLSMjgcHOBKyzRlYXUusEeCvNG:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.Init_TV_Total()
    return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies'])
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtm =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDeviceList()
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvtm not in['','-']:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_uuid']=qxdaJLSMjgcHOBKyzRlYXUusEeCvtm+'-'+qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetUniqueid(qxdaJLSMjgcHOBKyzRlYXUusEeCvtm)
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.Init_TV_Total()
   return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
 def GetProfileToken(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,user_pf):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtT=[]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvth =''
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='https://user.tving.com/pc/user/profiles.tving?returnUrl=https%3A%2F%2Fwww.tving.com'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbw=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.makeDefaultCookies()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvtf,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvbw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtT =re.findall('data-profile-no="\d+"',qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(qxdaJLSMjgcHOBKyzRlYXUusEeCvtT)
   for i in qxdaJLSMjgcHOBKyzRlYXUusEeCvQb(qxdaJLSMjgcHOBKyzRlYXUusEeCvQk(qxdaJLSMjgcHOBKyzRlYXUusEeCvtT)):
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtI =qxdaJLSMjgcHOBKyzRlYXUusEeCvtT[i].replace('data-profile-no=','').replace('"','')
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtT[i]=qxdaJLSMjgcHOBKyzRlYXUusEeCvtI
   qxdaJLSMjgcHOBKyzRlYXUusEeCvth=qxdaJLSMjgcHOBKyzRlYXUusEeCvtT[user_pf]
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.Init_TV_Total()
   return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='https://user.tving.com/pc/user/profile/api/checkout.tving'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbw=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.makeDefaultCookies()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvto={'profileNo':qxdaJLSMjgcHOBKyzRlYXUusEeCvth}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Post',qxdaJLSMjgcHOBKyzRlYXUusEeCvtf,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvto,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvbw)
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ in qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.cookies:
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.name=='_tving_token':
     qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_token']=qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.value
    elif qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.name==qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GLOBAL_COOKIENM['tv_cookiekey']:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_cookiekey']=qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.value
    elif qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.name==qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GLOBAL_COOKIENM['tv_lockkey']:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_lockkey']=qxdaJLSMjgcHOBKyzRlYXUusEeCvtQ.value
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.Init_TV_Total()
   return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
 def GetDeviceList(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtp=[]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvti='-'
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v1/user/device/list'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtD=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtf
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'apiKey':'4263d7d76161f4a19a9efe9ca7903ec4','model':'PC'}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbw=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.makeDefaultCookies()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvtD,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvtw,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvbw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtr=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtp=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtA in qxdaJLSMjgcHOBKyzRlYXUusEeCvtp:
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['model']=='PC' or qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['model']=='PC-Chrome':
     qxdaJLSMjgcHOBKyzRlYXUusEeCvti=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['uuid']
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvti
 def Get_Now_Datetime(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN):
  return datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9),'Asia/Seoul'))
 def make_stream_header(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,qxdaJLSMjgcHOBKyzRlYXUusEeCvkb,qxdaJLSMjgcHOBKyzRlYXUusEeCvbw):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtW=''
  if qxdaJLSMjgcHOBKyzRlYXUusEeCvbw not in[{},qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,'']:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtn=qxdaJLSMjgcHOBKyzRlYXUusEeCvQk(qxdaJLSMjgcHOBKyzRlYXUusEeCvbw)
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvbr,qxdaJLSMjgcHOBKyzRlYXUusEeCvtF in qxdaJLSMjgcHOBKyzRlYXUusEeCvbw.items():
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtW+='{}={}'.format(qxdaJLSMjgcHOBKyzRlYXUusEeCvbr,qxdaJLSMjgcHOBKyzRlYXUusEeCvtF)
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtn+=-1
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvtn>0:qxdaJLSMjgcHOBKyzRlYXUusEeCvtW+='; '
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkb['cookie']=qxdaJLSMjgcHOBKyzRlYXUusEeCvtW
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkt=''
  i=0
  for qxdaJLSMjgcHOBKyzRlYXUusEeCvbr,qxdaJLSMjgcHOBKyzRlYXUusEeCvtF in qxdaJLSMjgcHOBKyzRlYXUusEeCvkb.items():
   i=i+1
   if i>1:qxdaJLSMjgcHOBKyzRlYXUusEeCvkt+='&'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkt+='{}={}'.format(qxdaJLSMjgcHOBKyzRlYXUusEeCvbr,urllib.parse.quote(qxdaJLSMjgcHOBKyzRlYXUusEeCvtF))
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvkt
 def GetBroadURL(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,mediacode,sel_quality,stype,pvrmode='-',optUHD=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkV ={'streaming_url':'','drm_license':'','watermark':'','watermarkKey':'','subtitleYn':qxdaJLSMjgcHOBKyzRlYXUusEeCvNG,'error_msg':'',}
  qxdaJLSMjgcHOBKyzRlYXUusEeCvti =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_uuid'].split('-')[0] 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkP =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_uuid'] 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvko=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG 
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkN=qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetNoCache(1))
   if stype!='tvingtv':
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v2/media/stream/info' 
    qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams()
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'mediaCode':mediacode,'info':'Y','callingFrom':'HTML5','adReq':'adproxy','uuid':qxdaJLSMjgcHOBKyzRlYXUusEeCvkP,'deviceInfo':'PC','noCache':qxdaJLSMjgcHOBKyzRlYXUusEeCvkN,}
    qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ.update(qxdaJLSMjgcHOBKyzRlYXUusEeCvtw)
    qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtf
    qxdaJLSMjgcHOBKyzRlYXUusEeCvbw=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.makeDefaultCookies()
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvbw)
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.status_code!=200:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvkV['error_msg']='First Step - {} error'.format(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.status_code)
     return qxdaJLSMjgcHOBKyzRlYXUusEeCvkV
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtr=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['result']['code']=='060':
     for qxdaJLSMjgcHOBKyzRlYXUusEeCvbr,qxdaJLSMjgcHOBKyzRlYXUusEeCvtF in qxdaJLSMjgcHOBKyzRlYXUusEeCvbk.items():
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvtF==sel_quality:
       qxdaJLSMjgcHOBKyzRlYXUusEeCvkh=qxdaJLSMjgcHOBKyzRlYXUusEeCvbr
    elif qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['result']['code']!='000':
     qxdaJLSMjgcHOBKyzRlYXUusEeCvkV['error_msg']=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['result']['message']
     return qxdaJLSMjgcHOBKyzRlYXUusEeCvkV
    else: 
     if not('stream' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']):return qxdaJLSMjgcHOBKyzRlYXUusEeCvkV
     qxdaJLSMjgcHOBKyzRlYXUusEeCvkf=[]
     for qxdaJLSMjgcHOBKyzRlYXUusEeCvbr,qxdaJLSMjgcHOBKyzRlYXUusEeCvtF in qxdaJLSMjgcHOBKyzRlYXUusEeCvbk.items():
      for qxdaJLSMjgcHOBKyzRlYXUusEeCvtA in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['stream']['quality']:
       if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['active']=='Y' and qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['code']==qxdaJLSMjgcHOBKyzRlYXUusEeCvbr:
        qxdaJLSMjgcHOBKyzRlYXUusEeCvkf.append({qxdaJLSMjgcHOBKyzRlYXUusEeCvbk.get(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['code']):qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['code']})
     qxdaJLSMjgcHOBKyzRlYXUusEeCvkh=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.CheckQuality(sel_quality,qxdaJLSMjgcHOBKyzRlYXUusEeCvkf)
     try:
      if optUHD==qxdaJLSMjgcHOBKyzRlYXUusEeCvNn and qxdaJLSMjgcHOBKyzRlYXUusEeCvkh=='stream50' and 'stream_support_info' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['content']['info']:
       if qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['content']['info']['stream_support_info']!=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA:
        if 'stream70' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['content']['info']['stream_support_info']:
         qxdaJLSMjgcHOBKyzRlYXUusEeCvkh='stream70'
         qxdaJLSMjgcHOBKyzRlYXUusEeCvko =qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
     except:
      pass
     try:
      if optUHD==qxdaJLSMjgcHOBKyzRlYXUusEeCvNn and qxdaJLSMjgcHOBKyzRlYXUusEeCvkh=='stream50' and 'stream' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['content']['info']:
       if qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['content']['info']['stream']!=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA:
        for qxdaJLSMjgcHOBKyzRlYXUusEeCvtA in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['content']['info']['stream']:
         if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['code']=='stream70':
          qxdaJLSMjgcHOBKyzRlYXUusEeCvkh='stream70'
          qxdaJLSMjgcHOBKyzRlYXUusEeCvko =qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
          break
     except:
      pass
   else:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvkh='stream40'
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkV['error_msg']='First Step - except error'
   return qxdaJLSMjgcHOBKyzRlYXUusEeCvkV
  qxdaJLSMjgcHOBKyzRlYXUusEeCvND(qxdaJLSMjgcHOBKyzRlYXUusEeCvkh)
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkN=qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetNoCache(1))
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v2a/media/stream/info'
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvko==qxdaJLSMjgcHOBKyzRlYXUusEeCvNn:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams(uhd=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn)
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'mediaCode':mediacode,'noCache':qxdaJLSMjgcHOBKyzRlYXUusEeCvkN,'streamType':'hls','streamCode':qxdaJLSMjgcHOBKyzRlYXUusEeCvkh,'deviceId':qxdaJLSMjgcHOBKyzRlYXUusEeCvti,'adReq':'none','wm':'Y','ad_device':'','uuid':qxdaJLSMjgcHOBKyzRlYXUusEeCvkP,'deviceInfo':'android_tv',}
   else:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams()
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'callingFrom':'HTML5','mediaCode':mediacode,'info':'Y','adReq':'adproxy','streamCode':qxdaJLSMjgcHOBKyzRlYXUusEeCvkh,'deviceId':qxdaJLSMjgcHOBKyzRlYXUusEeCvti,'uuid':qxdaJLSMjgcHOBKyzRlYXUusEeCvkP,'deviceInfo':'PC_Chrome','noCache':qxdaJLSMjgcHOBKyzRlYXUusEeCvkN,'wm':'Y'}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ.update(qxdaJLSMjgcHOBKyzRlYXUusEeCvtw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtf
   qxdaJLSMjgcHOBKyzRlYXUusEeCvbw=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.makeDefaultCookies()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvbw,redirects=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtr=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['result']['code']!='000':
    qxdaJLSMjgcHOBKyzRlYXUusEeCvkV['error_msg']=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['result']['message']
    return qxdaJLSMjgcHOBKyzRlYXUusEeCvkV
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkI=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['stream']
   if 'drm_license_assertion' in qxdaJLSMjgcHOBKyzRlYXUusEeCvkI:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvkV['drm_license']=qxdaJLSMjgcHOBKyzRlYXUusEeCvkI['drm_license_assertion']
    if '4k_nondrm_url' in qxdaJLSMjgcHOBKyzRlYXUusEeCvkI['broadcast']and qxdaJLSMjgcHOBKyzRlYXUusEeCvko==qxdaJLSMjgcHOBKyzRlYXUusEeCvNn:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvkm =qxdaJLSMjgcHOBKyzRlYXUusEeCvkI['broadcast']['4k_nondrm_url']
     qxdaJLSMjgcHOBKyzRlYXUusEeCvkV['drm_license']=''
    else:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvkm =qxdaJLSMjgcHOBKyzRlYXUusEeCvkI['broadcast']['widevine']['broad_url']
   else:
    if not('broad_url' in qxdaJLSMjgcHOBKyzRlYXUusEeCvkI['broadcast']):return qxdaJLSMjgcHOBKyzRlYXUusEeCvkV
    qxdaJLSMjgcHOBKyzRlYXUusEeCvkm=qxdaJLSMjgcHOBKyzRlYXUusEeCvkI['broadcast']['broad_url']
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkV['error_msg']='Second Step - except error'
   return qxdaJLSMjgcHOBKyzRlYXUusEeCvkV
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkp=qxdaJLSMjgcHOBKyzRlYXUusEeCvkN
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkm=qxdaJLSMjgcHOBKyzRlYXUusEeCvkm.split('|')[1]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkm,qxdaJLSMjgcHOBKyzRlYXUusEeCvki,qxdaJLSMjgcHOBKyzRlYXUusEeCvkD=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.Decrypt_Url(qxdaJLSMjgcHOBKyzRlYXUusEeCvkm,mediacode,qxdaJLSMjgcHOBKyzRlYXUusEeCvkp)
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkV['streaming_url']=qxdaJLSMjgcHOBKyzRlYXUusEeCvkm
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkV['watermark'] =qxdaJLSMjgcHOBKyzRlYXUusEeCvki
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkV['watermarkKey']=qxdaJLSMjgcHOBKyzRlYXUusEeCvkD
  if 'subtitles' in qxdaJLSMjgcHOBKyzRlYXUusEeCvkI:
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvkw in qxdaJLSMjgcHOBKyzRlYXUusEeCvkI.get('subtitles'):
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvkw.get('code')in['KO','KO_CC']:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvkV['subtitleYn']=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
     break
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvkV
 def Tving_Parse_mpd(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,stream_url,watermarkKey=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,watermark=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA):
  if watermarkKey not in['',qxdaJLSMjgcHOBKyzRlYXUusEeCvNA]:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkb={'X-Tving-Param1':watermarkKey,'X-Tving-Param2':watermark,'Access-Control-Request-Headers':'x-tving-param1,x-tving-param2',}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=requests.get(url=stream_url,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvkb,allow_redirects=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.status_code)+' - '+qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.url))
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND('')
  else:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=requests.get(url=stream_url)
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkr=qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.content.decode('utf-8')
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkA=0
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkG =ET.ElementTree(ET.fromstring(qxdaJLSMjgcHOBKyzRlYXUusEeCvkr))
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkW =qxdaJLSMjgcHOBKyzRlYXUusEeCvkG.getroot()
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkn=re.match(r'\{.*\}',qxdaJLSMjgcHOBKyzRlYXUusEeCvkW.tag)[0] 
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkF=qxdaJLSMjgcHOBKyzRlYXUusEeCvQP([node for _,node in ET.iterparse(io.StringIO(qxdaJLSMjgcHOBKyzRlYXUusEeCvkr),events=['start-ns'])])
  for qxdaJLSMjgcHOBKyzRlYXUusEeCvbr,qxdaJLSMjgcHOBKyzRlYXUusEeCvVD in qxdaJLSMjgcHOBKyzRlYXUusEeCvkF.items():
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvbr!='ns2':
    ET.register_namespace(qxdaJLSMjgcHOBKyzRlYXUusEeCvbr,qxdaJLSMjgcHOBKyzRlYXUusEeCvVD)
  qxdaJLSMjgcHOBKyzRlYXUusEeCvVb=qxdaJLSMjgcHOBKyzRlYXUusEeCvkW.find(qxdaJLSMjgcHOBKyzRlYXUusEeCvkn+'Period')
  for qxdaJLSMjgcHOBKyzRlYXUusEeCvVt in qxdaJLSMjgcHOBKyzRlYXUusEeCvVb.findall(qxdaJLSMjgcHOBKyzRlYXUusEeCvkn+'AdaptationSet'):
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvVt.attrib.get('mimeType')=='video/mp4':
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvVk in qxdaJLSMjgcHOBKyzRlYXUusEeCvVt.findall(qxdaJLSMjgcHOBKyzRlYXUusEeCvkn+'Representation'):
     qxdaJLSMjgcHOBKyzRlYXUusEeCvVP=qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(qxdaJLSMjgcHOBKyzRlYXUusEeCvVk.attrib.get('bandwidth'))
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvkA<qxdaJLSMjgcHOBKyzRlYXUusEeCvVP:qxdaJLSMjgcHOBKyzRlYXUusEeCvkA=qxdaJLSMjgcHOBKyzRlYXUusEeCvVP
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvVk in qxdaJLSMjgcHOBKyzRlYXUusEeCvVt.findall(qxdaJLSMjgcHOBKyzRlYXUusEeCvkn+'Representation'):
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvkA>qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(qxdaJLSMjgcHOBKyzRlYXUusEeCvVk.attrib.get('bandwidth')):
      qxdaJLSMjgcHOBKyzRlYXUusEeCvVt.remove(qxdaJLSMjgcHOBKyzRlYXUusEeCvVk)
   else:
    continue
  qxdaJLSMjgcHOBKyzRlYXUusEeCvVo=ET.tostring(qxdaJLSMjgcHOBKyzRlYXUusEeCvkW).decode('utf-8')
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TextFile_Save(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV_STREAM_FILENAME,qxdaJLSMjgcHOBKyzRlYXUusEeCvVo)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
 def Tving_Parse_m3u8(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,stream_url):
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=requests.get(url=stream_url,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,stream=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVN=qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.content.decode('utf-8')
   if '#EXTM3U' not in qxdaJLSMjgcHOBKyzRlYXUusEeCvVN:
    return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
   if '#EXT-X-STREAM-INF' not in qxdaJLSMjgcHOBKyzRlYXUusEeCvVN: 
    return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVQ=0
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvVT in qxdaJLSMjgcHOBKyzRlYXUusEeCvVN.splitlines():
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvVT.startswith('#EXT-X-STREAM-INF'):
     qxdaJLSMjgcHOBKyzRlYXUusEeCvVh=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.MediaLine_Parse(qxdaJLSMjgcHOBKyzRlYXUusEeCvVT,'#EXT-X-STREAM-INF')
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvVQ<qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(qxdaJLSMjgcHOBKyzRlYXUusEeCvVh.get('BANDWIDTH')):
      qxdaJLSMjgcHOBKyzRlYXUusEeCvVQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(qxdaJLSMjgcHOBKyzRlYXUusEeCvVh.get('BANDWIDTH'))
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVf=[]
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVI=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvVT in qxdaJLSMjgcHOBKyzRlYXUusEeCvVN.splitlines():
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvVI==qxdaJLSMjgcHOBKyzRlYXUusEeCvNn:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvVI=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
     continue
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvVT.startswith('#EXT-X-STREAM-INF'):
     qxdaJLSMjgcHOBKyzRlYXUusEeCvVh=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.MediaLine_Parse(qxdaJLSMjgcHOBKyzRlYXUusEeCvVT,'#EXT-X-STREAM-INF')
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvVQ!=qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(qxdaJLSMjgcHOBKyzRlYXUusEeCvVh.get('BANDWIDTH')):
      qxdaJLSMjgcHOBKyzRlYXUusEeCvVI=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
      continue
    qxdaJLSMjgcHOBKyzRlYXUusEeCvVf.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvVT)
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
   return qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  qxdaJLSMjgcHOBKyzRlYXUusEeCvVm='\n'.join(qxdaJLSMjgcHOBKyzRlYXUusEeCvVf)
  qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TextFile_Save(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV_STREAM_FILENAME,qxdaJLSMjgcHOBKyzRlYXUusEeCvVm)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
 def MediaLine_Parse(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,qxdaJLSMjgcHOBKyzRlYXUusEeCvVT,prefix):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvVh={}
  for qxdaJLSMjgcHOBKyzRlYXUusEeCvVp in qxdaJLSMjgcHOBKyzRlYXUusEeCvbP.split(qxdaJLSMjgcHOBKyzRlYXUusEeCvVT.replace(prefix+':',''))[1::2]:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVi,qxdaJLSMjgcHOBKyzRlYXUusEeCvVD=qxdaJLSMjgcHOBKyzRlYXUusEeCvVp.split('=',1)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVh[qxdaJLSMjgcHOBKyzRlYXUusEeCvVi.upper()]=qxdaJLSMjgcHOBKyzRlYXUusEeCvVD.replace('"','').strip()
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvVh
 def CheckQuality(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,sel_qt,qxdaJLSMjgcHOBKyzRlYXUusEeCvkf):
  for qxdaJLSMjgcHOBKyzRlYXUusEeCvVw in qxdaJLSMjgcHOBKyzRlYXUusEeCvkf:
   if sel_qt>=qxdaJLSMjgcHOBKyzRlYXUusEeCvQo(qxdaJLSMjgcHOBKyzRlYXUusEeCvVw)[0]:return qxdaJLSMjgcHOBKyzRlYXUusEeCvVw.get(qxdaJLSMjgcHOBKyzRlYXUusEeCvQo(qxdaJLSMjgcHOBKyzRlYXUusEeCvVw)[0])
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVr=qxdaJLSMjgcHOBKyzRlYXUusEeCvVw.get(qxdaJLSMjgcHOBKyzRlYXUusEeCvQo(qxdaJLSMjgcHOBKyzRlYXUusEeCvVw)[0])
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvVr
 def makeOocUrl(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,ooc_params):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=''
  for qxdaJLSMjgcHOBKyzRlYXUusEeCvbr,qxdaJLSMjgcHOBKyzRlYXUusEeCvtF in ooc_params.items():
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT+="%s=%s^"%(qxdaJLSMjgcHOBKyzRlYXUusEeCvbr,qxdaJLSMjgcHOBKyzRlYXUusEeCvtF)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvkT
 def GetLiveChannelList(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,stype,page_int):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtp=[]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v2/media/lives'
   if stype=='onair': 
    qxdaJLSMjgcHOBKyzRlYXUusEeCvVG='CPCS0100,CPCS0400'
   else:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvVG='CPCS0300'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'cacheType':'main','pageNo':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(page_int),'pageSize':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.LIVE_LIMIT),'order':'rating','adult':'all','free':'all','guest':'all','scope':'all','channelType':qxdaJLSMjgcHOBKyzRlYXUusEeCvVG,}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ.update(qxdaJLSMjgcHOBKyzRlYXUusEeCvtw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtf
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtr=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   if not('result' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']):return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVW=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['result']
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtA in qxdaJLSMjgcHOBKyzRlYXUusEeCvVW:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvVn=qxdaJLSMjgcHOBKyzRlYXUusEeCvPt=qxdaJLSMjgcHOBKyzRlYXUusEeCvPk=''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvVF=qxdaJLSMjgcHOBKyzRlYXUusEeCvPW=''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPb=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['live_code']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvVn =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['channel']['name']['ko']
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['episode']!=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPt =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['program']['name']['ko']
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPt =qxdaJLSMjgcHOBKyzRlYXUusEeCvPt+', '+qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['episode']['frequency'])+'회'
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPk=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['episode']['synopsis']['ko']
    else:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPt =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['program']['name']['ko']
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPk=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['program']['synopsis']['ko']
    try: 
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =''
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =''
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=''
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ =''
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPT =''
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPh =''
     for qxdaJLSMjgcHOBKyzRlYXUusEeCvPf in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['program']['image']:
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP0900':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
      elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP1800':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
      elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP2000':qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
      elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP1900':qxdaJLSMjgcHOBKyzRlYXUusEeCvPT =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
      elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP0200':qxdaJLSMjgcHOBKyzRlYXUusEeCvPh =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
      elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP0500':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
      elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP0800':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvPV=='':
      for qxdaJLSMjgcHOBKyzRlYXUusEeCvPf in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['channel']['image']:
       if qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIC0400':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
       elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIC1400':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
       elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIC1900':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
    except:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvNA
    try:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPI =[]
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPm=[]
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPp =[]
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPi=''
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPD=''
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPw=''
     for qxdaJLSMjgcHOBKyzRlYXUusEeCvPr in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('schedule').get('program').get('actor'):
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvPr!='' and qxdaJLSMjgcHOBKyzRlYXUusEeCvPr!=u'없음':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPr)
     for qxdaJLSMjgcHOBKyzRlYXUusEeCvPA in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('schedule').get('program').get('director'):
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvPA!='' and qxdaJLSMjgcHOBKyzRlYXUusEeCvPA!='-' and qxdaJLSMjgcHOBKyzRlYXUusEeCvPA!=u'없음':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPA)
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('schedule').get('program').get('category1_name').get('ko')!='':
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['program']['category1_name']['ko'])
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('schedule').get('program').get('category2_name').get('ko')!='':
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['program']['category2_name']['ko'])
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('schedule').get('program').get('product_year'):qxdaJLSMjgcHOBKyzRlYXUusEeCvPi=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['program']['product_year']
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('schedule').get('program').get('grade_code') :qxdaJLSMjgcHOBKyzRlYXUusEeCvPD= qxdaJLSMjgcHOBKyzRlYXUusEeCvbV.get(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['program']['grade_code'])
     if 'broad_dt' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('schedule').get('program'):
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPG =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('schedule').get('program').get('broad_dt')
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPw='%s-%s-%s'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[:4],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[4:6],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[6:])
    except:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvNA
    qxdaJLSMjgcHOBKyzRlYXUusEeCvVF=qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['broadcast_start_time'])[8:12]
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPW =qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['schedule']['broadcast_end_time'])[8:12]
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPn={'channel':qxdaJLSMjgcHOBKyzRlYXUusEeCvVn,'title':qxdaJLSMjgcHOBKyzRlYXUusEeCvPt,'mediacode':qxdaJLSMjgcHOBKyzRlYXUusEeCvPb,'thumbnail':{'poster':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo,'thumb':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV,'clearlogo':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN,'icon':qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ,'fanart':qxdaJLSMjgcHOBKyzRlYXUusEeCvPh},'synopsis':qxdaJLSMjgcHOBKyzRlYXUusEeCvPk,'channelepg':' [%s:%s ~ %s:%s]'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvVF[0:2],qxdaJLSMjgcHOBKyzRlYXUusEeCvVF[2:],qxdaJLSMjgcHOBKyzRlYXUusEeCvPW[0:2],qxdaJLSMjgcHOBKyzRlYXUusEeCvPW[2:]),'cast':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI,'director':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm,'info_genre':qxdaJLSMjgcHOBKyzRlYXUusEeCvPp,'year':qxdaJLSMjgcHOBKyzRlYXUusEeCvPi,'mpaa':qxdaJLSMjgcHOBKyzRlYXUusEeCvPD,'premiered':qxdaJLSMjgcHOBKyzRlYXUusEeCvPw}
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPn)
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['has_more']=='Y':
    qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
 def GetProgramList(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,genre,orderby,page_int,genreCode='all'):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtp=[]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  try:
   if genre=='PARAMOUNT':
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v2/media/paramount/episodes'
   else:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v2/media/episodes'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'cacheType':'main','pageSize':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.VOD_LIMIT),'order':orderby,'adult':'all','free':'all','guest':'all','scope':'all','lastFrequency':'y','personal':'N','pageNo':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(page_int),}
   if genre not in['all','PARAMOUNT']:qxdaJLSMjgcHOBKyzRlYXUusEeCvtw['categoryCode']=genre
   if genreCode!='all' :qxdaJLSMjgcHOBKyzRlYXUusEeCvtw['genreCode'] =genreCode 
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ.update(qxdaJLSMjgcHOBKyzRlYXUusEeCvtw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtf
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtr=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   if not('result' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']):return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVW=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['result']
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtA in qxdaJLSMjgcHOBKyzRlYXUusEeCvVW:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPF=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['program']['code']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPt =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['program']['name']['ko']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPD =qxdaJLSMjgcHOBKyzRlYXUusEeCvbV.get(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['program'].get('grade_code'))
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ =''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPT =''
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvPf in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['program']['image']:
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP0900':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP0200':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP1800':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP2000':qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP1900':qxdaJLSMjgcHOBKyzRlYXUusEeCvPT =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPk =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['program']['synopsis']['ko']
    try:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvob=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['channel']['name']['ko']
    except:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvob=''
    try:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPI =[]
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPm=[]
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPp =[]
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPi =''
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPw=''
     for qxdaJLSMjgcHOBKyzRlYXUusEeCvPr in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('program').get('actor'):
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvPr!='' and qxdaJLSMjgcHOBKyzRlYXUusEeCvPr!='-' and qxdaJLSMjgcHOBKyzRlYXUusEeCvPr!=u'없음':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPr)
     for qxdaJLSMjgcHOBKyzRlYXUusEeCvPA in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('program').get('director'):
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvPA!='' and qxdaJLSMjgcHOBKyzRlYXUusEeCvPA!='-' and qxdaJLSMjgcHOBKyzRlYXUusEeCvPA!=u'없음':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPA)
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('program').get('category1_name').get('ko')!='':
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['program']['category1_name']['ko'])
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('program').get('category2_name').get('ko')!='':
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['program']['category2_name']['ko'])
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('program').get('product_year'):qxdaJLSMjgcHOBKyzRlYXUusEeCvPi=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['program']['product_year']
     if 'broad_dt' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('program'):
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPG =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('program').get('broad_dt')
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPw='%s-%s-%s'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[:4],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[4:6],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[6:])
    except:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvNA
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPn={'program':qxdaJLSMjgcHOBKyzRlYXUusEeCvPF,'title':qxdaJLSMjgcHOBKyzRlYXUusEeCvPt,'thumbnail':{'poster':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo,'thumb':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV,'clearlogo':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN,'icon':qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ,'banner':qxdaJLSMjgcHOBKyzRlYXUusEeCvPT,'fanart':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV},'synopsis':qxdaJLSMjgcHOBKyzRlYXUusEeCvPk,'channel':qxdaJLSMjgcHOBKyzRlYXUusEeCvob,'cast':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI,'director':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm,'info_genre':qxdaJLSMjgcHOBKyzRlYXUusEeCvPp,'year':qxdaJLSMjgcHOBKyzRlYXUusEeCvPi,'premiered':qxdaJLSMjgcHOBKyzRlYXUusEeCvPw,'mpaa':qxdaJLSMjgcHOBKyzRlYXUusEeCvPD}
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPn)
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['has_more']=='Y':qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
 def Get_UHD_ProgramList(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,page_int):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtp=[]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v2/operator/highlights'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams(uhd=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'positionKey':'SMTV_PROG_4K','pageSize':'20','page_int':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(page_int),'pocType':'APP_X_TVING_4.0.0',}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ.update(qxdaJLSMjgcHOBKyzRlYXUusEeCvtw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtf
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtr=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   if not('result' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']):return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVW=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['result']
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtA in qxdaJLSMjgcHOBKyzRlYXUusEeCvVW:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvot=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['content']['program']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvok =qxdaJLSMjgcHOBKyzRlYXUusEeCvot['code']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPt =qxdaJLSMjgcHOBKyzRlYXUusEeCvot['name']['ko'].strip()
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPD =qxdaJLSMjgcHOBKyzRlYXUusEeCvbV.get(qxdaJLSMjgcHOBKyzRlYXUusEeCvot.get('grade_code'))
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPk =qxdaJLSMjgcHOBKyzRlYXUusEeCvot['synopsis']['ko']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvob =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['content']['channel']['name']['ko']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPi =qxdaJLSMjgcHOBKyzRlYXUusEeCvot['product_year']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ =''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPT =''
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvPf in qxdaJLSMjgcHOBKyzRlYXUusEeCvot['image']:
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP0900':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP0200':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP1800':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP2000':qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP1900':qxdaJLSMjgcHOBKyzRlYXUusEeCvPT =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPp =[]
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPI =[]
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPm=[]
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPw =''
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvot.get('category1_name').get('ko')!='':
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvot['category1_name']['ko'])
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvot.get('category2_name').get('ko')!='':
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvot['category2_name']['ko'])
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvPr in qxdaJLSMjgcHOBKyzRlYXUusEeCvot.get('actor'):
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvPr!='' and qxdaJLSMjgcHOBKyzRlYXUusEeCvPr!='-' and qxdaJLSMjgcHOBKyzRlYXUusEeCvPr!=u'없음':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPr)
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvPA in qxdaJLSMjgcHOBKyzRlYXUusEeCvot.get('director'):
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvPA!='' and qxdaJLSMjgcHOBKyzRlYXUusEeCvPA!='-' and qxdaJLSMjgcHOBKyzRlYXUusEeCvPA!=u'없음':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPA)
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvot.get('broad_dt')not in[qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,'']:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPG =qxdaJLSMjgcHOBKyzRlYXUusEeCvot.get('broad_dt')
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPw='%s-%s-%s'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[:4],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[4:6],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[6:])
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPn={'program':qxdaJLSMjgcHOBKyzRlYXUusEeCvok,'title':qxdaJLSMjgcHOBKyzRlYXUusEeCvPt,'mpaa':qxdaJLSMjgcHOBKyzRlYXUusEeCvPD,'thumbnail':{'poster':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo,'thumb':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV,'clearlogo':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN,'icon':qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ,'banner':qxdaJLSMjgcHOBKyzRlYXUusEeCvPT,'fanart':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV},'channel':qxdaJLSMjgcHOBKyzRlYXUusEeCvob,'synopsis':qxdaJLSMjgcHOBKyzRlYXUusEeCvPk,'year':qxdaJLSMjgcHOBKyzRlYXUusEeCvPi,'info_genre':qxdaJLSMjgcHOBKyzRlYXUusEeCvPp,'cast':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI,'director':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm,'premiered':qxdaJLSMjgcHOBKyzRlYXUusEeCvPw,}
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPn)
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
 def Get_Origianl_ProgramList(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,page_int):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtp=[]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v2/media/band/originals'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'pageSize':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.VOD_LIMIT),'adult':'all','order':'viewHour','originalYn':'Y','exclusiveYn':'Y','pageNo':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(page_int),}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ.update(qxdaJLSMjgcHOBKyzRlYXUusEeCvtw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtf
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtr=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   if not('contents' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']):return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVW=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['contents']
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtA in qxdaJLSMjgcHOBKyzRlYXUusEeCvVW:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPF=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['vod_code']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPt =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['vod_name']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['image']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPn={'program':qxdaJLSMjgcHOBKyzRlYXUusEeCvPF,'title':qxdaJLSMjgcHOBKyzRlYXUusEeCvPt,'thumbnail':{'poster':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo,'thumb':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo}}
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPn)
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['has_more']=='Y':qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
 def GetEpisodeList(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,program_code,page_int,orderby='desc'):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtp=[]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v2/media/frequency/program/'+program_code
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'order':'newUpdate','cacheType':'main','pageSize':'20','order':'new','adult':'all','free':'all','guest':'all','scope':'all',}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ.update(qxdaJLSMjgcHOBKyzRlYXUusEeCvtw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtf
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtr=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   if not('result' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']):return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVW=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['result']
   qxdaJLSMjgcHOBKyzRlYXUusEeCvoV=qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['total_count'])
   qxdaJLSMjgcHOBKyzRlYXUusEeCvoP =qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(qxdaJLSMjgcHOBKyzRlYXUusEeCvoV//(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.EPISODE_LIMIT+1))+1
   if orderby=='desc':
    qxdaJLSMjgcHOBKyzRlYXUusEeCvoN =(qxdaJLSMjgcHOBKyzRlYXUusEeCvoV-1)-((page_int-1)*qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.EPISODE_LIMIT)
   else:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvoN =(page_int-1)*qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.EPISODE_LIMIT
   for i in qxdaJLSMjgcHOBKyzRlYXUusEeCvQb(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.EPISODE_LIMIT):
    if orderby=='desc':
     qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvoN-i
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ<0:break
    else:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvoN+i
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ>=qxdaJLSMjgcHOBKyzRlYXUusEeCvoV:break
    qxdaJLSMjgcHOBKyzRlYXUusEeCvoT=qxdaJLSMjgcHOBKyzRlYXUusEeCvVW[qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ]['episode']['code']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPt =qxdaJLSMjgcHOBKyzRlYXUusEeCvVW[qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ]['vod_name']['ko']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvoh =''
    try:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPG=qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvVW[qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ]['episode']['broadcast_date'])
     qxdaJLSMjgcHOBKyzRlYXUusEeCvoh='%s-%s-%s'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[:4],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[4:6],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[6:])
    except:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvNA
    try:
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvVW[qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ]['episode']['pip_cliptype']=='C012':
      qxdaJLSMjgcHOBKyzRlYXUusEeCvoh+=' - Quick VOD'
    except:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvNA
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPk =qxdaJLSMjgcHOBKyzRlYXUusEeCvVW[qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ]['episode']['synopsis']['ko']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ =''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPT =''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPh =''
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvPf in qxdaJLSMjgcHOBKyzRlYXUusEeCvVW[qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ]['program']['image']:
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP0900':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP1800':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP2000':qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP1900':qxdaJLSMjgcHOBKyzRlYXUusEeCvPT =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIP0200':qxdaJLSMjgcHOBKyzRlYXUusEeCvPh =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvPf in qxdaJLSMjgcHOBKyzRlYXUusEeCvVW[qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ]['episode']['image']:
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIE0400':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
    try:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvof=qxdaJLSMjgcHOBKyzRlYXUusEeCvom=qxdaJLSMjgcHOBKyzRlYXUusEeCvop=''
     qxdaJLSMjgcHOBKyzRlYXUusEeCvoI=0
     qxdaJLSMjgcHOBKyzRlYXUusEeCvof =qxdaJLSMjgcHOBKyzRlYXUusEeCvVW[qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ]['program']['name']['ko']
     qxdaJLSMjgcHOBKyzRlYXUusEeCvom =qxdaJLSMjgcHOBKyzRlYXUusEeCvoh
     qxdaJLSMjgcHOBKyzRlYXUusEeCvop =qxdaJLSMjgcHOBKyzRlYXUusEeCvVW[qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ]['channel']['name']['ko']
     if 'frequency' in qxdaJLSMjgcHOBKyzRlYXUusEeCvVW[qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ]['episode']:qxdaJLSMjgcHOBKyzRlYXUusEeCvoI=qxdaJLSMjgcHOBKyzRlYXUusEeCvVW[qxdaJLSMjgcHOBKyzRlYXUusEeCvoQ]['episode']['frequency']
    except:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvNA
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPn={'episode':qxdaJLSMjgcHOBKyzRlYXUusEeCvoT,'title':qxdaJLSMjgcHOBKyzRlYXUusEeCvPt,'subtitle':qxdaJLSMjgcHOBKyzRlYXUusEeCvoh,'thumbnail':{'poster':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo,'thumb':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV,'clearlogo':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN,'icon':qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ,'banner':qxdaJLSMjgcHOBKyzRlYXUusEeCvPT,'fanart':qxdaJLSMjgcHOBKyzRlYXUusEeCvPh},'synopsis':qxdaJLSMjgcHOBKyzRlYXUusEeCvPk,'info_title':qxdaJLSMjgcHOBKyzRlYXUusEeCvof,'aired':qxdaJLSMjgcHOBKyzRlYXUusEeCvom,'studio':qxdaJLSMjgcHOBKyzRlYXUusEeCvop,'frequency':qxdaJLSMjgcHOBKyzRlYXUusEeCvoI}
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPn)
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvoP>page_int:qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA,qxdaJLSMjgcHOBKyzRlYXUusEeCvoP
 def GetMovieList(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,genre,orderby,page_int):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtp=[]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  try:
   if genre=='PARAMOUNT':
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v2/media/paramount/movies'
   else:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v2/media/movies'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'pageSize':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.MOVIE_LIMIT),'order':orderby,'free':'all','adult':'all','guest':'all','scope':'all','personal':'N','diversityYn':'N' if genre!='diversityYn' else 'Y','pageNo':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(page_int),}
   if genre not in['all','PARAMOUNT','diversityYn']:qxdaJLSMjgcHOBKyzRlYXUusEeCvtw['categoryCode']=genre
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw['productPackageCode']=','.join(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.MOVIE_LITE)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ.update(qxdaJLSMjgcHOBKyzRlYXUusEeCvtw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtf
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtr=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   if not('result' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']):return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVW=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['result']
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtA in qxdaJLSMjgcHOBKyzRlYXUusEeCvVW:
    if 'release_date' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('movie'):
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPi=qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('movie').get('release_date'))[:4]
    else:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPi=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA
    qxdaJLSMjgcHOBKyzRlYXUusEeCvoi =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['movie']['code']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPt =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['movie']['name']['ko'].strip()
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvPi not in[qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,'0','']:qxdaJLSMjgcHOBKyzRlYXUusEeCvPt+=u' (%s)'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvPi)
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPo=''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=''
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvPf in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['movie']['image']:
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIM2100':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIM0400':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIM1800':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPk =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['movie']['story']['ko']
    try:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvof =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['movie']['name']['ko'].strip()
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPD =qxdaJLSMjgcHOBKyzRlYXUusEeCvbV.get(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('grade_code'))
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPI=[]
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPm=[]
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPp=[]
     qxdaJLSMjgcHOBKyzRlYXUusEeCvoD=0
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPw=''
     qxdaJLSMjgcHOBKyzRlYXUusEeCvop =''
     for qxdaJLSMjgcHOBKyzRlYXUusEeCvPr in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('movie').get('actor'):
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvPr!='':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPr)
     for qxdaJLSMjgcHOBKyzRlYXUusEeCvPA in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('movie').get('director'):
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvPA!='':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPA)
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('movie').get('category1_name').get('ko')!='':
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['movie']['category1_name']['ko'])
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('movie').get('category2_name').get('ko')!='':
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['movie']['category2_name']['ko'])
     if 'duration' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('movie'):qxdaJLSMjgcHOBKyzRlYXUusEeCvoD=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('movie').get('duration')
     if 'release_date' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('movie'):
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPG=qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('movie').get('release_date'))
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvPG!='0':qxdaJLSMjgcHOBKyzRlYXUusEeCvPw='%s-%s-%s'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[:4],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[4:6],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[6:])
     if 'production' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('movie'):qxdaJLSMjgcHOBKyzRlYXUusEeCvop=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('movie').get('production')
    except:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvNA
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPn={'moviecode':qxdaJLSMjgcHOBKyzRlYXUusEeCvoi,'title':qxdaJLSMjgcHOBKyzRlYXUusEeCvPt,'thumbnail':{'poster':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo,'thumb':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV,'clearlogo':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN,'fanart':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV},'synopsis':qxdaJLSMjgcHOBKyzRlYXUusEeCvPk,'info_title':qxdaJLSMjgcHOBKyzRlYXUusEeCvof,'year':qxdaJLSMjgcHOBKyzRlYXUusEeCvPi,'cast':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI,'director':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm,'info_genre':qxdaJLSMjgcHOBKyzRlYXUusEeCvPp,'duration':qxdaJLSMjgcHOBKyzRlYXUusEeCvoD,'premiered':qxdaJLSMjgcHOBKyzRlYXUusEeCvPw,'studio':qxdaJLSMjgcHOBKyzRlYXUusEeCvop,'mpaa':qxdaJLSMjgcHOBKyzRlYXUusEeCvPD}
    qxdaJLSMjgcHOBKyzRlYXUusEeCvow=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvor in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['billing_package_id']:
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvor in qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.MOVIE_LITE:
      qxdaJLSMjgcHOBKyzRlYXUusEeCvow=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
      break
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvow==qxdaJLSMjgcHOBKyzRlYXUusEeCvNG: 
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPn['title']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPn['title']+' [개별구매]'
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPn)
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['has_more']=='Y':qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
 def Get_UHD_MovieList(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,page_int):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtp=[]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v2/operator/highlights'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams(uhd=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'positionKey':'SMTV_MV_4K','pageSize':'20','page_int':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(page_int),'pocType':'APP_X_TVING_4.0.0',}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ.update(qxdaJLSMjgcHOBKyzRlYXUusEeCvtw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtf
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtr=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   if not('result' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']):return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVW=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['result']
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtA in qxdaJLSMjgcHOBKyzRlYXUusEeCvVW:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvot=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['content']['movie']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvok =qxdaJLSMjgcHOBKyzRlYXUusEeCvot['code']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPt =qxdaJLSMjgcHOBKyzRlYXUusEeCvot['name']['ko'].strip()
    qxdaJLSMjgcHOBKyzRlYXUusEeCvof =qxdaJLSMjgcHOBKyzRlYXUusEeCvot['name']['ko'].strip()
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPi =qxdaJLSMjgcHOBKyzRlYXUusEeCvot['product_year']
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvPi:qxdaJLSMjgcHOBKyzRlYXUusEeCvPt+=u' (%s)'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvot['product_year'])
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPk =qxdaJLSMjgcHOBKyzRlYXUusEeCvot['story']['ko']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvoD =qxdaJLSMjgcHOBKyzRlYXUusEeCvot['duration']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPD =qxdaJLSMjgcHOBKyzRlYXUusEeCvbV.get(qxdaJLSMjgcHOBKyzRlYXUusEeCvot.get('grade_code'))
    qxdaJLSMjgcHOBKyzRlYXUusEeCvop =qxdaJLSMjgcHOBKyzRlYXUusEeCvot['production']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPo=''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=''
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPp =[]
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPI =[]
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPm=[]
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPw =''
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvPf in qxdaJLSMjgcHOBKyzRlYXUusEeCvot['image']:
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIM2100':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIM0400':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
     elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['code']=='CAIM1800':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf['url']
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvot['release_date']not in[qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,0]:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPG=qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvot['release_date'])
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvPG!='0':qxdaJLSMjgcHOBKyzRlYXUusEeCvPw='%s-%s-%s'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[:4],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[4:6],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[6:])
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvot.get('category1_name').get('ko')!='':
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvot['category1_name']['ko'])
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvot.get('category2_name').get('ko')!='':
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvot['category2_name']['ko'])
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvPr in qxdaJLSMjgcHOBKyzRlYXUusEeCvot.get('actor'):
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvPr!='':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPr)
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvPA in qxdaJLSMjgcHOBKyzRlYXUusEeCvot.get('director'):
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvPA!='':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPA)
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPn={'moviecode':qxdaJLSMjgcHOBKyzRlYXUusEeCvok,'title':qxdaJLSMjgcHOBKyzRlYXUusEeCvPt,'thumbnail':{'poster':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo,'thumb':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV,'clearlogo':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN,'fanart':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV},'year':qxdaJLSMjgcHOBKyzRlYXUusEeCvPi,'info_title':qxdaJLSMjgcHOBKyzRlYXUusEeCvof,'synopsis':qxdaJLSMjgcHOBKyzRlYXUusEeCvPk,'mpaa':qxdaJLSMjgcHOBKyzRlYXUusEeCvPD,'duration':qxdaJLSMjgcHOBKyzRlYXUusEeCvoD,'premiered':qxdaJLSMjgcHOBKyzRlYXUusEeCvPw,'studio':qxdaJLSMjgcHOBKyzRlYXUusEeCvop,'info_genre':qxdaJLSMjgcHOBKyzRlYXUusEeCvPp,'cast':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI,'director':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm,}
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPn)
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
 def GetMovieGenre(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtp=[]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v2/media/movie/curations'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'pageNo':'1','pageSize':'10','movieViewType':'sma','curationSection':'view0002','order':'curation_code'}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ.update(qxdaJLSMjgcHOBKyzRlYXUusEeCvtw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtf
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtr=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   if not('result' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']):return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVW=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['result']
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtA in qxdaJLSMjgcHOBKyzRlYXUusEeCvVW:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvoA =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['curation_code']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvoG =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['curation_name']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvPn={'curation_code':qxdaJLSMjgcHOBKyzRlYXUusEeCvoA,'curation_name':qxdaJLSMjgcHOBKyzRlYXUusEeCvoG}
    qxdaJLSMjgcHOBKyzRlYXUusEeCvtp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPn)
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
 def GetSearchList(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,search_key,page_int,stype):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvoW=[]
  qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/search/getSearch.jsp'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'kwd':search_key,'category':'PROGRAM' if stype=='vod' else 'VODMV','pageNum':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(page_int),'notFoundText':search_key,'userid':'','siteName':'TVING_WEB','pageSize':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.SEARCH_LIMIT),'indexType':'both','methodType':'allwordthruindex','payFree':'ALL','runTime':'ALL','grade':'ALL','genre':'ALL','screen':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.SCREENCODE,'os':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.OSCODE,'network':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.NETWORKCODE,'sort1':'NO','sort2':'NO','sort3':'NO','type1':'desc','type2':'desc','type3':'desc','fixedType':'Y','spcMethod':'someword','spcSize':'0','schReqCnt':'0','vodBCReqCnt':'0','programReqCnt':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.SEARCH_LIMIT)if stype=='vod' else '0','vodMVReqCnt':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.SEARCH_LIMIT)if stype=='movie' else '0','aloneReqCnt':'0','smrclipReqCnt':'0','pickClipReqCnt':'0','cSocialClipCnt':'0','boardReqCnt':'0','talkReqCnt':'0','nowTime':'','mode':'normal','adult_yn':'','reKwd':'','xwd':'','apiKey':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.APIKEY,'networkCode':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.NETWORKCODE,'osCode ':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.OSCODE,'teleCode ':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TELECODE,'screenCode ':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.SCREENCODE}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.SEARCH_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtf
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvtw,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtr=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   if stype=='vod':
    if not('programRsb' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr):return qxdaJLSMjgcHOBKyzRlYXUusEeCvoW,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
    qxdaJLSMjgcHOBKyzRlYXUusEeCvon=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['programRsb']['dataList']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvoF =qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['programRsb']['count'])
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvtA in qxdaJLSMjgcHOBKyzRlYXUusEeCvon:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPF=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['mast_cd']
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPt =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['mast_nm']
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPo=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['web_url4']
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['web_url']
     try:
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPI =[]
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPm=[]
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPp =[]
      qxdaJLSMjgcHOBKyzRlYXUusEeCvoD =0
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPD =''
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPi =''
      qxdaJLSMjgcHOBKyzRlYXUusEeCvom =''
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('actor') !='' and qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('actor') !='-':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('actor').split(',')
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('director')!='' and qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('director')!='-':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('director').split(',')
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('cate_nm')!='' and qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('cate_nm')!='-':qxdaJLSMjgcHOBKyzRlYXUusEeCvPp =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('cate_nm').split('/')
      if 'targetage' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA:qxdaJLSMjgcHOBKyzRlYXUusEeCvPD=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('targetage')
      if 'broad_dt' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA:
       qxdaJLSMjgcHOBKyzRlYXUusEeCvPG=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('broad_dt')
       qxdaJLSMjgcHOBKyzRlYXUusEeCvom='%s-%s-%s'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[:4],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[4:6],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[6:])
       qxdaJLSMjgcHOBKyzRlYXUusEeCvPi =qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[:4]
     except:
      qxdaJLSMjgcHOBKyzRlYXUusEeCvNA
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPn={'program':qxdaJLSMjgcHOBKyzRlYXUusEeCvPF,'title':qxdaJLSMjgcHOBKyzRlYXUusEeCvPt,'thumbnail':{'poster':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo,'thumb':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV,'fanart':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV},'synopsis':'','cast':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI,'director':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm,'info_genre':qxdaJLSMjgcHOBKyzRlYXUusEeCvPp,'duration':qxdaJLSMjgcHOBKyzRlYXUusEeCvoD,'mpaa':qxdaJLSMjgcHOBKyzRlYXUusEeCvPD,'year':qxdaJLSMjgcHOBKyzRlYXUusEeCvPi,'aired':qxdaJLSMjgcHOBKyzRlYXUusEeCvom}
     qxdaJLSMjgcHOBKyzRlYXUusEeCvoW.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPn)
   else:
    if not('vodMVRsb' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr):return qxdaJLSMjgcHOBKyzRlYXUusEeCvoW,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
    qxdaJLSMjgcHOBKyzRlYXUusEeCvNb=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['vodMVRsb']['dataList']
    qxdaJLSMjgcHOBKyzRlYXUusEeCvoF =qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['vodMVRsb']['count'])
    for qxdaJLSMjgcHOBKyzRlYXUusEeCvtA in qxdaJLSMjgcHOBKyzRlYXUusEeCvNb:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPF=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['mast_cd']
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPt =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['mast_nm'].strip()
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['web_url']
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvPo
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=''
     try:
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPI =[]
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPm=[]
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPp =[]
      qxdaJLSMjgcHOBKyzRlYXUusEeCvoD =0
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPD =''
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPi =''
      qxdaJLSMjgcHOBKyzRlYXUusEeCvom =''
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('actor') !='' and qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('actor') !='-':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('actor').split(',')
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('director')!='' and qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('director')!='-':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('director').split(',')
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('cate_nm')!='' and qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('cate_nm')!='-':qxdaJLSMjgcHOBKyzRlYXUusEeCvPp =qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('cate_nm').split('/')
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('runtime_sec')!='':qxdaJLSMjgcHOBKyzRlYXUusEeCvoD=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('runtime_sec')
      if 'grade_nm' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA:qxdaJLSMjgcHOBKyzRlYXUusEeCvPD=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('grade_nm')
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPG=qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('broad_dt')
      if data_str!='':
       qxdaJLSMjgcHOBKyzRlYXUusEeCvom='%s-%s-%s'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[:4],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[4:6],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[6:])
       qxdaJLSMjgcHOBKyzRlYXUusEeCvPi =qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[:4]
     except:
      qxdaJLSMjgcHOBKyzRlYXUusEeCvNA
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPn={'movie':qxdaJLSMjgcHOBKyzRlYXUusEeCvPF,'title':qxdaJLSMjgcHOBKyzRlYXUusEeCvPt,'thumbnail':{'poster':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo,'thumb':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV,'fanart':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV,'clearlogo':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN},'synopsis':'','cast':qxdaJLSMjgcHOBKyzRlYXUusEeCvPI,'director':qxdaJLSMjgcHOBKyzRlYXUusEeCvPm,'info_genre':qxdaJLSMjgcHOBKyzRlYXUusEeCvPp,'duration':qxdaJLSMjgcHOBKyzRlYXUusEeCvoD,'mpaa':qxdaJLSMjgcHOBKyzRlYXUusEeCvPD,'year':qxdaJLSMjgcHOBKyzRlYXUusEeCvPi,'aired':qxdaJLSMjgcHOBKyzRlYXUusEeCvom}
     qxdaJLSMjgcHOBKyzRlYXUusEeCvow=qxdaJLSMjgcHOBKyzRlYXUusEeCvNG
     for qxdaJLSMjgcHOBKyzRlYXUusEeCvor in qxdaJLSMjgcHOBKyzRlYXUusEeCvtA['bill']:
      if qxdaJLSMjgcHOBKyzRlYXUusEeCvor in qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.MOVIE_LITE:
       qxdaJLSMjgcHOBKyzRlYXUusEeCvow=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
       break
     if qxdaJLSMjgcHOBKyzRlYXUusEeCvow==qxdaJLSMjgcHOBKyzRlYXUusEeCvNG: 
      qxdaJLSMjgcHOBKyzRlYXUusEeCvPn['title']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPn['title']+' [개별구매]'
     qxdaJLSMjgcHOBKyzRlYXUusEeCvoW.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPn)
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvoF>(page_int*qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.SEARCH_LIMIT):qxdaJLSMjgcHOBKyzRlYXUusEeCvVA=qxdaJLSMjgcHOBKyzRlYXUusEeCvNn
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvoW,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
 def GetBookmarkInfo(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,videoid,vidtype):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvNt={'indexinfo':{'ott':'tving','videoid':videoid,'vidtype':vidtype,},'saveinfo':{'title':'','subtitle':'','thumbnail':{'poster':'','thumb':'','clearlogo':'','icon':'','banner':'','fanart':''},'infoLabels':{'mediatype':vidtype,'title':'','mpaa':'','plot':'','year':'','studio':'','duration':0,'cast':[],'director':[],'genre':[],'premiered':'','country':'',},},}
  if vidtype=='tvshow':
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+'/v2/media/program/'+videoid
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'pageNo':'1','pageSize':'10','order':'name',}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ.update(qxdaJLSMjgcHOBKyzRlYXUusEeCvtw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNk=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   if not('body' in qxdaJLSMjgcHOBKyzRlYXUusEeCvNk):return{}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNV=qxdaJLSMjgcHOBKyzRlYXUusEeCvNk['body']
   qxdaJLSMjgcHOBKyzRlYXUusEeCvPt=qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('name').get('ko').strip()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['title'] =qxdaJLSMjgcHOBKyzRlYXUusEeCvPt
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['title']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPt
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['mpaa'] =qxdaJLSMjgcHOBKyzRlYXUusEeCvbV.get(qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('grade_code'))
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['plot'] =qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('synopsis').get('ko')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['year'] =qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('product_year')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['cast'] =qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('actor')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['director']=qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('director')
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('category1_name').get('ko')!='':
    qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['genre'].append(qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('category1_name').get('ko'))
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('category2_name').get('ko')!='':
    qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['genre'].append(qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('category2_name').get('ko'))
   qxdaJLSMjgcHOBKyzRlYXUusEeCvPG=qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('broad_dt'))
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvPG!='0':qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[:4],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[4:6],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[6:])
   qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =''
   qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =''
   qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=''
   qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ =''
   qxdaJLSMjgcHOBKyzRlYXUusEeCvPT =''
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvPf in qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('image'):
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('code')=='CAIP0900':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('url')
    elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('code')=='CAIP0200':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('url')
    elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('code')=='CAIP1800':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('url')
    elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('code')=='CAIP2000':qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('url')
    elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('code')=='CAIP1900':qxdaJLSMjgcHOBKyzRlYXUusEeCvPT =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('url')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['thumbnail']['poster']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPo
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['thumbnail']['thumb']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPV
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['thumbnail']['clearlogo']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPN
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['thumbnail']['icon']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPQ
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['thumbnail']['banner']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPT
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['thumbnail']['fanart']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPV
  else:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+'/v2a/media/stream/info'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'callingFrom':'HTML5','mediaCode':videoid,'info':'Y','adReq':'adproxy','streamCode':'stream40','deviceId':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_uuid'].split('-')[0],'uuid':qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.TV['cookies']['tving_uuid'],'deviceInfo':'PC_Chrome','noCache':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetNoCache(1)),'wm':'Y',}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ.update(qxdaJLSMjgcHOBKyzRlYXUusEeCvtw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNk=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   if not('content' in qxdaJLSMjgcHOBKyzRlYXUusEeCvNk['body']):return{}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNV=qxdaJLSMjgcHOBKyzRlYXUusEeCvNk['body']['content']['info']['movie']
   qxdaJLSMjgcHOBKyzRlYXUusEeCvPt =qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('name').get('ko').strip()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['title']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPt
   qxdaJLSMjgcHOBKyzRlYXUusEeCvPt +=u' (%s)'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('product_year'))
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['title'] =qxdaJLSMjgcHOBKyzRlYXUusEeCvPt
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['mpaa'] =qxdaJLSMjgcHOBKyzRlYXUusEeCvbV.get(qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('grade_code'))
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['plot'] =qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('story').get('ko')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['year'] =qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('product_year')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['studio'] =qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('production')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['duration']=qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('duration')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['cast'] =qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('actor')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['director']=qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('director')
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('category1_name').get('ko')!='':
    qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['genre'].append(qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('category1_name').get('ko'))
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('category2_name').get('ko')!='':
    qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['genre'].append(qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('category2_name').get('ko'))
   qxdaJLSMjgcHOBKyzRlYXUusEeCvPG=qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('release_date'))
   if qxdaJLSMjgcHOBKyzRlYXUusEeCvPG!='0':qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['infoLabels']['premiered']='%s-%s-%s'%(qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[:4],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[4:6],qxdaJLSMjgcHOBKyzRlYXUusEeCvPG[6:])
   qxdaJLSMjgcHOBKyzRlYXUusEeCvPo=''
   qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =''
   qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=''
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvPf in qxdaJLSMjgcHOBKyzRlYXUusEeCvNV.get('image'):
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('code')=='CAIM2100':qxdaJLSMjgcHOBKyzRlYXUusEeCvPo =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('url')
    elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('code')=='CAIM0400':qxdaJLSMjgcHOBKyzRlYXUusEeCvPV =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('url')
    elif qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('code')=='CAIM1800':qxdaJLSMjgcHOBKyzRlYXUusEeCvPN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.IMG_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvPf.get('url')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['thumbnail']['poster']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPo
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['thumbnail']['thumb']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPo 
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['thumbnail']['clearlogo']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPN
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNt['saveinfo']['thumbnail']['fanart']=qxdaJLSMjgcHOBKyzRlYXUusEeCvPV
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvNt
 def GetEuroChannelList(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvtp=[]
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtf ='/v2/operator/highlights'
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetDefaultParams()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtw={'positionKey':'PC_EURO_EVENT_LIST','cacheTime':'5','_':qxdaJLSMjgcHOBKyzRlYXUusEeCvQV(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.GetNoCache(2))}
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ.update(qxdaJLSMjgcHOBKyzRlYXUusEeCvtw)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkT=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.API_DOMAIN+qxdaJLSMjgcHOBKyzRlYXUusEeCvtf
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtN=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.callRequestCookies('Get',qxdaJLSMjgcHOBKyzRlYXUusEeCvkT,payload=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,params=qxdaJLSMjgcHOBKyzRlYXUusEeCvkQ,headers=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA,cookies=qxdaJLSMjgcHOBKyzRlYXUusEeCvNA)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvtr=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvtN.text)
   if not('result' in qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']):return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp,qxdaJLSMjgcHOBKyzRlYXUusEeCvVA
   qxdaJLSMjgcHOBKyzRlYXUusEeCvVW=qxdaJLSMjgcHOBKyzRlYXUusEeCvtr['body']['result']
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNP =qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.Get_Now_Datetime()
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNo=qxdaJLSMjgcHOBKyzRlYXUusEeCvNP+datetime.timedelta(days=-1)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNo=qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(qxdaJLSMjgcHOBKyzRlYXUusEeCvNo.strftime('%Y%m%d'))
   for qxdaJLSMjgcHOBKyzRlYXUusEeCvtA in qxdaJLSMjgcHOBKyzRlYXUusEeCvVW:
    qxdaJLSMjgcHOBKyzRlYXUusEeCvNQ=qxdaJLSMjgcHOBKyzRlYXUusEeCvNF(qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('content').get('banner_title2')[:8])
    if qxdaJLSMjgcHOBKyzRlYXUusEeCvNo<=qxdaJLSMjgcHOBKyzRlYXUusEeCvNQ:
     qxdaJLSMjgcHOBKyzRlYXUusEeCvPn={'channel':qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('content').get('banner_sub_title3'),'title':qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('content').get('banner_title'),'subtitle':qxdaJLSMjgcHOBKyzRlYXUusEeCvtA.get('content').get('banner_sub_title2'),}
     qxdaJLSMjgcHOBKyzRlYXUusEeCvtp.append(qxdaJLSMjgcHOBKyzRlYXUusEeCvPn)
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvtp
 def Make_DecryptKey(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,step,mediacode='000',timecode='000'):
  if step=='1':
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNT=qxdaJLSMjgcHOBKyzRlYXUusEeCvQN('cj*tving/{}/{}'.format(mediacode[-3:],timecode[:3]),'utf-8')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNh=qxdaJLSMjgcHOBKyzRlYXUusEeCvQN('6yhlJ4WF9ZIj6I8n','utf-8')
  else:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNT=qxdaJLSMjgcHOBKyzRlYXUusEeCvQN('kss2lym0kdw1lks3','utf-8')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNh=qxdaJLSMjgcHOBKyzRlYXUusEeCvQN([qxdaJLSMjgcHOBKyzRlYXUusEeCvQT('*'),0x07,qxdaJLSMjgcHOBKyzRlYXUusEeCvQT('r'),qxdaJLSMjgcHOBKyzRlYXUusEeCvQT(';'),qxdaJLSMjgcHOBKyzRlYXUusEeCvQT('7'),0x05,0x1e,0x01,qxdaJLSMjgcHOBKyzRlYXUusEeCvQT('n'),qxdaJLSMjgcHOBKyzRlYXUusEeCvQT('D'),0x02,qxdaJLSMjgcHOBKyzRlYXUusEeCvQT('3'),qxdaJLSMjgcHOBKyzRlYXUusEeCvQT('*'),qxdaJLSMjgcHOBKyzRlYXUusEeCvQT('a'),qxdaJLSMjgcHOBKyzRlYXUusEeCvQT('&'),qxdaJLSMjgcHOBKyzRlYXUusEeCvQT('<')])
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvNT,qxdaJLSMjgcHOBKyzRlYXUusEeCvNh
 def DecryptPlaintext(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,ciphertext,encryption_key,init_vector):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvNf=AES.new(encryption_key,AES.MODE_CBC,init_vector,)
  qxdaJLSMjgcHOBKyzRlYXUusEeCvNI=Padding.unpad(qxdaJLSMjgcHOBKyzRlYXUusEeCvNf.decrypt(base64.standard_b64decode(ciphertext)),16)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvNI.decode('utf-8')
 def Decrypt_Url(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN,ciphertext,mediacode,qxdaJLSMjgcHOBKyzRlYXUusEeCvkp):
  qxdaJLSMjgcHOBKyzRlYXUusEeCvNm=''
  qxdaJLSMjgcHOBKyzRlYXUusEeCvki=''
  qxdaJLSMjgcHOBKyzRlYXUusEeCvkD=''
  try:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNT,qxdaJLSMjgcHOBKyzRlYXUusEeCvNh=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.Make_DecryptKey('1',mediacode=mediacode,timecode=qxdaJLSMjgcHOBKyzRlYXUusEeCvkp)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNp=json.loads(qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.DecryptPlaintext(ciphertext,qxdaJLSMjgcHOBKyzRlYXUusEeCvNT,qxdaJLSMjgcHOBKyzRlYXUusEeCvNh))
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNi =qxdaJLSMjgcHOBKyzRlYXUusEeCvNp.get('broad_url')
   qxdaJLSMjgcHOBKyzRlYXUusEeCvki =qxdaJLSMjgcHOBKyzRlYXUusEeCvNp.get('watermark') if 'watermark' in qxdaJLSMjgcHOBKyzRlYXUusEeCvNp else ''
   qxdaJLSMjgcHOBKyzRlYXUusEeCvkD=qxdaJLSMjgcHOBKyzRlYXUusEeCvNp.get('watermarkKey')if 'watermarkKey' in qxdaJLSMjgcHOBKyzRlYXUusEeCvNp else ''
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNT,qxdaJLSMjgcHOBKyzRlYXUusEeCvNh=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.Make_DecryptKey('2',mediacode=mediacode,timecode=qxdaJLSMjgcHOBKyzRlYXUusEeCvkp)
   qxdaJLSMjgcHOBKyzRlYXUusEeCvNm=qxdaJLSMjgcHOBKyzRlYXUusEeCvbN.DecryptPlaintext(qxdaJLSMjgcHOBKyzRlYXUusEeCvNi,qxdaJLSMjgcHOBKyzRlYXUusEeCvNT,qxdaJLSMjgcHOBKyzRlYXUusEeCvNh)
  except qxdaJLSMjgcHOBKyzRlYXUusEeCvQt as exception:
   qxdaJLSMjgcHOBKyzRlYXUusEeCvND(exception)
  return qxdaJLSMjgcHOBKyzRlYXUusEeCvNm,qxdaJLSMjgcHOBKyzRlYXUusEeCvki,qxdaJLSMjgcHOBKyzRlYXUusEeCvkD
# Created by pyminifier (https://github.com/liftoff/pyminifier)
